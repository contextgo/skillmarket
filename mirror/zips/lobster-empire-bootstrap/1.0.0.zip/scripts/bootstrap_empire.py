#!/usr/bin/env python3
"""
Lobster Empire bootstrap scaffold

Creates the minimum directory/file skeleton for a target workspace to become
Empire-compatible. This script is intentionally conservative:
- creates missing directories
- copies canonical state/memlib files from the current workspace
- optionally patches AGENTS.md with a startup binding block if missing
- does not touch gateway/config/system-critical settings

Usage:
  py scripts/bootstrap_empire.py --target <workspace-path> [--mode bootstrap-new|adopt-existing|repair-drift]
"""

from __future__ import annotations
import argparse
import shutil
from pathlib import Path

THIS_FILE = Path(__file__).resolve()
SKILL_DIR = THIS_FILE.parent.parent
WORKSPACE = SKILL_DIR.parent.parent

CANONICAL_FILES = {
    "state/task_api.py": WORKSPACE / "state" / "task_api.py",
    "state/context_injector.py": WORKSPACE / "state" / "context_injector.py",
    "state/watchdog.py": WORKSPACE / "state" / "watchdog.py",
    "memlib/state-db-watchdog-lesson-system.md": WORKSPACE / "memlib" / "state-db-watchdog-lesson-system.md",
    "memlib/main-agent-statedb-execution-protocol.md": WORKSPACE / "memlib" / "main-agent-statedb-execution-protocol.md",
    "memlib/cortex-core-interface.md": WORKSPACE / "memlib" / "cortex-core-interface.md",
}

STARTUP_BLOCK = """
## Empire Startup Binding (lobster-empire-bootstrap)
0. StateDB startup gate:
   - load `state/context_injector.py`
   - call `build_context_for_task(\"session startup\")` or equivalent before task routing
1. Read `memlib/cortex-core-interface.md` before substantive routing
2. For substantial tasks, prefer DB-first execution discipline from `memlib/main-agent-statedb-execution-protocol.md`
""".strip()


def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def safe_copy(src: Path, dst: Path):
    ensure_dir(dst.parent)
    shutil.copy2(src, dst)


def patch_agents_md(agents_path: Path):
    if not agents_path.exists():
        agents_path.write_text("# AGENTS.md\n\n" + STARTUP_BLOCK + "\n", encoding="utf-8")
        return "created"
    text = agents_path.read_text(encoding="utf-8")
    if "Empire Startup Binding (lobster-empire-bootstrap)" in text:
        return "already-present"
    agents_path.write_text(text.rstrip() + "\n\n" + STARTUP_BLOCK + "\n", encoding="utf-8")
    return "appended"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", required=True, help="Target workspace path")
    ap.add_argument("--mode", default="bootstrap-new", choices=["bootstrap-new", "adopt-existing", "repair-drift"])
    ap.add_argument("--copy-db", action="store_true", help="Also copy state/system.db if present")
    args = ap.parse_args()

    target = Path(args.target).resolve()
    ensure_dir(target)

    results = []
    for rel, src in CANONICAL_FILES.items():
        dst = target / rel
        safe_copy(src, dst)
        results.append(("copied", rel))

    if args.copy_db:
        src_db = WORKSPACE / "state" / "system.db"
        if src_db.exists():
            safe_copy(src_db, target / "state" / "system.db")
            results.append(("copied", "state/system.db"))

    agents_status = patch_agents_md(target / "AGENTS.md")
    results.append((agents_status, "AGENTS.md startup binding"))

    print(f"[lobster-empire-bootstrap] mode={args.mode}")
    print(f"target={target}")
    for status, item in results:
        print(f"- {status}: {item}")
    print("validation-next: run scripts/validate_empire_bootstrap.py --target <workspace>")


if __name__ == "__main__":
    main()
