#!/usr/bin/env python3
"""
Validate whether a target workspace satisfies the Lobster Empire minimum contract.
"""

from __future__ import annotations
import argparse
from pathlib import Path

REQUIRED_FILES = [
    "state/task_api.py",
    "state/context_injector.py",
    "state/watchdog.py",
    "memlib/state-db-watchdog-lesson-system.md",
    "memlib/main-agent-statedb-execution-protocol.md",
    "memlib/cortex-core-interface.md",
    "AGENTS.md",
]

REQUIRED_STARTUP_MARKERS = [
    "context_injector",
    "cortex-core-interface.md",
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", required=True, help="Target workspace path")
    args = ap.parse_args()

    target = Path(args.target).resolve()
    missing = []
    present = []

    for rel in REQUIRED_FILES:
        p = target / rel
        if p.exists():
            present.append(rel)
        else:
            missing.append(rel)

    startup_ok = False
    agents = target / "AGENTS.md"
    if agents.exists():
        text = agents.read_text(encoding="utf-8", errors="ignore")
        startup_ok = all(marker in text for marker in REQUIRED_STARTUP_MARKERS)

    label = "empire-ready"
    if missing:
        label = "repair-needed"
    elif not startup_ok:
        label = "partial-shell"

    print(f"target={target}")
    print(f"label={label}")
    print("present:")
    for item in present:
        print(f"- {item}")
    if missing:
        print("missing:")
        for item in missing:
            print(f"- {item}")
    print(f"startup-binding={'ok' if startup_ok else 'missing-or-incomplete'}")


if __name__ == "__main__":
    main()
