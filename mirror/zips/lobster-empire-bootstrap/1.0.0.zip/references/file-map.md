# File Map

## Canonical source files in current workspace

### State implementation
- `C:\Users\cloud_user\.openclaw\workspace\state\task_api.py`
- `C:\Users\cloud_user\.openclaw\workspace\state\context_injector.py`
- `C:\Users\cloud_user\.openclaw\workspace\state\watchdog.py`
- `C:\Users\cloud_user\.openclaw\workspace\state\system.db`

### Protocol documents
- `C:\Users\cloud_user\.openclaw\workspace\memlib\state-db-watchdog-lesson-system.md`
- `C:\Users\cloud_user\.openclaw\workspace\memlib\main-agent-statedb-execution-protocol.md`
- `C:\Users\cloud_user\.openclaw\workspace\memlib\cortex-core-interface.md`

### Optional supporting context
- `C:\Users\cloud_user\.openclaw\workspace\cortex\CORTEX.md`
- `C:\Users\cloud_user\.openclaw\workspace\memlib\cortex-spec.md`
- `C:\Users\cloud_user\.openclaw\workspace\MEMORY.md` (for architecture history only; do not treat as the protocol source)

## Recommended transplant targets
In a target workspace, place them as:
- `state/*`
- `memlib/*`
- `AGENTS.md` startup binding edits

## Do not forget
The highest-risk omission is not the DB file; it is forgetting to wire startup so the new lobster actually reads ContextInjector and Cortex protocol before work.
