# Empire Overview

## Goal
把一个“刚初始化、还没有帝国骨架”的 lobster，变成能接入龙虾帝国执行体系的节点。

## Empire core
龙虾帝国当前最小核心不是人格文案，而是这 4 层：

1. **Cortex 协调层**
   - 负责路由、收口、执行透明
   - 关键文件：`memlib/cortex-core-interface.md`

2. **StateDB 状态层**
   - 本地 SQLite 公海记忆
   - 关键文件：`state/system.db`, `state/task_api.py`

3. **Watchdog 巡逻层**
   - 定时检查超时任务、沉默 agent、lesson 入库
   - 关键文件：`state/watchdog.py`

4. **Context Injection 启动层**
   - 每次会话 / 每次实质任务启动前，从 DB 提取事实与教训
   - 关键文件：`state/context_injector.py`

## Why this matters
一个普通新 agent 只有提示词和短上下文；帝国节点多了：
- 任务状态机
- 跨角色 lessons
- 存活状态 / 心跳
- watchdog 硬约束
- 可恢复的共享上下文

## Minimum viable Empire node
至少要具备：
- DB 层存在
- protocol 层存在
- startup gate 存在
- watchdog 可运行
- main agent 知道“先记 DB，再执行”

## Current canonical local sources
在当前工作区里，帝国实现的权威来源主要是：
- `memlib/state-db-watchdog-lesson-system.md`
- `memlib/main-agent-statedb-execution-protocol.md`
- `memlib/cortex-core-interface.md`
- `state/task_api.py`
- `state/context_injector.py`
- `state/watchdog.py`

## Bootstrap philosophy
不是“复制文件 = 加入帝国”，而是：
- 复制必要实现
- 绑定启动入口
- 建立运行检查
- 保证未来任务真的会用它
