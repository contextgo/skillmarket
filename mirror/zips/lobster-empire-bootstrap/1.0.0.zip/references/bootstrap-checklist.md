# Bootstrap Checklist

Use this as the acceptance checklist after bootstrap or repair.

## A. State layer
- [ ] `state/` directory exists
- [ ] `state/task_api.py` exists
- [ ] `state/context_injector.py` exists
- [ ] `state/watchdog.py` exists
- [ ] `state/system.db` exists, or an initialization path is documented

## B. DB contract
- [ ] tasks table available
- [ ] facts table available
- [ ] lessons table available
- [ ] agent_heartbeat table available
- [ ] audit_log table available

## C. Protocol layer
- [ ] `memlib/state-db-watchdog-lesson-system.md` exists
- [ ] `memlib/main-agent-statedb-execution-protocol.md` exists
- [ ] `memlib/cortex-core-interface.md` exists

## D. Startup binding
- [ ] `AGENTS.md` startup includes StateDB/context check
- [ ] startup includes Cortex core interface read before routing
- [ ] target agent can read generated `state/current_context.json`

## E. Runtime behavior
- [ ] substantial tasks create DB tasks before execution
- [ ] heartbeat can be written during execution
- [ ] lessons can be submitted to inbox / lessons table
- [ ] watchdog has a runnable path

## F. Validation result labels
- If all A–E pass -> `empire-ready`
- If files exist but startup/runtime missing -> `partial-shell`
- If only docs copied -> `documentation-only`
- If DB layer broken -> `repair-needed`
