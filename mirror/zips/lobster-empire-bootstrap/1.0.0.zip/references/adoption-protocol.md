# Adoption Protocol

## Mode 1: bootstrap-new
Use when the target is nearly blank.

Order:
1. Create `state/` and `memlib/`
2. copy StateDB implementation files
3. copy protocol docs
4. initialize DB or bring over a clean starter DB
5. edit `AGENTS.md` startup binding
6. validate against checklist

## Mode 2: adopt-existing
Use when the target already has its own personality / files / workflows.

Order:
1. inspect for conflicts in `AGENTS.md`, startup logic, task system
2. preserve the target's local identity files
3. graft Empire state/protocol files
4. merge startup gate instead of replacing the whole file
5. validate runtime behavior

## Mode 3: repair-drift
Use when the target claims to be Empire-compatible but behavior drifted.

Typical drift signs:
- State files exist but are no longer read
- lessons are written but never injected
- watchdog script exists but does not launch
- AGENTS startup no longer enforces the StateDB gate

Repair order:
1. identify broken layer
2. restore only that layer
3. re-run checklist
4. mark remaining debt explicitly

## Reporting template
When done, report using:
- target mode
- inherited layers
- repaired layers
- blocked layers
- validation label (`empire-ready` / `partial-shell` / `repair-needed`)
