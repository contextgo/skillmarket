---
name: lobster-empire-bootstrap
description: Turn a freshly initialized OpenClaw agent or workspace into a Lobster Empire-compatible node. Use when the user wants to initialize, clone, transplant, bootstrap, or recreate the 龙虾帝国 core architecture; when a new lobster needs to inherit the Empire's operating model; or when building the minimum viable StateDB + Watchdog + ContextInjector + Cortex execution discipline in a fresh environment.
---

# Lobster Empire Bootstrap

Use this skill when the goal is not just to copy files, but to **turn a new lobster into an Empire-compatible execution unit**.

## Core outcome
A fresh agent/workspace should gain these capabilities:
- shared execution state via StateDB
- watchdog-based timeout / silence supervision
- lesson sharing across roles
- startup context injection
- Cortex-style coordination discipline
- main-agent DB-first execution habit

## Trigger conditions
Use this skill when the user asks to:
- 把龙虾帝国核心架构做成技能
- 初始化一个新龙虾 / 新分身 / 新工作区
- 让一个新 agent 接入帝国
- 复制 / 迁移 / 重建 StateDB + Watchdog + LessonSync 架构
- 给新环境补上帝国执行协议
- bootstrap / transplant / inherit the Lobster Empire architecture

## What to read first
Always read these references in this order:
1. `references/empire-overview.md`
2. `references/bootstrap-checklist.md`
3. If the task includes real implementation, also read:
   - `references/file-map.md`
   - `references/adoption-protocol.md`

## Built-in scripts
Use these when real execution is needed:
- `scripts/bootstrap_empire.py` — scaffold/copy the minimum Empire stack into a target workspace
- `scripts/validate_empire_bootstrap.py` — validate whether the target already satisfies the Empire minimum contract

Preferred execution on this machine:
```powershell
& "C:\Users\cloud_user\AppData\Local\Programs\Python\Python314\python.exe" skills\lobster-empire-bootstrap\scripts\bootstrap_empire.py --target <workspace>
& "C:\Users\cloud_user\AppData\Local\Programs\Python\Python314\python.exe" skills\lobster-empire-bootstrap\scripts\validate_empire_bootstrap.py --target <workspace>
```

## Empire minimum contract
A lobster is considered "joined the Empire" only when all of these are true:
1. Has a local StateDB (`state/system.db`) with the 5 core tables
2. Has `state/task_api.py`
3. Has `state/context_injector.py`
4. Has `state/watchdog.py`
5. Startup flow reads ContextInjector before task routing
6. Main agent follows DB-first task execution for substantial tasks
7. Lessons are shared cross-role instead of trapped in one agent
8. A watchdog launch path exists (manual or auto-start)

## Workflow
1. Identify the target environment:
   - same machine new workspace
   - another OpenClaw workspace
   - partial repair of an existing Empire node
2. Read the architecture references.
3. Inspect whether the target already has any of these:
   - `state/`
   - `memlib/`
   - `AGENTS.md` startup gate
   - existing watchdog / task DB
4. Choose one mode:
   - **bootstrap-new**: create the minimum Empire stack from scratch
   - **adopt-existing**: graft Empire protocols onto an existing workspace
   - **repair-drift**: fix a broken or half-installed Empire node
5. Apply files in dependency order:
   - state layer
   - memlib protocol layer
   - startup binding layer
   - watchdog launch / health validation
6. Verify with the checklist in `references/bootstrap-checklist.md`.
7. Report what was inherited, what was skipped, and what still needs manual action.

## Required file groups
### 1) State layer
Mandatory core files:
- `state/task_api.py`
- `state/context_injector.py`
- `state/watchdog.py`
- `state/system.db` or an init path that creates it

### 2) Protocol layer
Mandatory mechanism files:
- `memlib/state-db-watchdog-lesson-system.md`
- `memlib/main-agent-statedb-execution-protocol.md`
- `memlib/cortex-core-interface.md`

### 3) Startup binding layer
At minimum, the target `AGENTS.md` startup must enforce:
- StateDB/context check before routing
- Cortex core interface read before substantive work

## Adoption rules
- Do not claim Empire bootstrap is complete if only files were copied but startup binding was not added.
- Do not claim success if Watchdog exists but cannot be launched.
- Do not leave the target in a "half-Empire" state without explicitly marking missing layers.
- If asked to produce a reusable skill, prefer a concise SKILL.md plus references over a giant monolith.

## When to create scripts
Create helper scripts only if the same bootstrap logic will be repeated or if deterministic setup is needed.
Good candidates:
- file copy / scaffold script
- validation script
- watchdog registration helper

This skill already includes:
- `scripts/bootstrap_empire.py`
- `scripts/validate_empire_bootstrap.py`

## Output expectations
When you finish, provide:
- installed layers
- skipped / blocked layers
- exact files added or expected
- validation result against the minimum contract
- next manual step if any

## Guardrails
- Do not silently overwrite a user's existing architecture without telling them.
- For system-critical config or gateway changes, ask first.
- If bootstrap is cross-machine and you cannot access the target, produce a transplant packet instead of pretending it is live.

## Success condition
The skill is successful when a future fresh lobster can use this skill to reliably become an Empire-compatible node rather than merely receiving a pile of copied files.
