from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from PIL import Image
import os, glob

pptx_path = r"C:\Users\一梦繁星\.qclaw\workspace\agents\skills\song-seed\song-seed-intro.pptx"
output_dir = r"C:\Users\一梦繁星\.qclaw\workspace\agents\skills\song-seed\slides"
os.makedirs(output_dir, exist_ok=True)

prs = Presentation(pptx_path)

for i, slide in enumerate(prs.slides, 1):
    # Render via LibreOffice is ideal, but we fallback to extracting text
    # since soffice not available - just grab slide metadata for now
    print(f"Slide {i}: {len(slide.shapes)} shapes")

print(f"\nTotal slides: {len(prs.slides)}")
print("LibreOffice not available for image render.")
print("PPT file is ready at:", pptx_path)
