const pptxgen = require("pptxgenjs");

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "歌词种子 song-seed";
pres.author = "song-seed skill";

// Color palette: Warm creative night theme
const C = {
  dark: "1A1A2E",      // deep night background
  primary: "FF6B35",    // warm orange - seed/flame
  secondary: "7C3AED",  // purple - creative
  light: "F5F0E8",      // cream
  muted: "94A3B8",      // muted text
  white: "FFFFFF",
  accent: "FCD34D",     // yellow accent
};

const makeShadow = () => ({
  type: "outer", blur: 8, offset: 3, angle: 135, color: "000000", opacity: 0.2,
});

// ── Slide 1: Title ──
{
  let slide = pres.addSlide();
  slide.background = { color: C.dark };

  // Left purple accent bar
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 0, y: 0, w: 0.15, h: 5.625,
    fill: { color: C.secondary },
  });

  // Big orange circle (seed)
  slide.addShape(pres.shapes.OVAL, {
    x: 7.0, y: 0.8, w: 3.5, h: 3.5,
    fill: { color: C.primary, transparency: 15 },
  });

  // Main title
  slide.addText("歌词种子", {
    x: 0.6, y: 1.2, w: 6.5, h: 1.4,
    fontSize: 56, fontFace: "Trebuchet MS", bold: true,
    color: C.white, margin: 0,
  });

  slide.addText("song-seed", {
    x: 0.6, y: 2.5, w: 6, h: 0.6,
    fontSize: 22, fontFace: "Calibri", italic: true,
    color: C.primary, margin: 0,
  });

  slide.addText("帮你找到写歌词的第一颗种子", {
    x: 0.6, y: 3.3, w: 6, h: 0.5,
    fontSize: 18, fontFace: "Calibri",
    color: C.muted, margin: 0,
  });

  // Bottom tag
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 0.6, y: 4.8, w: 2.5, h: 0.45,
    fill: { color: C.secondary },
  });
  slide.addText("灵感激活技能  ·  蒸馏自赵英俊", {
    x: 0.6, y: 4.8, w: 2.5, h: 0.45,
    fontSize: 10, fontFace: "Calibri", bold: true,
    color: C.white, align: "center", valign: "middle",
  });
}

// ── Slide 2: The Problem ──
{
  let slide = pres.addSlide();
  slide.background = { color: C.light };

  // Title
  slide.addText("写歌词最大的痛苦", {
    x: 0.5, y: 0.4, w: 9, h: 0.7,
    fontSize: 32, fontFace: "Trebuchet MS", bold: true,
    color: C.dark, margin: 0,
  });

  // Pain point cards
  const pains = [
    { icon: "?", text: "完全没方向\n不知道该写什么" },
    { icon: "💭", text: "有情绪但写不出来\n感觉不够" },
    { icon: "📖", text: "想借经典老歌\n但不知道怎么改" },
    { icon: "🎬", text: "为电影/短视频写歌\n找不到角度" },
  ];

  pains.forEach((p, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = 0.5 + col * 4.7;
    const y = 1.4 + row * 1.9;

    // Card background
    slide.addShape(pres.shapes.RECTANGLE, {
      x, y, w: 4.3, h: 1.6,
      fill: { color: C.white },
      shadow: makeShadow(),
    });
    // Left accent
    slide.addShape(pres.shapes.RECTANGLE, {
      x, y, w: 0.1, h: 1.6,
      fill: { color: C.secondary },
    });
    // Icon circle
    slide.addShape(pres.shapes.OVAL, {
      x: x + 0.3, y: y + 0.3, w: 0.9, h: 0.9,
      fill: { color: C.secondary, transparency: 85 },
    });
    slide.addText(p.icon, {
      x: x + 0.3, y: y + 0.3, w: 0.9, h: 0.9,
      fontSize: 22, align: "center", valign: "middle",
    });
    // Text
    slide.addText(p.text, {
      x: x + 1.4, y: y + 0.35, w: 2.7, h: 1.0,
      fontSize: 14, fontFace: "Calibri",
      color: C.dark, valign: "middle",
    });
  });
}

// ── Slide 3: The Person ──
{
  let slide = pres.addSlide();
  slide.background = { color: C.white };

  // Purple right panel
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 6.5, y: 0, w: 3.5, h: 5.625,
    fill: { color: C.secondary, transparency: 10 },
  });

  slide.addText("为什么是赵英俊", {
    x: 0.5, y: 0.4, w: 5.5, h: 0.7,
    fontSize: 32, fontFace: "Trebuchet MS", bold: true,
    color: C.dark, margin: 0,
  });

  // Key facts
  const facts = [
    "辽宁抚顺人，1977-2021，肝癌去世，享年43岁",
    "从未发过正式专辑，却留下多首热门电影主题曲",
    "《送你一朵小红花》《大王叫我来巡山》",
    "《港囧》《煎饼侠》《唐人街探案》配乐词曲",
  ];
  facts.forEach((f, i) => {
    slide.addShape(pres.shapes.OVAL, {
      x: 0.5, y: 1.35 + i * 0.75, w: 0.3, h: 0.3,
      fill: { color: C.primary },
    });
    slide.addText(f, {
      x: 1.0, y: 1.28 + i * 0.75, w: 5.2, h: 0.45,
      fontSize: 14, fontFace: "Calibri",
      color: C.dark, margin: 0,
    });
  });

  // Quote
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 6.8, y: 1.2, w: 2.9, h: 3.2,
    fill: { color: C.secondary },
  });
  slide.addText("\u201C做电影配乐，其实和做个厨子没什么区别\u201D", {
    x: 7.0, y: 1.6, w: 2.5, h: 2.2,
    fontSize: 16, fontFace: "Calibri", italic: true,
    color: C.white, valign: "middle",
  });
  slide.addText("— 赵英俊", {
    x: 7.0, y: 3.8, w: 2.5, h: 0.4,
    fontSize: 12, fontFace: "Calibri",
    color: C.accent, align: "right", margin: 0,
  });
}

// ── Slide 4: Core Value ──
{
  let slide = pres.addSlide();
  slide.background = { color: C.dark };

  slide.addText("这个 skill 能做什么", {
    x: 0.5, y: 0.4, w: 9, h: 0.7,
    fontSize: 32, fontFace: "Trebuchet MS", bold: true,
    color: C.white, margin: 0,
  });

  // Two columns
  // Left: NOT
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 0.5, y: 1.4, w: 4.3, h: 3.5,
    fill: { color: "2A2A4A" },
  });
  slide.addText("✗  不是代写枪手", {
    x: 0.7, y: 1.5, w: 4, h: 0.55,
    fontSize: 18, fontFace: "Trebuchet MS", bold: true,
    color: C.muted, margin: 0,
  });
  const nots = [
    "帮你写完整歌词",
    "给你押韵词典",
    "评判歌词好坏",
  ];
  nots.forEach((n, i) => {
    slide.addText(n, {
      x: 0.9, y: 2.15 + i * 0.65, w: 3.5, h: 0.5,
      fontSize: 14, fontFace: "Calibri",
      color: C.muted,
    });
  });

  // Right: IS
  slide.addShape(pres.shapes.RECTANGLE, {
    x: 5.2, y: 1.4, w: 4.3, h: 3.5,
    fill: { color: C.primary, transparency: 20 },
  });
  slide.addText("✓  是灵感搭档", {
    x: 5.4, y: 1.5, w: 4, h: 0.55,
    fontSize: 18, fontFace: "Trebuchet MS", bold: true,
    color: C.accent, margin: 0,
  });
  const is = [
    "帮你找到想写的主题",
    "把模糊情绪翻译成方向",
    "给你可以落笔的具体角度",
  ];
  is.forEach((s, i) => {
    slide.addText(s, {
      x: 5.6, y: 2.15 + i * 0.65, w: 3.5, h: 0.5,
      fontSize: 14, fontFace: "Calibri",
      color: C.white,
    });
  });
}

// ── Slide 5: 5 Core Methods ──
{
  let slide = pres.addSlide();
  slide.background = { color: C.light };

  slide.addText("赵英俊的 5 个创作心智", {
    x: 0.5, y: 0.4, w: 9, h: 0.7,
    fontSize: 32, fontFace: "Trebuchet MS", bold: true,
    color: C.dark, margin: 0,
  });

  const methods = [
    { title: "小人物视角", desc: "用\u201C我\u201D不说\u201C我们\u201D，用日常细节代替抽象概念" },
    { title: "二度创作", desc: "借经典老歌的情绪结构，换主题写新内容" },
    { title: "苦涩幽默", desc: "先让人笑，再让人心酸——苦中作乐的智慧" },
    { title: "具象意象", desc: "不写\u201C我孤独\u201D，写一个具体的孤独动作" },
    { title: "电影配乐思维", desc: "歌词是电影没说出口的话，不是附庸" },
  ];

  methods.forEach((m, i) => {
    const y = 1.2 + i * 0.82;

    // Number circle
    slide.addShape(pres.shapes.OVAL, {
      x: 0.5, y, w: 0.55, h: 0.55,
      fill: { color: C.secondary },
    });
    slide.addText(String(i + 1), {
      x: 0.5, y, w: 0.55, h: 0.55,
      fontSize: 16, fontFace: "Trebuchet MS", bold: true,
      color: C.white, align: "center", valign: "middle",
    });

    // Title
    slide.addText(m.title, {
      x: 1.25, y, w: 2.5, h: 0.55,
      fontSize: 16, fontFace: "Trebuchet MS", bold: true,
      color: C.dark, valign: "middle", margin: 0,
    });

    // Desc
    slide.addText(m.desc, {
      x: 3.8, y, w: 5.7, h: 0.55,
      fontSize: 14, fontFace: "Calibri",
      color: C.muted, valign: "middle",
    });

    // Separator line
    if (i < 4) {
      slide.addShape(pres.shapes.LINE, {
        x: 0.5, y: y + 0.72, w: 9, h: 0,
        line: { color: "E2E8F0", width: 0.5 },
      });
    }
  });
}

// ── Slide 6: 4 Workflows ──
{
  let slide = pres.addSlide();
  slide.background = { color: C.white };

  slide.addText("4 个工作流", {
    x: 0.5, y: 0.4, w: 9, h: 0.7,
    fontSize: 32, fontFace: "Trebuchet MS", bold: true,
    color: C.dark, margin: 0,
  });

  const workflows = [
    { label: "A", title: "有情绪写不出", desc: "从模糊情绪 → 具体场景 → 可写方向", color: C.primary },
    { label: "B", title: "完全没方向", desc: "从生活触发点切入，找到创作原点", color: C.secondary },
    { label: "C", title: "二度创作", desc: "借经典结构，换主题，写出新意", color: "059669" },
    { label: "D", title: "电影配乐", desc: "找到电影没说出口的那句话", color: "DC2626" },
  ];

  workflows.forEach((w, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = 0.5 + col * 4.7;
    const y = 1.2 + row * 2.1;

    slide.addShape(pres.shapes.RECTANGLE, {
      x, y, w: 4.3, h: 1.8,
      fill: { color: C.light },
      shadow: makeShadow(),
    });
    // Top color bar
    slide.addShape(pres.shapes.RECTANGLE, {
      x, y, w: 4.3, h: 0.1,
      fill: { color: w.color },
    });
    // Label circle
    slide.addShape(pres.shapes.OVAL, {
      x: x + 0.25, y: y + 0.35, w: 0.65, h: 0.65,
      fill: { color: w.color },
    });
    slide.addText(w.label, {
      x: x + 0.25, y: y + 0.35, w: 0.65, h: 0.65,
      fontSize: 20, fontFace: "Trebuchet MS", bold: true,
      color: C.white, align: "center", valign: "middle",
    });
    slide.addText(w.title, {
      x: x + 1.1, y: y + 0.3, w: 3, h: 0.5,
      fontSize: 16, fontFace: "Trebuchet MS", bold: true,
      color: C.dark, margin: 0,
    });
    slide.addText(w.desc, {
      x: x + 0.25, y: y + 1.1, w: 3.8, h: 0.5,
      fontSize: 13, fontFace: "Calibri",
      color: C.muted,
    });
  });
}

// ── Slide 7: Live Demo ──
{
  let slide = pres.addSlide();
  slide.background = { color: C.dark };

  slide.addText("现场演示", {
    x: 0.5, y: 0.4, w: 9, h: 0.7,
    fontSize: 32, fontFace: "Trebuchet MS", bold: true,
    color: C.white, margin: 0,
  });

  // Demo conversation bubbles
  const convs = [
    { who: "用户", text: "我想写歌，但完全不知道想写什么", color: "374151", align: "left" },
    { who: "AI", text: "最近有没有一件事、一段情绪，哪怕很模糊——\n说个大概就行", color: C.secondary, align: "right" },
    { who: "用户", text: "最近晚上总是失眠，想写失眠的感觉", color: "374151", align: "left" },
    { who: "AI", text: "你失眠的时候，身体是什么感觉？\n是身体累但脑子停不下来，还是整个人焦躁？", color: C.secondary, align: "right" },
  ];

  convs.forEach((c, i) => {
    const x = c.align === "right" ? 3.5 : 0.5;
    const y = 1.2 + i * 1.05;
    const bg = c.align === "right" ? c.color : "2A2A4A";

    slide.addShape(pres.shapes.RECTANGLE, {
      x, y, w: 6.2, h: 0.9,
      fill: { color: bg },
    });
    slide.addText(c.text, {
      x: x + 0.2, y, w: 5.8, h: 0.9,
      fontSize: 13, fontFace: "Calibri",
      color: C.white, valign: "middle",
    });
  });
}

// ── Slide 8: Target Users ──
{
  let slide = pres.addSlide();
  slide.background = { color: C.light };

  slide.addText("谁在用这个技能", {
    x: 0.5, y: 0.4, w: 9, h: 0.7,
    fontSize: 32, fontFace: "Trebuchet MS", bold: true,
    color: C.dark, margin: 0,
  });

  const users = [
    { emoji: "🎤", text: "词曲创作者", sub: "签约/独立音乐人，找不到方向时" },
    { emoji: "📱", text: "短视频创作者", sub: "需要为内容写BGM/片尾曲" },
    { emoji: "🎬", text: "影视文案策划", sub: "想为短片找到对的那句歌词" },
    { emoji: "💬", text: "任何想写歌词的人", sub: "有情绪想表达，但不知道怎么落笔" },
  ];

  users.forEach((u, i) => {
    const y = 1.2 + i * 1.05;

    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0.5, y, w: 9, h: 0.85,
      fill: { color: C.white },
      shadow: makeShadow(),
    });
    // Left emoji area
    slide.addShape(pres.shapes.RECTANGLE, {
      x: 0.5, y, w: 1.0, h: 0.85,
      fill: { color: C.secondary, transparency: 90 },
    });
    slide.addText(u.emoji, {
      x: 0.5, y, w: 1.0, h: 0.85,
      fontSize: 22, align: "center", valign: "middle",
    });
    slide.addText(u.text, {
      x: 1.7, y: y + 0.08, w: 4, h: 0.4,
      fontSize: 15, fontFace: "Trebuchet MS", bold: true,
      color: C.dark, margin: 0,
    });
    slide.addText(u.sub, {
      x: 1.7, y: y + 0.45, w: 7, h: 0.35,
      fontSize: 12, fontFace: "Calibri",
      color: C.muted, margin: 0,
    });
  });
}

// ── Slide 9: Closing ──
{
  let slide = pres.addSlide();
  slide.background = { color: C.secondary };

  slide.addText("song-seed", {
    x: 0.5, y: 1.5, w: 9, h: 1.2,
    fontSize: 60, fontFace: "Trebuchet MS", bold: true,
    color: C.white, align: "center", margin: 0,
  });

  slide.addText("播下一颗歌词种子，长出一首歌", {
    x: 0.5, y: 2.8, w: 9, h: 0.6,
    fontSize: 22, fontFace: "Calibri",
    color: C.accent, align: "center",
  });

  slide.addShape(pres.shapes.LINE, {
    x: 3.5, y: 3.6, w: 3, h: 0,
    line: { color: C.white, width: 1, transparency: 50 },
  });

  slide.addText("灵感激活技能  ·  蒸馏自赵英俊", {
    x: 0.5, y: 3.9, w: 9, h: 0.4,
    fontSize: 13, fontFace: "Calibri",
    color: C.white, align: "center", transparency: 60,
  });

  slide.addText("agents/skills/song-seed", {
    x: 0.5, y: 4.5, w: 9, h: 0.4,
    fontSize: 12, fontFace: "Consolas",
    color: C.accent, align: "center",
  });
}

pres.writeFile({ fileName: "C:\\Users\\一梦繁星\\.qclaw\\workspace\\agents\\skills\\song-seed\\song-seed-intro.pptx" })
  .then(() => console.log("Done!"))
  .catch(e => { console.error(e); process.exit(1); });
