"""
song-seed MCP 工具
歌词灵感激活引擎 - 赵英俊创作心智封装

用法:
python song_seed.py --emotion "加班特别累" --scene "城市疲惫"
"""

import sys
import os
import json
import argparse
import re
from typing import Dict, List, Optional

# Windows UTF-8 修复
if sys.platform == "win32":
    os.environ["PYTHONIOENCODING"] = "utf-8"
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# ============ 赵英俊歌词风格库 ============

STYLE_DIRECTIONS = {
    "苦涩幽默": {
        "description": "用幽默的方式写沉重的故事，先让人笑再让人哭",
        "keywords": ["荒诞", "段子", "笑着说", "搞笑", "讽刺"],
        "example_openings": [
            "太阳当空照，花儿对我笑",
            "大王叫我来巡山，我把人间走一遍"
        ],
        "activation_questions": [
            "这件事如果写成段子，怎么讲？",
            "最荒诞的瞬间是什么？",
            "你能笑着说一件难过的事吗？"
        ]
    },
    "具象意象": {
        "description": "不写抽象情绪，写一个具体的动作/画面/物品",
        "keywords": ["画面", "动作", "细节", "物品", "场景"],
        "example_openings": [
            "雨一直下，气氛不太融洽",
            "那是我最后一次看见天的表情"
        ],
        "activation_questions": [
            "有没有一个画面一直在你脑子里？",
            "如果只能用一个动作表达，是什么？",
            "什么东西你一直留着不舍得扔？"
        ]
    },
    "小人物视角": {
        "description": "用普通人的立场，不高大全",
        "keywords": ["普通人", "日常", "身边", "你我他"],
        "example_openings": [
            "吃饭，你家乡怎么念",
            "他们的唠叨是世上最美的歌"
        ],
        "activation_questions": [
            "身边最普通的一件事是什么？",
            "的你我他日常是什么？",
            "有什么小事一直想做但没做？"
        ]
    },
    "生命力量": {
        "description": "温柔有力，奖励式表达",
        "keywords": ["奖励", "小红花", "勇气", "温柔", "力量"],
        "example_openings": [
            "送你一朵小红花，奖励你有勇气主动来和我说话",
            "我，一定会回来的"
        ],
        "activation_questions": [
            "什么时候你觉得自己挺过来了？",
            "如果这是最后一首歌，你会说什么？",
            "什么东西你一直留着不舍得扔？"
        ]
    },
    "二度创作": {
        "description": "借经典结构换主题，不是抄袭",
        "keywords": ["借", "改编", "致敬", "老歌", "经典"],
        "example_openings": [
            "刺激2005 - 借用多首经典",
            "世界上不存在的歌 - 虚构经典"
        ],
        "activation_questions": [
            "哪首歌最打动你？",
            "你现在情绪和那首歌一样还是相反？"
        ]
    }
}

# ============ 场景到方向的映射 ============

SCENE_MAPPING = {
    "城市": "苦涩幽默",
    "加班": "苦涩幽默", 
    "疲惫": "苦涩幽默",
    "夜晚": "具象意象",
    "一个人": "具象意象",
    "离乡": "小人物视角",
    "外地": "小人物视角",
    "漂泊": "小人物视角",
    "亲情": "生命力量",
    "外婆": "生命力量",
    "告别": "生命力量",
    "失去": "生命力量",
    "分手": "生命力量",
    "暗恋": "生命力量",
    "电影": "二度创作",
    "配乐": "二度创作",
    "老歌": "二度创作",
    "借歌": "二度创作"
}

# ============ 赵英俊代表歌曲 ============

ZHAO_SONGS = {
    "大王叫我来巡山": {
        "type": "苦涩幽默",
        "mood": "表面轻松背后有分量",
        "lyrics": "大王叫我来巡山，抓个和尚来做晚餐..."
    },
    "送你一朵小红花": {
        "type": "生命力量", 
        "mood": "温柔有力",
        "lyrics": "送你一朵小红花，奖励你有勇气主动来和我说话"
    },
    "方的言": {
        "type": "小人物视角",
        "mood": "方言与漂泊",
        "lyrics": "吃饭，你家乡怎么念..."
    },
    "我一定会回来的": {
        "type": "生命力量",
        "mood": "承诺与执着",
        "lyrics": "我，一定会回来的"
    },
    "刺激2005": {
        "type": "二度创作",
        "mood": "经典串烧",
        "lyrics": "借多首经典拼接"
    },
    "世界上不存在的歌": {
        "type": "二度创作",
        "mood": "虚构经典",
        "lyrics": "我想写一首世界上不存在的歌"
    }
}


def detect_emotion_type(emotion: str, scene: str = "") -> str:
    """检测情绪类型"""
    text = (emotion + " " + scene).lower()
    
    # 先尝试场景映射
    for key, direction in SCENE_MAPPING.items():
        if key in text:
            return direction
    
    # 尝试关键词匹配
    for direction, data in STYLE_DIRECTIONS.items():
        for keyword in data["keywords"]:
            if keyword in text:
                return direction
    
    # 默认返回苦涩幽默（最常用）
    return "苦涩幽默"


def generate_activation_questions(emotion: str, direction: str, mode: str = "deep") -> List[str]:
    """生成激活问题"""
    questions = STYLE_DIRECTIONS[direction]["activation_questions"]
    
    if mode == "quick":
        return questions[:1]  # 快速模式只返回一个
    
    return questions


def map_to_scenes(emotion: str, scene: str) -> List[Dict]:
    """映射到具体场景"""
    scenes = []
    
    # 从情绪词提取场景
    emotional_words = emotion.replace("我", "").replace("的", "").replace("很", "").replace("特别", "").strip()
    
    # 构建场景映射
    if "加班" in emotion or "工作" in emotion:
        scenes.append({"scene": "早上睁眼的那一刻", "direction": "具象意象"})
        scenes.append({"scene": "等人的焦虑", "direction": "具象意象"})
    
    if "城市" in emotion or "外地" in emotion or "漂泊" in emotion:
        scenes.append({"scene": "家乡的什么吃的你最想", "direction": "小人物视角"})
        scenes.append({"scene": "现在住的地方不习惯的", "direction": "小人物视角"})
    
    if "分手" in emotion or "失去" in emotion:
        scenes.append({"scene": "最后悔没说的一句话", "direction": "生命力量"})
        scenes.append({"scene": "当时没说后来很后悔", "direction": "生命力量"})
    
    # 默认场景
    if not scenes:
        scenes = [
            {"scene": "一个人的夜里", "direction": "具象意象"},
            {"scene": "他们都说", "direction": "苦涩幽默"},
            {"scene": "明天再说", "direction": "苦涩幽默"}
        ]
    
    return scenes


def generate_directions(emotion: str, scene: str = "") -> List[Dict]:
    """生成方向选项"""
    direction_type = detect_emotion_type(emotion, scene)
    
    directions = []
    for name, data in STYLE_DIRECTIONS.items():
        score = 1.0 if name == direction_type else 0.6
        directions.append({
            "direction": name,
            "description": data["description"],
            "score": score,
            "example_opening": data["example_openings"][0] if data["example_openings"] else ""
        })
    
    # 按得分排序
    directions.sort(key=lambda x: x["score"], reverse=True)
    
    return directions


def find_reference_songs(emotion: str, scene: str = "") -> List[Dict]:
    """查找参考歌曲"""
    direction = detect_emotion_type(emotion, scene)
    
    songs = []
    for name, data in ZHAO_SONGS.items():
        if data["type"] == direction:
            songs.append({
                "song": name,
                "mood": data["mood"],
                "snippet": data["lyrics"][:50] + "..." if len(data["lyrics"]) > 50 else data["lyrics"]
            })
    
    # 如果找不到同类型的，返回所有
    if not songs:
        for name, data in ZHAO_SONGS.items():
            songs.append({
                "song": name,
                "mood": data["mood"],
                "snippet": data["lyrics"][:50] + "..." if len(data["lyrics"]) > 50 else data["lyrics"]
            })
    
    return songs[:3]  # 最多返回3首


def activate(emotion: str, scene: str = "", mode: str = "deep", work: str = "写歌") -> Dict:
    """
    核心激活函数
    
    Args:
        emotion: 用户情绪描述
        scene: 场景类型
        mode: quick|deep
        work: 创作目标
    
    Returns:
        包含 directions, activation_questions, reference_songs, example_openings 的字典
    """
    
    # 1. 检测情绪类型
    direction_type = detect_emotion_type(emotion, scene)
    
    # 2. 生成方向选项
    directions = generate_directions(emotion, scene)
    
    # 3. 生成激活问题
    activation_questions = generate_activation_questions(emotion, direction_type, mode)
    
    # 4. 查找参考歌曲
    reference_songs = find_reference_songs(emotion, scene)
    
    # 5. 生成场景选项（快速模式）
    scenes = map_to_scenes(emotion, scene) if mode == "quick" else []
    
    # 6. 构建示例开头
    example_openings = []
    if directions:
        for d in directions[:3]:
            if d.get("example_opening"):
                example_openings.append(d["example_opening"])
    
    return {
        "success": True,
        "direction_detected": direction_type,
        "directions": directions,
        "activation_questions": activation_questions,
        "reference_songs": reference_songs,
        "example_openings": example_openings,
        "scenes": scenes,  # 快速模式专用
        "message": f"检测到情绪类型：{direction_type}，以下是可选择的方向"
    }


def main():
    parser = argparse.ArgumentParser(description="song-seed 歌词灵感激活")
    parser.add_argument("--emotion", "-e", required=True, help="用户情绪描述")
    parser.add_argument("--scene", "-s", default="", help="场景类型")
    parser.add_argument("--mode", "-m", default="deep", choices=["quick", "deep"], help="模式")
    parser.add_argument("--work", "-w", default="写歌", help="创作目标")
    parser.add_argument("--quiet", "-q", action="store_true", help="安静模式（只输出JSON）")
    
    args = parser.parse_args()
    
    result = activate(args.emotion, args.scene, args.mode, args.work)
    
    if args.quiet:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"\n{'='*50}")
        print(f"🎵 song-seed 歌词灵感激活")
        print(f"{'='*50}")
        print(f"\n检测到情绪类型：{result['direction_detected']}")
        print(f"\n📋 可选择的方向：")
        for i, d in enumerate(result["directions"], 1):
            print(f"  {i}. {d['direction']} - {d['description']}")
            if d.get("example_opening"):
                print(f"     示例：{d['example_opening']}")
        
        print(f"\n❓ 激活问题：")
        for q in result["activation_questions"]:
            print(f"  • {q}")
        
        if result["reference_songs"]:
            print(f"\n🎶 参考歌曲：")
            for s in result["reference_songs"]:
                print(f"  • {s['song']} ({s['mood']})")
        
        if result["scenes"]:
            print(f"\n🌟 快速场景（{args.mode}模式）：")
            for s in result["scenes"]:
                print(f"  • {s['scene']} → {s['direction']}")
        
        print(f"\n{'='*50}\n")
    
    return result


if __name__ == "__main__":
    main()