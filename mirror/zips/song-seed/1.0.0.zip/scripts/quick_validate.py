#!/usr/bin/env python3
"""Quick validation script for skills - 修正编码版"""

import sys
import os
import re
import yaml
from pathlib import Path

def validate_skill(skill_path):
    skill_path = Path(skill_path)

    # Check SKILL.md exists
    skill_md = skill_path / 'SKILL.md'
    if not skill_md.exists():
        return False, "SKILL.md not found"

    # Read with UTF-8
    try:
        content = skill_md.read_text(encoding='utf-8')
    except Exception as e:
        return False, f"Cannot read SKILL.md: {e}"

    if not content.startswith('---'):
        return False, "No YAML frontmatter found"

    # Extract frontmatter
    match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
    if not match:
        return False, "Invalid frontmatter format"

    frontmatter_text = match.group(1)

    # Parse YAML frontmatter
    try:
        frontmatter = yaml.safe_load(frontmatter_text)
        if not isinstance(frontmatter, dict):
            return False, "Frontmatter must be a YAML dictionary"
    except yaml.YAMLError as e:
        return False, f"Invalid YAML in frontmatter: {e}"

    # Define allowed properties
    ALLOWED_PROPERTIES = {'name', 'description', 'license', 'allowed-tools', 'metadata', 'compatibility'}

    # Check for unexpected properties
    unexpected_keys = set(frontmatter.keys()) - ALLOWED_PROPERTIES
    if unexpected_keys:
        return False, f"Unexpected key(s): {', '.join(sorted(unexpected_keys))}. Allowed: {', '.join(sorted(ALLOWED_PROPERTIES))}"

    # Check required fields
    if 'name' not in frontmatter:
        return False, "Missing 'name'"
    if 'description' not in frontmatter:
        return False, "Missing 'description'"

    # Validate name format
    name = frontmatter.get('name', '').strip()
    if name and not re.match(r'^[a-z0-9-]+$', name):
        return False, f"Name '{name}' should be kebab-case"
    if name.startswith('-') or name.endswith('-') or '--' in name:
        return False, "Name cannot start/end with hyphen or contain consecutive hyphens"

    # Validate description
    desc = frontmatter.get('description', '').strip()
    if desc and ('<' in desc or '>' in desc):
        return False, "Description cannot contain angle brackets"

    return True, "Skill is valid!"


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python quick_validate.py <skill_directory>")
        sys.exit(1)
    
    valid, message = validate_skill(sys.argv[1])
    print(message)
    sys.exit(0 if valid else 1)