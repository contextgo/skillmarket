---
name: gpt-image-2-enhanced
description: Enhanced GPT Image 2 skill with 17 categories, 99+ templates, Gemini-style API support, and scenario-based template lookup. Use when the user wants to generate images using the gpt-image-2 model via OpenAI-compatible or Gemini-style APIs, needs to find the right template for their image generation task, wants to batch generate images, or needs to understand the complete gpt-image-2 template ecosystem. Covers infographics, posters, UI mockups, academic figures, branding, product visuals, maps, portraits, comics, technical diagrams, and editing workflows.
---

# GPT Image 2 Enhanced

This skill documents all enhancements made to the base `gpt-image-2` skill. It provides:

- Dual API support (OpenAI + Gemini style)
- 3 new custom templates
- Complete template catalog (17 categories / 99 templates)
- Scenario-based quick lookup
- Correct API calling format for Gemini-style endpoints

## API Support

### Gemini-Style API (e.g., nn.147ai.com)

The enhanced `generate.js` auto-detects Gemini-style APIs via `isGeminiApi()` in `shared.js`. Detection triggers when `OPENAI_BASE_URL` contains `nn.147ai.com` or `API_STYLE=gemini` env var is set.

**Endpoint:**
```
POST https://nn.147ai.com/v1beta/models/gpt-image-2:generateContent
```

**Request format:**
```json
{
  "contents": [{
    "parts": [{"text": "your image prompt here"}]
  }],
  "config": {
    "responseModalities": ["TEXT", "IMAGE"],
    "imageConfig": {
      "aspectRatio": "16:9",
      "imageSize": "2K"
    }
  }
}
```

**Headers:**
```
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json
```

**Response format:** Image embedded as `data:image/png;base64,...` text in JSON. Extracted via regex `data:image/(\w+);base64,([A-Za-z0-9+/=]+)`.

**Aspect ratios:** 1:1, 9:16, 16:9, 3:4, 4:3, 3:2, 2:3, 5:4, 4:5, 21:9
**Image sizes:** 1K, 2K, 4K

### OpenAI-Style API

Standard `/v1/images/generations` endpoint. Used when `OPENAI_BASE_URL` is a standard OpenAI-compatible endpoint.

### Modified Scripts

**`shared.js` additions:**
- `isGeminiApi()` — detects if current API is Gemini-style
- `buildGeminiPayload(prompt, cfg)` — builds Gemini-format request body
- `buildGeminiUrl()` — builds Gemini endpoint URL
- `postGeminiJson(url, payload)` — POSTs to Gemini endpoint
- `extractGeneratedBytes(json)` — updated to parse both OpenAI and Gemini responses

**`generate.js` changes:**
- Auto-routes between Gemini and OpenAI API styles
- `--size` maps to Gemini `aspectRatio` values
- `--quality` maps to Gemini `imageSize` (high→2K, default→1K)

**Environment variables:**
```
OPENAI_API_KEY=your_key
OPENAI_BASE_URL=https://nn.147ai.com/v1
ENABLE_GARDEN_IMAGEGEN=1
```

---

## New Templates

### 1. knowledge-card (知识卡片)
**Path:** `references/infographics/knowledge-card.md`
**Purpose:** Upload a document/article, auto-extract key points into visual knowledge cards.
**Variants:**
- Standard: warm white bg + blue/orange accents, 4 key points
- Tech docs: dark background + cyan/green, code snippets
- WeChat style: Morandi palette, literary, WeChat-optimized

### 2. article-illustration (新媒体配图)
**Path:** `references/slides-and-visual-docs/article-illustration.md`
**Purpose:** Generate social media illustrations from text content.
**Variants:**
- WeChat cover: 16:9, bold title, simple visual
- Xiaohongshu: 3:4, lifestyle aesthetic, warm tones
- Tech blog: dark bg, code/green accents

### 3. style-transfer-poster (风格迁移海报)
**Path:** `references/poster-and-campaigns/style-transfer-poster.md`
**Purpose:** Reference one image's visual style to create new theme posters.
**Variants:**
- Brand extension: extend main visual across materials
- Style copy + theme replace: 95%+ style fidelity
- Cross-medium: apply paint style to UI, or illustration to poster

---

## Complete Template Catalog

### 01. Academic Figures (9 templates)
`references/academic-figures/`
| Template | Use Case |
|----------|---------|
| method-pipeline-overview | Paper pipeline figure (CS/CV/ML) |
| neural-network-architecture | Neural network layer diagram |
| qualitative-comparison-grid | Multi-method comparison grid |
| scientific-schematic | Experimental setup schematic |
| mechanism-diagram | Causal mechanism / pathway |
| multi-condition-comparison | Side-by-side condition results |
| publication-chart | Publication-ready data charts |
| graphical-abstract | Journal Graphical Abstract |
| research-overview-poster | Thesis defense overview |

### 02. Assets & Props (2)
`references/assets-and-props/`
| Template | Use Case |
|----------|---------|
| retro-skeuomorphic-icons | Icon sets (skeuomorphic/Y2K/pixel) |
| game-screenshot-mockup | In-game screenshot with HUD |

### 03. Avatars & Profile (5)
`references/avatars-and-profile/`
| Template | Use Case |
|----------|---------|
| style-transfer-selfie | Style transfer portrait 2x2 |
| character-grid-portrait | Same character N×N variations |
| themed-3d-icon | 3D app icon avatar |
| sticker-set | Sticker pack / emoji set |
| cultural-portrait-series | Historical dynasty portraits |

### 04. Branding & Packaging (6)
`references/branding-and-packaging/`
| Template | Use Case |
|----------|---------|
| brand-identity-board | Full brand identity system |
| mascot-brand-kit | Mascot brand kit |
| full-mascot-brand-doc | 18+ module mascot document |
| cosmetic-packaging | Skincare/cosmetic packaging |
| beverage-label-design | Drink/food label design |
| character-merch-board | IP character merchandise |

### 05. Editing Workflows (5)
`references/editing-workflows/`
| Template | Use Case |
|----------|---------|
| background-replacement | Before/after bg swap |
| local-object-replacement | Replace specific object |
| object-removal | Remove people/clutter |
| product-retouching | Product polish/retouching |
| portrait-local-edit | Portrait hair/outfit/clothes |

### 06. Grids & Collages (5)
`references/grids-and-collages/`
| Template | Use Case |
|----------|---------|
| banner-grid-2x2 | 4-banner marketing set |
| lookbook-grid | 9-grid fashion lookbook |
| mixed-style-multi-panel | Same subject, different styles |
| anime-pitch-board | Anime project pitch board |
| ad-banner-multi-grid | Cross-industry banner grid |

### 07. Infographics (7)
`references/infographics/`
| Template | Use Case |
|----------|---------|
| bento-grid-infographic | Modular widget infographic |
| comparison-infographic | A vs B comparison |
| hand-drawn-infographic | Hand-drawn/chalkboard style |
| step-by-step-infographic | Step-by-step tutorial |
| kpi-dashboard-infographic | KPI dashboard / annual review |
| legend-heavy-infographic | Bilingual high-density infographic |
| **knowledge-card** 🆕 | Document → knowledge card |

### 08. Maps (5)
`references/maps/`
| Template | Use Case |
|----------|---------|
| food-map | City food guide map |
| travel-route-map | Multi-day travel route |
| illustrated-city-map | City landmark illustration |
| store-distribution-map | Store/outlet distribution |
| itinerary-day-trip-map | One-day itinerary split view |

### 09. Portraits & Characters (5)
`references/portraits-and-characters/`
| Template | Use Case |
|----------|---------|
| professional-portrait | Corporate headshot |
| founder-portrait | Dramatic founder portrait |
| virtual-host | VTuber character card |
| character-sheet | RPG character design sheet |
| pose-reference-sheet | Action pose reference N×N |

### 10. Poster & Campaigns (9)
`references/poster-and-campaigns/`
| Template | Use Case |
|----------|---------|
| brand-poster | Main brand poster |
| campaign-kv | Campaign Key Visual |
| banner-hero | Web banner / hero |
| editorial-cover | Magazine cover |
| biomimetic-concept-poster | Biomimetic concept design |
| vintage-editorial-infographic | Vintage infographic poster |
| character-catalog-poster | Character series catalog |
| lineup-comparison-poster | Product lineup comparison |
| **style-transfer-poster** 🆕 | Style transfer poster |

### 11. Product Visuals (6)
`references/product-visuals/`
| Template | Use Case |
|----------|---------|
| exploded-view-poster | Product exploded view |
| white-background-product | E-commerce white bg |
| premium-studio-product | Studio luxury product |
| packaging-showcase | Gift box / packaging |
| lifestyle-product-scene | Product in real life |
| ecommerce-marketing-board | Chinese e-commerce board |

### 12. Scenes & Illustrations (4)
`references/scenes-and-illustrations/`
| Template | Use Case |
|----------|---------|
| healing-scene | Cozy daily life scene |
| concept-scene | Cinematic epic concept |
| picture-book-scene | Children's book illustration |
| minimalist-mood-scene | Minimalist mood/atmosphere |

### 13. Slides & Visual Docs (5)
`references/slides-and-visual-docs/`
| Template | Use Case |
|----------|---------|
| dense-explainer-slides | High-density explainer |
| policy-style-slide | Government/policy slide |
| educational-diagram-slide | Textbook style diagram |
| visual-report-page | Business executive summary |
| **article-illustration** 🆕 | Social media article illustration |

### 14. Storyboards & Sequences (8)
`references/storyboards-and-sequences/`
| Template | Use Case |
|----------|---------|
| four-panel-comic | 4-panel comic strip |
| manga-spread-page | Manga spread layout |
| anime-key-visual | Anime key visual |
| character-relationship-diagram | Character relationship map |
| recipe-process-flowchart | Recipe/cooking guide |
| product-tvc-storyboard | TV commercial storyboard |
| cinematic-storyboard-grid | Film storyboard contact sheet |
| process-photo-board | Photo process board |

### 15. Technical Diagrams (7)
`references/technical-diagrams/`
| Template | Use Case |
|----------|---------|
| system-architecture | System architecture diagram |
| flowchart-decision | Flowchart / decision tree |
| sequence-diagram | Sequence diagram |
| state-machine | State machine / lifecycle |
| er-diagram | ER diagram |
| mind-map-tech | Tech mind map |
| network-topology | Network topology |

### 16. Typography & Text Layout (2)
`references/typography-and-text-layout/`
| Template | Use Case |
|----------|---------|
| title-safe-poster | Bold typography poster |
| bilingual-layout-visual | Bilingual layout design |

### 17. UI Mockups (6)
`references/ui-mockups/`
| Template | Use Case |
|----------|---------|
| live-commerce-ui | Live streaming UI |
| social-interface-mockup | Social media post UI |
| product-card-overlay | Product card overlay |
| chat-interface-scene | Chat interface |
| short-video-cover-ui | Short video cover |
| landing-page-case-study | SaaS landing page |

---

## Scenario-Based Quick Lookup

### Academia / Education
- Method pipeline → `method-pipeline-overview`
- Neural network diagram → `neural-network-architecture`
- Experimental setup → `scientific-schematic`
- Journal Graphical Abstract → `graphical-abstract`
- Thesis defense poster → `research-overview-poster`
- Textbook diagram → `educational-diagram-slide`

### Branding / Marketing
- Brand identity system → `brand-identity-board`
- Campaign Key Visual → `campaign-kv`
- Web banner / hero → `banner-hero`
- Magazine cover → `editorial-cover`
- KPI dashboard → `kpi-dashboard-infographic`
- Style transfer → `style-transfer-poster`

### E-commerce / Products
- Product exploded view → `exploded-view-poster`
- White background product → `white-background-product`
- Premium studio shot → `premium-studio-product`
- Lifestyle scene → `lifestyle-product-scene`
- E-commerce board → `ecommerce-marketing-board`
- Background replacement → `background-replacement`

### Social Media / Content
- Article cover image → `article-illustration`
- Knowledge card → `knowledge-card`
- Hand-drawn infographic → `hand-drawn-infographic`
- Step-by-step tutorial → `step-by-step-infographic`
- Professional headshot → `professional-portrait`
- Sticker pack → `sticker-set`

### Travel / Maps
- Food map → `food-map`
- Travel route → `travel-route-map`
- City illustration → `illustrated-city-map`
- Store distribution → `store-distribution-map`
- Day trip itinerary → `itinerary-day-trip-map`

### Film / Animation / Comics
- 4-panel comic → `four-panel-comic`
- Manga spread → `manga-spread-page`
- Anime Key Visual → `anime-key-visual`
- TVC storyboard → `product-tvc-storyboard`
- Cinematic storyboard → `cinematic-storyboard-grid`
- Healing scene → `healing-scene`

### Technology / Development
- System architecture → `system-architecture`
- Flowchart / decision → `flowchart-decision`
- Sequence diagram → `sequence-diagram`
- State machine → `state-machine`
- ER diagram → `er-diagram`
- Mind map → `mind-map-tech`
- Network topology → `network-topology`

### Design / IP / Creative
- Mascot brand kit → `mascot-brand-kit`
- Character design sheet → `character-sheet`
- Pose reference → `pose-reference-sheet`
- Character grid portrait → `character-grid-portrait`
- Anime pitch board → `anime-pitch-board`
- Icon set → `retro-skeuomorphic-icons`

### Image Editing
- Background swap → `background-replacement`
- Object replacement → `local-object-replacement`
- Remove clutter → `object-removal`
- Product retouching → `product-retouching`
- Portrait edit → `portrait-local-edit`

---

## Batch Generation

To batch generate images, create a JSON array and use the Node.js script pattern:

```js
import { readFile, writeFile, mkdir } from 'node:fs/promises';

const API = 'https://nn.147ai.com/v1beta/models/gpt-image-2:generateContent';
const KEY = process.env.OPENAI_API_KEY;

const entries = [
  { cat: "category", tmpl: "template-name", prompt: "your prompt" },
  // ...
];

for (const e of entries) {
  const body = {
    contents: [{ parts: [{ text: e.prompt }] }],
    config: { responseModalities: ["TEXT", "IMAGE"], imageConfig: { aspectRatio: "16:9", imageSize: "1K" } }
  };
  // ... fetch, extract base64, save
}
```

## Quick Reference

| When user says... | Use template... |
|---|---|
| "做张知识卡片" | knowledge-card |
| "公众号配图" | article-illustration |
| "参考这个风格做一张" | style-transfer-poster |
| "画个系统架构图" | system-architecture |
| "做个产品海报" | brand-poster |
| "信息图" | bento-grid-infographic |
| "漫画" | four-panel-comic |
| "地图" | food-map / travel-route-map |
| "头像" | professional-portrait |
| "电商主图" | white-background-product |
