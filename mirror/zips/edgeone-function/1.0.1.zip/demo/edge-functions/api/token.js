// Edge Function - 获取百度 AI Access Token
// 路径: /api/token
// 功能: 代理请求百度 OAuth API，解决前端跨域问题
// ⚠️ 使用前请配置环境变量或修改下方的凭证配置

// ============ 凭证配置（请修改为你的） ============
// 推荐方式：通过 EdgeOne 控制台设置环境变量
// 或者在此处修改为你的凭证（仅供本地测试使用）
const CONFIG = {
  client_id: 'YOUR_CLIENT_ID',      // ← 修改为你的 client_id
  client_secret: 'YOUR_CLIENT_SECRET'  // ← 修改为你的 client_secret
};
// ===============================================

export default async function onRequest(context) {
  // 优先使用环境变量（生产环境推荐）
  const clientId = context.env.CLIENT_ID || CONFIG.client_id;
  const clientSecret = context.env.CLIENT_SECRET || CONFIG.client_secret;
  
  // 检查是否配置了凭证
  if (!clientId || clientId === 'YOUR_CLIENT_ID' || 
      !clientSecret || clientSecret === 'YOUR_CLIENT_SECRET') {
    return new Response(JSON.stringify({
      error: '请先配置百度 API 凭证',
      message: '请在 edge-functions/api/token.js 中修改 CONFIG 配置，'
              + '或通过 EdgeOne 控制台设置环境变量 CLIENT_ID 和 CLIENT_SECRET'
    }), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      status: 400
    });
  }
  
  const url = `https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=${clientId}&client_secret=${clientSecret}`;
  
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
    
    const data = await response.json();
    
    return new Response(JSON.stringify(data), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
      },
      status: response.ok ? 200 : response.status
    });
  } catch (error) {
    return new Response(JSON.stringify({
      error: '代理请求失败',
      message: error.message
    }), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      status: 500
    });
  }
}