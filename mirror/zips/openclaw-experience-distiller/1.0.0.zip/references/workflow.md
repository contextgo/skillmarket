# 经验提炼工作流参考

## 核心原则

1. **只留成功路径** — 失败细节不记录，只记录最终生效的方案
2. **可复用性优先** — 经验必须能在类似场景下直接套用
3. **精简到本质** — 去掉环境细节，保留决策逻辑

## 识别「遇错自愈」模式的信号

### 强信号（必须提炼）

- 尝试方案 A 失败 → 切换方案 B 成功
- 遇到错误 X → 调整参数/配置 → 问题解决
- 工具/API 不可用 → 找到替代方案 → 完成任务
- 初始理解错误 → 用户纠正 → 重新执行成功

### 弱信号（视情况提炼）

- 一次性环境问题（网络抖动、临时权限问题）
- 用户偏好调整（非技术决策）
- 纯探索性尝试（无明确失败）

## 经验记录模板

```markdown
# {主题：一句话概括}

- **日期**: YYYY-MM-DD
- **场景**: 遇到什么问题/需求
- **失败尝试**: 哪些方案不行（一句话带过）
- **成功路径**: 最终生效的步骤（详细但精简）
- **关键决策**: 为什么选这个方案
- **复用条件**: 什么情况下可以直接用

## 示例

假设遇到 akshare 网络受限，切换到 tushare 成功。
```

### 示例：数据源切换策略

```markdown
# A股数据获取：akshare 受限时切换 tushare

- **日期**: 2026-04-11
- **场景**: 需要获取 A 股历史数据，服务器在腾讯云 VPS
- **失败尝试**: akshare（东方财富 API 被拒）、yfinance（Yahoo Finance 限流）
- **成功路径**: 
  1. 注册 tushare.pro 获取 token
  2. 配置 token 到 `~/.openclaw/.env`（TUSHARE_TOKEN）
  3. 使用 `tushare.pro_api(token).daily()` 获取日线数据
- **关键决策**: tushare 是国内稳定数据源，对 VPS 友好，无需代理
- **复用条件**: 
  - 服务器在国内或访问国外金融 API 受限
  - 需要 A 股数据（美股用 yfinance）
  - 有 tushare token（免费版即可）
```

## 经验索引 Excel 字段

| 字段 | 说明 |
|------|------|
| 序号 | 自增编号 |
| 主题 | 经验标题 |
| 场景关键词 | 用于检索（如：数据获取、网络受限、API切换） |
| 文件名 | 对应的 .md 文件名 |
| 日期 | YYYY-MM-DD |
| 复用次数 | 被引用的次数（初始为 0） |
| 状态 | 活跃/已过期 |

## 提炼时机

### 自动触发（Hook）

- `session:compact:after` — 会话压缩完成后
- `command:new` / `command:reset` — 会话切换前

### 手动触发

用户说：
- 「总结经验」
- 「提炼成功经验」
- 「记录这次的解决方案」
- 「这个方法以后可以复用」

## 查询经验库

面对复杂任务时，先查询 `success/index.xlsx`：

```python
# 伪代码示例
def before_complex_task(task_description):
    keywords = extract_keywords(task_description)
    matches = search_success_index(keywords)
    if matches:
        return load_experience(matches[0])
    return None
```

实际操作：
1. 读取 `success/index.xlsx`
2. 按场景关键词匹配
3. 读取对应 .md 文件
4. 提取「成功路径」直接复用
