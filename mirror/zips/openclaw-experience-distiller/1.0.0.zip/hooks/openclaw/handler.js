/**
 * Experience Distiller Hook
 * 
 * 在会话压缩后或会话切换时，注入经验提炼提示。
 * 核心逻辑：检测「遇错→自愈→成功」模式，提炼可复用经验。
 */

const COMPACT_REMINDER = `## 🏆 经验提炼检查

会话刚完成压缩。请快速扫描压缩摘要：
1. 是否存在「遇到错误/失败 → 换方案/重试 → 最终成功」的模式？
2. 如果有，提炼成功路径写入 \`success/\` 目录（格式见 experience-distiller 技能）
3. 更新 \`success/index.xlsx\`
4. 只记录成功路径，不记录失败细节`;

const SESSION_END_REMINDER = `## 🏆 经验提炼检查

会话即将切换。如果本次会话中存在「遇错自愈」的成功经验，请在新会话启动前：
1. 提炼成功路径写入 \`success/\`
2. 更新 \`success/index.xlsx\``;

const handler = async (event) => {
  if (!event || typeof event !== 'object') return;

  // 跳过子代理会话
  const sessionKey = event.sessionKey || '';
  if (sessionKey.includes(':subagent:')) return;

  // 压缩完成事件
  if (event.type === 'session' && event.action === 'compact:after') {
    if (Array.isArray(event.messages)) {
      event.messages.push(COMPACT_REMINDER);
    }
    return;
  }

  // 会话切换事件（/new 或 /reset）
  if (event.type === 'command' && (event.action === 'new' || event.action === 'reset')) {
    if (Array.isArray(event.messages)) {
      event.messages.push(SESSION_END_REMINDER);
    }
    return;
  }
};

export default handler;
