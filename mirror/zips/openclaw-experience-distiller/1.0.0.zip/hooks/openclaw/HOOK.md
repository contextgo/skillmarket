---
name: experience-distiller
description: "会话压缩后自动分析成功经验，会话结束时检测遇错自愈模式"
metadata: {"openclaw":{"emoji":"🏆","events":["session:compact:after","command:new","command:reset"]}}
---

# Experience Distiller Hook

在会话压缩完成后或会话结束时，注入经验提炼提示，引导 AI 分析是否存在可提炼的成功经验。
