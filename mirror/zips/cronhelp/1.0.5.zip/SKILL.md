---
name: CronHelp
description: "Explain cron syntax and build schedule expressions with run previews. Use when learning cron, building schedules, debugging expressions."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["cron","scheduler","crontab","jobs","automation","time","linux","sysadmin"]
categories: ["System Tools", "Developer Tools", "Utility"]
---
# CronHelp

A comprehensive sysops toolkit for scanning, monitoring, reporting, and maintaining system operations. CronHelp provides 18+ commands for tracking system events, performing health checks, managing backups, benchmarking, and exporting operational data in multiple formats.

## Commands

| Command | Description |
|---------|-------------|
| `cronhelp scan <input>` | Record a scan entry — run without args to view recent scan entries |
| `cronhelp monitor <input>` | Record a monitoring observation — run without args to view recent entries |
| `cronhelp report <input>` | Log a report entry — run without args to view recent reports |
| `cronhelp alert <input>` | Record an alert — run without args to view recent alerts |
| `cronhelp top <input>` | Log a top-level event — run without args to view recent entries |
| `cronhelp usage <input>` | Track usage data — run without args to view recent usage entries |
| `cronhelp check <input>` | Record a check result — run without args to view recent checks |
| `cronhelp fix <input>` | Log a fix action — run without args to view recent fixes |
| `cronhelp cleanup <input>` | Record a cleanup operation — run without args to view recent cleanups |
| `cronhelp backup <input>` | Log a backup event — run without args to view recent backups |
| `cronhelp restore <input>` | Record a restore operation — run without args to view recent restores |
| `cronhelp log <input>` | Add a general log entry — run without args to view recent log entries |
| `cronhelp benchmark <input>` | Record a benchmark result — run without args to view recent benchmarks |
| `cronhelp compare <input>` | Log a comparison — run without args to view recent comparisons |
| `cronhelp stats` | Display summary statistics across all log categories |
| `cronhelp export <fmt>` | Export all data to a file (formats: `json`, `csv`, `txt`) |
| `cronhelp search <term>` | Search across all log files for a keyword |
| `cronhelp recent` | Show the 20 most recent activity entries from the history log |
| `cronhelp status` | Health check — shows version, data directory, entry count, disk usage |
| `cronhelp help` | Display available commands and usage information |
| `cronhelp version` | Print current version (v2.0.0) |

Each data command (scan, monitor, report, etc.) works in two modes:
- **With arguments**: Records the input with a timestamp into its dedicated log file
- **Without arguments**: Displays the 20 most recent entries from that category

## Data Storage

All data is stored locally in plain-text log files:

- **Location**: `~/.local/share/cronhelp/`
- **Format**: Each entry is saved as `YYYY-MM-DD HH:MM|<value>` in per-category `.log` files
- **History**: All operations are additionally logged to `history.log` with timestamps
- **Export**: The `export` command can generate JSON, CSV, or TXT files from all log data
- **No cloud sync** — everything stays on your machine

## Requirements

- Bash 4.0+ (uses `set -euo pipefail`)
- Standard Unix utilities: `date`, `wc`, `du`, `head`, `tail`, `grep`, `basename`, `cat`
- No external dependencies, no API keys, no network access required
- Works on Linux and macOS

## When to Use

1. **System monitoring** — Record and review periodic scan results, health checks, and alerts across your infrastructure
2. **Backup tracking** — Log backup and restore operations with timestamps to maintain an audit trail
3. **Performance benchmarking** — Record benchmark results over time and compare them with the `compare` command
4. **Operational reporting** — Generate reports and export collected data in JSON/CSV/TXT for dashboards or further analysis
5. **Troubleshooting** — Search across all log categories with `cronhelp search` to quickly find relevant entries when debugging issues

## Examples

```bash
# Record a system scan result
cronhelp scan "disk usage at 78% on /dev/sda1"

# Set up a monitoring entry
cronhelp monitor "nginx response time 120ms avg"

# Log an alert for review
cronhelp alert "CPU temperature exceeded 85°C on server-03"

# Record a backup operation
cronhelp backup "full backup completed for /var/lib/postgres — 2.3GB"

# Check overall statistics across all categories
cronhelp stats

# Export everything to JSON for external processing
cronhelp export json

# Search for all entries mentioning "nginx"
cronhelp search nginx

# View recent activity at a glance
cronhelp recent

# Health check — verify the tool is working and see data summary
cronhelp status
```

## Configuration

Set `DATA_DIR` by modifying the script or symlinking `~/.local/share/cronhelp/` to your preferred location.

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
