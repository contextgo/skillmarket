# WARP.md

This file provides guidance to WARP (warp.dev) and other AI coding assistants when working with code in this repository.

## What this repo is
This repository is a **Claude Code / OpenCode skill** implemented entirely as Markdown. 

**Core Mission:** It is specifically designed as the **"Chinese Academic Humanizer" (academic-humanizer-zh)**. Its purpose is to remove AI-generated artifacts from Chinese academic texts (papers, abstracts, reports) and rewrite them to meet the strict, rigorous standards of top-tier Chinese academic journals (e.g., CSSCI, SCI).

The “runtime” artifact is `SKILL.md`: Claude Code reads the YAML frontmatter (metadata + allowed tools) and the prompt/instructions that follow.

`README.md` is for human users: it contains installation, usage, and a compact overview of the 29 localized Chinese AI patterns.

## Key files (and how they relate)
- `SKILL.md`
  - The actual skill definition.
  - Starts with YAML frontmatter (`---` … `---`) containing `name`, `version`, `description`, and `allowed-tools`.
  - After the frontmatter is the editor prompt. **CRITICAL:** The prompt enforces a strict, objective, and dense academic tone. It actively discourages casual language, emotional framing, and cliché AI idioms (e.g., "众所周知", "里程碑式的意义").
- `README.md`
  - Installation and usage instructions.
  - Contains a summarized “29 patterns” table tailored specifically for Chinese LLM outputs.

When changing behavior/content, treat `SKILL.md` as the source of truth, and update `README.md` to stay consistent.

## Common commands
### Install the skill into Claude Code
Recommended (clone directly into Claude Code skills directory):
```bash
mkdir -p ~/.claude/skills
git clone [https://github.com/your-username/academic-humanizer-zh.git](https://github.com/your-username/academic-humanizer-zh.git) ~/.claude/skills/academic-humanizer-zh
