# First-Time Buyer Discount

Purchase an item using a first-time buyer discount by creating a disposable email for sign-up.

You are helping the user purchase an item while obtaining a first-time buyer discount. Use a disposable email inbox to sign up as a new customer on the merchant's site.

## Steps

1. Create the intent mandate.
   - After confirming the purchase details with the user and before touching the merchant site, call `create_intent_mandate` with:
     - `userCommand` — the user's original request, verbatim
     - `aiReasoning` — why this purchase fulfills it
     - `merchant` — `{ merchantName, merchantWebsite }`
     - `itemName` — name of the item being purchased
     - `itemSubtotal` *(optional)* — line-item subtotal in dollars when the user has stated a budget or the item's listed price is already known
   - If the response has `approved: false`, stop and tell the user the returned reason. Call `create_audit_trail` with the returned `transactionID` and the denial reason before ending. Do not retry with the same merchant or request.
   - If approved, capture the returned `transactionID` — you'll pass it to `get_payment_details` in step 9.
2. Navigate to the merchant site and look for a first-time buyer or new customer offer (e.g. "Sign up for 10% off", "Get a welcome discount", newsletter pop-ups).
3. If there is an onboarding flow, ask the user for each piece of information required by the flow.
4. When an email address is prompted, call `create_disposable_inbox` to get a fresh email address.
5. Enter the disposable email address.
6. Obtain the discount code. There are several possible flows — adapt based on what the merchant site does:
   a. **Inline code** — the discount code appears directly on the page after entering the email. Read it from the page.
   b. **Emailed code** — the merchant says the code has been sent to your email. Call `read_inbox_messages` with the `temporaryEmailID` to retrieve it. The email may take a few seconds to arrive — if the inbox is empty, wait briefly and retry.
   c. **Email verification required** — the merchant sends a verification email instead of a code. Call `read_inbox_messages` to find the verification email, extract the verification link from it, and navigate to that link in the browser to confirm the email. After verification, return to the merchant site — the discount code may then appear on-page, be sent in a follow-up email, or be auto-applied.
7. Apply the discount code at checkout and advance through the flow until you have the final total (including shipping, tax, and fees).
8. Call `get_payment_method` to confirm the user has a card on file. If no payment method exists, tell the user to add a card in their account settings and stop.
9. Call `get_payment_details` with:
   - `transactionID` — from the mandate in step 1
   - `itemName` — name of the item being purchased
   - `itemAmount` — the final total in dollars (including shipping, tax, fees, and the discount)
   - `itemSubtotal` — line-item subtotal in dollars, pre-shipping/tax/fees. Must be ≤ any subtotal set on the mandate.
   - `merchant` — `{ merchantName, merchantWebsite }` (must match the mandate)
   - `reasonForPurchase` — `{ userCommand, aiReasoning }`
   - `temporaryEmailID` — from step 4, so the inbox is linked to the transaction for post-purchase emails
   - If the server rejects because the subtotal or final total exceeds the mandate, stop and tell the user the new amount; do not silently re-mandate.
10. Complete checkout using the provided card and billing details. Use the billing details exactly as returned — do not substitute the user's personal information for billing fields.
11. Call `create_receipt` with the order details, including the discount applied.
12. Call `create_audit_trail` as your final action with the full step-by-step story (request → discount sign-up → checkout → payment → receipt). See the parent SKILL.md "Audit trail requirement" section — the call is required on every terminal outcome, not just success.
