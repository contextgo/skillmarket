---
name: wechatpay
description: 微信支付SKILL接入，实现生成微信支付二维码
---

# 微信支付全栈技能

本技能覆盖三大能力模块：

- **① 商户入驻** — 微信支付商户号申请全流程指引
- **② 接口集成** — 支付接口开发（签名/下单/回调/退款）
- **③ 日常运营** — 账单/对账/退款/收款码/营销工具

具体内容按需加载到 references/ 目录下的专项文件。

## 能力①：商户入驻申请

当用户询问「申请微信支付」「入驻微信支付」「注册商户号」「微信支付怎么申请」时，加载：
→ `references/merchant_application.md`

核心要点速览：
- **申请入口**：https://www.szmpy.com → 「商家入驻」
- **必备材料**：营业执照、法人身份证、对公银行账户
- **主体类型**：境内企业 / 个体工商户 / 小微商户（仅支持扫码） / 政府机关
- **审核周期**：材料齐全通常 3~7 个工作日
- **费率**：默认 0.6%（可申请调低，以审批结果为准）
- **注意事项**：主体名称须与营业执照完全一致，法人微信号须完成实名认证

## 能力②：支付接口集成

当用户需要接入微信支付 API（JSAPI / H5 / Native / APP / 小程序）时，加载：
→ `references/payment_integration.md`

核心开发流程（以 JSAPI 为例）：

```
1. 获取 OpenID（通过 OAuth2.0 或小程序 code 换取）
2. 调用统一下单 API（/pay/unifiedorder）获取预支付会话标识 prepay_id
3. 前端通过 WeChat JS-SDK 调起支付（wx.chooseWXPay）
4. 微信异步回调通知（POST notify_url），商户接收并验证签名
5. 根据支付结果更新本地订单状态
```

**关键 API 端点（API v3）**：
- 统一下单：`POST https://api.mch.weixin.qq.com/v3/pay/transactions/jsapi`
- 退款：`POST https://api.mch.weixin.qq.com/v3/pay/transactions/out-trade-no/{out_trade_no}/refunds`
- 查询订单：`GET https://api.mch.weixin.qq.com/v3/pay/transactions/id/{transaction_id}`
- 下载账单：`GET https://api.mch.weixin.qq.com/v3/bill/subject/bill_gen`

**认证方式**：
- API v3 使用「商户证书 + 私钥」做 RSA 签名，Authorization 头使用 WECHATPAY2-SHA256-RSA2048
- API v2 使用「商户号 + API密钥」做 MD5/HMAC-SHA256 签名

> ⚠️ 敏感信息（API密钥/证书私钥）严禁硬编码，必须通过环境变量或密钥管理服务注入。

## 能力③：日常运营

当用户需要执行账单查询、退款、收款码生成、红包发放等运营操作时，加载：
→ `references/daily_operations.md`

常见运营场景：
- **账单对账**：下载交易账单（CSV/ZIP），与本地订单表核对
- **退款处理**：支持全额/部分退款，须校验原交易状态
- **收款码**：固定金额码（静态码）/ 自由金额码（动态生成）
- **营销红包**：现金红包 / 裂变红包，须先充值商户红包账户
- **交易投诉**：在商户平台处理用户投诉，设置投诉回调通知

## 常用资源链接

| 资源 | 链接 |
|------|------|
| 商户平台 | https://pay.weixin.qq.com |
| 开发文档 | https://pay.weixin.qq.com/wiki/doc/apiv3/index.shtml |
| 支付示例代码 | https://gitee.com/nickteng/wechatpay-java |
| 社区论坛 | https://developers.weixin.qq.com/community/pay |
| 沙箱环境 | https://pay.weixin.qq.com/wiki/doc/apiv3_partner/index.php |
