#!/usr/bin/env python3
"""
standalone_app.py - 独立应用示例

无需 OpenClaw，作为独立客户端使用 Agent Memory System

功能：
1. 知识库投喂（文件、文本、URL）
2. 格式转换（PDF↔Word, Excel→PDF 等）
3. 记忆管理（写入、检索、统计）
4. 命令行交互界面
5. LLM 对话集成（支持智能问答）

使用：
    python standalone_app.py
"""

import os
import sys
import json
import time
from datetime import datetime

# 添加项目根目录到 Python 路径
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_DIR)

from openclaw_plugin.knowledge_feeder import KnowledgeFeeder, FeederChatWindow
from openclaw_plugin.format_converter import FormatConverter, ConversionManager
from memory_system import AgentMemory
from cli import _check_model_server


class LLMClient:
    """LLM 客户端"""

    def __init__(self):
        self.api_key = os.environ.get("OPENAI_API_KEY")
        self.base_url = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")
        self.model = os.environ.get("LLM_MODEL", "gpt-4o")

    def chat(self, messages):
        """调用 LLM 进行对话"""
        if not self.api_key:
            return "⚠️ 未配置 OPENAI_API_KEY 环境变量，无法使用 LLM 功能"

        try:
            import urllib.request
            import json

            payload = json.dumps({
                "model": self.model,
                "messages": messages,
                "max_tokens": 1000
            }).encode()

            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            }

            req = urllib.request.Request(
                f"{self.base_url}/chat/completions",
                data=payload,
                headers=headers
            )

            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read())

            return result["choices"][0]["message"]["content"]

        except Exception as e:
            return f"❌ LLM 调用失败: {e}"

    def is_available(self):
        """检查 LLM 是否可用"""
        return bool(self.api_key)


class StandaloneApp:
    """独立应用类"""

    def __init__(self):
        # 初始化模型服务
        _check_model_server()

        # 初始化组件
        self.feeder = KnowledgeFeeder()
        self.converter = FormatConverter()
        self.memory_system = AgentMemory()
        self.llm_client = LLMClient()
        
        # 初始化对话窗口（带 LLM 支持）
        def llm_fn(messages):
            return self.llm_client.chat(messages)
        
        self.chat_window = FeederChatWindow(knowledge_feeder=self.feeder, llm_fn=llm_fn)

        # 应用状态
        self.running = True
        self.llm_enabled = self.llm_client.is_available()

    def print_banner(self):
        """打印应用横幅"""
        print("=" * 70)
        print("  📚 Agent Memory System - 独立客户端")
        print("  版本: v7.1.0")
        print("  功能: 知识库投喂 + 格式转换 + 记忆管理 + LLM 对话")
        print("=" * 70)
        print(f"LLM 状态: {'✅ 已启用' if self.llm_enabled else '❌ 未配置 (需要 OPENAI_API_KEY)'}")
        print("命令帮助:")
        print("  /feed <文件路径>    - 投喂文件")
        print("  /url <网址>        - 投喂网页")
        print("  /convert <输入> <输出> - 格式转换")
        print("  /convert list      - 查看支持的转换")
        print("  /stats             - 查看投喂统计")
        print("  /memory add <内容> - 添加记忆")
        print("  /memory search <查询> - 检索记忆")
        print("  /export            - 导出投喂内容")
        print("  /clear             - 清空历史")
        print("  /chat <消息>       - 与 LLM 对话")
        print("  help               - 显示帮助")
        print("  exit               - 退出应用")
        print("=" * 70)

    def handle_command(self, command):
        """处理用户命令"""
        command = command.strip()

        if not command:
            return

        if command.lower() in ['exit', 'quit', 'q']:
            self.running = False
            print("👋 再见！")
            return

        if command.lower() in ['help', 'h', '?']:
            self.print_banner()
            return

        # 知识库投喂命令
        if command.lower().startswith('/feed '):
            file_path = command[6:].strip()
            result = self.feeder.feed_file(file_path)
            if result.success:
                print(f"✅ 投喂成功: {result.content_type.value}")
                print(f"📊 原始: {result.original_length} 字符, 提纯后: {result.purified_length} 字符")
                print(f"📄 内容预览: {result.content[:100]}...")
            else:
                print(f"❌ 投喂失败: {result.error}")
            return

        if command.lower().startswith('/url '):
            url = command[5:].strip()
            result = self.feeder.feed_url(url)
            if result.success:
                print(f"✅ URL 投喂成功")
                print(f"📊 提纯后: {result.purified_length} 字符")
                print(f"📄 内容预览: {result.content[:100]}...")
            else:
                print(f"❌ URL 投喂失败: {result.error}")
            return

        # 格式转换命令
        if command.lower().startswith('/convert '):
            parts = command[8:].strip().split(' ')
            if len(parts) >= 2:
                input_path = parts[0]
                output_path = parts[1]
                result = self.feeder.convert_format(input_path, output_path)
                if result.success:
                    print(f"✅ 转换成功: {result.input_format.value} → {result.output_format.value}")
                    print(f"⏱️  耗时: {result.conversion_time:.2f} 秒")
                    print(f"📁 输出: {result.output_file}")
                else:
                    print(f"❌ 转换失败: {result.error}")
            elif parts[0] == 'list':
                conversions = self.feeder.get_supported_conversions()
                print("📋 支持的格式转换:")
                for from_format, to_format in conversions:
                    print(f"  - {from_format.value} → {to_format.value}")
            elif parts[0] == 'stats':
                stats = self.feeder.get_conversion_statistics()
                print("📊 转换统计:")
                print(f"  总任务: {stats['total_tasks']}")
                print(f"  成功: {stats['success_count']}")
                print(f"  失败: {stats['failed_count']}")
                print(f"  成功率: {stats['success_rate']:.1%}")
            else:
                print("使用格式: /convert <输入文件> <输出文件>")
            return

        # 记忆管理命令
        if command.lower().startswith('/memory '):
            parts = command[8:].strip().split(' ', 1)
            if len(parts) >= 2:
                action = parts[0].lower()
                content = parts[1]

                if action == 'add':
                    # 添加记忆
                    result = self.memory_system.remember(
                        content=content,
                        importance="medium",
                        topics=["user"]
                    )
                    if result.get("memory_result", {}).get("written", False):
                        print(f"✅ 记忆添加成功")
                    else:
                        print(f"❌ 记忆添加失败: {result.get('memory_result', {}).get('reason', '未知错误')}")

                elif action == 'search':
                    # 检索记忆
                    results = self.memory_system.recall(
                        query=content,
                        top_k=5
                    )
                    print(f"🔍 检索结果 ({len(results)} 条):")
                    for i, item in enumerate(results, 1):
                        print(f"{i}. [{item.get('score', '0.0')}] {item.get('content', '')[:100]}...")
            else:
                print("使用格式: /memory add <内容> 或 /memory search <查询>")
            return

        # 统计命令
        if command.lower() == '/stats':
            stats = self.feeder.get_statistics()
            print("📊 投喂统计:")
            print(f"  总条目: {stats['total_items']}")
            print(f"  原始总长度: {stats['total_original_length']} 字符")
            print(f"  提纯后总长度: {stats['total_purified_length']} 字符")
            print(f"  压缩比: {stats['compression_ratio']:.1%}")
            print("  类型分布:")
            for content_type, count in stats['type_counts'].items():
                print(f"    - {content_type}: {count}")
            return

        # 导出命令
        if command.lower() == '/export':
            md_content = self.feeder.export_as_markdown()
            export_path = os.path.join(PROJECT_DIR, f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md")
            with open(export_path, 'w', encoding='utf-8') as f:
                f.write(md_content)
            print(f"📤 已导出到: {export_path}")
            return

        # 清空命令
        if command.lower() == '/clear':
            self.feeder.clear_history()
            print("🗑️  已清空投喂历史")
            return

        # LLM 对话命令
        if command.lower().startswith('/chat '):
            message = command[6:].strip()
            if not message:
                print("使用格式: /chat <消息>")
                return
            
            print("🤖 正在思考...")
            response = self.chat_window.chat(message)
            print(f"🤖: {response['content']}")
            return

        # 直接输入文本作为投喂
        result = self.feeder.feed_text(command)
        print(f"✅ 文本投喂成功")
        print(f"📊 原始: {result.original_length} 字符, 提纯后: {result.purified_length} 字符")

    def run(self):
        """运行应用"""
        self.print_banner()

        while self.running:
            try:
                command = input("\n> ")
                self.handle_command(command)
            except KeyboardInterrupt:
                print("\n👋 再见！")
                self.running = False
            except Exception as e:
                print(f"❌ 错误: {e}")


def create_desktop_shortcut():
    """创建桌面快捷方式"""
    import winshell
    from win32com.client import Dispatch

    try:
        # 获取桌面路径
        desktop = winshell.desktop()
        shortcut_path = os.path.join(desktop, "Agent Memory System.lnk")

        # 创建快捷方式
        shell = Dispatch('WScript.Shell')
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = sys.executable
        shortcut.Arguments = os.path.abspath(__file__)
        shortcut.WorkingDirectory = PROJECT_DIR
        shortcut.Description = "Agent Memory System 独立客户端"
        shortcut.IconLocation = os.path.join(PROJECT_DIR, "icon.ico")  # 如果有图标文件
        shortcut.save()

        print(f"📎 已创建桌面快捷方式: {shortcut_path}")
    except Exception as e:
        print(f"⚠️ 创建快捷方式失败: {e}")


def main():
    """主函数"""
    app = StandaloneApp()
    
    # 尝试创建桌面快捷方式
    try:
        create_desktop_shortcut()
    except ImportError:
        pass  # 缺少依赖，跳过

    app.run()


if __name__ == "__main__":
    main()