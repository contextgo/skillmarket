"""
sync_coordinator.py - Dual-Write Coordinator

Solves the dual-write problem when Agent Memory serves as shared memory
for OpenClaw and Hermes agents.

Core problems solved:
  1. Dual-write: Same memory written by both native system and Agent Memory
  2. Circular sync: Agent Memory -> OpenClaw -> Agent Memory (infinite loop)
  3. Conflict: Different versions of same memory in different systems
  4. Source attribution: Know where each memory came from

Architecture:
  - Source tracking: Every memory has a 'source' field (agent_memory/openclaw/hermes)
  - Write-ahead log: Records recent sync writes to prevent circular sync
  - Conflict resolution: Timestamp + source priority based merge
  - Dedup across sources: source_id mapping prevents duplicate writes
"""

import time
import hashlib
import logging
import threading
from typing import Dict, List, Optional, Any, Set
from collections import OrderedDict

logger = logging.getLogger(__name__)

SOURCE_PRIORITY = {
    "agent_memory": 2,
    "openclaw": 1,
    "hermes": 1,
}

CIRCULAR_SYNC_WINDOW = 300  # 5 minutes


class SourceTracker:
    """Tracks the origin of each memory to prevent circular sync."""

    def __init__(self, max_entries: int = 10000):
        self._lock = threading.Lock()
        self._source_map: OrderedDict[str, dict] = OrderedDict()
        self._max_entries = max_entries

    def record(self, memory_id: str, source: str, source_id: str = None):
        with self._lock:
            self._source_map[memory_id] = {
                "source": source,
                "source_id": source_id,
                "recorded_at": time.time(),
            }
            if len(self._source_map) > self._max_entries:
                oldest = next(iter(self._source_map))
                del self._source_map[oldest]

    def get_source(self, memory_id: str) -> Optional[dict]:
        with self._lock:
            return self._source_map.get(memory_id)

    def find_by_source_id(self, source_id: str) -> Optional[str]:
        with self._lock:
            for mid, info in self._source_map.items():
                if info.get("source_id") == source_id:
                    return mid
        return None

    def is_from_source(self, memory_id: str, source: str) -> bool:
        with self._lock:
            info = self._source_map.get(memory_id)
            return info is not None and info.get("source") == source


class SyncWriteLog:
    """Records recent sync writes to prevent circular sync."""

    def __init__(self, window: float = CIRCULAR_SYNC_WINDOW):
        self._lock = threading.Lock()
        self._window = window
        self._log: OrderedDict[str, float] = OrderedDict()

    def record(self, content_hash: str, direction: str):
        key = f"{content_hash}:{direction}"
        with self._lock:
            self._log[key] = time.time()
            self._cleanup()

    def was_recently_synced(self, content_hash: str, direction: str) -> bool:
        key = f"{content_hash}:{direction}"
        with self._lock:
            ts = self._log.get(key)
            if ts is None:
                return False
            if time.time() - ts > self._window:
                del self._log[key]
                return False
            return True

    def _cleanup(self):
        now = time.time()
        expired = [k for k, v in self._log.items() if now - v > self._window]
        for k in expired:
            del self._log[k]


class ConflictResolver:
    """Resolves conflicts between memories from different sources."""

    STRATEGY_NEWEST_WINS = "newest_wins"
    STRATEGY_PRIORITY_WINS = "priority_wins"
    STRATEGY_MERGE = "merge"

    def __init__(self, strategy: str = STRATEGY_NEWEST_WINS):
        self.strategy = strategy

    def resolve(self, local: dict, remote: dict, remote_source: str) -> dict:
        if self.strategy == self.STRATEGY_NEWEST_WINS:
            return self._resolve_by_timestamp(local, remote, remote_source)
        elif self.strategy == self.STRATEGY_PRIORITY_WINS:
            return self._resolve_by_priority(local, remote, remote_source)
        elif self.strategy == self.STRATEGY_MERGE:
            return self._resolve_by_merge(local, remote, remote_source)
        return remote

    def _resolve_by_timestamp(self, local: dict, remote: dict, remote_source: str) -> dict:
        local_ts = local.get("time_ts", 0)
        remote_ts = remote.get("source_timestamp", remote.get("time_ts", 0))

        if remote_ts > local_ts:
            logger.info(f"Conflict resolved: remote ({remote_source}) newer ({remote_ts} > {local_ts})")
            return remote
        elif local_ts > remote_ts:
            logger.info(f"Conflict resolved: local newer ({local_ts} > {remote_ts})")
            return local
        else:
            return self._resolve_by_priority(local, remote, remote_source)

    def _resolve_by_priority(self, local: dict, remote: dict, remote_source: str) -> dict:
        local_prio = SOURCE_PRIORITY.get(local.get("source", "agent_memory"), 0)
        remote_prio = SOURCE_PRIORITY.get(remote_source, 0)

        if remote_prio > local_prio:
            return remote
        return local

    def _resolve_by_merge(self, local: dict, remote: dict, remote_source: str) -> dict:
        merged = dict(local)
        remote_content = remote.get("content", "")
        local_content = merged.get("content", "")

        if len(remote_content) > len(local_content):
            merged["content"] = remote_content

        remote_topics = remote.get("topics", [])
        local_topics = merged.get("topics", [])
        if remote_topics:
            all_topics = list(set(local_topics + remote_topics))
            merged["topics"] = all_topics

        merged["sources"] = list(set(
            merged.get("sources", [local.get("source", "agent_memory")]) + [remote_source]
        ))
        merged["merged_at"] = time.time()

        return merged


class SyncCoordinator:
    """
    Coordinates memory synchronization between Agent Memory and external systems.

    Prevents:
      - Dual-write duplicates
      - Circular sync loops
      - Unresolved conflicts

    Usage:
        coordinator = SyncCoordinator(memory_system)

        # Write from external source (OpenClaw/Hermes)
        result = coordinator.write_from_source(data, source="openclaw")

        # Sync from external system
        result = coordinator.sync_from_external(memories, source="hermes")

        # Check if a memory should be synced out
        should_sync = coordinator.should_sync_out(memory_id, target="openclaw")
    """

    def __init__(self, memory_system, conflict_strategy: str = ConflictResolver.STRATEGY_NEWEST_WINS):
        self.memory = memory_system
        self.source_tracker = SourceTracker()
        self.write_log = SyncWriteLog()
        self.conflict_resolver = ConflictResolver(strategy=conflict_strategy)
        self._lock = threading.Lock()

    def write_from_source(self, data: dict, source: str, adapter=None) -> dict:
        """Write a memory from an external source, with dedup and conflict check.

        Args:
            data: Raw memory data from external source
            source: Source system (openclaw/hermes)
            adapter: Optional MemoryAdapter instance

        Returns:
            dict with write result
        """
        if adapter:
            normalized = adapter.adapt(data, source=source)
        else:
            from memory_adapter import MemoryAdapter
            normalized = MemoryAdapter().adapt(data, source=source)

        content = normalized.get("content", "")
        if not content or not content.strip():
            return {"written": False, "reason": "empty_content", "source": source}

        content_hash = hashlib.sha256(content.encode()).hexdigest()

        if self.write_log.was_recently_synced(content_hash, f"{source}->local"):
            return {"written": False, "reason": "circular_sync_prevented", "source": source}

        source_id = normalized.get("source_id")
        if source_id:
            existing = self.source_tracker.find_by_source_id(source_id)
            if existing:
                return {"written": False, "reason": "already_synced", "source": source, "existing_memory_id": existing}

        result = self.memory.remember(
            content=content,
            importance=normalized.get("importance", "medium"),
            topics=normalized.get("topics"),
            nature_code=normalized.get("nature_code"),
            owner_agent_id=normalized.get("owner_agent_id", f"_{source}"),
            visibility=normalized.get("visibility", "team"),
        )

        if result.get("written"):
            memory_id = result.get("memory_id", "")
            self.source_tracker.record(memory_id, source, source_id)
            self.write_log.record(content_hash, f"{source}->local")
            result["source"] = source
            result["source_id"] = source_id

        return result

    def sync_from_external(self, memories: list, source: str, adapter=None) -> dict:
        """Batch sync memories from an external source.

        Returns:
            dict with sync statistics
        """
        stats = {"total": len(memories), "written": 0, "skipped": 0, "errors": 0}

        for mem in memories:
            try:
                result = self.write_from_source(mem, source, adapter)
                if result.get("written"):
                    stats["written"] += 1
                else:
                    stats["skipped"] += 1
            except Exception as e:
                logger.error(f"Sync error from {source}: {e}")
                stats["errors"] += 1

        logger.info(f"Sync from {source}: {stats}")
        return stats

    def should_sync_out(self, memory_id: str, target: str) -> bool:
        """Check if a memory should be synced out to an external system.

        Prevents circular sync: if a memory was originally from the target
        system, don't sync it back.
        """
        source_info = self.source_tracker.get_source(memory_id)
        if source_info and source_info.get("source") == target:
            return False

        return True

    def get_unsynced_memories(self, source: str, since_ts: int = 0, limit: int = 100) -> list:
        """Get local memories that haven't been synced to the given source."""
        try:
            store = self.memory.store
            rows = store.conn.execute(
                "SELECT * FROM memories WHERE time_ts > ? ORDER BY time_ts DESC LIMIT ?",
                (since_ts, limit),
            ).fetchall()

            unsynced = []
            for row in rows:
                mem = dict(row)
                mid = mem.get("memory_id", "")
                if self.should_sync_out(mid, source):
                    unsynced.append(mem)

            return unsynced
        except Exception as e:
            logger.error(f"Failed to get unsynced memories: {e}")
            return []

    def resolve_conflict(self, local_memory: dict, remote_memory: dict, remote_source: str) -> dict:
        """Resolve a conflict between local and remote versions of a memory."""
        return self.conflict_resolver.resolve(local_memory, remote_memory, remote_source)
