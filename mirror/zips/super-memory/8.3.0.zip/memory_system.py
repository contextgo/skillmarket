"""
memory_system.py - Agent Memory System 统一入口
一行初始化，一行调用
"""

import os
import logging
import time

from cache_manager import get_cache_manager

logger = logging.getLogger(__name__)


class AgentMemory:
    """
    Agent Memory System v4 — 统一 API

    用法:
        memory = AgentMemory(db_path="memory.db")

        # 写入（自动过滤 + 去重 + 编码 + 存储）
        memory.remember("用户偏好用 Chroma 做向量库")

        # 检索（结构化 + 语义混合）
        results = memory.recall("用户的向量库偏好")

        # 组装上下文（直接拼入 Agent prompt）
        prompt = memory.build_context(query="用户的问题")

        # 反馈（优化质量评分）
        memory.feedback(memory_id, useful=True)
    """

    # 输入长度限制
    MAX_CONTENT_LENGTH = 50_000       # 单条记忆最大 50K 字符（约 25K 汉字）
    MAX_CONTENT_WARN = 10_000         # 超过此长度警告（但不拒绝）

    def __init__(
        self,
        db_path: str = None,
        project_dir: str = None,
        llm_fn=None,
        vision_fn=None,
        audio_fn=None,
        enable_semantic: bool = True,
        enable_filter: bool = True,
        enable_dedup: bool = True,
        agent_id: str = None,
        team_id: str = "default",
    ):
        """
        参数:
            db_path: SQLite 数据库路径
            project_dir: 项目根目录（存放 registry、daily_index 等）
            llm_fn: LLM 函数（用于主题拆分 + 记忆压缩）
            vision_fn: 视觉模型函数 fn(bytes, mime, prompt) -> str（用于图片/视频理解）
            audio_fn: 语音模型函数 fn(bytes, mime) -> str（用于音频转写）
            enable_semantic: 启用语义搜索
            enable_filter: 启用记忆过滤
            enable_dedup: 启用去重
            agent_id: Agent ID（设置后启用多 Agent 模式，写入自动标注来源）
            team_id: 团队 ID（同一 team 的 Agent 共享 team 级记忆）
        """
        from encoder import DimensionEncoder
        from store import MemoryStore
        from pipeline import IngestPipeline
        from recall import RecallEngine
        from topic_registry import TopicRegistry
        from archiver import Archiver
        from decay import MemoryDecay
        from context_builder import ContextBuilder
        from memory_filter import MemoryFilter
        from dedup import MemoryDeduplicator
        from quality import MemoryQuality
        from causal import CausalChain
        from compressor import MemoryCompressor
        from hierarchical import HierarchicalMemory
        from self_healing import SelfHealing
        from memory_graph import MemoryGraph
        from content_cleaner import ContentCleaner
        from session_context import SessionContext
        from media_processor import MediaProcessor
        from agent_network import AgentMemoryNetwork, AgentIdentity
        from reactor import MemoryReactor
        from distill import MemoryDistiller
        from timeline import MemoryTimeline
        from memory_pack import MemoryPackManager

        self._project_dir = project_dir or os.path.dirname(__file__)

        # 核心组件
        self.encoder = DimensionEncoder(registry_path=os.path.join(self._project_dir, "dimensions.json"))
        self.store = MemoryStore(db_path)
        
        # 缓存管理器
        self.cache = get_cache_manager()

        # Schema 版本检查 + 自动迁移
        self._check_schema_version()

        self.topic_registry = TopicRegistry(os.path.join(self._project_dir, "dimensions.json"))

        # 向量存储（可选）
        self.embedding_store = None
        if enable_semantic:
            try:
                from embedding_store import EmbeddingStore
                # Fix (Issue 1): 注入 store 的连接，实现单事务原子性
                # Fix (Issue 9 - P0): 使用 conn_provider 动态返回当前线程连接
                self.embedding_store = EmbeddingStore(
                    db_path=db_path,
                    conn_provider=lambda: self.store.conn,
                )
                # Fix (Issue 3): 注册 embedding_store 引用到 store，用于容量清理时同步删向量
                self.store._embedding_store_ref = self.embedding_store
                logger.info("✅ 向量库已加载（sqlite-vec，共享连接模式）")
            except Exception as e:
                logger.warning(f"⚠️ 向量库不可用: {e}")

        # 语义主题匹配（可选）
        self.semantic_matcher = None
        if enable_semantic and self.embedding_store:
            try:
                from semantic_topic import SemanticTopicMatcher
                self.semantic_matcher = SemanticTopicMatcher(
                    embedding_store=self.embedding_store,
                    registry_path=os.path.join(self._project_dir, "dimensions.json"),
                )
            except Exception as e:
                logger.warning(f"⚠️ 语义主题匹配不可用: {e}")

        # 管道（v7.1: 直接注入 llm_fn，含 EmotionAnalyzer）
        index_dir = os.path.join(self._project_dir, "daily_index")
        self.pipeline = IngestPipeline(
            self.store, self.encoder,
            index_dir=index_dir,
            embedding_store=self.embedding_store,
            topic_registry=self.topic_registry,
            semantic_matcher=self.semantic_matcher,
            llm_fn=llm_fn,
        )

        # 增强组件（quality 必须在 recall_engine 之前初始化）
        self.filter = MemoryFilter(llm_fn=llm_fn) if enable_filter else None
        self.dedup = MemoryDeduplicator(self.store, self.embedding_store) if enable_dedup else None
        # 质量评分
        self.quality = MemoryQuality(self.store, os.path.join(self._project_dir, "quality_stats.json"))

        # Reranker（可选，加载失败自动降级）
        self.reranker = None
        if enable_semantic:
            try:
                from reranker import Reranker
                self.reranker = Reranker(use_reranker=True)
                if self.reranker.is_available:
                    logger.info(f"✅ Reranker 已加载: {self.reranker.model_type}")
                else:
                    logger.info(f"⚠️ Reranker 降级: {self.reranker.model_type}")
            except Exception as e:
                logger.warning(f"⚠️ Reranker 不可用: {e}")

        # 多模态处理器（可选）
        self.media_processor = None
        if vision_fn or audio_fn:
            self.media_processor = MediaProcessor(
                vision_fn=vision_fn,
                audio_fn=audio_fn,
            )
            logger.info(f"✅ 多模态处理器已加载: {self.media_processor.get_stats()}")
        else:
            # 自动检测可用的多模态后端
            try:
                self.media_processor = MediaProcessor.auto()
                if self.media_processor.is_available:
                    logger.info(f"✅ 多模态自动检测: {self.media_processor.get_stats()}")
            except Exception as e:
                logger.debug(f"多模态自动检测失败: {e}")

        self.causal = CausalChain(self.store, llm_fn=llm_fn)
        self.compressor = MemoryCompressor(self.store, self.encoder, llm_fn=llm_fn)
        self.decay = MemoryDecay(self.store, self.encoder, embedding_store=self.embedding_store)
        self.hierarchy = HierarchicalMemory(self.store, self.quality)
        self.self_healing = SelfHealing(self.store, self.embedding_store)
        self.graph = MemoryGraph(self.store, self.topic_registry)

        # 时间旅行（快照 / 差异 / 追溯）
        self.timeline = MemoryTimeline(self.store, llm_fn=llm_fn)

        # Phase 2-5: 意识进化模块（懒加载，首次访问时初始化）
        self._self_model = None
        self._metacognition = None
        self._motivation = None
        self._narrative = None
        self._digital_twin = None
        self._role_manager = None
        self._style_analyzer = None
        self._emotion_tracker = None
        self._llm_fn = llm_fn

        # 主动反应器（记忆驱动的 Agent 行为）
        self.reactor = MemoryReactor()
        self.reactor.register_default_hooks()

        # 检索（传入 quality 系统、reranker 和 self_model）
        self.recall_engine = RecallEngine(self.store, self.encoder, self.embedding_store, quality=self.quality, reranker=self.reranker, self_model=None)

        # 归档
        self.archiver = Archiver(self.pipeline, self.store, self.encoder)

        # 蒸馏器（智能归档之后的下一层：对话碎片 → 知识库）
        self.distiller = MemoryDistiller(
            store=self.store,
            encoder=self.encoder,
            llm_fn=llm_fn,
            embedding_store=self.embedding_store,
        )

        # 记忆包管理器（剥离/灌输/交易）
        self.pack_manager = MemoryPackManager(
            store=self.store,
            encoder=self.encoder,
            pack_dir=os.path.join(self._project_dir, "packs"),
        )

        # 上下文组装器
        self.session_context = SessionContext()
        self.context_builder = ContextBuilder(self.recall_engine, session_context=self.session_context)

        # 启用的标志
        self._enable_filter = enable_filter
        self._enable_dedup = enable_dedup

        # 内容清洗器
        self.cleaner = ContentCleaner()

        # 多 Agent 网络（可选）
        self.agent_id = agent_id
        self.team_id = team_id
        self.agent_network = None
        if agent_id:
            self.agent_network = AgentMemoryNetwork(self.store)
            self.agent_network.register(AgentIdentity(
                agent_id=agent_id,
                agent_name=agent_id,
                team_id=team_id,
            ))
            logger.info(f"✅ 多 Agent 模式: agent={agent_id}, team={team_id}")

        # 启动时能力报告
        self._report_capabilities()

    @property
    def self_model(self):
        if self._self_model is None:
            from self_model import SelfModel
            self._self_model = SelfModel(store=self.store)
            self.recall_engine.self_model = self._self_model
        return self._self_model

    @property
    def metacognition(self):
        if self._metacognition is None:
            from metacognition import MetacognitiveEngine
            self._metacognition = MetacognitiveEngine(
                store=self.store,
                recall_engine=self.recall_engine,
                self_model=self.self_model,
                memory_system=self,
                llm_fn=self._llm_fn,
            )
        return self._metacognition

    @property
    def motivation(self):
        if self._motivation is None:
            from motivation import MotivationEngine
            self._motivation = MotivationEngine(
                store=self.store,
                topic_registry=self.topic_registry,
                llm_fn=self._llm_fn,
            )
            self._motivation.load_state()
        return self._motivation

    @property
    def narrative(self):
        if self._narrative is None:
            from narrative import NarrativeBuilder
            self._narrative = NarrativeBuilder(
                store=self.store,
                motivation=self.motivation,
                llm_fn=self._llm_fn,
                causal=self.causal,
            )
        return self._narrative

    @property
    def digital_twin(self):
        if self._digital_twin is None:
            from digital_twin import DigitalTwinProfiler
            self._digital_twin = DigitalTwinProfiler(
                store=self.store,
                emotion_analyzer=self.pipeline.emotion_analyzer,
                self_model=self.self_model,
                motivation_engine=self.motivation,
                narrative_builder=self.narrative,
                quality_evaluator=self.quality,
            )
            logger.info("✅ 数字孪生模块已加载（懒加载）")
        return self._digital_twin

    @property
    def role_manager(self):
        if self._role_manager is None:
            try:
                from role_template import RoleManager
                self._role_manager = RoleManager()
            except Exception as e:
                logger.warning(f"⚠️ RoleManager 加载失败: {e}")
        return self._role_manager

    @property
    def style_analyzer(self):
        if self._style_analyzer is None:
            try:
                from style_analyzer import StyleAnalyzer
                self._style_analyzer = StyleAnalyzer()
            except Exception as e:
                logger.warning(f"⚠️ StyleAnalyzer 加载失败: {e}")
        return self._style_analyzer

    @property
    def emotion_tracker(self):
        if self._emotion_tracker is None:
            try:
                from emotion_tracker import EmotionTracker
                self._emotion_tracker = EmotionTracker()
            except Exception as e:
                logger.warning(f"⚠️ EmotionTracker 加载失败: {e}")
        return self._emotion_tracker

    def _report_capabilities(self):
        """启动时打印能力矩阵，明确标注当前可用/降级/不可用的能力"""
        caps = self.check_capabilities()
        available = [k for k, v in caps.items() if v["status"] == "ok"]
        degraded = [k for k, v in caps.items() if v["status"] == "degraded"]
        unavailable = [k for k, v in caps.items() if v["status"] == "unavailable"]

        if available:
            logger.info(f"✅ 可用: {', '.join(available)}")
        if degraded:
            logger.warning(f"⚠️ 降级: {', '.join(degraded)} — {caps[degraded[0]]['detail'] if degraded else ''}")
        if unavailable:
            logger.info(f"ℹ️ 不可用: {', '.join(unavailable)} — {caps[unavailable[0]]['detail'] if unavailable else ''}")

    def check_capabilities(self) -> dict:
        """
        检查当前环境下的能力可用性。

        返回: {capability_name: {"status": "ok"|"degraded"|"unavailable", "detail": str}}
        """
        caps = {}

        # SQLite + FTS5
        try:
            has_fts = self.store._has_fts if hasattr(self.store, '_has_fts') else False
            caps["sqlite_fts5"] = {
                "status": "ok" if has_fts else "degraded",
                "detail": "FTS5 trigram 全文搜索" if has_fts else "FTS5 不可用，降级为 LIKE 搜索",
            }
        except Exception:
            caps["sqlite_fts5"] = {"status": "degraded", "detail": "FTS5 状态未知"}

        # 语义向量搜索
        if self.embedding_store:
            try:
                backend = self.embedding_store._backend
                use_model = self.embedding_store._use_model
                if use_model:
                    caps["semantic_search"] = {
                        "status": "ok",
                        "detail": f"sqlite-vec + {self.embedding_store._model_name} ({backend})",
                    }
                elif backend == "hash":
                    caps["semantic_search"] = {
                        "status": "degraded",
                        "detail": "SimHash 降级模式，语义精度极低",
                    }
                else:
                    caps["semantic_search"] = {
                        "status": "degraded",
                        "detail": f"{backend} 后端初始化失败，将尝试加载",
                    }
            except Exception:
                caps["semantic_search"] = {"status": "degraded", "detail": "EmbeddingStore 状态异常"}
        else:
            caps["semantic_search"] = {
                "status": "unavailable",
                "detail": "sqlite-vec/sentence-transformers 未安装",
            }

        # Reranker
        if self.reranker and self.reranker.is_available:
            caps["reranker"] = {
                "status": "ok",
                "detail": f"交叉编码器重排序 ({self.reranker.model_type})",
            }
        elif self.reranker:
            caps["reranker"] = {
                "status": "degraded",
                "detail": f"FlagEmbedding 未安装，降级为分数排序",
            }
        else:
            caps["reranker"] = {"status": "unavailable", "detail": "未启用"}

        # 蒸馏（LLM 可用性）
        if self.distiller and self.distiller.llm_fn:
            caps["distillation_llm"] = {
                "status": "ok",
                "detail": "LLM 辅助蒸馏（主题摘要 + 实体提取 + 百科生成）",
            }
        else:
            caps["distillation_llm"] = {
                "status": "degraded",
                "detail": "无 LLM，蒸馏使用启发式降级（关键词提取 + 分类拼接）",
            }

        # 因果链
        caps["causal_chain"] = {
            "status": "ok",
            "detail": "启发式 + 时间线 + 链式传递 + 主题相似（4层检测）",
        }

        # 多模态（CLIP）
        try:
            if self.embedding_store:
                self.embedding_store._ensure_clip()
                if self.embedding_store._clip_model:
                    caps["multimodal_clip"] = {
                        "status": "ok",
                        "detail": "CLIP 图片 embedding（跨模态检索）",
                    }
                else:
                    caps["multimodal_clip"] = {
                        "status": "unavailable",
                        "detail": "transformers/torch 未安装",
                    }
            else:
                caps["multimodal_clip"] = {"status": "unavailable", "detail": "需要 embedding_store"}
        except Exception:
            caps["multimodal_clip"] = {"status": "unavailable", "detail": "CLIP 加载失败"}

        # 多 Agent
        caps["multi_agent"] = {
            "status": "ok" if self.agent_network else "unavailable",
            "detail": f"agent={self.agent_id}, team={self.team_id}" if self.agent_network else "未设置 agent_id",
        }

        # 时间旅行
        caps["time_travel"] = {"status": "ok", "detail": "快照 / 差异对比 / 来源追溯"}

        # 自我指涉
        caps["self_reference"] = {
            "status": "ok" if self.self_model else "unavailable",
            "detail": "推理追踪 / 置信度历史 / 自我反思",
        }

        # 元认知
        caps["metacognition"] = {
            "status": "ok" if self.metacognition else "unavailable",
            "detail": "检索评估 / 反思修正 / 多轮反思检索",
        }

        # 内在动机
        caps["motivation"] = {
            "status": "ok" if self.motivation else "unavailable",
            "detail": "好奇心 / 无聊度 / 知识空白 / 探索任务",
        }

        # 叙事自我
        caps["narrative"] = {
            "status": "ok" if self.narrative else "unavailable",
            "detail": "身份画像 / 时间线叙事 / 主题叙事 / WhoAmI",
        }

        # 主动反应器
        caps["reactor"] = {"status": "ok", "detail": "记忆驱动的 Agent 行为（提醒/矛盾/衰减）"}

        return caps

    def remember(
        self,
        content: str,
        importance: str = None,
        topics: list[str] = None,
        nature: str = None,
        force: bool = False,
        auto_write: bool = True,
    ) -> dict:
        """
        写入一条记忆。

        自动执行：过滤 → 清洗 → 去重 → 编码 → 存储 → 向量索引

        参数:
            content: 记忆内容
            importance: 重要度（None 则自动评估）
            topics: 主题列表（None 则自动检测）
            nature: 性质（None 则自动检测）
            force: 跳过过滤强制写入
            auto_write: 是否直接写入（False 则返回待审核状态，需再次调用 auto_write=True 确认）

        返回: {"written": bool, "memory_id": str, "reason": str}
        """
        # 0. 输入长度校验
        if not content or not content.strip():
            return {"written": False, "memory_id": None, "reason": "内容为空"}

        content_len = len(content)
        if content_len > self.MAX_CONTENT_LENGTH:
            return {
                "written": False,
                "memory_id": None,
                "reason": f"内容过长: {content_len} 字符（上限 {self.MAX_CONTENT_LENGTH}）",
            }
        if content_len > self.MAX_CONTENT_WARN:
            import logging
            logging.getLogger(__name__).warning(
                f"记忆内容较长: {content_len} 字符，建议拆分"
            )

        # 0.5 自动写入审核门：当 auto_write=False 时，不立即写入，返回待审核状态
        if not auto_write:
            preview = content[:200] + ("..." if len(content) > 200 else "")
            return {
                "written": False,
                "memory_id": None,
                "reason": "pending_review",
                "preview": preview,
                "content_length": content_len,
                "message": "记忆待人工审核。设置 auto_write=True 可跳过审核直接写入（仅限受信任环境）。",
            }

        # 1. 过滤
        if not force and self._enable_filter and self.filter:
            filter_result = self.filter.should_remember(content)
            if not filter_result["remember"]:
                return {
                    "written": False,
                    "memory_id": None,
                    "reason": f"过滤: {filter_result['reason']}",
                }
            if importance is None:
                importance = filter_result["suggested_importance"]
            if nature is None:
                nature = filter_result["suggested_nature"]

        # 1.5 清洗内容（删除废话、修复语病、保留核心）
        if self.cleaner:
            content = self.cleaner.clean(content, importance=importance or "medium")
            if not content or not content.strip():
                return {
                    "written": False,
                    "memory_id": None,
                    "reason": "清洗后内容为空",
                }

        # 2. 去重
        if self._enable_dedup and self.dedup:
            dup_result = self.dedup.check_duplicate(content)
            if dup_result["is_duplicate"]:
                action = dup_result["action"]
                if action == "skip":
                    return {
                        "written": False,
                        "memory_id": dup_result["duplicate_of"],
                        "reason": f"重复: {dup_result['method']} (sim={dup_result['similarity']:.2f})",
                    }
                elif action == "link":
                    # 写入但建立关联
                    pass

        # 2.5 冲突检测（相似但不重复的内容）
        conflict_result = None
        if self._enable_dedup and self.dedup:
            conflict_result = self.dedup.check_conflict(content)

        # 3. 写入
        result = self.pipeline.ingest(
            content=content,
            importance=importance or "medium",
            topics=topics,
            nature_code=nature,
            owner_agent_id=self.agent_id or "_system",
            visibility="team" if self.agent_id else "team",
        )

        # 4. 建立去重关联（确保 result 有 memory_id）
        if (self._enable_dedup and self.dedup
                and dup_result.get("is_duplicate")
                and dup_result.get("action") == "link"
                and result.get("memory_id")
                and dup_result.get("duplicate_of")):
            self.store.insert_link(
                source_id=result["memory_id"],
                target_id=dup_result["duplicate_of"],
                link_type="similar_to",
                weight=dup_result["similarity"],
                reason="近似重复",
            )

        # 5. v5.3: 完整因果检测（启发式 + 时间线 + 链式 + 主题相似）
        try:
            self.causal.full_causal_analysis(
                window_hours=6,
                embedding_store=self.embedding_store,
            )
        except Exception as e:
            logger.warning(f"因果检测失败（记忆已写入）: {e}")

        # 6. 主动反应器（时间解析 → 自动设提醒等）
        reactor_results = []
        try:
            memory_for_reactor = {
                "memory_id": result["memory_id"],
                "content": content,
                "importance": importance or "medium",
                "topics": result.get("topics", []),
            }
            reactor_results = self.reactor.fire_write(memory_for_reactor, self.store)
        except Exception as e:
            logger.warning(f"Reactor 触发失败（记忆已写入）: {e}")

        ret = {
            "written": True,
            "memory_id": result["memory_id"],
            "reason": "ok",
            "topics": result.get("topics", []),
            "nature": result.get("nature_id", ""),
            "importance": importance or "medium",
            "conflict": conflict_result,  # 可能的冲突记忆
            "reactor_actions": [r.message for r in reactor_results if r.success],
            "emotion": result.get("emotion", {}),
        }

        # v8.2: 记录情感轨迹
        try:
            emotion_data = result.get("emotion", {})
            if emotion_data:
                self.emotion_tracker.record(emotion_data, agent_id=owner_agent_id)
        except Exception:
            pass

        # 更新内在状态（Phase 4）
        try:
            memory_for_state = {
                "content": content,
                "importance": importance or "medium",
                "topics": result.get("topics", []),
                "significance": result.get("emotion", {}).get("significance", "notable"),
            }
            state, _trace = self.motivation.update_state([memory_for_state])
        except Exception:
            pass

        return ret

    def purge_cascade(self, memory_id: str) -> dict:
        """
        级联清除：删除指定记忆及其所有蒸馏派生内容。

        当一条记忆被删除或标记为不可信时，应调用此方法防止级联污染。
        同时清除：主题摘要、知识实体、关系、百科条目。

        参数:
            memory_id: 要清除的原始记忆 ID

        返回: {"purged": bool, "deleted": {table: count}, "memory_id": str}
        """
        result = self.distiller.purge_by_source(memory_id)
        result["memory_id"] = memory_id
        return result

    def purge_cascade_batch(self, memory_ids: list[str]) -> dict:
        """
        批量级联清除。

        参数:
            memory_ids: 要清除的原始记忆 ID 列表

        返回: {"purged": bool, "deleted": {table: count}, "count": int}
        """
        return self.distiller.purge_by_sources(memory_ids)

    def recall(
        self,
        query: str = None,
        topic: str = None,
        importance: str = None,
        significance: str = None,
        limit: int = 10,
        query_agent_id: str = None,
    ) -> dict:
        """
        检索记忆。

        自动执行：结构化 + 语义混合检索 → 质量评分排序

        参数:
            query: 自然语言查询
            topic: 主题过滤
            importance: 重要度过滤
            significance: 情感显著性过滤 (trivial/notable/important/breakthrough/crisis/milestone)
            limit: 返回条数
            query_agent_id: 查询者 Agent ID（启用权限过滤）
        """
        # 生成缓存键
        cache_key = f"recall:{query}:{topic}:{importance}:{significance}:{limit}:{query_agent_id}"
        
        # 检查缓存
        cached_result = self.cache.get(cache_key)
        if cached_result:
            return cached_result
        
        # 执行原始检索
        result = self.recall_engine.recall(
            query=query,
            topic_path=topic,
            importance=importance,
            significance=significance,
            limit=limit,
            query_agent_id=query_agent_id or self.agent_id,
            team_id=self.team_id,
        )

        # 质量评分排序（混合相关性 + 质量分）
        if result.get("primary"):
            result["primary"] = self.quality.rank_by_quality(result["primary"])

            # 只记录 top 3 检索事件（真正被"看到"的记忆）
            for mem in result["primary"][:3]:
                self.quality.record_retrieval(mem.get("memory_id", ""))
        
        # 缓存结果
        self.cache.set(cache_key, result, ttl=3600)

        return result

    def meta_recall(
        self,
        query: str = None,
        limit: int = 10,
        max_rounds: int = 2,
    ) -> dict:
        """
        带反思的检索：不确定 → 反思 → 修正查询 → 重新检索。

        与普通 recall() 的区别：
        - 会自动评估结果质量
        - 置信度低时会反思并修正查询
        - 最多重试 2 轮，不会无限循环
        - 反思结果自动写入记忆系统

        返回: {
            "results": [memory dicts],
            "reflections": [反思列表],
            "rounds": int,
            "evaluation": {评估维度},
        }
        """
        return self.metacognition.meta_recall(
            query=query or "",
            limit=limit,
            max_rounds=max_rounds,
        )

    def evaluate_recall(self, query: str, results: list[dict] = None) -> dict:
        """
        评估一次检索结果的质量（不重新检索）。

        参数:
            query: 查询内容
            results: 检索结果（None 则自动检索一次）

        返回: MetaEvaluation.to_dict()
        """
        if results is None:
            recall_result = self.recall_engine.recall(query=query, limit=10)
            results = recall_result.get("primary", [])

        evaluation = self.metacognition.evaluate_result(query, results)
        return evaluation.to_dict()

    def build_context(
        self,
        query: str = None,
        max_tokens: int = 800,
        style: str = "compact",
    ) -> str:
        """
        组装 Agent 上下文（直接拼入 system prompt）。

        参数:
            query: 当前对话内容
            max_tokens: token 预算（默认 800，v4.1 优化）
            style: compact / structured / narrative / xml（默认 compact，v4.1 优化）
        """
        # 生成缓存键
        cache_key = f"context:{query}:{max_tokens}:{style}"
        
        # 检查缓存
        cached_context = self.cache.get(cache_key)
        if cached_context:
            return cached_context
        
        # 执行原始构建
        result = self.context_builder.build(
            query=query,
            max_tokens=max_tokens,
            style=style,
        )
        context = result["context"]
        
        # 缓存结果
        self.cache.set(cache_key, context, ttl=3600)

        return context

    def feedback(self, memory_id: str, useful: bool, note: str = None):
        """对一条记忆给出有用/没用的反馈"""
        self.quality.record_feedback(memory_id, useful, note)

    def remember_image(
        self,
        image_path: str,
        description: str = None,
        importance: str = "medium",
        topics: list[str] = None,
        prompt: str = None,
    ) -> dict:
        """
        记住一张图片。

        如果配置了 vision_fn（GPT-4o / Qwen-VL / MiMo Omni 等），会自动：
        - 理解图片内容并生成描述
        - 提取图中文字（OCR）
        - 分析图表/代码/配置截图

        如果有 CLIP，还会生成图片 embedding（支持以图搜图）。

        否则降级为基本元数据提取。

        参数:
            image_path: 图片文件路径
            description: 手动描述（可选，模型描述会追加）
            importance: 重要度
            topics: 主题列表
            prompt: 给视觉模型的提示词（默认自动）

        返回: {"written": bool, "memory_id": str, "model_description": str, "has_clip_embedding": bool}
        """
        from media_processor import IMAGE_FORMATS
        return self._remember_media(image_path, IMAGE_FORMATS, "image", description, importance, topics, prompt)

    def remember_audio(
        self,
        audio_path: str,
        description: str = None,
        importance: str = "medium",
        topics: list[str] = None,
    ) -> dict:
        """
        记住一段音频。

        如果配置了 audio_fn（Whisper / MiMo Omni 等），会自动转写语音为文字。

        参数:
            audio_path: 音频文件路径
            description: 手动描述（可选）
            importance: 重要度
            topics: 主题列表

        返回: {"written": bool, "memory_id": str, "transcript": str}
        """
        from media_processor import AUDIO_FORMATS
        return self._remember_media(audio_path, AUDIO_FORMATS, "audio", description, importance, topics, None)

    def remember_video(
        self,
        video_path: str,
        description: str = None,
        importance: str = "medium",
        topics: list[str] = None,
        prompt: str = None,
    ) -> dict:
        """
        记住一个视频。

        如果同时配置了 vision_fn + audio_fn + ffmpeg，会自动：
        - 提取关键帧并用视觉模型分析
        - 提取音频并转写
        - 合并为完整的视频描述

        参数:
            video_path: 视频文件路径
            description: 手动描述（可选）
            importance: 重要度
            topics: 主题列表
            prompt: 给视觉模型的提示词

        返回: {"written": bool, "memory_id": str, "description": str}
        """
        from media_processor import VIDEO_FORMATS
        return self._remember_media(video_path, VIDEO_FORMATS, "video", description, importance, topics, prompt)

    def remember_media(
        self,
        file_path: str,
        description: str = None,
        importance: str = "medium",
        topics: list[str] = None,
        prompt: str = None,
    ) -> dict:
        """
        万能入口：自动识别图片/音频/视频并处理。

        用法：
            memory.remember_media("/path/to/screenshot.png")
            memory.remember_media("/path/to/meeting.mp3")
            memory.remember_media("/path/to/demo.mp4")
        """
        from media_processor import ALL_FORMATS
        return self._remember_media(file_path, ALL_FORMATS, None, description, importance, topics, prompt)

    def _remember_media(
        self,
        file_path: str,
        allowed_formats: set,
        expected_type: str = None,
        description: str = None,
        importance: str = "medium",
        topics: list[str] = None,
        prompt: str = None,
    ) -> dict:
        """内部统一处理入口"""
        import os

        if not os.path.exists(file_path):
            return {"written": False, "memory_id": None, "description": "", "reason": "文件不存在"}

        ext = os.path.splitext(file_path)[1].lower()
        if ext not in allowed_formats:
            return {"written": False, "memory_id": None, "description": "", "reason": f"不支持的格式: {ext}"}

        filename = os.path.basename(file_path)

        # 用 MediaProcessor 处理
        if self.media_processor:
            result = self.media_processor.process(file_path, prompt=prompt)
            model_desc = result.get("description", "")
            metadata = result.get("metadata", {})
            media_type = result.get("media_type", expected_type or "unknown")
        else:
            model_desc = ""
            metadata = {"filename": filename}
            media_type = expected_type or "unknown"

        # 组合内容
        content_parts = []
        if description:
            content_parts.append(description)
        content_parts.append(f"📁 {filename}")

        if metadata:
            meta_strs = []
            for k, v in metadata.items():
                if k != "filename":
                    meta_strs.append(f"{k}: {v}")
            if meta_strs:
                content_parts.append(" | ".join(meta_strs))

        if model_desc:
            content_parts.append(f"\n{model_desc}")

        content = "\n".join(content_parts)

        # 确定主题
        if topics is None:
            type_topics = {
                "image": "media.image",
                "audio": "media.audio",
                "video": "media.video",
            }
            topics = [type_topics.get(media_type, "media")]

        # 写入记忆
        write_result = self.remember(
            content=content,
            importance=importance,
            topics=topics,
            nature="note",
        )

        # CLIP 图片 embedding（支持以图搜图）
        has_clip = False
        if media_type == "image" and self.embedding_store and write_result.get("written"):
            try:
                self.embedding_store.add_image(
                    memory_id=write_result["memory_id"],
                    image_path=file_path,
                    text_description=model_desc or description or "",
                    metadata={
                        "media_type": "image",
                        "importance": importance,
                        "source_file": filename,
                    },
                )
                has_clip = True
            except Exception as e:
                logger.debug(f"CLIP embedding 失败: {e}")

        write_result["description"] = model_desc
        write_result["media_type"] = media_type
        write_result["metadata"] = metadata
        write_result["has_clip_embedding"] = has_clip
        return write_result

    def compress(self, topic: str = None, smart: bool = True) -> dict:
        """
        压缩记忆。

        参数:
            topic: 指定主题
            smart: 使用智能压缩（向量聚类区分核心/边缘）
        """
        if smart:
            return self.compressor.smart_compress(
                embedding_store=self.embedding_store,
                topic_code=topic,
            )
        return self.compressor.compress(topic_code=topic)

    def deduplicate(self) -> dict:
        """批量去重"""
        if self.dedup:
            return self.dedup.deduplicate_batch()
        return {"error": "dedup not enabled"}

    def analyze_decay(self) -> dict:
        """分析记忆衰减状态"""
        return self.decay.analyze_all()

    def detect_causality(self, window_hours: int = 24) -> list[dict]:
        """自动检测因果关系（v5.3: 完整分析含时间线+链式+主题相似）"""
        result = self.causal.full_causal_analysis(
            window_hours=window_hours,
            embedding_store=self.embedding_store,
        )
        return result.get("heuristic", []) + result.get("timeline", [])

    def self_heal(self) -> dict:
        """执行自我修复扫描"""
        return self.self_healing.full_scan()

    def generate_graph(self, topic: str = None, format: str = "mermaid") -> str:
        """生成记忆图谱"""
        return self.graph.generate(center_topic=topic, format=format)

    def l1_add(self, content: str, role: str = "user") -> dict:
        """添加到短期记忆"""
        return self.hierarchy.l1_add(content, role)

    def l1_context(self, max_tokens: int = 1500) -> str:
        """获取短期记忆上下文"""
        return self.hierarchy.l1_context(max_tokens)

    def flush_session(self) -> list[dict]:
        """对话结束：L1 沉淀到 L2（带去重）"""
        result = self.hierarchy.l1_flush_to_l2(self.pipeline, deduplicator=self.dedup)
        self.hierarchy.l1_clear()
        return result

    def maintain(self) -> dict:
        """
        一键维护：执行全生命周期流转。

        步骤：
        1. L1 consolidation（合并、过滤低价值消息）
        2. L1→L2 沉淀（带去重）
        3. L2→L3 升级（高频/高价值记忆）
        4. 衰减分析
        5. 自我修复
        6. 因果链更新（v5.3: 完整因果分析含时间线+链式+主题相似）
        7. 记忆蒸馏（归档之后：对话碎片 → 主题摘要 → 知识图谱 → 个人百科）

        返回: 各阶段统计
        """
        from trace_logger import get_tracer
        tracer = get_tracer()

        # 初始化追踪 ID
        trace_id = tracer._next_id() if tracer._enabled else None

        result = {}
        stages = {}

        # 1. L1 consolidation
        t0 = time.perf_counter()
        try:
            hier_result = self.hierarchy.maintain(
                pipeline=self.pipeline,
                deduplicator=self.dedup,
                decay=self.decay,
            )
            result.update(hier_result)
        except Exception as e:
            result["hierarchy"] = {"error": str(e)}
        stages["hierarchy"] = (time.perf_counter() - t0) * 1000
        tracer.log_maintain_stage("hierarchy", stages["hierarchy"], result.get("hierarchy"), trace_id=trace_id)

        # 2. 自我修复
        t0 = time.perf_counter()
        try:
            heal_result = self.self_healing.run()
            result["self_healing"] = heal_result
        except Exception as e:
            result["self_healing"] = {"error": str(e)}
        stages["self_healing"] = (time.perf_counter() - t0) * 1000
        tracer.log_maintain_stage("self_healing", stages["self_healing"], result.get("self_healing"), trace_id=trace_id)

        # 3. 完整因果分析
        t0 = time.perf_counter()
        try:
            causal_result = self.causal.full_causal_analysis(
                window_hours=6,
                embedding_store=self.embedding_store,
            )
            result["causal_links"] = causal_result["total"]
        except Exception:
            result["causal_links"] = 0
        stages["causal_analysis"] = (time.perf_counter() - t0) * 1000
        tracer.log_maintain_stage("causal_analysis", stages["causal_analysis"], {"links": result.get("causal_links")}, trace_id=trace_id)

        # 4. 主动反应器扫描
        t0 = time.perf_counter()
        try:
            reactor_result = self.reactor.scan(
                store=self.store,
                decay=self.decay,
                self_healing=self.self_healing,
                causal=self.causal,
            )
            result["reactor"] = {
                "total_actions": reactor_result["total_actions"],
                "contradictions": len(reactor_result["contradictions"]),
                "decay_reviews": len(reactor_result["decay_reviews"]),
                "decisions": len(reactor_result["decisions"]),
            }
        except Exception as e:
            result["reactor"] = {"error": str(e)}
        stages["reactor"] = (time.perf_counter() - t0) * 1000
        tracer.log_maintain_stage("reactor", stages["reactor"], result.get("reactor"), trace_id=trace_id)

        # 5. 记忆蒸馏
        t0 = time.perf_counter()
        try:
            distill_result = self.distiller.distill()
            result["distill"] = distill_result
            self._distill_fail_count = 0
        except Exception as e:
            result["distill"] = {"error": str(e)}
            if not hasattr(self, "_distill_fail_count"):
                self._distill_fail_count = 0
            self._distill_fail_count += 1
            if self._distill_fail_count >= 3:
                logger.warning(
                    f"⚠️ 蒸馏连续失败 {self._distill_fail_count} 次: {e}。"
                    f"请检查 distill 模块配置或 LLM 接口。"
                )
        stages["distill"] = (time.perf_counter() - t0) * 1000
        tracer.log_maintain_stage("distill", stages["distill"], result.get("distill"), trace_id=trace_id)

        # 6. 自动快照
        t0 = time.perf_counter()
        try:
            snap_result = self.timeline.auto_snapshot_if_needed(interval_hours=24)
            if snap_result:
                result["auto_snapshot"] = {
                    "taken": True,
                    "label": snap_result.get("label"),
                    "memory_count": snap_result.get("memory_count"),
                }
            else:
                result["auto_snapshot"] = {"taken": False}
        except Exception as e:
            result["auto_snapshot"] = {"error": str(e)}
        stages["auto_snapshot"] = (time.perf_counter() - t0) * 1000
        tracer.log_maintain_stage("auto_snapshot", stages["auto_snapshot"], result.get("auto_snapshot"), trace_id=trace_id)

        # 7. 数据库维护
        t0 = time.perf_counter()
        try:
            self.store.auto_maintain(embedding_store=self.embedding_store)
            result["db_maintain"] = "ok"
        except Exception as e:
            result["db_maintain"] = {"error": str(e)}
        stages["db_maintain"] = (time.perf_counter() - t0) * 1000
        tracer.log_maintain_stage("db_maintain", stages["db_maintain"], result.get("db_maintain"), trace_id=trace_id)

        # 8. Phase 4: 更新内在状态
        t0 = time.perf_counter()
        try:
            recent = self.store.query(limit=10)
            state, mot_trace = self.motivation.update_state(recent)
            result["motivation"] = {
                "mood": state.mood_summary,
                "curiosity": state.curiosity,
                "boredom": state.boredom,
                "trace": mot_trace,
            }
        except Exception as e:
            result["motivation"] = {"error": str(e)}
        stages["motivation"] = (time.perf_counter() - t0) * 1000
        tracer.log_maintain_stage("motivation", stages["motivation"], result.get("motivation"), trace_id=trace_id)

        # 9. Phase 5/6: 更新身份画像
        t0 = time.perf_counter()
        try:
            identity_result = self.narrative.build_identity_profile()
            result["narrative_update"] = {
                "status": "ok",
                "identity_trace": identity_result.get("_trace", {}),
            }
        except Exception as e:
            result["narrative_update"] = {"error": str(e)}
        stages["narrative_update"] = (time.perf_counter() - t0) * 1000
        tracer.log_maintain_stage("narrative_update", stages["narrative_update"], result.get("narrative_update"), trace_id=trace_id)

        # 10. Phase 6: 数字孪生（v7.5）
        t0 = time.perf_counter()
        try:
            profile = self.digital_twin.build_unified_profile()
            result["digital_twin"] = {
                "status": "ok",
                "profile_id": profile.get("profile_id"),
                "confidence": profile.get("overall_confidence", 0.7),
            }
        except Exception as e:
            result["digital_twin"] = {"error": str(e)}
        stages["digital_twin"] = (time.perf_counter() - t0) * 1000
        tracer.log_maintain_stage("digital_twin", stages["digital_twin"], result.get("digital_twin"), trace_id=trace_id)

        # 汇总阶段耗时
        result["_stage_timing_ms"] = {k: round(v, 2) for k, v in stages.items()}
        result["_total_timing_ms"] = round(sum(stages.values()), 2)

        return result

    def distill(self, force: bool = False) -> dict:
        """
        手动触发记忆蒸馏。

        将原始对话记忆逐层抽象为结构化知识：
        原始记忆 → 主题摘要 → 知识图谱 → 个人百科

        参数:
            force: 强制全量重新蒸馏（忽略增量阈值）

        返回: 各层蒸馏结果
        """
        return self.distiller.distill(force=force)

    def get_distill_stats(self) -> dict:
        """获取蒸馏系统统计"""
        return self.distiller.get_distill_stats()

    def get_encyclopedia(self, category: str = None) -> list[dict]:
        """获取百科条目"""
        return self.distiller.get_encyclopedia(category=category)

    def search_encyclopedia(self, query: str) -> list[dict]:
        """搜索百科"""
        return self.distiller.search_encyclopedia(query)

    def export_encyclopedia(self, output_path: str = None) -> str:
        """导出百科为 Markdown"""
        return self.distiller.export_encyclopedia(output_path)

    # ── 时间旅行 ─────────────────────────────────────────

    def take_snapshot(self, label: str = None, at_ts: int = None, description: str = None) -> dict:
        """创建记忆快照"""
        return self.timeline.take_snapshot(label=label, at_ts=at_ts, description=description)

    def list_snapshots(self, limit: int = 50) -> list[dict]:
        """列出所有快照"""
        return self.timeline.list_snapshots(limit=limit)

    def get_snapshot(self, snapshot_id: str) -> dict | None:
        """获取快照详情"""
        return self.timeline.get_snapshot(snapshot_id)

    def diff_memories(self, from_ts: int = None, to_ts: int = None,
                      from_snapshot: str = None, to_snapshot: str = None,
                      topic: str = None) -> dict:
        """对比两个时间点的记忆差异"""
        return self.timeline.diff(from_ts=from_ts, to_ts=to_ts,
                                  from_snapshot=from_snapshot, to_snapshot=to_snapshot,
                                  topic=topic)

    def diff_natural(self, from_ts: int = None, to_ts: int = None,
                     from_snapshot: str = None, to_snapshot: str = None) -> str:
        """自然语言风格的差异描述"""
        return self.timeline.diff_natural(from_ts=from_ts, to_ts=to_ts,
                                          from_snapshot=from_snapshot, to_snapshot=to_snapshot)

    def blame_memory(self, memory_id: str) -> dict:
        """追溯记忆来源"""
        return self.timeline.blame(memory_id)

    def blame_natural(self, memory_id: str) -> str:
        """自然语言风格的来源描述"""
        return self.timeline.blame_natural(memory_id)

    def get_timeline_stats(self) -> dict:
        """时间旅行系统统计"""
        return self.timeline.get_timeline_stats()

    def get_stats(self) -> dict:
        """系统整体统计（有界查询，不再全量加载）"""
        # COUNT(*) 是 O(1)，不加载数据到内存
        total = self.store.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        stats = {
            "total_memories": total,
            "quality": self.quality.get_stats(),
            "causal": self.causal.get_stats(),
            "hierarchy": self.hierarchy.get_stats(),
            "self_healing": self.self_healing.get_stats(),
            "distill": self.distiller.get_distill_stats(),
            "timeline": self.timeline.get_timeline_stats(),
        }
        # decay 只加载最近 100 条做分析，不全量
        if total > 0:
            stats["decay"] = self.decay.analyze_all()
        else:
            stats["decay"] = {}
        if self.dedup:
            stats["dedup"] = self.dedup.get_stats()
        if self.embedding_store:
            try:
                stats["vectors"] = self.embedding_store.count()
            except Exception:
                stats["vectors"] = "unavailable"
        if self.reranker:
            stats["reranker"] = self.reranker.get_stats()
        stats["reactor"] = self.reactor.get_stats()
        stats["self_model"] = self.self_model.get_stats()
        stats["metacognition"] = self.metacognition.get_stats()
        stats["motivation"] = self.motivation.get_stats()
        stats["narrative"] = self.narrative.get_stats()
        stats["digital_twin"] = {"status": "ok"}  # 数字孪生状态
        return stats

    def build_persona(self) -> dict:
        """
        构建数字孪生人格画像。
        
        返回: 包含认知风格、决策模式、情感模式、知识边界和价值观的统一画像
        """
        return self.digital_twin.build_unified_profile()

    def get_persona(self) -> dict:
        """
        获取最新的数字孪生人格画像。
        
        返回: 最新的人格画像，或 None（如果尚未构建）
        """
        return self.digital_twin.get_latest_profile()

    # ── 个人风格 Agent 接口 ─────────────────────────────

    def list_roles(self) -> dict:
        """
        列出所有可用的角色模板。
        
        返回: {role_id: {name, source, version, speaking_style, topic_preferences}}
        """
        if not self.role_manager:
            return {}
        return self.role_manager.list_roles()

    def get_role(self, role_id: str) -> dict:
        """
        获取特定角色模板。
        
        参数:
            role_id: 角色 ID
        
        返回: 角色模板数据，或 None
        """
        if not self.role_manager:
            return None
        role = self.role_manager.get_role(role_id)
        if role:
            return {
                "name": role.name,
                "prompt_template": role.prompt_template,
                "personality_traits": role.personality_traits,
                "speaking_style": role.speaking_style,
                "topic_preferences": role.topic_preferences,
                "emotional_tone": role.emotional_tone,
                "source": role.source,
                "version": role.version
            }
        return None

    def apply_role(self, role_id: str, weight: float = 0.4) -> dict:
        """
        应用角色风格到个人人格。
        
        参数:
            role_id: 角色 ID
            weight: 角色风格权重（0-1）
        
        返回: 混合后的人格画像
        """
        if not self.role_manager or not self.digital_twin:
            return {}
        role = self.role_manager.get_role(role_id)
        if not role:
            return {}
        return self.digital_twin.apply_role_style(role, weight)

    def create_role(self, role_id: str, name: str, prompt_template: str, 
                   personality_traits: dict, speaking_style: str = "",
                   topic_preferences: list = None, emotional_tone: str = "") -> dict:
        """
        创建新角色模板。
        
        参数:
            role_id: 角色 ID
            name: 角色名称
            prompt_template: 提示词模板
            personality_traits: 人格特质
            speaking_style: 说话风格
            topic_preferences: 主题偏好
            emotional_tone: 情感基调
        
        返回: 创建结果
        """
        if not self.role_manager:
            return {"created": False, "reason": "role_manager not available"}
        from role_template import RoleTemplate
        role = RoleTemplate(
            name=name,
            prompt_template=prompt_template,
            personality_traits=personality_traits,
            speaking_style=speaking_style,
            topic_preferences=topic_preferences,
            emotional_tone=emotional_tone,
            source="custom"
        )
        self.role_manager.create_role(role_id, role)
        return {"created": True, "role_id": role_id}

    def delete_role(self, role_id: str) -> dict:
        """
        删除角色模板。
        
        参数:
            role_id: 角色 ID
        
        返回: 删除结果
        """
        if not self.role_manager:
            return {"deleted": False, "reason": "role_manager not available"}
        self.role_manager.delete_role(role_id)
        return {"deleted": True, "role_id": role_id}

    def process_media_for_style(self, file_path: str) -> dict:
        """
        处理媒体文件并提取风格特征。
        
        参数:
            file_path: 媒体文件路径
        
        返回: 风格分析结果
        """
        if not self.media_processor or not self.style_analyzer:
            return {"success": False, "reason": "required components not available"}
        
        # 处理媒体文件
        result = self.media_processor.process_for_style(file_path)
        if not result.get("success"):
            return result
        
        # 分析风格
        content = result.get("content", "")
        if not content:
            return {"success": False, "reason": "no content extracted"}
        
        style = self.style_analyzer.analyze(content)
        result["style"] = style
        return result

    def create_role_from_media(self, file_path: str, role_name: str) -> dict:
        """
        从媒体文件创建角色模板。
        
        参数:
            file_path: 媒体文件路径
            role_name: 角色名称
        
        返回: 创建结果
        """
        # 处理媒体文件并提取风格
        process_result = self.process_media_for_style(file_path)
        if not process_result.get("success"):
            return {"created": False, "reason": process_result.get("reason", "process failed")}
        
        # 创建角色模板
        style = process_result.get("style", {})
        from style_analyzer import create_role_from_style
        role_data = create_role_from_style(style, role_name)
        
        # 生成角色 ID
        import hashlib
        role_id = f"media_{hashlib.md5((role_name + str(process_result.get('media_type', ''))).encode()).hexdigest()[:8]}"
        
        # 保存角色
        return self.create_role(
            role_id=role_id,
            name=role_name,
            prompt_template=role_data["prompt_template"],
            personality_traits=role_data["personality_traits"],
            speaking_style=role_data["speaking_style"],
            topic_preferences=role_data["topic_preferences"],
            emotional_tone=role_data["emotional_tone"]
        )

    # ── 主动反应器接口 ─────────────────────────────────

    def get_pending_notifications(self) -> list[dict]:
        """
        获取待处理的主动通知（由 reactor 创建的任务）。
        Agent 应在对话开始时调用此方法，检查是否有待处理事项。

        返回: [{"task_id", "title", "memory_id", "deadline", ...}, ...]
        """
        return self.reactor.get_pending_notifications(self.store)

    def reactor_scan(self) -> dict:
        """
        手动触发 reactor 全量扫描（矛盾/衰减/决策链）。

        通常不需要手动调用 —— maintain() 会自动执行。
        """
        return self.reactor.scan(
            store=self.store,
            decay=self.decay,
            self_healing=self.self_healing,
            causal=self.causal,
        )

    def export_json(self, output_path: str, limit: int = 10000) -> dict:
        """
        全量导出为 JSON（含所有维度）。

        用于数据迁移、备份、分析。
        """
        import json
        memories = self.store.query(limit=limit)

        export_data = {
            "version": "4.2.0",
            "exported_at": time.time(),
            "total": len(memories),
            "memories": [],
        }

        for mem in memories:
            record = {
                "memory_id": mem["memory_id"],
                "time_id": mem.get("time_id", ""),
                "time_ts": mem.get("time_ts", 0),
                "person_id": mem.get("person_id", ""),
                "nature_id": mem.get("nature_id", ""),
                "content": mem.get("content", ""),
                "content_hash": mem.get("content_hash", ""),
                "importance": mem.get("importance", "medium"),
                "topics": mem.get("topics", []),
                "tools": mem.get("tools", []),
                "knowledge": mem.get("knowledge", []),
                "is_aggregated": bool(mem.get("is_aggregated", 0)),
                "source_count": mem.get("source_count", 1),
            }
            export_data["memories"].append(record)

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(export_data, f, ensure_ascii=False, indent=2)

        return {"exported": len(memories), "file": output_path}

    def export_csv(self, output_path: str, limit: int = 10000) -> dict:
        """
        导出为 CSV（扁平化，方便 Excel/数据分析工具）。
        """
        import csv
        memories = self.store.query(limit=limit)

        with open(output_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "memory_id", "time_id", "time_ts", "person_id", "nature_id",
                "content", "importance", "topics", "is_aggregated",
            ])
            for mem in memories:
                topics = mem.get("topics", [])
                topic_str = ";".join(
                    t.get("code", "") if isinstance(t, dict) else t for t in topics
                )
                writer.writerow([
                    mem["memory_id"],
                    mem.get("time_id", ""),
                    mem.get("time_ts", 0),
                    mem.get("person_id", ""),
                    mem.get("nature_id", ""),
                    mem.get("content", "")[:500],  # CSV 截断
                    mem.get("importance", "medium"),
                    topic_str,
                    bool(mem.get("is_aggregated", 0)),
                ])

        return {"exported": len(memories), "file": output_path}

    def auto_backup(self, backup_dir: str = None, keep_days: int = 7) -> dict:
        """
        自动备份数据库 + 向量库。

        保留最近 keep_days 天的备份，超期自动清理。
        """
        import os
        import glob
        from datetime import datetime, timedelta

        backup_dir = backup_dir or os.path.join(self._project_dir, "backups")
        os.makedirs(backup_dir, exist_ok=True)

        now_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        db_backup = os.path.join(backup_dir, f"memory_{now_str}.db")

        # 备份 SQLite
        self.store.backup(db_backup)

        # 备份质量统计
        q_path = os.path.join(self._project_dir, "quality_stats.json")
        if os.path.exists(q_path):
            import shutil
            shutil.copy2(q_path, os.path.join(backup_dir, f"quality_{now_str}.json"))

        # 清理过期备份
        cutoff = datetime.now() - timedelta(days=keep_days)
        cleaned = 0
        for pattern in ["memory_*.db", "quality_*.json"]:
            for f in glob.glob(os.path.join(backup_dir, pattern)):
                try:
                    # 从文件名提取时间
                    basename = os.path.basename(f)
                    parts = basename.split("_")
                    if len(parts) >= 2:
                        date_str = parts[1].split(".")[0]
                        file_date = datetime.strptime(date_str, "%Y%m%d")
                        if file_date < cutoff:
                            os.unlink(f)
                            cleaned += 1
                except Exception:
                    pass

        return {
            "db_backup": db_backup,
            "cleaned_old": cleaned,
            "backup_dir": backup_dir,
        }

    def close(self):
        """关闭数据库连接"""
        self.store.close()

    def close_all(self):
        """关闭所有线程的数据库连接"""
        self.store.close_all()

    def _check_schema_version(self):
        """
        Schema 版本管理。

        在 _schema_version 表记录当前 schema 版本号。
        如果数据库版本 < 代码版本，执行增量迁移。
        如果数据库版本 > 代码版本，发出警告（向前兼容但不保证）。
        """
        CURRENT_SCHEMA_VERSION = 6  # Phase 5: identity_model + life_narratives

        # 创建版本表（如果不存在）
        self.store.conn.executescript("""
            CREATE TABLE IF NOT EXISTS _schema_version (
                version INTEGER PRIMARY KEY,
                applied_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );
        """)
        self.store.conn.commit()

        # 获取当前数据库版本
        row = self.store.conn.execute(
            "SELECT version FROM _schema_version ORDER BY version DESC LIMIT 1"
        ).fetchone()
        db_version = row["version"] if row else 0

        if db_version == CURRENT_SCHEMA_VERSION:
            # 版本匹配，尝试运行文件型迁移（migrate.py 管理的）
            self._run_file_migrations(db_version)
            return

        if db_version > CURRENT_SCHEMA_VERSION:
            logger.warning(
                f"⚠️ 数据库版本 (v{db_version}) 高于代码版本 (v{CURRENT_SCHEMA_VERSION})。"
                f"请升级 agent-memory 到 v{db_version}+ 或使用 migrate.py rollback。"
                f"继续运行可能丢失新版本数据。"
            )
            return

        logger.info(f"Schema 迁移: v{db_version} → v{CURRENT_SCHEMA_VERSION}")
        applied = []

        # 增量迁移
        if db_version < 1:
            try:
                from schema import SCHEMA_PATH  # noqa
            except Exception:
                pass
            applied.append("v1: base schema")

        if db_version < 2:
            try:
                from distill import DISTILL_SCHEMA
                self.store.conn.executescript(DISTILL_SCHEMA)
                applied.append("v2: distill tables")
            except Exception as e:
                logger.warning(f"Distill schema 迁移失败: {e}")

            try:
                from pipeline import _WRITE_QUEUE_SCHEMA
                self.store.conn.executescript(_WRITE_QUEUE_SCHEMA)
                applied.append("v2: write_queue table")
            except Exception as e:
                logger.warning(f"WriteQueue schema 迁移失败: {e}")

        if db_version < 3:
            try:
                from timeline import TIMELINE_SCHEMA
                self.store.conn.executescript(TIMELINE_SCHEMA)
                applied.append("v3: timeline tables")
            except Exception as e:
                logger.warning(f"Timeline schema 迁移失败: {e}")

        if db_version < 4:
            # Phase 2: reasoning_traces + self_reflections
            self.self_ref_schema = """
                CREATE TABLE IF NOT EXISTS reasoning_traces (
                    trace_id        TEXT PRIMARY KEY,
                    query           TEXT NOT NULL,
                    result_summary  TEXT,
                    confidence      REAL DEFAULT 0.0,
                    sources_used    TEXT DEFAULT '[]',
                    steps           TEXT DEFAULT '[]',
                    uncertainty     TEXT DEFAULT '[]',
                    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
                );
                CREATE TABLE IF NOT EXISTS self_reflections (
                    reflection_id   TEXT PRIMARY KEY,
                    trace_id        TEXT,
                    insight         TEXT NOT NULL,
                    action_taken    TEXT,
                    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                    FOREIGN KEY (trace_id) REFERENCES reasoning_traces(trace_id)
                );
                CREATE INDEX IF NOT EXISTS idx_trace_query ON reasoning_traces(query);
                CREATE INDEX IF NOT EXISTS idx_trace_confidence ON reasoning_traces(confidence);
                CREATE INDEX IF NOT EXISTS idx_trace_created ON reasoning_traces(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_reflection_trace ON self_reflections(trace_id);
                CREATE INDEX IF NOT EXISTS idx_reflection_created ON self_reflections(created_at DESC);
            """
            try:
                self.store.conn.executescript(self.self_ref_schema)
                applied.append("v4: reasoning_traces + self_reflections")
            except Exception as e:
                logger.warning(f"Self-reference schema 迁移失败: {e}")

        if db_version < 5:
            # Phase 4: internal_state
            try:
                self.store.conn.executescript("""
                    CREATE TABLE IF NOT EXISTS internal_state (
                        state_id        TEXT PRIMARY KEY,
                        curiosity       REAL DEFAULT 0.3,
                        boredom         REAL DEFAULT 0.0,
                        confidence      REAL DEFAULT 0.5,
                        satisfaction    REAL DEFAULT 0.5,
                        urgency         REAL DEFAULT 0.0,
                        dominant_drive  TEXT DEFAULT 'none',
                        updated_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
                    );
                """)
                applied.append("v5: internal_state")
            except Exception as e:
                logger.warning(f"Internal state schema 迁移失败: {e}")

        if db_version < 6:
            # Phase 5: identity_model + life_narratives
            try:
                self.store.conn.executescript("""
                    CREATE TABLE IF NOT EXISTS identity_model (
                        key             TEXT PRIMARY KEY,
                        value           TEXT NOT NULL,
                        confidence      REAL DEFAULT 0.5,
                        evidence_count  INTEGER DEFAULT 0,
                        updated_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
                    );
                    CREATE TABLE IF NOT EXISTS life_narratives (
                        narrative_id        TEXT PRIMARY KEY,
                        narrative_type      TEXT NOT NULL,
                        title               TEXT NOT NULL,
                        content             TEXT NOT NULL,
                        period_start        INTEGER,
                        period_end          INTEGER,
                        source_memory_count INTEGER DEFAULT 0,
                        created_at          INTEGER NOT NULL DEFAULT (strftime('%s','now'))
                    );
                    CREATE INDEX IF NOT EXISTS idx_identity_key ON identity_model(key);
                    CREATE INDEX IF NOT EXISTS idx_narrative_type ON life_narratives(narrative_type);
                    CREATE INDEX IF NOT EXISTS idx_narrative_created ON life_narratives(created_at DESC);
                """)
                applied.append("v6: identity_model + life_narratives")
            except Exception as e:
                logger.warning(f"Narrative schema 迁移失败: {e}")

        # 运行文件型迁移（migrate.py 管理的 .sql 文件）
        self._run_file_migrations(CURRENT_SCHEMA_VERSION)

        # 记录新版本
        self.store.conn.execute(
            "INSERT INTO _schema_version (version) VALUES (?)",
            (CURRENT_SCHEMA_VERSION,),
        )
        self.store.conn.commit()
        if applied:
            logger.info(f"✅ Schema 迁移完成: v{CURRENT_SCHEMA_VERSION} (applied: {', '.join(applied)})")
        else:
            logger.info(f"✅ Schema 版本确认: v{CURRENT_SCHEMA_VERSION}")

    def _run_file_migrations(self, _current_version: int = None):
        """运行 migrate.py 管理的文件型迁移（registry/migrations/*.sql）

        使用独立连接，与主 schema 版本系统并行工作。
        MigrationManager 自行追踪已应用的迁移版本。
        """
        try:
            from migrate import MigrationManager
            mgr = MigrationManager(db_path=self.store.db_path)
            pending = mgr.get_pending_migrations()
            if pending:
                logger.info(f"发现 {len(pending)} 个待应用的文件型迁移")
                result = mgr.upgrade()
                if result.get("applied"):
                    logger.info(f"文件型迁移完成: {result['applied']}")
                if result.get("errors"):
                    for err in result["errors"]:
                        logger.warning(f"迁移错误: {err}")
            mgr.conn.close()
        except Exception:
            pass  # migrate.py 不可用时不阻塞启动
