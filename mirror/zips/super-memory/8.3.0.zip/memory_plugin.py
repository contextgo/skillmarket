
"""
Agent Memory Plugin for OpenClaw
云端部署版
"""

import os
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class AgentMemoryPlugin:
    """
    记忆系统插件，用于OpenClaw
    """
    
    def __init__(self, plugin_config=None):
        """
        初始化插件
        :param plugin_config: 插件配置
        """
        self.config = plugin_config or {}
        self._setup_paths()
        self._init_memory_system()
        
    def _setup_paths(self):
        """设置路径"""
        # 插件目录
        self.plugin_dir = Path(__file__).parent
        # 数据目录（在插件目录下）
        self.data_dir = self.plugin_dir / "data"
        self.data_dir.mkdir(exist_ok=True)
        # 配置目录
        self.config_dir = self.plugin_dir / "config"
        self.config_dir.mkdir(exist_ok=True)
        # 角色目录
        self.roles_dir = self.plugin_dir / "roles"
        self.roles_dir.mkdir(exist_ok=True)
        
        logger.info(f"插件数据目录: {self.data_dir}")
        
    def _init_memory_system(self):
        """初始化记忆系统"""
        try:
            # 导入记忆系统
            import sys
            sys.path.insert(0, str(self.plugin_dir))
            
            from memory_system import AgentMemory
            
            # 初始化记忆系统
            self.memory = AgentMemory(
                db_path=str(self.data_dir / "memory.db"),
                project_dir=str(self.config_dir),
                enable_semantic=self.config.get("enable_semantic", True),
                enable_filter=self.config.get("enable_filter", True),
                enable_dedup=self.config.get("enable_dedup", True)
            )
            
            logger.info("记忆系统初始化成功")
            self._available = True
        except Exception as e:
            logger.error(f"记忆系统初始化失败: {e}")
            self._available = False
            self.memory = None
            
    def is_available(self):
        """检查记忆系统是否可用"""
        return self._available
    
    def remember(self, content, importance="medium", topics=None):
        """
        记住信息
        :param content: 记忆内容
        :param importance: 重要度
        :param topics: 主题列表
        :return: 写入结果
        """
        if not self._available:
            return {"written": False, "reason": "memory system unavailable"}
        
        return self.memory.remember(
            content=content,
            importance=importance,
            topics=topics
        )
    
    def recall(self, query, limit=10):
        """
        检索记忆
        :param query: 查询内容
        :param limit: 返回条数
        :return: 检索结果
        """
        if not self._available:
            return {"primary": [], "related": []}
        
        return self.memory.recall(query=query, limit=limit)
    
    def build_context(self, query, max_tokens=800):
        """
        构建上下文
        :param query: 查询内容
        :param max_tokens: 最大token数
        :return: 上下文字符串
        """
        if not self._available:
            return ""
        
        return self.memory.build_context(query=query, max_tokens=max_tokens)
    
    def get_persona(self):
        """获取人格画像"""
        if not self._available:
            return None
        
        return self.memory.get_persona()
    
    def apply_role(self, role_id, weight=0.4):
        """应用角色风格"""
        if not self._available:
            return {}
        
        return self.memory.apply_role(role_id, weight)
    
    def list_roles(self):
        """列出所有角色"""
        if not self._available:
            return {}
        
        return self.memory.list_roles()
    
    def close(self):
        """关闭资源"""
        if self.memory:
            try:
                self.memory.close()
                logger.info("记忆系统已关闭")
            except Exception as e:
                logger.error(f"关闭记忆系统时出错: {e}")

# 插件入口
_memory_plugin = None

def get_memory_plugin(plugin_config=None):
    """获取记忆系统插件实例（单例）"""
    global _memory_plugin
    if _memory_plugin is None:
        _memory_plugin = AgentMemoryPlugin(plugin_config)
    return _memory_plugin

def close_memory_plugin():
    """关闭记忆系统插件"""
    global _memory_plugin
    if _memory_plugin:
        _memory_plugin.close()
        _memory_plugin = None
