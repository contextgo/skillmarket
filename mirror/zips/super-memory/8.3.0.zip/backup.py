"""
backup.py - 备份与恢复工具

支持：
- SQLite 在线备份（不阻塞读写）
- 向量库快照（ChromaDB 导出）
- 全量 JSON 导出（可读、可迁移）
- 增量备份（基于时间戳）
- 自动清理过期备份
- 一键恢复

用法:
    python3 backup.py create                    # 创建完整备份
    python3 backup.py create --type json        # 仅 JSON 导出
    python3 backup.py list                      # 列出备份
    python3 backup.py restore backup_20260412   # 恢复备份
    python3 backup.py cleanup --keep-days 7     # 清理过期备份
"""

import os
import sys
import json
import shutil
import sqlite3
import gzip
import hashlib
import logging
from datetime import datetime, timedelta
from pathlib import Path

logger = logging.getLogger(__name__)


class BackupManager:
    """备份与恢复管理器"""

    def __init__(self, db_path: str = None, backup_dir: str = None, project_dir: str = None):
        self.project_dir = project_dir or str(Path(__file__).parent)
        self.db_path = db_path or os.path.join(self.project_dir, "memory.db")
        self.backup_dir = backup_dir or os.path.join(self.project_dir, "backups")
        os.makedirs(self.backup_dir, exist_ok=True)

    def create_backup(
        self,
        backup_type: str = "full",
        compress: bool = True,
        tag: str = None,
    ) -> dict:
        """
        创建备份。

        参数:
            backup_type: "full" (SQLite + 向量 + JSON) / "db" (仅 SQLite) / "json" (仅 JSON)
            compress: 是否压缩
            tag: 备份标签（用于标识用途）

        返回: {"backup_id": str, "files": list, "size_bytes": int, "duration_ms": int}
        """
        import time
        start = time.time()

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        tag_suffix = f"_{tag}" if tag else ""
        backup_id = f"backup_{timestamp}{tag_suffix}"
        backup_path = os.path.join(self.backup_dir, backup_id)
        os.makedirs(backup_path, exist_ok=True)

        files = []

        # 1. SQLite 在线备份
        if backup_type in ("full", "db"):
            db_backup = os.path.join(backup_path, "memory.db")
            self._backup_sqlite(db_backup)
            files.append("memory.db")

            # 附带迁移记录
            try:
                conn = sqlite3.connect(self.db_path)
                migrations = conn.execute("SELECT * FROM _migrations ORDER BY version").fetchall()
                conn.close()
                if migrations:
                    mig_file = os.path.join(backup_path, "migrations.json")
                    with open(mig_file, "w") as f:
                        json.dump([dict(m) for m in migrations], f, indent=2)
                    files.append("migrations.json")
            except Exception:
                pass

        # 2. 向量库（v6.0: 已合并到 SQLite，无需单独备份）

        # 3. JSON 导出（可读、可迁移）
        if backup_type in ("full", "json"):
            json_file = os.path.join(backup_path, "memories.json")
            count = self._export_json(json_file)
            files.append("memories.json")

        # 4. 质量统计
        quality_file = os.path.join(self.project_dir, "quality_stats.json")
        if os.path.exists(quality_file):
            shutil.copy2(quality_file, os.path.join(backup_path, "quality_stats.json"))
            files.append("quality_stats.json")

        # 5. 注册表
        registry_dir = os.path.join(self.project_dir, "registry")
        if os.path.exists(registry_dir):
            reg_backup = os.path.join(backup_path, "registry")
            shutil.copytree(registry_dir, reg_backup, dirs_exist_ok=True)
            files.append("registry/")

        # 6. 压缩
        total_size = sum(
            os.path.getsize(os.path.join(backup_path, f))
            for f in os.listdir(backup_path)
            if os.path.isfile(os.path.join(backup_path, f))
        )

        if compress:
            archive_path = shutil.make_archive(backup_path, "gztar", backup_path)
            # 删除未压缩的目录
            shutil.rmtree(backup_path)
            final_path = archive_path
            total_size = os.path.getsize(archive_path)
        else:
            final_path = backup_path

        duration_ms = int((time.time() - start) * 1000)

        # 写入元数据
        meta = {
            "backup_id": backup_id,
            "created_at": timestamp,
            "type": backup_type,
            "files": files,
            "size_bytes": total_size,
            "duration_ms": duration_ms,
            "compressed": compress,
            "tag": tag,
            "db_path": self.db_path,
        }

        # 备份验证：确保备份可用
        verify_result = self._verify_backup(backup_path if not compress else final_path, compress)
        meta["verified"] = verify_result["ok"]
        meta["verify_details"] = verify_result
        if not verify_result["ok"]:
            logger.error(f"⚠️ 备份验证失败: {verify_result['issues']}")
            meta["verify_warning"] = "BACKUP VERIFICATION FAILED - may not be restorable"

        meta_path = final_path + ".meta.json"
        with open(meta_path, "w") as f:
            json.dump(meta, f, indent=2)

        logger.info(f"✅ 备份完成: {backup_id} ({total_size:,} bytes, {duration_ms}ms, verified={verify_result['ok']})")
        return meta

    def _verify_backup(self, backup_path: str, is_compressed: bool) -> dict:
        """验证备份完整性：SQLite 完整性 + 记忆条数 + 外键检查"""
        import tempfile
        issues = []
        db_path = None
        tmp_dir = None

        try:
            if is_compressed:
                # 解压到临时目录
                tmp_dir = tempfile.mkdtemp()
                shutil.unpack_archive(backup_path, tmp_dir)
                db_path = os.path.join(tmp_dir, "memory.db")
            else:
                db_path = os.path.join(backup_path, "memory.db")

            if not os.path.exists(db_path):
                issues.append("memory.db not found in backup")
                return {"ok": False, "issues": issues}

            # 打开备份数据库做验证
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row

            # 1. SQLite 完整性检查
            row = conn.execute("PRAGMA integrity_check").fetchone()
            if row and row[0] != "ok":
                issues.append(f"integrity_check: {row[0]}")

            # 2. 外键检查
            fk_violations = conn.execute("PRAGMA foreign_key_check").fetchall()
            if fk_violations:
                issues.append(f"foreign_key violations: {len(fk_violations)}")

            # 3. 记忆条数 vs 源数据库
            backup_count = conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
            try:
                src_conn = sqlite3.connect(self.db_path)
                src_count = src_conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
                src_conn.close()
                if backup_count == 0 and src_count > 0:
                    issues.append(f"backup has 0 memories but source has {src_count}")
                elif backup_count < src_count:
                    # 增量差异允许（备份过程中可能有新写入），只记录不报错
                    pass
            except Exception:
                pass

            # 4. 关键表存在性检查
            tables = [r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()]
            required_tables = ["memories", "memory_topics", "memory_links", "memory_tools"]
            for t in required_tables:
                if t not in tables:
                    issues.append(f"missing table: {t}")

            conn.close()

        except Exception as e:
            issues.append(f"verification error: {e}")
        finally:
            if tmp_dir and os.path.exists(tmp_dir):
                shutil.rmtree(tmp_dir, ignore_errors=True)

        return {"ok": len(issues) == 0, "issues": issues}

    def _backup_sqlite(self, target_path: str):
        """SQLite 在线备份（不阻塞读写）"""
        src = sqlite3.connect(self.db_path)
        dst = sqlite3.connect(target_path)
        with dst:
            src.backup(dst)
        src.close()
        dst.close()

    def _export_json(self, output_path: str) -> int:
        """导出全部记忆为 JSON"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row

            memories = conn.execute("SELECT * FROM memories ORDER BY time_ts").fetchall()
            topics = conn.execute("SELECT * FROM memory_topics").fetchall()
            links = conn.execute("SELECT * FROM memory_links").fetchall()

            export = {
                "version": "5.1.0",
                "exported_at": datetime.now().isoformat(),
                "total": len(memories),
                "memories": [],
            }

            # 构建 topic 映射
            topic_map = {}
            for t in topics:
                mid = t["memory_id"]
                if mid not in topic_map:
                    topic_map[mid] = []
                topic_map[mid].append(t["topic_code"])

            for mem in memories:
                mid = mem["memory_id"]
                export["memories"].append({
                    "memory_id": mid,
                    "time_id": mem["time_id"],
                    "time_ts": mem["time_ts"],
                    "person_id": mem["person_id"],
                    "nature_id": mem["nature_id"],
                    "content": mem["content"],
                    "content_hash": mem["content_hash"],
                    "importance": mem["importance"],
                    "topics": topic_map.get(mid, []),
                })

            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(export, f, ensure_ascii=False, indent=2)

            conn.close()
            return len(memories)
        except Exception as e:
            logger.error(f"JSON 导出失败: {e}")
            return 0

    def list_backups(self) -> list[dict]:
        """列出所有备份"""
        backups = []
        for item in sorted(os.listdir(self.backup_dir)):
            item_path = os.path.join(self.backup_dir, item)
            meta_path = item_path + ".meta.json"

            if os.path.exists(meta_path):
                with open(meta_path, "r") as f:
                    meta = json.load(f)
                backups.append(meta)
            elif item.startswith("backup_"):
                # 没有元数据的旧备份
                size = os.path.getsize(item_path) if os.path.isfile(item_path) else sum(
                    os.path.getsize(os.path.join(dp, fn))
                    for dp, dn, fns in os.walk(item_path) for fn in fns
                )
                backups.append({
                    "backup_id": item,
                    "size_bytes": size,
                    "type": "unknown",
                })

        return backups

    def restore(self, backup_id: str, target_db: str = None) -> dict:
        """
        从备份恢复。

        参数:
            backup_id: 备份 ID
            target_db: 恢复目标路径（默认覆盖原数据库）

        返回: {"restored": list, "errors": list}
        """
        target_db = target_db or self.db_path

        # 查找备份
        backup_path = os.path.join(self.backup_dir, backup_id)
        archive_path = backup_path + ".tar.gz"

        if os.path.exists(archive_path):
            # 解压
            import tempfile
            tmp_dir = tempfile.mkdtemp()
            shutil.unpack_archive(archive_path, tmp_dir)
            backup_path = tmp_dir
        elif not os.path.exists(backup_path):
            return {"restored": [], "errors": [f"备份不存在: {backup_id}"]}

        restored = []
        errors = []

        # 1. 恢复 SQLite
        db_backup = os.path.join(backup_path, "memory.db")
        if os.path.exists(db_backup):
            try:
                # 备份当前数据库
                if os.path.exists(target_db):
                    shutil.copy2(target_db, target_db + ".pre_restore")
                shutil.copy2(db_backup, target_db)
                restored.append("memory.db")
            except Exception as e:
                errors.append(f"SQLite 恢复失败: {e}")

        # 2. 恢复向量库（v6.0: 已合并到 SQLite，旧 chroma_db 备份忽略）
        chroma_backup = os.path.join(backup_path, "chroma_db")
        if os.path.exists(chroma_backup):
            restored.append("chroma_db/ (跳过: v6.0 向量已合入 SQLite)")

        # 3. 恢复质量统计
        quality_backup = os.path.join(backup_path, "quality_stats.json")
        if os.path.exists(quality_backup):
            try:
                shutil.copy2(quality_backup, os.path.join(self.project_dir, "quality_stats.json"))
                restored.append("quality_stats.json")
            except Exception as e:
                errors.append(f"质量统计恢复失败: {e}")

        return {"restored": restored, "errors": errors}

    def cleanup(self, keep_days: int = 7) -> dict:
        """清理过期备份"""
        cutoff = datetime.now() - timedelta(days=keep_days)
        cleaned = []
        freed_bytes = 0

        for item in os.listdir(self.backup_dir):
            item_path = os.path.join(self.backup_dir, item)

            # 从名称提取时间
            try:
                # backup_20260412_120000[_tag]
                parts = item.replace(".tar.gz", "").replace(".meta.json", "").split("_")
                if len(parts) >= 2 and parts[0] == "backup":
                    date_str = parts[1]
                    file_date = datetime.strptime(date_str, "%Y%m%d")
                    if file_date < cutoff:
                        size = os.path.getsize(item_path) if os.path.isfile(item_path) else 0
                        os.unlink(item_path) if os.path.isfile(item_path) else shutil.rmtree(item_path)
                        cleaned.append(item)
                        freed_bytes += size
                        # 清理元数据
                        meta = item_path + ".meta.json"
                        if os.path.exists(meta):
                            os.unlink(meta)
            except (ValueError, IndexError):
                continue

        return {"cleaned": cleaned, "count": len(cleaned), "freed_bytes": freed_bytes}


def main():
    import argparse
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    parser = argparse.ArgumentParser(description="备份与恢复工具")
    parser.add_argument("command", choices=["create", "list", "restore", "cleanup"])
    parser.add_argument("--type", choices=["full", "db", "json"], default="full")
    parser.add_argument("--db", type=str, help="数据库路径")
    parser.add_argument("--backup-dir", type=str, help="备份目录")
    parser.add_argument("--keep-days", type=int, default=7, help="保留天数")
    parser.add_argument("--tag", type=str, help="备份标签")
    parser.add_argument("backup_id", nargs="?", help="备份 ID (restore)")

    args = parser.parse_args()
    mgr = BackupManager(db_path=args.db, backup_dir=args.backup_dir)

    if args.command == "create":
        result = mgr.create_backup(backup_type=args.type, tag=args.tag)
        print(f"备份 ID: {result['backup_id']}")
        print(f"大小: {result['size_bytes']:,} bytes")
        print(f"耗时: {result['duration_ms']}ms")
        print(f"文件: {', '.join(result['files'])}")

    elif args.command == "list":
        backups = mgr.list_backups()
        if not backups:
            print("无备份")
        else:
            for b in backups:
                size_mb = b.get("size_bytes", 0) / 1024 / 1024
                print(f"  {b['backup_id']}  ({size_mb:.1f} MB)  [{b.get('type', '?')}]")

    elif args.command == "restore":
        if not args.backup_id:
            print("错误: 请提供备份 ID")
            sys.exit(1)
        result = mgr.restore(args.backup_id)
        print(f"已恢复: {', '.join(result['restored'])}")
        if result["errors"]:
            for e in result["errors"]:
                print(f"  ❌ {e}")

    elif args.command == "cleanup":
        result = mgr.cleanup(keep_days=args.keep_days)
        print(f"清理完成: 删除 {result['count']} 个备份, 释放 {result['freed_bytes']:,} bytes")


if __name__ == "__main__":
    main()
