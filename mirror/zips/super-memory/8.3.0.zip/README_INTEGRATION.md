# OpenClaw 记忆系统集成指南

## 集成方案

### 1. 压缩包上传和安装

**步骤1：上传压缩包到服务器**
```bash
# 使用scp上传（示例）
scp agent_memory_v8.1_plugin.zip root@您的服务器IP:/tmp/

# 或者使用其他方式上传到/tmp/目录
```

**步骤2：解压到插件目录**
```bash
# 创建插件目录
mkdir -p /home/admin/.openclaw/plugins/agent_memory

# 解压到插件目录
cd /home/admin/.openclaw/plugins/agent_memory
unzip /tmp/agent_memory_v8.1_plugin.zip

# 安装依赖
pip install sqlite-vec sentence-transformers FlagEmbedding
```

### 2. 集成到OpenClaw

#### 方式A：直接在Agent中使用（推荐）

**找到Agent的主文件**：通常在 `/home/admin/.openclaw/src/agents/` 目录下

**修改Agent文件**：

```python
# 在文件顶部添加
import sys
from pathlib import Path

# 添加记忆系统路径
plugin_dir = Path("/home/admin/.openclaw/plugins/agent_memory")
sys.path.insert(0, str(plugin_dir))

from memory_bridge import get_memory_bridge

class Agent:
    def __init__(self, ...):
        # 现有初始化代码...
        
        # 初始化记忆系统
        self.memory = get_memory_bridge()
    
    def process_message(self, user_input):
        # 1. 记住用户输入
        self.memory.remember(user_input, importance="medium")
        
        # 2. 检索相关记忆
        related_memories = self.memory.recall(user_input, limit=3)
        
        # 3. 构建上下文
        context = self.memory.build_context(user_input)
        
        # 4. 现有的消息处理逻辑
        # 例如：response = self.generate_response(user_input, context)
        
        # 5. 记住回复
        # self.memory.remember(response, importance="low")
        
        return response
    
    def __del__(self):
        # 关闭记忆系统
        if hasattr(self, 'memory'):
            self.memory.close()
```

#### 方式B：创建插件服务

**在插件目录创建 `agent_memory_service.py`**：

```python
"""
记忆系统服务
为OpenClaw提供记忆功能
"""

from memory_bridge import get_memory_bridge

class MemoryService:
    """记忆系统服务类"""
    
    def __init__(self):
        self.memory = get_memory_bridge()
    
    def remember(self, content, importance="medium", topics=None):
        """记住信息"""
        return self.memory.remember(content, importance, topics)
    
    def recall(self, query, limit=10):
        """检索记忆"""
        return self.memory.recall(query, limit)
    
    def build_context(self, query, max_tokens=800):
        """构建上下文"""
        return self.memory.build_context(query, max_tokens)
    
    def get_persona(self):
        """获取人格画像"""
        return self.memory.get_persona()

# 全局服务实例
memory_service = MemoryService()

def get_memory_service():
    """获取记忆服务实例"""
    return memory_service
```

**在OpenClaw中使用**：

```python
# 导入服务
from plugins.agent_memory.agent_memory_service import get_memory_service

# 获取服务实例
memory_service = get_memory_service()

# 使用服务
memory_service.remember("用户的消息")
memories = memory_service.recall("查询内容")
context = memory_service.build_context("查询内容")
```

### 3. 测试验证

**测试记忆系统**：

```bash
cd /home/admin/.openclaw/plugins/agent_memory
python -c "
from memory_bridge import get_memory_bridge
m = get_memory_bridge()
print('✅ 记忆系统连接成功')
r = m.remember('测试记忆')
print('写入结果:', r)
r2 = m.recall('测试')
print('检索结果:', r2)
m.close()
"
```

**测试服务**：

```bash
cd /home/admin/.openclaw/plugins/agent_memory
python -c "
from agent_memory_service import get_memory_service
service = get_memory_service()
print('✅ 记忆服务连接成功')
r = service.remember('测试服务')
print('写入结果:', r)
r2 = service.recall('测试')
print('检索结果:', r2)
"
```

## 配置选项

### 记忆系统配置

**在 `memory_bridge.py` 中可以调整**：

```python
self.memory = AgentMemory(
    db_path=db_path,            # 数据库路径
    project_dir=str(plugin_dir / "config"),  # 配置目录
    enable_semantic=True,       # 启用语义搜索
    enable_filter=True,         # 启用过滤
    enable_dedup=True,          # 启用去重
    embedding_model="BAAI/bge-small-zh-v1.5"  # 嵌入模型
)
```

### 性能优化

**异步处理**：
```python
import asyncio

async def async_remember(self, content, importance="medium"):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, self.remember, content, importance)
```

**缓存机制**：
```python
import threading

class RecallCache:
    def __init__(self, maxsize=100):
        self._cache = {}
        self._lock = threading.Lock()
        self._maxsize = maxsize

    def get_or_compute(self, key, compute_fn):
        with self._lock:
            if key in self._cache:
                return self._cache[key]
        result = compute_fn()
        with self._lock:
            if len(self._cache) >= self._maxsize:
                self._cache.pop(next(iter(self._cache)))
            self._cache[key] = result
        return result

cache = RecallCache(maxsize=100)

def cached_recall(self, query, limit=10):
    return cache.get_or_compute((query, limit), lambda: self.recall(query, limit))
```

## 常见问题

### 1. 依赖安装失败

**解决方法**：
```bash
# 安装依赖
pip install --upgrade pip
pip install sqlite-vec sentence-transformers FlagEmbedding

# 如果sqlite-vec安装失败
pip install sqlite-vec --no-binary :all:
```

### 2. 内存不足

**解决方法**：
- 禁用语义搜索：`enable_semantic=False`
- 减少检索限制：`limit=5`
- 增加服务器内存

### 3. 路径问题

**解决方法**：
- 确保插件目录路径正确
- 检查文件权限

## 高级功能

### 1. 个人风格Agent

```python
# 列出所有角色
roles = memory_service.list_roles()
print('可用角色:', roles)

# 应用角色风格
style = memory_service.apply_role('tech_expert', weight=0.4)
print('技术专家风格:', style)
```

### 2. 人格画像

```python
# 构建人格画像
persona = memory_service.build_persona()
print('人格画像:', persona)

# 获取人格画像
persona = memory_service.get_persona()
print('当前人格画像:', persona)
```

## 总结

- ✅ 记忆系统已成功安装到OpenClaw
- ✅ 提供了两种集成方式：直接使用和服务方式
- ✅ 支持记忆写入、检索、上下文构建等核心功能
- ✅ 支持个人风格Agent、人格画像等高级功能

现在您可以开始在OpenClaw中使用记忆系统了！