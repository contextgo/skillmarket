"""
OpenClaw Memory Bridge
桥接模块 - 将记忆系统与OpenClaw协同工作
自动检测网络，智能降级，支持智能修正检测
集成投喂模式、欢迎引导和OpenClaw集成

⚠️ 安全: smart_memory 模块为可选扩展，默认禁用。
仅当 smart_memory.py 存在于插件目录时才启用智能触发功能。
"""

import sys
import logging
import socket
from pathlib import Path

logger = logging.getLogger(__name__)

plugin_dir = Path(__file__).parent
sys.path.insert(0, str(plugin_dir))

def check_network_accessibility():
    """检查网络连接检查"""
    try:
        # 先尝试DNS解析
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except Exception:
        try:
            # 再尝试HTTP连接
            import urllib.request
            urllib.request.urlopen("https://huggingface.co", timeout=3)
            return True
        except Exception:
            return False

class MemoryBridge:
    """
    记忆系统桥接类
    用于连接OpenClaw的Agent和记忆系统
    自动检测网络，智能降级
    支持智能修正检测（信号词 + 相似度）
    """

    def __init__(self, db_path=None, openclaw_llm=None):
        """
        初始化桥接模块
        :param db_path: 数据库路径，默认在插件data目录下
        :param openclaw_llm: OpenClaw的LLM实例（如果提供）
        """
        if db_path is None:
            data_dir = plugin_dir / "data"
            data_dir.mkdir(exist_ok=True)
            db_path = str(data_dir / "memory.db")

        # 检测网络
        has_network = check_network_accessibility()
        print(f"🔍 网络检测: {'✅ 可联网' if has_network else '❌ 离线模式'}")

        # 选择模式
        enable_semantic = has_network

        # 初始化
        from memory_system import AgentMemory
        self.memory = AgentMemory(
            db_path=db_path,
            project_dir=str(plugin_dir / "config"),
            enable_semantic=enable_semantic,
            enable_filter=True,
            enable_dedup=True
        )

        # 初始化修正检测器
        try:
            from correction_detector import create_detector
            self.correction_detector = create_detector(
                embedding_store=self.memory.embedding_store if enable_semantic else None
            )
        except ImportError:
            logger.warning("correction_detector module not found, correction detection disabled")
            self.correction_detector = None

        # 初始化智能模块（可选，默认禁用）
        # smart_memory.py 不包含在核心分发中，需单独安装
        self.smart_trigger = None
        try:
            from smart_memory import create_smart_trigger
            self.smart_trigger = create_smart_trigger(self)
        except ImportError:
            logger.info("smart_memory module not found, smart trigger disabled (this is normal)")

        from feeding_mode import create_feeding_mode
        self.feeding_mode = create_feeding_mode(self)

        from welcome_guide import create_welcome_guide
        self.welcome_guide = create_welcome_guide(self)

        from openclaw_integration import create_openclaw_integration
        self.openclaw_integration = create_openclaw_integration(self, openclaw_llm=openclaw_llm)

        from smart_config import create_smart_config
        self.config = create_smart_config()

        # v8.2: 统一记忆适配层 + 双写协调器
        try:
            from memory_adapter import MemoryAdapter
            self.memory_adapter = MemoryAdapter()
        except ImportError:
            self.memory_adapter = None

        try:
            from sync_coordinator import SyncCoordinator
            self.sync_coordinator = SyncCoordinator(self.memory)
        except ImportError:
            self.sync_coordinator = None

        # 检查是否首次使用
        self.is_first_time = self.welcome_guide.is_first_time()

        # 初始化媒体处理器
        try:
            from media_processor import MediaProcessor
            self.media_processor = MediaProcessor.auto(openclaw_llm=openclaw_llm)
            print("✅ 媒体处理器初始化成功")
        except Exception as e:
            print(f"⚠️ 媒体处理器初始化失败: {e}")
            self.media_processor = None

    def remember(self, content, importance="medium", topics=None, auto_detect_correction=True):
        """
        记住信息，支持自动修正检测

        Args:
            content: 记忆内容
            importance: 重要度
            topics: 主题列表
            auto_detect_correction: 是否自动检测修正

        Returns:
            写入结果 + 修正检测结果
        """
        result = {
            "memory_result": None,
            "correction_detection": None,
        }

        # 检测修正
        if auto_detect_correction and self.correction_detector:
            # 获取最近几条记忆
            recent_memories = self.get_recent_memories(limit=5, time_window_seconds=300)

            # 智能检测修正
            correction_result = self.correction_detector.smart_detect(
                new_text=content,
                recent_memories=recent_memories,
                time_window_seconds=300
            )

            result["correction_detection"] = correction_result

            # 如果检测到修正，执行相应行动
            if correction_result["is_correction"] and correction_result["suggested_action"] == "mark_retracted":
                self.correction_detector.process_correction(
                    self.memory.store, correction_result
                )

        # 写入记忆
        memory_result = self.memory.remember(
            content=content,
            importance=importance,
            topics=topics
        )
        result["memory_result"] = memory_result

        # 智能触发检测（仅在 smart_memory 模块可用且启用时）
        if self.smart_trigger and self.config.get("smart_memory.enabled", False):
            trigger_result = self.smart_trigger.on_message(content)
            if trigger_result.get("triggers"):
                result["triggers"] = trigger_result["triggers"]

        return result
    
    def get_recent_memories(self, limit: int = 5, time_window_seconds: int = 300):
        """
        获取最近的记忆

        Args:
            limit: 返回条数
            time_window_seconds: 时间窗口（秒）

        Returns:
            最近记忆列表
        """
        import time
        time_from = int(time.time()) - time_window_seconds
        result = self.memory.recall(time_from=time_from, limit=limit)
        return result.get("primary", [])

    def recall(self, query, limit=10, time_from=None, time_to=None):
        """
        检索记忆

        Args:
            query: 查询内容
            limit: 返回条数
            time_from: 开始时间戳
            time_to: 结束时间戳

        Returns:
            检索结果
        """
        return self.memory.recall(query=query, limit=limit, time_from=time_from, time_to=time_to)
    
    def build_context(self, query, max_tokens=800):
        """
        构建上下文
        :param query: 查询内容
        :param max_tokens: 最大token数
        :return: 上下文字符串
        """
        return self.memory.build_context(query=query, max_tokens=max_tokens)
    
    def get_persona(self):
        """获取人格画像"""
        return self.memory.get_persona()
    
    def build_persona(self):
        """构建人格画像"""
        return self.memory.build_persona()
    
    def apply_role(self, role_id, weight=0.4):
        """应用角色风格"""
        return self.memory.apply_role(role_id, weight)
    
    def list_roles(self):
        """列出所有角色"""
        return self.memory.list_roles()
    
    def try_recover_from_fallback(self) -> bool:
        """
        尝试从降级状态恢复到正常状态
        
        当之前因为网络或依赖问题降级时，
        可以调用此方法尝试重新恢复功能
        
        Returns:
            bool: 是否成功恢复
        """
        try:
            # 尝试恢复embedding
            if hasattr(self.memory, 'embedding_store') and self.memory.embedding_store:
                embedding_recovered = self.memory.embedding_store.try_recover_from_fallback()
            else:
                embedding_recovered = False
            
            # 可以添加其他恢复逻辑
            
            return embedding_recovered
        except Exception as e:
            print(f"恢复失败: {e}")
            return False

    # 智能触发相关方法
    def process_message(self, user_message: str, agent_response: str = None):
        """处理消息，触发智能操作（需 smart_memory 模块）"""
        if not self.smart_trigger:
            return {"triggers": [], "error": "smart_memory module not available"}
        return self.smart_trigger.on_message(user_message, agent_response)

    def start_recording(self):
        """开始记录对话（需 smart_memory 模块）"""
        if not self.smart_trigger:
            return {"error": "smart_memory module not available"}
        return self.smart_trigger.start_recording()

    def stop_recording(self):
        """停止记录对话（需 smart_memory 模块）"""
        if not self.smart_trigger:
            return {"error": "smart_memory module not available"}
        return self.smart_trigger.stop_recording()

    def summarize_conversation(self):
        """总结对话内容（需 smart_memory 模块）"""
        if not self.smart_trigger:
            return {"error": "smart_memory module not available"}
        return self.smart_trigger.summarize_conversation()

    def save_conversation(self):
        """保存对话内容（需 smart_memory 模块）"""
        if not self.smart_trigger:
            return {"error": "smart_memory module not available"}
        return self.smart_trigger.save_conversation()

    # 投喂模式相关方法
    def start_feeding_mode(self):
        """
        开始投喂模式

        Returns:
            dict: 操作结果
        """
        return self.feeding_mode.start()

    def feed(self, content: str, content_type: str = "text"):
        """
        投喂内容

        Args:
            content: 投喂的内容
            content_type: 内容类型 (text, file, url)

        Returns:
            dict: 投喂结果
        """
        return self.feeding_mode.feed(content, content_type)

    def check_feeding_inactivity(self):
        """
        检查投喂模式是否长时间无活动

        Returns:
            dict: 活动检查结果
        """
        return self.feeding_mode.check_inactivity()

    def end_feeding_mode(self):
        """
        结束投喂模式

        Returns:
            dict: 操作结果
        """
        return self.feeding_mode.end()

    def get_feeding_status(self):
        """
        获取投喂模式状态

        Returns:
            dict: 状态信息
        """
        return self.feeding_mode.get_status()

    # 欢迎引导相关方法
    def start_welcome_guide(self):
        """
        开始欢迎引导

        Returns:
            dict: 引导内容
        """
        return self.welcome_guide.start_guide()

    def get_help(self):
        """
        获取帮助信息

        Returns:
            dict: 帮助内容
        """
        return self.welcome_guide.get_help()

    def get_about(self):
        """
        获取系统信息

        Returns:
            dict: 系统信息
        """
        return self.welcome_guide.get_about()

    def is_first_time_use(self):
        """
        检查是否首次使用

        Returns:
            bool: 是否首次使用
        """
        return self.is_first_time

    # OpenClaw集成相关方法
    def connect_openclaw(self, openclaw_api):
        """
        连接OpenClaw

        Args:
            openclaw_api: OpenClaw API实例

        Returns:
            dict: 连接结果
        """
        return self.openclaw_integration.connect(openclaw_api)

    def sync_memory(self):
        """
        同步记忆（通过协调器，防止双写和循环同步）

        Returns:
            dict: 同步结果
        """
        if self.sync_coordinator:
            return self.openclaw_integration.sync_memory(coordinator=self.sync_coordinator)
        return self.openclaw_integration.sync_memory()

    def write_from_source(self, data: dict, source: str = "openclaw") -> dict:
        """从外部系统写入记忆（通过适配层 + 协调器，防止双写）。

        Args:
            data: 外部系统的原始记忆数据
            source: 来源系统 (openclaw/hermes)

        Returns:
            dict: 写入结果
        """
        if self.sync_coordinator:
            return self.sync_coordinator.write_from_source(
                data, source, adapter=self.memory_adapter
            )

        if self.memory_adapter:
            return self.memory_adapter.write(self.memory, data, source=source)

        return self.remember(data.get("content", data.get("text", data.get("message", ""))),
                             importance=data.get("importance", "medium"))

    def sync_from_hermes(self, memories: list) -> dict:
        """从 Hermes Agent 批量同步记忆。

        Args:
            memories: Hermes 格式的记忆列表

        Returns:
            dict: 同步统计
        """
        if self.sync_coordinator:
            return self.sync_coordinator.sync_from_external(
                memories, source="hermes", adapter=self.memory_adapter
            )

        stats = {"total": len(memories), "written": 0, "skipped": 0, "errors": 0}
        for mem in memories:
            try:
                result = self.write_from_source(mem, source="hermes")
                if result.get("written"):
                    stats["written"] += 1
                else:
                    stats["skipped"] += 1
            except Exception:
                stats["errors"] += 1
        return stats

    def get_combined_memory(self, query: str, limit: int = 10):
        """
        获取合并的记忆

        Args:
            query: 查询内容
            limit: 返回条数

        Returns:
            dict: 合并的记忆结果
        """
        return self.openclaw_integration.get_combined_memory(query, limit)

    def enable_sync(self, enabled: bool):
        """
        启用或禁用同步

        Args:
            enabled: 是否启用
        """
        self.openclaw_integration.enable_sync(enabled)

    def get_integration_status(self):
        """
        获取集成状态

        Returns:
            dict: 状态信息
        """
        return self.openclaw_integration.get_status()

    # 配置相关方法
    def get_config(self, key: str, default=None):
        """
        获取配置

        Args:
            key: 配置键
            default: 默认值

        Returns:
            Any: 配置值
        """
        return self.config.get(key, default)

    def set_config(self, key: str, value):
        """
        设置配置

        Args:
            key: 配置键
            value: 配置值
        """
        self.config.set(key, value)

    def enable_feature(self, feature: str):
        """
        启用功能

        Args:
            feature: 功能名称
        """
        self.config.enable(feature)

    def disable_feature(self, feature: str):
        """
        禁用功能

        Args:
            feature: 功能名称
        """
        self.config.disable(feature)

    def get_all_config(self):
        """
        获取所有配置

        Returns:
            dict: 所有配置
        """
        return self.config.get_all()

    def reset_config(self):
        """
        重置配置
        """
        self.config.reset()

    def close(self):
        """关闭资源"""
        if self.memory:
            self.memory.close()

# 全局单例
_memory_bridge = None

def get_memory_bridge():
    """获取记忆桥接单例"""
    global _memory_bridge
    if _memory_bridge is None:
        _memory_bridge = MemoryBridge()
    return _memory_bridge