"""
记忆系统服务
为OpenClaw提供记忆功能
"""

import sys
from pathlib import Path

# 添加插件目录到路径
plugin_dir = Path(__file__).parent
sys.path.insert(0, str(plugin_dir))

from memory_bridge import get_memory_bridge

class MemoryService:
    """记忆系统服务类"""
    
    def __init__(self):
        """初始化记忆服务"""
        self.memory = get_memory_bridge()
    
    def remember(self, content, importance="medium", topics=None):
        """记住信息
        
        Args:
            content: 记忆内容
            importance: 重要度 (high/medium/low)
            topics: 主题列表
            
        Returns:
            写入结果字典
        """
        return self.memory.remember(content, importance, topics)
    
    def recall(self, query, limit=10):
        """检索记忆
        
        Args:
            query: 查询内容
            limit: 返回条数
            
        Returns:
            检索结果列表
        """
        return self.memory.recall(query, limit)
    
    def build_context(self, query, max_tokens=800):
        """构建上下文
        
        Args:
            query: 查询内容
            max_tokens: 最大token数
            
        Returns:
            上下文字符串
        """
        return self.memory.build_context(query, max_tokens)
    
    def get_persona(self):
        """获取人格画像
        
        Returns:
            人格画像字典
        """
        return self.memory.get_persona()
    
    def build_persona(self):
        """构建人格画像
        
        Returns:
            人格画像字典
        """
        return self.memory.build_persona()
    
    def apply_role(self, role_id, weight=0.4):
        """应用角色风格
        
        Args:
            role_id: 角色ID
            weight: 角色权重 (0-1)
            
        Returns:
            风格混合结果
        """
        return self.memory.apply_role(role_id, weight)
    
    def list_roles(self):
        """列出所有角色
        
        Returns:
            角色列表
        """
        return self.memory.list_roles()
    
    def close(self):
        """关闭资源"""
        if self.memory:
            self.memory.close()

# 全局服务实例
memory_service = MemoryService()

def get_memory_service():
    """获取记忆服务实例
    
    Returns:
        MemoryService实例
    """
    return memory_service
