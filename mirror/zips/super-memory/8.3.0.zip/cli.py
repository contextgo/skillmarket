#!/usr/bin/env python3
"""
cli.py — Agent Memory System CLI
供 OpenClaw Agent 通过 exec 调用
"""

import sys
import os
import json
import time
import argparse
import logging
from datetime import datetime

# 抑制库级别的 logger 输出，避免污染 CLI JSON 输出
logging.basicConfig(level=logging.CRITICAL)
for name in ["huggingface_hub", "urllib3", "sentence_transformers", "chromadb"]:
    logging.getLogger(name).setLevel(logging.CRITICAL)

# 项目目录
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_DIR)

DB_PATH = os.path.join(PROJECT_DIR, "memory.db")
_MODEL_SERVER_WARNED = False


def _check_model_server():
    """检测 model_server 是否在运行，未运行则自动启动"""
    global _MODEL_SERVER_WARNED
    if _MODEL_SERVER_WARNED:
        return
    _MODEL_SERVER_WARNED = True

    # 只有 local 后端需要守护进程（hash/openai/cohere/voyage 不需要）
    backend = os.environ.get("AGENT_MEMORY_EMBEDDING_BACKEND", "local").lower()
    if backend != "local":
        return

    # 检查守护进程是否已经在运行
    try:
        from model_server import is_running
        if is_running():
            return  # 已在线，直接返回
    except Exception:
        pass

    # 自动启动守护进程
    try:
        print("⏳ 模型守护进程未启动，正在后台加载模型...", file=sys.stderr, flush=True)
        from model_server import start_server
        start_server(daemon=True)
        print("✅ 模型守护进程已启动", file=sys.stderr, flush=True)
    except Exception as e:
        print(
            f"⚠️  守护进程启动失败 ({e})，回退到冷启动模式（首次操作约 10-15s）。\n"
            f"   手动启动: python3 {os.path.join(PROJECT_DIR, 'model_server.py')} start",
            file=sys.stderr,
        )


def get_memory():
    """获取 AgentMemory 实例"""
    from memory_system import AgentMemory
    return AgentMemory(
        db_path=DB_PATH,
        project_dir=PROJECT_DIR,
        enable_semantic=True,
    )


def cmd_remember(args):
    """写入记忆"""
    mem = get_memory()
    result = mem.remember(
        content=args.content,
        importance=args.importance,
        topics=args.topics.split(",") if args.topics else None,
        nature=args.nature,
        force=args.force,
        auto_write=not args.review,
    )

    # 输出情感分析结果（写入成功时）
    if result.get("written") and result.get("emotion"):
        emotion = result["emotion"]
        if isinstance(emotion, dict) and emotion.get("significance"):
            from emotion import EmotionAnalyzer as _EA
            sig_icon = _EA.significance_icon(emotion.get("significance", ""))
            val_label = _EA.valence_label(emotion.get("valence", 0))
            result["emotion_display"] = f"{sig_icon} {val_label}"

    print(json.dumps(result, ensure_ascii=False, indent=2))
    mem.close()


def cmd_recall(args):
    """检索记忆"""
    mem = get_memory()
    result = mem.recall(
        query=args.query,
        topic=args.topic,
        importance=args.importance,
        significance=args.significance,
        limit=args.limit,
    )
    # 简化输出（含情感信号）
    output = {
        "total": result["total"],
        "mode": result["search_mode"],
        "memories": [
            {
                "id": m["memory_id"],
                "content": m["content"][:200],
                "importance": m.get("importance", "medium"),
                "topics": [t.get("code", t) if isinstance(t, dict) else t for t in m.get("topics", [])],
                "emotion": {
                    "significance": m.get("significance", ""),
                    "significance_icon": m.get("_significance_icon", ""),
                    "valence": m.get("valence"),
                    "valence_label": m.get("_valence_label", ""),
                } if m.get("significance") else None,
            }
            for m in result.get("primary", [])[:args.limit]
        ],
    }
    print(json.dumps(output, ensure_ascii=False, indent=2))
    mem.close()


def cmd_context(args):
    """组装上下文"""
    mem = get_memory()
    ctx = mem.build_context(
        query=args.query,
        max_tokens=args.max_tokens,
        style=args.style,
    )
    if ctx:
        print(ctx)
    else:
        print("（无相关记忆）")
    mem.close()


def cmd_stats(args):
    """查看统计"""
    mem = get_memory()
    stats = mem.get_stats()
    print(json.dumps(stats, ensure_ascii=False, indent=2, default=str))
    mem.close()


def cmd_maintain(args):
    """执行维护"""
    mem = get_memory()
    results = {}

    # 去重
    dedup_result = mem.deduplicate()
    results["dedup"] = {
        "scanned": dedup_result.get("total_scanned", 0),
        "found": dedup_result.get("duplicates_found", 0),
    }

    # 自修复
    heal_result = mem.self_heal()
    results["self_heal"] = {
        "contradictions": len(heal_result.get("contradictions", [])),
        "outdated": len(heal_result.get("outdated", [])),
        "healed": heal_result.get("importance_healed", 0),
        "total": heal_result.get("total_issues", 0),
    }

    # 衰减分析
    decay_result = mem.analyze_decay()
    results["decay"] = {
        "total": decay_result.get("total", 0),
        "needs_action": len(decay_result.get("needs_action", [])),
        "summary": decay_result.get("summary", ""),
    }

    print(json.dumps(results, ensure_ascii=False, indent=2))
    mem.close()


def cmd_compress(args):
    """压缩记忆"""
    mem = get_memory()
    result = mem.compress(topic=args.topic, smart=True)
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    mem.close()


def cmd_graph(args):
    """生成图谱"""
    mem = get_memory()
    graph = mem.generate_graph(topic=args.topic, format=args.format)
    print(graph)
    mem.close()


def cmd_feedback(args):
    """记录反馈"""
    mem = get_memory()
    mem.feedback(args.memory_id, useful=args.useful, note=args.note)
    print(json.dumps({"ok": True}, ensure_ascii=False))
    mem.close()


def cmd_forget(args):
    """删除单条记忆（含关联清理 + 向量清理）"""
    mem = get_memory()
    result = mem.store.delete_memory(args.memory_id, reason=args.reason or "user_delete")
    if result.get("deleted"):
        print(f"🗑️  记忆已删除: {args.memory_id}")
        if args.reason:
            print(f"   原因: {args.reason}")
    else:
        print(f"❌ 记忆不存在: {args.memory_id}")
    mem.close()


def cmd_flush(args):
    """L1 沉淀到 L2"""
    mem = get_memory()
    from pipeline import IngestPipeline
    pipeline = IngestPipeline(
        mem.store, mem.encoder,
        index_dir=os.path.join(PROJECT_DIR, "daily_index"),
    )
    result = mem.flush_session()
    print(json.dumps({"flushed": len(result)}, ensure_ascii=False))
    mem.close()


def cmd_heal(args):
    """自我修复"""
    mem = get_memory()
    result = mem.self_heal()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    mem.close()


def cmd_sync(args):
    """从 MEMORY.md 或其他 Markdown 文件同步记忆"""
    mem = get_memory()
    source = args.source
    if not os.path.exists(source):
        print(json.dumps({"error": f"文件不存在: {source}"}, ensure_ascii=False))
        sys.exit(1)

    with open(source, "r", encoding="utf-8") as f:
        content = f.read()

    # 按 ## 标题分割段落
    import re
    sections = re.split(r'\n(?=##\s)', content)
    written = 0
    skipped = 0
    errors = []

    for section in sections:
        section = section.strip()
        if not section or len(section) < 20:
            continue

        # 提取标题（如果有）
        title_match = re.match(r'^##\s+(.+)', section)
        title = title_match.group(1).strip() if title_match else ""

        # 推断重要度
        importance = "medium"
        if any(kw in section.lower() for kw in ["重要", "关键", "核心", "必须", "注意", "⚠️", "❗"]):
            importance = "high"
        elif any(kw in section.lower() for kw in ["临时", "草稿", "随便", "可以忽略"]):
            importance = "low"

        # 推断性质
        nature = None
        if any(kw in section for kw in ["TODO", "待办", "要做", "计划"]):
            nature = "todo"
        elif any(kw in section for kw in ["决定", "选择", "结论"]):
            nature = "note"
        elif any(kw in section for kw in ["教训", "踩坑", "错误"]):
            nature = "note"
        elif title:
            nature = "note"

        # 写入
        try:
            result = mem.remember(
                content=section,
                importance=importance,
                nature=nature,
                force=args.force,
            )
            if result["written"]:
                written += 1
            else:
                skipped += 1
        except Exception as e:
            errors.append({"section": title or section[:30], "error": str(e)})

    output = {
        "source": source,
        "total_sections": len([s for s in sections if len(s.strip()) >= 20]),
        "written": written,
        "skipped": skipped,
        "errors": len(errors),
    }
    if errors:
        output["error_details"] = errors[:5]
    print(json.dumps(output, ensure_ascii=False, indent=2))
    mem.close()


def cmd_auto_context(args):
    """自动组装上下文 — 根据最近对话智能检索 + 摘要"""
    mem = get_memory()
    ctx = mem.build_context(
        query=args.query,
        max_tokens=args.max_tokens,
        style=args.style,
    )
    if ctx:
        print(ctx)
    else:
        print("（记忆系统：暂无相关记忆）")
    mem.close()


def cmd_export(args):
    """导出记忆为 Markdown"""
    mem = get_memory()
    memories = mem.store.query(
        topic_path=args.topic,
        importance=args.importance,
        limit=args.limit,
    )

    lines = [
        f"# 记忆导出",
        f"",
        f"导出时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"共 {len(memories)} 条记忆",
        f"",
    ]

    # 按重要度分组
    by_importance = {"high": [], "medium": [], "low": []}
    for m in memories:
        imp = m.get("importance", "medium")
        by_importance.get(imp, by_importance["medium"]).append(m)

    icon_map = {"high": "⚡", "medium": "", "low": "🔻"}
    for imp in ["high", "medium", "low"]:
        mems = by_importance[imp]
        if not mems:
            continue
        lines.append(f"## {icon_map[imp]} {imp} ({len(mems)}条)")
        lines.append("")
        for m in mems:
            from datetime import datetime
            dt = datetime.fromtimestamp(m.get("time_ts", 0)).strftime("%Y-%m-%d %H:%M")
            content = m.get("content", "")
            mid = m.get("memory_id", "")
            lines.append(f"### [{dt}] {content[:50]}")
            lines.append(f"")
            lines.append(content)
            lines.append(f"")
            lines.append(f"> ID: `{mid}`")
            lines.append("")

    with open(args.output, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(json.dumps({"exported": len(memories), "file": args.output}, ensure_ascii=False))
    mem.close()


def cmd_notifications(args):
    """查看待处理的主动通知"""
    mem = get_memory()
    notifications = mem.get_pending_notifications()
    result = {
        "total": len(notifications),
        "notifications": notifications,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    mem.close()


def cmd_reactor_scan(args):
    """手动触发 reactor 全量扫描"""
    mem = get_memory()
    result = mem.reactor_scan()
    # 简化输出
    output = {
        "total_actions": result["total_actions"],
        "contradictions_triggered": len(result["contradictions"]),
        "decay_reviews_triggered": len(result["decay_reviews"]),
        "decisions_triggered": len(result["decisions"]),
        "action_details": [
            {"action": r.action_name, "success": r.success, "message": r.message}
            for r in result["contradictions"] + result["decay_reviews"] + result["decisions"]
        ],
        "stats": result["stats"],
    }
    print(json.dumps(output, ensure_ascii=False, indent=2))
    mem.close()


# ── v5.3: 蒸馏命令 ──────────────────────────────────────


def cmd_distill(args):
    """执行记忆蒸馏"""
    mem = get_memory()
    result = mem.distill(force=args.force)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    mem.close()


def cmd_distill_stats(args):
    """查看蒸馏系统统计"""
    mem = get_memory()
    stats = mem.get_distill_stats()
    print(json.dumps(stats, ensure_ascii=False, indent=2))
    mem.close()


def cmd_encyclopedia(args):
    """查看/搜索/导出个人百科"""
    mem = get_memory()

    if args.export:
        path = mem.export_encyclopedia(args.export)
        print(json.dumps({"exported": path}, ensure_ascii=False, indent=2))
    elif args.search:
        results = mem.search_encyclopedia(args.search)
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        entries = mem.get_encyclopedia(category=args.category)
        output = []
        for e in entries:
            output.append({
                "id": e["entry_id"],
                "title": e["title"],
                "category": e["category"],
                "preview": e["content"][:300],
            })
        print(json.dumps(output, ensure_ascii=False, indent=2))

    mem.close()


def cmd_entities(args):
    """查看知识实体"""
    mem = get_memory()
    entities = mem.distiller.get_entities(
        entity_type=args.type,
        name_like=args.name,
    )
    output = []
    for e in entities:
        attrs = json.loads(e.get("attributes", "{}"))
        output.append({
            "id": e["entity_id"],
            "name": e["name"],
            "type": e["entity_type"],
            "importance": e.get("importance", "medium"),
            "attributes": attrs,
        })
    print(json.dumps(output, ensure_ascii=False, indent=2))
    mem.close()


def cmd_topic_summaries(args):
    """查看主题摘要"""
    mem = get_memory()
    summaries = mem.distiller.get_topic_summaries(topic_code=args.topic)
    output = []
    for s in summaries:
        output.append({
            "id": s["topic_id"],
            "topic": s["topic_code"],
            "summary": s["summary"][:500],
            "source_count": s.get("source_count", 0),
            "importance": s.get("importance", "medium"),
        })
    print(json.dumps(output, ensure_ascii=False, indent=2))
    mem.close()


def cmd_conflicts(args):
    """检测记忆冲突"""
    mem = get_memory()
    if not mem.dedup:
        print(json.dumps({"error": "dedup not enabled"}, ensure_ascii=False))
        mem.close()
        return

    # 扫描所有记忆，找冲突对
    all_mems = mem.store.query(limit=500)
    conflicts = []
    checked = set()

    for i, m1 in enumerate(all_mems):
        for m2 in all_mems[i+1:]:
            pair_key = f"{m1['memory_id']}_{m2['memory_id']}"
            if pair_key in checked:
                continue
            checked.add(pair_key)

            score = mem.dedup._text_similarity(m1["content"], m2["content"])
            if mem.dedup.CONFLICT_LOW <= score < mem.dedup.CONFLICT_HIGH:
                conflicts.append({
                    "memory_1": {"id": m1["memory_id"], "content": m1["content"][:60]},
                    "memory_2": {"id": m2["memory_id"], "content": m2["content"][:60]},
                    "similarity": round(score, 4),
                })

    conflicts.sort(key=lambda x: -x["similarity"])
    result = {
        "total_memories": len(all_mems),
        "conflicts_found": len(conflicts),
        "conflicts": conflicts[:20],
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    mem.close()


# ── v5.4: 时间旅行命令 ──────────────────────────────────


def cmd_snapshot(args):
    """创建记忆快照"""
    mem = get_memory()
    at_ts = None
    if args.at:
        from timeline import parse_date_to_ts
        try:
            at_ts = parse_date_to_ts(args.at)
        except ValueError as e:
            print(json.dumps({"error": str(e)}, ensure_ascii=False))
            mem.close()
            return
    result = mem.take_snapshot(
        label=args.label,
        at_ts=at_ts,
        description=args.description,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    mem.close()


def cmd_snapshots(args):
    """列出所有快照"""
    mem = get_memory()
    snapshots = mem.list_snapshots(limit=args.limit)
    output = []
    for s in snapshots:
        output.append({
            "id": s["snapshot_id"],
            "label": s["label"],
            "at": datetime.fromtimestamp(s["at_ts"]).strftime("%Y-%m-%d %H:%M"),
            "memories": s["memory_count"],
            "high": s["high_count"],
        })
    print(json.dumps(output, ensure_ascii=False, indent=2))
    mem.close()


def cmd_diff(args):
    """对比两个时间点的记忆差异"""
    mem = get_memory()
    from timeline import parse_date_to_ts

    from_ts = None
    to_ts = None

    # 解析时间
    if not args.from_snapshot:
        try:
            from_ts = parse_date_to_ts(args.from_date)
        except ValueError as e:
            print(json.dumps({"error": str(e)}, ensure_ascii=False))
            mem.close()
            return

    if not args.to_snapshot and args.to_date:
        try:
            to_ts = parse_date_to_ts(args.to_date)
        except ValueError as e:
            print(json.dumps({"error": str(e)}, ensure_ascii=False))
            mem.close()
            return

    if args.natural:
        output = mem.diff_natural(
            from_ts=from_ts, to_ts=to_ts,
            from_snapshot=args.from_snapshot, to_snapshot=args.to_snapshot,
        )
        print(output)
    else:
        result = mem.diff_memories(
            from_ts=from_ts, to_ts=to_ts,
            from_snapshot=args.from_snapshot, to_snapshot=args.to_snapshot,
            topic=args.topic,
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
    mem.close()


def cmd_blame(args):
    """追溯记忆来源"""
    mem = get_memory()
    if args.natural:
        output = mem.blame_natural(args.memory_id)
        print(output)
    else:
        result = mem.blame_memory(args.memory_id)
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    mem.close()


def cmd_timeline_stats(args):
    """时间旅行系统统计"""
    mem = get_memory()
    stats = mem.get_timeline_stats()
    print(json.dumps(stats, ensure_ascii=False, indent=2))
    mem.close()


# ── Phase 2: 自我指涉命令 ────────────────────────────────


def cmd_traces(args):
    """查看推理追踪历史"""
    mem = get_memory()
    traces = mem.self_model.get_traces(limit=args.limit, topic=args.topic)
    output = []
    for t in traces:
        dt = datetime.fromtimestamp(t.get("created_at", 0)).strftime("%Y-%m-%d %H:%M")
        conf = t.get("confidence", 0)
        steps = t.get("steps", [])
        sources = t.get("sources_used", [])
        uncertainty = t.get("uncertainty", [])
        output.append({
            "id": t["trace_id"],
            "time": dt,
            "query": t["query"][:80],
            "confidence": round(conf, 3),
            "steps": len(steps),
            "sources": len(sources),
            "uncertainty": uncertainty[:3],
            "summary": (t.get("result_summary") or "")[:100],
        })
    print(json.dumps(output, ensure_ascii=False, indent=2))
    mem.close()


def cmd_trace_log(args):
    """查看结构化追踪日志"""
    from trace_logger import get_tracer
    tracer = get_tracer()
    if args.clear:
        tracer.clear_logs()
        print(json.dumps({"status": "cleared"}))
        return
    logs = tracer.get_recent_traces(module=args.module, limit=args.limit)
    print(json.dumps(logs, ensure_ascii=False, indent=2))


def cmd_trace_detail(args):
    """查看单次推理的详细步骤"""
    mem = get_memory()
    traces = mem.self_model.get_traces(limit=200)
    target = None
    for t in traces:
        if t["trace_id"] == args.trace_id:
            target = t
            break
    if not target:
        print(json.dumps({"error": f"未找到追踪: {args.trace_id}"}, ensure_ascii=False))
        mem.close()
        return

    dt = datetime.fromtimestamp(target.get("created_at", 0)).strftime("%Y-%m-%d %H:%M:%S")
    print(f"🧠 推理追踪 {target['trace_id']}")
    print(f"   时间: {dt}")
    print(f"   查询: {target['query']}")
    print(f"   置信度: {target.get('confidence', 0):.3f}")
    print(f"   摘要: {target.get('result_summary', 'N/A')}")
    print()

    steps = target.get("steps", [])
    if steps:
        print(f"📝 推理步骤 ({len(steps)}):")
        for i, s in enumerate(steps):
            ts = datetime.fromtimestamp(s.get("timestamp", 0)).strftime("%H:%M:%S")
            print(f"   {i+1}. [{ts}] {s.get('step_type', '?')}: {s.get('detail', '')}")

    sources = target.get("sources_used", [])
    if sources:
        print(f"\n🔗 查阅的记忆 ({len(sources)}):")
        for sid in sources[:10]:
            print(f"   → {sid}")

    uncertainty = target.get("uncertainty", [])
    if uncertainty:
        print(f"\n❓ 不确定因素 ({len(uncertainty)}):")
        for u in uncertainty:
            print(f"   ⚠️ {u}")

    mem.close()


def cmd_confidence(args):
    """查看置信度历史/概览"""
    mem = get_memory()
    if args.overview:
        overview = mem.self_model.get_confidence_overview()
        print(json.dumps(overview, ensure_ascii=False, indent=2))
    else:
        history = mem.self_model.get_confidence_history(topic=args.topic, limit=args.limit)
        print(json.dumps(history, ensure_ascii=False, indent=2))
    mem.close()


def cmd_reflect(args):
    """查看自我反思历史"""
    mem = get_memory()
    reflections = mem.self_model.get_reflections(limit=args.limit)
    output = []
    for r in reflections:
        dt = datetime.fromtimestamp(r.get("created_at", 0)).strftime("%Y-%m-%d %H:%M")
        output.append({
            "id": r["reflection_id"],
            "time": dt,
            "insight": r["insight"][:100],
            "action": (r.get("action") or "")[:80],
        })
    print(json.dumps(output, ensure_ascii=False, indent=2))
    mem.close()


def cmd_uncertainty(args):
    """查看不确定因素模式分析"""
    mem = get_memory()
    patterns = mem.self_model.get_uncertainty_patterns(limit=args.limit)
    print(json.dumps(patterns, ensure_ascii=False, indent=2))
    mem.close()


# ── Phase 3: 元认知命令 ──────────────────────────────────


def cmd_meta_recall(args):
    """带反思的检索（不确定时自动修正查询重试）"""
    mem = get_memory()
    result = mem.meta_recall(
        query=args.query,
        limit=args.limit,
        max_rounds=args.max_rounds,
    )
    # 简化输出
    output = {
        "rounds": result["rounds"],
        "final_count": len(result["results"]),
        "evaluation": result.get("evaluation", {}),
        "reflections": [
            {
                "round": r.get("round", 0),
                "confidence": r.get("confidence", 0),
                "insight": r.get("reflection_text", "")[:100],
                "revised_query": r.get("revised_queries", [None])[0],
            }
            for r in result.get("reflections", [])
        ],
        "memories": [
            {
                "id": m["memory_id"],
                "content": m["content"][:150],
                "importance": m.get("importance", "medium"),
            }
            for m in result["results"][:args.limit]
        ],
    }
    print(json.dumps(output, ensure_ascii=False, indent=2))
    mem.close()


def cmd_evaluate(args):
    """评估检索结果质量（多维度分析）"""
    mem = get_memory()
    evaluation = mem.evaluate_recall(query=args.query)
    print(json.dumps(evaluation, ensure_ascii=False, indent=2))
    mem.close()


# ── Phase 4: 内在动机命令 ────────────────────────────────


def cmd_mood(args):
    """查看 Agent 当前内在状态"""
    mem = get_memory()
    state = mem.motivation.state
    output = {
        "mood": state.mood_summary,
        "emoji": state.mood_emoji,
        "state": state.to_dict(),
        "dominant_drive": state.dominant_drive,
    }
    if args.detail:
        output["boredom_analysis"] = mem.motivation.compute_boredom_analysis()
        output["knowledge_gaps"] = len(mem.motivation.detect_knowledge_gaps())
    print(json.dumps(output, ensure_ascii=False, indent=2))
    mem.close()


def cmd_gaps(args):
    """查看知识空白"""
    mem = get_memory()
    gaps = mem.motivation.detect_knowledge_gaps()
    print(json.dumps(gaps, ensure_ascii=False, indent=2))
    mem.close()


def cmd_curious(args):
    """查看好奇驱动的探索任务"""
    mem = get_memory()
    tasks = mem.motivation.generate_curiosity_tasks()
    print(json.dumps(tasks, ensure_ascii=False, indent=2))
    mem.close()


# ── Phase 5: 叙事自我命令 ────────────────────────────────


def cmd_whoami(args):
    """我是谁 — 第一人称自我叙述"""
    mem = get_memory()
    print("⚠️  以下内容基于存储记忆生成，仅为近似摘要，不是事实或权威判断。")
    print(mem.narrative.whoami())
    mem.close()


def cmd_identity(args):
    """查看身份画像"""
    mem = get_memory()
    profile = mem.narrative.build_identity_profile()
    if args.raw:
        print(json.dumps(profile, ensure_ascii=False, indent=2))
    else:
        if profile.get("core_values"):
            print(f"核心价值观: {', '.join(profile['core_values'])}")
        if profile.get("expertise"):
            for e in profile["expertise"][:5]:
                print(f"  📚 {e['topic']} ({e['depth']}, {e['memory_count']}条)")
        if profile.get("personality_traits"):
            print(f"人格特质: {', '.join(profile['personality_traits'])}")
        if profile.get("interests"):
            print(f"兴趣: {', '.join(profile['interests'])}")
        if profile.get("preferences"):
            for k, v in profile["preferences"].items():
                print(f"  {k}: {v}")
        print(f"\n置信度: {profile.get('confidence', 0):.0%} (基于 {profile.get('evidence_count', 0)} 条记忆)")
    mem.close()


def cmd_narrative(args):
    """构建叙事（时间线/主题）"""
    mem = get_memory()
    if args.topic:
        result = mem.narrative.build_topic_narrative(args.topic, limit=args.limit)
        print(result)
    elif args.from_date:
        from timeline import parse_date_to_ts
        from_ts = parse_date_to_ts(args.from_date)
        to_ts = parse_date_to_ts(args.to_date) if args.to_date else None
        result = mem.narrative.build_timeline_narrative(from_ts=from_ts, to_ts=to_ts)
        print(result)
    else:
        # 默认：最近 7 天
        from_ts = int(time.time()) - 86400 * 7
        result = mem.narrative.build_timeline_narrative(from_ts=from_ts)
        print(result)
    mem.close()


def cmd_worldview(args):
    """查看世界观（信念/价值观/原则）"""
    mem = get_memory()
    worldview = mem.narrative.get_worldview()
    print(json.dumps(worldview, ensure_ascii=False, indent=2))
    mem.close()


def cmd_self_concept(args):
    """查看完整自我概念"""
    mem = get_memory()
    concept = mem.narrative.update_self_concept()
    print(json.dumps(concept, ensure_ascii=False, indent=2))
    mem.close()


def cmd_persona(args):
    """构建数字孪生人格画像"""
    mem = get_memory()
    print("⚠️  人格画像是基于记忆数据生成的统计摘要，不是对真实性格的权威描述。", file=sys.stderr)
    profile = mem.build_persona()
    print(json.dumps(profile, ensure_ascii=False, indent=2))
    mem.close()


def cmd_persona_get(args):
    """获取最新的数字孪生人格画像"""
    mem = get_memory()
    print("⚠️  人格画像是基于记忆数据生成的统计摘要，不是对真实性格的权威描述。", file=sys.stderr)
    profile = mem.get_persona()
    if profile:
        print(json.dumps(profile, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({"error": "尚未构建人格画像"}, ensure_ascii=False))
    mem.close()


# ── Phase 7: 个人风格 Agent 命令 ─────────────────────────


def cmd_roles(args):
    """列出所有可用的角色模板"""
    mem = get_memory()
    roles = mem.list_roles()
    print(json.dumps(roles, ensure_ascii=False, indent=2))
    mem.close()


def cmd_role_get(args):
    """获取特定角色模板"""
    mem = get_memory()
    role = mem.get_role(args.role_id)
    if role:
        print(json.dumps(role, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({"error": f"角色不存在: {args.role_id}"}, ensure_ascii=False))
    mem.close()


def cmd_role_apply(args):
    """应用角色风格到个人人格"""
    mem = get_memory()
    result = mem.apply_role(args.role_id, args.weight)
    if result:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({"error": f"角色不存在: {args.role_id}"}, ensure_ascii=False))
    mem.close()


def cmd_role_create(args):
    """创建新角色模板"""
    mem = get_memory()
    try:
        traits = json.loads(args.traits)
        topics = args.topics.split(",") if args.topics else None
        result = mem.create_role(
            role_id=args.role_id,
            name=args.name,
            prompt_template=args.prompt,
            personality_traits=traits,
            speaking_style=args.speaking_style,
            topic_preferences=topics,
            emotional_tone=args.emotional_tone
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except json.JSONDecodeError:
        print(json.dumps({"error": "人格特质 JSON 格式错误"}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False))
    mem.close()


def cmd_role_delete(args):
    """删除角色模板"""
    mem = get_memory()
    result = mem.delete_role(args.role_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    mem.close()


def cmd_role_from_media(args):
    """从媒体文件创建角色模板"""
    mem = get_memory()
    result = mem.create_role_from_media(args.file_path, args.name)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    mem.close()


# ── Phase 6: 统一自我入口 ────────────────────────────────


def cmd_self(args):
    """统一自我状态仪表盘"""
    mem = get_memory()

    if args.mood:
        state = mem.motivation.state
        print(f"{state.mood_emoji} 当前状态: {state.mood_summary}")
        print(f"   好奇心 {state.curiosity:.2f} | 无聊度 {state.boredom:.2f} | "
              f"自信度 {state.confidence:.2f} | 满足感 {state.satisfaction:.2f} | "
              f"紧迫感 {state.urgency:.2f}")
        print(f"   主导动机: {state.dominant_drive}")
    elif args.narrative:
        print(mem.narrative.whoami())
    elif args.confidence:
        overview = mem.self_model.get_confidence_overview()
        if overview:
            for topic, info in list(overview.items())[:8]:
                trend_icon = {"rising": "📈", "falling": "📉", "stable": "➡️"}.get(info["trend"], "❓")
                print(f"  {trend_icon} {topic}: {info['avg_confidence']:.2f} ({info['trace_count']}次)")
        else:
            print("（暂无置信度数据）")
    elif args.gaps:
        gaps = mem.motivation.detect_knowledge_gaps()
        if gaps:
            for g in gaps[:8]:
                print(f"  ❓ [{g['gap_type']}] {g['topic']}: {g['detail']}")
        else:
            print("（暂无知识空白）")
    elif args.recent_thinking:
        traces = mem.self_model.get_traces(limit=5)
        for t in traces:
            dt = datetime.fromtimestamp(t.get("created_at", 0)).strftime("%m-%d %H:%M")
            conf = t.get("confidence", 0)
            print(f"  🧠 [{dt}] conf={conf:.2f} {t['query'][:60]}")
    else:
        # 完整仪表盘
        print("=" * 50)
        print("🧠 自我状态仪表盘")
        print("=" * 50)

        # 身份
        profile = mem.narrative.build_identity_profile()
        if profile.get("core_values"):
            print(f"\n📌 价值观: {', '.join(profile['core_values'][:3])}")
        if profile.get("expertise"):
            top = profile["expertise"][0]
            print(f"📚 专长: {top['topic']} ({top['depth']})")

        # 内在状态
        state = mem.motivation.state
        print(f"\n{state.mood_emoji} 心情: {state.mood_summary}")
        print(f"   好奇={state.curiosity:.2f} 无聊={state.boredom:.2f} "
              f"自信={state.confidence:.2f} 满足={state.satisfaction:.2f}")

        # 知识空白
        gaps = mem.motivation.detect_knowledge_gaps()
        if gaps:
            print(f"\n❓ 待探索: {', '.join(g['topic'] for g in gaps[:3])}")

        # 最近推理
        traces = mem.self_model.get_traces(limit=3)
        if traces:
            avg_conf = sum(t.get("confidence", 0) for t in traces) / len(traces)
            print(f"\n🧠 最近推理: {len(traces)} 次, 平均置信度 {avg_conf:.2f}")

        # 统计
        sm_stats = mem.self_model.get_stats()
        print(f"\n📊 推理追踪: {sm_stats.get('traces', 0)} | 反思: {sm_stats.get('reflections', 0)}")

    mem.close()


def cmd_update(args):
    """更新记忆内容（版本化）"""
    mem = get_memory()
    topics = args.topics.split(",") if args.topics else None
    result = mem.store.update_memory(
        memory_id=args.memory_id,
        new_content=args.content,
        change_reason=args.reason,
        importance=args.importance,
        topics=topics,
    )
    if result.get("changed"):
        print(f"✅ 记忆已更新 → v{result['version']}")
        print(f"   原内容: {result['old_content'][:100]}{'...' if len(result['old_content']) > 100 else ''}")
        print(f"   新内容: {result['new_content'][:100]}{'...' if len(result['new_content']) > 100 else ''}")
        if result.get("reason"):
            print(f"   原因:   {result['reason']}")
    elif result.get("error"):
        print(f"❌ {result['error']}")
    else:
        print(f"ℹ️  {result.get('reason', '未变更')}")
    mem.close()


def cmd_versions(args):
    """查看记忆版本历史"""
    mem = get_memory()
    versions = mem.store.get_memory_versions(args.memory_id)
    if not versions:
        print(f"❌ 记忆不存在或无版本历史: {args.memory_id}")
        mem.close()
        return

    if args.as_json:
        print(json.dumps(versions, ensure_ascii=False, indent=2, default=str))
    else:
        mem_data = mem.store.get_memory(args.memory_id)
        print(f"📋 记忆 {args.memory_id} 的版本历史")
        if mem_data:
            topics = [t["code"] for t in mem_data.get("topics", [])]
            print(f"   当前主题: {', '.join(topics) if topics else '无'}")
        print(f"   共 {len(versions)} 个版本\n")

        for v in versions:
            marker = "→ " if v.get("is_current") else "  "
            ts = datetime.fromtimestamp(v["created_at"]).strftime("%Y-%m-%d %H:%M") if v.get("created_at") else "?"
            reason = v.get("change_reason", "")
            content_preview = v["content"][:80].replace("\n", " ")
            print(f"  {marker}v{v['version_id']} [{ts}] {reason}")
            print(f"     {content_preview}{'...' if len(v['content']) > 80 else ''}")
    mem.close()


def cmd_model_server(args):
    """管理模型守护进程"""
    from model_server import is_running, start_server, stop_server

    if args.action == "start":
        if is_running():
            print("✅ 模型守护进程已在运行")
        else:
            start_server(daemon=True)
            if is_running():
                print("✅ 模型守护进程已启动")
            else:
                print("❌ 守护进程启动失败")
    elif args.action == "stop":
        if not is_running():
            print("ℹ️  模型守护进程未运行")
        else:
            stop_server()
            print("✅ 模型守护进程已停止")
    elif args.action == "restart":
        if is_running():
            stop_server()
        start_server(daemon=True)
        if is_running():
            print("✅ 模型守护进程已重启")
        else:
            print("❌ 守护进程重启失败")
    elif args.action == "status":
        if is_running():
            from model_server import send_request
            resp = send_request({"action": "ping"}, timeout=2)
            model_name = resp.get("model", "unknown")
            print(f"✅ 运行中 — 模型: {model_name}")
        else:
            print("⛔ 未运行")


def main():
    parser = argparse.ArgumentParser(description="Agent Memory CLI")
    parser.add_argument("--trace", action="store_true", help="启用详细追踪日志（JSON Lines 格式）")
    parser.add_argument("--trace-module", default=None, help="只追踪指定模块（recall/maintain/metacognition）")
    sub = parser.add_subparsers(dest="command")

    # remember
    p = sub.add_parser("remember", help="写入记忆")
    p.add_argument("content", help="记忆内容")
    p.add_argument("--importance", "-i", default=None, help="high/medium/low")
    p.add_argument("--topics", "-t", default=None, help="主题列表（逗号分隔）")
    p.add_argument("--nature", "-n", default=None, help="性质 code")
    p.add_argument("--force", "-f", action="store_true", help="跳过过滤")
    p.add_argument("--review", action="store_true", help="审核模式：预览内容但不写入，需确认后再写入")

    # recall
    p = sub.add_parser("recall", help="检索记忆")
    p.add_argument("query", help="查询内容")
    p.add_argument("--topic", default=None, help="主题过滤")
    p.add_argument("--importance", default=None, help="重要度过滤")
    p.add_argument("--significance", default=None,
                    choices=["trivial", "notable", "important", "breakthrough", "crisis", "milestone"],
                    help="情感显著性过滤")
    p.add_argument("--limit", type=int, default=10, help="返回条数")

    # context
    p = sub.add_parser("context", help="组装上下文")
    p.add_argument("query", help="当前对话内容")
    p.add_argument("--max-tokens", type=int, default=1500, help="token 预算")
    p.add_argument("--style", default="structured", help="structured/narrative/compact/xml")

    # stats
    sub.add_parser("stats", help="查看统计")

    # maintain
    sub.add_parser("maintain", help="执行维护")

    # compress
    p = sub.add_parser("compress", help="压缩记忆")
    p.add_argument("--topic", default=None, help="指定主题")

    # graph
    p = sub.add_parser("graph", help="生成图谱")
    p.add_argument("--topic", default=None, help="指定主题")
    p.add_argument("--format", default="ascii", help="mermaid/dot/json/ascii")

    # feedback
    p = sub.add_parser("feedback", help="记录反馈")
    p.add_argument("memory_id", help="记忆 ID")
    p.add_argument("--useful", action="store_true", help="有用")
    p.add_argument("--not-useful", action="store_true", help="没用")
    p.add_argument("--note", default=None, help="备注")

    # forget
    p = sub.add_parser("forget", help="删除单条记忆（含关联和向量清理）")
    p.add_argument("memory_id", help="记忆 ID")
    p.add_argument("--reason", default=None, help="删除原因")

    # flush
    sub.add_parser("flush", help="L1→L2 沉淀")

    # heal
    sub.add_parser("heal", help="自我修复")

    # sync
    p = sub.add_parser("sync", help="从 MEMORY.md 同步记忆")
    p.add_argument("source", help="源文件路径（如 MEMORY.md）")
    p.add_argument("--force", "-f", action="store_true", help="跳过过滤强制写入")

    # auto-context
    p = sub.add_parser("auto-context", help="自动组装上下文（智能检索+摘要）")
    p.add_argument("query", help="当前对话内容")
    p.add_argument("--max-tokens", type=int, default=1500, help="token 预算")
    p.add_argument("--style", default="structured", help="structured/narrative/compact/xml")

    # export
    p = sub.add_parser("export", help="导出为 Markdown")
    p.add_argument("--output", "-o", default="memories_export.md", help="输出文件路径")
    p.add_argument("--topic", default=None, help="按主题过滤")
    p.add_argument("--importance", default=None, help="按重要度过滤")
    p.add_argument("--limit", type=int, default=1000, help="最多导出条数")

    # conflicts
    p = sub.add_parser("conflicts", help="检测记忆冲突")
    p.add_argument("--hours", type=int, default=168, help="检查时间窗口（小时）")

    sub.add_parser("notifications", help="查看待处理的主动通知")
    sub.add_parser("reactor-scan", help="手动触发 reactor 全量扫描")

    # v5.3: 蒸馏命令
    p = sub.add_parser("distill", help="执行记忆蒸馏（对话碎片→知识库）")
    p.add_argument("--force", action="store_true", help="强制全量重新蒸馏")

    sub.add_parser("distill-stats", help="查看蒸馏系统统计")

    p = sub.add_parser("encyclopedia", help="查看个人百科")
    p.add_argument("--category", type=str, default=None,
                   help="按类别过滤 (decisions/tools/projects/concepts/people/facts)")
    p.add_argument("--search", type=str, default=None, help="搜索百科条目")
    p.add_argument("--export", type=str, default=None, help="导出百科到文件")

    p = sub.add_parser("entities", help="查看知识实体")
    p.add_argument("--type", type=str, default=None, help="按类型过滤")
    p.add_argument("--name", type=str, default=None, help="按名称搜索")

    p = sub.add_parser("topic-summaries", help="查看主题摘要")
    p.add_argument("--topic", type=str, default=None, help="按主题过滤")

    # v5.4: 时间旅行命令
    p = sub.add_parser("snapshot", help="创建记忆快照（保存某一时刻的认知状态）")
    p.add_argument("--label", "-l", default=None, help="快照标签（默认: 当前日期）")
    p.add_argument("--at", default=None, help="快照时间点（支持: YYYY-MM-DD, 7d, 1m, today, yesterday）")
    p.add_argument("--description", "-d", default=None, help="描述")

    p = sub.add_parser("snapshots", help="列出所有快照")
    p.add_argument("--limit", type=int, default=20, help="显示数量")

    p = sub.add_parser("diff", help="对比两个时间点的记忆差异（这段时间学到了什么）")
    p.add_argument("from_date", help="起始时间（YYYY-MM-DD / 7d / 1m / today / yesterday）")
    p.add_argument("to_date", nargs="?", default="today", help="结束时间（默认: today）")
    p.add_argument("--topic", default=None, help="按主题过滤")
    p.add_argument("--from-snapshot", default=None, help="起始快照 ID")
    p.add_argument("--to-snapshot", default=None, help="结束快照 ID")
    p.add_argument("--natural", "-n", action="store_true", help="自然语言输出")

    p = sub.add_parser("blame", help="追溯记忆来源（这条记忆是怎么来的）")
    p.add_argument("memory_id", help="记忆 ID")
    p.add_argument("--natural", "-n", action="store_true", help="自然语言输出")

    sub.add_parser("timeline-stats", help="时间旅行系统统计")

    # Phase 2: 自我指涉命令
    p = sub.add_parser("traces", help="查看推理追踪历史")
    p.add_argument("--limit", type=int, default=20, help="显示数量")
    p.add_argument("--topic", default=None, help="按查询内容过滤")

    p = sub.add_parser("trace-detail", help="查看单次推理的详细步骤")
    p.add_argument("trace_id", help="追踪 ID")

    p = sub.add_parser("trace-log", help="查看结构化追踪日志（--trace 启用）")
    p.add_argument("--module", default=None, help="按模块过滤（recall/maintain/metacognition）")
    p.add_argument("--limit", type=int, default=50, help="显示数量")
    p.add_argument("--clear", action="store_true", help="清空追踪日志")

    p = sub.add_parser("confidence", help="查看置信度历史/概览")
    p.add_argument("--topic", default=None, help="按主题过滤")
    p.add_argument("--limit", type=int, default=50, help="显示数量")
    p.add_argument("--overview", "-o", action="store_true", help="显示各主题置信度概览")

    p = sub.add_parser("reflect", help="查看自我反思历史")
    p.add_argument("--limit", type=int, default=20, help="显示数量")

    p = sub.add_parser("uncertainty", help="查看不确定因素模式分析")
    p.add_argument("--limit", type=int, default=100, help="分析范围")

    # Phase 3: 元认知命令
    p = sub.add_parser("meta-recall", help="带反思的检索（不确定时自动修正查询重试）")
    p.add_argument("query", help="查询内容")
    p.add_argument("--limit", type=int, default=10, help="返回条数")
    p.add_argument("--max-rounds", type=int, default=2, help="最大反思轮数")

    p = sub.add_parser("evaluate", help="评估检索结果质量（多维度分析）")
    p.add_argument("query", help="查询内容")

    # Phase 4: 内在动机命令
    p = sub.add_parser("mood", help="查看 Agent 当前内在状态")
    p.add_argument("--detail", "-d", action="store_true", help="显示详细分析（无聊度 + 知识空白）")

    sub.add_parser("gaps", help="查看知识空白")
    sub.add_parser("curious", help="查看好奇驱动的探索任务")

    # Phase 5: 叙事自我命令
    sub.add_parser("whoami", help="我是谁 — 第一人称自我叙述")

    p = sub.add_parser("identity", help="查看身份画像")
    p.add_argument("--raw", "-r", action="store_true", help="JSON 格式输出")

    p = sub.add_parser("narrative", help="构建叙事（时间线/主题）")
    p.add_argument("--topic", default=None, help="按主题构建叙事")
    p.add_argument("--from-date", default=None, help="起始日期 (YYYY-MM-DD)")
    p.add_argument("--to-date", default=None, help="结束日期")
    p.add_argument("--limit", type=int, default=50, help="最大记忆数")

    sub.add_parser("worldview", help="查看世界观（信念/价值观/原则）")
    sub.add_parser("self-concept", help="查看完整自我概念")

    # Phase 6: 数字孪生命令
    sub.add_parser("persona", help="构建数字孪生人格画像")
    sub.add_parser("persona-get", help="获取最新的数字孪生人格画像")

    # Phase 7: 个人风格 Agent 命令
    sub.add_parser("roles", help="列出所有可用的角色模板")
    
    p = sub.add_parser("role-get", help="获取特定角色模板")
    p.add_argument("role_id", help="角色 ID")
    
    p = sub.add_parser("role-apply", help="应用角色风格到个人人格")
    p.add_argument("role_id", help="角色 ID")
    p.add_argument("--weight", type=float, default=0.4, help="角色风格权重 (0-1)")
    
    p = sub.add_parser("role-create", help="创建新角色模板")
    p.add_argument("role_id", help="角色 ID")
    p.add_argument("--name", required=True, help="角色名称")
    p.add_argument("--prompt", required=True, help="提示词模板")
    p.add_argument("--traits", required=True, help="人格特质 JSON")
    p.add_argument("--speaking-style", default="", help="说话风格")
    p.add_argument("--topics", default="", help="主题偏好（逗号分隔）")
    p.add_argument("--emotional-tone", default="", help="情感基调")
    
    p = sub.add_parser("role-delete", help="删除角色模板")
    p.add_argument("role_id", help="角色 ID")
    
    p = sub.add_parser("role-from-media", help="从媒体文件创建角色模板")
    p.add_argument("file_path", help="媒体文件路径")
    p.add_argument("--name", required=True, help="角色名称")

    # Phase 6: 统一自我入口
    p = sub.add_parser("self", help="统一自我状态仪表盘")
    p.add_argument("--mood", action="store_true", help="仅显示内在状态")
    p.add_argument("--narrative", "-n", action="store_true", help="仅显示身份叙事")
    p.add_argument("--confidence", "-c", action="store_true", help="仅显示置信度概览")
    p.add_argument("--gaps", "-g", action="store_true", help="仅显示知识空白")
    p.add_argument("--recent-thinking", "-t", action="store_true", help="仅显示最近推理")

    # v6.0: 记忆版本化命令
    p = sub.add_parser("update", help="更新记忆内容（版本化，保留历史）")
    p.add_argument("memory_id", help="要更新的记忆 ID")
    p.add_argument("--content", "-c", required=True, help="新内容")
    p.add_argument("--reason", "-r", default=None, help="变更原因")
    p.add_argument("--importance", "-i", default=None, help="新重要度 (high/medium/low)")
    p.add_argument("--topics", "-t", default=None, help="新主题列表（逗号分隔）")

    p = sub.add_parser("versions", help="查看记忆的版本历史")
    p.add_argument("memory_id", help="记忆 ID")
    p.add_argument("--json", dest="as_json", action="store_true", help="JSON 输出")

    # 模型守护进程管理
    p = sub.add_parser("model-server", help="管理模型守护进程（避免冷启动）")
    p.add_argument("action", choices=["start", "stop", "status", "restart"], help="操作")

    args = parser.parse_args()

    # 启用追踪日志
    if args.trace:
        from trace_logger import get_tracer, enable_tracing
        tracer = get_tracer()
        tracer.enable(True)
        if args.trace_module:
            tracer.set_module_filter(*args.trace_module.split(","))
        print(f"[TRACE] 追踪已启用 (module_filter={args.trace_module or 'all'})", file=sys.stderr)

    if not args.command:
        parser.print_help()
        sys.exit(1)

    handlers = {
        "remember": cmd_remember,
        "recall": cmd_recall,
        "context": cmd_context,
        "stats": cmd_stats,
        "maintain": cmd_maintain,
        "compress": cmd_compress,
        "graph": cmd_graph,
        "feedback": cmd_feedback,
        "forget": cmd_forget,
        "flush": cmd_flush,
        "heal": cmd_heal,
        "sync": cmd_sync,
        "auto-context": cmd_auto_context,
        "export": cmd_export,
        "conflicts": cmd_conflicts,
        "notifications": cmd_notifications,
        "reactor-scan": cmd_reactor_scan,
        "distill": cmd_distill,
        "distill-stats": cmd_distill_stats,
        "encyclopedia": cmd_encyclopedia,
        "entities": cmd_entities,
        "topic-summaries": cmd_topic_summaries,
        # 时间旅行
        "snapshot": cmd_snapshot,
        "snapshots": cmd_snapshots,
        "diff": cmd_diff,
        "blame": cmd_blame,
        "timeline-stats": cmd_timeline_stats,
        "update": cmd_update,
        "versions": cmd_versions,
        "model-server": cmd_model_server,
        # Phase 2: 自我指涉
        "traces": cmd_traces,
        "trace-detail": cmd_trace_detail,
        "trace-log": cmd_trace_log,
        "confidence": cmd_confidence,
        "reflect": cmd_reflect,
        "uncertainty": cmd_uncertainty,
        # Phase 3: 元认知
        "meta-recall": cmd_meta_recall,
        "evaluate": cmd_evaluate,
        # Phase 4: 内在动机
        "mood": cmd_mood,
        "gaps": cmd_gaps,
        "curious": cmd_curious,
        # Phase 5: 叙事自我
        "whoami": cmd_whoami,
        "identity": cmd_identity,
        "narrative": cmd_narrative,
        "worldview": cmd_worldview,
        "self-concept": cmd_self_concept,
        # Phase 6: 数字孪生
        "persona": cmd_persona,
        "persona-get": cmd_persona_get,
        # Phase 7: 个人风格 Agent
        "roles": cmd_roles,
        "role-get": cmd_role_get,
        "role-apply": cmd_role_apply,
        "role-create": cmd_role_create,
        "role-delete": cmd_role_delete,
        "role-from-media": cmd_role_from_media,
        # Phase 6: 统一自我
        "self": cmd_self,
    }

    # 检测 model_server 状态（仅涉及模型的命令才检查）
    _MODEL_COMMANDS = {"remember", "recall", "context", "auto-context", "maintain", "distill", "sync"}
    if args.command in _MODEL_COMMANDS:
        _check_model_server()

    handler = handlers.get(args.command)
    if handler:
        handler(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
