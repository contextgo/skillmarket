"""
metrics.py - 监控指标收集与导出

支持：
- Prometheus 格式导出（/metrics 端点直接可用）
- JSON 格式导出
- 指标：写入/检索 QPS、延迟、队列深度、缓存命中率、衰减分布等

用法:
    from metrics import MetricsCollector
    metrics = MetricsCollector(store, pipeline)
    metrics.record_write(latency_ms=12)
    metrics.record_recall(latency_ms=45, result_count=5)
    print(metrics.export_prometheus())  # Prometheus 格式
    print(metrics.export_json())         # JSON 格式
"""

import time
import threading
import logging
from collections import defaultdict
from datetime import datetime

logger = logging.getLogger(__name__)


class MetricsCollector:
    """指标收集器 — 线程安全，零依赖"""

    def __init__(self, store=None, pipeline=None, embedding_store=None):
        self.store = store
        self.pipeline = pipeline
        self.embedding_store = embedding_store

        self._lock = threading.Lock()
        self._start_time = time.time()

        # 计数器
        self._counters = defaultdict(int)

        # 延迟直方图（分桶）
        self._latency_buckets = {
            "write": [],
            "recall": [],
            "embed": [],
        }

        # 滑动窗口（最近 60 秒的 QPS）
        self._write_timestamps: list[float] = []
        self._recall_timestamps: list[float] = []
        self._window_sec = 60

    def record_write(self, latency_ms: float = 0, success: bool = True):
        """记录一次写入"""
        with self._lock:
            self._counters["writes_total"] += 1
            if success:
                self._counters["writes_success"] += 1
            else:
                self._counters["writes_failed"] += 1
            if latency_ms > 0:
                self._latency_buckets["write"].append(latency_ms)
                if len(self._latency_buckets["write"]) > 1000:
                    self._latency_buckets["write"] = self._latency_buckets["write"][-500:]
            self._write_timestamps.append(time.time())

    def record_recall(self, latency_ms: float = 0, result_count: int = 0, cached: bool = False):
        """记录一次检索"""
        with self._lock:
            self._counters["recalls_total"] += 1
            self._counters["recall_results_total"] += result_count
            if cached:
                self._counters["recall_cache_hits"] += 1
            if latency_ms > 0:
                self._latency_buckets["recall"].append(latency_ms)
                if len(self._latency_buckets["recall"]) > 1000:
                    self._latency_buckets["recall"] = self._latency_buckets["recall"][-500:]
            self._recall_timestamps.append(time.time())

    def record_embed(self, latency_ms: float = 0):
        """记录一次 embedding 计算"""
        with self._lock:
            self._counters["embeds_total"] += 1
            if latency_ms > 0:
                self._latency_buckets["embed"].append(latency_ms)
                if len(self._latency_buckets["embed"]) > 500:
                    self._latency_buckets["embed"] = self._latency_buckets["embed"][-250:]

    def record_throttle(self):
        """记录一次限流丢弃"""
        with self._lock:
            self._counters["throttled_total"] += 1

    def get_summary(self) -> dict:
        """获取指标摘要"""
        with self._lock:
            now = time.time()
            # 清理过期时间戳
            cutoff = now - self._window_sec
            self._write_timestamps = [t for t in self._write_timestamps if t >= cutoff]
            self._recall_timestamps = [t for t in self._recall_timestamps if t >= cutoff]

            write_qps = len(self._write_timestamps) / self._window_sec
            recall_qps = len(self._recall_timestamps) / self._window_sec

            uptime_sec = now - self._start_time

            # 延迟百分位
            def percentile(arr, p):
                if not arr:
                    return 0
                s = sorted(arr)
                idx = int(len(s) * p / 100)
                return round(s[min(idx, len(s) - 1)], 1)

            summary = {
                "uptime_seconds": round(uptime_sec),
                "write_qps": round(write_qps, 2),
                "recall_qps": round(recall_qps, 2),
                "counters": dict(self._counters),
                "latency": {},
            }

            for name, arr in self._latency_buckets.items():
                if arr:
                    summary["latency"][name] = {
                        "p50": percentile(arr, 50),
                        "p95": percentile(arr, 95),
                        "p99": percentile(arr, 99),
                        "max": round(max(arr), 1),
                        "count": len(arr),
                    }

            # 存储层指标
            if self.store:
                try:
                    mem_count = self.store.conn.execute("SELECT COUNT(*) as c FROM memories").fetchone()["c"]
                    link_count = self.store.conn.execute("SELECT COUNT(*) as c FROM memory_links").fetchone()["c"]
                    summary["storage"] = {
                        "memories": mem_count,
                        "links": link_count,
                    }
                except Exception:
                    pass

            # 向量库指标
            if self.embedding_store:
                try:
                    summary["vectors"] = self.embedding_store.count()
                except Exception:
                    pass

            # 队列指标
            if self.pipeline:
                queue_stats = self.pipeline.get_queue_stats()
                if queue_stats:
                    summary["write_queue"] = queue_stats

            return summary

    def export_prometheus(self) -> str:
        """导出 Prometheus 格式指标"""
        summary = self.get_summary()
        lines = [
            "# HELP agent_memory_uptime_seconds System uptime in seconds",
            "# TYPE agent_memory_uptime_seconds gauge",
            f"agent_memory_uptime_seconds {summary['uptime_seconds']}",
            "",
            "# HELP agent_memory_write_qps Write operations per second",
            "# TYPE agent_memory_write_qps gauge",
            f"agent_memory_write_qps {summary['write_qps']}",
            "",
            "# HELP agent_memory_recall_qps Recall operations per second",
            "# TYPE agent_memory_recall_qps gauge",
            f"agent_memory_recall_qps {summary['recall_qps']}",
            "",
        ]

        # 计数器
        for name, value in summary.get("counters", {}).items():
            lines.append(f"# HELP agent_memory_{name} {name.replace('_', ' ')}")
            lines.append(f"# TYPE agent_memory_{name} counter")
            lines.append(f"agent_memory_{name} {value}")
            lines.append("")

        # 延迟
        for op, stats in summary.get("latency", {}).items():
            lines.append(f"# HELP agent_memory_{op}_latency_ms {op} latency in ms")
            lines.append(f"# TYPE agent_memory_{op}_latency_ms summary")
            lines.append(f'agent_memory_{op}_latency_ms{{quantile="0.5"}} {stats["p50"]}')
            lines.append(f'agent_memory_{op}_latency_ms{{quantile="0.95"}} {stats["p95"]}')
            lines.append(f'agent_memory_{op}_latency_ms{{quantile="0.99"}} {stats["p99"]}')
            lines.append(f'agent_memory_{op}_latency_ms_count {stats["count"]}')
            lines.append("")

        # 存储
        if "storage" in summary:
            lines.append("# HELP agent_memory_storage_memories Total memories in SQLite")
            lines.append("# TYPE agent_memory_storage_memories gauge")
            lines.append(f"agent_memory_storage_memories {summary['storage']['memories']}")
            lines.append("")

        if "vectors" in summary:
            lines.append("# HELP agent_memory_vectors_total Total vectors in store")
            lines.append("# TYPE agent_memory_vectors_total gauge")
            lines.append(f"agent_memory_vectors_total {summary['vectors']}")
            lines.append("")

        return "\n".join(lines)

    def export_json(self) -> str:
        """导出 JSON 格式指标"""
        import json
        return json.dumps(self.get_summary(), ensure_ascii=False, indent=2)
