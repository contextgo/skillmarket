
"""
记忆系统部署脚本
将记忆系统部署到云端OpenClaw
"""

import os
import shutil
from pathlib import Path

def main():
    print("=" * 60)
    print("Agent Memory 部署脚本")
    print("=" * 60)
    
    # 当前目录
    current_dir = Path(__file__).parent
    print(f"当前目录: {current_dir}")
    
    # 插件源文件列表
    source_files = [
        "memory_system.py", "store.py", "encoder.py", "pipeline.py",
        "recall.py", "context_builder.py", "detector.py", "embedding_store.py",
        "reranker.py", "hierarchical.py", "quality.py", "causal.py",
        "decay.py", "compressor.py", "dedup.py", "content_cleaner.py",
        "memory_filter.py", "semantic_topic.py", "topic_registry.py",
        "self_healing.py", "memory_graph.py", "agent_network.py",
        "session_context.py", "media_processor.py", "reactor.py",
        "distill.py", "timeline.py", "emotion.py", "self_model.py",
        "metacognition.py", "motivation.py", "narrative.py",
        "digital_twin.py", "role_template.py", "style_analyzer.py",
        "trace_logger.py", "recall_eval.py", "archiver.py",
        "schema.sql", "dimensions.json", "quality_stats.json"
    ]
    
    # 检查源文件是否存在
    print("\n检查源文件...")
    existing_files = []
    missing_files = []
    for f in source_files:
        file_path = current_dir / f
        if file_path.exists():
            existing_files.append(f)
            print(f"  ✓ {f}")
        else:
            missing_files.append(f)
            print(f"  ✗ {f} (缺失)")
    
    print(f"\n找到 {len(existing_files)} 个源文件，缺失 {len(missing_files)} 个")
    
    # 创建部署包
    plugin_dir = current_dir / "openclaw_plugin"
    plugin_dir.mkdir(exist_ok=True)
    
    # 复制文件到插件目录
    print("\n创建部署包...")
    for f in existing_files:
        src = current_dir / f
        if f in ["schema.sql", "dimensions.json", "quality_stats.json"]:
            dst = plugin_dir / "config" / f
            (plugin_dir / "config").mkdir(exist_ok=True)
        else:
            dst = plugin_dir / f
        
        if src.is_file():
            shutil.copy2(src, dst)
            print(f"  ✓ 复制: {f} -&gt; {dst.relative_to(current_dir)}")
    
    # 创建部署说明
    readme_path = plugin_dir / "README.md"
    readme_content = """
# Agent Memory 插件部署说明

## 部署步骤

1. 将整个插件包复制到OpenClaw插件目录:
```
/home/admin/.openclaw/plugins/agent_memory/
```

2. 确保OpenClaw有插件加载机制，加载此插件

3. 重启OpenClaw服务

## 目录结构
```
agent_memory/
├── __init__.py
├── memory_plugin.py    # 插件入口
├── memory_system.py  # 记忆系统核心
├── store.py         # 存储层
├── encoder.py       # 编码器
├── ...             # 其他模块
├── config/
│   ├── schema.sql
│   └── dimensions.json
├── data/            # 运行时数据
└── roles/          # 角色模板
```

## 在OpenClaw中使用

通过 `from agent_memory_plugin import get_memory_plugin

# 获取插件实例
plugin = get_memory_plugin()

# 记住信息
plugin.remember("用户的内容", importance="high")

# 检索信息
results = plugin.recall("查询内容")
"""

    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    print(f"  ✓ 说明: {readme_path.relative_to(current_dir)}")
    
    print(f"\n部署包已创建到: {plugin_dir}")
    print(f"请将整个 'openclaw_plugin' 目录复制到: /home/admin/.openclaw/plugins/")

if __name__ == "__main__":
    main()
