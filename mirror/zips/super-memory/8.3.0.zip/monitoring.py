"""
monitoring.py - 监控系统

功能：
1. 系统状态监控（CPU、内存、磁盘使用情况）
2. 服务健康检查
3. 日志监控和分析
4. 性能指标收集和分析
5. 异常检测和报警

使用方式：
    from monitoring import MonitoringSystem
    monitor = MonitoringSystem()
    
    # 获取系统状态
    system_status = monitor.get_system_status()
    
    # 检查服务健康状态
    health_status = monitor.check_health()
    
    # 获取性能指标
    metrics = monitor.get_metrics()
"""

import os
import sys
import time
import logging
import psutil
import threading
import json
from datetime import datetime
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class MonitoringSystem:
    """监控系统"""
    
    def __init__(self, data_dir: str = None, check_interval: int = 60):
        """
        初始化监控系统
        
        Args:
            data_dir: 数据存储目录（可选）
            check_interval: 检查间隔（秒）
        """
        self.data_dir = data_dir or os.path.join(os.path.dirname(__file__), "data")
        self.check_interval = check_interval
        self.metrics_file = os.path.join(self.data_dir, "metrics.json")
        self.alerts_file = os.path.join(self.data_dir, "alerts.json")
        
        # 确保数据目录存在
        os.makedirs(self.data_dir, exist_ok=True)
        
        # 性能指标历史（限制大小）
        self.metrics_history = []
        self.max_history_size = 1000  # 最多保存1000条记录
        self.alerts = []
        self.max_alerts_size = 500  # 最多保存500条警报
        
        # 启动监控线程
        self.running = False
        self.monitor_thread = None
    
    def start(self):
        """启动监控系统"""
        if not self.running:
            self.running = True
            self.monitor_thread = threading.Thread(target=self._monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
            logger.info("监控系统已启动")
    
    def stop(self):
        """停止监控系统"""
        if self.running:
            self.running = False
            if self.monitor_thread:
                self.monitor_thread.join()
            logger.info("监控系统已停止")
    
    def _monitor_loop(self):
        """监控循环"""
        while self.running:
            try:
                # 收集系统状态
                system_status = self.get_system_status()
                
                # 检查服务健康状态
                health_status = self.check_health()
                
                # 收集性能指标
                metrics = self.get_metrics()
                
                # 检测异常
                alerts = self.detect_anomalies(metrics)
                if alerts:
                    self.alerts.extend(alerts)
                    # 限制警报数量
                    if len(self.alerts) > 500:
                        self.alerts = self.alerts[-500:]
                    self._save_alerts()
                
                # 保存性能指标
                self.metrics_history.append(metrics)
                # 只保留最近1000条指标
                if len(self.metrics_history) > 1000:
                    self.metrics_history = self.metrics_history[-1000:]
                self._save_metrics()
                
                # 等待下一次检查
                time.sleep(self.check_interval)
            except Exception as e:
                logger.error(f"监控循环错误: {e}")
                time.sleep(self.check_interval)
    
    def get_system_status(self) -> Dict:
        """
        获取系统状态
        
        Returns:
            Dict: 系统状态
        """
        try:
            # CPU 使用率
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # 内存使用情况
            memory = psutil.virtual_memory()
            memory_used_percent = memory.percent
            memory_used_gb = memory.used / (1024 * 1024 * 1024)
            memory_total_gb = memory.total / (1024 * 1024 * 1024)
            
            # 磁盘使用情况
            disk = psutil.disk_usage('/')
            disk_used_percent = disk.percent
            disk_used_gb = disk.used / (1024 * 1024 * 1024)
            disk_total_gb = disk.total / (1024 * 1024 * 1024)
            
            # 网络状态
            network = psutil.net_io_counters()
            
            return {
                "timestamp": datetime.now().isoformat(),
                "cpu": {
                    "percent": cpu_percent
                },
                "memory": {
                    "used_percent": memory_used_percent,
                    "used_gb": round(memory_used_gb, 2),
                    "total_gb": round(memory_total_gb, 2)
                },
                "disk": {
                    "used_percent": disk_used_percent,
                    "used_gb": round(disk_used_gb, 2),
                    "total_gb": round(disk_total_gb, 2)
                },
                "network": {
                    "bytes_sent": network.bytes_sent,
                    "bytes_recv": network.bytes_recv,
                    "packets_sent": network.packets_sent,
                    "packets_recv": network.packets_recv
                }
            }
        except Exception as e:
            logger.error(f"获取系统状态失败: {e}")
            return {
                "timestamp": datetime.now().isoformat(),
                "error": str(e)
            }
    
    def check_health(self) -> Dict:
        """
        检查服务健康状态
        
        Returns:
            Dict: 健康状态
        """
        try:
            # 检查数据库连接
            db_health = self._check_database_health()
            
            # 检查网络连接
            network_health = self._check_network_health()
            
            # 检查服务状态
            service_health = self._check_service_health()
            
            # 整体健康状态
            overall_health = "healthy"
            if not db_health["healthy"] or not network_health["healthy"] or not service_health["healthy"]:
                overall_health = "unhealthy"
            
            return {
                "timestamp": datetime.now().isoformat(),
                "overall": overall_health,
                "database": db_health,
                "network": network_health,
                "service": service_health
            }
        except Exception as e:
            logger.error(f"检查健康状态失败: {e}")
            return {
                "timestamp": datetime.now().isoformat(),
                "overall": "unhealthy",
                "error": str(e)
            }
    
    def _check_database_health(self) -> Dict:
        """检查数据库健康状态"""
        try:
            # 这里可以添加具体的数据库健康检查逻辑
            # 例如检查SQLite数据库文件是否存在、是否可读写等
            db_path = os.path.join(self.data_dir, "memory.db")
            db_exists = os.path.exists(db_path)
            db_readable = os.access(db_path, os.R_OK) if db_exists else False
            db_writable = os.access(db_path, os.W_OK) if db_exists else False
            
            return {
                "healthy": db_exists and db_readable and db_writable,
                "exists": db_exists,
                "readable": db_readable,
                "writable": db_writable
            }
        except Exception as e:
            return {
                "healthy": False,
                "error": str(e)
            }
    
    def _check_network_health(self) -> Dict:
        """检查网络健康状态"""
        try:
            # 检查网络连接
            import socket
            # 尝试连接到一个可靠的服务器
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex(('8.8.8.8', 53))
            sock.close()
            network_available = result == 0
            
            return {
                "healthy": network_available,
                "available": network_available
            }
        except Exception as e:
            return {
                "healthy": False,
                "error": str(e)
            }
    
    def _check_service_health(self) -> Dict:
        """检查服务健康状态"""
        try:
            # 这里可以添加具体的服务健康检查逻辑
            # 例如检查关键服务是否运行、API是否响应等
            # 暂时返回默认健康状态
            return {
                "healthy": True
            }
        except Exception as e:
            return {
                "healthy": False,
                "error": str(e)
            }
    
    def get_metrics(self) -> Dict:
        """
        获取性能指标
        
        Returns:
            Dict: 性能指标
        """
        try:
            system_status = self.get_system_status()
            health_status = self.check_health()
            
            # 计算请求处理时间（模拟）
            request_time = 0.1  # 假设平均请求处理时间为0.1秒
            
            # 计算内存使用情况
            process = psutil.Process(os.getpid())
            process_memory = process.memory_info().rss / (1024 * 1024)  # 转换为MB
            
            return {
                "timestamp": datetime.now().isoformat(),
                "system": system_status,
                "health": health_status,
                "process": {
                    "memory_mb": round(process_memory, 2),
                    "cpu_percent": process.cpu_percent(interval=0.1)
                },
                "performance": {
                    "request_time": request_time
                }
            }
        except Exception as e:
            logger.error(f"获取性能指标失败: {e}")
            return {
                "timestamp": datetime.now().isoformat(),
                "error": str(e)
            }
    
    def detect_anomalies(self, metrics: Dict) -> List[Dict]:
        """
        检测异常
        
        Args:
            metrics: 性能指标
        
        Returns:
            List[Dict]: 异常列表
        """
        alerts = []
        
        try:
            # 检查CPU使用率
            cpu_percent = metrics.get("system", {}).get("cpu", {}).get("percent", 0)
            if cpu_percent > 80:
                alerts.append({
                    "timestamp": datetime.now().isoformat(),
                    "level": "warning",
                    "message": f"CPU使用率过高: {cpu_percent}%",
                    "metric": "cpu.percent",
                    "value": cpu_percent,
                    "threshold": 80
                })
            
            # 检查内存使用率
            memory_percent = metrics.get("system", {}).get("memory", {}).get("used_percent", 0)
            if memory_percent > 85:
                alerts.append({
                    "timestamp": datetime.now().isoformat(),
                    "level": "warning",
                    "message": f"内存使用率过高: {memory_percent}%",
                    "metric": "memory.used_percent",
                    "value": memory_percent,
                    "threshold": 85
                })
            
            # 检查磁盘使用率
            disk_percent = metrics.get("system", {}).get("disk", {}).get("used_percent", 0)
            if disk_percent > 90:
                alerts.append({
                    "timestamp": datetime.now().isoformat(),
                    "level": "critical",
                    "message": f"磁盘使用率过高: {disk_percent}%",
                    "metric": "disk.used_percent",
                    "value": disk_percent,
                    "threshold": 90
                })
            
            # 检查服务健康状态
            overall_health = metrics.get("health", {}).get("overall", "healthy")
            if overall_health != "healthy":
                alerts.append({
                    "timestamp": datetime.now().isoformat(),
                    "level": "critical",
                    "message": f"服务健康状态异常: {overall_health}",
                    "metric": "health.overall",
                    "value": overall_health
                })
            
        except Exception as e:
            logger.error(f"检测异常失败: {e}")
        
        return alerts
    
    def get_alerts(self, limit: int = 50) -> List[Dict]:
        """
        获取异常警报
        
        Args:
            limit: 返回条数限制
        
        Returns:
            List[Dict]: 异常警报列表
        """
        return self.alerts[-limit:]
    
    def get_metrics_history(self, limit: int = 100) -> List[Dict]:
        """
        获取性能指标历史
        
        Args:
            limit: 返回条数限制
        
        Returns:
            List[Dict]: 性能指标历史列表
        """
        return self.metrics_history[-limit:]
    
    def get_summary(self) -> Dict:
        """
        获取监控摘要
        
        Returns:
            Dict: 监控摘要
        """
        try:
            # 获取最新的系统状态
            system_status = self.get_system_status()
            
            # 获取最新的健康状态
            health_status = self.check_health()
            
            # 获取最新的性能指标
            metrics = self.get_metrics()
            
            # 获取最新的警报
            recent_alerts = self.get_alerts(10)
            
            # 计算统计信息
            alert_counts = {
                "total": len(self.alerts),
                "recent": len(recent_alerts),
                "by_level": {}
            }
            for alert in recent_alerts:
                level = alert.get("level", "info")
                alert_counts["by_level"][level] = alert_counts["by_level"].get(level, 0) + 1
            
            return {
                "timestamp": datetime.now().isoformat(),
                "system_status": system_status,
                "health_status": health_status,
                "recent_metrics": metrics,
                "alert_summary": alert_counts,
                "recent_alerts": recent_alerts
            }
        except Exception as e:
            logger.error(f"获取监控摘要失败: {e}")
            return {
                "timestamp": datetime.now().isoformat(),
                "error": str(e)
            }
    
    def _save_metrics(self):
        """保存性能指标"""
        try:
            data = {
                "timestamp": datetime.now().isoformat(),
                "metrics": self.metrics_history
            }
            with open(self.metrics_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存性能指标失败: {e}")
    
    def _load_metrics(self):
        """加载性能指标"""
        try:
            if os.path.exists(self.metrics_file):
                with open(self.metrics_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.metrics_history = data.get("metrics", [])
        except Exception as e:
            logger.error(f"加载性能指标失败: {e}")
    
    def _save_alerts(self):
        """保存警报"""
        try:
            data = {
                "timestamp": datetime.now().isoformat(),
                "alerts": self.alerts
            }
            with open(self.alerts_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存警报失败: {e}")
    
    def _load_alerts(self):
        """加载警报"""
        try:
            if os.path.exists(self.alerts_file):
                with open(self.alerts_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.alerts = data.get("alerts", [])
        except Exception as e:
            logger.error(f"加载警报失败: {e}")
    
    def clear_alerts(self):
        """清空警报"""
        self.alerts = []
        self._save_alerts()
        logger.info("警报已清空")
    
    def clear_metrics(self):
        """清空性能指标历史"""
        self.metrics_history = []
        self._save_metrics()
        logger.info("性能指标历史已清空")


# 全局监控系统实例
_monitoring_system = None

def get_monitoring_system() -> MonitoringSystem:
    """
    获取全局监控系统实例
    
    Returns:
        MonitoringSystem: 监控系统实例
    """
    global _monitoring_system
    if _monitoring_system is None:
        _monitoring_system = MonitoringSystem()
    return _monitoring_system
