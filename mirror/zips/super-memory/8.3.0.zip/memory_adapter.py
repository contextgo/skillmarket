"""
memory_adapter.py - Unified Memory Write Adapter

Solves the format mismatch between Agent Memory, OpenClaw, and Hermes.

Each external system has its own memory format:
  - Agent Memory: {content, importance, topics, nature_code, owner_agent_id, ...}
  - OpenClaw:     {text, metadata: {source, tags, timestamp}, scope}
  - Hermes:       {message, role, context, session_id, metadata}

This adapter normalizes all formats into Agent Memory's internal format,
with source attribution and dedup hints.
"""

import time
import hashlib
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)


class MemoryFormat:
    AGENT_MEMORY = "agent_memory"
    OPENCLAW = "openclaw"
    HERMES = "hermes"
    UNKNOWN = "unknown"


class AgentMemoryFormat:
    """Agent Memory native format."""

    @staticmethod
    def normalize(data: dict) -> dict:
        return {
            "content": data.get("content", ""),
            "importance": data.get("importance", "medium"),
            "topics": data.get("topics"),
            "nature_code": data.get("nature_code"),
            "tool_codes": data.get("tool_codes"),
            "knowledge_codes": data.get("knowledge_codes"),
            "owner_agent_id": data.get("owner_agent_id", "_system"),
            "visibility": data.get("visibility", "team"),
            "person_code": data.get("person_code", "main"),
            "source": data.get("source", MemoryFormat.AGENT_MEMORY),
            "source_id": data.get("source_id"),
            "source_timestamp": data.get("source_timestamp", time.time()),
        }


class OpenClawFormat:
    """OpenClaw memory format adapter."""

    IMPORTANCE_MAP = {
        "critical": "high",
        "high": "high",
        "medium": "medium",
        "low": "low",
        "info": "medium",
    }

    VISIBILITY_MAP = {
        "private": "private",
        "team": "team",
        "org": "team",
        "public": "public",
        "global": "public",
    }

    @staticmethod
    def normalize(data: dict) -> dict:
        metadata = data.get("metadata", {})
        text = data.get("text", data.get("content", ""))

        importance = OpenClawFormat.IMPORTANCE_MAP.get(
            data.get("priority", "medium"), "medium"
        )

        visibility = OpenClawFormat.VISIBILITY_MAP.get(
            data.get("scope", "team"), "team"
        )

        tags = data.get("tags", metadata.get("tags", []))
        topics = tags if isinstance(tags, list) else [tags] if tags else None

        source_id = data.get("id", data.get("memory_id"))
        if not source_id:
            source_id = "oc_" + hashlib.md5(text.encode()).hexdigest()[:12]

        return {
            "content": text,
            "importance": importance,
            "topics": topics,
            "nature_code": metadata.get("nature_code"),
            "tool_codes": metadata.get("tool_codes"),
            "knowledge_codes": metadata.get("knowledge_codes"),
            "owner_agent_id": data.get("agent_id", metadata.get("agent_id", "_openclaw")),
            "visibility": visibility,
            "person_code": data.get("person", metadata.get("person", "main")),
            "source": MemoryFormat.OPENCLAW,
            "source_id": source_id,
            "source_timestamp": data.get("timestamp", metadata.get("timestamp", time.time())),
        }


class HermesFormat:
    """Hermes agent memory format adapter."""

    IMPORTANCE_MAP = {
        "critical": "high",
        "important": "high",
        "normal": "medium",
        "low": "low",
    }

    @staticmethod
    def normalize(data: dict) -> dict:
        message = data.get("message", data.get("content", ""))
        role = data.get("role", "user")
        context = data.get("context", "")
        session_id = data.get("session_id", "")

        if context and context != message:
            content = f"[{role}@{session_id}] {message}\nContext: {context}"
        else:
            content = f"[{role}@{session_id}] {message}" if session_id else message

        metadata = data.get("metadata", {})
        importance = HermesFormat.IMPORTANCE_MAP.get(
            data.get("priority", metadata.get("priority", "normal")), "medium"
        )

        topics = data.get("topics", metadata.get("topics"))
        if isinstance(topics, str):
            topics = [t.strip() for t in topics.split(",") if t.strip()]

        source_id = data.get("id", data.get("memory_id"))
        if not source_id:
            source_id = "hm_" + hashlib.md5(content.encode()).hexdigest()[:12]

        return {
            "content": content,
            "importance": importance,
            "topics": topics,
            "nature_code": metadata.get("nature_code"),
            "tool_codes": metadata.get("tool_codes"),
            "knowledge_codes": metadata.get("knowledge_codes"),
            "owner_agent_id": data.get("agent_id", metadata.get("agent_id", "_hermes")),
            "visibility": data.get("visibility", "team"),
            "person_code": data.get("person", metadata.get("person", "main")),
            "source": MemoryFormat.HERMES,
            "source_id": source_id,
            "source_timestamp": data.get("timestamp", metadata.get("timestamp", time.time())),
        }


class MemoryAdapter:
    """
    Unified memory write adapter.

    Normalizes memory data from any source (Agent Memory, OpenClaw, Hermes)
    into Agent Memory's internal format, with source attribution.

    Usage:
        adapter = MemoryAdapter()

        # Auto-detect format
        normalized = adapter.adapt(raw_data)

        # Explicit format
        normalized = adapter.adapt(raw_data, source="openclaw")

        # Write through adapter
        result = adapter.write(memory_system, raw_data, source="hermes")
    """

    FORMAT_NORMALIZERS = {
        MemoryFormat.AGENT_MEMORY: AgentMemoryFormat.normalize,
        MemoryFormat.OPENCLAW: OpenClawFormat.normalize,
        MemoryFormat.HERMES: HermesFormat.normalize,
    }

    DETECTION_RULES = [
        (lambda d: "text" in d or "scope" in d or "tags" in d, MemoryFormat.OPENCLAW),
        (lambda d: "message" in d or "session_id" in d or "role" in d, MemoryFormat.HERMES),
        (lambda d: "content" in d, MemoryFormat.AGENT_MEMORY),
    ]

    def detect_format(self, data: dict) -> str:
        if "source" in data and data["source"] in self.FORMAT_NORMALIZERS:
            return data["source"]

        for rule, fmt in self.DETECTION_RULES:
            try:
                if rule(data):
                    return fmt
            except (KeyError, TypeError):
                continue

        return MemoryFormat.UNKNOWN

    def adapt(self, data: dict, source: str = None) -> dict:
        fmt = source or self.detect_format(data)

        normalizer = self.FORMAT_NORMALIZERS.get(fmt)
        if not normalizer:
            logger.warning(f"Unknown memory format: {fmt}, treating as agent_memory")
            normalizer = AgentMemoryFormat.normalize

        normalized = normalizer(data)
        normalized["_detected_format"] = fmt
        return normalized

    def write(self, memory_system, data: dict, source: str = None, **kwargs) -> dict:
        normalized = self.adapt(data, source)

        content = normalized["content"]
        if not content or not content.strip():
            return {"written": False, "reason": "empty_content_after_adaptation"}

        return memory_system.remember(
            content=content,
            importance=normalized.get("importance", "medium"),
            topics=normalized.get("topics"),
            nature_code=normalized.get("nature_code"),
            tool_codes=normalized.get("tool_codes"),
            knowledge_codes=normalized.get("knowledge_codes"),
            owner_agent_id=normalized.get("owner_agent_id", "_system"),
            visibility=normalized.get("visibility", "team"),
            person_code=normalized.get("person_code", "main"),
            **kwargs,
        )

    def batch_write(self, memory_system, data_list: list, source: str = None) -> list:
        results = []
        for data in data_list:
            result = self.write(memory_system, data, source=source)
            results.append(result)
        return results
