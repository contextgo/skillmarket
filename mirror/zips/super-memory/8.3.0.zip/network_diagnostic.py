#!/usr/bin/env python3
"""
网络诊断和修复工具
用于检测和修复记忆系统的网络问题
"""

import sys
import socket
import subprocess
from pathlib import Path

def check_basic_connectivity():
    """检查基础网络连接"""
    print("=" * 60)
    print("1. 检查基础网络连接")
    print("=" * 60)
    
    try:
        # 测试DNS
        print("  - 测试DNS (8.8.8.8:53)...", end=" ")
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        print("✅ DNS连接正常")
    except Exception as e:
        print(f"❌ DNS连接失败: {e}")
    
    try:
        # 测试HTTP
        print("  - 测试HTTPS (huggingface.co)...", end=" ")
        import urllib.request
        response = urllib.request.urlopen("https://huggingface.co", timeout=5)
        print(f"✅ 连接成功 (状态码: {response.status})")
        return True
    except Exception as e:
        print(f"❌ HTTP连接失败: {e}")
        return False

def check_environment():
    """检查环境变量"""
    print("\n" + "=" * 60)
    print("2. 检查代理环境变量")
    print("=" * 60)
    
    import os
    env_vars = ["HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"]
    for var in env_vars:
        value = os.environ.get(var, "")
        if value:
            print(f"  - {var} = {value[:50]}...")
        else:
            print(f"  - {var} = (未设置)")

def try_fix_network():
    """尝试修复网络"""
    print("\n" + "=" * 60)
    print("3. 尝试修复网络 (需要sudo权限)")
    print("=" * 60)
    
    fixes = []
    
    # 1. 重启网络服务
    try:
        print("  - 尝试重启网络服务...")
        subprocess.run(["systemctl", "restart", "networking"], check=False, timeout=10)
        fixes.append("尝试重启网络服务")
    except Exception as e:
        print(f"  - 重启失败: {e}")
    
    # 2. 检查防火墙
    try:
        print("  - 检查防火墙状态...")
        result = subprocess.run(["iptables", "-L", "-n"], capture_output=True, timeout=10)
        if result.returncode == 0:
            print("  - 防火墙正在运行，可能需要配置")
    except Exception as e:
        print(f"  - 防火墙检查失败: {e}")
    
    # 3. 检查DNS配置
    try:
        print("  - 检查DNS配置...")
        resolv_conf = Path("/etc/resolv.conf")
        if resolv_conf.exists():
            content = resolv_conf.read_text()
            print(f"  - /etc/resolv.conf 内容:\n{content[:200]}")
    except Exception as e:
        print(f"  - DNS配置检查失败: {e}")
    
    return fixes

def offer_solutions():
    """提供解决方案"""
    print("\n" + "=" * 60)
    print("4. 解决方案")
    print("=" * 60)
    
    solutions = [
        "方案1: 配置代理（如果需要）",
        "  export https_proxy=http://your-proxy:port",
        "  export http_proxy=http://your-proxy:port",
        "",
        "方案2: 检查防火墙规则",
        "  sudo iptables -L -n  # 查看规则",
        "  sudo iptables -A OUTPUT -p tcp --dport 443 -j ACCEPT  # 允许HTTPS",
        "",
        "方案3: 使用离线模式（不需要网络）",
        "  export AGENT_MEMORY_DISABLE_SEMANTIC=true",
        "  记忆系统仍然可以正常工作，使用关键词搜索",
        "",
        "方案4: 使用国内镜像站",
        "  如果能访问国内网络，可以配置huggingface镜像",
    ]
    
    for solution in solutions:
        print("  " + solution)

def recommend_best_action():
    """推荐最佳操作"""
    print("\n" + "=" * 60)
    print("5. 推荐操作")
    print("=" * 60)
    
    recommendations = [
        "1. 首先运行诊断: python3 network_diagnostic.py",
        "2. 如果只是暂时网络问题，等网络恢复后再试",
        "3. 如果确定不能联网，可以使用离线模式（推荐）",
        "4. 如果需要语义搜索，需要配置网络或下载模型到本地",
    ]
    
    for rec in recommendations:
        print(rec)

def main():
    print("🧠 记忆系统网络诊断工具")
    print("=" * 60)
    
    # 检查连接
    is_connected = check_basic_connectivity()
    
    # 检查环境
    check_environment()
    
    # 尝试修复
    try_fix_network()
    
    # 提供方案
    offer_solutions()
    
    # 推荐操作
    recommend_best_action()
    
    print("\n" + "=" * 60)
    if is_connected:
        print("✅ 网络连接正常，可以使用语义搜索")
        print("   可以删除旧数据库重新初始化:")
        print("   rm -f /home/admin/.openclaw/plugins/agent_memory/data/memory.db")
    else:
        print("⚠️ 网络连接失败，推荐使用离线模式")
        print("   核心功能（记忆/检索）仍然可以使用")
        print("=" * 60)

if __name__ == "__main__":
    main()