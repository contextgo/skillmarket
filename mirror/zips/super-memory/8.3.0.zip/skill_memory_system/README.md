# 记忆系统 Skill 使用指南

## 安装步骤

### 1. 上传和安装
```bash
# 上传压缩包到服务器
scp agent_memory_v8.0_plugin.zip root@您的服务器IP:/tmp/

# 解压到插件目录
mkdir -p /home/admin/.openclaw/plugins/agent_memory
cd /home/admin/.openclaw/plugins/agent_memory
unzip /tmp/agent_memory_v8.0_plugin.zip

# 安装依赖
pip install sqlite-vec sentence-transformers FlagEmbedding
```

### 2. 安装Skill
```bash
# 复制skill到skills目录
cp -r /home/admin/.openclaw/plugins/agent_memory/skill_memory_system /home/admin/.openclaw/skills/

# 或者创建软链接
ln -s /home/admin/.openclaw/plugins/agent_memory/skill_memory_system /home/admin/.openclaw/skills/memory-system
```

## 使用方法

### 直接对话使用

**记住信息**
```
用户: 记住我的生日是1月1日
OpenClaw: 好的，我已经记住了！

用户: 记住我喜欢吃川菜
OpenClaw: 我已经记住了！
```

**回忆信息**
```
用户: 回忆我之前说过什么
OpenClaw: 找到了3条相关记忆...

用户: 回忆我的生日
OpenClaw: 根据记忆，您的生日是1月1日
```

**构建上下文**
```
用户: 帮我构建关于Python的上下文
OpenClaw: 已为您构建了相关上下文...
```

**人格画像**
```
用户: 获取我的人格画像
OpenClaw: 这是您的人格画像...

用户: 帮我构建人格画像
OpenClaw: 人格画像构建成功...
```

**角色风格**
```
用户: 使用技术专家风格
OpenClaw: 已应用技术专家角色风格

用户: 使用产品经理风格
OpenClaw: 已应用产品经理角色风格

用户: 列出所有可用角色
OpenClaw: 共有6个可用角色...
```

### 在技能中调用

```python
# 在OpenClaw的技能中使用
from skills.memory_system import get_memory_skill

skill = get_memory_skill()

# 记住信息
skill.remember("用户消息", importance="high")

# 检索记忆
memories = skill.recall("查询内容")

# 构建上下文
context = skill.build_context("查询内容")
```

## 可用角色

- **tech_expert**: 技术专家
- **product_manager**: 产品经理
- **creative_writer**: 创意作家
- **business_leader**: 商业领袖
- **advisor**: 顾问
- **counselor**: 咨询师

## 重要度级别

- **high**: 高重要度，会被优先保存和检索
- **medium**: 中重要度，默认选项
- **low**: 低重要度，可能被压缩或删除

## 测试验证

```bash
# 测试记忆系统
cd /home/admin/.openclaw/plugins/agent_memory
python -c "
from skill_memory_system import get_memory_skill
skill = get_memory_skill()
print('✅ 记忆系统Skill连接成功')

# 测试记住
result = skill.remember('测试记忆')
print('记住:', result)

# 测试回忆
result = skill.recall('测试')
print('回忆:', result)

skill.close()
"
```

## 高级功能

### 1. 主题标记
```
用户: 记住Python的列表推导式，主题是编程
OpenClaw: 我已经记住了！
```

### 2. 情感编码
记忆系统会自动分析和记录情感倾向

### 3. 时间旅行
可以追踪记忆的演变过程

### 4. 记忆蒸馏
自动将对话碎片提炼成结构化知识

## 常见问题

### Q: 如何忘记某些信息？
A: 暂时需要手动编辑数据库文件，后续会提供删除功能

### Q: 记忆会占用多少空间？
A: 文本记忆很小，大约每条几十字节，可以放心使用

### Q: 如何备份记忆？
A: 直接备份 `/home/admin/.openclaw/plugins/agent_memory/data/memory.db` 文件

## 总结

现在您可以通过自然语言对话来使用记忆系统了！
- ✅ 记住重要信息
- ✅ 回忆过往内容
- ✅ 构建人格画像
- ✅ 切换角色风格
- ✅ 构建对话上下文

享受您的智能记忆系统吧！
