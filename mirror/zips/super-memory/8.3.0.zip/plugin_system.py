"""
plugin_system.py - 插件系统

功能：
1. 允许第三方扩展功能
2. 支持插件的加载、卸载和管理
3. 提供插件API接口
4. 支持插件的配置和生命周期管理
5. 提供插件依赖管理

使用方式：
    from plugin_system import PluginSystem
    plugin_system = PluginSystem()
    
    # 加载插件
    plugin_system.load_plugin("my_plugin")
    
    # 执行插件方法
    result = plugin_system.execute_plugin("my_plugin", "my_method", arg1, arg2)
"""

import os
import sys
import logging
import importlib
import importlib.util
import threading
from typing import Dict, List, Optional, Any, Callable
from datetime import datetime

logger = logging.getLogger(__name__)


class Plugin:
    """插件类"""
    
    def __init__(self, name: str, module, version: str = "1.0.0", description: str = ""):
        """
        初始化插件
        
        Args:
            name: 插件名称
            module: 插件模块
            version: 插件版本
            description: 插件描述
        """
        self.name = name
        self.module = module
        self.version = version
        self.description = description
        self.enabled = True
        self.config = {}
        self.created_at = datetime.now().isoformat()
    
    def get_info(self) -> Dict[str, Any]:
        """
        获取插件信息
        
        Returns:
            Dict: 插件信息
        """
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "enabled": self.enabled,
            "created_at": self.created_at
        }
    
    def execute(self, method: str, *args, **kwargs) -> Any:
        """
        执行插件方法
        
        Args:
            method: 方法名称
            *args: 位置参数
            **kwargs: 关键字参数
        
        Returns:
            Any: 方法返回值
        """
        if not self.enabled:
            raise Exception(f"Plugin {self.name} is disabled")
        
        if hasattr(self.module, method):
            return getattr(self.module, method)(*args, **kwargs)
        else:
            raise Exception(f"Method {method} not found in plugin {self.name}")
    
    def enable(self):
        """启用插件"""
        self.enabled = True
    
    def disable(self):
        """禁用插件"""
        self.enabled = False
    
    def set_config(self, config: Dict[str, Any]):
        """
        设置插件配置
        
        Args:
            config: 配置字典
        """
        self.config = config
    
    def get_config(self) -> Dict[str, Any]:
        """
        获取插件配置
        
        Returns:
            Dict: 配置字典
        """
        return self.config


class PluginSystem:
    """
    插件系统

    ⚠️ 安全: 插件以当前用户权限执行任意 Python 代码。加载前需显式审批。
    首次发现的插件处于 pending 状态，必须调用 approve_plugin() 后才会加载。
    """

    APPROVED_FILE = "approved.json"

    def __init__(self, plugins_dir: str = None, auto_approve: bool = False):
        """
        初始化插件系统

        Args:
            plugins_dir: 插件目录
            auto_approve: 是否自动审批新插件（仅限受信任环境，默认 False）
        """
        self.plugins_dir = plugins_dir or os.path.join(os.path.dirname(__file__), "plugins")
        self.plugins: Dict[str, Plugin] = {}
        self._lock = threading.Lock()
        self._auto_approve = auto_approve
        self._approved: set = set()
        self._approved_hashes: dict = {}
        self._pending: set = set()

        os.makedirs(self.plugins_dir, exist_ok=True)
        self._load_approved_list()
        self._load_plugins()

    def _resolve_plugin_path(self, plugin_name: str) -> str:
        """解析插件文件路径（含路径遍历防护）"""
        if ".." in plugin_name or "/" in plugin_name or "\\" in plugin_name:
            logger.warning(f"Plugin name contains path traversal characters: {plugin_name}")
            return ""
        plugin_dir = os.path.join(self.plugins_dir, plugin_name)
        if os.path.isdir(plugin_dir) and os.path.exists(os.path.join(plugin_dir, "__init__.py")):
            return os.path.join(plugin_dir, "__init__.py")
        plugin_file = os.path.join(self.plugins_dir, f"{plugin_name}.py")
        if os.path.exists(plugin_file):
            return plugin_file
        return ""

    def _load_approved_list(self):
        """加载已审批插件列表（含文件哈希）"""
        approved_path = os.path.join(self.plugins_dir, self.APPROVED_FILE)
        if os.path.exists(approved_path):
            try:
                import json
                with open(approved_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for entry in data.get("approved", []):
                    if isinstance(entry, dict):
                        self._approved.add(entry["name"])
                        self._approved_hashes[entry["name"]] = entry.get("hash", "")
                    elif isinstance(entry, str):
                        self._approved.add(entry)
                logger.info(f"Loaded approved plugins: {self._approved or '(none)'}")
            except Exception as e:
                logger.warning(f"Failed to load approved list: {e}")
                self._approved = set()

    @staticmethod
    def _file_hash(filepath: str) -> str:
        """计算文件的 SHA256 哈希"""
        import hashlib
        h = hashlib.sha256()
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    def _save_approved_list(self):
        """保存已审批插件列表（含文件哈希）"""
        approved_path = os.path.join(self.plugins_dir, self.APPROVED_FILE)
        try:
            import json
            entries = []
            for name in sorted(self._approved):
                entries.append({
                    "name": name,
                    "hash": self._approved_hashes.get(name, ""),
                })
            with open(approved_path, "w", encoding="utf-8") as f:
                json.dump({"approved": entries}, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"Failed to save approved list: {e}")

    def approve_plugin(self, plugin_name: str) -> bool:
        """
        审批插件，允许其加载执行。

        审批时记录插件文件的 SHA256 哈希，后续加载时验证文件未被篡改。

        Args:
            plugin_name: 插件名称

        Returns:
            bool: 是否审批成功
        """
        plugin_path = self._resolve_plugin_path(plugin_name)
        if not plugin_path:
            logger.error(f"Plugin {plugin_name} not found")
            return False
        file_hash = self._file_hash(plugin_path)
        with self._lock:
            self._approved.add(plugin_name)
            self._approved_hashes[plugin_name] = file_hash
            self._pending.discard(plugin_name)
            self._save_approved_list()
            logger.info(f"Plugin approved: {plugin_name} (hash: {file_hash[:16]}...)")
        return self.load_plugin(plugin_name)

    def reject_plugin(self, plugin_name: str) -> bool:
        """
        拒绝插件，从审批列表移除并卸载。

        Args:
            plugin_name: 插件名称

        Returns:
            bool: 是否拒绝成功
        """
        with self._lock:
            self._approved.discard(plugin_name)
            self._pending.discard(plugin_name)
            self._save_approved_list()
        self.unload_plugin(plugin_name)
        logger.info(f"Plugin rejected: {plugin_name}")
        return True

    def list_pending(self) -> list[str]:
        """列出待审批的插件"""
        return sorted(self._pending)
    
    def _load_plugins(self):
        """加载已审批的插件"""
        try:
            for item in os.listdir(self.plugins_dir):
                if item == self.APPROVED_FILE:
                    continue
                plugin_path = os.path.join(self.plugins_dir, item)
                plugin_name = None
                if os.path.isdir(plugin_path):
                    init_file = os.path.join(plugin_path, "__init__.py")
                    if os.path.exists(init_file):
                        plugin_name = os.path.basename(plugin_path)
                elif item.endswith(".py") and not item.startswith("_"):
                    plugin_name = os.path.splitext(item)[0]

                if plugin_name:
                    if plugin_name in self._approved or self._auto_approve:
                        if os.path.isdir(plugin_path):
                            self._load_plugin_from_directory(plugin_path)
                        else:
                            self._load_plugin_from_file(plugin_path)
                    else:
                        self._pending.add(plugin_name)
                        logger.info(f"Plugin pending approval: {plugin_name}")

            logger.info(f"Loaded {len(self.plugins)} plugins, {len(self._pending)} pending approval")
        except Exception as e:
            logger.error(f"加载插件失败: {e}")
    
    def _load_plugin_from_directory(self, plugin_dir: str):
        """
        从目录加载插件

        ⚠️ 安全: 仅允许从项目 plugins 目录加载。

        Args:
            plugin_dir: 插件目录
        """
        try:
            plugin_dir = os.path.abspath(plugin_dir)
            allowed_dir = os.path.abspath(self.plugins_dir)
            if not plugin_dir.startswith(allowed_dir):
                logger.warning(f"Plugin rejected (path outside plugins/): {plugin_dir}")
                return

            plugin_name = os.path.basename(plugin_dir)
            
            # 添加插件目录到Python路径
            sys.path.insert(0, self.plugins_dir)
            
            # 导入插件模块
            module = importlib.import_module(plugin_name)
            
            # 获取插件信息
            version = getattr(module, "__version__", "1.0.0")
            description = getattr(module, "__description__", "")
            
            # 创建插件实例
            plugin = Plugin(plugin_name, module, version, description)
            
            # 加载插件配置
            config_file = os.path.join(plugin_dir, "config.json")
            if os.path.exists(config_file):
                with open(config_file, 'r', encoding='utf-8') as f:
                    import json
                    config = json.load(f)
                    plugin.set_config(config)
            
            # 注册插件
            self.plugins[plugin_name] = plugin
            logger.info(f"成功加载插件: {plugin_name} v{version}")
        except Exception as e:
            logger.error(f"加载插件 {os.path.basename(plugin_dir)} 失败: {e}")
    
    def _load_plugin_from_file(self, plugin_file: str):
        """
        从文件加载插件

        ⚠️ 安全: 此方法使用 importlib 动态加载 Python 模块，属于代码执行操作。
        仅允许从项目 plugins 目录加载，拒绝外部路径。

        Args:
            plugin_file: 插件文件路径
        """
        try:
            plugin_file = os.path.abspath(plugin_file)
            allowed_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "plugins"))
            if not plugin_file.startswith(allowed_dir):
                logger.warning(f"Plugin rejected (path outside plugins/): {plugin_file}")
                return

            plugin_name = os.path.splitext(os.path.basename(plugin_file))[0]

            # v8.2 安全：验证文件哈希，防止审批后被篡改
            expected_hash = self._approved_hashes.get(plugin_name, "")
            if expected_hash:
                current_hash = self._file_hash(plugin_file)
                if current_hash != expected_hash:
                    logger.error(
                        f"Plugin {plugin_name} hash mismatch! "
                        f"Expected {expected_hash[:16]}... got {current_hash[:16]}... "
                        f"File may have been tampered with. Re-approve to update hash."
                    )
                    self.plugins[plugin_name] = Plugin(plugin_name, None, "0.0.0", "HASH MISMATCH - disabled")
                    self.plugins[plugin_name].enabled = False
                    return

            spec = importlib.util.spec_from_file_location(plugin_name, plugin_file)
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                _load = getattr(spec.loader, "exec_module", None)
                if _load and callable(_load):
                    _load(module)
                else:
                    logger.error(f"Plugin {plugin_name}: no module loader available")
                    return

                version = getattr(module, "__version__", "1.0.0")
                description = getattr(module, "__description__", "")

                plugin = Plugin(plugin_name, module, version, description)

                self.plugins[plugin_name] = plugin
                logger.info(f"成功加载插件: {plugin_name} v{version}")
        except Exception as e:
            logger.error(f"加载插件 {os.path.basename(plugin_file)} 失败: {e}")
    
    def load_plugin(self, plugin_name: str) -> bool:
        """
        加载指定插件
        
        Args:
            plugin_name: 插件名称
        
        Returns:
            bool: 是否加载成功
        """
        try:
            with self._lock:
                # 检查插件是否已加载
                if plugin_name in self.plugins:
                    logger.info(f"插件 {plugin_name} 已加载")
                    return True
                
                # 尝试从目录加载
                plugin_dir = os.path.join(self.plugins_dir, plugin_name)
                if os.path.isdir(plugin_dir):
                    self._load_plugin_from_directory(plugin_dir)
                    return plugin_name in self.plugins
                
                # 尝试从文件加载
                plugin_file = os.path.join(self.plugins_dir, f"{plugin_name}.py")
                if os.path.exists(plugin_file):
                    self._load_plugin_from_file(plugin_file)
                    return plugin_name in self.plugins
                
                logger.error(f"插件 {plugin_name} 不存在")
                return False
        except Exception as e:
            logger.error(f"加载插件 {plugin_name} 失败: {e}")
            return False
    
    def unload_plugin(self, plugin_name: str) -> bool:
        """
        卸载插件
        
        Args:
            plugin_name: 插件名称
        
        Returns:
            bool: 是否卸载成功
        """
        try:
            with self._lock:
                if plugin_name in self.plugins:
                    del self.plugins[plugin_name]
                    logger.info(f"成功卸载插件: {plugin_name}")
                    return True
                else:
                    logger.warning(f"插件 {plugin_name} 未加载")
                    return False
        except Exception as e:
            logger.error(f"卸载插件 {plugin_name} 失败: {e}")
            return False
    
    def reload_plugin(self, plugin_name: str) -> bool:
        """
        重新加载插件
        
        Args:
            plugin_name: 插件名称
        
        Returns:
            bool: 是否重新加载成功
        """
        try:
            with self._lock:
                # 先卸载插件
                self.unload_plugin(plugin_name)
                # 再加载插件
                return self.load_plugin(plugin_name)
        except Exception as e:
            logger.error(f"重新加载插件 {plugin_name} 失败: {e}")
            return False
    
    def list_plugins(self) -> List[Dict[str, Any]]:
        """
        列出所有插件
        
        Returns:
            List[Dict]: 插件信息列表
        """
        with self._lock:
            return [plugin.get_info() for plugin in self.plugins.values()]
    
    def get_plugin(self, plugin_name: str) -> Optional[Plugin]:
        """
        获取插件实例
        
        Args:
            plugin_name: 插件名称
        
        Returns:
            Optional[Plugin]: 插件实例
        """
        with self._lock:
            return self.plugins.get(plugin_name)
    
    def execute_plugin(self, plugin_name: str, method: str, *args, **kwargs) -> Any:
        """
        执行插件方法
        
        Args:
            plugin_name: 插件名称
            method: 方法名称
            *args: 位置参数
            **kwargs: 关键字参数
        
        Returns:
            Any: 方法返回值
        """
        with self._lock:
            plugin = self.plugins.get(plugin_name)
            if not plugin:
                raise Exception(f"Plugin {plugin_name} not found")
            return plugin.execute(method, *args, **kwargs)
    
    def enable_plugin(self, plugin_name: str) -> bool:
        """
        启用插件
        
        Args:
            plugin_name: 插件名称
        
        Returns:
            bool: 是否启用成功
        """
        try:
            with self._lock:
                plugin = self.plugins.get(plugin_name)
                if plugin:
                    plugin.enable()
                    logger.info(f"成功启用插件: {plugin_name}")
                    return True
                else:
                    logger.warning(f"插件 {plugin_name} 未加载")
                    return False
        except Exception as e:
            logger.error(f"启用插件 {plugin_name} 失败: {e}")
            return False
    
    def disable_plugin(self, plugin_name: str) -> bool:
        """
        禁用插件
        
        Args:
            plugin_name: 插件名称
        
        Returns:
            bool: 是否禁用成功
        """
        try:
            with self._lock:
                plugin = self.plugins.get(plugin_name)
                if plugin:
                    plugin.disable()
                    logger.info(f"成功禁用插件: {plugin_name}")
                    return True
                else:
                    logger.warning(f"插件 {plugin_name} 未加载")
                    return False
        except Exception as e:
            logger.error(f"禁用插件 {plugin_name} 失败: {e}")
            return False
    
    def set_plugin_config(self, plugin_name: str, config: Dict[str, Any]) -> bool:
        """
        设置插件配置
        
        Args:
            plugin_name: 插件名称
            config: 配置字典
        
        Returns:
            bool: 是否设置成功
        """
        try:
            with self._lock:
                plugin = self.plugins.get(plugin_name)
                if plugin:
                    plugin.set_config(config)
                    logger.info(f"成功设置插件 {plugin_name} 的配置")
                    return True
                else:
                    logger.warning(f"插件 {plugin_name} 未加载")
                    return False
        except Exception as e:
            logger.error(f"设置插件 {plugin_name} 的配置失败: {e}")
            return False
    
    def get_plugin_config(self, plugin_name: str) -> Optional[Dict[str, Any]]:
        """
        获取插件配置
        
        Args:
            plugin_name: 插件名称
        
        Returns:
            Optional[Dict]: 配置字典
        """
        with self._lock:
            plugin = self.plugins.get(plugin_name)
            if plugin:
                return plugin.get_config()
            else:
                return None
    
    def get_plugin_info(self, plugin_name: str) -> Optional[Dict[str, Any]]:
        """
        获取插件信息
        
        Args:
            plugin_name: 插件名称
        
        Returns:
            Optional[Dict]: 插件信息
        """
        with self._lock:
            plugin = self.plugins.get(plugin_name)
            if plugin:
                return plugin.get_info()
            else:
                return None
    
    def scan_plugins(self):
        """
        扫描插件目录，加载新插件
        """
        try:
            # 保存当前已加载的插件
            current_plugins = set(self.plugins.keys())
            
            # 重新加载所有插件
            self._load_plugins()
            
            # 检查新增的插件
            new_plugins = set(self.plugins.keys()) - current_plugins
            if new_plugins:
                logger.info(f"发现并加载新插件: {', '.join(new_plugins)}")
        except Exception as e:
            logger.error(f"扫描插件失败: {e}")


# 全局插件系统实例
_plugin_system = None

def get_plugin_system() -> PluginSystem:
    """
    获取全局插件系统实例
    
    Returns:
        PluginSystem: 插件系统实例
    """
    global _plugin_system
    if _plugin_system is None:
        _plugin_system = PluginSystem()
    return _plugin_system
