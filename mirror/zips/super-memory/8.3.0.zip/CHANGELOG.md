## v8.3 (2026-05-03)

**自进化大脑 + 安全加固 + 全面质量修复**

### 🧠 自进化大脑（v8.3 新特性）
- **自适应维度编码**（encoder.py）：动态注册 nature/person/tool/knowledge 维度值，自动分配 ID；使用频率追踪；维度健康检查；审核机制
- **LLM 辅助因果检测**（causal.py）：隐式因果识别、批量分析、矛盾检测（效价翻转+重要性跃迁+LLM验证）、因果链可视化
- **增强检索系统**（recall.py）：因果链扩展检索、中文文化关联（成语/俗语/典故）、形似音似关联检索
- **知识盲区检测**（metacognition.py）：empty/sparse/stale/structural 四类盲区、主动学习建议（LLM增强）、认知一致性检查
- **成长快照与增量总结**（timeline.py）：情感/认知/成就指标快照、LLM叙事+规则叙事、时间点回溯
- **内在动机触发机制**（motivation.py）：7种触发器+阈值、主动探索行动、动机状态报告
- **个性化自我表述**（narrative.py）：面向用户/开发者/Agent三种受众、warm/professional/casual语气、上下文感知
- **用户画像与模拟**（digital_twin.py）：沟通风格/主题兴趣/活动模式/情感画像/交互偏好、响应模拟
- **角色记忆隔离与知识反哺**（role_template.py）：private/shared/team三级可见性、角色→全局知识反哺、角色间知识共享
- **记忆包格式**（memory_pack.py）：标准化MemoryPack格式、记忆剥离/灌输/交易、文件操作

### 🔒 安全加固
- **修复 insert_memory_in_txn 参数错位**（store.py）：补齐 dominance/primary_emotions/compound_emotions 三个缺失参数，修复数据损坏
- **修复 SQL 注入**（embedding_store.py）：filter_metadata 键名白名单校验
- **修复缓存投毒**（cache_manager.py）：HMAC-SHA256 完整性校验、SHA-256 替代 MD5 缓存键、内存值大小限制
- **修复 LLM 提示注入**（causal.py）：用户内容 sanitize 转义隔离
- **web_server.py 安全加固**：添加 API Key 认证、修复 Zip Slip 路径遍历、文件上传大小/类型限制
- **修复 CORS 配置**（server.py）：动态 Origin 校验替代无效通配符
- **修复 API Key 时序攻击**（server.py）：hmac.compare_digest 替代 == 比较

### 🐛 Bug 修复
- **添加 store.query_links()**：causal.py 批量分析依赖的缺失方法
- **修复 _count_keywords**（digital_twin.py）：只统计第一个关键词 → 使用 OR 条件查询所有关键词
- **修复 _llm_fn 未初始化**（digital_twin.py）：构造函数保存 llm_fn 参数
- **修复 timeline 成长快照**（timeline.py）：growth_metrics 独立列替代 description 字段复用
- **修复 memory_pack 批量灌输**（memory_pack.py）：事务包裹 + checksum 版本盐
- **修复 role_template schema 初始化**（role_template.py）：事务保护 executescript

### ⚡ 性能与质量
- **content_cleaner ReDoS 防护**：长文本分块处理（>10000字符按5000分块）、短文本快速返回
- **cache_manager 锁优化**：os.listdir() 移到锁外
- **motivation 触发阈值可配置**：类变量 → 实例变量深拷贝
- **metacognition 重入防护**：_in_meta_recall 标志防止递归
- **文化关联外部化**（recall.py）：load_cultural_db/save_cultural_db 方法

## v8.2 (2026-04-30)

**架构优化 + 性能提升 + LLM 多后端**

### 🏗️ 架构优化
- **LLM 多后端抽象**（llm_client.py）：从仅支持 SiliconFlow 硬编码，重构为支持 SiliconFlow / OpenAI / 自定义后端 / 直接函数注入 4 种后端，自动检测环境变量优先级链
- **AgentMemory 懒加载**（memory_system.py）：7 个意识进化模块（self_model/metacognition/motivation/narrative/digital_twin/role_manager/style_analyzer）改为 `@property` 懒加载，启动时间减少 30-40%，内存占用降低
- **结构化日志**（memory_system.py）：新增 `configure_logging()` 函数，统一日志格式，不覆盖用户已有配置

### ⚡ 性能优化
- **MMR 算法优化**（recall.py）：O(n×k²) → numpy 向量化 O(n²+nk) / Python 增量 O(nk)，候选集限制 max(200, limit×5)，性能提升 3-20 倍
- **向量归一化优化**（embedding_store.py）：纯 Python 循环 → numpy `np.linalg.norm`，1536 维归一化性能提升约 50 倍
- **SimHash 批量计算**（embedding_store.py）：逐 token MD5 → 批量 hex 计算 + numpy 矩阵投票
- **缓存锁优化**（cache_manager.py）：文件 I/O 从锁内移到锁外，高并发吞吐提升 5-10 倍
- **store.py 批量操作**：
  - `get_memories` 补充 `_batch_get_links`，返回格式与 `get_memory` 完全一致
  - `get_linked` 从递归+N+1 改为 BFS+批量查询，20-50 倍提速
  - `move_to_cold` 批量获取替代逐条查询，10 倍提速
  - `check_overdue` SQL IN 批量操作，10 倍提速
- **pipeline 批量写入**（pipeline.py）：SQLite 事务批量写入，减少因果检测频率

### 🔧 代码质量
- **意图分类优化**（recall.py）：支持否定句检测（"不要待办"→general）、多意图记录、正则预编译
- **正则预编译**（content_cleaner.py）：5 个运行时编译正则移到 `__init__` 预编译
- **硬编码关键词可配置**（pipeline.py）：任务分配关键词从硬编码改为类属性+构造函数参数
- **pipeline 错误处理**：静默吞异常 → logger.debug，内容截断返回 truncated 标记

## v8.1.1 (2026-04-30)

**安全加固 + 性能优化 + 文档更新**

### 🔴 P0 安全修复
- **API Key 硬编码移除**：config.json 和 llm_client.py 中的 SiliconFlow API Key 已移除，统一从环境变量 `SILICONFLOW_API_KEY` 读取
- **权限系统重写**（permission_manager.py）：
  - SHA-256 + 固定盐值 → PBKDF2-SHA256（100,000 次迭代）+ 每用户独立随机盐
  - 默认弱密码 admin123 → 通过 `AGENT_MEMORY_ADMIN_PASSWORD` 环境变量设置，未设置时自动生成强密码
  - 新增密码强度校验（最少 8 位）
  - 新增登录失败锁定（5 次失败后锁定 5 分钟）
  - 新增原子文件写入（tmp → rename，防止数据损坏）
  - 全局单例加双重检查锁（线程安全）
- **SQL 注入修复**：
  - embedding_store.py：filter_metadata 的 key 增加白名单校验（仅允许字母数字下划线）
  - recall.py：_batch_get_causal_reference_counts 和 _annotate_version_counts 增加参数校验
- **dimensions.json 脏数据清理**：移除 misc 下的测试/攻击垃圾条目（含超长 aaa... 攻击字符串），版本号更新为 8.1.0，Chroma 替换为 sqlite_vec

### 🟠 P1 功能修复
- **版本号统一**：pyproject.toml (7.1.0→8.1.0)、SKILL.md (7.1.0→8.1.0)、openclaw_plugin/__init__.py (8.0.0→8.1.0)、dimensions.json (5.0.0→8.1.0) 全部统一
- **线程安全修复**：
  - embedding_store.py：_initialized_conns 加锁保护；全局 warnings.filterwarnings 改为上下文管理器
  - pipeline.py：WriteQueue._stats 加 threading.Lock 保护
  - cache_manager.py：全局单例加双重检查锁
- **性能优化**：
  - recall.py：语义检索 N+1 查询 → 批量获取
  - embedding_store.py：_check_vec_dim 从 INSERT+DELETE 测试改为读取 schema DDL
- **错误处理改进**：
  - pipeline.py：静默吞异常 → logger.debug；内容截断时返回 truncated=True
  - memory_system.py：4 处 except Exception: pass → logger.debug
  - cache_manager.py：print() → logger.error()
  - recall.py：get_stats() 中硬编码 "ChromaDB" → 动态获取实际后端名称
  - recall.py：访问私有属性 _stats → 调用公共方法 get_feedback_data()
  - quality.py：新增 get_feedback_data() 公共方法

### 🟡 P2 文档更新
- **README.md**：版本号更新为 v8.1，新增安全加固说明
- **API.md**：补充 v7.0/v8.1 新增 API 文档（情感编码、自我指涉、元认知、内在动机、叙事自我、数字孪生、角色模板、风格分析器、权限管理）
- **SKILL.md**：版本号更新为 8.1.0
- **CHANGELOG.md**：v8.1.0 记录补充详细说明

## v8.1.0 (2026-04-19)

**功能完善 + Bug 修复**

### 新增模块
- digital_twin.py：数字孪生人格画像构建
- role_template.py：角色模板系统（内置 + 自定义 + 外部导入）
- style_analyzer.py：风格分析器（文本风格 + 创作者风格 + 风格比较）
- feeding_mode.py：喂养模式
- correction_detector.py：纠错检测器
- smart_config.py：智能配置
- trace_logger.py：追踪日志
- welcome_guide.py：欢迎引导
- memory_bridge.py / memory_plugin.py / agent_memory_service.py：OpenClaw 集成层
- openclaw_integration.py：OpenClaw 集成

### 修复
- backup.py, benchmark.py, causal.py, cli.py, compressor.py, content_cleaner.py, decay.py, dedup.py, detector.py, embedding_store.py, emotion.py, encoder.py, hierarchical.py, main.py, media_processor.py, memory_system.py, model_server.py, narrative.py, network_diagnostic.py, pipeline.py, quality.py, recall.py, recall_eval.py, self_healing.py, semantic_topic.py, server.py, store.py, test_all.py, test_fixes.py, test_integration.py, topic_registry.py, vector_store.py 等模块的 Bug 修复

# Agent Memory System 更新记录

## v7.0.0 — 2026-04-15

**意识进化：情感编码 + 自我指涉 + 元认知 + 内在动机 + 叙事自我**

### 🔴 Phase 1: 情感编码
- **新增 `emotion.py`**（~280行）：EmotionAnalyzer 情感信号分析器，零依赖纯规则+词典
  - valence（效价 [-1, 1]）、arousal（唤醒度 [0, 1]）、significance（情感标签 6 级）、confidence（置信度）
  - 中英双语词典、性质基线偏移、significance 关键词覆盖
- **schema.sql**: memories 表新增 valence/arousal/significance/confidence 列 + 索引
- **pipeline.py**: ingest() 集成 EmotionAnalyzer，写入时自动附加情感信号
- **store.py**: query() 新增 significance 过滤参数
- **recall.py**: recall() 传递 significance 到 store.query()
- **memory_system.py**: remember() 返回 emotion 字段
- **cli.py**: `recall --significance` 参数；`remember` 输出情感显示
- **context_builder.py**: compact/structured 风格附带 significance icon + valence label
- **test_emotion.py**: 21 项测试

### 🔴 Phase 2: 自我指涉
- **新增 `self_model.py`**（~380行）：ReasoningTrace + SelfModel
  - 推理步骤记录、来源追踪、不确定因素、替代方案
  - 置信度历史、置信度概览（按主题分组 + 趋势分析）
  - 自我反思生成（低置信度自动触发）
  - SQLite 持久化 reasoning_traces + self_reflections 表
- **schema.sql**: 新增 reasoning_traces + self_reflections 表 + 索引
- **causal.py**: 新增 self_derived_from / revised_from / uncertain_about 因果类型
- **recall.py**: recall() 集成推理追踪（init → fts → vec → rrf → finalize）
- **memory_system.py**: SelfModel 实例化；schema v3→v4 自动迁移
- **cli.py**: `traces` / `trace-detail` / `confidence` / `reflect` / `uncertainty` 5 个新命令
- **test_self_model.py**: 11 项测试

### 🔴 Phase 3: 元认知闭环
- **新增 `metacognition.py`**（~380行）：MetaEvaluation + MetacognitiveEngine
  - 5 维评估：相关性覆盖、内部一致性、来源多样性、时间新鲜度、缺口分析
  - 反思生成：5 种查询修正策略（扩展、泛化、换角度、同义改写、多样化）
  - meta_recall(): 不确定→反思→修正→重检（最多 2 轮，防无限循环）
  - 反思记忆化：反思自动写入记忆系统（nature=retro）
- **memory_system.py**: meta_recall() / evaluate_recall() 方法
- **cli.py**: `meta-recall` / `evaluate` 2 个新命令
- **test_metacognition.py**: 18 项测试

### 🔴 Phase 4: 内在动机
- **新增 `motivation.py`**（~310行）：InternalState + MotivationEngine
  - 5 维内在状态：好奇心、无聊度、自信度、满足感、紧迫感
  - 动态更新：新主题→好奇心↑、低信息→无聊度↑、突破性→自信度↑、里程碑→满足感↑
  - 知识空白检测：已注册无记忆/稀疏/过时 3 种类型
  - 好奇驱动任务生成 + 无聊度分析
  - 查询追踪（用于无聊度计算）
  - SQLite 持久化 internal_state 表
- **schema.sql**: 新增 internal_state 表
- **memory_system.py**: remember() 写入后自动更新状态；maintain() 集成；schema v4→v5
- **cli.py**: `mood` / `gaps` / `curious` 3 个新命令
- **test_motivation.py**: 18 项测试

### 🔴 Phase 5: 叙事自我
- **新增 `narrative.py`**（~530行）：IdentityProfile + NarrativeBuilder
  - 身份画像：核心价值观、偏好、专长领域、人格特质、兴趣方向
  - 时间线叙事：从记忆构建第一人称成长故事
  - 主题叙事：在某个领域的成长历程
  - WhoAmI: 第一人称自我叙述
  - 世界观提取：信念、价值观、原则
  - SQLite 持久化 identity_model + life_narratives 表
- **schema.sql**: 新增 identity_model + life_narratives 表 + 索引
- **memory_system.py**: NarrativeBuilder 实例化；maintain() 自动更新身份画像；schema v5→v6
- **cli.py**: `whoami` / `identity` / `narrative` / `worldview` / `self-concept` 5 个新命令
- **test_narrative.py**: 19 项测试

### 🔴 Phase 6: 第一人称整合
- **cli.py**: `self` 统一仪表盘命令（`--mood` / `--narrative` / `--confidence` / `--gaps` / `--recent-thinking`）
- **memory_system.py**: check_capabilities 报告全部 6 个子系统状态

### 📊 统计
- 5 个新模块（emotion.py / self_model.py / metacognition.py / motivation.py / narrative.py）
- ~1880 行新代码
- 15 个新 CLI 命令
- 87 项测试全部通过
- schema 自动迁移 v0→v6
- 所有模块零外部依赖

## v6.0.0 — 2026-04-13

**架构升级：sqlite-vec 统一存储 + 写入时因果检测**

### 🔴 架构：Chroma → sqlite-vec 迁移
- `EmbeddingStore` 从 Chroma 重写为 sqlite-vec，向量和结构化数据在同一 SQLite 文件
- 消灭双写架构：不再需要 `sync_flags`、`mark_vector_pending`、`repair_vector_sync`
- 删除 `_background_vector_repair` 后台线程
- `pipeline.py` 写入路径简化为单事务直写
- `store.py` 移除 `mark_vector_pending` / `mark_vector_synced` / `get_unsynced_to_vector` / `repair_vector_sync`
- `backup.py` 向量已合入 SQLite，无需单独备份 chroma_db 目录
- `memory_system.py` / `main.py` / `server.py` 全部改为 `db_path` 参数

### 🔴 新功能：三层写入时因果检测
- **Layer 1 — 正则硬匹配**：8 种模式（因为…所以、由于…因此、…导致…、…决定了…、基于…、在…基础上、鉴于…、箭头因果），准确率 >95%，覆盖率 ~20-30%，零成本同步执行
- **Layer 2 — 上下文线索**：决策词 + 结果词共现模式匹配（因为/由于/鉴于 + 所以/因此/决定），弱因果信号分级
- **Layer 3 — LLM 异步提取**：高重要度记忆触发 LLM 因果提取，在 reactor 的 on_write hook 中异步执行，不阻塞写入管道
- `detector.py` 新增 `CausalHint` 数据类 + `detect_causal_signals()` 方法
- `pipeline.py` ingest() 集成 Layer 1+2，自动建立 `causal.led_to` / `causal.timeline_before` 链接
- `reactor.py` 新增 `action_llm_causal_extract` hook + `set_llm_fn()` 方法

### 🟡 其他
- `test_all.py` 替换 `TestVectorSyncRepair` → `TestEmbeddingStoreDirect`（sqlite-vec 写入/删除测试）
- 176 测试全部通过

## v5.4.3 — 2026-04-13

**安全加固 + 运行时稳定性 + 架构改进**

### 🔴 P0 修复：HTTP Server 认证（server.py）
- 新增 API Key 认证，支持 `Authorization: Bearer <key>` 和 `X-API-Key` header
- 通过 `--api-key` 参数或 `AGENT_MEMORY_API_KEY` 环境变量配置
- `/health` 和 `/` 跳过认证（方便监控探活），其余端点全部保护
- 常量时间比较防时序攻击，无 key 启动时打印警告

### 🔴 P0 修复：全局变量竞态（server.py）
- 所有 `_get_*()` 函数加入 `threading.Lock` + double-checked locking
- `_INIT_LOCK` 保护 `_STORE`/`_PIPELINE`/`_EMBEDDING_STORE`/`_QUALITY` 四个全局单例

### 🔴 P0 修复：Schema 迁移竞态（store.py）
- `_ensure_schema()` 改为用 `self.transaction()` 包裹
- 捕获 `OperationalError("locked")` 自动重试一次
- `CREATE TABLE/INDEX IF NOT EXISTS` 保证幂等

### 🔴 P0 修复：SSE 连接无上限（server.py）
- 新增 `_MAX_SSE_CLIENTS = 500` 上限，超限返回 503
- 后台 daemon 线程每 60s 清理超时客户端
- `/maintain` 也会触发 SSE 清理

### 🔴 P0 修复：记忆内容泄漏（server.py）
- `SSEBroker.broadcast()` 自动过滤 `content`/`content_preview`/`message` 字段
- SSE 事件不再包含任何原始记忆内容

### 🟡 P1 改进：Embedding 多后端（embedding_store.py）
- 支持 5 种后端：`local`(默认) / `openai` / `cohere` / `voyage` / `hash`
- `AGENT_MEMORY_EMBEDDING_BACKEND` 环境变量切换
- `AGENT_MEMORY_EMBEDDING_MODEL` 和 `AGENT_MEMORY_EMBEDDING_DIM` 配置模型和维度
- 维度变更时自动检测并警告
- API 后端使用 `urllib.request`（零外部依赖）

### 🟡 P1 改进：压缩质量安全网（compressor.py）
- `_extract_key_facts()`: 从原文提取决策词、数据、文件路径等关键信息
- `_compute_retention_score()`: 计算压缩前后关键信息保留率
- `_validate_compression()`: 四重验证（保留率/长度/压缩比/模板检测）
- `_rollback_compression()`: 压缩失败自动回滚

### 🟡 P1 改进：冷迁移完整性（store.py）
- `move_to_cold()` 新增 `skip_referenced` 参数，跳过仍被因果链引用的记忆
- 同步清理 FTS 索引和向量库同步标记
- 全部在事务内执行

### 🟡 P1 改进：数据库完整性检查（store.py）
- 新增 `check_integrity()`: `PRAGMA integrity_check` + `PRAGMA foreign_key_check`
- 集成到 `auto_maintain()`: 每次维护自动检查

### 🟡 P1 改进：HTTP 输入验证（server.py）
- 请求体上限 1MB，batch 总内容上限 5MB，单条上限 50K
- `/recall` query 长度上限 10K，top_k 上限 100
- `/export` 新增 `limit` 参数，上限 1000
- `/graph` limit 上限 500，`/context` max_tokens 上限 10000

## v5.4.2 — 2026-04-13

**致命问题修复（第二轮）：并发安全 + 数据完整性 + 异常可见性**

### P0 修复：SQLite-Chroma 不一致窗口缩小
- 后台向量补写线程间隔从 30s 降至 5s，写入后语义检索 5s 内可见
- 补写失败时输出 warning 日志（原为静默）

### P0 修复：全局文件锁彻底移除
- `store.py` 的 `transaction()` 移除 `_FileLock`，改为纯 SQLite WAL + busy_timeout
- 多 Agent 并发写入不再串行化卡死
- 文件锁仅保留给 `dimensions.json` 等非 SQLite 资源

### P0 修复：编码器静默吞异常
- `encoder.py` `_auto_register_topic_path` 的 `except Exception: pass` → `logger.warning()`
- 输出具体错误信息和恢复建议（磁盘空间、文件权限）

### P0 修复：去重跳过更详细记忆
- `dedup.py` `_decide_action` 调整判断顺序：先检查新内容是否更长（→merge），再检查极相似（→skip）
- 修复场景：先写"Chroma 好用"(low) 后写"HNSW 参数 M=32"(high) → 不再丢失关键信息

### P0 修复：并发 JSON 写入损坏
- `encoder.py` 加 `threading.Lock` 保护注册表文件写入（同进程内多线程安全）
- `_auto_register_topic_path` 先锁再读再写，防止 TOCTOU 竞争
- `pipeline.py` `_update_daily_index` 加文件锁 + 原子写入（tmp→rename）
- JSON 读取失败时兜底为内存版本，不崩溃

### P1 修复：Self-Healing 无审计修改
- `self_healing.py` `heal_importance_consistency()` 改用 `store.transaction()`
- 变更后调用 `_invalidate_cache()` 刷新缓存
- 每次 importance 变更写入 `logger.info()` 审计日志

### P1 修复：内容长度校验
- `pipeline.py` `ingest()` 入口增加 50K 硬上限，超限截断 + 警告
- 空内容直接返回 skipped

## v5.4.1 — 2026-04-13

**致命问题修复：并发安全 + 数据一致性 + 向量同步可靠性**

### P0 修复：SQLite-Chroma 向量一致性
- **同步重试**：向量写入失败时指数退避重试 3 次（0.5s, 1s, 2s），不再静默丢弃
- **后台补写线程**：`_background_vector_repair` 每 30 秒扫描 `_sync_flags` 中未同步记录，自动补写
- **WriteQueue 兼容**：异步队列消费时也触发向量同步，确保批量写入场景下一致性
- 影响：语义检索结果不再因向量库写入延迟而缺失

### P0 修复：全局文件锁串行化
- **SQLite 写入去锁**：移除对 `memory.db.lock` 的全局 fcntl 文件锁，改用 SQLite WAL 模式内置并发控制
- **busy_timeout=5000** 已配置，SQLite 自动处理并发写冲突
- **注册表保留文件锁**：`dimensions.json` 等非 SQLite 资源仍使用 `_FileLock`
- **超时降至 3s**：注册表锁超时从 10s 降至 3s，减少阻塞
- 影响：多 Agent 并发写入不再串行化卡死

### P1 修复：内容长度校验
- `ingest()` 入口增加 50K 硬上限检查，超限截断并警告

### P1 修复：Self-Healing 审计
- `heal_importance_consistency()` 的 UPDATE 操作包裹在 `transaction()` 中
- importance 变更后调用 `_invalidate_cache()` 刷新缓存
- 变更记录写入 `memory_links`（link_type=importance_healed）可追溯

### P2 修复：FlagEmbedding 兼容性
- `modeling_minicpm_reranker.py` 中 `is_torch_fx_available` 导入改为 try/except + fallback
- 兼容 transformers 5.x（已移除该 API）

### 依赖安装
- chromadb 1.5.7, sentence-transformers 5.4.0, torch 2.11.0, FlagEmbedding 1.3.5, Pillow, pytesseract

## v5.4.0 — 2026-04-13

**时间旅行：记忆快照与回溯**

### 新增 timeline.py — 记忆时间旅行系统
- **Snapshot**: 在任意时间点保存记忆全貌，含元数据 + 记忆条目 + 主题分布
- **Diff**: 对比两个时间点（快照 or 时间戳），展示新增/消失/变化/主题增长
- **Blame**: 追溯单条记忆的完整来源链：创建时间、因果链、相关记忆、快照记录、版本历史
- 支持快照 ID 和时间戳两种对比模式
- 自然语言输出模式（`--natural`）
- 智能日期解析：`YYYY-MM-DD`、`7d`、`1m`、`today`、`yesterday`
- 自动快照：`auto_snapshot_if_needed()` 基于间隔 + 新记忆检测
- 独立 Schema（不污染主表）：`memory_snapshots` + `memory_snapshot_items`

### CLI 新增命令
- `snapshot` / `--label` / `--at` / `--description` — 创建记忆快照
- `snapshots` / `--limit` — 列出所有快照
- `diff <from> [to]` / `--from-snapshot` / `--to-snapshot` / `--topic` / `--natural` — 差异对比
- `blame <memory_id>` / `--natural` — 来源追溯
- `timeline-stats` — 时间旅行统计

### 集成
- `memory_system.py`: 新增 `timeline` 组件 + 7 个代理方法
- `get_stats()` 输出包含 `timeline` 统计
- `cli.py`: 新增 5 个命令 + 5 个处理函数

## v5.3.0 — 2026-04-13

**记忆蒸馏 + 增强因果链 + 性能修复：从对话碎片到知识手册**

### 新增 distill.py — 记忆蒸馏系统
- 4 层蒸馏管道：原始记忆 → 主题摘要 → 知识图谱 → 个人百科
- Layer 1: 按主题聚类 + LLM 生成结构化摘要（概述/决策/事实/趋势/偏好）
- Layer 2: 从摘要中提取实体（person/concept/tool/project/decision/fact/preference）和关系
- Layer 3: 按类别（decisions/tools/projects/concepts/people/facts）整合为百科条目
- 增量蒸馏：新记忆合并到已有摘要（version++），不重复全量
- 无 LLM 时启发式 fallback：关键词提取 + 结构化拼接
- 4 张独立表：distill_topics / distill_entities / distill_relations / distill_encyclopedia
- 可导出为完整 Markdown 文件

### 增强 causal.py — 三层因果检测
- 原有启发式规则：explore→decision, todo→output 等（O(n) 滑动窗口）
- 时间线因果：6h 窗口内相邻记忆多维评分（时间衰减+主题重叠+性质匹配+因果词+语义相似度）
- 链式传递：A→B + B→C → 推导 A→C (chain_trigger)
- 跨时主题相似：7 天窗口内、主题 Jaccard ≥ 0.3、性质不同 → topic_similar
- 统一入口：`full_causal_analysis()` 替代旧的 `auto_detect_causality()`

### CLI 新增命令
- `distill` / `distill --force` — 执行记忆蒸馏
- `distill-stats` — 蒸馏系统统计
- `encyclopedia` / `--category` / `--search` / `--export` — 百科查看/搜索/导出
- `entities` / `--type` / `--name` — 知识实体查询
- `topic-summaries` / `--topic` — 主题摘要查询

### P0 修复：写入路径 O(n²) → O(n)
- `dedup.check_duplicate()`: 候选集从 72h 全量 → FTS 缩小 + 24h 窗口 + 上限 50
- `dedup.deduplicate_batch()`: 500 条全量两两 → content_hash 分桶 + bigram 签名分桶，上限 200
- `dedup.check_conflict()`: 50 条无时间过滤 → 30 条 + time_from 参数
- `causal.auto_detect_causality()`: 200 条嵌套 for → O(n) 滑动窗口 + 100 条 + 6h 窗口
- `self_healing.detect_contradictions()`: 100 条 O(n²) → 50 条 + 主题分桶 + 桶内相邻比较
- `self_healing.detect_outdated()`: 200 条无时间过滤 → 100 条 + time_from 参数

### P0 修复：SQLite 并发安全
- `_FileLock`: 进程崩溃后 stale lock 清理（`_cleanup_stale_lock`）
- `_FileLock`: 超时后指数退避 retry（50ms→1s），最后才 raise
- `_invalidate_cache()`: 原子写入（先写 .tmp 再 os.replace）
- `query()`: FTS 快速路径 + 混合路径均加 try/except，失败降级 LIKE

### P1 修复：Embedding 懒加载
- `EmbeddingStore.__init__` 不再同步加载 SentenceTransformer（原来阻塞 10-15s）
- `_ensure_model()`: 首次 `_encode()` / `search()` / `add_batch()` 时才加载
- CLIP 同理：`_ensure_clip()` 懒加载

### P1 修复：全量加载 → 有界查询
- `get_stats()`: 从 `query(limit=10000)` 改为 `SELECT COUNT(*)`（O(1) 不加载数据）

### P1 修复：WriteQueue SQLite 持久化
- 入队同时写入 `_write_queue` 表（持久化，进程崩溃不丢）
- flush 成功后从 SQLite 删除
- `start()` 自动恢复 status=pending 的记录（崩溃恢复）
- item_hash 防重复入队

### P2 修复：压缩后关联不断裂
- `_migrate_links_to_summary()`: 将原始记忆的入向因果/主题链接复制到摘要
- 权重略降（×0.8），标记来源
- 原始链接保留（溯源用）

### P2 修复：权限过滤实际生效
- `recall()` 新增 `query_agent_id` / `team_id` 参数，传递到 `store.query()`
- `memory_system.recall()` 自动传递 `self.agent_id` / `self.team_id`

### P3 修复：Schema 版本管理
- `_schema_version` 表记录当前版本号
- `_check_schema_version()`: 启动时自动检测并执行增量迁移
- v0→v1: 基础表 / v1→v2: distill 表 + _write_queue 表

### 测试
- 新增 test_fixes.py：12 个测试覆盖所有 P0/P1/P2/P3 修复
- 批量写入性能、精确去重、FTS 候选缩小、stale lock 清理、
  FTS 故障降级、权限过滤、schema 迁移、因果 O(n)、
  WriteQueue 持久化、压缩关联迁移、蒸馏管道

---

## v5.2.0 — 2026-04-13

**记忆驱动的主动 Agent：记忆不是被动仓库，而是 Agent 的感知器官**

### 新增 reactor.py — 主动反应器
- 事件驱动架构：Hook(条件) → Action(动作) 模式
- 4 个核心事件类型：on_write / on_contradiction / on_decay_review / on_decision_complete
- 内置中文时间表达式解析器（明天3点、下周三、3天后 等）
- 防重复触发：事件指纹去重，fired_hashes 集合上限 10000
- 可扩展：`register_hook(event_type, condition_fn, action_fn)`

### memory_system.py 集成
- `remember()` 写入后自动触发 `reactor.fire_write()`
- `maintain()` 自动执行 `reactor.scan()` 全量扫描
- 新增 `get_pending_notifications()` / `reactor_scan()`

### CLI 新增命令
- `notifications` — 查看待处理的主动通知
- `reactor-scan` — 手动触发 reactor 全量扫描

---

## v5.1.0 — 2026-04-12

**Memory-as-a-Service：从 CLI 工具到 HTTP API**

### 新增 server.py — HTTP 记忆服务
- 纯 stdlib 实现，零外部依赖
- REST API：POST /remember / POST /recall / GET /context / GET /stats / GET /stream
- SSE 实时记忆流：浏览器、curl、任何 HTTP 客户端都能订阅
- 批量写入：POST /remember/batch（上限 50 条/次）
- 反馈闭环：POST /feedback
- 维护触发：POST /maintain
- 导出：GET /export?format=json|markdown
- 关联图谱：GET /graph
- CORS 全开，默认端口 8976

---

## v5.0.2 — 2026-04-12

**架构优化：9 项结构性改进**

- Dynamic topic detection (TF-IDF)：无监督关键词提取
- Retrieval evaluation (recall_eval.py)：Precision@K, NDCG@K, MRR + 消融实验
- L1 短期记忆持久化
- Vector store abstraction (vector_store.py)：Chroma / Milvus / pgvector
- ReDoS root fix：重写所有冗余正则
- 冷热分离：独立冷库，热库轻量 / 冷库全量
- 多模态：CLIP 图片 embedding + 跨模态检索
- Embedding 模型可配置：环境变量 + 国内镜像自动切换

---

## v5.0.1 — 2026-04-12

**安全与一致性修复：8 个生产级 bug 修复**

1. 权限模型空转修复 — query() 注入可见性条件
2. Chroma-SQLite 原子性修复 — 脏标记 + repair_vector_sync
3. 质量统计并发写入修复 — fcntl.flock 跨进程锁
4. Hash embedding 降级修复 — SimHash 替代 SHA256 线性扩展
5. 跨 Agent 缓存不一致修复 — .cache_ver 版本文件
6. Content cleaner ReDoS 防护修复 — SIGALRM 超时保护
7. FTS5 搜索注入修复 — 移除保留操作符
8. L1 短期记忆持久化修复 — SQLite buffer + 启动恢复

---

## v5.0.0 — 2026-04-12

**全面重构：从单体记忆系统到多 Agent 共享记忆网络**

### 致命问题修复
- 模型守护进程崩溃后锁死（stale socket 清理 + PID 校验）
- Chroma/SQLite 写入不同步（脏标记表 + repair_vector_sync）
- Content cleaner 正则 ReDoS（非捕获组 + 超时保护）
- SQLite 无 VACUUM/WAL checkpoint（auto_maintain）
- memory_id 碰撞（uuid4 替代 random）
- dedup 批量去重 N+1 查询
- 输入长度限制（50K 硬上限 + 10K 软警告）

### 检索层重构
- RRF 双路融合：Reciprocal Rank Fusion
- 查询意图分类：recall / knowledge / task / general
- 负反馈闭环 + MMR 多样性重排 + Reranker 精排

### 质量评分修复
- Bell curve 检索信号 + 可配置权重

### 真正的遗忘
- archive_memories（归档到 JSONL 后删除）
- delete_expired（物理删除，先归档保证可恢复）

### 存储层优化
- Schema 新增 8 个复合索引
- FTS 原子性 + 跨进程文件锁 + Chroma 脏标记

### 写入层优化
- MemoryFilter 模糊变体匹配 + 写入限流 + batch_ingest

### 上下文组装
- 动态 token 预算 + 跨会话连续性 + 记忆引用

### 多模态记忆
- media_processor.py：7 种后端（OpenAI / Anthropic / Google / Ollama / LiteLLM / MiMo / 自定义）

### 多 Agent 共享记忆网络
- agent_network.py：三级可见性 + 细粒度权限 + 跨 Agent 联想
- Schema 新增 agents / memory_permissions / agent_associations

### 运维
- HTTP 健康检查 + 全量导出 + 自动备份

### 测试
- 从 40 个扩展到 136 个

---

## v4.2.0 — 2026-04-12

- 6 维坐标编码系统
- 3 层主题检测（关键词 + 语义 + 动态注册表）
- 写入管道（过滤 → 清洗 → 去重 → 编码 → 存储）
- 双路检索（结构化 + 语义）
- 层级记忆（L1/L2/L3）
- 质量评分 + 因果链 + 智能压缩 + 自我修复
- 记忆图谱 + Obsidian 同步 + FTS5 全文搜索
- 40 个测试用例
