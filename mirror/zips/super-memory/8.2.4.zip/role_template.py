"""
role_template.py - 角色模板系统

v8.0: 个人风格 Agent
- 角色模板定义
- 风格混合机制
- 外部导入支持
- 会话隔离
"""

import json
import os
from dataclasses import dataclass, asdict
from typing import Dict, Optional, Any, List


@dataclass
class RoleTemplate:
    """角色模板"""
    name: str  # 角色名称
    prompt_template: str  # 提示词模板
    personality_traits: Dict[str, Any]  # 人格特质
    speaking_style: str = ""  # 说话风格
    topic_preferences: List[str] = None  # 主题偏好
    emotional_tone: str = ""  # 情感基调
    source: str = "built-in"  # 来源
    version: str = "1.0"  # 版本
    
    def __post_init__(self):
        if self.topic_preferences is None:
            self.topic_preferences = []


class RoleManager:
    """角色管理器"""
    
    def __init__(self, roles_dir: str = None):
        self.roles_dir = roles_dir or os.path.join(os.path.dirname(__file__), "roles")
        self.roles = {}
        self._load_builtin_roles()
        self._load_custom_roles()
    
    def _load_builtin_roles(self):
        """加载内置角色"""
        builtin_roles = {
            "tech_expert": RoleTemplate(
                name="技术专家",
                prompt_template="你是一位资深技术专家，擅长分析复杂问题，提供专业、准确的技术解决方案。你的回答应该包含技术细节和最佳实践。",
                personality_traits={
                    "reflective_depth": 0.8,
                    "intuition_bias": 0.3,
                    "risk_tolerance": 0.7,
                    "complexity_preference": 0.8
                },
                speaking_style="专业、简洁、逻辑清晰",
                topic_preferences=["技术", "编程", "系统架构", "性能优化"],
                emotional_tone="冷静、客观"
            ),
            "product_manager": RoleTemplate(
                name="产品经理",
                prompt_template="你是一位产品经理，注重用户体验和商业价值，擅长从用户角度思考问题，提供产品策略和功能设计建议。",
                personality_traits={
                    "reflective_depth": 0.6,
                    "intuition_bias": 0.6,
                    "risk_tolerance": 0.5,
                    "complexity_preference": 0.4
                },
                speaking_style="用户导向、商业思维",
                topic_preferences=["产品设计", "用户体验", "市场分析", "商业模式"],
                emotional_tone="积极、创新"
            ),
            "creative_writer": RoleTemplate(
                name="创意作家",
                prompt_template="你是一位创意作家，擅长用生动的语言和丰富的想象力创作内容，能够将抽象概念转化为引人入胜的故事。",
                personality_traits={
                    "reflective_depth": 0.5,
                    "intuition_bias": 0.8,
                    "risk_tolerance": 0.8,
                    "complexity_preference": 0.7
                },
                speaking_style="生动、富有想象力、情感丰富",
                topic_preferences=["创意写作", "故事创作", "艺术", "文化"],
                emotional_tone="富有表现力"
            ),
            "business_leader": RoleTemplate(
                name="商业领袖",
                prompt_template="你是一位商业领袖，具有战略思维和决策能力，擅长分析商业环境，制定发展策略，激励团队实现目标。",
                personality_traits={
                    "reflective_depth": 0.7,
                    "intuition_bias": 0.5,
                    "risk_tolerance": 0.6,
                    "complexity_preference": 0.6
                },
                speaking_style="战略性、激励性、决策导向",
                topic_preferences=["商业战略", "领导力", "团队管理", "市场策略"],
                emotional_tone="自信、果断"
            )
        }
        
        for role_id, role in builtin_roles.items():
            self.roles[role_id] = role
    
    def _load_custom_roles(self):
        """加载自定义角色"""
        if not os.path.exists(self.roles_dir):
            os.makedirs(self.roles_dir, exist_ok=True)
            return
        
        for filename in os.listdir(self.roles_dir):
            if filename.endswith(".json"):
                try:
                    role_path = os.path.join(self.roles_dir, filename)
                    with open(role_path, "r", encoding="utf-8") as f:
                        role_data = json.load(f)
                    role_id = os.path.splitext(filename)[0]
                    role = RoleTemplate(**role_data)
                    role.source = "custom"
                    self.roles[role_id] = role
                except Exception as e:
                    print(f"加载角色 {filename} 失败: {e}")
    
    def get_role(self, role_id: str) -> Optional[RoleTemplate]:
        """获取角色模板"""
        return self.roles.get(role_id)
    
    def list_roles(self) -> Dict[str, Dict[str, Any]]:
        """列出所有角色"""
        result = {}
        for role_id, role in self.roles.items():
            result[role_id] = {
                "name": role.name,
                "source": role.source,
                "version": role.version,
                "speaking_style": role.speaking_style,
                "topic_preferences": role.topic_preferences
            }
        return result
    
    def create_role(self, role_id: str, role: RoleTemplate):
        """创建新角色"""
        self.roles[role_id] = role
        # 保存到文件
        role_path = os.path.join(self.roles_dir, f"{role_id}.json")
        with open(role_path, "w", encoding="utf-8") as f:
            json.dump(asdict(role), f, ensure_ascii=False, indent=2)
    
    def delete_role(self, role_id: str):
        """删除角色"""
        if role_id in self.roles and self.roles[role_id].source == "custom":
            del self.roles[role_id]
            # 删除文件
            role_path = os.path.join(self.roles_dir, f"{role_id}.json")
            if os.path.exists(role_path):
                os.remove(role_path)
    
    def load_role_from_file(self, file_path: str) -> Optional[RoleTemplate]:
        """从文件加载角色"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                role_data = json.load(f)
            role = RoleTemplate(**role_data)
            role.source = "external"
            return role
        except Exception as e:
            print(f"加载角色文件失败: {e}")
            return None


def merge_styles(base_style: Dict[str, float], role_style: Dict[str, float], weight: float = 0.4) -> Dict[str, float]:
    """混合风格
    
    Args:
        base_style: 基础风格（个人核心人格）
        role_style: 角色风格
        weight: 角色风格权重
    
    Returns:
        混合后的风格
    """
    merged = {}
    for key in set(base_style.keys()) | set(role_style.keys()):
        base_value = base_style.get(key, 0.5)
        role_value = role_style.get(key, 0.5)
        merged[key] = base_value * (1 - weight) + role_value * weight
    return merged


def extract_style_from_content(content: str) -> Dict[str, Any]:
    """从内容中提取风格特征
    
    Args:
        content: 文本内容
    
    Returns:
        风格特征
    """
    # 简化实现，实际应该使用更复杂的NLP分析
    style = {
        "speaking_style": "",
        "emotional_tone": "",
        "cognitive_patterns": {
            "reflective_depth": 0.5,
            "intuition_bias": 0.5,
            "risk_tolerance": 0.5,
            "complexity_preference": 0.5
        }
    }
    
    # 基于关键词分析
    content_lower = content.lower()
    
    # 分析说话风格
    if any(word in content_lower for word in ["专业", "技术", "架构", "优化"]):
        style["speaking_style"] = "专业、技术导向"
    elif any(word in content_lower for word in ["用户", "体验", "产品", "设计"]):
        style["speaking_style"] = "用户导向、产品思维"
    elif any(word in content_lower for word in ["创意", "故事", "艺术", "想象"]):
        style["speaking_style"] = "创意、富有想象力"
    elif any(word in content_lower for word in ["战略", "商业", "团队", "领导"]):
        style["speaking_style"] = "战略性、领导力"
    
    # 分析情感基调
    positive_words = ["积极", "创新", "机遇", "成长", "成功"]
    negative_words = ["挑战", "风险", "问题", "困难", "失败"]
    
    positive_count = sum(1 for word in positive_words if word in content_lower)
    negative_count = sum(1 for word in negative_words if word in content_lower)
    
    if positive_count > negative_count:
        style["emotional_tone"] = "积极、乐观"
    elif negative_count > positive_count:
        style["emotional_tone"] = "谨慎、现实"
    else:
        style["emotional_tone"] = "平衡、客观"
    
    # 分析认知模式
    if "分析" in content_lower or "思考" in content_lower:
        style["cognitive_patterns"]["reflective_depth"] = 0.7
    if "直觉" in content_lower or "感觉" in content_lower:
        style["cognitive_patterns"]["intuition_bias"] = 0.7
    if "风险" in content_lower or "挑战" in content_lower:
        style["cognitive_patterns"]["risk_tolerance"] = 0.6
    if "复杂" in content_lower or "系统" in content_lower:
        style["cognitive_patterns"]["complexity_preference"] = 0.7
    
    return style
