"""
emotion.py - 情感信号分析器
基于规则 + 词典，从记忆内容中提取情感维度。

规则层做基线，LLM 层处理歧义和上下文理解。

Phase 1 核心模块（v7.1 增强：LLM 混合分析 + 结构化可观测性）。
"""

import re
import json
import time
import logging
from typing import Optional, Callable

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════
# 词典（中英双语）
# ═══════════════════════════════════════════════════════

# 正面词 → valence 正向贡献
POSITIVE_WORDS_CN = {
    # 高正面
    "成功", "突破", "优秀", "完美", "出色", "精彩", "惊喜", "高效",
    "解决了", "搞定了", "完成了", "实现了", "攻克", "突破性",
    "好用", "稳定", "流畅", "优雅", "漂亮", "厉害", "强", "赞",
    "开心", "满意", "值得", "幸运", "顺利", "进步", "提升", "优化",
    "新增", "支持", "兼容", "改善", "升级", "加强",
}
POSITIVE_WORDS_EN = {
    "great", "excellent", "amazing", "perfect", "solved", "fixed",
    "breakthrough", "success", "improved", "optimized", "works",
    "love", "awesome", "fantastic", "brilliant", "elegant",
}

# 负面词 → valence 负向贡献
NEGATIVE_WORDS_CN = {
    # 高负面
    "失败", "崩溃", "bug", "错误", "问题", "故障", "挂了", "炸了",
    "不行", "糟糕", "失望", "困难", "麻烦", "卡住", "卡死", "死锁",
    "超时", "泄漏", "异常", "警告", "风险", "隐患", "漏洞", "缺陷",
    "回滚", "回退", "放弃", "删除", "移除", "废弃", "弃用",
    "慢", "卡", "坑", "踩坑", "绕过", "workaround", "临时",
}
NEGATIVE_WORDS_EN = {
    "failed", "error", "bug", "crash", "broken", "issue", "problem",
    "terrible", "horrible", "disappointed", "difficult", "slow",
    "timeout", "leak", "exception", "warning", "risk", "rollback",
    "workaround", "hack", "deprecated", "removed",
}

# 高唤醒词 → arousal 正向贡献
HIGH_AROUSAL_WORDS = {
    # 感叹/激动
    "！", "！!", "卧槽", "牛", "太棒了", "终于", "竟然", "居然",
    "紧急", "马上", "立刻", "赶紧", "快", "严重", "重大", "关键",
    "！！！", "!!!", "wtf", "omg", "holy",
    # 冲突/危机
    "崩溃", "挂了", "炸了", "出事了", "不行了", "救命",
    "突破", "搞定", "解决", "攻克",
}

# 情感显著性关键词映射
SIGNIFICANCE_KEYWORDS = {
    "breakthrough": {"突破", "突破性", "攻克", "首创", "第一次", "里程碑", "breakthrough", "milestone"},
    "crisis": {"崩溃", "故障", "事故", "紧急", "严重", "crisis", "outage", "incident"},
    "milestone": {"发布", "上线", "完成", "交付", "里程碑", "launched", "shipped", "released"},
}


class EmotionAnalyzer:
    """
    情感信号分析器（v7.1 增强版）。

    分析维度：
    - valence: 效价 [-1.0, 1.0]（负面 → 正面）
    - arousal: 唤醒度 [0.0, 1.0]（平静 → 激动）
    - significance: 情感标签（trivial / notable / important / breakthrough / crisis / milestone）
    - confidence: 分析置信度 [0.0, 1.0]
    - nuance: 细腻度标签（直白 / 含蓄 / 矛盾 / 讽刺）

    架构：规则层（快速基线）→ LLM 层（歧义精修）→ 输出
    - 规则层处理明确信号，速度快、成本低
    - LLM 层处理"虽然…但是…"类矛盾句、反讽、隐含情感
    - 两层结果冲突时，以 LLM 为准但保留规则层 trace

    可观测性：每次分析返回 trace 字段，记录决策路径。
    """

    # 默认值
    DEFAULT_VALENCE = 0.0
    DEFAULT_AROUSAL = 0.2
    DEFAULT_SIGNIFICANCE = "notable"
    DEFAULT_CONFIDENCE = 0.5

    # LLM 触发阈值：规则层冲突信号超过此值时调用 LLM
    LLM_TRIGGER_CONFLICT_RATIO = 0.3  # pos/neg 比例在 0.3-0.7 之间 = 模糊
    LLM_TRIGGER_MIN_HITS = 2          # 至少有 2 个信号才触发 LLM

    # 性质 → 基线 valence/arousal 偏移
    NATURE_BASELINES = {
        "breakthrough": {"valence": 0.6, "arousal": 0.7, "significance": "breakthrough"},
        "decision":     {"valence": 0.1, "arousal": 0.3, "significance": "important"},
        "task":         {"valence": 0.0, "arousal": 0.3, "significance": "notable"},
        "todo":         {"valence": -0.1, "arousal": 0.2, "significance": "notable"},
        "output":       {"valence": 0.3, "arousal": 0.3, "significance": "important"},
        "log":          {"valence": 0.0, "arousal": 0.1, "significance": "trivial"},
        "chat":         {"valence": 0.0, "arousal": 0.1, "significance": "trivial"},
        "draft":        {"valence": 0.0, "arousal": 0.1, "significance": "trivial"},
        "note":         {"valence": 0.05, "arousal": 0.15, "significance": "notable"},
        "retro":        {"valence": 0.0, "arousal": 0.2, "significance": "notable"},
        "explore":      {"valence": 0.1, "arousal": 0.2, "significance": "notable"},
        "config":       {"valence": 0.0, "arousal": 0.05, "significance": "trivial"},
        "ask":          {"valence": 0.0, "arousal": 0.15, "significance": "trivial"},
        "archive":      {"valence": 0.0, "arousal": 0.05, "significance": "trivial"},
    }

    def __init__(self, llm_fn: Callable = None):
        """
        参数:
            llm_fn: LLM 函数 fn(prompt: str) -> str。
                     用于处理规则层无法判断的歧义内容。
                     不传则降级为纯规则模式。
        """
        self.llm_fn = llm_fn

        # 预编译正则
        self._pos_pattern_cn = self._build_pattern(POSITIVE_WORDS_CN)
        self._neg_pattern_cn = self._build_pattern(NEGATIVE_WORDS_CN)
        self._pos_pattern_en = self._build_pattern(POSITIVE_WORDS_EN)
        self._neg_pattern_en = self._build_pattern(NEGATIVE_WORDS_EN)
        self._high_arousal_pattern = self._build_pattern(HIGH_AROUSAL_WORDS)

        # 转折连词检测（用于矛盾句识别）
        self._contrast_markers = re.compile(
            r"但是|但|然而|不过|可是|虽然.*?但是|尽管.*?还是|"
            r"but|however|although|though|yet|despite",
            re.IGNORECASE,
        )

    @staticmethod
    def _build_pattern(words: set) -> re.Pattern:
        """将词集合编译为正则（按长度降序，长词优先匹配）"""
        sorted_words = sorted(words, key=len, reverse=True)
        escaped = [re.escape(w) for w in sorted_words if w]
        if not escaped:
            return re.compile(r"(?!)")  # 永远不匹配
        return re.compile("|".join(escaped))

    def analyze(
        self,
        content: str,
        importance: str = "medium",
        nature_code: str = None,
    ) -> dict:
        """
        分析内容的情感信号（v7.1 增强版）。

        参数:
            content: 记忆内容
            importance: 重要度 (high/medium/low)
            nature_code: 性质 code (decision/task/... 等)

        返回:
            {
                "valence": float,       # [-1.0, 1.0]
                "arousal": float,       # [0.0, 1.0]
                "significance": str,    # trivial/notable/important/breakthrough/crisis/milestone
                "confidence": float,    # [0.0, 1.0]
                "nuance": str,          # 直白/含蓄/矛盾/讽刺/不明
                "trace": dict,          # 可观测性：决策路径
            }
        """
        t_start = time.monotonic()
        trace = {"steps": [], "rule_valence": None, "llm_valence": None, "final_source": "rules"}

        if not content or not content.strip():
            return {
                "valence": self.DEFAULT_VALENCE,
                "arousal": self.DEFAULT_AROUSAL,
                "significance": self.DEFAULT_SIGNIFICANCE,
                "confidence": 0.1,
                "nuance": "不明",
                "trace": {"steps": ["empty_input"], "final_source": "default"},
            }

        content_lower = content.lower()

        # ── Valence 计算（规则层）──────────────────────
        pos_hits = (
            self._pos_pattern_cn.findall(content)
            + self._pos_pattern_en.findall(content_lower)
        )
        neg_hits = (
            self._neg_pattern_cn.findall(content)
            + self._neg_pattern_en.findall(content_lower)
        )
        pos_count = len(pos_hits)
        neg_count = len(neg_hits)

        trace["steps"].append(f"rules: pos={pos_count} ({pos_hits[:5]}), neg={neg_count} ({neg_hits[:5]})")

        total_hits = pos_count + neg_count
        if total_hits > 0:
            raw_valence = (pos_count - neg_count) / total_hits  # [-1, 1]
        else:
            raw_valence = 0.0

        # 性质基线偏移
        baseline = self.NATURE_BASELINES.get(nature_code or "", {"valence": 0.0, "arousal": 0.15, "significance": "notable"})
        rule_valence = self._clamp(0.6 * raw_valence + 0.4 * baseline["valence"], -1.0, 1.0)

        # ── 矛盾/歧义检测 + 子句分割（v7.1: Issue 2 修复）─────────
        nuance = "直白"
        is_contrastive = bool(self._contrast_markers.search(content))
        subclause_valence = None

        # 子句分割：转折连词处切分，后半句权重更高
        if is_contrastive:
            subclause_valence = self._analyze_contrast_clauses(content)

        # 子句分割结果融合
        if subclause_valence is not None:
            rule_valence = self._clamp(0.4 * rule_valence + 0.6 * subclause_valence, -1.0, 1.0)
            trace["steps"].append(f"subclause_valence={subclause_valence:.3f}, blended={rule_valence:.3f}")

        trace["rule_valence"] = round(rule_valence, 3)

        # 计算冲突比例
        conflict_ratio = 0.0
        if total_hits >= self.LLM_TRIGGER_MIN_HITS:
            minority = min(pos_count, neg_count)
            conflict_ratio = minority / total_hits

        needs_llm = (
            self.llm_fn is not None
            and (is_contrastive or conflict_ratio > self.LLM_TRIGGER_CONFLICT_RATIO)
            and total_hits >= self.LLM_TRIGGER_MIN_HITS
        )

        trace["steps"].append(
            f"contrast={is_contrastive}, conflict_ratio={conflict_ratio:.2f}, "
            f"needs_llm={needs_llm}"
        )

        # ── LLM 精修层 ────────────────────────────────
        valence = rule_valence
        llm_confidence = None

        if needs_llm:
            try:
                llm_result = self._analyze_with_llm(content, rule_valence)
                if llm_result:
                    llm_valence = llm_result.get("valence", rule_valence)
                    llm_confidence = llm_result.get("confidence", 0.6)
                    llm_nuance = llm_result.get("nuance", "不明")

                    trace["llm_valence"] = round(llm_valence, 3)
                    trace["steps"].append(
                        f"llm: valence={llm_valence:.3f}, nuance={llm_nuance}, "
                        f"confidence={llm_confidence:.2f}"
                    )

                    # LLM 与规则冲突时，以 LLM 为准（加权融合）
                    if abs(llm_valence - rule_valence) > 0.3:
                        # 高冲突：信任 LLM 70%
                        valence = 0.3 * rule_valence + 0.7 * llm_valence
                        trace["final_source"] = "llm_override"
                        trace["steps"].append(f"high_conflict: blended={valence:.3f}")
                    elif abs(llm_valence - rule_valence) > 0.1:
                        # 低冲突：平均融合
                        valence = 0.5 * rule_valence + 0.5 * llm_valence
                        trace["final_source"] = "llm_blend"
                    else:
                        # 一致：信任规则（更快）
                        trace["final_source"] = "rules_confirmed_by_llm"

                    nuance = llm_nuance
            except Exception as e:
                logger.debug(f"LLM 情感分析失败，降级为规则: {e}")
                trace["steps"].append(f"llm_error: {e}")

        # 无 LLM 时的 nuance 推断
        if not needs_llm or nuance == "不明":
            if is_contrastive and conflict_ratio > 0.2:
                nuance = "矛盾"
            elif conflict_ratio > 0.4:
                nuance = "含蓄"
            else:
                nuance = "直白"

        valence = self._clamp(valence, -1.0, 1.0)

        # ── Arousal 计算 ──────────────────────────────
        arousal_signals = 0

        # 感叹号密度
        excl_count = content.count("!") + content.count("！")
        arousal_signals += min(excl_count * 0.1, 0.3)

        # 问号密度
        q_count = content.count("?") + content.count("？")
        arousal_signals += min(q_count * 0.05, 0.15)

        # 高唤醒词
        ha_count = len(self._high_arousal_pattern.findall(content))
        arousal_signals += min(ha_count * 0.15, 0.4)

        # 内容长度（极短 = 可能是激动的感叹，极长 = 可能是平静的叙述）
        char_count = len(content)
        if char_count < 10:
            arousal_signals += 0.1  # 短消息偏激动
        elif char_count > 500:
            arousal_signals -= 0.05  # 长消息偏平静

        raw_arousal = self._clamp(arousal_signals, 0.0, 0.8)
        arousal = self._clamp(0.5 * raw_arousal + 0.5 * baseline["arousal"], 0.0, 1.0)

        # ── Significance 计算 ─────────────────────────
        significance = baseline["significance"]

        # importance 覆盖（v7.1: 修复 high 提升链）
        if importance == "high":
            # high 重要度：至少提升到 important
            if significance in ("trivial", "notable"):
                significance = "important"
        elif importance == "low":
            if significance in ("important", "breakthrough", "crisis"):
                significance = "notable"

        # 关键词覆盖
        for sig, keywords in SIGNIFICANCE_KEYWORDS.items():
            if any(kw in content for kw in keywords):
                significance = sig
                break

        # ── Confidence 计算 ──────────────────────────
        confidence = 0.5  # 基线

        # 长度加分（有实质内容）
        if char_count > 50:
            confidence += 0.15
        if char_count > 200:
            confidence += 0.1
        if char_count > 500:
            confidence += 0.05

        # 有结构（列表、标题）→ 更高质量
        if re.search(r"^[-*•]\s", content, re.MULTILINE):
            confidence += 0.1
        if re.search(r"^#{1,3}\s", content, re.MULTILINE):
            confidence += 0.1
        if "```" in content:
            confidence += 0.05  # 有代码块

        # 有明确信息（数字、专有名词）
        if re.search(r"\d+", content):
            confidence += 0.05

        # importance 加分
        if importance == "high":
            confidence += 0.15
        elif importance == "low":
            confidence -= 0.1

        # 矛盾句降权（规则层不确定）
        if nuance == "矛盾":
            confidence *= 0.8

        # LLM 确认加分
        if llm_confidence is not None:
            confidence = 0.6 * confidence + 0.4 * llm_confidence

        confidence = self._clamp(confidence, 0.1, 1.0)

        # ── 可观测性 ──────────────────────────────────
        elapsed_ms = (time.monotonic() - t_start) * 1000
        trace["elapsed_ms"] = round(elapsed_ms, 2)
        trace["valence"] = round(valence, 3)
        trace["arousal"] = round(arousal, 3)
        trace["significance"] = significance
        trace["nuance"] = nuance
        trace["confidence"] = round(confidence, 3)

        if trace["final_source"].startswith("llm"):
            logger.debug(
                f"Emotion LLM invoked: rule={trace['rule_valence']:.2f} → "
                f"final={valence:.2f} ({trace['final_source']}), "
                f"nuance={nuance}, {elapsed_ms:.1f}ms"
            )

        return {
            "valence": round(valence, 3),
            "arousal": round(arousal, 3),
            "significance": significance,
            "confidence": round(confidence, 3),
            "nuance": nuance,
            "trace": trace,
        }

    @staticmethod
    def _clamp(value: float, min_val: float, max_val: float) -> float:
        return max(min_val, min(max_val, value))

    def _analyze_with_llm(self, content: str, rule_valence: float) -> Optional[dict]:
        """
        调用 LLM 进行深层情感分析。

        用于规则层无法判断的歧义内容：
        - "虽然有缺陷但方向是对的"（矛盾句）
        - "这个方案"（反讽）
        - "还行吧"（含蓄表达）

        返回: {"valence": float, "confidence": float, "nuance": str} 或 None
        """
        if not self.llm_fn:
            return None

        prompt = (
            "分析以下文本的情感倾向。返回 JSON，不要输出其他内容。\n\n"
            "维度：\n"
            "- valence: 效价 [-1.0, 1.0]，-1=极负面，0=中性，1=极正面\n"
            "- nuance: 细腻度，选一个：直白/含蓄/矛盾/讽刺\n"
            "- confidence: 你对判断的把握 [0.0, 1.0]\n"
            "- reasoning: 一句话解释为什么这样判断\n\n"
            f"文本：「{content[:500]}」\n\n"
            f"规则层初步判断：valence={rule_valence:.2f}\n\n"
            "JSON 格式：{\"valence\": 0.0, \"nuance\": \"直白\", \"confidence\": 0.8, \"reasoning\": \"...\"}"
        )

        try:
            response = self.llm_fn(prompt)
            if not response:
                return None

            # 解析 JSON（容错：从响应中提取 JSON 块）
            json_match = re.search(r'\{[^}]+\}', response, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
                return {
                    "valence": self._clamp(float(result.get("valence", 0)), -1.0, 1.0),
                    "confidence": self._clamp(float(result.get("confidence", 0.5)), 0.0, 1.0),
                    "nuance": result.get("nuance", "不明"),
                }
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            logger.debug(f"LLM 情感分析 JSON 解析失败: {e}")

        return None

    def _analyze_contrast_clauses(self, content: str) -> Optional[float]:
        """
        子句级情感分析（v7.1: Issue 2 修复）。

        在转折连词处切分，分别计算前后子句的 valence，
        后半句（"但是"之后）权重更高（0.7）。

        返回: 融合后的 valence 或 None（无法切分时）
        """
        # 转折连词模式
        split_patterns = [
            r"(?:虽然|尽管)(.*?)(?:但是|但|然而|可是|却)(.*)",
            r"(.*?)(?:但是|但|然而|可是)(.*)",
            r"(.*?)(?:though|although|but|however|yet)(.*)",
        ]

        clauses = None
        for pattern in split_patterns:
            match = re.search(pattern, content, re.IGNORECASE | re.DOTALL)
            if match:
                before = match.group(1).strip()
                after = match.group(2).strip()
                if before and after:
                    clauses = (before, after)
                    break

        if not clauses:
            return None

        before, after = clauses

        # 分别计算子句的情感
        before_hits_pos = len(self._pos_pattern_cn.findall(before)) + len(self._pos_pattern_en.findall(before.lower()))
        before_hits_neg = len(self._neg_pattern_cn.findall(before)) + len(self._neg_pattern_en.findall(before.lower()))
        after_hits_pos = len(self._pos_pattern_cn.findall(after)) + len(self._pos_pattern_en.findall(after.lower()))
        after_hits_neg = len(self._neg_pattern_cn.findall(after)) + len(self._neg_pattern_en.findall(after.lower()))

        before_total = before_hits_pos + before_hits_neg
        after_total = after_hits_pos + after_hits_neg

        before_valence = (before_hits_pos - before_hits_neg) / before_total if before_total > 0 else 0.0
        after_valence = (after_hits_pos - after_hits_neg) / after_total if after_total > 0 else 0.0

        # 后半句权重更高（"但是"之后才是重点）
        blended = 0.3 * before_valence + 0.7 * after_valence
        return self._clamp(blended, -1.0, 1.0)

    def analyze_batch(self, contents: list[str], importances: list[str] = None, nature_codes: list[str] = None) -> list[dict]:
        """批量分析"""
        importances = importances or ["medium"] * len(contents)
        nature_codes = nature_codes or [None] * len(contents)
        return [
            self.analyze(c, imp, nat)
            for c, imp, nat in zip(contents, importances, nature_codes)
        ]

    @staticmethod
    def valence_label(valence: float) -> str:
        """将 valence 转为人类可读标签"""
        if valence >= 0.5:
            return "积极"
        elif valence >= 0.15:
            return "偏正面"
        elif valence >= -0.15:
            return "中性"
        elif valence >= -0.5:
            return "偏负面"
        else:
            return "消极"

    @staticmethod
    def arousal_label(arousal: float) -> str:
        """将 arousal 转为人类可读标签"""
        if arousal >= 0.7:
            return "激动"
        elif arousal >= 0.4:
            return "活跃"
        elif arousal >= 0.2:
            return "平静"
        else:
            return "沉静"

    @staticmethod
    def significance_icon(significance: str) -> str:
        """返回 significance 对应的 emoji"""
        return {
            "trivial": "⚪",
            "notable": "🔵",
            "important": "🟡",
            "breakthrough": "🌟",
            "crisis": "🔴",
            "milestone": "🏁",
        }.get(significance, "⚪")
