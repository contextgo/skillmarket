"""
openclaw_integration.py - OpenClaw深度集成

实现与OpenClaw的深度集成
- 统一记忆接口
- 数据双向同步
- 智能系统切换

⚠️ 安全: 同步操作会在 Agent 间共享记忆内容。
仅对受信任的 Agent/工作区启用同步，并审查同步内容。
默认 sync_enabled=False，需显式启用。
"""

import time
import logging
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)


class OpenClawIntegration:
    """
    OpenClaw集成

    实现与OpenClaw的深度集成

    ⚠️ 安全: 同步操作会跨 Agent 边界共享记忆。
    仅在受信任环境中启用，默认禁用同步。
    """

    def __init__(self, memory_bridge, openclaw_api=None, openclaw_llm=None):
        self.memory_bridge = memory_bridge
        self.openclaw_api = openclaw_api
        self.openclaw_llm = openclaw_llm
        self.is_connected = False
        self.sync_interval = 300
        self.last_sync_time = 0
        self.sync_enabled = False
    
    def connect(self, openclaw_api) -> Dict:
        """
        连接OpenClaw
        
        Args:
            openclaw_api: OpenClaw API实例
        
        Returns:
            dict: 连接结果
        """
        try:
            self.openclaw_api = openclaw_api
            self.is_connected = True
            logger.info("成功连接到OpenClaw")
            return {"success": True, "message": "成功连接到OpenClaw"}
        except Exception as e:
            logger.error(f"连接OpenClaw失败: {e}")
            return {"success": False, "message": f"连接失败: {str(e)}"}
    
    def sync_memory(self) -> Dict:
        """
        同步记忆（双向：OpenClaw ↔ 记忆系统）

        ⚠️ 安全: 同步会将记忆内容跨系统共享。
        仅在受信任环境中启用，审查同步内容。
        """
        if not self.is_connected or not self.sync_enabled:
            return {"success": False, "message": "未连接到OpenClaw或同步已禁用"}

        logger.warning("Memory sync initiated — data will cross agent boundaries")
        
        try:
            current_time = time.time()
            if current_time - self.last_sync_time < self.sync_interval:
                return {"success": False, "message": "同步间隔未到"}
            
            # 从OpenClaw同步到记忆系统
            openclaw_memories = self._get_openclaw_memories()
            if openclaw_memories:
                synced_count = self._sync_to_memory_system(openclaw_memories)
            else:
                synced_count = 0
            
            # 从记忆系统同步到OpenClaw
            memory_system_memories = self._get_memory_system_memories()
            if memory_system_memories:
                synced_to_openclaw = self._sync_to_openclaw(memory_system_memories)
            else:
                synced_to_openclaw = 0
            
            self.last_sync_time = current_time
            
            return {
                "success": True,
                "message": f"同步完成",
                "synced_to_memory_system": synced_count,
                "synced_to_openclaw": synced_to_openclaw
            }
        except Exception as e:
            logger.error(f"同步失败: {e}")
            return {"success": False, "message": f"同步失败: {str(e)}"}
    
    def _get_openclaw_memories(self) -> List[Dict]:
        """
        获取OpenClaw的记忆
        
        Returns:
            list: OpenClaw记忆列表
        """
        try:
            # 这里需要根据OpenClaw的API进行调整
            # 假设OpenClaw有get_memories方法
            if hasattr(self.openclaw_api, 'get_memories'):
                return self.openclaw_api.get_memories()
            return []
        except Exception as e:
            logger.warning(f"获取OpenClaw记忆失败: {e}")
            return []
    
    def _get_memory_system_memories(self) -> List[Dict]:
        """
        获取记忆系统的记忆
        
        Returns:
            list: 记忆系统记忆列表
        """
        try:
            result = self.memory_bridge.recall(limit=50)
            return result.get("primary", [])
        except Exception as e:
            logger.warning(f"获取记忆系统记忆失败: {e}")
            return []
    
    def _sync_to_memory_system(self, openclaw_memories: List[Dict]) -> int:
        """
        同步到记忆系统
        
        Args:
            openclaw_memories: OpenClaw记忆列表
        
        Returns:
            int: 同步成功的数量
        """
        synced_count = 0
        for memory in openclaw_memories:
            try:
                content = memory.get("content", "")
                if content:
                    result = self.memory_bridge.remember(
                        content=content,
                        importance=memory.get("importance", "medium"),
                        topics=memory.get("topics", ["openclaw"])
                    )
                    if result.get("memory_result", {}).get("written", False):
                        synced_count += 1
            except Exception as e:
                logger.warning(f"同步OpenClaw记忆失败: {e}")
        return synced_count
    
    def _sync_to_openclaw(self, memory_system_memories: List[Dict]) -> int:
        """
        同步到OpenClaw
        
        Args:
            memory_system_memories: 记忆系统记忆列表
        
        Returns:
            int: 同步成功的数量
        """
        synced_count = 0
        for memory in memory_system_memories:
            try:
                content = memory.get("content", "")
                if content:
                    # 这里需要根据OpenClaw的API进行调整
                    # 假设OpenClaw有add_memory方法
                    if hasattr(self.openclaw_api, 'add_memory'):
                        self.openclaw_api.add_memory({
                            "content": content,
                            "importance": memory.get("importance", "medium"),
                            "topics": memory.get("topics", ["memory_system"])
                        })
                        synced_count += 1
            except Exception as e:
                logger.warning(f"同步到OpenClaw失败: {e}")
        return synced_count
    
    def get_combined_memory(self, query: str, limit: int = 10) -> Dict:
        """
        获取合并的记忆（来自记忆系统 + OpenClaw）

        ⚠️ 安全: 合并检索会跨越 Agent 边界。
        仅对受信任的查询启用，审查返回内容。
        """
        if self.is_connected:
            logger.info(f"Combined memory query across boundaries: '{query[:50]}'")
        try:
            # 从记忆系统获取
            memory_system_result = self.memory_bridge.recall(query=query, limit=limit)
            memory_system_memories = memory_system_result.get("primary", [])
            
            # 从OpenClaw获取
            openclaw_memories = []
            if self.is_connected:
                # 假设OpenClaw有search_memories方法
                if hasattr(self.openclaw_api, 'search_memories'):
                    openclaw_memories = self.openclaw_api.search_memories(query, limit=limit)
            
            # 合并结果
            combined_memories = memory_system_memories + openclaw_memories
            
            # 去重
            seen_content = set()
            unique_memories = []
            for memory in combined_memories:
                content = memory.get("content", "")
                if content not in seen_content:
                    seen_content.add(content)
                    unique_memories.append(memory)
            
            # 按时间排序
            unique_memories.sort(key=lambda x: x.get("time_ts", 0), reverse=True)
            
            return {
                "success": True,
                "memories": unique_memories[:limit],
                "source_counts": {
                    "memory_system": len(memory_system_memories),
                    "openclaw": len(openclaw_memories)
                }
            }
        except Exception as e:
            logger.error(f"获取合并记忆失败: {e}")
            return {"success": False, "message": f"获取失败: {str(e)}"}
    
    def enable_sync(self, enabled: bool):
        """
        启用或禁用同步

        ⚠️ 安全: 启用同步会将记忆内容跨 Agent 边界共享。
        仅在受信任环境中启用。
        """
        self.sync_enabled = enabled
        if enabled:
            logger.warning("Memory sync ENABLED — data will cross agent boundaries on next sync")
        else:
            logger.info("Memory sync disabled")
    
    def set_sync_interval(self, interval: int):
        """
        设置同步间隔
        
        Args:
            interval: 同步间隔（秒）
        """
        self.sync_interval = interval
        logger.info(f"同步间隔已设置为 {interval} 秒")
    
    def get_status(self) -> Dict:
        """
        获取集成状态
        
        Returns:
            dict: 状态信息
        """
        return {
            "is_connected": self.is_connected,
            "sync_enabled": self.sync_enabled,
            "sync_interval": self.sync_interval,
            "last_sync_time": self.last_sync_time,
            "time_since_last_sync": time.time() - self.last_sync_time
        }


def create_openclaw_integration(memory_bridge, openclaw_api=None, openclaw_llm=None):
    """
    创建OpenClaw集成实例
    
    Args:
        memory_bridge: 记忆系统桥接实例
        openclaw_api: OpenClaw API实例（可选）
        openclaw_llm: OpenClaw LLM实例（可选）
    
    Returns:
        OpenClawIntegration: OpenClaw集成实例
    """
    return OpenClawIntegration(memory_bridge, openclaw_api, openclaw_llm)
