-- agent-memory SQLite Schema
-- 所有结构化维度 + 关联关系存储

-- 主表：记忆记录
CREATE TABLE IF NOT EXISTS memories (
    memory_id       TEXT PRIMARY KEY,
    time_id         TEXT NOT NULL,
    time_ts         INTEGER NOT NULL,
    person_id       TEXT NOT NULL,
    nature_id       TEXT NOT NULL,
    content         TEXT NOT NULL,
    content_hash    TEXT NOT NULL,
    importance      TEXT DEFAULT 'medium',
    is_aggregated   INTEGER DEFAULT 0,
    source_count    INTEGER DEFAULT 1,
    -- 多 Agent 扩展
    owner_agent_id  TEXT DEFAULT '_system',     -- 创建者 Agent ID
    visibility      TEXT DEFAULT 'team',        -- private / team / public
    -- Phase 1: 情感编码
    valence         REAL DEFAULT 0.0,           -- 效价 [-1.0, 1.0]
    arousal         REAL DEFAULT 0.2,           -- 唤醒度 [0.0, 1.0]
    significance    TEXT DEFAULT 'notable',      -- trivial/notable/important/breakthrough/crisis/milestone
    confidence      REAL DEFAULT 0.5,           -- 内容质量置信度 [0.0, 1.0]
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- Agent 注册表
CREATE TABLE IF NOT EXISTS agents (
    agent_id        TEXT PRIMARY KEY,           -- Agent 唯一标识
    agent_name      TEXT NOT NULL,              -- 显示名
    team_id         TEXT DEFAULT 'default',     -- 所属团队
    capabilities    TEXT DEFAULT '[]',          -- JSON: 能力标签 ["coding", "writing"]
    status          TEXT DEFAULT 'active',      -- active / inactive
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- 记忆访问权限（细粒度控制）
CREATE TABLE IF NOT EXISTS memory_permissions (
    memory_id       TEXT NOT NULL,
    agent_id        TEXT NOT NULL,              -- 被授权的 Agent
    permission      TEXT DEFAULT 'read',        -- read / write / admin
    granted_by      TEXT NOT NULL,              -- 授权者 Agent ID
    granted_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    expires_at      INTEGER,                   -- 过期时间（NULL=永久）
    FOREIGN KEY (memory_id) REFERENCES memories(memory_id),
    PRIMARY KEY (memory_id, agent_id)
);

-- Agent 间的知识关联（跨 Agent 联想）
CREATE TABLE IF NOT EXISTS agent_associations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    source_agent    TEXT NOT NULL,
    target_agent    TEXT NOT NULL,
    memory_id       TEXT NOT NULL,
    association_type TEXT NOT NULL,             -- shares_knowledge / depends_on / contradicts
    reason          TEXT,
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    FOREIGN KEY (memory_id) REFERENCES memories(memory_id)
);

CREATE INDEX IF NOT EXISTS idx_mem_owner ON memories(owner_agent_id);
CREATE INDEX IF NOT EXISTS idx_mem_visibility ON memories(visibility);
CREATE INDEX IF NOT EXISTS idx_mem_owner_vis ON memories(owner_agent_id, visibility);
CREATE INDEX IF NOT EXISTS idx_perm_agent ON memory_permissions(agent_id);
CREATE INDEX IF NOT EXISTS idx_perm_memory ON memory_permissions(memory_id);
CREATE INDEX IF NOT EXISTS idx_agent_team ON agents(team_id);
CREATE INDEX IF NOT EXISTS idx_assoc_source ON agent_associations(source_agent);
CREATE INDEX IF NOT EXISTS idx_assoc_target ON agent_associations(target_agent);

-- 主题关联
CREATE TABLE IF NOT EXISTS memory_topics (
    memory_id       TEXT NOT NULL,
    topic_code      TEXT NOT NULL,
    is_primary      INTEGER DEFAULT 1,
    FOREIGN KEY (memory_id) REFERENCES memories(memory_id),
    PRIMARY KEY (memory_id, topic_code)
);

-- 知识类型关联
CREATE TABLE IF NOT EXISTS memory_knowledge (
    memory_id       TEXT NOT NULL,
    knowledge_id    TEXT NOT NULL,
    FOREIGN KEY (memory_id) REFERENCES memories(memory_id),
    PRIMARY KEY (memory_id, knowledge_id)
);

-- 工具关联
CREATE TABLE IF NOT EXISTS memory_tools (
    memory_id       TEXT NOT NULL,
    tool_id         TEXT NOT NULL,
    FOREIGN KEY (memory_id) REFERENCES memories(memory_id),
    PRIMARY KEY (memory_id, tool_id)
);

-- 关联关系
CREATE TABLE IF NOT EXISTS memory_links (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id       TEXT NOT NULL,
    target_id       TEXT NOT NULL,
    link_type       TEXT NOT NULL,
    weight          REAL DEFAULT 1.0,
    reason          TEXT,
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    FOREIGN KEY (source_id) REFERENCES memories(memory_id),
    FOREIGN KEY (target_id) REFERENCES memories(memory_id)
);

-- 对话窗口
CREATE TABLE IF NOT EXISTS windows (
    window_id       TEXT PRIMARY KEY,
    start_time      INTEGER NOT NULL,
    end_time        INTEGER,
    person_id       TEXT NOT NULL,
    message_count   INTEGER DEFAULT 0,
    topic_dominant  TEXT
);

-- 窗口-记录映射
CREATE TABLE IF NOT EXISTS window_memories (
    window_id       TEXT NOT NULL,
    memory_id       TEXT NOT NULL,
    seq_order       INTEGER NOT NULL,
    FOREIGN KEY (window_id) REFERENCES windows(window_id),
    FOREIGN KEY (memory_id) REFERENCES memories(memory_id),
    PRIMARY KEY (window_id, memory_id)
);

-- ═══════════════════════════════════════════════════════
-- 索引策略
-- ═══════════════════════════════════════════════════════

-- 单列索引
CREATE INDEX IF NOT EXISTS idx_mem_time ON memories(time_ts);
CREATE INDEX IF NOT EXISTS idx_mem_person ON memories(person_id);
CREATE INDEX IF NOT EXISTS idx_mem_nature ON memories(nature_id);
CREATE INDEX IF NOT EXISTS idx_mem_importance ON memories(importance);
CREATE INDEX IF NOT EXISTS idx_mem_hash ON memories(content_hash);
CREATE INDEX IF NOT EXISTS idx_mem_aggregated ON memories(is_aggregated);

-- 复合索引：覆盖最常见的查询模式
-- "按时间范围 + 重要度过滤" — 最高频组合
CREATE INDEX IF NOT EXISTS idx_mem_time_importance ON memories(time_ts, importance);
-- "按时间范围 + 人物"
CREATE INDEX IF NOT EXISTS idx_mem_time_person ON memories(time_ts, person_id);
-- "按人物 + 性质"
CREATE INDEX IF NOT EXISTS idx_mem_person_nature ON memories(person_id, nature_id);
-- "按重要度 + 时间倒序" — 高优先记忆快速检索
CREATE INDEX IF NOT EXISTS idx_mem_importance_time ON memories(importance, time_ts DESC);
-- "按性质 + 聚合标记" — 查找可压缩的非聚合记忆
CREATE INDEX IF NOT EXISTS idx_mem_nature_aggregated ON memories(nature_id, is_aggregated);
-- "按创建时间" — 归档/清理查询
CREATE INDEX IF NOT EXISTS idx_mem_created ON memories(created_at);
-- Phase 1: 情感索引
CREATE INDEX IF NOT EXISTS idx_mem_significance ON memories(significance);
CREATE INDEX IF NOT EXISTS idx_mem_valence ON memories(valence);
CREATE INDEX IF NOT EXISTS idx_mem_arousal ON memories(arousal);

-- 关联表索引
CREATE INDEX IF NOT EXISTS idx_link_source ON memory_links(source_id);
CREATE INDEX IF NOT EXISTS idx_link_target ON memory_links(target_id);
CREATE INDEX IF NOT EXISTS idx_link_type ON memory_links(link_type);
CREATE INDEX IF NOT EXISTS idx_link_source_type ON memory_links(source_id, link_type);
CREATE INDEX IF NOT EXISTS idx_link_target_type ON memory_links(target_id, link_type);

-- 主题索引
CREATE INDEX IF NOT EXISTS idx_topic_code ON memory_topics(topic_code);
CREATE INDEX IF NOT EXISTS idx_topic_memory ON memory_topics(memory_id, is_primary);

-- 待办任务
CREATE TABLE IF NOT EXISTS tasks (
    task_id         TEXT PRIMARY KEY,
    memory_id       TEXT NOT NULL,
    title           TEXT NOT NULL,
    status          TEXT DEFAULT 'pending',
    assignee        TEXT DEFAULT 'ai',
    deadline        INTEGER,
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    updated_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    completed_at    INTEGER,
    topic_code      TEXT,
    FOREIGN KEY (memory_id) REFERENCES memories(memory_id)
);

CREATE INDEX IF NOT EXISTS idx_task_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_task_memory ON tasks(memory_id);
CREATE INDEX IF NOT EXISTS idx_task_deadline ON tasks(deadline);
CREATE INDEX IF NOT EXISTS idx_task_assignee_status ON tasks(assignee, status);

-- ═══════════════════════════════════════════════════════
-- 记忆版本化（流式更新）
-- ═══════════════════════════════════════════════════════

-- 每条记忆的版本历史
-- 主表 memories 存储最新版本，此表存储完整版本链
CREATE TABLE IF NOT EXISTS memory_versions (
    version_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    memory_id       TEXT NOT NULL,
    content         TEXT NOT NULL,
    content_hash    TEXT NOT NULL,
    importance      TEXT DEFAULT 'medium',
    topics_json     TEXT DEFAULT '[]',          -- JSON: 当时的主题列表
    change_reason   TEXT,                        -- 变更原因
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    FOREIGN KEY (memory_id) REFERENCES memories(memory_id)
);

CREATE INDEX IF NOT EXISTS idx_mv_memory ON memory_versions(memory_id);
CREATE INDEX IF NOT EXISTS idx_mv_created ON memory_versions(memory_id, created_at DESC);

-- ═══════════════════════════════════════════════════════
-- Phase 2: 自我指涉 — 推理追踪 + 反思
-- ═══════════════════════════════════════════════════════

-- 推理追踪：记录每次检索/决策的推理过程
CREATE TABLE IF NOT EXISTS reasoning_traces (
    trace_id        TEXT PRIMARY KEY,
    query           TEXT NOT NULL,              -- 检索/决策的查询
    result_summary  TEXT,                        -- 结果摘要
    confidence      REAL DEFAULT 0.0,           -- 最终置信度 [0.0, 1.0]
    sources_used    TEXT DEFAULT '[]',           -- JSON: 用到的 memory_id 列表
    steps           TEXT DEFAULT '[]',           -- JSON: 推理步骤 [{step_type, detail, timestamp}]
    uncertainty     TEXT DEFAULT '[]',           -- JSON: 不确定因素列表
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- 自我反思：基于低置信度推理生成的反思记录
CREATE TABLE IF NOT EXISTS self_reflections (
    reflection_id   TEXT PRIMARY KEY,
    trace_id        TEXT,                        -- 关联的推理追踪
    insight         TEXT NOT NULL,               -- 反思内容
    action_taken    TEXT,                        -- 采取的修正行动
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    FOREIGN KEY (trace_id) REFERENCES reasoning_traces(trace_id)
);

CREATE INDEX IF NOT EXISTS idx_trace_query ON reasoning_traces(query);
CREATE INDEX IF NOT EXISTS idx_trace_confidence ON reasoning_traces(confidence);
CREATE INDEX IF NOT EXISTS idx_trace_created ON reasoning_traces(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reflection_trace ON self_reflections(trace_id);
CREATE INDEX IF NOT EXISTS idx_reflection_created ON self_reflections(created_at DESC);

-- ═══════════════════════════════════════════════════════
-- Phase 4: 内在动机 — Agent 内在状态
-- ═══════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS internal_state (
    state_id        TEXT PRIMARY KEY,           -- 'current' 固定值
    curiosity       REAL DEFAULT 0.3,           -- 好奇心 [0, 1]
    boredom         REAL DEFAULT 0.0,           -- 无聊度 [0, 1]
    confidence      REAL DEFAULT 0.5,           -- 自信度 [0, 1]
    satisfaction    REAL DEFAULT 0.5,           -- 满足感 [0, 1]
    urgency         REAL DEFAULT 0.0,           -- 紧迫感 [0, 1]
    dominant_drive  TEXT DEFAULT 'none',         -- 当前主导动机
    updated_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- ═══════════════════════════════════════════════════════
-- Phase 5: 叙事自我 — 身份模型 + 生命叙事
-- ═══════════════════════════════════════════════════════

-- 身份模型：动态更新的自我认知
CREATE TABLE IF NOT EXISTS identity_model (
    key             TEXT PRIMARY KEY,           -- core_values / preferences / expertise / personality_traits / interests / _meta
    value           TEXT NOT NULL,              -- JSON
    confidence      REAL DEFAULT 0.5,
    evidence_count  INTEGER DEFAULT 0,
    updated_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- 生命叙事：从记忆构建的叙事记录
CREATE TABLE IF NOT EXISTS life_narratives (
    narrative_id        TEXT PRIMARY KEY,
    narrative_type      TEXT NOT NULL,           -- daily / topic / milestone / identity
    title               TEXT NOT NULL,
    content             TEXT NOT NULL,            -- Markdown 叙事
    period_start        INTEGER,
    period_end          INTEGER,
    source_memory_count INTEGER DEFAULT 0,
    created_at          INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE INDEX IF NOT EXISTS idx_identity_key ON identity_model(key);
CREATE INDEX IF NOT EXISTS idx_narrative_type ON life_narratives(narrative_type);
CREATE INDEX IF NOT EXISTS idx_narrative_created ON life_narratives(created_at DESC);
