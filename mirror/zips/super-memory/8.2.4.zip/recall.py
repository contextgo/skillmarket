"""
recall.py - 检索引擎
真正的双路检索（结构化 FTS + 语义向量）+ RRF 融合排序
+ 时序感知 + 查询意图分类 + 负反馈闭环 + MMR 多样性
"""

import time
import re
import math
import logging
from store import MemoryStore
from encoder import DimensionEncoder

logger = logging.getLogger(__name__)

# Reciprocal Rank Fusion 常数
_RRF_K = 60


class RecallEngine:
    """记忆检索引擎，支持结构化/语义/混合三种模式"""

    # 排序权重（可配置）
    RANK_WEIGHTS = {
        "importance": 0.20,
        "time": 0.15,
        "structured": 0.20,
        "semantic": 0.25,
        "causal": 0.10,
        "quality": 0.10,
    }

    # 意图分类 → 排序策略映射
    INTENT_STRATEGIES = {
        "recall": {  # 回忆型："我之前说了什么"
            "time_weight_boost": 0.15,  # 时间排序权重提高
            "semantic_weight_cut": 0.10,
            "prefer_recent": True,
        },
        "knowledge": {  # 知识型："RAG 怎么做"
            "semantic_weight_boost": 0.15,
            "time_weight_cut": 0.10,
            "prefer_recent": False,
        },
        "task": {  # 任务型："待办有哪些"
            "nature_filter": ["D03", "D07"],  # task/todo
            "time_weight_boost": 0.05,
            "prefer_recent": True,
        },
        "general": {  # 通用
            "prefer_recent": False,
        },
    }

    def __init__(self, store: MemoryStore, encoder: DimensionEncoder, embedding_store=None, quality=None, reranker=None, self_model=None):
        self.store = store
        self.encoder = encoder
        self.embedding_store = embedding_store
        self.quality = quality  # 可选：质量评分系统
        self.reranker = reranker  # 可选：交叉编码器重排序
        self.self_model = self_model  # 可选：自我指涉推理追踪

    def recall(
        self,
        # 结构化过滤参数
        time_from: int = None,
        time_to: int = None,
        person_id: str = None,
        nature_code: str = None,
        topic_path: str = None,
        tool_id: str = None,
        knowledge_id: str = None,
        importance: str = None,
        keyword: str = None,
        significance: str = None,
        # 语义搜索参数
        query: str = None,
        semantic_weight: float = 0.5,
        # 通用参数
        limit: int = 20,
        # 修复 (P2): 权限过滤参数
        query_agent_id: str = None,
        team_id: str = "default",
    ) -> dict:
        """
        综合检索入口

        根据传入参数自动选择检索模式：
        - 只有结构化参数 → structured
        - 只有 query → semantic
        - 两者都有 → hybrid（RRF 融合）

        返回：
        {
            "search_mode": "structured|semantic|hybrid",
            "total": int,
            "primary": [memory dicts],
            "related": [memory dicts],
            "query": str,
        }
        """
        has_structured = any([time_from, time_to, person_id, nature_code,
                              topic_path, tool_id, knowledge_id, importance, keyword, significance])
        has_semantic = query is not None and self.embedding_store is not None

        # ── 推理追踪初始化 ────────────────────────────
        trace = None
        if self.self_model and (query or keyword):
            trace = self.self_model.start_trace(query or keyword or "")
            trace.add_step("init", f"mode_hints: structured={has_structured}, semantic={has_semantic}")

        # ── 意图分类 ──────────────────────────────────
        intent = self.classify_intent(query or keyword or "")

        # 任务意图自动过滤 nature
        if intent == "task" and not nature_code:
            nature_code = None  # 让结构化查询去过滤
            # 但额外加入结构化查询
            if not has_structured:
                has_structured = True

        if has_structured and has_semantic:
            mode = "hybrid"
        elif has_semantic:
            mode = "semantic"
        else:
            mode = "structured"

        # ── 结构化检索（FTS + 维度过滤）──────────────
        structured_results = []
        if has_structured or mode == "structured":
            # Fix: 当有 query 但无语义后端时，将 query 用作 FTS keyword
            effective_keyword = keyword or (query if not has_semantic else None)
            nature_id = None
            if nature_code:
                try:
                    nature_id = self.encoder.encode_nature(nature_code)
                except ValueError:
                    pass

            structured_results = self.store.query(
                time_from=time_from,
                time_to=time_to,
                person_id=person_id,
                nature_id=nature_id,
                topic_code=topic_path,
                tool_id=tool_id,
                knowledge_id=knowledge_id,
                importance=importance,
                keyword=effective_keyword,
                significance=significance,
                limit=limit * 2,  # 多取一些供融合
                query_agent_id=query_agent_id,
                team_id=team_id,
            )
            # 推理追踪
            if trace:
                trace.add_step("fts_search", f"structured found {len(structured_results)} results")
                for m in structured_results[:5]:
                    trace.add_source(m.get("memory_id", ""))

        # ── 语义检索（向量余弦相似度）─────────────────
        semantic_results = []
        if has_semantic:
            # 构建语义过滤器
            filter_meta = {}
            if importance:
                filter_meta["importance"] = importance
            if person_id:
                filter_meta["person_id"] = person_id

            try:
                raw_semantic = self.embedding_store.search(
                    query=query,
                    top_k=limit * 2,
                    filter_metadata=filter_meta if filter_meta else None,
                )

                # 补充结构化信息
                for item in raw_semantic:
                    mem = self.store.get_memory(item["memory_id"])
                    if mem:
                        mem["_semantic_score"] = item["score"]
                        semantic_results.append(mem)
                # 推理追踪
                if trace:
                    trace.add_step("vec_search", f"semantic found {len(semantic_results)} results (top_k={limit*2})")
                    for m in semantic_results[:5]:
                        trace.add_source(m.get("memory_id", ""))
            except Exception as e:
                logger.warning(f"语义检索失败，降级为结构化: {e}")
                if trace:
                    trace.add_uncertainty(f"semantic_search_failed: {e}")

        # ── 融合排序 ──────────────────────────────────
        if mode == "structured":
            merged = structured_results
            if trace:
                trace.add_step("rrf_fusion", "structured-only, no fusion needed")
        elif mode == "semantic":
            merged = semantic_results
            if trace:
                trace.add_step("rrf_fusion", "semantic-only, no fusion needed")
        else:
            merged = self._rrf_merge(structured_results, semantic_results)
            dual_hits = sum(1 for m in merged if m.get("_dual_hit"))
            if trace:
                trace.add_step("rrf_fusion", f"hybrid merged {len(merged)} results ({dual_hits} dual hits)")

        # ── 综合排序 ──────────────────────────────────
        ranked = self._rank_results(merged, query=query, semantic_weight=semantic_weight, intent=intent)

        # ── 负反馈降权 ─────────────────────────────────
        ranked = self._apply_feedback_penalty(ranked, quality=self.quality)

        # ── RRF 追踪日志 ─────────────────────────────
        try:
            from trace_logger import get_tracer
            tracer = get_tracer()
            top_score = ranked[0].get("_rank_score", 0) if ranked else 0
            has_dual = any(m.get("_dual_hit") for m in ranked[:5]) if ranked else False
            confidence = min(1.0, 0.3 + top_score * 0.5 + (0.2 if has_dual else 0))
            tracer.log_recall_rrf(
                query=query or "",
                mode=mode,
                structured_raw=structured_results,
                semantic_raw=semantic_results,
                merged=merged,
                final_ranked=ranked,
                intent=intent,
                confidence=confidence,
            )
        except Exception:
            pass

        # ── 交叉编码器重排序 ───────────────────────────
        if self.reranker and query and ranked:
            try:
                ranked = self.reranker.rerank(
                    query=query,
                    results=ranked,
                    top_k=limit * 2,
                    score_field="_rank_score",
                )
            except Exception as e:
                logger.warning(f"Rerank 失败，跳过: {e}")

        # ── MMR 多样性重排 ─────────────────────────────
        if intent != "task" and len(ranked) > 3:
            ranked = self.mmr_rerank(ranked, lambda_param=0.7, max_results=limit * 2)

        # ── 版本信息标注（Fix #21）────────────────────
        if ranked:
            self._annotate_version_counts(ranked)

        # ── 关联记录（含因果链）───────────────────────
        related = []
        if ranked:
            top_id = ranked[0].get("memory_id")
            if top_id:
                related = self.store.get_linked(top_id, max_depth=2)

        # ── 推理追踪完成 ─────────────────────────────
        if trace:
            # 评估综合置信度
            top_score = ranked[0].get("_rank_score", 0) if ranked else 0
            has_dual = any(m.get("_dual_hit") for m in ranked[:5]) if ranked else False
            confidence = min(1.0, 0.3 + top_score * 0.5 + (0.2 if has_dual else 0))
            if len(ranked) < 3:
                trace.add_uncertainty(f"low_result_count: only {len(ranked)} results found")
            trace.finalize(
                result_summary=f"found {len(ranked)} results via {mode}, top_score={top_score:.3f}",
                confidence=confidence,
            )
            # 注入 trace 到返回结果
            return {
                "search_mode": mode,
                "total": len(ranked),
                "primary": ranked[:limit],
                "related": related,
                "query": query or "",
                "intent": intent,
                "_trace": trace.to_dict(),
            }

        return {
            "search_mode": mode,
            "total": len(ranked),
            "primary": ranked[:limit],
            "related": related,
            "query": query or "",
            "intent": intent,
        }

    def _rrf_merge(self, structured: list[dict], semantic: list[dict]) -> list[dict]:
        """
        Reciprocal Rank Fusion (RRF) 融合两路结果。

        公式: RRF_score(d) = Σ 1/(k + rank_i(d))
        k=60 是标准常数，降低排名靠前结果的主导性。

        对同时出现在两路的结果，分数叠加（这就是真正的融合价值）。
        """
        seen = {}
        merged = []

        # 结构化结果按排名给 RRF 分
        for rank, mem in enumerate(structured):
            mid = mem.get("memory_id")
            if not mid:
                continue
            rrf_score = 1.0 / (_RRF_K + rank + 1)
            mem["_structured_rrf"] = rrf_score
            mem["_structured_rank"] = rank + 1
            mem["_semantic_rrf"] = 0.0
            mem["_semantic_score"] = 0.0
            seen[mid] = len(merged)
            merged.append(mem)

        # 语义结果：已有的叠加，新的追加
        for rank, mem in enumerate(semantic):
            mid = mem.get("memory_id")
            if not mid:
                continue
            rrf_score = 1.0 / (_RRF_K + rank + 1)
            sem_score = mem.get("_semantic_score", 0)

            if mid in seen:
                # 叠加：同一条记忆在两路都命中 = 更高置信度
                existing = merged[seen[mid]]
                existing["_semantic_rrf"] = rrf_score
                existing["_semantic_score"] = sem_score
                existing["_semantic_rank"] = rank + 1
                existing["_dual_hit"] = True  # 标记双路命中
            else:
                mem["_structured_rrf"] = 0.0
                mem["_semantic_rrf"] = rrf_score
                mem["_semantic_score"] = sem_score
                mem["_semantic_rank"] = rank + 1
                mem["_dual_hit"] = False
                seen[mid] = len(merged)
                merged.append(mem)

        # 计算融合分（用于排序参考）
        for mem in merged:
            mem["_rrf_score"] = mem.get("_structured_rrf", 0) + mem.get("_semantic_rrf", 0)

        return merged

    def _rank_results(self, results: list[dict], query: str = None, semantic_weight: float = 0.5, intent: str = "general") -> list[dict]:
        """
        综合打分排序。

        维度：
        - 重要度 (20%)
        - 时间衰减 (15%)
        - 结构化 RRF 分 (20%)
        - 语义 RRF 分 (25%)
        - 因果链加成 (10%)：被其他记忆因果引用越多，权重越高
        - 质量分 (10%)：如有 quality 系统

        根据意图分类动态调整权重。
        """
        now = time.time()
        importance_map = {"high": 1.0, "medium": 0.5, "low": 0.1}

        # 根据意图调整权重
        w = self.apply_intent_strategy(dict(self.RANK_WEIGHTS), intent)

        # 预计算因果引用计数（被多少其他记忆因果引用）
        causal_counts = self._batch_get_causal_reference_counts([m.get("memory_id", "") for m in results])
        max_causal = max(causal_counts.values()) if causal_counts else 1

        for mem in results:
            scores = {}
            mid = mem.get("memory_id", "")

            # 重要度
            imp = mem.get("importance", "medium")
            scores["importance"] = importance_map.get(imp, 0.5) * w["importance"]

            # 时间衰减：一周内线性衰减
            time_ts = mem.get("time_ts", 0)
            age_hours = (now - time_ts) / 3600 if time_ts else 999
            scores["time"] = max(0, 1.0 - age_hours / 168) * w["time"]

            # 结构化 RRF 分（归一化）
            s_rrf = mem.get("_structured_rrf", 0)
            scores["structured"] = min(1.0, s_rrf / (1.0 / _RRF_K)) * w["structured"]

            # 语义 RRF 分（归一化）
            sem_rrf = mem.get("_semantic_rrf", 0)
            scores["semantic"] = min(1.0, sem_rrf / (1.0 / _RRF_K)) * w["semantic"]

            # 因果链加成：被引用越多 → 价值越高
            causal_count = causal_counts.get(mid, 0)
            scores["causal"] = (min(causal_count, 5) / 5.0) * w["causal"] if max_causal > 0 else 0

            # 质量分
            if self.quality:
                try:
                    q = self.quality.compute_quality(mem)
                    scores["quality"] = q.get("quality_score", 0.5) * w["quality"]
                except Exception:
                    scores["quality"] = 0.5 * w["quality"]
            else:
                scores["quality"] = 0.5 * w["quality"]

            # 双路命中加成（额外 +5%）
            dual_bonus = 0.05 if mem.get("_dual_hit") else 0

            mem["_rank_score"] = sum(scores.values()) + dual_bonus
            mem["_rank_breakdown"] = scores

        results.sort(key=lambda m: m.get("_rank_score", 0), reverse=True)
        return results

    def _batch_get_causal_reference_counts(self, memory_ids: list[str]) -> dict[str, int]:
        """批量获取每条记忆被因果引用的次数"""
        if not memory_ids:
            return {}
        try:
            placeholders = ",".join("?" * len(memory_ids))
            rows = self.store.conn.execute(
                f"""SELECT target_id, COUNT(*) as cnt
                    FROM memory_links
                    WHERE link_type LIKE 'causal.%' AND target_id IN ({placeholders})
                    GROUP BY target_id""",
                memory_ids,
            ).fetchall()
            return {r["target_id"]: r["cnt"] for r in rows}
        except Exception:
            return {}

    # ── 查询意图分类 ──────────────────────────────────

    def classify_intent(self, query: str) -> str:
        """
        将查询分为四类意图：recall / knowledge / task / general

        recall: "我之前说了什么"、"上次聊的"、"记得"、"说过"
        knowledge: "怎么"、"什么是"、"为什么"、"如何"、"RAG"
        task: "待办"、"todo"、"计划"、"任务"、"接下来"
        general: 其他
        """
        if not query:
            return "general"

        q = query.lower()

        # 任务意图（最高优先级，特征最明确）
        task_kw = r"待办|todo|计划|任务|接下来|还有什么没做|还有什么要做|进度"
        if re.search(task_kw, q):
            return "task"

        # 回忆意图
        recall_kw = r"之前|上次|刚才|说过|聊过|记得|提过|讨论过|决定过|以前|最早|什么时候"
        if re.search(recall_kw, q):
            return "recall"

        # 知识意图
        knowledge_kw = r"怎么|什么是|为什么|如何|区别|比较|哪个好|原理|方法|步骤"
        if re.search(knowledge_kw, q):
            return "knowledge"

        return "general"

    def apply_intent_strategy(self, weights: dict, intent: str) -> dict:
        """根据意图调整排序权重"""
        strategy = self.INTENT_STRATEGIES.get(intent, self.INTENT_STRATEGIES["general"])
        adjusted = dict(weights)

        if strategy.get("time_weight_boost"):
            adjusted["time"] = adjusted.get("time", 0.15) + strategy["time_weight_boost"]
        if strategy.get("semantic_weight_boost"):
            adjusted["semantic"] = adjusted.get("semantic", 0.25) + strategy["semantic_weight_boost"]
        if strategy.get("semantic_weight_cut"):
            adjusted["semantic"] = max(0.05, adjusted.get("semantic", 0.25) - strategy["semantic_weight_cut"])
        if strategy.get("time_weight_cut"):
            adjusted["time"] = max(0.05, adjusted.get("time", 0.15) - strategy["time_weight_cut"])

        return adjusted

    # ── MMR 多样性重排 ────────────────────────────────

    def mmr_rerank(
        self,
        results: list[dict],
        lambda_param: float = 0.7,
        max_results: int = None,
    ) -> list[dict]:
        """
        Maximal Marginal Relevance (MMR) 重排，保证检索结果的多样性。

        公式: MMR(d) = λ * relevance(d) - (1-λ) * max_similarity(d, selected)

        lambda_param: 0~1，越大越注重相关性，越大越注重多样性
            0.7 = 推荐值（70% 相关性 + 30% 多样性）

        避免结果全部集中在同一主题，确保跨主题覆盖。
        """
        if len(results) <= 2:
            return results

        max_results = max_results or len(results)

        # 按 _rank_score 预排序
        candidates = sorted(results, key=lambda m: m.get("_rank_score", 0), reverse=True)
        selected = [candidates.pop(0)]  # 最高分直接入选

        while candidates and len(selected) < max_results:
            best_mmr = -float("inf")
            best_idx = 0

            for i, candidate in enumerate(candidates):
                rel = candidate.get("_rank_score", 0)

                # 计算与已选结果的最大相似度
                max_sim = 0
                for sel in selected:
                    sim = self._memory_similarity(candidate, sel)
                    max_sim = max(max_sim, sim)

                mmr = lambda_param * rel - (1 - lambda_param) * max_sim

                if mmr > best_mmr:
                    best_mmr = mmr
                    best_idx = i

            selected.append(candidates.pop(best_idx))

        return selected

    def _memory_similarity(self, a: dict, b: dict) -> float:
        """
        两条记忆的相似度（用于 MMR）。

        综合考虑主题重叠和时间邻近度。
        """
        # 主题重叠
        topics_a = set()
        for t in a.get("topics", []):
            if isinstance(t, dict):
                topics_a.add(t.get("code", ""))
            else:
                topics_a.add(t)

        topics_b = set()
        for t in b.get("topics", []):
            if isinstance(t, dict):
                topics_b.add(t.get("code", ""))
            else:
                topics_b.add(t)

        if topics_a and topics_b:
            # Jaccard 相似度
            topic_sim = len(topics_a & topics_b) / len(topics_a | topics_b)
        else:
            topic_sim = 0

        # 时间邻近度（同一天 = 高相似）
        ts_a = a.get("time_ts", 0)
        ts_b = b.get("time_ts", 0)
        if ts_a and ts_b:
            day_gap = abs(ts_a - ts_b) / 86400
            time_sim = max(0, 1.0 - day_gap / 7)  # 一周内线性衰减
        else:
            time_sim = 0

        # 性质重叠
        nature_sim = 1.0 if a.get("nature_id") == b.get("nature_id") else 0

        return 0.5 * topic_sim + 0.3 * time_sim + 0.2 * nature_sim

    # ── 负反馈信号 ────────────────────────────────────

    def _apply_feedback_penalty(self, results: list[dict], quality=None) -> list[dict]:
        """
        负反馈闭环：用户标记"没用"的记忆降权。

        从 quality 系统读取反馈数据，对负反馈记忆施加惩罚。
        """
        if not quality:
            return results

        feedback_data = getattr(quality, '_stats', {}).get('feedback', {})

        for mem in results:
            mid = mem.get("memory_id", "")
            fb = feedback_data.get(mid)
            if fb and not fb.get("useful", True):
                # 负反馈：降低排名分数 50%
                mem["_rank_score"] = mem.get("_rank_score", 0) * 0.5
                mem["_negative_feedback"] = True

        return results

    def format_context(self, result: dict, max_items: int = 10) -> str:
        """格式化检索结果为可读上下文文本"""
        lines = []
        mode = result.get("search_mode", "unknown")
        total = result.get("total", 0)

        lines.append(f"📋 检索结果 [{mode}] 共 {total} 条")
        lines.append("")

        for i, mem in enumerate(result.get("primary", [])[:max_items]):
            # 标签
            tags = []
            imp = mem.get("importance", "medium")
            if imp == "high":
                tags.append("⚡高优先")
            elif imp == "low":
                tags.append("🔻低优先")

            # 语义相似度
            sem = mem.get("_semantic_score")
            if sem is not None and sem > 0:
                tags.append(f"~{sem:.2f}")

            # 双路命中标记
            if mem.get("_dual_hit"):
                tags.append("🔄双路")

            # 因果引用
            causal = mem.get("_rank_breakdown", {}).get("causal", 0)
            if causal > 0.02:
                tags.append("🔗因果")

            # 主题
            topics = mem.get("topics", [])
            topic_str = ""
            if topics:
                codes = [t["code"] if isinstance(t, dict) else t for t in topics]
                topic_str = " | " + ", ".join(codes)

            # 时间
            time_id = mem.get("time_id", "")

            tag_str = " ".join(tags)
            content = mem.get("content", "")[:80]

            lines.append(f"  {i+1}. {tag_str} [{time_id}]{topic_str}")
            lines.append(f"     {content}")

        # 关联记录
        related = result.get("related", [])
        if related:
            lines.append("")
            lines.append(f"  🔗 关联记录 ({len(related)} 条):")
            for r in related[:5]:
                r_content = r.get("content", "")[:50]
                link_type = r.get("_link_type", "")
                lines.append(f"     → [{link_type}] {r_content}")

        return "\n".join(lines)

    def _annotate_version_counts(self, results: list[dict]):
        """批量查询 memory_versions 表，给检索结果附加 version_count（Fix #21）"""
        if not results:
            return
        try:
            # 先检查表是否存在
            self.store.conn.execute(
                "SELECT 1 FROM memory_versions LIMIT 1"
            )
        except Exception:
            return  # 表不存在，跳过

        memory_ids = [m.get("memory_id", "") for m in results if m.get("memory_id")]
        if not memory_ids:
            return

        try:
            placeholders = ",".join("?" * len(memory_ids))
            rows = self.store.conn.execute(
                f"""SELECT memory_id, COUNT(*) as version_count
                    FROM memory_versions
                    WHERE memory_id IN ({placeholders})
                    GROUP BY memory_id""",
                memory_ids
            ).fetchall()

            version_map = {r["memory_id"]: r["version_count"] for r in rows}
            for mem in results:
                mid = mem.get("memory_id", "")
                vc = version_map.get(mid, 0)
                if vc > 0:
                    mem["version_count"] = vc
        except Exception:
            pass  # 查询失败不影响主流程

    def get_stats(self) -> dict:
        """返回检索引擎统计信息"""
        stats = {
            "structured_db": "SQLite",
            "semantic_db": "none",
            "fusion_method": "RRF",
        }
        if self.embedding_store:
            stats["semantic_db"] = "ChromaDB"
            try:
                stats["vector_count"] = self.embedding_store.count()
            except Exception:
                stats["vector_count"] = -1
        return stats
