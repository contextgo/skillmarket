"""
recall_eval.py - 检索质量评估系统
Precision@K, Recall@K, NDCG@K, MRR（Fix #2）
"""

import logging
from typing import Callable

logger = logging.getLogger(__name__)


class RetrievalEvaluator:
    """信息检索标准评估指标"""

    def __init__(self, recall_fn: Callable):
        """
        recall_fn: 检索函数，签名 fn(query: str, top_k: int) -> list[dict]
                   返回的 dict 需包含 memory_id 字段
        """
        self.recall_fn = recall_fn

    def precision_at_k(self, retrieved: list[str], relevant: set[str], k: int) -> float:
        """Precision@K: 前 K 个结果中相关结果的比例"""
        if k == 0:
            return 0.0
        top_k = retrieved[:k]
        hits = sum(1 for r in top_k if r in relevant)
        return hits / k

    def recall_at_k(self, retrieved: list[str], relevant: set[str], k: int) -> float:
        """Recall@K: 前 K 个结果覆盖了多少比例的相关结果"""
        if not relevant:
            return 0.0
        top_k = retrieved[:k]
        hits = sum(1 for r in top_k if r in relevant)
        return hits / len(relevant)

    def ndcg_at_k(self, retrieved: list[str], relevant: set[str], k: int) -> float:
        """NDCG@K: 归一化折损累积增益"""
        import math
        # DCG
        dcg = 0.0
        for i, r in enumerate(retrieved[:k]):
            if r in relevant:
                dcg += 1.0 / math.log2(i + 2)  # i+2 因为 log2(1)=0
        # IDCG（理想排序）
        idcg = 0.0
        for i in range(min(len(relevant), k)):
            idcg += 1.0 / math.log2(i + 2)
        return dcg / idcg if idcg > 0 else 0.0

    def mrr(self, retrieved: list[str], relevant: set[str]) -> float:
        """MRR: 平均倒数排名"""
        for i, r in enumerate(retrieved):
            if r in relevant:
                return 1.0 / (i + 1)
        return 0.0

    def evaluate(self, test_cases: list[dict], k_values: list[int] = [1, 3, 5, 10]) -> dict:
        """
        批量评估。

        test_cases: [{"query": str, "relevant_ids": set[str]}, ...]
        k_values: 评估的 K 值列表

        返回: {"precision@k": float, "recall@k": float, "ndcg@k": float, "mrr": float, ...}
        """
        results = {f"precision@{k}": [] for k in k_values}
        results.update({f"recall@{k}": [] for k in k_values})
        results.update({f"ndcg@{k}": [] for k in k_values})
        results["mrr"] = []

        for tc in test_cases:
            query = tc["query"]
            relevant = tc["relevant_ids"]
            max_k = max(k_values)

            try:
                recall_results = self.recall_fn(query, top_k=max_k)
                retrieved = [r.get("memory_id", r.get("id", "")) for r in recall_results]
            except Exception as e:
                logger.warning(f"检索失败: {e}")
                retrieved = []

            for k in k_values:
                results[f"precision@{k}"].append(self.precision_at_k(retrieved, relevant, k))
                results[f"recall@{k}"].append(self.recall_at_k(retrieved, relevant, k))
                results[f"ndcg@{k}"].append(self.ndcg_at_k(retrieved, relevant, k))

            results["mrr"].append(self.mrr(retrieved, relevant))

        # 求平均
        avg = {}
        for key, values in results.items():
            avg[key] = round(sum(values) / len(values), 4) if values else 0.0

        return avg

    def ablation_study(self, test_cases: list[dict], pipeline_components: dict, k: int = 5) -> dict:
        """
        消融实验：逐个关闭排序因子，量化每个因子的贡献。

        pipeline_components: {"component_name": enable_fn, ...}
            enable_fn: fn(enabled: bool) -> None，控制组件开关

        返回: {"baseline": metrics, "without_rrf": metrics, ...}
        """
        # 先跑 baseline（全开）
        baseline = self.evaluate(test_cases, k_values=[k])
        results = {"baseline": baseline}

        # 逐个关闭
        for name, toggle_fn in pipeline_components.items():
            try:
                toggle_fn(False)  # 关闭
                ablated = self.evaluate(test_cases, k_values=[k])
                toggle_fn(True)   # 恢复
                results[f"without_{name}"] = ablated
            except Exception as e:
                logger.warning(f"消融实验 {name} 失败: {e}")

        return results
