"""
encoder.py - 维度编码器
负责将维度值编码为 memory_id，查注册表
"""

import json
import hashlib
import time
import uuid
import threading
from datetime import datetime
from pathlib import Path

REGISTRY_PATH = Path(__file__).parent / "dimensions.json"

# 线程锁：保护注册表文件的并发写入（同进程内多线程）
_registry_write_lock = threading.Lock()


class DimensionEncoder:
    def __init__(self, registry_path: str = None):
        self.registry_path = Path(registry_path) if registry_path else REGISTRY_PATH
        with open(self.registry_path, "r", encoding="utf-8") as f:
            self.registry = json.load(f)
        # 建反向索引：code → id（避免线性扫描）
        self._nature_by_code = {}
        for nid, info in self.registry["natures"].items():
            self._nature_by_code[info["code"]] = nid

        self._person_by_code = {}
        for pid, info in self.registry["persons"].items():
            self._person_by_code[info["code"]] = pid

        self._tool_by_code = {}
        for tid, info in self.registry["tools"].items():
            self._tool_by_code[info["code"]] = tid

        self._knowledge_by_code = {}
        for kid, info in self.registry["knowledge_types"].items():
            self._knowledge_by_code[info["code"]] = kid

    # ── 时间编码 ──────────────────────────────────────────

    def encode_time(self, ts: float = None, precision: str = "second") -> str:
        """生成时间编码
        precision: 'second' → T20260411.213742
                   'minute' → T20260411.2137
                   'micro'  → T20260411.213742.123456 (防冲突)
        """
        dt = datetime.fromtimestamp(ts) if ts else datetime.now()
        if precision == "minute":
            return f"T{dt.strftime('%Y%m%d.%H%M')}"
        if precision == "micro":
            us = int((ts or time.time()) % 1 * 1_000_000)
            return f"T{dt.strftime('%Y%m%d.%H%M%S')}.{us:06d}"
        return f"T{dt.strftime('%Y%m%d.%H%M%S')}"

    # ── 人物编码 ──────────────────────────────────────────

    def encode_person(self, person_id: str) -> str:
        """直接用注册表里的 ID，如 P01"""
        if person_id not in self.registry["persons"]:
            raise ValueError(f"未注册的人物 ID: {person_id}，请先在 dimensions.json 中注册")
        return person_id

    def get_person_by_code(self, code: str) -> str:
        """通过 code 查 person_id（O(1) 反向索引）"""
        if code in self._person_by_code:
            return self._person_by_code[code]
        raise ValueError(f"未找到 code={code} 的人物")

    # ── 主题编码 ──────────────────────────────────────────

    def encode_topic(self, topic_path: str, auto_register: bool = True) -> str:
        """主题路径直接作为编码，如 ai.rag.vdb

        如果路径未注册：
        - auto_register=True（默认）：自动在注册表中创建，静默通过
        - auto_register=False：抛 ValueError（向后兼容）
        """
        parts = topic_path.split(".")
        node = self.registry["topics"]
        missing_from = None
        for i, p in enumerate(parts):
            if p not in node:
                missing_from = i
                break
            if "children" in node[p]:
                node = node[p]["children"]
            elif p != parts[-1]:
                if auto_register:
                    # 中间节点缺失 children，补充之
                    node[p]["children"] = {}
                    node = node[p]["children"]
                    missing_from = i + 1
                    break
                else:
                    raise ValueError(f"主题路径不完整: {topic_path}")

        # 自动注册缺失的路径段
        if missing_from is not None and auto_register:
            self._auto_register_topic_path(topic_path, parts, missing_from)
        elif missing_from is not None:
            raise ValueError(f"未注册的主题路径: {topic_path}，请先在 dimensions.json 中注册")

        return topic_path

    def _auto_register_topic_path(self, full_path: str, parts: list, start_idx: int):
        """自动将缺失的主题路径段写入注册表（线程安全）

        Fix (P0): 加 threading.Lock 防止同进程内多线程同时写 JSON 导致损坏。
        Fix (Bug 3): 移除 fcntl 文件锁，改用 threading.Lock 实现线程安全。
        """
        import os

        with _registry_write_lock:
            self._do_register_topic_path(full_path, parts, start_idx)

    def _do_register_topic_path(self, full_path: str, parts: list, start_idx: int):
        """实际的注册逻辑（由 _auto_register_topic_path 持锁后调用）"""
        import os

        node = self.registry["topics"]
        # 先导航到 start_idx 之前的节点
        for p in parts[:start_idx]:
            if "children" in node[p]:
                node = node[p]["children"]
            else:
                node[p]["children"] = {}
                node = node[p]["children"]

        # 创建缺失的路径段
        for p in parts[start_idx:]:
            if p not in node:
                node[p] = {"name": p, "keywords": [p]}
            else:
                if "keywords" not in node[p]:
                    node[p]["keywords"] = [p]
            if p != parts[-1]:
                if "children" not in node[p]:
                    node[p]["children"] = {}
                node = node[p]["children"]

        # Fix (Bug 3): threading.Lock 已在 _auto_register_topic_path 中获取
        # 此处直接原子写入（os.rename 在同一文件系统上是原子的）
        registry_path = self.registry_path
        try:
            # 持有锁期间读取磁盘上最新版本
            latest = {}
            if registry_path.exists():
                try:
                    with open(registry_path, "r", encoding="utf-8") as f:
                        content = f.read()
                        if content.strip():
                            latest = json.loads(content)
                except (json.JSONDecodeError, IOError, ValueError) as read_err:
                    import logging as _logging
                    _logging.getLogger(__name__).warning(
                        f"注册表文件读取异常，用内存版本兜底: {read_err}"
                    )
                    latest = {}

            # 合并：把我们新增的路径合并到最新版本
            if "topics" in latest:
                self._merge_topics(latest["topics"], self.registry["topics"])
            else:
                latest = {"topics": dict(self.registry["topics"])}

            # 原子写入：写 tmp → rename（rename 在同一文件系统上是原子的）
            import uuid as _uuid
            tmp = f"{registry_path}.{os.getpid()}.{_uuid.uuid4().hex[:8]}.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.registry, f, ensure_ascii=False, indent=4)
            os.replace(tmp, str(registry_path))
        except Exception as e:
            import logging as _logging
            _logging.getLogger(__name__).warning(
                f"主题注册表写入失败 path={full_path}: {e} — "
                f"该主题在下次重启前有效，但可能丢失。建议检查磁盘空间和文件权限。"
            )

    @staticmethod
    def _merge_topics(base: dict, incoming: dict):
        """将 incoming 的主题树合并到 base 中（深合并）"""
        for key, val in incoming.items():
            if key not in base:
                base[key] = val
            else:
                # 合并 keywords
                if "keywords" in val:
                    existing_kw = set(base[key].get("keywords", []))
                    existing_kw.update(val["keywords"])
                    base[key]["keywords"] = list(existing_kw)
                # 递归合并 children
                if "children" in val:
                    if "children" not in base[key]:
                        base[key]["children"] = {}
                    DimensionEncoder._merge_topics(base[key]["children"], val["children"])

    def list_topics(self, prefix: str = "") -> list:
        """列出所有主题路径"""
        results = []
        self._walk_topics(self.registry["topics"], prefix, results)
        return results

    def _walk_topics(self, node, path, results):
        for key, val in node.items():
            full = f"{path}.{key}" if path else key
            if "children" in val:
                self._walk_topics(val["children"], full, results)
            else:
                results.append(full)

    # ── 性质编码 ──────────────────────────────────────────

    def encode_nature(self, nature_code: str) -> str:
        """通过 code（如 'explore'）查找 D 编码"""
        if nature_code in self._nature_by_code:
            return self._nature_by_code[nature_code]
        # 也支持直接传 D 编码
        if nature_code in self.registry["natures"]:
            return nature_code
        raise ValueError(f"未注册的性质: {nature_code}")

    # ── 知识类型编码 ──────────────────────────────────────

    def encode_knowledge(self, knowledge_code: str) -> str:
        """通过 code（如 'rule'）查找 K 编码（O(1) 反向索引）"""
        if knowledge_code in self._knowledge_by_code:
            return self._knowledge_by_code[knowledge_code]
        # 也支持直接传 K 编码
        if knowledge_code in self.registry["knowledge_types"]:
            return knowledge_code
        raise ValueError(f"未注册的知识类型: {knowledge_code}")

    # ── 重要度编码 ──────────────────────────────────────────

    VALID_IMPORTANCE = ("high", "medium", "low")

    def encode_importance(self, level: str) -> str:
        """校验并返回 importance 值"""
        if level not in self.VALID_IMPORTANCE:
            raise ValueError(f"未注册的重要度: {level}，可选: {self.VALID_IMPORTANCE}")
        return level

    # ── 工具编码 ──────────────────────────────────────────

    def encode_tool(self, tool_id: str) -> str:
        """直接用注册表里的工具 ID，如 t_lc"""
        if tool_id not in self.registry["tools"]:
            raise ValueError(f"未注册的工具 ID: {tool_id}，请先在 dimensions.json 中注册")
        return tool_id

    def get_tool_by_code(self, code: str) -> str:
        """通过 code 查 tool_id（O(1) 反向索引）"""
        if code in self._tool_by_code:
            return self._tool_by_code[code]
        raise ValueError(f"未找到 code={code} 的工具")

    # ── Memory ID 生成 ────────────────────────────────────

    def generate_memory_id(
        self,
        time_id: str,
        person_id: str,
        topic_codes: list[str],
        nature_id: str,
        tool_ids: list[str] = None,
    ) -> str:
        """组合维度生成唯一 memory_id
        格式: T20260411.213742_P01_rag.vdb_D04_lc.ch
        """
        # 主题取主主题（第一个）
        primary_topic = topic_codes[0] if topic_codes else "none"
        # 短化：去掉顶层前缀 ai./dev./life.
        for prefix in ("ai.", "dev.", "life."):
            if primary_topic.startswith(prefix):
                primary_topic = primary_topic[len(prefix):]
                break

        # 工具缩写（取前两个）
        tool_part = ""
        if tool_ids:
            tool_codes = []
            for tid in tool_ids[:2]:
                info = self.registry["tools"].get(tid, {})
                tool_codes.append(info.get("code", tid))
            tool_part = "." + "+".join(tool_codes)

        raw = f"{time_id}_{person_id}_{primary_topic}_{nature_id}{tool_part}"

        # 末尾加 8 位 uuid hex 保证唯一性（16^8 = 42 亿种可能，碰撞概率可忽略）
        # 替代原来的 random.randint(0, 0xFFFF)（只有 65536 种，批量写入必撞）
        suffix = uuid.uuid4().hex[:8]
        raw = f"{raw}_{suffix}"

        # 如果组合太长，截断并保留 hash
        if len(raw) > 64:
            h = hashlib.sha256(raw.encode()).hexdigest()[:6]
            raw = f"{raw[:58]}_{h}"

        return raw

    @staticmethod
    def content_hash(content: str) -> str:
        return hashlib.sha256(content.encode("utf-8")).hexdigest()


if __name__ == "__main__":
    enc = DimensionEncoder()
    print("=== 性质列表 ===")
    for nid, info in enc.registry["natures"].items():
        print(f"  {nid} ({info['code']:8s}) → {info['name']}  {info['desc']}")

    print("\n=== 主题树 ===")
    for t in enc.list_topics():
        print(f"  {t}")

    print("\n=== 示例编码 ===")
    tid = enc.encode_time(precision="second")
    mid = enc.generate_memory_id(
        time_id=tid,
        person_id="P01",
        topic_codes=["ai.rag.vdb"],
        nature_id=enc.encode_nature("explore"),
        tool_ids=["t_ch", "t_lc"],
    )
    print(f"  memory_id = {mid}")
