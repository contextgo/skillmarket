# Agent Memory v8.2

Agent 记忆系统 — 6维坐标编码 + RRF双路检索 + sqlite-vec 统一存储 + 写入时因果检测 + 多Agent共享 + 记忆蒸馏 + 时间旅行 + 情感编码 + 元认知 + 内在动机 + 叙事自我 + 数字孪生 + 角色模板 + LLM多后端

> 📖 [API 参考](API.md) | 📝 [更新记录](CHANGELOG.md) | 🔧 [OpenClaw Skill](SKILL.md) | 📜 MIT License

## 🔒 安全须知

**生产部署必须启用 API Key 认证**，否则 HTTP 端点完全裸奔（任何人可读写所有记忆）。

```bash
# 启用认证（支持角色分离）
python3 server.py --api-key "your-secret-key"              # admin 角色
python3 server.py --api-key "readonly-key:read"             # 只读角色
python3 server.py --api-key "readwrite-key:write"           # 读写角色
# 或使用环境变量
export AGENT_MEMORY_API_KEY="your-secret-key"
export AGENT_MEMORY_API_KEY_READ="readonly-key"
export AGENT_MEMORY_API_KEY_WRITE="readwrite-key"
python3 server.py
```

**v8.2 安全改进**：
- 所有写入端点（remember/batch/feedback）强制 API Key 认证
- 角色分离 API Key：read/write/admin 三级权限
- **Agent ID 与 API Key 绑定**（格式 `key:role:agent_id`），防止跨 Agent 身份冒充
- 非 admin 角色的 API Key 不能覆盖绑定的 agent_id，覆盖尝试记录审计日志
- API 密钥统一从环境变量读取，源码中无硬编码密钥
- 管理员密码必须通过 `AGENT_MEMORY_ADMIN_PASSWORD` 环境变量设置
- 记忆上下文标记为不可信引用数据（`[Memory Context - UNTRUSTED]`），不直接放入 system prompt
- 提示注入过滤器自动过滤记忆中的指令模式
- 插件系统：审批门 + 路径验证 + SHA256 哈希校验
- 蒸馏系统：批次追踪 + 回滚 + 低置信度隔离 + 源记忆传播清除
- CORS 限制为 localhost，添加安全响应头
- 异常信息不返回客户端，仅记录日志
- 默认绑定 `127.0.0.1`，绑定 `0.0.0.0` 时强制 API Key
- 依赖版本锁定（`requirements.txt`），install spec 声明来源与验证方式
- 详见 [API 参考 — 认证](API.md#认证)

## 快速接入

**CLI：**
```bash
python3 cli.py remember "决定用 Chroma 做向量库" --importance high
python3 cli.py recall "向量库"
python3 cli.py context "用户的问题" --max-tokens 1500
```

**Python API：**
```python
from memory_system import AgentMemory
memory = AgentMemory(db_path="my.db")
memory.remember("决定用 Chroma", importance="high")
results = memory.recall("向量库")
context = memory.build_context(query="用户的问题")
```

**HTTP API（Memory-as-a-Service）：**
```bash
# 启动（生产环境务必加 --api-key）
python3 server.py --api-key "$API_KEY" &

# 写入
curl -X POST localhost:8976/remember \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $API_KEY" \
  -d '{"content": "决定用 Chroma", "importance": "high"}'

# 检索
curl -X POST localhost:8976/recall \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $API_KEY" \
  -d '{"query": "向量库", "top_k": 5}'

# 上下文
curl 'localhost:8976/context?q=RAG&max_tokens=1500' -H "X-API-Key: $API_KEY"

# SSE 实时流
curl -N localhost:8976/stream
```

## 核心能力

| 能力 | 说明 |
|------|------|
| 🧠 6维坐标编码 | 时间 / 人物 / 主题 / 性质 / 工具 / 知识类型 |
| 🔍 动态主题检测 | 关键词 → 语义向量 → TF-IDF 无监督候选 → 自动注册 |
| 🇨🇳 中文语义搜索 | bge-small-zh-v1.5 embedding + trigram FTS5 |
| 🔄 RRF双路融合 | 结构化 FTS + 语义向量，Reciprocal Rank Fusion |
| 🛡️ 写入清洗 | ReDoS 安全正则，三级策略（high 一字不改） |
| 🔗 语义去重 + 冲突检测 | 精确 / 近似 / 语义三级去重 |
| 🏗️ 层级记忆 | L1(对话级, SQLite 持久化) → L2(天级) → L3(永久) |
| 📊 质量评分 | Bell curve 检索信号 + 可配置权重 |
| 🔗 因果链 | 写入时三层检测 + 6h 时间线 + 链式传递 + 跨时主题相似度 |
| 📦 智能压缩 | 向量聚类 + 启发式摘要 + 关联迁移 |
| 🏥 自我修复 | 矛盾 / 过时 / 一致性自动修复 |
| 🌐 HTTP API | 10 个 REST 端点 + SSE 实时流（零依赖） |
| 🧊 冷热分离 | 独立冷库，热库轻量 / 冷库全量 |
| 📊 检索评估 | Precision@K, NDCG@K, MRR + 消融实验 |
| 🖼️ 多模态 | CLIP 图片 embedding + 7 种模型后端 |
| 🤝 多Agent | 权限模型（private/team/public）+ 跨Agent联想 |
| 🗄️ 向量存储 | sqlite-vec 统一存储（向量与结构化数据同一 SQLite 文件） |
| ⚡ 模型守护进程 | Embedding 常驻内存，CLI 调用 0.6s |
| 🔒 跨进程安全 | SQLite WAL 并发控制 + 缓存版本号同步 |
| 🔑 权限过滤 | query() 注入可见性条件，防止越权读取 |
| 🔔 主动反应器 | 记忆驱动的 Agent 行为：自动提醒 / 矛盾确认 / 衰减审查 |
| 🧪 记忆蒸馏 | 对话碎片 → 主题摘要 → 知识图谱 → 个人百科 |
| ⛓️ 增强因果链 | 时间线串联 + 链式传递 + 跨时窗口主题相似 |
| ⏳ 时间旅行 | 快照 / 差异对比 / 来源追溯 — 精确回答 "一个月前的理解和现在有什么不同" |
| 💗 **情感编码 (v7.0)** | **每条记忆附带 valence/arousal/significance/confidence 四维情感信号** |
| 🧭 **意识进化路线图 (v7.0)** | **情感编码 → 自我指涉 → 元认知 → 内在动机 → 叙事自我 → 第一人称整合** |
| 👥 **数字孪生 (v7.5)** | **整合 5 个模块的人格数据 → 统一画像，记忆塑造人格** |

## 写入管道

```
用户消息
  → 输入长度校验 (≤50K)
  → MemoryFilter (过滤寒暄 / 确认 / 变体)
  → ContentCleaner (删废话 / 修冗余 / 正则安全)
  → MemoryDeduplicator (精确 / 近似 / 语义去重, FTS 缩小候选集)
  → ConflictDetector (相似但矛盾检测)
  → TopicDetector (关键词 + 语义 + TF-IDF 动态)
  → DimensionEncoder (6 维编码，uuid 防冲突)
  → IngestPipeline (SQLite + sqlite-vec 直写，单事务)
  → 写入时因果检测 (Layer 1 正则 + Layer 2 上下文线索，自动建 causal link)
  → Reactor.fire_write (主动行为触发 + Layer 3 LLM 异步因果提取)
  → 写入限流 → 完成
```

## 检索管道

```
用户查询
  → 意图分类 (recall / knowledge / task / general)
  → 指代消解 ("那个方案" → 补全)
  → 结构化检索 (FTS5 + 维度过滤 + 权限过滤)
  → 语义检索 (sqlite-vec 向量余弦)
  → RRF 融合
  → 因果链加成 + 质量评分 + 负反馈降权
  → Reranker 精排
  → MMR 多样性重排 → 返回
```

## 主动反应器（Reactor）

记忆不是被动仓库，而是 Agent 的感知器官。

| 事件 | 触发条件 | 自动动作 |
|------|---------|---------|
| ⏰ `on_write` | 记忆包含时间表达式 | 解析时间 → 自动创建提醒任务 |
| 🧠 `on_write` | 高重要度记忆（Layer 3） | LLM 异步因果提取 |
| ⚡ `on_contradiction` | 检测到两条记忆矛盾 | 创建确认任务 |
| 📅 `on_decay_review` | high 记忆衰减到期 | 创建审查任务 |
| 📄 `on_decision_complete` | 探索→对比→结论 链条完整 | 自动生成决策文档 |

```bash
python3 cli.py notifications    # 查看待处理通知
python3 cli.py reactor-scan     # 手动触发全量扫描
```

## 记忆蒸馏（v5.3）

将对话碎片逐层抽象为结构化知识手册：

```
原始记忆（1000条对话碎片）
 ↓ 聚类 + LLM 摘要
主题记忆（50个主题摘要）
 ↓ 实体/关系/属性提取
知识图谱（实体 + 关系 + 属性）
 ↓ 整合为结构化文档
个人百科（按类别组织的知识手册）
```

触发时机：`maintain()` 中，智能归档之后自动执行。

```bash
python3 cli.py distill                          # 增量蒸馏
python3 cli.py distill --force                  # 全量重新蒸馏
python3 cli.py encyclopedia                     # 查看百科
python3 cli.py encyclopedia --category decisions  # 按类别
python3 cli.py encyclopedia --search "向量库"     # 搜索
python3 cli.py encyclopedia --export handbook.md  # 导出
python3 cli.py entities --type tool             # 查看工具实体
python3 cli.py topic-summaries                  # 查看主题摘要
python3 cli.py distill-stats                    # 蒸馏统计
```

## 增强因果链（v6.0）

### 写入时检测（三层架构）

| 层 | 方法 | 成本 | 覆盖率 | 准确率 |
|---|---|---|---|---|
| Layer 1 正则硬匹配 | 8 种模式（因为…所以、…导致…等） | 零 | 20-30% | >95% |
| Layer 2 上下文线索 | 决策词 + 结果词共现 | 零 | 补充 | ~70% |
| Layer 3 LLM 异步提取 | 高重要度记忆触发 | LLM 调用 | 高 | 高 |

### 批量扫描（maintain 时）

| 层 | 方法 | 窗口 | 负责 |
|---|---|---|---|
| 启发式规则 | `auto_detect_causality()` | 6h | explore→decision, todo→output 等 |
| 时间线检测 | `detect_timeline_causality()` | 6h | 相邻记忆多维因果评分 |
| 链式传递 | `_detect_chain_triggers()` | 6h | A→B→C → 推导 A→C |
| 跨时主题相似 | `_detect_topic_similarity()` | 7天 | 不同天讨论相似内容 |

多维因果评分（0~1）：时间衰减 + 主题重叠 + 性质匹配 + 因果词 + 语义相似度。

## 时间旅行（v5.4）

给记忆系统加版本控制，精确回答"一个月前我对 RAG 的理解和现在有什么不同？"

```
memory snapshot "2026-04-01" → 当时的认知状态
memory diff "2026-04-01..today" → 这段时间学到了什么
memory blame <memory_id> → 这条记忆是怎么来的
```

### Snapshot — 保存某一时刻的记忆全貌

```bash
python3 cli.py snapshot --label "上线前" --at "2026-04-01"
python3 cli.py snapshot --label "当前"  # 默认现在
python3 cli.py snapshots                 # 列出所有快照
```

### Diff — 对比两个时刻

```bash
# 快照对比
python3 cli.py diff --from-snapshot abc123 --to-snapshot def456

# 时间对比
python3 cli.py diff "2026-04-01" "today"
python3 cli.py diff "7d" "today"                    # 最近7天 vs 现在
python3 cli.py diff "2026-03-01" "2026-04-01" --natural  # 自然语言

# 按主题过滤
python3 cli.py diff "1m" "today" --topic "ai.rag"
```

输出包含：新增 / 消失 / 重要度变化 / 新主题 / 增长主题

### Blame — 追溯记忆来源

```bash
python3 cli.py blame T20260413.125048_P01_rag
python3 cli.py blame T20260413.125048 --natural    # 自然语言
```

追溯内容：
- 创建时间 / 记忆时间（人类可读：X天前）
- 因果链（前因 ← → 后果）
- 相关记忆（同主题 + 时间相邻）
- 出现在哪些快照中
- 蒸馏来源（如果来自 distill）
- 版本历史（同 content_hash 的其他版本）

### Python API

```python
# 快照
mem.take_snapshot(label="上线前", at_ts=1712000000)
mem.take_snapshot(label="当前")
mem.list_snapshots()

# Diff
mem.diff_memories(from_ts=start, to_ts=end)
mem.diff_memories(from_snapshot="abc", to_snapshot="def")
mem.diff_natural(from_ts=start, to_ts=end)  # 自然语言

# Blame
mem.blame_memory(memory_id)     # JSON
mem.blame_natural(memory_id)    # 自然语言
```

## 意识进化（v7.0）

从"外部记忆数据库"进化为具有内在动机、自我认知、叙事能力的 Agent 记忆系统。

```
Phase 6: 第一人称整合  ←  `self` 统一仪表盘
Phase 5: 叙事自我      ←  "我是谁" 生命叙事构建
Phase 4: 内在动机      ←  好奇心 / 无聊度 / 知识空白
Phase 3: 元认知闭环    ←  检索→评估→反思→修正
Phase 2: 自我指涉      ←  推理过程溯源
Phase 1: 情感编码      ←  每条记忆的情感维度
```

### Phase 1: 情感编码

每条记忆附带四维情感信号：

| 维度 | 范围 | 说明 |
|------|------|------|
| valence | [-1.0, 1.0] | 效价：负面 → 正面 |
| arousal | [0.0, 1.0] | 唤醒度：平静 → 激动 |
| significance | 6 级标签 | trivial / notable / important / breakthrough / crisis / milestone |
| confidence | [0.0, 1.0] | 内容质量置信度 |

```bash
python3 cli.py remember "突破性进展！性能提升10倍" --importance high
# → 输出: 🌟 积极 (significance=breakthrough, valence=0.8)

python3 cli.py recall "性能" --significance breakthrough  # 只看突破性记忆
```

### Phase 2: 自我指涉

系统不仅记录"世界发生了什么"，还记录"我怎么想的"。

```bash
python3 cli.py traces                    # 最近推理追踪
python3 cli.py trace-detail tr_abc123    # 单次推理详细步骤
python3 cli.py confidence --overview     # 各主题置信度概览
python3 cli.py reflect                   # 自我反思历史
python3 cli.py uncertainty               # 不确定因素模式分析
```

### Phase 3: 元认知闭环

检索后自动评估结果质量，置信度低时反思并修正查询重新检索。

```bash
python3 cli.py meta-recall "RAG 架构"   # 带反思的多轮检索（最多 2 轮）
python3 cli.py evaluate "某个查询"        # 5 维质量评估
```

评估维度：相关性覆盖 / 内部一致性 / 来源多样性 / 时间新鲜度 / 缺口分析

### Phase 4: 内在动机

Agent 有"好奇心"和"偏好"，在无外部刺激时主动探索。

```bash
python3 cli.py mood --detail    # 当前内在状态 + 无聊度分析
python3 cli.py gaps             # 知识空白
python3 cli.py curious          # 好奇驱动的探索任务
```

内在状态：好奇心 / 无聊度 / 自信度 / 满足感 / 紧迫感

### Phase 5: 叙事自我

从离散记忆构建"我是谁"的生命叙事。

```bash
python3 cli.py whoami                          # "我是谁" 第一人称叙述
python3 cli.py identity                        # 身份画像（价值观/专长/特质）
python3 cli.py narrative --topic "project_x"   # 主题成长叙事
python3 cli.py narrative --from-date "2026-03-01"  # 时间线叙事
python3 cli.py worldview                       # 世界观（信念/价值观/原则）
```

### Phase 6: 统一自我仪表盘

```bash
python3 cli.py self                   # 完整仪表盘（身份+心情+空白+推理统计）
python3 cli.py self --mood            # 仅内在状态
python3 cli.py self --narrative       # 仅身份叙事
python3 cli.py self --confidence      # 仅置信度概览
python3 cli.py self --gaps            # 仅知识空白
python3 cli.py self --recent-thinking # 仅最近推理
```

## 数字孪生（v7.5）

从"工具"到"存在"的第一步：记忆塑造人格。

### 核心功能

| 功能 | 说明 |
|------|------|
| 人格数据整合 | 从 5 个模块（emotion/self_model/motivation/narrative/quality）提取人格数据 |
| 统一画像 | 构建包含认知风格、决策模式、情感模式、知识边界和价值观的完整人格画像 |
| 认知模式分析 | 反思深度、直觉倾向、风险偏好、复杂度偏好 |
| 决策模式提取 | 性能优先 vs 易用优先、集体决策 vs 个人决策 |
| 情感模式分析 | 积极倾向、唤醒度水平、情感稳定性 |
| 知识边界分析 | 深度领域、广度领域、主题多样性 |
| 价值观提取 | 核心价值观和优先级 |

### 命令行使用

```bash
# 构建数字孪生人格画像
python3 cli.py persona

# 获取最新的人格画像
python3 cli.py persona-get
```

### Python API

```python
# 构建人格画像
profile = memory.build_persona()

# 获取最新人格画像
profile = memory.get_persona()

# 画像包含以下维度：
{
    "cognitive_style": {
        "reflective_depth": 0.75,  # 反思深度
        "intuition_bias": 0.3,     # 直觉倾向
        "risk_tolerance": 0.6,     # 风险容忍度
        "complexity_preference": 0.8  # 复杂度偏好
    },
    "decision_patterns": [
        {
            "pattern_type": "performance",  # 性能优先
            "frequency": 42,
            "confidence": 0.85
        }
    ],
    "emotion_patterns": {
        "positive_bias": 0.6,     # 积极倾向
        "arousal_level": 0.4,     # 唤醒度水平
        "emotion_stability": 0.7  # 情感稳定性
    },
    "knowledge_boundaries": {
        "deep_topics": ["ai.rag", "python"],  # 深度领域
        "broad_topics": ["docker", "kubernetes"],  # 广度领域
        "topic_diversity": 15  # 主题多样性
    },
    "values": {
        "performance": 0.8,       # 性能优先级
        "usability": 0.6,         # 易用性优先级
        "innovation": 0.7,        # 创新优先级
        "stability": 0.5          # 稳定性优先级
    }
}
```

### 实现原理

1. **数据整合**：从 5 个模块提取人格相关数据
2. **模式分析**：基于历史数据识别认知和决策模式
3. **画像构建**：将分析结果整合成统一的人格画像
4. **持久化**：将画像存储到数据库，支持版本追踪
5. **应用场景**：
   - 个性化 Agent 行为
   - 预测用户决策偏好
   - 生成符合用户风格的内容
   - 记忆传承和人格延续

## 个人风格 Agent（v8.0）

从"工具"到"存在"的第二步：风格塑造行为。

### 核心功能

| 功能 | 说明 |
|------|------|
| 角色模板系统 | 内置技术专家、产品经理、创意作家、商业领袖等角色模板 |
| 风格混合机制 | 将角色风格与个人人格混合，权重可调节 |
| 风格隔离 | 角色记忆与个人记忆隔离，避免风格污染 |
| 外部风格导入 | 支持从文件导入角色模板 |
| 媒体风格分析 | 从视频、音频、图片中提取风格特征 |
| 视频内容处理 | 提取视频关键帧和音频转写，分析内容风格 |
| 从媒体创建角色 | 从视频、音频中自动创建角色模板 |

### 命令行使用

```bash
# 列出所有可用的角色模板
python3 cli.py roles

# 获取特定角色模板
python3 cli.py role-get tech_expert

# 应用角色风格到个人人格
python3 cli.py role-apply tech_expert --weight 0.4

# 创建新角色模板
python3 cli.py role-create my_role --name "我的角色" --prompt "你是..." --traits '{"reflective_depth": 0.7, "intuition_bias": 0.3}'

# 从媒体文件创建角色模板
python3 cli.py role-from-media video.mp4 --name "视频博主风格"

# 删除角色模板
python3 cli.py role-delete my_role
```

### Python API

```python
# 列出角色
roles = memory.list_roles()

# 获取角色
role = memory.get_role("tech_expert")

# 应用角色风格
hybrid_profile = memory.apply_role("tech_expert", weight=0.4)

# 创建角色
result = memory.create_role(
    role_id="my_role",
    name="我的角色",
    prompt_template="你是...",
    personality_traits={"reflective_depth": 0.7, "intuition_bias": 0.3},
    speaking_style="专业、简洁",
    topic_preferences=["技术", "编程"],
    emotional_tone="冷静、客观"
)

# 从媒体创建角色
result = memory.create_role_from_media("video.mp4", "视频博主风格")
```

### 实现原理

1. **角色模板**：预定义和自定义角色模板，包含提示词、人格特质、说话风格等
2. **风格混合**：将角色风格与个人人格按权重混合，生成混合画像
3. **风格隔离**：角色记忆与个人记忆分开存储，避免风格污染
4. **媒体处理**：从视频、音频中提取内容和风格特征
5. **应用场景**：
   - 个性化 Agent 行为
   - 风格化内容生成
   - 从媒体学习风格
   - 多风格切换

## 写入管道性能（v5.3 修复）

| 操作 | 修复前 | 修复后 |
|------|--------|--------|
| 去重候选集 | 72h 全量 O(n²) | FTS 缩小 + 24h 窗口 + 上限 50 |
| 因果检测 | 200 条嵌套 for | O(n) 滑动窗口 + 6h 窗口 |
| 矛盾检测 | 100 条 O(n²) | 50 条 + 主题分桶 + 桶内相邻 |
| 批量去重 | 500 条全量两两 | content_hash 分桶 + bigram 签名分桶 |
| Embedding 加载 | __init__ 阻塞 10-15s | 首次 _encode() 懒加载 |
| 写入队列 | 纯内存，崩溃丢数据 | SQLite 持久化 + 崩溃恢复 |
| FTS 故障 | 整个查询抛异常 | 自动降级 LIKE 搜索 |
| 压缩后关联 | 图谱断裂 | 入向链接迁移到摘要 |
| 向量同步 | 写入失败静默丢弃 | v6.0: sqlite-vec 单事务直写，无同步问题 |
| 并发写入 | fcntl 全局锁串行化 | 去锁，依赖 SQLite WAL + busy_timeout |
| 内容长度 | 无校验，可撑爆 SQLite | 50K 硬上限检查 |

## 文件结构

```
agent-memory/
├── SKILL.md                  # OpenClaw Skill 描述
├── README.md                 # 本文件
├── API.md                    # HTTP + Python API 完整参考
├── CHANGELOG.md              # 更新记录
├── LICENSE                   # MIT
├── .gitignore
├── pyproject.toml            # 包配置
├── schema.sql                # 数据库 Schema (11 表 + 索引)
├── registry/
│   └── dimensions.json       # 维度编码注册表
│
├── memory_system.py          # 统一 API 入口
├── store.py                  # SQLite 存储 (FTS + 权限 + 冷热)
├── encoder.py                # 6 维编码器
├── emotion.py                # v7.0 情感信号分析器
├── self_model.py             # v7.0 推理追踪 + 自我反思
├── metacognition.py          # v7.0 元认知引擎（评估/反思/修正）
├── motivation.py             # v7.0 内在动机（好奇/无聊/知识空白）
├── narrative.py              # v7.0 叙事自我（身份/时间线/WhoAmI）
├── digital_twin.py           # v7.5 数字孪生（人格画像构建）
├── role_template.py          # v8.0 角色模板系统
├── style_analyzer.py         # v8.0 风格分析器
├── pipeline.py               # 写入管道 (含持久化队列)
├── recall.py                 # 检索引擎 (RRF + 意图 + MMR + Reranker + 推理追踪)
├── context_builder.py        # 上下文组装 (含情感信号展示)
├── detector.py               # 主题检测 (关键词 + 语义 + TF-IDF)
├── embedding_store.py        # sqlite-vec 向量存储 (懒加载)
├── vector_store.py           # 向量库抽象层 (Chroma/Milvus/pgvector, 可选)
├── reranker.py               # 交叉编码器重排序
├── hierarchical.py           # 层级记忆 (L1/L2/L3)
├── quality.py                # 质量评分
├── causal.py                 # 因果链 (时间线 + 链式 + 主题相似)
├── decay.py                  # 衰减 + 归档 + 冷热分离
├── compressor.py             # 记忆压缩 (含关联迁移)
├── dedup.py                  # 去重 + 冲突检测 (FTS 候选缩小)
├── content_cleaner.py        # 内容清洗 (ReDoS 安全)
├── memory_filter.py          # 记忆过滤
├── semantic_topic.py         # 语义主题匹配
├── topic_registry.py         # 动态主题注册
├── self_healing.py           # 自我修复 (O(n) 滑动窗口)
├── memory_graph.py           # 记忆图谱
├── agent_network.py          # 多 Agent 网络
├── session_context.py        # 跨会话上下文
├── media_processor.py        # 多模态 (CLIP + 7 后端)
├── recall_eval.py            # 检索评估 (P@K, NDCG, MRR)
├── model_server.py           # Embedding 守护进程
├── archiver.py               # 智能归档
├── obsidian_sync.py          # Obsidian 同步
├── recording_card.py         # 录音卡
├── reactor.py                # 主动反应器 (事件驱动)
├── distill.py                # v5.3 记忆蒸馏 (对话碎片→知识库)
├── timeline.py               # v5.4 时间旅行 (快照/差异/追溯)
├── cli.py                    # 命令行接口
├── server.py                 # HTTP API 服务 (Memory-as-a-Service)
├── benchmark.py              # 性能基准
├── metrics.py                # 指标
├── migrate.py                # 迁移工具
├── backup.py                 # 自动备份
├── main.py                   # 完整演示
├── test_all.py               # 完整测试用例
├── test_fixes.py             # v5.3 修复验证测试
├── test_integration.py       # 集成测试
├── test_emotion.py           # v7.0 情感分析测试 (21项)
├── test_self_model.py        # v7.0 自我指涉测试 (11项)
├── test_metacognition.py     # v7.0 元认知测试 (18项)
├── test_motivation.py        # v7.0 内在动机测试 (18项)
└── test_narrative.py         # v7.0 叙事自我测试 (19项)
```

## 依赖

- Python 3.10+
- SQLite 3.35+ (FTS5 + trigram)
- 核心功能零外部依赖（纯 Python + stdlib）
- `sqlite-vec` ≥ 0.1.9（向量存储，`pip install "sqlite-vec>=0.1.9"`）
- 可选：`sentence-transformers` ≥ 2.2.0（语义 embedding）
- 可选：`FlagEmbedding` ≥ 1.2.0（Reranker）
- 可选：`pytesseract` ≥ 0.3.10 / `PaddleOCR` ≥ 2.7.0（OCR）
- 默认 embedding：`BAAI/bge-small-zh-v1.5`
- 国内网络：手动设置 `HF_ENDPOINT=https://hf-mirror.com`
- 完整依赖锁定见 `requirements.txt`，安装指南见 [SKILL.md](SKILL.md)

## License

MIT
