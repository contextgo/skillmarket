// app.js - Agent Memory System Web UI 脚本

class App {
    constructor() {
        this.initElements();
        this.initEventListeners();
        this.loadStatus();
        this.loadSupportedFormats();
    }

    initElements() {
        // 菜单和内容区域
        this.menuItems = document.querySelectorAll('.menu-item');
        this.sections = document.querySelectorAll('.section');
        
        // 聊天相关
        this.chatMessages = document.getElementById('chat-messages');
        this.chatInput = document.getElementById('chat-input-field');
        this.sendBtn = document.getElementById('send-btn');
        this.chatFileBtn = document.getElementById('chat-file-btn');
        this.chatFileInput = document.getElementById('chat-file-input');
        
        // 投喂相关
        this.feedTabs = document.querySelectorAll('.feed-tabs .tab-btn');
        this.feedTabPanes = document.querySelectorAll('#feed-section .tab-pane');
        this.textContent = document.getElementById('text-content');
        this.feedTextBtn = document.getElementById('feed-text-btn');
        this.urlInput = document.getElementById('url-input');
        this.feedUrlBtn = document.getElementById('feed-url-btn');
        this.fileInput = document.getElementById('file-input');
        this.feedFileBtn = document.getElementById('feed-file-btn');
        this.fileList = document.getElementById('file-list');
        
        // 转换相关
        this.inputPath = document.getElementById('input-path');
        this.outputPath = document.getElementById('output-path');
        this.convertBtn = document.getElementById('convert-btn');
        this.formatsList = document.getElementById('formats-list');
        
        // 记忆相关
        this.memoryTabs = document.querySelectorAll('.memory-tabs .tab-btn');
        this.memoryTabPanes = document.querySelectorAll('#memory-section .tab-pane');
        this.memoryContent = document.getElementById('memory-content');
        this.addMemoryBtn = document.getElementById('add-memory-btn');
        this.searchQuery = document.getElementById('search-query');
        this.searchMemoryBtn = document.getElementById('search-memory-btn');
        this.searchResults = document.getElementById('search-results');
        
        // 工具相关
        this.toolsCategories = document.getElementById('tools-categories');
        this.toolDetails = document.getElementById('tool-details');
        this.toolParams = document.getElementById('tool-params');
        this.executeToolBtn = document.getElementById('execute-tool-btn');
        this.toolResults = document.getElementById('tool-results');
        
        // 其他
        this.exportBtn = document.getElementById('export-btn');
        this.clearBtn = document.getElementById('clear-btn');
        this.llmStatus = document.getElementById('llm-status');
        this.statsStatus = document.getElementById('stats-status');
        this.systemStatus = document.getElementById('system-status');
        this.notification = document.getElementById('notification');
        this.notificationMessage = document.getElementById('notification-message');
        
        // 设置相关
        this.apiKeyInput = document.getElementById('api-key');
        this.llmModelSelect = document.getElementById('llm-model');
        this.apiBaseUrlInput = document.getElementById('api-base-url');
        this.saveApiKeyBtn = document.getElementById('save-api-key');
        
        // 当前选中的工具
        this.currentTool = null;
    }

    initEventListeners() {
        // 菜单项点击
        this.menuItems.forEach(item => {
            item.addEventListener('click', () => this.switchSection(item.dataset.section));
        });

        // 聊天发送
        this.sendBtn.addEventListener('click', () => this.sendChatMessage());
        this.chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendChatMessage();
        });

        // 聊天文件上传
        this.chatFileBtn.addEventListener('click', () => {
            this.chatFileInput.click();
        });
        
        this.chatFileInput.addEventListener('change', (e) => {
            this.uploadChatFile(e.target.files);
        });

        // 投喂标签切换
        this.feedTabs.forEach(tab => {
            tab.addEventListener('click', () => this.switchTab('feed', tab.dataset.tab));
        });

        // 投喂按钮
        this.feedTextBtn.addEventListener('click', () => this.feedText());
        this.feedUrlBtn.addEventListener('click', () => this.feedUrl());
        this.feedFileBtn.addEventListener('click', () => this.feedFile());

        // 记忆标签切换
        this.memoryTabs.forEach(tab => {
            tab.addEventListener('click', () => this.switchTab('memory', tab.dataset.tab));
        });

        // 记忆按钮
        this.addMemoryBtn.addEventListener('click', () => this.addMemory());
        this.searchMemoryBtn.addEventListener('click', () => this.searchMemory());

        // 转换按钮
        this.convertBtn.addEventListener('click', () => this.convertFormat());

        // 工具按钮
        this.executeToolBtn.addEventListener('click', () => this.executeTool());

        // 其他按钮
        this.exportBtn.addEventListener('click', () => this.exportContent());
        this.clearBtn.addEventListener('click', () => this.clearHistory());
        
        // 设置相关
        this.saveApiKeyBtn.addEventListener('click', () => this.saveSettings());
    }

    switchSection(sectionId) {
        // 切换菜单选中状态
        this.menuItems.forEach(item => {
            item.classList.remove('active');
            if (item.dataset.section === sectionId) {
                item.classList.add('active');
            }
        });

        // 切换内容区域
        this.sections.forEach(section => {
            section.classList.remove('active');
            if (section.id === sectionId + '-section') {
                section.classList.add('active');
            }
        });

        // 加载工具列表
        if (sectionId === 'tools') {
            this.loadTools();
        }
        
        // 加载设置
        if (sectionId === 'settings') {
            this.loadSettings();
        }
    }

    switchTab(tabGroup, tabId) {
        // 切换标签按钮
        const tabs = document.querySelectorAll(`.${tabGroup}-tabs .tab-btn`);
        tabs.forEach(tab => {
            tab.classList.remove('active');
            if (tab.dataset.tab === tabId) {
                tab.classList.add('active');
            }
        });

        // 切换内容
        const panes = document.querySelectorAll(`#${tabGroup}-section .tab-pane`);
        panes.forEach(pane => {
            pane.classList.remove('active');
            if (pane.id === tabId + '-tab') {
                pane.classList.add('active');
            }
        });
    }

    async loadStatus() {
        try {
            const response = await fetch('/api/status');
            const data = await response.json();

            if (data.llm_available) {
                this.llmStatus.innerHTML = '<i class="fas fa-robot"></i> <span>LLM: 已启用</span>';
            } else {
                this.llmStatus.innerHTML = '<i class="fas fa-robot"></i> <span>LLM: 未配置</span>';
            }

            if (data.stats) {
                const stats = data.stats;
                this.statsStatus.innerHTML = `<i class="fas fa-chart-bar"></i> <span>统计: ${stats.total_feeds || 0} 条</span>`;
            }

            this.systemStatus.textContent = '系统运行中';

        } catch (error) {
            console.error('加载状态失败:', error);
            this.llmStatus.innerHTML = '<i class="fas fa-robot"></i> <span>LLM: 加载失败</span>';
            this.statsStatus.innerHTML = '<i class="fas fa-chart-bar"></i> <span>统计: 加载失败</span>';
            this.systemStatus.textContent = '系统错误';
        }
    }

    async loadSupportedFormats() {
        try {
            const response = await fetch('/api/conversions');
            const data = await response.json();

            if (data.data) {
                this.formatsList.innerHTML = '';
                data.data.forEach(format => {
                    const item = document.createElement('div');
                    item.className = 'format-item';
                    item.textContent = `${format.from} → ${format.to}`;
                    this.formatsList.appendChild(item);
                });
            }

        } catch (error) {
            console.error('加载支持的格式失败:', error);
        }
    }

    async uploadChatFile(files) {
        if (files.length === 0) return;

        const file = files[0];
        
        // 显示上传中消息
        this.addChatMessage('user', `正在上传文件: ${file.name}...`);

        // 使用 FormData 上传文件
        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('/api/feed', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.status === 'ok') {
                const fileInfo = data.data.files[0];
                if (fileInfo.success) {
                    // 生成文件链接
                    const fileUrl = `/files/${file.name}`;
                    
                    // 显示上传成功消息
                    this.addChatMessage('user', `文件上传成功: ${file.name}`);
                    
                    // 发送消息给 LLM，包含文件信息
                    this.sendChatMessage(`我上传了文件: ${file.name}，请分析其中的内容。`);
                } else {
                    this.addChatMessage('user', `文件上传失败: ${fileInfo.message}`);
                }
            } else {
                this.addChatMessage('user', `文件上传失败: ${data.data?.error || '未知错误'}`);
            }

        } catch (error) {
            console.error('文件上传失败:', error);
            this.addChatMessage('user', `文件上传失败: 网络错误`);
        }

        // 重置文件输入
        this.chatFileInput.value = '';
    }

    async sendChatMessage() {
        const message = this.chatInput.value.trim();
        if (!message) return;

        // 添加用户消息
        this.addChatMessage('user', message);
        this.chatInput.value = '';

        // 显示正在输入
        const typingMessage = this.addChatMessage('assistant', '<span class="typing">正在思考...</span>');

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message })
            });

            const data = await response.json();

            // 移除正在输入消息
            typingMessage.remove();

            if (data.status === 'ok') {
                this.addChatMessage('assistant', data.data.content);
            } else {
                this.addChatMessage('assistant', `❌ 错误: ${data.data?.error || '未知错误'}`);
            }

        } catch (error) {
            console.error('发送消息失败:', error);
            typingMessage.remove();
            this.addChatMessage('assistant', '❌ 网络错误，请稍后重试');
        }
    }

    addChatMessage(type, content) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `${type}-message`;
        messageDiv.innerHTML = `<p>${content}</p>`;
        this.chatMessages.appendChild(messageDiv);
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
        return messageDiv;
    }

    async feedText() {
        const content = this.textContent.value.trim();
        if (!content) {
            this.showNotification('请输入文本内容', 'warning');
            return;
        }

        try {
            const response = await fetch('/api/feed', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ type: 'text', content })
            });

            const data = await response.json();

            if (data.status === 'ok') {
                this.textContent.value = '';
                this.showNotification('文本投喂成功', 'success');
                this.loadStatus();
            } else {
                this.showNotification(`错误: ${data.data?.error || '未知错误'}`, 'error');
            }

        } catch (error) {
            console.error('投喂文本失败:', error);
            this.showNotification('网络错误，请稍后重试', 'error');
        }
    }

    async feedUrl() {
        const url = this.urlInput.value.trim();
        if (!url) {
            this.showNotification('请输入 URL', 'warning');
            return;
        }

        try {
            const response = await fetch('/api/feed', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ type: 'url', url })
            });

            const data = await response.json();

            if (data.status === 'ok') {
                this.urlInput.value = '';
                this.showNotification('网页投喂成功', 'success');
                this.loadStatus();
            } else {
                this.showNotification(`错误: ${data.data?.error || '未知错误'}`, 'error');
            }

        } catch (error) {
            console.error('投喂 URL 失败:', error);
            this.showNotification('网络错误，请稍后重试', 'error');
        }
    }

    async feedFile() {
        const files = this.fileInput.files;
        if (files.length === 0) {
            this.showNotification('请选择文件', 'warning');
            return;
        }

        // 显示文件列表
        this.fileList.innerHTML = '';
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            fileItem.textContent = `${file.name} (${(file.size / 1024).toFixed(2)} KB)`;
            this.fileList.appendChild(fileItem);
        }

        // 使用 FormData 上传文件
        const formData = new FormData();
        for (let i = 0; i < files.length; i++) {
            formData.append('file', files[i]);
        }

        try {
            const response = await fetch('/api/feed', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.status === 'ok') {
                this.fileInput.value = '';
                this.fileList.innerHTML = '';
                this.showNotification(`成功处理 ${data.data.files.length} 个文件`, 'success');
                this.loadStatus();
            } else {
                this.showNotification(`错误: ${data.data?.error || '未知错误'}`, 'error');
            }

        } catch (error) {
            console.error('文件上传失败:', error);
            this.showNotification('网络错误，请稍后重试', 'error');
        }
    }

    async convertFormat() {
        const input = this.inputPath.value.trim();
        const output = this.outputPath.value.trim();

        if (!input || !output) {
            this.showNotification('请输入输入和输出文件路径', 'warning');
            return;
        }

        try {
            const response = await fetch('/api/convert', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ input, output })
            });

            const data = await response.json();

            if (data.status === 'ok') {
                this.showNotification('格式转换成功', 'success');
            } else {
                this.showNotification(`错误: ${data.data?.error || '未知错误'}`, 'error');
            }

        } catch (error) {
            console.error('转换格式失败:', error);
            this.showNotification('网络错误，请稍后重试', 'error');
        }
    }

    async addMemory() {
        const content = this.memoryContent.value.trim();
        if (!content) {
            this.showNotification('请输入记忆内容', 'warning');
            return;
        }

        try {
            const response = await fetch('/api/memory', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ action: 'add', content })
            });

            const data = await response.json();

            if (data.status === 'ok' && data.data.success) {
                this.memoryContent.value = '';
                this.showNotification('记忆添加成功', 'success');
            } else {
                this.showNotification('记忆添加失败', 'error');
            }

        } catch (error) {
            console.error('添加记忆失败:', error);
            this.showNotification('网络错误，请稍后重试', 'error');
        }
    }

    async searchMemory() {
        const query = this.searchQuery.value.trim();
        if (!query) {
            this.showNotification('请输入检索关键词', 'warning');
            return;
        }

        try {
            const response = await fetch('/api/memory', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ action: 'search', query })
            });

            const data = await response.json();

            if (data.status === 'ok') {
                this.displaySearchResults(data.data);
            } else {
                this.showNotification('检索失败', 'error');
            }

        } catch (error) {
            console.error('检索记忆失败:', error);
            this.showNotification('网络错误，请稍后重试', 'error');
        }
    }

    displaySearchResults(results) {
        this.searchResults.innerHTML = '';

        if (!results || results.length === 0) {
            this.searchResults.innerHTML = '<div class="search-result-item">没有找到匹配的记忆</div>';
            return;
        }

        results.forEach(result => {
            const item = document.createElement('div');
            item.className = 'search-result-item';
            item.innerHTML = `
                <div class="search-result-content">${result.content}</div>
                <div class="search-result-meta">
                    相似度: ${(result.similarity * 100).toFixed(2)}%
                    ${result.metadata?.created_at ? ` | 创建时间: ${result.metadata.created_at}` : ''}
                </div>
            `;
            this.searchResults.appendChild(item);
        });
    }

    async exportContent() {
        try {
            const response = await fetch('/api/export');
            const data = await response.json();

            if (data.status === 'ok') {
                this.showNotification(`导出成功，文件路径: ${data.data.export_path}`, 'success');
            } else {
                this.showNotification('导出失败', 'error');
            }

        } catch (error) {
            console.error('导出内容失败:', error);
            this.showNotification('网络错误，请稍后重试', 'error');
        }
    }

    async clearHistory() {
        if (confirm('确定要清空所有历史记录吗？')) {
            try {
                // 这里应该调用清空 API，暂时模拟
                this.showNotification('历史记录已清空', 'success');
                this.loadStatus();
            } catch (error) {
                console.error('清空历史失败:', error);
                this.showNotification('清空失败', 'error');
            }
        }
    }

    showNotification(message, type = 'info') {
        this.notificationMessage.textContent = message;
        this.notification.className = `notification show ${type}`;

        setTimeout(() => {
            this.notification.classList.remove('show');
        }, 3000);
    }

    async loadTools() {
        try {
            const response = await fetch('/api/tools');
            const data = await response.json();

            if (data.status === 'ok') {
                this.renderToolCategories(data.data);
            } else {
                this.showNotification('加载工具失败', 'error');
            }

        } catch (error) {
            console.error('加载工具失败:', error);
            this.showNotification('网络错误，无法加载工具', 'error');
        }
    }

    renderToolCategories(categories) {
        this.toolsCategories.innerHTML = '';

        categories.forEach(category => {
            const categoryDiv = document.createElement('div');
            categoryDiv.className = 'category-item';
            categoryDiv.innerHTML = `
                <h3 class="category-title">${category.category}</h3>
                <div class="tool-list">
                    ${category.tools.map(tool => `
                        <div class="tool-item" data-tool-id="${tool.id}" data-tool-name="${tool.name}" data-tool-description="${tool.description}" title="${tool.hint || tool.description}">
                            <h4>${tool.name}</h4>
                            <p>${tool.description}</p>
                        </div>
                    `).join('')}
                </div>
            `;
            this.toolsCategories.appendChild(categoryDiv);
        });

        // 添加工具点击事件
        document.querySelectorAll('.tool-item').forEach(item => {
            item.addEventListener('click', () => this.selectTool(item));
        });
    }

    selectTool(toolItem) {
        // 移除其他工具的选中状态
        document.querySelectorAll('.tool-item').forEach(item => {
            item.classList.remove('active');
        });

        // 添加当前工具的选中状态
        toolItem.classList.add('active');

        // 获取工具信息
        const toolId = toolItem.dataset.toolId;
        const toolName = toolItem.dataset.toolName;
        const toolDescription = toolItem.dataset.toolDescription;

        // 更新当前工具
        this.currentTool = {
            id: toolId,
            name: toolName,
            description: toolDescription
        };

        // 更新工具详情
        this.toolDetails.innerHTML = `
            <h3>${toolName}</h3>
            <p>${toolDescription}</p>
        `;

        // 渲染工具参数表单
        this.renderToolParams(toolId);

        // 启用执行按钮
        this.executeToolBtn.disabled = false;
    }

    renderToolParams(toolId) {
        // 清空参数表单
        this.toolParams.innerHTML = '';

        // 根据工具类型渲染参数表单
        switch (toolId) {
            case 'remember':
                this.toolParams.innerHTML = `
                    <div class="param-group">
                        <label for="remember-content">记忆内容</label>
                        <textarea id="remember-content" class="param-input" placeholder="输入要写入的记忆内容..."></textarea>
                    </div>
                    <div class="param-group">
                        <label for="remember-importance">重要度</label>
                        <select id="remember-importance" class="param-input">
                            <option value="high">高</option>
                            <option value="medium" selected>中</option>
                            <option value="low">低</option>
                        </select>
                    </div>
                    <div class="param-group">
                        <label for="remember-topics">主题（逗号分隔）</label>
                        <input type="text" id="remember-topics" class="param-input" placeholder="例如：工作,学习,生活">
                    </div>
                `;
                break;

            case 'recall':
                this.toolParams.innerHTML = `
                    <div class="param-group">
                        <label for="recall-query">查询内容</label>
                        <input type="text" id="recall-query" class="param-input" placeholder="输入查询关键词...">
                    </div>
                    <div class="param-group">
                        <label for="recall-limit">返回条数</label>
                        <input type="number" id="recall-limit" class="param-input" value="10" min="1" max="50">
                    </div>
                `;
                break;

            case 'context':
                this.toolParams.innerHTML = `
                    <div class="param-group">
                        <label for="context-query">当前对话内容</label>
                        <textarea id="context-query" class="param-input" placeholder="输入当前对话内容..."></textarea>
                    </div>
                    <div class="param-group">
                        <label for="context-max-tokens">最大 tokens</label>
                        <input type="number" id="context-max-tokens" class="param-input" value="1500" min="100" max="4000">
                    </div>
                `;
                break;

            case 'distill':
                this.toolParams.innerHTML = `
                    <div class="param-group">
                        <label for="distill-force">强制全量蒸馏</label>
                        <input type="checkbox" id="distill-force" class="param-input">
                    </div>
                `;
                break;

            case 'encyclopedia':
                this.toolParams.innerHTML = `
                    <div class="param-group">
                        <label for="encyclopedia-category">类别</label>
                        <select id="encyclopedia-category" class="param-input">
                            <option value="">全部</option>
                            <option value="decisions">决策</option>
                            <option value="tools">工具</option>
                            <option value="projects">项目</option>
                            <option value="concepts">概念</option>
                            <option value="people">人物</option>
                            <option value="facts">事实</option>
                        </select>
                    </div>
                    <div class="param-group">
                        <label for="encyclopedia-search">搜索内容</label>
                        <input type="text" id="encyclopedia-search" class="param-input" placeholder="输入搜索关键词...">
                    </div>
                    <div class="param-group">
                        <label for="encyclopedia-export">导出路径</label>
                        <input type="text" id="encyclopedia-export" class="param-input" placeholder="输入导出文件路径...">
                    </div>
                `;
                break;

            case 'convert':
                this.toolParams.innerHTML = `
                    <div class="param-group">
                        <label for="convert-input">输入文件路径</label>
                        <input type="text" id="convert-input" class="param-input" placeholder="例如：C:\\path\\to\\file.pdf">
                    </div>
                    <div class="param-group">
                        <label for="convert-output">输出文件路径</label>
                        <input type="text" id="convert-output" class="param-input" placeholder="例如：C:\\path\\to\\file.docx">
                    </div>
                `;
                break;

            case 'snapshot':
                this.toolParams.innerHTML = `
                    <div class="param-group">
                        <label for="snapshot-name">快照名称</label>
                        <input type="text" id="snapshot-name" class="param-input" placeholder="输入快照名称...">
                    </div>
                `;
                break;

            case 'diff':
                this.toolParams.innerHTML = `
                    <div class="param-group">
                        <label for="diff-snapshot1">快照1 ID</label>
                        <input type="text" id="diff-snapshot1" class="param-input" placeholder="输入第一个快照的ID...">
                    </div>
                    <div class="param-group">
                        <label for="diff-snapshot2">快照2 ID</label>
                        <input type="text" id="diff-snapshot2" class="param-input" placeholder="输入第二个快照的ID...">
                    </div>
                `;
                break;

            case 'blame':
                this.toolParams.innerHTML = `
                    <div class="param-group">
                        <label for="blame-memory-id">记忆 ID</label>
                        <input type="text" id="blame-memory-id" class="param-input" placeholder="输入记忆的ID...">
                    </div>
                `;
                break;

            default:
                this.toolParams.innerHTML = `
                    <div class="param-group">
                        <p>此工具不需要参数</p>
                    </div>
                `;
        }
    }

    async executeTool() {
        if (!this.currentTool) {
            this.showNotification('请先选择一个工具', 'warning');
            return;
        }

        // 收集参数
        const params = this.collectToolParams(this.currentTool.id);

        // 显示加载状态
        this.toolResults.innerHTML = `
            <h4>执行结果</h4>
            <div class="result-content">执行中...</div>
        `;

        try {
            const response = await fetch('/api/tool', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    tool_id: this.currentTool.id,
                    params: params
                })
            });

            const data = await response.json();

            if (data.status === 'ok') {
                this.renderToolResults(data.data);
            } else {
                this.showNotification('执行工具失败', 'error');
                this.toolResults.innerHTML = `
                    <h4>执行结果</h4>
                    <div class="result-content result-error">错误: ${data.data?.error || '未知错误'}</div>
                `;
            }

        } catch (error) {
            console.error('执行工具失败:', error);
            this.showNotification('网络错误，无法执行工具', 'error');
            this.toolResults.innerHTML = `
                <h4>执行结果</h4>
                <div class="result-content result-error">网络错误: ${error.message}</div>
            `;
        }
    }

    collectToolParams(toolId) {
        const params = {};

        switch (toolId) {
            case 'remember':
                params.content = document.getElementById('remember-content')?.value || '';
                params.importance = document.getElementById('remember-importance')?.value || 'medium';
                params.topics = document.getElementById('remember-topics')?.value || '';
                break;

            case 'recall':
                params.query = document.getElementById('recall-query')?.value || '';
                params.limit = parseInt(document.getElementById('recall-limit')?.value || '10');
                break;

            case 'context':
                params.query = document.getElementById('context-query')?.value || '';
                params.max_tokens = parseInt(document.getElementById('context-max-tokens')?.value || '1500');
                break;

            case 'distill':
                params.force = document.getElementById('distill-force')?.checked || false;
                break;

            case 'encyclopedia':
                params.category = document.getElementById('encyclopedia-category')?.value || '';
                params.search = document.getElementById('encyclopedia-search')?.value || '';
                params.export = document.getElementById('encyclopedia-export')?.value || '';
                break;

            case 'convert':
                params.input = document.getElementById('convert-input')?.value || '';
                params.output = document.getElementById('convert-output')?.value || '';
                break;

            case 'snapshot':
                params.name = document.getElementById('snapshot-name')?.value || '';
                break;

            case 'diff':
                params.snapshot1 = document.getElementById('diff-snapshot1')?.value || '';
                params.snapshot2 = document.getElementById('diff-snapshot2')?.value || '';
                break;

            case 'blame':
                params.memory_id = document.getElementById('blame-memory-id')?.value || '';
                break;
        }

        return params;
    }

    renderToolResults(result) {
        if (result.success) {
            let content = '';
            
            // 检查是否是图谱数据
            if (typeof result.data === 'string' && result.data.includes('graph LR')) {
                content = `
                    <div class="result-content result-success">
                        <h5>Mermaid 图谱代码</h5>
                        <pre class="mermaid-code">${result.data}</pre>
                        <button id="render-mermaid" class="btn btn-primary" style="margin-top: 10px;">查看可视化图谱</button>
                        <div id="mermaid-diagram" style="margin-top: 20px;"></div>
                    </div>
                `;
            }
            // 检查是否是统计数据
            else if (result.data && result.data.total_memories !== undefined) {
                content = this.formatStats(result.data);
            }
            // 检查是否是列表类型（角色、快照等）
            else if (Array.isArray(result.data)) {
                content = this.formatList(result.data);
            }
            // 检查是否是转换结果
            else if (result.data && result.data.success !== undefined) {
                content = this.formatConversion(result.data);
            }
            // 检查是否是百科条目
            else if (result.data && (result.data.entries || result.data.categories)) {
                content = this.formatEncyclopedia(result.data);
            }
            // 检查是否是自我状态
            else if (result.data && result.data.mood !== undefined) {
                content = this.formatSelfState(result.data);
            }
            // 检查是否是简单对象
            else if (typeof result.data === 'object' && result.data !== null) {
                content = this.formatObject(result.data);
            }
            // 其他情况
            else {
                content = `
                    <div class="result-content result-success">
                        ${typeof result.data === 'string' ? result.data : JSON.stringify(result.data, null, 2)}
                    </div>
                `;
            }
            
            this.toolResults.innerHTML = `
                <h4>执行结果</h4>
                ${content}
            `;
            
            // 添加图谱渲染事件
            const renderButton = document.getElementById('render-mermaid');
            if (renderButton) {
                renderButton.addEventListener('click', () => this.renderMermaid());
            }
        } else {
            this.toolResults.innerHTML = `
                <h4>执行结果</h4>
                <div class="result-content result-error">
                    错误: ${result.error || '未知错误'}
                </div>
            `;
        }
    }
    
    formatList(data) {
        if (data.length === 0) {
            return `<div class="result-content result-success"><p>列表为空</p></div>`;
        }
        
        // 检查是否是角色列表
        if (data[0] && data[0].name && data[0].description) {
            return `
                <div class="result-content result-success">
                    <h5>角色列表</h5>
                    <div class="list-container">
                        ${data.map(item => `
                            <div class="list-item">
                                <h6>${item.name}</h6>
                                <p>${item.description}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        // 检查是否是快照列表
        if (data[0] && data[0].id && data[0].name) {
            return `
                <div class="result-content result-success">
                    <h5>快照列表</h5>
                    <div class="list-container">
                        ${data.map(item => `
                            <div class="list-item">
                                <h6>${item.name}</h6>
                                <p>ID: ${item.id}</p>
                                <p>时间: ${new Date(item.timestamp).toLocaleString()}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        // 通用列表
        return `
            <div class="result-content result-success">
                <h5>列表结果</h5>
                <ul class="result-list">
                    ${data.map(item => `<li>${typeof item === 'object' ? JSON.stringify(item) : item}</li>`).join('')}
                </ul>
            </div>
        `;
    }
    
    formatConversion(data) {
        return `
            <div class="result-content result-success">
                <h5>格式转换结果</h5>
                <div class="conversion-result">
                    <div class="conversion-info">
                        <div class="info-item">
                            <span class="label">输入格式:</span>
                            <span class="value">${data.input_format || '未知'}</span>
                        </div>
                        <div class="info-item">
                            <span class="label">输出格式:</span>
                            <span class="value">${data.output_format || '未知'}</span>
                        </div>
                        <div class="info-item">
                            <span class="label">输入文件:</span>
                            <span class="value">${data.input_file || '未知'}</span>
                        </div>
                        <div class="info-item">
                            <span class="label">输出文件:</span>
                            <span class="value">${data.output_file || '未知'}</span>
                        </div>
                        <div class="info-item">
                            <span class="label">转换状态:</span>
                            <span class="value ${data.success ? 'success' : 'error'}">${data.success ? '成功' : '失败'}</span>
                        </div>
                        ${data.message ? `
                        <div class="info-item">
                            <span class="label">消息:</span>
                            <span class="value">${data.message}</span>
                        </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }
    
    formatEncyclopedia(data) {
        if (data.entries) {
            return `
                <div class="result-content result-success">
                    <h5>百科条目</h5>
                    <div class="encyclopedia-container">
                        ${data.entries.map(entry => `
                            <div class="encyclopedia-item">
                                <h6>${entry.title}</h6>
                                <p class="category">类别: ${entry.category}</p>
                                <p class="content">${entry.content}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        return `<div class="result-content result-success">${JSON.stringify(data, null, 2)}</div>`;
    }
    
    formatSelfState(data) {
        return `
            <div class="result-content result-success">
                <h5>自我状态</h5>
                <div class="self-state-container">
                    <div class="state-card">
                        <div class="state-value">${data.emoji || '😊'}</div>
                        <div class="state-label">情绪</div>
                        <div class="state-desc">${data.mood || '未知'}</div>
                    </div>
                    ${data.profile ? `
                    <div class="state-section">
                        <h6>身份画像</h6>
                        <p>${data.profile}</p>
                    </div>
                    ` : ''}
                    ${data.gaps ? `
                    <div class="state-section">
                        <h6>知识空白</h6>
                        <ul>
                            ${data.gaps.map(gap => `<li>${gap}</li>`).join('')}
                        </ul>
                    </div>
                    ` : ''}
                </div>
            </div>
        `;
    }
    
    formatObject(data) {
        return `
            <div class="result-content result-success">
                <h5>结果详情</h5>
                <div class="object-container">
                    ${Object.entries(data).map(([key, value]) => `
                        <div class="object-item">
                            <span class="object-key">${key}:</span>
                            <span class="object-value">${typeof value === 'object' ? JSON.stringify(value) : value}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderMermaid() {
        const codeElement = document.querySelector('.mermaid-code');
        const diagramElement = document.getElementById('mermaid-diagram');
        
        if (codeElement && diagramElement) {
            const mermaidCode = codeElement.textContent;
            diagramElement.innerHTML = `<div class="mermaid">${mermaidCode}</div>`;
            
            // 初始化 Mermaid
            if (window.mermaid) {
                mermaid.initialize({ startOnLoad: true });
                mermaid.init();
            }
        }
    }
    
    formatStats(stats) {
        return `
            <div class="stats-container">
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-value">${stats.total_memories || 0}</div>
                        <div class="stat-label">总记忆数</div>
                    </div>
                    ${stats.quality ? `
                        <div class="stat-card">
                            <div class="stat-value">${stats.quality.total_feedback || 0}</div>
                            <div class="stat-label">反馈总数</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">${stats.quality.useful_ratio || 0}%</div>
                            <div class="stat-label">有用比例</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">${stats.quality.total_retrieval_events || 0}</div>
                            <div class="stat-label">检索事件</div>
                        </div>
                    ` : ''}
                </div>
                ${stats.quality ? `
                    <div class="stats-section">
                        <h5>质量指标</h5>
                        <ul>
                            <li>总反馈: ${stats.quality.total_feedback || 0}</li>
                            <li>有用比例: ${stats.quality.useful_ratio || 0}%</li>
                            <li>检索事件: ${stats.quality.total_retrieval_events || 0}</li>
                            <li>唯一检索: ${stats.quality.unique_retrieved || 0}</li>
                            <li>唯一引用: ${stats.quality.unique_referenced || 0}</li>
                        </ul>
                    </div>
                ` : ''}
                ${stats.causal ? `
                    <div class="stats-section">
                        <h5>因果关系</h5>
                        <ul>
                            ${Object.entries(stats.causal).map(([key, value]) => `
                                <li>${key}: ${value}</li>
                            `).join('')}
                        </ul>
                    </div>
                ` : ''}
            </div>
        `;
    }
    
    async loadSettings() {
        try {
            const response = await fetch('/api/personalization/settings');
            const data = await response.json();
            
            if (data.status === 'ok' && data.data) {
                const settings = data.data;
                
                if (settings.llm) {
                    // security: never populate the API key input with the actual key
                    // only show a placeholder if a key exists
                    if (settings.llm.api_key_configured) {
                        this.apiKeyInput.value = '';
                        this.apiKeyInput.placeholder = '•••••••• (key already set, leave empty to keep)';
                    }
                    this.llmModelSelect.value = settings.llm.model || 'gpt-4o';
                    this.apiBaseUrlInput.value = settings.llm.api_base_url || 'https://api.openai.com/v1';
                }
            }
        } catch (error) {
            console.error('加载设置失败:', error);
            this.showNotification('加载设置失败', 'error');
        }
    }
    
    async saveSettings() {
        try {
            const settings = {
                llm: {
                    model: this.llmModelSelect.value,
                    api_base_url: this.apiBaseUrlInput.value
                }
            };
            // security: only send the API key if the user entered a new one
            const newKey = this.apiKeyInput.value.trim();
            if (newKey) {
                settings.llm.api_key = newKey;
            }
            
            const response = await fetch('/api/personalization/settings', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ settings })
            });
            
            const data = await response.json();
            
            if (data.status === 'ok') {
                this.showNotification('设置保存成功', 'success');
                // 重新加载状态
                this.loadStatus();
            } else {
                this.showNotification('保存设置失败', 'error');
            }
        } catch (error) {
            console.error('保存设置失败:', error);
            this.showNotification('网络错误，无法保存设置', 'error');
        }
    }
}

// 初始化应用
window.addEventListener('DOMContentLoaded', () => {
    new App();
});