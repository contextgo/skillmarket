"""
store.py - SQLite 存储层
所有结构化维度的 CRUD 操作
进程级锁 + 线程安全 + FTS5 全文搜索 + 查询缓存
"""

import sqlite3
import threading
import hashlib
import time
import json
import logging
import os
import re
import sys
from pathlib import Path
from datetime import datetime
from contextlib import contextmanager

logger = logging.getLogger(__name__)

if sys.platform != "win32":
    import fcntl
    _HAS_FCNTL = True
else:
    _HAS_FCNTL = False

DB_PATH = Path(__file__).parent / "memory.db"
SCHEMA_PATH = Path(__file__).parent / "schema.sql"


class _FileLock:
    """跨进程文件锁 — 仅用于注册表等非 SQLite 资源。

    SQLite 写入不再使用文件锁（依赖 WAL 模式 + busy_timeout），
    避免全局串行化导致的多 Agent 卡死问题。

    Windows: 使用 threading.Lock 替代（跨进程锁在 Windows 上不常用）
    """

    def __init__(self, lock_path: str, timeout: float = 3.0):
        self._lock_path = lock_path
        self._timeout = timeout
        self._fd = None
        self._thread_lock = threading.Lock()

    def acquire(self):
        if not _HAS_FCNTL:
            self._thread_lock.acquire()
            return
        self._fd = open(self._lock_path, "w")
        deadline = time.time() + self._timeout
        retry_delay = 0.05
        while True:
            try:
                fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return
            except (IOError, OSError):
                if time.time() >= deadline:
                    self._fd.close()
                    self._cleanup_stale_lock()
                    self._fd = open(self._lock_path, "w")
                    try:
                        fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        return
                    except (IOError, OSError):
                        self._fd.close()
                        raise TimeoutError(f"获取文件锁超时: {self._lock_path}")
                time.sleep(retry_delay)
                retry_delay = min(retry_delay * 1.5, 1.0)

    def _cleanup_stale_lock(self):
        try:
            if os.path.exists(self._lock_path):
                mtime = os.path.getmtime(self._lock_path)
                if time.time() - mtime > self._timeout * 2:
                    os.unlink(self._lock_path)
                    logger.debug(f"清理 stale lock: {self._lock_path}")
        except Exception:
            pass

    def release(self):
        if not _HAS_FCNTL:
            try:
                self._thread_lock.release()
            except Exception:
                pass
            return
        if self._fd:
            try:
                fcntl.flock(self._fd, fcntl.LOCK_UN)
                self._fd.close()
            except Exception:
                pass
            self._fd = None

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *args):
        self.release()


class MemoryStore:
    def __init__(self, db_path: str = None):
        self.db_path = str(db_path or DB_PATH)
        self._lock_path = self.db_path + ".lock"
        self._local = threading.local()
        self._thread_lock = threading.Lock()
        self._query_cache: dict = {}
        self._cache_max_size = 200
        self._stats = {"reads": 0, "writes": 0, "cache_hits": 0, "cache_misses": 0}
        # Fix #5: 跨进程缓存版本标记
        self._cache_version_path = self.db_path + ".cache_ver"
        self._local_cache_version = 0

        # Fix (Issue 3): 向量存储引用，由 MemorySystem 注入
        # 用于 write-through 清理（归档/删除时同步清理向量）
        self._embedding_store_ref = None

        # Fix (Issue 3): 最大记忆数限制
        self._max_memories = int(os.environ.get("AGENT_MEMORY_MAX_MEMORIES", "0"))  # 0=不限制

        # Fix (#17): 连接追踪 — 记录所有线程的连接，支持 close_all()
        self._all_conns: dict[int, sqlite3.Connection] = {}
        self._all_conns_lock = threading.Lock()

        # 先初始化连接，再建表，再初始化 FTS
        _ = self.conn  # 触发连接创建
        self._ensure_schema()
        self._init_fts()

    @property
    def conn(self):
        """线程安全的连接获取"""
        if not hasattr(self._local, 'conn') or self._local.conn is None:
            self._local.conn = sqlite3.connect(self.db_path)
            self._local.conn.row_factory = sqlite3.Row
            self._local.conn.execute("PRAGMA journal_mode=WAL")
            self._local.conn.execute("PRAGMA foreign_keys=ON")
            self._local.conn.execute("PRAGMA synchronous=NORMAL")
            self._local.conn.execute("PRAGMA cache_size=-64000")  # 64MB cache
            self._local.conn.execute("PRAGMA busy_timeout=30000")
            # Fix (#17): 注册到全局连接追踪
            with self._all_conns_lock:
                self._all_conns[threading.get_ident()] = self._local.conn
        return self._local.conn

    @contextmanager
    def transaction(self, process_safe: bool = True):
        """原子事务上下文管理器。

        Fix (P0): 移除 _FileLock — SQLite WAL 模式本身支持一个写者 + 多个读者并发，
        加 fcntl 文件锁会导致所有写操作完全串行化，多 Agent 场景下系统卡死。

        并发控制交给：
        - PRAGMA journal_mode=WAL（单写者 + 多读者）
        - PRAGMA busy_timeout=5000（写冲突时自动等待重试）
        - SQLite 内部的锁机制

        process_safe 参数保留向后兼容，但不再使用文件锁。
        文件锁 (_FileLock) 仅保留给注册表等非 SQLite 资源使用。
        """
        conn = self.conn
        try:
            conn.execute("BEGIN")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise

    def _ensure_schema(self):
        """
        Fix (P0 #3): 使用事务保护 schema 初始化，防止多进程竞态重复执行。

        策略：
        1. 用 BEGIN/COMMIT 包裹 executescript，利用 SQLite 的写锁串行化
        2. CREATE TABLE/INDEX IF NOT EXISTS 保证幂等
        3. 捕获 OperationalError(concurrent schema change)，静默重试一次
        """
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            schema = f.read()
        extra_schema = """
            -- _sync_flags 已移除 (v6.0: 向量与结构化数据在同一 SQLite 中，无需同步追踪)
        """
        for attempt in range(2):
            try:
                with self.transaction():
                    self.conn.executescript(schema)
                    self.conn.executescript(extra_schema)
                break
            except sqlite3.OperationalError as e:
                if "locked" in str(e).lower() and attempt == 0:
                    logger.debug("Schema init locked, retrying...")
                    time.sleep(0.1)
                    continue
                # IF NOT EXISTS 保证幂等，第二次失败可忽略
                logger.debug(f"Schema init attempt {attempt}: {e}")
                break

    def _init_fts(self):
        """初始化 FTS5 全文搜索（trigram tokenizer，中文友好）"""
        try:
            self.conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
                    memory_id UNINDEXED,
                    content,
                    tokenize='trigram'
                )
            """)
            # 检查是否需要初始同步
            count = self.conn.execute("SELECT COUNT(*) FROM memories_fts").fetchone()[0]
            mem_count = self.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
            if count < mem_count:
                logger.info(f"FTS 同步: {mem_count - count} 条记忆")
                self.conn.execute("DELETE FROM memories_fts")
                self.conn.execute("""
                    INSERT INTO memories_fts(memory_id, content)
                    SELECT memory_id, content FROM memories
                """)
            self.conn.commit()
            self._has_fts = True
        except Exception as e:
            logger.warning(f"FTS5 不可用: {e}")
            self._has_fts = False

    def rebuild_fts(self) -> dict:
        """
        Fix (Issue 2): 重建 FTS 索引。

        当 FTS 表损坏或数据不一致时调用：
        1. 删除旧 FTS 表
        2. 重新创建
        3. 从 memories 表全量填充

        返回: {"rebuilt": bool, "count": int, "error": str}
        """
        try:
            # 删除旧 FTS 表
            self.conn.execute("DROP TABLE IF EXISTS memories_fts")
            self.conn.commit()

            # 重建
            self.conn.execute("""
                CREATE VIRTUAL TABLE memories_fts USING fts5(
                    memory_id UNINDEXED,
                    content,
                    tokenize='trigram'
                )
            """)

            # 全量填充
            self.conn.execute("""
                INSERT INTO memories_fts(memory_id, content)
                SELECT memory_id, content FROM memories
            """)
            self.conn.commit()

            count = self.conn.execute("SELECT COUNT(*) FROM memories_fts").fetchone()[0]
            self._has_fts = True
            logger.info(f"FTS 索引重建完成: {count} 条")
            return {"rebuilt": True, "count": count, "error": None}
        except Exception as e:
            self._has_fts = False
            logger.error(f"FTS 索引重建失败: {e}")
            return {"rebuilt": False, "count": 0, "error": str(e)}

    def _invalidate_cache(self):
        """
        写入时清除缓存 + 递增跨进程版本号（Fix #5）

        修复 (P0): 文件 I/O 失败不阻塞写入事务
        """
        with self._thread_lock:
            self._query_cache.clear()
        try:
            ver = 0
            if os.path.exists(self._cache_version_path):
                try:
                    with open(self._cache_version_path, "r") as f:
                        ver = int(f.read().strip())
                except (ValueError, IOError):
                    pass
            ver += 1
            tmp_path = self._cache_version_path + ".tmp"
            with open(tmp_path, "w") as f:
                f.write(str(ver))
            os.replace(tmp_path, self._cache_version_path)
            self._local_cache_version = ver
        except Exception:
            pass

    def _cache_get(self, key: str):
        try:
            if os.path.exists(self._cache_version_path):
                with open(self._cache_version_path, "r") as f:
                    remote_ver = int(f.read().strip())
                if remote_ver > self._local_cache_version:
                    with self._thread_lock:
                        self._query_cache.clear()
                    self._local_cache_version = remote_ver
        except Exception:
            pass
        with self._thread_lock:
            self._stats["reads"] += 1
            if key in self._query_cache:
                self._stats["cache_hits"] += 1
                return self._query_cache[key]
            self._stats["cache_misses"] += 1
            return None

    def _cache_set(self, key: str, value):
        with self._thread_lock:
            if len(self._query_cache) >= self._cache_max_size:
                keys = list(self._query_cache.keys())
                for k in keys[:self._cache_max_size // 4]:
                    del self._query_cache[k]
            self._query_cache[key] = value

    # ── 写入 ──────────────────────────────────────────────

    def insert_memory(
        self,
        memory_id: str,
        time_id: str,
        time_ts: int,
        person_id: str,
        nature_id: str,
        content: str,
        content_hash: str,
        topics: list[str] = None,
        tools: list[str] = None,
        knowledge_types: list[str] = None,
        importance: str = "medium",
        is_aggregated: bool = False,
        source_count: int = 1,
        owner_agent_id: str = "_system",
        visibility: str = "team",
        valence: float = 0.0,
        arousal: float = 0.2,
        significance: str = "notable",
        confidence: float = 0.5,
    ) -> str:
        """写入一条记忆记录，返回 memory_id（原子写入）

        独立使用时自行管理事务。pipeline 请使用 insert_memory_in_txn。
        """
        with self.transaction() as conn:
            self._do_insert(conn, memory_id, time_id, time_ts, person_id, nature_id,
                            content, content_hash, topics, tools, knowledge_types,
                            importance, is_aggregated, source_count, owner_agent_id, visibility,
                            valence, arousal, significance, confidence)
        self._invalidate_cache()

        if self._max_memories > 0:
            self._enforce_max_memories()

        return memory_id

    def insert_memory_in_txn(
        self,
        txn_conn: sqlite3.Connection,
        memory_id: str,
        time_id: str,
        time_ts: int,
        person_id: str,
        nature_id: str,
        content: str,
        content_hash: str,
        topics: list[str] = None,
        tools: list[str] = None,
        knowledge_types: list[str] = None,
        importance: str = "medium",
        is_aggregated: bool = False,
        source_count: int = 1,
        owner_agent_id: str = "_system",
        visibility: str = "team",
        valence: float = 0.0,
        arousal: float = 0.2,
        significance: str = "notable",
        confidence: float = 0.5,
    ) -> str:
        """Fix (Issue 1): 在外部事务中写入记忆记录。

        由 pipeline.ingest() 调用，与 embedding_store.add() 共享同一事务，
        确保结构化数据+向量的原子性。

        txn_conn: 由 store.transaction() 提供的连接，调用方管理 commit/rollback。
        """
        self._do_insert(txn_conn, memory_id, time_id, time_ts, person_id, nature_id,
                        content, content_hash, topics, tools, knowledge_types,
                        importance, is_aggregated, source_count, owner_agent_id, visibility,
                        valence, arousal, significance, confidence)
        self._invalidate_cache()

        if self._max_memories > 0:
            self._enforce_max_memories()

        return memory_id

    def _do_insert(
        self,
        conn: sqlite3.Connection,
        memory_id: str,
        time_id: str,
        time_ts: int,
        person_id: str,
        nature_id: str,
        content: str,
        content_hash: str,
        topics: list[str] = None,
        tools: list[str] = None,
        knowledge_types: list[str] = None,
        importance: str = "medium",
        is_aggregated: bool = False,
        source_count: int = 1,
        owner_agent_id: str = "_system",
        visibility: str = "team",
        valence: float = 0.0,
        arousal: float = 0.2,
        significance: str = "notable",
        confidence: float = 0.5,
    ):
        """实际的 INSERT 逻辑（在给定连接上执行）"""
        self._stats["writes"] += 1
        conn.execute(
            """INSERT OR IGNORE INTO memories
               (memory_id, time_id, time_ts, person_id, nature_id,
                content, content_hash, importance, is_aggregated, source_count,
                owner_agent_id, visibility, valence, arousal, significance, confidence)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (memory_id, time_id, time_ts, person_id, nature_id,
             content, content_hash, importance, int(is_aggregated), source_count,
             owner_agent_id, visibility, valence, arousal, significance, confidence),
        )

        if topics:
            for i, topic in enumerate(topics):
                conn.execute(
                    """INSERT OR IGNORE INTO memory_topics (memory_id, topic_code, is_primary)
                       VALUES (?, ?, ?)""",
                    (memory_id, topic, 1 if i == 0 else 0),
                )

        if tools:
            for tool_id in tools:
                conn.execute(
                    """INSERT OR IGNORE INTO memory_tools (memory_id, tool_id)
                       VALUES (?, ?)""",
                    (memory_id, tool_id),
                )

        if knowledge_types:
            for kid in knowledge_types:
                conn.execute(
                    """INSERT OR IGNORE INTO memory_knowledge (memory_id, knowledge_id)
                       VALUES (?, ?)""",
                    (memory_id, kid),
                )

        # 同步 FTS（在同一事务内，保证原子性）
        if self._has_fts:
            try:
                conn.execute(
                    "INSERT OR IGNORE INTO memories_fts(memory_id, content) VALUES (?, ?)",
                    (memory_id, content),
                )
            except Exception as e:
                logger.warning(f"FTS 同步失败，标记重建: {e}")
                self._has_fts = False
                try:
                    self.rebuild_fts()
                except Exception:
                    pass

    def _enforce_max_memories(self):
        """
        Fix (Issue 3): 超过最大记忆数时自动清理。

        策略：
        1. 仅清理 low 重要度的记忆
        2. 按 quality_score（如有）或 time_ts 降序保留最新的
        3. high 重要度永不自动清理
        """
        try:
            count = self.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
            if count <= self._max_memories:
                return

            excess = count - self._max_memories
            # 删除最旧的 low 记忆
            rows = self.conn.execute(
                """SELECT memory_id FROM memories
                   WHERE importance = 'low'
                   ORDER BY time_ts ASC
                   LIMIT ?""",
                (excess,),
            ).fetchall()

            to_delete = [r["memory_id"] for r in rows]

            # 如果 low 不够，删除最旧的 medium
            if len(to_delete) < excess:
                remaining = excess - len(to_delete)
                medium_rows = self.conn.execute(
                    """SELECT memory_id FROM memories
                       WHERE importance = 'medium'
                       ORDER BY time_ts ASC
                       LIMIT ?""",
                    (remaining,),
                ).fetchall()
                to_delete.extend(r["memory_id"] for r in medium_rows)

            if to_delete:
                self._batch_delete_memories(to_delete, reason="max_memories_eviction")
                logger.info(f"容量清理: 删除 {len(to_delete)} 条记忆（上限 {self._max_memories}）")
        except Exception as e:
            logger.warning(f"容量清理失败: {e}")

    def _batch_delete_memories(self, memory_ids: list[str], reason: str = "eviction"):
        """批量删除记忆（含关联清理 + 向量清理）"""
        if not memory_ids:
            return
        placeholders = ",".join("?" * len(memory_ids))
        with self.transaction() as conn:
            conn.execute(f"DELETE FROM memory_topics WHERE memory_id IN ({placeholders})", memory_ids)
            conn.execute(f"DELETE FROM memory_tools WHERE memory_id IN ({placeholders})", memory_ids)
            conn.execute(f"DELETE FROM memory_knowledge WHERE memory_id IN ({placeholders})", memory_ids)
            conn.execute(f"DELETE FROM memory_links WHERE source_id IN ({placeholders}) OR target_id IN ({placeholders})", memory_ids + memory_ids)
            if self._has_fts:
                try:
                    conn.execute(f"DELETE FROM memories_fts WHERE memory_id IN ({placeholders})", memory_ids)
                except Exception:
                    pass
            conn.execute(f"DELETE FROM memories WHERE memory_id IN ({placeholders})", memory_ids)

        # 清理向量
        if self._embedding_store_ref:
            for mid in memory_ids:
                try:
                    self._embedding_store_ref.delete(mid)
                except Exception:
                    pass

        self._invalidate_cache()

    def delete_memory(self, memory_id: str, reason: str = "user_delete") -> dict:
        """删除单条记忆（含关联清理 + 向量清理）。

        参数:
            memory_id: 记忆 ID
            reason: 删除原因（审计日志）

        返回: {"deleted": bool, "memory_id": str, "reason": str}
        """
        mem = self.get_memory(memory_id)
        if not mem:
            return {"deleted": False, "memory_id": memory_id, "reason": "not found"}
        self._batch_delete_memories([memory_id], reason=reason)
        logger.info(f"Memory deleted: {memory_id} (reason: {reason})")
        return {"deleted": True, "memory_id": memory_id, "reason": reason}

    def insert_link(
        self,
        source_id: str,
        target_id: str,
        link_type: str,
        weight: float = 1.0,
        reason: str = None,
    ):
        """插入一条关联关系"""
        if not source_id or not target_id:
            logger.warning(f"insert_link 跳过: source_id={source_id}, target_id={target_id}")
            return
        if source_id == target_id:
            return
        with self.transaction() as conn:
            conn.execute(
                """INSERT INTO memory_links (source_id, target_id, link_type, weight, reason)
                   VALUES (?, ?, ?, ?, ?)""",
                (source_id, target_id, link_type, weight, reason),
            )
        self._invalidate_cache()

    # ── 查询 ──────────────────────────────────────────────

    def get_memory(self, memory_id: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM memories WHERE memory_id = ?", (memory_id,)
        ).fetchone()
        if not row:
            return None
        mem = dict(row)
        mem["topics"] = self._get_topics(memory_id)
        mem["tools"] = self._get_tools(memory_id)
        mem["knowledge"] = self._get_knowledge(memory_id)
        mem["links"] = self._get_links(memory_id)
        return mem

    def get_memories(self, memory_ids: list[str]) -> dict[str, dict]:
        """批量获取记忆（解决 N+1 查询问题）"""
        if not memory_ids:
            return {}
        ids = [mid for mid in dict.fromkeys(memory_ids) if mid]
        if not ids:
            return {}

        placeholders = ",".join("?" * len(ids))
        rows = self.conn.execute(
            f"SELECT * FROM memories WHERE memory_id IN ({placeholders})", ids
        ).fetchall()

        topics_map = self._batch_get_topics(ids)
        tools_map = self._batch_get_tools(ids)
        knowledge_map = self._batch_get_knowledge(ids)

        result = {}
        for row in rows:
            mem = dict(row)
            mid = mem["memory_id"]
            mem["topics"] = topics_map.get(mid, [])
            mem["tools"] = tools_map.get(mid, [])
            mem["knowledge"] = knowledge_map.get(mid, [])
            result[mid] = mem
        return result

    # ── 记忆版本化（流式更新）────────────────────────

    def update_memory(
        self,
        memory_id: str,
        new_content: str,
        change_reason: str = None,
        importance: str = None,
        topics: list[str] = None,
    ) -> dict:
        """更新记忆内容（版本化 — 不删除旧版本）

        策略：
        1. 将当前版本存入 memory_versions 表
        2. 更新 memories 表为新内容
        3. 同步更新 FTS 索引
        4. 更新 content_hash

        返回: {"memory_id": str, "version": int, "old_content": str, "changed": bool}
        """
        import json as _json

        # 获取当前版本
        row = self.conn.execute(
            "SELECT content, content_hash, importance FROM memories WHERE memory_id = ?",
            (memory_id,),
        ).fetchone()

        if not row:
            return {"memory_id": memory_id, "version": 0, "changed": False, "error": "not found"}

        old_content = row["content"]
        old_importance = row["importance"]

        # 内容未变 → 跳过
        new_hash = hashlib.sha256(new_content.encode()).hexdigest()
        if new_hash == row["content_hash"]:
            return {"memory_id": memory_id, "version": 0, "changed": False, "reason": "content identical"}

        # 获取当前主题
        current_topics = [t["code"] for t in self._get_topics(memory_id)]

        # 获取当前版本号
        ver_row = self.conn.execute(
            "SELECT COALESCE(MAX(version_id), 0) as v FROM memory_versions WHERE memory_id = ?",
            (memory_id,),
        ).fetchone()
        next_version = (ver_row["v"] if ver_row else 0) + 1

        with self.transaction() as conn:
            # 1. 保存旧版本
            conn.execute(
                """INSERT INTO memory_versions
                   (memory_id, content, content_hash, importance, topics_json, change_reason)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    memory_id,
                    old_content,
                    row["content_hash"],
                    old_importance,
                    _json.dumps(current_topics, ensure_ascii=False),
                    change_reason or "update",
                ),
            )

            # 2. 更新主表
            update_fields = ["content = ?", "content_hash = ?", "created_at = strftime('%s','now')"]
            update_params = [new_content, new_hash]

            if importance is not None:
                update_fields.append("importance = ?")
                update_params.append(importance)

            update_params.append(memory_id)
            conn.execute(
                f"UPDATE memories SET {', '.join(update_fields)} WHERE memory_id = ?",
                update_params,
            )

            # 3. 更新主题（如果指定了新主题）
            if topics is not None:
                conn.execute("DELETE FROM memory_topics WHERE memory_id = ?", (memory_id,))
                for i, topic in enumerate(topics):
                    conn.execute(
                        "INSERT OR IGNORE INTO memory_topics (memory_id, topic_code, is_primary) VALUES (?, ?, ?)",
                        (memory_id, topic, 1 if i == 0 else 0),
                    )

            # 4. 同步 FTS
            if self._has_fts:
                try:
                    conn.execute("DELETE FROM memories_fts WHERE memory_id = ?", (memory_id,))
                    conn.execute(
                        "INSERT INTO memories_fts(memory_id, content) VALUES (?, ?)",
                        (memory_id, new_content),
                    )
                except Exception:
                    pass

        self._invalidate_cache()

        logger.info(f"记忆版本更新: {memory_id} → v{next_version} ({change_reason or 'update'})")
        return {
            "memory_id": memory_id,
            "version": next_version,
            "old_content": old_content[:200],
            "new_content": new_content[:200],
            "changed": True,
        }

    def get_memory_versions(self, memory_id: str) -> list[dict]:
        """获取记忆的完整版本历史（从旧到新）

        返回: [{"version_id": int, "content": str, "importance": str, "change_reason": str, "created_at": int}, ...]
        """
        import json as _json

        rows = self.conn.execute(
            """SELECT version_id, content, content_hash, importance, topics_json, change_reason, created_at
               FROM memory_versions
               WHERE memory_id = ?
               ORDER BY version_id ASC""",
            (memory_id,),
        ).fetchall()

        versions = []
        for r in rows:
            v = dict(r)
            try:
                v["topics"] = _json.loads(v.pop("topics_json", "[]"))
            except Exception:
                v["topics"] = []
            versions.append(v)

        # 附加当前版本作为最新
        current = self.conn.execute(
            "SELECT content, content_hash, importance, created_at FROM memories WHERE memory_id = ?",
            (memory_id,),
        ).fetchone()
        if current:
            versions.append({
                "version_id": len(versions) + 1,
                "content": current["content"],
                "content_hash": current["content_hash"],
                "importance": current["importance"],
                "topics": [t["code"] for t in self._get_topics(memory_id)],
                "change_reason": "current",
                "created_at": current["created_at"],
                "is_current": True,
            })

        return versions

    def query(
        self,
        time_from: int = None,
        time_to: int = None,
        person_id: str = None,
        nature_id: str = None,
        topic_code: str = None,
        tool_id: str = None,
        knowledge_id: str = None,
        importance: str = None,
        keyword: str = None,
        significance: str = None,
        limit: int = 50,
        offset: int = 0,
        query_agent_id: str = None,
        team_id: str = "default",
        include_public: bool = True,
    ) -> list[dict]:
        """多维度结构化查询（带缓存 + FTS 加速 + 权限过滤）"""
        use_permission_filter = query_agent_id is not None

        # 生成缓存键
        cache_key = f"q:{time_from}:{time_to}:{person_id}:{nature_id}:{topic_code}:{tool_id}:{knowledge_id}:{importance}:{keyword}:{significance}:{limit}:{offset}:{query_agent_id}:{team_id}"
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached

        # FTS 快速路径：仅关键词查询
        if keyword and self._has_fts and not any([time_from, time_to, person_id, nature_id, topic_code, tool_id, knowledge_id, importance]):
            try:
                results = self._query_fts(keyword, limit)
                if use_permission_filter:
                    results = self._apply_visibility_filter(results, query_agent_id, team_id, include_public)
                self._cache_set(cache_key, results)
                return results
            except Exception as e:
                logger.warning(f"FTS 快速路径失败，走标准查询: {e}")
                self._has_fts = False

        # 构建查询条件
        conditions = []
        params = []

        # 权限过滤条件
        if use_permission_filter:
            vis_parts = []
            vis_parts.append("m.owner_agent_id = ?")
            params.append(query_agent_id)
            vis_parts.append("(m.visibility = 'team' AND m.owner_agent_id IN (SELECT agent_id FROM agents WHERE team_id = ?))")
            params.append(team_id)
            if include_public:
                vis_parts.append("m.visibility = 'public'")
            vis_parts.append("(m.memory_id IN ("
                "SELECT memory_id FROM memory_permissions "
                "WHERE agent_id = ? AND (expires_at IS NULL OR expires_at > ?)"
            "))")
            params.append(query_agent_id)
            params.append(int(time.time()))
            conditions.append(f"({' OR '.join(vis_parts)})")

        # 时间范围条件
        if time_from is not None:
            conditions.append("m.time_ts >= ?")
            params.append(time_from)
        if time_to is not None:
            conditions.append("m.time_ts <= ?")
            params.append(time_to)

        # 其他过滤条件
        if person_id:
            conditions.append("m.person_id = ?")
            params.append(person_id)
        if nature_id:
            conditions.append("m.nature_id = ?")
            params.append(nature_id)
        if importance:
            conditions.append("m.importance = ?")
            params.append(importance)
        if significance:
            conditions.append("m.significance = ?")
            params.append(significance)

        # 关键词查询
        if keyword:
            if self._has_fts:
                try:
                    # 使用 FTS 加速关键词查询
                    fts_results = self._query_fts(keyword, limit * 2)
                    fts_ids = [r["memory_id"] for r in fts_results]
                    if fts_ids:
                        # 使用 IN 子句过滤
                        placeholders = ",".join("?" * len(fts_ids))
                        conditions.append(f"m.memory_id IN ({placeholders})")
                        params.extend(fts_ids)
                    else:
                        # FTS 无结果，使用 LIKE
                        conditions.append("m.content LIKE ?")
                        params.append(f"%{keyword}%")
                except Exception as e:
                    logger.warning(f"FTS 查询失败，降级到 LIKE: {e}")
                    self._has_fts = False
                    conditions.append("m.content LIKE ?")
                    params.append(f"%{keyword}%")
            else:
                conditions.append("m.content LIKE ?")
                params.append(f"%{keyword}%")

        # 构建 WHERE 子句
        where = " AND ".join(conditions) if conditions else "1=1"

        # 构建 SQL 查询
        joins = []
        if topic_code:
            joins.append("JOIN memory_topics mt ON m.memory_id = mt.memory_id")
        if tool_id:
            joins.append("JOIN memory_tools mt2 ON m.memory_id = mt2.memory_id")
        if knowledge_id:
            joins.append("JOIN memory_knowledge mk ON m.memory_id = mk.memory_id")

        join_clause = " ".join(joins)

        sql = f"""
            SELECT DISTINCT m.* FROM memories m
            {join_clause}
            WHERE {where}
            {"AND mt.topic_code LIKE ?" if topic_code else ""}
            {"AND mt2.tool_id = ?" if tool_id else ""}
            {"AND mk.knowledge_id = ?" if knowledge_id else ""}
            ORDER BY m.time_ts DESC
            LIMIT ? OFFSET ?
        """

        # 添加主题、工具、知识类型参数
        if topic_code:
            params.append(topic_code + "%")
        if tool_id:
            params.append(tool_id)
        if knowledge_id:
            params.append(knowledge_id)
        params.extend([limit, offset])

        # 执行查询
        rows = self.conn.execute(sql, params).fetchall()

        # 批量获取关联数据
        memory_ids = [row["memory_id"] for row in rows]
        topics_map = self._batch_get_topics(memory_ids)
        tools_map = self._batch_get_tools(memory_ids)
        knowledge_map = self._batch_get_knowledge(memory_ids)

        # 构建结果
        results = []
        for row in rows:
            mem = dict(row)
            mid = mem["memory_id"]
            mem["topics"] = topics_map.get(mid, [])
            mem["tools"] = tools_map.get(mid, [])
            mem["knowledge"] = knowledge_map.get(mid, [])
            results.append(mem)

        # 应用权限过滤
        if use_permission_filter:
            results = self._apply_visibility_filter(results, query_agent_id, team_id, include_public)

        # 缓存结果
        self._cache_set(cache_key, results)
        return results

    def _query_fts(self, keyword: str, limit: int) -> list[dict]:
        """FTS5 全文搜索（trigram 兼容）

        Fix (#22): FTS5 trigram 对中文短查询命中率低。
        策略：
          1. < 3 字符 → 直接 LIKE
          2. FTS5 MATCH 正常搜索
          3. FTS5 返回 0 结果 → CJK 分词后回退 LIKE
        """
        try:
            if len(keyword.strip()) < 3:
                rows = self.conn.execute(
                    "SELECT * FROM memories WHERE content LIKE ? ORDER BY time_ts DESC LIMIT ?",
                    (f"%{keyword}%", limit),
                ).fetchall()
                return [dict(r) for r in rows]

            safe_keyword = keyword.replace('"', '""')
            safe_keyword = re.sub(r'\b(NOT|AND|OR|NEAR)\b', ' ', safe_keyword, flags=re.IGNORECASE)
            safe_keyword = safe_keyword.replace('+', ' ').replace('-', ' ')
            words = [w.strip() for w in safe_keyword.split() if len(w.strip()) >= 2]
            if not words:
                words = [safe_keyword]

            match_expr = " OR ".join(f'"{w}"*' for w in words)
            rows = self.conn.execute(
                """SELECT m.* FROM memories m
                   JOIN memories_fts fts ON m.memory_id = fts.memory_id
                   WHERE memories_fts MATCH ?
                   ORDER BY rank
                   LIMIT ?""",
                (match_expr, limit),
            ).fetchall()

            # Fix (#22): FTS5 trigram 对中文查询返回 0 结果时，分词后回退 LIKE
            if not rows and self._is_cjk_query(keyword):
                logger.debug(f"FTS 返回 0 结果，CJK LIKE 回退: {keyword}")
                rows = self._like_fallback_cjk(keyword, limit)

            return [dict(r) for r in rows]
        except Exception as e:
            # Fix (Issue 2): FTS 失败时自动重建
            logger.warning(f"FTS 查询异常，触发自动重建: {e}")
            try:
                self.rebuild_fts()
            except Exception:
                pass
            # 回退到 LIKE
            return self._like_fallback_cjk(keyword, limit)

    def _like_fallback_cjk(self, keyword: str, limit: int) -> list[dict]:
        """CJK 查询 LIKE 回退：先整串匹配，无结果则分词匹配"""
        try:
            # 整串匹配
            rows = self.conn.execute(
                "SELECT * FROM memories WHERE content LIKE ? ORDER BY time_ts DESC LIMIT ?",
                (f"%{keyword}%", limit),
            ).fetchall()
            if rows:
                return [dict(r) for r in rows]

            # Fix (#22): 分词匹配 — 将 '炒菜烹饪' 拆为 ['炒菜', '烹饪']
            # 用滑动窗口提取 2-gram 作为搜索词
            cjk_chars = re.findall(r'[\u4e00-\u9fff\u3400-\u4dbf]+', keyword)
            if not cjk_chars:
                return []
            like_parts = []
            for segment in cjk_chars:
                # 2-gram 滑动窗口
                for i in range(len(segment) - 1):
                    bigram = segment[i:i+2]
                    if bigram not in like_parts:
                        like_parts.append(bigram)
                # 单字 fallback（≥2 字的段）
                if len(segment) >= 3:
                    for ch in segment:
                        if ch not in [p for p in like_parts if len(p) == 1]:
                            pass  # 单字 LIKE 太宽泛，跳过

            if not like_parts:
                return []

            # 任一 bigram 匹配即返回（OR 查询）
            conditions = " OR ".join(["content LIKE ?"] * len(like_parts))
            params = [f"%{bg}%" for bg in like_parts]
            rows = self.conn.execute(
                f"SELECT * FROM memories WHERE ({conditions}) ORDER BY time_ts DESC LIMIT ?",
                params + [limit],
            ).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []

    @staticmethod
    def _is_cjk_query(text: str) -> bool:
        """判断查询是否包含 CJK（中日韩）字符"""
        return bool(re.search(r'[\u4e00-\u9fff\u3400-\u4dbf]', text))

    def _apply_visibility_filter(self, memories: list[dict], query_agent_id: str, team_id: str, include_public: bool) -> list[dict]:
        filtered = []
        for mem in memories:
            if mem.get("owner_agent_id") == query_agent_id:
                filtered.append(mem)
                continue
            if mem.get("visibility") == "public" and include_public:
                filtered.append(mem)
                continue
            if mem.get("visibility") == "team":
                owner = self.get_agent(mem.get("owner_agent_id", ""))
                if owner and owner.get("team_id") == team_id:
                    filtered.append(mem)
                    continue
            if self.check_permission(mem["memory_id"], query_agent_id, "read"):
                filtered.append(mem)
                continue
        return filtered

    def get_linked(self, memory_id: str, link_type: str = None, max_depth: int = 1) -> list[dict]:
        visited = set()
        results = []

        def _traverse(current_id, depth, weight):
            if depth > max_depth or current_id in visited:
                return
            visited.add(current_id)

            conditions = ["(source_id = ? OR target_id = ?)"]
            params = [current_id, current_id]
            if link_type:
                conditions.append("link_type = ?")
                params.append(link_type)

            links = self.conn.execute(
                f"SELECT * FROM memory_links WHERE {' AND '.join(conditions)}",
                params,
            ).fetchall()

            for link in links:
                target = link["target_id"] if link["source_id"] == current_id else link["source_id"]
                if target not in visited:
                    mem = self.get_memory(target)
                    if mem:
                        mem["_link_weight"] = weight * link["weight"]
                        mem["_link_type"] = link["link_type"]
                        mem["_link_depth"] = depth
                        results.append(mem)
                    _traverse(target, depth + 1, weight * link["weight"])

        _traverse(memory_id, 1, 1.0)
        return results

    # ── 待办任务管理 ──────────────────────────────────────

    def add_task(self, memory_id: str, title: str, assignee: str = "ai", deadline: int = None, topic_code: str = None) -> str:
        raw = f"{memory_id}_{title}_{time.time()}"
        task_id = "task_" + hashlib.sha256(raw.encode()).hexdigest()[:12]
        with self.transaction() as conn:
            conn.execute(
                """INSERT INTO tasks (task_id, memory_id, title, status, assignee, deadline, topic_code)
                   VALUES (?, ?, ?, 'pending', ?, ?, ?)""",
                (task_id, memory_id, title, assignee, deadline, topic_code),
            )
        self._invalidate_cache()
        return task_id

    def update_task_status(self, task_id: str, status: str) -> bool:
        valid = {"pending", "in_progress", "done", "overdue"}
        if status not in valid:
            raise ValueError(f"无效状态: {status}，可选: {valid}")

        now = int(time.time())
        params = [status, now]
        sql = "UPDATE tasks SET status = ?, updated_at = ?"
        if status == "done":
            sql += ", completed_at = ?"
            params.append(now)
        sql += " WHERE task_id = ?"
        params.append(task_id)

        with self.transaction() as conn:
            cur = conn.execute(sql, params)
        self._invalidate_cache()
        return cur.rowcount > 0

    def get_tasks(self, status: str = None, assignee: str = None, topic_code: str = None, overdue_only: bool = False, limit: int = 50) -> list[dict]:
        conditions = []
        params = []
        if status:
            conditions.append("t.status = ?")
            params.append(status)
        if assignee:
            conditions.append("t.assignee = ?")
            params.append(assignee)
        if topic_code:
            conditions.append("t.topic_code LIKE ?")
            params.append(topic_code + "%")
        if overdue_only:
            conditions.append("t.deadline < ? AND t.status NOT IN ('done', 'overdue')")
            params.append(int(time.time()))

        where = " AND ".join(conditions) if conditions else "1=1"

        rows = self.conn.execute(
            f"""SELECT t.*, m.content as memory_content
                FROM tasks t
                LEFT JOIN memories m ON t.memory_id = m.memory_id
                WHERE {where}
                ORDER BY
                    CASE t.status
                        WHEN 'overdue' THEN 0
                        WHEN 'pending' THEN 1
                        WHEN 'in_progress' THEN 2
                        WHEN 'done' THEN 3
                    END,
                    t.created_at DESC
                LIMIT ?""",
            params + [limit],
        ).fetchall()
        return [dict(r) for r in rows]

    def check_overdue(self) -> list[dict]:
        now = int(time.time())
        rows = self.conn.execute(
            """SELECT task_id FROM tasks
               WHERE deadline < ? AND status IN ('pending', 'in_progress')""",
            (now,),
        ).fetchall()
        overdue_ids = [r["task_id"] for r in rows]
        if overdue_ids:
            with self.transaction() as conn:
                for tid in overdue_ids:
                    conn.execute(
                        "UPDATE tasks SET status = 'overdue', updated_at = ? WHERE task_id = ?",
                        (now, tid),
                    )
        result = []
        for tid in overdue_ids:
            row = self.conn.execute("SELECT * FROM tasks WHERE task_id = ?", (tid,)).fetchone()
            if row:
                result.append(dict(row))
        return result

    def get_task_stats(self) -> dict:
        rows = self.conn.execute("SELECT status, COUNT(*) as cnt FROM tasks GROUP BY status").fetchall()
        stats = {r["status"]: r["cnt"] for r in rows}
        stats["total"] = sum(stats.values())
        return stats

    # ── 内部方法 ──────────────────────────────────────────

    def _get_topics(self, memory_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT topic_code, is_primary FROM memory_topics WHERE memory_id = ?", (memory_id,)
        ).fetchall()
        return [{"code": r["topic_code"], "is_primary": bool(r["is_primary"])} for r in rows]

    def _get_tools(self, memory_id: str) -> list[str]:
        rows = self.conn.execute("SELECT tool_id FROM memory_tools WHERE memory_id = ?", (memory_id,)).fetchall()
        return [r["tool_id"] for r in rows]

    def _get_knowledge(self, memory_id: str) -> list[str]:
        rows = self.conn.execute("SELECT knowledge_id FROM memory_knowledge WHERE memory_id = ?", (memory_id,)).fetchall()
        return [r["knowledge_id"] for r in rows]

    def _batch_get_topics(self, memory_ids: list[str]) -> dict[str, list[dict]]:
        if not memory_ids:
            return {}
        placeholders = ",".join("?" * len(memory_ids))
        rows = self.conn.execute(
            f"SELECT memory_id, topic_code, is_primary FROM memory_topics WHERE memory_id IN ({placeholders})", memory_ids,
        ).fetchall()
        result = {}
        for r in rows:
            mid = r["memory_id"]
            if mid not in result:
                result[mid] = []
            result[mid].append({"code": r["topic_code"], "is_primary": bool(r["is_primary"])})
        return result

    def _batch_get_tools(self, memory_ids: list[str]) -> dict[str, list[str]]:
        if not memory_ids:
            return {}
        placeholders = ",".join("?" * len(memory_ids))
        rows = self.conn.execute(
            f"SELECT memory_id, tool_id FROM memory_tools WHERE memory_id IN ({placeholders})", memory_ids,
        ).fetchall()
        result = {}
        for r in rows:
            mid = r["memory_id"]
            if mid not in result:
                result[mid] = []
            result[mid].append(r["tool_id"])
        return result

    def _batch_get_knowledge(self, memory_ids: list[str]) -> dict[str, list[str]]:
        if not memory_ids:
            return {}
        placeholders = ",".join("?" * len(memory_ids))
        rows = self.conn.execute(
            f"SELECT memory_id, knowledge_id FROM memory_knowledge WHERE memory_id IN ({placeholders})", memory_ids,
        ).fetchall()
        result = {}
        for r in rows:
            mid = r["memory_id"]
            if mid not in result:
                result[mid] = []
            result[mid].append(r["knowledge_id"])
        return result

    def _get_links(self, memory_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM memory_links WHERE source_id = ? OR target_id = ?", (memory_id, memory_id)
        ).fetchall()
        return [dict(r) for r in rows]

    def close(self):
        if hasattr(self._local, 'conn') and self._local.conn:
            self._local.conn.close()
            # Fix (#17): 从全局追踪中移除
            with self._all_conns_lock:
                self._all_conns.pop(threading.get_ident(), None)
            self._local.conn = None

    def close_all(self):
        """关闭所有线程的连接 — 用于 server.py 优雅关闭（Fix #17）"""
        with self._all_conns_lock:
            for tid, conn in list(self._all_conns.items()):
                try:
                    conn.close()
                except Exception:
                    pass
            self._all_conns.clear()
        # 清理当前线程的引用
        if hasattr(self._local, 'conn'):
            self._local.conn = None

    # ── Agent 管理 ─────────────────────────────────────

    def register_agent(self, agent_id: str, agent_name: str, team_id: str = "default", capabilities: list[str] = None) -> dict:
        import json as _json
        caps = _json.dumps(capabilities or [], ensure_ascii=False)
        with self.transaction() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO agents (agent_id, agent_name, team_id, capabilities, status)
                   VALUES (?, ?, ?, ?, 'active')""",
                (agent_id, agent_name, team_id, caps),
            )
        return {"agent_id": agent_id, "agent_name": agent_name, "team_id": team_id}

    def get_agent(self, agent_id: str) -> dict | None:
        row = self.conn.execute("SELECT * FROM agents WHERE agent_id = ?", (agent_id,)).fetchone()
        if not row:
            return None
        import json as _json
        d = dict(row)
        try:
            d["capabilities"] = _json.loads(d.get("capabilities", "[]"))
        except Exception:
            d["capabilities"] = []
        return d

    def list_agents(self, team_id: str = None) -> list[dict]:
        if team_id:
            rows = self.conn.execute("SELECT * FROM agents WHERE team_id = ? AND status = 'active'", (team_id,)).fetchall()
        else:
            rows = self.conn.execute("SELECT * FROM agents WHERE status = 'active'").fetchall()
        import json as _json
        result = []
        for r in rows:
            d = dict(r)
            try:
                d["capabilities"] = _json.loads(d.get("capabilities", "[]"))
            except Exception:
                d["capabilities"] = []
            result.append(d)
        return result

    # ── 权限管理 ───────────────────────────────────────

    def grant_permission(self, memory_id: str, agent_id: str, granted_by: str, permission: str = "read", expires_at: int = None) -> bool:
        try:
            with self.transaction() as conn:
                conn.execute(
                    """INSERT OR REPLACE INTO memory_permissions
                       (memory_id, agent_id, permission, granted_by, expires_at)
                       VALUES (?, ?, ?, ?, ?)""",
                    (memory_id, agent_id, permission, granted_by, expires_at),
                )
            return True
        except Exception:
            return False

    def revoke_permission(self, memory_id: str, agent_id: str) -> bool:
        try:
            with self.transaction() as conn:
                conn.execute(
                    "DELETE FROM memory_permissions WHERE memory_id = ? AND agent_id = ?",
                    (memory_id, agent_id),
                )
            return True
        except Exception:
            return False

    def check_permission(self, memory_id: str, agent_id: str, required: str = "read") -> bool:
        now = int(time.time())
        row = self.conn.execute(
            """SELECT permission, expires_at FROM memory_permissions
               WHERE memory_id = ? AND agent_id = ? AND (expires_at IS NULL OR expires_at > ?)""",
            (memory_id, agent_id, now),
        ).fetchone()
        if not row:
            return False
        perm_levels = {"read": 1, "write": 2, "admin": 3}
        return perm_levels.get(row["permission"], 0) >= perm_levels.get(required, 1)

    def query_agent_memories(self, agent_id: str, team_id: str = "default", query_agent_id: str = None, include_public: bool = True, limit: int = 50, **kwargs) -> list[dict]:
        if not query_agent_id:
            return self.query(limit=limit, **kwargs)

        conditions = []
        params = []
        vis_conditions = []

        vis_conditions.append("(m.owner_agent_id = ?)")
        params.append(query_agent_id)
        vis_conditions.append("(m.visibility = 'team' AND m.owner_agent_id IN (SELECT agent_id FROM agents WHERE team_id = ?))")
        params.append(team_id)
        if include_public:
            vis_conditions.append("m.visibility = 'public'")
        vis_conditions.append("""(m.memory_id IN (
            SELECT memory_id FROM memory_permissions
            WHERE agent_id = ? AND (expires_at IS NULL OR expires_at > ?)
        ))""")
        params.append(query_agent_id)
        params.append(int(time.time()))
        conditions.append(f"({' OR '.join(vis_conditions)})")

        if agent_id:
            conditions.append("m.owner_agent_id = ?")
            params.append(agent_id)

        for field in ("importance", "nature_id", "person_id"):
            val = kwargs.get(field)
            if val:
                conditions.append(f"m.{field} = ?")
                params.append(val)
        if kwargs.get("time_from"):
            conditions.append("m.time_ts >= ?")
            params.append(kwargs["time_from"])
        if kwargs.get("time_to"):
            conditions.append("m.time_ts <= ?")
            params.append(kwargs["time_to"])

        where = " AND ".join(conditions) if conditions else "1=1"

        rows = self.conn.execute(
            f"SELECT * FROM memories m WHERE {where} ORDER BY m.time_ts DESC LIMIT ?",
            params + [limit],
        ).fetchall()

        memory_ids = [r["memory_id"] for r in rows]
        topics_map = self._batch_get_topics(memory_ids)
        tools_map = self._batch_get_tools(memory_ids)

        results = []
        for row in rows:
            mem = dict(row)
            mid = mem["memory_id"]
            mem["topics"] = topics_map.get(mid, [])
            mem["tools"] = tools_map.get(mid, [])
            results.append(mem)
        return results

    # ── 跨 Agent 关联 ─────────────────────────────────

    def add_agent_association(self, source_agent: str, target_agent: str, memory_id: str, assoc_type: str = "shares_knowledge", reason: str = None) -> bool:
        try:
            with self.transaction() as conn:
                conn.execute(
                    """INSERT INTO agent_associations (source_agent, target_agent, memory_id, association_type, reason)
                       VALUES (?, ?, ?, ?, ?)""",
                    (source_agent, target_agent, memory_id, assoc_type, reason),
                )
            return True
        except Exception:
            return False

    def get_agent_associations(self, agent_id: str, direction: str = "both") -> list[dict]:
        if direction == "incoming":
            rows = self.conn.execute(
                """SELECT aa.*, m.content as memory_content, m.owner_agent_id
                   FROM agent_associations aa
                   JOIN memories m ON aa.memory_id = m.memory_id
                   WHERE aa.target_agent = ?""", (agent_id,),
            ).fetchall()
        elif direction == "outgoing":
            rows = self.conn.execute(
                """SELECT aa.*, m.content as memory_content, m.owner_agent_id
                   FROM agent_associations aa
                   JOIN memories m ON aa.memory_id = m.memory_id
                   WHERE aa.source_agent = ?""", (agent_id,),
            ).fetchall()
        else:
            rows = self.conn.execute(
                """SELECT aa.*, m.content as memory_content, m.owner_agent_id
                   FROM agent_associations aa
                   JOIN memories m ON aa.memory_id = m.memory_id
                   WHERE aa.source_agent = ? OR aa.target_agent = ?""",
                (agent_id, agent_id),
            ).fetchall()
        return [dict(r) for r in rows]

    def get_io_stats(self) -> dict:
        with self._thread_lock:
            stats = dict(self._stats)
        total = stats["reads"] + stats["cache_misses"]
        stats["cache_hit_rate"] = stats["cache_hits"] / total if total > 0 else 0
        stats["has_fts"] = self._has_fts
        stats["max_memories"] = self._max_memories
        return stats

    def optimize(self):
        logger.info("数据库优化中...")
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("ANALYZE")
            conn.execute("PRAGMA optimize")
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        logger.info("数据库优化完成")

    def vacuum(self):
        logger.info("VACUUM 执行中...")
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("VACUUM")
        logger.info("VACUUM 完成")

    def check_integrity(self) -> dict:
        issues = []
        try:
            row = self.conn.execute("PRAGMA integrity_check").fetchone()
            result = (row[0] if row else "unknown").strip()
            if result != "ok":
                issues.append(f"integrity_check: {result}")
        except Exception as e:
            issues.append(f"integrity_check failed: {e}")

        try:
            row = self.conn.execute("PRAGMA foreign_key_check").fetchone()
            if row:
                issues.append(f"foreign_key violation: table={row[0]}, rowid={row[1]}, parent={row[2]}")
        except Exception as e:
            issues.append(f"foreign_key_check failed: {e}")

        return {"ok": len(issues) == 0, "issues": issues, "checked_at": int(time.time())}

    def auto_maintain(self, vacuum_threshold_mb: float = 50, embedding_store=None):
        """自动维护：WAL checkpoint + 完整性检查 + 按需 VACUUM + FTS 健康检查"""
        integrity = self.check_integrity()
        if not integrity["ok"]:
            logger.warning(f"⚠️ 数据库完整性问题: {integrity['issues']}")

        # Fix (Issue 2): FTS 健康检查 — 如果 FTS 索引条目远少于记忆条目，触发重建
        try:
            if self._has_fts:
                fts_count = self.conn.execute("SELECT COUNT(*) FROM memories_fts").fetchone()[0]
                mem_count = self.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
                if mem_count > 0 and fts_count < mem_count * 0.9:
                    logger.warning(f"FTS 索引不一致: fts={fts_count}, memories={mem_count}，触发重建")
                    self.rebuild_fts()
        except Exception:
            pass

        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:
            pass

        try:
            db_size_mb = os.path.getsize(self.db_path) / (1024 * 1024)
            if db_size_mb > vacuum_threshold_mb:
                self.vacuum()
        except Exception:
            pass

    # ── 冷热分离 ─────────────────────────────────────

    def init_cold_storage(self, cold_db_path: str = None):
        import sqlite3 as _sqlite3
        self._cold_db_path = cold_db_path or self.db_path.replace(".db", "_cold.db")
        self._cold_conn = _sqlite3.connect(self._cold_db_path)
        self._cold_conn.row_factory = sqlite3.Row
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            self._cold_conn.executescript(f.read())
        self._cold_conn.commit()
        logger.info(f"冷存储初始化: {self._cold_db_path}")

    def move_to_cold(self, memory_ids: list[str], skip_referenced: bool = True) -> int:
        """将记忆迁移到冷存储（含向量清理）"""
        if not hasattr(self, '_cold_conn'):
            self.init_cold_storage()

        moved = 0
        skipped = 0
        for mid in memory_ids:
            mem = self.get_memory(mid)
            if not mem:
                continue

            if skip_referenced:
                ref_count = self.conn.execute(
                    "SELECT COUNT(*) as cnt FROM memory_links WHERE target_id = ?", (mid,)
                ).fetchone()["cnt"]
                if ref_count > 0:
                    skipped += 1
                    continue

            try:
                with self._cold_conn:
                    self._cold_conn.execute(
                        """INSERT OR REPLACE INTO memories
                           (memory_id, time_id, time_ts, person_id, nature_id,
                            content, content_hash, importance, is_aggregated, source_count,
                            owner_agent_id, visibility)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (mem["memory_id"], mem["time_id"], mem["time_ts"],
                         mem["person_id"], mem["nature_id"], mem["content"],
                         mem.get("content_hash", ""), mem.get("importance", "medium"),
                         mem.get("is_aggregated", 0), mem.get("source_count", 1),
                         mem.get("owner_agent_id", "_system"), mem.get("visibility", "team")),
                    )
                with self.transaction() as conn:
                    conn.execute("DELETE FROM memory_topics WHERE memory_id = ?", (mid,))
                    conn.execute("DELETE FROM memory_tools WHERE memory_id = ?", (mid,))
                    conn.execute("DELETE FROM memory_knowledge WHERE memory_id = ?", (mid,))
                    conn.execute("DELETE FROM memory_links WHERE source_id = ? OR target_id = ?", (mid, mid))
                    if self._has_fts:
                        try:
                            conn.execute("DELETE FROM memories_fts WHERE memory_id = ?", (mid,))
                        except Exception:
                            pass
                    conn.execute("DELETE FROM memories WHERE memory_id = ?", (mid,))

                # Fix: 冷迁移时同步清理向量
                if self._embedding_store_ref:
                    try:
                        self._embedding_store_ref.delete(mid)
                    except Exception:
                        pass

                moved += 1
            except Exception as e:
                logger.warning(f"冷迁移失败 {mid}: {e}")

        self._invalidate_cache()
        if skipped:
            logger.info(f"❄️ 冷迁移: {moved} 条已迁移, {skipped} 条因被引用跳过")
        else:
            logger.info(f"❄️ 冷迁移: {moved} 条记忆")
        return moved

    def search_cold(self, keyword: str = None, limit: int = 50) -> list[dict]:
        if not hasattr(self, '_cold_conn'):
            return []
        if keyword:
            rows = self._cold_conn.execute(
                "SELECT * FROM memories WHERE content LIKE ? ORDER BY time_ts DESC LIMIT ?",
                (f"%{keyword}%", limit),
            ).fetchall()
        else:
            rows = self._cold_conn.execute(
                "SELECT * FROM memories ORDER BY time_ts DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    def get_storage_stats(self) -> dict:
        hot_count = self.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        cold_count = 0
        if hasattr(self, '_cold_conn'):
            cold_count = self._cold_conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        db_size_mb = os.path.getsize(self.db_path) / (1024 * 1024) if os.path.exists(self.db_path) else 0
        vector_count = 0
        if self._embedding_store_ref:
            try:
                vector_count = self._embedding_store_ref.count()
            except Exception:
                pass
        return {"hot_count": hot_count, "cold_count": cold_count, "hot_size_mb": round(db_size_mb, 2), "vector_count": vector_count}

    def backup(self, backup_path: str):
        import shutil
        import os
        import time
        tmp = backup_path + ".tmp"
        
        # 检查数据库文件是否存在且有内容
        if not os.path.exists(self.db_path):
            logger.error(f"数据库文件不存在: {self.db_path}")
            return
        
        db_size = os.path.getsize(self.db_path)
        if db_size == 0:
            logger.error(f"数据库文件为空: {self.db_path}")
            return
        
        logger.info(f"开始备份: {self.db_path} ({db_size} bytes) -> {backup_path}")
        
        # 关闭所有连接，确保数据库文件不被锁定
        self.close_all()
        
        # 等待一小段时间，确保连接完全关闭
        time.sleep(0.1)
        
        # 复制数据库文件
        copy_success = False
        for attempt in range(5):
            try:
                shutil.copy2(self.db_path, tmp)
                # 检查复制是否成功
                if os.path.exists(tmp):
                    tmp_size = os.path.getsize(tmp)
                    logger.info(f"复制尝试 {attempt+1}: {tmp_size} bytes")
                    if tmp_size > 0:
                        copy_success = True
                        break
            except Exception as e:
                logger.error(f"复制失败: {e}")
                time.sleep(0.1)
                continue
        
        if not copy_success:
            logger.error("复制失败，备份终止")
            return
        
        # 重新打开连接
        _ = self.conn
        
        # 修复 Windows 上的权限问题
        if os.name == 'nt':  # Windows
            # 在 Windows 上，先删除目标文件（如果存在）
            if os.path.exists(backup_path):
                for attempt in range(5):
                    try:
                        os.unlink(backup_path)
                        logger.info(f"删除旧备份文件: {backup_path}")
                        break
                    except Exception as e:
                        logger.error(f"删除旧备份文件失败: {e}")
                        time.sleep(0.1)
                        continue
            
            # 然后重命名临时文件
            rename_success = False
            for attempt in range(5):
                try:
                    os.rename(tmp, backup_path)
                    logger.info(f"重命名临时文件: {tmp} -> {backup_path}")
                    rename_success = True
                    break
                except Exception as e:
                    logger.error(f"重命名失败: {e}")
                    time.sleep(0.1)
                    continue
            
            if not rename_success:
                logger.error("重命名失败，备份终止")
                return
        else:
            # 在 Unix-like 系统上使用原子替换
            try:
                os.replace(tmp, backup_path)
                logger.info(f"原子替换: {tmp} -> {backup_path}")
            except Exception as e:
                logger.error(f"原子替换失败: {e}")
                return
        
        # 检查最终备份文件
        if os.path.exists(backup_path):
            final_size = os.path.getsize(backup_path)
            logger.info(f"备份完成: {backup_path} ({final_size} bytes)")
        else:
            logger.error(f"备份文件不存在: {backup_path}")


    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
