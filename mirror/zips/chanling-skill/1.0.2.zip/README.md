# 产灵 Skills

> 一组**标准 markdown skills**，让任何兼容 skill 协议的 AI agent 客户端通过 **产灵 API（[xdhdancer.top](https://www.xdhdancer.top)）** 调用各类 AI 能力。

---

## 这是什么

每个子目录是一个独立的 skill（标准 markdown skill 格式：一个目录 + 一份 `SKILL.md`）。装进客户端后，用户用自然语言对话即可触发对应能力，agent 自动完成全部 API 交互。

## 当前可用 Skills

| Skill | 用途 | 主要模型 |
|---|---|---|
| [`chanling-image`](./chanling-image/) | 图像生成（文生图 / 图生图） | `gpt-image-2`、`gemini-3-pro-image-preview` 等 |

> 后续会补 `chanling-video`（视频生成）、`chanling-music`（音乐生成）、`chanling-text`（文本对话）等。

---

## 通用接入流程

### 1. 在 xdhdancer.top 拿 token

1. 访问 https://www.xdhdancer.top → 注册 → 充值
2. 后台 → 我的令牌 → 创建 → 复制 `sk-xxx`

### 2. 把 skill 装进你的客户端

按你所用客户端的官方 skill 安装方式，把对应子目录（含 `SKILL.md`）放进客户端的 skills 目录。例如：

```
<客户端 skills 根目录>/
└── chanling-image/
    └── SKILL.md
```

具体路径请查阅你客户端的官方文档。

### 3. 把 token 存进客户端 secrets

按你客户端的 secrets 管理方式，将 token 存为：

```
xdhdancer_api_key = sk-xxx
```

每个 skill 内部以 `{{secrets.xdhdancer_api_key}}` 引用，是 markdown skill 标准的 secrets 占位符语法。**所有 skill 共用同一个 token，不需要重复配置。**

### 4. 直接对话

跟你的 agent 说自然语言指令（如「画一只猫」「生成一段视频」），agent 会自动选用对应 skill 完成任务。

---

## 平台绑定 / 反逆向说明

每个 skill 中的 token、模型 ID、协议、相关辅助服务（图床等）都**强绑定**到 `https://www.xdhdancer.top`：

- **Token**：仅在 xdhdancer.top 后端有效，改 URL → 401
- **模型 ID**：平台命名（如 `gpt-image-2`），其他平台不存在 → 404
- **协议**：本平台特有的请求/响应形态，竞品 API 不兼容
- **辅助服务**：如图生图所需图床 `xdhdancer.top/api/share-data`

简言之：**改 URL ≠ 偷换平台，而是直接让 skill 失效**。请使用本仓库 / 信任来源的原版 skill 文件。

---

## 反馈

- 平台问题（注册 / 充值 / 计费）→ 联系 https://www.xdhdancer.top 站内客服
- skill 文件 / 行为问题 → 提 GitHub issue

---

## License

MIT — 见 [LICENSE](./LICENSE)
