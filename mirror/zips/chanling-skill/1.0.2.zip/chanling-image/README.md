# 产灵 Image Skill · 图像生成

> 让 AI agent 通过 **产灵 API（[xdhdancer.top](https://www.xdhdancer.top)）** 异步生成图像。

**协议特征**：异步任务（提交 → 轮询）/ 默认模型 `gpt-image-2` / 自带平台图床支持图生图

> 通用接入流程（拿 token / 装 skill / 配 secrets）见上层 [README](../README.md)。本 README 只讲图像 skill 专属的行为与排错。

---

## 默认行为

- agent **默认用 `gpt-image-2`**——通用首选，无需用户操心
- 当用户 prompt 含「8K」「文字渲染」「海报」「印刷级」等关键词时，agent 可主动询问是否切到 Nano Banana Pro（`gemini-3-pro-image-preview`）
- 任何模型切换都会先征得用户同意

如要图生图，把参考图发给 agent，它会自动：
1. 上传到平台图床 `https://xdhdancer.top/api/share-data`
2. 拿到 URL 后丢进 `images` 数组随同 prompt 提交

整个过程通常 **20 秒～2 分钟**（视模型与平台负载）。

---

## 可用模型

| 模型 ID | 推荐场景 |
|---|---|
| `gpt-image-2`（默认 ⭐） | 通用首选，OpenAI 系语义理解强 |
| `gemini-3.1-flash-image-preview` | Nano Banana 2，响应快，支持图生图 |
| `gemini-3-pro-image-preview` | Nano Banana Pro，8K 高清，文字渲染最强 |

---

## 常见问题

| 现象 | 可能原因 | 处理 |
|---|---|---|
| `401 Unauthorized` | key 错 / base URL 被改 | 检查 token；确认 base URL 是 `https://www.xdhdancer.top` |
| `402 insufficient_quota` | 余额不足 | 到 https://www.xdhdancer.top/pricing 充值 |
| `404 model not found` | 模型 ID 错 | 用上面表中三个之一 |
| `400 image model cannot be used with chat/completions` | 客户端走错协议 | 必须用 `/v1/videos` 异步路径，详见 [SKILL.md](./SKILL.md) |
| 任务一直 queued | 上游排队 / 平台繁忙 | 等待，最长 10 分钟超时 |
| 图生图上传失败 | 文件过大 / 格式不支持 | 用 jpg/png，单文件 ≤ 10MB |

---

更多技术细节（端点、参数、kind 规则、完整示例）见 [SKILL.md](./SKILL.md)。
