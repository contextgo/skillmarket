---
name: hk-saas-api
description: >-
  Generates SAAS platform integration code in multiple languages (HTTP client,
  request signing, verification) using the bundled YAML API catalog (doc/api-catalog.yaml)
  and structured signing spec (reference/signing.md). If no catalog match, prompt the user
  to confirm the API name or supply a doc URL or pasted spec; fetch user URLs like catalog
  doc_url. Config holds request URLs only; credentials via env/secrets; shared sign+POST;
  doc-example demos only when the user does not specify parameter flow and placement.
  Use when the user types /hk-api or /hk-update, or asks to integrate SAAS or
  海科/机构对接 APIs in Java, Python, Go, TypeScript, C#, etc.
  /hk-update is used to refresh local API document cache from online doc portal.
---

# SAAS 平台接口对接（hk-saas-api）

## 何时启用

用户在消息中使用 **`/hk-api`**，或表达要对接 **SAAS / 海科 API**、实现 **sign签名**、按接口文档**生成对接代码**时，须按本 skill 流程执行。

用户在消息中使用 **`/hk-update`**，或表达要**更新接口文档缓存**时，须按 §7 流程执行。

## 自包含约束（必读）

本 skill **可单独复制到任意工程或工具目录使用**。执行时**只读**本目录内资源：

| 路径 | 用途 |
|------|------|
| `doc/api-catalog.yaml` | 接口场景与在线文档 URL（**唯一结构化目录**，勿再找历史 txt）；每个 API 含 `local_doc` 指向本地缓存 |
| `doc/docs/` | **本地接口文档缓存**（Markdown 格式，从在线文档门户预下载并转换），`manifest.json` 记录下载时间与映射 |
| `doc/SignUtils.java` | **Java** 可直接复制到目标工程工具包；其它语言勿直接拷贝，见 §5 |
| `reference/signing.md` | Sign 算法、速查表、golden examples（**规范与跨语言对照**） |
| `reference/api-index.md` | 场景 id与人类可读索引 |
| `reference/languages.md` | 多语言检测与 HTTP 栈建议 |
| `doc/README.md`（可选） | `doc/` 目录说明 |

**仅导入本文件夹即可**：无论从何处复制（例如本仓库的 `api-server/skills/hk-saas-api`），目标环境**只需要**这一层目录内的全部文件与子目录；**不必**带上 `hkrt_ai`、`api-server` 或任何上级路径。Markdown/YAML 中的相对路径均以 **`hk-saas-api/`根目录** 为基准解析。

**禁止**引用本 skill 目录外的「原始 txt / 未整理附件」；**禁止**假设运行时代码仓库里一定存在名为 `api-server/` 的目录（文中若出现仅作反面说明）。

## 工作流（必须按序）

```mermaid
flowchart TD
  trigger[Trigger_slash_saas_or_intent]
  scene[Resolve_or_list_business_scenes]
  api[Resolve_or_list_APIs_under_scene]
  miss{Catalog_hit?}
  clarify[Confirm_API_name_or_user_doc_URL_or_paste]
  lang[Detect_or_ask_target_language]
  learn[Learn_project_conventions]
  fetch_online[Try_fetch_doc_url_online]
  online_ok{Online_fetch_ok?}
  fetch_local[Read_local_doc_cache]
  local_ok{Local_doc_exists?}
  ask_user[Ask_user_to_provide_doc]
  gen[Generate_client_and_sign_helper]
  check[Syntax_and_convention_check]
  trigger --> scene --> api --> miss
  miss -->|no| clarify --> lang --> learn --> fetch_online
  miss -->|yes| lang --> learn --> fetch_online
  fetch_online --> online_ok
  online_ok -->|yes| gen --> check
  online_ok -->|no| fetch_local --> local_ok
  local_ok -->|yes| gen --> check
  local_ok -->|no| ask_user --> gen --> check
```

进度清单：

```
- [ ] 业务场景已明确（或已从 api-catalog 的 scenario 列出并确认）
- [ ] 具体接口已明确（catalog 唯一命中，或多匹配时已列出候选并由用户选定具体接口，或用户已提供文档/URL）
- [ ] 若在 catalog 中未命中：已向用户说明无匹配项，并确认名称准确性或已取得文档/URL
- [ ] 目标语言已明确
- [ ] 已学习当前项目的开发规范（目录结构、命名风格、代码分层、依赖管理等）
- [ ] 已取得接口文档内容（在线抓取成功 / 本地缓存读取 / 用户提供）
- [ ] 已在用户指定路径生成对接代码；签名实现符合 reference/signing.md
- [ ] 已对生成代码做语法检查与项目规范一致性校验
```

### 1. 业务场景检测

- 读取 [`reference/api-index.md`](reference/api-index.md) 中的场景表（与 `api-catalog.yaml` 的 `scenarios[].id` 对应）。  
- 无法确定时：列出全部 `title`，用 **AskQuestion** 或对话映射到某个 `id`。

### 2. 接口检测

- 解析 [`doc/api-catalog.yaml`](doc/api-catalog.yaml)：在用户已选或已推断的 `scenarios[].id` 下匹配 `apis[].name`；若用户**未选场景**，可在**全部 scenarios** 中按名称做模糊检索。  
- **唯一命中**：展示该条的 **`name` + `doc_url`**，进入 §4。  
- **多个命中**（必须确认，严禁全量生成）：  
  1. **停止生成**，将匹配到的接口**列表展示**给用户（每项含 `name` + 所属场景），并**询问用户**具体需要对接哪个（或哪些）。  
  2. **用户指定后才继续**：在用户明确选出具体接口之前，**不得**生成任何对接代码。  
  3. 例外：**仅当用户明确说明「全部都要对接」或「上面列出的都生成」时**，方可按列表逐接口生成。  

**未命中 catalog 时（必读，禁止硬编）**  

1. **明确告知**：当前 `api-catalog.yaml` 中**没有**与用户描述一致的接口条目（或无法唯一确定），**不要**猜测或捏造 `doc_url`、路径与参数字段。  
2. **询问用户**：提供的**接口名称是否准确**（是否别名、简称、口误、是否属于别的产品线）。  
3. **名称不准确**：请用户给出**准确接口名称**或从门户里复制的**完整标题**后，**重新检索 catalog**；在用户提供准确名称之前，**不生成**对接代码。  
4. **名称准确仍无条目**（或用户直接选择自建流程）：请用户任选其一提供材料，再进入 §4 / §5：  
   - **接口文档正文**（可粘贴）：须至少包含测试/生产 **请求 URL**、参数表或请求示例、返回说明（能支撑签名与 HTTP 即可）；  
   - **接口文档地址**：用户给出的 **URL** 与 catalog 里的 `doc_url` **同等对待**——按 §4「快速提取法」**抓取页面**得到正文后再生成代码。  
5. 用户仅提供模糊需求且无法补齐名称或文档时：**停止生成**，保持对话直到材料足够；可建议用户到 SAAS 文档门户按关键词搜索后把**页面链接或截图文字**发回。

### 3. 目标语言检测（多语言）

见 [`reference/languages.md`](reference/languages.md)：优先用户明示 → 仓库文件信号 → 询问。

### 3.5 项目规范学习（必读，生成代码前必须执行）

本 skill 可能被导入**不同的开发工具、不同的项目、使用不同的编程语言**，因此生成代码前**必须**先了解当前项目的开发规范，确保生成的代码与项目风格一致。

**学习步骤：**

1. **扫描项目结构**：查看项目根目录及子目录的文件组织方式，识别：
   - 源码目录结构（如 `src/main/java`、`app/`、`lib/` 等）
   - 配置文件位置（如 `resources/`、`config/`、`.env` 等）
   - 工具类/公共方法存放目录（如 `utils/`、`common/`、`helpers/` 等）
   - 业务逻辑存放目录（如 `service/`、`controllers/`、`api/` 等）

2. **识别开发规范**：检查项目中是否包含规范文件：
   - `.editorconfig` — 编辑器配置
   - `eslint`/`ruff`/`checkstyle` 等代码检查配置
   - `README.md` 中的开发规范章节
   - 项目已有的代码风格（命名约定、注释风格、异常处理模式等）

3. **总结规范要点**：将扫描到的规范整理为以下维度，作为代码生成的约束：
   - **目录规范**：代码文件应放在哪个目录下（如公用方法放 `common`、工具类放 `utils`、业务逻辑放 `service`、配置放 `config`/`resources`）
   - **命名规范**：类名、方法名、变量名的命名风格（camelCase、snake_case、PascalCase）
   - **代码分层**：controller 层避免过多业务逻辑、SQL 通过配置文件管理不嵌入代码
   - **依赖管理**：新增依赖需同步更新打包部署文件
   - **代码复用**：重复逻辑提取为公共方法
   - **方法长度**：方法代码行数控制（如 50 行以内），复杂逻辑需拆分

4. **规范冲突处理**：
   - 若项目规范与本 skill 默认建议冲突，**以项目规范为准**
   - 若项目无明确规范，则按 `reference/languages.md` 中该语言的通用最佳实践执行

### 4. 获取接口文档（三级回退，必读）

获取接口文档时**必须**按以下优先级逐级回退，确保在网络不稳定时仍能正常工作：

```
优先级 1：在线抓取 doc_url → 成功则使用
优先级 2：读取本地缓存 local_doc → 文件存在则使用
优先级 3：请用户提供文档 → 用户粘贴正文或提供新 URL
```

#### 4.1 第一级：在线抓取（优先）

- 文档来源可以是：**catalog 中的 `doc_url`**，或 **用户在 §2 中提供的官方/自建文档 URL**。对 **URL**：统一先做一次"快速抓取"，目标是**直接拿到接口页主体内容**（避免工具长时间探索整个站点）。  
- 该文档站点页面通常包含 `editormd`/`markdown-article-inner` 等标记；主体内容一般在 HTML 的：
  - `<article class="markdown-article-inner"> ... </article>`（优先）
  - 或 `id="page-content"` 所在区域

**推荐的快速提取法（适用于 Mindoc/EditorMD 风格页面）**

1. 使用 Agent 的 WebFetch 能力抓取 `doc_url` 页面，获取 HTML 内容
2. 从 HTML 中**只提取** `<article ...markdown-article-inner...>` 的内部 HTML（剔除目录 TOC，如 `markdown-toc` div），再做 HTML→Markdown 的轻量转换
3. 只要先拿到"接口名称、请求方法、路径、参数表、示例、返回字段"，就可以开始生成代码；无需完整还原页面样式
4. **在线抓取成功** → 直接使用抓取内容，跳过第二级和第三级

**备选命令行方式**（仅当 Agent 无 WebFetch 能力时使用）：

1. 用命令行先确认可访问（返回 200）：`curl -I <doc_url>`
2. 获取 HTML：`curl -L <doc_url>`
3. 再按上述步骤 2-3 提取主体内容

#### 4.2 第二级：本地缓存回退

若在线抓取失败（网络超时、连接拒绝、登录/动态渲染/反爬等），**立即**回退到本地缓存：

1. 从 `api-catalog.yaml` 中该 API 条目读取 `local_doc` 字段（如 `docs/files_saas-1ebob0j33h3ed.md`）。
2. 以 `doc/` 目录为基准，拼接 `local_doc` 路径，读取本地 Markdown 文件。
3. 本地 Markdown 已是从 HTML 转换后的格式，包含完整的接口参数表、请求示例、返回示例等，可直接读取使用。
4. **本地文件存在且可读** → 使用本地缓存内容，跳过第三级。
5. **本地文件不存在** → 进入第三级。

**本地缓存说明**：
- `doc/docs/` 目录包含从文档门户预下载并转换为 Markdown 的全部接口文档（161 个文件）。
- `doc/docs/manifest.json` 记录了下载时间、每个 API 的 `doc_url` 与本地文件的映射关系。
- 可通过 `doc/download_docs.py` 脚本重新下载或更新本地缓存（自动将 HTML 转换为 Markdown）。
- 本地缓存可能不是最新版本；若用户反馈文档内容过时，应优先尝试在线抓取。

#### 4.3 第三级：请用户提供

若在线抓取失败且本地无缓存，**必须**请用户提供文档材料：

1. **明确告知**：在线文档抓取失败，本地也无该接口的缓存文档。
2. 请用户任选其一提供材料：
   - **接口文档正文**（可粘贴）：须至少包含测试/生产 **请求 URL**、参数表或请求示例、返回说明（能支撑签名与 HTTP 即可）；  
   - **接口文档地址**：用户给出的 **URL** → 按 §4.1「快速提取法」**重新尝试抓取**（用户提供的 URL 可能指向不同的文档站点）。
3. 用户仅提供模糊需求且无法补齐文档时：**停止生成**，保持对话直到材料足够。

页面内出现的关联链接（如公共参数）按需再抓取；优先抓取与当前接口**直接相关**的链接，避免全站爬取。

**实测提示（减少探索时间）**  

- 该站点 `doc_url` 页面往往**未显式标注 HTTP 方法**，但请求示例为 JSON；默认按 **`POST` + `Content-Type: application/json; charset=utf-8`** 实现，若接口页另有说明则覆盖。
- 请求示例中的 `sign` 通常是示例值；生成代码时应当**忽略示例 sign**并按 `reference/signing.md` 实时计算。
- 若接口参数说明包含"**至少送一个**"这类约束（例如：`agent_apply_no、merch_no 至少送一个`），生成代码时必须做**显式校验**并给出清晰错误提示，避免请求发出后才失败。
  - 若同一业务存在**微信/支付宝等多渠道的"业务申请"接口**，其必填字段通常不同（例如：微信 `settle_id`，支付宝 `mcc`/`business_id`）。生成代码时应：
    - 为不同渠道生成**独立的 payload builder / 配置键**（例如 `wx_*`、`ali_*`），避免字段混用；
    - 依据文档参数表的 `M/O`（必传/非必传）做必填校验，并在报错中明确缺失的字段名。
  - Windows 终端可能不是 UTF-8，导致中文报错乱码；生成代码时建议在 README 加提示（如 `chcp 65001` 或 `PYTHONUTF8=1`），且异常信息至少包含 `field_name` 等可读的 ASCII 关键字，便于定位。
  - 文档标题可能出现**多余空格**（例如 `请求  URL:`），仅用 `grep 请求URL` 可能漏检；提取测试地址时可搜 **`测试环境`**、`<a href="http://47.`** 或页面内 **第一个业务路径型 URL**。
  - 参数表 **可空列均为 O**，但说明里写 **「二选一」**（如 `apply_no` 与 `business_code`）时，应按说明做 **OR 校验**，不能误以为都可省略。
  - 部分接口请求 JSON 使用 **camelCase** 或与 `agent_no` 并存的 **`agentNo`** 等字段名；**必须与文档示例完全一致**后再参与签名（签名按 key 字典序拼接，大小写敏感）。
  - 页面 **概要描述** 偶发与真实接口不符（复制错误）；以 **请求 URL + 参数表 + 请求示例** 为准；若 YAML 目录缺项，可抓取门户首页 HTML 搜索中文接口名得到 `doc_url`，并将条目**补回** `doc/api-catalog.yaml`（保持 skill 自洽）。
  - **`api-catalog.yaml` 未收录**时：下载文档门户首页 HTML（如 `doc_portal_base`），用标题关键词检索 `<a ... title="...">` 定位 `doc_url`；勿凭接口中文名猜路径。
  - **整页 HTML 常为一超长行**：`rg`/`grep` 在部分环境可能对「超长行」匹配不稳定；可搜 **URL 路径片段**（如 `trade/limit`、`query-merchant-product`），或对已保存的 HTML 用脚本/`read_file` 局部查看。
  - **`accessid` 并非所有接口必传**：`accessid` 主要用于在平台侧获取 `accesskey`，而非所有接口的必传参数。若接口文档参数表中包含 `accessid`，则按文档要求传入并参与签名；若文档中无此字段，则无需配置和传入。生成代码时**以接口文档的参数表 M/O 标注为准**，但请求示例中包含的字段即使参数表未列出也应传入（参数表偶有遗漏，请求示例是实际可用的参考）。**签名只需 `accesskey`**，`accessid` 仅当接口文档要求时才作为请求参数参与签名。**但生成 Demo/测试代码时，若请求示例中出现 `accessid`，则 Demo 参数中也必须包含该字段（使用示例中的值），不得因"非必传"而自行省略。**
  - **签名计算顺序至关重要**：必须先组装业务参数（按文档参数表）→ 计算签名 → 放入 `sign`。若 `sign` 提前放入参数字典，签名必然失败。
  - **嵌套对象中的空值字段必须递归过滤**：如 `merchant_data.ledger_receive_flag=""`、`product_data.wx.mcc=""` 等字段，签名时必须跳过。Java 的 `SignUtils.getToBeSign()` 已实现递归过滤；其他语言实现时也必须对嵌套 dict/object 做同样的空值过滤。
  - **部分页面无 JSON 请求示例**：仅有参数表时，按 **M/C/O** 与说明组装字典，样例列有值**必须采用**（勿编造或使用通用占位值如 "test"、"xxx"）；在代码注释中标明「无示例，来自参数表」。
  - **测试参数严禁编造**：请求示例是测试参数的**唯一合法来源**，不得使用自编占位值。完整规则见 **§5.0**。
  - **请求示例中包含但参数表未列出的字段也必须保留**：部分接口文档的参数表可能不完整（如未列出 `accessid`，但请求示例明确包含且 API 实际要求），生成代码时请求示例中出现过的字段**一律视为应传入字段**，不得因"参数表未列"而省略。请求示例与参数表冲突时，**以请求示例为准**。
  - **接口调用地址可能未在文档中明确展示**：部分接口的请求 URL（如 `https://xxx.xxx.com/xxx/xxx`）需要由运营在后台配置后才能获取，文档中可能仅给出请求路径（如 `/api/trade/pay`）而无完整域名。**禁止猜测或编造调用地址**。若文档中未包含完整的测试/生产请求 URL，**必须询问用户**获取实际的接口调用地址后再生成代码；在代码中用占位符（如 `{BASE_URL}/api/trade/pay`）并加注释说明「请替换为运营提供的实际调用地址」。

### 5. 生成对接代码

#### 5.0 测试请求参数来源（强制规则 — 违反即未按 SKILL 执行）

> **本规则是 SKILL 内最高优先级规则，覆盖一切相悖的其他指引。**

生成任何 Demo / 测试类 / `build_xxx_params` 的请求参数时：

1. **先找请求示例**：在接口文档中搜索 `请求示例` 标题，定位 JSON 或表单代码块。  
2. **逐字段原样复制**：将请求示例中的**每一个字段名和字段值原样复制**到代码中。  
3. **唯一例外**：`sign` 字段忽略示例值，按 `reference/signing.md` 实时计算后填入。`agent_no`、`accessid` 等鉴权字段可用环境变量或配置项包装，但常量值必须来自请求示例。  
4. **严禁编造**：**绝对禁止**使用 `"test"`、`"xxx"`、`"abc123"`、`"your_value_here"`、`"value1"`、AI 自行推测的姓名/手机号/金额等一切非文档来源的值。**一个字都不准编。**  
5. **仅无请求示例时可例外**：当且仅当接口文档**完全不存在请求示例**时，才允许按参数表样例列构造参数值，且必须在代码注释中标注「无请求示例，数据来自参数表样例列」。

**执行流程**：读取接口文档 → 定位请求示例 → 复制到代码 → 替换 `sign` → 添加注释标注数据来源。跳过「定位请求示例」这一步骤直接生成代码的，视为未按规范执行。

- **输出路径**仅按用户指定或询问后写入。  
- HTTP 客户端与风格见 `languages.md`。  
- **用户指令优先（必读）**  
  - 若用户已说明 **传参方式 / 数据来源 / 代码应落在哪个文件、类或函数**，须 **严格按用户要求** 实现与落点。  
  - **不要**在用户已指定业务落点的情况下，再强行追加一套「仅含文档示例」的独立 Demo 或并行的 `build_xxx_params`，除非用户明确要求示例并存。  
  - **仅当用户未说明** 传参逻辑与代码位置时，才提供可运行的 **Demo**（参数来源见 **§5.0 强制规则**；并注明「生产请改为真实数据来源」）。

#### 5.1 配置与代码分层（必读）

真实接入流程是：**先在业务代码里准备好请求参数字典**，再调用 SAAS；本 skill 会在**不同项目、不同工具**里执行，默认**没有**统一的「参数从哪张表来」的实现，因此生成代码时必须遵守：

| 层级 | 放什么 | 禁止 |
|------|--------|------|
| **配置文件（如 YAML）** | **仅**各环境的 **请求 URL**（可按接口分键，如 `query_merchant_info_url`）。**注意**：部分接口的调用地址需由运营配置，文档中可能无完整 URL；此时配置文件中放占位符（如 `https://{BASE_URL}/api/xxx`），并加注释说明「请替换为运营提供的实际调用地址」 | 不要把 `merch_no`、门店信息、费率等业务字段写进「接口配置文件」；**禁止猜测或编造调用地址** |
| **鉴权** | `accesskey`（签名必需）、`agent_no` 等：按目标工程使用 **环境变量 / 密钥管理 / 独立凭据文件**（勿提交真实密钥）；`accessid` 仅当接口文档要求时才配置，主要用于在平台侧获取 `accesskey`；跨工具可复制示例名如 `SAAS_ACCESSKEY`、`SAAS_AGENT_NO`、`SAAS_ACCESSID`（可选） | 与大量业务键混在同一份「万能 YAML」里 |
| **公用封装** | **一个**「给定 URL + `accesskey` + 业务参数字典（**不含** `sign`）→ 按 `reference/signing.md` 计算 `sign` → `POST application/json; charset=utf-8`」的方法/类，全项目复用 | 每个接口各写一套散落的签名 + HTTP 拼接（除非用户项目已有统一客户端，则接入该客户端） |
| **业务层** | 用户在提示词中指定的模块/函数内组装参数；未指定时再由 Agent 在合理位置实现或落 Demo | 与用户指定的文件路径、命名或调用链冲突 |
| **Demo（可选）** | **仅当用户未说明传参逻辑与落点**：可提供 `build_xxx_params`（参数来源见 **§5.0**）+ `main`/脚本入口，便于工具内快速验证签名与 HTTP | 用户已指定落点时仍默认再生成一套「仅示例」的并行入口（除非用户要） |

**交付形态建议**  

- **用户已指定**传参与代码位置：只改/只增用户要求处，并接上既有或新建的 **公用签名 + POST**；若用户说复用项目里已有 HTTP 客户端，则**不要**再新建一套并行封装。  
- **用户未指定**：公用封装 +（可选）文档示例 **`build_xxx_params`**（参数来源见 **§5.0**）+ 简短可运行入口。

#### 5.2 accesskey 与联调

- `accesskey` 是签名计算的**必需凭据**，一般在服务商入网成功后下发，也可通过 **`agent_no`** 在平台侧查询/获取。
- `accessid` 主要用于在平台侧获取 `accesskey`，并非所有接口的必传参数。仅当接口文档参数表中包含 `accessid` 时，才需将其作为请求参数传入并参与签名。
- 生成代码时：**优先**用环境变量或项目既有密钥模块存放 `accesskey`，**不要**把它和业务参数堆在同一配置文件中。`accessid` 仅在接口文档要求时才配置。
- 若用户仅有 `agent_no`：提示向平台补全 `accesskey` 后再联调，避免在文档站无意义翻找。
- **签名工具类落盘规则（必守）**  
  - **Java**：将本 skill 内 [`doc/SignUtils.java`](doc/SignUtils.java)**原样复制**到用户项目**工具类所在包路径**下（仅修改 `package` 与必要时类名以符合项目规范）；补全 `pom.xml` / `build.gradle` 中 **net.sf.json（json-lib，注意需指定 `jdk15` classifier）**、**commons-codec** 等与该类 import 一致的依赖。  
  - **非 Java**：**不得**直接复制 `SignUtils.java`。须阅读 [`doc/SignUtils.java`](doc/SignUtils.java) 与 [`reference/signing.md`](reference/signing.md)，将**同等逻辑**用目标语言实现后，写入用户项目约定的 **utils / helpers / common** 等目录（与项目现有工具类组织方式一致）；并用 `signing.md` §5 golden examples 做自测。  
- **签名语义**始终以 [`reference/signing.md`](reference/signing.md) 为准；与平台单接口文档冲突时以接口文档为准。  
- 生成物须可编译、可测，勿留未解析依赖。

**Java 签名调用模板（必读，防止签名错误）**

生成 Java 对接代码时，签名调用**必须**遵循以下模板，避免常见签名错误：

```java
// 1. 组装业务参数（不要包含 sign 字段，按文档参数表组装）
Map<String, Object> params = new HashMap<>();
params.put("agent_no", agentNo);
params.put("agent_apply_no", applyNo);
// ... 其他业务参数（按文档参数表 M/O 标注添加）
// 若文档参数表包含 accessid，则添加（accessid 主要用于获取 accesskey，非所有接口必传）：
// params.put("accessid", accessId);

// 2. 计算签名（只需 accesskey，SignUtils 会自动过滤 sign/mac 和空值）
String sign = SignUtils.signParams(accessKey, params);

// 3. 将 sign 放入请求体
params.put("sign", sign);

// 4. 发送请求
String response = httpClient.post(url, JSONObject.fromObject(params).toString());
```

**关键注意事项**：
- **签名只需 `accesskey`**：`accesskey` 是签名计算的必需凭据；`accessid` 主要用于获取 `accesskey`，仅当接口文档要求时才作为请求参数参与签名
- **步骤 3 必须在步骤 2 之后**：`sign` 字段不能参与签名计算
- **嵌套对象中的空值字段会自动被过滤**：如 `product_data.wx.mcc=""` 不会出现在签名串中
- **不要使用 `JSONObject` 直接遍历拼接**：`JSONObject` 键序不确定，必须通过 `SignUtils.getToBeSign()` 转为 `TreeMap` 后拼接

### 5.5 语法检查与规范校验（生成代码后必须执行）

代码生成完成后，**必须**进行以下检查，确保代码可正常运行且符合项目规范：

1. **语法检查**：
   - **Java**：检查 import 是否完整、类型是否匹配、方法签名是否正确、异常处理是否完善
   - **Python**：检查缩进是否一致、import 是否完整、类型注解是否正确

2. **项目规范一致性校验**（基于 §3.5 学习到的规范）：
   - 代码文件是否放在正确的目录下（公用方法 → `common`，工具类 → `utils`，业务逻辑 → `service`，配置 → `config`/`resources`）
   - 命名风格是否与项目一致（类名、方法名、变量名）
   - 方法长度是否在限制内（如 50 行以内），超长方法需拆分
   - controller 层是否避免了过多业务逻辑
   - SQL 语句是否通过配置文件管理，而非直接嵌入代码
   - 新增依赖是否已同步更新到打包部署文件
   - 是否存在重复逻辑应提取为公共方法

3. **签名逻辑校验**：
   - 签名实现是否与 `reference/signing.md` 一致
   - 是否正确过滤了 `sign`/`mac` 字段和空值
   - 嵌套参数展开规则是否正确（对照 golden examples）
   - 密钥拼接方式是否与接口文档要求一致（直接拼接 vs `&key=` 前缀）
   - **Java 特有检查**：
     - 是否使用了 `SignUtils.signParams()` 而非自行拼接签名串
     - `accessid` 仅在接口文档要求时才传入和参与签名，非文档要求时不应强行添加；`accesskey` 是签名必需凭据
     - `sign` 字段是否在签名计算**之后**才放入参数 Map
     - 嵌套对象中的空值字段（如 `mcc=""`）是否被递归过滤
     - `pom.xml` 中 json-lib 是否指定了 `jdk15` classifier
     - 是否编写了 golden examples 单元测试（见 `signing.md` §8.2）
     - Demo/测试参数是否符合 **§5.0 强制规则**（来自请求示例，非编造）

4. **依赖完整性检查**：
   - 新增的第三方库是否已在项目依赖文件中声明（`pom.xml`、`requirements.txt`、`go.mod`、`package.json` 等）
   - 是否存在未解析的 import 或引用

5. **问题处理**：
   - 发现语法错误 → 立即修复后重新检查
   - 发现规范不一致 → 调整代码以符合项目规范
   - 发现签名逻辑问题 → 对照 `reference/signing.md` 修正

### 6. 清理临时文件（生成后必须执行）

- 若为"抓文档→生成代码"过程创建了临时文件（如 `*.html`、`*_doc.html`、抓取缓存、解析中间产物），在代码生成完成后应**自动删除**，避免污染用户工程与提交历史。  
- 仅保留：最终对接代码、配置模板、必要的单元测试（如签名 golden tests）与简短 README。

## 详细参考

- [`reference/languages.md`](reference/languages.md)  
- [`reference/signing.md`](reference/signing.md)  
- [`reference/api-index.md`](reference/api-index.md)  
- [`doc/README.md`](doc/README.md)  

## 安装到各工具

复制整个 **`hk-saas-api`** 文件夹（含 `doc/`、`doc/docs/`、`reference/`、`SKILL.md`）到对应 skills 目录。缺少 `doc/api-catalog.yaml`、`doc/docs/`（本地文档缓存）、`doc/SignUtils.java`（Java 直拷用）或 `reference/signing.md` 则本 skill 不完整。

可通过 `doc/download_docs.py` 脚本重新下载或更新本地接口文档缓存（需网络连接到文档门户，**仅当环境中安装了 Python 时可用**）。

### 7. 更新接口文档（`/hk-update` 命令）

用户使用 **`/hk-update`** 命令时，按以下流程更新本地接口文档缓存。

**重要**：本 skill 支持 Java/Python/Go/TypeScript/C# 等多语言环境，**不能假设运行环境已安装 Python**。更新操作必须通过 Agent 自身能力（WebFetch 抓取页面 + 文件写入）完成，而非调用 Python 脚本。

**命令格式**：

```
/hk-update                    # 更新全部接口文档
/hk-update {接口名称}         # 按接口名称模糊匹配，仅更新匹配的接口
```

**示例**：

```
/hk-update                    # 更新全部 161 个接口文档
/hk-update 预下单             # 更新"预下单"接口文档
/hk-update 商户入网           # 更新所有包含"商户入网"的接口文档
/hk-update pre-pay            # 按英文标识（local_doc 文件名）匹配
```

**执行步骤**（由 Agent 直接执行，不依赖 Python）：

1. **解析过滤条件**：从命令参数中提取接口名称关键词（支持中文名称和英文标识模糊匹配）
2. **匹配接口**：读取 `doc/api-catalog.yaml`，遍历所有 `scenarios[].apis[]`，对 `name`（中文名称）和 `local_doc`（英文标识文件名）做模糊匹配
3. **在线抓取**：对匹配到的每个接口，使用 Agent 的 WebFetch 能力从 `doc_url` 抓取文档页面 HTML
4. **提取主体内容**：从 HTML 中提取 `<article class="markdown-article-inner">` 区域的内容，剔除 TOC 目录（`markdown-toc` div），转换为 Markdown 格式
5. **保存到本地**：将 Markdown 内容写入 `doc/{local_doc}` 指定的文件路径（如 `doc/docs/pre-pay.md`），已有文件直接覆盖
6. **更新清单**：更新 `doc/docs/manifest.json` 中对应条目的下载时间和状态
7. **输出结果**：报告成功/失败数量，失败的接口输出名称和 URL

**HTML 提取规则**（与 `doc/download_docs.py` 一致）：

- 定位 `<article class="markdown-article-inner">` 标签，提取其内部 HTML
- 若无此标签，尝试 `<article id="page-content">`
- 剔除 `<div class="markdown-toc">` 目录导航区域
- 剔除 `<script>` 和 `<style>` 标签
- 将清理后的 HTML 转换为 Markdown 格式（保留表格、代码块、链接等结构）
- 合并多余空行（3 个以上连续空行合并为 2 个）

**备选方案**：若环境中安装了 Python 及 `yaml`、`markdownify` 依赖，也可直接运行脚本：

```bash
python doc/download_docs.py 预下单 订单查询    # 按名称过滤
python doc/download_docs.py                    # 更新全部
```

但**不得将此脚本作为唯一更新方式**，Agent 必须能独立完成更新操作。
