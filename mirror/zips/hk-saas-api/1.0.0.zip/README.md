# SAAS 平台接口对接 Skill（hk-saas-api）

基于结构化 YAML 接口目录与签名规范，为 SAAS / 海科聚合等机构侧 API 自动生成多语言对接代码（HTTP 客户端 + 请求签名 + 验签）。

## 目录结构

```
hk-saas-api/
├── SKILL.md                    # Skill 主流程定义（触发条件、工作流、代码生成规范）
├── README.md                   # 本文件
├── doc/
│   ├── README.md               # doc/ 目录说明
│   ├── api-catalog.yaml        # 接口场景与在线文档 URL（唯一结构化目录）
│   ├── SignUtils.java          # Java 签名工具类（可直接复制到 Java 工程）
│   ├── download_docs.py        # 本地文档缓存下载/更新脚本（支持增量更新）
│   └── docs/                   # 本地接口文档缓存（161 个 Markdown 文件 + manifest.json）
└── reference/
    ├── api-index.md             # 业务场景 id 与人类可读索引
    ├── languages.md             # 多语言检测信号与 HTTP 栈建议
    └── signing.md               # Sign 算法规范、速查表、Golden Examples
```

## 覆盖的业务场景

`api-catalog.yaml` 收录 **24 个业务场景、150+ 接口**，涵盖：

| 场景 | 说明 |
|------|------|
| 文件上传 | 人脸库 ID 查询、图片/视频上传 |
| 商户入网 | 入网申请、各渠道业务申请、申请单通知/查询 |
| 商户信息变更 | 入网修改、结算卡修改/查询、费率变更、门店新增 |
| 商户查询与通知 | 产品费率查询、名称查询、额度查询、结算/退汇通知 |
| 终端绑定 | 终端绑定/解绑/查询、云音响播报、归属查询 |
| 实名认证 | 微信/支付宝申请单、审核、认证状态 |
| 微信公众号 | 公众号配置及查询 |
| 电签签章 | 协议签约、结果查询、重新签约通知 |
| 流程工单 | 工单申请与状态查询 |
| 提现 | 当日提现、提现查询、手提、余额查询 |
| A/T/U 支付 | 预下单、付款码支付、订单查询/关闭、退款、异步通知 |
| 用户标识获取 | 银联云闪付、微信 openid、刷脸凭证 |
| 银行卡支付 | 交易查询、消费/撤销/退货通知 |
| 数字货币 | 被扫支付、订单查询、退款 |
| 扫码预授权 | 预授权开通/申请/完成/撤销 |
| 营销活动 | 微信/支付宝官方优惠、服务商营销活动 |
| 微信卡券 | 代金券发放/查询、核销通知、退款/核销明细 |
| 分账 | 分账开通/创建/查询/修改/退回、延迟分账 |
| 终端管理 | 参数下载、激活、签到、二维码、ICCID、卡 BIN |
| 发票管理 | 企业查询、发票申请/查询/撤销/重发 |
| 风控管理 | 风险案例查询/提交/推送、调单推送/查询/提交 |
| 投诉处理 | 支付宝/微信投诉列表/详情/提交/回复/推送 |
| 国际业务 | 国际商户入网、消费/预授权/撤销/DCC/退货 |
| 退款手续费 | 退款手续费预算 |

## 签名算法

默认签名规则（对应 `reference/signing.md`）：

1. 过滤掉 `sign`、`mac` 字段及空值
2. 剩余参数按**参数名字典序**排列
3. 拼接为 `key1=value1&key2=value2&...`（嵌套对象/数组按规则递归展开）
4. 在拼接串末尾**直接追加** `accesskey`（无 `&key=` 前缀）
5. 对 UTF-8 字节做 **MD5**，输出 **32 位十六进制大写**

```
待签串 = "a=1&b=c=2&d=3"
签名串 = 待签串 + accesskey
sign  = MD5(签名串).toUpperCase()
```

> 部分通道使用 `&key=accesskey` 前缀或 SHA-256 摘要，仅当接口文档明确要求时采用。

## 支持的语言

| 语言 | 检测信号 | 推荐 HTTP 栈 |
|------|----------|-------------|
| Java | `pom.xml`、`build.gradle*` | `java.net.http.HttpClient`、OkHttp、Spring `RestTemplate` |
| Python | `pyproject.toml`、`requirements.txt` | `httpx`、`requests` |

## 使用方式

### 生成对接代码

在 Trae IDE 中输入 `/hk-api` 或描述对接需求，例如：

```
/hk-api 用 Python 对接商户入网申请接口
/hk-api 帮我生成微信业务申请的 Java 对接代码
```

Skill 将按以下流程执行：

1. **场景检测** — 从 `api-catalog.yaml` 匹配业务场景
2. **接口检测** — 在场景下匹配具体接口，未命中时引导用户提供文档
3. **语言检测** — 根据用户指定或项目信号推断目标语言
4. **项目规范学习** — 扫描项目结构与规范文件，确保代码风格一致
5. **获取接口文档** — 三级回退：在线抓取 `doc_url` → 读取本地缓存 `local_doc` → 请用户提供
6. **生成对接代码** — 按分层规范生成签名工具 + HTTP 客户端 + 业务调用
7. **语法检查与规范校验** — 确保代码可编译、签名逻辑正确

### 更新接口文档

在 Trae IDE 中输入 `/hk-update` 更新本地接口文档缓存：

```
/hk-update                    # 更新全部接口文档
/hk-update 预下单             # 按接口名称模糊匹配，仅更新匹配的接口
/hk-update pre-pay            # 按英文标识匹配，仅更新匹配的接口
/hk-update 商户入网           # 按接口名称模糊匹配，更新所有入网相关接口
```

更新流程：
1. 从 `api-catalog.yaml` 中匹配目标接口
2. 在线抓取 `doc_url` 获取最新文档
3. 转换为 Markdown 并覆盖本地缓存文件
4. 更新 `manifest.json` 中的下载时间

也可直接运行脚本：

```bash
python doc/download_docs.py                          # 更新全部
python doc/download_docs.py 预下单 订单查询           # 按名称过滤更新
```

## 代码分层规范

| 层级 | 放什么 | 禁止 |
|------|--------|------|
| 配置文件 | 仅各环境的请求 URL | 不放业务字段 |
| 鉴权 | `accesskey`（签名必需）/ `agent_no` 放环境变量或密钥管理；`accessid` 仅当接口文档要求时配置（主要用于获取 accesskey） | 与业务参数混在同一配置 |
| 公用封装 | 一个「参数字典 + accesskey → 签名 → POST JSON」方法 | 每个接口各写一套签名 |
| 业务层 | 用户指定模块内组装参数 | 与用户指定落点冲突 |
| Demo | 仅当用户未指定时提供可运行示例 | 用户已指定时强加并行入口 |

## Java 签名工具类

`doc/SignUtils.java` 提供 Java 项目可直接复制的签名实现：

- **`signParams(accesskey, params)`** — 默认签名：待签串 + accesskey → MD5 大写
- **`signParamsAddKey(accesskey, params)`** — 通道签名：待签串 + `&key=` + accesskey → MD5 大写
- **`getXinyuanfuSign(params, agentKey)`** — 新悦付通道：忽略大小写排序 + `key=` + SHA-256 大写

依赖：`net.sf.json`（json-lib）、`commons-codec`

> 非 Java 项目：根据 `SignUtils.java` + `signing.md` 用目标语言重写等价逻辑，勿直接复制 `.java` 文件。

## 安装到其他工具

复制整个 `hk-saas-api` 文件夹（含 `doc/`、`doc/docs/`、`reference/`、`SKILL.md`）到对应 skills 目录即可。缺少 `api-catalog.yaml`、`docs/`（本地文档缓存）、`SignUtils.java` 或 `signing.md` 则功能不完整。

可通过 `doc/download_docs.py` 脚本重新下载或更新本地接口文档缓存（需 Python 环境）。若未安装 Python，可通过 `/hk-update` 命令由 Agent 直接完成更新。
