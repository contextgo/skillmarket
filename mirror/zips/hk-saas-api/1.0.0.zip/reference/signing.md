# SAAS 机构对接 Sign 规范（Skill 整理版）

本页是历史「签名说明」条文的**结构化重写**：实现时以本文为准；与个别接口页冲突时以**该接口官方文档**为准。

## 1. 用途

- 机构与 SAAS 平台之间**请求 / 响应**均可使用同一套 sign 规则。  
- 平台可能**新增字段**；验签逻辑必须按「参与排序的键值」动态计算，**禁止写死字段白名单**。

## 2. 规则速查

| 项目 | 要求 |
|------|------|
| 参与签名的键 | 除 `sign` 外全部非空参数；与常见 Java 实现对齐时同时排除 `mac` |
| 空值 | 键或值为空（null、空串等）**不参与** |
| 排序 | 参数名 **字典序（字母序）** |
| 单层拼接 | `k1=v1&k2=v2&...` |
| 嵌套结构 | 对象 / 数组按平台给定规则展开为子串后，再参与上层 `name=value`（见 §4） |
| accesskey | 拼在第 1 步得到串的**末尾直接拼接**，**无** `&key=` 前缀 |
| 摘要 | **MD5**，**32 位十六进制大写**，待签串编码 **UTF-8** |

## 3. 算法步骤

1. 过滤：去掉 `sign`、（可选）`mac`、空值项。  
2. 将剩余参数按**参数名**升序排列。  
3. 对每个参数生成 `name=value`：`value` 为标量则直接 `toString`；为对象 / 数组则先按 §4 变为**单一路径字符串**再作为 value。  
4. 用 `&` 连接所有 `name=value`，得到串 `S`。  
5. 计算 `S + accesskey`（accesskey 紧跟在 `S` 后面）。  
6. 对整段 UTF-8 字节做 MD5，转十六进制并 **转大写**，即为 `sign`。

## 4. 嵌套参数（与官方示例一致）

- **对象**：对内部键排序后，按与顶层相同规则拼成子串；作为外层字段的 `value`（见官方示例 b）。  
- **数组**：每个元素按序展开；元素为对象的按对象规则；多个元素之间用 `&` 衔接（见官方示例 c、d、e）。  
- 具体边界情况以平台说明中的 a)–e) **golden string** 自测对齐为准。

## 5. Golden examples（自测用）

待签串 **不含** accesskey；表中为步骤 4 得到的 `S`。

| 编号 | 输入要点 | 拼接结果 `S` |
|------|-----------|--------------|
| a | `version=1.0.0`, `return_code=0` | `return_code=0&version=1.0.0` |
| b | `a=1`, `b={d:3,c:2}` | `a=1&b=c=2&d=3` |
| c | `a=1`, `b=[{d:3,c:2},{d:5,c:4}]` | `a=1&b=c=2&d=3&c=4&d=5` |
| d | `a=1`, `b=["2","3"]` | `a=1&b=2&3` |
| e | `a=1`, `b` 为二维对象数组（见原说明） | `a=1&b=c1=2&d1=1&c2=4&d2=3&c3=6&d3=5&c4=8&d4=7` |

accesskey 示例：`S = return_code=0&version=1.0.0`，key=`123456789ABCDEF` → 待 MD5 串为  
`return_code=0&version=1.0.0123456789ABCDEF`。

## 6. 其它变体

部分通道使用 `&key=<accesskey>` 再 MD5（等价于 `signParamsAddKey` 一类命名）。**仅当当前接口文档明确要求时**采用；默认机构对接采用 **§3步骤 5 直接拼接 accesskey**。

## 7. 任意语言实现要点

1. 使用语言内置或标准库的 **UTF-8** 与 **MD5**；输出十六进制**大写**。  
2. Map 结构若无序，必须先按键排序再拼接。  
3. JSON 解析后需区分**对象 / 数组 / 标量**，递归或迭代展开规则与 §4、§5 一致。  
4. 建议为 §5 表格编写单元测试，通过后再对接真实环境。

**工程化提示（来自对接实测）**

- 文档页里的 `sign` 多为示例值；实现时以实时计算的 `sign` 为准。
- **嵌套对象中的空值字段必须递归过滤**：如 `merchant_data.ledger_receive_flag=""`、`product_data.wx.mcc=""` 等空字符串字段，在签名拼接时必须跳过，否则签名串会多出 `ledger_receive_flag=&` 导致签名不匹配。过滤规则与顶层一致：值为 `null`、空字符串、`JSONNull` 的键值对均不参与签名。
- **`accessid` 的签名规则**：`accessid` 主要用于在平台侧获取 `accesskey`，并非所有接口的必传参数。**签名只需 `accesskey`**。若接口文档的请求示例或参数表中包含 `accessid`，则签名时需将其纳入参数字典；若文档中未出现 `accessid`，则无需配置和传入。生成代码时应以接口文档的参数表 M/O 标注为准。
- **签名计算顺序**：先组装完整业务参数（按文档参数表）→ 计算签名 → 将 `sign` 放入请求体。**禁止**在签名计算前就把 `sign` 字段放入参数字典。

## 8. Java：随包提供的参考实现

本 skill 在 [`doc/SignUtils.java`](../doc/SignUtils.java) 中提供**可直接复制**的 Java 工具类（修改 `package` 后放到用户项目的工具包下）。行为与本文 §3–§5 默认规则一致；依赖主要为 **net.sf.json**、**commons-codec**（见文件头注释）。

### 8.1 Java 签名常见坑（实测总结）

以下问题在实际对接中频繁出现，生成 Java 代码时**必须**避免：

| 坑 | 说明 | 正确做法 |
|----|------|----------|
| **JSONObject 键序不确定** | `net.sf.json.JSONObject` 内部使用 `HashMap`，迭代顺序不固定；直接遍历拼接会导致每次签名结果不同 | 必须先转为 `TreeMap` 再拼接，`SignUtils.getToBeSign(JSONObject)` 已做此处理 |
| **JSONNull 未过滤** | JSON 反序列化时，缺失字段可能被解析为 `net.sf.json.JSONNull` 实例而非 `null`；仅判断 `== null` 会漏掉 | 使用 `SignUtils.isNullOrEmpty()` 判断，该方法同时处理 `null`、`JSONNull`、空字符串 |
| **嵌套对象空值未递归过滤** | 如 `merchant_data.ledger_receive_flag=""`、`product_data.wx.mcc=""`，仅过滤顶层空值不够 | `SignUtils.getToBeSign(Map)` 对嵌套 `JSONObject` 递归调用自身，内层空值同样被过滤 |
| **accessid 未按文档要求参与签名** | `accessid` 主要用于获取 `accesskey`，仅当接口文档参数表或请求示例中包含时才需传入参与签名 | 若接口文档参数表或请求示例中包含 `accessid`，签名前需将其放入参数 Map；若文档中无此字段则无需配置和传入 |
| **Map 类型使用 raw Map** | `SignUtils` 方法签名使用 `Map`（raw type），传入 `Map<String, Object>` 时需注意类型安全 | 传入 `new HashMap<String, Object>()` 或 `new JSONObject()` 均可，内部统一按 `Map` 处理 |
| **json-lib 依赖缺失** | `SignUtils.java` 依赖 `net.sf.json`（json-lib）和 `commons-codec`，Maven 中 json-lib 需指定 JDK15 classifier | `pom.xml` 中添加：`<dependency><groupId>net.sf.json-lib</groupId><artifactId>json-lib</artifactId><version>2.4</version><classifier>jdk15</classifier></dependency>` 和 `<dependency><groupId>commons-codec</groupId><artifactId>commons-codec</artifactId><version>1.15</version></dependency>` |
| **先放 sign 再签名** | 将 `sign` 字段先放入 Map 再调 `signParams`，导致 sign 参与签名计算 | `signParams` 内部会自动过滤 `sign` 字段，但最佳实践是签名前不要放入 `sign` |

### 8.2 Java 签名验证步骤

复制 `SignUtils.java` 到项目后，**必须**编写以下单元测试验证签名正确性：

```java
// 使用 §5 golden examples 验证
@Test
public void testGoldenA() {
    Map<String, Object> params = new HashMap<>();
    params.put("version", "1.0.0");
    params.put("return_code", "0");
    String sign = SignUtils.signParams("123456789ABCDEF", params);
    assertEquals("AC58F7A8575958A2D0E212461701B371", sign);
}

@Test
public void testGoldenB() {
    JSONObject b = new JSONObject();
    b.put("d", "3");
    b.put("c", "2");
    Map<String, Object> params = new HashMap<>();
    params.put("a", "1");
    params.put("b", b);
    String toBeSign = SignUtils.getToBeSign(params);
    assertEquals("a=1&b=c=2&d=3", toBeSign);
}

// 验证空值过滤
@Test
public void testEmptyValueFiltered() {
    Map<String, Object> params = new HashMap<>();
    params.put("agent_no", "11010200097");
    params.put("mcc", "");           // 空字符串，应被过滤
    params.put("ledger_receive_flag", null); // null，应被过滤
    String toBeSign = SignUtils.getToBeSign(params);
    assertEquals("agent_no=11010200097", toBeSign);
}

// 验证嵌套对象中的空值也被过滤
@Test
public void testNestedEmptyValueFiltered() {
    JSONObject wx = new JSONObject();
    wx.put("channel_no", "222970902d");
    wx.put("mcc", "");          // 嵌套对象中的空值，应被过滤
    wx.put("settle_id", "770");
    Map<String, Object> params = new HashMap<>();
    params.put("product_data", wx);
    String toBeSign = SignUtils.getToBeSign(params);
    assertEquals("product_data=channel_no=222970902d&settle_id=770", toBeSign);
}
```

## 9. 非 Java 语言

将 `SignUtils.java` 中的递归拼接与 `signParams` 流程**翻译**为目标语言后写入用户项目的工具模块，并以 §5 表格做单元测试对齐；勿把 `.java` 文件拷进非 Java 工程。

### 9.1 Python 实现要点

- 使用 `sorted(params.items())` 保证字典序（Python dict 3.7+ 虽然有序但不排序）
- 嵌套 `dict` 递归展开时，内层也要 `sorted`
- 空值过滤：`v is None or v == ""`
- MD5：`hashlib.md5(sign_str.encode("utf-8")).hexdigest().upper()`
- 参考实现见 `test/saas/sign_utils.py`
