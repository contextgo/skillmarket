# 目标语言：检测信号与默认技术栈

签名算法与语言无关，见 [signing.md](signing.md)（含 golden examples）。

## 优先级

1. 用户在提示词中**明确写出**语言或运行时（如「用 Go 写」「TypeScript」）→ 直接使用，无需再猜。  
2. 否则按下方**仓库文件信号**推断；多信号冲突时，以**用户当前打开文件 / 最近编辑文件**扩展名为辅证。  
3. 仍不确定 → 用 **AskQuestion** 或对话列出常见选项让用户选；也可接受用户自由输入（如 `Elixir`、`Dart`）。

## 常见语言：检测信号与 HTTP 客户端建议

| 语言 | 典型检测信号 | 生成对接代码时优先对齐的 HTTP 栈 |
|------|----------------|----------------------------------|
| Java | `pom.xml`、`build.gradle*` | `java.net.http.HttpClient`、OkHttp、Spring `RestTemplate` / `WebClient` |
| Python | `pyproject.toml`、`requirements.txt`、`setup.cfg` | `httpx`、`requests` |

## 其它语言

未列入表时：**向用户确认**官方推荐的 HTTP 客户端或项目已有依赖，再生成；签名仍按 `signing.md`用该语言标准库或常用加密库实现 **MD5 + 十六进制大写 + UTF-8 待签串**。

## 生成代码时的统一要求

- 与**当前项目**已有风格一致（命名、目录、异步/同步、错误处理）。  
- **配置文件只放请求 URL**（按环境切换）；`accesskey`（签名必需）/ `agent_no` 等放环境变量或密钥系统；`accessid` 仅当接口文档要求时配置（主要用于获取 accesskey）；**业务请求字段**在代码里由业务逻辑组装，勿塞进「接口 YAML」。
- 提供**一层公用封装**：参数字典（无 `sign`）+ `accesskey` + URL → 计算签名并 POST JSON。  
- **Demo**：仅当用户**未说明**传参逻辑与代码落点时，再为各接口提供文档示例型 Demo；若用户已指定落点与数据来源，**优先按用户要求**实现，勿额外强加示例脚本（除非用户明确要求）。  
- 嵌套参数参与签名的展开规则必须与 [signing.md](signing.md) §4–§5 一致；拿不准时用该节表格做单元测试对齐。

## 签名工具类放置（与 SKILL §5 一致）

| 目标语言 | 做法 |
|----------|------|
| **Java** | 复制 skill 内 [`doc/SignUtils.java`](../doc/SignUtils.java) 到当前项目的工具类包，改 `package`，补 Maven/Gradle 依赖。 |
| **其它** | 勿复制 `.java`；根据 `SignUtils.java` + [signing.md](signing.md) 用该语言重写等价逻辑，放入项目约定的 utils 目录。 |
