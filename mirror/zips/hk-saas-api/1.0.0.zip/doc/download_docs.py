import yaml
import urllib.request
import os
import re
import time
import json
import sys
from markdownify import markdownify as md

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOG_PATH = os.path.join(SCRIPT_DIR, 'api-catalog.yaml')
DOCS_DIR = os.path.join(SCRIPT_DIR, 'docs')
MANIFEST_PATH = os.path.join(DOCS_DIR, 'manifest.json')

os.makedirs(DOCS_DIR, exist_ok=True)

with open(CATALOG_PATH, 'r', encoding='utf-8') as f:
    catalog = yaml.safe_load(f)

def extract_article_html(html):
    start_pattern = re.compile(r'<article[^>]*class="[^"]*markdown-article-inner[^"]*"[^>]*>', re.IGNORECASE)
    m = start_pattern.search(html)
    if not m:
        m = re.search(r'<article[^>]*id="page-content"[^>]*>', html, re.IGNORECASE)
    if not m:
        toc_div = re.search(r'<div[^>]*class="[^"]*markdown-toc[^"]*"[^>]*>', html, re.IGNORECASE)
        if toc_div:
            article_start = html.find('<article', toc_div.end())
            if article_start != -1:
                m = re.search(r'<article[^>]*>', html[article_start:])
                if m:
                    m = type('M', (), {'start': lambda self: article_start + m.start(), 'end': lambda self: article_start + m.end()})()
    if not m:
        return html

    start_pos = m.end()
    depth = 1
    pos = start_pos
    while depth > 0 and pos < len(html):
        open_tag = html.find('<article', pos)
        close_tag = html.find('</article', pos)
        if close_tag == -1:
            break
        if open_tag != -1 and open_tag < close_tag:
            depth += 1
            pos = open_tag + 7
        else:
            depth -= 1
            if depth == 0:
                return html[m.start():close_tag + len('</article>')]
            pos = close_tag + 9
    return html[m.start():]

def html_to_markdown(article_html):
    toc_pattern = re.compile(r'<div[^>]*class="[^"]*markdown-toc[^"]*"[^>]*>.*?</div>', re.IGNORECASE | re.DOTALL)
    cleaned = toc_pattern.sub('', article_html)
    markdown = md(cleaned, heading_style='ATX', strip=['script', 'style'])
    markdown = re.sub(r'\n{3,}', '\n\n', markdown)
    return markdown.strip()

def download_api(sid, api, idx=None, total=None):
    name = api.get('name', 'unknown')
    doc_url = api.get('doc_url', '')
    local_doc = api.get('local_doc', '')

    if not doc_url:
        prefix = f"[{idx}/{total}] " if idx else ""
        print(f"{prefix}SKIP (no doc_url): {sid}/{name}")
        return None

    if not local_doc:
        url_slug = doc_url.rstrip('/').split('/')[-1]
        filename = f"{sid}_{url_slug}.md"
        local_doc = f"docs/{filename}"
        api['local_doc'] = local_doc

    filename = os.path.basename(local_doc)
    filepath = os.path.join(DOCS_DIR, filename)

    prefix = f"[{idx}/{total}] " if idx and total else ""
    print(f"{prefix}Downloading: {name} ({doc_url})")

    for attempt in range(3):
        try:
            req = urllib.request.Request(doc_url, headers={'User-Agent': 'Mozilla/5.0'})
            resp = urllib.request.urlopen(req, timeout=30)
            html = resp.read().decode('utf-8')
            article_html = extract_article_html(html)
            markdown = html_to_markdown(article_html)

            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(markdown)

            print(f"  -> OK ({len(markdown)} chars)")
            return {
                'filename': filename,
                'doc_url': doc_url,
                'scenario_id': sid,
                'api_name': name,
                'id_hint': api.get('id_hint', ''),
                'note': api.get('note', ''),
                'status': 'ok'
            }
        except Exception as e:
            if attempt < 2:
                print(f"  -> Retry {attempt+1}/2: {e}")
                time.sleep(2)
            else:
                print(f"  -> FAILED: {e}")
                return {
                    'filename': filename,
                    'doc_url': doc_url,
                    'scenario_id': sid,
                    'api_name': name,
                    'id_hint': api.get('id_hint', ''),
                    'note': api.get('note', ''),
                    'status': 'failed',
                    'error': str(e)
                }
    time.sleep(0.3)

filter_names = [n.strip() for n in sys.argv[1:] if n.strip()] if len(sys.argv) > 1 else []

all_apis = []
for scenario in catalog.get('scenarios', []):
    sid = scenario.get('id', 'unknown')
    for api in scenario.get('apis', []):
        name = api.get('name', '')
        if filter_names:
            matched = any(fn.lower() in name.lower() or fn.lower() in api.get('local_doc', '').lower() for fn in filter_names)
            if not matched:
                continue
        all_apis.append((sid, api))

total = len(all_apis)
success = 0
failed = []
manifest_apis = {}

if filter_names:
    print(f"Filter: {filter_names}")
print(f"APIs to download: {total}")

for idx, (sid, api) in enumerate(all_apis, 1):
    result = download_api(sid, api, idx, total)
    if result:
        manifest_apis[f"{sid}/{api.get('name', '')}"] = result
        if result['status'] == 'ok':
            success += 1
        else:
            failed.append((sid, api.get('name', ''), api.get('doc_url', ''), result.get('error', '')))
    time.sleep(0.3)

if os.path.exists(MANIFEST_PATH):
    with open(MANIFEST_PATH, 'r', encoding='utf-8') as f:
        existing_manifest = json.load(f)
else:
    existing_manifest = {"download_time": "", "apis": {}, "total": 0, "success": 0, "failed_count": 0}

existing_manifest['apis'].update(manifest_apis)
existing_manifest['download_time'] = time.strftime('%Y-%m-%d %H:%M:%S')
total_all = sum(len(s.get('apis', [])) for s in catalog.get('scenarios', []))
existing_manifest['total'] = total_all
existing_manifest['success'] = sum(1 for v in existing_manifest['apis'].values() if v.get('status') == 'ok')
existing_manifest['failed_count'] = sum(1 for v in existing_manifest['apis'].values() if v.get('status') == 'failed')

with open(MANIFEST_PATH, 'w', encoding='utf-8') as f:
    json.dump(existing_manifest, f, ensure_ascii=False, indent=2)

with open(CATALOG_PATH, 'w', encoding='utf-8') as f:
    yaml.dump(catalog, f, allow_unicode=True, default_flow_style=False, sort_keys=False, width=120)

print(f"\nDone: {success}/{total} succeeded, {len(failed)} failed")
if failed:
    print("\n===== FAILED APIS =====")
    print(f"{'接口名称':<30} {'URL'}")
    print("-" * 80)
    for sid, name, url, err in failed:
        print(f"{name:<30} {url}")
        print(f"  Error: {err}")
    print(f"\nTotal failed: {len(failed)}")
