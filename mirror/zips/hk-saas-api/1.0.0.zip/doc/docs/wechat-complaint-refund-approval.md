## 微信-更新退款审批结果

### 基本信息

**Path：** /api/v1/complaint/wechat/updateRefundProgress

**Method：** POST

**接口描述：**

### 备注

### 请求参数

**Headers**

| 参数名称 | 参数值 | 是否必须 |
| --- | --- | --- |
| Content-Type | application/json | 是 |

**Body**

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| complaintId | string | 必须 |  | 投诉单号 |  |
| action | string | 必须 |  | 审批动作 REJECT: 拒绝退款 APPROVE: 同意退款 |  |
| launchRefundDay | number | 非必须 |  | 预计发起退款时间 在同意退款时返回，预计将在多少个工作日内能发起退款, 0代表当天 |  |
| rejectReason | string | 非必须 |  | 拒绝退款原因 |  |
| rejectMediaList | string [] | 非必须 |  | 拒绝退款的举证图片列表 在拒绝退款时，如果有拒绝的图片举证，可以提供 最多上传4张图片, 传入调用“商户上传反馈图片”接口返回的media\_id，最多上传4张图片凭证 | item 类型:  string |
| remark | string | 非必须 |  | 任何需要向微信支付客服反馈的信息 |  |

### 请求示例

```
{
  "accessid": "4028803d6a97099f016a9b3d8f57000f",
  "signKey": "fa907d6e05cc4869a3330add779e9ff7",
  ...
}
```

### 返回数据

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| rspCode | string | 必须 |  | 返回码 |  |
| rspMsg | string | 必须 |  | 返回信息 |  |

文档更新时间: 2024-11-19 15:13   作者：胡闽川