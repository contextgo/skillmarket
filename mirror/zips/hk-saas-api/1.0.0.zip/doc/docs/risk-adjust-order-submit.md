#### 简要描述：

1、风控案例提交信息接口

#### 请求URL:

* 测试环境： <http://47.95.131.62:8080/api/v1/agent/risk/dispatch/commit>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| dispatchNum |  | String |  | 风险调单号 | O |
| accessid |  | String |  | 服务商标识 | O |
| operator |  | String |  | 操作人 | O |
| remark |  | String |  | 备注 | O |
| agentNum |  | String |  | 所属服务商编号 | O |
| billInfoImgsStr |  | String |  | 商户名称 | O |
| tradeProImgsStr |  | String |  | 一级服务商名称 | O |
| tradeCardBackImgsStr |  | String |  | 交易卡背面 | O |
| tradeCardFrontImgsStr |  | String |  | 交易卡正面 | O |
| certificateFrontImgsStr |  | String |  | 身份证正面 | O |
| certificateBackImgsStr |  | String |  | 身份证反面 | O |

#### 请求示例:

```
{
   "caseNo": "20230511155524394956750290100",
   "operator": "张三",
   "surveyWay":"DHDC" ,
  "surveyRemark":"已核实清楚，没有风险问题" ,
  "businessPlacesStr":"77cf1a60f951357417057f80750,77cf1a60f95145741705780750",
  "businessLicensesStr":"77cf1a60fbb357417057f80750,77cf1a60f95741705780750",
  "headSignsStr":"77cf1a60f95140557417057f80750,77cf1a60f95140b3505780750",
  "idCardsStr":"77cf1a60f95140750,77cf1a60f95140705780750",
  "accessid": "4028805b6e86d179016e874f6c4200ad",
  "sign": "975077BFC098C592C721A3948A97460F"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| rspCode | 返回码 | int | 10000：成功 其他：失败 |  | M |
| rspMsg | 错误消息 | String | 申请成功 |  | O |

#### 返回示例:

```
{

    "return_code": 10000
}
```

文档更新时间: 2025-04-29 20:29   作者：张亚飞