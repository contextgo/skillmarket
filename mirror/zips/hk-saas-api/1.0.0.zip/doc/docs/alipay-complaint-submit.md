## 支付宝-提交投诉

### 基本信息

**Path：** /api/v1/complaint/ali/processFinish

**Method：** POST

**接口描述：**

### 请求参数

**Headers**

| 参数名称 | 参数值 | 是否必须 | 示例 | 备注 |
| --- | --- | --- | --- | --- |
| Content-Type | application/json | 是 |  |  |

**Body**

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| idList | string [] | 必须 |  | 投诉id列表 | item 类型: string |
| ├─ |  | 非必须 |  |  |  |
| processCode | string | 必须 |  | 投诉处理结果码 已联系到用户，协商一致，无异议: CONSENSUS\_WITH\_CLIENT 其他: ORTHER 不涉及退款，已针对投诉内容进行整改: RECTIFICATION\_NO\_REFUND 已退款，用户无异议: REFUND 已提交证明材料: SUBMIT\_PROOF\_NOT\_CONTACTED |  |
| remark | string | 非必须 |  | 备注 |  |
| imgFileList | JSONArray | 必须 |  | 图片文件列表 | item 类型: string |
| ├─ imgUrl | String | 非必须 |  | 图片url |  |
| ├─ imgUrlKey | String | 非必须 |  | 图片文件key |  |

### 请求示例

```
{
    "accessid": "4028803d6a97099f016a9b3d8f57000f",
    "sign": "3B13E5343E42A6D1153A216EEFA5496F",
    "idList": [
        "1212121",
        "23232323"
    ],
    "processCode": "CONSENSUS_WITH_CLIENT ",
    "imgFileList": [
        {
            "imgUrlKey": "121212"
        },
        {
            "imgUrlKey": "22323212"
        }
    ]
}
```

### 返回示例

```
{
  "return_code": 10000
}
```

文档更新时间: 2025-06-30 15:26   作者：郝庚鑫