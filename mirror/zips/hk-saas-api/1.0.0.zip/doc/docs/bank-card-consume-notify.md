### **接口地址**

* 通知的地址为发起支付交易的时候上送的notify\_url

### **通知策略**

* 支付完成后，SaaS会把相关支付结果发送给商户，商户需要接收处理，并返回应答。对后台通知交互时，如果SaaS收到商户的应答不是成功或超时，SaaS认为通知失败，SaaS会通过一定的策略定期重新发起通知。尽可能提高通知的成功率，但不保证通知最终能成功。(通知频率为15/15/30/180/1800/1800/1800/1800/3600，单位：秒)

如果异步通知的状态与查询接口的返回存在不一致，以查询接口的返回为准。

### **请求参数(O-非必传 ,M-必传):**

* 请求参数为SaaS通知给第三方的内容

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| sign | 参数签名值 | String |  |  | M |
| tradeId | SaaS平台的交易订单编号 | String |  |  | M |
| merchNo | 商户编号 | String |  |  | M |
| pn | 终端编号 | String |  |  | M |
| sn | 终端sn号 | String |  |  | M |
| bankName | 发卡行 | String |  |  | M |
| acquiringBank | 收单行 | String |  |  | M |
| cardNo | 卡号 | String |  |  | M |
| expDate | 卡有效期 | String |  |  | O |
| batchNo | 批次号 | String |  |  | O |
| f11 | 凭证号 | String | 冲正交易时不存在 |  | O |
| f61 | 授权码 | String | POS消费时返回 |  | O |
| f38 | SAAS平台参考号 | String | POS消费时返回 |  | O |
| f22 | 原请求刷卡方式 | String | 冲正交易时不存在 具体参见银行卡支付附录。常用代码： 011-手输有密、 021-刷卡有密、 051-插卡有密、 071-挥卡有密、 012-手输无密、 022-刷卡无密、 052-插卡无密、 072-挥卡无密、 911-人脸支付 |  | O |
| tradeBeginTime | 交易开始时间 | String |  |  | M |
| tradeEndTime | 交易完成时间 | String |  |  | M |
| amount | 交易金额（单位：元） | String |  |  | M |
| settleAmount | 交易结算金额(单位：元) | String |  |  | M |
| bankIssno | 发卡行代码 | String |  |  | M |
| unionPayCode | 银联商户号 | String |  |  | M |
| unionRefNo | 银联参考号 | String | POS消费时返回，可用该参考号在银联端查询该订单 |  | O |
| unionTerminalSn | 银联终端号 | String |  |  | M |
| terminalTxNo | 终端流水号 | String |  |  | M |
| outTradeNo | 外部流水号 | String |  |  | O |
| tradeResult | 交易结果 | Integer | 1：成功 |  | M |
| relativeTradeId | 相关交易号 | String | 不为空时，消费交易：若交易成功，该参数是撤销交易号，若交易失败，该参数是对应的冲正交易号。撤销（冲正）交易：该参数是原消费交易号。 |  | O |
| fee | 手续费（单位：元） | String | （v1.01增加） | 1.00 | O |
| cardType | 卡类型 | String | 01-借记卡；02-贷记卡；03-准贷记卡；04-预付费卡（v1.01增加） | 01 | O |
| payMode | 支付方式 | String | (v1.0.3修改) CONSUME（消费）,  REVOKE（撤销）,  REFUND（退货）,  PREAUTH（预授权）,  PREAUTHUNDO（预授权撤销）,  PREAUTHFINISH（预授权完成）,  PREAUTHFINISHUNDO（预授权完成撤销）, | COMSUME | O |
| tradeType | 支付类型 | String | (v1.16增加)BANK |  | M |
| cardOrg | 卡组织(v1.44增加) | String | result为0时返回，卡组织 | 银联：UNION，运通：EXPRESS | O |
| currency | 币种(v1.44增加) | String | result为0时返回，币种 | 人民币卡：CNY，外卡：OUT | O |
| hkActivityId | 海科活动ID | String |  |  | O |
| real\_fee\_subsidy\_amount | 手续费实际补贴金额 | String |  |  | O |

### **返回参数说明:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result | 接收结果 | String | 接收成功后返回“SUCCESS” | SUCCESS | M |

### **返回示例:**

文档更新时间: 2026-04-23 09:42   作者：梁博