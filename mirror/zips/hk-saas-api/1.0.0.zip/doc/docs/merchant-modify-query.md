#### 概要描述:

* 商户入网审核通过信息修改结果查询接口

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/merchant-modify/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 服务商的编号，由SaaS平台分配，表示当前商户属于该服务商名下 | 88888888 | M |
| apply\_no | 商户入网修改申请单号 | String | 申请单号 | 2021030212090011 | M |

#### 请求示例:

```
{
    "agent_no": "11010200097",
    "apply_no": "2021030212090011",
    "accessid": "cpostest",
    "sign": "793F54D0E4B8E2D073BB76610003A5B0"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| apply\_no | SAAS平台修改申请单号，用于查询修改状态 | String | 2021030212090011 |  | return\_code:10000时必返 |
| accept\_status | 申请单状态 | String | audit 审核中,success 审核成功,fail 审核失败 |  | return\_code:10000时必返 |
| accept\_fail\_msg | 失败原因 | String | 失败原因 |  | accept\_status:fail时必返 |
| wx\_accept\_status | 微信审核状态 | String | 微信审核状态 |  | 修改简称并且已开通微信业务时必返 |
| wx\_fail\_msg | 微信审核失败原因 | String | 微信审核失败原因 |  | wx\_accept\_status:fail时必返 |
| ali\_accept\_status | 支付宝审核状态 | String | 支付宝审核状态 |  | 修改简称并且已开通支付宝业务时必返 |
| ali\_fail\_msg | 支付宝审核失败原因 | String | 支付宝审核失败原因 |  | ali\_accept\_status:fail时必返 |
| union\_accept\_status | 银联审核状态 | String | 银联审核状态 |  | 修改简称并且已开通银联业务时必返 |
| union\_fail\_msg | 银联审核失败原因 | String | 银联审核失败原因 |  | union\_accept\_status:fail时必返 |

#### 返回示例:

```
正确：
{
    "apply_no": "2021030212090011',
    "accept_status": "success',
    "wx_accept_status": "success',
    "ali_accept_status": "success',
    "union_accept_status": "success',
    "return_code": 10000,
    "sign": "F07B3E86B0502C96C5393F8C0B97322A"
}
错误：
{
    "return_code": 22004,
    "return_msg": "营业执照照片为空"
}
或者错误：
{
    "apply_no": "2021030212090011',
    "accept_status": "success',
    "wx_accept_status": "fail',
    "wx_fail_msg":"简称包含敏感字信息",
    "ali_accept_status": "success',
    "union_accept_status": "success',
    "return_code": 10000,
    "sign": "F07B3E86B0502C96C5393F8C0B97322A"

}
```

文档更新时间: 2025-06-26 11:32   作者：王金晶