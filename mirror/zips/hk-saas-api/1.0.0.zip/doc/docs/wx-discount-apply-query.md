#### 概要描述:

服务商可以通过该接口向微信支付提交高校食堂商户的优惠活动查询。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/wx-auth/activity-apply/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| agent\_apply\_no | 服务商申请单编号 | String |  |  | M |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "agent_apply_no": "11111111111",
    "sign": "36EE79FD2E36527F5A75D58E40C9FEC4"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| wx\_apply\_no | 微信申请单编号 | String |  |  | O |
| apply\_status | 申请状态 | String | 1-处理中，2-申请失败，3-申请成功 |  | O |
| reject\_parameter | 拒绝参数 | String |  |  | O |
| reject\_reason | 拒绝理由 | String |  |  | O |
| pass\_time | 审核时间 | String |  |  | O |

#### 返回示例:

```
{
    "wx_apply_no": "200323174241616939321401",
    "return_code": 10000,
    "apply_status": "3",
    "pass_time": "2021-04-07T10:29:35+08:00",
    "sign": "F354732C4886EC9001C2E9FF2E45870E"
}
```

文档更新时间: 2024-11-29 10:13   作者：admin