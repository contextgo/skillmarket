#### 概要描述:

只适用于调用SDK模式进行开发。  
微信刷脸，调用微信官网接口获取face\_code时，将authinfo替换为从海科接口获取的authinfo参数，然后用微信官网返回的face\_code调海科的被扫接口（auth\_code）完成交易.

微信官方:<https://pay.weixin.qq.com/wiki/doc/wxfacepay/develop/windows/faceuser.html#_3%E3%80%81%E8%8E%B7%E5%8F%96%E8%B0%83%E7%94%A8%E5%87%AD%E8%AF%81>

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/pay/wx/get-wxpayface-authinfo>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String | 海科平台商户编号 |  | M |
| store\_id | 门店编号 | String | 门店编号 |  | M |
| store\_name | 门店名称 | String | 门店名称 |  | M |
| device\_id | 终端编号 | String | 终端编号 |  | M |
| rawdata | 初始数据 | String | 初始数据 |  | M |
| sub\_appid | 子商户appid | String | 子商户appid |  | O |
| attach | 附加参数 | String | 附加参数 |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "merch_no": "83388888888",
    "store_name": "门店名称1",
    "device_id": "123456789",
    "rawdata": "0CSmor/Pp4vC7WE5CsJxet4Sg+D24C8eJxAMjjkBEl58hDLmofPunD+OX8v7JQyxUFmimUb9ai9cuPmGXC87MfStCOGaK/Fjb77DzF7nJgpwQhl8bdprPWKx6h04ZzPRQBlE6DAgcylr3CFSisWpMSUUmA9MtHAKD8fhzFeTEAgj0NK49DjIFZXczfZRgj8qUTRrajdJtO6gZMqlRgSwM83MP8xPG2lCO33nA5HsSMy/vh5ET5O3ubj+wpfMuD1fUj3HBy3YXxxGqFKjJV6dRwuMmAXnaTk0P0u3LSOWO7wiA6En/JgwVZvf9zkcCzq9OyJFrc+8QY6bQeuPWCe4E73n397jaD5fu8GqyokUlO/XytuYP2qcNWAol9vBpf3u2xWt/MobKjJcsDwsCxGFxtjWATRyU0fB9atI8GKGt9zxwWbMd0m6gleWWVGVOHxodNKJbWFP4rRKvPjG0nntZzX4SJ0q/7zevKzYQhU+F+q+ePvvgjKAcxnI5Jhaz/khkffQLw4YAaR7GuLZhHYeFPYEvzOXVk89+dJ/M7s1jZK4dtFa75U1Et9vn2bYtfourPpL3PA9oPPVVu2gPuq/S+WmBG6hCp0lq+/3P4png82cgLq6MNPhSwAq5YRqxlrHbfE3qk0qr/vXXSMbIOhfLWnKFdOyRv+3ohdQOC/8sdHbbSDcyQSprYZ+JREhz0W3qPKlHxlsbvSrpGNj9D4VxL4UXTnloq5KdwZoGSeBgvpNS5NPhXuU6u0cVMufUriKsxptftFu68cDzVv3hdu+1bYy/P9vffwSl01U2uJiTGErHqVMuILTNL==",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| authinfo | SDK调用凭证 | String | 用于调用SDK的人脸识别接口 |  | M |
| expires\_in | authinfo的有效时间 | String | authinfo的有效时间, 单位秒。 | 3600 | M |
| merch\_no | 海科商户编号 | String | 海科平台商户编号 |  | M |
| wxsub\_merch\_no | 微信商户编号 | String | 微信商户编号 |  | M |
| sub\_appid | 子商户appid | String | 子商户appid |  | O |

#### 返回示例:

```
{
    "merch_no": "83388888888",
    "wxsub_merch_no": "2370123456",
    "authinfo": "q3OPhFtQBf6KZGqmZhejKCRy5K/ch0kwS11YSsEj9XmUGqcsT2QPHt0Oa7xaCMCoSZTWMmShCo4dOiO5tU+OJEsvSxXzn5m3Nkh747tinNlbpJmVq1zOPj+FJNndkzanxoiAddO8p1EfrmUhJs/aNf0pDfrPoVfkAapK+ZY6blwyaDQ9bB7+KkZq29kObsXOZ3thg+bxP4RAqC0oxNS4JiyP0uA1Euzxtkc9lCTebloFied8stILrMehUKukeMGkZ1SzTyc8/HFHApzHahNPX6yD8ttzYnhe+IRMFJgpuTlIvEOYZUxenPXE1A5clrPvOBeJDszX/OvZl4fpYWPpXAcVQlw+gfYhblt+rT6ALMsD73w/rT4NRriQEEraC4Pfb5yua4qAqv4TVo04",
    "expires_in": "3600",
    "return_code": "10000",
    "return_msg": "成功",
    "sign": "1032A57E96E4048B27EC2A5C3CE5E663"
}
```

文档更新时间: 2024-12-05 18:02   作者：陈文