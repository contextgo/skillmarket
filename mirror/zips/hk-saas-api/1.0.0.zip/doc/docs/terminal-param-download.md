#### 简要描述：

* 该终端提前调拨至服务商之后，厂商可以调用此接口获取接入信息参数，加密方式为非对称秘钥加密算法,请求中加密数据使用公钥加密，返回的加密数据使用公钥解密。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/params-init/download>

#### 请求参数(O-非必传 ,M-必传):

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| sn | 厂商sn编号 | String | 加密后转成base64后的数据(银联认证终端必须上送tusn) | p111166668888 | M |
| firm | 厂商 | String |  |  | M |

#### 请求示例:

```
{    
    "sn": "base64(encrypt(sn))",
    "firm": "MF"
}
真实数据：
{
    "firm":"FJLDSB",
    "sn":"iNu5VEOfgnM1Yj7iw7Wozp2hzWzBP5QX3ceztg7YlKzmAbahDhDAUo4HKuSSy0CR6mhkO6cPJeyVz6koWzZrQ184Ul7nIjtd/eE7l1BnQMhqwaHJ67i31pKq6tHvGMJoil5aMqyVusubR0JRqBVQ3zXs3/IKTKKU1COL8ScRr2g\u003d"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 错误码 | int | 正常：10000；其他为异常 | 10000 | M |
| sysTime | 系统时间 | String | yyyy-MM-dd HH:mm:ss |  | M |
| return\_msg | 错误信息 | String |  |  | O |
| accessid | 接入机构标识 | String | 加密后转成base64后的数据 |  | M |
| accesskey | 接入机构秘钥 | String | 加密后转成base64后的数据 |  | M |
| transferkey | 传输秘钥 | String | 加密后转成base64后的数据 |  | M |
| agent\_no | 服务商编号 | String | 加密后转成base64后的数据 |  | M |

#### 返回示例:

```
{
    "return_code": 10000,
    "sysTime": "2020-05-18 14:34:12",
    "accessid": "base64(encrypt(accessid))",
    "accesskey": "base64(encrypt(accesskey))",
    "transferkey": "base64(encrypt(transferkey))",
    "agent_no": "base64(encrypt(agent_no))"
}
真实数据：
{
    "accessid":"pdWMxpUeCKooZ73CrxsNU8rL0ENw6/OPxgtj1wrB85HbFgRfuEzpGzvd2qRAKdU8VoSKFv5t2un+tS2gH5Vn+2I1FRs1K1WdePHRvbUmYX/UBcyLslz120qt3Znqy05lPSxMW8oRJvtaMls+i98qut+/pQHdWjrLBbehTsPC/oE=",
    "accesskey":"gAbINlkW/GDcNlHAFFymMqoqbCa2E1nSfeK01/MXHrvRa5LeY73XG5Esj9y7SBA+8jcGeVotBM+vccb18EepAvopVt+GbBMXt8ZXrsn4HgSRXoGxhSRjP7YyXzZJFoIx3Nk9/Zpb7BME3yTU2aihtyYPGz+ietnAZkYKWew0Nmk=",
    "transferkey":"nmd0rwyC9+T8pKe08Dh/gv/YW/lyxXPXLGw68mPYJSA2W/XkrIEx6Nvtjric+PhcNeWf1MIOlUdf8jnRJUpPfEMDMQ1d6uMQ2k7JmILoqyKrPwx4SqpQDbVR0IBr6f7nnVvnRyTxXQUsyqoN8qsgbbK0GSECp7D3IKGRegF16OU=",
    "agent_no":"NfyNF6zZ9jiUZyfPtOs8C5GaZlZPBJP18ydrkYb5DR0LJbUIVeqhYuhrl/lp7OblmwUcjZ0IdE7+ueEhT4KsNJUYxY/xzJt0iLHbwPFTXLptq/EChLj8H9NYbBtl8gBZHpSUdPAN+DdgNSeuUR3OJOUtmXDZRhtVvd/rLZohHao=",
    "return_code":10000
}
```

文档更新时间: 2024-11-29 10:15   作者：陈文