## 图片上传

### 基本信息

**Path：** /api/v1/complaint/upload

**Method：** POST

**接口描述：**

### 请求参数

**Headers**

| 参数名称 | 参数值 | 是否必须 | 示例 | 备注 |
| --- | --- | --- | --- | --- |
| Content-Type | application/json | 是 |  |  |

**Body**

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| file | string | 必须 |  | 文件Base64 |  |
| complaintId | string | 必须 |  | 投诉订单号 |  |
| channelName | string | 必须 |  | 通道名称 支付宝：alipay 微信：wechatpay |  |

### 请求示例

```
{
  "file": "/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAA...",
  "complaintId": "177454931",
  "channelName": "alipay",
  "accessid": "4028803d6a97099f016a9b3d8f57000f",
  "sign": "3B13E5343E42A6D1153A216EEFA5496F"
}
```

### 返回数据

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| fileName | string | 非必须 |  | 文件名 |  |
| fileKey | string | 非必须 |  | 文件key（支付宝） |  |
| fileUrl | string | 非必须 |  | 文件url（支付宝） |  |
| mediaId | string | 非必须 |  | 媒体文件标识Id（微信） |  |

### 返回示例

```
{
  "fileName": "wKg1a2c8JgSAbxPtAALXETC-_VI093.jpg",
  "fileKey": "A*OjQmQKZ5UsAAAAAAAAAAAAAADsJ2AA",
  "fileUrl": "http://mdn.alipayobjects.com/security_fraudmng/afts/img/A*OjQmQKZ5UsAAAAAAAAAAAAAADsJ2AA/original?t=aZOXJXHCarc1D03TYR9ZpzuuhPD-yQP3IsuNWP97JCUDAAAAZAAAdsIAAAAA",
  "mediaId": "",
  "return_code": 10000
}
```

文档更新时间: 2024-11-29 10:16   作者：郝庚鑫