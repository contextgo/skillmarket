#### 简要描述：

* 本接口调用成功只表示当前业务申请成功，对于业务最终是否开通成功需要通过“商户业务查询”接口查询来确定。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v2/merchant-bank-biz/apply>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 商户编号 | String |  |  | M |
| agent\_apply\_no | 服务商申请单号 | String | 服务商申请单号 |  | O |
| rate | 费率 | JSON | 费率单位：万分之一，例如费率为0.6,需要传60;手续费封顶单位：分;区间范围必须包括0-50000。 | {"bank\_debit\_rate":"38","bank\_debit\_max":"2000","bank\_credit\_rate":"40","union\_debit\_rate":"41","union\_debit\_max":"2000","union\_credit\_rate":"43","union\_mix\_rate":"44"} | M |
| notify\_url | 通知地址 | String | 商户业务审核状态变更后的通知地址 | <http://x.cn/shop/notice> | O |

##### 费率信息：rate (银行卡与银联二维码可以分组上传，例如bank\_debit\_rate,bank\_debit\_max,bank\_credit\_rate为一组)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| bank\_debit\_rate | 银行卡借记卡费率 | String |  | 例如费率为0.6,需要传60; | O |
| bank\_debit\_max | 银行卡借记卡手续费封顶 | String |  | 18元需要传1800 | O |
| bank\_credit\_rate | 银行卡贷记卡费率 | String |  | 例如费率为0.6,需要传60; | O |
| union\_debit\_rate | 银联二维码借记卡费率 | String |  | 例如费率为0.6,需要传60; | O |
| union\_debit\_max | 银联二维码借记卡手续费封顶 | String |  | 18元需要传1800 | O |
| union\_credit\_rate | 银联二维码贷记卡费率 | String |  | 例如费率为0.6,需要传60; | O |
| union\_mix\_rate | 银联二维码1000以下包括1000费率值 | String |  | 例如费率为0.6,需要传60; | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "merch_no": "833581758120002",
    "agent_apply_no": "451433356171",
    "notify_url": "http://x.cn/shop/notice",
    "rate": {
        "bank_debit_rate": "38",
        "bank_debit_max": "2000",
        "bank_credit_rate": "40",
        "union_debit_rate": "41",
        "union_debit_max": "2000",
        "union_credit_rate": "43",
        "union_mix_rate": "44"
    },
    "step_rate": {
        "bank_rate": [
            {
                "min_amt": 0,
                "max_amt": 10000000,
                "bank_debit_rate": "38",
                "bank_debit_max": "2000",
                "bank_credit_rate": "40"
            }
        ],
        "union_rate": [
            {
                "min_amt": 0,
                "max_amt": 1000.01,
                "union_mix_rate": "44",
                "union_debit_max": "1000"
            },
            {
                "min_amt": 1000.01,
                "max_amt": 10000000,
                "union_debit_rate": "41",
                "union_debit_max": "2000",
                "union_credit_rate": "43"
            }
        ]
    },
    "sign": "C562D118A1CC147D203B271D59615CE3"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| apply\_no | 申请单编号 | String |  |  | M |

#### 返回示例:

```
正确：
{
    "apply_no": "200323151012085188201041",
    "return_code": 10000,
    "sign": "E93B3A4E6C51D6AB1DA6989FF2A30C6A"
}
错误：
{
    "return_code": 23015,
    "return_msg": "费率与阶梯费率不能同时上传",
    "sign": "B91EF38C647904509FA28A121756B3A9"
}
```

文档更新时间: 2024-11-29 10:06   作者：王金晶