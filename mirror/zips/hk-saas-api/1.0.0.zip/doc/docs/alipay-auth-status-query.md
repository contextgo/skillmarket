#### 概要描述:

获取商家认证状态

* 注：使用海科pid的服务商必须调用该接口；使用自己主体pid的服务商，可以调用该接口或直接调用支付宝官方认证接口均可完成支付宝二次认证。  
  支付宝官方接口链接如下：<https://opendocs.alipay.com/open/03sqz8>

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/ali-auth/query-merchant-status>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |
| ali\_merch\_no | 支付宝商户编号 | String |  |  | M |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "merch_no": "83311010100002012",
    "ali_merch_no": "3677167941212169",
    "sign": "36EE79FD2E36527F5A75D58E40C9FEC4"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| authorize\_state | 授权状态 | String | 确认状态，枚举：已确认（AUTHORIZED）/未确认（UNAUTHORIZED）/已销户（CLOSED）/smid不存在（SMID\_NOT\_EXIST） |  | M |

#### 返回示例:

```
{
    "return_msg": "查询成功",
    "return_code": 10000,
    "authorize_state": "AUTHORIZED",
    "sign": "74D55ACA6A2698290542DF709BB966B2"
}
```

文档更新时间: 2024-11-29 10:08   作者：admin