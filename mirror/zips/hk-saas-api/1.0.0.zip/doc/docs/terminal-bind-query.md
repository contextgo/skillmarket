#### 简要描述：

* 通过该接口可查询终端绑定状态（已绑定：查询后返回pn、sn、merch\_no参数；已入库未绑定商户/操作终端解绑后：查询后返回pn、sn参数；）。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/merchant-terminal/new-query>

#### 请求参数(O-非必传 ,M-必传):

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| agent\_apply\_no | 服务商申请单号 | String |  |  | O |
| sn | 厂商sn编号 | String | 1、通过银联认证硬件终端必须上送tusn,未通过银联认证终端上送终端sn； 2、软件类或码牌需上送服务商系统内的终端唯一标识 | 88888888 | O |
| pn | SaaS终端编号 | String | 海科saas系统内的终端唯一标识，与sn一一对应; sn为空时此参数必传 |  | O |

#### 请求示例:

```
{    
    "accessid": "ckrykj",
    "agent_no": "11010200116",
    "sn": "0917080000002311",
    "pn": "A83456",
    "agent_apply_no": "11010500003521",
    "sign": "DA074B19207C4A00441D2197FBA6E826"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| pn | 海科系统序列号 | String | 海科系统终端唯一标识 | 1601120100000222 | M |
| sn | 厂商sn编号 | String | 终端机身sn/tusn | 5678776554 | M |
| merch\_no | SAAS平台商户编号 | String | 终端未绑定商户，此参数返回空 | 833885678776554 | O |
| yl\_report\_status | 银联业务开通状态 | String | 0、报备成功1、报备失败2、报备中3、未报备 |  | O |
| yl\_report\_msg | 银联业务响应消息 | String |  |  | O |
| ali\_report\_status | 支付宝业务开通状态 | String | 0、报备成功1、报备失败2、报备中3、未报备 |  | O |
| ali\_report\_msg | 支付宝业务响应消息 | String |  |  | O |
| wx\_report\_status | 微信业务开通状态 | String | 0、报备成功1、报备失败2、报备中3、未报备 |  | O |
| wx\_report\_msg | 微信业务响应消息 | String |  |  | O |

#### 返回示例:

```
{
    "pn": "S0000542",
    "sn": "1645976595896205312",
    "merch_no": "833290872300025",
    "report_result": {
        "yl_report_status": "3",
        "yl_report_msg": "请为商户开通银联业务",
        "ali_report_status": "3",
        "ali_report_msg": "请为商户开通支付宝业务",
        "wx_report_status": "0",
        "wx_report_msg": "成功"
    },
    "return_code": 10000,
    "sign": "62BBF801DB63BFAA2B650F8890B1A0DE"
}
```

文档更新时间: 2024-11-29 10:07   作者：王金晶