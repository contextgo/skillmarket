## 支付宝-投诉详情

### 基本信息

**Path：** /api/v1/complaint/wechat/detail

**Method：** POST

**接口描述：**

### 请求参数

**Headers**

| 参数名称 | 参数值 | 是否必须 | 示例 | 备注 |
| --- | --- | --- | --- | --- |
| Content-Type | application/json | 是 |  |  |

**Body**

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| complaintId | string | 必须 |  | 投诉订单号 |  |

### 请求示例

```
{
  "complaintId": "171231231",
  "accessid": "4028803d6a97099f016a9b3d8f57000f",
  "sign": "3B13E5343E42A6D1153A216EEFA5496F"
}
```

### 返回数据

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| transFirstLevelAgentNum | string | 非必须 |  | 交易一级服务商编号 |  |
| transFirstLevelAgentName | string | 非必须 |  | 交易一级服务商名称 |  |
| transAgentNum | string | 非必须 |  | 交易服务商编号 |  |
| transAgentName | string | 非必须 |  | 交易服务商名称 |  |
| transMercNum | string | 非必须 |  | 交易商户编号 |  |
| transMercName | string | 非必须 |  | 交易商户名称 |  |
| bussOrderNo | string | 非必须 |  | 业务交易订单号 |  |
| complaintId | string | 非必须 |  | 投诉单号 |  |
| complaintTime | string | 非必须 |  | 投诉时间 |  |
| complaintDetail | string | 非必须 |  | 投诉详情 |  |
| complaintState | string | 非必须 |  | 投诉单状态 PENDING-待处理 PROCESSING-处理中 PROCESSED-已处理完成 |  |
| complaintedMchid | string | 非必须 |  | 被诉商户号 |  |
| payerPhone | string | 非必须 |  | 投诉人联系方式 |  |
| transactionId | string | 非必须 |  | 微信订单号 |  |
| outTradeNo | string | 非必须 |  | 商户订单号 |  |
| amount | string | 非必须 |  | 订单金额，单位（分） |  |
| complaintFullRefunded | string | 非必须 |  | 投诉单是否已全额退款 |  |
| incomingUserResponse | string | 非必须 |  | 是否有待回复的用户留言 |  |
| userComplaintTimes | string | 非必须 |  | 用户投诉次数 |  |
| mediaType | string | 非必须 |  | 媒体文件业务类型 USER\_COMPLAINT\_IMAGE: 用户提交投诉时上传的图片凭证 OPERATION\_IMAGE: 用户、商户、微信支付客服在协商解决投诉时，上传的图片凭证 |  |
| mediaUrl | string | 非必须 |  | 媒体文件请求url |  |
| problemDescription | string | 非必须 |  | 问题描述 |  |
| problemType | string | 非必须 |  | 问题类型 REFUND: 申请退款 SERVICE\_NOT\_WORK: 服务权益未生效 OTHERS: 其他类型 |  |
| applyRefundAmount | string | 非必须 |  | 申请退款金额(单位:分) |  |
| userTagList | string | 非必须 |  | 用户标签列表 TRUSTED: 此类用户满足极速退款条件 HIGH\_RISK: 高风险投诉，请按照运营要求优先妥善处理 |  |
| orderId | string | 非必须 |  | 微信支付服务订单号 |  |
| outOrderNo | string | 非必须 |  | 商户服务订单号 |  |
| state | string | 非必须 |  | 支付分服务单状态 DOING: 服务订单进行中 REVOKED: 服务订单已取消 WAITPAY: 服务订单待支付 DONE: 服务订单已完成 |  |
| type | string | 非必须 |  | 补充信息类型 SHARE\_POWER\_TYPE: 充电宝投诉相关行业 |  |
| returnTime | string | 非必须 |  | 归还时间 |  |
| returnAddress | string | 非必须 |  | 归还地点 |  |
| longitude | string | 非必须 |  | 归还地点经度 |  |
| latitude | string | 非必须 |  | 归还地点纬度 |  |
| isReturnedToSameMachine | string | 非必须 |  | 是否归还同一柜机 |  |
| inPlatformService | string | 非必须 |  | 是否在平台协助中 |  |
| needImmediateService | string | 非必须 |  | 是否需即时服务用户 |  |
| payerOpenid | string | 非必须 |  | 投诉人OpenID |  |

### 返回示例

```

```

文档更新时间: 2024-12-03 11:08   作者：胡闽川