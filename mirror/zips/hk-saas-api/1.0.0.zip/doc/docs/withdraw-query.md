#### 概要描述:

提现查询接口

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/account/withdraw/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| apply\_no | 返回提现订单号 | String | 返回提现订单号（二选一上送，不可为空） |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |
| out\_apply\_no | 服务商申请单号 | String | 服务商生成订单号（二选一上送，不可为空） |  | M |
| settlement\_cycle | 结算方式 | String | DN：自助提现 MANAUL：手动提现 | 56 | M |

#### 请求示例:

```
{
    "merch_no": "833102158123961",
    out_apply_no": "432428409238402",
    "agent_apply_no": "4324332324424324",
    "accessid": "4028805b8353abde018353c1118d005d",
    "sign": "B320179AEACFA2E9E300875CE585B2FE"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| apply\_no | 提现申请单ID | String | 状态为10000时会返回（返回申请单号） |  | M |
| amount | 提现金额 | String | 提现金额（单位：元） |  | O |
| withdraw\_fee | 提现手续费 | String | 状态为10000时会返回 |  | O |
| real\_amount | 实际到账金额 | String | 状态为10000时会返回 |  | M |
| out\_apply\_no | 服务商申请单号 | String | 状态为10000时会返回 |  | O |
| success\_time | 发起申请时间 | String | 状态为10000时会返回，调用接口成功时间 |  | O |

#### 成功时返回示例:

```
{
    "return_code": 10000
    return_msg:''''''
    apply_no": 2026034234324324324
    amount:'''56'''
    "withdraw_fee": "1"
    real_amount:''''55''
    success_time:'''' 2026-03-11 11:11:11''
}
```

文档更新时间: 2026-03-23 15:33   作者：张亚飞