#### 概要描述:

收银员使用扫码设备读取用户数字钱包付款码以后，二维码或条码信息传送至商户收银台，由商户收银台或者商户后台调用该接口发起支付对用户进行收款。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/pay/digitalwallet/micropay>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String | 海科平台商户编号 |  | M |
| auth\_code | 支付授权码 | String | 支付授权码 |  | M |
| out\_trade\_no | 服务商支付订单号 | String | 服务商内部订单号（同一服务商下唯一） |  | M |
| total\_amount | 订单金额 | String | 订单总金额（单位：元） |  | M |
| pn | SAAS终端号 | String | SAAS终端号 |  | O |
| notify\_url | 异步通知地址 | String | 交易成功异步通知地址 |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "merch_no": "83388888888",
    "auth_code": "287667597892433290",
    "out_trade_no": "123456789",
    "total_amount": "1",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 响应码 | String | 10000代表成功 |  | M |
| return\_msg | 响应信息 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户编号 |  | M |
| out\_trade\_no | 服务商支付订单号 | String |  |  | M |
| trade\_no | 海科支付订单号 | String |  |  | M |
| trade\_status | 交易状态 | String | 1：交易成功 2：交易失败 3：交易进行中 4：交易超时 |  | M |
| error\_code | 错误码 | String |  |  | O |
| error\_msg | 错误消息 | String |  |  | O |

#### 返回示例:

```
{
    "merch_no": "83388888888",
    "out_trade_no": "123456789",
    "trade_no": "AL88888888",
    "trade_status": "1",
    "return_code": "10000",
    "return_msg": "成功",
    "sign": "1032A57E96E4048B27EC2A5C3CE5E663"
}
```

文档更新时间: 2024-11-29 10:11   作者：陈文