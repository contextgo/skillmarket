#### 简要描述：

* 在交易中涉及到终端编号的参数，均为“SaaS终端编号”。这个编号在“绑定终端”接口中会返回，但此编号有可能只存储在了第三方应用的服务器端，为了方便第三方应用终端的使用，可以在终端直接发起本查询，用终端厂商的终端编号查询得到“SaaS终端编号”。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/terminal/auth/queryterminalsn>

#### 请求参数(O-非必传 ,M-必传):

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| sn | 厂商sn编号 | String |  |  | M |

#### 请求示例:

```
{
    "accessid":"4028803d6a97099f016a9b3d8f57000f",
    "sign":"626DDECA65450C6CC3B2C26FF5F6A67D",
    "sn":"195GCA8C3803"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| pn | SaaS终端编号 | String |  | 1601120100000222 | M |
| merch\_no | 商户编号 | String |  | 88888888 | O |
| merch\_name | 商户名称 | String |  | 商户名称1 | O |
| merch\_short\_name | 商户简称 | String |  | 商户简称1（1.33版本新增） | O |
| shop\_name | 门店名称 | String |  | 门店名称1 | O |
| double\_excemption\_status | 双免标记（1.25版本新增） | String | 0启用 1禁用 | 1 | O |
| double\_excemption\_limit | 双免额度（1.25版本新增） | String | 单位(元) | 1000 | O |
| express\_channel\_merch\_no | 运通商户号 | String | 仅开通运通业务时有值 | 833100058888889-yt | O |
| express\_terminal\_no | 运通终端号 | String | 仅报备运通的终端有值 | MBNQQQJS | O |
| union\_merch\_no | 银联商户号 | String | 银联商户号 | 833100058888889 | O |
| union\_terminal\_no | 银联终端号 | String | 银联终端号 | MBNQQQJS | O |

#### 返回示例:

```
{
    "merch_no":"833110100000061",
    "merch_name":"测试账号",
    "merch_short_name":"测试账号简称",
    "shop_name":"测试小商户",
    "double_excemption_status":"1",
    "double_excemption_limit":"1000",
    "pn":"1002019070100089",
    "return_code":10000,
    "sign":"8C6E2DF627D774E2953E9E71AF5243A5"
}
```

文档更新时间: 2025-12-22 13:24   作者：admin