#### 简要描述：

1、调单推送接口

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| createTime | 创建时间 | String | yyyy-MM-dd HH:mm:ss |  | M |
| dispatchNum | 调单号 | String |  |  | M |
| bankFirstDate | 银行卡首发日 | String | yyyy-MM-dd |  | M |
| bankLastDate | 最后期限 | String | yyyy-MM-dd |  | M |
| orderId | 交易流水号 | String |  |  | M |
| bankMerchantNo | 银行商户号 | String |  |  | M |
| mercNum | 商户编号 | String |  |  | M |
| mercName | 商户名称 | String |  |  | M |
| firstLevelAgentNum | 一级服务商编号 | String |  |  | M |
| firstLevelAgentName | 一级服务商名称 | String |  |  | M |
| transTime | 交易开始时间 | String |  |  | M |
| transAmt | 持卡人发起金额 | String |  |  | M |
| actualPay | 持卡人实付金额 | String |  |  | M |
| isDoubleFree | 是否面签免密 | String |  | 是，否 | M |
| cardNo | 交易卡号 | String |  |  | M |
| issuerName | 发卡行 | String |  |  | M |
| dispatchAnnotation | 调单注释 | String |  |  | M |
| dispatchType | 调单类型 | String |  | “调单”，“查询” | M |
| dispatchStatus | 调单状态 | String |  | DCL：待处理  DSH：待审核 SHJJ：审核拒绝 SHTG：审核通过 | M |
| remark | 备注 | String |  |  | M |

#### 请求示例:

```
{
    "mercNum": "8331634891201",
    "typeNo": " T00038 ",
    "caseDealWay": " investigate ",
    "auditStatus": " DSH ",
    "description": " 1)如企业商户，请提供商户营业执照照片（营业执照必须真实，工商网可查）、经营场所照片及门头照等 ",
    "riskTypeName": " SR00048 ",
    "caseNo": "20230511155524394956750290100",
    "firstAgentNo": "ISV100001",    
    "firstAgentName": "张三有限公司",    
    "referOrders": "涉及交易流水号",    
}
```

文档更新时间: 2025-04-29 19:54   作者：张亚飞