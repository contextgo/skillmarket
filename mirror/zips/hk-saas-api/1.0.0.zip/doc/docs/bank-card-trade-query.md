# 交易查询

### **测试环境：**

<http://47.95.131.62:8080/api/v1/pay/bankcard/query>

### **请求参数(O-非必传 ,M-必传):**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| tradeId | SaaS平台的交易订单编号 | String | tradeId和outTradeNo 二选一上传查询,优先以tradeId查询 |  | O |
| outTradeNo | 外部流水号 | String | tradeId和outTradeNo 二选一上传查询,优先以tradeId查询 |  |  |

```
{
    "accessid":"cpostest",
    "sign":"FB5D71B7D9A000A39C37B96D6A35B95C",
    "tradeId":"BA200326154028900890524615"
}
```

### **返回参数说明:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| tradeId | 交易id | String | SaaS平台的交易订单编号 |  | M |
| merchNo | 商户编号 | String | (v1.0.2修改) |  | M |
| pn | 终端编号 | String | (v1.0.2修改) |  | M |
| bankName | 发卡行 | String |  |  | M |
| acquiringBank | 收单行 | String |  |  | M |
| cardNo | 卡号 | String |  |  | M |
| expDate | 卡有效期 | String |  |  | O |
| batchNo | 批次号 | String |  |  | O |
| f11 | 凭证号 | String | 冲正交易时不存在 |  | O |
| f61 | 授权码 | String | POS消费时返回 |  | O |
| f38 | SAAS平台参考号 | String | POS消费时返回 |  | O |
| f22 | 原请求刷卡方式 | String | 冲正交易时不存在 |  | O |
| tradeBeginTime | 交易开始时间 | String |  |  | M |
| tradeEndTime | 交易完成时间 | String |  |  | M |
| amount | 交易金额(单位：元) | String |  |  | M |
| fee | 交易手续费(单位：元) | String |  |  | M |
| settleAmount | 交易结算金额(单位：元) | String |  |  | M |
| bankIssno | 发卡行代码 | String |  |  | M |
| unionPayCode | 银联商户号 | String |  |  | M |
| unionRefNo | 银联参考号 | String | POS消费时返回，可用该参考号在银联端查询该订单 |  | O |
| unionTerminalSn | 银联终端号 | String |  |  | M |
| terminalTxNo | 终端流水号 | String |  |  | M |
| outTradeNo | 外部流水号 | String |  |  | O |
| tradeResult | 交易结果 | String | 1：成功,2：失败,3：进行中 |  | M |
| relativeTradeId | 相关交易号 | String | 不为空时，消费交易：若交易成功，该参数是撤销交易号，若交易失败，该参数是对应的冲正交易号。撤销（冲正）交易：该参数是原消费交易号。 |  | O |
| refundedAmount | 已退款金额 | String | 已退款金额(v1.30增加) |  | M |
| remanentAmount | 剩余可退款金额 | String | 剩余可退款金额(v1.30增加) |  | M |
| receiptImage | 小票签名图片（V1.41增加） | String | 通过小票上传接口上送的签名图片（base64） |  | O |
| cardOrg | 卡组织(v1.44增加) | String | result为0时返回，卡组织 | 银联：UNION，运通：EXPRESS | O |
| currency | 币种(v1.44增加) | String | result为0时返回，币种 | 人民币卡：CNY，外卡：OUT | O |

### **返回示例:**

```
{
    "tradeId":"BA200326154028900890524615",
    "merchNo":"88888888","pn":"M0000007",
    "bankName":"建设银行",
    "acquiringBank":"海科融通",
    "cardNo":"6217000010070258077",
    "f22":"071",
    "f11":"000032",
    "expDate":"2412",
    "batchNo":"000001",
    "f38":"615445297786",
    "tradeBeginTime":"2020-03-26 15:40:28",
    "amount":"0.01",
    "f61":"",
    "bankIssno":"01050000",
    "unionPayCode":"83311005462H003",
    "unionRefNo":"615401297786",
    "unionTerminalSn":"Q0066904",
    "terminalTxNo":"209345",
    "outTradeNo":"1585208338613",
    "tradeResult":1,
    "remanentAmount":"0.01",
    "refundedAmount":"0.00",
    "receiptImage":"""return_code":10000,
    "sign":"BEB98CB7E8BDF4330362B0A67E537893"
    }
```

文档更新时间: 2024-12-19 10:48   作者：梁博