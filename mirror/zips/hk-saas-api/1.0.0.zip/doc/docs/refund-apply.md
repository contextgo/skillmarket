#### 概要描述:

当交易发生之后一段时间内，由于买家或者卖家的原因需要退款时，卖家可以通过退款接口将支付款退还给买家，微信支付将在收到退款请求并且验证成功之后，按照退款规则将支付款按原路退到买家帐号上。

注意：  
1、交易时间超过90天的订单无法提交退款。  
2、退款支持单笔交易分多次退款，多次退款需要提交原支付订单订单号（服务商交易订单号、海科交易订单号二选一）和设置不同的退款单号。  
3、申请退款总金额不能超过订单金额。

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/api/v2/pay/refund>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String(32) | 海科商户编号 |  | M |
| out\_trade\_no | 服务商支付订单号 | String(32) | trade\_no、out\_trade\_no二选一上送,优选顺序：trade\_no、out\_trade\_no |  | C |
| trade\_no | 海科支付订单号 | String(32) | trade\_no、out\_trade\_no二选一上送,优选顺序：trade\_no、out\_trade\_no |  | C |
| out\_refund\_no | 服务商退款订单号 | String(32) | 服务商内部订单号（同一服务商下唯一） |  | M |
| refund\_amount | 退款金额 | String(12) | 退款金额（单位：元） |  | M |
| pn | SAAS终端号 | String(32) | SAAS终端号 |  | M |
| market\_subsidy\_biz | 营销补贴退款业务信息 | JSON | 营销补贴退款业务信息 |  | O |
| notify\_url | 异步通知地址 | String(128) | 交易成功异步通知地址 |  | O |
| remark | 备注 | String(100) | 交易备注 |  | O |
| extend\_params | 原生请求参数 | JSON | 原生参数，透传给通道的参数 |  | O |

##### 营销补贴退款业务信息:market\_subsidy\_biz

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| subsidy\_agent\_no | 营销补贴代理商编号 | String | 1、涉及到多营销主体补贴时该字段必填。 2、运营提供营销补贴代理商编号 |  | O |
| subsidy\_detail | 营销补贴详情 | JSONArray | 营销补贴详情 |  | M |

##### 营销补贴详情:subsidy\_detail

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| party | 营销补贴账户 | String | 在海科开通的营销补贴账户号 |  | M |
| amt | 营销补贴金额 | String | 营销补贴金额（单位：元） | 1 | M |

##### 云闪付原生请求参数:extend\_params

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| acqAddnData | 收款方附加数据 | JSON | 收款方附加数据 |  | O |

##### (银联二维码)收款方附加数据:acqAddnData

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| orderInfo | 订单信息 | JSON | 订单明细内容，如订单标 题、订单描述等 |  | O |
| goodsInfo | 商品信息 | JSONArray | 商品明细内容 |  | O |

##### (银联二维码)订单信息:orderInfo

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| title | 标题 | String | 标题 |  | M |
| description | 订单描述 | String | 订单描述 |  | O |
| dctAmount | 可优惠金额 | String | 当前订单可以参与优惠计算的金额 |  | O |
| addnInfo | 附加信息 | String | 内容自定义 |  | O |

##### (银联二维码)商品信息:goodsInfo

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| id | 标题 | String | 标题 |  | M |
| name | 商品名称 | String | 订单描述 |  | M |
| price | 商品单价 | String | 以分为单位 |  | M |
| quantity | 商品数量 | String | 商品数量 |  | M |
| category | 商品类目 | String | 商品类目 |  | O |
| addnInfo | 附加信息 | String | 附加信息 |  | O |

#### 请求示例:

```
{
    "agent_no": "IS88888888",
    "req_id": "147258369",
    "merch_no": "83388888888",
    "out_trade_no": "123456789",
    "out_refund_no": "R123456789",
    "pn": "WZ0009989",
    "refund_amount": "0.01",
    "market_subsidy_biz": {
        "subsidy_detail": [
            {
                "party": "A0001",
                "amt": "0.5"
            },
            {
                "party": "A0002",
                "amt": "0.6"
            }
        ],
        "subsidy_agent_no": "M0001"
    },
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表业务处理成功，交易结果需要根据trade\_status判断 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科商户编号 |  | M |
| out\_refund\_no | 服务商退款订单号 | String |  |  | M |
| refund\_no | 海科退款订单号 | String |  |  | M |
| refund\_amount | 退款金额 | String | 退款金额（单位：元） |  | M |
| pay\_type | 支付类型 | String | WX：微信支付 ALI：支付宝支付 UNIONQR：云闪付 |  | M |
| trade\_status | 交易状态 | String | 1：交易成功 2：交易失败 3：交易进行中 |  | M |
| attach | 通道原生参数 | String |  |  | O |

#### 返回示例:

```
{
    "result_msg": "请求成功",
    "out_refund_no": "440000199711151124",
    "refund_no": "WX240410170222000818227131",
    "trade_status": "1",
    "sign": "D2C61D2BD73DCEA50C6602116213CE1D",
    "refund_amount": "0.01",
    "agent_no": "FW3002100",
    "pay_type": "WX",
    "result_code": "10000",
    "return_msg": "成功",
    "attach": "{
        \"nonce_str\": \"c720449a331a43d192747e04bc15e35e\",
        \"out_refund_no\": \"WX240410170222000818227131\",
        \"settlement_refund_fee\": \"1\",
        \"cert_id\": \"4233741533\",
        \"return_msg\": \"成功\",
        \"fee_type\": \"CNY\",
        \"mch_id\": \"1505378701\",
        \"sub_mch_id\": \"626185853\",
        \"refund_id\": \"50103409282024041029404981024\",
        \"coupon_refund_fee\": \"0\",
        \"refund_create_time\": \"2024-04-1017: 02: 22\",
        \"appid\": \"wx17728c1a8fa300d6\",
        \"refund_fee\": \"1\",
        \"result_code\": \"SUCCESS\",
        \"cash_refund_fee\": \"1\",
        \"sign_type\": \"SM2\",
        \"return_code\": \"SUCCESS\"
    }",
    "return_code": "SUCCESS"
}
```

文档更新时间: 2025-11-05 14:44   作者：陈文