#### 请求URL:

服务商线下提供接收通知地址，一般出现为结算异常，服务商收到通知后，可做结算卡变更，恢复正常结算。

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 商户编号 | String |  |  | M |
| settle\_day | 结算日期 | String |  |  | M |
| return\_remit\_no | 退汇单号 | String |  |  | O |
| last\_return\_remit\_no | 上次退汇单号 | String |  |  | O |
| ori\_payment\_no | 结算订单号 | String |  |  | O |
| settle\_amount | 结算金额 | String |  |  | O |
| refund\_reason | 退汇原因 | String |  |  | M |
| status | 退汇处理状态 | String |  | 0待处理；1申请失败；2 申请成功 | M |
| settle\_status | 结算状态 | String |  | 0 待结算；1 结算成功；2 结算失败 | M |

#### 通知示例:

```
{
    "merch_no": "8888888888",
    "agent_no": "XXXXX",
    "settle_day": "2018-12-12",
    "refund_reason": "Ⅱ、Ⅲ类户年累计交易金额超限[789X1021261][通知]",
    "sign": "91741FA7910DC5EB2B325130BDBA1164"
}
```

文档更新时间: 2025-11-26 17:19   作者：王金晶