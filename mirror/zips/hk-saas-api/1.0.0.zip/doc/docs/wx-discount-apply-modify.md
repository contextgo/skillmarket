#### 概要描述:

服务商可以通过该接口向微信支付提交高校食堂商户的优惠活动修改。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/wx-auth/activity-apply/update>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| agent\_apply\_no | 服务商申请单编号 | String |  |  | M |
| activity\_detail | 活动报名信息 | JSON |  |  | O |
| additional\_information | 补充信息 | JSON |  |  | O |

##### 活动报名信息：activity\_detail

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| activity\_rate | 活动费率 | String | 1、参见[《优惠费率活动对照表》](https://docs.qq.com/sheet/DSkZxWVhnUlFpbndy?tab=BB08J2)。 2、若为固定费率，则无需填写该字段 3、若为区间费率，则由从业机构自定义填写，支持两个小数点，需在优惠费率活动ID指定费率范围内，如0.6%（接口无需传%，只需传数字） 示例值：0.6 |  | O |
| activity\_apply\_information | 活动报名材料 | Array | 参见[《优惠费率活动对照表》](https://docs.qq.com/sheet/DSkZxWVhnUlFpbndy?tab=BB08J2)，填写活动报名资料。 |  | O |

##### 活动报名材料：activity\_apply\_information

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| apply\_material\_id | 材料ID | String | 根据活动id（activity\_id）所选优惠费率活动，参见[《优惠费率活动对照表》](https://docs.qq.com/sheet/DSkZxWVhnUlFpbndy?tab=BB08J2)填写对应的材料ID。 示例值：SCHOOL\_QUALIFICATION\_PROOF |  | O |
| apply\_material\_information | 材料内容 | Array | 根据所选优惠费率活动，在相应材料名称后提供相关材料，详细参见[《优惠费率活动对照表》](https://docs.qq.com/sheet/DSkZxWVhnUlFpbndy?tab=BB08J2)（图片ID）。 |  | O |

##### 补充信息：additional\_information

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| additional\_message | 补充说明 | String | 根据要求提供额外文本信息。 |  | O |
| additional\_material | 补充材料 | Array | 根据要求提供额外补充资料（图片ID） |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "agent_apply_no": "11111111111",
    "sign": "36EE79FD2E36527F5A75D58E40C9FEC4",
    "additional_information": {
        "additional_message": "特殊情况，说明原因",
        "additional_material": [
            "6ea605328e93413190cac49dd7965e55",
            "6ea605328e93413190cac49dd7965e56"
        ]
    },
    "activity_detail": {
        "activity_id": "schoolcanteen_001",
        "activity_rate": "0.6",
        "activity_apply_information": [
            {
                "apply_material_id": "SCHOOL_QUALIFICATION_PROOF",
                "apply_material_information": [
                    "6ea605328e93413190cac49dd7965e57",
                    "6ea605328e93413190cac49dd7965e58"
                ]
            },
            {
                "apply_material_id": "CANTEEN_FRONT_PHOTO",
                "apply_material_information": [
                    "6ea605328e93413190cac49dd7965e59",
                    "6ea605328e93413190cac49dd7965e60"
                ]
            }
        ]
    }
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| wx\_apply\_no | 微信申请单编号 | String |  |  | O |

#### 返回示例:

```
{
    "wx_apply_no": "200323174241616939321401",
    "return_code": 10000,
    "sign": "F354732C4886EC9001C2E9FF2E45870E"
}
```

文档更新时间: 2024-11-29 10:13   作者：admin