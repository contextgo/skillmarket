#### 概要描述:

1、服务商可调用该接口查询微信修改结算ID申请单信息。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/wx-settleid-modify/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| apply\_no | 申请单编号 | String | 微信返回的申请单编号 |  | M |

#### 返回参数:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 | 1000 | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| apply\_no | 申请单编号 | String | 微信返回的申请单编号 |  | O |
| process\_info | 申请单处理信息 | String | 申请单的具体处理信息 |  | O |
| status | 申请单状态 | String | PROCESSING：处理中；PASSED：成功；FAILED：失败 |  | O |
| update\_time | 最后更新时间 | String | 单据的最后更新时间，格式：yyyy-MM-dd HH:mm:ss |  | O |
| merch\_no | 商户编号 | String | 商户在SaaS平台的编号 | 88888888 | O |
| wx\_merch\_no | 渠道商户号 | String | 微信商户号 |  | O |
| bus\_scope\_code | 营业范围代码 | String | 营业范围代码 |  | O |
| rate | 费率 | String | 单位为万分之一，例如费率为0.6%,需要传60。（如果为0.2，需要传20） | 20 | O |

文档更新时间: 2025-05-21 13:20   作者：张亚飞