#### 概要描述:

服务商可调用该接口查询SAAS流程工单状态。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/flow/queryStatus>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| flow\_no | 申请单编号 | String |  |  | M |

#### 请求示例:

```
{
    "flow_no": "A23051000000003"   
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | String |  |  | M |
| return\_msg | 错误信息 | String | return\_code不为10000时有值 |  | O |
| flow\_status | 申请单状态 | String | return\_code=10000时有值 SHTG:审核通过； SHBH:审核驳回； SHJJ:审核拒绝； SHZ:审核中 ； |  | O |
| biz\_type | 申请单名称 | String | return\_code=10000时有值 RAISE\_LIMIT：商户提额 |  | O |
| audit\_description | 审核描述 | String |  |  | O |

#### 成功时返回示例:

```
{
    "flow_status": "SHJJ",
    "biz_type": "RAISE_LIMIT",
    "audit_description": "不符合要求",
    "return_code": 10000,
    "sign": "87CA77DDEC0C4FAF81C0FA70F8B1AB6D"
}
```

文档更新时间: 2024-11-29 10:10   作者：admin