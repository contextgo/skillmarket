#### 简要描述：

1、风控调单详情

#### 请求URL:

测试环境：<http://47.95.131.62:8080/api/v1/agent/risk/dispatch/detail>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| dispatchNum | 风险案例编号 | String |  |  | M |
| accessid | 服务商标识 | String |  |  | M |

#### 请求示例:

```
{
    "caseNo": "20230511155524394956750290100",
    "accessid": "4028805b6e86d179016e874f6c4200ad",
    "sign": "975077BFC098C592C721A3948A97460F"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | String 当return\_code不为10000时有值 |  | O |
| Data | 返回数据 | JSON | String 当return\_code=10000时有值 |  | O |

#### Data参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| legalPhone | 法人手机号 | String | 法人手机号 | 13113151131 | O |
| dispatchType | 调单类型 | String |  |  | O |
| tradeCardFrontImgs | 交易卡正面 | String |  |  | O |
| firstAgentNum | 一级代理商编号 | String |  |  | O |
| dispatchCode | 调单原因码 | String |  |  | O |
| remark | 备注 | String |  |  | O |
| trxType | 是否双免 | String |  | 否 | O |
| cardNo | 交易卡号 | String |  | 6259625742250102 | O |
| realAmount | 持卡人实付金额 | String |  | 500.00 | O |
| agentNum | 代理商编号 | String |  | 500.00 | O |
| issName | 发卡行 | String |  | 兴业银行 | O |
| certificateFrontImgs | 身份证正面 | String |  |  | O |
| updateBy | 操作人 | String |  |  | O |
| provincename | 省 | String |  |  | O |
| dispatchAnnotation | 调单注释 | String |  |  | O |
| id |  | String |  |  | O |
| billInfoImgs | 小票信息 | String |  |  | O |
| trxSource | 交易方式 | String |  |  | O |
| startOrg | 发起机构 | String |  |  | O |
| trxAmt | 持卡人发起金额 | String |  | 500.00 | O |
| thirdorderid | 上游订单号 | String |  |  | O |
| disabledReason | 注销原因 | String |  |  | O |
| mercName | 商户名称 | String |  | 开平市华籽食品配送有限公司 | O |
| certificateBackImgs | 身份证反面 | String |  |  | O |
| orgName | 分公司 | String |  | 山东分中心 | O |
| dispatchNum | 调单号 | String |  | 20250408170844030001 | O |
| sysRefNum | 银联流水号 | String |  | UN2503301451050000326071439 | O |
| areaname | 区代码 | String |  | 开平市 | O |
| bankFirstDate | 银行首发日 | String |  | 2025-04-07 00:00:00 | O |
| bankMerchantNo | 银行商户号 | String |  | 83358945311H04T | O |
| firstAgentName | 一级代理商名称 | String |  | 数字支付中心 | O |
| cityname | 市代码 | String |  | 江门市 | O |
| bankLastDate | 最后期限 | String |  | 2025-04-18 00:00:00 | O |
| mercNum | 商户编号 | String |  | 833589453110159 | O |
| agentName | 代理商名称 | String |  | 数字支付中心 | O |
| updateTime | 更新时间 | String |  | 2025-04-18 17:23:03 | O |
| dispatchStatus | 调单状态 | String |  | SHTG | O |
| tradeProImgs | 交易证明 | String |  |  | O |
| tradeCardBackImgs | 交易卡反面 | String |  |  | O |
| paymentNo | 交易流水号 | String |  | UN2503301451050000326071439 | O |
| disabledBy | 注销人 | String |  |  | O |
| createTime | 创建时间 | String |  | 2025-04-08 17:08:44 | O |
| fastdfsUrl |  | String |  | <https://dfs-pro.icardpay.com> | O |
| disabledState | 注销状态 | String |  | normal | O |
| importTransTime | 导入交易时间 | String |  | 2025-03-30 00:00:00 | O |
| startTrxTime | 交易时间 | String |  | 2025-03-30 14:51:0 | O |
| recordList |  | JSON |  |  | O |

#### recordList:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| operateBy | 操作人 | String |  |  | O |
| dispatchNum | 调单号 | String |  |  | O |
| createTime | 创建时间 | String |  |  | O |
| operateType | 操作类型 | String |  |  | O |
| operateDesc | 操作描述 | String |  |  | O |

#### 返回示例:

```
{
    "legalPhone": "15819734174",
    "dispatchType": "dispatch",
    "tradeCardFrontImgs": "",
    "agentType": "ISV",
    "firstAgentNum": "ISV003533",
    "recordList": [{
        "operateBy": "luosijia",
        "dispatchNum": "20250408170844030001",
        "createTime": "2025-04-18 17:23:03",
        "operateType": "SHTG",
        "operateDesc": ""
    }, {
        "operateBy": "13426352829",
        "dispatchNum": "20250408170844030001",
        "createTime": "2025-04-18 17:18:38",
        "operateType": "SAASSH",
        "operateDesc": "李健华 广东省江门市开平市苍城镇大东中路18号18幢首层，15819734174，04"
    }],
    "dispatchCode": "6303",
    "remark": "李健华 广东省江门市开平市苍城镇大东中路18号18幢首层，15819734174，04",
    "trxType": "否",
    "cardNo": "6259625742250102",
    "realAmount": "500.00",
    "agentNum": "ISV003533",
    "issName": "兴业银行",
    "certificateFrontImgs": "",
    "updateBy": "luosijia",
    "provincename": "广东省",
    "dispatchAnnotation": "调取签购单、商户名称、地址、电话",
    "id": "361",
    "billInfoImgs": "",
    "trxSource": "银联二维码",
    "startOrg": "03090010",
    "trxAmt": "500.00",
    "thirdorderid": "48330000000499927460800330145105",
    "disabledReason": "",
    "mercName": "开平市华籽食品配送有限公司",
    "certificateBackImgs": "",
    "orgName": "山东分中心",
    "dispatchNum": "20250408170844030001",
    "sysRefNum": "UN2503301451050000326071439",
    "areaname": "开平市",
    "bankFirstDate": "2025-04-07 00:00:00",
    "bankMerchantNo": "83358945311H04T",
    "firstAgentName": "数字支付中心",
    "cityname": "江门市",
    "bankLastDate": "2025-04-18 00:00:00",
    "mercNum": "833589453110159",
    "agentName": "数字支付中心",
    "updateTime": "2025-04-18 17:23:03",
    "dispatchStatus": "SHTG",
    "tradeProImgs": "",
    "tradeCardBackImgs": "",
    "paymentNo": "UN2503301451050000326071439",
    "disabledBy": "",
    "createTime": "2025-04-08 17:08:44",
    "fastdfsUrl": "https://dfs-pro.icardpay.com",
    "disabledState": "normal",
    "importTransTime": "2025-03-30 00:00:00",
    "startTrxTime": "2025-03-30 14:51:05"
}
```

文档更新时间: 2025-04-30 13:16   作者：张亚飞