#### 概要描述:

当服务商需要确认微信支付子商户号是否完成确认时，如果调用此接口提到”已授权“状态，则说明该商户号已完成开户意愿确认。

* 注：使用海科渠道号的服务商必须调用该接口；使用自己主体渠道号的服务商，可以调用该接口或直接调用微信官方认证接口均可完成微信二次认证。  
  微信官方接口链接如下：<https://pay.weixin.qq.com/wiki/doc/apiv3_partner/apis/chapter10_1_4.shtml>

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/wx-auth/query-merchant-auth-status>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |
| wx\_merch\_no | 微信商户编号 | String |  |  | M |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "merch_no": "83311010100002012",
    "wx_merch_no": "36771679469",
    "sign": "36EE79FD2E36527F5A75D58E40C9FEC4"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| authorize\_state | 授权状态 | String | AUTHORIZE\_STATE\_UNAUTHORIZED：未授权 AUTHORIZE\_STATE\_AUTHORIZED ：已授权 |  | M |

#### 返回示例:

```
{
    "return_msg": "查询成功",
    "return_code": 10000,
    "authorize_state": "AUTHORIZE_STATE_UNAUTHORIZED",
    "sign": "74D55ACA6A2698290542DF709BB966B2"
}
```

文档更新时间: 2024-11-29 10:08   作者：admin