#### 概要描述:

此接口可为商户报名支付宝特殊活动  
开通流程：  
1、服务商联系对应BD营销经理，开通配置相关参数信息  
2、商户支付宝通道商户号，必须报备在海科机构号下。  
3、提交成功后自动修改商户支付宝费率值。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/activity/apply>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_apply\_no | 服务商申请单号 | String |  |  | M |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |
| sub\_mch\_id | 通道商户号 | String | 通道商户号 |  | M |
| activity\_type | 活动类型 | String | ALI\_LARGE:支付宝大额通道 |  | M |
| activity\_rate | 费率值 | String | 单位为万分之一，例如费率为0.6%,需要传60。（如果为0.2，需要传20） | 20 | M |
| remark | 备注 | String |  |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_apply_no":'3213213213123213213',
    "agent_no": "11010200097",
    "merch_no": "833495470920001",
    "sub_mch_id"："20883213213123"
    "activity_type": "ALI_LARGE",
    "activity_rate": "48",
    "remark": "",
    "sign": "2F2564D5853FE24308FB5E3F655C1900"
}
```

#### 返回信息(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| merch\_no | 海科商户编号 | String | 成功返回海科平台商户号 |  | M |
| sub\_mch\_id | 通道商户号 | String | 通道商户号 |  | M |
| activity\_create\_time | 活动创建时间 | String | 活动创建时间 |  | M |

#### 返回示例:

```
{
    "return_code": 10000,
    "merch_no": "833495470920001",
    "sub_mch_id": "20883213213123",
    "activity_create_time": "2024-05-20 11:11:11",
    "sign": "D657A5EDA8D1ACC730D8A0EB4C0CE185"
}
```

文档更新时间: 2024-11-29 10:13   作者：admin