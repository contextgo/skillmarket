#### 概要描述:

商户查询结算卡信息接口

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/merchant-bank-info/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |
| agent\_no | 服务商编号 | String | 服务商编号 |  | M |

#### 请求示例:

```
{
    "agent_no": "11010200097",
    "merch_no": "833110100000024",
    "accessid": "cpostest",
    "sign": "BBFC7365E74FD46A2EB386151DA2E9EC"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| acc\_no | 账户账号 | String | 入账银行卡卡号 |  | M |
| acc\_type | 账户类型 | String | 10A:对公 10B:对私 10C:对私非法人 |  | M |
| acc\_name | 账户户名 | String | 结算人姓名/公司名 |  | M |
| phone | 持卡人手机号 | String | acc\_type=10B时必传 |  | O |
| bank\_code | 结算账户清算行号 | String | 取值详见附录：[银行代码](http://39.106.84.215:8181/docs/saas/saas-1b70ddl9848ar "银行代码") |  | M |
| bank\_name | 开户行网点名称 | String | acc\_type=10A时必传 |  | O |
| bank\_province\_code | 开户行网点-省 | String | 取值详见附录：[省市区代码](http://39.106.84.215:8181/docs/saas/saas-1b6thep6bs5c2 "省市区代码") |  | M |
| bank\_city\_code | 开户行网点-市 | String | 取值详见附录：[省市区代码](http://39.106.84.215:8181/docs/saas/saas-1b6thep6bs5c2 "省市区代码") |  | M |

#### 成功时返回示例:

```
{
    "acc_no": "6217000010044116492",
    "acc_type": "10B",
    "acc_name": "艾飞",
    "phone": "18645178182",
    "bank_code": "105100000017",
    "bank_name": "西直门支行",
    "bank_province_code": "110000",
    "bank_city_code": "110100",
    "return_code": 10000,
    "sign": "B0EB14E63E76D9BCFD61302899D0AD8F"
}
```

文档更新时间: 2025-06-26 11:32   作者：王金晶