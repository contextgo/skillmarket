#### 概要描述:

活动报名查询

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/activity/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| agent\_apply\_no | 服务商申请单号 | String | 服务商申请单号或海科商户编号、通道商户号、活动类型二选一进行上送 |  | C |
| merch\_no | 海科商户编号 | String | 服务商申请单号或海科商户编号、通道商户号、活动类型二选一进行上送 |  | C |
| sub\_mch\_id | 通道商户号 | String | 服务商申请单号或海科商户编号、通道商户号、活动类型二选一进行上送 |  | C |
| activity\_type | 活动类型 | String | 服务商申请单号或海科商户编号、通道商户号、活动类型二选一进行上送 |  | C |

#### 请求示例:

```
{
    "accessid": "cpostest",
        "agent_no": "11010200097",
    "agent_apply_no":'3213213213123213213',
    "sign": "2F2564D5853FE24308FB5E3F655C1900"
}
```

#### 返回信息(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| apply\_status | 申请状态 | String | 1、已报名 2.报名失败 3报名中 |  | M |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科商户编号 |  | M |
| sub\_mch\_id | 通道商户号 | String | 通道商户号 |  | M |
| activity\_type | 活动类型 | String | 1、支付宝大额活动 |  | M |
| activity\_rate | 费率值 | String |  |  | M |
| remark | 备注 | String |  |  | O |
| activity\_create\_time | 活动创建时间 | String | 活动创建时间 |  | M |

#### 返回示例:

```
{
    "return_code": 10000,
    "apply_status": 1,
    "agent_no": "11010200097",
    "merch_no": "833495470920001",
    "sub_mch_id": "20883213213123",
    "activity_type":1,
    "activity_rate": "48",
    "remark": "",
    "activity_create_time": "2024-05-20 11:11:11",
    "sign": "D657A5EDA8D1ACC730D8A0EB4C0CE185"
}
```

文档更新时间: 2024-11-29 10:13   作者：admin