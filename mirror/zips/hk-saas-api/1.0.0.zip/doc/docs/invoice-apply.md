## 1.1. 发票业务申请接口

### 1.1.1. 接口说明

发票业务申请接口  
1）按照商户交易完成时间和商户实收手续费减去手续费补贴金额进行汇总  
2）按照商户交易时上送的实收手续费进行汇总手续费金额  
3）商户全称和购方名称必须一致。（总公司开票除外）  
4）如果开票状态为：开票成功，签章失败，需要发起查询。  
5）发票作废逆向流程联系运营&商务进行处理

### 1.1.2. 接口地址

<http://47.95.131.62:8080//api/v2/invoice/apply>

### 1.1.3. 请求参数

| **参数** | **参数名称** | **类型** | **参数说明** | **必填** | **样例** |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 海科分配的服务商编号 | M | FW10000XXX |
| agent\_apply\_no | 服务商申请单号 | String | 服务商发票申请上送的 ，服务商唯一订单号 | M |  |
| merch\_no | 商户号的集合 | String | 开发票的商户号的集合,逗号分隔,多商户号进行开发票的时候,需要注意并发,避免锁竞争 | M | 8331,8332 |
| client\_name | 购方名称 | String | 发票购方信息下的名称 | M | 北京XXXX有限公司 |
| invoice\_type | 发票类型 | String | 开发票的类型,DZZP:数电专票,PTDZFP:数电普通发票 1、商户类型为企业时开票的时候无论普票还是专票都需要税号 2、其他商户类型开专票必须输入税号，非专票无需上传税号 | M | DZZP |
| code\_type | 发票种类 | String | 何种类型的发票 手续费:tradeFee | M | tradeFee |
| begin\_month | 开始月份 | String | 计算手续费的开始月份,不可超过当前月份 | M | 2024-10 |
| end\_month | 结束月份 | String | 计算手续费的截止月份,不可超过当前月份 | M | 2024-10 |
| tax\_num | 税号 | String | 购方信息:税号 | M | 30003213123123123123 |
| send\_email | 发票通知邮箱 | String | 下发通知的邮箱地址,非必填,不超过50字符 | O | [1234@qq.com](mailto:1234@qq.com) |
| nat\_per\_flag | 购买方自然人标志 | String | 是否个人开票:Y 是 N 不是,不传默认是N | O | N |
| parent\_company | 总公司开票 | String | 是否总公司开票:Y 是 N 不是,不传默认是N,总公司开票进入审核环节 | O | N |
| client\_bank\_name | 购方银行名称 | String | 购方银行账户名称 | O | 北京银行 |
| client\_bank\_acc\_no | 购方银行账户号 | String | 购方银行账户号 | O | 622220202020020202020 |
| concat\_address | 联系人地址 | String | 联系人地址 | O | 北京市 |
| concat\_phone | 联系人电话 | String | 联系人电话 | O | 83310256231235 |
| invoice\_notes | 发票备注 | String | 发票下方备注信息 | O | 83310256231235 |

### 1.1.4. 返回参数

| **参数** | **参数名称** | **类型** | **参数说明** | **必填** | **样例** |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败,成功返回其他业务信息 | M | 10000 |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 | O |  |
| apply\_no | 海科申请单号 | String |  | M | 海科系统申请发票单号 |
| agent\_apply\_no | 服务商申请单号 | String | 上送的服务商单号 | M | 10000 |
| client\_name | 购方名称 | String | 上送的 | M | 10000 |
| invoice\_status | 发票状态 | String | 枚举值： YSQ:已申请 YKP:已开票 YJC:已寄出 YZF:已作废 YCX:已撤销 DSH：待审核 YKPDOZ:已开票待签章 KPSB:开票失败 KPZ:开票中 YSQDHS:已申请待核算 | M | 1 |
| invoice\_status\_msg | 发票状态描述 | String | 非成功下参考 | C | 10000 |
| invoice\_type | 发票类型 | String | DZFP:数电专票,PTDZZP:数电普票 | M | 10000 |
| tax\_num | 税号 | String | 申请上送的 | M | 10000 |
| send\_email | 发送邮箱 | String | 申请上送的 | C |  |
| nat\_per\_flag | 购买方自然人标志 | String | 是否个人开票:Y 是 N 不是 | M | N |
| parent\_company | 总公司开票 | String | Y是N不是 | M |  |
| client\_bank\_name | 购方银行名称 | String | 购方银行账户名称 | C | 北京银行 |
| client\_bank\_acc\_no | 购方银行账户号 | String | 购方银行账户号 | C | 622220202020020202020 |
| concat\_address | 联系人地址 | String | 联系人地址 | C | 北京市 |
| concat\_phone | 联系人电话 | String | 联系人电话 | C | 83310256231235 |
| invoice\_notes | 发票备注 | String | 发票下方备注信息 | C | 83310256231235 |
| invoice\_no | 发票号码 | String | 开票成功:发票号码 | O |  |
| pdf\_url | PDF文件下载链接 | String | 开票成功:PDF文件下载链接 | C |  |
| electric\_code | 数电发票号码 | String | 开票成功:数电发票号码 | C |  |
| amount | 订单总金额 | String | 申请发票周期内的订单总金额 | M | 10.00元 |
| free\_amount | 手续费金额 | String | 申请发票周期内的订单手续费金额 | M | 10.00元 |

文档更新时间: 2025-04-16 15:44   作者：张亚飞