#### 概要描述:

可获取到某批次的核销明细数据，包括订单号、单品信息、银行流水号等，用于对账/数据分析。

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/front-api/wx-coupon/download-use-flow>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| stock\_id | 卡券批次id | String(64) | 微信为每个批次分配的唯一id |  | M |

#### 请求示例:

```
{
    "agent_no": "IS88888888",
    "req_id": "147258369",
    "stock_id": "",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表成功 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| url | 下载链接 | String | 流水文件下载链接，30s内有效 |  | M |
| hash\_value | 安全校验码 | String | 文件内容的哈希值，防止篡改 |  | M |
| hash\_type | 哈希算法类型 | String | 哈希算法类型，目前只支持SHA1 |  | M |

#### 返回示例:

```
{
    "return_msg": "成功",
    "return_code": "SUCCESS",
    "result_code": "10000",
    "result_msg": "请求成功",
    "url": "https://api.mch.weixin.qq.com/v3/1111",
    "hash_value": "8ae0eb442c408d2e90d669d6f4ad6b7e6e049d6f",
    "hash_type": "SHA1"
}
```

文档更新时间: 2025-02-13 09:50   作者：陈文