#### 概要描述:

本服务商下商户提现接口，请确保商户已开通手工提现功能  
提现时间：07：00-21：59：59

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/account/withdraw/settle>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_apply\_no | 服务商申请单号 | String | 服务商申请单号 |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |
| agent\_no | 服务商编号 | String | 服务商编号 |  | M |
| withdraw\_amount | 提现金额 | String | 提现金额 | 56 | M |

#### 请求示例:

```
{
    "merch_no": "833102158123961",
    "agent_no": "ISV000607",
    "agent_apply_no": "4324332324424324",
    "withdraw_amount": "56",
    "accessid": "4028805b8353abde018353c1118d005d",
    "sign": "B320179AEACFA2E9E300875CE585B2FE"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| apply\_no | 提现申请单ID | String | 状态为10000时会返回（返回申请单号） |  | M |
| amount | 提现金额 | String | 提现金额（单位：元） |  | O |
| withdraw\_fee | 提现手续费 | String | 状态为10000时会返回 |  | O |
| real\_amount | 实际到账金额 | String | 状态为10000时会返回 |  | M |
| apply\_time | 创建时间 | String | 状态为10000时会返回 |  | O |

#### 成功时返回示例:

```
{
    "return_code": 10000
    return_msg:''''''
    apply_no": 2026034234324324324
    amount:'''56'''
    "withdraw_fee": "1"
    real_amount:''''55''
    apply_time:'''' 2026-03-11 11:11:11''
}
```

文档更新时间: 2026-03-23 15:41   作者：张亚飞