#### 概要描述:

当交易发生之后一段时间内，由于买家或者卖家的原因需要退款时，卖家可以通过退款接口将支付款退还给买家，微信支付将在收到退款请求并且验证成功之后，按照退款规则将支付款按原路退到买家帐号上。  
注意：只支持全额退款。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/pay/digitalwallet/refund>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String | 海科平台商户编号 |  | M |
| out\_trade\_no | 原服务商交易订单号 | String | trade\_no、out\_trade\_no必传其中一个，都传则以trade\_no为准，推荐使用trade\_no |  | O |
| trade\_no | 原海科支付订单号 | String | trade\_no、out\_trade\_no必传其中一个，都传则以trade\_no为准，推荐使用trade\_no |  | O |
| out\_refund\_no | 服务商退款订单号 | String | 服务商内部订单号（同一服务商下唯一） |  | M |
| refund\_amount | 退款金额 | String | 退款金额（单位：元） |  | M |
| pn | SAAS终端号 | String | SAAS终端号 |  | O |
| notify\_url | 异步通知地址 | String | 交易成功异步通知地址 |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "merch_no": "83388888888",
    "trade_no": "123456789",
    "out_refund_no": "12345678922",
    "refund_amount": "1",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 响应码 | String | 10000代表成功 |  | M |
| return\_msg | 响应信息 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户编号 |  | M |
| out\_refund\_no | 服务商退款订单号 | String |  |  | M |
| refund\_no | 海科退款订单号 | String |  |  | M |
| trade\_status | 交易状态 | String | 1：交易成功 2：交易失败 3：交易进行中 4：交易超时 |  | M |
| error\_code | 错误码 | String |  |  | O |
| error\_msg | 错误消息 | String |  |  | O |

#### 返回示例:

```
{
    "merch_no": "83388888888",
    "out_refund_no": "123456789",
    "refund_no": "AL88888888",
    "trade_status": "1",
    "return_code": "10000",
    "return_msg": "成功",
    "sign": "1032A57E96E4048B27EC2A5C3CE5E663"
}
```

文档更新时间: 2024-11-29 10:11   作者：陈文