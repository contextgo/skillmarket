#### 简要描述：

* 该终端提前调拨至服务商之后，厂商可以调用此接口获取银联卡BIN信息（请求参数同：参数下载 接口）。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/params-init/union-cardbin-download>

#### 请求参数(O-非必传 ,M-必传):

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| sn | 厂商sn编号 | String | 加密后转成base64后的数据 | p111166668888 | M |
| firm | 厂商 | String |  |  | M |
| type | 卡bin类型 | String | 如果传EXPRESS，则返回34或37开头卡BIN信息；如果没传或者传其他则返回全部银联卡bin数据 |  | O |

#### 请求示例:

```
{    
    "sn": "base64(encrypt(sn))",
    "firm": "MF"
}
真实数据：
{
    "firm":"FJLDSB",
    "sn":"iNu5VEOfgnM1Yj7iw7Wozp2hzWzBP5QX3ceztg7YlKzmAbahDhDAUo4HKuSSy0CR6mhkO6cPJeyVz6koWzZrQ184Ul7nIjtd/eE7l1BnQMhqwaHJ67i31pKq6tHvGMJoil5aMqyVusubR0JRqBVQ3zXs3/IKTKKU1COL8ScRr2g\u003d"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 错误码 | int | 正常：10000；其他为异常 | 10000 | M |
| return\_msg | 错误信息 | String |  |  | O |
| data | 卡BIN列表数据 | JSONARRAY |  |  | M |

##### 卡BIN列表数据：data

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| Id | 主键 | int |  |  | M |
| all\_track | 全部磁道信息 | String | 表示全部磁道信息：“2”为仅存在第2磁道；“3”为仅存在第3磁道；“2 3”为存在第2及3磁道 |  | O |
| all\_track\_len | 第2及3磁道长度 | String | 表示全部磁道信息各磁道长度：“37” 表示2磁为37；“104” 表示3磁为104；“37 104” 表示2磁长为37，3磁长为104 |  | O |
| all\_track\_start\_pos | 全部磁道起始字节 | String | 从磁道的哪个字节开始读取，与“全部磁道信息”相对应。 如全部磁道信息为2或3，则2、3磁道信息起始字节各为1位数字，左起第一位表示2磁的起始字节，左起第二位表示3磁的起始字节。 |  | O |
| bin\_len | 卡BIN长度 | int | 一般为6位 |  | M |
| bin\_num | 卡BIN号 | String | 数字型，左对齐，如622123 |  | O |
| bin\_start\_pos | 卡BIN起始字节 | int | 卡BIN从磁道的哪个字节开始读取，与“卡BIN读取磁道”相对应。 如卡BIN读取磁道为”2”或”3”，则卡BIN起始字节为1位数字，表示从“卡BIN读取磁道”指明的磁道的第几字节开始读取； 如卡BIN读取磁道为“23”或“2&3”，则卡BIN起始字节为2位数字，左起第一位表示2磁的卡BIN起始字节，左起第二位表示3磁的卡BIN起始字节。 |  | M |
| bin\_track | 卡BIN读取磁道 | String | 卡BIN从哪个磁道读取： “2”为仅读取第2磁道； “3”为仅读取第3磁道； “2 3”为第2或3磁道； “2&3”为第2与3磁道。 |  | O |
| card\_name | 卡名称 | String | 如牡丹灵通卡等 |  | O |
| card\_no\_len | 主账号长度 | int | P\_KEY值,一般为13-19位 |  | M |
| card\_no\_start\_pos | 主账号起始字节 | String | 主账号从磁道的哪个字节开始读取，与“主账号读取磁道”相对应。 如主账号读取磁道为”2”或”3”，则主账号起始字节为1位数字，表示从“主账号读取磁道”指明的磁道的第几字节开始读取； 如主账号读取磁道为”2 3”，则主账号起始字节为2位数字，左起第一位表示2磁的主账号起始字节，左起第二位表示3磁的主账号起始字节。 注：发卡方优先从第2磁道截取主帐号，若无法从第2磁道截取主帐号，则可从第3磁道截取。 |  | O |
| card\_no\_track | 主账号读取磁道 | String | 主账号从哪个磁道读取 “2”为仅读取第2磁道； “3”为仅读取第3磁道； “2 3”为第2或3磁道 |  | O |
| cup\_logo\_flag | 是否银联品牌卡 | String | 0- 非银联品牌卡； 1- 银联品牌卡(9字头卡或银联标准卡) |  | O |
| debit\_credit\_flag | 卡种 | String | 1-借记卡； 2-贷记卡； 3-准贷记卡； 4-预付卡 |  | O |
| issuer\_code | 发卡机构代码 | String | 如01020000表示中国工商银行。 |  | O |
| issuer\_name | 发卡行名称 | String | 如中国工商银行。 |  | O |

#### 返回示例:

```
{
    "return_code": 10000,
    "data": [{"id":13101,"issuer_code":"03030000","issuer_name":"光大银行","card_name":"光大银行卡","card_no_track":"1","card_no_start_pos":"1","card_no_len":16,"bin_num":"522622","bin_track":"2","bin_start_pos":1,"bin_len":6,"all_track":"1","all_track_start_pos":"1","all_track_len":"1","cup_logo_flag":"1","debit_credit_flag":"1"},{"id":13100,"issuer_code":"01020000","issuer_name":"银联","card_name":"白卡0119","card_no_track":"1","card_no_start_pos":"1","card_no_len":19,"bin_num":"62121416","bin_track":"2","bin_start_pos":1,"bin_len":8,"all_track":"1","all_track_start_pos":"1","all_track_len":"1","cup_logo_flag":"1","debit_credit_flag":"1"},{"id":13099,"issuer_code":"01020000","issuer_name":"银联","card_name":"白卡0103","card_no_track":"1","card_no_start_pos":"1","card_no_len":19,"bin_num":"62121415","bin_track":"2","bin_start_pos":1,"bin_len":8,"all_track":"1","all_track_start_pos":"1","all_track_len":"1","cup_logo_flag":"1","debit_credit_flag":"1"},{"id":13098,"issuer_code":"01020000","issuer_name":"银联","card_name":"白卡0097","card_no_track":"1","card_no_start_pos":"1","card_no_len":19,"bin_num":"62121419","bin_track":"2","bin_start_pos":1,"bin_len":8,"all_track":"1","all_track_start_pos":"1","all_track_len":"1","cup_logo_flag":"1","debit_credit_flag":"1"}]
}
```

文档更新时间: 2024-11-29 10:15   作者：陈文