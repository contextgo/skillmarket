#### 概要描述:

商户产品开通及费率查询接口

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/agent/store/insert>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agentApplyNo | 服务商申请单号 | String | 服务商申请单号 |  | M |
| merchNo | 海科商户编号 | String | 海科平台商户号 |  | M |
| agentNo | 服务商编号 | String | 服务商编号 |  | M |
| name | 门店名称 | String | 门店名称 |  | M |
| phone | 门店联系人手机号 | String | 门店联系人手机号 |  | M |
| linkMan | 门店联系人 | String | 门店联系人 |  | M |
| province\_code | 省编号 | String | 省编号 |  | M |
| city\_code | 市编号 | String | 市编号 |  | M |
| area\_code | 区编号 | String | 区编号 |  | M |
| address | 详细地址 | String | 详细地址 |  | M |
| busLicenseNo | 营业执照编号 | String | 营业执照编号&营业执照名称&法人姓名，三个一起上传 |  | C |
| busLicenseName | 营业执照名称 | String | 营业执照编号&营业执照名称&法人姓名，三个一起上传 |  | C |
| legalName | 法人姓名 | String | 营业执照编号&营业执照名称&法人姓名，三个一起上传 |  | C |
| A32 | 辅助资料 | String | 辅助资料 |  | O |
| A1 | 营业执照照片 | String | 企业或者个体视频为必填 |  | C |
| videoId | 验证视频 | String | 企业或者个体视频为必填 |  | C |
| A5 | 商户门头照 | String | 商户门头照 |  | M |

#### 请求示例:

```
{
    "merchNo": "833102158123961",
    "agentNo": "ISV000607",
    "name": "烧烤一部11",
    "phone": "18612830668",
    "linkMan": "李四",
    "address": "北京市西城区西直门内大街132号11幢201室",
    "A5": "942f59faab374086b02be755b9a3581e",
    "longitude": "13213213",
    "latitude": "32133213",
    "province_code": "110000",
    "city_code": "110100",
    "area_code": "110100",
    "busLicenseNo": "34232ERREWRE",
    "busLicenseName": "营业门店",
    "legalName": "李三",
    "shopRefund": "on",
    "shopOwner": "on",
    "agentApplyNo": "4324332324424324",
    "accessid": "4028805b8353abde018353c1118d005d",
    "sign": "B320179AEACFA2E9E300875CE585B2FE"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| shop\_no | 门店编号 | String | 门店编号 |  | M |
| merch\_no | 商户编号 | String | SAAS商户编号 |  | O |

#### 成功时返回示例:

```
{
    "shop_no": "833102158123961_0006",
    "merch_no": "833102158123961",
    "return_code": 10000
    return_msg:''''''
}
```

文档更新时间: 2025-06-26 11:32   作者：张亚飞