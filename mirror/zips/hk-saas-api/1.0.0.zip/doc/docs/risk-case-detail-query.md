#### 简要描述：

1、风控案例详情查询

#### 请求URL:

测试环境：<http://47.95.131.62:8080/api/v1/agent/risk/case/detail>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| caseNo | 案例编号 | String |  | 20230511155524394956750290100 | M |

#### 请求示例:

```
{
    "caseNo": "20230511155524394956750290100",
    "accessid": "4028805b6e86d179016e874f6c4200ad",
    "sign": "975077BFC098C592C721A3948A97460F"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | String 当return\_code不为10000时有值 |  | O |
| data | 返回数据 | JSON | String 当return\_code=10000时有值 |  | O |

#### data参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| legalPhone | 法人手机号 | String | 法人手机号 | 13113151131 | O |
| mercCreateTime | 入网时间 | String | 入网时间 | 2019-12-13 11:35:15 | O |
| cardNo | 卡号 | String | 卡号 |  | O |
| surveyRemark | 风险调查回复 | String | 风险调查回复 |  | O |
| surveyTime | 风险调查时间 | String | 风险调查时间 | 2019-12-13 11:35:15 | O |
| riskTypeNo | 风险编号 | String | 风险编号 |  | O |
| riskTypeRules | 风险类别规则 | String | 风险类别规则 |  | O |
| riskTypeName | 风险类别名称 | String | 风险类别名称 |  | O |
| orders | 案例关联订单 | JSONARRAY | 案例订单信息 |  | O |
| mercName | 商户名称 | String | 山西兴宇装饰工程服务有限公司 |  | O |
| riskTypeLevel | 风险类别风险等级 | String | firstLevel |  | O |
| mercNum | 商户编号 | String | 8331634891201 |  | O |
| agentName | 服务商名称 | String |  |  | O |
| areaCode | 商户所属地区 | String |  | 110101 | O |
| submitTime | 提交资料时间 | String |  | 2019-12-13 11:35:15 | O |
| headSign | 门头照片 | String |  |  | O |
| cityCode | 市代码 | String |  | 110100 | O |
| latitude | 经纬度 | String |  | 经纬度 | O |
| remark | 备注 | String |  | 备注 | O |
| agentNo | 服务商编号 | String |  | 隶属服务商编号 | O |
| typeNo | 风险类别编号 | String |  | T00038 | O |
| flowNodeKey | 流程节点 | String |  |  | O |
| surveyWay | 调查方式 | String |  |  | O |
| provCode | 商户所属省 | String |  | 10000 | O |
| suggest | 调查意见 | String |  | T00038 | O |
| caseNo | 案例编号 | String |  | T0202305051530373944368628081000038 | O |
| createTime | 创建时间 | String |  | 2023-05-05 15:30:37 | O |
| caseDealWay | 案例处理方式 | String |  |  | O |
| fastdfsUrl | 图片地址 | String |  | <https://dfs-test.icardpay.com">, 图片地址前缀 | O |
| auditStatus | 审核状态 | String |  | 待审核 “DSH”;审核中 “SHZ”; 回退”HT”; 审核通过 “SHTG”; | O |
| surveyResult | 调查结果说明 | String |  |  | O |
| mercType | 商户类型 | String |  |  | O |
| others | 其他图片信息 | String |  |  | O |
| firstAgentNo | 一级服务商编号 | String |  |  | O |
| firstAgentName | 一级服务商名称 | String |  |  | O |
| recordList | 审核节点 | String |  |  | O |
| level | 服务商层级 | String |  |  | O |

#### orders:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| cardNo | 交易卡号 | String |  |  | O |
| trxAmt | 交易金额 | String |  |  | O |
| subMerchantNo | 商户号 | String |  |  | O |
| startTrxTime | 交易时间 | String |  |  | O |
| trxType | 交易类型 | String |  |  | O |
| paymentNo | 订单号 | String |  |  | O |
| status | 状态 | String |  |  | O |
| issBankName | 银行名称 | String |  |  | O |
| payType | 支付类型 | String |  |  | O |

#### 返回示例:

```
{
    "data ": [
        {
            "legalPhone": "15235252720", 法人手机号
            "mercCreateTime": "2019-12-13 11:35:15", 入网时间 
            "cardNo": "", 卡号
            "surveyRemark": "", 风险调查回复
            "riskTypeRules": "SR00045", 风险规则编号
            "longitude": "", 经度
            "mercName": "山西兴宇装饰工程服务有限公司", 商户名称
            "mercNum": "833163489120001", 商户编号
            "riskTypeCaseDealWay": "investigate", 商户编号 
            "areaCode": "110101", 商户所属地区
            "referOrders": "", 涉及交易流水号
            "cityCode": "110100", 市代码
            "latitude": "", 纬度
            "remark": "", 备注
            "agentNo": "FW1000161", 服务商编号
            "typeNo": "T00038", 类别编号
            "legalPerson": "索亦荣", 法人姓名
            "flowNodeKey": "SAASSH", SAASSH：SAAS审核 
            "surveyWay": "", 调查方式
            "provCode": "110000", 商户所属省
            "suggest": "", 商户处理建议
            "caseNo": "20230505153037394436862808100", 案例编号
            "createTime": "2023-05-05 15:30:37", 创建时间
            "caseDealWay": "investigate", 案例处理方式
            "auditStatus": "DSH", 审核状态
            "createWay": "", 案例生成方式
            "surveyResult": "", 调查结果说明
            "termNo": "CHT0092930", 终端号
            "firstAgentNo": "FW1000161", 一级服务商编号
            "firstAgentName": "张亚飞测试测试", 一级服务商名称
            "agentName": "张亚飞测试测试", 服务商名称
            "surveyTime": {}, 风险调查时间
            "submitTime": {}, 提交资料时间
            "level": "1级服务商编号：FW1000161" 服务商层级
        }
    ],
    "return_code": 10000
}
```

文档更新时间: 2025-06-03 10:15   作者：张亚飞