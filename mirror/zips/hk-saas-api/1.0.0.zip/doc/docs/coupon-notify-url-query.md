#### 概要描述:

通过此接口查询营销事件通知的回调URL地址。

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/front-api/wx-coupon/query-callbacks>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

#### 请求示例:

```
{
    "agent_no": "IS88888888",
    "req_id": "147258369",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表成功 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| notify\_url | 通知地址 | String | 同请求参数 |  | M |

#### 返回示例:

```
{
  "result_msg": "请求成功",
  "sign": "EC585176B1E0DFBEF01A2126CD1A303F",
  "result_code": "10000",
  "return_msg": "成功",
  "notify_url": "http://www.baidu.com",
  "return_code": "SUCCESS"
}
```

文档更新时间: 2025-02-13 09:50   作者：王思阳