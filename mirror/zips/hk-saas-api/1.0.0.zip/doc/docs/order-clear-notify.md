### 订单清分成功异步通知API

**通知地址**  
通知的地址为发起支付交易的时候上送的notify\_url。

**通知策略**  
订单清分完成后，SaaS会把相关清分结果发送给商户，商户需要接收处理，并返回应答。对后台通知交互时，如果SaaS收到商户的应答不是成功或超时，SaaS认为通知失败，SaaS会通过一定的策略定期重新发起通知,请服务商系统做好幂等处理。尽可能提高通知的成功率，但不保证通知最终能成功。(通知频率为15/15/30/180/1800/1800/1800/1800/3600，单位：秒)

如果异步通知的状态与查询接口的返回存在不一致，以查询接口的返回为准。

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科商户编号 |  | M |
| total\_amount | 交易金额 | String(12) | 上送银联的交易金额（单位：元,支持2位小数） |  | M |
| order\_amount | 订单金额 | String | 订单总金额（单位：元,支持2位小数） |  | M |
| discount\_amount | 免充值优惠券金额 | String | 不走结算资金的免充值型优惠券金额（单位：元,支持2位小数） |  | O |
| pay\_type | 支付类型 | String | WX：微信支付 ALI：支付宝支付 UNIONQR：云闪付 |  | M |
| pay\_mode | 支付方式 | String | NATIVE：扫码支付 JSAPI：JSAPI支付 BARPAY：付款码支付 |  | M |
| out\_trade\_no | 服务商支付订单号 | String |  |  | M |
| trade\_no | 海科支付订单号 | String |  |  | M |
| trade\_status | 交易状态 | String | 1：交易成功 2：交易失败 3：交易进行中 |  | M |
| clear\_status | 清算状态 | String | 1：已清算 2：未清算 | 固定是1 | M |
| real\_fee\_amount | 实收手续费金额 | String | 实收手续费金额（单位：元,支持2位小数） clear\_status=1时返回 |  | M |
| fee\_subsidy\_amount | 手续费补贴金额 | String | 手续费补贴金额（单位：元,支持2位小数） 有手续费补贴且clear\_status=1时返回 |  | O |
| market\_subsidy\_amount | 营销补贴金额 | String | 营销补贴金额（单位：元,支持2位小数） 有营销补贴且clear\_status=1时返回 |  | O |
| settle\_amount | 交易结算金额 | String | 交易结算金额（单位：元,支持2位小数） clear\_status=1时返回 |  | M |
| trade\_rate | 交易费率 | String | 交易费率，单位：% clear\_status=1时返回 | 0.38 | M |
| appid | 公众账号ID | String | 微信支付时使用的公众账号 ID |  | O |
| openid | 用户标识 | String | 用户标识 |  | O |
| sub\_mch\_id | 报备商户编号 | String | 通道子商户号（ATU商户号） |  | M |
| end\_time | 交易完成时间 | String | 交易在海科的完成时间 | 2024-01-01 10:10:10 | M |
| pn | SAAS终端号 | String(32) | SAAS终端号 |  | M |
| settle\_way | 交易结算方式 | String | 交易结算方式 |  | M |
| bank\_trade\_no | 银联订单号 | String | 银联订单号 |  | M |
| card\_type | 卡类型 | String(10) | 01：借记卡 02：贷记卡 |  | O |
| remark | 备注 | String(100) | 交易备注，原交易请求时上送的备注信息 |  | O |
| activity\_id | 官方活动id | String(100) | 国补：UN\_SUBSIDY |  | O |
| hk\_activity\_id | 海科活动id | String(100) | 海科活动id |  | O |
| attach | 通道原生参数 | String |  |  | O |

#### 请求示例:

```
{
    "discount_amount": "0.00",
    "sign": "2BB9386345E71D80363CDDFD542C6001",
    "agent_no": "FW3002100",
    "pay_mode": "BARPAY",
    "out_trade_no": "640000200704218151",
    "total_amount": "1.01",
    "settle_amount": "0.71",
    "order_amount": "1.01",
    "clear_status": "1",
    "real_fee_amount": "0.30",
    "fee_subsidy_amount": "0.20",
    "market_subsidy_amount": "3",
    "trade_rate": "0.38",
    "trade_status": "1",
    "trade_no": "WX240411110602000615748248",
    "bank_trade_no": "4200002157202404112867871702",
    "sub_mch_id": "626185853",
    "end_time": "2024-04-11 11:06:04",
    "pay_type": "WX",
    "pn": "A00000001",
    "settle_way": "D1",
    "attach": "{
        \"transaction_id\": \"4200002157202404112867871702\",
        \"nonce_str\": \"ee4cd0486b434934b61b3fd4e088b2c5\",
        \"trade_state\": \"SUCCESS\",
        \"bank_type\": \"COMM_CREDIT\",
        \"openid\": \"sdfgSjkOdekjshjMHp7efaeBmjU\",
        \"cert_id\": \"4233741533\",
        \"return_msg\": \"成功\",
        \"fee_type\": \"CNY\",
        \"mch_id\": \"1505378701\",
        \"sub_mch_id\": \"626185853\",
        \"cash_fee\": \"101\",
        \"out_trade_no\": \"WX240411110602000615748248\",
        \"cash_fee_type\": \"CNY\",
        \"coupon_fee\": \"0\",
        \"appid\": \"wx17728c1a8fa300d6\",
        \"total_fee\": \"101\",
        \"settlement_total_fee\": \"101\",
        \"trade_type\": \"MICROPAY\",
        \"result_code\": \"SUCCESS\",
        \"time_end\": \"20240411110604\",
        \"sign_type\": \"SM2\",
        \"return_code\": \"SUCCESS\"
    }"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回状态码 | String(16) | SUCCESS/FAIL SUCCESS表示商户接收通知成功并校验成功 |  | M |
| return\_msg | 返回信息 | String(128) | 当return\_code为FAIL时返回信息为错误原因 |  | O |

#### 返回示例:

```
{
    "return_code": "SUCCESS"
}
```

文档更新时间: 2025-12-18 14:11   作者：陈文