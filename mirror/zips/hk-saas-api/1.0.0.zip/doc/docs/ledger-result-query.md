### 查询订单API

**业务功能**  
根据服务商订单号或者平台订单号查询平台的具体订单信息。  
**交互模式**  
后台系统调用交互模式  
**测试url：**  
<http://47.95.131.62:8080/api/v1/pay/polymeric/queryledger>

**请求参数(O-非必传 ,M-必传):**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| trade\_no | 交易订单号 | String | trade\_no和out\_trade\_no必传其中一个，两个都传则以trade\_no为准，推荐使用trade\_no |  | O |
| out\_trade\_no | 服务商交易订单号 | String | 服务商的交易订单编号 | 161018121614000624679888 | O |
| channel\_trade\_no | 凭证条码订单号 | String | 凭证条码订单号(v1.24增加) | 161018121614000624679888 | O |

#### 请求示例:

```
{{"accessid":"4028805b7cb551ee017cb562c073003a","sign":"BBC5F3AFB034CF1BCC781A7813FDCE81","trade_no":"AL211129163210240811973525"}}
```

**返回参数:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| error\_code | 错误码 | String |  |  | M |
| error\_msg | 错误消息 | String |  |  | O |
| agent\_no | 服务商编号 | String | 服务商编号 |  | M |
| merch\_no | 商户编号 | String | (v1.16增加) |  | M |
|
| trade\_no | 交易订单号 | String | SaaS平台的交易订单编号 |  | M |
| out\_trade\_no | 服务商交易订单号 | String | 服务商的交易订单编号 | 161018121614000624679888 | M |
| channel\_trade\_no | 凭证条码订单号 | String | 凭证条码订单号(v1.24增加) | 161018121614000624679888 | M |
| ledger\_amount | 分账总金额 | String | 订单总金额，以元为单位 | 100 | M |
| status | 分账状态 | String | 固定为0（成功） | 0 | M |
| ledger\_relation | 分账交易关系组 | jsonArray | 分账交易关系组 | 分账交易关系组 | M |
| receive\_no | 收账方商户号 | String | 收账方商户号 |  | 收账方商户号 |
| amt | 接受分账金额 | String | 接受分账金额 |  | O |

#### 返回示例:

```
{{"agent_no":"FW1000566","merch_no":"833102354620068","out_trade_no":"210802212","channel_trade_no":"011321112916321907971MC","trade_no":"AL211129163210240811973525","ledger_amount":0.01,"status":"0","ledger_relation":[{"receive_no":"833102354620071","amt":"0.01"}],"return_code":10000,"sign":"2B4F24BAFF4A9942DC3D266FB533BD1A"}}
```

文档更新时间: 2024-11-29 10:14   作者：王金晶