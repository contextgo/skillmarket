#### 概要描述:

微信发放代金券接口。  
通过调用此接口可发放指定批次给指定用户，发券场景可以是小程序、H5、APP等。

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/front-api/wx-coupon/send-coupon>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| openid | 用户标识 | String(128) | 用户openId |  | M |
| appid | appid | String(64) | appid |  | O |
| stock\_id | 卡券批次id | String(64) | 微信为每个批次分配的唯一id |  | M |
| out\_request\_no | 商户单据号 | String(128) | 商户单据号，格式：商户id+日期+流水号 |  | M |

#### 请求示例:

```
{
  "agent_no": "FW88888888",
  "stock_id": "19716664",
  "out_request_no": "12332222",
  "openid": "oc5mSjkOsuwebcasde7efa2Bmj1",
  "appid": "wx171234567891234566",
  "req_id": "@id",
  "sign": "12345678"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表成功 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| coupon\_id | 代金券id | String | result\_code 为成功时返回 |  | O |

#### 返回示例:

```
{
  "result_msg": "请求成功",
  "coupon_id": "80219025353",
  "sign": "55F866EAEB0019282CDB14207CB07ACC",
  "result_code": "10000",
  "return_msg": "成功",
  "return_code": "SUCCESS"
}
```

文档更新时间: 2025-02-13 09:50   作者：王思阳