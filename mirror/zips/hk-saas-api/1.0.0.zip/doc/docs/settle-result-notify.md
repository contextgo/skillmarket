#### 请求URL:

服务商线下提供接收通知地址，由运营人员维护通知地址，结算结果成功、失败均通知；

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 商户编号 | String |  |  | M |
| remit\_Amount | 结算金额 | String | 单位元 |  | M |
| settle\_day | 结算日期 | String | 生成日期YYYY-MM-DD |  | M |
| fail\_reason | 失败原因 | String |  |  | O |
| merchant\_order\_No | 结算订单号 | String |  |  | M |
| remit\_status | 出款状态 | String | 打款成功、打款失败 |  | M |
| update\_time | 更新时间 | String | YYYY-MM-DD hh:mm:ss |  | M |
| remark | 备注 | String |  |  | O |
| trade\_no | 交易订单号 | String | TS结算时该字段有值 |  | O |
| channelFlag | 打款通道 | String | CUP：银联、NUCC：网联 |  | O |
| btxnNo | 通道流水号 | String | 银行入账流水号，用于与银行间查询结算流水 |  | O |
| settlementCycle | 结算方式 | String | 例如：T1/D1 等 |  | O |
| fee | 结算手续费 | String | 单位元 |  | O |
| realAmount | 实际到账金额 | String | 单位元 |  | O |
| cardNo | 银行卡号 | String | 前6后4，脱敏 |  | O |
| bankName | 银行名称 | String |  |  | O |
| accName | 账户名称 | String |  |  | O |

#### 返回示例:

```
{
    "merch_no": "833112200123456",
    "fee": "0.00",
    "settle_day": "2025-12-02",
    "accName": "常**",
    "agent_no": "ISV123456",
    "remark": "00:成功[00000000000][通知]",
    "bankName": "天津银行",
    "channel_flag": "CUP",
    "cardNo": "621452********1234",
    "merchant_order_No": "WX123456789123456789",
    "realAmount": "10.00",
    "update_time": "2025-12-02 10:54:47",
    "remit_Amount": "10.00",
    "trade_no": "WX123456789123456789",
    "btxn_no": "22011220011",
    "settlementCycle": "Ts",
    "fail_reason": "00:成功[00000000000][通知]",
    "remit_status": "打款成功"
}
```

文档更新时间: 2025-12-02 11:07   作者：常兴宇Stark