#### 概要描述:

当服务商提交申请单后，需要定期调用此接口查询申请单的审核状态。

* 注：使用海科渠道号的服务商必须调用该接口；使用自己主体渠道号的服务商，可以调用该接口或直接调用微信官方认证接口均可完成微信二次认证。  
  微信官方接口链接如下：<https://pay.weixin.qq.com/wiki/doc/apiv3_partner/apis/chapter10_1_3.shtml>

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/wx-auth/query-apply-status>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| apply\_no | 申请单编号 | String | apply\_no和business\_code二选一上送 |  | O |
| business\_code | 服务商申请单号 | String | apply\_no和business\_code二选一上送 |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "business_code": "356771679469",
    "sign": "36EE79FD2E36527F5A75D58E40C9FEC4"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String |  |  | O |
| applyment\_state | 申请单状态 | String | APPLYMENT\_STATE\_WAITTING\_FOR\_AUDIT-【审核中】：请耐心等待1~2个工作日，微信支付将会完成审核。 APPLYMENT\_STATE\_EDITTING-【编辑中】：可能提交申请发生了错误导致，可用同一个业务申请编号重新提交。 APPLYMENT\_STATE\_WAITTING\_FOR\_CONFIRM\_CONTACT-【待确认联系信息】：请扫描微信支付返回的小程序码确认联系信息(此过程可修改超级管理员手机号)。 APPLYMENT\_STATE\_WAITTING\_FOR\_CONFIRM\_LEGALPERSON-【待账户验证】：请扫描微信支付返回的小程序码在小程序端完成账户验证。 APPLYMENT\_STATE\_PASSED-【审核通过】：请扫描微信支付返回的小程序码在小程序端完成授权流程。 APPLYMENT\_STATE\_REJECTED-【审核驳回】：请按照驳回原因修改申请资料，并更换业务申请编码，重新提交申请。 APPLYMENT\_STATE\_FREEZED-【已冻结】：可能是该主体已完成过入驻，请查看驳回原因，并通知驳回原因中指定的联系人扫描微信支付返回的小程序码在小程序端完成授权流程。 APPLYMENT\_STATE\_CANCELED-【已作废】：表示申请单已被撤销，无需再对其进行操作。 |  | M |
| qrcode\_data | 小程序码图片 | String | 1、当申请单状态为APPLYMENT\_STATE\_WAITTING\_FOR\_CONFIRM\_CONTACT、APPLYMENT\_STATE\_WAITTING\_FOR\_CONFIRM\_LEGALPERSON、APPLYMENT\_STATE\_PASSED、APPLYMENT\_STATE\_FREEZED时，会返回小程序码图片。 2、使用base64解码该字段，可得到图片二进制数据。 3、可用img标签直接加载该图片。 |  | M |
| reject\_param | 驳回参数 | String | 当申请单状态为“审核驳回”时，会返回该字段，标识被驳回的字段名。 |  | M |
| reject\_reason | 驳回原因 | String | 当申请单状态为“审核驳回”时，会返回该字段，表示驳回原因。 |  | M |

#### 返回示例:

```
{
    "return_msg": "查询成功",
    "return_code": 10000,
    "applyment_state": "APPLYMENT_STATE_PASSED",
    "qrcode_data": "cGFnZXMvYXBwbHkvYXBpdzQvd2VsY29tZS93ZWxjb21lP2FwcGx5bWVudF9pZD14eHg=",
    "reject_param": "merchant_name",
    "reject_reason": "公司名称与工商局登记不一致"
    "sign": "74D55ACA6A2698290542DF709BB966B2"
}
```

文档更新时间: 2024-11-29 10:08   作者：admin