#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/merchant-image/video-upload>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| video | 视频文件 | String | 视频转成base64后的数据 |  | M |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "video": "imgToBase64data...",
    "sign": "91741FA7910DC5EB2B325130BDBA1164"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| videoId | 视频id | String | 视频id | image12345 | O |

#### 返回示例:

```
{"reqData":{"accessid":"cpostest","sign":"402432F5366156BA11E81E0A30A5CF8C"},"respData":{"videoId":"6ea605328e93413190cac49dd7965e59","return_code":10000,"sign":"216E9A00BFEA61B76D34035C2234BF86"}}
```

文档更新时间: 2025-06-26 11:32   作者：admin