#### 简要描述：

1、调单数据查询

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/agent/risk/dispatch/list>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 样例 | 类型 | 参数说明 | 名称 | 可空 |
| --- | --- | --- | --- | --- | --- |
| dispatchNum |  | String |  | 风险调单号 | O |
| accessid |  | String |  | 服务商标识 | O |
| mercNum |  | String |  | 商户号 | O |
| caseNo |  | String |  | 交易卡号 | O |
| agentNum |  | String |  | 所属服务商编号 | O |
| mercNameLike |  | String |  | 商户名称 | O |
| firstAgentNameLike |  | String |  | 一级服务商名称 | O |
| agentNameLike |  | String |  | 所属服务商名称 | O |
| agentType |  | String |  | 服务商类型 | O |
| dispatchStatus |  | String |  | 单据状态 | O |
| dispatchType |  | String |  | 调单类别 | O |
| disabledState |  | String |  | 注销状态 | O |
| payType |  | String |  | 交易方式 | O |
| orgName |  | String |  | 分公司 | O |
| transDatBegin |  | String |  | 交易完成时间 | O |
| transDatEnd |  | String |  | 交易完成时间 | O |
| bankFirstDateBegin |  | String |  | 交易完成时间 | O |
| bankFirstDateEnd |  | String |  | 银行首发日 | O |
| bankLastDateBegin |  | String |  | 银行首发日 | O |
| bankLastDateEnd |  | String |  | 最后期限日 | O |
| createTimeBegin |  | String |  | 创建时间 | O |
| createTimeEnd |  | String |  | 创建时间 | O |
| page |  | String |  | 页码 | O |
| rows |  | String |  | 每页条数 | O |

#### 请求示例:

```
{
   "caseNo": "20230511155524394956750290100",
   "mercNum": "833588696325",
   "page": 1,
   "rows": 10,
   "accessid": "4028805b6e86d179016e874f6c4200ad",
   "sign": "975077BFC098C592C721A3948A97460F"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| data | 返回数据 | JSON | 当return\_code=10000时有值 |  | O |

#### data参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| total | 全部 | String | 5 |  | M |
| rows | 案例列表 | JSONArray |  |  | O |

#### rows参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agentName | 服务商名称 | String |  | 青岛亿清圆劳务工程有限公司 | O |
| agentNum | 服务商编号 | String |  | ISV005464 | O |
| agentType | 服务商类型 | String |  | ISV | O |
| areaname | 地区名称 | String |  | 湖里区 | O |
| bankFirstDate | 银行首发日 | String |  | 2025-04-23 00:00:00 | O |
| bankLastDate | 最后期限 | String |  | 2025-05-08 00:00:00 | O |
| bankMerchantNo | 银行商户号 | String |  | 83339337372H0AA | O |
| billInfoImgs | 小票信息 | String |  |  | O |
| cardNo | 交易卡号 | String |  | 6225750024166940 | O |
| certificateBackImgs | 身份证反面 | String |  |  | O |
| certificateFrontImgs | 身份证正面 | String |  |  | O |
| cityname | 市代码 | String |  | 厦门市 | O |
| createTime | 操作日期 | String |  | 2025-04-24 15:35:40 | O |
| disabledBy | 注销人 | String |  |  | O |
| disabledReason | 注销原因 | String |  |  | O |
| disabledState | 注销状态 | String |  | normal | O |
| dispatchAnnotation | 调单注释 | String |  | 调取签购单、商户名称、地址、电话 | O |
| dispatchCode | 调单原因码 | String |  | 6303 | O |
| dispatchNum | 调单编号 | String |  | 20250424153539010001 | O |
| dispatchStatus | 单据状态 | String |  | DCL | O |
| dispatchType | 调单类型 | String |  | dispatch | O |
| firstAgentName | 一级代理商名称 | String |  | 青岛亿清圆劳务工程有限公司 | O |
| firstAgentNum | 一级代理商编号 | String |  | ISV005464 | O |
| id |  | String |  | 363 | O |
| importTransTime | 导入交易时间 | String |  | 2025-02-03 00:00:00 | O |
| issName | 发卡行 | String |  | 招商银行 | O |
| legalPhone | 商户手机号 | String |  | 13559660562 | O |
| mercName | 商户名称 | String |  | 厦门盟旧照科技有限公司 | O |
| mercNum | 商户编号 | String |  | 833393373722980 | O |
| orgName | 分公司 | String |  | 机构合作部 | O |
| paymentNo | 交易流水号 | String |  | UN2502031351050000963936068 | O |
| provincename | 省 | String |  | 福建省 | O |
| realAmount | 持卡人实付金额 | String |  | 1350.00 | O |
| remark | 备注 | String |  |  | O |
| startOrg | 发起机构 | String |  | 03080010 | O |
| startTrxTime | 交易时间 | String |  | 2025-02-03 13:51:05 | O |
| sysRefNum | 银联流水号 | String |  | UN2502031351050000963936068 | O |
| thirdorderid | 上游订单号 | String |  | 48330000000499921240760203135342 | O |
| tradeCardBackImgs | 交易卡反面 | String |  |  | O |
| tradeCardFrontImgs | 交易卡正面 | String |  |  | O |
| tradeProImgs | 交易证明 | String |  |  | O |
| trxAmt | 持卡人发起金额 | String |  | 1350.00 | O |
| trxSource | 交易方式 | String |  | 银联二维码 | O |
| trxType | 是否双免 | String |  | 否 | O |
| updateBy | 操作人 | String |  | luosijia | O |
| updateTime |  | String |  | 2025-04-24 15:35:40 | O |

#### 返回示例:

```
{
    Return_code :10000
    Rows:[{
    "agentName": "青岛亿清圆劳务工程有限公司",
    "agentNum": "ISV005464",
    "agentType": "ISV",
    "areaname": "湖里区",
    "bankFirstDate": "2025-04-23 00:00:00",
    "bankLastDate": "2025-05-08 00:00:00",
    "bankMerchantNo": "83339337372H0AA",
    "billInfoImgs": "",
    "cardNo": "6225750024166940",
    "certificateBackImgs": "",
    "certificateFrontImgs": "",
    "cityname": "厦门市",
    "createTime": "2025-04-24 15:35:40",
    "disabledBy": "",
    "disabledReason": "",
    "disabledState": "normal",
    "dispatchAnnotation": "调取签购单、商户名称、地址、电话",
    "dispatchCode": "6303",
    "dispatchNum": "20250424153539010001",
    "dispatchStatus": "DCL",
    "dispatchType": "dispatch",
    "firstAgentName": "青岛亿清圆劳务工程有限公司",
    "firstAgentNum": "ISV005464",
    "id": "363",
    "importTransTime": "2025-02-03 00:00:00",
    "issName": "招商银行",
    "legalPhone": "13559660562",
    "mercName": "厦门盟旧照科技有限公司",
    "mercNum": "833393373722980",
    "orgName": "机构合作部",
    "paymentNo": "UN2502031351050000963936068",
    "provincename": "福建省",
    "realAmount": "1350.00",
    "remark": "",
    "startOrg": "03080010",
    "startTrxTime": "2025-02-03 13:51:05",
    "sysRefNum": "UN2502031351050000963936068",
    "thirdorderid": "48330000000499921240760203135342",
    "tradeCardBackImgs": "",
    "tradeCardFrontImgs": "",
    "tradeProImgs": "",
    "trxAmt": "1350.00",
    "trxSource": "银联二维码",
    "trxType": "否",
    "updateBy": "luosijia",
    "updateTime": "2025-04-24 15:35:40"
}]
}
```

文档更新时间: 2025-04-30 11:17   作者：张亚飞