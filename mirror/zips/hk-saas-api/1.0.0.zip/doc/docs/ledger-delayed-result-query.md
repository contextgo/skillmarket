### 分账请求后，使用请求单号查询分账结果

**业务功能**  
延迟分账订单请求单次分账后，使用服务商请求单号进行分账结果查询  
分账中状态可进行状态确认,意为补单  
**交互模式**  
请求：后台请求交互模式  
返回结果：后台请求交互模式  
**测试url：**  
<http://47.95.131.62:8080/api/v1/delay-ledger/query-by-applyno>

**请求参数(O-非必传 ,M-必传):**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 服务商的编号，由SaaS平台分配，表示当前商户属于该服务商名下 | ISV01991023 | M |
| merch\_no | 商户编号 | String | 商户在SaaS平台的编号 | a10253390 | M |
| trade\_no | 交易交易订单号 | String | saas订单号 |  | M |
| apply\_no | 请求订单号 | String | 服务商分账请求订单号 | 161018121614000624679888 | M |

#### 请求示例:

```
{
    "agent_no": "FW1000566",
    "merch_no": "833451158120001",
    "trade_no": "AL221215155407099383691588",
    "apply_no": "2022121501630",
    "accessid": "4028805b7cb551ee017cb562c073003a",
    "sign": "AB0CFC6B9983A93C456CFCD44DA34786"
}
```

**返回参数:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 服务商的编号，由SaaS平台分配，表示当前商户属于该服务商名下 | ISV01991023 | M |
| merch\_no | 商户编号 | String | 商户在SaaS平台的编号 | a10253390 | M |
| trade\_no | SAAS交易订单号 | String | saas订单号 |  | M |
| apply\_no | 请求订单号 | String | 服务商分账请求订单号（同一服务商下唯一） | 161018121614000624679888 | M |
| ledger\_no | 分账订单号 | String | SAAS分账订单号 |  | M |
| ledger\_relation | 分账结果 | JSONArray | receive\_no：分账接收方 amt:分账金额 remark：分账备注 result:分账结果（int 0：失败 1：成功 2:分账中） ledger\_detail\_id：分账明细标识 end\_time：分账完成时间 | [ { "receive\_no": "833102158120726", "amt": 0.01, "remark": "", "result": 1, "ledger\_detail\_id": "230104054710259914380846", "end\_time": "2023-01-04 05:47:10" } ] | M |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |

#### 返回示例:

```
{
    "trade_no": "AL221555450963671588",
    "agent_no": "FW20302182",
    "merch_no": "83362141230001",
    "apply_no": "2022121501630",
    "ledger_no": "22124542495150585578",
    "ledger_relation": [
        {
            "receive_no": "833121553310081",
            "amt": 0.02,
            "remark": "测试1",
            "result": 1,
            "ledger_detail_id": "221215163145986527195901",
            "end_time": ""
        }
    ],
    "return_code": 10000,
    "sign": "1F2DC2A0FFF427B691D350687DB84518"
}
```

文档更新时间: 2024-11-29 10:14   作者：张亚飞