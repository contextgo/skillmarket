### 核销事件回调通知

**通知地址**  
通知的地址为服务商设置的notify\_url。

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| attach | 通道原生参数 | String | 微信通道原生异步通知参数 |  | M |

#### 请求示例:

```
{
    "agent_no": "FW3002100",
    "sign": "9B2CED3414EAECC1C0BEA09941C63BEA",
    "attach": "{
        \"stock_creator_mchid\": \"1505378701\",
        \"stock_id\": \"19719754\",
        \"coupon_id\": \"80219081353\",
        \"coupon_name\": \"代金券0.1\",
        \"status\": \"USED\",
        \"description\": \"\",
        \"create_time\": \"2024-11-07T16:10:29+08:00\",
        \"coupon_type\": \"NORMAL\",
        \"no_cash\":false,
        \"available_begin_time\": \"2024-11-07T00:00:00+08:00\",
        \"available_end_time\": \"2025-02-01T23:59:59+08:00\",
        \"singleitem\":false,
        \"normal_coupon_information\":{
            \"coupon_amount\":10.0,
            \"transaction_minimum\":20.0
        },
        \"consume_information\":{
            \"consume_time\":\"2024-11-12T15:52:59+08:00\",
            \"consume_mchid\":\"1500947831\",
            \"transaction_id\":\"4200002561202411121723927860\"
        }
    }"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回状态码 | String(16) | SUCCESS/FAIL SUCCESS表示商户接收通知成功并校验成功 |  | M |
| return\_msg | 返回信息 | String(128) | 当return\_code为FAIL时返回信息为错误原因 |  | O |

#### 返回示例:

```
{
    "return_code": "SUCCESS"
}
```

文档更新时间: 2025-02-13 09:50   作者：王思阳