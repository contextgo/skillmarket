### （非定向）获取银联用户标识API

**业务功能**  
获取用户在银联的唯一标识，用于银联js支付下单。  
**交互模式**  
服务商使用**POST请求**的方式进行请求本接口，haipay返回银联用户标识  
**测试url：**  
<http://47.95.131.62:8080/api/v1/pay/uniqr/direct/getUserId>

**请求参数(O-非必传 ,M-必传):**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| userAuthCode | 授权码 | String |  |  | M |
| appUpIdentifier | 银联支付标识 | String |  |  | M |

appUpIdentifier 规则:

从请求头里面获取user-agent对应的值，然后参考下面代码的处理

```
public String getAppUpIdentifier(String userAgent){
    logger.info("获取银联支付标识str:{}",userAgent);
    userAgent = userAgent.substring(userAgent.indexOf("UnionPay/")+9);
    String version=userAgent.substring(0,userAgent.indexOf(" ")+1);
    String app="";
    String regEx = "\\S\\W";
    Pattern p = Pattern.compile(regEx);
    Matcher m = p.matcher(userAgent.substring(userAgent.indexOf(" ")+1));
    if (m.find()) {
        app =userAgent.substring(userAgent.indexOf(" ")+1).substring(0,m.end()-1);
    }else{
        app = userAgent.substring(userAgent.indexOf(" ")+1);
    }
    logger.info("获取银联支付标识返回:{}","UnionPay/"+version+app);
    return "UnionPay/"+version+app;
}
```

#### 请求示例:

```
{

    "userAuthCode": "0783************ftQj",
    "appUpIdentifier": "UnionPay"
}
```

**返回参数:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| userId | 用户标识 | String | 用户在银联平台的唯一标识 |  | M |

#### 返回示例:

```
{
    "return_code": "10000",
    "return_msg": "成功",
    "userId": "alg6aklsdksjlgwjirg**********jkhfjksd"
}
```

文档更新时间: 2024-12-05 18:02   作者：admin