#### 概要描述:

可通过该接口查询用户在某商户号可用的全部券，可用于商户的小程序/H5中，用户”我的代金券”或”提交订单页”展示优惠信息。无法查询到微信支付立减金。本接口查不到用户的微信支付立减金（又称“全平台通用券”），即在所有商户都可以使用的券，例如：摇摇乐红包；当按可用商户号查询时，无法查询用户已经核销的券。

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/front-api/wx-coupon/list-coupons>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| openid | 用户标识 | String(128) | 用户openId |  | M |
| appid | appid | String(64) | appid |  | M |
| stock\_id | 卡券批次id | String(20) | 微信为每个批次分配的唯一id |  | C |
| status | 券或消费金状态 | String(6) | 代金券或消费金状态：选填creator\_mchid时， SENDED：返回可用 USED：返回可用+已实扣 选填available\_mchid时，该字段不生效，仅返回 可用 状态的券或消费金。 |  | C |
| stock\_creator\_mchid | 创建批次的商户号 | string(20) | 批次创建方商户号。请求参数传创建商户号返回除过期以外所有状态的用户券。stock\_creator\_mchid与available\_mchid二选一，如果同时存在，优先使用stock\_creator\_mchid。 |  | C |
| available\_mchid | 可用商户号 | string(20) | 可用商户号请求参数传可用商户号只能返回可用的代金券，实扣的与过期的无法返回。stock\_creator\_mchid与available\_mchid二选一，如果同时存在，优先使用stock\_creator\_mchid。 |  | C |
| offset | 分页页码 | int | 分页页码，默认0，填写available\_mchid，该字段不生效 |  | C |
| limit | 分页大小 | int | 分页大小，默认20，填写available\_mchid，该字段不生效 |  | C |
| business\_type | 业务类型 | int | 若选择MULTIUSE，则仅返回查询用户拥有的消费金列表 枚举值：MULTIUSE：消费金 |  | C |

#### 请求示例:

```
{
  "agent_no": "FW3002100",
  "stock_id": "88888888",
  "openid": "oc5mSjkOsuwebcasde7efa2Bmj1",
  "appid": "wx171234567891234566",
  "available_mchid": "123124523",
  "offset": "1",
  "limit": "10",
  "req_id": "@id",
  "sign": "8888888888888888888888"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表成功 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| offset | 分页页码 | int | 分页页码 |  | M |
| limit | 分页大小 | int | 分页大小 |  | M |
| total\_count | 查询结果总数 | int | 查询结果总数 |  | M |
| data | 结果集 | JSONArray | 结果集 |  | M |

#### 返回示例:

```
{
  "sign": "9E7EC1422ED7BB28E6077C44661299A3",
  "result_code": "10000",
  "return_code": "SUCCESS",
  "data": [{
        "stock_creator_mchid": "9800064",
        "stock_id": "9865888",
        "coupon_id": "98674556",
        "cut_to_message": {
            "single_price_max": 100,
            "cut_to_price": 80
        },
        "coupon_name": "微信支付代金券",
        "status": "EXPIRED",
        "description": "微信支付营销",
        "create_time": "2015-05-20T13:29:35.120+08:00",
        "coupon_type": "CUT_TO",
        "no_cash": false,
        "available_begin_time": "2015-05-20T13:29:35.120+08:00",
        "available_end_time": "2015-05-20T13:29:35.120+08:00",
        "singleitem": false,
        "normal_coupon_information": {
            "coupon_amount": 100,
            "transaction_minimum": 100
        },
        "out_request_no": "example_out_request_no",
        "available_balance": 10000,
        "business_type": "MULTIUSE"
    }],
    "total_count": 100,
    "limit": 10,
    "offset": 10
}
```

文档更新时间: 2025-02-13 09:50   作者：陈文