#### 概要描述:

该接口用于查询商户收单协议的签约结果。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/agreement-merchant-sign/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 服务商编号 | ISV01991023 | M |
| merch\_no | 商户编号 | String | 商户在SaaS平台的编号 | 88888888 | M |
| contract\_no | 合同编号 | String | 合同编号 | 321321312 | M |

#### 返回参数:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 | 1000 | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| agent\_apply\_no | 服务商申请单编号 | String | 服务商申请单编号 |  | O |
| contract\_no | 合同编号 | String | 合同编号 |  | O |
| url | 电子签章地址 | String | 电子签章地址 |  | O |
| merch\_no | 商户号 | String | 商户号 |  | O |
| status | 电签状态 | String | 电签状态 | 0：未签约  1：已签约  2：签约失败 | O |

文档更新时间: 2024-11-29 10:10   作者：张亚飞