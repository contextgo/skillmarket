## 微信-回复用户

### 基本信息

**Path：** /api/v1/complaint/wechat/replyUser

**Method：** POST

**接口描述：**

### 备注

### 请求参数

**Headers**

| 参数名称 | 参数值 | 是否必须 |
| --- | --- | --- |
| Content-Type | application/json | 是 |

**Body**

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| complaintId | string | 必须 |  | 投诉单号 |  |
| complaintedMchid | string | 必须 |  | 被诉商户号 |  |
| responseContent | string | 必须 |  | 【回复内容】 具体的投诉处理方案，限制200个字符以内。 |  |
| responseImages | string [] | 非必须 |  | 【回复图片】 传入调用“商户上传反馈图片”接口返回的media\_id，最多上传4张图片凭证 | item 类型:  string |
|  |  | 非必须 |  |  | 备注: |
| jumpUrl | string | 非必须 |  | 【跳转链接】 商户可在回复中附加跳转链接，引导用户跳转至商户客诉处理页面，链接需满足HTTPS格式。注：配置文字链属于灰度功能，若有需要请联系对接的行业运营进行咨询。 |  |
| jumpUrlText | string | 非必须 |  | 【跳转链接文案】 实际展示给用户的文案，附在回复内容之后。用户点击文案，即可进行跳转。 注：若传入跳转链接，则跳转链接文案为必传项，二者缺一不可。 |  |
| miniProgramJumpInfo | object | 非必须 |  | 跳转链接文案 | 备注:  跳转链接文案 |
| appid | string | 必须 |  | 跳转小程序APPID |  |
| path | string | 必须 |  | 跳转小程序页面PATH |  |
| text | string | 必须 |  | 跳转小程序页面名称 |  |

### 请求示例

```
{
  "accessid": "4028803d6a97099f016a9b3d8f57000f",
  "signKey": "fa907d6e05cc4869a3330add779e9ff7",
  ...
}
```

### 返回数据

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| rspCode | string | 必须 |  | 返回码 |  |
| rspMsg | string | 必须 |  | 返回信息 |  |

文档更新时间: 2024-11-19 15:14   作者：胡闽川