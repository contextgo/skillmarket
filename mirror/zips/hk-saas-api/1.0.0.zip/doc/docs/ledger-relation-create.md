#### 简要描述：

1、服务商需开通分账业务  
2、分账方和分账接收方需隶属于同一服务商  
3、商户状态为禁用或者注销的商户不允许创建分账关系  
4、2023-06-28日后创建的分账关系组，需要运营审核通过后的分账关系组才可进行删除，否则不允许删除。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/merchant-ledger-relation/apply>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_apply\_no | 服务商申请编号 | String | 新增：服务商开通分账业务申请单号唯一单号 删除&修改：需上传原服务商申请编号 | 88888888 | M |
| agent\_no | 服务商编号 | String | 服务商的编号，由SaaS平台分配，表示当前商户属于该服务商名下 | 88888888 | M |
| merch\_no | 分账方商户编号 | String | 商户编号 |  | M |
| operator\_type | 类型 | String | ADD：新增  DELETE：删除   UPDATE：修改 |  | M |
| receive\_arr | 分账接收关系组 | jsonArray |  |  | M |
| notify\_url | 异步通知地址 | String |  |  | O |
| remark | 备注 | String |  |  | O |

#### receive\_arr分账接收关系组

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| home\_page | 分账方与分账接收方协议首页 | String |  |  | M |
| last\_page | 分账方与分账接收方协议尾页 | String |  |  | M |
| business\_page | 分账方商户与分账接收方之间的分账协议合作页 | String |  |  | M |
| agreement | 其他辅助资料 | String |  |  | O |
| receive\_no | 分账接收方商户号 | String |  |  | M |
| relation | 关系 | String | SERVICE\_PROVIDER：服务商  STORE：门店 STAFF：员工 STORE\_OWNER：店主  PARTNER：合作伙伴  HEADQUARTER：总部 DISTRIBUTOR：分销商  USER：用户  SUPPLIER：供应商  CUSTOM：自定义 |  | M |

#### 请求示例:

```
{
    "accessid": "4028805b7cb551ee017cb562c073003a",
    "agent_no": "FW1000566",
    "merch_no": "833102354620079",
    "agent_apply_no": "957308282976",
    "operator_type": "ADD",
    "receive_arr": [
        {
            "receive_no": "833102354620078",
            "relation": "SERVICE_PROVIDER",
            "home_page":"123",
            "last_page":"123",
            "business_page":"123",
            "agreement":"123"
        }
    ],
    "sign": "E520CE0D979E65CAA2CE6037EF1B756B"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| apply\_no | 服务商申请编号 | String | 当return\_code=10000时有值 |  | O |

#### 返回示例:

```
{
    "agent_apply_no": "200324132235396280367202",
    "return_code": 10000,
    "sign": "A5503002FC11A79E3309EB6C6D9712AE"
}
```

文档更新时间: 2024-11-29 10:14   作者：王金晶