#### 概要描述:

查询代金券信息，包括代金券的基础信息、状态。

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/front-api/wx-coupon/query-coupon-detail>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| coupon\_id | 代金券或消费金id | String(48) | 微信为代金券或消费金唯一分配的id |  | M |
| openid | 用户openid | String(128) | 用户openid |  | M |
| appid | appid | String(64) | appid |  | O |

#### 请求示例:

```
{
  "coupon_id": "88888888",
  "openid": "oc5mSjk88888888efaeBmjU",
  "appid": "wx88888888",
  "agent_no": "FW88888888",
  "req_id": "@id",
  "sign": "123456789ABCDEFG"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表成功 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| stock\_id | 卡券批次id | String | result\_code 为成功时返回 |  | M |
| stock\_creator\_mchid | 商户号 | String | 创建方商户 |  | M |
| coupon\_id | 代金券或消费金id | String | 微信为代金券或消费金唯一分配的id |  | M |
| cut\_to\_message | 单品优惠特定信息 | JSON |  |  | M |
| status | 券或消费金状态 | String | SENDED：可用 USED：已实扣 EXPIRED：已过期 |  | M |
| description | 使用说明 | String | 券或消费金描述说明字段 |  | M |
| create\_time | 领券时间 | String | 领券时间，遵循rfc3339标准格式，格式为yyyy-MM-DDTHH:mm:ss+TIMEZONE |  | M |
| coupon\_type | 券或消费金类型 | String | NORMAL：满减券 CUT\_TO：减至券 |  | M |
| no\_cash | 是否无资金流 | String | true：是 false：否 |  | M |
| available\_begin\_time | 可用开始时间 | String | 可用开始时间，遵循rfc3339标准格式，格式为yyyy-MM-DDTHH:mm:ss+TIMEZONE |  | M |
| available\_end\_time | 可用结束时间 | String | 可用结束时间，遵循rfc3339标准格式，格式为yyyy-MM-DDTHH:mm:ss+TIMEZONE |  | M |
| singleitem | 是否单品优惠 | String | true：是 false：否 |  | M |
| normal\_coupon\_information | 满减券或消费金信息 | JSON | 普通满减券或消费金面额、门槛信息 |  | O |
| out\_request\_no | 商户单据号 | String |  |  | O |
| available\_balance | 剩余金额 | int | 可用余额，单位：分。仅有当business\_type=MULTIUSE时，才会返回 |  | O |
| business\_type | 业务类型 | String | 细分业务类型,当business\_type=MULTIUSE时才返回，枚举值：MULTIUSE：消费金 |  | O |

#### 返回示例:

```
{
  "create_time": "2024-11-07T16:10:29+08:00",
  "available_end_time": "2025-02-01T23:59:59+08:00",
  "singleitem": false,
  "sign": "9E7EC1422ED7BB28E6077C44661299A3",
  "description": "",
  "return_msg": "成功",
  "stock_id": "88888888",
  "coupon_name": "代金券0.1",
  "result_msg": "请求成功",
  "no_cash": false,
  "stock_creator_mchid": "88888888",
  "normal_coupon_information": {
    "coupon_amount": 10,
    "transaction_minimum": 20
  },
  "result_code": "10000",
  "return_code": "SUCCESS",
  "coupon_type": "NORMAL",
  "available_begin_time": "2024-11-07T00:00:00+08:00",
  "status": "SENDED"
}
```

文档更新时间: 2025-02-13 09:50   作者：王思阳