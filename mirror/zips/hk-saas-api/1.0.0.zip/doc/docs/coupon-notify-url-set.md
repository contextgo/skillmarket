#### 概要描述:

用于设置接收营销事件通知的URL，可接收营销相关的事件通知。

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/front-api/wx-coupon/set-callbacks>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| notify\_url | 通知地址 | String(256) | 通知地址 |  | M |

#### 请求示例:

```
{
  "agent_no": "FW88888888",
  "notify_url": "http://www.baidu.com",
  "req_id": "@id",
  "sign": "8888888888888888888888"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表成功 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| notify\_url | 通知地址 | String | 同请求参数 |  | M |
| update\_time | 变更时间 | String | 格式：yyyy-MM-dd HH:mm:ss |  | M |

#### 返回示例:

```
{
  "result_msg": "请求成功",
  "update_time": "2024-11-07 15:17:18",
  "sign": "D7DBCBB84721A1E04FDAD938D2C2C3D9",
  "result_code": "10000",
  "return_msg": "成功",
  "notify_url": "http://www.baidu.com",
  "return_code": "SUCCESS"
}
```

文档更新时间: 2025-02-13 09:50   作者：王思阳