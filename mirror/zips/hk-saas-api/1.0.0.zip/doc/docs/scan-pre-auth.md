#### 概要描述:

收银员使用扫码设备读取用户微信/支付宝APP付款码/银联二维码以后，二维码或条码信息传送至商户收银台，由商户收银台或者商户后台调用该接口发起支付对用户进行收款。

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/api/v2/pre-auth/passive-pay>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String(32) | 海科商户编号 |  | M |
| appid | 公众账号ID | String(32) | 微信支付时选填：微信分配的公众账号 ID |  | C |
| auth\_code | 支付授权码 | String(32) | 支付授权码 |  | M |
| sub\_mch\_id | 报备商户编号 | String(32) | 通道子商户号（ATU商户号） |  | O |
| out\_trade\_no | 服务商支付订单号 | String(32) | 服务商内部订单号（同一服务商下唯一） |  | M |
| total\_amount | 交易金额 | String(12) | 上送银联的交易金额（单位：元,支持2位小数） |  | M |
| pn | SAAS终端号 | String(32) | SAAS终端号 |  | M |
| limit\_pay | 限制贷记卡支付 | String(10) | 0：不限制贷记卡支付 1：禁止使用贷记卡支付。 不上送此参数时，limit\_pay默认为0，即：不限制贷记卡支付 |  | O |
| notify\_url | 异步通知地址 | String(128) | 交易成功异步通知地址 |  | O |
| remark | 备注 | String(100) | 交易备注 |  | O |
| longitude | 经度 | String(10) | 经度 |  | O |
| latitude | 纬度 | String(10) | 纬度 |  | O |
| extend\_params | 原生请求参数 | JSON | 原生参数，透传给通道的参数 |  | O |
| terminal\_info | 终端信息 | JSON | 259终端信息 |  | M |

##### 259终端信息:terminal\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| location | 终端实时经纬度信息 | String | 受理终端设备实时经纬度信息，格式为纬度/经度， +表示北纬、东经，-表示南纬、西经 | +37.12/-121.213 | O |
| device\_ip | 商户端设备 IP | String | 商户端终端设备 IP 地址。注： 如经、维度信息未上送，该字段必送。 |  | O |
| encrypt\_rand\_num | 加密随机因子 | String（10） | 仅在被扫支付类交易报文中出现：若付款码为 19 位数字，则取后6 位；若付款码为 EMV二维码，则取其tag 57 的卡号/token 号的后 6 位 |  | O |
| secret\_text | 密文数据 | String（16） | 仅在被扫支付类交易报文中出现：64bit 的密文数据， 对终端硬件序列号和加密随机因子加密后的结果。本子域取值为： 64bit 密文数据进行base64 编码后的结果。加密前8位，加密后应为12位 |  | O |
| app\_version | 应用程序版本号 | String（8） | 终端应用程序的版本号。应用程序变更应保证版本号不重复。当长度不足时，右补空格。 |  | O |

##### 微信原生请求参数:extend\_params

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| body | 商品描述 | String(127) | 商品简单描述，该字段请按照规范传递 | 腾讯充值中心-QQ会员充值 | O |
| goods\_tag | 微信订单优惠标记 | String(32) | 微信订单优惠标记，代金券或立减优惠功能的参数 |  | O |
| device\_info | 微信设备号 | String(32) | 终端设备号(门店号或收银设备ID)，注意：PC网页或JSAPI支付请传”WEB” |  | O |
| detail | 微信商品详情 | JSON | 微信单品优惠功能 |  | O |

##### 微信单品优惠功能:detail

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| cost\_price | 订单原价 | int | 1.商户侧一张小票订单可能被分多次支付，订单原价用于记录整张小票的交易金额。 2.当订单原价与支付金额不相等，则不享受优惠。 3.该字段主要用于防止同一张小票分多次支付，以享受多次优惠的情况，正常支付订单不必上传此参数。 | 608800 | O |
| receipt\_id | 商品小票ID | String(32) | 商家小票ID |  | O |
| goods\_detail | 单品列表 | JSONArray | 单品信息，使用Json数组格式提交 |  | O |

##### 微信单品列表:goods\_detail

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| goods\_id | 商品编码 | String(32) | 由半角的大小写字母、数字、中划线、下划线中的一种或几种组成 |  | M |
| wxpay\_goods\_id | 微信侧商品编码 | String(32) | 微信支付定义的统一商品编号（没有可不传） |  | O |
| goods\_name | 商品名称 | String(256) | 商品的实际名称 |  | O |
| quantity | 商品数量 | int | 用户购买的数量 |  | M |
| price | 商品单价 | int | 单位为：分。如果商户有优惠，需传输商户优惠后的单价(例如：用户对一笔100元的订单使用了商场发的纸质优惠券100-50，则活动商品的单价应为原单价-50) | 528800 | M |

##### 支付宝原生请求参数:extend\_params

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| subject | 订单标题 | String(256) | 订单标题。注意：不可使用特殊字符，如 /，=，& 等。 | Iphone6 16G | O |
| operator\_id | 商户操作员编号 | String(28) | 商户操作员编号。新当面资金授权场景必填。 | yx\_001 | O |
| store\_id | 商户门店编号 | String(32) | 商户门店编号。新当面资金授权场景必填。 | NJ\_001 | O |
| terminal\_id | 商户机具终端编号 | String(32) | 商户机具终端编号 | NJ\_T\_001 | O |
| goods\_detail | 订单包含的商品列表信息 | JSONArray | 订单包含的商品列表信息，json数组格式。 |  | O |
| extend\_params | 业务扩展参数 | JSON | 业务扩展参数 |  | O |

##### 支付宝订单包含的商品列表信息:goods\_detail

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| goods\_id | 商品编号 | String(32) |  | apple-01 | M |
| goods\_name | 商品名称 | String(256) | 商品的实际名称 |  | M |
| quantity | 商品数量 | int | 用户购买的数量 |  | M |
| price | 商品单价 | int | 商品单价，单位为元 | 2000 | M |
| goods\_category | 商品类目 | String（24） | 商品类目 | 34543238 | O |
| categories\_tree | 商品类目树 | String（128） | 商品类目树，从商品类目根节点到叶子节点的类目id组成，类目id值使用 | 分割 |  |
| body | 商品描述信息 | String(1000) | 商品描述信息 |  | O |
| show\_url | 商品的展示地址 | String(400) | 商品的展示地址 |  | O |

##### 支付宝业务扩展参数:extend\_params

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| sys\_service\_provider\_id | 系统商编号 | String(64) | 该参数作为系统商返佣数据提取的依据，请填写系统商签约协议的PID |  | O |
| hb\_fq\_num | 花呗分期数 | String | 使用花呗分期要进行的分期数 |  | O |
| hb\_fq\_seller\_percent | 花呗分期数手续费 | String | 使用花呗分期需要卖家承担的手续费比例的百分值，传入100 代表100% |  | O |
| industry\_reflux\_info | 行业数据回流信息 | String(512) | 行业数据回流信息, 详见：地铁支付接口参数补充说明 |  | O |
| card\_type | 卡类型 | String(32) | 卡类型 |  | O |

##### 云闪付原生请求参数:extend\_params

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| pnrInsIdCd | 银联服务商机构号 | String | 银联服务商机构号，参加银联云闪付活动时上送 |  | O |
| acqAddnData | 收款方附加数据 | JSON | 收款方附加数据 |  | O |

##### (银联二维码)收款方附加数据:acqAddnData

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| orderInfo | 订单信息 | JSON | 订单明细内容，如订单标 题、订单描述等 |  | O |
| goodsInfo | 商品信息 | JSONArray | 商品明细内容 |  | O |

##### (银联二维码)订单信息:orderInfo

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| title | 标题 | String | 标题 |  | M |
| description | 订单描述 | String | 订单描述 |  | O |
| dctAmount | 可优惠金额 | String | 当前订单可以参与优惠计算的金额 |  | O |
| addnInfo | 附加信息 | String | 内容自定义 |  | O |

##### (银联二维码)商品信息:goodsInfo

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| id | 标题 | String | 标题 |  | M |
| name | 商品名称 | String | 订单描述 |  | M |
| price | 商品单价 | String | 以分为单位 |  | M |
| quantity | 商品数量 | String | 商品数量 |  | M |
| category | 商品类目 | String | 商品类目 |  | O |
| addnInfo | 附加信息 | String | 附加信息 |  | O |

#### 请求示例:

```
{
    "agent_no": "IS88888888",
    "req_id": "147258369",
    "merch_no": "83388888888",
    "auth_code": "133237758672778080",
    "out_trade_no": "123456789",
    "pn": "WZ0092809",
    "total_amount": "1",
    "ledger_biz": {
        "ledger_relation": [
            {
                "receive_no": "833102158124164",
                "amt": "0.01"
            },
            {
                "receive_no": "833102158124165",
                "amt": "0.01"
            }
        ],
        "ledger_type": "REALTIME_SETTLE"
    },
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表业务处理成功，交易结果需要根据trade\_status判断 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科商户编号 |  | M |
| pay\_type | 支付类型 | String | WX：微信支付 ALI：支付宝支付 UNIONQR：云闪付 |  | M |
| out\_trade\_no | 服务商支付订单号 | String |  |  | M |
| trade\_no | 海科支付订单号 | String |  |  | M |
| trade\_status | 交易状态 | String | 1：交易成功 2：交易失败 3：交易进行中 |  | M |
| end\_time | 交易完成时间 | String | 交易在海科的完成时间 | 2024-01-01 10:10:10 | O |
| attach | 通道原生参数 | String |  |  | O |

#### 返回示例:

```
{
    "agent_no": "IS88888888",
    "merch_no": "83388888888",
    "pay_type": "WX",
    "out_trade_no": "123456789",
    "trade_no": "WX240411172957000410317154",
    "trade_status": "1",
    "return_code": "SUCCESS",
    "return_msg": "成功",
    "result_code": "10000",
    "result_msg": "成功",
    "end_time": "2024-04-11 11:06:04",
    "attach": "{
        \"transaction_id\": \"4200066306202404110683647184\",
        \"nonce_str\": \"6e609eef344d4b74900c907d1fd598b0\",
        \"trade_state\": \"SUCCESS\",
        \"bank_type\": \"COMM_CREDIT\",
        \"openid\": \"oc5mSjk234Hnxykk2jp7efaeBmjU\",
        \"cert_id\": \"4233741533\",
        \"return_msg\": \"成功\",
        \"fee_type\": \"CNY\",
        \"mch_id\": \"1505378701\",
        \"sub_mch_id\": \"626185853\",
        \"cash_fee\": \"101\",
        \"out_trade_no\": \"WX240411172957000410317154\",
        \"cash_fee_type\": \"CNY\",
        \"coupon_fee\": \"0\",
        \"appid\": \"wx17728c1a8fa300d6\",
        \"total_fee\": \"101\",
        \"settlement_total_fee\": \"101\",
        \"trade_type\": \"MICROPAY\",
        \"result_code\": \"SUCCESS\",
        \"time_end\": \"20240411172959\",
        \"sign_type\": \"SM2\",
        \"return_code\": \"SUCCESS\"
    }",
    "sign": "1032A57E96E4048B27EC2A5C3CE5E663"
}
```

文档更新时间: 2025-01-10 09:25   作者：陈文