#### 概要描述:

服务商（渠道商）可以通过该接口向微信支付提交商户的联系人、主体等信息，根据指引完成商户开户意愿确认。

* 注：使用海科渠道号的服务商必须调用该接口；使用自己主体渠道号的服务商，可以调用该接口或直接调用微信官方认证接口均可完成微信二次认证。  
  微信官方接口链接如下：<https://pay.weixin.qq.com/static/help_guide/real_name_authentication.shtml>

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/wx-auth/apply>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |
| wx\_merch\_no | 微信商户编号 | String |  |  | M |
| business\_code | 业务申请编号 | String |  |  | M |
| contact\_info | 联系人信息 | JSON |  |  | M |
| subject\_info | 主体信息 | JSON |  |  | M |
| identification\_info | 法人身份信息 | JSON |  |  | M |

##### 联系人信息：contact\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| name | 联系人姓名 | String |  |  | M |
| mobile | 联系人手机号 | String |  |  | M |
| id\_card\_number | 联系人身份证号码 | String |  |  | M |
| contact\_type | 联系人类型 | String | 1、主体为“小微/个人卖家 ”，可选择：LEGAL：经营者/法人。2、主体为“个体工商户/企业/政府机关/事业单位/社会组织”，可选择：LEGAL：经营者/法人、SUPER：经办人。 （经办人：经商户授权办理微信支付业务的人员） | LEGAL | M |
| contact\_front\_image | 联系人证件正面照片 | String | 1、当联系人类型是经办人时，请上传联系人证件的正面照片。2、若证件类型为身份证，请上传人像面照片。 | 图片上传id:121321211 | O |
| contact\_back\_image | 联系人证件反面照片 | String | 1、当联系人类型是经办人时，请上传联系人证件的反面照片。2、若证件类型为护照，无需上传反面照片。 | 图片上传id:121321211 | O |
| contact\_period\_begin | 联系人证件有效期开始时间 | String | 1、当联系人类型是经办人时，请上传证件有效期开始时间2、请按照示例值填写。3、结束时间大于开始时间。 | 2019-06-06 | O |
| contact\_period\_end | 联系人证件有效期结束时间 | String | 当联系人类型是经办人时，请上传证件有效期结束时间2、请按照示例值填写，若证件有效期为长期，请填写：长期。3、结束时间大于开始时间。 | 2019-06-06/forever | O |
| business\_authorization\_letter | 业务办理授权函 | String | 1、当联系人类型是经办人时，请上传业务办理授权函2、请参照[示例图]打印业务办理授权函，全部信息需打印，不支持手写商户信息，并加盖公章。 | 图片上传id:121321211 | O |

##### 主体信息：subject\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| subject\_type | 主体类型 | String | SUBJECT\_TYPE\_ENTERPRISE：企业 SUBJECT\_TYPE\_INSTITUTIONS\_CLONED：事业单位 SUBJECT\_TYPE\_INDIVIDUAL：个体工商户 SUBJECT\_TYPE\_OTHERS：其他组织 SUBJECT\_TYPE\_MICRO：小微商户 |  | M |
| business\_licence\_info | 营业执照信息 | JSON | 主体类型为企业或个体户时，营业执照信息必填。 |  | O |
| assist\_prove\_info | 辅助证明材料信息 | JSON | 主体类型为小微商户时，辅助证明材料信息必填。 |  | O |

##### 营业执照信息：business\_licence\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| licence\_number | 营业执照注册号 | String |  |  | M |
| licence\_copy | 营业执照照片 | String |  |  | M |
| merchant\_name | 商户名称 | String |  |  | M |
| legal\_person | 法人姓名 | String |  |  | M |
| company\_address | 注册地址 | String |  |  | M |
| licence\_valid\_date | 营业执照有效日期 | JSONArray | 1、请填写营业执照上的营业期限，注意参照示例中的格式，长期用”forever”表示。 2、结束时间需大于开始时间。 3、有效期必须大于60天，即结束时间距当前时间需超过60天。 示例值：["1970-01-01","forever"] |  | M |

##### 辅助证明材料信息：assist\_prove\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| micro\_biz\_type | 小微经营类型 | String | MICRO\_TYPE\_STORE：门店场所 MICRO\_TYPE\_MOBILE：流动经营/便民服务 MICRO\_TYPE\_ONLINE：线上商品/服务交易 |  | M |
| store\_name | 门店名称 | String | 1、门店场所：填写门店名称。 2、流动经营/便民服务：填写经营/服务名称。 3、线上商品/服务交易：填写线上店铺名称。 |  | M |
| store\_address\_code | 门店省市编码 | String | 1、门店场所：填写门店省市编码。 2、流动经营/便民服务：填写经营/服务所在地省市编码。 3、线上商品/服务交易：填写卖家所在地省市编码。[省市区编码对照表](http://39.106.84.215:8181/attach_files/saas/294 "省市区编码对照表.xlsx") |  | M |
| store\_address | 门店地址 | String | 1、门店场所：填写店铺详细地址，具体区/县及街道门牌号或大厦楼层。 2、流动经营/便民服务：填写“无”。 3、线上商品/服务交易：填写电商平台名称。 |  | M |
| store\_header\_copy | 门店门头照片 | String | 填写规范： 1)门店场所：提交门店门口照片，要求招牌清晰可见。 2)流动经营/便民服务：提交经营/服务现场照片。 3)线上商品/服务交易：提交店铺首页截图。 |  | M |
| store\_indoor\_copy | 店内环境照片 | String | 填写规范： 1)门店场所：提交店内环境照片。 2)流动经营/便民服务：可提交另一张经营/服务现场照片。 3)线上商品/服务交易：提交店铺管理后台截图。 |  | M |

##### 法人身份信息：identification\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| identification\_type | 法人证件类型 | String | IDENTIFICATION\_TYPE\_IDCARD：身份证（限中国大陆居民) IDENTIFICATION\_TYPE\_OVERSEA\_PASSPORT：护照（限境外人士) IDENTIFICATION\_TYPE\_HONGKONG\_PASSPORT ：中国香港居民-来往内地通行证 IDENTIFICATION\_TYPE\_MACAO\_PASSPORT：中国澳门居民-来往内地通行证 IDENTIFICATION\_TYPE\_TAIWAN\_PASSPORT：中国台湾居民-来往大陆通行证 |  | M |
| identification\_name | 证件姓名 | String | 请填写法人证件上的姓名，2~30个中文字符、英文字符、符号。 |  | M |
| identification\_number | 证件号码 | String | 请填写法人证件上的证件号码。 |  | M |
| identification\_valid\_date | 证件有效日期 | JSONArray | 1、请填写法人证件的有效时间，注意参照示例中的格式。 2、结束时间需大于开始时间。 3、证件有效期需大于60天，即结束时间距当前时间需超过60天。 示例值：["1970-01-01","forever"] |  | M |
| identification\_front\_copy | 证件正面照片 | String | 1、请上传法人证件的正面照片。 2、若法人证件类型为身份证，请上传人像面照片。 |  | M |
| identification\_back\_copy | 证件反面照片 | String | 1、请上传法人证件的反面照片。 2、若法人证件类型为身份证，请上传国徽面照片。 3、若证件类型为护照或通行证，无需上传反面照片。 |  | O |
| identification\_address | 证件居住地址 | String | 1、主体类型为企业时，需要填写。其他主体类型，无需上传。2、请按照证件上住址填写，若证件上无住址则按照实际住址填写，如广东省深圳市南山区xx路xx号xx室。 |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "merch_no": "83311010100002012",
    "wx_merch_no": "36771679469",
    "business_code": "1111111111",
    "sign": "36EE79FD2E36527F5A75D58E40C9FEC4",
    "contact_info": {
        "name": "张三",
        "mobile": "13312345678",
        "id_card_number": "430422199001236704"
    },
    "subject_info": {
        "subject_type": "SUBJECT_TYPE_ENTERPRISE",
        "business_licence_info": {
            "licence_number": "914201123033363296",
            "licence_copy": "c0941d8a969b4e20a890be8f6edc2959",
            "merchant_name": "李四网络有限公司",
            "legal_person": "李四",
            "company_address": "广东省深圳市南山区xx路xx号",
            "licence_valid_date": ["1970-01-01","forever"]
        },
        "assist_prove_info": {
            "micro_biz_type": "MICRO_TYPE_STORE",
            "store_name": "大郎烧饼",
            "store_address_code": "440305",
            "store_address": "广东省深圳市南山区xx大厦x层xxxx室",
            "store_header_copy": "c0941d8a969b4e20a890be8f6edc2959",
            "store_indoor_copy": "c0941d8a969b4e20a890be8f6edc2959"
        }
    },
    "identification_info": {
        "identification_type": "IDENTIFICATION_TYPE_IDCARD",
        "identification_name": "李四",
        "identification_number": "430422199001236705",
        "identification_valid_date": ["1970-01-01","forever"],
        "identification_front_copy": "c0941d8a969b4e20a890be8f6edc2959",
        "identification_back_copy": "c0941d8a969b4e20a890be8f6edc2959"
    }
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| apply\_no | 申请单编号 | String |  |  | M |

#### 返回示例:

```
{
    "apply_no": "200323174241616939321401",
    "return_code": 10000,
    "sign": "F354732C4886EC9001C2E9FF2E45870E"
}
```

文档更新时间: 2024-11-29 10:07   作者：admin