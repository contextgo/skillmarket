### 页面重定向方式获取银联用户标识API

**业务功能**  
获取用户在银联的唯一标识，用于银联js支付下单。  
**交互模式**  
服务商使用**页面重定向**的方式进行请求本接口，并上送服务商的重定向地址，haipay获取到用户标识以后会**重定向到指定的地址**，并在地址后面携带响应的返回参数（URL传参的方式）。整个过程需要使用银联云闪付app完成  
**测试url：**  
<http://47.95.131.62:8080/api/v1/pay/uniqr/getUserId>

**请求参数(O-非必传 ,M-必传):**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 商户编号 | String |  |  | M |
| redirect\_url | 服务商的重定向地址 | String | （需要Base64处理）haipay获取到用户标识以后会重定向到指定的地址，并携带响应的返回参数 |  | M |

#### 请求示例:

`http://47.95.131.62:8080/api/v1/pay/uniqr/getUserId?accessid=cpostest&merch_no=88888888&redirect_url=aHR0cDovLzQ3Ljk1LjEzMS42Mjo4MDgwL2FwaS92MS90cmFkZS9zdWNjZXNzL25vdGljZS90ZXN0YQ==`

**返回参数:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| userid | 用户标识 | String | 用户在银联平台的唯一标识 |  | M |
| userAuthCode | 用户授权码 | String | 付款方返回的临时授权码 |  | M |

#### 返回示例:

`http://test.abc.cn/callback?return_code=10000&return_msg=成功&userAuthCode=078331232131232131231ftQj&userid=MTIzMTIzMTIzMTIzMTIzMTIzMTMyMzEyMzE&sign=953A3CE8C278BB7A8BA277419724C3FD`

文档更新时间: 2024-12-05 18:02   作者：admin