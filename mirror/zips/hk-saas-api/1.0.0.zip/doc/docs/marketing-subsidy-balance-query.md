#### 概要描述:

服务商可以通过该接口查询营销补贴账户余额

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/subsidy/subsidyAccQuery>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| subsidy\_no | 营销补贴户编号 | String |  |  | M |

#### 请求示例:

```
{
    "accessid": "****",
    "agent_no": "****",
    "subsidy_no": "*****",
    "sign": "EB8F8DCF468E2BE704B566487A87F022"
}
```

#### 返回信息(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 服务商编号 |  |  |
| list | 营销补贴户list表 | List | 格式为：JsonArray |  |  |

AccInfo：

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| subsidyNo | 营销补贴户编号 | String | 营销补贴户编号 |  |  |
| subsidyAccAmt | 账户余额 | String | 单位为元 |  |  |

#### 返回示例:

```
{
    "return_code": "00000",
    "return_msg": "查询成功",
    "agent_no": "ISV000607",
    "list": [
        {
            "subsidyNo": "Buuuuuuj",
            "subsidyAccAmt": "9999974"
        }
    ],
    "sign": "2580E7CAF2D85A06338EFF10D21268A9"
}
```

文档更新时间: 2024-11-29 10:13   作者：admin