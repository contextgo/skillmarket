## 微信-投诉信息推送

### 基本信息

**Path：** /运营配置地址

**Method：** POST

**接口描述：**

### 请求参数

**Headers**

| 参数名称 | 参数值 | 是否必须 | 示例 | 备注 |
| --- | --- | --- | --- | --- |
| Content-Type | application/json | 是 |  |  |

**Body**

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| firstLevelAgentNum | string | 非必须 |  | 一级服务商编号 |  |
| firstLevelAgentName | string | 非必须 |  | 一级服务商名称 |  |
| agentNum | string | 非必须 |  | 所属服务商编号 |  |
| agentName | string | 非必须 |  | 所属服务商名称 |  |
| mercNum | string | 非必须 |  | 业务平台商编 |  |
| mercName | string | 非必须 |  | 业务平台商户名称 |  |
| mercCreateTime | string | 非必须 |  | 商户入网时间 |  |
| mercStatus | string | 非必须 |  | 商户状态 |  |
| mercLegalPersonName | string | 非必须 |  | 商户法人姓名 |  |
| mercLegalPersonTel | string | 非必须 |  | 商户法人联系方式 |  |
| provinceName | string | 非必须 |  | 所在省 |  |
| cityName | string | 非必须 |  | 所在市 |  |
| districtName | string | 非必须 |  | 地区名称 |  |
| complaintId | string | 非必须 |  | 投诉单号 |  |
| complaintTime | string | 非必须 |  | 投诉时间 |  |
| complaintDetail | string | 非必须 |  | 投诉详情 |  |
| complaintState | string | 非必须 |  | 投诉单状态 PENDING-待处理 PROCESSING-处理中 PROCESSED-已处理完成 |  |
| complaintedMchid | string | 非必须 |  | 被诉商户号 |  |
| payerPhone | string | 非必须 |  | 投诉人联系方式 |  |
| transactionId | string | 非必须 |  | 微信订单号 |  |
| outTradeNo | string | 非必须 |  | 商户订单号 |  |
| amount | string | 非必须 |  | 订单金额，单位（分） |  |
| complaintFullRefunded | string | 非必须 |  | 投诉单是否已全额退款 |  |
| incomingUserResponse | string | 非必须 |  | 是否有待回复的用户留言 |  |
| userComplaintTimes | string | 非必须 |  | 用户投诉次数 |  |
| mediaType | string | 非必须 |  | 媒体文件业务类型： USER\_COMPLAINT\_IMAGE: 用户提交投诉时上传的图片凭证 OPERATION\_IMAGE: 用户、商户、微信支付客服在协商解决投诉时，上传的图片凭证 |  |
| mediaUrl | string | 非必须 |  | 媒体文件请求url |  |
| problemDescription | string | 非必须 |  | 问题描述 |  |
| problemType | string | 非必须 |  | 问题类型 REFUND: 申请退款 SERVICE\_NOT\_WORK: 服务权益未生效 OTHERS: 其他类型 |  |
| applyRefundAmount | string | 非必须 |  | 申请退款金额(单位:分) |  |
| userTagList | string | 非必须 |  | 用户标签列表 TRUSTED: 此类用户满足极速退款条件 HIGH\_RISK: 高风险投诉，请按照运营要求优先妥善处理 |  |
| orderId | string | 非必须 |  | 微信支付服务订单号 |  |
| outOrderNo | string | 非必须 |  | 商户服务订单号 |  |
| state | string | 非必须 |  | 支付分服务单状态 DOING: 服务订单进行中 REVOKED: 服务订单已取消 WAITPAY: 服务订单待支付 DONE: 服务订单已完成 |  |
| type | string | 非必须 |  | 补充信息类型 SHARE\_POWER\_TYPE: 充电宝投诉相关行业 |  |
| returnTime | string | 非必须 |  | 归还时间 |  |
| returnAddress | string | 非必须 |  | 归还地点 |  |
| longitude | string | 非必须 |  | 归还地点经度 |  |
| latitude | string | 非必须 |  | 归还地点纬度 |  |
| isReturnedToSameMachine | string | 非必须 |  | 是否归还同一柜机 |  |
| inPlatformService | string | 非必须 |  | 是否在平台协助中 |  |
| needImmediateService | string | 非必须 |  | 是否需即时服务用户 |  |
| payerOpenid | string | 非必须 |  | 投诉人OpenID |  |
| payType | string | 非必须 |  | ALI:支付宝；WX：微信 |  |
| agent\_no | string | 非必须 |  | 一级代理商编号 |  |
| sign | string | 非必须 |  | 签名值 |  |

文档更新时间: 2025-10-20 10:47   作者：郝庚鑫