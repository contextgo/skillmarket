#### 概要描述:

服务商可以通过该接口向微信支付提交商户的联系人信息、主体信息以及联系人信息。

* 注：使用海科pid的服务商必须调用该接口；使用自己主体pid的服务商，可以调用该接口或直接调用支付宝官方认证接口均可完成支付宝二次认证。  
  支付宝官方接口链接如下：<https://opendocs.alipay.com/open/03sqz8>

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/ali-auth/create>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |
| ali\_merch\_no | 支付宝商户编号 | String |  |  | M |
| business\_code | 业务申请编号 | String |  |  | M |
| contact\_person\_info | 联系人信息 | JSON |  |  | M |
| auth\_identity\_info | 主体信息 | JSON |  |  | M |
| legal\_person\_info | 法人身份信息 | JSON |  |  | M |

##### 联系人信息：contact\_person\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| contact\_name | 联系人姓名 | String |  |  | M |
| contact\_phone\_no | 联系人手机号 | String |  |  | M |
| contact\_card\_no | 联系人身份证号码 | String |  |  | M |

##### 主体信息：auth\_identity\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| identity\_type | 主体类型 | String | 枚举定义：企业(ENTERPRISE)、个体工商户(IND\_BIZ)、事业单位(INST)、党政机关(GOV)、社会组织(ORG)、小微商户(MSE) | ENTERPRISE | M |

###### 当主体类型为个体企业是 以下信息必传

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| cert\_no | 营业执照注册号 | String | 证件编号 | 0000001 | M |
| cert\_image | 营业执照照片 | String | 调用图片上传接口返回的id | c6ddaa891d6b405db2 | M |
| merchant\_name | 证照商户名称 | String | 证照商户名称 | 好吃再来 | M |
| legal\_person\_name | 证照法人姓名 | String | 证照法人姓名 | 张三 | M |
| register\_address | 证照注册地址 | String | 证照注册地址 | 北京市西城区xx号 | M |
| effect\_time | 营业执照有效日期[起] | String | 证照生效时间 | 2022-08-08 | M |
| expire\_time | 营业执照有效日期[止] | String | 证照过期时间 | 2022-08-08或者forever | M |

###### 当主体类型为小微商户 以下信息必传

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merchant\_type | 小微经营类型 | String | 小微商户经营类型，枚举值：门店场所（STORE）、流动经营（STALL） | STORE | M |
| store\_name | 门店名称 | String | 门店名称 | 好吃再来小吃店 | M |
| province\_code | 门店省行政区号（数字) | String | 门店省行政区号（数字) [省市区编码对照表](http://39.106.84.215:8181/attach_files/saas/294 "省市区编码对照表.xlsx") | 110000 | M |
| province | 门店省行政区号（数字) | String | 门店省份  [省市区编码对照表](http://39.106.84.215:8181/attach_files/saas/294 "省市区编码对照表.xlsx") | 北京市 | M |
| city\_code | 门店市行政区号（数字）) | String | 门店市行政区号（数字)[省市区编码对照表](http://39.106.84.215:8181/attach_files/saas/294 "省市区编码对照表.xlsx") | 130600 | M |
| city | 门店市行政区号 | String | 门店市行政区号（数字)[省市区编码对照表](http://39.106.84.215:8181/attach_files/saas/294 "省市区编码对照表.xlsx") | 保定市 | M |
| district\_code | 门店街道区号（数字) | String | 门店省行政区号（数字)[省市区编码对照表](http://39.106.84.215:8181/attach_files/saas/294 "省市区编码对照表.xlsx") | 130602 | M |
| district | 门店街道区 | String | 门店省行政区号（数字)[省市区编码对照表](http://39.106.84.215:8181/attach_files/saas/294 "省市区编码对照表.xlsx") | 新市区 | M |
| store\_address | 门店详细地址 | String | 门店场所填写门店详细地址，流动经营类型填“无” | 河北省保定市竞秀区新市场街16号 | M |
| store\_door\_img | 门店门头照片 | String | 门店门头照信息或摊位照（使用图片上传接口） | c6ddaa891d6b405db2ef4d5c1f281049 | M |
| store\_inner\_img | 店内环境照片 | String | 门店店内照片或者摊位照侧面（使用图片上传接口） | c6ddaa891d6b405db2ef4d5c1f281049 | M |

##### 法人身份信息：legal\_person\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| person\_name | 法人姓名 | String | 请填写法人证件上的姓名，2~30个中文字符、英文字符、符号。 | 张三 | M |
| card\_no | 证件号码 | String | 请填写法人证件上的证件号码。 | 233330199001010001 | M |
| effect\_time | 证件有效日期[起] | String | 证件生效时间 | 2022-08-08 | M |
| expire\_time | 证件有效日期[止] | String | 证件过期时间 | 2022-08-08或者forever | M |
| card\_front\_img | 证件正面照片 | String | 法人/经营者证件正面照（使用图片上传接口返回的image\_id） | c6ddaa891d6b405db2ef4d5c1f281049 | M |
| card\_back\_img | 证件反面照片 | String | 法人/经营者证件反面照（使用图片上传接口的image\_id | c6ddaa891d6b405db2ef4d5c1f281049 | M |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "merch_no": "83311010100002012",
    "ali_merch_no": "36771679469",
    "business_code": "1111111111",
    "sign": "36EE79FD2E36527F5A75D58E40C9FEC4",
    "contact_person_info": {
        "contact_name": "张三",
        "contact_phone_no": "13312345678",
        "contact_card_no": "430422199001236704"
    },
    "auth_identity_info": {
        "identity_type": "ENTERPRISE",
         "cert_no": "914201123033363296",
         "cert_image": "c0941d8a969b4e20a890be8f6edc2959",
         "merchant_name": "李四网络有限公司",
         "legal_person_name": "李四",
         "register_address": "广东省深圳市南山区xx路xx号",
         "effect_time": "1970-01-01",
         "expire_time":"forever"
         "merchant_type": "STORE",
         "store_name": "大郎烧饼",
         "province_code":"130000",
         "province":"河北省",
         "city_code":"130100",
         "city":"石家庄市",
         "district_code":"130127",
         "district":"高邑县",
         "store_address": "河北省石家庄市高邑县府前路151号",
         "store_door_img": "c0941d8a969b4e20a890be8f6edc2959",
         "store_inner_img": "c0941d8a969b4e20a890be8f6edc2959"
    },
    "legal_person_info": {
        "person_name": "李四",
        "card_no": "430422199001236705",
        "effect_time": "1970-01-01",
        "expire_time":forever",
        "card_front_img": "c0941d8a969b4e20a890be8f6edc2959",
        "card_back_img": "c0941d8a969b4e20a890be8f6edc2959"
    }
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| apply\_no | 申请单编号 | String |  |  | M |

#### 返回示例:

```
{
    "apply_no": "200323174241616939321401",
    "return_code": 10000,
    "sign": "F354732C4886EC9001C2E9FF2E45870E"
}
```

文档更新时间: 2024-11-29 10:08   作者：admin