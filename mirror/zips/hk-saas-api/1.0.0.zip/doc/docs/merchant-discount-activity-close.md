#### 概要描述:

此接口可为商户终止优惠费率活动

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/activity/close>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |
| activity\_id | 活动模板id | String | 线下联系商务/运营获取/已经报名的活动 id |  | M |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "merch_no": "833226358120003",
    "activity_id":"ffdfdffffffffffffffffffffff",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |

#### 返回示例:

```
{
    "return_code": 10000,
    "sign": "F354732C4886EC9001C2E9FF2E45870E"
}
```

文档更新时间: 2024-11-29 10:13   作者：admin