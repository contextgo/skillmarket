### 交易完成后，请求单次分账

**业务功能**  
延迟分账订单交易成功后，请求单次分账  
**交互模式**  
请求：后台请求交互模式  
返回结果：后台请求交互模式  
**测试url：**  
<http://47.95.131.62:8080/api/v1/delay-ledger/ledger>

**请求参数(O-非必传 ,M-必传):**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 服务商的编号，由SaaS平台分配，表示当前商户属于该服务商名下 | ISV01991023 | M |
| merch\_no | 商户编号 | String | 商户在SaaS平台的编号 | a10253390 | M |
| trade\_no | 交易交易订单号 | String | saas订单号 |  | M |
| apply\_no | 请求订单号 | String | 服务商分账请求订单号（同一服务商下唯一） | 161018121614000624679888 | M |
| ledger\_relation | 分账交易关系组 | JSONArray | 分账参数关系组（组内接收方不能重复） | [ { "receive\_no": "", "amt": "", "remark": "" }, { "receive\_no": "", "amt": "", "remark": "" } ] | M |

#### 请求示例:

```
{
    "agent_no": "FF109108120",
    "merch_no": "83320253445099",
    "trade_no": "UN2312320546186687318899",
    "apply_no": "202301040535",
    "ledger_relation": [
        {
            "receive_no": "833112128140726",
            "amt": "0.01",
            "remark": ""
        },
        {
            "receive_no": "833212168540726",
            "amt": "0.02",
            "remark": ""
        }
    ],
    "accessid": "405544499f016a9b3d8f57000f",
    "sign": "3DD98E25484BB84E08AF32E57B6D6662F"
}
```

**返回参数:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 服务商的编号，由SaaS平台分配，表示当前商户属于该服务商名下 | ISV01991023 | M |
| merch\_no | 商户编号 | String | 商户在SaaS平台的编号 | a10253390 | M |
| trade\_no | SAAS交易订单号 | String | saas订单号 |  | M |
| apply\_no | 请求订单号 | String | 服务商分账请求订单号（同一服务商下唯一） | 161018121614000624679888 | M |
| ledger\_no | 分账订单号 | String | SAAS分账订单号 |  | M |
| ledger\_relation | 分账关系结果 | JSONArray | 当return\_code==10000时有值 receive\_no：分账接收方 amt:分账金额 remark：分账备注 result:分账结果（int 0：失败 1：成功 2:分账中） ledger\_detail\_id：分账明细标识 end\_time：分账完成时间 | [ { "receive\_no": "833102158120726", "amt": 0.01, "remark": "", "result": 1, "ledger\_detail\_id": "230104054710259914380846", "end\_time": "2023-01-04 05:47:10" } ] | M |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |

#### 返回示例:

```
{
    "merch_no": "83320253445099",
    "ledger_relation": [
        {
            "receive_no": "833112128140726",
            "amt": 0.01,
            "remark": "",
            "result": 1,
            "ledger_detail_id": "230104054710259914380846",
            "end_time": "2023-01-03 15:47:10"
        },
        {
            "receive_no": "833212168540726",
            "amt": 0.02,
            "remark": "",
            "result": 1,
            "ledger_detail_id": "23010405471025992560847",
            "end_time": "2023-01-03 15:47:10"
        }
    ],
    "apply_no": "202301040535",
    "trade_no": "UN2312320546186687318899",
    "agent_no": "FF109108120",
    "ledger_no": "23050605482166772759516",
    "return_code": 10000,
    "sign": "6EBAF8D5C3291DDC79B83EBC9BCE868F"
}
```

文档更新时间: 2024-11-29 10:14   作者：张亚飞