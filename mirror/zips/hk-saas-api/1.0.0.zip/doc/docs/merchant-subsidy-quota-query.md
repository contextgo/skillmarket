# 1.1商户补贴额度查询API

## 1.1.1接口说明

* 本接口适用于服务商下参加费率活动的商户补贴额度汇总
* 手续费补贴额度汇总：补贴总额度、额度有效起止日期、额度状态

## 1.1.2请求URL

<http://47.95.131.62:8080/api/v1/bus-cooper/detail>

## 1.1.3请求参数（Y-必传，N-非必传）

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 必填 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String(16) | 海科服务商编号 | ISV/FW+xxxx | M |
| merch\_no | 海科商户编号 | String(32) | 海科商户编号 | 833+xxxx | M |

## 1.1.4请求示例

```
{
    "accessid": "cpostest",
    "agent_no": "FW200097",
    "merch_no": "833226358120003",
}
```

## 1.1.5返回信息

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 必填 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回状态码 | String | 10000：成功，其他：失败 | 10000 |  |
| return\_msg | 返回信息 | String | 返回信息 |  |  |
| detail\_list | 商户补贴额度汇总信息 | json | 参考下表 |  |  |

**商户补贴额度汇总信息**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 必填 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 商户编号 | string |  |  |  |
| id | 额度充值ID | string | 额度充值ID |  |  |
| cal\_type | 额度包计算类型 | string | 交易金额:TRADE\_AMOUNT 补贴金额:SUBSIDY\_AMOUNT |  |  |
| total\_amount | 总额度(元) | string | 总额度(元) |  |  |
| used\_amount | 已使用额度(元) | string | 已使用额度(元) |  |  |
| period\_type | 期限类型 | string | SHORT\_PERIOD 短期有效 LONG\_PERIOD 长期有效 |  |  |
| amount | 剩余额度(元) | string |  |  |  |
| active\_time | 额度有效期开始日 | string |  |  |  |
| expire\_time | 额度有效期结束日 | string |  |  |  |
| status | 额度状态 | string |  |  |  |

文档更新时间: 2025-09-05 11:36   作者：闵丹阳