## 支付宝-投诉详情

### 基本信息

**Path：** /api/v1/complaint/ali/detail

**Method：** POST

**接口描述：**

### 请求参数

**Headers**

| 参数名称 | 参数值 | 是否必须 | 示例 | 备注 |
| --- | --- | --- | --- | --- |
| Content-Type | application/json | 是 |  |  |
| **Body** |  |  |  |  |

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| complaintId | string | 必须 |  | 投诉订单号 |  |

### 请求示例

```
{
  "complaintId": "177454931",
  "accessid": "4028803d6a97099f016a9b3d8f57000f",
  "sign": "3B13E5343E42A6D1153A216EEFA5496F"
}
```

### 返回数据

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| complaintId | string | 非必须 |  | 投诉主表主键id |  |
| oppositePid | string | 非必须 |  | 被投诉人pid |  |
| oppositeName | string | 非必须 |  | 被投诉人名称 |  |
| complainAmount | string | 非必须 |  | 投诉单涉及交易总金额（单位：人民币元） |  |
| contact | string | 非必须 |  | 联系方式 |  |
| gmtComplain | string | 非必须 |  | 投诉时间 |  |
| gmtProcess | string | 非必须 |  | 处理时间 |  |
| gmtOverdue | string | 非必须 |  | 过期时间 |  |
| complainContent | string | 非必须 |  | 投诉内容 |  |
| tradeNo | string | 非必须 |  | 交易单号 |  |
| status | string | 非必须 |  | 投诉单状态码 用户撤诉: DROP\_COMPLAIN 超时后用户撤诉: DROP\_OVERDUE\_COMPLAIN 超时处理完成用户撤诉: DROP\_OVERDUE\_PROCESSED 处理完成用户撤诉: DROP\_PROCESSED 超时未处理: OVERDUE 超时处理完成: OVERDUE\_PROCESSED 部分超时未处理: PART\_OVERDUE 处理完成: PROCESSED 处理中: PROCESSING 待处理: WAIT\_PROCESS |  |
| statusDescription | string | 非必须 |  | 状态描述 |  |
| processCode | string | 非必须 |  | 商家处理结果码 已联系到用户，协商一致，无异议: CONSENSUS\_WITH\_CLIENT 其他: ORTHER 不涉及退款，已针对投诉内容进行整改: RECTIFICATION\_NO\_REFUND 已退款，用户无异议: REFUND 已提交证明材料: SUBMIT\_PROOF\_NOT\_CONTACTED |  |
| processMessage | string | 非必须 |  | 商家处理结果码对应描述 |  |
| processRemark | string | 非必须 |  | 商家处理备注 |  |
| processImgUrlList | string | 非必须 |  | 商家处理备注图片url列表 |  |
| gmtRiskFinishTime | string | 非必须 |  | 推送时间 |  |
| taskId | string | 非必须 |  | 投诉单号id |  |
| certifyInfo | string | 非必须 |  | 投诉凭证图片信息特殊 |  |
| complainUrl | string | 非必须 |  | 投诉网址 |  |
| detailList | object [] | 非必须 |  |  | item 类型: object |
| ├─ complaintId | string | 非必须 |  | 投诉主表主键id |  |
| ├─ detailId | string | 非必须 |  | 交易信息表主键id |  |
| ├─ complaintRecordId | string | 非必须 |  | 投诉主表id |  |
| ├─ tradeNo | string | 非必须 |  | 支付宝交易单号 |  |
| ├─ outNo | string | 非必须 |  | 商家订单号 |  |
| ├─ gmtTrade | string | 非必须 |  | 交易时间 |  |
| ├─ gmtRefund | string | 非必须 |  | 退款时间 |  |
| ├─ status | string | 非必须 |  | 交易投诉状态 用户撤诉: DROP\_COMPLAIN 超时未处理: OVERDUE 已退款: PROCESSED 退款处理中: REFUNDING 待处理: WAIT\_PROCESS |  |
| ├─ statusDescription | string | 非必须 |  | 交易投诉状态描述 |  |
| ├─ amount | string | 非必须 |  | 交易单金额（单位：人民币元） |  |
| ├─ transFirstLevelAgentNum | null | 非必须 |  | 交易一级服务商编号 |  |
| ├─ transFirstLevelAgentName | null | 非必须 |  | 交易一级服务商名称 |  |
| ├─ transAgentNum | null | 非必须 |  | 交易服务商编号 |  |
| ├─ transAgentName | null | 非必须 |  | 交易服务商名称 |  |
| ├─ transMercNum | null | 非必须 |  | 交易商户编号 |  |
| ├─ transMercName | null | 非必须 |  | 交易商户名称 |  |
| ├─ bussOrderNo | null | 非必须 |  | 业务交易订单号 |  |

### 返回示例

```
{
  "processMessage": "",
  "complainContent": "售卖机支付后没有出货要求退款",
  "oppositeName": "商户_刘某",
  "processRemark": "",
  "certifyInfo": "",
  "complainUrl": "",
  "gmtOverdue": "2024-11-09 18:43:13",
  "contact": "",
  "gmtRiskFinishTime": "2024-11-06 18:43:13",
  "processImgUrlList": "",
  "tradeNo": "2024100522001492561429009757",
  "oppositePid": "2088340*****9593",
  "statusDescription": "超时未处理",
  "complaintId": "177454931",
  "processCode": "",
  "detailList": [
    {
      "amount": "5.00",
      "tradeNo": "2024100522001492561429009757",
      "complaintRecordId": "177454931",
      "detailId": "195571969",
      "gmtRefund": "2024-11-06 18:43:14",
      "gmtTrade": "2024-10-05 02:45:14",
      "statusDescription": "待处理",
      "complaintId": "177454931",
      "outNo": "6812660000483300037895221650645530",
      "status": "WAIT_PROCESS",
      "transFirstLevelAgentNum": "FW1000161",
      "transMercNum": "833308348140929",
      "transAgentNum": "ISV003668",
      "bussOrderNo": "AL2411261443100001881562945"
    }
  ],
  "complainAmount": "5.00",
  "gmtProcess": "2024-11-06 18:43:13",
  "gmtComplain": "2024-11-06 18:43:07",
  "taskId": "11590429759",
  "status": "OVERDUE",
  "return_code": 10000
}
```

文档更新时间: 2025-05-28 18:18   作者：郝庚鑫