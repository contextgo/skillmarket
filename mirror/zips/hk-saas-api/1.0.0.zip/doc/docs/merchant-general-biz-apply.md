#### 简要描述：

#### 1.1.商户通用业务申请(**目前此接口适用于万事达内外卡，以及Visa、Jcb、Diners外卡业务申请**)

#### 1.1.1.接口说明

适用于万事达内外卡，以及Visa、Jcb、Diners外卡业务申请

#### 1.1.2请求URL:

* <http://47.95.131.62:8080/api/v2/common-biz/apply>

#### 1.1.3请求参数：

| 参数 | 参数名称 | 类型 | 参数说明 | 必填 | 样例 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 服务商的编号，由SAAS平台分配，表示当前商户属于该服务商名下 | M | ISV12346 |
| agent\_apply\_no | 服务商申请单号 | String | 服务商系统生成的请求流水号，保证唯一 | M | SQB123456 |
| merch\_no | 商户编号 | String | 商户入网返回的833商户号 | M | 833….. |
| biz\_type | 业务类型 | String | Saas业务类型:**万事达内卡**:MASTERCARD,**万事达外卡**:MASTERCARDINTER,**Visa外卡**:VISACARD,**Jcb外卡**:JCBCARD,**Diners外卡**:DINERSCARD | M | MASTERCARD |
| biz\_info | 业务信息 | JSON | 业务申请的具体信息 | M | {xxx:xxx} |
| notify\_url | 异步通知地址 | String | 异步回调通知业务申请结果 | O | [www.baidu.com](http://www.baidu.com) |

#### 业务类型MASTERCARD的业务参数:

| 参数 | 参数名称 | 类型 | 参数说明 | 必填 | 样例 |
| --- | --- | --- | --- | --- | --- |
| bank\_debit\_rate | 银行卡借记卡费率 | String | 0.6% 传60 | M | 60 |
| bank\_debit\_max | 银行卡借记卡封顶金额 | String | 18元传1800 | M | 1800 |
| bank\_credit\_rate | 银行卡贷记卡费率 | String | 0.6% 传60 | M | 60 |

#### 业务类型VISACARD/JCBCARD/DINERSCARD/MASTERCARDINTER的业务参数:

| 参数 | 参数名称 | 类型 | 参数说明 | 必填 | 样例 |
| --- | --- | --- | --- | --- | --- |
| out\_bank\_dcc\_rate | 国际卡dcc费率 | String | 0.6% 传60 | M | 60 |
| out\_bank\_edc\_rate | 国际卡edc费率 | String | 0.6% 传60 | M | 60 |

#### 1.1.4返回参数:

| 参数 | 参数名称 | 类型 | 参数说明 | 必填 | 样例 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | String | 10000成功,其他失败 | Y | 10000 |
| return\_msg | 返回信息 | String | 信息描述 | Y | 成功 |
| apply\_no | 业务申请单号 | String | 业务申请单号(1000返回) |  | 10000 |

**附件**

* [SaaS对外接口文档(国际卡).docx](http://39.106.84.215:8181/attach_files/saas/696 "SaaS对外接口文档(国际卡).docx")
* [SaaS对外接口文档(万事网联).docx](http://39.106.84.215:8181/attach_files/saas/616 "SaaS对外接口文档(万事网联).docx")

文档更新时间: 2024-12-18 16:25   作者：admin