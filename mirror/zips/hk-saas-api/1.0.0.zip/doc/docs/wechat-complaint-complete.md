## 微信-反馈处理完成

### 基本信息

**Path：** /api/v1/complaint/wechat/disposeFinish

**Method：** POST

**接口描述：**

### 备注

### 请求参数

**Headers**

| 参数名称 | 参数值 | 是否必须 |
| --- | --- | --- |
| Content-Type | application/json | 是 |

**Body**

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| complaintId | string | 必须 |  | 投诉单号 |  |
| complaintedMchid | string | 必须 |  | 被诉商户号 |  |

### 请求示例

```
{
  "accessid": "4028803d6a97099f016a9b3d8f57000f",
  "signKey": "fa907d6e05cc4869a3330add779e9ff7",
  ...
}
```

### 返回数据

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| rspCode | string | 必须 |  | 返回码 |  |
| rspMsg | string | 必须 |  | 返回信息 |  |

文档更新时间: 2024-11-19 15:14   作者：胡闽川