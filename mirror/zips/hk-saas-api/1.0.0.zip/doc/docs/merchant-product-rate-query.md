#### 概要描述:

商户产品开通及费率查询接口

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/merchant-info/query-merchant-product>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |
| agent\_no | 服务商编号 | String | 服务商编号 |  | M |

#### 请求示例:

```
{
    "agent_no": "11010200097",
    "merch_no": "88888888",
    "accessid": "cpostest",
    "sign": "D3D8612BC3F5441893B02F8D88DA4ADC"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| merch\_apply\_status | 商户申请单状态 | String | 1:提交失败 2:已受理 3:自动审核 4:待审核 5:审核失败 6:审核拒绝 7:审核成功 申请单状态为[提交失败、已受理、审核拒绝]时不返回相关信息 |  | M |
| apply\_info | 收单产品开通信息 | JSONArray | 包含业务开通原申请单号、业务产品类型、费率 |  | O |
| settlement\_info | 出款产品开通信息 | JSONArray | 包括结算周期（结算产品）、提现费率、单笔最低提现费率 |  | O |

##### 收单产品开通信息：apply\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| apply\_type | 申请单类型 | String | WX\ALI\BA |  | M |
| apply\_no | 服务商申请单号 | String | 服务商申请单号 |  | M |
| apply\_status | 服务商申请单状态 | String | 0:待报备 1:报备中 2:报备失败 3:报备成功 |  | M |
| rate | 费率 | String | 阶梯费率。银行卡（BA）分为银行卡费率（bank\_rate）和银联二维码（union\_rate）费率 |  | M |

##### 出款产品开通信息：settlement\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| settlement\_cycle | 结算周期 | String | T1(工作日) D1(每日) D0(当日到账) |  | M |
| withdrawal\_rate | 费率 | String |  |  | M |
| withdrawal\_fee\_min | 单笔最低手续费 | String |  |  | M |
| public\_withdrawal\_rate | 对公费率 | String | 单位为：%，比如费率为 0.6%, 有对公费率时返回 |  | C |
| public\_withdrawal\_feemin | 对公单笔最低手续费 | String | 单位为：元，比如费率为 1, 哟对公费率时返回 |  | C |

#### 成功时返回示例:

```
{
    "merch_apply_status": "4",
    "apply_info": [
        {
            "apply_type": "WX",
            "apply_no": "200609145721263927509320",
            "apply_status": "3",
            "rate": [
                {
                    "minAmt": "0",
                    "maxAmt": "10000000",
                    "rate": "0.6"
                }
            ]
        },
        {
            "apply_type": "AL",
            "apply_no": "200609145721303926990368",
            "apply_status": "3",
            "rate": [
                {
                    "minAmt": "0",
                    "maxAmt": "10000000",
                    "rate": "0.6"
                }
            ]
        },
        {
            "apply_type": "BA",
            "apply_no": "190826105818233000224400",
            "apply_status": "3",
            "bank_rate": [
                {
                    "minAmt": "0",
                    "maxAmt": "10000000",
                    "bankDebitRate": "0.6",
                    "bankDebitMax": "18",
                    "bankCreditRate": "0.6"
                }
            ],
            "union_rate": [
                {
                    "minAmt": "0",
                    "maxAmt": "1000.01",
                    "unionDebitRate": "0.6",
                    "unionDebitMax": "1000",
                    "unionCreditRate": "0.6"
                },
                {
                    "minAmt": "1000.01",
                    "maxAmt": "10000000",
                    "unionDebitRate": "0.6",
                    "unionDebitMax": "18",
                    "unionCreditRate": "0.6"
                }
            ]
        }
    ],
    "settlement_info": [
        {
            "settlement_cycle": "T1",
            "withdrawal_rate": "0",
            "withdrawal_fee_min": "0"
        }
    ],
    "return_code": 10000,
    "sign": "D67057B7FAFCFE773022FCF422402714"
}
```

文档更新时间: 2025-08-21 10:13   作者：admin