#### 概要描述:

当交易发生之后一段时间内，由于买家或者卖家的原因需要退款时，卖家可以通过退款接口将支付款退还给买家，微信支付将在收到退款请求并且验证成功之后，按照退款规则将支付款按原路退到买家帐号上。

注意：  
1、交易时间超过90天的订单无法提交退款。  
2、预授权订单只支持一次预授权完成或预授权撤销。  
3、预授权完成金额不能超过预授权订单金额。

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/api/v2/pre-auth/revoke>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String(32) | 海科商户编号 |  | M |
| out\_trade\_no | 服务商预授权订单号 | String(32) | trade\_no、out\_trade\_no二选一上送,优选顺序：trade\_no、out\_trade\_no |  | C |
| trade\_no | 海科预授权订单号 | String(32) | trade\_no、out\_trade\_no二选一上送,优选顺序：trade\_no、out\_trade\_no |  | C |
| out\_pre\_auth\_no | 服务商预授权撤销订单号 | String(32) | 服务商内部订单号（同一服务商下唯一） |  | M |
| pn | SAAS终端号 | String(32) | SAAS终端号 |  | M |
| notify\_url | 异步通知地址 | String(128) | 交易成功异步通知地址 |  | O |
| remark | 备注 | String(100) | 交易备注 |  | O |

#### 请求示例:

```
{
  "agent_no": "FW3002100",
  "req_id": "@id",
  "merch_no": "833103159990017",
  "pn": "APP0006738",
  "trade_no": "WX2412051001450000896977846",
  "out_pre_auth_no": "@id",
  "extend_params": {
    "body": "商品测试2"
  },
  "remark": "撤销",
  "sign": "dawangjiaowolaixunshan",
  "signKey": "d47dbc6342dc4f0b8bcd7f676524a234",
  "notify_url": "http://39.105.99.14:8080/test/v1/async/notify"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表业务处理成功，交易结果需要根据trade\_status判断 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科商户编号 |  | M |
| trade\_no | 海科订单号 | String |  |  | M |
| pay\_type | 支付类型 | String | WX：微信支付 ALI：支付宝支付 UNIONQR：云闪付 |  | M |
| trade\_status | 交易状态 | String | 1：交易成功 2：交易失败 3：交易进行中 |  | M |
| attach | 通道原生参数 | String |  |  | O |

#### 返回示例:

```
{
  "merch_no": "833103159990017",
  "result_msg": "请求成功",
  "trade_status": "1",
  "end_time": "2024-12-05 10:02:56",
  "sign": "E009A81BF82FFF9616ED06840D93A0A5",
  "trade_no": "WX2412051002550000614789803",
  "agent_no": "FW3002100",
  "pay_type": "WX",
  "result_code": "10000",
  "return_msg": "成功",
  "attach": "{\"nonce_str\":\"432ac77c19134ddfb37444de36d0cd47\",\"out_refund_no\":\"WX2412051002550000614789803\",\"settlement_refund_fee\":\"1\",\"cert_id\":\"4233741533\",\"return_msg\":\"成功\",\"fee_type\":\"CNY\",\"mch_id\":\"1505378701\",\"sub_mch_id\":\"626185853\",\"refund_id\":\"50102401782024120535837450548\",\"coupon_refund_fee\":\"0\",\"refund_create_time\":\"2024-12-05 10:02:55\",\"appid\":\"wx17728c1a8fa300d6\",\"refund_fee\":\"1\",\"result_code\":\"SUCCESS\",\"cash_refund_fee\":\"1\",\"sign_type\":\"SM2\",\"return_code\":\"SUCCESS\"}",
  "return_code": "SUCCESS"
}
```

文档更新时间: 2025-01-10 09:25   作者：陈文