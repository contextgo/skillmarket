#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/merchant-image/upload>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| image | 图片文件 | String | 图片文件转成base64后的数据,截取data:image/png;base64, 之后的数据进行上传,否则后端无法正确展示图片 |  | M |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "image": "imgToBase64data...",
    "sign": "91741FA7910DC5EB2B325130BDBA1164"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| image\_id | 图片id | String | 图片id | image12345 | O |

#### 返回示例:

```
{"reqData":{"accessid":"cpostest","sign":"402432F5366156BA11E81E0A30A5CF8C"},"respData":{"image_id":"6ea605328e93413190cac49dd7965e59","return_code":10000,"sign":"216E9A00BFEA61B76D34035C2234BF86"}}
```

文档更新时间: 2025-06-26 11:32   作者：王金晶