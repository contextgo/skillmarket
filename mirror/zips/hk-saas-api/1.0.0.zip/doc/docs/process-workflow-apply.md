#### 概要描述:

服务商可调用该接口发起SAAS流程工单申请和修改（审核驳回时）。

* SAAS目前支持发起的工单申请如下：  
  1、【商户提额申请】  
  1.1、申请提额的商户须符合以下条件：①商户状态=启用；②该商户当下没有在申请中的商户提额申请单（在申请中定义：商户提额申请单状态=审核中或审核驳回，审核拒绝和审核通过为终态，可再次发起申请）  
  1.2、申请单名称=商户提额；申请单类型=商户类型；申请变更值：须上传申请的贷记卡单笔额度等值，申请额度值的规则：单月金额≥单日金额≥单笔金额；  
  1.3、可调用9.1接口查询商户当前额度。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/flow/apply>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 商户编号 | String |  |  | M |
| flow\_no | 申请单编号 | String | 驳回修改时必传 |  | O |
| flow\_type | 申请单类型 | String | 商户类型：MERCH 服务商类型：AGENT 终端类型：TERMINAL |  | M |
| biz\_type | 申请单名称 | String | 商户提额：RAISE\_LIMIT |  | M |
| after\_value | 申请变更值 | JSON |  |  | M |
| apply\_reason | 申请原因 | String | 最大长度100 |  | M |
| attach\_info | 申请附件信息 | JSON | 若传申请附件信息，则视频ID和图片ID至少传一项 |  | O |

##### 申请变更值：after\_value

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| cardCreditSingleAmount | 贷记卡单笔额度 | String | 单位：元 |  | M |
| cardCreditDayAmount | 贷记卡单日限额 | String | 单位：元 |  | M |
| cardDebitSingleAmount | 借记卡单笔额度 | String | 单位：元 |  | M |
| cardDebitDayAmount | 借记卡单日额度 | String | 单位：元 |  | M |
| cardDayAmount | 卡交易单日额度 | String | 单位：元 |  | M |
| cardMonthAmount | 卡交易单月额度 | String | 单位：元 |  | M |
| scanSingleAmount | 扫码交易单笔额度 | String | 单位：元 |  | M |
| scanDayAmount | 扫码交易单日额度 | String | 单位：元 |  | M |
| scanMonthAmount | 扫码交易单月额度 | String | 单位：元 |  | M |

##### 申请附件信息：attach\_info

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| video | 视频ID | String | 视频ID,多个用”,”号分割 |  | O |
| image | 图片ID | String | 图片ID,多个用”,”号分割 |  | O |

#### 请求示例:

```
{
    "agent_no": "FW1002041",
    "merch_no": "833102259700486",
    "flow_no": "",
    "flow_type": "MERCH",
    "biz_type": "RAISE_LIMIT",
    "after_value": "{        
        "cardCreditDayAmount": "10",
        "cardCreditSingleAmount": "11",
        "cardDayAmount": "13",
        "cardDebitDayAmount": "122",
        "cardDebitSingleAmount": "130",
        "cardMonthAmount": "144",
        "scanDayAmount": "14.44",
        "scanMonthAmount": "16",
        "scanSingleAmount": "11"
    }",
    "attach_info": "{
        "video": "",
        "image": "cd1d117a89354c2b963fc06a9c261222,cce83be6c3f44ac6aa3a15c141275077,e78f6e1422f0481787de82f4cccb275d,5e2254762eda4b4d9d17e4ca133cdf43,0c45d32697d24c02a09d36924090a478,70ed2c8271b64aedad831ddde191bff3"
    }",
    "apply_reason": "申请信息"   
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | String |  |  | M |
| return\_msg | 错误信息 | String | return\_code不为10000时有值 |  | O |
| flow\_no | 申请单编号 | String | return\_code=10000时返回 |  | O |

#### 成功时返回示例:

```
{
 "flow_no": "A23051000000003",
    "return_code": 10000,
    "sign": "1BC833BBB88864884F766792DE5CC912"
}
```

文档更新时间: 2024-11-29 11:20   作者：admin