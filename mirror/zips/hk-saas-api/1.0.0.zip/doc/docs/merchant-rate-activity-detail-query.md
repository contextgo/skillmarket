# 1.商户费率活动明细查询API

## 1.1接口说明

* 本接口适用于查询服务商下参加费率活动商户所有配置的费率活动明细查询
* 商户可以配置多个费率活动模板，但同一时间段内可执行的费率活动仅有一个

## 1.2请求URL

<http://47.95.131.62:8080/api/v1/activity/merchant/rate/detail>

## 1.3请求参数（Y-必传，N-非必传）

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 必填 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String(16) | 海科服务商编号 | ISV/FW+xxxx | Y |
| merch\_no | 海科商户编号 | String(32) | 海科商户编号 | 833+xxxx | Y |

## 1.4请求示例

```
{
    "accessid": "cpostest",
    "agent_no": "FW200097",
    "merch_no": "833226358120003",
}
```

## 1.5返回信息

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 必填 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回状态码 | String | 10000：成功，其他：失败 | 10000 |  |
| return\_msg | 返回信息 | String | 返回信息 |  |  |
| detail\_list | 费率活动模板list | json | 参考下表 |  |  |

**费率活动模板list**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 必填 |
| --- | --- | --- | --- | --- | --- |
| activity\_id | 费率活动模板ID | String |  |  |  |
| type | 活动类型 | String | rate固定优惠费率活动fixed固定补贴费率活动 |  |  |
| start\_date | 活动报名开始时间 | String |  |  |  |
| end\_date | 活动报名结束时间 | String |  |  |  |
| effective\_time | 活动执行开始时间 | String |  |  |  |
| invalid\_time | 活动执行结束时间 | String |  |  |  |
| status | 费率活动状态 | String | 1、已生效2、待生效 |  |  |

文档更新时间: 2025-04-21 10:23   作者：闵丹阳