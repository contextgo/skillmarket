#### 概要描述:

该接口提供所有码交易支付订单的查询，商户可以通过该接口主动查询订单状态，完成下一步的业务逻辑。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/pay/digitalwallet/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String | 海科平台商户编号 |  | M |
| out\_trade\_no | 服务商交易订单号 | String | trade\_no、out\_trade\_no必传其中一个，都传则以trade\_no为准，推荐使用trade\_no |  | O |
| trade\_no | 海科支付订单号 | String | trade\_no、out\_trade\_no必传其中一个，都传则以trade\_no为准，推荐使用trade\_no |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "merch_no": "83388888888",
    "trade_no": "123456789",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 响应码 | String | 10000代表成功 |  | M |
| return\_msg | 响应信息 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户编号 |  | M |
| out\_trade\_no | 服务商交易订单号 | String |  |  | M |
| trade\_no | 海科支付订单号 | String |  |  | M |
| trade\_status | 交易状态 | String | 1：交易成功 2：交易失败 3：交易进行中 4：交易超时 |  | M |
| trade\_end\_time | SaaS平台交易完成时间 | String | SaaS平台交易完成时间，交易完成以后会返回 | 2021-04-01 14:11:23 | M |
| error\_code | 错误码 | String |  |  | O |
| error\_msg | 错误消息 | String |  |  | O |

#### 返回示例:

```
{
    "merch_no": "83388888888",
    "out_trade_no": "123456789",
    "trade_no": "AL88888888",
    "trade_status": "1",
    "trade_end_time": "2021-04-01 14:11:23",
    "return_code": "10000",
    "return_msg": "成功",
    "sign": "1032A57E96E4048B27EC2A5C3CE5E663"
}
```

文档更新时间: 2024-11-29 10:11   作者：陈文