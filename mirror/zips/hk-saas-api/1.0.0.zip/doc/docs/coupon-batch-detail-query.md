#### 概要描述:

通过此接口可查询批次信息，包括批次的配置信息以及批次概况数据。

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/front-api/wx-coupon/query-stock>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| stock\_id | 卡券批次id | String(64) | 微信为每个批次分配的唯一id |  | M |
| appid | appid | String(64) | appid |  | O |

#### 请求示例:

```
{
    "agent_no": "IS88888888",
    "req_id": "147258369",
    "appid": "",
    "stock_id": "",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表成功 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| stock\_id | 卡券批次id | String | result\_code 为成功时返回 |  | M |
| stock\_creator\_mchid | 商户号 | String | 创建方商户 |  | M |
| stock\_name | 批次名称 | String |  |  | M |
| status | 批次状态 | String | unactivated：未激活 audit：审核中 running：运行中 stoped：已停止 paused：暂停发放 |  | M |
| create\_time | 创建时间 | String | 批次创建时间，遵循rfc3339标准格式，格式为yyyy-MM-DDTHH:mm:ss.sss+TIMEZONE，yyyy-MM-DD表示年月日，T出现在字符串中，表示time元素的开头，HH:mm:ss.sss表示时分秒毫秒，TIMEZONE表示时区（+08:00表示东八区时间，领先UTC 8小时，即北京时间）。例如：2015-05-20T13:29:35.120+08:00表示，北京时间2015年5月20日 13点29分35秒。 |  | M |
| description | 使用说明 | String | 批次描述信息 |  | M |
| stock\_use\_rule | 满减券、消费金批次使用规则 | object | 详见微信原生文档 |  | M |
| available\_begin\_time | 可用开始时间 | object | 遵循rfc3339标准格式，格式为yyyy-MM-DDTHH:mm:ss.sss+TIMEZONE |  | M |
| available\_end\_time | 可用结束时间 | object | 遵循rfc3339标准格式，格式为yyyy-MM-DDTHH:mm:ss.sss+TIMEZONE |  | M |
| distributed\_coupons | 已发券或消费金数量 | integer | 已发券或消费金数量 |  | M |
| no\_cash | 是否无资金流 | boolean | 枚举值： ture：是 false：否 |  | M |
| start\_time | 激活批次的时间 | string | 循rfc3339标准格式，格式为yyyy-MM-DDTHH:mm:ss.sss+TIMEZONE |  | O |
| stop\_time | 终止批次的时间 | string | 循rfc3339标准格式，格式为yyyy-MM-DDTHH:mm:ss.sss+TIMEZONE |  | O |
| cut\_to\_message | 减至批次特定信息 | object | 单品优惠特定信息 |  | O |
| singleitem | 是否单品优惠 | string | 单品优惠特定信息 枚举值： ture：是 false：否 |  | M |
| stock\_type | 批次类型 | string | 枚举值： NORMAL：代金券批次 DISCOUNT\_CUT：立减与折扣 OTHER：其他 |  | M |
| card\_id | 卡包ID | string | 微信卡包ID |  | O |
| business\_type | 业务类型 | string | 细分业务类型，仅有当business\_type=MULTIUSE时，才会返回。  枚举值:MULTIUSE：消费金 |  | C |
| available\_region\_list | 消费金可用地域 | JSONArray | 消费金可用地域列表，仅有当business\_type=MULTIUSE时，才会返回。 |  | C |
| available\_industry\_list | 消费金可用行业 | JSONArray | 消费金可用行业列表，仅有当business\_type=MULTIUSE时，才会返回。 |  | C |

#### 返回示例:

```
{
    "stock_name": "有资金券0.3减0.2",
    "create_time": "2024-05-08T11:12:58+08:00",
    "available_end_time": "2024-11-08T23:59:59+08:00",
    "singleitem": false,
    "sign": "107308B9F39689BD21B11C1FF27815D4",
    "description": "",
    "return_msg": "成功",
    "stock_id": "88888888",
    "stock_type": "DISCOUNT_CUT",
    "result_msg": "请求成功",
    "no_cash": false,
    "stock_creator_mchid": "12345678",
    "stock_use_rule": {
        "max_amount_by_day": 0,
        "goods_tag": [],
        "combine_use": true,
        "max_amount": 220,
        "trade_type": [],
        "max_coupons_per_user": 10,
        "fixed_normal_coupon": {
            "coupon_amount": 20,
            "transaction_minimum": 30
            },
        "max_coupons": 11,
        "coupon_type": "NORMAL"
  },
    "result_code": "10000",
    "return_code": "SUCCESS",
    "available_begin_time": "2024-05-08T00:00:00+08:00",
    "distributed_coupons": 2,
    "status": "running"
}
```

文档更新时间: 2025-02-13 09:50   作者：王思阳