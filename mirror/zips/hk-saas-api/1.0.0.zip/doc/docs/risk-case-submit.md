#### 简要描述：

1、风控案例提交信息接口

#### 请求URL:

* 测试环境： <http://47.95.131.62:8080/api/v1/agent/risk/case/commit>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| caseNo | 案例编号 | String |  | 20230511155524394956750290100 | M |
| operator | 提交人 | String | 张三 |  | M |
| agentNo | 服务商编号 | String | 隶属服务商编号 |  | O |
| surveyRemark | 备注 | String | 备注 |  | O |
| surveyWay | 调查方式 | String | DHDC：电话调查 SDKC:实地考察 |  | O |
| surveyResult | 调查结果回复 | String | 调查结果回复 |  | O |
| businessLicensesStr | 营业执照照片 | String | 案例对应商户为小微时可以为空 |  | C |
| businessPlacesStr | 营业场所 | String | 营业场所照片 |  | M |
| headSignsStr | 门头照片 | String | 门头照片 |  | M |
| tradeStatementsStr | 交易相关照片 | String |  |  | O |
| tradeReceiptsStr | 交易凭证照片 | String | 交易凭证照片 |  | O |
| tradeCardsStr | 涉及交易卡照片 | String |  |  | O |
| guaranteesStr | 承诺函照片 | String |  |  | O |
| othersStr | 其他照片 | String |  |  | O |
| idCardsStr | 身份证正反照片 | String |  |  | M |
| machinesStr | 终端机具照片 | String |  |  | O |
| attachmentsStr | 附件zip | String | 附件压缩包 |  | O |
| attachmentsOriName | 附件原始名称 | String |  |  | O |

#### 请求示例:

```
{
   "caseNo": "20230511155524394956750290100",
   "operator": "张三",
   "surveyWay":"DHDC" ,
  "surveyRemark":"已核实清楚，没有风险问题" ,
  "businessPlacesStr":"77cf1a60f951357417057f80750,77cf1a60f95145741705780750",
  "businessLicensesStr":"77cf1a60fbb357417057f80750,77cf1a60f95741705780750",
  "headSignsStr":"77cf1a60f95140557417057f80750,77cf1a60f95140b3505780750",
  "idCardsStr":"77cf1a60f95140750,77cf1a60f95140705780750",
  "accessid": "4028805b6e86d179016e874f6c4200ad",
  "sign": "975077BFC098C592C721A3948A97460F"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 申请成功 |  | O |

#### 返回示例:

```
{

    "return_code": 10000
}
```

文档更新时间: 2025-12-26 13:37   作者：张亚飞