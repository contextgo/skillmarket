### 获取用户openid

**业务功能**  
获取用户在海科公众号下的唯一用户标识openid，适用于使用海科渠道号并且使用海科公众号做支付的商户。  
**交互模式**  
服务商使用**页面重定向**的方式进行请求本接口，并上送服务商的重定向地址，haipay获取到用户标识以后会**重定向到指定的地址**，并在地址后面携带响应的返回参数（URL传参的方式）。整个过程需要在微信app中完成  
**测试url：**  
<http://47.95.131.62:8080/api/v1/pay/wx/getOpenid>

**请求参数(O-非必传 ,M-必传):**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| redirect\_url | 回调地址 | String | 获取到用户openid后重定向的回调链接地址。请不要在地址后面拼接参数，如果要透传参数请使用RESTful风格的回调地址，直接拼接在地址后面的参数将会被忽略 | https://www.myurl/aaaa/bbbb | M |

#### 请求示例:

`http://47.95.131.62:8080/api/v1/pay/wx/getOpenid?accessid=cpostest&redirect_url=https://www.myurl/aaaa/bbbb&sign=CC213C22BE87F1878C0EEE82D0C81CF9`

**返回参数:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| appid | 公众号appid | String | 海科公众号appid | wx8888888888888888 | M |
| openid | 用户唯一标识 | String | 用户相对海科公众号的唯一标识 | oUpF8uMuAJO\_M2pxb1Q9zNjWeS6o | M |

#### 返回示例:

`http://test.abc.cn/callback?return_code=10000&return_msg=成功&appid=wx8888888888888888&openid=oUpF8uMuAJO_M2pxb1Q9zNjWeS6o&sign=953A3CE8C278BB7A8BA277419724C3FD`

文档更新时间: 2024-12-05 18:02   作者：admin