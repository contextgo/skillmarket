#### 概要描述:

服务商可以通过此接口查询打款结果、商户结算状态

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/payment/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 不为空 |  | M |
| merch\_no | 商户编号 | String | 商户编号、结算单号二选一 |  | O |
| merchantOrderNo | 结算订单号 | String | 商户编号、结算单号二选一 |  | O |
| trade\_no | 交易订单号 | String | 仅TS交易查询使用 |  | O |
| remit\_time\_start | 结算日期起 | String | (YYYY-MM-DD) 商户编号不为空时，必填 |  | O |
| remit\_time\_end | 结算日期止 | String | (YYYY-MM-DD) 商户编号不为空时，必填 |  | O |

#### 请求示例:

```
{
    "agent_no": "ISV000219",
    "merch_no": "833102053310098",
    "merchantOrderNo": "202210280630008218246",
    "remit_time_start": "",
    "remit_time_end": "",
    "accessid": "4028805b6e86d179016e874f6c4200ad",
    "sign": "75D24750A18EA190659ECBAEFC9BE269"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 商户编号 | String | 服务商编号 |  | M |
| agent\_no | 服务商编号 | String | 商户编号 |  | M |
| list | 结算状态关系组 | List | 格式为：JsonArray |  | M |

##### 结算状态关系组：list

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| remitTime | 结算日期 | String | 结算日期 | 生成日期YYYY-MM-DD | M |
| merchantOrderNo | 结算订单号 | String | 结算订单号 |  | M |
| trade\_no | 交易订单号 | String | TS结算时该字段有值 |  | O |
| failReason | 失败原因 | String |  |  | O |
| remitStatus | 出款状态 | String | 打款成功,打款失败 |  | O |
| updateTime | 更新时间 | String | YYYY-MM-DD hh:mm:ss |  | O |
| remark | 备注 | String |  |  | O |
| remitAmount | 结算金额 | String | 单位为元 |  | O |
| realAmount | 实际到账金额 | String | 单位为元 |  | O |
| fee | 手续费 | String | 单位为元 |  | O |
| settlementCycle | 出款方式 | String |  |  | O |
| cardNo | 银行卡号 | String | 前6后4脱敏 |  | O |
| bankName | 银行名称 | String |  |  | O |
| accName | 账户名称 | String |  |  | O |
| accType | 结算账户类型 | String | 10A:对公 10B:对私 10C:对私非法人 |  | O |
| channel\_flag | 打款通道 | String | CUP：银联、NUCC：网联 |  | O |
| btxnNo | 通道流水号 | String | 银行入账流水号，用于与银行间查询结算流水 |  | O |

#### 成功时返回示例:

```
{
    "merch_no": "833102053310098",
    "agent_no": "ISV000219",
    "list": [
        {
            "remitStatus": "打款成功",
            "fee": "0.01",
            "accName": "侯敏",
            "bankName": "建设银行",
            "updateTime": "2022-10-19 11:27:55",
            "remark": "60:发卡方状态不正常，请稍后重试[609X1000091][通知]",
            "merchantOrderNo": "202210182200043533825",
            "cardNo": "436742*********0226",
            "mercNo": "833102053310098",
            "realAmount": "0.01",
            "failReason": "测试推送：20221019线下打款",
            "settlementCycle": "D0",
            "remitTime": "2022-10-18",
            "remitAmount": "0.02",
            "accType": ""
        }
    ],
    "return_code": 10000,
    "sign": "AF7664D355FA2EA35F97732A6292C1BE"
}
```

文档更新时间: 2025-11-07 14:12   作者：admin