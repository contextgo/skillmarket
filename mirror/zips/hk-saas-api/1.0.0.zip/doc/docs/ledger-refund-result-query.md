## 业务功能

查询分账资金归集结果；

## 交互模式

请求：后台请求交互模式  
返回结果：后台请求交互模式

## 接口地址

api/v1/merchant-ledger/collection-query

## 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 可空 |
| --- | --- | --- | --- | --- |
| agent\_apply\_no | 服务商申请单号 | String | 分账归集请求订单号 | M |
| agent\_no | 服务商编号 | String |  | M |
| merch\_no | 商户编号 | String |  | M |
| ledger\_type | 分账类型 | String | 原交易订单分账类型  DELAY\_SETTLE延时分账  REALTIME\_SETTLE实时分账 | M |

## 请求示例

```
{
    "agent_no": "FW1000566",
    "merch_no": "833102158123880",
    "agent_apply_no": "773955587951",
    "ledger_type": "DELAY_SETTLE",
    "accessid": "4028803d6a97099f016a9b3d8f57000f",
    "sign": "529070FC7DBB3214C25AA7DF59749977"
}
```

## 返回参数

| 参数 | 参数名称 | 类型 | 参数说明 | 可空 |
| --- | --- | --- | --- | --- |
| status | 状态 | String | 1成功 0失败 | O |
| collection\_list | 归集关系组 | json |  | O |
| merch\_no | 商户号 | String |  |  |
| money | 金额 | String |  |  |

## 返回示例

```
{
    "data": {
        "collectionList": [
            {
                "merch_no": "833584358130035",
                "money": 0.01
            }
        ],
        "status": "1"
    },
    "return_code": 10000,
    "sign": "13C60F6A5F845CFDD34FDF133F3B7217"
}
```

文档更新时间: 2025-06-25 16:26   作者：admin