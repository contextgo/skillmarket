#### 概要描述:

提交退款申请后，通过调用该接口查询退款状态。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/pay/digitalwallet/refundquery>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String | 海科平台商户编号 |  | M |
| out\_refund\_no | 服务商交易订单号 | String | refund\_no、out\_refund\_no必传其中一个，都传则以refund\_no为准，推荐使用refund\_no |  | O |
| refund\_no | 海科支付订单号 | String | refund\_no、out\_refund\_no必传其中一个，都传则以refund\_no为准，推荐使用refund\_no |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "merch_no": "83388888888",
    "refund_no": "123456789",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 响应码 | String | 10000代表成功 |  | M |
| return\_msg | 响应信息 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科平台商户编号 |  | M |
| out\_refund\_no | 服务商退款订单号 | String |  |  | M |
| refund\_no | 海科退款订单号 | String |  |  | M |
| trade\_status | 交易状态 | String | 1：交易成功 2：交易失败 3：交易进行中 4：交易超时 |  | M |
| trade\_end\_time | SaaS平台交易完成时间 | String | SaaS平台交易完成时间，交易完成以后会返回 | 2021-04-01 14:11:23 | M |
| refund\_amount | 退款金额 | String | 退款金额，以元为单位 | -100 | M |
| total\_amount | 订单金额 | String | 订单金额，以元为单位 | 100 | M |
| error\_code | 错误码 | String |  |  | O |
| error\_msg | 错误消息 | String |  |  | O |

#### 返回示例:

```
{
    "merch_no": "83388888888",
    "out_refund_no": "123456789",
    "refund_no": "AL88888888",
    "trade_status": "1",
    "trade_end_time": "2021-04-01 14:11:23",
    "refund_amount": "-100",
    "total_amount": "100",
    "return_code": "10000",
    "return_msg": "成功",
    "sign": "1032A57E96E4048B27EC2A5C3CE5E663"
}
```

文档更新时间: 2024-11-29 10:11   作者：陈文