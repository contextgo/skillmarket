#### 概要描述:

服务商可调用本接口查询商户当前额度。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/trade/limit/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 商户编号 | String | 海科平台商户号 |  | M |
| agent\_no | 服务商编号 | String |  |  | M |

#### 请求示例:

```
{
    "agent_no": "FW2002042",
    "merch_no": "833102259700486"   
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| cardCreditSingleAmount | 贷记卡单笔额度 | String | 当return\_code=10000时有值； 单位：元 |  | O |
| cardCreditDayAmount | 贷记卡单日限额 | String | 当return\_code=10000时有值； 单位：元 |  | O |
| cardDebitSingleAmount | 借记卡单笔额度 | String | 当return\_code=10000时有值； 单位：元 |  | O |
| cardDebitDayAmount | 借记卡单日额度 | String | 当return\_code=10000时有值； 单位：元 |  | O |
| cardDayAmount | 卡交易单日额度 | String | 当return\_code=10000时有值； 单位：元 |  | O |
| cardMonthAmount | 卡交易单月额度 | String | 当return\_code=10000时有值； 单位：元 |  | O |
| scanSingleAmount | 扫码交易单笔额度 | String | 当return\_code=10000时有值； 单位：元 |  | O |
| scanDayAmount | 扫码交易单日额度 | String | 当return\_code=10000时有值； 单位：元 |  | O |
| scanMonthAmount | 扫码交易单月额度 | String | 当return\_code=10000时有值； 单位：元 |  | O |

#### 返回示例:

```
{
 "cardCreditDayAmount": "10.00",
    "cardCreditSingleAmount": "11.00",
    "cardDayAmount": "13.00",
    "cardDebitDayAmount": "122.00",
    "cardDebitSingleAmount": "130.00",
    "cardMonthAmount": "144.00",
    "scanDayAmount": "14.44",
    "scanMonthAmount": "16.00",
    "scanSingleAmount": "11.00",
    "return_code": 10000,
    "sign": "7A9689578BFE64E5B081B26B88110684"
}
```

文档更新时间: 2025-06-26 11:32   作者：admin