#### 简要描述：

* 第三方应用在进行银行卡消费时，与SaaS平台通信前需要先签到,获取会话秘钥包含PINKey和MACKey。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/terminal/auth/signin>

#### 请求参数(O-非必传 ,M-必传):

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| pn | 终端编号 | String |  |  | M |

#### 请求示例:

```
{
    "accessid": "4028803d6a97099f016a9b3d8f57000f",
    "pn": "1002019070100089",
    "sign": "EEDF74B8E1698F169DFF38E7F967A64B"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| workingKey | 会话密钥 | String | 含PINKey、MACKey共40字节，Hex编码。其中前20字节是PINKEY，后20字节是MACKEY。 20字节的前16字节是用终端主秘钥加密的密钥，后4字节是CV值（CV值是通过对应密钥加密8字节0x00，并取加密结果的前4个字节得到）。 |  | M |
| sysTime | 系统时间 | String | yyyy-MM-dd HH:mm:ss |  | M |

#### 返回示例:

```
{
    "workingKey": "16B2BD286E479FE82B83E75E642461D1358B82C157B89EF64F7DCCAFBE2C6D4CF3EAA0D1B946A54D",
    "sysTime":"2020-05-18 14:34:12",
    "return_code": 10000,
    "sign": "23AFFA66E98BD77879206FDD3AAE6945"
}
```

文档更新时间: 2024-11-29 10:15   作者：admin