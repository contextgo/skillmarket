#### 概要描述:

以下情况需要调用关单接口：商户订单支付失败需要生成新单号重新发起支付，要对原订单号调用关单，避免重复支付；系统下单后，用户支付超时，系统退出不再受理，避免用户继续，请调用关单接口。(仅支持微信支付宝)

#### 请求URL:

* 测试环境：<http://39.106.187.68:8080/api/v2/pay/close-order>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String(32) | 海科商户编号 |  | M |
| out\_trade\_no | 服务商支付订单号 | String(32) | trade\_no、out\_trade\_no二选一上送,优选顺序：trade\_no、out\_trade\_no |  | C |
| trade\_no | 海科支付订单号 | String(32) | trade\_no、out\_trade\_no二选一上送,优选顺序：trade\_no、out\_trade\_no |  | C |

#### 请求示例:

```
{
    "agent_no": "IS88888888",
    "req_id": "147258369",
    "merch_no": "83388888888",
    "out_trade_no": "123456789",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表关单成功 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科商户编号 |  | M |
| out\_trade\_no | 服务商支付订单号 | String |  |  | M |
| trade\_no | 海科支付订单号 | String |  |  | M |

#### 返回示例:

```
{
    "agent_no": "IS88888888",
    "merch_no": "83388888888",
    "out_trade_no": "123456789",
    "trade_no": "AL88888888",
    "return_code": "SUCCESS",
    "return_msg": "成功",
    "result_code": "10000",
    "result_msg": "成功",
    "sign": "1032A57E96E4048B27EC2A5C3CE5E663"
}
```

文档更新时间: 2025-11-05 14:44   作者：陈文