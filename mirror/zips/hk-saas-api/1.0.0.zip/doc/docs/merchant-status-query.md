#### 概要描述:

* 根据服务商申请单号或商户编号查询信息（包含商户基本信息、支付产品、结算产品等）；
* 与商户入网申请-聚合版V2接口配套使用；
* 提交失败状态下，系统未创建商户编号，通过服务商申请单号查询时仅返回提交失败状态，不返回商户编号；

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/sub/query-merchant-info>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| agent\_apply\_no | 服务商申请单号 | String | agent\_apply\_no、merch\_no至少送一个 |  | O |
| merch\_no | 海科商户编号 | String | agent\_apply\_no、merch\_no至少送一个 |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "agent_apply_no":"aaaabbbbcccc",
    "merch_no": "833226358120003",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 商户编号 | String |  |  | O |
| merch\_name | 商户名称 | String |  |  | O |
| merch\_short\_name | 商户简称 | String |  |  | O |
| merch\_type | 商户类型 | String |  |  | O |
| merch\_status | 商户状态 | String | 0:启动  1:禁用  2:注销 |  | O |
| status | 商户入网状态 | String | 1:提交失败  2:已受理  3:自动审核  4:待审核   5:审核失败   6:审核拒绝  7:审核成功   8:运营审核退回 9:运营审核退回未处理完 |  | O |
| fail\_msg | 入网失败原因 | String | 入网状态为提交失败、审核失败时返回 |  | O |
| shop\_name | 门店名称 | String |  |  | O |
| wx\_biz\_info | 微信支付产品信息 | JSON | 参考（微信支付产品信息：**wx\_biz\_info**） |  | O |
| ali\_biz\_info | 支付宝支付产品信息 | JSON | 参考（支付宝支付产品信息：**ali\_biz\_info**） |  | O |
| bank\_biz\_info | 银行卡支付产品信息 | JSON | 参考（银行卡支付产品信息：**bank\_biz\_info**） |  | O |
| pay\_product\_info | 商户结算产品信息 | JSON | 参考（商户结算产品信息：**pay\_product\_info**） |  | O |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |

#### 微信支付产品信息 wx\_biz\_info:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| report\_status | 报备状态 | String | 0:待报备  1: 报备中 2:报备失败  3:报备成功 |  | M |
| fail\_msg | 失败原因 | String |  |  | O |
| channel\_no | 微信渠道号 | String |  |  | O |
| wxsub\_merch\_no | 微信子商户号 | String |  | 例：87739 | O |
| wx\_rate | 微信交易费率 | String | 单位：万分之一 |  | O |

#### 支付宝支付产品信息 ali\_biz\_info:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| report\_status | 报备状态 | String | 0:待报备  1: 报备中 2:报备失败  3:报备成功 |  | M |
| fail\_msg | 失败原因 | String |  |  | O |
| channel\_no | 支付宝渠道号 | String |  |  | O |
| alisub\_merch\_no | 支付宝子商户号 | String |  | 例：2888009381 | O |
| ali\_rate | 支付宝交易费率 | String | 单位：万分之一 |  | O |

#### 银行卡支付产品信息 bank\_biz\_info:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| report\_status | 报备状态 | String | 0:待报备  1: 报备中 2:报备失败  3:报备成功 |  | M |
| fail\_msg | 失败原因 | String |  |  | O |
| channel\_no | 银联渠道号 | String |  |  | O |
| banksub\_merch\_no | 银联子商户号 | String |  | 例：100294949M2 | O |
| bank\_debit\_rate | 银行卡借记卡交易费率 | String | 单位：万分之一 |  | O |
| bank\_credit\_rate | 银行卡贷记卡交易费率 | String | 单位：万分之一 |  | O |
| bank\_debit\_max | 银行卡借记卡手续费封顶 | String | 单位：元 |  | O |
| union\_debit\_rate | 银联二维码借记卡1000以下（包含）交易费率 | String | 单位：万分之一 |  | O |
| union\_credit\_rate | 银联二维码贷记卡1000以下（包含）交易费率 | String | 单位：万分之一 |  | O |
| union\_debit\_max | 银联二维码借记卡1000以下（包含）手续费封顶 | String | 单位：元 |  | O |
| union\_debit\_rate\_1000 | 银联二维码借记卡单笔大于1000交易费率 | String | 单位：万分之一 |  | O |
| union\_credit\_rate\_1000 | 银联二维码贷记卡单笔大于1000交易费率 | String | 单位：万分之一 |  | O |
| union\_debit\_max\_1000 | 银联二维码借记卡单笔大于1000手续费封顶 | String | 单位：元 |  | O |

#### 结算产品信息 pay\_product\_info:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| settlement\_cycle | 结算周期 | String |  |  | M |
| withdrawal\_rate | 结算费率 | String | 单位：万分之一 |  | M |
| withdrawal\_fee\_min | 单笔最小结算手续费 | String | 单位：元 |  | M |
| public\_withdrawal\_rate | 对公费率 | String | 单位为：%，比如费率为 0.6%, 有对公费率时返回 |  | C |
| public\_withdrawal\_feemin | 对公单笔最低手续费 | String | 单位为：元，比如费率为 1, 哟对公费率时返回 |  | C |

#### 返回示例:

```
{
    "merch_no": "88888888",
    "merch_name": "深圳康寓测试99",
    "merch_short_name": "asdas",
    "merch_type": "10A",
        "merch status": "0",
    "status": "4",
    "shop_name": "深圳康寓测试",
    "wx_biz_info": {
        "report_status": "3",
        "channel_no": "222970902",
        "wxsub_merch_no": "383149681",
        "wx_rate": 60
    },
    "ali_biz_info": {
        "report_status": "3",
        "channel_no": "2088631598508348",
        "alisub_merch_no": "2088800170468950",
        "ali_rate": 60
    },
    "bank_biz_info": {
        "report_status": "3",
        "bank_debit_rate": 60,
        "bank_credit_rate": 60,
        "bank_debit_max": 18,
        "union_debit_rate": 60,
        "union_credit_rate": 60,
        "union_debit_max": 1000,
        "union_debit_rate_1000": 60,
        "union_credit_rate_1000": 60,
        "union_debit_max_1000": 18,
        "banksub_merch_no": "83311005462H003"
    },
    "pay_product_info": {
        "settlement_cycle": "T1",
        "withdrawal_rate": 0,
        "withdrawal_fee_min": "0"
    },
    "return_code": 10000,
    "sign": "1032A57E96E4048B27EC2A5C3CE5E663"
}
```

文档更新时间: 2025-08-21 10:12   作者：王金晶