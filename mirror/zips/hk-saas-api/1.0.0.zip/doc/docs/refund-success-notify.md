### 退款成功异步通知API

**通知地址**  
通知的地址为发起退款交易的时候上送的notify\_url。

**通知策略**  
退款完成后，SaaS会把相关支付结果发送给商户，商户需要接收处理，并返回应答。对后台通知交互时，如果SaaS收到商户的应答不是成功或超时，SaaS认为通知失败，SaaS会通过一定的策略定期重新发起通知。尽可能提高通知的成功率，但不保证通知最终能成功。(通知频率为15/15/30/180/1800/1800/1800/1800/3600，单位：秒)

如果异步通知的状态与查询接口的返回存在不一致，以查询接口的返回为准。

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String(32) | 海科商户编号 |  | M |
| out\_refund\_no | 服务商退款订单号 | String |  |  | M |
| trade\_no | 海科交易订单号 | String |  |  | M |
| refund\_no | 海科退款订单号 | String |  |  | M |
| pay\_type | 支付类型 | String | WX：微信支付 ALI：支付宝支付 UNIONQR：云闪付 |  | M |
| refund\_amount | 退款金额 | String | 退款金额（单位：元） |  | M |
| discount\_amount | 免充值优惠券金额 | String | 不走结算资金的免充值型优惠券金额（单位：元,支持2位小数） |  | O |
| trade\_status | 交易状态 | String | 1：交易成功 |  | M |
| clear\_status | 清算状态 | String | 1：已清算  2：未清算 | 默认是2 | M |
| pn | SAAS终端号 | String(32) | SAAS终端号 |  | M |
| settle\_way | 交易结算方式 | String | 交易结算方式 |  | M |
| card\_type | 卡类型 | String(10) | 01：借记卡 02：贷记卡 |  | O |
| remark | 备注 | String(100) | 交易备注，原退款请求时上送的备注信息 |  | O |
| activity\_id | 官方活动id | String(100) | 国补：UN\_SUBSIDY |  | O |
| attach | 通道原生参数 | String |  |  | O |

#### 请求示例:

```
{
    "out_refund_no": "440000199711151124",
    "refund_no": "WX240410170222000818227131",
    "sign": "96853DF7B2285AC4CD6A09EC61C2158D",
    "agent_no": "FW3002100",
    "trade_status": "1",
    "refund_amount":"0.01",
    "pay_type": "WX",
    "pn": "A00000001",
    "settle_way": "D1",
    "attach": "{
        \"nonce_str\": \"c720449a331a43d192747e04bc15e35e\",
        \"out_refund_no\": \"WX240410170222000818227131\",
        \"settlement_refund_fee\": \"1\",
        \"cert_id\": \"4233741533\",
        \"return_msg\": \"成功\",
        \"fee_type\": \"CNY\",
        \"mch_id\": \"1505378701\",
        \"sub_mch_id\": \"626185853\",
        \"refund_id\": \"50103409282024041029404142563\",
        \"coupon_refund_fee\": \"0\",
        \"refund_create_time\": \"2024-04-10 17:02:22\",
        \"appid\": \"wx17728c1a8fa300d6\",
        \"refund_fee\": \"1\",
        \"result_code\": \"SUCCESS\",
        \"cash_refund_fee\": \"1\",
        \"sign_type\": \"SM2\",
        \"return_code\": \"SUCCESS\"
    }"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回状态码 | String(16) | SUCCESS/FAIL SUCCESS表示商户接收通知成功并校验成功 |  | M |
| return\_msg | 返回信息 | String(128) | 当return\_code为FAIL时返回信息为错误原因 |  | O |

#### 返回示例:

```
{
    "return_code": "SUCCESS"
}
```

文档更新时间: 2025-12-18 14:12   作者：陈文