#### 概要描述:

查询商家认证申请单状态，以及失败原因

* 注：使用海科pid的服务商必须调用该接口；使用自己主体pid的服务商，可以调用该接口或直接调用支付宝官方认证接口均可完成支付宝二次认证。  
  支付宝官方接口链接如下：<https://opendocs.alipay.com/open/03sqz8>

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/ali-auth/query-status>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| apply\_no | 申请单编号 | String | apply\_no和business\_code二选一上送 |  | O |
| business\_code | 服务商申请单号 | String | apply\_no和business\_code二选一上送 |  | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "business_code": "356771679469",
    "sign": "36EE79FD2E36527F5A75D58E40C9FEC4"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| apply\_status | 申请单状态 | String | 商家认证申请单状态，枚举值：审核中(AUDITING)、待联系人确认（CONTACT\_CONFIRM），待法人确认（LEGAL\_CONFIRM）、审核通过(AUDIT\_PASS)、审核失败(AUDIT\_REJECT)、已冻结(AUDIT\_FREEZE)、已撤回(CANCELED) |  | O |
| qr\_code | 二维码链接 | String | 商家认证小程序二维码图片链接，申请单状态处于审核通过、待联系人确认、待法人确认、已冻结时返回，商户使用支付宝APP扫码后完成后续确认动作。此字段是平台生成并返回的二维码码值，通过浏览器访问即可获得一个二维码的图片。服务商在推广过程中，可引导商家使用支付宝APP扫描此二维码，进入认证申请单页面，完成认证申请的后续确认操作。 |  | O |
| fail\_param | 审核失败字段 | String | 审核失败返回 |  | O |
| fail\_reason | 描述申请单审核失败原因 | String | 审核失败原因:主体类型匹配失败，请更换证件重试 法人/经办人未查询到对应身份信息，请检查上传的信息后重新上传 证件信息核验不通过，请检查上传的信息后重新上传 |  | O |

#### 返回示例:

```
{
    "return_msg": "成功",
    "return_code": 10000,
    "apply_status":"AUDIT_REJECT",
    "fail_param":"card_front_img",
    "fail_reason":"审核失败原因:主体类型匹配失败，请更换证件重试 法人/经办人未查询到对应身份信息，请检查上传的信息后重新上传 证件信息核验不通过，请检查上传的信息后重新上传",
    "sign": "74D55ACA6A2698290542DF709BB966B2"
}
```

文档更新时间: 2024-11-29 10:08   作者：admin