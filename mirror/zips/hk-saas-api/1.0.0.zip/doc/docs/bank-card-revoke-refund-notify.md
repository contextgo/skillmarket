**通知地址**通知的地址为发起退款交易的时候上送的notify\_url。

**通知策略**退款完成后，SaaS会把相关支付结果发送给商户，商户需要接收处理，并返回应答。对后台通知交互时，如果SaaS收到商户的应答不是成功或超时，SaaS认为通知失败，SaaS会通过一定的策略定期重新发起通知。尽可能提高通知的成功率，但不保证通知最终能成功。(通知频率为15/15/30/180/1800/1800/1800/1800/3600，单位：秒)

如果异步通知的状态与查询接口的返回存在不一致，以查询接口的返回为准。

### **请求参数(O-非必传 ,M-必传):**

* 请求参数为SaaS通知给第三方的内容

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| sign | 参数签名值 | String |  |  | M |
| tradeId | 交易id | String | SaaS平台的订单编号 |  | M |
| merchNo | 商户编号 | String |  |  | M |
| pn | 终端编号 | String |  |  | M |
| sn | 终端sn号 | String |  |  | O |
| bankName | 发卡行 | String |  |  | M |
| acquiringBank | 收单行 | String |  |  | M |
| cardNo | 卡号 | String |  |  | M |
| expDate | 卡有效期 | String |  |  | O |
| batchNo | 批次号 | String |  |  | O |
| f11 | 凭证号 | String |  |  | O |
| f61 | 授权码 | String | 消费撤销或者退货时候上送的 |  | O |
| f38 | SAAS平台参考号 | String | 消费撤销或者退货时候上送的 |  | O |
| f22 | 原请求刷卡方式 | String |  |  | O |
| tradeBeginTime | 交易开始时间 | String |  |  | M |
| tradeEndTime | 交易完成时间 | String |  |  | M |
| amount | 交易金额 | String | 以元为单位 |  | M |
| settleAmount | 交易结算金额(单位：元) | String |  |  | M |
| bankIssno | 发卡行代码 | String |  |  | M |
| unionPayCode | 银联商户号 | String |  |  | M |
| unionRefNo | 银联参考号 | String | POS消费时返回，可用该参考号在银联端查询该订单 |  | O |
| unionTerminalSn | 银联终端号 | String |  |  | M |
| terminalTxNo | 终端流水号 | String |  |  | M |
| outTradeNo | 外部流水号 | String |  |  | O |
| tradeResult | 交易结果 | Integer | 1：成功 |  | M |
| fee | 手续费 | String | 以元为单位 |  | O |
| cardType | 卡类型 | String | 01-借记卡；02-贷记卡；03-准贷记卡；04-预付费卡 |  | M |
| payMode | 支付方式 | String | (v1.0.3修改)CONSUME-消费；REVOKE-撤销；REFUND-退货 |  | O |
| originTradeId | 原交易标识 | String |  |  | M |
| originOutTradeNo | 原交易外部流水号 | String |  |  | O |
| originTotalAmount | 原交易订单金额 | String | 以元为单位 |  | O |
| originRefundAmount | 原交易已退款金额合计 | String | 以元为单位 |  | O |
| tradeType | 支付类型 | String | BANK(V1.16增加) |  | M |
| cardOrg | 卡组织(v1.44增加) | String | 银联：UNION，运通：EXPRESS |  | M |
| currency | 币种(v1.44增加) | String | 人民币卡：CNY，外卡：OUT |  | M |

### **请求示例:**

```
参见微信支付宝异步通知格式，请求内容为本页请求参数！
```

### **返回参数说明:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result | 接收结果 | String | 接收成功后返回“SUCCESS” | SUCCESS | M |

### **返回示例:**

文档更新时间: 2024-12-19 10:50   作者：梁博