#### 简要描述：

* 本接口调用成功只表示当前业务申请成功，对于业务最终是否开通成功需要通过“商户业务查询”接口查询来确定。
* 海科已配合微信完成微信账单升级，原微信经营类目ID已变更为结算规则ID。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/merchant-wx-biz/apply>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 商户编号 | String |  |  | M |
| agent\_apply\_no | 服务商申请单号 | String |  |  | O |
| rate | 交易费率 | String | 单位为：万分之一，比如费率为 0.6%, 需要传 60 | 38 | M |
| channel\_no | 微信渠道号 | String | 服务商通过海科申请的微信渠道号 |  | M |
| settle\_id | 结算规则id | String | 非必填参数 取值详见附录：[微信经营类目](http://39.106.84.215:8181/docs/saas/saas-1b72gi9ekje46) |  | O |
| notify\_url | 通知地址 | String | 商户业务审核状态变更后的通知地址 | <http://x.cn/shop/notice> | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "merch_no": "833581758120002",
    "agent_apply_no": "245870687720",
    "notify_url": "https://www.baidu.com",
    "rate": "58",
    "channel_no": "24006513",
    "settle_id": "770",
    "sign": "814B66FDABA3E0896DCE54FE7E8008C4"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| apply\_no | 申请单编号 | String |  |  | M |

#### 返回示例:

```
{
    "apply_no": "200323174241616939321401",
    "return_code": 10000,
    "sign": "8151B2D44AD97CCED6D415D901E9E754"
}
```

文档更新时间: 2025-07-04 14:50   作者：王金晶