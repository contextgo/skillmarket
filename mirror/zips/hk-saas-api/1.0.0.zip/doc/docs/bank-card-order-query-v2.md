# 订单查询

**测试环境**：<http://39.106.187.68:8080/api/v2/bank-pay/query>

#### 请求参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String(32) | 海科商户编号 |  | M |
| out\_trade\_no | 服务商支付订单号 | String(32) | trade\_no、out\_trade\_no二选一上送,优选顺序：trade\_no、out\_trade\_no |  | C |
| trade\_no | 海科支付订单号 | String(32) | trade\_no、out\_trade\_no二选一上送,优选顺序：trade\_no、out\_trade\_no |  | C |

#### 请求示例:

```
{
    "agent_no": "IS88888888",
    "req_id": "147258369",
    "merch_no": "83388888888",
    "out_trade_no": "123456789",
    "sign": "5F154E14FDC459ED5DF628B56F61A609"
}
```

#### 返回参数(O-非必传 ,M-必传,C-选传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| result\_code | 响应码 | String | 10000代表业务处理成功，交易结果需要根据trade\_status判断 |  | M |
| result\_msg | 响应信息 | String |  |  | M |
| error\_code | 错误码 | String | trade\_status=2时返回 |  | O |
| error\_msg | 错误信息 | String | trade\_status=2时返回 |  | O |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 海科商户编号 | String | 海科商户编号 |  | M |
| pn | 海科终端号 | String | 海科终端号 |  | M |
| bank\_merch\_no | 银联商户编号 | String | 银联商户编号 |  | M |
| union\_sn | 银联终端号 | String | 银联终端号 |  | M |
| total\_amount | 交易金额 | String | 上送银联的交易金额（单位：元,支持2位小数） |  | M |
| order\_amount | 订单金额 | String | 订单总金额（单位：元,支持2位小数） |  | M |
| discount\_amount | 免充值优惠券金额 | String | 不走结算资金的免充值型优惠券金额（单位：元,支持2位小数） |  | O |
| pay\_type | 支付类型 | String | BANK：银行卡 |  | M |
| pay\_mode | 支付方式 | String | 消费：CONSUME 消费撤销：REVOKE 退款（退货）：REFUND 预授权：PREAUTH 预授权撤销：PREAUTHUNDO 预授权完成：PREAUTHFINISH 预授权完成撤销：PREAUTHFINISHUNDO |  | M |
| out\_trade\_no | 服务商支付订单号 | String |  |  | M |
| trade\_no | 海科支付订单号 | String |  |  | M |
| terminal\_serial\_num | 终端流水号;凭证号 | String |  |  | M |
| trade\_status | 交易状态 | String | 1：交易成功 2：交易失败 3：交易进行中 |  | M |
| clear\_status | 清算状态 | String | 1：已清算 2：未清算 |  | M |
| real\_fee\_amount | 实收手续费金额 | String | 实收手续费金额（单位：元,支持2位小数） clear\_status=1时返回 |  | C |
| fee\_subsidy\_amount | 手续费补贴金额 | String | 手续费补贴金额（单位：元,支持2位小数） 有手续费补贴且clear\_status=1时返回 |  | C |
| settle\_amount | 交易结算金额 | String | 交易结算金额（单位：元,支持2位小数） clear\_status=1时返回 |  | C |
| trade\_rate | 交易费率 | String | 交易费率，单位：% clear\_status=1时返回 | 0.38 | C |
| settle\_way | 交易结算方式 | String | 交易结算方式 clear\_status=1时返回 |  | C |
| refer\_trade\_no | 关联订单号 | String | 关联订单号 |  | O |
| bank\_trade\_no | 银联订单号 | String | 银联订单号 |  | O |
| voucher\_no | 授权码 | String |  |  | O |
| trade\_end\_time | 交易完成时间 | String | 交易在海科的完成时间 | 2024-01-01 10:10:10 | O |
| card\_type | 卡类型 | String | 01：借记卡 02：贷记卡 03：准贷记卡 04：预付费 |  | O |
| remark | 备注 | String | 交易备注，原交易请求时上送的备注信息 |  | O |
| card\_org | 卡组织 | String |  |  | O |
| currency | 币种 | String | 人民币卡：CNY，外卡：OUT |  | O |
| issuer\_no | 发卡行代码 | String | 发卡行代码 |  | M |
| fee\_subsidy\_amt | 手续费补贴金额 | String | 手续费补贴金额（单位：元,支持2位小数）有手续费补贴且clear\_status=1时返回 |  | C |
| hk\_activity\_id | 海科活动id | String(100) | 海科活动id |  | O |

#### 返回示例:

```
{
    "merch_no": "833177158120005",
    "error_msg": null,
    "bank_trade_no": "144107400001",
    "discount_amount": "0",
    "voucher_no": "817513",
    "sign": "CDE14B99A7158267E45B0FEFE35F992F",
    "agent_no": "FW3002100",
    "return_msg": "成功",
    "refer_trade_no": null,
    "result_msg": "请求成功",
    "trade_rate": "50",
    "out_trade_no": "230000202208266018",
    "total_amount": "0.01",
    "settle_amount": "0",
    "order_amount": "0.01",
    "trade_status": "1",
    "trade_no": "BA2407111441520000666700093",
    "error_code": null,
    "result_code": "10000",
    "trade_end_time": "2024-07-11 14:41:53",
    "clear_status": "1",
    "real_fee_amount": "0.01",
    "return_code": "SUCCESS"
}
```

文档更新时间: 2026-04-23 09:38   作者：admin