## 微信-投诉列表

### 基本信息

**Path：** /api/v1/complaint/wechat/queryListPage

**Method：** POST

**接口描述：**

### 备注

#### 业务端查询’开始’,’结束’时间跨度不要超过一个月

### 请求参数

**Headers**

| 参数名称 | 参数值 | 是否必须 |
| --- | --- | --- |
| Content-Type | application/json | 是 |

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| transFirstLevelAgentNum | string | 必须 |  | 交易一级代理商编号 |  |
| transMercNum | string | 非必须 |  | 交易商户号 |  |
| complaintId | string | 非必须 |  | 投诉单号 |  |
| complaintedMchid | string | 非必须 |  | 被诉商户号 |  |
| transactionId | string | 非必须 |  | 微信订单号 |  |
| outTradeNo | string | 非必须 |  | 商户订单号 |  |
| complaintState | string | 非必须 |  | 投诉单状态 PENDING-待处理 PROCESSING-处理中 PROCESSED-已处理完成 |  |
| orderId | string | 非必须 |  | 微信支付服务订单号 |  |
| outOrderNo | string | 非必须 |  | 商户服务订单号 |  |
| beginComplaintTime | string | 非必须 |  | 开始投诉时间 |  |
| endComplaintTime | string | 非必须 |  | 结束投诉时间 |  |
| current | number | 非必须 |  | 页数 |  |
| size | number | 非必须 |  | 条数 |  |

### 请求示例

```
{
  "accessid": "4028803d6a97099f016a9b3d8f57000f",
  "signKey": "fa907d6e05cc4869a3330add779e9ff7",
  "transFirstLevelAgentNum": "ISV123123"
}
```

### 返回数据

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| return\_code | string | 必须 |  | 返回码 |  |
| return\_msg | string | 必须 |  | 返回信息 |  |
| list | object | 非必须 |  | title 数据 | 备注:  title 数据 |
| transFirstLevelAgentNum | string | 非必须 |  | 交易一级服务商编号 |  |
| transFirstLevelAgentName | string | 非必须 |  | 交易一级服务商名称 |  |
| transAgentNum | string | 非必须 |  | 交易服务商编号 |  |
| transAgentName | string | 非必须 |  | 交易服务商名称 |  |
| transMercNum | string | 非必须 |  | 交易商户编号 |  |
| transMercName | string | 非必须 |  | 交易商户名称 |  |
| bussOrderNo | string | 非必须 |  | 业务交易订单号 |  |
| complaintId | string | 非必须 |  | 投诉单号 |  |
| complaintTime | string | 非必须 |  | 投诉时间 |  |
| complaintDetail | string | 非必须 |  | 投诉详情 |  |
| complaintState | string | 非必须 |  | 投诉单状态 PENDING-待处理 PROCESSING-处理中 PROCESSED-已处理完成 |  |
| complaintedMchid | string | 非必须 |  | 被诉商户号 |  |
| payerPhone | string | 非必须 |  | 投诉人联系方式 |  |
| transactionId | string | 非必须 |  | 微信订单号 |  |
| outTradeNo | string | 非必须 |  | 商户订单号 |  |
| amount | string | 非必须 |  | 订单金额，单位（分） |  |
| complaintFullRefunded | string | 非必须 |  | 投诉单是否已全额退款 |  |
| incomingUserResponse | string | 非必须 |  | 是否有待回复的用户留言 |  |
| userComplaintTimes | string | 非必须 |  | 用户投诉次数 |  |
| mediaType | string | 非必须 |  | 媒体文件业务类型 USER\_COMPLAINT\_IMAGE: 用户提交投诉时上传的图片凭证 OPERATION\_IMAGE: 用户、商户、微信支付客服在协商解决投诉时，上传的图片凭证 |  |
| mediaUrl | string | 非必须 |  | 媒体文件请求url |  |
| problemDescription | string | 非必须 |  | 问题描述 |  |
| problemType | string | 非必须 |  | 问题类型 REFUND: 申请退款 SERVICE\_NOT\_WORK: 服务权益未生效 OTHERS: 其他类型 |  |
| applyRefundAmount | string | 非必须 |  | 申请退款金额(单位:分) |  |
| userTagList | string | 非必须 |  | 用户标签列表 TRUSTED: 此类用户满足极速退款条件 HIGH\_RISK: 高风险投诉，请按照运营要求优先妥善处理 |  |
| orderId | string | 非必须 |  | 微信支付服务订单号 |  |
| outOrderNo | string | 非必须 |  | 商户服务订单号 |  |
| state | string | 非必须 |  | 支付分服务单状态 DOING: 服务订单进行中 REVOKED: 服务订单已取消 WAITPAY: 服务订单待支付 DONE: 服务订单已完成 |  |
| type | string | 非必须 |  | 补充信息类型 SHARE\_POWER\_TYPE: 充电宝投诉相关行业 |  |
| returnTime | string | 非必须 |  | 归还时间 |  |
| returnAddress | string | 非必须 |  | 归还地点 |  |
| longitude | string | 非必须 |  | 归还地点经度 |  |
| latitude | string | 非必须 |  | 归还地点纬度 |  |
| isReturnedToSameMachine | string | 非必须 |  | 是否归还同一柜机 |  |
| inPlatformService | string | 非必须 |  | 是否在平台协助中 |  |
| needImmediateService | string | 非必须 |  | 是否需即时服务用户 |  |
| payerOpenid | string | 非必须 |  | 投诉人OpenID |  |
| totalNumber | number | 必须 |  | 总条数 |  |

### 返回示例

```
{
    "totalNumber": 1493,
    "rspCode": "00",
    "rspMsg": "成功",
    "list": [
        {
            "complaintId": "2000012312312312388621",
            "complaintTime": "2024-10-25 15:53:03",
            "complaintDetail": "中午吃了砂锅牛肉面，上了一份砂锅面，没有牛肉，当时觉得纳闷没多想，吃完出门看到门口的图片才进去问老板。老板说因为报的是砂锅面，没有说是砂锅牛肉面。但我付的是砂锅牛肉面的钱，没有牛肉。老板也没退我点钱。",
            "complaintState": "PENDING",
            "complaintedMchid": "681231234",
            "payerPhone": "h22r1231231234A==",
            "transactionId": "420001231231231230217",
            "outTradeNo": "7891231231231231146",
            "amount": "1200",
            "complaintFullRefunded": "false",
            "incomingUserResponse": "true",
            "userComplaintTimes": "1",
            "mediaType": "USER_COMPLAINT_IMAGE",
            "mediaUrl": "https://api.mch.weixin.qq.com/v3/merchant-service/images/ChsyMDAwMDAwMjA123123ODg2MjEYAC123123igBMAE4AQ%3D%3D",
            "problemDescription": "不满意商家的商品或服务",
            "problemType": "OTHERS",
            "applyRefundAmount": null,
            "userTagList": null,
            "orderId": null,
            "outOrderNo": null,
            "state": null,
            "type": null,
            "returnTime": null,
            "returnAddress": null,
            "longitude": null,
            "latitude": null,
            "isReturnedToSameMachine": null,
            "inPlatformService": "false",
            "needImmediateService": "false",
            "payerOpenid": null,
            "transFirstLevelAgentNum": "FW1000161",
            "transMercNum": "833177648122603",
            "transAgentNum": "ISV003668"
        }
    ]
}
```

文档更新时间: 2025-05-28 18:26   作者：胡闽川