#### 简要描述：

1、风控案例推送数据

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/agent/risk/case/list>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| caseNo | 案例编号 | String |  | 20230511155524394956750290100 | O |
| agentNo | 服务商编号 | String | 服务商的编号，由SaaS平台分配，表示当前商户属于该服务商名下 | ISV01991023 | O |
| mercNum | 商户编号 | String | 商户编号 | 88888888 | O |
| max\_amount | 开始时间 | String |  |  | O |
| createTimeEnd | 结束时间 | String |  |  | O |
| page | 页数 | int | 第几页 | 1 | M |
| rows | 每页数量 | int | 每页20条数据 | 20 | M |

#### 请求示例:

```
{
   "caseNo": "20230511155524394956750290100",
   "mercNum": "833588696325",
   "page": 1,
   "rows": 10,
   "accessid": "4028805b6e86d179016e874f6c4200ad",
   "sign": "975077BFC098C592C721A3948A97460F"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| data | 返回数据 | JSON | 当return\_code=10000时有值 |  | O |

#### data参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| total | 全部 | String | 5 |  | M |
| rows | 案例列表 | JSONArray |  |  | O |

#### rows参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| legalPhone | 法人手机号 | String |  | 5 | O |
| mercCreateTime | 入网时间 | String |  | 2019-12-13 11:35:15 | O |
| cardNo | 卡号 | String |  |  | O |
| surveyRemark | 风险调查回复 | String |  |  | O |
| riskTypeRules | 风险类别规则 | String |  |  | O |
| longitude | 经度 | String |  |  | O |
| mercName | 商户名称 | String |  | 山西兴宇装饰工程服务有限公司 | O |
| mercNum | 商户编号 | String |  | 8331634891201 | O |
| riskTypeCaseDealWay | 风险类别案例处理方式 | String | investigate | 案例处理方式 ：investigate 风险调查, warn 预警 | O |
| areaCode | 商户所属地区 | String |  | 110101 | O |
| referOrders | 涉及交易流水号 | String |  |  | O |
| cityCode | 市代码 | String |  | 110100 | O |
| latitude | 纬度 | String |  |  | O |
| remark | 备注 | String |  |  | O |
| agentNo | 服务商编号 | String |  | 隶属服务商编号 | O |
| typeNo | 类别编号 | String |  | T00038 | O |
| legalPerson | 法人姓名 | String |  |  | O |
| flowNodeKey | 流程节点 | String |  |  | O |
| surveyWay | 调查方式 | String |  |  | O |
| provCode | 商户所属省 | String |  | 10000 | O |
| suggest | 商户处理建议 | String |  | T00038 | O |
| caseNo | 案例编号 | String |  | 20230505153037394436862808100 | O |
| createTime | 创建时间 | String |  | 2023-05-05 15:30:37 | O |
| caseDealWay | 案例处理方式 | String |  |  | O |
| auditStatus | 审核状态 | String |  |  | O |
| createWay | 案例生成方式 | String |  |  | O |
| surveyResult | 调查结果说明 | String |  |  | O |
| termNo | 终端号 | String |  |  | O |
| firstAgentNo | 一级服务商编号 | String |  |  | O |
| agentName | 服务商名称 | String |  |  | O |
| surveyTime | 风险调查时间 | String |  |  | O |
| submitTime | 提交资料时间 | String |  |  | O |
| level | 服务商层级 | String |  |  | O |

#### 返回示例:

```
{
    "total": 5,
    "rows": [
        {
            "legalPhone": "15235252720", 法人手机号
            "mercCreateTime": "2019-12-13 11:35:15", 入网时间 
            "cardNo": "", 卡号
            "surveyRemark": "", 风险调查回复
            "riskTypeRules": "SR00045", 风险规则编号
            "longitude": "", 经度
            "mercName": "山西兴宇装饰工程服务有限公司", 商户名称
            "mercNum": "833163489120001", 商户编号
            "riskTypeCaseDealWay": "investigate", 商户编号 
            "areaCode": "110101", 商户所属地区
            "referOrders": "", 涉及交易流水号
            "cityCode": "110100", 市代码
            "latitude": "", 纬度
            "remark": "", 备注
            "agentNo": "FW1000161", 服务商编号
            "typeNo": "T00038", 类别编号
            "legalPerson": "索亦荣", 法人姓名
            "flowNodeKey": "SAASSH", SAASSH：SAAS审核 
            "surveyWay": "", 调查方式
            "provCode": "110000", 商户所属省
            "suggest": "", 商户处理建议
            "caseNo": "20230505153037394436862808100", 案例编号
            "createTime": "2023-05-05 15:30:37", 创建时间
            "caseDealWay": "investigate", 案例处理方式
            "auditStatus": "DSH", 审核状态
            "createWay": "", 案例生成方式
            "surveyResult": "", 调查结果说明
            "termNo": "CHT0092930", 终端号
            "firstAgentNo": "FW1000161", 一级服务商编号
            "firstAgentName": "张亚飞测试测试", 一级服务商名称
            "agentName": "张亚飞测试测试", 服务商名称
            "surveyTime": {}, 风险调查时间
            "submitTime": {}, 提交资料时间
            "level": "1级服务商编号：FW1000161" 服务商层级
        }
    ],
    "return_code": 10000
}
```

文档更新时间: 2025-04-30 10:13   作者：张亚飞