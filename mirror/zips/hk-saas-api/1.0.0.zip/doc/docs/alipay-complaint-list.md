## 支付宝-投诉列表

### 基本信息

**Path：** /api/v1/complaint/ali/queryListPager

**Method：** POST

**接口描述：**

### 请求参数

**Headers**

| 参数名称 | 参数值 | 是否必须 | 示例 | 备注 |
| --- | --- | --- | --- | --- |
| Content-Type | application/json | 是 |  |  |
| **Body** |  |  |  |  |

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| transFirstLevelAgentNum | string | 必须 |  | 交易一级服务商编号 |  |
| transMercNum | string | 非必须 |  | 交易商户编号 |  |
| complaintId | string | 非必须 |  | 投诉主表主键id |  |
| status | string | 非必须 |  | 投诉单状态码 |  |
| processCode | string | 非必须 |  | 商家处理结果码 |  |
| taskId | string | 非必须 |  | 投诉单号id |  |
| beginGmtComplain | string | 非必须 |  | 开始投诉时间 |  |
| endGmtComplain | string | 非必须 |  | 结束投诉时间 |  |
| beginGmtProcess | string | 非必须 |  | 开始处理时间 |  |
| endGmtProcess | string | 非必须 |  | 结束处理时间 |  |
| beginGmtRiskFinishTime | string | 非必须 |  | 开始推送时间 |  |
| endGmtRiskFinishTime | string | 非必须 |  | 结束推送时间 |  |
| current | string | 必须 |  | 页数 |  |
| size | string | 必须 |  | 条数 |  |

### 请求示例

```
{
  "accessid": "4028803d6a97099f016a9b3d8f57000f",
  "sign": "3B13E5343E42A6D1153A216EEFA5496F",
  "transFirstLevelAgentNum": "ISV002571"
}
```

### 返回数据

| 名称 | 类型 | 是否必须 | 默认值 | 备注 | 其他信息 |
| --- | --- | --- | --- | --- | --- |
| return\_code | string | 必须 |  | 返回码，返回1000代表成功，其他失败 |  |
| return\_msg | string | 必须 |  | 返回信息 |  |
| list | object [] | 非必须 |  | 投诉列表 | item 类型: object |
| ├─ complaintId | string | 非必须 |  | 投诉主表主键id |  |
| ├─ oppositePid | string | 非必须 |  | 被投诉人pid |  |
| ├─ oppositeName | string | 非必须 |  | 被投诉人名称 |  |
| ├─ complainAmount | string | 非必须 |  | 投诉单涉及交易总金额（单位：人民币元） |  |
| ├─ contact | string | 非必须 |  | 联系方式 |  |
| ├─ gmtComplain | string | 非必须 |  | 投诉时间 |  |
| ├─ gmtProcess | string | 非必须 |  | 处理时间 |  |
| ├─ gmtOverdue | string | 非必须 |  | 过期时间 |  |
| ├─ complainContent | string | 非必须 |  | 投诉内容 |  |
| ├─ complainTradeNo | string | 非必须 |  | 投诉单交易单号 |  |
| ├─ complainStatus | string | 非必须 |  | 投诉单状态码 用户撤诉: DROP\_COMPLAIN 超时后用户撤诉: DROP\_OVERDUE\_COMPLAIN 超时处理完成用户撤诉: DROP\_OVERDUE\_PROCESSED 处理完成用户撤诉: DROP\_PROCESSED 超时未处理: OVERDUE 超时处理完成: OVERDUE\_PROCESSED 部分超时未处理: PART\_OVERDUE 处理完成: PROCESSED 处理中: PROCESSING 待处理: WAIT\_PROCESS |  |
| ├─ complainStatusDescription | string | 非必须 |  | 投诉单状态描述 |  |
| ├─ processCode | string | 非必须 |  | 商家处理结果码 已联系到用户，协商一致，无异议: CONSENSUS\_WITH\_CLIENT 其他: ORTHER 不涉及退款，已针对投诉内容进行整改: RECTIFICATION\_NO\_REFUND 已退款，用户无异议: REFUND 已提交证明材料: SUBMIT\_PROOF\_NOT\_CONTACTED |  |
| ├─ processMessage | string | 非必须 |  | 商家处理结果码对应描述 |  |
| ├─ processRemark | string | 非必须 |  | 商家处理备注 |  |
| ├─ processImgUrlList | string | 非必须 |  | 商家处理备注图片url列表 |  |
| ├─ gmtRiskFinishTime | string | 非必须 |  | 推送时间 |  |
| ├─ taskId | string | 非必须 |  | 投诉单号id |  |
| ├─ certifyInfo | string | 非必须 |  | 投诉凭证图片信息特殊 |  |
| ├─ complainUrl | string | 非必须 |  | 投诉网址 |  |
| ├─ complaintId | string | 非必须 |  | 投诉主表主键id |  |
| ├─ detailId | string | 非必须 |  | 交易信息表主键id |  |
| ├─ complaintRecordId | null | 非必须 |  | 投诉主表id |  |
| ├─ tradeNo | string | 非必须 |  | 支付宝交易单号 |  |
| ├─ outNo | null | 非必须 |  | 商家订单号 |  |
| ├─ gmtTrade | null | 非必须 |  | 交易时间 |  |
| ├─ gmtRefund | null | 非必须 |  | 退款时间 |  |
| ├─ status | string | 非必须 |  | 交易投诉状态 用户撤诉: DROP\_COMPLAIN 超时未处理: OVERDUE 已退款: PROCESSED 退款处理中: REFUNDING 待处理: WAIT\_PROCESS |  |
| ├─ statusDescription | string | 非必须 |  | 交易投诉状态描述 |  |
| ├─ amount | null | 非必须 |  | 交易单金额（单位：人民币元） |  |
| ├─ transFirstLevelAgentNum | null | 非必须 |  | 交易一级服务商编号 |  |
| ├─ transFirstLevelAgentName | null | 非必须 |  | 交易一级服务商名称 |  |
| ├─ transAgentNum | null | 非必须 |  | 交易服务商编号 |  |
| ├─ transAgentName | null | 非必须 |  | 交易服务商名称 |  |
| ├─ transMercNum | null | 非必须 |  | 交易商户编号 |  |
| ├─ transMercName | null | 非必须 |  | 交易商户名称 |  |
| ├─ bussOrderNo | null | 非必须 |  | 业务交易订单号 |  |
| ├─ isPush | null | 非必须 |  | 推送 |  |

### 返回示例

```
{
    "list": [
        {
            "transFirstLevelAgentName": "河南友之顺商贸有限公司",
            "complainStatusDescription": "待处理",
            "isPush": "Y",
            "processMessage": "",
            "complaintRecordId": "241328865",
            "complainContent": "用户是未成年，在咸鱼上通过商家购买商品，商家引导未成年孩子通过支付宝付款，收到的商品与描述不符，多次联系不上您，希望退款，怀疑您欺诈，如不退款将会举报您",
            "detailId": "270438199",
            "oppositeName": "林龙海",
            "gmtRefund": "1748325035000",
            "processRemark": "",
            "complainStatus": "WAIT_PROCESS",
            "gmtTrade": "1747632299000",
            "transFirstLevelAgentNum": "FW1002879",
            "certifyInfo": "",
            "transAgentNum": "FW2007679",
            "complainUrl": "",
            "gmtOverdue": "1748584235000",
            "contact": "",
            "gmtRiskFinishTime": "1748325035000",
            "transAgentName": "刘晓玲-陈定军",
            "complainTradeNo": "2025051922001476741442572926",
            "processImgUrlList": "",
            "amount": "3000.00",
            "transMercName": "林龙海",
            "tradeNo": "2025051922001476741442572926",
            "oppositePid": "2088370196683410",
            "statusDescription": "待处理",
            "transMercNum": "833596355710074",
            "complaintId": "241328865",
            "processCode": "",
            "complainAmount": "3000.00",
            "transfirstLevelAgentNumCnt": "1",
            "bussOrderNo": "AL2505191324590001460325054",
            "gmtProcess": "1748325035000",
            "outNo": "791266000048330003AL2505191324590001460325054",
            "gmtComplain": "1748325031000",
            "taskId": "12361435046",
            "status": "WAIT_PROCESS"
        },
        {
            "transFirstLevelAgentName": "河南友之顺商贸有限公司",
            "complainStatusDescription": "待处理",
            "isPush": "Y",
            "processMessage": "",
            "complaintRecordId": "241328858",
            "complainContent": "用户是未成年，在咸鱼上通过商家购买商品，商家引导未成年孩子通过支付宝付款，收到的商品与描述不符，多次联系不上您，希望退款，怀疑您欺诈，如不退款将会举报您",
            "detailId": "270438192",
            "oppositeName": "林龙海",
            "gmtRefund": "1748325029000",
            "processRemark": "",
            "complainStatus": "WAIT_PROCESS",
            "gmtTrade": "1747632321000",
            "transFirstLevelAgentNum": "FW1002879",
            "certifyInfo": "",
            "transAgentNum": "FW2007679",
            "complainUrl": "",
            "gmtOverdue": "1748584228000",
            "contact": "",
            "gmtRiskFinishTime": "1748325028000",
            "transAgentName": "刘晓玲-陈定军",
            "complainTradeNo": "2025051922001476741448277557",
            "processImgUrlList": "",
            "amount": "2980.00",
            "transMercName": "林龙海",
            "tradeNo": "2025051922001476741448277557",
            "oppositePid": "2088370196683410",
            "statusDescription": "待处理",
            "transMercNum": "833596355710074",
            "complaintId": "241328858",
            "processCode": "",
            "complainAmount": "2980.00",
            "transfirstLevelAgentNumCnt": "1",
            "bussOrderNo": "AL2505191325210000085292235",
            "gmtProcess": "1748325028000",
            "outNo": "031266000048330003AL2505191325210000085292235",
            "gmtComplain": "1748325022000",
            "taskId": "12361577269",
            "status": "WAIT_PROCESS"
        }
    ],
    "total": 98,
    "return_code": 10000
}
```

文档更新时间: 2025-05-28 19:20   作者：郝庚鑫