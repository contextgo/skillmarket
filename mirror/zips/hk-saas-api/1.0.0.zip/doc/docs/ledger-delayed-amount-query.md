### 根据交易订单号查询分账金额详情

**业务功能**  
通过交易订单号查询分账金额的情况  
**交互模式**  
请求：后台请求交互模式  
返回结果：后台请求交互模式  
**测试url：**  
<http://47.95.131.62:8080/api/v1/delay-ledger/query>

**请求参数(O-非必传 ,M-必传):**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 服务商的编号，由SaaS平台分配，表示当前商户属于该服务商名下 | ISV01991023 | M |
| merch\_no | 商户编号 | String | 商户在SaaS平台的编号 | a10253390 | M |
| trade\_no | SAAS交易订单号 | String | saas订单号 |  | M |

#### 请求示例:

```
{
    "agent_no": "FW10303096",
    "merch_no": "8333569520205",
    "trade_no": "UN221228962451812464392",
    "accessid": "4028805b7c597017cb562c073003a",
    "sign": "BF88A567EFD305552B5935F50F99B"
}
```

**返回参数:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String | 服务商的编号，由SaaS平台分配，表示当前商户属于该服务商名下 | ISV01991023 | M |
| trade\_no | SAAS交易订单号 | String | saas订单号 |  | M |
| ledger\_amount | 已分账金额 | BigDecimal |  | 100 | M |
| trade\_amount | 交易金额 | BigDecimal |  | 100 | M |
| settle\_amount | 结算金额 | BigDecimal | 未分账前可结算款 | 100 | M |
| is\_finish | 是否完结 | String | 0：未完结 1：已完结 |  | M |
| remain\_amount | 可分账金额 | BigDecimal | 剩余可分账金额（商户剩余可结算款） | 100 | M |
| finish\_amount | 完结金额 | BigDecimal | 同remain\_amount | 100 | M |
| finish\_time | 完结时间 | String | 延时分账订单完结时间 |  | M |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |

#### 返回示例:

```
{
    "ledger_amount": 0.01,
    "trade_amount": 0.01,
    "settle_amount": 0.02,
    "trade_no": "UN221229234102059812464392",
    "agent_no": "FW1000566",
    "is_finish": "1",
    "remain_amount": 0.01,
    "finish_amount": 0.01,
    "finish_time": "2022-12-29 23:57:00",
    "return_code": 10000,
    "sign": "A768F558D6F66DC9EF414538960FAAFC"
}
```

文档更新时间: 2024-11-29 10:14   作者：张亚飞