#### 简要描述：

1、风控案例推送接口

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| mercNum | 商户编号 | String |  | 8331634891201 | M |
| typeNo | 风险类别编号 | String |  | T00038 | M |
| caseDealWay | 案例处理方式 | String |  | investigate | M |
| auditStatus | 审核状态 | String | 待提交：“DTJ”待审核 “DSH”;审核中 “SHZ”; 回退”HT”;审核通过 “SHTG”; | DSH | M |
| description | 提交案例资质说明 | String |  | 1)如企业商户，请提供商户营业执照照片（营业执照必须真实，工商网可查）、经营场所照片及门头照等、相关交易说明、交易卡正反面照片、交易凭证、代理承诺函； \n2)如个人商户，请提供商户身份证正反面照片、可以定位至国内具体位置的手持机具照片，或商户法人在店面的手持机具照片（序列号需清晰可见）、相关交易说明、交易卡正反面照片、交易凭证、代理承诺函;\n注：材料图片单张大小2MB，文件格式JPG，PNG，每种类型最多4张。 | M |
| riskTypeName | 类别名称 | String |  | SR00048 | M |
| caseNo | 案例编号 | String |  | 20230511155524394956750290100 | M |
| firstAgentNo | 一级服务商编号 | String |  | ISV100001 | M |
| firstAgentName | 一级服务商名称 | String |  | 张三有限公司 | M |
| referOrders | 涉及交易流水号 | String |  | 20230511155524394956750290100 | M |

#### 请求示例:

```
{
    "mercNum": "8331634891201",
    "typeNo": " T00038 ",
    "caseDealWay": " investigate ",
    "auditStatus": " DSH ",
    "description": " 1)如企业商户，请提供商户营业执照照片（营业执照必须真实，工商网可查）、经营场所照片及门头照等 ",
    "riskTypeName": " SR00048 ",
    "caseNo": "20230511155524394956750290100",
    "firstAgentNo": "ISV100001",    
    "firstAgentName": "张三有限公司",    
    "referOrders": "涉及交易流水号",    
}
```

文档更新时间: 2025-02-28 15:05   作者：张亚飞