### 微信被扫获取openid

**业务功能**  
通过微信付款码查询公众号Openid。

* 如果子商户号没有绑定appid，只返回openid
* 如果子商户号绑定一个appid，入参sub\_appid非必传，返回openid和sub\_openid
* 如果子商户号绑定多个appid，入参sub\_appid必传，返回openid和sub\_openid

**交互模式**  
请求：后台请求交互模式  
返回结果：后台请求交互模式

**测试url：**  
<http://47.95.131.62:8080/api/v1/pay/wx/get-wx-openid>

**请求参数(O-非必传 ,M-必传):**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 商户编号 | String | 商户在SaaS平台的编号 | a10253390 | M |
| auth\_code | 授权码 | String | 微信支付的二维码 |  | M |
| sub\_appid | 子商户公众账号ID | String |  |  | O |

#### 请求示例:

```
{
    "accessid": "4028805b76736db4017674c6a5bd0201",
    "merch_no": "833102253310391",
    "auth_code": "147484154541",
    "sign": "EF6CAA9B05490A6BF251DF1DEE6E0618"
}
```

**返回参数:**

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 错误码 | String | 错误码 | 80002 | M |
| return\_msg | 错误信息 | String |  |  | O |
| sub\_mch\_id | 微信子商户号 | String |  |  | M |
| merch\_no | 商户号 | String |  |  | M |
| openid | 用户标识 | String |  |  | O |
| sub\_openid | 用户子标识 | String |  |  | O |
| sub\_appid | 子商户公众账号ID | String |  |  | O |

#### 返回示例:

```
正确：
{
    "return_code": 10000,
    "openid": "125454451",
    "sub_openid": "1848747854",
    "merch_no": "833154545512",
    "sign": "821B1642BDC1BED2BFA886856AFEC9A4"
}
错误：
{
    "return_code": 99999,
    "return_msg": "从业机构信息异常",
    "sign": "821B1642BDC1BED2BFA886856AFEC9A4"
}
```

文档更新时间: 2024-12-05 18:02   作者：梁宇鹏