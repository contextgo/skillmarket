#### 概要描述:

用于查询在微信侧配置成功的appid及授权目录明细

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/wx-appid-conf/query>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| merch\_no | 海科商户编号 | String | 海科平台商户号 |  | M |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "merch_no": "833226358120003",
    "sign": "4E4BC92E2E7BDFA27DFAB254E0BF5B36"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 返回码 | int | 10000：成功 其他：失败 |  | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| result\_code | 真实结果状态码 | String | 当此值为SUCCESS时返回 jsapi\_path\_list和appid\_config\_list |  | O |
| jsapi\_path\_list | 授权目录(成功时返回) | String | 银行特约商户公众账号JS API支付授权目录列表 ，JSON格式数据，每个支付目录 要求符合URI格式规范，最多返回5个 |  | O |
| appid\_config\_list | 关联APPID与关注(成功时返回) | String | sub\_appid为绑定好的商户公众号、小程序、APP支付等APPIDsubscribe\_appid关注特约商户公众号的APPID，配置关系如果绑定多个以列表形式返回，如果不区分绑定则sub\_appid=NULL的记录返回默认推荐关注的APPID |  | O |
| err\_code | 微信错误码 | String | 当result\_code不为SUCCESS时必返 |  | O |
| err\_code\_des | 微信错误消息 | String | 当result\_code不为SUCCESS时必返 |  | O |

#### 成功时返回示例:

```
{
        "result_code": "SUCCESS",
        "jsapi_path_list": [
            "https://m*.******.cn/"
        ],
        "appid_config_list": [
            {
                "sub_appid": "wx2a0bae9******",
                "subscribe_appid": "wx2a0bae9******"
            }
        ],
    "return_code": 10000,
    "sign": "A0F5B437FF016CC0E07D57E0EC2C28BC"
}
```

文档更新时间: 2024-11-29 10:08   作者：王金晶