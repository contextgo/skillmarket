#### 简要描述：

* 本接口为费率变更聚合接口，可同时修改微信、支付宝、银行卡/银联二维码相关费率值。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v2/merchant/aggregation/rate/update>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 商户编号 | String |  |  | M |
| agent\_apply\_no | 服务商申请单号 | String |  |  | O |
| product\_data | 费率信息 | JSON |  |  | O |
| effect\_mode | 生效方式 | String | 1实时生效、2次日生效、3下个工作日生效、不传默认为实时生效 |  | O |

##### 费率信息：

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| 费率模式 | 费率模式 | JSON |  |  | O |

##### 费率模式：

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| wx\_rate | 微信费率 | String | 单位为万分之一，例如费率为0.6%,需要传60。（如果为0.2，需要传20） |  | O |
| ali\_rate | 支付宝费率 | String | 单位为万分之一，例如费率为0.6%,需要传60。（如果为0.2，需要传20） |  | O |
| bank | 银行卡/银联二维码费率值 | JSON |  |  | O |

##### 银行卡/银联二维码费率信息：bank (银行卡与银联二维码需要同时上传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| bank\_debit\_rate | 银行卡借记卡费率 | String |  | 例如费率为0.6,需要传60; | O |
| bank\_debit\_max | 银行卡借记卡手续费封顶 | String |  | 18元需要传1800 | O |
| bank\_credit\_rate | 银行卡贷记卡费率 | String |  | 例如费率为0.6,需要传60; | O |
| union\_debit\_rate | 银联二维码借记卡费率 | String |  | 例如费率为0.6,需要传60; | O |
| union\_debit\_max | 银联二维码借记卡手续费封顶 | String |  | 18元需要传1800 | O |
| union\_credit\_rate | 银联二维码贷记卡费率 | String |  | 例如费率为0.6,需要传60; | O |
| union\_mix\_rate | 银联二维码1000以下包括1000费率值 | String |  | 例如费率为0.6,需要传60; | O |

#### 请求示例:

```
{
 "agent_no": "11010200097",
 "agent_apply_no": "70552864916523",
 "notify_url": "https://www.baidu.com",
 "merch_no": "88888888",
 "product_data": {
  "bank": {
   "bank_debit_rate": "38",
   "bank_credit_rate": "40",
   "union_debit_rate": "41",
   "bank_debit_max": "2000",
   "union_credit_rate": "43",
   "union_mix_rate": "44",
   "union_debit_max": "2000"
  },
  "wx_rate": "38",
  "ali_rate": "38"
 },
 "accessid": "cpostest",
 "sign": "2DD3280907154F8993A77371669D97D0"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| return\_code | 请求返回码 | String |  | 10000 | M |
| return\_msg | 错误消息 | String | 当return\_code不为10000时有值 |  | O |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 商户编号 | String |  |  | M |
| notify\_url | 通知地址 | String |  |  | O |
| agent\_apply\_no | 服务商申请单编号 | String |  |  | O |
| result\_msg | 返回内容 | JSON | 业务修改结果返回 | 例如：修改微信业务，只返回微信修改结果 | C |

##### 返回内容：result\_msg

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| wx\_return\_code | 微信返回码 | String |  | 10000 | O |
| wx\_return\_msg | 当wx\_return\_code不为10000时有值 | String |  |  | O |
| ali\_return\_code | 支付宝返回码 | String |  | 10000 | O |
| ali\_return\_msg | 当ali\_return\_code不为10000时有值 | String |  |  | O |
| bank\_return\_code | 银行卡/银联二维码返回码 | String |  | 10000 | O |
| bank\_return\_msg | 当bank\_return\_code不为10000时有值 | String |  |  | O |

#### 返回示例:

```
{
 "return_code": 10000,
 "agent_no": "11010200097",
 "merch_no": "88888888",
 "notify_url: "70552864916523",
 "agent_apply_no": "https://www.baidu.com",
 "result_msg": {
  "wx_return_code": 10000,
  "ali_return_code": 10000,
  "bank_return_code": 10000
 }
}
```

文档更新时间: 2025-08-28 18:51   作者：王金晶