#### 简要描述：

* 本接口调用成功只表示当前业务申请成功，对于业务最终是否开通成功需要通过“商户业务查询”接口查询来确定。

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/merchant-ali-biz/apply>

#### 请求参数(O-非必传 ,M-必传)

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| agent\_no | 服务商编号 | String |  |  | M |
| merch\_no | 商户编号 | String |  |  | M |
| agent\_apply\_no | 服务商申请单号 | String |  |  | O |
| rate | 交易费率 | String | 单位为：万分之一，比如费率为 0.6%, 需要传 60 | 38 | M |
| channel\_no | 支付宝渠道号 | String | 服务商通过海科申请的支付宝渠道号(v1.13) |  | M |
| business\_id | 经营类目id | String | 非必填参数 取值详见附录：[支付宝商户经营类目](http://39.106.84.215:8181/docs/saas/saas-1b72ghlpfqd7i "支付宝商户经营类目") |  | O |
| mcc | 支付宝mcc | String | 非必填参数 取值详见附录：[支付宝MCC和经营类目](http://39.106.84.215:8181/docs/saas/saas-1b72gd45o8rrp "支付宝MCC和经营类目") |  | O |
| notify\_url | 通知地址 | String | 商户业务审核状态变更后的通知地址 | <http://x.cn/shop/notice> | O |

#### 请求示例:

```
{
    "accessid": "cpostest",
    "agent_no": "11010200097",
    "merch_no": "833581758120002",
    "agent_apply_no": "196697870347",
    "notify_url": "https://www.baidu.com",
    "mcc": "0742",
    "rate":"38",
    "channel_no": "2088421659182334",
    "business_id": "2015050700000000",
    "sign": "8674723B7E711291E7676B8AEE2EF6D2"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| apply\_no | 申请单编号 | String |  |  | M |

#### 返回示例:

```
{
    "return_code": 23003,
    "return_msg": "费率为空",
    "sign": "185E40DF38540C1BBFFED89E78305A91"
}
```

文档更新时间: 2025-01-02 20:23   作者：王金晶