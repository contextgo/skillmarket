#### 简要描述：

* 终端通过本接口下载三元组信息

#### 请求URL:

* 测试环境：<http://47.95.131.62:8080/api/v1/terminal-triple/download>

#### 请求参数(O-非必传 ,M-必传):

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| sn | 终端sn | String |  |  | M |

#### 请求示例:

```
{
    "sn":"195GCA8C3803"
}
```

#### 返回参数说明:

| 参数 | 参数名称 | 类型 | 参数说明 | 样例 | 可空 |
| --- | --- | --- | --- | --- | --- |
| DeviceName | 设备名称 | String |  |  | M |
| DeviceSecret | 设备秘钥 | String |  |  | M |
| ProductKey | 产品KEY | String |  |  | M |

#### 返回示例:

```
{
    "DeviceName":"195GCA8C3803",
    "DeviceSecret":"XXXXXXXX",
    "ProductKey":"XXXXXXXX"
    }
```

文档更新时间: 2024-12-06 14:36   作者：admin