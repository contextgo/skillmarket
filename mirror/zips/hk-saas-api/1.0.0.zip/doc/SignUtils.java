package cn.hkrt.haipay.common.utils;

import net.sf.json.JSONArray;
import net.sf.json.JSONNull;
import net.sf.json.JSONObject;
import org.apache.commons.codec.digest.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/**
 * SAAS 机构对接参数签名工具类。
 * <p>
 * 默认签名规则与 reference/signing.md 一致：
 * 待签串末尾直接拼接 accesskey（无 {@code &key=} 前缀），UTF-8 + MD5 → 32位十六进制大写。
 * </p>
 *
 * <h3>接入步骤</h3>
 * <ol>
 *   <li>将本文件复制到当前项目的工具类包下，修改 {@code package} 声明以符合项目规范；</li>
 *   <li>确保依赖 net.sf.json（json-lib）、Apache Commons Codec（如使用 getXinyuanfuSign 等）；</li>
 *   <li>使用 signing.md §5 的 golden examples 编写单元测试验证签名正确性。</li>
 * </ol>
 *
 * <h3>核心方法速查</h3>
 * <table>
 *   <tr><th>方法</th><th>签名变体</th><th>适用场景</th></tr>
 *   <tr><td>{@link #signParams(String, Map)}</td><td>待签串 + accesskey → MD5</td><td>默认机构对接</td></tr>
 *   <tr><td>{@link #signParamsAddKey(String, Map)}</td><td>待签串 + &amp;key=accesskey → MD5</td><td>部分通道（文档明确要求时）</td></tr>
 *   <tr><td>{@link #signParams2g(String, String)}</td><td>已拼接串 + accesskey → MD5</td><td>调用方自行拼接待签串</td></tr>
 *   <tr><td>{@link #getXinyuanfuSign(Map, String)}</td><td>排序拼接 + key=agentKey → SHA-256</td><td>新悦付通道专用</td></tr>
 * </table>
 *
 * @see reference/signing.md 签名算法规范与 golden examples
 */
public class SignUtils {

    /**
     * 判断值是否为 null、JSONNull 或空字符串。
     * <p>空值参数不参与签名拼接。</p>
     *
     * @param value 待判断的值，可为任意类型
     * @return true 表示值为空或 null，应跳过
     */
    private static boolean isNullOrEmpty(Object value) {
        if (value == null) {
            return true;
        }
        if (value instanceof JSONNull) {
            return true;
        }
        String s = value.toString();
        return s.isEmpty();
    }

    /**
     * 将字节数组转换为十六进制字符串（小写）。
     * <p>调用方通常会在结果上调用 {@code toUpperCase()} 以满足平台"32位十六进制大写"要求。</p>
     *
     * @param bytes 原始字节数组
     * @return 十六进制小写字符串，长度为 bytes.length * 2
     */
    private static String byte2Hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b & 0xff));
        }
        return sb.toString();
    }

    /**
     * 对 UTF-8 字符串做 MD5 摘要，返回 32 位十六进制大写字符串。
     * <p>这是默认签名流程的核心摘要方法，对应 signing.md §3 步骤 6。</p>
     *
     * @param data 待签字符串（UTF-8 编码）
     * @return 32 位十六进制大写 MD5 值
     * @throws RuntimeException 当运行环境不支持 MD5 算法时抛出
     */
    public static String md5dataToSign(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] rtn = md.digest(data.getBytes(StandardCharsets.UTF_8));
            return byte2Hex(rtn).toUpperCase();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("MD5 not available", e);
        }
    }

    /**
     * 对原始字节数组做 MD5 摘要，返回 32 位十六进制大写字符串。
     * <p>适用于调用方已自行将待签内容转为字节的场景（如文件签名）。</p>
     *
     * @param data 原始字节数组
     * @return 32 位十六进制大写 MD5 值
     * @throws RuntimeException 当运行环境不支持 MD5 算法时抛出
     */
    public static String md5data(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] rtn = md.digest(data);
            return byte2Hex(rtn).toUpperCase();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("MD5 not available", e);
        }
    }

    /**
     * 默认机构对接签名：{@code getToBeSign(params) + partnerKey} → MD5 大写。
     * <p>
     * 对应 signing.md §3 默认规则：待签串末尾直接拼接 accesskey，无 {@code &key=} 前缀。
     * 这是最常用的签名方式，适用于绝大多数 SAAS 机构对接场景。
     * </p>
     *
     * @param partnerKey 接入密钥（accesskey），由平台下发
     * @param params     业务参数字典（可包含嵌套对象/数组），其中 sign/mac 字段和空值会被自动过滤
     * @return 32 位十六进制大写签名字符串
     */
    public static String signParams(String partnerKey, Map params) {
        String tobesign = getToBeSign(params) + partnerKey;
        return md5dataToSign(tobesign);
    }

    /**
     * 对已拼接的待签串直接追加 partnerKey 后做 MD5 大写。
     * <p>
     * 适用于调用方已自行完成参数排序与拼接，仅需追加密钥并摘要的场景。
     * </p>
     *
     * @param partnerKey 接入密钥（accesskey）
     * @param signStr    已按规则拼接好的待签字符串
     * @return 32 位十六进制大写签名字符串
     */
    public static String signParams2g(String partnerKey, String signStr) {
        return md5dataToSign(signStr + partnerKey);
    }

    /**
     * 部分通道签名：{@code getToBeSign(params) + "&key=" + partnerKey} → MD5 大写。
     * <p>
     * 与 {@link #signParams} 的区别在于密钥前缀：本方法在 accesskey 前加了 {@code &key=}。
     * <b>仅当接口文档明确要求时才使用此变体</b>，默认请使用 {@link #signParams}。
     * </p>
     *
     * @param partnerKey 接入密钥（accesskey）
     * @param params     业务参数字典
     * @return 32 位十六进制大写签名字符串
     */
    public static String signParamsAddKey(String partnerKey, Map params) {
        return md5dataToSign(getToBeSign(params) + "&key=" + partnerKey);
    }

    /**
     * 仅拼接值（不含 key=）的签名变体，内部委托 {@link #signParamsAddKey}。
     * <p>保留用于兼容旧调用方。</p>
     *
     * @param partnerKey 接入密钥（accesskey）
     * @param params     业务参数字典
     * @return 32 位十六进制大写签名字符串
     */
    public static String signValueAddKey(String partnerKey, Map params) {
        return signParamsAddKey(partnerKey, params);
    }

    /**
     * 将 JSONObject 转为 TreeMap 后委托 {@link #getToBeSign(Map)}。
     * <p>JSONObject 本身不保证键序，需先转为 TreeMap 以确保字典序排列。</p>
     *
     * @param jo JSON 对象
     * @return 按 signing.md §3 规则拼接的待签字符串（不含 accesskey）
     */
    public static String getToBeSign(JSONObject jo) {
        TreeMap tm = new TreeMap();
        for (Iterator it = jo.keys(); it.hasNext(); ) {
            String k = (String) it.next();
            tm.put(k, jo.get(k));
        }
        return getToBeSign(tm);
    }

    /**
     * 核心拼接方法：按 signing.md §3 规则生成待签字符串。
     * <p>
     * 算法步骤：
     * <ol>
     *   <li>将参数放入 TreeMap 按键名字典序排列；</li>
     *   <li>过滤掉 sign、mac 字段及空值；</li>
     *   <li>对每个键值对生成 {@code key=value}，value 为嵌套对象/数组时递归展开；</li>
     *   <li>用 {@code &} 连接所有键值对。</li>
     * </ol>
     * 嵌套展开规则详见 signing.md §4。
     * </p>
     *
     * @param params 业务参数字典
     * @return 拼接后的待签字符串（不含 accesskey），如 {@code "a=1&b=2&c=3"}
     */
    public static String getToBeSign(Map params) {
        TreeMap tm = new TreeMap();
        tm.putAll(params);
        StringBuffer sb = new StringBuffer();
        int i = 0;
        for (Iterator iterator = tm.entrySet().iterator(); iterator.hasNext(); ) {
            Map.Entry e = (Map.Entry) iterator.next();
            String k = (String) e.getKey();
            if (isNullOrEmpty(e.getValue()) || "sign".equals(k) || "mac".equals(k)) {
                continue;
            }
            String v;
            if (e.getValue() instanceof JSONArray) {
                v = getJsonArrayStr((JSONArray) e.getValue());
            } else if (e.getValue() instanceof JSONObject) {
                v = getToBeSign((JSONObject) e.getValue());
            } else {
                v = e.getValue().toString();
            }
            if (i != 0) {
                sb.append("&");
            }
            sb.append(k).append("=").append(v);
            i++;
        }
        return sb.toString();
    }

    /**
     * 将 JSONObject 转为 TreeMap 后委托 {@link #getToBeSignValue(Map)}。
     * <p>与 {@link #getToBeSign(JSONObject)} 的区别：仅拼接 value，不含 {@code key=}。</p>
     *
     * @param jo JSON 对象
     * @return 仅含 value 的待签字符串
     */
    public static String getToBeSignValue(JSONObject jo) {
        TreeMap tm = new TreeMap();
        for (Iterator it = jo.keys(); it.hasNext(); ) {
            String k = (String) it.next();
            tm.put(k, jo.get(k));
        }
        return getToBeSignValue(tm);
    }

    /**
     * 仅拼接 value（不含 key=）的待签串生成方法。
     * <p>
     * 用于部分特殊签名场景（仅按值排序拼接，不含键名）。
     * 过滤规则与 {@link #getToBeSign(Map)} 一致：排除 sign、mac 及空值。
     * </p>
     *
     * @param params 业务参数字典
     * @return 仅含 value 的待签字符串，如 {@code "1&2&3"}
     */
    public static String getToBeSignValue(Map params) {
        TreeMap tm = new TreeMap();
        tm.putAll(params);
        StringBuffer sb = new StringBuffer();
        int i = 0;
        for (Iterator iterator = tm.entrySet().iterator(); iterator.hasNext(); ) {
            Map.Entry e = (Map.Entry) iterator.next();
            String k = (String) e.getKey();
            if (isNullOrEmpty(e.getValue()) || "sign".equals(k) || "mac".equals(k)) {
                continue;
            }
            String v;
            if (e.getValue() instanceof JSONArray) {
                v = getJsonArrayStr((JSONArray) e.getValue());
            } else if (e.getValue() instanceof JSONObject) {
                v = getToBeSignValue((JSONObject) e.getValue());
            } else {
                v = e.getValue().toString();
            }
            if (i != 0) {
                sb.append("&");
            }
            sb.append(v);
            i++;
        }
        return sb.toString();
    }

    /**
     * 递归展开 JSONArray 为字符串，用于签名拼接。
     * <p>
     * 展开规则（对应 signing.md §4）：
     * <ul>
     *   <li>数组元素为标量 → 直接 toString；</li>
     *   <li>数组元素为 JSONObject → 递归调用 {@link #getToBeSign(JSONObject)} 展开；</li>
     *   <li>数组元素为嵌套 JSONArray → 递归调用本方法；</li>
     *   <li>多个元素之间用 {@code &} 衔接。</li>
     * </ul>
     * </p>
     *
     * @param a JSON 数组
     * @return 展开后的字符串，如 {@code "c=2&d=3&c=4&d=5"}
     */
    public static String getJsonArrayStr(JSONArray a) {
        String r = "";
        for (int j = 0; j < a.size(); j++) {
            Object b = a.get(j);
            String v;
            if (b instanceof JSONArray) {
                v = getJsonArrayStr((JSONArray) b);
            } else if (b instanceof JSONObject) {
                v = getToBeSign((JSONObject) b);
            } else {
                v = b.toString();
            }
            if (j == 0) {
                r = v;
            } else {
                r += "&" + v;
            }
        }
        return r;
    }

    /**
     * 按字典序拼接参数（排除 sign 字段和空值），格式为 {@code key=value&key=value}。
     * <p>
     * 与 {@link #getToBeSign(Map)} 的区别：不排除 mac 字段，不处理嵌套对象/数组（值直接 toString）。
     * 适用于简单扁平参数的排序拼接场景。
     * </p>
     *
     * @param params 业务参数字典
     * @return 排序拼接后的字符串
     */
    public static String sortSplice(Map params) {
        TreeMap tm = new TreeMap();
        tm.putAll(params);
        StringBuffer sb = new StringBuffer();
        int i = 0;
        for (Iterator iterator = tm.entrySet().iterator(); iterator.hasNext(); ) {
            Map.Entry e = (Map.Entry) iterator.next();
            String k = (String) e.getKey();
            if (isNullOrEmpty(e.getValue()) || "sign".equals(k)) {
                continue;
            }
            if (i != 0) {
                sb.append("&");
            }
            sb.append(k).append("=").append(e.getValue().toString());
            i++;
        }
        return sb.toString();
    }

    /**
     * 按原始顺序拼接参数（排除空值），格式为 {@code key=value&key=value}。
     * <p>
     * 与 {@link #sortSplice(Map)} 的区别：不排序，保持 Map 原始迭代顺序；
     * 不排除 sign/mac 字段（仅排除空值）。
     * </p>
     *
     * @param params 业务参数字典
     * @return 按原始顺序拼接的字符串
     */
    public static String sortMap(Map params) {
        StringBuffer sb = new StringBuffer();
        int i = 0;
        for (Iterator iterator = params.entrySet().iterator(); iterator.hasNext(); ) {
            Map.Entry e = (Map.Entry) iterator.next();
            String k = (String) e.getKey();
            if (isNullOrEmpty(e.getValue())) {
                continue;
            }
            if (i != 0) {
                sb.append("&");
            }
            sb.append(k).append("=").append(e.getValue().toString());
            i++;
        }
        return sb.toString();
    }

    /**
     * 按键名忽略大小写排序后拼接参数，每项末尾带 {@code &}。
     * <p>
     * 专用于新悦付通道签名（{@link #getXinyuanfuSign}），排序方式为
     * {@link String#CASE_INSENSITIVE_ORDER}，拼接格式为 {@code key=value&}（每项末尾带 &）。
     * </p>
     *
     * @param map 参数字典（键值均为 String）
     * @return 忽略大小写排序后拼接的字符串，如 {@code "a=1&b=2&"}
     */
    private static String sortStringByMap(Map<String, String> map) {
        ArrayList<String> list = new ArrayList<>();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (entry.getValue() != null && entry.getValue().length() > 0) {
                list.add(entry.getKey() + "=" + entry.getValue() + "&");
            }
        }
        int size = list.size();
        String[] arrayToSort = list.toArray(new String[size]);
        Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(arrayToSort[i]);
        }
        return sb.toString();
    }

    /**
     * 新悦付通道专用签名：按键名忽略大小写排序拼接 + {@code key=agentKey} → SHA-256 大写。
     * <p>
     * 与默认签名规则的区别：
     * <ul>
     *   <li>排序方式为忽略大小写（而非字典序）；</li>
     *   <li>密钥前缀为 {@code key=}（而非直接拼接）；</li>
     *   <li>摘要算法为 SHA-256（而非 MD5）。</li>
     * </ul>
     * <b>仅用于新悦付通道</b>，其它场景请使用 {@link #signParams} 或 {@link #signParamsAddKey}。
     * </p>
     *
     * @param params   业务参数字典（键值均为 String）
     * @param agentKey 新悦付通道密钥
     * @return SHA-256 十六进制大写签名字符串
     */
    public static String getXinyuanfuSign(Map<String, String> params, String agentKey) {
        String tobesign = sortStringByMap(params) + "key=" + agentKey;
        return DigestUtils.sha256Hex(tobesign).toUpperCase();
    }

    /**
     * 对字符串做 SHA-1 摘要，返回十六进制小写字符串。
     * <p>适用于需要 SHA-1 校验的场景，非默认签名流程。</p>
     *
     * @param data 原始字符串
     * @return SHA-1 十六进制小写摘要值
     */
    public static String sha1(String data) {
        return DigestUtils.sha1Hex(data);
    }
}
