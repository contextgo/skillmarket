# `doc/` 目录说明

| 文件 | 说明 |
|------|------|
| `api-catalog.yaml` | SAAS 接口场景与 `doc_url` 的**结构化目录**（主数据源）。v2 版本覆盖 24 个业务场景共 150+ 接口，含已废弃分组与附录参考文档。每个 API 含 `local_doc` 指向本地缓存 |
| `SignUtils.java` | **Java** 项目可直接复制到工具包并改 `package`；**非 Java** 请据其逻辑用目标语言重写（见 `reference/signing.md` §8–§9） |
| `download_docs.py` | 本地文档缓存下载/更新脚本，支持全量更新和按名称过滤增量更新 |
| `docs/` | **本地接口文档缓存**目录（Markdown 格式），详见下方说明 |

签名规范与 golden examples 见 [`../reference/signing.md`](../reference/signing.md)。

## api-catalog.yaml 结构说明

- `scenarios[]`：活跃接口场景，每个含 `id`、`title`、`apis[]`
- `deprecated_scenarios[]`：已废弃接口分组，仅供历史对照
- `appendix_refs[]`：附录参考文档（签名说明、银行代码等），非接口条目
- 每条 API：`name`、`doc_url`（在线文档）、`local_doc`（本地缓存路径）、可选 `id_hint`（原编号）、可选 `note`（补充说明）

## docs/ 本地文档缓存

| 文件 | 说明 |
|------|------|
| `manifest.json` | 缓存清单：下载时间、每个 API 的 `doc_url` 与本地文件映射、下载状态 |
| `*.md` | 从在线文档门户抓取并转换为 Markdown 的接口文档（包含参数表、请求示例、返回示例等） |

### 更新本地缓存

```bash
python doc/download_docs.py                          # 更新全部
python doc/download_docs.py 预下单 订单查询           # 按接口名称过滤更新
python doc/download_docs.py pre-pay                  # 按英文标识过滤更新
```

脚本会读取 `api-catalog.yaml` 中的 `local_doc` 字段确定目标文件名，从 `doc_url` 抓取 HTML 页面、提取接口页主体内容并转换为 Markdown 格式后保存。已有文件会被覆盖。支持传入关键词参数按接口名称或英文标识模糊匹配，仅更新匹配的接口。

也可通过 `/hk-update` 命令触发更新（见 SKILL.md §7），该方式由 Agent 直接执行，**不依赖 Python 环境**。

### 三级回退机制

Skill 获取接口文档时按以下优先级逐级回退：

1. **在线抓取** `doc_url` → 成功则使用（获取最新内容）
2. **读取本地缓存** `local_doc` → 文件存在则使用（网络不可用时的兜底）
3. **请用户提供** → 用户粘贴正文或提供新 URL
