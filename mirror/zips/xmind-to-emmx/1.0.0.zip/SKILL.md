# xmind-to-emmx

XMind → EMMX 格式转换工具。将 XMind 思维导图文件（.xmind）转换为 eMindMap 格式（.emmx）。

## 依赖

- Python 3.6+（纯标准库，零额外依赖）

## 使用方法

```bash
python scripts/convert.py <输入文件.xmind> [输出文件.emmx]
```

### 示例

```bash
# 指定输出文件名
python scripts/convert.py mymap.xmind mymap.emmx

# 省略输出文件名，默认在同目录生成同名 .emmx
python scripts/convert.py mymap.xmind
```

## 支持格式

- 输入：XMind Zen 格式（.xmind，内含 content.json），即 XMind 2019 及以上版本
- 输出：eMindMap 格式（.emmx）

## 已知限制

- 仅支持 XMind Zen 格式，不支持旧版 XMind（content.xml 格式）
- 仅转换文本内容与层级结构，不保留样式/颜色/图标/图片/备注/链接/优先级标签
- 仅处理第一个 Sheet（多 Sheet 文件只转换第一个）
- 输出 EMMX 为基础结构，不含布局坐标（依赖 eMindMap 自动布局）

## 文件结构

```
xmind-to-emmx.skill/
├── SKILL.md
└── scripts/
    └── convert.py
```

## 版本

1.0.0 (2026-05-05)
