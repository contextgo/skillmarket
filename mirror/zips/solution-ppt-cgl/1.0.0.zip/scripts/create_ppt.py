#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PPT生成脚本
从大纲Markdown文件生成PowerPoint演示文稿
"""

import sys
import re
from pathlib import Path

def check_dependencies():
    """检查依赖库"""
    try:
        from pptx import Presentation
        from pptx.util import Inches, Pt
        from pptx.enum.text import PP_ALIGN
        from pptx.dml.color import RGBColor
        return True
    except ImportError:
        print("错误: 需要安装 python-pptx 库")
        print("安装命令: pip install python-pptx")
        return False

def parse_outline(md_content):
    """解析大纲Markdown内容"""
    slides = []
    current_slide = None
    
    lines = md_content.split('\n')
    
    for line in lines:
        line = line.rstrip()
        
        # 检测页面标题 (## 第X页：标题)
        page_match = re.match(r'^##\s*第(\d+)页[：:]\s*(.+)$', line)
        if page_match:
            if current_slide:
                slides.append(current_slide)
            current_slide = {
                'page_num': int(page_match.group(1)),
                'title': page_match.group(2),
                'content': []
            }
            continue
        
        # 检测子标题 (### 标题)
        subtitle_match = re.match(r'^###\s*(.+)$', line)
        if subtitle_match and current_slide:
            current_slide['content'].append({
                'type': 'subtitle',
                'text': subtitle_match.group(1)
            })
            continue
        
        # 检测列表项 (- 内容 或 - **粗体**：内容)
        list_match = re.match(r'^-\s*(.+)$', line)
        if list_match and current_slide:
            text = list_match.group(1)
            # 处理粗体标记
            text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
            current_slide['content'].append({
                'type': 'list_item',
                'text': text
            })
            continue
        
        # 检测建议配图
        img_match = re.match(r'^\*\*建议配图\*\*[：:]\s*(.+)$', line)
        if img_match and current_slide:
            current_slide['content'].append({
                'type': 'image_hint',
                'text': img_match.group(1)
            })
            continue
        
        # 检测分隔线，跳过
        if line.strip() == '---':
            continue
        
        # 其他非空行作为普通文本
        if line.strip() and current_slide:
            # 跳过代码块标记
            if line.strip().startswith('```'):
                continue
            # 跳过表格分隔行
            if re.match(r'^[\|\-\s]+$', line):
                continue
            # 跳过表头行
            if '|' in line and not current_slide['content']:
                continue
    
    if current_slide:
        slides.append(current_slide)
    
    return slides

def create_ppt(slides, output_path):
    """创建PPT文件"""
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN
    from pptx.dml.color import RGBColor
    
    prs = Presentation()
    prs.slide_width = Inches(13.333)  # 16:9比例
    prs.slide_height = Inches(7.5)
    
    # 定义颜色
    TITLE_COLOR = RGBColor(0, 51, 102)  # 深蓝色
    SUBTITLE_COLOR = RGBColor(51, 51, 51)  # 深灰色
    ACCENT_COLOR = RGBColor(0, 112, 192)  # 蓝色
    
    for slide_data in slides:
        # 判断页面类型
        is_cover = slide_data['page_num'] == 1
        is_toc = slide_data['page_num'] == 2
        
        # 添加空白幻灯片
        slide_layout = prs.slide_layouts[6]  # 空白布局
        slide = prs.slides.add_slide(slide_layout)
        
        if is_cover:
            # 封面页
            # 提取封面信息
            title_text = slide_data['title']
            subtitle_text = ""
            date_text = ""
            
            for item in slide_data['content']:
                if item['type'] == 'subtitle':
                    if '标题' in item['text']:
                        title_text = item['text'].replace('标题：', '').replace('标题:', '').strip()
                    elif '副标题' in item['text']:
                        subtitle_text = item['text'].replace('副标题：', '').replace('副标题:', '').strip()
                    elif '日期' in item['text']:
                        date_text = item['text'].replace('日期：', '').replace('日期:', '').strip()
            
            # 添加标题
            title_box = slide.shapes.add_textbox(
                Inches(1), Inches(2.5), Inches(11.333), Inches(1)
            )
            tf = title_box.text_frame
            p = tf.paragraphs[0]
            p.text = title_text
            p.font.size = Pt(44)
            p.font.bold = True
            p.font.color.rgb = TITLE_COLOR
            p.alignment = PP_ALIGN.CENTER
            
            # 添加副标题
            if subtitle_text:
                subtitle_box = slide.shapes.add_textbox(
                    Inches(1), Inches(3.7), Inches(11.333), Inches(0.6)
                )
                tf = subtitle_box.text_frame
                p = tf.paragraphs[0]
                p.text = subtitle_text
                p.font.size = Pt(24)
                p.font.color.rgb = SUBTITLE_COLOR
                p.alignment = PP_ALIGN.CENTER
            
            # 添加日期
            if date_text:
                date_box = slide.shapes.add_textbox(
                    Inches(1), Inches(5.5), Inches(11.333), Inches(0.5)
                )
                tf = date_box.text_frame
                p = tf.paragraphs[0]
                p.text = date_text
                p.font.size = Pt(18)
                p.font.color.rgb = SUBTITLE_COLOR
                p.alignment = PP_ALIGN.CENTER
        
        else:
            # 内容页
            # 添加标题
            title_box = slide.shapes.add_textbox(
                Inches(0.5), Inches(0.3), Inches(12.333), Inches(0.8)
            )
            tf = title_box.text_frame
            p = tf.paragraphs[0]
            p.text = slide_data['title']
            p.font.size = Pt(32)
            p.font.bold = True
            p.font.color.rgb = TITLE_COLOR
            
            # 添加内容
            content_top = 1.3
            current_subtitle = None
            
            for item in slide_data['content']:
                if item['type'] == 'subtitle':
                    # 子标题
                    subtitle_box = slide.shapes.add_textbox(
                        Inches(0.5), Inches(content_top), Inches(12.333), Inches(0.5)
                    )
                    tf = subtitle_box.text_frame
                    p = tf.paragraphs[0]
                    p.text = item['text']
                    p.font.size = Pt(20)
                    p.font.bold = True
                    p.font.color.rgb = ACCENT_COLOR
                    content_top += 0.6
                    current_subtitle = item['text']
                
                elif item['type'] == 'list_item':
                    # 列表项
                    list_box = slide.shapes.add_textbox(
                        Inches(0.8), Inches(content_top), Inches(11.5), Inches(0.4)
                    )
                    tf = list_box.text_frame
                    p = tf.paragraphs[0]
                    p.text = "• " + item['text']
                    p.font.size = Pt(16)
                    p.font.color.rgb = SUBTITLE_COLOR
                    content_top += 0.35
                
                elif item['type'] == 'image_hint':
                    # 图片提示（不生成，只记录）
                    pass
            
            # 添加底部页码
            page_box = slide.shapes.add_textbox(
                Inches(12), Inches(7), Inches(1), Inches(0.3)
            )
            tf = page_box.text_frame
            p = tf.paragraphs[0]
            p.text = str(slide_data['page_num'])
            p.font.size = Pt(12)
            p.font.color.rgb = RGBColor(150, 150, 150)
            p.alignment = PP_ALIGN.RIGHT
    
    # 保存PPT
    prs.save(output_path)
    print(f"✓ PPT已生成: {output_path}")
    return output_path

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法: python create_ppt.py <大纲文件.md> [-o 输出文件.pptx]")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = "技术方案PPT.pptx"
    
    # 解析输出参数
    if '-o' in sys.argv:
        o_index = sys.argv.index('-o')
        if o_index + 1 < len(sys.argv):
            output_file = sys.argv[o_index + 1]
    
    # 检查输入文件
    if not Path(input_file).exists():
        print(f"错误: 文件不存在 - {input_file}")
        sys.exit(1)
    
    # 检查依赖
    if not check_dependencies():
        sys.exit(1)
    
    # 读取大纲
    with open(input_file, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    print(f"正在解析大纲: {input_file}")
    slides = parse_outline(md_content)
    print(f"解析到 {len(slides)} 页幻灯片")
    
    # 生成PPT
    print("正在生成PPT...")
    create_ppt(slides, output_file)

if __name__ == "__main__":
    main()
