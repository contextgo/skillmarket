---
name: hkex-filing-scraper
version: 1.0.0
description: |
  港交所（HKEx）披露易公告检索与下载工具。支持按股票代码、日期范围搜索公告，
  批量下载PDF/HTML文档，提取公告元数据（股票代码、公司名称、公告类型、发布日期等）。
  触发词：披露易、港交所公告、HKEX filing、HKEx公告下载、披露易搜索、
  港交所公告下载、港股公告、批量下载公告、HKEX search、披露易爬取
---

# HKEx Filing Scraper Skill

港交所（HKEx）披露易公告检索与下载工具，直接调用港交所未公开的 JSON API，
无需浏览器，速度快且稳定。

## 能力

1. **搜索公告**：按股票代码 + 日期范围搜索港交所披露易公告
2. **批量下载**：并行下载公告PDF/HTML文档到本地目录
3. **元数据导出**：输出结构化JSON或Excel（含超链接）
4. **公告分类**：自动识别公告类型（年报、中报、通函、公告等）

## 使用方式

调用 `scripts/hkex_scraper.py` 脚本：

```bash
# 搜索某只股票的公告（最近2个月）
python scripts/hkex_scraper.py search --stock 01748

# 搜索指定日期范围
python scripts/hkex_scraper.py search --stock 01748 --from 2024-01-01 --to 2024-12-31

# 搜索全市场公告（不指定股票代码）
python scripts/hkex_scraper.py search --from 2026-04-01 --to 2026-04-22

# 下载公告文档
python scripts/hkex_scraper.py download --stock 01748 --from 2026-01-01 --output ./pdfs

# 导出为Excel
python scripts/hkex_scraper.py search --stock 01748 --from 2025-01-01 --format xlsx --output 01748_filings.xlsx

# 限制返回数量
python scripts/hkex_scraper.py search --stock 01748 --limit 50
```

## 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `search` | 子命令：搜索公告元数据 | - |
| `download` | 子命令：搜索并下载文档 | - |
| `--stock` | 股票代码（5位数字，如01748） | 全市场 |
| `--from` | 起始日期（YYYY-MM-DD） | 2个月前 |
| `--to` | 结束日期（YYYY-MM-DD） | 今天 |
| `--limit` | 限制返回数量 | 0=不限 |
| `--format` | 输出格式：json/xlsx | json |
| `--output` | 输出文件路径 | stdout |
| `--workers` | 并行下载线程数 | 5 |

## 数据字段

每条公告包含以下字段：

- `stockCode`: 股票代码（如 01748）
- `stockName`: 公司简称
- `title`: 公告标题
- `date`: 发布日期
- `link`: 文档下载链接
- `fileType`: 文件类型（PDF/HTML/XLSX）
- `fileSize`: 文件大小
- `filingType`: 分类类型（ANNUAL_REPORT/RESULTS/CIRCULAR/NOTICE/OTHER）

## 技术原理

使用港交所披露易搜索页面的未公开 JSON API 端点：
- 搜索页面：`https://www1.hkexnews.hk/search/titlesearch.xhtml`
- JSON API：`https://www1.hkexnews.hk/search/titleSearchServlet.do`

该 API 支持：
- 按股票代码筛选
- 按日期范围查询
- 分页获取全部记录
- 无需浏览器，纯HTTP请求

## 审计场景示例

- 获取某港股客户特定期间的全部公告列表
- 批量下载年报、中报、通函用于审计底稿
- 检查某公司公告披露的及时性和完整性
- 对比不同期间的公告类型和数量变化
