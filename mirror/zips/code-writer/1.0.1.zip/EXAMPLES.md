# 小红书内容生成 - 完整示例

## 示例1: 技术知识点类 - Redis面试指南

### 输入
```
Redis面试知识点 小红书文案 1000字以内
```

### 输出文案
```markdown
# 🌐 Redis从入门到精通｜一张图讲透，面试直接套用！

**背完这张图，面试官以为我工作3年**

---

## 📌 一句话记住Redis

> Redis = **内存级key-value数据库**，**无状态**、**明文传输**，默认**80端口**

💡 记不住？想象：Redis是个"健忘的邮差"...

---

## 🔄 完整流程（5步搞定）

```
DNS解析 🔍 → TCP三次握手 🤝 → 发送请求 📤 → 收到响应 📥 → 四次挥手 👋
```

---

## 📤 请求长什么样？

| 部分 | 内容 | 例子 |
|------|------|------|
| 请求行 | 方法 + URL + 版本 | `GET /api/user HTTP/1.1` |
| 请求头 | 各种元信息 | `Host: xxx.com` |
| 空行 | 分隔符 | （就是空一行） |
| 请求体 | POST的数据 | `{"name":"张三"}` |

---

## 🔢 状态码速记（面试必考！）

| 类型 | 含义 | 常见码 |
|------|------|--------|
| 🟢 **2xx** | 成功 | 200 OK |
| 🟡 **3xx** | 重定向 | 301/302 |
| 🔴 **4xx** | 客户端错 | 400/401/403/404 |
| 🔴 **5xx** | 服务端错 | 500/502/503 |

💡 **口诀：2成功3跳转，4你错5我错**

---

## 🍪 Cookie/Session/Token 三者区别

| 技术 | 存哪 | 解决什么问题 |
|------|------|-------------|
| **Cookie** | 浏览器 🍪 | 存小数据，每次请求自动带 |
| **Session** | 服务器 📝 | 存用户状态 |
| **Token** | 客户端 🔑 | JWT无状态，现在主流 |

---

💬 **你面试被问过Redis吗？最刁钻的问题是什么？评论区交流！**
👉 觉得有用就收藏，面试前翻出来看一遍！

#Redis #计算机网络 #面试题 #后端开发 #编程入门
```

### AI配图提示词（单图完整版）
```
A hand-drawn doodle infographic on textured white paper with visible grain 
and coffee stains. A clean layout with Redis logo at center, six sections 
radiating outward like a mind map...

[完整提示词见PROMPTS.md]
```

---

## 示例2: 工具推荐类 - IDEA插件

### 输入
```
IDEA插件推荐 小红书文案
```

### 输出文案
```markdown
# 💻 用了3年还在更的IDEA插件｜Java开发直接抄作业！

**从菜鸟到架构师，这15个插件陪我走了3年**

---

## 🔥 先上必装4件套（不装等于白用IDEA）

**① Lombok** 🟢
- 省掉getter/setter/构造器，代码直接少一半
- 💡 **Java开发不装这个，等于用Word写代码**

**② Rainbow Brackets** 🌈
- 彩虹括号，嵌套代码一眼看清层级
- 💡 **回调地狱/Stream链式操作救星**

**③ Alibaba Java Coding Guidelines** ⚠️
- 阿里编码规范自动检查
- 💡 **代码审查前自己先扫一遍，少被骂**

**④ Key Promoter X** ⌨️
- 你点鼠标，它告诉你快捷键
- 💡 **坚持2周，快捷键肌肉记忆养成**

---

## 🚀 效率三剑客

**⑦ MyBatisX** 🔄
- Mapper接口↔XML一键跳转
- 💡 **告别Ctrl+Shift+F搜XML的日子**

**⑧ Maven Helper** 🌲
- 依赖树可视化，冲突一眼定位
- 💡 **"ClassNotFoundException"从此远离你**

**⑨ GenerateAllSetter** ⚡
- 一键生成对象set方法
- 💡 **写单元测试/赋值的时候，手速×10**

---

💬 **你还有什么私藏插件？评论区交换！**
👉 觉得有用就收藏，换电脑的时候翻出来对着装！

#IDEA #Java #程序员 #开发工具 #插件推荐
```

### AI配图提示词（九宫格）
```
A hand-drawn doodle showing 9 connected milestones along a timeline path...

[完整提示词见PROMPTS.md]
```

---

## 示例3: 避坑指南类 - Claude封号

### 输入
```
Claude封号避坑 小红书文案
```

### 输出文案
```markdown
# 🤖 Claude大规模封号｜程序员避坑指南速码⚠️

**作为天天和AI打交道的程序员，最近被Claude封号潮搞麻了😭**

---

## 🔍 封号两大重灾区

❶ **企业账号集体翻车**（4.18实测）
- Belo公司60+员工账号一夜全封
- 官方就甩一句"检测到自动化信号"
- 工作流被突然切断，每一分钟都是损耗！

❷ **个人实名验证=踩雷预警**
- 大陆是不支持地区，验证=自投罗网
- 和OpenAI同一家风控服务商Persona执行
- 验证完还是被封，纯属白费功夫

---

## ⚙️ 封号逻辑拆解

✅ **企业场景**：高并发、自动化调用容易被误判成异常
✅ **个人场景**：3个雷区别踩！
 1. 地域坑：大陆未开放，别瞎实名
 2. 验证坑：验完还是可能被封
 3. 工具坑：第三方插件必被封

---

## 💡 避坑四指南

❶ **多工具冗余**：Cursor + Copilot + GPT，别放一个篮子
❷ **拒绝实名验证**：控制调用频率，IP别乱切
❸ **本地备份**：Prompt、代码片段一定要本地存
❹ **替代方案**：日常用Cursor，复杂逻辑用Claude Code终端版

---

💬 **你的Claude还好吗？有没有被封的经历？评论区交流！**
👉 收藏这篇，封号前提前准备！

#程序员 #Claude封号 #AI工具避坑 #编程干货
```

### AI配图提示词（单图完整版）
```
A hand-drawn doodle infographic on textured white paper with red warning 
and green solution zones. A vertical flow layout from top to bottom...

[完整提示词见PROMPTS.md]
```

---

## 示例4: 单图完整版 - HTTP协议

### 输入
```
HTTP协议知识点 一张图
```

### 输出提示词
```
A hand-drawn doodle infographic on textured white paper with visible grain 
and coffee stains. A clean vertical flow layout from top to bottom showing 
HTTP concepts with rough sketch icons and handwritten Chinese labels...

[完整提示词见上文]
```

### 信息架构
```
TOP: HTTP是什么 → 内存key-value + 快vs慢
↓
MIDDLE LEFT: 三大优势 → 快/高并发/功能多
MIDDLE CENTER: 五大数据类型 → String/Hash/List/Set/ZSet
MIDDLE RIGHT: 持久化 → RDB快照 + AOF日志
↓
BOTTOM: 缓存三大问题 → 穿透/击穿/雪崩 + 解决方案
```

---

## 快速复制模板

### 技术知识点类
```
{主题} 小红书文案
{主题} AI配图 手绘涂鸦风
{主题} 一张图
```

### 工具推荐类
```
{工具名}推荐 小红书文案
{工具名} AI配图 九宫格
{工具名} 一张图
```

### 避坑指南类
```
{主题}避坑 小红书文案
{主题} AI配图
{主题} 一张图
```
