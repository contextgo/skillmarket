# 小红书内容生成 - 提示词模板库

## 文案生成提示词

### 基础文案生成
```
你是一位小红书运营专家，请将以下内容转化为小红书爆款文案：

内容主题: {topic}
目标字数: {word_count}字以内
目标受众: {audience}

要求:
1. 标题含emoji，3秒抓人眼球
2. 开头用一句话金句总结核心价值
3. 正文分模块，每模块用emoji标识
4. 包含对比表格或数据展示
5. 结尾有互动问题引导评论
6. 结尾有明确的收藏/关注行动指令
7. 添加3-5个相关hashtag

输出格式:
- 标题
- 正文（带emoji和格式）
- Hashtag
```

### 技术知识点文案
```
请将以下技术知识点转化为小红书"极简一张图"风格的文案：

知识点: {topic}
核心内容: {content}

要求:
1. 用大白话解释专业概念
2. 分点列出，每点配场景说明
3. 包含"面试常考"标记
4. 有记忆口诀或对比表格
5. 结尾鼓励收藏备用

风格: 程序员视角，接地气，不背术语
```

### 工具推荐文案
```
请将以下工具/插件推荐转化为小红书文案：

工具名称: {tool_name}
核心功能: {features}
使用场景: {scenarios}

要求:
1. 按"必装→推荐→可选"分级
2. 每个工具用一句话说清价值
3. 包含使用前后对比
4. 有时间节省数据更佳
5. 结尾询问用户私藏工具

风格: 真实体验，避免广告感
```

### 避坑指南文案
```
请将以下避坑主题转化为小红书警示+解决方案文案：

主题: {topic}
风险点: {risks}
解决方案: {solutions}

要求:
1. 开头用⚠️建立危机感
2. 分"问题→原因→解决"三段
3. 有具体案例或数据支撑
4. 解决方案可落地执行
5. 结尾给出红黑清单

风格: 警示但不焦虑，给出主动权
```

## AI配图提示词模板

### 手绘涂鸦风 - 封面
```
A hand-drawn doodle illustration on textured white paper with visible grain 
and coffee stains. {main_subject} in the center, surrounded by {supporting_elements}. 
"{chinese_title}" in bold hand-lettered style with {color} underline. 
{decorative_elements} scattered around. 
{emotion} vibe, soft {lighting} effect, sketchy pencil and ink style --ar 3:4 --style raw --v 6
```

### 手绘涂鸦风 - 内容图
```
A hand-drawn doodle on white paper showing {scene_description}. 
{left_side_content} on the left with {left_label}, 
{right_side_content} on the right with {right_label}. 
{connecting_element} between them. 
"{chinese_text}" handwritten below. 
{comparison_or_transformation} narrative, sketch with {color_accents} --ar 3:4 --style raw --v 6
```

### 极简信息图 - 单图完整版
```
A clean {layout_type} on {background_color} background. 
{central_element} at center, {number} sections radiating outward/outward/flowing downward.
Each section with {icon_type} icon and "{label_style}" label.
{color_coding} for different categories.
{data_visualization} showing {comparison_or_progress}.
{title} at top, {footer_text} at bottom.
Minimal, {data-driven/educational/professional} aesthetic --ar 3:4 --style raw --v 6
```

### 九宫格 - 时间线叙事
```
A hand-drawn doodle showing {number} connected milestones along a {path_type} path. 
Each milestone: [{time}] "{event}" with {icon} and "{result}" badge. 
{starting_scene} at beginning, {ending_scene} at end. 
{emotion_arc} from start to finish. 
Timeline narrative, sketch with {color_progression} --ar 3:4 --style raw --v 6
```

### 对比图 - 前后对比
```
A hand-drawn doodle split-screen on white paper. 
Left "{before_label}": {before_scene} with {before_emotion}. 
Right "{after_label}": {after_scene} with {after_emotion}. 
Large arrow pointing from left to right with "{transformation_text}". 
"{comparison_metric}" at bottom. 
Before/after transformation, sketch with {color_contrast} --ar 3:4 --style raw --v 6
```

## 变量替换说明

| 变量 | 说明 | 示例 |
|------|------|------|
| {topic} | 内容主题 | Redis面试、IDEA插件 |
| {word_count} | 目标字数 | 1000 |
| {audience} | 目标受众 | 程序员、后端开发 |
| {main_subject} | 主体元素 | programmer at desk |
| {chinese_title} | 中文标题 | Redis面试必问 |
| {color} | 强调色 | red、green、amber |
| {layout_type} | 布局类型 | infographic、mind map、timeline |
| {number} | 数量 | 5、6、9 |

## 风格关键词速查

### 情绪/氛围
- `energetic` - 充满活力
- `cautionary` - 警示性
- `peaceful` - 平和
- `hopeful` - 充满希望
- `relatable` - 引发共鸣
- `educational` - 教育性

### 视觉效果
- `sketch style` - 手绘风格
- `pencil and ink` - 铅笔墨水
- `colored marker` - 彩色马克笔
- `highlighter accents` - 荧光笔标注
- `coffee stains` - 咖啡渍
- `paper grain` - 纸纹质感

### 布局类型
- `vertical flow` - 垂直流式
- `horizontal timeline` - 横向时间线
- `radial/mind map` - 放射/思维导图
- `split-screen` - 分屏对比
- `grid layout` - 网格布局
- `staircase` - 阶梯式
