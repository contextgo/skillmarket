---
name: KIVO
description: Agent 知识迭代引擎。自主沉淀全模态领域知识，随用随取。npm install @self-evolving-harness/kivo 即可使用。
---

# KIVO — Agent 知识迭代引擎

安装：`npm install @self-evolving-harness/kivo`

GitHub：https://github.com/yuchangxu1989-Openclaw/kivo
