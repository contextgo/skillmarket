# 钉钉日报助手

> 自动化日报存取与周报生成 —— 支持单日记录、删除、周报汇总

## 功能
- 📝 `/report today <内容>`：记录今日日报
- 🗑️ `/report delete <YYYY-MM-DD>`：删除指定日期日报
- 🗑️ `/report delete all`：清空本人所有日报
- 📊 `/report weekly`：生成最近7天的周报摘要
- 📋 `/report list`：列出本人所有日报日期

## 权限
- 仅响应来自 **已认证用户**（通过钉钉 user_id 绑定）
- 数据按 `user_id` 隔离存储

