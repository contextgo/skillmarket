#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import json
import time
import datetime
from typing import Dict, List, Optional

# ===== 配置 =====
DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
os.makedirs(DATA_DIR, exist_ok=True)


def get_user_data_file(user_id: str) -> str:
    return os.path.join(DATA_DIR, f"{user_id}.json")


def load_reports(user_id: str) -> Dict[str, str]:
    path = get_user_data_file(user_id)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def save_reports(user_id: str, data: Dict[str, str]):
    path = get_user_data_file(user_id)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def today_str() -> str:
    return datetime.date.today().isoformat()


def parse_date_arg(arg: str) -> Optional[str]:
    if arg == 'all':
        return 'all'
    try:
        d = datetime.datetime.strptime(arg, '%Y-%m-%d').date()
        return d.isoformat()
    except ValueError:
        return None


def format_weekly_summary(reports: Dict[str, str]) -> str:
    dates = sorted(reports.keys(), reverse=True)
    recent = [d for d in dates if datetime.date.fromisoformat(d) >= datetime.date.today() - datetime.timedelta(days=6)]

    if not recent:
        return "⚠️ 近7天无日报记录。"

    lines = [f"📅 周报（{recent[0]} 至 {recent[-1]}）"]
    for d in recent:
        content = reports[d].strip()
        lines.append(f"• {d}: {content}")
    return "\n".join(lines)


# ===== 主处理函数 =====
def main(context: dict):
    user_id = context.get("user_id", "unknown")
    text = context.get("text", "").strip()
    channel = context.get("channel", "unknown")

    # 解析命令
    parts = text.split(maxsplit=2)
    if len(parts) < 2 or parts[0] != "/report":
        return {"reply": "请使用：`/report today <内容>` 或 `/report weekly` 等命令。"}

    cmd = parts[1]
    args = parts[2] if len(parts) > 2 else ""

    reports = load_reports(user_id)

    if cmd == "today":
        if not args:
            return {"reply": "❌ 请提供日报内容，例如：`/report today 完成任务A`"}
        reports[today_str()] = args
        save_reports(user_id, reports)
        return {"reply": f"✅ 已保存今日日报：\n>{args}"}

    elif cmd == "delete":
        target = parse_date_arg(args)
        if target is None:
            return {"reply": "❌ 日期格式错误，请用 YYYY-MM-DD 或 'all'"}

        if target == "all":
            reports.clear()
            save_reports(user_id, reports)
            return {"reply": "🗑️ 已清空您所有日报。"}
        else:
            if target in reports:
                del reports[target]
                save_reports(user_id, reports)
                return {"reply": f"🗑️ 已删除 {target} 的日报。"}
            else:
                return {"reply": f"ℹ️ {target} 无日报记录。"}

    elif cmd == "weekly":
        reply = format_weekly_summary(reports)
        return {"reply": reply}

    elif cmd == "list":
        if not reports:
            return {"reply": "📋 您暂无日报记录。"}
        dates = sorted(reports.keys(), reverse=True)
        items = [f"• {d}: {reports[d][:40]}{'...' if len(reports[d]) > 40 else ''}" for d in dates]
        return {"reply": "📌 您的日报记录：\n" + "\n".join(items[:10]) + (
            "\n...（共 {} 条）".format(len(dates)) if len(dates) > 10 else "")}

    else:
        return {"reply": "❌ 不支持的命令。可用：`today`, `delete`, `weekly`, `list`"}


# 供 OpenClaw 调用的入口
if __name__ == "__main__":
    # 测试用（非必须）
    pass