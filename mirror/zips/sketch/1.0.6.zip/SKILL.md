---
name: sketch
version: "2.0.0"
author: BytesAgain
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
license: MIT-0
tags: [sketch, tool, utility]
description: "Draw ASCII diagrams, flowcharts, and wireframes with box drawing. Use when sketching architecture, previewing wireframes, generating charts, exporting images."
---

# Sketch

Design toolkit for managing color palettes, previews, gradients, swatches, and more. Each command logs entries with timestamps and lets you review past entries, search history, view statistics, and export data in multiple formats.

## Commands

| Command | Description |
|---------|-------------|
| `sketch palette <input>` | Log a palette entry (or view recent palette entries with no args) |
| `sketch preview <input>` | Log a preview entry (or view recent preview entries with no args) |
| `sketch generate <input>` | Log a generate entry (or view recent entries with no args) |
| `sketch convert <input>` | Log a convert entry (or view recent entries with no args) |
| `sketch harmonize <input>` | Log a harmonize entry (or view recent entries with no args) |
| `sketch contrast <input>` | Log a contrast entry (or view recent entries with no args) |
| `sketch export <input>` | Log an export entry (or view recent entries with no args) |
| `sketch random <input>` | Log a random entry (or view recent entries with no args) |
| `sketch browse <input>` | Log a browse entry (or view recent entries with no args) |
| `sketch mix <input>` | Log a mix entry (or view recent entries with no args) |
| `sketch gradient <input>` | Log a gradient entry (or view recent entries with no args) |
| `sketch swatch <input>` | Log a swatch entry (or view recent entries with no args) |
| `sketch stats` | Show summary statistics across all log categories |
| `sketch export <fmt>` | Export all data to json, csv, or txt format |
| `sketch search <term>` | Search across all log files for a term |
| `sketch recent` | Show the 20 most recent history entries |
| `sketch status` | Health check: version, data dir, entry count, disk usage, last activity |
| `sketch help` | Show help with all available commands |
| `sketch version` | Show version number |

## How It Works

Each design command (palette, preview, generate, convert, etc.) works in two modes:

- **With arguments**: Saves the input with a timestamp to a dedicated `.log` file and displays the total entry count
- **Without arguments**: Shows the 20 most recent entries from that category's log file

All actions are also recorded in a central `history.log` for unified tracking.

## Data Storage

All data is stored in `~/.local/share/sketch/`. The directory contains:

- `palette.log`, `preview.log`, `generate.log`, etc. — one log file per command category
- `history.log` — central log of all actions with timestamps
- `export.json`, `export.csv`, `export.txt` — generated export files

The tool automatically creates the data directory on first run.

## Requirements

- **Shell**: Bash 4+
- **No external dependencies** — uses only standard Unix utilities (`date`, `wc`, `du`, `grep`, `tail`, `head`)

## When to Use

1. **Tracking color palette decisions** — Log and review palette choices across a design project with `sketch palette "#FF5733 warm accent"`
2. **Previewing and iterating on designs** — Record preview notes with `sketch preview "homepage v2 layout"` to maintain a design history
3. **Mixing and harmonizing colors** — Use `sketch mix` and `sketch harmonize` to log color combination experiments
4. **Generating design assets** — Track generated assets with `sketch generate "icon set 48px"` for an auditable creation log
5. **Reviewing design history** — Run `sketch stats` or `sketch recent` to see activity summaries across all categories

## Examples

```bash
# Log a new palette entry
sketch palette "#2E86AB ocean blue, #A23B72 plum"

# View recent palette entries
sketch palette

# Log a gradient experiment
sketch gradient "linear #000 to #FFF 5 stops"

# Mix two colors
sketch mix "#FF0000 + #0000FF = purple blend"

# Check contrast
sketch contrast "foreground #333 on background #FFF"

# View overall statistics
sketch stats

# Export all data as JSON
sketch export json

# Search for a specific term across all logs
sketch search "blue"

# View the 20 most recent actions
sketch recent

# Health check
sketch status
```

## Export Formats

The `export` command supports three formats:

- **json** — Array of objects with `type`, `time`, and `value` fields
- **csv** — Comma-separated with `type,time,value` header
- **txt** — Plain text grouped by category

Export files are saved to the data directory and the output shows the file path and size.

## Output

All command output goes to stdout in plain text. Use shell redirection to save: `sketch stats > report.txt`

---
Powered by BytesAgain | bytesagain.com | hello@bytesagain.com
