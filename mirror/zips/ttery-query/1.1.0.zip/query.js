/**
 * 彩票查询技能 - 主脚本
 * 查询双色球和大乐透近 10 期开奖结果，并推荐号码
 * 数据来源：中国福利彩票官网、中国体育彩票官网、百度搜索（缓存数据）
 * v1.1.0: 优化数据源优先级，优先使用缓存数据（百度搜索校正后）
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// 检查是否有 Playwright 可用
let playwright = null;
try {
    // 优先尝试本地安装
    playwright = require('playwright');
} catch (e) {
    try {
        // 尝试全局安装
        playwright = require('C:/Users/Administrator/AppData/Roaming/npm/node_modules/playwright');
    } catch (e2) {
        // Playwright 未安装，使用备用方案
    }
}

// 官网 URL
const SSQ_URL = 'https://www.cwl.gov.cn/ygkj/wqkjgg/ssq/';
const DLT_URL = 'https://www.lottery.gov.cn/kj/kjlb.html?dlt';

// API 源列表（备用）
const SSQ_APIS = [
    'http://kaijiang.zhtong.cn/ssq.json',
    'https://m.zhtong.cn/api/v2/lottery/ssq.json',
];

const DLT_APIS = [
    'http://kaijiang.zhtong.cn/dlt.json',
    'https://m.zhtong.cn/api/v2/lottery/dlt.json',
    'https://api.zhtong.cn/api/v2/lottery/dlt.json',
];

// 缓存文件路径
const CACHE_FILE = path.join(__dirname, 'cache.json');

/**
 * 抓取网页内容
 */
function fetchHTML(url, timeout = 10000) {
    return new Promise((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        const options = {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            }
        };
        
        const req = client.get(url, options, (res) => {
            if (res.statusCode !== 200) {
                reject(new Error(`HTTP ${res.statusCode}`));
                return;
            }
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => resolve(data));
        }).on('error', reject);
        
        req.setTimeout(timeout, () => {
            req.destroy();
            reject(new Error('请求超时'));
        });
    });
}

/**
 * 解析双色球 HTML 提取开奖数据
 */
function parseSSQHTML(html) {
    const results = [];
    
    // 匹配包含期号的 tr 行
    const trRegex = /<tr[^>]*><td>(\d{6,8})<\/td><td>([\d-]+)[^(]+\(([^)]+)\)<\/td><td><div class="qiu">(.*?)<\/div><\/td>/gs;
    let match;
    
    while ((match = trRegex.exec(html)) !== null && results.length < 10) {
        const expect = match[1];
        const ballsHtml = match[4];
        
        // 提取红球和蓝球号码
        const redBalls = [];
        let blueBall = '';
        
        const ballRegex = /qiu-item-wqgg-zjhm-red[^>]*>(\d+)<\/div>|qiu-item-wqgg-zjhm-blue[^>]*>(\d+)<\/div>/g;
        let ballMatch;
        
        while ((ballMatch = ballRegex.exec(ballsHtml)) !== null) {
            if (ballMatch[1]) {
                redBalls.push(ballMatch[1].padStart(2, '0'));
            } else if (ballMatch[2]) {
                blueBall = ballMatch[2].padStart(2, '0');
            }
        }
        
        if (redBalls.length === 6 && blueBall) {
            results.push({
                expect: expect,
                red: redBalls.join(' '),
                blue: blueBall
            });
        }
    }
    
    return results;
}

/**
 * 解析大乐透 HTML 提取开奖数据
 */
function parseDLTHTML(html) {
    const results = [];
    
    // 大乐透官网是动态加载，尝试从 JSON 或 script 标签中提取数据
    // 查找 JSON 数据
    const jsonMatch = html.match(/"list"\s*:\s*(\[.*?\])/s);
    if (jsonMatch) {
        try {
            const list = JSON.parse(jsonMatch[1]);
            for (const item of list.slice(0, 10)) {
                if (item.expect && item.red && item.blue) {
                    results.push({
                        expect: item.expect,
                        red: item.red,
                        blue: item.blue
                    });
                }
            }
        } catch (e) {
            // JSON 解析失败
        }
    }
    
    // 如果 JSON 提取失败，尝试 HTML 解析
    if (results.length === 0) {
        const trRegex = /<tr[^>]*><td>(\d{6,8})<\/td>.*?<td>([\d-]+).*?<\/td>.*?<td>.*?(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+).*?(\d+)\s+(\d+)/gs;
        let match;
        
        while ((match = trRegex.exec(html)) !== null && results.length < 10) {
            results.push({
                expect: match[1],
                red: `${match[3]} ${match[4]} ${match[5]} ${match[6]} ${match[7]}`,
                blue: `${match[8]} ${match[9]}`
            });
        }
    }
    
    return results;
}

/**
 * 使用 Playwright 浏览器自动化抓取官网数据
 */
async function fetchWithPlaywright(url, parseFunc, type) {
    if (!playwright) {
        throw new Error('Playwright 未安装');
    }
    
    // 使用 Edge 浏览器
    const browser = await playwright.chromium.launch({
        headless: true,
        channel: 'msedge',
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    try {
        const context = await browser.newContext();
        const page = await context.newPage();
        
        // 访问页面，等待加载
        await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
        
        // 等待开奖列表加载
        await page.waitForTimeout(3000);
        
        // 获取页面内容
        const content = await page.content();
        const results = parseFunc(content);
        
        await browser.close();
        
        if (results.length > 0) {
            return {
                success: true,
                data: {
                    info: results[0],
                    list: results
                },
                source: 'official'
            };
        }
        
        throw new Error('解析失败');
    } catch (e) {
        await browser.close().catch(() => {});
        throw e;
    }
}

/**
 * 从官网获取开奖数据（优先浏览器自动化，失败后用简单 HTTP）
 */
async function fetchFromOfficial(type) {
    const url = type === 'ssq' ? SSQ_URL : DLT_URL;
    const parseFunc = type === 'ssq' ? parseSSQHTML : parseDLTHTML;
    
    // 1. 优先尝试浏览器自动化
    if (playwright) {
        try {
            return await fetchWithPlaywright(url, parseFunc, type);
        } catch (e) {
            console.error(`浏览器抓取失败：${e.message}`);
        }
    }
    
    // 2. 浏览器不可用时，尝试简单 HTTP 请求
    try {
        const html = await fetchHTML(url, 10000);
        const results = parseFunc(html);
        
        if (results.length > 0) {
            return {
                success: true,
                data: {
                    info: results[0],
                    list: results
                },
                source: 'official'
            };
        }
    } catch (e) {
        // HTTP 请求也失败
    }
    
    return { success: false, error: '官网抓取失败' };
}

/**
 * 生成双色球随机号码
 */
function generateSSQNumbers() {
    const redBalls = new Set();
    while (redBalls.size < 6) {
        redBalls.add(Math.floor(Math.random() * 33) + 1);
    }
    const blueBall = Math.floor(Math.random() * 16) + 1;
    
    const reds = Array.from(redBalls).sort((a, b) => a - b).map(n => n.toString().padStart(2, '0'));
    const blue = blueBall.toString().padStart(2, '0');
    
    return `${reds.join(' ')} + ${blue}`;
}

/**
 * 生成大乐透随机号码
 */
function generateDLTNumbers() {
    const frontBalls = new Set();
    while (frontBalls.size < 5) {
        frontBalls.add(Math.floor(Math.random() * 35) + 1);
    }
    const backBalls = new Set();
    while (backBalls.size < 2) {
        backBalls.add(Math.floor(Math.random() * 12) + 1);
    }
    
    const fronts = Array.from(frontBalls).sort((a, b) => a - b).map(n => n.toString().padStart(2, '0'));
    const backs = Array.from(backBalls).sort((a, b) => a - b).map(n => n.toString().padStart(2, '0'));
    
    return `${fronts.join(' ')} + ${backs.join(' ')}`;
}

/**
 * HTTP 请求（带超时）
 */
function fetchJSON(url, timeout = 3000) {
    return new Promise((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        const req = client.get(url, (res) => {
            if (res.statusCode !== 200) {
                reject(new Error(`HTTP ${res.statusCode}`));
                return;
            }
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch (e) {
                    reject(new Error('JSON 解析失败'));
                }
            });
        }).on('error', reject);
        
        req.setTimeout(timeout, () => {
            req.destroy();
            reject(new Error('请求超时'));
        });
    });
}

/**
 * 尝试多个 API 源
 */
async function fetchLotteryData(apis) {
    for (const api of apis) {
        try {
            const data = await fetchJSON(api, 3000);
            if (data && data.info) {
                return { success: true, data, source: 'api' };
            }
        } catch (e) {
            continue;
        }
    }
    return { success: false, error: 'API 不可用' };
}

/**
 * 获取开奖数据（优先缓存，失败后用官网/浏览器）
 * v1.1.0: 调整优先级为缓存 > 官网 > API
 */
async function getLotteryData(type) {
    // 1. 优先使用缓存数据（百度搜索校正后，数据更准确）
    const cacheResult = loadCache(type);
    if (cacheResult.success) {
        return cacheResult;
    }
    
    // 2. 缓存不可用，尝试官网
    const officialResult = await fetchFromOfficial(type);
    if (officialResult.success) {
        return officialResult;
    }
    
    // 3. 官网失败，尝试备用 API
    const apis = type === 'ssq' ? SSQ_APIS : DLT_APIS;
    const apiResult = await fetchLotteryData(apis);
    if (apiResult.success) {
        return apiResult;
    }
    
    // 4. 都失败，返回缓存错误
    return { success: false, error: '所有数据源不可用' };
}

/**
 * 加载缓存数据
 */
function loadCache(type) {
    try {
        if (fs.existsSync(CACHE_FILE)) {
            const cache = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
            if (type === 'ssq' && cache.ssq) {
                return { success: true, data: cache.ssq, source: 'cache' };
            }
            if (type === 'dlt' && cache.dlt) {
                return { success: true, data: cache.dlt, source: 'cache' };
            }
        }
    } catch (e) {
        // 忽略缓存加载错误
    }
    return { success: false, error: '无缓存数据' };
}

/**
 * 格式化双色球结果
 */
function formatSSQResult(result) {
    let output = '🔴 **双色球 - 近 10 期开奖结果**\n\n';
    
    if (result.success && result.data) {
        const { info, list } = result.data;
        let sourceTag = '';
        if (result.source === 'official') sourceTag = '（数据来源：福彩官网）';
        else if (result.source === 'cache') sourceTag = '（缓存数据）';
        
        output += `最新期号：第${info.expect}期${sourceTag}\n`;
        output += `开奖号码：${info.red} + ${info.blue}\n\n`;
        output += '━━━━━━━━━━━━━━━━━━\n\n';
        
        (list || []).slice(0, 10).forEach((item, index) => {
            output += `${index + 1}. 第${item.expect}期：${item.red} + ${item.blue}\n`;
        });
    } else {
        output += '⚠️ 未能获取最新开奖数据\n';
        output += '建议访问福彩官网：https://www.cwl.gov.cn/ygkj/wqkjgg/ssq/\n\n';
    }
    
    output += '\n━━━━━━━━━━━━━━━━━━\n\n';
    output += '🎯 **推荐号码（2 注）**\n\n';
    output += `① ${generateSSQNumbers()}\n`;
    output += `② ${generateSSQNumbers()}\n\n`;
    output += '⚠️ 仅供娱乐参考，理性购彩';
    
    return output;
}

/**
 * 格式化大乐透结果
 */
function formatDLTResult(result) {
    let output = '🔵 **大乐透 - 近 10 期开奖结果**\n\n';
    
    if (result.success && result.data) {
        const { info, list } = result.data;
        let sourceTag = '';
        if (result.source === 'official') sourceTag = '（数据来源：体彩官网）';
        else if (result.source === 'cache') sourceTag = '（缓存数据）';
        
        output += `最新期号：第${info.expect}期${sourceTag}\n`;
        output += `开奖号码：${info.red} + ${info.blue}\n\n`;
        output += '━━━━━━━━━━━━━━━━━━\n\n';
        
        (list || []).slice(0, 10).forEach((item, index) => {
            output += `${index + 1}. 第${item.expect}期：${item.red} + ${item.blue}\n`;
        });
    } else {
        output += '⚠️ 未能获取最新开奖数据\n';
        output += '建议访问体彩官网：https://www.lottery.gov.cn/kj/kjlb.html?dlt\n\n';
    }
    
    output += '\n━━━━━━━━━━━━━━━━━━\n\n';
    output += '🎯 **推荐号码（2 注）**\n\n';
    output += `① ${generateDLTNumbers()}\n`;
    output += `② ${generateDLTNumbers()}\n\n`;
    output += '⚠️ 仅供娱乐参考，理性购彩';
    
    return output;
}

/**
 * 检查并安装 Playwright
 */
function ensurePlaywright() {
    if (playwright) {
        return true;
    }
    
    console.log('⚠️ Playwright 未安装，尝试自动安装...');
    
    try {
        // 安装 Playwright
        execSync('npm install -g playwright', { stdio: 'ignore' });
        execSync('npx playwright install chromium', { stdio: 'ignore' });
        
        // 重新加载 Playwright
        playwright = require('playwright');
        console.log('✅ Playwright 安装成功');
        return true;
    } catch (e) {
        console.log('⚠️ Playwright 安装失败，将使用备用数据源');
        return false;
    }
}

/**
 * 主函数
 */
async function main() {
    const query = process.argv[2] || '';
    
    if (!query) {
        console.log('请指定查询类型：双色球 或 大乐透');
        process.exit(1);
    }
    
    // 确保 Playwright 已安装
    ensurePlaywright();
    
    let result;
    if (query.includes('双色球')) {
        result = await getLotteryData('ssq');
        console.log(formatSSQResult(result));
    } else if (query.includes('大乐透')) {
        result = await getLotteryData('dlt');
        console.log(formatDLTResult(result));
    } else {
        console.log('未识别的彩票类型，请查询"双色球"或"大乐透"');
    }
}

main();
