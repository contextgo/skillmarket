---
name: self-evolving-core
version: "4.5.4"
description: >
  Agent自进化能力v4.5.4 — 让AI同一个坑只踩一次。
  自动记账+阈值检测+经验积累+免疫规则，开箱即用。
trigger_words:
  - 安装self-evolving
  - 部署自进化
  - 初始化自进化
  - 帮我配置自进化
  - 启用自进化
  - AI记忆系统
  - agent记忆
  - 团队记忆
  - 让ai记住
  - 让agent记住
  - 避免重复踩坑
  - 经验积累
  - 自我学习
  - 自我进化
  - memory管理
  - memory超限
  - 记忆蒸馏
  - distill
  - MEMORY.md
  - 短期记忆
  - 记忆归档
  - 自进化
  - 记忆系统
  - 经验存储
  - 持续学习
  - 经验复用
  - evolution_guardian
  - 免疫系统
  - 复盘
  - 进化引擎
  - 一键部署
  - domain模式
  - 大一统架构
  - 领域路由
metadata: {"clawdbot":{"emoji":"🧬","requires":{"python":">=3.8","packages":[]},"version":"4.5.4","deployable":true,"core_script":"evolution_guardian.py","one_command_deploy":"--deploy","architecture":"dual-mode-c"}}
---

# 🧬 Self-Evolving-Core v4.5.4 — Agent自进化能力

> 让Agent拥有"同一个坑只踩一次"的记忆力。每次任务后自动记账+阈值检测+经验沉淀，零人工干预。

---

## ⚡ 30秒上手

**3条铁律，记住就行**：

```
① 安装：python3 {SKILL_PATH}/scripts/upgrade_agent.py --deploy
   → 一键完成：识别架构 + 创建域 + 注入触发钩子 + 整理MEMORY.md

② 每次任务结束 → log：
   python3 domains/_shared/evolution_guardian.py log <domain> "<任务>" <success|failed|partial>
   失败时加教训：--lesson="踩坑原因"

③ 每天结束 → distill 三段式（不可跳步）：
   distill --from-daily   # 日志→STM
   distill --from-stm     # STM→MEMORY.md
   distill                # 仅应急：MEMORY超150行
```

> 💡 域名填错？系统自动提示可用域列表。该不该log？**永远log**——这是自动进化的唯一入口。

---

## 1. 核心概念

### 1.1 工作流闭环

```
用户给任务 → Router路由(角色+经验+免疫警告) → AI执行 → log记账(自动检测R1-R4)
```

- **Router**自动完成：领域分类、经验检索、免疫预检
- **log**自动完成：记账、统计、阈值检测、输出行动指令
- AI只需：**执行任务 + 执行log + 看到指令就响应**

### 1.2 四条进化规则（log自动检测）

| 规则 | 触发条件 | 输出 | 要求 |
|------|---------|------|------|
| **R1** | 每**3次**任务 | 📊 review指令 | 当轮执行review |
| **R2** | 同类连续失败**≥2次** | 🔴 CRITICAL | 立即提取免疫规则 |
| **R3** | **≥1条**负面反馈 | ⚠️ CRITICAL | 分析根因修正策略 |
| **R4** | MEMORY.md**>150行** | 📋 distill指令 | 运行distill蒸馏 |

> 阈值在 `evo-config.json` → `trigger_config` 中可调。AI无需记忆阈值，看到指令就执行。

### 1.3 四层记忆

| 层级 | 存什么 | 位置 |
|------|--------|------|
| L1 陈述性 | URL、配置、命名规则 | experiences.json |
| L2 程序性⭐ | 已验证步骤、最佳实践 | experiences.json |
| L3 语义 | 错误模式、根因链 | experiences.json |
| L4 工作 | 当前会话验证的方法 | l4-memory.json(临时) |

### 1.4 免疫规则

从历史错误中提取的P0级避坑指令，Router每次任务前**自动预检**：

| 级别 | 含义 | 行为 |
|------|------|------|
| 🔴 critical | 绝对红线 | 必须先确认再行动 |
| 🟡 warning | 强烈建议避免 | 有意识绕开 |
| 🔵 info | 参考建议 | 可选优化 |

---

## 2. 命令参考

所有命令入口：`python3 domains/_shared/evolution_guardian.py <command>`

### 2.1 log — 任务记账（每次必做）

```bash
log <domain> "<task>" <success|failed|partial> [error_type] [error_category] [tokens] [duration_sec]

# 示例
log data "数据清洗10万行" success
log data "API调用超时" failed timeout "API调用" 62000 120
log data "API调用" failed timeout API --lesson="需要加retry机制"
```

| 参数 | 必填 | 说明 |
|------|------|------|
| domain | ✅ | 域名（deploy时生成，check可查） |
| task | ✅ | 任务简述 |
| result | ✅ | success / failed / partial |
| error_type | ❌ | 失败时填：tool_failed / timeout / empty_result |
| error_category | ❌ | 错误分类 |
| tokens | ❌ | Token消耗估算 |
| duration_sec | ❌ | 耗时秒数 |
| --lesson | ❌ | 失败教训→自动写experiences+immune_rules |

### 2.2 check — 域诊断

```bash
check <domain>    # 多维诊断报告
```

### 2.3 review — 复盘

```bash
review <domain>   # 模式链检测+免疫规则生成
```

### 2.4 evolve — 深度进化

```bash
evolve <domain> "原因描述"    # 清理过时规则+深度学习
```

### 2.5 feedback — 记录负面反馈

```bash
feedback admin negative <strong|medium|mild> "<触发词>" "<上下文>"
```

### 2.6 distill — 三段式蒸馏

```bash
# 第一步：每日日志→STM（每天做）
distill --from-daily
distill --from-daily --date=2026-05-01

# 第二步：STM→MEMORY.md（STM积累>20行时）
distill --from-stm
distill --from-stm --dry-run

# 第三步（仅应急）：MEMORY.md→experiences.json
distill --dry-run    # 先预览
distill
```

### 2.7 archive-logs — 日志归档

```bash
archive-logs              # 默认15天
archive-logs --days=30    # 自定义
```

### 2.8 experience-update — 经验生命周期

```bash
experience-update <domain> <id> <deprecate|supersede> [new_id]
```

---

## 3. 目录结构

```
项目根目录/
├── domains/                        ← 核心目录
│   ├── _shared/                   ← 全局共享
│   │   ├── evo-config.json       ← 全局配置（阈值/域注册）
│   │   ├── evo-feedback.json     ← 反馈记录
│   │   ├── evolution_guardian.py ← 统一入口脚本
│   │   ├── domain_router.py     ← 领域路由引擎
│   │   └── admin-experiences.json← 跨域共享经验
│   │
│   └── <域名>/                    ← 每域一个（deploy自动推断生成）
│       ├── experiences.json      ← 经验库
│       ├── memory.json           ← 统计数据
│       ├── immune_rules.json     ← 免疫规则
│       └── evolution.log         ← 进化日志
│
├── .workbuddy/memory/              ← 工作记忆
│   ├── MEMORY.md                  ← 长期元层（<150行）
│   ├── short-term-memory.md       ← 短期缓冲
│   ├── YYYY-MM-DD.md              ← 每日日志
│   └── archive/                   ← 归档（>15天）
│
└── workspace/.tmp/l4-memory.json   ← Session临时记忆
```

---

## 4. 记忆管理详解

### 4.1 三段式蒸馏流程

```
每日日志 → distill --from-daily → STM新内容区
  → distill --from-stm → MEMORY.md(PINNED区之后)
  → distill(仅应急) → experiences.json
```

**关键原则**：
- 每日日志→STM 是唯一常规入口
- MEMORY.md 顶部 `PINNED_SECTION_END` 以上内容永不被蒸馏
- 全量重写用三步安全写入（防崩溃丢数据）

### 4.2 STM机制

```
# 短期记忆
[新内容区] ← AI写到这里（顶部）
[新内容区]
<!-- STM_BOUNDARY: 上次提炼 2026-05-01 --> ← 分界线
[已蒸馏区] ← 历史留档，不读取
```

- 只读分界线以上内容（节省Token）
- 提炼后清空新区、更新时间戳
- 历史区留档可回滚

### 4.3 MEMORY.md 置顶保护区

```markdown
# 长期记忆
<!-- PINNED_SECTION: 核心规范，永不蒸馏 -->
## 🔴 绝对规则...
<!-- PINNED_SECTION_END -->
---
## 📌 可被蒸馏的内容...
```

### 4.4 触发时机

| 场景 | 操作 |
|------|------|
| 每日工作结束 | `distill --from-daily` |
| STM>20行 | `distill --from-stm` |
| R4触发(MEMORY>150行) | `distill --dry-run` 预览后执行 |
| 每月维护 | `archive-logs` |

---

## 5. 部署

### 5.1 一键部署

```bash
python3 {SKILL_PATH}/scripts/upgrade_agent.py --deploy [--root <目录>] [--yes]
```

自动执行：
1. 检测工作空间架构（全新/已有域/已有agents）
2. 创建 `domains/` + 推断域目录
3. 注入 IDENTITY.md/SOUL.md 触发钩子
4. 整理 MEMORY.md（补全配置段、检查行数）
5. 端到端验证

### 5.2 从多Agent迁移

```bash
python3 {SKILL_PATH}/scripts/upgrade_agent.py --migrate-to-domain [--root <目录>] [--yes]
```

自动分析Agent的IDENTITY.md推断映射关系，agents/目录保留不删。

---

## 6. 配置参考

`domains/_shared/evo-config.json` → `trigger_config`：

```json
{
  "consecutive_error_threshold": 2,
  "review_every_n_tasks": 3,
  "negative_feedback_threshold": 1,
  "memory_line_threshold": 150,
  "stm_distill_threshold": 20,
  "log_archive_days": 15
}
```

---

## 7. 禁止行为

- ❌ 不执行log记账
- ❌ 连续使用失败方法超过2次
- ❌ 忽略log输出的🔴/📊/⚠️行动指令
- ❌ 数据类任务编撰/默认填充值（查不到→置空Null）

---

## 8. FAQ

| 问题 | 解决 |
|------|------|
| log报目录不存在 | 检查是否已deploy |
| check显示immune_rules缺失 | 跑一次 `review <domain>` |
| Router返回null域 | 用默认身份执行，经验使用中积累 |
| MEMORY.md超限 | `distill --dry-run` 预览后执行 |
| distill后内容丢失 | 检查文件标记，重新运行distill恢复 |
| 域名填错 | 系统自动提示可用域列表+修复建议 |

---

## 9. 版本历史

| 版本 | 核心变更 |
|------|---------|
| **v4.5.4** | 钩子触发条件扩展为14类具体动作+豁免清单；Router输出末尾追加结构化收尾任务块 |
| **v4.5.3** | 未知域名校验+可用域提示；SKILL.md加TL;DR；trigger_words补强 |
| **v4.5.2** | 全面净化（零项目污染）；E2E验证通过 |
| **v4.5.1** | deploy自动注入钩子（修复R1-R4不触发根因）；log新增--lesson参数 |
| **v4.5** | 三段式蒸馏固化；MEMORY.md置顶保护区；STM分区隔离 |
| **v4.4** | MEMORY.md生命周期治理；安全写入；日志归档 |
| v4.2 | 经验生命周期(active/deprecated/superseded) |
| v4.1 | log内置阈值自检引擎(R1-R4) |
| v4.0 | Domain大一统架构；Router内嵌检索 |

---

*"好的Agent不是不犯错，而是同一个坑只踩一次。"*
