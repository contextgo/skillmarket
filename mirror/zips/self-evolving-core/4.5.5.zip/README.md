# 🧬 Self-Evolving-Core v4.5.4

> Agent 自进化能力：从任务经验中自动积累知识，同类问题只踩一次坑。
> v4.5 新增三段式记忆蒸馏流程 + MEMORY.md 置顶保护 + STM 顶部写入分区隔离。

**版本**: 4.5.4 | **依赖**: Python ≥3.8（无第三方包）

---

**→ 使用指南请看 [GUIDE.md](GUIDE.md)**（精简版，5分钟读完）

**→ 完整协议规范请看 [SKILL.md](SKILL.md)**（Agent执行规范）

---

## 核心文件

| 文件 | 用途 |
|------|------|
| `GUIDE.md` | ★ 快速上手指南（推荐先读） |
| `SKILL.md` | Agent行为规范（完整版） |
| `scripts/upgrade_agent.py` | 部署/检测/迁移工具（v4.4: 新增_audit_and_fix_memory） |
| `scripts/domain_router.py` | 任务前路由（部署后复制到用户项目） |
| `scripts/evolution_guardian.py` | 任务后记账+进化检测+三段式蒸馏（部署后复制） |

## 一键部署

```bash
python3 scripts/upgrade_agent.py --deploy
```

自动分析工作空间 → 推断业务领域 → 初始化域目录 → 整理MEMORY.md规则 → 部署核心脚本。

## ★ 三段式蒸馏流程（v4.5 核心）

```
每日日志 → distill --from-daily → STM → distill --from-stm → MEMORY.md
                                                               ↓ 仅超限应急
                                                        experiences.json
```

```bash
# 每日结束时（常规必做）
python3 domains/_shared/evolution_guardian.py distill --from-daily

# STM有积累时
python3 domains/_shared/evolution_guardian.py distill --from-stm

# 仅MEMORY.md超150行时（应急）
python3 domains/_shared/evolution_guardian.py distill
```
