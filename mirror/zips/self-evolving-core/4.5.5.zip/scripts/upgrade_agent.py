#!/usr/bin/env python3
"""
架构部署/升级/检测工具 — Self-Evolving-Core v4.0

功能:
  --deploy            : ★ 全自动部署模式（首次启用必用，v4.0自动检测架构）
  --detect            : ★ v4.0新增 架构智能检测（判断用户应使用Domain还是Agent模式）
  --migrate-to-domain : ★ v4.0新增 从多Agent迁移到Domain架构
  --check             : 检测单个agent是否需要升级
  --upgrade           : 升级单个agent

★ v4.0 核心变更 — 方案C双模架构：
  - 新增架构自动检测：启用时自动识别用户环境（Domain/Agent/全新）
  - Domain模式优先：--deploy 自动初始化 domains/ 目录结构
  - 向后兼容：保留完整的多Agent能力作为Legacy附录

用法:
  # ★ 架构检测（v4.0推荐首先执行）
  python3 upgrade_agent.py --detect [--root /path/to/project]

  # ★ 首次启用（全自动，v4.0自动选择架构）
  python3 upgrade_agent.py --deploy [--root /path/to/project] [--yes]

  # 从多Agent迁移到Domain
  python3 upgrade_agent.py --migrate-to-domain [--root /path/to/project] [--yes]

  # 单个agent检测/升级（Legacy兼容）
  python3 upgrade_agent.py --agent-dir /path/to/your-agent --check
  python3 upgrade_agent.py --agent-dir /path/to/your-agent --upgrade --yes
"""

import json
import os
import sys
import shutil
import argparse
import glob
from datetime import datetime, timezone

# 获取本脚本所在目录（skill根目录）
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)


class AgentUpgrader:
    """Agent架构升级器"""
    
    REQUIRED_FILES = {
        "self-evolution": ["config.json", "memory.json", "feedback.json", "evolution.log", "immune_rules.json"],
    }
    
    NEW_FILES = {
        "experiences_v2.json": "四层结构化经验库",
        "working_memory.json": "L4工作记忆",
    }
    
    # agent目录识别特征：包含 IDENTITY.md 或 SOUL.md
    AGENT_MARKER_FILES = ["IDENTITY.md", "SOUL.md"]
    
    # 跳过的目录名
    SKIP_DIRS = {".git", "__pycache__", ".evolving_data", "node_modules", ".idea", 
                 "legacy", "scripts", "self-evolution", ".workbuddy"}
    
    HOOK_TEXT_IDENTITY = """
---
## 🧬 自进化触发钩子 (v3.1 由self-evolving-core skill自动添加)

### ❌ 禁止行为
- ❌ 不执行 pre_task_check 就开始任务
- ❌ 连续使用已验证失败的方法超过2次

### ⚡ 每次任务开始前（必须执行）
```bash
python3 <SKILL_PATH>/scripts/pre_task_check.py --agent <AGENT_NAME> --task "<任务>" --keywords "<关键词>"
```
→ 返回相关经验 + 反向拦截警告

### ⚡ 每次任务完成后（必须执行）
```bash
python3 <SKILL_PATH>/scripts/post_task_learn.py --agent <AGENT_NAME> --task "<任务>" --result success|partial|failed --lessons "经验" --failed "失败方法" --tokens <N> --duration <秒>
```
→ 存储经验 + 同步到核心经验区

### 📊 监控命令
log / check / evolve / feedback — 见 SKILL.md 速查表
---

"""

    # ★ v3.1 前部注入钩子（负向框架+强约束，~180 token）
    # 核心理念：从"信任AI会做对"变为"确保AI不容易做错"
    # 双保险：静态硬编码(核心经验区) + 动态搜索(pre_task_check)
    HOOK_TEXT_IDENTITY_FRONT = """

---

## ❌ 禁止行为（违反=重复犯错）

- ❌ **禁止不执行 `pre_task_check` 就开始任务**
- ❌ **禁止连续使用已验证失败的方法超过2次**
- ❌ **禁止忽略 `log` 命令的记录要求**
- ❌ **禁止在失败超3次后不停止并重新评估方案**
- ❌ **禁止用 SendMessage 汇报任务进度** → 必须写文件（见下方「多Agent通信」）

## 📡 多Agent协作通信铁律（v3.2.3）

**所有耗时任务脚本必须遵守，无例外：**

```
{task_dir}/progress.json  ← 每处理1条就更新（status/current/total/pct/ok/empty/failed）
{task_dir}/result.json    ← 任务完成/失败时写入（status=done|error|partial）
{task_dir}/task.log       ← 详细操作日志（append-only，不能只打印stdout）
```

**5条强制规范**：
1. 进度文件每处理1条立即更新
2. 日志必须写文件（不能只 print）
3. 每N条保存中间结果（支持断点续跑）
4. 启动时检测已有结果，跳过已处理条目
5. 完成/失败都要写 result.json

**Admin监控方式（随时查，不等消息）**：
```bash
cat {task_dir}/progress.json   # 当前进度
tail -f {task_dir}/task.log    # 实时日志
```

**Python快速模板**（每个新脚本开头必须包含）：
```python
import json
from datetime import datetime

def update_progress(progress_file, current, total, ok, empty, failed, last_item):
    with open(progress_file, "w") as f:
        json.dump({"status":"running","current":current,"total":total,
                   "pct":current*100//total,"ok":ok,"empty":empty,"failed":failed,
                   "last_item":last_item,"timestamp":datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                  }, f, ensure_ascii=False, indent=2)

def write_result(result_file, status, output_file, summary, error_msg=""):
    with open(result_file, "w") as f:
        json.dump({"status":status,"output_file":output_file,"summary":summary,
                   "finished_at":datetime.now().strftime("%Y-%m-%d %H:%M:%S"),"error_msg":error_msg
                  }, f, ensure_ascii=False, indent=2)
```

## 🚨 核心经验速查（★ 每次任务必须先扫这里 ★）

> **硬编码的关键经验。有相关的直接用，别重复造轮子。**
> **如果此区块为空=还没有积累经验 → 必须执行 pre_task_check 检索完整库。**

<!-- AUTO_SYNC_START: 以下由 post_task_learn.py 自动维护，不要手动修改 -->
<!-- 经验条目将自动同步到这里 -->
<!-- AUTO_SYNC_END -->

## ✅ 强制执行流程（按顺序！）

### 第一步：任务开始前
```bash
python3 {SKILL_PATH}/scripts/pre_task_check.py --agent <AGENT_NAME> --task "<任务>" --keywords "<关键词>"
```
→ 有相关经验直接用 / 无经验走标准流程

### 最后一步：任务完成后
```bash
python3 {SKILL_PATH}/scripts/evolution_guardian.py log <AGENT_NAME> "<任务>" <success|failed|partial> [error_type] [category] [tokens] [duration_sec]
```

### 出问题时
连续失败≥3次同类错误 → `check` → `evolve`
用户说"又错了/不对" → `feedback negative ...`

---
    """

    # ★ v4.5新增: Domain模式IDENTITY/SOUL钩子模板（适配大一统单Agent架构）
    # 关键设计：
    #   1. 路径用 ./domains/_shared/...（相对路径），不硬编码用户名
    #   2. 强制要求每次任务后调log（这是R1-R4自动检测的唯一入口）
    #   3. 三段式蒸馏流程明确：from-daily → from-stm → distill(应急)
    #   4. 无钩子=R2/R4永不触发，整个自进化系统失效
    HOOK_TEXT_DOMAIN = """

---

## 🧬 自进化系统钩子（self-evolving-core v4.5 自动注入）

> ⚠️ **不可删除**。删除将导致 R1-R4 进化规则永不触发，整个自进化系统失效。

### ⚡ 强制执行规则（每次任务必做）

#### 🔴 触发条件（命中任一立即执行 log）

**只要你在本轮做了下面任意一件事，结束前必须 log，没有例外**：

| 类别 | 触发动作（命中任一即触发） |
|------|--------------------------|
| **写文件** | Write/Edit/Create/Append/修改/写入/保存/落盘/生成文件 |
| **改代码** | 重构/refactor/修bug/fix/补丁/patch/优化/提交/commit |
| **跑命令** | Bash/run/执行脚本/调用工具/部署/deploy/install/build |
| **写文档** | 写报告/写总结/写PRD/写方案/写README/输出markdown |
| **数据加工** | 查询/统计/分析/解析/转换/清洗/聚合/导出 |
| **决策记录** | 选型/拍板/确认方案/给出建议/做出取舍 |
| **回答问题** | 完成 1 轮以上问答交互且涉及具体信息（≥3 条建议/事实） |
| **设计输出** | 画图/出表/做PPT/做可视化/widget/render |
| **修复错误** | 排查/诊断/复盘/修正之前的失误 |
| **集成调用** | 调用 MCP/API/skill/agent/tool 完成任务 |
| **接收反馈** | 用户表达满意/不满/纠正/补充要求 |
| **多步操作** | 单轮内 ≥3 个工具调用（无论成功失败） |
| **创建/更新 skill** | SkillManage create/update |
| **任何会被用户感知的产出** | 用户能看到/拿到的任何结果 |

**只要满足上述任一条**，结束前在项目根目录执行：

```bash
python3 ./domains/_shared/evolution_guardian.py log <域名> "<任务简述>" <success|failed|partial> [error_type] [error_category]
```

#### 🚫 唯一豁免清单（命中即可跳过 log）

仅以下场景可不 log：
- 单纯打招呼（你好/早/谢谢）
- 单句确认（好的/收到/明白）
- 用户主动取消任务
- 询问当前时间/路径等无加工的元信息

**不在豁免清单 = 必须 log**。"任务很小""不重要""没改东西"——都不是借口。

#### 参数说明

- `<域名>`：用 `check` 命令查看可用域，或用 `domain_router.py "<任务>"` 路由匹配（Router 输出末尾会直接给出现成的 log 命令，复制即用）
- `<result>`：success / failed / partial
- `<error_type>`：失败时填，常用值：tool_failed / timeout / empty_result / user_reject
- `<error_category>`：错误分类（用于 R2 同类错误检测），如"数据解析"/"API调用"

**为什么必须做**：log 命令内置阈值自检引擎，每次记账后自动检测 4 条进化规则：
- R1：每 10 次任务 → 提示复盘
- R2：同类任务连续失败 ≥3 次 → 🔴 提示提取免疫规则
- R3：收到负面反馈 ≥1 条 → ⚠️ 提示深度进化
- R4：MEMORY.md > 150 行 → 📋 提示 distill

**违反 = 重复犯错、记忆爆炸、整个系统形同虚设**。

### 🧠 三段式记忆蒸馏（不可跳步）

```
每日日志 → distill --from-daily → STM → distill --from-stm → MEMORY.md
                                                    ↓ 仅超限应急
                                              experiences.json
```

```bash
# 每日结束（常规必做）
python3 ./domains/_shared/evolution_guardian.py distill --from-daily

# STM 有积累时
python3 ./domains/_shared/evolution_guardian.py distill --from-stm

# 仅 MEMORY.md > 150 行时（应急）
python3 ./domains/_shared/evolution_guardian.py distill --dry-run
python3 ./domains/_shared/evolution_guardian.py distill
```

### 📝 收到用户负面反馈时

```bash
python3 ./domains/_shared/evolution_guardian.py feedback admin negative <strong|medium|mild> "<触发词>" "<上下文>"
```

→ 触发 R3，提示立即 evolve 修正策略。

### 🔍 任务前路由（推荐）

```bash
python3 ./domains/_shared/domain_router.py "<任务描述>"
```

→ 自动匹配域 + 检索历史经验 + 免疫规则预检。

---

"""

    def __init__(self, agent_dir: str, agent_name: str = None):
        self.agent_dir = os.path.abspath(agent_dir)
        self.agent_name = agent_name or os.path.basename(agent_dir)
        self.evo_dir = os.path.join(self.agent_dir, "self-evolution")
        self.identity_path = os.path.join(self.agent_dir, "IDENTITY.md")
        self.soul_path = os.path.join(self.agent_dir, "SOUL.md")
        
        self.planned_changes = []
        self.executed_changes = []
        self.warnings = []
    
    # ==================== v3.0: 全自动部署模式 ====================
    
    @staticmethod
    def discover_agents(root_dir: str) -> list:
        """
        自动发现项目中的所有agent目录
        
        识别规则：
        1. 目录下包含 IDENTITY.md 或 SOUL.md（agent特征文件）
        2. 排除系统目录、缓存目录等
        """
        agents = []
        
        if not os.path.exists(root_dir):
            return agents
        
        # 扫描agents目录或root下的子目录
        search_paths = [
            os.path.join(root_dir, "agents"),  # 标准 agents/ 目录
            root_dir,                           # root本身
        ]
        
        for search_base in search_paths:
            if not os.path.isdir(search_base):
                continue
            
            for entry in sorted(os.listdir(search_base)):
                entry_path = os.path.join(search_base, entry)
                
                # 跳过非目录
                if not os.path.isdir(entry_path):
                    continue
                
                # 跳过已知非agent目录
                if entry in AgentUpgrader.SKIP_DIRS:
                    continue
                
                # 跳过隐藏目录
                if entry.startswith('.'):
                    continue
                
                # 检查是否有agent特征文件
                is_agent = any(
                    os.path.exists(os.path.join(entry_path, marker))
                    for marker in AgentUpgrader.AGENT_MARKER_FILES
                )
                
                if is_agent:
                    agents.append({
                        "name": entry,
                        "dir": entry_path,
                    })
        
        return agents

    @staticmethod
    def detect_architecture(root_dir: str) -> dict:
        """
        ★ v4.0新增: 架构智能检测

        检测用户当前环境，判断应使用哪种架构模式。
        对应 SKILL.md 中的「架构选择指南」逻辑。

        Returns:
            {
                "mode": "domain_only" | "agent_legacy" | "dual_mode" | "fresh_install",
                "recommendation": "推荐模式说明",
                "details": {
                    "has_domains_dir": bool,
                    "has_agents_dir": bool,
                    "domains_configured": list,
                    "agents_found": list,
                    "evo_config_exists": bool
                }
            }
        """
        domains_dir = os.path.join(root_dir, "domains")
        agents_dir = os.path.join(root_dir, "agents")
        shared_dir = os.path.join(domains_dir, "_shared") if os.path.exists(domains_dir) else None

        has_domains = os.path.isdir(domains_dir)
        has_agents = os.path.isdir(agents_dir)
        has_evo_config = shared_dir and os.path.exists(os.path.join(shared_dir, "evo-config.json"))

        # 检测已配置的域
        domains_configured = []
        if has_domains:
            for entry in os.listdir(domains_dir):
                if entry.startswith(".") or entry == "_shared":
                    continue
                dpath = os.path.join(domains_dir, entry)
                if os.path.isdir(dpath):
                    # 检查是否有experiences或memory文件
                    has_data = (
                        os.path.exists(os.path.join(dpath, "experiences.json")) or
                        os.path.exists(os.path.join(dpath, "memory.json")) or
                        os.path.exists(os.path.join(dpath, "role-snapshot.json"))
                    )
                    domains_configured.append({"name": entry, "has_data": has_data})

        # 发现的agents
        agents_found = AgentUpgrader.discover_agents(root_dir)

        # 判断架构类型
        if has_evo_config and has_domains:
            mode = "domain_only"
            recommendation = (
                f"★ 已检测到Domain架构（{len(domains_configured)}个域已配置）。"
                f" 推荐继续使用Domain模式作为主线。\n"
                f"   域列表: {', '.join(d['name'] for d in domains_configured)}"
            )
        elif has_agents and agents_found:
            mode = "agent_legacy"
            agent_names = [a["name"] for a in agents_found]
            recommendation = (
                f"⚠️ 检测到多Agent架构（{len(agents_found)}个Agent: {', '.join(agent_names)}）。"
                f"\n   ★ 推荐执行 --migrate-to-domain 迁移到Domain架构（方案C）。"
                f"\n   或继续使用Agent模式（Legacy，见SKILL.md附录A）。"
                f"\n   迁移时会自动分析各Agent角色并映射到对应业务域。"
            )
        elif has_domains and not has_evo_config:
            mode = "partial_domain"
            recommendation = (
                f"⚠️ domains/目录存在但未完全初始化（缺少evo-config.json）。"
                f"\n   推荐: 运行 --deploy 完成Domain架构初始化。"
            )
        else:
            mode = "fresh_install"
            recommendation = (
                "🆕 全新环境，未检测到任何自进化架构。"
                "\n   ★ 推荐: 运行 --deploy 自动初始化Domain大一统架构（方案C主线）。"
            )

        return {
            "mode": mode,
            "recommendation": recommendation,
            "details": {
                "has_domains_dir": has_domains,
                "has_agents_dir": has_agents,
                "evo_config_exists": has_evo_config,
                "domains_configured": domains_configured,
                "agents_found": agents_found,
                "root_dir": root_dir,
            },
            "timestamp": datetime.now().isoformat(),
        }

    def deploy(self, root_dir: str, auto_confirm: bool = False) -> dict:
        """
        ★ 全自动部署流程（v3.0核心方法）
        
        流程：
        1. 发现所有agent → 2. 检测每个状态 → 3. 展示计划+询问 → 
        4. 逐个升级 → 5. 验证所有 → 6. 输出最终报告
        
        返回: 完整的部署报告字典
        """
        report = {
            "timestamp": datetime.now().isoformat(),
            "skill_version": self._get_skill_version(),
            "architecture_version": "4.0",
            "root_dir": root_dir,
            "agents_found": [],
            "agents_upgraded": [],
            "agents_skipped": [],
            "domains_initialized": [],
            "total_changes": 0,
            "verification": {},
            "success": True,
            "errors": [],
            "architecture_detected": None,
        }

        # ★ v4.0 Step 0: 架构智能检测
        print("\n" + "=" * 65)
        print("  🧬 Self-Evolving-Core v4.0 — 架构部署（方案C双模）")
        print("=" * 65)

        arch_result = self.detect_architecture(root_dir)
        report["architecture_detected"] = arch_result

        print(f"\n  📡 [v4.0] 架构自动检测结果:")
        print(f"     模式: {arch_result['mode']}")
        print(f"     domains目录: {'✅' if arch_result['details']['has_domains_dir'] else '❌'}")
        print(f"     agents目录: {'✅' if arch_result['details']['has_agents_dir'] else '❌'}")
        print(f"     evo-config: {'✅' if arch_result['details']['evo_config_exists'] else '❌'}")
        if arch_result['details']['domains_configured']:
            print(f"     已配置域: {', '.join(d['name'] for d in arch_result['details']['domains_configured'])}")
        if arch_result['details']['agents_found']:
            print(f"     发现Agent: {', '.join(a['name'] for a in arch_result['details']['agents_found'])}")
        print(f"\n  💡 {arch_result['recommendation']}")

        # 根据检测结果的模式决定部署策略
        if arch_result["mode"] == "domain_only":
            # 已有Domain架构 → 验证+补充（顺带补全工作空间结构）
            print("\n  ✅ Domain架构已就绪，执行验证和补充...")
            AgentUpgrader.init_workspace_structure(root_dir)
            # ★ v4.4: 顺带整理 MEMORY.md（检查行数+规则配置）
            print(f"\n{'=' * 65}")
            print(f"  🧹 整理 MEMORY.md 记忆规则...")
            print(f"{'=' * 65}")
            domains_cfg = arch_result["details"].get("domains_configured", [])
            AgentUpgrader._audit_and_fix_memory(root_dir, domains_cfg, auto_confirm)
            return self._deploy_domain_mode(root_dir, arch_result, report, auto_confirm)

        elif arch_result["mode"] == "agent_legacy":
            # 有多Agent架构 → 方案C: 初始化Domain + 保留Agent
            print("\n  ⚠️  检测到Legacy Agent架构，按方案C处理...")
            print("     (初始化Domain主线 + 保留agents/作为Legacy)")
            AgentUpgrader.init_workspace_structure(root_dir)
            domain_report = self._init_domain_structure(root_dir, auto_confirm)
            report["domains_initialized"] = domain_report.get("initialized", [])
            report["total_changes"] += domain_report.get("changes", 0)
            # 继续走原有的agent deploy流程
            # (不中断，让用户可以继续使用agent模式过渡)

        elif arch_result["mode"] == "fresh_install":
            # ★ v4.3: 全新安装 → 先补全工作空间标准结构，再扫描记忆，再交互确认，再初始化
            print("\n  🆕 全新环境，准备初始化 Domain 大一统架构...")

            # ★ v4.3新增: 先检查并补全工作空间标准结构
            print(f"\n{'=' * 65}")
            print(f"  🏗️  Step 0: 检查工作空间标准结构...")
            print(f"{'=' * 65}")
            ws_result = AgentUpgrader.init_workspace_structure(root_dir)
            if ws_result["created"]:
                print(f"  ✅ 补全了 {len(ws_result['created'])} 个文件/目录")
            else:
                print(f"  ℹ️  工作空间结构完整，无需补全")
            if ws_result["errors"]:
                for err in ws_result["errors"]:
                    print(f"  ⚠️  {err}")

            print(f"\n{'=' * 65}")
            print(f"  🔍 Step 1: 扫描工作空间历史记忆...")
            print(f"{'=' * 65}")

            scan = AgentUpgrader._scan_memory_files(root_dir)

            if scan["has_content"]:
                print(f"\n  📂 发现以下历史内容：")
                for mf in scan["memory_files"]:
                    size_kb = mf["size"] // 1024 or 1
                    print(f"     📄 {mf['name']} ({size_kb}KB)")
                    print(f"        └─ {mf['preview'][:80]}...")
                for ef in scan["experience_files"]:
                    print(f"     🧠 {ef['agent']}/experiences ({ef['count']}条经验)")

                total_chars = scan["total_memory_chars"]
                print(f"\n  📊 共 {len(scan['memory_files'])} 个记忆文件，"
                      f"{len(scan['experience_files'])} 个经验文件，"
                      f"约 {total_chars//1000}K 字")

                if not auto_confirm:
                    print(f"\n  ❓ 是否分析这些历史内容，从中推断业务领域并提炼初始经验？")
                    print(f"     选 y：分析历史记忆，生成贴合你实际业务的域配置（推荐）")
                    print(f"     选 n：跳过分析，创建3个通用域（空白起步）")
                    print(f"     (y/n): ", end="")
                    try:
                        scan_confirm = input().strip().lower()
                    except EOFError:
                        scan_confirm = "n"
                else:
                    scan_confirm = "y"  # --yes 模式下自动分析

                analyze_memory = (scan_confirm == "y")
            else:
                print(f"\n  ℹ️  未发现历史记忆文件，将使用3个通用域起步。")
                analyze_memory = False

            # 推断域（有记忆时从记忆推断，无则fallback通用域）
            workspace_signals = AgentUpgrader._analyze_workspace(root_dir)
            inferred_list = AgentUpgrader._infer_domains(workspace_signals, root_dir)

            print(f"\n{'=' * 65}")
            print(f"  🧩 Step 2: 推断业务领域...")
            print(f"{'=' * 65}")
            print(f"\n  根据工作空间分析，推断出以下 {len(inferred_list)} 个业务域：\n")
            for d in inferred_list:
                src_tag = {"agent_role": "来自Agent配置", "memory_keywords": "来自历史记忆",
                           "dir_name": "来自目录名", "fallback": "通用默认"}.get(d.get("source", ""), "")
                print(f"    [{d['key']:<14}] 《{d['name']}》 — {d['description']}")
                print(f"                   触发词: {', '.join(d.get('trigger_keywords', [])[:4])} ({src_tag})")

            if not auto_confirm:
                print(f"\n  ❓ 确认使用以上域配置？(y/n 或 输入自定义域名用逗号分隔): ", end="")
                try:
                    domain_confirm = input().strip()
                except EOFError:
                    domain_confirm = "y"

                if domain_confirm.lower() == "n":
                    print("\n  ⏹️  部署已取消。")
                    report["success"] = False
                    return report
                elif domain_confirm.lower() not in ("y", ""):
                    # 用户输入了自定义域名
                    custom_names = [n.strip() for n in domain_confirm.split(",") if n.strip()]
                    if custom_names:
                        inferred_list = [
                            {"key": name, "name": name, "description": f"{name}相关任务",
                             "trigger_keywords": [name], "role_name": "", "source": "user_input"}
                            for name in custom_names
                        ]
                        print(f"  ✅ 使用自定义域: {', '.join(custom_names)}")

            # 提炼初始经验（如果有记忆且用户确认分析）
            initial_experiences = {}
            if analyze_memory and scan["memory_files"]:
                print(f"\n{'=' * 65}")
                print(f"  📖 Step 3: 从历史记忆中提炼初始经验...")
                print(f"{'=' * 65}")
                memory_contents = [mf["full_content"] for mf in scan["memory_files"]]
                initial_experiences = AgentUpgrader._extract_domain_experiences_from_memory(
                    memory_contents, inferred_list
                )
                total_extracted = sum(len(v) for v in initial_experiences.values())
                print(f"\n  ✅ 从历史记忆中提炼了 {total_extracted} 条初始经验（置信度0.5，待实际任务验证）")
                for key, exps in initial_experiences.items():
                    if exps:
                        print(f"     {key}: {len(exps)}条")

            # ★ v4.4新增: Step 4 — 整理 MEMORY.md 规则配置
            print(f"\n{'=' * 65}")
            print(f"  🧹 Step 4: 整理 MEMORY.md 记忆规则...")
            print(f"{'=' * 65}")
            AgentUpgrader._audit_and_fix_memory(root_dir, inferred_list, auto_confirm)

            # 执行初始化
            domain_report = self._init_domain_structure(
                root_dir, auto_confirm,
                inferred_domains_override=inferred_list,
                initial_experiences=initial_experiences,
            )
            report["domains_initialized"] = domain_report.get("initialized", [])
            report["total_changes"] += domain_report.get("changes", 0)
            if domain_report.get("success"):
                print("\n  ✨ Domain架构初始化完成！")
                report["verification"] = {"result": "domain_initialized", "all_passed": True}
                self._print_deploy_report_v4(report)
                return report

        # Step 1: 发现所有agent（原有逻辑，用于agent_legacy模式）
        
        all_agents = self.discover_agents(root_dir)
        
        if not all_agents:
            print(f"\n  ⚠️  未在 {root_dir} 下发现任何Agent目录")
            print(f"     查找范围：agents/ 子目录 或 包含 IDENTITY.md/SOUL.md 的子目录")
            print(f"     提示：使用 --root 参数指定正确的项目根目录")
            
            report["success"] = False
            report["errors"].append("未发现任何agent目录")
            return report
        
        print(f"\n  📍 扫描路径: {root_dir}")
        print(f"  🎯 发现 {len(all_agents)} 个Agent:\n")
        
        # Step 2: 检测每个agent的状态
        deploy_plan = []  # (upgrader_obj, check_result)
        
        for agent_info in all_agents:
            name = agent_info["name"]
            d = agent_info["dir"]
            
            upgrader = AgentUpgrader(d, name)
            status = upgrader.check()
            
            report["agents_found"].append({"name": name, "dir": d, **status})
            
            icon = "⚠️" if status["needs_upgrade"] else "✅"
            detail = ""
            if status["needs_upgrade"]:
                detail = f"（{len(status['recommended_actions'])}项待处理）"
            
            print(f"    {icon} {name:<15} {'需要升级' + detail if status['needs_upgrade'] else '已是最新'}")
            
            if status["needs_upgrade"]:
                deploy_plan.append((upgrader, status))
        
        if not deploy_plan:
            print("\n  ✨ 所有Agent架构已是最新，无需部署！")
            report["verification"]["result"] = "all_current"
            return report
        
        # Step 3: 展示部署计划并确认
        print(f"\n{'─' * 65}")
        print(f"  📋 部署计划：需处理 {len(deploy_plan)} 个Agent\n")
        
        total_actions = 0
        for upgrader, status in deploy_plan:
            print(f"  🔧 {upgrader.agent_name}:")
            for action in status["recommended_actions"]:
                print(f"      • {action}")
                total_actions += 1
            print()
        
        print(f"  📊 总计: {total_actions} 项操作待执行")
        
        if not auto_confirm:
            print(f"\n  ❓ 是否立即执行部署？(y/n): ", end="")
            try:
                confirm = input().strip().lower()
            except EOFError:
                confirm = "n"
            if confirm != 'y':
                print("\n  ⏹️  部署已取消。可随时重新运行此命令。")
                report["success"] = False
                return report
        
        # Step 4: 逐个执行升级
        print(f"\n{'=' * 65}")
        print(f"  🚀 开始部署...")
        print(f"{'=' * 65}\n")
        
        for i, (upgrader, status) in enumerate(deploy_plan, 1):
            name = upgrader.agent_name
            print(f"  ┌──────────────────────────────────────────┐")
            print(f"  │ [{i}/{len(deploy_plan)}] 升级: {name:<27}│")
            print(f"  └──────────────────────────────────────────┘")
            
            try:
                success = upgrader.execute_upgrade(auto_confirm=True)
                
                if success:
                    report["agents_upgraded"].append(name)
                    report["total_changes"] += len(upgrader.executed_changes)
                    print(f"  ✅ {name} 升级完成 ({len(upgrader.executed_changes)}项)\n")
                else:
                    report["agents_skipped"].append(name)
                    print(f"  ⚠️  {name} 有警告（见上方详情）\n")
                    
            except Exception as e:
                report["agents_skipped"].append(name)
                report["errors"].append(f"{name}: {e}")
                print(f"  ❌ {name} 升级失败: {e}\n")
        
        # Step 5: 自动验证
        print(f"{'=' * 65}")
        print(f"  🔍 自动验证...")
        print(f"{'=' * 65}\n")
        
        verification = self._run_verification(deploy_plan)
        report["verification"] = verification
        
        if verification["all_passed"]:
            print(f"  🎉 全部验证通过！({verification['passed']}/{verification['total']} 项)")
        else:
            report["success"] = False
            print(f"  ⚠️  验证结果: {verification['passed']}/{verification['total']} 通过")
            for fail in verification.get("failed_items", []):
                print(f"      ❌ {fail}")
        
        # Step 6: 最终报告
        print(f"\n{'=' * 65}")
        print(f"  📊 部署完成报告")
        print(f"{'=' * 65}")
        print(f"""
  发现Agent:   {len(report['agents_found'])} 个
  成功升级:   {len(report['agents_upgraded'])} 个 ({', '.join(report['agents_upgraded']) or '无'})
  跳过:       {len(report['agents_skipped'])} 个 ({', '.join(report['agents_skipped']) or '无'})
  总操作数:   {report['total_changes']} 项
  验证状态:   {'✅ 全部通过' if verification['all_passed'] else '⚠️ 有未通过项'}
  
  💡 下一步:
  1. 每次任务完成后执行: evolution_guardian.py log <agent> "<任务>" <结果>
  2. 每10次任务执行: evolution_guardian.py check <agent>
  3. 连续异常时执行: evolution_guardian.py review <agent>
""")
        
        return report
    
    def _get_skill_version(self) -> str:
        """获取skill版本号"""
        meta_path = os.path.join(SKILL_DIR, "_meta.json")
        try:
            with open(meta_path, 'r') as f:
                data = json.load(f)
                return data.get("version", "unknown")
        except:
            return "unknown"
    
    def _run_verification(self, deploy_plan: list) -> dict:
        """运行端到端验证"""
        results = {"passed": 0, "total": 0, "all_passed": True, "failed_items": []}
        guard_path = os.path.join(SCRIPT_DIR, "evolution_guardian.py")
        
        # 验证1: 核心脚本可执行
        results["total"] += 1
        if os.path.exists(guard_path):
            results["passed"] += 1
        else:
            results["all_passed"] = False
            results["failed_items"].append("evolution_guardian.py 不存在")
        
        # 验证2: 每个升级后的agent完整性
        for upgrader, _ in deploy_plan:
            name = upgrader.agent_name
            final_check = upgrader.check()
            
            results["total"] += 1
            if not final_check["needs_upgrade"]:
                results["passed"] += 1
            else:
                results["all_passed"] = False
                results["failed_items"].append(f"{name}: 仍有 {len(final_check['recommended_actions'])} 项缺失")
            
            # 验证3: evolution_guardian.py log 可执行
            results["total"] += 1
            if os.path.exists(upgrader.evo_dir):
                results["passed"] += 1
            else:
                results["all_passed"] = False
                results["failed_items"].append(f"{name}: self-evolution/ 目录不存在")
        
        return results

    # ========== ★ v4.1 智能工作空间分析引擎 ==========

    @staticmethod
    def _analyze_workspace(root_dir: str) -> dict:
        """
        ★ v4.1新增: 扫描用户工作空间，收集信号用于智能域推断。

        扫描内容：
          - 目录结构（子目录名→业务领域信号）
          - .workbuddy/memory/ 历史记忆文件（任务类型、关键词）
          - agents/ 已有Agent配置（IDENTITY.md的角色定义）
          - 文件类型分布（.py/.xlsx/.md/.sql→业务属性）

        返回: {
            "dir_signals": [...],       # 目录名列表
            "memory_keywords": [...],   # 从记忆文件提取的高频词
            "agent_roles": [...],       # 已有Agent角色描述
            "file_type_stats": {...},   # 文件类型统计
            "raw_memory_snippets": [...] # 记忆文件原始片段（最多500字符）
        }
        """
        signals = {
            "dir_signals": [],
            "memory_keywords": [],
            "agent_roles": [],
            "file_type_stats": {},
            "raw_memory_snippets": [],
        }

        # 1. 目录结构信号
        skip_dirs = {".git", "__pycache__", "node_modules", ".idea", "domains", "workspace"}
        try:
            for entry in os.listdir(root_dir):
                p = os.path.join(root_dir, entry)
                if os.path.isdir(p) and not entry.startswith(".") and entry not in skip_dirs:
                    signals["dir_signals"].append(entry)
        except Exception:
            pass

        # 2. 扫描 .workbuddy/memory/ 历史记忆
        memory_dir = os.path.join(root_dir, ".workbuddy", "memory")
        if os.path.isdir(memory_dir):
            for fname in sorted(os.listdir(memory_dir))[-5:]:  # 最近5个文件
                fpath = os.path.join(memory_dir, fname)
                if fname.endswith(".md") and os.path.isfile(fpath):
                    try:
                        with open(fpath, "r", encoding="utf-8") as f:
                            content = f.read(2000)
                        signals["raw_memory_snippets"].append(content[:500])
                    except Exception:
                        pass

        # 3. 扫描 agents/ 已有角色
        agents_dir = os.path.join(root_dir, "agents")
        if os.path.isdir(agents_dir):
            for agent_entry in os.listdir(agents_dir):
                identity_path = os.path.join(agents_dir, agent_entry, "IDENTITY.md")
                if os.path.isfile(identity_path):
                    try:
                        with open(identity_path, "r", encoding="utf-8") as f:
                            snippet = f.read(800)
                        signals["agent_roles"].append({"name": agent_entry, "snippet": snippet[:400]})
                    except Exception:
                        pass

        # 4. 文件类型统计
        type_count = {}
        try:
            for dirpath, dirnames, filenames in os.walk(root_dir):
                # 跳过隐藏目录和常见干扰目录
                dirnames[:] = [d for d in dirnames
                               if not d.startswith(".") and d not in ("node_modules", "__pycache__", "domains")]
                for fn in filenames:
                    ext = os.path.splitext(fn)[1].lower()
                    if ext:
                        type_count[ext] = type_count.get(ext, 0) + 1
        except Exception:
            pass
        signals["file_type_stats"] = dict(sorted(type_count.items(), key=lambda x: -x[1])[:15])

        return signals

    @staticmethod
    def _infer_domains(workspace_signals: dict, root_dir: str) -> list:
        """
        ★ v4.1新增: 根据工作空间分析信号，智能推断用户的业务域。

        推断策略（优先级从高到低）：
          P0 - 从已有agents/IDENTITY.md直接提取角色→映射到域
          P1 - 从记忆文件关键词推断业务类型
          P2 - 从目录名推断
          P3 - 从文件类型分布推断
          Fallback - 生成3个通用域（研究分析/开发实现/文档管理）

        返回: [
          {"key": "域键名(英文)", "name": "简洁中文名", "description": "职责简述",
           "trigger_keywords": [...], "role_name": "角色名(可选中文)"}
        ]
        """
        inferred = []

        # P0: 从已有Agent角色直接推断
        agent_roles = workspace_signals.get("agent_roles", [])
        for ar in agent_roles:
            snippet = ar["snippet"].lower()
            name = ar["name"]
            # 跳过admin（大总管是调度者，不需要独立域）
            if name in ("admin", "administrator"):
                continue
            # 尝试从snippet提取职责描述
            role_hint = ""
            for line in ar["snippet"].split("\n"):
                if "职责" in line or "负责" in line or "专注" in line or "专业" in line:
                    role_hint = line.strip("# -").strip()[:40]
                    break

            # 基于名字和描述推断域
            domain_map = {
                "data": ("数据分析", "数据查询/分析/处理/报表", ["数据", "分析", "查询", "统计", "Excel", "数据库"]),
                "product": ("产品研发", "产品设计/代码开发/需求分析", ["产品", "需求", "代码", "开发", "功能", "PRD"]),
                "ux": ("交互设计", "UI设计/交互原型/用户体验", ["界面", "交互", "设计", "UX", "原型", "用户体验"]),
                "test": ("测试验证", "质量保障/测试/验收", ["测试", "QA", "验收", "bug", "质量", "回归"]),
            }
            # 模糊匹配Agent名或描述到已知类型
            matched_key = None
            for key, (zh_name, desc, kws) in domain_map.items():
                if any(k in snippet for k in kws[:3]) or key in name:
                    matched_key = key
                    break

            if matched_key:
                zh_name, desc, kws = domain_map[matched_key]
                if not any(d["key"] == matched_key for d in inferred):
                    inferred.append({
                        "key": matched_key,
                        "name": zh_name,
                        "description": role_hint or desc,
                        "trigger_keywords": kws,
                        "role_name": name,
                        "source": "agent_role",
                    })

        # P1: 从记忆文件关键词推断
        all_memory = " ".join(workspace_signals.get("raw_memory_snippets", []))
        keyword_domain_hints = [
            # (检测词, 域key, 中文名, 描述, 触发词)
            (["数据", "查询", "分析", "统计", "Excel", "数据库", "爬虫"],
             "数据处理", "data_work", "数据查询/分析/处理", ["数据", "分析", "查询", "统计"]),
            (["代码", "开发", "脚本", "python", "api", "接口", "bug", "程序"],
             "代码开发", "dev_work", "代码编写/脚本开发/系统集成", ["代码", "开发", "脚本", "调试"]),
            (["文档", "报告", "prd", "需求", "方案", "规划", "总结"],
             "文档写作", "doc_work", "文档撰写/方案设计/需求分析", ["文档", "报告", "方案", "需求"]),
            (["测试", "验证", "qa", "验收", "回归"],
             "测试验证", "test_work", "质量保障/测试/验收", ["测试", "验证", "验收", "质量"]),
            (["设计", "界面", "ui", "ux", "原型", "交互"],
             "交互设计", "ux_work", "界面设计/交互原型/用户体验", ["设计", "界面", "交互", "原型"]),
            (["运营", "内容", "营销", "推广", "增长"],
             "运营内容", "ops_work", "内容运营/营销推广/增长分析", ["运营", "内容", "营销", "推广"]),
            (["研究", "调研", "分析", "竞品", "报告"],
             "研究调研", "research_work", "市场研究/竞品分析/行业报告", ["研究", "调研", "竞品", "分析"]),
        ]
        for kw_list, cn_name, key_hint, desc, trigger_kws in keyword_domain_hints:
            hit_count = sum(1 for kw in kw_list if kw.lower() in all_memory.lower())
            if hit_count >= 2:
                # 找一个不冲突的key
                base_key = key_hint.replace("_work", "")
                key = base_key
                i = 2
                while any(d["key"] == key for d in inferred):
                    key = f"{base_key}{i}"
                    i += 1
                if not any(d["name"] == cn_name for d in inferred):
                    inferred.append({
                        "key": key,
                        "name": cn_name,
                        "description": desc,
                        "trigger_keywords": trigger_kws,
                        "role_name": "",
                        "source": "memory_keywords",
                    })

        # P2: 从目录名推断
        dir_hint_map = {
            "src": ("代码开发", "dev", "代码实现/功能开发", ["代码", "开发", "实现"]),
            "docs": ("文档管理", "docs", "文档编写/知识管理", ["文档", "说明", "手册"]),
            "data": ("数据处理", "data_work", "数据分析/数据处理", ["数据", "分析", "处理"]),
            "test": ("测试验证", "test_work", "测试/质量验证", ["测试", "验证", "质量"]),
            "scripts": ("脚本工具", "scripts", "脚本编写/自动化", ["脚本", "自动化", "工具"]),
            "research": ("研究调研", "research", "研究/调研/分析", ["研究", "调研", "分析"]),
            "reports": ("报告生成", "reports", "报告/分析报告生成", ["报告", "分析", "汇总"]),
        }
        for dir_name in workspace_signals.get("dir_signals", []):
            hint = dir_hint_map.get(dir_name.lower())
            if hint:
                cn_name, key, desc, trigger_kws = hint
                if not any(d["name"] == cn_name or d["key"] == key for d in inferred):
                    inferred.append({
                        "key": key,
                        "name": cn_name,
                        "description": desc,
                        "trigger_keywords": trigger_kws,
                        "role_name": "",
                        "source": "dir_name",
                    })

        # Fallback: 至少保证3个通用域（如果推断不出来）
        fallback_domains = [
            {"key": "分析研究", "name": "分析研究", "description": "数据分析/研究调研/问题诊断",
             "trigger_keywords": ["分析", "研究", "调研", "数据", "报告"], "role_name": "", "source": "fallback"},
            {"key": "开发实现", "name": "开发实现", "description": "代码开发/功能实现/系统集成",
             "trigger_keywords": ["代码", "开发", "实现", "脚本", "功能"], "role_name": "", "source": "fallback"},
            {"key": "文档写作", "name": "文档写作", "description": "文档撰写/方案设计/内容创作",
             "trigger_keywords": ["文档", "方案", "需求", "报告", "说明"], "role_name": "", "source": "fallback"},
        ]
        if len(inferred) < 2:
            for fb in fallback_domains:
                if not any(d["key"] == fb["key"] or d["name"] == fb["name"] for d in inferred):
                    inferred.append(fb)
                if len(inferred) >= 3:
                    break

        # 最多保留6个域，避免冗余
        return inferred[:6]

    @staticmethod
    def _scan_memory_files(root_dir: str) -> dict:
        """
        ★ v4.2新增: 全面扫描工作空间中的所有记忆和历史任务文件

        扫描范围：
          - .workbuddy/memory/*.md  (working memory日志)
          - .workbuddy/memory/MEMORY.md (长期记忆)
          - agents/*/self-evolution/experiences*.json (历史经验)
          - domains/*/experiences.json (已有经验，如果存在)

        返回: {
            "memory_files": [{"path": str, "size": int, "preview": str}],
            "experience_files": [{"path": str, "agent": str, "count": int}],
            "total_memory_chars": int,
            "has_content": bool
        }
        """
        result = {
            "memory_files": [],
            "experience_files": [],
            "total_memory_chars": 0,
            "has_content": False,
        }

        # 扫描 working memory 文件
        memory_dir = os.path.join(root_dir, ".workbuddy", "memory")
        if os.path.isdir(memory_dir):
            for fname in sorted(os.listdir(memory_dir)):
                fpath = os.path.join(memory_dir, fname)
                if fname.endswith(".md") and os.path.isfile(fpath):
                    try:
                        size = os.path.getsize(fpath)
                        with open(fpath, "r", encoding="utf-8") as f:
                            content = f.read()
                        preview = content[:200].replace("\n", " ").strip()
                        result["memory_files"].append({
                            "path": fpath,
                            "name": fname,
                            "size": size,
                            "preview": preview,
                            "full_content": content,
                        })
                        result["total_memory_chars"] += len(content)
                    except Exception:
                        pass

        # 扫描 agents 下的经验文件
        agents_dir = os.path.join(root_dir, "agents")
        if os.path.isdir(agents_dir):
            for agent_name in os.listdir(agents_dir):
                evo_dir = os.path.join(agents_dir, agent_name, "self-evolution")
                for exp_fname in ("experiences_v2.json", "experiences.json"):
                    exp_path = os.path.join(evo_dir, exp_fname)
                    if os.path.isfile(exp_path):
                        try:
                            with open(exp_path, "r", encoding="utf-8") as f:
                                data = json.load(f)
                            count = len(data.get("experiences", []))
                            if count > 0:
                                result["experience_files"].append({
                                    "path": exp_path,
                                    "agent": agent_name,
                                    "count": count,
                                })
                        except Exception:
                            pass

        result["has_content"] = bool(result["memory_files"] or result["experience_files"])
        return result

    @staticmethod
    def _extract_domain_experiences_from_memory(
        memory_contents: list, inferred_domains: list
    ) -> dict:
        """
        ★ v4.2新增: 从记忆文件内容中提取各域的初始经验摘要

        逻辑：
          遍历记忆文件内容，按推断出的域关键词匹配，
          为每个域生成1-3条高置信度的初始经验。

        返回: {
            "data": [经验列表],
            "dev": [经验列表],
            ...
        }
        """
        domain_experiences = {d["key"]: [] for d in inferred_domains}

        # 合并所有记忆内容
        all_content = "\n".join(memory_contents)
        lines = all_content.split("\n")

        for domain in inferred_domains:
            key = domain["key"]
            trigger_kws = domain.get("trigger_keywords", [])
            matched_lines = []

            for i, line in enumerate(lines):
                line_lower = line.lower()
                if any(kw.lower() in line_lower for kw in trigger_kws):
                    # 取前后共3行作为上下文
                    ctx_start = max(0, i - 1)
                    ctx_end = min(len(lines), i + 3)
                    ctx = " ".join(lines[ctx_start:ctx_end]).strip()
                    if len(ctx) > 20 and ctx not in matched_lines:
                        matched_lines.append(ctx)

            # 取前3条最有价值的匹配作为初始经验
            for j, ctx in enumerate(matched_lines[:3]):
                domain_experiences[key].append({
                    "id": f"init_{key}_{j+1:03d}",
                    "layer": "L2",
                    "status": "active",
                    "scenario": f"{domain['name']}初始经验",
                    "keywords": trigger_kws[:3],
                    "fact": ctx[:200],
                    "steps": [],
                    "insight": f"从历史记忆中提取，待在实际任务中验证和完善",
                    "confidence": 0.5,
                    "proven_count": 0,
                    "superseded_by": None,
                    "updated_at": datetime.now().strftime("%Y-%m-%d"),
                    "source": "memory_import",
                })

        return domain_experiences

    @staticmethod
    def _audit_and_fix_memory(root_dir: str, domains_list: list, auto_confirm: bool = False) -> dict:
        """★ v4.4新增: 部署时检查并整理 MEMORY.md

        工作流:
        1. 检查 MEMORY.md 是否存在 + 当前行数
        2. 扫描内容，判断:
           a. 元层内容（保留）
           b. 超出元层的具体经验内容（标记待蒸馏）
           c. 是否包含记忆规则配置段（Domain框架/运行模式/触发规则说明）
        3. 若缺少规则配置段 → 自动追加「self-evolving-core 记忆规则」区块
        4. 若行数超 150 → 提示运行 distill（不自动执行，需用户确认）
        5. 若行数合理 → 仅输出状态报告

        规则配置段内容（追加到 MEMORY.md 末尾）:
        - Domain框架路径/域名列表
        - 记忆管理触发规则（R4阈值、distill/archive-logs 命令）
        - 写入规范（元层 vs 具体经验的分界说明）

        返回: {
            "status": "ok" | "need_distill" | "rules_added",
            "line_count": int,
            "rules_added": bool,
        }
        """
        import re

        result = {"status": "ok", "line_count": 0, "rules_added": False}

        memory_path = os.path.join(root_dir, ".workbuddy", "memory", "MEMORY.md")

        # ── 文件不存在 → 跳过（init_workspace_structure 会创建）──
        if not os.path.exists(memory_path):
            print(f"  ℹ️  MEMORY.md 不存在，将由 init_workspace_structure 创建")
            return result

        with open(memory_path, "r", encoding="utf-8") as f:
            content = f.read()

        lines = content.splitlines()
        line_count = len(lines)
        result["line_count"] = line_count

        print(f"  📄 MEMORY.md 当前 {line_count} 行")

        # ── 检查是否已有记忆规则配置段 ──
        HAS_RULES_MARKER = "self-evolving-core 记忆规则"
        has_rules_section = HAS_RULES_MARKER in content

        # ── 生成域名列表（用于规则配置段）──
        domain_names = []
        for d in domains_list:
            if isinstance(d, dict):
                domain_names.append(d.get("key") or d.get("name") or str(d))
            elif isinstance(d, str):
                domain_names.append(d)
        domain_list_str = " / ".join(domain_names) if domain_names else "（由 --deploy 推断）"

        # ── 生成规则配置段文本 ──
        today_str = datetime.now().strftime("%Y-%m-%d")
        rules_block = f"""
## 📌 self-evolving-core 记忆规则（由 --deploy 自动生成，{today_str}）

### 域配置
- 当前域：{domain_list_str}
- 路由引擎：`domains/_shared/domain_router.py`
- 经验库：`domains/<域名>/experiences.json`（★ 具体经验存这里，不要存MEMORY.md）

### 记忆分层规则
- `MEMORY.md`（本文件）：**只存元层**——沟通规范、运行模式、架构概览、指针行
- `short-term-memory.md`：临时缓冲区，随时追加，`distill --from-stm` 提炼到本文件
- `domains/*/experiences.json`：具体操作经验、踩坑记录的最终归宿
- `YYYY-MM-DD.md`：当日工作日志，15天后自动归档到 `archive/`

### 触发规则（由 evolution_guardian.py log 自动检测）
- **R4**：本文件超 150 行 → 自动提示运行 `distill` 蒸馏
- **distill 命令**：`python3 domains/_shared/evolution_guardian.py distill [--dry-run]`
- **从短期记忆提炼**：`python3 domains/_shared/evolution_guardian.py distill --from-stm`
- **日志归档**：`python3 domains/_shared/evolution_guardian.py archive-logs [--days=15]`

### 写作规范
- ✅ 元层内容（保留）：称呼规范、运行模式、架构版本、已下沉经验的指针行
- ❌ 不应存此处：具体操作步骤、10行以上的项目经验 → 用 `distill` 自动下沉
"""

        # ── 若缺少规则段 → 追加 ──
        if not has_rules_section:
            new_content = content.rstrip() + rules_block
            try:
                with open(memory_path, "w", encoding="utf-8") as f:
                    f.write(new_content)
                result["rules_added"] = True
                result["status"] = "rules_added"
                print(f"  ✅ 已追加「self-evolving-core 记忆规则」配置段到 MEMORY.md")
                line_count = len(new_content.splitlines())
                result["line_count"] = line_count
                print(f"     追加后行数: {line_count}")
            except Exception as e:
                print(f"  ⚠️  追加规则段失败: {e}")
        else:
            print(f"  ℹ️  MEMORY.md 已包含记忆规则配置段，跳过追加")

        # ── 行数检查 → 提示蒸馏 ──
        if line_count > 150:
            result["status"] = "need_distill"
            print(f"\n  ⚠️  MEMORY.md 当前 {line_count} 行，超过 150 行目标")
            print(f"  📋 建议执行以下命令将具体经验下沉到域经验库：")
            print(f"     python3 domains/_shared/evolution_guardian.py distill --dry-run  # 先预览")
            print(f"     python3 domains/_shared/evolution_guardian.py distill            # 再执行")

            if not auto_confirm:
                print(f"\n  ❓ 是否现在立即执行 distill？(y/n): ", end="")
                try:
                    do_distill = input().strip().lower()
                except EOFError:
                    do_distill = "n"

                if do_distill == "y":
                    # 调用 evolution_guardian.py distill
                    import subprocess
                    guardian_path = os.path.join(
                        os.path.dirname(os.path.abspath(__file__)), "evolution_guardian.py"
                    )
                    if not os.path.exists(guardian_path):
                        # fallback: 从项目domains/_shared/找
                        guardian_path = os.path.join(root_dir, "domains", "_shared", "evolution_guardian.py")

                    if os.path.exists(guardian_path):
                        try:
                            subprocess.run(
                                [sys.executable, guardian_path, "distill", memory_path],
                                check=True
                            )
                            result["status"] = "distilled"
                        except Exception as e:
                            print(f"  ⚠️  distill执行出错: {e}")
                    else:
                        print(f"  ⚠️  未找到 evolution_guardian.py，请手动运行 distill 命令")
            else:
                print(f"  ℹ️  --yes 模式下跳过交互，请部署后手动运行 distill")
        else:
            if not result["rules_added"]:
                print(f"  ✅ MEMORY.md 行数正常（{line_count} ≤ 150），无需蒸馏")

        return result

    @staticmethod
    def init_workspace_structure(root_dir: str) -> dict:
        """
        ★ v4.4更新: 空白工作空间标准结构初始化

        当用户的工作空间是全新的（无任何标准结构）时，自动补全以下目录和文件：
          .workbuddy/memory/           — working memory目录
          .workbuddy/memory/archive/   — 日志归档目录（★v4.4新增）
          .workbuddy/memory/MEMORY.md  — 长期记忆模板（元层，目标<150行，★v4.4更新）
          .workbuddy/memory/YYYY-MM-DD.md — 今日日志
          .workbuddy/skills/           — skills目录（空）

        规则：
          - 已存在的文件/目录不覆盖
          - 不创建 SOUL.md（用户身份文件，应由用户自定义）
          - 只做补全，不修改现有内容

        返回: {
            "created": [文件路径列表],
            "skipped": [已存在的文件列表],
            "errors": [错误列表]
        }
        """
        result = {"created": [], "skipped": [], "errors": []}
        now = datetime.now()
        today_str = now.strftime("%Y-%m-%d")

        # ── 目录结构 ──
        dirs_to_ensure = [
            os.path.join(root_dir, ".workbuddy"),
            os.path.join(root_dir, ".workbuddy", "memory"),
            os.path.join(root_dir, ".workbuddy", "memory", "archive"),  # ★ v4.4: 归档目录
            os.path.join(root_dir, ".workbuddy", "skills"),
            os.path.join(root_dir, "workspace"),
            os.path.join(root_dir, "workspace", ".tmp"),
        ]
        for d in dirs_to_ensure:
            try:
                if not os.path.isdir(d):
                    os.makedirs(d, exist_ok=True)
                    result["created"].append(d + "/")
            except Exception as e:
                result["errors"].append(f"创建目录失败 {d}: {e}")

        # ── MEMORY.md 元层模板 ──
        memory_path = os.path.join(root_dir, ".workbuddy", "memory", "MEMORY.md")
        if not os.path.exists(memory_path):
            memory_template = f"""# 长期记忆（元层）

> **设计原则**：本文件只存"元信息"（框架规范、指针）。具体操作经验全部下沉到
> `domains/*/experiences.json`。目标保持 <150行，永不超限。
>
> 超限时运行：`python3 domains/_shared/evolution_guardian.py distill`
> 短期笔记请写到：`.workbuddy/memory/short-term-memory.md`（留档，不清空）

## 📌 沟通规范
- （在此填写你与AI助手的沟通偏好，如语言风格、称呼等）

## 📌 运行模式
- 唯一模式：Domain框架，所有自进化走 `--domain {{域名}}`

## 📌 Domain框架
- 路由引擎：`domains/_shared/domain_router.py`
- 部署完成后在此补充域列表（由 `--deploy` 自动生成）

## 📌 self-evolving-core 记忆规则
- MEMORY.md 只存元层，具体经验 → `domains/*/experiences.json`
- 短期笔记 → `short-term-memory.md`，提炼用 `distill --from-stm`
- R4触发（>150行）→ 运行 `distill` 蒸馏 | 日志15天后 `archive-logs` 归档

## 📌 项目约定
- （在此填写项目特有的约定、命名规范、注意事项等）

---
*初始化时间: {today_str}（由 self-evolving-core --deploy 自动创建）*
*完整经验详见 domains/*/experiences.json*
"""
            try:
                with open(memory_path, "w", encoding="utf-8") as f:
                    f.write(memory_template)
                result["created"].append(memory_path)
                print(f"  ✅ 创建: .workbuddy/memory/MEMORY.md（元层模板，目标<150行）")
            except Exception as e:
                result["errors"].append(f"创建MEMORY.md失败: {e}")
        else:
            result["skipped"].append(memory_path)
            print(f"  ℹ️  跳过: MEMORY.md（已存在）")

        # ── 今日日志 ──
        daily_log_path = os.path.join(root_dir, ".workbuddy", "memory", f"{today_str}.md")
        if not os.path.exists(daily_log_path):
            try:
                with open(daily_log_path, "w", encoding="utf-8") as f:
                    f.write(f"# {today_str} 工作日志\n\n"
                            f"> 由 self-evolving-core --deploy 初始化创建\n\n"
                            f"## 任务记录\n\n")
                result["created"].append(daily_log_path)
                print(f"  ✅ 创建: .workbuddy/memory/{today_str}.md（今日日志）")
            except Exception as e:
                result["errors"].append(f"创建今日日志失败: {e}")
        else:
            result["skipped"].append(daily_log_path)

        # ── task-registry目录（子agent任务注册表）──
        registry_dir = os.path.join(root_dir, ".workbuddy", "task-registry")
        registry_script = os.path.join(registry_dir, "task_registry.py")
        if not os.path.isdir(registry_dir):
            try:
                os.makedirs(registry_dir, exist_ok=True)
                result["created"].append(registry_dir + "/")
            except Exception as e:
                result["errors"].append(f"创建task-registry目录失败: {e}")

        # 如果技术实现文件不存在，创建最小可用版本
        if not os.path.exists(registry_script):
            try:
                with open(registry_script, "w", encoding="utf-8") as f:
                    f.write(
                        '#!/usr/bin/env python3\n'
                        '"""任务注册表 — 防止子Agent回调丢失（minimal版本）"""\n'
                        'import json, os, sys\n'
                        'from datetime import datetime\n\n'
                        'REGISTRY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "registry.json")\n\n'
                        'def _load():\n'
                        '    if os.path.exists(REGISTRY_FILE):\n'
                        '        with open(REGISTRY_FILE) as f: return json.load(f)\n'
                        '    return {"tasks": {}}\n\n'
                        'def _save(data):\n'
                        '    with open(REGISTRY_FILE, "w") as f: json.dump(data, f, ensure_ascii=False, indent=2)\n\n'
                        'def cmd_check():\n'
                        '    data = _load()\n'
                        '    unreported = [t for t in data["tasks"].values() \n'
                        '                  if t.get("status") == "completed" and not t.get("reported")]\n'
                        '    if unreported:\n'
                        '        print(f"\\n🔴 发现 {len(unreported)} 个未通知任务:")\n'
                        '        for t in unreported: print(f"  [{t[\'id\']}] {t[\'desc\']}")\n'
                        '    else:\n'
                        '        print("✅ 无未通知任务")\n\n'
                        'if __name__ == "__main__":\n'
                        '    if len(sys.argv) > 1 and sys.argv[1] == "check": cmd_check()\n'
                        '    else: print("用法: task_registry.py check")\n'
                    )
                result["created"].append(registry_script)
                print(f"  ✅ 创建: .workbuddy/task-registry/task_registry.py（最小版）")
            except Exception as e:
                result["errors"].append(f"创建task_registry.py失败: {e}")

        return result

    def _init_domain_structure(
        self,
        root_dir: str,
        auto_confirm: bool = False,
        inferred_domains_override: list = None,
        initial_experiences: dict = None,
    ) -> dict:
        """
        ★ v4.2升级: 初始化Domain大一统目录结构

        参数:
          inferred_domains_override: 外部传入的域列表（来自交互式确认流程）
            如果为None，则内部调用智能分析
          initial_experiences: 从历史记忆提炼的初始经验 {domain_key: [经验列表]}

        核心保证：零硬编码域，所有域都来自用户环境推断或用户确认。
        """
        result = {
            "success": True,
            "initialized": [],
            "changes": 0,
            "errors": [],
            "inferred_domains": [],  # ★ v4.1: 记录推断出的域
        }

        domains_root = os.path.join(root_dir, "domains")
        shared_dir = os.path.join(domains_root, "_shared")

        # ★ v4.2: 域推断——优先使用外部传入的确认域列表，否则内部智能推断
        if inferred_domains_override is not None:
            # 来自交互式确认流程，直接使用
            inferred_list = inferred_domains_override
            print(f"\n  🧩 使用已确认的域配置（{len(inferred_list)}个域）:")
        else:
            # 内部推断（非fresh_install的其他路径调用，如migrate）
            print(f"\n  🔍 分析工作空间，推断业务领域...")
            workspace_signals = AgentUpgrader._analyze_workspace(root_dir)
            inferred_list = AgentUpgrader._infer_domains(workspace_signals, root_dir)
            print(f"\n  🧩 推断领域方案（{len(inferred_list)}个域）:")

        for d in inferred_list:
            src_tag = {"agent_role": "来自Agent配置", "memory_keywords": "来自历史记忆",
                       "dir_name": "来自目录名", "fallback": "通用默认",
                       "user_input": "用户自定义"}.get(d.get("source", ""), "")
            print(f"     [{d['key']:<14}] 《{d['name']}》 — {d['description']} ({src_tag})")

        result["inferred_domains"] = inferred_list

        # 将 list 转为 dict（key→info）供后续使用
        domain_definitions = {
            d["key"]: {
                "name": d["name"],
                "description": d["description"],
                "trigger_keywords": d.get("trigger_keywords", []),
                "role_name": d.get("role_name", ""),
            }
            for d in inferred_list
        }

        # 创建 domains/ 根目录
        try:
            os.makedirs(domains_root, exist_ok=True)
            result["initialized"].append("domains/")
            result["changes"] += 1
            print(f"  ✅ 创建: domains/")
        except Exception as e:
            result["success"] = False
            result["errors"].append(f"创建domains/失败: {e}")
            return result

        # 创建 _shared/ + 全局文件
        try:
            os.makedirs(shared_dir, exist_ok=True)

            # evo-config.json (如果不存在)
            config_file = os.path.join(shared_dir, "evo-config.json")
            if not os.path.exists(config_file):
                config_data = {
                    "schema_version": "4.0",
                    "description": f"大一统自进化系统 — 由upgrade_agent.py v4.0自动初始化",
                    "last_updated": datetime.now().isoformat(),
                    "architecture": "unified-domain",
                    "self_evolution_enabled": True,
                    "evolution_version": "4.0",
                    "domains": {
                        name: {
                            "name": info["name"],
                            "experience_file": f"domains/{name}/experiences.json",
                            "memory_file": f"domains/{name}/memory.json",
                            "immune_rules_file": f"domains/{name}/immune_rules.json",
                        }
                        for name, info in domain_definitions.items()
                    },
                    "global_files": {
                        "config": "domains/_shared/evo-config.json",
                        "feedback": "domains/_shared/evo-feedback.json",
                        "l4_working_memory": "workspace/.tmp/l4-memory.json",
                        "admin_experiences": "domains/_shared/admin-experiences.json",
                    },
                }
                with open(config_file, 'w', encoding='utf-8') as f:
                    json.dump(config_data, f, ensure_ascii=False, indent=2)
                result["initialized"].append("domains/_shared/evo-config.json")
                result["changes"] += 1
                print(f"  ✅ 创建: domains/_shared/evo-config.json")

            # evo-feedback.json
            feedback_file = os.path.join(shared_dir, "evo-feedback.json")
            if not os.path.exists(feedback_file):
                with open(feedback_file, 'w', encoding='utf-8') as f:
                    json.dump({"schema_version": "4.0", "feedback_records": [], "trigger_words_config": {
                        "strong": ["蠢模型", "又错了", "完全不对", "废物"],
                        "medium": ["不对", "有问题", "重做", "错了"],
                        "mild": ["再想想", "可以更好", "不太对"],
                    }}, f, ensure_ascii=False, indent=2)
                result["initialized"].append("domains/_shared/evo-feedback.json")
                result["changes"] += 1
                print(f"  ✅ 创建: domains/_shared/evo-feedback.json")

            # admin-experiences.json
            admin_exp_file = os.path.join(shared_dir, "admin-experiences.json")
            if not os.path.exists(admin_exp_file):
                with open(admin_exp_file, 'w', encoding='utf-8') as f:
                    json.dump({"schema_version": "4.0", "experiences": []}, f, ensure_ascii=False, indent=2)
                result["initialized"].append("domains/_shared/admin-experiences.json")
                result["changes"] += 1
                print(f"  ✅ 创建: domains/_shared/admin-experiences.json")

            # ★ index.json — Router触发词索引（★v4.1: 从推断域动态生成，零硬编码）
            index_file = os.path.join(shared_dir, "index.json")
            if not os.path.exists(index_file):
                _index_domains = {
                    d_key: {
                        "name": d_info["name"],
                        "path": f"domains/{d_key}/",
                        "role_name": d_info.get("role_name", ""),
                        "trigger_keywords": d_info.get("trigger_keywords", []),
                        "experience_count": 0,
                    }
                    for d_key, d_info in domain_definitions.items()
                }
                _index_template = {
                    "schema_version": "1.0",
                    "description": "大一统自进化系统 — 领域索引（由upgrade_agent.py --deploy智能生成）",
                    "last_updated": datetime.now().isoformat(),
                    "domains": _index_domains,
                    "cross_domain_links": [],
                    "total_experiences": 0,
                    "total_domains": len(domain_definitions),
                }
                with open(index_file, 'w', encoding='utf-8') as f:
                    json.dump(_index_template, f, ensure_ascii=False, indent=2)
                result["initialized"].append("domains/_shared/index.json")
                result["changes"] += 1
                print(f"  ✅ 创建: domains/_shared/index.json ({len(domain_definitions)}个域)")


            # evolution-protocol.md（协议文档，从源环境复制或创建简化版）
            protocol_file = os.path.join(shared_dir, "evolution-protocol.md")
            if not os.path.exists(protocol_file):
                # 尝试从源项目复制
                _src_protocol = os.path.join(_project_root if '_project_root' in dir() else "", "domains", "_shared", "evolution-protocol.md") if '_project_root' in dir() else ""
                if _src_protocol and os.path.exists(_src_protocol):
                    shutil.copy2(_src_protocol, protocol_file)
                else:
                    with open(protocol_file, 'w', encoding='utf-8') as f:
                        f.write("# 自进化协议 v4.0\n> 由 upgrade_agent.py --deploy 自动生成\n> 完整版请参考SKILL.md附录或源项目的 domains/_shared/evolution-protocol.md\n")
                result["initialized"].append("domains/_shared/evolution-protocol.md")
                result["changes"] += 1
                print(f"  ✅ 创建: domains/_shared/evolution-protocol.md")

        except Exception as e:
            result["success"] = False
            result["errors"].append(f"创建共享文件失败: {e}")
            return result

        # ★ v4.1: 复制两个核心脚本到 domains/_shared/
        # evolution_guardian.py: 自包含实现版（直接操作JSON，零外部依赖）
        # domain_router.py:      领域路由引擎（内嵌经验检索+免疫预检）
        # 两者都从 domains/_shared/ 源取（自包含实现）；
        # skill/scripts/ 里的 evolution_guardian.py 是wrapper，不能复制给用户
        _SCRIPT_FILES = ["domain_router.py", "evolution_guardian.py"]
        scripts_copied = 0
        scripts_source = None

        # 策略: 按优先级查找脚本源（必须是自包含实现的那份）
        #   P0: 当前项目环境的 domains/_shared/（开发环境一定有自包含版）
        #   P1: scripts/目录自身（仅当P0不可用时，注意此处的guardian是wrapper）
        _candidate_sources = []
        # P0: 从当前项目的 domains/_shared/ 获取自包含实现
        _skill_dir_parts = SKILL_DIR.rstrip(os.sep).split(os.sep)
        if len(_skill_dir_parts) >= 4:
            _project_root = os.sep.join(_skill_dir_parts[:-3])
            _candidate_sources.append(os.path.join(_project_root, "domains", "_shared"))
        # P1: scripts/目录（router可从此处取，guardian是wrapper版仅作备用）
        _candidate_sources.append(SCRIPT_DIR)
        for candidate in _candidate_sources:
            if os.path.isdir(candidate) and os.path.exists(os.path.join(candidate, "evolution_guardian.py")):
                scripts_source = candidate
                break

        if scripts_source:
            for script_name in _SCRIPT_FILES:
                src = os.path.join(scripts_source, script_name)
                dst = os.path.join(shared_dir, script_name)
                if not os.path.exists(dst) and os.path.exists(src):
                    try:
                        shutil.copy2(src, dst)
                        result["initialized"].append(f"domains/_shared/{script_name}")
                        result["changes"] += 1
                        scripts_copied += 1
                        print(f"  ✅ 复制: domains/_shared/{script_name}")
                    except Exception as copy_err:
                        result["errors"].append(f"复制{script_name}失败: {copy_err}")
            if scripts_copied > 0:
                print(f"  📦 已复制{scripts_copied}个核心脚本到 domains/_shared/")
            elif scripts_copied == 0 and len(_SCRIPT_FILES) > 0:
                print(f"  ⚠️  核心脚本未复制（源文件不存在或目标已存在）")
                print(f"     用户需确保 domains/_shared/ 中有: {', '.join(_SCRIPT_FILES)}")
        else:
            print(f"  ⚠️  未找到脚本源目录，跳过脚本复制")
            print(f"     用户可从 skill 发布包获取 domains/_shared/*.py 脚本")

        # 创建5个域目录及基础文件
        for domain_name, domain_info in domain_definitions.items():
            domain_path = os.path.join(domains_root, domain_name)
            try:
                os.makedirs(domain_path, exist_ok=True)

                # memory.json
                memory_file = os.path.join(domain_path, "memory.json")
                if not os.path.exists(memory_file):
                    with open(memory_file, 'w', encoding='utf-8') as f:
                        json.dump({"statistics": {"total_tasks": 0, "success_count": 0, "failed_count": 0, "total_tokens": 0, "total_duration_sec": 0}, "recent_tasks": []}, f, ensure_ascii=False, indent=2)
                    result["changes"] += 1

                # experiences.json — ★v4.2: 如有初始经验则写入，否则空模板
                exp_file = os.path.join(domain_path, "experiences.json")
                if not os.path.exists(exp_file):
                    domain_init_exps = []
                    if initial_experiences and domain_name in initial_experiences:
                        domain_init_exps = initial_experiences[domain_name]
                    with open(exp_file, 'w', encoding='utf-8') as f:
                        json.dump(
                            {"schema_version": "4.2", "experiences": domain_init_exps},
                            f, ensure_ascii=False, indent=2
                        )
                    result["changes"] += 1
                    if domain_init_exps:
                        print(f"  ✅ 创建: domains/{domain_name}/experiences.json "
                              f"({len(domain_init_exps)}条初始经验)")

                # immune_rules.json — ★v4.1: 全部空模板，零项目专属预设规则
                # 用户的免疫规则应从真实任务经验中自动提炼，不应预填
                rules_file = os.path.join(domain_path, "immune_rules.json")
                if not os.path.exists(rules_file):
                    with open(rules_file, 'w', encoding='utf-8') as f:
                        json.dump({"schema_version": "4.0", "rules": []}, f, ensure_ascii=False, indent=2)
                    result["changes"] += 1

                # evolution.log
                log_file = os.path.join(domain_path, "evolution.log")
                if not os.path.exists(log_file):
                    with open(log_file, 'w', encoding='utf-8') as f:
                        write_log_header = True
                    result["changes"] += 1

                result["initialized"].append(f"domains/{domain_name}/")
                print(f"  ✅ 创建: domains/{domain_name}/ ({domain_info['name']})")

            except Exception as e:
                result["errors"].append(f"创建{domain_name}域失败: {e}")

        # workspace/.tmp/l4-memory.json
        tmp_dir = os.path.join(root_dir, "workspace", ".tmp")
        try:
            os.makedirs(tmp_dir, exist_ok=True)
            l4_file = os.path.join(tmp_dir, "l4-memory.json")
            if not os.path.exists(l4_file):
                with open(l4_file, 'w', encoding='utf-8') as f:
                    json.dump({
                        "session_id": "",
                        "current_task": "",
                        "domain_active": None,
                        "subtasks": [],
                        "errors": [],
                        "corrections": [],
                        "verified_methods": [],
                        "created_at": datetime.now().isoformat(),
                    }, f, ensure_ascii=False, indent=2)
                result["initialized"].append("workspace/.tmp/l4-memory.json")
                result["changes"] += 1
                print(f"  ✅ 创建: workspace/.tmp/l4-memory.json")
        except Exception as e:
            result["errors"].append(f"创建L4记忆文件失败: {e}")

        # ★ v4.5新增: 注入 Domain 模式 IDENTITY/SOUL 钩子
        # 关键修复: 之前 Domain 模式部署完全不写入 IDENTITY.md，
        # 导致 AI 不知道每次任务后必须 log → R1-R4 永不触发 → 自进化系统失效
        print(f"\n  🧬 Step: 注入自进化触发钩子到 IDENTITY/SOUL.md ...")
        hook_result = AgentUpgrader._inject_domain_hooks_to_identity(root_dir)
        if hook_result["injected"]:
            for f in hook_result["injected"]:
                print(f"  ✅ 钩子已注入: {f}")
                result["initialized"].append(f"hook:{f}")
                result["changes"] += 1
        if hook_result["skipped"]:
            for f in hook_result["skipped"]:
                print(f"  ℹ️  跳过(已含钩子): {f}")
        if hook_result["warnings"]:
            for w in hook_result["warnings"]:
                print(f"  ⚠️  {w}")

        if result["errors"]:
            result["success"] = False

        return result

    @staticmethod
    def _inject_domain_hooks_to_identity(root_dir: str) -> dict:
        """★ v4.5新增: 将 Domain 模式钩子注入用户的 IDENTITY.md / SOUL.md

        策略（v4.5.1 修正版）:
          1. 优先策略 — **项目级文件**（`{root}/SOUL.md` / `{root}/IDENTITY.md`）
             - 这些是项目自定义文件，注入安全
             - 只要任一存在就注入，全部成功后停止
          2. 兜底策略 — 项目级**全部不存在**时，才注入到用户级
             - 仅 `~/.workbuddy/IDENTITY.md`（不动 SOUL.md，那是个人灵魂）
          3. 检测已含钩子（v4.5标记或任何形式的旧钩子）→ 跳过
          4. 注入位置：文件末尾追加

        返回: {injected: [...], skipped: [...], warnings: [...]}
        """
        result = {"injected": [], "skipped": [], "warnings": []}

        HOOK_MARKER = "self-evolving-core v4.5 自动注入"
        # 已含任何形式的自进化钩子的特征（含手写自定义版）→ 跳过
        OLD_MARKERS = [
            "自进化触发钩子",
            "self-evolving-core v",
            "自进化工作流钩子",  # 用户手写常用标题
            "档位1：静默记账",  # 手写钩子常见特征
            "evolution_guardian.py log",  # 已含log命令的视为已有钩子
        ]

        def _try_inject(path: str) -> str:
            """返回 'injected' / 'skipped' / 'old_skipped' / 'error'"""
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                if HOOK_MARKER in content:
                    return "skipped"
                if any(m in content for m in OLD_MARKERS):
                    return "old_skipped"
                new_content = content.rstrip() + "\n" + AgentUpgrader.HOOK_TEXT_DOMAIN
                with open(path, "w", encoding="utf-8") as f:
                    f.write(new_content)
                return "injected"
            except Exception as e:
                result["warnings"].append(f"注入 {path} 失败: {e}")
                return "error"

        # ── 第一优先级：项目级文件 ──
        project_files = []
        for fname in ["SOUL.md", "IDENTITY.md"]:
            p = os.path.join(root_dir, fname)
            if os.path.exists(p):
                project_files.append(p)

        any_project_handled = False
        for p in project_files:
            status = _try_inject(p)
            if status == "injected":
                result["injected"].append(p)
                any_project_handled = True
            elif status == "skipped":
                result["skipped"].append(p)
                any_project_handled = True
            elif status == "old_skipped":
                result["skipped"].append(p)
                result["warnings"].append(
                    f"{p} 已含旧版/自定义钩子，跳过自动注入。"
                    "如需更新到v4.5（三段式蒸馏+R4规则），请手动覆盖。"
                )
                any_project_handled = True

        # ── 兜底：项目级文件全无时，才注入用户级 IDENTITY.md ──
        if not any_project_handled:
            home = os.path.expanduser("~")
            user_identity = os.path.join(home, ".workbuddy", "IDENTITY.md")
            if os.path.exists(user_identity):
                status = _try_inject(user_identity)
                if status == "injected":
                    result["injected"].append(user_identity)
                elif status == "skipped":
                    result["skipped"].append(user_identity)
                elif status == "old_skipped":
                    result["skipped"].append(user_identity)
                    result["warnings"].append(
                        f"{user_identity} 已含旧版钩子，跳过自动注入。"
                    )
            else:
                result["warnings"].append(
                    "未找到任何 IDENTITY.md / SOUL.md（已搜索: 项目根 + ~/.workbuddy/IDENTITY.md）。"
                    "AI将不知道每次任务后必须log，请手动复制以下钩子到你的身份文件末尾：\n"
                    + AgentUpgrader.HOOK_TEXT_DOMAIN[:500] + "...\n"
                )

        return result

    def _deploy_domain_mode(self, root_dir: str, arch_result: dict, report: dict, auto_confirm: bool) -> dict:
        """★ v4.0新增: Domain架构已存在时的验证和补充"""
        print("\n  🔍 验证现有Domain架构完整性...")

        domains_configured = arch_result["details"]["domains_configured"]
        verified = 0
        total = len(domains_configured) * 4  # 每域检查4个核心文件

        for dinfo in domains_configured:
            dname = dinfo["name"]
            dpath = os.path.join(root_dir, "domains", dname)
            for fname in ["experiences.json", "memory.json", "immune_rules.json", "role-snapshot.json"]:
                fpath = os.path.join(dpath, fname)
                total += 1
                if os.path.exists(fpath):
                    verified += 1
                else:
                    # 尝试补全缺失文件
                    try:
                        with open(fpath, 'w', encoding='utf-8') as f:
                            if "rules" in fname:
                                json.dump({"schema_version": "4.0", "rules": []}, f, ensure_ascii=False, indent=2)
                            elif "experience" in fname:
                                json.dump({"schema_version": "4.0", "experiences": []}, f, ensure_ascii=False, indent=2)
                            else:
                                json.dump({}, f, ensure_ascii=False, indent=2)
                        verified += 1
                        report["total_changes"] += 1
                        print(f"  🔧 补全: domains/{dname}/{fname}")
                    except Exception:
                        pass

        report["verification"] = {
            "result": "domain_verified",
            "all_passed": verified >= total * 0.75,
            "passed": verified,
            "total": total,
            "failed_items": [],
        }

        # ★ v4.5新增: 已有Domain架构的老用户也要补全钩子（之前版本没注入过）
        print(f"\n  🧬 检查并补全 IDENTITY/SOUL.md 钩子...")
        hook_result = AgentUpgrader._inject_domain_hooks_to_identity(root_dir)
        for f in hook_result["injected"]:
            print(f"  ✅ 钩子已注入: {f}")
            report["total_changes"] += 1
        for f in hook_result["skipped"]:
            print(f"  ℹ️  跳过(已含钩子): {f}")
        for w in hook_result["warnings"]:
            print(f"  ⚠️  {w}")

        self._print_deploy_report_v4(report)
        return report

    @staticmethod
    def _print_deploy_report_v4(report: dict):
        """v4.0部署报告输出格式"""
        arch = report.get("architecture_detected", {})
        mode = arch.get('mode', 'N/A')
        skill_ver = report.get('skill_version', 'N/A')
        arch_ver = report.get('architecture_version', '4.0')
        domains_init = len(report.get('domains_initialized', []))
        agents_up = report.get('agents_upgraded', [])
        agents_str = ', '.join(agents_up) if agents_up else '无'
        total_changes = report['total_changes']
        v = report.get('verification', {})
        v_ok = v.get('all_passed', False)
        v_status = "✅ 通过" if v_ok else "⚠️ 有警告"

        # ★ v4.5.3: 列出可用域，让用户/AI知道<domain>可填什么
        try:
            domains_root = os.path.join(report.get("root", ""), "domains")
            available_domains = sorted([
                d for d in os.listdir(domains_root)
                if d != "_shared" and not d.startswith(".")
                and os.path.isdir(os.path.join(domains_root, d))
            ]) if os.path.isdir(domains_root) else []
        except Exception:
            available_domains = []
        domain_hint = (
            f"\n  ⚠️  替换 <domain> 为以下任一: {', '.join(available_domains)}"
            if available_domains else
            "\n  ⚠️  <domain> 替换为本次部署生成的实际域名（看上方'域已初始化'）"
        )

        print("\n" + "=" * 65)
        print("  📊 v4.0 部署完成报告")
        print("=" * 65)
        print(f"""
  架构检测:   {mode}
  Skill版本:  {skill_ver}
  架构版本:   {arch_ver}
  域已初始化: {domains_init} 个
  Agent升级:  {len(agents_up)} 个 ({agents_str})
  总操作数:   {total_changes} 项
  验证状态:   {v_status}

  💡 下一步速查（按使用频率排序）:

  【★ 每次任务完成后必做】
    python3 domains/_shared/evolution_guardian.py log <domain> "<任务>" <success|failed|partial>
    # 失败时一步写经验+免疫规则:
    python3 domains/_shared/evolution_guardian.py log <domain> "<任务>" failed timeout API 0 0 --lesson="教训内容"
{domain_hint}

  【★ 每天结束时（常规蒸馏流程）】
    python3 domains/_shared/evolution_guardian.py distill --from-daily   # 第1步: 日志→STM
    python3 domains/_shared/evolution_guardian.py distill --from-stm     # 第2步: STM→MEMORY.md
    # 仅 MEMORY.md 超 150行 时:
    python3 domains/_shared/evolution_guardian.py distill                # 第3步(应急)

  【收到用户负面反馈时】
    python3 domains/_shared/evolution_guardian.py feedback admin negative strong "触发词" "上下文"

  【任务前路由（推荐）】
    python3 domains/_shared/domain_router.py "<任务描述>"

  【月度维护】
    python3 domains/_shared/evolution_guardian.py archive-logs         # 归档旧日志(15天)
    python3 domains/_shared/evolution_guardian.py check <domain>       # 域诊断报告

  💡 钩子已自动注入到你的 SOUL.md/IDENTITY.md。
     从下次任务开始，R1-R4 自动触发，进化系统会自己管自己。
""")

    def check(self) -> dict:
        """检测当前架构状态"""
        result = {
            "agent": self.agent_name,
            "dir": self.agent_dir,
            "exists": os.path.exists(self.agent_dir),
            "needs_upgrade": False,
            "current_status": {},
            "recommended_actions": [],
        }
        
        if not result["exists"]:
            result["needs_upgrade"] = True
            result["recommended_actions"].append(f"❌ Agent目录不存在: {self.agent_dir}")
            return result
        
        # 检查 self-evolution 目录
        evo_exists = os.path.exists(self.evo_dir)
        result["current_status"]["self-evolution"] = evo_exists
        
        if evo_exists:
            # 检查现有文件
            existing_files = os.listdir(self.evo_dir)
            for f in self.REQUIRED_FILES["self-evolution"]:
                if f in existing_files:
                    result["current_status"][f] = f"✅ 存在"
                else:
                    result["current_status"][f] = f"❌ 缺失"
                    result["needs_upgrade"] = True
                    result["recommended_actions"].append(f"创建 {f}")
            
            # 检查新文件是否存在
            for new_f, desc in self.NEW_FILES.items():
                new_path = os.path.join(self.evo_dir, new_f)
                if os.path.exists(new_path):
                    result["current_status"][new_f] = f"✅ 已有"
                else:
                    result["current_status"][new_f] = f"⬜ 待创建"
                    result["needs_upgrade"] = True
                    result["recommended_actions"].append(f"添加 {new_f} ({desc})")
            
            # 检查 IDENTITY.md 是否有触发钩子
            has_hooks = False
            if os.path.exists(self.identity_path):
                with open(self.identity_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                # v3.0: 兼容新旧两种钩子标记（注意：content在with块外使用，但if块内已赋值）
                has_hooks = ("pre_task_check" in content or "自进化触发钩子" in content 
                            or "核心经验速查" in content or "自进化能力（强制执行）" in content)
            
            result["current_status"]["identity_hooks"] = "✅ 已植入" if has_hooks else "⬜ 未植入"
            if not has_hooks:
                result["needs_upgrade"] = True
                result["recommended_actions"].append("在 IDENTITY.md 中植入自进化触发钩子")
            
            # ★ v3.1: 检查是否有AUTO_SYNC标记（双保险机制所需）
            has_auto_sync = False
            if os.path.exists(self.identity_path):
                with open(self.identity_path, 'r', encoding='utf-8') as f:
                    content_sync = f.read()
                has_auto_sync = "AUTO_SYNC_START" in content_sync
            result["current_status"]["auto_sync"] = "✅ 已植入" if has_auto_sync else "⬜ 未植入"
            if has_hooks and not has_auto_sync:
                result["needs_upgrade"] = True
                result["recommended_actions"].append("在 IDENTITY.md 中植入 AUTO_SYNC 标记（v3.1双保险机制）")
            
            # 导入种子经验（仅当有实际预置数据时）
            seed_path = os.path.join(SCRIPT_DIR, "experience_store.json")
            exp_path = os.path.join(self.evo_dir, "experiences_v2.json")
            
            if os.path.exists(exp_path):
                result["current_status"]["seed_experiences"] = "✅ 已有经验库"
            elif os.path.exists(seed_path):
                seed_count = self._count_seeds()
                if seed_count > 0:
                    result["current_status"]["seed_experiences"] = f"⬜ 待导入({seed_count}条)"
                    result["needs_upgrade"] = True
                    result["recommended_actions"].append(f"导入种子经验({seed_count}条)")
                else:
                    result["current_status"]["seed_experiences"] = "✅ 跳过（无预置种子）"
            else:
                result["current_status"]["seed_experiences"] = "✅ 无种子文件"
        
        else:
            result["needs_upgrade"] = True
            result["recommended_actions"].append("创建完整的 self-evolution 目录结构")
        
        return result
    
    def _count_seeds(self) -> int:
        """统计种子经验数量"""
        seed_path = os.path.join(SCRIPT_DIR, "experience_store.json")
        try:
            with open(seed_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return len(data.get("experiences", []))
        except:
            return 0
    
    def plan_upgrade(self) -> list:
        """规划升级步骤"""
        self.planned_changes = []
        
        # 1. 确保self-evolution目录存在
        if not os.path.exists(self.evo_dir):
            self.planned_changes.append(("create_dir", self.evo_dir, "创建self-evolution目录"))
        
        # 2. 检查并补全REQUIRED_FILES中的每个文件
        for req_f in self.REQUIRED_FILES["self-evolution"]:
            target = os.path.join(self.evo_dir, req_f)
            if not os.path.exists(target):
                self.planned_changes.append(("create_file", target, f"创建{req_f}"))
        
        # 3. 检查并补全NEW_FILES（v2新增文件）
        for new_f, desc in self.NEW_FILES.items():
            target = os.path.join(self.evo_dir, new_f)
            if not os.path.exists(target):
                self.planned_changes.append(("create_file", target, f"创建{new_f} ({desc})"))
        
        # 3. 植入IDENTITY.md钩子
        if os.path.exists(self.identity_path):
            with open(self.identity_path, 'r', encoding='utf-8') as f:
                content = f.read()
            if ("pre_task_check" not in content and "自进化触发钩子" not in content
                    and "核心经验速查" not in content):
                self.planned_changes.append(("modify_identity", self.identity_path, "植入自进化触发钩子"))
        
        # 4. 导入种子经验（仅当有种子数据时）
        seed_path = os.path.join(SCRIPT_DIR, "experience_store.json")
        exp_path = os.path.join(self.evo_dir, "experiences_v2.json")
        if os.path.exists(seed_path) and not os.path.exists(exp_path):
            seed_count = self._count_seeds()
            if seed_count > 0:
                self.planned_changes.append(("import_seeds", seed_path, exp_path, f"导入{seed_count}条种子经验"))
        
        # 5. 复制核心脚本（仅当目标目录不存在且源存在时）
        scripts_dest = os.path.join(self.evo_dir, "scripts")
        src_scripts = os.path.join(SCRIPT_DIR, "scripts")
        if not os.path.exists(scripts_dest) and os.path.exists(src_scripts):
            self.planned_changes.append(("copy_scripts", SCRIPT_DIR, scripts_dest, "复制核心脚本到agent目录"))
        
        return self.planned_changes
    
    def execute_upgrade(self, auto_confirm=False) -> bool:
        """执行升级"""
        self.plan_upgrade()
        
        if not self.planned_changes:
            print("✅ 无需升级，架构已是最新。")
            return True
        
        # 展示计划
        print("\n" + "=" * 60)
        print(f"📋 升级计划 [{self.agent_name}]")
        print("=" * 60)
        for i, change in enumerate(self.planned_changes, 1):
            action = change[0]
            desc = change[-1]
            icon = {"create_dir": "📁", "create_file": "📄", "modify_identity": "✏️",
                   "import_seeds": "🌱", "copy_scripts": "📦"}.get(action, "🔧")
            print(f"  {i}. {icon} {desc}")
        
        # 确认
        if not auto_confirm:
            print("\n是否继续？(y/n): ", end="")
            try:
                confirm = input().strip().lower()
            except EOFError:
                confirm = "n"
            if confirm != "y":
                print("❌ 升级已取消。")
                return False
        
        # 执行
        print("\n🔄 开始执行...")
        
        for change in self.planned_changes:
            action = change[0]
            try:
                if action == "create_dir":
                    os.makedirs(change[1], exist_ok=True)
                    print(f"  ✅ 创建目录: {change[1]}")
                    
                elif action == "create_file":
                    fname = os.path.basename(change[1])
                    
                    # 根据不同文件名使用对应模板
                    if fname == "config.json":
                        data = {
                            "schema_version": "2.1",
                            "enabled": True,
                            "capabilities": ["memory_system", "immune_system", "pattern_detection"],
                            "trigger_config": {
                                "consecutive_error_threshold": 2,
                                "negative_feedback_threshold": 1,
                                "token_anomaly_multiplier": 1.5,
                                "success_rate_threshold": 0.7,
                                "check_interval_tasks": 3,
                            },
                            "immune_config": {
                                "auto_generate": True,
                                "confidence_threshold": 0.7,
                                "max_rules": 50,
                            }
                        }
                    elif fname == "memory.json":
                        data = {
                            "schema_version": "2.1",
                            "task_log": [],
                            "statistics": {
                                "total_tasks": 0, "success_count": 0,
                                "failure_count": 0, "partial_count": 0,
                                "total_tokens": 0, "total_duration_sec": 0,
                                "last_task_time": None, "since_last_review": 0,
                                "since_last_check": 0
                            },
                            "created_at": datetime.now().isoformat(),
                            "last_updated": None
                        }
                    elif fname == "feedback.json":
                        data = {"schema_version": "2.1", "feedbacks": [], "unresolved_count": 0, "last_update": None}
                    elif fname == "evolution.log":
                        with open(change[1], 'w', encoding='utf-8') as f:
                            f.write(f"# Evolution Log - Created by self-evolving-core v3.0\n")
                            f.write(f"# Created: {datetime.now().isoformat()}\n")
                        print(f"  ✅ 创建文件: {fname}")
                        continue
                    elif fname == "immune_rules.json":
                        data = {"schema_version": "2.1", "rules": [], "total_rules": 0, "last_updated": None}
                    elif fname == "working_memory.json":
                        data = {"schema_version": "2.1", "current_session_id": None, "verified_methods": [], "context_notes": [], "session_start_time": None}
                    elif fname == "experiences_v2.json":
                        data = {"schema_version": "2.0", "experiences": [], "last_updated": None, "total_count": 0}
                    else:
                        data = {}
                    
                    with open(change[1], 'w', encoding='utf-8') as f:
                        json.dump(data, f, ensure_ascii=False, indent=2)
                    print(f"  ✅ 创建文件: {fname}")
                    
                elif action == "modify_identity":
                    self._implant_identity_hooks(change[1])
                    print(f"  ✅ 更新: IDENTITY.md（植入触发钩子）")
                    
                elif action == "import_seeds":
                    shutil.copy2(change[1], change[2])
                    print(f"  ✅ 导入种子经验: {self._count_seeds()}条")
                    
                elif action == "copy_scripts":
                    src_scripts = os.path.join(change[1], "scripts")
                    if os.path.exists(src_scripts) and not os.path.exists(change[2]):
                        shutil.copytree(src_scripts, change[2])
                        scripts = os.listdir(src_scripts)
                        print(f"  ✅ 复制脚本: {len(scripts)}个文件")
                    else:
                        print(f"  ⏭️ 脳本目录已存在或源不存在，跳过")
                
                self.executed_changes.append(change)
                
            except Exception as e:
                print(f"  ❌ 失败: {change[-1]} — {e}")
                self.warnings.append(str(e))
        
        # 最终报告
        print("\n" + "=" * 60)
        print(f"🎉 升级完成！[{self.agent_name}]")
        print("=" * 60)
        print(f"  执行: {len(self.executed_changes)}项成功 / {len(self.warnings)}项警告")
        
        # 验证
        final_check = self.check()
        if not final_check["needs_upgrade"]:
            print("  ✅ 架构状态: 最新")
        else:
            print(f"  ⚠️ 仍需处理: {len(final_check['recommended_actions'])}项")
            for a in final_check["recommended_actions"]:
                print(f"     - {a}")
        
        print("\n💡 下一步:")
        print("  1. 在你的Agent工作流程中植入 pre_task_check 和 post_task_learn 调用")
        print("  2. 执行一次测试验证：")
        print(f'     python3 {SCRIPT_DIR}/pre_task_check.py --agent {self.agent_name} --task "测试"')
        
        return len(self.warnings) == 0
    
    def _implant_identity_hooks(self, identity_path: str):
        """★ v3.0: 在IDENTITY.md前部注入触发钩子（而非末尾追加）
        
        设计原理：
        v2.x的钩子追加到文件末尾（第442行+），被超长prompt淹没，
        导致pre_task_check.py从未被实际调用过。
        v3.0改为注入到文件前1/3处（基本身份信息之后），确保100%_visible。
        
        v3.0.1修复: 如果只有旧版末尾钩子(没有新版前部钩子)，执行迁移：
        先删除旧版末尾钩子，再注入新版前部钩子。
        """
        with open(identity_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # ★ v3.1: 检查是否已有AUTO_SYNC标记（双保险机制）
        has_auto_sync = "AUTO_SYNC_START" in content
        
        # ★ v3.0: 检查新版前部标记
        if "核心经验速查" in content and "自进化能力（强制执行）" in content:
            # 已有v3.0前部钩子，但检查是否缺少v3.1的AUTO_SYNC标记
            if not has_auto_sync:
                # 补注入AUTO_SYNC标记到"核心经验速查"段落中
                print(f"  🔄 检测到v3.0钩子但缺少AUTO_SYNC标记，正在补充...")
                self._inject_auto_sync_only(identity_path)
            return
        
        # ★ v3.1: 如果已有新式钩子（有pre_task_check但没有旧版v2标记），检查AUTO_SYNC
        if "pre_task_check" in content and "自进化触发钩子" not in content:
            if not has_auto_sync:
                print(f"  🔄 检测到v3.0+钩子但缺少AUTO_SYNC标记，正在补充...")
                self._inject_auto_sync_only(identity_path)
            return
        
        # ★ v3.0.1 关键修复: 检测到旧版末尾钩子 → 需要迁移！不能直接return
        has_old_hook = "self-evolving-core skill自动添加" in content
        if has_old_hook:
            print(f"  🔄 检测到v2.x末尾钩子，正在迁移到前部...")
            # 删除旧版末尾钩子：找到起始标记到文件末尾
            import re
            # 用字符串定位代替复杂正则
            hook_start = content.find("## 🧬 自进化触发钩子")
            if hook_start > 0:
                # 往前找 --- 分隔线
                sep_pos = content.rfind("---", 0, hook_start)
                if sep_pos > 0 and content[sep_pos:sep_pos+3] == "---":
                    # 确保是独立行的 ---
                    if content[sep_pos-1] == "\n" or (sep_pos > 0 and content[sep_pos-1] == "\r"):
                        content = content[:sep_pos].rstrip() + "\n"
                        print(f"    已删除旧版末尾钩子 ({len(content) - len(content[:sep_pos])} bytes)")
            
        hook_text = self.HOOK_TEXT_IDENTITY_FRONT.replace("<SKILL_PATH>", SKILL_DIR).replace("<AGENT_NAME>", self.agent_name)
        
        # ★ v3.0 策略：找到第一个 "---" 后的位置（通常是header之后），在那里插入
        lines = content.split('\n')
        insert_pos = 0
        for i, line in enumerate(lines):
            if line.strip() == '---' and i > 2:  # 跳过开头的front matter
                insert_pos = i + 1
                break
        
        if insert_pos == 0:
            # 找不到合适的插入点，就在开头追加
            insert_pos = len([l for l in lines[:10] if l.strip().startswith('#')])
        
        # 插入钩子文本
        lines.insert(insert_pos, hook_text)
        content = '\n'.join(lines)
        
        with open(identity_path, 'w', encoding='utf-8') as f:
            f.write(content)

    def _inject_auto_sync_only(self, identity_path: str):
        """
        ★ v3.1: 仅补充 AUTO_SYNC 标记到已有的"核心经验速查"区块。
        
        适用于：已有v3.0钩子但缺少AUTO_SYNC标记的旧agent。
        找到"核心经验速查"标题下的第一个> **引用块，在其后插入AUTO_SYNC区块。
        """
        with open(identity_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if "AUTO_SYNC_START" in content:
            return  # 已存在，跳过
        
        auto_sync_block = (
            "\n<!-- AUTO_SYNC_START: 以下由 post_task_learn.py 自动维护，不要手动修改 -->\n"
            "<!-- 暂无关键经验积累，继续使用后会自动填充 -->\n"
            "<!-- AUTO_SYNC_END -->\n"
        )
        
        # 找到 "核心经验速查" 所在区域，在最近的 > **引用行之后插入
        idx = content.find("核心经验速查")
        if idx == -1:
            # 找不到目标位置，退后方案：插入到文件第一个 "---" 后
            idx = content.find("\n---\n")
            if idx == -1:
                return
            insert_at = idx + 5
        else:
            # 找到该段落结尾（下一个 ## 标题或 --- 之前）
            # 策略：在 "核心经验速查" 段的最后一行 "> **..." 之后插入
            next_heading = content.find("\n##", idx + 1)
            next_sep = content.find("\n---", idx + 1)
            end_of_section = min(
                next_heading if next_heading != -1 else len(content),
                next_sep if next_sep != -1 else len(content)
            )
            # 在段落结束前插入
            insert_at = end_of_section
        
        content = content[:insert_at] + auto_sync_block + content[insert_at:]
        
        with open(identity_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"  ✅ AUTO_SYNC标记已补充到: {identity_path}")


def _auto_detect_root() -> str:
    """自动检测项目根目录"""
    root = SKILL_DIR
    for expected in ["self-evolving-core", "skills", ".workbuddy"]:
        if os.path.basename(root) == expected:
            root = os.path.dirname(root)
    return root


def main():
    parser = argparse.ArgumentParser(
        description="🧬 自进化架构部署/升级/检测工具 v4.0（方案C双模）",
        epilog="示例:\n"
               "  python3 upgrade_agent.py --detect                    # ★ 架构智能检测\n"
               "  python3 upgrade_agent.py --deploy                     # ★ 全自动部署（v4.0自动选架构）\n"
               "  python3 upgrade_agent.py --deploy --yes              # 全自动（跳过确认）\n"
               "  python3 upgrade_agent.py --migrate-to-domain         # ★ Agent→Domain迁移\n"
               "  python3 upgrade_agent.py --agent-dir ./agents/<your-agent> --check  # 单agent检测(Legacy)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # 模式选择
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument("--detect", action="store_true",
                            help="★ v4.0新增: 架构智能检测（判断应使用Domain还是Agent模式）")
    mode_group.add_argument("--deploy", action="store_true",
                            help="★ 全自动部署模式：检测架构→自动初始化→验证（首次启用必用）")
    mode_group.add_argument("--migrate-to-domain", action="store_true",
                            help="★ v4.0新增: 从多Agent架构迁移到Domain大一统架构（方案C）")
    mode_group.add_argument("--check", action="store_true", help="检查单个agent是否需要升级（Legacy）")
    mode_group.add_argument("--upgrade", action="store_true", help="升级单个agent（Legacy）")

    # 参数
    parser.add_argument("--agent-dir", default="", help="Agent目录路径（单agent模式用，Legacy）")
    parser.add_argument("--agent", default="", help="Agent名称（Legacy）")
    parser.add_argument("--root", default="", help="项目根目录（默认自动检测）")
    parser.add_argument("--yes", "-y", action="store_true", help="跳过确认直接执行")

    args = parser.parse_args()

    # ========== ★ v4.0 --detect 架构智能检测 ==========
    if args.detect:
        root = args.root or _auto_detect_root()
        print("\n" + "=" * 65)
        print("  🧬 v4.0 架构智能检测 (Architecture Detection)")
        print("=" * 65)
        print(f"\n  📍 检测路径: {root}")

        result = AgentUpgrader.detect_architecture(root)

        print(f"\n  📊 检测结果:")
        print(f"     模式类型: {result['mode']}")
        details = result["details"]
        print(f"     domains/: {'✅ 存在' if details['has_domains_dir'] else '❌ 不存在'}")
        print(f"     agents/:  {'✅ 存在' if details['has_agents_dir'] else '❌ 不存在'}")
        print(f"     配置文件: {'✅ evo-config.json就绪' if details['evo_config_exists'] else '❌ 未配置'}")

        if details["domains_configured"]:
            print(f"\n  📁 已配置域:")
            for d in details["domains_configured"]:
                data_mark = "📊有数据" if d["has_data"] else "🔩空"
                print(f"     {data_mark} {d['name']}")
        if details["agents_found"]:
            print(f"  🤖 发现Agent:")
            for a in details["agents_found"]:
                print(f"     📌 {a['name']} ({a['dir']})")

        print(f"\n  💡 推荐方案:\n     {result['recommendation']}")
        print(f"\n  📎 建议命令:")
        if result["mode"] == "fresh_install":
            print('     python3 upgrade_agent.py --deploy --yes')
        elif result["mode"] == "domain_only":
            print('     python3 domains/_shared/domain_router.py "任务描述"   # 测试路由')
            print('     python3 domains/_shared/evolution_guardian.py check data  # 自检')
        elif result["mode"] == "agent_legacy":
            print('     python3 upgrade_agent.py --migrate-to-domain --yes   # 迁移到Domain')
        print()
        sys.exit(0)

    # ========== ★ v4.0 --migrate-to-domain 迁移 ==========
    if args.migrate_to_domain:
        root = args.root or _auto_detect_root()
        print("\n" + "=" * 65)
        print("  🔄 v4.0 多Agent → Domain迁移 (Migration)")
        print("=" * 65)

        arch = AgentUpgrader.detect_architecture(root)
        if arch["mode"] not in ("agent_legacy", "partial_domain"):
            print(f"\n  ⚠️  当前模式 '{arch['mode']}' 不需要迁移。")
            print(f"     {arch['recommendation']}")
            sys.exit(1)

        agents = arch["details"]["agents_found"]
        if not agents:
            print("\n  ❌ 未发现可迁移的Agent。")
            sys.exit(1)

        # 映射关系：优先用智能工作空间分析推断，这里的表只是通用兜底
        # 注意：不硬编码任何项目专属的Agent名
        # 实际迁移时，_infer_domains()会分析每个Agent的IDENTITY.md来决定映射域
        agent_domain_map = {
            "admin": "_shared",    # 大总管/调度者→共享域（通用规范）
        }
        # 其他Agent名→域的映射由_analyze_workspace()智能推断

        print(f"\n  📋 迁移计划 ({len(agents)}个Agent):\n")
        migration_plan = []
        # 用工作空间智能分析推断每个Agent对应的域
        workspace_signals = AgentUpgrader._analyze_workspace(root)
        inferred = AgentUpgrader._infer_domains(workspace_signals, root)
        inferred_key_map = {d["key"]: d for d in inferred}

        for a in agents:
            # 优先：查已知通用映射（admin→_shared）
            # 其次：根据Agent的IDENTITY.md内容匹配推断域
            if a["name"] == "admin":
                target_domain = "_shared"
            else:
                # 读取该Agent的IDENTITY.md，用智能匹配
                identity_path = os.path.join(a["dir"], "IDENTITY.md")
                identity_content = ""
                if os.path.exists(identity_path):
                    try:
                        with open(identity_path, "r", encoding="utf-8") as f:
                            identity_content = f.read(800).lower()
                    except Exception:
                        pass
                # 尝试和推断出的域做关键词匹配
                best_match = None
                best_score = 0
                for d in inferred:
                    if d["key"] == "_shared":
                        continue
                    score = sum(1 for kw in d.get("trigger_keywords", [])
                                if kw.lower() in identity_content)
                    if score > best_score:
                        best_score = score
                        best_match = d["key"]
                # 没有匹配到推断域，用第一个非_shared域作为默认
                if best_match is None:
                    non_shared = [d["key"] for d in inferred if d["key"] != "_shared"]
                    best_match = non_shared[0] if non_shared else "通用"
                target_domain = best_match

            evo_dir = os.path.join(a["dir"], "self-evolution")
            has_experiences = os.path.exists(os.path.join(evo_dir, "experiences_v2.json"))
            print(f"     {a['name']:<12} → {target_domain:<10} {'(有经验数据)' if has_experiences else '(空)'}")
            migration_plan.append({"agent": a, "domain": target_domain, "has_data": has_experiences})

        if not args.yes:
            print(f"\n  ❓ 确认执行迁移？原agents/目录将保留归档不删除。(y/n): ", end="")
            try:
                confirm = input().strip().lower()
            except EOFError:
                confirm = "n"
            if confirm != 'y':
                print("\n  ⏹️  迁移已取消。")
                sys.exit(0)

        # 执行: 初始化Domain + 迁移数据
        upgrader = AgentUpgrader(root, "migrator")
        domain_report = upgrader._init_domain_structure(root, auto_confirm=True)

        migrated_count = 0
        for item in migration_plan:
            a = item["agent"]
            target = item["domain"]
            src_evo = os.path.join(a["dir"], "self-evolution")

            if not os.path.exists(src_evo):
                continue

            # 迁移experiences_v2.json → experiences.json
            src_exp = os.path.join(src_evo, "experiences_v2.json")
            dst_exp = os.path.join(root, "domains", target, "experiences.json")
            if os.path.exists(src_exp) and item["has_data"]:
                try:
                    import shutil
                    # 读取旧格式，转换为新格式后追加
                    with open(src_exp, 'r', encoding='utf-8') as f:
                        old_data = json.load(f)

                    existing = []
                    if os.path.exists(dst_exp):
                        with open(dst_exp, 'r', encoding='utf-8') as f:
                            existing = json.load(f).get("experiences", [])

                    # 转换L1/L2/L3格式
                    converted = []
                    for exp in old_data.get("experiences", []):
                        converted.append({
                            "id": exp.get("id", f"migrated_{len(converted)}"),
                            "layer": exp.get("layer", "L2"),
                            "scenario": exp.get("scenario", ""),
                            "keywords": exp.get("keywords", []),
                            "fact": exp.get("fact", ""),
                            "steps": exp.get("steps", []),
                            "insight": exp.get("insight", ""),
                            "confidence": exp.get("confidence", 0.8),
                            "proven": True,
                            "tags": ["migrated-from-agent"],
                            "agent": target,
                            "source_task": exp.get("source_task", ""),
                        })

                    all_exps = existing + converted
                    with open(dst_exp, 'w', encoding='utf-8') as f:
                        json.dump({"schema_version": "4.0", "experiences": all_exps}, f, ensure_ascii=False, indent=2)
                    migrated_count += len(converted)
                    print(f"  ✅ {a['name']} → {target}: 迁移{len(converted)}条经验")
                except Exception as e:
                    print(f"  ⚠️  {a['name']} 经验迁移失败: {e}")

        print(f"""
{'=' * 65}
  🔄 迁移完成报告
{'=' * 65}
  初始化域:   {len(domain_report.get('initialized', []))} 个目录
  迁移经验:   {migrated_count} 条
  agents/目录: ✅ 保留未删除（Legacy归档）

  💡 下一步:
    1. 新任务使用Domain模式: evolution_guardian.py log <domain> ...
    2. 测试路由: domain_router.py "任务描述"
    3. 确认无误后可手动删除agents/目录
""")
        sys.exit(0)

    # ========== ★ --deploy 全自动模式（v4.0增强版）==========
    if args.deploy:
        root = args.root
        
        # 自动检测项目根目录
        if not root:
            # 从脚本位置向上查找
            root = SKILL_DIR  # skill根目录
            # 如果skill在 .workbuddy/skills/ 下，再往上一级到workspace
            if os.path.basename(root) == "self-evolving-core":
                root = os.path.dirname(root)
            if os.path.basename(root) == "skills":
                root = os.path.dirname(root)
            if os.path.basename(root) == ".workbuddy":
                root = os.path.dirname(root)
        
        print(f"📍 项目根目录: {root}")
        upgrader = AgentUpgrader(root, "deploy-manager")
        report = upgrader.deploy(root, auto_confirm=args.yes)
        sys.exit(0 if report["success"] else 1)
    
    # ========== 单agent模式（兼容旧版） ==========
    
    if not args.agent_dir:
        parser.print_help()
        print("\n❌ 单agent模式需要 --agent-dir 参数，或使用 --deploy 全自动模式。")
        sys.exit(1)
    
    agent_name = args.agent or os.path.basename(args.agent_dir.rstrip('/'))
    upgrader = AgentUpgrader(args.agent_dir, agent_name)
    
    if args.check or (not args.upgrade and not args.check):
        # 默认是check模式
        result = upgrader.check()
        
        print("\n" + "=" * 60)
        print(f"🔍 架构检测结果 [{result['agent']}]")
        print("=" * 60)
        print(f"  目录: {result['dir']}")
        print(f"  存在: {'✅' if result['exists'] else '❌'}")
        print(f"  需要升级: {'⚠️ 是' if result['needs_upgrade'] else '✅ 否（已是最新）'}")
        
        print("\n📋 当前状态:")
        for key, value in result.get("current_status", {}).items():
            print(f"  {key}: {value}")
        
        if result["recommended_actions"]:
            print(f"\n📝 建议操作:")
            for i, action in enumerate(result["recommended_actions"], 1):
                print(f"  {i}. {action}")
            print(f"\n  执行升级: python3 {sys.argv[0]} --agent-dir {args.agent_dir} --upgrade")
        else:
            print("\n✨ 一切就绪！无需升级。")
    
    elif args.upgrade:
        success = upgrader.execute_upgrade(auto_confirm=args.yes)
        sys.exit(0 if success else 1)
    
    print()


if __name__ == "__main__":
    main()
