#!/usr/bin/env python3
"""
四层记忆引擎（Memory Core）— Self-Evolving-Core 核心

L1 陈述性记忆(Declarative): 事实知识 — "是什么"
L2 程序性记忆(Procedural):   操作流程 — "怎么做"  ⭐最重要
L3 语义记忆(Semantic):       概念关联 — "为什么"  
L4 工作记忆(Working):        当前上下文 — "现在"

用法:
  from memory_core import MemoryCore
  mc = MemoryCore("/path/to/agent/self-evolution")
  
  # 写入经验
  mc.store_l2("数据清洗任务", steps=[...], proven=True, failed_approaches=["直接read_csv内存溢出"])
  
  # 检索经验
  results = mc.search("pandas 数据处理")  # 返回最相关的N条经验
  
  # 任务后学习
  mc.learn_from_task(task="销售报表生成", result="success", lessons="分块读取效率更高", tokens=15000)
"""

import json
import os
import re
import time
from datetime import datetime, timezone
from typing import Optional

class ExperienceV2:
    """结构化经验条目（v2格式，兼容扩展）"""
    
    def __init__(self, data=None):
        self.id = data.get("id", "") if data else ""
        self.layer = data.get("layer", "L2") if data else "L2"  # L1/L2/L3/L4
        self.timestamp = data.get("timestamp", "") if data else ""
        self.scenario = data.get("scenario", "") if data else ""  # 场景描述
        self.keywords = data.get("keywords", []) if data else []  # 检索关键词
        
        # L1: 陈述性 — 事实知识
        self.fact = data.get("fact", "") if data else ""  # 事实陈述
        self.category = data.get("category", "") if data else ""  # 分类: URL/API/config/pattern
        
        # L2: 程序性 — 操作步骤 ⭐
        self.steps = data.get("steps", []) if data else []  # 操作步骤列表
        self.proven = data.get("proven", False) if data else False  # 是否验证过
        self.attempts = data.get("attempts_before_success", 0) if data else 0  # 成功前尝试次数
        self.failed_approaches = data.get("failed_approaches", []) if data else []  # 失败方法
        self.success_count = data.get("success_count", 0) if data else 0  # 复用成功次数
        
        # L3: 语义 — 概念关联
        self.associations = data.get("associations", []) if data else []
        self.error_patterns = data.get("error_patterns", []) if data else []  # 错误模式
        self.root_cause = data.get("root_cause", "") if data else ""
        
        # 元数据
        self.source_task = data.get("source_task", "") if data else ""  # 来源任务
        self.agent = data.get("agent", "admin") if data else "admin"
        self.tags = data.get("tags", []) if data else []  # 标签: [critical, workaround, best-practice]
        self.confidence = data.get("confidence", 0.8) if data else 0.8  # 可信度 0-1
        self.last_used = data.get("last_used", "") if data else ""  # 最后复用时间
        self.expires_at = data.get("expires_at", "") if data else ""  # 过期时间(空=永不过期)
        
    def to_dict(self):
        return {
            "id": self.id,
            "layer": self.layer,
            "timestamp": self.timestamp,
            "scenario": self.scenario,
            "keywords": self.keywords,
            "fact": self.fact,
            "category": self.category,
            "steps": self.steps,
            "proven": self.proven,
            "attempts": self.attempts,
            "failed_approaches": self.failed_approaches,
            "success_count": self.success_count,
            "associations": self.associations,
            "error_patterns": self.error_patterns,
            "root_cause": self.root_cause,
            "source_task": self.source_task,
            "agent": self.agent,
            "tags": self.tags,
            "confidence": self.confidence,
            "last_used": self.last_used,
            "expires_at": self.expires_at
        }


class MemoryCore:
    """四层记忆引擎"""
    
    DEFAULT_EXPERIENCES_FILE = "experiences_v2.json"
    DEFAULT_WORKING_FILE = "working_memory.json"
    
    def __init__(self, evolution_dir: str, agent_name: str = "admin", 
                 experiences_file: str = None):
        """
        初始化记忆核心
        
        Args:
            evolution_dir: agent的self-evolution目录或domain目录绝对路径
            agent_name: agent名称
            experiences_file: ★ v3.3 指定经验文件名（domain模式用"experiences.json"，agent模式用"experiences_v2.json"）
                            不传则默认使用DEFAULT_EXPERIENCES_FILE
        """
        self.evolution_dir = evolution_dir
        self.agent_name = agent_name
        # ★ v3.3: 支持domain模式传入自定义文件名
        self._exp_filename = experiences_file or self.DEFAULT_EXPERIENCES_FILE
        self.experiences_path = os.path.join(evolution_dir, self._exp_filename)
        self.working_path = os.path.join(evolution_dir, self.DEFAULT_WORKING_FILE)
        
        # 确保目录存在
        os.makedirs(evolution_dir, exist_ok=True)
        
        # 加载或初始化经验库
        self._experiences = self._load_experiences()
        self._working_memory = self._load_working_memory()
        
    def _load_experiences(self) -> list:
        """加载经验库"""
        if os.path.exists(self.experiences_path):
            try:
                with open(self.experiences_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get("experiences", [])
            except (json.JSONDecodeError, IOError):
                return []
        return []
    
    def _save_experiences(self):
        """保存经验库（★ v3.3: schema_version动态适配domain/agent格式）"""
        # Domain模式用schema 1.0，Agent模式用schema 2.0
        is_domain = "experiences.json" in self._exp_filename
        schema_ver = "1.0" if is_domain else "2.0"
        data = {
            "schema_version": schema_ver,
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "total_count": len(self._experiences),
            "experiences": self._experiences
        }
        with open(self.experiences_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            
    def _load_working_memory(self) -> dict:
        """加载工作记忆(L4)"""
        if os.path.exists(self.working_path):
            try:
                with open(self.working_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {"session_id": "", "items": [], "created_at": ""}
        return {"session_id": "", "items": [], "created_at": ""}
    
    def _save_working_memory(self):
        """保存工作记忆"""
        with open(self.working_path, 'w', encoding='utf-8') as f:
            json.dump(self._working_memory, f, ensure_ascii=False, indent=2)
    
    def _generate_id(self) -> str:
        """生成唯一ID"""
        return f"exp_{int(time.time()*1000)}_{len(self._experiences)}"
    
    # ==================== 存储API ====================
    
    def store_l1(self, fact: str, category: str, keywords: list, 
                 scenario: str = "", tags: list = None) -> str:
        """
        存入L1陈述性记忆 — 事实知识
        
        Args:
            fact: 事实内容，如"API接口URL格式为 https://api.example.com/v1/..."
            category: 分类: url/api/config/pattern/rule/naming
            keywords: 检索关键词列表
            scenario: 使用场景描述
            tags: 标签列表
            
        Returns:
            经验ID
        """
        exp = ExperienceV2({
            "id": self._generate_id(),
            "layer": "L1",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "scenario": scenario or fact[:60],
            "keywords": keywords,
            "fact": fact,
            "category": category,
            "agent": self.agent_name,
            "tags": tags or [],
            "confidence": 0.9
        })
        self._experiences.append(exp.to_dict())
        self._save_experiences()
        return exp.id
    
    def store_l2(self, scenario: str, steps: list, proven: bool = True,
                 failed_approaches: list = None, attempts: int = 0,
                 keywords: list = None, source_task: str = "",
                 error_patterns: list = None, root_cause: str = "",
                 tags: list = None) -> str:
        """
        存入L2程序性记忆 — 操作流程 ⭐ 最重要
        
        Args:
            scenario: 场景名称，如"销售数据批量处理"
            steps: 操作步骤列表，如["1. goto打开URL", "2. 等7秒", ...]
            proven: 是否已验证成功
            failed_approaches: 尝试过但失败的方法列表
            attempts: 成功前的尝试次数
            keywords: 检索关键词
            source_task: 来源任务名
            error_patterns: 相关错误模式
            root_cause: 根因分析
            tags: 标签
            
        Returns:
            经验ID
        """
        exp = ExperienceV2({
            "id": self._generate_id(),
            "layer": "L2",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "scenario": scenario,
            "keywords": keywords or self._extract_keywords(scenario),
            "steps": steps,
            "proven": proven,
            "attempts_before_success": attempts,
            "failed_approaches": failed_approaches or [],
            "success_count": 1 if proven else 0,
            "source_task": source_task,
            "error_patterns": error_patterns or [],
            "root_cause": root_cause,
            "agent": self.agent_name,
            "tags": tags or ["verified"] if proven else ["experimental"],
            "confidence": min(0.95, 0.6 + attempts * 0.05)  # 越难得到的经验越可信
        })
        self._experiences.append(exp.to_dict())
        self._save_experiences()
        return exp.id
    
    def store_l3(self, concept: str, associations: list, 
                 error_patterns: list = None, keywords: list = None,
                 root_cause: str = "", scenario: str = "") -> str:
        """
        存入L3语义记忆 — 概念关联
        
        Args:
            concept: 中心概念，如"大文件处理性能优化"
            associations: 关联列表 [{"from":"内存限制", "to":"需要分块处理"}, ...]
            error_patterns: 错误模式
            keywords: 检索关键词
            root_cause: 根因
            scenario: 场景
        """
        exp = ExperienceV2({
            "id": self._generate_id(),
            "layer": "L3",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "scenario": scenario or concept,
            "keywords": keywords or [concept] + [a["from"] for a in associations],
            "associations": associations,
            "error_patterns": error_patterns or [],
            "root_cause": root_cause,
            "agent": self.agent_name,
            "tags": ["semantic"]
        })
        self._experiences.append(exp.to_dict())
        self._save_experiences()
        return exp.id
    
    def store_l4(self, key: str, value: any, session_id: str = ""):
        """
        存入L4工作记忆 — 当前会话上下文
        
        Args:
            key: 键名
            value: 值（任意类型）
            session_id: 会话ID
        """
        self._working_memory["session_id"] = session_id
        self._working_memory["created_at"] = self._working_memory.get("created_at") or datetime.now(timezone.utc).isoformat()
        
        # 更新或追加
        found = False
        for item in self._working_memory["items"]:
            if item["key"] == key:
                item["value"] = value
                item["updated_at"] = datetime.now(timezone.utc).isoformat()
                found = True
                break
        if not found:
            self._working_memory["items"].append({
                "key": key,
                "value": value,
                "created_at": datetime.now(timezone.utc).isoformat()
            })
        
        # L4限制：最多50条
        if len(self._working_memory["items"]) > 50:
            self._working_memory["items"] = self._working_memory["items"][-50:]
        
        self._save_working_memory()
    
    # ==================== 检索API ====================
    
    def search(self, query: str, top_k: int = 5, layer_filter: list = None) -> list:
        """
        搜索相关经验（关键词匹配 + 场景模糊匹配）
        
        Args:
            query: 搜索词，如"pandas 数据处理 分块读取"
            top_k: 返回前K条结果
            layer_filter: 只搜索指定层级，如["L2"] 或 ["L1","L2"]
            
        Returns:
            排序后的经验列表（按相关性降序），每项含 relevance_score
        """
        query_lower = query.lower().split()  # 分词
        scored = []
        
        for exp in self._experiences:
            # 层级过滤
            if layer_filter and exp["layer"] not in layer_filter:
                continue
                
            # 过期检查
            if exp.get("expires_at"):
                if datetime.now(timezone.utc).isoformat() > exp["expires_at"]:
                    continue
            
            score = 0.0
            reasons = []
            
            # 1. 精确关键词匹配（权重最高）
            exp_kw = [k.lower() for k in exp.get("keywords", [])]
            for qword in query_lower:
                for kw in exp_kw:
                    if qword == kw:
                        score += 10.0
                        reasons.append(f"exact:{kw}")
                    elif qword in kw or kw in qword:
                        score += 5.0
                        reasons.append(f"partial:{kw}")
                    
                    # 也检查scenario和fact
                    if qword in exp.get("scenario", "").lower():
                        score += 4.0
                        reasons.append(f"in_scenario:{qword}")
                    if qword in exp.get("fact", "").lower():
                        score += 4.0
                        reasons.append(f"in_fact:{qword}")
            
            # 2. 已验证的经验加分
            if exp.get("proven"):
                score += 3.0
                reasons.append("proven")
                
            # 3. 复用成功次数加权
            score += exp.get("success_count", 0) * 0.5
            
            # 4. L2优先（程序性经验最有用）
            if exp["layer"] == "L2":
                score += 2.0
            
            # 5. 高可信度加分
            score += exp.get("confidence", 0.5) * 2
            
            # ★ v3.1: 6. 错误模式反向匹配（最高优先级！）
            for pattern in exp.get("error_patterns", []):
                pattern_lower = pattern.lower()
                if any(
                    q in pattern_lower or pattern_lower in q 
                    or (len(q) >= 2 and any(c in pattern_lower for c in [q, q.lower()]))
                    for q in query_lower
                ):
                    score += 15.0
                    reasons.append(f"error_pattern:{pattern}")
            
            # ★ v3.1: 7. 失败方法反向匹配（拦截！）
            for failed in exp.get("failed_approaches", []):
                if failed and (failed.lower() in query_lower or any(failed.lower() in q or q in failed.lower() for q in query_lower)):
                    score += 20.0  # 比error_patterns更高——这是直接拦截
                    reasons.append(f"BLOCKED:{failed}")
            
            if score > 0:
                result = dict(exp)
                result["relevance_score"] = round(score, 2)
                result["match_reasons"] = reasons
                scored.append(result)
        
        # 按相关性排序
        scored.sort(key=lambda x: x["relevance_score"], reverse=True)
        
        return scored[:top_k]
    
    def get_by_layer(self, layer: str) -> list:
        """获取指定层的所有经验"""
        return [e for e in self._experiences if e["layer"] == layer]
    
    def get_by_tag(self, tag: str) -> list:
        """按标签检索"""
        return [e for e in self._experiences if tag in e.get("tags", [])]
    
    def get_all(self) -> list:
        """获取所有经验（用于身份同步等批量操作）"""
        return list(self._experiences)
    
    # ★ v3.1: 反向匹配——检查用户打算用的方法是否在已知失败列表中
    def check_failed_approaches(self, query: str, top_k: int = 5) -> list:
        """
        反向拦截：如果用户的查询包含已验证失败的方法名，立即返回HIGH警告。
        
        这是最有效的"不犯两次错"机制：
        - 即使pre_task_check没被执行，单独调用此函数也能拦住已知坑
        - 返回的是警告而非建议，优先级高于普通搜索结果
        """
        query_lower = query.lower()
        warnings = []
        seen_methods = set()
        
        for exp in self._experiences:
            for failed in exp.get("failed_approaches", []):
                if not failed or failed in seen_methods:
                    continue
                failed_lower = failed.lower()
                # 检查：查询词是否包含失败方法名，或失败方法是否包含查询词
                is_match = (
                    failed_lower in query_lower or
                    any(q in failed_lower or failed_lower in q for q in query_lower.split()) or
                    any(q in failed_lower for q in [w.strip('，。、()（）') for w in query.replace(',', '，').split('，')])
                )
                
                if is_match:
                    severity = "HIGH" if exp.get("proven") else "MEDIUM"
                    warnings.append({
                        "blocked_method": failed,
                        "exp_id": exp.get("id", ""),
                        "source_task": exp.get("source_task", ""),
                        "reason": f"此方法已在'{exp.get('source_task', '')}'中验证失败",
                        "suggested_alternative": exp.get("steps", [])[:3] if exp.get("steps") else None,
                        "severity": severity,
                        "layer": exp.get("layer", "?"),
                        "match_type": "failed_approach_reverse_match"
                    })
                    seen_methods.add(failed)
                    
                    if len(warnings) >= top_k:
                        break
            if len(warnings) >= top_k:
                break
        
        return warnings
    
    def get_l4(self, key: str = None) -> any:
        """读取L4工作记忆"""
        if key:
            for item in self._working_memory.get("items", []):
                if item["key"] == key:
                    return item["value"]
            return None
        return self._working_memory
    
    # ==================== 学习API（任务后自动提取）====================
    
    def learn_from_task(self, task: str, result: str, lessons: str = "",
                       failed_methods: str = "", tokens: int = 0,
                       duration_sec: float = 0, keywords: list = None) -> str:
        """
        从任务中自动学习并存储经验
        
        这是最重要的API——每次任务完成后调用，自动提取有价值的信息
        
        Args:
            task: 任务描述
            result: success / partial / failed
            lessons: 经验教训文本（自然语言）
            failed_methods: 失败方法的逗号分隔字符串
            tokens: Token消耗
            duration_sec: 耗时秒数
            keywords: 额外关键词
            
        Returns:
            创建的经验ID（如果有价值的话），空串表示没有值得记录的
        """
        # 如果是成功任务且有教训 → 存L2程序性记忆
        if result in ("success", "partial") and lessons.strip():
            # 解析lessons中的步骤信息
            steps = [s.strip() for s in lessons.split(",") if s.strip()]
            failed = [f.strip() for f in failed_methods.split(",") if f.strip()] if failed_methods else []
            
            auto_keywords = keywords or self._extract_keywords(task, lessons=lessons, failed_methods=failed_methods)
            
            return self.store_l2(
                scenario=task[:80],
                steps=steps if len(steps) > 1 else [lessons],
                proven=(result == "success"),
                failed_approaches=failed,
                keywords=auto_keywords,
                source_task=task,
                tags=["auto-extracted"]
            )
        
        # 如果失败了且有失败方法 → 记录失败模式（存L3）
        elif result == "failed":
            if failed_methods:
                return self.store_l3(
                    concept=f"失败模式:{task[:40]}",
                    associations=[
                        {"from": m.strip(), "to": "已验证不可行"} 
                        for m in failed_methods.split(",") if m.strip()
                    ] if failed_methods else [],
                    error_patterns=[task[:60]],
                    keywords=keywords or self._extract_keywords(task, failed_methods=failed_methods),
                    scenario=task[:80]
                )
        
        return ""
    
    # ==================== 维护API ====================
    
    def mark_used(self, exp_id: str):
        """标记某条经验被复用（增加成功计数）"""
        for exp in self._experiences:
            if exp["id"] == exp_id:
                exp["last_used"] = datetime.now(timezone.utc).isoformat()
                exp["success_count"] = exp.get("success_count", 0) + 1
                break
        self._save_experiences()
    
    def clear_l4(self):
        """清空工作记忆（会话结束时调用）"""
        # 先把有价值的L4内容压缩到L1/L2
        valuable_items = [item for item in self._working_memory.get("items", []) 
                         if isinstance(item.get("value"), str) and len(item["value"]) > 20]
        for item in valuable_items:
            self.store_l1(
                fact=item["value"],
                category="session_compressed",
                keywords=self._extract_keywords(item.get("key", "")),
                scenario=f"L4压缩:{item['key']}",
                tags=["from_L4"]
            )
        
        self._working_memory = {"session_id": "", "items": [], "created_at": ""}
        self._save_working_memory()
    
    def compress(self):
        """记忆压缩：清理过期/低价值的经验"""
        now = datetime.now(timezone.utc)
        kept = []
        removed = 0
        for exp in self._experiences:
            # 删除过期的
            if exp.get("expires_at") and now.isoformat() > exp["expires_at"]:
                removed += 1
                continue
            # 删除从未使用且低可信度的实验性经验
            if (not exp.get("last_used") and 
                exp.get("confidence", 0) < 0.5 and
                "experimental" in exp.get("tags", [])):
                removed += 1
                continue
            kept.append(exp)
        
        self._experiences = kept
        self._save_experiences()
        return removed
    
    def stats(self) -> dict:
        """统计信息"""
        l1_count = sum(1 for e in self._experiences if e["layer"] == "L1")
        l2_count = sum(1 for e in self._experiences if e["layer"] == "L2")
        l3_count = sum(1 for e in self._experiences if e["layer"] == "L3")
        total_used = sum(e.get("success_count", 0) for e in self._experiences)
        
        return {
            "total": len(self._experiences),
            "L1_declarative": l1_count,
            "L2_procedural": l2_count,
            "L3_semantic": l3_count,
            "L4_working_items": len(self._working_memory.get("items", [])),
            "total_reuses": total_used,
            "most_used": sorted(self._experiences, 
                               key=lambda x: x.get("success_count", 0), 
                               reverse=True)[:3]
        }
    
    # ==================== 内部工具 ====================
    
    def _extract_keywords(self, text: str, lessons: str = "", failed_methods: str = "") -> list:
        """
        ★ v3.1 增强：从多个来源智能提取检索关键词。
        
        优先级：
        1. 技术词汇表匹配
        2. 从lessons中提取"A比B"结构中的A和B（关键对比词）
        3. 从failed_methods中提取失败方法名
        4. 长度>=2的中文/英文通用词
        """
        # 常见技术词汇（通用扩展版，无项目专属词）
        tech_words = set([
            'python', 'javascript', 'typescript', 'java', 'go', 'rust',
            'api', 'url', 'http', 'https', 'json', 'yaml', 'xml',
            'rest', 'graphql', 'grpc', 'websocket',
            'html', 'css', 'dom', 'xpath', 'selector', 'click',
            'sql', 'database', 'mysql', 'postgresql', 'mongodb', 'redis',
            'pandas', 'numpy', 'dataframe', 'excel', 'csv',
            'docker', 'kubernetes', 'git', 'github', 'gitlab',
            'pytest', 'jest', 'unittest', 'mock',
            'regex', '正则', 'shlex', 'subprocess', 'asyncio',
            'syntaxError', 'TypeError', 'ValueError', 'KeyError',
            'IndentationError', 'UnboundLocalError',
            'pre_task_check', 'post_task_learn', 'evolution_guardian',
            'upgrade_agent', 'domain_router'
        ])
        
        keywords = set()
        
        # 1. 从task描述提取
        text_lower = text.lower()
        words = re.findall(r'[\w\u4e00-\u9fff]+', text_lower)
        for w in words:
            if len(w) >= 2:
                if w in tech_words:
                    keywords.add(w)
                elif re.match(r'^[\u4e00-\u9fff]{2,}$', w):  # 纯中文2字以上
                    keywords.add(w)
                elif re.match(r'^[a-z][a-z0-9_]{3,}$', w):  # 英文标识符
                    keywords.add(w)
        
        # ★ v3.1: 2. 从lessons中提取关键对比词（"A比B好" → 提取A和B）
        if lessons:
            for m in re.finditer(r'([\w\u4e00-\u9fff\s]+?)\s*比\s*([\w\u4e00-\u9fff\s]+?)[，。,.\s更]', lessons):
                for term in [m.group(1).strip(), m.group(2).strip()]:
                    if len(term) >= 2:
                        keywords.add(term)
            # 提取"用/使用/需要"后面的名词性短语
            for m in re.finditer(r'(?:用|使用|需要|通过)\s*([^\s，。,]{2,})', lessons):
                term = m.group(1).strip('()（）[]【】')
                if len(term) >= 2:
                    keywords.add(term)
        
        # ★ v3.1: 3. 从failed_methods中提取失败方法名（这些是最重要的搜索命中点）
        if failed_methods:
            for method in failed_methods.split(','):
                method = method.strip().strip('()（）')
                # "method(原因)" → 提取method
                if '(' in method:
                    method = method.split('(')[0].strip()
                if len(method) >= 2:
                    keywords.add(method)
                    # 也把失败方法标记为error_pattern格式的关键词
                    keywords.add(f"失败:{method}")
        
        return list(keywords)[:20]  # 限制数量防止过多


# ==================== CLI入口 ====================

if __name__ == "__main__":
    import sys
    
    # CLI用法示例
    if len(sys.argv) < 2:
        print("""
四层记忆引擎 CLI用法:

  # 存储
  python memory_core.py --store-l2 --scenario "数据批量处理" --steps "step1,step2,step3" --failed "直接read_csv内存溢出"
  
  # 检索  
  python memory_core.py --search "pandas 数据处理"
  
  # 学习（从任务结果自动提取）
  python memory_core.py --learn --task "月度销售报表" --result success --lessons "分块读取效率高,先聚合再透视"
  
  # 统计
  python memory_core.py --stats
  
  # 压缩
  python memory_core.py --compress
""")
        sys.exit(0)
    
    action = sys.argv[1]
    agent_dir = os.path.dirname(os.path.abspath(__file__))
    # 默认使用admin的evolution目录（从脚本位置自动推导）
    _project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    default_evo = os.environ.get("SELF_EVO_DIR",
        os.path.join(_project_root, "agents", "admin", "self-evolution"))
    mc = MemoryCore(default_evo)
    
    if action == "--search" and len(sys.argv) >= 3:
        query = sys.argv[2]
        results = mc.search(query)
        print(json.dumps(results, ensure_ascii=False, indent=2))
        
    elif action == "--store-l2":
        # 简化的L2存储
        scenario = ""
        steps_str = ""
        failed_str = ""
        for i, arg in enumerate(sys.argv):
            if arg == "--scenario" and i+1 < len(sys.argv):
                scenario = sys.argv[i+1]
            elif arg == "--steps" and i+1 < len(sys.argv):
                steps_str = sys.argv[i+1]
            elif arg == "--failed" and i+1 < len(sys.argv):
                failed_str = sys.argv[i+1]
        
        steps = steps_str.split(",") if steps_str else []
        failed = failed_str.split(",") if failed_str else []
        eid = mc.store_l2(scenario=scenario or "未命名场景", steps=steps, failed_approaches=failed)
        print(f"✅ stored L2: {eid}")
        
    elif action == "--learn":
        # 自动学习
        task, result, lessons, failed = "", "success", "", ""
        for i, arg in enumerate(sys.argv):
            if arg == "--task" and i+1 < len(sys.argv): task = sys.argv[i+1]
            elif arg == "--result" and i+1 < len(sys.argv): result = sys.argv[i+1]
            elif arg == "--lessons" and i+1 < len(sys.argv): lessons = sys.argv[i+1]
            elif arg == "--failed" and i+1 < len(sys.argv): failed = sys.argv[i+1]
        
        eid = mc.learn_from_task(task=task, result=result, lessons=lessons, failed_methods=failed)
        print(f"✅ learned: {eid}" if eid else "ℹ️ nothing worth recording")
        
    elif action == "--stats":
        print(json.dumps(mc.stats(), ensure_ascii=False, indent=2))
        
    elif action == "--compress":
        removed = mc.compress()
        print(f"🗑 compressed, removed {removed} expired items")
        
    else:
        print(f"❓ Unknown action: {action}")
