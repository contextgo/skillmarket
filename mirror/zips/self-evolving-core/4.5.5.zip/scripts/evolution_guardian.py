#!/usr/bin/env python3
"""
Evolution Guardian v4.5.3 — Domain架构入口（自包含实现）
================================================

独立运行的四档守护脚本，不依赖委托。
直接操作 domains/{domain}/ 下的JSON文件。

★ 正确蒸馏流程（三段式，不可跳步）：
  每日日志(YYYY-MM-DD.md)
    → distill --from-daily   → STM新内容区（临时缓冲）
    → distill --from-stm     → MEMORY.md（元层，PINNED区之后）
    → distill                → experiences.json（具体经验）

  直接蒸馏MEMORY.md（distill不带参数）仅用于紧急应急，不是常规流程！

v4.5新增:
  - distill --from-daily: 从每日日志提炼到STM（★常规流程第一步）
  - MEMORY.md置顶保护区: PINNED_SECTION_END标记以上内容永驻，distill跳过
  - STM顶部写入 + 分区隔离: 新内容区↑ / STM_BOUNDARY / 已蒸馏区↓（节省Token）
  - STM提炼内容插入MEMORY.md置顶区(PINNED_SECTION_END)之后

v4.4新增:
  - MEMORY.md 生命周期管理全面升级
  - 短期记忆(short-term-memory.md)作为默认写入端
  - 自动触发: log记账时检测MEMORY.md行数，超150行提示distill
  - 全量重写改为安全写入（头部追加+确认后清理旧版）
  - 跨域内容自动保存到_shared公共区
  - 每日日志15天后归档到archive/，不删除

v4.2新增: 经验生命周期管理（experience-update命令）
v4.1新增: 阈值自检引擎（R1/R2/R3/R4四条规则）

用法:
  # ★ 常规蒸馏流程（按顺序执行）
  python3 evolution_guardian.py distill --from-daily [--date=YYYY-MM-DD] [--dry-run]
  python3 evolution_guardian.py distill --from-stm [--dry-run]
  python3 evolution_guardian.py distill [--dry-run]          # 仅应急，将MEMORY.md具体经验下沉

  # 其他命令
  python3 evolution_guardian.py log data "任务" success "" "" 45000 30
  python3 evolution_guardian.py check data
  python3 evolution_guardian.py feedback admin negative strong "词" "上下文"
  python3 evolution_guardian.py experience-update data <old_id> deprecate
  python3 evolution_guardian.py archive-logs [--days=15]
"""

import json
import os
import sys
import shutil
import time
from datetime import datetime, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def _find_project_root():
    """向上搜索项目根目录"""
    current = os.path.dirname(SCRIPT_DIR)
    for _ in range(6):
        parent = os.path.dirname(current)
        if parent == current:
            break
        if os.path.isdir(os.path.join(current, "domains")) or \
           os.path.isdir(os.path.join(current, ".workbuddy")) or \
           os.path.isdir(os.path.join(current, "workspace")):
            return current
        current = parent
    return os.path.dirname(os.path.dirname(SCRIPT_DIR))


def _get_domain_dir(domain):
    """获取域目录路径"""
    return os.path.join(_find_project_root(), "domains", domain)


def _list_available_domains() -> list:
    """★ v4.5.3: 列出当前已部署的所有域（domains/下所有非_shared子目录）"""
    domains_root = os.path.join(_find_project_root(), "domains")
    if not os.path.isdir(domains_root):
        return []
    return sorted([
        d for d in os.listdir(domains_root)
        if d != "_shared" and not d.startswith(".")
        and os.path.isdir(os.path.join(domains_root, d))
    ])


def _validate_domain(domain: str, auto_create: bool = False) -> tuple:
    """★ v4.5.3: 校验域是否已部署
    
    返回 (is_valid: bool, hint_msg: str)
    
    auto_create=False（默认）: 域不存在 → 返回(False, 友好提示+可用域列表)
    auto_create=True: 域不存在但允许自动创建（如distill下沉时的_shared）
    """
    if not domain or not domain.strip():
        return False, "❌ 域名为空。用法: <command> <domain> ..."

    domain_dir = _get_domain_dir(domain)
    if os.path.isdir(domain_dir):
        return True, ""

    # 域不存在
    available = _list_available_domains()
    if not available:
        msg = (
            f"❌ 域 '{domain}' 不存在，且当前项目尚未部署任何域。\n"
            f"   请先运行: python3 {{SKILL_PATH}}/scripts/upgrade_agent.py --deploy\n"
            f"   或运行: python3 domains/_shared/upgrade_agent.py --deploy"
        )
    else:
        msg = (
            f"❌ 域 '{domain}' 不存在。\n"
            f"   当前已部署的域: {', '.join(available)}\n"
            f"   建议:\n"
            f"     1. 用其中一个已有域名重试: log {available[0]} ...\n"
            f"     2. 用路由自动匹配域: python3 domains/_shared/domain_router.py \"<任务描述>\"\n"
            f"     3. 如确实需要新域，重新运行 --deploy 让系统智能推断"
        )
    if auto_create:
        return True, msg + "\n   ⚠️  --auto-create 已启用，将创建该域。"
    return False, msg


def _ensure_evo_dir(domain):
    """确保域的自进化目录存在（仅用于已部署的域）"""
    d = _get_domain_dir(domain)
    os.makedirs(d, exist_ok=True)
    return d


def _read_json(path, default=None):
    """安全读取JSON"""
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return default or {}


def _write_json(path, data):
    """安全写入JSON"""
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ===== 阈值自检引擎（v4.1 新增）=====

def _normalize_task_type(task: str) -> str:
    """将任务描述归一化为类型键（用于同类任务聚合统计）

    规则:
    1. 去首尾空白，截取前18个字符作为类型前缀
    2. 同一前缀的任务视为同一"类型"
    例: "月度销售数据分析报表生成" → "月度销售数据分析报表生"
        "用户行为数据分析"        → "用户行为数据分析"
    """
    return task.strip()[:18]


def _read_trigger_config():
    """读取evo-config.json中的触发阈值配置"""
    root = _find_project_root()
    cfg = _read_json(os.path.join(root, "domains", "_shared", "evo-config.json"), {})
    return cfg.get("trigger_config", {
        "consecutive_error_threshold": 2,
        "error_window": 5,
        "negative_feedback_threshold": 1,  # ★ v4.1: 1条负面即触发（用户规则）
        "feedback_window_days": 7,
        "review_every_n_tasks": 3,
    })


def _update_task_type_stats(mem_file: str, task: str, result: str):
    """★ v4.1新增: 按任务类型分类统计（写入memory.json的task_type_counts字段）"""
    mem = _read_json(mem_file, {})
    if "task_type_counts" not in mem:
        mem["task_type_counts"] = {}

    type_key = _normalize_task_type(task)

    if type_key not in mem["task_type_counts"]:
        mem["task_type_counts"][type_key] = {
            "total": 0, "success": 0, "failed": 0, "partial": 0,
            "consecutive_errors": 0, "last_results": [],
        }

    ttc = mem["task_type_counts"][type_key]
    ttc["total"] += 1
    if result == "success":
        ttc["success"] += 1
        ttc["consecutive_errors"] = 0
    elif result == "failed":
        ttc["failed"] += 1
        ttc["consecutive_errors"] = ttc.get("consecutive_errors", 0) + 1
    elif result == "partial":
        ttc["partial"] += 1
        # partial不算连续错误但也不重置
        ttc["consecutive_errors"] = 0

    ttc["last_results"].append({
        "result": result, "ts": datetime.now().isoformat(),
    })
    ttc["last_results"] = ttc["last_results"][-10:]  # 保留最近10次

    _write_json(mem_file, mem)
    return ttc


def _check_memory_size(root: str, threshold: int = 150) -> tuple:
    """★ v4.4: 检测MEMORY.md行数，返回 (line_count, over_threshold)
    也检查short-term-memory.md是否有待提炼的内容。
    """
    memory_path = os.path.join(root, ".workbuddy", "memory", "MEMORY.md")
    stm_path = os.path.join(root, ".workbuddy", "memory", "short-term-memory.md")

    mem_lines = 0
    stm_lines = 0

    if os.path.exists(memory_path):
        with open(memory_path, "r", encoding="utf-8") as f:
            mem_lines = sum(1 for _ in f)

    if os.path.exists(stm_path):
        with open(stm_path, "r", encoding="utf-8") as f:
            stm_lines = sum(1 for _ in f)

    return mem_lines, stm_lines, (mem_lines > threshold)


def _auto_check_triggers(domain: str, mem_file: str, task: str, result: str):
    """★ v4.1新增/v4.4增强: 每次log后自动检查所有进化触发条件

    四条规则（v4.4新增R4）:
      R1: 累计每10次任务 → 建议review+learn
      R2: 同类任务连续犯错≥3次 → 🔴强制review+提取免疫规则
      R3: 有未处理的负面反馈 → 🔴必须evolve
      R4: MEMORY.md超150行 → 📋建议运行distill

    达到条件时输出醒目的行动指令（AI看到后必须在当轮响应）。
    返回触发的规则列表（空列表=未触发任何规则）。
    """
    mem = _read_json(mem_file, {})
    stats = mem.get("statistics", {})
    cfg = _read_trigger_config()
    triggers = []

    # ── R1: 每 N 次任务触发 review 260506改成3次提高频率──
    review_n = cfg.get("review_every_n_tasks", 3)
    total = stats.get("total_tasks", 0)
    if total > 0 and total % review_n == 0:
        triggers.append({
            "id": "R1_PERIODIC_REVIEW",
            "level": "info",
            "icon": "\U0001F4CA",  # 📊
            "message": f"本域已累计 {total} 次任务（每{review_n}次节点）",
            "action": f"执行 review {domain} → 回顾近期任务模式 → 如有新经验追加到 experiences.json",
        })

    # ── R2: 同类任务连续错误检测 260506改成2次提高频率──
    type_key = _normalize_task_type(task)
    ttc = mem.get("task_type_counts", {}).get(type_key, {})
    consec_err = ttc.get("consecutive_errors", 0)
    err_threshold = cfg.get("consecutive_error_threshold", 2)

    if consec_err >= err_threshold:
        triggers.append({
            "id": "R2_CONSECUTIVE_ERRORS",
            "level": "critical",
            "icon": "\U0001F534",  # 🔴
            "message": (
                f"任务类型「{type_key}...」连续犯错 {consec_err} 次 "
                f"(阈值={err_threshold})"
            ),
            "action": (
                f"立即执行 review {domain} → 从最近失败中提取教训 → "
                f"追加 immune_rules.json（severity=critical）→ "
                f"追加 experiences.json（L2层）"
            ),
        })

    # ── R3: 负面反馈检测 ──
    root = _find_project_root()
    fb_file = os.path.join(root, "domains", "_shared", "evo-feedback.json")
    fb = _read_json(fb_file, {"feedback_records": []})
    unresolved_negatives = [
        f for f in fb.get("feedback_records", [])
        if f.get("type") == "negative"
    ]
    fb_threshold = cfg.get("negative_feedback_threshold", 1)

    if len(unresolved_negatives) >= fb_threshold:
        latest_fb = unresolved_negatives[-1]
        triggers.append({
            "id": "R3_NEGATIVE_FEEDBACK",
            "level": "critical",
            "icon": "\u26A0\uFE0F",  # ⚠️
            "message": (
                f"收到 {len(unresolved_negatives)} 条未处理负面反馈 | "
                f"最新:「{latest_fb.get('phrase', '')}」"
            ),
            "action": (
                f"立即执行 evolve {domain} \"用户负面反馈:{latest_fb.get('phrase', '')}\" → "
                f"分析反馈根因 → 修正经验/规则 → 改进后续执行策略"
            ),
        })

    # ── R4: ★ v4.4新增 MEMORY.md行数检测 ──
    mem_threshold = cfg.get("memory_line_threshold", 150)
    mem_lines, stm_lines, mem_over = _check_memory_size(root, mem_threshold)

    if mem_over:
        triggers.append({
            "id": "R4_MEMORY_OVERFLOW",
            "level": "warn",
            "icon": "\U0001F4CB",  # 📋
            "message": (
                f"MEMORY.md当前 {mem_lines} 行，超过阈值 {mem_threshold} 行"
                + (f" | short-term-memory.md: {stm_lines} 行待提炼" if stm_lines > 0 else "")
            ),
            "action": (
                "运行 python3 evolution_guardian.py distill --dry-run 预览 → "
                "确认无误后去掉 --dry-run 执行蒸馏 → 将具体经验下沉到各域experiences.json"
                + (" | 建议同时运行 distill --from-stm 提炼短期记忆" if stm_lines > 10 else "")
            ),
        })
    elif stm_lines > 20:
        # STM有内容但MEMORY未超限——轻提示
        triggers.append({
            "id": "R4_STM_PENDING",
            "level": "info",
            "icon": "\U0001F4DD",  # 📝
            "message": f"short-term-memory.md积累了 {stm_lines} 行，可以提炼到MEMORY.md",
            "action": "运行 python3 evolution_guardian.py distill --from-stm 提炼短期记忆",
        })

    # ── 输出结果（仅在触发时输出）──
    if triggers:
        print(f"\n{'=' * 56}")
        print(f"  \U0001F9E0 进化阈值自检结果 [{domain}]")
        print(f"{'=' * 56}")
        for t in triggers:
            print(f"\n  {t['icon']} [{t['level'].upper()}] {t['message']}")
            print(f"  \u279C 行动指令: {t['action']}")
        print(f"\n{'=' * 56}")
        print(f"  \u26A0\ufe0f  以上指令为系统自动生成，请在本轮内响应。\n")

    return triggers


def cmd_archive_logs(days: int = 15):
    """★ v4.4新增: 每日日志归档
    
    将超过N天（默认15天）的 YYYY-MM-DD.md 日志文件
    移动到 .workbuddy/memory/archive/ 目录，而非删除。
    
    用法:
      python3 evolution_guardian.py archive-logs           # 默认15天
      python3 evolution_guardian.py archive-logs --days=7  # 7天归档
    """
    root = _find_project_root()
    memory_dir = os.path.join(root, ".workbuddy", "memory")
    archive_dir = os.path.join(memory_dir, "archive")
    os.makedirs(archive_dir, exist_ok=True)

    cutoff = datetime.now() - timedelta(days=days)
    archived = []
    skipped = []

    import re
    for fname in os.listdir(memory_dir):
        # 匹配 YYYY-MM-DD.md 格式
        if not re.match(r"^\d{4}-\d{2}-\d{2}\.md$", fname):
            continue
        try:
            file_date = datetime.strptime(fname[:10], "%Y-%m-%d")
        except ValueError:
            continue

        if file_date < cutoff:
            src = os.path.join(memory_dir, fname)
            dst = os.path.join(archive_dir, fname)
            if os.path.exists(dst):
                # 目标已存在，重命名避免覆盖
                dst = os.path.join(archive_dir, fname.replace(".md", f"_dup_{int(time.time())}.md"))
            shutil.move(src, dst)
            archived.append(fname)
        else:
            skipped.append(fname)

    print(f"\n{'=' * 50}")
    print(f"  📦 日志归档完成（>{days}天）")
    print(f"{'=' * 50}")
    print(f"  归档目录: {archive_dir}")
    print(f"  已归档: {len(archived)} 个文件")
    for f in archived:
        print(f"    ✅ {f}")
    print(f"  保留(≤{days}天): {len(skipped)} 个文件")
    print(f"{'=' * 50}\n")


# ===== 命令实现 =====

def _append_lesson_to_domain(domain: str, task: str, lesson: str, error_type: str = "", error_cat: str = "") -> dict:
    """★ v4.5新增: 记录失败任务的教训到域 experiences.json + immune_rules.json
    
    当用户传入 --lesson 时调用，一步完成：
      1. 写入 experiences.json（layer=L2，记录失败教训）
      2. 写入 immune_rules.json（severity=warning，作为预检规则）
    
    返回: {experience_id, rule_id}
    """
    evo_dir = _ensure_evo_dir(domain)
    ts = datetime.now().isoformat()
    
    # 1. 写入 experiences.json
    exp_file = os.path.join(evo_dir, "experiences.json")
    exp_data = _read_json(exp_file, {"schema_version": "4.2", "experiences": []})
    exps = exp_data.get("experiences", [])
    exp_id = f"lesson_{int(time.time()*1000)}_{len(exps)}"
    exps.append({
        "id": exp_id,
        "status": "active",
        "layer": "L2",
        "scenario": task[:80],
        "keywords": [w for w in [error_cat, error_type] if w],
        "steps": [f"教训: {lesson}"],
        "insight": lesson,
        "confidence": 0.7,
        "proven_count": 1,
        "superseded_by": None,
        "source_task": task,
        "agent": "admin",
        "tags": ["from_log_lesson", "failure"],
        "timestamp": ts,
        "updated_at": ts,
    })
    exp_data["experiences"] = exps
    exp_data["total_count"] = len(exps)
    exp_data["last_updated"] = ts
    _write_json(exp_file, exp_data)
    
    # 2. 写入 immune_rules.json（自动生成预检规则）
    rule_file = os.path.join(evo_dir, "immune_rules.json")
    rule_data = _read_json(rule_file, {"schema_version": "4.2", "rules": []})
    rules = rule_data.get("rules", [])
    rule_id = f"rule_{int(time.time()*1000)}_{len(rules)}"
    rules.append({
        "id": rule_id,
        "scenario": task[:80],
        "rule": lesson,
        "severity": "warning",
        "source_lesson": f"任务'{task[:40]}'失败教训自动提取",
        "source_experience_id": exp_id,
        "error_type": error_type,
        "error_category": error_cat,
        "created_at": ts,
    })
    rule_data["rules"] = rules
    rule_data["total_rules"] = len(rules)
    rule_data["last_updated"] = ts
    _write_json(rule_file, rule_data)
    
    return {"experience_id": exp_id, "rule_id": rule_id}


def cmd_log(domain, task, result, error_type, error_cat, tokens, duration, lesson=""):
    """档位1: 静默记账 + ★v4.5: 支持lesson参数自动写经验/免疫规则"""
    # ★ v4.5.3: 域校验（避免蠢模型乱写域名造成污染）
    is_valid, hint = _validate_domain(domain)
    if not is_valid:
        print(hint)
        return

    evo_dir = _ensure_evo_dir(domain)
    log_file = os.path.join(evo_dir, "evolution.log")
    mem_file = os.path.join(evo_dir, "memory.json")

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_line = (
        f"[{ts}] 任务完成 [domain:{domain}] task='{task}' result={result}"
        f" | Token消耗:{tokens} | 耗时:{duration}s"
    )
    if lesson:
        log_line += f" | lesson='{lesson[:80]}'"
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(log_line + "\n")

    # 更新memory.json统计
    mem = _read_json(mem_file, {"statistics": {"total_tasks": 0, "success_count": 0, "failed_count": 0, "total_tokens": 0, "total_duration_sec": 0}, "recent_tasks": []})
    stats = mem["statistics"]
    stats["total_tasks"] = stats.get("total_tasks", 0) + 1
    stats["total_tokens"] = stats.get("total_tokens", 0) + int(tokens)
    stats["total_duration_sec"] = stats.get("total_duration_sec", 0) + int(duration)
    if result == "success":
        stats["success_count"] = stats.get("success_count", 0) + 1
    elif result in ("failed", "partial"):
        stats["failed_count"] = stats.get("failed_count", 0) + 1
    recent = mem.get("recent_tasks", [])
    recent.append({"timestamp": ts, "task_desc": task, "result": result, "domain": domain})
    mem["recent_tasks"] = recent[-20:]  # 保留最近20条
    _write_json(mem_file, mem)

    # ★ v4.1: 按任务类型分类统计
    _update_task_type_stats(mem_file, task, result)

    print(f"\U0001F7E1 日志已记录 | agent=admin [domain:{domain}] task='{task}' result={result}")

    # ★ v4.5: 如果传入了 lesson，自动写入 experiences.json + immune_rules.json
    if lesson:
        try:
            ids = _append_lesson_to_domain(domain, task, lesson, error_type, error_cat)
            print(f"  📚 经验已自动写入: experiences.json (id={ids['experience_id']})")
            print(f"  🛡️ 免疫规则已自动写入: immune_rules.json (id={ids['rule_id']}, severity=warning)")
        except Exception as e:
            print(f"  ⚠️  自动写入经验失败: {e}")

    # ★ v4.1: 自动阈值自检（每次log后无条件执行）
    triggers = _auto_check_triggers(domain, mem_file, task, result)
    if not triggers:
        return  # 无触发时静默结束
    # 有触发时：triggers已在_auto_check_triggers内打印行动指令
    # 返回值供外部程序化使用（如automation脚本判断）


def cmd_check(domain):
    """档位2: 自检诊断"""
    # ★ v4.5.3: 域校验
    is_valid, hint = _validate_domain(domain)
    if not is_valid:
        print(hint)
        return

    evo_dir = _get_domain_dir(domain)
    mem = _read_json(os.path.join(evo_dir, "memory.json"), {})
    exp_file = os.path.join(evo_dir, "experiences.json")
    experiences = _read_json(exp_file, {}).get("experiences", [])
    rules_file = os.path.join(evo_dir, "immune_rules.json")
    rules = _read_json(rules_file, {}).get("rules", [])
    log_file = os.path.join(evo_dir, "evolution.log")
    log_lines = 0
    if os.path.exists(log_file):
        with open(log_file) as f:
            log_lines = sum(1 for _ in f)

    stats = mem.get("statistics", {})
    total = stats.get("total_tasks", 0)
    success = stats.get("success_count", 0)
    failed = stats.get("failed_count", 0)
    rate = (success / total * 100) if total > 0 else 100

    # ★ v4.2: 按状态分类统计经验（兼容旧数据，无status字段视为active）
    active_exps = [e for e in experiences if e.get("status", "active") == "active"]
    deprecated_exps = [e for e in experiences if e.get("status", "active") != "active"]
    l1 = sum(1 for e in active_exps if e.get("layer") == "L1")
    l2 = sum(1 for e in active_exps if e.get("layer") == "L2")
    l3 = sum(1 for e in active_exps if e.get("layer") == "L3")

    print(f"\n{'='*60}")
    print(f"  Evolution Guardian 自检报告 [{domain}] v4.2")
    print(f"{'='*60}\n")
    print(f"  时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"\n  ── 1. 文件完整性 ──")
    for name, path in [("experiences.json", exp_file), ("evolution.log", log_file), ("immune_rules.json", rules_file)]:
        if os.path.exists(path):
            size = os.path.getsize(path)
            print(f"  ✅ {name:<25} ({size:,} B)")
        else:
            print(f"  ❌ {name:<25} (缺失)")
    print(f"\n  ── 2. 经验库状态 ──")
    print(f"  有效经验(active): {len(active_exps)} | L1:{l1} L2:{l2} L3:{l3}")
    if deprecated_exps:
        print(f"  已废弃(deprecated): {len(deprecated_exps)} 条（不参与检索，保留归档）")
    print(f"\n  ── 3. 任务统计 ──")
    print(f"  总任务: {total} | 成功: {success} ({rate:.0f}%) | 失败: {failed}")

    # ★ v4.1: 任务类型分布（同类聚合统计）
    ttc = mem.get("task_type_counts", {})
    if ttc:
        print(f"\n  ── 3b. 任务类型分布 ──")
        # 按总次数降序排列
        sorted_types = sorted(ttc.items(), key=lambda x: x[1].get("total", 0), reverse=True)
        for tkey, tdata in sorted_types[:8]:  # 最多显示前8类
            consec = tdata.get("consecutive_errors", 0)
            warn = f" \U0001F534 x{consec}" if consec >= 2 else ""
            print(f"    {tdata['total']:>3}次 [{tkey:<18}] S:{tdata.get('success',0)} F:{tdata.get('failed',0)}{warn}")
    else:
        print(f"\n  ── 3b. 任务类型分布 ── (暂无数据，将在首次log后生成)")
    print(f"\n  ── 5. 免疫系统 ──")
    print(f"  免疫规则: {len(rules)} 条")
    for r in rules[:5]:
        sev = r.get('severity', '?')
        print(f"    [{sev}] {r.get('scenario', '?')[:40]}")
    print(f"\n{'='*60}\n")


def cmd_experience_update(domain, old_id, new_id=None, action="deprecate"):
    """★ v4.2新增: 经验生命周期管理

    发现历史经验有误时，将其标记为废弃（deprecated/superseded），
    而不是删除或修改原始内容。废弃的经验不参与检索，但保留历史记录。

    action:
      deprecate     — 直接废弃（发现经验错误，且无新经验替代）
      supersede     — 被新经验替代（用 new_id 指向替代经验）

    用法:
      # 废弃一条错误的经验
      evolution_guardian.py experience-update <domain> <old_id> deprecate

      # 将旧经验标记为被新经验替代
      evolution_guardian.py experience-update <domain> <old_id> supersede <new_id>
    """
    evo_dir = _get_domain_dir(domain)
    exp_file = os.path.join(evo_dir, "experiences.json")
    data = _read_json(exp_file, {"schema_version": "4.0", "experiences": []})
    experiences = data.get("experiences", [])

    # 找到目标经验
    target = next((e for e in experiences if e.get("id") == old_id), None)
    if not target:
        print(f"❌ 未找到 id='{old_id}' 的经验（域: {domain}）")
        print(f"   可用ID: {[e.get('id') for e in experiences[:10]]}")
        return False

    old_status = target.get("status", "active")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if action == "deprecate":
        target["status"] = "deprecated"
        target["deprecated_at"] = ts
        target["deprecated_reason"] = "手动标记废弃"
        print(f"✅ 经验已废弃 | id={old_id} | 原status={old_status} → deprecated")
        print(f"   场景: {target.get('scenario', '?')}")
        print(f"   该经验将不再出现在检索结果中，但保留历史记录")

    elif action == "supersede":
        if not new_id:
            print(f"❌ supersede操作需要提供 new_id 参数")
            return False
        # 验证新经验存在
        new_exp = next((e for e in experiences if e.get("id") == new_id), None)
        if not new_exp:
            print(f"❌ 替代经验 id='{new_id}' 不存在，请先写入新经验")
            return False
        target["status"] = "superseded"
        target["superseded_by"] = new_id
        target["superseded_at"] = ts
        print(f"✅ 经验已替代 | {old_id} → superseded_by={new_id}")
        print(f"   旧: {target.get('scenario', '?')}")
        print(f"   新: {new_exp.get('scenario', '?')}")
        print(f"   旧经验不再参与检索，新经验生效")

    else:
        print(f"❌ 未知操作: {action}，支持: deprecate / supersede")
        return False

    _write_json(exp_file, data)
    return True


def cmd_feedback(agent, ftype, severity, phrase, context):
    """反馈记录（全局）"""
    root = _find_project_root()
    fb_file = os.path.join(root, "domains", "_shared", "evo-feedback.json")
    fb = _read_json(fb_file, {"schema_version": "4.0", "feedback_records": [], "trigger_words_config": {}})
    records = fb.get("feedback_records", [])
    records.append({
        "timestamp": datetime.now().isoformat(),
        "agent": agent, "type": ftype, "severity": severity,
        "phrase": phrase, "context": context,
    })
    fb["feedback_records"] = records[-100:]
    _write_json(fb_file, fb)
    print(f"✅ 反馈已记录 | agent={agent} [{severity}] \"{phrase}\"")


def cmd_review(domain):
    """复盘（提示需手动积累经验后自动生成规则）"""
    # ★ v4.5.3: 域校验
    is_valid, hint = _validate_domain(domain)
    if not is_valid:
        print(hint)
        return

    print(f"\n📋 复盘建议 [{domain}]:")
    print(f"  1. 确认最近任务经验已通过 post_task_learn 写入 experiences.json")
    print(f"  2. 如发现重复错误模式，手动追加到 immune_rules.json")
    print(f"  3. 运行 check {domain} 确认规则生效\n")


def cmd_evolve(domain, reason=""):
    """深度进化"""
    # ★ v4.5.3: 域校验
    is_valid, hint = _validate_domain(domain)
    if not is_valid:
        print(hint)
        return

    print(f"\n🧬 深度进化 [{domain}]: {reason or '(手动触发)'}")
    print(f"  待实现：清理过时规则 + 经验精炼 + Token优化")
    print(f"  （当前版本为轻量级提醒，完整进化需后续迭代）\n")


# ===== MEMORY.md 生命周期管理（v4.3新增）=====

# 域关键词映射——用于判断MEMORY内容归属哪个域
# 格式: {domain_key: [keyword_list]}
# 由distill命令动态加载evo-config.json中的域配置
_FALLBACK_DOMAIN_KEYWORDS = {
    "data":    ["数据", "查询", "SQL", "excel", "爬虫", "数据库", "统计", "分析", "表格", "报表"],
    "product": ["需求", "PRD", "产品", "功能", "设计", "文档", "流程", "用户故事", "迭代", "版本"],
    "ux":      ["交互", "UI", "界面", "原型", "设计稿", "用户体验", "前端", "组件", "样式", "布局"],
    "test":    ["测试", "QA", "验证", "用例", "回归", "bug", "缺陷", "质量"],
    "skilldev":["skill", "技能", "SKILL.md", "架构", "脚本", "部署", "自进化"],
}

# MEMORY.md 元层内容特征——这些内容不下沉，永驻元层
_META_LAYER_PATTERNS = [
    r"^#+\s*(沟通规范|运行模式|架构.*概览|当前版本|沟通.*规则|身份.*定义)",
    r"唯一.*模式|已停用|恢复条件",
    r"称呼用户|称用户为|沟通风格|对话风格",
    r"最后更新.*\d{4}-\d{2}-\d{2}",
    r"^---\s*$",
]


def _load_domain_keyword_map(root: str) -> dict:
    """从evo-config.json加载域关键词映射（优先），fallback到内置映射
    
    evo-config.json的domains字段支持两种格式：
      - list格式: [{"key": "data", "trigger_keywords": [...]}]  (upgrade_agent.py --deploy生成)
      - dict格式: {"data": {"name": "...", ...}}                (旧版格式，无trigger_keywords)
    """
    cfg_path = os.path.join(root, "domains", "_shared", "evo-config.json")
    cfg = _read_json(cfg_path, {})
    domains_raw = cfg.get("domains", {})
    domain_map = {}

    if isinstance(domains_raw, list):
        # list格式（新版upgrade_agent生成）
        for d in domains_raw:
            key = d.get("key", "")
            kws = d.get("trigger_keywords", [])
            if key and kws:
                domain_map[key] = kws
    elif isinstance(domains_raw, dict):
        # dict格式（旧版/手动配置）——从index.json补充trigger_keywords
        index_path = os.path.join(root, "domains", "_shared", "index.json")
        index = _read_json(index_path, {})
        index_domains = index.get("domains", {})
        for key in domains_raw:
            kws = index_domains.get(key, {}).get("trigger_keywords", [])
            if not kws:
                # fallback：用内置映射
                kws = _FALLBACK_DOMAIN_KEYWORDS.get(key, [])
            if kws:
                domain_map[key] = kws

    if not domain_map:
        domain_map = _FALLBACK_DOMAIN_KEYWORDS
    return domain_map


def _is_meta_layer(line: str) -> bool:
    """判断某行是否属于元层内容（不应被下沉）"""
    import re
    for pat in _META_LAYER_PATTERNS:
        if re.search(pat, line):
            return True
    return False


def _classify_block_to_domain(block_text: str, domain_map: dict) -> tuple:
    """★ v4.4增强: 将一段MEMORY文本归类到最匹配的域
    
    返回 (primary_domain, is_cross_domain)
    - primary_domain: 最匹配的域名，None表示无匹配
    - is_cross_domain: True表示内容跨多个域（应存入_shared公共区）
    
    跨域判断：得分前两名都>0且分差<=2，认为是跨域内容
    """
    text_lower = block_text.lower()
    scores = {}
    for domain, kws in domain_map.items():
        score = sum(1 for kw in kws if kw.lower() in text_lower)
        if score > 0:
            scores[domain] = score
    if not scores:
        return None, False

    sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    best_domain = sorted_scores[0][0]
    best_score = sorted_scores[0][1]

    # 跨域判断：第二名存在且分差<=2（即两个域都匹配度高）
    is_cross = (
        len(sorted_scores) >= 2 and
        sorted_scores[1][1] > 0 and
        (best_score - sorted_scores[1][1]) <= 2
    )
    return best_domain, is_cross


def _append_experience_to_domain(root: str, domain: str, scenario: str, content: str, source: str):
    """把提炼出的内容写入域experiences.json"""
    domain_dir = os.path.join(root, "domains", domain)
    os.makedirs(domain_dir, exist_ok=True)
    exp_file = os.path.join(domain_dir, "experiences.json")
    data = _read_json(exp_file, {"schema_version": "1.0", "experiences": []})
    exps = data.get("experiences", [])

    import time
    new_id = f"distilled_{int(time.time()*1000)}_{len(exps)}"
    ts = datetime.now().isoformat()
    exps.append({
        "id": new_id,
        "layer": "L2",
        "timestamp": ts,
        "scenario": scenario[:80],
        "keywords": [],
        "steps": [content],
        "proven": False,
        "confidence": 0.6,
        "source_task": f"distill from MEMORY.md ({source})",
        "agent": "admin",
        "tags": ["distilled", "from_memory"],
        "status": "active",
    })
    data["experiences"] = exps
    data["total_count"] = len(exps)
    data["last_updated"] = ts
    _write_json(exp_file, data)
    return new_id


def _safe_write_memory(memory_path: str, new_content: str) -> bool:
    """★ v4.4: 安全写入MEMORY.md
    
    策略: 头部追加新内容 + 用分隔符标记旧版本 → 确认写入成功后清除旧版本标记区
    原理: 写入分两步，第一步不删旧内容（有回滚机会），第二步才清理
    
    返回: True=成功，False=失败（原文件未被修改）
    """
    import re

    SEPARATOR = "\n\n<!-- MEMORY_SAFE_WRITE_OLD_VERSION_START -->\n"
    SEPARATOR_END = "<!-- MEMORY_SAFE_WRITE_OLD_VERSION_END -->\n"

    # 读取当前内容
    old_content = ""
    if os.path.exists(memory_path):
        with open(memory_path, "r", encoding="utf-8") as f:
            old_content = f.read()

    # 如果上次写入未清理（意外中断），先清理旧标记区
    if "MEMORY_SAFE_WRITE_OLD_VERSION_START" in old_content:
        # 提取标记区之前的内容（即上次写入的新内容，已验证为有效）
        parts = old_content.split(SEPARATOR, 1)
        old_content = parts[0].rstrip() + "\n"
        with open(memory_path, "w", encoding="utf-8") as f:
            f.write(old_content)

    # Step 1: 写入 [新内容 + 分隔符 + 旧内容]
    combined = new_content.rstrip() + SEPARATOR + old_content.rstrip() + "\n" + SEPARATOR_END
    with open(memory_path, "w", encoding="utf-8") as f:
        f.write(combined)

    # Step 2: 验证新内容已写入
    with open(memory_path, "r", encoding="utf-8") as f:
        verify = f.read()

    if new_content[:50].strip() not in verify:
        # 写入验证失败，恢复原内容
        with open(memory_path, "w", encoding="utf-8") as f:
            f.write(old_content)
        return False

    # Step 3: 写入成功，清除旧版本标记区
    with open(memory_path, "w", encoding="utf-8") as f:
        f.write(new_content.rstrip() + "\n")

    return True


def cmd_distill(memory_path: str = None, dry_run: bool = False, from_stm: bool = False):
    """
    ★ v4.4重构: MEMORY.md生命周期管理——将具体经验下沉到域经验库

    两种模式:
      distill              — 蒸馏MEMORY.md本体（将具体块下沉到experiences.json）
      distill --from-stm   — 从short-term-memory.md提炼到MEMORY.md

    MEMORY.md蒸馏流程:
    1. 扫描MEMORY.md，识别"具体经验"段落（非元层内容）
    2. 按域关键词归类；跨域内容→_shared公共区
    3. 写入域experiences.json（置信度0.6，标注from_memory来源）
    4. 安全写入：头部追加保留结果 + 确认成功后清理旧内容
    5. 目标: MEMORY.md < 150行

    short-term-memory蒸馏流程:
    1. 读取short-term-memory.md内容
    2. 识别有价值的块（非临时日志）
    3. 追加到MEMORY.md（不清空short-term-memory，作为留档）
    4. 在short-term-memory末尾标记"已提炼时间戳"

    用法:
      python3 evolution_guardian.py distill              # 蒸馏MEMORY.md
      python3 evolution_guardian.py distill --dry-run   # 仅预览
      python3 evolution_guardian.py distill --from-stm  # 从短期记忆提炼
    """
    import re

    root = _find_project_root()

    if from_stm:
        _cmd_distill_from_stm(root, dry_run)
        return

    # ── 定位MEMORY.md ──
    if not memory_path:
        candidates = [
            os.path.join(root, ".workbuddy", "memory", "MEMORY.md"),
            os.path.join(root, "MEMORY.md"),
        ]
        memory_path = next((p for p in candidates if os.path.exists(p)), None)

    if not memory_path or not os.path.exists(memory_path):
        print(f"❌ 未找到MEMORY.md（搜索路径: {root}/.workbuddy/memory/MEMORY.md）")
        print(f"   提示: 可传入路径 python3 evolution_guardian.py distill /path/to/MEMORY.md")
        return

    domain_map = _load_domain_keyword_map(root)

    with open(memory_path, "r", encoding="utf-8") as f:
        content = f.read()

    lines = content.splitlines()
    total_lines = len(lines)

    print(f"\n{'=' * 60}")
    print(f"  🧹 MEMORY.md 蒸馏 {'[预览模式]' if dry_run else '[执行模式]'}")
    print(f"{'=' * 60}")
    print(f"  文件: {memory_path}")
    print(f"  当前行数: {total_lines}")

    # ★ v4.5: 识别置顶保护区（PINNED_SECTION_END 标记以上的内容永驻，不蒸馏）
    PINNED_END = "<!-- PINNED_SECTION_END -->"
    pinned_content = ""
    distillable_content = content

    if PINNED_END in content:
        parts = content.split(PINNED_END, 1)
        pinned_content = parts[0] + PINNED_END  # 置顶区（含标记行）
        distillable_content = parts[1]           # 只蒸馏这部分
        pinned_lines = len(pinned_content.splitlines())
        print(f"  🔒 置顶保护区: {pinned_lines} 行（跳过，不蒸馏）")
        print(f"  📋 可蒸馏区: {total_lines - pinned_lines} 行")
    else:
        print(f"  ℹ️  未检测到置顶保护区（PINNED_SECTION_END标记），全文参与蒸馏")

    lines = distillable_content.splitlines()

    # ── 按 ## 分割成块 ──
    blocks = []
    current_block_lines = []
    current_heading = ""

    for line in lines:
        if re.match(r'^#{1,3}\s+', line):
            if current_block_lines:
                blocks.append({
                    "heading": current_heading,
                    "lines": current_block_lines,
                    "text": "\n".join(current_block_lines),
                })
            current_heading = line
            current_block_lines = [line]
        else:
            current_block_lines.append(line)

    if current_block_lines:
        blocks.append({
            "heading": current_heading,
            "lines": current_block_lines,
            "text": "\n".join(current_block_lines),
        })

    # ── 分析每个块 ──
    to_distill = []
    to_keep = []
    to_shared = []  # ★ v4.4: 跨域内容单独收集

    META_HEADINGS = [
        "沟通规范", "运行模式", "当前版本", "架构概览", "长期记忆",
        "批判性思维", "核心操作纪律", "自进化v4", "SKILL相关",
        "已下沉经验索引", "self-evolving-core 记忆规则",  # ★ v4.4: 防止指针区/规则段被再次蒸馏
    ]

    for block in blocks:
        heading_text = block["heading"]
        block_text = block["text"]
        block_lines = len(block["lines"])

        is_meta = (
            block_lines <= 3 or
            any(kw in heading_text for kw in META_HEADINGS) or
            _is_meta_layer(heading_text)
        )

        if is_meta:
            to_keep.append(block)
            continue

        # ★ v4.4: 获取域分类 + 跨域标志
        target_domain, is_cross = _classify_block_to_domain(block_text, domain_map)

        if is_cross:
            # 跨域内容→_shared公共区
            to_shared.append({"block": block, "domain": "_shared"})
        elif target_domain and os.path.isdir(os.path.join(root, "domains", target_domain)):
            to_distill.append({"block": block, "domain": target_domain})
        else:
            to_keep.append(block)

    print(f"\n  分析结果:")
    print(f"  ✅ 保留元层: {len(to_keep)} 个块")
    print(f"  ⬇️  单域下沉: {len(to_distill)} 个块")
    print(f"  🔀 跨域→_shared: {len(to_shared)} 个块\n")

    all_to_move = to_distill + to_shared

    if not all_to_move:
        print(f"  ℹ️  无需蒸馏，MEMORY.md已是精简状态。")
        return

    # ── 展示计划 ──
    for item in all_to_move:
        b = item["block"]
        d = item["domain"]
        label = "[_shared跨域]" if d == "_shared" else f"[{d}]"
        preview = b["text"][:100].replace("\n", " ")
        print(f"  ⬇️  {label} {b['heading']}")
        print(f"       预览: {preview}...")
        print()

    if dry_run:
        print(f"  [预览模式] 以上内容将被下沉，MEMORY.md替换为指针行。")
        print(f"  运行不带 --dry-run 执行实际蒸馏。")
        return

    # ── 执行下沉 ──
    distilled_count = 0
    pointer_lines = []

    for item in all_to_move:
        b = item["block"]
        d = item["domain"]
        scenario = b["heading"].lstrip("#").strip()
        exp_id = _append_experience_to_domain(root, d, scenario, b["text"], "MEMORY.md")
        distilled_count += 1
        domain_label = "_shared(跨域)" if d == "_shared" else d
        pointer_lines.append(
            f"- **{scenario}**: 已下沉到 `domains/{d}/` (id: {exp_id})\n"
        )
        print(f"  ✅ 已下沉 → [{domain_label}] {scenario[:40]} (id: {exp_id})")

    # ── ★ v4.5: 安全写入（置顶区 + 保留元层 + 指针区）──
    kept_text = "\n".join(
        "\n".join(b["lines"]) for b in to_keep
    ).rstrip()

    pointer_section = "\n\n## 📍 已下沉经验索引\n\n" + "".join(pointer_lines) if pointer_lines else ""

    # 置顶区 + 可蒸馏区的保留内容 + 指针区
    if pinned_content:
        new_content = pinned_content + "\n" + kept_text.lstrip("\n") + pointer_section + "\n"
    else:
        new_content = kept_text + pointer_section + "\n"

    new_lines = len(new_content.splitlines())

    success = _safe_write_memory(memory_path, new_content)

    print(f"\n{'=' * 60}")
    if success:
        print(f"  🎉 蒸馏完成!")
        print(f"  下沉条数: {distilled_count}（其中跨域→_shared: {len(to_shared)}条）")
        print(f"  MEMORY.md: {total_lines}行 → {new_lines}行")
        print(f"  目标: <150行 | 当前: {new_lines}行 {'✅' if new_lines <= 150 else '⚠️ 仍超目标，可再次运行'}")
    else:
        print(f"  ❌ 写入失败！MEMORY.md已恢复原内容，请检查磁盘空间。")
    print(f"{'=' * 60}\n")


def _cmd_distill_from_stm(root: str, dry_run: bool = False):
    """★ v4.5: 从short-term-memory.md提炼内容到MEMORY.md

    STM文件结构（新版，顶部写入）：
    ┌─────────────────────────────┐
    │  [新内容区] ← 未蒸馏，AI每次   │
    │  写入时插入到这里最顶部         │
    │                             │
    │  ---                        │
    │  <!-- STM_BOUNDARY -->      │ ← 分界线（提炼后更新此行时间戳）
    │  [已蒸馏区] ← 历史留档         │
    │  [已蒸馏区] ← 不再读取         │
    └─────────────────────────────┘

    提炼逻辑：
    1. 只读取 STM_BOUNDARY 标记**以上**的内容（新内容区）
    2. 提炼到 MEMORY.md 的"元信息层以下"（PINNED_SECTION_END 之后）
    3. 把新内容区清空，更新 STM_BOUNDARY 时间戳（已蒸馏区保留不动）
    4. 节省 Token：不全篇扫描，只处理新内容区
    """
    stm_path = os.path.join(root, ".workbuddy", "memory", "short-term-memory.md")
    memory_path = os.path.join(root, ".workbuddy", "memory", "MEMORY.md")

    if not os.path.exists(stm_path):
        print(f"  ℹ️  short-term-memory.md不存在，无内容可提炼。")
        print(f"     路径: {stm_path}")
        return

    with open(stm_path, "r", encoding="utf-8") as f:
        stm_content = f.read()

    STM_BOUNDARY = "<!-- STM_BOUNDARY:"

    # 找到分界线位置，只读分界线以上的内容
    if STM_BOUNDARY in stm_content:
        boundary_idx = stm_content.index(STM_BOUNDARY)
        # 分界线所在行的行首
        new_section = stm_content[:boundary_idx]
        archived_section = stm_content[boundary_idx:]
    else:
        # 旧格式兼容：没有分界线，全部视为新内容
        new_section = stm_content
        archived_section = ""

    # 过滤有意义的行（去掉空行、纯分隔线、HTML注释、文件头）
    meaningful_lines = [
        l for l in new_section.splitlines()
        if l.strip()
        and l.strip() != "---"
        and not l.startswith("# 短期记忆")
        and not l.strip().startswith("<!--")
    ]

    print(f"\n{'=' * 60}")
    print(f"  📝 短期记忆提炼 {'[预览模式]' if dry_run else '[执行模式]'}")
    print(f"{'=' * 60}")
    print(f"  STM文件: {stm_path}")
    total_lines = len(stm_content.splitlines())
    new_area_lines = len(new_section.splitlines())
    print(f"  总行数: {total_lines} | 新内容区: {new_area_lines} 行 | 待提炼: {len(meaningful_lines)} 行")
    print(f"  ✅ 已蒸馏区不读取（节省Token）")

    if not meaningful_lines:
        print(f"  ℹ️  新内容区为空，无内容可提炼。")
        return

    # 预览待提炼内容
    print(f"\n  待提炼内容预览（前5行）:")
    for l in meaningful_lines[:5]:
        print(f"    {l[:80]}")
    if len(meaningful_lines) > 5:
        print(f"    ... 共{len(meaningful_lines)}行")

    if dry_run:
        print(f"\n  [预览模式] 以上内容将提炼到MEMORY.md的元信息区之后。")
        print(f"  运行不带 --dry-run 执行实际提炼。")
        return

    # ── 将内容插入 MEMORY.md 的置顶区之后 ──
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    insert_block = (
        f"\n## 📥 短期记忆提炼 ({ts})\n\n"
        + "\n".join(meaningful_lines)
        + "\n"
    )

    existing_memory = ""
    if os.path.exists(memory_path):
        with open(memory_path, "r", encoding="utf-8") as f:
            existing_memory = f.read()

    PINNED_END = "<!-- PINNED_SECTION_END -->"
    if PINNED_END in existing_memory:
        # 插入到置顶区之后（紧接 PINNED_SECTION_END 标记后）
        parts = existing_memory.split(PINNED_END, 1)
        new_memory = parts[0] + PINNED_END + insert_block + parts[1].lstrip("\n")
    else:
        # 无置顶标记：追加到文件末尾
        new_memory = existing_memory.rstrip() + insert_block

    success = _safe_write_memory(memory_path, new_memory)

    if success:
        # 清空 STM 新内容区，更新分界线时间戳，已蒸馏区保留
        new_boundary_line = f"<!-- STM_BOUNDARY: 上次提炼 {ts} | {len(meaningful_lines)} 行已提炼到MEMORY.md -->\n"
        # 已蒸馏区 = 旧分界线行 + 旧已蒸馏内容
        if archived_section:
            # 替换第一行（旧分界线）为新时间戳
            old_archive_body = archived_section.split("\n", 1)[1] if "\n" in archived_section else ""
            new_archived = new_boundary_line + old_archive_body
        else:
            new_archived = new_boundary_line

        # STM 文件头（固定不变）
        stm_header = "# 短期记忆（临时缓冲区）\n\n> 新内容请写到分界线以上。提炼命令：`python3 domains/_shared/evolution_guardian.py distill --from-stm`\n\n---\n"
        new_stm = stm_header + new_archived

        with open(stm_path, "w", encoding="utf-8") as f:
            f.write(new_stm)

        print(f"\n  ✅ 提炼完成!")
        print(f"  已提炼 {len(meaningful_lines)} 行到 MEMORY.md（置顶区之后）")
        print(f"  STM 新内容区已清空，历史留档保留")
        mem_lines = len(new_memory.splitlines())
        print(f"  MEMORY.md当前: {mem_lines} 行 {'⚠️ 超150行，建议运行distill蒸馏' if mem_lines > 150 else '✅'}")
    else:
        print(f"\n  ❌ 写入MEMORY.md失败，STM未修改，请重试。")

    print(f"{'=' * 60}\n")


def _cmd_distill_from_daily(root: str, date_str: str = None, dry_run: bool = False):
    """★ v4.5新增: 从每日日志提炼关键内容到STM新内容区

    ★ 这是常规蒸馏流程的【第一步】，不可跳过：
       daily → STM → MEMORY.md → experiences.json

    逻辑：
    1. 读取指定日期（默认今天）的 YYYY-MM-DD.md 日志
    2. 识别「有价值的内容」（任务完成记录、决策、教训），过滤流水账
    3. 生成摘要块，插入到 STM 文件顶部（STM_BOUNDARY 以上的新内容区）
    4. 不修改原日志文件

    用法：
      python3 evolution_guardian.py distill --from-daily              # 今天的日志
      python3 evolution_guardian.py distill --from-daily --date=2026-04-28  # 指定日期
      python3 evolution_guardian.py distill --from-daily --dry-run   # 预览
    """
    memory_dir = os.path.join(root, ".workbuddy", "memory")
    stm_path = os.path.join(memory_dir, "short-term-memory.md")

    # 确定日志文件路径
    if not date_str:
        date_str = datetime.now().strftime("%Y-%m-%d")
    daily_path = os.path.join(memory_dir, f"{date_str}.md")

    print(f"\n{'=' * 60}")
    print(f"  📅 每日日志→STM 提炼 {'[预览模式]' if dry_run else '[执行模式]'}")
    print(f"{'=' * 60}")
    print(f"  日志文件: {daily_path}")
    print(f"  目标STM: {stm_path}")

    if not os.path.exists(daily_path):
        print(f"  ❌ 日志文件不存在: {daily_path}")
        print(f"     可用日志: {[f for f in os.listdir(memory_dir) if f.endswith('.md') and f[0].isdigit()]}")
        return

    with open(daily_path, "r", encoding="utf-8") as f:
        daily_content = f.read()

    daily_lines = daily_content.splitlines()
    print(f"  日志行数: {len(daily_lines)} 行")

    # ── 识别有价值的内容块 ──
    # 规则：以 ## 开头的二级标题块，且内容超过3行（排除空块和流水账标题）
    import re
    value_blocks = []
    current_heading = ""
    current_lines = []

    SKIP_PATTERNS = [
        r"^## session启动",
        r"^## 任务记录\s*$",
        r"^# \d{4}-\d{2}-\d{2}",   # 文件标题行
    ]

    for line in daily_lines:
        if re.match(r'^#{1,3}\s+', line):
            if current_lines and current_heading:
                # 判断是否有价值（内容>3行且不全是空行）
                content_lines = [l for l in current_lines if l.strip()]
                is_skip = any(re.match(pat, current_heading, re.IGNORECASE) for pat in SKIP_PATTERNS)
                if len(content_lines) >= 3 and not is_skip:
                    value_blocks.append({
                        "heading": current_heading,
                        "lines": current_lines,
                        "text": "\n".join(current_lines),
                    })
            current_heading = line
            current_lines = [line]
        else:
            current_lines.append(line)

    # 处理最后一个块
    if current_lines and current_heading:
        content_lines = [l for l in current_lines if l.strip()]
        is_skip = any(re.match(pat, current_heading, re.IGNORECASE) for pat in SKIP_PATTERNS)
        if len(content_lines) >= 3 and not is_skip:
            value_blocks.append({
                "heading": current_heading,
                "lines": current_lines,
                "text": "\n".join(current_lines),
            })

    print(f"  识别到有价值块: {len(value_blocks)} 个")

    if not value_blocks:
        print(f"  ℹ️  未识别到有价值的内容块（所有块内容<3行或全为流水账）")
        print(f"     可手动把重要内容复制到 short-term-memory.md 顶部")
        return

    # 预览
    print(f"\n  待提炼块：")
    for b in value_blocks:
        preview = b["text"].replace("\n", " ")[:80]
        print(f"    [{b['heading'][:40]}] → {preview}...")

    if dry_run:
        print(f"\n  [预览模式] 以上内容将插入 STM 新内容区顶部。")
        print(f"  运行不带 --dry-run 执行实际提炼。")
        return

    # ── 插入到 STM 新内容区顶部 ──
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    insert_text = f"## 📅 来自 {date_str} 日志（提炼于 {ts}）\n\n"
    for b in value_blocks:
        insert_text += b["text"].rstrip() + "\n\n"

    # 读取现有STM
    if os.path.exists(stm_path):
        with open(stm_path, "r", encoding="utf-8") as f:
            stm_content = f.read()
    else:
        # STM不存在时自动创建
        stm_content = f"# 短期记忆（临时缓冲区）\n\n<!-- 新内容写到分界线以上 -->\n\n---\n<!-- STM_BOUNDARY: 初始化 {ts} -->\n"

    STM_BOUNDARY = "<!-- STM_BOUNDARY:"

    if STM_BOUNDARY in stm_content:
        # 插入到分界线之前（新内容区顶部）
        boundary_idx = stm_content.index(STM_BOUNDARY)
        # 找到分界线所在行的行首（确保插到行前）
        line_start = stm_content.rfind("\n", 0, boundary_idx) + 1
        new_stm = (
            stm_content[:line_start]
            + insert_text
            + stm_content[line_start:]
        )
    else:
        # 无分界线：追加到末尾
        new_stm = stm_content.rstrip() + "\n\n" + insert_text

    with open(stm_path, "w", encoding="utf-8") as f:
        f.write(new_stm)

    stm_lines = len(new_stm.splitlines())
    print(f"\n  ✅ 提炼完成!")
    print(f"  已插入 {len(value_blocks)} 个块到 STM 新内容区顶部")
    print(f"  STM当前: {stm_lines} 行")
    print(f"  下一步: 运行 distill --from-stm 将 STM 内容提炼到 MEMORY.md")
    print(f"{'=' * 60}\n")


# ===== 主入口 =====

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    command = sys.argv[1].lower()

    if command == "log":
        if len(sys.argv) < 4:
            print("用法: evolution_guardian.py log <domain> '<task>' <result> [error_type] [error_cat] [tokens] [duration] [--lesson='教训']")
            sys.exit(1)
        # ★ v4.5: 支持 --lesson="..." 参数（自动写经验+免疫规则）
        lesson_arg = ""
        positional = []
        for a in sys.argv[2:]:
            if a.startswith("--lesson="):
                lesson_arg = a.split("=", 1)[1].strip().strip("'\"")
            else:
                positional.append(a)
        cmd_log(
            positional[0] if len(positional) > 0 else "",
            positional[1] if len(positional) > 1 else "",
            positional[2] if len(positional) > 2 else "success",
            positional[3] if len(positional) > 3 else "",
            positional[4] if len(positional) > 4 else "",
            positional[5] if len(positional) > 5 else 0,
            positional[6] if len(positional) > 6 else 0,
            lesson=lesson_arg,
        )

    elif command == "check":
        if len(sys.argv) < 3:
            print(f"用法: evolution_guardian.py check <domain>")
            sys.exit(1)
        cmd_check(sys.argv[2])

    elif command == "feedback":
        if len(sys.argv) < 6:
            print("用法: evolution_guardian.py feedback <agent> <type> <severity> '<phrase>' '<context>'")
            sys.exit(1)
        cmd_feedback(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])

    elif command == "review":
        if len(sys.argv) < 3:
            print(f"用法: evolution_guardian.py review <domain>")
            sys.exit(1)
        cmd_review(sys.argv[2])

    elif command == "evolve":
        if len(sys.argv) < 3:
            print(f"用法: evolution_guardian.py evolve <domain> [reason]")
            sys.exit(1)
        cmd_evolve(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "")

    elif command == "status":
        if len(sys.argv) < 3:
            print("用法: evolution_guardian.py status <domain>")
            sys.exit(1)
        cmd_check(sys.argv[2])  # status ≈ check for now

    elif command in ("experience-update", "exp-update"):
        # ★ v4.2新增: 经验生命周期管理
        # 用法: experience-update <domain> <old_id> <deprecate|supersede> [new_id]
        if len(sys.argv) < 5:
            print("用法: evolution_guardian.py experience-update <domain> <old_id> <deprecate|supersede> [new_id]")
            print("示例:")
            print("  # 废弃错误经验:")
            print("  evolution_guardian.py experience-update data exp_001 deprecate")
            print("  # 标记被新经验替代:")
            print("  evolution_guardian.py experience-update data exp_001 supersede exp_002")
            sys.exit(1)
        new_id = sys.argv[5] if len(sys.argv) > 5 else None
        cmd_experience_update(sys.argv[2], sys.argv[3], new_id, sys.argv[4])

    elif command == "distill":
        # ★ v4.3+v4.5: 三段式蒸馏流程
        # 常规流程：
        #   distill --from-daily  → 每日日志→STM（第一步）
        #   distill --from-stm    → STM→MEMORY.md（第二步）
        #   distill               → MEMORY.md→experiences.json（第三步，仅应急）
        memory_path_arg = None
        dry_run_arg = False
        from_stm_arg = False
        from_daily_arg = False
        date_arg = None
        for arg in sys.argv[2:]:
            if arg == "--dry-run":
                dry_run_arg = True
            elif arg == "--from-stm":
                from_stm_arg = True
            elif arg == "--from-daily":
                from_daily_arg = True
            elif arg.startswith("--date="):
                date_arg = arg.split("=", 1)[1].strip()
            elif not arg.startswith("--"):
                memory_path_arg = arg

        if from_daily_arg:
            root = _find_project_root()
            _cmd_distill_from_daily(root, date_str=date_arg, dry_run=dry_run_arg)
        else:
            cmd_distill(memory_path=memory_path_arg, dry_run=dry_run_arg, from_stm=from_stm_arg)

    elif command in ("archive-logs", "archive_logs"):
        # ★ v4.4: 日志归档（默认15天，不删除，移到archive/）
        days_arg = 15
        for arg in sys.argv[2:]:
            if arg.startswith("--days="):
                try:
                    days_arg = int(arg.split("=")[1])
                except ValueError:
                    pass
        cmd_archive_logs(days=days_arg)

    else:
        print(f"未知命令: {command}")
        print("可用命令: log | check | evolve | feedback | review | status | experience-update | distill | archive-logs")
        print("蒸馏三段式: distill --from-daily → distill --from-stm → distill")
        sys.exit(1)


if __name__ == "__main__":
    main()
