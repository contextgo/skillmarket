#!/usr/bin/env python3
"""
任务前经验检索（Pre-Task Check）— Self-Evolving-Core v4.2

每次任务执行前调用，自动检索历史相关经验，
让Agent不重复踩坑、直接复用已验证方案。

用法:
  # 旧模式(Agent模式，向后兼容)
  python3 pre_task_check.py --agent admin --task "数据清洗任务"

  # ★ 大一统新模式(Domain模式，推荐)
  python3 pre_task_check.py --domain data --task "分析销售数据生成报表"
  python3 pre_task_check.py --domain product --task "撰写产品需求文档"

输出:
  - JSON格式的历史相关经验列表（仅返回status=active的经验）
  - 推荐的最优操作路径（如果有的话）
  - 需要避开的坑

集成方式:
  在agent的IDENTITY.md或工作流程中植入：
  "每个新任务开始前必须执行 pre_task_check.py"
"""

import json
import os
import sys
import argparse
from datetime import datetime, timezone

# 添加父目录到路径以导入memory_core
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from memory_core import MemoryCore


# === ★ v3.3: Domain模式路径解析 ===

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_ROOT = os.path.dirname(SCRIPT_DIR)
# scripts → self-evolving-core → skills → .workbuddy → 项目根目录(4级上)
_CLAW_ROOT_CANDIDATE = os.path.dirname(os.path.dirname(os.path.dirname(SKILL_ROOT)))
CLAW_ROOT = os.environ.get("CLAW_ROOT", _CLAW_ROOT_CANDIDATE)
DOMAINS_ROOT = os.path.join(CLAW_ROOT, "domains")


def resolve_evo_dir(domain: str = None, agent: str = None, agent_dir: str = None) -> tuple:
    """
    ★ v3.3: 统一路由解析函数
    
    优先级: domain模式 > agent_dir参数 > agent名称推导
    
    Returns:
        (evo_dir, mode_string) — 经验目录路径 + 模式标识
    """
    if domain:
        # Domain模式: domains/{domain}/
        evo_dir = os.path.join(DOMAINS_ROOT, domain)
        if not os.path.exists(evo_dir):
            return (None, f"domain_not_found:{domain}")
        return (evo_dir, f"domain:{domain}")
    
    if agent_dir and os.path.exists(agent_dir):
        # 显式指定了agent_dir
        evo_dir = os.path.join(agent_dir, "self-evolution")
        return (evo_dir, f"agent_dir:{agent_dir}")
    
    if agent:
        # Agent模式: agents/{agent}/self-evolution/
        agent_path = os.path.join(CLAW_ROOT, "agents", agent)
        if os.path.exists(agent_path):
            evo_dir = os.path.join(agent_path, "self-evolution")
            return (evo_dir, f"agent:{agent}")
        return (None, f"agent_not_found:{agent}")
    
    # 默认admin
    evo_dir = os.path.join(CLAW_ROOT, "agents", "admin", "self-evolution")
    return (evo_dir, "agent:admin(default)")


def get_exp_filename(evo_dir: str) -> str:
    """
    ★ v3.3: 根据目录格式自动检测经验文件名
    
    Domain模式用 experiences.json，Agent模式用 experiences_v2.json
    """
    # 优先检查 domain 格式
    domain_exp = os.path.join(evo_dir, "experiences.json")
    if os.path.exists(domain_exp):
        # 验证是否是 domain 格式（有 schema_version + domain 字段）
        try:
            with open(domain_exp, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if "domain" in data or "schema_version" in data:
                return "experiences.json"
        except (json.JSONDecodeError, IOError):
            pass
    
    # 回退到 agent 格式
    agent_exp = os.path.join(evo_dir, "experiences_v2.json")
    if os.path.exists(agent_exp):
        return "exp_v2"
    
    # 都不存在时：如果在domains/下用新格式，否则用旧格式
    if "/domains/" in evo_dir:
        return "experiences.json"
    return "exp_v2"


def run_pre_task_check(agent_dir: str = "", agent_name: str = "admin", task: str = "",
                       keywords: list = None, context: str = "",
                       domain: str = None) -> dict:
    """
    执行任务前检查

    Args:
        agent_dir: agent目录（向后兼容，优先级低于domain）
        agent_name: agent名称
        task: 当前任务描述
        keywords: 用户提供的额外关键词
        context: 额外上下文
        domain: ★ v3.3 Domain模式 — 传入领域名如 "data"/"product"

    Returns:
        检查结果字典
    """
    # ★ v3.3: 统一路由解析，支持domain模式
    evo_dir, mode_str = resolve_evo_dir(domain=domain, agent=agent_name if not domain else None,
                                         agent_dir=agent_dir if agent_dir else None)

    if not evo_dir or not os.path.exists(evo_dir):
        return {
            "has_relevant": False,
            "reason": f"自进化目录不存在: {evo_dir} (mode: {mode_str})",
            "experiences": [],
            "recommended_path": None,
            "pitfalls": [],
            "facts": [],
            "confidence": 0.0,
            "mode": mode_str,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    # 确定经验文件名（自动检测 domain/agent 格式）
    exp_filename = get_exp_filename(evo_dir)
    display_name = domain or agent_name or "unknown"

    # ★ v3.3修复: 将检测到的文件名传给MemoryCore（否则Domain模式的experiences.json永远不被读取）
    mc = MemoryCore(evo_dir, display_name, experiences_file=exp_filename if exp_filename != "exp_v2" else None)
    
    # 构建搜索查询
    query = task
    if keywords:
        query += " " + " ".join(keywords)
    if context:
        query += " " + context
    
    # 搜索：优先找L2程序性经验（最有用），其次L1和L3
    results_l2 = mc.search(query, top_k=5, layer_filter=["L2"])
    results_l1 = mc.search(query, top_k=3, layer_filter=["L1"])
    results_l3 = mc.search(query, top_k=3, layer_filter=["L3"])
    all_results = results_l2 + results_l1 + results_l3
    
    # 提取推荐路径和坑
    recommended_path = None
    pitfalls = []
    facts = []
    
    for exp in all_results:
        # L2 → 提取推荐步骤
        if exp["layer"] == "L2" and exp.get("proven") and exp.get("steps"):
            if not recommended_path or exp["relevance_score"] > recommended_path.get("score", 0):
                recommended_path = {
                    "scenario": exp["scenario"],
                    "steps": exp["steps"],
                    "attempts_before_success": exp.get("attempts_before_success", 0),
                    "success_count": exp.get("success_count", 0),
                    "source_task": exp.get("source_task", ""),
                    "exp_id": exp["id"],
                    "score": exp["relevance_score"]
                }
                # 标记为已使用
                mc.mark_used(exp["id"])
        
        # L2/L3 → 提取失败的坑
        for fail in exp.get("failed_approaches", []):
            if fail and fail not in pitfalls:
                pitfalls.append(fail)
        for pattern in exp.get("error_patterns", []):
            if pattern and pattern not in pitfalls:
                pitfalls.append(pattern)
        
        # L1 → 提取事实知识
        if exp["layer"] == "L1" and exp.get("fact"):
            facts.append({
                "fact": exp["fact"],
                "category": exp.get("category", ""),
                "relevance": exp.get("relevance_score", 0)
            })
    
    # 计算整体置信度
    confidence = 0.0
    if recommended_path:
        confidence += min(0.7, 0.3 + recommended_path["success_count"] * 0.1)
    if facts:
        confidence += 0.15
    if pitfalls:
        confidence += 0.15
    confidence = min(1.0, confidence)
    
    # ★ v3.1: 反向拦截——检查用户打算用的方法是否在已知失败列表中
    blocked_warnings = mc.check_failed_approaches(query, top_k=3)
    if blocked_warnings:
        confidence = min(1.0, confidence + 0.2)  # 有拦截信息=更有价值
        # 把拦截方法加入pitfalls
        for w in blocked_warnings:
            method_desc = f"⛔ {w['blocked_method']} ({w['severity']}: {w['reason']})"
            if method_desc not in pitfalls:
                pitfalls.insert(0, method_desc)  # 放在最前面
    
    result = {
        "has_relevant": len(all_results) > 0 or len(blocked_warnings) > 0,
        "query": query,
        "experience_count": len(all_results),
        "l2_count": len(results_l2),
        "l1_count": len(results_l1),
        "l3_count": len(results_l3),
        "experiences": all_results[:8],  # 返回前8条最相关的
        "recommended_path": recommended_path,
        "pitfalls_to_avoid": pitfalls,
        "facts": facts,
        "confidence": round(confidence, 2),
        "blocked_warnings": blocked_warnings,  # ★ v3.1 新增
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "action_suggestion": _generate_action_suggestion(recommended_path, pitfalls, confidence, blocked_warnings)
    }
    
    return result


def _generate_action_suggestion(recommended_path, pitfalls, confidence, blocked_warnings=None) -> str:
    """生成自然语言行动建议"""
    # ★ v3.1: 拦截警告优先级最高
    if blocked_warnings:
        high_severity = [w for w in blocked_warnings if w['severity'] == 'HIGH']
        if high_severity:
            w = high_severity[0]
            alt = " → ".join(w["suggested_alternative"]) if w.get("suggested_alternative") else "参考推荐路径"
            return f"⛔ 拦截：'{w['blocked_method']}' 已验证失败！{alt}。{('' if not recommended_path else '')}"
    
    if not recommended_path and not pitfalls:
        return "未找到历史相关经验，按标准流程执行即可。"
    
    parts = []
    
    if recommended_path:
        steps_str = " → ".join(recommended_path["steps"][:5])
        sc = recommended_path.get("success_count", 0)
        verify_note = f"({sc}次验证)" if sc > 1 else ""
        parts.append(f"✅ 推荐{verify_note}: {steps_str}")
    
    if pitfalls:
        pit_str = ", ".join(pitfalls[:4])
        parts.append(f"⚠️ 避开: {pit_str}")
    
    if confidence >= 0.7:
        parts.insert(0, "🎯 高置信度建议 — 建议直接按推荐方案执行")
    elif confidence >= 0.4:
        parts.insert(0, "📋 中等匹配 — 参考推荐方案，结合实际情况调整")
    else:
        parts.insert(0, "💭 低匹配 — 有参考价值但不完全确定适用")
    
    return " | ".join(parts)


def main():
    parser = argparse.ArgumentParser(description="任务前经验检索 (v3.3 支持Domain模式)")
    parser.add_argument("--agent-dir", default="", help="Agent目录路径")
    parser.add_argument("--agent", default="admin", help="Agent名称")
    parser.add_argument("--domain", default=None, help="★ v3.3 领域名: data/product/ux/test")
    parser.add_argument("--task", required=True, help="当前任务描述")
    parser.add_argument("--keywords", default="", help="逗号分隔的关键词")
    parser.add_argument("--context", default="", help="额外上下文信息")
    parser.add_argument("--json-only", action="store_true", help="只输出JSON")

    args = parser.parse_args()

    # ★ v3.3: 优先使用domain模式，否则回退到agent模式
    keywords = [k.strip() for k in args.keywords.split(",") if k.strip()] if args.keywords else []

    result = run_pre_task_check(
        agent_dir=args.agent_dir or None,
        agent_name=args.agent,
        task=args.task,
        keywords=keywords,
        context=args.context,
        domain=args.domain
    )

    display_name = args.domain or args.agent

    if args.json_only:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        exp_count = result.get('experience_count', 0)
        l2_count = result.get('l2_count', 0)
        l1_count = result.get('l1_count', 0)
        l3_count = result.get('l3_count', 0)
        confidence = result.get('confidence', 0)
        ts = result.get('timestamp', '')[:19]
        mode = result.get('mode', f"agent:{args.agent}")

        print("=" * 60)
        print(f"\U0001f50d 任务前经验检索 [{display_name}] ({mode})")
        print(f"   任务: {args.task}")
        print(f"   时间: {ts}")
        print(f"   匹配: {exp_count}条经验 (L2:{l2_count} L1:{l1_count} L3:{l3_count})")
        print(f"   置信度: {confidence*100:.0f}%")
        print("=" * 60)

        print(f"\n\U0001f4cb 行动建议:")
        print(f"   {result['action_suggestion']}")
        
        if result["recommended_path"]:
            rp = result["recommended_path"]
            print(f"\n✅ 推荐方案 ({rp['scenario']}):")
            for i, step in enumerate(rp["steps"], 1):
                print(f"   {i}. {step}")
            if rp.get("attempts_before_success", 0) > 0:
                print(f"   💡 该方案经过{rp['attempts_before_success']}次试错后验证成功")
        
        if result["pitfalls_to_avoid"]:
            print(f"\n⚠️ 历史踩过的坑（请避开）:")
            for p in result["pitfalls_to_avoid"]:
                print(f"   ❌ {p}")
        
        if result["facts"]:
            print(f"\n📚 相关事实知识:")
            for f in result["facts"]:
                print(f"   • [{f['category']}] {f['fact'][:80]}")
        
        print("\n--- 完整JSON数据 ---")
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
