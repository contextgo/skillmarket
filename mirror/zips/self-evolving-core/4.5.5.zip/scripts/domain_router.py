#!/usr/bin/env python3
"""
大一统Agent架构 — 领域路由器 v4.5.4 (Domain Router)
====================================================
v4.5.4 变更：
  - 输出末尾自动追加结构化"任务完成后必做"清单（log/distill 现成命令）
  - JSON 新增 next_actions 字段（机器可读）
  - CLI 末尾追加 ⏰ 提示块（人类可读，蠢模型也能看到）

v4.0 变更：内嵌经验检索 + 免疫规则预检 + 自进化协议集成

核心功能：
  接收用户输入 → 匹配领域 → 加载角色快照 + 相关经验 + 免疫规则 → 输出执行上下文 → 强制收尾任务

使用方式：
  python3 domains/_shared/domain_router.py "用户输入的任务描述"

输出：
  JSON格式 + 末尾「⏰ 任务完成后请执行」结构化收尾任务清单
"""

import json
import os
import sys
import re
from pathlib import Path
from datetime import datetime

# === 配置 ===
DOMAINS_ROOT = Path(__file__).parent.parent  # domains/
SHARED_DIR = DOMAINS_ROOT / "_shared"
INDEX_FILE = SHARED_DIR / "index.json"
CONFIG_FILE = SHARED_DIR / "evo-config.json"
TOP_K_EXPERIENCES = 5  # 检索时返回最相关的K条经验


# ============================================================
# 第一层：基础加载函数
# ============================================================

def load_index():
    """加载全局索引"""
    with open(INDEX_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_config():
    """加载全局进化配置"""
    if not CONFIG_FILE.exists():
        return None
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_role_snapshot(domain: str) -> dict:
    """加载指定领域的角色快照"""
    snapshot_file = DOMAINS_ROOT / domain / "role-snapshot.json"
    if not snapshot_file.exists():
        return None
    with open(snapshot_file, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_experiences(domain: str, query_keywords: list = None, top_k: int = TOP_K_EXPERIENCES) -> list:
    """
    加载指定领域的经验数据（v4.0增强版）
    支持三种模式：
      1. domain="data" → 加载 domains/data/experiences.json
      2. domain="_shared" → 加载 domains/_shared/admin-experiences.json
    如果提供query_keywords，按相关性排序返回top_k
    """
    # _shared 域用 admin-experiences 文件
    if domain == "_shared":
        exp_file = SHARED_DIR / "admin-experiences.json"
    else:
        exp_file = DOMAINS_ROOT / domain / "experiences.json"

    if not exp_file.exists():
        return []

    with open(exp_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    all_experiences = data.get('experiences', [])

    # ★ v4.2: 只检索 active 状态的经验（deprecated/superseded 的不参与检索）
    # 兼容旧数据：没有 status 字段的视为 active
    experiences = [
        e for e in all_experiences
        if e.get('status', 'active') == 'active'
    ]

    # 如果没有关键词查询，返回全部 active（按confidence降序）
    if not query_keywords:
        experiences.sort(key=lambda x: x.get('confidence', 0), reverse=True)
        return experiences[:top_k]

    # 关键词匹配评分（BM25简化版）
    MIN_RELEVANCE_SCORE = 1.5  # ★ v4.2: 相关性阈值，低于此分数的不返回给AI
    scored = []
    for exp in experiences:
        exp_keywords = exp.get('keywords', [])
        scenario = exp.get('scenario', '')
        fact = exp.get('fact', '')
        confidence = exp.get('confidence', 0)
        score = 0

        for qk in query_keywords:
            qk_lower = qk.lower()
            # 关键词精确匹配(权重高)
            for ek in exp_keywords:
                if qk_lower in ek.lower():
                    score += 3
            # 场景文本部分匹配(权重中)
            if qk_lower in scenario.lower():
                score += 2
            # 事实/步骤文本匹配(权重低)
            fact_text = fact or json.dumps(exp.get('steps', []), ensure_ascii=False)
            if qk_lower in fact_text.lower():
                score += 1

        # 置信度加权
        score = score * (0.5 + confidence * 0.5)
        scored.append((score, exp))

    # 按分数降序排列，取top_k，且过滤掉相关性不足的（宁可返回0条也不返回不相关的）
    scored.sort(key=lambda x: x[0], reverse=True)
    return [exp for score, exp in scored[:top_k] if score >= MIN_RELEVANCE_SCORE]


def load_immune_rules(domain: str) -> list:
    """
    加载指定领域的免疫规则（v4.0新增）
    返回该domain下所有免疫规则列表
    """
    rules_file = DOMAINS_ROOT / domain / "immune_rules.json"
    if not rules_file.exists():
        return []

    with open(rules_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    return data.get('rules', [])


# ============================================================
# 第二层：分类与检索
# ============================================================

def classify_input(user_input: str, index: dict) -> tuple:
    """
    分类用户输入到最匹配的领域
    返回 (domain_name, match_score, matched_keywords)
    """
    input_lower = user_input.lower()
    results = []

    for domain_name, domain_info in index.get("domains", {}).items():
        trigger_keywords = domain_info.get("trigger_keywords", [])
        anti_keywords = domain_info.get("anti_trigger_keywords", [])

        # 反触发词检查（命中则大幅降分）
        anti_score = 0
        for ak in anti_keywords:
            if ak.lower() in input_lower:
                anti_score -= 2

        # 正向关键词匹配
        pos_score = 0
        matched = []
        for tk in trigger_keywords:
            if tk.lower() in input_lower:
                pos_score += 1
                matched.append(tk)

        total_score = pos_score + anti_score
        results.append((domain_name, total_score, matched))

    # 排序取最高分
    results.sort(key=lambda x: x[1], reverse=True)
    best_domain, best_score, best_matched = results[0]

    # 阈值：至少匹配1个关键词才算命中
    if best_score <= 0:
        return None, 0, []

    return best_domain, best_score, best_matched


def check_immune_rules(user_input: str, domain: str) -> list:
    """
    检查用户输入是否触发免疫规则（v4.0新增 — 内嵌pre_task_check核心逻辑）

    对比用户输入与当前域的免疫规则触发模式，
    返回所有被触发的规则列表（按severity排序）。
    这是轻量级预检，不需要调用外部脚本。
    """
    if not domain:
        return []

    rules = load_immune_rules(domain)
    if not rules:
        return []

    input_lower = user_input.lower()
    triggered = []

    for rule in rules:
        patterns = rule.get('trigger_pattern', [])
        triggered_count = 0
        for pattern in patterns:
            if pattern.lower() in input_lower:
                triggered_count += 1

        # 至少命中1个触发词才算触发
        if triggered_count > 0:
            triggered.append({
                "id": rule.get('id'),
                "scenario": rule.get('scenario'),
                "rule": rule.get('rule'),
                "severity": rule.get('severity', 'info'),
                "source_lesson": rule.get('source_lesson', ''),
                "triggered_patterns": triggered_count,
                "effective_since": rule.get('effective_since', '')
            })

    # 按严重程度排序: critical > warning > info
    severity_order = {'critical': 0, 'warning': 1, 'info': 2}
    triggered.sort(key=lambda r: severity_order.get(r['severity'], 9))

    return triggered


# ============================================================
# 第三层：路由主函数
# ============================================================

def route(user_input: str, verbose: bool = True) -> dict:
    """
    主路由函数 v4.0：用户任务 → 完整执行上下文

    新增输出字段：
      immune_rules_triggered: 触发的免疫规则列表（内嵌预检结果）
      pre_task_warnings: 预检警告信息
      evolution_protocol: 自进化协议提示
    """
    index = load_index()
    config = load_config()

    # Step 1: 分类
    domain, score, matched = classify_input(user_input, index)

    # Step 2: 加载角色快照
    snapshot = None
    if domain:
        snapshot = load_role_snapshot(domain)

    # Step 3: 加载相关经验（域专属 + 跨域共享）
    experiences = []
    admin_experiences = []
    if domain:
        experiences = load_experiences(domain, matched if matched else None)
    # 始终加载admin通用经验（跨域共享，top_3控制量）
    admin_experiences = load_experiences("_shared", matched if matched else None, top_k=3)

    # Step 4: 免疫规则预检（v4.0新增 — 内嵌pre_task_check核心逻辑）
    triggered_rules = check_immune_rules(user_input, domain)

    # Step 5: 组装完整结果
    result = {
        "timestamp": datetime.now().isoformat(),
        "input": user_input,
        "routing": {
            "matched_domain": domain,
            "match_score": score,
            "matched_keywords": matched,
            "confidence": "high" if score >= 3 else "medium" if score >= 1 else "low"
        },
        "role": {
            "name": snapshot.get("role_name", "大总管(默认)") if snapshot else "大总管(默认)",
            "identity": snapshot.get("core_identity", "") if snapshot else "",
            "responsibilities": snapshot.get("responsibilities", []) if snapshot else [],
            "forbidden_actions": snapshot.get("forbidden_actions", []) if snapshot else [],
            "key_methods": snapshot.get("key_methods", {}) if snapshot else {},
            "work_principles": snapshot.get("work_principles", []) if snapshot else []
        } if snapshot else None,
        "experiences": {
            "domain_specific": [
                {
                    "id": e.get("id"),
                    "scenario": e.get("scenario"),
                    "layer": e.get("layer"),
                    "hint": (e.get("fact") or json.dumps(e.get("steps", []), ensure_ascii=False))[:300],
                    "confidence": e.get("confidence")
                }
                for e in experiences
            ],
            "cross_domain_shared": [
                {
                    "id": e.get("id"),
                    "scenario": e.get("scenario"),
                    "hint": (e.get("fact") or json.dumps(e.get("steps", []), ensure_ascii=False))[:200]
                }
                for e in admin_experiences
            ]
        },
        # ====== v4.0 新增字段 ======
        "immune_rules_triggered": [
            {
                "id": r["id"],
                "scenario": r["scenario"],
                "rule": r["rule"],
                "severity": r["severity"],
                "source": r.get("source_lesson", "")
            }
            for r in triggered_rules
        ] if triggered_rules else [],
        "pre_task_warnings": generate_preTaskWarnings(triggered_rules),
        "evolution_protocol": generate_evolutionProtocol(domain, config),
        # ===========================
        "execution_advice": generate_executionAdvice(domain, snapshot, experiences, triggered_rules),
        "next_actions": generate_next_actions(user_input, domain, triggered_rules),
        "file_references": {
            "role_snapshot": f"domains/{domain}/role-snapshot.json" if domain else None,
            "experiences": f"domains/{domain}/experiences.json" if domain else None,
            "immune_rules": f"domains/{domain}/immune_rules.json" if domain else None,
            "memory": f"domains/{domain}/memory.json" if domain else None,
            "templates": [f"domains/{domain}/templates/"] if domain and (DOMAINS_ROOT / domain / "templates").exists() else [],
            "rules": [f"domains/{domain}/rules/"] if domain and (DOMAINS_ROOT / domain / "rules").exists() else []
        }
    }

    return result


# ============================================================
# 第四层：辅助生成函数
# ============================================================

def generate_executionAdvice(domain, snapshot, experiences, triggered_rules=None) -> str:
    """生成执行建议（v4.0增强：加入免疫规则警告）"""
    advice_parts = []

    if domain and snapshot:
        role_name = snapshot.get("role_name", "")
        advice_parts.append(f"以「{role_name}」身份执行此任务")

        principles = snapshot.get("work_principles", [])
        if principles:
            advice_parts.append(f"遵循原则: {' | '.join(principles[:3])}")

        forbidden = snapshot.get("forbidden_actions", [])
        if forbidden:
            advice_parts.append(f"禁止操作: {', '.join(forbidden[:3])}")

    # v4.0新增：免疫规则警告优先显示
    if triggered_rules:
        critical_rules = [r for r in triggered_rules if r.get('severity') == 'critical']
        if critical_rules:
            rule_texts = [f"[P0] {r['scenario']}: {r['rule']}" for r in critical_rules]
            advice_parts.append(f"⚠️ 免疫规则警告:\n  " + "\n  ".join(rule_texts))

    if experiences:
        relevant_scenarios = [e.get("scenario", "") for e in experiences[:3]]
        if relevant_scenarios:
            advice_parts.append(f"可参考经验: {', '.join(relevant_scenarios)}")

    if not advice_parts:
        advice_parts.append("使用默认身份(大总管)直接执行")

    return "\n".join(advice_parts)


def generate_preTaskWarnings(triggered_rules: list) -> list:
    """根据触发生成预检警告列表"""
    if not triggered_rules:
        return []

    warnings = []
    for r in triggered_rules:
        severity_icon = {"critical": "🔴", "warning": "🟡", "info": "🔵"}
        icon = severity_icon.get(r.get('severity', 'info'), '⚪')
        warnings.append(
            f"{icon} [{r.get('severity').upper()}] {r['scenario']}: {r['rule']}"
        )
        if r.get('source_lesson'):
            warnings.append(f"   └─ 教训来源: {r['source_lesson']}")

    return warnings


def generate_next_actions(user_input: str, domain: str, triggered_rules: list = None) -> dict:
    """
    ★ v4.5.4 新增：生成结构化「任务完成后必做」清单。

    AI 看到 Router 输出的同时，就同步看到现成的 log 命令（已填好域名+任务摘要），
    复制即用，杜绝"忘记 log"。
    """
    # 任务摘要：取前40字（防止命令过长）
    task_brief = (user_input or "").strip().replace('"', "'").replace("\n", " ")
    if len(task_brief) > 40:
        task_brief = task_brief[:40] + "..."

    inferred_domain = domain or "_shared"
    has_critical = any(r.get('severity') == 'critical' for r in (triggered_rules or []))

    actions = {
        "phase": "post_task_mandatory",
        "headline": "⏰ 任务完成后必做（不可跳过）",
        "primary_command": (
            f'python3 ./domains/_shared/evolution_guardian.py log {inferred_domain} '
            f'"{task_brief}" success'
        ),
        "primary_command_failed_template": (
            f'python3 ./domains/_shared/evolution_guardian.py log {inferred_domain} '
            f'"{task_brief}" failed <error_type> <error_category>'
        ),
        "with_lesson_template": (
            f'python3 ./domains/_shared/evolution_guardian.py log {inferred_domain} '
            f'"{task_brief}" success --lesson "<新经验/教训一句话>"'
        ),
        "checks": [
            "1️⃣ 任务成功 → 复制 primary_command 直接执行",
            "2️⃣ 任务失败 → 用 primary_command_failed_template 填 error_type/category",
            "3️⃣ 学到新经验 → 用 with_lesson_template 一步写经验+免疫规则",
        ],
        "remember": (
            "log 命令内置 R1-R4 阈值自检，每次记账后自动检测进化触发条件。"
            "不 log = 系统失明、记忆爆炸、重复犯错。"
        ),
    }

    if has_critical:
        actions["extra_warning"] = (
            "🔴 已触发 critical 免疫规则，强烈建议任务完成后立刻 log + --lesson 巩固经验"
        )

    return actions


def generate_evolutionProtocol(domain: str, config: dict = None) -> dict:
    """生成本次任务应遵循的自进化协议提示"""
    protocol = {
        "enabled": True if config and config.get("self_evolution_enabled") else False,
        "version": "4.0",
        "actions_required": []
    }

    if not protocol["enabled"]:
        return protocol

    # 任务开始前（Pre-task）
    protocol["actions_required"].append({
        "phase": "pre_task",
        "action": "router_auto_retrieve",
        "description": "✅ 已完成：Router自动检索了相关经验和免疫规则",
        "status": "auto_completed"
    })

    # 任务完成后（Post-task）
    protocol["actions_required"].append({
        "phase": "post_task",
        "action": "log_task_result",
        "description": "记录任务结果到 memory.json（统计+历史）",
        "target_file": f"domains/{domain}/memory.json" if domain else None
    })
    protocol["actions_required"].append({
        "phase": "post_task",
        "action": "extract_experience",
        "description": "如有新经验，追加到 experiences.json",
        "target_file": f"domains/{domain}/experiences.json" if domain else None
    })
    protocol["actions_required"].append({
        "phase": "on_negative_feedback",
        "action": "record_feedback",
        "description": "如收到负面反馈，记录到 evo-feedback.json",
        "target_file": "domains/_shared/evo-feedback.json"
    })

    return protocol


# ============================================================
# CLI入口
# ============================================================

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Domain Router v4.5.4 — 大一统自进化架构")
        print("=" * 50)
        print("Usage: python3 domain_router.py \"任务描述\"")
        print("\n示例:")
        print('  python3 domain_router.py "帮我看一下PRD v2.1需要改什么地方"')
        print('  python3 domain_router.py "查一下最近的销售数据情况"')
        print('  python3 domain_router.py "批量处理Excel数据并生成汇总报表"')
        print("\nv4.5.4 新功能:")
        print("  - 末尾自动追加「⏰ 任务完成后必做」结构化收尾任务")
        print("  - JSON 新增 next_actions 字段（机器可读 + 人类可读）")
        print("\nv4.0 功能:")
        print("  - 内嵌经验检索（自动匹配相关经验）")
        print("  - 免疫规则预检（自动触发避坑警告）")
        print("  - 自进化协议提示（任务前后自动提醒）")
        sys.exit(1)

    user_input = sys.argv[1]
    result = route(user_input)

    # 输出JSON结果
    print(json.dumps(result, ensure_ascii=False, indent=2))

    # ★ v4.5.4: 末尾追加结构化「任务完成后必做」提示块（人类/AI 可读）
    next_actions = result.get("next_actions") or {}
    if next_actions:
        print()
        print("=" * 70)
        print(next_actions.get("headline", "⏰ 任务完成后必做"))
        print("=" * 70)
        print()
        print("✅ 任务成功 → 直接复制执行：")
        print(f"   {next_actions.get('primary_command', '')}")
        print()
        print("❌ 任务失败 → 用此模板（替换 <error_type>/<error_category>）：")
        print(f"   {next_actions.get('primary_command_failed_template', '')}")
        print()
        print("🧠 学到新经验 → 一步写经验+免疫规则：")
        print(f"   {next_actions.get('with_lesson_template', '')}")
        print()
        for chk in next_actions.get("checks", []):
            print(f"   {chk}")
        if next_actions.get("extra_warning"):
            print()
            print(f"   {next_actions['extra_warning']}")
        print()
        print(f"💡 {next_actions.get('remember', '')}")
        print("=" * 70)
