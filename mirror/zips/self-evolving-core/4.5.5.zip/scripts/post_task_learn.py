#!/usr/bin/env python3
"""
任务后自动学习（Post-Task Learn）— Self-Evolving-Core v4.2

每次任务完成后调用，自动从结果中提取有价值的信息，
存入四层记忆系统，确保下次遇到同类问题不再踩坑。

用法:
  # 旧模式(Agent模式，向后兼容)
  python3 post_task_learn.py --agent admin --task "数据清洗任务" \
    --result success \
    --lessons "pandas处理大文件时分块读取效率更高" \
    --failed "直接read_csv内存溢出" \
    --tokens 50000 --duration 120

  # ★ v4.2 大一统新模式(Domain模式，推荐)
  python3 post_task_learn.py --domain data --task "月度销售报表生成" \
    --result success --lessons "先按类目聚合再透视，速度提升3倍" --tokens 30000 --duration 60

集成方式:
  在evolution-guardian的log命令后追加调用，或植入agent工作流：
  "每个任务结束后必须执行 post_task_learn.py"
"""

import json
import os
import sys
import argparse
import re
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from memory_core import MemoryCore


# === ★ v3.3: Domain模式路径解析（与pre_task_check共享同一套路由）===

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_SKILL_ROOT = os.path.dirname(_SCRIPT_DIR)
# scripts → self-evolving-core → skills → .workbuddy → 项目根目录(4级上)
_CLAW_ROOT_CANDIDATE = os.path.dirname(os.path.dirname(os.path.dirname(_SKILL_ROOT)))
CLAW_ROOT = os.environ.get("CLAW_ROOT", _CLAW_ROOT_CANDIDATE)
DOMAINS_ROOT = os.path.join(CLAW_ROOT, "domains")


def resolve_evo_dir(domain: str = None, agent: str = None, agent_dir: str = None) -> tuple:
    """★ v3.3: 统一路由 — domain模式 > agent_dir > agent名称 > 默认admin"""
    if domain:
        evo_dir = os.path.join(DOMAINS_ROOT, domain)
        if not os.path.exists(evo_dir):
            return (None, f"domain_not_found:{domain}")
        return (evo_dir, f"domain:{domain}")
    if agent_dir and os.path.exists(agent_dir):
        return (os.path.join(agent_dir, "self-evolution"), f"agent_dir:{agent_dir}")
    if agent:
        agent_path = os.path.join(CLAW_ROOT, "agents", agent)
        if os.path.exists(agent_path):
            return (os.path.join(agent_path, "self-evolution"), f"agent:{agent}")
        return (None, f"agent_not_found:{agent}")
    return (os.path.join(CLAW_ROOT, "agents", "admin", "self-evolution"), "agent:admin(default)")


def get_exp_filename(evo_dir: str) -> str:
    """★ v3.3: 自动检测经验文件格式（domain=experiences.json, agent=experiences_v2.json）"""
    domain_exp = os.path.join(evo_dir, "experiences.json")
    if os.path.exists(domain_exp):
        try:
            with open(domain_exp, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if "domain" in data or "schema_version" in data:
                return "experiences.json"
        except (json.JSONDecodeError, IOError):
            pass
    if os.path.exists(os.path.join(evo_dir, "experiences_v2.json")):
        return "exp_v2"
    return "experiences.json" if "/domains/" in evo_dir else "exp_v2"


def run_post_task_learn(agent_dir: str = "", agent_name: str = "admin", task: str = "",
                        result: str = "", lessons: str = "", failed_methods: str = "",
                        tokens: int = 0, duration_sec: float = 0,
                        context: str = "",
                        auto_extract: bool = True,
                        domain: str = None) -> dict:
    """
    执行任务后学习（v3.3 支持Domain模式）

    Args:
        agent_dir: agent目录（向后兼容，优先级低于domain）
        agent_name: agent名称
        task: 任务描述
        result: success / partial / failed
        lessons: 经验教训
        failed_methods: 失败方法
        tokens: Token消耗
        duration_sec: 耗时秒数
        context: 完整任务上下文
        auto_extract: 是否自动智能提取
        domain: ★ v3.3 领域名
    """
    # ★ v3.3: 统一路由解析
    evo_dir, mode_str = resolve_evo_dir(domain=domain, agent=agent_name if not domain else None,
                                         agent_dir=agent_dir if agent_dir else None)

    if not evo_dir or not os.path.exists(evo_dir):
        return {"status": "error", "reason": f"目录不存在: {evo_dir} (mode: {mode_str})"}

    display_name = domain or agent_name or "unknown"
    # ★ v3.3修复: 将检测到的文件名传给MemoryCore
    _exp_fn = get_exp_filename(evo_dir)
    mc = MemoryCore(evo_dir, display_name, experiences_file=_exp_fn if _exp_fn != "exp_v2" else None)
    
    recorded_ids = []
    recorded_layers = []
    
    if auto_extract and lessons:
        # 智能提取：将自然语言经验分类到L1/L2/L3
        
        # 1. 检测是否包含步骤性信息 → L2程序性记忆
        step_indicators = ["步骤", "流程", "先", "然后", "接着", "最后", 
                          "->", "→", "第1", "1.", "2.", "3."]
        is_procedural = any(ind in lessons for ind in step_indicators)
        
        # 2. 检测是否包含事实信息 → L1陈述性记忆
        fact_indicators = ["URL=", "url是", "格式为", "参数是", "配置",
                           "地址", "端点", "api:", "http"]
        has_facts = any(ind in lessons.lower() for ind in fact_indicators)
        
        # 3. 检测是否包含关联/因果信息 → L3语义记忆
        semantic_indicators = ["因为", "由于", "导致", "原因", "关联", 
                              "映射", "对应", "意味着"]
        has_semantic = any(ind in lessons for ind in semantic_indicators)
        
        if is_procedural or (not has_facts and not has_semantic):
            # 主要作为L2存储
            steps = [s.strip() for s in _split_lessons(lessons) if s.strip()]
            failed = [f.strip() for f in failed_methods.split(",") if f.strip()] if failed_methods else []
            
            eid = mc.store_l2(
                scenario=task[:80],
                steps=steps,
                proven=(result == "success"),
                failed_approaches=failed,
                attempts=len(failed),
                source_task=task,
                tags=["auto-extracted-from-task"],
                error_patterns=[f"失败:{f}" for f in failed] if failed else []
            )
            recorded_ids.append(eid)
            recorded_layers.append("L2")
        
        if has_facts:
            # 提取L1事实
            fact_parts = _extract_fact_parts(lessons)
            for fp in fact_parts:
                eid = mc.store_l1(
                    fact=fp,
                    category="auto-extracted",
                    keywords=_extract_keywords(task),
                    scenario=f"来自任务: {task[:40]}"
                )
                recorded_ids.append(eid)
                recorded_layers.append("L1")
        
        if has_semantic:
            # 提取L3语义关联
            eid = mc.store_l3(
                concept=f"任务经验:{task[:40]}",
                associations=_extract_associations(lessons),
                error_patterns=[f"失败:{f}" for f in failed_methods.split(",") if f.strip()] if failed_methods else [],
                root_cause=_extract_root_cause(lessons),
                keywords=_extract_keywords(task + " " + lessons),
                scenario=task[:80]
            )
            recorded_ids.append(eid)
            recorded_layers.append("L3")
    
    else:
        # 非自动模式：直接用learn_from_task
        eid = mc.learn_from_task(
            task=task, result=result, 
            lessons=lessons, failed_methods=failed_methods,
            tokens=tokens, duration_sec=duration_sec
        )
        if eid:
            recorded_ids.append(eid)
            recorded_layers.append(mc._experiences[-1]["layer"] if mc._experiments else "?")
    
    stats = mc.stats()
    
    # ★ v3.1: 自动同步关键经验到 IDENTITY.md 核心经验速查区块（双保险机制）
    # 注意：domain模式下不需要同步到agent IDENTITY.md（因为可能没有）
    sync_result = {"synced": False, "reason": "domain模式跳过IDENTITY同步"}
    if not domain:
        sync_result = _sync_critical_to_identity(mc, evo_dir, display_name, max_items=5)

    # ★ v3.2: 自动生成MD镜像文件（人工可读版本）
    md_result = _generate_md_mirror(evo_dir)

    return {
        "status": "success",
        "task": task,
        "result": result,
        "context": context[:500] if context else "(未提供完整上下文)",
        "recorded_count": len(recorded_ids),
        "recorded_ids": recorded_ids,
        "layers_used": list(set(recorded_layers)),
        "memory_stats": stats,
        "identity_sync": sync_result,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }


# ==================== v3.2: MD镜像生成 ====================

def _generate_md_mirror(evo_dir: str) -> dict:
    """
    从经验库自动生成MD镜像文件（人工可读版本）。
    MD版本用于人工阅读和核对，JSON保持程序可读。
    每次post_task_learn调用后自动同步。

    ★ v3.3: 自动检测domain/agent格式，生成对应的MD镜像
        - domain模式 → experiences.json → experiences.md (无v2后缀)
        - agent模式 → experiences_v2.json → experiences_v2.md
    """
    result = {"generated": False}

    # ★ v3.3: 动态检测JSON源文件
    domain_json = os.path.join(evo_dir, "experiences.json")
    agent_json = os.path.join(evo_dir, "experiences_v2.json")

    if os.path.exists(domain_json):
        json_path = domain_json
        md_path = os.path.join(evo_dir, "experiences.md")
    elif os.path.exists(agent_json):
        json_path = agent_json
        md_path = os.path.join(evo_dir, "experiences_v2.md")
    else:
        return {**result, "reason": "JSON不存在"}

    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    experiences = data.get('experiences', [])
    total = len(experiences)
    last_updated = data.get('last_updated', '')

    LAYER_ICONS = {"L1": "📌", "L2": "🔧", "L3": "🧠", "L4": "⚡"}
    CONF_MAP = {
        1.0: "█████", 0.99: "████▊", 0.97: "████▎", 0.95: "███▊ ",
        0.92: "███░ ", 0.9: "██▊  ", 0.8: "██░  ",
        0.7: "█▊   ", 0.65: "█░   ", 0.6: "▊    "
    }

    lines = [
        f"# 经验库",
        f"> 共 **{total}** 条经验 | 更新: {str(last_updated)[:19] if last_updated else '?'}",
        "",
        "---",
        ""
    ]

    by_layer = {}
    for exp in experiences:
        layer = exp.get('layer', '?')
        by_layer.setdefault(layer, []).append(exp)

    for layer in sorted(by_layer.keys()):
        exps = by_layer[layer]
        icon = LAYER_ICONS.get(layer, '📋')
        lines.append(f"## {icon} {layer} 层 — {len(exps)} 条")
        lines.append("")

        for i, exp in enumerate(exps):
            scenario = exp.get('scenario', '(无标题)')
            conf = exp.get('confidence', 0)
            bar = CONF_MAP.get(conf, '?' * 5)
            tags = exp.get('tags', [])
            tag_str = ', '.join(tags) if tags else ''
            proven = exp.get('proven')
            source = exp.get('source_task', '')

            meta_parts = [f"ID: `{exp.get('id', f'#{i}')}`"]
            meta_parts.append(f"置信度: `{conf}` {bar}")
            if tag_str:
                meta_parts.append(f"标签: {tag_str}")
            if proven:
                meta_parts.append("✅ 已验证")
            if source:
                meta_parts.append(f"来源: *{source}*")

            lines.append(f"### {i+1}. {scenario}")
            lines.append(
                f"<details><summary>📋 {' | '.join(meta_parts)}</summary>"
            )
            lines.append("")

            fact = exp.get('fact', '')
            if fact:
                lines.append(f"> **事实**: {fact}")
                lines.append("")

            cat = exp.get('category', '')
            if cat:
                lines.append(f"- 分类: `{cat}`")

            kws = exp.get('keywords', [])
            if kws:
                lines.append(f"- 关键词: {' / '.join(kws)}")

            steps = exp.get('steps', [])
            if steps:
                lines.append("")
                lines.append("**操作步骤**:")
                for s in steps:
                    lines.append(f"  {s}")

            failed = exp.get('failed_approaches', [])
            if failed:
                lines.append("")
                lines.append("**❌ 失败方法(已排除)**:")
                for fa in failed:
                    lines.append(f"  - ~~{fa}~~")

            epats = exp.get('error_patterns', [])
            if epats:
                lines.append("")
                lines.append("**⚠️ 错误模式**:")
                for e in epats:
                    lines.append(f"  - `{e}`")

            rc = exp.get('root_cause', '')
            if rc:
                lines.append("")
                lines.append(f"**根因**: {rc}")

            sc = exp.get('success_count')
            attempts = exp.get('attempts_before_success') or exp.get('attempts')
            if sc is not None or attempts is not None:
                parts = []
                if attempts:
                    parts.append(f"尝试{attempts}次后成功")
                if sc:
                    parts.append(f"累计成功{sc}次")
                lines.append(f"*{' · '.join(parts)}*")

            lines.append("</details>")
            lines.append("")

    lines.append("---")
    src_name = os.path.basename(json_path)
    lines.append(f"*自动生成 | 源文件: {src_name}*")

    try:
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))
        result["generated"] = True
        result["path"] = md_path
        result["size"] = os.path.getsize(md_path)
    except Exception as e:
        result["error"] = str(e)

    return result


# ==================== v3.1: 身份同步（双保险机制）====================

def _sync_critical_to_identity(mc, agent_dir: str, agent_name: str, max_items: int = 5) -> dict:
    """
    将最重要的经验同步到 IDENTITY.md 的"核心经验速查"区块。
    
    这是v3.1的双保险机制：
    - 路径1: pre_task_check.py 动态搜索完整经验库
    - 路径2: 这里将critical经验硬编码到IDENTITY.md前部 → 即使路径1被跳过也能保底
    
    只同步 proven=True 或 tags含 critical/best-practice 的L2经验，
    以及所有含error_patterns的条目。
    """
    result = {"synced": False, "count": 0, "items": []}
    
    # 确定IDENTITY.md路径
    identity_path = os.path.join(agent_dir, agent_name, "IDENTITY.md") if os.path.basename(agent_dir) != agent_name else os.path.join(agent_dir, "IDENTITY.md")
    
    if not os.path.exists(identity_path):
        result["reason"] = f"IDENTITY.md不存在: {identity_path}"
        return result
    
    # 收集需要同步的经验
    critical_exps = []
    all_exps = mc.get_all() if hasattr(mc, 'get_all') else (mc._experiments if hasattr(mc, '_experiments') else [])
    
    for exp in (all_exps if isinstance(all_exps, list) else []):
        # 优先级筛选
        is_critical = (
            exp.get("proven", False) or 
            "critical" in exp.get("tags", []) or
            "best-practice" in exp.get("tags", []) or
            exp.get("layer") == "L2" and exp.get("success_count", 0) >= 1
        )
        if not is_critical:
            continue
        
        # 构建一行经验文本
        line = _format_exp_as_line(exp)
        if line:
            critical_exps.append({
                "id": exp.get("id", ""),
                "line": line,
                "score": exp.get("success_count", 0) * 10 + (5 if exp.get("proven") else 0),
                "timestamp": exp.get("timestamp", "")
            })
    
    # 按重要性排序，取最新的max_items条
    critical_exps.sort(key=lambda x: (x["score"], x["timestamp"]), reverse=True)
    selected = critical_exps[:max_items]
    
    if not selected:
        result["reason"] = "没有足够重要的经验可同步"
        return result
    
    # 读取并更新 IDENTITY.md
    try:
        with open(identity_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # 找到 AUTO_SYNC 区块并替换内容
        sync_start_tag = "<!-- AUTO_SYNC_START:"
        sync_end_tag = "<!-- AUTO_SYNC_END -->"

        start_idx = content.find(sync_start_tag)
        if start_idx == -1:
            result["reason"] = "未找到AUTO_SYNC_START标记"
            return result

        end_idx = content.find(sync_end_tag)
        if end_idx == -1:
            result["reason"] = "未找到AUTO_SYNC_END标记"
            return result

        # 保留START标记所在行（从start_idx到第一个\n）
        line_end = content.find("\n", start_idx)
        if line_end == -1:
            line_end = len(content)
        start_line = content[start_idx:line_end]

        # 构造新内容：START标记行 + 经验列表 + END标记
        lines = []
        for item in selected:
            lines.append(f"- {item['line']}")
        new_block = start_line + "\n"
        if lines:
            new_block += "\n".join(lines) + "\n"
        else:
            new_block += "<!-- 暂无关键经验积累，继续使用后会自动填充 -->\n"
        new_block += sync_end_tag + "\n"

        # 替换整个区块（从start_idx到end_idx + len(sync_end_tag)）
        end_pos = end_idx + len(sync_end_tag)
        if end_pos < len(content) and content[end_pos] == '\n':
            end_pos += 1
        content = content[:start_idx] + new_block + content[end_pos:]

        with open(identity_path, 'w', encoding='utf-8') as f:
            f.write(content)

        result["synced"] = True
        result["count"] = len(selected)
        result["items"] = [item["line"] for item in selected]

    except Exception as e:
        result["error"] = str(e)

    return result


def _format_exp_as_line(exp: dict) -> str:
    """将一条经验格式化为IDENTITY中的一行文本"""
    layer = exp.get("layer", "?")
    
    if layer == "L2" and exp.get("steps"):
        steps_str = " → ".join(exp.get("steps", [])[:3])
        scenario = exp.get("scenario", "")[:30]
        tags = ""
        if exp.get("failed_approaches"):
            tags = f" | ❌避免: {', '.join(exp['failed_approaches'][:2])}"
        return f"[{scenario}] {steps_str}{tags}"
    
    elif layer == "L1" and exp.get("fact"):
        fact = exp.get("fact", "")
        category = exp.get("category", "")
        return f"[{category}] {fact}" if category else fact
    
    elif layer == "L3" and exp.get("error_patterns"):
        patterns = ", ".join(exp["error_patterns"][:2])
        root = exp.get("root_cause", "")
        return f"⚠️ {patterns}" + (f" (根因:{root})" if root else "")
    
    elif exp.get("failed_approaches"):
        return f"❌ 避免: {', '.join(exp['failed_approaches'][:2])}"
    
    return None  # 无法格式化


# ==================== 自然语言解析工具 ====================

def _split_lessons(text: str) -> list:
    """将自然语言经验文本拆分为步骤/要点"""
    # 尝试各种分隔符
    for sep in ["。", "；", ";", "|", "，,", " -> ", " → ", " then "]:
        if sep in text:
            parts = text.split(sep)
            if len(parts) >= 2 and all(p.strip() for p in parts):
                return parts
    return [text]

def _extract_fact_parts(text: str) -> list:
    """从文本中提取事实陈述"""
    facts = []
    sentences = re.split(r'[,，;；|]', text)
    for s in sentences:
        s = s.strip()
        if len(s) > 5 and ("=" in s or "是" in s or "为" in s or "http" in s.lower() or "url" in s.lower()):
            facts.append(s)
    return facts

def _extract_associations(text: str) -> list:
    """从文本中提取概念关联"""
    associations = []
    # 简单的模式匹配（通用的因果/依赖关系）
    patterns = [
        r'(.+?)因为(.+)',
        r'(.+?)由于(.+)',
        r'(.+?)导致(.+)',
        r'(.+?)需要(.+)',
        r'(.+?)依赖(.+)',
    ]
    for pat in patterns:
        m = re.search(pat, text)
        if m:
            associations.append({"from": m.group(1).strip(), "to": m.group(2).strip()})
    return associations

def _extract_root_cause(text: str) -> str:
    """提取根因"""
    cause_patterns = [
        r'根因[是为：:\s]*(.+?)[。，]',
        r'因为(.+?)[。，]',
        r'由于(.+?)[。，]',
        r'原因是?(.+?)[。，]'
    ]
    for pat in cause_patterns:
        m = re.search(pat, text)
        if m:
            return m.group(1).strip()
    return ""

def _extract_keywords(text: str) -> list:
    """简单关键词提取（通用技术词白名单）"""
    words = set(re.findall(r'[\w\u4e00-\u9fff]{2,}', text))
    tech_keywords = {
        'python', 'javascript', 'typescript', 'java', 'go', 'rust',
        'api', 'url', 'json', 'yaml', 'xml', 'html', 'css',
        'sql', 'database', 'pandas', 'numpy', 'excel', 'csv',
        'docker', 'kubernetes', 'git', 'http', 'https', 'rest', 'graphql',
        'pytest', 'jest', 'unittest', 'mock',
        'subprocess', 'shlex', 'regex', 'eval',
    }
    result = [w for w in words if w.lower() in tech_keywords or len(w) >= 2]
    return list(result)[:15]


def main():
    parser = argparse.ArgumentParser(description="任务后自动学习 (v3.3 支持Domain模式)")
    parser.add_argument("--agent-dir", default="", help="Agent目录")
    parser.add_argument("--agent", default="admin", help="Agent名称")
    parser.add_argument("--domain", default=None, help="★ v3.3 领域名: data/product/ux/test")
    parser.add_argument("--task", required=True, help="任务描述")
    parser.add_argument("--result", required=True, choices=["success", "partial", "failed"], help="结果")
    parser.add_argument("--lessons", default="", help="经验教训")
    parser.add_argument("--failed", default="", help="失败方法（逗号分隔）")
    parser.add_argument("--tokens", type=int, default=0, help="Token消耗")
    parser.add_argument("--duration", type=float, default=0, help="耗时秒数")
    parser.add_argument("--no-auto", action="store_true", help="禁用自动智能提取")
    parser.add_argument("--context", default="", help="完整任务上下文，v3.2新增")
    parser.add_argument("--json-only", action="store_true", help="只输出JSON")

    args = parser.parse_args()

    # ★ v3.3: domain模式优先
    result = run_post_task_learn(
        agent_dir=args.agent_dir or None,
        agent_name=args.agent,
        task=args.task,
        result=args.result,
        lessons=args.lessons,
        failed_methods=args.failed,
        tokens=args.tokens,
        duration_sec=args.duration,
        context=args.context,
        auto_extract=not args.no_auto,
        domain=args.domain
    )

    display_name = args.domain or args.agent

    if args.json_only:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("=" * 60)
        icon = "✅" if args.result == "success" else "⚠️" if args.result == "partial" else "❌"
        print(f"{icon} 任务后学习 [{display_name}]")
        print(f"   任务: {args.task}")
        print(f"   结果: {args.result}")
        print(f"   记录: {result.get('recorded_count', 0)}条 ({', '.join(result.get('layers_used', []))})")
        print("=" * 60)
        
        if result.get("recorded_ids"):
            print(f"\n📝 已记录的经验:")
            for i, (eid, layer) in enumerate(zip(result["recorded_ids"], result["layers_used"])):
                print(f"   {i+1}. [{layer}] {eid}")
        
        stats = result.get("memory_stats", {})
        print(f"\n📊 记忆库状态:")
        print(f"   总计: {stats.get('total', 0)}条 | L1:{stats.get('L1_declarative', 0)} L2:{stats.get('L2_procedural', 0)} L3:{stats.get('L3_semantic', 0)}")
        print(f"   历史复用次数: {stats.get('total_reuses', 0)}")
        
        print("\n--- 完整JSON ---")
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
