# Self-Evolving-Core 使用指南 v4.5.4

> **一句话**：让 Agent 从每次任务中自动积累经验，同样的坑只踩一次。

---

## 设计理念

```
任务来了 → Router 自动检索历史经验 + 预警已知坑 → 带着经验执行
任务完了 → Guardian 记账 + 自动检测是否需要总结进化
每日结束 → distill --from-daily 提炼日志 → STM → MEMORY.md
```

**两个核心角色**：

| 脚本 | 职责 |
|------|------|
| `domain_router.py` | 接任务时调：分析任务属于哪个域，自动加载该域的经验和免疫规则 |
| `evolution_guardian.py` | 完成任务后调：记账、统计、检测是否触发进化；日常蒸馏记忆 |

---

## 快速上手（三步）

### 第一步：部署（仅首次）

```bash
python3 {SKILL_PATH}/scripts/upgrade_agent.py --deploy
```

脚本会**自动分析你的工作空间**（历史记忆/目录/Agent配置），推断出你的业务领域，生成专属的域配置，并整理 MEMORY.md 规则配置。无需手动定义域。

### 第二步：每次任务前调 Router

```bash
python3 domains/_shared/domain_router.py "任务描述"
```

返回：匹配的域 + 相关历史经验 + 免疫规则警告。Agent 据此以正确角色执行任务。

### 第三步：每次任务后调 Guardian

```bash
python3 domains/_shared/evolution_guardian.py log <域名> "任务描述" <success|failed|partial>
```

Guardian 会自动检测四条进化规则，达到条件时输出行动指令：

| 规则 | 触发条件 | 系统输出 |
|------|---------|---------|
| R1 定期复盘 | 累计每 **10 次**任务 | 📊 建议 review |
| R2 错误免疫 | 同类任务**连续失败 3 次** | 🔴 立即 review + 写免疫规则 |
| R3 反馈响应 | 收到**任意 1 条**负面反馈 | ⚠️ 立即 evolve |
| R4 记忆治理 | MEMORY.md 超 **150 行** | 📋 运行 distill |

> 只要坚持执行 log，进化检测**100% 自动**，无需额外操作。

---

## ★ 三段式记忆蒸馏流程（不可跳步！）

这是 v4.5 最核心的新机制：

```
每日日志 (YYYY-MM-DD.md)
    ↓  distill --from-daily      ← ★ 第一步，每日必做
short-term-memory.md 新内容区   ← 顶部写入，STM_BOUNDARY分界
    ↓  distill --from-stm        ← 第二步，STM积累时做
MEMORY.md 元层（置顶区之后）     ← PINNED_SECTION_END保护核心规范
    ↓  distill                   ← ⚠️ 第三步，仅MEMORY.md超限应急
domains/*/experiences.json       ← 具体经验最终归宿
```

**日常命令**：

```bash
# ★ 每日结束时（常规必做）
python3 domains/_shared/evolution_guardian.py distill --from-daily

# STM积累到一定量时提炼到MEMORY.md
python3 domains/_shared/evolution_guardian.py distill --from-stm

# 仅在MEMORY.md超过150行时使用（应急）
python3 domains/_shared/evolution_guardian.py distill --dry-run  # 先预览
python3 domains/_shared/evolution_guardian.py distill
```

**MEMORY.md 结构**：
```
<!-- PINNED_SECTION_END --> 以上 = 置顶保护区（核心规范，永不蒸馏）
------------------------分界线------------------------
以下 = 可蒸馏区（项目信息、架构说明等，distill时处理）
```

**STM 文件结构**：
```
[新内容区] ← AI每次有新内容，插入到分界线以上
<!-- STM_BOUNDARY: 时间戳 --> ← 分界线
[已蒸馏区] ← 历史留档，蒸馏时不读取（节省Token）
```

---

## 域是什么

域 = 你工作的一个业务方向。每个域独立存储：
- `experiences.json` — 这个方向上积累的可复用经验（含status生命周期）
- `immune_rules.json` — 这个方向上踩过的坑，Router 自动预警
- `memory.json` — 任务统计（总次数/成功率/连续错误检测/类型分布）

**部署时自动推断，开箱即用，用多了越来越准。**

---

## 日常命令速查

```bash
# 任务前：路由 + 获取经验
python3 domains/_shared/domain_router.py "我要做什么"

# 任务后：记账（支持多种结果）
python3 domains/_shared/evolution_guardian.py log <域> "任务" success
python3 domains/_shared/evolution_guardian.py log <域> "任务" failed timeout "错误类型"

# 收到用户负面反馈时
python3 domains/_shared/evolution_guardian.py feedback admin negative strong "触发词" "上下文"

# 查看域状态（含经验数/免疫规则/任务分布）
python3 domains/_shared/evolution_guardian.py check <域>

# 记忆蒸馏（三段式，按顺序）
python3 domains/_shared/evolution_guardian.py distill --from-daily
python3 domains/_shared/evolution_guardian.py distill --from-stm
python3 domains/_shared/evolution_guardian.py distill  # 仅应急

# 日志归档（每月）
python3 domains/_shared/evolution_guardian.py archive-logs

# 架构检测
python3 {SKILL_PATH}/scripts/upgrade_agent.py --detect
```

---

## 经验怎么写进去

Guardian 的 `log` 只做统计，经验内容由 Agent 在任务结束后手动追加到 `domains/<域>/experiences.json`：

```json
{
  "id": "唯一ID（如 exp_20260429_001）",
  "status": "active",
  "layer": "L2",
  "scenario": "任务场景名（简洁描述）",
  "keywords": ["关键词1", "关键词2"],
  "steps": ["步骤1", "步骤2"],
  "insight": "核心教训，一句话",
  "confidence": 0.9,
  "proven_count": 1,
  "superseded_by": null,
  "updated_at": "2026-04-29"
}
```

**L 层含义**：L1 = 事实性知识 | L2 = 操作步骤（最常用）| L3 = 规律洞察

## 发现经验有误怎么办

**不要修改或删除旧经验**，而是用 `experience-update` 命令废弃它：

```bash
# 发现经验有错，直接废弃
python3 domains/_shared/evolution_guardian.py experience-update <域> <old_id> deprecate

# 有更准确的新经验替代旧经验
python3 domains/_shared/evolution_guardian.py experience-update <域> <old_id> supersede <new_id>
```

废弃的经验不参与检索，但历史记录保留（可审查、可回滚）。

---

## 老用户迁移（已有 agents/ 目录）

```bash
python3 {SKILL_PATH}/scripts/upgrade_agent.py --detect           # 先检测当前架构
python3 {SKILL_PATH}/scripts/upgrade_agent.py --migrate-to-domain  # 迁移到新架构
```

原 `agents/` 目录保留不删，历史经验自动迁移到对应域。

---

## 常见问题

**Q: 域名怎么知道？**  
A: `--detect` 或 `check` 都会显示当前所有域名。路由输出的 `matched_domain` 就是域名。

**Q: 路由匹配不到怎么办？**  
A: 输出 `matched_domain: null`，以通用身份执行即可。多用几次后可手动给域补充触发关键词。

**Q: 经验什么时候真正起作用？**  
A: `experiences.json` 有内容后，下次路由时自动检索并输出。第一次使用是冷启动，正常。

**Q: MEMORY.md 超限了怎么办？**  
A: 先运行 `distill --dry-run` 预览，再运行 `distill` 执行。注意：这是应急操作，正常流程是 from-daily → from-stm。

---

*v4.5.4 | 依赖 Python ≥3.8，无第三方包*

**两个核心角色**：

| 脚本 | 职责 |
|------|------|
| `domain_router.py` | 接任务时调：分析任务属于哪个域，自动加载该域的经验和免疫规则 |
| `evolution_guardian.py` | 完成任务后调：记账、统计、检测是否触发进化 |

---

## 快速上手（三步）

### 第一步：部署（仅首次）

```bash
python3 {SKILL_PATH}/scripts/upgrade_agent.py --deploy
```

脚本会**自动分析你的工作空间**（历史记忆/目录/Agent配置），推断出你的业务领域，生成专属的域配置。无需手动定义域。

### 第二步：每次任务前调 Router

```bash
python3 domains/_shared/domain_router.py "任务描述"
```

返回：匹配的域 + 相关历史经验 + 免疫规则警告。Agent 据此以正确角色执行任务。

### 第三步：每次任务后调 Guardian

```bash
python3 domains/_shared/evolution_guardian.py log <域名> "任务描述" <success|failed|partial>
```

Guardian 会自动检测三条进化规则，达到条件时输出行动指令：

| 规则 | 触发条件 | 系统输出 |
|------|---------|---------|
| 定期复盘 | 累计每 **10 次**任务 | 📊 建议 review |
| 错误免疫 | 同类任务**连续失败 3 次** | 🔴 立即 review + 写免疫规则 |
| 反馈响应 | 收到**任意 1 条**负面反馈 | ⚠️ 立即 evolve |

> 只要坚持执行 log，进化检测**100% 自动**，无需额外操作。

---

## 域是什么

域 = 你工作的一个业务方向。每个域独立存储：
- `experiences.json` — 这个方向上积累的可复用经验
- `immune_rules.json` — 这个方向上踩过的坑，Router 自动预警
- `memory.json` — 任务统计（总次数/成功率/连续错误检测）

**部署时自动推断，开箱即用，用多了越来越准。**

---

## 日常命令速查

```bash
# 任务前：路由 + 获取经验
python3 domains/_shared/domain_router.py "我要做什么"

# 任务后：记账（支持多种结果）
python3 domains/_shared/evolution_guardian.py log <域> "任务" success
python3 domains/_shared/evolution_guardian.py log <域> "任务" failed timeout "错误类型"

# 收到用户负面反馈时
python3 domains/_shared/evolution_guardian.py feedback admin negative strong "触发词" "上下文"

# 查看域状态（含经验数/免疫规则/任务分布）
python3 domains/_shared/evolution_guardian.py check <域>

# 架构检测（不确定当前状态时）
python3 {SKILL_PATH}/scripts/upgrade_agent.py --detect
```

---

## 经验怎么写进去

Guardian 的 `log` 只做统计，经验内容由 Agent 在任务结束后手动追加到 `domains/<域>/experiences.json`：

```json
{
  "id": "唯一ID（如 exp_20260429_001）",
  "status": "active",
  "layer": "L2",
  "scenario": "任务场景名（简洁描述）",
  "keywords": ["关键词1", "关键词2"],
  "steps": ["步骤1", "步骤2"],
  "insight": "核心教训，一句话",
  "confidence": 0.9,
  "proven_count": 1,
  "superseded_by": null,
  "updated_at": "2026-04-29"
}
```

**L 层含义**：L1 = 事实性知识 | L2 = 操作步骤（最常用）| L3 = 规律洞察

**写入前先检索**：追加新经验前，先用 Router 搜索类似场景，确认没有现有经验可以更新。避免同类知识重复堆积。

## 发现经验有误怎么办

**不要修改或删除旧经验**，而是用 `experience-update` 命令废弃它：

```bash
# 发现经验有错，直接废弃
python3 domains/_shared/evolution_guardian.py experience-update <域> <old_id> deprecate

# 有更准确的新经验替代旧经验
python3 domains/_shared/evolution_guardian.py experience-update <域> <old_id> supersede <new_id>
```

废弃的经验不参与检索，但历史记录保留（可审查、可回滚）。这样避免了"相悖经验同时出现在检索结果里"的问题。

---

## 老用户迁移（已有 agents/ 目录）

```bash
python3 {SKILL_PATH}/scripts/upgrade_agent.py --detect    # 先检测当前架构
python3 {SKILL_PATH}/scripts/upgrade_agent.py --migrate-to-domain  # 迁移到新架构
```

原 `agents/` 目录保留不删，历史经验自动迁移到对应域。

---

## 常见问题

**Q: 域名怎么知道？**  
A: `--detect` 或 `check` 都会显示当前所有域名。路由输出的 `matched_domain` 就是域名。

**Q: 路由匹配不到怎么办？**  
A: 输出 `matched_domain: null`，以通用身份执行即可。多用几次后可手动给域补充触发关键词到 `domains/_shared/index.json`。

**Q: 经验什么时候真正起作用？**  
A: `experiences.json` 有内容后，下次路由时自动检索并输出。第一次使用是冷启动，正常。

---

*v4.2 | 依赖 Python ≥3.8，无第三方包*
