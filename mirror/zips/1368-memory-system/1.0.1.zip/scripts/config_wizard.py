#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神系统 - 配置向导
===================================
1元3维6层8面体记忆系统的配置向导

配置流程（8步骤）：
1. L0 阈值配置
2. L1/L2/L3 阈值配置
3. 向量搜索配置
4. 初始化目录 + Embedding配置
5. 历史数据回溯
6. L1/L2/L3提取
7. 索引构建
8. 启动L0监听
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 加载.env配置文件
def load_env_file():
    """从configs/.env.local加载环境变量"""
    env_path = os.path.join(os.path.dirname(__file__), '..', 'configs', '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key.strip()] = value.strip()

load_env_file()

try:
    from paths_config import WORKSPACE, MEMORY_1368
    SKILL_DIR = os.path.dirname(os.path.dirname(__file__))
except ImportError:
    SKILL_DIR = "/root/.openclaw/workspace/main/skills/1368元神记忆系统"
    WORKSPACE = "/root/.openclaw/workspace/main"
    MEMORY_1368 = os.path.join(WORKSPACE, "memory", "1368-memory")

class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def print_banner():
    print(f"""
{Colors.BOLD}{'='*60}
  1368元神系统 — 配置向导
  1元3维6层8面体记忆系统
{'='*60}{Colors.ENDC}
""")

def print_step(step, total, title, desc):
    print(f"\n{'='*60}")
    print(f"  【第 {step}/{total} 步】{title}")
    print(f"{'='*60}")
    print(f"  说明：{desc}\n")

def ask_choice(options, current, prompt):
    """询问选择"""
    current_idx = None
    for i, (key, desc) in enumerate(options, 1):
        marker = ""
        if key == current:
            current_idx = i
            marker = " <- 当前"
        print(f"  [{i}] {desc}{marker}")
    
    print(f"\n{prompt} (1-{len(options)}) 或回车默认: ", end='')
    try:
        choice = input().strip()
    except:
        choice = ''
    
    if choice == "" and current_idx:
        return current
    
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(options):
            return options[idx][0]
    except:
        pass
    
    return current

def ask_yes_no(prompt):
    """确认"""
    print(f"\n{prompt} [Y/n]: ", end='')
    try:
        choice = input().strip().lower()
    except:
        choice = 'y'
    return choice in ['', 'y', 'Y']

def load_current_config():
    """加载当前配置"""
    config_path = os.path.join(SKILL_DIR, "configs", "1368_config.json")
    config = {
        "L0_SIZE_LIMIT": "4mb",
        "L123_SIZE_LIMIT": "400kb",
        "EMBEDDING_BACKEND": "minimax",
        "AUTO_START": "enable",
        "MIGRATE_HISTORY": "none"
    }
    if os.path.exists(config_path):
        import json
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config.update(json.load(f))
        except:
            pass
    return config

def save_config(config):
    """保存配置"""
    config_dir = os.path.join(SKILL_DIR, "configs")
    os.makedirs(config_dir, exist_ok=True)
    config_path = os.path.join(config_dir, "1368_config.json")
    try:
        import json
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"保存配置失败: {e}")
        return False

# ==================== 步骤执行函数 ====================

def step_initialize_and_embed():
    """步骤4：初始化目录 + 配置Embedding"""
    print_step(4, 8, "初始化配置", "初始化1368目录结构 + 配置Embedding向量后端")
    
    # 4.1 初始化目录结构
    print("\n  【4.1】初始化目录结构")
    dirs = [
        os.path.join(MEMORY_1368, "L0_raw"),
        os.path.join(MEMORY_1368, "L1_decision"),
        os.path.join(MEMORY_1368, "L2_scene"),
        os.path.join(MEMORY_1368, "L3_profile"),
        os.path.join(MEMORY_1368, "indexes"),
    ]
    
    for d in dirs:
        os.makedirs(d, exist_ok=True)
        print(f"  ✅ 创建目录: {d}")
    
    # 各智能体子目录
    agents = ['main', 'xiaodai', 'xiaodang', 'xiaogu', 'xiaofa', 'vice-manager']
    for agent in agents:
        agent_dir = os.path.join(MEMORY_1368, "L0_raw", agent)
        os.makedirs(agent_dir, exist_ok=True)
    
    print("\n  ✅ 目录结构初始化完成")
    
    if not ask_yes_no("确认目录初始化"):
        return False
    
    # 4.2 配置Embedding
    print("\n  【4.2】配置Embedding（向量后端）")
    
    print("""
  请选择向量嵌入模型后端（用于语义搜索）：

  [1] Ollama 本地部署（免费、私密、离线可用）
      - 优点：免费使用、无需 API Key、离线可用
      - 安装：curl -fsSL https://ollama.com/install.sh | sh
      - 启动：ollama serve
      - 下载模型：ollama pull nomic-embed-text

  [2] 云端大模型 API（配置简单、快速上手）
      - 推荐：MiniMAX API（性价比高）
      - 注册：https://platform.minimax.io/
      - 设置：export OPENAI_API_KEY=你的Key
    """)
    
    # 检查当前状态
    import requests
    ollama_available = False
    try:
        r = requests.get('http://localhost:11434', timeout=2)
        if r.status_code == 200:
            ollama_available = True
    except:
        pass
    
    api_key = os.environ.get('OPENAI_API_KEY', '')
    
    print(f"\n  【当前状态】")
    if ollama_available:
        print(f"    Ollama 本地服务: ✅ 已运行")
    else:
        print(f"    Ollama 本地服务: ⚠️ 未运行")
    
    if api_key:
        print(f"    云端 API Key: ✅ 已配置")
    else:
        print(f"    云端 API Key: ⚠️ 未配置")
    
    print(f"\n  请选择 [1/2] (默认2): ", end='')
    try:
        choice = input().strip()
    except:
        choice = '2'
    
    if choice == '1':
        if not ollama_available:
            print("\n  ⚠️ Ollama 未运行，请先安装并启动")
            print("  安装：curl -fsSL https://ollama.com/install.sh | sh")
            print("  启动：ollama serve")
            print("  下载模型：ollama pull nomic-embed-text")
            return False
        print("  ✅ 已选择 Ollama 本地方案")
        return "ollama"
    else:
        if not api_key:
            print("\n  ⚠️ 未配置 API Key")
            print("  请先设置：export OPENAI_API_KEY=你的Key")
            return False
        print("  ✅ 已选择 MiniMAX API 方案")
        return "minimax"

def step_migrate_history():
    """步骤5：历史数据回溯"""
    print_step(5, 8, "历史数据回溯", "是否回溯转写原系统历史数据到 L0_raw")
    
    migrate_options = [
        ("all", "回溯全部（所有.jsonl文件）"),
        ("recent30", "回溯近期（30天内）"),
        ("none", "暂不回溯（仅处理新数据）"),
    ]
    
    print("\n  请选择历史数据处理方式：\n")
    for i, (key, desc) in enumerate(migrate_options, 1):
        print(f"    [{i}] {desc}")
    
    print(f"\n  请输入选择 (1-3) 或回车默认 [3]: ", end='')
    try:
        choice = input().strip()
    except:
        choice = '3'
    
    if choice == "1":
        migrate_choice = "all"
        print("  已选择：回溯全部历史数据")
    elif choice == "2":
        migrate_choice = "recent30"
        print("  已选择：回溯30天内数据")
    else:
        migrate_choice = "none"
        print("  已选择：暂不回溯历史数据")
    
    if not ask_yes_no("确认此配置"):
        return None
    
    return migrate_choice

def step_l123_extractor():
    """步骤6：L1/L2/L3提取"""
    print_step(6, 8, "L1/L2/L3提取", "从L0_raw提取决策/场景/画像")
    
    print("""
  说明：扫描L0_raw目录，从原始会话中提取：
    - L1决策：决策、纠正、数字结论
    - L2场景：任务背景、项目进展、事件上下文
    - L3画像：偏好、习惯、沟通风格
  
  执行命令：python3 scripts/l123_extractor.py
  """)
    
    print(f"\n  请确认是否执行 [Y/n]: ", end='')
    try:
        choice = input().strip().lower()
    except:
        choice = 'y'
    
    if choice not in ['', 'y', 'Y']:
        print("  已跳过 L1/L2/L3 提取")
        return None
    
    print("\n  正在执行 l123_extractor.py...")
    
    script_path = os.path.join(SKILL_DIR, "scripts", "l123_extractor.py")
    import subprocess
    result = subprocess.run([sys.executable, script_path], capture_output=True, text=True)
    
    if result.returncode == 0:
        for line in result.stdout.split('\n'):
            if '[L123]' in line or '[处理]' in line or '[完成]' in line or '提取' in line:
                print(f"  {line}")
        print("\n  ✅ L1/L2/L3提取完成")
        return True
    else:
        print(f"\n  ⚠️ L1/L2/L3提取输出：{result.stdout[:300]}")
        if result.stderr:
            print(f"  错误：{result.stderr[:200]}")
        return False

def step_build_index():
    """步骤7：索引构建"""
    print_step(7, 8, "索引构建", "构建向量索引")
    
    api_key = os.environ.get('OPENAI_API_KEY', '')
    
    if not api_key:
        print("""
  说明：为L0_raw、L1_decision、L2_scene、L3_profile构建向量索引
  执行命令：python3 scripts/build_index_1368.py
  
  ⚠️ 当前未配置 API Key，无法构建索引
  请先设置：export OPENAI_API_KEY=你的Key
  然后手动运行：python3 scripts/build_index_1368.py
  """)
        print(f"\n  请按回车继续（跳过索引构建）: ", end='')
        try:
            input()
        except:
            pass
        return None
    
    print(f"""
  说明：为L0_raw、L1_decision、L2_scene、L3_profile构建向量索引
  执行命令：python3 scripts/build_index_1368.py
  
  ⚠️ 注意：索引构建可能需要几分钟（22925个文本块）
  """)
    
    print(f"\n  请确认是否执行 [Y/n]: ", end='')
    try:
        choice = input().strip().lower()
    except:
        choice = 'y'
    
    if choice not in ['', 'y', 'Y']:
        print("  已跳过索引构建")
        return None
    
    print("\n  正在执行 build_index_1368.py...")
    print("  （等待较久，请耐心等待）\n")
    
    script_path = os.path.join(SKILL_DIR, "scripts", "build_index_1368.py")
    import subprocess
    result = subprocess.run([sys.executable, script_path], capture_output=True, text=True, timeout=300)
    
    if result.returncode == 0:
        for line in result.stdout.split('\n'):
            if '索引构建' in line or '完成' in line or '构建' in line or '进度' in line:
                print(f"  {line}")
        print("\n  ✅ 索引构建完成")
        return True
    else:
        print(f"\n  ⚠️ 索引构建输出：{result.stdout[:500]}")
        if result.stderr:
            print(f"  错误：{result.stderr[:200]}")
        return False

def step_start_l0_watcher():
    """步骤8：配置L0心跳规则"""
    print_step(8, 8, "配置L0心跳规则", "写入HEARTBEAT.md心跳执行规则")
    
    print(f"""
  说明：在HEARTBEAT.md中配置L0心跳执行规则
    - 心跳触发时执行：python3 l0_watcher.py --heartbeat
    - 增量复制新会话到L0_raw/
    - 自动跳过已处理的会话（断点机制）
  
  配置内容：
    - 源目录：/root/.openclaw/agents/main/sessions/
    - 目标目录：memory/1368-memory/L0_raw/main/
    - 提取：user + assistant 对话
""")
    
    # ========== 写入向量搜索规则到AGENTS.md ==========
    vector_search_rule = "5. **如果是查询历史记录**：使用1368元神记忆系统向量搜索"
    vector_search_marker = "1368元神记忆系统向量搜索"
    
    if os.path.exists(agents_md):
        with open(agents_md, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if vector_search_marker not in content:
            # 在第4项后插入第5项
            lines = content.split('\n')
            new_lines = []
            inserted = False
            for line in lines:
                new_lines.append(line)
                if '**如果是主会话**' in line and not inserted:
                    new_lines.append(vector_search_rule)
                    inserted = True
            
            with open(agents_md, 'w', encoding='utf-8') as f:
                f.write('\n'.join(new_lines))
            print(f"\n  ✅ 已写入向量搜索规则到AGENTS.md")
        else:
            print(f"\n  ✅ AGENTS.md 已有向量搜索规则，无需修改")
    
    # ========== 写入L0心跳规则到HEARTBEAT.md ==========
    heartbeat_md = os.path.join(WORKSPACE, "HEARTBEAT.md")
    heartbeat_rule = """## L0会话复制（心跳执行）

**触发条件**：每次心跳
**执行命令**：`python3 skills/1368元神记忆系统/scripts/l0_watcher.py --heartbeat`

**断点机制**：
- 记录已处理session_id：`memory/1368-memory/L0_raw/l0_archive_log.json`
- 只处理新的session_id

**执行内容**：
- 源目录：`/root/.openclaw/agents/main/sessions/`
- 目标目录：`memory/1368-memory/L0_raw/main/`
- 提取：user + assistant 对话
- 格式：jsonl → .md

"""
    heartbeat_marker = "L0会话复制（心跳执行）"
    
    if os.path.exists(heartbeat_md):
        with open(heartbeat_md, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if heartbeat_marker not in content:
            # 在"保持安静"前插入L0心跳规则
            lines = content.split('\n')
            new_lines = []
            inserted = False
            for line in lines:
                new_lines.append(line)
                if '## 保持安静' in line and not inserted:
                    new_lines.append(heartbeat_rule)
                    inserted = True
            
            with open(heartbeat_md, 'w', encoding='utf-8') as f:
                f.write('\n'.join(new_lines))
            print(f"\n  ✅ 已写入L0心跳规则到HEARTBEAT.md")
        else:
            print(f"\n  ✅ HEARTBEAT.md 已有L0心跳规则，无需修改")
    
    print(f"""
  配置完成！
    - 心跳触发时自动执行L0会话复制
    - 断点机制确保不重复处理
    - 重启Gateway使配置生效
""")
    
    return True

# ==================== 主流程 ====================

def main():
    print_banner()
    
    config = load_current_config()
    results = {}
    total_steps = 8
    
    # ========== 步骤1：L0 阈值配置 ==========
    print_step(1, total_steps, "L0 阈值配置", "原始会话复刻文件的大小限制")
    
    l0_options = [
        ("1mb", "1MB（频繁分离，适合大会话量）"),
        ("2mb", "2MB（平衡）"),
        ("4mb", "4MB（少量分离，推荐）"),
    ]
    
    current_l0 = config.get("L0_SIZE_LIMIT", "4mb")
    l0_choice = ask_choice(l0_options, current_l0, "L0 阈值")
    results["L0_SIZE_LIMIT"] = l0_choice
    print(f"  已选择：L0 阈值 = {l0_choice}")
    
    if not ask_yes_no("确认此配置"):
        print("已取消。")
        return
    
    # ========== 步骤2：L1/L2/L3 阈值配置 ==========
    print_step(2, total_steps, "L1/L2/L3 阈值配置", "决策/场景/画像文件的大小限制")
    
    l123_options = [
        ("200kb", "200KB（更多文件，更细粒度）"),
        ("400kb", "400KB（平衡，推荐）"),
        ("500kb", "500KB（较少文件，更粗粒度）"),
    ]
    
    current_l123 = config.get("L123_SIZE_LIMIT", "400kb")
    l123_choice = ask_choice(l123_options, current_l123, "L1/L2/L3 阈值")
    results["L123_SIZE_LIMIT"] = l123_choice
    print(f"  已选择：L1/L2/L3 阈值 = {l123_choice}")
    
    if not ask_yes_no("确认此配置"):
        print("已取消。")
        return
    
    # ========== 步骤3：搜索方式配置 ==========
    print_step(3, total_steps, "搜索方式配置", "选择记忆搜索方式")
    
    search_options = [
        ("memory", "memorySearch（腾讯TencentDB插件）- 自动索引，实时搜索"),
        ("faiss", "FAISS（1368本地索引）- 离线搜索，不消耗token"),
        ("both", "两者都要 - memorySearch + FAISS"),
    ]
    
    current_search = config.get("SEARCH_MODE", "memory")
    search_choice = ask_choice(search_options, current_search, "搜索方式")
    results["SEARCH_MODE"] = search_choice
    
    print(f"\n  已选择：搜索方式 = {search_choice}")
    if search_choice == "memory":
        print("  优点: 自动捕获会话，无需手动建索引")
        print("  缺点: 每次搜索消耗API token")
    elif search_choice == "faiss":
        print("  优点: 离线搜索，不消耗API额度")
        print("  缺点: 需要手动构建索引")
    else:
        print("  优点: 两套系统互补，更全面")
        print("  缺点: 需要维护两套索引")
    
    if not ask_yes_no("确认此配置"):
        print("已取消。")
        return
    
    # ========== 步骤4：初始化目录 + 配置Embedding ==========
    embed_result = step_initialize_and_embed()
    if embed_result is False:
        print("\n  ⚠️ Embedding 配置未完成，继续使用默认配置")
        embed_result = config.get("EMBEDDING_BACKEND", "minimax")
    results["EMBEDDING_BACKEND"] = embed_result if embed_result else results["EMBEDDING_BACKEND"]
    
    # ========== 步骤5：历史数据回溯 ==========
    migrate_result = step_migrate_history()
    if migrate_result is None:
        print("\n已取消。")
        return
    results["MIGRATE_HISTORY"] = migrate_result
    
    # ========== 步骤6：L1/L2/L3提取 ==========
    if not step_l123_extractor():
        print("\n  ⚠️ L1/L2/L3提取失败，继续下一步")
    
    # ========== 步骤7：索引构建 ==========
    step_build_index()  # 可能因为API Key问题跳过
    
    # ========== 步骤8：启动L0监听 ==========
    step_start_l0_watcher()
    
    # ========== 完成 ==========
    print(f"\n{Colors.BOLD}{'='*60}")
    print("  配置完成摘要")
    print(f"{'='*60}{Colors.ENDC}")
    print(f"  L0 阈值: {results.get('L0_SIZE_LIMIT', '2mb')}")
    print(f"  L1/L2/L3 阈值: {results.get('L123_SIZE_LIMIT', '200kb')}")
    print(f"  向量搜索后端: {results.get('EMBEDDING_BACKEND', 'minimax')}")
    print(f"  历史数据回溯: {results.get('MIGRATE_HISTORY', 'none')}")
    print(f"{Colors.BOLD}{'='*60}{Colors.ENDC}")
    
    if save_config(results):
        print("\n✅ 配置已保存!")
    else:
        print("\n⚠️ 配置保存失败!")
    
    print(f"""
{Colors.BOLD}
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🎉 1368元神系统配置完成！                               ║
║                                                           ║
║   查看系统状态：python3 scripts/health_check.py           ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
{Colors.ENDC}
""")
    
    sys.exit(0)

if __name__ == "__main__":
    main()