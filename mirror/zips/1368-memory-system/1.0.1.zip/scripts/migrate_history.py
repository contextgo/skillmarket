#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神系统 - 会话历史数据提取
==============================
从 agents/*/sessions/ 目录提取会话内容到 L0

处理文件类型：
1. .trajectory.jsonl - 已完成会话的轨迹文件
2. .jsonl（无特殊后缀）- 当前活跃会话

跳过文件：
- .checkpoint.*.jsonl - 检查点文件
- .deleted.* - 已删除文件
- .lock - 锁文件
- .trajectory-path.json - 元数据文件

输出：
- 每个会话提取后写入 L0_raw/{agent_id}/
- 文件名格式：{agent_id}-{日期}-{session_id前8位}.md
- 单文件大小由 1368_config.json 的 L0_SIZE_LIMIT 配置（默认4MB）
- 满阈值自动新建文件继续写入
"""

import os
import sys
import json
import argparse
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from paths_config import (
    WORKSPACE, MEMORY_1368, L0_RAW,
    AGENTS_SESSIONS, L0_SIZE_LIMIT
)
from l0_import import find_next_l0_file, get_l0_import_path

# ============== Archive Log 读写 ==============

ARCHIVE_LOG = os.path.join(L0_RAW, "l0_archive_log.json")
TOOL_NAME = "migrate_history"

def get_default_log_structure():
    """获取默认日志结构（v2.0按工具分开的格式）"""
    return {
        "_meta": {
            "version": "2.0",
            "total_sessions": 0,
            "total_messages": 0,
            "tools": [TOOL_NAME]
        },
        "_tools": {
            TOOL_NAME: {
                "sessions": 0,
                "messages": 0,
                "last_run": None
            }
        },
        TOOL_NAME: {}
    }

def migrate_old_format(data):
    """旧格式迁移到v2.0格式"""
    if "_meta" in data and "tools" in data.get("_meta", {}):
        return data  # 已是新格式
    new_data = get_default_log_structure()
    # 检查是否有l0_watcher的数据
    for k, v in data.items():
        if k != "_meta" and isinstance(v, dict):
            if "l0_watcher" not in new_data["_meta"]["tools"]:
                new_data["_meta"]["tools"].append("l0_watcher")
                new_data["l0_watcher"] = {}
                new_data["_tools"]["l0_watcher"] = {"sessions": 0, "messages": 0, "last_run": None}
            new_data["l0_watcher"][k] = v
    # 归并migrate_history数据（如果有）
    if TOOL_NAME in data:
        new_data[TOOL_NAME] = data[TOOL_NAME]
        if TOOL_NAME not in new_data["_meta"]["tools"]:
            new_data["_meta"]["tools"].append(TOOL_NAME)
    # 重建统计
    for tool in new_data["_meta"]["tools"]:
        if tool in new_data:
            new_data["_tools"][tool]["sessions"] = len(new_data[tool])
            new_data["_tools"][tool]["messages"] = sum(
                info.get("last_line_count", 0) for info in new_data[tool].values()
            )
    return new_data

def load_archive_log():
    """加载归档日志（统一函数）"""
    if os.path.exists(ARCHIVE_LOG):
        try:
            with open(ARCHIVE_LOG, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return migrate_old_format(data)
        except:
            pass
    return get_default_log_structure()

def save_archive_log(log_data):
    """保存归档日志（统一函数）"""
    # 重建汇总统计
    tools = log_data.get("_meta", {}).get("tools", [])
    total_sessions = sum(len(log_data.get(tool, {})) for tool in tools)
    total_messages = sum(
        sum(info.get("last_line_count", 0) for info in log_data.get(tool, {}).values())
        for tool in tools
    )
    log_data["_meta"]["total_sessions"] = total_sessions
    log_data["_meta"]["total_messages"] = total_messages
    
    # 更新各工具统计
    for tool in tools:
        if tool in log_data and tool not in log_data.get("_tools", {}):
            log_data["_tools"][tool] = {"sessions": 0, "messages": 0, "last_run": None}
        if tool in log_data:
            log_data["_tools"][tool]["sessions"] = len(log_data[tool])
            log_data["_tools"][tool]["messages"] = sum(
                info.get("last_line_count", 0) for info in log_data[tool].values()
            )
    
    try:
        with open(ARCHIVE_LOG, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"  ❌ 保存archive_log失败: {e}")

def register_tool(tool_name):
    """注册工具到日志"""
    log = load_archive_log()
    if tool_name not in log["_meta"]["tools"]:
        log["_meta"]["tools"].append(tool_name)
    if tool_name not in log:
        log[tool_name] = {}
    if tool_name not in log["_tools"]:
        log["_tools"][tool_name] = {"sessions": 0, "messages": 0, "last_run": None}
    save_archive_log(log)

def is_session_processed(session_id):
    """检查任意工具是否已处理过此会话，返回(True, tool_name)或(False, None)"""
    log = load_archive_log()
    for tool in log["_meta"]["tools"]:
        if session_id in log.get(tool, {}):
            return True, tool
    return False, None

def update_tool_stats(session_id, info):
    """更新工具统计并写入记录"""
    log = load_archive_log()
    if TOOL_NAME not in log:
        log[TOOL_NAME] = {}
    log[TOOL_NAME][session_id] = {
        **info,
        "archived_at": datetime.now().isoformat()
    }
    log["_tools"][TOOL_NAME]["last_run"] = datetime.now().isoformat()
    save_archive_log(log)

# 兼容旧函数（不再使用，保留以防万一）
def update_archive_log(session_id, archive_path, last_line_count):
    """更新archive_log记录（已废弃，用update_tool_stats代替）"""
    update_tool_stats(session_id, {
        'archived_path': archive_path,
        'last_line_count': last_line_count
    })

# ============== Gap Log 读写 ==============

GAP_LOG = os.path.join(L0_RAW, "l0_timestamp_log.json")

def load_gap_log():
    """加载 gap_log"""
    if os.path.exists(GAP_LOG):
        try:
            with open(GAP_LOG, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            pass
    return {}

def save_gap_log(log_data):
    """保存 gap_log"""
    try:
        with open(GAP_LOG, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"  ❌ 保存gap_log失败: {e}")

def write_gap_record(session_id, action, details):
    """记录到时间戳日志"""
    log = load_gap_log()
    timestamp = datetime.now().isoformat()
    
    if session_id not in log:
        log[session_id] = {
            "records": [],
            "last_action": None,
            "created_at": None,
            "recorded_at": None,
            "backfilled_at": None,
            "status": None
        }
    
    log[session_id]["records"].append({
        "timestamp": timestamp,
        "action": action,
        "details": details
    })
    log[session_id]["last_action"] = action
    
    if action == "recorded":
        log[session_id]["recorded_at"] = timestamp
        log[session_id]["status"] = "recorded"
    elif action == "backfilled":
        log[session_id]["backfilled_at"] = timestamp
        log[session_id]["status"] = "backfilled"
    
    save_gap_log(log)

# ============== 辅助函数 ==============

def safe_ts(ts):
    """安全解析时间戳"""
    if not ts:
        return None
    try:
        if isinstance(ts, (int, float)):
            return datetime.fromtimestamp(ts/1000)
        ts_str = str(ts)
        if 'T' in ts_str:
            return datetime.fromisoformat(ts_str.replace('Z', '+00:00').split('.')[0])
    except:
        pass
    return None

def extract_text_from_content(content):
    """从content中提取纯文本内容"""
    if isinstance(content, list):
        texts = []
        for c in content:
            if isinstance(c, dict):
                if c.get('type') == 'text':
                    texts.append(c.get('text', ''))
        return ''.join(texts)
    return str(content)

def clean_user_message(text):
    """清理用户消息中的元信息前缀"""
    marker = 'Conversation info (untrusted metadata)'
    if marker in text:
        idx = text.find(marker)
        text = text[idx + len(marker):].strip()
        if 'Sender (untrusted metadata):' in text:
            parts = text.split('Sender (untrusted metadata):')
            if len(parts) > 1:
                text = parts[-1].strip()
                if text.startswith('```'):
                    idx = text.find('```', 3)
                    if idx > 0:
                        text = text[idx+3:].strip()
    if text.startswith('Sender (untrusted metadata)'):
        idx = text.find('```', 30)
        if idx > 0:
            text = text[idx+3:].strip()
            if text.startswith('```'):
                idx2 = text.find('```', 3)
                if idx2 > 0:
                    text = text[idx2+3:].strip()
    return text

def parse_jsonl(path):
    """解析 jsonl 文件"""
    messages = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    messages.append(json.loads(line))
                except:
                    continue
    except Exception as e:
        print(f"  ❌ 读取失败: {e}")
    return messages

def make_filename(agent_id, date_str, session_prefix, part_num):
    """生成文件名
    
    单文件：{agent}-{date}-{session}.md
    多文件：{agent}-{date}-{session}.part001.md
    """
    base = f"{agent_id}-{date_str}-{session_prefix}"
    if part_num == 1:
        return f"{base}.md"
    else:
        return f"{base}.part{part_num:03d}.md"

def extract_date_from_ts(ts):
    """从时间戳提取日期字符串"""
    if not ts:
        return datetime.now().strftime('%Y%m%d')
    if isinstance(ts, (int, float)):
        return datetime.fromtimestamp(ts/1000).strftime('%Y%m%d')
    ts_str = str(ts)
    if 'T' in ts_str:
        return ts_str.split('T')[0].replace('-', '')
    return ts_str[:8]

def generate_header(messages, session_id, date_str):
    """生成会话头部"""
    first_msg = messages[0] if messages else None
    first_ts = safe_ts(first_msg.get('timestamp') or first_msg.get('ts', '')) if first_msg else datetime.now()
    
    user_count = sum(1 for m in messages if m.get('type') == 'message' and m.get('message', {}).get('role') == 'user')
    user_count += sum(1 for m in messages if m.get('type') == 'model.completed' for msg in m.get('data', {}).get('messagesSnapshot', []) if msg.get('role') == 'user')
    
    return f"""# 会话存档：{first_ts.strftime('%Y-%m-%d %H:%M')}
- 会话ID: {session_id}
- Agent: main
- 日期: {date_str}

---
"""

def format_message_line(msg):
    """将单条消息格式化为一行"""
    msg_type = msg.get('type', '')
    ts = msg.get('timestamp') or msg.get('ts', '')
    
    # 格式化时间
    if ts:
        if 'T' in str(ts):
            dt = safe_ts(ts)
            ts_str = dt.strftime('%H:%M') if dt else '??:??'
        elif isinstance(ts, (int, float)):
            ts_str = datetime.fromtimestamp(ts/1000).strftime('%H:%M')
        else:
            ts_str = str(ts)[:5]
    else:
        ts_str = '??:??'
    
    # 旧格式：type=message
    if msg_type == 'message' and 'message' in msg:
        m = msg['message']
        role = m.get('role', '')
        content = m.get('content', '')
        text = extract_text_from_content(content)
        if role == 'user':
            text = clean_user_message(text)
        if text:
            return f"[{ts_str} {role}] {text}"
    
    # 新格式：model.completed / context.compiled
    elif msg_type in ('model.completed', 'context.compiled'):
        data = msg.get('data', {})
        snapshot = data.get('messagesSnapshot', [])
        
        seen_user = False
        seen_assistant = False
        
        for m in snapshot:
            role = m.get('role', '')
            content = m.get('content', '')
            text = extract_text_from_content(content)
            if role == 'user':
                text = clean_user_message(text)
            if not text:
                continue
            
            if role == 'user' and not seen_user:
                seen_user = True
                return f"[{ts_str} user] {text}"
            elif role == 'assistant' and not seen_assistant:
                seen_assistant = True
                return f"[{ts_str} assistant] {text}"
    
    return None

# ============== 流式写入核心函数 ==============

def stream_write_messages(messages, session_id, agent_id, output_dir, source_type='trajectory', size_limit=None):
    """流式写入：多文件合并追加，满阀值新建序号
    
    所有会话文件按时间顺序追加到同一个输出池：
    - L0_migrate_001.md 满了 -> L0_migrate_002.md
    - 每个文件只写一次header，后续追加内容
    - 文件命名: L0_migrate_{序号}.md
    
    Args:
        messages: 消息列表
        session_id: 会话ID
        agent_id: 智能体ID
        output_dir: 输出目录
        source_type: 来源类型（trajectory/checkpoint/active）
        size_limit: 文件大小阈值（字节），默认从L0_SIZE_LIMIT读取
    
    Returns:
        (成功数, 文件列表, 消息数)
    """
    if size_limit is None:
        size_limit = L0_SIZE_LIMIT
    
    # 检查是否已被任意工具处理过
    processed, tool = is_session_processed(session_id)
    if processed:
        print(f"  ⏭️ {session_id[:16]}... 已被 {tool} 处理，跳过")
        return 0, [], 0
    
    # 注册本工具
    register_tool(TOOL_NAME)
    
    # 提取日期（用于header）
    first_msg = messages[0] if messages else {}
    ts = first_msg.get('timestamp') or first_msg.get('ts', '')
    date_str = extract_date_from_ts(ts)
    
    # 生成header
    header = generate_header(messages, session_id, date_str)
    
    # 找到第一个可写文件
    current_path, current_seq = find_next_l0_file('migrate', output_dir, date_str)
    files_written = []
    
    # 状态变量
    current_lines = []
    current_size = 0
    message_count = 0
    header_written = False
    
    # 逐条处理消息
    for msg in messages:
        line = format_message_line(msg)
        if not line:
            continue
        
        line_bytes = (line + '\n').encode('utf-8')
        line_size = len(line_bytes)
        
        # 检查是否需要换文件
        if current_size + line_size > size_limit and current_lines:
            # 写当前文件
            if current_lines:
                write_file_content(current_path, header, current_lines, header_written)
                files_written.append(os.path.basename(current_path))
                header_written = True
            
            # 获取下一个文件
            current_seq += 1
            current_path = get_l0_import_path('migrate', current_seq, output_dir, date_str)
            
            current_lines = []
            current_size = 0
        
        current_lines.append(line)
        current_size += line_size
        message_count += 1
    
    # 写最后一个文件
    if current_lines:
        write_file_content(current_path, header, current_lines, header_written)
        files_written.append(os.path.basename(current_path))
    
    # 更新统计
    if files_written:
        update_tool_stats(session_id, {
            'archived_path': files_written[0],
            'last_line_count': message_count,
            'source': source_type,
            'parts': len(files_written)
        })
        write_gap_record(session_id, 'recorded', {
            'source': 'migrate',
            'file': files_written[0],
            'count': message_count,
            'parts': len(files_written)
        })
    
    return len(files_written), files_written, message_count


def write_file_content(filepath, header, lines, header_exists=False):
    """写入文件内容（追加模式）"""
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    with open(filepath, 'a', encoding='utf-8') as f:
        if not header_exists:
            f.write(header)
        f.write('\n'.join(lines))
        f.write('\n')

# ============== 会话历史提取逻辑 ==============

def get_session_files(sessions_dir):
    """获取需要提取的会话文件
    
    只处理：
    1. .trajectory.jsonl - 轨迹文件
    2. .jsonl（无特殊后缀）- 当前会话
    3. .checkpoint.*.jsonl - 检查点文件
    
    跳过：
    - .deleted.*
    - .lock
    - .trajectory-path.json
    """
    if not os.path.exists(sessions_dir):
        return []
    
    files = []
    for f in os.listdir(sessions_dir):
        if not f.endswith('.jsonl'):
            continue
        if '.deleted.' in f:
            continue
        if f.endswith('.lock'):
            continue
        if f.endswith('.trajectory.jsonl') or (f.endswith('.jsonl') and '.jsonl.' not in f) or '.checkpoint.' in f:
            filepath = os.path.join(sessions_dir, f)
            mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
            files.append((filepath, mtime))
    
    return sorted(files, key=lambda x: x[1])

def extract_session_to_l0(filepath, agent_id, output_dir):
    """提取单个会话文件到L0（流式写入版本）"""
    filename = os.path.basename(filepath)
    mtime = os.path.getmtime(filepath)
    
    # 提取session_id和来源标识
    if filename.endswith('.trajectory.jsonl'):
        session_id = filename.replace('.trajectory.jsonl', '')
        source_type = 'trajectory'
    elif '.checkpoint.' in filename:
        # 格式: xxx.checkpoint.yyy.jsonl
        # 用mtime区分不同版本的checkpoint
        session_id = f"{filename.split('.checkpoint.')[0]}_{int(mtime)}"
        source_type = 'checkpoint'
    else:
        session_id = filename.replace('.jsonl', '')
        source_type = 'active'
    
    # 解析文件
    messages = parse_jsonl(filepath)
    if not messages:
        return False, "空文件或解析失败"
    
    # 流式写入
    part_count, files, msg_count = stream_write_messages(
        messages, session_id, agent_id, output_dir, source_type
    )
    
    if part_count == 1:
        return True, f"写入 {files[0]} ({msg_count}条消息)"
    else:
        return True, f"分割为 {part_count} 个文件 ({msg_count}条消息)"

def migrate_agent(agent_id, sessions_dir, output_dir, dry_run=False):
    """提取单个智能体的会话历史"""
    print(f"\n{'='*50}")
    print(f"  智能体: {agent_id}")
    print(f"  源目录: {sessions_dir}")
    print(f"  目标目录: {output_dir}")
    print(f"  阈值: {L0_SIZE_LIMIT / 1024 / 1024:.0f}MB")
    print(f"{'='*50}")
    
    files = get_session_files(sessions_dir)
    
    if not files:
        print(f"  ℹ 没有需要提取的会话文件")
        return 0
    
    print(f"  找到 {len(files)} 个会话文件")
    
    agent_output = os.path.join(output_dir, agent_id)
    os.makedirs(agent_output, exist_ok=True)
    
    success_count = 0
    for filepath, mtime in files:
        filename = os.path.basename(filepath)
        
        if dry_run:
            print(f"  [DRY] {filename}")
            success_count += 1
            continue
        
        success, msg = extract_session_to_l0(filepath, agent_id, agent_output)
        if success:
            print(f"  ✅ {filename} -> {msg}")
            success_count += 1
        else:
            print(f"  ❌ {filename}: {msg}")
    
    return success_count

def deduplicate_l0_files(agent_id, dry_run=False):
    """对生成的L0文件进行去重（优化版）
    
    规则：
    1. 相同内容的文件：删除后生成的文件
    2. 部分内容重复的：去除后面文件开头的重复部分
    
    优化：先快速比较行数+首尾行，再详细比较
    
    Returns:
        (deleted_count, trimmed_count)
    """
    agent_output = os.path.join(L0_RAW, agent_id)
    if not os.path.exists(agent_output):
        return 0, 0
    
    # 获取所有L0文件（按文件名排序，文件名含时间）
    files = sorted([
        f for f in os.listdir(agent_output)
        if f.endswith('.md') and 'main-' in f
    ])
    
    if len(files) < 2:
        return 0, 0
    
    print(f"\n  🔍 开始去重检查 ({len(files)} 个文件)...")
    
    # 快速扫描：收集文件信息（不读全部内容）
    file_info = {}
    for f in files:
        filepath = os.path.join(agent_output, f)
        size = os.path.getsize(filepath)
        try:
            with open(filepath, 'r', encoding='utf-8') as fp:
                first_line = fp.readline()[:100]  # 首行前100字符
                fp.seek(max(0, size - 200))
                last_line = fp.readline()[-100:]  # 尾行后100字符
        except UnicodeDecodeError:
            # 编码问题，用二进制读取后忽略错误
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as fp:
                first_line = fp.readline()[:100]
                fp.seek(max(0, size - 200))
                last_line = fp.readline()[-100:]
        file_info[f] = {
            'size': size,
            'first': first_line,
            'last': last_line,
            'path': filepath
        }
    
    deleted_count = 0
    trimmed_count = 0
    to_delete = []
    to_trim = []
    
    # 第一遍：快速扫描找出可能重复的文件
    content_hashes = {}  # hash -> [(filename, filepath), ...]
    for f in files:
        filepath = file_info[f]['path']
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as fp:
                content = fp.read()
        except:
            continue
        content_hash = hash(content)
        if content_hash not in content_hashes:
            content_hashes[content_hash] = []
        content_hashes[content_hash].append((f, filepath))
    
    # 找出完全相同的（相同hash）
    to_delete = []
    for content_hash, file_list in content_hashes.items():
        if len(file_list) > 1:
            # 按文件名排序，保留第一个，删除其他的
            file_list.sort()
            for i in range(1, len(file_list)):
                to_delete.append(file_list[i][0])
                print(f"    🗑️ 待删除（内容相同）: {file_list[i][0]}")
    
    # 第二遍：检查部分重叠（按时间顺序）
    prev_content = None
    prev_file = None
    
    for f in files:
        if f in to_delete:
            prev_file = f  # 仍然更新prev_file
            continue
            
        filepath = file_info[f]['path']
        
        with open(filepath, 'r', encoding='utf-8') as fp:
            content = fp.read()
        
        if prev_content is not None:
            prev_filepath = file_info[prev_file]['path']
            
            # 检查是否完全包含上一个文件
            if content.startswith(prev_content):
                to_delete.append(prev_file)
                print(f"    🗑️ 待删除（被后续包含）: {prev_file}")
                deleted_count += 1
            else:
                # 检查重叠部分
                prev_lines = prev_content.split('\n')
                curr_lines = content.split('\n')
                
                # 找到最大的重叠行数
                overlap_lines = 0
                for i in range(min(len(prev_lines), len(curr_lines) // 2)):
                    if prev_lines[-(i+1)] == curr_lines[i]:
                        overlap_lines = i + 1
                    else:
                        break
                
                if overlap_lines >= 3:  # 重叠超过3行
                    # 裁剪重叠部分
                    new_content = '\n'.join(curr_lines[overlap_lines:])
                    to_trim.append((f, new_content))
                    print(f"    ✂️ 待裁剪: {f} (去除前 {overlap_lines} 行重叠)")
                    trimmed_count += 1
        
        prev_content = content
        prev_file = f
    
    # 执行删除
    if not dry_run:
        for f in to_delete:
            filepath = file_info[f]['path']
            if os.path.exists(filepath):
                os.remove(filepath)
                print(f"    🗑️ 已删除: {f}")
        
        for f, new_content in to_trim:
            filepath = file_info[f]['path']
            with open(filepath, 'w', encoding='utf-8') as fp:
                fp.write(new_content)
            print(f"    ✂️ 已裁剪: {f}")
    
    total = len(to_delete) + trimmed_count
    if total > 0:
        print(f"  ✅ 去重完成: 删除 {len(to_delete)} 个，裁剪 {trimmed_count} 个")
    else:
        print(f"  ℹ️ 无重复内容")
    
    return len(to_delete), trimmed_count

def main():
    parser = argparse.ArgumentParser(description="1368元神系统 - 会话历史数据提取")
    parser.add_argument("--dry-run", action="store_true", help="仅模拟，不实际写入")
    parser.add_argument("--agent", type=str, help="指定智能体ID")
    parser.add_argument("--no-dedup", action="store_true", help="跳过去重步骤")
    args = parser.parse_args()
    
    print("=" * 60)
    print("  1368元神系统 - 会话历史数据提取")
    print("=" * 60)
    
    # 确定要处理的智能体
    if args.agent:
        agents = {args.agent: AGENTS_SESSIONS.get(args.agent, "")}
    else:
        agents = AGENTS_SESSIONS
    
    print(f"\n处理范围: .trajectory.jsonl + checkpoint + 当前会话.jsonl")
    print(f"跳过: .deleted, .lock")
    print(f"输出阈值: {L0_SIZE_LIMIT / 1024 / 1024:.0f}MB (从1368_config.json读取)")
    print(f"\n将处理 {len(agents)} 个智能体")
    
    total_success = 0
    for agent_id, sessions_dir in agents.items():
        if not sessions_dir or not os.path.exists(sessions_dir):
            continue
        
        count = migrate_agent(agent_id, sessions_dir, L0_RAW, args.dry_run)
        total_success += count
        
        # 去重处理（默认开启）
        if not args.no_dedup and not args.dry_run:
            dedup_del, dedup_trim = deduplicate_l0_files(agent_id, args.dry_run)
    
    print("\n" + "=" * 60)
    if args.dry_run:
        print(f"  [DRY RUN] 共处理 {total_success} 个文件")
    else:
        print(f"  ✅ 完成！共提取 {total_success} 个会话")
    print("=" * 60)

if __name__ == "__main__":
    main()