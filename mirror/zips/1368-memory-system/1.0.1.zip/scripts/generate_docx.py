#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神系统 - 完整技能说明文档生成器
=====================================
"""

import os
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE

SKILL_DIR = "/root/.openclaw/workspace/main/skills/1368元神记忆系统"
OUTPUT_PATH = os.path.join(SKILL_DIR, "1368元神系统技能说明文档.docx")

def add_heading(doc, text, level):
    heading = doc.add_heading(text, level)
    return heading

def add_code(doc, code, title=""):
    if title:
        p = doc.add_paragraph(title)
        p.style = 'Quote'
    pre = doc.add_paragraph()
    run = pre.add_run(code)
    run.font.name = 'Courier New'
    run.font.size = Pt(9)

def create_doc():
    doc = Document()
    
    # ========== 标题页 ==========
    doc.add_heading('1368元神系统', 0)
    doc.add_paragraph('1元3维6层8面体记忆系统')
    doc.add_paragraph('')
    doc.add_paragraph('版本：v1.0.1')
    doc.add_paragraph('更新日期：2026-05-02')
    doc.add_paragraph('')
    
    # ========== 目录 ==========
    doc.add_heading('目录', 1)
    toc_items = [
        "1. 系统概述",
        "2. 系统架构",
        "3. 目录结构",
        "4. 核心脚本说明",
        "5. 配置向导",
        "6. 安装向导",
        "7. L0监听器",
        "8. 历史数据回溯",
        "9. 分片合并工具",
        "10. 系统状态查看",
        "11. 快速开始",
        "12. 常见问题"
    ]
    for item in toc_items:
        doc.add_paragraph(item)
    
    doc.add_page_break()
    
    # ========== 1. 系统概述 ==========
    doc.add_heading('1. 系统概述', 1)
    doc.add_paragraph('''1368元神系统是攀西助贷网数字员工团队的永久记忆系统，采用"1元3维6层8面体"架构设计。

核心设计原则：
• 只读不写：永远不修改原始 .jsonl 会话文件
• 实时转写：新产生的每条消息实时转写到 L0 层文件
• 文件限制：L0<=2MB，L1/L2/L3<=200KB
• 独立进程：L1/L2/L3 提取与 OpenClaw 解耦
''')
    
    add_heading(doc, "1.1 名词解释", 2)
    doc.add_paragraph('''
| 名词 | 说明 |
|------|------|
| L0层（一元） | 原始会话复刻，一比一复刻原始会话 |
| L1层（三维之一） | 决策提取，记录用户确认、选择、纠正等关键决策 |
| L2层（三维之二） | 场景提取，记录任务上下文、使用工俱等 |
| L3层（三维之三） | 画像提取，记录用户偏好、习惯等 |
| 六层 | 原始→复刻→L1→L2→L3→索引 |
| 八面体 | 记忆索引+知识库索引双驱动 |
''')
    
    add_heading(doc, "1.2 文件规格限制", 2)
    doc.add_paragraph('''
| 层级 | 文件大小限制 |
|------|-------------|
| L0层 | <=2MB（超过自动建新文件） |
| L1/L2/L3层 | <=200KB（超过自动建新文件） |
''')
    
    # ========== 2. 系统架构 ==========
    doc.add_heading('2. 系统架构', 1)
    doc.add_paragraph('''
1368元神系统架构如下：

                    ┌─────────────────────────────────────┐
                    │          OpenClaw 运行时             │
                    │   (原始会话 .jsonl 文件写入)         │
                    └──────────────┬──────────────────────┘
                                   │
                    ┌──────────────▼──────────────────────┐
                    │         L0 Watcher 监听器            │
                    │   (只读不写，转写到 L0_raw/)         │
                    └──────────────┬──────────────────────┘
                                   │
          ┌────────────────────────┼────────────────────────┐
          │                        │                        │
┌─────────▼─────────┐    ┌─────────▼─────────┐    ┌─────────▼─────────┐
│   L1_decision/    │    │    L2_scene/     │    │   L3_profile/    │
│    (决策提取)     │    │    (场景提取)    │    │    (画像提取)    │
└───────────────────┘    └───────────────────┘    └───────────────────┘
          │                        │                        │
          └────────────────────────┼────────────────────────┘
                                   │
                    ┌──────────────▼──────────────────────┐
                    │       indexes/ (索引文件)           │
                    │   memory_index.faiss                │
                    │   knowledge_index.faiss             │
                    └─────────────────────────────────────┘
''')
    
    # ========== 3. 目录结构 ==========
    doc.add_heading('3. 目录结构', 1)
    doc.add_paragraph('''
1368元神系统目录结构：

/root/.openclaw/workspace/main/
└── memory/
    └── 1368-memory/
        ├── L0_raw/              # 一元：原始会话复刻 (<=2MB/文件)
        │   ├── main/
        │   ├── xiaodai/
        │   ├── xiaodang/
        │   ├── xiaogu/
        │   ├── xiaofa/
        │   └── vice-manager/
        ├── L1_decision/         # 三维之一：决策提取 (<=200KB/文件)
        ├── L2_scene/            # 三维之二：场景提取 (<=200KB/文件)
        ├── L3_profile/          # 三维之三：画像提取 (<=200KB/文件)
        ├── indexes/             # 六层：索引文件
        └── l0_timestamp_log.json # 时间戳日志

技能目录结构：

/root/.openclaw/workspace/main/skills/1368元神记忆系统/
├── SKILL.md                    # 技能说明
├── CHANGELOG.md                # 更新日志
├── DESIGN_1368.md              # 设计文档
├── logs/                       # 运行时日志
│   ├── l0_watcher.log          # L0监听器日志
│   ├── l0_session_log.json     # 会话操作流水
│   ├── l0_gap_recovery.json    # 异常中断恢复记录
│   └── l0_watcher_status.json  # 运行状态
├── scripts/                    # 核心脚本
│   ├── paths_config.py         # 路径配置
│   ├── l0_watcher.py           # L0监听器
│   ├── l123_extractor.py       # L1/L2/L3提取器
│   ├── build_index_1368.py     # 索引构建器
│   ├── config_wizard.py        # 配置向导
│   ├── install_wizard.py       # 安装向导
│   ├── migrate_history.py      # 历史数据回溯
│   ├── l0_split_merge.py       # 分片合并工具
│   ├── health_check.py        # 系统状态查看
│   ├── health_check.py         # 健康检查
│   └── auto_start.py           # 自动启动脚本
└── configs/                    # 配置文件
    └── 1368_config.json        # 系统配置
''')
    
    # ========== 4. 核心脚本说明 ==========
    doc.add_heading('4. 核心脚本说明', 1)
    
    add_heading(doc, "4.1 paths_config.py - 路径配置", 2)
    doc.add_paragraph('''
路径配置文件，定义所有目录和常量。
''')
    add_code(doc, '''# 主要配置
WORKSPACE = "/root/.openclaw/workspace/main"
MEMORY_1368 = os.path.join(WORKSPACE, "memory", "1368-memory")

# 六层目录
L0_RAW = os.path.join(MEMORY_1368, "L0_raw")           # 一元：原始会话复刻
L1_DECISION = os.path.join(MEMORY_1368, "L1_decision") # 三维之一：决策提取
L2_SCENE = os.path.join(MEMORY_1368, "L2_scene")       # 三维之二：场景提取
L3_PROFILE = os.path.join(MEMORY_1368, "L3_profile")   # 三维之三：画像提取
INDEXES = os.path.join(MEMORY_1368, "indexes")          # 六层：索引文件

# 文件大小限制
L0_SIZE_LIMIT = 2 * 1024 * 1024   # 2MB - L0层文件限制
L1_SIZE_LIMIT = 200 * 1024        # 200KB - L1/L2/L3层文件限制

# 智能体会话目录
AGENTS_SESSIONS = {
    'main': '/root/.openclaw/agents/main/sessions',
    'xiaodai': '/root/.openclaw/agents/xiaodai/sessions',
    ...
}
''', title="主要配置项")
    
    add_heading(doc, "4.2 l0_watcher.py - L0监听器", 2)
    doc.add_paragraph('''
L0 Watcher 是 1368元神系统的核心组件，负责：
• 监听 OpenClaw .jsonl 文件变动
• 只读取新增行（不碰原始文件）
• 实时追加到 L0 层 .md 文件
• 达到 2MB 限制时自动建新文件继续写同一会话
• 记录操作到 l0_timestamp_log.json
''')
    add_code(doc, '''# 使用方法
python3 scripts/l0_watcher.py

# 后台运行
nohup python3 scripts/l0_watcher.py > /dev/null 2>&1 &

# 查看状态
python3 scripts/health_check.py
''')
    
    add_heading(doc, "4.3 l0_split_merge.py - 分片合并工具", 2)
    doc.add_paragraph('''
用于导入历史记忆时合并 L0 Watcher 产生的分片文件。
''')
    add_code(doc, '''# 合并指定智能体的分片
python3 scripts/l0_split_merge.py --dir memory/1368-memory/L0_raw/main

# 合并所有智能体
python3 scripts/l0_split_merge.py

# 仅模拟
python3 scripts/l0_split_merge.py --dry-run
''')
    
    add_heading(doc, "4.4 migrate_history.py - 历史数据回溯", 2)
    doc.add_paragraph('''
将原系统 .jsonl 文件转写到 L0_raw 格式。
''')
    add_code(doc, '''# 回溯全部历史
python3 scripts/migrate_history.py --all

# 回溯最近30天
python3 scripts/migrate_history.py --days 30

# 指定智能体
python3 scripts/migrate_history.py --agent xiaodai --all

# 模拟运行
python3 scripts/migrate_history.py --dry-run --all
''')
    
    add_heading(doc, "4.5 build_index_1368.py - 索引构建器", 2)
    doc.add_paragraph('''
构建向量索引，支持增量更新。
''')
    add_code(doc, '''# 构建所有索引
python3 scripts/build_index_1368.py

# 仅构建内存索引
python3 scripts/build_index_1368.py --memory

# 仅构建知识库索引
python3 scripts/build_index_1368.py --knowledge
''')
    
    # ========== 5. 配置向导 ==========
    doc.add_heading('5. 配置向导', 1)
    doc.add_paragraph('''
config_wizard.py 是交互式配置向导，共 5 个步骤：
''')
    add_code(doc, '''python3 scripts/config_wizard.py

# 步骤说明：
# 1. L0 阈值配置（1MB/2MB/4MB）
# 2. L1/L2/L3 阈值配置（100KB/200KB/500KB）
# 3. 向量搜索配置（MiniMAX API/Ollama/其他）
# 4. 自启动配置（启用/禁用）
# 5. 历史数据回溯（全部/30天/不回溯）
''')
    
    # ========== 6. 安装向导 ==========
    doc.add_heading('6. 安装向导', 1)
    doc.add_paragraph('''
install_wizard.py 是交互式安装向导，共 4 个步骤：
''')
    add_code(doc, '''python3 scripts/install_wizard.py

# 步骤说明：
# 1. 环境检测（Python版本、依赖库、磁盘空间）
# 2. 选择安装组件
# 3. 执行安装
# 4. 验证安装
''')
    
    # ========== 7. L0监听器 ==========
    doc.add_heading('7. L0监听器', 1)
    
    add_heading(doc, "7.1 工作原理", 2)
    doc.add_paragraph('''
L0 Watcher 通过 watchdog 库监听 OpenClaw 的 .jsonl 文件变动：

1. 启动时：扫描所有 .jsonl 文件，记录当前位置
2. 运行时：检测到文件变化 → 只读取新增行 → 转写到 .md 文件
3. 写满 2MB → 自动建新文件继续写同一会话（通过 session_id 关联）
4. 停止时：记录停止时间到 l0_watcher_status.json
5. 重启时：从上次停止位置继续，自动补全停机期间的数据
''')
    
    add_heading(doc, "7.2 时间戳日志", 2)
    doc.add_paragraph('''
l0_timestamp_log.json 记录 L0 Watcher 的操作：

• start - 开始写入新文件
• append - 继续追加到当前文件

此日志用于标识"正在转写的会话"，在导入历史时避免覆盖。
''')
    add_code(doc, '''{
  "session_id": {
    "records": [
      {"timestamp": "2026-05-02T03:00:18", "action": "append", "details": {...}},
      {"timestamp": "2026-05-02T03:00:31", "action": "start", "details": {...}}
    ],
    "last_action": "start"
  }
}
''')
    
    # ========== 8. 历史数据回溯 ==========
    doc.add_heading('8. 历史数据回溯', 1)
    doc.add_paragraph('''
migrate_history.py 将原系统的 .jsonl 会话文件转写为 L0_raw 格式：

• 解析 .jsonl 文件中的消息
• 转换为 Markdown 格式
• 保存到 memory/1368-memory/L0_raw/{agent}/ 目录
• 命名格式：{agent}-{date}-{time}-{session}.md
''')
    
    # ========== 9. 分片合并工具 ==========
    doc.add_heading('9. 分片合并工具', 1)
    doc.add_paragraph('''
l0_split_merge.py 用于合并 L0 Watcher 产生的分片文件。

说明：L0 Watcher 自动控制 <=2MB，不会产生 >2MB 的文件。
分片文件（.part001.md）是为了保证每个文件<=2MB而设计的标准格式。
''')
    add_code(doc, '''# 使用方法
python3 scripts/l0_split_merge.py --dir memory/1368-memory/L0_raw/main

# 查看时间戳日志
python3 scripts/l0_split_merge.py --log
''')
    
    # ========== 10. 系统状态查看 ==========
    doc.add_heading('10. 系统状态查看', 1)
    doc.add_paragraph('''
health_check.py 显示 1368元神系统的当前状态：
''')
    add_code(doc, '''python3 scripts/health_check.py

# 输出示例：
# ==================================================
# 1368元神系统状态
# ==================================================
# 工作区: /root/.openclaw/workspace/main
# 系统目录: /root/.openclaw/workspace/main/memory/1368-memory
# Embedding 后端: minimax
#
# [六层目录结构]
#   L0_raw: 71 文件 (9.6MB)
#   L1_decision: 无文件
#   L2_scene: 无文件
#   L3_profile: 无文件
#   indexes: 无文件
#
# [文件规格限制]
#   L0 文件限制: 2MB
#   L1/L2/L3 文件限制: 200KB
#
# [L0 Watcher 状态]
#   L0 Watcher: 运行中
# ==================================================
''')
    
    # ========== 11. 快速开始 ==========
    doc.add_heading('11. 快速开始', 1)
    
    add_heading(doc, "11.1 首次安装", 2)
    add_code(doc, '''# 1. 运行安装向导
python3 scripts/install_wizard.py

# 2. 运行配置向导
python3 scripts/config_wizard.py

# 3. 启动 L0 Watcher
python3 scripts/l0_watcher.py
''')
    
    add_heading(doc, "11.2 导入历史数据", 2)
    add_code(doc, '''# 1. 配置向导选择历史数据回溯方式
# 2. 或者手动执行回溯
python3 scripts/migrate_history.py --all

# 3. 合并分片（如有）
python3 scripts/l0_split_merge.py

# 4. 构建索引
python3 scripts/build_index_1368.py
''')
    
    add_heading(doc, "11.3 日常使用", 2)
    add_code(doc, '''# 查看系统状态
python3 scripts/health_check.py

# 查看健康状态
python3 scripts/health_check.py

# 重启 L0 Watcher（如已停止）
python3 scripts/auto_start.py
''')
    
    # ========== 12. 常见问题 ==========
    doc.add_heading('12. 常见问题', 1)
    
    add_heading(doc, "Q1: L0 Watcher 无法启动？", 2)
    doc.add_paragraph('''
检查：1) Python 版本 >=3.8；2) watchdog 库已安装；3) 配置文件存在
''')
    
    add_heading(doc, "Q2: 分片文件如何合并？", 2)
    doc.add_paragraph('''
运行：python3 scripts/l0_split_merge.py --dir memory/1368-memory/L0_raw/main
''')
    
    add_heading(doc, "Q3: 如何回溯历史数据？", 2)
    doc.add_paragraph('''
运行：python3 scripts/migrate_history.py --all
''')
    
    add_heading(doc, "Q4: 索引如何构建？", 2)
    doc.add_paragraph('''
运行：python3 scripts/build_index_1368.py
''')
    
    add_heading(doc, "Q5: L0 Watcher 是否会自动停止？", 2)
    doc.add_paragraph('''
不会。L0 Watcher 是常驻进程，使用 nohup 运行时可持续监听。
如需停止：pkill -f l0_watcher.py
''')
    
    # 保存
    doc.save(OUTPUT_PATH)
    print(f"文档已生成：{OUTPUT_PATH}")
    return OUTPUT_PATH

if __name__ == "__main__":
    create_doc()