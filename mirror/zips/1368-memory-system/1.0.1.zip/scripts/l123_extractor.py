#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神系统 - L1/L2/L3 提取器
===================================
1元3维6层8面体元神系统的三维提取模块

提取逻辑:
- L1 决策维度:决策、纠正、数字、结论
- L2 场景维度:任务、上下文、项目、事件
- L3 画像维度:偏好、习惯、风格、关系

独立进程,不与OpenClaw原生记忆交叉
"""

import os
import sys
import json
import re
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from paths_config import (
        WORKSPACE, MEMORY_1368, L0_RAW, L1_DECISION, L2_SCENE, L3_PROFILE,
        L1_SIZE_LIMIT, L2_SIZE_LIMIT, L3_SIZE_LIMIT
    )
except ImportError:
    print("[WARN] paths_config not found, using defaults")
    WORKSPACE = "/root/.openclaw/workspace/main"
    MEMORY_1368 = os.path.join(WORKSPACE, "memory", "1368-memory")
    L0_RAW = os.path.join(MEMORY_1368, "L0_raw")
    L1_DECISION = os.path.join(MEMORY_1368, "L1_decision")
    L2_SCENE = os.path.join(MEMORY_1368, "L2_scene")
    L3_PROFILE = os.path.join(MEMORY_1368, "L3_profile")
    L1_SIZE_LIMIT = L2_SIZE_LIMIT = L3_SIZE_LIMIT = 1024 * 1024  # 1MB

def extract_l1_decision(content):
    """提取 L1 决策信息"""
    decisions = []

    # 决策关键词
    decision_keywords = [
        "决定", "决策", "确认", "批准", "采用", "选择",
        "let us do", "go with", "execute", "confirm",
        "同意", "通过"
    ]

    # 数字和金额模式
    number_pattern = r"[\d,.]+\s*(?:万|亿|元|块|千|百)"

    lines = content.split("\n")
    for line in lines:
        line_lower = line.lower()

        # 检测决策关键词
        for kw in decision_keywords:
            if kw in line_lower:
                decisions.append(line.strip())
                break

        # 检测数字变化
        if re.search(number_pattern, line) and any(x in line for x in ["增加", "减少", "变化", "从"]):
            decisions.append(line.strip())

    return decisions

def extract_l2_scene(content):
    """提取 L2 场景信息"""
    scenes = []

    # 场景关键词
    scene_keywords = [
        "项目", "任务", "客户", "合同", "订单",
        "会议", "日程", "计划", "安排",
        "业务", "流程", "系统", "功能"
    ]

    lines = content.split("\n")
    for line in lines:
        line_lower = line.lower()

        for kw in scene_keywords:
            if kw in line_lower and len(line.strip()) > 10:
                scenes.append(line.strip())
                break

    return scenes[:50]

def extract_l3_profile(content):
    """提取 L3 画像信息"""
    profiles = []

    # 画像关键词
    profile_keywords = [
        "我喜欢", "我不喜欢", "i like", "i prefer",
        "习惯", "偏好", "风格", "通常", "一般",
        "我的", "我是", "觉得", "认为", "感觉"
    ]

    lines = content.split("\n")
    for line in lines:
        line_lower = line.lower()

        for kw in profile_keywords:
            if kw in line_lower:
                profiles.append(line.strip())
                break

    return profiles[:30]

def extract_date_from_l0_content(l0_path):
    """从L0文件内容中提取开始日期(跳过前几行的合并说明)"""
    try:
        with open(l0_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # 尝试从内容中找日期(跳过合并文件的header)
        lines = content.split('\n')

        # 跳过前10行的header(合并文件说明)
        for i, line in enumerate(lines[10:50], start=10):
            import re
            # 匹配 YYYY-MM-DD 格式
            match = re.search(r'^# (\d{4}-\d{2}-\d{2})', line)
            if match:
                return match.group(1).replace('-', '')
            # 匹配 YYYYMMDD 格式
            match = re.search(r'(\d{4})(\d{2})(\d{2})', line)
            if match:
                return f"{match.group(1)}{match.group(2)}{match.group(3)}"

        # 如果内容没找到,用文件修改时间
        import time
        return time.strftime("%Y%m%d", time.localtime(os.path.getmtime(l0_path)))
    except:
        return datetime.now().strftime("%Y%m%d")

def get_output_filename(level, date, seq, agent_id):
    """生成输出文件名: L(x)_日期_序号.md"""
    return f"L{level}_{date}_{seq:03d}_{agent_id}.md"

def find_next_l_file(l_dir, level, agent_id, content_date):
    """
    找到下一个可写入的L文件
    - 先查cursor，找到当前写入位置
    - 检查cursor文件是否满阀值
    - 满则新建序号+1的文件
    """
    limit = L1_SIZE_LIMIT if level == 1 else (L2_SIZE_LIMIT if level == 2 else L3_SIZE_LIMIT)
    level_key = f"L{level}"
    
    # 先查cursor
    cursor = get_cursor(agent_id, level)
    if cursor:
        cursor_file = os.path.join(l_dir, cursor['file'])
        if os.path.exists(cursor_file):
            cursor_size = os.path.getsize(cursor_file)
            if cursor_size < limit:
                # cursor文件未满，继续写入
                return cursor_file, cursor['seq'], cursor['date']
            else:
                # cursor文件满了，新建序号+1
                new_seq = cursor['seq'] + 1
                new_file = os.path.join(l_dir, get_output_filename(level, cursor['date'], new_seq, agent_id))
                return new_file, new_seq, cursor['date']
    
    # 无cursor，扫描现有文件找未满的
    if not os.path.exists(l_dir):
        os.makedirs(l_dir, exist_ok=True)
        path = os.path.join(l_dir, get_output_filename(level, content_date, 1, agent_id))
        return path, 1, content_date

    existing_files = [f for f in os.listdir(l_dir) 
                      if f.startswith(f"L{level}_") and f.endswith(f"_{agent_id}.md")]
    
    if not existing_files:
        path = os.path.join(l_dir, get_output_filename(level, content_date, 1, agent_id))
        return path, 1, content_date

    # 找最高序号且未满的文件
    candidates = []
    for f in existing_files:
        try:
            parts = f.replace('.md', '').split('_')
            file_date = parts[1]
            file_seq = int(parts[2])
            file_path = os.path.join(l_dir, f)
            file_size = os.path.getsize(file_path)
            candidates.append((file_seq, file_date, file_path, file_size))
        except:
            pass

    candidates.sort(key=lambda x: x[0], reverse=True)

    for seq, file_date, file_path, file_size in candidates:
        if file_size < limit:
            return file_path, seq, file_date

    # 全部满了，新建序号+1（使用最高序号文件的日期）
    highest_seq = candidates[0][0]
    file_date = candidates[0][1]
    new_seq = highest_seq + 1
    new_path = os.path.join(l_dir, get_output_filename(level, file_date, new_seq, agent_id))
    return new_path, new_seq, file_date

def process_l0_file(l0_path, agent_id="main"):
    """处理单个 L0 文件,提取 L1/L2/L3(累加到文件)"""
    try:
        with open(l0_path, "r", encoding="utf-8") as f:
            content = f.read()

        l0_filename = os.path.basename(l0_path)
        session_id = l0_filename.replace(".md", "")

        # 从L0文件内容提取起始日期
        date = extract_date_from_l0_content(l0_path)

        # 提取三维信息
        l1_items = extract_l1_decision(content)
        l2_items = extract_l2_scene(content)
        l3_items = extract_l3_profile(content)

        # 统计
        result = {
            "file": session_id,
            "date": date,
            "l1_count": len(l1_items),
            "l2_count": len(l2_items),
            "l3_count": len(l3_items)
        }

        # 处理 L1
        if l1_items:
            l1_dir = os.path.join(L1_DECISION, agent_id)
            os.makedirs(l1_dir, exist_ok=True)

            # 找到最新文件或新建（使用内容的起始日期）
            l1_path, seq, file_date = find_next_l_file(l1_dir, 1, agent_id, date)
            # 检查是否超限，超限则用下一个序号
            if l1_path and os.path.exists(l1_path):
                current_size = os.path.getsize(l1_path)
                new_size = sum(len(item.encode('utf-8')) for item in l1_items) + 300
                if current_size + new_size > L1_SIZE_LIMIT:
                    seq += 1
                    l1_path = os.path.join(l1_dir, get_output_filename(1, file_date, seq, agent_id))

            with open(l1_path, 'a', encoding='utf-8') as f:
                f.write(f"\n## 来源: {l0_filename}\n\n")
                for item in l1_items:
                    f.write(f"- {item}\n")
            print(f"[L1-追加] L1_{file_date}_{seq:03d}_{agent_id}.md: +{len(l1_items)} 条")
            # 更新cursor
            update_cursor(agent_id, 1, l1_path, file_date, seq, len(l1_items))

        # 处理 L2
        if l2_items:
            l2_dir = os.path.join(L2_SCENE, agent_id)
            os.makedirs(l2_dir, exist_ok=True)

            l2_path, seq, file_date = find_next_l_file(l2_dir, 2, agent_id, date)
            # 检查是否超限，超限则用下一个序号
            if l2_path and os.path.exists(l2_path):
                current_size = os.path.getsize(l2_path)
                new_size = sum(len(item.encode('utf-8')) for item in l2_items) + 300
                if current_size + new_size > L2_SIZE_LIMIT:
                    seq += 1
                    l2_path = os.path.join(l2_dir, get_output_filename(2, file_date, seq, agent_id))

            with open(l2_path, 'a', encoding='utf-8') as f:
                f.write(f"\n## 来源: {l0_filename}\n\n")
                for item in l2_items:
                    f.write(f"- {item}\n")
            print(f"[L2-追加] L2_{file_date}_{seq:03d}_{agent_id}.md: +{len(l2_items)} 条")
            # 更新cursor
            update_cursor(agent_id, 2, l2_path, file_date, seq, len(l2_items))

        # 处理 L3
        if l3_items:
            l3_dir = os.path.join(L3_PROFILE, agent_id)
            os.makedirs(l3_dir, exist_ok=True)

            l3_path, seq, file_date = find_next_l_file(l3_dir, 3, agent_id, date)
            # 检查是否超限，超限则用下一个序号
            if l3_path and os.path.exists(l3_path):
                current_size = os.path.getsize(l3_path)
                new_size = sum(len(item.encode('utf-8')) for item in l3_items) + 300
                if current_size + new_size > L3_SIZE_LIMIT:
                    seq += 1
                    l3_path = os.path.join(l3_dir, get_output_filename(3, file_date, seq, agent_id))

            with open(l3_path, 'a', encoding='utf-8') as f:
                f.write(f"\n## 来源: {l0_filename}\n\n")
                for item in l3_items:
                    f.write(f"- {item}\n")
            print(f"[L3-追加] L3_{file_date}_{seq:03d}_{agent_id}.md: +{len(l3_items)} 条")
            # 更新cursor
            update_cursor(agent_id, 3, l3_path, file_date, seq, len(l3_items))

        # 标记L0文件已处理
        mark_l0_processed(agent_id, l0_filename)

        return result

    except Exception as e:
        print(f"[L123-错误] {l0_path}: {e}")
        return {"file": l0_filename, "l1_count": 0, "l2_count": 0, "l3_count": 0, "error": str(e)}

def get_log_path():
    """获取日志文件路径"""
    return os.path.join(MEMORY_1368, "L123_log.json")

def load_log():
    """加载日志"""
    log_path = get_log_path()
    if os.path.exists(log_path):
        try:
            with open(log_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            pass
    return {
        "runs": [],
        "total_files": 0,
        "total_l1": 0,
        "total_l2": 0,
        "total_l3": 0
    }

def save_log(log_data):
    """保存日志"""
    log_path = get_log_path()
    with open(log_path, 'w', encoding='utf-8') as f:
        json.dump(log_data, f, ensure_ascii=False, indent=2)

# === Cursor 记录（下次写入位置） ===
def get_cursor_path():
    """获取cursor文件路径"""
    return os.path.join(MEMORY_1368, "L123_cursor.json")

def load_cursor():
    """加载cursor记录"""
    cursor_path = get_cursor_path()
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            pass
    return {}

def save_cursor(cursor_data):
    """保存cursor记录"""
    cursor_path = get_cursor_path()
    try:
        with open(cursor_path, 'w', encoding='utf-8') as f:
            json.dump(cursor_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[WARN] 保存cursor失败: {e}")

def update_cursor(agent_id, level, file_path, file_date, seq, count):
    """更新cursor记录"""
    cursor = load_cursor()
    if agent_id not in cursor:
        cursor[agent_id] = {}
    level_key = f"L{level}"
    cursor[agent_id][level_key] = {
        "file": os.path.basename(file_path),
        "date": file_date,
        "seq": seq,
        "last_count": count
    }
    save_cursor(cursor)

def mark_l0_processed(agent_id, l0_filename):
    """标记L0文件已处理"""
    cursor = load_cursor()
    if agent_id not in cursor:
        cursor[agent_id] = {}
    if "processed_l0" not in cursor[agent_id]:
        cursor[agent_id]["processed_l0"] = []
    if l0_filename not in cursor[agent_id]["processed_l0"]:
        cursor[agent_id]["processed_l0"].append(l0_filename)
    save_cursor(cursor)

def is_l0_processed(agent_id, l0_filename):
    """检查L0文件是否已处理"""
    cursor = load_cursor()
    return l0_filename in cursor.get(agent_id, {}).get("processed_l0", [])

def get_cursor(agent_id, level):
    """获取指定agent和level的cursor"""
    cursor = load_cursor()
    return cursor.get(agent_id, {}).get(f"L{level}")

def record_extract_run(agent_id, l0_files_processed, results):
    """
    记录一次提取运行
    results: list of {file: str, l1_count: int, l2_count: int, l3_count: int}
    """
    log = load_log()

    # 本次运行的统计
    run = {
        "timestamp": datetime.now().isoformat(),
        "agent": agent_id,
        "files": [],
        "file_count": len(results),
        "l1_sum": 0,
        "l2_sum": 0,
        "l3_sum": 0
    }

    for r in results:
        file_stats = {
            "file": r["file"],
            "l1": r["l1_count"],
            "l2": r["l2_count"],
            "l3": r["l3_count"]
        }
        run["files"].append(file_stats)
        run["l1_sum"] += r["l1_count"]
        run["l2_sum"] += r["l2_count"]
        run["l3_sum"] += r["l3_count"]

    # 累计统计
    log["total_files"] += len(results)
    log["total_l1"] += run["l1_sum"]
    log["total_l2"] += run["l2_sum"]
    log["total_l3"] += run["l3_sum"]

    run["cumulative_files"] = log["total_files"]
    run["cumulative_l1"] = log["total_l1"]
    run["cumulative_l2"] = log["total_l2"]
    run["cumulative_l3"] = log["total_l3"]

    log["runs"].append(run)
    save_log(log)

    return run

def print_run_summary(run):
    """打印运行摘要"""
    print(f"\n📊 本次提取统计 [{run['timestamp']}]")
    print(f"   Agent: {run['agent']}")
    print(f"   文件数: {run['file_count']}")
    print(f"   L1决策: {run['l1_sum']} 条")
    print(f"   L2场景: {run['l2_sum']} 条")
    print(f"   L3画像: {run['l3_sum']} 条")
    print(f"   累计: 文件={run['cumulative_files']}, L1={run['cumulative_l1']}, L2={run['cumulative_l2']}, L3={run['cumulative_l3']}")

def scan_and_process_all(agent_id="main"):
    """扫描所有 L0 文件并处理,返回结果列表"""
    agent_l0_dir = os.path.join(L0_RAW, agent_id)
    if not os.path.exists(agent_l0_dir):
        print(f"[L123] 无 L0 目录: {agent_l0_dir}")
        return []

    l0_files = [f for f in os.listdir(agent_l0_dir) if f.endswith(".md")]
    print(f"[L123] 发现 {len(l0_files)} 个 L0 文件")
    
    results = []
    for l0_file in l0_files:
        # 检查是否已处理过
        if is_l0_processed(agent_id, l0_file):
            continue
        
        l0_path = os.path.join(agent_l0_dir, l0_file)
        result = process_l0_file(l0_path, agent_id)
        results.append(result)
    
    return results

def main():
    print("=" * 50)
    print("[1368元神系统] L1/L2/L3 提取器")
    print(f"L0_raw: {L0_RAW}")
    print(f"L1_decision: {L1_DECISION}")
    print(f"L2_scene: {L2_SCENE}")
    print(f"L3_profile: {L3_PROFILE}")
    print("=" * 50)

    # 处理所有智能体的 L0 文件
    agents = ["main", "xiaodai", "xiaodang", "xiaogu", "xiaofa", "vice-manager"]
    for agent in agents:
        print(f"\n[处理] {agent} ...")
        results = scan_and_process_all(agent)
        if results:
            run = record_extract_run(agent, len(results), results)
            print_run_summary(run)

    # 显示累计统计
    log = load_log()
    print("\n" + "=" * 50)
    print("[L123] 历史累计统计")
    print(f"   总文件数: {log['total_files']}")
    print(f"   L1决策累计: {log['total_l1']} 条")
    print(f"   L2场景累计: {log['total_l2']} 条")
    print(f"   L3画像累计: {log['total_l3']} 条")
    print("=" * 50)
    print(f"\n📁 日志文件: {get_log_path()}")
    print("[L123] 处理完成")

if __name__ == "__main__":
    main()
