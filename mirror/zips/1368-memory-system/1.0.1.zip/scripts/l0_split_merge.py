#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神系统 - L0分片合并工具
===================================
用于历史记忆导入时合并 L0 Watcher 产生的分片文件

功能：
1. 拆分超过限制的大文件（默认4MB）
2. 合并分片文件（.part001.md 格式）
3. **批量合并**：按时间排序合并同目录下的多个文件
   - 名称以第一个文件为准
   - 内容头部标注源文件列表
   - 支持日期排序模式（YYYYMMDD）

时间戳日志 (l0_timestamp_log.json)：
- start - 开始写入新文件（同一会话可能多个文件）
- append - 继续追加到当前文件
"""

import os
import sys
import json
import argparse
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from paths_config import L0_RAW, get_timestamp_log_path, L0_SIZE_LIMIT

def load_timestamp_log():
    """加载时间戳日志"""
    log_path = get_timestamp_log_path()
    if os.path.exists(log_path):
        try:
            with open(log_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_timestamp_log(log_data):
    """保存时间戳日志"""
    log_path = get_timestamp_log_path()
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    with open(log_path, 'w', encoding='utf-8') as f:
        json.dump(log_data, f, ensure_ascii=False, indent=2)

def record_action(session_id, action, details):
    """记录动作到时间戳日志"""
    log = load_timestamp_log()
    if session_id not in log:
        log[session_id] = {"records": [], "last_action": None}
    
    log[session_id]["records"].append({
        "timestamp": datetime.now().isoformat(),
        "action": action,
        "details": details
    })
    log[session_id]["last_action"] = action
    save_timestamp_log(log)

def is_part_file(filename):
    """判断是否是分片文件（格式: basename.part001.md）"""
    import re
    return bool(re.search(r'\.part\d+\.md$', filename))

def get_basename_from_part(part_filename):
    """从分片文件名获取原始basename（格式: basename.part001.md -> basename）"""
    # L0-2026-05-01.part001.md -> L0-2026-05-01
    # main-2026-04-30-2001-2f839830.part001.md -> main-2026-04-30-2001-2f839830
    import re
    match = re.match(r'^(.+)\.part\d+\.md$', part_filename)
    return match.group(1) if match else part_filename

def split_file(file_path, target_dir, size_limit=None):
    """拆分大文件为指定大小的分片"""
    if size_limit is None:
        size_limit = L0_SIZE_LIMIT
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    file_size = len(content.encode('utf-8'))
    if file_size <= size_limit:
        return True, "文件小于限制，无需拆分"
    
    basename = os.path.splitext(os.path.basename(file_path))[0]
    lines = content.split('\n')
    
    part_num = 1
    current_size = 0
    current_lines = []
    total_parts = (file_size + size_limit - 1) // size_limit
    
    for line in lines:
        line_size = len(line.encode('utf-8')) + 1  # +1 for newline
        
        if current_size + line_size > size_limit and current_lines:
            # 写入当前分片
            output_name = f"{basename}.part{part_num:03d}.md"
            output_path = os.path.join(target_dir, output_name)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(current_lines))
            
            record_action(basename, "split", {
                "part": part_num,
                "output": output_name,
                "size": os.path.getsize(output_path)
            })
            
            current_size = 0
            current_lines = []
            part_num += 1
        
        current_lines.append(line)
        current_size += line_size
    
    # 写入最后一个分片
    if current_lines:
        output_name = f"{basename}.part{part_num:03d}.md"
        output_path = os.path.join(target_dir, output_name)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(current_lines))
        
        record_action(basename, "split", {
            "part": part_num,
            "output": output_name,
            "size": os.path.getsize(output_path)
        })
    
    return True, f"拆分完成 ({total_parts} 个分片)"

def process_split(directory, dry_run=False):
    """处理拆分超过限制的文件"""
    if not os.path.exists(directory):
        return [], f"目录不存在: {directory}"
    
    actions = []
    size_limit = L0_SIZE_LIMIT
    
    for filename in os.listdir(directory):
        # 跳过已经是分片的文件
        if is_part_file(filename):
            continue
        
        file_path = os.path.join(directory, filename)
        if not os.path.isfile(file_path) or not filename.endswith('.md'):
            continue
        
        file_size = os.path.getsize(file_path)
        if file_size <= size_limit:
            continue
        
        print(f"\n📦 拆分: {filename} ({file_size // 1024}KB > {size_limit // 1024}KB限制)")
        
        if dry_run:
            print(f"   [DRY] 将拆分为多个分片")
            actions.append(f"split: {filename}")
            continue
        
        success, msg = split_file(file_path, directory, size_limit)
        
        if success:
            print(f"   ✅ {msg}")
            actions.append(f"split: {filename}")
            # 删除原文件（已拆分）
            os.remove(file_path)
        else:
            print(f"   ❌ {msg}")
    
    return actions, f"处理了 {len(actions)} 个文件"

def collect_parts(directory):
    """收集所有分片文件组"""
    part_groups = {}  # basename -> [part_files sorted]
    
    for f in os.listdir(directory):
        if not is_part_file(f):
            continue
        
        basename = get_basename_from_part(f)
        if basename not in part_groups:
            part_groups[basename] = []
        part_groups[basename].append(os.path.join(directory, f))
    
    # 排序
    for basename in part_groups:
        part_groups[basename] = sorted(part_groups[basename])
    
    return part_groups

def merge_parts(basename, part_files, output_dir):
    """合并分片文件"""
    # 确保输出文件名有 .md 扩展名
    if not basename.endswith('.md'):
        output_path = os.path.join(output_dir, basename + '.md')
    else:
        output_path = os.path.join(output_dir, basename)
    all_content = []
    header = None
    
    for part_file in sorted(part_files):
        try:
            with open(part_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            lines = content.split('\n')
            
            # 提取头部（只取第一个分片的头部）
            if header is None:
                header_lines = []
                for i, line in enumerate(lines):
                    if i < 10 and (line.startswith('#') or line.startswith('**') or line.strip() == '---'):
                        header_lines.append(line)
                    else:
                        break
                header = '\n'.join(header_lines)
            
            # 收集内容（跳过头部）
            in_content = False
            for i, line in enumerate(lines):
                if i < 10 and (line.startswith('#') or line.startswith('**') or line.strip() == '---'):
                    continue
                if not line.strip() and not in_content:
                    continue
                in_content = True
                all_content.append(line)
        
        except Exception as e:
            return False, f"读取失败 {part_file}: {e}"
    
    # 写入合并文件
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            if header:
                f.write(header + '\n\n')
            f.write('\n'.join(all_content))
    except Exception as e:
        return False, f"写入失败: {e}"
    
    return True, f"合并完成 ({len(part_files)} 个分片)"

def merge_by_date_order(source_dir, output_filename=None, dry_run=False):
    """
    按时间排序合并同目录下的多个文件
    - 名称以第一个文件为准（或指定 output_filename）
    - 内容头部标注源文件列表
    - 支持日期排序模式（YYYYMMDD）
    """
    import re
    
    # 获取所有 .md 文件（排除已合并的和分片文件）
    files = [f for f in os.listdir(source_dir) 
             if f.endswith('.md') and '_MERGED_' not in f and '.part' not in f]
    
    if not files:
        return [], "没有找到需要合并的文件"
    
    # 提取日期用于排序
    def extract_date(fname):
        match = re.search(r'(\d{8})|(\d{4}-\d{2}-\d{2})', fname)
        if match:
            if match.group(1):
                return match.group(1)  # YYYYMMDD
            else:
                return match.group(2).replace('-', '')  # YYYY-MM-DD -> YYYYMMDD
        return '00000000'
    
    # 按日期排序
    sorted_files = sorted(files, key=extract_date)
    
    # 确定输出文件名
    if output_filename is None:
        output_filename = f"_MERGED_{sorted_files[0]}"
        if not output_filename.endswith('.md'):
            output_filename += '.md'
    
    output_path = os.path.join(source_dir, output_filename)
    
    actions = []
    for f in sorted_files:
        actions.append(f"merge: {f}")
    
    if dry_run:
        return actions, f"将合并 {len(sorted_files)} 个文件到 {output_filename}"
    
    # 读取所有内容
    merged_content = []
    for fname in sorted_files:
        fpath = os.path.join(source_dir, fname)
        with open(fpath, 'r', encoding='utf-8') as f:
            merged_content.append(f.read())
    
    # 生成头部
    header = f"""# 批量合并文件

> 合并日期: {datetime.now().strftime('%Y-%m-%d')}
> 合并文件数: {len(sorted_files)}

## 源文件列表（按时间排序）

"""
    for i, fn in enumerate(sorted_files, 1):
        header += f"{i}. {fn}\n"
    
    header += "\n---\n\n"
    
    # 写入合并文件
    final_content = header + "\n\n---\n\n".join(merged_content)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(final_content)
    
    return actions, f"合并完成: {output_filename} ({len(sorted_files)} 个文件)"

def process_merge(directory, dry_run=False):
    """处理合并所有分片"""
    part_groups = collect_parts(directory)
    
    if not part_groups:
        return [], "没有找到分片文件"
    
    actions = []
    
    for basename, parts in sorted(part_groups.items()):
        print(f"\n📦 合并: {basename}")
        print(f"   分片: {len(parts)} 个")
        
        if dry_run:
            print(f"   [DRY] → {basename}")
            actions.append(f"merge: {basename} ({len(parts)} parts)")
            continue
        
        output_path = os.path.join(directory, basename + '.md')
        success, msg = merge_parts(basename, parts, directory)
        
        if success:
            # 删除分片文件
            for p in parts:
                os.remove(p)
            
            # 记录到时间戳日志（用带.md的文件名）
            output_basename = os.path.basename(output_path)
            record_action(output_basename, "merge", {
                "parts": len(parts),
                "output": output_basename,
                "size": os.path.getsize(output_path)
            })
            
            print(f"   ✅ {msg}")
            actions.append(f"merge: {basename}")
        else:
            print(f"   ❌ {msg}")
    
    return actions, f"处理了 {len(part_groups)} 组分片"

def main():
    parser = argparse.ArgumentParser(description="1368元神系统 - L0分片合并工具")
    parser.add_argument('--dir', default=L0_RAW, help='L0_raw目录路径（包含各智能体子目录）')
    parser.add_argument('--dry-run', action='store_true', help='仅模拟')
    parser.add_argument('--log', action='store_true', help='查看时间戳日志')
    parser.add_argument('--session', type=str, help='查看指定会话的时间戳')
    parser.add_argument('--split', action='store_true', help='拆分超过限制的大文件')
    parser.add_argument('--merge', action='store_true', help='合并分片文件')
    parser.add_argument('--merge-date', action='store_true', help='按时间排序合并多个文件（批量合并）')
    parser.add_argument('--output', type=str, help='合并后的输出文件名（用于--merge-date）')
    args = parser.parse_args()
    
    print("=" * 60)
    print("  1368元神系统 - L0分片合并工具")
    print("  阈值: {}MB".format(L0_SIZE_LIMIT // 1024 // 1024))
    print("=" * 60)
    
    if args.log:
        log = load_timestamp_log()
        if args.session:
            if args.session in log:
                print(f"\n会话: {args.session}")
                for rec in log[args.session].get("records", []):
                    print(f"  [{rec['timestamp']}] {rec['action']}")
                    print(f"    {rec['details']}")
            else:
                print(f"\n未找到会话: {args.session}")
        else:
            print(f"\n共有 {len(log)} 个会话记录")
            for sid, data in log.items():
                last = data.get("last_action", "N/A")
                print(f"  {sid}: {last}")
        return
    
    print(f"\nL0目录: {args.dir}")
    
    # 收集所有智能体的分片
    all_actions = []
    
    # 按时间排序批量合并
    if args.merge_date:
        # 直接使用 args.dir 作为目标目录（支持任意目录名）
        target_dir = args.dir
        
        if os.path.exists(target_dir):
            actions, msg = merge_by_date_order(target_dir, args.output, args.dry_run)
            all_actions.extend(actions)
            print(f"\n批量合并: {msg}")
        else:
            print(f"\n目录不存在: {target_dir}")
    else:
        # 确定操作类型
        do_split = args.split or (not args.merge and not args.log)
        do_merge = args.merge
    
    # 检查是否指定了具体的智能体目录
    if os.path.basename(args.dir) in ['main', 'xiaodai', 'xiaodang', 'xiaogu', 'xiaofa', 'vice-manager']:
        # 直接处理指定目录
        agent_dir = args.dir
        if os.path.exists(agent_dir):
            if do_split:
                actions, msg = process_split(agent_dir, args.dry_run)
                all_actions.extend(actions)
                print(f"\n{agent_dir}: {msg}")
            if do_merge:
                actions, msg = process_merge(agent_dir, args.dry_run)
                all_actions.extend(actions)
                print(f"\n{agent_dir}: {msg}")
    else:
        # 遍历所有智能体子目录
        for agent in ['main', 'xiaodai', 'xiaodang', 'xiaogu', 'xiaofa', 'vice-manager']:
            agent_dir = os.path.join(args.dir, agent)
            if os.path.exists(agent_dir):
                if do_split:
                    actions, msg = process_split(agent_dir, args.dry_run)
                    if actions:
                        all_actions.extend(actions)
                        print(f"\n{agent}: {msg}")
                if do_merge:
                    actions, msg = process_merge(agent_dir, args.dry_run)
                    if actions:
                        all_actions.extend(actions)
                        print(f"\n{agent}: {msg}")
    
    # 完成
    print("\n" + "=" * 60)
    if args.dry_run:
        print(f"  [DRY RUN] 将执行 {len(all_actions)} 个合并操作")
        for a in all_actions[:10]:
            print(f"    {a}")
        if len(all_actions) > 10:
            print(f"    ... 还有 {len(all_actions) - 10} 个")
    else:
        print(f"  ✅ 完成！执行了 {len(all_actions)} 个合并操作")
    print("=" * 60)

if __name__ == "__main__":
    main()