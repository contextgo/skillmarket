"""
1368元神记忆系统 - 向量搜索
=================================
语义搜索四层向量索引：L0 + L1 + L2 + L3
支持 memory_index 和 knowledge_index

使用方式：
  python3 vector_search.py "搜索关键词" [--top 5] [--layer L0]
  
搜索方式由 config_wizard.py 配置后存储在 configs/1368_config.json 的 SEARCH_MODE 字段
"""

import sys
import os
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
os.environ['PYTHONIOENCODING'] = 'utf-8'

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 加载.env配置文件
def load_env_file():
    """从configs/.env.local加载环境变量"""
    env_path = os.path.join(os.path.dirname(__file__), '..', 'configs', '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key.strip()] = value.strip()

load_env_file()

# 从 paths_config 导入索引配置和搜索模式
from paths_config import (
    INDEXES, INDEX_CONFIG, WORKSPACE,
    EMBEDDING_BACKEND, OLLAMA_URL, EMBED_MODEL,
    SEARCH_MODE
)

import json
import numpy as np
import faiss

# ==================== 系统检测 ====================

def check_memory_search_available():
    """检测 memorySearch 是否可用"""
    config_path = "/root/.openclaw/openclaw.json"
    if not os.path.exists(config_path):
        return False
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        agents = config.get('agents', {}).get('list', [])
        for agent in agents:
            if agent.get('id') == 'main':
                ms = agent.get('memorySearch', {})
                return ms.get('provider') == 'openai' and ms.get('model')
        return False
    except:
        return False

# ==================== Embedding 后端 ====================

def get_embedding_ollama(text):
    """从 Ollama 获取 embedding"""
    import requests
    response = requests.post(
        f"{OLLAMA_URL}/api/embeddings",
        json={"model": EMBED_MODEL, "prompt": text},
        timeout=60
    )
    response.raise_for_status()
    return np.array(response.json()["embedding"], dtype=np.float32)

def get_embedding_api(text):
    """从 MiniMAX API 获取 embedding（OpenAI兼容格式）"""
    api_key = os.environ.get("OPENAI_API_KEY", "")
    api_base = os.environ.get("OPENAI_API_BASE", "https://api.minimax.chat/v1")
    model = os.environ.get("EMBEDDING_MODEL", "embo-01")

    if not api_key:
        raise RuntimeError("API mode selected but OPENAI_API_KEY is not set")

    import requests
    response = requests.post(
        f"{api_base}/embeddings",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        },
        json={"texts": [text], "type": "db", "model": model},
        timeout=30
    )
    response.raise_for_status()
    data = response.json()
    return np.array(data["vectors"][0], dtype=np.float32)

def get_embedding(text):
    """根据配置选择后端"""
    if EMBEDDING_BACKEND == "ollama":
        return get_embedding_ollama(text)
    else:
        return get_embedding_api(text)

# ==================== 搜索函数 ====================

def search_index(query, layer_name, layer_config, top_k=5):
    """搜索单个索引"""
    index_file = layer_config["index_file"]
    meta_file = layer_config["meta_file"]

    if not os.path.exists(index_file) or not os.path.exists(meta_file):
        return []

    # 加载索引
    index = faiss.read_index(index_file)

    # 加载元数据
    with open(meta_file, 'r', encoding='utf-8') as f:
        docs = json.load(f)

    # 生成 query embedding
    query_emb = get_embedding(query).reshape(1, -1)

    # 搜索
    k = min(top_k, len(docs))
    D, I = index.search(query_emb, k)

    # 整理结果
    results = []
    for i, (d, idx) in enumerate(zip(D[0], I[0])):
        if idx < len(docs):
            results.append({
                "rank": i + 1,
                "score": float(d),
                "content": docs[idx].get("content", docs[idx].get("text", ""))[:200],
                "source": docs[idx].get("source", ""),
                "file": docs[idx].get("file", "")
            })

    return results

def print_results(results, label):
    """打印搜索结果"""
    if not results:
        print(f"\n[{label}] 无结果")
        return

    print(f"\n[{label}] 找到 {len(results)} 个结果:")
    for r in results:
        print(f"\n--- 结果 {r['rank']} (相似度: {r['score']:.4f}) ---")
        print(f"文件: {r['file']}")
        print(f"内容: {r['content'][:150]}...")

def show_system_info():
    """显示系统配置信息"""
    memory_available = check_memory_search_available()
    
    print("\n" + "=" * 60)
    print("  📊 1368元神系统 - 搜索模式配置状态")
    print("=" * 60)
    print()
    print(f"  当前模式: {SEARCH_MODE}")
    print()
    
    if SEARCH_MODE == "memory":
        print("  ✓ 使用 memorySearch（腾讯TencentDB插件）")
        print("    - 自动索引 /workspace/main/memory/")
        print("    - SQLite + sqlite-vec 存储")
        print("    - 每次搜索消耗 token")
    elif SEARCH_MODE == "faiss":
        print("  ✓ 使用 1368 本地 FAISS 索引")
        print("    - 索引目录: " + INDEXES)
        print("    - 本地检索，不消耗 token")
    else:
        print("  ✓ 同时使用两套系统")
        print("    - memorySearch: 自动捕获")
        print("    - FAISS: 本地深度搜索")
    
    print()
    if memory_available:
        print("  memorySearch: ✅ 可用")
    else:
        print("  memorySearch: ⚠️ 未配置")
    print("=" * 60)
    print()

# ==================== 主程序 ====================

def main():
    import argparse
    parser = argparse.ArgumentParser(description='1368元神记忆系统 - 向量搜索')
    parser.add_argument('query', nargs='+', help='搜索关键词')
    parser.add_argument('--top', type=int, default=5, help='返回数量')
    parser.add_argument('--layer', type=str, default=None, help='指定层: L0/L1/L2/L3/memory/knowledge/all')
    parser.add_argument('--system', type=str, choices=['memory', 'faiss', 'info'], default=None,
                        help='指定搜索系统: memory/faiss/info')
    args = parser.parse_args()

    query = ' '.join(args.query)
    top_k = args.top
    target_layer = args.layer

    # 显示系统信息
    if args.system == 'info':
        show_system_info()
        return

    # 检测 memorySearch 是否可用
    memory_search_available = check_memory_search_available()

    # 根据配置决定搜索方式
    # 如果命令行指定了 --system，优先使用命令行的选择
    search_mode = args.system if args.system else SEARCH_MODE

    # 如果配置为 memory 但不可用，自动切换到 faiss
    if search_mode == 'memory' and not memory_search_available:
        print("\n⚠️ memorySearch 不可用，自动切换到 FAISS 模式")
        search_mode = 'faiss'

    if search_mode == 'memory':
        print("\n📢 当前配置使用 memorySearch（腾讯TencentDB插件）")
        print("   请直接在对话中使用 memorySearch 或 tdai_memory_search")
        print("   本脚本仅支持 1368 FAISS 索引搜索")
        return

    # 执行 1368 FAISS 搜索
    print("\n" + "=" * 50)
    print(f"🔍 搜索: {query}")
    print(f"📊 返回: 最多 {top_k} 个结果")
    print(f"📁 索引目录: {INDEXES}")
    if target_layer:
        print(f"🎯 指定层: {target_layer}")
    print("=" * 50)

    # 确定要搜索哪些层
    if target_layer and target_layer != 'all':
        layers_to_search = {target_layer: INDEX_CONFIG.get(target_layer.upper(), {})}
    else:
        layers_to_search = INDEX_CONFIG if target_layer == 'all' else INDEX_CONFIG

    # 搜索每个层
    for layer_name, layer_config in layers_to_search.items():
        if layer_config and layer_config.get("index_file"):
            print_results(search_index(query, layer_name, layer_config, top_k), layer_name)

if __name__ == "__main__":
    main()
