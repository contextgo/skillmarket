#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神系统 - L0 Watcher
===================================
心跳触发逻辑：
1. 读取archive_log（记录会话和行号）
2. 检查有无新增会话 → 无则退出
3. 写入L0文件（追加或新建）
4. 文件满4MB时，等当前条写完 → 新建L0继续写
5. 每满一个文件 → 触发L123处理 → 结束
6. L0/L1/L2/L3纳入系统索引
"""

import os
import sys
import json
from datetime import datetime

# 路径配置
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from paths_config import (
        WORKSPACE, MEMORY_1368, L0_RAW, L1_DECISION, L2_SCENE, L3_PROFILE,
        L0_SIZE_LIMIT, get_all_agent_sessions, get_l0_import_path, find_next_l0_file
    )
except ImportError:
    WORKSPACE = "/root/.openclaw/workspace/main"
    MEMORY_1368 = os.path.join(WORKSPACE, "memory", "1368-memory")
    L0_RAW = os.path.join(MEMORY_1368, "L0_raw")
    L0_SIZE_LIMIT = 4 * 1024 * 1024
    def get_all_agent_sessions():
        return [{'id': 'main', 'sessions_dir': '/root/.openclaw/agents/main/sessions'}]
    def get_l0_import_path(source_prefix, seq, output_dir, date_str=None):
        if date_str is None:
            date_str = datetime.now().strftime('%Y%m%d')
        filename = f"L0_{date_str}_{source_prefix}_{seq:03d}.md"
        return os.path.join(output_dir, filename)
    def find_next_l0_file(source_prefix, output_dir, date_str=None):
        if date_str is None:
            date_str = datetime.now().strftime('%Y%m%d')
        seq = 1
        while True:
            path = get_l0_import_path(source_prefix, seq, output_dir, date_str)
            if not os.path.exists(path):
                return path, seq
            if os.path.getsize(path) < L0_SIZE_LIMIT:
                return path, seq
            seq += 1
            if seq > 999:
                return get_l0_import_path(source_prefix, seq, output_dir, date_str), seq

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
LOG_DIR = os.path.join(SKILL_DIR, 'logs')
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "l0_watcher.log")

def log(msg):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{ts}] {msg}"
    print(line)
    try:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(line + "\n")
    except:
        pass

# ==================== Archive Log ====================
ARCHIVE_LOG = os.path.join(L0_RAW, "l0_archive_log.json")
TIMESTAMP_LOG = os.path.join(L0_RAW, "l0_timestamp_log.json")

TOOL_NAME = "l0_watcher"

def get_default_log_structure():
    """获取默认日志结构（v2.0按工具分开的格式）"""
    return {
        "_meta": {
            "version": "2.0",
            "total_sessions": 0,
            "total_messages": 0,
            "tools": [TOOL_NAME]
        },
        "_tools": {
            TOOL_NAME: {
                "sessions": 0,
                "messages": 0,
                "last_run": None
            }
        },
        TOOL_NAME: {}
    }

def migrate_old_format(data):
    """旧格式迁移到v2.0格式"""
    if "_meta" in data and "tools" in data.get("_meta", {}):
        return data  # 已是新格式
    new_data = get_default_log_structure()
    # 旧数据归到l0_watcher
    for k, v in data.items():
        if k != "_meta" and isinstance(v, dict):
            new_data["l0_watcher"][k] = v
    # 重建统计
    new_data["_meta"]["total_sessions"] = len(new_data["l0_watcher"])
    new_data["_meta"]["total_messages"] = sum(
        info.get("last_line_count", 0) 
        for info in new_data["l0_watcher"].values()
    )
    new_data["_tools"][TOOL_NAME]["sessions"] = new_data["_meta"]["total_sessions"]
    new_data["_tools"][TOOL_NAME]["messages"] = new_data["_meta"]["total_messages"]
    return new_data

def load_archive_log():
    """加载归档日志（统一函数）"""
    if os.path.exists(ARCHIVE_LOG):
        try:
            with open(ARCHIVE_LOG, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return migrate_old_format(data)
        except:
            pass
    return get_default_log_structure()

def save_archive_log(log_data):
    """保存归档日志（统一函数）"""
    # 重建汇总统计
    tools = log_data.get("_meta", {}).get("tools", [])
    total_sessions = sum(len(log_data.get(tool, {})) for tool in tools)
    total_messages = sum(
        sum(info.get("last_line_count", 0) for info in log_data.get(tool, {}).values())
        for tool in tools
    )
    log_data["_meta"]["total_sessions"] = total_sessions
    log_data["_meta"]["total_messages"] = total_messages
    
    # 更新各工具统计
    for tool in tools:
        if tool in log_data and tool not in log_data.get("_tools", {}):
            log_data["_tools"][tool] = {"sessions": 0, "messages": 0, "last_run": None}
        if tool in log_data:
            log_data["_tools"][tool]["sessions"] = len(log_data[tool])
            log_data["_tools"][tool]["messages"] = sum(
                info.get("last_line_count", 0) for info in log_data[tool].values()
            )
    
    try:
        with open(ARCHIVE_LOG, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"[错误] 保存archive_log失败: {e}")

def register_tool(tool_name):
    """注册工具到日志"""
    log = load_archive_log()
    if tool_name not in log["_meta"]["tools"]:
        log["_meta"]["tools"].append(tool_name)
    if tool_name not in log:
        log[tool_name] = {}
    if tool_name not in log["_tools"]:
        log["_tools"][tool_name] = {"sessions": 0, "messages": 0, "last_run": None}
    save_archive_log(log)

def is_session_processed(session_id):
    """检查任意工具是否已处理过此会话，返回(True, tool_name)或(False, None)"""
    log = load_archive_log()
    for tool in log["_meta"]["tools"]:
        if session_id in log.get(tool, {}):
            return True, tool
    return False, None

def update_tool_stats(session_id, info):
    """更新工具统计并写入记录"""
    log = load_archive_log()
    if TOOL_NAME not in log:
        log[TOOL_NAME] = {}
    log[TOOL_NAME][session_id] = {
        **info,
        "archived_at": datetime.now().isoformat()
    }
    log["_tools"][TOOL_NAME]["last_run"] = datetime.now().isoformat()
    save_archive_log(log)

# 兼容旧代码的别名
def load_log():
    return load_archive_log()

def save_log(data):
    save_archive_log(data)

def update_start_log():
    """更新l0_timestamp_log.json中的启动计数"""
    try:
        if os.path.exists(TIMESTAMP_LOG):
            with open(TIMESTAMP_LOG, 'r') as f:
                ts_data = json.load(f)
        else:
            ts_data = {}
        
        if '_l0_start' not in ts_data:
            ts_data['_l0_start'] = {'count': 0, 'last_start': None}
        
        ts_data['_l0_start']['count'] = ts_data['_l0_start'].get('count', 0) + 1
        ts_data['_l0_start']['last_start'] = datetime.now().isoformat()
        
        with open(TIMESTAMP_LOG, 'w') as f:
            json.dump(ts_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"[警告] 更新启动记录失败: {e}")

# ==================== 消息解析 ====================
def parse_message(data):
    """提取消息内容，只处理user和assistant"""
    try:
        if data.get('type') == 'message':
            msg_data = data.get('message', {})
            role = msg_data.get('role', '')
            if role not in ['user', 'assistant']:
                return None
            
            # content可能是字符串或列表
            content = msg_data.get('content', '')
            if isinstance(content, list):
                # 列表格式：[{'type': 'text', 'text': 'xxx'}]
                text = ''
                for item in content:
                    if isinstance(item, dict) and item.get('type') == 'text':
                        text += item.get('text', '')
            else:
                text = content
            
            if not text or text.startswith('[TOOL_CALL]'):
                return None
            
            ts = data.get('timestamp', '')
            try:
                if ts:
                    dt = datetime.fromisoformat(ts.replace('Z', '+00:00'))
                    ts_str = dt.strftime('%H:%M')
                else:
                    ts_str = ''
            except:
                ts_str = ''
            return f"[{ts_str} {role}] {text[:100]}"
        
        elif data.get('type') == 'human':
            text = data.get('text', '')
            if text:
                return f"[USER] {text[:100]}"
        
        elif data.get('type') == 'ai':
            text = data.get('text', '')
            if text:
                return f"[ASSISTANT] {text[:100]}"
    except:
        pass
    return None

def read_session_lines(path, start=0):
    """读取session文件的行，从start开始"""
    messages = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for i, line in enumerate(f):
                if i < start:
                    continue
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    msg = parse_message(data)
                    if msg:
                        messages.append(msg)
                except:
                    continue
    except Exception as e:
        log(f"[错误] 读取session失败: {e}")
    return messages

# ==================== L0写入（合并逻辑）====================
def write_l0(session_id, agent_id, messages, existing_path=None):
    """写入L0文件（合并追加逻辑）
    
    多文件合并追加：
    - L0_watcher_001.md 满了 -> L0_watcher_002.md
    - 每个文件只写一次header，后续追加内容
    """
    if not messages:
        return existing_path, 0
    
    # 找到当前可写文件
    agent_dir = os.path.join(L0_RAW, agent_id)
    os.makedirs(agent_dir, exist_ok=True)
    
    current_path, current_seq = find_next_l0_file('watcher', agent_dir)
    files_written = []
    message_count = 0
    header_written = {}  # 记录每个文件是否已写header
    
    def write_to_file(path, msg_list, seq):
        """追加写入消息到文件"""
        header_exists = header_written.get(seq, False)
        with open(path, 'a', encoding='utf-8') as f:
            if not header_exists:
                first_ts = datetime.now()
                f.write(f"# 会话存档：{first_ts.strftime('%Y-%m-%d %H:%M')}\n")
                f.write(f"- 来源: l0_watcher\n")
                f.write(f"- Agent: {agent_id}\n")
                f.write(f"- 起始序号: {seq}\n\n---\n\n")
                header_written[seq] = True
            for msg in msg_list:
                f.write(msg + "\n\n")
        return len(msg_list)
    
    # 处理每条消息
    for msg in messages:
        msg_bytes = (msg + "\n\n").encode('utf-8')
        msg_size = len(msg_bytes)
        
        # 检查当前文件是否满阀值
        if os.path.exists(current_path):
            current_size = os.path.getsize(current_path)
        else:
            current_size = 0
        
        if current_size + msg_size > L0_SIZE_LIMIT:
            # 切换到下一个文件
            files_written.append((current_path, current_seq))
            current_seq += 1
            current_path = get_l0_import_path('watcher', current_seq, agent_dir)
            header_written[current_seq] = False
        
        # 写入消息
        current_size += write_to_file(current_path, [msg], current_seq)
        message_count += 1
    
    # 记录写入的文件
    for path, seq in files_written:
        update_tool_stats(session_id, {
            'archived_path': os.path.basename(path),
            'last_line_count': message_count,
            'source': 'l0_watcher',
            'parts': len(files_written)
        })
    
    return current_path, message_count


def check_and_trigger_l123(file_path):
    """检查文件大小，满4MB则触发L123"""
    if not os.path.exists(file_path):
        return False
    size = os.path.getsize(file_path)
    if size > L0_SIZE_LIMIT:
        log(f"[L0-触发] 文件满{L0_SIZE_LIMIT//1024//1024}MB ({size//1024//1024}MB)，触发L123")
        l123_script = os.path.join(SCRIPT_DIR, "l123_extractor.py")
        if os.path.exists(l123_script):
            try:
                result = subprocess.run(
                    ['python3', l123_script, '--file', file_path],
                    capture_output=True, text=True, timeout=60
                )
                if result.returncode == 0:
                    log(f"[L0-触发] L123处理完成")
                else:
                    log(f"[L0-触发] L123失败: {result.stderr}")
            except Exception as e:
                log(f"[错误] 调用L123失败: {e}")
        return True
    return False

# ==================== 心跳模式 ====================
def heartbeat_mode():
    log("[L0-心跳] 开始...")
    
    # 注册工具（首次运行）
    register_tool(TOOL_NAME)
    
    agents = get_all_agent_sessions()
    new_count = 0
    total_written = 0
    
    for agent in agents:
        agent_id = agent['id']
        sessions_dir = agent['sessions_dir']
        
        if not os.path.exists(sessions_dir):
            log(f"[L0-心跳] 目录不存在: {sessions_dir}")
            continue
        
        try:
            files = os.listdir(sessions_dir)
        except Exception as e:
            log(f"[错误] 扫描目录失败: {sessions_dir}")
            continue
        
        for filename in files:
            # 跳过非jsonl、临时文件、轨迹文件
            if not filename.endswith('.jsonl') or '.lock' in filename or '.checkpoint' in filename or '.trajectory' in filename:
                continue
            
            session_id = os.path.splitext(filename)[0].replace('.trajectory', '')
            jsonl_path = os.path.join(sessions_dir, filename)
            
            # 检查是否已被任意工具处理过
            processed, tool = is_session_processed(session_id)
            if processed:
                # 获取当前工具的记录信息
                log_data = load_archive_log()
                state = log_data.get(TOOL_NAME, {}).get(session_id, {})
            else:
                state = {}
            
            last_line = state.get('last_line_count', 0)
            
            # 读取增量
            messages = read_session_lines(jsonl_path, start=last_line)
            
            if not messages:
                continue
            
            # 写入L0
            existing_path = state.get('archived_path')
            file_path, lines_written = write_l0(session_id, agent_id, messages, existing_path)
            
            if lines_written > 0:
                # 更新记录（使用统一函数）
                new_last_line = last_line + lines_written
                update_tool_stats(session_id, {
                    'archived_path': file_path,
                    'last_line_count': new_last_line,
                    'source': 'active_session'
                })
                
                log(f"[L0-写入] {session_id[:16]}... +{lines_written}行 -> {os.path.basename(file_path)}")
                
                # 检查是否满4MB，满则触发L123
                check_and_trigger_l123(file_path)
                
                new_count += 1
                total_written += lines_written
    
    log(f"[L0-心跳] 完成！新增会话:{new_count}，写入:{total_written}行")
    return new_count

def main():
    log("=" * 50)
    log("[1368系统] L0 Watcher")
    log(f"存档目录: {L0_RAW}")
    log(f"触发阈值: {L0_SIZE_LIMIT//1024//1024}MB")
    log("=" * 50)
    
    # 更新启动计数并记录到timestamp_log
    update_start_log()
    
    # 读取当前计数用于显示
    try:
        with open(TIMESTAMP_LOG, 'r') as f:
            ts_data = json.load(f)
        current_count = ts_data.get('_l0_start', {}).get('count', 0)
    except:
        current_count = 0
    
    log(f"[L0-启动] 第{current_count}次")
    
    heartbeat_mode()
    
    log("[L0-完成] 进程退出")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--heartbeat', action='store_true')
    args = parser.parse_args()
    
    if args.heartbeat:
        main()
    else:
        print("用法: python3 l0_watcher.py --heartbeat")