#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神系统 - 健康检查脚本
===================================
检查系统各组件运行状态和参数

检查项：
- L0 写入状态
- L1/L2/L3 状态
- 索引状态
- API 状态
"""

import os
import sys
import json
import subprocess
from datetime import datetime, timedelta
import time

# 路径配置
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPT_DIR = os.path.join(SKILL_DIR, 'scripts')
sys.path.insert(0, SCRIPT_DIR)

try:
    from paths_config import (
        WORKSPACE, MEMORY_1368, L0_RAW, L1_DECISION, L2_SCENE, L3_PROFILE,
        INDEXES, L0_SIZE_LIMIT, L1_SIZE_LIMIT, OPENAI_API_KEY, EMBEDDING_BACKEND
    )
except ImportError:
    WORKSPACE = "/root/.openclaw/workspace/main"
    MEMORY_1368 = os.path.join(WORKSPACE, "memory", "1368-memory")
    L0_RAW = os.path.join(MEMORY_1368, "L0_raw")
    L1_DECISION = os.path.join(MEMORY_1368, "L1_decision")
    L2_SCENE = os.path.join(MEMORY_1368, "L2_scene")
    L3_PROFILE = os.path.join(MEMORY_1368, "L3_profile")
    SKILL_DIR = os.path.join(WORKSPACE, "skills", "1368-memory-system")
    INDEXES = os.path.join(SKILL_DIR, "indexes")
    L0_SIZE_LIMIT = 2 * 1024 * 1024
    L1_SIZE_LIMIT = 200 * 1024
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
    EMBEDDING_BACKEND = "minimax"

# 日志文件
LOG_DIR = os.path.join(SKILL_DIR, 'logs')
RUN_LOG_FILE = os.path.join(LOG_DIR, "l0_session_log.json")
ARCHIVE_LOG = os.path.join(L0_RAW, "l0_archive_log.json")
GAP_LOG = os.path.join(L0_RAW, "l0_timestamp_log.json")

def format_size(size):
    """格式化文件大小"""
    if size < 1024:
        return f"{size}B"
    elif size < 1024 * 1024:
        return f"{size//1024}KB"
    else:
        return f"{size//1024//1024}MB"

# ==================== 检查函数 ====================

def check_session_extraction():
    """检查会话提取状态"""
    if not os.path.exists(RUN_LOG_FILE):
        return "WARNING", "无运行日志", {}
    
    try:
        with open(RUN_LOG_FILE, 'r', encoding='utf-8') as f:
            log_data = json.load(f)
        
        total_sessions = len(log_data)
        
        # 统计最近1小时的更新
        now = datetime.now()
        recent_1h = 0
        recent_24h = 0
        
        for session_id, data in log_data.items():
            last_update = data.get('last_update')
            if last_update:
                try:
                    update_time = datetime.fromisoformat(last_update)
                    diff = (now - update_time).total_seconds()
                    if diff < 3600:  # 1小时
                        recent_1h += 1
                    if diff < 86400:  # 24小时
                        recent_24h += 1
                except:
                    pass
        
        # 统计各操作类型
        actions = {'created': 0, 'recorded': 0, 'append': 0, 'backfilled': 0}
        for session_id, data in log_data.items():
            last_action = data.get('last_action')
            if last_action in actions:
                actions[last_action] += 1
        
        detail = f"总会话: {total_sessions} | 1h内: {recent_1h} | 24h内: {recent_24h}"
        return "OK", detail, {
            "total": total_sessions,
            "recent_1h": recent_1h,
            "recent_24h": recent_24h,
            "actions": actions
        }
    except Exception as e:
        return "ERROR", f"读取失败: {e}", {}

def check_l0_write_status():
    """检查 L0 写入状态"""
    if not os.path.exists(L0_RAW):
        return "ERROR", "L0目录不存在", {}
    
    try:
        # 统计各智能体目录
        agents = ["main", "xiaodai", "xiaodang", "xiaogu", "xiaofa", "vice-manager"]
        stats = {}
        total_files = 0
        total_size = 0
        
        for agent in agents:
            agent_dir = os.path.join(L0_RAW, agent)
            if os.path.exists(agent_dir):
                files = [f for f in os.listdir(agent_dir) if f.endswith('.md')]
                sizes = [os.path.getsize(os.path.join(agent_dir, f)) for f in files]
                stats[agent] = {
                    "files": len(files),
                    "size": sum(sizes),
                    "avg_size": sum(sizes) // len(sizes) if sizes else 0
                }
                total_files += len(files)
                total_size += sum(sizes)
        
        # 检查是否有大文件
        large_files = 0
        for agent, s in stats.items():
            if s['avg_size'] > L0_SIZE_LIMIT:
                large_files += 1
        
        detail = f"总文件: {total_files} | 总大小: {format_size(total_size)}"
        if large_files > 0:
            return "WARNING", f"{detail} | {large_files}个目录接近限制", stats
        
        return "OK", detail, stats
    except Exception as e:
        return "ERROR", f"检查失败: {e}", {}

def check_l123_status():
    """检查 L1/L2/L3 状态"""
    results = {}
    all_ok = True
    
    for name, path in [("L1决策", L1_DECISION), ("L2场景", L2_SCENE), ("L3画像", L3_PROFILE)]:
        if not os.path.exists(path):
            results[name] = ("ERROR", "目录不存在", 0, 0)
            all_ok = False
            continue
        
        try:
            # 递归统计所有.md文件
            md_files = []
            total_size = 0
            for root, dirs, files in os.walk(path):
                for f in files:
                    if f.endswith('.md'):
                        full_path = os.path.join(root, f)
                        md_files.append(f)
                        total_size += os.path.getsize(full_path)
            
            avg_size = total_size // len(md_files) if md_files else 0
            results[name] = ("OK", f"{len(md_files)}个 | {format_size(total_size)}", len(md_files), avg_size)
        except Exception as e:
            results[name] = ("ERROR", str(e)[:20], 0, 0)
            all_ok = False
    
    # 汇总
    detail = " | ".join([f"{k}: {v[1]}" for k, v in results.items()])
    status = "OK" if all_ok else "WARNING"
    return status, detail, results

def check_index_status():
    """检查索引状态"""
    if not os.path.exists(INDEXES):
        return "WARNING", "索引目录不存在", {}
    
    try:
        files = [f for f in os.listdir(INDEXES) if f.endswith('.faiss')]
        
        if not files:
            return "ERROR", "无索引文件", {"count": 0}
        
        stats = {}
        total_size = 0
        for f in files:
            path = os.path.join(INDEXES, f)
            size = os.path.getsize(path)
            stats[f] = size
            total_size += size
        
        # 检查是否有对应的meta文件
        meta_files = [f for f in os.listdir(INDEXES) if f.endswith('.json')]
        
        return "OK", f"{len(files)}个索引 | {format_size(total_size)}", {
            "count": len(files),
            "total_size": total_size,
            "files": stats
        }
    except Exception as e:
        return "ERROR", f"检查失败: {e}", {}

def check_api_status():
    """检查 API 状态"""
    # 从.env加载配置
    env_file = os.path.join(SKILL_DIR, 'configs', '.env')
    api_key = OPENAI_API_KEY
    backend = EMBEDDING_BACKEND
    
    if os.path.exists(env_file):
        with open(env_file, 'r') as f:
            for line in f:
                if line.strip().startswith('OPENAI_API_KEY='):
                    api_key = line.strip().split('=', 1)[1]
                if line.strip().startswith('EMBEDDING_MODEL='):
                    model = line.strip().split('=', 1)[1]
    
    # 测试API连接
    api_ok = False
    latency_ms = None
    
    if api_key and backend == "minimax":
        try:
            import requests
            start = time.time()
            response = requests.post(
                "https://api.minimax.chat/v1/embeddings",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "texts": ["test"],
                    "model": "embo-01",
                    "type": "db"
                },
                timeout=10
            )
            latency_ms = int((time.time() - start) * 1000)
            
            if response.status_code == 200:
                result = response.json()
                if result.get("vectors"):
                    api_ok = True
        except Exception as e:
            return "ERROR", f"API错误: {str(e)[:30]}", {"key_prefix": api_key[:15] if api_key else None}
    
    if api_ok:
        return "OK", f"正常 | 延迟: {latency_ms}ms | 后端: {backend}", {
            "backend": backend,
            "key_prefix": api_key[:15] if api_key else None,
            "latency_ms": latency_ms
        }
    else:
        return "WARNING", f"后端: {backend} | Key: {api_key[:15] if api_key else '未设置'}...", {
            "backend": backend,
            "key_prefix": api_key[:15] if api_key else None
        }

# ==================== 主函数 ====================

def main():
    """健康检查主函数"""
    # 获取OpenClaw进程信息
    openclaw_info = ""
    try:
        result = subprocess.run(["ps", "aux"], capture_output=True, text=True)
        lines = [l for l in result.stdout.split('\n') if 'openclaw' in l.lower() and 'grep' not in l]
        if lines:
            total_cpu = sum(float(l.split()[2]) for l in lines if len(l.split()) >= 3)
            total_mem = sum(float(l.split()[3]) for l in lines if len(l.split()) >= 4)
            openclaw_info = f" | OpenClaw: {len(lines)}进程, CPU:{total_cpu:.1f}%, 内存:{total_mem:.1f}%"
    except:
        pass
    
    print("=" * 60)
    print("  1368元神系统 - 健康检查" + openclaw_info)
    print("=" * 60)
    print(f"检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"系统目录: {MEMORY_1368}")
    print()
    
    # 执行各项检查
    checks = {
        "🟠 OpenClaw进程": check_openclaw_processes,
        
        "📝 会话提取": check_session_extraction,
        "💾 L0 写入": check_l0_write_status,
        "📊 L1/L2/L3": check_l123_status,
        "🔍 索引状态": check_index_status,
        "🌐 API 状态": check_api_status,
    }
    
    results = {}
    for name, func in checks.items():
        status, detail, extra = func()
        results[name] = (status, detail, extra)
    
    # 打印结果表格
    print("-" * 60)
    print(f"{'检查项':<20} {'状态':<8} {'详情'}")
    print("-" * 60)
    for name, (status, detail, extra) in results.items():
        icon = {"OK": "✅", "WARNING": "⚠️", "ERROR": "❌"}.get(status, "?")
        status_text = {"OK": "✅ 好的", "WARNING": "⚠️ 注意", "ERROR": "❌ 错误"}.get(status, status)
        # 清理name中的emoji
        clean_name = name.replace("🟠 ", "").replace("🔴 ", "").replace("📝 ", "").replace("💾 ", "").replace("📊 ", "").replace("🔍 ", "").replace("🌐 ", "")
        print(f"{clean_name:<20} {status_text:<8} {detail}")
    
    # OpenClaw进程列表
    if "🟠 OpenClaw进程" in results:
        _, _, extra = results["🟠 OpenClaw进程"]
        if extra.get("processes"):
            print()
            print("OpenClaw执行的任务进程列表：")
            print("-" * 60)
            for proc in extra["processes"]:
                print(f"  {proc}")
    
    # 汇总
    has_error = any(r[0] == "ERROR" for r in results.values())
    has_warning = any(r[0] == "WARNING" for r in results.values())
    
    print("-" * 60)
    if has_error:
        print("❌ 系统异常，请检查上述问题")
        sys.exit(1)
    elif has_warning:
        print("⚠️ 系统需要注意")
        sys.exit(0)
    else:
        print("✅ 系统正常")
        sys.exit(0)



def check_openclaw_processes():
    """检查所有OpenClaw任务进程列表"""
    try:
        result = subprocess.run(["ps", "aux"], capture_output=True, text=True)
        lines = [l for l in result.stdout.split('\n') if 'openclaw' in l.lower() and 'grep' not in l]
        
        if not lines:
            return "WARNING", "未找到OpenClaw进程", {}
        
        total_cpu = 0
        total_mem = 0
        process_list = []
        
        for line in lines:
            parts = line.split()
            if len(parts) >= 11:
                try:
                    pid = parts[1]
                    cpu = float(parts[2])
                    mem = float(parts[3])
                    cmd_parts = parts[10:]
                    cmd = ' '.join(cmd_parts)[:60] if cmd_parts else parts[-1][:60]
                    total_cpu += cpu
                    total_mem += mem
                    process_list.append(f"{pid}  CPU:{cpu:4.1f}%  MEM:{mem:4.1f}%  {cmd}")
                except:
                    pass
        
        detail = f"共{len(lines)}个进程 | CPU:{total_cpu:.1f}% | 内存:{total_mem:.1f}%"
        
        return "OK", detail, {
            "count": len(lines),
            "cpu": total_cpu,
            "mem": total_mem,
            "processes": process_list
        }
    except Exception as e:
        return "ERROR", f"检查失败: {e}", {}

if __name__ == "__main__":
    main()