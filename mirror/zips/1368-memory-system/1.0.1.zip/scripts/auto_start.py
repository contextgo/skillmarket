#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神记忆系统 - 自动启动脚本
===================================
在 OpenClaw 启动时自动拉起 L0 Watcher

调用位置：AGENTS.md bootstrap
调用方式：openclaw 会话启动时自动执行 bootstrapTotalMaxChars 范围内的脚本

功能：
1. 检查 L0 Watcher 是否运行
2. 如果未运行，自动启动
3. 检查状态一致性，执行必要恢复
"""

import os
import sys
import json
import subprocess
from datetime import datetime

# 路径配置
SKILL_DIR = "/root/.openclaw/workspace/main/skills/1368元神记忆系统"
SCRIPT_DIR = os.path.join(SKILL_DIR, "scripts")
LOG_DIR = os.path.join(SKILL_DIR, "logs")
WATCHER_SCRIPT = os.path.join(SCRIPT_DIR, "l0_watcher.py")
WATCHER_LOG = os.path.join(LOG_DIR, "l0_watcher.log")
STATUS_FILE = os.path.join(LOG_DIR, "l0_watcher_status.json")
GAP_LOG = os.path.join(LOG_DIR, "l0_gap_recovery.json")

def log(msg):
    """输出日志"""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[auto_start.py] {ts} {msg}")

def is_watcher_running():
    """检查 Watcher 是否运行"""
    try:
        result = subprocess.run(
            ["pgrep", "-f", "python3.*l0_watcher"],
            capture_output=True,
            text=True
        )
        # 过滤掉 grep 自身
        pids = [p for p in result.stdout.strip().split('\n') if p and 'grep' not in p]
        return len(pids) > 0
    except:
        return False

def load_status():
    """加载状态文件"""
    if os.path.exists(STATUS_FILE):
        try:
            with open(STATUS_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {"running": False}

def start_watcher():
    """启动 L0 Watcher"""
    log("启动 L0 Watcher...")
    try:
        subprocess.Popen(
            ["nohup", "python3", WATCHER_SCRIPT, ">>", WATCHER_LOG, "2>&1", "&"],
            start_new_session=True
        )
        log("L0 Watcher 启动命令已执行")
        return True
    except Exception as e:
        log(f"启动失败: {e}")
        return False

def main():
    log("=" * 50)
    log("1368元神记忆系统自启动检查")
    log("=" * 50)

    # 1. 检查 Watcher 是否运行
    if is_watcher_running():
        log("L0 Watcher 已在运行中")
        status = load_status()
        if not status.get('running'):
            log("⚠️ 状态文件显示未运行，但进程存在")
    else:
        log("L0 Watcher 未运行，准备启动...")
        start_watcher()

    # 2. 检查状态文件一致性
    status = load_status()
    if status.get('running') and status.get('last_stop'):
        last_stop = status.get('last_stop')
        log(f"⚠️ 检测到异常中断状态 (last_stop: {last_stop})")
        log("⚠️ Gap Recovery 仅手工操作，如需恢复请手动调用")

    log("自启动检查完成")

if __name__ == "__main__":
    main()