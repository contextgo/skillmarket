#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神记忆系统 — 安装向导
=====================================
检测系统环境，提示用户安装所需依赖

使用方式：
    python3 scripts/install_wizard.py
"""

import os
import sys
import subprocess
import re

def print_banner():
    print("=" * 60)
    print("  1368元神记忆系统 — 安装向导")
    print("=" * 60)
    print("")

def print_section(title):
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print("=" * 60)

def check_python():
    """检查 Python 版本"""
    try:
        result = subprocess.run(['python3', '--version'], capture_output=True, text=True)
        version = result.stdout.strip()
        match = re.search(r'Python (\d+)\.(\d+)\.(\d+)', version)
        if match:
            major, minor, _ = int(match.group(1)), int(match.group(2)), int(match.group(3))
            if major >= 3 and minor >= 8:
                return True, version
        return False, f"{version} (需要 Python 3.8+)"
    except Exception as e:
        return False, f"未找到 Python: {e}"

def check_library(name, import_name=None):
    """检查库是否已安装"""
    if import_name is None:
        import_name = name.lower().replace('-', '')
    try:
        __import__(import_name)
        return True, "已安装"
    except ImportError:
        return False, "未安装"

def check_command(name):
    """检查命令是否可用"""
    try:
        result = subprocess.run(['which', name], capture_output=True, text=True)
        if result.returncode == 0:
            path = result.stdout.strip()
            return True, path
        return False, "未找到"
    except:
        return False, "未找到"

def install_package(package, version=None, description=""):
    """安装包（固定版本）"""
    print(f"\n  正在安装 {package}...")
    try:
        pkg = f"{package}=={version}" if version else package
        result = subprocess.run(
            ['pip3', 'install', pkg],
            capture_output=True,
            text=True,
            timeout=120
        )
        if result.returncode == 0:
            print(f"  ✅ {package} 安装成功")
            return True
        else:
            print(f"  ❌ 安装失败: {result.stderr[:200]}")
            return False
    except subprocess.TimeoutExpired:
        print(f"  ❌ 安装超时（120秒）")
        return False
    except Exception as e:
        print(f"  ❌ 安装异常: {e}")
        return False

def main():
    print_banner()
    
    print("欢迎使用1368元神记忆系统安装向导！")
    print("本向导将检测系统环境并引导您安装所需依赖。")
    print("")
    
    # ========== 第一步：环境检测 ==========
    print_section("第一步：环境检测")
    
    print("\n  检测系统环境，请稍候...")
    print("")
    
    checks = []
    
    # Python 版本
    ok, msg = check_python()
    checks.append(("Python 3.8+", ok, msg))
    
    # 核心依赖库
    libs = [
        ("watchdog", "watchdog", "文件监听"),
        ("python-docx", "docx", "生成WORD文档"),
        ("embed-model", "openai", "向量搜索支持"),
    ]
    
    for name, import_name, desc in libs:
        ok, msg = check_library(name, import_name)
        checks.append((f"{name} ({desc})", ok, msg))
    
    # 磁盘空间
    try:
        result = subprocess.run(['df', '-h', '/root/.openclaw/'], capture_output=True, text=True)
        line = result.stdout.strip().split('\n')[-1]
        available = line.split()[3]
        ok = True
        checks.append(("磁盘空间 (>500MB)", ok, f"剩余 {available}"))
    except:
        checks.append(("磁盘空间 (>500MB)", False, "检测失败"))
    
    # 显示检测结果
    print("  ┌─ 检测结果")
    print("  │")
    for name, ok, msg in checks:
        status = "✅" if ok else "❌"
        print(f"  │{status} {name}: {msg}")
    print("  │")
    print("  └─")
    
    # 统计未安装的
    missing = [name for name, ok, _ in checks if not ok]
    
    if not missing:
        print("\n  ✅ 所有环境检测通过，无需安装！")
    else:
        print(f"\n  ⚠️  发现 {len(missing)} 个未安装/不满足的组件：")
        for name in missing:
            print(f"     - {name}")
    
    # ========== 第二步：选择安装 ==========
    print_section("第二步：选择安装")
    
    print("\n  请选择要安装的组件：")
    print("")
    
    # 重新列出需要安装的组件
    install_options = []
    for name, ok, msg in checks:
        if not ok:
            install_options.append(name)
    
    if not install_options:
        print("  所有组件已安装，无需选择。")
    else:
        print("  可选组件：")
        for i, name in enumerate(install_options, 1):
            desc = ""
            if "watchdog" in name:
                desc = "（文件监听，L0 Watcher 必需）"
            elif "python-docx" in name:
                desc = "（生成WORD文档）"
            elif "embed-model" in name:
                desc = "（向量搜索支持）"
            elif "Python" in name:
                desc = "（系统必需）"
            print(f"    [{i}] {name} {desc}")
        
        print(f"    [0] 全部安装")
        print(f"    [-1] 跳过（稍后手动安装）")
        
        print("")
        choices = input("  请输入要安装的编号（用逗号分隔，如 1,2 或 0 全部）: ").strip()
        
        selected = []
        if choices == "0":
            selected = install_options
        elif choices == "-1":
            print("\n  ⚠️  已跳过安装，部分功能可能不可用。")
            print("  ℹ  手动安装命令：pip3 install <包名>")
        else:
            try:
                indices = [int(c.strip()) for c in choices.split(',')]
                selected = [install_options[i-1] for i in indices if 0 < i <= len(install_options)]
            except:
                print("  ❌ 无效输入")
                selected = []
        
        # ========== 第三步：执行安装 ==========
        if selected:
            print_section("第三步：执行安装")
            
            package_map = {
                "watchdog": ("watchdog", "4.0.0"),
                "python-docx": ("python-docx", "1.1.2"),
                "embed-model": ("openai", "1.30.0"),  # 向量搜索支持
                "Python 3.8+": None,  # 需要手动安装
            }
            
            install_results = []
            for name in selected:
                pkg_info = package_map.get(name.split(' (')[0], name)
                if pkg_info:
                    pkg, ver = pkg_info if isinstance(pkg_info, tuple) else (pkg_info, None)
                    ok = install_package(pkg, ver)
                    install_results.append((name, ok))
                else:
                    print(f"\n  ℹ  {name} 需要手动安装系统包")
                    install_results.append((name, False))
            
            # 显示安装结果
            print("\n  ┌─ 安装结果")
            for name, ok in install_results:
                status = "✅" if ok else "❌"
                print(f"  │{status} {name}")
            print("  │")
            print("  └─")
    
    # ========== 第四步：验证 ==========
    print_section("第四步：验证安装")
    
    print("\n  正在验证安装结果...")
    
    all_ok = True
    for name, was_ok, msg in checks:
        if was_ok:
            continue
        # 重新检查
        for lib_name, import_name, _ in libs:
            if lib_name in name:
                ok, _ = check_library(lib_name, import_name)
                if ok:
                    print(f"  ✅ {lib_name}: 验证通过")
                else:
                    print(f"  ❌ {lib_name}: 仍然未安装")
                    all_ok = False
                break
    
    # ========== 完成 ==========
    print("\n" + "=" * 60)
    if all_ok:
        print("  ✅ 安装完成！所有组件已就绪。")
    else:
        print("  ⚠️  安装完成，但部分组件未安装成功。")
        print("  ℹ  可稍后运行 pip3 install <包名> 手动安装。")
    print("=" * 60)
    
    # 显示配置状态
    print("\n" + "=" * 60)
    print("  📋 配置状态")
    print("=" * 60)
    
    config_path = os.path.join(os.path.dirname(__file__), "..", "configs", "1368_config.json")
    if os.path.exists(config_path):
        import json
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        print("\n  当前配置：")
        print(f"    L0 阈值: {config.get('L0_SIZE_LIMIT', '2mb')}")
        print(f"    L1/L2/L3 阈值: {config.get('L123_SIZE_LIMIT', '200kb')}")
        print(f"    向量搜索后端: {config.get('EMBEDDING_BACKEND', 'minimax')}")
        print(f"    自启动: {config.get('AUTO_START', 'enable')}")
        print(f"    历史数据回溯: {config.get('MIGRATE_HISTORY', 'none')}")
    else:
        print("\n  ⚠️  尚未配置")
        print("\n  可用配置选项：")
        print("    L0 阈值: 1MB / 2MB / 4MB")
        print("    L1/L2/L3 阈值: 100KB / 200KB / 500KB")
        print("    向量搜索后端: MiniMAX API / Ollama / 其他AI API")
        print("    自启动: 启用 / 禁用")
        print("    历史数据回溯: 全部 / 30天内 / 暂不回溯")
    
    print("\n" + "=" * 60)
    print("  ✅ 安装完成！")
    print("=" * 60)
    
    print("""
    
    ╔═══════════════════════════════════════════════════════════╗
    ║                                                           ║
    ║   🎉 安装完成！请进入1368元神系统配置流程                  ║
    ║                                                           ║
    ║   下一步：python3 scripts/config_wizard.py                ║
    ║                                                           ║
    ╚═══════════════════════════════════════════════════════════╝
    """)
    
    sys.exit(0)

if __name__ == "__main__":
    main()
