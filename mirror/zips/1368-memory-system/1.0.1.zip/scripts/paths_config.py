"""
1368元神系统 - 路径配置
================================
1元3维6层8面体元神系统

自动从 openclaw.json 读取 workspace 配置
"""

import os
import json

# 默认路径
DEFAULT_WORKSPACE = "/root/.openclaw/workspace/main"
DEFAULT_SESSIONS = "/root/.openclaw/agents/main/sessions"

# 智能体会话目录映射
AGENTS_SESSIONS = {
    'main': '/root/.openclaw/agents/main/sessions',
    'xiaodai': '/root/.openclaw/agents/xiaodai/sessions',
    'xiaodang': '/root/.openclaw/agents/xiaodang/sessions',
    'xiaogu': '/root/.openclaw/agents/xiaogu/sessions',
    'xiaofa': '/root/.openclaw/agents/xiaofa/sessions',
    'vice-manager': '/root/.openclaw/agents/vice-manager/sessions',
}

# ==================== 1368系统配置 ====================

def parse_size_limit(size_str):
    """解析大小限制字符串，如 '2mb' -> 2097152"""
    if isinstance(size_str, int):
        return size_str
    size_str = str(size_str).lower().strip()
    if size_str.endswith('mb'):
        return int(float(size_str[:-2]) * 1024 * 1024)
    elif size_str.endswith('kb'):
        return int(float(size_str[:-2]) * 1024)
    elif size_str.endswith('b'):
        return int(size_str[:-1])
    return int(size_str)

# 加载配置文件
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_FILE = os.path.join(SKILL_DIR, 'configs', '1368_config.json')
_config = {}
if os.path.exists(CONFIG_FILE):
    try:
        with open(CONFIG_FILE, 'r') as f:
            _config = json.load(f)
    except:
        pass

# 文件大小限制（从配置文件读取）
L0_SIZE_LIMIT = parse_size_limit(_config.get('L0_SIZE_LIMIT', '4mb'))
L1_SIZE_LIMIT = parse_size_limit(_config.get('L1_SIZE_LIMIT', '1mb'))
L2_SIZE_LIMIT = parse_size_limit(_config.get('L2_SIZE_LIMIT', '1mb'))
L3_SIZE_LIMIT = parse_size_limit(_config.get('L3_SIZE_LIMIT', '1mb'))

# Embedding 配置
EMBEDDING_BACKEND = "minimax"
OLLAMA_URL = "http://127.0.0.1:11434"
EMBED_MODEL = "nomic-embed-text"

# 搜索模式配置
# - "memory": 使用 TencentDB memorySearch (消耗API token)
# - "faiss": 使用 1368 本地 FAISS 索引 (不消耗token)
# - "both": 两个都使用
SEARCH_MODE = _config.get('SEARCH_MODE', 'memory')

def find_openclaw_json():
    """查找 openclaw.json 位置"""
    paths = [
        "/root/.openclaw/openclaw.json",
        os.path.expanduser("~/.openclaw/openclaw.json"),
    ]
    for p in paths:
        if os.path.exists(p):
            return p
    return None

def get_workspace():
    """获取 workspace 路径 - 优先使用 main agent 的 workspace"""
    openclaw_path = find_openclaw_json()
    if openclaw_path:
        try:
            with open(openclaw_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                
                # 优先从 agents.list 中找 main agent
                agents_list = config.get('agents', {}).get('list', [])
                for agent in agents_list:
                    if agent.get('id') == 'main':
                        ws = agent.get('workspace')
                        if ws:
                            return os.path.expanduser(ws)
                
                # 回退到 defaults.workspace
                defaults = config.get('agents', {}).get('defaults', {})
                ws = defaults.get('workspace')
                if ws:
                    return os.path.expanduser(ws)
        except Exception as e:
            print(f"[WARN] 读取 openclaw.json 失败: {e}")
    return DEFAULT_WORKSPACE

def get_all_agent_sessions():
    """获取所有智能体的会话目录"""
    agents_config = {
        'main': '/root/.openclaw/agents/main/sessions',
        'xiaodai': '/root/.openclaw/agents/xiaodai/sessions',
        'xiaodang': '/root/.openclaw/agents/xiaodang/sessions',
        'xiaogu': '/root/.openclaw/agents/xiaogu/sessions',
        'xiaofa': '/root/.openclaw/agents/xiaofa/sessions',
        'vice-manager': '/root/.openclaw/agents/vice-manager/sessions',
    }
    result = []
    for agent_id, sessions_dir in agents_config.items():
        if os.path.exists(sessions_dir):
            result.append({'id': agent_id, 'sessions_dir': sessions_dir})
    return result if result else [{'id': 'main', 'sessions_dir': '/root/.openclaw/agents/main/sessions'}]

def get_agent_archive_dir(agent_id='main'):
    """获取指定智能体的存档目录"""
    return os.path.join(MEMORY_1368, agent_id)

def get_timestamp_log_path():
    """获取时间戳日志文件路径"""
    return os.path.join(L0_RAW, "l0_timestamp_log.json")

# ==================== 1368 目录结构 ====================

WORKSPACE = get_workspace()

# 1368元神系统根目录
MEMORY_1368 = os.path.join(WORKSPACE, "memory", "1368-memory")
os.makedirs(MEMORY_1368, exist_ok=True)

# 六层目录
L0_RAW = os.path.join(MEMORY_1368, "L0_raw")           # 一元：原始会话复刻
L1_DECISION = os.path.join(MEMORY_1368, "L1_decision") # 三维之一：决策提取
L2_SCENE = os.path.join(MEMORY_1368, "L2_scene")       # 三维之二：场景提取
L3_PROFILE = os.path.join(MEMORY_1368, "L3_profile")   # 三维之三：画像提取
SKILL_DIR = os.path.join(WORKSPACE, "skills", "1368-memory-system")
INDEXES = os.path.join(SKILL_DIR, "indexes")          # 六层：索引文件（放技能目录，避免被索引）

# 确保目录存在
for d in [L0_RAW, L1_DECISION, L2_SCENE, L3_PROFILE, INDEXES]:
    os.makedirs(d, exist_ok=True)

# ==================== 索引配置 ====================

# 向量索引配置
INDEX_CONFIG = {
    'L0': {
        'name': 'L0 原始会话索引',
        'sources': [L0_RAW],
        'index_file': os.path.join(INDEXES, 'L0_index.faiss'),
        'meta_file': os.path.join(INDEXES, 'L0_meta.json')
    },
    'L1': {
        'name': 'L1 决策索引',
        'sources': [L1_DECISION],
        'index_file': os.path.join(INDEXES, 'L1_index.faiss'),
        'meta_file': os.path.join(INDEXES, 'L1_meta.json')
    },
    'L2': {
        'name': 'L2 场景索引',
        'sources': [L2_SCENE],
        'index_file': os.path.join(INDEXES, 'L2_index.faiss'),
        'meta_file': os.path.join(INDEXES, 'L2_meta.json')
    },
    'L3': {
        'name': 'L3 画像索引',
        'sources': [L3_PROFILE],
        'index_file': os.path.join(INDEXES, 'L3_index.faiss'),
        'meta_file': os.path.join(INDEXES, 'L3_meta.json')
    },
    'memory': {
        'name': '综合记忆索引（L1/L2/L3）',
        'sources': [L1_DECISION, L2_SCENE, L3_PROFILE],
        'index_file': os.path.join(INDEXES, 'memory_index.faiss'),
        'meta_file': os.path.join(INDEXES, 'memory_meta.json')
    },
    'knowledge': {
        'name': '知识库索引',
        'sources': [
            os.path.join(WORKSPACE, "knowledge-repo"),
            os.path.join(WORKSPACE, "本盘knowledge-repo"),
        ],
        'index_file': os.path.join(INDEXES, 'knowledge_index.faiss'),
        'meta_file': os.path.join(INDEXES, 'knowledge_meta.json')
    }
}

# API 配置
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_API_BASE = os.environ.get("OPENAI_API_BASE", "https://api.minimax.chat/v1")
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "text-embedding-3-small")

print(f"[DEBUG] paths_config imported OK - 1368元神系统")
print(f"  WORKSPACE: {WORKSPACE}")
print(f"  MEMORY_1368: {MEMORY_1368}")
print(f"  L0_RAW: {L0_RAW}")
print(f"  L1_DECISION: {L1_DECISION}")
print(f"  L2_SCENE: {L2_SCENE}")
print(f"  L3_PROFILE: {L3_PROFILE}")
print(f"  INDEXES: {INDEXES}")
