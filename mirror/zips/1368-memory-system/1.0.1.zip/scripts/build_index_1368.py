#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神系统 - 向量索引构建
===================================
1元3维6层8面体元神系统的索引构建模块

索引层级：
- L0_index: L0 原始会话索引
- L1_index: L1 决策索引
- L2_index: L2 场景索引
- L3_index: L3 画像索引
- memory_index: L1/L2/L3 综合记忆索引
- knowledge_index: 知识库索引
"""

import os
import sys
import json
import faiss
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 加载.env配置文件
def load_env_file():
    """从configs/.env.local加载环境变量"""
    env_path = os.path.join(os.path.dirname(__file__), '..', 'configs', '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key.strip()] = value.strip()

load_env_file()

try:
    from paths_config import (
        WORKSPACE, MEMORY_1368, L0_RAW, L1_DECISION, L2_SCENE, L3_PROFILE,
        INDEXES, INDEX_CONFIG, EMBEDDING_BACKEND,
        OPENAI_API_KEY, OPENAI_API_BASE
    )
    # 使用embo-01作为MiniMAX的默认模型
    EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "embo-01")
except ImportError:
    print("[WARN] paths_config not found")
    WORKSPACE = "/root/.openclaw/workspace/main"
    MEMORY_1368 = os.path.join(WORKSPACE, "memory", "1368-memory")
    L0_RAW = os.path.join(MEMORY_1368, "L0_raw")
    L1_DECISION = os.path.join(MEMORY_1368, "L1_decision")
    L2_SCENE = os.path.join(MEMORY_1368, "L2_scene")
    L3_PROFILE = os.path.join(MEMORY_1368, "L3_profile")
    SKILL_DIR = os.path.join(WORKSPACE, "skills", "1368-memory-system")
    INDEXES = os.path.join(SKILL_DIR, "indexes")
    EMBEDDING_BACKEND = "minimax"
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
    OPENAI_API_BASE = os.environ.get("OPENAI_API_BASE", "https://api.minimax.chat/v1")
    EMBEDDING_MODEL = "embo-01"

def get_embedding(text, retries=3, base_delay=2):
    """获取单个文本的 embedding，带速率控制和重试"""
    import requests
    import time
    
    if EMBEDDING_BACKEND == "minimax":
        api_key = os.environ.get("OPENAI_API_KEY", OPENAI_API_KEY)
        url = os.environ.get("OPENAI_API_BASE", OPENAI_API_BASE) + "/embeddings"
        
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        data = {
            "texts": [text[:8192]],  # MiniMAX格式
            "model": "embo-01",  # 固定使用embo-01模型
            "type": "db"  # MiniMAX必需参数
        }
        
        for attempt in range(retries):
            try:
                response = requests.post(url, headers=headers, json=data, timeout=30)
                result = response.json()
                
                # 检查速率限制
                if result.get('base_resp', {}).get('status_code') == 1002:
                    wait_time = base_delay * (2 ** attempt)  # 指数退避
                    print(f"[速率限制] 等待 {wait_time}秒后重试 ({attempt+1}/{retries})")
                    time.sleep(wait_time)
                    continue
                
                if response.status_code == 200:
                    if result.get("vectors") and len(result["vectors"]) > 0:
                        return np.array(result["vectors"][0], dtype="float32")
                    else:
                        print(f"[错误] API返回无vectors: {result}")
                        return None
                else:
                    print(f"[错误] API 返回: {response.status_code} - {response.text[:200]}")
                    return None
                    
            except Exception as e:
                print(f"[错误] 请求异常: {str(e)[:50]}")
                if attempt < retries - 1:
                    wait_time = base_delay * (2 ** attempt)
                    time.sleep(wait_time)
                    continue
                return None
        
        print(f"[错误] 重试{retries}次后仍失败")
        return None
    
    return None

def get_embeddings_batch(texts, batch_size=32, delay_between=0.1):
    """批量获取 embeddings，带批次间延迟"""
    import time
    
    embeddings = []
    total_batches = (len(texts) + batch_size - 1) // batch_size
    
    for batch_idx in range(total_batches):
        start = batch_idx * batch_size
        end = min(start + batch_size, len(texts))
        batch = texts[start:end]
        batch_embeddings = []
        
        for text in batch:
            emb = get_embedding(text)
            if emb is not None:
                batch_embeddings.append(emb)
            else:
                # 如果失败，使用零向量
                if embeddings:
                    batch_embeddings.append(np.zeros_like(embeddings[0]))
                else:
                    batch_embeddings.append(np.zeros(1536, dtype="float32"))
            time.sleep(delay_between)  # 批次内请求间隔
        
        embeddings.extend(batch_embeddings)
        # 每10个批次打印一次进度
        if batch_idx % 10 == 0:
            print(f"[进度] {end}/{len(texts)} ({batch_idx+1}/{total_batches}批次)")
        time.sleep(delay_between * 2)  # 批次间额外延迟
    
    return np.array(embeddings) if embeddings else None

def scan_docs(sources):
    """扫描目录获取所有文档"""
    docs = []
    
    for source in sources:
        if not os.path.exists(source):
            continue
        
        for root, dirs, files in os.walk(source):
            for file in files:
                if not file.endswith(".md"):
                    continue
                
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()
                    
                    # 简单分块（按段落）
                    blocks = content.split("\n\n")
                    for block in blocks:
                        block = block.strip()
                        if len(block) > 20:  # 忽略太短的块
                            docs.append({
                                "content": block,
                                "source": file_path,
                                "file": file
                            })
                except Exception as e:
                    print(f"[跳过] {file_path}: {e}")
    
    return docs

def build_layer_index(layer_name, layer_config):
    """构建单个层的索引"""
    print(f"\n[索引构建] {layer_name}")
    print(f"  来源: {layer_config['sources']}")
    
    docs = scan_docs(layer_config["sources"])
    print(f"  发现 {len(docs)} 个文本块")
    
    if not docs:
        print(f"  无内容，跳过")
        return 0
    
    texts = [d["content"] for d in docs]
    print(f"  生成 Embedding ({EMBEDDING_BACKEND})...")
    
    embeddings = get_embeddings_batch(texts)
    if embeddings is None or len(embeddings) == 0:
        print(f"  Embedding 生成失败")
        return 0
    
    dim = embeddings.shape[1]
    print(f"  向量维度: {dim}")
    
    # 创建 FAISS 索引
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)
    
    # 保存索引
    os.makedirs(os.path.dirname(layer_config["index_file"]), exist_ok=True)
    faiss.write_index(index, layer_config["index_file"])
    
    # 保存元数据
    with open(layer_config["meta_file"], "w", encoding="utf-8") as f:
        json.dump(docs, f, ensure_ascii=False, indent=2)
    
    print(f"  完成: {len(docs)} 块, 维度={dim}")
    return len(docs)

def build_all():
    """构建所有索引"""
    print("=" * 50)
    print("[1368元神系统] 向量索引构建")
    print(f"后端: {EMBEDDING_BACKEND}")
    print("=" * 50)
    
    os.makedirs(INDEXES, exist_ok=True)
    
    total = 0
    for layer_name, layer_config in INDEX_CONFIG.items():
        total += build_layer_index(layer_name, layer_config)
    
    print(f"\n[完成] 共构建 {total} 个文本块的索引")
    print(f"索引目录: {INDEXES}")

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--layer":
        # 构建指定层
        layer_name = sys.argv[2] if len(sys.argv) > 2 else "memory"
        if layer_name in INDEX_CONFIG:
            build_layer_index(layer_name, INDEX_CONFIG[layer_name])
        else:
            print(f"[错误] 未知层级: {layer_name}")
            print(f"可用层级: {list(INDEX_CONFIG.keys())}")
    else:
        # 构建所有索引
        build_all()

if __name__ == "__main__":
    main()
