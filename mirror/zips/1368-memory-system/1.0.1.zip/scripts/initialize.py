#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神记忆系统 - 初始化向导
==========================================

初始化流程（v2.0）：
1. 检查环境依赖
2. 初始化目录结构
3. 配置Embedding（向量后端）
4. 完成（提示后续步骤）

注意：历史数据导入、L1/L2/L3提取、索引构建由独立脚本处理
"""

import os
import sys
import json
from datetime import datetime

# 添加脚本目录到路径
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
WORKSPACE = '/root/.openclaw/workspace/main'

# 加载.env配置文件
def load_env_file():
    """从configs/.env加载环境变量"""
    env_path = os.path.join(SKILL_DIR, 'configs', '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key.strip()] = value.strip()

load_env_file()

sys.path.insert(0, SCRIPT_DIR)

# 导入配置
try:
    from paths_config import (
        WORKSPACE, MEMORY_DIR, MEMORY_SESSIONS, PROJECTS_DIR,
        L0_SIZE_LIMIT, SEPARATE_SIZE
    )
except ImportError:
    print("[WARN] paths_config 导入失败，使用默认配置")
    WORKSPACE = '/root/.openclaw/workspace/main'
    MEMORY_DIR = os.path.join(WORKSPACE, "memory")
    MEMORY_SESSIONS = os.path.join(MEMORY_DIR, "sessions")
    PROJECTS_DIR = os.path.join(MEMORY_DIR, "projects")
    L0_SIZE_LIMIT = 4 * 1024 * 1024
    SEPARATE_SIZE = 2 * 1024 * 1024

class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def log(msg, level="INFO"):
    levels = {
        "INFO": f"{Colors.OKBLUE}[INFO]{Colors.ENDC}",
        "OK": f"{Colors.OKGREEN}[OK]{Colors.ENDC}",
        "WARN": f"{Colors.WARNING}[WARN]{Colors.ENDC}",
        "ERROR": f"{Colors.FAIL}[ERROR]{Colors.ENDC}",
        "STEP": f"{Colors.HEADER}[STEP]{Colors.ENDC}",
    }
    print(f"{levels.get(level, '[INFO]')} {msg}")

def log_section(title):
    print(f"\n{'='*60}")
    print(f"{Colors.BOLD}{title}{Colors.ENDC}")
    print(f"{'='*60}")

# ==================== 步骤1：环境检查 ====================

def check_environment():
    """检查环境依赖"""
    log_section("步骤1：环境检查")
    
    checks = [
        ("Python 版本", lambda: sys.version_info >= (3, 8)),
        ("watchdog 库", lambda: __import__('watchdog')),
        ("docx 库", lambda: __import__('docx')),
        ("numpy 库", lambda: __import__('numpy')),
    ]
    
    all_passed = True
    for name, check in checks:
        try:
            check()
            log(f"{name}: {Colors.OKGREEN}OK{Colors.ENDC}", "OK")
        except Exception as e:
            log(f"{name}: {Colors.FAIL}缺失 ({e}){Colors.ENDC}", "ERROR")
            all_passed = False
    
    if not all_passed:
        log("安装缺失的依赖：pip install watchdog python-docx numpy", "WARN")
        return False
    
    log("环境检查完成，所有依赖就绪", "OK")
    return True

# ==================== 步骤2：初始化目录 ====================

def initialize_directories():
    """初始化目录结构"""
    log_section("步骤2：初始化目录结构")
    
    # 1368记忆系统目录
    dirs = [
        os.path.join(WORKSPACE, "memory", "1368-memory"),
        os.path.join(WORKSPACE, "memory", "1368-memory", "L0_raw"),
        os.path.join(WORKSPACE, "memory", "1368-memory", "L1_decision"),
        os.path.join(WORKSPACE, "memory", "1368-memory", "L2_scene"),
        os.path.join(WORKSPACE, "memory", "1368-memory", "L3_profile"),
        os.path.join(WORKSPACE, "memory", "1368-memory", "indexes"),
    ]
    
    for d in dirs:
        os.makedirs(d, exist_ok=True)
        log(f"创建目录: {d}", "OK")
    
    # 各智能体子目录
    agents = ['main', 'xiaodai', 'xiaodang', 'xiaogu', 'xiaofa', 'vice-manager']
    for agent in agents:
        agent_dir = os.path.join(WORKSPACE, "memory", "1368-memory", "L0_raw", agent)
        os.makedirs(agent_dir, exist_ok=True)
    
    log("目录结构初始化完成", "OK")
    return True

# ==================== 步骤3：配置Embedding ====================

def configure_embedding():
    """配置Embedding向量后端"""
    log_section("步骤3：配置Embedding（向量后端）")
    
    print("""
请选择向量嵌入模型后端（用于语义搜索）：

1. 【推荐】Ollama 本地部署（免费、私密、离线可用）
   - 优点：免费使用、无需 API Key、离线可用、数据私密
   - 安装要求：
     a) 安装 Ollama: curl -fsSL https://ollama.com/install.sh | sh
     b) 启动服务: ollama serve
     c) 下载模型: ollama pull nomic-embed-text

2. 云端大模型 API（配置简单、快速上手）
   - 优点：配置简单、速度快、无需本地部署
   - 推荐：MiniMAX API（性价比高）
     - 注册: https://platform.minimax.io/
     - 获取 Key 后设置环境变量: export OPENAI_API_KEY=xxx

""")
    
    # 检查当前配置状态
    api_key = os.environ.get('OPENAI_API_KEY', '')
    ollama_available = False
    try:
        import requests
        r = requests.get('http://localhost:11434', timeout=2)
        if r.status_code == 200:
            ollama_available = True
    except:
        pass
    
    print(f"【当前状态】")
    if ollama_available:
        log(f"Ollama 本地服务: {Colors.OKGREEN}已运行{Colors.ENDC}", "OK")
    else:
        log(f"Ollama 本地服务: {Colors.WARNING}未运行{Colors.ENDC}", "WARN")
    
    if api_key:
        log(f"云端 API Key: {Colors.OKGREEN}已配置{Colors.ENDC}", "OK")
    else:
        log(f"云端 API Key: {Colors.WARNING}未配置{Colors.ENDC}", "WARN")
    
    # 询问用户选择
    print(f"请选择后端方案 [1/2] (直接回车默认方案2): ", end='')
    try:
        choice = input().strip()
    except:
        choice = '2'
    
    if choice == '1':
        # Ollama 方案
        if not ollama_available:
            print("""
【Ollama 未运行，请先安装并启动】
1. 安装: curl -fsSL https://ollama.com/install.sh | sh
2. 启动: ollama serve
3. 下载模型: ollama pull nomic-embed-text
4. 重新运行本向导
""")
            log("请先安装并启动 Ollama，然后重新运行本向导", "WARN")
            return False
        else:
            log("已选择 Ollama 本地方案", "OK")
            save_config('ollama')
            return True
    else:
        # API 方案
        if not api_key:
            print("""
【MiniMAX API 配置指引】
1. 注册: https://platform.minimax.io/
2. 获取 API Key
3. 设置: export OPENAI_API_KEY=你的Key
4. 重新运行本向导
""")
            log("请先配置好 API Key 后重新运行向导", "WARN")
            return False
        else:
            log("已选择云端 API 方案", "OK")
            save_config('minimax')
            return True

def save_config(backend):
    """保存配置到1368_config.json"""
    config_dir = os.path.join(SKILL_DIR, "configs")
    os.makedirs(config_dir, exist_ok=True)
    config_path = os.path.join(config_dir, "1368_config.json")
    
    config = {
        "L0_SIZE_LIMIT": "2mb",
        "L123_SIZE_LIMIT": "200kb",
        "EMBEDDING_BACKEND": backend,
        "AUTO_START": "enable",
        "MIGRATE_HISTORY": "none"
    }
    
    try:
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        log(f"配置已保存: {config_path}", "OK")
    except Exception as e:
        log(f"配置保存失败: {e}", "WARN")

# ==================== 完成 ====================

def main():
    """主初始化流程"""
    print(f"\n{Colors.BOLD}{'='*60}")
    print("1368元神记忆系统 - 初始化向导")
    print(f"{'='*60}{Colors.ENDC}\n")
    
    start_time = datetime.now()
    log(f"开始时间: {start_time.strftime('%Y-%m-%d %H:%M:%S')}", "INFO")
    
    # 步骤1：环境检查
    if not check_environment():
        log("环境检查未通过，请先安装依赖", "ERROR")
        return False
    
    # 步骤2：初始化目录
    if not initialize_directories():
        log("目录初始化失败", "ERROR")
        return False
    
    # 步骤3：配置Embedding
    if not configure_embedding():
        log("Embedding 配置未完成", "WARN")
        log("可稍后运行 python3 scripts/config_wizard.py 完成配置", "INFO")
    
    # 完成
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()
    
    log_section("初始化完成")
    log(f"结束时间: {end_time.strftime('%Y-%m-%d %H:%M:%S')}", "INFO")
    log(f"总耗时: {duration:.1f} 秒", "INFO")
    
    print(f"""
{Colors.BOLD}初始化完成！{Colors.ENDC}

{Colors.OKCYAN}后续步骤：{Colors.ENDC}
  步骤4: 运行 config_wizard.py（完整配置流程）
  步骤6: 运行 auto_start.py（启动L0 Watcher）

  或运行一步完成全部：
    python3 scripts/config_wizard.py
""")
    
    return True

if __name__ == "__main__":
    main()