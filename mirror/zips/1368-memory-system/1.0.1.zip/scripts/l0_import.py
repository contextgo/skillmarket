#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1368元神系统 - 历史数据导入工具
===================================
从用户指定目录扫描 .jsonl / .md / .txt / .doc / .docx 文件，导入到 L0_raw

命名规范：L0_{来源前缀}_{开始日期}_{序号}.md
示例: L0_cloud_20260410_001.md

功能：
1. 接受用户指定的目录路径
2. 扫描该目录下所有支持的文件类型
3. 转换为 L0_raw 格式（满阀值自动新建序号文件）
4. 自动分片：大文件自动拆分为 <=2MB 的分片

支持的文件类型：
- .jsonl  OpenClaw会话文件
- .md     Markdown/记忆文件
- .txt    文本文件
- .doc    Word 97-2003 文档
- .docx   Word 2007+ 文档
"""

import os
import sys
import json
import argparse
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from paths_config import (
    WORKSPACE, MEMORY_1368, L0_RAW, L1_DECISION, L2_SCENE, L3_PROFILE,
    AGENTS_SESSIONS, L0_SIZE_LIMIT
)

def safe_ts(ts):
    """解析时间戳"""
    if ts is None:
        return None
    if isinstance(ts, str):
        try:
            if 'T' in ts:
                return datetime.fromisoformat(ts.replace('Z', '+00:00'))
        except:
            pass
    return None

def extract_date_from_md(content, filename):
    """从.md文件内容或文件名提取日期"""
    import re
    lines = content.split('\n')
    first_line = lines[0] if lines else ""
    
    # 匹配 # YYYY-MM-DD 格式
    match = re.match(r'^# (\d{4}-\d{2}-\d{2})(?:\s+\d{2}:\d{2})?', first_line)
    if match:
        return match.group(1)  # 返回 YYYY-MM-DD
    
    # 匹配 # 林哥助手工作日志_YYYYMMDD 格式
    match = re.search(r'_(\d{8})', first_line)
    if match:
        date_str = match.group(1)  # 20260415
        return f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]}"  # 2026-04-15
    
    # 匹配文件名中的日期 YYYY-MM-DD 或 YYYYMMDD
    filename_base = os.path.splitext(filename)[0]
    match = re.search(r'(\d{4}-\d{2}-\d{2})', filename_base)
    if match:
        return match.group(1)
    match = re.search(r'(\d{4})(\d{2})(\d{2})', filename_base)
    if match:
        return f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
    
    return None

def extract_date_from_jsonl(messages):
    """从jsonl消息提取日期"""
    if messages:
        first_ts = messages[0].get('timestamp') or messages[0].get('ts')
        if first_ts:
            # 处理 ISO 格式或时间戳
            if 'T' in str(first_ts):
                return str(first_ts).split('T')[0]  # YYYY-MM-DDTHH:MM:SS -> YYYY-MM-DD
            elif len(str(first_ts)) == 13:  # 毫秒时间戳
                from datetime import datetime
                return datetime.fromtimestamp(int(first_ts)/1000).strftime('%Y-%m-%d')
    return None

def get_l0_import_path(source_prefix, seq, output_dir, date_str=None):
    """
    生成L0导入文件路径
    格式: L0_{日期}_{来源前缀}_{序号}.md
    示例: L0_20260505_history_001.md
    """
    if date_str is None:
        date_str = datetime.now().strftime('%Y%m%d')
    filename = f"L0_{date_str}_{source_prefix}_{seq:03d}.md"
    return os.path.join(output_dir, filename)

def find_next_l0_file(source_prefix, output_dir, date_str=None):
    """
    查找下一个可写入的L0文件
    - 找到不满阀值的文件追加
    - 都满了则新建序号+1的文件
    """
    if date_str is None:
        date_str = datetime.now().strftime('%Y%m%d')
    seq = 1
    while True:
        path = get_l0_import_path(source_prefix, seq, output_dir, date_str)
        if not os.path.exists(path):
            # 文件不存在，新建
            return path, seq
        # 文件存在，检查是否超限
        current_size = os.path.getsize(path)
        if current_size < L0_SIZE_LIMIT:
            return path, seq
        # 满了，用下一个序号
        seq += 1
        if seq > 999:
            return get_l0_import_path(source_prefix, seq, output_dir, date_str), seq
    return path, seq

def get_output_path(session_id, agent_id, output_dir, file_index=1, actual_date=None):
    """生成输出文件路径（兼容旧接口）"""
    if actual_date:
        ts = actual_date.replace('-', '')  # 20260410
        suffix = session_id[:8]  # 取session_id前8位
        base_name = f"{agent_id}-{ts}-{suffix}"
        
        if file_index > 1:
            return os.path.join(output_dir, f"{base_name}.part{file_index:03d}.md")
        return os.path.join(output_dir, f"{base_name}.md")
    else:
        ts = datetime.now().strftime("%Y-%m-%d-%H%M")
        prefix = f"{agent_id}-{ts}-{session_id[:8]}"
        if file_index > 1:
            return os.path.join(output_dir, f"{prefix}.part{file_index:03d}.md")
        return os.path.join(output_dir, f"{prefix}.md")

def split_content_to_parts(content, session_id, agent_id, output_dir):
    """将内容拆分为 <=2MB 的多个文件"""
    lines = content.split('\n')
    
    # 提取头部（前10行包含标题/元信息的行）
    header_lines = []
    content_start = 0
    for i, line in enumerate(lines[:15]):
        if line.startswith('# ') or line.startswith('**') or line.strip() == '---':
            header_lines.append(line)
        else:
            content_start = i
            break
    
    header_text = '\n'.join(header_lines) + '\n\n' if header_lines else None
    
    # 按行拆分，确保每部分 <= 2MB
    parts = []
    current_part = []
    current_size = 0
    part_num = 1
    
    def write_part(part_num, lines):
        prefix = f"{agent_id}-{datetime.now().strftime('%Y-%m-%d-%H%M')}-{session_id[:8]}"
        part_name = f"{prefix}.part{part_num:03d}.md"
        part_path = os.path.join(output_dir, part_name)
        
        with open(part_path, 'w', encoding='utf-8') as f:
            if header_text:
                f.write(header_text)
            f.write('\n'.join(lines))
        
        size = os.path.getsize(part_path)
        return part_name, size
    
    for i in range(content_start, len(lines)):
        line = lines[i]
        line_bytes = (line + '\n').encode('utf-8')
        line_size = len(line_bytes)
        
        # 跳过空行（开头）
        if not line.strip() and current_size == 0:
            continue
        
        # 检查是否需要新建分片
        if current_size + line_size > L0_SIZE_LIMIT and current_part:
            part_name, size = write_part(part_num, current_part)
            parts.append((part_name, size))
            part_num += 1
            current_part = []
            current_size = 0
        
        current_part.append(line)
        current_size += line_size
    
    # 写最后一个分片
    if current_part:
        part_name, size = write_part(part_num, current_part)
        parts.append((part_name, size))
    
    return parts

def parse_jsonl(path):
    """解析 .jsonl 文件"""
    messages = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    messages.append(json.loads(line))
                except:
                    continue
    except Exception as e:
        print(f"  ❌ 解析失败: {e}")
    return messages

def extract_text_from_content(content):
    """从content中提取纯文本内容"""
    if isinstance(content, list):
        texts = []
        for c in content:
            if isinstance(c, dict):
                # 只提取text类型，跳过thinking/toolCall/toolResult
                if c.get('type') == 'text':
                    texts.append(c.get('text', ''))
        return ''.join(texts)
    return str(content)

def clean_user_message(text):
    """清理用户消息中的元信息前缀"""
    marker = 'Conversation info (untrusted metadata)'
    if marker in text:
        idx = text.find(marker)
        text = text[idx + len(marker):].strip()
        if 'Sender (untrusted metadata):' in text:
            parts = text.split('Sender (untrusted metadata):')
            if len(parts) > 1:
                text = parts[-1].strip()
                if text.startswith('```'):
                    idx = text.find('```', 3)
                    if idx > 0:
                        text = text[idx+3:].strip()
    # 也处理只残留Sender部分的情况
    if text.startswith('Sender (untrusted metadata)'):
        idx = text.find('```', 30)
        if idx > 0:
            text = text[idx+3:].strip()
            if text.startswith('```'):
                idx2 = text.find('```', 3)
                if idx2 > 0:
                    text = text[idx2+3:].strip()
    return text

def jsonl_to_markdown(messages, session_id, source_path):
    """将 JSONL 消息转换为 L0 人工可读格式"""
    # 从第一条消息获取时间戳
    first_msg = messages[0] if messages else None
    if first_msg:
        ts = first_msg.get('timestamp') or first_msg.get('ts', '')
        if ts:
            if 'T' in str(ts):
                first_ts = safe_ts(ts)
            elif isinstance(ts, (int, float)):
                first_ts = datetime.fromtimestamp(ts/1000)
            else:
                first_ts = datetime.now()
        else:
            first_ts = datetime.now()
    else:
        first_ts = datetime.now()
    
    lines = []
    user_count = 0
    assistant_count = 0
    
    for msg in messages:
        msg_type = msg.get('type', '')
        ts = msg.get('timestamp') or msg.get('ts', '')
        
        # 格式化时间
        if ts:
            if 'T' in str(ts):
                dt = safe_ts(ts)
                ts_str = dt.strftime('%H:%M') if dt else str(ts)[11:16]
            elif isinstance(ts, (int, float)):
                ts_str = datetime.fromtimestamp(ts/1000).strftime('%H:%M')
            else:
                ts_str = str(ts)[:5]
        else:
            ts_str = '??:??'
        
        # 旧格式：type=message，有message字段
        if msg_type == 'message' and 'message' in msg:
            m = msg['message']
            role = m.get('role', '')
            content = m.get('content', '')
            text = extract_text_from_content(content)
            
            if role == 'user':
                text = clean_user_message(text)
            
            if not text:
                continue
            
            if role == 'user' and text:
                lines.append(f"[{ts_str} user] {text}")
                user_count += 1
            elif role == 'assistant' and text:
                lines.append(f"[{ts_str} assistant] {text}")
                assistant_count += 1
        
        # 新格式：model.completed 的 messagesSnapshot
        elif msg_type == 'model.completed':
            data = msg.get('data', {})
            snapshot = data.get('messagesSnapshot', [])
            
            # 分别收集用户和助手消息（去重）
            seen_user = False
            seen_assistant = False
            
            for m in snapshot:
                role = m.get('role', '')
                content = m.get('content', '')
                text = extract_text_from_content(content)
                
                # 清理用户消息元信息
                if role == 'user':
                    text = clean_user_message(text)
                
                # 跳过空消息
                if not text:
                    continue
                
                # 只保留用户和助手的最终消息，跳过compactionSummary/thinking/toolCall/toolResult
                if role == 'user' and not seen_user:
                    lines.append(f"[{ts_str} user] {text}")
                    user_count += 1
                    seen_user = True
                elif role == 'assistant' and not seen_assistant:
                    lines.append(f"[{ts_str} assistant] {text}")
                    assistant_count += 1
                    seen_assistant = True
            
        # 从 context.compiled 提取消息
        elif msg_type == 'context.compiled':
            data = msg.get('data', {})
            snapshot = data.get('messagesSnapshot', [])
            
            for m in snapshot:
                role = m.get('role', '')
                content = m.get('content', '')
                text = extract_text_from_content(content)
                
                if role == 'user':
                    text = clean_user_message(text)
                
                if not text:
                    continue
                
                # 跳过内部角色
                if role in ('user', 'assistant'):
                    if role == 'user' and text:
                        lines.append(f"[{ts_str} user] {text}")
                        user_count += 1
                    elif role == 'assistant' and text:
                        lines.append(f"[{ts_str} assistant] {text}")
                        assistant_count += 1
    
    # 生成文件头
    header = f"""# 会话存档：{first_ts.strftime('%Y-%m-%d %H:%M')}
- 会话ID: {session_id}
- Agent: main
- 消息数: {user_count + assistant_count}（用户: {user_count}，助手: {assistant_count}）

---
"""
    return header + '\n\n'.join(lines)

def read_md_file(path):
    """读取 .md 文件内容"""
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"  ❌ 读取失败: {e}")
        return None

def read_txt_file(path):
    """读取 .txt 文件内容"""
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception:
        try:
            # 尝试其他编码
            with open(path, 'r', encoding='gbk') as f:
                return f.read()
        except Exception as e:
            print(f"  ❌ TXT读取失败: {e}")
            return None

def read_docx_file(path):
    """读取 .docx 文件内容（Word 2007+）"""
    try:
        from zipfile import ZipFile
        from xml.etree import ElementTree
        
        with ZipFile(path, 'r') as docx:
            # 读取 document.xml
            with docx.open('word/document.xml') as xml:
                tree = ElementTree.parse(xml)
                root = tree.getroot()
        
        # 提取命名空间
        ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        
        # 提取所有文本
        paragraphs = []
        for para in root.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'):
            texts = []
            for t in para.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'):
                if t.text:
                    texts.append(t.text)
            if texts:
                paragraphs.append(''.join(texts))
        
        return '\n'.join(paragraphs)
    except ImportError:
        print(f"  ⚠️ docx需要安装python-docx: pip install python-docx")
        return None
    except Exception as e:
        print(f"  ❌ DOCX读取失败: {e}")
        return None

def read_doc_file(path):
    """读取 .doc 文件内容（Word 97-2003）"""
    try:
        from docx import Document
        doc = Document(path)
        paragraphs = []
        for para in doc.paragraphs:
            if para.text.strip():
                paragraphs.append(para.text)
        return '\n'.join(paragraphs)
    except ImportError:
        print(f"  ⚠️ .doc需要安装python-docx: pip install python-docx")
        return None
    except Exception as e:
        print(f"  ❌ DOC读取失败: {e}")
        return None

def extract_date_from_generic(content, filename):
    """从通用文档内容或文件名提取日期"""
    import re
    
    # 匹配文件名中的日期
    filename_base = os.path.splitext(filename)[0]
    patterns = [
        r'(\d{4}-\d{2}-\d{2})',  # YYYY-MM-DD
        r'(\d{4})(\d{2})(\d{2})',  # YYYYMMDD
        r'_(\d{8})_',  # _YYYYMMDD_
        r'-(\d{8})-',  # -YYYYMMDD-
    ]
    
    for pattern in patterns:
        match = re.search(pattern, filename_base)
        if match:
            if len(match.groups()) == 3:
                return f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
            else:
                return match.group(1)
    
    # 尝试从内容前几行匹配日期
    lines = content.split('\n')[:10]
    date_patterns = [
        r'(\d{4}-\d{2}-\d{2})',
        r'(\d{4}/\d{2}/\d{2})',
    ]
    for line in lines:
        for pattern in date_patterns:
            match = re.search(pattern, line)
            if match:
                date_str = match.group(1).replace('/', '-')
                return date_str
    
    return None

def import_generic_file(file_path, agent_id, source_prefix, output_dir, file_type, dry_run=False):
    """
    通用文件导入函数（处理 txt/doc/docx）
    使用新命名规范: L0_{来源前缀}_{开始日期}_{序号}.md
    """
    filename = os.path.basename(file_path)
    
    # 根据类型读取内容
    if file_type == 'txt':
        content = read_txt_file(file_path)
    elif file_type == 'docx':
        content = read_docx_file(file_path)
    elif file_type == 'doc':
        content = read_doc_file(file_path)
    else:
        return False, f"❌ 不支持的文件类型: {file_type}"
    
    if content is None:
        return False, f"⚠ 读取失败: {filename}"
    
    if not content.strip():
        return False, f"⚠ 空文件: {filename}"
    
    # 提取开始日期
    actual_date = extract_date_from_generic(content, filename)
    if actual_date:
        print(f"  📅 检测到日期: {actual_date}")
    else:
        actual_date = datetime.now().strftime("%Y-%m-%d")
    
    # 检查文件大小并写入
    content_bytes = content.encode('utf-8')
    if len(content_bytes) <= L0_SIZE_LIMIT:
        # 小文件，找到下一个可用文件
        output_path, seq = find_next_l0_file(source_prefix, output_dir)
        if dry_run:
            return True, f"[DRY] {os.path.basename(output_path)} ({file_type})"
        try:
            # 追加模式写入（如果文件已存在且不满）
            mode = 'a' if os.path.exists(output_path) else 'w'
            with open(output_path, mode, encoding='utf-8') as f:
                if mode == 'a':
                    f.write('\n\n--- 来源: ' + os.path.basename(file_path) + ' ---\n\n')
                f.write(content)
            return True, f"✅ {os.path.basename(output_path)} ({file_type})"
        except Exception as e:
            return False, f"❌ 写入失败: {e}"
    else:
        # 大文件需要分片
        if dry_run:
            estimated_parts = (len(content_bytes) // L0_SIZE_LIMIT) + 1
            return True, f"[DRY] {source_prefix}_{actual_date}... (预计 {estimated_parts} 个分片, {file_type})"
        
        parts = split_content_to_parts(content, f"{source_prefix}_{actual_date}", source_prefix, output_dir)
        return True, f"✅ {source_prefix}_{actual_date}... -> {len(parts)} 个分片 ({file_type})"


def import_jsonl(jsonl_path, agent_id, source_prefix, output_dir, dry_run=False):
    """
    导入单个 .jsonl 文件
    命名规范: L0_{来源前缀}_{开始日期}_{序号}.md
    满阀值自动追加到已有文件或新建
    """
    messages = parse_jsonl(jsonl_path)
    if not messages:
        return False, f"⚠ 空文件或解析失败: {os.path.basename(jsonl_path)}"
    
    # 提取开始日期
    actual_date = extract_date_from_jsonl(messages)
    if actual_date:
        print(f"  📅 检测到日期: {actual_date}")
    else:
        actual_date = datetime.now().strftime("%Y-%m-%d")
    
    # 转换为 Markdown
    session_id = os.path.splitext(os.path.basename(jsonl_path))[0][:16]
    content = jsonl_to_markdown(messages, session_id, jsonl_path)
    content_bytes = content.encode('utf-8')
    
    if len(content_bytes) <= L0_SIZE_LIMIT:
        # 小文件，找到下一个可用文件
        output_path, seq = find_next_l0_file(source_prefix, output_dir)
        if dry_run:
            return True, f"[DRY] {os.path.basename(output_path)} ({len(messages)} 条消息)"
        try:
            # 追加模式写入（如果文件已存在且不满）
            mode = 'a' if os.path.exists(output_path) else 'w'
            with open(output_path, mode, encoding='utf-8') as f:
                if mode == 'a':
                    f.write('\n\n--- 来源: ' + os.path.basename(jsonl_path) + ' ---\n\n')
                f.write(content)
            return True, f"✅ {os.path.basename(output_path)} ({len(messages)} 条消息)"
        except Exception as e:
            return False, f"❌ 写入失败: {e}"
    else:
        # 大文件需要分片
        if dry_run:
            estimated_parts = (len(content_bytes) // L0_SIZE_LIMIT) + 1
            return True, f"[DRY] {source_prefix}_{actual_date}... (预计 {estimated_parts} 个分片)"
        base_name = f"{source_prefix}_{actual_date}"
        parts = split_content_to_parts(content, base_name, source_prefix, output_dir)
        return True, f"✅ {source_prefix}_{actual_date}... -> {len(parts)} 个分片"

def import_md(md_path, agent_id, source_prefix, output_dir, dry_run=False):
    """
    导入单个 .md 文件
    命名规范: L0_{来源前缀}_{开始日期}_{序号}.md
    满阀值自动追加到已有文件或新建
    """
    content = read_md_file(md_path)
    if content is None:
        return False, f"⚠ 读取失败: {os.path.basename(md_path)}"
    
    if not content.strip():
        return False, f"⚠ 空文件: {os.path.basename(md_path)}"
    
    # 提取开始日期
    actual_date = extract_date_from_md(content, os.path.basename(md_path))
    if actual_date:
        print(f"  📅 检测到日期: {actual_date}")
    else:
        actual_date = datetime.now().strftime("%Y-%m-%d")
    
    content_bytes = content.encode('utf-8')
    
    if len(content_bytes) <= L0_SIZE_LIMIT:
        # 小文件，找到下一个可用文件
        output_path, seq = find_next_l0_file(source_prefix, output_dir)
        if dry_run:
            return True, f"[DRY] {os.path.basename(output_path)} (md)"
        try:
            # 追加模式写入（如果文件已存在且不满）
            mode = 'a' if os.path.exists(output_path) else 'w'
            with open(output_path, mode, encoding='utf-8') as f:
                if mode == 'a':
                    f.write('\n\n--- 来源: ' + os.path.basename(md_path) + ' ---\n\n')
                f.write(content)
            return True, f"✅ {os.path.basename(output_path)} (md)"
        except Exception as e:
            return False, f"❌ 写入失败: {e}"
    else:
        # 大文件需要分片
        if dry_run:
            estimated_parts = (len(content_bytes) // L0_SIZE_LIMIT) + 1
            return True, f"[DRY] {source_prefix}_{actual_date}... (预计 {estimated_parts} 个分片)"
        base_name = f"{source_prefix}_{actual_date}"
        parts = split_content_to_parts(content, base_name, source_prefix, output_dir)
        return True, f"✅ {source_prefix}_{actual_date}... -> {len(parts)} 个分片"

def scan_directory(source_dir, recursive=False):
    """扫描目录获取所有支持的文件类型"""
    jsonl_files = []
    md_files = []
    txt_files = []
    docx_files = []
    doc_files = []
    
    file_extensions = ['.jsonl', '.md', '.txt', '.docx', '.doc']
    
    if recursive:
        for root, dirs, files in os.walk(source_dir):
            for f in files:
                if '.part' in f:  # 跳过已分片的文件
                    continue
                if f.endswith('.jsonl'):
                    jsonl_files.append(os.path.join(root, f))
                elif f.endswith('.md'):
                    md_files.append(os.path.join(root, f))
                elif f.endswith('.txt'):
                    txt_files.append(os.path.join(root, f))
                elif f.endswith('.docx'):
                    docx_files.append(os.path.join(root, f))
                elif f.endswith('.doc'):
                    doc_files.append(os.path.join(root, f))
    else:
        for f in os.listdir(source_dir):
            if '.part' in f:  # 跳过已分片的文件
                continue
            if f.endswith('.jsonl'):
                jsonl_files.append(os.path.join(source_dir, f))
            elif f.endswith('.md'):
                md_files.append(os.path.join(source_dir, f))
            elif f.endswith('.txt'):
                txt_files.append(os.path.join(source_dir, f))
            elif f.endswith('.docx'):
                docx_files.append(os.path.join(source_dir, f))
            elif f.endswith('.doc'):
                doc_files.append(os.path.join(source_dir, f))
    
    return jsonl_files, md_files, txt_files, docx_files, doc_files

def main():
    parser = argparse.ArgumentParser(
        description="1368元神系统 - 历史数据导入工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
支持的文件类型：
  .jsonl  OpenClaw会话文件
  .md     Markdown/记忆文件
  .txt    文本文件
  .docx   Word 2007+ 文档
  .doc    Word 97-2003 文档

使用示例：
  # 导入指定目录的所有支持文件
  python3 l0_import.py --dir /path/to/sessions
  
  # 指定智能体
  python3 l0_import.py --dir /path/to/sessions --agent xiaodai
  
  # 递归扫描子目录
  python3 l0_import.py --dir /path/to/sessions --recursive
  
  # 仅模拟，不实际写入
  python3 l0_import.py --dir /path/to/sessions --dry-run
        """
    )
    
    parser.add_argument('--dir', '-d', required=True, help='源目录路径')
    parser.add_argument('--prefix', '-p', default='import', help='来源前缀（默认: import，用于文件名 L0_{前缀}_日期_序号）')
    parser.add_argument('--agent', '-a', default='imported', help='目标智能体ID（默认: imported）')
    parser.add_argument('--recursive', '-r', action='store_true', help='递归扫描子目录')
    parser.add_argument('--dry-run', '-n', action='store_true', help='仅模拟，不实际写入')
    parser.add_argument('--output', '-o', help='输出目录（默认: L0_raw/{agent}）')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("  1368元神系统 - 历史数据导入工具")
    print("=" * 60)
    print(f"\n源目录: {args.dir}")
    print(f"来源前缀: {args.prefix}")
    print(f"智能体: {args.agent}")
    print(f"递归: {'是' if args.recursive else '否'}")
    print(f"文件限制: 2MB（超过自动新建序号文件）")
    
    # 检查源目录
    if not os.path.exists(args.dir):
        print(f"\n❌ 目录不存在: {args.dir}")
        return
    
    # 确定输出目录
    if args.output:
        output_dir = args.output
    else:
        output_dir = os.path.join(L0_RAW, args.agent)
    
    os.makedirs(output_dir, exist_ok=True)
    print(f"输出目录: {output_dir}")
    
    if args.dry_run:
        print("\n[DRY RUN] 仅模拟，不实际写入")
    
    # 扫描文件
    print("\n扫描文件...")
    jsonl_files, md_files, txt_files, docx_files, doc_files = scan_directory(args.dir, args.recursive)
    
    print(f"  .jsonl 文件: {len(jsonl_files)} 个")
    print(f"  .md 文件: {len(md_files)} 个")
    print(f"  .txt 文件: {len(txt_files)} 个")
    print(f"  .docx 文件: {len(docx_files)} 个")
    print(f"  .doc 文件: {len(doc_files)} 个")
    
    total_files = len(jsonl_files) + len(md_files) + len(txt_files) + len(docx_files) + len(doc_files)
    if total_files == 0:
        print("  未找到支持的文件")
        return
    
    # 导入统计变量
    success_jsonl = fail_jsonl = 0
    success_md = fail_md = 0
    success_txt = fail_txt = 0
    success_docx = fail_docx = 0
    success_doc = fail_doc = 0
    
    # 导入 .jsonl 文件
    if jsonl_files:
        print(f"\n导入 .jsonl 文件...")
        for path in jsonl_files:
            success, msg = import_jsonl(path, args.agent, args.prefix, output_dir, args.dry_run)
            print(f"  {msg}")
            if success:
                success_jsonl += 1
            else:
                fail_jsonl += 1
    
    # 导入 .md 文件
    if md_files:
        print(f"\n导入 .md 文件...")
        for path in md_files:
            success, msg = import_md(path, args.agent, args.prefix, output_dir, args.dry_run)
            print(f"  {msg}")
            if success:
                success_md += 1
            else:
                fail_md += 1
    
    # 导入 .txt 文件
    if txt_files:
        print(f"\n导入 .txt 文件...")
        for path in txt_files:
            success, msg = import_generic_file(path, args.agent, args.prefix, output_dir, 'txt', args.dry_run)
            print(f"  {msg}")
            if success:
                success_txt += 1
            else:
                fail_txt += 1
    
    # 导入 .docx 文件
    if docx_files:
        print(f"\n导入 .docx 文件...")
        for path in docx_files:
            success, msg = import_generic_file(path, args.agent, args.prefix, output_dir, 'docx', args.dry_run)
            print(f"  {msg}")
            if success:
                success_docx += 1
            else:
                fail_docx += 1
    
    # 导入 .doc 文件
    if doc_files:
        print(f"\n导入 .doc 文件...")
        for path in doc_files:
            success, msg = import_generic_file(path, args.agent, args.prefix, output_dir, 'doc', args.dry_run)
            print(f"  {msg}")
            if success:
                success_doc += 1
            else:
                fail_doc += 1
    
    # 完成
    print("\n" + "=" * 60)
    total = success_jsonl + success_md + success_txt + success_docx + success_doc
    if args.dry_run:
        print(f"  [DRY RUN] 将导入 {total} 个文件")
    else:
        print(f"  ✅ 导入完成！")
        print(f"     .jsonl: {success_jsonl} 成功, {fail_jsonl} 失败")
        print(f"     .md: {success_md} 成功, {fail_md} 失败")
        print(f"     .txt: {success_txt} 成功, {fail_txt} 失败")
        print(f"     .docx: {success_docx} 成功, {fail_docx} 失败")
        print(f"     .doc: {success_doc} 成功, {fail_doc} 失败")
    print("=" * 60)

if __name__ == "__main__":
    main()