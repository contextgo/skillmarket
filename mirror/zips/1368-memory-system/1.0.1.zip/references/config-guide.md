# 1368元神系统 — 配置向导

> **版本**: v1.0.1 | **日期**: 2026-05-02

---

## 一、配置项总览

### 1.1 可调整配置清单

| 分类 | 配置项 | 默认值 | 说明 | 推荐值 |
|------|--------|--------|------|-------|
| **L0阈值** | `L0_SIZE_LIMIT` | 2MB | L0原始文件大小限制 | 2MB |
| **L1/L2/L3阈值** | `L123_SIZE_LIMIT` | 200KB | 决策/场景/画像文件限制 | 200KB |
| **向量搜索** | `EMBEDDING_BACKEND` | "minimax" | 向量模型后端 | "minimax" |
| **历史数据** | `MIGRATE_HISTORY` | "none" | 回溯模式 | "none" |

---

## 二、配置流程图

```
┌─────────────────────────────────────────────────────────────┐
│              1368元神系统 - 8步配置向导                       │
└─────────────────────────────────────────────────────────────┘

开始
  │
  ▼
┌─────────────────┐
│ 步骤1: L0阈值   │ → L0_SIZE_LIMIT (1MB/2MB/4MB)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 步骤2: L123阈值 │ → L123_SIZE_LIMIT (100KB/200KB/500KB)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 步骤3: 向量配置  │ → EMBEDDING_BACKEND (MiniMAX/Ollama/其他)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 步骤4: 初始化   │ → 创建目录结构 + 配置Embedding
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 步骤5: 历史回溯  │ → MIGRATE_HISTORY (all/recent30/none)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 步骤6: L123提取 │ → python3 l123_extractor.py
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 步骤7: 索引构建 │ → python3 build_index_1368.py
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 步骤8: 启动监听 │ → python3 auto_start.py
└────────┬────────┘
         │
         ▼
      完成
```

---

## 三、详细配置步骤

### 步骤1：L0 阈值配置

```
【第 1/8 步】L0 阈值配置
  说明：原始会话复刻文件的大小限制

  [1] 1MB（频繁分离，适合大会话量）
  [2] 2MB（平衡，推荐）
  [3] 4MB（少量分离，适合小会话量）

L0 阈值 (1-3) 或回车默认: 2
确认此配置 [Y/n]: y
```

### 步骤2：L1/L2/L3 阈值配置

```
【第 2/8 步】L1/L2/L3 阈值配置
  说明：决策/场景/画像文件的大小限制

  [1] 100KB（更多文件，更细粒度）
  [2] 200KB（平衡，推荐）
  [3] 500KB（较少文件，更粗粒度）

L1/L2/L3 阈值 (1-3) 或回车默认: 2
确认此配置 [Y/n]: y
```

### 步骤3：向量搜索配置

```
【第 3/8 步】向量搜索配置
  说明：选择向量搜索的后端服务

  [1] MiniMAX API（推荐，按量付费）
  [2] Ollama 本地部署（免费，需本地部署）
  [3] 其他AI API（火山引擎等）

向量搜索后端 (1-3) 或回车默认: 1
确认此配置 [Y/n]: y
```

### 步骤4：初始化目录 + Embedding配置

```
【第 4/8 步】初始化配置
  说明：初始化1368目录结构 + 配置Embedding向量后端

  【4.1】初始化目录结构
  ✅ 创建目录: memory/1368-memory/L0_raw/
  ✅ 创建目录: memory/1368-memory/L1_decision/
  ✅ 创建目录: memory/1368-memory/L2_scene/
  ✅ 创建目录: memory/1368-memory/L3_profile/
  ✅ 创建目录: memory/1368-memory/indexes/

  确认目录初始化 [Y/n]: y

  【4.2】配置Embedding（向量后端）
  [1] Ollama 本地部署
  [2] 云端大模型 API（推荐MiniMAX）

  请选择 [1/2] (默认2): 2
```

### 步骤5：历史数据回溯

```
【第 5/8 步】历史数据回溯
  说明：是否回溯转写原系统历史数据到 L0_raw

  [1] 回溯全部（所有.jsonl文件）
  [2] 回溯近期（30天内）
  [3] 暂不回溯（仅处理新数据）

  请输入选择 (1-3) 或回车默认 [3]: 3
  确认此配置 [Y/n]: y
```

### 步骤6：L1/L2/L3提取

```
【第 6/8 步】L1/L2/L3提取
  说明：从L0_raw提取决策/场景/画像

  执行命令：python3 scripts/l123_extractor.py

  请确认是否执行 [Y/n]: y

  [处理] main ...
  [L123] 发现 71 个 L0 文件
  [L1-提取] l1-2026-05-02-1640-main-2026-04-30-.md: 207 条
  [L2-提取] l2-2026-05-02-1640-main-2026-04-30-.md: 50 条
  [L3-提取] l3-2026-05-02-1640-main-2026-04-30-.md: 30 条
  ✅ L1/L2/L3提取完成
```

### 步骤7：索引构建

```
【第 7/8 步】索引构建
  说明：为L0_raw、L1_decision、L2_scene、L3_profile构建向量索引

  执行命令：python3 scripts/build_index_1368.py

  ⚠️ 需要配置 API Key
  export OPENAI_API_KEY=你的Key

  请按回车继续（跳过索引构建）:
```

### 步骤8：启动L0监听

```
【第 8/8 步】启动L0监听
  说明：启动L0 Watcher，实时监控6个智能体的会话目录

  请确认是否启动 [Y/n]: y

  ✅ L0 Watcher 启动完成
```

---

## 四、文件规格限制

| 层级 | 文件大小限制 | 说明 |
|------|-------------|------|
| L0_raw | ≤ 2MB/文件 | 超出会自动新建文件 |
| L1/L2/L3 | ≤ 200KB/文件 | 超出会自动新建文件 |

---

## 五、历史数据导入（独立功能）

### l0_import.py - 历史数据导入

从用户指定目录导入 .jsonl 和 .md 文件到 L0_raw

```bash
# 导入指定目录的所有 .jsonl 和 .md 文件
python3 scripts/l0_import.py --dir /path/to/sessions --agent xiaodai

# 递归扫描子目录
python3 scripts/l0_import.py --dir /path/to --recursive

# 干跑测试（不实际写入）
python3 scripts/l0_import.py --dir /path/to --dry-run
```

特点：
- 同时扫描 .jsonl 和 .md 文件
- 自动分片（每个文件 ≤2MB）
- 记录到时间戳日志

### migrate_history.py - 历史数据回溯

将原系统 .jsonl 文件转写到 L0_raw 格式

```bash
# 模拟运行
python3 scripts/migrate_history.py --dry-run

# 回溯全部
python3 scripts/migrate_history.py --all

# 只回溯30天内
python3 scripts/migrate_history.py --days 30
```

---

## 六、分片合并工具

### l0_split_merge.py - 分片合并

将已存在的分片文件合并为完整文件

```bash
# 合并所有分片
python3 scripts/l0_split_merge.py

# 指定目录
python3 scripts/l0_split_merge.py --dir /path/to/L0_raw/main

# 干跑测试
python3 scripts/l0_split_merge.py --dry-run
```

---

## 七、配置检查清单

| 检查项 | 命令 | 通过标准 |
|--------|------|----------|
| Python版本 | `python3 --version` | >= 3.8 |
| 向量模型 | `echo $OPENAI_API_KEY` | 非空 |
| 自启动 | `ps aux \| grep l0_watcher` | 有进程 |
| 存档目录 | `ls memory/1368-memory/` | 有子目录 |

---

## 八、快速配置命令

```bash
# 1. 启动配置向导
python3 scripts/config_wizard.py

# 2. 检查当前配置
python3 scripts/health_check.py

# 3. 查看帮助
python3 scripts/config_wizard.py --help

# 4. 重启 L0 Watcher
pkill -f l0_watcher.py && python3 scripts/auto_start.py
```

---

## 九、配置变更记录

| 日期 | 版本 | 变更内容 |
|------|------|----------|
| 2026-05-02 | v1.0.1 | 全新8步配置向导，整合所有配置步骤 |
| 2026-05-01 | v1.0.9 | 老系统配置向导 |