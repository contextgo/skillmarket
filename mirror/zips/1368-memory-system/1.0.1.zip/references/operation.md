# 1368元神记忆系统 — 操作手册

**版本：1.1**
**日期：2026-04-30**

---

## 一、系统概览

### 1.1 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                   1368元神记忆系统                            │
├─────────────────────────────────────────────────────────────┤
│  双驱：2 个向量索引                                          │
│  ├── memory_index.faiss    ← 个人记忆索引                     │
│  └── knowledge_index.faiss ← 业务知识索引                    │
├─────────────────────────────────────────────────────────────┤
│  三维：3 个分类追溯层                                         │
│  ├── L3 用户画像 ← 偏好/习惯/重要信息                        │
│  ├── L2 场景分块 ← 按业务场景分类                            │
│  └── L1 决策记录 ← WAL 标记提取的决策                        │
├─────────────────────────────────────────────────────────────┤
│  归一：1 个原始层                                             │
│  └── L0 原始对话存档 ← 最真实的记忆来源                       │
└─────────────────────────────────────────────────────────────┘
```

---

## 二、目录结构

```
/workspace/{agent}/
├── SOUL.md                 ← L3: AI 灵魂定义
├── USER.md                 ← L3: 用户信息
├── MEMORY.md              ← L3: 长期记忆
├── memory/
│   ├── sessions/          ← L0: 原始对话存档
│   │   ├── *.md         ← 当前存档
│   │   └── *-hist-*.md  ← 历史分离文件
│   ├── projects/         ← L2: 场景分块
│   │   ├── business/
│   │   ├── knowledge/
│   │   └── system/
│   ├── memory_index.faiss    ← 双驱: 个人索引
│   └── knowledge_index.faiss ← 双驱: 业务索引
└── knowledge-repo/          ← 外部知识库
    ├── 00_林哥助手/
    ├── 01_小档-建档员/
    └── ...
```

---

## 三、快速开始

### 3.1 查看系统状态

```bash
cd /root/.openclaw/workspace/main/skills/1368元神记忆系统
python3 scripts/health_check.py
```

**输出示例：**
```
==================================================
1368元神记忆系统状态
==================================================
Workspace: /root/.openclaw/workspace/main
Embedding Backend: api

[双驱：向量索引]
  个人记忆索引: OK (64 chunks)
  业务知识索引: OK (221 chunks)

[三维：分类层]
  L0 原始存档: 22 文件 (2.7MB) [阈值: 4MB]
  L1 决策记录: 4 文件 (3.0KB)
  L2 场景分块: 17 文件 (16.3KB)
  L3 用户画像: 3/3 文件 (9.2KB)

[归一：原始层]
  L0 历史文件: 查看 sessions/ 目录
```

---

### 3.2 语义搜索

```bash
python3 scripts/vector_search.py search "汪继英贷款"
```

**输出示例：**
```
[搜索] 汪继英贷款
[索引] memory_index - 找到 3 个相关
[索引] knowledge_index - 找到 5 个相关
---
[结果 1] L1: LOG-2026-04-11-01.md
  相关度: 0.85
  内容: [10:56] **[决策]** - 汪继英建档完成
  来源: /workspace/main/memory/LOG-2026-04-11-01.md
  L0路径: /workspace/main/memory/sessions/main-2026-04-11-0801-abc123.md
---
[结果 2] L2: projects/business/main-2026-04-18.md
  相关度: 0.72
  ...
```

---

### 3.3 重建向量索引

```bash
python3 scripts/build_index.py
```

**注意**：全量重建约需 30 分钟（1700+ chunks）

---

## 四、L0 Watcher 操作

### 4.1 启动 L0 Watcher

```bash
cd /root/.openclaw/workspace/main/skills/1368元神记忆系统
python3 scripts/l0_watcher.py
```

### 4.2 查看 L0 Watcher 日志

```bash
tail -f /root/.openclaw/workspace/main/memory/sessions/l0_watcher.log
```

### 4.3 L0 日志标签说明

| 标签 | 含义 |
|------|------|
| `[L0-实时]` | 检测到新消息 |
| `[L0-追加]` | 追加到 L0 存档 |
| `[L0-阈值触发]` | 超过 4MB |
| `[L0-历史分离]` | 分离 2MB 到历史文件 |
| `[L0-L1L2触发]` | 触发三维分类处理 |

---

## 五、三维分类处理

### 5.1 手动运行 L1/L2/L3 分类

```bash
# 处理所有 L0 历史文件
python3 scripts/migrate_l1_l2.py

# 处理单个文件
python3 scripts/migrate_l1_l2.py --single /path/to/hist-file.md
```

### 5.2 查看 L1 决策记录

```bash
# 查看所有决策
cat /workspace/main/memory/LOG-*.md

# 按日期查看
cat /workspace/main/memory/LOG-2026-04-22-01.md
```

### 5.3 查看 L2 场景分块

```bash
# 查看业务场景
ls /workspace/main/memory/projects/business/

# 查看知识场景
ls /workspace/main/memory/projects/knowledge/

# 查看系统场景
ls /workspace/main/memory/projects/system/
```

---

## 六、WAL 标记规范

### 6.1 支持的标记

在对话中使用以下标记，系统会自动提取到 L1：

| 标记 | 用途 | 示例 |
|------|------|------|
| `**[决策]**` | 关键决策 | `**[决策]**：确认使用方案A` |
| `**[操作]**` | 操作步骤 | `**[操作]**：执行备份脚本` |
| `**[问题]**` | 发现问题 | `**[问题]**：配置文件缺失` |
| `**[数字]**` | 关键数字 | `**[数字]**：处理了 1000 条数据` |
| `**[状态]**` | 状态更新 | `**[状态]**：服务已重启` |

### 6.2 WAL 格式

```
### [HH:MM]
- **[类型]**：[内容]
```

**示例：**
```
### [10:56]
- **[决策]**：确认使用方案A处理客户贷款
- **[数字]**：本次处理 500 万贷款额度
- **[状态]**：方案已发送给客户确认
```

---

## 七、L0 归档规则

### 8.1 文件分离规则

L0 阈值：4MB
- **文本文件（.md 等）**：达到 4MB 时，拆分成 2MB 子文件后再建索引
- **二进制文件（图片/视频/压缩包等）**：直接跳过，不建索引，不保留在 L0 会话中

**判断逻辑：**
```
文件 ≥ 4MB？
    ↓ 是
文件是纯文本？
    → 是：拆分 → 建索引
    → 否（二进制）：跳过，不处理
```

### 8.2 二进制文件处理

| 文件类型 | L0 处理方式 |
|----------|-------------|
| .md/.txt/.json | ✅ 建索引（超4MB则拆分） |
| .jpg/.png/.gif | ❌ 跳过，不建索引 |
| .mp4/.avi | ❌ 跳过，不建索引 |
| .zip/.tar | ❌ 跳过，不建索引 |

二进制文件由 OpenClaw 的媒体系统单独管理，不进入 L0 归档流程。

---

## 八、故障排查

### 7.1 L0 Watcher 无法启动

**检查**：
```bash
# 检查进程
ps aux | grep l0_watcher

# 检查 Python 环境
python3 --version

# 检查 watchdog 库
python3 -c "import watchdog; print('ok')"
```

**解决**：
```bash
pip install watchdog
```

### 7.2 向量索引搜索无结果

**检查**：
```bash
# 检查索引文件是否存在
ls -la /workspace/main/memory/*.faiss

# 重建索引
python3 scripts/build_index.py
```

### 7.3 L1/L2/L3 没有生成

**检查**：
1. L0 历史文件是否存在：`ls /workspace/main/memory/sessions/*-hist-*.md`
2. 运行分类脚本：`python3 scripts/migrate_l1_l2.py`

---

## 九、配置说明

### 8.1 L0 阈值配置

在 `scripts/l0_watcher.py` 中：

```python
# L0 阈值：达到 4MB 时触发归档
L0_SIZE_LIMIT = 4 * 1024 * 1024  # 4MB

# 分离大小：每次分离最早的 2MB
SEPARATE_SIZE = 2 * 1024 * 1024  # 2MB
```

### 8.2 Embedding 后端配置

在 `scripts/paths_config.py` 中：

```python
# Ollama 模式（推荐）
EMBEDDING_BACKEND = "ollama"
OLLAMA_URL = "http://localhost:11434"
EMBED_MODEL = "nomic-embed-text"

# API 模式
EMBEDDING_BACKEND = "api"
import os
os.environ["OPENAI_API_KEY"] = "your-key"
```

---

## 十、自动化配置

### 9.1 Cron 任务建议

```bash
# 定时任务示例（crontab -e）

# 每小时：检查 L0 Watcher 状态
0 * * * * ps aux | grep l0_watcher | grep -v grep

# 每天 18:00：重建向量索引
0 18 * * * cd /root/.openclaw/workspace/main/skills/1368元神记忆系统 && python3 scripts/build_index.py >> logs/build.log 2>&1

# 每天 23:00：检查 L1/L2 状态
0 23 * * * cd /root/.openclaw/workspace/main/skills/1368元神记忆系统 && python3 scripts/health_check.py >> logs/status.log 2>&1
```

---

## 十一、常见问题

### Q1：为什么要分离 L0 而不是一直累积？

**A**：L0 文件过大会导致：
- 向量索引构建变慢
- 读取速度下降
- 难以管理

分离后可以保持 L0 文件轻盈，同时保留完整历史。

### Q2：L1/L2/L3 有什么区别？

**A**：
- **L1 决策记录**：提取的 WAL 标记，适合快速查找决策
- **L2 场景分块**：按业务场景组织，适合主题搜索
- **L3 用户画像**：用户偏好/习惯，适合个性化服务

### Q3：可以不分离 L0 吗？

**A**：可以，但建议保持 4MB 阈值以确保系统性能。

### Q4：如何查看当前 L0 大小？

**A**：
```bash
du -sh /workspace/main/memory/sessions/*.md | sort -h
```
