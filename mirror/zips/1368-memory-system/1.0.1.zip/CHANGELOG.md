# 1368元神系统 更新日志

## v4.0.0 (2026-05-03)

### 核心修复
1. **L0分割逻辑修复**：文件超过4MB时创建新文件继续追加
2. **断点统一**：使用 `last_line_count` 记录 jsonl 行号，统一断点管理
3. **配置读取**：从 `configs/1368_config.json` 读取配置
4. **活跃会话监控**：只监控主 jsonl 文件，跳过 checkpoint 文件
5. **移除Gap Recovery自动执行**：改为手工操作

### 配置项
- L0_SIZE_LIMIT: 4mb（从配置文件读取）
- L123_SIZE_LIMIT: 400kb
- EMBEDDING_BACKEND: minimax

### 架构
- L0 Watcher: 实时监控会话文件，写入L0存档
- L1/L2/L3: 从L0提取决策/场景/画像
- archive_log: 记录断点（last_line_count）和消息统计

## v3.0.0 - v3.1.0
- 初始化版本
- 双驱三维归一记忆系统

## v1.0.1 (2026-05-06)

### 修复
- vector_search.py: 修复路径错误，现在正确使用 INDEX_CONFIG
- build_index_1368.py: INDEXES 路径改为技能目录
- health_check.py: INDEXES 路径改为技能目录

### 变更
- 索引目录迁移: 从 `memory/1368-memory/indexes/` 移到 `skills/1368-memory-system/indexes/`
- 索引文件不在被 memorySearch 索引（避免浪费资源）

### 文档
- 更新使用说明文档
- 明确搜索方式和 token 消耗
