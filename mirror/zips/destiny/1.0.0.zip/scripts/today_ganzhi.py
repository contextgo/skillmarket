#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
destiny-master: 获取今日干支信息
用法: python today_ganzhi.py
"""
import datetime
import sys

TIANGAN = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸']
DIZHI = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥']
WUXING_DIZHI = {'子':'水','丑':'土','寅':'木','卯':'木','辰':'土','巳':'火',
                '午':'火','未':'土','申':'金','酉':'金','戌':'土','亥':'水'}
WUXING_TIANGAN = {'甲':'木','乙':'木','丙':'火','丁':'火','戊':'土',
                   '己':'土','庚':'金','辛':'金','壬':'水','癸':'水'}

BASE_DATE = datetime.date(1984, 1, 1)

def get_day_ganzhi(date):
    idx = (date - BASE_DATE).days % 60
    gan = TIANGAN[idx % 10]
    zhi = DIZHI[idx % 12]
    return gan + zhi, WUXING_TIANGAN[gan] + WUXING_DIZHI[zhi]

def get_month_ganzhi(year_gan, month_num):
    """五虎遁：年干定月干"""
    month_gan_table = {'甲':'丙','乙':'戊','丙':'庚','丁':'辛',
                        '戊':'壬','己':'甲','庚':'丙','辛':'戊',
                        '壬':'庚','癸':'壬'}
    first_gan = month_gan_table[year_gan]
    first_idx = TIANGAN.index(first_gan)
    month_gan = TIANGAN[(first_idx + month_num - 1) % 10]
    zhi_list = ['寅','卯','辰','巳','午','未','申','酉','戌','亥','子','丑']
    return month_gan + zhi_list[month_num - 1]

def get_year_ganzhi(year):
    idx = (year - 1984) % 10
    zhi_idx = (year - 1984) % 12
    return TIANGAN[idx] + DIZHI[zhi_idx]

def get_today_info():
    today = datetime.date.today()
    year = today.year
    year_ganzhi = get_year_ganzhi(year)
    year_gan = year_ganzhi[0]
    month_ganzhi = get_month_ganzhi(year_gan, today.month)
    day_ganzhi, day_wuxing = get_day_ganzhi(today)
    return {
        'date': today.strftime('%Y-%m-%d'),
        'year': year_ganzhi,
        'month': month_ganzhi,
        'day': day_ganzhi,
        'day_wuxing': day_wuxing,
    }

def main():
    info = get_today_info()
    # ASCII-safe output (GBK console compatibility)
    sep = '=' * 32
    print(sep)
    print('[DATE]   ' + info['date'])
    print('[YEAR]   ' + info['year'])
    print('[MONTH]  ' + info['month'])
    print('[DAY]    ' + info['day'])
    print('[ELEMENT]' + info['day_wuxing'])
    print(sep)
    # 五行对照
    print('[INFO] 五行旺衰对照（需结合月令综合判断）')
    zhi = info['day'][-1]
    print('[INFO] 今日地支: ' + zhi + ' = ' + WUXING_DIZHI[zhi])
    print('[INFO] 喜金土者: ' + ('大吉' if WUXING_DIZHI[zhi] in ['金','土'] else '宜静待'))
    print('[INFO] 忌火水者: ' + ('谨慎' if WUXING_DIZHI[zhi] in ['火','水'] else '平稳'))

if __name__ == '__main__':
    main()
