---
name: skill-registry-manager
description: 面向 OpenClaw 的技能注册与分类管理 skill，用于识别已安装 skill 的类型、建立分类视图，并在同类任务下协调其他 skill 协作。
---

# 技能注册与分类管理

当用户表达以下需求时，使用这个 skill：

- “帮我识别当前装了哪些 skill”
- “把这些 skill 按类型分类管理”
- “哪些 skill 是同类型的，哪些可以协作”
- “当我调用某类 skill 时，顺便考虑其他 skill 协作完成任务”
- “帮我做 skill 治理、盘点、编排和协同规则”

## 设计目标

这个 skill 的目标不是替代业务 skill，而是作为技能治理层，解决 4 件事：

1. 识别当前工作区已安装的 skills
2. 根据职责把 skills 自动归类
3. 建立同类 skill 和跨类 skill 的协作关系
4. 在用户触发某类任务时，主动考虑是否需要其他 skill 辅助完成

## 分类范围

默认扫描工作区内：

- `skills/**/SKILL.md`

默认不把以下内容当作业务 skill：

- `.github/skills/**`
- `skills/*_GUIDE.md`
- `skills/*OVERVIEW*.md`
- 其他非 `SKILL.md` 的说明文件

## 分类方法

分类时优先读取每个 skill 的：

1. frontmatter 中的 `name`
2. frontmatter 中的 `description`
3. 正文里的“当用户表达以下需求时”或“适合的用户指令”
4. 正文中的默认工作流程和输出要求

然后按 [../SKILL_TYPE_TAXONOMY.md](../SKILL_TYPE_TAXONOMY.md) 中的规则归类。

## 默认类型

优先归为以下类型之一：

- `analysis-reporting`：分析与报告类
- `opportunity-selection`：机会筛选与缩圈类
- `risk-control`：风险守护与防守类
- `workflow-orchestration`：流程编排与定时类
- `skill-governance`：技能治理与分类管理类
- `execution-support`：执行辅助类
- `delivery-integration`：外部推送与交付类

如果一个 skill 同时覆盖多个类型，必须明确：

- `primary_type`
- `secondary_types`

## 主动工作流程

### 1. 盘点已安装 skills

先扫描 `skills/**/SKILL.md`，列出：

- skill 名称
- skill 路径
- 描述
- 初步类型判断

### 2. 建立分类视图

输出至少要有两种视图：

- 按 skill 列表查看
- 按类型分组查看

### 3. 建立协作关系

每个 skill 至少应映射：

- `primary_role`：主负责什么
- `support_roles`：在哪些场景下适合作为辅助 skill
- `collaborates_with`：推荐协作的其他 skill

### 4. 同类任务下主动考虑协作

当用户调用某类 skill 时，不要默认只用一个 skill 机械处理。

应按以下规则判断是否需要协作：

#### `analysis-reporting`

主 skill 可单独完成日报，但如果用户要求更强行动性，应考虑协作：

- `opportunity-selection`
- `risk-control`

#### `opportunity-selection`

主 skill 负责缩圈，但如果用户要求可执行性或风险过滤，应考虑协作：

- `analysis-reporting`
- `risk-control`

#### `risk-control`

主 skill 负责防守，但如果用户需要替代标的或重新缩圈，应考虑协作：

- `opportunity-selection`
- `analysis-reporting`

#### `workflow-orchestration`

主 skill 负责定时和自动化，但如果用户要落地真实产出，应考虑协作：

- `analysis-reporting`
- `skill-governance`

### 5. 协作时的选择约束

不要每次都把所有 skill 全部拉进来。

默认原则：

1. 选择 1 个主 skill
2. 最多再加 2 个明确增值的辅助 skill
3. 如果辅助 skill 不增加结果质量，就不要硬加

## 输出要求

当用户要求“分类管理”时，至少输出：

- 已安装 skill 清单
- 每个 skill 的类型
- 每个类型下包含哪些 skill
- 推荐协作关系
- 哪些类型已经覆盖，哪些类型仍缺失

如果需要形成稳定的目录化输出，优先参考：

- `skills/SKILL_REGISTRY_REPORT_TEMPLATE.md`

如果需要查看当前工作区的一份真实样例，可参考：

- `skills/SKILL_REGISTRY_CURRENT_REPORT.md`

当用户要求“任务协同”时，至少输出：

- 本次任务建议的主 skill
- 本次任务建议的辅助 skill
- 为什么需要协作
- 如果不协作会损失什么

## 管理建议

如果用户没有额外要求，应主动补充：

1. 是否需要我生成一份当前工作区的 skill 分类目录
2. 是否需要我把新 skill 接入到触发指令和固定口令清单
3. 是否需要我识别重复能力和职责冲突

## 约束

1. 不要把普通说明文档误识别成业务 skill。
2. 不要因为“能协作”就默认所有 skill 一起上。
3. 归类时优先看职责，而不是只看 skill 名称。
4. 如果当前工作区 skill 数量很少，也要明确说明分类结果，不要强行编造复杂结构。
