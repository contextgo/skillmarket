---
name: photo-poses
description: Recommend photography poses and composition tips for different scenarios. Use when the user asks about拍照姿势、怎么摆姿势、拍照动作、pose推荐、拍照技巧、合影姿势、情侣拍照、单人拍照、旅行拍照等场景。Covers solo, couples, groups, travel, selfies, and professional portraits.
---

# Photo Poses — 拍照姿势推荐

Recommend natural, flattering poses based on the user's scenario, number of people, and vibe.

## Quick Workflow

1. Identify scenario (solo/couple/group/travel/selfie/professional)
2. Identify vibe (casual/romantic/fun/elegant/cool)
3. Recommend 3-5 specific poses with body positioning details
4. Include 1-2 composition/lighting tips per recommendation

## Core Posing Principles

- **Angles > Front-facing** — ¾ body angle is universally flattering
- **Create triangles** — Bent elbows, knees, or tilted head add dynamism
- **Weight on one leg** — Shift weight to back leg for natural stance
- **Hands need purpose** — In pocket, touching hair, holding something
- **Elongate neck** — Push chin slightly forward and down
- **Relax shoulders** — Roll back and down, breathe out

## Bundled Resources

| Type | Path | Description |
|------|------|-------------|
| Photos | `assets/poses/` | Reference photos for each pose category |
| References | `references/solo.md` | 单人拍照姿势 (含示意图) |
| References | `references/couples.md` | 情侣拍照姿势 (含示意图) |
| References | `references/groups.md` | 多人合影姿势 |
| References | `references/travel.md` | 旅行打卡姿势 |
| References | `references/selfies.md` | 自拍/他拍技巧 |
| Solo/单人 | `references/solo.md` | 个人写真、日常自拍、街拍 |
| Couples/情侣 | `references/couples.md` | 情侣照、婚纱、纪念日 |
| Groups/多人 | `references/groups.md` | 闺蜜照、家庭合影、团队 |
| Travel/旅行 | `references/travel.md` | 旅行打卡、景点拍照 |
| Selfies/自拍 | `references/selfies.md` | 自拍、对镜拍、他拍 |

## Output Format

```markdown
### 📸 推荐姿势

**姿势1: [名称]**
- 身体朝向：...
- 手部动作：...
- 面部表情：...
- 💡 小贴士：...

**姿势2: [名称]**
- ...

### 🎯 构图建议
- ...
```

## Tips by Body Concern

- **显高**：低角度拍摄，脚贴画面底部，一条腿前伸
- **显瘦**：¾侧面，一手叉腰制造腰部曲线，微收下巴
- **显脸小**：头发遮一侧脸，手托下巴或摸头发，微微低头
- **显腿长**：一脚前伸重心在后，脚尖指向镜头
