package ${packageName}.config.cache;

import cn.hutool.crypto.digest.MD5;
import cn.hutool.crypto.symmetric.AES;
import com.alibaba.fastjson2.JSON;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * @author ${author}
 * @since ${date}
 */
@Aspect
@Component
public class CacheDataAnnotationAop {

    @Autowired
    private RedisTemplate<String,Object> redisTemplate;

    // SpEL解析器
    private static final ExpressionParser PARSER = new SpelExpressionParser();

    // 默认是AES/ECB/PKCS5Padding，指定key，防止相同的内容生成不同的密文
    private static final AES AES_UTIL = new AES("1234567890abcdef".getBytes(StandardCharsets.UTF_8));
    private static final MD5 MD5_UTIL = MD5.create();

    @Around("@annotation(cacheDataAnnotation)")
    public Object around(ProceedingJoinPoint joinPoint, CacheDataAnnotation cacheDataAnnotation) throws Throwable {
        String cacheKey = parseKey(joinPoint, cacheDataAnnotation);

        Object data = redisTemplate.opsForValue().get(cacheKey);
        if (null != data) {
            return data;
        }
        // 解析和保存json字符串
        // String data = redisTemplate.opsForValue().get(chacheKey);
        // if (StringUtils.isNotBlank(data)) {
        //     // 获取返回值类型
        //     Class<?> returnType = ((MethodSignature) joinPoint.getSignature()).getReturnType();
        //     return JSON.parseObject(data, returnType);
        // }
        // redisTemplate.opsForValue().set(cacheKey,JSON.toJSONString(returnData),cacheDataAnnotation.expire(), cacheDataAnnotation.timeUnit());

        Object returnData = joinPoint.proceed();
        if (null != returnData) {
            redisTemplate.opsForValue().set(cacheKey,returnData,cacheDataAnnotation.expire(), cacheDataAnnotation.timeUnit());
        }
        return returnData;
    }


    /**
     * 解析缓存key
     * @param joinPoint joinPoint
     * @param cacheDataAnnotation 缓存注解
     * @return 缓存key
     */
    private String parseKey(ProceedingJoinPoint joinPoint,CacheDataAnnotation cacheDataAnnotation){
        String keyPrefix = cacheDataAnnotation.cacheKeyPrefix();
        String key = cacheDataAnnotation.key();
        String spElKey = cacheDataAnnotation.spElKey();
        if (StringUtils.isNotBlank(key)) {
            return keyPrefix+key;
        }
        if (StringUtils.isNotBlank(spElKey)) {
            String spElKeyValue = parseSpElKey(spElKey, joinPoint);
            return keyPrefix+spElKeyValue;
        }
        String methodKey = useMethodKeyMd5(joinPoint);
        return keyPrefix+methodKey;
    }


    /**
     * 使用方法和参数当作key（AES加密参数）
     * @param joinPoint joinPoint
     * @return 返回key
     */
    private static String useMethodKey(ProceedingJoinPoint joinPoint) {
        String className = joinPoint.getTarget().getClass().getName();
        Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();
        String methodName = method.getName();
        Object[] args = joinPoint.getArgs();

        StringBuilder argsBuilder = new StringBuilder();
        if (ArrayUtils.isNotEmpty(args)) {
            argsBuilder.append(":");
            for (Object arg : args) {
                String aesArg = AES_UTIL.encryptHex(JSON.toJSONString(arg));
                argsBuilder.append(aesArg);
            }
        }
        return className + "." + methodName+argsBuilder;
    }

    /**
     * 使用方法和参数当作key（MD5加密参数）
     * @param joinPoint joinPoint
     * @return 返回key
     */
    private static String useMethodKeyMd5(ProceedingJoinPoint joinPoint) {
        String className = joinPoint.getTarget().getClass().getName();
        Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();
        String methodName = method.getName();
        Object[] args = joinPoint.getArgs();

        StringBuilder argsBuilder = new StringBuilder();
        if (ArrayUtils.isNotEmpty(args)) {
            argsBuilder.append(":");
            for (Object arg : args) {
                String md5Arg = MD5_UTIL.digestHex(JSON.toJSONString(arg));
                argsBuilder.append(md5Arg);
            }
        }
        return className + "." + methodName+argsBuilder;
    }


    /**
     * 解析SpEL表达式
     * @param spElKey el表达式
     * @param joinPoint joinPoint
     * @return 解析后的key
     */
    private String parseSpElKey(String spElKey,ProceedingJoinPoint joinPoint){
        StandardEvaluationContext context = new StandardEvaluationContext();
        // 将方法的参数传入SpEL上下文
        Object[] args = joinPoint.getArgs();
        String[] parameterNames = getParameterNames(joinPoint);

        for (int i = 0; i < args.length; i++) {
            context.setVariable(parameterNames[i], args[i]);
        }
        return PARSER.parseExpression(spElKey).getValue(context, String.class);
    }


    /**
     * 获取方法参数名
     * @param joinPoint joinPoint
     * @return 参数名
     */
    private String[] getParameterNames(JoinPoint joinPoint) {
        Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();
        return Arrays.stream(method.getParameters())
                .map(Parameter::getName)
                .toArray(String[]::new);
    }
}
