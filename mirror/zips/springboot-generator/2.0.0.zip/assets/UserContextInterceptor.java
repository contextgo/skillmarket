package ${packageName}.config;

import ${packageName}.common.UserContext;
import ${packageName}.utils.RequestUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * 用户上下文拦截器
 * 从请求头获取userCode和requestId，放入UserContext
 * 请求结束后清空UserContext
 * @author ${author}
 */
@Slf4j
public class UserContextInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // 从请求头获取userCode和requestId
        try {
            String userCode = request.getHeader(RequestUtil.USER_CODE_HEADER);
            String requestId = request.getHeader(RequestUtil.REQUEST_ID_HEADER);

            // 放入UserContext
            UserContext.setUserCode(userCode);
            UserContext.setRequestId(requestId);
            MDC.put("x-user",userCode);
            MDC.put("x-request-id", requestId);
        } catch (Exception e) {
            log.error("UserContextInterceptor.preHandle error", e);
        }
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        // 请求结束后清空UserContext，防止内存泄漏
        try {
            UserContext.remove();
        } catch (Exception e) {
            log.error("UserContextInterceptor.afterCompletion error", e);
        }
        try {
            MDC.clear();
        } catch (Exception e) {
            log.error("UserContextInterceptor.afterCompletion error", e);
        }
    }
}
