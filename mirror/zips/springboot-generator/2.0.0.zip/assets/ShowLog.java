package ${packageName}.config.log;

import java.lang.annotation.*;

/**
 * 打印日志信息
 *
 * @author ${author}
 * @since ${date}
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ShowLog {
    /**
     * 日志描述
     */
    String value();

    /**
     * 是否开启日志打印，默认true-开启
     */
    boolean enabled() default true;

    /**
     * 是否打印请求参数
     */
    boolean showArgs() default true;

    /**
     * 是否打印返回值
     */
    boolean showResult() default true;

    /**
     * 是否打印耗时
     */
    boolean showTime() default true;

}
