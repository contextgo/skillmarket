package ${packageName}.config.log;

import com.alibaba.fastjson2.JSON;
import ${packageName}.common.UserContext;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author ${author}
 */
@Slf4j
@Aspect
@Component
public class ShowLogHandler {

    @Around("@annotation(showLog)")
    public Object handle(ProceedingJoinPoint joinPoint, ShowLog showLog) throws Throwable {
        if (!showLog.enabled()) {
            return joinPoint.proceed();
        }
        boolean isSuccess = true;
        long startTime = 0;
        String desc = showLog.value();

        // 获取类名和方法名
        String className = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        String fullName = className + "." + methodName;
        String args = null;

        log.info("<<==[{}]打印日志[{}]", desc,fullName);

        try {
            // 计算耗时
            if (showLog.showTime()) {
                startTime = System.currentTimeMillis();
            }
            // 获取参数
            if (showLog.showArgs()) {
                try {
                    // 参数过滤
                    args = JSON.toJSONString(filterArgs(joinPoint.getArgs()));
                    log.info("<<==[{}]参数{}",desc, args);
                } catch (Exception e) {
                    log.error("日志打印参数失败[{}]",e.getMessage());
                }
            }
            // 执行方法
            Object result = joinPoint.proceed();
            // 获取结果
            if (showLog.showResult()) {
                try {
                    log.info("==>>[{}]方法返回值:[{}]", desc, JSON.toJSONString(result));
                } catch (Exception e) {
                    log.error("日志打印返回值失败[{}]",e.getMessage());
                }
            }
            return result;
        } catch (Throwable e) {
            // 记录错误堆栈信息
            isSuccess = false;
            log.error("==>>[{}]方法出错:[{}]", desc, e.getMessage());
            throw e;
        } finally {
            if (showLog.showTime()) {
                long endTime = System.currentTimeMillis();
                log.info("==>>[{}]方法耗时[{}]毫秒,[{}]", desc, endTime - startTime, isSuccess);
            }

        }

    }


    /**
     * 参数过滤
     * @param args 参数
     * @return 过滤后的参数
     */
    private List<Object> filterArgs(Object[] args) {
        if (ArrayUtils.isEmpty(args)) {
            return Collections.emptyList();
        }
        List<Object> result = new ArrayList<>(args.length);

        for (Object arg : args) {
            if (arg instanceof ServletRequest) {
                continue;
            }
            if (arg instanceof ServletResponse) {
                continue;
            }
            result.add(arg);
        }

        return result;
    }


}
