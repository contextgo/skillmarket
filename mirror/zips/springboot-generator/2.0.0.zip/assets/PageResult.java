package ${packageName}.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * 分页结果类
 *
 * @author ${author}
 * @since ${date}
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class PageResult extends Result<List<?>> {

    /**
     * 总记录数
     */
    private long total;

    /**
     * 当前页码
     */
    private int pageNum;

    /**
     * 每页大小
     */
    private int pageSize;


    /**
     * 创建空的分页结果
     */
    public static PageResult empty(int pageNum, int pageSize) {
        return new PageResult(0, pageNum, pageSize);
    }

    /**
     * 创建分页结果
     */
    public static PageResult of(long total, int pageNum, int pageSize, List<?> records) {
        PageResult pageResult = new PageResult(total, pageNum, pageSize);
        pageResult.setData(records);
        return pageResult;
    }
}
