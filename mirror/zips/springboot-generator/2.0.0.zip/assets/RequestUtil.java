package ${packageName}.utils;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * request对象工具
 *
 * @author ${author}
 * @since ${date}
 */
@Slf4j
public class RequestUtil {

    public static final String REQUEST_ID_HEADER = "x-request-id";
    public static final String USER_CODE_HEADER = "X-USER";


    public static HttpServletRequest getRequest() {
        try {
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            return requestAttributes != null ? requestAttributes.getRequest() : null;
        } catch (Exception e) {
            log.error("获取request对象失败[{}]", e.getMessage());
            return null;
        }
    }

    /**
     * 获取请求头
     */
    public static String getHeader(String headerName) {
        try {
            if (StringUtils.isBlank(headerName)) {
                return "";
            }
            HttpServletRequest request = getRequest();
            if (request == null) {
                return "";
            }
            String header = request.getHeader(headerName);
            return StringUtils.defaultString(header);
        } catch (Exception e) {
            log.error("获取请求头[{}]失败[{}]", headerName, e.getMessage());
            return "";
        }
    }


    /**
     * 获取当前登录用户
     */
    public static String getCurrentUserCode() {
        return getHeader(USER_CODE_HEADER);
    }

    /**
     * 获取请求id
     */
    public static String getRequestId() {
        return getHeader(REQUEST_ID_HEADER);
    }

    /**
     * 获取token
     */
    public static String getToken() {
        String header = getHeader("Authorization");
        if (StringUtils.isBlank(header)) {
            return null;
        }

        Pattern pattern = Pattern.compile("(?i)^Bearer\\s+(.+)$");
        Matcher matcher = pattern.matcher(header);

        if (matcher.find()){
			return matcher.group(1);
		}
        return null;
    }

}