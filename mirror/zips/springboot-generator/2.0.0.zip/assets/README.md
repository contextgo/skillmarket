# ${projectName}

## 项目简介

这是一个基于SpringBoot ${springBootVersion}的标准项目脚手架,集成了常用的开发组件和最佳实践。

## 技术栈

- **SpringBoot**: ${springBootVersion}
- **MyBatis Plus**: ${mybatisPlusVersion}
- **Redis**: Spring Data Redis
- **Knife4j**: ${knife4jVersion} (Swagger增强)
- **MySQL**: ${mysqlVersion}

## 项目结构

```
${artifactId}/
├── src/main/java/${packagePath}/
│   ├── ${className}Application.java     # 启动类
│   ├── common/                          # 公共模块
│   │   ├── Result.java                 # 统一响应
│   │   ├── ResultCode.java             # 响应码
│   │   ├── BizException.java           # 业务异常
│   │   └── GlobalExceptionHandler.java # 全局异常处理
│   ├── config/                          # 配置类
│   ├── controller/                      # 控制器
│   ├── service/                         # 服务层
│   │   └── impl/                       # 服务实现
│   ├── mapper/                          # Mapper接口
│   ├── entity/                          # 实体类
│   └── utils/                           # 工具类
└── src/main/resources/
    └── application.yml                 # 配置文件
```

## 快速开始

### 1. 环境准备

- JDK 17+
- Maven 3.6+
- MySQL 8.0+
- Redis (可选)

### 2. 数据库配置

创建数据库:
```sql
CREATE DATABASE ${artifactId} DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
```

修改`application.yml`中的数据库配置。

### 3. 启动项目

```bash
mvn clean install
mvn spring-boot:run
```

访问: http://localhost:8080/${artifactId}

### 4. 访问API文档

访问Knife4j文档: http://localhost:8080/${artifactId}/doc.html

## 开发规范

### 1. 方法入参判空

所有方法入参必须进行判空处理,优先使用工具类判断。

### 2. 方法返回值避免null

方法返回时尽量避免返回null,应返回合理的默认值。

### 3. 代码注释

所有类必须包含标准注释(说明、作者、创建时间)。

## 作者

${author}

## 最后更新

${date}
