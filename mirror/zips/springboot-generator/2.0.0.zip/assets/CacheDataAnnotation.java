package ${packageName}.config.cache;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.concurrent.TimeUnit;

/**
 * 缓存注解
 *
 * @author ${author}
 * @since ${date}
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface CacheDataAnnotation {

    /**
     * 缓存key，优先使用
     */
    String key() default "";

    /**
     * 缓存spElKey，el表达式
     */
    String spElKey() default "";

    /**
     * key前缀
     */
    String cacheKeyPrefix() default "project:cache:";

    /**
     * 缓存时间分钟,默认60L=1小时
     */
    long expire() default 60L;

    TimeUnit timeUnit() default TimeUnit.MINUTES;

}
