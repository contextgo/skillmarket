package ${packageName}.common;

import lombok.Data;

/**
 * 用户上下文工具类
 * 使用ThreadLocal存储当前请求的userCode和requestId
 * ${packageName}.config.UserContextInterceptor负责设置userCode和requestId
 *
 * @author ${author}
 * @since ${date}
 */
public class UserContext {

    private static final ThreadLocal<UserDTO> USER_THREAD_LOCAL = ThreadLocal.withInitial(UserDTO::new);

    @Data
    public static class UserDTO {
        private String userCode;
        private String requestId;
    }

    /**
     * set userCode方法
     */
    public static void setUserCode(String userCode) {
        USER_THREAD_LOCAL.get().setUserCode(userCode);
    }

    /**
     * get userCode方法
     */
    public static String getUserCode() {
        return USER_THREAD_LOCAL.get().getUserCode();
    }

    /**
     * set requestId方法
     */
    public static void setRequestId(String requestId) {
        USER_THREAD_LOCAL.get().setRequestId(requestId);
    }

    /**
     * get requestId方法
     */
    public static String getRequestId() {
        return USER_THREAD_LOCAL.get().getRequestId();
    }

    /**
     * 清空方法
     */
    public static void remove() {
        USER_THREAD_LOCAL.remove();
    }
}
