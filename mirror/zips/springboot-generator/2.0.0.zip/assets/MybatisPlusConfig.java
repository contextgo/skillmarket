package ${packageName}.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;

/**
 * MyBatis Plus配置类
 *
 * @author ${author}
 * @since ${date}
 */
@Configuration
public class MybatisPlusConfig {

    /**
     * 分页插件
     */
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }


    /**
     * MyBatis-Plus 自动填充处理器
     * 填充字段 createTime, updateTime, 填充类型 LocalDateTime
     */
    @Bean
    public MetaObjectHandler metaObjectHandler() {
        return new MetaObjectHandler() {
            private static final String CREATE_TIME = "createTime";
            private static final String UPDATE_TIME = "updateTime";

            @Override
            public void insertFill(MetaObject metaObject) {
                LocalDateTime now = LocalDateTime.now();
                // 填充 createTime 字段（如果存在）
                if (metaObject.hasSetter(CREATE_TIME)) {
                    this.strictInsertFill(metaObject, CREATE_TIME, LocalDateTime.class, now);
                }
                // 填充 updateTime 字段（如果存在）
                if (metaObject.hasSetter(UPDATE_TIME)) {
                    this.strictInsertFill(metaObject, UPDATE_TIME, LocalDateTime.class, now);
                }
            }

            @Override
            public void updateFill(MetaObject metaObject) {
                LocalDateTime now = LocalDateTime.now();
                // 填充 updateTime 字段（如果存在）
                if (metaObject.hasSetter(UPDATE_TIME)) {
                    this.strictUpdateFill(metaObject, UPDATE_TIME, LocalDateTime.class, now);
                }
            }
        };
    }

}
