package ${packageName}.common;

import lombok.Getter;

/**
 * 业务异常
 *
 * @author ${author}
 * @since ${date}
 */
@Getter
public class BizException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * 错误码
     */
    private final Integer code;

    /**
     * 错误消息
     */
    private final String message;

    public BizException() {
        super(ResultCode.BIZ_ERROR.getMessage());
        this.code = ResultCode.BIZ_ERROR.getCode();
        this.message = ResultCode.BIZ_ERROR.getMessage();
    }

    public BizException(String message) {
        super(message);
        this.code = ResultCode.BIZ_ERROR.getCode();
        this.message = message;
    }

    public BizException(Integer code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }

    public BizException(ResultCode resultCode) {
        super(resultCode.getMessage());
        this.code = resultCode.getCode();
        this.message = resultCode.getMessage();
    }

}
