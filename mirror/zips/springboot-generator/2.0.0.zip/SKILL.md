---
name: springboot-generator
description: 生成标准化的SpringBoot项目脚手架,包含完整的配置、工具类、统一响应处理、异常处理等功能。当用户需要创建一个新的SpringBoot项目时使用此技能。触发场景包括:(1)创建新SpringBoot项目,(2)生成项目脚手架,(3)初始化项目结构,(4)快速搭建项目框架。
---

# SpringBoot项目生成器

## 概述

本Skill用于快速生成标准化的SpringBoot项目脚手架,**直接在当前工作目录生成项目结构**,无需创建子目录。包含完整的配置、工具类、统一响应处理、异常处理等最佳实践。

## 快速开始

### 1. 确认项目参数

AI会询问用户以下参数:

| 参数 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| groupId | 是 | - | 项目groupId,如com.example |
| artifactId | 否 | 当前目录名 | 项目artifactId,默认使用当前工作目录名 |
| version | 否 | 1.0.0 | 项目版本号 |
| springBootVersion | 否 | 3.2.0 | SpringBoot版本 |
| packageName | 否 | groupId | 主包名 |
| author | 否 | CodeArts | 作者信息 |

### 2. 动态参数说明

**自动获取的参数:**
- **当前目录名**: 通过`pwd`命令获取当前工作目录,提取目录名作为默认artifactId
- **application.name**: 使用当前目录名
- **context-path**: 使用`/当前目录名`

**示例:**
- 当前目录: `C:\Users\Admin\Desktop\x`
- 目录名: `x`
- application.name: `x`
- context-path: `/x`

### 3. 版本映射

根据SpringBoot版本自动匹配依赖版本:

| SpringBoot版本 | MyBatisPlus | Knife4j | MySQL Connector |
|---------------|-------------|---------|-----------------|
| 3.5.x         | 3.5.5       | 4.5.0   | 8.0.33          |
| 3.2.x         | 3.5.5       | 4.4.0   | 8.0.33          |
| 3.1.x         | 3.5.4       | 4.3.0   | 8.0.33          |
| 2.7.x         | 3.5.3       | 4.1.0   | 8.0.29          |

### 4. 执行流程

AI将按以下步骤生成项目:

1. **获取当前目录** - 使用`pwd`命令获取当前工作目录
2. **提取目录名** - 从路径中提取目录名作为默认artifactId
3. **询问参数** - 询问用户groupId等参数,artifactId默认使用目录名
4. **创建目录结构** - 在当前目录直接创建src等目录结构
5. **生成配置文件** - 读取assets模板,替换占位符,生成pom.xml和application.yml
6. **生成核心类** - 生成统一响应、异常处理、分页、用户上下文等核心类
7. **生成配置类** - 生成MyBatis Plus、Redis、Knife4j、WebMvc、响应 advice、日志切面、缓存AOP等配置类
8. **复制静态资源** - 复制 `assets/resources/static/favicon.ico` 到 `src/main/resources/static/favicon.ico`
9. **生成文档** - 生成README.md项目说明文档

## 项目结构

生成的项目结构(直接在当前目录):

```
当前目录/
├── pom.xml
├── README.md
└── src/
    ├── main/
    │   ├── java/${packagePath}/
    │   │   ├── ${className}Application.java
    │   │   ├── common/
    │   │   │   ├── Result.java
    │   │   │   ├── ResultCode.java
    │   │   │   ├── BizException.java
    │   │   │   ├── GlobalExceptionHandler.java
    │   │   │   ├── PageResult.java
    │   │   │   └── UserContext.java
    │   │   ├── config/
    │   │   │   ├── MybatisPlusConfig.java
    │   │   │   ├── RedisConfig.java
    │   │   │   ├── Knife4jConfig.java
    │   │   │   ├── WebMvcConfig.java
    │   │   │   ├── ResponseAdvice.java
    │   │   │   ├── UserContextInterceptor.java
    │   │   │   ├── log/
    │   │   │   │   ├── ShowLog.java
    │   │   │   │   └── ShowLogHandler.java
    │   │   │   └── cache/
    │   │   │       ├── CacheDataAnnotation.java
    │   │   │       └── CacheDataAnnotationAop.java
    │   │   ├── controller/
    │   │   ├── service/
    │   │   │   └── impl/
    │   │   ├── mapper/
    │   │   ├── entity/
    │   │   └── utils/
    │   │       └── RequestUtil.java
    │   └── resources/
    │       ├── application.yml
    │       └── static/
    │           └── favicon.ico
    └── test/
        └── java/${packagePath}/
```

## 模板文件说明

所有模板文件位于`assets/`目录,使用占位符`${param}`标记需要替换的内容:

| 模板文件 | 说明 |
|---------|------|
| pom.xml | Maven配置模板 |
| application.yml | SpringBoot配置模板 |
| DemoApplication.java | 启动类模板 |
| Result.java | 统一响应类模板 |
| ResultCode.java | 响应码常量类模板 |
| BizException.java | 业务异常类模板 |
| GlobalExceptionHandler.java | 全局异常处理器模板 |
| PageResult.java | 分页结果类模板 |
| UserContext.java | 用户上下文模板 |
| ResponseAdvice.java | 全局响应处理器模板 |
| UserContextInterceptor.java | 用户上下文拦截器模板 |
| WebMvcConfig.java | Web MVC配置模板 |
| MybatisPlusConfig.java | MyBatis Plus配置模板 |
| RedisConfig.java | Redis配置模板 |
| Knife4jConfig.java | Knife4j配置模板 |
| ShowLog.java | 日志注解模板 |
| ShowLogHandler.java | 日志切面处理器模板 |
| CacheDataAnnotation.java | 缓存注解模板 |
| CacheDataAnnotationAop.java | 缓存AOP实现模板 |
| RequestUtil.java | 请求工具类模板 |
| resources/static/favicon.ico | 网站图标静态资源 |
| README.md | 项目说明文档模板 |

### 占位符说明

| 占位符 | 说明 | 示例 |
|--------|------|------|
| ${groupId} | 项目groupId | com.example |
| ${artifactId} | 项目artifactId(当前目录名) | x |
| ${version} | 项目版本 | 1.0.0 |
| ${springBootVersion} | SpringBoot版本 | 3.2.0 |
| ${packageName} | 主包名 | com.example.x |
| ${packagePath} | 包路径 | com/example/x |
| ${className} | 启动类名 | XApplication |
| ${projectName} | 项目名称(当前目录名) | x |
| ${author} | 作者 | CodeArts |
| ${date} | 创建日期 | 2026-04-24 |
| ${mybatisPlusVersion} | MyBatis Plus版本 | 3.5.5 |
| ${knife4jVersion} | Knife4j版本 | 4.4.0 |
| ${mysqlVersion} | MySQL版本 | 8.0.33 |
| ${hutoolVersion} | Hutool版本 | 5.8.25 |
| ${commonsLang3Version} | Commons Lang3版本 | 3.14.0 |
| ${commonsCollections4Version} | Commons Collections4版本 | 4.4 |
| ${fastjson2Version} | Fastjson2版本 | 2.0.43 |

## 代码规范

生成的代码遵循以下规范:

### 1. 方法入参判空

所有方法入参必须进行判空处理,优先使用工具类判断:
- 字符串: `StringUtils.isBlank()` / `StringUtils.isNotBlank()`
- 集合: `CollectionUtils.isEmpty()` / `CollectionUtils.isNotEmpty()`
- 对象: `Objects.isNull()` / `Objects.nonNull()`

### 2. 方法返回值避免null

方法返回时尽量避免返回null,应返回合理的默认值:
- 数值类型: 返回 0 或 0.0
- 集合类型: 返回空集合
- 字符串类型: 返回空字符串 ""

### 3. 代码注释

所有类必须包含标准注释(说明、作者、创建时间)。

### 4. 日志规范

Service类使用`@Slf4j`注解,关键操作记录日志。

## 功能特性

### 1. 统一响应格式

所有接口返回统一的响应格式:
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {}
}
```

### 2. 全局异常处理

自动捕获并处理各类异常,返回友好的错误信息。

### 3. 参数校验

支持JSR-303参数校验,自动返回校验错误信息。

### 4. 分页支持

集成MyBatis Plus分页插件,支持分页查询。

### 5. Redis缓存

配置了Redis序列化,支持对象缓存。

### 6. API文档

集成Knife4j,提供在线API文档。

## 注意事项

1. **直接在当前目录生成** - 不会创建子目录,直接在当前工作目录生成项目结构
2. **目录名作为项目名** - 默认使用当前目录名作为artifactId、application.name和context-path
3. **JDK版本**: 项目使用JDK 17,确保环境已安装
4. **数据库配置**: 生成后需修改application.yml中的数据库连接信息
5. **Redis配置**: 如不使用Redis,可移除相关依赖和配置
6. **包名规范**: 建议使用标准的包名格式,如com.company.project

## 常见问题

### Q1: 为什么不创建子目录?

A: 为了简化项目结构,直接在当前目录生成,避免嵌套目录。例如在`C:\Users\Admin\Desktop\x`目录下直接生成src、pom.xml等。

### Q2: 如何修改项目名?

A: 默认使用当前目录名,如需修改可在询问参数时指定artifactId。

### Q3: 如何修改SpringBoot版本?

A: 在询问参数时指定springBootVersion,如3.1.0,依赖版本会自动匹配。

### Q4: 如何添加更多功能模块?

A: 项目生成后,可根据需要在controller、service、mapper、entity包下添加业务代码。

### Q5: 如何关闭Swagger?

A: 在application.yml中设置`knife4j.enable: false`。

### Q6: 生成的项目如何启动?

A:
1. 创建数据库(数据库名为当前目录名)
2. 修改数据库配置
3. 执行`mvn clean install`
4. 执行`mvn spring-boot:run`
5. 访问`http://localhost:8080/${artifactId}`

## 资源文件

- `assets/pom.xml` - Maven配置模板
- `assets/application.yml` - SpringBoot配置模板
- `assets/DemoApplication.java` - 启动类模板
- `assets/Result.java` - 统一响应类模板
- `assets/ResultCode.java` - 响应码常量类模板
- `assets/BizException.java` - 业务异常类模板
- `assets/GlobalExceptionHandler.java` - 全局异常处理器模板
- `assets/resources/static/favicon.ico` - 网站图标静态资源
- `assets/README.md` - 项目说明文档模板
