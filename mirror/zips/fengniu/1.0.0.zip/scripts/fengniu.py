#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
疯牛 v2.0 - 涨停捕捉模型（基于回测数据重构）
==================================================
v2.0 核心改进（2026-05-04 基于回测数据）：
1. 移除"首板启动"维度（回测显示首板信号反效果：连板率8.5% vs 非首板26.4%）
2. 新增"连板辨识度"维度（市场偏好有辨识度的标的）
3. 保留"资金进场"作为最高权重（最强预测因子：连板率32.7% vs 3.9%）
4. 移除"二次启动"维度（95%涨停股都有，完全无区分度）
5. 新增"量波共振"维度替代综合过滤
6. 提高信号阈值：>=80强信号，60-79中等，<60观望

Usage:
    python -X utf8 fengniu.py --date YYYYMMDD --top 10 --html
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

import akshare as ak
import pandas as pd
import numpy as np


# ============================================================
# 工具函数
# ============================================================

def get_latest_trading_date():
    """获取最近一个交易日（跳过周末）"""
    d = datetime.now()
    if d.weekday() < 5 and d.hour < 15:
        d -= timedelta(days=1)
    while d.weekday() >= 5:
        d -= timedelta(days=1)
    return d.strftime('%Y%m%d')


def safe_get(df, col, idx=0, default=0.0):
    try:
        if df is None or df.empty:
            return default
        val = df.iloc[idx][col]
        if pd.isna(val):
            return default
        return float(val)
    except (KeyError, IndexError, ValueError):
        return default


def safe_str(df, col, idx=0, default=''):
    try:
        if df is None or df.empty:
            return default
        val = str(df.iloc[idx][col])
        return val.strip() if val != 'nan' else default
    except (KeyError, IndexError):
        return default


# ============================================================
# 数据获取层
# ============================================================

class FNADataFetcher:
    """疯牛模型统一数据接口"""

    def __init__(self, target_date):
        self.target_date = target_date
        self._cache = {}

    def get_stock_hist(self, code, days=120):
        key = 'hist_' + code
        if key in self._cache:
            return self._cache[key]
        try:
            end_date = self.target_date
            start_dt = datetime.strptime(self.target_date, '%Y%m%d') - timedelta(days=days)
            start_date = start_dt.strftime('%Y%m%d')
            df = ak.stock_zh_a_hist(
                symbol=code, period="daily",
                start_date=start_date, end_date=end_date, adjust="qfq"
            )
            self._cache[key] = df
        except Exception as e:
            print('  [数据] ' + code + ' K线获取失败: ' + str(e))
            self._cache[key] = pd.DataFrame()
        return self._cache[key]

    def get_zt_pool(self):
        if 'zt_pool' not in self._cache:
            try:
                df = ak.stock_zt_pool_em(date=self.target_date)
                self._cache['zt_pool'] = df
            except Exception as e:
                print('  [数据] 涨停池获取失败: ' + str(e))
                self._cache['zt_pool'] = pd.DataFrame()
        return self._cache['zt_pool']

    def get_fund_flow(self, code):
        key = 'flow_' + code
        if key in self._cache:
            return self._cache[key]
        result = {'net': 0.0, 'ratio': 0.0, 'main_net': 0.0}
        try:
            market = "sz" if code.startswith(('0', '3')) else "sh"
            df = ak.stock_individual_fund_flow(stock=code, market=market)
            if not df.empty:
                for col in ['主力净流入-净额', '主力净流入净额', '主力净流入']:
                    if col in df.columns:
                        val = df[col].iloc[-1]
                        result['main_net'] = float(val) if not pd.isna(val) else 0
                        break
                for col in ['主力净流入-净占比', '主力净流入净占比']:
                    if col in df.columns:
                        val = df[col].iloc[-1]
                        result['ratio'] = float(val) if not pd.isna(val) else 0
                        break
                result['net'] = result['main_net']
        except Exception:
            pass
        self._cache[key] = result
        return result

    def get_stock_info(self, code):
        key = 'info_' + code
        if key in self._cache:
            return self._cache[key]
        info = {}
        try:
            df = ak.stock_individual_info_em(symbol=code)
            if not df.empty:
                for _, row in df.iterrows():
                    info[str(row.iloc[0])] = row.iloc[1]
        except Exception:
            pass
        self._cache[key] = info
        return info


# ============================================================
# 核心分析引擎 v2.0（基于回测数据重构）
# ============================================================

class FengNiuAnalyzer:
    """
    疯牛 v2.0 - 四维评分系统
    维度1：资金强度 (40分) — 最强预测因子
    维度2：连板辨识度 (30分) — 新增，替代首板
    维度3：技术形态 (20分)
    维度4：量波共振 (10分) — 替代综合过滤
    """

    ST_KEYWORDS = ['ST', '*ST', '退']

    def __init__(self, fetcher):
        self.fetcher = fetcher

    # ----------------------------------------------------------
    # 维度1：资金强度 (40分) — 回测证实最强预测因子
    #   有资金信号组连板率32.7% vs 无信号组3.9%
    # ----------------------------------------------------------
    def check_fund_strength(self, code, hist):
        """
        资金强度评分
        子项：主力净流入(20) + 资金流占比(10) + EXPMA突破(10)
        """
        result = {'signal': False, 'score': 0, 'desc': '', 'details': {}}

        flow = self.fetcher.get_fund_flow(code)
        net_val = flow['net']       # 主力净流入（元）
        ratio_val = flow['ratio']   # 主力净流入占比（%）

        score = 0
        reasons = []

        # 子项1：主力净流入 (最高20分)
        if net_val > 10_000_000:       # > 1000万
            score += 20
            reasons.append('主力净流入%.2f亿(大资金强势)' % (net_val / 1e8))
        elif net_val > 5_000_000:      # > 500万
            score += 15
            reasons.append('主力净流入%.0f万(资金充裕)' % (net_val / 1e4))
        elif net_val > 2_000_000:      # > 200万
            score += 10
            reasons.append('主力净流入%.0f万(有资金关注)' % (net_val / 1e4))
        elif net_val > 0:
            score += 5
            reasons.append('主力净流入%.0f万(微量)' % (net_val / 1e4))
        else:
            reasons.append('主力净流出%.0f万' % (abs(net_val) / 1e4))

        # 子项2：资金流占比 (最高10分)
        if ratio_val > 15:
            score += 10
            reasons.append('占比%.1f%%(极高)' % ratio_val)
        elif ratio_val > 10:
            score += 7
            reasons.append('占比%.1f%%(高)' % ratio_val)
        elif ratio_val > 5:
            score += 4
            reasons.append('占比%.1f%%(中等)' % ratio_val)
        elif ratio_val > 0:
            score += 2
            reasons.append('占比%.1f%%(低)' % ratio_val)

        # 子项3：EXPMA成本线突破 (最高10分)
        expma_desc = ''
        if not hist.empty and len(hist) >= 20:
            closes = hist['收盘'].values
            ema20 = pd.Series(closes).ewm(span=20, adjust=False).mean().values
            last_close = closes[-1]
            if ema20[-1] > 0:
                ratio_em = last_close / ema20[-1]
                if ratio_em >= 1.10:       # > 10%
                    score += 10
                    expma_desc = '突破EXPMA%.1f%%(强势突破)' % ((ratio_em - 1) * 100)
                elif ratio_em >= 1.05:     # > 5%
                    score += 7
                    expma_desc = '突破EXPMA%.1f%%' % ((ratio_em - 1) * 100)
                elif ratio_em >= 1.03:     # > 3%
                    score += 4
                    expma_desc = '突破EXPMA%.1f%%' % ((ratio_em - 1) * 100)
                else:
                    expma_desc = '距EXPMA%.1f%%' % ((ratio_em - 1) * 100)
                reasons.append(expma_desc)

        signal = score >= 25
        result['signal'] = signal
        result['score'] = min(score, 40)
        result['desc'] = '; '.join(reasons) if reasons else '无资金信号'
        result['details'] = {
            'net_inflow_wan': round(net_val / 1e4, 0),
            'flow_ratio': ratio_val,
            'expma_desc': expma_desc,
        }
        return result

    # ----------------------------------------------------------
    # 维度2：连板辨识度 (30分) — 新增维度
    #   回测发现：有连板记录→连板率26.4%，纯首板→连板率仅8.5%
    # ----------------------------------------------------------
    def check_lianban_recognition(self, code, hist, n_days=30):
        """
        连板辨识度评分
        子项：连板数等级(25) + 涨停统计形态(5)
        """
        result = {'signal': False, 'score': 0, 'desc': '', 'details': {}}

        # 从涨停池获取连板数
        lianban = 1  # 默认1板
        try:
            zt_pool = self.fetcher.get_zt_pool()
            if not zt_pool.empty:
                match = zt_pool[zt_pool['代码'] == code]
                if not match.empty:
                    lianban = int(safe_get(match, '连板数', default=1))
        except Exception:
            pass

        zt_count_30 = 0  # 30日内涨停次数
        if not hist.empty and len(hist) >= n_days:
            closes = hist['收盘'].values
            highs = hist['最高'].values
            for i in range(1, len(closes)):
                prev_c = closes[i - 1]
                cur_c = closes[i]
                pct = (cur_c - prev_c) / prev_c * 100
                if pct >= 9.8 and cur_c >= highs[i] * 0.998:
                    zt_count_30 += 1

        score = 0
        reasons = []

        # 子项1：连板数等级 (最高25分)
        if lianban >= 4:
            score += 25
            reasons.append('%d连板(辨识度顶尖)' % lianban)
        elif lianban == 3:
            score += 25
            reasons.append('%d连板(龙头辨识度)' % lianban)
        elif lianban == 2:
            score += 20
            reasons.append('2连板(辨识度较高)')
        elif lianban == 1 and zt_count_30 > 1:
            # 非首板：30日内已有涨停记录
            score += 12
            reasons.append('非首板(30日内有涨停记录)')
        else:
            # 纯首板：30日内首次涨停
            score += 3
            reasons.append('纯首板(辨识度低)')

        signal = score >= 15
        result['signal'] = signal
        result['score'] = min(score, 30)
        result['desc'] = '; '.join(reasons)
        result['details'] = {
            'lianban': lianban,
            'zt_count_30': zt_count_30,
        }
        return result

    # ----------------------------------------------------------
    # 维度3：技术形态 (20分)
    #   均线多头排列(8) + 突破布林上轨(6) + 突破60日线(6)
    # ----------------------------------------------------------
    def check_tech_breakout(self, code, hist):
        result = {'signal': False, 'score': 0, 'desc': '', 'details': {}}

        if hist.empty or len(hist) < 30:
            result['desc'] = 'K线数据不足30日'
            return result

        closes = hist['收盘'].values
        score = 0
        reasons = []

        ma5 = np.mean(closes[-5:])
        ma10 = np.mean(closes[-10:])
        ma20 = np.mean(closes[-20:])
        last = closes[-1]

        # 均线多头排列 (8分)
        if ma5 > ma10 > ma20 and last > ma5:
            score += 8
            reasons.append('5/10/20多头排列')
        elif ma5 > ma10:
            score += 3
            reasons.append('5/10金叉')

        # 突破布林上轨 (6分)
        if len(closes) >= 20:
            std20 = np.std(closes[-20:])
            upper_band = ma20 + 2 * std20
            if last >= upper_band * 1.06:
                score += 6
                reasons.append('突破布林上轨')
            elif last >= upper_band:
                score += 3
                reasons.append('触及布林上轨')

        # 突破60日线/妖股线 (6分)
        if len(closes) >= 60:
            ma60 = np.mean(closes[-60:])
            if last > ma60 * 1.03:
                score += 6
                reasons.append('突破妖股线%.1f%%' % ((last / ma60 - 1) * 100))
            elif last > ma60:
                score += 3
                reasons.append('站上60日线')

        signal = score >= 12
        result['signal'] = signal
        result['score'] = min(score, 20)
        result['desc'] = '; '.join(reasons) if reasons else '无明显技术突破'
        result['details'] = {
            'ma5': round(float(ma5), 2),
            'ma10': round(float(ma10), 2),
            'ma20': round(float(ma20), 2),
        }
        return result

    # ----------------------------------------------------------
    # 维度4：量波共振 (10分) — 替代综合过滤
    #   量比>2(4) + 换手率3-8%(3) + 10:30前封板(3)
    # ----------------------------------------------------------
    def check_wave_volume(self, code, name, hist, zt_time=''):
        """
        量波共振评分
        排除项：ST/新股/连续跌停
        """
        result = {'pass': True, 'score': 0, 'desc': '', 'exclude': False}

        # 排除项检查
        for kw in self.ST_KEYWORDS:
            if kw in name:
                result['exclude'] = True
                result['desc'] = '排除: ' + name + '含' + repr(kw)
                return result

        if not hist.empty and len(hist) < 50:
            result['desc'] += '新股(上市不足50日);'

        if not hist.empty and len(hist) >= 10:
            closes = hist['收盘'].values
            dt_count = 0
            for i in range(max(0, len(closes) - 10), len(closes)):
                if i == 0:
                    continue
                pct = (closes[i] - closes[i - 1]) / closes[i - 1] * 100
                if pct <= -9.8:
                    dt_count += 1
                else:
                    dt_count = 0
                if dt_count >= 2:
                    result['desc'] += '10日内连续2跌停;'
                    break

        score = 0
        desc_parts = []

        # 量比 > 2 (4分)
        if not hist.empty and len(hist) >= 6:
            volumes = hist['成交量'].values
            avg_vol = np.mean(volumes[-6:-1]) if len(volumes) > 5 else volumes[-1]
            vol_ratio = volumes[-1] / avg_vol if avg_vol > 0 else 1
            if vol_ratio > 3:
                score += 4
                desc_parts.append('量比%.1f(巨量)' % vol_ratio)
            elif vol_ratio > 2:
                score += 3
                desc_parts.append('量比%.1f(放量)' % vol_ratio)
            elif vol_ratio > 1.5:
                score += 1
                desc_parts.append('量比%.1f' % vol_ratio)

        # 换手率 3-8% (3分)
        if not hist.empty and len(hist) >= 6:
            info = self.fetcher.get_stock_info(code)
            mv_str = str(info.get('流通市值', '0'))
            try:
                volumes = hist['成交量'].values
                if '亿' in mv_str:
                    mv = float(mv_str.replace('亿', '').replace(',', '')) * 1e8
                else:
                    mv = float(mv_str) if mv_str else 1
                turnover = volumes[-1] * hist['收盘'].values[-1] / mv * 100 if mv > 0 else 0
                if 3 <= turnover <= 8:
                    score += 3
                    desc_parts.append('换手%.1f%%(理想)' % turnover)
                elif 2 <= turnover < 3 or 8 < turnover <= 15:
                    score += 1
                    desc_parts.append('换手%.1f%%(可接受)' % turnover)
                elif turnover > 15:
                    desc_parts.append('换手%.1f%%(偏高)' % turnover)
            except Exception:
                pass

        # 10:30前封板 (3分)
        if zt_time:
            try:
                t = int(zt_time.replace(':', ''))
                if t <= 93000:
                    score += 3
                    desc_parts.append('开盘即封板(最强)')
                elif t <= 103000:
                    score += 2
                    desc_parts.append('10:30前封板')
                elif t <= 113000:
                    score += 1
                    desc_parts.append('午前封板')
            except Exception:
                pass

        result['score'] = min(score, 10)
        result['desc'] = '; '.join(desc_parts) if desc_parts else '无加分'
        return result

    # ----------------------------------------------------------
    # 综合评分
    # ----------------------------------------------------------
    def analyze_stock(self, code, name):
        """四维评分"""
        hist = self.fetcher.get_stock_hist(code, days=120)

        result = {
            'code': code,
            'name': name,
            'dimensions': {},
            'total_score': 0,
            'signals': [],
            'conclusion': '',
            'action': '',
        }

        # 维度1：资金强度 (40分)
        d1 = self.check_fund_strength(code, hist)
        result['dimensions']['fund'] = d1
        if d1['signal']:
            result['signals'].append('资金强势')

        # 维度2：连板辨识度 (30分)
        d2 = self.check_lianban_recognition(code, hist)
        result['dimensions']['recognition'] = d2
        if d2['signal']:
            result['signals'].append('辨识度' if d2['details']['lianban'] >= 2 else '非首板')

        # 维度3：技术形态 (20分)
        d3 = self.check_tech_breakout(code, hist)
        result['dimensions']['tech'] = d3
        if d3['signal']:
            result['signals'].append('技术突破')

        # 维度4：量波共振 (10分)
        zt_time = ''
        try:
            zt_pool = self.fetcher.get_zt_pool()
            if not zt_pool.empty:
                match = zt_pool[zt_pool['代码'] == code]
                if not match.empty:
                    zt_time = safe_str(match, '首次封板时间', default='')
        except Exception:
            pass
        d4 = self.check_wave_volume(code, name, hist, zt_time)
        result['dimensions']['wave_volume'] = d4

        if d4['exclude']:
            result['conclusion'] = d4['desc']
            result['action'] = '不操作'
            return result

        # 计算总分
        score = d1['score'] + d2['score'] + d3['score'] + d4['score']
        result['total_score'] = min(score, 100)

        # 信号等级 (基于回测校准)
        # ≥80分: 强信号 | 60-79分: 中等信号 | <60分: 观望
        if result['total_score'] >= 80:
            result['conclusion'] = '强信号: 多维共振, 连板潜力高'
            result['action'] = '重点关注'
        elif result['total_score'] >= 60:
            result['conclusion'] = '中等信号: 部分条件满足, 需盘中确认'
            result['action'] = '一般关注'
        else:
            result['conclusion'] = '弱信号: 辨识度或资金不足'
            result['action'] = '观望'

        return result


# ============================================================
# HTML报告生成
# ============================================================

def generate_html_report(results, target_date):
    results_sorted = sorted([r for r in results if r['total_score'] > 0],
                           key=lambda x: x['total_score'], reverse=True)

    if not results_sorted:
        return ('<!DOCTYPE html><html><head><meta charset="UTF-8">'
                '<title>疯牛分析' + target_date + '</title>'
                '<style>body{background:#0d0d1a;color:#ccc;font-family:sans-serif;'
                'padding:20px;}.nodata{text-align:center;padding:60px;'
                'color:#888;font-size:18px;}</style></head>'
                '<body><div class="nodata">当日无符合条件个股<br>'
                '建议等待市场情绪转暖后再分析</div></body></html>')

    cards_html = ''
    for i, r in enumerate(results_sorted):
        sig_color = '#ff4444' if r['total_score'] >= 80 else '#ff8800' if r['total_score'] >= 60 else '#888888'
        sig_bg = ('rgba(255,68,68,0.1)' if r['total_score'] >= 80
                   else 'rgba(255,136,0,0.1)' if r['total_score'] >= 60
                   else 'rgba(136,136,136,0.05)')

        dims_html = ''
        dim_names = [
            ('fund', '资金强度(40)'),
            ('recognition', '连板辨识(30)'),
            ('tech', '技术形态(20)'),
            ('wave_volume', '量波共振(10)'),
        ]
        for key, label in dim_names:
            d = r['dimensions'].get(key, {})
            sc = d.get('score', 0)
            desc = d.get('desc', '')
            color = '#ff4444' if sc >= 20 else '#ff8800' if sc >= 10 else '#666'
            dims_html += ('<div style="margin-bottom:8px;">'
                          '<div style="font-size:12px;color:#aaa;min-width:80px;'
                          'display:inline-block;">' + label + '</div>'
                          '<div style="display:inline-block;color:' + color + ';'
                          'font-size:13px;font-weight:bold;">' + str(sc) + '分</div>'
                          '<div style="font-size:11px;color:#777;margin-top:2px;'
                          'margin-left:80px;">' + desc + '</div></div>')

        signals_str = ' + '.join(r['signals']) if r['signals'] else '无信号'

        cards_html += ('<div style="background:#1a1a2e;border:1px solid ' + sig_color +
                       ';border-radius:12px;padding:20px;margin-bottom:16px;">'
                       '<div style="display:flex;justify-content:space-between;'
                       'align-items:center;margin-bottom:12px;">'
                       '<div><span style="font-size:11px;color:#666;">#' + str(i+1) + '</span>'
                       '<span style="font-size:18px;font-weight:bold;color:#fff;'
                       'margin-left:8px;">' + r['name'] + '</span>'
                       '<span style="font-size:13px;color:#888;margin-left:6px;">' +
                       r['code'] + '</span></div>'
                       '<div style="text-align:right;">'
                       '<div style="font-size:28px;font-weight:bold;color:' + sig_color +
                       ';">' + str(r['total_score']) + '</div>'
                       '<div style="font-size:12px;color:#888;">/100</div></div></div>'
                       '<div style="display:inline-block;background:' + sig_bg +
                       ';color:' + sig_color + ';font-size:13px;font-weight:bold;'
                       'padding:4px 12px;border-radius:6px;margin-bottom:12px;">' +
                       r['action'] + ' | ' + signals_str + '</div>'
                       '<div style="background:#111125;border-radius:8px;padding:12px;">' +
                       dims_html + '</div>'
                       '<div style="margin-top:10px;font-size:13px;color:#ddd;">' +
                       r['conclusion'] + '</div></div>')

    html = ('<!DOCTYPE html><html lang="zh-CN"><head>'
             '<meta charset="UTF-8">'
             '<meta name="viewport" content="width=device-width,initial-scale=1.0">'
             '<title>疯牛v2.0 · 涨停分析 ' + target_date + '</title>'
             '<style>*{margin:0;padding:0;box-sizing:border-box;}'
             'body{background:#0d0d1a;color:#e0e0e0;font-family:Microsoft YaHei,'
             'PingFang SC,sans-serif;padding:20px;max-width:800px;margin:0 auto;}'
             '.header{text-align:center;padding:20px 0;border-bottom:2px solid #ff4444;'
             'margin-bottom:20px;}'
             '.header h1{font-size:24px;color:#ff4444;}'
             '.header .version{font-size:12px;color:#ff4444;margin-top:2px;}'
             '.header .date{font-size:14px;color:#888;margin-top:4px;}'
             '.section{margin-bottom:24px;}'
             '.discipline{background:#1a1a2e;border:1px solid #ff4444;'
             'border-radius:8px;padding:12px;margin-bottom:16px;'
             'font-size:13px;color:#ff8888;}'
             '.discipline b{color:#ffcc00;}</style></head><body>'
             '<div class="header"><h1>疯牛 v2.0</h1>'
             '<div class="version">基于回测数据重构 · 四维评分系统</div>'
             '<div class="date">分析日期: ' + target_date + '</div></div>'
             '<div class="discipline"><b>操作纪律：</b>'
             '买入——封涨停排队买入，或次日回调-5%时分批建仓(2-2-2-4法)<br>'
             '<b>止盈：</b>次日高开高走持股，不涨停卖出；'
             '连续涨停持股至量能异常放大时出局<br>'
             '<b>止损：</b>次日低开低走立即止损，'
             '单笔亏损控制在5%以内，不加仓不补仓</div>'
             '<div class="section"><h2 style="font-size:18px;color:#fff;'
             'margin-bottom:16px;">信号排名 (共' + str(len(results_sorted)) + '只)</h2>' +
             cards_html + '</div>'
             '<div style="text-align:center;color:#555;font-size:11px;'
             'margin-top:30px;padding:16px;border-top:1px solid #222;">'
             '疯牛 v2.0 · 基于回测数据重构 · 仅供参考，不构成投资建议<br>'
             '数据来源：东方财富 · AKShare</div></body></html>')
    return html


# ============================================================
# 主函数
# ============================================================

def run_fengniu_analysis(target_date=None, top_n=10, mode='all'):
    """
    执行疯牛分析
    mode: 'all' | 'fund-break' (保留兼容)
    """
    if target_date is None:
        target_date = get_latest_trading_date()

    print('[疯牛v2.0] 分析日期: ' + target_date)
    print()

    fetcher = FNADataFetcher(target_date)
    analyzer = FengNiuAnalyzer(fetcher)

    zt_pool = fetcher.get_zt_pool()
    if zt_pool.empty:
        print('[疯牛] 涨停池为空，可能非交易日')
        return []

    print('[疯牛] 涨停股数量: ' + str(len(zt_pool)))
    print('=' * 60)
    print()

    results = []
    for idx, row_pair in enumerate(zt_pool.iterrows()):
        row = row_pair[1]
        code = safe_str(row, '代码')
        name = safe_str(row, '名称')
        if not code:
            continue

        print('[' + str(idx+1) + '/' + str(len(zt_pool)) + '] ' +
              name + '(' + code + ')...', end=' ')

        try:
            result = analyzer.analyze_stock(code, name)
            results.append(result)
            flag = ('\u2605' if result['total_score'] >= 80
                     else '\u2606' if result['total_score'] >= 60 else ' ')
            print(flag + ' ' + str(result['total_score']) + '分 - ' +
                  result['action'] + ' ' + '+'.join(result['signals']))
        except Exception as e:
            print('失败: ' + str(e))

    results.sort(key=lambda x: x['total_score'], reverse=True)

    strong = sum(1 for r in results if r['total_score'] >= 80)
    medium = sum(1 for r in results if 60 <= r['total_score'] < 80)

    print()
    print('=' * 60)
    print('疯牛v2.0分析完成！共分析 ' + str(len(results)) + ' 只')
    print('强信号(>=80): ' + str(strong) + ' 只 | 中等信号(60-79): ' + str(medium) + ' 只')
    print('=' * 60)
    print()
    print('排名  代码    名称       总分  操作建议')
    print('-' * 60)
    for i, r in enumerate(results[:top_n]):
        print('#' + str(i+1) + '  ' + r['code'] + '  ' +
              r['name'] + '  ' + str(r['total_score']) + '  ' + r['action'])

    return results


def main():
    parser = argparse.ArgumentParser(description='疯牛v2.0 · 涨停捕捉模型')
    parser.add_argument('--date', type=str, default=None, help='分析日期(YYYYMMDD)')
    parser.add_argument('--top', type=int, default=10, help='输出前N名')
    parser.add_argument('--html', action='store_true', help='生成HTML报告')
    parser.add_argument('--output', type=str, default=None, help='输出目录')

    args = parser.parse_args()
    target_date = args.date if args.date else get_latest_trading_date()

    results = run_fengniu_analysis(target_date=target_date, top_n=args.top)

    if not results:
        print('[结果] 无分析结果')
        return

    if args.html:
        html = generate_html_report(results, target_date)
        output_dir = Path(args.output) if args.output else Path('.')
        output_dir.mkdir(parents=True, exist_ok=True)
        html_path = output_dir / ('疯牛v2_分析_' + target_date + '.html')
        html_path.write_text(html, encoding='utf-8')
        print('[报告] HTML: ' + str(html_path))

        json_path = output_dir / ('疯牛v2_结果_' + target_date + '.json')
        json_path.write_text(json.dumps(results, ensure_ascii=False, indent=2),
                            encoding='utf-8')
        print('[数据] JSON: ' + str(json_path))


if __name__ == '__main__':
    main()
