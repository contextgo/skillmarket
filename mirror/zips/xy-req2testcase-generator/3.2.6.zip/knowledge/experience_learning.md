# T3-03：经验学习扩展模块

> 负责人：小墨 | 2026-04-25

## 概述

经验学习模块（L6）负责收集用户反馈、写入经验池、定期优化模型能力表。

## 反馈收集流程

### 1. 反馈入口
- **分类纠偏**：用户发现图片分类错误时，通过 T3-04 模块纠正
- **OCR 不准确**：用户发现 OCR 近音字纠错未生效或引入新错误
- **上下文不足**：用户认为 before_text/after_text/caption 信息不足以推断图片内容
- **提取遗漏**：用户发现图片中的关键信息未被提取

### 2. 反馈写入
```python
# I-FIX-07: 更新函数签名，支持 original_type/corrected_type/doc_file/context_keywords 等字段
def record_classification_feedback(image_id, original_type, corrected_type, context_keywords, feedback_type="classification_error", doc_file="", original_output=None):
    """
    反馈写入 experience_pool.json。

    Args:
        feedback_type: 反馈类型 (classification_error / ocr_inaccuracy / context_insufficient / extraction_missing)
        image_id: 图片 ID
        original_output: 原始 PX 输出 (dict)
        user_correction: 用户纠正内容 (str)
        **kwargs: 可选参数，包括：
            - original_type (str): 原始分类类型
            - corrected_type (str): 纠正后的类型
            - doc_file (str): 文档文件名
            - context_keywords (list): 上下文关键词列表
    """
    entry = {
        "id": f"fb_{datetime.now().strftime('%Y%m%d')}_{next_seq()}",
        "timestamp": datetime.now().isoformat(),
        "image_id": image_id,
        "feedback_type": feedback_type,
        "original_output": original_output,
        "user_correction": user_correction,
        "original_type": kwargs.get("original_type", ""),
        "corrected_type": kwargs.get("corrected_type", ""),
        "doc_file": kwargs.get("doc_file", ""),
        "context_keywords": kwargs.get("context_keywords", []),
        "applied": False,
        "applied_date": None,
    }
    # 追加到 experience_pool.json
    # 同时更新 correction_stats:
    #   correction_stats.total_corrections += 1
    #   correction_stats.by_type[feedback_type] += 1
```

### 3. 定期优化
- **每周回顾**：汇总未 applied 的反馈，分析高频错误模式
- **模型能力表更新**：根据运行时探测失败记录，调整 model_vision_capability.json
- **启发规则补充**：高频遗漏 → 新增启发规则到 image_test_heuristics.md
- **纠错词表扩展**：OCR 纠错词表根据用户反馈扩充

### 4. 反馈应用优先级
1. **classification_error** → 立即写入 experience_pool，下次同类上下文优先匹配
2. **ocr_inaccuracy** → 累计 3 次同类错误 → 更新纠错词表
3. **context_insufficient** → 记录，下次 review 时评估是否扩大 before_text/after_text 窗口
4. **extraction_missing** → 累计 5 次同类遗漏 → 补充启发规则

### 5. 命中验证与效果回收（AB-04修复）
- **命中条件**：经验条目的 context_keywords 与当前图片的 section/before_text 关键词重叠度 ≥ 0.6
- **命中记录**：每次命中经验后，在 feedback_entry 中追加 hit_count+1 和 last_hit_date
- **效果追踪**：命中后分类结果与人工反馈对比，记录 success_count（纠偏成功）/ fail_count（纠偏引入新误判）
- **经验回滚**：若 fail_count > success_count，自动设置 rollback_flag=true，该条经验降权不再自动应用
- **经验老化**：连续 30 天未命中的经验自动降权（priority 降低），90 天未命中标记为 stale

### 6. 经验池字段补充（AB-04修复）
每条 feedback_entry 增加以下字段：
- `match_condition`: 匹配条件描述
- `scope`: 适用范围（document_type / section_pattern / keyword_set）
- `priority`: 优先级（1-10，默认5）
- `hit_count`: 命中次数
- `success_count`: 纠偏成功次数
- `fail_count`: 纠偏失败次数
- `rollback_flag`: 是否已回滚
- `version_range`: 适用的代码版本范围
- `last_hit_date`: 最后命中日期

## 经验池结构

见 `knowledge/experience_pool.json`

## 与其他模块的交互
- **T3-04（分类纠偏）** → 写入 experience_pool.classification_error
- **T2-02（OCR 纠错）** → 读取 experience_pool 中的 ocr_inaccuracy 记录
- **T2-05（启发规则）** → 读取 experience_pool 中的 extraction_missing 记录
- **T1-03（模型能力表）** → 根据 model_capability_adjustments 定期更新
