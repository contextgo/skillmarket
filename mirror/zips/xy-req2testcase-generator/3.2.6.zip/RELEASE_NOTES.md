# Release Notes — xy-req2testcase-generator v2.2.2

发布日期：2026-04-24
发布人：loveshaozhe

---

## v2.2.2 字段字典对齐与交付体验修复

### 修复
- **MEDIA 发送路径强化**：Step 7 发送文件时必须将 `{DATA_DIR}` / `{task_id}` 替换为实际路径，不得输出占位符字面量
- **优先级字典对齐**：P0/P1/P2/P3 映射到公司字典 Highest/High/Medium/Low（兼容 Lowest 直通）
- **用例类型字典对齐**：公司字典只有“正例”和“反例”，导出时自动映射（正向验证等→正例，异常处理等→反例）
- **测试类别字典对齐**：导出时自动映射到公司字典（功能测试/性能测试/安全性测试/兼容性测试/可靠性测试/可维护性测试/可移植性测试），未识别的默认功能测试
- **执行结果默认置空**：`status` 字段导出时固定置空
- **备注字段允许为空**：`remarks` 加入 ALLOW_EMPTY_FIELDS，不再因备注为空而导出失败

---

## v2.2.1 云端运行问题修复

### 修复
- **缓存检测默认自动重跑**：Onboarding 检测到历史缓存时，不再弹出三选项等待用户，默认自动清理并重新开始
- **Step 4 截断自愈**：P5 执行截断后自动补全，不再等待用户追问；新增 `p5_output.json` 完成性校验，校验失败自动重跑
- **元叙述硬禁令**：运行协议新增元叙述黑名单，禁止输出“根据技能要求”“现在先输出”“接下来我将”等元叙述语句
- **Excel 空列修复**：P6 Prompt 新增 19 列字段完整输出契约；`p6_output.schema.json` 必填字段从 7 个提升为 19 个；`export_excel.py` 新增导出前字段完整性校验，缺字段直接报错
- **P6 Prompt 字段口径全链路统一**：few-shot 示例、输出模板、接口字段映射表全部对齐到 19 列标准字段名；删除旧字段 `type` / `precondition` / `execution_result`
- **`prompts/examples/p6/` 外部示例文件全量重建**：trade / asset_mgmt / risk_ctrl 三个示例文件全部转换为 `testcases[].fields` 结构，字段名全部对齐到 19 列标准
- **`P7_quality_gate.md` 字段名修正**：`precondition` 全部改为 `preconditions`
- **Step 4 完成性校验字段名修正**：按真实 P5 schema 顶层键校验，不再引用不存在的 `statistics.by_priority`

---

## v2.2.0 执行协议重构

### 新增/改进
- 新增顶部「运行协议」，统一对话输出白名单与唯一合法结束点
- Onboarding 后新增「零暂停模式」声明，主流程进入连续执行模式
- 合并 Step 3/4/5（P2/P3/P4）为一个复合步骤，减少中途停顿概率
- Step 1/2/P5/P6/P7/输出步骤改为三段式结构：禁止事项 → 内部动作 → 对话输出 → 自动推进
- Step 编号统一重排为 Step 0 → Step 7
- 输出步骤新增 `p6_output.json` 前置校验，禁止绕过 `export_excel.py` 自行生成 Excel
- P2/P3/P4 合并步骤新增子步骤断点续跑检查
- P7 自动重试链路同步到新编号体系

### 修复
- 修复云端场景下中途输出 JSON、停顿等待用户继续的问题
- 修复 Excel 可能未使用公司固定模板、被 LLM 自行生成的风险
- 修复编号重排后顶部“唯一合法结束点”被误替换的问题
- 修复 P6 输出 schema 与 19 列导出字段映射不一致问题
- 修复 Step 7 备忘标签错误与 company_standards 下 21 列残留口径

---

## v2.1.0 业务域扩展

### 新增
- **domain 枚举扩展至 8 个域**：新增 crm / etrading / ops_mgmt / compliance / it_infra，覆盖券商常见内部系统场景
- **P0 Few-shot 补充**：新增 CRM域、etrading域、ops_mgmt域、compliance域四个示例
- **knowledge/industry 新增**：etrading.md / ops_mgmt.md / it_infra.md 占位文件，修复运行时必注入错误
- **skill_v2 域识别关键词补全**：新增 5 个域的自动识别规则
- **schema enum 约束**：p0_input / p0_output schema 的 domain 字段新增 enum 验证
- **两套域体系统一**：skill/SKILL.md 业务域表格统一为 P0 的 8 域体系，原有 clearing/data/platform/investment_banking/derivatives 域数据并入相近域

### 待补充（下一版本）
- P6 新域功能测试 few-shot 示例（小猿负责）
- P0 示例深化：4 个新域的 unknowns / business_rules 补充（小析负责）
- P2 新域专属测试点注入规则（小析负责）
- it_infra 域 Few-shot 示例

---

## v1.2.0 第四阶段修复闭环

发布日期：2026-04-21

---

## 主要功能

- **P0~P7 完整 Prompt 链路**：需求结构化 → 功能点树 → 测试点（并行）→ 合并优先级 → 用例展开 → 质量自检
- **P0.5 PRD 质量审查**（可选，默认关闭）：对 PRD 进行质量评分，分级处理阻塞/警告类问题
- **L1~L6 六层 RAG 知识库**：L1~L4 内置（行业知识/测试方法/公司规范/历史缺陷），L5/L6 外挂扩展
- **LLMRetriever / ChromaRetriever 可插拔检索**：零依赖模式开箱即用，可选向量检索提升精度
- **Excel 19列标准输出**：含冒烟用例标注，符合公司评审规范
- **交付物直接发送**：通过 MEDIA 指令在对话窗口直接发送 Excel 文件，云端用户无需访问 workspace

---

## 安装方式

```bash
clawhub install xy-req2testcase-generator
```

---

## 快速开始

安装后，在 OpenClaw 对话中发送：

```text
xy用例生成 [需求文档内容]
```

或使用专属触发词：`xy需求分析` / `xy测试用例` / `req2testcase`

---

## 已知限制

1. **PII 脱敏**：当前为预处理占位，内网部署需实现具体脱敏模块
2. **Python 版本**：需要 >= 3.10
3. **L5 项目知识库**：未配置时使用通用行业知识，用例覆盖率约 60%；配置后可提升至 ~85%
4. **并发控制**：`max_concurrency: 2`，可按 LLM 配额调整

---

## 第五阶段灰度验证说明

本版本发布后，将进入第五阶段灰度验证：
1. **本地内部灰度**：基于已发布 Skill，使用新需求说明书样本验证
2. **云端干净环境灰度**：在干净 OpenClaw 环境从 ClawHub 安装后完整验证

灰度问题将建立独立问题清单，不与第四阶段问题混用。
