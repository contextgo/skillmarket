# xy-req2testcase-generator - AgentSkill 执行指令

> 版本:2.3.2
> 架构:零部署,Agent 直接执行,无 FastAPI 服务依赖
> 新增:PX 图片理解与测试增强层(视觉/OCR/纯文本三级降级)

---

## 🔴 运行协议(最高优先级,覆盖后文所有描述)

**对话输出白名单(只允许以下几类,其他一律不输出)**:
- 步骤完成行:`✅ Step X(PX)完成!- {关键指标} - 文件已保存`
- P6 进度行:`⏳ 正在生成测试用例,预计需要 1-2 分钟,请稍候...` / `已生成 X/N 条用例(第 Y 批完成)...`
- 最终完成行:`✅ 测试用例已生成,共 N 条。Excel 文件已发送。`
- 学习邀请:`💡 L6 经验学习...`

**元叙述硬禁令(一律禁止输出)**:
- 禁止输出: `根据技能要求` / `现在先输出` / `接下来我将` / `先看看` / `是否完成` / `是否继续`
- 禁止解释自己正在遵循什么协议、准备做什么、为什么先做某一步
- 完成信息必须与执行结果同轮直接输出,不得先输出解释性过渡语

**❌ 错误示范 → ✅ 正确做法**:

| 错误行为 | 正确做法 |
|---------|---------|
| 检测到历史缓存后输出三选项菜单 | 直接输出 `检测到历史缓存,已自动清理,开始新任务。` 然后立即继续 |
| 将 Step 5/6/7 合并为一个回复执行 | 每个 Step 必须单独完成并输出一行状态行,再自动推进 |
| 输出完整 JSON 到对话 | 只写入文件,对话只输出一行状态 |
| "是否继续执行下一步?" | 直接执行,不需要用户确认 |
| "先看看中间成果" | 不展示,只有最终 Excel 输出 |
| Step 完成后等待用户回复 | 立即开始下一个 Step |
| 每步输出 2+ 行说明 | 每步只有 1 行 ✅ 状态行 |

**唯一合法结束点**:Step 7 完成,Excel 文件已发送,输出最终完成信息(及允许的 L6 学习邀请)后才允许结束本轮回复。

---

## 元数据

```yaml
name: xy-req2testcase-generator
version: "2.3.2"
description: "AI 驱动的需求→测试用例生成能力。新增 PX 图片理解与测试增强层,支持视觉/OCR/纯文本三级降级。Agent 读取本文件后,串行执行 PX→P0→P6 全链路,直接调用 OpenClaw 内置 LLM,零部署即用。"
author: "券商科技测试团队"
tags: ["testing", "test-case-generation", "requirement-analysis", "securities"]
```

---

## 触发条件

### 专属触发词(精准命中,多 Skill 共存时优先)

- 「xy用例生成」「xy需求分析」「xy测试用例」「xy测试用例生成」「req2testcase"

### 通用触发词

- 「生成测试用例」「分析需求」「拆解功能点」「输出测试点」「需求评审」
- 「帮我写用例」「这个需求怎么测」「PRD 转测试用例」

### PRD 质量审查开关

- 开启:「PRD质量审查能力打开」「开启PRD审查」
- 关闭:「关闭PRD审查」

**开关指令处理(优先于流程执行)**:

当用户消息匹配以下指令时,不进入主流程,直接执行开关操作:

1. 用户发送「PRD质量审查能力打开」或「开启PRD审查」:
   - 读取 `{SKILL_DIR}/user_knowledge/preferences.json`
   - 将 `prd_quality_review` 字段更新为 `true`
   - 写回文件
   - 回复用户:「✅ PRD 质量审查已开启,下次分析时生效。」
   - 结束(不进入 Step 0)

2. 用户发送「关闭PRD审查」:
   - 读取 `{SKILL_DIR}/user_knowledge/preferences.json`
   - 将 `prd_quality_review` 字段更新为 `false`
   - 写回文件
   - 回复用户:「✅ PRD 质量审查已关闭。」
   - 结束(不进入 Step 0)

当用户发送以上触发词并附带需求文本时,开始执行以下流程。

---

## ⚠️ 执行铁律(最高优先级,任何情况下不得违反)

> **跳步 = 交付失败。** 本技能的核心价值在于通过 P0→P1→P2→P3→P4→P5→P6 的完整分析链路,系统性覆盖正向/异常/边界/权限/性能等测试场景。任何跳步行为都会导致测试用例严重不足,用户将收到质量低劣的不完整交付物。

> **关键约束**:
> 1. 所有步骤串行执行,禁止使用 sessions_spawn 并行
> 2. **你(Agent)就是 LLM**:所有「调用 LLM」的步骤,直接用你自己的推理能力执行
> 3. 每步调用 LLM 后必须执行 JSON 解析兜底逻辑
> 4. 中间结果必须写入 `{DATA_DIR}/`,确保可断点续跑
> 5. **严禁跳步**:必须严格按 Step 0→1→2→3→4→5→6→7 顺序执行
> 6. **输出规范见顶部「运行协议」**,每步约束已内联在该步骤开头

---

## Onboarding 检查(每次执行前必做)

> **全流程非交互规则**：本技能全流程（Onboarding → Step 0-7）均为非交互模式。所有检查输出、状态提示、警告信息均为信息性提示，执行方不得暂停等待用户回复。唯一允许暂停的情况：Onboarding BLOCKED 且用户明确要求介入。

在开始 Step 0 之前,按以下顺序检查环境就绪状态。任何一项 BLOCKED 则停止并提示用户。

### 检查 1:文件完整性

```
读取本 SKILL.md 所在目录,确认以下文件/目录存在:
- prompts/P0_requirement_structuring.md
- prompts/P1_feature_tree_generation.md
- prompts/P2_test_point_draft.md
- prompts/P3_risk_identification.md
- prompts/P4_pci_identification.md
- prompts/P5_test_point_merge.md
- prompts/P6_testcase_generation.md
- prompts/P7_quality_gate.md
- prompts/PX_image_understand.md
- tools/image_extract.py
- tools/model_detect.py
- tools/image_understand.py
- tools/image_enhance.py
- knowledge/model_vision_capability.json
- knowledge/industry/
- knowledge/methodology/
- knowledge/company_standards/
- knowledge/defect_patterns/
```

如有缺失:输出 `❌ Onboarding 失败:缺少文件 {path}，Skill 安装不完整。` → BLOCKED（用户可检查安装后重试）

### 检查 0.5:缓存检测(新任务 vs 续跑)

```bash
exec: ls ~/.openclaw/workspace/data/ 2>/dev/null | grep "^task_" | sort -r | head -3
```

> ⚠️ **此步骤禁止输出任何选项菜单。不得输出「继续 / 重新开始 / 重新生成」三选项。不得等待用户回复。违反即为协议违规。**

- **无缓存**:直接继续
- **有缓存**:默认按**新任务优先**处理,**自动清理本次不复用的历史缓存并重新开始**,不得等待用户选择,不得输出三选项
- **仅当用户消息中明确包含以下指令时**,才进入特例分支:
  - `继续 task_XXXXXX` → 从指定 task 继续
  - `重新生成` → 保留 P0-P5,仅清除 P6/P7/最终 Excel 后重跑
  - `从 P{n} 重新开始` → 清除该步及后续缓存,从指定步骤重跑

> **默认策略(必须严格执行)**:
> - 用户直接发送新需求文档/需求文本 = 视为新任务,自动重新开始
> - 不得因发现历史缓存而暂停或要求用户确认
> - **严禁输出"继续 / 重新开始 / 重新生成"选择菜单**
> - 检测到缓存后应直接输出: `检测到历史缓存,已自动清理,开始新任务。` 然后立即进入下一步

### 检查 1.5:SKILL_DIR 路径自动发现(必须完成,后续步骤依赖此结果)

```bash
exec: bash -c '
# 1. 环境变量优先
if [ -n "$SKILL_DIR" ] && [ -f "$SKILL_DIR/tools/export_excel.py" ]; then
    echo "SKILL_DIR=$SKILL_DIR"; echo "export_excel.py=$SKILL_DIR/tools/export_excel.py"
# 2. 原glob搜索
elif candidates=$(timeout 10 find ~/.openclaw ~/.local ~/skills /app/skills -name export_excel.py -print -quit 2>/dev/null) && [ -n "$candidates" ]; then
    skill_dir=$(dirname $(dirname "$candidates"))
    echo "SKILL_DIR=$skill_dir"; echo "export_excel.py=$candidates"
# 3. 容器常见路径
elif [ -f "/app/skills/xy-req2testcase-generator/tools/export_excel.py" ]; then
    echo "SKILL_DIR=/app/skills/xy-req2testcase-generator"; echo "export_excel.py=/app/skills/xy-req2testcase-generator/tools/export_excel.py"
else
    echo "ERROR: 未找到 export_excel.py，请设置 SKILL_DIR 环境变量"
fi
'
```

- 成功找到:将输出的 `SKILL_DIR` 路径记录为本次任务的 `{SKILL_DIR}`,后续所有步骤使用此实际路径
- 未找到:输出 `⚠️ 无法定位 export_excel.py,Excel 导出将降级为 Markdown 输出。` → 继续(不阻塞)

> **重要**:后续步骤中所有 `{SKILL_DIR}` 占位符,必须替换为本步骤发现的实际路径,不得使用字面量 `{SKILL_DIR}`。

### 检查 2:Python + openpyxl 可用性

```bash
exec: python3 -c "import openpyxl; print('ok')"
```

- 成功:继续
- 失败:尝试 `exec: pip install openpyxl`,再次检查
- 仍失败:输出 `⚠️ openpyxl 不可用,Excel 导出将不可用,但 Markdown 输出正常。` → 继续(不阻塞)

### 检查 3:用户偏好

```
读取 user_knowledge/preferences.json
```

- 存在:解析并记录 `prd_quality_review`、`default_domain`、`max_defect_patterns`、`output_format`
- 不存在:自动创建默认配置(见下方默认值),提示用户 `i️ 已创建默认偏好配置,可在 user_knowledge/preferences.json 中自定义。`
- 文件存在但格式损坏:输出 `⚠️ preferences.json 格式错误,已使用默认配置。`,使用默认值继续,不阻塞流程
- **默认不暂停**:
  - 若用户消息明确包含 `开启PRD审查` / `PRD质量审查能力打开` → 按开关指令处理
  - 其他普通执行场景 → 直接使用 `preferences.json` 中的当前值继续,不得额外询问"开启/跳过"
- 仅允许输出一行提示(可选,非必需):
  ```
  i️ PRD 质量审查当前状态:{prd_quality_review 为 true 则显示「已开启」,false 则显示「未开启」}。（已自动继续）
  ```
- 不得暂停等待用户回复"开启/跳过"

默认值:
```json
{
  "prd_quality_review": false,
  "default_domain": "trade",
  "max_defect_patterns": 20,
  "output_format": "excel"
}
```

### 检查 4:知识库状态(L5 为空时强制中断)

```bash
exec: ls {SKILL_DIR}/user_knowledge/project/ 2>/dev/null | wc -l
```

- **L5 有文件**:提示「✅ L5 项目知识库已就绪」,继续检查 L6
- **L5 为空**:输出一次非阻塞提示后直接继续,不得等待用户回复:
  ```
  i️ L5 项目知识库为空,本次按通用知识直接执行;后续可随时上传历史文档补充 L5。（已自动继续）
  ```
- 仅当用户主动发送"上传"并附文件时,才执行 L5 导入逻辑

```bash
exec: ls {SKILL_DIR}/user_knowledge/experience/ 2>/dev/null | wc -l
```
- **L6 有文件**:提示「✅ L6 经验库已就绪」
- **L6 为空**:提示「i️ L6 经验库为空,生成用例后可将评审结果交给我学习。」(不阻塞)

---

---

## 🔴 主流程模式:零暂停(从此处开始)

> Onboarding 阶段的交互已完成。**从现在开始进入零暂停模式**:
>
> - **Onboarding 允许交互治理;进入主流程后,Step 0 到 Step 7 必须连续执行**,不得在任何步骤之间等待用户输入
> - 每步完成后唯一的动作是:写入文件 → 输出一行状态 → 开始下一步的 exec 命令
> - 你不需要、也不应该输出任何确认性语句
> - 唯一允许暂停的情况:Onboarding BLOCKED 且用户明确要求介入（与「全流程非交互规则」一致）。Step 0.5 blocker 已改为自动转 PCI 继续执行，不再暂停等待用户。

---

## 路径约定

| 变量 | 含义 | 示例 |
|------|------|------|
| `{SKILL_DIR}` | 本 SKILL.md 所在目录 | `.../skill_v2/` |
| `{DATA_DIR}` | 中间结果持久化目录 | `~/.openclaw/workspace/data/{task_id}/` |
| `{task_id}` | 任务唯一标识 | `task_20260421_153000` |

每步输出写入 `{DATA_DIR}/p{n}_output.json`,支持断点续跑。

---

## 执行流程:Step 0 → Step 7

> **关键约束**:
> 1. 所有步骤串行执行,禁止使用 sessions_spawn 并行
> 2. **你(Agent)就是 LLM**:所有「调用 LLM」的步骤,直接用你自己的推理能力执行,不需要调用任何外部接口或 API。你读取 Prompt 模板后,直接输出对应的 JSON 结果即可。
> 3. 每步调用 LLM 后必须执行 JSON 解析兜底逻辑(见「JSON 解析兜底」一节)
> 4. 中间结果必须写入 `{DATA_DIR}/`,确保可断点续跑
> 5. **严禁跳步**:必须严格按 Step 0→Step 1(P0)→Step 2(P1)→Step 3(P2/P3/P4)→Step 4(P5)→Step 5(P6)→Step 6(P7)→Step 7(输出) 顺序执行,任何步骤不得跳过或合并。每步必须有对应的 JSON 输出文件写入 `{DATA_DIR}/`,否则视为未完成,不得进入下一步。禁止直接从需求文档一步生成测试用例。
> 6. **严禁合并 Step 5/6/7**:禁止将 Step 5(P6)、Step 6(P7)、Step 7(输出)合并为一个回复执行。每个 Step 必须单独完成并输出一行状态行后,再自动推进到下一个 Step。
> 6. **严禁中途暂停**:从 Step 0 开始到 Step 7 输出完成,必须一气呵成执行完毕,不得以「回复过长」「是否继续」「先看看成果」等任何理由中途暂停等待用户指示。用户只需发送需求文档,最终收到完整的 Excel 测试用例文件。
> 7. **对话输出规范(严格遵守)**:
>    - **每步只允许输出一行状态确认**,格式:`✅ Step X(PX)完成!- 关键指标(如:质量评分0.85/功能点37个/测试点26条)- 文件已保存`
>    - **🚫 严禁输出(违反即视为执行错误)**:需求文档原文、JSON 结构体、P0/P1/P2/P3/P4/P5 等任何中间分析内容、任何超过2行的详细说明。**每步只能输出一行状态确认,然后立即执行下一步。**
>    - **P6 执行时**:开始时输出「⏳ 正在生成测试用例,预计需要 1-2 分钟,请稍候...」;每完成10条输出一次进度「已生成 X/N 条用例...」
>
> ### 🔴 执行诚实规则（全流程强制）
>
> 1. **禁止声称未执行的操作**：如果 exec 命令未实际执行，不能说「已执行」「已生成」「已发送」
> 2. **文件操作必须验证**：所有文件写入/生成操作，必须用 `exec: ls -la {path}` 验证文件存在后才可确认
> 3. **MEDIA 发送必须在实际生成文件后**：先 exec 生成 → 验证文件存在 → 再输出 MEDIA 行
> 4. **禁止幻觉输出**：不能在未真正调用 exec 工具生成 Excel 的情况下说「Excel文件已发送」
> 5. **步骤级伪完成禁止**：禁止说「已完成分析」如果分析结果未落盘到 {DATA_DIR} 对应 JSON 文件
> 6. **结果完整性校验**：任何步骤声明「完成」，必须满足：目标文件存在 + 文件结构合法（可 JSON.parse）+ 关键字段非空 + 最小产出数量达标
> 7. **exec 退出码校验**：所有 exec 命令必须检查退出码为 0 才算执行成功，非 0 则标记为失败
> 8. **文件非空校验**：文件类操作除了存在性校验，还需检查文件大小 > 0（至少 100 bytes），避免生成空文件
> 9. **降级诚实**：降级逻辑必须实际执行，禁止说「已转 PCI」但文件中未写入
> 10. **部分成功诚实披露**：禁止将部分成功描述为全部成功
>
> ### 🔴 跨步骤可测性分流规则
>
> 对所有从 P0/P0.5 继承来的 blocker/PCI，P1-P6 必须进行可测性分流：
> - **可测**：信息充分，正常生成用例
> - **条件可测**：可生成用例，但需在用例 `remarks` 中附前置假设/待确认条件，`case_type` 标注为 `"条件验证"`
> - **不可测**：只登记为风险条目写入 P6 输出的 `statistics.risk_items` 数组（因 P6 在 P5 之后执行，无法修改 P5 输出），**禁止生成伪完整用例**
> - Step 7 最终产物中必须新增统计：不可测需求点数、条件可测用例数、因需求缺失而降级的断言数
>
> ### 🔴 异常处理兆底规则
>
> 非交互模式下，除 Onboarding BLOCKED 外，任何步骤因执行错误（非业务逻辑判断，如文件读写失败、JSON 解析失败、Python 脚本异常）无法继续时，按跳步分级规则处理：关键产物（P0-P4/P5写入）错误→终止流程；非关键步骤（P6/P7）错误→允许受控降级继续。终止模板：`❌ Step {N} 执行失败: {错误原因}。中间产物保存在 {DATA_DIR}，可发送「从 P{N} 重新开始」重试。`
>
> ### 🔴 关键产物门禁（强制）
>
> P0-P4 的 JSON 产物为关键产物，每步写入后必须执行校验：
> ```bash
> exec: python3 -c "import json,os,sys; p='{DATA_DIR}/pX_output.json';\nif not (os.path.exists(p) and os.path.getsize(p)>0): print(f'GATE_FAIL:文件不存在或为空: {p}'); sys.exit(1)\ntry: json.load(open(p))\nexcept: print(f'GATE_FAIL:JSON格式无效: {p}'); sys.exit(1)\nprint('GATE_PASS')"
> ```
> 校验失败（GATE_FAIL）→ **必须终止流程并报错**，不得“简化策略”跳步继续。
> P5 为二级关键产物（合并了P2/P3/P4的数据）：写入失败（文件不存在/为空/JSON无效）→ 必须终止；质量不达标（如测试点合并不完整）→ 允许受控降级。P6-P7 为非关键产物，校验失败时允许受控降级（输出警告但可继续）。
>
> ### 🔴 跳步分级规则
>
> - **一级关键产物缺失（P0-P4 JSON文件不存在、为空或JSON格式无效）→ 必须终止**，输出 `❌ 关键产物缺失：{文件名}，流程终止。中间产物保存在 {DATA_DIR}，用户可发送「重试」重新执行。`
> - **二级关键产物P5写入失败（文件不存在/为空/JSON无效）→ 必须终止**；P5质量不达标 → 允许受控降级
- **非关键步骤失败（P6/P7）→ 允许受控降级**，输出警告但继续执行。P6失败时降级操作：跳过P6完整用例展开，直接基于P0需求结构+P1功能点树+P2测试点，生成最小可行用例集（每个功能点至少1条正向验证用例），输出简化的p6_output.json（testcases数组仅含降级用例，每条用例仍须包含完整19列字段，statistics中标记degraded:true），并输出警告 ⚠️ P6用例展开失败，已降级为最小可行用例集，建议人工补充。
> - **禁止行为**：不得“调整策略”、“简化流程”、跳过已失败的步骤继续执行。失败后唯一选项是终止或重试。
>
> ### 🔴 工具调用指导（弱模型适配）
>
> - write工具的content参数必须是纯字符串，不要嵌套JSON对象
> - JSON内容中如含引号、换行符等特殊字符，必须使用heredoc写入方式
> - 禁止连续3次工具调用失败后继续尝试同一方式，必须切换策略（如从write切换到exec heredoc）
> - **严禁自建脚本替代官方工具**：不得创建自定义 export_excel.py 或其他 tools/ 目录下的脚本替代官方版本
>
> **优先级**：关键产物门禁 > 工具调用指导。P0-P4写入失败时，允许切换策略重试1次（如write→heredoc），重试仍失败则必须终止（不适用“切换策略继续”规则）。P5-P7写入失败时，允许切换策略重试最多3次。
>
> ### 🔴 禁止自建脚本
>
> tools/ 目录下的脚本（export_excel.py、export_markdown.py、model_detect.py等）为官方工具，执行方不得创建替代版本。如果路径发现检查1.5失败，输出错误并在Step 7中直接内联输出Markdown格式用例到对话（不依赖export_markdown.py脚本），不得自建简化版export_excel.py。内联Markdown格式规范：表头含19列完整字段名（项目/类型/用例编号/需求/优先级/标题/用例菜单/预置条件/步骤/期望结果/是否冒烟用例/创建者/经办人/用例类型/测试类别/执行结果/截图/测试用例集/备注），每个用例一行，末尾附统计（总数/P0数/冒烟数/降级标记）。

---

### Step 0:接收用户需求 & 初始化

**目标**:从用户消息中提取需求文本,初始化任务上下文。

**执行指令**:

1. 从用户消息中提取 `requirement_text`(原始需求全文)
2. 识别业务域 `domain`:
   - 从需求文本中识别关键词(按优先级匹配,取第一个命中的域):
     - 交易/委托/撤单/成交/清算/结算/资金冻结/T+1 → `trade`
     - 资管/净值/申赎/申购/赎回/衍生品/期货/期权/保证金 → `asset_mgmt`
     - 风控/预警/限额/合规检查/风险控制 → `risk_ctrl`
     - 客户/跟进/开户/KYC/客户经理/客户关系 → `crm`
     - 网上营业厅/APP/适当性/产品推荐/在线交易/移动端/H5 → `etrading`
     - 运营/活动/营销/后台管理/数据报表/统计/导出 → `ops_mgmt`
     - 合规/证书/从业/监管/报送/资质/执照 → `compliance`
     - 部署/监控/服务器/权限配置/变更/IT/基础设施/投行/承销/IPO → `it_infra`
   - 无法识别 → 使用 `preferences.json` 中的 `default_domain`(默认 `trade`)
3. 生成 `task_id`:格式 `task_YYYYMMDD_HHMMSS`
4. 创建数据目录:`exec: mkdir -p ~/.openclaw/workspace/data/{task_id}`
5. 读取 `{SKILL_DIR}/user_knowledge/preferences.json`,记录用户偏好
6. 向用户确认:`「✅ 任务 {task_id} 已创建,业务域:{domain},开始分析需求...」`

**写入**:`{DATA_DIR}/task_meta.json`
```json
{
  "task_id": "...",
  "domain": "...",
  "requirement_text": "...",
  "created_at": "ISO8601",
  "preferences": { ... },
  "skill_version": "2.3.1",
  "requirement_hash": "sha256(requirement_text)",
  "preferences_hash": "sha256(preferences.json normalized)",
  "cache_signature": "{skill_version}:{domain}:{requirement_hash}:{preferences_hash}"
}
```

---

### Step 0.8(自动):PX 图片理解与测试增强

**目标**:从需求文档中抽取图片,进行理解和测试增强,生成 derived_* 数据供后续步骤消费。

**触发条件**:用户提供的需求文档为 docx 格式时自动执行。非 docx 格式或纯文本输入时跳过此步。

**内部动作**(不输出到对话):

1. **图片抽取**:
   ```bash
   exec: python3 {SKILL_DIR}/tools/image_extract.py "{docx_path}" --output-dir {DATA_DIR}/px_images --json-output {DATA_DIR}/px_extract.json
   ```
   - 失败或无图片 → 跳过 PX,继续 Step 0.5/Step 1

2. **模型能力探测**:
   ```bash
   exec: python3 {SKILL_DIR}/tools/model_detect.py "{model_id}" --full-mode
   ```
   - 获取 active_mode(vision / ocr / context_only)

3. **图片理解**：
   ```bash
   exec: python3 {SKILL_DIR}/tools/image_understand.py {DATA_DIR}/px_extract.json --mode {active_mode} --model-id "{model_id}" --task-id {task_id} --output {DATA_DIR}/px_understand.json
   ```
   > ⚠️ I-FIX-02：CLI方式仅支持 `ocr` 和 `context_only` 模式。视觉模式（vision）需要Agent在Python层面调用 `understand_images()` 并传入 `model_caller` 参数，CLI无法提供模型调用能力，视觉模式会自动降级。

4. **测试增强聚合**:
   ```bash
   exec: python3 {SKILL_DIR}/tools/image_enhance.py {DATA_DIR}/px_understand.json --output {DATA_DIR}/px_enhance.json
   ```
   - 输出含 step_subsets,供 P0-P7 各步消费

5. **写入结果**:`{DATA_DIR}/px_enhance.json`

**降级策略**:
- PX 任何步骤失败不阻断主链路,直接跳过进入 Step 0.5/Step 1
- 视觉模式失败 → 自动降级 OCR → OCR 失败 → 纯文本模式
- 纯文本模式仅注入 caption + before_text + after_text 作为 P0 补充

**对话输出**(仅此一行):
`✅ Step 0.8(PX)完成!- 图片{N}张/视觉{V}张/OCR{O}张/跳过{S}张 - 文件已保存`

**⚡ 自动推进**:完成后立即执行 Step 0.5(如开启)或 Step 1。

---

### Step 0.5(可选):PRD 质量审查

**触发条件**:`preferences.json` 中 `prd_quality_review == true`

**执行指令**:

1. 读取 `{SKILL_DIR}/prompts/P0.5_prd_quality_review.md`
2. 构造 Prompt:将 `requirement_text` 填入模板
3. 调用 LLM
4. 解析输出 JSON(执行 JSON 解析兜底)
5. 写入:`{DATA_DIR}/p0.5_output.json`
6. **生成 PRD 质量审查报告 Excel**(云端用户必须通过文件获取完整报告):
   ```bash
   exec: python3 {实际SKILL_DIR}/tools/export_prd_review.py --input {DATA_DIR}/p0.5_output.json --output {DATA_DIR}/PRD质量审查报告_{task_id}.xlsx
   # {实际SKILL_DIR} 使用 Onboarding 检查 1.5 中自动发现的实际路径
   ```
   - 成功 → 执行步骤 7
   - 失败(openpyxl 不可用等)→ 降级为纯对话文字输出,不阻塞流程
7. **发送 Excel 文件给用户**:
   ```
   MEDIA:{DATA_DIR}/PRD质量审查报告_{task_id}.xlsx
   ```
8. **在对话中输出审查摘要**(简洁版,方便快速阅读):
   ```
   📋 PRD 质量审查完成
   综合评分:{overall_score} 分({grade} {grade_label})
   🔴 阻塞问题:{blocking_count} 条  🟡 警告:{warning_count} 条  i️ 建议:{info_count} 条
   完整报告已通过 Excel 文件发送,请查收。
   ```
9. 检查结果并执行流程控制:
   - 存在 `severity == "blocking"` 的问题 → **不阻塞，不等待用户**。自动将 blocker 转为 PCI 条目写入 `p0.5_output.json`，在 `p0.5_output.json` 根级别添加 `"auto_skipped": true`（类型：boolean）和 `"skipped_blocker_count": {N}`（类型：integer），输出一行警告 `⚠️ P0.5: {N} 个 blocker 已自动转为 PCI，继续执行`，然后立即继续
   - 仅 `warning` 级别 → 追加提示 `「⚠️ PRD 存在 {warning_count} 处警告,建议补充后再生成用例,或直接继续。」` → 继续执行
   - 无问题(A/B级)→ 追加提示 `「✅ PRD 质量良好,继续生成测试用例。」` → 继续执行

**未开启时**:跳过此步,直接进入 Step 1。

---

### Step 1:P0 需求结构化

> 📌 [Step 1→2 备忘] 写文件 → 一行状态 → 立即下一步

**禁止事项**(本步高风险误操作):
- 禁止在对话中输出 P0 的 JSON 结构体
- 禁止在质量评分 ≥ 0.7 时暂停等待用户确认
- 禁止输出"是否继续"等等待语句

**内部动作**(不输出到对话):

1. 读取 Prompt:`{SKILL_DIR}/prompts/P0_requirement_structuring.md`
2. 注入知识(token 预算 ≤ 2000):
   - 必注入:`{SKILL_DIR}/knowledge/industry/{domain}.md`
   - 必注入:`{SKILL_DIR}/knowledge/methodology/design_methods.md`
   - 可选(L5):检查 `{SKILL_DIR}/user_knowledge/project/` 下是否有文件,有则读取内容最相关的 1~2 个文件(按文件名关键词匹配),无则跳过
3. 构造完整 Prompt:
   ```
   [P0 Prompt 模板内容]

   ---
   ## 注入知识

   ### 行业知识({domain})
   {industry knowledge content}

   ### 测试设计方法论
   {design_methods content}

   ### 项目知识(如有)
   {L5 content or "无"}

   ### PX 图片理解增强(如有)
   如果 {DATA_DIR}/px_enhance.json 存在,读取其中 step_subsets.P0 字段,注入以下内容:
   - derived_features:图片中提取的功能点(作为需求补充)
   - derived_test_points:图片中提取的测试点(作为需求补充)
   - degradation_notice:降级说明(如有)
   - 纯文本模式下:注入 image_context(图注 + 前后文)作为需求补充
   注入增量控制 ≤ 1500 token。无 px_enhance.json 则跳过。

   i️ T3-02 降级说明使用指引:
   - 如果 degradation_notice 字段非空,将其作为 P0 输出的一部分保留,传递到后续步骤
   - 降级说明中包含按图片类型细化的缺失信息提示,帮助用户判断哪些图片需要人工审阅
   - OCR 模式:区分降级类型(流程图/原型图/状态图)和中度提取类型(规则表/接口截图)
   - 纯文本模式:所有图类型均未解析,仅提供元数据

   ---
   ## 输入需求

   {requirement_text}
   ```
4. 调用 LLM
5. 执行 JSON 解析兜底(见下方统一逻辑)
6. 检查质量评分:
   - 解析结果中 `quality_score < 0.7` → **不阻塞，不等待用户**。自动将 `quality_check.status` 设为 `"CONDITIONAL_PASS"`（禁止写 `"PASSED"`，避免弱化质量信号），添加 `"auto_forced": true`（类型：boolean）和 `"original_score": {实际分值}`（类型：number，0~1.0），将 `missing_items` 转为 PCI 条目追加到 `blocks.unknowns` 中，输出一行警告 `⚠️ Step 1(P0): 质量评分 {score} < 0.7，已自动继续，缺失项已转 PCI`，然后立即继续
   - `quality_score >= 0.7` → 继续
7. 写入:`{DATA_DIR}/p0_output.json`

**对话输出**(仅此一行):
`✅ Step 1(P0)完成!- 质量评分{score} - 文件已保存`

**⚡ 自动推进**:完成后立即执行 Step 2,无需任何确认。

---

### Step 2:P1 功能点树生成

> 📌 [Step 2→3 备忘] 写文件 → 一行状态 → 立即下一步

**禁止事项**(本步高风险误操作):
- 禁止在对话中输出 P1 的 JSON 结构体
- 禁止输出"是否继续"等等待语句
- 禁止跳过 Step 3 直接进入后续步骤

**内部动作**(不输出到对话):

1. 读取 Prompt:`{SKILL_DIR}/prompts/P1_feature_tree_generation.md`
2. 读取上一步输出:`{DATA_DIR}/p0_output.json`
3. 构造 Prompt:将 P0 输出填入 P1 模板
4. 调用 LLM
5. 执行 JSON 解析兜底
6. 写入:`{DATA_DIR}/p1_output.json`

**对话输出**(仅此一行):
`✅ Step 2(P1)完成!- 功能点树{N}个模块 - 文件已保存`

**⚡ 自动推进**:完成后立即执行 Step 3,无需任何确认。

---

### Step 3:P2/P3/P4 三路分析(一步完成,中间不停顿)

> 📌 [Step 3→4 备忘] 写文件 → 一行状态 → 立即下一步

**禁止事项**(本步高风险误操作):
- 禁止在 3a/3b/3c 之间输出任何内容
- 禁止在 3a/3b/3c 之间等待用户
- 禁止展示任何中间 JSON

**前置验证**:
```bash
exec: cat {DATA_DIR}/p1_output.json
```
> 如果文件不存在或为空,停止执行,提示用户先完成 Step 2(P1)。

**内部动作**(不输出到对话):

**3a - P2 测试点草案**:
> 断点续跑:如果 `{DATA_DIR}/p2_output.json` 已存在且非空,跳过 3a,直接执行 3b。
1. 读取 Prompt:`{SKILL_DIR}/prompts/P2_test_point_draft.md`
2. 注入知识(token 预算 ≤ 2000):
   - 必注入:`{SKILL_DIR}/knowledge/methodology/api_test_standard.md`
   - 必注入:`{SKILL_DIR}/knowledge/methodology/boundary_rules.md`
3. 读取:`{DATA_DIR}/p1_output.json`
4. 构造 Prompt:
   ```
   [P2 Prompt 模板内容]

   ---
   ## 注入知识

   ### 接口测试标准
   {api_test_standard content}

   ### 边界值规则
   {boundary_rules content}

   ### PX 图片测试点增强(如有)
   如果 {DATA_DIR}/px_enhance.json 存在,读取 step_subsets.P2.derived_test_points 注入。
   注入增量控制 ≤ 1500 token。

   ---
   ## 输入:功能点树

   {p1_output JSON}
   ```
5. 调用 LLM
6. 执行 JSON 解析兜底
7. 构造完整JSON后，使用以下命令写入文件（禁止使用write工具，必须用exec heredoc方式）：
   ```bash
   exec: cat << 'JSONEOF' > {DATA_DIR}/p2_output.json
   {LLM生成的完整JSON内容}
   JSONEOF
   ```
8. 不输出任何内容,立即执行 3b

**3b - P3 风险点识别**:
> 断点续跑:如果 `{DATA_DIR}/p3_output.json` 已存在且非空,跳过 3b,直接执行 3c。
1. 读取 Prompt:`{SKILL_DIR}/prompts/P3_risk_identification.md`
2. 注入知识(token 预算 ≤ 2000):
   - 必注入:`{SKILL_DIR}/knowledge/industry/{domain}.md`(风险规则部分)
   - PX 增强(如有):读取 {DATA_DIR}/px_enhance.json 中 step_subsets.P3.derived_risks 注入,增量 ≤ 1500 token
3. 读取:`{DATA_DIR}/p1_output.json`
4. 构造 Prompt:将知识和 P1 输出填入 P3 模板
5. 调用 LLM
6. 执行 JSON 解析兜底
7. 构造完整JSON后，使用以下命令写入文件（禁止使用write工具，必须用exec heredoc方式）：
   ```bash
   exec: cat << 'JSONEOF' > {DATA_DIR}/p3_output.json
   {LLM生成的完整JSON内容}
   JSONEOF
   ```
8. 不输出任何内容,立即执行 3c

**3c - P4 待确认问题识别**:
> 断点续跑:如果 `{DATA_DIR}/p4_output.json` 已存在且非空,跳过 3c,直接执行 3d。
1. 读取 Prompt:`{SKILL_DIR}/prompts/P4_pci_identification.md`
2. 读取:`{DATA_DIR}/p1_output.json`
3. 构造 Prompt:将 P1 输出填入 P4 模板
   - PX 增强(如有):读取 {DATA_DIR}/px_enhance.json 中 step_subsets.P4.derived_questions 注入,增量 ≤ 1500 token
4. 调用 LLM
5. 执行 JSON 解析兜底
6. 构造完整JSON后，使用以下命令写入文件（禁止使用write工具，必须用exec heredoc方式）：
   ```bash
   exec: cat << 'JSONEOF' > {DATA_DIR}/p4_output.json
   {LLM生成的完整JSON内容}
   JSONEOF
   ```
7. 不输出任何内容,立即执行 3d

**3d - 验证(仅验证,不生成对话输出)**:
```bash
exec: python3 -c "
import json, os, sys
data_dir = '{DATA_DIR}'
results = {}
for step, fname in [('P2', 'p2_output.json'), ('P3', 'p3_output.json'), ('P4', 'p4_output.json')]:
    path = os.path.join(data_dir, fname)
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        print(f'FAIL:{step}:MISSING_FILE'); sys.exit(1)
    d = json.load(open(path))
    results[step] = d

tp_list = results.get('P2', {}).get('test_points', [])
risk_list = results.get('P3', {}).get('risk_points', [])
pci_list = results.get('P4', {}).get('pci_list', [])
tp = len(tp_list)
risk = len(risk_list)
pci = len(pci_list)
feature_count = len(json.load(open(os.path.join(data_dir, 'p1_output.json'))).get('feature_tree', {}).get('modules', []))
if tp < max(1, feature_count * 2):
    print(f'FAIL:P2:QUALITY_TEST_POINTS_TOO_FEW:{tp}'); sys.exit(1)
if risk < 2:
    print(f'FAIL:P3:QUALITY_RISK_TOO_FEW:{risk}'); sys.exit(1)
if any(not x.get('title') for x in tp_list[:min(len(tp_list),5)]):
    print('FAIL:P2:QUALITY_EMPTY_TITLE'); sys.exit(1)
if risk_list and any(not x.get('description') for x in risk_list[:min(len(risk_list),5)]):
    print('FAIL:P3:QUALITY_EMPTY_DESCRIPTION'); sys.exit(1)
print(f'PASS:{tp}:{risk}:{pci}')
"
```
> exec 返回 `PASS:{tp}:{risk}:{pci}` → 输出对话输出行,然后立即执行 Step 4
> exec 返回 `FAIL:{step}:{reason}` → 输出:`❌ Step 3 子任务 {step} 校验失败({reason})，流程终止。已完成子任务结果已保留，用户可发送「重试Step3」从失败处恢复，系统将复用已完成子任务，仅补跑缺失或不达标部分。`

**对话输出**(仅此一行):
`✅ Step 3(P2/P3/P4)完成!- 测试点{tp}条/风险{risk}条/PCI{pci}条 - 文件已保存`

**⚡ 自动推进**:验证通过后立即执行 Step 4,无需任何确认。

---

### Step 4:P5 测试点合并与优先级

> 📌 [Step 4→5 备忘] 写文件 → 一行状态 → 立即下一步
> 📌 [Step 4 截断自愈] 若本步输出被截断、文件半写入、JSON 不完整或关键字段缺失,必须自动补全/重跑,不得等待用户追问

**禁止事项**(本步高风险误操作):
- 禁止在对话中输出 P5 的 JSON 结构体
- 禁止输出"是否继续"等等待语句
- 禁止缺少 p2/p3/p4 任一输入时继续执行

**前置验证**:
```bash
exec: python3 -c "
import os, sys
for f in ['p2_output.json','p3_output.json','p4_output.json']:
    if not os.path.exists('{DATA_DIR}/'+f) or os.path.getsize('{DATA_DIR}/'+f) == 0:
        print(f'缺失 {f}'); sys.exit(1)
print('ok')
"
```

**内部动作**(不输出到对话):

1. 读取 Prompt:`{SKILL_DIR}/prompts/P5_test_point_merge.md`
2. 注入知识(token 预算 ≤ 2000):
   - 必注入:`{SKILL_DIR}/knowledge/methodology/automation_scoring.md`
3. 读取三路输入:
   - `{DATA_DIR}/p2_output.json`
   - `{DATA_DIR}/p3_output.json`
   - `{DATA_DIR}/p4_output.json`
4. 构造 Prompt:
   ```
   [P5 Prompt 模板内容]

   ---
   ## 注入知识

   ### 自动化评分标准
   {automation_scoring content}

   ---
   ## 输入

   ### 测试点草案(P2)
   {p2_output JSON}

   ### 风险点(P3)
   {p3_output JSON}

   ### 待确认问题(P4)
   {p4_output JSON}
   ```
5. 调用 LLM
6. 执行 JSON 解析兜底
7. 构造完整JSON后，使用以下命令写入文件（禁止使用write工具，必须用exec heredoc方式）：
   ```bash
   exec: cat << 'JSONEOF' > {DATA_DIR}/p5_output.json
   {LLM生成的完整JSON内容}
   JSONEOF
   ```
8. **完成性校验(强制)**:
   ```bash
   exec: python3 -c "
   import json, os, sys
   path = '{DATA_DIR}/p5_output.json'
   if not os.path.exists(path) or os.path.getsize(path) == 0:
       print('FAIL:MISSING_OR_EMPTY'); sys.exit(1)
   try:
       d = json.load(open(path))
   except Exception:
       print('FAIL:INVALID_JSON'); sys.exit(1)
   tps = d.get('test_points', [])
   required_top = ['merge_log', 'quality_warnings', 'coverage_summary']
   if not isinstance(tps, list) or len(tps) == 0:
       print('FAIL:TEST_POINTS_EMPTY'); sys.exit(1)
   missing_top = [k for k in required_top if k not in d]
   if missing_top:
       print(f'FAIL:MISSING_TOP_KEYS:{missing_top}'); sys.exit(1)
   print(f'PASS:{len(tps)}')
   "
   ```
9. 若校验失败:自动重跑 Step 4 一次并覆盖不完整文件;仍失败则报错终止,不得进入 Step 5,不得等待用户追问
10. 本校验仅使用当前 P5 schema 已存在的顶层键,禁止引用 schema 中不存在的统计字段名

**对话输出**(仅此一行):
`✅ Step 4(P5)完成!- 合并后测试点{N}条 - 文件已保存`

**⚡ 自动推进**:完成后立即执行 Step 5,无需任何确认。

---

### Step 5:P6 用例展开

> 📌 [Step 5→6 备忘] 分批生成,每批只输出进度行,不输出 JSON,完成后立即下一步

**禁止事项**(本步高风险误操作):
- 禁止在对话中输出任何用例 JSON 或数组
- 禁止在批次之间等待用户
- 禁止在 p6_output.json 写入失败时自行生成 Excel

**前置文件校验(必须在执行任何操作前完成)**:
```bash
exec: python3 -c "
import json, sys, os
required = ['p2_output.json', 'p3_output.json', 'p4_output.json', 'p5_output.json']
data_dir = os.path.expanduser('~/.openclaw/workspace/data/{task_id}')
missing = []
for f in required:
    path = os.path.join(data_dir, f)
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        missing.append(f)
if missing:
    print(f'❌ 前置步骤未完成,缺少文件:{missing}')
    print('FAIL:前置步骤缺失,流程终止。中间产物已保留,用户可指定步骤重新开始。')
    sys.exit(1)
print('✅ 前置文件校验通过,继续执行 P6。')
"
```
> 如果校验失败(任一文件缺失或为空),**必须停止执行,提示用户重新执行缺失步骤**,不得继续生成用例。

**内部动作**(不输出到对话):

1. 读取 Prompt:`{SKILL_DIR}/prompts/P6_testcase_generation.md`
2. 注入知识(token 预算 ≤ 4000,本步放宽):
   - 必注入:`{SKILL_DIR}/knowledge/company_standards/testcase_design_spec.md`
   - 必注入:缺陷模式注入(见下方「缺陷模式注入逻辑」)
   - 可选(L6):检查 `{SKILL_DIR}/user_knowledge/experience/` 下是否有文件,有则读取最相关的 1~3 个作为 few-shot 示例注入,无则跳过
3. 读取:`{DATA_DIR}/p5_output.json`
4. 构造 Prompt:
   ```
   [P6 Prompt 模板内容]

   ---
   ## 注入知识

   ### 测试用例设计细则(公司标准)
   {testcase_design_spec content}

   ### 历史缺陷模式({domain},前 {max_defect_patterns} 条)
   {defect patterns text - 见下方转换格式}

   ### 经验库 few-shot(如有)
   {L6 content or "无"}

   ---
   ## 输入:带优先级测试点

   {p5_output JSON}
   ```
5. **开始时输出进度提示**:`⏳ 正在生成测试用例,预计需要 1-2 分钟,请稍候...`
6. **分批生成(强制)**:将 P5 测试点按每批 ≤ 10 个分批调用 LLM,每批完成后:
   - 输出进度:`已生成 X/N 条用例(第 Y 批完成)...`
   - 将本批结果追加到内存列表,并**立即落盘**到 `{DATA_DIR}/p6_batches/batch_{Y}.json`
   - 同步写入 `{DATA_DIR}/p6_progress.json`,记录 `completed_batches / total_batches / completed_case_count / failed_batches`
   - 合并规则:用例编号按模块前缀编号(如 TC-模块A-001),避免重复
7. **批次级恢复**:如中途中断或重试,仅补跑缺失/失败的 batch 文件,已完成批次直接复用,不得整轮重生
8. 所有批次完成后,合并批次结果统一写入 `{DATA_DIR}/p6_output.json`
   - **P6统一使用write→校验→cp方式写入**（禁止heredoc，P6 JSON通常较大且结构复杂）：
     1. 使用 `write` 工具写入临时文件 `{DATA_DIR}/p6_raw.json`
     2. 校验：`exec: python3 -c "import json,sys; d=json.load(open('{DATA_DIR}/p6_raw.json')); sys.exit(0) if len(d.get('testcases',[]))>0 else (print('FAIL:testcases为空'),sys.exit(1))"`
     3. 校验通过后：`exec: mv {DATA_DIR}/p6_raw.json {DATA_DIR}/p6_output.json`
     4. 校验失败时：`exec: rm -f {DATA_DIR}/p6_raw.json`（清理临时文件）→ 终止流程
9. 执行 JSON 解析兜底
10. **字段完整性校验(强制)**:`testcases[].fields` 中必须包含公司 19 列全部 key:
   `project, case_type, case_id, requirement, priority, title, menu_path, preconditions, steps, expected_results, is_smoke, creator, assignee, test_case_type, test_category, status, screenshot, test_suite, remarks`
   - 允许空字符串的字段:`assignee, status, screenshot`
   - 其余字段不得缺 key;如无值,也必须显式输出空字符串,不得省略字段
11. 若任一 case 缺少上述 key,或仅凭猜测/手工臆造 P5 active 数据生成 P6 输出 → 视为失败,必须回到真实 P5 结果重生,不得带病进入 Step 6/7

**对话输出**:
- 开始时:`⏳ 正在生成测试用例,预计需要 1-2 分钟,请稍候...`
- 每批完成:`已生成 X/N 条用例(第 Y 批完成)...`
- 全部完成:`✅ Step 5(P6)完成!- 用例{N}条 - 文件已保存`

**⚡ 自动推进**:完成后立即执行 Step 6,无需任何确认。

#### 缺陷模式注入逻辑

```
1. 读取 {SKILL_DIR}/knowledge/defect_patterns/defects_by_domain/{domain}.txt
2. 逐行解析 JSONL,每行是一个 JSON 对象
3. 按 severity 字段排序(high > medium > low)
4. 取前 N 条(N = preferences.max_defect_patterns,默认 20)
5. 每条转换为以下文本格式:

   ### 缺陷模式 [严重度: {severity}]
   - 类别: {category}
   - 模式描述: {description}
   - 测试建议: {test_suggestion}

6. 拼接所有条目,控制总量在 2000 tokens 以内
7. 如果 JSONL 文件不存在或为空,输出 "无历史缺陷模式" 并继续(不阻塞)
```

---

### Step 6:P7 质量自检(支持自动重试)

> 📌 [Step 6→7 备忘] 写文件 → 一行状态 → 立即下一步

**禁止事项**(本步高风险误操作):
- 禁止在对话中输出质量自检的 JSON 报告
- 禁止在自检通过时暂停等待用户确认
- 禁止在重试次数未用尽时直接结束流程

**内部动作**(不输出到对话):

1. 初始化重试计数器:`p7_retry_count = 0`
2. 读取 Prompt:`{SKILL_DIR}/prompts/P7_quality_gate.md`
3. 读取:`{DATA_DIR}/p6_output.json`
4. 构造 Prompt:将 P6 输出填入 P7 模板
5. 调用 LLM
6. 执行 JSON 解析兜底(见「JSON 解析兜底」一节)
7. 检查结果:
   - `status == "PASSED"` 或 `gate_result == "PASSED"` → 继续 Step 7
   - (`status == "FAILED"` 或 `gate_result == "FAILED"`) 且 `p7_retry_count < 2` → 执行自动重试流程(见下方)
   - (`status == "FAILED"` 或 `gate_result == "FAILED"`) 且 `p7_retry_count >= 2` → 输出 `「⚠️ 质量自检未通过(已重试 2 次):{issues}。建议人工复核。如需重新生成用例,请发送"重新生成测试用例"。」` → 继续 Step 7
8. 写入:`{DATA_DIR}/p7_output.json`

**对话输出**(仅此一行):
`✅ Step 6(P7)完成!- 质量自检{PASSED/FAILED} - 文件已保存`

#### T2-06:置信度相关门禁规则(对齐方案 §10 + §20.6)

P7 质量自检时,需额外检查图片置信度相关项:

1. **中置信度图片关注**:检查 `_confidence_tier == "medium"` 的图片,其 derived_* 已入链路但需确认:
   - 对应的 derived_test_points 是否可执行(非泛泛描述)
   - 对应的 derived_risks 是否已标注置信度提醒
   - 如发现中置信度图片的 derived_* 质量不达标,在 P7 报告中标记为 warning(不阻断)

2. **低置信度图片确认**:检查 `_confidence_tier == "low"` 的图片,确认其 derived_* 未入链路:
   - 如发现低置信度图片的 derived_* 意外入链路,标记为 error

3. **ocr_degraded 视为已解析**(§20.6 边界注释):
   - P7 门禁检查"高价值图片是否已解析"时,ocr_degraded 视为已解析(已尝试处理且产出了结果)
   - 但 derived_* 是否入链路仍受置信度规则约束(< 0.5 不入链路)
   - 举例:一张 flowchart 在 OCR 模式下置信度 0.45,extraction_mode 为 ocr_degraded。P7 门禁"高价值图片是否已解析"→ 通过;但 derived_test_points 因置信度 < 0.5 不入链路

**⚡ 自动推进**:自检通过后立即执行 Step 7;自检失败且重试次数 < 2 时,自动回退 P6 重新生成,不暂停等待用户。

#### 自动重试流程(当 status == "FAILED" 且 p7_retry_count < 2)

```
1. 从 P7 输出中提取不通过项列表 p7_failed_issues
2. p7_retry_count += 1
3. 输出:「🔄 质量自检未通过(第 {p7_retry_count} 次重试),正在将问题反馈给 P6 重新生成...」
4. 重新执行 Step 5(P6 用例展开),但在 P6 Prompt 末尾追加以下内容:

   ---
   ## 质量自检反馈(请修复以下问题后重新生成)
   {p7_failed_issues}

5. 优先复用 `{DATA_DIR}/p6_batches/` 中已通过校验的批次,仅重生成 `fix_actions` 命中的 case 所在批次或缺失批次
6. P6 重新生成完成后,先更新对应 batch 文件,再重新合并写入新的 `{DATA_DIR}/p6_output.json`
7. 回到 Step 6 第 2 步,重新执行 P7 质量自检
```

> **注意**:重试时仅重新执行 Step 5(P6)和 Step 6(P7),不影响其他步骤的缓存结果。重试时跳过断点续跑的缓存检查(因为需要强制重新生成)。

---

### Step 7:输出结果

> 📌 [Step 7 备忘] 这是唯一合法结束点,Excel 只能通过脚本生成

**禁止事项**(本步最高风险误操作):
- **禁止任何情况下绕过 `export_excel.py` 脚本,自行生成 Excel 内容**
- 禁止 `p6_output.json` 校验失败时继续执行
- 禁止输出中间用例数据、JSON 片段到对话
- 禁止修改公司 19 列 Excel 模板字段格式

**内部动作**(不输出到对话):

1. 前置校验 `p6_output.json`:
   ```bash
   exec: python3 -c "
   import os, sys, json
   REQUIRED = ['project','case_type','case_id','requirement','priority','title','menu_path','preconditions','steps','expected_results','is_smoke','creator','assignee','test_case_type','test_category','status','screenshot','test_suite','remarks']
   path = '{DATA_DIR}/p6_output.json'
   if not os.path.exists(path) or os.path.getsize(path) == 0:
       print('FAIL:p6_output.json 缺失或为空'); sys.exit(1)
   d = json.load(open(path))
   cases = d.get('testcases', [])
   if not cases:
       print('FAIL:testcases 为空'); sys.exit(1)
   for idx, case in enumerate(cases, start=1):
       fields = case.get('fields', case) if isinstance(case, dict) else {}
       missing = [k for k in REQUIRED if k not in fields]
       if missing:
           print(f'FAIL:case#{idx} 缺少字段:{missing}'); sys.exit(1)
   print(f'PASS:{len(cases)}')
   "
   ```
   > 返回 FAIL → **停止执行,输出错误提示,不得自行生成 Excel,不得手工补 Excel**,提示用户发送「重新生成」重试

2. 读取 `{DATA_DIR}/p6_output.json`
3. 统计用例数量 `case_count`
4. 生成 Markdown 格式用例摘要(前 5 条预览):
   ```markdown
   ## 测试用例生成结果

   任务ID:{task_id}
   业务域:{domain}
   用例总数:{case_count}
   质量自检:{p7_status}

   ### 用例预览(前 5 条)

   | 编号 | 用例简述 | 优先级 | 冒烟 |
   |------|---------|--------|------|
   | {case_id} | {title} | {priority} | {is_smoke} |
   ...
   ```
5. 生成 Excel(必须通过脚本):

   **文件名规则**:`测试用例_[需求名]_[任务ID].xlsx`
   - `[需求名]`:取需求文档标题中的系统名+版本号+核心功能关键词,最多20字,去除标点和空格。示例:`集团CRM_XCV1.0.12_兴光闪耀总榜`
   - `[任务ID]`:即 `{task_id}`,格式 `task_YYYYMMDD_HHMMSS`
   - 完整示例:`测试用例_集团CRM_XCV1.0.12_兴光闪耀总榜_task_20260422_121901.xlsx`

   ```bash
   exec: python3 {实际SKILL_DIR}/tools/export_excel.py --input {DATA_DIR}/p6_output.json --output {DATA_DIR}/测试用例_[需求名]_{task_id}.xlsx
   # 注意:{实际SKILL_DIR} 使用检查 1.5 中自动发现的实际路径,不得使用字面量 {SKILL_DIR}
   ```
   > 脚本失败 → **按统一导出失败策略处理,不得自行生成 Excel**

   **统一导出失败策略**:
   - 第 1 次失败:自动重试 1 次同一脚本命令
   - 重试成功:继续发送 Excel,流程正常结束
   - 重试仍失败:调用 `export_markdown.py` 生成真正的 Markdown 用例文件（禁止用 `cp .json → .md` 伪装）：
     ```bash
     exec: python3 {实际SKILL_DIR}/tools/export_markdown.py --input {DATA_DIR}/p6_output.json --output {DATA_DIR}/测试用例_[需求名]_{task_id}.md
     ```
   - Markdown 生成成功:用 MEDIA 发送 .md 文件，完成消息说明「⚠️ Excel 生成失败，已发送 Markdown 格式用例文件」
   - Markdown 也失败且存在 `p6_output.json`:直接发送 JSON 原文件（保留 .json 后缀，不要伪装为 .md），完成消息说明「⚠️ Excel 生成失败，已发送 JSON 格式原始用例数据」
   - `p6_output.json` 缺失/为空:停止流程,提示用户发送"重新生成"重试
   - **任何情况下都不得绕过 `export_excel.py` 手工拼 Excel**

   **Excel 输出约束**:
   - 只输出用例数据行,**禁止在 Excel 末尾追加统计行**(如"用例总数""P0用例数"等汇总信息)
   - 统计信息只在对话中文字输出,不写入 Excel

6. **Step 7 导出门禁（强制）**：Excel/Markdown 导出后必须校验：
   ```bash
   exec: python3 -c "import os,sys; p='{DATA_DIR}/测试用例_[需求名]_{task_id}.xlsx'; sys.exit(0) if (os.path.exists(p) and os.path.getsize(p)>0) else (print(f'EXPORT_FAIL:文件不存在或为空: {p}'),sys.exit(1))"
   ```
   导出门禁失败后完整降级链（与统一导出失败策略一致）：
   - EXPORT_FAIL → 重试export_excel.py一次
   - 仍失败 → 降级调用export_markdown.py生成Markdown文件
   - Markdown也失败 → 内联输出Markdown格式用例到对话（格式：表头含19列字段名、每个用例一行、末尾附统计）
   - 内联也失败 → 发送p6_output.json原文件
   - 全部失败 → 报错终止

7. 发送文件给用户:
   ```
   MEDIA:{DATA_DIR}/测试用例_[需求名]_{task_id}.xlsx
   ```
   > 重要:必须将 `{DATA_DIR}` 替换为实际路径(如 `/root/.openclaw/workspace/data/task_20260424_140500`),将 `[需求名]` 替换为实际需求名,将 `{task_id}` 替换为实际任务ID。不得输出占位符字面量。
   > **MEDIA 必须全大写**——OpenClaw 解析大小写敏感，`media:` 或 `Media:` 不会触发文件发送。行前后不能有任何空白字符，不能被 markdown 代码块包裹。
   > 示例:`MEDIA:/root/.openclaw/workspace/data/task_20260424_140500/测试用例_集团CRM_V1.0.14_兴光闪耀优化_task_20260424_140500.xlsx`

7. 输出 L6 学习邀请(固定追加,不可省略):
   ```
   💡 L6 经验学习:如果你对这批用例进行了评审或修改,可以把修改后的 Excel 发给我,我会对比原版和修改版,提取改动规律(如哪类场景被补充、哪类描述被优化),存入 L6 经验库,下次生成同类需求时自动参考,持续提升用例质量。
   回复「学习」并附上修改后的 Excel → 触发经验沉淀
   ```
   收到用户回复「学习」并附文件后:
   - 读取用户上传的 Excel 文件
   - 与 `{DATA_DIR}/p6_output.json` 对比,提取新增/修改/删除的用例及改动原因
   - 将经验摘要写入 `{SKILL_DIR}/user_knowledge/experience/{task_id}_experience.json`,格式:
     ```json
     {
       "task_id": "{task_id}",
       "domain": "{domain}",
       "requirement_summary": "需求简述",
       "lessons": [
         {"type": "补充场景", "description": "补充了文件大小边界值用例"},
         {"type": "优化描述", "description": "期望结果改为具体可观测的状态描述"}
       ],
       "created_at": "ISO8601"
     }
     ```
   - 输出「✅ 已学习 X 条经验,存入 L6 经验库。下次生成同类需求时将自动参考。」

**对话输出**:
`✅ 测试用例已生成,共 {case_count} 条。Excel 文件已发送。`


---

## JSON 解析兜底逻辑(每步必用)

每次调用 LLM 获得响应后,按以下顺序解析:

```
1. 尝试直接 JSON.parse(response)
   → 成功:使用解析结果

2. 失败 → 正则提取:
   - 尝试匹配 ```json\n...\n``` 代码块中的内容
   - 尝试匹配响应中第一个 { ... } 或 [ ... ] 块(贪婪匹配最外层)
   → 对提取内容再次 JSON.parse
   → 成功:使用解析结果

3. 仍失败 → 重试一次:
   - 在原 Prompt 末尾追加:「重要:只输出合法 JSON,不要包含任何其他文字、注释或 markdown 标记。」
   - 重新调用 LLM
   - 对响应重复步骤 1~2

4. 重试仍失败 → 报错:
   - 输出:「❌ Step {N} JSON 解析失败,已重试 1 次。原始响应已保存到 {DATA_DIR}/p{n}_raw_response.txt，供用户排查。」
   - 将原始响应写入 {DATA_DIR}/p{n}_raw_response.txt
   - 终止流程
```

---

## 断点续跑

每步开始前,检查 `{DATA_DIR}/p{n}_output.json` 是否已存在:
- 存在且非空 → **复用缓存结果**(该步骤已在之前会话中正常执行并保存),直接读取已有结果,输出 `「i️ Step {N} 已有缓存结果,复用。」`

> ⚠️ **重要区分**:「复用缓存结果」是合法行为,表示该步骤已正常执行并保存了结果。「跳过步骤」是严禁行为,表示未执行该步骤直接进入下一步。两者不得混淆。
- 不存在或为空 → 正常执行

用户可发送「从 P{n} 重新开始」来强制从某步重新执行(删除该步及后续所有 output 文件)。

---

## 引用文件清单

| 文件路径(相对 SKILL_DIR) | 用途 | 使用步骤 |
|---------------------------|------|---------|
| `prompts/P0_requirement_structuring.md` | P0 需求结构化 Prompt | Step 1 |
| `prompts/P0.5_prd_quality_review.md` | PRD 质量审查 Prompt | Step 0.5 |
| `prompts/P1_feature_tree_generation.md` | P1 功能点树 Prompt | Step 2 |
| `prompts/P2_test_point_draft.md` | P2 测试点草案 Prompt | Step 3 |
| `prompts/P3_risk_identification.md` | P3 风险点识别 Prompt | Step 3(子步骤 3b) |
| `prompts/P4_pci_identification.md` | P4 PCI 识别 Prompt | Step 3(子步骤 3c) |
| `prompts/P5_test_point_merge.md` | P5 合并优先级 Prompt | Step 4 |
| `prompts/P6_testcase_generation.md` | P6 用例展开 Prompt | Step 5 |
| `prompts/P7_quality_gate.md` | P7 质量自检 Prompt | Step 6 |
| `knowledge/industry/{domain}.md` | L1 行业知识 | Step 1, Step 3(子步骤 3b) |
| `knowledge/methodology/design_methods.md` | L2 设计方法论 | Step 1 |
| `knowledge/methodology/api_test_standard.md` | L2 接口测试标准 | Step 3 |
| `knowledge/methodology/boundary_rules.md` | L2 边界值规则 | Step 3 |
| `knowledge/methodology/automation_scoring.md` | L2 自动化评分 | Step 4 |
| `knowledge/company_standards/testcase_design_spec.md` | L3 用例设计细则 | Step 5 |
| `knowledge/defect_patterns/defects_by_domain/{domain}.txt` | L4 历史缺陷 | Step 5 |
| `knowledge/config/project_dict.json` | 项目字典(用于填充「项目」字段) | Step 5 |
| `user_knowledge/project/` | L5 项目知识 | Step 1 |
| `user_knowledge/experience/` | L6 经验库 | Step 5 |
| `user_knowledge/preferences.json` | 用户偏好 | Step 0 |
| `tools/export_excel.py` | 测试用例 Excel 生成 | Step 7 |
| `tools/export_markdown.py` | 测试用例 Markdown 生成（降级方案） | Step 7 |
| `tools/export_prd_review.py` | PRD 质量审查报告 Excel 生成 | Step 0.5 |
| `tools/image_extract.py` | docx 图片抽取与章节映射 | Step 0.8 (PX) |
| `tools/model_detect.py` | 模型视觉能力探测 | Step 0.8 (PX) |
| `tools/image_understand.py` | 图片理解调度(视觉/OCR/纯文本) | Step 0.8 (PX) |
| `tools/image_enhance.py` | 测试增强聚合(去重/冲突/门禁) | Step 0.8 (PX) |
| `prompts/PX_image_understand.md` | PX 视觉模式图片理解 Prompt | Step 0.8 (PX) |
| `knowledge/model_vision_capability.json` | 已知模型视觉能力映射表 | Step 0.8 (PX) |

---

## 错误处理总则

| 错误类型 | 处理方式 |
|---------|---------|
| 知识文件不存在 | 跳过该知识注入,输出 `⚠️ 知识文件缺失: {path},已跳过` |
| LLM 调用超时 | 重试 1 次,仍超时则报错终止 |
| JSON 解析失败 | 执行兜底逻辑(见上方) |
| 中间结果文件写入失败 | 报错终止,提示检查磁盘空间和权限 |
| openpyxl 不可用 | 自动重试 1 次导出;仍失败则输出 Markdown 摘要并标记"导出失败",不得手工生成 Excel |
| 用户发送"取消"/"停止" | 立即终止,保留已完成的中间结果 |

---

## 已知限制

1. P0.5 PRD 质量审查不支持自动重试
2. L6 经验库 few-shot 注入为简单文件名匹配,非向量检索
3. 大 PRD 分批阈值固定为 30 个测试点
4. Excel 导出依赖 openpyxl;不可用时按统一导出失败策略处理(自动重试一次,失败后降级为 Markdown 格式用例文件,再失败发送 JSON 原文件)
5. 非交互模式依赖 LLM 遵守 SKILL.md 文字约束,存在小概率不遵守的风险(长期建议 TaskFlow 改造)

---

## Changelog

### v2.3.1 (2026-04-26)

**变更类型**: fix

**变更内容**:
1. model_detect.py 增加 provider 前缀剥离，修复 Doubao-Seed-2.0-pro 等带前缀模型ID被误判降级为OCR的问题
2. model_vision_capability.json 新增 doubao-seed-2.0-pro 等精确匹配条目
3. SKILL.md Step 3/4 JSON 写入改用 heredoc 方式，解决弱模型 tool calling 失败问题
4. SKILL.md Step 5 (P6) 大JSON采用 write→校验→mv 分步写入策略
5. SKILL.md 新增关键产物门禁：P0-P4 JSON写入后必须校验，失败则终止
6. SKILL.md 新增跳步分级规则：关键产物缺失必须终止，非关键步骤允许受控降级
7. SKILL.md 新增工具调用指导（弱模型适配）和禁止自建脚本规则
8. SKILL.md Onboarding 输出加“已自动继续”后缀，防止被误解为需用户回复
9. SKILL.md 检查1.5路径发现增加环境变量兜底和容器常见路径
10. model_detect.py 增加日志输出，便于排查模型能力检测结果
11. 门禁校验脚本assert改为if+sys.exit(1)，防止python3 -O优化跳过
12. P6写入策略移除5KB阈值判断，统一使用write→校验→mv方式（避免LLM无法精确判断字节数）
13. P5提升为二级关键产物：写入失败必须终止，质量不达标允许降级
14. 跳步分级触发条件新增"JSON格式无效"，与关键产物门禁一致
15. 路径发现失败时Markdown降级改为内联输出（不依赖export_markdown.py脚本）
16. P6校验失败时清理p6_raw.json临时文件（mv替代cp）
17. Onboarding非交互总则升级为全流程非交互规则（覆盖Onboarding→Step 0-7）
18. Step 7新增导出门禁，Excel/Markdown导出后强制校验文件存在且非空
19. P6降级操作具体化：最小可行用例集+degraded:true标记+警告输出
20. 工具调用指导vs门禁优先级明确：关键产物门禁>工具调用指导
21. 异常处理兆底规则与跳步分级规则措辞统一
22. 路径发现find命令加timeout 10和-print -quit优化

**影响范围**:
- model_detect.py: model_id 预处理逻辑变更，所有带 provider 前缀的模型ID受影响
- SKILL.md: Step 3/4/5 写入方式变更，Onboarding/路径发现/跳步规则增强

### v2.3.0 (2026-04-26)

**变更类型**: fix + behavior-change

**变更内容**:
1. Step 0.5 blocker 处理:从「等待用户强制跳过」改为「自动转 PCI 继续执行」,新增 `auto_skipped`/`skipped_blocker_count` 字段
2. Step 1 质量门禁:从「等待用户强制继续」改为「自动 CONDITIONAL_PASS 继续执行」,新增 `auto_forced`/`original_score` 字段,禁止写 `PASSED`
3. 新增「执行诚实规则」(全流程10条),解决 Excel 文件幻觉发送问题
4. 新增「跨步骤可测性分流规则」:可测/条件可测/不可测三分类
5. 新增「异常处理兆底规则」:执行错误→终止,不等用户
6. Step 7 输出增加文件生成验证和三级降级机制(Excel→Markdown→JSON)
7. MEDIA 指令强制全大写,独占一行,无前后空白
8. 新增 `export_markdown.py` 降级脚本,禁止 `cp .json → .md` 伪装
9. `export_excel.py` 增加 try-catch 兜底、空列表警告、写入异常捕获
10. P6 质量门禁冒烟占比从固定"10%~20%"改为分档规则(与生成规则/P7一致)
11. P6/P7 P0占比从强制"≤15%"改为建议"≤40%"(非强制,避免缩减必要用例)
12. P6 增加 blocked 测试点可测性分流(含6类核心缺失判定清单)
13. p6_output.schema.json 新增"条件验证" enum
14. P6 新增"禁止伞形用例规则",P7 新增 C9 伞形用例检测(WARNING级别)
15. SKILL.md blocked不可测落盘位置从 P5 的 blocked_test_points 改为 P6 的 statistics.risk_items

**影响范围**:
- 所有步骤的"等待用户"指令被非交互模式覆盖
- `p0_output.json` 新增可选字段 `auto_forced`/`original_score`(quality_check 对象内),status 新增 `CONDITIONAL_PASS` 枚举值
- `p0.5_output.json` 新增可选字段 `auto_skipped`/`skipped_blocker_count`(根级别)
- Step 7 行为变更:先验证后发送,支持降级输出

**兼容性**: ⚠️ 行为性变更,原有"等待用户确认"语义不再生效
