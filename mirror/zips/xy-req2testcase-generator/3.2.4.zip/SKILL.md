---
name: xy-req2testcase-generator
description: "AI驱动的需求→测试用例生成能力。V3.2.4架构：orchestrator代码控制流程，Agent只负责生成内容。8段确认模式，用户掌控节奏。图片理解API集成（腾讯云数据万象OCR+标签）。"
version: "3.2.4"
metadata:
  author: "券商科技测试团队"
  architecture: "orchestrator-driven"
---

# xy-req2testcase-generator V3.2.4

> 版本:3.2.4
> 架构:orchestrator代码控制 + Agent生成内容 + 8段确认模式

---

## 🔴 运行协议

**核心原则:orchestrator.py控制流程,Agent只负责执行prompt返回JSON。**

**参数自动化:orchestrator自动发现skill_dir、自动回填data_dir/task_id,Agent几乎不需要传参。**

**8段确认模式:流程分严格的8段执行，每段结束等用户确认后继续。用户始终知道流程在哪一步。**

**🔴🔴🔴 段落编号严格对应（绝对禁止合并段落）:**
- 段落1 = init+onboarding
- 段落2 = step0+图片理解
- 段落3 = P0+P1
- 段落4 = P2（测试点）
- 段落5 = P3+P4（风险+PCI）
- 段落6 = P5（代码自动合并）
- 段落7 = P6（用例生成，必须用分批流程，绝对禁止用step_run）
- 段落8 = P7+Excel

每段结束时必须输出“段落N完成”，不允许把多个段落合并成一个。

Agent在本技能中只做3类事情:
1. 调用orchestrator命令(exec)
2. 读取prompt文件并生成JSON结果,write到文件
3. 读取图片并描述内容(PX步骤)

**禁止Agent自行:**
- 决定下一步做什么(由orchestrator决定)
- 直接写入p*_output.json文件(由orchestrator通过truncation_guard写入)
- 绕过orchestrator(🔴 即使orchestrator报错,也不允许回退到"手动执行"模式,必须修复参数后重试)
- 输出JSON结构体到对话(只写文件)

**对话输出规则:每段只输出1行状态+确认提示。**

---

## 触发条件

「xy用例生成」「xy需求分析」「xy测试用例」「xy测试用例生成」「req2testcase」
「生成测试用例」「分析需求」「拆解功能点」「输出测试点」「需求评审」「帮我写用例」「这个需求怎么测」「PRD转测试用例」

---

## 🔴 8段确认模式

**需求载荷前置:** 触发后,如用户消息中不包含需求正文/需求附件/明确引用近期需求材料,仅输出:`请发送需求正文或需求文档,收到后立即开始分析。`

**收到需求后,按以下8段执行(每段结束等用户确认后继续):**

---

### 📋 段落1:初始化 + Onboarding

**首先定位orchestrator(只需执行一次,后续复用$ORCH变量):**
```
exec: ORCH=$(find ~/.openclaw ~/.local ~/skills /app/skills -name orchestrator.py -path "*/xy-req2testcase-generator/*" -print -quit 2>/dev/null) && echo "ORCH=$ORCH"
```
如果找到,后续所有命令使用 `python3 "$ORCH"` 调用。如果未找到,输出错误。

```
exec: python3 "$ORCH" --action init
→ 获得 task_id

exec: python3 "$ORCH" --action onboarding
→ 环境检查结果
```

然后执行Onboarding交互(🔴 必须分步确认,每项单独展示,等用户回复后再展示下一项):

**🔴 第1步:PRD审查(必须单独展示,等用户回复)**
```
📋 PRD审查可在生成用例前检查需求文档质量。
请选择:
• 回复「开启」→ 启动PRD审查(不到合格分会中断并输出问题清单)
• 回复「跳过」→ 直接生成用例
```
🔴 **必须等用户回复后,才能展示第2步。不允许和其他选项一起展示。**

**🔴 第2步:L5知识库(等第1步用户回复后才展示)**
```
📚 L5知识库可注入历史测试经验,提升用例质量。
请选择:
• 上传知识库文件 → 解析入库
• 回复「跳过」→ 不使用知识库
```
🔴 **必须等用户回复后,才能展示第3步。**

**🔴 第3步:图片理解API密码(等第2步用户回复后才展示)**
(见下方检查4B详细流程)

**检查4B:图片理解API密码**
```
i️ 图片理解API可自动解析需求文档中的原型图/流程图/截图,提升用例质量。
请选择:
• 回复图片API密码 → 启用图片理解(密码验证后启用,不会保存到任何文件)
• 回复「跳过」→ 纯文本模式,图片信息仅通过前后文推断
```

用户输入密码时:
1. Agent将密码传给orchestrator进行验证:exec: python3 "$ORCH" --action check_image_api --api-key "用户输入的密码"
2. orchestrator调用API的/api/auth-check接口验证密码
3. 密码正确→启用,Agent记住密码(仅在当前会话,不写文件),后续step0_8_prep时传入
4. 密码错误→提示用户"密码验证失败",允许重试(最多3次),3次失败后自动降级为纯文本模式
5. 服务不可用→提示"API服务暂不可用",自动降级为纯文本模式

密码验证失败时的处理流程:
- 第1次失败:提示"密码错误,请重新输入或回复「跳过」"
- 第2次失败:提示"密码再次错误,还有1次机会,或回复「跳过」"
- 第3次失败:自动切换为纯文本模式,告知用户

用户选择「跳过」→纯文本降级模式(caption_only)

⚠️ 密码安全:不写入任何文件,不保存到preferences/environment,仅在当前会话内存中持有

完成后输出:
```
✅ 段落1完成 | Onboarding通过 | task_id=xxx
📋 请回复「继续」开始需求分析
```

---

### 📋 段落2:需求接收 + 图片理解

用户回复"继续"/"好的"/"下一步"/"go"等确认意图后执行:

**🔴 段间验证(必须先执行):**
```
exec: python3 "$ORCH" --action status
```
确认onboarding gate pass存在。如不存在,必须重新执行段落1。

```
exec: python3 "$ORCH" --action step0 --requirement-file "{docx_path}"
→ 需求接收完成

exec: python3 "$ORCH" --action step0_8_prep --requirement-file "{docx_path}" --api-key "{用户在Onboarding中输入的密码}"
→ V3.2.4: orchestrator自动调用API理解图片(密码正确时),或降级为caption_only
→ 密码为空或未输入则自动降级
→ 结果写入px_api_results.json,无需Agent看图
→ 如返回skipped:非docx或无图片,跳过

exec: python3 "$ORCH" --action step0_8_save
→ 统一收口:读取结果→px_understand.json→image_enhance→mark_complete
```

完成后输出:
```
✅ 段落2完成 | 需求已解析 | 业务域:xxx | 图片N张
📋 请回复「继续」开始需求结构化
```

---

### 📋 段落3:需求结构化 + 模块拆解(P0 + P1)

用户确认后执行:

**🔴 段间验证(必须先执行):**
```
exec: python3 "$ORCH" --action status
```
确认P0的gate pass存在(说明段落2+段落3的前置已完成)。如不存在,必须重新执行段落2。

```
对 P0 和 P1 各执行:
  exec: python3 "$ORCH" --action prep_prompt --step P{N}
  → 获得 prompt_file 路径
  read {prompt_file} → 用推理能力生成JSON
  write {DATA_DIR}/p{n}_agent_output.json → JSON结果
  exec: python3 "$ORCH" --action step_run --step P{N}
  → orchestrator校验+truncation_guard+gate pass
```

完成后输出:
```
✅ 段落3完成 | P0评分:0.xx | P1模块:N个/功能点:M个
📋 请回复「继续」开始生成测试点
```

---

### 📋 段落4:测试点生成(P2)

用户确认后执行:

**🔴 段间验证(必须先执行):**
```
exec: python3 "$ORCH" --action status
```
确认P0和P1的gate pass存在。如不存在,必须重新执行段落3。

**执行P2(测试点草案):**
```
exec: python3 "$ORCH" --action prep_prompt --step P2
```
→ 读取P2 prompt文件 → 生成JSON → write到p2_agent_output.json
```
exec: python3 "$ORCH" --action step_run --step P2
```

完成后输出:
```
✅ 段落4完成 | 测试点:N条
📋 请回复「继续」进入风险识别
```

---

### 📋 段落5:风险识别 + PCI(P3 + P4)

用户确认后执行:

**🔴 段间验证:**
```
exec: python3 "$ORCH" --action status
```
确认P2的gate pass存在。

**执行P3(风险识别):**
```
exec: python3 "$ORCH" --action prep_prompt --step P3
```
→ 读取P3 prompt → 生成JSON → write到p3_agent_output.json
```
exec: python3 "$ORCH" --action step_run --step P3
```

**执行P4(PCI识别):**
```
exec: python3 "$ORCH" --action prep_prompt --step P4
```
→ 读取P4 prompt → 生成JSON → write到p4_agent_output.json
```
exec: python3 "$ORCH" --action step_run --step P4
```

完成后输出:
```
✅ 段落5完成 | 风险:N条 | PCI:M条
📋 请回复「继续」进入测试点合并
```

---

### 📋 段落6:测试点合并(P5,代码自动执行)

用户确认后执行:

**🔴 段间验证:**
```
exec: python3 "$ORCH" --action status
```
确认P2/P3/P4的gate pass存在。

**P5由代码自动合并(Agent不参与):**
```
exec: python3 "$ORCH" --action p5_code_merge
```
→ orchestrator自动读P2+P3+P4→代码合并→写入P5→gate pass

完成后输出:
```
✅ 段落6完成 | 合并测试点:N条(P2:X + P3:Y + P4:Z)
📋 请回复「继续」开始生成测试用例
```

---

### 📋 段落7:用例生成(P6)

用户确认后执行:

**🔴 段间验证:**
```
exec: python3 "$ORCH" --action status
```
确认P5的gate pass存在。

**🔴🔴🔴 重要：P6用例生成必须用分批流程，绝对禁止用step_run！**

P6不是用step_run执行的，而是用专用的分批流程：

**Step 1: 获取批次信息**
```
exec: python3 "$ORCH" --action p6_batch_info
```
→ 获得total_batches（如4批）

**Step 2: 对每个批次N=1,2,...执行以下循环:**
```
exec: python3 "$ORCH" --action prep_prompt --step P6 --batch-index {N}
```
→ 读取prompt文件 → Agent生成JSON → write到p6_batch_{N}_agent_output.json
```
exec: python3 "$ORCH" --action p6_save_batch --batch-index {N}
```
→ 校验并保存该批次结果

**🔴 循环完整性约束（必须遵守）:**
- 必须从批次1循环到total_batches，不得跳批、不得少批
- 任一批次p6_save_batch未成功，禁止执行p6_merge
- 仅当全部批次保存成功后，才允许执行p6_merge

**Step 3: 全部批次完成后合并:**
```
exec: python3 "$ORCH" --action p6_merge
```
→ 合并所有批次+质量校验+写入p6_output.json+gate pass

**❌ 错误示例（绝对禁止）:**
```
# 这是协议违规，禁止执行！
exec: python3 "$ORCH" --action step_run --step P6
```

完成后输出:
```
✅ 段落7完成 | 用例:N条 | 冒烟:M条
📋 请回复「继续」进入质检和导出
```

---

### 📋 段落8:质检 + 导出(P7 + Excel)

用户确认后执行:

**🔴 段间验证(必须先执行):**
```
exec: python3 "$ORCH" --action status
```
确认P6的gate pass存在。如不存在,必须重新执行段落7。

**Step 1: P7质量门禁**
```
exec: python3 "$ORCH" --action prep_prompt --step P7
```
→ 读取prompt → 生成JSON → write到p7_agent_output.json
```
exec: python3 "$ORCH" --action step_run --step P7
```

**Step 2: Excel导出**
```
exec: python3 "$ORCH" --action step7_export
```
→ 🔴 step7_export会自动校验P6质量(用例数≥15/冒烟8%-20%/P0≤40%)+ P7 gate_result=PASS
→ 不达标会被拒绝,需要重新执行段落7的P6

完成后:
1. 从step7_export返回的JSON中获取excel_path的实际值
2. 输出状态行:`✅ 全部完成 | 用例:N条 | 冒烟:M条 | Excel已生成`
3. **🔴 必须在下一行输出MEDIA指令发送文件(独占一行,全大写,路径用实际值):**
```
MEDIA:/root/.openclaw/workspace/xxx.xlsx
```
4. 输出:`💡 如需L6经验学习,可将评审结果发给我`

**⚠️ MEDIA指令是发送文件给用户的唯一方式。不输出MEDIA=用户收不到文件。**

---

## 用户交互指令

| 用户输入 | 含义 |
|---------|------|
| 继续/好的/下一步/go | 执行下一段 |
| 查看进度 | exec orchestrator.py --action status |
| 从P{N}重新开始 | exec: python3 "$ORCH" --action restart_from --step P{N} |
| 取消/停止 | 终止流程,保留已完成产物 |

## 断点续跑

用户发送"继续"时,如果当前任务有未完成步骤:
```
exec: python3 "$ORCH" --action resume
→ 获得 next_step,从对应段落继续
```

## 错误处理

| 错误 | 处理 |
|------|------|
| orchestrator返回error | 输出错误信息,🔴 不允许回退到手动模式,必须修复后重试 |
| orchestrator返回gate_blocked | 检查前置步骤是否完成 |
| orchestrator返回guard_failed | 重新生成JSON重试(最多1次) |
| orchestrator返回quality_failed | 按retry_hint重新执行对应步骤 |

## 引用文件

| 路径 | 说明 |
|------|------|
| tools/orchestrator.py | V3.0核心:流程控制器,15个action,参数自动化 |
| references/orchestrator_protocol.md | Agent↔orchestrator交互协议 |
| references/onboarding.md | Onboarding检查+交互流程 |
| references/step0-px.md | Step 0+PX详细指令(prompt参考源) |
| references/step1-4.md | P0-P5详细指令(prompt参考源) |
| references/step5-7.md | P6-P7+Excel详细指令(prompt参考源) |
| tools/truncation_guard.py | 四级截断检测+原子写入 |
| tools/export_excel.py | Excel导出(21列公司标准) |
| tools/image_extract.py | docx图片抽取 |
| tools/image_enhance.py | 图片理解增强聚合 |
| prompts/P0-P7_*.md | 各步骤Prompt模板 |

## 已知限制

1. Agent需配合orchestrator协议,不配合时orchestrator会重试但无法强制
2. 8段确认模式需要用户回复7次"继续"
3. Excel导出依赖openpyxl
4. 图片理解依赖Agent模型的视觉能力
