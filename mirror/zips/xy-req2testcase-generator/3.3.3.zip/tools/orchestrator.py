#!/usr/bin/env python3
"""
V3.3.1 Orchestrator — 测试用例生成流程控制器
代码控制流程，Agent只负责生成内容。

用法：
  由SKILL.md指导Agent调用：
  exec: python3 {SKILL_DIR}/tools/orchestrator.py --action <action> [--args ...]

支持的action：
  init          - 初始化任务（创建task_id, DATA_DIR）
  onboarding    - 执行Onboarding检查（环境/Python/路径）
  step0         - 接收需求，写入task_meta
  step0_8_prep  - PX图片抽取+选图（返回待Agent理解的图片列表）
  step0_8_save  - 保存Agent的图片理解结果+调用image_enhance
  step_run      - 执行P0-P7任一步骤（准备prompt输入，校验Agent输出，写文件+guard）
  step7_export  - 调用export_excel.py导出
  status        - 查看当前任务状态
  resume        - 断点续跑（检测已完成步骤，返回下一步）
"""

import argparse
import json
import hashlib
import os
import sys
import time
import subprocess
import glob
from pathlib import Path


# ============================================================
# 常量
# ============================================================

SKILL_VERSION = "3.3.3"
STEPS = ["onboarding", "step0", "step0_8", "P0", "P1", "P2", "P3", "P4", "P5", "P6", "P7", "step7"]
GATE_STEPS = ["onboarding", "P0", "P1", "P2", "P3", "P4", "P5", "P6", "P7"]

# P0必需顶层字段
# === 各步骤必需字段（以云端实际JSON为真源，2026-04-29统一） ===
P0_REQUIRED_FIELDS = ["quality_score", "blocks", "objective"]
P1_REQUIRED_FIELDS = ["feature_tree"]  # 云端实际输出用feature_tree
P3_REQUIRED_FIELDS = ["risk_points"]  # 云端实际输出用risk_points
P4_REQUIRED_FIELDS = ["pci_list"]  # 云端实际输出用pci_list
P5_REQUIRED_FIELDS = ["test_points", "merge_log"]
P6_REQUIRED_FIELDS = ["testcases"]
P7_REQUIRED_FIELDS = ["gate_result"]  # 云端实际输出gate_result，不是quality_check

# 域识别关键词
# ============================================================
# 自动发现 SKILL_DIR（V3.0.0-patch3）
# ============================================================

DEFAULT_SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def resolve_skill_dir(cli_value=""):
    """自动发现skill_dir，带目录完整性校验"""
    candidate = cli_value or DEFAULT_SKILL_DIR
    required_files = [
        os.path.join(candidate, "tools", "export_excel.py"),
        os.path.join(candidate, "tools", "truncation_guard.py"),
        os.path.join(candidate, "prompts", "P0_requirement_structuring.md"),
    ]
    missing = [p for p in required_files if not os.path.exists(p)]
    if missing:
        # 尝试DEFAULT_SKILL_DIR作为兜底
        if cli_value and cli_value != DEFAULT_SKILL_DIR:
            return resolve_skill_dir("")  # 递归用默认值重试
        raise ValueError(f"skill_dir无效({candidate})，缺失: {[os.path.basename(p) for p in missing[:3]]}")
    return candidate


# ============================================================
# 自动发现最近任务（V3.0.0-patch3）
# ============================================================

def find_latest_task():
    """查找最近的未完成任务，返回(task_id, data_dir)或(None, None)"""
    base = os.path.expanduser("~/.openclaw/workspace/data")
    if not os.path.exists(base):
        return None, None
    tasks = sorted(glob.glob(os.path.join(base, "task_*")), reverse=True)
    for task_dir in tasks[:3]:  # 只看最近3个，减少串task风险
        state_path = os.path.join(task_dir, "orchestrator_state.json")
        if os.path.exists(state_path):
            try:
                state = _read_json(state_path)
                tid = state.get("task_id", "")
                # 未完成的任务（没有step7）
                if "step7" not in state.get("completed_steps", []):
                    return tid, task_dir
            except Exception:
                pass
    return None, None


DOMAIN_KEYWORDS = {
    "trade": ["交易", "委托", "撤单", "成交", "清算", "结算", "资金冻结", "T+1"],
    "asset_mgmt": ["资管", "净值", "申赎", "申购", "赎回", "衍生品", "期货", "期权", "保证金"],
    "risk_ctrl": ["风控", "预警", "限额", "合规检查", "风险控制"],
    "crm": ["客户", "跟进", "开户", "KYC", "客户经理", "客户关系"],
    "etrading": ["网上营业厅", "APP", "适当性", "产品推荐", "在线交易", "移动端", "H5"],
    "ops_mgmt": ["运营", "活动", "营销", "后台管理", "数据报表", "统计", "导出"],
    "compliance": ["合规", "证书", "从业", "监管", "报送", "资质", "执照"],
    "it_infra": ["部署", "监控", "服务器", "权限配置", "变更", "IT", "基础设施", "投行", "承销", "IPO"],
}


# ============================================================
# 工具函数
# ============================================================

def _ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def _write_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def _read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _file_exists(path):
    return os.path.exists(path) and os.path.getsize(path) > 10

def _sha256(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]

def _detect_domain(text, default="trade"):
    text_lower = text.lower()
    for domain, keywords in DOMAIN_KEYWORDS.items():
        for kw in keywords:
            if kw in text_lower:
                return domain
    return default


    return default


def _check_api_features(data_dir):
    """V3.3.2: 判断是否需要接口测试规则（检查P0 operations和P1 feature names）"""
    API_KEYWORDS = {"接口", "API", "api", "推送", "webhook", "回调", "对接", "同步", "通知", "HTTP", "http"}
    # 检查P0 operations
    p0_path = os.path.join(data_dir, "p0_output.json")
    if os.path.exists(p0_path):
        try:
            p0_data = _read_json(p0_path)
            ops = p0_data.get("blocks", {}).get("operations", [])
            for op in ops:
                name = op.get("name", "") + op.get("trigger", "")
                if any(kw in name for kw in API_KEYWORDS):
                    return True
        except Exception:
            pass
    # 检查P1 feature names
    p1_path = os.path.join(data_dir, "p1_output.json")
    if os.path.exists(p1_path):
        try:
            p1_data = _read_json(p1_path)
            ft = p1_data.get("feature_tree", {})
            ft_modules = ft.get("modules", []) if isinstance(ft, dict) else []
            if not ft_modules:
                ft_modules = p1_data.get("modules", [])
            for mod in ft_modules:
                for feat in mod.get("children", []):
                    if any(kw in feat.get("name", "") for kw in API_KEYWORDS):
                        return True
        except Exception:
            pass
    return False


def _get_case_field(case, field, default=""):
    """从P6用例中读取字段值，兼容两种结构：
    1. 扁平结构：case.get(field)
    2. 嵌套结构：case.get("fields", {}).get(field)
    
    V3.2.4新增：修复P6数据结构为嵌套fields时，
    quality_check/p6_merge/step7_export/export_excel全部读不到字段的致命Bug。
    """
    val = case.get(field)
    if val is not None and val != "":
        return val
    fields = case.get("fields")
    if isinstance(fields, dict):
        val = fields.get(field)
        if val is not None:
            return val
    return default


def _is_smoke(value):
    """V3.2.8: 统一is_smoke判断逻辑，兼容所有格式。
    返回True/False，消除多处重复的判断代码。
    支持: True, "true", "是", "Y", "yes", 1
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value == 1
    if isinstance(value, str):
        return value.lower() in ("true", "是", "y", "yes", "1")
    return False


# ============================================================
# HMAC签名机制 (V3.2.6: 防止Agent伪造gate pass)
# ============================================================

import hmac as _hmac_mod

# 内嵌密钥：基于orchestrator文件自身的哈希派生，Agent无法获取
def _get_hmac_key():
    """V3.2.6: 从 orchestrator.py 自身文件哈希派生 HMAC 密钥。
    Agent无法获取此密钥，因为它依赖于文件内容的SHA256。
    """
    orch_path = os.path.abspath(__file__)
    with open(orch_path, "rb") as f:
        file_hash = hashlib.sha256(f.read()).hexdigest()
    return f"orch-gate-{file_hash[:32]}".encode("utf-8")


def _sign_gate(gate_data, task_id):
    """V3.2.6: 对gate pass数据生成HMAC签名。
    签名覆盖gate_data的所有字段（排除hmac字段本身）+ task_id。
    """
    # 拷贝并移除hmac字段，避免循环依赖
    data_copy = {k: v for k, v in gate_data.items() if k != "hmac"}
    data_copy["_task_id"] = task_id  # 确保task_id参与签名
    payload = json.dumps(data_copy, sort_keys=True, ensure_ascii=False)
    key = _get_hmac_key()
    sig = _hmac_mod.new(key, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return sig


def _write_signed_gate(gate_path, gate_data, task_id):
    """V3.2.6: 写入带HMAC签名的gate pass文件。"""
    gate_data["hmac"] = _sign_gate(gate_data, task_id)
    _write_json(gate_path, gate_data)


def _verify_gate_hmac(gate_data, task_id):
    """V3.2.6: 验证gate pass的HMAC签名。
    返回 (True, "OK") 或 (False, "原因")
    """
    stored_hmac = gate_data.get("hmac")
    if not stored_hmac:
        return False, "gate pass缺少HMAC签名（可能Agent伪造）"
    # 重新计算签名
    expected = _sign_gate(gate_data, task_id)
    if not _hmac_mod.compare_digest(stored_hmac, expected):
        return False, "HMAC签名不匹配（gate pass被篡改或Agent伪造）"
    return True, "OK"


# ============================================================
# 状态管理
# ============================================================

class TaskState:
    """任务状态管理器"""

    def __init__(self, data_dir=None, task_id=None):
        self.task_id = task_id
        self.data_dir = data_dir
        self.state_path = os.path.join(data_dir, "orchestrator_state.json") if data_dir else None
        self.state = self._load()

    def _load(self):
        if self.state_path and os.path.exists(self.state_path):
            try:
                return _read_json(self.state_path)
            except Exception:
                pass
        return {
            "task_id": self.task_id,
            "data_dir": self.data_dir,
            "skill_dir": "",
            "current_step": None,
            "completed_steps": [],
            "current_phase": 1,
            "requirement_file": "",
            "skill_version": SKILL_VERSION,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
            "updated_at": None,
        }

    def save(self):
        if self.state_path:
            self.state["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%S+08:00")
            _write_json(self.state_path, self.state)

    def mark_complete(self, step):
        if step not in self.state["completed_steps"]:
            self.state["completed_steps"].append(step)
        self.state["current_step"] = step
        self.save()

    def is_complete(self, step):
        return step in self.state["completed_steps"]

    def get_next_step(self):
        for step in STEPS:
            if step not in self.state["completed_steps"]:
                return step
        return None


# ============================================================
# Gate Pass 管理
# ============================================================

def check_gate(data_dir, step, task_id):
    """V3.2.6: 检查指定步骤的gate pass是否存在、task_id一致、且HMAC签名有效"""
    gp_path = os.path.join(data_dir, "gates", f"{step}.pass.json")
    if not os.path.exists(gp_path):
        return False, f"{step}.pass.json不存在"
    try:
        gp = _read_json(gp_path)
        if gp.get("task_id") != task_id:
            return False, f"task_id不匹配: {gp.get('task_id')} != {task_id}"
        # V3.2.6: HMAC验签
        hmac_ok, hmac_msg = _verify_gate_hmac(gp, task_id)
        if not hmac_ok:
            return False, f"{step}: {hmac_msg}"
        return True, "OK"
    except Exception:
        return False, f"{step}.pass.json读取失败"

def run_truncation_guard(skill_dir, data_dir, task_id, step, revision=1):
    """调用truncation_guard.py进行四级校验+auto-mv"""
    tmp_path = os.path.join(data_dir, f"{step.lower()}_output.tmp.json")
    guard_script = os.path.join(skill_dir, "tools", "truncation_guard.py")

    if not os.path.exists(guard_script):
        return False, "truncation_guard.py不存在"
    if not os.path.exists(tmp_path):
        return False, f"{tmp_path}不存在"

    cmd = [
        "python3", guard_script,
        "--file", tmp_path,
        "--step", step,
        "--data-dir", data_dir,
        "--task-id", task_id,
        "--revision", str(revision),
        "--auto-mv"
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

    if result.returncode == 0:
        return True, result.stdout.strip()
    else:
        return False, f"exit={result.returncode}: {result.stderr.strip() or result.stdout.strip()}"


# ============================================================
# Action: init
# ============================================================

def action_init(args):
    """初始化任务：创建task_id和DATA_DIR"""
    task_id = f"task_{time.strftime('%Y%m%d_%H%M%S')}"
    base_dir = os.path.expanduser("~/.openclaw/workspace/data")
    data_dir = os.path.join(base_dir, task_id)

    _ensure_dir(data_dir)
    _ensure_dir(os.path.join(data_dir, "gates"))

    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.state["skill_dir"] = resolve_skill_dir("")
    state.state["data_dir"] = data_dir
    state.save()

    print(json.dumps({
        "status": "ok",
        "task_id": task_id,
        "data_dir": data_dir,
    }))


# ============================================================
# Action: onboarding
# ============================================================

def action_onboarding(args):
    """执行Onboarding环境检查（非交互部分）"""
    skill_dir = args.skill_dir
    data_dir = args.data_dir
    task_id = args.task_id

    checks = []

    # 检查1: 文件完整性
    required_files = [
        "prompts/P0_requirement_structuring.md",
        "prompts/P1_feature_tree_generation.md",
        "prompts/P2_test_point_draft.md",
        "prompts/P6_testcase_generation.md",
        "prompts/archive/P7_quality_gate.md",  # V3.3.1: P7已改为代码校验，prompt归档
        "tools/export_excel.py",
        "tools/truncation_guard.py",
        "tools/image_extract.py",
    ]
    missing = [f for f in required_files if not os.path.exists(os.path.join(skill_dir, f))]
    checks.append({
        "name": "file_integrity",
        "passed": len(missing) == 0,
        "missing": missing,
    })

    # 检查1.5: SKILL_DIR确认
    checks.append({
        "name": "skill_dir",
        "passed": os.path.exists(os.path.join(skill_dir, "tools", "export_excel.py")),
        "skill_dir": skill_dir,
    })

    # 检查2: Python + openpyxl
    try:
        result = subprocess.run(
            ["python3", "-c", "import openpyxl; print('ok')"],
            capture_output=True, text=True, timeout=10
        )
        openpyxl_ok = result.returncode == 0
    except Exception:
        openpyxl_ok = False
    checks.append({"name": "python_openpyxl", "passed": openpyxl_ok})

    # 检查0.5: 缓存检测
    cache_dir = os.path.expanduser("~/.openclaw/workspace/data")
    existing = sorted(glob.glob(os.path.join(cache_dir, "task_*")), reverse=True)[:3]
    checks.append({
        "name": "cache_detection",
        "existing_tasks": [os.path.basename(p) for p in existing],
    })

    all_passed = all(c.get("passed", True) for c in checks)

    # 写入onboarding.pass.json (V3.2.6: HMAC签名)
    if all_passed:
        gate_path = os.path.join(data_dir, "gates", "onboarding.pass.json")
        gate_data = {
            "step": "onboarding",
            "task_id": task_id,
            "status": "PASS",
            "source": "onboarding",
            "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
            "checks": checks,
        }
        _write_signed_gate(gate_path, gate_data, task_id)

        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.state["skill_dir"] = args.skill_dir
        state.state["data_dir"] = data_dir
        state.mark_complete("onboarding")

    print(json.dumps({
        "status": "ok" if all_passed else "blocked",
        "checks": checks,
        "onboarding_pass": all_passed,
    }))


# ============================================================
# Action: step0
# ============================================================

def action_step0(args):
    """Step 0: 接收需求，写入task_meta"""
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir
    requirement_text = args.requirement_text or ""
    requirement_file = args.requirement_file or ""

    # 门禁检查
    ok, msg = check_gate(data_dir, "onboarding", task_id)
    if not ok:
        print(json.dumps({"status": "gate_blocked", "step": "onboarding", "reason": msg}))
        sys.exit(1)

    # 如果是文件，提取文本
    if requirement_file and not requirement_text:
        if requirement_file.endswith(".docx"):
            try:
                result = subprocess.run(
                    ["python3", "-c", f"""
import zipfile, re
with zipfile.ZipFile("{requirement_file}") as z:
    xml = z.read("word/document.xml").decode("utf-8")
    text = re.sub(r"<[^>]+>", " ", xml)
    text = re.sub(r"\\s+", " ", text).strip()
    print(text[:50000])
"""],
                    capture_output=True, text=True, timeout=30
                )
                requirement_text = result.stdout.strip()
            except Exception as e:
                requirement_text = f"[docx解析失败: {e}]"
        else:
            try:
                with open(requirement_file, "r", encoding="utf-8") as f:
                    requirement_text = f.read()[:50000]
            except Exception:
                requirement_text = "[文件读取失败]"

    domain = _detect_domain(requirement_text)

    # 读取preferences（脱敏：不写入api_key等敏感字段到task_meta）
    prefs_path = os.path.join(skill_dir, "user_knowledge", "preferences.json")
    prefs = {}
    prefs_safe = {}  # 脱敏版本，只保留非敏感字段
    if os.path.exists(prefs_path):
        try:
            prefs = _read_json(prefs_path)
            # 脱敏：image_api只保留url/model/timeout（api_key运行时输入，不存此处）
            if "image_api" in prefs:
                ia = prefs["image_api"]
                prefs_safe["image_api"] = {
                    "url": ia.get("url", ""),
                    "model": ia.get("model", "ci"),
                    "timeout": ia.get("timeout", 120),
                }
        except Exception:
            pass

    # 写入task_meta
    meta = {
        "task_id": task_id,
        "domain": domain,
        "requirement_text": requirement_text,
        "requirement_file": requirement_file,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "preferences": prefs_safe,  # 脱敏版本
        "skill_version": SKILL_VERSION,
        "requirement_hash": _sha256(requirement_text),
    }
    _write_json(os.path.join(data_dir, "task_meta.json"), meta)

    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.state["requirement_file"] = requirement_file
    state.state["current_phase"] = 2
    state.mark_complete("step0")

    print(json.dumps({
        "status": "ok",
        "task_id": task_id,
        "domain": domain,
        "requirement_length": len(requirement_text),
    }))


# ============================================================
# ============================================================
# 图片理解API配置读取
# ============================================================

def _load_image_api_config(skill_dir, api_key=None):
    """读取图片理解API配置
    
    - url/model/timeout从preferences.json读取（写死，用户无需输入）
    - api_key从运行时参数传入（Onboarding交互时用户输入，不落盘）
    - enabled由api_key是否非空决定（有密码=启用，无密码=降级）
    """
    prefs_path = os.path.join(skill_dir, "user_knowledge", "preferences.json")
    prefs = {}
    if os.path.exists(prefs_path):
        try:
            prefs = _read_json(prefs_path)
        except Exception:
            pass

    ia = prefs.get("image_api", {})

    config = {
        "enabled": bool(api_key and api_key.strip()),  # 有密码才启用
        "url": ia.get("url", ""),
        "model": ia.get("model", "ci"),  # ci=数据万象, qwen=通义千问VL
        "timeout": ia.get("timeout", 120),
        "api_key": (api_key or "").strip(),
    }

    # 配置完整性校验
    if config["enabled"]:
        if not config["url"].startswith("https://") and not config["url"].startswith("http://"):
            config["enabled"] = False
            config["_invalid_reason"] = "API地址未配置或格式不正确（检查preferences.json中image_api.url）"

    return config


def _check_image_api_health(config):
    """预检：调用API的auth-check接口验证密码+服务可用性
    
    V3.0.3-patch1: 改用/api/auth-check替代/api/health
    原因: /api/health不鉴权，无法验证密码正确性（F2/F17修复）
    """
    try:
        import requests
        # 从analyze URL推导auth-check URL
        if "/api/" in config["url"]:
            base_url = config["url"].rsplit("/api/", 1)[0]
        else:
            base_url = config["url"].rsplit("/", 1)[0]
        auth_check_url = base_url + "/api/auth-check"

        resp = requests.get(
            auth_check_url,
            headers={"X-API-Key": config["api_key"]},
            timeout=5,
        )
        if resp.status_code == 200:
            data = resp.json()
            return data.get("status") == "ok", data
        elif resp.status_code in (401, 403):
            return False, {"error": "auth_failed", "message": "密码错误"}
        elif resp.status_code == 503:
            data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
            return False, {"error": "service_not_configured", "message": data.get("reason", data.get("message", "服务未配置密码验证"))}
        return False, {"error": f"HTTP {resp.status_code}"}
    except requests.exceptions.ConnectionError:
        return False, {"error": "connection_failed", "message": "无法连接到API服务"}
    except requests.exceptions.Timeout:
        return False, {"error": "timeout", "message": "API服务响应超时"}
    except Exception as e:
        return False, {"error": str(e)[:100]}


def _call_image_api(image_path, config):
    """调用图片理解API分析单张图片"""
    try:
        import requests
        with open(image_path, "rb") as f:
            resp = requests.post(
                config["url"],
                headers={"X-API-Key": config["api_key"]},
                files={"file": f},
                data={"model": config["model"]},
                timeout=config["timeout"],
            )
        if resp.status_code == 200:
            return resp.json()
        elif resp.status_code in (401, 403):
            return {"status": "auth_failed", "error": f"鉴权失败: HTTP {resp.status_code}"}
        elif resp.status_code == 429:
            return {"status": "rate_limited", "error": "请求频率超限"}
        else:
            return {"status": "error", "error": f"HTTP {resp.status_code}"}
    except requests.exceptions.Timeout:
        return {"status": "timeout", "error": "请求超时"}
    except Exception as e:
        return {"status": "error", "error": str(e)[:100]}


# ============================================================
# Action: step0_8_prep (PX图片抽取+选图+API理解/caption_only降级)
# ============================================================

def action_step0_8_prep(args):
    """PX图片抽取+价值优先选图+自动调用API理解（或降级为caption_only）
    
    V3.0.3改动：
    - API模式：orchestrator直接调用图片理解API，不依赖Agent
    - 降级模式：caption_only（用前后文生成描述），不回退Agent看图
    - 结果写入px_api_results.json，由step0_8_save统一收口
    """
    data_dir = args.data_dir
    skill_dir = args.skill_dir
    requirement_file = args.requirement_file or ""

    if not requirement_file or not requirement_file.endswith(".docx"):
        print(json.dumps({"status": "skipped", "reason": "非docx格式，跳过PX"}))
        return

    # 调用image_extract.py
    extract_script = os.path.join(skill_dir, "tools", "image_extract.py")
    px_images_dir = os.path.join(data_dir, "px_images")
    px_extract_path = os.path.join(data_dir, "px_extract.json")

    _ensure_dir(px_images_dir)

    result = subprocess.run(
        ["python3", extract_script, requirement_file,
         "--output-dir", px_images_dir,
         "--json-output", px_extract_path],
        capture_output=True, text=True, timeout=60
    )

    if result.returncode != 0 or not os.path.exists(px_extract_path):
        print(json.dumps({"status": "skipped", "reason": f"图片抽取失败: {result.stderr[:200]}"}))
        return

    extract_data = _read_json(px_extract_path)
    images = extract_data.get("images", [])

    if not images:
        print(json.dumps({"status": "skipped", "reason": "docx中无图片"}))
        return

    # 价值优先选图
    value_keywords = ["流程", "状态", "原型", "页面", "规则", "接口", "表格", "如下图", "见图"]
    scored = []
    for img in images:
        caption = (img.get("caption", "") or "").lower()
        before = (img.get("before_text", "") or "").lower()
        after = (img.get("after_text", "") or "").lower()
        context = caption + " " + before + " " + after

        score = 0
        for kw in value_keywords:
            if kw in context:
                score += 1

        # 跳过装饰性图片
        w = img.get("width", 100)
        h = img.get("height", 100)
        if (w < 50 and h < 50) or "logo" in context or "icon" in context:
            score = -1

        scored.append((score, img))

    scored.sort(key=lambda x: x[0], reverse=True)
    selected = [img for score, img in scored if score >= 0][:50]

    # ============================================================
    # V3.0.3: 图片理解（API模式 or caption_only降级）
    # ============================================================
    # V3.2.0: api_key优先从命令行参数读取，其次从task目录缓存读取（解决Agent跨段落丢密码问题）
    api_key = getattr(args, 'api_key', None) or ''
    if not api_key.strip():
        cache_path = os.path.join(data_dir, ".image_api_key")
        if os.path.exists(cache_path):
            try:
                with open(cache_path, "r") as f:
                    api_key = f.read().strip()
            except Exception:
                pass
    api_config = _load_image_api_config(skill_dir, api_key=api_key or None)
    use_api = api_config["enabled"]

    # 预检：API health check
    service_ok = False
    if use_api:
        service_ok, health_data = _check_image_api_health(api_config)
        if not service_ok:
            use_api = False  # 降级

    results = []
    api_success = 0
    api_fallback = 0

    # V3.2.0: 并行调用API（解决19张图串行~570s的问题）
    # 策略：线程池并发=3，主线程汇总结果，401/403立即标记
    def _process_single_image(img):
        """处理单张图片（线程安全：只读输入，返回结果，不修改共享状态）"""
        image_id = img.get("image_id", "")
        file_path = img.get("file_path", "")
        caption = img.get("caption", "") or ""
        before_text = (img.get("before_text", "") or "")[:200]
        after_text = (img.get("after_text", "") or "")[:200]

        caption_desc = caption
        if before_text or after_text:
            context_parts = []
            if before_text:
                context_parts.append(f"图片前文: {before_text}")
            if caption:
                context_parts.append(f"图片标题: {caption}")
            if after_text:
                context_parts.append(f"图片后文: {after_text}")
            caption_desc = " | ".join(context_parts)

        if not file_path or not os.path.exists(file_path):
            return {"image_id": image_id, "understanding_mode": "caption_only",
                    "failure_type": "file_not_found", "description": caption_desc,
                    "ocr_text": "", "labels": [],
                    "before_text": before_text, "after_text": after_text, "_ok": False}

        api_result = _call_image_api(file_path, api_config)

        if api_result.get("status") in ("ok", "partial"):
            mode = "api" if api_result.get("status") == "ok" else "api_partial"
            return {"image_id": image_id, "understanding_mode": mode,
                    "api_provider": api_result.get("model", api_config["model"]),
                    "description": api_result.get("description", caption_desc),
                    "ocr_text": api_result.get("ocr_text", ""),
                    "labels": api_result.get("labels", []),
                    "confidence": api_result.get("confidence", 0),
                    "before_text": before_text, "after_text": after_text, "_ok": True}
        elif api_result.get("status") in ("auth_failed", "rate_limited"):
            return {"image_id": image_id, "understanding_mode": "api_fallback_caption",
                    "failure_type": api_result.get("status"), "description": caption_desc,
                    "ocr_text": "", "labels": [],
                    "before_text": before_text, "after_text": after_text, "_ok": False, "_fatal": True}
        else:
            return {"image_id": image_id, "understanding_mode": "api_fallback_caption",
                    "failure_type": api_result.get("status", "unknown"), "description": caption_desc,
                    "ocr_text": "", "labels": [],
                    "before_text": before_text, "after_text": after_text, "_ok": False}

    if use_api:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        fatal_detected = False
        with ThreadPoolExecutor(max_workers=3) as executor:
            future_map = {executor.submit(_process_single_image, img): img.get("image_id", "") for img in selected}
            try:
                for future in as_completed(future_map, timeout=600):
                    try:
                        r = future.result(timeout=120)
                        ok = r.pop("_ok", False)
                        is_fatal = r.pop("_fatal", False)
                        results.append(r)
                        if ok:
                            api_success += 1
                        else:
                            api_fallback += 1
                        # 401/403立即取消剩余任务
                        if is_fatal:
                            fatal_detected = True
                            for f in future_map:
                                f.cancel()
                            break
                    except Exception as e:
                        results.append({"image_id": future_map.get(future, "?"),
                                        "understanding_mode": "api_fallback_caption",
                                        "failure_type": "exception", "description": str(e)[:200],
                                        "ocr_text": "", "labels": [],
                                        "before_text": "", "after_text": ""})
                        api_fallback += 1
            except TimeoutError:
                # 总超时600s，未完成的图片降级为caption_only
                for f, img_id in future_map.items():
                    if not f.done():
                        results.append({"image_id": img_id,
                                        "understanding_mode": "api_fallback_caption",
                                        "failure_type": "total_timeout",
                                        "description": "总超时600s未完成",
                                        "ocr_text": "", "labels": [],
                                        "before_text": "", "after_text": ""})
                        api_fallback += 1
    else:
        for img in selected:
            image_id = img.get("image_id", "")
            caption = img.get("caption", "") or ""
            before_text = (img.get("before_text", "") or "")[:200]
            after_text = (img.get("after_text", "") or "")[:200]
            caption_desc = caption
            if before_text or after_text:
                parts = []
                if before_text: parts.append(f"图片前文: {before_text}")
                if caption: parts.append(f"图片标题: {caption}")
                if after_text: parts.append(f"图片后文: {after_text}")
                caption_desc = " | ".join(parts)
            results.append({"image_id": image_id, "understanding_mode": "caption_only",
                            "description": caption_desc, "ocr_text": "", "labels": [],
                            "before_text": before_text, "after_text": after_text})

    # 将结果写入临时文件，由step0_8_save统一收口
    _write_json(os.path.join(data_dir, "px_api_results.json"), {
        "results": results,
        "summary": {
            "mode": "api" if api_config["enabled"] and service_ok else "caption_only",
            "service_status": "ok" if api_success > 0 and api_fallback == 0 else
                              ("partial_success" if api_success > 0 else "degraded"),
            "api_success_count": api_success,
            "api_fallback_count": api_fallback,
            "total_selected": len(selected),
            "total_images": len(images),
            "api_provider": api_config["model"] if api_config["enabled"] else "none",
        }
    })

    # 输出状态
    mode = "api" if api_config["enabled"] and service_ok else "caption_only"
    if not api_config["enabled"]:
        mode_msg = "caption_only（未输入图片API密码，如需启用请在Onboarding时输入密码）"
    elif not service_ok:
        mode_msg = f"caption_only（API健康检查失败: {health_data.get('error', 'unknown')}）"
    elif api_fallback > 0:
        mode_msg = f"api_with_fallback（成功{api_success}张，降级{api_fallback}张）"
    else:
        mode_msg = f"api（全部{api_success}张通过{api_config['model']}理解）"

    print(json.dumps({
        "status": "ok",
        "mode": mode,
        "mode_message": mode_msg,
        "total_images": len(images),
        "selected_count": len(selected),
        "api_success_count": api_success,
        "api_fallback_count": api_fallback,
    }))


# ============================================================
# Action: step0_8_save (保存图片理解结果)
# ============================================================

def action_step0_8_save(args):
    """保存图片理解结果，调用image_enhance（统一收口）
    
    V3.0.3改动：
    - 优先读取px_api_results.json（API/caption_only模式产出）
    - 如无API结果文件，回退读取args.results_json（兼容旧模式）
    - 统一生成px_understand.json + 调用image_enhance + mark_complete
    """
    data_dir = args.data_dir
    skill_dir = args.skill_dir
    task_id = args.task_id

    # 优先读取API结果文件
    api_results_path = os.path.join(data_dir, "px_api_results.json")
    if os.path.exists(api_results_path):
        api_data = _read_json(api_results_path)
        results = api_data.get("results", [])
        api_summary = api_data.get("summary", {})
    elif args.results_json:
        # 兼容旧模式：从命令行参数读取
        try:
            results = json.loads(args.results_json)
            api_summary = {}
        except Exception:
            print(json.dumps({"status": "error", "reason": "图片理解结果JSON解析失败"}))
            return
    else:
        print(json.dumps({"status": "error", "reason": "无图片理解结果（px_api_results.json不存在且未传入results_json）"}))
        return

    # 读取抽取数据获取总数
    px_extract_path = os.path.join(data_dir, "px_extract.json")
    total = 0
    if os.path.exists(px_extract_path):
        total = len(_read_json(px_extract_path).get("images", []))

    # 构造px_understand.json
    api_count = sum(1 for r in results if r.get("understanding_mode") == "api")
    caption_count = sum(1 for r in results if r.get("understanding_mode") in ("caption_only", "api_fallback_caption"))
    vision_count = sum(1 for r in results if r.get("understanding_mode") == "vision")  # 兼容旧模式

    # 构造skipped_images列表（未被选中的图片）
    skipped_images = []
    if os.path.exists(px_extract_path):
        all_images = _read_json(px_extract_path).get("images", [])
        selected_ids = set(r.get("image_id", "") for r in results)
        for img in all_images:
            if img.get("image_id", "") not in selected_ids:
                skipped_images.append({
                    "image_id": img.get("image_id", ""),
                    "file_path": img.get("file_path", ""),
                    "selected": False,
                    "selection_reason": "超出50张上限或未命中高价值关键词",
                    "understanding_mode": "skipped"
                })

    understand = {
        "task_id": task_id,
        "total_images": total,
        "selected_images": len(results),
        "results": results,
        "skipped_images": skipped_images,
        "summary": {
            "api_count": api_count,
            "caption_count": caption_count,
            "vision_count": vision_count,
            "skipped_count": total - len(results),
            "mode": api_summary.get("mode", "unknown"),
            "service_status": api_summary.get("service_status", "unknown"),
            "api_provider": api_summary.get("api_provider", "none"),
        }
    }
    _write_json(os.path.join(data_dir, "px_understand.json"), understand)

    # 调用image_enhance
    enhance_script = os.path.join(skill_dir, "tools", "image_enhance.py")
    enhance_output = os.path.join(data_dir, "px_enhance.json")

    result = subprocess.run(
        ["python3", enhance_script,
         os.path.join(data_dir, "px_understand.json"),
         "--output", enhance_output],
        capture_output=True, text=True, timeout=30
    )

    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.mark_complete("step0_8")

    print(json.dumps({
        "status": "ok",
        "mode": api_summary.get("mode", "unknown"),
        "api_count": api_count,
        "caption_count": caption_count,
        "vision_count": vision_count,
        "total": total,
        "enhance_ok": result.returncode == 0,
    }))


# ============================================================
# Action: step_run (执行P0-P7任一步骤)
# ============================================================

def action_step_run(args):
    """
    执行P0-P4/P7步骤：
    1. 检查前置gate pass
    2. 准备prompt输入（读取上游产物+知识注入）
    3. 接收Agent的JSON输出
    4. 写入tmp → truncation_guard → gate pass
    
    V3.2.5: P5和P6禁止通过step_run执行，必须走专用流程
    """
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir
    step = args.step  # P0/P1/P2/P3/P4/P7
    agent_output = args.agent_output  # Agent返回的JSON字符串

    # V3.3.3: P2/P5/P6/P7禁止通过step_run执行，必须走代码路径
    if step == "P2":
        print(json.dumps({
            "status": "rejected",
            "reason": "❌ P2禁止用step_run执行！P2是代码自动生成，必须用: python3 orchestrator.py --action p2_code_generate",
            "correct_action": "p2_code_generate",
        }))
        sys.exit(1)
    if step == "P5":
        print(json.dumps({
            "status": "rejected",
            "reason": "❌ P5禁止用step_run执行！P5是代码自动合并，必须用: python3 orchestrator.py --action p5_code_merge",
            "correct_action": "p5_code_merge",
        }))
        sys.exit(1)
    if step == "P6":
        print(json.dumps({
            "status": "rejected",
            "reason": "❌ P6禁止用step_run执行！P6必须用分批流程: p6_batch_info → 循环prep_prompt+p6_save_batch → p6_merge",
            "correct_flow": "p6_batch_info -> prep_prompt --step P6 --batch-index N -> p6_save_batch --batch-index N -> p6_merge",
        }))
        sys.exit(1)
    # V3.3.1: P7禁止通过step_run执行，必须走代码校验
    if step == "P7":
        print(json.dumps({
            "status": "rejected",
            "reason": "❌ P7禁止用step_run执行！P7是代码自动校验，必须用: python3 orchestrator.py --action p7_code_check",
            "correct_action": "p7_code_check",
        }))
        sys.exit(1)

    # 前置gate pass检查
    prerequisites = {
        "P0": ["onboarding"],
        "P1": ["P0"],
        "P2": ["P1"],
        "P3": ["P1"],
        "P4": ["P1"],
        "P5": ["P2", "P3", "P4"],
        "P6": ["P5"],
        "P7": ["P6"],
    }

    for prereq in prerequisites.get(step, []):
        ok, msg = check_gate(data_dir, prereq, task_id)
        if not ok:
            print(json.dumps({"status": "gate_blocked", "step": prereq, "reason": msg}))
            sys.exit(1)

    # 解析Agent输出
    try:
        output_data = json.loads(agent_output)
    except json.JSONDecodeError:
        # JSON解析兜底：尝试正则提取
        import re
        match = re.search(r'\{[\s\S]*\}', agent_output)
        if match:
            try:
                output_data = json.loads(match.group())
            except Exception:
                print(json.dumps({"status": "error", "reason": "Agent输出JSON解析失败（含正则兜底）"}))
                sys.exit(1)
        else:
            print(json.dumps({"status": "error", "reason": "Agent输出不含有效JSON"}))
            sys.exit(1)

    # 写入tmp文件
    tmp_path = os.path.join(data_dir, f"{step.lower()}_output.tmp.json")
    _write_json(tmp_path, output_data)

    # === V3.0.3新增：写入tmp后、guard前，先做必需字段校验（代码硬控） ===
    required_fields_map = {
        "P0": P0_REQUIRED_FIELDS,
        "P1": P1_REQUIRED_FIELDS,
        "P3": P3_REQUIRED_FIELDS,
        "P4": P4_REQUIRED_FIELDS,
        "P5": P5_REQUIRED_FIELDS,
        "P6": P6_REQUIRED_FIELDS,
        "P7": P7_REQUIRED_FIELDS,
    }
    if step in required_fields_map:
        missing_fields = []
        for field in required_fields_map[step]:
            # 支持嵌套路径和多候选
            val = _get_nested(output_data, field)
            if val is None:
                missing_fields.append(field)
        if missing_fields:
            # 删除tmp文件，拒绝写入
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
            print(json.dumps({
                "status": "validation_failed",
                "step": step,
                "reason": f"必需字段缺失: {missing_fields}。请确保输出JSON包含这些顶层字段。",
                "missing_fields": missing_fields,
                "hint": f"{step}输出必须包含: {required_fields_map[step]}",
            }))
            sys.exit(1)

    # 调用truncation_guard
    ok, msg = run_truncation_guard(skill_dir, data_dir, task_id, step)

    if ok:
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete(step)
        print(json.dumps({"status": "ok", "step": step, "guard_result": msg}))
    else:
        print(json.dumps({"status": "guard_failed", "step": step, "reason": msg}))
        sys.exit(1)


# ============================================================
# Action: step7_export
# ============================================================

def action_step7_export(args):
    """Step 7: 调用export_excel.py导出
    
    V3.0.3: 内置quality_check硬门禁，Agent无法绕过
    """
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir

    # 检查全链路gate pass完整性（防止Agent"表演"流程）
    required_gates = ["onboarding", "P0", "P1", "P2", "P3", "P4", "P5", "P6", "P7"]
    missing_gates = []
    for step in required_gates:
        ok, msg = check_gate(data_dir, step, task_id)
        if not ok:
            missing_gates.append(step)

    if missing_gates:
        print(json.dumps({
            "status": "gate_blocked",
            "reason": f"以下步骤的gate pass缺失: {missing_gates}。Agent必须真正执行这些步骤（通过orchestrator），不能跳过。",
            "missing_gates": missing_gates,
        }))
        sys.exit(1)

    # === V3.3.0: P6用例数量底线校验（精简版，详细校验已移至P7 code_check） ===
    p6_path = os.path.join(data_dir, "p6_output.json")
    if os.path.exists(p6_path):
        p6_data = _read_json(p6_path)
        cases = p6_data.get("testcases", [])
        total = len(cases)
        if total < 15:
            print(json.dumps({
                "status": "quality_blocked",
                "reason": f"P6用例数量{total}<底线15，禁止导出",
            }))
            sys.exit(1)

    # === V3.3.0: P7门禁校验（必须由p7_code_check生成） ===
    p7_path = os.path.join(data_dir, "p7_output.json")
    if os.path.exists(p7_path):
        p7_data = _read_json(p7_path)
        # V3.3.1: 验证source字段确认是代码生成的
        if p7_data.get("source") != "p7_code_check":
            print(json.dumps({
                "status": "quality_blocked",
                "reason": "P7输出不是由p7_code_check生成的，禁止导出。请执行: python3 orchestrator.py --action p7_code_check",
            }))
            sys.exit(1)
        gate_result = p7_data.get("gate_result", {})
        if isinstance(gate_result, str):
            gate_passed = gate_result.upper() in ("PASS", "PASSED")
        elif isinstance(gate_result, dict):
            gate_passed = gate_result.get("status", "").upper() in ("PASS", "PASSED")
        else:
            gate_passed = False
        if not gate_passed:
            print(json.dumps({
                "status": "quality_blocked",
                "reason": f"P7质量门禁未通过: {gate_result}",
                "gate_result": gate_result,
            }))
            sys.exit(1)

    # === V3.2.6新增：P5结构特征校验（辅助防线，确认P5由代码合并生成） ===
    p5_path = os.path.join(data_dir, "p5_output.json")
    if os.path.exists(p5_path):
        p5_data = _read_json(p5_path)
        merge_log = p5_data.get("merge_log", {})
        required_merge_keys = ["from_p2", "from_p3", "from_p4"]
        missing_merge_keys = [k for k in required_merge_keys if k not in merge_log]
        if missing_merge_keys:
            print(json.dumps({
                "status": "structure_blocked",
                "reason": f"P5 merge_log缺少必要字段: {missing_merge_keys}。P5必须由p5_code_merge生成，不允许Agent自己写。",
                "missing_keys": missing_merge_keys,
            }))
            sys.exit(1)

    # === V3.2.6新增：P6批次结构校验（辅助防线，确认P6由分批流程生成） ===
    p6_batches_dir = os.path.join(data_dir, "p6_batches")
    if not os.path.isdir(p6_batches_dir):
        print(json.dumps({
            "status": "structure_blocked",
            "reason": "p6_batches目录不存在。P6必须用分批流程(p6_batch_info→p6_save_batch→p6_merge)生成，不允许Agent直接写p6_output.json。",
        }))
        sys.exit(1)
    p6_batch_files = glob.glob(os.path.join(p6_batches_dir, "batch_*.json"))
    if len(p6_batch_files) == 0:
        print(json.dumps({
            "status": "structure_blocked",
            "reason": "p6_batches目录下无batch文件。P6必须用分批流程生成。",
        }))
        sys.exit(1)

    # 读取task_meta获取文件名
    meta = _read_json(os.path.join(data_dir, "task_meta.json"))
    domain = meta.get("domain", "unknown")

    export_script = os.path.join(skill_dir, "tools", "export_excel.py")
    p6_path = os.path.join(data_dir, "p6_output.json")
    output_path = os.path.join(data_dir, f"测试用例_{task_id}.xlsx")

    result = subprocess.run(
        ["python3", export_script, "--input", p6_path, "--output", output_path],
        capture_output=True, text=True, timeout=60
    )

    if result.returncode == 0 and os.path.exists(output_path):
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete("step7")
        # V3.2.9: 重置重试计数
        state.state.pop("p6_retry_count", None)
        state.save()
        print(json.dumps({
            "status": "ok",
            "excel_path": output_path,
            "file_size": os.path.getsize(output_path),
            "media_instruction": f"MEDIA:{output_path}",
            "reminder": "Agent必须在对话中独占一行输出上面的MEDIA指令，否则用户收不到文件",
        }))
    else:
        # V3.2.9: 失败时检查重试计数，返回结构化重试指引
        state = TaskState(data_dir=data_dir, task_id=task_id)
        retry_count = state.state.get("p6_retry_count", 0)
        error_msg = result.stderr[:300] if result.stderr else "unknown"
        
        if retry_count < 2:
            # 可重试：返回明确的自动回流指令
            state.state["p6_retry_count"] = retry_count + 1
            state.save()
            print(json.dumps({
                "status": "auto_retry",
                "retry_count": retry_count + 1,
                "max_retries": 2,
                "reason": f"Excel导出失败: {error_msg}",
                "action": "Agent必须立即执行 restart_from P6 然后重新走段落7的分批流程，禁止向用户抛选择题",
            }))
            sys.exit(1)
        else:
            # 超过最大重试次数，报告用户
            print(json.dumps({
                "status": "error",
                "reason": f"Excel导出失败（已重试{retry_count}次）: {error_msg}",
                "retry_exhausted": True,
            }))
            sys.exit(1)


# ============================================================
# Action: status
# ============================================================

def action_status(args):
    """查看当前任务状态"""
    data_dir = args.data_dir
    task_id = args.task_id

    state = TaskState(data_dir=data_dir, task_id=task_id)
    next_step = state.get_next_step()

    # 检查所有gate pass
    gates = {}
    gates_dir = os.path.join(data_dir, "gates")
    if os.path.exists(gates_dir):
        for f in os.listdir(gates_dir):
            if f.endswith(".pass.json"):
                step_name = f.replace(".pass.json", "")
                gates[step_name] = True

    print(json.dumps({
        "task_id": task_id,
        "completed_steps": state.state["completed_steps"],
        "next_step": next_step,
        "gates": gates,
    }))


# ============================================================
# Action: resume
# ============================================================

def action_resume(args):
    """断点续跑：检测已完成步骤，返回下一步"""
    data_dir = args.data_dir
    task_id = args.task_id

    state = TaskState(data_dir=data_dir, task_id=task_id)

    # 扫描gate pass补充completed_steps
    gates_dir = os.path.join(data_dir, "gates")
    if os.path.exists(gates_dir):
        for f in sorted(os.listdir(gates_dir)):
            if f.endswith(".pass.json"):
                step_name = f.replace(".pass.json", "")
                try:
                    gp = _read_json(os.path.join(gates_dir, f))
                    if gp.get("task_id") == task_id:
                        if step_name not in state.state["completed_steps"]:
                            state.state["completed_steps"].append(step_name)
                except Exception:
                    pass
        state.save()

    next_step = state.get_next_step()

    print(json.dumps({
        "status": "ok",
        "task_id": task_id,
        "completed_steps": state.state["completed_steps"],
        "next_step": next_step,
    }))


# ============================================================
# Action: prep_prompt (为每个P步骤准备完整prompt)
# ============================================================

# Prompt文件映射
PROMPT_FILES = {
    "P0": "prompts/P0_requirement_structuring.md",
    "P1": "prompts/P1_feature_tree_generation.md",
    "P2": "prompts/P2_test_point_draft.md",
    "P3": "prompts/P3_risk_identification.md",
    "P4": "prompts/P4_pci_identification.md",
    "P5": "prompts/P5_test_point_merge.md",
    "P6": "prompts/P6_testcase_generation.md",
    "P7": "prompts/archive/P7_quality_gate.md",  # V3.3.1: deprecated, P7走p7_code_check
}

# 每步需要的上游产物
UPSTREAM_FILES = {
    "P0": ["task_meta.json"],
    "P1": ["p0_output.json"],
    "P2": ["p1_output.json"],
    "P3": ["p1_output.json"],
    "P4": ["p1_output.json"],
    "P5": ["p2_output.json", "p3_output.json", "p4_output.json"],
    "P6": [],  # V3.3.2: 移除完整p5注入，改为批次信息中注入P1 scenario语义
    "P7": ["p6_output.json"],
}

# 知识注入映射
KNOWLEDGE_INJECT = {
    "P0": ["knowledge/industry/{domain}.md", "knowledge/methodology/design_methods.md"],
    "P1": ["knowledge/methodology/design_methods.md"],
    "P2": ["knowledge/methodology/boundary_rules.md", "knowledge/methodology/api_test_standard.md"],
    "P3": ["knowledge/industry/{domain}.md"],
    "P4": ["knowledge/industry/{domain}.md"],
    "P5": [],
    "P6": ["knowledge/company_standards/testcase_design_spec.md"],  # V3.3.2: 移除defect_schema（与P6用例生成无关）
    "P7": [],
}

def _read_file_safe(path, max_chars=8000):
    """安全读取文件，不存在返回空字符串"""
    if not os.path.exists(path):
        return ""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()[:max_chars]
    except Exception:
        return ""

def action_prep_prompt(args):
    """为指定的P步骤准备完整prompt，输出给Agent执行"""
    skill_dir = args.skill_dir
    data_dir = args.data_dir
    task_id = args.task_id
    step = args.step
    batch_index = int(getattr(args, 'batch_index', 0))  # P6分批用，确保int类型

    # V3.3.3: 代码路径步骤禁止生成Prompt（P6保留，分批流程需要）
    PREP_PROMPT_BLOCKED = {"P2": "p2_code_generate", "P5": "p5_code_merge", "P7": "p7_code_check"}
    if step in PREP_PROMPT_BLOCKED:
        print(json.dumps({
            "status": "rejected",
            "reason": f"❌ {step}禁止生成Prompt！{step}由代码自动执行，必须用: python3 orchestrator.py --action {PREP_PROMPT_BLOCKED[step]}",
            "correct_action": PREP_PROMPT_BLOCKED[step],
        }))
        sys.exit(1)

    if step not in PROMPT_FILES:
        print(json.dumps({"status": "error", "reason": f"不支持的步骤: {step}"}))
        sys.exit(1)

    # 前置gate pass检查
    prerequisites = {
        "P0": ["onboarding"], "P1": ["P0"], "P2": ["P1"],
        "P3": ["P1"], "P4": ["P1"], "P5": ["P2", "P3", "P4"],
        "P6": ["P5"], "P7": ["P6"],
    }
    for prereq in prerequisites.get(step, []):
        ok, msg = check_gate(data_dir, prereq, task_id)
        if not ok:
            print(json.dumps({"status": "gate_blocked", "step": prereq, "reason": msg}))
            sys.exit(1)

    # 1. 读取prompt模板
    prompt_path = os.path.join(skill_dir, PROMPT_FILES[step])
    prompt_template = _read_file_safe(prompt_path, 15000)
    if not prompt_template:
        print(json.dumps({"status": "error", "reason": f"Prompt文件不存在: {PROMPT_FILES[step]}"}))
        sys.exit(1)

    # V3.3.2: P6接口测试规则按需注入
    if step == "P6":
        has_api = _check_api_features(data_dir)
        if has_api:
            api_rules_path = os.path.join(skill_dir, "prompts", "P6_api_rules.md")
            api_rules = _read_file_safe(api_rules_path, 5000)
            if api_rules:
                prompt_template += f"\n\n---\n{api_rules}"

    # 2. 读取上游产物
    upstream_data = {}
    for fname in UPSTREAM_FILES.get(step, []):
        fpath = os.path.join(data_dir, fname)
        content = _read_file_safe(fpath, 20000)
        if content:
            upstream_data[fname] = content

    # 3. 知识注入
    # 读取domain
    meta_path = os.path.join(data_dir, "task_meta.json")
    domain = "trade"
    requirement_text = ""
    if os.path.exists(meta_path):
        try:
            meta = _read_json(meta_path)
            domain = meta.get("domain", "trade")
            requirement_text = meta.get("requirement_text", "")
        except Exception:
            pass

    knowledge_texts = []
    for kpath_template in KNOWLEDGE_INJECT.get(step, []):
        kpath = os.path.join(skill_dir, kpath_template.replace("{domain}", domain))
        kt = _read_file_safe(kpath, 3000)
        if kt:
            knowledge_texts.append(kt)

    # 4. PX增强注入（如有）
    px_inject = ""
    px_enhance_path = os.path.join(data_dir, "px_enhance.json")
    if os.path.exists(px_enhance_path):
        try:
            px_data = _read_json(px_enhance_path)
            step_subsets = px_data.get("step_subsets", {})
            step_key = step  # P0/P1/...
            if step_key in step_subsets:
                px_inject = json.dumps(step_subsets[step_key], ensure_ascii=False)
                # Qwen VL的description可能很长，截取注入不超过3000字符
                if len(px_inject) > 3000:
                    px_inject = px_inject[:3000] + "\n...(内容过长已截断)"
        except Exception:
            pass

    # 5. P6分批处理
    p6_batch_info = ""
    if step == "P6" and batch_index > 0:
        # 读取P5测试点，按批次切分
        p5_path = os.path.join(data_dir, "p5_output.json")
        if os.path.exists(p5_path):
            try:
                p5 = _read_json(p5_path)
                test_points = p5.get("test_points", [])
                batch_size = 10
                start = (batch_index - 1) * batch_size
                end = start + batch_size
                batch_points = test_points[start:end]
                total_batches = (len(test_points) + batch_size - 1) // batch_size
                # V3.2.8: 注入complexity预算信息
                batch_budget = sum(bp.get("expected_case_count", 2) for bp in batch_points)
                budget_detail = []
                for bp in batch_points:
                    bp_id = bp.get("id", "?")
                    bp_complexity = bp.get("complexity", "L2")
                    bp_expected = bp.get("expected_case_count", 2)
                    budget_detail.append(f"  - {bp_id}: {bp_complexity}(应展开{bp_expected}条)")
                budget_text = f"\n\n## ❗ 本批次用例预算（必须遵守）\n本批次应生成至少 **{batch_budget}条** 用例。每个测试点的展开数量如下：\n" + "\n".join(budget_detail) + f"\n\n复杂度说明：L1(简单)≥{1}条, L2(常规)≥{2}条, L3(复杂)≥{3}条。复杂测试点可以展开更多。"
                # V3.2.8: 精简字段版batch_points（避免全量 JSON被[:5000]截断削弱预算绑定）
                slim_points = []
                for bp in batch_points:
                    slim_points.append({
                        "id": bp.get("id", ""),
                        "description": bp.get("description", ""),
                        "category": bp.get("category", ""),
                        "priority": bp.get("priority", ""),
                        "risk_flag": bp.get("risk_flag", False),
                        "pci_flag": bp.get("pci_flag", False),
                        "complexity": bp.get("complexity", "L2"),
                        "expected_case_count": bp.get("expected_case_count", 2),
                    })
                # V3.2.9: 骨架预分配（priority/is_smoke由代码预设，Agent只填内容）
                # 冷烟分配策略：每个测试点的第1条用例为正向验证，仅当测试点priority为P0且category为main_flow/branch/integration时标记冷烟
                SMOKE_CATEGORIES = {"main_flow", "branch", "integration", "正向验证", "分支验证", "集成验证"}
                case_skeletons = []
                batch_smoke_count = 0
                batch_total_count = 0
                for bp in batch_points:
                    bp_id = bp.get("id", "")
                    bp_priority = bp.get("priority", "P1")
                    bp_category = (bp.get("category", "") or "").lower()
                    bp_expected = bp.get("expected_case_count", 2)
                    for case_idx in range(1, bp_expected + 1):
                        batch_total_count += 1
                        # 第1条=正向验证，后续=异常/边界
                        if case_idx == 1:
                            case_priority = bp_priority
                            # 冷烟标记：P0+主流程类别才标冷烟，且控制总比例≨20%
                            is_smoke = (bp_priority == "P0" and bp_category in SMOKE_CATEGORIES)
                        else:
                            # 后续用例降一级优先级
                            case_priority = "P2" if bp_priority in ("P0", "P1") else "P3"
                            is_smoke = False
                        if is_smoke:
                            batch_smoke_count += 1
                        case_skeletons.append({
                            "case_id": f"{bp_id}-TC-{case_idx:03d}",
                            "source_test_point": bp_id,
                            "priority": case_priority,
                            "is_smoke": is_smoke,
                        })
                # 冷烟比例安全检查：如果批次内无冷烟且有P0测试点，强制第一个P0的第1条为冷烟
                if batch_smoke_count == 0:
                    for sk in case_skeletons:
                        if sk["priority"] == "P0":
                            sk["is_smoke"] = True
                            batch_smoke_count = 1
                            break

                # V3.3.2: 骨架JSON改compact格式（节省~2000 chars）
                skeleton_text = f"\n\n## ❗ 用例骨架（代码预分配，禁止修改priority/is_smoke）\n以下是本批次的用例骨架，你必须为每个骨架填充title/preconditions/steps/expected_results等内容字段。\n⚠️ **case_id/source_test_point/priority/is_smoke由代码预设，你返回的这些字段将被忽略，以代码原值为准。**\n```json\n{json.dumps(case_skeletons, ensure_ascii=False)}\n```"

                # 将骨架写入文件供 save_batch 读取
                skeleton_path = os.path.join(data_dir, f"p6_batch_{batch_index:03d}_skeleton.json")
                _write_json(skeleton_path, case_skeletons)

                # V3.3.2: 全局上下文摘要 + P1 scenario语义注入 + 输出预估
                # 全局摘要
                p1_path_for_p6 = os.path.join(data_dir, "p1_output.json")
                module_names_for_summary = []
                p1_for_p6 = {}
                if os.path.exists(p1_path_for_p6):
                    try:
                        p1_for_p6 = _read_json(p1_path_for_p6)
                        ft = p1_for_p6.get("feature_tree", {})
                        ft_modules = ft.get("modules", []) if isinstance(ft, dict) else []
                        if not ft_modules:
                            ft_modules = p1_for_p6.get("modules", [])
                        module_names_for_summary = [m.get("name", "") for m in ft_modules]
                    except Exception:
                        pass
                module_names_str = '、'.join(module_names_for_summary)
                global_summary = f"\n---\n## 全局上下文（仅供参考，不要为非本批次的内容生成用例）\n本需求共{len(module_names_for_summary)}个模块：{module_names_str}。\n总测试点{len(test_points)}条，分{total_batches}批处理。本批次为第{batch_index}批。"

                # P1 scenario语义注入：提取当前批次对应的scenario详情
                batch_scenario_ids = set(bp.get("source_scenario", "") for bp in batch_points)
                scenario_details = []
                if p1_for_p6:
                    ft = p1_for_p6.get("feature_tree", {})
                    ft_modules = ft.get("modules", []) if isinstance(ft, dict) else []
                    if not ft_modules:
                        ft_modules = p1_for_p6.get("modules", [])
                    for mod in ft_modules:
                        for feat in mod.get("children", []):
                            for scen in feat.get("children", []):
                                if scen.get("id") in batch_scenario_ids:
                                    scenario_details.append({
                                        "id": scen["id"],
                                        "name": scen.get("name", ""),
                                        "module": mod.get("name", ""),
                                        "feature": feat.get("name", ""),
                                        "precondition": scen.get("precondition", ""),
                                        "related_rules": scen.get("related_rules", []),
                                        "scenario_type": scen.get("scenario_type", ""),
                                    })
                scenario_inject = ""
                if scenario_details:
                    scenario_text = json.dumps(scenario_details, ensure_ascii=False, indent=2)
                    # 大小限制：防止极端情况下注入过大
                    MAX_SCENARIO_INJECT = 3000
                    if len(scenario_text) > MAX_SCENARIO_INJECT:
                        scenario_details_slim = [{"id": s["id"], "name": s["name"], "module": s["module"]} for s in scenario_details]
                        scenario_text = json.dumps(scenario_details_slim, ensure_ascii=False, indent=2)
                    scenario_inject = f"\n---\n## 业务场景详情（用于理解测试点的业务语义）\n```json\n{scenario_text}\n```"

                # 输出长度预估提示
                output_estimate = f"\n---\n## ❗ 输出要求\n本批次需要生成 **{batch_total_count}条** 用例。\n预计输出JSON约{batch_total_count * 800}-{batch_total_count * 1200}字符。\n请确保输出完整的JSON对象，包含testcases数组，不要截断。"

                p6_batch_info = f"\n---\n## 当前批次\n第{batch_index}/{total_batches}批，处理测试点{start+1}-{min(end, len(test_points))}:\n{json.dumps(slim_points, ensure_ascii=False)}{budget_text}{skeleton_text}{global_summary}{scenario_inject}{output_estimate}"
            except Exception:
                pass

    # 6. 组装完整prompt
    full_prompt_parts = [prompt_template]

    if knowledge_texts:
        full_prompt_parts.append("\n---\n## 注入知识\n" + "\n\n".join(knowledge_texts))

    if px_inject:
        full_prompt_parts.append(f"\n---\n## 图片理解增强\n{px_inject}")

    if upstream_data:
        full_prompt_parts.append("\n---\n## 输入数据")
        for fname, content in upstream_data.items():
            full_prompt_parts.append(f"\n### {fname}\n{content}")

    # P0需要需求文本
    if step == "P0" and requirement_text:
        full_prompt_parts.append(f"\n---\n## 需求文本\n{requirement_text[:15000]}")

    if p6_batch_info:
        full_prompt_parts.append(p6_batch_info)

    # P0内联必需字段提醒
    if step == "P0":
        full_prompt_parts.append("\n---\n## ❗ 输出必须包含以下顶层字段\n- quality_score: number (0~1.0)\n- blocks: object\n- objective: string")

    # P1内联必需字段提醒
    if step == "P1":
        full_prompt_parts.append("\n---\n## ❗ 输出必须包含以下顶层字段\n- feature_tree: object (包含modules数组)\n- modules: array (与feature_tree.modules镜像)")

    # P2内联必需字段提醒（确保Agent生成的测试点带priority和status）
    if step == "P2":
        full_prompt_parts.append("""\n---\n## ❗ 每个test_point必须包含以下字段
- id: 字符串，测试点唯一标识
- source_scenario: 字符串，来源场景
- description: 字符串，测试点描述
- category: 字符串，测试类型
- priority: 必须是 "P0"/"P1"/"P2"/"P3" 之一
- status: 必须是 "active"/"blocked" 之一（默认active）
- priority_hint: 字符串，优先级建议

## ❗ 优先级分布要求（必须遵守，否则后续质量门禁会拒绝）
- P0优先级不得超过20%，推荐控制在10%-15%。P0仅用于核心主链路可用性+核心权限/交易入口级阻断场景
- P1应占主体（40%-60%），用于重要分支/异常场景
- P2/P3用于边界/兼容/性能等补充场景
- 删除/隐藏类、普通异常类、一般展示类原则上不标P0
- 不允许所有测试点为同一优先级""")

    # P7内联必需字段提醒
    if step == "P7":
        full_prompt_parts.append("""\n---\n## ❗ 输出必须包含以下顶层字段
- gate_result: object (必须包含status字段)
  - gate_result.status: 必须是 "PASS" 或 "FAIL"（全大写）
  - gate_result.summary: 字符串，检查结论
  - gate_result.checks: 数组，各项检查结果

⚠️ 注意：顶层字段名是 gate_result，不是 quality_check""")

    # P6质量规则+字段格式注入
    if step == "P6":
        full_prompt_parts.append("""\n---\n## ❗ 用例质量硬性规则（必须遵守，quality_check会校验）
1. **每个测试点至少展开为2条用例**（1条正向+1条反向/异常/边界），复杂测试点应展开更多
2. **冒烟用例比例**: 必须在8%~20%之间。冒烟用例=P0优先级+核心功能正向验证（排除删除/隐藏/异常用例）
3. **P0优先级占比**: 不得超过20%。大部分用例应为P1/P2
4. **优先级分布**: 不允许所有用例为同一优先级
5. **每需求冒烟**: 每个需求至少1条冒烟用例
6. **用例数下限**: 合并后至少15条用例，且不少于P5测试点数×1.5

违反以上任何规则的用例集将被quality_check拒绝，需要重新生成。

## ❗ 字段格式要求（必须严格遵守）
- **is_smoke**: 必须是布尔值 true 或 false（不是字符串，不是"是/否"，不是"?"）
- **priority**: 必须是 "P0"/"P1"/"P2"/"P3" 之一
- **title**: 必须非空
- **preconditions**: 必须非空
- **steps**: 必须是数组，每项包含 step 和 expected
- **testcases**: 顶层字段名必须是 testcases（小写）

## ❗ 严禁占位符内容（违反将被直接拒绝）
- 每条用例的steps必须是**具体的、可执行的操作步骤**，不允许使用"执行相关操作""观察结果"等泛化描述
- 每条用例的expected_results必须是**具体的、可验证的预期结果**，不允许使用"页面展示正常""数据与预期一致"等泛化描述
- 不同测试点的用例步骤必须有差异，不允许所有用例使用相同的步骤模板
- 违反以上规则的批次将被p6_save_batch直接拒绝""")

    full_prompt = "\n".join(full_prompt_parts)

    # 输出
    result = {
        "status": "ok",
        "step": step,
        "prompt_length": len(full_prompt),
        "upstream_files": list(upstream_data.keys()),
        "knowledge_injected": len(knowledge_texts),
        "px_injected": bool(px_inject),
    }

    # 将prompt写入文件（太长不适合通过stdout传递）
    prompt_output_path = os.path.join(data_dir, f"{step.lower()}_prompt.txt")
    with open(prompt_output_path, "w", encoding="utf-8") as f:
        f.write(full_prompt)
    result["prompt_file"] = prompt_output_path

    print(json.dumps(result))


# ============================================================
# Action: p6_batch_info (P6分批信息)
# ============================================================

# ============================================================
# Action: p2_code_generate (V3.3.2: P2测试点代码自动生成)
# ============================================================

def action_p2_code_generate(args):
    """代码层从P1 feature_tree自动生成P2测试点（零Agent依赖）
    
    职责边界：只管结构（数量、category、priority、source_scenario）
    语义细化由P6承担（P6 prompt注入P1 scenario详情）
    """
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir

    # 前置gate检查：P1必须完成
    ok, msg = check_gate(data_dir, "P1", task_id)
    if not ok:
        print(json.dumps({"status": "gate_blocked", "step": "P1", "reason": msg}))
        sys.exit(1)

    # 读取P1 feature_tree
    p1_path = os.path.join(data_dir, "p1_output.json")
    if not os.path.exists(p1_path):
        print(json.dumps({"status": "error", "reason": "p1_output.json不存在"}))
        sys.exit(1)
    p1_data = _read_json(p1_path)
    
    # P1数据结构：feature_tree.modules 包含嵌套children结构
    feature_tree = p1_data.get("feature_tree", {})
    if isinstance(feature_tree, dict):
        modules = feature_tree.get("modules", [])
    else:
        modules = []
    # 兼容：如果feature_tree为空，尝试顶层modules
    if not modules:
        modules = p1_data.get("modules", [])

    if not modules:
        print(json.dumps({"status": "error", "reason": "P1数据中未找到modules"}))
        sys.exit(1)

    # 读取P0 operations（补充语义判断）
    p0_path = os.path.join(data_dir, "p0_output.json")
    p0_operations = []
    if os.path.exists(p0_path):
        try:
            p0_data = _read_json(p0_path)
            p0_operations = p0_data.get("blocks", {}).get("operations", [])
        except Exception:
            pass

    # 关键词集合
    DATA_KEYWORDS = {"导入", "导出", "上传", "下载", "查询", "统计", "推送", "同步"}

    # 获取requirement_id
    requirement_id = p1_data.get("requirement_id", "REQ-UNKNOWN")

    # 遍历所有scenario生成测试点
    test_points = []
    seq = 1

    for module in modules:
        for feature in module.get("children", []):
            if feature.get("type") != "feature":
                continue
            for scenario in feature.get("children", []):
                if scenario.get("type") != "scenario":
                    continue

                scenario_id = scenario.get("id", "")
                scenario_name = scenario.get("name", "")
                scenario_type = scenario.get("scenario_type", "positive")
                precondition = scenario.get("precondition", "")
                related_rules = scenario.get("related_rules", [])
                related_roles = scenario.get("related_roles", [])

                # 规则1：正向验证（所有scenario必有）
                test_points.append({
                    "id": f"{requirement_id}-TP-{seq:03d}",
                    "source_scenario": scenario_id,
                    "category": "main_flow",
                    "description": f"验证{scenario_name}正常流程",
                    "precondition": precondition,
                    "related_rules": related_rules,
                    "related_roles": related_roles,
                    "priority": "P1",
                    "priority_hint": "P1",
                    "status": "active",
                })
                seq += 1

                # 规则2：异常验证
                test_points.append({
                    "id": f"{requirement_id}-TP-{seq:03d}",
                    "source_scenario": scenario_id,
                    "category": "exception",
                    "description": f"验证{scenario_name}异常场景处理",
                    "precondition": precondition,
                    "related_rules": related_rules,
                    "related_roles": related_roles,
                    "priority": "P2",
                    "priority_hint": "P2",
                    "status": "active",
                })
                seq += 1

                # 规则3：边界验证（数据相关场景）
                if any(kw in scenario_name for kw in DATA_KEYWORDS):
                    test_points.append({
                        "id": f"{requirement_id}-TP-{seq:03d}",
                        "source_scenario": scenario_id,
                        "category": "boundary",
                        "description": f"验证{scenario_name}边界条件和数据完整性",
                        "precondition": precondition,
                        "related_rules": related_rules,
                        "related_roles": related_roles,
                        "priority": "P3",
                        "priority_hint": "P3",
                        "status": "active",
                    })
                    seq += 1

                # 规则4：权限验证（多角色场景）
                if related_roles and len(related_roles) > 1:
                    test_points.append({
                        "id": f"{requirement_id}-TP-{seq:03d}",
                        "source_scenario": scenario_id,
                        "category": "permission",
                        "description": f"验证{scenario_name}不同角色权限控制",
                        "precondition": precondition,
                        "related_rules": related_rules,
                        "related_roles": related_roles,
                        "priority": "P1",
                        "priority_hint": "P1",
                        "status": "active",
                    })
                    seq += 1

    # P0提升逻辑：每module第1个main_flow升为P0
    seen_modules_for_p0 = set()
    for tp in test_points:
        if tp["category"] == "main_flow":
            # 从source_scenario提取module ID（如REQ-2026-XG-014-M01-F01-S01中的M01）
            src = tp.get("source_scenario", "")
            module_id = None
            for part in src.split("-"):
                if part.startswith("M") and part[1:].isdigit():
                    module_id = part
                    break
            if module_id and module_id not in seen_modules_for_p0:
                tp["priority"] = "P0"
                tp["priority_hint"] = "P0"
                seen_modules_for_p0.add(module_id)

    # complexity和expected_case_count标签（与P5 merge逻辑一致）
    SIMPLE_CATEGORIES = {"compatibility", "display", "ui_check"}
    COMPLEX_CATEGORIES = {"permission", "exception", "integration", "data_consistency"}
    for tp in test_points:
        cat = tp.get("category", "").lower()
        has_risk = tp.get("risk_flag", False)
        priority = tp.get("priority", "P1")
        score = 0
        if cat in COMPLEX_CATEGORIES:
            score += 2
        if has_risk:
            score += 1
        if priority in ("P0", "P1"):
            score += 1
        if score >= 3:
            tp["complexity"] = "L3"
            tp["expected_case_count"] = 3
        elif score >= 1:
            tp["complexity"] = "L2"
            tp["expected_case_count"] = 2
        else:
            tp["complexity"] = "L1"
            tp["expected_case_count"] = 1
        # 初始化risk/pci标记（P5 merge会覆盖）
        tp.setdefault("risk_flag", False)
        tp.setdefault("pci_flag", False)

    # 覆盖率校验
    modules_covered = set()
    features_covered = set()
    for tp in test_points:
        src = tp.get("source_scenario", "")
        for part in src.split("-"):
            if part.startswith("M") and part[1:].isdigit():
                modules_covered.add(part)
            if part.startswith("F") and part[1:].isdigit():
                # 提取到feature级别
                idx = src.index(part)
                features_covered.add(src[:idx + len(part)])

    total_modules = len(modules)
    coverage_ok = len(modules_covered) >= total_modules

    # 构建输出
    output = {
        "schema_version": "1.0.0",
        "prompt_version": "1.0.0",
        "requirement_id": requirement_id,
        "test_points": test_points,
        "coverage_summary": {
            "total_test_points": len(test_points),
            "modules_covered": len(modules_covered),
            "total_modules": total_modules,
            "features_covered": len(features_covered),
            "coverage_ok": coverage_ok,
            "generation_method": "code",
        }
    }

    # 写入tmp文件
    tmp_path = os.path.join(data_dir, "p2_output.tmp.json")
    _write_json(tmp_path, output)

    # 调用truncation_guard
    guard_ok, guard_msg = run_truncation_guard(skill_dir, data_dir, task_id, "P2", revision=1)
    if not guard_ok:
        print(json.dumps({"status": "guard_failed", "reason": guard_msg}))
        sys.exit(1)

    # 统计
    from collections import Counter
    pri_dist = dict(Counter(tp["priority"] for tp in test_points))
    cat_dist = dict(Counter(tp["category"] for tp in test_points))

    print(json.dumps({
        "status": "ok",
        "step": "P2",
        "test_points_count": len(test_points),
        "priority_distribution": pri_dist,
        "category_distribution": cat_dist,
        "coverage": output["coverage_summary"],
        "guard_result": f"GUARD_PASS:P2:{len(test_points)}",
    }))


# ============================================================
# Action: p5_code_merge (V3.2.0: P5合并下沉代码层)
# ============================================================

def action_p5_code_merge(args):
    """代码层合并P2+P3+P4→P5（不再依赖Agent/prompt合并）
    
    读取P2测试点 + P3风险点 + P4 PCI项，代码合并后写入P5
    """
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir

    # 前置gate检查
    for prereq in ["P2", "P3", "P4"]:
        ok, msg = check_gate(data_dir, prereq, task_id)
        if not ok:
            print(json.dumps({"status": "gate_blocked", "step": prereq, "reason": msg}))
            sys.exit(1)

    # 读取P2测试点
    p2_path = os.path.join(data_dir, "p2_output.json")
    p2_data = _read_json(p2_path) if os.path.exists(p2_path) else {}
    p2_points = p2_data.get("test_points", [])

    # 读取P3风险点（兼容risk_points和risks）
    p3_path = os.path.join(data_dir, "p3_output.json")
    p3_data = _read_json(p3_path) if os.path.exists(p3_path) else {}
    p3_risks = p3_data.get("risk_points", p3_data.get("risks", []))

    # 读取P4 PCI项（兼容pci_list和pci_items）
    p4_path = os.path.join(data_dir, "p4_output.json")
    p4_data = _read_json(p4_path) if os.path.exists(p4_path) else {}
    p4_pcis = p4_data.get("pci_list", p4_data.get("pci_items", []))

    # 合并逻辑：P2测试点为基础，P3风险补充风险标记，P4 PCI补充待确认标记
    merged_points = []
    from_p3_count = 0
    from_p4_count = 0

    # 复制P2测试点
    for tp in p2_points:
        point = dict(tp)  # 浅拷贝
        point["source"] = "P2"
        point.setdefault("risk_flag", False)
        point.setdefault("pci_flag", False)
        merged_points.append(point)

    # 边界安全前缀匹配（防止M01-F01误匹配M01-F010）
    def _boundary_prefix_match(full_str, prefix):
        """prefix后必须紧跟'-'或完全相等"""
        if not prefix or not full_str:
            return False
        if full_str == prefix:
            return True
        return full_str.startswith(prefix + "-")

    # P3风险点补充：多策略匹配（精确→边界前缀→新增）
    # P3实际字段：source_node(feature级别如M01-F01)，无source_scenario
    # 改进：feature级风险应映射到该feature下所有scenario（不再break）
    for risk in p3_risks:
        risk_ref = risk.get("source_scenario") or risk.get("source_node") or risk.get("source", "")
        matched = False
        if risk_ref:
            # 策略1：精确匹配（scenario级别）
            for point in merged_points:
                point_source = point.get("source_scenario", "")
                if point_source and risk_ref == point_source:
                    point["risk_flag"] = True
                    point["risk_description"] = risk.get("description", "")
                    point["risk_severity"] = risk.get("severity", risk.get("impact", "medium"))
                    matched = True
                    from_p3_count += 1
                    break  # 精确匹配只命中1个
            # 策略2：边界前缀匹配（feature级→所有子scenario，不break）
            if not matched:
                for point in merged_points:
                    point_source = point.get("source_scenario", "")
                    if point_source and _boundary_prefix_match(point_source, risk_ref):
                        point["risk_flag"] = True
                        point["risk_description"] = risk.get("description", "")
                        point["risk_severity"] = risk.get("severity", risk.get("impact", "medium"))
                        matched = True
                # 前缀匹配命中后统一计数
                if matched:
                    from_p3_count += 1
        if not matched:
            merged_points.append({
                "id": risk.get("id", f"RISK-{len(merged_points)+1}"),
                "source": "P3",
                "source_scenario": risk_ref,
                "description": f"[风险验证] {risk.get('description', '')}",
                "category": "risk_verification",
                "risk_flag": True,
                "risk_severity": risk.get("severity", risk.get("impact", "medium")),
                "pci_flag": False,
                "priority_hint": "P1",
            })
            from_p3_count += 1

    # P4 PCI补充：多策略全量匹配（blocked_scenarios全量→source边界前缀→新增）
    # P4实际字段：source="P1"(无用)，blocked_scenarios=[scenario IDs](有用)
    # 改进：blocked_scenarios全量匹配，不再break
    for pci in p4_pcis:
        blocked = pci.get("blocked_scenarios", [])
        # 兼容字符串转单元素数组
        if isinstance(blocked, str) and blocked:
            blocked = [blocked]
        elif not isinstance(blocked, list):
            blocked = []
        pci_source = pci.get("source_scenario") or pci.get("source", "")
        matched = False
        # 策略1：用blocked_scenarios全量匹配P2测试点（不break）
        if blocked:
            for point in merged_points:
                point_source = point.get("source_scenario", "")
                if point_source and point_source in blocked:
                    point["pci_flag"] = True
                    point["pci_description"] = pci.get("description", "")
                    matched = True
            if matched:
                from_p4_count += 1
        # 策略2：用source_scenario或source边界前缀匹配（全量）
        if not matched and pci_source and pci_source not in ("P0", "P1", "P2", "P3", "P4"):
            for point in merged_points:
                point_source = point.get("source_scenario", "")
                if point_source and (pci_source == point_source or _boundary_prefix_match(point_source, pci_source)):
                    point["pci_flag"] = True
                    point["pci_description"] = pci.get("description", "")
                    matched = True
            if matched:
                from_p4_count += 1
        if not matched:
            merged_points.append({
                "id": pci.get("id", f"PCI-{len(merged_points)+1}"),
                "source": "P4",
                "source_scenario": blocked[0] if isinstance(blocked, list) and blocked else pci_source,
                "description": f"[待确认] {pci.get('description', '')}",
                "category": "pci_verification",
                "risk_flag": False,
                "pci_flag": True,
                "priority_hint": "P1",
            })
            from_p4_count += 1

    # 去重（基于description相似度，简化为完全相同）
    seen_descs = set()
    deduped = []
    removed = 0
    for point in merged_points:
        desc = point.get("description", "")
        if desc and desc in seen_descs:
            removed += 1
            continue
        if desc:
            seen_descs.add(desc)
        deduped.append(point)

    # 统一补齐 priority 和 status（truncation_guard L3 必检字段）
    for point in deduped:
        if "priority" not in point:
            point["priority"] = point.get("priority_hint", "P1")
        if "status" not in point:
            point["status"] = "active"

    # V3.2.8: 给每个测试点打complexity和expected_case_count标签
    # 规则：根据测试点类型、风险标记、PCI标记、描述长度综合判断
    # L1(简单)≥1条, L2(常规)≥2条, L3(复杂)≥3条
    SIMPLE_CATEGORIES = {"compatibility", "display", "ui_check", "兼容回归", "展示校验"}
    COMPLEX_CATEGORIES = {"permission", "exception", "integration", "data_consistency",
                          "权限验证", "异常处理", "集成异常", "数据一致性"}
    for point in deduped:
        cat = (point.get("category", "") or "").lower()
        desc = point.get("description", "") or ""
        has_risk = point.get("risk_flag", False)
        has_pci = point.get("pci_flag", False)
        source = point.get("source", "P2")

        # 复杂度评分
        score = 0
        if cat in COMPLEX_CATEGORIES:
            score += 2
        elif cat in SIMPLE_CATEGORIES:
            score += 0
        else:
            score += 1  # 默认常规
        if has_risk:
            score += 1
        if has_pci:
            score += 1
        if source in ("P3", "P4"):
            score += 1  # 风险/PCI派生的测试点本身就复杂
        if len(desc) > 100:
            score += 1  # 描述越长通常越复杂

        # 分级
        if score <= 0:
            point["complexity"] = "L1"
            point["expected_case_count"] = 1
        elif score <= 2:
            point["complexity"] = "L2"
            point["expected_case_count"] = 2
        else:
            point["complexity"] = "L3"
            point["expected_case_count"] = 3

    # 统计复杂度分布
    complexity_dist = {}
    total_expected = 0
    for point in deduped:
        c = point.get("complexity", "L2")
        complexity_dist[c] = complexity_dist.get(c, 0) + 1
        total_expected += point.get("expected_case_count", 2)

    # 构造P5输出
    p5_output = {
        "schema_version": "1.0.0",
        "prompt_version": "1.0.0",
        "requirement_id": p2_data.get("requirement_id", ""),
        "test_points": deduped,
        "merge_log": {
            "from_p2": len(p2_points),
            "from_p3": from_p3_count,
            "from_p4": from_p4_count,
            "merged": len(merged_points),
            "removed_duplicates": removed,
            "final_count": len(deduped),
        },
        "coverage_summary": {
            "total_test_points": len(deduped),
            "risk_flagged": sum(1 for p in deduped if p.get("risk_flag")),
            "pci_flagged": sum(1 for p in deduped if p.get("pci_flag")),
            "complexity_distribution": complexity_dist,
            "total_expected_cases": total_expected,
        },
    }

    # 写入tmp→truncation_guard→gate pass
    tmp_path = os.path.join(data_dir, "p5_output.tmp.json")
    _write_json(tmp_path, p5_output)

    ok, msg = run_truncation_guard(skill_dir, data_dir, task_id, "P5")
    if ok:
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete("P5")
        print(json.dumps({
            "status": "ok",
            "step": "P5",
            "total_test_points": len(deduped),
            "from_p2": len(p2_points),
            "from_p3": from_p3_count,
            "from_p4": from_p4_count,
            "removed_duplicates": removed,
        }))
    else:
        print(json.dumps({"status": "guard_failed", "step": "P5", "reason": msg}))
        sys.exit(1)


def action_p6_batch_info(args):
    """返回P6分批信息：总批次数、每批测试点数"""
    data_dir = args.data_dir
    task_id = args.task_id

    # V3.2.6: P5前置gate校验
    ok, msg = check_gate(data_dir, "P5", task_id)
    if not ok:
        print(json.dumps({
            "status": "gate_blocked",
            "reason": f"P6批次信息需要P5 gate pass: {msg}。必须先执行p5_code_merge完成P5。",
        }))
        sys.exit(1)

    p5_path = os.path.join(data_dir, "p5_output.json")
    if not os.path.exists(p5_path):
        print(json.dumps({"status": "error", "reason": "p5_output.json不存在"}))
        sys.exit(1)

    p5 = _read_json(p5_path)
    test_points = p5.get("test_points", [])
    total = len(test_points)
    batch_size = 10
    total_batches = (total + batch_size - 1) // batch_size

    print(json.dumps({
        "status": "ok",
        "total_test_points": total,
        "batch_size": batch_size,
        "total_batches": total_batches,
    }))


# ============================================================
# Action: p6_merge (P6批次合并)
# ============================================================

def action_p6_merge(args):
    """合并P6所有批次结果，写入p6_output.tmp.json，调用truncation_guard"""
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir

    # V3.2.6: P5前置gate校验（防止Agent伪造batch后借刀签名）
    ok, msg = check_gate(data_dir, "P5", task_id)
    if not ok:
        print(json.dumps({
            "status": "gate_blocked",
            "reason": f"P6合并需要P5 gate pass: {msg}。必须先执行p5_code_merge完成P5。",
        }))
        sys.exit(1)

    # 扫描p6_batches目录
    batches_dir = os.path.join(data_dir, "p6_batches")
    if not os.path.exists(batches_dir):
        print(json.dumps({"status": "error", "reason": "p6_batches目录不存在"}))
        sys.exit(1)

    all_cases = []
    batch_files = sorted(glob.glob(os.path.join(batches_dir, "batch_*.json")))

    for bf in batch_files:
        try:
            batch_data = _read_json(bf)
            cases = batch_data.get("testcases", batch_data.get("cases", []))
            all_cases.extend(cases)
        except Exception as e:
            print(json.dumps({"status": "warning", "reason": f"批次文件读取失败: {bf}: {e}"}), file=sys.stderr)

    if not all_cases:
        print(json.dumps({"status": "error", "reason": "所有批次合并后用例数为0"}))
        sys.exit(1)

    # 统计（V3.2.4: 使用_get_case_field兼容fields嵌套结构）
    p0_count = sum(1 for c in all_cases if _get_case_field(c, "priority", "").upper() in ("P0", "HIGHEST"))
    smoke_count = sum(1 for c in all_cases if _is_smoke(_get_case_field(c, "is_smoke", "")))

    # 按优先级统计
    by_priority = {}
    for c in all_cases:
        p = _get_case_field(c, "priority", "unknown").upper()
        by_priority[p] = by_priority.get(p, 0) + 1

    merged = {
        "testcases": all_cases,
        "statistics": {
            "total": len(all_cases),
            "by_priority": by_priority,
            "smoke_count": smoke_count,
            "p0_count": p0_count,
            "batch_count": len(batch_files),
        }
    }

    # V3.2.9: 全局硬校验（代码层硬控，不依赖Agent）
    merge_issues = []
    p5_path = os.path.join(data_dir, "p5_output.json")
    if os.path.exists(p5_path):
        try:
            p5_data = _read_json(p5_path)
            p5_points = p5_data.get("test_points", [])
            p5_ids = set(tp.get("id", "") for tp in p5_points if tp.get("id"))
            total_expected = p5_data.get("coverage_summary", {}).get("total_expected_cases", 0)

            # 校验1：总用例数≥总预算
            if total_expected > 0 and len(all_cases) < total_expected:
                merge_issues.append(f"用例总数{len(all_cases)}<预算{total_expected}")

            # 校验2：逐测试点展开数达标
            tp_actual = {}
            covered_ids = set()
            for c in all_cases:
                src = _get_case_field(c, "source_test_point", "")
                if not src:
                    cid = _get_case_field(c, "case_id", "")
                    if cid and "-TC-" in cid:
                        src = cid.rsplit("-TC-", 1)[0]
                if src:
                    tp_actual[src] = tp_actual.get(src, 0) + 1
                    covered_ids.add(src)

            shortfall_points = []
            for tp in p5_points:
                tp_id = tp.get("id", "")
                expected = tp.get("expected_case_count", 2)
                actual = tp_actual.get(tp_id, 0)
                if actual < expected:
                    shortfall_points.append(f"{tp_id}:应{expected}实{actual}")
            if shortfall_points:
                merge_issues.append(f"{len(shortfall_points)}个测试点展开不足: {', '.join(shortfall_points[:5])}")

            # 校验3：未覆盖的测试点
            uncovered = p5_ids - covered_ids
            if uncovered:
                merge_issues.append(f"{len(uncovered)}个测试点未覆盖: {', '.join(sorted(uncovered)[:5])}")

            # 写入覆盖统计
            merged["statistics"]["p5_coverage"] = {
                "total_p5": len(p5_ids),
                "covered": len(covered_ids),
                "uncovered": sorted(uncovered) if uncovered else [],
                "shortfall_points": shortfall_points[:10] if shortfall_points else [],
            }
        except Exception:
            pass

    # V3.3.1: 全局底线校验（精确比例校验已移至P7 code_check）
    # 校验4：全局smoke>0（底线，避免全局smoke=0的极端情况）
    if len(all_cases) > 0:
        if smoke_count == 0:
            merge_issues.append("全局冒烟用例为0，必须有核心主链路的冒烟用例")

    # 校验5：全局P0>0（底线）
    if len(all_cases) > 0:
        if p0_count == 0:
            merge_issues.append("全局P0用例为0，必须有核心主链路的P0用例")
    if merge_issues:
        print(json.dumps({
            "status": "quality_rejected",
            "issues": merge_issues,
            "retry_hint": "全局质量校验未通过，请重新执行P6分批流程",
        }))
        sys.exit(1)

    # 写入tmp
    tmp_path = os.path.join(data_dir, "p6_output.tmp.json")
    _write_json(tmp_path, merged)

    # truncation_guard
    ok, msg = run_truncation_guard(skill_dir, data_dir, task_id, "P6")

    if ok:
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete("P6")
        print(json.dumps({
            "status": "ok",
            "total_cases": len(all_cases),
            "smoke_count": smoke_count,
            "batches_merged": len(batch_files),
            "guard_result": msg,
            "quality_check": "V3.3.1_global_hard_pass",
        }))
    else:
        print(json.dumps({"status": "guard_failed", "reason": msg}))
        sys.exit(1)


# ============================================================
# Action: p6_save_batch (保存P6单批结果)
# ============================================================

def action_p6_save_batch(args):
    """保存P6单批结果到p6_batches/batch_N.json"""
    data_dir = args.data_dir
    task_id = args.task_id
    batch_index = int(args.batch_index) if args.batch_index else 1
    agent_output = args.agent_output

    # V3.2.6: P5前置gate校验（防止Agent在无合法P5时伪造batch）
    ok, msg = check_gate(data_dir, "P5", task_id)
    if not ok:
        print(json.dumps({
            "status": "gate_blocked",
            "reason": f"P6保存批次需要P5 gate pass: {msg}。必须先执行p5_code_merge完成P5。",
        }))
        sys.exit(1)

    try:
        batch_data = json.loads(agent_output)
    except Exception:
        import re
        match = re.search(r'\{[\s\S]*\}', agent_output)
        if match:
            try:
                batch_data = json.loads(match.group())
            except Exception:
                print(json.dumps({"status": "error", "reason": "P6批次JSON解析失败"}))
                sys.exit(1)
        else:
            print(json.dumps({"status": "error", "reason": "P6批次输出不含JSON"}))
            sys.exit(1)

    batches_dir = os.path.join(data_dir, "p6_batches")
    _ensure_dir(batches_dir)

    batch_path = os.path.join(batches_dir, f"batch_{batch_index:03d}.json")
    _write_json(batch_path, batch_data)

    cases = batch_data.get("testcases", batch_data.get("cases", []))

    # V3.2.9: 骨架锁定——读取预分配的skeleton，用代码原值覆盖Agent返回的priority/is_smoke
    skeleton_path = os.path.join(data_dir, f"p6_batch_{batch_index:03d}_skeleton.json")
    skeleton_map = {}  # case_id -> {priority, is_smoke, source_test_point}
    if os.path.exists(skeleton_path):
        try:
            skeletons = _read_json(skeleton_path)
            for sk in skeletons:
                skeleton_map[sk.get("case_id", "")] = sk
        except Exception:
            pass

    # 对每条用例强制覆盖priority/is_smoke/source_test_point
    if skeleton_map:
        for c in cases:
            cid = _get_case_field(c, "case_id", "")
            if cid in skeleton_map:
                sk = skeleton_map[cid]
                # 强制覆盖到fields或顶层
                if "fields" in c and isinstance(c["fields"], dict):
                    c["fields"]["priority"] = sk["priority"]
                    c["fields"]["is_smoke"] = sk["is_smoke"]
                    c["fields"]["source_test_point"] = sk["source_test_point"]
                    c["fields"]["case_id"] = sk["case_id"]
                else:
                    c["priority"] = sk["priority"]
                    c["is_smoke"] = sk["is_smoke"]
                    c["source_test_point"] = sk["source_test_point"]
                    c["case_id"] = sk["case_id"]
        # 重新写入覆盖后的batch文件
        batch_data["testcases"] = cases
        _write_json(batch_path, batch_data)

    # V3.2.9: 硬校验（不达标直接拒绝保存）
    hard_issues = []

    # 校验0：case_id全集一致性（防止Agent伪造/缺少/重复case_id）
    if skeleton_map:
        skeleton_ids = set(skeleton_map.keys())
        returned_ids = set()
        duplicate_ids = []
        for c in cases:
            cid = _get_case_field(c, "case_id", "")
            if cid in returned_ids:
                duplicate_ids.append(cid)
            returned_ids.add(cid)
        missing_ids = skeleton_ids - returned_ids
        extra_ids = returned_ids - skeleton_ids
        if missing_ids:
            hard_issues.append(f"缺少{len(missing_ids)}个骨架用例: {', '.join(sorted(missing_ids)[:3])}")
        if extra_ids:
            hard_issues.append(f"多出{len(extra_ids)}个非法用例: {', '.join(sorted(extra_ids)[:3])}")
        if duplicate_ids:
            hard_issues.append(f"重复{len(duplicate_ids)}个case_id: {', '.join(duplicate_ids[:3])}")

    # 校验1：用例数量≥batch_budget（逐测试点校验）
    p5_path = os.path.join(data_dir, "p5_output.json")
    if os.path.exists(p5_path) and os.path.exists(skeleton_path):
        try:
            p5_data = _read_json(p5_path)
            p5_map = {tp.get("id", ""): tp for tp in p5_data.get("test_points", [])}
            skeletons = _read_json(skeleton_path)
            # 统计每个测试点的实际用例数
            tp_actual = {}
            for c in cases:
                src = _get_case_field(c, "source_test_point", "")
                if not src:
                    cid = _get_case_field(c, "case_id", "")
                    if cid and "-TC-" in cid:
                        src = cid.rsplit("-TC-", 1)[0]
                if src:
                    tp_actual[src] = tp_actual.get(src, 0) + 1
            # 逐点校验
            tp_expected = {}
            for sk in skeletons:
                src = sk.get("source_test_point", "")
                tp_expected[src] = tp_expected.get(src, 0) + 1
            shortfall = []
            for tp_id, expected in tp_expected.items():
                actual = tp_actual.get(tp_id, 0)
                if actual < expected:
                    shortfall.append(f"{tp_id}:应{expected}条实际{actual}条")
            if shortfall:
                hard_issues.append(f"测试点展开不足: {', '.join(shortfall[:5])}")
        except Exception:
            pass

    # 校验2：冷烟比例≨25%（单批宽松，merge再卡—20%）
    if len(cases) > 0:
        smoke_count = sum(1 for c in cases if _is_smoke(_get_case_field(c, "is_smoke", "")))
        smoke_ratio = smoke_count / len(cases)
        if smoke_ratio > 0.25:
            hard_issues.append(f"冷烟比例{smoke_ratio:.0%}>25%")

    # 校验3：P0比例≨25%
    if len(cases) > 0:
        p0_count = sum(1 for c in cases if _get_case_field(c, "priority", "").upper() in ("P0", "HIGHEST"))
        p0_ratio = p0_count / len(cases)
        if p0_ratio > 0.25:
            hard_issues.append(f"P0比例{p0_ratio:.0%}>25%")

    # 校验4：步骤去重检测（唯一步骤<50%拒绝）
    if len(cases) >= 4:
        steps_set = set()
        for c in cases:
            s = _get_case_field(c, "steps", "")
            if s:
                steps_set.add(s.strip())
        unique_ratio = len(steps_set) / len(cases)
        if unique_ratio < 0.5:
            hard_issues.append(f"步骤内容过于模板化：{len(steps_set)}种步骤/{len(cases)}条用例(唯一率{unique_ratio:.0%}<50%)，每条用例必须有针对具体业务场景的差异化步骤")

    # 校验5：关键字段非空
    empty_title = sum(1 for c in cases if not _get_case_field(c, "title", ""))
    empty_steps = sum(1 for c in cases if not _get_case_field(c, "steps", ""))
    empty_expected = sum(1 for c in cases if not _get_case_field(c, "expected_results", ""))
    if empty_title > 0:
        hard_issues.append(f"{empty_title}条用例title为空")
    if empty_steps > 0:
        hard_issues.append(f"{empty_steps}条用例steps为空")
    if empty_expected > 0:
        hard_issues.append(f"{empty_expected}条用例expected_results为空")

    # V3.3.3: 步骤唯一性检查（拒绝占位符内容）
    if len(cases) > 3:
        steps_set = set()
        for c in cases:
            steps_text = _get_case_field(c, "steps", "")
            if steps_text:
                steps_set.add(str(steps_text)[:100])
        if len(steps_set) <= 1:
            hard_issues.append("所有用例的操作步骤完全相同，这是占位符内容。请根据每个测试点的业务场景生成差异化的具体步骤")

    if hard_issues:
        # 删除已写入的不合格文件
        if os.path.exists(batch_path):
            os.remove(batch_path)
        print(json.dumps({
            "status": "quality_rejected",
            "batch_index": batch_index,
            "issues": hard_issues,
            "retry_hint": "请重新生成本批次用例，确保每个测试点按预算展开、步骤差异化、关键字段非空",
        }))
        sys.exit(1)

    print(json.dumps({
        "status": "ok",
        "batch_index": batch_index,
        "cases_in_batch": len(cases),
        "batch_file": batch_path,
        "skeleton_locked": bool(skeleton_map),
    }))


# ============================================================
# Action: quality_check (质量校验强化)
# ============================================================

# 每步最小产出数量
# 每步最小产出数量（以云端实际JSON字段名为真源，支持多候选路径用|分隔）
MIN_OUTPUT_COUNTS = {
    "P0": {"blocks.operations|blocks.pages|blocks.business_rules": 1},  # P0实际输出用blocks.operations/pages/business_rules
    "P1": {"feature_tree.modules|modules": 2},  # P1实际输出用feature_tree.modules或顶层modules
    "P2": {"test_points": 8},  # V3.2.8: 静态底线8，quality_check中动态计算为max(8, P1叶节点数×2)
    "P3": {"risk_points": 1},  # 至少1个风险点
    "P4": {"pci_list": 1},  # 至少1个PCI
    "P5": {"test_points": 10},
    "P6": {"testcases": 15},  # V3.2.7: 静态底线15，quality_check中动态计算为P5测试点数×1.5
}

# P6用例质量规则（V3.0.3统一真源，prep_prompt和quality_check共用）
P6_QUALITY_RULES = {
    "smoke_ratio_min": 0.08,  # 冒烟用例至少8%
    "smoke_ratio_max": 0.20,  # 冒烟用例不超过20%
    "p0_ratio_max": 0.20,  # P0优先级不超过20%（V3.2.3收紧→V3.2.4沿用，与P2 prep_prompt注入一致）
    "all_same_priority": False,  # 不允许所有用例同一优先级
    "per_requirement_smoke": True,  # 每个需求至少1条冒烟用例
}

def _get_nested(data, key_path):
    """获取嵌套字段值，支持多候选路径（用|分隔）
    
    示例:
      _get_nested(data, "blocks.modules")  # 单路径
      _get_nested(data, "blocks.operations|blocks.pages")  # 多候选，返回第一个非空的
    """
    candidates = key_path.split("|")
    for candidate in candidates:
        keys = candidate.strip().split(".")
        current = data
        for k in keys:
            if isinstance(current, dict):
                current = current.get(k)
            else:
                current = None
                break
        if current is not None:
            return current
    return None

# ============================================================
# Action: p7_code_check (V3.3.1: P7代码硬校验，替代Agent审计)
# ============================================================

# P7子检查函数
def _p7_check_c1(cases):
    """C1 要素完整性 [BLOCK]: 必填7项非空"""
    required = ['case_id', 'title', 'preconditions', 'steps', 'expected_results', 'priority', 'is_smoke']
    issues = []
    for c in cases:
        for rf in required:
            val = _get_case_field(c, rf, "")
            if val is None or (isinstance(val, str) and not val.strip()):
                issues.append({"case_id": _get_case_field(c, "case_id", "?"), "field": rf, "issue": f"{rf}为空"})
    return {
        "check_id": "C1", "name": "要素完整性", "level": "BLOCK",
        "status": "FAILED" if issues else "PASSED",
        "detail": f"{len(cases)}/{len(cases)}条用例7项必填字段完整" if not issues else f"{len(issues)}个字段缺失",
        "issues": issues[:20],
    }

def _p7_check_c2(cases):
    """C2 步骤-结果数量对应 [分级]: ±1=INFO, ±2=WARNING, >=3=BLOCK"""
    import re as _re
    block_issues, warn_issues, info_issues = [], [], []
    for c in cases:
        steps = _get_case_field(c, "steps", "")
        expected = _get_case_field(c, "expected_results", "")
        s_lines = [l for l in steps.split('\n') if l.strip() and _re.match(r'^\d+\.', l.strip())]
        e_lines = [l for l in expected.split('\n') if l.strip() and _re.match(r'^\d+\.', l.strip())]
        diff = abs(len(s_lines) - len(e_lines))
        cid = _get_case_field(c, "case_id", "?")
        if diff >= 3:
            block_issues.append({"case_id": cid, "steps": len(s_lines), "expected": len(e_lines), "diff": diff})
        elif diff == 2:
            warn_issues.append({"case_id": cid, "steps": len(s_lines), "expected": len(e_lines), "diff": diff})
        elif diff == 1:
            info_issues.append({"case_id": cid, "steps": len(s_lines), "expected": len(e_lines), "diff": diff})
    if block_issues:
        status = "FAILED"
    elif warn_issues:
        status = "WARNING"
    else:
        status = "PASSED"
    return {
        "check_id": "C2", "name": "步骤-结果数量对应", "level": "BLOCK",
        "status": status,
        "detail": f"差≥3:{len(block_issues)}条, 差2:{len(warn_issues)}条, 差1:{len(info_issues)}条(INFO)",
        "issues": block_issues[:10] + warn_issues[:10],
        "info_count": len(info_issues),
    }

def _p7_check_c3(cases):
    """C3 P0占比 [WARNING/BLOCK]: ≤20%通过, 20-40%警告, >40%阻塞"""
    total = len(cases)
    p0 = sum(1 for c in cases if _get_case_field(c, "priority", "").upper() in ("P0", "HIGHEST"))
    ratio = p0 / max(total, 1)
    if ratio > 0.40:
        status = "FAILED"
    elif ratio > 0.20:
        status = "WARNING"
    else:
        status = "PASSED"
    return {
        "check_id": "C3", "name": "P0占比", "level": "WARNING",
        "status": status,
        "detail": f"P0={p0}/{total}({ratio:.1%})",
        "issues": [],
    }

def _p7_check_c4(cases):
    """C4 冒烟占比 [WARNING]: 按总数分档校验"""
    total = len(cases)
    smoke = sum(1 for c in cases if _is_smoke(_get_case_field(c, "is_smoke", "")))
    ratio = smoke / max(total, 1)
    if total <= 15:
        lo, hi = 0.20, 0.35
    elif total <= 30:
        lo, hi = 0.15, 0.25
    else:
        lo, hi = 0.10, 0.20
    if ratio < lo or ratio > hi:
        status = "WARNING"
    else:
        status = "PASSED"
    return {
        "check_id": "C4", "name": "冒烟占比", "level": "WARNING",
        "status": status,
        "detail": f"冒烟={smoke}/{total}({ratio:.1%}), 期望{lo:.0%}-{hi:.0%}",
        "issues": [],
    }

def _p7_check_c5(cases):
    """C5 步骤描述质量 [WARNING]: 上下文感知正则"""
    import re as _re
    VAGUE_NOUNS = {'数据', '结果', '页面', '功能', '状态', '信息', '内容', '格式'}
    issues = []
    for c in cases:
        steps = _get_case_field(c, "steps", "")
        lines = [l.strip() for l in steps.split('\n') if _re.match(r'^\d+\.', l.strip())]
        for line in lines:
            m = _re.match(r'^\d+\.\s*(验证|检查|确认)\s*(.*)$', line)
            if m:
                verb, rest = m.group(1), m.group(2).strip()
                # 放行：有判断词
                if _re.search(r'是否|能否|有无|包含|显示为|等于|大于|小于|超出|不足', rest):
                    continue
                # 放行：去掉模糊名词后仍有内容
                cleaned = rest
                for vn in VAGUE_NOUNS:
                    cleaned = cleaned.replace(vn, '')
                cleaned = _re.sub(r'[正确正常无误成功]', '', cleaned).strip()
                if len(cleaned) >= 2:
                    continue
                issues.append({"case_id": _get_case_field(c, "case_id", "?"), "line": line[:80], "verb": verb})
    ratio = len(issues) / max(len(cases), 1)
    return {
        "check_id": "C5", "name": "步骤描述质量", "level": "WARNING",
        "status": "WARNING" if ratio > 0.30 else "PASSED",
        "detail": f"{len(issues)}/{len(cases)}条含模糊动词({ratio:.1%})",
        "issues": issues[:15],
    }

def _p7_check_c6(cases):
    """C6 期望结果质量 [WARNING]: 负向模式正则"""
    import re as _re
    VAGUE_PATTERNS = [
        r'(?:操作|执行|处理|加载|保存|删除|修改|提交)(?:成功|正确|正常)\s*$',
        r'(?:显示|展示|呈现)(?:正确|正常|无误)\s*$',
        r'符合预期\s*$',
        r'(?:数据|结果|内容|信息)(?:正确|正常|无误)\s*$',
        r'(?:功能|模块|接口)(?:正常|可用)\s*$',
        r'(?:验证|校验)(?:通过|成功)\s*$',
    ]
    issues = []
    for c in cases:
        expected = _get_case_field(c, "expected_results", "")
        lines = [l.strip() for l in expected.split('\n') if _re.match(r'^\d+\.', l.strip())]
        for line in lines:
            for pattern in VAGUE_PATTERNS:
                if _re.search(pattern, line):
                    issues.append({"case_id": _get_case_field(c, "case_id", "?"), "line": line[:80]})
                    break
    ratio = len(issues) / max(len(cases), 1)
    return {
        "check_id": "C6", "name": "期望结果质量", "level": "WARNING",
        "status": "WARNING" if ratio > 0.30 else "PASSED",
        "detail": f"{len(issues)}/{len(cases)}条含模糊描述({ratio:.1%})",
        "issues": issues[:15],
    }

def _p7_check_c61(cases):
    """C6.1 前置条件三要素 [BLOCK]: 账号/权限 + 数据构造 + 环境配置"""
    import re as _re
    KW_ACCOUNT = _re.compile(r'账号|权限|登录|用户|角色')
    KW_DATA = _re.compile(r'数据|预置|构造|预设|测试数据|造数')
    KW_ENV = _re.compile(r'环境|系统|配置|服务|运行|部署')
    issues = []
    for c in cases:
        precond = _get_case_field(c, "preconditions", "")
        missing = []
        if not KW_ACCOUNT.search(precond):
            missing.append('账号/权限')
        if not KW_DATA.search(precond):
            missing.append('数据构造')
        if not KW_ENV.search(precond):
            missing.append('环境配置')
        if missing:
            issues.append({"case_id": _get_case_field(c, "case_id", "?"), "missing": missing})
    return {
        "check_id": "C6.1", "name": "前置条件三要素", "level": "BLOCK",
        "status": "FAILED" if issues else "PASSED",
        "detail": f"{len(issues)}/{len(cases)}条前置条件不完整" if issues else f"{len(cases)}条前置条件均含三要素",
        "issues": issues[:20],
    }

def _p7_check_c7(cases, p5_test_points):
    """C7 测试点覆盖率 [BLOCK]: P5 active测试点必须100%覆盖"""
    p5_active = set()
    for tp in p5_test_points:
        if tp.get('status', 'active') == 'active':
            p5_active.add(tp.get('id', ''))
    p6_covered = set()
    for c in cases:
        src = _get_case_field(c, "source_test_point", "")
        if not src:
            src = c.get("source_test_point", "")
        if src:
            p6_covered.add(src)
    uncovered = sorted(p5_active - p6_covered)
    rate = len(p6_covered & p5_active) / max(len(p5_active), 1)
    return {
        "check_id": "C7", "name": "测试点覆盖率", "level": "BLOCK",
        "status": "FAILED" if uncovered else "PASSED",
        "detail": f"覆盖{len(p6_covered & p5_active)}/{len(p5_active)}({rate:.0%})",
        "issues": [{"test_point": tp, "issue": "未覆盖"} for tp in uncovered[:20]],
        "coverage_rate": rate,
    }

def _p7_check_c71(cases, p5_test_points):
    """C7.1 语义覆盖 [WARNING]: 业务实体匹配"""
    import re as _re
    # 从P5描述中提取业务实体
    ENTITY_PATTERNS = [
        r'月亮晒|周亮晒|金种子|商机沙盘|海交综服',
        r'个人标杆|分公司综合实力|有效机构[户客]',
        r'重点机构|债融|托管|福建区域',
        r'增量排名|目标完成率',
    ]
    combined_re = _re.compile('|'.join(ENTITY_PATTERNS))
    tp_entities = {}
    for tp in p5_test_points:
        tp_id = tp.get('id', '')
        desc = tp.get('description', '')
        entities = set(combined_re.findall(desc))
        # 补充引号内术语
        quoted = _re.findall(r'[「""\u201c]([^「""\u201d]+)[」""\u201d]', desc)
        entities.update(q for q in quoted if len(q) >= 2)
        tp_entities[tp_id] = entities

    issues = []
    for c in cases:
        src_tp = _get_case_field(c, "source_test_point", "") or c.get("source_test_point", "")
        if src_tp not in tp_entities or not tp_entities[src_tp]:
            continue
        entities = tp_entities[src_tp]
        text = _get_case_field(c, "title", "") + ' ' + _get_case_field(c, "steps", "")
        hit = sum(1 for e in entities if e in text)
        ratio = hit / max(len(entities), 1)
        if ratio < 0.3:
            issues.append({
                "case_id": _get_case_field(c, "case_id", "?"),
                "source_tp": src_tp,
                "hit_ratio": f"{hit}/{len(entities)}",
            })
    return {
        "check_id": "C7.1", "name": "语义覆盖(业务实体)", "level": "WARNING",
        "status": "WARNING" if issues else "PASSED",
        "detail": f"{len(issues)}/{len(cases)}条语义覆盖不足" if issues else "全部用例语义覆盖充分",
        "issues": issues[:15],
    }

def _p7_check_c8(cases):
    """C8 冒烟合规性 [WARNING]: 冒烟用例priority应为P0/P1"""
    issues = []
    for c in cases:
        if _is_smoke(_get_case_field(c, "is_smoke", "")):
            p = _get_case_field(c, "priority", "")
            if p not in ("P0", "P1"):
                issues.append({
                    "case_id": _get_case_field(c, "case_id", "?"),
                    "priority": p,
                    "suggestion": f"建议将priority从{p}升级为P1",
                })
    return {
        "check_id": "C8", "name": "冒烟合规性", "level": "WARNING",
        "status": "WARNING" if issues else "PASSED",
        "detail": f"{len(issues)}条冒烟用例priority不合规" if issues else "冒烟用例priority均为P0/P1",
        "issues": issues,
    }

def _p7_check_c9(cases):
    """C9 伞形用例检测 [WARNING]"""
    import re as _re
    UMBRELLA_RE = _re.compile(r'同上|同理|与.*一致|相应的调整|参照|类似')
    issues = []
    for c in cases:
        title = _get_case_field(c, "title", "")
        steps = _get_case_field(c, "steps", "")
        matches = UMBRELLA_RE.findall(title + ' ' + steps)
        if matches:
            issues.append({
                "case_id": _get_case_field(c, "case_id", "?"),
                "matches": matches[:3],
            })
    return {
        "check_id": "C9", "name": "伞形用例检测", "level": "WARNING",
        "status": "WARNING" if issues else "PASSED",
        "detail": f"{len(issues)}条含伞形表述" if issues else "无伞形用例",
        "issues": issues[:10],
    }

def _p7_statistics(cases):
    """INFO级统计指标"""
    from collections import Counter as _Counter
    priorities = _Counter(_get_case_field(c, "priority", "unknown") for c in cases)
    step_texts = set()
    step_lens = []
    precond_lens = []
    title_counter = _Counter()
    for c in cases:
        s = _get_case_field(c, "steps", "")
        step_texts.add(s.strip())
        step_lens.append(len(s))
        precond_lens.append(len(_get_case_field(c, "preconditions", "")))
        title_counter[_get_case_field(c, "title", "")] += 1
    dup_titles = {t: cnt for t, cnt in title_counter.items() if cnt > 1}
    return {
        "total_cases": len(cases),
        "priority_distribution": dict(priorities),
        "smoke_count": sum(1 for c in cases if _is_smoke(_get_case_field(c, "is_smoke", ""))),
        "step_uniqueness": len(step_texts) / max(len(cases), 1),
        "avg_step_length": sum(step_lens) / max(len(step_lens), 1),
        "avg_precondition_length": sum(precond_lens) / max(len(precond_lens), 1),
        "duplicate_titles": len(dup_titles),
        "duplicate_title_samples": list(dup_titles.keys())[:5],
    }

def _generate_p7_html_report(checks, statistics, output_path):
    """生成P7质量报告HTML"""
    status_icon = {"PASSED": "✅", "FAILED": "❌", "WARNING": "⚠️"}
    status_color = {"PASSED": "#27ae60", "FAILED": "#e74c3c", "WARNING": "#f39c12"}
    checks_html = ""
    for ck in checks:
        color = status_color.get(ck["status"], "#999")
        icon = status_icon.get(ck["status"], "")
        issues_html = ""
        if ck.get("issues"):
            issues_html = "<ul>" + "".join(f"<li>{json.dumps(i, ensure_ascii=False)[:200]}</li>" for i in ck["issues"][:10]) + "</ul>"
        checks_html += f"""<tr>
            <td>{ck['check_id']}</td><td>{ck['name']}</td><td>{ck['level']}</td>
            <td style="color:{color};font-weight:bold;">{icon} {ck['status']}</td>
            <td>{ck['detail']}</td></tr>"""
        if issues_html:
            checks_html += f"<tr><td colspan='5' style='background:#fafafa;padding-left:40px;'>{issues_html}</td></tr>"

    pri = statistics.get("priority_distribution", {})
    total = statistics.get("total_cases", 0)
    smoke = statistics.get("smoke_count", 0)

    html = f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">
<title>P7 Quality Report</title>
<style>
body{{font-family:-apple-system,sans-serif;background:#f5f7fa;padding:20px;color:#333;line-height:1.6;}}
.container{{max-width:960px;margin:0 auto;}}
h1{{font-size:22px;color:#1a1a2e;}}
.card{{background:#fff;border-radius:10px;padding:20px;margin:16px 0;box-shadow:0 2px 6px rgba(0,0,0,0.05);}}
table{{width:100%;border-collapse:collapse;font-size:13px;}}
th{{background:#f8f9fb;padding:8px 10px;text-align:left;border-bottom:2px solid #e8ecf1;}}
td{{padding:8px 10px;border-bottom:1px solid #f0f0f0;}}
.metric{{display:inline-block;text-align:center;padding:10px 16px;margin:4px;background:#f8f9fb;border-radius:6px;}}
.metric .v{{font-size:24px;font-weight:700;color:#1a1a2e;}}
.metric .l{{font-size:11px;color:#888;}}
ul{{margin:4px 0;padding-left:20px;font-size:12px;color:#666;}}
</style></head><body><div class="container">
<h1>🐈‍⬛ P7 Quality Report</h1>
<p style="color:#666;font-size:13px;">Generated by p7_code_check V3.3.1</p>
<div class="card">
<div class="metric"><div class="v">{total}</div><div class="l">总用例</div></div>
<div class="metric"><div class="v">{smoke}</div><div class="l">冒烟用例</div></div>
<div class="metric"><div class="v">{statistics.get('step_uniqueness',0):.0%}</div><div class="l">步骤唯一率</div></div>
<div class="metric"><div class="v">{pri.get('P0',0)}/{pri.get('P1',0)}/{pri.get('P2',0)}/{pri.get('P3',0)}</div><div class="l">P0/P1/P2/P3</div></div>
</div>
<div class="card"><h2>校验结果</h2>
<table><tr><th>ID</th><th>校验项</th><th>级别</th><th>状态</th><th>详情</th></tr>
{checks_html}</table></div>
</div></body></html>"""
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)


def action_p7_code_check(args):
    """V3.3.1: P7代码硬校验，替代Agent审计。
    
    纯代码执行C1-C9+C7.1全部校验，零Agent依赖，秒级完成。
    读取p5_output.json和p6_output.json，输出p7_output.json + P7.pass.json + p7_report.html
    """
    data_dir = args.data_dir
    task_id = args.task_id

    # 前置gate校验
    ok, msg = check_gate(data_dir, "P6", task_id)
    if not ok:
        print(json.dumps({"status": "gate_blocked", "step": "P6", "reason": msg}))
        sys.exit(1)

    # 读取P5和P6产出
    p5_path = os.path.join(data_dir, "p5_output.json")
    p6_path = os.path.join(data_dir, "p6_output.json")
    if not os.path.exists(p5_path):
        print(json.dumps({"status": "error", "reason": "p5_output.json不存在"}))
        sys.exit(1)
    if not os.path.exists(p6_path):
        print(json.dumps({"status": "error", "reason": "p6_output.json不存在"}))
        sys.exit(1)

    p5_data = _read_json(p5_path)
    p6_data = _read_json(p6_path)
    cases = p6_data.get("testcases", [])
    p5_tps = p5_data.get("test_points", [])

    if not cases:
        print(json.dumps({"status": "error", "reason": "p6_output.json中testcases为空"}))
        sys.exit(1)

    # 执行全部校验
    checks = [
        _p7_check_c1(cases),
        _p7_check_c2(cases),
        _p7_check_c3(cases),
        _p7_check_c4(cases),
        _p7_check_c5(cases),
        _p7_check_c6(cases),
        _p7_check_c61(cases),
        _p7_check_c7(cases, p5_tps),
        _p7_check_c71(cases, p5_tps),
        _p7_check_c8(cases),
        _p7_check_c9(cases),
    ]
    statistics = _p7_statistics(cases)

    # 判定门禁
    block_failed = any(ck["status"] == "FAILED" and ck["level"] == "BLOCK" for ck in checks)
    has_warning = any(ck["status"] in ("WARNING", "FAILED") and ck["level"] == "WARNING" for ck in checks)

    if block_failed:
        gate_status = "FAIL"
        action_required = "RETRY_P6"
        failed_cases = []
        for ck in checks:
            if ck["status"] == "FAILED":
                for iss in ck.get("issues", []):
                    fc = {"check_id": ck["check_id"], "case_id": iss.get("case_id", ""), "field": iss.get("field", "")}
                    fc.update(iss)
                    failed_cases.append(fc)
    elif has_warning:
        gate_status = "PASS"
        action_required = "MANUAL_REVIEW"
        failed_cases = []
    else:
        gate_status = "PASS"
        action_required = "NONE"
        failed_cases = []

    block_passed = sum(1 for ck in checks if ck["level"] == "BLOCK" and ck["status"] == "PASSED")
    block_total = sum(1 for ck in checks if ck["level"] == "BLOCK")
    warn_triggered = sum(1 for ck in checks if ck["level"] == "WARNING" and ck["status"] in ("WARNING", "FAILED"))
    warn_total = sum(1 for ck in checks if ck["level"] == "WARNING")

    summary = f"{len(checks)}项检查: BLOCK {block_passed}/{block_total}通过, WARNING {warn_triggered}/{warn_total}项触发"

    # 构造输出
    p7_output = {
        "schema_version": "2.0.0",
        "source": "p7_code_check",
        "gate_result": {
            "status": gate_status,
            "summary": summary,
            "checks": checks,
        },
        "statistics": statistics,
        "p7_check_summary": {
            "status": gate_status,
            "checked_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
            "block_passed": block_passed,
            "block_total": block_total,
            "warnings": warn_triggered,
            "source": "p7_code_check",
        },
        "action_required": action_required,
        "failed_cases": failed_cases[:50],
    }

    # 写入p7_output.json
    p7_out_path = os.path.join(data_dir, "p7_output.json")
    _write_json(p7_out_path, p7_output)

    # 生成HTML报告
    html_path = os.path.join(data_dir, "p7_report.html")
    _generate_p7_html_report(checks, statistics, html_path)

    # 写gate pass（仅PASS时）
    if gate_status == "PASS":
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete("P7")
        gate_dir = os.path.join(data_dir, "gates")
        _ensure_dir(gate_dir)
        gate_path = os.path.join(gate_dir, "P7.pass.json")
        gate_data = {
            "step": "P7",
            "status": "PASS",
            "task_id": task_id,
            "source": "p7_code_check",
            "summary": summary,
            "validated_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        }
        _write_signed_gate(gate_path, gate_data, task_id)

    print(json.dumps({
        "status": "ok" if gate_status == "PASS" else "quality_failed",
        "gate_result": gate_status,
        "summary": summary,
        "action_required": action_required,
        "block_checks": f"{block_passed}/{block_total}",
        "warnings": warn_triggered,
        "p7_output": p7_out_path,
        "html_report": html_path,
    }))
    if gate_status != "PASS":
        sys.exit(1)





def action_quality_check(args):
    """对指定步骤的产出进行质量校验"""
    data_dir = args.data_dir
    step = args.step

    output_path = os.path.join(data_dir, f"{step.lower()}_output.json")
    if not os.path.exists(output_path):
        print(json.dumps({"status": "error", "reason": f"{step}产出文件不存在"}))
        sys.exit(1)

    data = _read_json(output_path)
    issues = []
    warnings = []

    # 1. 最小产出数量校验
    if step in MIN_OUTPUT_COUNTS:
        for field_path, min_count in MIN_OUTPUT_COUNTS[step].items():
            value = _get_nested(data, field_path)
            if value is None:
                issues.append(f"字段{field_path}不存在")
            elif isinstance(value, list) and len(value) < min_count:
                issues.append(f"{field_path}数量{len(value)}<最小要求{min_count}")
            elif isinstance(value, (int, float)) and value < min_count:
                issues.append(f"{field_path}值{value}<最小要求{min_count}")

    # 2. P0质量评分校验
    if step == "P0":
        score = data.get("quality_score", 0)
        if score < 0.5:
            issues.append(f"质量评分{score}<0.5，需求结构化质量太低")
        elif score < 0.7:
            warnings.append(f"质量评分{score}<0.7，建议补充需求")

    # 2.5 V3.2.8: P2测试点数量动态校验 = max(8, P1叶节点数×2)
    if step == "P2":
        test_points = data.get("test_points", [])
        p2_count = len(test_points) if isinstance(test_points, list) else 0
        p1_path = os.path.join(data_dir, "p1_output.json")
        p2_dynamic_min = 8
        if os.path.exists(p1_path):
            try:
                p1_data = _read_json(p1_path)
                # 计算P1叶节点数（场景数）
                ft = p1_data.get("feature_tree", {})
                modules = ft.get("modules", p1_data.get("modules", []))
                leaf_count = 0
                for m in (modules if isinstance(modules, list) else []):
                    features = m.get("features", [])
                    for f in (features if isinstance(features, list) else []):
                        scenarios = f.get("scenarios", [])
                        leaf_count += len(scenarios) if isinstance(scenarios, list) else 1
                    if not features:
                        leaf_count += 1  # 模块本身算一个叶节点
                p2_dynamic_min = max(8, leaf_count * 2)
            except Exception:
                pass
        if p2_count < p2_dynamic_min:
            issues.append(f"测试点数量{p2_count}<最低要求{p2_dynamic_min}（P1叶节点×2），每个场景应至少生成2个测试点")

    # 3. P6用例质量校验（V3.2.4: 使用_get_case_field兼容fields嵌套结构）
    if step == "P6":
        cases = data.get("testcases", [])
        total = len(cases)

        # V3.2.8: 动态计算P6最低用例数
        # 优先用P5的total_expected_cases（基于complexity标签精确计算）
        # 其次用P5测试点数×1.5（V3.2.7兼容）
        # 底线15
        p5_min = 15
        p5_path = os.path.join(data_dir, "p5_output.json")
        if os.path.exists(p5_path):
            try:
                p5_data = _read_json(p5_path)
                p5_count = len(p5_data.get("test_points", []))
                # V3.2.8: 优先用complexity标签的精确预算
                total_expected = p5_data.get("coverage_summary", {}).get("total_expected_cases", 0)
                if total_expected > 0:
                    p5_min = max(15, total_expected)
                else:
                    p5_min = max(15, int(p5_count * 1.5))
            except Exception:
                pass
        if total < p5_min:
            issues.append(f"用例数量{total}<最低要求{p5_min}（P5测试点×1.5），每个测试点应至少展开为2条用例")

        if total > 0:
            smoke = sum(1 for c in cases if _is_smoke(_get_case_field(c, "is_smoke", "")))
            p0 = sum(1 for c in cases if _get_case_field(c, "priority", "").upper() in ("P0", "HIGHEST"))

            smoke_ratio = smoke / total
            p0_ratio = p0 / total

            # 冒烟比例超限→拒绝（与prep_prompt注入规则一致）
            if smoke_ratio < P6_QUALITY_RULES["smoke_ratio_min"]:
                issues.append(f"冒烟用例比例{smoke_ratio:.1%}<{P6_QUALITY_RULES['smoke_ratio_min']:.0%}，不达标")
            if smoke_ratio > P6_QUALITY_RULES["smoke_ratio_max"]:
                issues.append(f"冒烟用例比例{smoke_ratio:.1%}>{P6_QUALITY_RULES['smoke_ratio_max']:.0%}，过高")
            if p0_ratio > P6_QUALITY_RULES["p0_ratio_max"]:
                issues.append(f"P0优先级占比{p0_ratio:.1%}>{P6_QUALITY_RULES['p0_ratio_max']:.0%}，优先级分布异常")

            # 检查是否所有用例同一优先级
            priorities = set(_get_case_field(c, "priority", "") for c in cases)
            if len(priorities) == 1 and total > 5:
                issues.append(f"所有{total}条用例都是{priorities.pop()}优先级，分布异常")

            # 每需求至少1条冒烟用例（与prep_prompt注入规则一致）
            if P6_QUALITY_RULES.get("per_requirement_smoke"):
                req_smoke = {}
                for c in cases:
                    req = _get_case_field(c, "requirement", _get_case_field(c, "module", "unknown"))
                    if req not in req_smoke:
                        req_smoke[req] = False
                    if _is_smoke(_get_case_field(c, "is_smoke", "")):
                        req_smoke[req] = True
                no_smoke_reqs = [r for r, has in req_smoke.items() if not has]
                if no_smoke_reqs and len(req_smoke) > 1:
                    warnings.append(f"{len(no_smoke_reqs)}个需求无冒烟用例: {', '.join(no_smoke_reqs[:3])}")

    passed = len(issues) == 0
    # P7失败时提供回流指引
    retry_hint = None
    if not passed and step == "P7":
        retry_hint = "P7质量自检失败，建议重新执行P6用例展开（从 prep_prompt P6 重新开始）"
    if not passed and step == "P6":
        retry_hint = "P6质量校验失败，建议重新执行P6全部批次"

    # V3.2.4新增：quality_check通过后自动创建gate文件，不再需要Agent手动创建
    # V3.2.6: 使用HMAC签名
    if passed and step in GATE_STEPS:
        task_id = args.task_id
        gate_dir = os.path.join(data_dir, "gates")
        _ensure_dir(gate_dir)
        gate_path = os.path.join(gate_dir, f"{step}.pass.json")
        if not os.path.exists(gate_path):
            gate_data = {
                "task_id": task_id,
                "step": step,
                "status": "PASS",
                "source": "quality_check",
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
            }
            _write_signed_gate(gate_path, gate_data, task_id)

    print(json.dumps({
        "status": "ok" if passed else "quality_failed",
        "step": step,
        "passed": passed,
        "issues": issues,
        "warnings": warnings,
        "retry_hint": retry_hint,
        "gate_created": passed and step in GATE_STEPS,
    }))
    if not passed:
        sys.exit(1)


# ============================================================
# 主入口
# ============================================================


# ============================================================
# Action: check_image_api (验证图片理解API密码)
# ============================================================

def action_check_image_api(args):
    """验证用户输入的API密码是否正确"""
    skill_dir = args.skill_dir
    api_key = getattr(args, 'api_key', '') or ''

    if not api_key.strip():
        print(json.dumps({"status": "skipped", "reason": "未输入密码，将使用纯文本模式"}))
        return

    config = _load_image_api_config(skill_dir, api_key=api_key)

    if not config["enabled"]:
        reason = config.get("_invalid_reason", "API地址未配置")
        print(json.dumps({"status": "error", "reason": reason}))
        return

    # V3.0.3-patch1: 调用auth-check验证密码（不再用health，因为health不鉴权）
    ok, data = _check_image_api_health(config)

    if ok:
        # V3.2.0: 验证成功后缓存密码到task目录（解决Agent跨段落丢密码问题）
        # 密码只在当前task生命周期内有效，不会泄露到其他任务
        data_dir = getattr(args, 'data_dir', '') or ''
        if data_dir and os.path.isdir(data_dir):
            cache_path = os.path.join(data_dir, ".image_api_key")
            try:
                with open(cache_path, "w") as f:
                    f.write(api_key)
                os.chmod(cache_path, 0o600)  # 只有owner可读写
            except Exception:
                pass  # 缓存失败不阻塞流程
        print(json.dumps({
            "status": "ok",
            "message": "密码验证成功，图片理解API已启用",
            "provider": config["model"],
            "ci_configured": data.get("ci_configured", True),
            "qwen_configured": data.get("qwen_configured", False),
            "key_cached": bool(data_dir),
        }))
    else:
        error = data.get("error", "unknown")
        message = data.get("message", "")
        # 精确区分密码错误/服务未配置/服务不可用
        if error == "auth_failed":
            print(json.dumps({"status": "auth_failed", "reason": "密码错误，请重新输入或回复「跳过」使用纯文本模式"}))
        elif error == "service_not_configured":
            print(json.dumps({"status": "service_error", "reason": f"API服务未配置密码验证: {message}"}))
        elif error == "connection_failed":
            print(json.dumps({"status": "service_error", "reason": f"无法连接API服务，请检查API地址: {message}"}))
        elif error == "timeout":
            print(json.dumps({"status": "service_error", "reason": "API服务响应超时，请稍后重试"}))
        else:
            print(json.dumps({"status": "service_error", "reason": f"API服务暂不可用: {message or error}"}))


# ============================================================
# Action: restart_from (从指定步骤重新开始)
# ============================================================

def action_restart_from(args):
    """从指定步骤重新开始：清除该步及后续的gate pass和output"""
    data_dir = args.data_dir
    task_id = args.task_id
    step = args.step.upper()

    if step not in GATE_STEPS:
        print(json.dumps({"status": "error", "reason": f"无效步骤: {step}，可选: {GATE_STEPS}"}))
        sys.exit(1)

    # 找到该步骤及后续所有步骤
    step_idx = GATE_STEPS.index(step)
    steps_to_clear = GATE_STEPS[step_idx:]

    gates_dir = os.path.join(data_dir, "gates")
    cleared = []
    for s in steps_to_clear:
        # 清除gate pass
        gp = os.path.join(gates_dir, f"{s}.pass.json")
        if os.path.exists(gp):
            os.remove(gp)
            cleared.append(f"{s}.pass.json")
        # 清除output
        for suffix in ["_output.json", "_output.tmp.json", "_output.prev.json"]:
            op = os.path.join(data_dir, f"{s.lower()}{suffix}")
            if os.path.exists(op):
                os.remove(op)
                cleared.append(f"{s.lower()}{suffix}")

    # 更新state
    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.state["completed_steps"] = [s for s in state.state["completed_steps"] if s not in [st.lower() for st in steps_to_clear] and s not in steps_to_clear]
    state.save()

    print(json.dumps({
        "status": "ok",
        "restart_from": step,
        "cleared_files": cleared,
        "next_step": step,
    }))


def main():
    parser = argparse.ArgumentParser(description="V3.0 Orchestrator")
    parser.add_argument("--action", required=True, choices=[
        "init", "onboarding", "step0", "step0_8_prep", "step0_8_save",
        "step_run", "step7_export", "status", "resume",
        "prep_prompt", "p2_code_generate", "p5_code_merge", "p6_batch_info", "p6_save_batch", "p6_merge",
        "quality_check", "p7_code_check",
        "restart_from", "check_image_api"
    ])
    parser.add_argument("--skill-dir", default="")
    parser.add_argument("--data-dir", default="")
    parser.add_argument("--task-id", default="")
    parser.add_argument("--requirement-text", default="")
    parser.add_argument("--requirement-file", default="")
    parser.add_argument("--step", default="")
    parser.add_argument("--agent-output", default="")  # 兼容保留，优先从文件读
    parser.add_argument("--results-json", default="")  # 兼容保留，优先从文件读
    parser.add_argument("--batch-index", default="0")
    parser.add_argument("--api-key", default="", help="图片理解API密钥（Onboarding时用户输入，不落盘）")

    args = parser.parse_args()

    # === V3.0.0-patch3: 参数自动化 ===
    # 1. skill_dir自动发现
    try:
        args.skill_dir = resolve_skill_dir(args.skill_dir)
    except ValueError as e:
        print(json.dumps({"status": "error", "reason": str(e)}))
        sys.exit(1)

    # 2. data_dir/task_id自动回填（非init action时）
    if args.action != "init":
        if not args.data_dir or not args.task_id:
            auto_tid, auto_dir = find_latest_task()
            if auto_tid and auto_dir:
                if not args.task_id:
                    args.task_id = auto_tid
                if not args.data_dir:
                    args.data_dir = auto_dir
            else:
                if args.action not in ("status",):
                    print(json.dumps({"status": "error", "reason": "未找到活跃任务，请先执行 --action init"}))
                    sys.exit(1)

    # 3. agent-output从文件读取（优先级：文件 > 命令行参数）
    if args.action in ("step_run", "p6_save_batch") and not args.agent_output:
        step = args.step or "unknown"
        if args.action == "p6_save_batch":
            batch_idx = int(args.batch_index) if args.batch_index else 1
            agent_file = os.path.join(args.data_dir, f"p6_batch_{batch_idx:03d}_agent_output.json")
        else:
            agent_file = os.path.join(args.data_dir, f"{step.lower()}_agent_output.json")
        if os.path.exists(agent_file):
            args.agent_output = _read_file_safe(agent_file, 100000)

    # 4. results-json从文件读取
    if args.action == "step0_8_save" and not args.results_json:
        results_file = os.path.join(args.data_dir, "px_agent_results.json")
        if os.path.exists(results_file):
            args.results_json = _read_file_safe(results_file, 100000)

    actions = {
        "init": action_init,
        "onboarding": action_onboarding,
        "step0": action_step0,
        "step0_8_prep": action_step0_8_prep,
        "step0_8_save": action_step0_8_save,
        "step_run": action_step_run,
        "step7_export": action_step7_export,
        "status": action_status,
        "resume": action_resume,
        "prep_prompt": action_prep_prompt,
        "p2_code_generate": action_p2_code_generate,
        "p5_code_merge": action_p5_code_merge,
        "p6_batch_info": action_p6_batch_info,
        "p6_save_batch": action_p6_save_batch,
        "p6_merge": action_p6_merge,
        "quality_check": action_quality_check,
        "p7_code_check": action_p7_code_check,
        "restart_from": action_restart_from,
        "check_image_api": action_check_image_api,
    }

    try:
        actions[args.action](args)
    except SystemExit:
        raise
    except Exception as e:
        print(json.dumps({"status": "error", "reason": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
