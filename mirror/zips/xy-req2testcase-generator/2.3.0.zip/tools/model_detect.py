#!/usr/bin/env python3
"""
T1-02：模型能力探测模块 model_detect.py
探测当前运行模型的图片理解能力，决定走视觉/OCR/纯文本模式。

功能：
- 前缀匹配 + 大小写归一化 + 最长前缀优先
- 内置表 knowledge/model_vision_capability.json
- 用户覆盖 user_knowledge/model_vision_override.json
- 运行时探测协议（生成测试图 → 传入模型 → 判定）
- 探测结果任务级缓存
- 探测失败默认走 OCR 模式

依赖：Pillow（运行时探测生成测试图，可选）
"""

import json
import os
import time
import subprocess
import tempfile
from typing import Optional, Dict, Any
from pathlib import Path


# ============================================================
# 默认路径
# ============================================================

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_SKILL_DIR = os.path.dirname(_SCRIPT_DIR)
_BUILTIN_TABLE_PATH = os.path.join(_SKILL_DIR, 'knowledge', 'model_vision_capability.json')
_USER_OVERRIDE_PATH = os.path.join(_SKILL_DIR, 'user_knowledge', 'model_vision_override.json')


# ============================================================
# 探测结果数据结构
# ============================================================

def _make_result(model_id: str, vision_supported: bool,
                 detection_method: str, matched_prefix: str = None,
                 source: str = "unknown", **extra) -> dict:
    """构造标准探测结果"""
    result = {
        "model_capability": {
            "model_id": model_id,
            "vision_supported": vision_supported,
            "detection_method": detection_method,
            "detection_time": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        }
    }
    if matched_prefix:
        result["model_capability"]["matched_prefix"] = matched_prefix
    if source:
        result["model_capability"]["source"] = source
    result["model_capability"].update(extra)
    return result


# ============================================================
# 核心探测器
# ============================================================

class ModelCapabilityDetector:
    """
    模型视觉能力探测器。
    优先级：用户覆盖 > 内置表 > 运行时探测。
    """

    def __init__(self,
                 builtin_table_path: str = None,
                 user_override_path: str = None,
                 model_caller=None):
        """
        Args:
            builtin_table_path: 内置模型能力表路径
            user_override_path: 用户覆盖表路径
            model_caller: 可选的模型调用函数，签名 fn(prompt, image_path) -> str
                          用于运行时探测。如果不提供，运行时探测将跳过。
        """
        self.builtin = self._load_json(builtin_table_path or _BUILTIN_TABLE_PATH)
        self.user_override = self._load_json(user_override_path or _USER_OVERRIDE_PATH)
        self.model_caller = model_caller
        self._cache: Dict[str, dict] = {}  # 任务级缓存

    @staticmethod
    def _load_json(path: str) -> dict:
        """安全加载 JSON 文件"""
        if os.path.exists(path):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return {}

    def _prefix_match(self, model_id: str, models_dict: dict) -> Optional[tuple]:
        """
        前缀匹配：大小写归一化 + 最长前缀优先。
        返回 (matched_prefix, value_dict) 或 None。
        """
        model_id_lower = model_id.lower()
        best_match = None
        best_len = 0

        for prefix, value in models_dict.items():
            prefix_lower = prefix.lower()
            if model_id_lower.startswith(prefix_lower) and len(prefix_lower) > best_len:
                best_match = (prefix, value)
                best_len = len(prefix_lower)

        return best_match

    def _generate_probe_image(self) -> Optional[str]:
        """
        生成运行时探测用的测试图片（200x100，白底黑字"测试"）。
        返回临时文件路径，调用方负责清理。
        """
        try:
            from PIL import Image, ImageDraw, ImageFont
            img = Image.new('RGB', (200, 100), 'white')
            draw = ImageDraw.Draw(img)
            # 尝试使用系统字体，失败则用默认字体
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 36)
            except (IOError, OSError):
                try:
                    font = ImageFont.truetype("/System/Library/Fonts/PingFang.ttc", 36)
                except (IOError, OSError):
                    font = ImageFont.load_default()
            draw.text((50, 25), "测试", fill='black', font=font)

            tmp = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
            img.save(tmp.name, 'PNG')
            return tmp.name
        except ImportError:
            # Pillow 不可用，尝试用 subprocess 生成
            return None

    def _runtime_probe(self, model_id: str) -> dict:
        """
        运行时探测：生成测试图 → 传入模型 → 判定。
        探测失败默认走 OCR 模式（vision_supported=False）。
        """
        if self.model_caller is None:
            # 无模型调用能力，默认不支持视觉
            return _make_result(
                model_id, False, "runtime_probe_skipped",
                source="runtime",
                reason="no model_caller provided, defaulting to OCR mode"
            )

        probe_image = self._generate_probe_image()
        if probe_image is None:
            return _make_result(
                model_id, False, "runtime_probe_failed",
                source="runtime",
                reason="failed to generate probe image (Pillow not available)"
            )

        try:
            # 调用模型，超时 10 秒
            prompt = "请描述这张图片中的文字内容"
            response = self.model_caller(prompt, probe_image)

            # 判定：返回包含"测试"则支持视觉
            if response and "测试" in response:
                return _make_result(
                    model_id, True, "runtime_probe",
                    source="runtime"
                )
            else:
                return _make_result(
                    model_id, False, "runtime_probe",
                    source="runtime",
                    reason="model did not recognize text in probe image"
                )
        except Exception as e:
            # 探测失败，默认走 OCR 模式
            return _make_result(
                model_id, False, "runtime_probe_failed",
                source="runtime",
                reason=f"probe error: {str(e)}"
            )
        finally:
            # 清理临时文件
            if probe_image and os.path.exists(probe_image):
                os.unlink(probe_image)

    def detect(self, model_id: str) -> dict:
        """
        完整探测流程（带缓存）。
        优先级：缓存 > 用户覆盖 > 内置表 > 运行时探测。

        Args:
            model_id: 模型标识字符串

        Returns:
            标准探测结果 dict，包含 model_capability 字段
        """
        # 缓存命中
        if model_id in self._cache:
            return self._cache[model_id]

        result = self._detect_internal(model_id)
        self._cache[model_id] = result
        return result

    def _detect_internal(self, model_id: str) -> dict:
        """内部探测逻辑（不含缓存）"""
        if not model_id:
            return _make_result(
                model_id or "", False, "empty_model_id",
                source="default",
                reason="empty model_id, defaulting to no vision"
            )

        # 1. 用户覆盖表
        user_models = self.user_override.get("models", {})
        user_match = self._prefix_match(model_id, user_models)
        if user_match:
            prefix, value = user_match
            vision = value.get("vision", False)
            if vision == "auto":
                return self._runtime_probe(model_id)
            return _make_result(
                model_id, bool(vision), "metadata",
                matched_prefix=prefix, source="user_override"
            )

        # 2. 内置表
        builtin_models = self.builtin.get("models", {})
        builtin_match = self._prefix_match(model_id, builtin_models)
        if builtin_match:
            prefix, value = builtin_match
            vision = value.get("vision", False)
            if vision == "auto":
                return self._runtime_probe(model_id)
            return _make_result(
                model_id, bool(vision), "metadata",
                matched_prefix=prefix, source="builtin"
            )

        # 3. 未知模型 → 运行时探测
        return self._runtime_probe(model_id)

    def clear_cache(self):
        """清除探测缓存（任务结束时调用）"""
        self._cache.clear()

    def get_cache(self) -> dict:
        """获取当前缓存内容"""
        return dict(self._cache)


# ============================================================
# OCR 可用性检查
# ============================================================

def check_ocr_availability() -> dict:
    """
    检查 OCR 引擎可用性。
    检查顺序：Tesseract CLI → PaddleOCR CLI → EasyOCR → 不可用。

    Returns:
        {
            "ocr_available": bool,
            "ocr_engine": str,  # tesseract / paddleocr / easyocr / none
            "version": str
        }
    """
    # 1. Tesseract CLI
    try:
        result = subprocess.run(
            ['tesseract', '--version'],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            version = result.stdout.strip().split('\n')[0] if result.stdout else \
                      result.stderr.strip().split('\n')[0]
            return {
                "ocr_available": True,
                "ocr_engine": "tesseract",
                "version": version
            }
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # 2. PaddleOCR CLI
    try:
        result = subprocess.run(
            ['paddleocr', '--version'],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            version = result.stdout.strip().split('\n')[0]
            return {
                "ocr_available": True,
                "ocr_engine": "paddleocr",
                "version": version
            }
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # 3. EasyOCR
    try:
        result = subprocess.run(
            ['python3', '-c', 'import easyocr; print(easyocr.__version__)'],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            version = result.stdout.strip()
            return {
                "ocr_available": True,
                "ocr_engine": "easyocr",
                "version": version
            }
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # 4. 不可用
    return {
        "ocr_available": False,
        "ocr_engine": "none",
        "version": ""
    }


# ============================================================
# 路径选择逻辑
# ============================================================

def determine_processing_mode(model_id: str,
                              detector: ModelCapabilityDetector = None,
                              **kwargs) -> dict:
    """
    综合判断处理模式：vision / ocr / context_only。

    Args:
        model_id: 模型标识
        detector: 可选的探测器实例

    Returns:
        {
            "active_mode": "vision" | "ocr" | "context_only",
            "model_capability": {...},
            "ocr_status": {...}
        }
    """
    if detector is None:
        detector = ModelCapabilityDetector(**kwargs)

    # 探测模型能力
    capability = detector.detect(model_id)
    vision_supported = capability["model_capability"]["vision_supported"]

    if vision_supported:
        return {
            "active_mode": "vision",
            "model_capability": capability["model_capability"],
            "ocr_status": None
        }

    # 模型不支持视觉，检查 OCR
    ocr_status = check_ocr_availability()
    if ocr_status["ocr_available"]:
        return {
            "active_mode": "ocr",
            "model_capability": capability["model_capability"],
            "ocr_status": ocr_status
        }

    # OCR 也不可用，纯文本模式
    return {
        "active_mode": "context_only",
        "model_capability": capability["model_capability"],
        "ocr_status": ocr_status
    }


# ============================================================
# 公共接口
# ============================================================

def detect_model_capability(model_id: str,
                            builtin_table_path: str = None,
                            user_override_path: str = None) -> dict:
    """
    探测模型视觉能力的公共接口。

    Args:
        model_id: 模型标识字符串
        builtin_table_path: 内置表路径（可选）
        user_override_path: 用户覆盖表路径（可选）

    Returns:
        model_capability dict
    """
    detector = ModelCapabilityDetector(
        builtin_table_path=builtin_table_path,
        user_override_path=user_override_path
    )
    return detector.detect(model_id)


# ============================================================
# CLI 入口
# ============================================================

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="模型视觉能力探测工具")
    parser.add_argument("model_id", help="模型标识字符串")
    parser.add_argument("--builtin", help="内置能力表路径")
    parser.add_argument("--override", help="用户覆盖表路径")
    parser.add_argument("--check-ocr", action="store_true", help="同时检查 OCR 可用性")
    parser.add_argument("--full-mode", action="store_true", help="输出完整处理模式判断")
    args = parser.parse_args()

    if args.full_mode:
        result = determine_processing_mode(
            args.model_id,
            builtin_table_path=args.builtin,
            user_override_path=args.override
        )
    else:
        result = detect_model_capability(
            args.model_id,
            builtin_table_path=args.builtin,
            user_override_path=args.override
        )

    if args.check_ocr and not args.full_mode:
        result["ocr_status"] = check_ocr_availability()

    print(json.dumps(result, ensure_ascii=False, indent=2))
