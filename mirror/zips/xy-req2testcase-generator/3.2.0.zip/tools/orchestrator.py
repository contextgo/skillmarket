#!/usr/bin/env python3
"""
V3.2.0 Orchestrator — 测试用例生成流程控制器
代码控制流程，Agent只负责生成内容。

用法：
  由SKILL.md指导Agent调用：
  exec: python3 {SKILL_DIR}/tools/orchestrator.py --action <action> [--args ...]

支持的action：
  init          - 初始化任务（创建task_id, DATA_DIR）
  onboarding    - 执行Onboarding检查（环境/Python/路径）
  step0         - 接收需求，写入task_meta
  step0_8_prep  - PX图片抽取+选图（返回待Agent理解的图片列表）
  step0_8_save  - 保存Agent的图片理解结果+调用image_enhance
  step_run      - 执行P0-P7任一步骤（准备prompt输入，校验Agent输出，写文件+guard）
  step7_export  - 调用export_excel.py导出
  status        - 查看当前任务状态
  resume        - 断点续跑（检测已完成步骤，返回下一步）
"""

import argparse
import json
import hashlib
import os
import sys
import time
import subprocess
import glob
from pathlib import Path


# ============================================================
# 常量
# ============================================================

SKILL_VERSION = "3.2.0"
STEPS = ["onboarding", "step0", "step0_8", "P0", "P1", "P2", "P3", "P4", "P5", "P6", "P7", "step7"]
GATE_STEPS = ["onboarding", "P0", "P1", "P2", "P3", "P4", "P5", "P6", "P7"]

# P0必需顶层字段
# === 各步骤必需字段（以云端实际JSON为真源，2026-04-29统一） ===
P0_REQUIRED_FIELDS = ["quality_score", "blocks", "objective"]
P1_REQUIRED_FIELDS = ["feature_tree"]  # 云端实际输出用feature_tree
P3_REQUIRED_FIELDS = ["risk_points"]  # 云端实际输出用risk_points
P4_REQUIRED_FIELDS = ["pci_list"]  # 云端实际输出用pci_list
P5_REQUIRED_FIELDS = ["test_points", "merge_log"]
P6_REQUIRED_FIELDS = ["testcases"]
P7_REQUIRED_FIELDS = ["gate_result"]  # 云端实际输出gate_result，不是quality_check

# 域识别关键词
# ============================================================
# 自动发现 SKILL_DIR（V3.0.0-patch3）
# ============================================================

DEFAULT_SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def resolve_skill_dir(cli_value=""):
    """自动发现skill_dir，带目录完整性校验"""
    candidate = cli_value or DEFAULT_SKILL_DIR
    required_files = [
        os.path.join(candidate, "tools", "export_excel.py"),
        os.path.join(candidate, "tools", "truncation_guard.py"),
        os.path.join(candidate, "prompts", "P0_requirement_structuring.md"),
    ]
    missing = [p for p in required_files if not os.path.exists(p)]
    if missing:
        # 尝试DEFAULT_SKILL_DIR作为兜底
        if cli_value and cli_value != DEFAULT_SKILL_DIR:
            return resolve_skill_dir("")  # 递归用默认值重试
        raise ValueError(f"skill_dir无效({candidate})，缺失: {[os.path.basename(p) for p in missing[:3]]}")
    return candidate


# ============================================================
# 自动发现最近任务（V3.0.0-patch3）
# ============================================================

def find_latest_task():
    """查找最近的未完成任务，返回(task_id, data_dir)或(None, None)"""
    base = os.path.expanduser("~/.openclaw/workspace/data")
    if not os.path.exists(base):
        return None, None
    tasks = sorted(glob.glob(os.path.join(base, "task_*")), reverse=True)
    for task_dir in tasks[:3]:  # 只看最近3个，减少串task风险
        state_path = os.path.join(task_dir, "orchestrator_state.json")
        if os.path.exists(state_path):
            try:
                state = _read_json(state_path)
                tid = state.get("task_id", "")
                # 未完成的任务（没有step7）
                if "step7" not in state.get("completed_steps", []):
                    return tid, task_dir
            except Exception:
                pass
    return None, None


DOMAIN_KEYWORDS = {
    "trade": ["交易", "委托", "撤单", "成交", "清算", "结算", "资金冻结", "T+1"],
    "asset_mgmt": ["资管", "净值", "申赎", "申购", "赎回", "衍生品", "期货", "期权", "保证金"],
    "risk_ctrl": ["风控", "预警", "限额", "合规检查", "风险控制"],
    "crm": ["客户", "跟进", "开户", "KYC", "客户经理", "客户关系"],
    "etrading": ["网上营业厅", "APP", "适当性", "产品推荐", "在线交易", "移动端", "H5"],
    "ops_mgmt": ["运营", "活动", "营销", "后台管理", "数据报表", "统计", "导出"],
    "compliance": ["合规", "证书", "从业", "监管", "报送", "资质", "执照"],
    "it_infra": ["部署", "监控", "服务器", "权限配置", "变更", "IT", "基础设施", "投行", "承销", "IPO"],
}


# ============================================================
# 工具函数
# ============================================================

def _ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def _write_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def _read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _file_exists(path):
    return os.path.exists(path) and os.path.getsize(path) > 10

def _sha256(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]

def _detect_domain(text, default="trade"):
    text_lower = text.lower()
    for domain, keywords in DOMAIN_KEYWORDS.items():
        for kw in keywords:
            if kw in text_lower:
                return domain
    return default


# ============================================================
# 状态管理
# ============================================================

class TaskState:
    """任务状态管理器"""

    def __init__(self, data_dir=None, task_id=None):
        self.task_id = task_id
        self.data_dir = data_dir
        self.state_path = os.path.join(data_dir, "orchestrator_state.json") if data_dir else None
        self.state = self._load()

    def _load(self):
        if self.state_path and os.path.exists(self.state_path):
            try:
                return _read_json(self.state_path)
            except Exception:
                pass
        return {
            "task_id": self.task_id,
            "data_dir": self.data_dir,
            "skill_dir": "",
            "current_step": None,
            "completed_steps": [],
            "current_phase": 1,
            "requirement_file": "",
            "skill_version": SKILL_VERSION,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
            "updated_at": None,
        }

    def save(self):
        if self.state_path:
            self.state["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%S+08:00")
            _write_json(self.state_path, self.state)

    def mark_complete(self, step):
        if step not in self.state["completed_steps"]:
            self.state["completed_steps"].append(step)
        self.state["current_step"] = step
        self.save()

    def is_complete(self, step):
        return step in self.state["completed_steps"]

    def get_next_step(self):
        for step in STEPS:
            if step not in self.state["completed_steps"]:
                return step
        return None


# ============================================================
# Gate Pass 管理
# ============================================================

def check_gate(data_dir, step, task_id):
    """检查指定步骤的gate pass是否存在且task_id一致"""
    gp_path = os.path.join(data_dir, "gates", f"{step}.pass.json")
    if not os.path.exists(gp_path):
        return False, f"{step}.pass.json不存在"
    try:
        gp = _read_json(gp_path)
        if gp.get("task_id") != task_id:
            return False, f"task_id不匹配: {gp.get('task_id')} != {task_id}"
        return True, "OK"
    except Exception:
        return False, f"{step}.pass.json读取失败"

def run_truncation_guard(skill_dir, data_dir, task_id, step, revision=1):
    """调用truncation_guard.py进行四级校验+auto-mv"""
    tmp_path = os.path.join(data_dir, f"{step.lower()}_output.tmp.json")
    guard_script = os.path.join(skill_dir, "tools", "truncation_guard.py")

    if not os.path.exists(guard_script):
        return False, "truncation_guard.py不存在"
    if not os.path.exists(tmp_path):
        return False, f"{tmp_path}不存在"

    cmd = [
        "python3", guard_script,
        "--file", tmp_path,
        "--step", step,
        "--data-dir", data_dir,
        "--task-id", task_id,
        "--revision", str(revision),
        "--auto-mv"
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

    if result.returncode == 0:
        return True, result.stdout.strip()
    else:
        return False, f"exit={result.returncode}: {result.stderr.strip() or result.stdout.strip()}"


# ============================================================
# Action: init
# ============================================================

def action_init(args):
    """初始化任务：创建task_id和DATA_DIR"""
    task_id = f"task_{time.strftime('%Y%m%d_%H%M%S')}"
    base_dir = os.path.expanduser("~/.openclaw/workspace/data")
    data_dir = os.path.join(base_dir, task_id)

    _ensure_dir(data_dir)
    _ensure_dir(os.path.join(data_dir, "gates"))

    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.state["skill_dir"] = resolve_skill_dir("")
    state.state["data_dir"] = data_dir
    state.save()

    print(json.dumps({
        "status": "ok",
        "task_id": task_id,
        "data_dir": data_dir,
    }))


# ============================================================
# Action: onboarding
# ============================================================

def action_onboarding(args):
    """执行Onboarding环境检查（非交互部分）"""
    skill_dir = args.skill_dir
    data_dir = args.data_dir
    task_id = args.task_id

    checks = []

    # 检查1: 文件完整性
    required_files = [
        "prompts/P0_requirement_structuring.md",
        "prompts/P1_feature_tree_generation.md",
        "prompts/P2_test_point_draft.md",
        "prompts/P6_testcase_generation.md",
        "prompts/P7_quality_gate.md",
        "tools/export_excel.py",
        "tools/truncation_guard.py",
        "tools/image_extract.py",
    ]
    missing = [f for f in required_files if not os.path.exists(os.path.join(skill_dir, f))]
    checks.append({
        "name": "file_integrity",
        "passed": len(missing) == 0,
        "missing": missing,
    })

    # 检查1.5: SKILL_DIR确认
    checks.append({
        "name": "skill_dir",
        "passed": os.path.exists(os.path.join(skill_dir, "tools", "export_excel.py")),
        "skill_dir": skill_dir,
    })

    # 检查2: Python + openpyxl
    try:
        result = subprocess.run(
            ["python3", "-c", "import openpyxl; print('ok')"],
            capture_output=True, text=True, timeout=10
        )
        openpyxl_ok = result.returncode == 0
    except Exception:
        openpyxl_ok = False
    checks.append({"name": "python_openpyxl", "passed": openpyxl_ok})

    # 检查0.5: 缓存检测
    cache_dir = os.path.expanduser("~/.openclaw/workspace/data")
    existing = sorted(glob.glob(os.path.join(cache_dir, "task_*")), reverse=True)[:3]
    checks.append({
        "name": "cache_detection",
        "existing_tasks": [os.path.basename(p) for p in existing],
    })

    all_passed = all(c.get("passed", True) for c in checks)

    # 写入onboarding.pass.json
    if all_passed:
        gate_path = os.path.join(data_dir, "gates", "onboarding.pass.json")
        _write_json(gate_path, {
            "step": "onboarding",
            "task_id": task_id,
            "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
            "checks": checks,
        })

        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.state["skill_dir"] = args.skill_dir
        state.state["data_dir"] = data_dir
        state.mark_complete("onboarding")

    print(json.dumps({
        "status": "ok" if all_passed else "blocked",
        "checks": checks,
        "onboarding_pass": all_passed,
    }))


# ============================================================
# Action: step0
# ============================================================

def action_step0(args):
    """Step 0: 接收需求，写入task_meta"""
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir
    requirement_text = args.requirement_text or ""
    requirement_file = args.requirement_file or ""

    # 门禁检查
    ok, msg = check_gate(data_dir, "onboarding", task_id)
    if not ok:
        print(json.dumps({"status": "gate_blocked", "step": "onboarding", "reason": msg}))
        sys.exit(1)

    # 如果是文件，提取文本
    if requirement_file and not requirement_text:
        if requirement_file.endswith(".docx"):
            try:
                result = subprocess.run(
                    ["python3", "-c", f"""
import zipfile, re
with zipfile.ZipFile("{requirement_file}") as z:
    xml = z.read("word/document.xml").decode("utf-8")
    text = re.sub(r"<[^>]+>", " ", xml)
    text = re.sub(r"\\s+", " ", text).strip()
    print(text[:50000])
"""],
                    capture_output=True, text=True, timeout=30
                )
                requirement_text = result.stdout.strip()
            except Exception as e:
                requirement_text = f"[docx解析失败: {e}]"
        else:
            try:
                with open(requirement_file, "r", encoding="utf-8") as f:
                    requirement_text = f.read()[:50000]
            except Exception:
                requirement_text = "[文件读取失败]"

    domain = _detect_domain(requirement_text)

    # 读取preferences（脱敏：不写入api_key等敏感字段到task_meta）
    prefs_path = os.path.join(skill_dir, "user_knowledge", "preferences.json")
    prefs = {}
    prefs_safe = {}  # 脱敏版本，只保留非敏感字段
    if os.path.exists(prefs_path):
        try:
            prefs = _read_json(prefs_path)
            # 脱敏：image_api只保留url/model/timeout（api_key运行时输入，不存此处）
            if "image_api" in prefs:
                ia = prefs["image_api"]
                prefs_safe["image_api"] = {
                    "url": ia.get("url", ""),
                    "model": ia.get("model", "ci"),
                    "timeout": ia.get("timeout", 120),
                }
        except Exception:
            pass

    # 写入task_meta
    meta = {
        "task_id": task_id,
        "domain": domain,
        "requirement_text": requirement_text,
        "requirement_file": requirement_file,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "preferences": prefs_safe,  # 脱敏版本
        "skill_version": SKILL_VERSION,
        "requirement_hash": _sha256(requirement_text),
    }
    _write_json(os.path.join(data_dir, "task_meta.json"), meta)

    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.state["requirement_file"] = requirement_file
    state.state["current_phase"] = 2
    state.mark_complete("step0")

    print(json.dumps({
        "status": "ok",
        "task_id": task_id,
        "domain": domain,
        "requirement_length": len(requirement_text),
    }))


# ============================================================
# ============================================================
# 图片理解API配置读取
# ============================================================

def _load_image_api_config(skill_dir, api_key=None):
    """读取图片理解API配置
    
    - url/model/timeout从preferences.json读取（写死，用户无需输入）
    - api_key从运行时参数传入（Onboarding交互时用户输入，不落盘）
    - enabled由api_key是否非空决定（有密码=启用，无密码=降级）
    """
    prefs_path = os.path.join(skill_dir, "user_knowledge", "preferences.json")
    prefs = {}
    if os.path.exists(prefs_path):
        try:
            prefs = _read_json(prefs_path)
        except Exception:
            pass

    ia = prefs.get("image_api", {})

    config = {
        "enabled": bool(api_key and api_key.strip()),  # 有密码才启用
        "url": ia.get("url", ""),
        "model": ia.get("model", "ci"),  # ci=数据万象, qwen=通义千问VL
        "timeout": ia.get("timeout", 120),
        "api_key": (api_key or "").strip(),
    }

    # 配置完整性校验
    if config["enabled"]:
        if not config["url"].startswith("https://") and not config["url"].startswith("http://"):
            config["enabled"] = False
            config["_invalid_reason"] = "API地址未配置或格式不正确（检查preferences.json中image_api.url）"

    return config


def _check_image_api_health(config):
    """预检：调用API的auth-check接口验证密码+服务可用性
    
    V3.0.3-patch1: 改用/api/auth-check替代/api/health
    原因: /api/health不鉴权，无法验证密码正确性（F2/F17修复）
    """
    try:
        import requests
        # 从analyze URL推导auth-check URL
        if "/api/" in config["url"]:
            base_url = config["url"].rsplit("/api/", 1)[0]
        else:
            base_url = config["url"].rsplit("/", 1)[0]
        auth_check_url = base_url + "/api/auth-check"

        resp = requests.get(
            auth_check_url,
            headers={"X-API-Key": config["api_key"]},
            timeout=5,
        )
        if resp.status_code == 200:
            data = resp.json()
            return data.get("status") == "ok", data
        elif resp.status_code in (401, 403):
            return False, {"error": "auth_failed", "message": "密码错误"}
        elif resp.status_code == 503:
            data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
            return False, {"error": "service_not_configured", "message": data.get("reason", data.get("message", "服务未配置密码验证"))}
        return False, {"error": f"HTTP {resp.status_code}"}
    except requests.exceptions.ConnectionError:
        return False, {"error": "connection_failed", "message": "无法连接到API服务"}
    except requests.exceptions.Timeout:
        return False, {"error": "timeout", "message": "API服务响应超时"}
    except Exception as e:
        return False, {"error": str(e)[:100]}


def _call_image_api(image_path, config):
    """调用图片理解API分析单张图片"""
    try:
        import requests
        with open(image_path, "rb") as f:
            resp = requests.post(
                config["url"],
                headers={"X-API-Key": config["api_key"]},
                files={"file": f},
                data={"model": config["model"]},
                timeout=config["timeout"],
            )
        if resp.status_code == 200:
            return resp.json()
        elif resp.status_code in (401, 403):
            return {"status": "auth_failed", "error": f"鉴权失败: HTTP {resp.status_code}"}
        elif resp.status_code == 429:
            return {"status": "rate_limited", "error": "请求频率超限"}
        else:
            return {"status": "error", "error": f"HTTP {resp.status_code}"}
    except requests.exceptions.Timeout:
        return {"status": "timeout", "error": "请求超时"}
    except Exception as e:
        return {"status": "error", "error": str(e)[:100]}


# ============================================================
# Action: step0_8_prep (PX图片抽取+选图+API理解/caption_only降级)
# ============================================================

def action_step0_8_prep(args):
    """PX图片抽取+价值优先选图+自动调用API理解（或降级为caption_only）
    
    V3.0.3改动：
    - API模式：orchestrator直接调用图片理解API，不依赖Agent
    - 降级模式：caption_only（用前后文生成描述），不回退Agent看图
    - 结果写入px_api_results.json，由step0_8_save统一收口
    """
    data_dir = args.data_dir
    skill_dir = args.skill_dir
    requirement_file = args.requirement_file or ""

    if not requirement_file or not requirement_file.endswith(".docx"):
        print(json.dumps({"status": "skipped", "reason": "非docx格式，跳过PX"}))
        return

    # 调用image_extract.py
    extract_script = os.path.join(skill_dir, "tools", "image_extract.py")
    px_images_dir = os.path.join(data_dir, "px_images")
    px_extract_path = os.path.join(data_dir, "px_extract.json")

    _ensure_dir(px_images_dir)

    result = subprocess.run(
        ["python3", extract_script, requirement_file,
         "--output-dir", px_images_dir,
         "--json-output", px_extract_path],
        capture_output=True, text=True, timeout=60
    )

    if result.returncode != 0 or not os.path.exists(px_extract_path):
        print(json.dumps({"status": "skipped", "reason": f"图片抽取失败: {result.stderr[:200]}"}))
        return

    extract_data = _read_json(px_extract_path)
    images = extract_data.get("images", [])

    if not images:
        print(json.dumps({"status": "skipped", "reason": "docx中无图片"}))
        return

    # 价值优先选图
    value_keywords = ["流程", "状态", "原型", "页面", "规则", "接口", "表格", "如下图", "见图"]
    scored = []
    for img in images:
        caption = (img.get("caption", "") or "").lower()
        before = (img.get("before_text", "") or "").lower()
        after = (img.get("after_text", "") or "").lower()
        context = caption + " " + before + " " + after

        score = 0
        for kw in value_keywords:
            if kw in context:
                score += 1

        # 跳过装饰性图片
        w = img.get("width", 100)
        h = img.get("height", 100)
        if (w < 50 and h < 50) or "logo" in context or "icon" in context:
            score = -1

        scored.append((score, img))

    scored.sort(key=lambda x: x[0], reverse=True)
    selected = [img for score, img in scored if score >= 0][:50]

    # ============================================================
    # V3.0.3: 图片理解（API模式 or caption_only降级）
    # ============================================================
    # V3.2.0: api_key优先从命令行参数读取，其次从task目录缓存读取（解决Agent跨段落丢密码问题）
    api_key = getattr(args, 'api_key', None) or ''
    if not api_key.strip():
        cache_path = os.path.join(data_dir, ".image_api_key")
        if os.path.exists(cache_path):
            try:
                with open(cache_path, "r") as f:
                    api_key = f.read().strip()
            except Exception:
                pass
    api_config = _load_image_api_config(skill_dir, api_key=api_key or None)
    use_api = api_config["enabled"]

    # 预检：API health check
    service_ok = False
    if use_api:
        service_ok, health_data = _check_image_api_health(api_config)
        if not service_ok:
            use_api = False  # 降级

    results = []
    api_success = 0
    api_fallback = 0

    # V3.2.0: 并行调用API（解决19张图串行~570s的问题）
    # 策略：线程池并发=3，主线程汇总结果，401/403立即标记
    def _process_single_image(img):
        """处理单张图片（线程安全：只读输入，返回结果，不修改共享状态）"""
        image_id = img.get("image_id", "")
        file_path = img.get("file_path", "")
        caption = img.get("caption", "") or ""
        before_text = (img.get("before_text", "") or "")[:200]
        after_text = (img.get("after_text", "") or "")[:200]

        caption_desc = caption
        if before_text or after_text:
            context_parts = []
            if before_text:
                context_parts.append(f"图片前文: {before_text}")
            if caption:
                context_parts.append(f"图片标题: {caption}")
            if after_text:
                context_parts.append(f"图片后文: {after_text}")
            caption_desc = " | ".join(context_parts)

        if not file_path or not os.path.exists(file_path):
            return {"image_id": image_id, "understanding_mode": "caption_only",
                    "failure_type": "file_not_found", "description": caption_desc,
                    "ocr_text": "", "labels": [],
                    "before_text": before_text, "after_text": after_text, "_ok": False}

        api_result = _call_image_api(file_path, api_config)

        if api_result.get("status") in ("ok", "partial"):
            mode = "api" if api_result.get("status") == "ok" else "api_partial"
            return {"image_id": image_id, "understanding_mode": mode,
                    "api_provider": api_result.get("model", api_config["model"]),
                    "description": api_result.get("description", caption_desc),
                    "ocr_text": api_result.get("ocr_text", ""),
                    "labels": api_result.get("labels", []),
                    "confidence": api_result.get("confidence", 0),
                    "before_text": before_text, "after_text": after_text, "_ok": True}
        elif api_result.get("status") in ("auth_failed", "rate_limited"):
            return {"image_id": image_id, "understanding_mode": "api_fallback_caption",
                    "failure_type": api_result.get("status"), "description": caption_desc,
                    "ocr_text": "", "labels": [],
                    "before_text": before_text, "after_text": after_text, "_ok": False, "_fatal": True}
        else:
            return {"image_id": image_id, "understanding_mode": "api_fallback_caption",
                    "failure_type": api_result.get("status", "unknown"), "description": caption_desc,
                    "ocr_text": "", "labels": [],
                    "before_text": before_text, "after_text": after_text, "_ok": False}

    if use_api:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        fatal_detected = False
        with ThreadPoolExecutor(max_workers=3) as executor:
            future_map = {executor.submit(_process_single_image, img): img.get("image_id", "") for img in selected}
            try:
                for future in as_completed(future_map, timeout=600):
                    try:
                        r = future.result(timeout=120)
                        ok = r.pop("_ok", False)
                        is_fatal = r.pop("_fatal", False)
                        results.append(r)
                        if ok:
                            api_success += 1
                        else:
                            api_fallback += 1
                        # 401/403立即取消剩余任务
                        if is_fatal:
                            fatal_detected = True
                            for f in future_map:
                                f.cancel()
                            break
                    except Exception as e:
                        results.append({"image_id": future_map.get(future, "?"),
                                        "understanding_mode": "api_fallback_caption",
                                        "failure_type": "exception", "description": str(e)[:200],
                                        "ocr_text": "", "labels": [],
                                        "before_text": "", "after_text": ""})
                        api_fallback += 1
            except TimeoutError:
                # 总超时600s，未完成的图片降级为caption_only
                for f, img_id in future_map.items():
                    if not f.done():
                        results.append({"image_id": img_id,
                                        "understanding_mode": "api_fallback_caption",
                                        "failure_type": "total_timeout",
                                        "description": "总超时600s未完成",
                                        "ocr_text": "", "labels": [],
                                        "before_text": "", "after_text": ""})
                        api_fallback += 1
    else:
        for img in selected:
            image_id = img.get("image_id", "")
            caption = img.get("caption", "") or ""
            before_text = (img.get("before_text", "") or "")[:200]
            after_text = (img.get("after_text", "") or "")[:200]
            caption_desc = caption
            if before_text or after_text:
                parts = []
                if before_text: parts.append(f"图片前文: {before_text}")
                if caption: parts.append(f"图片标题: {caption}")
                if after_text: parts.append(f"图片后文: {after_text}")
                caption_desc = " | ".join(parts)
            results.append({"image_id": image_id, "understanding_mode": "caption_only",
                            "description": caption_desc, "ocr_text": "", "labels": [],
                            "before_text": before_text, "after_text": after_text})

    # 将结果写入临时文件，由step0_8_save统一收口
    _write_json(os.path.join(data_dir, "px_api_results.json"), {
        "results": results,
        "summary": {
            "mode": "api" if api_config["enabled"] and service_ok else "caption_only",
            "service_status": "ok" if api_success > 0 and api_fallback == 0 else
                              ("partial_success" if api_success > 0 else "degraded"),
            "api_success_count": api_success,
            "api_fallback_count": api_fallback,
            "total_selected": len(selected),
            "total_images": len(images),
            "api_provider": api_config["model"] if api_config["enabled"] else "none",
        }
    })

    # 输出状态
    mode = "api" if api_config["enabled"] and service_ok else "caption_only"
    if not api_config["enabled"]:
        mode_msg = "caption_only（未输入图片API密码，如需启用请在Onboarding时输入密码）"
    elif not service_ok:
        mode_msg = f"caption_only（API健康检查失败: {health_data.get('error', 'unknown')}）"
    elif api_fallback > 0:
        mode_msg = f"api_with_fallback（成功{api_success}张，降级{api_fallback}张）"
    else:
        mode_msg = f"api（全部{api_success}张通过{api_config['model']}理解）"

    print(json.dumps({
        "status": "ok",
        "mode": mode,
        "mode_message": mode_msg,
        "total_images": len(images),
        "selected_count": len(selected),
        "api_success_count": api_success,
        "api_fallback_count": api_fallback,
    }))


# ============================================================
# Action: step0_8_save (保存图片理解结果)
# ============================================================

def action_step0_8_save(args):
    """保存图片理解结果，调用image_enhance（统一收口）
    
    V3.0.3改动：
    - 优先读取px_api_results.json（API/caption_only模式产出）
    - 如无API结果文件，回退读取args.results_json（兼容旧模式）
    - 统一生成px_understand.json + 调用image_enhance + mark_complete
    """
    data_dir = args.data_dir
    skill_dir = args.skill_dir
    task_id = args.task_id

    # 优先读取API结果文件
    api_results_path = os.path.join(data_dir, "px_api_results.json")
    if os.path.exists(api_results_path):
        api_data = _read_json(api_results_path)
        results = api_data.get("results", [])
        api_summary = api_data.get("summary", {})
    elif args.results_json:
        # 兼容旧模式：从命令行参数读取
        try:
            results = json.loads(args.results_json)
            api_summary = {}
        except Exception:
            print(json.dumps({"status": "error", "reason": "图片理解结果JSON解析失败"}))
            return
    else:
        print(json.dumps({"status": "error", "reason": "无图片理解结果（px_api_results.json不存在且未传入results_json）"}))
        return

    # 读取抽取数据获取总数
    px_extract_path = os.path.join(data_dir, "px_extract.json")
    total = 0
    if os.path.exists(px_extract_path):
        total = len(_read_json(px_extract_path).get("images", []))

    # 构造px_understand.json
    api_count = sum(1 for r in results if r.get("understanding_mode") == "api")
    caption_count = sum(1 for r in results if r.get("understanding_mode") in ("caption_only", "api_fallback_caption"))
    vision_count = sum(1 for r in results if r.get("understanding_mode") == "vision")  # 兼容旧模式

    # 构造skipped_images列表（未被选中的图片）
    skipped_images = []
    if os.path.exists(px_extract_path):
        all_images = _read_json(px_extract_path).get("images", [])
        selected_ids = set(r.get("image_id", "") for r in results)
        for img in all_images:
            if img.get("image_id", "") not in selected_ids:
                skipped_images.append({
                    "image_id": img.get("image_id", ""),
                    "file_path": img.get("file_path", ""),
                    "selected": False,
                    "selection_reason": "超出50张上限或未命中高价值关键词",
                    "understanding_mode": "skipped"
                })

    understand = {
        "task_id": task_id,
        "total_images": total,
        "selected_images": len(results),
        "results": results,
        "skipped_images": skipped_images,
        "summary": {
            "api_count": api_count,
            "caption_count": caption_count,
            "vision_count": vision_count,
            "skipped_count": total - len(results),
            "mode": api_summary.get("mode", "unknown"),
            "service_status": api_summary.get("service_status", "unknown"),
            "api_provider": api_summary.get("api_provider", "none"),
        }
    }
    _write_json(os.path.join(data_dir, "px_understand.json"), understand)

    # 调用image_enhance
    enhance_script = os.path.join(skill_dir, "tools", "image_enhance.py")
    enhance_output = os.path.join(data_dir, "px_enhance.json")

    result = subprocess.run(
        ["python3", enhance_script,
         os.path.join(data_dir, "px_understand.json"),
         "--output", enhance_output],
        capture_output=True, text=True, timeout=30
    )

    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.mark_complete("step0_8")

    print(json.dumps({
        "status": "ok",
        "mode": api_summary.get("mode", "unknown"),
        "api_count": api_count,
        "caption_count": caption_count,
        "vision_count": vision_count,
        "total": total,
        "enhance_ok": result.returncode == 0,
    }))


# ============================================================
# Action: step_run (执行P0-P7任一步骤)
# ============================================================

def action_step_run(args):
    """
    执行P0-P7任一步骤：
    1. 检查前置gate pass
    2. 准备prompt输入（读取上游产物+知识注入）
    3. 接收Agent的JSON输出
    4. 写入tmp → truncation_guard → gate pass
    """
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir
    step = args.step  # P0/P1/P2/P3/P4/P5/P6/P7
    agent_output = args.agent_output  # Agent返回的JSON字符串

    # 前置gate pass检查
    prerequisites = {
        "P0": ["onboarding"],
        "P1": ["P0"],
        "P2": ["P1"],
        "P3": ["P1"],
        "P4": ["P1"],
        "P5": ["P2", "P3", "P4"],
        "P6": ["P5"],
        "P7": ["P6"],
    }

    for prereq in prerequisites.get(step, []):
        ok, msg = check_gate(data_dir, prereq, task_id)
        if not ok:
            print(json.dumps({"status": "gate_blocked", "step": prereq, "reason": msg}))
            sys.exit(1)

    # 解析Agent输出
    try:
        output_data = json.loads(agent_output)
    except json.JSONDecodeError:
        # JSON解析兜底：尝试正则提取
        import re
        match = re.search(r'\{[\s\S]*\}', agent_output)
        if match:
            try:
                output_data = json.loads(match.group())
            except Exception:
                print(json.dumps({"status": "error", "reason": "Agent输出JSON解析失败（含正则兜底）"}))
                sys.exit(1)
        else:
            print(json.dumps({"status": "error", "reason": "Agent输出不含有效JSON"}))
            sys.exit(1)

    # 写入tmp文件
    tmp_path = os.path.join(data_dir, f"{step.lower()}_output.tmp.json")
    _write_json(tmp_path, output_data)

    # === V3.0.3新增：写入tmp后、guard前，先做必需字段校验（代码硬控） ===
    required_fields_map = {
        "P0": P0_REQUIRED_FIELDS,
        "P1": P1_REQUIRED_FIELDS,
        "P3": P3_REQUIRED_FIELDS,
        "P4": P4_REQUIRED_FIELDS,
        "P5": P5_REQUIRED_FIELDS,
        "P6": P6_REQUIRED_FIELDS,
        "P7": P7_REQUIRED_FIELDS,
    }
    if step in required_fields_map:
        missing_fields = []
        for field in required_fields_map[step]:
            # 支持嵌套路径和多候选
            val = _get_nested(output_data, field)
            if val is None:
                missing_fields.append(field)
        if missing_fields:
            # 删除tmp文件，拒绝写入
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
            print(json.dumps({
                "status": "validation_failed",
                "step": step,
                "reason": f"必需字段缺失: {missing_fields}。请确保输出JSON包含这些顶层字段。",
                "missing_fields": missing_fields,
                "hint": f"{step}输出必须包含: {required_fields_map[step]}",
            }))
            sys.exit(1)

    # 调用truncation_guard
    ok, msg = run_truncation_guard(skill_dir, data_dir, task_id, step)

    if ok:
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete(step)
        print(json.dumps({"status": "ok", "step": step, "guard_result": msg}))
    else:
        print(json.dumps({"status": "guard_failed", "step": step, "reason": msg}))
        sys.exit(1)


# ============================================================
# Action: step7_export
# ============================================================

def action_step7_export(args):
    """Step 7: 调用export_excel.py导出
    
    V3.0.3: 内置quality_check硬门禁，Agent无法绕过
    """
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir

    # 检查全链路gate pass完整性（防止Agent"表演"流程）
    required_gates = ["onboarding", "P0", "P1", "P2", "P3", "P4", "P5", "P6", "P7"]
    missing_gates = []
    for step in required_gates:
        ok, msg = check_gate(data_dir, step, task_id)
        if not ok:
            missing_gates.append(step)

    if missing_gates:
        print(json.dumps({
            "status": "gate_blocked",
            "reason": f"以下步骤的gate pass缺失: {missing_gates}。Agent必须真正执行这些步骤（通过orchestrator），不能跳过。",
            "missing_gates": missing_gates,
        }))
        sys.exit(1)

    # === V3.0.3新增：导出前强制执行P6质量校验（代码硬控，Agent无法绕过） ===
    p6_path = os.path.join(data_dir, "p6_output.json")
    if os.path.exists(p6_path):
        p6_data = _read_json(p6_path)
        cases = p6_data.get("testcases", [])
        total = len(cases)
        quality_issues = []

        if total < 15:
            quality_issues.append(f"用例数量{total}<15，不达标")

        if total > 0:
            smoke = sum(1 for c in cases if c.get("is_smoke", "") in ("是", "Y", "yes", True))
            p0 = sum(1 for c in cases if c.get("priority", "").upper() in ("P0", "HIGHEST"))
            smoke_ratio = smoke / total
            p0_ratio = p0 / total

            if smoke_ratio < P6_QUALITY_RULES["smoke_ratio_min"]:
                quality_issues.append(f"冒烟比例{smoke_ratio:.1%}<{P6_QUALITY_RULES['smoke_ratio_min']:.0%}")
            if smoke_ratio > P6_QUALITY_RULES["smoke_ratio_max"]:
                quality_issues.append(f"冒烟比例{smoke_ratio:.1%}>{P6_QUALITY_RULES['smoke_ratio_max']:.0%}")
            if p0_ratio > P6_QUALITY_RULES["p0_ratio_max"]:
                quality_issues.append(f"P0占比{p0_ratio:.1%}>{P6_QUALITY_RULES['p0_ratio_max']:.0%}")

            priorities = set(c.get("priority", "") for c in cases)
            if len(priorities) == 1 and total > 5:
                quality_issues.append(f"所有{total}条用例同一优先级")

        if quality_issues:
            print(json.dumps({
                "status": "quality_blocked",
                "reason": f"P6质量校验未通过，禁止导出: {quality_issues}",
                "issues": quality_issues,
                "retry_hint": "请重新执行P6用例展开（从p6 prep_prompt重新开始）",
            }))
            sys.exit(1)

    # === P7门禁校验：确认P7实际输出PASS ===
    p7_path = os.path.join(data_dir, "p7_output.json")
    if os.path.exists(p7_path):
        p7_data = _read_json(p7_path)
        gate_result = p7_data.get("gate_result", {})
        if gate_result.get("status", "").upper() != "PASS":
            print(json.dumps({
                "status": "quality_blocked",
                "reason": f"P7质量门禁未通过: {gate_result.get('status', 'UNKNOWN')}",
                "gate_result": gate_result,
            }))
            sys.exit(1)

    # 读取task_meta获取文件名
    meta = _read_json(os.path.join(data_dir, "task_meta.json"))
    domain = meta.get("domain", "unknown")

    export_script = os.path.join(skill_dir, "tools", "export_excel.py")
    p6_path = os.path.join(data_dir, "p6_output.json")
    output_path = os.path.join(data_dir, f"测试用例_{task_id}.xlsx")

    result = subprocess.run(
        ["python3", export_script, "--input", p6_path, "--output", output_path],
        capture_output=True, text=True, timeout=60
    )

    if result.returncode == 0 and os.path.exists(output_path):
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete("step7")
        print(json.dumps({
            "status": "ok",
            "excel_path": output_path,
            "file_size": os.path.getsize(output_path),
            "media_instruction": f"MEDIA:{output_path}",
            "reminder": "Agent必须在对话中独占一行输出上面的MEDIA指令，否则用户收不到文件",
        }))
    else:
        print(json.dumps({
            "status": "error",
            "reason": f"Excel导出失败: {result.stderr[:300]}",
        }))
        sys.exit(1)


# ============================================================
# Action: status
# ============================================================

def action_status(args):
    """查看当前任务状态"""
    data_dir = args.data_dir
    task_id = args.task_id

    state = TaskState(data_dir=data_dir, task_id=task_id)
    next_step = state.get_next_step()

    # 检查所有gate pass
    gates = {}
    gates_dir = os.path.join(data_dir, "gates")
    if os.path.exists(gates_dir):
        for f in os.listdir(gates_dir):
            if f.endswith(".pass.json"):
                step_name = f.replace(".pass.json", "")
                gates[step_name] = True

    print(json.dumps({
        "task_id": task_id,
        "completed_steps": state.state["completed_steps"],
        "next_step": next_step,
        "gates": gates,
    }))


# ============================================================
# Action: resume
# ============================================================

def action_resume(args):
    """断点续跑：检测已完成步骤，返回下一步"""
    data_dir = args.data_dir
    task_id = args.task_id

    state = TaskState(data_dir=data_dir, task_id=task_id)

    # 扫描gate pass补充completed_steps
    gates_dir = os.path.join(data_dir, "gates")
    if os.path.exists(gates_dir):
        for f in sorted(os.listdir(gates_dir)):
            if f.endswith(".pass.json"):
                step_name = f.replace(".pass.json", "")
                try:
                    gp = _read_json(os.path.join(gates_dir, f))
                    if gp.get("task_id") == task_id:
                        if step_name not in state.state["completed_steps"]:
                            state.state["completed_steps"].append(step_name)
                except Exception:
                    pass
        state.save()

    next_step = state.get_next_step()

    print(json.dumps({
        "status": "ok",
        "task_id": task_id,
        "completed_steps": state.state["completed_steps"],
        "next_step": next_step,
    }))


# ============================================================
# Action: prep_prompt (为每个P步骤准备完整prompt)
# ============================================================

# Prompt文件映射
PROMPT_FILES = {
    "P0": "prompts/P0_requirement_structuring.md",
    "P1": "prompts/P1_feature_tree_generation.md",
    "P2": "prompts/P2_test_point_draft.md",
    "P3": "prompts/P3_risk_identification.md",
    "P4": "prompts/P4_pci_identification.md",
    "P5": "prompts/P5_test_point_merge.md",
    "P6": "prompts/P6_testcase_generation.md",
    "P7": "prompts/P7_quality_gate.md",
}

# 每步需要的上游产物
UPSTREAM_FILES = {
    "P0": ["task_meta.json"],
    "P1": ["p0_output.json"],
    "P2": ["p1_output.json"],
    "P3": ["p1_output.json"],
    "P4": ["p1_output.json"],
    "P5": ["p2_output.json", "p3_output.json", "p4_output.json"],
    "P6": ["p5_output.json"],
    "P7": ["p6_output.json"],
}

# 知识注入映射
KNOWLEDGE_INJECT = {
    "P0": ["knowledge/industry/{domain}.md", "knowledge/methodology/design_methods.md"],
    "P1": ["knowledge/methodology/design_methods.md"],
    "P2": ["knowledge/methodology/boundary_rules.md", "knowledge/methodology/api_test_standard.md"],
    "P3": ["knowledge/industry/{domain}.md"],
    "P4": ["knowledge/industry/{domain}.md"],
    "P5": [],
    "P6": ["knowledge/company_standards/testcase_design_spec.md", "knowledge/defect_patterns/defect_schema.md"],
    "P7": [],
}

def _read_file_safe(path, max_chars=8000):
    """安全读取文件，不存在返回空字符串"""
    if not os.path.exists(path):
        return ""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()[:max_chars]
    except Exception:
        return ""

def action_prep_prompt(args):
    """为指定的P步骤准备完整prompt，输出给Agent执行"""
    skill_dir = args.skill_dir
    data_dir = args.data_dir
    task_id = args.task_id
    step = args.step
    batch_index = int(getattr(args, 'batch_index', 0))  # P6分批用，确保int类型

    if step not in PROMPT_FILES:
        print(json.dumps({"status": "error", "reason": f"不支持的步骤: {step}"}))
        sys.exit(1)

    # 前置gate pass检查
    prerequisites = {
        "P0": ["onboarding"], "P1": ["P0"], "P2": ["P1"],
        "P3": ["P1"], "P4": ["P1"], "P5": ["P2", "P3", "P4"],
        "P6": ["P5"], "P7": ["P6"],
    }
    for prereq in prerequisites.get(step, []):
        ok, msg = check_gate(data_dir, prereq, task_id)
        if not ok:
            print(json.dumps({"status": "gate_blocked", "step": prereq, "reason": msg}))
            sys.exit(1)

    # 1. 读取prompt模板
    prompt_path = os.path.join(skill_dir, PROMPT_FILES[step])
    prompt_template = _read_file_safe(prompt_path, 15000)
    if not prompt_template:
        print(json.dumps({"status": "error", "reason": f"Prompt文件不存在: {PROMPT_FILES[step]}"}))
        sys.exit(1)

    # 2. 读取上游产物
    upstream_data = {}
    for fname in UPSTREAM_FILES.get(step, []):
        fpath = os.path.join(data_dir, fname)
        content = _read_file_safe(fpath, 20000)
        if content:
            upstream_data[fname] = content

    # 3. 知识注入
    # 读取domain
    meta_path = os.path.join(data_dir, "task_meta.json")
    domain = "trade"
    requirement_text = ""
    if os.path.exists(meta_path):
        try:
            meta = _read_json(meta_path)
            domain = meta.get("domain", "trade")
            requirement_text = meta.get("requirement_text", "")
        except Exception:
            pass

    knowledge_texts = []
    for kpath_template in KNOWLEDGE_INJECT.get(step, []):
        kpath = os.path.join(skill_dir, kpath_template.replace("{domain}", domain))
        kt = _read_file_safe(kpath, 3000)
        if kt:
            knowledge_texts.append(kt)

    # 4. PX增强注入（如有）
    px_inject = ""
    px_enhance_path = os.path.join(data_dir, "px_enhance.json")
    if os.path.exists(px_enhance_path):
        try:
            px_data = _read_json(px_enhance_path)
            step_subsets = px_data.get("step_subsets", {})
            step_key = step  # P0/P1/...
            if step_key in step_subsets:
                px_inject = json.dumps(step_subsets[step_key], ensure_ascii=False)
                # Qwen VL的description可能很长，截取注入不超过3000字符
                if len(px_inject) > 3000:
                    px_inject = px_inject[:3000] + "\n...(内容过长已截断)"
        except Exception:
            pass

    # 5. P6分批处理
    p6_batch_info = ""
    if step == "P6" and batch_index > 0:
        # 读取P5测试点，按批次切分
        p5_path = os.path.join(data_dir, "p5_output.json")
        if os.path.exists(p5_path):
            try:
                p5 = _read_json(p5_path)
                test_points = p5.get("test_points", [])
                batch_size = 10
                start = (batch_index - 1) * batch_size
                end = start + batch_size
                batch_points = test_points[start:end]
                total_batches = (len(test_points) + batch_size - 1) // batch_size
                p6_batch_info = f"\n---\n## 当前批次\n第{batch_index}/{total_batches}批，处理测试点{start+1}-{min(end, len(test_points))}:\n{json.dumps(batch_points, ensure_ascii=False)[:5000]}"
            except Exception:
                pass

    # 6. 组装完整prompt
    full_prompt_parts = [prompt_template]

    if knowledge_texts:
        full_prompt_parts.append("\n---\n## 注入知识\n" + "\n\n".join(knowledge_texts))

    if px_inject:
        full_prompt_parts.append(f"\n---\n## 图片理解增强\n{px_inject}")

    if upstream_data:
        full_prompt_parts.append("\n---\n## 输入数据")
        for fname, content in upstream_data.items():
            full_prompt_parts.append(f"\n### {fname}\n{content}")

    # P0需要需求文本
    if step == "P0" and requirement_text:
        full_prompt_parts.append(f"\n---\n## 需求文本\n{requirement_text[:15000]}")

    if p6_batch_info:
        full_prompt_parts.append(p6_batch_info)

    # P0内联必需字段提醒
    if step == "P0":
        full_prompt_parts.append("\n---\n## ❗ 输出必须包含以下顶层字段\n- quality_score: number (0~1.0)\n- blocks: object\n- objective: string")

    # P1内联必需字段提醒
    if step == "P1":
        full_prompt_parts.append("\n---\n## ❗ 输出必须包含以下顶层字段\n- feature_tree: object (包含modules数组)\n- modules: array (与feature_tree.modules镜像)")

    # P7内联必需字段提醒
    if step == "P7":
        full_prompt_parts.append("\n---\n## ❗ 输出必须包含以下顶层字段\n- gate_result: object (包含status: PASS/FAIL)")

    # P6质量规则注入（解决冒烟89%/P0占83%异常高的问题）
    if step == "P6":
        full_prompt_parts.append("""\n---\n## ❗ 用例质量硬性规则（必须遵守，quality_check会校验）
1. **冒烟用例比例**: 必须在8%~20%之间。冒烟用例=P0优先级+核心功能正向验证（排除删除/隐藏/异常用例）
2. **P0优先级占比**: 不得超过40%。大部分用例应为P1/P2
3. **优先级分布**: 不允许所有用例为同一优先级
4. **每需求冒烟**: 每个需求至少1条冒烟用例，不能全部为"否"
5. **用例数下限**: 合并后至少15条用例

违反以上任何规则的用例集将被quality_check拒绝，需要重新生成。""")

    full_prompt = "\n".join(full_prompt_parts)

    # 输出
    result = {
        "status": "ok",
        "step": step,
        "prompt_length": len(full_prompt),
        "upstream_files": list(upstream_data.keys()),
        "knowledge_injected": len(knowledge_texts),
        "px_injected": bool(px_inject),
    }

    # 将prompt写入文件（太长不适合通过stdout传递）
    prompt_output_path = os.path.join(data_dir, f"{step.lower()}_prompt.txt")
    with open(prompt_output_path, "w", encoding="utf-8") as f:
        f.write(full_prompt)
    result["prompt_file"] = prompt_output_path

    print(json.dumps(result))


# ============================================================
# Action: p6_batch_info (P6分批信息)
# ============================================================

# ============================================================
# Action: p5_code_merge (V3.2.0: P5合并下沉代码层)
# ============================================================

def action_p5_code_merge(args):
    """代码层合并P2+P3+P4→P5（不再依赖Agent/prompt合并）
    
    读取P2测试点 + P3风险点 + P4 PCI项，代码合并后写入P5
    """
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir

    # 前置gate检查
    for prereq in ["P2", "P3", "P4"]:
        ok, msg = check_gate(data_dir, prereq, task_id)
        if not ok:
            print(json.dumps({"status": "gate_blocked", "step": prereq, "reason": msg}))
            sys.exit(1)

    # 读取P2测试点
    p2_path = os.path.join(data_dir, "p2_output.json")
    p2_data = _read_json(p2_path) if os.path.exists(p2_path) else {}
    p2_points = p2_data.get("test_points", [])

    # 读取P3风险点（兼容risk_points和risks）
    p3_path = os.path.join(data_dir, "p3_output.json")
    p3_data = _read_json(p3_path) if os.path.exists(p3_path) else {}
    p3_risks = p3_data.get("risk_points", p3_data.get("risks", []))

    # 读取P4 PCI项（兼容pci_list和pci_items）
    p4_path = os.path.join(data_dir, "p4_output.json")
    p4_data = _read_json(p4_path) if os.path.exists(p4_path) else {}
    p4_pcis = p4_data.get("pci_list", p4_data.get("pci_items", []))

    # 合并逻辑：P2测试点为基础，P3风险补充风险标记，P4 PCI补充待确认标记
    merged_points = []
    from_p3_count = 0
    from_p4_count = 0

    # 复制P2测试点
    for tp in p2_points:
        point = dict(tp)  # 浅拷贝
        point["source"] = "P2"
        point.setdefault("risk_flag", False)
        point.setdefault("pci_flag", False)
        merged_points.append(point)

    # P3风险点补充：尝试关联到已有测试点，关联不上的新增为独立测试点
    for risk in p3_risks:
        risk_source = risk.get("source_scenario", risk.get("source", ""))
        matched = False
        for point in merged_points:
            point_source = point.get("source_scenario", point.get("id", ""))
            if risk_source and risk_source == point_source:
                point["risk_flag"] = True
                point["risk_description"] = risk.get("description", "")
                point["risk_severity"] = risk.get("severity", "medium")
                matched = True
                from_p3_count += 1
                break
        if not matched:
            # 新增为独立测试点
            merged_points.append({
                "id": risk.get("id", f"RISK-{len(merged_points)+1}"),
                "source": "P3",
                "description": f"[风险验证] {risk.get('description', '')}",
                "category": "risk_verification",
                "risk_flag": True,
                "risk_severity": risk.get("severity", "medium"),
                "pci_flag": False,
                "priority_hint": "P1",
            })
            from_p3_count += 1

    # P4 PCI补充：同理
    for pci in p4_pcis:
        pci_source = pci.get("source_scenario", pci.get("source", ""))
        matched = False
        for point in merged_points:
            point_source = point.get("source_scenario", point.get("id", ""))
            if pci_source and pci_source == point_source:
                point["pci_flag"] = True
                point["pci_description"] = pci.get("description", "")
                matched = True
                from_p4_count += 1
                break
        if not matched:
            merged_points.append({
                "id": pci.get("id", f"PCI-{len(merged_points)+1}"),
                "source": "P4",
                "description": f"[待确认] {pci.get('description', '')}",
                "category": "pci_verification",
                "risk_flag": False,
                "pci_flag": True,
                "priority_hint": "P1",
            })
            from_p4_count += 1

    # 去重（基于description相似度，简化为完全相同）
    seen_descs = set()
    deduped = []
    removed = 0
    for point in merged_points:
        desc = point.get("description", "")
        if desc and desc in seen_descs:
            removed += 1
            continue
        if desc:
            seen_descs.add(desc)
        deduped.append(point)

    # 构造P5输出
    p5_output = {
        "schema_version": "1.0.0",
        "prompt_version": "1.0.0",
        "requirement_id": p2_data.get("requirement_id", ""),
        "test_points": deduped,
        "merge_log": {
            "from_p2": len(p2_points),
            "from_p3": from_p3_count,
            "from_p4": from_p4_count,
            "merged": len(merged_points),
            "removed_duplicates": removed,
            "final_count": len(deduped),
        },
        "coverage_summary": {
            "total_test_points": len(deduped),
            "risk_flagged": sum(1 for p in deduped if p.get("risk_flag")),
            "pci_flagged": sum(1 for p in deduped if p.get("pci_flag")),
        },
    }

    # 写入tmp→truncation_guard→gate pass
    tmp_path = os.path.join(data_dir, "p5_output.tmp.json")
    _write_json(tmp_path, p5_output)

    ok, msg = run_truncation_guard(skill_dir, data_dir, task_id, "P5")
    if ok:
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete("P5")
        print(json.dumps({
            "status": "ok",
            "step": "P5",
            "total_test_points": len(deduped),
            "from_p2": len(p2_points),
            "from_p3": from_p3_count,
            "from_p4": from_p4_count,
            "removed_duplicates": removed,
        }))
    else:
        print(json.dumps({"status": "guard_failed", "step": "P5", "reason": msg}))
        sys.exit(1)


def action_p6_batch_info(args):
    """返回P6分批信息：总批次数、每批测试点数"""
    data_dir = args.data_dir
    task_id = args.task_id

    p5_path = os.path.join(data_dir, "p5_output.json")
    if not os.path.exists(p5_path):
        print(json.dumps({"status": "error", "reason": "p5_output.json不存在"}))
        sys.exit(1)

    p5 = _read_json(p5_path)
    test_points = p5.get("test_points", [])
    total = len(test_points)
    batch_size = 10
    total_batches = (total + batch_size - 1) // batch_size

    print(json.dumps({
        "status": "ok",
        "total_test_points": total,
        "batch_size": batch_size,
        "total_batches": total_batches,
    }))


# ============================================================
# Action: p6_merge (P6批次合并)
# ============================================================

def action_p6_merge(args):
    """合并P6所有批次结果，写入p6_output.tmp.json，调用truncation_guard"""
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir

    # 扫描p6_batches目录
    batches_dir = os.path.join(data_dir, "p6_batches")
    if not os.path.exists(batches_dir):
        print(json.dumps({"status": "error", "reason": "p6_batches目录不存在"}))
        sys.exit(1)

    all_cases = []
    batch_files = sorted(glob.glob(os.path.join(batches_dir, "batch_*.json")))

    for bf in batch_files:
        try:
            batch_data = _read_json(bf)
            cases = batch_data.get("testcases", batch_data.get("cases", []))
            all_cases.extend(cases)
        except Exception as e:
            print(json.dumps({"status": "warning", "reason": f"批次文件读取失败: {bf}: {e}"}), file=sys.stderr)

    if not all_cases:
        print(json.dumps({"status": "error", "reason": "所有批次合并后用例数为0"}))
        sys.exit(1)

    # 统计
    p0_count = sum(1 for c in all_cases if c.get("priority", "").upper() in ("P0", "HIGHEST"))
    smoke_count = sum(1 for c in all_cases if c.get("is_smoke", "") in ("是", "Y", "yes", True))

    # 按优先级统计
    by_priority = {}
    for c in all_cases:
        p = c.get("priority", "unknown").upper()
        by_priority[p] = by_priority.get(p, 0) + 1

    merged = {
        "testcases": all_cases,
        "statistics": {
            "total": len(all_cases),
            "by_priority": by_priority,
            "smoke_count": smoke_count,
            "p0_count": p0_count,
            "batch_count": len(batch_files),
        }
    }

    # 写入tmp
    tmp_path = os.path.join(data_dir, "p6_output.tmp.json")
    _write_json(tmp_path, merged)

    # truncation_guard
    ok, msg = run_truncation_guard(skill_dir, data_dir, task_id, "P6")

    if ok:
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete("P6")
        print(json.dumps({
            "status": "ok",
            "total_cases": len(all_cases),
            "smoke_count": smoke_count,
            "batches_merged": len(batch_files),
            "guard_result": msg,
        }))
    else:
        print(json.dumps({"status": "guard_failed", "reason": msg}))
        sys.exit(1)


# ============================================================
# Action: p6_save_batch (保存P6单批结果)
# ============================================================

def action_p6_save_batch(args):
    """保存P6单批结果到p6_batches/batch_N.json"""
    data_dir = args.data_dir
    batch_index = int(args.batch_index) if args.batch_index else 1
    agent_output = args.agent_output

    try:
        batch_data = json.loads(agent_output)
    except Exception:
        import re
        match = re.search(r'\{[\s\S]*\}', agent_output)
        if match:
            try:
                batch_data = json.loads(match.group())
            except Exception:
                print(json.dumps({"status": "error", "reason": "P6批次JSON解析失败"}))
                sys.exit(1)
        else:
            print(json.dumps({"status": "error", "reason": "P6批次输出不含JSON"}))
            sys.exit(1)

    batches_dir = os.path.join(data_dir, "p6_batches")
    _ensure_dir(batches_dir)

    batch_path = os.path.join(batches_dir, f"batch_{batch_index:03d}.json")
    _write_json(batch_path, batch_data)

    cases = batch_data.get("testcases", batch_data.get("cases", []))
    print(json.dumps({
        "status": "ok",
        "batch_index": batch_index,
        "cases_in_batch": len(cases),
        "batch_file": batch_path,
    }))


# ============================================================
# Action: quality_check (质量校验强化)
# ============================================================

# 每步最小产出数量
# 每步最小产出数量（以云端实际JSON字段名为真源，支持多候选路径用|分隔）
MIN_OUTPUT_COUNTS = {
    "P0": {"blocks.operations|blocks.pages|blocks.business_rules": 1},  # P0实际输出用blocks.operations/pages/business_rules
    "P1": {"feature_tree.modules|modules": 2},  # P1实际输出用feature_tree.modules或顶层modules
    "P2": {"test_points": 8},
    "P3": {"risk_points": 1},  # 至少1个风险点
    "P4": {"pci_list": 1},  # 至少1个PCI
    "P5": {"test_points": 10},
    "P6": {"testcases": 15},
}

# P6用例质量规则（V3.0.3统一真源，prep_prompt和quality_check共用）
P6_QUALITY_RULES = {
    "smoke_ratio_min": 0.08,  # 冒烟用例至少8%
    "smoke_ratio_max": 0.20,  # 冒烟用例不超过20%
    "p0_ratio_max": 0.40,  # P0优先级不超过40%
    "all_same_priority": False,  # 不允许所有用例同一优先级
    "per_requirement_smoke": True,  # 每个需求至少1条冒烟用例
}

def _get_nested(data, key_path):
    """获取嵌套字段值，支持多候选路径（用|分隔）
    
    示例:
      _get_nested(data, "blocks.modules")  # 单路径
      _get_nested(data, "blocks.operations|blocks.pages")  # 多候选，返回第一个非空的
    """
    candidates = key_path.split("|")
    for candidate in candidates:
        keys = candidate.strip().split(".")
        current = data
        for k in keys:
            if isinstance(current, dict):
                current = current.get(k)
            else:
                current = None
                break
        if current is not None:
            return current
    return None

def action_quality_check(args):
    """对指定步骤的产出进行质量校验"""
    data_dir = args.data_dir
    step = args.step

    output_path = os.path.join(data_dir, f"{step.lower()}_output.json")
    if not os.path.exists(output_path):
        print(json.dumps({"status": "error", "reason": f"{step}产出文件不存在"}))
        sys.exit(1)

    data = _read_json(output_path)
    issues = []
    warnings = []

    # 1. 最小产出数量校验
    if step in MIN_OUTPUT_COUNTS:
        for field_path, min_count in MIN_OUTPUT_COUNTS[step].items():
            value = _get_nested(data, field_path)
            if value is None:
                issues.append(f"字段{field_path}不存在")
            elif isinstance(value, list) and len(value) < min_count:
                issues.append(f"{field_path}数量{len(value)}<最小要求{min_count}")
            elif isinstance(value, (int, float)) and value < min_count:
                issues.append(f"{field_path}值{value}<最小要求{min_count}")

    # 2. P0质量评分校验
    if step == "P0":
        score = data.get("quality_score", 0)
        if score < 0.5:
            issues.append(f"质量评分{score}<0.5，需求结构化质量太低")
        elif score < 0.7:
            warnings.append(f"质量评分{score}<0.7，建议补充需求")

    # 3. P6用例质量校验
    if step == "P6":
        cases = data.get("testcases", [])
        total = len(cases)
        if total > 0:
            smoke = sum(1 for c in cases if c.get("is_smoke", "") in ("是", "Y", "yes", True))
            p0 = sum(1 for c in cases if c.get("priority", "").upper() in ("P0", "HIGHEST"))

            smoke_ratio = smoke / total
            p0_ratio = p0 / total

            # 冒烟比例超限→拒绝（与prep_prompt注入规则一致）
            if smoke_ratio < P6_QUALITY_RULES["smoke_ratio_min"]:
                issues.append(f"冒烟用例比例{smoke_ratio:.1%}<{P6_QUALITY_RULES['smoke_ratio_min']:.0%}，不达标")
            if smoke_ratio > P6_QUALITY_RULES["smoke_ratio_max"]:
                issues.append(f"冒烟用例比例{smoke_ratio:.1%}>{P6_QUALITY_RULES['smoke_ratio_max']:.0%}，过高")
            if p0_ratio > P6_QUALITY_RULES["p0_ratio_max"]:
                issues.append(f"P0优先级占比{p0_ratio:.1%}>{P6_QUALITY_RULES['p0_ratio_max']:.0%}，优先级分布异常")

            # 检查是否所有用例同一优先级
            priorities = set(c.get("priority", "") for c in cases)
            if len(priorities) == 1 and total > 5:
                issues.append(f"所有{total}条用例都是{priorities.pop()}优先级，分布异常")

            # 每需求至少1条冒烟用例（与prep_prompt注入规则一致）
            if P6_QUALITY_RULES.get("per_requirement_smoke"):
                req_smoke = {}
                for c in cases:
                    req = c.get("requirement", c.get("module", "unknown"))
                    if req not in req_smoke:
                        req_smoke[req] = False
                    if c.get("is_smoke", "") in ("是", "Y", "yes", True):
                        req_smoke[req] = True
                no_smoke_reqs = [r for r, has in req_smoke.items() if not has]
                if no_smoke_reqs and len(req_smoke) > 1:
                    warnings.append(f"{len(no_smoke_reqs)}个需求无冒烟用例: {', '.join(no_smoke_reqs[:3])}")

    passed = len(issues) == 0
    # P7失败时提供回流指引
    retry_hint = None
    if not passed and step == "P7":
        retry_hint = "P7质量自检失败，建议重新执行P6用例展开（从 prep_prompt P6 重新开始）"
    if not passed and step == "P6":
        retry_hint = "P6质量校验失败，建议重新执行P6全部批次"

    print(json.dumps({
        "status": "ok" if passed else "quality_failed",
        "step": step,
        "passed": passed,
        "issues": issues,
        "warnings": warnings,
        "retry_hint": retry_hint,
    }))
    if not passed:
        sys.exit(1)


# ============================================================
# 主入口
# ============================================================


# ============================================================
# Action: check_image_api (验证图片理解API密码)
# ============================================================

def action_check_image_api(args):
    """验证用户输入的API密码是否正确"""
    skill_dir = args.skill_dir
    api_key = getattr(args, 'api_key', '') or ''

    if not api_key.strip():
        print(json.dumps({"status": "skipped", "reason": "未输入密码，将使用纯文本模式"}))
        return

    config = _load_image_api_config(skill_dir, api_key=api_key)

    if not config["enabled"]:
        reason = config.get("_invalid_reason", "API地址未配置")
        print(json.dumps({"status": "error", "reason": reason}))
        return

    # V3.0.3-patch1: 调用auth-check验证密码（不再用health，因为health不鉴权）
    ok, data = _check_image_api_health(config)

    if ok:
        # V3.2.0: 验证成功后缓存密码到task目录（解决Agent跨段落丢密码问题）
        # 密码只在当前task生命周期内有效，不会泄露到其他任务
        data_dir = getattr(args, 'data_dir', '') or ''
        if data_dir and os.path.isdir(data_dir):
            cache_path = os.path.join(data_dir, ".image_api_key")
            try:
                with open(cache_path, "w") as f:
                    f.write(api_key)
                os.chmod(cache_path, 0o600)  # 只有owner可读写
            except Exception:
                pass  # 缓存失败不阻塞流程
        print(json.dumps({
            "status": "ok",
            "message": "密码验证成功，图片理解API已启用",
            "provider": config["model"],
            "ci_configured": data.get("ci_configured", True),
            "qwen_configured": data.get("qwen_configured", False),
            "key_cached": bool(data_dir),
        }))
    else:
        error = data.get("error", "unknown")
        message = data.get("message", "")
        # 精确区分密码错误/服务未配置/服务不可用
        if error == "auth_failed":
            print(json.dumps({"status": "auth_failed", "reason": "密码错误，请重新输入或回复「跳过」使用纯文本模式"}))
        elif error == "service_not_configured":
            print(json.dumps({"status": "service_error", "reason": f"API服务未配置密码验证: {message}"}))
        elif error == "connection_failed":
            print(json.dumps({"status": "service_error", "reason": f"无法连接API服务，请检查API地址: {message}"}))
        elif error == "timeout":
            print(json.dumps({"status": "service_error", "reason": "API服务响应超时，请稍后重试"}))
        else:
            print(json.dumps({"status": "service_error", "reason": f"API服务暂不可用: {message or error}"}))


# ============================================================
# Action: restart_from (从指定步骤重新开始)
# ============================================================

def action_restart_from(args):
    """从指定步骤重新开始：清除该步及后续的gate pass和output"""
    data_dir = args.data_dir
    task_id = args.task_id
    step = args.step.upper()

    if step not in GATE_STEPS:
        print(json.dumps({"status": "error", "reason": f"无效步骤: {step}，可选: {GATE_STEPS}"}))
        sys.exit(1)

    # 找到该步骤及后续所有步骤
    step_idx = GATE_STEPS.index(step)
    steps_to_clear = GATE_STEPS[step_idx:]

    gates_dir = os.path.join(data_dir, "gates")
    cleared = []
    for s in steps_to_clear:
        # 清除gate pass
        gp = os.path.join(gates_dir, f"{s}.pass.json")
        if os.path.exists(gp):
            os.remove(gp)
            cleared.append(f"{s}.pass.json")
        # 清除output
        for suffix in ["_output.json", "_output.tmp.json", "_output.prev.json"]:
            op = os.path.join(data_dir, f"{s.lower()}{suffix}")
            if os.path.exists(op):
                os.remove(op)
                cleared.append(f"{s.lower()}{suffix}")

    # 更新state
    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.state["completed_steps"] = [s for s in state.state["completed_steps"] if s not in [st.lower() for st in steps_to_clear] and s not in steps_to_clear]
    state.save()

    print(json.dumps({
        "status": "ok",
        "restart_from": step,
        "cleared_files": cleared,
        "next_step": step,
    }))


def main():
    parser = argparse.ArgumentParser(description="V3.0 Orchestrator")
    parser.add_argument("--action", required=True, choices=[
        "init", "onboarding", "step0", "step0_8_prep", "step0_8_save",
        "step_run", "step7_export", "status", "resume",
        "prep_prompt", "p5_code_merge", "p6_batch_info", "p6_save_batch", "p6_merge",
        "quality_check",
        "restart_from", "check_image_api"
    ])
    parser.add_argument("--skill-dir", default="")
    parser.add_argument("--data-dir", default="")
    parser.add_argument("--task-id", default="")
    parser.add_argument("--requirement-text", default="")
    parser.add_argument("--requirement-file", default="")
    parser.add_argument("--step", default="")
    parser.add_argument("--agent-output", default="")  # 兼容保留，优先从文件读
    parser.add_argument("--results-json", default="")  # 兼容保留，优先从文件读
    parser.add_argument("--batch-index", default="0")
    parser.add_argument("--api-key", default="", help="图片理解API密钥（Onboarding时用户输入，不落盘）")

    args = parser.parse_args()

    # === V3.0.0-patch3: 参数自动化 ===
    # 1. skill_dir自动发现
    try:
        args.skill_dir = resolve_skill_dir(args.skill_dir)
    except ValueError as e:
        print(json.dumps({"status": "error", "reason": str(e)}))
        sys.exit(1)

    # 2. data_dir/task_id自动回填（非init action时）
    if args.action != "init":
        if not args.data_dir or not args.task_id:
            auto_tid, auto_dir = find_latest_task()
            if auto_tid and auto_dir:
                if not args.task_id:
                    args.task_id = auto_tid
                if not args.data_dir:
                    args.data_dir = auto_dir
            else:
                if args.action not in ("status",):
                    print(json.dumps({"status": "error", "reason": "未找到活跃任务，请先执行 --action init"}))
                    sys.exit(1)

    # 3. agent-output从文件读取（优先级：文件 > 命令行参数）
    if args.action in ("step_run", "p6_save_batch") and not args.agent_output:
        step = args.step or "unknown"
        if args.action == "p6_save_batch":
            batch_idx = int(args.batch_index) if args.batch_index else 1
            agent_file = os.path.join(args.data_dir, f"p6_batch_{batch_idx:03d}_agent_output.json")
        else:
            agent_file = os.path.join(args.data_dir, f"{step.lower()}_agent_output.json")
        if os.path.exists(agent_file):
            args.agent_output = _read_file_safe(agent_file, 100000)

    # 4. results-json从文件读取
    if args.action == "step0_8_save" and not args.results_json:
        results_file = os.path.join(args.data_dir, "px_agent_results.json")
        if os.path.exists(results_file):
            args.results_json = _read_file_safe(results_file, 100000)

    actions = {
        "init": action_init,
        "onboarding": action_onboarding,
        "step0": action_step0,
        "step0_8_prep": action_step0_8_prep,
        "step0_8_save": action_step0_8_save,
        "step_run": action_step_run,
        "step7_export": action_step7_export,
        "status": action_status,
        "resume": action_resume,
        "prep_prompt": action_prep_prompt,
        "p5_code_merge": action_p5_code_merge,
        "p6_batch_info": action_p6_batch_info,
        "p6_save_batch": action_p6_save_batch,
        "p6_merge": action_p6_merge,
        "quality_check": action_quality_check,
        "restart_from": action_restart_from,
        "check_image_api": action_check_image_api,
    }

    try:
        actions[args.action](args)
    except SystemExit:
        raise
    except Exception as e:
        print(json.dumps({"status": "error", "reason": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
