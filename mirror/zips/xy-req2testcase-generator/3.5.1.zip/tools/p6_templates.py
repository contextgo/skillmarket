#!/usr/bin/env python3
"""
V3.4.0 P6模板引擎 — 基于P5测试点自动生成完整用例
用于hybrid模式的p6_code_generate action

每种category一套模板，通过关键词提取+变体词组实现差异化。
"""

import re
import json
from collections import Counter


# ============================================================
# 关键词提取
# ============================================================

def extract_keywords(description, precondition=""):
    """从description中提取关键操作词和对象"""
    # 提取动词+宾语
    action_patterns = [
        r'(查看|导入|导出|上传|下载|点击|切换|输入|删除|新增|修改|编辑|搜索|筛选|排序|推送|同步|验证|提交|审核|登录|退出)',
        r'(展示|显示|隐藏|加载|刷新|跳转|返回|保存|取消|确认|关闭|打开)',
    ]
    actions = []
    for pat in action_patterns:
        actions.extend(re.findall(pat, description))

    # 提取操作对象（名词短语）
    object_patterns = [
        r'([\u4e00-\u9fa5]{2,8}(?:Tab|页面|列表|表格|按钮|字段|弹窗|菜单|模块|榜单|数据|文件|报表))',
        r'([\u4e00-\u9fa5]{2,6}(?:功能|入口|权限|角色|状态))',
    ]
    objects = []
    for pat in object_patterns:
        objects.extend(re.findall(pat, description))

    # 提取角色
    role_patterns = [
        r'(管理员|运营人员|业务人员|普通用户|机构用户|员工|客户)',
    ]
    roles = []
    for pat in role_patterns:
        roles.extend(re.findall(pat, description + " " + precondition))

    return {
        "actions": actions[:3] if actions else ["操作"],
        "objects": objects[:3] if objects else ["相关功能"],
        "roles": roles[:2] if roles else ["用户"],
        "desc_short": description[:30],
    }


# ============================================================
# 步骤动词变体（避免重复）
# ============================================================

VERB_VARIANTS = {
    "查看": ["查看", "浏览", "检查"],
    "点击": ["点击", "单击", "选择"],
    "输入": ["输入", "填写", "录入"],
    "验证": ["验证", "确认", "检查"],
    "进入": ["进入", "打开", "访问"],
}

_variant_counter = Counter()

def get_variant(verb):
    """获取动词变体，轮换使用避免重复"""
    variants = VERB_VARIANTS.get(verb, [verb])
    idx = _variant_counter[verb] % len(variants)
    _variant_counter[verb] += 1
    return variants[idx]


# ============================================================
# 模板定义（11套）
# ============================================================

def _gen_main_flow(tp, case_idx, kw):
    """main_flow: 主流程正向验证"""
    role = kw["roles"][0]
    obj = kw["objects"][0] if kw["objects"] else "相关功能"
    action = kw["actions"][0] if kw["actions"] else "操作"

    if case_idx == 1:  # 正向验证
        steps = [
            f"1. 使用{role}账号登录CRM系统",
            f"2. {get_variant('进入')}{obj}页面",
            f"3. {get_variant(action)}{kw['desc_short'][:15]}",
        ]
        expected = [
            "1. 登录成功，进入系统首页",
            f"2. {obj}页面正常加载，数据展示完整",
            f"3. {action}成功，结果符合业务规则",
        ]
    else:  # 异常/边界变体
        steps = [
            f"1. 使用{role}账号登录CRM系统",
            f"2. {get_variant('进入')}{obj}页面",
            f"3. 构造异常条件（如数据为空/网络超时/并发操作）",
        ]
        expected = [
            "1. 登录成功",
            f"2. {obj}页面正常加载",
            "3. 系统给出明确错误提示，数据不受影响",
        ]
    return steps, expected


def _gen_branch(tp, case_idx, kw):
    """branch: 分支逻辑验证"""
    obj = kw["objects"][0] if kw["objects"] else "目标元素"

    if case_idx == 1:
        steps = [
            f"1. 登录CRM系统，进入相关页面",
            f"2. 定位{obj}，确认当前状态",
            f"3. 执行分支操作（{kw['desc_short'][:15]}）",
        ]
        expected = [
            "1. 登录成功，页面正常展示",
            f"2. {obj}状态正确显示",
            "3. 分支逻辑正确执行，结果符合预期",
        ]
    else:
        steps = [
            f"1. 登录CRM系统，进入相关页面",
            f"2. 构造非预期分支条件",
            f"3. 观察系统处理逻辑",
        ]
        expected = [
            "1. 登录成功",
            "2. 系统正确识别非预期条件",
            "3. 走入正确的异常分支，给出合理提示",
        ]
    return steps, expected


def _gen_integration(tp, case_idx, kw):
    """integration: 功能间联动验证"""
    if case_idx == 1:
        steps = [
            f"1. 登录CRM系统，完成前置操作（{kw['desc_short'][:12]}的前置条件）",
            f"2. 执行当前操作（依赖前置结果）",
            f"3. 验证上下游数据一致性",
        ]
        expected = [
            "1. 前置操作成功，产生预期数据",
            "2. 当前操作成功，正确引用前置数据",
            "3. 关联数据同步更新，无数据不一致",
        ]
    else:
        steps = [
            f"1. 登录CRM系统，前置操作产生异常数据",
            f"2. 执行当前操作（依赖异常前置数据）",
            f"3. 观察系统处理",
        ]
        expected = [
            "1. 前置操作完成（含异常数据）",
            "2. 系统检测到数据异常，给出提示",
            "3. 不产生脏数据，事务回滚或拒绝操作",
        ]
    return steps, expected


def _gen_permission(tp, case_idx, kw):
    """permission: 权限控制验证"""
    obj = kw["objects"][0] if kw["objects"] else "受限功能"

    if case_idx == 1:  # 无权限访问
        steps = [
            f"1. 使用无{obj}权限的普通账号登录CRM系统",
            f"2. 尝试访问{obj}页面（直接输入URL或点击菜单）",
            f"3. 观察系统响应",
        ]
        expected = [
            "1. 登录成功（普通账号）",
            f"2. 系统拒绝访问或隐藏{obj}入口",
            "3. 显示权限不足提示，不泄露受限数据",
        ]
    else:  # 越权操作
        steps = [
            f"1. 使用低权限账号登录CRM系统",
            f"2. 通过接口/URL直接请求{obj}的操作接口",
            f"3. 观察系统响应",
        ]
        expected = [
            "1. 登录成功",
            "2. 接口返回403或权限校验失败",
            "3. 操作被拒绝，数据未被修改",
        ]
    return steps, expected


def _gen_exception(tp, case_idx, kw):
    """exception: 异常场景验证"""
    obj = kw["objects"][0] if kw["objects"] else "相关功能"

    if case_idx == 1:
        steps = [
            f"1. 登录CRM系统，进入{obj}页面",
            f"2. 构造异常输入（空值/超长/特殊字符/非法格式）",
            f"3. 提交操作并观察系统响应",
        ]
        expected = [
            f"1. {obj}页面正常加载",
            "2. 系统接受输入或前端校验拦截",
            "3. 给出明确错误提示（如「输入格式不正确」），数据不受影响",
        ]
    else:
        steps = [
            f"1. 登录CRM系统，进入{obj}页面",
            f"2. 模拟系统异常（如后端超时/数据库连接失败）",
            f"3. 观察前端表现",
        ]
        expected = [
            f"1. {obj}页面正常加载",
            "2. 触发异常条件",
            "3. 前端显示友好错误提示（非技术堆栈），支持重试",
        ]
    return steps, expected


def _gen_boundary(tp, case_idx, kw):
    """boundary: 边界值验证"""
    obj = kw["objects"][0] if kw["objects"] else "输入字段"

    if case_idx == 1:  # 边界内
        steps = [
            f"1. 登录CRM系统，进入相关页面",
            f"2. 在{obj}中输入边界值（最大值/最小值/临界值）",
            f"3. 提交并验证处理结果",
        ]
        expected = [
            "1. 页面正常加载",
            "2. 系统接受边界值输入",
            "3. 数据正确处理，结果符合业务规则",
        ]
    else:  # 超出边界
        steps = [
            f"1. 登录CRM系统，进入相关页面",
            f"2. 在{obj}中输入超出边界的值（超大/超小/溢出）",
            f"3. 提交并观察系统响应",
        ]
        expected = [
            "1. 页面正常加载",
            "2. 前端校验拦截或后端返回错误",
            "3. 给出明确提示（如「数值超出范围」），不产生异常数据",
        ]
    return steps, expected


def _gen_compatibility(tp, case_idx, kw):
    """compatibility: 兼容性验证"""
    obj = kw["objects"][0] if kw["objects"] else "相关功能"

    if case_idx == 1:
        steps = [
            f"1. 使用Chrome浏览器登录CRM系统",
            f"2. 进入{obj}页面，执行核心操作",
            f"3. 切换到Firefox/Edge浏览器重复操作",
        ]
        expected = [
            "1. Chrome下功能正常",
            f"2. {obj}操作成功，数据正确",
            "3. 其他浏览器下功能表现一致，无兼容性问题",
        ]
    else:
        steps = [
            f"1. 使用移动端浏览器访问CRM系统",
            f"2. 进入{obj}页面",
            f"3. 验证页面自适应和功能可用性",
        ]
        expected = [
            "1. 移动端可正常访问",
            "2. 页面自适应展示，无错位",
            "3. 核心功能可用，交互正常",
        ]
    return steps, expected


def _gen_performance(tp, case_idx, kw):
    """performance: 性能验证"""
    obj = kw["objects"][0] if kw["objects"] else "相关功能"

    if case_idx == 1:
        steps = [
            f"1. 登录CRM系统，准备大量测试数据（1000+条）",
            f"2. 进入{obj}页面，触发数据加载",
            f"3. 记录页面加载时间和响应速度",
        ]
        expected = [
            "1. 测试数据准备完成",
            f"2. {obj}页面在3秒内完成加载",
            "3. 列表滚动流畅，无卡顿，分页正常",
        ]
    else:
        steps = [
            f"1. 模拟10个用户并发访问{obj}",
            f"2. 每个用户执行相同操作",
            f"3. 观察系统响应和数据一致性",
        ]
        expected = [
            "1. 并发请求全部到达服务器",
            "2. 所有请求在5秒内返回",
            "3. 数据一致，无脏读/幻读",
        ]
    return steps, expected


def _gen_security(tp, case_idx, kw):
    """security: 安全验证"""
    obj = kw["objects"][0] if kw["objects"] else "输入字段"

    if case_idx == 1:
        steps = [
            f"1. 登录CRM系统，进入含{obj}的页面",
            f"2. 在输入框中注入特殊字符（<script>alert(1)</script>）",
            f"3. 提交并观察页面渲染",
        ]
        expected = [
            "1. 页面正常加载",
            "2. 系统对输入进行转义或拦截",
            "3. 页面不执行注入脚本，显示转义后的文本",
        ]
    else:
        steps = [
            f"1. 使用已过期的Token访问API接口",
            f"2. 尝试执行敏感操作",
            f"3. 观察系统响应",
        ]
        expected = [
            "1. 请求携带过期Token",
            "2. 系统返回401未授权",
            "3. 敏感操作被拒绝，引导重新登录",
        ]
    return steps, expected


def _gen_state_migration(tp, case_idx, kw):
    """state_migration: 状态迁移验证"""
    obj = kw["objects"][0] if kw["objects"] else "业务对象"

    if case_idx == 1:
        steps = [
            f"1. 登录CRM系统，创建{obj}（初始状态）",
            f"2. 执行状态变更操作（如提交/审核/完成）",
            f"3. 验证状态流转是否正确",
        ]
        expected = [
            f"1. {obj}创建成功，状态为初始态",
            "2. 状态变更成功，记录变更时间和操作人",
            "3. 状态流转符合业务规则，不可逆操作不可回退",
        ]
    else:
        steps = [
            f"1. 登录CRM系统，将{obj}置于特定状态",
            f"2. 尝试执行非法状态跳转（如从完成态回到初始态）",
            f"3. 观察系统响应",
        ]
        expected = [
            f"1. {obj}处于指定状态",
            "2. 系统拒绝非法状态跳转",
            "3. 给出明确提示，状态不变",
        ]
    return steps, expected


def _gen_api(tp, case_idx, kw):
    """api: 接口验证"""
    obj = kw["objects"][0] if kw["objects"] else "业务接口"

    if case_idx == 1:  # 正向
        steps = [
            f"1. 获取有效Token（通过登录接口）",
            f"2. 调用{obj}接口，传入合法参数",
            f"3. 验证响应状态码和返回数据",
        ]
        expected = [
            "1. Token获取成功",
            "2. 接口返回HTTP 200",
            "3. 响应体包含预期字段，数据正确",
        ]
    else:  # 异常参数
        steps = [
            f"1. 获取有效Token",
            f"2. 调用{obj}接口，传入非法参数（缺失必填/类型错误/超长）",
            f"3. 验证错误响应",
        ]
        expected = [
            "1. Token获取成功",
            "2. 接口返回HTTP 400/422",
            "3. 响应体包含明确错误码和错误描述",
        ]
    return steps, expected


# ============================================================
# 模板分发器
# ============================================================

TEMPLATE_GENERATORS = {
    "main_flow": _gen_main_flow,
    "branch": _gen_branch,
    "integration": _gen_integration,
    "permission": _gen_permission,
    "exception": _gen_exception,
    "boundary": _gen_boundary,
    "compatibility": _gen_compatibility,
    "performance": _gen_performance,
    "security": _gen_security,
    "state_migration": _gen_state_migration,
    "state": _gen_state_migration,  # 别名
    "api": _gen_api,
    "interface": _gen_api,  # 别名
}


def generate_testcase(tp, case_idx, skeleton_entry):
    """为单条用例生成完整的fields内容

    Args:
        tp: P5测试点dict（含id/description/category/precondition等）
        case_idx: 用例序号（1=正向，2+=异常/边界）
        skeleton_entry: 骨架条目（含case_id/priority/is_smoke）

    Returns:
        dict: 完整的用例fields
    """
    category = (tp.get("category", "") or "main_flow").lower()
    description = tp.get("description", "")
    precondition = tp.get("precondition", "")
    related_rules = tp.get("related_rules", [])

    # 提取关键词
    kw = extract_keywords(description, precondition)

    # 选择模板生成器
    generator = TEMPLATE_GENERATORS.get(category, _gen_main_flow)
    steps, expected = generator(tp, case_idx, kw)

    # 构建前置条件（三要素）
    role = kw["roles"][0]
    precond_parts = [
        f"1. {role}已登录CRM系统，账户状态正常",
    ]
    if precondition:
        precond_parts.append(f"2. {precondition}")
    else:
        precond_parts.append("2. 预置相关测试数据，通过后台接口创建")
    precond_parts.append("3. 系统处于正常工作状态，相关服务可用")
    preconditions_text = "；".join(precond_parts)

    # 构建title
    case_type_map = {1: "正向验证", 2: "异常验证", 3: "边界验证"}
    case_type_label = case_type_map.get(case_idx, "补充验证")
    title = f"{description[:30]}-{case_type_label}"

    # 构建test_case_type
    type_map = {
        "main_flow": "正向验证",
        "branch": "分支验证",
        "integration": "集成异常",
        "permission": "权限验证",
        "exception": "异常处理",
        "boundary": "边界验证",
        "compatibility": "兼容回归",
        "performance": "性能验证",
        "security": "安全验证",
        "state_migration": "状态迁移",
        "state": "状态迁移",
        "api": "接口验证",
        "interface": "接口验证",
    }
    test_case_type = type_map.get(category, "正向验证")
    if case_idx > 1 and category in ("main_flow", "branch"):
        test_case_type = "异常处理"

    # 构建test_category
    cat_map = {
        "performance": "性能",
        "security": "安全",
        "compatibility": "兼容性",
    }
    test_category = cat_map.get(category, "功能")

    # 构建remarks
    remarks_prefix_map = {
        "main_flow": "[前台功能/正向流程]",
        "branch": "[前台功能/正向流程]",
        "exception": "[前台功能/异常处理]",
        "boundary": "[前台功能/边界值]",
        "permission": "[权限控制]",
        "performance": "[性能]",
        "security": "[安全]",
        "compatibility": "[兼容性]",
        "integration": "[后台功能/正向流程]",
        "state_migration": "[前台功能/正向流程]",
        "state": "[前台功能/正向流程]",
        "api": "[后台功能/正向流程]",
        "interface": "[后台功能/正向流程]",
    }
    remarks_prefix = remarks_prefix_map.get(category, "[前台功能/正向流程]")
    rules_text = f" 关联规则:{'、'.join(related_rules)}" if related_rules else ""
    remarks = f"{remarks_prefix}{rules_text}"

    # 构建automation_score
    automation_score = {
        "ui_stability": 4,
        "data_dependency": 3,
        "assertion_clarity": 4,
        "environment_dependency": 3,
        "execution_time": 4,
        "maintenance_cost": 3,
    }

    # 组装fields
    fields = {
        "title": title,
        "preconditions": preconditions_text,
        "steps": "\n".join(steps),
        "expected_results": "\n".join(expected),
        "test_case_type": test_case_type,
        "test_category": test_category,
        "remarks": remarks,
        "automation_score": automation_score,
    }

    return fields


def generate_batch(test_points, skeleton_entries, batch_meta=None):
    """为一个批次生成全部用例

    Args:
        test_points: 本批次的P5测试点列表
        skeleton_entries: 本批次的骨架列表
        batch_meta: 批次元信息（可选）

    Returns:
        dict: 完整的batch JSON（含testcases和statistics）
    """
    # 构建测试点索引
    tp_map = {tp.get("id", ""): tp for tp in test_points}

    # 按source_test_point分组骨架
    from collections import defaultdict
    tp_cases = defaultdict(list)
    for sk in skeleton_entries:
        src = sk.get("source_test_point", "")
        tp_cases[src].append(sk)

    testcases = []
    for src_tp_id, skeletons in tp_cases.items():
        tp = tp_map.get(src_tp_id, {"description": src_tp_id, "category": "main_flow"})
        for idx, sk in enumerate(skeletons, 1):
            fields = generate_testcase(tp, idx, sk)
            testcases.append({
                "id": sk["case_id"],
                "source_test_point": src_tp_id,
                "priority": sk.get("priority", "P1"),
                "is_smoke": sk.get("is_smoke", False),
                "fields": fields,
            })

    # 统计
    pri_dist = Counter(tc.get("priority", "?") for tc in testcases)
    smoke_count = sum(1 for tc in testcases if tc.get("is_smoke"))

    return {
        "testcases": testcases,
        "statistics": {
            "total_cases": len(testcases),
            "smoke_count": smoke_count,
            "by_priority": dict(pri_dist),
            "generation_method": "code_template",
        }
    }
