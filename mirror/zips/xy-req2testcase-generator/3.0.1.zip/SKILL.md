---
name: xy-req2testcase-generator
description: "AI驱动的需求→测试用例生成能力。V3.0.1架构：orchestrator代码控制流程，Agent只负责生成内容。5段确认模式，用户掌控节奏。"
version: "3.0.1"
metadata:
  author: "券商科技测试团队"
  architecture: "orchestrator-driven"
---

# xy-req2testcase-generator V3.0.1

> 版本:3.0.0
> 架构:orchestrator代码控制 + Agent生成内容 + 5段确认模式

---

## 🔴 运行协议

**核心原则：orchestrator.py控制流程，Agent只负责执行prompt返回JSON。**

**参数自动化：orchestrator自动发现skill_dir、自动回填data_dir/task_id，Agent几乎不需要传参。**

**5段确认模式：流程分5段执行，每段结束等用户确认后继续。用户始终知道流程在哪一步。**

Agent在本技能中只做3类事情：
1. 调用orchestrator命令（exec）
2. 读取prompt文件并生成JSON结果，write到文件
3. 读取图片并描述内容（PX步骤）

**禁止Agent自行：**
- 决定下一步做什么（由orchestrator决定）
- 直接写入p*_output.json文件（由orchestrator通过truncation_guard写入）
- 绕过orchestrator（🔴 即使orchestrator报错，也不允许回退到"手动执行"模式，必须修复参数后重试）
- 输出JSON结构体到对话（只写文件）

**对话输出规则：每段只输出1行状态+确认提示。**

---

## 触发条件

「xy用例生成」「xy需求分析」「xy测试用例」「xy测试用例生成」「req2testcase」
「生成测试用例」「分析需求」「拆解功能点」「输出测试点」「需求评审」「帮我写用例」「这个需求怎么测」「PRD转测试用例」

---

## 🔴 5段确认模式

**需求载荷前置：** 触发后，如用户消息中不包含需求正文/需求附件/明确引用近期需求材料，仅输出：`请发送需求正文或需求文档，收到后立即开始分析。`

**收到需求后，按以下5段执行：**

---

### 📋 段落1：初始化 + Onboarding

**首先定位orchestrator（只需执行一次，后续复用$ORCH变量）：**
```
exec: ORCH=$(find ~/.openclaw ~/.local ~/skills /app/skills -name orchestrator.py -path "*/xy-req2testcase-generator/*" -print -quit 2>/dev/null) && echo "ORCH=$ORCH"
```
如果找到，后续所有命令使用 `python3 "$ORCH"` 调用。如果未找到，输出错误。

```
exec: python3 "$ORCH" --action init
→ 获得 task_id

exec: python3 "$ORCH" --action onboarding
→ 环境检查结果
```

然后执行Onboarding交互（暂停等用户选择）：
- PRD审查：开启/跳过（按references/onboarding.md中的P0.5流程，不经过orchestrator）
- L5知识库：上传/跳过

完成后输出：
```
✅ 段落1完成 | Onboarding通过 | task_id=xxx
📋 请回复「继续」开始需求分析
```

---

### 📋 段落2：需求接收 + 图片理解

用户回复"继续"/"好的"/"下一步"/"go"等确认意图后执行：

```
exec: python3 "$ORCH" --action step0 --requirement-file "{docx_path}"
→ 需求接收完成

exec: python3 "$ORCH" --action step0_8_prep --requirement-file "{docx_path}"
→ 如返回images_to_understand列表：
  对每张图片: read {图片路径} → 描述内容 → 收集结果
  write {DATA_DIR}/px_agent_results.json → 结果JSON
  exec: python3 "$ORCH" --action step0_8_save
→ 如返回skipped：跳过
```

完成后输出：
```
✅ 段落2完成 | 需求已解析 | 业务域:xxx | 图片N张
📋 请回复「继续」开始需求结构化
```

---

### 📋 段落3：需求结构化 + 模块拆解（P0 + P1）

用户确认后执行：

```
对 P0 和 P1 各执行：
  exec: python3 "$ORCH" --action prep_prompt --step P{N}
  → 获得 prompt_file 路径
  read {prompt_file} → 用推理能力生成JSON
  write {DATA_DIR}/p{n}_agent_output.json → JSON结果
  exec: python3 "$ORCH" --action step_run --step P{N}
  → orchestrator校验+truncation_guard+gate pass
```

完成后输出：
```
✅ 段落3完成 | P0评分:0.xx | P1模块:N个/功能点:M个
📋 请回复「继续」开始生成测试点
```

---

### 📋 段落4：测试点生成 + 合并（P2-P5）

用户确认后执行：

```
对 P2, P3, P4, P5 各执行同样的 prep_prompt → 生成JSON → write文件 → step_run 模式
```

完成后输出：
```
✅ 段落4完成 | 测试点:N条 | 风险:M条
📋 请回复「继续」开始生成测试用例
```

---

### 📋 段落5：用例生成 + 质检 + 导出（P6-P7 + Excel）

用户确认后执行：

```
exec: python3 "$ORCH" --action p6_batch_info
→ 获得 total_batches

对每个批次：
  exec: python3 "$ORCH" --action prep_prompt --step P6 --batch-index {N}
  read {prompt_file} → 生成JSON
  write {DATA_DIR}/p6_batch_{N}_agent_output.json → JSON
  exec: python3 "$ORCH" --action p6_save_batch --batch-index {N}

exec: python3 "$ORCH" --action p6_merge
→ 合并所有批次

P7同样执行 prep_prompt → 生成 → write → step_run

exec: python3 "$ORCH" --action step7_export
→ Excel导出
```

完成后输出：
```
✅ 全部完成 | 用例:N条 | 冒烟:M条 | Excel已生成
MEDIA:{excel_path}
💡 如需L6经验学习，可将评审结果发给我
```

---

## 用户交互指令

| 用户输入 | 含义 |
|---------|------|
| 继续/好的/下一步/go | 执行下一段 |
| 查看进度 | exec orchestrator.py --action status |
| 从P{N}重新开始 | exec: python3 "$ORCH" --action restart_from --step P{N} |
| 取消/停止 | 终止流程，保留已完成产物 |

## 断点续跑

用户发送"继续"时，如果当前任务有未完成步骤：
```
exec: python3 "$ORCH" --action resume
→ 获得 next_step，从对应段落继续
```

## 错误处理

| 错误 | 处理 |
|------|------|
| orchestrator返回error | 输出错误信息，🔴 不允许回退到手动模式，必须修复后重试 |
| orchestrator返回gate_blocked | 检查前置步骤是否完成 |
| orchestrator返回guard_failed | 重新生成JSON重试（最多1次） |
| orchestrator返回quality_failed | 按retry_hint重新执行对应步骤 |

## 引用文件

| 路径 | 说明 |
|------|------|
| tools/orchestrator.py | V3.0核心：流程控制器，14个action，参数自动化 |
| references/orchestrator_protocol.md | Agent↔orchestrator交互协议 |
| references/onboarding.md | Onboarding检查+交互流程 |
| references/step0-px.md | Step 0+PX详细指令（prompt参考源） |
| references/step1-4.md | P0-P5详细指令（prompt参考源） |
| references/step5-7.md | P6-P7+Excel详细指令（prompt参考源） |
| tools/truncation_guard.py | 四级截断检测+原子写入 |
| tools/export_excel.py | Excel导出（21列公司标准） |
| tools/image_extract.py | docx图片抽取 |
| tools/image_enhance.py | 图片理解增强聚合 |
| prompts/P0-P7_*.md | 各步骤Prompt模板 |

## 已知限制

1. Agent需配合orchestrator协议，不配合时orchestrator会重试但无法强制
2. 5段确认模式需要用户回复4次"继续"
3. Excel导出依赖openpyxl
4. 图片理解依赖Agent模型的视觉能力
