#!/usr/bin/env python3
"""
V3.0 Orchestrator — 测试用例生成流程控制器
代码控制流程，Agent只负责生成内容。

用法：
  由SKILL.md指导Agent调用：
  exec: python3 {SKILL_DIR}/tools/orchestrator.py --action <action> [--args ...]

支持的action：
  init          - 初始化任务（创建task_id, DATA_DIR）
  onboarding    - 执行Onboarding检查（环境/Python/路径）
  step0         - 接收需求，写入task_meta
  step0_8_prep  - PX图片抽取+选图（返回待Agent理解的图片列表）
  step0_8_save  - 保存Agent的图片理解结果+调用image_enhance
  step_run      - 执行P0-P7任一步骤（准备prompt输入，校验Agent输出，写文件+guard）
  step7_export  - 调用export_excel.py导出
  status        - 查看当前任务状态
  resume        - 断点续跑（检测已完成步骤，返回下一步）
"""

import argparse
import json
import hashlib
import os
import sys
import time
import subprocess
import glob
from pathlib import Path


# ============================================================
# 常量
# ============================================================

SKILL_VERSION = "3.0.1"
STEPS = ["onboarding", "step0", "step0_8", "P0", "P1", "P2", "P3", "P4", "P5", "P6", "P7", "step7"]
GATE_STEPS = ["onboarding", "P0", "P1", "P2", "P3", "P4", "P5", "P6", "P7"]

# P0必需顶层字段
P0_REQUIRED_FIELDS = ["quality_score", "blocks", "objective"]
P1_REQUIRED_FIELDS = ["modules"]
P5_REQUIRED_FIELDS = ["test_points", "merge_log"]
P6_REQUIRED_FIELDS = ["testcases", "statistics"]
P7_REQUIRED_FIELDS = ["quality_check"]

# 域识别关键词
# ============================================================
# 自动发现 SKILL_DIR（V3.0.0-patch3）
# ============================================================

DEFAULT_SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def resolve_skill_dir(cli_value=""):
    """自动发现skill_dir，带目录完整性校验"""
    candidate = cli_value or DEFAULT_SKILL_DIR
    required_files = [
        os.path.join(candidate, "tools", "export_excel.py"),
        os.path.join(candidate, "tools", "truncation_guard.py"),
        os.path.join(candidate, "prompts", "P0_requirement_structuring.md"),
    ]
    missing = [p for p in required_files if not os.path.exists(p)]
    if missing:
        # 尝试DEFAULT_SKILL_DIR作为兜底
        if cli_value and cli_value != DEFAULT_SKILL_DIR:
            return resolve_skill_dir("")  # 递归用默认值重试
        raise ValueError(f"skill_dir无效({candidate})，缺失: {[os.path.basename(p) for p in missing[:3]]}")
    return candidate


# ============================================================
# 自动发现最近任务（V3.0.0-patch3）
# ============================================================

def find_latest_task():
    """查找最近的未完成任务，返回(task_id, data_dir)或(None, None)"""
    base = os.path.expanduser("~/.openclaw/workspace/data")
    if not os.path.exists(base):
        return None, None
    tasks = sorted(glob.glob(os.path.join(base, "task_*")), reverse=True)
    for task_dir in tasks[:3]:  # 只看最近3个，减少串task风险
        state_path = os.path.join(task_dir, "orchestrator_state.json")
        if os.path.exists(state_path):
            try:
                state = _read_json(state_path)
                tid = state.get("task_id", "")
                # 未完成的任务（没有step7）
                if "step7" not in state.get("completed_steps", []):
                    return tid, task_dir
            except Exception:
                pass
    return None, None


DOMAIN_KEYWORDS = {
    "trade": ["交易", "委托", "撤单", "成交", "清算", "结算", "资金冻结", "T+1"],
    "asset_mgmt": ["资管", "净值", "申赎", "申购", "赎回", "衍生品", "期货", "期权", "保证金"],
    "risk_ctrl": ["风控", "预警", "限额", "合规检查", "风险控制"],
    "crm": ["客户", "跟进", "开户", "KYC", "客户经理", "客户关系"],
    "etrading": ["网上营业厅", "APP", "适当性", "产品推荐", "在线交易", "移动端", "H5"],
    "ops_mgmt": ["运营", "活动", "营销", "后台管理", "数据报表", "统计", "导出"],
    "compliance": ["合规", "证书", "从业", "监管", "报送", "资质", "执照"],
    "it_infra": ["部署", "监控", "服务器", "权限配置", "变更", "IT", "基础设施", "投行", "承销", "IPO"],
}


# ============================================================
# 工具函数
# ============================================================

def _ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def _write_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def _read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _file_exists(path):
    return os.path.exists(path) and os.path.getsize(path) > 10

def _sha256(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]

def _detect_domain(text, default="trade"):
    text_lower = text.lower()
    for domain, keywords in DOMAIN_KEYWORDS.items():
        for kw in keywords:
            if kw in text_lower:
                return domain
    return default


# ============================================================
# 状态管理
# ============================================================

class TaskState:
    """任务状态管理器"""

    def __init__(self, data_dir=None, task_id=None):
        self.task_id = task_id
        self.data_dir = data_dir
        self.state_path = os.path.join(data_dir, "orchestrator_state.json") if data_dir else None
        self.state = self._load()

    def _load(self):
        if self.state_path and os.path.exists(self.state_path):
            try:
                return _read_json(self.state_path)
            except Exception:
                pass
        return {
            "task_id": self.task_id,
            "data_dir": self.data_dir,
            "skill_dir": "",
            "current_step": None,
            "completed_steps": [],
            "current_phase": 1,
            "requirement_file": "",
            "skill_version": SKILL_VERSION,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
            "updated_at": None,
        }

    def save(self):
        if self.state_path:
            self.state["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%S+08:00")
            _write_json(self.state_path, self.state)

    def mark_complete(self, step):
        if step not in self.state["completed_steps"]:
            self.state["completed_steps"].append(step)
        self.state["current_step"] = step
        self.save()

    def is_complete(self, step):
        return step in self.state["completed_steps"]

    def get_next_step(self):
        for step in STEPS:
            if step not in self.state["completed_steps"]:
                return step
        return None


# ============================================================
# Gate Pass 管理
# ============================================================

def check_gate(data_dir, step, task_id):
    """检查指定步骤的gate pass是否存在且task_id一致"""
    gp_path = os.path.join(data_dir, "gates", f"{step}.pass.json")
    if not os.path.exists(gp_path):
        return False, f"{step}.pass.json不存在"
    try:
        gp = _read_json(gp_path)
        if gp.get("task_id") != task_id:
            return False, f"task_id不匹配: {gp.get('task_id')} != {task_id}"
        return True, "OK"
    except Exception:
        return False, f"{step}.pass.json读取失败"

def run_truncation_guard(skill_dir, data_dir, task_id, step, revision=1):
    """调用truncation_guard.py进行四级校验+auto-mv"""
    tmp_path = os.path.join(data_dir, f"{step.lower()}_output.tmp.json")
    guard_script = os.path.join(skill_dir, "tools", "truncation_guard.py")

    if not os.path.exists(guard_script):
        return False, "truncation_guard.py不存在"
    if not os.path.exists(tmp_path):
        return False, f"{tmp_path}不存在"

    cmd = [
        "python3", guard_script,
        "--file", tmp_path,
        "--step", step,
        "--data-dir", data_dir,
        "--task-id", task_id,
        "--revision", str(revision),
        "--auto-mv"
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

    if result.returncode == 0:
        return True, result.stdout.strip()
    else:
        return False, f"exit={result.returncode}: {result.stderr.strip() or result.stdout.strip()}"


# ============================================================
# Action: init
# ============================================================

def action_init(args):
    """初始化任务：创建task_id和DATA_DIR"""
    task_id = f"task_{time.strftime('%Y%m%d_%H%M%S')}"
    base_dir = os.path.expanduser("~/.openclaw/workspace/data")
    data_dir = os.path.join(base_dir, task_id)

    _ensure_dir(data_dir)
    _ensure_dir(os.path.join(data_dir, "gates"))

    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.state["skill_dir"] = resolve_skill_dir("")
    state.state["data_dir"] = data_dir
    state.save()

    print(json.dumps({
        "status": "ok",
        "task_id": task_id,
        "data_dir": data_dir,
    }))


# ============================================================
# Action: onboarding
# ============================================================

def action_onboarding(args):
    """执行Onboarding环境检查（非交互部分）"""
    skill_dir = args.skill_dir
    data_dir = args.data_dir
    task_id = args.task_id

    checks = []

    # 检查1: 文件完整性
    required_files = [
        "prompts/P0_requirement_structuring.md",
        "prompts/P1_feature_tree_generation.md",
        "prompts/P2_test_point_draft.md",
        "prompts/P6_testcase_generation.md",
        "prompts/P7_quality_gate.md",
        "tools/export_excel.py",
        "tools/truncation_guard.py",
        "tools/image_extract.py",
    ]
    missing = [f for f in required_files if not os.path.exists(os.path.join(skill_dir, f))]
    checks.append({
        "name": "file_integrity",
        "passed": len(missing) == 0,
        "missing": missing,
    })

    # 检查1.5: SKILL_DIR确认
    checks.append({
        "name": "skill_dir",
        "passed": os.path.exists(os.path.join(skill_dir, "tools", "export_excel.py")),
        "skill_dir": skill_dir,
    })

    # 检查2: Python + openpyxl
    try:
        result = subprocess.run(
            ["python3", "-c", "import openpyxl; print('ok')"],
            capture_output=True, text=True, timeout=10
        )
        openpyxl_ok = result.returncode == 0
    except Exception:
        openpyxl_ok = False
    checks.append({"name": "python_openpyxl", "passed": openpyxl_ok})

    # 检查0.5: 缓存检测
    cache_dir = os.path.expanduser("~/.openclaw/workspace/data")
    existing = sorted(glob.glob(os.path.join(cache_dir, "task_*")), reverse=True)[:3]
    checks.append({
        "name": "cache_detection",
        "existing_tasks": [os.path.basename(p) for p in existing],
    })

    all_passed = all(c.get("passed", True) for c in checks)

    # 写入onboarding.pass.json
    if all_passed:
        gate_path = os.path.join(data_dir, "gates", "onboarding.pass.json")
        _write_json(gate_path, {
            "step": "onboarding",
            "task_id": task_id,
            "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
            "checks": checks,
        })

        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.state["skill_dir"] = args.skill_dir
        state.state["data_dir"] = data_dir
        state.mark_complete("onboarding")

    print(json.dumps({
        "status": "ok" if all_passed else "blocked",
        "checks": checks,
        "onboarding_pass": all_passed,
    }))


# ============================================================
# Action: step0
# ============================================================

def action_step0(args):
    """Step 0: 接收需求，写入task_meta"""
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir
    requirement_text = args.requirement_text or ""
    requirement_file = args.requirement_file or ""

    # 门禁检查
    ok, msg = check_gate(data_dir, "onboarding", task_id)
    if not ok:
        print(json.dumps({"status": "gate_blocked", "step": "onboarding", "reason": msg}))
        sys.exit(1)

    # 如果是文件，提取文本
    if requirement_file and not requirement_text:
        if requirement_file.endswith(".docx"):
            try:
                result = subprocess.run(
                    ["python3", "-c", f"""
import zipfile, re
with zipfile.ZipFile("{requirement_file}") as z:
    xml = z.read("word/document.xml").decode("utf-8")
    text = re.sub(r"<[^>]+>", " ", xml)
    text = re.sub(r"\\s+", " ", text).strip()
    print(text[:50000])
"""],
                    capture_output=True, text=True, timeout=30
                )
                requirement_text = result.stdout.strip()
            except Exception as e:
                requirement_text = f"[docx解析失败: {e}]"
        else:
            try:
                with open(requirement_file, "r", encoding="utf-8") as f:
                    requirement_text = f.read()[:50000]
            except Exception:
                requirement_text = "[文件读取失败]"

    domain = _detect_domain(requirement_text)

    # 读取preferences
    prefs_path = os.path.join(skill_dir, "user_knowledge", "preferences.json")
    prefs = {}
    if os.path.exists(prefs_path):
        try:
            prefs = _read_json(prefs_path)
        except Exception:
            pass

    # 写入task_meta
    meta = {
        "task_id": task_id,
        "domain": domain,
        "requirement_text": requirement_text,
        "requirement_file": requirement_file,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "preferences": prefs,
        "skill_version": SKILL_VERSION,
        "requirement_hash": _sha256(requirement_text),
    }
    _write_json(os.path.join(data_dir, "task_meta.json"), meta)

    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.state["requirement_file"] = requirement_file
    state.state["current_phase"] = 2
    state.mark_complete("step0")

    print(json.dumps({
        "status": "ok",
        "task_id": task_id,
        "domain": domain,
        "requirement_length": len(requirement_text),
    }))


# ============================================================
# Action: step0_8_prep (PX图片抽取+选图)
# ============================================================

def action_step0_8_prep(args):
    """PX图片抽取+价值优先选图，返回待Agent理解的图片列表"""
    data_dir = args.data_dir
    skill_dir = args.skill_dir
    requirement_file = args.requirement_file or ""

    if not requirement_file or not requirement_file.endswith(".docx"):
        print(json.dumps({"status": "skipped", "reason": "非docx格式，跳过PX"}))
        return

    # 调用image_extract.py
    extract_script = os.path.join(skill_dir, "tools", "image_extract.py")
    px_images_dir = os.path.join(data_dir, "px_images")
    px_extract_path = os.path.join(data_dir, "px_extract.json")

    _ensure_dir(px_images_dir)

    result = subprocess.run(
        ["python3", extract_script, requirement_file,
         "--output-dir", px_images_dir,
         "--json-output", px_extract_path],
        capture_output=True, text=True, timeout=60
    )

    if result.returncode != 0 or not os.path.exists(px_extract_path):
        print(json.dumps({"status": "skipped", "reason": f"图片抽取失败: {result.stderr[:200]}"}))
        return

    extract_data = _read_json(px_extract_path)
    images = extract_data.get("images", [])

    if not images:
        print(json.dumps({"status": "skipped", "reason": "docx中无图片"}))
        return

    # 价值优先选图
    value_keywords = ["流程", "状态", "原型", "页面", "规则", "接口", "表格", "如下图", "见图"]
    scored = []
    for img in images:
        caption = (img.get("caption", "") or "").lower()
        before = (img.get("before_text", "") or "").lower()
        after = (img.get("after_text", "") or "").lower()
        context = caption + " " + before + " " + after

        score = 0
        for kw in value_keywords:
            if kw in context:
                score += 1

        # 跳过装饰性图片
        w = img.get("width", 100)
        h = img.get("height", 100)
        if (w < 50 and h < 50) or "logo" in context or "icon" in context:
            score = -1

        scored.append((score, img))

    scored.sort(key=lambda x: x[0], reverse=True)
    selected = [img for score, img in scored if score >= 0][:5]

    # 输出待Agent理解的图片列表
    to_understand = []
    for img in selected:
        to_understand.append({
            "image_id": img.get("image_id", ""),
            "file_path": img.get("file_path", ""),
            "caption": img.get("caption", ""),
            "before_text": (img.get("before_text", "") or "")[:200],
            "after_text": (img.get("after_text", "") or "")[:200],
        })

    print(json.dumps({
        "status": "ok",
        "total_images": len(images),
        "selected_count": len(selected),
        "images_to_understand": to_understand,
    }))


# ============================================================
# Action: step0_8_save (保存图片理解结果)
# ============================================================

def action_step0_8_save(args):
    """保存Agent的图片理解结果，调用image_enhance"""
    data_dir = args.data_dir
    skill_dir = args.skill_dir
    task_id = args.task_id
    results_json = args.results_json  # Agent返回的理解结果JSON字符串

    try:
        results = json.loads(results_json)
    except Exception:
        print(json.dumps({"status": "error", "reason": "图片理解结果JSON解析失败"}))
        return

    # 读取抽取数据获取总数
    px_extract_path = os.path.join(data_dir, "px_extract.json")
    total = 0
    if os.path.exists(px_extract_path):
        total = len(_read_json(px_extract_path).get("images", []))

    # 构造px_understand.json
    vision_count = sum(1 for r in results if r.get("understanding_mode") == "vision")

    # 构造skipped_images列表（未被选中的图片）
    skipped_images = []
    if os.path.exists(px_extract_path):
        all_images = _read_json(px_extract_path).get("images", [])
        selected_ids = set(r.get("image_id", "") for r in results)
        for img in all_images:
            if img.get("image_id", "") not in selected_ids:
                skipped_images.append({
                    "image_id": img.get("image_id", ""),
                    "file_path": img.get("file_path", ""),
                    "selected": False,
                    "selection_reason": "超出5张上限或未命中高价值关键词",
                    "understanding_mode": "skipped"
                })

    understand = {
        "task_id": task_id,
        "total_images": total,
        "selected_images": len(results),
        "results": results,
        "skipped_images": skipped_images,
        "summary": {
            "vision_count": vision_count,
            "caption_only_count": len(results) - vision_count,
            "skipped_count": total - len(results),
        }
    }
    _write_json(os.path.join(data_dir, "px_understand.json"), understand)

    # 调用image_enhance
    enhance_script = os.path.join(skill_dir, "tools", "image_enhance.py")
    enhance_output = os.path.join(data_dir, "px_enhance.json")

    result = subprocess.run(
        ["python3", enhance_script,
         os.path.join(data_dir, "px_understand.json"),
         "--output", enhance_output],
        capture_output=True, text=True, timeout=30
    )

    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.mark_complete("step0_8")

    print(json.dumps({
        "status": "ok",
        "vision_count": vision_count,
        "total": total,
        "enhance_ok": result.returncode == 0,
    }))


# ============================================================
# Action: step_run (执行P0-P7任一步骤)
# ============================================================

def action_step_run(args):
    """
    执行P0-P7任一步骤：
    1. 检查前置gate pass
    2. 准备prompt输入（读取上游产物+知识注入）
    3. 接收Agent的JSON输出
    4. 写入tmp → truncation_guard → gate pass
    """
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir
    step = args.step  # P0/P1/P2/P3/P4/P5/P6/P7
    agent_output = args.agent_output  # Agent返回的JSON字符串

    # 前置gate pass检查
    prerequisites = {
        "P0": ["onboarding"],
        "P1": ["P0"],
        "P2": ["P1"],
        "P3": ["P1"],
        "P4": ["P1"],
        "P5": ["P2", "P3", "P4"],
        "P6": ["P5"],
        "P7": ["P6"],
    }

    for prereq in prerequisites.get(step, []):
        ok, msg = check_gate(data_dir, prereq, task_id)
        if not ok:
            print(json.dumps({"status": "gate_blocked", "step": prereq, "reason": msg}))
            sys.exit(1)

    # 解析Agent输出
    try:
        output_data = json.loads(agent_output)
    except json.JSONDecodeError:
        # JSON解析兜底：尝试正则提取
        import re
        match = re.search(r'\{[\s\S]*\}', agent_output)
        if match:
            try:
                output_data = json.loads(match.group())
            except Exception:
                print(json.dumps({"status": "error", "reason": "Agent输出JSON解析失败（含正则兜底）"}))
                sys.exit(1)
        else:
            print(json.dumps({"status": "error", "reason": "Agent输出不含有效JSON"}))
            sys.exit(1)

    # 写入tmp文件
    tmp_path = os.path.join(data_dir, f"{step.lower()}_output.tmp.json")
    _write_json(tmp_path, output_data)

    # 调用truncation_guard
    ok, msg = run_truncation_guard(skill_dir, data_dir, task_id, step)

    if ok:
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete(step)
        print(json.dumps({"status": "ok", "step": step, "guard_result": msg}))
    else:
        print(json.dumps({"status": "guard_failed", "step": step, "reason": msg}))
        sys.exit(1)


# ============================================================
# Action: step7_export
# ============================================================

def action_step7_export(args):
    """Step 7: 调用export_excel.py导出"""
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir

    # 检查P5+P6+P7三个gate pass
    for step in ["P5", "P6", "P7"]:
        ok, msg = check_gate(data_dir, step, task_id)
        if not ok:
            print(json.dumps({"status": "gate_blocked", "step": step, "reason": msg}))
            sys.exit(1)

    # 读取task_meta获取文件名
    meta = _read_json(os.path.join(data_dir, "task_meta.json"))
    domain = meta.get("domain", "unknown")

    export_script = os.path.join(skill_dir, "tools", "export_excel.py")
    p6_path = os.path.join(data_dir, "p6_output.json")
    output_path = os.path.join(data_dir, f"测试用例_{task_id}.xlsx")

    result = subprocess.run(
        ["python3", export_script, "--input", p6_path, "--output", output_path],
        capture_output=True, text=True, timeout=60
    )

    if result.returncode == 0 and os.path.exists(output_path):
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete("step7")
        print(json.dumps({
            "status": "ok",
            "excel_path": output_path,
            "file_size": os.path.getsize(output_path),
        }))
    else:
        print(json.dumps({
            "status": "error",
            "reason": f"Excel导出失败: {result.stderr[:300]}",
        }))
        sys.exit(1)


# ============================================================
# Action: status
# ============================================================

def action_status(args):
    """查看当前任务状态"""
    data_dir = args.data_dir
    task_id = args.task_id

    state = TaskState(data_dir=data_dir, task_id=task_id)
    next_step = state.get_next_step()

    # 检查所有gate pass
    gates = {}
    gates_dir = os.path.join(data_dir, "gates")
    if os.path.exists(gates_dir):
        for f in os.listdir(gates_dir):
            if f.endswith(".pass.json"):
                step_name = f.replace(".pass.json", "")
                gates[step_name] = True

    print(json.dumps({
        "task_id": task_id,
        "completed_steps": state.state["completed_steps"],
        "next_step": next_step,
        "gates": gates,
    }))


# ============================================================
# Action: resume
# ============================================================

def action_resume(args):
    """断点续跑：检测已完成步骤，返回下一步"""
    data_dir = args.data_dir
    task_id = args.task_id

    state = TaskState(data_dir=data_dir, task_id=task_id)

    # 扫描gate pass补充completed_steps
    gates_dir = os.path.join(data_dir, "gates")
    if os.path.exists(gates_dir):
        for f in sorted(os.listdir(gates_dir)):
            if f.endswith(".pass.json"):
                step_name = f.replace(".pass.json", "")
                try:
                    gp = _read_json(os.path.join(gates_dir, f))
                    if gp.get("task_id") == task_id:
                        if step_name not in state.state["completed_steps"]:
                            state.state["completed_steps"].append(step_name)
                except Exception:
                    pass
        state.save()

    next_step = state.get_next_step()

    print(json.dumps({
        "status": "ok",
        "task_id": task_id,
        "completed_steps": state.state["completed_steps"],
        "next_step": next_step,
    }))


# ============================================================
# Action: prep_prompt (为每个P步骤准备完整prompt)
# ============================================================

# Prompt文件映射
PROMPT_FILES = {
    "P0": "prompts/P0_requirement_structuring.md",
    "P1": "prompts/P1_feature_tree_generation.md",
    "P2": "prompts/P2_test_point_draft.md",
    "P3": "prompts/P3_risk_identification.md",
    "P4": "prompts/P4_pci_identification.md",
    "P5": "prompts/P5_test_point_merge.md",
    "P6": "prompts/P6_testcase_generation.md",
    "P7": "prompts/P7_quality_gate.md",
}

# 每步需要的上游产物
UPSTREAM_FILES = {
    "P0": ["task_meta.json"],
    "P1": ["p0_output.json"],
    "P2": ["p1_output.json"],
    "P3": ["p1_output.json"],
    "P4": ["p1_output.json"],
    "P5": ["p2_output.json", "p3_output.json", "p4_output.json"],
    "P6": ["p5_output.json"],
    "P7": ["p6_output.json"],
}

# 知识注入映射
KNOWLEDGE_INJECT = {
    "P0": ["knowledge/industry/{domain}.md", "knowledge/methodology/design_methods.md"],
    "P1": ["knowledge/methodology/design_methods.md"],
    "P2": ["knowledge/methodology/boundary_rules.md", "knowledge/methodology/api_test_standard.md"],
    "P3": ["knowledge/industry/{domain}.md"],
    "P4": ["knowledge/industry/{domain}.md"],
    "P5": [],
    "P6": ["knowledge/company_standards/testcase_design_spec.md", "knowledge/defect_patterns/defect_schema.md"],
    "P7": [],
}

def _read_file_safe(path, max_chars=8000):
    """安全读取文件，不存在返回空字符串"""
    if not os.path.exists(path):
        return ""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()[:max_chars]
    except Exception:
        return ""

def action_prep_prompt(args):
    """为指定的P步骤准备完整prompt，输出给Agent执行"""
    skill_dir = args.skill_dir
    data_dir = args.data_dir
    task_id = args.task_id
    step = args.step
    batch_index = int(getattr(args, 'batch_index', 0))  # P6分批用，确保int类型

    if step not in PROMPT_FILES:
        print(json.dumps({"status": "error", "reason": f"不支持的步骤: {step}"}))
        sys.exit(1)

    # 前置gate pass检查
    prerequisites = {
        "P0": ["onboarding"], "P1": ["P0"], "P2": ["P1"],
        "P3": ["P1"], "P4": ["P1"], "P5": ["P2", "P3", "P4"],
        "P6": ["P5"], "P7": ["P6"],
    }
    for prereq in prerequisites.get(step, []):
        ok, msg = check_gate(data_dir, prereq, task_id)
        if not ok:
            print(json.dumps({"status": "gate_blocked", "step": prereq, "reason": msg}))
            sys.exit(1)

    # 1. 读取prompt模板
    prompt_path = os.path.join(skill_dir, PROMPT_FILES[step])
    prompt_template = _read_file_safe(prompt_path, 15000)
    if not prompt_template:
        print(json.dumps({"status": "error", "reason": f"Prompt文件不存在: {PROMPT_FILES[step]}"}))
        sys.exit(1)

    # 2. 读取上游产物
    upstream_data = {}
    for fname in UPSTREAM_FILES.get(step, []):
        fpath = os.path.join(data_dir, fname)
        content = _read_file_safe(fpath, 20000)
        if content:
            upstream_data[fname] = content

    # 3. 知识注入
    # 读取domain
    meta_path = os.path.join(data_dir, "task_meta.json")
    domain = "trade"
    requirement_text = ""
    if os.path.exists(meta_path):
        try:
            meta = _read_json(meta_path)
            domain = meta.get("domain", "trade")
            requirement_text = meta.get("requirement_text", "")
        except Exception:
            pass

    knowledge_texts = []
    for kpath_template in KNOWLEDGE_INJECT.get(step, []):
        kpath = os.path.join(skill_dir, kpath_template.replace("{domain}", domain))
        kt = _read_file_safe(kpath, 3000)
        if kt:
            knowledge_texts.append(kt)

    # 4. PX增强注入（如有）
    px_inject = ""
    px_enhance_path = os.path.join(data_dir, "px_enhance.json")
    if os.path.exists(px_enhance_path):
        try:
            px_data = _read_json(px_enhance_path)
            step_subsets = px_data.get("step_subsets", {})
            step_key = step  # P0/P1/...
            if step_key in step_subsets:
                px_inject = json.dumps(step_subsets[step_key], ensure_ascii=False)[:1500]
        except Exception:
            pass

    # 5. P6分批处理
    p6_batch_info = ""
    if step == "P6" and batch_index > 0:
        # 读取P5测试点，按批次切分
        p5_path = os.path.join(data_dir, "p5_output.json")
        if os.path.exists(p5_path):
            try:
                p5 = _read_json(p5_path)
                test_points = p5.get("test_points", [])
                batch_size = 10
                start = (batch_index - 1) * batch_size
                end = start + batch_size
                batch_points = test_points[start:end]
                total_batches = (len(test_points) + batch_size - 1) // batch_size
                p6_batch_info = f"\n---\n## 当前批次\n第{batch_index}/{total_batches}批，处理测试点{start+1}-{min(end, len(test_points))}:\n{json.dumps(batch_points, ensure_ascii=False)[:5000]}"
            except Exception:
                pass

    # 6. 组装完整prompt
    full_prompt_parts = [prompt_template]

    if knowledge_texts:
        full_prompt_parts.append("\n---\n## 注入知识\n" + "\n\n".join(knowledge_texts))

    if px_inject:
        full_prompt_parts.append(f"\n---\n## 图片理解增强\n{px_inject}")

    if upstream_data:
        full_prompt_parts.append("\n---\n## 输入数据")
        for fname, content in upstream_data.items():
            full_prompt_parts.append(f"\n### {fname}\n{content}")

    # P0需要需求文本
    if step == "P0" and requirement_text:
        full_prompt_parts.append(f"\n---\n## 需求文本\n{requirement_text[:15000]}")

    if p6_batch_info:
        full_prompt_parts.append(p6_batch_info)

    # P0内联必需字段提醒
    if step == "P0":
        full_prompt_parts.append("\n---\n## ❗ 输出必须包含以下顶层字段\n- quality_score: number (0~1.0)\n- blocks: object\n- objective: string")

    full_prompt = "\n".join(full_prompt_parts)

    # 输出
    result = {
        "status": "ok",
        "step": step,
        "prompt_length": len(full_prompt),
        "upstream_files": list(upstream_data.keys()),
        "knowledge_injected": len(knowledge_texts),
        "px_injected": bool(px_inject),
    }

    # 将prompt写入文件（太长不适合通过stdout传递）
    prompt_output_path = os.path.join(data_dir, f"{step.lower()}_prompt.txt")
    with open(prompt_output_path, "w", encoding="utf-8") as f:
        f.write(full_prompt)
    result["prompt_file"] = prompt_output_path

    print(json.dumps(result))


# ============================================================
# Action: p6_batch_info (P6分批信息)
# ============================================================

def action_p6_batch_info(args):
    """返回P6分批信息：总批次数、每批测试点数"""
    data_dir = args.data_dir
    task_id = args.task_id

    p5_path = os.path.join(data_dir, "p5_output.json")
    if not os.path.exists(p5_path):
        print(json.dumps({"status": "error", "reason": "p5_output.json不存在"}))
        sys.exit(1)

    p5 = _read_json(p5_path)
    test_points = p5.get("test_points", [])
    total = len(test_points)
    batch_size = 10
    total_batches = (total + batch_size - 1) // batch_size

    print(json.dumps({
        "status": "ok",
        "total_test_points": total,
        "batch_size": batch_size,
        "total_batches": total_batches,
    }))


# ============================================================
# Action: p6_merge (P6批次合并)
# ============================================================

def action_p6_merge(args):
    """合并P6所有批次结果，写入p6_output.tmp.json，调用truncation_guard"""
    data_dir = args.data_dir
    task_id = args.task_id
    skill_dir = args.skill_dir

    # 扫描p6_batches目录
    batches_dir = os.path.join(data_dir, "p6_batches")
    if not os.path.exists(batches_dir):
        print(json.dumps({"status": "error", "reason": "p6_batches目录不存在"}))
        sys.exit(1)

    all_cases = []
    batch_files = sorted(glob.glob(os.path.join(batches_dir, "batch_*.json")))

    for bf in batch_files:
        try:
            batch_data = _read_json(bf)
            cases = batch_data.get("testcases", batch_data.get("cases", []))
            all_cases.extend(cases)
        except Exception as e:
            print(json.dumps({"status": "warning", "reason": f"批次文件读取失败: {bf}: {e}"}), file=sys.stderr)

    if not all_cases:
        print(json.dumps({"status": "error", "reason": "所有批次合并后用例数为0"}))
        sys.exit(1)

    # 统计
    p0_count = sum(1 for c in all_cases if c.get("priority", "").upper() in ("P0", "HIGHEST"))
    smoke_count = sum(1 for c in all_cases if c.get("is_smoke", "") in ("是", "Y", "yes", True))

    # 按优先级统计
    by_priority = {}
    for c in all_cases:
        p = c.get("priority", "unknown").upper()
        by_priority[p] = by_priority.get(p, 0) + 1

    merged = {
        "testcases": all_cases,
        "statistics": {
            "total": len(all_cases),
            "by_priority": by_priority,
            "smoke_count": smoke_count,
            "p0_count": p0_count,
            "batch_count": len(batch_files),
        }
    }

    # 写入tmp
    tmp_path = os.path.join(data_dir, "p6_output.tmp.json")
    _write_json(tmp_path, merged)

    # truncation_guard
    ok, msg = run_truncation_guard(skill_dir, data_dir, task_id, "P6")

    if ok:
        state = TaskState(data_dir=data_dir, task_id=task_id)
        state.mark_complete("P6")
        print(json.dumps({
            "status": "ok",
            "total_cases": len(all_cases),
            "smoke_count": smoke_count,
            "batches_merged": len(batch_files),
            "guard_result": msg,
        }))
    else:
        print(json.dumps({"status": "guard_failed", "reason": msg}))
        sys.exit(1)


# ============================================================
# Action: p6_save_batch (保存P6单批结果)
# ============================================================

def action_p6_save_batch(args):
    """保存P6单批结果到p6_batches/batch_N.json"""
    data_dir = args.data_dir
    batch_index = int(args.batch_index) if args.batch_index else 1
    agent_output = args.agent_output

    try:
        batch_data = json.loads(agent_output)
    except Exception:
        import re
        match = re.search(r'\{[\s\S]*\}', agent_output)
        if match:
            try:
                batch_data = json.loads(match.group())
            except Exception:
                print(json.dumps({"status": "error", "reason": "P6批次JSON解析失败"}))
                sys.exit(1)
        else:
            print(json.dumps({"status": "error", "reason": "P6批次输出不含JSON"}))
            sys.exit(1)

    batches_dir = os.path.join(data_dir, "p6_batches")
    _ensure_dir(batches_dir)

    batch_path = os.path.join(batches_dir, f"batch_{batch_index:03d}.json")
    _write_json(batch_path, batch_data)

    cases = batch_data.get("testcases", batch_data.get("cases", []))
    print(json.dumps({
        "status": "ok",
        "batch_index": batch_index,
        "cases_in_batch": len(cases),
        "batch_file": batch_path,
    }))


# ============================================================
# Action: quality_check (质量校验强化)
# ============================================================

# 每步最小产出数量
MIN_OUTPUT_COUNTS = {
    "P0": {"blocks.modules": 1},  # 至少识别1个模块
    "P1": {"modules": 2},  # 至少2个功能模块
    "P2": {"test_points": 8},  # 至少8个测试点
    "P5": {"test_points": 10},  # 合并后至少10个
    "P6": {"testcases": 15},  # 至少15条用例
}

# P6用例质量规则
P6_QUALITY_RULES = {
    "smoke_ratio_min": 0.08,  # 冒烟用例至少8%
    "smoke_ratio_max": 0.20,  # 冒烟用例不超过20%
    "p0_ratio_max": 0.40,  # P0优先级不超过40%
    "all_same_priority": False,  # 不允许所有用例同一优先级
}

def _get_nested(data, key_path):
    """获取嵌套字段值，如 'blocks.modules'"""
    keys = key_path.split(".")
    current = data
    for k in keys:
        if isinstance(current, dict):
            current = current.get(k)
        else:
            return None
    return current

def action_quality_check(args):
    """对指定步骤的产出进行质量校验"""
    data_dir = args.data_dir
    step = args.step

    output_path = os.path.join(data_dir, f"{step.lower()}_output.json")
    if not os.path.exists(output_path):
        print(json.dumps({"status": "error", "reason": f"{step}产出文件不存在"}))
        sys.exit(1)

    data = _read_json(output_path)
    issues = []
    warnings = []

    # 1. 最小产出数量校验
    if step in MIN_OUTPUT_COUNTS:
        for field_path, min_count in MIN_OUTPUT_COUNTS[step].items():
            value = _get_nested(data, field_path)
            if value is None:
                issues.append(f"字段{field_path}不存在")
            elif isinstance(value, list) and len(value) < min_count:
                issues.append(f"{field_path}数量{len(value)}<最小要求{min_count}")
            elif isinstance(value, (int, float)) and value < min_count:
                issues.append(f"{field_path}值{value}<最小要求{min_count}")

    # 2. P0质量评分校验
    if step == "P0":
        score = data.get("quality_score", 0)
        if score < 0.5:
            issues.append(f"质量评分{score}<0.5，需求结构化质量太低")
        elif score < 0.7:
            warnings.append(f"质量评分{score}<0.7，建议补充需求")

    # 3. P6用例质量校验
    if step == "P6":
        cases = data.get("testcases", [])
        total = len(cases)
        if total > 0:
            smoke = sum(1 for c in cases if c.get("is_smoke", "") in ("是", "Y", "yes", True))
            p0 = sum(1 for c in cases if c.get("priority", "").upper() in ("P0", "HIGHEST"))

            smoke_ratio = smoke / total
            p0_ratio = p0 / total

            if smoke_ratio < P6_QUALITY_RULES["smoke_ratio_min"]:
                warnings.append(f"冒烟用例比例{smoke_ratio:.1%}<{P6_QUALITY_RULES['smoke_ratio_min']:.0%}")
            if smoke_ratio > P6_QUALITY_RULES["smoke_ratio_max"]:
                warnings.append(f"冒烟用例比例{smoke_ratio:.1%}>{P6_QUALITY_RULES['smoke_ratio_max']:.0%}")
            if p0_ratio > P6_QUALITY_RULES["p0_ratio_max"]:
                issues.append(f"P0优先级占比{p0_ratio:.1%}>{P6_QUALITY_RULES['p0_ratio_max']:.0%}，优先级分布异常")

            # 检查是否所有用例同一优先级
            priorities = set(c.get("priority", "") for c in cases)
            if len(priorities) == 1 and total > 5:
                issues.append(f"所有{total}条用例都是{priorities.pop()}优先级，分布异常")

    passed = len(issues) == 0
    # P7失败时提供回流指引
    retry_hint = None
    if not passed and step == "P7":
        retry_hint = "P7质量自检失败，建议重新执行P6用例展开（从 prep_prompt P6 重新开始）"
    if not passed and step == "P6":
        retry_hint = "P6质量校验失败，建议重新执行P6全部批次"

    print(json.dumps({
        "status": "ok" if passed else "quality_failed",
        "step": step,
        "passed": passed,
        "issues": issues,
        "warnings": warnings,
        "retry_hint": retry_hint,
    }))
    if not passed:
        sys.exit(1)


# ============================================================
# 主入口
# ============================================================


# ============================================================
# Action: restart_from (从指定步骤重新开始)
# ============================================================

def action_restart_from(args):
    """从指定步骤重新开始：清除该步及后续的gate pass和output"""
    data_dir = args.data_dir
    task_id = args.task_id
    step = args.step.upper()

    if step not in GATE_STEPS:
        print(json.dumps({"status": "error", "reason": f"无效步骤: {step}，可选: {GATE_STEPS}"}))
        sys.exit(1)

    # 找到该步骤及后续所有步骤
    step_idx = GATE_STEPS.index(step)
    steps_to_clear = GATE_STEPS[step_idx:]

    gates_dir = os.path.join(data_dir, "gates")
    cleared = []
    for s in steps_to_clear:
        # 清除gate pass
        gp = os.path.join(gates_dir, f"{s}.pass.json")
        if os.path.exists(gp):
            os.remove(gp)
            cleared.append(f"{s}.pass.json")
        # 清除output
        for suffix in ["_output.json", "_output.tmp.json", "_output.prev.json"]:
            op = os.path.join(data_dir, f"{s.lower()}{suffix}")
            if os.path.exists(op):
                os.remove(op)
                cleared.append(f"{s.lower()}{suffix}")

    # 更新state
    state = TaskState(data_dir=data_dir, task_id=task_id)
    state.state["completed_steps"] = [s for s in state.state["completed_steps"] if s not in [st.lower() for st in steps_to_clear] and s not in steps_to_clear]
    state.save()

    print(json.dumps({
        "status": "ok",
        "restart_from": step,
        "cleared_files": cleared,
        "next_step": step,
    }))


def main():
    parser = argparse.ArgumentParser(description="V3.0 Orchestrator")
    parser.add_argument("--action", required=True, choices=[
        "init", "onboarding", "step0", "step0_8_prep", "step0_8_save",
        "step_run", "step7_export", "status", "resume",
        "prep_prompt", "p6_batch_info", "p6_save_batch", "p6_merge",
        "quality_check",
        "restart_from"
    ])
    parser.add_argument("--skill-dir", default="")
    parser.add_argument("--data-dir", default="")
    parser.add_argument("--task-id", default="")
    parser.add_argument("--requirement-text", default="")
    parser.add_argument("--requirement-file", default="")
    parser.add_argument("--step", default="")
    parser.add_argument("--agent-output", default="")  # 兼容保留，优先从文件读
    parser.add_argument("--results-json", default="")  # 兼容保留，优先从文件读
    parser.add_argument("--batch-index", default="0")

    args = parser.parse_args()

    # === V3.0.0-patch3: 参数自动化 ===
    # 1. skill_dir自动发现
    try:
        args.skill_dir = resolve_skill_dir(args.skill_dir)
    except ValueError as e:
        print(json.dumps({"status": "error", "reason": str(e)}))
        sys.exit(1)

    # 2. data_dir/task_id自动回填（非init action时）
    if args.action != "init":
        if not args.data_dir or not args.task_id:
            auto_tid, auto_dir = find_latest_task()
            if auto_tid and auto_dir:
                if not args.task_id:
                    args.task_id = auto_tid
                if not args.data_dir:
                    args.data_dir = auto_dir
            else:
                if args.action not in ("status",):
                    print(json.dumps({"status": "error", "reason": "未找到活跃任务，请先执行 --action init"}))
                    sys.exit(1)

    # 3. agent-output从文件读取（优先级：文件 > 命令行参数）
    if args.action in ("step_run", "p6_save_batch") and not args.agent_output:
        step = args.step or "unknown"
        if args.action == "p6_save_batch":
            batch_idx = int(args.batch_index) if args.batch_index else 1
            agent_file = os.path.join(args.data_dir, f"p6_batch_{batch_idx:03d}_agent_output.json")
        else:
            agent_file = os.path.join(args.data_dir, f"{step.lower()}_agent_output.json")
        if os.path.exists(agent_file):
            args.agent_output = _read_file_safe(agent_file, 100000)

    # 4. results-json从文件读取
    if args.action == "step0_8_save" and not args.results_json:
        results_file = os.path.join(args.data_dir, "px_agent_results.json")
        if os.path.exists(results_file):
            args.results_json = _read_file_safe(results_file, 100000)

    actions = {
        "init": action_init,
        "onboarding": action_onboarding,
        "step0": action_step0,
        "step0_8_prep": action_step0_8_prep,
        "step0_8_save": action_step0_8_save,
        "step_run": action_step_run,
        "step7_export": action_step7_export,
        "status": action_status,
        "resume": action_resume,
        "prep_prompt": action_prep_prompt,
        "p6_batch_info": action_p6_batch_info,
        "p6_save_batch": action_p6_save_batch,
        "p6_merge": action_p6_merge,
        "quality_check": action_quality_check,
        "restart_from": action_restart_from,
    }

    try:
        actions[args.action](args)
    except SystemExit:
        raise
    except Exception as e:
        print(json.dumps({"status": "error", "reason": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
