#!/usr/bin/env python3
"""
轻量 Excel 生成脚本 — 将 P6 输出 JSON 转换为公司标准 21 列测试用例 Excel。

依赖: openpyxl
用法: python3 export_excel.py --input p6_output.json --output testcases.xlsx

退出码:
  0 = 成功
  1 = 输入文件不存在
  2 = JSON 解析失败
"""

import argparse
import json
import sys
from pathlib import Path

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
except ImportError:
    print("错误: 缺少 openpyxl，请执行 pip install openpyxl", file=sys.stderr)
    sys.exit(3)

# ── 公司标准 21 列定义 ──────────────────────────────────────────────
# P6 JSON 字段 → Excel 列名
COLUMNS = [
    ("case_id",          "用例编号"),
    ("title",            "用例简述"),
    ("menu_path",        "菜单"),
    ("preconditions",    "预置条件"),
    ("steps",            "操作步骤"),
    ("expected_results", "期望结果"),
    ("priority",         "优先级"),
    ("is_smoke",         "是否冒烟用例"),
    ("case_type",        "用例类型"),
    ("test_category",    "测试类别"),
    ("creator",          "创建者"),
    ("assignee",         "经办人"),
    ("executor",         "执行人"),
    ("test_phase",       "测试阶段"),
    ("module",           "所属模块"),
    ("feature",          "所属功能点"),
    ("data_requirements","测试数据要求"),
    ("environment",      "测试环境"),
    ("automation_flag",  "是否可自动化"),
    ("remarks",          "备注"),
    ("status",           "执行状态"),
]

# 优先级映射: P6 输出 → 公司字典(Highest/High/Medium/Low/Lowest)
PRIORITY_MAP = {
    "P0": "Highest", "core": "Highest",
    "P1": "High",   "high": "High",
    "P2": "Medium", "medium": "Medium",
    "P3": "Low",    "low": "Low",
    # 兼容中文输入
    "核心": "Highest",
    "高": "High",
    "中": "Medium",
    "低": "Low",
}

# 用例类型映射: P6 输出 → 公司字典(正例/反例)
TEST_CASE_TYPE_MAP = {
    "正向验证": "正例",
    "分支验证": "正例",
    "逻辑组合": "正例",
    "状态迁移": "正例",
    "兼容回归": "正例",
    "接口验证": "正例",
    "条件验证": "正例",
    "异常处理": "反例",
    "边界验证": "反例",
    "集成异常": "反例",
    "歧义验证": "反例",
    "权限验证": "反例",
    "性能验证": "反例",
    "安全验证": "反例",
}

# 测试类别映射: P6 输出 → 公司字典
TEST_CATEGORY_MAP = {
    "功能": "功能测试",
    "性能": "性能测试",
    "安全": "安全性测试",
    "兼容性": "兼容性测试",
    "可靠性": "可靠性测试",
    "可移植性": "可移植性测试",
    "可维护性": "可维护性测试",
    # 直接匹配公司字典值
    "功能测试": "功能测试",
    "性能测试": "性能测试",
    "安全性测试": "安全性测试",
    "兼容性测试": "兼容性测试",
    "可靠性测试": "可靠性测试",
    "可移植性测试": "可移植性测试",
    "可维护性测试": "可维护性测试",
}

HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
HEADER_FONT = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
BODY_FONT = Font(name="微软雅黑", size=10)
THIN_BORDER = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"), bottom=Side(style="thin"),
)
WRAP_ALIGNMENT = Alignment(wrap_text=True, vertical="top")


def normalize_value(key: str, raw) -> str:
    """将 P6 JSON 值转换为 Excel 友好字符串。"""
    try:
        if raw is None:
            return ""
        if key == "priority":
            return PRIORITY_MAP.get(str(raw), str(raw))
        if key == "test_case_type" or key == "case_type":
            return TEST_CASE_TYPE_MAP.get(str(raw), str(raw))
        if key == "test_category":
            return TEST_CATEGORY_MAP.get(str(raw), str(raw))
        if key == "is_smoke":
            return "是" if raw in (True, "true", "是") else "否"
        if key == "steps" and isinstance(raw, list):
            return "\n".join(f"{i+1}. {s}" for i, s in enumerate(raw))
        if key == "expected_results" and isinstance(raw, list):
            return "\n".join(f"{i+1}. {r}" for i, r in enumerate(raw))
        if isinstance(raw, (list, dict)):
            return json.dumps(raw, ensure_ascii=False, indent=None)
        return str(raw)
    except Exception:
        return str(raw)[:500]  # 兜底：截断过长或异常内容


def build_workbook(cases: list) -> Workbook:
    wb = Workbook()
    ws = wb.active
    ws.title = "测试用例"

    # 写表头
    for col_idx, (_, cn_name) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=cn_name)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal="center", vertical="center")

    # 写数据行
    for row_idx, case in enumerate(cases, start=2):
        for col_idx, (field, _) in enumerate(COLUMNS, start=1):
            val = normalize_value(field, case.get(field, ""))
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            cell.font = BODY_FONT
            cell.border = THIN_BORDER
            cell.alignment = WRAP_ALIGNMENT

    # 冻结首行
    ws.freeze_panes = "A2"

    # 自动列宽（简易估算）
    for col_idx, (_, cn_name) in enumerate(COLUMNS, start=1):
        max_len = len(cn_name)
        for row in ws.iter_rows(min_row=2, min_col=col_idx, max_col=col_idx):
            for cell in row:
                if cell.value:
                    max_len = max(max_len, min(len(str(cell.value).split("\n")[0]), 50))
        ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = max_len + 4

    return wb


def main():
    parser = argparse.ArgumentParser(description="P6 JSON → 公司标准 21 列 Excel")
    parser.add_argument("--input", required=True, help="P6 输出 JSON 文件路径")
    parser.add_argument("--output", required=True, help="输出 Excel 文件路径")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"错误: 输入文件不存在 → {input_path}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(input_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        print(f"错误: JSON 解析失败 → {e}", file=sys.stderr)
        sys.exit(2)

    # 兼容两种格式: 直接数组 或 {"testcases": [...]}
    if isinstance(data, dict):
        cases = data.get("testcases", data.get("test_cases", []))
    elif isinstance(data, list):
        cases = data
    else:
        print("错误: JSON 顶层结构不是数组或对象", file=sys.stderr)
        sys.exit(2)

    if not cases:
        print("⚠️ 警告: 用例列表为空，将生成空 Excel", file=sys.stderr)

    wb = build_workbook(cases)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        wb.save(str(output_path))
    except Exception as e:
        print(f"错误: Excel 写入失败 → {e}", file=sys.stderr)
        sys.exit(4)
    print(f"✅ 已生成 {len(cases)} 条用例 → {output_path}")


if __name__ == "__main__":
    main()
