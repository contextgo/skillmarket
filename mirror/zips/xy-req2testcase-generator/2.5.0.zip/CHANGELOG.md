# Changelog

## Changelog

### v2.5.0-patch1 (2026-04-28)

**变更类型**: fix (四路评审修复)

**变更内容**:
1. **image_enhance.py A-2适配层**：新增_adapt_a2_format()函数，将A-2方案的results/understanding_mode/confidence(字符串)映射为旧格式的images/processing_status/classification.confidence(数值)，解决PX增强完全失效问题
2. **Onboarding门禁时序修复**：task_id创建从Step 0提前到Onboarding完成时，解决"task_id未创建→无法写onboarding.pass.json→无法进入Step 0"的时序悖论
3. **Step 0门禁检查增强**：从"扫描最新pass文件"改为"校验当前task_id的pass文件+task_id一致性验证"
4. **step0-px.md顶部OCR残留清理**：删除"OCR不可用时先装Tesseract"旧约束，替换为A-2方案说明
5. **skill_version更新**：step0-px.md中task_meta.json的skill_version从2.4.0更新为2.5.0
6. **状态行模板统一**：所有references中旧格式`✅ Step X(PX)完成!-`统一为新格式`✅ P{N}完成 | {指标} | 文件已保存`
7. **执行模型表述统一**：onboarding.md"零暂停"改为"自动推进"；step0-px.md"一气呵成"改为"按顺序自动推进"；step1-4.md/step5-7.md顶部新增"顶层协议优先"声明
8. **model_detect.py退出范围精确化**：从"退出主流程"改为"退出PX主流程（仍在P5分批模式中使用）"；引用文件清单新增退出标注

**影响范围**:
- tools/image_enhance.py: 新增A-2适配层
- references/onboarding.md: task_id提前创建+门禁时序修复+自动推进表述
- references/step0-px.md: 顶部OCR清理+skill_version+门禁检查增强+执行模型统一
- references/step1-4.md: 状态行统一+顶层协议优先声明
- references/step5-7.md: 状态行统一+顶层协议优先声明
- SKILL.md: 引用文件清单退出标注

### v2.5.0 (2026-04-28)

**变更类型**: fix + architecture-change

**变更内容**:
1. **需求载荷前置规则**：触发技能后必须先确认需求已就绪才启动Onboarding,未收到需求时仅输出固定等待话术,不输出步骤清单或能力介绍
2. **需求上下文判定规则**：支持本条消息含需求/含附件/明确引用近期需求三种就绪判定,禁止复用已完成task的旧需求
3. **Onboarding完成状态门禁**：Onboarding完成后写入onboarding.pass.json,Step 0前置检查该文件存在才允许进入主流程,从"指令约束"升级为"状态门禁"
4. **三阶段执行规则**：从两阶段(Onboarding+主流程)升级为三阶段(需求等待+Onboarding+主流程)
5. **对话输出硬约束**：从白名单改为计数硬约束(每步严格限1行),新增固定状态行格式和动作链模板
6. **PX图片理解A-2方案重构**：
   - 删除三级降级架构(model_detect→vision/OCR/context_only)
   - 改为Agent直接read图片,能看懂就用,看不懂就降级为caption+上下文
   - 图片选择改为价值优先(流程图>原型页>规则表>其他),最多5张
   - 新增三条件理解判定标准(识别类型+提取2个元素+1个测试价值点)
   - px_understand.json新增understanding_mode/confidence/evidence/selection_reason等字段
   - model_detect.py/image_understand.py/image_ocr.py退出主流程(保留文件不删除)
7. **P0内联必需字段**：在step1-4.md中直接内联P0顶层必需字段(quality_score/blocks/objective),减少Agent读schema的认知负担
8. **截断防护规则**：禁止单exec写完整P0-P7逻辑;禁止单轮回复连续推进超过一个Step;新增按gate pass精准恢复规则(支持P2/P3/P4复合步骤局部续跑)
9. **每步输出提醒**：所有Step指令开头新增"⚠️ 本步只输出1行状态"提醒

**影响范围**:
- SKILL.md: 运行协议重写(三阶段+需求前置+输出硬约束+截断防护+动作链模板)
- references/onboarding.md: 新增需求载荷前置规则+onboarding.pass.json门禁
- references/step0-px.md: Step 0新增onboarding门禁检查;Step 0.8整段重写为A-2方案
- references/step1-4.md: P0内联字段+各步输出提醒
- references/step5-7.md: 各步输出提醒

**兼容性**: ⚠️ 重大架构变更,PX从三级降级改为Agent直接视觉,Onboarding新增状态门禁


### v2.3.3 (2026-04-27)

**变更类型**: fix + architecture-change

**变更内容**:
1. **truncation_guard.py 四级截断检测脚本**：L1文件存在→L2 JSON有效→L3结构完整→L4内容完整，支持 `--auto-mv` 原子操作（校验通过自动mv+生成gate pass，失败自动rm tmp），Agent无法绕过
2. **thresholds.json L4阈值外部化配置**：P5输出≥max(15, P2×0.6)，P6输出≥max(10, P5×0.8)
3. **所有P0-P7统一改为tmp→truncation_guard→mv原子写入**：禁止heredoc直写正式文件，截断时最多损坏tmp不污染正式缓存
4. **gate pass链式依赖机制**：每步校验通过后自动生成gates/{step}.pass.json，下游步骤必须检查上游pass才能启动
5. **断点续跑改为"gate pass才能复用"**：不再只看"文件存在且非空"，必须pass存在且task_id一致
6. **P6降级产物隔离**：降级产物写入p6_output.degraded.json，不生成gate pass
7. **P5双模式执行**：新增model_detect.py output_capacity检测（high/medium/low三级），P5根据模型能力自动选择single/auto_batch/force_batch策略
8. **P5分批模式**：新增p5_prepare.py（按模块分组生成batch_context）+ P5a_batch_merge.md（批内合并子Prompt）+ Step 4c跨批汇总（脚本级ID去重+统计口径重定义）
9. **P5统计口径重定义**：merge_log区分batch_merge和cross_batch_dedup，coverage_summary新增source_covered_ratio
10. **Onboarding恢复交互模式**：PRD审查和L5上传恢复为用户可选择的开/跳过
11. **PX视觉模式修复**：支持视觉的模型必须走Agent直接调用路径（CLI无法提供model_caller），禁止CLI调用视觉模式
12. **OCR自动安装**：Tesseract不可用时先尝试自动安装（apt/yum/brew/apk），只有安装失败后才降级
13. **export_excel.py字典值映射修复**：优先级→Highest/High/Medium/Low，用例类型→正例/反例，测试类别→功能测试等
14. **P5严禁跳步强化**：明确禁止跳过P5/P6/P7直接生成Excel
15. **L4组合校验**：P5增加模块覆盖+优先级保留+merge_log一致性；P6增加P0全展开率；WARNING不阻塞流程
16. **revision简化版**：current_revision.json管理+断点续跑revision校验+bump-revision时清除下游gate pass+备份策略(.prev.json)
17. **SKILL.md指令冲突修复（根因级）**：对话输出白名单追加"Onboarding交互输出"豁免；元叙述硬禁令追加"Onboarding阶段例外"；全流程交互规则重构为两阶段制（Onboarding交互+主流程零暂停）；消除"零暂停"误杀Onboarding交互的根因
18. 专属触发词新增「xy测试用例生成」

**影响范围**:
- 新增 tools/truncation_guard.py（四级截断检测脚本）
- 新增 tools/thresholds.json（L4阈值配置）
- 新增 tools/p5_prepare.py（P5分批预处理脚本）
- 新增 prompts/P5a_batch_merge.md（P5批内合并子Prompt）
- 修改 tools/model_detect.py（新增output_capacity检测）
- SKILL.md: 所有Step写入方式改造、gate pass链式依赖、断点续跑升级、P5双模式执行、关键产物门禁重写
- export_excel.py: PRIORITY_MAP/TEST_CASE_TYPE_MAP/TEST_CATEGORY_MAP重写
- P6_testcase_generation.md: 字段映射对齐公司字典

**兼容性**: ⚠️ 重大架构变更，所有Step写入方式改变，新增gate pass机制

### v2.3.2 (2026-04-27)

**变更类型**: fix + behavior-change

**变更内容**:
1. **Onboarding 恢复交互模式**:PRD质量审查和L5知识库上传恢复为交互式询问,用户可选择「开启/跳过」和「上传/跳过」,之前的非交互模式导致能力丢失
2. **PX 图片理解视觉模式修复**:
   - 视觉模式(vision)禁止通过CLI调用(CLI无法提供model_caller,导致静默降级)
   - 支持视觉的模型(Doubao-Seed-2.0-pro等)必须走Agent直接调用路径:用read工具逐张读取图片,Agent用自己的视觉能力理解
   - 新增视觉模式Agent调用流程和VISION_QUEUE机制
3. **OCR引擎自动安装**:OCR不可用时先尝试自动安装Tesseract(含中文语言包),支持apt/yum/brew/apk四种包管理器,只有安装失败后才降级为纯文本模式
4. PX 跳过原因输出增强:跳过时必须附带具体原因
5. P5 截断自愈规则加强:明确禁止跳过P5/P6/P7直接生成Excel
6. export_excel.py 字典值映射修复:
   - 优先级:P0→Highest / P1→High / P2→Medium / P3→Low
   - 用例类型:正向类→「正例」,异常/边界/安全类→「反例」
   - 测试类别:功能→功能测试 / 性能→性能测试 / 安全→安全性测试 等
7. P6 Prompt 和 testcase_design_spec.md 字段映射说明同步更新
8. 专属触发词新增「xy测试用例生成」

**影响范围**:
- SKILL.md: Onboarding交互模式恢复、PX视觉模式调用方式变更、OCR自动安装、P5严禁跳步
- export_excel.py: PRIORITY_MAP / TEST_CASE_TYPE_MAP / TEST_CATEGORY_MAP 全部重写
- P6_testcase_generation.md: 字段映射说明对齐公司字典
- testcase_design_spec.md: 字段映射说明对齐公司字典

**兼容性**: ⚠️ 行为性变更,Onboarding从非交互恢复为交互,PX视觉模式调用方式变更

### v2.3.1 (2026-04-26)

**变更类型**: fix

**变更内容**:
1. model_detect.py 增加 provider 前缀剥离,修复 Doubao-Seed-2.0-pro 等带前缀模型ID被误判降级为OCR的问题
2. model_vision_capability.json 新增 doubao-seed-2.0-pro 等精确匹配条目
3. SKILL.md Step 3/4 JSON 写入改用 heredoc 方式,解决弱模型 tool calling 失败问题
4. SKILL.md Step 5 (P6) 大JSON采用 write→校验→mv 分步写入策略
5. SKILL.md 新增关键产物门禁:P0-P4 JSON写入后必须校验,失败则终止
6. SKILL.md 新增跳步分级规则:关键产物缺失必须终止,非关键步骤允许受控降级
7. SKILL.md 新增工具调用指导(弱模型适配)和禁止自建脚本规则
8. SKILL.md Onboarding 输出加"已自动继续"后缀,防止被误解为需用户回复
9. SKILL.md 检查1.5路径发现增加环境变量兜底和容器常见路径
10. model_detect.py 增加日志输出,便于排查模型能力检测结果
11. 门禁校验脚本assert改为if+sys.exit(1),防止python3 -O优化跳过
12. P6写入策略移除5KB阈值判断,统一使用write→校验→mv方式(避免LLM无法精确判断字节数)
13. P5提升为二级关键产物:写入失败必须终止,质量不达标允许降级
14. 跳步分级触发条件新增"JSON格式无效",与关键产物门禁一致
15. 路径发现失败时Markdown降级改为内联输出(不依赖export_markdown.py脚本)
16. P6校验失败时清理p6_raw.json临时文件(mv替代cp)
17. Onboarding非交互总则升级为全流程非交互规则(覆盖Onboarding→Step 0-7)
18. Step 7新增导出门禁,Excel/Markdown导出后强制校验文件存在且非空
19. P6降级操作具体化:最小可行用例集+degraded:true标记+警告输出
20. 工具调用指导vs门禁优先级明确:关键产物门禁>工具调用指导
21. 异常处理兆底规则与跳步分级规则措辞统一
22. 路径发现find命令加timeout 10和-print -quit优化

**影响范围**:
- model_detect.py: model_id 预处理逻辑变更,所有带 provider 前缀的模型ID受影响
- SKILL.md: Step 3/4/5 写入方式变更,Onboarding/路径发现/跳步规则增强

### v2.3.0 (2026-04-26)

**变更类型**: fix + behavior-change

**变更内容**:
1. Step 0.5 blocker 处理:从「等待用户强制跳过」改为「自动转 PCI 继续执行」,新增 `auto_skipped`/`skipped_blocker_count` 字段
2. Step 1 质量门禁:从「等待用户强制继续」改为「自动 CONDITIONAL_PASS 继续执行」,新增 `auto_forced`/`original_score` 字段,禁止写 `PASSED`
3. 新增「执行诚实规则」(全流程10条),解决 Excel 文件幻觉发送问题
4. 新增「跨步骤可测性分流规则」:可测/条件可测/不可测三分类
5. 新增「异常处理兆底规则」:执行错误→终止,不等用户
6. Step 7 输出增加文件生成验证和三级降级机制(Excel→Markdown→JSON)
7. MEDIA 指令强制全大写,独占一行,无前后空白
8. 新增 `export_markdown.py` 降级脚本,禁止 `cp .json → .md` 伪装
9. `export_excel.py` 增加 try-catch 兜底、空列表警告、写入异常捕获
10. P6 质量门禁冒烟占比从固定"10%~20%"改为分档规则(与生成规则/P7一致)
11. P6/P7 P0占比从强制"≤15%"改为建议"≤40%"(非强制,避免缩减必要用例)
12. P6 增加 blocked 测试点可测性分流(含6类核心缺失判定清单)
13. p6_output.schema.json 新增"条件验证" enum
14. P6 新增"禁止伞形用例规则",P7 新增 C9 伞形用例检测(WARNING级别)
15. SKILL.md blocked不可测落盘位置从 P5 的 blocked_test_points 改为 P6 的 statistics.risk_items

**影响范围**:
- 所有步骤的"等待用户"指令被非交互模式覆盖
- `p0_output.json` 新增可选字段 `auto_forced`/`original_score`(quality_check 对象内),status 新增 `CONDITIONAL_PASS` 枚举值
- `p0.5_output.json` 新增可选字段 `auto_skipped`/`skipped_blocker_count`(根级别)
- Step 7 行为变更:先验证后发送,支持降级输出

**兼容性**: ⚠️ 行为性变更,原有"等待用户确认"语义不再生效
