---
name: xy-req2testcase-generator
description: "AI驱动的需求→测试用例生成能力。触发：生成测试用例/分析需求/拆解功能点/输出测试点/需求评审/PRD转测试用例。V2.5.0云端稳定性修复。"
version: "2.5.0"
metadata:
  author: "券商科技测试团队"
  architecture: "progressive-disclosure"
---

# xy-req2testcase-generator V2.5.0

> 版本:2.5.0
> 架构:零部署,Agent直接执行,Progressive Disclosure拆分

---

## 🔴 运行协议(最高优先级,覆盖后文所有描述)

**需求载荷前置规则**:
- 触发本技能后,如用户消息中不包含需求正文/需求附件/明确引用近期需求材料,仅输出:`请发送需求正文或需求文档，收到后立即开始分析。` 不得启动Onboarding、不得输出步骤清单或能力介绍。

**三阶段执行规则**:
- **阶段0—需求等待**:未收到需求载荷时,仅输出固定等待话术,不启动任何流程
- **阶段1—Onboarding**:交互模式,检查3(PRD审查)和检查4(L5上传)**必须暂停等待用户选择**。完成后写入onboarding.pass.json门禁。
- **阶段2—主流程Step 0-7**:零暂停模式,前置检查onboarding.pass.json存在才允许进入

**对话输出硬约束(每步严格限1行,超过=协议违规)**:
- Onboarding交互输出(检查结果/PRD审查询问/L5上传询问)
- 步骤状态行:固定格式 `✅ P{N}完成 | {1-2个关键指标} | 文件已保存`
- P6进度行:`✅ 已生成 X/N 条用例`
- 最终完成行:`✅ 测试用例已生成,共 N 条。Excel文件已发送。`
- 错误行:`❌ Step {N} 失败: {1行原因}`
- 警告行:`⚠️ {1行内容}`
- **严禁输出**:JSON结构体、中间分析内容、多行说明、执行过程描述

**动作链模板(每步必须严格按此执行)**:
1. read对应references子文件 → 2. 执行步骤逻辑 → 3. 写入tmp文件 → 4. truncation_guard校验 → 5. 输出1行状态 → 6. 立即read下一步reference

**元叙述硬禁令(Onboarding阶段例外)**:
- 禁止输出:`根据技能要求`/`现在先输出`/`接下来我将`/`先看看`/`是否完成`/`是否继续`
- 禁止解释自己正在遵循什么协议、准备做什么

**截断防护规则**:
- 🔴 禁止在单个exec中编写包含完整P0-P7逻辑的Python脚本。每个Step必须独立执行。
- 🔴 单轮回复中禁止连续推进超过一个Step的重工具执行链(除P6内部分批外)。
- 回复被截断后的恢复规则:用户发送"继续"时,扫描{DATA_DIR}/gates/目录,找到最后通过的gate pass(P0→P7顺序),从下一步继续。复合步骤(P2/P3/P4)支持局部续跑。tmp文件视为失败残留不复用。

**错误示范 → 正确做法**:

| 错误行为 | 正确做法 |
|---------|--------|
| 触发技能后先输出步骤清单再等需求 | 只输出固定等待话术,不输出任何步骤/能力介绍 |
| 检测到历史缓存后输出三选项菜单 | 直接输出`检测到历史缓存,已自动清理,开始新任务。`然后立即继续 |
| 将Step 5/6/7合并为一个回复执行 | 每个Step必须单独完成并输出一行状态行 |
| 输出完整JSON到对话 | 只写入文件,对话只输出一行状态 |
| "是否继续执行下一步?" | 直接执行,不需要用户确认 |
| 每步输出2+行说明 | 每步只有1行状态行 |
| 在单个exec中写完整P0-P7逻辑 | 每个Step独立执行 |
| 未read onboarding.md就开始执行 | 第一个动作必须是read references/onboarding.md |

**唯一合法结束点**:Step 7完成,Excel文件已发送,输出最终完成信息(及允许的L6学习邀请)后才允许结束本轮回复。

**执行规则**:每个Step执行前,read对应的references/子文件获取详细指令

---

## 触发条件

### 专属触发词(精准命中)
「xy用例生成」「xy需求分析」「xy测试用例」「xy测试用例生成」「req2testcase」

### 通用触发词
「生成测试用例」「分析需求」「拆解功能点」「输出测试点」「需求评审」「帮我写用例」「这个需求怎么测」「PRD转测试用例」

### 开关指令
- 开启PRD审查:「PRD质量审查能力打开」「开启PRD审查」
- 关闭PRD审查:「关闭PRD审查」
- 重新生成:「重新生成」→保留P0-P5,仅重跑P6/P7

---

## 🔴 流程骨架(含关键约束)

**🔴 硬性门禁:read对应子文件是每个Step的前置条件。未read=协议违规。**

**🔴 第一个动作必须是 read references/onboarding.md。未完成Onboarding门禁(onboarding.pass.json)不得进入Step 0。**

**强制:进入主流程前,必须先 read references/onboarding.md 执行所有Onboarding检查并通过门禁**

| Step | 名称 | 关键约束 | 详细指令 |
|------|------|---------|---------|
| Onboarding | 环境检查+用户偏好 | 🔴必须完成并写入onboarding.pass.json;检查3/4必须等待用户选择 | read references/onboarding.md |
| 0 | 接收需求 | 🔴前置:onboarding.pass.json存在;创建task_id,写入task_meta | read references/step0-px.md |
| 0.8 | PX图片理解 | 🔴Agent直接read图片(最多5张,价值优先);不依赖model_detect/OCR | read references/step0-px.md |
| 0.5 | PRD质量审查 | 🔴用户选择开启才执行;有blocker时暂停让用户选择[1]中断/[2]转PCI继续 | read references/step1-4.md |
| 1 | P0需求结构化 | 前置:检查p0.pass | read references/step1-4.md |
| 2 | P1功能点树 | 前置:检查p1.pass | read references/step1-4.md |
| 3 | P2/P3/P4三路 | 前置:检查p2.pass(硬)+p3/p4.pass(增强);断点续跑需gate pass+task_id+revision一致 | read references/step1-4.md |
| 4 | P5测试点合并 | 🔴严禁跳过P5/P6/P7直接生成Excel;前置:检查p2.pass;写入:tmp→guard→mv | read references/step1-4.md |
| 5 | P6用例展开 | 前置:检查p5.pass;写入:tmp→guard→mv | read references/step5-7.md |
| 6 | P7质量自检 | 前置:检查p6.pass | read references/step5-7.md |
| 7 | 导出Excel | 🔴前置:检查p5+p6+p7三个pass;必须通过export_excel.py导出,禁止自建脚本 | read references/step5-7.md |

---

## 🔴 执行铁律

1. **跳步=交付失败**:必须严格按Step 0→1→2→3→4→5→6→7顺序执行
2. **你就是LLM**:所有「调用LLM」的步骤,直接用你自己的推理能力执行
3. **所有步骤串行执行**:禁止并行
4. **每步LLM输出后必须执行JSON解析兜底**→失败则正则提取→仍失败则修复→仍失败则该步骤失败
5. **中间结果必须写入`{DATA_DIR}/`**,确保可断点续跑

---

## 路径约定

- `{SKILL_DIR}`:Onboarding检查1.5发现的实际路径
- `{DATA_DIR}`:`~/.openclaw/workspace/data/{task_id}`
- `{task_id}`:`task_YYYYMMDD_XXX`

## 断点续跑(精简)

每步开始前检查`{DATA_DIR}/gates/{step}.pass.json`:存在+task_id一致+revision一致→复用;不存在或不一致→正常执行。用户可发「从P{n}重新开始」强制重跑。详见references/step1-4.md和step5-7.md。

## 错误处理

| 错误类型 | 处理方式 |
|---------|---------|
| 知识文件不存在 | 跳过该知识注入,输出`⚠️ 知识文件缺失: {path},已跳过` |
| LLM调用超时 | 重试1次,仍超时则报错终止 |
| JSON解析失败 | 执行兜底逻辑 |
| 文件写入失败 | 报错终止,提示检查磁盘空间和权限 |
| openpyxl不可用 | 自动重试1次;仍失败则输出Markdown摘要 |
| 用户发"取消/停止" | 立即终止,保留已完成中间结果 |

---

## 引用文件清单

| 路径(相对SKILL_DIR) |
|---|
| references/onboarding.md |
| references/step0-px.md |
| references/step1-4.md |
| references/step5-7.md |
| prompts/P0_requirement_structuring.md |
| prompts/P0.5_prd_quality_review.md |
| prompts/P1_feature_tree_generation.md |
| prompts/P2_test_point_draft.md |
| prompts/P3_risk_identification.md |
| prompts/P4_pci_identification.md |
| prompts/P5_test_point_merge.md |
| prompts/P5a_batch_merge.md |
| prompts/P6_testcase_generation.md |
| prompts/P7_quality_gate.md |
| prompts/PX_image_understand.md |
| prompts/PX_ocr_extract.md |
| tools/export_excel.py |
| tools/export_markdown.py |
| tools/export_prd_review.py |
| tools/truncation_guard.py |
| tools/thresholds.json |
| tools/p5_prepare.py |
| tools/model_detect.py | ⚠️ 退出PX主流程,仅P5分批使用 |
| tools/image_understand.py | ⚠️ 退出PX主流程,保留供回退 |
| tools/image_ocr.py | ⚠️ 退出PX主流程,保留供回退 |
| tools/image_extract.py |
| tools/image_enhance.py |
| knowledge/model_vision_capability.json |
| knowledge/config/project_dict.json |
| knowledge/industry/ |
| knowledge/methodology/ |
| knowledge/company_standards/ |
| knowledge/defect_patterns/ |
| user_knowledge/project/ |
| user_knowledge/experience/ |
| user_knowledge/preferences.json |

## 已知限制

1. P0.5 PRD质量审查不支持自动重试
2. L6经验库few-shot注入为简单文件名匹配,非向量检索
3. 大PRD分批阈值固定为30个测试点
4. Excel导出依赖openpyxl;不可用时按统一导出失败策略处理(自动重试一次,失败后降级为Markdown格式用例文件,再失败发送JSON)
5. 非交互模式依赖LLM遵守SKILL.md文字约束,存在小概率不遵守的风险(长期建议TaskFlow改造)
