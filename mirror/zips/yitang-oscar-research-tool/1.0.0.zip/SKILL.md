---
name: yitang-oscar-research
description: Apply Yitang OSCAR research management to decision-oriented research with objective, scope, checklist, acquisition, and reasoning. Use when asked to 做调研计划, 分派调研任务, 定调研范围, 做市场/竞品/用户/技术调研, 输出调研结论, or to manage research “按一堂 / OSCAR 方法”.
---

# Yitang OSCAR Research

Use this skill to turn loose research requests into decision-support work with explicit scope, owners, acquisition paths, and conclusions.

## Core Rules

- Research exists to support a decision, not to collect information.
- Write the decision question before gathering material.
- Narrow scope aggressively; refuse “everything about this industry”.
- Require a named owner and a conclusion format for every research task.
- End with `该做 / 怎么做 / 不该做什么`, not an information dump.

## OSCAR Workflow

### 1. Objective

- State the decision that the research must support.
- Make the question concrete enough to be answered with evidence.

### 2. Scope

- Define what to include and what to exclude.
- Cut future possibilities, adjacent topics, and nice-to-have research.

### 3. Checklist

- List the exact objects, people, products, datasets, or documents to inspect.
- Prefer a finite list over generic “do some market research”.

### 4. Acquisition

- Specify how the information will be obtained: documents, interviews, tests, field checks, trials.
- Choose channels proportional to the importance of the decision.

### 5. Reasoning

- Synthesize findings back to the original decision.
- Write conclusion, next action, and explicit non-actions.

## Default Output

Unless the user asks for another format, output these sections:

1. `调研目标`
2. `调研范围`
3. `调研对象清单`
4. `信息获取路径`
5. `主责 / 协同 / 截止时间`
6. `结论需要回答的问题`
7. `不做清单`

## Research Management Rules

- Do not run more research tracks in parallel than the project can absorb.
- Force each track to report against its objective, not against effort spent.
- Use short daily updates and a midweek calibration when multiple people are involved.

## References

- Read [references/framework.md](references/framework.md) for the full OSCAR method, templates, and anti-patterns.
- Read [references/templates.md](references/templates.md) when the user wants a ready-to-fill research brief, task assignment sheet, interview guide, or conclusion summary.
