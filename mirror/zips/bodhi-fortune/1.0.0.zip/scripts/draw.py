#!/usr/bin/env python3
"""
观音灵签随机抽签脚本

用法:
    python draw.py
    python draw.py --id 42      # 抽取指定签号（测试用）

输出:
    JSON 格式的单支签数据
"""

import json
import random
import argparse
import sys
from pathlib import Path

# 数据文件路径：相对于本脚本所在目录的上一级 references 文件夹
SKILL_ROOT = Path(__file__).resolve().parent.parent
DATA_FILE = SKILL_ROOT / "references" / "fortune_data.json"


def load_fortunes():
    if not DATA_FILE.exists():
        print(f"ERROR: 数据文件不存在: {DATA_FILE}", file=sys.stderr)
        sys.exit(1)
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def draw(fortune_id=None):
    fortunes = load_fortunes()
    if fortune_id is not None:
        matches = [f for f in fortunes if f["id"] == fortune_id]
        if not matches:
            print(f"ERROR: 签号 {fortune_id} 不存在（有效范围 1-{len(fortunes)}）", file=sys.stderr)
            sys.exit(1)
        fortune = matches[0]
    else:
        fortune = random.choice(fortunes)
    print(json.dumps(fortune, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="观音灵签随机抽签")
    parser.add_argument("--id", type=int, default=None, help="指定签号（1-100），不传则随机抽取")
    args = parser.parse_args()
    draw(args.id)
