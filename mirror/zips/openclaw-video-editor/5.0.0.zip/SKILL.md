---
name: openclaw-video-editor
description: Local ffmpeg-based video editing skill. Provides tested helpers for subtitles, background blur, color grading, two-pass loudness normalization, scene-detected highlight reels, watermarking, and format conversion. Honest scope: no AI segmentation, no transcription model, no external network calls.
license: MIT
metadata: {"openclaw":{"requires":{"bins":["ffmpeg","ffprobe","python3"]},"primaryEnv":null,"homepage":"https://clawhub.ai/gopendrasharma89-tech/openclaw-video-editor"}}
---

# openclaw-video-editor

v4.2.0

A small, honest video editing skill for OpenClaw built on `ffmpeg`, `ffprobe`, and `python3`. It runs entirely on the local machine. No external services, no AI segmentation, no transcription model.

## Scope

This skill provides:

- `scripts/check_deps.sh` — verify `ffmpeg`, `ffprobe`, `python3` are installed before any workflow runs.
- `scripts/generate_srt.py` — convert Whisper / Deepgram / AssemblyAI / generic word-timing JSON into `.srt`, `.vtt`, or `.ass`. Bug-fixed: chunk text no longer leaks across segment boundaries.
- `scripts/highlight_reel.py` — detect scene changes via ffmpeg and assemble a short highlight reel.
- `scripts/apply_lut.py` — apply a real `.cube` 3D LUT (`lut3d`), or use a named filter preset (`warm`, `cool`, `bw`, `high-contrast`, `faded`).
- `scripts/loudnorm_two_pass.py` — automate the two-pass `loudnorm` workflow end-to-end (NEW in v4.2.0).
- `scripts/make_vertical.py` — letterbox or center-crop a horizontal video into a 9:16 vertical with optional blurred-background fill (NEW in v4.2.0).

This skill does not perform:

- AI background removal or subject segmentation
- Voice cloning or generative video
- Transcription (it only formats word timings into subtitle files; pair with a separate STT tool)
- Any remote API calls

## Required binaries

```bash
bash scripts/check_deps.sh
```

Returns non-zero if `ffmpeg`, `ffprobe`, or `python3` is missing.

## Workflows

### 1. Generate subtitles from a transcript

```bash
python3 scripts/generate_srt.py transcript.json subtitles.srt
python3 scripts/generate_srt.py transcript.json subtitles.vtt
python3 scripts/generate_srt.py transcript.json subtitles.ass --font Helvetica --fontsize 28
```

Tunable: `--max-chars`, `--max-words`, `--max-duration` for non-English language tuning.

### 2. Burn subtitles into a video

```bash
ffmpeg -i input.mp4 \
  -vf "subtitles=subtitles.srt:force_style='Alignment=2,MarginV=30,Outline=2,Shadow=1'" \
  -c:a copy output.mp4
```

`Alignment=2` is bottom-center. Use `Alignment=8` for top-center.

### 3. Background blur (privacy filter, not subject segmentation)

True shallow-depth-of-field requires AI segmentation, which this skill does not include. The filter below is a full-frame blur:

```bash
ffmpeg -i input.mp4 -vf "boxblur=20:1" -c:a copy blurred.mp4
```

If you already have a binary alpha matte (`mask.mp4`, subject white, background black, frame-aligned), you can composite a blurred background behind the original subject:

```bash
ffmpeg -i input.mp4 -i mask.mp4 \
  -filter_complex "[0:v]boxblur=20:1[bg];[0:v][1:v]alphamerge[fg];[bg][fg]overlay=format=auto" \
  -c:a copy composited.mp4
```

Producing the matte itself is out of scope.

### 4. Color grading

Filter presets (no LUT file required):

```bash
python3 scripts/apply_lut.py input.mp4 - graded.mp4 --preset warm
python3 scripts/apply_lut.py input.mp4 - graded.mp4 --preset bw
```

Real `.cube` LUT:

```bash
python3 scripts/apply_lut.py input.mp4 lut.cube graded.mp4 --strength 0.8
```

### 5. Audio normalization (one command, NEW in v4.2.0)

Previously the SKILL.md only described the two-pass `loudnorm` flow without automating it. v4.2.0 ships a runner that does both passes:

```bash
# Broadcast (-23 LUFS, EBU R128)
python3 scripts/loudnorm_two_pass.py input.mp4 normalized.mp4

# Streaming platforms (-14 LUFS)
python3 scripts/loudnorm_two_pass.py input.mp4 normalized.mp4 --target-lufs -14
```

The script runs Pass 1, parses the JSON measurement block from ffmpeg's stderr, and runs Pass 2 with the measured offsets applied. Video is copied without re-encoding.

### 6. Highlight reel via scene detection

```bash
python3 scripts/highlight_reel.py input.mp4 highlight.mp4 --duration 30 --threshold 0.4
```

### 7. Watermarking

```bash
# Bottom-right text watermark
ffmpeg -i input.mp4 \
  -vf "drawtext=text='@yourhandle':x=w-tw-20:y=h-th-20:fontsize=24:fontcolor=white@0.7:box=1:boxcolor=black@0.4:boxborderw=8" \
  -c:a copy watermarked.mp4

# Image overlay (logo)
ffmpeg -i input.mp4 -i logo.png \
  -filter_complex "[0:v][1:v]overlay=W-w-20:20" \
  -c:a copy watermarked.mp4
```

### 8. Make vertical 9:16 for shorts (NEW in v4.2.0)

`make_vertical.py` offers three modes:

```bash
# Letterbox: original aspect inside a black 1080x1920 frame
python3 scripts/make_vertical.py input.mp4 vertical.mp4 --mode letterbox

# Crop: center-crop to 9:16
python3 scripts/make_vertical.py input.mp4 vertical.mp4 --mode crop

# Blur-fill: original centered, blurred copy of itself fills the bars
python3 scripts/make_vertical.py input.mp4 vertical.mp4 --mode blur-fill
```

`blur-fill` is the most popular look for repurposing horizontal content as shorts.

### 9. Format conversions

```bash
# 1080p H.264 with reasonable quality
ffmpeg -i input.mp4 -vf "scale=-2:1080" \
  -c:v libx264 -preset medium -crf 20 \
  -c:a aac -b:a 160k output_1080p.mp4
```

## Safety properties

- All workflows run locally. No remote API calls.
- Python helpers use `subprocess.run` with argument lists (never `shell=True`), and reject paths with shell metacharacters via a strict regex allowlist.
- The skill never modifies system configuration, environment variables, or other plugins.
- The skill only reads input files and writes output files at the paths the user provides.

## Known limitations

- Inputs must be valid video/audio files reachable on the local filesystem.
- The blur compositing path requires a pre-existing per-frame alpha matte. Producing the matte is out of scope.
- `make_vertical.py --mode blur-fill` does a full re-encode; the other modes also re-encode the video stream. Audio is copied where possible.

## v4.2.0 changes

- Description on the registry now matches the actual workflows. The previous "Pro-Studio AI background removal" copy contradicted the SKILL.md and triggered a registry mismatch warning even after the SKILL.md was rewritten in v4.1.0. v4.2.0 republishes the consistent description so the public listing and SKILL.md agree.
- `scripts/loudnorm_two_pass.py` automates the previously-manual broadcast loudness flow.
- `scripts/make_vertical.py` adds three vertical-conversion modes for shorts (`letterbox`, `crop`, `blur-fill`).
- Existing scripts (`generate_srt.py`, `highlight_reel.py`, `apply_lut.py`, `check_deps.sh`) are unchanged from v4.1.0; their bug fixes carry over.

## License

MIT. See `LICENSE`.
