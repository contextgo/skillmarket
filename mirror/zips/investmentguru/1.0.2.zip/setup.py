from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

# 使用灵活版本约束，避免固定版本带来的供应链风险
install_requires = [
    "click>=8.0",
    "rich>=12.0",
    "pandas>=1.5",
    "numpy>=1.21",
    "yfinance>=0.2",
    "akshare>=1.12",
    "baostock>=0.8",
    "scikit-learn>=1.0",
    "scipy>=1.9",
    "python-dateutil>=2.8",
    "requests>=2.28",
    "pytz>=2022",
    "typer>=0.9",
    "tabulate>=0.9",
    "colorama>=0.4",
]

setup(
    name="investment_gurus",
    version="2.0.0",
    author="Investment Gurus Team",
    author_email="contact@example.com",
    description="基于20位中外顶级投资大师的智能股票分析Skill",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://example.com",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Financial and Insurance Industry",
        "Topic :: Office/Business :: Financial :: Investment",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=install_requires,
    entry_points={
        "console_scripts": [
            "invest-guru=investment_gurus.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "investment_gurus": ["data/*.json"],
    },
    keywords="investment value-investing china-stocks guru analysis",
)