---
name: fund-analysis
description: '对指定公募基金进行分析，涵盖基本信息、业绩表现、区间业绩、基金经理观点及底层资产持仓。当用户询问某基金表现、基金经理观点或重仓股时触发。Use when: "分析易方达蓝筹精选", "这只基金最近半年表现", "基金重仓了哪些股票". Calls tools: guessFundCode, fundBasicInfo, fundPerformance, fundRecentViews, fundUnderAssets, fundRangePerformance.'
compatibility: 'Requires DeepQ MCP Server. Preferred: streamableHttp with access_token. Fallback: stdio via npx @deepqtech/mcp-server-js. DEEPQ_API_KEY env var or default sWxMywZpIt8N62JXGNng.'
metadata:
  author: deepqtech
  version: "1.0"
---

# 基金分析

## MCP Server 配置

本技能依赖 **DeepQ MCP Server** 提供数据工具。使用前请确保已在 agent 中配置 MCP Server。

### 推荐：Streamable HTTP（无需本地安装）

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-streamable": {
      "type": "streamableHttp",
      "url": "https://cgi.deepq.tech:9198/mcp-servers/mcp?access_token=sWxMywZpIt8N62JXGNng"
    }
  }
}
```

> `access_token` 优先使用环境变量 `DEEPQ_API_KEY` 的值，未设置时使用默认值 `sWxMywZpIt8N62JXGNng`。

### 备选：Stdio 本地进程

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-stdio": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@deepqtech/mcp-server-js@latest", "start"],
      "env": {
        "DEEPQ_API_KEY": "sWxMywZpIt8N62JXGNng"
      }
    }
  }
}
```

---

## 功能说明

围绕特定公募基金（主动/被动权益、债券、混合型等），提供：
- **基本信息**：基金类型、规模、成立日期、基金经理、费率
- **业绩表现**：近期各时间段收益率、最大回撤、夏普比率
- **区间业绩**：自定义时间段内的详细业绩归因
- **基金经理观点**：近期基金经理对市场和持仓的最新表态
- **底层资产**：十大重仓股、行业集中度、资产配置比例

## 触发场景

- "帮我分析一下易方达蓝筹精选"
- "这只基金最近半年表现怎么样？"
- "基金经理对后市怎么看？"
- "这只基金重仓了哪些股票？"

## 执行步骤

### 第一步：解析基金代码

```json
调用工具: guessFundCode
参数: { "query": "<用户输入的基金名称或代码>" }
```

### 第二步：综合基金分析（并行调用）

```json
调用工具: fundBasicInfo
参数: { "query": "<基金代码或名称>" }

调用工具: fundPerformance
参数: { "query": "<基金代码或名称>" }

调用工具: fundRecentViews
参数: { "query": "<基金代码或名称>" }

调用工具: fundUnderAssets
参数: { "query": "<基金代码或名称>" }
```

### 第三步（按需）：区间业绩查询

当用户指定了具体时间段时：

```json
调用工具: fundRangePerformance
参数: {
  "query": "<基金代码或名称>",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD"
}
```

### 第四步：整合输出报告

| 章节 | 数据来源 |
|---|---|
| 基金基本信息 | `fundBasicInfo` |
| 业绩表现（多周期） | `fundPerformance` |
| 自定义区间业绩 | `fundRangePerformance`（按需） |
| 基金经理最新观点 | `fundRecentViews` |
| 底层持仓分析 | `fundUnderAssets` |
| 综合评价 | 综合以上数据给出简明评价 |

## 注意事项

- 基金代码为 6 位数字，如 `110011`（易方达中小盘）。
- 公募基金持仓数据通常有季度滞后，最新重仓以最近一期季报为准。
- 过去业绩不代表未来收益，输出时需加免责声明。
