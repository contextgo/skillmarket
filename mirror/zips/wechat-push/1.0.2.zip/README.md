# wechat-push - 微信公众号推文助手

微信公众号推文写作与发布助手，支持深度文章撰写、智能配图、API 配置和草稿箱上传。

## 功能特性

- ✅ **深度写作** - 每篇文章 1500-2500 字
- ✅ **分段标题** - H1/H2/H3 清晰结构
- ✅ **智能配图** - Pexels/Unsplash 无版权图片
- ✅ **API 配置** - 完整的配置引导流程
- ✅ **草稿上传** - 直接上传到公众号草稿箱

## 快速开始

### 1. 配置微信公众号 API

在 `openclaw.json` 中添加：

```json
{
  "channels": {
    "openclaw-weixin": {
      "accounts": {
        "default": {
          "appId": "你的 AppID",
          "appSecret": "你的 AppSecret"
        }
      }
    }
  }
}
```

### 2. 配置 IP 白名单

登录微信公众平台 → 开发 → 基本配置 → API IP 白名单

添加你的服务器公网 IP。

### 3. 使用技能

```
写 3 篇热点推文，1500 字以上，配图，保存到草稿箱
```

## 文章规范

- **字数**：1500-2500 字
- **结构**：H1 主标题 + H2 章节标题 + H3 小节标题
- **配图**：每 500-800 字 1 张，共 2-4 张
- **图片**：使用 Pexels/Unsplash 无版权图片

## 文件结构

```
wechat-push/
├── SKILL.md      # 技能详细说明
├── README.md     # 本文件
├── package.json  # 包信息
└── examples/     # 使用示例
```

## License

MIT
