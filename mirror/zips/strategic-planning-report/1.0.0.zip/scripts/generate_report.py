#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
战略规划报告 DOCX 生成器
使用 python-docx 库生成专业 Word 文档

依赖：pip install python-docx

用法：
  python generate_report.py <公司名> <规划年数> <输出路径>
  
或作为模块导入：
  from generate_report import StrategicReportGenerator
  gen = StrategicReportGenerator("XX公司", 5)
  gen.set_module_content(1, "...模块1内容...")
  ...
  gen.save("output.docx")
"""

import os
import sys
from datetime import datetime


class StrategicReportGenerator:
    """战略规划报告 DOCX 生成器"""
    
    # 模块配色（用于表头和标题装饰）
    COLORS = {
        "ext": (27, 134, 171),      # 外部环境 - 科技蓝 #2E86AB
        "int": (39, 174, 96),        # 内部环境 - 成功绿 #27AE60
        "exec": (241, 143, 1),       # 战略落地 - 橙色 #F18F01
        "primary": (27, 42, 74),     # 主色 - 深海军蓝 #1B2A4A
        "text": (45, 52, 54),        # 正文色
    }
    
    def __init__(self, company_name, period_years):
        self.company_name = company_name
        self.period_years = period_years
        self.end_year = datetime.now().year + period_years - 1
        self.current_date = datetime.now().strftime("%Y年%m月%d日")
        self.modules_data = {}
        
        try:
            from docx import Document
            from docx.shared import Pt, Cm, Inches, RGBColor
            from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
            from docx.enum.table import WD_TABLE_ALIGNMENT
            from docx.enum.section import WD_ORIENT
            from docx.oxml.ns import qn, nsdecls
            from docx.oxml import parse_xml
            self.Document = Document
            self.Pt = Pt
            self.Cm = Cm
            self.Inches = Inches
            self.RGBColor = RGBColor
            self.WD_ALIGN_PARAGRAPH = WD_ALIGN_PARAGRAPH
            self.WD_LINE_SPACING = WD_LINE_SPACING
            self.WD_TABLE_ALIGNMENT = WD_TABLE_ALIGNMENT
            self.qn = qn
            self._deps_ok = True
        except ImportError:
            print("错误：缺少 python-docx 依赖，请运行 pip install python-docx")
            self._deps_ok = False
    
    def set_module_content(self, module_num, content_html):
        """设置模块内容"""
        self.modules_data[str(module_num)] = content_html
    
    def _get_doc(self):
        """创建文档实例并设置页面样式"""
        doc = self.Document()
        
        # 页面设置：A4
        for section in doc.sections:
            section.page_width = self.Cm(21)
            section.page_height = self.Cm(29.7)
            section.top_margin = self.Cm(2.54)
            section.bottom_margin = self.Cm(2.54)
            section.left_margin = self.Cm(3.17)
            section.right_margin = self.Cm(3.17)
            
            # 页眉
            header = section.header
            header_para = header.paragraphs[0]
            header_para.text = f"{self.company_name} · 战略规划报告"
            header_para.alignment = self.WD_ALIGN_PARAGRAPH.CENTER
            run = header_para.runs[0]
            run.font.size = self.Pt(9)
            run.font.color.rgb = self.RGBColor(150, 150, 150)
            
            # 页脚（页码）
            footer = section.footer
            footer_para = footer.paragraphs[0]
            footer_para.text = "— "
            footer_para.alignment = self.WD_ALIGN_PARAGRAPH.CENTER
        
        return doc
    
    def _add_cover_page(self, doc):
        """添加封面页"""
        # 空行占位
        for _ in range(6):
            doc.add_paragraph()
        
        # 公司名称
        p = doc.add_paragraph()
        p.alignment = self.WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(self.company_name)
        run.font.size = self.Pt(36)
        run.font.bold = True
        run.font.color.rgb = self.RGBColor(*self.COLORS["primary"])
        run.font.name = "黑体"
        run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '黑体')
        
        # 分隔线
        p = doc.add_paragraph()
        p.alignment = self.WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("━" * 20)
        run.font.color.rgb = self.RGBColor(*self.COLORS["exec"])
        run.font.size = self.Pt(14)
        
        # 副标题
        p = doc.add_paragraph()
        p.alignment = self.WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("战 略 规 划 报 告")
        run.font.size = self.Pt(24)
        run.font.color.rgb = self.RGBColor(*self.COLORS["primary"])
        run.font.name = "黑体"
        run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '黑体')
        
        # 规划周期
        p = doc.add_paragraph()
        p.alignment = self.WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(
            f"规划周期：{datetime.now().year}年 — {self.end_year}年（{self.period_years}年）"
        )
        run.font.size = self.Pt(14)
        run.font.color.rgb = self.RGBColor(100, 100, 100)
        
        # 日期
        p = doc.add_paragraph()
        p.alignment = self.WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"编制日期：{self.current_date}")
        run.font.size = self.Pt(12)
        run.font.color.rgb = self.RGBColor(140, 140, 140)
        
        # 分页
        doc.add_page_break()
    
    def _add_toc(self, doc):
        """添加目录页"""
        p = doc.add_paragraph()
        run = p.add_run("目  录")
        run.font.size = self.Pt(22)
        run.font.bold = True
        run.font.color.rgb = self.RGBColor(*self.COLORS["primary"])
        run.font.name = "黑体"
        run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '黑体')
        p.alignment = self.WD_ALIGN_PARAGRAPH.CENTER
        
        doc.add_paragraph()
        
        modules_toc = [
            ("一", "外部环境分析", "", None),
            ("", "  模块1：国家政策分析", "ext", 1),
            ("", "  模块2：产业洞察", "ext", 2),
            ("", "  模块3：竞争对手产品分析", "ext", 3),
            ("二", "内部环境分析", "", None),
            ("", "  模块4：公司内部业务梳理", "int", 4),
            ("", "  模块5：解决方案及产品规划", "int", 5),
            ("", "  模块6：技术研发战略规划", "int", 6),
            ("三", "战略落地", "", None),
            ("", "  模块7：关键举措", "exec", 7),
            ("", "  模块8：销售及研发预算", "exec", 8),
            ("", "  模块9：绩效计划及评审办法", "exec", 9),
            ("四", "附录", "", None),
        ]
        
        for num, title, color_type, mod_id in modules_toc:
            p = doc.add_paragraph()
            if num in ["一", "二", "三", "四"]:
                # 大章节标题
                run = p.add_run(f"  {num}、{title}")
                run.font.bold = True
                run.font.size = self.Pt(13)
                run.font.color.rgb = self.RGBColor(*self.COLORS["primary"])
            else:
                # 子项
                run = p.add_run(f"    {title}")
                run.font.size = self.Pt(11)
                if color_type:
                    run.font.color.rgb = self.RGBColor(*self.COLORS[color_type])
            run.font.name = "宋体"
            run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '宋体')
        
        doc.add_page_break()
    
    def _add_heading_styled(self, doc, text, level=1, color_type=None):
        """添加带样式的标题"""
        p = doc.add_paragraph()
        run = p.add_run(text)
        run.font.name = "黑体"
        run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '黑体')
        
        if level == 1:
            # 一级标题（模块名）
            run.font.size = self.Pt(18)
            run.font.bold = True
            if color_type and color_type in self.COLORS:
                run.font.color.rgb = self.RGBColor(*self.COLORS[color_type])
            else:
                run.font.color.rgb = self.RGBColor(*self.COLORS["primary"])
            # 添加底部边框线效果
            p2 = doc.add_paragraph()
            run2 = p2.add_run("─" * 40)
            run2.font.color.rgb = self.RGBColor(
                *self.COLORS.get(color_type, self.COLORS["primary"])
            )
            run2.font.size = self.Pt(6)
        elif level == 2:
            run.font.size = self.Pt(15)
            run.font.bold = True
            run.font.color.rgb = self.RGBColor(
                *self.COLORS.get(color_type, (45, 52, 54))
            )
        elif level == 3:
            run.font.size = self.Pt(13)
            run.font.bold = True
            run.font.color.rgb = self.RGBColor(45, 52, 54)
        else:
            run.font.size = self.Pt(11)
            run.font.bold = True
        
        return p
    
    def _add_body_text(self, doc, text):
        """添加正文段落"""
        p = doc.add_paragraph()
        run = p.add_run(text)
        run.font.size = self.Pt(11)
        run.font.name = "宋体"
        run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '宋体')
        p.paragraph_format.line_spacing_rule = self.WD_LINE_SPACING.ONE_POINT_FIVE
        p.paragraph_format.first_line_indent = self.Cm(0.74)  # 首行缩进两字符
        return p
    
    def _add_table_styled(self, doc, headers, rows, color_type="primary"):
        """添加带样式的表格"""
        table = doc.add_table(rows=1 + len(rows), cols=len(headers))
        table.style = "Table Grid"
        table.alignment = self.WD_TABLE_ALIGNMENT.CENTER
        
        color = self.COLORS.get(color_type, self.COLORS["primary"])
        
        # 表头
        hdr_cells = table.rows[0].cells
        for i, h in enumerate(headers):
            hdr_cells[i].text = h
            for para in hdr_cells[i].paragraphs:
                para.alignment = self.WD_ALIGN_PARAGRAPH.CENTER
                for run in para.runs:
                    run.font.bold = True
                    run.font.size = self.Pt(10)
                    run.font.color.rgb = self.RGBColor(255, 255, 255)
                    run.font.name = "黑体"
                    run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '黑体')
            # 设置表头背景色
            shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color[0]:02X}{color[1]:02X}{color[2]:02X}"/>')
            hdr_cells[i]._tc.get_or_add_tcPr().append(shading)
        
        # 数据行
        for r_idx, row_data in enumerate(rows):
            row_cells = table.rows[r_idx + 1].cells
            for c_idx, cell_text in enumerate(row_data):
                row_cells[c_idx].text = str(cell_text)
                for para in row_cells[c_idx].paragraphs:
                    for run in para.runs:
                        run.font.size = self.Pt(10)
                        run.font.name = "宋体"
                        run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '宋体')
                # 交替行背景色
                if r_idx % 2 == 1:
                    shading = parse_xml(
                        f'<w:shd {nsdecls("w")} w:fill="F5F7FA"/>'
                    )
                    row_cells[c_idx]._tc.get_or_add_tcPr().append(shading)
        
        doc.add_paragraph()  # 表后空行
        return table
    
    def _add_module_section(self, doc, module_num, title, content, color_type):
        """添加一个完整的模块章节"""
        # 模块一级标题
        badge = f"【模块{module_num}】"
        self._add_heading_styled(doc, f"{badge} {title}", level=1, color_type=color_type)
        
        # 内容区域 — 将HTML/Markdown内容转为段落和表格
        if content and content.strip():
            # 解析内容：按段落拆分
            lines = content.split('\n')
            current_rows = []
            table_headers = None
            in_table = False
            
            for line in lines:
                stripped = line.strip()
                
                # 检测表格头（| ... |）
                if stripped.startswith('|') and not all(c == '-' or c in '|:' for c in stripped.replace(' ', '')):
                    cells = [c.strip() for c in stripped.split('|')[1:-1]]
                    
                    # 跳过分隔行
                    if cells and all(set(c) <= set('-: ') for c in cells):
                        continue
                    
                    if not in_table:
                        # 新表格开始
                        table_headers = cells
                        current_rows = []
                        in_table = True
                    else:
                        current_rows.append(cells)
                
                else:
                    # 非表格内容：先输出之前的表格
                    if in_table and table_headers:
                        try:
                            self._add_table_styled(doc, table_headers, current_rows, color_type)
                        except Exception:
                            pass
                        in_table = False
                        table_headers = None
                        current_rows = []
                    
                    # 处理标题
                    if stripped.startswith('#'):
                        level = len(stripped) - len(stripped.lstrip('#'))
                        title_text = stripped.lstrip('#').strip()
                        if level >= 2:
                            self._add_heading_styled(doc, title_text, level=min(level + 1, 4), color_type=color_type)
                    # 处理列表
                    elif stripped.startswith('- ') or stripped.startswith('* '):
                        p = doc.add_paragraph(style='List Bullet')
                        run = p.add_run(stripped[2:])
                        run.font.size = self.Pt(11)
                        run.font.name = "宋体"
                        run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '宋体')
                    elif stripped.startswith('- **') or stripped.startswith('- **'):
                        text = stripped.strip('- ').strip('*').strip(': ')
                        parts = text.split('**:', 1) if '**:' in text else [text, ""]
                        label = parts[0] if parts else text
                        p = doc.add_paragraph(style='List Bullet')
                        run = p.add_run(label)
                        run.font.size = self.Pt(11)
                        run.font.bold = "**" in stripped[:10]
                        run.font.name = "宋体"
                        run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '宋体')
                    elif stripped and not stripped.startswith('<') and len(stripped) > 2:
                        self._add_body_text(doc, stripped)
            
            # 处理末尾的未闭合表格
            if in_table and table_headers:
                try:
                    self._add_table_styled(doc, table_headers, current_rows, color_type)
                except Exception:
                    pass
        else:
            self._add_body_text(doc, "[本模块内容待填充]")
    
    def generate(self, output_path):
        """生成完整报告"""
        if not self._deps_ok:
            raise ImportError("python-docx 未安装")
        
        doc = self._get_doc()
        
        # 1. 封面
        self._add_cover_page(doc)
        
        # 2. 目录
        self._add_toc(doc)
        
        # 3. 执行摘要
        self._add_heading_styled(doc, "执行摘要", level=1, color_type="exec")
        summary_items = [
            f"公司名称：{self.company_name}",
            f"规划周期：{datetime.now().year}年 — {self.end_year}年",
            f"编制日期：{self.current_date}",
            "",
            "本报告涵盖外部环境分析（国家政策、产业洞察、竞品分析）、",
            "内部环境梳理（业务板块、产品规划、技术研发）以及战略落地",
            "（关键举措、预算规划、绩效计划）九大模块。",
        ]
        for item in summary_items:
            if item:
                self._add_body_text(doc, item)
            else:
                doc.add_paragraph()
        
        # 4. 分页进入正文章节
        doc.add_page_break()
        
        # 5-13. 九大模块
        module_config = [
            (1, "国家政策分析", "ext"),
            (2, "产业洞察", "ext"),
            (3, "竞争对手产品分析", "ext"),
            (4, "公司内部业务梳理", "int"),
            (5, "解决方案及产品规划", "int"),
            (6, "技术研发战略规划", "int"),
            (7, "关键举措", "exec"),
            (8, "销售及研发预算", "exec"),
            (9, "绩效计划及评审办法", "exec"),
        ]
        
        for mod_num, mod_title, color_type in module_config:
            content = self.modules_data.get(str(mod_num), "")
            self._add_module_section(doc, mod_num, mod_title, content, color_type)
            doc.add_page_break()  # 每个模块分页
        
        # 14. 附录
        self._add_heading_styled(doc, "附录", level=1)
        self._add_heading_styled(doc, "A. 数据来源说明", level=3)
        sources = [
            "- 国家政策数据来源：中国政府网(gov.cn)、发改委、工信部等官方网站",
            "- 产业洞察数据来源：行业研究报告(Gartner/IDC/艾瑞等)、金融数据接口",
            "- 竞品信息来源：公开官网、行业评测、专利检索系统",
            "- 内部数据来源：用户提供的业务资料与访谈输入",
        ]
        for s in sources:
            self._add_body_text(doc, s)
        
        self._add_heading_styled(doc, "B. 方法论说明", level=3)
        methods = [
            "- 外部环境采用 PEST 分析框架",
            "- 内部能力基于资源基础理论(RBV)",
            "- 战略举措通过 SWOT 矩阵推导",
            "- 预算参考行业标杆数据(收入占比法)",
            "- 绩效设计遵循 SMART 原则与 OKR/KPI 混合模式",
        ]
        for m in methods:
            self._add_body_text(doc, m)
        
        # 免责声明
        doc.add_paragraph()
        p = doc.add_paragraph()
        run = p.add_run(
            "⚠️ 本报告由 AI 战略规划报告生成工具辅助制作，数据基于公开信息采集和AI分析，仅供参考。"
            "关键决策请结合公司内部数据和专业咨询。"
        )
        run.font.size = self.Pt(9)
        run.font.color.rgb = self.RGBColor(180, 180, 180)
        run.font.name = "宋体"
        run._element.rPr.rFonts.set(self.qn('w:eastAsia'), '宋体')
        p.alignment = self.WD_ALIGN_PARAGRAPH.CENTER
        
        # 保存
        output_dir = os.path.dirname(output_path)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        doc.save(output_path)
        return output_path


# ========== CLI 入口 ==========

def main():
    if len(sys.argv) < 4:
        print("用法: python generate_report.py <公司名> <规划年数> <输出路径>")
        print("")
        print("示例:")
        print("  python generate_report.py \"XX科技有限公司\" 5 ./output/战略规划报告.docx")
        sys.exit(1)
    
    company = sys.argv[1]
    years = int(sys.argv[2])
    output = sys.argv[3]
    
    print(f"正在生成 {company} {years}年战略规划报告...")
    print("=" * 50)
    
    gen = StrategicReportGenerator(company, years)
    
    # 如果提供了JSON数据文件，加载模块内容
    if len(sys.argv) >= 5:
        data_path = sys.argv[4]
        import json
        with open(data_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        for k, v in data.items():
            gen.set_module_content(k, v)
    
    result = gen.generate(output)
    print(f"\n✅ 报告已生成: {result}")
    return result


if __name__ == "__main__":
    main()
