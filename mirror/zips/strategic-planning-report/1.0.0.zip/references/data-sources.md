# 数据来源参考 — 模块1政策/模块2产业

本文件列示各模块的推荐数据源URL及采集方式，供AI Agent自动调用 web_fetch / web_search 时参考。

---

## 模块1: 国家政策

### 中央政府
| 站点 | URL | 采集方式 | 内容 |
|------|-----|---------|------|
| 中国政府网 | https://www.gov.cn/ | web_fetch | 国务院文件、十五五规划纲要 |
| 发改委 | https://www.ndrc.gov.cn/ | web_fetch | 产业政策、发展规划 |
| 工信部 | https://www.miit.gov.cn/ | web_fetch | 行业规范、数字化转型政策 |
| 科技部 | https://www.most.gov.cn/ | web_fetch | 科技创新政策、重点研发计划 |
| 市场监管总局 | https://www.samr.gov.cn/ | web_fetch | 合规法规 |

### 搜索关键词模板
- "{行业名} 十五五规划"
- "{行业名} 国家政策 扶持"
- "数字经济 政策 {年份}"
- "人工智能 发展规划"
- "{行业名} 税收优惠 补贴"

---

## 模块2: 产业洞察

### 行业报告来源
| 来源 | URL | 采集方式 | 内容 |
|------|-----|---------|------|
| 中国信通院 | https://www.caict.ac.cn/ | web_fetch | 数字经济白皮书、行业报告 |
| CNNIC | https://www.cnnic.net.cn/ | web_fetch | 互联网发展报告 |
| 艾瑞咨询 | https://www.iresearch.cn/ | web_search | 行业研究报告 |
| IDC中国 | https://www.idc.com/cn | web_search | IT市场分析 |
| Gartner | https://www.gartner.com/ | web_search | 技术成熟度曲线 |
| 36氪研究院 | https://36kr.com/research | web_search | 创投/行业分析 |

### 技术动态来源
| 来源 | URL | 采集方式 | 内容 |
|------|-----|---------|------|
| GitHub Trending | https://github.com/trending | web_fetch | 开源项目热点 |
| Papers with Code | https://paperswithcode.com/ | web_fetch | AI论文与代码 |
| HuggingFace | https://huggingface.co/ | web_search | 模型/数据集动态 |
| arXiv | https://arxiv.org/ | web_search | 前沿论文 |

### 搜索关键词模板
- "{技术名} 发展趋势 {年份}"
- "{行业名} 市场规模 报告"
- "{技术名} 落地场景 案例"
- "AI Agent 技术发展现状"
- "{行业名} 产业链 上中下游"

---

## 模块3: 竞品分析

### 竞品信息来源
| 来源 | 采集方式 | 内容 |
|------|---------|------|
| 竞品官网 | web_fetch | 产品介绍、定价、客户案例 |
| 天眼查/企查查 | web_search | 工商信息、融资历程 |
| IT桔子 | web_search | 融资/估值数据 |
| 各大云市场 | web_search | 产品评价、上架情况 |
| 行业媒体 | web_search | 报道、评测文章 |
| 专利检索(国家知识产权局) | web_search | 技术专利布局 |

### 搜索关键词模板
- "{竞品名} 产品 功能"
- "{竞品名} 定价 价格"
- "{竞品名} 融资 估值"
- "{竞品名} 客户案例"
- "{行业名} 竞品对比 评测"
