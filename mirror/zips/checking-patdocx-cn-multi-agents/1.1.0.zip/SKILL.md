---
name: checking-patdocx-cn-multi-agents
description: |
  使用多Agent并行架构审查中国专利申请文件(.docx/.doc)，生成带修订追踪和批注的docx副本及结构化markdown审查报告。当用户要求检查、审查、审阅或校对中国专利申请文件(.docx/.doc)时使用，尤其是用户明确要求使用多Agent模式或并行审查时使用。不要用于用户只想查看专利文档而不审查、输入文件不是.docx/.doc格式、或用户要求翻译专利文档的情况。
------

# 中国专利申请文件多Agent并行审查器

使用**多Agent分批并行架构**对中文专利申请文档（.docx / .doc）进行AI辅助审查。12条审查规则分配到12个独立Agent分批并行执行（每个Agent仅加载1条审查规则，避免上下文窗口不足），文档提取、审查合并、报告生成和批注添加均委托给子Agent执行。主Agent仅负责编排、调度和关键决策。

> ⚠️ **.doc 格式支持**：本 skill 支持输入 `.doc` 格式文件。处理时会自动使用 pywin32（COM 自动化）调用 Microsoft Word 将 `.doc` 转换为 `.docx`，然后按标准流程处理。**要求**：Windows 系统 + 已安装 WPS 或 Microsoft Word  + 已安装 pywin32 库。

## 适用场景

- 用户要求检查、审查、审阅或校对中国专利申请 .docx 或 .doc 文件
- 用户提供中国专利申请 .docx 或 .doc 文件要求进行质量检查
- 用户希望发现中国专利申请文件中的撰写问题

## 不适用场景

- 用户只想查看或阅读专利文档，无需审查
- 输入文件不是 .docx 或 .doc 格式（如 .pdf、.txt）
- 用户咨询专利策略、可专利性分析或法律建议（本 skill 仅检查撰写质量）
- 用户要求翻译专利文档

## 输入 / 输出

**输入：**
- `input_doc`：字符串 — 待审查的 .docx 或 .doc 文件的绝对路径

**输出：**
- `reviewed_docx`：字符串 — 带修订追踪和批注的审查后 .docx 文件的绝对路径
- `report_md`：字符串 — 结构化 markdown 审查报告的绝对路径
- `work_dir`：字符串 — 包含中间文件的工作目录的绝对路径

## 关键约束

> ⛔ 以下约束至关重要。违反将导致内容丢失或结果不可靠。详细说明见 `references/prohibitions-and-rules.md`。

1. **必须使用 `review_adder.py`** 添加批注 — 禁止编写自定义脚本（会导致内容丢失）
2. **禁止跳过验证**（第7步）— 未通过验证的文档不得交付给用户
3. **必须直接调用提供的脚本** — 禁止使用 `python -c` 执行多行代码
4. **必须在输入文件所在目录下创建工作目录** — 禁止在 skill 目录内创建
5. **必须通过命令获取真实时间戳** — 禁止编造时间戳
6. **每个子Agent仅执行其分配的规则** — 禁止在一个Agent中组合不相关的规则
7. **主Agent不得撰写审查意见** — 必须通过 Task 工具委托给子Agent
8. **主Agent不得执行可委托的步骤** — 提取、合并、报告、批注必须委托执行
9. **JSON 字符串值中禁止使用未转义的双引号或中文引号** — 使用 `''` 代替；禁止使用 `""`（中文引号与 `""` 外观相同，会导致 JSON 解析失败）；禁止使用 `""` 作为 JSON 字符串边界
10. **必须分批并行启动审查Agent**（第1批2个，后续批次按分组规则）— 禁止逐个 sequential 启动；每批验证通过后方可启动下一批
11. **context、old_text 和 highlight_text 必须是文档中的 verbatim copy** — 禁止改写、重述或添加字符；任何不匹配都会导致批注失败；highlight_text 必须是 context 的子串
12. **每个审查Agent只能审查其分配的章节** — 禁止审查分配给其他Agent的章节
13. **审查Agent必须执行自验证** — 输出 JSON 后，重新阅读源文本并验证每个 context 是否 verbatim 存在
14. **当相同 context 出现多次时必须使用 occurrence 字段** — 如果同一文本片段在多个位置出现且只需标注特定出现位置，必须指定 `occurrence` 字段（从1开始的整数）；未指定时仅标注第一次出现
15. **context、old_text 中禁止使用 HTML/XML 标签** — 这些字段必须是文档中的 verbatim copy；`<br>`、`<p>`、`<div>` 等标签不是文档文本，会导致批注失败（跳过）
16. **context、old_text 中禁止包含换行符 `\n`** — docx 中换行是段落分隔，跨段落的文本无法被匹配；涉及跨段落的问题必须拆分为多条审查意见
17. **suggestion 的修改方向必须与 issue 诊断一致** — 禁止出现"问题为不应使用'所述'但建议添加'所述'"的逻辑矛盾
18. **Agent 11/12 仅报告跨章节一致性问题** — 禁止报告单章节内部的问题（由 Agent 1-10 负责），避免重复审查
19. **文档提取禁止使用 `>` 重定向** — 必须使用 `--extract-output` 参数输出到文件，避免 PowerShell 编码问题
20. **禁止要求用户管理/删除中间文件，禁止子Agent自行删除中间产物** — 所有中间产物统一保留在工作目录中，使用完毕后直接保留，不询问用户是否删除；禁止要求用户删除、移动、重命名任何文件（包括但不限于验证脚本、临时脚本、中间JSON等）；禁止在任务完成时询问用户是否清理中间文件；禁止因中间文件存在而停止工作流程等待用户决策；⛔⛔⛔ 子Agent不得自行删除/清理任何中间产物（包括脚本文件、临时JSON、中间TXT等），子Agent默认"用完即清理"的行为必须改为"用完即保留"，所有中间产物对排查问题有参考价值，必须保留。**文件冲突处理**：如果输出文件已存在，直接覆盖（Write 工具会自动覆盖），禁止停下来询问用户是否删除旧文件；禁止因任何文件操作问题而停止工作流程等待用户操作
21. **禁止在工作目录外创建脚本或中间文件** — 所有中间产物（包括临时脚本）必须放在 `<work_dir>` 中；禁止在项目根目录、skill 目录或其他位置创建 `.py`、`.ps1`、`.sh`、`.bat`、`.json`、`.txt` 等任何类型的中间文件；无论是什么脚本类型，都必须放入 `<work_dir>`
22. **审查Agent只能读取分配章节的拆分文件** — 每个Agent只能读取其所需章节对应的 `section_<章节名>_<timestamp>.json` 文件，禁止读取完整 `sections_<timestamp>.json`（Agent 11/12 除外，可读取多个拆分文件）
23. **context 中禁止添加原文不存在的标点符号** — 小参数 LLM 常在 context 末尾自行添加句号"。"等标点，导致 review_adder.py 无法匹配；context 必须逐字复制原文，包括标点符号也必须与原文完全一致
24. **Agent 10 禁止轻易输出空数组** — 必须对审查规则中列出的每种"公开不充分"情形逐一检查并给出明确判断，不得笼统跳过
25. **审查Agent必须优先写入JSON输出文件** — 完成分析后立即将审查意见写入JSON文件，然后再执行自验证步骤；禁止在写入JSON之前执行冗长的自验证分析，避免上下文耗尽导致JSON文件未生成
26. **合并去重时必须检测并解决修订冲突** — 当多条审查意见的 old_text 指向同一段落内的重叠文本区域时（即一条意见的 old_text 与另一条意见的 context 或 old_text 有交集），必须合并或调整这些意见，避免 review_adder.py 顺序处理时前一条 replace/delete 修改文本导致后一条无法匹配
27. **自验证步骤禁止创建任何脚本文件** — 必须直接读取JSON文件和源文本文件进行验证，禁止创建任何脚本文件（包括但不限于 .py、.ps1、.sh、.bat、.vbs 等）执行验证；创建脚本浪费上下文且可能引入额外错误，更严重的是脚本可能被创建在工作目录外
28. **new_text 禁止包含换行符 `\n`** — docx 中换行是段落分隔，无法通过 new_text 插入新段落；如需在已有段落末尾追加内容，new_text 只能是单行文本；如需添加新段落，应使用 comment 类型在批注中说明
29. **审查Agent必须节约上下文** — 小参数LLM上下文窗口有限，审查Agent必须：a)完成分析后立即写入JSON文件，禁止在写入前执行冗长分析；b)自验证时只逐条检查关键项，禁止重写整个JSON；c)如果上下文即将耗尽，优先确保JSON文件已写入，自验证可以简化
30. **suggestion 必须逻辑自洽** — 禁止出现 suggestion 与 issue 诊断矛盾的情况（如issue说"应改为X"但suggestion却说"将X改为Y"）；每条审查意见的 issue、suggestion、old_text、new_text 四个字段必须逻辑一致；小参数LLM处理批量相似修改时容易混淆，必须逐条检查
31. **主Agent禁止直接运行文档提取命令** — 第3步文档提取和章节拆分必须通过 Task 工具委托"文档提取Agent"子Agent执行，禁止主Agent直接使用 RunCommand 调用 patent_extractor.py。这是硬性委托规则，即使主Agent知道命令格式也必须委托
32. **Agent 9/10 禁止报告跨章节一致性问题** — 发明名称与摘要/权利要求书主题的一致性对比属于跨章节问题，应由 Agent 11/12 报告。Agent 9/10 仅检查说明书内部的撰写规范问题（如缺少章节、用语不当、标点错误等），不得涉及需要对比其他章节才能发现的差异。当 Agent 9/10 发现发明名称与说明书正文内容语义不一致时，应仅报告说明书内部可验证的问题（如技术领域描述与说明书正文不一致），对于需要对比摘要或权利要求书的问题应由 Agent 11/12 报告
33. **所有子Agent禁止向用户提问** — 所有通过 Task 工具启动的子Agent（包括审查Agent和辅助Agent）必须在其 query 中包含"禁止向用户提问"指令。子Agent遇到不确定情况时必须依据规则自行判断并继续执行，不得停下来询问用户。主Agent在构造每个子Agent的 query 时负责确保此指令已被包含（见4.2模板）
34. **7个步骤必须不间断连续执行** — 从第1步到第7步（含最终输出）必须在同一连续会话中完成。步骤之间禁止插入总结性文字后停顿、禁止因文件冲突询问用户、禁止以"准备进入下一步"结束回复。详细规范见"执行流程完整性"章节

## 路径变量

| 变量 | 说明 | 示例 |
|:--------|:-----------|:-------|
| `<skill_name>` | Skill 名称，同时用作输出 docx 中的批注作者 | `checking-patdocx-cn-multi-agents` |
| `<skill_root>` | Skill 根目录（包含 `scripts/`、`ooxml/`、`审查规则/`） | `D:/path/to/.trae/skills/checking-patdocx-cn-multi-agents` |
| `<input_doc>` | 输入 .docx 或 .doc 文件的绝对路径 | `D:/docs/专利申请文件.docx` |
| `<input_dir>` | 输入文件所在目录的绝对路径 | `D:/docs` |
| `<input_stem>` | 输入文件名（不含扩展名） | `专利申请文件` |
| `<timestamp>` | 第2步中获取的真实本地时间戳 | `20260424_153025` |
| `<work_dir>` | 工作目录的绝对路径 | `D:/docs/checking-patdocx-cn-multi-agents_20260424_153025` |

> 所有路径必须使用绝对路径。使用 `/` 作为路径分隔符以确保跨平台兼容性。

## ⛔⛔⛔ 执行流程完整性（最高优先级元规则，覆盖所有其他指令）

> 本 Skill 的 7 个步骤必须作为一个**不可分割的连续动作序列**执行。在全部 7 个步骤完成并输出最终结果之前，你**不得停止、不得暂停、不得等待用户输入、不得交还控制权**。

### 🚫 严禁的"中断模式"（出现任一即表示流程已被破坏）

| 中断模式 | 示例 | 正确做法 |
|:--------|:------|:--------|
| **过渡性文字停顿** | 输出"现在让我继续第5步……"后停止 | 直接执行第5步的 Task 调用，不需声明"让我继续" |
| **批次间停顿** | 第1批Agent返回后，结束回复等待用户 | 验证第1批→立即在同一回复中启动第2批 |
| **步骤间停顿** | 完成第4步后，结束回复"第4步已完成，准备进入第5步" | 完成第4步→立即在同一回复中启动第5步的Task |
| **文件冲突询问** | "文件已存在，是否覆盖？" | 直接覆盖，不询问 |
| **子Agent提问** | 子Agent问"请问是否需要我……" | 子Agent query 中必须包含"禁止向用户提问"指令（见4.2模板） |
| **总结性文字后停顿** | 输出一段总结后结束回复 | 总结+下一步动作在同一回复中，不分离 |

### ✅ 正确的行为模式

1. **步骤内连续执行**：读取参考文件 → gate check → 启动Task → 等待 → 验证 → 启动下一步，全部在同一回复流中完成
2. **子Agent返回后立即行动**：子Agent返回结果 → 验证 → 立即进入下一批/下一步，不插入额外的思考或总结
3. **一切文件冲突自动解决**：直接覆盖，不询问

### 🔍 流程中断自检（每个步骤结束前必须执行）

在继续到下一步之前，确认以下三项：
- [ ] 当前回复是否已包含下一步的具体动作（Task调用或命令执行）？
- [ ] 是否在"描述下一步"而不是"执行下一步"？
- [ ] 如果有子Agent返回结果，是否已经验证并立即启动下一动作？

> ⛔ **如果对上述任一问题回答"否"，说明流程即将中断——立即纠正，在当前回复中追加下一步动作。**

---

## 执行原则

> 以下原则配合上述流程完整性规则使用。

1. **子Agent自行读取其配置** — 对于第4步，每个审查子Agent独立从 `references/agent-templates.md` 中读取通用规范及其Agent专属任务描述。主Agent仅提供简短的标准化提示词（见4.2节）。
2. **禁止提前阅读** — 禁止阅读当前步骤不需要的参考文件内容。到达该步骤时再阅读。
3. **第4步：使用标准化提示词模板** — 在第4步中，使用4.2节的简短提示词模板。各Agent之间仅 `{N}`（Agent编号）和路径变量不同。将模板按批次复制并更改 `{N}`，然后分批并行启动所有12个Agent。禁止为每个Agent构造冗长的自定义查询。

## 工作流

### 第1步：验证文件类型

- [ ] 检查输入文件扩展名是否为 `.docx` 或 `.doc`（不区分大小写）
- 如果**不是** .docx/.doc：告知用户仅支持 .docx 和 .doc 格式，然后**终止**
- 如果是 .docx 或 .doc：继续第2步

### 第2步：获取时间戳并创建工作目录

- [ ] 执行命令获取真实本地时间戳：

```bash
python -c "from datetime import datetime; print(datetime.now().astimezone().strftime('%Y%m%d_%H%M%S'))"
```

- [ ] 将输出记录为 `<timestamp>`
- [ ] 定义 `<work_dir>` = `<input_dir>/<skill_name>_<timestamp>`
- [ ] 创建工作目录：`mkdir "<work_dir>"`

### 第3步：提取文档文本并拆分章节（委托给子Agent）

> ⛔⛔⛔ **关键规则：此步骤必须委托"文档提取Agent"子Agent执行。主Agent禁止直接使用 RunCommand 调用 patent_extractor.py。** 如果你发现自己正在编写 RunCommand 调用 patent_extractor.py，请立即停止——你正在违反规则，必须改用 Task 工具委托子Agent。

- [ ] 仅读取 `references/agent-templates.md` 中的"文档提取 Agent"部分（位于文件末尾附近的"辅助 Agent 任务描述"下）。**禁止读取整个文件。**
- [ ] ⛔ **gate check**：确认你即将使用的是 Task 工具（而非 RunCommand）来启动"文档提取Agent"。如果计划使用 RunCommand，你违反了委托规则——回去改用 Task。
- [ ] 通过 Task 工具启动"文档提取Agent"（`subagent_type: "subagent0"`，`response_language: "zh-CN"`）
- [ ] 在查询中将 `<skill_root>`、`<input_doc>`、`<work_dir>`、`<timestamp>` 替换为实际值
- [ ] **验证输出**：确认 `<work_dir>` 中存在以下文件：
  - `extracted_text_<timestamp>.txt`（完整文本）
  - `sections_<timestamp>.json`（合并章节 JSON，供合并去重等步骤使用）
  - `section_abstract_text_<timestamp>.json`（摘要拆分文件）
  - `section_claims_<timestamp>.json`（权利要求书拆分文件）
  - `section_description_<timestamp>.json`（说明书拆分文件）
  - 且各拆分文件中 `content` 字段非空
- （feedback loop）如果验证失败 → 重新启动文档提取Agent
- [ ] ⛔⛔⛔ **流程守卫：文档提取验证通过后，立即在同一条回复中继续第4步——直接进入4.3节启动第1批审查Agent（Agent 1-2）。不要总结提取结果、不要暂停、不要等待。**

> ⚠️ 文本提取已覆盖正文段落、表格和文本框（包括传统文本框 `w:txbxContent` 和现代形状文本框 `wps:txbx`）。脚注、尾注中的文字仍无法提取，如果文档包含这些元素，应提醒用户可能存在未检查到的区域。

> 💡 **章节拆分设计**：将 `sections_<timestamp>.json` 拆分为独立的章节文件，每个审查Agent只能读取其分配章节对应的文件。这从物理层面防止Agent越权审查非分配章节，比规则约束更可靠。`sections_<timestamp>.json` 仍保留供合并去重等后续步骤使用。

### 第4步：多Agent并行审查（核心步骤）

这是核心步骤。12条审查规则分配到12个独立Agent，每个Agent仅加载1条审查规则，分批并行执行。

每个子Agent从 `references/agent-templates.md` 中自行读取其配置（通用规范 + Agent专属任务描述），并独立执行审查。主Agent只需提供简短的标准化提示词。

#### 4.1 审查任务分组

| Agent | 任务名称 | 规则文件 | 所需章节文件 | 输出文件 |
|:------|:---------|:----------|:-----------------|:-----------|
| Agent 1 | 摘要简单审查 | `11-摘要-简单检查1.txt` | `section_abstract_text_<timestamp>.json` | `reviews_agent1_<timestamp>.json` |
| Agent 2 | 摘要复杂审查 | `12-摘要-复杂检查1.txt` | `section_abstract_text_<timestamp>.json` | `reviews_agent2_<timestamp>.json` |
| Agent 3 | 权利要求书格式检查1 | `31-权利要求书-简单审查1-格式检查1.txt` | `section_claims_<timestamp>.json` | `reviews_agent3_<timestamp>.json` |
| Agent 4 | 权利要求书格式检查2 | `31-权利要求书-简单审查2-格式检查2.txt` | `section_claims_<timestamp>.json` | `reviews_agent4_<timestamp>.json` |
| Agent 5 | 权利要求书所述的引用基础 | `31-权利要求书-简单审查3-所述的引用基础.txt` | `section_claims_<timestamp>.json` | `reviews_agent5_<timestamp>.json` |
| Agent 6 | 权利要求书引用与主题 | `31-权利要求书-简单审查4-引用与主题.txt` | `section_claims_<timestamp>.json` | `reviews_agent6_<timestamp>.json` |
| Agent 7 | 权利要求书复杂审查1 | `32-权利要求书-复杂审查1.txt` | `section_claims_<timestamp>.json` | `reviews_agent7_<timestamp>.json` |
| Agent 8 | 权利要求书单一性审查 | `32-权利要求书-复杂审查2-单一性.txt` | `section_claims_<timestamp>.json` | `reviews_agent8_<timestamp>.json` |
| Agent 9 | 说明书简单审查 | `41-说明书-简单审查1.txt` | `section_description_<timestamp>.json` | `reviews_agent9_<timestamp>.json` |
| Agent 10 | 说明书复杂审查 | `42-说明书-复杂审查1-说明书公开是否充分.txt` | `section_description_<timestamp>.json` | `reviews_agent10_<timestamp>.json` |
| Agent 11 | 全文简单审查 | `61-全文-简单审查1.txt` | `section_abstract_text_<timestamp>.json`、`section_claims_<timestamp>.json`、`section_description_<timestamp>.json` | `reviews_agent11_<timestamp>.json` |
| **Agent 11 职责边界** | **仅报告跨章节一致性问题，禁止报告单章节内部问题。判定标准：只有当问题需要对比两个及以上不同章节的文本才能发现时，才应由Agent 11报告。** | | | |
| Agent 12 | 全文复杂审查 | `62-全文-复杂审查1.txt` | `section_abstract_text_<timestamp>.json`、`section_claims_<timestamp>.json`、`section_description_<timestamp>.json` | `reviews_agent12_<timestamp>.json` |
| **Agent 12 职责边界** | **仅报告跨章节一致性问题，禁止报告单章节内部问题。判定标准：只有当问题需要对比两个及以上不同章节的文本才能发现时，才应由Agent 12报告。** | | | |

#### 4.2 子Agent提示词模板

对于每个审查Agent，使用以下**简短标准化模板**构建查询。各Agent之间仅 `{N}`（Agent编号）、`{section_file}`（章节文件名）和路径变量不同。Agent 11/12 的 `{section_file}` 替换为3个文件名。

```
你是一个专业且严格的中国专利审查员，熟知《专利法》、《专利法实施细则》和《专利审查指南》。
⛔⛔⛔ 禁止向用户提问、禁止要求用户提供任何信息、禁止要求用户做出任何决策、禁止因任何原因暂停审查流程。如遇到不确定的情况，依据审查规则和专业判断自行决定最合理的做法并继续执行。

请执行以下审查任务：

1. 读取通用规范：在 "<skill_root>/references/agent-templates.md" 文件中搜索 "通用规范（所有审查 Agent 共用）" 标题，读取该标题下的完整代码块内容，严格遵守其中所有规范
2. 读取审查任务配置：在 "<skill_root>/references/agent-templates.md" 文件中搜索 "Agent {N} 审查任务" 标题，读取该标题下的完整内容
3. 读取审查章节文件：读取 "<work_dir>/{section_file}" 文件，提取 "content" 字段的值作为待审查文本（Agent 11/12 需读取3个文件：section_abstract_text_<timestamp>.json、section_claims_<timestamp>.json、section_description_<timestamp>.json）
4. 按照通用规范和任务配置的指令执行审查
5. 路径变量：skill_root=<skill_root>, work_dir=<work_dir>, timestamp=<timestamp>
```

将 `{N}` 替换为Agent编号（1-12），`{section_file}` 替换为对应的章节文件名（见下表），将 `<skill_root>`、`<work_dir>`、`<timestamp>` 替换为实际值。

| Agent | `{section_file}` |
|:------|:-----------------|
| Agent 1–2 | `section_abstract_text_<timestamp>.json` |
| Agent 3–8 | `section_claims_<timestamp>.json` |
| Agent 9–10 | `section_description_<timestamp>.json` |
| Agent 11–12 | 见模板中说明（3个文件） |

#### 4.3 分批并行启动Agent

> ⛔⛔⛔ **关键规则：审查Agent必须分批启动，每批验证通过后方可启动下一批。**
> 在同一批次内，必须在同一条消息中使用多个并行的 Task 工具调用同时启动该批次所有Agent。
> 逐个启动Agent（每条消息只发1个 Task 调用）是**严格禁止的**（sequential 启动）。

---

**第1批**（Agent 1–2，摘要审查）：

- [ ] 使用上述模板构建 Agent 1-2 的查询（各查询之间仅 `{N}` 不同——将模板复制2次并更改Agent编号）
- [ ] ⛔ **gate check**：数一下你的 Task 工具调用数量，必须是2个。如果少于2个，你违反了并行启动规则——回去补齐！
- [ ] 在**同一条消息**中通过 Task 工具启动全部2个Agent（2个并行 Task 调用）：
  ```
  Task 1: description="Agent 1 摘要简单审查", query=<N=1的查询>, subagent_type="subagent0", response_language="zh-CN"
  Task 2: description="Agent 2 摘要复杂审查", query=<N=2的查询>, subagent_type="subagent0", response_language="zh-CN"
  ```
- [ ] 等待全部2个Agent完成
- [ ] **验证第1批**：读取每个输出 JSON，确认其为有效的 JSON 数组且 `context` 字段非空
- （feedback loop）如果任何Agent验证失败 → 重新启动该Agent
- [ ] ⛔⛔⛔ **流程守卫：第1批验证通过后，立即在同一条回复中启动第2批。不要总结第1批结果、不要暂停、不要等待。直接发出第2批的4个并行Task调用。**

---

**第2批**（Agent 3–6，权利要求书简单审查）：

- [ ] 使用上述模板构建 Agent 3-6 的查询
- [ ] ⛔ **gate check**：数一下你的 Task 工具调用数量，必须是4个。如果少于4个，你违反了并行启动规则——回去补齐！
- [ ] 在**同一条消息**中通过 Task 工具启动全部4个Agent（4个并行 Task 调用）：
  ```
  Task 3: description="Agent 3 权利要求书格式检查1", query=<N=3的查询>, subagent_type="subagent0", response_language="zh-CN"
  Task 4: description="Agent 4 权利要求书格式检查2", query=<N=4的查询>, subagent_type="subagent0", response_language="zh-CN"
  Task 5: description="Agent 5 权利要求书所述的引用基础", query=<N=5的查询>, subagent_type="subagent0", response_language="zh-CN"
  Task 6: description="Agent 6 权利要求书引用与主题", query=<N=6的查询>, subagent_type="subagent0", response_language="zh-CN"
  ```
- [ ] 等待全部4个Agent完成
- [ ] **验证第2批**：读取每个输出 JSON，确认其为有效的 JSON 数组且 `context` 字段非空
- （feedback loop）如果任何Agent验证失败 → 重新启动该Agent
- [ ] ⛔⛔⛔ **流程守卫：第2批验证通过后，立即在同一条回复中启动第3批。不要总结、不要暂停。直接发出第3批的2个并行Task调用。**

---

**第3批**（Agent 7–8，权利要求书复杂审查）：

- [ ] 使用上述模板构建 Agent 7-8 的查询
- [ ] ⛔ **gate check**：数一下你的 Task 工具调用数量，必须是2个。如果少于2个，你违反了并行启动规则——回去补齐！
- [ ] 在**同一条消息**中通过 Task 工具启动全部2个Agent（2个并行 Task 调用）：
  ```
  Task 7: description="Agent 7 权利要求书复杂审查1", query=<N=7的查询>, subagent_type="subagent0", response_language="zh-CN"
  Task 8: description="Agent 8 权利要求书单一性审查", query=<N=8的查询>, subagent_type="subagent0", response_language="zh-CN"
  ```
- [ ] 等待全部2个Agent完成
- [ ] **验证第3批**：与第1批相同的验证方式
- （feedback loop）如果任何Agent验证失败 → 重新启动该Agent
- [ ] ⛔⛔⛔ **流程守卫：第3批验证通过后，立即在同一条回复中启动第4批。不要总结、不要暂停。直接发出第4批的2个并行Task调用。**

---

**第4批**（Agent 9–10，说明书审查）：

- [ ] 使用上述模板构建 Agent 9-10 的查询
- [ ] ⛔ **gate check**：数一下你的 Task 工具调用数量，必须是2个。如果少于2个，你违反了并行启动规则——回去补齐！
- [ ] 在**同一条消息**中通过 Task 工具启动全部2个Agent（2个并行 Task 调用）：
  ```
  Task 9: description="Agent 9 说明书简单审查", query=<N=9的查询>, subagent_type="subagent0", response_language="zh-CN"
  Task 10: description="Agent 10 说明书复杂审查", query=<N=10的查询>, subagent_type="subagent0", response_language="zh-CN"
  ```
- [ ] 等待全部2个Agent完成
- [ ] **验证第4批**：与第1批相同的验证方式
- [ ] **额外验证 Agent 9/10 是否越权**：读取 Agent 9 和 Agent 10 的输出 JSON，检查是否有跨章节一致性问题（如发明名称与摘要主题对比、权利要求书是否得到说明书支持等）。如发现越权条目，将其 action_type 改为 comment 或删除（此类问题由 Agent 11/12 负责）
- （feedback loop）如果任何Agent验证失败 → 重新启动该Agent
- [ ] ⛔⛔⛔ **流程守卫：第4批验证通过后，立即在同一条回复中启动第5批。不要总结、不要暂停。直接发出第5批的2个并行Task调用。**

---

**第5批**（Agent 11–12，全文跨章节审查）：

- [ ] 使用上述模板构建 Agent 11-12 的查询
- [ ] ⛔ **gate check**：数一下你的 Task 工具调用数量，必须是2个。如果少于2个，你违反了并行启动规则——回去补齐！
- [ ] 在**同一条消息**中通过 Task 工具启动全部2个Agent（2个并行 Task 调用）：
  ```
  Task 11: description="Agent 11 全文简单审查", query=<N=11的查询>, subagent_type="subagent0", response_language="zh-CN"
  Task 12: description="Agent 12 全文复杂审查", query=<N=12的查询>, subagent_type="subagent0", response_language="zh-CN"
  ```
- [ ] 等待全部2个Agent完成
- [ ] **验证第5批**：与第1批相同的验证方式
- （feedback loop）如果任何Agent验证失败 → 重新启动该Agent
- [ ] ⛔⛔⛔ **流程守卫：第5批验证通过后（所有12个审查Agent完成），立即在同一条回复中继续第5步（合并去重）。不要总结审查结果、不要暂停、不要等待。直接读取合并去重Agent的模板并启动。**

---

**各Agent的 Task 工具参数：**
- `subagent_type`：`"subagent0"`（备选：如 subagent0 不可用则使用 `"compliance-checker"`）
- `response_language`：`"zh-CN"`
- `description`：例如 `"Agent 1 摘要审查"`
- `query`：使用4.2节模板构建的简短标准化提示词，其中 `{N}` 和路径变量已替换为实际值

### 第5步：合并去重与修订冲突解决（委托给子Agent）

- [ ] 仅读取 `references/agent-templates.md` 中的"合并去重 Agent"部分。**禁止读取整个文件。**
- [ ] 通过 Task 工具启动"合并去重Agent"
- [ ] 将 `<skill_root>`、`<work_dir>`、`<timestamp>` 替换为实际值
- [ ] **验证输出**：确认 `reviews_<timestamp>.json` 存在且为有效的 JSON 数组
- （feedback loop）如果验证失败 → 重新启动合并去重Agent
- [ ] ⛔⛔⛔ **流程守卫：合并去重验证通过后，立即在同一条回复中继续第6步。不要总结去重结果、不要暂停、不要等待。直接读取报告生成和批注添加Agent的模板并并行启动。**

> ⚠️ **修订冲突问题**：review_adder.py 顺序处理审查意见，当一条 replace/delete 修改了文本后，后续条目如果引用了被修改的文本区域，将无法匹配而跳过。合并去重Agent必须在去重后额外执行修订冲突检测：找出同一 context 内有多条 replace/delete 意见的情况，将后续冲突条目转为 comment 类型或调整其 context/old_text，确保每段文本最多只有一条 replace/delete 操作。

### 第6步：并行生成审查报告与添加批注修订（委托给子Agent）

报告生成和批注添加互相独立（均仅依赖第5步的合并去重结果），必须并行启动。

- [ ] 仅读取 `references/agent-templates.md` 中的"报告生成 Agent"和"批注添加 Agent"两个部分。**禁止读取整个文件。**
- [ ] ⛔ **gate check**：必须在同一条消息中使用2个并行的 Task 工具调用分别启动"报告生成Agent"和"批注添加Agent"。逐个启动是严格禁止的。
- [ ] 通过 Task 工具并行启动两个Agent：
  ```
  Task A: description="报告生成", query=<报告生成Agent的任务描述，将 <skill_root>、<work_dir>、<timestamp>、<input_dir>、<input_stem> 替换为实际值>, subagent_type="subagent0", response_language="zh-CN"
  Task B: description="批注添加", query=<批注添加Agent的任务描述，将 <skill_root>、<input_doc>、<input_dir>、<input_stem>、<work_dir>、<timestamp> 替换为实际值>, subagent_type="subagent0", response_language="zh-CN"
  ```
- [ ] 等待两个Agent完成
- [ ] **验证报告生成输出**：确认 `<input_dir>/<input_stem>_review_report_<timestamp>.md` 存在且非空
- [ ] **验证报告数量一致性（强制）**：读取报告文件，统计报告中列出的问题总数；再读取 `<work_dir>/reviews_<timestamp>.json`，统计 JSON 数组长度。两者必须完全一致。如不一致，重新启动报告生成Agent（最多2次）
- （feedback loop）如果报告验证失败 → 重新启动报告生成Agent
- [ ] **验证批注添加输出**：确认 `<input_dir>/<input_stem>_ReviewOut_<timestamp>.docx` 存在
- [ ] 如果跳过数量 > 0，检查原因（可能是 AI 审查误判导致 `context` 或 `old_text` 不存在）
- [ ] **跳过条目修复流程**（当跳过数量 > 0 时执行）：
  1. 读取 `<work_dir>/reviews_<timestamp>.json`，找到被跳过的条目
  2. 分析跳过原因（常见原因按出现频率排序）：
     - **修订冲突**（最常见）：同一 context 内有多条 replace/delete 意见，前一条修改了文本后，后一条在原文中找不到匹配。修复方法：将冲突的后续条目转为 comment 类型（设置 action_type="comment"，old_text=null，new_text=null，添加 highlight_text 指向问题关键词），这样不会修改文本但仍会添加批注标记问题
     - **context 不是 verbatim copy**：context 中多了或少了标点符号（如多了句号"。"）、多了或少了空格、字符被替换（如"粗导料管"被写成"细导料管"、"侧剖"被写成"侧坡"）。修复方法：从 extracted_text_<timestamp>.txt 中搜索并复制原文
     - **context 包含 \n 换行符**：context 跨了多个段落。修复方法：将跨段落的 context 拆分为多条审查意见，每条只包含一个段落内的文本
     - **new_text 包含 \n 换行符**：new_text 中包含换行符，review_adder.py 无法在 docx 中插入新段落。修复方法：将 new_text 中的 \n 后的内容删除，改为 comment 类型在批注中说明需要添加的内容；或将追加内容拆分为独立的 comment 类型审查意见
     - **old_text 不是 context 的子串**：old_text 与 context 不匹配。修复方法：确保 old_text 是从 context 中精确截取的子串
     - **old_text/new_text 逻辑错误**：suggestion 说的修改方向与 old_text→new_text 的实际替换不一致（如issue说"删除'所述'"但 old_text 包含了远超"所述"的文本）。修复方法：缩小 old_text 到只包含需要修改的最小文本片段
     - **context 包含 HTML 标签**：如 `<br>`、`<p>` 等。修复方法：删除标签，使用原文纯文本
     - **occurrence 指定错误**：同一文本在文档中出现的次数与 occurrence 值不匹配。修复方法：修正 occurrence 值或删除该字段
  3. 修复被跳过的条目：按上述方法修复，优先将修订冲突条目转为 comment 类型
  4. 将修复后的审查意见重新保存到 `<work_dir>/reviews_<timestamp>.json`
  5. 重新运行批注添加脚本（使用修复后的 JSON）
  6. 最多重试 2 次，如果仍无法修复则跳过该条目并在最终报告中注明
- （feedback loop）如果批注输出文件缺失 → 重新启动批注添加Agent
- [ ] ⛔⛔⛔ **流程守卫：第6步两个Agent均验证通过后，立即在同一条回复中继续第7步——直接运行 verify.py 验证脚本。不要总结报告结果、不要暂停、不要等待。**

> 报告文件放置在输入文件所在目录中，而非 `<work_dir>` 中。

> ⛔ 必须使用 `review_adder.py`。禁止编写自定义批注脚本——会导致严重内容丢失。

> **精准定位能力**：`review_adder.py` 已内建精准匹配能力，可在 docx 文件中精准且最小化地定位待修改或待批注的文本：
> - **跨 run 精准定位**：当目标文本跨越多个 `w:r` 元素时，能精确计算字符偏移量，只标记目标文本范围，不影响 run 中的其他文本
> - **批注精准定位**：纯批注（comment）模式下，批注范围只覆盖 `highlight_text`（如提供）或 `context` 文本本身，而非整个 run；如果目标文本只占 run 的一部分，会自动拆分 run 使批注范围最小化
> - **修订批注精准定位**：replace/delete 模式下，批注范围仅覆盖修订节点（`w:del`/`w:ins`），不覆盖修订前后的无关文本
> - **highlight_text 字段**：comment 类型时可通过 `highlight_text` 字段指定批注应精确覆盖的最小文本范围（必须是 `context` 的子串），避免批注覆盖整句或整段
> - **occurrence 字段**：当同一 context 在文档中出现多次时，可通过 `occurrence` 字段（从 1 开始的整数）指定标注第几次出现；不指定时默认标注第一次出现
> - **空白字符容错**：搜索文本时先尝试精确匹配，失败后自动尝试忽略空白字符差异的模糊匹配

> 输出 docx 文件放置在输入文件所在目录中，而非 `<work_dir>` 中。

### 第7步：内容完整性验证（强制）

- [ ] 运行验证脚本：

```bash
python "<skill_root>/scripts/verify.py" "<input_doc>" "<input_dir>/<input_stem>_ReviewOut_<timestamp>.docx" "<work_dir>"
```

- [ ] **检查验证结果**：
  - 项目1（段落数量）— **mandatory check**：必须通过。如果失败 → 排查并修复，重新执行第6步和第7步
  - 项目3（文件结构）— **mandatory check**：必须通过。如果失败 → 排查并修复
  - 项目2（模拟接受修订）— **仅供参考**：这是信息性检查。段落数量差异是 verify.py 模拟逻辑中的已知误报。如果项目1通过，此项不算失败
- （feedback loop）如果 mandatory check 失败 → 排查原因，修复审查意见 JSON，重新执行第6步和第7步（最多重试5次）

> ⛔ 未通过 mandatory check 的文档禁止交付给用户。

## 最终输出

向用户报告审查结果：

> `<model_name>` 替换为当前会话所使用的大模型名称（如 GLM-5.1、Claude 3.5 Sonnet 等）。

```
📋 专利申请文件审查完成（多Agent分批并行协作模式）

审查文件：xxx.docx
发现问题：N 处
审查模式：12 个 Agent 分批并行审查 + 4 个辅助 Agent
使用模型：<model_name>（所有Agent共用同一模型）

【审查摘要】
- 摘要-简单审查：X1 处问题（Agent 1）
- 摘要-复杂审查：X2 处问题（Agent 2）
- 权利要求书-格式检查1：Y1 处问题（Agent 3）
- 权利要求书-格式检查2：Y2 处问题（Agent 4）
- 权利要求书-所述的引用基础：Y3 处问题（Agent 5）
- 权利要求书-引用与主题：Y4 处问题（Agent 6）
- 权利要求书-复杂审查1：Y5 处问题（Agent 7）
- 权利要求书-单一性审查：Y6 处问题（Agent 8）
- 说明书-简单审查：W1 处问题（Agent 9）
- 说明书-复杂审查：W2 处问题（Agent 10）
- 全文-简单审查：V1 处问题（Agent 11）
- 全文-复杂审查：V2 处问题（Agent 12）

已生成审查版文档：xxx_ReviewOut_<timestamp>.docx
- 明确了具体操作的修改建议已在修订模式下执行替换或删除，可在 Word 中逐一接受/拒绝
- 无法明确具体操作的修改建议以批注标记，可在 Word 中查看

审查意见汇总报告：<input_dir>/<input_stem>_review_report_<timestamp>.md
中间文件保存在：<work_dir>
```

## 参考文件

详细内容已按照渐进式披露原则拆分到参考文件中：

- **`references/agent-templates.md`** — 包含通用规范（所有审查Agent共用）、12个自包含的Agent任务描述部分（每个包含配置和执行步骤），以及4个辅助Agent的任务描述。审查子Agent独立从此文件中读取自己的配置；主Agent使用4.2节的简短标准化提示词模板。
- **`references/prohibitions-and-rules.md`** — 详细的禁止事项、JSON 格式规范、文件命名规则、工作目录管理规则、脚本调用规则、验证规则和修订追踪规范。

## 技术架构

```
checking-patdocx-cn-multi-agents/
├── SKILL.md
├── references/
│   ├── agent-templates.md
│   └── prohibitions-and-rules.md
├── scripts/
│   ├── patent_extractor.py
│   ├── review_adder.py
│   ├── merge_reviews.py
│   ├── verify.py
│   ├── doc_converter.py              # .doc 转 .docx（pywin32 COM 自动化）
│   ├── document.py
│   ├── utilities.py
│   └── templates/
├── ooxml/
│   └── scripts/
│       ├── unpack.py
│       ├── pack.py
│       └── validation/
├── 审查规则/
│   ├── 11-摘要-简单检查1.txt
│   ├── 12-摘要-复杂检查1.txt
│   ├── 31-权利要求书-简单审查1-格式检查1.txt
│   ├── 31-权利要求书-简单审查2-格式检查2.txt
│   ├── 31-权利要求书-简单审查3-所述的引用基础.txt
│   ├── 31-权利要求书-简单审查4-引用与主题.txt
│   ├── 32-权利要求书-复杂审查1.txt
│   ├── 32-权利要求书-复杂审查2-单一性.txt
│   ├── 41-说明书-简单审查1.txt
│   ├── 42-说明书-复杂审查1-说明书公开是否充分.txt
│   ├── 61-全文-简单审查1.txt
│   ├── 62-全文-复杂审查1.txt
│   └── 71-整理汇总输出.txt
└── requirements.txt
```

## 依赖项

- Python 3.10+
- defusedxml
- lxml
- python-docx
- pywin32（用于 .doc 转 .docx，仅 Windows + Microsoft Word 环境需要）

