import sys
import json
import argparse
from pathlib import Path
from glob import glob

sys.path.insert(0, str(Path(__file__).parent.parent))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work-dir", required=True)
    parser.add_argument("--timestamp", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--pattern", default="reviews_agent*_*.json")
    args = parser.parse_args()

    work_dir = Path(args.work_dir)
    output_path = Path(args.output)
    pattern = args.pattern

    search_pattern = str(work_dir / pattern)
    matched_files = sorted(glob(search_pattern))

    files_found = len(matched_files)
    files_merged = 0
    files_skipped = 0
    merged_reviews = []

    for file_path_str in matched_files:
        file_path = Path(file_path_str)
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                merged_reviews.extend(data)
                files_merged += 1
            else:
                print(f"Warning: {file_path.name} does not contain a JSON array, skipping")
                files_skipped += 1
        except FileNotFoundError:
            print(f"Warning: {file_path.name} not found, skipping")
            files_skipped += 1
        except json.JSONDecodeError:
            print(f"Warning: {file_path.name} could not be parsed as JSON, skipping")
            files_skipped += 1
        except Exception as e:
            print(f"Warning: {file_path.name} could not be read ({e}), skipping")
            files_skipped += 1

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(merged_reviews, f, ensure_ascii=False, indent=2)

    total_reviews = len(merged_reviews)
    print(f"Files found: {files_found}")
    print(f"Files merged: {files_merged}")
    print(f"Files skipped: {files_skipped}")
    print(f"Total reviews: {total_reviews}")


if __name__ == "__main__":
    main()
