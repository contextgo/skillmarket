# Orchestration Rules

## Core principle
A full major-theme plan should coordinate three functions in the right order:
- source grounding
- audience entry
- package architecture

## Default order
Use this when the topic starts broad, abstract, or concept-heavy:
1. practice-origin-topic-designer
2. audience-barrier-reframer
3. multi-format-amplification-planner

## Alternative paths
- **Case already exists, but framing is weak**: reframing first, then source validation, then package design
- **Framing exists, rollout is the main need**: package planning first, then stress-test grounding and audience entry
- **Wording is the main problem**: reframing first, then optional light package design
- **Topic is weak everywhere**: grounding first and keep the package lean

## Planning state diagnosis
Classify the case as:
- theme-only
- angle exists but remains abstract
- case exists but audience entry is weak
- topic and framing exist, package logic missing
- full-package ambition exceeds topic maturity

## Conflict resolution priorities
- keep strong grounding and redesign entry
- preserve distinctiveness while improving accessibility
- strengthen the anchor before expanding fragments
- reduce scope if resources are thin
