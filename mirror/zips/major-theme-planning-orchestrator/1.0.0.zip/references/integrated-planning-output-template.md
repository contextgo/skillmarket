# Integrated Planning Output Template

### Topic Definition
Restate the topic in plain editorial language.

### Planning State Diagnosis
State the current planning state and why.

### Recommended Planning Spine
Give:
- theme restatement
- planning objective
- anchor case or source point
- reframed central question
- core evidence chain
- primary angle

### Source Grounding Assessment
Summarize source point quality, evolution path, present-day echo, reportability, and a grounding verdict.

### Audience Reframing Assessment
Summarize dominant barriers, best entry point, explanation bridge, wording strategy, and a reframing verdict.

### Amplification Architecture
Summarize anchor product, supporting products, platform role map, sequencing logic, recirculation paths, and an amplification verdict.

### Resource and Coordination Needs
List the minimum conditions required to make the plan work.

### Key Risks and Trade-offs
Identify the main risks and the trade-offs being accepted.

### Final Recommendation
Choose one clear recommendation and explain why.
