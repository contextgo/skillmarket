# Store Metadata

    ## Listing identity
    - **Display name:** Major Theme Planning Orchestrator
    - **Slug:** `major-theme-planning-orchestrator`
    - **Category:** editorial-planning
    - **Short description:** Coordinate full major-theme editorial planning end to end.
    - **One-line positioning:** Integrate source grounding, audience entry, and package design into one coherent planning memo for international communication.

    ## Suggested tags
    - `editorial-planning`
- `major-theme`
- `orchestration`
- `international-communication`
- `integrated-planning`
- `planning-agent`

    ## Best-fit queries
    - Create a full planning package for an overseas-facing report on long-term planning.
- We have only a broad theme. Orchestrate the full planning workflow.
- Diagnose this topic and tell me whether it needs grounding, reframing, or package design first.

    ## Core use cases
    - Build a full planning package from a broad theme
- Decide which planning lens to run first
- Integrate angle, framing, package, and risk into one memo

    ## README intro block
    > Major Theme Planning Orchestrator helps editorial teams and planning agents solve one specific planning problem with repeatable structure, output patterns, and reference materials. It is best used as one module inside a larger editorial planning system.

    ## Publish notes
    - Keep this skill listed separately rather than bundling it with all six skills.
    - Use a concise changelog line such as `Initial public release` or `Improved trigger wording and examples`.
    - Keep the public listing focused on the problem it solves, not the full six-skill architecture.
    - Recommended audience: editorial strategists, newsroom innovation teams, international communication planners, and multi-agent OpenClaw builders.
