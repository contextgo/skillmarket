---
name: major-theme-planning-orchestrator
description: orchestrate major-theme editorial planning for international communication by coordinating practice-origin topic design, audience-barrier reframing, and multi-format amplification planning. use when chatgpt needs to turn a broad major theme, policy topic, or institution-centered idea into a complete planning package with source-grounded angle, audience-enterable framing, and multi-format distribution architecture.
---

# Major Theme Planning Orchestrator

Coordinate a full editorial planning workflow for major-theme, policy, governance, or institution-centered topics in international communication.

This skill is a planning orchestrator. It does not replace specialized planning skills. It decides which planning logic to invoke first, what each one should contribute, and how to merge the results into one coherent planning package.

## Core task
Produce a complete planning package that answers:
- what is the strongest source-grounded topic angle?
- what audience barriers must be solved?
- what is the clearest reframed entry point?
- what content package should carry the topic across formats and platforms?
- what are the key execution risks and next steps?

## Workflow

### 1. Classify the planning task
Identify topic type and planning state: no angle yet, angle exists but is abstract, case exists but relevance is unclear, framing exists but audience entry is weak, package design is missing, or full package is needed from zero.

### 2. Decide orchestration order
Default order:
1. practice-origin-topic-designer
2. audience-barrier-reframer
3. multi-format-amplification-planner

Change order only when the topic already has a strong case or when rollout is clearly the main need.

### 3. Generate the planning spine
Before package design, identify:
- theme restatement
- planning objective
- anchor case or source point
- audience-enterable central question
- core evidence chain
- one primary angle

### 4. Run the three planning lenses
Keep these lenses distinct, then merge them:
- source grounding
- audience entry
- package architecture

### 5. Resolve tensions across outputs
If outputs conflict, prioritize:
- source grounding over empty accessibility
- comprehension over abstract correctness
- coherence over platform quantity
- one strong anchor over many weak assets

### 6. Output one integrated planning package
Use `references/integrated-planning-output-template.md` and follow sequencing rules in `references/orchestration-rules.md`.

## Boundary
This skill is for full major-theme editorial planning and coordinated integration. It is not for final article writing, detailed production scheduling, or post-publication analytics.
