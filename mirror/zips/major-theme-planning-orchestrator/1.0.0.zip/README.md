# Major Theme Planning Orchestrator

Coordinate grounding, reframing, and amplification into one plan.

## Included files
- SKILL.md
- agents/openai.yaml
- references/
- MANIFEST.yaml
- CHANGELOG.md
- _meta.json

## Install notes
This bundle is packaged as a standard ZIP with a top-level `major-theme-planning-orchestrator/` directory so it can be imported by skill installers that expect one skill per archive.
