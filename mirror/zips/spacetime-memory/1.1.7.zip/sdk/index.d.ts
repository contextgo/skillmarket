import { DbConnectionBuilder as __DbConnectionBuilder, DbConnectionImpl as __DbConnectionImpl, SubscriptionBuilderImpl as __SubscriptionBuilderImpl, type ErrorContextInterface as __ErrorContextInterface, type EventContextInterface as __EventContextInterface, type QueryBuilder as __QueryBuilder, type ReducerEventContextInterface as __ReducerEventContextInterface, type SubscriptionEventContextInterface as __SubscriptionEventContextInterface, type SubscriptionHandleImpl as __SubscriptionHandleImpl } from "spacetimedb";
/** Type-only namespace exports for generated type groups. */
/** The schema information for all tables in this module. This is defined the same was as the tables would have been defined in the server. */
declare const tablesSchema: any;
/** The remote SpacetimeDB module schema, both runtime and type information. */
declare const REMOTE_MODULE: __RemoteModule<any, any, any>;
/** The tables available in this remote SpacetimeDB module. Each table reference doubles as a query builder. */
export declare const tables: __QueryBuilder<typeof tablesSchema.schemaType>;
/** The reducers available in this remote SpacetimeDB module. */
export declare const reducers: any;
/** The context type returned in callbacks for all possible events. */
export type EventContext = __EventContextInterface<typeof REMOTE_MODULE>;
/** The context type returned in callbacks for reducer events. */
export type ReducerEventContext = __ReducerEventContextInterface<typeof REMOTE_MODULE>;
/** The context type returned in callbacks for subscription events. */
export type SubscriptionEventContext = __SubscriptionEventContextInterface<typeof REMOTE_MODULE>;
/** The context type returned in callbacks for error events. */
export type ErrorContext = __ErrorContextInterface<typeof REMOTE_MODULE>;
/** The subscription handle type to manage active subscriptions created from a {@link SubscriptionBuilder}. */
export type SubscriptionHandle = __SubscriptionHandleImpl<typeof REMOTE_MODULE>;
/** Builder class to configure a new subscription to the remote SpacetimeDB instance. */
export declare class SubscriptionBuilder extends __SubscriptionBuilderImpl<typeof REMOTE_MODULE> {
}
/** Builder class to configure a new database connection to the remote SpacetimeDB instance. */
export declare class DbConnectionBuilder extends __DbConnectionBuilder<DbConnection> {
}
/** The typed database connection to manage connections to the remote SpacetimeDB instance. This class has type information specific to the generated module. */
export declare class DbConnection extends __DbConnectionImpl<typeof REMOTE_MODULE> {
    /** Creates a new {@link DbConnectionBuilder} to configure and connect to the remote SpacetimeDB instance. */
    static builder: () => DbConnectionBuilder;
    /** Creates a new {@link SubscriptionBuilder} to configure a subscription to the remote SpacetimeDB instance. */
    subscriptionBuilder: () => SubscriptionBuilder;
}
export {};
//# sourceMappingURL=index.d.ts.map