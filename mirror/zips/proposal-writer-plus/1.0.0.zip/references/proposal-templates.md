# Proposal Templates

Use these templates as defaults. Adapt to the project, but keep the logic chain intact.

## Template A: Standard full proposal with two phases

### 1. Executive Summary
- Summarize `[客户]`'s current context and urgency
- State project objective and intended value
- Highlight the overall two-phase logic: diagnose/design, then implement/realize value

### 2. Project Background / Context
- Briefly describe `[客户]`
- Explain the trigger for the project
- State the desired business and management outcomes
- Note why execution support is likely required

### 3. Key Challenges / Problem Definition
- Challenge 1: strategic or business issue
- Challenge 2: operating model or execution bottleneck
- Challenge 3: organizational, governance, or capability gap
- Optional challenge 4-5 if complexity warrants

### 4. Our Approach / Methodology
#### Phase 1: diagnosis and solution design
- current-state review
- issue tree or root-cause analysis
- benchmark and opportunity assessment
- target solution design
- roadmap and governance design

#### Phase 2: implementation support and value realization
- pmo and governance cadence
- initiative planning and tracking
- change management and communications
- topic-specific implementation support
- pilot, scale-up, and value capture tracking

### 5. Workplan, Timeline & Deliverables
Suggested structure:
- Stage 1: project mobilization and hypothesis refinement
- Stage 2: diagnosis and deep dive analysis
- Stage 3: solution design and roadmap definition
- Stage 4: implementation preparation and governance setup
- Stage 5: implementation support and issue resolution
- Stage 6: consolidation, handover, and value review

For each stage, specify:
- duration
- key activities
- milestone
- deliverables
- client touchpoints
- parallel streams if relevant

### 6. Team Structure
- Steering committee
- Project management team
- Execution or workstream teams
- Escalation and review cadence

### 7. Commercials / Fees
- optional, only when requested or contextually necessary

## Template B: Diagnosis-first proposal with optional phase 2

Use when the user clearly emphasizes assessment, blueprinting, or strategy design, but execution support may remain optional.

### 1. Executive Summary
Frame phase 1 as the core scope and phase 2 as an optional extension.

### 2. Project Background / Context
Clarify why a fact base and strategic design are needed first.

### 3. Key Challenges / Problem Definition
Focus on uncertainty, fragmented facts, unclear priorities, and lack of a coherent target state.

### 4. Our Approach / Methodology
#### Phase 1: core scope
- diagnose
- prioritize
- design
- roadmap

#### Optional Phase 2
- pmo
- change enablement
- functional design and rollout support

### 5. Workplan, Timeline & Deliverables
Show a core phase 1 plan and a separately labeled optional phase 2 plan.

### 6. Team Structure
Keep the same three-layer logic, but show lighter execution-team intensity in phase 1.

## Template C: Rewrite mode structure

When the user provides a draft, first check whether these links exist:
- background -> challenge
- challenge -> approach
- approach -> workplan
- workplan -> deliverables
- governance -> implementation

If any links are missing, rebuild the section rather than lightly editing it.

## Example snippets

### Example 1: Executive Summary opening
`[客户]`当前正面临业务增长、组织协同与执行落地多重挑战。为支持管理层形成一致的问题判断，并系统推进解决方案设计与落地实施，本项目拟分两个阶段展开：第一阶段聚焦诊断与方案设计，明确关键问题、优先事项及目标路径；第二阶段聚焦实施支持与价值落地，通过项目管理机制、跨部门协同及重点专题支持，推动关键举措有效实施并逐步固化为组织能力。

### Example 2: Two-phase approach sentence
我们建议以“诊断设计 + 实施落地”两阶段推进本项目：第一阶段形成对关键问题的系统判断与解决方案蓝图，第二阶段围绕治理机制、重点举措推进及专题支撑，协助 `[客户]` 将设计成果转化为可执行、可追踪、可落地的实际成效。
