# Module Guidelines

Use this file to determine what each section must contain, how to write it, and what to avoid.

## 1. Executive Summary

### Must include
- concise summary of `[客户]` context
- the project objective
- the most important issues to solve
- what the team will do
- expected value or result
- if relevant, the implementation-support dimension

### How to write it
- keep it tight and front-page ready
- use 1 to 3 short paragraphs or 3 to 5 bullets
- emphasize why now, why this project, and what value
- keep process detail minimal

### Common mistakes
- writing a generic introduction that could fit any client
- overloading with methodology detail
- failing to mention execution support when the scope clearly includes implementation

## 2. Project Background / Context

### Must include
- brief description of `[客户]`
- immediate trigger for the project
- external and internal context relevant to the project
- target business, management, and decision-support outcomes
- implementation objective if phase 2 is needed

### How to write it
- add context, do not merely repeat the user input
- supplement with careful inference when needed
- when a real client is named, use only relevant public facts and de-identify in the final output
- focus on project-relevant facts, not company history

### Common mistakes
- turning the section into a company encyclopedia entry
- repeating the executive summary verbatim
- including interesting but irrelevant public facts

## 3. Key Challenges / Problem Definition

### Must include
For each key challenge:
- a short title
- a concise explanation of the issue
- why it matters
- whether it is mainly diagnosis-related, implementation-related, or both

### How to write it
- derive directly from the background
- show root causes, not only symptoms
- prioritize 3 to 5 challenges
- ensure every challenge can be answered by the approach

### Common mistakes
- generic phrases like "improve management efficiency" without context
- too many overlapping challenges
- challenges that do not connect to the later workstreams

## 4. Our Approach / Methodology

### Must include
- overall project logic
- phase structure
- workstreams
- objectives, activities, and outputs for each workstream
- explanation of how the approach addresses the challenges

### Phase 1 typical content
- current-state diagnosis
- problem decomposition
- benchmark or best-practice comparison
- opportunity sizing
- target-state or solution design
- roadmap and governance design

### Phase 2 typical content
- pmo
- implementation cadence
- change management
- digital or functional-topic support
- initiative tracking
- issue resolution
- value realization
- capability transfer or mechanism embedding

### How to write it
- default to two phases unless clearly unnecessary
- make phase 2 selective and relevant
- describe workstreams using objective, activity, output logic
- show the bridge from design to implementation

### Common mistakes
- describing methods without linking them to the client problem
- stopping at strategy design when the project clearly needs rollout support
- listing every possible module without prioritizing relevance

## 5. Workplan, Timeline & Deliverables

### Must include
For each stage:
- stage objective
- duration
- key activities
- milestone
- client touchpoints
- deliverables
- parallel vs sequential logic where relevant

### How to write it
- merge workplan, timeline, and deliverables into a single integrated section
- reflect the actual delivery rhythm of a consulting project
- estimate time in weeks unless the user requests another unit
- explain what each deliverable enables for the client

### Time estimation heuristics
- light diagnosis: 3 to 5 weeks
- medium complexity design: 6 to 10 weeks
- design plus implementation: 10 to 20 weeks
- larger cross-functional execution scopes may require longer timelines

### Common mistakes
- static bullet lists with no timeline logic
- timelines that ignore workshops, alignment, and synthesis time
- deliverables named without content or decision value
- no indication of parallel workstreams when the project obviously has them

## 6. Team Structure

### Default governance layers
1. Steering Committee / SteerCo
2. Project Management Team
3. Execution Team / Workstream Teams

### 6.1 Steering Committee
#### Reference responsibilities
- support or approve critical decisions
- review, challenge, and approve key recommendations
- provide stage-gate quality assurance comments
- help the project team remove major barriers
- sponsor change and maintain project momentum

#### Writing guidance
- position as decision and oversight body
- highlight milestone reviews and directional guidance
- avoid portraying as a daily execution team

### 6.2 Project Management Team
#### Reference responsibilities
- lead overall program control and operating design
- create and manage project plans
- coordinate cross-functional collaboration
- drive execution and solution development
- coordinate deliverable creation and sign-off
- organize management workshops, site visits, and working sessions
- support change management and communications

#### Writing guidance
- emphasize integration, cadence, escalation, and stakeholder alignment
- show it as the bridge between steerco and execution teams

### 6.3 Execution Team / Workstream Teams
#### Reference responsibilities
- design detailed workstream plans
- define milestones and resource plans
- drive execution of initiatives and solution rollout
- manage cross-workstream interdependencies
- track progress and prepare status updates
- identify and solve execution issues, escalating as needed
- organize working sessions and thematic discussions

#### Writing guidance
- emphasize delivery, analysis, rollout, and feedback loops
- explain how execution teams support both design and implementation phases

### Important note
These responsibilities are reference only. Adapt them to the actual project. Do not copy them mechanically when a lighter structure is more appropriate.

## 7. Commercials / Fees

### Must include when requested
- pricing structure
- scope assumptions
- phase split or payment cadence if relevant
- disclaimers or exclusions

### Common mistakes
- quoting a fee without assumptions
- mixing pricing options without explaining scope differences
