# Style Guidelines

Adjust proposal language to the client type. If the client type is unclear, use neutral, professional language with moderate formality.

## 1. State-owned enterprise style

### Tone
- formal
- steady
- structured
- prudent
- governance oriented

### Emphasis
- strategic direction
- top-level design
- mechanism building
- organizational coordination
- phased implementation
- implementation safeguards
- long-term capability building

### Preferred wording
- 统筹推进
- 顶层设计
- 机制保障
- 协同联动
- 阶段实施
- 体系化建设
- 组织保障
- 能力提升
- 落地实施

### Avoid
- overly aggressive commercial claims
- startup-style hype
- highly casual phrasing

### Example
`本项目将围绕战略方向澄清、关键问题诊断、实施路径设计及治理机制建设分阶段推进，协助 [客户] 在确保组织协同和实施保障的前提下，有序推动重点举措落地，并逐步形成支撑长期发展的能力基础。`

## 2. Private company style

### Tone
- direct
- business oriented
- pragmatic
- concise
- action oriented

### Emphasis
- growth
- performance improvement
- speed
- management levers
- execution discipline
- value capture

### Preferred wording
- 增长机会
- 经营改善
- 效率提升
- 关键举措
- 执行落地
- 价值释放
- 业绩改善
- 推进节奏

### Avoid
- excessive formalism
- policy-heavy phrasing when not relevant
- abstract language without business impact

### Example
`本项目将聚焦 [客户] 当前最关键的增长与经营提升议题，在快速形成问题判断和优先举措的基础上，通过清晰的推进节奏、责任机制和实施支持，帮助 [客户] 将方案转化为可见的经营改善与价值释放。`

## 3. MNC style

### Tone
- structured
- professional
- restrained
- evidence oriented
- governance heavy

### Emphasis
- governance
- stage-gated delivery
- cross-functional alignment
- traceability
- capability building
- change enablement

### Preferred wording
Chinese output may retain a few common English terms naturally:
- governance
- PMO
- workstream
- milestone
- capability building
- change enablement
- stage-gate

### Avoid
- ornate rhetoric
- overly local bureaucratic phrasing unless the user wants it
- high-emotion persuasion language

### Example
`We propose a two-phase, hypothesis-driven approach for [客户], starting with fact-based diagnosis and solution design, followed by implementation support through a dedicated PMO, cross-functional workstream governance, and targeted change enablement to ensure transparent progress tracking and sustainable adoption.`

## 4. Inference rules

Infer style from clues such as:
- organization type explicitly mentioned by the user
- wording of the rfp
- ownership structure or industry norms
- governance complexity
- whether the user uses terms common in multinationals or state-owned organizations

If still unclear:
- use neutral, professional Chinese
- avoid slang or extreme stylistic markers
- keep the proposal logic strong and the wording moderately formal

## 5. Universal quality bar

Regardless of style, always keep the proposal:
- professional
- concise
- high-density
- logically linked
- results oriented
- de-identified as `[客户]`
- stronger in reasoning than in adjectives
