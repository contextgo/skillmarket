# Frameworks

Use this file to choose the most relevant consulting logic for the project. Select and combine only what the project needs.

## Growth strategy
Use when the project focuses on topline growth, new profit pools, or strategic expansion.

Common lenses:
- growth drivers by segment, channel, product, or geography
- market attractiveness and right-to-win
- portfolio prioritization
- commercial model and activation roadmap

Phase 2 options:
- growth PMO
- sales or channel rollout support
- performance tracking and governance

## Market entry
Use when the client is evaluating entry into a new market, segment, or region.

Common lenses:
- market sizing and attractiveness
- customer need and segment prioritization
- competitor and capability assessment
- entry model and phased rollout

Phase 2 options:
- launch PMO
- partner management
- pilot and scale-up support

## Operating model / organization optimization
Use when the project focuses on organization design, decision rights, governance, or role clarity.

Common lenses:
- current-state operating issues
- role and decision mapping
- governance redesign
- capability and talent implications

Phase 2 options:
- governance implementation
- change management
- role transition support

## Operational improvement
Use when the project focuses on cost, service, throughput, productivity, or end-to-end process improvement.

Common lenses:
- baseline performance diagnosis
- pain-point and root-cause mapping
- process redesign
- value sizing and prioritization

Phase 2 options:
- implementation PMO
- KPI dashboarding
- frontline change support
- value capture tracking

## Transformation
Use when the scope is enterprise-wide and cross-functional.

Common lenses:
- transformation ambition and scope
- initiative portfolio design
- sequencing and governance
- capability and culture implications

Phase 2 options:
- transformation office / PMO
- change story and communication plan
- initiative tracking
- capability building

## Digital transformation
Use when digital tools, systems, or data enablement are central to the scope.

Common lenses:
- digital maturity and bottlenecks
- use-case prioritization
- target architecture or operating implications
- roadmap and adoption requirements

Phase 2 options:
- digital PMO
- deployment support
- adoption and training
- benefit tracking

## PMI / post-merger integration
Use when the project focuses on integration, synergy capture, or combined operating model design.

Common lenses:
- integration priorities
- synergy hypothesis and validation
- target operating model
- TSA or transition planning where relevant

Phase 2 options:
- integration PMO
- cross-functional interdependency management
- synergy tracking
- communication and change support

## Functional-topic support modules for phase 2
Use selectively when implementation requires functional depth.

### Finance
- target finance processes
- management reporting and control mechanisms
- planning and performance tracking

### Tax
- transaction or model implications
- policy and compliance considerations
- implementation coordination with finance and legal stakeholders

### HR
- organization alignment
- talent and role transition
- incentive alignment
- capability building

### Supply chain
- network and process design
- planning, sourcing, and fulfillment implications
- rollout and KPI management

### Procurement
- category strategy support
- sourcing governance
- savings tracking and implementation discipline

## Selection rules
- Start from the user's problem, not from the framework list.
- Pick one dominant logic and add only a few supporting lenses.
- Use phase 2 modules only when they help convert design into execution.
- Avoid framework overload.
