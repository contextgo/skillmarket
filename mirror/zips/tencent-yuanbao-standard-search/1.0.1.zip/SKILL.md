---
name: tencent-yuanbao-standard-search
description: Search the web using TencentCloud Web Search API (WSA). Prioritize using it when you need to retrieve network information.
allowed-tools: Read,Bash
homepage: https://cloud.tencent.com/product/wsa
metadata: {"openclaw":{"emoji":"🔍︎","requires":{"bins":["python3"],"env":["TENCENTCLOUD_WSA_APIKEY"]}}}
---

# 元宝搜索标准版skill

元宝搜索标准版skill以互联网全网公开资源为基础，叠加腾讯优质内容生态，结合元宝APP联网搜索应用实践，从数据收录到智能检索召回，全链路构建AI友好搜索引擎。

针对用户对话中的关键问题（query）实时搜索互联网内容，返回最新相关的、高质量网页的内容信息，包括文章标题、摘要、url地址、发布时间、发布站点等，为大模型提供关键有效的决策信息，为用户提供更精准、更高质量的回答。

## 使用场景
通过接入元宝搜索标准版skill，为大模型拓展互联网信息实时检索能力，突破大模型知识困局，帮助大模型准确理解并快速回应用户的多样化问题。
- **信息查询**：搜索特定主题的互联网信息
- **热点追踪**：获取最新的新闻、资讯
- **知识检索**：查找百科、教程等知识类内容

## 触发场景

当用户输入包含以下意图时，应触发此技能：

- 明确要求搜索："帮我搜索..."、"查找..."、"搜索一下..."
- 需要最新信息："最新的..."、"近期的新闻..."、"2024年..."
- 关键词触发："联网搜索"、"在线查找"、"web search"

## 执行逻辑

### 1. 环境检查
在执行搜索前，检查是否已配置 API Key环境变量：TENCENTCLOUD_WSA_APIKEY

如果未配置，提醒用户按以下步骤操作：
- **[开通服务](https://console.cloud.tencent.com/wsapi/index?tab=apikey)**：登陆腾讯云联网搜索API控制台，开通标准版服务。
- **[创建服务API KEY](https://console.cloud.tencent.com/wsapi/index?tab=apikey)**：登陆腾讯云联网搜索API控制台，创建服务API KEY并保存。
- **[领取免费额度](https://console.cloud.tencent.com/wsapi/activity)**：登陆腾讯云联网搜索API活动专区页面，领取每日免费调用额度，活动限时，具体规则以页面信息为准。

安装skill后，您需要将服务API KEY以环境变量的方式配置在Open Claw中，Skill 会自动读取。
详细的配置方法可参考：`references/setup.md`

### 2. 执行搜索
** 注意：需要切换到该 skill 同目录下执行**

使用`scripts/websearch.py`执行搜索：

参数说明：
#### 输入参数说明

| 参数    | 必填 | 说明                     | 示例                                                             |
|-------| ---- |------------------------|----------------------------------------------------------------|
| query | 是   | 搜索关键词                 | `python3 scripts/websearch.py --query="搜索关键词"`                   |
| site | 否 | 用于约束搜索范围的站点,要求是严格的域名格式 | `python3 scripts/websearch.py --query="搜索关键词" --site="sogou.com"` |
| mode | 否| 0-自然检索结果(默认)，1-多模态VR结果（包括天气、金价、股价、医疗、汇率、油价、贵金属等相关信息），2-混合结果（多模态VR结果+自然检索结果)| `python3 scripts/websearch.py --query="搜索关键词" --mode=2`          |
| freshness| 否| 'day': 表示最近一天,'week': 表示最近一周,'month': 表示最近一个月,'year': 表示最近一年| `python3 scripts/websearch.py --query="搜索关键词" --freshness='year'` |

#### 场景说明
- 基于关键词搜索
```bash
python3 scripts/websearch.py --query="搜索关键词"
```

- 指定网页站点搜索
```bash
python3 scripts/websearch.py --query="搜索关键词" --site="sogou.com"
```

- 指定时间范围搜索相关信息
```bash
python3 scripts/websearch.py --query="搜索关键词" --freshness='year'
```
freshness包含以下选项:
|选项|解释|
|-----|----|
| ''| 空或者不带freshness不强调时间范围|
| day | 搜索最近一天的内容|
| week| 搜索最近一周的内容|
| month| 搜索最近一个月的内容|
| year| 搜索最近一年的内容|

- 搜索天气、金价、股价、医疗、汇率、油价、贵金属相关高时效高精度的垂类信息，混合搜索独家插件内容来源。
```bash
python3 scripts/websearch.py --query="搜索关键词" --mode=2
```

### 3.结果解析
搜索脚本会自动将结果格式化为 Markdown，包含：

- 搜索结果标题（带链接）
  - 摘要
  - 内容发布时间
  - 网站
  - 相关图片（如果有）

markdown输出格式示例：
```
## 查询词:腾讯股价, 搜索结果:2条
1. [腾讯版“小龙虾”爆火,股价涨超7%、市值重回5万亿__财经头条__新浪财经](https://cj.sina.cn/articles/view/2587691232/9a3d08e002001mr1o%3Ffroms%3Dggmp%26vt%3D4)
 - 摘要：同日,腾讯股价大涨｡截至当日收盘,报553.5港元,涨7.27%,市值重回5万亿元｡
 - 内容发布时间：2026-04-22 00:56:18
 - 网站：新浪财经
 - 相关图片：https://k.sinaimg.cn/n/sinakd20260311s/475/w909h366/20260311/e169-cee03761e128389727727e2ea2a8766c.png/w700d1q75cms.jpg
2. [港股收盘  恒指收跌1.22% 联想集团领跑蓝筹 光通信概念股逆市大涨](http://stock.10jqka.com.cn/hks/20260422/c676189781.shtml)
 - 摘要：股普遍承压,阿里(BABA)跌3.52%,腾讯(K80700)跌2.89%｡光通信板块午后涨幅扩大,长飞光纤光缆(HK6869)､剑桥科技(HK6166)均大幅上涨,得益于光模块行业景气度提升及光纤市场量价齐升;AI次新股表现亮眼,极视角(HK6636)､爱芯元智(HK0600)､澜起科技(HK6809)､智谱(HK2513)等个股均有明显上涨｡
 - 内容发布时间：2026-04-22 00:00:00
 - 网站：同花顺财经
```

## 工作流程示例

**用户输入：**
> "帮我搜索一下 腾讯股价"

**执行步骤：**

1. 识别触发词"搜索"，激活 tencent-yuanbao-standard-search 技能
2. 检查环境变量 `TENCENTCLOUD_WSA_APIKEY` 是否已设置
3. 执行搜索命令：
   ```bash
   python3 scripts/websearch.py --query="Python 3.13 新特性"
   ```
4. 获取 Markdown 格式的搜索结果
5. 将结果呈现给用户

## 错误处理
搜索出现错误时，脚本会返回以下内容：
```
## 搜索失败
原因：[提示信息]
```
根据对应的原因提示信息，可向用户提供处理建议：
- **服务不可用**：请登陆[腾讯云费用中心](https://console.cloud.tencent.com/expense/overview)检查账号是否欠费，并及时冲正。
- **服务未开通**：请登陆腾讯云[联网搜索API控制台](https://console.cloud.tencent.com/wsapi/index?tab=apikey)，开通标准版服务。
- **未授权操作**：请登陆[联网搜索API控制台](https://console.cloud.tencent.com/wsapi/index?tab=apikey)创建服务API KEY并配置到环境变量(TENCENTCLOUD_WSA_APIKEY)中。若已配置，请检查填入的变量值是否正确。