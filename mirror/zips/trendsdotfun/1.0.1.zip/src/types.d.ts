declare module "bn.js";
