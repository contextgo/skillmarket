#!/usr/bin/env python3
"""
Paper Reader - Main Entry Point
Read, analyze, and summarize academic papers with multiple tools
"""

import json
import sys
import os
import time
from typing import Optional

# Add scripts to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from api_client import (
    APP_CONFIG,
    build_attachment,
    build_paper_payload,
    parse_sse_stream,
    call_paper_api,
    stream_paper_api,
    call_search_paper_api,
    upload_public_file,
    call_audio_to_video_api,
    call_video_gen_progress_api,
)
from mindmap import markdown_to_graphviz_image
from video_assembler import assemble_video_data


def _get_workspace_dir() -> str:
    """获取 openclaw workspace 目录路径

    按优先级依次查找：
    1. 环境变量 OPENCLAW_WORKSPACE
    2. 默认路径 ~/.openclaw/workspace
    """
    workspace = os.environ.get("OPENCLAW_WORKSPACE", "")
    if workspace and os.path.isdir(workspace):
        return workspace
    return os.path.expanduser("~/.openclaw/workspace")


# ==================== 工具函数 ====================


def paper_mindmap(
    authorization: str,
    file_url: str,
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
) -> dict:
    """论文脑图 —— 调用接口获取 Markdown 层级脑图文本，生成 PNG 图片并上传到 COS"""
    payload = build_paper_payload(
        app_key="mindmap",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    result = call_paper_api(authorization, payload)

    # 如果接口调用失败，直接返回错误
    if not result.get("success", False):
        return result

    markdown_content = result.get("content", "")
    if not markdown_content:
        return result

    # 生成 PNG 脑图图片到临时目录，然后上传到 COS
    image_url = ""
    try:
        import tempfile

        # 以 PDF 文件名 + 时间戳命名
        timestamp = int(time.time())
        base_name = os.path.splitext(file_name)[0] if file_name else "paper"
        png_filename = f"mindmap_{base_name}_{timestamp}.png"

        # 生成到临时目录
        tmp_dir = tempfile.mkdtemp(prefix="paper_mindmap_")
        tmp_path = os.path.join(tmp_dir, png_filename)
        image_path = markdown_to_graphviz_image(markdown_content, output_path=tmp_path)

        # 读取图片文件内容，调用 upload_public_file 接口上传到 COS
        with open(image_path, "rb") as f:
            file_data = f.read()

        upload_result = upload_public_file(authorization, file_data, filename=png_filename)
        if upload_result.get("success"):
            image_url = upload_result["file_url"]
            result["mindmap_image_url"] = image_url
            result["mindmap_image_filename"] = png_filename
        else:
            result["mindmap_image_error"] = f"脑图图片上传失败: {upload_result.get('error', '未知错误')}"

        # 清理临时文件
        try:
            os.remove(image_path)
            os.rmdir(tmp_dir)
        except OSError:
            pass

    except Exception as e:
        # 图片生成/上传失败不影响主流程，记录错误信息
        result["mindmap_image_error"] = f"脑图图片生成或上传失败: {str(e)}"

    # 同步附上图片 URL（如上传成功）
    if image_url:
        # 只返回脑图图片，不包含 Markdown 文本内容
        result["content"] = f"## 📊 论文脑图\n\n![脑图图片]({image_url})\n\n**图片可直接点击查看或下载使用。**"
        # 纯Markdown格式图片
        result["markdown_image"] = f"![脑图图片]({image_url})"

    else:
        result["content"] = f"## 📊 论文脑图\n\n脑图图片生成失败，请重试。"

    return result


def paper_deep_read(
    authorization: str,
    file_url: str,
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
) -> dict:
    """论文精读 —— 依次调用精读分析、关键问题及回答、论文评价三个接口，合并返回综合结果"""
    results = {}
    combined_content_parts = []
    all_success = True

    # 1. 调用论文精读接口
    deep_read_payload = build_paper_payload(
        app_key="deep_read",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    deep_read_result = call_paper_api(authorization, deep_read_payload)
    results["deep_read"] = deep_read_result
    if deep_read_result.get("success", False):
        content = deep_read_result.get("content", "")
        if content:
            combined_content_parts.append(f"## 📖 论文精读\n\n{content}")
    else:
        all_success = False

    # 2. 调用关键问题及回答接口
    key_qa_payload = build_paper_payload(
        app_key="key_qa",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    key_qa_result = call_paper_api(authorization, key_qa_payload)
    results["key_qa"] = key_qa_result
    if key_qa_result.get("success", False):
        content = key_qa_result.get("content", "")
        if content:
            combined_content_parts.append(f"## ❓ 关键问题及回答\n\n{content}")
    else:
        all_success = False

    # 3. 调用论文评价接口
    evaluate_payload = build_paper_payload(
        app_key="evaluate",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    evaluate_result = call_paper_api(authorization, evaluate_payload)
    results["evaluate"] = evaluate_result
    if evaluate_result.get("success", False):
        content = evaluate_result.get("content", "")
        if content:
            combined_content_parts.append(f"## ⭐ 论文评价\n\n{content}")
    else:
        all_success = False

    # 合并结果
    combined = {
        "success": len(combined_content_parts) > 0,
        "content": "\n\n---\n\n".join(combined_content_parts) if combined_content_parts else "论文精读分析失败，未能获取到有效内容。",
        "details": results,
    }

    # 如果有任何一个接口返回了 conversation_id，取第一个
    for key in ["deep_read", "key_qa", "evaluate"]:
        cid = results.get(key, {}).get("conversation_id", "")
        if cid:
            combined["conversation_id"] = cid
            break

    return combined


def paper_summary(
    authorization: str,
    file_url: str,
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
) -> dict:
    """论文总结 —— 对论文内容进行摘要总结"""
    payload = build_paper_payload(
        app_key="summary",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    return call_paper_api(authorization, payload)


def paper_translate(
    authorization: str,
    file_url: str,
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
) -> dict:
    """论文翻译 —— 对论文全文进行翻译"""
    payload = build_paper_payload(
        app_key="translate",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    return call_paper_api(authorization, payload)


def paper_evaluate(
    authorization: str,
    file_url: str,
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
) -> dict:
    """论文评价 —— 对论文进行综合评价分析"""
    payload = build_paper_payload(
        app_key="evaluate",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    return call_paper_api(authorization, payload)


def paper_key_qa(
    authorization: str,
    file_url: str,
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
) -> dict:
    """关键问题及回答 —— 从论文中提取关键问题并给出回答"""
    payload = build_paper_payload(
        app_key="key_qa",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    return call_paper_api(authorization, payload)


def paper_chat(
    authorization: str,
    question: str,
    file_url: str = "",
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
) -> dict:
    """论文对话 —— 基于论文进行多轮对话问答"""
    payload = build_paper_payload(
        app_key="chat",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        content=question,
        conversation_id=conversation_id,
    )
    return call_paper_api(authorization, payload)


def paper_podcast(
    authorization: str,
    file_url: str,
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    doc_id: str = "",
    mode: str = "quick_insight",
    voices: Optional[list] = None,
    conversation_id: str = "",
) -> dict:
    """AI播客 —— 将文件内容转换为双人对话播客音频"""
    if voices is None:
        voices = ["zixin", "acan"]

    podcast_config = {
        "mode": mode,
        "voices": voices,
    }

    payload = build_paper_payload(
        app_key="podcast",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
        doc_id=doc_id,
        podcast_config=podcast_config,
    )
    return call_paper_api(authorization, payload, timeout=300.0)


def paper_podcast_video(
    authorization: str,
    podcast_data_path: str,
    doc_id: str = "",
    style: str = "quick_insight",
) -> dict:
    """生成翻转字幕视频 —— 基于 AI 播客数据生成翻转字幕视频

    前置条件：需要先调用 paper_podcast 生成播客，播客数据会自动保存到文件。

    Args:
        authorization: 用户鉴权 token
        podcast_data_path: 播客数据 JSON 文件路径
        doc_id: 文档 ID（可选，用于关联视频与文档）
        style: 播客风格，影响视频配色和动画

    Returns:
        dict: 包含 task_id、video_url 等信息
    """
    # 1. 读取播客数据文件
    if not podcast_data_path or not os.path.isfile(podcast_data_path):
        return {
            "success": False,
            "error": "播客数据文件不存在，请先使用 paper_podcast 生成 AI 播客",
        }

    try:
        with open(podcast_data_path, "r", encoding="utf-8") as f:
            podcast_data = json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        return {
            "success": False,
            "error": f"读取播客数据文件失败: {str(e)}",
        }

    speaker_text_list = podcast_data.get("all_speaker_text_list", [])
    audio_url = podcast_data.get("podcast_audio_url", "")
    title = podcast_data.get("podcast_title", "播客视频")
    start_text = podcast_data.get("podcast_start_text", "欢迎收听混元AI播客")

    if not speaker_text_list:
        return {
            "success": False,
            "error": "播客数据中缺少 speaker_text_list，请重新生成 AI 播客",
        }

    if not audio_url:
        return {
            "success": False,
            "error": "播客数据中缺少 audio_url，请重新生成 AI 播客",
        }

    # 2. 组装视频数据
    video_data = assemble_video_data(
        speaker_text_list=speaker_text_list,
        audio_url=audio_url,
        title=title,
        start_text=start_text,
    )

    if not video_data:
        return {
            "success": False,
            "error": "视频数据组装失败，播客数据可能不完整",
        }

    # 3. 调用视频生成接口
    if not doc_id:
        # 生成一个随机 doc_id
        import uuid
        doc_id = uuid.uuid4().hex

    submit_result = call_audio_to_video_api(
        authorization=authorization,
        doc_id=doc_id,
        audio_url=audio_url,
        title=title,
        video_data=video_data,
    )

    if not submit_result.get("success"):
        if submit_result.get("other_processing"):
            return {
                "success": False,
                "error": "当前有视频正在生成中，请等待完成后再操作",
            }
        return submit_result

    task_id = submit_result.get("task_id", "")
    if not task_id:
        return {
            "success": False,
            "error": "视频生成任务提交成功但未返回 task_id",
        }

    # 4. 轮询视频生成进度
    import time as time_mod
    max_wait = 600  # 最长等待 10 分钟
    poll_interval = 5  # 每 5 秒查询一次
    elapsed = 0

    while elapsed < max_wait:
        time_mod.sleep(poll_interval)
        elapsed += poll_interval

        progress_result = call_video_gen_progress_api(
            authorization=authorization,
            doc_id=doc_id,
            audio_url=audio_url,
            task_id=task_id,
        )

        if not progress_result.get("success"):
            return progress_result

        status = progress_result.get("status", "")
        progress = progress_result.get("progress", 0)

        if status == "completed" and progress >= 100:
            video_url = progress_result.get("video_url", "")
            return {
                "success": True,
                "task_id": task_id,
                "video_url": video_url,
                "title": title,
                "content": "",
            }
        elif status == "failed":
            error_msg = progress_result.get("error", "视频生成失败")
            return {
                "success": False,
                "task_id": task_id,
                "error": f"视频生成失败: {error_msg}",
            }
        elif status == "canceled":
            return {
                "success": False,
                "task_id": task_id,
                "error": "视频生成任务已被取消",
            }

        # 输出进度信息到 stderr（不影响 stdout 的纯文本输出）
        import sys as _sys
        _sys.stderr.write(f"[video] 视频生成中... 进度: {progress}%, 状态: {status}\n")
        _sys.stderr.flush()

    return {
        "success": False,
        "task_id": task_id,
        "error": f"视频生成超时（已等待 {max_wait} 秒），任务仍在后台运行，task_id: {task_id}",
    }


# ==================== 流式输出版本 ====================


def stream_paper_summary(
    authorization: str,
    file_url: str,
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
):
    """论文总结（流式）"""
    payload = build_paper_payload(
        app_key="summary",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    yield from stream_paper_api(authorization, payload)


def stream_paper_translate(
    authorization: str,
    file_url: str,
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
):
    """论文翻译（流式）"""
    payload = build_paper_payload(
        app_key="translate",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    yield from stream_paper_api(authorization, payload)


def stream_paper_chat(
    authorization: str,
    question: str,
    file_url: str = "",
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
):
    """论文对话（流式）"""
    payload = build_paper_payload(
        app_key="chat",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        content=question,
        conversation_id=conversation_id,
    )
    yield from stream_paper_api(authorization, payload)


def stream_paper_deep_read(
    authorization: str,
    file_url: str,
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    conversation_id: str = "",
):
    """论文精读（流式）—— 依次流式输出精读、关键问答、评价三个部分"""
    # 1. 精读分析
    yield {"type": "chunk", "content": "## 📖 论文精读\n\n", "conversation_id": ""}
    deep_read_payload = build_paper_payload(
        app_key="deep_read",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    for event in stream_paper_api(authorization, deep_read_payload):
        if event.get("type") == "error":
            yield event
            return
        if event.get("type") == "chunk":
            yield event
        # done 事件不转发，因为还有后续部分

    # 2. 关键问题及回答
    yield {"type": "chunk", "content": "\n\n---\n\n## ❓ 关键问题及回答\n\n", "conversation_id": ""}
    key_qa_payload = build_paper_payload(
        app_key="key_qa",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    for event in stream_paper_api(authorization, key_qa_payload):
        if event.get("type") == "error":
            yield event
            return
        if event.get("type") == "chunk":
            yield event

    # 3. 论文评价
    yield {"type": "chunk", "content": "\n\n---\n\n## ⭐ 论文评价\n\n", "conversation_id": ""}
    evaluate_payload = build_paper_payload(
        app_key="evaluate",
        file_url=file_url,
        file_name=file_name,
        file_type=file_type,
        file_size=file_size,
        conversation_id=conversation_id,
    )
    for event in stream_paper_api(authorization, evaluate_payload):
        if event.get("type") == "error":
            yield event
            return
        if event.get("type") == "chunk":
            yield event

    yield {"type": "done", "conversation_id": ""}


def paper_search(
    authorization: str,
    keyword: str,
    page: int = 1,
    size: int = 10,
) -> dict:
    """论文搜索 —— 根据关键词搜索论文"""
    result = call_search_paper_api(
        authorization=authorization,
        keyword=keyword,
        page=page,
        size=size,
    )

    if not result.get("success"):
        return result

    # 格式化搜索结果为可读内容
    papers = result.get("papers", [])
    total = result.get("total", 0)

    if not papers:
        result["content"] = f'未找到与 "{keyword}" 相关的论文。'
        return result

    lines = [f'## 🔍 论文搜索结果\n\n关键词：**{keyword}**　|　共找到 **{total}** 篇论文（当前显示 {len(papers)} 篇）\n']

    for i, paper in enumerate(papers, start=1):
        title = paper.get("title", "未知标题")
        authors = ", ".join(paper.get("authors", [])) or "未知"
        published = paper.get("published", "")[:10]
        categories = ", ".join(paper.get("categories", []))
        summary = paper.get("summary", "")
        pdf_url = paper.get("pdf_url", "")
        abstract_url = paper.get("abstract_url", "")

        lines.append(f"### {i}. {title}\n")
        lines.append(f"- **作者：** {authors}")
        lines.append(f"- **摘要：** {summary}")
        if categories:
            lines.append(f"- **分类：** {categories}")
        lines.append(f"- **发布日期：** {published}")
        link_parts = []
        if abstract_url:
            link_parts.append(f"[查看论文]({abstract_url})")
        if pdf_url:
            link_parts.append(f"[PDF]({pdf_url})")
        if link_parts:
            lines.append(f"- **链接：** {' | '.join(link_parts)}")
        lines.append("")

    result["content"] = "\n".join(lines)
    return result


# ==================== 命令行入口 ====================


def main():
    """CLI entry point

    Usage:
        python paper_reader_skill.py mindmap <token> <file_url> [file_name]
        python paper_reader_skill.py deep_read <token> <file_url> [file_name]
        python paper_reader_skill.py summary <token> <file_url> [file_name]
        python paper_reader_skill.py translate <token> <file_url> [file_name]
        python paper_reader_skill.py chat <token> <question> [file_url] [conversation_id]
        python paper_reader_skill.py podcast <token> <file_url> [file_name]
        python paper_reader_skill.py search <token> <keyword> [page] [size]
    """
    if len(sys.argv) < 4:
        print("Usage:")
        print("  python paper_reader_skill.py <command> <token> <file_url|question|keyword> [...]")
        print()
        print("Commands: mindmap, deep_read, summary, translate, chat, podcast, search")
        sys.exit(1)

    command = sys.argv[1]
    token = sys.argv[2]

    tool_map = {
        "mindmap": paper_mindmap,
        "deep_read": paper_deep_read,
        "summary": paper_summary,
        "translate": paper_translate,
    }

    if command in tool_map:
        file_url = sys.argv[3]
        file_name = sys.argv[4] if len(sys.argv) > 4 else "paper.pdf"
        result = tool_map[command](token, file_url, file_name)
    elif command == "chat":
        question = sys.argv[3]
        file_url = sys.argv[4] if len(sys.argv) > 4 else ""
        cid = sys.argv[5] if len(sys.argv) > 5 else ""
        result = paper_chat(token, question, file_url, conversation_id=cid)
    elif command == "podcast":
        file_url = sys.argv[3]
        file_name = sys.argv[4] if len(sys.argv) > 4 else "paper.pdf"
        result = paper_podcast(token, file_url, file_name)
    elif command == "search":
        keyword = sys.argv[3]
        page = int(sys.argv[4]) if len(sys.argv) > 4 else 1
        size = int(sys.argv[5]) if len(sys.argv) > 5 else 10
        result = paper_search(token, keyword, page=page, size=size)
    else:
        print(f"未知命令: {command}")
        sys.exit(1)

    # 输出结果
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()