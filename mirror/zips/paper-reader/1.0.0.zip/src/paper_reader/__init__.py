"""
Paper Reader - 论文阅读助手

支持论文搜索、论文脑图、精读（含关键问答和评价）、总结、翻译、论文对话、AI播客。
"""

__version__ = "1.0.0"

from .paper_reader_skill import (
    paper_mindmap,
    paper_deep_read,
    paper_summary,
    paper_translate,
    paper_chat,
    paper_podcast,
    stream_paper_summary,
    stream_paper_translate,
    stream_paper_chat,
    stream_paper_deep_read,
)

from .api_client import (
    call_paper_api,
    stream_paper_api,
    build_paper_payload,
    parse_sse_stream,
    iter_sse_stream,
    build_attachment,
    download_file,
    APP_CONFIG,
)

from .mindmap import markdown_to_graphviz_image

__all__ = [
    "paper_mindmap",
    "paper_deep_read",
    "paper_summary",
    "paper_translate",
    "paper_chat",
    "paper_podcast",
    "stream_paper_summary",
    "stream_paper_translate",
    "stream_paper_chat",
    "stream_paper_deep_read",
    "call_paper_api",
    "stream_paper_api",
    "build_paper_payload",
    "parse_sse_stream",
    "iter_sse_stream",
    "build_attachment",
    "download_file",
    "markdown_to_graphviz_image",
    "APP_CONFIG",
]
