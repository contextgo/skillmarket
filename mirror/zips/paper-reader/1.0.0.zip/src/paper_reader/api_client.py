#!/usr/bin/env python3
"""
Paper Reader - API Client Module
Handles SSE streaming communication with the backend API
"""

import json
import os
import sys
import urllib.request
import urllib.error
import urllib.parse
from typing import Optional


def _get_skill_root_dir() -> str:
    """获取 skill 根目录路径（config.json 所在目录）

    通过当前源码文件的位置向上推导：
    src/paper_reader/api_client.py -> ../../ 即为 skill 根目录
    """
    return os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))


def _load_config() -> dict:
    """从 config.json 加载配置，按优先级依次查找：
    1. 环境变量 PAPER_READER_CONFIG 指定的路径
    2. skill 根目录（通过源码位置推导，最可靠）
    3. 当前工作目录
    4. 用户 home 目录 ~/.paper_reader/config.json
    """
    search_paths = [
        os.environ.get("PAPER_READER_CONFIG", ""),
        os.path.join(_get_skill_root_dir(), "config.json"),
        os.path.join(os.getcwd(), "config.json"),
        os.path.expanduser("~/.paper_reader/config.json"),
    ]
    for path in search_paths:
        if path and os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                    sys.stderr.write(f"[paper-reader] 配置文件已加载: {path}\n")
                    sys.stderr.flush()
                    return config
            except Exception as e:
                sys.stderr.write(f"[paper-reader] 配置文件加载失败({path}): {e}\n")
                sys.stderr.flush()
                continue
    # 所有路径都找不到配置文件，输出明确的错误提示
    sys.stderr.write(
        f"[paper-reader] 警告: 未找到 config.json，已搜索路径:\n"
        + "".join(f"  - {p}\n" for p in search_paths if p)
        + "请设置环境变量 PAPER_READER_CONFIG 或将 config.json 放到 skill 根目录\n"
    )
    sys.stderr.flush()
    return {}


_CONFIG = _load_config()
_API_CONFIG = _CONFIG.get("api", {})

API_BASE_URL = _API_CONFIG.get("base_url", "")
CHAT_ENDPOINT = API_BASE_URL + _API_CONFIG.get("chat_endpoint", "")
DEFAULT_AUTHORIZATION = _API_CONFIG.get("authorization", "")
DEFAULT_TIMEOUT = _API_CONFIG.get("timeout", 180)
DEFAULT_PODCAST_TIMEOUT = _API_CONFIG.get("podcast_timeout", 300)
AUTH_URL = _API_CONFIG.get("auth_url", "")

# app_name 与 agent_tag 映射
APP_CONFIG = {
    "mindmap": {"app_name": "论文脑图", "agent_tag": "mind_map"},
    "deep_read": {"app_name": "论文精读", "agent_tag": "deep_read"},
    "summary": {"app_name": "论文总结", "agent_tag": "abstract"},
    "translate": {"app_name": "论文翻译", "agent_tag": "translate"},
    "evaluate": {"app_name": "论文评价", "agent_tag": ""},
    "key_qa": {"app_name": "关键问题及回答", "agent_tag": "key_quest_answer"},
    "chat": {"app_name": "论文对话", "agent_tag": ""},
    "podcast": {"app_name": "AI播客", "agent_tag": "podcast"},
}


def build_attachment(
    file_name: str,
    file_path: str,
    file_type: str = "pdf",
    size: str = "0",
    app_name: str = "",
    agent_tag: str = "",
    doc_id: str = "",
) -> dict:
    """构建附件对象"""
    attachment = {
        "file_name": file_name,
        "app_name": app_name,
        "show": True,
        "path": file_path,
        "file_type": file_type,
        "size": str(size),
    }
    if agent_tag:
        attachment["agent_tag"] = agent_tag
    if doc_id:
        attachment["doc_id"] = doc_id
    return attachment


def build_paper_payload(
    app_key: str,
    file_url: str = "",
    file_name: str = "paper.pdf",
    file_type: str = "pdf",
    file_size: str = "0",
    content: str = "",
    conversation_id: str = "",
    doc_id: str = "",
    podcast_config: Optional[dict] = None,
    translation_src: str = "auto",
    translation_dst: str = "auto",
) -> dict:
    """构建论文阅读请求体

    Args:
        app_key: 应用类型 key (mindmap/deep_read/summary/translate/evaluate/key_qa/chat/podcast)
        file_url: 文件URL
        file_name: 文件名
        file_type: 文件类型
        file_size: 文件大小
        content: 用户消息内容（论文对话时使用）
        conversation_id: 会话ID
        doc_id: 文件 doc_id（播客专用）
        podcast_config: 播客配置 {"mode": "...", "voices": [...]}
        translation_src: 翻译源语言，默认 "auto"（自动检测）
        translation_dst: 翻译目标语言，默认 "auto"（自动检测）

    Returns:
        请求体字典
    """
    config = APP_CONFIG.get(app_key)
    if not config:
        raise ValueError(f"未知的应用类型: {app_key}")

    app_name = config["app_name"]
    agent_tag = config["agent_tag"]

    attachments = []
    if file_url:
        attachments.append(
            build_attachment(
                file_name=file_name,
                file_path=file_url,
                file_type=file_type,
                size=file_size,
                app_name=app_name,
                agent_tag=agent_tag,
                doc_id=doc_id,
            )
        )

    payload = {
        "conversation_id": conversation_id,
        "incr_rsp": True,
        "message": {
            "content": content,
            "attachments": attachments,
        },
        "app_name": app_name,
        "app_type": "hy",
    }

    # 播客专属字段
    if app_key == "podcast" and podcast_config:
        payload["podcast"] = podcast_config

    # 翻译专属字段
    if app_key == "translate":
        payload["translation_src"] = translation_src
        payload["translation_dst"] = translation_dst

    return payload


def parse_sse_stream(response) -> dict:
    """解析 SSE 流式响应，拼接所有增量内容

    Args:
        response: urllib 响应对象

    Returns:
        dict: {"conversation_id": str, "content": str, "success": bool, "podcast_msg": dict|None,
               "all_speaker_text_list": list|None, "podcast_title": str, "podcast_audio_url": str,
               "podcast_start_text": str}
    """
    full_content = ""
    conversation_id = ""
    podcast_msg = None
    # 收集所有 speaker_text_list 条目（用于视频生成）
    all_speaker_text_list = []
    podcast_title = ""
    podcast_audio_url = ""
    podcast_start_text = ""

    for raw_line in response:
        line = raw_line.decode("utf-8", errors="replace").strip()

        if not line:
            continue

        # SSE 格式: data: {...}
        if line.startswith("data:"):
            json_str = line[5:].strip()
            if not json_str:
                continue

            try:
                data = json.loads(json_str)
            except json.JSONDecodeError:
                continue

            if data.get("code", 0) != 0:
                error_msg = data.get("msg", "未知错误")
                return {
                    "conversation_id": conversation_id,
                    "content": "",
                    "success": False,
                    "error": f"接口错误(code={data.get('code')}): {error_msg}",
                }

            inner = data.get("data", {})
            conversation_id = inner.get("conversation_id", conversation_id)

            # 检查播客消息
            content_obj = inner.get("content", {})
            if isinstance(content_obj, dict):
                if "podcast_msg" in content_obj:
                    podcast_msg = content_obj["podcast_msg"]
                    # 收集 speaker_text_list
                    stl = podcast_msg.get("speaker_text_list", [])
                    if stl:
                        all_speaker_text_list.extend(stl)
                    # 收集标题
                    if podcast_msg.get("title") and not podcast_title:
                        podcast_title = podcast_msg["title"]
                    # 收集音频 URL（最终消息中才有）
                    if podcast_msg.get("audio_url"):
                        podcast_audio_url = podcast_msg["audio_url"]
                    # 收集欢迎语
                    if podcast_msg.get("start_text"):
                        podcast_start_text = podcast_msg["start_text"]
                chunk = content_obj.get("content", "")
                if chunk:
                    full_content += chunk

            # 也检查顶层的 podcast_msg（最终消息格式不同）
            if isinstance(content_obj, dict) and not content_obj.get("role"):
                top_podcast_msg = content_obj.get("podcast_msg")
                if top_podcast_msg:
                    if top_podcast_msg.get("audio_url"):
                        podcast_audio_url = top_podcast_msg["audio_url"]
                    if top_podcast_msg.get("start_text"):
                        podcast_start_text = top_podcast_msg["start_text"]
                    if top_podcast_msg.get("title") and not podcast_title:
                        podcast_title = top_podcast_msg["title"]

            # 结束标志
            if inner.get("stop", False):
                break

    result = {
        "conversation_id": conversation_id,
        "content": full_content,
        "success": True,
    }
    if podcast_msg:
        result["podcast_msg"] = podcast_msg
    if all_speaker_text_list:
        result["all_speaker_text_list"] = all_speaker_text_list
    if podcast_title:
        result["podcast_title"] = podcast_title
    if podcast_audio_url:
        result["podcast_audio_url"] = podcast_audio_url
    if podcast_start_text:
        result["podcast_start_text"] = podcast_start_text

    return result


def iter_sse_stream(response):
    """以生成器方式逐 chunk 解析 SSE 流式响应

    Yields:
        dict: 每次 yield 一个事件字典，格式为以下之一：
            - {"type": "chunk", "content": str, "conversation_id": str}
            - {"type": "podcast_msg", "podcast_msg": dict, "conversation_id": str}
            - {"type": "error", "error": str, "conversation_id": str}
            - {"type": "done", "conversation_id": str}
    """
    conversation_id = ""

    for raw_line in response:
        line = raw_line.decode("utf-8", errors="replace").strip()

        if not line:
            continue

        if line.startswith("data:"):
            json_str = line[5:].strip()
            if not json_str:
                continue

            try:
                data = json.loads(json_str)
            except json.JSONDecodeError:
                continue

            if data.get("code", 0) != 0:
                error_msg = data.get("msg", "未知错误")
                yield {
                    "type": "error",
                    "error": f"接口错误(code={data.get('code')}): {error_msg}",
                    "conversation_id": conversation_id,
                }
                return

            inner = data.get("data", {})
            conversation_id = inner.get("conversation_id", conversation_id)

            content_obj = inner.get("content", {})
            if isinstance(content_obj, dict):
                if "podcast_msg" in content_obj:
                    yield {
                        "type": "podcast_msg",
                        "podcast_msg": content_obj["podcast_msg"],
                        "conversation_id": conversation_id,
                    }
                chunk = content_obj.get("content", "")
                if chunk:
                    yield {
                        "type": "chunk",
                        "content": chunk,
                        "conversation_id": conversation_id,
                    }

            if inner.get("stop", False):
                break

    yield {"type": "done", "conversation_id": conversation_id}


def download_file(url: str, timeout: float = 60.0) -> bytes:
    """下载文件内容，保留 URL 中的签名参数，不对 URL 进行二次编码

    Args:
        url: 文件下载 URL（可能含 COS 签名参数，如 q-sign-time、X-Cos-Signature 等）
        timeout: 超时时间（秒）

    Returns:
        文件二进制内容

    Raises:
        urllib.error.URLError: 网络错误
        urllib.error.HTTPError: HTTP 错误
    """
    # 使用 urllib.parse.urlsplit 解析 URL，再用 urlunsplit 重新拼接
    # 这样可以保留原始 URL 中已有的编码（如签名参数中的 %2F、%3D 等），不会二次编码
    parsed = urllib.parse.urlsplit(url)
    # urlunsplit 直接使用原始各部分，不会对已编码的内容再次编码
    safe_url = urllib.parse.urlunsplit(parsed)
    req = urllib.request.Request(safe_url)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def _validate_url(url: str, name: str = "URL") -> None:
    """校验 URL 是否包含有效的协议头（http:// 或 https://）

    Args:
        url: 待校验的 URL
        name: URL 名称，用于错误提示

    Raises:
        ValueError: URL 无效时抛出
    """
    if not url:
        raise ValueError(
            f"{name} 为空，请检查 config.json 中的 api.base_url 配置是否正确。"
            f"当前 API_BASE_URL='{API_BASE_URL}'"
        )
    if not url.startswith(("http://", "https://")):
        raise ValueError(
            f"{name} 缺少协议头(http/https): '{url}'，"
            f"请检查 config.json 中的 api.base_url 配置。"
            f"当前 API_BASE_URL='{API_BASE_URL}'"
        )


def _open_sse_connection(authorization: str, payload: dict, timeout: float = 180.0):
    """打开 SSE 连接，返回 urllib 响应对象

    Args:
        authorization: 用户鉴权 token
        payload: 请求体
        timeout: 超时时间（秒）

    Returns:
        urllib 响应对象

    Raises:
        ValueError: CHAT_ENDPOINT 无效时抛出
        urllib.error.HTTPError, urllib.error.URLError, Exception
    """
    _validate_url(CHAT_ENDPOINT, "CHAT_ENDPOINT")

    if not authorization:
        authorization = DEFAULT_AUTHORIZATION
    headers = {
        "Authorization": authorization,
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
    }

    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(CHAT_ENDPOINT, data=body, headers=headers, method="POST")
    return urllib.request.urlopen(req, timeout=timeout)


def _build_api_error(e) -> dict:
    """将异常转换为统一的错误结果字典"""
    if isinstance(e, urllib.error.HTTPError):
        error_body = ""
        try:
            error_body = e.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        if e.code == 401:
            if AUTH_URL:
                error_msg = f"鉴权失败，[点击获取 token]({AUTH_URL})"
            else:
                error_msg = "鉴权失败，请在 config.json 的 api.authorization 中配置有效的 token"
            return {
                "conversation_id": "",
                "content": "",
                "success": False,
                "error": error_msg,
            }
        return {
            "conversation_id": "",
            "content": "",
            "success": False,
            "error": f"HTTP {e.code}: {e.reason}. {error_body[:500]}",
        }
    elif isinstance(e, urllib.error.URLError):
        return {
            "conversation_id": "",
            "content": "",
            "success": False,
            "error": f"网络错误: {str(e.reason)}",
        }
    else:
        return {
            "conversation_id": "",
            "content": "",
            "success": False,
            "error": f"请求失败: {str(e)}",
        }


def call_paper_api(authorization: str, payload: dict, timeout: float = 180.0) -> dict:
    """调用论文阅读接口（非流式，等待完整响应后返回）

    Args:
        authorization: 用户鉴权 token，为空时使用 config.json 中的默认值
        payload: 请求体
        timeout: 超时时间（秒）

    Returns:
        解析后的结果
    """
    try:
        response = _open_sse_connection(authorization, payload, timeout)
        return parse_sse_stream(response)
    except Exception as e:
        return _build_api_error(e)


def stream_paper_api(authorization: str, payload: dict, timeout: float = 180.0):
    """调用论文阅读接口（流式，逐 chunk yield）

    Args:
        authorization: 用户鉴权 token，为空时使用 config.json 中的默认值
        payload: 请求体
        timeout: 超时时间（秒）

    Yields:
        dict: 每次 yield 一个事件字典（chunk / podcast_msg / error / done）
    """
    try:
        response = _open_sse_connection(authorization, payload, timeout)
        yield from iter_sse_stream(response)
    except Exception as e:
        err = _build_api_error(e)
        yield {"type": "error", "error": err.get("error", "未知错误"), "conversation_id": ""}


# 上传公开文件接口地址
UPLOAD_PUBLIC_FILE_ENDPOINT = API_BASE_URL + "/trpc/aiwriter/v1/upload_public_file"

# 论文搜索接口地址
SEARCH_PAPER_ENDPOINT = API_BASE_URL + _API_CONFIG.get("search_paper_endpoint", "/trpc/aiwriter/v1/search_paper")

# 播客视频生成接口地址
AUDIO_TO_VIDEO_ENDPOINT = API_BASE_URL + "/trpc/aiwriter/v1/podcast/audio_to_video"

# 播客视频生成进度查询接口地址
VIDEO_GEN_PROGRESS_ENDPOINT = API_BASE_URL + "/trpc/aiwriter/v1/podcast/video_gen_progress"


def call_search_paper_api(
    authorization: str,
    keyword: str,
    page: int = 1,
    size: int = 10,
    timeout: float = 60.0,
) -> dict:
    """调用论文搜索接口

    Args:
        authorization: 用户鉴权 token，为空时使用 config.json 中的默认值
        keyword: 搜索关键词
        page: 页码，默认 1
        size: 每页数量，默认 10
        timeout: 超时时间（秒）

    Returns:
        dict: {"success": bool, "total": int, "keyword": str, "papers": list, "error": str}
    """
    _validate_url(SEARCH_PAPER_ENDPOINT, "SEARCH_PAPER_ENDPOINT")

    if not authorization:
        authorization = DEFAULT_AUTHORIZATION

    headers = {
        "Authorization": authorization,
        "Content-Type": "application/json;charset=UTF-8",
        "Accept": "application/json",
    }

    payload = {
        "page": page,
        "size": size,
        "keyword": keyword,
    }

    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        SEARCH_PAPER_ENDPOINT, data=body, headers=headers, method="POST"
    )

    try:
        response = urllib.request.urlopen(req, timeout=timeout)
        resp_data = json.loads(response.read().decode("utf-8"))

        if resp_data.get("code", -1) != 0:
            return {
                "success": False,
                "total": 0,
                "keyword": keyword,
                "papers": [],
                "error": resp_data.get("msg", "未知错误"),
            }

        return {
            "success": True,
            "total": resp_data.get("total", 0),
            "keyword": resp_data.get("keyword", keyword),
            "papers": resp_data.get("papers", []),
            "request_id": resp_data.get("request_id", ""),
            "error": "",
        }
    except urllib.error.HTTPError as e:
        error_body = ""
        try:
            error_body = e.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        if e.code == 401:
            if AUTH_URL:
                error_msg = f"鉴权失败，[点击获取 token]({AUTH_URL})"
            else:
                error_msg = "鉴权失败，请在 config.json 的 api.authorization 中配置有效的 token"
            return {
                "success": False,
                "total": 0,
                "keyword": keyword,
                "papers": [],
                "error": error_msg,
            }
        return {
            "success": False,
            "total": 0,
            "keyword": keyword,
            "papers": [],
            "error": f"HTTP {e.code}: {e.reason}. {error_body[:500]}",
        }
    except urllib.error.URLError as e:
        return {
            "success": False,
            "total": 0,
            "keyword": keyword,
            "papers": [],
            "error": f"网络错误: {str(e.reason)}",
        }
    except Exception as e:
        return {
            "success": False,
            "total": 0,
            "keyword": keyword,
            "papers": [],
            "error": f"请求失败: {str(e)}",
        }


def upload_public_file(authorization: str, file_data: bytes, filename: str = "",
                       timeout: float = 60.0) -> dict:
    """调用 upload_public_file 接口，将文件上传到公开 COS 桶

    Args:
        authorization: 用户鉴权 token，为空时使用 config.json 中的默认值
        file_data: 文件二进制内容
        filename: 文件名（如 "mindmap_2510.20255v1_1712678400.png"）
        timeout: 超时时间（秒）

    Returns:
        dict: {"success": bool, "file_url": str, "error": str}
    """
    import base64 as b64

    _validate_url(UPLOAD_PUBLIC_FILE_ENDPOINT, "UPLOAD_PUBLIC_FILE_ENDPOINT")

    if not authorization:
        authorization = DEFAULT_AUTHORIZATION

    # 将文件内容 base64 编码
    encoded_data = b64.b64encode(file_data).decode("utf-8")

    payload = {
        "data": encoded_data,
        "is_base64": True,
        "filename": filename,
    }

    headers = {
        "Authorization": authorization,
        "Content-Type": "application/json",
    }

    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        UPLOAD_PUBLIC_FILE_ENDPOINT, data=body, headers=headers, method="POST"
    )

    try:
        response = urllib.request.urlopen(req, timeout=timeout)
        resp_data = json.loads(response.read().decode("utf-8"))
        file_url = resp_data.get("file_url", "")
        if not file_url:
            return {"success": False, "file_url": "", "error": "接口返回的 file_url 为空"}
        return {"success": True, "file_url": file_url, "error": ""}
    except urllib.error.HTTPError as e:
        error_body = ""
        try:
            error_body = e.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        return {"success": False, "file_url": "", "error": f"HTTP {e.code}: {e.reason}. {error_body[:500]}"}
    except urllib.error.URLError as e:
        return {"success": False, "file_url": "", "error": f"网络错误: {str(e.reason)}"}
    except Exception as e:
        return {"success": False, "file_url": "", "error": f"上传失败: {str(e)}"}


def call_audio_to_video_api(
    authorization: str,
    doc_id: str,
    audio_url: str,
    title: str,
    video_data: dict,
    timeout: float = 600.0,
) -> dict:
    """调用播客视频生成接口

    Args:
        authorization: 用户鉴权 token
        doc_id: 文档 ID
        audio_url: 播客音频 URL
        title: 视频标题
        video_data: assembleVideoData 生成的视频数据
        timeout: 超时时间（秒）

    Returns:
        dict: {"success": bool, "task_id": str, "video_id": int, "status": str, "error": str}
    """
    if not authorization:
        authorization = DEFAULT_AUTHORIZATION

    config = {
        "width": video_data.get("width", 1920),
        "height": video_data.get("height", 1080),
        "duration": video_data.get("duration", 0),
        "audioUrl": audio_url,
    }

    data_payload = {
        "width": video_data.get("width", 1920),
        "height": video_data.get("height", 1080),
        "duration": video_data.get("duration", 0),
        "speed": 150,
        "backgroundColor": video_data.get("backgroundColor", "#1A1A2E"),
        "x": video_data.get("x", 600),
        "y": video_data.get("y", 600),
        "audioUrl": audio_url,
        "captions": video_data.get("captions", []),
    }

    payload = {
        "doc_id": doc_id,
        "audio_url": audio_url,
        "title": title,
        "config": config,
        "data": json.dumps(data_payload, ensure_ascii=False),
    }

    headers = {
        "Authorization": authorization,
        "Content-Type": "application/json;charset=UTF-8",
        "Accept": "application/json",
        "global-timeout": "600",
    }

    _validate_url(AUDIO_TO_VIDEO_ENDPOINT, "AUDIO_TO_VIDEO_ENDPOINT")

    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        AUDIO_TO_VIDEO_ENDPOINT, data=body, headers=headers, method="POST"
    )

    try:
        response = urllib.request.urlopen(req, timeout=timeout)
        resp_data = json.loads(response.read().decode("utf-8"))

        if resp_data.get("code", -1) != 0:
            return {
                "success": False,
                "task_id": "",
                "video_id": 0,
                "status": "",
                "other_processing": resp_data.get("other_processing", False),
                "error": resp_data.get("msg", "未知错误"),
            }

        return {
            "success": True,
            "task_id": resp_data.get("task_id", ""),
            "video_id": resp_data.get("video_id", 0),
            "status": resp_data.get("status", ""),
            "other_processing": resp_data.get("other_processing", False),
            "error": "",
        }
    except urllib.error.HTTPError as e:
        error_body = ""
        try:
            error_body = e.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        if e.code == 401:
            if AUTH_URL:
                error_msg = f"鉴权失败，[点击获取 token]({AUTH_URL})"
            else:
                error_msg = "鉴权失败，请在 config.json 的 api.authorization 中配置有效的 token"
            return {"success": False, "task_id": "", "video_id": 0, "status": "", "error": error_msg}
        return {"success": False, "task_id": "", "video_id": 0, "status": "", "error": f"HTTP {e.code}: {e.reason}. {error_body[:500]}"}
    except urllib.error.URLError as e:
        return {"success": False, "task_id": "", "video_id": 0, "status": "", "error": f"网络错误: {str(e.reason)}"}
    except Exception as e:
        return {"success": False, "task_id": "", "video_id": 0, "status": "", "error": f"请求失败: {str(e)}"}


def call_video_gen_progress_api(
    authorization: str,
    doc_id: str,
    audio_url: str,
    task_id: str,
    timeout: float = 60.0,
) -> dict:
    """查询播客视频生成进度

    Args:
        authorization: 用户鉴权 token
        doc_id: 文档 ID
        audio_url: 播客音频 URL
        task_id: 视频生成任务 ID
        timeout: 超时时间（秒）

    Returns:
        dict: {"success": bool, "status": str, "progress": int, "video_url": str, "error": str}
    """
    if not authorization:
        authorization = DEFAULT_AUTHORIZATION

    payload = {
        "doc_id": doc_id,
        "audio_url": audio_url,
        "task_id": task_id,
    }

    headers = {
        "Authorization": authorization,
        "Content-Type": "application/json;charset=UTF-8",
        "Accept": "application/json",
        "global-timeout": "600",
    }

    _validate_url(VIDEO_GEN_PROGRESS_ENDPOINT, "VIDEO_GEN_PROGRESS_ENDPOINT")

    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        VIDEO_GEN_PROGRESS_ENDPOINT, data=body, headers=headers, method="POST"
    )

    try:
        response = urllib.request.urlopen(req, timeout=timeout)
        resp_data = json.loads(response.read().decode("utf-8"))

        if resp_data.get("code", -1) != 0:
            return {
                "success": False,
                "status": "",
                "progress": 0,
                "video_url": "",
                "task_id": task_id,
                "error": resp_data.get("msg", "未知错误"),
            }

        return {
            "success": True,
            "status": resp_data.get("status", ""),
            "progress": resp_data.get("progress", 0),
            "video_url": resp_data.get("video_url", ""),
            "task_id": resp_data.get("task_id", task_id),
            "error": resp_data.get("error_msg", ""),
        }
    except urllib.error.HTTPError as e:
        error_body = ""
        try:
            error_body = e.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        if e.code == 401:
            if AUTH_URL:
                error_msg = f"鉴权失败，[点击获取 token]({AUTH_URL})"
            else:
                error_msg = "鉴权失败，请在 config.json 的 api.authorization 中配置有效的 token"
            return {"success": False, "status": "", "progress": 0, "video_url": "", "task_id": task_id, "error": error_msg}
        return {"success": False, "status": "", "progress": 0, "video_url": "", "task_id": task_id, "error": f"HTTP {e.code}: {e.reason}. {error_body[:500]}"}
    except urllib.error.URLError as e:
        return {"success": False, "status": "", "progress": 0, "video_url": "", "task_id": task_id, "error": f"网络错误: {str(e.reason)}"}
    except Exception as e:
        return {"success": False, "status": "", "progress": 0, "video_url": "", "task_id": task_id, "error": f"请求失败: {str(e)}"}