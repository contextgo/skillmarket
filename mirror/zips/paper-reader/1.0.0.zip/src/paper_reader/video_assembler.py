#!/usr/bin/env python3
"""
视频数据组装模块 —— 将播客 speaker_text_list 转换为翻转字幕视频的入参数据

移植自前端 videoTemplate.ts 的 assembleVideoData 逻辑。
"""

import math
import random
import re
from typing import List, Optional


# ==================== 颜色与尺寸配置 ====================

# 视频尺寸（横屏）
VIDEO_WIDTH = 1920
VIDEO_HEIGHT = 1080
VIDEO_X = 600
VIDEO_Y = 600

# 背景色
BACKGROUND_COLOR = "#1A1A2E"

# 字体
FONT_FAMILY = "PingFang SC, Microsoft YaHei, Arial, sans-serif"

# 字幕颜色：60% 白色，40% 绿色
COLOR_WHITE = "#FFFFFF"
COLOR_GREEN = "#93EEB2"


# ==================== 文本拆分 ====================


def _smart_word_split(text: str, max_length: int = 10) -> List[str]:
    """智能分词函数 —— 保持词语完整性并过滤标点符号

    Args:
        text: 原始文本
        max_length: 每个词的最大长度

    Returns:
        分词后的列表
    """
    if not text:
        return []

    # 标点符号正则
    punctuation_re = re.compile(
        r'[。！？，；：、""""""\'\'\'!?,;:—·…（）\[\]【】《》〈〉\(\)]'
    )
    # 词汇边界
    word_boundary_re = re.compile(r'[\s，。！？；：、""\'\'（）【】《》〈〉]')
    letter_re = re.compile(r'[a-zA-Z]')

    words = []
    current_word = ""

    for i, char in enumerate(text):
        current_word += char

        # 检查是否到达词汇边界
        next_char = text[i + 1] if i + 1 < len(text) else None
        is_at_boundary = (
            next_char is None
            or bool(word_boundary_re.match(next_char))
        )

        # 英文边界
        is_english_boundary = (
            bool(letter_re.match(char))
            and next_char is not None
            and not bool(letter_re.match(next_char))
        )

        if is_at_boundary or is_english_boundary:
            if current_word.strip():
                clean_word = punctuation_re.sub("", current_word).strip()
                if clean_word:
                    # 超长词拆分
                    if len(clean_word) > max_length:
                        remaining = clean_word
                        while len(remaining) > max_length:
                            break_point = max_length
                            # 如果断点处是字母，继续到非字母
                            if break_point < len(remaining) and letter_re.match(remaining[break_point]):
                                while break_point < len(remaining) and letter_re.match(remaining[break_point]):
                                    break_point += 1
                            words.append(remaining[:break_point])
                            remaining = remaining[break_point:]
                        if remaining:
                            words.append(remaining)
                    else:
                        words.append(clean_word)
                current_word = ""

    # 处理最后一个词
    if current_word.strip():
        clean_word = punctuation_re.sub("", current_word).strip()
        if clean_word:
            if len(clean_word) > max_length:
                remaining = clean_word
                while len(remaining) > max_length:
                    break_point = max_length
                    if break_point < len(remaining) and letter_re.match(remaining[break_point]):
                        while break_point < len(remaining) and letter_re.match(remaining[break_point]):
                            break_point += 1
                    words.append(remaining[:break_point])
                    remaining = remaining[break_point:]
                if remaining:
                    words.append(remaining)
            else:
                words.append(clean_word)

    return words


def split_text_with_timing(
    text: str, total_duration: float, max_length: int = 9
) -> List[dict]:
    """将文本拆分为带时间分配的片段

    Args:
        text: 原始文本
        total_duration: 总时长（毫秒）
        max_length: 每行最大字符数

    Returns:
        [{"text": str, "duration": float}, ...]
    """
    if not text:
        return []

    words = _smart_word_split(text, max_length)
    if not words:
        return []

    temp_chunks = []
    current_chunk = ""
    i = 0

    while i < len(words):
        word = words[i]
        potential_chunk = f"{current_chunk}{word}" if current_chunk else word

        # 每行字符限制（随机 3 到 max_length）
        max_chars_per_line = random.randint(3, max_length)

        if len(potential_chunk) > max_chars_per_line and current_chunk:
            temp_chunks.append({
                "text": current_chunk.strip(),
                "char_count": len(current_chunk.strip()),
            })
            current_chunk = word
        else:
            current_chunk = potential_chunk

        i += 1

        # 最后一个词或达到最大长度
        if i == len(words) or len(current_chunk) >= max_length:
            if current_chunk.strip():
                temp_chunks.append({
                    "text": current_chunk.strip(),
                    "char_count": len(current_chunk.strip()),
                })
                current_chunk = ""

    # 处理剩余
    if current_chunk.strip():
        temp_chunks.append({
            "text": current_chunk.strip(),
            "char_count": len(current_chunk.strip()),
        })

    # 按字符数比例分配时长
    total_char_count = sum(c["char_count"] for c in temp_chunks)
    if total_char_count == 0:
        return []

    return [
        {
            "text": item["text"],
            "duration": max(total_duration * item["char_count"] / total_char_count, 100),
        }
        for item in temp_chunks
    ]


# ==================== 视频模板生成 ====================


def _gen_template(caption_data: List[dict]) -> dict:
    """根据字幕数据生成视频模板（含动画、旋转等参数）

    Args:
        caption_data: [{"start": int, "end": int, "sentence": str}, ...]

    Returns:
        视频配置字典
    """
    cumulative_no_rotation = 0
    data_length = len(caption_data)
    right_rotation = False
    need_clear = False

    captions = []
    for index, item in enumerate(caption_data):
        is_last_message = (data_length == index + 1)

        # 颜色：60% 白色，40% 绿色
        fill = COLOR_WHITE if random.random() < 0.6 else COLOR_GREEN

        text_num = len(item["sentence"])

        # 缩放
        scale = 0.8 + random.random() * 0.7
        # 字号
        font_size = 100

        # 旋转
        rotation = None
        container_rotate = None

        if need_clear:
            need_clear = False
            rotation = {"angle": -math.pi / 2}
        elif (index % 2 == 0 and random.random() < 0.5) or cumulative_no_rotation >= 8:
            rotation = {"angle": -math.pi / 2}
            cumulative_no_rotation = 0
            right_rotation = False
        elif index % 3 == 0 and random.random() < 0.7:
            container_rotate = {"angle": math.pi / 2, "speed": 200}
            cumulative_no_rotation += 1
            right_rotation = True
        elif index % 4 == 0 and random.random() < 0.7:
            rotation = {"angle": math.pi / 2}
            cumulative_no_rotation = 8
            need_clear = True
        else:
            cumulative_no_rotation += 1

        # 短文本放大
        if text_num == 1:
            scale = 1.4
        elif text_num == 2:
            scale = 1.3
        elif text_num == 3:
            scale = 1.2

        # 避免旋转时文本重叠
        if cumulative_no_rotation >= 8 or cumulative_no_rotation == 0 or right_rotation:
            scale = 1
            font_size = min(font_size, 80)

        scale = min(scale, 1.4)

        animation_speed = 400 if (item["end"] - item["start"]) > 400 else 0

        # 随机动画（Random 模式）
        if not is_last_message:
            animation = {
                "scale": random.random() < 0.4,
                "rotation": random.random() < 0.2,
                "shake": random.random() < 0.2,
                "fromLeft": random.random() < 0.2,
                "verticalSwing": random.random() < 0.2,
                "fromTop": random.random() < 0.4,
            }
        else:
            animation = {
                "scale": False,
                "rotation": False,
                "shake": False,
                "fromLeft": False,
                "verticalSwing": False,
                "fromTop": False,
            }

        caption = {
            "text": item["sentence"],
            "start": item["start"],
            "end": item["end"],
            "style": {
                "fill": fill,
                "fontSize": font_size,
                "fontFamily": FONT_FAMILY,
                "animation": animation,
                "animationSpeed": animation_speed,
            },
            "zoom": {"scale": scale},
        }

        if rotation is not None:
            caption["rotation"] = rotation
        if container_rotate is not None:
            caption["containerRotate"] = container_rotate

        captions.append(caption)

    return {
        "width": VIDEO_WIDTH,
        "height": VIDEO_HEIGHT,
        "x": VIDEO_X,
        "y": VIDEO_Y,
        "captions": captions,
        "backgroundColor": BACKGROUND_COLOR,
    }


# ==================== 主函数 ====================


def assemble_video_data(
    speaker_text_list: List[dict],
    audio_url: str,
    title: str = "",
    start_text: str = "",
) -> Optional[dict]:
    """组装生成视频的数据

    将播客的 speaker_text_list 转换为 /trpc/aiwriter/v1/podcast/audio_to_video 接口所需的入参。

    Args:
        speaker_text_list: 播客返回的发言人文本列表，每项包含 {"speaker": str, "text": str, "time": [start, end]}
        audio_url: 播客音频 URL
        title: 视频标题
        start_text: 欢迎语文本

    Returns:
        视频数据字典，可直接作为 call_audio_to_video_api 的 video_data 参数；
        失败时返回 None
    """
    if not speaker_text_list:
        return None

    items = list(speaker_text_list)

    # 处理欢迎语：在列表开头插入
    welcome_text = (start_text or "欢迎收听混元AI播客").strip()
    if welcome_text and items:
        first_time = items[0].get("time", [0])
        welcome_end = first_time[0] - 2 if isinstance(first_time, list) and first_time else 0
        welcome_end = max(welcome_end, 0)
        items.insert(0, {
            "speaker": "",
            "text": welcome_text,
            "time": [0, welcome_end],
        })

    # 计算总时长（毫秒）
    last_item = items[-1]
    duration = 0
    if last_item.get("time") and isinstance(last_item["time"], list) and last_item["time"]:
        duration = math.ceil(last_item["time"][-1]) * 1000
    duration += 6000  # 欢迎语额外时间

    # 将播客数据转换为字幕数据
    caption_data = []
    for item in items:
        original_text = item.get("text", "")
        if not original_text:
            continue

        time_arr = item.get("time", [])
        start_time = 0
        end_time = 0

        if isinstance(time_arr, list) and len(time_arr) >= 2:
            start_time = time_arr[0] * 1000  # 转毫秒
            end_time = time_arr[1] * 1000
        elif isinstance(time_arr, list) and len(time_arr) == 1:
            start_time = time_arr[0] * 1000
            end_time = start_time + max(len(original_text) * 300, 500)

        total_duration = end_time - start_time
        text_chunks = split_text_with_timing(original_text, total_duration, 9)
        if not text_chunks:
            continue

        cumulative_time = start_time
        for chunk in text_chunks:
            chunk_start = cumulative_time
            chunk_end = chunk_start + chunk["duration"]
            caption_data.append({
                "start": round(chunk_start),
                "end": round(chunk_end),
                "sentence": chunk["text"],
            })
            cumulative_time = chunk_end

    if not caption_data:
        return None

    # 生成视频模板
    result = _gen_template(caption_data)
    result["duration"] = duration

    return result
