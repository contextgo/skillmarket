#!/usr/bin/env python3
"""
Paper Reader - Mindmap Module
纯 Python 实现 markmap 风格的思维导图，使用 SVG 构建 + cairosvg 转 PNG。
视觉效果对齐 markmap.vue 组件（颜色、字体、圆角矩形、贝塞尔曲线连线）。
无需浏览器或 Node.js 依赖。
"""

import os
import re
import sys
import logging
import time
import tempfile
import unicodedata
from xml.sax.saxutils import escape as xml_escape

_logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# markmap.vue 配色方案（对齐 colorList 中 8 种颜色的 -20/-40/-50 色阶）
# ---------------------------------------------------------------------------
# 根节点使用 brand-50
_ROOT_BG = "#0052D9"
_ROOT_FG = "#FFFFFF"

# 二级分支颜色循环（fill 用 -20 浅色，连线/文字用 -40 深色）
_BRANCH_COLORS = [
    {"fill": "#BBD3FB", "line": "#4787F0", "text": "#0D47A1"},  # brand
    {"fill": "#B9E5A4", "line": "#4CAF50", "text": "#1B5E20"},  # success
    {"fill": "#FDDEB1", "line": "#F9A825", "text": "#E65100"},  # warning
    {"fill": "#D7C4F2", "line": "#9C27B0", "text": "#4A148C"},  # purple
    {"fill": "#FFF3B0", "line": "#FBC02D", "text": "#F57F17"},  # yellow
    {"fill": "#C8E6C9", "line": "#689F38", "text": "#33691E"},  # olive
    {"fill": "#B3E5FC", "line": "#0288D1", "text": "#01579B"},  # cerulean
    {"fill": "#E1BEE7", "line": "#8E24AA", "text": "#6A1B9A"},  # violet
]

# 默认叶节点颜色（当深度 > 2 时继承分支色）
_LEAF_BG = "#F5F5F5"
_LEAF_FG = "#333333"

# ---------------------------------------------------------------------------
# 布局参数（对齐 markmap.vue 的 createMarkmap 配置）
# ---------------------------------------------------------------------------
_SPACING_H = 80       # 连线水平长度 spacingHorizontal
_SPACING_V = 20       # 节点垂直间距 spacingVertical
_PADDING_X_ROOT = 12  # 根/二级节点水平内边距
_PADDING_Y_ROOT = 8   # 根/二级节点垂直内边距
_PADDING_X_LEAF = 8   # 其他节点水平内边距
_PADDING_Y_LEAF = 6   # 其他节点垂直内边距
_BLOCK_RADIUS = 6     # 圆角半径 blockRadius
_LINE_WIDTH = 3       # 连线宽度 lineWidth

# 字体参数（对齐 markmap.vue CSS）
# 注意：字体列表需要覆盖 macOS / Windows / Linux 三个平台的中文字体
# Linux (Ubuntu): Noto Sans CJK SC, WenQuanYi Micro Hei, WenQuanYi Zen Hei
# macOS: PingFang SC
# Windows: Microsoft YaHei
_FONT_FAMILY = (
    "'Noto Sans CJK SC', 'Noto Sans SC', "
    "'WenQuanYi Micro Hei', 'WenQuanYi Zen Hei', "
    "'PingFang SC', 'Microsoft YaHei', "
    "'Helvetica Neue', Arial, sans-serif"
)
_FONT_SIZE = {1: 40, 2: 36}   # depth -> px，默认 32
_FONT_WEIGHT = {1: 500, 2: 500}  # depth -> weight，默认 400
_LINE_HEIGHT_RATIO = 1.4  # 行高比例

# 文本宽度估算：中文字符按 1em，ASCII 按 0.55em
_CJK_WIDTH_RATIO = 1.0
_ASCII_WIDTH_RATIO = 0.55
_MAX_TEXT_WIDTH_CHARS = 20  # 超过此字符数自动换行


# ========================== Markdown 解析 ==========================

def _parse_md_to_tree(markdown_text: str) -> dict:
    """将 Markdown 标题文本解析为树结构

    支持 # ~ ###### 六级标题，以及 - 开头的列表项。

    Returns:
        树节点字典：{"text": str, "children": [...], "depth": int}
    """
    lines = markdown_text.strip().split("\n")
    headings = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        m = re.match(r'^(#{1,6})\s+(.*)', stripped)
        if m:
            level = len(m.group(1))
            title = m.group(2).strip()
            headings.append((level, title))
            continue
        m2 = re.match(r'^[-*]\s+(.*)', stripped)
        if m2:
            indent = len(line) - len(line.lstrip())
            level = 7 + indent // 2
            title = m2.group(1).strip()
            headings.append((level, title))

    if not headings:
        return {}

    root = {"text": headings[0][1], "children": [], "_level": headings[0][0]}
    stack = [root]

    for level, title in headings[1:]:
        node = {"text": title, "children": [], "_level": level}
        while len(stack) > 1 and stack[-1]["_level"] >= level:
            stack.pop()
        stack[-1]["children"].append(node)
        stack.append(node)

    # 清理 _level，赋值 depth（根=1）
    def _assign_depth(n, depth):
        n.pop("_level", None)
        n["depth"] = depth
        for c in n.get("children", []):
            _assign_depth(c, depth + 1)
    _assign_depth(root, 1)
    return root


# ========================== 文本测量 ==========================

def _is_wide_char(ch: str) -> bool:
    """判断字符是否为宽字符（CJK、全角等）"""
    cat = unicodedata.east_asian_width(ch)
    return cat in ("W", "F")


def _estimate_text_width(text: str, font_size: int) -> float:
    """估算文本渲染宽度（像素）"""
    w = 0.0
    for ch in text:
        if _is_wide_char(ch):
            w += _CJK_WIDTH_RATIO
        else:
            w += _ASCII_WIDTH_RATIO
    return w * font_size


def _wrap_text(text: str, max_chars: int = _MAX_TEXT_WIDTH_CHARS) -> list:
    """将长文本按字符数拆分为多行"""
    if len(text) <= max_chars:
        return [text]
    lines = []
    current = ""
    count = 0
    for ch in text:
        current += ch
        count += 1
        if count >= max_chars:
            lines.append(current)
            current = ""
            count = 0
    if current:
        lines.append(current)
    return lines


# ========================== 节点尺寸计算 ==========================

def _calc_node_size(node: dict):
    """计算节点的宽度和高度（含内边距），并存入节点字典"""
    depth = node["depth"]
    font_size = _FONT_SIZE.get(depth, 32)
    px = _PADDING_X_ROOT if depth <= 2 else _PADDING_X_LEAF
    py = _PADDING_Y_ROOT if depth <= 2 else _PADDING_Y_LEAF

    text_lines = _wrap_text(node["text"])
    node["_lines"] = text_lines

    # 取最宽行
    max_line_w = max(_estimate_text_width(line, font_size) for line in text_lines)
    line_h = font_size * _LINE_HEIGHT_RATIO
    text_h = line_h * len(text_lines)

    node["_w"] = max_line_w + px * 2
    node["_h"] = text_h + py * 2
    node["_font_size"] = font_size
    node["_line_h"] = line_h

    for child in node.get("children", []):
        _calc_node_size(child)


# ========================== 树布局算法 ==========================

def _layout_tree(node: dict, x: float = 0, y_offset: float = 0) -> float:
    """从左到右的树布局，返回子树占用的总高度

    每个节点被赋值 _x, _y（节点左上角坐标）。
    """
    node["_x"] = x
    children = node.get("children", [])

    if not children:
        node["_y"] = y_offset
        return node["_h"]

    # 递归布局子节点
    child_x = x + node["_w"] + _SPACING_H
    total_children_h = 0
    for i, child in enumerate(children):
        child_h = _layout_tree(child, child_x, y_offset + total_children_h)
        total_children_h += child_h
        if i < len(children) - 1:
            total_children_h += _SPACING_V

    # 当前节点垂直居中于子节点区域
    subtree_h = max(total_children_h, node["_h"])
    if total_children_h > node["_h"]:
        node["_y"] = y_offset + (total_children_h - node["_h"]) / 2
    else:
        node["_y"] = y_offset
        # 子节点也需要居中偏移
        offset_delta = (node["_h"] - total_children_h) / 2
        _shift_subtree_y(children, offset_delta)

    return subtree_h


def _shift_subtree_y(nodes: list, delta: float):
    """递归偏移子树的 y 坐标"""
    for n in nodes:
        n["_y"] += delta
        _shift_subtree_y(n.get("children", []), delta)


# ========================== 分支颜色分配 ==========================

def _assign_branch_colors(root: dict):
    """为每个二级分支分配颜色，子节点继承分支色"""
    root["_bg"] = _ROOT_BG
    root["_fg"] = _ROOT_FG
    root["_line_color"] = _ROOT_BG

    for i, child in enumerate(root.get("children", [])):
        color = _BRANCH_COLORS[i % len(_BRANCH_COLORS)]
        _assign_color_recursive(child, color)


def _assign_color_recursive(node: dict, branch_color: dict):
    """递归分配分支颜色"""
    depth = node["depth"]
    if depth == 2:
        node["_bg"] = branch_color["fill"]
        node["_fg"] = branch_color["text"]
    else:
        node["_bg"] = _LEAF_BG
        node["_fg"] = _LEAF_FG
    node["_line_color"] = branch_color["line"]

    for child in node.get("children", []):
        _assign_color_recursive(child, branch_color)


# ========================== SVG 生成 ==========================

def _build_svg(root: dict) -> str:
    """根据布局好的树生成 SVG 字符串"""
    # 收集所有节点，计算画布边界
    all_nodes = []
    _collect_nodes(root, all_nodes)

    min_x = min(n["_x"] for n in all_nodes)
    min_y = min(n["_y"] for n in all_nodes)
    max_x = max(n["_x"] + n["_w"] for n in all_nodes)
    max_y = max(n["_y"] + n["_h"] for n in all_nodes)

    padding = 40
    svg_w = max_x - min_x + padding * 2
    svg_h = max_y - min_y + padding * 2
    offset_x = -min_x + padding
    offset_y = -min_y + padding

    parts = []
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'width="{svg_w:.0f}" height="{svg_h:.0f}" '
        f'viewBox="0 0 {svg_w:.0f} {svg_h:.0f}">'
    )
    parts.append(f'<rect width="100%" height="100%" fill="#FFFFFF"/>')
    parts.append(
        f'<style>'
        f'text {{ font-family: {_FONT_FAMILY}; }}'
        f'</style>'
    )
    parts.append(f'<g transform="translate({offset_x:.1f},{offset_y:.1f})">')

    # 先画连线（在节点下方）
    _draw_edges(root, parts)
    # 再画节点
    _draw_nodes(all_nodes, parts)

    parts.append('</g>')
    parts.append('</svg>')
    return '\n'.join(parts)


def _collect_nodes(node: dict, result: list):
    """递归收集所有节点"""
    result.append(node)
    for child in node.get("children", []):
        _collect_nodes(child, result)


def _draw_edges(node: dict, parts: list):
    """递归绘制父→子的贝塞尔曲线连线"""
    children = node.get("children", [])
    for child in children:
        # 起点：父节点右侧中点
        x1 = node["_x"] + node["_w"]
        y1 = node["_y"] + node["_h"] / 2
        # 终点：子节点左侧中点
        x2 = child["_x"]
        y2 = child["_y"] + child["_h"] / 2
        # 贝塞尔控制点（水平方向的 S 曲线）
        cx = (x1 + x2) / 2
        color = child.get("_line_color", "#CCCCCC")
        parts.append(
            f'<path d="M{x1:.1f},{y1:.1f} C{cx:.1f},{y1:.1f} {cx:.1f},{y2:.1f} {x2:.1f},{y2:.1f}" '
            f'fill="none" stroke="{color}" stroke-width="{_LINE_WIDTH}" stroke-opacity="0.6"/>'
        )
        _draw_edges(child, parts)


def _draw_nodes(nodes: list, parts: list):
    """绘制所有节点（圆角矩形 + 文本）"""
    for node in nodes:
        x = node["_x"]
        y = node["_y"]
        w = node["_w"]
        h = node["_h"]
        bg = node.get("_bg", _LEAF_BG)
        fg = node.get("_fg", _LEAF_FG)
        depth = node["depth"]
        font_size = node["_font_size"]
        font_weight = _FONT_WEIGHT.get(depth, 400)
        line_h = node["_line_h"]
        text_lines = node["_lines"]

        # 圆角矩形
        parts.append(
            f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" '
            f'rx="{_BLOCK_RADIUS}" ry="{_BLOCK_RADIUS}" fill="{bg}"/>'
        )

        # 文本（多行居中）
        px = _PADDING_X_ROOT if depth <= 2 else _PADDING_X_LEAF
        py = _PADDING_Y_ROOT if depth <= 2 else _PADDING_Y_LEAF
        text_x = x + px
        text_start_y = y + py + font_size * 0.85  # baseline 偏移

        for i, line in enumerate(text_lines):
            ty = text_start_y + i * line_h
            escaped = xml_escape(line)
            parts.append(
                f'<text x="{text_x:.1f}" y="{ty:.1f}" '
                f'font-size="{font_size}" font-weight="{font_weight}" '
                f'fill="{fg}">{escaped}</text>'
            )


# ========================== 字体检测 ==========================

_cjk_font_checked = False


def _check_cjk_fonts():
    """检测 Linux 环境下是否安装了中文字体（仅检测一次）

    如果缺少中文字体，cairosvg 渲染 SVG 时中文会显示为方块。
    """
    global _cjk_font_checked
    if _cjk_font_checked:
        return
    _cjk_font_checked = True

    if sys.platform != "linux":
        return

    import subprocess
    try:
        result = subprocess.run(
            ["fc-list", ":lang=zh"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0 and result.stdout.strip():
            return  # 找到中文字体
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass  # fc-list 不可用，跳过检测

    _logger.warning(
        "未检测到中文字体！脑图中的中文可能显示为方块。"
        "请安装中文字体：sudo apt-get install -y fonts-noto-cjk fonts-wqy-zenhei && fc-cache -fv"
    )


# ========================== 文件名处理 ==========================

def _sanitize_filename(name: str) -> str:
    """清理文件名，去除不安全字符，只保留字母、数字、中文、下划线、连字符"""
    # 去除文件扩展名
    base = os.path.splitext(name)[0]
    # 只保留安全字符
    cleaned = re.sub(r'[^\w\u4e00-\u9fff\-]', '_', base)
    # 合并连续下划线
    cleaned = re.sub(r'_+', '_', cleaned).strip('_')
    # 限制长度，避免文件名过长
    if len(cleaned) > 80:
        cleaned = cleaned[:80]
    return cleaned if cleaned else "mindmap"


# ========================== 主入口 ==========================

def markdown_to_markmap_image(markdown_text: str, output_path: str = "", fmt: str = "png", file_name: str = "") -> str:
    """将 Markdown 层级文本转换为 markmap 风格的思维导图图片

    纯 Python 实现：构建 SVG + cairosvg 转 PNG，无需浏览器。

    Args:
        markdown_text: Markdown 格式的思维导图文本（# 层级标题）
        output_path: 输出图片路径，为空时自动生成（使用 file_name + 时间戳命名）
        fmt: 输出格式，默认 png，也支持 svg
        file_name: 输入的 PDF 文件名（如 "2510.20255v1.pdf"），用于生成输出文件名

    Returns:
        生成的图片文件绝对路径

    Raises:
        RuntimeError: 解析失败或渲染失败时抛出
    """
    import cairosvg

    # 检测 Linux 环境下是否安装了中文字体
    _check_cjk_fonts()

    # 1. 解析 Markdown 为树结构
    tree = _parse_md_to_tree(markdown_text)
    if not tree:
        raise RuntimeError("未能从 Markdown 文本中解析出有效的标题层级")

    # 2. 计算节点尺寸
    _calc_node_size(tree)

    # 3. 树布局（从左到右）
    _layout_tree(tree)

    # 4. 分配分支颜色
    _assign_branch_colors(tree)

    # 5. 生成 SVG
    svg_content = _build_svg(tree)

    # 6. 确定输出路径
    #    默认保存到临时目录，由调用方决定后续处理（上传 COS 等）
    if not output_path:
        prefix = _sanitize_filename(file_name) if file_name else "mindmap"
        base_name = f"{prefix}_{int(time.time())}.{fmt}"
        tmp_dir = tempfile.mkdtemp(prefix="paper_mindmap_")
        output_path = os.path.join(tmp_dir, base_name)

    # 7. 输出
    if fmt == "svg":
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(svg_content)
    else:
        # 使用 cairosvg 转 PNG，2x 缩放保证高清
        cairosvg.svg2png(
            bytestring=svg_content.encode("utf-8"),
            write_to=output_path,
            scale=2,
        )

    return output_path


# 保持向后兼容的别名
markdown_to_graphviz_image = markdown_to_markmap_image
