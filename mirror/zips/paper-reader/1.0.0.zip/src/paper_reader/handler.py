#!/usr/bin/env python3
"""
论文阅读助手 — OpenClaw Tool Handler

OpenClaw 框架调用此脚本执行工具。
输入：从 stdin 读取 JSON，格式为 {"tool": "tool_name", "arguments": {...}}
输出：向 stdout 直接写入纯文本结果（流式工具逐 chunk 输出，非流式工具一次性输出）
"""

import json
import sys
import os
import time
import urllib.request

# 将当前源码目录加入模块搜索路径
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)

# 确保工作目录为 skill 根目录，使 api_client.py 的 _load_config() 能正确找到 config.json
# skill 根目录 = src/paper_reader/../../ = skill 安装目录
_SKILL_ROOT_DIR = os.path.normpath(os.path.join(_SCRIPT_DIR, "..", ".."))
if os.path.isfile(os.path.join(_SKILL_ROOT_DIR, "config.json")):
    os.chdir(_SKILL_ROOT_DIR)


def _load_config() -> dict:
    """从 config.json 加载配置，按优先级依次查找：
    1. 环境变量 PAPER_READER_CONFIG 指定的路径
    2. 当前工作目录
    3. 源码目录结构（开发时：src/paper_reader/../../config.json）
    4. 用户 home 目录 ~/.paper_reader/config.json
    """
    search_paths = [
        os.environ.get("PAPER_READER_CONFIG", ""),
        os.path.join(os.getcwd(), "config.json"),
        os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "config.json")),
        os.path.expanduser("~/.paper_reader/config.json"),
    ]
    for path in search_paths:
        if path and os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                continue
    return {}


_CONFIG = _load_config()
_DEFAULT_AUTHORIZATION = _CONFIG.get("api", {}).get("authorization", "")

from paper_reader_skill import (
    paper_mindmap,
    paper_deep_read,
    paper_summary,
    paper_translate,
    paper_chat,
    paper_podcast,
    paper_search,
    paper_podcast_video,
    stream_paper_summary,
    stream_paper_translate,
    stream_paper_chat,
    stream_paper_deep_read,
)

# 可用工具列表提示信息
_AVAILABLE_TOOLS_HINT = """## 📚 论文阅读助手

当前技能支持以下工具，请选择需要的功能：

| 工具 | 说明 |
|------|------|
| `paper_search` | 🔍 **论文搜索** — 根据关键词搜索论文，支持分页 |
| `paper_mindmap` | 🧠 **论文脑图** — 生成思维导图 PNG 图片 |
| `paper_deep_read` | 📖 **论文精读** — 深度精读分析（含精读、关键问答、评价） |
| `paper_summary` | 📝 **论文总结** — 对论文内容进行摘要总结 |
| `paper_translate` | 🌐 **论文翻译** — 对论文全文进行翻译 |
| `paper_chat` | 💬 **论文对话** — 基于论文进行多轮问答 |
| `paper_podcast` | 🎙️ **AI播客** — 将论文转为双人对话播客音频 |
| `paper_podcast_video` | 🎬 **翻转字幕视频** — 基于AI播客生成翻转字幕视频（需先生成播客） |

请告诉我您想使用哪个功能？"""


# 支持流式输出的工具集合
_STREAM_TOOLS = {
    "paper_deep_read", "paper_summary", "paper_translate", "paper_chat",
}


def _write_text(text: str):
    """将纯文本写入 stdout，立即 flush"""
    sys.stdout.write(text)
    sys.stdout.flush()


def _get_output_dir() -> str:
    """获取 output 目录路径，保存到工作区根目录下的 output 子目录

    查找优先级：
    1. 环境变量 OPENCLAW_WORKSPACE 指定的工作区目录下的 output
    2. 默认路径 ~/.openclaw/workspace/output
    """
    workspace = os.environ.get("OPENCLAW_WORKSPACE", "")
    if workspace and os.path.isdir(workspace):
        return os.path.join(workspace, "output")
    # 回退到默认 workspace 路径，而不是项目根目录
    return os.path.join(os.path.expanduser("~/.openclaw/workspace"), "output")


def _build_output_filename(tool_name: str, arguments: dict, ext: str = ".md") -> str:
    """根据工具名和参数构建输出文件名

    格式：{工具名}_{文件基础名}_{时间戳}{扩展名}
    """
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    # 从参数中提取文件名作为标识
    file_name = arguments.get("file_name", "")
    if file_name:
        base_name = os.path.splitext(file_name)[0]
    else:
        # 对于 paper_search 使用关键词，paper_chat 使用 question 的前几个字
        keyword = arguments.get("keyword", "") or arguments.get("question", "")
        base_name = keyword[:20].strip() if keyword else "result"
    # 清理文件名中的非法字符
    base_name = "".join(c if c.isalnum() or c in ("_", "-", ".") else "_" for c in base_name)
    # 去掉工具名前缀 paper_
    short_tool = tool_name.replace("paper_", "")
    return f"{short_tool}_{base_name}_{timestamp}{ext}"


def _save_to_output(content: str, tool_name: str, arguments: dict, ext: str = ".md"):
    """将内容保存到 output 目录

    Args:
        content: 要保存的文本内容
        tool_name: 工具名称
        arguments: 工具参数
        ext: 文件扩展名，默认 .md
    """
    try:
        output_dir = _get_output_dir()
        os.makedirs(output_dir, exist_ok=True)
        filename = _build_output_filename(tool_name, arguments, ext)
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        # 输出保存路径提示到 stdout，让框架/大模型知道文件已保存
        _write_text(f"\n\n---\n📄 结果已自动保存到: {filepath}\n")
    except Exception as e:
        sys.stderr.write(f"\n[output] 保存结果失败: {str(e)}\n")
        sys.stderr.flush()


def _save_binary_from_url(url: str, tool_name: str, arguments: dict, ext: str):
    """从 URL 下载二进制文件并保存到 output 目录

    Args:
        url: 文件下载地址
        tool_name: 工具名称
        arguments: 工具参数
        ext: 文件扩展名，如 .png, .wav
    """
    try:
        output_dir = _get_output_dir()
        os.makedirs(output_dir, exist_ok=True)
        filename = _build_output_filename(tool_name, arguments, ext)
        filepath = os.path.join(output_dir, filename)
        urllib.request.urlretrieve(url, filepath)
        _write_text(f"\n📎 文件已自动保存到: {filepath}\n")
    except Exception as e:
        sys.stderr.write(f"\n[output] 下载保存文件失败: {str(e)}\n")
        sys.stderr.flush()


def handle_tool_call_stream(tool_name: str, arguments: dict):
    """处理工具调用（流式输出纯文本）

    对于支持流式的工具，逐 chunk 将纯文本内容直接写入 stdout。

    Returns:
        True 表示已流式处理，False 表示不支持流式（需回退到非流式处理）
    """
    if tool_name not in _STREAM_TOOLS:
        return False

    # 鉴权检查
    authorization = _DEFAULT_AUTHORIZATION
    if not authorization:
        auth_url = _CONFIG.get("api", {}).get("auth_url", "")
        if auth_url:
            _write_text(f"错误：缺少鉴权 token，[点击获取 token]({auth_url})\n")
        else:
            _write_text("错误：缺少鉴权 token，请在 config.json 的 api.authorization 中配置有效的 token\n")
        return True

    # 公共参数提取
    file_url = arguments.get("file_url", "")
    file_name = arguments.get("file_name", "paper.pdf")
    file_type = arguments.get("file_type", "pdf")
    file_size = arguments.get("file_size", "0")
    conversation_id = arguments.get("conversation_id", "")

    # 文件URL检查
    file_required_tools = {"paper_deep_read", "paper_summary", "paper_translate"}
    if tool_name in file_required_tools and not file_url:
        _write_text("错误：file_url 参数不能为空，请提供论文文件的URL地址\n")
        return True

    # 获取流式生成器
    stream_gen = None
    if tool_name == "paper_summary":
        stream_gen = stream_paper_summary(authorization, file_url, file_name, file_type, file_size, conversation_id)
    elif tool_name == "paper_translate":
        stream_gen = stream_paper_translate(authorization, file_url, file_name, file_type, file_size, conversation_id)
    elif tool_name == "paper_chat":
        question = arguments.get("question", "")
        if not question:
            _write_text("错误：question 参数不能为空\n")
            return True
        stream_gen = stream_paper_chat(authorization, question, file_url, file_name, file_type, file_size, conversation_id)
    elif tool_name == "paper_deep_read":
        stream_gen = stream_paper_deep_read(authorization, file_url, file_name, file_type, file_size, conversation_id)

    if stream_gen is None:
        return False

    # 逐 chunk 将纯文本内容直接写入 stdout，同时收集完整内容用于保存
    collected_content = []
    for event in stream_gen:
        event_type = event.get("type", "")
        if event_type == "chunk":
            content = event.get("content", "")
            if content:
                _write_text(content)
                collected_content.append(content)
        elif event_type == "error":
            error_msg = event.get("error", "未知错误")
            _write_text(f"\n错误：{error_msg}\n")
        # done 类型不输出任何内容

    # 流式输出完成后，将完整内容保存到 output 目录
    if collected_content:
        full_content = "".join(collected_content)
        _save_to_output(full_content, tool_name, arguments)

    return True


def handle_tool_call(tool_name: str, arguments: dict) -> dict:
    """处理工具调用

    Args:
        tool_name: 工具名称
        arguments: 工具参数

    Returns:
        工具执行结果
    """
    # 已知工具名集合
    _known_tools = {
        "paper_mindmap", "paper_deep_read", "paper_summary",
        "paper_translate", "paper_chat", "paper_podcast", "paper_search",
        "paper_podcast_video",
    }

    # 未知工具名时，返回可用工具列表
    if tool_name not in _known_tools:
        return {"content": _AVAILABLE_TOOLS_HINT, "success": True}

    # 从 config.json 读取鉴权 token
    authorization = _DEFAULT_AUTHORIZATION

    if not authorization:
        auth_url = _CONFIG.get("api", {}).get("auth_url", "")
        if auth_url:
            return {"error": f"缺少鉴权 token，[点击获取 token]({auth_url})"}
        return {"error": "缺少鉴权 token，请在 config.json 的 api.authorization 中配置有效的 token"}

    # 公共参数提取
    file_url = arguments.get("file_url", "")
    file_name = arguments.get("file_name", "paper.pdf")
    file_type = arguments.get("file_type", "pdf")
    file_size = arguments.get("file_size", "0")
    conversation_id = arguments.get("conversation_id", "")

    # 需要文件URL的工具（chat除外）
    file_required_tools = {
        "paper_mindmap", "paper_deep_read", "paper_summary",
        "paper_translate", "paper_podcast",
    }

    if tool_name in file_required_tools and not file_url:
        return {"error": "file_url 参数不能为空，请提供论文文件的URL地址"}

    if tool_name == "paper_mindmap":
        return paper_mindmap(authorization, file_url, file_name, file_type, file_size, conversation_id)

    elif tool_name == "paper_deep_read":
        return paper_deep_read(authorization, file_url, file_name, file_type, file_size, conversation_id)

    elif tool_name == "paper_summary":
        return paper_summary(authorization, file_url, file_name, file_type, file_size, conversation_id)

    elif tool_name == "paper_translate":
        return paper_translate(authorization, file_url, file_name, file_type, file_size, conversation_id)

    elif tool_name == "paper_chat":
        question = arguments.get("question", "")
        if not question:
            return {"error": "question 参数不能为空"}
        return paper_chat(authorization, question, file_url, file_name, file_type, file_size, conversation_id)

    elif tool_name == "paper_podcast":
        doc_id = arguments.get("doc_id", "")
        mode = arguments.get("mode", "quick_insight")
        voices = arguments.get("voices", ["zixin", "acan"])
        result = paper_podcast(
            authorization, file_url, file_name, file_type, file_size,
            doc_id=doc_id, mode=mode, voices=voices, conversation_id=conversation_id,
        )
        
        # 检查请求是否成功
        if not result.get("success"):
            # 处理错误情况
            error_msg = result.get("error", "未知错误")
            error_content = f"""
## ❌ AI播客生成失败

**📁 文件名：** {file_name}
**🎙️ 播客模式：** {mode}
**❌ 错误信息：** {error_msg}

### 🔧 可能的原因：
- 后端音频生成服务暂时不可用
- 文件处理过程中出现异常
- 资源限制或超时

### 💡 建议操作：
1. 稍后重试此操作
2. 尝试使用其他模式（如"deep_analysis"）
3. 联系技术支持检查服务状态

需要我帮您尝试其他论文分析功能吗？比如生成论文摘要、思维导图或者关键问答？
"""
            result["content"] = error_content
            return result
        
        # 从 podcast_msg 中提取音频 URL
        podcast_msg = result.get("podcast_msg")
        audio_url = ""
        if podcast_msg:
            audio_url = podcast_msg.get("audio_url", "")
        # 也检查 parse_sse_stream 收集的 audio_url
        if not audio_url:
            audio_url = result.get("podcast_audio_url", "")

        if audio_url:
            result["audio_url"] = audio_url

            file_name = arguments.get("file_name", "paper.pdf")

            # 构建播客结果内容
            # 使用 HTML5 <audio> 标签，支持在浏览器/对话框中直接播放音频
            audio_content = (
                f"## 🎙️ AI播客已成功生成！\n\n"
                f"**📁 文件：** {file_name}　|　**🎙️ 模式：** {mode}\n\n"
                f"<audio controls src=\"{audio_url}\">您的浏览器不支持音频播放</audio>\n\n"
                f"[📥 下载音频文件]({audio_url})\n"
            )

            result["content"] = audio_content

        # 保存完整播客数据到文件（用于后续生成翻转字幕视频）
        _save_podcast_data(result, arguments)

        return result

    elif tool_name == "paper_search":
        keyword = arguments.get("keyword", "")
        if not keyword:
            return {"error": "keyword 参数不能为空，请提供搜索关键词"}
        page = arguments.get("page", 1)
        size = arguments.get("size", 10)
        return paper_search(authorization, keyword, page=page, size=size)

    elif tool_name == "paper_podcast_video":
        # 查找播客数据文件
        podcast_data_path = arguments.get("podcast_data_path", "")
        if not podcast_data_path:
            # 自动查找最近的播客数据文件
            podcast_data_path = _find_latest_podcast_data(arguments)
        if not podcast_data_path:
            return {
                "error": "未找到播客数据，请先使用 paper_podcast 工具生成 AI 播客，然后再生成翻转字幕视频",
            }
        doc_id = arguments.get("doc_id", "")
        style = arguments.get("style", "quick_insight")
        result = paper_podcast_video(
            authorization=authorization,
            podcast_data_path=podcast_data_path,
            doc_id=doc_id,
            style=style,
        )

        if result.get("success") and result.get("video_url"):
            video_url = result["video_url"]
            title = result.get("title", "播客视频")
            video_content = (
                f"## 🎬 翻转字幕视频已生成！\n\n"
                f"**📹 标题：** {title}\n\n"
                f"<video controls width=\"100%\" src=\"{video_url}\">您的浏览器不支持视频播放</video>\n\n"
                f"[📥 下载视频文件]({video_url})\n"
            )
            result["content"] = video_content

        return result

    else:
        return {"content": _AVAILABLE_TOOLS_HINT, "success": True}


def _get_podcast_data_dir() -> str:
    """获取播客数据保存目录"""
    output_dir = _get_output_dir()
    podcast_dir = os.path.join(output_dir, "podcast_data")
    os.makedirs(podcast_dir, exist_ok=True)
    return podcast_dir


def _save_podcast_data(result: dict, arguments: dict):
    """保存播客完整数据到文件（用于后续生成翻转字幕视频）

    保存的数据包含 all_speaker_text_list、podcast_audio_url、podcast_title、podcast_start_text 等字段。
    """
    all_speaker_text_list = result.get("all_speaker_text_list", [])
    podcast_audio_url = result.get("podcast_audio_url", "") or result.get("audio_url", "")

    if not all_speaker_text_list or not podcast_audio_url:
        return

    podcast_data = {
        "all_speaker_text_list": all_speaker_text_list,
        "podcast_audio_url": podcast_audio_url,
        "podcast_title": result.get("podcast_title", ""),
        "podcast_start_text": result.get("podcast_start_text", "欢迎收听混元AI播客"),
        "file_url": arguments.get("file_url", ""),
        "file_name": arguments.get("file_name", "paper.pdf"),
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }

    try:
        podcast_dir = _get_podcast_data_dir()
        file_name = arguments.get("file_name", "paper.pdf")
        base_name = os.path.splitext(file_name)[0] if file_name else "paper"
        base_name = "".join(c if c.isalnum() or c in ("_", "-", ".") else "_" for c in base_name)
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"podcast_{base_name}_{timestamp}.json"
        filepath = os.path.join(podcast_dir, filename)

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(podcast_data, f, ensure_ascii=False, indent=2)

        sys.stderr.write(f"[podcast] 播客数据已保存到: {filepath}\n")
        sys.stderr.flush()
    except Exception as e:
        sys.stderr.write(f"[podcast] 保存播客数据失败: {str(e)}\n")
        sys.stderr.flush()


def _find_latest_podcast_data(arguments: dict) -> str:
    """查找最近的播客数据文件

    优先匹配同名文件，否则返回最新的播客数据文件。
    """
    try:
        podcast_dir = _get_podcast_data_dir()
        if not os.path.isdir(podcast_dir):
            return ""

        json_files = [
            f for f in os.listdir(podcast_dir)
            if f.startswith("podcast_") and f.endswith(".json")
        ]

        if not json_files:
            return ""

        # 尝试匹配同名文件
        file_name = arguments.get("file_name", "")
        if file_name:
            base_name = os.path.splitext(file_name)[0]
            base_name_clean = "".join(c if c.isalnum() or c in ("_", "-", ".") else "_" for c in base_name)
            matching = [f for f in json_files if base_name_clean in f]
            if matching:
                matching.sort(reverse=True)
                return os.path.join(podcast_dir, matching[0])

        # 返回最新的文件
        json_files.sort(reverse=True)
        return os.path.join(podcast_dir, json_files[0])
    except Exception:
        return ""


def _save_non_stream_result(tool_name: str, arguments: dict, result: dict, text_output: str):
    """保存非流式工具的输出结果到 output 目录

    根据工具类型和返回结果，自动判断保存的文件类型：
    - paper_mindmap：保存 .md 文本 + 下载 .png 脑图图片
    - paper_podcast：保存 .md 文本 + 下载 .wav 音频文件
    - 其他工具：保存 .md 纯文本
    """
    # 错误结果或空工具列表提示不保存
    if "error" in result or not result.get("success", True):
        return
    if not text_output or text_output.startswith("错误："):
        return

    # 保存纯文本内容为 .md
    _save_to_output(text_output, tool_name, arguments)

    # 脑图工具：额外下载 PNG 图片
    if tool_name == "paper_mindmap":
        image_url = result.get("mindmap_image_url", "")
        if image_url:
            _save_binary_from_url(image_url, tool_name, arguments, ".png")

    # 播客工具：额外下载 WAV 音频
    elif tool_name == "paper_podcast":
        audio_url = result.get("audio_url", "")
        if audio_url:
            _save_binary_from_url(audio_url, tool_name, arguments, ".wav")

    # 翻转字幕视频工具：额外下载 MP4 视频
    elif tool_name == "paper_podcast_video":
        video_url = result.get("video_url", "")
        if video_url:
            _save_binary_from_url(video_url, tool_name, arguments, ".mp4")


def _extract_text_from_result(result: dict) -> str:
    """从工具返回的 dict 中提取纯文本内容"""
    if "error" in result:
        return f"错误：{result['error']}\n"
    if "content" in result:
        return result["content"]
    # 对于没有 content 字段的结果，回退为 JSON 输出
    return json.dumps(result, ensure_ascii=False)


def main():
    """主入口：从 stdin 读取工具调用请求，执行后直接输出纯文本结果

    支持两种输出模式：
    1. 流式输出：对于支持流式的工具，逐 chunk 直接输出纯文本
    2. 非流式输出：对于不支持流式的工具，一次性输出纯文本结果
    """
    try:
        # 从 stdin 读取请求
        input_data = sys.stdin.read()
        if not input_data.strip():
            _write_text("错误：输入为空\n")
            return

        request = json.loads(input_data)
        tool_name = request.get("tool", "")
        arguments = request.get("arguments", {})

        if not tool_name:
            _write_text(_AVAILABLE_TOOLS_HINT)
            return

        # 尝试流式输出
        if handle_tool_call_stream(tool_name, arguments):
            return

        # 回退到非流式输出（直接输出纯文本）
        result = handle_tool_call(tool_name, arguments)
        text_output = _extract_text_from_result(result)
        _write_text(text_output)

        # 将非流式输出结果保存到 output 目录
        _save_non_stream_result(tool_name, arguments, result, text_output)

    except json.JSONDecodeError as e:
        _write_text(f"错误：JSON 解析失败: {str(e)}\n")
    except Exception as e:
        _write_text(f"错误：执行失败: {str(e)}\n")


if __name__ == "__main__":
    main()
