# Paper Reader 论文阅读助手

论文阅读助手，调用后端接口对论文进行搜索和多种维度的智能分析。

## Features

- 🔍 论文搜索 — 根据关键词搜索论文，支持分页
- 📊 论文脑图 — 生成 Markdown 层级思维导图
- 📖 论文精读 — 深度精读分析，包含精读、关键问答、评价三合一
- 📝 论文总结 — 对论文内容进行摘要总结
- 🌐 论文翻译 — 对论文全文进行翻译
- 💬 论文对话 — 基于论文进行多轮问答
- 🎙️ AI播客 — 将论文转为双人对话播客音频

## Installation

```bash
# Install locally
pip install -e .
```

## Usage

### As OpenClaw Skill

工具调用通过 stdin/stdout JSON 交互：

```bash
echo '{"tool": "paper_summary", "arguments": {"file_url": "https://example.com/paper.pdf"}}' | \
  python -m paper_reader.handler
```

### Command Line

```bash
python -m paper_reader.paper_reader_skill summary <token> <file_url> [file_name]
python -m paper_reader.paper_reader_skill chat <token> <question> [file_url] [conversation_id]
python -m paper_reader.paper_reader_skill podcast <token> <file_url> [file_name]
python -m paper_reader.paper_reader_skill search <token> <keyword> [page] [size]
```

## Supported Commands

| Command | Description |
|---------|-------------|
| `search` | 论文搜索 |
| `mindmap` | 论文脑图 |
| `deep_read` | 论文精读（含精读、关键问答、评价） |
| `summary` | 论文总结 |
| `translate` | 论文翻译 |
| `chat` | 论文对话 |
| `podcast` | AI播客 |

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

```
## Authentication (Token 鉴权)

所有接口调用需要提供鉴权 token。

### Token 缺失或无效时的提示

当用户未提供 token，或接口返回 **HTTP 401**（鉴权失败）时，技能会返回以下提示信息：

```
[点击获取 token](https://edu.tencent.com/agent/#/api-keys)
```

> 该地址由 `config.json` 的 `api.auth_url` 字段统一配置，代码中从 config 读取。


