# Paper Reader - API References

## 后端接口

### SSE Chat Endpoint

- **URL**: `POST /sse/aiwriter/v1/chat`
- **Base URL**: 由 `config.json` 中的 `api.base_url` 配置
- **Content-Type**: `application/json`
- **Accept**: `text/event-stream`
- **Authorization**: Header 中传入用户 token

### Request Body

```json
{
  "conversation_id": "",
  "incr_rsp": true,
  "message": {
    "content": "",
    "attachments": [
      {
        "file_name": "paper.pdf",
        "app_name": "论文脑图",
        "show": true,
        "path": "https://example.com/paper.pdf",
        "file_type": "pdf",
        "size": "0",
        "agent_tag": "mind_map"
      }
    ]
  },
  "app_name": "论文脑图",
  "app_type": "hy"
}
```

### SSE Response Format

```
data: {"code": 0, "data": {"conversation_id": "xxx", "content": {"content": "增量文本"}, "stop": false}}
data: {"code": 0, "data": {"conversation_id": "xxx", "content": {"content": ""}, "stop": true}}
```

### App Config Mapping

| app_key | app_name | agent_tag |
|---------|----------|-----------|
| mindmap | 论文脑图 | mind_map |
| deep_read | 论文精读 | deep_read |
| summary | 论文总结 | abstract |
| translate | 论文翻译 | translate |
| evaluate | 论文评价 | (empty) |
| key_qa | 关键问题及回答 | key_quest_answer |
| chat | 论文对话 | (empty) |
| podcast | AI播客 | podcast |

### Podcast Extra Fields

播客请求额外包含 `podcast` 字段：

```json
{
  "podcast": {
    "mode": "quick_insight",
    "voices": ["zixin", "acan"]
  }
}
```

---

### Search Paper Endpoint

- **URL**: `POST /trpc/aiwriter/v1/search_paper`
- **Base URL**: 由 `config.json` 中的 `api.base_url` 配置
- **Content-Type**: `application/json;charset=UTF-8`
- **Accept**: `application/json`
- **Authorization**: Header 中传入用户 token

### Request Body

```json
{
  "page": 1,
  "size": 10,
  "keyword": "deepseek"
}
```

### Response Format

```json
{
  "total": 1954,
  "keyword": "deepseek",
  "papers": [
    {
      "id": "2604.14853v1",
      "title": "Adaptive TestTime Compute Allocation for Reasoning LLMs",
      "authors": ["Author1", "Author2"],
      "categories": ["cs.LG"],
      "published": "2026-04-16T10:39:22Z",
      "updated": "2026-04-16T10:39:22Z",
      "summary": "论文摘要...",
      "comment": "",
      "journal_ref": "",
      "pdf_url": "https://arxiv.org/pdf/2604.14853v1",
      "abstract_url": "https://arxiv.org/abs/2604.14853v1"
    }
  ],
  "request_id": "c278de05-6220-4d74-8aa4-8b9135b0be9b",
  "code": 0,
  "msg": "ok"
}
```

---

### Error Handling

- **401**: 鉴权失败，token 无效或过期。此时返回以下提示信息：

  ```
  [点击获取 token](https://edu.tencent.com/agent/#/api-keys)
  ```

- **Token 缺失**: 用户未提供鉴权 token 时，同样返回上述提示信息。

> 该地址由 `config.json` 的 `api.auth_url` 字段统一配置，代码中从 config 读取。
- **非0 code**: 业务逻辑错误，`msg` 字段包含错误信息
- **Search Paper 接口**: 同样遵循上述错误处理规则，返回 JSON 格式（非 SSE 流式）
