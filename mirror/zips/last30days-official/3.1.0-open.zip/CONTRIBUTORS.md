# Contributors

last30days is built by [@mvanhorn](https://github.com/mvanhorn) with help from the community.

## v3 Inspiration

These contributors submitted PRs and issues that directly inspired v3 features. The v3 engine was a ground-up rewrite, so their original code wasn't merged, but their ideas shaped what shipped.

Want to claim your entry? Submit a PR replacing the placeholder line below your name with your bio, website, or anything you'd like.

---

### @uppinote20
[PR #143](https://github.com/mvanhorn/last30days-skill/pull/143) - Rich Reddit comments, top 3 per post
v3 ships top comments with upvote counts on every thread.
> _Add your bio, website, or anything you'd like here._

### @zerone0x
[Issue #134](https://github.com/mvanhorn/last30days-skill/issues/134) + [PR #136](https://github.com/mvanhorn/last30days-skill/pull/136) - GitHub as a first-class data source
v3 has full GitHub search: issues, PRs, person-mode profiles, project-mode repos with live star counts.
> _Add your bio, website, or anything you'd like here._

### @thinkun
[PR #116](https://github.com/mvanhorn/last30days-skill/pull/116) - Resilient Reddit, prevent enrichment timeout from discarding results
v3 has parallel enrichment with per-item timeouts. No results are ever dropped.
> _Add your bio, website, or anything you'd like here._

### @thomasmktong
[PR #124](https://github.com/mvanhorn/last30days-skill/pull/124) - Pure Python Reddit fallback
v3 Reddit is 100% pure Python with zero external dependencies.
> _Add your bio, website, or anything you'd like here._

### @fanispoulinakisai-boop
[Issue #100](https://github.com/mvanhorn/last30days-skill/issues/100) - Reddit timeout report
Drove the timeout resilience work that made v3 Reddit bulletproof.
> _Add your bio, website, or anything you'd like here._

### @pejmanjohn
[Issue #78](https://github.com/mvanhorn/last30days-skill/issues/78) - ScrapeCreators silent failures
v3 surfaces all API errors with clear diagnostics instead of silently returning empty results.
> Repping the mighty MI; home of the most cracked agentic engineers. https://github.com/pejmanjohn

### @zl190
[PR #115](https://github.com/mvanhorn/last30days-skill/pull/115) - HN trending merge
v3 merges trending and keyword HN results with deduplication for better coverage.
> Healthcare AI engineer. [Blog](https://zl190.github.io/blog)

### @hnshah
[PR #84](https://github.com/mvanhorn/last30days-skill/pull/84), [#85](https://github.com/mvanhorn/last30days-skill/pull/85), [#86](https://github.com/mvanhorn/last30days-skill/pull/86) - Watchlist delivery, 90-day scanning window, HN/Polymarket storage
v3 has durable watchlist with multi-source storage and extended time windows.
> Hiten Shah. Founder. Builds in public. https://github.com/hnshah

---

## Past Contributors

- [@JosephOIbrahim](https://github.com/JosephOIbrahim) - Windows Unicode fix ([#17](https://github.com/mvanhorn/last30days-skill/pull/17))
- [@levineam](https://github.com/levineam) - Model fallback for unverified orgs ([#16](https://github.com/mvanhorn/last30days-skill/pull/16))
- [@jonthebeef](https://github.com/jonthebeef) - Early testing and feedback
