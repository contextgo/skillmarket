# Check-in Manager Skill

通用打卡活动管理系统，支持多活动并行、AI 智能校验、自然语言配置。

---

## 🎯 核心特点

- **配置简单**：TXT 文件自然语言描述规则，无需学习 JSON
- **AI 驱动**：智能匹配活动、提取数据、校验规则
- **灵活强大**：支持严格数值规则和主观判断（如"感想有深度"）
- **多活动并行**：同一群可以创建多个打卡活动（周度、月度等）

---

## 📂 目录结构

```
check-in-manager-skill/
├── SKILL.md                    # Skill 主文件（Agent 执行逻辑）
├── README.md                   # 本文件
├── activities/                 # 活动配置目录（TXT 格式）
│   ├── group-xxx_running_xxx.txt       # 周跑步打卡
│   ├── group-xxx_act384xxx.txt         # 月慢跑打卡
│   ├── example-running.txt             # 示例：跑步打卡
│   └── example-reading.txt             # 示例：读书打卡
├── records/                    # 打卡记录目录（JSON 格式）
│   ├── group-xxx_running_xxx/
│   │   └── 2026-04-08.json
│   └── group-xxx_act384xxx/
│       └── 2026-04-08.json
├── scripts/                    # 工具脚本
│   ├── generate_activity_id.py         # 生成活动 ID ✅
│   └──save_record.py          # 保存打卡记录 ✅
└── docs/                       # 文档目录
    ├── README.md                       # 文档索引
    ├── SKILL-CHANGELOG.md              # Skill 变更日志
    ├── MODIFICATION-SUMMARY.md         # 修改总结
    ├── validation-*.md                 # 旧版校验逻辑文档（参考）
    ├── activity-id-design-v3.md        # Activity ID 设计文档
    └── activity-id-v3-changelog.md     # Activity ID 变更日志
```

---

## 🚀 快速开始

### 1. 创建打卡活动

**方式1：直接告诉群规则**
```
用户：群规则：每周跑步不少于10公里，配速不超过10分钟/公里
Agent：[自动创建活动配置 TXT 文件]
```

**方式2：手动创建 TXT 文件**
```txt
# 文件名：activities/group-xxx_creator_running_timestamp.txt

活动名称: 跑步打卡
活动ID: group-xxx_creator_running_timestamp
状态: 激活

【触发关键词】
- 跑步
- 公里
- 配速

【规则详情】
规则1: 距离不少于10公里
规则2: 配速不超过10分钟/公里
规则3: 60岁以上可以豁免配速
```

### 2. 用户打卡

```
用户：今天跑了12公里，配速8分钟
Agent：
  → AI 匹配活动（跑步打卡）
  → AI 提取数据（distance: 12, pace: 8）
  → AI 校验规则（12 ≥ 10 ✅，8 ≤ 10 ✅）
  → 保存记录
  → 回复用户："✅ 打卡成功！"
```

### 3. 查询进度

```
用户：我本月跑了多少公里？
Agent：
  → 读取记录文件
  → 统计累计距离
  → 分析进度和建议
```

---

## 📝 配置文件格式

### TXT 配置文件（activities/\*.txt）

```txt
活动名称: 跑步打卡
活动ID: group-075a2475_ceceilyqi_running_1775643955
状态: 激活
创建时间: 2026-04-08 18:25:00
创建者: ceceilyqi

【触发关键词】
- 跑步
- 公里
- 配速
- km
- run

【打卡频次】
每周至少1次，截止时间：周一 0:00

【打卡内容要求】
- 户外跑或跑步机跑步
- 需要包含距离和配速信息

【规则详情】
规则1: 距离不少于10公里
规则2: 配速不超过10分钟/公里
规则3: 必须提供距离和配速数据
规则4: 60周岁及以上用户可只记录10公里数，不计配速
规则5: 雨天可以降低距离要求到5公里

【惩罚机制】
连续3周未完成打卡，强制退群

【备注】
鼓励大家坚持运动，保持健康！
有特殊情况可以说明，酌情处理。
```

### JSON 记录文件（records/\*/YYYY-MM-DD.json）

```json
[
  {
    "user": "ceceilyqi",
    "user_id": "ceceilyqi",
    "time": "2026-04-08T18:30:00+08:00",
    "data": {
      "distance": 12,
      "pace": 8,
      "duration": 96
    },
    "content": "今天跑了12公里，配速8分钟",
    "valid": true,
    "validated_by": "ai_model",
    "validation_time": "2026-04-08T18:30:05+08:00"
  }
]
```

---

## 🔧 使用的脚本

### ✅ 当前使用

#### 1. `generate_activity_id.py`
**功能**：生成唯一的活动 ID

**使用场景**：创建新活动时

**命令**：
```bash
python3 scripts/generate_activity_id.py \
  --group "跑步打卡群" \
  --creator "alice" \
  --type "跑步"

# 输出：group-075a2475_alice_running_1775643955
```

**ID 格式**：`{群名}_{创建者}_{类型}_{时间戳}`
- 纯英文/数字（无中文）
- 群名：提取英文或生成 hash
- 创建者：保留字母数字或生成 hash
- 类型：预定义映射（跑步→running）或生成 hash

#### 2. `save_record.py`
**功能**：保存打卡记录到 JSON 文件

**使用场景**：打卡校验通过后

**命令**：
```bash
python3 scripts/save_record.py \
  --activity-id "group-075a2475_ceceilyqi_running_1775643955" \
  --user "alice" \
  --data '{"distance": 12, "pace": 8}' \
  --content "今天跑了12公里，配速8分钟"
```

**输出**：`records/{activity_id}/YYYY-MM-DD.json`

---


## 🔄 工作流程

### 完整流程图

```
用户消息
    ↓
[1] AI 识别意图
    ├─ 创建活动 → 生成 activity_id → 创建 TXT 配置
    ├─ 打卡 → 进入打卡流程
    └─ 查询 → 读取记录统计
    ↓
[2] 打卡流程
    ↓
[2.1] AI 匹配活动
    - 读取所有 activities/*.txt
    - 语义分析最匹配的活动
    - 置信度评估
    ↓
[2.2] AI 提取数据
    - 从用户消息中提取结构化数据
    - {"distance": 12, "pace": 8}
    ↓
[2.3] AI 校验规则
    - 读取活动规则 TXT
    - AI 判断是否符合规则
    - 返回 {"valid": true/false, "reason": "..."}
    ↓
[2.4] 保存记录（如果通过）
    - 调用 save_record.py
    - 写入 records/{activity_id}/YYYY-MM-DD.json
    ↓
[2.5] 回复用户
    - 通过 → "✅ 打卡成功！"
    - 不通过 → "❌ 打卡未通过，原因：..."
```

---

## 🎯 设计特点

### 1. TXT 配置 vs JSON 配置

| 维度 | TXT（新版） | JSON（旧版） |
|------|------------|-------------|
| **可读性** | ✅ 自然语言 | ⚠️ 需要学习语法 |
| **编辑难度** | ✅ 任何人都能编辑 | ❌ 需要技术背景 |
| **灵活性** | ✅ 支持主观判断 | ⚠️ 只能严格规则 |
| **机器可解析** | ⚠️ 需要 AI | ✅ 标准库直接解析 |

---

### 2. AI 校验 vs 代码校验

| 维度 | AI 校验（新版） | 代码校验（旧版） |
|------|----------------|----------------|
| **灵活性** | ✅ 理解模糊表达 | ❌ 只能精确匹配 |
| **主观判断** | ✅ 支持（如"有深度"） | ❌ 无法实现 |
| **确定性** | ⚠️ 95-98% | ✅ 100% |
| **成本** | ⚠️ Token 消耗 | ✅ 0 |
| **维护** | ✅ 改 TXT 即可 | ⚠️ 需要改代码 |

---

### 3. Activity ID 设计（v3）

**格式**：`{群名}_{创建者}_{类型}_{时间戳}`

**示例**：
- `tech-group_alice_running_1775643955`（全英文）
- `group-6bd4d29d_bob_running_1775644000`（纯中文群名→hash）
- `fitness-club_u615db57a_reading_1775644001`（中文创建者→hash）

**优势**：
- ✅ 唯一性：时间戳保证
- ✅ 可追溯：包含群名和创建者信息
- ✅ 兼容性：纯 ASCII，无编码问题
- ✅ URL 友好：可直接用于 API

**详细文档**：`docs/activity-id-design-v3.md`

---

## 📊 实际案例

### 案例1：周跑步打卡

**规则**：
- 每周10公里，配速≤10分钟
- 60岁豁免配速
- 连续3周未完成退群

**用户打卡**：
```
张总（65岁）：今天跑了10公里，配速15分钟
AI判断：✅ 通过（60岁豁免配速）

李明：今天跑了8公里，配速8分钟
AI判断：❌ 不通过（距离不足）
```

---

### 案例2：月慢跑打卡

**规则**：
- 每月累计100公里（老手）或50公里（新手）
- 配速≤20分钟
- 可每天多次打卡累计

**查询进度**：
```
用户：我本月跑了多少公里？
Agent：
  - 本月累计：25公里
  - 目标距离：100公里（老手）
  - 完成进度：25%
  - 还需：75公里
  - 建议：每周跑3-4次，每次6-8公里
```

---

## ⚠️ 注意事项

### AI 校验的限制

1. **不确定性**：同样输入可能不同输出（通过 prompt 工程减少）
2. **成本**：每次校验消耗 token（小规模可接受）
3. **可能被欺骗**：需要防护（prompt 中加"严格按规则"）

### 适用场景

**✅ 推荐使用**：
- 小到中等规模群组（<200人）
- 低到中频打卡（每周1-3次）
- 规则包含主观判断
- 需要频繁调整规则

**❌ 不推荐使用**：
- 严格合规要求（如企业考勤）
- 超大规模高频（成本考虑）
- 需要精确审计（如比赛排名）

---

## 🔄 版本历史

### v2.0（2026-04-08）
- 🎉 **重大重构**：从代码校验改为 AI 校验
- ✅ 配置文件：JSON → TXT
- ✅ 活动匹配：关键词 → AI 语义
- ✅ 数据提取：正则 → AI NLP
- ✅ 规则校验：代码 → AI 判断
- 📝 Activity ID v3：纯英文版本

### v1.0（2026-04-07）
- ✅ 基础功能：创建活动、打卡记录
- ✅ JSON 配置 + 代码校验
- ✅ 支持豁免机制（validate_checkin_v2.py）

---

## 📖 相关文档

- `SKILL.md`：主文件（Agent 执行逻辑）
- `docs/SKILL-CHANGELOG.md`：详细变更日志（v1 vs v2）
- `docs/MODIFICATION-SUMMARY.md`：修改总结
- `docs/activity-id-design-v3.md`：Activity ID 设计文档
- `docs/validation-*.md`：旧版校验逻辑文档（参考）

---

## 🚀 未来计划

- [ ] 统计报告生成（周报、月报）
- [ ] 可视化配置界面（Web UI / 企业微信小程序）
- [ ] 导出数据功能（Excel、PDF）
- [ ] 群成员排名和徽章系统
- [ ] 多语言支持（中英文切换）

---

## 💡 常见问题

### Q1: 为什么改为 AI 校验？
A: TXT 配置更易读，AI 校验更灵活，支持主观判断和模糊表达。

### Q2: 如果 AI 判断不准确怎么办？
A: 通过 prompt 工程优化，或在关键场景使用混合方案（AI 提取 + 代码校验）。

### Q3: 旧版脚本还能用吗？
A: 可以，但不推荐。如果需要回退到代码校验，保留的 validate_checkin_v2.py 仍可使用。

### Q4: 如何创建新活动？
A: 直接创建 TXT 文件（参考 activities/example-\*.txt），或告诉 Agent 群规则让其自动生成。

### Q5: 打卡记录存在哪里？
A: `records/{activity_id}/YYYY-MM-DD.json`，JSON 格式，便于统计和导出。

---

## 📧 联系方式

如有问题或建议，请联系：
- 创建者：ceceilyqi
- Skill 路径：`~/.openclaw/workspace/skills/check-in-manager-skill`

---

**最后更新**：2026-04-08 21:22  
**版本**：v2.0（AI 校验版本）
