#!/usr/bin/env python3
"""
Activity ID 生成工具 (v4)
用于生成符合规范的唯一活动标识符（纯英文/数字）

v4 更新：移除群名前缀，通过目录结构隔离群组
格式: {活动类型}_{创建者ID}_{时间戳}
"""
import time
import re
import sys
import argparse
import hashlib


def transliterate_chinese(text):
    """
    将中文转换为拼音或移除
    简单策略：如果包含中文，生成 hash 作为标识
    """
    # 检测是否包含中文
    if re.search(r'[\u4e00-\u9fa5]', text):
        # 包含中文，生成短 hash
        return hashlib.md5(text.encode()).hexdigest()[:8]
    return text


def generate_activity_id(creator_id, activity_type):
    """
    生成活动 ID (v4 - 移除群名前缀)
    
    格式: {活动类型}_{创建者ID}_{时间戳}
    所有字段只包含小写字母、数字、连字符
    
    参数:
        creator_id: 创建者标识（如 "alice" 或 "张三"）
        activity_type: 活动类型（如 "running" 或 "跑步"）
    
    返回:
        格式化的 activity_id（如 "running_alice_1733568000"）
        纯英文/数字，不包含中文
    """
    # 1. 处理活动类型
    # 先提取英文部分
    english_type = re.findall(r'[a-zA-Z0-9]+', activity_type)
    if english_type:
        type_slug = ''.join(english_type).lower()
    else:
        # 纯中文或特殊字符，根据常见类型映射或生成 hash
        type_map = {
            '跑步': 'running',
            '跑步打卡': 'running',
            '读书': 'reading',
            '读书打卡': 'reading',
            '健身': 'workout',
            '运动': 'exercise',
            '学习': 'study',
            '早起': 'wakeup',
            '写作': 'writing',
            '英语': 'english',
        }
        type_slug = type_map.get(activity_type, f"act{transliterate_chinese(activity_type)}")
    
    # 2. 处理创建者ID
    creator_clean = re.sub(r'[^a-zA-Z0-9]+', '', creator_id)
    if not creator_clean:
        # 完全是非字母数字（如纯中文），生成 hash
        creator_slug = f"u{transliterate_chinese(creator_id)}"
    else:
        creator_slug = creator_clean.lower()
    
    # 3. 生成时间戳
    timestamp = int(time.time())
    
    # 4. 拼接 (v4: 移除群名前缀)
    activity_id = f"{type_slug}_{creator_slug}_{timestamp}"
    
    return activity_id


def parse_activity_id(activity_id):
    """
    解析活动 ID
    
    返回: (type, creator, timestamp) 或 None
    """
    parts = activity_id.split('_')
    if len(parts) != 3:
        return None
    
    try:
        timestamp = int(parts[-1])
        creator = parts[-2]
        activity_type = parts[0]
        
        return {
            "type": activity_type,
            "creator": creator,
            "timestamp": timestamp
        }
    except ValueError:
        return None


def main():
    parser = argparse.ArgumentParser(
        description="Generate activity ID for check-in activities (v4)"
    )
    parser.add_argument("--creator", help="Creator user ID or name")
    parser.add_argument("--type", help="Activity type (e.g., running, reading)")
    parser.add_argument("--validate", action="store_true", help="Validate an existing ID")
    parser.add_argument("--id", help="Activity ID to validate")
    
    args = parser.parse_args()
    
    # 验证模式
    if args.validate:
        if not args.id:
            parser.error("--validate requires --id")
        
        result = parse_activity_id(args.id)
        if result:
            print(f"✅ Valid activity ID")
            print(f"   Type: {result['type']}")
            print(f"   Creator: {result['creator']}")
            print(f"   Timestamp: {result['timestamp']} ({time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(result['timestamp']))})")
        else:
            print(f"❌ Invalid activity ID format", file=sys.stderr)
            sys.exit(1)
    else:
        # 生成模式
        if not all([args.creator, args.type]):
            parser.error("generation mode requires --creator and --type")
        
        activity_id = generate_activity_id(args.creator, args.type)
        print(activity_id)


if __name__ == "__main__":
    main()
