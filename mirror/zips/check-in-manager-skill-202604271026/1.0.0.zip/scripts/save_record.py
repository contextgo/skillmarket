#!/usr/bin/env python3
"""
保存打卡记录 (v7)

v7 更新：支持覆盖已存在的打卡记录（最新记录为准）
v6 更新：支持指定日期（--date），用于补录历史数据
v5 更新：区分发送者和打卡归属者，支持代打卡
v4 更新：支持群组级目录隔离
路径格式: records/{group_id}/{activity_id}/YYYY-MM-DD.json
"""
import json
import sys
import argparse
from pathlib import Path
from datetime import datetime


def save_record(args):
    skill_dir = Path(__file__).parent.parent
    
    # v4: 增加 group_id 层级
    records_dir = skill_dir / "records" / args.group_id / args.activity_id
    records_dir.mkdir(parents=True, exist_ok=True)
    
    # v6: 支持指定日期（补录历史数据）
    if args.date:
        # 验证日期格式
        try:
            datetime.strptime(args.date, "%Y-%m-%d")
            target_date = args.date
        except ValueError:
            print(f"错误: 日期格式不正确，应为 YYYY-MM-DD，如 2026-04-08", file=sys.stderr)
            sys.exit(1)
    else:
        target_date = datetime.now().strftime("%Y-%m-%d")
    
    record_file = records_dir / f"{target_date}.json"
    
    # 读取现有记录
    if record_file.exists():
        with open(record_file, "r", encoding="utf-8") as f:
            records = json.load(f)
    else:
        records = []
    
    # 解析打卡数据
    data = json.loads(args.data)
    
    # 判断是否为代打卡
    is_proxy = (args.sender_id != args.user_id)
    
    # v6: 支持自定义时间戳（补录历史数据时使用指定日期）
    if args.time:
        record_time = args.time
    else:
        # 使用目标日期 + 当前时间（用于补录时保持时序）
        current_time = datetime.now().strftime("%H:%M:%S")
        record_time = f"{target_date}T{current_time}+08:00"
    
    validation_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00")
    
    # v7: 检查是否已存在该用户的打卡记录
    existing_record_index = next(
        (i for i, r in enumerate(records) if r.get("user_id") == args.user_id),
        None
    )
    
    # 构建新记录条目 (v5: 区分 sender 和 user)
    new_record = {
        "sender_id": args.sender_id,
        "sender_name": args.sender_name,
        "user_id": args.user_id,
        "user_name": args.user_name,
        "is_proxy": is_proxy,
        "time": record_time,
        "data": data,
        "content": args.content or "",
        "valid": True,
        "validated_by": "ai_model",
        "validation_time": validation_time
    }
    
    # v7: 如果已存在，覆盖旧记录（最新记录为准）
    if existing_record_index is not None:
        old_record = records[existing_record_index]
        records[existing_record_index] = new_record
        print(f"⚠️  {args.user_name} 今日已有打卡记录，已覆盖为最新记录", file=sys.stderr)
        print(f"旧记录时间: {old_record.get('time')}", file=sys.stderr)
        print(f"旧记录内容: {json.dumps(old_record.get('data'), ensure_ascii=False)}", file=sys.stderr)
        print(f"新记录时间: {record_time}", file=sys.stderr)
        print(f"新记录内容: {json.dumps(data, ensure_ascii=False)}", file=sys.stderr)
        action = "updated"
    else:
        # 追加新记录
        records.append(new_record)
        action = "added"
    
    # 写入文件
    with open(record_file, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)
    
    print(f"记录已保存到: {record_file}")
    print(f"操作类型: {'覆盖已有记录' if action == 'updated' else '新增记录'}")
    if is_proxy:
        print(f"代打卡: {args.sender_name} 帮 {args.user_name} 打卡")
    print(f"目标日期: {target_date}")
    print(f"当前日期 {args.user_name} 打卡次数: {len([r for r in records if r.get('user_id') == args.user_id])}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Save check-in record (v7)")
    parser.add_argument("--group-id", required=True, help="Group ID (normalized chat_id)")
    parser.add_argument("--activity-id", required=True, help="Activity ID")
    parser.add_argument("--sender-id", required=True, help="Message sender ID (who sent the message)")
    parser.add_argument("--sender-name", required=True, help="Message sender display name")
    parser.add_argument("--user-id", required=True, help="Check-in owner ID (who gets the credit)")
    parser.add_argument("--user-name", required=True, help="Check-in owner display name")
    parser.add_argument("--data", required=True, help="Check-in data JSON")
    parser.add_argument("--content", default="", help="Original message content")
    parser.add_argument("--date", help="Target date (YYYY-MM-DD, default: today)")
    parser.add_argument("--time", help="Custom timestamp (ISO 8601, e.g. 2026-04-08T20:00:00+08:00)")
    
    args = parser.parse_args()
    save_record(args)
