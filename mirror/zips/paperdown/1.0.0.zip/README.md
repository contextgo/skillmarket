# Academic Natural Rewrite Skill

这是一个用于中文论文正文润色与重构的 Skill。

用途：
- 保持原意、术语、数据、引用不变；
- 优化句式、逻辑和自然度；
- 减少模板化表达；
- 控制修改前后字数基本一致；
- 不用于规避或保证任何 AIGC 检测结果。

主文件：`SKILL.md`
