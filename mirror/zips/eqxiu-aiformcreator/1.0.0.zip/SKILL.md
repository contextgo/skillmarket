---
name: eqxiu-aisigncreator
description: >-
  支持招聘报名、招生登记、体检预约、活动报名、志愿者招募、比赛报名等多场景。提供海量酷炫模板，全程免费使用，制作简单三步完成，数据实时统计，服务稳定可靠
---

# 易企秀 AI 报名

## 配置 Token

1. 打开 [易企秀 token 页](https://www.eqxiu.com/skillAccess/token) 取得 access-token。  
2. 写入 `~/.eqxiu/config.json`

```json
{"X-Openclaw-Token": "你的token"}
```

3. 可用 **`--config <路径>`** 指定其它配置文件（默认即为上述路径）。

## 全局选项

| 选项 | 说明 |
|------|------|
| `--config` | 配置文件路径，默认 `~/.eqxiu/config.json` |

## 子命令一览（与 `python3 scripts/baoming_cli.py --help` 一致）

| 子命令 | 作用 |
|--------|------|
| **`auth info`** | `GET …/user/info`；stdout 为账号 JSON；解析到 userId 时 stderr 提示一行。`--user-id-only` 则仅 stdout 输出一行 userId |
| **`auth status`** | `GET …/user/profile`；stdout 为接口 JSON；**仅当**响应为字典且 **`success is True`** 时退出码 0，否则 **1** |
| **`form-data`** | 表单填报列表；必填 `--id`；可选 `--start-time`、`--end-time`（默认空）、`--page-no`（默认 1）、`--page-size`（默认 10）、`--show-trash 0\|1`（默认 1） |
| **`pipeline`** | 端到端：search → ai → create → saveDesign → publish；必填 `--prompt`；可选 `--user-id`、`--channel`、`--biz-type`、`--apicode` |

说明：`create` / `pipeline` 未传 `--user-id` 时，行为与内部调用 **`auth info`** 的数据源一致（passport `/user/info`，解析 `obj.userScoreInfo.userId`）。

## 脚本复用

同一目录或已加入 `PYTHONPATH` 时，可 **`from baoming_cli import run_sign_pipeline`**，参数见源码（与 `pipeline` 子命令等价逻辑）。

## 帮助与示例

```bash
python3 scripts/baoming_cli.py --help
python3 scripts/baoming_cli.py <子命令> --help
python3 scripts/baoming_cli.py auth info --help
python3 scripts/baoming_cli.py auth status --help
```

```bash
python3 scripts/baoming_cli.py auth status
python3 scripts/baoming_cli.py auth info
python3 scripts/baoming_cli.py auth info --user-id-only

python3 scripts/baoming_cli.py pipeline --prompt "你的需求描述"

python3 scripts/baoming_cli.py form-data --id 20648261 --start-time "2026-05-05" --end-time "2026-05-06"
```

## 出问题先看什么

- **401 / 连接失败**：更新 token；确认网络与 `--config` 路径。  
- **业务 `success` 为 false**：核对 **`--product-code`** 是否与业务环境一致；其余字段以接口返回 JSON 为准。
