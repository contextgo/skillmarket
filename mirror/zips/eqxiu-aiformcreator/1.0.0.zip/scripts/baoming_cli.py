#!/usr/bin/env python3
"""
易企秀 AI 报名相关接口 CLI（不含 securityCheck）。

Token：~/.eqxiu/config.json → {"X-Openclaw-Token": "..."}
获取：https://www.eqxiu.com/skillAccess/token

userId：未传 --user-id 时会 GET passport …/user/info；也可手动执行 `auth info` / `auth info --user-id-only`。

流水线逻辑集中在 run_sign_pipeline() 与各 api_* / *_or_exit() 步骤函数中，
外部脚本可：from baoming_cli import run_sign_pipeline（须在同一目录或已加入 PYTHONPATH）。
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import urlencode

DEFAULT_CONFIG_PATH = Path.home() / ".eqxiu" / "config.json"
DEFAULT_SOURCE_FALLBACK = 20568050
DEFAULT_PRODUCT_CODE = "P010245"
DEFAULT_WORK_TYPE = "form_sign_skill"
DEFAULT_CHANNEL = 67
DEFAULT_BIZ_TYPE = 103
DEFAULT_AI_APICODE = "ele_gen_11"
SEARCH_APICODE = "43013"
COVER = "d26ed374-5176-4691-865d-5a8cc0b24c07.png"

URL_NEW_SEARCH = "https://m5.eqxiu.com/v1/search/sf/newSearch"
URL_AI_DO = "https://ai-api.eqxiu.com/ai-center/do"
URL_LONGPAGE_CREATE = "https://m6.eqxiu.com/editor/longpage/create"
URL_PASSPORT_USER_INFO = "https://passport.eqxiu.com/user/info"
URL_PASSPORT_USER_PROFILE = "https://passport.eqxiu.com/user/profile"
URL_FORM_DATA_LIST = "https://form-editor-api.eqxiu.com/m/lp/data/list"
# 发布后外链：https://form.ebdan.net/ls/<worksCode>
FORM_LS_PUBLIC_BASE = "https://form.ebdan.net/ls/"


def load_token(config_path: Path) -> str:
    if not config_path.is_file():
        raise FileNotFoundError(
            f"未找到配置文件: {config_path}\n"
            "请从 https://www.eqxiu.com/skillAccess/token 获取 token，并写入:\n"
            '{"X-Openclaw-Token": "你的token"}'
        )
    with config_path.open(encoding="utf-8") as f:
        data = json.load(f)
    token = data.get("X-Openclaw-Token")
    if not token:
        raise KeyError(f'{config_path} 中缺少 "X-Openclaw-Token"')
    return str(token)


def build_passport_headers(token: str) -> dict[str, str]:
    """与 curl 一致：仅携带 Token（GET，无 JSON body）。"""
    return {
        "Accept": "application/json",
        "X-Openclaw-Token": token,
    }


def build_headers(
    token: str,
    *,
    product_code: str | None = None,
) -> dict[str, str]:
    h: dict[str, str] = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Openclaw-Token": token,
    }
    if product_code:
        # 与前端 request 封装一致，名称按网关实际要求可调整
        h["productCode"] = product_code
    return h


def http_json(
    method: str,
    url: str,
    *,
    headers: Mapping[str, str],
    body: Any | None = None,
    timeout: float = 60.0,
) -> Any:
    data = None
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method, headers=dict(headers))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {e.code} {e.reason}\n{err_body}") from e
    except urllib.error.URLError as e:
        raise SystemExit(f"请求失败: {e.reason}") from e
    if not raw.strip():
        return None
    return json.loads(raw)


def public_form_url(works_code: str | None) -> str | None:
    if works_code is None or not str(works_code).strip():
        return None
    return f"{FORM_LS_PUBLIC_BASE}{str(works_code).strip()}"


def get_longpage_publish(
    token: str,
    *,
    product_code: str | None,
    works_id: Any,
) -> Any:
    """POST m6 …/editor/longpage/publish/{worksId}，与 saveDesign 相同 JSON 头。"""
    wid = str(works_id).strip()
    url = f"https://m6.eqxiu.com/editor/longpage/publish/{wid}"
    headers = build_headers(token, product_code=product_code or None)
    return http_json("GET", url, headers=headers, body={})


def post_longpage_create(
    token: str,
    *,
    product_code: str | None,
    payload: Mapping[str, Any],
    timeout: float = 60.0,
) -> Any:
    """
    POST m6 …/editor/longpage/create

    `create` 仅传 `data` + `productCode`，**没有** `sendJSON: '1'`，
    前端封装一般为 `application/x-www-form-urlencoded`，不要用 JSON body。
    """
    form: dict[str, str] = {
        "channel": str(payload["channel"]),
        "bizType": str(payload["bizType"]),
        "title": str(payload["title"]),
        "userId": str(payload["userId"]),
        "workType": str(payload["workType"]),
        "cover": str(payload["cover"]),
    }
    headers: dict[str, str] = {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Accept": "application/json",
        "X-Openclaw-Token": token,
    }
    if product_code:
        form["productCode"] = str(product_code)
        headers["productCode"] = str(product_code)
    data = urlencode(form).encode("utf-8")
    req = urllib.request.Request(
        URL_LONGPAGE_CREATE, data=data, method="POST", headers=headers
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {e.code} {e.reason}\n{err_body}") from e
    except urllib.error.URLError as e:
        raise SystemExit(f"请求失败: {e.reason}") from e
    if not raw.strip():
        return None
    return json.loads(raw)


def fetch_user_info(token: str) -> Any:
    """GET https://passport.eqxiu.com/user/info，请求头仅 X-Openclaw-Token。"""
    return http_json(
        "GET",
        URL_PASSPORT_USER_INFO,
        headers=build_passport_headers(token),
    )


def parse_user_id_from_user_info(res: Any) -> str | None:
    """
    从 /user/info 响应中取业务 userId。
    典型路径：obj.userScoreInfo.userId（见 passport 返回）。
    """
    if not isinstance(res, dict) or not res.get("success"):
        return None
    obj = res.get("obj")
    if not isinstance(obj, dict):
        return None
    usi = obj.get("userScoreInfo")
    if isinstance(usi, dict):
        uid = usi.get("userId")
        if uid is not None and str(uid).strip():
            return str(uid).strip()
    for key in ("userId", "id"):
        v = obj.get(key)
        if v is not None and str(v).strip():
            return str(v).strip()
    return None


def resolve_user_id(token: str, explicit: str | None) -> str:
    """显式传入优先；否则请求 passport /user/info。"""
    if explicit is not None and str(explicit).strip():
        return str(explicit).strip()
    info = fetch_user_info(token)
    uid = parse_user_id_from_user_info(info)
    if not uid:
        print(json.dumps(info, ensure_ascii=False, indent=2))
        raise SystemExit(
            "无法从 /user/info 解析 userId（期望 obj.userScoreInfo.userId）。"
            "请检查 token 或手动传入 --user-id。"
        )
    return uid


# --- 流水线与各子命令共用的 API 步骤（避免在 cmd_pipeline 里重复拼接请求）---


def build_create_payload(
    user_id: str,
    *,
    channel: int,
    biz_type: int,
    title: str,
) -> dict[str, Any]:
    return {
        "channel": channel,
        "bizType": biz_type,
        "title": title,
        "userId": user_id,
        "workType": DEFAULT_WORK_TYPE,
        "cover": COVER,
    }


def api_search_template(
    token: str,
    product_code: str | None,
    keyword: str,
    *,
    page_size: int = 1,
) -> tuple[Any, int]:
    """模板搜索；返回 (完整响应, source_id)，无结果时 source_id 为兜底值。"""
    headers = build_headers(token, product_code=product_code)
    payload = {
        "apicode": SEARCH_APICODE,
        "filters": [],
        "orders": [],
        "keyword": keyword,
        "pageNo": 1,
        "pageSize": page_size,
    }
    search_res = http_json("POST", URL_NEW_SEARCH, headers=headers, body=payload)
    source_id = DEFAULT_SOURCE_FALLBACK
    if (
        isinstance(search_res, dict)
        and search_res.get("success")
        and search_res.get("list")
    ):
        source_id = search_res["list"][0].get("source_id") or source_id
    return search_res, source_id


def api_ai_do_raw(
    token: str,
    product_code: str | None,
    apicode: str,
    prompt: str,
) -> Any:
    headers = build_headers(token, product_code=product_code)
    return http_json(
        "POST",
        URL_AI_DO,
        headers=headers,
        body={"apicode": apicode, "prompt": prompt},
    )


def api_ai_sign_sanitized_or_exit(
    token: str,
    product_code: str | None,
    apicode: str,
    prompt: str,
) -> dict[str, Any]:
    """AI 生成报名表并做 sanitize；失败则打印响应并以 SystemExit 结束。"""
    ai_res = api_ai_do_raw(token, product_code, apicode, prompt)
    if not (isinstance(ai_res, dict) and ai_res.get("success") and ai_res.get("data")):
        print(json.dumps(ai_res, ensure_ascii=False, indent=2))
        raise SystemExit("AI 生成未返回 success/data")
    return sanitize_ai_content(dict(ai_res["data"]))


def create_sign_work_or_exit(
    token: str,
    product_code: str | None,
    payload: Mapping[str, Any],
) -> tuple[Any, Any, dict[str, Any]]:
    """
    创建表单作品。返回 (works_id, works_code, create_res)；
    create_res 为完整响应字典（失败时已打印并 SystemExit）。
    """
    create_res = post_longpage_create(
        token, product_code=product_code, payload=payload
    )
    if not (isinstance(create_res, dict) and create_res.get("success")):
        print(json.dumps(create_res, ensure_ascii=False, indent=2))
        raise SystemExit("创建作品失败")
    works_id = create_res.get("obj")
    form_map = create_res.get("map") or {}
    form = form_map.get("form") or {}
    works_code = form.get("code")
    return works_id, works_code, create_res


def save_design_url(source_id: int) -> str:
    q = urlencode({"sourceId": str(source_id), "workType": DEFAULT_WORK_TYPE})
    return f"https://m6.eqxiu.com/editor/longpage/ai/saveDesign?{q}"


def save_sign_design_or_exit(
    token: str,
    product_code: str | None,
    source_id: int,
    ai_content: Mapping[str, Any],
) -> Any:
    url = save_design_url(source_id)
    headers = build_headers(token, product_code=product_code)
    save_res = http_json("POST", url, headers=headers, body=dict(ai_content))
    if not (isinstance(save_res, dict) and save_res.get("success")):
        print(json.dumps(save_res, ensure_ascii=False, indent=2))
        raise SystemExit("保存设计失败")
    return save_res


def publish_work_or_exit(
    token: str,
    product_code: str | None,
    works_id: Any,
) -> Any:
    publish_res = get_longpage_publish(
        token, product_code=product_code, works_id=works_id
    )
    if not (isinstance(publish_res, dict) and publish_res.get("success")):
        print(json.dumps(publish_res, ensure_ascii=False, indent=2))
        raise SystemExit("发布作品失败")
    return publish_res


def run_sign_pipeline(
    *,
    token: str,
    product_code: str | None,
    user_id: str,
    prompt: str,
    apicode: str,
    channel: int,
    biz_type: int,
) -> dict[str, Any]:
    """
    端到端：搜模板 → AI → 创建 → 保存 → 发布。
    供 cmd_pipeline 与外部脚本 `from baoming_cli import run_sign_pipeline` 复用。
    """
    _, source_id = api_search_template(
        token, product_code, prompt, page_size=1
    )
    ai_content = api_ai_sign_sanitized_or_exit(
        token, product_code, apicode, prompt
    )
    ai_content["userId"] = user_id

    create_payload = build_create_payload(
        user_id,
        channel=channel,
        biz_type=biz_type,
        title=str(ai_content.get("title") or "未命名报名"),
    )
    works_id, works_code, _create_res = create_sign_work_or_exit(
        token, product_code, create_payload
    )
    ai_content["worksId"] = works_id
    ai_content["worksCode"] = works_code

    save_res = save_sign_design_or_exit(
        token, product_code, source_id, ai_content
    )
    publish_res = publish_work_or_exit(token, product_code, works_id)
    public_url = public_form_url(str(works_code) if works_code is not None else None)
    return {
        "sourceId": source_id,
        "worksId": works_id,
        "worksCode": works_code,
        "save": save_res,
        "publish": publish_res,
        "publicFormUrl": public_url,
    }

def sanitize_ai_content(ai: dict[str, Any]) -> dict[str, Any]:
    out = dict(ai)
    completion = out.get("completionQuestion") or []
    completion_question_list: list[str] = []
    for s in completion:
        str_s = str(s)
        str_s = re.sub(r"【[^】]+】", "", str_s)
        str_s = re.sub(r"_{2,}", "", str_s)
        str_s = str_s.replace("：", "")
        str_s = " ".join(str_s.split())
        completion_question_list.append(str_s)

    drop_down = list(out.get("dropDownQuestion") or [])
    drop_down_question_list: list[Any] = []
    for item in drop_down:
        if isinstance(item, dict):
            title = str(item.get("title", ""))
            if "电话" in title or "手机" in title:
                completion_question_list.append(title)
            else:
                drop_down_question_list.append(item)
        else:
            drop_down_question_list.append(item)
    out["dropDownQuestion"] = drop_down_question_list
    out["completionQuestion"] = completion_question_list
    return out

def cmd_pipeline(args: argparse.Namespace) -> None:
    token = load_token(Path(args.config))
    user_id = resolve_user_id(token, args.user_id)
    out = run_sign_pipeline(
        token=token,
        product_code=args.product_code or None,
        user_id=user_id,
        prompt=args.prompt,
        apicode=args.apicode,
        channel=args.channel,
        biz_type=args.biz_type,
    )
    print(json.dumps(out, ensure_ascii=False, indent=2))



def cmd_form_data(args: argparse.Namespace) -> None:
    """表单填报数据列表：POST form-editor-api …/m/lp/data/list"""
    token = load_token(Path(args.config))
    headers = build_headers(token, product_code=args.product_code)
    payload: dict[str, Any] = {
        "id": str(args.id),
        "startTime": args.start_time,
        "endTime": args.end_time,
        "pageNo": args.page_no,
        "pageSize": args.page_size,
        "time": int(time.time() * 1000),
        "showTrash": args.show_trash,
    }
    res = http_json("POST", URL_FORM_DATA_LIST, headers=headers, body=payload)
    print(json.dumps(res, ensure_ascii=False, indent=2))


def cmd_auth_status(args: argparse.Namespace) -> None:
    """GET passport …/user/profile，用于判断当前配置文件中的 token 是否可用。"""
    token = load_token(Path(args.config))
    res = http_json(
        "GET",
        URL_PASSPORT_USER_PROFILE,
        headers=build_passport_headers(token),
    )
    print(json.dumps(res, ensure_ascii=False, indent=2))
    if isinstance(res, dict) and res.get("success") is True:
        return
    raise SystemExit(1)


def cmd_auth_info(args: argparse.Namespace) -> None:
    """GET passport …/user/info，查看账号信息并解析 userId（与 resolve_user_id 数据来源一致）。"""
    token = load_token(Path(args.config))
    res = fetch_user_info(token)
    if args.user_id_only:
        uid = parse_user_id_from_user_info(res)
        if not uid:
            print(json.dumps(res, ensure_ascii=False, indent=2))
            raise SystemExit("无法解析 userId")
        return
    print(json.dumps(res, ensure_ascii=False, indent=2))
    # uid = parse_user_id_from_user_info(res)
    # if uid:
    #     print(f"\nuserId: {uid}", file=sys.stderr)


def main() -> None:
    parser = argparse.ArgumentParser(description="易企秀 AI 报名 API CLI")
    parser.add_argument(
        "--config",
        default=str(DEFAULT_CONFIG_PATH),
        help=f"配置文件路径（默认: {DEFAULT_CONFIG_PATH}）",
    )
    parser.add_argument(
        "--product-code",
        default=os.environ.get("EQXIU_PRODUCT_CODE", DEFAULT_PRODUCT_CODE),
        help=f"可选，随请求传递 productCode（默认: {DEFAULT_PRODUCT_CODE}）",
    )

    sub = parser.add_subparsers(dest="cmd", required=True)

    p_auth = sub.add_parser("auth", help="鉴权：token 校验与用户信息服务")
    auth_sub = p_auth.add_subparsers(dest="auth_cmd", required=True)
    p_auth_info = auth_sub.add_parser(
        "info",
        help="GET passport …/user/info（可加 --user-id-only 只输出一行 userId）",
    )
    p_auth_info.add_argument(
        "--user-id-only",
        action="store_true",
        help="仅 stdout 打印解析到的 userId",
    )
    p_auth_info.set_defaults(func=cmd_auth_info)

    p_auth_status = auth_sub.add_parser(
        "status",
        help="GET passport …/user/profile，检查 config 中 token 是否有效（失败时退出码 1）",
    )
    p_auth_status.set_defaults(func=cmd_auth_status)

    p_form = sub.add_parser(
        "form-data",
        help="查看表单填报数据 POST form-editor-api …/m/lp/data/list",
    )
    p_form.add_argument(
        "--id",
        required=True,
        help="作品/表单 id（与 pipeline 返回的 worksId 等一致，多为数字字符串）",
    )
    p_form.add_argument("--start-time", default="", help="筛选开始时间，默认空")
    p_form.add_argument("--end-time", default="", help="筛选结束时间，默认空")
    p_form.add_argument("--page-no", type=int, default=1)
    p_form.add_argument("--page-size", type=int, default=10)
    p_form.add_argument(
        "--show-trash",
        type=int,
        default=1,
        choices=(0, 1),
        help="是否包含回收站等，默认 1（与常见前端一致）",
    )
    p_form.set_defaults(func=cmd_form_data)

    p_pipe = sub.add_parser(
        "pipeline",
        help="一条龙：search → ai → create → saveDesign → publish",
    )
    p_pipe.add_argument("--prompt", required=True)
    p_pipe.add_argument(
        "--user-id",
        default=None,
        help="不传则从 passport /user/info 取 obj.userScoreInfo.userId",
    )
    p_pipe.add_argument("--channel", type=int, default=DEFAULT_CHANNEL)
    p_pipe.add_argument("--biz-type", type=int, default=DEFAULT_BIZ_TYPE)
    p_pipe.add_argument("--apicode", default=DEFAULT_AI_APICODE)
    p_pipe.set_defaults(func=cmd_pipeline)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
