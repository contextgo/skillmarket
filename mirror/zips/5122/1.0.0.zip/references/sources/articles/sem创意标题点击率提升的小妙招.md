     sem创意标题点击率提升的小妙招 \* { margin: 0; padding: 0; outline: 0; } body { font-family: "PingFang SC", system-ui, -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Hiragino Sans GB", "Microsoft YaHei UI", "Microsoft YaHei", Arial, sans-serif; line-height: 1.6; } .\_\_page\_content\_\_ { max-width: 667px; margin: 0 auto; padding: 20px; text-size-adjust: 100%; color: rgba(0, 0, 0, 0.9); padding-bottom: 64px; } .title { user-select: text; font-size: 22px; line-height: 1.4; margin-bottom: 14px; font-weight: 500; } .\_\_meta\_\_ { color: rgba(0, 0, 0, 0.3); font-size: 15px; line-height: 20px; hyphens: auto; word-break: break-word; margin-bottom: 50px; } .\_\_meta\_\_ .nick\_name { color: #576B95; } .\_\_meta\_\_ .copyright { color: rgba(0, 0, 0, 0.3); background-color: rgba(0, 0, 0, 0.05); padding: 0 4px; margin: 0 10px 10px 0; } blockquote.source { padding: 10px; margin: 30px 0; border-left: 5px solid #ccc; color: #333; font-style: italic; word-wrap: break-word; } blockquote.source a { cursor: pointer; text-decoration: underline; } .item\_show\_type\_0 > section { margin-top: 0; margin-bottom: 24px; } a { color: #576B95; text-decoration: none; cursor: default; } .text\_content { margin-bottom: 50px; user-select: text; font-size: 17px; white-space: pre-wrap; word-wrap: break-word; line-height: 28px; hyphens: auto; } .picture\_content .picture\_item { margin-bottom: 30px; } .picture\_content .picture\_item .picture\_item\_label { text-align: center; } img { max-width: 100%; } .pay\_subscribe\_notice { margin: 30px 0; padding: 20px; background: #fffbe6; border: 1px solid #ffe58f; border-radius: 8px; } .pay\_subscribe\_badge { display: inline-block; padding: 4px 12px; background: #faad14; color: #fff; border-radius: 4px; font-size: 14px; font-weight: 500; margin-bottom: 12px; } .pay\_subscribe\_desc { font-size: 15px; line-height: 1.8; color: rgba(0, 0, 0, 0.7); margin-bottom: 12px; } .pay\_subscribe\_hint { font-size: 13px; color: rgba(0, 0, 0, 0.4); } .\_\_bottom-bar\_\_ { display: flex; justify-content: space-between; align-items: center; position: fixed; bottom: 0; left: 0; right: 0; height: 64px; padding: 8px 20px; background: white; box-sizing: border-box; border-top: 1px solid rgba(0, 0, 0, 0.2); } .\_\_bottom-bar\_\_ .left { display: flex; align-items: center; font-size: 15px; white-space: nowrap; } .\_\_bottom-bar\_\_ .right { display: flex; } .\_\_bottom-bar\_\_ .sns\_opr\_btn { display: flex; align-items: center; user-select: none; background: transparent; border: 0; color: rgba(0, 0, 0, 0.9); font-size: 14px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn:not(:last-child) { margin-right: 16px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn > img { margin-right: 4px; }

sem创意标题点击率提升的小妙招
================

原创 o君言o 君言戏语 2022-05-12 13:30 福建

> 原文地址: [https://mp.weixin.qq.com/s/cnML-5\_T2pfrsrXIB-uMxQ](https://mp.weixin.qq.com/s/cnML-5_T2pfrsrXIB-uMxQ)

问题
--

说到提升竞价创意点击率，你能想到哪些方式？

比如常见的有：提升排名、调整关键词相关性、优化标题等等！

这其中，提升排名有简单粗暴的方式：提高出价，而关键词相关性则可以通过类似否词这些手段来删减相关性低的关键词进而提升账户整体质量。

这都是有迹可循的明确手段！

  

可是标题呢？优化标题这四个字说起来容易，但好像没有具体步骤，网上一搜我们可以找到很多建议，可以确切落地的方式比如：

多使用数字、或者早前会有人叠加一些醒目符号等等吸睛手段！

这些手段相对初级，使用起来较为“便宜”，刚入行的SEMer都明白，属于没有竞争力的手段，不稀奇。

  

因此，本文尝试分享一种提升标题点击率的小技巧，这种技巧特别在一些传统行业里效果非常明显。

同时，这种技巧本质也适用于某一类问题，即：

**当我们在谈论XX时，我们在谈论什么？**

思考
--

当我们想要找人开发一个网站，在搜索引擎搜索“北京网站建设费用”时，我们本质上关心的是什么？

编程技术就好像医疗技术一样，是一种绝对的门槛，它不是外行人凭常识可以搞定的，这就会带来绝对的信息差。

我说建个网站多少钱那就得是多少钱，我说这个涉及的技术有多复杂那就是有多复杂，外行人是没办法质疑的。

而正因为我们的“无知”，当我们作为外行人去寻找内行服务商的时候，我们会额外关心费用，这里的费用还并非是绝对意义上的数值。

因为我们不懂，所以我们**特别怕他乱收费**，如果他能给我一个价格清单就好了，如果他能再给我一个收费明细就更好了。

当然了，如果这个行业有清晰的收费标准那就最好了，我就不必担心被宰了，这才是一个目标客户关于费用最直接的诉求！

所以，当客户在谈论费用时，**很多时候他关心的是你有没有在宰他！**

当一个精准客户在搜索目标广告时(很多传统行业的客户在搜索时就是要找广告)，**如果标题能明确包含他在意的点**，那么点击率就会大大增加。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMVMvjePichSCGm7l352th1zesU0ibRE6bZ0ukG1CSHUrhbIrdACKibwx86g/640?wx_fmt=png)

因此提升标题点击率的一个重点是：

**标题尽可能提到用户确**切**在意的点！**

  

迄今为止，传统搜索引擎已经升级演变了几代，从最开始的分类目录形式到现在基于用户行为的第四代搜索，可以说：搜索引擎一定是越来越智能的。

可是我们会发现，即使是今天如百度谷歌这样先进的搜索引擎，依然保留“飘红”这样一个很基础的产品功能：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMVsgqx3xPvcibO76oHkfTquvstj3ZbKROuBfXYIS4d01drrbeDwOAiblFw/640?wx_fmt=png)

搜索结果飘红

按道理，搜索系统随着累积的用户数据越来越多，它能分析的用户行为就越多，一个功能是保留还是优化掉，答案是很容易计算出来的。

所以很显然，**飘红的作用极其重要**，有无飘红造成的点击率差别是巨大的。

从常识的角度来看，**飘红可以以最低的成本帮助用户做选择**，在其他条件差别不大的情况下，**更红就更相关**，这很直观！

正常人在使用搜索的时候都会有这种**下意识**的“认知”。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMVonkTJIHHxq1EDicZ8fKo6LYRetkPeJ5MKMO9XOVTUK7q5HAcibmSOOxg/640?wx_fmt=png)

因此提升标题点击率的另一个重点是：

**在保证自然通顺的前提下使飘红尽可能多！**

统计
--

了解了提升标题点击率的两个重点之后，我们只需要做一件事：找出用户关于某个问题--**实际在意的点有哪些**。

这些点都罗列出来之后，就可以融入标题里，同时飘红的比例也就增加了。

  

那么用户关于某个问题，实际在意的点有哪些？**这样一个问题有时候就连用户自己也是说不清的**。

做付费投放，好的效果要靠细节上的优化，但优化并不能拍脑袋，一定是基于数据的。

事实上搜索引擎有两个版块刚好可以解决这个问题：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMVM6LIvvAwJfQF81IKlOUuiadpTxqAhmFlejic3ITh4PlAUcB9tZe8HW3A/640?wx_fmt=png)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMVWd8HT0so7PibfFk1J960BZeDEDWvqwxaU17mEuhszDvSXscibMMh2T6w/640?wx_fmt=png)

<<< 左右滑动见更多 >>>

就是“其他人在搜”和“相关搜索”！

  

这两个版块我在过往文章已经针对性的聊过几次了！

为什么搜索引擎会向用户提供一些推荐搜索的长尾词？就是因为有很多用户其实自己也不知道应该搜索啥，确切的说是不知道如何键入正确的搜索词来寻找到自己的目标。

但总会有一些人知道，他们很懂得怎么搜索，知道键入什么样的搜索词更合适找到答案。

因此搜索引擎可以反反复复的做记录和统计，长尾词a和长尾词b类似，**用户经常搜索长尾词a后又搜索长尾词b，搜索长尾词b后点开某个结果就不再搜索了**，那么很显然：长尾词b可以找到答案。

这样的数据被记录多了之后，当有用户再搜索长尾词a时，搜索引擎就自然懂得向ta推荐长尾词b了，**因为长尾词b大概率可以解决搜索长尾词a的用户的需求**。

当用户在搜索长尾词a时，**实际上它想要(应该)搜索长尾词b**，这个逻辑是不是很熟悉？

  

逻辑知道后，具体怎么做？在这里我们以传统服务“代理记账”这样一个行业来说明步骤：

### 步骤1 循环挖掘推荐词

以“代理记账”作为最开始的母词，循环收集其在搜索结果中的推荐词。

将“代理记账”拿到搜索引擎中搜索，我们会在搜索结果中得到“其他人在搜”和“相关推荐”的内容。

提取里面的长尾词(只保留包含代理 记账 或 代账的长尾词)，加入搜索词队列，把得到的每一个长尾词作为新的母词继续搜索，以此循环。

在这个过程中至少需要保留这样一份数据：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMVotQ1iczAdqv1GrqQG8G5DLGXJG5DBKXyibAkXqehicQTViayDscpphrX5w/640?wx_fmt=png)

对于每一个挖掘到的长尾词，都应该记录它的父词，即：通过搜索哪个词才得到这个长尾词的，那个词就是这个长尾词的父词。

很显然：一个长尾词会有很多父词，**有些长尾词会有非常多的父词**。

当然我们还可以记录这个长尾词最开始的母词、这个长尾词是属于“其他人在搜”还是“相关搜索”，以及长尾词对应的快照链接(href)。

循环挖掘直到搜索词队列不再有新的词、所有词都搜索过一次了为止。

由于这种策略的目标在于统计一个相对值，因此我只收集了1W左右的长尾词数据作为演示(数据收集越多，统计结果越接近)：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMVrlYtCVwNf3X0hQ3ib4GqibfDdEsaCfJ4clagVGWP9lT4qVdTvMoPpicaQ/640?wx_fmt=png)

### 步骤2 选择有商业价值的高频需求

做竞价，肯定是首先考虑需求有没有商业价值！

在我收集的1万个推荐词里，TOP50的词频为：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMV0e8uMQsG838Xia2B5bfqOJj91thBiaFTR68IYgqgbcHOtgy1ePh46zUA/640?wx_fmt=png)

这其中，“收费”是一个明显有商业价值的词汇，一个在询问费用的客户是非常精准的。

“收费”的词频高说明包含它的长尾词多，如果这一个个包含“收费”的长尾词作为父词的话，那么它们会带出什么推荐词来？

### 步骤3 统计高频关联词缀

这个答案在刚才我们保存的父子关系数据里就可以得到了，把所有父词包含“收费”的推荐词都提取出来：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMVHq5AHNIaZEvEbiayrL5kN3icuGVJgrVPclhFx24ELiaGQun73uz5icCKAA/640?wx_fmt=png)

然后再计算这批推荐词的高频词缀：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMVsEg1bUxSnyRwDwHgCl51y0cspibEzxZpmEtFkA6o7jA4ON1FhUOicL6w/640?wx_fmt=png)

结果显而易见：除去“代理、记账、代账、公司”这些以外，最高的词频包含着：“标准”、“价目表”、“明细”、“项目(收费项)”等等这些与“收费”高度相关的词缀。

这些是搜索引擎给出的与“收费”有关的长尾词的搜索推荐，应该没有什么数据能比搜索引擎的推荐更准确了，它们可以代表用户关于“收费”所在意的具体点。

有了这些词缀之后，接下去就好办了，只需要把这些词缀融入到与“收费”有关的长尾词的单元对应的创意即可。

如果客户搜索与“收费”相关的长尾词，但没有包含这些词缀，那么创意标题里提到的这些词缀是他在意的点，可以促进ta的点击，如果客户搜索与“收费”相关的长尾词同时包含这些词缀，那么飘红又增加了。

当然这些词缀也可以融入到描述里，如果效果好，甚至可以醒目的写到创意图片上。

事实上，我把一批“代理记账”包含“收费”的长尾词拿到搜索引擎里收集了几百个创意标题，统计了一下有包含这些重要词缀的标题的比例，仅有20%：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLnnBfAeKfcg6FZSeqibutMVbdPMiaj0JciaFWeKeAnM7aj9u2HhJuta8TrDqryRZWNMQic11y645wKcQ/640?wx_fmt=png)

  

一般竞价专员在文案撰写上都没有什么灵感，经常是同行之间互相抄来抄去，使用这种方式还可以解决竞价人员硬着头皮写标题的问题。

当我们利用脚本按照不同维度自动分类出几十个甚至更多的单元时，由于词缀不同，创意标题都要有些差别，这些挖掘出来的关联词缀可以很自然的补充，不用不同单元的创意几小时憋出几个字。

延伸
--

我们在开头有说过，这个策略还可以解决：当我们在谈论XX时，我们在讨论什么 的问题！

所以这种方式不止可以用于竞价，还可以用于自媒体标题党(轻度)上。

用户关注某个领域的内容，ta有具体在意的点，也许我们去深度挖掘一些细分领域的问题，把提取出来的词缀、描述融入到标题里，可能会带来不错的效果。

不论是个人常识、过往经验、大咖分享、课程学习等，关于“写出一个优秀标题”的理论，其中一定会有一点：标题要与目标用户有关。

标题需要让目标用户认为这个内容跟ta有确切关系！

那么写上用户心里在意的点或者在意但却没发现的点，效果应该不错。

结语
--

延伸出来的思路我没有试过这些方面的运用，专门研究标题 这在推荐算法的平台上可能效果会不错，但是做自媒体过渡依赖标题可能会有问题，这涉及选择。

不过竞价上倒不必担心这些问题，为什么我会举“代理记账”这样一个例子？

这种技巧我不好说是不是适用于全行业，但是在传统行业的竞价竞争上效果是会不错的。

首先传统行业的服务大部分都很直接，比如和“代理记账”相关的一个服务是“公司注销”，这样一个服务它是有标准化的流程和结果的。

等待相关部门审核的周期要多久就是多久，你没办法比同行更快，大家做到最后的结果就是成功把资质注销掉，结果都是一个。

对于正准备把一个资质注销的客户来说，选择本地哪一家企业，都是差不多的，这样一个有需求的本地客户只要点进来广告页面，大概率都能留下联系方式。

竞价在某种程度还是硬广，**打广告的人直接，搜广告的人也直接**，我们要做的就是增加精准客户进来的概率，并引导其留下联系方式，接下去就跟竞价无关了。

其次传统行业的竞价账户往往做得很差，大概率老板是不舍得高价请一个竞价负责人的，顶多是一个优化专员。

而更多情况是把账户交给运营商的客服打理，对于预算一天五百以下的账户基本是交给一个人打理几十个账户的客服。

那么ta能做的就是打开关键词工具拓展一批有商业价值的词，大致划分下单元，复制几个创意就上了。

对于这样的竞争对手，**你只需要稍微做得比他们专业一点即可**。

  

思路希望对你有启发，但不保证会有确切效果，sem和seo属于动态竞争游戏，所以当你对点击率不满意时，可以考虑优化看看。

本文结束！

  

![](http://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLbYm2TI7kiameic7QEzKqbsk6jyHS4XpzpdnBgLOZOYzLO1eBLLOEN0CK2IJjjegG2kT7GRf7uZOnA/0?wx_fmt=png) 君言戏语

 ![](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3C!-- Icon from Lucide by Lucide Contributors - https://github.com/lucide-icons/lucide/blob/main/LICENSE --%3E%3Cg fill='none' stroke='%23888888' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'%3E%3Cpath d='M2.062 12.348a1 1 0 0 1 0-.696a10.75 10.75 0 0 1 19.876 0a1 1 0 0 1 0 .696a10.75 10.75 0 0 1-19.876 0'/%3E%3Ccircle cx='12' cy='12' r='3'/%3E%3C/g%3E%3C/svg%3E) 阅读![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M16.154 6.797l-.177 2.758h4.009c1.346 0 2.359 1.385 2.155 2.763l-.026.148-1.429 6.743c-.212.993-1.02 1.713-1.977 1.783l-.152.006-13.707-.006c-.553 0-1-.448-1-1v-8.58a1 1 0 0 1 1-1h2.44l1.263-.03.417-.018.168-.015.028-.005c1.355-.315 2.39-2.406 2.58-4.276l.01-.16.022-.572.022-.276c.074-.707.3-1.54 1.08-1.883 2.054-.9 3.387 1.835 3.274 3.62zm-2.791-2.52c-.16.07-.282.294-.345.713l-.022.167-.019.224-.023.604-.014.204c-.253 2.486-1.615 4.885-3.502 5.324l-.097.018-.204.023-.181.012-.256.01v8.218l9.813.004.11-.003c.381-.028.72-.304.855-.709l.034-.125 1.422-6.708.02-.11c.099-.668-.354-1.308-.87-1.381l-.098-.007h-5.289l.26-4.033c.09-1.449-.864-2.766-1.594-2.446zM7.5 11.606l-.21.005-2.241-.001v8.181l2.45.001v-8.186z' fill='%23000'/%3E%3C/svg%3E) 赞 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cpath d='M0 0h24v24H0z'/%3E    %3Cpath fill='%23576B95' d='M13.707 3.288l7.171 7.103a1 1 0 0 1 .09 1.32l-.09.1-7.17 7.104a1 1 0 0 1-1.705-.71v-3.283c-2.338.188-5.752 1.57-7.527 5.9-.295.72-1.02.713-1.177-.22-1.246-7.38 2.952-12.387 8.704-13.294v-3.31a1 1 0 0 1 1.704-.71zm-.504 5.046l-1.013.16c-4.825.76-7.976 4.52-7.907 9.759l.007.287c1.594-2.613 4.268-4.45 7.332-4.787l1.581-.132v4.103l6.688-6.623-6.688-6.623v3.856z'/%3E  %3C/g%3E%3C/svg%3E) 分享 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cdefs%3E    %3Cpath id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-a' d='M0 0h24v24H0z'/%3E  %3C/defs%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cmask id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-b' fill='%23fff'%3E      %3Cuse xlink:href='%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-a'/%3E    %3C/mask%3E    %3Cg mask='url(%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-b)'%3E      %3Cg transform='translate(0 -2.349)'%3E        %3Cpath d='M0 2.349h24v24H0z'/%3E        %3Cpath fill='%23576B95' d='M16.45 7.68c-.954 0-1.94.362-2.77 1.113l-1.676 1.676-1.853-1.838a3.787 3.787 0 0 0-2.63-.971 3.785 3.785 0 0 0-2.596 1.112 3.786 3.786 0 0 0-1.113 2.687c0 .97.368 1.938 1.105 2.679l7.082 6.527 7.226-6.678a3.787 3.787 0 0 0 .962-2.618 3.785 3.785 0 0 0-1.112-2.597A3.687 3.687 0 0 0 16.45 7.68zm3.473.243a4.985 4.985 0 0 1 1.464 3.418 4.98 4.98 0 0 1-1.29 3.47l-.017.02-7.47 6.903a.9.9 0 0 1-1.22 0l-7.305-6.73-.008-.01a4.986 4.986 0 0 1-1.465-3.535c0-1.279.488-2.56 1.465-3.536A4.985 4.985 0 0 1 7.494 6.46c1.24-.029 2.49.4 3.472 1.29l.01.01L12 8.774l.851-.85.01-.01c1.046-.951 2.322-1.434 3.59-1.434 1.273 0 2.52.49 3.472 1.442z'/%3E      %3C/g%3E    %3C/g%3E  %3C/g%3E%3C/svg%3E) 推荐 ![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M22.242 7a2.5 2.5 0 0 0-2.5-2.5h-14a2.5 2.5 0 0 0-2.5 2.5v8.5a2.5 2.5 0 0 0 2.5 2.5h2.5v1.59a1 1 0 0 0 1.707.7l1-1a.569.569 0 0 0 .034-.03l1.273-1.273a.6.6 0 0 0-.8-.892v-.006L9.441 19.1l.001-2.3h-3.7l-.133-.007A1.3 1.3 0 0 1 4.442 15.5V7l.007-.133A1.3 1.3 0 0 1 5.742 5.7h14l.133.007A1.3 1.3 0 0 1 21.042 7v4.887a.6.6 0 1 0 1.2 0V7z' fill='%23000' fill-opacity='.9'/%3E%3Crect x='14.625' y='16.686' width='7' height='1.2' rx='.6' fill='%23000' fill-opacity='.9'/%3E%3Crect x='18.725' y='13.786' width='7' height='1.2' rx='.6' transform='rotate(90 18.725 13.786)' fill='%23000' fill-opacity='.9'/%3E%3C/svg%3E) 留言