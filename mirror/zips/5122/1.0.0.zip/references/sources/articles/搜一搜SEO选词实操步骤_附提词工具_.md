     搜一搜SEO选词实操步骤，附提词工具！ \* { margin: 0; padding: 0; outline: 0; } body { font-family: "PingFang SC", system-ui, -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Hiragino Sans GB", "Microsoft YaHei UI", "Microsoft YaHei", Arial, sans-serif; line-height: 1.6; } .\_\_page\_content\_\_ { max-width: 667px; margin: 0 auto; padding: 20px; text-size-adjust: 100%; color: rgba(0, 0, 0, 0.9); padding-bottom: 64px; } .title { user-select: text; font-size: 22px; line-height: 1.4; margin-bottom: 14px; font-weight: 500; } .\_\_meta\_\_ { color: rgba(0, 0, 0, 0.3); font-size: 15px; line-height: 20px; hyphens: auto; word-break: break-word; margin-bottom: 50px; } .\_\_meta\_\_ .nick\_name { color: #576B95; } .\_\_meta\_\_ .copyright { color: rgba(0, 0, 0, 0.3); background-color: rgba(0, 0, 0, 0.05); padding: 0 4px; margin: 0 10px 10px 0; } blockquote.source { padding: 10px; margin: 30px 0; border-left: 5px solid #ccc; color: #333; font-style: italic; word-wrap: break-word; } blockquote.source a { cursor: pointer; text-decoration: underline; } .item\_show\_type\_0 > section { margin-top: 0; margin-bottom: 24px; } a { color: #576B95; text-decoration: none; cursor: default; } .text\_content { margin-bottom: 50px; user-select: text; font-size: 17px; white-space: pre-wrap; word-wrap: break-word; line-height: 28px; hyphens: auto; } .picture\_content .picture\_item { margin-bottom: 30px; } .picture\_content .picture\_item .picture\_item\_label { text-align: center; } img { max-width: 100%; } .pay\_subscribe\_notice { margin: 30px 0; padding: 20px; background: #fffbe6; border: 1px solid #ffe58f; border-radius: 8px; } .pay\_subscribe\_badge { display: inline-block; padding: 4px 12px; background: #faad14; color: #fff; border-radius: 4px; font-size: 14px; font-weight: 500; margin-bottom: 12px; } .pay\_subscribe\_desc { font-size: 15px; line-height: 1.8; color: rgba(0, 0, 0, 0.7); margin-bottom: 12px; } .pay\_subscribe\_hint { font-size: 13px; color: rgba(0, 0, 0, 0.4); } .\_\_bottom-bar\_\_ { display: flex; justify-content: space-between; align-items: center; position: fixed; bottom: 0; left: 0; right: 0; height: 64px; padding: 8px 20px; background: white; box-sizing: border-box; border-top: 1px solid rgba(0, 0, 0, 0.2); } .\_\_bottom-bar\_\_ .left { display: flex; align-items: center; font-size: 15px; white-space: nowrap; } .\_\_bottom-bar\_\_ .right { display: flex; } .\_\_bottom-bar\_\_ .sns\_opr\_btn { display: flex; align-items: center; user-select: none; background: transparent; border: 0; color: rgba(0, 0, 0, 0.9); font-size: 14px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn:not(:last-child) { margin-right: 16px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn > img { margin-right: 4px; }

搜一搜SEO选词实操步骤，附提词工具！
===================

原创 o君言o 君言戏语 2021-11-24 11:47 undefined

> 原文地址: [https://mp.weixin.qq.com/s/wksTf\_ykoZT7HKcC4sHN8Q](https://mp.weixin.qq.com/s/wksTf_ykoZT7HKcC4sHN8Q)

前言
--

一篇文章，不应该是当下一看觉得有用，过后就马上没价值。

一篇文章，也不只是给读者启发学习，对于作者本人，也要起到梳理、回顾、提炼或总结的作用。

这是我在写文章时尽力在靠近的目标。

目前堆积了好几个有价值的选题，但是因为个人节奏，进度有些慢，现正在陆续安排。

问题
--

在9月中旬，读者群里恰巧聊到了**搜一搜SEO**这个问题，对于没有做过这个领域的我，基于自己的经验说了下我的看法：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80F1GG4KKFBzQ6ACrQrkiazICOQQInhPoloOibxj7IxlGNy0kgFSWIW6Niaw/640?wx_fmt=jpeg)

交流群

  

搜一搜seo这个事情当然有很大的商业价值，市面上有很多相关的培训和教程，也有很多人挖空心思的抢占排名词，毕竟带来的回报是很可观的。

但是SEO从来不是天然学科，它是没有标准方式方法的，涉及到SEO的很多问题经常被看成是玄学。

这也导致市面上存在很多乱象，有些人在做无用功，有些人想做却没有思路，有些人尽做损害平台和用户体验的行为，有些人放大了**搜一搜SEO**的操作空间和效果。

因此，这篇文章基于我在交流群里提到的内容展开，围绕**三个差异化竞争** 说说我对**搜一搜SEO**的看法以及相应可以落地的方法步骤。

正确看待搜一搜SEO
----------

一般而言，我认为应该先明白某件事物的性质，即底层的逻辑，才能做好相应的事情。

对于任何提供搜索的平台而言，他们其实很愿意与创作者形成“良性的seo关系”，即：

创作者希望平台确认正确的seo行为以获得收益  
平台希望创作者正确运用seo手段提升用户体验

这是一种双赢的局面！

早在几年前，综合搜索引擎陆续开放了站长平台和学院，试图正确引导站长运用合理的seo手段来运营站点，帮助站长提升数据和收益的同时也改善搜索引擎的用户体验。

尽管截止目前也有些地方不尽人意，但这已经是很大的进步。

而作为微信延伸出来的子产品，号称月活5亿的搜一搜，官方却一直并未重视seo这个问题，有各种搜一搜官方公众号、小程序或开放平台，但都只是发布品牌合作相关内容，与seo相关不大。

这里面可能有很多考量，但是我认为有个比较重要的原因，就是我在群里提到的问题：**综合搜索引擎的很多SEO优化工作在搜一搜SEO这里，并不存在**。

  

下面是传统SEO要考虑的主要问题：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FFOo07O6NG3VgqxMLTbwbkibkecibv9qmfs0ferjicleFkENfLbcQiaTqOA/640?wx_fmt=png)

传统SEO

### 收录

搜一搜的搜索结果，更多是微信的子产品，公众号、小程序、视频号 等等，大家竞争的主要也是这方面。

当我们的内容出现时，马上就到了他们自家数据库了，根本不存在爬虫过来抓取这个问题。

同时，由于子产品是自家的，产品形式和技术手段都是固定的，这与综合搜索引擎面对**基于半结构化语言HTML做出来的web站点**不一样的地方在于：

**搜一搜的搜索系统不需要担心这些搜索结果存在的各种技术问题**。

比如综合搜索引擎要担心站点内容用js技术展示，这会让搜索引擎抓取不到正文内容，所以它需要引导一些不懂的站长，让站长避免使用js或ajax来展示内容，这是一种很基础的seo优化手段。

但是搜一搜不需要，你的文章发在我的自家产品“公众号”里，根本不用担心内容检索不到的问题。

对于需要用户权限的站点内容，传统搜索引擎是没办法抓取到的，但是对于一篇公众号付费文章，搜一搜同样可以拿到它的原文内容。

如果我们的账号不是风险账号、内容不是风险内容，关于SEO收录问题以及相关优化工作，在搜一搜这里是不存在的，不需要优化，也无从竞争。

_ps：偶尔有个别内容没有被收录，可以到社区反馈，这是可能存在的技术问题，是可以解决的。_

### 点击率

这在传统搜索引擎的SEO优化工作中很重要，在搜一搜也有相应价值，因为点击率的背后是用户选择。

但问题在于：

对于自家站点，内容在自己服务器上，我们想怎么改标题都可以，改几次也无所谓，可以改到数据最佳为止。

可一个公众号名称或一篇公众号文章标题，能修改的次数是非常有限的，基本做不了什么测试，唯一能做的就是换号或发新文，但是这个资源也是有限的。

所以**点击率优化**这个问题，显得有些鸡肋。

### 外链

传统搜索引擎在很长一段时间里是基于PageRank的算法来作为主要排名因素的。

所谓的PageRank，简单粗暴来说是把网页链接之间的指向关系视为一种投票，根据获得的投票分值计算权重。

而搜一搜官方有明确表示过：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80Fvib4NHVDosKWoQrvAjM8pklakPJ0BBY0CVuz7kYlWWUWSjAXPE9SmmQ/640?wx_fmt=jpeg)

PeopleRank

搜一搜的排名算法基于PeopleRank，这个算法我没有深入了解，严格意义来说，我认为应该算一种概念，而非具体某个技术。

结合PageRank，**我们其实可以联想到的是PeopleRank是基于人与人之间的传播关系**，将这种关系视为一种投票来影响排名。

当然，PeopleRank可能不止计算传播关系，还包含其他与人相关的因素，我们后面再聊。

  

传统搜索引擎无法计算搜索用户之间的传播关系，毕竟它不可能知道谁把哪条链接通过什么方式发给了谁，但是微信可以，在微信生态下的用户之间的传播关系是可以计算的。

说到底：公众号之间**并不存在需要像网站那样靠增加链接指向来增加排名权重**，所以综合搜索引擎里与外链相关的各种seo正规违规操作在搜一搜这里也不存在了。

毕竟链接指向可以操控，但是人与人之间的传播无法控制。

### 关键词

关键词竞争并非搜索引擎官方规定的某个排名因子，而是基于这些排名因素延伸出来的另一种排名竞争手段。

相当于：某个词我们竞争不过，但是我们可以竞争另一个没人竞争的词，反正最终目的是排在第一位。

这在传统搜索优化工作里是**很重要、也很立竿见影的流量提升手段**，这种手段同样适用于搜一搜SEO，也是我们今天重点要聊的方向。

**关于关键词堆砌**：

公众号名称、简介、文章标题、内容、自定义菜单，这些地方可以增加一些关键词来提升相关性（过分堆砌是很容易识别出来的、体验也很不好），这没错，也有作用。

但是这种优化手段不存在竞争力，**是属于我们可以做别人也轻易可以做的事情**，国家队里不缺努力的人，努力是基本门槛，所以如果我们只寄希望于这些地方做做优化带来相应的效果，那经常是要失望的。

### 排名

传统搜索引擎的排名算法可以罗列出几十几百个因子，这里面有技术层面的、用户层面的、网站自身层面的、站外层面的。

而到了搜一搜SEO，就只剩自身层面和用户层面：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80F3Nvl3yjaE6sOWSdp8g4AR9DxXesJpvh81k5lcgg3b9OuH7KhTBEk9w/640?wx_fmt=jpeg)

搜一搜官方

而这张图片上面的标签：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FVFhp1kKic2slmbuADiaOlyrenhqTqSVpnicRNTHrV12C5V03ZB5vv1ibLA/640?wx_fmt=jpeg)

排名因素

可以看得出来，大部分是不具备“优化意义”的，比如“注册时间”，我们又不能“优化”自己的“注册时间”。

**自身层面**

传统SEO可以在自己的站点上做关键词优化、内链布局、关联内容 等等甚至一个URL层级也可以优化。

但是到了公众号呢？你是不是只能堆砌几个关键词？

这种操作无非就是对应“内容相关性”这个排名因素，除此之外，还有什么与排名相关的优化手段吗？

**关于时效性**

时效性，应该只存在于新闻领域，这个在技术上是比较容易识别的，其他领域不需要考虑时效性。

同时时效性在有些地方是没有意义的，搜索一个公众号不至于要考虑时效性吧？

**用户层面**

用户数据应该是搜一搜排名算法里比较重要的一个版块，所谓的PeopleRank算法，基本是基于用户数据的。

所谓的用户数据：

关注、阅读、点赞、在看、赞赏、评论、转发、点击率

这是拍脑袋可以想得到的因素，同时还是很重要的因素！

这个“拍脑袋”是指：做搜一搜SEO的人可以想得到、负责制定算法的搜一搜工程师也想得到。

那么**这种谁都想得到、同时还是核心矛盾的问题，就不会是轻易可以解决的问题**。

这就好像减肥：都知道运动和饮食是关键，但又有几个人可以做到坚持呢？谁都知道赚钱要努力奋斗，对吧。

同理，谁都知道优质内容可以提升上面这些数据，但优质内容并非信手可以拈来，所以归根结底：这种所谓的技巧压根没意义。

**关于刷数据**：

不能提供优质内容，那我可以通过技术手段、资源手段来操控数据，把用户数据“刷”上去，比如刷点阅读、刷点在看，看上去好像不错？

实际上效果是有的，但是这让我想到一个事情：

记得应该是18年的微信公开课上，针对“跳一跳”玩家使用作弊工具的问题，张小龙老师表示：已经有一套相应的算法来识别。

算法思路也很简单：一个正常人，从第一次玩跳一跳，到玩出高分后，这个过程中他的历史分数是如何分布如何增长的，这种分布增长符合一个客观规律，算法可以计算出一条曲线出来。

一个正常玩家，他的分数分布是符合这条曲线的，因此：对于分数突然大涨，“进步神速”的玩家，结合其他因素，很容易被识别出来是作弊的。

那么我们的公众号、视频号等，平时是什么样的表现，历史数据是统计得到的，用户数据突然呈现不符合规律的比例，而相应的传播数据却没有，你说是不是很容易判断出来？

除了自然传播之外，你如何让自己的一切数据符合系统的预期呢？

所以：系统想要识别作弊，有很多策略，毕竟我们的一切数据都在系统生态里，当我们选择一些作弊手段的时候要考虑到：是不是经得起封号？

长期与平台对抗，平台是肯定不会累的，但是你自己会很累。

灰色手段，只适合平台初期，一切还在野蛮生长的阶段，平台暂时还不在乎，但是对于今天的微信生态，我极不建议运用“刷数据”这种手段。

配合平台，替平台考虑，为用户着想，才是可持续的路线。

  

**综上，对于搜一搜seo，我们可以得出的结论是**：

传统搜索引擎涉及的很多seo优化手段在这里是不存在的，没有想象中那么复杂和高深。

影响搜一搜排名的因素主要有：内容相关性、用户行为数据、关键词竞争。

“用户行为数据”属于内容运营问题，不存在SEO层面的技术问题，“内容相关性”属于基础门槛，不值一提，唯一可以优化的切入点只剩下：“关键词竞争”。

搜一搜SEO选词步骤
----------

缕清了搜一搜SEO的本质问题，接下来我们就可以清晰的根据现有的切入点着手，选择相对的科学一点的SEO手段。

鉴于目前搜一搜SEO的优化场景更多是公众号名称排名、公众号文章排名，对象更多是新号名称选择或新文章标题撰写(毕竟谁也没办法或不会时不时修改名称和标题)。

因此下面主要基于这方面来演示相应的步骤和思路，实际过程中再结合当下情况调整。

假设我们现在希望挖掘一个有流量、有商业价值、竞争相对低的关键词来注册一个公众号，以此获得一些自然排名的流量 进而变现，下面是具体步骤：

### 步骤1

确定一批自己感兴趣或有优势的领域，比如我选择的数据有：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80Fk3Qr4UmY0yhbjvpmlIbCjVDiciaenAhQUnyt2iapJyoiaJQJlriaUV0LMcA/640?wx_fmt=png)

50个领域

挨个挖掘这批领域的长尾词，这里我选择直接用5118下载过的长尾词数据：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80F41jwAe9ibicyCHLqVXfryfRu4n5xqnicQKr1XYlBqwTucPib0YYpjZp92g/640?wx_fmt=png)

5118数据

### 步骤2

接着提取领域大词，所谓的领域大词：

seo：这个领域常见的词根有：优化、排名、原创 等等，那么可以组合出：seo优化、seo排名、seo原创 等等，这些被认定为领域大词。

自媒体：这个领域常见的词根有：涨粉、引流、变现 等等，那么可以组合出：自媒体涨粉、自媒体引流、自媒体变现 等等，这些被认定为领域大词。

提取领域大词的目的，就是我们这篇文章提到的第一个差异化竞争：

我们现在如果去注册 seo、sem、自媒体 这样名称的公众号，要嘛被人抢占了，要嘛因为各种政策原因或法律原因不让注册。

因此我们需要退而求其次，注册这些目标领域里的大词而不是主词，它们实际上也有很大体量的搜索，同时流量更加精准，商业价值更高。

当然：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FGPRZmXzLPS6MsSRkHJ5JBF6fGewg8J6nowuUTibdQbtibjJnDBY7eZibA/640?wx_fmt=jpeg)

seo优化

如果我们只是选择一个seo，立刻能想到“seo优化”这种有商业价值的大词，那么实际上别人也能想得到，搜索一下马上就失望了。

因此我们需要一批领域、一个领域提取一批大词，大批量的词汇里才能找到别人遗漏的。

那么如何提取领域大词呢？

### 步骤3

当我们面对一个领域想要得到这个领域的大词，比如seo，靠想是不应该的，因为我们不可能对那么多领域都知根知底如数家珍，而且再熟悉的领域，一时也可能会有遗漏的。

因此，交给程序是最适合的。

当我们有一份50万条“seo”相关长尾词的数据，如何把这个领域的常见词根提取出来呢？

词频，这是比较直接的，最高词频就是常见的。

但是，词频数据首先要基于分词，可分词技术只能识别已登录词(可以理解为它认识的)，对于很多领域的专业术语是识别不出来的。

它可能认得“优化”、“排名”这些词，因为这些词不只是这个领域的常见词，但是它大概率不认得“霸屏”这个词，可这还是这个领域的常见词。

  

在这里，我们引入**新词发现**技术，这个算法我们后续文章再聊，简单来说：它会根据数据里的文本分布，结合左右邻文本和整体出现频率，用概率的方式计算一段文本是不是一个词汇。

当我们把一份seo相关数据给它时，它可以返回这样一份数据（限定返回TOP100个）：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FSHn7LyastVm2ebSJOYnQdxAyQucw5K1HwP3yd3fRbRNa99rOoQ9M1w/640?wx_fmt=png)

可能的词汇

TOP前的词汇一般都是正确的，但是这些词汇是按照概率返回的，不一定是seo领域主要的、常见的。

所以我们只需要再根据词频排序（领域常见的词频就比较高）：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FeUrtnxojXtatvE6EozYsHr8Buj3K3b7nmp5EKM8KoZcgy2BibYuhzhg/640?wx_fmt=png)

seo常见词汇

可以看到TOP前的大都是seo这个领域常见、重要、主要的词汇，即：这个领域聊来聊去都是在聊这些的词汇，提供的数据越多越丰富，结果越准确。

这个算法我有封装了一个小工具，给它数据(给一批也行)，就返回相应的词汇，可以限制数量，可以做词汇过滤：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80F0KdstbVeLWspySaMcsNfEy5ib7VJd4Su2icWIG1XWSkTn9LJyWYeXGSw/640?wx_fmt=png)

提词工具

工具除了这个作用以外，还适合提取出大词，用于深挖领域长尾词，而新词发现的功能还可以用于其他地方，后续再介绍。

工具在文末领取。

_ps：我们这里的演示数据是长尾词，然而新词算法的原始数据可以是长尾词、也可以是标题、文章，数据越多越丰富越准确。_

### 步骤4

通过刚才的程序，我们得到了每一个领域的常见词汇，在我的测试数据里，限制返回词量50个，50份数据得到了2500个词汇分别保存：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FYPPaiciabHKZZZ52V8txOWias6n9M2SRTDrALw2zry4JwpIAp11Q3caQw/640?wx_fmt=png)

领域大词

接下来我们去除一些非目标词：

在返回的词汇里，我们可能会碰到“怎么”这样的词汇，类似“好像”这样的词虽然也不是目标，但是因为它在长尾词数据里的词频太低，一般不会被程序当成“可能的词汇”，至少没办法排在返回的数据里的top。

可是“怎么”这样的词汇是很有可能出现的，因为词频太高了，而我们显然不打算注册一个名称为“seo怎么”的公众号，因此这些词要去除。

下面是常见要去除的目标词，一般可以解决掉7788：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80F3wBH4LdPPuSvtqjw23TRwnhm3icMpKWe0bO9FTiamqC8KAI9nHHuFPUA/640?wx_fmt=png)

无效词

小部分不理会，我们只是尽可能的减少无效目标。

这个步骤在上述工具里可以事先设置，只是这里需要讲一下这个步骤。

### 步骤5

去除了无效词，接下来要组合出大词，也就是“seo”这个领域里出现“优化”，我们要把“seo”和“优化”组合起来形成组合大词。

新词算法根据提供的数据计算，它有可能直接计算出“seo优化”这样一个组合词(如果这个组合在数据里出现足够多的频率)。

因此我们需要挨个判断一下：如果seo这个领域返回的某个词有包含seo，那就不需要组合了，它一定是个常见组合词，反之，需要把“seo”组合进去。

但是这又会有个问题：当它出现“优化”这个词时，到底要让程序把“seo”放前面还是放后面呢？

人工显然知道放哪里，但这是程序自动执行的，需要给它判断条件才行，否则就可能会组合出“优化seo”，要是碰到“书籍”，出现“英语”，然后组合出“书籍英语”，这就很尴尬了。

行业不同，很多表述千奇百怪，一味放前或放后都不行，需要灵活判断。

  

在这里我们运用一个简单的策略，基本可以做到万无一失：

我们分别把“seo”放到前面和后面，会得到“seo优化”和“优化seo”，然后把这两个组合词拿到原始数据里统计词频。

看看哪一个组合词的词频高，词频高代表“这个描述更常见”，取词频高的那一种作为组合结果。

同时，因为“优化”这个词是来源于seo里的高频词汇，与“seo”组合并经过词频比较，得出来的组合词一定是通顺自然的。

运用这种方式就不可能得到“书籍英语”这样的结果，毕竟在一份正常的行业内容数据里，“英语书籍”这个文本怎么都会比“书籍英语”来得更常见。

这个步骤在上述工具里会自动执行！

这是最终得到的数据例：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80Fvz1PXsf5LicvZqjgO039aribwxR1TBF8kvicF4fcnuORohUGNArHfTlicQ/640?wx_fmt=png)

seo

这样组合出来的词就没有存在什么违和感，同样每个领域的数据分别保存一份。

### 步骤6

“seo排名”、“seo方案”、“seo优化”，这样的词，我们都知道有商业价值，但如果数据里出现“seo内链”这样一个词呢？

对seo了解的朋友肯定知道，与seo相关的各种合作或服务里，不会有“内链”这么一个相关业务，顶多只是优化方案当中的一小环。

所以我们也不打算注册一个“seo内链”这样的公众号，这种词的搜索可能不少，但是流量基本不具备商业价值。

因此，接下来的步骤是去除没有商业价值的组合词。

  

通过人工，很多时候我们可以大致判断一个词汇有没有商业价值，特别是自己熟悉的领域。

但是人工毕竟精力有限，而且很多领域其实我们判断不出来，因为不熟悉不了解。

不过没关系，资本会告诉我们一个事物有没有价值，竞价会告诉我们一个业务能不能赚钱。

能不能赚钱暂时还不是我们评判的标准，但是一个事物能做竞价，商业价值是肯定有了，比如：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FsbDUianBTT9ib1YEHggktGx1XQaI75jIep7Q1rpfKUQZz3EWkcw3tZzw/640?wx_fmt=png)

seo排名

但是“seo内链”：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FVXbkJRaTiaevWWVUCf7LHTnL9GhNIuqJ2tvdSiazT5XfLgTTmVD4G5Pg/640?wx_fmt=png)

seo内链

出现的广告都是匹配了“seo”，人家就不要“内链”这样的词。

因此：把目标组合词批量查询百度竞价，通过竞价标题是否同时出现“seo”和“内链”来判断有没有商业价值就是最直接有效的手段。

最后我们可以得到这样一份数据：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FS1tDQqrcMeH4xl7wvuLyHeKCtcq4DkfwD05eoAicCqToeamiap8fxqsw/640?wx_fmt=png)

竞价数据

分开匹配表示“seo”和“优化”同时在标题里，但没有连在一起，完全匹配则相反。

_ps：广告标题不包含主词的不计算广告数，比如查询“seo课程”：“seo”是主词，但是广告标题里只是包含“课程”，这很可能根本不是seo方面的广告。_

这个查询竞价的工作也可以使用WebScraper来执行，数据计算再在Excel里处理，学习可看：[技能篇：想要挖掘商机，先学会这个能力](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247484553&idx=1&sn=ac1bc4f6d19ec6954a577e0d346eef96&chksm=feb867dec9cfeec8a2b36673c17c32213aff74e970f2c309f578f16dce2cfc18943984d93d8d&token=629866051&lang=zh_CN&scene=21#wechat_redirect)。

  

然后根据数据结果把广告数量为0的直接去除，这大概率都是没有商业价值的。

有些词的广告满满，但是偏偏竞价标题都没有出现两个词缀同时存在的情况，比如“seo霸屏”（搜索下去5个广告位分散开 不好截图）。

那可能是因为“霸屏”这个词竞价不给上或其他因素不方便写上去，这种可以具体再人工看看。

最后剩下的词，就是具有商业价值、可以进一步筛选的目标。

### 步骤7

通过上面几个步骤，我们已经做好了全部的基本工作，接下来就到了关键一步，筛选关键词竞争度。

思路其实很简单：

把我们的每一个目标组合词拿去查询一下搜一搜结果，看看有没有相应的公众号，比如搜索“seo优化”：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FGPRZmXzLPS6MsSRkHJ5JBF6fGewg8J6nowuUTibdQbtibjJnDBY7eZibA/640?wx_fmt=jpeg)

seo优化

这已经被人注册了，不是我们的目标，我们的目标就是找出那些搜索下去没有多少相关公众号、没有与我们的搜索词完全一致的公众号，这种情况才是我们的机会，这是我们这篇文章的第二个差异化竞争。

  

但是，批量查询“搜一搜”的搜索结果，这个要嘛技术成本高、要嘛账号成本高，对于做营销的朋友，大部分没办法完成这个工作。

因此我们这里采取折中的方式：

目前市面上有很多第三方拥有公众号数据，比如典型的新榜，号称拥有5000万公众号数据，这已经很可观了，并且他们支持查询：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FjazERyDicyHOAJrq4MUhhuugWDtvGBpTa1MwrgTIsYWaDM3zcSibJmibQ/640?wx_fmt=png)

新榜

程序员可以使用自己的方式，非程序员朋友同样可以使用WebScraper来批量查询，万级以内的数据问题不大。

其次：搜狗微信也是一个渠道：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FLyzxkbbyGvvDtCRpeibuLfWneHnFvibQ05c6SpRm36fX7M4voHQhia0ug/640?wx_fmt=png)

搜狗微信

不过搜狗微信的数据我也不太清楚是滞后性问题还是其他原因，搜索结果有时与实际会有些许差别，同样一个关键词搜索结果，新榜经常比搜狗还要多。

就在我要截图的时候尴尬的发现我的公众号又搜索不到了，之前可以搜索到。

其他地方没有再看到有什么平台，剩下的是第三方api商业接口，这个可以到百度搜索下相关接口，需要花钱，就不分享这方面的信息了。

新榜也是提供这个服务的：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FAw9ialwKKYkxhmuxqvrmrc79zIeBwYBV0N5dhrFWfN4wgnM9c0S1obg/640?wx_fmt=png)

新榜api

api接口也很简单：

`url = 'https://api.newrank.cn/api/sync/weixin/account/search'   headers = {       'Content-Type':'application/x-www-form-urlencoded;charset=utf-8',       'Key':'*********'   }   rel = ssion.post(url,data={'keyword':'君言戏语'},headers=headers)   print(rel.json())   `

这么几行代码就可以搜索查询，3000块钱对于打算从事这个领域的投入，我觉得也不大。

**花钱选择第三方商业数据接口，是最好的方案**。

通过批量查询我们最后可以得到这样一份数据：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80Foap4tShcjpzKm2tAwxQiaic1RXEX0B3kgjf5quFItCzM6dicOJgR3udbw/640?wx_fmt=png)

统计结果

_ps：里面的数量计算，仅计算搜索返回的第一份最相关的结果即可。_

把已经存在公众号的关键词直接去除掉，对于剩下的关键词，直接拿到百度关键词规划师查询搜索量：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80Fope17faWh2xiaANQgtVzBkHR5uV299bnwtFeDtP9aOYAibB9vz1vVsHg/640?wx_fmt=png)

关键词规划师

数据下载后按照搜索量降序，人工从上到下挨个选择，过程中结合搜索结果数，确实想注册某个词时，再排查下微信指数：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FnvWBOGrBEHC2WtcA6X1quSg7AEzlyXQ5Rt3cQiaoQicAPDHhWM5fgWxw/640?wx_fmt=jpeg)

微信指数

搜索量、竞争度这些指标都有了，选词就有了明确的方向，然后根据个人情况来挑选自己认为有价值、有需求的关键词，进而注册为公众号。

注册公众号需要注意一个细节：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FWUmtuVqTdbKhFa4MSbRL9zHRGjDsNsibGX322VqcyCCbXibmG1UAoBrA/640?wx_fmt=jpeg)

搜一搜沙盒期

新注册的公众号存在沙盒期，因此不建议把目标关键词带上其它个性词汇组合注册，这样会搜索不到。

比如目标词是：sem培训，然后注册了个公众号：君言sem培训，这样情况下搜索：君言、sem培训，在沙盒期都是不会出现的，而在没有知名度时用户又不可能完整搜索。

  

以上就是完整流程，而在实际运用中，有些小细节要灵活变动，因此需要理解每一步的意义，这样做是为了什么。

至于技术问题，只是钱的问题，还不是大钱，所以不算问题。

延伸拓展
----

每个人的思维都是有局限性的：

从事运营，一天到晚想的都是数据，从事推广，一天到晚想的都是引流，从事技术，一天到晚想的都是代码。

同样的，从事互联网，一天到晚想的都是互联网相关的那些事物，哪怕偶尔想要发散下思维，也都逃离不了当下在做的事情。

有很多专门做搜一搜seo排名抢占的人员，做的词也可能总是围绕着互联网相关的领域，因为他自己本身是做互联网的。

比如我上面用来挖掘的领域，很多都是互联网相关，然而实际上：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FFNLykmpZN6JrfhCdBtRnWjsPNFnhwxU8b61cFFsictjqQLcfzp1fH4g/640?wx_fmt=png)

百度贴吧

这个世界上有太多领域了，互联网只是很小的一部分，由于微信数据的查询成本问题，我个人认为还有很多领域没有被人深挖细挖过。

在百度贴吧可以找到很多很多的细分领域。

而且很多领域本身跟互联网无关，这个领域里的人其实是不会来做搜一搜排名这种事的，当我们把涉及面扩大，再用上述的整套流程走一遍，我相信还是可以挖掘到不少空白的流量。

把思维散开，看到同行没有看到的更多领域，就是我们这篇文章的第三个差异化竞争。

结语
--

对于做过传统SEO的人，是没有太大必要去做这个渠道的，因为同样是SEO手段获得流量，传统SEO更加灵活。

通过这个流程，我自己也挖掘出一些不错的关键词，但是搜一搜SEO有天然的局限性，尽管我们可以大量获得一些优质词的名称排名，但得考虑后续的内容生产问题。

以今天的微信生态，更多重心应该还是在内容上（当然了，有些词不需要内容，只需要提供直接的服务，这就看你能不能找到了）。

合理的策略、适当运用一些技巧，都只是为了降低成本提升竞争力，并不代表要依靠这些手段做破坏。

一味寻求短期技巧，会让自己长期一直很累！

提词工具
----

上面提到的工具，我简单封装了一个脚本。

针对指定领域的数据：长尾词、文章标题、文章内容等，提取这些领域里的常见词汇，再与领域主词结合成领域大词，生成结果：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLKlpj1K5ngmdbRw8K1ia80FfHO6Zy06Rdqc3kIOcs3zwHvSPnY5P4Ly5vmcFP8oI9Vp6iawq23rAbw/640?wx_fmt=png)

工具生成结果

适用于大词注册、大词拓展等用途，给不会技术的朋友配合使用！

大词注册不要局限在公众号，短视频平台、自媒体平台、社群等等，还有很多地方是没有被人筛选过的。

进入公众号：

回复关键字：cw

即可领取！

* * *

文章被抄袭得厉害，抄袭就算了，修改、删减、涂水印、涂名称，缝缝补补后再说是自己团队做的，然后引导加付费社群，唉……

最近事情又多也懒得搭理，暂时先一个个记录着。

文章经常图片很多，几十张，每次都要挨个上传，挨个换链接(使用Markdown语法)。

于是从上一篇文章开始，做了个小工具，自动加水印，水印自适应图片，可随机、间隔或指定图片添加。

然后自动上传到公众号素材库，返回的链接自动替换在原文位置，效率高了好几倍。

半透明的水印不影响浏览，后续文章都会这样，大家见谅！

  

貌似上一篇文章有朋友到了昨天才收到推送……

公众号这推送机制也是神奇！

![](http://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLbYm2TI7kiameic7QEzKqbsk6jyHS4XpzpdnBgLOZOYzLO1eBLLOEN0CK2IJjjegG2kT7GRf7uZOnA/0?wx_fmt=png) 君言戏语

 ![](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3C!-- Icon from Lucide by Lucide Contributors - https://github.com/lucide-icons/lucide/blob/main/LICENSE --%3E%3Cg fill='none' stroke='%23888888' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'%3E%3Cpath d='M2.062 12.348a1 1 0 0 1 0-.696a10.75 10.75 0 0 1 19.876 0a1 1 0 0 1 0 .696a10.75 10.75 0 0 1-19.876 0'/%3E%3Ccircle cx='12' cy='12' r='3'/%3E%3C/g%3E%3C/svg%3E) 阅读![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M16.154 6.797l-.177 2.758h4.009c1.346 0 2.359 1.385 2.155 2.763l-.026.148-1.429 6.743c-.212.993-1.02 1.713-1.977 1.783l-.152.006-13.707-.006c-.553 0-1-.448-1-1v-8.58a1 1 0 0 1 1-1h2.44l1.263-.03.417-.018.168-.015.028-.005c1.355-.315 2.39-2.406 2.58-4.276l.01-.16.022-.572.022-.276c.074-.707.3-1.54 1.08-1.883 2.054-.9 3.387 1.835 3.274 3.62zm-2.791-2.52c-.16.07-.282.294-.345.713l-.022.167-.019.224-.023.604-.014.204c-.253 2.486-1.615 4.885-3.502 5.324l-.097.018-.204.023-.181.012-.256.01v8.218l9.813.004.11-.003c.381-.028.72-.304.855-.709l.034-.125 1.422-6.708.02-.11c.099-.668-.354-1.308-.87-1.381l-.098-.007h-5.289l.26-4.033c.09-1.449-.864-2.766-1.594-2.446zM7.5 11.606l-.21.005-2.241-.001v8.181l2.45.001v-8.186z' fill='%23000'/%3E%3C/svg%3E) 赞 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cpath d='M0 0h24v24H0z'/%3E    %3Cpath fill='%23576B95' d='M13.707 3.288l7.171 7.103a1 1 0 0 1 .09 1.32l-.09.1-7.17 7.104a1 1 0 0 1-1.705-.71v-3.283c-2.338.188-5.752 1.57-7.527 5.9-.295.72-1.02.713-1.177-.22-1.246-7.38 2.952-12.387 8.704-13.294v-3.31a1 1 0 0 1 1.704-.71zm-.504 5.046l-1.013.16c-4.825.76-7.976 4.52-7.907 9.759l.007.287c1.594-2.613 4.268-4.45 7.332-4.787l1.581-.132v4.103l6.688-6.623-6.688-6.623v3.856z'/%3E  %3C/g%3E%3C/svg%3E) 分享 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cdefs%3E    %3Cpath id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-a' d='M0 0h24v24H0z'/%3E  %3C/defs%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cmask id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-b' fill='%23fff'%3E      %3Cuse xlink:href='%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-a'/%3E    %3C/mask%3E    %3Cg mask='url(%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-b)'%3E      %3Cg transform='translate(0 -2.349)'%3E        %3Cpath d='M0 2.349h24v24H0z'/%3E        %3Cpath fill='%23576B95' d='M16.45 7.68c-.954 0-1.94.362-2.77 1.113l-1.676 1.676-1.853-1.838a3.787 3.787 0 0 0-2.63-.971 3.785 3.785 0 0 0-2.596 1.112 3.786 3.786 0 0 0-1.113 2.687c0 .97.368 1.938 1.105 2.679l7.082 6.527 7.226-6.678a3.787 3.787 0 0 0 .962-2.618 3.785 3.785 0 0 0-1.112-2.597A3.687 3.687 0 0 0 16.45 7.68zm3.473.243a4.985 4.985 0 0 1 1.464 3.418 4.98 4.98 0 0 1-1.29 3.47l-.017.02-7.47 6.903a.9.9 0 0 1-1.22 0l-7.305-6.73-.008-.01a4.986 4.986 0 0 1-1.465-3.535c0-1.279.488-2.56 1.465-3.536A4.985 4.985 0 0 1 7.494 6.46c1.24-.029 2.49.4 3.472 1.29l.01.01L12 8.774l.851-.85.01-.01c1.046-.951 2.322-1.434 3.59-1.434 1.273 0 2.52.49 3.472 1.442z'/%3E      %3C/g%3E    %3C/g%3E  %3C/g%3E%3C/svg%3E) 推荐 ![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M22.242 7a2.5 2.5 0 0 0-2.5-2.5h-14a2.5 2.5 0 0 0-2.5 2.5v8.5a2.5 2.5 0 0 0 2.5 2.5h2.5v1.59a1 1 0 0 0 1.707.7l1-1a.569.569 0 0 0 .034-.03l1.273-1.273a.6.6 0 0 0-.8-.892v-.006L9.441 19.1l.001-2.3h-3.7l-.133-.007A1.3 1.3 0 0 1 4.442 15.5V7l.007-.133A1.3 1.3 0 0 1 5.742 5.7h14l.133.007A1.3 1.3 0 0 1 21.042 7v4.887a.6.6 0 1 0 1.2 0V7z' fill='%23000' fill-opacity='.9'/%3E%3Crect x='14.625' y='16.686' width='7' height='1.2' rx='.6' fill='%23000' fill-opacity='.9'/%3E%3Crect x='18.725' y='13.786' width='7' height='1.2' rx='.6' transform='rotate(90 18.725 13.786)' fill='%23000' fill-opacity='.9'/%3E%3C/svg%3E) 留言