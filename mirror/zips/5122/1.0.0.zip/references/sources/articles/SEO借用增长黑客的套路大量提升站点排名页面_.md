     SEO借用增长黑客的套路大量提升站点排名页面！ \* { margin: 0; padding: 0; outline: 0; } body { font-family: "PingFang SC", system-ui, -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Hiragino Sans GB", "Microsoft YaHei UI", "Microsoft YaHei", Arial, sans-serif; line-height: 1.6; } .\_\_page\_content\_\_ { max-width: 667px; margin: 0 auto; padding: 20px; text-size-adjust: 100%; color: rgba(0, 0, 0, 0.9); padding-bottom: 64px; } .title { user-select: text; font-size: 22px; line-height: 1.4; margin-bottom: 14px; font-weight: 500; } .\_\_meta\_\_ { color: rgba(0, 0, 0, 0.3); font-size: 15px; line-height: 20px; hyphens: auto; word-break: break-word; margin-bottom: 50px; } .\_\_meta\_\_ .nick\_name { color: #576B95; } .\_\_meta\_\_ .copyright { color: rgba(0, 0, 0, 0.3); background-color: rgba(0, 0, 0, 0.05); padding: 0 4px; margin: 0 10px 10px 0; } blockquote.source { padding: 10px; margin: 30px 0; border-left: 5px solid #ccc; color: #333; font-style: italic; word-wrap: break-word; } blockquote.source a { cursor: pointer; text-decoration: underline; } .item\_show\_type\_0 > section { margin-top: 0; margin-bottom: 24px; } a { color: #576B95; text-decoration: none; cursor: default; } .text\_content { margin-bottom: 50px; user-select: text; font-size: 17px; white-space: pre-wrap; word-wrap: break-word; line-height: 28px; hyphens: auto; } .picture\_content .picture\_item { margin-bottom: 30px; } .picture\_content .picture\_item .picture\_item\_label { text-align: center; } img { max-width: 100%; } .pay\_subscribe\_notice { margin: 30px 0; padding: 20px; background: #fffbe6; border: 1px solid #ffe58f; border-radius: 8px; } .pay\_subscribe\_badge { display: inline-block; padding: 4px 12px; background: #faad14; color: #fff; border-radius: 4px; font-size: 14px; font-weight: 500; margin-bottom: 12px; } .pay\_subscribe\_desc { font-size: 15px; line-height: 1.8; color: rgba(0, 0, 0, 0.7); margin-bottom: 12px; } .pay\_subscribe\_hint { font-size: 13px; color: rgba(0, 0, 0, 0.4); } .\_\_bottom-bar\_\_ { display: flex; justify-content: space-between; align-items: center; position: fixed; bottom: 0; left: 0; right: 0; height: 64px; padding: 8px 20px; background: white; box-sizing: border-box; border-top: 1px solid rgba(0, 0, 0, 0.2); } .\_\_bottom-bar\_\_ .left { display: flex; align-items: center; font-size: 15px; white-space: nowrap; } .\_\_bottom-bar\_\_ .right { display: flex; } .\_\_bottom-bar\_\_ .sns\_opr\_btn { display: flex; align-items: center; user-select: none; background: transparent; border: 0; color: rgba(0, 0, 0, 0.9); font-size: 14px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn:not(:last-child) { margin-right: 16px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn > img { margin-right: 4px; }

SEO借用增长黑客的套路大量提升站点排名页面！
=======================

原创 o君言o 君言戏语 2022-09-14 11:30 福建

> 原文地址: [https://mp.weixin.qq.com/s/JpJm8YdwjfCgHNh-dnByWw](https://mp.weixin.qq.com/s/JpJm8YdwjfCgHNh-dnByWw)

小工具网站
-----

假设我们要做这样一个小工具站点：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIrcjFXQ8vxibAOzS4DQJYDFiaQw1OmRmDaVuAbniaxTPWTTr2ibS8wMNzszFJQFKbvRl6vcJow9Aa5ibA/640?wx_fmt=png)

如图，这是站点里的其中一个工具：

`图片尺寸修改器`

在这个站点里，每一个页面都是一个单独的小工具，实现某个功能。

  

可以看到我们这个页面去参与seo排名的核心词是：`图片修改尺寸`。

所以我们在标题里直接写入相应的长尾词，页面H1标题也是如此。

同样，我们这个网站还会有很多类似的页面，每一个页面承载一两个功能性描述的目标长尾词。

基于这样的框架下，网站上线后，

这一个个页面、一个个长尾词就是我们参与seo排名的流量词汇。

而用户也通过这些长尾词的搜索找到我们的页面，并使用工具服务。

增长的问题
-----

基于这样的布局方式来打造一个线上小工具的网站并没有问题，

是比较常规的方式，但有些情况需要考虑：

工具页面一般只有简单的几个交互控件，以及简洁的描述说明信息，

注定是**没办法承载太多内容**，因此也不会有太多关键词字眼。

一个页面能承载的关键词数量也是有限的，这样的页面**撞不到什么长尾流量**。

  

其次，同样一个需求，它可能产生的描述是**极具丰富性**的，当用户需要`图片修改尺寸`的时候，

用户可以搜索：`图片调整大小`、`图片设置宽高`，这很正常。

尽管现在的搜索引擎在“语义相关”技术上做得不错，但是同等条件下，

搜索词完全匹配肯定会相对有优势，比如**飘红带来不一样的点击率**，点击率带来更优质的排名。

  

再者，由于专业度、执行力等问题，大部分同行总是会**集中在小部分热门词汇的竞争**，

而忽略了同样有搜索量的其他目标长尾词，导致很多流量可能是没人要的。

  

最后，我们可能很辛苦才开发出100个小工具，但是这100个小工具只能产生100个页面，

加上一些延伸出来的列表页等，这个网站最终不过只有一两百个长尾词参与竞争。

在很多网站成千上万、甚至几十万的收录面前，这样的站点能拿到的流量一般少得可怜。

那么针对这种情况，如何来制定一个内容增长、流量提升的策略呢？

策略思考
----

seo的很多策略应该是**基于用户角度来考虑的**，而不是单纯的应对机器。

在满足用户需求的前提下思考流量增长的策略才是相对科学的seo方式。

  

在这种情况下，我们可以参考这样做：

`图片修改尺寸`这样一个长尾词的词根词缀其实都有可以替换的同义词，比如：

图片 -> 图像  
修改 -> 更换  
尺寸 -> 大小

这是不用思考的近义词替换，具体执行时我们可以这样找：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIrcjFXQ8vxibAOzS4DQJYDFpRGqf0sReRcPHyleLEOjpRcIS5TJ705ltjGp8t6gc619Hmzia2gsViaQ/640?wx_fmt=png)

大部分词汇都可以找到几个替换的近义词。

  

进一步来说，“名词”这种词汇经常存在一种“**子集包含**”的关系，比如：

图片，这只是一个具体的总称，但其实很多东西都可以称之为图片，

照片、头像、壁纸、海报、截图、证件照 等等，

这些也都是图片，所以它们同样会产生批量修改尺寸的需求，当用户正在处理一批海报时，

ta很可能**下意识**搜索的是：`海报调整尺寸`。

同理，文档也是一个具体的总称，`文档批量重命名`的小工具的同类词可以是：

`txt批量重命名`、`ppt批量重命名`、`pdf批量重命名`

  

实际上我们的`图片修改尺寸`这个小工具是可以解决`海报调整尺寸`这样一个需求的，

但是由于我们网站没有布局相关长尾词，我们的工具大概率没办法被搜索到。

因此我们可以针对该长尾词再生成一个模板页面：

假设长尾词a`“图片修改尺寸”`对应我们现有工具页面a：

`https://www.abcd.com/photo/size/`

下面是它的页面：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIrcjFXQ8vxibAOzS4DQJYDFiaQw1OmRmDaVuAbniaxTPWTTr2ibS8wMNzszFJQFKbvRl6vcJow9Aa5ibA/640?wx_fmt=png)

现在我们得到一个新的长尾词b：`“海报调整尺寸”`，

随即在网站后台生成一个工具页面b：

`https://www.abcd.com/photo/size2/`

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIrcjFXQ8vxibAOzS4DQJYDFMaEDrsjUrSDz8UibjkNsia2oHAH4sQibNBl3WTSUT3QM502Srib99wMibiaw/640?wx_fmt=png)

该页面对应着长尾词b，标题、H1、页面描述里，都替换成`海报调整尺寸`这个目标长尾词。

页面b的工具功能与页面a完全一致。

这样不管用户搜索的是`图片修改尺寸`还是`海报调整尺寸`，

我们站点的这个小工具都有机会参与排名，进而被访问到！

  

有些朋友看到这里可能会疑惑，这样是不是生成大量重复页面？

然而做SEO要基于用户的角度考虑，而不是机器，因为**机器最终也是为了用户**。

对于用户来说，搜索到一个结果，**只要这个结果能解决ta的需求即可**，

这个结果在站内站外是不是大量重复，这不是ta关心的，也影响不了ta。

其次，一款在线页面小工具，几乎没有完整的主体内容，就是几个控件组成。

机器是很难判断页面a的小工具和页面b的小工具是不是同一个小工具，

是不是在解决同一个具体问题，甚至这个小工具能不能正常使用，机器也根本判断不了。

重复页面会浪费搜索引擎的抓取资源，这个是可以避免的，在后面我们会讲。

重点步骤
----

有了基本思路后，我们来简单梳理一下落地的步骤：

首先根据工具的核心描述拓展长尾词：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIrcjFXQ8vxibAOzS4DQJYDFM5TCYbO2pZpdFcsbBftOgb66xu9bbRK8Erbra7bm6XkiaWqKJrWJzMQ/640?wx_fmt=png)

接着根据词频排序提取长尾词的核心词缀：

a

b

图片修改尺寸

图片,修改,尺寸

图片尺寸修改软件

图片,修改,尺寸,软件

修改图片尺寸的软件

图片,修改,尺寸,软件

图片尺寸怎么修改

图片,修改,尺寸,怎么

怎么修改图片尺寸

图片,修改,尺寸,怎么

可左右滑动

可以参考文章[搜一搜SEO选词实操步骤，附提词工具！](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486024&idx=1&sn=9a32fa672d7bb5e4d3dfe632646eeb9d&chksm=feb8691fc9cfe00941f1be53b5ed3e576036cfb477bdbd8bd9c2583c748707394dd9edd8bb76&token=1960401433&lang=zh_CN&scene=21#wechat_redirect)里的逻辑。

然后根据提取出的核心词缀(b列)去除同样的数据(a列)，即b列一样的a列去除。

  

接下来统计剩余长尾词的高频词根：

词根

词频

图片

13459

修改

13459

尺寸

13459

大小

1371

像素

936

批量

929

软件

856

在线

387

工具

231

可左右滑动

这些高频词根是目标工具的核心描述，同义词的替换只需要针对它们即可。

收集这些词根的同义词、同类描述，做一份对照表：

母词

同义词

同义词

同义词

图片

照片

壁纸

……

修改

调整

更改

……

尺寸

大小

像素

……

批量

一键

大量

……

软件

工具

助手

……

……

……

……

……

可左右滑动

同义词的收集先基于语文上的近义词在百度查找，再基于常识思考名词里的同类描述。

又或者根据这篇文章的思路[用逆向思维收集大量被忽略的"声音"](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247484016&idx=1&sn=6eb962822951c704b5fe4ee4ce877ba6&chksm=feb86127c9cfe831164c1226594a2d8c9ff4517f3db14d0aaad26870e85970d51d9784327bef&payreadticket=HFByzjwuNP6CZufvu7Yu1sYpvzsKnbZFjGo7JFgBn02ia1soA2-8E0Y03Ag-eJrCaARrM80&scene=21#wechat_redirect)。

最后利用这份对照表去替换 去除重复后 剩余的长尾词数据。

替换的逻辑可以是组合排列、仅名词替换 等等。

再把替换后的数据拿到关键词规划师里查询搜索量：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIrcjFXQ8vxibAOzS4DQJYDFNNO9CIEOP6PVpGaUDqk0NcruBDP7PRiaArN4wEmccqPzyzc6I4VXZfw/640?wx_fmt=png)

按照搜索量降序，优先挑选有搜索量的长尾词用于下一步的页面生成。

基于搜索量筛选的原因是：同义、近义的替换可能带来错误的不可读的词汇，

这些错误的长尾词一般不是正常人会搜索的，也就不会有搜索量。

**PS**：以上数据只是方便理解的演示数据，上述步骤应充分理解，不要在任何类目里生搬硬套！！

  

根据自己使用的web程序(ecms、dedecms等php语言或基于python的flask、django)，

在网站后台制作一个自动生成页面的脚本工具。

只需要向这个脚本工具提供一个新长尾词(海报调整尺寸)和原工具页面(页面a)的url，

即可在数据库里根据该页面的模板生成一个新的复制页面(替换页面里的长尾词)，

并返回一个前端可以直接访问的url。

这部分处理并不存在技术上的难度，技术策略根据实际情况调整，

当然 不懂技术的朋友可能不明白在做什么。

细节优化
----

除了原始的页面a，其他模板化出来的页面不在网站的任何页面里出现，

用户和搜索引擎无法在网站上看到模板化生成的这些页面。

然后通过站长平台等工具提交这些模板化生成的页面链接即可。

也就是说链接可以被收录，这个页面也可以被搜索到，可以访问和使用，

但是网站上看不到任何入口，用户不会在网站上看到各种重复的工具，

搜索引擎每天的抓取资源也不会浪费在我们站点里重复的工具上。

基于这样一个策略，一个小工具页面找到几十个合适的长尾词，就可以延伸出几十个参与排名的页面。

  

小工具的页面一般比较单一，我们可以给这个页面多设计一些版块内容，增加页面价值。

比如相关的小工具推荐、相关的经验文章，这些内容通过随机或其他排序规则展示。

基于这样的调整，同一个工具的多个页面之间的内容也是不一样的，大大降低页面的重复度。

还记得我在文章[从seo原创策略聊到短视频内容：瞬间量产1000个原创](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485072&idx=1&sn=c7018afcc92f4f2a991652d0250f5605&chksm=feb865c7c9cfecd16668efb13515028d3b2cb5677ed0bdb9e69364ba7c8896e291ae91fa79eb&token=1960401433&lang=zh_CN&scene=21#wechat_redirect)讲过，我们是在原创一个页面，不是在原创一篇文章。

这个页面模板你应该如何去设计它，才能在现有数据的前提下产生更多不一样的页面。

最后可以实现，能收集到多少优质长尾词，就能自动产生多少优质页面。

  
  

这篇文章所介绍的方式有点类似增长黑客的套路，

事实上大家认真去分析很多现有的一些大站，经常能从中找到一些增长黑客的方式方法。

大家其实没有那么多的内容，但是会基于用户、基于规则，

**在合理的范围里利用技术和现有数据**，大量创造出原创的页面来参与流量的竞争。

这与辛苦原创内容的站点的竞争是不在一个维度的。

如果你现在还打算运营seo这个渠道，你应该从最开始就思考内容增长策略。

大部分行业的搜索词总是比你的内容多，你应该思考如何有更多的页面来承载这些长尾词，

那么流量会自然而然的过来。

* * *

简单介绍一下自己，称呼：小曾，“君言”是我用来写东西的名称，目前自由职业，挖掘了不少互联网项目，独立跑通过几个！

擅于用技术辅助互联网营销，喜欢做需求分析的事情，崇尚走增长黑客的路线。

咨询、进读者交流群，可以[点击与我联系](http://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485860&idx=1&sn=52073ba58c5c70e2544440895af80a82&chksm=feb86af3c9cfe3e5af8e288e627af5c69b45197c2f40285734d26dc50723ea22eededea47e6a&scene=21#wechat_redirect)。

公众号回复数字 1 可查看历史分享的资源或工具：

  

##### 相关推荐

[大量发布占位视频的抖音seo方式](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486946&idx=1&sn=ac77d87514ae3dc98e80a105fdfe603a&chksm=feb86eb5c9cfe7a3c76ceaa496eafee1ac19f1c1ad13e23b95a00a9b82d12ddc397ab2957b3a&token=861650817&lang=zh_CN&scene=21#wechat_redirect)  
[抖音短视频如何运营-战略层面的思考](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247484861&idx=1&sn=8164842ae96ae330adb758cc8399078e&chksm=feb866eac9cfeffccc6dc79ff16c0433b59d51d5f48bfff5f2a9eadb9f22048c0ef5212e0f71&token=635007497&lang=zh_CN&scene=21#wechat_redirect)  
[你有没有注意那些能在私域里自传播的东西？](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485726&idx=1&sn=496a937c4d7360a83c311f52867df511&chksm=feb86a49c9cfe35f5c3a75d40886c7ba7680b10d130aab9c472d80bfe61228ebf065bd22bb90&token=635007497&lang=zh_CN&scene=21#wechat_redirect)

[电商](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzU5OTE2MDM3Ng==&action=getalbum&album_id=2018029515741986819#wechat_redirect) | [SEM](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzU5OTE2MDM3Ng==&action=getalbum&album_id=1634233881941884931#wechat_redirect) | [Python](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzU5OTE2MDM3Ng==&action=getalbum&album_id=1700951606508240897#wechat_redirect)

##### 付费文章

[用逆向思维收集大量被忽略的"声音"](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247484016&idx=1&sn=6eb962822951c704b5fe4ee4ce877ba6&chksm=feb86127c9cfe831164c1226594a2d8c9ff4517f3db14d0aaad26870e85970d51d9784327bef&payreadticket=HCN6R2uIyE-hxRPQfCKuTXGkhKpI_cSbOOKwskOfqmPZJBz0NyrdstHxaA2tNtgFKlQbaoA&scene=21#wechat_redirect)  
[程序员稳定的副业：如何做个小工具？](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485848&idx=1&sn=0b5c668e4ebe06b92babd12d679bcd08&chksm=feb86acfc9cfe3d9a4e2b9d5d12c865bcd106ed7ff3a43ee6fe0ba56bb8b0068de2c000ac34a&payreadticket=HPeOVpKPPuPIjYL0cZ1y1UEnfHxXSCvlpqDZA-keHvEVU35w4uC3xwezh-akrRmcp3IN8CQ&scene=21#wechat_redirect)  
[450个抖音类目，可能是2022年全网最全的](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486617&idx=1&sn=aa6087716c3b603f0297cfe36ef8bb93&chksm=feb86fcec9cfe6d836540b2b31b762aecd58758c3566d3d4e3e841fdc930dc09e15f7d85282a&payreadticket=HH63HOXgh_KT2_nz2EyXJYqXRb2Q4nYVhar94YnHM_nQLFHU0MZ6_2kUDbG8aCnj66hdnxg&scene=21#wechat_redirect)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpJcPCXasmEbSFOygEicQHGElhEibHheicN45y084Fw6NsDDZduDWIz9uOKia8ic20QuOvCt45nwIOHtnCw/640?wx_fmt=png)

据粉丝反馈，经常收不到推文，如果你不想错过，那么可以：[加我微信](http://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485860&idx=1&sn=52073ba58c5c70e2544440895af80a82&chksm=feb86af3c9cfe3e5af8e288e627af5c69b45197c2f40285734d26dc50723ea22eededea47e6a&scene=21#wechat_redirect)、星标公众号，或者分享点赞增加互动！👇

  

![](http://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLbYm2TI7kiameic7QEzKqbsk6jyHS4XpzpdnBgLOZOYzLO1eBLLOEN0CK2IJjjegG2kT7GRf7uZOnA/0?wx_fmt=png) 君言戏语

 ![](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3C!-- Icon from Lucide by Lucide Contributors - https://github.com/lucide-icons/lucide/blob/main/LICENSE --%3E%3Cg fill='none' stroke='%23888888' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'%3E%3Cpath d='M2.062 12.348a1 1 0 0 1 0-.696a10.75 10.75 0 0 1 19.876 0a1 1 0 0 1 0 .696a10.75 10.75 0 0 1-19.876 0'/%3E%3Ccircle cx='12' cy='12' r='3'/%3E%3C/g%3E%3C/svg%3E) 阅读![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M16.154 6.797l-.177 2.758h4.009c1.346 0 2.359 1.385 2.155 2.763l-.026.148-1.429 6.743c-.212.993-1.02 1.713-1.977 1.783l-.152.006-13.707-.006c-.553 0-1-.448-1-1v-8.58a1 1 0 0 1 1-1h2.44l1.263-.03.417-.018.168-.015.028-.005c1.355-.315 2.39-2.406 2.58-4.276l.01-.16.022-.572.022-.276c.074-.707.3-1.54 1.08-1.883 2.054-.9 3.387 1.835 3.274 3.62zm-2.791-2.52c-.16.07-.282.294-.345.713l-.022.167-.019.224-.023.604-.014.204c-.253 2.486-1.615 4.885-3.502 5.324l-.097.018-.204.023-.181.012-.256.01v8.218l9.813.004.11-.003c.381-.028.72-.304.855-.709l.034-.125 1.422-6.708.02-.11c.099-.668-.354-1.308-.87-1.381l-.098-.007h-5.289l.26-4.033c.09-1.449-.864-2.766-1.594-2.446zM7.5 11.606l-.21.005-2.241-.001v8.181l2.45.001v-8.186z' fill='%23000'/%3E%3C/svg%3E) 赞 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cpath d='M0 0h24v24H0z'/%3E    %3Cpath fill='%23576B95' d='M13.707 3.288l7.171 7.103a1 1 0 0 1 .09 1.32l-.09.1-7.17 7.104a1 1 0 0 1-1.705-.71v-3.283c-2.338.188-5.752 1.57-7.527 5.9-.295.72-1.02.713-1.177-.22-1.246-7.38 2.952-12.387 8.704-13.294v-3.31a1 1 0 0 1 1.704-.71zm-.504 5.046l-1.013.16c-4.825.76-7.976 4.52-7.907 9.759l.007.287c1.594-2.613 4.268-4.45 7.332-4.787l1.581-.132v4.103l6.688-6.623-6.688-6.623v3.856z'/%3E  %3C/g%3E%3C/svg%3E) 分享 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cdefs%3E    %3Cpath id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-a' d='M0 0h24v24H0z'/%3E  %3C/defs%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cmask id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-b' fill='%23fff'%3E      %3Cuse xlink:href='%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-a'/%3E    %3C/mask%3E    %3Cg mask='url(%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-b)'%3E      %3Cg transform='translate(0 -2.349)'%3E        %3Cpath d='M0 2.349h24v24H0z'/%3E        %3Cpath fill='%23576B95' d='M16.45 7.68c-.954 0-1.94.362-2.77 1.113l-1.676 1.676-1.853-1.838a3.787 3.787 0 0 0-2.63-.971 3.785 3.785 0 0 0-2.596 1.112 3.786 3.786 0 0 0-1.113 2.687c0 .97.368 1.938 1.105 2.679l7.082 6.527 7.226-6.678a3.787 3.787 0 0 0 .962-2.618 3.785 3.785 0 0 0-1.112-2.597A3.687 3.687 0 0 0 16.45 7.68zm3.473.243a4.985 4.985 0 0 1 1.464 3.418 4.98 4.98 0 0 1-1.29 3.47l-.017.02-7.47 6.903a.9.9 0 0 1-1.22 0l-7.305-6.73-.008-.01a4.986 4.986 0 0 1-1.465-3.535c0-1.279.488-2.56 1.465-3.536A4.985 4.985 0 0 1 7.494 6.46c1.24-.029 2.49.4 3.472 1.29l.01.01L12 8.774l.851-.85.01-.01c1.046-.951 2.322-1.434 3.59-1.434 1.273 0 2.52.49 3.472 1.442z'/%3E      %3C/g%3E    %3C/g%3E  %3C/g%3E%3C/svg%3E) 推荐 ![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M22.242 7a2.5 2.5 0 0 0-2.5-2.5h-14a2.5 2.5 0 0 0-2.5 2.5v8.5a2.5 2.5 0 0 0 2.5 2.5h2.5v1.59a1 1 0 0 0 1.707.7l1-1a.569.569 0 0 0 .034-.03l1.273-1.273a.6.6 0 0 0-.8-.892v-.006L9.441 19.1l.001-2.3h-3.7l-.133-.007A1.3 1.3 0 0 1 4.442 15.5V7l.007-.133A1.3 1.3 0 0 1 5.742 5.7h14l.133.007A1.3 1.3 0 0 1 21.042 7v4.887a.6.6 0 1 0 1.2 0V7z' fill='%23000' fill-opacity='.9'/%3E%3Crect x='14.625' y='16.686' width='7' height='1.2' rx='.6' fill='%23000' fill-opacity='.9'/%3E%3Crect x='18.725' y='13.786' width='7' height='1.2' rx='.6' transform='rotate(90 18.725 13.786)' fill='%23000' fill-opacity='.9'/%3E%3C/svg%3E) 留言