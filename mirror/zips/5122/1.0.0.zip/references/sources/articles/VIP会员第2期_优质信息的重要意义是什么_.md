     VIP会员第2期：优质信息的重要意义是什么？ \* { margin: 0; padding: 0; outline: 0; } body { font-family: "PingFang SC", system-ui, -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Hiragino Sans GB", "Microsoft YaHei UI", "Microsoft YaHei", Arial, sans-serif; line-height: 1.6; } .\_\_page\_content\_\_ { max-width: 667px; margin: 0 auto; padding: 20px; text-size-adjust: 100%; color: rgba(0, 0, 0, 0.9); padding-bottom: 64px; } .title { user-select: text; font-size: 22px; line-height: 1.4; margin-bottom: 14px; font-weight: 500; } .\_\_meta\_\_ { color: rgba(0, 0, 0, 0.3); font-size: 15px; line-height: 20px; hyphens: auto; word-break: break-word; margin-bottom: 50px; } .\_\_meta\_\_ .nick\_name { color: #576B95; } .\_\_meta\_\_ .copyright { color: rgba(0, 0, 0, 0.3); background-color: rgba(0, 0, 0, 0.05); padding: 0 4px; margin: 0 10px 10px 0; } blockquote.source { padding: 10px; margin: 30px 0; border-left: 5px solid #ccc; color: #333; font-style: italic; word-wrap: break-word; } blockquote.source a { cursor: pointer; text-decoration: underline; } .item\_show\_type\_0 > section { margin-top: 0; margin-bottom: 24px; } a { color: #576B95; text-decoration: none; cursor: default; } .text\_content { margin-bottom: 50px; user-select: text; font-size: 17px; white-space: pre-wrap; word-wrap: break-word; line-height: 28px; hyphens: auto; } .picture\_content .picture\_item { margin-bottom: 30px; } .picture\_content .picture\_item .picture\_item\_label { text-align: center; } img { max-width: 100%; } .pay\_subscribe\_notice { margin: 30px 0; padding: 20px; background: #fffbe6; border: 1px solid #ffe58f; border-radius: 8px; } .pay\_subscribe\_badge { display: inline-block; padding: 4px 12px; background: #faad14; color: #fff; border-radius: 4px; font-size: 14px; font-weight: 500; margin-bottom: 12px; } .pay\_subscribe\_desc { font-size: 15px; line-height: 1.8; color: rgba(0, 0, 0, 0.7); margin-bottom: 12px; } .pay\_subscribe\_hint { font-size: 13px; color: rgba(0, 0, 0, 0.4); } .\_\_bottom-bar\_\_ { display: flex; justify-content: space-between; align-items: center; position: fixed; bottom: 0; left: 0; right: 0; height: 64px; padding: 8px 20px; background: white; box-sizing: border-box; border-top: 1px solid rgba(0, 0, 0, 0.2); } .\_\_bottom-bar\_\_ .left { display: flex; align-items: center; font-size: 15px; white-space: nowrap; } .\_\_bottom-bar\_\_ .right { display: flex; } .\_\_bottom-bar\_\_ .sns\_opr\_btn { display: flex; align-items: center; user-select: none; background: transparent; border: 0; color: rgba(0, 0, 0, 0.9); font-size: 14px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn:not(:last-child) { margin-right: 16px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn > img { margin-right: 4px; }

VIP会员第2期：优质信息的重要意义是什么？
======================

原创 o君言o 君言戏语 2024-12-30 16:30 福建

> 原文地址: [https://mp.weixin.qq.com/s/DXLCBP0\_L\_Ogkp6IdcsIRA](https://mp.weixin.qq.com/s/DXLCBP0_L_Ogkp6IdcsIRA)

时间很快，一年的VIP服务已经结束，上周开启了第二期。

在去年开启后，当天大概是进了200出头的成员，一周后大概又增加100左右。

这是主要的跨越一整年的成员，截止目前粗算续费了70%左右。

  

对于我这种不带项目的、不是垂直类目的社群，这个续费率其实是不错的。

但是对于我来说，还没及格，我心里的及格线是80%，满意的是90%。

  

事实上这一年在自媒体这块业务中，我就没做其他事情，时间基本花在了VIP服务上了；

要做到全部人满意显然不行，但我认为我应该可以做到大部分人认可。

从数据上来看有点勉强，所以我也在思考这一年提供的服务。

  

这一年给社群输出了两篇文章，**其中一篇是付费级中的付费级**，标题我都没命名，就不希望它作为一个具体对象被人传播。

光这一篇的价值，几百块都不止；当然，不同人不同看法。

也有建了一些小组，输出了一些结果，但我觉得做得并不好，所以小组的运作今年有调整。

目前就还有个seo学习小组。

最主要的服务，是**输出了150条信息**，这些信息题目可以稍后文章底部查看。

  

这些内容很多不会是寻常渠道有人在讨论的，一些高价社群也看不到。

确实也给很多会员增加了不少见识。

我月初做了一份年终评价，有参与的人是180多位，**表单是完全匿名的**。

目前为止，**这份表单没有收到差评**。

  

下图是第一道题目：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpKl5CUWfUFEOz66rH6djnsLNKtL4bZGXOm4qMr2hibLvMNxDqMvLsexLX3RlYXoCoo2yhCLtGiaPHUg/640?&wx_fmt=jpeg)

近90%是愿意推荐，其中几位不愿意推荐的会员，下面是他们的补充：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpKl5CUWfUFEOz66rH6djnsL1FUyRiccIXW9S10SSBPkoNmbGMktDaIj10tHicotiahIXkR4ib6c2zgSWg/640?&wx_fmt=jpeg)

  

下图是第二道题目：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpKl5CUWfUFEOz66rH6djnsLX5yLsFbGP8t3oN6DRN3VPiao3ZtIIY1ypiaPn72shoF9qy5AnIwuL7OQ/640?&wx_fmt=jpeg)

一半一半；有些人觉得正常涨100就行，有些人觉得可以更高。

下面是选“更高”的人给的数值：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpKl5CUWfUFEOz66rH6djnsLaM2UFG1p7r45pUYl7m5V7NToWkpNxgk307bNqwmDymT7OExk81dmiag/640?&wx_fmt=jpeg)

有些是觉得可以更高一点，有些是捧个场表示认可，小部分大佬是希望它更高。

  

下图是第三道题目：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpKl5CUWfUFEOz66rH6djnsLsNJiaQamw3MBicqiaVgoRxIX3rDDDW4zVSJeic8YBa7cibJKBHz11XakXzw/640?&wx_fmt=jpeg)

让我意外的是竞价项目在最后面；

思考方式获得最高投票，也许有些人不理解，不能直接赚钱的东西有什么用？

所谓的思考方式是什么，比如：

同样是百度识图，我能用出不一样的价值，见上一篇文章；又比如同样是虚拟资源挖掘，我能使用别人想不到的角度；

那么能赚钱吗？不知道，要看个人！

  

第四题是“用一句话评价群里提供的内容”，下面是所有评价(可左右拖动)：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpKl5CUWfUFEOz66rH6djnsLNw4ibVicKibOWCL84RkYBrVrXJZnX6cUYvUYtesBEFqmTpfm8semSAHnQ/640?&wx_fmt=png)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpKl5CUWfUFEOz66rH6djnsLCo5d4JDYtLdSAeU5y5GjmcVeVhJ8GFf4HiafNaclbIQgHvBK0laDibiaw/640?&wx_fmt=png)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpKl5CUWfUFEOz66rH6djnsLx4ub4V7f6kY73Ze8r4Sdur00YAZ0ibzoVvVezmTprTp9iaBoR5IBltBg/640?&wx_fmt=png)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpKl5CUWfUFEOz66rH6djnsLWm6WuIichm5oLJiaBLoACGM0DicwrJ0fgBC8eADYzLujsUIGdTYBACtYw/640?&wx_fmt=png)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpKl5CUWfUFEOz66rH6djnsLxiaDdaeQFAo9qs6B4tNVskSLj22K5BxpZEXYibYwo0jh6gibm8gB95KicA/640?&wx_fmt=png)

<<< 左右滑动见更多 >>>

在截图的时候我多看了一眼，确实是没有什么明显的差评，有几条算中评。

这里要特别感谢给与评价的朋友们！

有些朋友该续费续费，但是他没时间给你评价，有些朋友可能是不满意，不想评价，这应该也是有的。

  

最后一道题是投票出所有分享里的No.1，这条No.1的分享是：`**业务矩阵公众号`。

这条分享讲的是某个本地同城业务在公众号矩阵运营，买卖广告位的模式，一个月的收益可能是几万甚至小几十。

这个模式看起来简单粗暴，难得的是在8年前有这样的想法并做到了现在，背后团队赚的钱不好想象。

我们希望发现的就是别人这种**有意思的模式、创造性的思维**。

  
  

目前还没有续费的人里，只有10位左右是明确跟我说暂不续费了；

这里面有几个人的意思是一样的：

思维很棒，思路很有价值，但他不知道怎么落地。

  

为什么说竞价项目的分享在评价里排在最后让我意外呢。

事实上竞价项目以及其他一些分享的项目，我自己是挺看好的，

个别项目我是很看好并打算安排人做的，我会分享就说明一种态度。

而且有些项目我知道群里有人已经在做的，这些人或有经验、或有团队、或有执行力。

  

所以按说项目是不错，只不过落地有门槛；

比如竞价项目，有些人没有做过，他甚至不知道怎么开户，也不一定有广告预算可以尝试，

所以即使看起来很好，但是他落不了地，也就不会很期待。

当然这里也有我引导不够的因素在，有些项目虽然发现于竞价，但不代表只能做竞价。

  

这个问题我是这么想的，分三个角度：

首先还是要明确我自己的定位，本身我就不是卖项目和带赚钱的服务；

我就是课程和文章被频繁盗版才开的VIP会员。

这个服务是**基于我的经验为大家提供相对优质的信息**，一些思路、技巧、模式、项目。

  

它适合：

有经验可以自己运用的人、有团队可以快速启动的人、想要借鉴更多思维的人；以及基础薄弱的人开阔视野看到更多想象不到的。

但并不适合：

希望有人带着做项目的朋友，这个服务他本身就不是做这个事的，我也不擅长带项目。

  

其次，也应该增加一些实操的细节或落地的关键，降低一些会员的尝试成本。

所以在分享的相关项目上，以后会侧重多写一些操作方面的问题。

  

今年想让自己这边先做一些项目，稳定之后再拿出来开个实操小组看看。

也不是带着做，只是像之前闲鱼那样给一个大致的流程框架，大家自己试试，有问题在里面交流。

重要的意义在于，这个东西我拿出来了，那肯定是测试过了，参与的成员不用怀疑项目，而是考虑自己怎么去做好它。

  

再一点，群里的会员都看过我分享的一些业务，细品一下这些业务，很多是一种：

`小生意`、`小产品`、`小服务`

无论是群里的会员，还是公众号的读者，其实大家细想一个问题：

`自动取英文名服务` 和 `公众号爆文项目`，后者大家应该在各种社群看过，还有各种训练营。

这两者的差别在于：

后者是可以一堆人一起实操的，反正大家做不同内容，一起薅平台收益，互不干扰；

但是前者呢？几百个人做几百个一样的程序投入市场？那最终有谁能赚钱。

  

前者，它一般情况下，**只有服务方和被服务方参与**，如果你不是特意去发现，你注意不到这个东西，**也想象不到它可能的收益**；

后者，你流量大起来一定会被人注意到，你的流量能赚多少钱别人也能推测出来大概；

你做的这件事情有一堆人在标准化培训，那么大概是赚不到持续化的收益的。

**我的方向是前者，不是后者**。

  

前段时间有位会员在群里晒了一张截图，上面显示的支付总单数是10万笔多一点，支付总金额我就不说了，群里大家都能看到！

他说他这个项目和我在群里分享的一个项目是基本一模一样的。

具体是哪个项目他会说吗，不可能的，谁也不会具体问。

哪怕是这几句话，我也是经过他同意的，毕竟有心的人稍微多给他一点信息，窗户纸就破了。

  

所以我认为：

可以钻研培训的项目，可以参加训练营，可以追求保姆级的教程等等，但你自己得清楚性质，知道你大概是在赚着什么样的钱；

真正那些被人捂在角落里偷偷赚钱的东西你可能看得到，**但你不可能听得到有人亲口告诉你它一天可以赚几千几万**，更不说带着做。

> 优质信息服务的重要意义就在于：先让你能看到，再帮你起到提示和强调的作用；过多解释会让信息不再优质。

**赚钱与普通人无关**！

什么是普通人，这是相对的，如果一个项目的核心是依靠技术赚钱，你不会技术，那你就是这个项目对应的普通人；

然后你说你想试试能不能跟这些会技术的竞争一下，这个逻辑就是有问题的，**应该考虑的是如何让自己会点技术**。

**任何事物因有门槛而有价值**。

  
  
  

今年VIP费用还是原先计划的定在`699`；

在上一年[VIP第一期](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247488956&idx=1&sn=bd2ad3f7f01983dceab57388588a3079&token=418323661&lang=zh_CN&scene=21#wechat_redirect)的基础上，增加了一些服务，除了前面说的实操小组之外，还包括：

**信息监控**：

过往我的一些挖掘信息的策略，有一部分可以使用技术自动化形成监控的方式来提供服务。

新的广告、新的词汇、新的热点、新的资源 等等，通过一些策略去定向抓取。

**搜索词报告**：

对特定领域的搜索词进行需求类别的分析，让大家看到该领域清晰的意图分类，寻找有机会的需求。

**出海研究**：

现在出海很火热，老实说这方面我没有多少经验，只不过我看群里不少人都在研究这方面或者有这方面的业务在做着。

现在出海相关的一些项目，研究的东西其实没有很复杂，玩法都差不多，只是整个环境我比较陌生；

群里也有几位出海大佬私下建议我去研究研究，用我的这些经验去看看有没有不一样的角度、想法、思路。

所以明年我想尝试研究一下，然后提供一点我的想法，只不过我自己得先去新手村走一趟。

  

其他方面的服务或权益基本上与上一期差不多；

就是针对性的咨询太累了，不再对外承诺提供了，确实有麻烦的问题我还是可以帮忙解答的，

一般我给的咨询回复还都能得到满意结果，光一个咨询感觉值回门票的也有好几位表示。

这也是我给会员的权益，只是不承诺我压力会小一点……

  

这篇文章除了给后续考虑加入的人一些简单了解之外，最重要的还是明确一下定位：

**我能提供的以及我不能提供的**；也希望大家对我的付费选择是清楚的、是明确的。

  

类似我这种性质的服务，不是垂类不是具体项目，并不讨好，人数也不会很多。

但是我对会员的人数也只打算最多最多到1000；不限制数量，信息的质量会被稀释，

超过这个数，服务成本增加，我就真的要找人来一起运营了，

那我岂不是又要回到上班的感觉，这不适合我……

  

最后，感谢过往所有认可过和支持过的会员，**是大家一起提供了这个信息窗口**。

查看过往分享题目可点击下方，发送字母：`vip`

  

![](http://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLbYm2TI7kiameic7QEzKqbsk6jyHS4XpzpdnBgLOZOYzLO1eBLLOEN0CK2IJjjegG2kT7GRf7uZOnA/0?wx_fmt=png) 君言戏语

 ![](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3C!-- Icon from Lucide by Lucide Contributors - https://github.com/lucide-icons/lucide/blob/main/LICENSE --%3E%3Cg fill='none' stroke='%23888888' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'%3E%3Cpath d='M2.062 12.348a1 1 0 0 1 0-.696a10.75 10.75 0 0 1 19.876 0a1 1 0 0 1 0 .696a10.75 10.75 0 0 1-19.876 0'/%3E%3Ccircle cx='12' cy='12' r='3'/%3E%3C/g%3E%3C/svg%3E) 阅读![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M16.154 6.797l-.177 2.758h4.009c1.346 0 2.359 1.385 2.155 2.763l-.026.148-1.429 6.743c-.212.993-1.02 1.713-1.977 1.783l-.152.006-13.707-.006c-.553 0-1-.448-1-1v-8.58a1 1 0 0 1 1-1h2.44l1.263-.03.417-.018.168-.015.028-.005c1.355-.315 2.39-2.406 2.58-4.276l.01-.16.022-.572.022-.276c.074-.707.3-1.54 1.08-1.883 2.054-.9 3.387 1.835 3.274 3.62zm-2.791-2.52c-.16.07-.282.294-.345.713l-.022.167-.019.224-.023.604-.014.204c-.253 2.486-1.615 4.885-3.502 5.324l-.097.018-.204.023-.181.012-.256.01v8.218l9.813.004.11-.003c.381-.028.72-.304.855-.709l.034-.125 1.422-6.708.02-.11c.099-.668-.354-1.308-.87-1.381l-.098-.007h-5.289l.26-4.033c.09-1.449-.864-2.766-1.594-2.446zM7.5 11.606l-.21.005-2.241-.001v8.181l2.45.001v-8.186z' fill='%23000'/%3E%3C/svg%3E) 赞 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cpath d='M0 0h24v24H0z'/%3E    %3Cpath fill='%23576B95' d='M13.707 3.288l7.171 7.103a1 1 0 0 1 .09 1.32l-.09.1-7.17 7.104a1 1 0 0 1-1.705-.71v-3.283c-2.338.188-5.752 1.57-7.527 5.9-.295.72-1.02.713-1.177-.22-1.246-7.38 2.952-12.387 8.704-13.294v-3.31a1 1 0 0 1 1.704-.71zm-.504 5.046l-1.013.16c-4.825.76-7.976 4.52-7.907 9.759l.007.287c1.594-2.613 4.268-4.45 7.332-4.787l1.581-.132v4.103l6.688-6.623-6.688-6.623v3.856z'/%3E  %3C/g%3E%3C/svg%3E) 分享 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cdefs%3E    %3Cpath id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-a' d='M0 0h24v24H0z'/%3E  %3C/defs%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cmask id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-b' fill='%23fff'%3E      %3Cuse xlink:href='%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-a'/%3E    %3C/mask%3E    %3Cg mask='url(%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-b)'%3E      %3Cg transform='translate(0 -2.349)'%3E        %3Cpath d='M0 2.349h24v24H0z'/%3E        %3Cpath fill='%23576B95' d='M16.45 7.68c-.954 0-1.94.362-2.77 1.113l-1.676 1.676-1.853-1.838a3.787 3.787 0 0 0-2.63-.971 3.785 3.785 0 0 0-2.596 1.112 3.786 3.786 0 0 0-1.113 2.687c0 .97.368 1.938 1.105 2.679l7.082 6.527 7.226-6.678a3.787 3.787 0 0 0 .962-2.618 3.785 3.785 0 0 0-1.112-2.597A3.687 3.687 0 0 0 16.45 7.68zm3.473.243a4.985 4.985 0 0 1 1.464 3.418 4.98 4.98 0 0 1-1.29 3.47l-.017.02-7.47 6.903a.9.9 0 0 1-1.22 0l-7.305-6.73-.008-.01a4.986 4.986 0 0 1-1.465-3.535c0-1.279.488-2.56 1.465-3.536A4.985 4.985 0 0 1 7.494 6.46c1.24-.029 2.49.4 3.472 1.29l.01.01L12 8.774l.851-.85.01-.01c1.046-.951 2.322-1.434 3.59-1.434 1.273 0 2.52.49 3.472 1.442z'/%3E      %3C/g%3E    %3C/g%3E  %3C/g%3E%3C/svg%3E) 推荐 ![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M22.242 7a2.5 2.5 0 0 0-2.5-2.5h-14a2.5 2.5 0 0 0-2.5 2.5v8.5a2.5 2.5 0 0 0 2.5 2.5h2.5v1.59a1 1 0 0 0 1.707.7l1-1a.569.569 0 0 0 .034-.03l1.273-1.273a.6.6 0 0 0-.8-.892v-.006L9.441 19.1l.001-2.3h-3.7l-.133-.007A1.3 1.3 0 0 1 4.442 15.5V7l.007-.133A1.3 1.3 0 0 1 5.742 5.7h14l.133.007A1.3 1.3 0 0 1 21.042 7v4.887a.6.6 0 1 0 1.2 0V7z' fill='%23000' fill-opacity='.9'/%3E%3Crect x='14.625' y='16.686' width='7' height='1.2' rx='.6' fill='%23000' fill-opacity='.9'/%3E%3Crect x='18.725' y='13.786' width='7' height='1.2' rx='.6' transform='rotate(90 18.725 13.786)' fill='%23000' fill-opacity='.9'/%3E%3C/svg%3E) 留言