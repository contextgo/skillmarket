     来了，vip专属社群，仅有一次的价格！ \* { margin: 0; padding: 0; outline: 0; } body { font-family: "PingFang SC", system-ui, -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Hiragino Sans GB", "Microsoft YaHei UI", "Microsoft YaHei", Arial, sans-serif; line-height: 1.6; } .\_\_page\_content\_\_ { max-width: 667px; margin: 0 auto; padding: 20px; text-size-adjust: 100%; color: rgba(0, 0, 0, 0.9); padding-bottom: 64px; } .title { user-select: text; font-size: 22px; line-height: 1.4; margin-bottom: 14px; font-weight: 500; } .\_\_meta\_\_ { color: rgba(0, 0, 0, 0.3); font-size: 15px; line-height: 20px; hyphens: auto; word-break: break-word; margin-bottom: 50px; } .\_\_meta\_\_ .nick\_name { color: #576B95; } .\_\_meta\_\_ .copyright { color: rgba(0, 0, 0, 0.3); background-color: rgba(0, 0, 0, 0.05); padding: 0 4px; margin: 0 10px 10px 0; } blockquote.source { padding: 10px; margin: 30px 0; border-left: 5px solid #ccc; color: #333; font-style: italic; word-wrap: break-word; } blockquote.source a { cursor: pointer; text-decoration: underline; } .item\_show\_type\_0 > section { margin-top: 0; margin-bottom: 24px; } a { color: #576B95; text-decoration: none; cursor: default; } .text\_content { margin-bottom: 50px; user-select: text; font-size: 17px; white-space: pre-wrap; word-wrap: break-word; line-height: 28px; hyphens: auto; } .picture\_content .picture\_item { margin-bottom: 30px; } .picture\_content .picture\_item .picture\_item\_label { text-align: center; } img { max-width: 100%; } .pay\_subscribe\_notice { margin: 30px 0; padding: 20px; background: #fffbe6; border: 1px solid #ffe58f; border-radius: 8px; } .pay\_subscribe\_badge { display: inline-block; padding: 4px 12px; background: #faad14; color: #fff; border-radius: 4px; font-size: 14px; font-weight: 500; margin-bottom: 12px; } .pay\_subscribe\_desc { font-size: 15px; line-height: 1.8; color: rgba(0, 0, 0, 0.7); margin-bottom: 12px; } .pay\_subscribe\_hint { font-size: 13px; color: rgba(0, 0, 0, 0.4); } .\_\_bottom-bar\_\_ { display: flex; justify-content: space-between; align-items: center; position: fixed; bottom: 0; left: 0; right: 0; height: 64px; padding: 8px 20px; background: white; box-sizing: border-box; border-top: 1px solid rgba(0, 0, 0, 0.2); } .\_\_bottom-bar\_\_ .left { display: flex; align-items: center; font-size: 15px; white-space: nowrap; } .\_\_bottom-bar\_\_ .right { display: flex; } .\_\_bottom-bar\_\_ .sns\_opr\_btn { display: flex; align-items: center; user-select: none; background: transparent; border: 0; color: rgba(0, 0, 0, 0.9); font-size: 14px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn:not(:last-child) { margin-right: 16px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn > img { margin-right: 4px; }

来了，vip专属社群，仅有一次的价格！
===================

原创 o君言o 君言戏语 2023-12-18 11:01 福建

> 原文地址: [https://mp.weixin.qq.com/s/jHy8pETXs0JTbO8En-9mjQ](https://mp.weixin.qq.com/s/jHy8pETXs0JTbO8En-9mjQ)

上个月关于“盗版”问题的文章发出之后，收到了不少来信，文章评论都翻了几倍，还顺带炸出了一些平时不怎么交流的读者朋友。

来信的朋友关于“公众号”、“付费内容”、“vip方案”、“技术手段”等；

不吝赐教的给了我很多建议，有些朋友特意过来红包“反馈”，**因为我以往的输出，他们所获得的一些收益**。

总的来说，还是很感谢信任！

  

而关于“vip读者”的方案，一些朋友表示要**闭眼入**，这让我更加慎重，毕竟这不是写文章那样爱写就写。

在思考一番之后，我做了一份初步的规划，这里面有一些我觉得不错的**闪光点**，所以决定尝试看看。

对于“vip读者”，我会在保持“内容”的前提，把侧重点放在“服务”上，这也避免了各种“复制”。

下面我来说说我想怎么做这个事情：

  

`vip读者`

公众号“君言戏语”的会员，为期一年。

  

`vip读者权益`

`1：专属内容`

**1.1：付费级文章**

付费级别的文章，至少1份，期限内不定时提供，只对vip读者推送。

**1.2：统计数据or分析报告**

统计数据集、分析报告文档等，至少2份，分上下半年分享，只对vip读者推送。

**1.3：其他**

免费之上、付费之下的短篇幅内容，可能是一些思考、一些小思路；不定量、不定时，只对vip读者推送。

  

`2：专属权益`

**2.1：针对性咨询**

在期限内一人一次的针对性咨询：围绕一个详细描述的问题，提供我的建议和指导，以一份文档回答。

比如：新项目的选择、项目运营过程中的问题、付费事项的评估、行业相关的疑问、前景发展规划等。

**2.2：专享优惠**

公众号发布的课程、软件、服务或其他付费产品等，均有专享的折扣优惠，**1000元以下的，直接5折**。

**2.3：优先内侧**

新出的软件、脚本，可以优先内侧使用，有时候一些不对外的脚本，可以内部使用，有提供即免费。

本来还有考虑一些项目实操的内侧，不过这点放在下面了。

**2.4：其他**

微信及时响应(在我看到的情况下)，小问题直接发。

后续可能的资源对接、置换、推荐、合作等，这点待定。

另外其实还有个饼，暂时就不画了，等真的饼出来再直接吃吧。

  

`3：专属微信群`

**3.1：基础功能**

消息同步、信息分发、通知提醒、问题反馈等，是我和vip读者的沟通窗口。

**3.2：增值信息**

这个版块由我个人提供，以我的视角，用我的挖掘方式为大家提供：

有意思的需求、比较好的产品、不错的业务、新颖的模式、奇妙的思路、有价值的知识点、付费经验等等；

不只是简单的知道某个信息，尽可能是大家可以模仿或者具有借鉴价值的内容，因为除了基本描述，我还会加上我自己的理解和思考或建议。

另外偶尔也会晒一下我自己在思考某些问题时的角度、分析的内容等等。

  

这些信息我会尽量在一年下来约有**100条**左右的量，大概3-4天一条。

但是：**不为分享而分享**，是我觉得有、我看到了觉得不错，我就分享。

不会是因为这一周是最后一天了所以我必须“整”一条出来。

  

群成员也可以分享，但是暂时禁止利益相关的分享，比如你的文章、产品、社群等。

如果你希望引起别人的注意或关注，请通过一些简短的观点、经验、思路、案例。

毕竟，其他成员很难判断这位非“群主”的人分享某篇内容是不是为了广告。

**精简信息**，让成员减少信息焦虑、减少判断成本。

**3.3：日常交流**

社群不闲聊！拒绝任何情绪化观点，没有鸡汤和大道理，不聊人生感悟。

可以提问、可以简单交流，有事说事；话题结束后该干嘛干嘛，三言两语说不清的问题，请私聊。

因为会员群**主要是用来获取信息**，不做讨论，我们留有额外讨论的地方，见下文！

  

没有嘉宾分享、没有定时推送，不设置任何固定化的内容版块。

毕竟，嘉宾基本是潜水的，定时推送的内容都是用来收藏的，**为了分享而分享的内容会慢慢失去价值**。

群里没有大佬、老板、KOL，大家只是在群里互换经验，平等交流！

**3.4：隐藏增值**

有一些想法，还在想，会有的，当做彩蛋吧。

  

`4：小组制`

**小组制是对vip读者的重点服务版块**，当前分为三个类别：

**4.1：实践小组**

市面上比较火热的项目、我有过经验的项目、我觉得不错的项目等等，我们拉一个兴趣小组出来，大家一起去实操一下这个项目。

如果是我有过经验的，比如我跑通过的(类似之前闲鱼那样)，又或者我在内测的一些策略方法，那我可以整理出主要的核心步骤和策略，让大家优先做看看。

如果是大家感兴趣的，但是我并没有做过，那我会在过程中用我的经验给大家建议和指导。

  

这件事情我没有额外再收钱，但是我也不管谁赚不赚钱，它不是带赚钱的训练营，它的首要意义是实操经验。

**4.2：讨论小组**

这是我比较愿意做的事情，也是我强推的一件事情。

我在引流课里教大家挖掘目标群体的特征，哪怕是想个10天8天都没问题，这其实是一个头脑风暴的过程。

但是一个人的思维是有限的，容易走入死胡同，**思维之间需要碰撞才会产生火花**。

  

那么比如我在群里问：**都市银发这个群体有什么特征**？

如果你刚好对这个群体感兴趣或者正在经营对标他们的业务，那我们马上拉一个兴趣小组；

在未来的十天半个月里，我们就思考这一个问题，任何人有想到一点就往群里丢：

今天他说：有退休金、明天你说：时间充裕、后天我说：有基本文化水平，然后有个人看到你说的“时间充裕”进而想到了“经常旅游”这个特征 ……

谁有想到就往里发，没想到也不用刻意表达，看看别人发的答案，记着这个事情，突然哪天灵光一闪想到一个好的角度就丢里面。

就这样，十天半个月甚至更长时间后，对于这个问题我们已经无法再给出新的认识了；

这个时候由我来梳理总结，或者我梳理之后做个表单让大家对每一项打分，经过总结之后最终：**整个小组的人对于这个问题就有了全新的认识和理解**。

这是我们所有人思考的结晶，然后这份理解就可以马上应用到你的工作中：

这个群体的文案怎么写？针对他们做什么营销手段？什么样的引流方式效果会更好？什么样的营销话术会更容易转化？怎么针对他们的诉求设计产品？

这些困扰你的老问题就有了新的思路。

  

类似的问题还可以是：某某产品的用户应该有什么需求、某某技术可以有什么应用；某某业务有什么推广方案、某个品类的视频可以怎么来拍、提升某个环节的转化可以有什么策略 等等。

这些话题可以由我或成员发起，或者几个话题大家投票来选择。

  

兴趣小组的重点在于兴趣，你对这个话题有兴趣，不管你有没有经验！

你有兴趣，并且愿意参与其中，一起思考和讨论，看着这个“答案”一点一点的“饱满”起来，你参与着整个思考过程，你的理解会更加深刻。

而勇于表达自己的想法，实际上是**给自己一个检验自己思考的机会**，你不说，可能一直没机会能发现自己的想法有多幼稚，这太正常了。

经常参与这样的思考，可以锻炼自己的思考力，以后碰到类似的问题，思考的速度会快很多。

至于我可以在里面起到的作用可以是：

抛砖引玉、引导思考方向、纠正明显误区、点评一些想法(给与我不同的看法)、梳理总结等等，让讨论可以顺利进行，因为我经常做这样的思考。

当然，实际执行过程中还会有些细节问题，这也是初步的想法，还可以再设计。

**4.3：学习小组**

同样是拉一个兴趣小组，一起去学习一个技能。

可以是我教大家的(免费)，也可以是找一份公开资源一起来学习，最终的结果是大家一起把这个技能啃下来。

不过学习小组暂时不保证有。

  

以上就是小组制的说明介绍。

实践小组是通过实操获得新的经验、学习小组是通过学习获得新的技能、讨论小组是通过交流发现新的思维；

三者分别对应：经验、技能、思路，它们代表着长久的能力。

最重要的地方在于：参与！

  

我其实更愿意做“讨论小组”这件事情，我认为它的价值会更大，大很多。

况且，在一年内有限的时间里，实践小组和学习小组肯定是无法频繁组织的，成本很高，而讨论小组可以每月举行甚至同步举行。

讨论小组的成本较低，产生的价值却很大，比如：吃透某个品类的用户需求、诉求、心理、想法，价值无限大。

  

以上是所有vip会员的权益，也就是我要交付的内容。

一般来说，我是少承诺再给超预期的价值，所以最后的交付一定会比现在提到的多。

  

`事项说明`

`1：时长类型`

统一采用固定到期时间，即每年的`12.18`统一到期。

刚推出一两个月我可能还会陆续推一下，过后就可以不再推了，也能专心做好服务，另外也方便统一管理。

`2：vip费用`

这一期的费用是：`599元`。

我个人比较理想化的费用是在`1000元`左右，这个价位不高不低。

现有的服务其实是完全以我为核心，交付有点重，单独拧出小组制的服务，也不止这个价格。

  

我是想反正第一期，暂时人不会很多，我先做看看，第二期继续办肯定会涨，如果我觉得做得不错，费用就直接一步到位。

不过有一个规则，就是**价格锁定制**，你第一次加入是什么价格，后续怎么涨都跟你没关系。

  

`成为vip读者`

有我微信的直接滴我，请不要直接转账。

没有微信的请添加：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpK0YCp3akzK4GJiaZmjURaI9zaRYtY3kjrYiachKEicibXDP83JqbVGn0u40OBdmd9m5ymfpCtABGNo0w/640?wx_fmt=png&wxfrom=5&wx_lazy=1&wx_co=1)

添加时请备注字母：v

![](http://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLbYm2TI7kiameic7QEzKqbsk6jyHS4XpzpdnBgLOZOYzLO1eBLLOEN0CK2IJjjegG2kT7GRf7uZOnA/0?wx_fmt=png) 君言戏语

 ![](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3C!-- Icon from Lucide by Lucide Contributors - https://github.com/lucide-icons/lucide/blob/main/LICENSE --%3E%3Cg fill='none' stroke='%23888888' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'%3E%3Cpath d='M2.062 12.348a1 1 0 0 1 0-.696a10.75 10.75 0 0 1 19.876 0a1 1 0 0 1 0 .696a10.75 10.75 0 0 1-19.876 0'/%3E%3Ccircle cx='12' cy='12' r='3'/%3E%3C/g%3E%3C/svg%3E) 阅读![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M16.154 6.797l-.177 2.758h4.009c1.346 0 2.359 1.385 2.155 2.763l-.026.148-1.429 6.743c-.212.993-1.02 1.713-1.977 1.783l-.152.006-13.707-.006c-.553 0-1-.448-1-1v-8.58a1 1 0 0 1 1-1h2.44l1.263-.03.417-.018.168-.015.028-.005c1.355-.315 2.39-2.406 2.58-4.276l.01-.16.022-.572.022-.276c.074-.707.3-1.54 1.08-1.883 2.054-.9 3.387 1.835 3.274 3.62zm-2.791-2.52c-.16.07-.282.294-.345.713l-.022.167-.019.224-.023.604-.014.204c-.253 2.486-1.615 4.885-3.502 5.324l-.097.018-.204.023-.181.012-.256.01v8.218l9.813.004.11-.003c.381-.028.72-.304.855-.709l.034-.125 1.422-6.708.02-.11c.099-.668-.354-1.308-.87-1.381l-.098-.007h-5.289l.26-4.033c.09-1.449-.864-2.766-1.594-2.446zM7.5 11.606l-.21.005-2.241-.001v8.181l2.45.001v-8.186z' fill='%23000'/%3E%3C/svg%3E) 赞 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cpath d='M0 0h24v24H0z'/%3E    %3Cpath fill='%23576B95' d='M13.707 3.288l7.171 7.103a1 1 0 0 1 .09 1.32l-.09.1-7.17 7.104a1 1 0 0 1-1.705-.71v-3.283c-2.338.188-5.752 1.57-7.527 5.9-.295.72-1.02.713-1.177-.22-1.246-7.38 2.952-12.387 8.704-13.294v-3.31a1 1 0 0 1 1.704-.71zm-.504 5.046l-1.013.16c-4.825.76-7.976 4.52-7.907 9.759l.007.287c1.594-2.613 4.268-4.45 7.332-4.787l1.581-.132v4.103l6.688-6.623-6.688-6.623v3.856z'/%3E  %3C/g%3E%3C/svg%3E) 分享 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cdefs%3E    %3Cpath id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-a' d='M0 0h24v24H0z'/%3E  %3C/defs%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cmask id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-b' fill='%23fff'%3E      %3Cuse xlink:href='%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-a'/%3E    %3C/mask%3E    %3Cg mask='url(%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-b)'%3E      %3Cg transform='translate(0 -2.349)'%3E        %3Cpath d='M0 2.349h24v24H0z'/%3E        %3Cpath fill='%23576B95' d='M16.45 7.68c-.954 0-1.94.362-2.77 1.113l-1.676 1.676-1.853-1.838a3.787 3.787 0 0 0-2.63-.971 3.785 3.785 0 0 0-2.596 1.112 3.786 3.786 0 0 0-1.113 2.687c0 .97.368 1.938 1.105 2.679l7.082 6.527 7.226-6.678a3.787 3.787 0 0 0 .962-2.618 3.785 3.785 0 0 0-1.112-2.597A3.687 3.687 0 0 0 16.45 7.68zm3.473.243a4.985 4.985 0 0 1 1.464 3.418 4.98 4.98 0 0 1-1.29 3.47l-.017.02-7.47 6.903a.9.9 0 0 1-1.22 0l-7.305-6.73-.008-.01a4.986 4.986 0 0 1-1.465-3.535c0-1.279.488-2.56 1.465-3.536A4.985 4.985 0 0 1 7.494 6.46c1.24-.029 2.49.4 3.472 1.29l.01.01L12 8.774l.851-.85.01-.01c1.046-.951 2.322-1.434 3.59-1.434 1.273 0 2.52.49 3.472 1.442z'/%3E      %3C/g%3E    %3C/g%3E  %3C/g%3E%3C/svg%3E) 推荐 ![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M22.242 7a2.5 2.5 0 0 0-2.5-2.5h-14a2.5 2.5 0 0 0-2.5 2.5v8.5a2.5 2.5 0 0 0 2.5 2.5h2.5v1.59a1 1 0 0 0 1.707.7l1-1a.569.569 0 0 0 .034-.03l1.273-1.273a.6.6 0 0 0-.8-.892v-.006L9.441 19.1l.001-2.3h-3.7l-.133-.007A1.3 1.3 0 0 1 4.442 15.5V7l.007-.133A1.3 1.3 0 0 1 5.742 5.7h14l.133.007A1.3 1.3 0 0 1 21.042 7v4.887a.6.6 0 1 0 1.2 0V7z' fill='%23000' fill-opacity='.9'/%3E%3Crect x='14.625' y='16.686' width='7' height='1.2' rx='.6' fill='%23000' fill-opacity='.9'/%3E%3Crect x='18.725' y='13.786' width='7' height='1.2' rx='.6' transform='rotate(90 18.725 13.786)' fill='%23000' fill-opacity='.9'/%3E%3C/svg%3E) 留言