     大量发布占位视频的抖音seo方式 \* { margin: 0; padding: 0; outline: 0; } body { font-family: "PingFang SC", system-ui, -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Hiragino Sans GB", "Microsoft YaHei UI", "Microsoft YaHei", Arial, sans-serif; line-height: 1.6; } .\_\_page\_content\_\_ { max-width: 667px; margin: 0 auto; padding: 20px; text-size-adjust: 100%; color: rgba(0, 0, 0, 0.9); padding-bottom: 64px; } .title { user-select: text; font-size: 22px; line-height: 1.4; margin-bottom: 14px; font-weight: 500; } .\_\_meta\_\_ { color: rgba(0, 0, 0, 0.3); font-size: 15px; line-height: 20px; hyphens: auto; word-break: break-word; margin-bottom: 50px; } .\_\_meta\_\_ .nick\_name { color: #576B95; } .\_\_meta\_\_ .copyright { color: rgba(0, 0, 0, 0.3); background-color: rgba(0, 0, 0, 0.05); padding: 0 4px; margin: 0 10px 10px 0; } blockquote.source { padding: 10px; margin: 30px 0; border-left: 5px solid #ccc; color: #333; font-style: italic; word-wrap: break-word; } blockquote.source a { cursor: pointer; text-decoration: underline; } .item\_show\_type\_0 > section { margin-top: 0; margin-bottom: 24px; } a { color: #576B95; text-decoration: none; cursor: default; } .text\_content { margin-bottom: 50px; user-select: text; font-size: 17px; white-space: pre-wrap; word-wrap: break-word; line-height: 28px; hyphens: auto; } .picture\_content .picture\_item { margin-bottom: 30px; } .picture\_content .picture\_item .picture\_item\_label { text-align: center; } img { max-width: 100%; } .pay\_subscribe\_notice { margin: 30px 0; padding: 20px; background: #fffbe6; border: 1px solid #ffe58f; border-radius: 8px; } .pay\_subscribe\_badge { display: inline-block; padding: 4px 12px; background: #faad14; color: #fff; border-radius: 4px; font-size: 14px; font-weight: 500; margin-bottom: 12px; } .pay\_subscribe\_desc { font-size: 15px; line-height: 1.8; color: rgba(0, 0, 0, 0.7); margin-bottom: 12px; } .pay\_subscribe\_hint { font-size: 13px; color: rgba(0, 0, 0, 0.4); } .\_\_bottom-bar\_\_ { display: flex; justify-content: space-between; align-items: center; position: fixed; bottom: 0; left: 0; right: 0; height: 64px; padding: 8px 20px; background: white; box-sizing: border-box; border-top: 1px solid rgba(0, 0, 0, 0.2); } .\_\_bottom-bar\_\_ .left { display: flex; align-items: center; font-size: 15px; white-space: nowrap; } .\_\_bottom-bar\_\_ .right { display: flex; } .\_\_bottom-bar\_\_ .sns\_opr\_btn { display: flex; align-items: center; user-select: none; background: transparent; border: 0; color: rgba(0, 0, 0, 0.9); font-size: 14px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn:not(:last-child) { margin-right: 16px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn > img { margin-right: 4px; }

大量发布占位视频的抖音seo方式
================

原创 o君言o 君言戏语 2022-07-14 14:30 福建

> 原文地址: [https://mp.weixin.qq.com/s/d\_zMIkTHjKOdQIcJ5ZHnCg](https://mp.weixin.qq.com/s/d_zMIkTHjKOdQIcJ5ZHnCg)

前言
--

作为从事互联网方向业务的我们来说，谈到抖音一般离不开涨粉这个问题，这个没错，这是必然要面对和解决的问题。

但是这个风气影响了很多传统行业的人，对于很多依靠互联网但实际上做的是传统生意的商家们，ta们在经营抖音的时候也跟着主流基调，天天想着怎么拍内容涨粉。

事实上这是本末倒置的，到底我们的目标是粉丝量还是订单量？粉丝量多一定代表订单量大吗？传统商家们服务的对象应该是粉丝还是会下单的客户？

  

在去年我写过一篇文章[搜一搜SEO选词实操步骤，附提词工具！](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486024&idx=1&sn=9a32fa672d7bb5e4d3dfe632646eeb9d&chksm=feb8691fc9cfe00941f1be53b5ed3e576036cfb477bdbd8bd9c2583c748707394dd9edd8bb76&token=635007497&lang=zh_CN&scene=21#wechat_redirect)，其目的是希望提醒一些想要从事搜一搜seo的朋友们，要正确认识搜一搜seo，一是它没有那么复杂，二是要找准核心竞争点。

而这个问题，在抖音seo这个领域也是同样存在的。

今天刚好把两个问题结合起来聊一聊！

**PS**：由于本文涉及的三个主要问题在过往文章都有针对性的讲解过，因此本文不谈具体实操，重点在于讲解整体流程。

批量上架工具的逻辑
---------

在上一篇文章[自动为每一句文案匹配应景的表情图片](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486739&idx=1&sn=77aa26ea86424affaf39bf31fb11f68a&chksm=feb86e44c9cfe75244019a6ec157181cac7c6e8215b60cfe11dcee5e8f54de495d3b6eec9c9d&token=635007497&lang=zh_CN&scene=21#wechat_redirect)里最后提到的国际站批量上架的方式，有些朋友觉得好像很难，有些朋友觉得这种工具很有价值。

然而这个东西实现起来其实非常简单，随便一个程序员都可以做。

在这篇文章里提到这个小工具是因为和我们接下去要讲的视频生产方式有些类似，所以稍微讲解一下逻辑。

  

我们以泉州生产的特色产品石茶盘为例：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpJiayaP3xmSFyn1y0NMJQ6aUfUGjOk7OjywMpvx2jDaQKLv8NhaaWoKgric7lCOaZbLCRvfZaYtZgxA/640?wx_fmt=png)

素材来源阿里巴巴 侵删

假设电商平台给我们这样一份文档：

商品标题

关键词1

关键词2

商品主图1

商品主图2

商品主图3

商品详情

商品价格

是否包邮

自定义属性名1

自定义属性值1

自定义属性名2

自定义属性值2

  

  

  

  

  

  

  

  

  

  

  

  

  

可左右滑动

  

我们需要这样填好：

商品标题

关键词1

关键词2

商品主图1

商品主图2

商品主图3

商品详情

商品价格

是否包邮

自定义属性名1

自定义属性值1

自定义属性名2

自定义属性值2

天然乌金石茶盘创意影雕石头托盘

大小号茶具排水石材家用茶台整块

石茶盘

乌金石石茶盘

https://www.abc.com/1.png

https://www.abc.com/2.png

https://www.abc.com/3.png

html源码

999

是

品牌

xxx

石质

乌金石

可左右滑动

  

这就是写好了一个商品，然后将这份表格文档上传，这个商品就会进入后台审核。

OK，那么我们所需要做的就是用程序自动生成一行一行的数据，然后把整份文档上传就可以上架一大批商品了。

一行数据代表一个商品，每一个列是一个商品具体要填的项，我们来一个个看：

**1：标题**

标题需要不重复，让运营收集或撰写一批标题，作为本次要生成的商品标题，每次按顺序取一个作为某个商品的即可。

标题

乌金石茶盘石头茶海茶台石材天然大号石茶盘排水简约黑金石刻字

乌金石头茶盘石盘家用套装全自动烧水壶自动上水一体式茶台茗器赏

家用乌金石茶盘整块手工抛光面石头茶台简约茶盘沥水盘茶海可定制

...

可左右滑动

  

**2：关键词**

需要填入两个，我们首先准备一批行业词：

主词

辅词

茶盘

石茶盘价格

石茶盘

石茶盘定制

…

…

可左右滑动

  

分主词和辅词，随机从主词挑选一个作为“关键词1”的值，同理从辅词里得到“关键词2”的值，搞定！

**3：商品主图**

这里的例子是3张，一般主图是6张！

假设我们的茶盘一共有两种，商品ID分别是“01”和“02”。

把01和02的所有图片先上传到平台的图片库，然后取得对应的图片链接，放在我们的数据表里：

01

02

https://www.abc.com/1.png

https://www.abc.com/a.png

https://www.abc.com/2.png

https://www.abc.com/b.png

https://www.abc.com/3.png

https://www.abc.com/c.png

可左右滑动

  

程序按商品顺序生成，所以先取01的所有图片，然后从中随机取3张，分别填入对应项，图片也完成了。

**4：商品详情**

就是详情页介绍的内容，这个是以html的形式，我们可以事先给每个商品存一份html源码的文档：

`<p>用乌金石雕刻制作而成的石茶盘，美观大方，经济实用，让茶叶回归自然</p>   <p><img src="https://www.abc.com/1.png"></p>   <p>赶紧抢购吧</p>   `

命名为01.html，现在在生成的是01这个商品，所以程序直接读取这份html作为“商品详情”的值，OK！

当然我们可以多设计几份，然后随机，这样就有机会测试不同详情页的转化效果。

**5：商品价格**

这个没什么可说的，同样是以一份价格表作为支撑，按商品ID来取值。

**6：是否包邮**

假设只有两个值：是或否，那么根据不同商品选择即可，或者一般默认是。

**7：自定义属性**

它在前端一般是类似这样的：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpJiayaP3xmSFyn1y0NMJQ6aU1sliavemicgIg8YZJYeicoapXuBw2Jkc0fmqrP2AFffd4tdfRQ4sTXbeA/640?wx_fmt=png)

我们可以自定义名称和值，然后自行决定是否添加，同样以商品ID区分，根据不同的ID来取对应的值。

最终我们可以输出这样一份文档出来：

商品标题

关键词1

关键词2

商品主图1

商品主图2

商品主图3

商品详情

商品价格

是否包邮

自定义属性名1

自定义属性值1

自定义属性名2

自定义属性值2

乌金石茶盘石头茶海茶台石材天然大号石茶盘排水简约黑金石刻字

茶盘

石茶盘价格

https://www.abc.com/1.png

https://www.abc.com/2.png

https://www.abc.com/3.png

html源码

399

是

品牌

xxx

名称

乌金石石茶盘

乌金石头茶盘石盘家用套装全自动烧水壶自动上水一体式茶台茗器赏

石茶盘

石茶盘定制

https://www.abc.com/2.png

https://www.abc.com/1.png

https://www.abc.com/3.png

html源码

399

是

品牌

xxx

名称

乌金石石茶盘

家用乌金石茶盘整块手工抛光面石头茶台简约茶盘沥水盘茶海可定制

石茶盘

乌金石茶盘

https://www.abc.com/c.png

https://www.abc.com/a.png

https://www.abc.com/b.png

html源码

499

是

品牌

xxx

名称

高级乌金石石茶盘

可左右滑动

  

你看，这其实就是我们把所有数据准备好，以商品为维度构建整份数据，然后让程序根据我们制定的规则：随机、固定、顺序、组合等等方式来选择每一个项的值，最后一起按格式输出。

整份数据构建完了之后，**我们有多少标题就可以在规则范围内生成多少个商品**。

程序员朋友肯定知道，这个非常简单，无非就是一堆文本数据的处理。

当然，实际上国际站的这份文档会相对麻烦一些，一个商品有70几个项要填，而且做批发的有价格表，一个单品就有不同的阶梯价格表，以及不同的尺寸规格等。

广告投放也是可以用类似的方式搭建账户。

经营抖音的误区
-------

有了这个工具逻辑的背景，我们来聊聊今天的主题！

正如开头所讲，我想给一些传统商家朋友的建议是：做抖音，**我们的目的是订单量而不是粉丝量**！

可以看到我这边用的是“**经营**抖音的误区”，而不是“**运营**抖音的误区”，很多传统商家并不是互联网人士，也没有太多这方面的经验，做抖音的目的是经营自己的生意，**而不是为了打造一个头部大号**。

  

这里面的区别在于：

当你期望运营一个行业头部大号的时候，你的操作会围绕着粉丝、点赞、评论这些数据，进而你会去思考算法机制、内容拍摄、文案脚本等等因素。

因为你也很清楚一天到晚讲价格、做广告、引导下单这些内容是没办法吸引粉丝的、没办法获得更多推荐的。

可是，**被你那些为了涨粉、点赞而制作出来的视频内容“触动”进而关注你的人，大概率都不是为了购买你的产品**。

ta们只是被推荐到，觉得讲得不错，顺手点个关注或点赞一下，但是并不会考虑买，因为ta看到的内容也没在谈论下单、购买这些问题。

ta不是被价格、优惠、质量等等问题吸引进来的，**关注的动机本身就是错的**。

通过这样的方式经营抖音号以期望能增加订单，**最终的结果经常是粉丝量不上不下，里面一半是同行 一半是在评论里挑剔、唱反调、提意见但就是不买的人**。

没必要，你的潜在客户不应该是那些老用户，而是想要但几乎不太懂的客户。

那么针对传统生意在抖音经营，有什么相对好一点的策略呢？

可以考虑seo方向。

抖音seo
-----

关于抖音seo，其实我想表达的问题与文章[搜一搜SEO选词实操步骤，附提词工具！](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486024&idx=1&sn=9a32fa672d7bb5e4d3dfe632646eeb9d&chksm=feb8691fc9cfe00941f1be53b5ed3e576036cfb477bdbd8bd9c2583c748707394dd9edd8bb76&token=635007497&lang=zh_CN&scene=21#wechat_redirect)里提到的基本类似，没有看过这篇文章的朋友可以先看看！

  

在网上，大家可以看到很多抖音seo的教程，有很多人包装了付费课程，我也看过一些付费课程，讲的那些内容实在浅显，但是又刻意要把这些浅显的东西拔高了讲。

比如昵称可以加入行业主词、合集权重相对高一些 等等，实际上我仍然想强调在抖音做seo没有想象那么复杂。

核心方向仍然是两点：关键词布局和长尾词竞争！

假设“seo”是行业主词，那么“seo优化”就是行业大词：

昵称加入主词  
简介加入大词  
视频内容以合集呈现  
合集名称加入大词(包括描述)  
视频文案加入目标长尾词  
视频内容画面全程有目标长尾词  
尽可能添加更多行业相关话题标签  
评论引导直播销售  
前期适量投点dou+

遵循这个原则，然后以每一个长尾词生成每一个视频，大批量生产和发布。

  

关键词的布局，这个是基础，**写完让视频可以正常参与排名就行**，但是不需要对它有什么很大的期待，这个别人也能做，你只是不做不行而已。

当然，这里面的合集命名注意下：

这里的合集可以理解为sem里的单元，一般根据词根、词性、需求、类别来划分，合集里的每一个视频对应的长尾词都是这个合集名称的子集，合集名称就是这些长尾词里提取出来的大词。

也就是说，这个事情要运作，要解决两个关键问题：**词库建立、批量生产**！

至于粉丝、点赞、评论这些数据不需要去在意和刻意，这些数据你要是能轻易优化，你也不需要依靠seo了，我们竞争的就是剩下的流量，就是那些放在地上没人捡的流量。

刷数据，这就没必要了，没有意义，一是系统有能力做基本区分，二是这也是资源，也要钱，还不如去投dou+。

词库建立
----

这个问题我在过往文章已经讲过很多角度了，挖词和分类看这一篇就行：[如何在百万级的数据里找到别人正在赚钱的项目](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485128&idx=1&sn=249ec2af9e00e807c16ba5d99dde754e&chksm=feb8659fc9cfec896c1b8846dc8eabbafe23272e757396fe2b05f06c1bcba1e66e0af7fca114&token=635007497&lang=zh_CN&scene=21#wechat_redirect)(知乎ID：君言)。

清洗的步骤多一个：去除没有商业价值的词汇，方法可以是大量查询竞价或者根据你自己的行业经验挑选一些高频的非目标词根，然后筛选去除(比如 保养，这种词根的长尾词就没必要了)。

做好了这些词库就建立完成了。

挖词我们可以选择巨量算数或者巨量千川，没有账号的话，百度渠道的竞价关键词规划师也可以，再不行就第三方挖词工具。

不用在意这些关键词的数据不是抖音官方的，首先用户需求不会因为平台不同就消失了，不同词量大量小的问题而已，其次我们是批量化产出，大规模碰撞，竞争的目标是长尾需求，所以不用在乎当下的具体搜索量。

批量生产
----

石茶盘这个商品不复杂，就是一门很传统的生意，工厂进石材原料，工人加工，样式都是抄或仿，一般有尺寸规格材质的差别。

很多老板和工厂对接，或者老板自己就有工厂，然后在网上渠道经营，零售批发皆可。

目前淘宝卖石茶盘的top店铺大部分是泉州工厂生产，利润空间相对很多产品非常可观。

这是我在阿里巴巴找的一个石茶盘商品详情里的属性：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpJiayaP3xmSFyn1y0NMJQ6aU1sliavemicgIg8YZJYeicoapXuBw2Jkc0fmqrP2AFffd4tdfRQ4sTXbeA/640?wx_fmt=png)

可以看到一块石茶盘大致有这些属性，这是用户可能存在的需求点。此外，我们做好了词库之后，石茶盘的需求类别也大致清晰了，假设主要有：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpJiayaP3xmSFyn1y0NMJQ6aUxCl6HyFFGOIFiaXXJMHaQuNwzdM9LBx5icfRhaicRMURAVYcCyxoFfBFw/640?wx_fmt=png)

这些结合起来是我们划分合集的依据，也是我们视频文案撰写的方向！

  

现在，假设我们有这样一批在售石茶盘商品：

商品id

茶盘名称

尺寸规格

石质

颜色

风格

工艺

支持定制

01

乌金石石茶盘

50x30x3、60x30x3、70x35x3

乌金石

灰色

国画

火烧

否

02

高级乌金石石茶盘

50x30x3、60x30x3、70x35x3、90x45x3

乌金石

黑色

简约

抛光

是

可左右滑动

  

我们在抖音开设一个账号，取名“XXX石茶盘”，认证一下蓝V，联系信息该填的能填的都填上，简介介绍自己的服务范围，正常介绍都会自然融入关键词，不用刻意堆砌。

根据上面的需求类别，我们把合集主要划分为：

`乌金石石茶盘、灵璧石石茶盘、国画石茶盘、简约石茶盘、火烧石茶盘、抛光石茶盘、石茶盘图片、石茶盘视频`

接着整体设计一个视频生产的规则，首先是一个视频需要的元素：

目标长尾词

类别(合集)

茶盘名称

尺寸规格

石质

颜色

风格

工艺

支持定制

商品图片1

商品图片2

商品图片3

商品图片4

商品图片5

商品图片6

商品图片7

商品图片8

商品图片9

商品图片10

厂家图片

打包图片

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

可左右滑动

  

假设“乌金石石茶盘”这个合集(类别)下面有一个长尾词：乌金石石茶盘价格

根据上面这份表格，结合我们现有在售的商品，可以利用程序生成这样一份数据：

目标长尾词

类别(合集)

茶盘名称

尺寸规格

石质

颜色

风格

工艺

支持定制

商品图片1

商品图片2

商品图片3

商品图片4

商品图片5

商品图片6

商品图片7

商品图片8

商品图片9

商品图片10

厂家图片

打包图片

乌金石石茶盘价格

乌金石石茶盘

乌金石石茶盘

50x30x3、60x30x3、70x35x3

乌金石

灰色

国画

火烧

否

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

乌金石石茶盘价格

乌金石石茶盘

高级乌金石石茶盘

50x30x3、60x30x3、70x35x3、90x45x3

乌金石

黑色

简约

抛光

是

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

随机图片url

可左右滑动

  

这个就是跟上面批量化上传文档的逻辑一样了。

注意：这里是一个长尾词对应多个同类别的不同商品，所以一个长尾词可以生成很多个不一样的视频。

最后再制作一个脚本程序来读取这份表格，提取每一行数据，根据数据生成一个个视频。

生成逻辑或者说视频的展现形式可以自行设计，这里演示一个我自己制作的例子：

  

展示方式是自己定的，内容来源于表格里的数据。

视频中的口播文案可以根据不同类别撰写一份转换为语音，当前在生成什么类别的视频就取类别对应的文案语音即可。

BGM准备一些应景的随机。

假设“乌金石石茶盘”这个合集下我们收集了M个长尾词，我们共有N个在售的乌金石茶盘商品，那么这个合集下我们可以生成M x N个视频。

商品表格的数据规范是我们制定的，数据生成视频的程序规则也是我们设计的，文案、BGM等材料也都准备着，那么程序就可以自动在框架内生成我们可以预期的视频，剩下的就是上传了(尽量多加相关话题标签)。

这种视频批量制作的程序原理这里就不多说了，相比去年写的[如何3天自动生产1000个优质原创短视频](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485317&idx=1&sn=9af87ab5b67e18756eeaa6a45f2f2a2e&chksm=feb864d2c9cfedc4c9792ba91e275896d63cb6010f9b411cfdef1018c039cfe0e3965c43b509&token=635007497&lang=zh_CN&scene=21#wechat_redirect)，这种算简单了。

案例
--

我在抖音上搜索了下”石茶盘“，看到了一个账号：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpJiayaP3xmSFyn1y0NMJQ6aUFyTb3TCtk4iaNrRsjA67bXB3pzCsFOjl3ibCDBTBJvXQhmmhia5mfZe3w/640?wx_fmt=jpeg)

素材来源抖音 侵删

这个账号的视频内容也很一般：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpJiayaP3xmSFyn1y0NMJQ6aUdcwRG698RUcvhfJIcicoZ4icXM1v0h911zrtEIE460rBia4icFyWicZfAQA/640?wx_fmt=jpeg)

素材来源抖音 侵删

类似这样的(截取了一小段)：

又或者往茶盘倒点水之类的，整体产出的视频很简单，粉丝量才1.7W。

但小店的表现是很不错的：

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/qfbwFTq4UpJiayaP3xmSFyn1y0NMJQ6aUheBofwsiciad2w0eT0cV9QFKthpZx6wyibbTx1o2fjT3POd5Rh31NnvHQ/640?wx_fmt=jpeg)

素材来源抖音 侵删

石茶盘的均价一般很少低于200的客单。

这个案例他倒不一定是跟这篇文章讲的逻辑一样的操作，但是表现出来的结果其实是一样的：传统生意，做好分类(合集)，简单制作，大量生产，重在销售。

ps：有没有发现传统行业销量做的好的账户数据或作品数据的表现反而一般？**因为真正搜索进来买你东西的人不会给你点赞关注的**。

当搜索大量长尾词的时候用户都能看到你，恰巧你又在直播，进来购买后走了，你的视频有的甚至不会去看，看了也不会点赞。

**做出来的视频不是为了给用户欣赏的，而是占位**！

延伸拓展
----

借着这个行业来演示整体的流程以及过程中几个重要的问题(误区、seo)，具体到自己的行业应该灵活改变，要尽可能理解这种计算的思维，一切数据和操作都在自己的计算框架内。

维度、元素尽可能多，能“有机结合”的地方就越多，哪怕是视频里的画面切换，也是可以随机不同的风格。

用于插入视频的产品图片，一定是用图片吗？其实也可以先把一个产品多角度多场景拍摄几段视频，然后随机组合。

文章讲的整体策略对于toB业务(比如批发)效果更好，对于垂直行业(越垂直越好)效果更好，因为他们只需要讲解清楚、增加曝光即可，不需要像toC那样营销客户。

结语
--

对于没有太多互联网经验的传统老板，看到这里可能会觉得这些很难，然而这些事情对于互联网人士来说很简单。

要知道：你的同行也是这么认为的！

百度直到今天仍然还有流量是没多少人在抢的，数据和需求的挖掘是无止境的，每天都会有新的产生，更何况抖音才发展几年。

可以预见的是：很多行业在抖音还有很多需求、流量是没人去承接的。

只要你愿意去挖掘，比你的同行多做好几个步骤就可以。

很多传统行业的老板生意做得不错，但不代表他懂很多，他认为程序员就是修电脑的也一点都不奇怪。

他们不知道他们的生意还可以以这样的方式来运作，但你至少知道，要说信息差，这就是信息差！

  

**点击右上角把文章分享给小伙伴讨论一下吧，也许你会有新的思路！**

#### 相关推荐

[几个现学现用的方式：提取用户较为“迫切”的需求！](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247484778&idx=1&sn=df7a6ee6edfb100c331cc683860b9d4f&chksm=feb8663dc9cfef2bfa73d22ccd03c42b730c0dfb219f6a45a213382dbf32505b88472921eef6&token=635007497&lang=zh_CN&scene=21#wechat_redirect)  
[你有没有注意那些能在私域里自传播的东西？](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485726&idx=1&sn=496a937c4d7360a83c311f52867df511&chksm=feb86a49c9cfe35f5c3a75d40886c7ba7680b10d130aab9c472d80bfe61228ebf065bd22bb90&token=635007497&lang=zh_CN&scene=21#wechat_redirect)  
[百度竞价：大量挖掘有商业价值的词汇，截流另一片长尾流量！](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247484427&idx=1&sn=04230977d95d030386a3fac6cec21c14&chksm=feb8675cc9cfee4afef99e8e47cde329edf5295acaf840113538f6bdeafd82f63027ba70011d&token=635007497&lang=zh_CN&scene=21#wechat_redirect)

* * *

简单介绍一下自己，称呼：小曾，“君言”是我用来写东西的名称，目前自由职业，挖掘了不少互联网项目，独立跑通过几个！

擅于用技术辅助互联网营销，喜欢做需求分析的事情，崇尚走增长黑客的路线。

咨询、进读者交流群，可以[点击与我联系](http://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485860&idx=1&sn=52073ba58c5c70e2544440895af80a82&chksm=feb86af3c9cfe3e5af8e288e627af5c69b45197c2f40285734d26dc50723ea22eededea47e6a&scene=21#wechat_redirect)。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpJcPCXasmEbSFOygEicQHGElhEibHheicN45y084Fw6NsDDZduDWIz9uOKia8ic20QuOvCt45nwIOHtnCw/640?wx_fmt=png)

  

![](http://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLbYm2TI7kiameic7QEzKqbsk6jyHS4XpzpdnBgLOZOYzLO1eBLLOEN0CK2IJjjegG2kT7GRf7uZOnA/0?wx_fmt=png) 君言戏语

 ![](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3C!-- Icon from Lucide by Lucide Contributors - https://github.com/lucide-icons/lucide/blob/main/LICENSE --%3E%3Cg fill='none' stroke='%23888888' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'%3E%3Cpath d='M2.062 12.348a1 1 0 0 1 0-.696a10.75 10.75 0 0 1 19.876 0a1 1 0 0 1 0 .696a10.75 10.75 0 0 1-19.876 0'/%3E%3Ccircle cx='12' cy='12' r='3'/%3E%3C/g%3E%3C/svg%3E) 阅读![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M16.154 6.797l-.177 2.758h4.009c1.346 0 2.359 1.385 2.155 2.763l-.026.148-1.429 6.743c-.212.993-1.02 1.713-1.977 1.783l-.152.006-13.707-.006c-.553 0-1-.448-1-1v-8.58a1 1 0 0 1 1-1h2.44l1.263-.03.417-.018.168-.015.028-.005c1.355-.315 2.39-2.406 2.58-4.276l.01-.16.022-.572.022-.276c.074-.707.3-1.54 1.08-1.883 2.054-.9 3.387 1.835 3.274 3.62zm-2.791-2.52c-.16.07-.282.294-.345.713l-.022.167-.019.224-.023.604-.014.204c-.253 2.486-1.615 4.885-3.502 5.324l-.097.018-.204.023-.181.012-.256.01v8.218l9.813.004.11-.003c.381-.028.72-.304.855-.709l.034-.125 1.422-6.708.02-.11c.099-.668-.354-1.308-.87-1.381l-.098-.007h-5.289l.26-4.033c.09-1.449-.864-2.766-1.594-2.446zM7.5 11.606l-.21.005-2.241-.001v8.181l2.45.001v-8.186z' fill='%23000'/%3E%3C/svg%3E) 赞 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cpath d='M0 0h24v24H0z'/%3E    %3Cpath fill='%23576B95' d='M13.707 3.288l7.171 7.103a1 1 0 0 1 .09 1.32l-.09.1-7.17 7.104a1 1 0 0 1-1.705-.71v-3.283c-2.338.188-5.752 1.57-7.527 5.9-.295.72-1.02.713-1.177-.22-1.246-7.38 2.952-12.387 8.704-13.294v-3.31a1 1 0 0 1 1.704-.71zm-.504 5.046l-1.013.16c-4.825.76-7.976 4.52-7.907 9.759l.007.287c1.594-2.613 4.268-4.45 7.332-4.787l1.581-.132v4.103l6.688-6.623-6.688-6.623v3.856z'/%3E  %3C/g%3E%3C/svg%3E) 分享 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cdefs%3E    %3Cpath id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-a' d='M0 0h24v24H0z'/%3E  %3C/defs%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cmask id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-b' fill='%23fff'%3E      %3Cuse xlink:href='%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-a'/%3E    %3C/mask%3E    %3Cg mask='url(%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-b)'%3E      %3Cg transform='translate(0 -2.349)'%3E        %3Cpath d='M0 2.349h24v24H0z'/%3E        %3Cpath fill='%23576B95' d='M16.45 7.68c-.954 0-1.94.362-2.77 1.113l-1.676 1.676-1.853-1.838a3.787 3.787 0 0 0-2.63-.971 3.785 3.785 0 0 0-2.596 1.112 3.786 3.786 0 0 0-1.113 2.687c0 .97.368 1.938 1.105 2.679l7.082 6.527 7.226-6.678a3.787 3.787 0 0 0 .962-2.618 3.785 3.785 0 0 0-1.112-2.597A3.687 3.687 0 0 0 16.45 7.68zm3.473.243a4.985 4.985 0 0 1 1.464 3.418 4.98 4.98 0 0 1-1.29 3.47l-.017.02-7.47 6.903a.9.9 0 0 1-1.22 0l-7.305-6.73-.008-.01a4.986 4.986 0 0 1-1.465-3.535c0-1.279.488-2.56 1.465-3.536A4.985 4.985 0 0 1 7.494 6.46c1.24-.029 2.49.4 3.472 1.29l.01.01L12 8.774l.851-.85.01-.01c1.046-.951 2.322-1.434 3.59-1.434 1.273 0 2.52.49 3.472 1.442z'/%3E      %3C/g%3E    %3C/g%3E  %3C/g%3E%3C/svg%3E) 推荐 ![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M22.242 7a2.5 2.5 0 0 0-2.5-2.5h-14a2.5 2.5 0 0 0-2.5 2.5v8.5a2.5 2.5 0 0 0 2.5 2.5h2.5v1.59a1 1 0 0 0 1.707.7l1-1a.569.569 0 0 0 .034-.03l1.273-1.273a.6.6 0 0 0-.8-.892v-.006L9.441 19.1l.001-2.3h-3.7l-.133-.007A1.3 1.3 0 0 1 4.442 15.5V7l.007-.133A1.3 1.3 0 0 1 5.742 5.7h14l.133.007A1.3 1.3 0 0 1 21.042 7v4.887a.6.6 0 1 0 1.2 0V7z' fill='%23000' fill-opacity='.9'/%3E%3Crect x='14.625' y='16.686' width='7' height='1.2' rx='.6' fill='%23000' fill-opacity='.9'/%3E%3Crect x='18.725' y='13.786' width='7' height='1.2' rx='.6' transform='rotate(90 18.725 13.786)' fill='%23000' fill-opacity='.9'/%3E%3C/svg%3E) 留言