     RPA要不要学习，真的能解放双手吗？ \* { margin: 0; padding: 0; outline: 0; } body { font-family: "PingFang SC", system-ui, -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Hiragino Sans GB", "Microsoft YaHei UI", "Microsoft YaHei", Arial, sans-serif; line-height: 1.6; } .\_\_page\_content\_\_ { max-width: 667px; margin: 0 auto; padding: 20px; text-size-adjust: 100%; color: rgba(0, 0, 0, 0.9); padding-bottom: 64px; } .title { user-select: text; font-size: 22px; line-height: 1.4; margin-bottom: 14px; font-weight: 500; } .\_\_meta\_\_ { color: rgba(0, 0, 0, 0.3); font-size: 15px; line-height: 20px; hyphens: auto; word-break: break-word; margin-bottom: 50px; } .\_\_meta\_\_ .nick\_name { color: #576B95; } .\_\_meta\_\_ .copyright { color: rgba(0, 0, 0, 0.3); background-color: rgba(0, 0, 0, 0.05); padding: 0 4px; margin: 0 10px 10px 0; } blockquote.source { padding: 10px; margin: 30px 0; border-left: 5px solid #ccc; color: #333; font-style: italic; word-wrap: break-word; } blockquote.source a { cursor: pointer; text-decoration: underline; } .item\_show\_type\_0 > section { margin-top: 0; margin-bottom: 24px; } a { color: #576B95; text-decoration: none; cursor: default; } .text\_content { margin-bottom: 50px; user-select: text; font-size: 17px; white-space: pre-wrap; word-wrap: break-word; line-height: 28px; hyphens: auto; } .picture\_content .picture\_item { margin-bottom: 30px; } .picture\_content .picture\_item .picture\_item\_label { text-align: center; } img { max-width: 100%; } .pay\_subscribe\_notice { margin: 30px 0; padding: 20px; background: #fffbe6; border: 1px solid #ffe58f; border-radius: 8px; } .pay\_subscribe\_badge { display: inline-block; padding: 4px 12px; background: #faad14; color: #fff; border-radius: 4px; font-size: 14px; font-weight: 500; margin-bottom: 12px; } .pay\_subscribe\_desc { font-size: 15px; line-height: 1.8; color: rgba(0, 0, 0, 0.7); margin-bottom: 12px; } .pay\_subscribe\_hint { font-size: 13px; color: rgba(0, 0, 0, 0.4); } .\_\_bottom-bar\_\_ { display: flex; justify-content: space-between; align-items: center; position: fixed; bottom: 0; left: 0; right: 0; height: 64px; padding: 8px 20px; background: white; box-sizing: border-box; border-top: 1px solid rgba(0, 0, 0, 0.2); } .\_\_bottom-bar\_\_ .left { display: flex; align-items: center; font-size: 15px; white-space: nowrap; } .\_\_bottom-bar\_\_ .right { display: flex; } .\_\_bottom-bar\_\_ .sns\_opr\_btn { display: flex; align-items: center; user-select: none; background: transparent; border: 0; color: rgba(0, 0, 0, 0.9); font-size: 14px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn:not(:last-child) { margin-right: 16px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn > img { margin-right: 4px; }

RPA要不要学习，真的能解放双手吗？
==================

原创 o君言o 君言戏语 2023-05-25 12:30 福建

> 原文地址: [https://mp.weixin.qq.com/s/dPTzv8Y2txhklWbyO25VOg](https://mp.weixin.qq.com/s/dPTzv8Y2txhklWbyO25VOg)

打开影刀RPA工具，并新建一个“手机自动化”应用：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWYa1McUaU1eMWsqia24E9MYVTEmGUsfPHEPm4gcyicW2yE3dHibUlpELqw/640?wx_fmt=png)

然后打开上方的手机管理器：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWYgEot7AwvNRQ5BndPJHr8iaZmVKUE3IDbK6BrPAjlEWvxVuPmGCY6GA/640?wx_fmt=png)

再准备一把安卓手机，并开启“USB调试”：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWJqOu2eHn2bX96aym1t5uMianHGks57bVYic8xhVibgEI9QibKKiaVlzoOAQ/640?wx_fmt=png)

将手机插上数据线接入电脑，然后选择“传输文件”模式：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWicz7jjAacdORP55S85ynrCdjuUgnYGmzQmq5ibAdrvKEBOlfz2OjBDiag/640?wx_fmt=png)

**PS**：不同品牌手机开启“USB调试”的方式可百度，有标准教程。

  

至此，你就可以在电脑里操控你的手机，所有操作都是完全同步的，类似于投屏效果：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWmMPKKHicoMzntP1j3JtoOG9hZGicCcEa7nuCHfAZNqRpuDibRwZe8WdzQ/640?wx_fmt=png)

接着，我们需要准备一批`特殊词汇`，让影刀自动将每一个词汇放入到咸鱼搜索框：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWIyAvYkYoMFIsunE5ukWeYxss19xtFne8cVmmeRXfrjrlISZjZ3SfHg/640?wx_fmt=png)

影刀会自动控制电脑里的手机管理器，实现自动控制外接的手机设备。

输入后自动回车得到商品搜索结果：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWfVLYiapxoibESQRBFXzwWBYlFX1gtuvQvibibSNYa91yoic0ZgRNKibVuhNg/640?wx_fmt=png)

然后自动截图当前手机界面，保存到电脑指定文件夹里，之后再下拉屏幕一次(影刀自动模拟人工下滑)，再截图保存一次，每一个词汇都进行同样的操作：

搜索、截图、保存、下拉、截图、保存，下一个词汇 ……

下面是完成这些自动化操作的指令代码：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWrod5ZmIclTFQvr6Ty8wkibHwRnibmia8RXpG8UlnrHeN6pDicdNqZgGBPw/640?wx_fmt=png)

避免风险问题，我没有全部截图下来，总共才15行，只要稍微会一点RPA，这点指令很简单，并不是重点。

  

最后，我们得到了一堆商品搜索结果，大概有上千张：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWtKOC89PwT1I1yxBZ767KFhgWN7uQMFzmRyZ6rYnq6NsqdCjMAU0s8A/640?wx_fmt=png)

这里面存放着很多待发现的优质商品，只需要把这些图片上传到百度网盘，

再找张好一点的沙发躺下来，接下去就是一张张的在手机里面翻，看看别人在卖什么，数据怎么样。

一两个小时后，你能找出很多“爆品”出来，遇到感兴趣的品类，可以把对应的词汇记录下来，过后再重点了解。

  

OK，我们刚才通过影刀RPA工具，结合“特殊词汇”的逻辑，完成了对闲鱼优质商品的挖掘。

关于特殊词汇，可以看我知乎文章：互联网常见的"特殊词汇"，往往被忽略的商机(懒得同步过来，链接在下面)。

这是我最近在启动的一个闲鱼小项目，上面的商品挖掘是其中一个步骤。

  

目前已经挖掘到一个还不错的品类，快速上线了上百个商品(获得了鱼小铺邀请，可以上500个商品)，正在陆续出单中。

整个项目从零到跑通(自然出单)花了3天左右，过程中没有花什么钱(几十块)。

对这个项目的期待不高，1个号一个月能稳定纯利2k以上即可，因为它是自动发货的，基本不太需要维护，

如果稳定了再让身边的人把账号资源给过来一起操作。

这个项目后续再考虑写一些思路出来，今天的重点是RPA！

关于RPA
-----

是不是感觉这两三年，RPA这个名词慢慢被很多人提及？好像是个新鲜领域。

但实际上，早在十年前甚至更早，RPA就已经不新鲜了。

RPA是“机器人流程自动化”，通俗来说，就是擅长自动控制你的鼠标键盘来完成一些重复性的工作。

在十年前左右，那时候流行的RPA工具，比较典型的是：`按键精灵`，

我在那时候使用它开发过`营销QQ`(相当于现在的`企业微信`)这款产品的自动化程序，让按键精灵自动帮我添加好友：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWn29ibWOlbe67Nf1iaHtLO1rmicZEKkQqzAKXoHtZh92lhhx5CGlcXTN7w/640?wx_fmt=png)

由于按键精灵是通过图片比对来识别操作目标的，这是那时候各个操作目标的截图。

那时候还是代码，不像现在有更简单的指令(比如上面的影刀)，我还保存着：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWcqK9Jdc7d6y2Dx94tUCsDbA1FWSsGVjbMSusg6bKzCeMmNcsuibBg8Q/640?wx_fmt=png)

运行后程序就会挨个选择一个号码来进行添加。

所以，RPA不是什么新鲜事物，也不是什么神秘黑科技，

但是随着RPA的普及，市面上出现了不少培训课程，这其中还存在不少误导现象。

  

作为运营推广的非技术人员，RPA要不要学、自学还是报课、是不是很简单、能不能完全解放双手、是不是比Python好用，

这篇文章将针对相关问题，以我个人的经验给大家一些参考建议。

Python和RPA
----------

RPA就是使用编程语言开发出来的一些工具软件，把编程代码封装成一系列简单的指令，完成一些相对固定的工作。

所以从技术层面上来说，Python作为一款流行编程语言，当然会比具体的某一个工具来得强大，这是毋庸置疑的。

  

RPA能做的事情，Python都可以，Python能做的很多事情，RPA是不行的。

如果RPA是流水线上的自动化机器，那么Python就是能生产这些流水线自动化机器的，

因此，两者在能力上没有可比性。

RPA的优势
------

作为一名业余里的专业Python选手，为什么上面的挖掘步骤我不用Python来实现呢？

尽管Python作为一款高级编程语言，已经非常的灵活和便捷，

但是它毕竟是编程语言而不是某种针对性的工具。

如果我没有过相关经验，那么我需要去查找具体方案，部署相关环境，安装对应的模块包等等，

这些都不是现成的，需要你自己去组装。

  

那么我本身可能只是做个简单的调研或测试，我完全没必要把时间和精力浪费在这些琐事上，然后最后才发现这个项目做不了……

这个时候，RPA的优势就出来了，这次使用影刀挖掘咸鱼商品，是我第一次使用影刀这个工具。

大概花了半小时左右来熟悉软件的使用方式、以及相应一些指令的作用等，

除去过程中踩了一些坑以外，平时要写出上面那样一段自动化流程的指令也就1分钟。

要知道，我并不打算大规模抓取，所以我不考虑稳定、效率等方面的问题，

我只是集中收集一批数据快速调研一下，那么使用影刀这样的工具，就是在操作一个软件而已，很简单。

  

RPA工具的优势就是：**傻瓜式操作**、**简单快速落地你的需求**，

它在鼠键自动化方面就好像一把组装好了的**瑞士军刀**，各种功能都是**现成**的。

RPA局限
-----

现在的RPA工具(比如影刀这种)会更加高级一些，融合了很多**现成**的功能点，

但是RPA最主要的还是`鼠键自动化`，而鼠键自动化基于系统桌面，这就是会导致一些问题：

### 稳定

不间断运作的程序最主要的是稳定性，RPA程序控制鼠标和键盘在系统桌面自动化执行时，

容易受人工或桌面其他意外情况(比如弹窗)的影响，导致程序执行错误。

RPA程序也无法像编程语言有灵活的错误机制来应对各种意外的情况。

当程序发生错误时，错乱的鼠键胡乱执行可能会带来其他的意外。

### 效率

编程语言将处理对象读取到系统内存处理，这一切都发生在后台，

而RPA直接操作前端桌面，会受打开、关闭、切换、显示、加载等步骤的影响，降低了效率。

同时，由于很多场景没有很好的判断机制，导致程序经常要使用一些暂停延时的指令来等待，更加降低了效率和稳定。

不过讲道理，都使用RPA了，就不要挑剔效率问题了。

### 鼠键自动化的局限(重点)

提到自动化，我们会下意识的想到鼠键自动化，一些教RPA培训的老师会告诉你学习RPA可以完全解放双手，

你双手可以干的工作，全都可以交给它。

乍一听好像还真是这么回事，所有的工作可不都是通过双手干的嘛。

但是，可以自动化的工作，**不止你双手可以干的**，**还包括你双手干不了的**。

  

我以前讲过“情感分析”这个事情，我们可以写一个Python脚本，让它分析每一句评论的情感倾向。

这种功能的逻辑是，程序事先预训练了一批数据，然后基于这批数据的计算结果来预测目标评论的情感倾向。

很显然，这需要经过大量的事先计算，然后再将目标数据与之前的数据做进一步计算。

即使你不懂编程也应该能明白，**这种运算它不是鼠标键盘的事**，

它需要算法、公式、数据结构，需要百万千万甚至更多的数据做支撑，

这些运算发生在系统内存里，你不可能在电脑桌面上做这些事情。

  

像这样一个文本批处理的工作，它也是一种自动化，在Python里面，它只需要6行代码搞定：

`from snownlp import SnowNLP   with open('text.txt','r',encoding='utf-8') as file:       text_list = file.read().split('\n')   for text in text_list:       s = SnowNLP(text)       print('%s\t%s' % (text,s.sentiments))   `

如果你只会RPA，你貌似做不了这样的事情，但是：

我前面说了，现在的RPA工具会更加高级一些，融合了很多**现成**的功能点，

我们打开影刀软件，搜索指令：NLP(自然语言处理)：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWHIiah9gfZoIH20bSQ729XuqyKKuv3e3y4ApwLZAV3UtMB0M5seia0SRQ/640?wx_fmt=png)

会发现它居然有这样的指令(功能)：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWJoic25I41aFxSo8Q9O9Y5N4NQVRq8avictgWRAzY5aKjHHNK6R2rWxjQ/640?wx_fmt=png)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahW4fwNYkGp9snctZcd5OP0SKZAUjHSdpL9p1lSMF2sIc0skL26GQ7ayw/640?wx_fmt=png)

除了情感分析以外，还有其他几种典型的文本处理功能。

  

当然，且不说这是要收费的功能，并且可能还有数据量的限制，实际上，这些功能已经超出鼠键自动化了，

你执行这样的功能，也跟鼠标键盘没有关系，它只是影刀给你封装了这样一个功能，你直接调用就可以了，它会在后台执行计算。

那么`NLP`是文本处理的常见应用，影刀可以给你封装，**但不代表任何文本批处理的功能都会给你封装好**，

如果没有，那你就做不了。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWxvICtDd8dzZG3TA7JibicKib26KGx9yqqyV4iaMA5r3Hq1pArRH8hqzzDw/640?wx_fmt=png)

上面是影刀现成的一些文本数据批处理的小功能，但是文本数据的批处理是非常灵活的，

你说我想要把每一个标题的第五个字去除怎么办？

如果上面没有，那就是没有，这个需求就是做不了。

鼠键自动化是弱需求
---------

目前，RPA常见的一些典型应用主要是：

### 自动化测试

运维工程师利用它去测试一些即将上线的产品应用，比如公司开发了某个页面，

利用自动化工具模拟用户的使用过程来测试产品。

但是，这些运维工程师不一定需要学习RPA的，他们有自己的方式。

### 网络游戏

按键精灵最早的典型应用就是游戏方面(网游)，有玩过网络游戏的都会有相关经验，

在游戏任务中经常会有一些重复点击的行为。

但是，大部分游戏玩家，你很难想象他会花心思钻研这些技术，直接就买WG。

### 办公自动化

这应该是很多人学习RPA的初衷，希望RPA可以提升日常办公的效率，彻底解放双手。

很多培训RPA的老师也是以这个角度作为宣传点。

但我认为，这是错误的需求。

### 网络营销

批量发布、自动加人、大量群发，这是营销人员的最爱，他们有学习的意愿和学习的基础条件，最重要的是有钻研的动力。

这可能是当前各大主流RPA工具的主要用户群体。

  

Python被培训机构或者个人爱好者宣传成：除了不能生孩子，其他都能。

这虽然运用了夸张的修辞手法，但是Python近年来在各领域的作用确实不负盛名。

而现在，RPA也被个别培训老师宣传为无所不能，但这显然是极其夸大的。

  

在最开始发现按键精灵并成功用它解决一些工作的时候，我非常兴奋，

遇到一点稍微重复的事情，就马上思考能不能自动化，那就好像你获得一把锤子，看见什么都像钉子一样。

然而一段时间后，我发现用它来解决办公场景里(电脑桌面)的自动化，其实是很鸡肋的一件事情，

你写出来的各种小脚本，过了几天发现电脑里的环境：这里变了、那里改了，

然后你的程序要嘛不能用了，要嘛还得改，这就本末倒置了！

  

从我十年前接触RPA到现在，我并没有在太多领域看到它的身影，

如果你有兴趣去分析一下RPA相关的搜索词，你会发现上百万的搜索信息里，统计下来，你看不到多少个领域，

也就是说，没有很多各行各业的人带着他的行业在提问RPA相关的应用问题，

原因很简单：

**鼠键自动化要求目标工作的操作流程是完全标准化的**，如果你一天下来的主要工作内容全都是这种完全无脑重复的手工操作，

我很怀疑你的工资有没有超过1000块。

实际上不可能会有这样的岗位，在办公场景里**大量重复无脑**的操作，早就会被一些工具解决掉了。

办公场景里的自动化有3个特点：

`低频`、`占比低`，`价值小`，你偶尔才会遇到一些高度重复的无脑操作，而这点事情在你工作内容中的比重很小，否则程序员个个都财富自由了。

  

另外我相信有很多网络从业人员想要学习RPA，目的就是做一些自动化的营销工作：

生产内容、抓取数据、批量发布、自动加人 等等，有很多培训课程的卖点也是这个方向。

那么我的建议是：可以，你应该学习一些辅助技能！

但是你得明白，不是说学习了RPA就无所不能了，有些培训课程会告诉你RPA完全模拟人工操作，

不用担心被封，可以不间断的重复执行。

实际上，别说你是模拟人工，你就是真的自己双手去操作，只要频率高了一样被限制。

批量发布、自动加人，这些都需要账号资源的，如果你没有账号资源，你一天能发几万次请求都没有用。

我在我的Python课程里也有一节鼠键自动化的课程，是一个批量发送群成员消息的案例，

那时候在课程里我就跟大家说了，只是让你知道有这么些东西，可以用来做什么，

这种技术有时候有用，但是不要用来做这些群发的事情。

系统在服务端以 IP + 账号 的策略就可以完全给你限制了，没有意义。

**PS**：虽然营销QQ的卖点是可以有25万好友，但实际上你加的频繁了照样出现验证码，理由是骚扰用户。

至于抓取数据之类的，那都是一些少量的抓取。

Python的高级爬虫工程师一个月可能要几万块，你猜公司为什么不请个大学生用RPA去做。

  

实际上，我们做运营和推广或者互联网营销的朋友，你仔细思考一下：

你的工作中真正高频的自动化工作是什么？

是**文本数据**的自动化。

大批量的文本要处理，几十份的报表要整合 等等，这些才是真正高频的场景。

RPA需要编程知识
---------

有些RPA培训老师会告诉你学习编程是很痛苦的，而RPA学起来很简单，

纯中文，简单易理解的指令，UI界面，一切都是傻瓜式的操作，不需要懂编程。

是这样吗？是的。

  

但是 `是` 不一定就是 `对`。

前面说了，RPA是将代码封装成一些简单的指令，但是封装完了之后，它也是像代码那样执行，本质上仍然是程序。

既然是程序，那就会涉及：什么是数组(列表)、什么是变量、什么是条件语句、什么是循环语句、循环语句的运行逻辑是什么样的？等等，

你使用它抓取网页数据，那你可能就要有一点`html`、`css`相关的知识，你甚至不懂什么是`xpath`。

如果这些你不知道，那你一样要学习和理解这些概念，否则你仍然写不出你想要的脚本程序。

那你都学习这些了，那跟学习编程又有多少差别呢？

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWKdBgXSwqsoykFUsWBP2WnJD4sAbIO6EIBs8dAFRLiarkHfNu77MBy4Q/640?wx_fmt=png)

影刀帮助中心

  

很多人会认为编程学习难是语言问题，这当然会有些障碍，但是常用命令无非那么三二十个，这根本不会成为阻碍。

事实上我在我的Python课程里，这些编程基础概念就花了一节课基本讲完了，后面都在讲实操案例。

对于编程，真正困难的是逻辑运算，数据构建，流程分析 等等，知识性的内容是很少的。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWBqgQCPlahfeicjzGaJN1ghdv6Stj53h6x1uq8gmybFz6iaq9pw10J77g/640?wx_fmt=png)

上图是影刀社区里用户遇到问题的一些提问，篇幅问题没有截取很多，

那么你可以看看，这些是你愿意去花时间研究的事情吗？

网站、APP、软件，这些都是基于程序做出来的，你想要把玩他们，怎么可能不需要一点技术知识呢？

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIicWwGbhEp9RUTsapwvOahWAc09Wtbo5zJ8UlvC59xEREueLMlhR9icU6ibcJGca53dW4jTjm8lj2tw/640?wx_fmt=png)

上图也是影刀官方的教程，教你如何在影刀里面使用Python来编写程序功能，这就已经是在写代码了。

因为有些时候某些功能适合甚至说只能用代码的方式来处理，又或者你想要实现的功能没有现成封装的，那就只能自己写了。

**PS**：实际上你以为的编程难，熟悉了之后没有太大差别，很多看起来很秀的功能，代码就那么几行，比如上面提到的情感分析的案例。

  

也就是说你兜兜转转，最后会发现想要实现更多效果，还是得会编程。

学习建议
----

通篇下来，其实很啰嗦，但我相信已经足够给你指导参考了，

我的建议是：

如果你想要**深入**运用这些工具，辅助你的日常工作或者营销活动等，技术知识是不可避免的，

最起码学习一种简单语言，比如py或者R之类的，学会这些之后你再学习RPA就跟玩一样。

如果你不打算深入运用，只是轻度简单使用，依赖不高，甚至就是偶尔装个13，那直接就学习RPA，

尽可能不去扯上技术层面的事情，遇到做不了的就做不了，你本来也不是技术领域的工种。

  

报班可以，如果你有信任的老师，报个班会快很多，学起来也轻松很多，这种简单的技术课程你吃不了亏上不了当。

而且老实说我觉得一些RPA产品的官方教程也不是很友好，

影刀还算丰富，但是对于不懂技术的初学者，没有建立那种系统性的知识框架，学起来会比较吃力。

总的来说，RPA是不错的工具，但是不管培训老师如何鼓吹，你应该明白它的优势是什么，局限是什么，你主要用来解决什么，

不要有错误的期待就行。

* * *

之前开了一份问卷，陆续收到一些朋友的反馈，

如果你长期阅读我的文章，并从中获得到一些帮助，那么希望你给公众号提点建议，

算是对公众号的一点支持，也希望你的建议可以帮助我把公众号的内容做得更好：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIyzUDSTcCN5rdbRnz1NM4stVmSrSicoK3gKrUu3Qr7GCe3zsMlyZeKqpgXP1DkgqVfKh74C5xC6rQ/640?wx_fmt=png&wxfrom=5&wx_lazy=1&wx_co=1)

* * *

简单介绍一下自己，称呼：小曾，“君言”是我用来写东西的名称，目前自由职业，挖掘了不少互联网项目，独立跑通过几个！

擅于用技术辅助互联网营销，喜欢做需求分析的事情，崇尚走增长黑客的路线。

咨询、进读者交流群，可以[点击与我联系](http://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485860&idx=1&sn=52073ba58c5c70e2544440895af80a82&chksm=feb86af3c9cfe3e5af8e288e627af5c69b45197c2f40285734d26dc50723ea22eededea47e6a&scene=21#wechat_redirect)。

公众号回复数字 1 可查看历史分享的资源或工具：

  

##### 相关推荐

[绝大部分需求痛点都可以按照这套词库框架挖掘出来](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247484369&idx=1&sn=86da8288afd7bb595af60de54f9882b8&chksm=feb86086c9cfe990d8c70a98420b6c5d0515fce873c78be459f485b07dee9da5770b97ede861&token=884061634&lang=zh_CN&scene=21#wechat_redirect)  
[搜一搜SEO选词实操步骤，附提词工具！](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486024&idx=1&sn=9a32fa672d7bb5e4d3dfe632646eeb9d&chksm=feb8691fc9cfe00941f1be53b5ed3e576036cfb477bdbd8bd9c2583c748707394dd9edd8bb76&token=635007497&lang=zh_CN&scene=21#wechat_redirect)  
[百度竞价：大量挖掘有商业价值的词汇，截流另一片长尾流量！](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247484427&idx=1&sn=04230977d95d030386a3fac6cec21c14&chksm=feb8675cc9cfee4afef99e8e47cde329edf5295acaf840113538f6bdeafd82f63027ba70011d&token=635007497&lang=zh_CN&scene=21#wechat_redirect)

[闲鱼](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzU5OTE2MDM3Ng==&action=getalbum&album_id=2018029519969845249#wechat_redirect) | [兼职](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzU5OTE2MDM3Ng==&action=getalbum&album_id=2496340746527277057#wechat_redirect) | [数据采集](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzU5OTE2MDM3Ng==&action=getalbum&album_id=1702065254098124801#wechat_redirect)

##### 付费文章

[用逆向思维收集大量被忽略的"声音"](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247484016&idx=1&sn=6eb962822951c704b5fe4ee4ce877ba6&chksm=feb86127c9cfe831164c1226594a2d8c9ff4517f3db14d0aaad26870e85970d51d9784327bef&payreadticket=HCN6R2uIyE-hxRPQfCKuTXGkhKpI_cSbOOKwskOfqmPZJBz0NyrdstHxaA2tNtgFKlQbaoA&scene=21#wechat_redirect)  
[程序员稳定的副业：如何做个小工具？](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485848&idx=1&sn=0b5c668e4ebe06b92babd12d679bcd08&chksm=feb86acfc9cfe3d9a4e2b9d5d12c865bcd106ed7ff3a43ee6fe0ba56bb8b0068de2c000ac34a&payreadticket=HPeOVpKPPuPIjYL0cZ1y1UEnfHxXSCvlpqDZA-keHvEVU35w4uC3xwezh-akrRmcp3IN8CQ&scene=21#wechat_redirect)  
[450个抖音类目，可能是2022年全网最全的](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486617&idx=1&sn=aa6087716c3b603f0297cfe36ef8bb93&chksm=feb86fcec9cfe6d836540b2b31b762aecd58758c3566d3d4e3e841fdc930dc09e15f7d85282a&payreadticket=HH63HOXgh_KT2_nz2EyXJYqXRb2Q4nYVhar94YnHM_nQLFHU0MZ6_2kUDbG8aCnj66hdnxg&scene=21#wechat_redirect)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpJcPCXasmEbSFOygEicQHGElhEibHheicN45y084Fw6NsDDZduDWIz9uOKia8ic20QuOvCt45nwIOHtnCw/640?wx_fmt=png)  
![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpJjuVCVM7VRlANNYicDsEy7UocrIyRJT1xHe8G8BghicC9BuSnhibialvxomB8npWoVrzD1WIBJB1vXVA/640?wx_fmt=png)

据粉丝反馈，经常收不到推文，如果你不想错过，那么可以：[加我微信](http://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485860&idx=1&sn=52073ba58c5c70e2544440895af80a82&chksm=feb86af3c9cfe3e5af8e288e627af5c69b45197c2f40285734d26dc50723ea22eededea47e6a&scene=21#wechat_redirect)、星标公众号，或者分享点赞增加互动！👇

### 资料补充

**互联网常见的"特殊词汇"，往往被忽略的商机**：`https://zhuanlan.zhihu.com/p/182462542`

![](http://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLbYm2TI7kiameic7QEzKqbsk6jyHS4XpzpdnBgLOZOYzLO1eBLLOEN0CK2IJjjegG2kT7GRf7uZOnA/0?wx_fmt=png) 君言戏语

 ![](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3C!-- Icon from Lucide by Lucide Contributors - https://github.com/lucide-icons/lucide/blob/main/LICENSE --%3E%3Cg fill='none' stroke='%23888888' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'%3E%3Cpath d='M2.062 12.348a1 1 0 0 1 0-.696a10.75 10.75 0 0 1 19.876 0a1 1 0 0 1 0 .696a10.75 10.75 0 0 1-19.876 0'/%3E%3Ccircle cx='12' cy='12' r='3'/%3E%3C/g%3E%3C/svg%3E) 阅读![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M16.154 6.797l-.177 2.758h4.009c1.346 0 2.359 1.385 2.155 2.763l-.026.148-1.429 6.743c-.212.993-1.02 1.713-1.977 1.783l-.152.006-13.707-.006c-.553 0-1-.448-1-1v-8.58a1 1 0 0 1 1-1h2.44l1.263-.03.417-.018.168-.015.028-.005c1.355-.315 2.39-2.406 2.58-4.276l.01-.16.022-.572.022-.276c.074-.707.3-1.54 1.08-1.883 2.054-.9 3.387 1.835 3.274 3.62zm-2.791-2.52c-.16.07-.282.294-.345.713l-.022.167-.019.224-.023.604-.014.204c-.253 2.486-1.615 4.885-3.502 5.324l-.097.018-.204.023-.181.012-.256.01v8.218l9.813.004.11-.003c.381-.028.72-.304.855-.709l.034-.125 1.422-6.708.02-.11c.099-.668-.354-1.308-.87-1.381l-.098-.007h-5.289l.26-4.033c.09-1.449-.864-2.766-1.594-2.446zM7.5 11.606l-.21.005-2.241-.001v8.181l2.45.001v-8.186z' fill='%23000'/%3E%3C/svg%3E) 赞 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cpath d='M0 0h24v24H0z'/%3E    %3Cpath fill='%23576B95' d='M13.707 3.288l7.171 7.103a1 1 0 0 1 .09 1.32l-.09.1-7.17 7.104a1 1 0 0 1-1.705-.71v-3.283c-2.338.188-5.752 1.57-7.527 5.9-.295.72-1.02.713-1.177-.22-1.246-7.38 2.952-12.387 8.704-13.294v-3.31a1 1 0 0 1 1.704-.71zm-.504 5.046l-1.013.16c-4.825.76-7.976 4.52-7.907 9.759l.007.287c1.594-2.613 4.268-4.45 7.332-4.787l1.581-.132v4.103l6.688-6.623-6.688-6.623v3.856z'/%3E  %3C/g%3E%3C/svg%3E) 分享 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cdefs%3E    %3Cpath id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-a' d='M0 0h24v24H0z'/%3E  %3C/defs%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cmask id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-b' fill='%23fff'%3E      %3Cuse xlink:href='%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-a'/%3E    %3C/mask%3E    %3Cg mask='url(%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-b)'%3E      %3Cg transform='translate(0 -2.349)'%3E        %3Cpath d='M0 2.349h24v24H0z'/%3E        %3Cpath fill='%23576B95' d='M16.45 7.68c-.954 0-1.94.362-2.77 1.113l-1.676 1.676-1.853-1.838a3.787 3.787 0 0 0-2.63-.971 3.785 3.785 0 0 0-2.596 1.112 3.786 3.786 0 0 0-1.113 2.687c0 .97.368 1.938 1.105 2.679l7.082 6.527 7.226-6.678a3.787 3.787 0 0 0 .962-2.618 3.785 3.785 0 0 0-1.112-2.597A3.687 3.687 0 0 0 16.45 7.68zm3.473.243a4.985 4.985 0 0 1 1.464 3.418 4.98 4.98 0 0 1-1.29 3.47l-.017.02-7.47 6.903a.9.9 0 0 1-1.22 0l-7.305-6.73-.008-.01a4.986 4.986 0 0 1-1.465-3.535c0-1.279.488-2.56 1.465-3.536A4.985 4.985 0 0 1 7.494 6.46c1.24-.029 2.49.4 3.472 1.29l.01.01L12 8.774l.851-.85.01-.01c1.046-.951 2.322-1.434 3.59-1.434 1.273 0 2.52.49 3.472 1.442z'/%3E      %3C/g%3E    %3C/g%3E  %3C/g%3E%3C/svg%3E) 推荐 ![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M22.242 7a2.5 2.5 0 0 0-2.5-2.5h-14a2.5 2.5 0 0 0-2.5 2.5v8.5a2.5 2.5 0 0 0 2.5 2.5h2.5v1.59a1 1 0 0 0 1.707.7l1-1a.569.569 0 0 0 .034-.03l1.273-1.273a.6.6 0 0 0-.8-.892v-.006L9.441 19.1l.001-2.3h-3.7l-.133-.007A1.3 1.3 0 0 1 4.442 15.5V7l.007-.133A1.3 1.3 0 0 1 5.742 5.7h14l.133.007A1.3 1.3 0 0 1 21.042 7v4.887a.6.6 0 1 0 1.2 0V7z' fill='%23000' fill-opacity='.9'/%3E%3Crect x='14.625' y='16.686' width='7' height='1.2' rx='.6' fill='%23000' fill-opacity='.9'/%3E%3Crect x='18.725' y='13.786' width='7' height='1.2' rx='.6' transform='rotate(90 18.725 13.786)' fill='%23000' fill-opacity='.9'/%3E%3C/svg%3E) 留言