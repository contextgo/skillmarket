     普通玩家对于AIGC的侧重点：结构化数据！ \* { margin: 0; padding: 0; outline: 0; } body { font-family: "PingFang SC", system-ui, -apple-system, BlinkMacSystemFont, "Helvetica Neue", "Hiragino Sans GB", "Microsoft YaHei UI", "Microsoft YaHei", Arial, sans-serif; line-height: 1.6; } .\_\_page\_content\_\_ { max-width: 667px; margin: 0 auto; padding: 20px; text-size-adjust: 100%; color: rgba(0, 0, 0, 0.9); padding-bottom: 64px; } .title { user-select: text; font-size: 22px; line-height: 1.4; margin-bottom: 14px; font-weight: 500; } .\_\_meta\_\_ { color: rgba(0, 0, 0, 0.3); font-size: 15px; line-height: 20px; hyphens: auto; word-break: break-word; margin-bottom: 50px; } .\_\_meta\_\_ .nick\_name { color: #576B95; } .\_\_meta\_\_ .copyright { color: rgba(0, 0, 0, 0.3); background-color: rgba(0, 0, 0, 0.05); padding: 0 4px; margin: 0 10px 10px 0; } blockquote.source { padding: 10px; margin: 30px 0; border-left: 5px solid #ccc; color: #333; font-style: italic; word-wrap: break-word; } blockquote.source a { cursor: pointer; text-decoration: underline; } .item\_show\_type\_0 > section { margin-top: 0; margin-bottom: 24px; } a { color: #576B95; text-decoration: none; cursor: default; } .text\_content { margin-bottom: 50px; user-select: text; font-size: 17px; white-space: pre-wrap; word-wrap: break-word; line-height: 28px; hyphens: auto; } .picture\_content .picture\_item { margin-bottom: 30px; } .picture\_content .picture\_item .picture\_item\_label { text-align: center; } img { max-width: 100%; } .pay\_subscribe\_notice { margin: 30px 0; padding: 20px; background: #fffbe6; border: 1px solid #ffe58f; border-radius: 8px; } .pay\_subscribe\_badge { display: inline-block; padding: 4px 12px; background: #faad14; color: #fff; border-radius: 4px; font-size: 14px; font-weight: 500; margin-bottom: 12px; } .pay\_subscribe\_desc { font-size: 15px; line-height: 1.8; color: rgba(0, 0, 0, 0.7); margin-bottom: 12px; } .pay\_subscribe\_hint { font-size: 13px; color: rgba(0, 0, 0, 0.4); } .\_\_bottom-bar\_\_ { display: flex; justify-content: space-between; align-items: center; position: fixed; bottom: 0; left: 0; right: 0; height: 64px; padding: 8px 20px; background: white; box-sizing: border-box; border-top: 1px solid rgba(0, 0, 0, 0.2); } .\_\_bottom-bar\_\_ .left { display: flex; align-items: center; font-size: 15px; white-space: nowrap; } .\_\_bottom-bar\_\_ .right { display: flex; } .\_\_bottom-bar\_\_ .sns\_opr\_btn { display: flex; align-items: center; user-select: none; background: transparent; border: 0; color: rgba(0, 0, 0, 0.9); font-size: 14px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn:not(:last-child) { margin-right: 16px; } .\_\_bottom-bar\_\_ .sns\_opr\_btn > img { margin-right: 4px; }

普通玩家对于AIGC的侧重点：结构化数据！
=====================

原创 o君言o 君言戏语 2023-04-28 18:01 福建

> 原文地址: [https://mp.weixin.qq.com/s/4nz33VVglG9I9ACAp8iOAg](https://mp.weixin.qq.com/s/4nz33VVglG9I9ACAp8iOAg)

对ChatGPT提出一个需求：

> > ### 问题：
> > 
> > 请推荐10个中文男孩名称，不包含姓氏，名字是两个字的，每一个名字都有相应的释义，释义分为两句，类似诗句，请以表格形式返回给我，第1列是名称，释义分别放在第2列和第3列。
> > 
> > ### ChatGPT回答：
> > 
> > 好的，以下是10个中文男孩名称及其相应释义，按照你要求的表格形式排列：
> > 
> > 名称
> > 
> > 释义1
> > 
> > 释义2
> > 
> > 烨华
> > 
> > 明亮辉煌，才华出众
> > 
> > 高贵优雅，气质非凡
> > 
> > 天佑
> > 
> > 天助人顺，运势亨通
> > 
> > 志向高远，格局宏大
> > 
> > 梓豪
> > 
> > 豪气冲天，志向远大
> > 
> > 才情出众，气度非凡
> > 
> > 启航
> > 
> > 开拓进取，奋发向前
> > 
> > 追求自由，扬帆起航
> > 
> > 子涵
> > 
> > 儒雅清新，涵养深厚
> > 
> > 才华横溢，志向远大
> > 
> > 健柏
> > 
> > 强健有力，坚韧不拔
> > 
> > 高贵典雅，品格卓越
> > 
> > 飞翰
> > 
> > 飞跃腾飞，志向远大
> > 
> > 才华横溢，气度非凡
> > 
> > 子安
> > 
> > 平和安宁，稳健不惧
> > 
> > 仁爱和善，气度不凡
> > 
> > 修远
> > 
> > 精益求精，追求卓越
> > 
> > 远大理想，志向远大
> > 
> > 启明
> > 
> > 明亮清晰，迎接黎明
> > 
> > 志向高远，气度非凡

将ChatGPT返回的数据黏贴到Excel中并保存：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIyzUDSTcCN5rdbRnz1NM4spsibrU1aeoWY9Ss9KXqjJiaSq27vpVnpBicAb6kiaFzBToiayHsBEAFYooQ/640?wx_fmt=png)

然后新建一份PPT，简单设计一张图文模板并保存：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIyzUDSTcCN5rdbRnz1NM4sbRFmepISKxY6gDof9VUWEZlVmAoBkOjrheeWISQsMibjJOFaK37qH7Q/640?wx_fmt=png)

接着打开我的“图文批量生成器”，创建一个规则：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIyzUDSTcCN5rdbRnz1NM4sIbc1bB180wWghORGEY3Z7yDiaDI1QTB7fgjQEaSzpebjfQydMNzp4FQ/640?wx_fmt=png)

最后导入刚才保存的Excel文档，并点击“生成图文”：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIyzUDSTcCN5rdbRnz1NM4s7xKsAlSpIbVekQUP9Bne37ia5wiajURHWOBjtsAIkiaLYvgQILhDaibK4g/640?wx_fmt=png)

成功得到了10张起名业务的图文内容：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIyzUDSTcCN5rdbRnz1NM4sunVfNcNhXmqlrNapcKpOYu4dZt0JWNST6wKylen3TKgDcLvKxECcHg/640?wx_fmt=png)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIyzUDSTcCN5rdbRnz1NM4skibQNJiagVkVYMR2yn4YSbyb6oUrVicicic1ZOCBNUkiar0rj3z1RX6fM3JA/640?wx_fmt=png)

姓氏无所谓，固定随机几个大姓即可！

至此，操作结束！

  

你看，这个事情全程是无脑化的，新建模板和新建规则只做一次就可以了，

后续你只需要反复向ChatGPT拿数据即可，或者一次性拿几百条数据批量生成，

正常短视频账号，够发个把月了。

通过以上这样一个简单的例子，我为大家演示了AIGC这件事情：便利、无脑、高效、源源不断，这是它的特性。

AIGC
----

那么关于AIGC，有很多可以展开讨论，但是我个人认为，讨论归讨论，是不是有切身利益的关系就不一定了。

AIGC是由AI来创造内容，包括文本、图片、音频、视频以及组合 等。

我把AIGC可以带来的改变或影响，粗暴的分为上中下三个主要维度：

**在上**，类似腾讯这样的企业，可以在游戏里把AI植入NPC，创造出个性化的游戏人物角色，

在电商领域，当然是作为推荐助手或者智能客服来与买家沟通聊天。

**在中**，影视宣传公司、广告策划公司等中小企业，可以利用AI来生成广告语、海报图、甚至是宣传视频，完成甲方的任务，这也是一种工业化应用，顺便可以再裁点人。

但是我们会发现，这两个方向，跟我们这些在网上搞流量、做项目的人，**并没有几毛钱关系！**

所以我也只是偶尔关注，这些不是这篇文章的重点。

  

**在下**，就是我们这些人对于AIGC能够产生的运用了，比如文章开头的例子，这也是这篇文章的核心。

如果你希望运用AIGC来产生内容，进而通过其他方式变现，那么有两个重要问题需要考虑：

1：在ChatGPT刚出来不久，就马上有人提出可以让它写文章作为seo站点的内容，

你看，这是稍微思考一下就可以想到的。

所以如果你想运用AIGC做点内容，你不能“稍微思考一下”，从ChatGPT那里拿点数据就直接对外发。

2：无论是腾讯利用AIGC对NPC的优化，还是电商利用AIGC对消费场景的优化，

又或者是中小企业利用AIGC提升效率、节省成本，我们要从中看到这本身是具有价值意义的。

  

创意整合
----

所以综上，我认为对于我们从事网络营销的人来说：利用AIGC变现，**应该多考虑内容创意上的整合，**

一是为了避免简单重复，二是为了创造出来的数据有更多价值意义，且不说避免产生垃圾，至少我们也希望能带来更多的变现价值。

具体来说：

AI有的是数据，但是这些数据谁都有机会拿到，

那么：**拿什么数据、怎么提问、以什么格式返回、配合什么工具整合，最后以什么形式呈现给受众，**

就是我们这个项目操盘手需要考虑的问题。

比如我们文章开头的例子，ChatGPT返回的那份数据，我们可以黏贴到Excel直接发布出去，但是很难产生什么正向反馈，

那么我们将数据“包装”在一个“设计”过的“精美”模板里，发布在短视频平台，配合BGM，

一份具有可读性、参考性的内容就产生了。

至于我在提问的时候要求以表格形式返回，每一列分别是什么内容，这是因为我自己有个“图文批量生成器”的工具，它需要这样的格式。

同样的，我以前讲过聊天段子的案例：[如何3天自动生产1000个优质原创短视频](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485317&idx=1&sn=9af87ab5b67e18756eeaa6a45f2f2a2e&chksm=feb864d2c9cfedc4c9792ba91e275896d63cb6010f9b411cfdef1018c039cfe0e3965c43b509&token=2004497411&lang=zh_CN&scene=21#wechat_redirect)

那么一样可以向ChatGPT拿数据：

> > ### 问题：
> > 
> > 请你编辑一段夫妻搞笑对话，总共大概在6-10句话，每句话前面要有对应称谓，比如丈夫或妻子。
> > 
> > ### ChatGPT回答：
> > 
> > 好的，以下是夫妻之间的搞笑对话：
> > 
> > 妻子：老公，你夸夸我呗。
> > 
> > 丈夫：……
> > 
> > 妻子：呵呵，怎么着，以前让你夸，你还会随便敷衍几句，现在连敷衍都不想了？
> > 
> > 丈夫：我只是觉得我不配跟仙女说话。
> > 
> > 妻子：……

然后将数据通过我自己写的脚本工具整合出来：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIyzUDSTcCN5rdbRnz1NM4sAXqJxBjvia0GUywwgITQlVuv1sdpTaso6tq6htdwy6DXcYRytZ6Jflw/640?wx_fmt=png)

这又是一份不一样的原创数据，它会比一段枯燥的文字笑话来得有意思。

我以前还讲过自动匹配场景图的案例：[自动为每一句文案匹配应景的表情图片](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486739&idx=1&sn=77aa26ea86424affaf39bf31fb11f68a&chksm=feb86e44c9cfe75244019a6ec157181cac7c6e8215b60cfe11dcee5e8f54de495d3b6eec9c9d&token=2004497411&lang=zh_CN&scene=21#wechat_redirect)

现在有了AI，那么以后文案可以找ChatGPT拿，应景的图片甚至是视频可以找其他作图AI拿，

将ChatGPT返回的文案逐句拆分，每一句再分词，提取一定比例的主词，

再将这些主词作为标签丢给作图AI，返回每一句的应景图片，

最后将图片和文案按顺序整合起来，配合语音技术和BGM，一份口播视频就出来了。

当然，这其中少不了要会一门编程语言来衔接这些工作，因为没有现成的工具。

结构化数据
-----

我们刚才提到AIGC的特性：便利、无脑、高效、源源不断，

这是因为它毕竟是程序，而程序还有典型的特点就是擅长：

**标准化、结构化**，比如程序处理的数据库就是一张张结构清晰的表格。

**构建结构化的数据、思考数据的呈现方式**，就是我们运用AIGC时所要考虑的重点，

只要这两个问题想明白，我们就有源源不断的具有商业价值的内容数据。

  

还是前面举的例子：将名称和释义按表格返回，这是我构建结构化数据的过程，

通过“图文批量生成器”将数据整合形成一张张的图片，这是我思考出来的呈现方式。

同样的，将笑话的对话分开为两列，植入到微信聊天场景，这也是一样的思考过程。

类似我以前还提过的一些例子，比如书单：

> > ### 问题：
> > 
> > 请推荐5本励志书籍，我需要这些字段：书名、作者、评分、一句经典书摘、一句网民评论，表格形式返回。
> > 
> > ### ChatGPT回答：
> > 
> > 好的，以下是我为您推荐的5本励志书籍及其相关信息：
> > 
> > 书名
> > 
> > 作者
> > 
> > 评分
> > 
> > 经典书摘
> > 
> > 网民评论
> > 
> > 《刻意练习》（原书名：Peak）
> > 
> > 安德斯•艾瑞克森 (Anders Ericsson)
> > 
> > 4.6
> > 
> > 突破天花板的秘密在于刻意练习，每个人都可以通过实践成为专家。
> > 
> > 这本书是关于“练习成就卓越”的教科书，作者为我们提供了一种实用的方法来提高自己的技能，对于想要成为专业人士的人来说非常值得一读。
> > 
> > 《卓有成效的管理者》（原书名：The Effective Executive）
> > 
> > 彼得·德鲁克 (Peter Drucker)
> > 
> > 4.2
> > 
> > “把时间浪费在决策不重要的事情上，是一切管理者的致命弱点。”
> > 
> > 这是一本经典的管理书籍，德鲁克在书中提供了一些关于如何做出正确的决策以及如何提高个人效率的建议。
> > 
> > 《如何阅读一本书》（原书名：How to Read a Book）
> > 
> > 莫提默·J. 艾德勒 (Mortimer J. Adler)
> > 
> > 4.3
> > 
> > 阅读的目的在于获得知识，而不是仅仅读懂书本的表面内容。
> > 
> > 这本书可以帮助你更好地理解和分析你所阅读的书籍，不管是在学术界还是个人生活中都非常实用。
> > 
> > 《追风筝的人》（原书名：The Kite Runner）
> > 
> > 卡勒德·胡赛尼 (Khaled Hosseini)
> > 
> > 4.5
> > 
> > “每个人都会犯错误，但关键是要学会从中吸取教训。”
> > 
> > 这是一本感人至深的小说，讲述了一个阿富汗男孩的成长经历，对于我们来说，可以从中学到很多关于家庭、友谊和忠诚的价值观。
> > 
> > 《永远的终点》（原书名：The Endurance）
> > 
> > 亚历山大·林德 (Alexander Macklin)
> > 
> > 4.5
> > 
> > 在绝境中生存下来的关键是拥有强大的意志力和坚定的信念。
> > 
> > 这本书是一个生动的历史故事。

书有很多附加的属性信息，很容易构建出结构化的数据。

此外，构建结构化数据其实是一个“重建”的过程，这样可以顺带解决原创的问题。

这点在以前seo盛行的时候是常规操作：市面上有一堆数据，收集回来整合一下形成一个新的原创页面。

  

所以对于在看的你，如果你有确定的业务已经在经营了，那么你需要思考你的业务中有哪些数据是可以结构化的。

如果你没有确定的业务在经营，你希望运用AIGC做点事情，那么你需要多和AI“聊天”，

你需要思考AI有着什么样的数据，又或者哪些业务有明显的结构化数据，而这些数据通过AI是可以拿到的。

  

现阶段(可能很长的一段时间里)，AI(比如ChatGPT)，**是无法真正在商业问题上帮你做决策的，**

不一定是它不够聪明，只不过机器做决策需要各种各样的参数条件做支撑，

而我们永远无法将某件事情涉及的各种客观条件(比如你自己是什么样的能力水平)以它可以理解的方式传达给它，

那么它就不可能帮你做出客观的决策，对于你是这样，对于其他人也是这样。

所以刚才提到的：AI数据每个人都有，也就是说AI每个人都能用，但是怎么用还是个人思考的结果，

不是说AI出来了就能让某个人突飞猛进，这点在之前的文章也聊过，

同样一款工具，比拼的还是个人的思考，不同人可以玩出不一样的高度。

至少现阶段来说，AI只能是辅助你，**你的思考仍然是最重要的！**

  

关于AIGC的这篇文章聊得很短，倒也不是偷懒，而是我觉得我们普通玩家，只需关注我刚才提到的重点即可，

AIGC也不是天然出来让人赚钱的，不见得AIGC做的事情就一定跟赚钱有直接关系，

所以其他太多信息对我们而言更多时候是干扰，没有必要过多了解。

  

对了，如果你长期阅读我的文章，并从中获得到一些帮助，那么希望你给公众号提点建议，

算是对公众号的一点支持，也希望你的建议可以帮助我把公众号的内容做得更好：

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpIyzUDSTcCN5rdbRnz1NM4stVmSrSicoK3gKrUu3Qr7GCe3zsMlyZeKqpgXP1DkgqVfKh74C5xC6rQ/640?wx_fmt=png)

请直接扫码即可打开金山表单，只有3个选择题，微信授权登录即可，匿名填写。

感谢，51happy！

* * *

简单介绍一下自己，称呼：小曾，“君言”是我用来写东西的名称，目前自由职业，挖掘了不少互联网项目，独立跑通过几个！

擅于用技术辅助互联网营销，喜欢做需求分析的事情，崇尚走增长黑客的路线。

咨询、进读者交流群，可以[点击与我联系](http://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485860&idx=1&sn=52073ba58c5c70e2544440895af80a82&chksm=feb86af3c9cfe3e5af8e288e627af5c69b45197c2f40285734d26dc50723ea22eededea47e6a&scene=21#wechat_redirect)。

公众号回复数字 1 可查看历史分享的资源或工具：

  

##### 相关推荐

[零粉丝，运用错位竞争，运营「好物推荐」](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247483779&idx=1&sn=4b76d07827179d7454fe1ee5aff869f0&chksm=feb862d4c9cfebc264d639c8b42003b184c1c7fad64c894911debc355717ea95058f277ce034&token=635007497&lang=zh_CN&scene=21#wechat_redirect)  
[理解这些逻辑，闲鱼随时入场随时可以赚！](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485434&idx=1&sn=d062b1d12510c52e8ae84c1797e956fd&chksm=feb864adc9cfedbb3c41d37a5431b7f51c123e9d43cd4f743912af60e140ba39a796e739d89c&token=635007497&lang=zh_CN&scene=21#wechat_redirect)  
[如何3天自动生产1000个优质原创短视频-续篇](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486564&idx=1&sn=8ad9595a35bc0fcc8994af3788b5f7cb&chksm=feb86f33c9cfe625dad8e27d38caffa019bf46eb903e1455864e9a6279515d90901fa602a455&token=635007497&lang=zh_CN&scene=21#wechat_redirect)

[SEO](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzU5OTE2MDM3Ng==&action=getalbum&album_id=1555770789919047681#wechat_redirect) | [搜一搜](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzU5OTE2MDM3Ng==&action=getalbum&album_id=2486719148241420289#wechat_redirect) | [关键词](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzU5OTE2MDM3Ng==&action=getalbum&album_id=1709691760500654085#wechat_redirect)

##### 付费文章

[用逆向思维收集大量被忽略的"声音"](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247484016&idx=1&sn=6eb962822951c704b5fe4ee4ce877ba6&chksm=feb86127c9cfe831164c1226594a2d8c9ff4517f3db14d0aaad26870e85970d51d9784327bef&payreadticket=HCN6R2uIyE-hxRPQfCKuTXGkhKpI_cSbOOKwskOfqmPZJBz0NyrdstHxaA2tNtgFKlQbaoA&scene=21#wechat_redirect)  
[程序员稳定的副业：如何做个小工具？](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485848&idx=1&sn=0b5c668e4ebe06b92babd12d679bcd08&chksm=feb86acfc9cfe3d9a4e2b9d5d12c865bcd106ed7ff3a43ee6fe0ba56bb8b0068de2c000ac34a&payreadticket=HPeOVpKPPuPIjYL0cZ1y1UEnfHxXSCvlpqDZA-keHvEVU35w4uC3xwezh-akrRmcp3IN8CQ&scene=21#wechat_redirect)  
[450个抖音类目，可能是2022年全网最全的](https://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247486617&idx=1&sn=aa6087716c3b603f0297cfe36ef8bb93&chksm=feb86fcec9cfe6d836540b2b31b762aecd58758c3566d3d4e3e841fdc930dc09e15f7d85282a&payreadticket=HH63HOXgh_KT2_nz2EyXJYqXRb2Q4nYVhar94YnHM_nQLFHU0MZ6_2kUDbG8aCnj66hdnxg&scene=21#wechat_redirect)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpJcPCXasmEbSFOygEicQHGElhEibHheicN45y084Fw6NsDDZduDWIz9uOKia8ic20QuOvCt45nwIOHtnCw/640?wx_fmt=png)  
![](https://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpJjuVCVM7VRlANNYicDsEy7UocrIyRJT1xHe8G8BghicC9BuSnhibialvxomB8npWoVrzD1WIBJB1vXVA/640?wx_fmt=png)

据粉丝反馈，经常收不到推文，如果你不想错过，那么可以：[加我微信](http://mp.weixin.qq.com/s?__biz=MzU5OTE2MDM3Ng==&mid=2247485860&idx=1&sn=52073ba58c5c70e2544440895af80a82&chksm=feb86af3c9cfe3e5af8e288e627af5c69b45197c2f40285734d26dc50723ea22eededea47e6a&scene=21#wechat_redirect)、星标公众号，或者分享点赞增加互动！👇

![](http://mmbiz.qpic.cn/sz_mmbiz_png/qfbwFTq4UpLbYm2TI7kiameic7QEzKqbsk6jyHS4XpzpdnBgLOZOYzLO1eBLLOEN0CK2IJjjegG2kT7GRf7uZOnA/0?wx_fmt=png) 君言戏语

 ![](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3C!-- Icon from Lucide by Lucide Contributors - https://github.com/lucide-icons/lucide/blob/main/LICENSE --%3E%3Cg fill='none' stroke='%23888888' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'%3E%3Cpath d='M2.062 12.348a1 1 0 0 1 0-.696a10.75 10.75 0 0 1 19.876 0a1 1 0 0 1 0 .696a10.75 10.75 0 0 1-19.876 0'/%3E%3Ccircle cx='12' cy='12' r='3'/%3E%3C/g%3E%3C/svg%3E) 阅读![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M16.154 6.797l-.177 2.758h4.009c1.346 0 2.359 1.385 2.155 2.763l-.026.148-1.429 6.743c-.212.993-1.02 1.713-1.977 1.783l-.152.006-13.707-.006c-.553 0-1-.448-1-1v-8.58a1 1 0 0 1 1-1h2.44l1.263-.03.417-.018.168-.015.028-.005c1.355-.315 2.39-2.406 2.58-4.276l.01-.16.022-.572.022-.276c.074-.707.3-1.54 1.08-1.883 2.054-.9 3.387 1.835 3.274 3.62zm-2.791-2.52c-.16.07-.282.294-.345.713l-.022.167-.019.224-.023.604-.014.204c-.253 2.486-1.615 4.885-3.502 5.324l-.097.018-.204.023-.181.012-.256.01v8.218l9.813.004.11-.003c.381-.028.72-.304.855-.709l.034-.125 1.422-6.708.02-.11c.099-.668-.354-1.308-.87-1.381l-.098-.007h-5.289l.26-4.033c.09-1.449-.864-2.766-1.594-2.446zM7.5 11.606l-.21.005-2.241-.001v8.181l2.45.001v-8.186z' fill='%23000'/%3E%3C/svg%3E) 赞 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cpath d='M0 0h24v24H0z'/%3E    %3Cpath fill='%23576B95' d='M13.707 3.288l7.171 7.103a1 1 0 0 1 .09 1.32l-.09.1-7.17 7.104a1 1 0 0 1-1.705-.71v-3.283c-2.338.188-5.752 1.57-7.527 5.9-.295.72-1.02.713-1.177-.22-1.246-7.38 2.952-12.387 8.704-13.294v-3.31a1 1 0 0 1 1.704-.71zm-.504 5.046l-1.013.16c-4.825.76-7.976 4.52-7.907 9.759l.007.287c1.594-2.613 4.268-4.45 7.332-4.787l1.581-.132v4.103l6.688-6.623-6.688-6.623v3.856z'/%3E  %3C/g%3E%3C/svg%3E) 分享 ![](data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24' height='24' viewBox='0 0 24 24'%3E  %3Cdefs%3E    %3Cpath id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-a' d='M0 0h24v24H0z'/%3E  %3C/defs%3E  %3Cg fill='none' fill-rule='evenodd'%3E    %3Cmask id='a62bde5b-af55-42c8-87f2-e10e8a48baa0-b' fill='%23fff'%3E      %3Cuse xlink:href='%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-a'/%3E    %3C/mask%3E    %3Cg mask='url(%23a62bde5b-af55-42c8-87f2-e10e8a48baa0-b)'%3E      %3Cg transform='translate(0 -2.349)'%3E        %3Cpath d='M0 2.349h24v24H0z'/%3E        %3Cpath fill='%23576B95' d='M16.45 7.68c-.954 0-1.94.362-2.77 1.113l-1.676 1.676-1.853-1.838a3.787 3.787 0 0 0-2.63-.971 3.785 3.785 0 0 0-2.596 1.112 3.786 3.786 0 0 0-1.113 2.687c0 .97.368 1.938 1.105 2.679l7.082 6.527 7.226-6.678a3.787 3.787 0 0 0 .962-2.618 3.785 3.785 0 0 0-1.112-2.597A3.687 3.687 0 0 0 16.45 7.68zm3.473.243a4.985 4.985 0 0 1 1.464 3.418 4.98 4.98 0 0 1-1.29 3.47l-.017.02-7.47 6.903a.9.9 0 0 1-1.22 0l-7.305-6.73-.008-.01a4.986 4.986 0 0 1-1.465-3.535c0-1.279.488-2.56 1.465-3.536A4.985 4.985 0 0 1 7.494 6.46c1.24-.029 2.49.4 3.472 1.29l.01.01L12 8.774l.851-.85.01-.01c1.046-.951 2.322-1.434 3.59-1.434 1.273 0 2.52.49 3.472 1.442z'/%3E      %3C/g%3E    %3C/g%3E  %3C/g%3E%3C/svg%3E) 推荐 ![](data:image/svg+xml,%3Csvg width='25' height='24' viewBox='0 0 25 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M22.242 7a2.5 2.5 0 0 0-2.5-2.5h-14a2.5 2.5 0 0 0-2.5 2.5v8.5a2.5 2.5 0 0 0 2.5 2.5h2.5v1.59a1 1 0 0 0 1.707.7l1-1a.569.569 0 0 0 .034-.03l1.273-1.273a.6.6 0 0 0-.8-.892v-.006L9.441 19.1l.001-2.3h-3.7l-.133-.007A1.3 1.3 0 0 1 4.442 15.5V7l.007-.133A1.3 1.3 0 0 1 5.742 5.7h14l.133.007A1.3 1.3 0 0 1 21.042 7v4.887a.6.6 0 1 0 1.2 0V7z' fill='%23000' fill-opacity='.9'/%3E%3Crect x='14.625' y='16.686' width='7' height='1.2' rx='.6' fill='%23000' fill-opacity='.9'/%3E%3Crect x='18.725' y='13.786' width='7' height='1.2' rx='.6' transform='rotate(90 18.725 13.786)' fill='%23000' fill-opacity='.9'/%3E%3C/svg%3E) 留言