#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QClaw 局域网二维码文件共享 Skill
功能：主站网关/单文件共享/从站UDP自动发现/生命周期共享
文件: pdf_fast_handler_skill.py
版本: 1.1.0
"""
import os
import sys
import socket
import threading
import time
import json
import argparse
import logging
import signal
from pathlib import Path
from typing import Optional, List, Dict

# 第三方依赖延迟导入，便于安装检查
flask = qrcode = PIL = tkinter = None

# ===================== 基础配置 =====================
BASE_PATH = os.path.dirname(os.path.abspath(__file__))
SHARE_DIR = os.path.join(BASE_PATH, "qclaw_shared")
LOG_FILE = os.path.join(BASE_PATH, "qclaw_share.log")
ALLOWED_TYPES = {"pdf", "txt", "png", "jpg", "jpeg", "zip", "md", "docx", "xlsx", "pptx", "mp4", "mp3"}
HOST = "0.0.0.0"
DEFAULT_PORT = 8989
UDP_BROADCAST_IP = "255.255.255.255"
UDP_PORT = 10086
BROADCAST_INTERVAL = 2  # 广播间隔(秒)
DISCOVER_TIMEOUT = 8    # 发现超时(秒)
MAX_FILE_SIZE = 200 * 1024 * 1024  # 200MB

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# ===================== 依赖检查 =====================
def check_dependencies():
    """检查并导入必需的第三方库"""
    global flask, qrcode, PIL, tkinter
    missing = []
    
    try:
        from flask import Flask, request, send_from_directory, jsonify, render_template_string
        from werkzeug.utils import secure_filename
        flask = {"Flask": Flask, "request": request, "send_from_directory": send_from_directory, 
                 "jsonify": jsonify, "render_template_string": render_template_string, "secure_filename": secure_filename}
    except ImportError:
        missing.append("flask")
    
    try:
        import qrcode
        from qrcode.image.pil import PilImage
        globals()['qrcode'] = qrcode
    except ImportError:
        missing.append("qrcode")
    
    try:
        from PIL import Image, ImageTk
        PIL = {"Image": Image, "ImageTk": ImageTk}
    except ImportError:
        missing.append("pillow")
    
    try:
        import tkinter as tk
        from tkinter import Tk, Label, Button, Toplevel, Listbox, Scrollbar, END, SINGLE, messagebox
        tkinter = {"Tk": Tk, "Label": Label, "Button": Button, "Toplevel": Toplevel,
                   "Listbox": Listbox, "Scrollbar": Scrollbar, "END": END, "SINGLE": SINGLE, "messagebox": messagebox}
    except ImportError:
        missing.append("tkinter (python3-tk)")
    
    if missing:
        logger.error(f"缺少依赖: {', '.join(missing)}")
        logger.error("请运行安装脚本: bash install_pdf_fast_handler_skill.sh")
        sys.exit(1)
    logger.info("依赖检查通过 ✓")

# ===================== 共享目录初始化 =====================
def init_share_dir():
    """初始化共享目录"""
    os.makedirs(SHARE_DIR, exist_ok=True)
    logger.info(f"共享目录: {SHARE_DIR}")

# ===================== 全局状态管理 =====================
class GlobalState:
    """全局状态管理器，确保弹窗与服务生命周期同步"""
    server_running = True
    current_mode = "master"  # master / single / slave
    single_file_path: Optional[str] = None
    flask_app = None
    qr_window = None
    main_window = None
    
    @classmethod
    def shutdown(cls):
        """优雅关闭所有资源"""
        logger.info("正在关闭服务...")
        cls.server_running = False
        if cls.qr_window:
            try:
                cls.qr_window.destroy()
            except:
                pass
        if cls.main_window:
            try:
                cls.main_window.destroy()
            except:
                pass
        sys.exit(0)

# ===================== 网络工具函数 =====================
def get_local_ip() -> str:
    """获取本机局域网IP地址"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception as e:
        logger.warning(f"获取IP失败: {e}, 使用默认值")
        return "127.0.0.1"

def get_local_ips() -> List[str]:
    """获取所有本地网络接口IP"""
    ips = []
    hostname = socket.gethostname()
    try:
        for info in socket.getaddrinfo(hostname, None):
            ip = info[4][0]
            if ip.startswith("192.168.") or ip.startswith("10.") or ip.startswith("172.16."):
                if ip not in ips:
                    ips.append(ip)
    except:
        pass
    return ips if ips else [get_local_ip()]

def allowed_file(filename: str) -> bool:
    """检查文件类型是否允许"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_TYPES

# ===================== Flask 服务 =====================
def create_flask_app() -> "flask['Flask']":
    """创建并配置Flask应用"""
    app = flask["Flask"](__name__)
    app.config["UPLOAD_FOLDER"] = SHARE_DIR
    app.config["MAX_CONTENT_LENGTH"] = MAX_FILE_SIZE
    
    @app.route("/")
    def index():
        if GlobalState.current_mode == "single" and GlobalState.single_file_path:
            # 单文件模式：直接提供文件下载/预览
            filename = os.path.basename(GlobalState.single_file_path)
            return flask["send_from_directory"](
                os.path.dirname(GlobalState.single_file_path), 
                filename, 
                as_attachment=False
            )
        
        # 主站模式：文件列表 + 上传表单
        files = [f for f in os.listdir(SHARE_DIR) if os.path.isfile(os.path.join(SHARE_DIR, f))]
        html = """
        <!DOCTYPE html>
        <html><head><meta charset="UTF-8"><title>QClaw 共享网关</title>
        <style>body{font-family:sans-serif;max-width:800px;margin:2rem auto;padding:0 1rem;}
        .file-list{list-style:none;padding:0;}
        .file-list li{padding:0.5rem;border-bottom:1px solid #eee;}
        .upload-box{background:#f5f5f5;padding:1rem;border-radius:8px;margin:1rem 0;}
        a{text-decoration:none;color:#0066cc;}a:hover{text-decoration:underline;}
        </style></head><body>
        <h2>📡 QClaw 局域网共享网关</h2>
        <div class="upload-box">
            <form method=post enctype=multipart/form-data>
                <input type=file name=file multiple>
                <button type=submit>📤 上传文件</button>
            </form>
        </div>
        <h3>📁 已共享文件 ({{ files|length }})</h3>
        <ul class="file-list">
        {% for f in files %}
            <li>📄 <a href='/files/{{f}}' target='_blank'>{{f}}</a></li>
        {% endfor %}
        </ul>
        <p><small>💡 提示: 同一局域网内扫描上方二维码即可访问</small></p>
        </body></html>
        """
        return flask["render_template_string"](html, files=files)

    @app.route("/files/<path:filename>")
    def get_file(filename):
        return flask["send_from_directory"](SHARE_DIR, filename, as_attachment=True)

    @app.route("/upload", methods=["POST"])
    def upload_file():
        if "file" not in flask["request"].files:
            return flask["jsonify"]({"status": "err", "msg": "未找到文件字段"})
        
        uploaded = flask["request"].files.getlist("file")
        results = []
        
        for file in uploaded:
            if file.filename == "":
                continue
            if file and allowed_file(file.filename):
                name = flask["secure_filename"](file.filename)
                # 防止文件名冲突
                save_path = os.path.join(SHARE_DIR, name)
                if os.path.exists(save_path):
                    base, ext = os.path.splitext(name)
                    counter = 1
                    while os.path.exists(save_path):
                        name = f"{base}_{counter}{ext}"
                        save_path = os.path.join(SHARE_DIR, name)
                        counter += 1
                file.save(save_path)
                logger.info(f"文件上传成功: {name}")
                results.append({"name": name, "status": "ok"})
            else:
                results.append({"name": file.filename, "status": "err", "msg": "不支持的文件类型"})
        
        return flask["jsonify"]({"results": results})
    
    @app.route("/api/info")
    def api_info():
        """API: 获取服务信息"""
        return flask["jsonify"]({
            "mode": GlobalState.current_mode,
            "ip": get_local_ip(),
            "port": DEFAULT_PORT,
            "files_count": len(os.listdir(SHARE_DIR)) if os.path.exists(SHARE_DIR) else 0
        })
    
    return app

# ===================== UDP 主站广播 =====================
def udp_broadcast_server(port: int):
    """主站模式: 周期性广播服务信息"""
    local_ip = get_local_ip()
    broadcast_msg = json.dumps({
        "type": "qclaw_share_master",
        "version": "1.1.0",
        "ip": local_ip,
        "port": port,
        "hostname": socket.gethostname(),
        "mode": GlobalState.current_mode,
        "timestamp": time.time()
    }).encode('utf-8')

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.settimeout(1)
    
    logger.info(f"📡 开始广播: {local_ip}:{port}")
    
    while GlobalState.server_running:
        try:
            sock.sendto(broadcast_msg, (UDP_BROADCAST_IP, UDP_PORT))
            for _ in range(BROADCAST_INTERVAL):
                if not GlobalState.server_running:
                    break
                time.sleep(0.5)
        except Exception as e:
            logger.debug(f"广播发送异常: {e}")
            time.sleep(1)
    
    sock.close()
    logger.info("📡 广播服务已停止")

# ===================== UDP 从站发现 =====================
def udp_discover_masters(timeout: int = DISCOVER_TIMEOUT) -> List[Dict]:
    """从站模式: 发现局域网内的主站"""
    masters = []
    seen = set()  # 去重
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", UDP_PORT))
    sock.settimeout(1)
    
    logger.info(f"🔍 开始扫描主站 (超时: {timeout}秒)...")
    start_time = time.time()
    
    while time.time() - start_time < timeout:
        try:
            data, addr = sock.recvfrom(2048)
            info = json.loads(data.decode('utf-8', errors='ignore'))
            
            if info.get("type") == "qclaw_share_master":
                key = f"{info['ip']}:{info['port']}"
                if key not in seen:
                    seen.add(key)
                    master_info = {
                        "name": info.get("hostname", "未知主机"),
                        "ip": info["ip"],
                        "port": info["port"],
                        "mode": info.get("mode", "master"),
                        "version": info.get("version", "1.0"),
                        "display": f"{info.get('hostname', '未知')} | {info['ip']}:{info['port']} | {info.get('mode', 'master')}"
                    }
                    masters.append(master_info)
                    logger.info(f"✅ 发现主站: {master_info['display']}")
        except socket.timeout:
            continue
        except Exception as e:
            logger.debug(f"接收广播异常: {e}")
            continue
    
    sock.close()
    return masters

# ===================== GUI 弹窗: 二维码展示 =====================
def show_qr_popup(url: str, title: str = "QClaw 共享服务"):
    """显示二维码弹窗，与服务生命周期绑定"""
    if not tkinter:
        logger.error("tkinter 未可用，无法显示二维码弹窗")
        return
    
    root = tkinter["Tk"]()
    root.title(title)
    root.geometry("400x480")
    root.attributes("-topmost", True)
    GlobalState.qr_window = root
    
    def on_close():
        """关闭弹窗时同时停止服务"""
        logger.info("二维码窗口关闭，停止服务")
        GlobalState.shutdown()
    
    root.protocol("WM_DELETE_WINDOW", on_close)
    
    # 标题
    tkinter["Label"](root, text=f"🔗 访问地址:", font=("Arial", 10, "bold")).pack(pady=(15, 5))
    tkinter["Label"](root, text=url, wraplength=350, fg="#0066cc", cursor="hand").pack(pady=5)
    
    # 生成并显示二维码
    try:
        qr = qrcode.QRCode(box_size=8, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
        
        # 保存二维码图片备用
        qr_path = os.path.join(BASE_PATH, "qclaw_qr.png")
        img.save(qr_path)
        logger.info(f"二维码已保存: {qr_path}")
        
        # 在GUI中显示
        pil_img = PIL["ImageTk"].PhotoImage(img)
        qr_label = tkinter["Label"](root, image=pil_img)
        qr_label.image = pil_img  # 保持引用
        qr_label.pack(pady=10)
    except Exception as e:
        tkinter["Label"](root, text=f"⚠️ 二维码生成失败: {e}", fg="red").pack(pady=10)
    
    # 操作按钮
    btn_frame = tkinter["Frame"](root)
    btn_frame.pack(pady=10)
    
    def copy_url():
        root.clipboard_clear()
        root.clipboard_append(url)
        tkinter["messagebox"].showinfo("已复制", "链接已复制到剪贴板")
    
    tkinter["Button"](btn_frame, text="📋 复制链接", command=copy_url).pack(side="left", padx=10)
    tkinter["Button"](btn_frame, text="🚪 关闭服务", command=on_close, bg="#ff6b6b", fg="white").pack(side="left", padx=10)
    
    # 提示信息
    tkinter["Label"](root, text="💡 同一局域网设备扫码即可访问", fg="#666", font=("Arial", 9)).pack(pady=(0, 15))
    
    root.mainloop()

# ===================== GUI 弹窗: 主站选择器 =====================
def show_master_selector(masters: List[Dict]):
    """从站模式: 显示发现的主站列表供用户选择"""
    if not tkinter:
        # 无GUI时，打印列表并打开第一个
        print("\n📡 发现的主站:")
        for i, m in enumerate(masters, 1):
            print(f"  {i}. {m['display']}")
        if masters:
            import webbrowser
            url = f"http://{masters[0]['ip']}:{masters[0]['port']}"
            print(f"🔗 自动打开: {url}")
            webbrowser.open(url)
        return
    
    root = tkinter["Tk"]()
    root.title("🔍 QClaw 发现共享主站")
    root.geometry("500x350")
    root.attributes("-topmost", True)
    GlobalState.main_window = root
    
    tkinter["Label"](root, text=f"✅ 发现 {len(masters)} 个共享主站", font=("Arial", 11, "bold")).pack(pady=10)
    
    # 列表框
    listbox = tkinter["Listbox"](root, width=70, height=12, selectmode=tkinter["SINGLE"], font=("Arial", 10))
    scrollbar = tkinter["Scrollbar"](root, command=listbox.yview)
    listbox.config(yscrollcommand=scrollbar.set)
    
    scrollbar.pack(side="right", fill="y")
    listbox.pack(pady=5, padx=10)
    
    for m in masters:
        listbox.insert(tkinter["END"], m["display"])
    
    # 默认选中第一个
    if masters:
        listbox.selection_set(0)
    
    def select_master():
        selection = listbox.curselection()
        if not selection:
            tkinter["messagebox"].showwarning("提示", "请先选择一个主站")
            return
        
        master = masters[selection[0]]
        url = f"http://{master['ip']}:{master['port']}"
        logger.info(f"🔗 打开主站: {url}")
        
        import webbrowser
        webbrowser.open(url)
        root.destroy()
    
    def refresh():
        """刷新发现列表"""
        root.destroy()
        # 重新发现并显示
        new_masters = udp_discover_masters()
        if new_masters:
            show_master_selector(new_masters)
        else:
            tkinter["messagebox"].showinfo("提示", "未发现新的主站")
    
    # 按钮区域
    btn_frame = tkinter["Frame"](root)
    btn_frame.pack(pady=15)
    
    tkinter["Button"](btn_frame, text="🚀 打开选中的网关", command=select_master, bg="#4CAF50", fg="white", width=20).pack(side="left", padx=10)
    tkinter["Button"](btn_frame, text="🔄 重新扫描", command=refresh, width=12).pack(side="left", padx=10)
    tkinter["Button"](btn_frame, text="❌ 退出", command=root.destroy, width=12).pack(side="left", padx=10)
    
    # 底部提示
    tkinter["Label"](root, text="💡 双击列表项可快速打开", fg="#888", font=("Arial", 9)).pack(pady=(0, 10))
    listbox.bind("<Double-Button-1>", lambda e: select_master())
    
    root.mainloop()

# ===================== 服务启动器 =====================
def start_server(port: int, file_path: Optional[str] = None):
    """启动共享服务（主站/单文件模式）"""
    GlobalState.flask_app = create_flask_app()
    local_ip = get_local_ip()
    
    # 构建访问URL
    if file_path and os.path.exists(file_path):
        GlobalState.current_mode = "single"
        GlobalState.single_file_path = os.path.abspath(file_path)
        filename = os.path.basename(file_path)
        url = f"http://{local_ip}:{port}/{filename}"
        logger.info(f"📄 单文件模式: {filename}")
    else:
        GlobalState.current_mode = "master"
        url = f"http://{local_ip}:{port}"
        logger.info(f"🌐 主站模式: {url}")
    
    # 启动UDP广播线程
    broadcast_thread = threading.Thread(
        target=udp_broadcast_server, 
        args=(port,), 
        daemon=True,
        name="UDPBroadcaster"
    )
    broadcast_thread.start()
    
    # 启动二维码弹窗线程（需在主线程运行tkinter）
    def launch_gui():
        show_qr_popup(url)
    
    gui_thread = threading.Thread(target=launch_gui, daemon=True, name="QRPopup")
    gui_thread.start()
    
    # 信号处理
    def signal_handler(signum, frame):
        logger.info(f"收到信号 {signum}, 准备关闭")
        GlobalState.shutdown()
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 启动Flask服务（阻塞）
    logger.info(f"🚀 Flask服务启动: {HOST}:{port}")
    try:
        GlobalState.flask_app.run(host=HOST, port=port, debug=False, use_reloader=False, threaded=True)
    except OSError as e:
        if "Address already in use" in str(e):
            logger.error(f"❌ 端口 {port} 被占用，请尝试 --port 指定其他端口")
        else:
            logger.error(f"服务启动失败: {e}")
        GlobalState.shutdown()

# ===================== 主入口 =====================
def main():
    """程序入口"""
    parser = argparse.ArgumentParser(
        description="🔗 QClaw 局域网二维码文件共享工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 主站模式（文件网关）
  python %(prog)s --master
  
  # 单文件快速共享
  python %(prog)s --single /path/to/document.pdf
  
  # 从站模式（自动发现）
  python %(prog)s --slave
  
  # 自定义端口
  python %(prog)s --master --port 9000
        """
    )
    
    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument("--master", action="store_true", help="主站模式：开启文件共享网关")
    mode_group.add_argument("--single", metavar="FILE", help="单文件模式：直接共享指定文件")
    mode_group.add_argument("--slave", action="store_true", help="从站模式：自动发现并连接主站")
    
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"服务端口 (默认: {DEFAULT_PORT})")
    parser.add_argument("--dir", type=str, default=SHARE_DIR, help=f"共享目录路径 (默认: {SHARE_DIR})")
    parser.add_argument("--timeout", type=int, default=DISCOVER_TIMEOUT, help=f"从站发现超时秒数 (默认: {DISCOVER_TIMEOUT})")
    parser.add_argument("--no-gui", action="store_true", help="禁用GUI弹窗（适合服务器/无桌面环境）")
    
    args = parser.parse_args()
    
    # 初始化
    check_dependencies()
    init_share_dir()
    if args.dir != SHARE_DIR:
        global SHARE_DIR
        SHARE_DIR = os.path.abspath(args.dir)
        os.makedirs(SHARE_DIR, exist_ok=True)
    
    logger.info("=" * 50)
    logger.info("🎯 QClaw 局域网共享工具启动")
    logger.info(f"📁 共享目录: {SHARE_DIR}")
    logger.info(f"🌐 本地IP: {get_local_ip()}")
    logger.info("=" * 50)
    
    # 执行对应模式
    if args.slave:
        # 从站模式
        masters = udp_discover_masters(timeout=args.timeout)
        if not masters:
            print("\n❌ 未发现任何共享主站")
            print("💡 请确保主站已启动，且在同一局域网内")
            sys.exit(1)
        
        if args.no_gui:
            # 无GUI时直接打开第一个
            import webbrowser
            first = masters[0]
            url = f"http://{first['ip']}:{first['port']}"
            print(f"🔗 自动连接: {url}")
            webbrowser.open(url)
        else:
            show_master_selector(masters)
    
    else:
        # 主站/单文件模式
        if args.no_gui:
            logger.warning("⚠️  --no-gui 模式: 二维码弹窗已禁用")
            # 仅打印链接
            local_ip = get_local_ip()
            if args.single:
                filename = os.path.basename(args.single)
                print(f"\n📄 单文件共享: {filename}")
                print(f"🔗 访问链接: http://{local_ip}:{args.port}/{filename}")
            else:
                print(f"\n🌐 主站网关: http://{local_ip}:{args.port}")
            print(f"📱 同一局域网设备可直接访问以上链接")
        
        start_server(args.port, file_path=args.single if hasattr(args, 'single') else None)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n👋 用户中断，服务已停止")
        sys.exit(0)
    except Exception as e:
        logger.exception(f"❌ 程序异常: {e}")
        sys.exit(1)