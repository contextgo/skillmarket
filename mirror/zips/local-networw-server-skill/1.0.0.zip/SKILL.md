---
name: local-network-server-skill
description: 局域网二维码文件共享技能。支持主站网关/单文件直传/从站自动发现三种模式，零配置跨设备共享，生命周期同步管理。
homepage: https://github.com/QClaw/skills
metadata:
  {
    "clawdbot":
      {
        "emoji": "📡",
        "requires": { "bins": ["python3"], "packages": ["flask", "qrcode[pil]", "pillow", "werkzeug"] },
        "primaryEnv": "python3",
        "systemDeps": { 
          "linux": ["python3-tk", "python3-pil.imagetk"], 
          "macos": [], 
          "windows": [] 
        }
      }
  }
---

# 🔗 局域网二维码文件共享技能

> 零配置 · 跨设备 · 生命周期同步 · 扫码即用

通过二维码实现局域网内快速文件共享，无需互联网、无需账号、无需手动配置IP。支持**主站网关**、**单文件直传**、**从站自动发现**三种工作模式。

---

## 🤖 Agent 执行指令

**执行本技能后，代理必须：**

1. **显示连接信息**：
   - 主站/单文件模式：展示二维码图片 `![二维码](sandbox:/path/to/qclaw_qr.png)` + 访问链接
   - 从站模式：列出发现的主站列表，提供选择指引

2. **确认服务状态**：
   - 明确告知用户服务已启动/已连接
   - 标注监听端口、局域网IP、共享目录路径

3. **提供操作指引**：
   - 手机端：扫码 → 浏览器打开 → 上传/下载
   - 电脑端：复制链接到浏览器访问
   - 关闭服务：关闭窗口或按 `Ctrl+C`

4. **异常处理提示**：
   - 端口冲突：建议更换 `--port` 参数
   - 依赖缺失：提示执行安装脚本
   - 发现失败：检查防火墙/网段配置

---

## 🚀 快速开始

```bash
# 第1步：安装依赖（首次使用）
bash install_local_network_server_skill.sh

# 第2步：选择模式启动

# 🔹 模式A：主站网关（多人共享中心）
python3 local_network_server_skill.py --master

# 🔹 模式B：单文件直传（快速分享指定文件）
python3 local_network_server_skill.py --single /path/to/document.pdf

# 🔹 模式C：从站发现（搜索并连接他人共享）
python3 local_network_server_skill.py --slave

# 第3步：按弹窗指引扫码或复制链接访问