# EdgeOne Pages 技能发布指南

## 发布平台

本技能可发布到以下平台：

### 1. ClawHub（推荐）

**官网地址**：https://clawhub.ai

#### 发布步骤：

1. **访问发布页面**
   打开 https://clawhub.ai/import

2. **填写表单**
   
   | 字段 | 填写内容 |
   |------|---------|
   | Slug | `edgeone-pages-deploy-free` |
   | Display name | `EdgeOne Pages 网页免费部署` |
   | Version | `1.0.0` |
   | Tags | `latest` |
   | License | 勾选 MIT-0 |

3. **上传文件夹**
   - 点击 "Drop a folder"
   - 选择 `C:\Users\haicgt\.workbuddy\skills\edgeone-pages` 文件夹

4. **填写 Changelog**
   ```
   首次发布：免登录一键部署 HTML 到腾讯云 EdgeOne Pages
   ```

5. **发布**
   - 点击 "Publish skill"
   - 等待审核（通常几分钟）

---

### 2. SkillHub（腾讯官方）

**官网地址**：https://skillhub.tencent.com

#### 发布步骤：

1. **访问 SkillHub**
   打开 https://skillhub.tencent.com

2. **找到发布入口**
   - 点击右上角「开发者中心」或「发布技能」
   - 如果没有，可能是邀请制或需要申请

3. **提交审核**
   - 填写技能名称、描述、分类
   - 上传技能文件夹（包含 SKILL.md）
   - 等待官方审核

---

## 发布前检查清单

- [x] SKILL.md 文件存在
- [x] README.md 文件存在
- [x] deploy.py 脚本可正常运行
- [x] requirements.txt 包含依赖
- [x] 文件夹内无 .git、LICENSE 等非文本文件
- [x] Slug 格式正确（小写字母 + 短横线）

---

## 发布后验证

发布成功后，可以通过以下方式验证：

1. 在平台上搜索 "EdgeOne Pages"
2. 访问技能详情页
3. 在 CodeBuddy 中安装测试

---

## 资料包

本文件夹包含以下发布资料：

```
edgeone-pages/
├── SKILL.md        # 技能核心描述（必须）
├── README.md       # 详细使用文档
├── requirements.txt # Python 依赖
├── scripts/
│   └── deploy.py   # 部署脚本
└── PUBLISH.md      # 本文件 - 发布指南
```

---

## 联系方式

如有问题，可通过以下方式联系作者：
- (可填写你的邮箱或社交账号)

---

祝发布顺利！🎉
