#!/usr/bin/env python3
"""
EdgeOne Pages 部署工具
将 HTML 内容或文件一键部署到 EdgeOne Pages，返回公开访问链接。

用法：
    python deploy.py --file path/to/index.html
    python deploy.py --html "<html>...</html>"
    python deploy.py --file hupu_clone.html --open
"""

import argparse
import json
import os
import sys

try:
    import requests
except ImportError:
    print("[ERROR] 缺少依赖：pip install requests", file=sys.stderr)
    sys.exit(1)


BASE_URL_API = "https://mcp.edgeone.site/get_base_url"


def get_base_url() -> str:
    """获取 EdgeOne Pages 上传端点"""
    r = requests.get(BASE_URL_API, timeout=10)
    r.raise_for_status()
    return r.json()["baseUrl"]


def deploy_html(html: str) -> str:
    """
    部署 HTML 字符串到 EdgeOne Pages
    返回公开访问 URL
    """
    base_url = get_base_url()
    r = requests.post(base_url, json={"value": html}, timeout=30)
    r.raise_for_status()
    result = r.json()
    return result["url"]


def deploy_file(filepath: str) -> str:
    """
    读取本地 HTML 文件并部署
    返回公开访问 URL
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"文件不存在: {filepath}")

    with open(filepath, "r", encoding="utf-8") as f:
        html = f.read()

    size_kb = len(html.encode("utf-8")) / 1024
    print(f"  文件大小: {size_kb:.1f} KB")
    return deploy_html(html)


def main():
    parser = argparse.ArgumentParser(
        description="一键部署 HTML 到 EdgeOne Pages，获取公开访问链接"
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--file", "-f", help="要部署的 HTML 文件路径")
    group.add_argument("--html", help="直接传入 HTML 字符串内容")
    parser.add_argument(
        "--open", "-o", action="store_true", help="部署后自动在浏览器打开"
    )
    parser.add_argument(
        "--json", action="store_true", help="以 JSON 格式输出结果（方便脚本调用）"
    )

    args = parser.parse_args()

    print("正在部署到 EdgeOne Pages...")

    try:
        if args.file:
            print(f"  源文件: {args.file}")
            url = deploy_file(args.file)
        else:
            url = deploy_html(args.html)

        if args.json:
            print(json.dumps({"success": True, "url": url}))
        else:
            print(f"\n✅ 部署成功！")
            print(f"🔗 访问链接: {url}")

        if args.open:
            import webbrowser
            webbrowser.open(url)

        return url

    except requests.exceptions.ConnectionError:
        msg = "网络连接失败，请检查网络"
        if args.json:
            print(json.dumps({"success": False, "error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        msg = str(e)
        if args.json:
            print(json.dumps({"success": False, "error": msg}))
        else:
            print(f"❌ 部署失败: {msg}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
