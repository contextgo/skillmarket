# EdgeOne Pages 一键部署 Skill

## 功能简介

将本地 HTML 文件或 HTML 字符串**一键部署到腾讯 EdgeOne Pages**，秒级返回公开访问链接，无需登录、无需备案、免费使用。

底层调用 `https://mcp.edgeone.site/kv/set` 接口，不依赖 MCP 协议，纯 HTTP 调用。

---

## 使用方式

直接告诉我：

- "把 `hupu_clone.html` 部署到线上"
- "帮我把这个 HTML 文件部署到 EdgeOne，给我个访问链接"
- "把刚写好的页面发布上去"
- "部署到 EdgeOne Pages"

我会自动调用部署脚本，并把公开访问链接返回给你。

---

## 命令行直接使用

```bash
# 部署本地 HTML 文件
python skills/edgeone-pages/scripts/deploy.py --file path/to/index.html

# 部署并自动打开浏览器预览
python skills/edgeone-pages/scripts/deploy.py --file index.html --open

# 直接传入 HTML 字符串
python skills/edgeone-pages/scripts/deploy.py --html "<html><body><h1>Hello</h1></body></html>"

# 以 JSON 格式输出（方便脚本调用）
python skills/edgeone-pages/scripts/deploy.py --file index.html --json
```

---

## 参数说明

| 参数 | 说明 |
|------|------|
| `--file / -f` | 本地 HTML 文件路径（与 --html 二选一） |
| `--html` | 直接传入 HTML 字符串（与 --file 二选一） |
| `--open / -o` | 部署后自动在浏览器打开链接 |
| `--json` | 以 JSON 格式输出 `{"success": true, "url": "..."}` |

---

## 返回示例

```
正在部署到 EdgeOne Pages...
  源文件: hupu_clone.html
  文件大小: 29.5 KB

✅ 部署成功！
🔗 访问链接: https://mcp.edgeone.site/share/xxxxxxxxxxxxxx
```

---

## 技术说明

- **接口**：`GET https://mcp.edgeone.site/get_base_url` 获取上传端点，`POST https://mcp.edgeone.site/kv/set` 上传内容
- **无需认证**：免登录、免 API Key
- **内容存储**：EdgeOne 边缘 KV 存储，全球加速访问
- **注意**：链接为临时性公开链接，适合预览和分享，不保证永久有效

---

## 环境要求

### 🤖 AI 编程工具中使用（推荐）
**无需安装任何依赖**，主流 AI 编程工具（CodeBuddy、WorkBuddy、OpenClaw、Cursor 等）均内置 Python 环境，技能开箱即用。

### 💻 本地命令行使用
仅当需要本地单独运行脚本时需要：

1. **安装 Python 3.x**
   ```bash
   python --version
   ```

2. **安装依赖**
   ```bash
   pip install requests
   ```

---

## 适用场景

- AI 生成的网页快速发布预览
- 静态页面临时分享给他人
- 本地 HTML 原型一键上线
- 把做好的页面发给客户/同事看效果
