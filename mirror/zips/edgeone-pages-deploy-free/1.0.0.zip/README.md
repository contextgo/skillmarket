# EdgeOne Pages - 一键部署 HTML 到腾讯云 EdgeOne

## 技能简介

| 项目 | 内容 |
|------|------|
| **技能名称** | EdgeOne Pages 部署 |
| **Slug** | `edgeone-pages-deploy` |
| **版本** | 1.0.0 |
| **作者** | (你的用户名) |
| **分类** | 工具类 / 部署类 |
| **许可证** | MIT |

---

## 一句话介绍

免登录、免密钥，一键将 HTML 页面部署到腾讯云 EdgeOne Pages，秒级返回全球可访问链接。

---

## 核心功能

- ✅ **零门槛部署** - 无需登录账号、无需配置 API Key
- ✅ **秒级生效** - 部署后立即获得公开访问链接
- ✅ **全球加速** - 依托腾讯云 EdgeOne 边缘网络
- ✅ **多种方式** - 支持文件部署和直接传入 HTML 字符串
- ✅ **自动打开** - 部署后可选择自动在浏览器打开预览

---

## 适用场景

| 场景 | 说明 |
|------|------|
| AI 生成网页快速预览 | 用 AI 生成页面后一键发布测试 |
| 原型分享 | 将 HTML 原型快速分享给客户/同事 |
| 临时页面托管 | 不需要服务器，快速上线临时页面 |
| 文档演示 | 生成 HTML 文档后直接在线展示 |

---

## 使用示例

### 对话方式（推荐）

```
用户：把 login.html 部署到线上
助手：正在部署到 EdgeOne Pages...
      文件大小: 3.2 KB
      ✅ 部署成功！
      🔗 访问链接: https://mcp.edgeone.site/share/xxxxxxxxxxxxxx
```

### 命令行方式

```bash
# 部署本地 HTML 文件
python deploy.py --file index.html

# 部署后自动打开浏览器
python deploy.py --file index.html --open

# 直接传入 HTML 字符串
python deploy.py --html "<html><body><h1>Hello</h1></body></html>"

# JSON 格式输出（方便脚本调用）
python deploy.py --file index.html --json
```

---

## 技术原理

| 项目 | 说明 |
|------|------|
| **上传接口** | `POST https://mcp.edgeone.site/kv/set` |
| **获取端点** | `GET https://mcp.edgeone.site/get_base_url` |
| **存储方式** | EdgeOne 边缘 KV 存储 |
| **依赖** | Python 3.x + requests 库 |

---

## 环境要求

### 在 CodeBuddy 中使用（推荐）
**无需安装任何依赖**，开箱即用。

### 本地命令行使用
```bash
# 1. 安装 Python 3.x
# 2. 安装依赖
pip install requests
```

---

## 文件结构

```
edgeone-pages/
├── SKILL.md           # 技能核心描述文件
├── README.md          # 详细使用文档
├── requirements.txt   # Python 依赖
└── scripts/
    └── deploy.py      # 部署脚本
```

---

## 发布记录 (Changelog)

### v1.0.0 (2026-04-09)
- 首次发布
- 支持文件部署和字符串部署
- 支持自动打开浏览器预览
- 支持 JSON 格式输出

---

## 注意事项

1. 链接为临时公开链接，适合预览分享，不保证永久有效
2. 单次部署内容大小建议控制在 10MB 以内
3. 不适合部署敏感信息或生产环境内容

---

## 许可证

MIT License - 可免费商用，欢迎 fork 和 star！
