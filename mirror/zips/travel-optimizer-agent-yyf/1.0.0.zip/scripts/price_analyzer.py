#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
价格趋势分析工具
用于分析机票价格历史数据，预测最优购票时机
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

class PriceAnalyzer:
    """机票价格趋势分析器"""
    
    def __init__(self):
        self.holiday_patterns = {
            "五一": {
                "peak_dates": ["04-30", "05-01", "05-05"],
                "cheap_dates": ["05-02", "05-03", "05-04"],
                "book_before_days": 21,  # 提前3周
                "price_multiplier": {"peak": 2.5, "normal": 1.5, "cheap": 1.0}
            },
            "国庆": {
                "peak_dates": ["09-30", "10-01", "10-07"],
                "cheap_dates": ["10-02", "10-03", "10-06"],
                "book_before_days": 30,
                "price_multiplier": {"peak": 3.0, "normal": 1.8, "cheap": 1.0}
            },
            "春节": {
                "peak_dates": ["除夕前3天", "初五", "初六"],
                "cheap_dates": ["除夕", "初七后"],
                "book_before_days": 45,
                "price_multiplier": {"peak": 4.0, "normal": 2.0, "cheap": 1.0}
            }
        }
    
    def detect_holiday(self, date_str: str) -> Tuple[str, str]:
        """
        检测日期所属节假日类型
        返回: (节假日名称, 日期类型: peak/normal/cheap)
        """
        date = datetime.strptime(date_str, "%Y-%m-%d")
        month_day = date.strftime("%m-%d")
        
        for holiday, pattern in self.holiday_patterns.items():
            if month_day in pattern["peak_dates"]:
                return holiday, "peak"
            elif month_day in pattern["cheap_dates"]:
                return holiday, "cheap"
        
        # 检测是否在节假日附近
        for holiday, pattern in self.holiday_patterns.items():
            for peak_date in pattern["peak_dates"]:
                peak = datetime.strptime(f"{date.year}-{peak_date}", "%Y-%m-%d")
                diff = abs((date - peak).days)
                if diff <= 3:
                    return holiday, "normal"
        
        return None, "normal"
    
    def calculate_optimal_booking_time(self, 
                                       departure_date: str,
                                       current_date: str = None) -> Dict:
        """
        计算最佳购票时间
        
        Args:
            departure_date: 出发日期 (YYYY-MM-DD)
            current_date: 当前日期 (YYYY-MM-DD)，默认今天
        
        Returns:
            包含建议的字典
        """
        if current_date is None:
            current_date = datetime.now().strftime("%Y-%m-%d")
        
        dep = datetime.strptime(departure_date, "%Y-%m-%d")
        cur = datetime.strptime(current_date, "%Y-%m-%d")
        days_until = (dep - cur).days
        
        holiday, date_type = self.detect_holiday(departure_date)
        
        result = {
            "departure_date": departure_date,
            "days_until_departure": days_until,
            "holiday": holiday,
            "date_type": date_type,
            "urgency": "",
            "recommendation": "",
            "expected_price_trend": ""
        }
        
        # 判断紧急程度
        if holiday:
            pattern = self.holiday_patterns[holiday]
            optimal_days = pattern["book_before_days"]
            
            if days_until > optimal_days + 7:
                result["urgency"] = "时间充裕"
                result["recommendation"] = f"建议 {optimal_days} 天前（约{(dep - timedelta(days=optimal_days)).strftime('%m月%d日')}）开始关注价格"
                result["expected_price_trend"] = "目前价格可能偏高，建议等待"
            elif days_until > optimal_days:
                result["urgency"] = "即将进入最佳购票期"
                result["recommendation"] = "未来一周内密切关注价格，设置价格提醒"
                result["expected_price_trend"] = "价格即将进入低位区间"
            elif days_until > 7:
                result["urgency"] = "建议尽快购买"
                result["recommendation"] = "已进入最佳购票窗口期，看到合适价格立即下手"
                result["expected_price_trend"] = "价格可能开始上涨"
            else:
                result["urgency"] = "紧急"
                result["recommendation"] = "时间紧迫，有票就买，不要犹豫"
                result["expected_price_trend"] = "价格将持续上涨，余票紧张"
        else:
            # 非节假日
            if days_until > 28:
                result["urgency"] = "时间充裕"
                result["recommendation"] = "建议提前2-4周购票，目前可观望"
                result["expected_price_trend"] = "价格可能波动，建议设置提醒"
            elif days_until > 14:
                result["urgency"] = "正常"
                result["recommendation"] = "可以开始购票，周二周三通常有低价"
                result["expected_price_trend"] = "价格相对稳定"
            elif days_until > 7:
                result["urgency"] = "建议尽快"
                result["recommendation"] = "建议本周内完成购票"
                result["expected_price_trend"] = "价格可能小幅上涨"
            else:
                result["urgency"] = "紧急"
                result["recommendation"] = "临近出发，有票就买"
                result["expected_price_trend"] = "价格较高，余票有限"
        
        return result
    
    def compare_transport_modes(self, 
                                distance_km: float,
                                adults: int = 2,
                                children: int = 0,
                                child_age: int = None) -> Dict:
        """
        对比不同出行方式
        
        Args:
            distance_km: 距离（公里）
            adults: 成人数量
            children: 儿童数量
            child_age: 儿童年龄（用于判断票价）
        
        Returns:
            各出行方式对比
        """
        total_people = adults + children
        
        # 估算价格（仅供参考）
        # 飞机：约 0.8-1.5 元/公里（含税）
        # 高铁：约 0.4-0.6 元/公里
        # 自驾：约 0.5-0.8 元/公里（油费+过路费）
        
        results = {
            "飞机": {
                "estimated_cost_per_person": distance_km * 1.0,
                "total_cost": distance_km * 1.0 * total_people,
                "time_hours": 1.5 + distance_km / 800,  # 飞行时间 + 机场时间
                "comfort": "中",
                "suitable_for_family": "适合" if distance_km > 800 else "短途不划算",
                "notes": "2岁以下婴儿票10%，2-12岁儿童票50%"
            },
            "高铁": {
                "estimated_cost_per_person": distance_km * 0.5,
                "total_cost": distance_km * 0.5 * total_people,
                "time_hours": distance_km / 250,  # 高铁平均时速
                "comfort": "高",
                "suitable_for_family": "非常适合" if distance_km < 1200 else "长途较累",
                "notes": "1.2米以下儿童免票，空间大适合带娃"
            },
            "自驾": {
                "estimated_cost_per_person": distance_km * 0.6,
                "total_cost": distance_km * 0.6,  # 按车算，不按人
                "time_hours": distance_km / 80,  # 含休息
                "comfort": "高",
                "suitable_for_family": "适合" if distance_km < 600 else "长途太累",
                "notes": "自由灵活，但司机累，需考虑娃的耐受度"
            }
        }
        
        # 儿童票价调整
        if children > 0 and child_age is not None:
            if child_age < 2:
                # 婴儿票10%
                results["飞机"]["total_cost"] = (
                    distance_km * 1.0 * adults + 
                    distance_km * 1.0 * 0.1 * children
                )
            elif child_age < 12:
                # 儿童票50%，但有时不如成人折扣票
                child_price = min(distance_km * 1.0 * 0.5, distance_km * 0.8)
                results["飞机"]["total_cost"] = (
                    distance_km * 1.0 * adults + 
                    child_price * children
                )
        
        return results
    
    def format_recommendation(self, analysis: Dict) -> str:
        """格式化输出建议"""
        lines = [
            f"📅 出发日期: {analysis['departure_date']}",
            f"⏰ 距离出发还有: {analysis['days_until_departure']} 天",
        ]
        
        if analysis['holiday']:
            lines.append(f"🎉 节假日: {analysis['holiday']} ({analysis['date_type']})")
        
        lines.extend([
            f"🔥 紧急程度: {analysis['urgency']}",
            f"💡 建议: {analysis['recommendation']}",
            f"📈 价格趋势: {analysis['expected_price_trend']}"
        ])
        
        return "\n".join(lines)


def main():
    """命令行入口"""
    import sys
    
    analyzer = PriceAnalyzer()
    
    if len(sys.argv) < 2:
        print("用法: python price_analyzer.py <出发日期> [当前日期]")
        print("示例: python price_analyzer.py 2025-05-01")
        print("      python price_analyzer.py 2025-05-01 2025-04-08")
        return
    
    departure = sys.argv[1]
    current = sys.argv[2] if len(sys.argv) > 2 else None
    
    result = analyzer.calculate_optimal_booking_time(departure, current)
    print(analyzer.format_recommendation(result))
    
    # 如果提供了距离，也输出交通方式对比
    if len(sys.argv) > 3:
        distance = float(sys.argv[3])
        print("\n" + "="*50)
        print("🚗 交通方式对比")
        print("="*50)
        comparison = analyzer.compare_transport_modes(distance)
        for mode, info in comparison.items():
            print(f"\n{mode}:")
            for key, value in info.items():
                print(f"  {key}: {value}")


if __name__ == "__main__":
    main()
