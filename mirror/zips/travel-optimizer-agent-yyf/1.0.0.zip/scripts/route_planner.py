#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
路线规划工具
计算最优出行路线，考虑时间、价格、舒适度
"""

import json
from typing import Dict, List, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta

@dataclass
class FlightOption:
    """航班选项"""
    airline: str
    flight_no: str
    departure_time: str
    arrival_time: str
    price: float
    platform: str
    is_direct: bool = True
    stops: List[str] = None
    
    def duration_minutes(self) -> int:
        """计算飞行时长（分钟）"""
        dep = datetime.strptime(self.departure_time, "%H:%M")
        arr = datetime.strptime(self.arrival_time, "%H:%M")
        if arr < dep:  # 跨天
            arr += timedelta(days=1)
        return int((arr - dep).total_seconds() / 60)
    
    def format_duration(self) -> str:
        """格式化时长"""
        mins = self.duration_minutes()
        hours = mins // 60
        minutes = mins % 60
        return f"{hours}h{minutes}m"


@dataclass
class TravelPlan:
    """完整出行方案"""
    name: str
    outbound: FlightOption
    return_flight: FlightOption = None
    total_price: float = 0
    score: float = 0  # 综合评分
    pros: List[str] = None
    cons: List[str] = None


class RoutePlanner:
    """路线规划器"""
    
    def __init__(self):
        self.airline_ratings = {
            "中国国航": 4.5,
            "南方航空": 4.3,
            "东方航空": 4.2,
            "海南航空": 4.4,
            "厦门航空": 4.6,
            "四川航空": 4.3,
            "春秋航空": 3.8,  # 廉航
            "吉祥航空": 4.2,
        }
    
    def score_flight(self, flight: FlightOption, 
                     has_child: bool = False,
                     prefer_morning: bool = True) -> float:
        """
        给航班打分（满分100）
        
        评分维度：
        - 价格 (30分): 越低越好
        - 时间便利性 (25分): 早班机/午睡时段加分
        - 航司质量 (20分): 准点率、服务
        - 直飞优先 (15分): 带娃强烈建议直飞
        - 时长 (10分): 越短越好
        """
        score = 0
        
        # 价格分（假设基准价1000，越低分越高）
        price_score = max(0, 30 - (flight.price - 500) / 50)
        score += min(30, price_score)
        
        # 时间便利性
        dep_hour = int(flight.departure_time.split(":")[0])
        if 7 <= dep_hour <= 9:  # 早班机
            score += 25
        elif 12 <= dep_hour <= 14:  # 午睡时段
            score += 20 if has_child else 15
        elif 20 <= dep_hour <= 22:  # 晚班机
            score += 10
        else:  # 其他时段
            score += 15
        
        # 航司质量
        airline_score = self.airline_ratings.get(flight.airline, 4.0)
        score += airline_score * 4  # 满分20
        
        # 直飞加分
        if flight.is_direct:
            score += 15 if has_child else 10
        else:
            score += 5
        
        # 时长分
        duration = flight.duration_minutes()
        if duration < 120:
            score += 10
        elif duration < 180:
            score += 8
        elif duration < 240:
            score += 5
        else:
            score += max(0, 10 - (duration - 240) / 60)
        
        return round(score, 1)
    
    def find_best_options(self, 
                          flights: List[FlightOption],
                          has_child: bool = False,
                          top_n: int = 3) -> List[Tuple[FlightOption, float]]:
        """
        找出最优选项
        
        Returns:
            [(flight, score), ...] 按分数排序
        """
        scored = [(f, self.score_flight(f, has_child)) for f in flights]
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_n]
    
    def compare_platforms(self, 
                          platform_prices: Dict[str, float],
                          has_child: bool = False) -> Dict:
        """
        对比各平台，给出购买建议
        """
        platform_features = {
            "携程": {
                "service": 5,  # 客服好
                "refund": 4,   # 退改方便
                "child_friendly": 5,  # 儿童票流程成熟
            },
            "去哪儿": {
                "service": 3,
                "refund": 3,
                "child_friendly": 3,
            },
            "飞猪": {
                "service": 3,
                "refund": 3,
                "child_friendly": 4,
            },
            "航司官网": {
                "service": 4,
                "refund": 4,
                "child_friendly": 4,
            }
        }
        
        # 计算综合得分（价格 + 服务）
        min_price = min(platform_prices.values())
        
        results = {}
        for platform, price in platform_prices.items():
            features = platform_features.get(platform, {"service": 3, "refund": 3, "child_friendly": 3})
            
            # 价格分（最低价为满分）
            price_score = (min_price / price) * 40
            
            # 服务分
            service_score = features["service"] * 4  # 满分20
            refund_score = features["refund"] * 4    # 满分20
            child_score = features["child_friendly"] * 5 if has_child else 0  # 满分20
            
            total_score = price_score + service_score + refund_score + child_score
            
            results[platform] = {
                "price": price,
                "price_score": round(price_score, 1),
                "service_score": service_score,
                "total_score": round(total_score, 1),
                "recommendation": ""
            }
        
        # 排序并生成建议
        sorted_results = sorted(results.items(), key=lambda x: x[1]["total_score"], reverse=True)
        
        best = sorted_results[0]
        if has_child:
            if best[0] in ["携程", "航司官网"]:
                best[1]["recommendation"] = "带娃首选，退改方便"
            else:
                best[1]["recommendation"] = "价格便宜，但退改需注意"
        else:
            best[1]["recommendation"] = "综合最优"
        
        return dict(sorted_results)
    
    def generate_travel_summary(self,
                                departure: str,
                                destination: str,
                                dates: Tuple[str, str],
                                people: Tuple[int, int, int],  # 成人,儿童,婴儿
                                best_flight: FlightOption,
                                platform: str,
                                total_cost: float) -> str:
        """
        生成出行方案摘要
        """
        adults, children, infants = people
        
        summary = f"""
╔══════════════════════════════════════════════════════════╗
║                    🎯 最优出行方案                        ║
╚══════════════════════════════════════════════════════════╝

📍 行程: {departure} → {destination}
📅 日期: {dates[0]} 至 {dates[1]}
👨‍👩‍👧 人员: {adults}成人 {f"{children}儿童 " if children else ""}{f"{infants}婴儿" if infants else ""}

✈️ 推荐航班
─────────────────────────────────────────
航司: {best_flight.airline} {best_flight.flight_no}
时间: {best_flight.departure_time} - {best_flight.arrival_time}
时长: {best_flight.format_duration()}
价格: ¥{best_flight.price}/人
平台: {platform}

💰 费用估算
─────────────────────────────────────────
机票: ¥{total_cost}
机建燃油: ¥{50 * (adults + children)} (成人¥50/人，儿童¥50/人)
{'婴儿票: ¥' + str(int(best_flight.price * 0.1 * infants)) if infants else ''}
预估总计: ¥{total_cost + 50 * (adults + children) + (int(best_flight.price * 0.1 * infants) if infants else 0)}

📋 购票建议
─────────────────────────────────────────
1. 建议通过 {platform} 购买
2. 提前24小时在线值机选座
3. 携带证件: 成人身份证{f", 儿童户口本" if children or infants else ""}
4. {'2岁儿童需购买儿童票（50%票价）' if children else ''}
{f"{infants}婴儿可购买婴儿票（10%票价，无座）" if infants else ''}

⚠️ 注意事项
─────────────────────────────────────────
• 建议提前2小时到达机场
• 带娃可走爱心通道优先安检
• 随身带零食、iPad、换洗衣物
• 起飞降落时让娃喝水/吃奶缓解耳压
"""
        return summary


def main():
    """命令行入口"""
    import sys
    
    planner = RoutePlanner()
    
    if len(sys.argv) < 2:
        print("用法:")
        print("  python route_planner.py demo    # 运行示例")
        print("  python route_planner.py score   # 测试评分系统")
        return
    
    if sys.argv[1] == "demo":
        # 示例数据
        flights = [
            FlightOption("中国国航", "CA1234", "08:00", "11:30", 1200, "携程"),
            FlightOption("南方航空", "CZ5678", "14:00", "17:30", 980, "去哪儿"),
            FlightOption("春秋航空", "9C9012", "06:30", "10:00", 680, "飞猪"),
            FlightOption("海南航空", "HU3456", "20:00", "23:30", 850, "携程"),
        ]
        
        print("="*60)
        print("🧒 带娃家庭推荐（有2岁儿童）")
        print("="*60)
        best_with_child = planner.find_best_options(flights, has_child=True)
        for i, (flight, score) in enumerate(best_with_child, 1):
            print(f"\n{i}. {flight.airline} {flight.flight_no}")
            print(f"   时间: {flight.departure_time}-{flight.arrival_time}")
            print(f"   价格: ¥{flight.price}  平台: {flight.platform}")
            print(f"   评分: {score}/100")
        
        print("\n" + "="*60)
        print("👤 成人出行推荐")
        print("="*60)
        best_adult = planner.find_best_options(flights, has_child=False)
        for i, (flight, score) in enumerate(best_adult, 1):
            print(f"\n{i}. {flight.airline} {flight.flight_no}")
            print(f"   时间: {flight.departure_time}-{flight.arrival_time}")
            print(f"   价格: ¥{flight.price}  平台: {flight.platform}")
            print(f"   评分: {score}/100")
    
    elif sys.argv[1] == "score":
        # 测试评分系统
        test_flight = FlightOption("中国国航", "CA1234", "08:00", "11:30", 1200, "携程")
        
        print("测试航班评分系统")
        print(f"航班: {test_flight.airline} {test_flight.flight_no}")
        print(f"时间: {test_flight.departure_time}-{test_flight.arrival_time}")
        print(f"价格: ¥{test_flight.price}")
        print()
        
        child_score = planner.score_flight(test_flight, has_child=True)
        adult_score = planner.score_flight(test_flight, has_child=False)
        
        print(f"带娃家庭评分: {child_score}/100")
        print(f"成人出行评分: {adult_score}/100")


if __name__ == "__main__":
    main()
