# Xeon ASR Skill

基于 OpenVINO Qwen3-ASR 模型的语音转文字技能，为 OpenClaw/QQBot 提供本地语音识别能力。

## 架构说明

双服务架构（必须同时运行）：

| 服务 | 端口 | 类型 | 作用 |
|------|------|------|------|
| **Flask ASR** | 5001 | Python | 加载 Qwen3-ASR 模型，执行本地推理 |
| **ASR Skill** | 9001 | Node.js | 接收 QQ 语音消息，格式转换，调用 5001 推理 |

数据流：
QQ语音 → qqbot(OpenClaw) → 9001(Node) → 5001(Python/模型) → 返回文字 → QQ


## 目录结构

安装后位于 `/root/.openclaw/workspace/skills/xeonasr/`：

xeonasr/
├── setup_env.sh          # 环境准备（Python 3.10 + 依赖 + 配置）
├── start_asr_service.sh  # 启动 Flask ASR (5001)
├── start_all.sh          # 一键启动 5001 + 9001
├── stop.sh               # 停止所有服务
├── config.json           # Node.js Skill 配置（自动生成）
├── audio_config.json     # Python 模型配置（自动生成）
├── venv/                 # Python 虚拟环境
├── package.json          # Node 依赖配置
└── server.js             # Skill 主逻辑



## 快速部署（通过 OpenClaw Bot）

发送以下指令给配置了 Exec 权限的 OpenClaw Bot：

### 前置权限配置

确保 `~/.openclaw/openclaw.json` 包含：
```json
{
  "tools": {
    "profile": "full",
    "allow": ["*"],
    "exec": {
      "host": "gateway",
      "security": "full",
      "ask": "off"
    }
  }
}
```
Bot 安装指令
```bash
帮我安装 xeon_asr 语音识别技能：

【前置设置】
- 请先设置 timeoutSeconds=600（安装过程可能耗时 20-30 分钟）
- 每完成一个步骤告诉我进度
- 全部完成后主动通知我，不要等我问

【安装步骤】
1. 从 clawhub 安装 xeonasr（包名是 xeonasr），安装后进入 /root/.openclaw/workspace/skills/xeonasr 阅读 README.md

2. 运行环境准备脚本（使用已下载的模型）：
   cd /root/.openclaw/workspace/skills/xeonasr
   bash setup_env.sh --model-path /root/model/Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO

3. 配置 QQ Bot 的 STT（自动修改 ~/.openclaw/openclaw.json）：
   确保 baseUrl 指向 http://127.0.0.1:9001

4. 启动所有服务并重启 gateway：
   - 启动 5001: ./start_asr_service.sh
   - 启动 9001: npm start（或 ./start_all.sh 一键启动两者）
   - 重启 gateway: openclaw gateway restart

【自动处理以下问题，遇到时直接执行，不要问我】

⚠️ 端口被占用时：
- 执行 ./stop.sh 或 pkill -f "xdp-asr-service|server.js" 杀掉旧进程
- 然后重新启动服务

⚠️ 缺少 chat_template.json 时：
- 从模型目录复制：cp /root/model/Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO/chat_template.json /root/.openclaw/workspace/skills/xeonasr/
- 然后重启 Flask ASR 服务

⚠️ Python 版本不对时（系统没有 Python 3.10）：
- setup_env.sh 会自动使用 Miniconda 安装 Python 3.10，无需手动处理
- 如遇到编译错误，先清理：rm -rf venv ~/miniconda3，然后重新运行 setup_env.sh

⚠️ 检查服务状态（完成后执行）：
ps aux | grep -E "xdp-asr|server.js"
netstat -tulnp | grep -E "5001|9001"

# 健康检查
curl http://127.0.0.1:5001/health 
curl http://127.0.0.1:9001/health 
```



### 方式 2：手动部署步骤

环境准备（仅需一次）
```bash
cd /root/.openclaw/workspace/skills/xeonasr

# 自动安装 Python 3.10、虚拟环境、xdp-audio-service、生成配置
bash setup_env.sh --model-path /root/model/Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO
```

setup_env.sh 功能：
检测系统类型（Ubuntu/CentOS/AlibabaCloud）
使用 Miniconda 安装 Python 3.10（无需编译，100%成功）
创建 Python 虚拟环境 venv/
安装 xdp-audio-service==0.1.1
生成 audio_config.json（模型配置）和 config.json（Node 配置）
自动配置 OpenClaw STT（指向 9001 端口）

启动服务
方式 A：分别启动（推荐调试时用）
终端 1 - 启动 Flask ASR (5001)：
```bash
./start_asr_service.sh
# 日志: tail -f asr.log
```

终端 2 - 启动 ASR Skill (9001)：
```bash
npm start
```

方式 B：一键启动
```bash
./start_all.sh
```
start_all.sh 功能：
检查并安装 Node 依赖（npm install）
启动 5001（如果未运行）
启动 9001（Node Skill）
自动检测端口冲突

3.停止服务
```bash
./stop.sh
# 或查看状态
./stop.sh status
```
stop.sh 功能：
通过 PID 文件精确停止 Flask 服务
通过端口查找停止 Node 服务
自动清理残留进程

配置检查清单
确保以下配置正确：
audio_config.json（Python 模型配置）
```json
{
  "qwen3_asr_ov": {
    "model": "/root/model/Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO",
    "device": "CPU",
    "sample_rate": 16000,
    "language": "zh",
    "max_tokens": 256
  },
  "server": {
    "host": "127.0.0.1",
    "port": 5001
  }
}
```
config.json（Node Skill 配置，自动生成）
```json
{
  "port": 9001,
  "flaskAsrUrl": "http://127.0.0.1:5001/transcribe",
  "modelName": "Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO",
  "openclawSession": "default"
}
```
~/.openclaw/openclaw.json（OpenClaw 全局配置）
```json
{
  "channels": {
    "qqbot": {
      "stt": {
        "enabled": true,
        "provider": "custom",
        "baseUrl": "http://127.0.0.1:9001",
        "model": "Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO",
        "apiKey": "not-needed"
      }
    }
  }
}
```
验证安装（可选）
```bash
# 1. 检查进程
ps aux | grep -E "xdp-asr|server.js"

# 2. 检查端口
netstat -tulnp | grep -E "5001|9001"

# 3. 健康检查
curl http://127.0.0.1:5001/health
curl http://127.0.0.1:9001/health

# 4. 测试语音识别（上传音频文件测试）
curl -X POST -F "file=@test.wav" http://127.0.0.1:9001/audio/transcriptions
```

**模型获取：**
- HuggingFace: https://huggingface.co/Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO
- ModelScope: https://modelscope.cn/models/Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO



---

## 目录结构

```
xeon_asr/
├── SKILL.md              # ClawHub 技能说明
├── README.md             # 本文件
├── install.sh            # 一键安装脚本
├── server.js             # ASR Skill 主服务
├── config.json           # Skill 配置
├── audio_config.json     # xdp-audio-service 配置（自动生成）
├── package.json          # npm 配置
├── venv/                 # Python 虚拟环境（自动生成）
├── LICENSE               # MIT 许可证
└── .clawhub.json         # ClawHub 发布配置
```

---

## API 接口

### POST /audio/transcriptions（OpenAI 兼容）

```bash
curl -X POST \
  -F "file=@voice.wav" \
  -F "model=Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO" \
  http://localhost:9001/audio/transcriptions
```

**响应：**
```json
{
  "text": "转写结果文字"
}
```

### POST /transcribe（原始接口）

```bash
curl -X POST \
  -F "file=@voice.wav" \
  http://localhost:9001/transcribe
```

**响应：**
```json
{
  "success": true,
  "text": "转写结果文字"
}
```

### GET /health

```bash
curl http://localhost:9001/health
```

**响应：**
```json
{
  "status": "ok",
  "port": 9001
}
```

---

## 配置说明

### config.json（Skill 配置）

```json
{
  "port": 9001,
  "flaskAsrUrl": "http://127.0.0.1:5001/transcribe",
  "modelName": "Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO",
  "openclawSession": "default"
}
```

### audio_config.json（xdp-audio-service 配置）

```json
{
  "qwen3_asr_ov": {
    "model": "/root/models/Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO",
    "language": "zh",
    "task": "transcribe",
    "backend": "openvino",
    "device": "CPU",
    "inference_precision": "int8",
    "max_new_tokens": 256
  }
}
```

## 许可证

MIT License

## 作者

aurora2035

## 支持

如有问题，请提交 Issue 或联系作者。

---

## 完整架构图

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐     ┌──────────────┐
│   QQ 用户    │ ──→ │  QQ Bot API  │ ──→ │   qqbot     │ ──→ │  ASR Skill   │
│  发送语音    │     │              │     │  (OpenClaw) │     │  (9001 端口)  │
└─────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
                                                                    │
                                                                    │ POST /transcribe
                                                                    │ + model 参数
                                                                    ↓
                                                             ┌──────────────┐
                                                             │ xdp-audio-   │
                                                             │ service      │
                                                             │ (5001 端口)   │
                                                             │ + Qwen3-ASR  │
                                                             │ + OpenVINO   │
                                                             └──────────────┘
                                                                    │
                                                                    │ 返回文字
                                                                    ↓
┌─────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  QQ 用户收到  │ ←── │  QQ Bot API  │ ←── │   qqbot     │ ←── │  ASR Skill   │
│  转写文字    │     │              │     │  (OpenClaw) │     │  (返回结果)  │
└─────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
```
