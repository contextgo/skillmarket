#!/usr/bin/env node

const fs = require("fs");
const os = require("os");
const path = require("path");

const DEFAULT_CONFIG_FILE = path.join(os.homedir(), ".codex", "kuaishou-ads-qingsong-skills", "config.json");
const CONFIG_FILE = process.env.ADS_QA_CONFIG_FILE || DEFAULT_CONFIG_FILE;
const CONFIG_DIR = path.dirname(CONFIG_FILE);

function fail(message) {
  console.error(message);
  process.exit(1);
}

const rawAppKey = process.argv[2];
const baseUrl = process.argv[3] || "https://ad.e.kuaishou.com";

if (!rawAppKey || !rawAppKey.trim()) {
  fail("app-key is empty.");
}

const appKey = rawAppKey.trim().replace(/^Bearer\s+/i, "");

fs.mkdirSync(CONFIG_DIR, { recursive: true, mode: 0o700 });
fs.writeFileSync(CONFIG_FILE, JSON.stringify({
  appKey,
  baseUrl: baseUrl.replace(/\/+$/, ""),
  tenantId: "1"
}, null, 2), { mode: 0o600 });

console.log("Qingsong app-key saved.");
