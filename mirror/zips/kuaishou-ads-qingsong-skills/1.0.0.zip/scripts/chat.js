#!/usr/bin/env node

const fs = require("fs");
const os = require("os");
const path = require("path");

const HOME_CONFIG_FILE = path.join(os.homedir(), ".codex", "kuaishou-ads-qingsong-skills", "config.json");
const CONFIG_FILE = process.env.ADS_QA_CONFIG_FILE || HOME_CONFIG_FILE;
const ENDPOINT = "/rest/dsp/jarvis/skill/chat";

function exitWith(code, prefix, message) {
  console.error(`${prefix} ${message}`);
  process.exit(code);
}

function loadConfig() {
  let fileConfig = {};
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      fileConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
    } catch (error) {
      fileConfig = {};
    }
  }
  return {
    appKey: process.env.ADS_QA_APP_KEY || fileConfig.appKey || "",
    baseUrl: (process.env.ADS_QA_BASE_URL || fileConfig.baseUrl || "https://ad.e.kuaishou.com").replace(/\/+$/, ""),
    tenantId: process.env.ADS_QA_TENANT_ID || fileConfig.tenantId || "1"
  };
}

function parseInput() {
  if (!process.argv[2]) {
    exitWith(4, "[API_ERROR]", "Missing JSON request argument.");
  }
  try {
    return JSON.parse(process.argv[2]);
  } catch (error) {
    exitWith(4, "[API_ERROR]", `Invalid JSON request: ${error.message}`);
  }
}

function buildRequest(input, config) {
  return {
    req_type: "KNOWLEDGE_CHAT",
    skill_name: input.skill_name || input.skillName || "qingsong_ads_qa",
    tenant_id: Number(input.tenant_id || input.tenantId || config.tenantId || 1),
    query: input.query || "",
    enable_think: Boolean(input.enable_think ?? input.enableThink),
    from_pc_or_mini_program: Number(input.from_pc_or_mini_program || input.fromPcOrMiniProgram || 2)
  };
}

function returnedText(data) {
  return data.final_answer || data.finalAnswer || data.message || "";
}

function isUnsupportedIntent(data) {
  const text = returnedText(data);
  return data.supported === false ||
    data.is_supported === false ||
    data.intent_supported === false ||
    /不支持|暂不支持|unsupported/i.test(String(text));
}

function writeResult(data) {
  const text = returnedText(data);
  if (isUnsupportedIntent(data)) {
    const reminder = "当前还在开发中，很快会支持其他意图。";
    process.stdout.write(text && text.trim() ? `${text}\n\n${reminder}` : reminder);
    return;
  }
  if (text) {
    process.stdout.write(text);
    return;
  }
  process.stdout.write(JSON.stringify(data, null, 2));
}

function apiErrorMessage(payload) {
  return payload.errorMessage || payload.message || payload.msg || JSON.stringify(payload);
}

function isGatewayError(payload) {
  if (payload.result !== undefined) {
    return payload.result !== 1;
  }
  return payload.code !== undefined && payload.code !== 0;
}

async function main() {
  const config = loadConfig();
  if (!fs.existsSync(CONFIG_FILE) && !process.env.ADS_QA_APP_KEY) {
    exitWith(2, "[TOKEN_NOT_FOUND]", "Qingsong app-key config not found. Run scripts/setup_token.js.");
  }
  const appKey = config.appKey.trim().replace(/^Bearer\s+/i, "");
  if (!appKey) {
    exitWith(3, "[TOKEN_EMPTY]", "Qingsong app-key is empty. Run scripts/setup_token.js.");
  }

  const input = parseInput();
  if (!input.query || !input.query.trim()) {
    exitWith(4, "[API_ERROR]", "query is required.");
  }

  const body = buildRequest(input, config);
  const headers = {
    "accept": "application/json, text/plain, */*",
    "content-type": "application/json",
    "Authorization": `Bearer ${appKey}`
  };
  let response;
  try {
    response = await fetch(`${config.baseUrl}${ENDPOINT}`, {
      method: "POST",
      headers,
      body: JSON.stringify(body)
    });
  } catch (error) {
    exitWith(5, "[NETWORK_ERROR]", error.message);
  }

  let text = await response.text();
  let payload = null;
  try {
    payload = text ? JSON.parse(text) : null;
  } catch (error) {
    payload = null;
  }

  if (!response.ok) {
    exitWith(4, "[API_ERROR]", `HTTP ${response.status}: ${text}`);
  }
  if (!payload) {
    exitWith(4, "[API_ERROR]", `Invalid JSON response: ${text}`);
  }
  if (isGatewayError(payload)) {
    exitWith(4, "[API_ERROR]", apiErrorMessage(payload));
  }

  const data = payload.data || payload;
  writeResult(data);
}

main();
