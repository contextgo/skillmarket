# Kuaishou Ads Qingsong Skill API Reference

## Endpoint

Default:

`POST https://ad.e.kuaishou.com/rest/dsp/jarvis/skill/chat`

## Required Headers

- `content-type`: `application/json`
- `Authorization`: `Bearer <APP_KEY>`

## HTTP Body Sent By scripts/chat.js

```json
{
  "req_type": "KNOWLEDGE_CHAT",
  "skill_name": "qingsong_ads_qa",
  "tenant_id": 1,
  "query": "什么是 MCB",
  "enable_think": false,
  "from_pc_or_mini_program": 2
}
```

`scripts/chat.js` always sends `req_type` as `KNOWLEDGE_CHAT`, defaults `skill_name` to `qingsong_ads_qa`, and defaults `tenant_id` to numeric `1`.

## Expected Response

```json
{
  "result": 1,
  "data": {
    "status": "AD_JARVIS_SKILL_STATUS_SUCCESS",
    "statusCode": 1,
    "message": "",
    "requestId": "qingsong-1770000000000",
    "skillName": "qingsong_ads_qa",
    "recognizedIntent": "知识问答",
    "supported": true,
    "final_answer": "Markdown answer",
    "chatMessage": {}
  }
}
```

`scripts/chat.js` prints Qingsong's returned `data.final_answer`, `data.finalAnswer`, or `data.message` exactly when present. It does not synthesize answers. If the response says the request is unsupported, it appends the fixed reminder: `当前还在开发中，很快会支持其他意图。`

If the gateway returns an error envelope such as `{"code":401000,"message":"apiKey failed to authenticate"}`,
`scripts/chat.js` exits with code `4` and prints the message with `[API_ERROR]`.

## Config File

`scripts/setup_token.js` writes:

`~/.codex/kuaishou-ads-qingsong-skills/config.json`

Fields:

- `appKey`
- `baseUrl`
- `tenantId`

Environment variables override the config file.
