---
name: kuaishou-ads-qingsong-skills
description: Kuaishou Ads Qingsong skill for advertising knowledge Q&A. Use for general advertising knowledge, policy, workflow, material specification, and platform operation questions answered by the Qingsong ads QA backend.
---

# Kuaishou Ads Qingsong Skills

## Overview

Use this skill to answer ads-related questions by calling the Jarvis Skill HTTP API exposed by Ad Star Gateway:

`POST https://ad.e.kuaishou.com/rest/dsp/jarvis/skill/chat`

The default backend skill is `qingsong_ads_qa`. This skill only supports advertising knowledge Q&A.

## Runtime

Scripts require Node.js 18 or later. Do not proactively check Node or credential state; run the scripts first and react to exit codes.

## Credential Setup

The scripts need an app-key for the `Authorization: Bearer` header. If `scripts/chat.js` exits with code `2` or `3`, ask the user to provide the app-key, then save it with:

```bash
node scripts/setup_token.js "<APP_KEY>"
```

Optional base URL override:

```bash
node scripts/setup_token.js "<APP_KEY>" "https://ad.e.kuaishou.com"
```

The app-key can be provided with or without the `Bearer ` prefix. Never print a full app-key back to the user.

Environment variables override saved config:

- `ADS_QA_APP_KEY`
- `ADS_QA_BASE_URL`
- `ADS_QA_TENANT_ID`

## Workflow

1. Treat the user's latest message as a knowledge Q&A query.
2. Build a JSON request and execute:

```bash
node scripts/chat.js '<JSON_REQUEST>'
```

Wrap the JSON in single quotes.
The JSON request should normally contain only `query`.

## Request Format

The gateway request uses snake_case fields. `scripts/chat.js` sends `req_type`, `skill_name`, `tenant_id`, `query`, `enable_think`, and `from_pc_or_mini_program`. `req_type` is always `KNOWLEDGE_CHAT`.

Important field/header mapping:

- `tenant_id` is always numeric and defaults to `1`.

Canonical curl shape:

```bash
curl -X POST "https://ad.e.kuaishou.com/rest/dsp/jarvis/skill/chat" \
  -H "Authorization: Bearer <APP_KEY>" \
  -H "Content-Type: application/json" \
  --data-raw '{
    "req_type": "KNOWLEDGE_CHAT",
    "skill_name": "qingsong_ads_qa",
    "tenant_id": 1,
    "query": "广告预览功能怎么用",
    "enable_think": false,
    "from_pc_or_mini_program": 2
  }'
```

## Request Examples

```json
{"query":"什么是 MCB？"}
```

```json
{"query":"广告预览功能怎么用"}
```

## Exit Codes

| Code | Prefix | Meaning | Action |
| --- | --- | --- | --- |
| 0 | none | Success | Output the script stdout. |
| 2 | `[TOKEN_NOT_FOUND]` | app-key/config not found | Ask the user for app-key, then run `setup_token.js`. |
| 3 | `[TOKEN_EMPTY]` | app-key empty | Ask the user for app-key, then run `setup_token.js`. |
| 4 | `[API_ERROR]` | Backend returned non-success or HTTP error | Show the error. If auth-related, ask user to refresh app-key. |
| 5 | `[NETWORK_ERROR]` | Network/request failure | Show the error and suggest checking base URL or network. |

## Result Display

For a successful call, output `scripts/chat.js` stdout exactly as-is. Do not rewrite, summarize, expand, supplement, infer, or invent content that is not returned by Qingsong.

If Qingsong returns content indicating the request is unsupported, output the returned message if present, then remind the user: `当前还在开发中，很快会支持其他意图。`

For detailed API fields and config behavior, read `references/ads_qa_openapi_spec.md` only when debugging or manually inspecting integration details.
