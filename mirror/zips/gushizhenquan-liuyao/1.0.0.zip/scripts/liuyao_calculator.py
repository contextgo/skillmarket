#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
六爻装卦计算器
基于《古筮真诠》理论体系
根据起卦时间和铜钱结果自动装卦
"""

import sys
import json
from datetime import datetime

# 六十四卦信息 (卦名, 宫位, 世爻位置, 应爻位置)
# 世应位置：从初爻开始为1，上爻为6
BAGUA_INFO = {
    # 乾宫八卦
    "乾为天": {"gong": "乾", "shi": 6, "ying": 3},
    "天风姤": {"gong": "乾", "shi": 1, "ying": 4},
    "天山遁": {"gong": "乾", "shi": 2, "ying": 5},
    "天地否": {"gong": "乾", "shi": 3, "ying": 6},
    "风地观": {"gong": "乾", "shi": 4, "ying": 1},
    "山地剥": {"gong": "乾", "shi": 5, "ying": 2},
    "火地晋": {"gong": "乾", "shi": 4, "ying": 1},  # 游魂
    "火天大有": {"gong": "乾", "shi": 3, "ying": 6},  # 归魂

    # 坎宫八卦
    "坎为水": {"gong": "坎", "shi": 6, "ying": 3},
    "水泽节": {"gong": "坎", "shi": 1, "ying": 4},
    "水雷屯": {"gong": "坎", "shi": 2, "ying": 5},
    "水火既济": {"gong": "坎", "shi": 3, "ying": 6},
    "泽火革": {"gong": "坎", "shi": 4, "ying": 1},
    "雷火丰": {"gong": "坎", "shi": 5, "ying": 2},
    "地火明夷": {"gong": "坎", "shi": 4, "ying": 1},  # 游魂
    "地水师": {"gong": "坎", "shi": 3, "ying": 6},  # 归魂

    # 艮宫八卦
    "艮为山": {"gong": "艮", "shi": 6, "ying": 3},
    "山火贲": {"gong": "艮", "shi": 1, "ying": 4},
    "山天大畜": {"gong": "艮", "shi": 2, "ying": 5},
    "山泽损": {"gong": "艮", "shi": 3, "ying": 6},
    "火泽睽": {"gong": "艮", "shi": 4, "ying": 1},
    "天泽履": {"gong": "艮", "shi": 5, "ying": 2},
    "风泽中孚": {"gong": "艮", "shi": 4, "ying": 1},  # 游魂
    "风山渐": {"gong": "艮", "shi": 3, "ying": 6},  # 归魂

    # 震宫八卦
    "震为雷": {"gong": "震", "shi": 6, "ying": 3},
    "雷地豫": {"gong": "震", "shi": 1, "ying": 4},
    "雷水解": {"gong": "震", "shi": 2, "ying": 5},
    "雷风恒": {"gong": "震", "shi": 3, "ying": 6},
    "地风升": {"gong": "震", "shi": 4, "ying": 1},
    "水风井": {"gong": "震", "shi": 5, "ying": 2},
    "泽风大过": {"gong": "震", "shi": 4, "ying": 1},  # 游魂
    "泽雷随": {"gong": "震", "shi": 3, "ying": 6},  # 归魂

    # 巽宫八卦
    "巽为风": {"gong": "巽", "shi": 6, "ying": 3},
    "风天小畜": {"gong": "巽", "shi": 1, "ying": 4},
    "风火家人": {"gong": "巽", "shi": 2, "ying": 5},
    "风雷益": {"gong": "巽", "shi": 3, "ying": 6},
    "天雷无妄": {"gong": "巽", "shi": 4, "ying": 1},
    "火雷噬嗑": {"gong": "巽", "shi": 5, "ying": 2},
    "山雷颐": {"gong": "巽", "shi": 4, "ying": 1},  # 游魂
    "山风蛊": {"gong": "巽", "shi": 3, "ying": 6},  # 归魂

    # 离宫八卦
    "离为火": {"gong": "离", "shi": 6, "ying": 3},
    "火山旅": {"gong": "离", "shi": 1, "ying": 4},
    "火风鼎": {"gong": "离", "shi": 2, "ying": 5},
    "火水未济": {"gong": "离", "shi": 3, "ying": 6},
    "山水蒙": {"gong": "离", "shi": 4, "ying": 1},
    "风水涣": {"gong": "离", "shi": 5, "ying": 2},
    "天水讼": {"gong": "离", "shi": 4, "ying": 1},  # 游魂
    "天火同人": {"gong": "离", "shi": 3, "ying": 6},  # 归魂

    # 坤宫八卦
    "坤为地": {"gong": "坤", "shi": 6, "ying": 3},
    "地雷复": {"gong": "坤", "shi": 1, "ying": 4},
    "地泽临": {"gong": "坤", "shi": 2, "ying": 5},
    "地天泰": {"gong": "坤", "shi": 3, "ying": 6},
    "雷天大壮": {"gong": "坤", "shi": 4, "ying": 1},
    "泽天夬": {"gong": "坤", "shi": 5, "ying": 2},
    "水天需": {"gong": "坤", "shi": 4, "ying": 1},  # 游魂
    "水地比": {"gong": "坤", "shi": 3, "ying": 6},  # 归魂

    # 兑宫八卦
    "兑为泽": {"gong": "兑", "shi": 6, "ying": 3},
    "泽水困": {"gong": "兑", "shi": 1, "ying": 4},
    "泽地萃": {"gong": "兑", "shi": 2, "ying": 5},
    "泽山咸": {"gong": "兑", "shi": 3, "ying": 6},
    "水山蹇": {"gong": "兑", "shi": 4, "ying": 1},
    "地山谦": {"gong": "兑", "shi": 5, "ying": 2},
    "雷山小过": {"gong": "兑", "shi": 4, "ying": 1},  # 游魂
    "雷泽归妹": {"gong": "兑", "shi": 3, "ying": 6},  # 归魂
}

# 纳甲地支 (八宫纳甲法)
# 乾纳甲壬，坤纳乙癸，震纳庚，巽纳辛，坎纳戊，离纳己，艮纳丙，兑纳丁
# 简化为：根据卦宫和爻位确定地支

# 六亲关系 (以卦宫五行为主)
# 生我者父母，我生者子孙，克我者官鬼，我克者妻财，同我者兄弟

# 六神 (青龙、朱雀、勾陈、螣蛇、白虎、玄武)
# 根据起卦日的天干确定六神起始位置


def get_bagua_from_yao(yao_results):
    """
    根据六次铜钱结果得到本卦和变卦
    铜钱结果：字面=阳(0)，面=阴(1) 或 字=阴(0)，面=阳(1)
    传统：两个字一个面=少阳(7)，三个字=老阴(8)变，一个字两个面=少阴(9)，三个面=老阳(6)变
    
    参数:
        yao_results: 列表，6个元素，从初爻到上爻
                    每个元素可以是 "字字字", "字面字" 等，或 "0" "1" 表示阴阳
    
    返回:
        (本卦, 变卦, 动爻列表)
    """
    # 简化版：这里假设输入已经是阴阳表示
    # 实际应该使用三枚铜钱的抛掷结果
    
    # 暂时返回示例
    return "水雷屯", "水雷屯", []


def load_bagua_info(gua_name):
    """加载卦象信息"""
    if gua_name in BAGUA_INFO:
        return BAGUA_INFO[gua_name]
    return None


def get_dizhi(yao_index, gua_gong, is_bian=False):
    """
    获取爻的地支
    根据八宫纳甲法和爻的位置确定
    
    参数:
        yao_index: 爻位 (0=初爻, 5=上爻)
        gua_gong: 卦宫 (乾、坤、震、巽、坎、离、艮、兑)
        is_bian: 是否为变卦
    """
    # 八宫纳甲地支表 (简化版)
    dizhi_map = {
        "乾": ["子水", "寅木", "辰土", "午火", "申金", "戌土"],  # 初至上
        "坤": ["未土", "巳火", "卯木", "丑土", "亥水", "酉金"],
        "震": ["子水", "寅木", "辰土", "午火", "申金", "戌土"],
        "巽": ["丑土", "亥水", "酉金", "未土", "巳火", "卯木"],
        "坎": ["寅木", "辰土", "午火", "申金", "戌土", "子水"],
        "离": ["卯木", "丑土", "亥水", "酉金", "未土", "巳火"],
        "艮": ["辰土", "午火", "申金", "戌土", "子水", "寅木"],
        "兑": ["巳火", "卯木", "丑土", "亥水", "酉金", "未土"],
    }
    
    if gua_gong in dizhi_map:
        return dizhi_map[gua_gong][yao_index]
    return "未知"


def get_liuqin(yao_dizhi, gua_gong):
    """
    获取六亲
    根据卦宫五行和爻地支五行的生克关系确定
    
    参数:
        yao_dizhi: 爻的地支 (如 "子水")
        gua_gong: 卦宫
    """
    # 五行属性
    wuxing = {
        "水": ["子", "亥"],
        "木": ["寅", "卯"],
        "火": ["巳", "午"],
        "土": ["辰", "戌", "丑", "未"],
        "金": ["申", "酉"],
    }
    
    # 卦宫五行
    gong_wuxing = {
        "乾": "金",
        "坤": "土",
        "震": "木",
        "巽": "木",
        "坎": "水",
        "离": "火",
        "艮": "土",
        "兑": "金",
    }
    
    # 生克关系：我、父母(生我)、子孙(我生)、官鬼(克我)、妻财(我克)、兄弟(同我)
    # 六亲：父母、兄弟、子孙、妻财、官鬼
    
    gong = gong_wuxing.get(gua_gong, "金")
    
    # 获取爻地支的五行
    dizhi = yao_dizhi[0]  # 取地支第一个字
    yao_wuxing = None
    for wx, dz_list in wuxing.items():
        if dizhi in dz_list:
            yao_wuxing = wx
            break
    
    if not yao_wuxing:
        return "未知"
    
    # 确定六亲
    # 我 = 卦宫五行
    if yao_wuxing == gong:
        return "兄弟"  # 同我者兄弟
    elif is_sheng(yao_wuxing, gong):
        return "父母"  # 生我者父母
    elif is_sheng(gong, yao_wuxing):
        return "子孙"  # 我生者子孙
    elif is_ke(yao_wuxing, gong):
        return "官鬼"  # 克我者官鬼
    elif is_ke(gong, yao_wuxing):
        return "妻财"  # 我克者妻财
    
    return "未知"


def is_sheng(wuxing_a, wuxing_b):
    """a生b?"""
    sheng = {"木": "火", "火": "土", "土": "金", "金": "水", "水": "木"}
    return sheng.get(wuxing_a) == wuxing_b


def is_ke(wuxing_a, wuxing_b):
    """a克b?"""
    ke = {"木": "土", "土": "水", "水": "火", "火": "金", "金": "木"}
    return ke.get(wuxing_a) == wuxing_b


def get_liushen(day_gan, yao_index):
    """
    获取六神
    根据起卦日的天干确定六神起始
    
    参数:
        day_gan: 日天干 (甲、乙、丙、丁、戊、己、庚、辛、壬、癸)
        yao_index: 爻位 (0=初爻, 5=上爻)
    """
    # 六神顺序：青龙、朱雀、勾陈、螣蛇、白虎、玄武
    liushen = ["青龙", "朱雀", "勾陈", "螣蛇", "白虎", "玄武"]
    
    # 日干起六神：甲乙起青龙，丙丁起朱雀，戊起勾陈，己起螣蛇，庚辛起白虎，壬癸起玄武
    start_map = {
        "甲": 0, "乙": 0,
        "丙": 1, "丁": 1,
        "戊": 2,
        "己": 3,
        "庚": 4, "辛": 4,
        "壬": 5, "癸": 5,
    }
    
    start = start_map.get(day_gan, 0)
    index = (start + yao_index) % 6
    return liushen[index]


def calculate_liuyao(date_str, yao_results):
    """
    主函数：计算六爻装卦
    
    参数:
        date_str: 起卦日期 "YYYY-MM-DD" 或 "YYYY年MM月DD日"
        yao_results: 铜钱结果列表，6个元素，从初爻到上爻
                    每个元素: "字字字"(老阴8), "字面字"(少阳7), "字字面"(少阴9), "面面面"(老阳6)
                    或简化: "000"(老阴), "001"(少阳), "010"(少阴), "111"(老阳)
    
    返回:
        装卦结果字典
    """
    # 解析日期
    try:
        if "-" in date_str:
            date = datetime.strptime(date_str, "%Y-%m-%d")
        elif "年" in date_str:
            # 简单解析，实际可能需要更复杂的农历转换
            date = datetime.now()
        else:
            date = datetime.now()
    except:
        date = datetime.now()
    
    # 获取日天干 (简化，实际需要万年历)
    day_gan = "甲"  # 默认值
    
    # 根据铜钱结果确定本卦和变卦 (这里需要完整的起卦逻辑)
    # 暂时返回示例结构
    
    result = {
        "起卦时间": date_str,
        "本卦": "待计算",
        "变卦": "待计算",
        "世爻": "待定",
        "应爻": "待定",
        "爻详情": []
    }
    
    return result


def print_loading_result(result):
    """打印装卦结果"""
    print("=" * 60)
    print(f"起卦时间: {result['起卦时间']}")
    print(f"本卦: {result['本卦']}")
    print(f"变卦: {result['变卦']}")
    print(f"世爻: {result['世爻']}")
    print(f"应爻: {result['应爻']}")
    print("-" * 60)
    print("爻位 | 六亲 | 六神 | 地支 | 动静 | 变爻")
    print("-" * 60)
    for yao in result['爻详情']:
        print(f"{yao['爻位']} | {yao['六亲']} | {yao['六神']} | {yao['地支']} | {yao['动静']} | {yao['变爻']}")


def main():
    """命令行入口"""
    if len(sys.argv) < 3:
        print("用法: python liuyao_calculator.py --date <日期> --results <铜钱结果>")
        print("示例: python liuyao_calculator.py --date 2026-05-05 --results 000,001,111,001,110,111")
        sys.exit(1)
    
    # 解析参数
    date_str = ""
    yao_results = []
    
    i = 1
    while i < len(sys.argv):
        if sys.argv[i] == "--date":
            date_str = sys.argv[i+1]
            i += 2
        elif sys.argv[i] == "--results":
            results_str = sys.argv[i+1]
            yao_results = results_str.split(",")
            i += 2
        else:
            i += 1
    
    # 计算
    result = calculate_liuyao(date_str, yao_results)
    
    # 输出
    print_loading_result(result)
    
    # 也输出JSON格式
    print("\nJSON格式:")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
