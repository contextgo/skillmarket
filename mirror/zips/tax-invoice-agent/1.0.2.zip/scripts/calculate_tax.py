#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
"""
税务代开发票 - 税款计算与合同信息处理脚本
支持：税款计算、附报资料匹配、发票备注生成
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import Optional, Dict, List
from datetime import datetime


# 业务类型与税率配置
BUSINESS_TYPES = {
    "labor": {"name": "劳务报酬", "vat_rate": 0.03, "income_type": "labor"},
    "service": {"name": "技术/信息服务", "vat_rate": 0.03, "income_type": "labor"},
    "design": {"name": "设计服务", "vat_rate": 0.03, "income_type": "labor"},
    "consulting": {"name": "咨询服务", "vat_rate": 0.03, "income_type": "labor"},
    "goods": {"name": "货物销售", "vat_rate": 0.03, "income_type": "labor"},
    "construction": {"name": "建筑服务", "vat_rate": 0.03, "income_type": "labor"},
    "transport": {"name": "货物运输", "vat_rate": 0.03, "income_type": "labor"},
    "rental_residential": {"name": "住宅租赁", "vat_rate": 0.05, "income_type": "rental"},
    "rental_commercial": {"name": "非住宅租赁", "vat_rate": 0.05, "income_type": "rental"},
    "property_transfer": {"name": "财产转让", "vat_rate": 0.05, "income_type": "transfer"},
}

# 城建税率
LOCATION_RATES = {
    "city": 0.07,      # 市区
    "county": 0.05,    # 县镇
    "rural": 0.01,     # 农村
}

# 附加费率
SURCHARGE_RATES = {
    "education": 0.03,       # 教育费附加
    "local_education": 0.02, # 地方教育附加
}

# 印花税税率
STAMP_DUTY_RATES = {
    "purchase_sale": 0.0003,    # 购销合同
    "construction": 0.0003,     # 建筑合同
    "technology": 0.0003,       # 技术合同
    "transport": 0.0003,        # 运输合同
    "lease": 0.001,             # 租赁合同
    "property_transfer": 0.0005, # 产权转移
}

# 附报资料配置
DOCUMENT_REQUIREMENTS = {
    "技术服务": {
        "required": ["技术服务合同/协议"],
        "optional": ["技术成果验收单", "付款凭证"],
        "note_template": "合同编号：{contract_no}，签订日期：{sign_date}",
        "stamp_duty_type": "technology",
    },
    "劳务报酬": {
        "required": ["劳务合同/用工协议"],
        "optional": ["考勤记录", "工作量确认单"],
        "note_template": "劳务内容：{service_content}，服务期限：{service_period}",
        "stamp_duty_type": None,
    },
    "住宅租赁": {
        "required": ["房屋租赁合同", "房产证复印件"],
        "optional": ["租金收据", "租赁备案证明"],
        "note_template": "不动产地址：{property_address}，租赁期：{lease_start}至{lease_end}",
        "stamp_duty_type": "lease",
    },
    "非住宅租赁": {
        "required": ["房屋租赁合同", "房产证复印件"],
        "optional": ["租金收据", "租赁备案证明"],
        "note_template": "不动产地址：{property_address}，租赁期：{lease_start}至{lease_end}",
        "stamp_duty_type": "lease",
    },
    "货物运输": {
        "required": ["运输合同/托运单"],
        "optional": ["货物清单", "签收单"],
        "note_template": "起运地：{origin}，到达地：{destination}，运输工具：{vehicle}",
        "stamp_duty_type": "transport",
    },
    "建筑服务": {
        "required": ["建筑安装合同"],
        "optional": ["工程结算单", "施工许可证"],
        "note_template": "建筑服务发生地：{project_location}，项目名称：{project_name}",
        "stamp_duty_type": "construction",
    },
    "货物销售": {
        "required": ["购销合同/订单"],
        "optional": ["发货单", "收货确认单"],
        "note_template": "货物名称：{goods_name}，规格型号：{goods_spec}",
        "stamp_duty_type": "purchase_sale",
    },
    "设计服务": {
        "required": ["设计委托合同"],
        "optional": ["设计成果确认书"],
        "note_template": "设计项目名称：{project_name}，合同编号：{contract_no}",
        "stamp_duty_type": "technology",
    },
    "咨询服务": {
        "required": ["咨询服务协议"],
        "optional": ["咨询报告", "会议纪要"],
        "note_template": "咨询服务内容：{service_content}，服务期限：{service_period}",
        "stamp_duty_type": "technology",
    },
}


@dataclass
class ContractInfo:
    """合同信息"""
    contract_no: str = ""
    contract_name: str = ""
    sign_date: str = ""
    party_a: str = ""  # 甲方/购买方
    party_b: str = ""  # 乙方/销售方
    contract_amount: float = 0.0
    payment_method: str = ""  # 一次性/分期
    service_start: str = ""
    service_end: str = ""
    project_location: str = ""
    project_name: str = ""
    property_address: str = ""
    service_content: str = ""
    goods_name: str = ""
    goods_spec: str = ""
    origin: str = ""
    destination: str = ""
    vehicle: str = ""


@dataclass
class TaxResult:
    """税款计算结果"""
    business_type: str
    amount_with_tax: float
    amount_without_tax: float
    vat: float
    vat_exempt: bool
    urban_tax: float
    education_surcharge: float
    local_education_surcharge: float
    total_surcharge: float
    personal_income_tax: float
    stamp_duty: float
    total_tax: float
    net_amount: float
    location: str
    is_micro: bool
    invoice_note: str = ""
    required_documents: List[str] = None
    optional_documents: List[str] = None


def get_document_requirements(invoice_type: str) -> Dict:
    """获取附报资料要求"""
    return DOCUMENT_REQUIREMENTS.get(invoice_type, {
        "required": ["合同/协议"],
        "optional": ["付款凭证"],
        "note_template": "合同编号：{contract_no}",
        "stamp_duty_type": None,
    })


def generate_invoice_note(invoice_type: str, contract: ContractInfo) -> str:
    """生成发票备注"""
    req = get_document_requirements(invoice_type)
    template = req.get("note_template", "合同编号：{contract_no}")
    
    # 构建格式化参数
    params = {
        "contract_no": contract.contract_no or "未填写",
        "sign_date": contract.sign_date or "未填写",
        "service_content": contract.service_content or "详见合同",
        "service_period": f"{contract.service_start}至{contract.service_end}" if contract.service_start else "未填写",
        "property_address": contract.property_address or "未填写",
        "lease_start": contract.service_start or "未填写",
        "lease_end": contract.service_end or "未填写",
        "origin": contract.origin or "未填写",
        "destination": contract.destination or "未填写",
        "vehicle": contract.vehicle or "未填写",
        "project_location": contract.project_location or "未填写",
        "project_name": contract.project_name or "未填写",
        "goods_name": contract.goods_name or "未填写",
        "goods_spec": contract.goods_spec or "未填写",
    }
    
    try:
        return template.format(**params)
    except KeyError:
        return f"合同编号：{contract.contract_no or '未填写'}"


def calculate_labor_income_tax(income: float) -> float:
    """计算劳务报酬个人所得税（预扣预缴）"""
    if income <= 0:
        return 0
    
    # 减除费用
    if income <= 4000:
        taxable_income = income - 800
    else:
        taxable_income = income * 0.8
    
    if taxable_income <= 0:
        return 0
    
    # 适用税率
    if taxable_income <= 20000:
        tax = taxable_income * 0.2
    elif taxable_income <= 50000:
        tax = taxable_income * 0.3 - 2000
    else:
        tax = taxable_income * 0.4 - 7000
    
    return max(0, tax)


def calculate_rental_income_tax(income: float, is_residential: bool = True) -> float:
    """计算财产租赁个人所得税"""
    if income <= 0:
        return 0
    
    # 减除费用
    if income <= 4000:
        taxable_income = income - 800
    else:
        taxable_income = income * 0.8
    
    if taxable_income <= 0:
        return 0
    
    # 税率
    rate = 0.1 if is_residential else 0.2
    return taxable_income * rate


def calculate_stamp_duty(contract_amount: float, duty_type: Optional[str], is_micro: bool = True) -> float:
    """计算印花税"""
    if not duty_type or contract_amount <= 0:
        return 0
    
    rate = STAMP_DUTY_RATES.get(duty_type, 0)
    tax = contract_amount * rate
    
    # 小微企业免征（2024政策）
    if is_micro:
        return 0
    
    return tax


def calculate(
    amount: float,
    business_type: str = "service",
    location: str = "city",
    is_micro: bool = True,
    is_tax_inclusive: bool = True,
    invoice_type: str = "技术服务",
    contract: Optional[ContractInfo] = None,
) -> TaxResult:
    """
    计算代开发票税款
    
    Args:
        amount: 开票金额
        business_type: 业务类型代码
        location: 地区类型 (city/county/rural)
        is_micro: 是否小微企业/个人（享受免税）
        is_tax_inclusive: 金额是否含税
        invoice_type: 开票项目类型（用于附报资料匹配）
        contract: 合同信息（用于生成发票备注）
    """
    
    # 获取业务配置
    biz_config = BUSINESS_TYPES.get(business_type, BUSINESS_TYPES["service"])
    vat_rate = biz_config["vat_rate"]
    income_type = biz_config["income_type"]
    
    # 计算不含税金额和增值税
    if is_tax_inclusive:
        amount_without_tax = amount / (1 + vat_rate)
        vat = amount - amount_without_tax
    else:
        amount_without_tax = amount
        vat = amount_without_tax * vat_rate
        amount = amount_without_tax + vat
    
    # 小微企业免税判断（月销售额≤10万）
    vat_exempt = is_micro and amount_without_tax <= 100000
    
    if vat_exempt:
        vat = 0
        amount_without_tax = amount  # 免税时含税=不含税
    
    # 计算附加税费
    urban_rate = LOCATION_RATES.get(location, 0.07)
    education_rate = SURCHARGE_RATES["education"]
    local_education_rate = SURCHARGE_RATES["local_education"]
    
    # 小微企业附加税减半
    surcharge_discount = 0.5 if is_micro else 1.0
    
    if vat_exempt:
        urban_tax = 0
        education_surcharge = 0
        local_education_surcharge = 0
    else:
        urban_tax = vat * urban_rate * surcharge_discount
        education_surcharge = vat * education_rate * surcharge_discount
        local_education_surcharge = vat * local_education_rate * surcharge_discount
    
    total_surcharge = urban_tax + education_surcharge + local_education_surcharge
    
    # 计算个人所得税
    if income_type == "labor":
        personal_income_tax = calculate_labor_income_tax(amount_without_tax)
    elif income_type == "rental":
        is_residential = business_type == "rental_residential"
        personal_income_tax = calculate_rental_income_tax(amount_without_tax, is_residential)
    elif income_type == "transfer":
        # 财产转让所得，需要原值信息，这里简化处理
        personal_income_tax = amount_without_tax * 0.2  # 简化计算
    else:
        personal_income_tax = 0
    
    # 计算印花税
    doc_req = get_document_requirements(invoice_type)
    stamp_duty_type = doc_req.get("stamp_duty_type")
    contract_amount = contract.contract_amount if contract else amount
    stamp_duty = calculate_stamp_duty(contract_amount, stamp_duty_type, is_micro)
    
    # 合计
    total_tax = vat + total_surcharge + personal_income_tax + stamp_duty
    net_amount = amount - total_tax
    
    # 生成发票备注
    if contract:
        invoice_note = generate_invoice_note(invoice_type, contract)
    else:
        invoice_note = f"合同编号：未提供"
    
    # 获取附报资料清单
    required_docs = doc_req.get("required", [])
    optional_docs = doc_req.get("optional", [])
    
    return TaxResult(
        business_type=biz_config["name"],
        amount_with_tax=round(amount, 2),
        amount_without_tax=round(amount_without_tax, 2),
        vat=round(vat, 2),
        vat_exempt=vat_exempt,
        urban_tax=round(urban_tax, 2),
        education_surcharge=round(education_surcharge, 2),
        local_education_surcharge=round(local_education_surcharge, 2),
        total_surcharge=round(total_surcharge, 2),
        personal_income_tax=round(personal_income_tax, 2),
        stamp_duty=round(stamp_duty, 2),
        total_tax=round(total_tax, 2),
        net_amount=round(net_amount, 2),
        location=location,
        is_micro=is_micro,
        invoice_note=invoice_note,
        required_documents=required_docs,
        optional_documents=optional_docs,
    )


def format_output(result: TaxResult) -> str:
    """格式化输出结果"""
    lines = [
        "",
        "=" * 60,
        "  税务代开发票 — 税款计算与资料清单",
        "=" * 60,
        f"  业务类型      : {result.business_type}",
        f"  含税开票金额  : ¥ {result.amount_with_tax:>12,.2f}",
        f"  不含税金额    : ¥ {result.amount_without_tax:>12,.2f}",
        "-" * 60,
    ]
    
    if result.vat_exempt:
        lines.append(f"  增值税        :           免征  (月销售额 ≤ 10万元)")
    else:
        lines.append(f"  增值税        : ¥ {result.vat:>12,.2f}")
    
    lines.extend([
        f"  附加税费合计  : ¥ {result.total_surcharge:>12,.2f}",
        f"    城建税      : ¥ {result.urban_tax:>12,.2f}",
        f"    教育费附加  : ¥ {result.education_surcharge:>12,.2f}",
        f"    地方教育附加: ¥ {result.local_education_surcharge:>12,.2f}",
        f"  个人所得税    : ¥ {result.personal_income_tax:>12,.2f}",
        f"  印花税        : ¥ {result.stamp_duty:>12,.2f}",
        "-" * 60,
        f"  合计应缴税款  : ¥ {result.total_tax:>12,.2f}",
        f"  实际到手金额  : ¥ {result.net_amount:>12,.2f}",
        "",
        "  【附报资料清单】",
        "  必需资料：",
    ])
    
    for doc in result.required_documents:
        lines.append(f"    ✓ {doc}")
    
    lines.append("  可选资料：")
    for doc in result.optional_documents:
        lines.append(f"    ○ {doc}")
    
    lines.extend([
        "",
        f"  【发票备注】",
        f"  {result.invoice_note}",
        "",
    ])
    
    if result.vat_exempt:
        lines.append("  [小微优惠] 增值税及附加税免征，已适用")
    
    lines.append("=" * 60)
    lines.append("")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="税务代开发票税款计算")
    parser.add_argument("--amount", type=float, required=True, help="开票金额")
    parser.add_argument("--type", dest="business_type", default="service",
                       choices=list(BUSINESS_TYPES.keys()),
                       help="业务类型")
    parser.add_argument("--location", default="city",
                       choices=["city", "county", "rural"],
                       help="地区类型")
    parser.add_argument("--micro", default="yes",
                       choices=["yes", "no"],
                       help="是否小微企业/个人")
    parser.add_argument("--tax-inclusive", dest="tax_inclusive", default="yes",
                       choices=["yes", "no"],
                       help="金额是否含税")
    parser.add_argument("--invoice-type", default="技术服务",
                       help="开票项目类型")
    parser.add_argument("--contract-no", default="",
                       help="合同编号")
    parser.add_argument("--sign-date", default="",
                       help="合同签订日期")
    parser.add_argument("--project-name", default="",
                       help="项目名称")
    parser.add_argument("--project-location", default="",
                       help="项目地点")
    parser.add_argument("--output-json", action="store_true",
                       help="输出JSON格式")
    
    args = parser.parse_args()
    
    # 构建合同信息
    contract = ContractInfo(
        contract_no=args.contract_no,
        sign_date=args.sign_date,
        project_name=args.project_name,
        project_location=args.project_location,
    )
    
    # 计算税款
    result = calculate(
        amount=args.amount,
        business_type=args.business_type,
        location=args.location,
        is_micro=(args.micro == "yes"),
        is_tax_inclusive=(args.tax_inclusive == "yes"),
        invoice_type=args.invoice_type,
        contract=contract,
    )
    
    # 输出结果
    if args.output_json:
        output = {
            "business_type": result.business_type,
            "amount_with_tax": result.amount_with_tax,
            "amount_without_tax": result.amount_without_tax,
            "vat": result.vat,
            "vat_exempt": result.vat_exempt,
            "urban_tax": result.urban_tax,
            "education_surcharge": result.education_surcharge,
            "local_education_surcharge": result.local_education_surcharge,
            "total_surcharge": result.total_surcharge,
            "personal_income_tax": result.personal_income_tax,
            "stamp_duty": result.stamp_duty,
            "total_tax": result.total_tax,
            "net_amount": result.net_amount,
            "invoice_note": result.invoice_note,
            "required_documents": result.required_documents,
            "optional_documents": result.optional_documents,
        }
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(format_output(result))


if __name__ == "__main__":
    main()
