#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Tax Invoice Agent - Self Learning Module
Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
Author: QQ 1817694478 | Q-Group: 972156177
"""
import json
import os
from datetime import datetime
from pathlib import Path

DATA_FILE = Path(__file__).parent.parent / "assets" / "learn_data.json"

def init_data():
    """Initialize learning data file"""
    if not DATA_FILE.exists():
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "version": "1.0.0",
            "last_updated": datetime.now().isoformat(),
            "interaction_count": 0,
            "success_records": [],
            "failure_records": [],
        }
        save_data(data)

def load_data():
    """Load learning data"""
    init_data()
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_data(data):
    """Save learning data"""
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def record_success(context=""):
    """Record successful execution"""
    data = load_data()
    data["interaction_count"] += 1
    data["success_records"].append({
        "timestamp": datetime.now().isoformat(),
        "context": context,
    })
    # Keep only last 30 records
    data["success_records"] = data["success_records"][-30:]
    data["last_updated"] = datetime.now().isoformat()
    save_data(data)
    print(f"[OK] Success recorded. Total: {data['interaction_count']}")

def record_failure(reason="", context=""):
    """Record failed execution"""
    data = load_data()
    data["failure_records"].append({
        "timestamp": datetime.now().isoformat(),
        "reason": reason,
        "context": context,
    })
    # Keep only last 30 records
    data["failure_records"] = data["failure_records"][-30:]
    data["last_updated"] = datetime.now().isoformat()
    save_data(data)
    print(f"[WARN] Failure recorded: {reason}")

def show_stats():
    """Show learning statistics"""
    data = load_data()
    print(f"Version: {data['version']}")
    print(f"Last Updated: {data['last_updated']}")
    print(f"Total Interactions: {data['interaction_count']}")
    print(f"Success Records: {len(data['success_records'])}")
    print(f"Failure Records: {len(data['failure_records'])}")

def reset_data():
    """Reset all learning data"""
    if DATA_FILE.exists():
        DATA_FILE.unlink()
    init_data()
    print("[OK] Learning data reset")

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "--stats":
            show_stats()
        elif cmd == "--success":
            context = sys.argv[2] if len(sys.argv) > 2 else ""
            record_success(context)
        elif cmd == "--failure":
            reason = sys.argv[2] if len(sys.argv) > 2 else ""
            context = sys.argv[3] if len(sys.argv) > 3 else ""
            record_failure(reason, context)
        elif cmd == "--reset":
            reset_data()
        else:
            print("Usage: python self_learning.py [--stats|--success [ctx]|--failure reason [ctx]|--reset]")
    else:
        show_stats()