from __future__ import annotations

import argparse
import json
import sys
import urllib.request
from typing import Any

from common import dump_json, dump_text


CHROMIUM_DASH_URL = "https://chromiumdash.appspot.com/fetch_releases?channel=Stable&platform={platform}"


def version_tuple(value: str) -> tuple[int, ...]:
    return tuple(int(part) for part in value.split(".") if part.isdigit())


def fetch_releases(platform: str, timeout: int) -> list[dict[str, Any]]:
    with urllib.request.urlopen(CHROMIUM_DASH_URL.format(platform=platform), timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))
    if not isinstance(payload, list):
        raise ValueError(f"unexpected ChromiumDash response for {platform}")
    return payload


def latest_release(releases: list[dict[str, Any]]) -> dict[str, Any]:
    stable = [release for release in releases if release.get("version")]
    if not stable:
        raise ValueError("no stable releases with versions found")
    return max(stable, key=lambda release: version_tuple(str(release["version"])))


def render_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Chrome Stable Release Check",
        "",
        f"Blockers: **{len(report['blockers'])}**",
        f"Warnings: **{len(report['warnings'])}**",
        "",
        "| Platform | Milestone | Version |",
        "| --- | --- | --- |",
    ]
    for item in report["platforms"]:
        lines.append(f"| {item['platform']} | {item['milestone']} | {item['version']} |")
    lines.extend(["", "## Blockers"])
    lines.extend([f"- {item}" for item in report["blockers"]] or ["No blockers."])
    lines.extend(["", "## Warnings"])
    lines.extend([f"- {item}" for item in report["warnings"]] or ["No warnings."])
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Check current Chrome Stable versions from ChromiumDash.")
    parser.add_argument("--platform", action="append", default=[], help="Repeatable platform. Defaults to Mac, Windows, Linux.")
    parser.add_argument("--min-milestone", type=int, help="Fail if any checked Stable milestone is older.")
    parser.add_argument("--tested-chrome-version", help="Chrome version used for local E2E; warns when behind latest Stable milestone.")
    parser.add_argument("--timeout", type=int, default=20, help="HTTP timeout in seconds.")
    parser.add_argument("--json-out", help="Optional JSON report output path.")
    parser.add_argument("--markdown-out", help="Optional Markdown report output path.")
    args = parser.parse_args()

    platforms = args.platform or ["Mac", "Windows", "Linux"]
    blockers: list[str] = []
    warnings: list[str] = []
    platform_reports: list[dict[str, Any]] = []

    for platform in platforms:
        try:
            release = latest_release(fetch_releases(platform, args.timeout))
        except Exception as exc:  # noqa: BLE001 - report the platform-specific failure.
            blockers.append(f"{platform}: failed to fetch Chrome Stable release data: {exc}")
            continue
        milestone = int(release.get("milestone") or version_tuple(str(release["version"]))[0])
        platform_reports.append(
            {
                "platform": platform,
                "milestone": milestone,
                "version": release["version"],
                "source": CHROMIUM_DASH_URL.format(platform=platform),
            }
        )
        if args.min_milestone and milestone < args.min_milestone:
            blockers.append(f"{platform}: Stable milestone {milestone} is below required {args.min_milestone}")

    if args.tested_chrome_version and platform_reports:
        tested_milestone = version_tuple(args.tested_chrome_version)[0]
        latest_milestone = max(item["milestone"] for item in platform_reports)
        if tested_milestone < latest_milestone:
            warnings.append(
                f"local E2E used Chrome {args.tested_chrome_version}, behind current Stable milestone {latest_milestone}"
            )

    report = {
        "ok": not blockers,
        "platforms": platform_reports,
        "blockers": blockers,
        "warnings": warnings,
        "references": [
            "https://chromiumdash.appspot.com/fetch_releases",
            "https://chromereleases.googleblog.com/",
            "https://developer.chrome.com/release-notes/",
        ],
    }
    if args.json_out:
        dump_json(args.json_out, report)
    if args.markdown_out:
        dump_text(args.markdown_out, render_markdown(report))
    print(json.dumps(report, indent=2, ensure_ascii=True))
    if blockers:
        sys.exit(1)


if __name__ == "__main__":
    main()
