---
name: step-factory
description: CAD STEP 文件生成工厂 - 基于 PythonOCC (miniconda) 和 FreeCAD 双引擎。支持：方块、圆柱、管材、锥形、齿轮、法兰、装配体等工业级 STEP 文件生成。
capabilities:
  - name: make_box
    description: 生成方块/长方体实心模型
    parameters:
      - name: w
        type: float
        required: true
        description: 宽度(mm)
      - name: h
        type: float
        required: true
        description: 高度(mm)
      - name: d
        type: float
        required: true
        description: 厚度(mm)
    output: STEP文件路径
    invoke:
      type: cli
      command: "/home/timo/.miniconda/bin/python3 /home/timo/.openclaw/skills/step-factory/scripts/step_occ.py --func make_box --params '{params}'"
    example: '{"w":120,"h":80,"d":10}'

  - name: make_punched_plate
    description: 生成矩形打孔板（法兰）- 支持多孔
    parameters:
      - name: w
        type: float
        required: true
        description: 宽度(mm)
      - name: h
        type: float
        required: true
        description: 长度(mm)
      - name: thickness
        type: float
        required: true
        description: 厚度(mm)
      - name: hole_rs
        type: list
        required: true
        description: 孔径列表(mm)
      - name: spacing
        type: list
        required: true
        description: 孔间距[x,y]
    output: STEP文件路径
    invoke:
      type: cli
      command: "/home/timo/.miniconda/bin/python3 /home/timo/.openclaw/skills/step-factory/scripts/step_occ.py punched_plate {w} {h} {thickness} {hole_rs} {spacing}"
    example: '{"w":120,"h":80,"thickness":10,"hole_rs":[8],"spacing":[60,40]}'
---

name: step-factory
description: CAD STEP 文件生成工厂 - 基于 PythonOCC (miniconda) 和 FreeCAD 双引擎。支持：方块、圆柱、管材、锥形、齿轮、法兰、装配体等工业级 STEP 文件生成。
capabilities:
  - name: make_box
    description: 生成方块/长方体实心模型
    parameters:
      - name: w
        type: float
        required: true
        description: 宽度(mm)
      - name: h
        type: float
        required: true
        description: 高度(mm)
      - name: d
        type: float
        required: true
        description: 厚度(mm)
    output: STEP文件路径
    invoke:
      type: cli
      command: "/home/timo/.miniconda/bin/python3 /home/timo/.openclaw/skills/step-factory/scripts/step_occ.py --func make_box --params '{params}'"
    example: '{"w":120,"h":80,"d":10}'

  - name: make_punched_plate
    description: 生成矩形打孔板（法兰）- 支持多孔
    parameters:
      - name: w
        type: float
        required: true
        description: 宽度(mm)
      - name: h
        type: float
        required: true
        description: 长度(mm)
      - name: thickness
        type: float
        required: true
        description: 厚度(mm)
      - name: hole_rs
        type: list
        required: true
        description: 孔径列表(mm)
      - name: spacing
        type: list
        required: true
        description: 孔间距[x,y]
    output: STEP文件路径
    invoke:
      type: cli
      command: "/home/timo/.miniconda/bin/python3 /home/timo/.openclaw/skills/step-factory/scripts/step_occ.py punched_plate {w} {h} {thickness} {hole_rs} {spacing}"
    example: '{"w":120,"h":80,"thickness":10,"hole_rs":[8],"spacing":[60,40]}'
---
# STEP Factory - CAD 模型生成技能

## 双引擎架构
- **PythonOCC** (首选): `/home/timo/.miniconda/bin/python3` - 用于精确 CAD 建模
- **FreeCAD** (备选): `/usr/bin/freecadcmd` - 用于复杂装配和钣金

## 环境验证
```bash
~/.miniconda/bin/python3 -c "from OCC.Core import BRepPrimAPI, STEPControl; print('OCC OK')"
```

## PythonOCC 核心 API

### 基础形状
```python
from OCC.Core.BRepPrimAPI import BRepPrimAPI_MakeBox, BRepPrimAPI_MakeCylinder, BRepPrimAPI_MakeCone, BRepPrimAPI_MakeSphere, BRepPrimAPI_MakeTorus
from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_MakeSolid
from OCC.Core.STEPControl import STEPControl_Writer
```

### 布尔运算
```python
from OCC.Core.BoolTools import BoolTools_Common
from OCC.Core.BRepAlgoAPI import BRepAlgoAPI_Cut, BRepAlgoAPI_Fuse, BRepAlgoAPI_Common
```

### 导出
```python
writer = STEPControl_Writer()
writer.Transfer(shape, 1)  # 1 = silent mode
writer.Save(filepath)
```

## CAD 功能清单

### 基础类型（Primitive）
| 类型 | API | 参数 |
|

capabilities:
  - name: make_box
    description: 生成方块/长方体实心模型
    parameters:
      - name: w
        type: float
        required: true
        description: 宽度(mm)
      - name: h
        type: float
        required: true
        description: 高度(mm)
      - name: d
        type: float
        required: true
        description: 厚度(mm)
    output: STEP文件路径
    invoke:
      type: cli
      command: "/home/timo/.miniconda/bin/python3 /home/timo/.openclaw/skills/step-factory/scripts/step_occ.py --func make_box --params '{params}'"
    example: '{"w":120,"h":80,"d":10}'

  - name: make_punched_plate
    description: 生成矩形打孔板（法兰）- 支持多孔
    parameters:
      - name: w
        type: float
        required: true
        description: 宽度(mm)
      - name: h
        type: float
        required: true
        description: 长度(mm)
      - name: thickness
        type: float
        required: true
        description: 厚度(mm)
      - name: hole_rs
        type: list
        required: true
        description: 孔径列表(mm)
      - name: spacing
        type: list
        required: true
        description: 孔间距[x,y]
    output: STEP文件路径
    invoke:
      type: cli
      command: "/home/timo/.miniconda/bin/python3 /home/timo/.openclaw/skills/step-factory/scripts/step_occ.py punched_plate {w} {h} {thickness} {hole_rs} {spacing}"
    example: '{"w":120,"h":80,"thickness":10,"hole_rs":[8],"spacing":[60,40]}'
------|-----|------|
| box | BRepPrimAPI_MakeBox | W, H, D |
| cylinder | BRepPrimAPI_MakeCylinder | R, H |
| cone | BRepPrimAPI_MakeCone | bottom_R, top_R, H |
| sphere | BRepPrimAPI_MakeSphere | R |
| torus | BRepPrimAPI_MakeTorus | major_R, minor_R |

### 空心/管材
```python
# 管材: 外圆柱 - 内圆柱
outer = BRepPrimAPI_MakeCylinder(outer_r, h).Shape()
inner = BRepPrimAPI_MakeCylinder(inner_r, h).Shape()
tube = BRepAlgoAPI_Cut(outer, inner).Shape()
```

### 法兰
```python
outer = BRepPrimAPI_MakeCylinder(outer_r, thickness).Shape()
hole = BRepPrimAPI_MakeCylinder(hole_r, thickness + 2).Shape()
flange = BRepAlgoAPI_Cut(outer, hole).Shape()
```

### 锥管
```python
cone = BRepPrimAPI_MakeCone(bottom_r, top_r, h).Shape()
# 切内孔
inner = BRepPrimAPI_MakeCone(inner_bottom_r, inner_top_r, h + 1).Shape()
tapered_tube = BRepAlgoAPI_Cut(cone, inner).Shape()
```

### 多级轴
```python
segments = [(r1, h1), (r2, h2), ...]
shapes = []
y = 0
for r, h in segments:
    cyl = BRepPrimAPI_MakeCylinder(r, h).Shape()
    # translate
    from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_Transform
    from OCC.Core.gp import gp_Vec, gp_Trsf
    trsf = gp_Trsf()
    trsf.SetTranslation(gp_Vec(0, y, 0))
    shapes.append(BRepBuilderAPI_Transform(cyl, trsf).Shape())
    y += h
# fuse all
```

### 齿轮
```python
# 渐开线齿轮 - 需要较复杂建模
# 简化: 用圆环代替齿轮
gear = BRepPrimAPI_MakeCylinder(external_r, thickness).Shape()
```

### 钣金折弯
```python
# 用 FreeCAD 做钣金更方便
```

## 输出目录
- `/home/timo/STEP`

## 执行方式
通过 exec 工具运行 `~/.miniconda/bin/python3` 脚本

## 已有 STEP 文件分类参考

### Demo 系列（100个基础测试件）
- `demo1_50x50x50` - 50³ 方块
- `demo2_r20h60` - R20×H60 圆柱
- `demoN_orXirYhZ` - 外径X/内径Y/高度Z 空心管
- `demoN_rXhY` - 半径X/高度Y 圆柱

### Test 系列（20个复杂件）
- `test1_box_with_hole` - 带孔方块
- `test2_threaded_counterbore` - 螺纹埋头孔
- `test3_hex_prism_with_features` - 六角棱柱带特征
- `test5_shaft_with_steps` - 多级轴
- `test7_sheet_metal_bend` - 钣金折弯

### CNC 测试系列
- `cnc_test_thin_wall` - 薄壁加工
- `cnc_test_deep_slot` - 深槽加工
- `cnc_test_precision_holes` - 精密孔加工
- `cnc_test_thread` - 螺纹加工
- `five_axis_turbine_blade` - 五轴叶轮

### 3D打印系列
- `print3d_nurbs_ultraman` - NURBS 曲面
- `print3d_robot_hand_fixed` - 机器人手
- `print3d_assembly_gap_block/pin` - 配合测试

### PythonOCC 生成的样件
- `occ_box_50x50x50.step` - OCC 方块
- `occ_cylinder_r25h100.step` - OCC 圆柱
- `occ_tube_r40r10h80.step` - OCC 管材

## 执行流程
1. 解析用户输入（图片识别 → 参数提取 / 直接参数描述）
2. 确定 CAD 类型和参数
3. 生成 PythonOCC 脚本
4. 执行 `~/.miniconda/bin/python3 script.py`
5. 验证输出 STEP 文件
6. 返回文件路径
---

## Capabilities (供Orchestrator编排器使用)

```yaml
capabilities:
capabilities:
  - name: make_box
    description: 生成方块/长方体实心模型
    parameters:
      - name: w
        type: float
        required: true
        description: 宽度(mm)
      - name: h
        type: float
        required: true
        description: 高度(mm)
      - name: d
        type: float
        required: true
        description: 厚度(mm)
    output: STEP文件路径
    example: '{"w":120,"h":80,"d":10}'
    call: "/home/timo/.miniconda/bin/python3 -c \"from OCC.Core.BRepPrimAPI import BRepPrimAPI_MakeBox; from OCC.Core.STEPControl import STEPControl_Writer; s=BRepPrimAPI_MakeBox(120,80,10).Shape(); w=STEPControl_Writer(); w.Transfer(s,1); w.Write('/home/timo/STEP/box.step')\""

  - name: make_punched_plate
    description: 生成矩形打孔板（法兰）- 支持多孔
    parameters:
      - name: w
        type: float
        required: true
        description: 宽度(mm)
      - name: h
        type: float
        required: true
        description: 长度(mm)
      - name: thickness
        type: float
        required: true
        description: 厚度(mm)
      - name: hole_rs
        type: list
        required: true
        description: 孔径列表(mm)
      - name: spacing
        type: list
        required: true
        description: 孔间距[x,y]
    output: STEP文件路径
    example: '{"w":120,"h":80,"thickness":10,"hole_rs":[8],"spacing":[60,40]}'
    call: "/home/timo/.miniconda/bin/python3 /home/timo/.openclaw/skills/step-factory/scripts/step_occ.py --func make_punched_plate --params '{\"w\":120,\"h\":80,\"thickness\":10,\"hole_rs\":[8],\"spacing\":[60,40]}'"
