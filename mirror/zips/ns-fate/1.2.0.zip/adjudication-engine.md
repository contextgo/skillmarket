# NS Fate Adjudication Engine

当不同体系给出冲突结论时，使用本引擎做“硬仲裁”，避免主观挑选。

---

## 1) 目标

把多体系输出统一成：

- 一个主结论（Main Direction）
- 一个备选路径（Fallback Path）
- 明确的触发与失效条件
- 一个决策码（GO/HOLD/NO-GO）

---

## 2) 输入结构（强制）

每个体系先标准化成同一结构：

```markdown
Source: [Astrology/Calendar/Tarot/Symbolic]
Direction: [Positive/Neutral/Negative]
Confidence: [0.00-1.00]
Time Fit: [0.00-1.00]      # 与用户时间窗匹配度
Data Quality: [0.00-1.00]  # 数据完整度
Specificity: [0.00-1.00]   # 是否可检验
Volatility Risk: [0.00-1.00]
Claim:
Trigger:
Invalid:
```

---

## 3) 基础权重

默认权重（可按问题类型动态改）：

- Astrology: 0.34
- Calendar: 0.28
- Tarot: 0.24
- Symbolic: 0.14

### 问题类型修正

- 时间窗口问题：Astrology +0.06, Calendar +0.08, Tarot -0.08, Symbolic -0.06
- 动机/关系问题：Tarot +0.08, Symbolic +0.06, Astrology -0.08, Calendar -0.06
- 重大决策问题：Astrology +0.04, Calendar +0.04, Tarot +0.02, Symbolic -0.10

修正后统一归一化到 1.0。

---

## 4) 源级可信度分

每个来源计算：

`source_score = w * Confidence * TimeFit * DataQuality * Specificity * (1 - 0.5*VolatilityRisk)`

其中 `w` 为修正后权重。

---

## 5) 方向融合与决策码

将方向编码：

- Positive = +1
- Neutral = 0
- Negative = -1

计算：

`fusion_signal = Σ(source_score * direction_code)`

方向阈值：

- `fusion_signal >= +0.12` -> 主方向 Positive
- `fusion_signal <= -0.12` -> 主方向 Negative
- 其他 -> 主方向 Neutral

决策码映射（强制输出）：

- Positive -> `GO`
- Negative -> `NO-GO`
- Neutral -> `HOLD`

---

## 6) 冲突等级判定

定义 `dominance = |top1_score - top2_score|`（前两高来源分差）。

- **Low Conflict**: dominance >= 0.08 且方向一致
- **Medium Conflict**: dominance < 0.08 或存在中度反向
- **High Conflict**: 前两来源方向相反且分差 < 0.05

---

## 7) 仲裁动作

### 7.1 Low Conflict

- 直接采用主方向
- 输出 1 条主路径 + 1 条风险提示

### 7.2 Medium Conflict

- 输出主路径 + 备选路径
- 明确“触发条件 A / 触发条件 B”
- 复盘周期缩短到 7 天

### 7.3 High Conflict

- 禁止“强置信度”结论（不是禁止方向）
- 仍需给出主决策码，默认 `HOLD`
- 同时输出“条件化结论（If/Then）”
- 必须追加最小补充数据（如出生时分或候选日期）
- 信心上限为 Medium

---

## 8) 时间优先与动机优先的拆分

当 Astrology/Calendar 与 Tarot 明显冲突：

- “是否做”优先看 Tarot/Symbolic（动机与结构阻力）
- “何时做”优先看 Astrology/Calendar（时间与节奏）

最终输出格式：

- Decision: 做 / 不做 / 延后
- Timing: 何时推进 / 何时回避
- Preconditions: 先完成哪些条件再执行

---

## 9) 反过拟合规则

若出现以下任一情况，自动降级结论：

1. 结论依赖单一来源 > 70%
2. 缺少 Trigger 或 Invalid 条件
3. 使用大量不可检验语句
4. 时间窗超出用户请求 2 倍以上

降级动作：

- High -> Medium
- Medium -> Low

---

## 10) 输出模板（仲裁版）

```markdown
## Adjudication Result
- Decision Code: [GO/HOLD/NO-GO]
- Main Direction:
- Fusion Signal:
- Conflict Level:
- Primary Source(s):
- Secondary Source(s):

### Path A (Primary)
- Do:
- Timing:
- Trigger:
- Invalid:

### Path B (Fallback)
- Use when:
- Do:
- Timing:

### Confidence Guardrail
- Max Confidence Allowed:
- Why:
```
