# NS Fate Prediction Registry

这是高精度运行的“预测登记簿”。  
未登记的预测默认不参与准确度统计。

---

## 1) 单条登记模板

```markdown
## Record ID: [YYYYMMDD-XXX]
- Date Created:
- Source Type: [Astrology/Calendar/Tarot/Symbolic/Mixed]
- Source Name:
- Scenario: [career/relationship/timing]
- Time Window: [7d/30d/90d]

- Tarot Draw Metadata (if Source Type includes Tarot):
  - Spread Size:
  - Seed:
  - Picked Numbers:
  - Revealed Cards:
  - Reproducible: [Yes/No]

- Claim (Testable):
  - [一句可检验陈述]

- Trigger Condition:
  - [满足则应触发]

- Invalid Condition:
  - [满足则预测失效]

- Action Recommendation:
  - Do:
  - Avoid:

- Expected Review Date:
- Review Result: [Pending/Hit/Partial/Miss/Unclear]
- Evidence Note:
```

---

## 2) 记录规范

1. Claim 必须是“能被现实验证”的句子。
2. 不允许“模棱两可双向陈述”。
3. 无触发条件或无失效条件的记录，标记为 `Unclear`。
4. 每条记录必须有复盘日期，否则不计入样本。
5. 塔罗记录若无 Seed 或 Picked Numbers，自动标记 `Reproducible: No`。

---

## 3) 周汇总模板

```markdown
# Weekly Registry Summary - [YYYY-WW]

## Counts
- Total Registered:
- Testable:
- Pending:

## Outcomes
- Hit:
- Partial:
- Miss:
- Unclear:

## Scenario Split
- Career:
- Relationship:
- Timing:

## Notes
- Major bias found:
- Data quality issue:
- Next week adjustment:
```

---

## 4) 偏差归因标签

每次 Miss 必须打一个主标签：

- `T1`: 时间窗错误
- `T2`: 触发条件判断错误
- `T3`: 方法冲突未处理
- `T4`: 输入数据缺失
- `T5`: 解释过拟合

季度统计时，按标签反推系统弱点并更新规则库。
