#!/usr/bin/env python3
"""NS Fate Tarot Deck - Shuffle & Draw System"""

import sys
import json
import hashlib
import struct
import time
import random

# Complete 78-card Tarot deck
MAJOR_ARCANA = [
    "0 愚者 The Fool",
    "I 魔术师 The Magician",
    "II 女祭司 The High Priestess",
    "III 女皇 The Empress",
    "IV 皇帝 The Emperor",
    "V 教皇 The Hierophant",
    "VI 恋人 The Lovers",
    "VII 战车 The Chariot",
    "VIII 力量 Strength",
    "IX 隐者 The Hermit",
    "X 命运之轮 Wheel of Fortune",
    "XI 正义 Justice",
    "XII 倒吊人 The Hanged Man",
    "XIII 死神 Death",
    "XIV 节制 Temperance",
    "XV 恶魔 The Devil",
    "XVI 塔 The Tower",
    "XVII 星星 The Star",
    "XVIII 月亮 The Moon",
    "XIX 太阳 The Sun",
    "XX 审判 Judgement",
    "XXI 世界 The World",
]

SUITS = {
    "Wands": "权杖",
    "Cups": "圣杯",
    "Swords": "宝剑",
    "Pentacles": "星币",
}

COURT = ["Page 侍从", "Knight 骑士", "Queen 王后", "King 国王"]
PIPS = ["Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"]

def build_deck():
    deck = []
    # Major Arcana (22 cards)
    for card in MAJOR_ARCANA:
        deck.append(card)
    # Minor Arcana (56 cards)
    for suit_en, suit_cn in SUITS.items():
        for pip in PIPS:
            deck.append(f"{suit_cn}{pip} ({pip} of {suit_en})")
        for court in COURT:
            deck.append(f"{suit_cn}{court} ({court.split()[0]} of {suit_en})")
    return deck

def shuffle_deck(seed=None):
    """Shuffle with optional seed. Returns shuffled deck and seed used."""
    if seed is None:
        seed = int(time.time() * 1000000)  # microsecond precision
    rng = random.Random(seed)
    deck = build_deck()
    # Add upright/reversed (正位/逆位) 
    deck_with_orientation = []
    for card in deck:
        orientation = "正位" if rng.random() > 0.5 else "逆位"
        deck_with_orientation.append({"card": card, "orientation": orientation})
    rng.shuffle(deck_with_orientation)
    return deck_with_orientation, seed

def draw(deck, positions):
    """Draw cards at given positions (1-indexed)."""
    results = []
    for pos in positions:
        if 1 <= pos <= 78:
            entry = deck[pos - 1]
            results.append({
                "position": pos,
                "card": entry["card"],
                "orientation": entry["orientation"],
            })
        else:
            results.append({"position": pos, "error": "超出范围 (1-78)"})
    return results

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "shuffle"
    
    if cmd == "shuffle":
        deck, seed = shuffle_deck()
        print(json.dumps({"action": "shuffled", "seed": seed, "total_cards": 78}, ensure_ascii=False))
    
    elif cmd == "draw":
        seed = int(sys.argv[2])
        positions = [int(x) for x in sys.argv[3:]]
        deck, _ = shuffle_deck(seed)
        results = draw(deck, positions)
        print(json.dumps({"action": "draw", "seed": seed, "cards": results}, ensure_ascii=False, indent=2))
    
    elif cmd == "info":
        deck = build_deck()
        print(f"Total cards: {len(deck)}")
        print(f"Major Arcana: {len(MAJOR_ARCANA)}")
        print(f"Minor Arcana: {len(deck) - len(MAJOR_ARCANA)}")
