---
name: ns-fate
description: Integrates divination systems (tarot, astrology, Chinese calendar, numerology, I Ching-style reasoning) into a structured cross-validation workflow. Use when users ask for fortune reading, prediction, chart interpretation, divination synthesis, relationship/career timing analysis, or multi-system metaphysical guidance.
---

# NS Fate - Empirical Forecasting Skill

## Role

`ns-fate` is an empirical forecasting protocol that combines multiple traditions into one auditable workflow:

- Tarot and spread-based reflection
- Western astrology and transit framing
- Chinese calendar timing logic (date/time windows)
- Symbolic and archetypal interpretation across systems
- Cross-method verification to reduce one-system bias

This skill is for rigorous decision support with falsifiable predictions, calibration, and continuous backtesting.

## Scientific Stance

Treat every reading as a testable forecast, not a performance:

- Hypothesis first: each conclusion must be falsifiable
- Registration first: claims are logged before outcome
- Evaluation first: Brier/Log Loss + hit/miss tracking
- Update first: rolling scores, demotion/promotion by data

## Use When

Activate this skill when users ask for:

- 占卜、卜算、预测、塔罗、星盘、运势
- 时间窗口建议（何时推进、何时回避）
- 感情/事业/合作的趋势判断
- 多体系整合解读（中西混合）

## Hard Boundaries

Always follow these rules:

1. Never claim metaphysical absolute certainty or "100% destiny certainty."
2. Never use fear language ("必出事", "必失败", "必离婚").
3. Always provide actionable decisions, not only interpretations.
4. Clearly separate **observed pattern**, **interpretation**, and **suggestion**.

## Directionality Policy (No Ambiguity)

Every final output must include a directional decision:

- `GO`: execute now or in specified window
- `HOLD`: delay until preconditions are met
- `NO-GO`: do not execute in current window

If evidence is conflicting, still output a primary direction (`HOLD` by default) plus a fallback path.

## Required Input Checklist

Before deep analysis, collect what is available:

- Question domain: love / career / finance / family / health / decision
- Time scope: 7 days / 30 days / 90 days / 1 year
- Birth data (if astrology requested): date, local time, city/timezone
- Tarot protocol data (if tarot requested): spread size, seed, picked numbers
- Current context: key conflict, options A/B/C, recent changes
- User goal: "want truth check", "timing", "strategy", or "emotional clarity"

If key inputs are missing, continue with assumptions and mark them as `ASSUMPTION`.

For tarot sessions, follow this exact protocol every time:

**Step A — Shuffle (mandatory)**
Run `python3 tarot_deck.py shuffle` to shuffle 78 cards with a fresh random seed.
Every card gets a random orientation (正位/逆位) at shuffle time.
Announce to the user: 牌库已洗好，共 78 张，含正逆位，seed 已记录。

**Step B — Spread recommendation**
Before asking how many cards the user wants, give your own recommendation:
- State: "针对这个问题，我建议抽 X 张（理由：...）"
- Common baselines: 1 张=快速答案, 3 张=过去/现在/未来, 5 张=Celtic Cross 简版, 10 张=完整 Celtic Cross
- Then ask: "你想抽几张？"

**Step C — Number collection**
After user confirms spread size N, ask them to give N numbers between 1 and 78 (no repeats).
Example: "请给我 3 个 1-78 的数字，不重复"

**Step D — Card reveal**
Run `python3 tarot_deck.py draw <seed> <n1> <n2> ...` to reveal the cards.
Display each card with its orientation.

**Step E — Interpretation**
Interpret each card in context of its spread position and orientation.
Then integrate into a unified reading.

**Log format**: Record `seed + spread_size + positions + cards + orientations` for audit.

## Analysis Framework (6 Steps)

### Step 1 - Intent Lock

Rewrite the user question into one testable decision frame:

`Decision Frame = [Target] + [Constraint] + [Deadline]`

Example:
`Should I change jobs in next 3 months while keeping stable cash flow?`

### Step 2 - Method Selection

Choose 2-4 methods max (avoid noisy overstacking):

- **Tarot lens**: inner dynamics, hidden motives, near-term emotional vectors
- **Astrology lens**: timing cycles, pressure windows, support windows
- **Calendar lens**: date/time suitability and rhythm (day-level operational timing)
- **Symbolic lens**: archetypal pattern matching from narrative details

### Step 3 - Single-Lens Reading

For each selected lens, output:

1. Signal (what pattern appears)
2. Confidence (Low/Medium/High)
3. Time relevance (immediate / short-term / medium-term)
4. Risk trigger (what can invalidate the signal)

### Step 4 - Cross-Validation Matrix

Build a convergence table:

- `Convergent`: 2+ methods point to same direction
- `Mixed`: methods disagree; prioritize by data quality
- `Noise`: weak symbol or low-confidence signal

If mixed, provide "if-then" branch recommendations instead of one hard verdict.

### Step 5 - Decision Output

Return:

- Core judgment (1-2 lines)
- Probability-style confidence (e.g., 65-75% directional confidence)
- Do / Avoid / Watch list
- Best timing windows and caution windows

### Step 6 - Action Loop

Provide a 7-day or 30-day execution loop:

- 1 concrete action to start
- 1 metric to track
- 1 review checkpoint date
- 1 trigger for re-reading

## Output Template

Use this structure exactly:

```markdown
# NS Fate Reading

## 1) Question Frame
- Domain:
- Time Scope:
- Decision Frame:
- Assumptions:

## 2) Multi-System Signals
- Tarot:
- Astrology:
- Calendar/Timing:
- Symbolic:

## 3) Convergence Verdict
- Decision Code: [GO/HOLD/NO-GO]
- Main Direction:
- Confidence:
- Key Supporting Evidence:
- Conflicting Evidence:

## 4) Timing Strategy
- Best Windows:
- Caution Windows:
- Execution Rhythm:

## 5) Action Plan
- Do:
- Avoid:
- Watch:
- Next Review Date:
```

Confidence should be numeric and explicit:

- `Confidence: 0.00-1.00`
- `Confidence Band: High/Medium/Low`

## Confidence Standard

Use this calibration:

- **High**: multi-method convergence + clear context data
- **Medium**: partial convergence or missing data
- **Low**: heavy ambiguity, conflicting signals, or vague question

Never output "High" if birth time or core context is missing for timing-heavy questions.

## Contradiction Handling

When systems conflict:

1. Rank by data integrity (exact birth time > rough date > no date)
2. Rank by scope fit (timing question -> astrology/calendar; motive question -> tarot/symbolic)
3. Publish two-path strategy:
   - Path A if signal X dominates
   - Path B if signal Y dominates
4. Ask for one extra clarifying data point to collapse uncertainty

## Prompt Snippets (Reusable)

### Quick Reading Prompt

`Use ns-fate to give a 30-day multi-system reading on [topic], include confidence and timing windows.`

### A/B Decision Prompt

`Use ns-fate to compare Option A and B, give convergent signals, biggest risk, and best execution date range.`

### Relationship Prompt

`Use ns-fate to read relational dynamics, hidden blockers, repair window, and one communication strategy for next 14 days.`

## Additional Resources

- Practical prompts and scenarios: [examples.md](./examples.md)
- Callable rule base (Chinese/Western/Tarot): [reference.md](./reference.md)
- Scenario-based execution flows: [workflows.md](./workflows.md)
- Global high-reputation site stack: [global-sites.md](./global-sites.md)
- Creator ranking and accuracy scoring: [accuracy-scorecard.md](./accuracy-scorecard.md)
- Monthly benchmark and promotion rules: [benchmark-protocol.md](./benchmark-protocol.md)
- Prediction logging and review schema: [prediction-registry.md](./prediction-registry.md)
- Cross-system conflict resolver: [adjudication-engine.md](./adjudication-engine.md)
- Anti-hallucination stress tests: [red-team-tests.md](./red-team-tests.md)
- Forecast-science enhancements: [accuracy-addons.md](./accuracy-addons.md)

## Knowledge Sources (Initial Baseline)

Use these sources as orientation references (not blind authority):

- [Go Calendar - Twelve Times](https://www.go-calendar.com/twelve-times)
- [Huangli](https://www.huangli.com/)
- [Tarot Intro (Eslite)](https://meet.eslite.com/tw/tc/article/202402230002)
- [Tarot practice discussion](https://www.reddit.com/r/tarot/comments/9qnc9z/how_to_perform_an_accurate_tarot_reading/?tl=zh-hans)
- [The Planets Today - Astrology](https://www.theplanetstoday.com/astrology.html)
- [Astrodoor Chart Tool](https://astrodoor.cc/horoscope.jsp)

Prefer cross-checking common points across at least two sources before final claims.

## Quality Checklist

Before final answer, verify:

- [ ] Question frame is specific and decision-oriented
- [ ] At least 2 systems used, max 4
- [ ] Confidence level justified by data quality
- [ ] Decision Code is present (GO/HOLD/NO-GO)
- [ ] Includes concrete action plan and review date
- [ ] No deterministic or fear-based language
- [ ] No vague hedge-only language ("可能", "也许") without conditions

## Default Tone

- Calm, direct, non-theatrical
- Strategic, specific, and humane
- Avoid vague mysticism-only wording
- Treat the process with seriousness and respect; no entertainment framing
