# NS Fate Accuracy Scorecard

这个文档用于“我不自己找博主，由系统代筛”的高准度场景。  
目标：把“感觉准”变成“可量化、可淘汰、可迭代”的博主清单。

---

## 1) 评分原则（准度优先）

只按以下硬标准评分，不按粉丝量和人设评分：

1. **预测可检验性（30分）**  
   是否给出明确时间窗、事件条件、触发信号。
2. **方法透明度（20分）**  
   是否说明推导逻辑，而非只给结论。
3. **计算与工具可靠性（20分）**  
   是否使用可信计算工具和稳定框架。
4. **复盘友好度（15分）**  
   是否能被记录、回测、统计命中率。
5. **噪声控制（15分）**  
   是否避免泛化、恐吓、模糊话术。

总分 100，采用等级：

- `S`: 85-100（高优先长期跟踪）
- `A`: 75-84（可用）
- `B`: 65-74（仅做补充）
- `C`: <65（淘汰）

---

## 2) 代筛候选池（你无需自己找）

以下名单由系统代筛，覆盖中英双语、占星/塔罗主流方法：

1. 安格斯（占星之门）
2. Chris Brennan（The Astrology Podcast）
3. Chani Nicholas（CHANI）
4. Jessica Lanyadoo
5. Susan Miller（Astrology Zone）
6. Brigit Esselmont（Biddy Tarot）
7. Labyrinthos（创始团队方法）
8. Benebell Wen（Holistic Tarot）

备注：这是“方法稳定 + 长期内容产出 + 可复盘”的初始样本。后续可继续替换。

---

## 3) 初始评分（V1）

> 说明：V1 为方法论预评分，不是你个人命中率最终分。  
> 真实优先级以你连续 12 周回测后的“实测分”覆盖。

| 博主/平台 | 预测可检验性 (30) | 方法透明度 (20) | 计算可靠性 (20) | 复盘友好度 (15) | 噪声控制 (15) | 总分 | 等级 | 使用建议 |
|---|---:|---:|---:|---:|---:|---:|---|---|
| Chris Brennan | 25 | 19 | 17 | 13 | 13 | 87 | S | 技术框架主参考，适合严谨判断 |
| 安格斯 | 24 | 18 | 16 | 14 | 13 | 85 | S | 中文实操主参考，适合决策清单 |
| Chani Nicholas | 23 | 17 | 16 | 13 | 12 | 81 | A | 行运节奏与执行窗口参考 |
| Jessica Lanyadoo | 21 | 17 | 14 | 13 | 13 | 78 | A | 关系/边界类问题辅参考 |
| Brigit Esselmont | 18 | 18 | 12 | 14 | 14 | 76 | A | 塔罗问法与结构参考 |
| Benebell Wen | 17 | 19 | 12 | 12 | 14 | 74 | B | 深度研究强，快决策不优先 |
| Labyrinthos | 17 | 16 | 11 | 14 | 13 | 71 | B | 日常记录强，预测硬度中等 |
| Susan Miller | 18 | 13 | 13 | 10 | 10 | 64 | C | 只看大趋势，不做关键决策依据 |

---

## 4) 强制使用规则（防“看谁都准”）

### Rule A - 双源交叉

任何结论至少来自：

- `1 位 S/A 级占星来源` + `1 个高可靠计算站点（Astro.com/Astro-Seek）`

单一博主结论不得直接执行重大决策。

### Rule B - 时间窗强制

只接收含时间窗的判断：

- 7天 / 30天 / 90天

若博主内容只有抽象描述，不计入预测分母。

### Rule C - 触发条件强制

每条判断必须写清：

- 触发条件
- 失效条件
- 复盘日期

缺一项，判定为“不可复盘内容”。

---

## 5) 实测评分模板（每周更新）

复制以下模板为每位博主建一条记录：

```markdown
### [Name] - Week [YYYY-WW]
- Prediction Window: [7/30/90 days]
- Claim: [具体可检验句]
- Trigger Condition: [触发条件]
- Invalid Condition: [失效条件]
- Outcome: [Hit / Partial / Miss]
- Notes: [偏差原因]

Score Update:
- Hit = +3
- Partial = +1
- Miss = -2
```

---

## 6) 淘汰与晋级机制

- **淘汰**：连续 6 周实测分 <= -6，移出核心池 8 周。
- **降级**：连续 4 周命中率 < 35%，等级降一级。
- **晋级**：连续 8 周命中率 >= 65%，可晋升一级（最高 S）。
- **重测**：被淘汰者 8 周后用新样本重测，不继承旧分。

---

## 7) 你的默认执行名单（现在就用）

### 核心名单（优先）

1. Chris Brennan
2. 安格斯
3. Chani Nicholas

### 辅助名单（补解释）

1. Jessica Lanyadoo
2. Brigit Esselmont

### 观察名单（暂不作为主依据）

1. Benebell Wen
2. Labyrinthos
3. Susan Miller

---

## 8) 参考链接（方法论入口）

- [占星之门 - 安格斯](https://cn.astrodoor.cc/angus.jsp)
- [The Astrology Podcast - About](https://theastrologypodcast.com/about/)
- [CHANI App](https://app.chani.com/)
- [CHANI Transits](https://chaninicholas.zendesk.com/hc/en-us/articles/4409909027731-Transits)
- [Jessica Lanyadoo - About](https://www.lovelanyadoo.com/about)
- [Astrology Zone - About Susan Miller](https://www.astrologyzone.com/about/)
- [Biddy Tarot - About Brigit](https://biddytarot.com/about)
- [Labyrinthos Philosophy](https://labyrinthos.co/pages/our-philosopy-about-us)
- [Benebell Wen - Holistic Tarot](https://benebellwen.com/category/holistic-tarot-book/)

---

## 9) 与 ns-fate 的联动方式

在执行 `ns-fate` 时，先读本文件并按以下顺序调用：

1. 从核心名单抽 1-2 位作为方法参照
2. 用 `Astro.com / Astro-Seek` 做计算校验
3. 输出时附上：来源等级 + 本周实测趋势
4. 若来源等级低于 B，不允许作为主结论来源

---

## 10) 动态评分公式（强制）

为避免“某人一阵子很准，后面失真”，使用滚动分数而非静态总分：

### 10.1 Weekly Score

每周每位博主：

`weekly_score = 3*Hit + 1*Partial - 2*Miss - 1*Unclear`

其中：

- `Hit`: 明确命中
- `Partial`: 部分命中
- `Miss`: 明确偏差
- `Unclear`: 无法检验或表述模糊（计惩罚，防模糊话术）

### 10.2 Rolling Score (近新权重更高)

`rolling_score = 0.60*avg(last_4_weeks) + 0.25*avg(weeks_5_to_8) + 0.15*avg(weeks_9_to_12)`

### 10.3 Scenario Score（分场景）

对每位博主独立维护：

- `career_score`
- `relationship_score`
- `timing_score`

最终调用时按问题类型选最高分来源，不再用“总分一刀切”。

### 10.4 Volatility Penalty（波动惩罚）

`volatility = stdev(last_8_weeks)`

若 `volatility > 3.0`，则：

`effective_score = rolling_score - 0.8*(volatility - 3.0)`

高波动即降权，即使偶尔爆准也不直接升核心。
