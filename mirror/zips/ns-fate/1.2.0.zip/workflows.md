# NS Fate Workflows

这份文档给出“测测替代”可执行工作流。目标不是迷信单站点，而是通过多源交叉提高稳定性。

---

## Workflow A - 30天关系判断（感情/合作关系）

**适用问题**  
关系降温、反复争执、是否修复、是否继续投入。

**步骤**

1. **问题定焦（2分钟）**
   - 写成一句决策句：`我该如何做，才能在30天内判断这段关系是否可修复？`
2. **塔罗动力层（8-12分钟）**
   - 用 [Biddy Tarot](https://biddytarot.com/) 或 [Labyrinthos](https://labyrinthos.co/) 做动力与阻力判断。
3. **时间窗口层（8-10分钟）**
   - 用 [The Planets Today](https://www.theplanetstoday.com/astrology.html) 看近期逆行和沟通摩擦段。
4. **执行日筛选（5分钟）**
   - 在 [Huangli](https://www.huangli.com/) 或 [Go Calendar](https://www.go-calendar.com/twelve-times) 选沟通窗口。
5. **结论输出**
   - 给 `Do / Avoid / Watch`，并设 14 天复盘点。

**最低输出标准**

- 主方向（修复/观察/止损）
- 一条沟通动作
- 一条禁做事项
- 下一次复盘日期

---

## Workflow B - 90天职业转型（换岗/创业/跳槽）

**适用问题**  
是否转岗、何时离职、要不要创业。

**步骤**

1. **星盘主框架（10-15分钟）**
   - 用 [Astro.com](https://www.astro.com/) 或 [Astro-Seek](https://astrology-seek.com/) 看中期节奏。
2. **解释补充（8-10分钟）**
   - 用 [Cafe Astrology](https://cafeastrology.com/) 做可读性补充解释。
3. **本地择时（5-8分钟）**
   - [Huangli](https://www.huangli.com/) 或 [Go Calendar](https://www.go-calendar.com/twelve-times) 选启动/签约日。
4. **风险镜像（5分钟）**
   - 用 Tarot（Biddy/Labyrinthos）补“内在阻力和盲点”。
5. **结论输出**
   - 形成双路径：`保守路径` vs `进攻路径`。

**最低输出标准**

- 最佳推进窗口（2段）
- 慎行窗口（1段）
- 现金流底线动作（1条）
- 30天内可执行任务（1条）

---

## Workflow C - 合同/发布择时（7-21天短周期）

**适用问题**  
签约、上线、发布、谈判、开会节点。

**步骤**

1. 列出 3-7 个可选日期与时段。
2. 用 [Huangli](https://www.huangli.com/) 做第一轮筛选。
3. 用 [Go Calendar](https://www.go-calendar.com/twelve-times) 做时段细化。
4. 用 [The Planets Today](https://www.theplanetstoday.com/astrology.html) 回避明显冲突段。
5. 产出 A/B 备选日期，并写好失败应急方案。

**最低输出标准**

- `首选日 + 备选日`
- `建议时段`
- `必须提前确认的条款`
- `失败回滚动作`

---

## Workflow D - 年度主题规划（12个月）

**适用问题**  
事业扩张 vs 关系修复 vs 能力重构。

**步骤**

1. 用 [Astrodoor](https://astrodoor.cc/horoscope.jsp)、[Astro.com](https://www.astro.com/) 做年度主线判断。
2. 用 Tarot（Biddy/Labyrinthos）识别“内在重复模式”。
3. 以季度为单位切成 Q1-Q4 执行主题。
4. 每季度首月用 Calendar 选关键启动日。

**最低输出标准**

- 年度主线（1个）
- 季度子目标（4个）
- 每季度一个关键动作
- 每季度复盘问题（固定模板）

---

## Workflow E - 信息不足时的快速模式（Quick Mode）

**适用问题**  
用户没给出生时分、问题泛化、时间范围不清。

**步骤**

1. 先执行 2 系统：`Tarot + Calendar` 或 `Astrology + Calendar`。
2. 置信度最多给到 Medium。
3. 同时要求补 3 条信息：
   - 决策有效期（7/30/90天）
   - 底线约束（钱/时间/关系）
   - 目标动作（做不做/何时做）

**最低输出标准**

- 暂定方向
- 缺失信息清单
- 下一步补数后的复读时间

---

## Workflow F - 参与式塔罗抽牌（Seed Protocol）

**适用问题**  
需要把“随机性 + 意念参与 + 可复盘”统一起来的塔罗解读。

**步骤**

1. 用户提供或确认 `seed`，洗 78 张牌。
2. 确定牌阵位数（例如 3 张）。
3. 解读方在 `1-78` 中报 `N` 个不重复数字。
4. 用户按数字翻牌并回传具体牌名（含正逆位）。
5. 记录 `seed + picked_numbers + revealed_cards`，再进入解读。

**最低输出标准**

- Decision Code（GO/HOLD/NO-GO）
- 至少 1 条触发条件与 1 条失效条件
- 下次复盘日期
- 抽牌元数据（seed/数字/牌面）完整

---

## 统一复盘模板

每次占断后，固定复盘：

1. 哪条建议被执行了？
2. 结果是否符合“趋势判断”？
3. 偏差来自时间、执行，还是问题定义？
4. 是否需要切换路径（A -> B）？
