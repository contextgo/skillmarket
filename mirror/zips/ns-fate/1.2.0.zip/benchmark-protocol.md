# NS Fate Benchmark Protocol

用于把 `ns-fate` 从“可用”提升为“高精度可验证系统”。

---

## 1) Benchmark 目标

统一比较不同来源、不同方法、不同时间窗的真实表现，输出：

- 命中率（Hit Rate）
- 偏差率（Miss Rate）
- 可执行率（Actionability）
- 稳定性（Volatility）

---

## 2) 测试集设计

每月固定生成 30 个测试问题，按场景均匀分布：

- 职业/财务: 10
- 关系/沟通: 10
- 择时/节点: 10

每题必须包含：

- 时间窗（7/30/90天之一）
- 可检验指标（是否发生 + 发生强度）
- 触发条件与失效条件

---

## 3) 对照组设计

每条预测都要有对照组：

1. **Method Group A**: Astrology + Calendar
2. **Method Group B**: Tarot + Symbolic
3. **Method Group C**: A + B 融合

目标是验证：融合是否显著优于单体系。

---

## 4) 评分指标

### 4.1 Primary Metrics

- `hit_rate = hits / total_testable_predictions`
- `miss_rate = misses / total_testable_predictions`
- `actionability = actionable_predictions / total_predictions`

### 4.2 Calibration Metrics（新增）

为概率化结论（例如“60%-70%”）加入校准指标：

- **Brier Score**（越低越好）  
  `BS = (1/N) * Σ (p_i - o_i)^2`  
  其中 `p_i` 为预测概率，`o_i` 为实际结果（0/1）。

- **Log Score / Log Loss**（越低越好）  
  `LL = -(1/N) * Σ [o_i*ln(p_i) + (1-o_i)*ln(1-p_i)]`

说明：

- Brier 对整体偏差敏感，适合周/月追踪
- Log Loss 对“过度自信但错判”惩罚更大

### 4.3 Weighted Accuracy

`weighted_accuracy = 0.55*hit_rate + 0.30*actionability - 0.15*miss_rate`

### 4.4 Calibration-Adjusted Accuracy（新增）

将命中率与校准同时考虑：

`calibrated_accuracy = 0.45*weighted_accuracy + 0.30*(1-BS) + 0.25*(1-normalized_LL)`

其中 `normalized_LL` 建议按近12周历史分布做 min-max 归一化。

### 4.5 Stability Index

`stability_index = 1 / (1 + stdev(weekly_score_last_8))`

取值越接近 1 越稳定。

### 4.6 Outside View / Reference Class（新增）

每条预测必须附一个“参考类基线概率”（outside view）：

- 先估计同类事件历史基线 `base_rate`
- 再给个案修正后的 `adjusted_prob`
- 记录 `delta = adjusted_prob - base_rate`

若 `|delta| > 0.35`，必须写出至少两条强证据；否则降级置信度。

---

## 5) 显著性门槛（升级条件）

若要把某方法/来源升级到核心：

1. 至少 8 周有效样本
2. `calibrated_accuracy >= 0.60`
3. `BS <= 0.23`（二元事件场景）
4. `stability_index >= 0.45`
5. 且在 2 个以上场景分组中达标

任一条件不达标，不升级。

---

## 6) 回归检测（防“突然失准”）

每周执行：

- 若本周 `calibrated_accuracy` 比 4 周均值低 0.15 以上，标记 `Regression Alert`
- 连续两周告警，自动降级一个级别
- 连续四周告警，移出核心名单

---

## 7) 输出格式（每月）

```markdown
# NS Fate Monthly Benchmark - [YYYY-MM]

## Top Sources
- [Name]: calibrated_accuracy=0.xx, BS=0.xx, stability=0.xx

## By Scenario
- Career:
- Relationship:
- Timing:

## Regression Alerts
- [Name] - reason

## Promote / Demote Decisions
- Promote:
- Demote:
- Watchlist:
```

---

## 8) 执行频率

- 每周：更新单条命中数据、滚动分数、波动惩罚
- 每月：跑完整 benchmark，执行升降级
- 每季度：重构候选池（替换低质量来源）
