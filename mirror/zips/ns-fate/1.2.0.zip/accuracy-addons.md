# NS Fate Accuracy Add-ons

本文件汇总“网上可借鉴、对准确度有实质提升”的增量模块。  
这些模块不是玄学内容，而是预测科学中的通用增益机制。

---

## 1) Probability Calibration（概率校准）

### Why

只看命中率会误导。  
一个总给 51% 的系统可能命中不差，但信息价值低。

### Add

- Brier Score（整体校准）
- Log Loss（惩罚过度自信错判）
- 校准分箱图（预测 60% 的事件，是否真有约 60% 发生）

---

## 2) Reference Class Forecasting（参考类预测）

### Why

个案判断容易过度乐观。  
先看同类事件基线概率（outside view），再做个案修正更稳。

### Add

- 每条预测记录 `base_rate` 与 `adjusted_prob`
- 若偏离基线超过阈值（如 0.35），必须给强证据

---

## 3) Strict Pre-registration（严格预注册）

### Why

避免“马后炮重解释”导致虚高命中率。

### Add

- 预测创建后锁定四字段：Claim / Trigger / Invalid / Review Date
- 任何改动自动作废该条记录

---

## 4) Blind Outcome Review（盲评复盘）

### Why

减少“我主观觉得算命中了”的偏差。

### Add

- 复盘时先隐藏来源名称，仅看预测文本与结果证据
- 由规则先判 Hit/Partial/Miss，再揭示来源

---

## 5) Horizon-specific Models（分时间窗建模）

### Why

7天、30天、90天的信号性质不同，混算会拉低精度。

### Add

- 三套独立分数：`score_7d` / `score_30d` / `score_90d`
- 调用时按用户请求窗口取对应模型

---

## 6) Prediction-Market Prior（市场先验）

### Why

预测市场在校准上通常表现稳定，可作为对照先验。

### Add

- 重要事件先给“市场先验概率区间”
- 再叠加占星/塔罗/历法修正
- 若修正幅度过大，自动触发审计

---

## 7) Anti-vagueness Grammar（反模糊语法）

### Why

模糊语言会制造“看起来都对”的假准度。

### Add

- 禁用词与替代语法清单
- 句子必须包含：动作 + 时间 + 条件 + 可观察结果

---

## 8) Fail-tag Analytics（失败标签分析）

### Why

不分析失败原因，就无法系统提准。

### Add

- 统一失败标签（T1-T5）
- 每月统计 top2 失败来源并修规则

---

## 9) 推荐优先实施顺序

1. 预注册锁定（立刻）
2. Brier + Log Loss（立刻）
3. 参考类基线（本周）
4. 盲评复盘（本周）
5. 分时间窗模型（本月）
6. 市场先验与审计（进阶）
