# 数据结构定义

本文档定义了读书辅助工具使用的所有数据结构。

## 目录

- [书籍档案结构](#书籍档案结构)
- [摘录数据结构](#摘录数据结构)
- [当前在读信息](#当前在读信息)
- [完整示例](#完整示例)

## 书籍档案结构

每本书的档案存储在独立的 JSON 文件中，路径为 `./reading-notes/books/{书名}.json`。

### 数据模型

```json
{
  "book_info": {
    "title": "string (必需) - 书名",
    "author": "string (可选) - 作者",
    "status": "string (必需) - 阅读状态：reading | completed | archived",
    "reading_stage": "string (必需) - 阅读阶段：inspection | interpretation | output",
    "created_at": "string (必需) - 创建日期，格式：YYYY-MM-DD",
    "completed_at": "string (可选) - 完成日期，格式：YYYY-MM-DD",
    "tags": "array (可选) - 书籍级别的标签",
    "cover": "string (可选) - 封面图片URL或路径",
    "total_chapters": "number (可选) - 总章节数"
  },
  "inspection_questions": [
    {
      "id": "string (必需) - 问题唯一标识",
      "question": "string (必需) - 问题内容",
      "user_answer": "string (可选) - 用户回答",
      "system_answer": "string (可选) - 系统辅助回答",
      "answered": "boolean (必需) - 是否已回答",
      "answered_at": "string (可选) - 回答时间，格式：YYYY-MM-DD HH:MM:SS"
    }
  ],
  "excerpts": [
    {
      "id": "string (必需) - 摘录唯一标识",
      "content": "string (必需) - 摘录原文内容",
      "summary": "string (可选) - 智能摘要（超过300字时生成）",
      "chapter": "string (可选) - 章节信息",
      "tags": "array (可选) - 关键词标签",
      "deep_meaning": "string (可选) - 深层含义分析",
      "application": "string (可选) - 应用建议",
      "related_questions": "array (可选) - 关联提问列表",
      "created_at": "string (必需) - 创建时间，格式：YYYY-MM-DD HH:MM:SS",
      "source": "string (可选) - 来源：wechat | kindle | manual",
      "page": "number (可选) - 页码",
      "note": "string (可选) - 用户添加的笔记"
    }
  ],
  "reading_output": {
    "summary": "string (可选) - 核心观点总结",
    "applications": "array (可选) - 应用场景列表",
    "knowledge_connections": "array (可选) - 知识关联列表",
    "created_at": "string (可选) - 输出创建时间，格式：YYYY-MM-DD HH:MM:SS"
  }
}
```

### 字段说明

#### book_info 对象

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| title | string | 是 | 书名，作为文件名的一部分 |
| author | string | 否 | 作者姓名 |
| status | string | 是 | 阅读状态：reading（在读）、completed（已完成）、archived（已归档） |
| reading_stage | string | 是 | 阅读阶段：inspection（检视阅读）、interpretation（诠释阅读）、output（阅读输出） |
| created_at | string | 是 | 创建日期，格式：YYYY-MM-DD |
| completed_at | string | 否 | 完成日期，格式：YYYY-MM-DD |
| tags | array | 否 | 书籍级别的标签，如 ["儒家思想", "古典文学"] |
| cover | string | 否 | 封面图片URL或本地路径 |
| total_chapters | number | 否 | 总章节数 |

#### inspection_questions 数组元素

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| id | string | 是 | 问题唯一标识，格式：qst_YYYYMMDDHHMMSS_序号 |
| question | string | 是 | 问题内容，由智能体在检视阅读阶段生成 |
| user_answer | string | 否 | 用户回答 |
| system_answer | string | 否 | 系统辅助回答，基于书籍内容生成 |
| answered | boolean | 是 | 是否已回答 |
| answered_at | string | 否 | 回答时间，格式：YYYY-MM-DD HH:MM:SS |

#### excerpts 数组元素

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| id | string | 是 | 摘录唯一标识，格式：exc_YYYYMMDDHHMMSS_序号 |
| content | string | 是 | 摘录原文内容 |
| summary | string | 否 | 智能摘要，超过300字时自动生成100字以内摘要 |
| chapter | string | 否 | 章节信息，如"第1章"、"Chapter 1" |
| tags | array | 否 | 关键词标签，如 ["仁", "礼", "中庸"] |
| deep_meaning | string | 否 | 深层含义分析，由智能体生成 |
| application | string | 否 | 应用建议，由智能体生成 |
| related_questions | array | 否 | 关联提问列表，在诠释阅读阶段触发 |
| created_at | string | 是 | 创建时间，格式：YYYY-MM-DD HH:MM:SS |
| source | string | 否 | 来源：wechat、kindle、manual |
| page | number | 否 | 页码 |
| note | string | 否 | 用户添加的个人笔记 |

#### reading_output 对象

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| summary | string | 否 | 核心观点总结，300字以上 |
| applications | array | 否 | 应用场景列表 |
| knowledge_connections | array | 否 | 知识关联列表 |
| created_at | string | 否 | 输出创建时间，格式：YYYY-MM-DD HH:MM:SS |

## 当前在读信息

`current.json` 文件记录当前正在阅读的书籍，方便快速切换。

### 数据模型

```json
{
  "current_book": "string - 当前在读的书名",
  "updated_at": "string - 更新时间，格式：YYYY-MM-DD HH:MM:SS"
}
```

### 示例

```json
{
  "current_book": "论语",
  "updated_at": "2024-01-15 10:30:00"
}
```

## 完整示例

### 书籍档案示例（以《论语》为例）

```json
{
  "book_info": {
    "title": "论语",
    "author": "孔子及其弟子",
    "status": "reading",
    "reading_stage": "inspection",
    "created_at": "2024-01-01",
    "tags": ["儒家思想", "古典文学", "哲学经典"],
    "total_chapters": 20
  },
  "inspection_questions": [
    {
      "id": "qst_20240101100000_0",
      "question": "《论语》的核心思想'仁'在不同语境下有哪些不同含义？",
      "user_answer": null,
      "system_answer": null,
      "answered": false
    },
    {
      "id": "qst_20240101100000_1",
      "question": "孔子的教育理念'有教无类'在当代社会有何现实意义？",
      "user_answer": "打破了阶级限制，让每个人都有受教育的权利，这对现代教育公平很有启发。",
      "system_answer": null,
      "answered": true,
      "answered_at": "2024-01-05 14:30:00"
    }
  ],
  "excerpts": [
    {
      "id": "exc_20240101100000_0",
      "content": "子曰：'学而时习之，不亦说乎？有朋自远方来，不亦乐乎？人不知而不愠，不亦君子乎？'",
      "summary": "孔子提出学习、交友和为人处世的三个境界。",
      "chapter": "学而第一",
      "tags": ["学习", "交友", "君子"],
      "deep_meaning": "孔子提出了学习、交友和为人处世的三个境界。学习要注重实践，交友要珍惜远方来的朋友，做人要达到'不愠'的境界。",
      "application": "在学习中要注重实践和应用，珍惜志同道合的朋友，修炼自己的心胸和修养。",
      "related_questions": ["孔子为什么将学习放在第一位？", "'不愠'的修养如何培养？"],
      "created_at": "2024-01-01 10:00:00",
      "source": "manual"
    }
  ],
  "reading_output": null
}
```

## 阅读阶段说明

### 检视阅读（inspection）
- **目标**：快速了解书籍概览，把握核心框架
- **时长**：10-15分钟
- **产出**：
  - 书籍概览（核心观点、章节框架、作者思想）
  - 5个关键问题（用户可回答或跳过）
- **触发**：创建书籍档案时自动进入

### 诠释阅读（interpretation）
- **目标**：深度理解内容，建立知识关联
- **时长**：贯穿整个阅读过程
- **产出**：
  - 交互式笔记（关联提问、观点验证、对比阅读）
  - 章节复盘（核心观点、疑问清单、主题关联）
- **触发**：记录摘录时自动触发

### 阅读输出（output）
- **目标**：知识转化，形成个人见解
- **时长**：完成阅读后
- **产出**：
  - 核心观点总结（300字以上）
  - 应用场景设计
  - 知识关联列表
- **触发**：标记书籍为"已完成"时自动进入

## 数据验证规则

### 书籍名称

- 不能包含特殊字符：`\ / : * ? " < > |`
- 长度限制：1-100 字符

### 摘录 ID

- 格式：`exc_YYYYMMDDHHMMSS_序号`

### 问题 ID

- 格式：`qst_YYYYMMDDHHMMSS_序号`

### 时间格式

- 日期：`YYYY-MM-DD`
- 时间：`YYYY-MM-DD HH:MM:SS`

### 状态值

- `reading`：在读
- `completed`：已完成
- `archived`：已归档

### 阅读阶段值

- `inspection`：检视阅读
- `interpretation`：诠释阅读
- `output`：阅读输出

## 版本兼容性

### v2.0 向下兼容

- v1.0 版本的书籍档案自动升级
- 自动添加 `reading_stage` 字段（默认为 `inspection`）
- 自动生成 `inspection_questions`（对于已完成的书籍）

### 迁移规则

- 对于 v1.0 已完成的书籍，系统自动生成检视阅读问题并提示用户补充回答
- 所有现有摘录保留不变
- 新增字段使用默认值
