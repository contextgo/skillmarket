#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文档解析脚本
支持 EPUB、PDF、DOCX 格式的文档解析
输出结构化的 JSON 格式数据，支持逐章节解析
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional

try:
    from ebooklib import epub
    from bs4 import BeautifulSoup
except ImportError:
    print("错误：缺少依赖库，请安装：pip install ebooklib beautifulsoup4", file=sys.stderr)
    sys.exit(1)

try:
    from pypdf import PdfReader
except ImportError:
    print("错误：缺少依赖库，请安装：pip install pypdf", file=sys.stderr)
    sys.exit(1)

try:
    from docx import Document
except ImportError:
    print("错误：缺少依赖库，请安装：pip install python-docx", file=sys.stderr)
    sys.exit(1)


class DocumentParser:
    """文档解析器基类"""
    
    def __init__(self, file_path: str):
        self.file_path = Path(file_path)
        if not self.file_path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")
    
    def parse(self, section_numbers: Optional[List[int]] = None) -> Dict:
        """解析文档，返回结构化数据"""
        raise NotImplementedError


class EpubParser(DocumentParser):
    """EPUB格式解析器"""
    
    def parse(self, section_numbers: Optional[List[int]] = None) -> Dict:
        """解析EPUB文件"""
        try:
            book = epub.read_epub(str(self.file_path))
        except Exception as e:
            raise Exception(f"EPUB解析失败: {str(e)}")
        
        # 提取书籍元数据
        metadata = {
            "document_title": self._get_metadata(book, 'title') or self.file_path.stem,
            "author": self._get_metadata(book, 'creator') or "未知作者",
            "format": "epub",
            "total_sections": 0,
            "sections": []
        }
        
        # 提取章节内容
        sections = []
        section_idx = 1
        
        for item in book.get_items():
            if item.get_type() == 9:  # ITEM_DOCUMENT
                # 检查是否需要解析该章节
                if section_numbers and section_idx not in section_numbers:
                    section_idx += 1
                    continue
                
                # 解析HTML内容
                soup = BeautifulSoup(item.get_content(), 'html.parser')
                
                # 提取章节标题
                title = self._extract_title(soup, section_idx)
                
                # 提取正文内容
                content = self._extract_content(soup)
                
                # 只保留有实际内容的章节
                if content.strip():
                    sections.append({
                        "number": section_idx,
                        "title": title,
                        "content": content
                    })
                
                section_idx += 1
        
        metadata["total_sections"] = len(sections)
        metadata["sections"] = sections
        
        return metadata
    
    def _get_metadata(self, book, field: str) -> Optional[str]:
        """提取元数据"""
        try:
            metadata = book.get_metadata('DC', field)
            if metadata and len(metadata) > 0:
                return metadata[0][0]
        except:
            pass
        return None
    
    def _extract_title(self, soup, section_idx: int) -> str:
        """提取章节标题"""
        # 尝试从标题标签提取
        for tag in ['h1', 'h2', 'h3', 'h4']:
            title_tag = soup.find(tag)
            if title_tag:
                return title_tag.get_text().strip()
        
        # 如果没有标题标签，返回默认标题
        return f"第{section_idx}章"
    
    def _extract_content(self, soup) -> str:
        """提取正文内容"""
        # 移除脚本和样式标签
        for script in soup(["script", "style"]):
            script.decompose()
        
        # 提取文本
        text = soup.get_text()
        
        # 清理文本
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = '\n'.join(chunk for chunk in chunks if chunk)
        
        return text


class PdfParser(DocumentParser):
    """PDF格式解析器"""
    
    def parse(self, section_numbers: Optional[List[int]] = None) -> Dict:
        """解析PDF文件"""
        try:
            reader = PdfReader(str(self.file_path))
        except Exception as e:
            raise Exception(f"PDF解析失败: {str(e)}")
        
        metadata = {
            "document_title": self._get_title(reader) or self.file_path.stem,
            "author": self._get_author(reader) or "未知作者",
            "format": "pdf",
            "total_sections": 0,
            "sections": []
        }
        
        # PDF按页处理，每页作为一个"章节"
        sections = []
        total_pages = len(reader.pages)
        
        # 如果指定了章节编号，转换为页码范围
        if section_numbers:
            page_indices = [pn - 1 for pn in section_numbers if 0 < pn <= total_pages]
        else:
            page_indices = range(total_pages)
        
        for page_num in page_indices:
            page = reader.pages[page_num]
            content = page.extract_text()
            
            if content and content.strip():
                sections.append({
                    "number": page_num + 1,
                    "title": f"第{page_num + 1}页",
                    "content": content.strip()
                })
        
        metadata["total_sections"] = len(sections)
        metadata["sections"] = sections
        
        return metadata
    
    def _get_title(self, reader) -> Optional[str]:
        """提取PDF标题"""
        try:
            if reader.metadata and reader.metadata.title:
                return reader.metadata.title
        except:
            pass
        return None
    
    def _get_author(self, reader) -> Optional[str]:
        """提取PDF作者"""
        try:
            if reader.metadata and reader.metadata.author:
                return reader.metadata.author
        except:
            pass
        return None


class DocxParser(DocumentParser):
    """DOCX格式解析器"""
    
    def parse(self, section_numbers: Optional[List[int]] = None) -> Dict:
        """解析DOCX文件"""
        try:
            doc = Document(str(self.file_path))
        except Exception as e:
            raise Exception(f"DOCX解析失败: {str(e)}")
        
        # 提取文档元数据
        metadata = {
            "document_title": doc.core_properties.title or self.file_path.stem,
            "author": doc.core_properties.author or "未知作者",
            "format": "docx",
            "total_sections": 0,
            "sections": []
        }
        
        # 提取段落内容，按标题分段
        sections = []
        current_section = {
            "number": 0,
            "title": "",
            "content": ""
        }
        section_idx = 0
        
        for para in doc.paragraphs:
            # 判断是否为标题段落
            if para.style.name.startswith('Heading'):
                # 保存上一个section（如果有内容）
                if current_section["number"] > 0 and current_section["content"].strip():
                    sections.append(current_section.copy())
                
                # 检查是否需要解析该章节
                section_idx += 1
                if section_numbers and section_idx not in section_numbers:
                    current_section["number"] = section_idx
                    current_section["title"] = para.text.strip()
                    current_section["content"] = ""
                    continue
                
                # 开始新section
                current_section = {
                    "number": section_idx,
                    "title": para.text.strip(),
                    "content": ""
                }
            else:
                # 普通段落内容
                if section_numbers and current_section["number"] > 0 and current_section["number"] not in section_numbers:
                    continue
                
                text = para.text.strip()
                if text:
                    if current_section["content"]:
                        current_section["content"] += "\n\n"
                    current_section["content"] += text
        
        # 保存最后一个section
        if current_section["number"] > 0 and current_section["content"].strip():
            sections.append(current_section)
        
        metadata["total_sections"] = len(sections)
        metadata["sections"] = sections
        
        return metadata


def detect_format(file_path: str) -> str:
    """检测文档格式"""
    path = Path(file_path)
    ext = path.suffix.lower()
    
    if ext == '.epub':
        return 'epub'
    elif ext == '.pdf':
        return 'pdf'
    elif ext in ['.doc', '.docx']:
        return 'docx'
    else:
        raise ValueError(f"不支持的文件格式: {ext}，仅支持 .epub、.pdf 和 .docx 格式")


def parse_document(input_path: str, section_numbers: Optional[List[int]] = None) -> Dict:
    """解析文档主函数"""
    # 检测格式
    format_type = detect_format(input_path)
    
    # 选择解析器
    if format_type == 'epub':
        parser = EpubParser(input_path)
    elif format_type == 'pdf':
        parser = PdfParser(input_path)
    elif format_type == 'docx':
        parser = DocxParser(input_path)
    else:
        raise ValueError(f"不支持的格式: {format_type}")
    
    # 执行解析
    return parser.parse(section_numbers)


def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(
        description='文档解析工具 - 支持EPUB、PDF、DOCX格式',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  # 解析整本书
  python document_parser.py --input book.epub
  
  # 解析指定章节
  python document_parser.py --input book.docx --section 1 2 3
  
  # 输出到文件
  python document_parser.py --input book.pdf --output result.json
        '''
    )
    
    parser.add_argument(
        '--input', '-i',
        required=True,
        help='文档文件路径（支持.epub、.pdf、.docx格式）'
    )
    
    parser.add_argument(
        '--output', '-o',
        help='输出JSON文件路径（默认输出到标准输出）'
    )
    
    parser.add_argument(
        '--section', '-s',
        type=int,
        nargs='+',
        help='指定要解析的章节编号（可指定多个，如：--section 1 2 3）'
    )
    
    args = parser.parse_args()
    
    try:
        # 解析文档
        result = parse_document(args.input, args.section)
        
        # 输出结果
        json_output = json.dumps(result, ensure_ascii=False, indent=2)
        
        if args.output:
            # 写入文件
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(json_output)
            print(f"解析完成，结果已保存到: {args.output}", file=sys.stderr)
        else:
            # 输出到标准输出
            print(json_output)
            
    except FileNotFoundError as e:
        print(f"错误: {str(e)}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"错误: {str(e)}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"解析失败: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
