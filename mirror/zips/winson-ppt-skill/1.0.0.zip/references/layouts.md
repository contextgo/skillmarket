# 八大内容版式布局库（Layouts）

本文档收录 8 种核心页面布局骨架（Layout 0-7），加 2 种结构页（幕封 + 金句页）。每种都是一个完整可粘贴的 `<section class="slide ...">...</section>` 代码块，直接替换文案/图片即可使用。

**核心原则**：常用版式按人脑可理解的习惯设计，无法抽象提炼则页面存在问题。

---

## ⚠️ 生成前必读（Pre-flight）

### A. 类名必须来自 template.html

layouts.md 使用的所有类（`h-hero` / `h-xl` / `h-sub` / `slide-title` / `slide-subtitle` / `kicker` / `meta-row` / `data-table` / `data-row` / `data-cell` / `data-header` / `stat-card` / `stat-label` / `stat-nb` / `stat-unit` / `stat-note` / `pipeline-section` / `pipeline-label` / `pipeline` / `step` / `step-nb` / `step-title` / `step-desc` / `grid-2` / `grid-3` / `grid-4` / `grid-6` / `frame` / `frame-img` / `img-cap` / `callout` / `callout-src` / `vs-block` / `vs-label` / `logic-flow` / `logic-step` / `logic-arrow` / `chrome` / `foot` / `cover-client` / `cover-rule` / `hi` / `bar-chart` / `bar-group` / `bar` / `bar-theme` / `bar-accent` / `bar-value` / `bar-label` / `hbar-chart` / `hbar-row` / `hbar-label` / `hbar-track` / `hbar` / `hbar-positive` / `hbar-negative` / `hbar-warning` / `hbar-value` / `donut-chart` / `donut-svg` / `donut-legend` / `donut-legend-item` / `donut-legend-dot` / `donut-legend-label` / `donut-legend-value` / `timeline` / `tl-item` / `tl-dot` / `tl-dot-inner` / `tl-dot-ghost` / `tl-content` / `tl-date` / `tl-title` / `tl-desc` / `bleed-img` / `bleed-overlay` / `bleed-content`）都在 `assets/template.html` 的 `<style>` 块里预定义。

**不要发明新类名**。如果必须自定义，用 `style="..."` inline 写。生成前若不确定某个类是否存在，grep template.html 确认。

### A2. 动效标记 `data-anim`

每个 slide 内需要入场动效的元素加 `data-anim` 属性。Motion One 按 DOM 顺序逐元素 60ms 间隔入场（280ms 快入，`cubic-bezier(.22,.01,0,1)` 冷曲线）。**不要给 chrome/foot 加 data-anim**——它们是导航骨架，不应动。

### B. 版式选择理论

**核心公式**：`版式选择 = f(内容, 思维, 见识, 状态, 交付标准) + 误差项`

**关键洞察**：
- 页面观点决定内容
- 但观点**不直接决定**版式选择
- 同一Message可对应版式A/B/C
- 版式选择受困于：内容、思维、见识/存量、状态、交付标准

**版式选择决策树**：

```
这一页的观点需要什么来支撑？
│
├── 单一模块即可支撑
│   ├── 需要展示空间/多维信息 → Layout 1(图片) 或 Layout 2(表格)
│   └── 需要突出单一发现/结构 → Layout 3(数据大字报) 或 Layout 4(图示)
│
└── 需要多模块支撑
    ├── 多个并列论据 → Layout 5(并列支撑)
    ├── 两个对立面 → Layout 6(二元对立)
    └── 有逻辑关系 → Layout 7(逻辑推导)
        ├── 推理：因→果
        ├── 递进：浅→深
        ├── 分析：现象→本质
        ├── 归纳：具体→一般
        ├── 拆解：整体→局部
        └── 时序对比：前→后
```

### C. 配色节奏规划

**核心机制**：每页 `<section>` 必须带 `light` 或 `dark` 主题。JS 根据 class 推断主题，切换背景。

#### 按布局的主题默认值

| Layout | 默认主题 | 原因 |
|---|---|---|
| 1. 多维信息→图片 | `light` | 图片需亮底清晰展示 |
| 2. 多维信息→表格 | `light` | 表格需亮底保证可读 |
| 3. 关键发现→数据大字报 | `light` | 数据大字报需亮底突出数据 |
| 4. 关键结构→图示 | `light` | 图示需清晰 |
| 5. 并列支撑 | `light` | 多列需清晰 |
| 6. 二元对立 | `light` | 对比需清晰 |
| 7. 逻辑推导 | `light` | 流程需清晰 |

**商业PPT以light为主**，dark用于封面、章节幕封、金句页制造节奏。

#### 节奏硬规则

- ❌ **禁止**连续3页以上相同主题
- ❌ **禁止**8页以上的PPT没有至少1个dark页
- ✅ **推荐**每4-5页插入1个dark页（封面/幕封/金句）
- ✅ **推荐**数据密集页用light，观点总结页可用dark

---

## 0. 基础结构（所有 slide 都一样）

```html
<section class="slide [light|dark]">
  <div class="chrome">
    <div>章节标签 · 子标签</div>
    <div>页号 / 总页数</div>
  </div>
  <!-- 主内容 -->
  <div class="foot">
    <div>页码说明</div>
    <div>[项目代号] · [数据来源/日期]</div>
  </div>
</section>
```

- 正文页建议加 `light`；封面/幕封/金句页加 `dark`
- `chrome` 和 `foot` 是可选但推荐保留的上下左右四角元数据

### chrome 和 kicker 不要写同一句话

| 位置 | 角色 | 内容性质 | 例子 |
|------|------|---------|------|
| `.chrome` 左上 | **导航元数据** | 稳定的"栏目名"，跨多页可相同 | "市场分析 · Market" / "Phase 01 · 诊断" |
| `.chrome` 右上 | **页号** | 固定格式 | "03 / 20" |
| `.kicker` | **本页独一份的引导句** | 是标题的"小前缀"，每页都应不同 | "Finding 01 · 核心发现" / "Framework · 关键结构" / "Analysis · 逻辑推导" |

### foot 元数据规范

| 位置 | 角色 | 内容性质 | 例子 |
|------|------|---------|------|
| `.foot` 左侧 | **页级说明** | 本页内容的简要归类 | "核心数据 · FY2025" / "竞品分析" |
| `.foot` 右侧 | **溯源信息** | 项目代号 + 数据来源/日期 | "PRJ-001 · 数据截至2025Q4" / "PRJ-001 · 2026.05" |

**foot右侧禁止使用无意义装饰**（如 `— · —`）。每一页的foot右侧必须是可溯源的信息：项目代号、数据截止日期、或来源标注。

### kicker 编号规范

kicker应采用**结构化编号**，而非泛化标签：

| ❌ 不够商业化 | ✅ 商业化编号 |
|-------------|-------------|
| 核心发现 | Finding 01 · 核心发现 |
| 关键结构 | Framework · 关键结构 |
| 逻辑推导 | Analysis · 逻辑推导 |
| 并列支撑 | Evidence · 并列支撑 |
| 二元对立 | Comparison · 二元对立 |
| 多维对比 | Matrix · 多维对比 |

**规则**：kicker = `[英文分类词] · [中文说明]`，英文分类词全篇统一。

---

## Cover: 封面页（Cover Page）

**适用**：PPT首页，必须为 `dark` 主题

**设计逻辑**：咨询公司封面惯例——内容左下对齐，而非居中。上方留白制造呼吸感，下方结构化信息传递专业严谨。

```html
<section class="slide dark active">
  <div class="chrome">
    <div>[项目代号] · [客户名称]</div>
    <div>01 / 12</div>
  </div>
  <div class="frame" style="display:grid;gap:0;align-content:end;min-height:80vh;padding-bottom:8vh">
    <div class="cover-client">[客户名称 / 项目代号]</div>
    <div class="cover-rule"></div>
    <h1 class="h-hero" style="font-size:3.6vw" data-anim>[主标题：核心观点]</h1>
    <h2 class="slide-subtitle" style="font-size:1.4vw;color:rgba(255,255,255,.45)" data-anim>[副标题：补充说明与关键定语]</h2>
    <div class="meta-row" style="margin-top:3vh" data-anim>
      <span>[汇报场景]</span><span>·</span><span>[日期]</span><span>·</span><span>[版本]</span>
    </div>
  </div>
  <div class="foot">
    <div>[内容主题标签]</div>
    <div>[项目代号] · [日期]</div>
  </div>
</section>
```

**要点**：
- `align-content:end` 将内容推至页面下方——这是咨询公司封面的标准布局
- `.cover-client` 用等宽字体+大写+宽字距，传递项目标识的正式感
- `.cover-rule` 是4vw宽的主题色细线，分隔客户标识与标题
- 主标题字号 `3.6vw`（比正文页的 `3.2vw` 略大），但不过度放大
- 副标题字号 `1.4vw`，颜色降至50%透明度，制造层级
- `meta-row` 包含三个结构化字段：汇报场景 · 日期 · 版本
- `foot` 左侧标注**内容主题标签**（非固定"机密"），右侧标注项目代号+日期
- **禁止**使用 `kicker`（封面不需要章节标签）

### 封面必填字段

| 字段 | 位置 | 格式 | 例子 |
|------|------|------|------|
| 项目代号 | chrome左 + foot右 | 大写字母-数字 | "STR-2026-001" |
| 客户名称 | chrome左 + cover-client | 全称 | "XX集团" |
| 主标题 | slide-title | 观点驱动 | "增长瓶颈在产品差异化，不在获客" |
| 副标题 | slide-subtitle | 补充定语 | "从增长到高质量增长的关键跃迁" |
| 汇报场景 | meta-row第1项 | 场景名 | "董事会汇报" / "管理层工作会" |
| 日期 | meta-row第2项 | YYYY.MM | "2026.05" |
| 内容主题标签 | foot左 | 主题性标签 | "战略规划" / "市场研究" / "年度复盘" |
| 版本 | meta-row第3项 | V+数字 | "V1.0" / "V2.3-Draft" |

---

## Section Divider: 幕封页（章节分隔）

**适用**：章节开头 / 每4-5页内容后插入 / 15页以上PPT必须有

**设计逻辑**：幕封是PPT的呼吸。连续5页数据轰炸后，读者需要一次"认知重置"——幕封就是那个深呼吸。它不是装饰，是节奏的骨架。

```html
<section class="slide dark">
  <div class="chrome">
    <div>[项目代号]</div>
    <div>05 / 20</div>
  </div>
  <div class="frame" style="display:grid;gap:3vh;align-content:center;min-height:80vh">
    <div class="kicker" data-anim>Phase 02 · [章节英文标签]</div>
    <h1 class="h-hero" style="font-size:3.2vw" data-anim>[章节标题：该章节的核心观点]</h1>
    <p class="slide-subtitle" style="color:rgba(255,255,255,.4);max-width:55vw" data-anim>[一句话概括本章节要回答的问题]</p>
  </div>
  <div class="foot">
    <div>[内容主题标签]</div>
    <div>[项目代号] · [日期]</div>
  </div>
</section>
```

**要点**：
- 幕封必须 `dark`，与前后 `light` 内容页形成节奏
- kicker 用 `Phase XX` 或 `Chapter XX` 编号，与封面 kicker 区分
- 标题不是章节名，是**该章节的核心观点**。❌ "市场分析" ✅ "市场已从增量转向存量竞争"
- 副标题是一句话问题，引导读者带着问题进入后续内容
- **禁止**使用 `cover-rule`（那是封面专属）
- **禁止**使用 `cover-client`（那是封面专属）

### 幕封插入规则

| PPT总页数 | 幕封数量 | 插入位置 |
|----------|---------|---------|
| ≤10页 | 0 | 不需要 |
| 11-15页 | 1 | 中段（约第5-6页） |
| 16-20页 | 2 | 三等分点 |
| 21-30页 | 3 | 四等分点 |

---

## Key Quote: 金句/结论页

**适用**：PPT最后一页 / 关键转折点 / 需要用一句话钉入读者记忆的时刻

**设计逻辑**：金句页是PPT的终审判决。前面所有数据和逻辑都是铺垫，这一页是锤子落下的声音。一个PPT只允许有1-2个金句页——多了就不金了。

```html
<section class="slide dark">
  <div class="chrome">
    <div>核心结论 · Key Takeaway</div>
    <div>20 / 20</div>
  </div>
  <div class="frame" style="display:grid;gap:6vh;align-content:center;min-height:80vh">
    <div class="kicker" data-anim>Conclusion · 核心结论</div>
    <h1 class="h-hero" style="font-size:2.8vw;line-height:1.4" data-anim>
      [核心结论：一句话，不超过20字]
    </h1>
    <p class="slide-subtitle" style="color:rgba(255,255,255,.4);max-width:60vw" data-anim>
      [结论的展开说明：为什么这个结论重要，它意味着什么]
    </p>
  </div>
  <div class="foot">
    <div>核心结论</div>
    <div>[项目代号] · [日期]</div>
  </div>
</section>
```

**要点**：
- 金句页必须 `dark`
- 标题不超过20字，否则不是金句，是段落
- 标题必须是**可独立传播的判断句**，不是描述句。❌ "产品差异化是关键" ✅ "增长的瓶颈不在获客，而在产品差异化"
- 副标题回答"So What"——这个结论对读者意味着什么
- 字号 `2.8vw` 比封面略小，比正文大——是"判决"而非"呐喊"
- **金句页不要放数据**——数据在前面已经放完了，这里只放判决

---

## Layout 0: 数据可视化→图表（Chart）

**适用**：需要用柱状图/条形图直观呈现数据对比和趋势的场景

**设计逻辑**：数字是刻度，图表是判决的形状。当数据需要"看见差距"而非"读出数字"时，用图表替代纯数字卡片。

### 0A. 竖向柱状图

```html
<section class="slide light">
  <div class="chrome">
    <div>[章节标签] · [子标签]</div>
    <div>XX / NN</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker" data-anim>[KICKER标签]</div>
    <h2 class="h-xl" data-anim>[页面观点：用数据揭示的判断]</h2>
    <p class="slide-subtitle" data-anim>[数据来源/时间范围]</p>
    <div class="bar-chart" style="margin-top:4vh" data-anim>
      <div class="bar-group">
        <div class="bar-value">87%</div>
        <div class="bar bar-theme" style="height:87%"></div>
        <div class="bar-label">缺乏观点</div>
      </div>
      <div class="bar-group">
        <div class="bar-value">73%</div>
        <div class="bar" style="height:73%"></div>
        <div class="bar-label">信息堆砌</div>
      </div>
      <div class="bar-group">
        <div class="bar-value">68%</div>
        <div class="bar" style="height:68%"></div>
        <div class="bar-label">配色混乱</div>
      </div>
      <div class="bar-group">
        <div class="bar-value">61%</div>
        <div class="bar" style="height:61%"></div>
        <div class="bar-label">版式随意</div>
      </div>
      <div class="bar-group">
        <div class="bar-value">55%</div>
        <div class="bar" style="height:55%"></div>
        <div class="bar-label">字体不当</div>
      </div>
      <div class="bar-group">
        <div class="bar-value">42%</div>
        <div class="bar" style="height:42%"></div>
        <div class="bar-label">动效过度</div>
      </div>
    </div>
  </div>
  <div class="foot">
    <div>[主题标签]</div>
    <div>[项目代号] · [数据来源]</div>
  </div>
</section>
```

**要点**：
- `.bar-chart` 是 flex 容器，子元素 `.bar-group` 自动等分
- `.bar` 的高度用 inline `style="height:XX%"` 控制，最大100%
- `.bar-theme` 用铁幕蓝标注重点柱，其余用 `--level-3` 灰
- `.bar-accent` 用强调蓝标注特殊柱
- 柱数建议 4-8 根，超过8根拆分多页
- **零圆角**：柱子是判决的形状，不是装饰

### 0B. 横向条形图

```html
<section class="slide light">
  <div class="chrome">
    <div>[章节标签] · [子标签]</div>
    <div>XX / NN</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker" data-anim>[KICKER标签]</div>
    <h2 class="h-xl" data-anim>[页面观点]</h2>
    <p class="slide-subtitle" data-anim>[补充说明]</p>
    <div class="hbar-chart" style="margin-top:4vh" data-anim>
      <div class="hbar-row">
        <div class="hbar-label">华东区</div>
        <div class="hbar-track"><div class="hbar hbar-positive" style="width:87%"></div></div>
        <div class="hbar-value">87%</div>
      </div>
      <div class="hbar-row">
        <div class="hbar-label">华南区</div>
        <div class="hbar-track"><div class="hbar hbar-positive" style="width:72%"></div></div>
        <div class="hbar-value">72%</div>
      </div>
      <div class="hbar-row">
        <div class="hbar-label">华北区</div>
        <div class="hbar-track"><div class="hbar" style="width:65%"></div></div>
        <div class="hbar-value">65%</div>
      </div>
      <div class="hbar-row">
        <div class="hbar-label">西南区</div>
        <div class="hbar-track"><div class="hbar hbar-warning" style="width:48%"></div></div>
        <div class="hbar-value">48%</div>
      </div>
      <div class="hbar-row">
        <div class="hbar-label">西北区</div>
        <div class="hbar-track"><div class="hbar hbar-negative" style="width:31%"></div></div>
        <div class="hbar-value">31%</div>
      </div>
    </div>
  </div>
  <div class="foot">
    <div>[主题标签]</div>
    <div>[项目代号] · [数据来源]</div>
  </div>
</section>
```

**要点**：
- `.hbar` 的宽度用 inline `style="width:XX%"` 控制
- `.hbar-positive` / `.hbar-negative` / `.hbar-warning` 对应强调色，不加则用铁幕蓝
- 条形数建议 4-7 行，超过7行拆分多页
- `.hbar-label` 固定 8vw 宽度，标签过长时调宽
- 横向条形图适合排名/进度/达标率，竖向柱状图适合对比/分布

### 0C. 图表+数据卡片混排

图表不必须独占一页。可以左半放图表，右半放 stat-card 数据卡片，用 `grid-2` 布局：

```html
<div class="grid-2" style="margin-top:4vh">
  <div data-anim>
    <!-- 柱状图或条形图 -->
  </div>
  <div data-anim>
    <div class="stat-card">...</div>
    <div class="stat-card" style="margin-top:2vh">...</div>
  </div>
</div>
```

---

### 0D. 环形图/饼图

**适用**：市场占有率 / 预算分配 / 构成比例 / 需要展示"部分占整体"的场景

```html
<section class="slide light">
  <div class="chrome">
    <div>[章节标签] · [子标签]</div>
    <div>XX / NN</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker" data-anim>Composition · 构成分析</div>
    <h2 class="h-xl" data-anim>[页面观点：用构成数据揭示的判断]</h2>
    <p class="slide-subtitle" data-anim>[数据来源/时间范围]</p>
    <div class="donut-chart" style="margin-top:4vh" data-anim>
      <svg class="donut-svg" viewBox="0 0 42 42">
        <circle cx="21" cy="21" r="15.91549431" fill="transparent" stroke="var(--level-3)" stroke-width="5" stroke-dasharray="0 100"/>
        <circle cx="21" cy="21" r="15.91549431" fill="transparent" stroke="var(--theme)" stroke-width="5" stroke-dasharray="42 58" stroke-dashoffset="25"/>
        <circle cx="21" cy="21" r="15.91549431" fill="transparent" stroke="var(--accent-positive)" stroke-width="5" stroke-dasharray="28 72" stroke-dashoffset="83"/>
        <circle cx="21" cy="21" r="15.91549431" fill="transparent" stroke="var(--accent-warning)" stroke-width="5" stroke-dasharray="18 82" stroke-dashoffset="55"/>
        <circle cx="21" cy="21" r="15.91549431" fill="transparent" stroke="var(--border)" stroke-width="5" stroke-dasharray="12 88" stroke-dashoffset="37"/>
      </svg>
      <div class="donut-legend">
        <div class="donut-legend-item">
          <div class="donut-legend-dot" style="background:var(--theme)"></div>
          <div class="donut-legend-label">产品A</div>
          <div class="donut-legend-value">42%</div>
        </div>
        <div class="donut-legend-item">
          <div class="donut-legend-dot" style="background:var(--accent-positive)"></div>
          <div class="donut-legend-label">产品B</div>
          <div class="donut-legend-value">28%</div>
        </div>
        <div class="donut-legend-item">
          <div class="donut-legend-dot" style="background:var(--accent-warning)"></div>
          <div class="donut-legend-label">产品C</div>
          <div class="donut-legend-value">18%</div>
        </div>
        <div class="donut-legend-item">
          <div class="donut-legend-dot" style="background:var(--border)"></div>
          <div class="donut-legend-label">其他</div>
          <div class="donut-legend-value">12%</div>
        </div>
      </div>
    </div>
  </div>
  <div class="foot">
    <div>[主题标签]</div>
    <div>[项目代号] · [数据来源]</div>
  </div>
</section>
```

**要点**：
- SVG 环形图用 `stroke-dasharray` + `stroke-dashoffset` 控制每段弧长
- 核心公式：`stroke-dasharray="占比 (100-占比)"`，`stroke-dashoffset` = 100 - 前面所有占比之和 + 25（起点从12点方向开始）
- 分段建议 3-5 段，超过5段拆分或合并"其他"
- 颜色优先用 `var(--theme)` 标注最大段，其余用强调色和灰
- 图例用 `.donut-legend` 右侧排列，与环形图水平对齐
- **零圆角**：图例圆点也是方形

---

### 0E. 时间轴（Timeline）

**适用**：项目里程碑 / 路线图 / 历史回顾 / 变革阶段

```html
<section class="slide light">
  <div class="chrome">
    <div>[章节标签] · [子标签]</div>
    <div>XX / NN</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker" data-anim>Milestone · 关键里程碑</div>
    <h2 class="h-xl" data-anim>[页面观点：时间轴揭示的判断]</h2>
    <p class="slide-subtitle" data-anim>[补充说明]</p>
    <div class="timeline" data-anim>
      <div class="tl-item">
        <div class="tl-dot"><div class="tl-dot-inner"></div></div>
        <div class="tl-content">
          <div class="tl-date">2026.Q1</div>
          <div class="tl-title">MVP上线</div>
          <div class="tl-desc">核心功能交付，种子客户验证</div>
        </div>
      </div>
      <div class="tl-item">
        <div class="tl-dot"><div class="tl-dot-inner"></div></div>
        <div class="tl-content">
          <div class="tl-date">2026.Q2</div>
          <div class="tl-title">规模化推广</div>
          <div class="tl-desc">3个BU全面铺开，目标覆盖80%业务线</div>
        </div>
      </div>
      <div class="tl-item">
        <div class="tl-dot"><div class="tl-dot-ghost"></div></div>
        <div class="tl-content">
          <div class="tl-date">2026.Q3</div>
          <div class="tl-title">生态建设</div>
          <div class="tl-desc">开放API，引入合作伙伴，构建数据网络效应</div>
        </div>
      </div>
      <div class="tl-item">
        <div class="tl-dot"><div class="tl-dot-ghost"></div></div>
        <div class="tl-content">
          <div class="tl-date">2026.Q4</div>
          <div class="tl-title">行业标杆</div>
          <div class="tl-desc">输出方法论，成为行业数字化转型的参考标准</div>
        </div>
      </div>
    </div>
  </div>
  <div class="foot">
    <div>[主题标签]</div>
    <div>[项目代号] · [数据来源]</div>
  </div>
</section>
```

**要点**：
- 已完成里程碑用 `.tl-dot-inner`（铁幕蓝实色），未完成用 `.tl-dot-ghost`（灰色）
- 时间轴左侧竖线用 `::before` 伪元素
- 建议每页 3-5 个节点，超过5个拆分多页
- 日期用等宽字体，标题用衬线字体——裁决式分工

---

### 0F. 全幅图片（Full Bleed Image）

**适用**：情绪冲击 / 愿景描绘 / 场景代入——一张图胜过千言万语

```html
<section class="slide dark">
  <div class="chrome" style="position:relative;z-index:3">
    <div>[章节标签] · [子标签]</div>
    <div>XX / NN</div>
  </div>
  <img class="bleed-img" src="images/hero.jpg" alt="[图片描述]">
  <div class="bleed-overlay"></div>
  <div class="bleed-content" style="padding:0 3vw">
    <div class="kicker" data-anim>Vision · 愿景</div>
    <h1 class="h-hero" style="font-size:3.2vw" data-anim>[核心观点：一句话钉入记忆]</h1>
    <p class="slide-subtitle" style="color:rgba(255,255,255,.6);max-width:55vw" data-anim>[补充说明]</p>
  </div>
  <div class="foot" style="position:relative;z-index:3">
    <div>[主题标签]</div>
    <div>[项目代号] · [日期]</div>
  </div>
</section>
```

**要点**：
- 图片铺满整页（`position:absolute; inset:0`），底部渐变遮罩保证文字可读
- 全幅图片页必须 `dark`——遮罩叠加后文字为白色
- 文字量极少：kicker + 标题 + 一句副标题，不超过3行
- 图片选择标准：有氛围感、不杂乱、底部偏暗（配合遮罩）
- **一个PPT最多1-2页全幅图片**——多了就不稀罕了

---

## 版式灵活性指引

### 问题：为什么第二页总是二元对立？

**根因**：AI生成时习惯性地按"现状→对比→方案"的线性叙事，导致封面后第一页内容页总是选 Layout 6（二元对立）。这是路径依赖，不是最优解。

### 解决：叙事节奏模板

不要用单一决策树，而是根据PPT的**叙事目的**选择节奏模板：

| 叙事类型 | 节奏模板 | 适用场景 |
|---------|---------|---------|
| 诊断型 | Cover → **图表**(数据冲击) → 逻辑推导 → 幕封 → 并列支撑 → 金句 | 问题诊断 / 现状分析 |
| 论证型 | Cover → **数据大字报**(核心指标) → 逻辑推导 → 幕封 → 二元对立 → 表格 → 金句 | 方案论证 / 策略建议 |
| 展示型 | Cover → **图表**(全景数据) → 并列支撑 → 幕封 → 图示(架构) → 条形图(排名) → 金句 | 年度复盘 / 成果展示 |
| 说服型 | Cover → **二元对立**(痛点vs方案) → 逻辑推导 → 幕封 → 并列支撑 → 表格 → 金句 | 变革管理 / 投资建议 |

**核心原则**：封面后的第一页内容页，决定了整份PPT的"第一印象"。不要默认选二元对立——**数据冲击**（图表/大字报）往往更有力。

### 同内容多版式映射

同一内容可以映射多种版式，取决于你想**强调什么**：

| 内容 | 强调对比 → | 强调趋势 → | 强调规模 → | 强调结构 → |
|------|-----------|-----------|-----------|-----------|
| 多组数据 | 二元对立(L6) | 竖向柱状图(L0A) | 数据大字报(L3) | 表格(L2) |
| 流程/架构 | 逻辑推导(L7) | — | — | 图示(L4) |
| 排名/进度 | — | 横向条形图(L0B) | 数据大字报(L3) | 表格(L2) |
| 多维信息 | 表格(L2) | 竖向柱状图(L0A) | 并列支撑(L5) | 图片+标注(L1) |

**操作**：先确定这一页要强调什么（对比/趋势/规模/结构），再从对应列选版式。

### 图表类型选择决策树

当你确定需要用图表时，按以下决策树选择具体类型：

```
你要用图表表达什么？
│
├── 对比大小（谁多谁少）
│   ├── 项目 ≤8 个 → 竖向柱状图(L0A)
│   ├── 项目 4-7 个 + 有排名含义 → 横向条形图(L0B)
│   └── 只有2组对比 → 二元对立(L6)
│
├── 构成比例（谁占多少）
│   ├── 3-5 段 → 环形图(L0D)
│   ├── 需要精确数值 → 表格(L2)
│   └── 多个维度的构成对比 → 堆叠柱状图(用L0A + 分段色)
│
├── 趋势变化（怎么变的）
│   ├── 时间点 ≥4 → 竖向柱状图(L0A)
│   ├── 需看连续走势 → 折线图(用SVG在L0A结构中替换)
│   └── 只看首尾 → 时间轴(L0E)
│
├── 关联关系（谁和谁有关）
│   └── 散点图(用SVG在L0A结构中替换)
│
└── 进度/达标率
    ├── 多项对比达标率 → 横向条形图(L0B)
    └── 单项进度 → 数据大字报(L3)
```

**硬规则**：
- 3D图表 = 禁止。3D扭曲数据比例，是装饰不是信息
- 饼图分段 >5 = 合并"其他"或换表格
- 双Y轴 = 尽量避免。读者无法同时解读两个刻度

---

## Layout 1: 多维信息→图片（Map + Annotations）

**适用**：地图+标注 / 空间分布 / 多维信息需要图片承载

```html
<section class="slide light">
  <div class="chrome">
    <div>市场格局 · Market Landscape</div>
    <div>03 / 20</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker">Matrix · 多维信息</div>
    <h2 class="slide-title">市场格局全景</h2>
    <p class="slide-subtitle">四大象限定位竞争格局</p>

    <div class="grid-2" style="margin-top:4vh; gap:3vw">
      <figure class="frame-img" style="aspect-ratio:16/10; max-height:56vh">
        <img src="images/market-map.png" alt="市场格局图">
        <figcaption class="img-cap">竞争格局四象限定位</figcaption>
      </figure>
      <div>
        <div class="callout">
          "头部玩家集中在右上象限，<br>但左下象限存在蓝海机会。"
          <div class="callout-src">— 市场调研团队</div>
        </div>
        <div class="meta-row" style="margin-top:3vh">
          <span>数据来源：行业报告 2025Q4</span>
        </div>
      </div>
    </div>
  </div>
  <div class="foot">
    <div>市场格局分析</div>
    <div>[项目代号] · 数据截至2025Q4</div>
  </div>
</section>
```

**要点**：
- 左图右文，图片承载多维信息，文字提炼核心发现
- 图片用标准比例 16/10 + `max-height:56vh`
- callout 提炼图片中的核心洞察

---

## Layout 2: 多维信息→表格（Data Table）

**适用**：数据表格 / 对比矩阵 / 多维度数据对比

```html
<section class="slide light">
  <div class="chrome">
    <div>竞品对比 · Competitive Analysis</div>
    <div>05 / 20</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker">Matrix · 多维对比</div>
    <h2 class="slide-title">核心竞品能力矩阵</h2>
    <p class="slide-subtitle">五维能力对比，我司在3项领先</p>

    <div class="data-table" style="margin-top:4vh;--data-cols:2fr 1fr 1fr 1fr 1fr">
      <div class="data-row data-header">
        <div class="data-cell">能力维度</div>
        <div class="data-cell">我司</div>
        <div class="data-cell">竞品A</div>
        <div class="data-cell">竞品B</div>
        <div class="data-cell">竞品C</div>
      </div>
      <div class="data-row">
        <div class="data-cell">技术能力</div>
        <div class="data-cell" style="color:var(--theme);font-weight:700">★★★★★</div>
        <div class="data-cell">★★★★</div>
        <div class="data-cell">★★★</div>
        <div class="data-cell">★★★</div>
      </div>
      <div class="data-row">
        <div class="data-cell">市场覆盖</div>
        <div class="data-cell">★★★★</div>
        <div class="data-cell" style="color:var(--theme);font-weight:700">★★★★★</div>
        <div class="data-cell">★★★★</div>
        <div class="data-cell">★★★</div>
      </div>
      <div class="data-row">
        <div class="data-cell">客户服务</div>
        <div class="data-cell" style="color:var(--theme);font-weight:700">★★★★★</div>
        <div class="data-cell">★★★</div>
        <div class="data-cell">★★★★</div>
        <div class="data-cell">★★★</div>
      </div>
      <div class="data-row">
        <div class="data-cell">价格竞争力</div>
        <div class="data-cell">★★★</div>
        <div class="data-cell">★★★★</div>
        <div class="data-cell">★★★★★</div>
        <div class="data-cell" style="color:var(--theme);font-weight:700">★★★★★</div>
      </div>
      <div class="data-row">
        <div class="data-cell">品牌影响力</div>
        <div class="data-cell">★★★★</div>
        <div class="data-cell" style="color:var(--theme);font-weight:700">★★★★★</div>
        <div class="data-cell">★★★</div>
        <div class="data-cell">★★</div>
      </div>
    </div>
  </div>
  <div class="foot">
    <div>竞品分析 · 数据截至2025Q4</div>
    <div>[项目代号] · 行业公开数据</div>
  </div>
</section>
```

**要点**：
- 表格用 `.data-table` + `.data-row` + `.data-cell` 结构
- 首行 `.data-header` 自动加深背景
- 重点数据用 `color:var(--theme)` + `font-weight:700` 标注
- 表格行数控制在5-7行，超过则拆分多页

---

## Layout 3: 关键发现→数据大字报（Key Finding + Data Cards）

**适用**：柱状图 / 趋势图 / 饼图 / 需要突出单一关键发现

```html
<section class="slide light">
  <div class="chrome">
    <div>核心数据 · Key Metrics</div>
    <div>07 / 20</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker">Finding 01 · 关键发现</div>
    <h2 class="slide-title">营收同比增长 23%</h2>
    <p class="slide-subtitle">连续4个季度正增长，Q4加速明显</p>

    <div class="grid-6" style="margin-top:4vh">
      <div class="stat-card">
        <div class="stat-label">年度营收</div>
        <div class="stat-nb">2.4<span class="stat-unit">亿</span></div>
        <div class="stat-note">同比 +23%</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">净利润率</div>
        <div class="stat-nb">18.5<span class="stat-unit">%</span></div>
        <div class="stat-note">行业平均 12%</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">客户数</div>
        <div class="stat-nb">1,200<span class="stat-unit">+</span></div>
        <div class="stat-note">净增 320</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">客单价</div>
        <div class="stat-nb">20<span class="stat-unit">万</span></div>
        <div class="stat-note">同比 +8%</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">续约率</div>
        <div class="stat-nb">92<span class="stat-unit">%</span></div>
        <div class="stat-note">行业领先</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">NPS</div>
        <div class="stat-nb">67</div>
        <div class="stat-note">较去年 +12</div>
      </div>
    </div>
  </div>
  <div class="foot">
    <div>核心数据 · FY2025</div>
    <div>[项目代号] · 财务数据</div>
  </div>
</section>
```

**要点**：
- 标题本身就是关键发现（"营收同比增长23%"），不是无意义的"数据概览"
- 3×2 网格最稳（`.grid-6`）
- 每个 `stat-card` 结构固定：label → nb → note
- 数字建议2-3位字符，用K/M/亿简写
- stat-note 是洞察，不是重复数字

---

## Layout 4: 关键结构→图示（Structure Diagram）

**适用**：流程图 / 组织架构 / 逻辑图 / 需要展示结构关系

```html
<section class="slide light">
  <div class="chrome">
    <div>方案架构 · Solution Architecture</div>
    <div>09 / 20</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker">Framework · 关键结构</div>
    <h2 class="slide-title">三阶段转型路径</h2>
    <p class="slide-subtitle">从诊断到落地，18个月完成组织能力升级</p>

    <div class="pipeline-section" style="margin-top:4vh">
      <div class="pipeline-label">Phase 1 · 诊断期（0-3月）</div>
      <div class="pipeline">
        <div class="step">
          <div class="step-nb">01</div>
          <div class="step-title">现状评估</div>
          <div class="step-desc">组织能力盘点</div>
        </div>
        <div class="step">
          <div class="step-nb">02</div>
          <div class="step-title">差距分析</div>
          <div class="step-desc">对标行业标杆</div>
        </div>
        <div class="step">
          <div class="step-nb">03</div>
          <div class="step-title">优先级排序</div>
          <div class="step-desc">影响度×紧迫度矩阵</div>
        </div>
      </div>
    </div>

    <div class="pipeline-section" style="margin-top:3vh">
      <div class="pipeline-label">Phase 2 · 建设期（4-12月）</div>
      <div class="pipeline">
        <div class="step">
          <div class="step-nb">04</div>
          <div class="step-title">能力建设</div>
          <div class="step-desc">人才+流程+工具</div>
        </div>
        <div class="step">
          <div class="step-nb">05</div>
          <div class="step-title">试点验证</div>
          <div class="step-desc">2-3个BU先行</div>
        </div>
        <div class="step">
          <div class="step-nb">06</div>
          <div class="step-title">迭代优化</div>
          <div class="step-desc">快速反馈修正</div>
        </div>
      </div>
    </div>

    <div class="pipeline-section" style="margin-top:3vh">
      <div class="pipeline-label">Phase 3 · 推广期（13-18月）</div>
      <div class="pipeline">
        <div class="step">
          <div class="step-nb">07</div>
          <div class="step-title">全面推广</div>
          <div class="step-desc">全组织覆盖</div>
        </div>
        <div class="step">
          <div class="step-nb">08</div>
          <div class="step-title">固化机制</div>
          <div class="step-desc">制度+考核+文化</div>
        </div>
      </div>
    </div>
  </div>
  <div class="foot">
    <div>转型方案 · 三阶段路径</div>
    <div>[项目代号] · 项目组建议</div>
  </div>
</section>
```

**要点**：
- 用 `.pipeline-section` 分组 + `.pipeline-label` 作组标题
- 每个 step 是固定的 nb → title → desc 结构
- 步骤数不限但单行最好 ≤5 个
- 标题是关键结构（"三阶段转型路径"），不是"流程图"

---

## Layout 5: 并列支撑（Parallel Support ≠ 堆砌）

**适用**：多组并列数据/图表 / 多个并列论据支撑同一观点

**核心区别**：并列支撑 ≠ 堆砌。每个并列项必须支撑同一个观点，不是简单罗列。

```html
<section class="slide light">
  <div class="chrome">
    <div>竞争优势 · Competitive Edge</div>
    <div>11 / 20</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker">Evidence · 并列支撑</div>
    <h2 class="slide-title">三大核心优势驱动增长</h2>
    <p class="slide-subtitle">技术领先、客户粘性、生态壁垒构成护城河</p>

    <div class="grid-3" style="margin-top:5vh">
      <div class="stat-card" style="padding:3vh 2vw; border-top:3px solid var(--theme)">
        <div class="stat-label">优势一</div>
        <div class="stat-nb" style="font-size:2.5vw">技术领先</div>
        <div class="stat-note" style="margin-top:2vh; font-size:1vw; line-height:1.6">
          核心算法专利 47 项<br>
          研发投入占比 22%<br>
          技术团队占比 65%
        </div>
      </div>
      <div class="stat-card" style="padding:3vh 2vw; border-top:3px solid var(--theme)">
        <div class="stat-label">优势二</div>
        <div class="stat-nb" style="font-size:2.5vw">客户粘性</div>
        <div class="stat-note" style="margin-top:2vh; font-size:1vw; line-height:1.6">
          续约率 92%<br>
          NPS 67（行业平均 42）<br>
          客户生命周期 5.2 年
        </div>
      </div>
      <div class="stat-card" style="padding:3vh 2vw; border-top:3px solid var(--theme)">
        <div class="stat-label">优势三</div>
        <div class="stat-nb" style="font-size:2.5vw">生态壁垒</div>
        <div class="stat-note" style="margin-top:2vh; font-size:1vw; line-height:1.6">
          合作伙伴 380+<br>
          API 调用量 12亿/月<br>
          数据网络效应显著
        </div>
      </div>
    </div>
  </div>
  <div class="foot">
    <div>竞争优势分析</div>
    <div>[项目代号] · 内部评估</div>
  </div>
</section>
```

**要点**：
- 3列并列最常见（`.grid-3`），也可用 `.grid-4`（4列）
- 每列顶部用 `border-top:3px solid var(--theme)` 统一强调
- 每列结构一致：标签 → 标题 → 数据/描述
- 标题必须表达"并列支撑同一观点"的逻辑关系

---

## Layout 6: 二元对立（Binary Opposition）

**适用**：VS对比 / ✓✗ / 旧vs新 / 问题vs方案

```html
<section class="slide light">
  <div class="chrome">
    <div>模式对比 · Model Comparison</div>
    <div>13 / 20</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker">Comparison · 二元对立</div>
    <h2 class="slide-title">传统模式 vs 数字化模式</h2>
    <p class="slide-subtitle">从线性增长到指数增长的范式跃迁</p>

    <div class="grid-2" style="margin-top:5vh; gap:4vw">
      <div class="vs-block" style="border-left:4px solid var(--level-3); padding-left:2vw">
        <div class="vs-label" style="color:var(--level-3)">传统模式</div>
        <div style="margin-top:3vh">
          <div class="data-row" style="padding:1.5vh 0; border-bottom:1px solid var(--border)">
            <div class="data-cell" style="font-weight:600">增长方式</div>
            <div class="data-cell">线性扩张</div>
          </div>
          <div class="data-row" style="padding:1.5vh 0; border-bottom:1px solid var(--border)">
            <div class="data-cell" style="font-weight:600">决策依据</div>
            <div class="data-cell">经验直觉</div>
          </div>
          <div class="data-row" style="padding:1.5vh 0; border-bottom:1px solid var(--border)">
            <div class="data-cell" style="font-weight:600">响应速度</div>
            <div class="data-cell">月级/季级</div>
          </div>
          <div class="data-row" style="padding:1.5vh 0; border-bottom:1px solid var(--border)">
            <div class="data-cell" style="font-weight:600">组织形态</div>
            <div class="data-cell">层级制</div>
          </div>
          <div class="data-row" style="padding:1.5vh 0">
            <div class="data-cell" style="font-weight:600">边际成本</div>
            <div class="data-cell">递增</div>
          </div>
        </div>
      </div>

      <div class="vs-block" style="border-left:4px solid var(--theme); padding-left:2vw">
        <div class="vs-label" style="color:var(--theme)">数字化模式</div>
        <div style="margin-top:3vh">
          <div class="data-row" style="padding:1.5vh 0; border-bottom:1px solid var(--border)">
            <div class="data-cell" style="font-weight:600">增长方式</div>
            <div class="data-cell" style="color:var(--theme);font-weight:700">指数扩张</div>
          </div>
          <div class="data-row" style="padding:1.5vh 0; border-bottom:1px solid var(--border)">
            <div class="data-cell" style="font-weight:600">决策依据</div>
            <div class="data-cell" style="color:var(--theme);font-weight:700">数据驱动</div>
          </div>
          <div class="data-row" style="padding:1.5vh 0; border-bottom:1px solid var(--border)">
            <div class="data-cell" style="font-weight:600">响应速度</div>
            <div class="data-cell" style="color:var(--theme);font-weight:700">实时/日级</div>
          </div>
          <div class="data-row" style="padding:1.5vh 0; border-bottom:1px solid var(--border)">
            <div class="data-cell" style="font-weight:600">组织形态</div>
            <div class="data-cell" style="color:var(--theme);font-weight:700">网状协同</div>
          </div>
          <div class="data-row" style="padding:1.5vh 0">
            <div class="data-cell" style="font-weight:600">边际成本</div>
            <div class="data-cell" style="color:var(--theme);font-weight:700">递减趋零</div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="foot">
    <div>模式对比分析</div>
    <div>[项目代号] · 行业研究</div>
  </div>
</section>
```

**要点**：
- 左右两列用 `.grid-2` 对分
- 左列用浅色边框（`var(--level-3)`），右列用主题色边框（`var(--theme)`）——视觉暗示"右列是推荐"
- 对比项必须一一对应，行数相同
- 右列（推荐方案）的关键词用主题色+加粗标注

---

## Layout 7: 逻辑推导（Logical Derivation ≥ 2 Modules）

**适用**：推理/递进/分析/归纳/拆解/时序对比

**6种子类型**：

| 子类型 | 逻辑关系 | 箭头方向 | 典型场景 |
|--------|---------|---------|---------|
| 推理 | 因→果 | → | 原因分析→结论 |
| 递进 | 浅→深 | → | 表面现象→深层规律 |
| 分析 | 现象→本质 | → | 观察到的问题→根本原因 |
| 归纳 | 具体→一般 | → | 多个案例→通用规律 |
| 拆解 | 整体→局部 | ↓ | 战略→执行拆解 |
| 时序对比 | 前→后 | → | 变革前vs变革后 |

```html
<section class="slide light">
  <div class="chrome">
    <div>根因分析 · Root Cause</div>
    <div>15 / 20</div>
  </div>
  <div class="frame" style="padding-top:6vh">
    <div class="kicker">逻辑推导 · 分析</div>
    <h2 class="slide-title">从现象到本质：增长放缓的根因</h2>
    <p class="slide-subtitle">三层穿透，定位核心瓶颈</p>

    <div class="logic-flow" style="margin-top:5vh">
      <div class="logic-step" style="flex:1; padding:3vh 2vw; background:var(--bg-light)">
        <div class="step-nb" style="color:var(--level-3)">现象层</div>
        <div class="step-title" style="margin-top:1.5vh">营收增速放缓</div>
        <div class="step-desc" style="margin-top:1vh">
          Q3同比+8%<br>
          较Q2下降15pp
        </div>
      </div>

      <div class="logic-arrow" style="display:flex;align-items:center;padding:0 1vw;color:var(--level-3)">→</div>

      <div class="logic-step" style="flex:1; padding:3vh 2vw; background:var(--bg-light)">
        <div class="step-nb" style="color:var(--level-2)">原因层</div>
        <div class="step-title" style="margin-top:1.5vh">新客获取效率下降</div>
        <div class="step-desc" style="margin-top:1vh">
          CAC同比+35%<br>
          转化率下降12pp
        </div>
      </div>

      <div class="logic-arrow" style="display:flex;align-items:center;padding:0 1vw;color:var(--level-3)">→</div>

      <div class="logic-step" style="flex:1; padding:3vh 2vw; background:var(--theme-light); border-left:3px solid var(--theme)">
        <div class="step-nb" style="color:var(--theme)">根因层</div>
        <div class="step-title" style="margin-top:1.5vh; color:var(--theme)">产品差异化不足</div>
        <div class="step-desc" style="margin-top:1vh">
          核心功能被竞品追平<br>
          客户感知价值下降
        </div>
      </div>
    </div>

    <div class="callout" style="margin-top:4vh">
      "根因不是获客问题，而是产品竞争力问题。<br>解决方案应聚焦产品差异化，而非加大营销投入。"
    </div>
  </div>
  <div class="foot">
    <div>根因分析 · 三层穿透</div>
    <div>[项目代号] · 项目组分析</div>
  </div>
</section>
```

**要点**：
- 用 `.logic-flow` + `.logic-step` + `.logic-arrow` 构建推导链
- 每一步用浅灰背景（`var(--bg-light)`），最后一步用主题色浅底（`var(--theme-light)`）突出结论
- 箭头用 `→` 符号，简洁清晰
- 2-4步推导最常见，超过4步拆分多页
- callout 提炼推导结论的核心洞察

---

## 8页节奏模板（可直接套用）

| 页 | 主题 | 布局 | 备注 |
|---|---|---|---|
| 1 | `dark` | 封面 | 开场 |
| 2 | `light` | 数据大字报(L3) | 抛关键数据 |
| 3 | `light` | 二元对立(L6) | 现状vs目标 |
| 4 | `dark` | 章节幕封 | 呼吸 |
| 5 | `light` | 逻辑推导(L7) | 根因分析 |
| 6 | `light` | 并列支撑(L5) | 方案三支柱 |
| 7 | `light` | 表格(L2) | 行动计划 |
| 8 | `dark` | 金句页 | 核心结论 |

**先画这张表对齐，再动手写slide**。跳过规划直接粘骨架 = 全是light。
