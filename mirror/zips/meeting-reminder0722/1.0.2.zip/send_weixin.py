#!/usr/bin/env python3
"""
微信消息发送脚本 - meeting-reminder skill
使用 OpenClaw 的 message 工具发送微信消息
"""

import json
import subprocess
import sys
import os
from datetime import datetime

# 配置文件路径
USERS_FILE = os.path.join(os.path.dirname(__file__), 'users.json')
ACCOUNT_ID = "ceac8a5097e5-im-bot"


def load_users():
    """读取用户信息"""
    try:
        with open(USERS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get('users', [])
    except FileNotFoundError:
        print(f"[错误] 用户文件不存在: {USERS_FILE}")
        return []
    except json.JSONDecodeError as e:
        print(f"[错误] 用户文件格式错误: {e}")
        return []


def send_weixin_message(to_openid, message, account_id=ACCOUNT_ID):
    """
    发送微信消息
    
    Args:
        to_openid: 接收者的 openid
        message: 消息内容
        account_id: 微信账号 ID
    
    Returns:
        dict: 包含 success, message_id, error 信息
    """
    if not to_openid:
        return {
            'success': False,
            'error': 'openid 不能为空',
            'message_id': None
        }
    
    # 构建 message 命令
    cmd = [
        'openclaw', 'message',
        '--action', 'send',
        '--channel', 'openclaw-weixin',
        '--to', f'{to_openid}@im.wechat',
        '--message', message,
        '--accountId', account_id
    ]
    
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=True,
            timeout=30
        )
        
        # 解析输出获取 message_id
        output = result.stdout
        message_id = None
        if 'messageId' in output:
            try:
                import re
                match = re.search(r'"messageId":\s*"([^"]+)"', output)
                if match:
                    message_id = match.group(1)
            except:
                pass
        
        return {
            'success': True,
            'message_id': message_id,
            'error': None,
            'raw_output': output
        }
        
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr if e.stderr else e.stdout
        return {
            'success': False,
            'error': f'命令执行失败: {error_msg}',
            'message_id': None,
            'return_code': e.returncode
        }
    except subprocess.TimeoutExpired:
        return {
            'success': False,
            'error': '发送超时（30秒）',
            'message_id': None
        }
    except Exception as e:
        return {
            'success': False,
            'error': f'未知错误: {str(e)}',
            'message_id': None
        }


def notify_user(name, message, verbose=True):
    """
    发送给指定用户
    
    Args:
        name: 用户名
        message: 消息内容
        verbose: 是否打印详细信息
    
    Returns:
        dict: 发送结果
    """
    users = load_users()
    
    # 查找用户（不区分大小写）
    for user in users:
        if user['name'].lower() == name.lower():
            if verbose:
                print(f"[发送] {name} ({user['openid']})...")
            
            result = send_weixin_message(user['openid'], message)
            
            if verbose:
                if result['success']:
                    print(f"  ✓ 成功 (message_id: {result['message_id']})")
                else:
                    print(f"  ✗ 失败: {result['error']}")
            
            return {
                'name': name,
                'openid': user['openid'],
                **result
            }
    
    error_msg = f"未找到用户: {name}"
    if verbose:
        print(f"[错误] {error_msg}")
    
    return {
        'name': name,
        'openid': None,
        'success': False,
        'error': error_msg,
        'message_id': None
    }


def notify_all(message, verbose=True):
    """
    发送给所有用户
    
    Args:
        message: 消息内容
        verbose: 是否打印详细信息
    
    Returns:
        list: 所有发送结果
    """
    users = load_users()
    results = []
    
    if not users:
        if verbose:
            print("[警告] 用户列表为空")
        return results
    
    if verbose:
        print(f"[批量发送] 共 {len(users)} 人")
        print("-" * 50)
    
    for user in users:
        result = notify_user(user['name'], message, verbose=verbose)
        results.append(result)
    
    if verbose:
        print("-" * 50)
        success_count = sum(1 for r in results if r['success'])
        print(f"[完成] 成功: {success_count}/{len(results)}")
    
    return results


def print_results(results):
    """打印发送结果表格"""
    print("\n发送结果汇总:")
    print("-" * 60)
    print(f"{'姓名':<10} {'状态':<6} {'消息ID/错误':<40}")
    print("-" * 60)
    
    for r in results:
        status = "✓" if r['success'] else "✗"
        info = r['message_id'] if r['success'] else r['error']
        if info and len(info) > 38:
            info = info[:35] + "..."
        print(f"{r['name']:<10} {status:<6} {info or '-':<40}")
    
    print("-" * 60)


# CLI 入口
if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='微信消息发送工具')
    parser.add_argument('--user', '-u', help='指定用户名发送')
    parser.add_argument('--all', '-a', action='store_true', help='发送给所有用户')
    parser.add_argument('--message', '-m', required=True, help='消息内容')
    parser.add_argument('--quiet', '-q', action='store_true', help='静默模式')
    
    args = parser.parse_args()
    
    verbose = not args.quiet
    
    if args.all:
        results = notify_all(args.message, verbose=verbose)
        if verbose and results:
            print_results(results)
    elif args.user:
        result = notify_user(args.user, args.message, verbose=verbose)
        if verbose:
            print_results([result])
    else:
        parser.print_help()
        sys.exit(1)
