---
name: meeting-reminder
description: 会议提醒助手。**用户注册**：当用户说"我叫xxx"、"我是xxx"、"记录名字xxx"、"叫我xxx"等自我介绍时，立即记录用户名和open ID。**会议提醒**：当用户说"提醒xxx开会"、"通知xxx"、发送参会人员Excel时，匹配users.json并发送微信提醒。**优先级：用户注册意图检测优先于普通对话**。触发词：我叫、我是、叫我、名字是、记录名字、提醒、通知、开会、会议。
---

# 会议提醒助手

## 功能概述

1. **用户注册**：记录用户名字和对应的open ID
2. **会议提醒**：根据Excel或文本指令给指定用户发送微信提醒

## 核心工作流

### 需求1：记录用户信息

当用户说"我叫xxx"、"我是xxx"、"记录名字xxx"时：

1. 提取用户名
2. 从当前会话context获取用户的open ID（`chat_id`字段中的`@im.wechat`前部分）
3. 追加写入到用户信息文件：`users.json`
4. 回复：`我已记录您的名字为xxx，openid为xxxx`

**用户信息文件格式**：
```json
{
  "users": [
    {"name": "张三", "openid": "abc123", "registered_at": "2026-04-27T16:00:00+08:00"},
    {"name": "李四", "openid": "def456", "registered_at": "2026-04-27T16:05:00+08:00"}
  ]
}
```

**注意**：
- 每次注册前检查是否已存在同名用户，若存在则更新openid和注册时间
- 用户名不区分大小写匹配（如"张三"和"张三"视为同一人）
- 如果用户多次注册同一名字，只保留最新的记录

### 需求2：发送会议提醒

**重要：所有消息发送都通过 `send_weixin.py` 脚本执行，不要直接调用 message 工具。**

支持两种输入方式：

#### 方式A：直接文本指令

用户说"提醒张三"、"通知李四开会"、"提醒张三和李四"等：

1. 提取用户名列表
2. 在users.json中查找对应的openid
3. **调用Python脚本发送**：
   ```bash
   python3 /root/.openclaw/workspace/skills/meeting-reminder0722/send_weixin.py --user "张三" --message "【会议提醒】请参加会议"
   ```
4. 汇报发送结果

#### 方式B：Excel文件

用户发送包含会议人员和时间的Excel：

1. 解析Excel文件，提取人员名单和会议时间
2. 在users.json中匹配每个人员的openid
3. **调用Python脚本批量发送**：
   ```bash
   python3 /root/.openclaw/workspace/skills/meeting-reminder0722/send_weixin.py --all --message "【会议提醒】请参加会议"
   ```
4. 汇报发送结果（成功/失败/未匹配）

**Excel格式期望**：
- 包含"姓名"或"人员"列
- 可选："时间"、"会议主题"等列

## 文件结构

```
skills/meeting-reminder0722/
├── SKILL.md              # 本文件
├── users.json            # 用户信息存储
└── send_weixin.py        # 微信消息发送脚本（核心）
```

## 实现步骤

### 步骤1：注册用户

当检测到用户注册意图（"我叫xxx"、"我是xxx"等）：

1. **提取用户名**：从用户消息中提取名字部分
2. **获取open ID**：从inbound context的`chat_id`字段提取
   - chat_id格式：`<openid>@im.wechat`
   - 提取openid：去掉`@im.wechat`后缀
3. **更新users.json**：
   ```python
   # 读取现有数据
   with open('users.json', 'r', encoding='utf-8') as f:
       data = json.load(f)
   
   # 检查是否已存在同名用户（不区分大小写）
   for user in data['users']:
       if user['name'].lower() == name.lower():
           user['openid'] = openid
           user['registered_at'] = 当前时间
           break
   else:
       # 新用户，追加
       data['users'].append({
           'name': name,
           'openid': openid,
           'registered_at': 当前时间
       })
   
   # 写回文件
   with open('users.json', 'w', encoding='utf-8') as f:
       json.dump(data, f, ensure_ascii=False, indent=2)
   ```
4. **回复确认**：`我已记录您的名字为{名字}，openid为{openid}`

### 步骤2：发送提醒

当检测到提醒意图（"提醒xxx"、"通知xxx开会"等）：

1. **提取用户名列表**：支持多个名字（逗号、空格、"和"分隔）
2. **匹配用户信息**：在users.json中查找（不区分大小写）
3. **调用Python脚本发送**（**必须**）：
   
   **发送给指定用户**：
   ```bash
   python3 /root/.openclaw/workspace/skills/meeting-reminder0722/send_weixin.py \
     --user "张三" \
     --message "【会议提醒】请立即参加会议！"
   ```
   
   **发送给所有用户**：
   ```bash
   python3 /root/.openclaw/workspace/skills/meeting-reminder0722/send_weixin.py \
     --all \
     --message "【会议提醒】请立即参加会议！"
   ```

4. **汇报结果**：脚本会输出详细的发送结果，包括成功/失败状态和错误信息

## send_weixin.py 脚本说明

### 功能
- 从 users.json 读取用户信息
- 调用 `openclaw message` 命令发送微信消息
- 提供完整的错误处理和日志输出
- 支持单个用户和批量发送

### 使用方法

```bash
# 发送给指定用户
python3 send_weixin.py --user "张三" --message "会议提醒内容"

# 发送给所有用户
python3 send_weixin.py --all --message "会议提醒内容"

# 静默模式（不输出详细信息）
python3 send_weixin.py --all --message "会议提醒" --quiet
```

### 输出示例

```
[批量发送] 共 4 人
--------------------------------------------------
[发送] 吴希宝 (o9cq806bIz-Cjnf4dAVnR9q0AamI)...
  ✓ 成功 (message_id: openclaw-weixin:1777346837562-b3412c30)
[发送] 张驰高 (o9cq804Z_cjIT0-r_h8LIGwhzUww)...
  ✓ 成功 (message_id: openclaw-weixin:1777346837637-cc520e60)
...
--------------------------------------------------
[完成] 成功: 4/4

发送结果汇总:
------------------------------------------------------------
姓名       状态   消息ID/错误                             
------------------------------------------------------------
吴希宝     ✓      openclaw-weixin:1777346837562-b3412c...
张驰高     ✓      openclaw-weixin:1777346837637-cc520e...
...
------------------------------------------------------------
```

## 错误处理

- **用户名未找到**：脚本返回"未找到xxx的用户信息"
- **发送失败**：脚本输出详细错误信息（如openid无效、网络超时等）
- **Excel解析失败**：提示具体错误原因
- **users.json不存在**：脚本自动处理，返回空用户列表

## 示例对话

**用户注册**：
```
用户：我叫张三
助手：我已记录您的名字为张三，openid为abc123
```

**文本提醒**（调用脚本）：
```
用户：提醒张三开会
助手：正在发送通知...
[执行脚本] python3 send_weixin.py --user "张三" --message "【会议提醒】请参加会议"

结果：
✓ 张三 - 发送成功
```

**批量提醒**（调用脚本）：
```
用户：通知所有人开会
助手：正在发送通知给所有 4 人...
[执行脚本] python3 send_weixin.py --all --message "【会议提醒】请参加会议"

结果：
✓ 吴希宝 - 发送成功
✓ 张驰高 - 发送成功
✓ 钱小楠 - 发送成功
✓ 王梦圆 - 发送成功
```

**Excel提醒**：
```
用户：[发送meeting.xlsx]
助手：已解析Excel，发现3位参会人员，正在发送...
[执行脚本] python3 send_weixin.py --user "张三" --message "【会议提醒】..."
[执行脚本] python3 send_weixin.py --user "李四" --message "【会议提醒】..."
...

结果：
- 张三：已发送 ✓
- 李四：已发送 ✓
- 王五：未注册，跳过
```

## 注意事项

1. **必须使用Python脚本**：所有消息发送都通过 `send_weixin.py` 执行，不要直接调用 message 工具
2. **脚本路径**：`/root/.openclaw/workspace/skills/meeting-reminder0722/send_weixin.py`
3. **依赖**：需要 `openclaw` CLI 工具已安装并配置好
4. **权限**：确保脚本有执行权限（`chmod +x send_weixin.py`）
