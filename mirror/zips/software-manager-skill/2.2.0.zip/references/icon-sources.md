---
source: |
  来源：Tailwind CSS / 行业最佳实践
  URL: https://www.tailwindcss.cn/
date: 2026-04-25
---

# Icon Library Sources - Research Results

## 1. Heroicons
- **Website**: https://heroicons.com/
- **GitHub**: https://github.com/tailwindlabs/heroicons
- **Description**: Beautiful hand-crafted SVG icons, by the makers of Tailwind CSS
- **Icon Count**: 316 icons
- **License**: MIT License
- **Format**: SVG (both outline and solid styles)
- **Libraries**: React and Vue components available
- **Version**: v2.1.5
- **Stars**: approximately 23,481
- **CDN Access**: Via npm packages
- **Features**: Two styles: 24x24 outline and 20x20 solid, optimized for Tailwind CSS

## 2. Lucide Icons
- **Website**: https://lucide.dev/
- **GitHub**: https://github.com/lucide-icons/lucide
- **Description**: Beautiful and consistent icon toolkit made by the community
- **Icon Count**: 1000+ icons
- **License**: MIT License
- **Format**: SVG
- **Libraries**: React, Vue, Svelte, and more
- **Stars**: approximately 22,267
- **CDN Access**: Available via jsDelivr, unpkg, and their own API
- **Features**: Forked from Feather Icons, tree-shakable, consistent 24x24 grid

## 3. SVGRepo
- **Website**: https://www.svgrepo.com/
- **Description**: Collection of free SVG icons and illustrations
- **Icon Count**: 100,000+ SVG icons
- **License**: Mixed - check individual icons (many MIT, Apache 2.0)
- **Format**: SVG
- **CDN Access**: Yes, provides CDN URLs
- **Features**: Large collection, search and filter, bulk download

## 4. Iconify Design
- **Website**: https://iconify.design/
- **GitHub**: https://github.com/iconify
- **Description**: Universal icon framework with over 150 icon sets
- **Icon Count**: 200,000+ icons across 150+ icon sets
- **License**: Apache 2.0 (for Iconify framework); icons vary by source
- **Format**: SVG, web components, React, Vue, Svelte
- **Stars**: approximately 6,067
- **CDN Access**: Yes - Iconify API with free hosting
- **Features**: Unifies many icon sets, works with Tailwind CSS, design tool plugins

## Summary

| Library | URL | Icons | License | CDN | Best For |
|---------|-----|-------|---------|-----|----------|
| Heroicons | heroicons.com | 316 | MIT | npm | Tailwind projects |
| Lucide | lucide.dev | 1000+ | MIT | Yes | React/Vue apps |
| SVGRepo | svgrepo.com | 100k+ | Mixed | Yes | General SVG icons |
| Iconify | iconify.design | 200k+ | Apache 2.0 | Yes | Universal icon needs |
