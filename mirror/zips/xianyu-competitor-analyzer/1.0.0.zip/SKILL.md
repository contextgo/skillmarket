---
name: xianyu-competitor-analyzer
description: Analyze Xianyu (Goofish) marketplace listings to generate product descriptions and competitive insights. Use when the user wants to (1) search for competitor products on Xianyu/闲鱼, (2) analyze Xianyu marketplace listings for pricing, titles, and descriptions, (3) generate product listings based on Xianyu market research, or (4) research second-hand/resale market trends on Xianyu. Triggers on keywords like 闲鱼, 咸鱼, xianyu, goofish, 竞品分析, 同行分析, 产品介绍, 闲鱼搜索, 闲鱼商品分析.
---

# Xianyu Competitor Analyzer

Analyze Xianyu (闲鱼/Goofish) marketplace listings to extract competitive intelligence and generate optimized product listings.

## Workflow

### Step 1: Access Xianyu Homepage

Visit `https://www.goofish.com`. The page loads with recommended products in the "猜你喜欢" (Guess You Like) section even without login.

**Handle login popup**: If a login modal appears (短信登录/密码登录/扫码登录), close it by clicking the X button or clicking outside the modal (element index varies; look for `<div />` or close button near the modal).

### Step 2: Search for Industry Keyword

**Method A - Direct URL (preferred)**:
Navigate directly to `https://www.goofish.com/search?q={URL_ENCODED_KEYWORD}`

**Method B - Search box**:
If on homepage, locate the search input field (typically near the top), input the keyword, and click the search button.

**Login limitation handling**:
Xianyu web version requires login for search results. If the search page shows "小闲鱼没有找到你想要的宝贝~" or login modal appears:
1. Close the login modal
2. Fall back to collecting products from the homepage "猜你喜欢" section
3. Use category links related to the industry keyword (e.g., click relevant category from left sidebar like 手机/数码/电脑)
4. Collect all visible product cards from the page

### Step 3: Collect Product Data

Scroll down the page (`browser_scroll_down` with 500-800px) multiple times to load more products. Collect data from each product card:

**Extract per product**:
- **Title**: Product title text (e.g., "金士顿 DDR4 16G 3200台式机内存 成色基本完美包邮")
- **Price**: Price after ¥ symbol (e.g., "¥485", "¥28")
- **Original price**: Strikethrough price if present (e.g., "¥3999")
- **Want count**: Number of people who clicked "想要" (e.g., "38人想要")
- **Seller name**: Masked seller nickname (e.g., "兔***子")
- **Seller rating**: Credit level (e.g., "卖家信用优秀", "卖家信用极好")
- **Brand tags**: Brand names shown as tags (e.g., "KOHLER/科勒", "XTJQZ")
- **Condition**: Item condition tags (e.g., "全新", "轻微使用痕迹", "99新")
- **Shipping tags**: "包邮" (free shipping), etc.
- **Product description snippet**: Any visible description text in the card

**Target collection**: Gather at least 15-20 products for meaningful analysis. Keep scrolling until enough products are collected or page end is reached.

### Step 4: Analyze Collected Data

Analyze all collected products to extract patterns:

**Pricing analysis**:
- Price range (min, max, average)
- Most common price points
- Original vs. selling price comparison (discount patterns)

**Title analysis**:
- Most frequent keywords used in titles
- Common prefixes/suffixes (e.g., 【包邮】, 【全新正品】, 清仓！)
- Brand mention patterns
- Emoji/special character usage patterns

**Description patterns**:
- Common selling points (e.g., "包邮", "全新未拆封", "清仓处理")
- Urgency phrases (e.g., "数量有限", "亏本包邮赚人气", "买到就是赚到")
- Trust signals (e.g., "描述不符包邮退", "保证正品", "实体发货")
- Call-to-action phrases (e.g., "感兴趣的话点'我想要'和我私聊吧～")

**Seller behavior patterns**:
- Common seller ratings and their correlation with sales
- Professional seller indicators (e.g., "鱼小铺" level)
- Shipping strategies (包邮 vs. 不包邮)

**Product condition distribution**:
- Ratio of "全新" vs. used items
- Condition descriptions for used items

### Step 5: Generate Product Introduction

Based on the analysis, generate a comprehensive product listing template that would be competitive on Xianyu.

**Output structure**:

```markdown
# 【商品名称】{industry keyword} - 闲鱼竞品分析报告

## 一、市场概况
- 采集样本数：{N}个同类商品
- 价格区间：¥{min} - ¥{max}
- 主流价位：¥{common_range}
- 平均想要数：{avg_wants}人

## 二、竞品标题关键词分析
高频关键词：{keyword1}, {keyword2}, {keyword3}...
标题结构模式：{patterns}

## 三、卖点与描述策略分析
- 核心卖点：{top selling points}
- 信任背书方式：{trust signals}
- 促单话术：{urgency phrases}
- 物流策略：{shipping strategy}

## 四、生成的商品发布模板

### 推荐标题
{optimized title based on keyword analysis}

### 商品描述
{full product description incorporating best practices}

### 定价建议
{pricing recommendation with rationale}

### 标签建议
{suggested tags for the listing}
```

**Generation rules**:
1. Title should incorporate top 3-5 most frequent keywords from competitor analysis
2. Title should include trust signals (包邮, 正品, 全新 if applicable)
3. Description should mimic successful sellers' tone and structure
4. Price should be positioned competitively (typically average or slightly below average of collected samples)
5. Include urgency/trust elements that performed well in the analysis
6. Match the language style of the specific industry (casual for personal items, professional for electronics, etc.)

## Important Notes

- **Login requirement**: Xianyu web search requires user login. This skill works with publicly visible homepage products and falls back gracefully when search is blocked. The generated analysis is based on available sample data.
- **Data freshness**: Product listings change constantly. The analysis reflects a snapshot in time.
- **Legal compliance**: Generated listings should follow Xianyu community guidelines. Do not copy exact competitor text - synthesize patterns into original content.
- **Scroll strategy**: Scroll down 2-3 times (500-800px each) to collect sufficient sample data before analysis.
