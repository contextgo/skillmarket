---
name: 图片翻译表格
description: |
  [ZH] 将图片中的文字内容识别并翻译为中英对照表格，支持批量处理多张图片。适用于UI截图、文档、流程图、界面、菜单、海报等任何含文字的图片。当用户要求翻译图片内容、创建翻译对照表、批量翻译图片文字时触发。支持术语库管理保证翻译一致性。
  [EN] Recognize and translate text from images into Chinese-English comparison tables, supporting batch processing. Works with UI screenshots, documents, flowcharts, interfaces, menus, posters and any image containing text. Triggers when user asks to translate image content, create translation tables, or batch translate images.
version: 1.1.0
icon: 🖼️
---

# 图片翻译表格技能

将图片中的文字内容识别并翻译为中英对照表格，支持逐张或批量处理多张图片。适用于任何含文字的图片，如 UI 界面、流程图、文档、菜单、海报、宣传资料等。

## 何时使用

- 用户发送图片并要求翻译内容
- 用户要求创建中英对照表格
- 用户要求批量翻译多张图片
- 用户要求整理翻译记录

## 支持的图片类型

- UI 界面截图
- 流程图 / 架构图
- 数据表格截图
- 菜单 / 界面
- 海报 / 宣传资料
- 文档扫描件
- 任何含文字的图片

## 工作流程

### 单张图片处理

1. **加载术语库** → 自动加载 `./翻译术语库.xlsx`，构建术语字典和翻译记忆
2. **读取图片** → 使用 Read 工具读取图片，识别所有文字元素
3. **分类整理** → 按区域/位置分类整理文字内容
4. **术语匹配** → 优先使用术语库中的翻译
5. **翻译记忆** → 查翻译记忆，完全匹配直接复用
6. **翻译** → 为每个文字元素提供准确的英文翻译
7. **一致性检查** → 检查术语使用是否一致
8. **标记不一致** → 用橙色背景（FFCC99）标记不一致项
9. **创建 Excel** → 使用 Python + openpyxl 生成表格
10. **输出结果** → 展示结果和文件路径

### 批量图片处理

1. **加载术语库** → 自动加载术语库
2. **逐张读取** → 逐张读取图片，识别并整理翻译
3. **术语匹配** → 确保术语一致性，复用历史翻译
4. **合并 Excel** → 创建单个文件，每张图片独立工作表
5. **一致性检查** → 每完成一张立即检查并标记
6. **添加说明页** → 自动添加 `00_说明` 工作表
7. **汇总输出** → 展示文件路径和各 Sheet 说明

## 术语库管理

术语库文件 `翻译术语库.xlsx` 包含两个工作表：

**主术语表**
| 序号 | 中文 | English | 类别 | 备注 |
|------|------|---------|------|------|
| 1 | 保存 | Save | 操作 | |
| 2 | 取消 | Cancel | 操作 | |
| 3 | 确认 | Confirm | 操作 | |

**翻译记忆**
| 来源 | 中文句段 | 英文翻译 | 创建日期 |
|------|----------|----------|----------|
| 图片A | 主菜单 | Main Menu | 2026-01-01 |

### 加载术语库

```python
from openpyxl import load_workbook

def load_terminology_library(file_path):
    """加载术语库"""
    wb = load_workbook(file_path)
    sheet = wb['主术语表']
    terminology = {}
    for row in sheet.iter_rows(min_row=2, values_only=True):
        if row[1] and row[2]:
            terminology[row[1]] = {
                'translation': row[2],
                'category': row[3] if len(row) > 3 else '',
                'notes': row[4] if len(row) > 4 else ''
            }
    return terminology
```

### 翻译记忆匹配

```python
def find_translation_memory(chinese_text, memory_db):
    """查找翻译记忆"""
    if chinese_text in memory_db:
        return memory_db[chinese_text]
    for key, translation in memory_db.items():
        if chinese_text in key or key in chinese_text:
            return f"[参考] {translation}"
    return None
```

## Excel 表格代码模板

### 单张图片翻译

```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

# 术语库路径
TERMINOLOGY_PATH = './翻译术语库.xlsx'
terminology = load_terminology_library(TERMINOLOGY_PATH)

wb = Workbook()
sheet = wb.active
sheet.title = '翻译'

# 表头
headers = ['序号', '位置/区域', '中文', 'English']
for col, header in enumerate(headers, 1):
    cell = sheet.cell(row=1, column=col, value=header)
    cell.font = Font(bold=True)
    cell.fill = PatternFill('solid', start_color='FFFF00')
    cell.alignment = Alignment(horizontal='center')

# 翻译数据
data = [
    [1, '顶部导航', '主页', 'Home'],
    [2, '顶部导航', '搜索', 'Search'],
]

inconsistencies = []
for row_idx, row_data in enumerate(data, 2):
    for col_idx, value in enumerate(row_data, 1):
        sheet.cell(row=row_idx, column=col_idx, value=value)
    
    chinese_text = row_data[2]
    english_text = row_data[3]
    for term_cn, term_data in terminology.items():
        if term_cn in chinese_text:
            if term_data['translation'].lower() not in english_text.lower():
                sheet.cell(row=row_idx, column=4).fill = PatternFill('solid', start_color='FFCC99')

# 列宽
sheet.column_dimensions['A'].width = 8
sheet.column_dimensions['B'].width = 18
sheet.column_dimensions['C'].width = 45
sheet.column_dimensions['D'].width = 55

wb.save('翻译对照表.xlsx')
```

### 批量图片翻译

```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

TERMINOLOGY_PATH = './翻译术语库.xlsx'
terminology = load_terminology_library(TERMINOLOGY_PATH)

wb = Workbook()
wb.remove(wb.active)

images_data = {
    '图片A': [[1, '区域', '中文', 'English']],
    '图片B': [[1, '区域', '中文', 'English']],
}

for sheet_name, data in images_data.items():
    clean_name = sheet_name.replace('/', '-').replace('\\', '-')[:31]
    sheet = wb.create_sheet(title=clean_name)
    
    headers = ['序号', '位置/区域', '中文', 'English']
    for col, header in enumerate(headers, 1):
        cell = sheet.cell(row=1, column=col, value=header)
        cell.font = Font(bold=True)
        cell.fill = PatternFill('solid', start_color='FFFF00')
        cell.alignment = Alignment(horizontal='center')
    
    for row_idx, row_data in enumerate(data, 2):
        for col_idx, value in enumerate(row_data, 1):
            sheet.cell(row=row_idx, column=col_idx, value=value)
    
    sheet.column_dimensions['A'].width = 8
    sheet.column_dimensions['B'].width = 18
    sheet.column_dimensions['C'].width = 45
    sheet.column_dimensions['D'].width = 55

# 添加说明页
summary = wb.create_sheet(title='00_说明', index=0)
summary.cell(1, 1, value='翻译对照表汇总')
summary.cell(1, 1).font = Font(bold=True, size=14)
summary.cell(2, 1, value='本文件包含以下图片的翻译内容：')
for idx, sheet_name in enumerate(images_data.keys(), 3):
    summary.cell(idx, 1, value=f'• {sheet_name}')
summary.column_dimensions['A'].width = 50

wb.save('批量翻译对照表.xlsx')
```

## 文件命名规范

| 类型 | 命名格式 | 示例 |
|------|----------|------|
| 单张 | `{图片名}_翻译对照表.xlsx` | `截图1_翻译对照表.xlsx` |
| 批量 | `批量翻译对照表_{日期}.xlsx` | `批量翻译对照表_20260101.xlsx` |
| 指定主题 | `{主题}_翻译对照表.xlsx` | `产品手册_翻译对照表.xlsx` |

## 通用术语参考

### 界面操作类

| 中文 | English |
|------|---------|
| 新建 | New |
| 创建 | Create |
| 编辑 | Edit |
| 删除 | Delete |
| 保存 | Save |
| 取消 | Cancel |
| 确认 | Confirm |
| 关闭 | Close |
| 返回 | Back |
| 上一步 | Previous |
| 下一步 | Next |
| 完成 | Done / Complete |
| 搜索 | Search |
| 查询 | Query |
| 添加 | Add |
| 移除 | Remove |
| 导入 | Import |
| 导出 | Export |
| 复制 | Copy |
| 粘贴 | Paste |
| 剪切 | Cut |
| 撤销 | Undo |
| 重做 | Redo |

### 状态类

| 中文 | English |
|------|---------|
| 成功 | Success |
| 失败 | Failed |
| 错误 | Error |
| 警告 | Warning |
| 提示 | Tip / Notice |
| 进行中 | In Progress |
| 已完成 | Completed |
| 待处理 | Pending |
| 已禁用 | Disabled |
| 已启用 | Enabled |

### 流程控制类

| 中文 | English |
|------|---------|
| 开始 | Start |
| 结束 | End |
| 继续 | Continue |
| 退出 | Exit |
| 是 | Yes |
| 否 | No |
| 确认 | Yes / Confirm |
| 拒绝 | Reject |
| 跳过 | Skip |
| 重试 | Retry |

## 翻译原则

1. **简洁明了** - 符合目标语言的界面文案风格
2. **保持专业术语一致** - 同一术语在不同位置译法统一
3. **专有名词保留原文** - 品牌名、产品名、技术术语等
4. **格式保持不变** - 时间、日期、百分比等格式按原文
5. **编号、标识符保持不变** - 变量名、路径等不翻译
6. **优先术语库** - 术语库中的翻译优先使用
7. **翻译记忆复用** - 完全匹配时直接复用历史翻译

## 输出格式

处理完成后向用户输出：

1. Excel 文件路径（markdown 链接格式）
2. 翻译内容摘要
3. 多张图片时说明各工作表对应的图片
4. 术语一致性检查结果
5. 新增术语统计

### 示例输出

**单张图片：**

翻译已完成。

中文 - 英文对照表已生成：[截图1_翻译对照表.xlsx](file://./截图1_翻译对照表.xlsx)

表格包含 2 个区域的翻译内容：顶部导航栏（5 项）、主体内容区（12 项），共计 17 条翻译记录。

术语一致性检查：通过，所有术语翻译一致。
新增术语：3 条（已记录）。

**批量图片：**

翻译已完成。

批量翻译对照表已生成：[批量翻译对照表_20260101.xlsx](file://./批量翻译对照表_20260101.xlsx)

本文件包含 2 张图片的翻译内容：截图1（17 条记录）、截图2（8 条记录）。首页"00_说明"列出了所有工作表说明。

术语一致性检查：通过。
新增术语：5 条。

## 注意事项

1. 使用 Python + openpyxl 创建 Excel 表格
2. 表头黄色背景（FFFF00），文字加粗居中
3. 列宽根据内容调整，确保中英文完整显示
4. 多张图片合并为单个 Excel，每张独立工作表
5. 工作表名称清理特殊字符，限制 31 字符
6. 多图片文件自动添加 `00_说明` 首页
7. **翻译前加载术语库**，确保一致性
8. **翻译后执行术语一致性检查**，橙色标记不一致项
9. 术语库不存在时跳过术语匹配，翻译后创建新术语库
10. 生成文件保存在当前工作目录
