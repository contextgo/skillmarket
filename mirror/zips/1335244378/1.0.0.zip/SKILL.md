---
name: cloud-deploy
description: |
  Deploy web projects (static sites, frontend+backend, full-stack) to CloudBase (腾讯云开发).
  Use when user asks to deploy, host, publish, or launch a website, web app, or project.
  Handles CloudBase static hosting, Cloud Functions (云函数), CloudRun (云托管), NoSQL database,
  and API gateway configuration. Triggers on: deploy, host, publish, launch, 部署, 发布, 上线.
---

# Cloud Deploy

Generic CloudBase deployment workflow for any web project type.

## Deployment Decision Tree

```
1. Is there a backend (API, database)?
   NO  → Static Hosting only → Step 3 (Frontend)
   YES → Continue

2. What type of backend?
   Node.js/Express (simple API)    → Cloud Functions (函数型云托管)
   Multi-language or containers      → CloudRun (容器型云托管) — requires paid tier
   Heavy computation / long-running → CloudRun
   CloudRun unavailable?            → Fall back to Cloud Functions + NoSQL

3. Static assets?
   Pure HTML/JS/CSS → Static Hosting
   React/Vue build  → Build first, then Static Hosting
```

## Core Workflow

### Step 0 — Environment Check (ALWAYS FIRST)

```bash
# Check MCP status and env
npx mcporter call cloudbase.auth action=status --output json
```

Key questions before starting:
- Free tier? CloudRun (container) may not be available. Always have a Cloud Functions fallback ready.
- Already has cloud functions? Check `queryFunctions(action=listFunctions)` before creating new ones.

### Step 1 — Analyze the Project

```
Read the project's:
- README.md, CLAUDE.md, package.json
- server/ directory (backend code)
- deploy/ directory (Dockerfile, nginx.conf)
- Static files: index.html, js/, css/
```

Determine:
- Backend type (Express/Node, Python, Java, Go, PHP...)
- Database needs (NoSQL, MySQL, none)
- Static or built frontend

### Step 2 — Deploy Backend First

**Option A: Cloud Functions (Node.js)**

Use when: simple Express API, Node.js backend, free tier compatible.

```bash
# Create a proper cloudfunctions/<name>/ directory
mkdir -p cloudfunctions/<funcName>
# index.js + package.json
npx mcporter call cloudbase.manageFunctions \
  action=updateFunctionCode \
  functionName=<funcName> \
  functionRootPath=/path/to/project \
  cloudfunctionsPaths=<funcName>
```

**Option B: CloudRun (Container) — PAID TIER ONLY**

```bash
npx mcporter call cloudbase.manageCloudRun \
  action=deploy \
  serverName=<name> \
  targetPath=/path/to/project \
  serverConfig='{"OpenAccessTypes":["PUBLIC"],"Cpu":0.5,"Mem":1,"MinNum":1,"MaxNum":5}'
```

**Common CloudRun error**: `"云托管资源未开通"` → Free tier. Switch to Cloud Functions.

**Option C: Cloud Functions + NoSQL (stateless API)**

When CloudRun unavailable: convert API to Cloud Functions + NoSQL database.

1. Create NoSQL collections: `writeNoSqlDatabaseStructure(action=createCollection, collectionName=...)`
2. Write cloud function with `@cloudbase/node-sdk` database calls
3. Deploy: `manageFunctions(action=updateFunctionCode)`
4. Create HTTP access: `queryGateway(action=listDomains)` to find gateway URL

### Step 3 — Deploy Frontend

**Static files only:**

```bash
npx mcporter call cloudbase.uploadFiles \
  localPath=/path/to/project \
  cloudPath=/
```

**Get static hosting URL:**

```bash
npx mcporter call cloudbase.envQuery action=hosting --output json
# Returns: CdnDomain, Bucket
```

### Step 4 — Update Frontend API URLs

After backend is deployed, update frontend code:

```javascript
// BEFORE (local dev)
API_BASE: '/api'

// AFTER (cloud deployment)
API_BASE: 'https://<gateway-domain>/<api-path>'
```

### Step 5 — Cache Busting (CRITICAL)

CloudBase CDN aggressively caches static files. When updating static files:

**Do NOT re-upload the same filename.** Use versioned filenames:

```html
<!-- Before -->
<script src="js/app.js"></script>

<!-- After (cache bust) -->
<script src="js/app.v2.js"></script>
```

Then upload the new file and update HTML to reference it.

Alternatively: delete the file from COS first, then re-upload.

## Common Pitfalls

| Pitfall | Symptom | Fix |
|---------|---------|-----|
| CloudRun not available | `"云托管资源未开通"` | Use Cloud Functions fallback |
| CDN serves stale file | 404 on new code | Version filename (app.v2.js) or delete COS file first |
| Cloud Function body > 256KB | 413 Payload Too Large | Move large data (images) to cloud storage URL |
| Wrong API path | 404 from frontend | Test API with curl first; `/<funcName>` vs `/<funcName>-new` |
| Wrong API response field | `result.likes` undefined | Cloud Functions return `{ success, data: { likes } }` — check actual curl output |
| ID field mismatch | Delete/update fails | MongoDB returns `_id`, not `id`. Normalize in frontend: `id: p._id \|\| p.id` |
| CORS blocked | OPTIONS error | Cloud Functions handle CORS automatically; check `Access-Control-Allow-Origin` header |
| Security domain not set | Browser blocks request | Add domain in CloudBase console: envQuery(action=domains) |

## API Response Format

Cloud Functions return this structure:

```json
{
  "success": true,
  "data": { ... }
}
```

**When calling from frontend**, unwrap appropriately:

```javascript
const result = await cloudRequest('/api/likes', { method: 'POST' });
// Cloud Function returns: { success: true, data: { likes: 5 } }
const newCount = (result.data && result.data.likes) || 0;
```

## Verify Deployment

Always verify with curl before telling user it's done:

```bash
# Test static hosting
curl -s https://<cdn-domain>/

# Test API
curl -s https://<gateway-domain>/<funcName>/api/products
```

## Key Commands Reference

```bash
# Auth
npx mcporter call cloudbase.auth action=status --output json

# List existing cloud functions
npx mcporter call cloudbase.queryFunctions action=listFunctions --output json

# Get cloud function detail
npx mcporter call cloudbase.queryFunctions action=getFunctionDetail functionName=<name> --output json

# Deploy cloud function
npx mcporter call cloudbase.manageFunctions action=updateFunctionCode functionName=<name> functionRootPath=/path/to/project cloudfunctionsPaths=<funcDir> --output json

# List cloud run services
npx mcporter call cloudbase.queryCloudRun action=list --output json

# Static hosting config
npx mcporter call cloudbase.envQuery action=hosting --output json

# Upload static files
npx mcporter call cloudbase.uploadFiles localPath=/path/to/project cloudPath=/ --output json

# Check gateway / API paths
npx mcporter call cloudbase.queryGateway action=listDomains --output json
npx mcporter call cloudbase.queryGateway action=getAccess targetName=<funcName> --output json

# Database collections
npx mcporter call cloudbase.writeNoSqlDatabaseStructure action=createCollection collectionName=<name> --output json
npx mcporter call cloudbase.readNoSqlDatabaseContent collectionName=<name> --output json
```