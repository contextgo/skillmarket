# Frontend Integration Patterns

## API URL Configuration

### Static Dev (localhost)
```javascript
API_BASE: '/api'   // proxy through webpack/vite dev server
```

### Cloud Deployment
```javascript
API_BASE: 'https://<gateway-domain>/<functionName>'
// Example:
API_BASE: 'https://openclaw-01-xxx.service.tcloudbase.com/xundao-api-new'
```

## Response Handling

Cloud Functions return `{ success: true, data: {...} }`. Always unwrap:

```javascript
// GET request — data is an array or object
const result = await cloudRequest('/api/products', { method: 'GET' });
const products = result.data;  // NOT result.data.data

// POST request — data is the created object
const saved = result.data;
saved.id = saved._id || saved.id;  // normalize _id → id

// Like/toggle request — data contains the new count
const newCount = (result.data && result.data.likes) || 0;
```

## ID Normalization

CloudBase NoSQL uses `_id`. Most frontends use `id`. Normalize at the boundary:

```javascript
// When reading from API
const list = result.data.map(p => ({ ...p, id: p._id || p.id }));

// When deleting
cached.filter(p => (p._id || p.id) !== id);

// When finding
products.find(p => (p._id || p.id) === id);

// In HTML templates
data-id="${product._id || product.id}"
onclick="handleDelete('${product._id || product.id}')"
```

## CDN Cache Busting

CloudBase CDN caches static files aggressively. **Updating a file with the same name may not propagate for hours.**

### Method 1 — Versioned Filenames (RECOMMENDED)

```html
<!-- Version bump each deploy -->
<script src="js/app.js"></script>
<!-- becomes after update -->
<script src="js/app.v2.js"></script>
```

```bash
# Create new version
cp js/app.js js/app.v2.js
# Upload
npx mcporter call cloudbase.uploadFiles localPath=. cloudPath=/ --output json
# Verify
curl -s https://<cdn>/js/app.v2.js | grep "API_BASE"
```

### Method 2 — Delete COS file first

```bash
npx mcporter call cloudbase.manageStorage action=delete localPath=/path cloudPath=/old-file.js force=true
# Then re-upload same filename
```

### Method 3 — Query string cache bust (less reliable)

```html
<script src="js/app.js?v=12345"></script>
```

## CORS Issues

If browser shows CORS error:
1. Check CloudBase security domains: `envQuery(action=domains)`
2. Cloud Functions handle CORS automatically via gateway
3. If still failing, verify the gateway path is correct (not `*` blocking)

## Form Submission with Images

Cloud Functions have 256KB body limit. **Never send images as base64.**

### Pattern: URL Reference for Images

```html
<!-- Admin form: URL input instead of file upload -->
<label>图片链接</label>
<input type="url" id="productImageUrl" placeholder="https://...">
```

```javascript
// Admin form handler
const image = document.getElementById('productImageUrl').value.trim();
// Store URL, not base64
await addProduct({ title, description, image, link });
```

### Pattern: Upload to Cloud Storage First

If you need actual file upload:
1. Use `manageStorage(action=upload)` from MCP to upload to COS
2. Get CDN URL
3. Store URL in database (not base64)

## Error Handling

### API Error: 413 Payload Too Large
- Cause: Request body > 256KB (usually base64 image)
- Fix: Switch to URL reference pattern

### API Error: 404 Not Found
- Cause: Wrong gateway path
- Fix: `queryGateway(action=getAccess, targetName=...)` to find correct URL

### API Error: 500 Function Error
- Cause: Function code crashed
- Fix: Check logs with `listFunctionLogs`

### Stale Data After Deploy
- Cause: Frontend using old cached JS with wrong API URLs
- Fix: Cache bust with new filename (app.v2.js)

## Admin Form Validation Pattern

Always validate before sending to API:

```javascript
async function handleAddProduct(e) {
  e.preventDefault();
  const title = document.getElementById('productTitle').value.trim();
  const description = document.getElementById('productDescription').value.trim();
  const image = document.getElementById('productImageUrl').value.trim();
  const link = document.getElementById('productLink').value;

  // Client-side validation
  if (!title || !description) {
    alert('请填写标题和描述');
    return;
  }

  const result = await XUNDAO.products.addProduct({ title, description, image, link });

  // Handle failure
  if (!result) return;  // addProduct already showed error alert

  // Success
  await renderProductList();
  alert('发布成功');
  e.target.reset();
}
```

## Async/Await in Render Functions

Render functions that fetch data must be async:

```javascript
// CORRECT
async function renderProducts() {
  const products = await XUNDAO.products.getProducts();
  const allLikes = await XUNDAO.likes.getLikes();
  // render...
}

// Call with IIFE or event listener
(async () => { await renderProducts(); })();
```

## hasLiked Sync Check

`hasLiked` uses localStorage (sync), not async:

```javascript
// In template
const hasLiked = XUNDAO.likes.hasLiked(pid);  // sync — reads localStorage directly

// NOT — this would return a Promise
const hasLiked = await XUNDAO.likes.hasLiked(pid);  // WRONG
```