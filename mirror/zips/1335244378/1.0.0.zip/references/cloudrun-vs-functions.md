# CloudRun vs Cloud Functions

## Decision Guide

| Criteria | Cloud Functions | CloudRun (Container) |
|----------|---------------|---------------------|
| **Cost** | Free tier available | Paid only |
| **Runtime** | Node.js 18.x only | Any language |
| **Body limit** | 256 KB | 256 KB |
| **Startup** | ~100ms cold start | ~1-3s cold start |
| **Complexity** | Simple, file-based deploy | Need Dockerfile |
| **Storage** | Ephemeral `/tmp` only | Can mount volumes |
| **Multi-file** | One .js file per function | Full project |
| **Best for** | Simple APIs, webhooks | Python, Go, Java, existing containers |

## CloudRun Availability Check

```bash
npx mcporter call cloudbase.queryCloudRun action=list --output json
```

If error: `"云托管资源未开通"` → Free tier. Use Cloud Functions fallback.

## Cloud Functions Structure

```
cloudfunctions/
└── <functionName>/
    ├── index.js        # exports.main
    └── package.json   # dependencies
```

index.js template:
```javascript
const cloudbase = require('@cloudbase/node-sdk');
const tcb = cloudbase.init({ env: cloudbase.SYMBOL_CURRENT_ENV });
const db = tcb.database();

exports.main = async (event, context) => {
  // event.httpMethod, event.path, event.body
  const httpMethod = event.httpMethod || event.method;
  const path = event.path || event.url;
  let body = event.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch(e) { body = {}; }
  }

  // Route
  if (httpMethod === 'GET' && path === '/api/products') {
    // ...
  }

  return { success: true, data: result };
};
```

## Response Wrapping

Cloud Functions **wrap** all responses. Never return raw data.

```javascript
// CORRECT — wrapped
return { success: true, data: { likes: 5 } };

// WRONG — raw (frontend can't unwrap)
return { likes: 5 };
```

## Gateway Path Discovery

After deploying a function, find its HTTP access path:

```bash
# List gateway domains
npx mcporter call cloudbase.queryGateway action=listDomains --output json
# Returns: DefaultDomain like openclaw-01-xxx.service.tcloudbase.com

# Get function's path
npx mcporter call cloudbase.queryGateway action=getAccess targetName=<functionName> --output json
# Returns urls array: ["https://<domain>/<funcName>"]
```

There may be multiple paths (e.g., `/funcName` and `/funcName-new`). Use the latest one.

## NoSQL Database from Cloud Functions

```javascript
const db = tcb.database();

// Add document
const res = await db.collection('products').add({
  data: { title: '...', description: '...' }
});
// res.id → the document _id

// Query
const result = await db.collection('products').get();

// Update
await db.collection('products').doc(id).update({ field: value });

// Delete
await db.collection('products').doc(id).remove();
```

## Error: FUNCTION_EXECUTE_FAIL

Usually means the function code crashed. Check logs:

```bash
npx mcporter call cloudbase.queryFunctions action=listFunctionLogs functionName=<name> --output json
npx mcporter call cloudbase.queryFunctions action=getFunctionLogDetail functionName=<name> requestId=<id> --output json
```

Common causes:
- Syntax error in index.js
- Wrong `require('@cloudbase/node-sdk')` usage
- Database collection doesn't exist → create first with `writeNoSqlDatabaseStructure`

## Deploy Cloud Function

```bash
npx mcporter call cloudbase.manageFunctions \
  action=updateFunctionCode \
  functionName=<existingFuncName> \
  functionRootPath=/path/to/project \
  cloudfunctionsPaths=<funcDirName>
```

Common error: `"paths[0] argument must be of type string"` → functionRootPath not absolute or cloudfunctionsPaths wrong.

Tip: If function doesn't exist yet, you need `createFunction` instead. Check existing names first:

```bash
npx mcporter call cloudbase.queryFunctions action=listFunctions --output json
```