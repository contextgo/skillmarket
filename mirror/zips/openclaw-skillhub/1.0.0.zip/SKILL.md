---
name: openclaw-skillhub
description: 使用 SkillHub 安装和管理 OpenClaw Skills。用于安装、更新、搜索 SkillHub 技能库中的技能。触发场景：(1) 用户想要安装新的 skill，(2) 用户想要搜索 skill，(3) 用户想要更新已安装的 skill，(4) 用户提到 skillhub。
---

# OpenClaw SkillHub

用于通过 SkillHub 安装和管理 OpenClaw Skills。

## 安装目录

OpenClaw Skills 目录优先级（从高到低）：

| 优先级 | 目录 |
|--------|------|
| 1 | `<workspace>/skills` |
| 2 | `<workspace>/.agents/skills` |
| 3 | `~/.agents/skills` |
| 4 | `~/.openclaw/skills` |
| 5 | 内置 skills |

**推荐安装到 workspace 目录：**
```
~/.openclaw/workspace/skills
```

## 安装命令

```bash
# 安装 skill 到 workspace（--dir 放在 install 前面）
skillhub --dir ~/.openclaw/workspace/skills install <skill-name> --force

# 示例：安装 weather skill
skillhub --dir ~/.openclaw/workspace/skills install weather --force

# 搜索 skill
skillhub search <关键词>

# 列出已安装的 skills
skillhub list

# 升级已安装的 skills
skillhub upgrade
```

## 常用 Skills（SkillHub 下载热榜）

### 热门 AI 增强
- self-improving - 主动式自我提升智能体
- proactive-agent - 主动式智能体
- nano-banana-pro - Nano Banana Pro
- humanizer - AI 生成文字人性化

### 信息处理
- summarize - 文本总结
- pdf - PDF 处理

### 办公效率
- word-docx - Word 文档处理
- excel-xlsx - Excel 表格处理
- powerpoint-pptx - PPT 演示文稿

### 搜索与工具
- multi-search-engine - 多搜索引擎集成
- find-skills - 技能查找
- web-tools-guide - Web 工具指南
- agent-browser - 浏览器自动化

### 开发工具
- github - GitHub 集成
- codeconductor - 代码指挥家

### 知识管理
- ontology - 知识图谱
- obsidian - Obsidian 笔记

### 垂直场景
- weather - 天气查询
- stock-analysis - 股票分析
- akshare-stock - A股股票数据

### 其他实用
- skill-vetter - 技能安全审核
- desktop-control - 桌面控制

## 注意

- `--dir` 参数必须放在 `install` 子命令之前
- 使用 `--force` 覆盖已存在的 skill
- 安装后 OpenClaw 会自动感知新 skill（无需重启）