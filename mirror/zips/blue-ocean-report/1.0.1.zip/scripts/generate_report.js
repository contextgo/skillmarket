/**
 * =====================================================
 * 蓝海市场分析报告生成器 - 通用版
 * =====================================================
 * 功能：生成专业的蓝海市场分析Word报告
 * 用法：修改 REPORT_CONFIG 对象配置报告参数
 * 输出：Word文档保存到桌面
 * =====================================================
 */

const docx = require('docx');
const fs = require('fs');
const path = require('path');

// ==================== 报告配置（修改这里） ====================
const REPORT_CONFIG = {
    // 产品/行业信息
    productName: "产品名称",
    productNameEn: "Product Name",
    reportDate: new Date().toISOString().split('T')[0].replace(/-/g, '年').replace(/T.*/, '月').split('月')[0] + '月',
    analystName: "蓝海研究团队",

    // 一、市场规模数据
    marketSize: {
        currentValue: "X亿美元",      // 当前市场规模
        baseYear: "2024年",          // 基准年份
        forecastValue: "X-Y亿美元",   // 预测市场规模
        forecastYear: "2030年",      // 预测年份
        cagr: "X%",                  // 复合增长率
        currency: "美元"             // 货币单位
    },

    // 二、市场驱动因素（5-8个）
    marketDrivers: [
        "驱动因素1：描述",
        "驱动因素2：描述",
        "驱动因素3：描述",
        "驱动因素4：描述",
        "驱动因素5：描述"
    ],

    // 三、区域分布
    regionalDistribution: [
        { region: "北美", share: "X%", cagr: "X%", feature: "特点描述" },
        { region: "欧洲", share: "X%", cagr: "X%", feature: "特点描述" },
        { region: "亚太", share: "X%", cagr: "X%", feature: "特点描述" },
        { region: "拉美", share: "X%", cagr: "X%", feature: "特点描述" },
        { region: "其他", share: "X%", cagr: "X%", feature: "特点描述" }
    ],

    // 四、市场分层
    marketLayers: [
        { level: "高端市场", brands: "品牌A、品牌B", priceRange: "$X-Y", feature: "特点描述" },
        { level: "中端市场", brands: "品牌C、品牌D", priceRange: "$X-Y", feature: "特点描述" },
        { level: "低端市场", brands: "白牌/本地厂商", priceRange: "$X-Y", feature: "特点描述" }
    ],

    // 五、主要玩家分析
    players: [
        { name: "品牌A", analysis: "优势：XXX | 劣势：XXX | 市占率：XX%" },
        { name: "品牌B", analysis: "优势：XXX | 劣势：XXX | 市占率：XX%" },
        { name: "品牌C", analysis: "优势：XXX | 劣势：XXX | 市占率：XX%" },
        { name: "品牌D", analysis: "优势：XXX | 劣势：XXX | 市占率：XX%" }
    ],

    // 六、竞争真空区
    competitionGaps: [
        "真空区1：描述（为什么存在机会）",
        "真空区2：描述",
        "真空区3：描述"
    ],

    // 七、蓝海机会矩阵
    opportunities: [
        {
            name: "蓝海机会1",
            competition: "低/中/高",
            profitMargin: "XX-XX%",
            marketSize: "X亿美元",
            entryBarrier: "低/中/高",
            score: 4.5,  // 评分 1-5
            priority: "⭐⭐⭐⭐⭐"
        },
        {
            name: "蓝海机会2",
            competition: "中",
            profitMargin: "XX-XX%",
            marketSize: "X亿美元",
            entryBarrier: "中",
            score: 4.0,
            priority: "⭐⭐⭐⭐"
        },
        {
            name: "蓝海机会3",
            competition: "中",
            profitMargin: "XX-XX%",
            marketSize: "X亿美元",
            entryBarrier: "中",
            score: 3.5,
            priority: "⭐⭐⭐⭐"
        }
    ],

    // 八、机会详细分析
    opportunityDetails: [
        {
            id: 1,
            name: "机会1名称",
            priority: "⭐⭐⭐⭐⭐",
            targetCustomer: "目标客户描述（Who）",
            painPoints: [
                "痛点1：描述",
                "痛点2：描述",
                "痛点3：描述"
            ],
            marketSize: "市场规模描述",
            competitionLevel: "竞争度描述",
            profitMargin: "利润率描述",
            entryStrategy: [
                "切入方式1：具体做法",
                "切入方式2：具体做法",
                "切入方式3：具体做法"
            ],
            successFactors: [
                "成功要素1",
                "成功要素2"
            ]
        }
    ],

    // 九、风险提示
    risks: [
        { type: "技术风险", description: "风险描述和影响" },
        { type: "市场风险", description: "风险描述和影响" },
        { type: "竞争风险", description: "风险描述和影响" },
        { type: "政策风险", description: "风险描述和影响" },
        { type: "运营风险", description: "风险描述和影响" }
    ],

    // 十、MVP验证计划
    mvpPhases: [
        {
            name: "阶段一：市场验证",
            duration: "1-2个月",
            budget: "$X,XXX-X,XXX",
            actions: [
                "行动1：具体任务",
                "行动2：具体任务",
                "行动3：具体任务"
            ],
            successCriteria: "验证成功的标准"
        },
        {
            name: "阶段二：小批量测试",
            duration: "2-3个月",
            budget: "$XX,XXX-XX,XXX",
            actions: [
                "行动1：具体任务",
                "行动2：具体任务",
                "行动3：具体任务"
            ],
            successCriteria: "验证成功的标准"
        },
        {
            name: "阶段三：规模验证",
            duration: "3-6个月",
            budget: "$XX,XXX-XX,XXX",
            actions: [
                "行动1：具体任务",
                "行动2：具体任务",
                "行动3：具体任务"
            ],
            successCriteria: "验证成功的标准"
        }
    ],

    // 十一、优先推荐
    recommendations: [
        {
            priority: "🏆 第一优先",
            name: "推荐机会名称",
            reasons: [
                "推荐理由1：量化说明",
                "推荐理由2：量化说明",
                "推荐理由3：量化说明"
            ],
            expectedROI: "预期回报XX%"
        },
        {
            priority: "🥈 第二优先",
            name: "次选机会名称",
            reasons: [
                "推荐理由1",
                "推荐理由2"
            ],
            expectedROI: "预期回报XX%"
        }
    ],

    // 十二、数据来源
    dataSources: [
        "数据来源1：机构名称，URL或报告名称",
        "数据来源2：机构名称，URL或报告名称",
        "数据来源3：机构名称，URL或报告名称",
        "数据来源4：机构名称，URL或报告名称"
    ]
};

// ==================== 样式配置 ====================
const STYLES = {
    // 配色方案
    colors: {
        primary: "1A5276",      // 深蓝
        secondary: "2980B9",    // 中蓝
        accent: "3498DB",       // 亮蓝
        highlight: "5DADE2",    // 浅蓝
        dark: "1C2833",         // 深灰蓝
        text: "2C3E50",         // 正文色
        lightBg: "EBF5FB",      // 浅蓝背景
        tableHeader: "2471A3"   // 表格表头
    },

    // 字体
    fonts: {
        primary: "微软雅黑",
        secondary: "Arial",
        heading: "微软雅黑"
    }
};

// ==================== 辅助函数 ====================

/**
 * 创建星级评分
 */
function getStars(score) {
    const fullStars = Math.floor(score);
    const halfStar = score % 1 >= 0.5 ? 1 : 0;
    return '⭐'.repeat(fullStars) + (halfStar ? '⭐' : '');
}

/**
 * 创建表格
 */
function createTable(headers, rows, options = {}) {
    const { headerBg = STYLES.colors.tableHeader } = options;

    const headerRow = new TableRow({
        children: headers.map(h => new TableCell({
            children: [new Paragraph({
                text: h,
                bold: true,
                color: "FFFFFF"
            })],
            shading: { fill: headerBg },
            width: { size: 100 / headers.length, type: WidthType.PERCENTAGE }
        }))
    });

    const dataRows = rows.map((row, idx) => new TableRow({
        children: row.map(cell => new TableCell({
            children: [new Paragraph({ text: String(cell) })],
            shading: { fill: idx % 2 === 0 ? "FFFFFF" : "F4F6F7" }
        }))
    }));

    return new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [headerRow, ...dataRows]
    });
}

/**
 * 创建机会矩阵表格
 */
function createOpportunityTable(opportunities) {
    const headers = ["蓝海机会", "竞争度", "利润率", "市场规模", "进入门槛", "评分", "优先级"];
    const rows = opportunities
        .sort((a, b) => b.score - a.score)
        .map(op => [
            op.name,
            op.competition,
            op.profitMargin,
            op.marketSize,
            op.entryBarrier,
            op.score.toFixed(1),
            op.priority
        ]);

    return createTable(headers, rows);
}

// ==================== 报告生成器 ====================

class BlueOceanReport {
    constructor(config) {
        this.config = config;
        this.children = [];
    }

    // 添加段落
    addParagraph(text, options = {}) {
        this.children.push(new Paragraph({
            text,
            spacing: { after: options.spacing || 200 },
            ...options
        }));
    }

    // 添加带样式的段落
    addStyledParagraph(runs, options = {}) {
        this.children.push(new Paragraph({
            children: runs.map(r => new TextRun(r)),
            spacing: { after: options.spacing || 200 },
            ...options
        }));
    }

    // 添加标题
    addHeading(text, level = 1) {
        const headingMap = {
            1: HeadingLevel.HEADING_1,
            2: HeadingLevel.HEADING_2,
            3: HeadingLevel.HEADING_3
        };
        this.children.push(new Paragraph({
            text,
            heading: headingMap[level],
            spacing: { after: 300 }
        }));
    }

    // 添加分页
    addPageBreak() {
        this.children.push(new Paragraph({ pageBreakBefore: true }));
    }

    // 生成封面
    generateCover() {
        this.addParagraph("", { spacing: { after: 2000 } });

        this.addParagraph(this.config.productName, {
            heading: HeadingLevel.TITLE,
            alignment: AlignmentType.CENTER,
            spacing: { after: 400 }
        });

        this.addParagraph(this.config.productNameEn, {
            alignment: AlignmentType.CENTER,
            spacing: { after: 800 }
        });

        this.addParagraph("蓝海市场分析报告", {
            alignment: AlignmentType.CENTER,
            spacing: { after: 600 },
            bold: true
        });

        this.addParagraph(this.config.analystName, {
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 }
        });

        this.addParagraph(this.config.reportDate, {
            alignment: AlignmentType.CENTER
        });

        this.addPageBreak();
    }

    // 生成目录
    generateTOC() {
        this.addHeading("目  录", 1);
        this.addParagraph("一、行业现状概览", { spacing: { after: 200 } });
        this.addParagraph("二、竞争格局分析", { spacing: { after: 200 } });
        this.addParagraph("三、蓝海机会识别", { spacing: { after: 200 } });
        this.addParagraph("四、机会详细分析", { spacing: { after: 200 } });
        this.addParagraph("五、风险与挑战", { spacing: { after: 200 } });
        this.addParagraph("六、MVP验证步骤", { spacing: { after: 200 } });
        this.addParagraph("七、战略建议", { spacing: { after: 200 } });
        this.addParagraph("八、数据来源", { spacing: { after: 400 } });
        this.addPageBreak();
    }

    // 生成第一章
    generateChapter1() {
        this.addHeading("一、行业现状概览", 1);

        // 1.1 市场规模
        this.addHeading("1.1 市场规模与增长", 2);
        this.addStyledParagraph([
            { text: "当前市场规模：", bold: true },
            { text: `${this.config.marketSize.currentValue}（${this.config.marketSize.baseYear}）` }
        ]);
        this.addStyledParagraph([
            { text: "市场预测：", bold: true },
            { text: `预计${this.config.marketSize.forecastYear}增长至${this.config.marketSize.forecastValue}` }
        ]);
        this.addStyledParagraph([
            { text: "复合增长率：", bold: true },
            { text: this.config.marketSize.cagr }
        ], { spacing: { after: 400 } });

        // 1.2 市场驱动因素
        this.addHeading("1.2 市场驱动因素", 2);
        this.config.marketDrivers.forEach(driver => {
            this.addParagraph(`• ${driver}`, { spacing: { after: 150 } });
        });
        this.addParagraph("", { spacing: { after: 200 } });

        // 1.3 区域分布
        this.addHeading("1.3 区域市场分布", 2);
        const regionalHeaders = ["区域", "市场份额", "CAGR", "市场特点"];
        const regionalRows = this.config.regionalDistribution.map(r => [
            r.region, r.share, r.cagr, r.feature
        ]);
        this.children.push(createTable(regionalHeaders, regionalRows));
        this.addParagraph("", { spacing: { after: 400 } });

        this.addPageBreak();
    }

    // 生成第二章
    generateChapter2() {
        this.addHeading("二、竞争格局分析", 1);

        // 2.1 市场分层
        this.addHeading("2.1 市场分层", 2);
        const layerHeaders = ["市场层级", "代表品牌", "价格区间", "特点"];
        const layerRows = this.config.marketLayers.map(l => [
            l.level, l.brands, l.priceRange, l.feature
        ]);
        this.children.push(createTable(layerHeaders, layerRows));
        this.addParagraph("", { spacing: { after: 400 } });

        // 2.2 主要玩家
        this.addHeading("2.2 主要玩家分析", 2);
        this.config.players.forEach(player => {
            this.addStyledParagraph([
                { text: `${player.name}：`, bold: true },
                { text: player.analysis }
            ], { spacing: { after: 200 } });
        });

        // 2.3 竞争真空区
        this.addHeading("2.3 竞争真空区识别", 2);
        this.config.competitionGaps.forEach(gap => {
            this.addParagraph(`• ${gap}`, { spacing: { after: 150 } });
        });
        this.addParagraph("", { spacing: { after: 400 } });

        this.addPageBreak();
    }

    // 生成第三章
    generateChapter3() {
        this.addHeading("三、蓝海机会识别", 1);
        this.addParagraph("基于市场规模、竞争度、利润率、进入门槛四个维度的综合评估，识别出以下蓝海机会：", { spacing: { after: 300 } });

        this.children.push(createOpportunityTable(this.config.opportunities));
        this.addParagraph("", { spacing: { after: 400 } });

        this.addPageBreak();
    }

    // 生成第四章
    generateChapter4() {
        this.addHeading("四、机会详细分析", 1);

        this.config.opportunityDetails.forEach((opp, idx) => {
            this.addHeading(`${idx + 1}. ${opp.name} ${opp.priority}`, 2);

            this.addStyledParagraph([
                { text: "目标客户：", bold: true },
                { text: opp.targetCustomer }
            ], { spacing: { after: 150 } });

            this.addParagraph("客户痛点：", { spacing: { after: 100 } });
            opp.painPoints.forEach(p => {
                this.addParagraph(`• ${p}`, { spacing: { after: 100 } });
            });

            this.addStyledParagraph([
                { text: "市场规模：", bold: true },
                { text: opp.marketSize }
            ], { spacing: { after: 150 } });

            this.addStyledParagraph([
                { text: "竞争度：", bold: true },
                { text: opp.competitionLevel }
            ], { spacing: { after: 150 } });

            this.addStyledParagraph([
                { text: "利润率：", bold: true },
                { text: opp.profitMargin }
            ], { spacing: { after: 150 } });

            this.addParagraph("切入方式：", { spacing: { after: 100 } });
            opp.entryStrategy.forEach(s => {
                this.addParagraph(`• ${s}`, { spacing: { after: 100 } });
            });

            this.addParagraph("成功要素：", { spacing: { after: 100 } });
            opp.successFactors.forEach(f => {
                this.addParagraph(`• ${f}`, { spacing: { after: 100 } });
            });

            this.addParagraph("", { spacing: { after: 400 } });
        });

        this.addPageBreak();
    }

    // 生成第五章
    generateChapter5() {
        this.addHeading("五、风险与挑战", 1);

        this.config.risks.forEach(risk => {
            this.addStyledParagraph([
                { text: `• ${risk.type}：`, bold: true },
                { text: risk.description }
            ], { spacing: { after: 200 } });
        });

        this.addParagraph("", { spacing: { after: 400 } });
        this.addPageBreak();
    }

    // 生成第六章
    generateChapter6() {
        this.addHeading("六、MVP验证步骤", 1);

        this.config.mvpPhases.forEach((phase, idx) => {
            this.addStyledParagraph([
                { text: `${phase.name}`, bold: true },
                { text: `（${phase.duration}）` }
            ], { spacing: { after: 150 } });

            this.addStyledParagraph([
                { text: "预算：", bold: true },
                { text: phase.budget }
            ], { spacing: { after: 100 } });

            phase.actions.forEach(action => {
                this.addParagraph(`• ${action}`, { spacing: { after: 100 } });
            });

            this.addStyledParagraph([
                { text: "成功标准：", bold: true },
                { text: phase.successCriteria }
            ], { spacing: { after: 300 } });
        });

        this.addPageBreak();
    }

    // 生成第七章
    generateChapter7() {
        this.addHeading("七、战略建议", 1);

        this.config.recommendations.forEach(rec => {
            this.addStyledParagraph([
                { text: `${rec.priority}：`, bold: true, size: 28 },
                { text: rec.name }
            ], { spacing: { after: 200 } });

            rec.reasons.forEach((reason, idx) => {
                this.addParagraph(`${idx + 1}. ${reason}`, { spacing: { after: 100 } });
            });

            this.addStyledParagraph([
                { text: "预期回报：", bold: true },
                { text: rec.expectedROI }
            ], { spacing: { after: 400 } });
        });

        this.addPageBreak();
    }

    // 生成第八章
    generateChapter8() {
        this.addHeading("八、数据来源", 1);
        this.addParagraph("本报告数据来源于以下渠道：", { spacing: { after: 200 } });

        this.config.dataSources.forEach(source => {
            this.addParagraph(`• ${source}`, { spacing: { after: 150 } });
        });

        this.addParagraph("", { spacing: { after: 300 } });

        this.addParagraph("免责声明：", { bold: true, spacing: { after: 100 } });
        this.addParagraph("本报告仅供参考。数据来源于公开渠道，存在时效性和统计口径差异。预测数据基于合理假设，实际结果可能存在差异。做出投资或商业决策前，请结合最新市场信息进行独立判断。", {
            italics: true,
            spacing: { after: 200 }
        });

        this.addParagraph(`报告生成时间：${new Date().toLocaleString('zh-CN')}`, {
            italics: true
        });
    }

    // 生成完整报告
    generate() {
        this.generateCover();
        this.generateTOC();
        this.generateChapter1();
        this.generateChapter2();
        this.generateChapter3();
        this.generateChapter4();
        this.generateChapter5();
        this.generateChapter6();
        this.generateChapter7();
        this.generateChapter8();

        return new Document({
            styles: {
                default: {
                    document: {
                        run: {
                            font: STYLES.fonts.primary,
                            size: 24  // 12pt
                        }
                    }
                }
            },
            sections: [{
                properties: {},
                children: this.children
            }]
        });
    }
}

// ==================== 主程序 ====================

function main() {
    // 生成报告
    const report = new BlueOceanReport(REPORT_CONFIG);
    const doc = report.generate();

    // 输出路径
    const outputPath = path.join(
        process.env.USERPROFILE || process.env.HOME || 'C:\\Users\\alex',
        'Desktop',
        `${REPORT_CONFIG.productName}蓝海市场分析报告.docx`
    );

    // 保存文档
    docx.Packer.toBuffer(doc).then(buffer => {
        fs.writeFileSync(outputPath, buffer);
        console.log(`\n✅ 报告生成成功！`);
        console.log(`📄 文件位置：${outputPath}`);
        console.log(`📊 产品/行业：${REPORT_CONFIG.productName}`);
        console.log(`📅 生成时间：${new Date().toLocaleString('zh-CN')}\n`);
    }).catch(err => {
        console.error(`\n❌ 生成失败：${err.message}`);
        process.exit(1);
    });
}

// 导出类供外部调用
module.exports = { BlueOceanReport, REPORT_CONFIG, STYLES };

// 直接运行
if (require.main === module) {
    main();
}
