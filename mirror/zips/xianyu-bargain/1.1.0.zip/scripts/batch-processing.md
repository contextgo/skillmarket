# 闲鱼批量砍价 - 状态管理

## 批量任务索引文件

位置: `~/.openclaw/workspace/xianyu-bargain-state/batch-index.json`

```json
{
  "activeTasks": [
    {
      "itemId": "1029661015986",
      "name": "17Pro 512G",
      "target": 6200,
      "max": 6500,
      "status": "active",
      "cronJobId": "xxx"
    }
  ],
  "completedTasks": [],
  "failedTasks": []
}
```

## 批量输入格式

用户可以用以下格式提交多个商品：

### 格式1: 简洁列表
```
批量砍价：
https://www.goofish.com/item?id=111 目标4500 底价4800
https://www.goofish.com/item?id=222 目标6200 底价6500
https://www.goofish.com/item?id=333 目标3000 底价3200
```

### 格式2: 表格格式
```
批量砍价：
| 链接 | 目标价 | 底价 |
| https://...?id=111 | 4500 | 4800 |
| https://...?id=222 | 6200 | 6500 |
```

### 格式3: JSON格式
```json
{
  "items": [
    {"url": "https://...?id=111", "target": 4500, "max": 4800},
    {"url": "https://...?id=222", "target": 6200, "max": 6500}
  ]
}
```

## 批量处理流程

1. 解析用户输入，提取所有商品信息
2. 对每个商品：
   - 获取商品详情
   - 创建状态文件
   - 发送首轮砍价消息
   - 创建监控 cron job
3. 更新批量索引文件
4. 返回汇总结果

## 批量状态查询

命令: `砍价进度` / `批量状态`

输出示例:
```
📊 批量砍价状态 (3个任务)

✅ 进行中 (2)
  1. iPhone 17 Pro - ¥6200/6500 - 等待回复
  2. AirPods Pro - ¥650/700 - 卖家已还价680

🎉 成功 (1)  
  3. iPad Air - ¥3200成交 (省¥300)

使用 "停止砍价 [商品名/ID]" 停止单个
使用 "停止全部砍价" 停止所有
```

## 批量停止

- `停止砍价 17Pro` - 停止单个
- `停止全部砍价` - 停止所有任务
