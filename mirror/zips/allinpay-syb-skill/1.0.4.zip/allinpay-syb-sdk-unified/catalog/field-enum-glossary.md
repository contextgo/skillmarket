# Field & Enum Glossary

该词典仅收录“已核验且稳定”的字段与枚举。  
原则：宁可少，不写错；有接口差异时，必须标注适用范围。

## 一、通用字段（稳定）

| 字段 | 中文说明 | 典型取值/格式 | 备注 |
|---|---|---|---|
| `orgid` | 集团/代理商商户号 | 15位 | 共享集团号/代理商参数时必填 |
| `cusid` | 商户号 | 平台分配 | 一般必填 |
| `appid` | 应用ID | 平台分配 | 一般必填 |
| `version` | 版本号 | 依接口文档 | 不同接口默认值可能不同 |
| `reqsn` | 商户订单号 | 商户侧唯一 | 幂等关键字段 |
| `trxamt` | 交易金额 | 单位分 | 100元=10000 |
| `notify_url` | 异步通知地址 | 可公网直连URL | 不能带参数，https默认端口 |
| `front_url` | 页面跳转地址 | URL | 仅支持前端跳转接口场景 |
| `randomstr` | 随机串 | 32位随机 | 用于签名 |
| `signtype` | 签名类型 | 见“签名枚举” | 不同接口支持集可能不同 |
| `sign` | 签名值 | 字符串 | 按签名规范生成 |

## 二、响应字段（稳定）

说明：表内“字段”列为**响应报文 JSON 字段名**（多为全小写）；Java 必须用 **SDK 真实 getter**（驼峰分段）。常见误拼：JSON `retcode` **不是** `getRetcode()`，而是基类 `getRetCode()`（`Code` 首字母大写）；同理 `retmsg` → `getRetMsg()`，`errmsg`（若响应类含该字段）→ `getErrMsg()`。

| JSON 字段 | 中文说明 | Java 属性 / getter | 备注 |
|---|---|---|---|
| `retcode` | 通信返回码 | `retCode` / `getRetCode()` | 基类 `AllinpayResp`；仅表示通信是否成功 |
| `retmsg` | 通信返回说明 | `retMsg` / `getRetMsg()` | 基类 `AllinpayResp`；通信层描述 |
| `trxstatus` | 交易状态码 | `trxStatus` / `getTrxStatus()` | 交易结果以接口文档定义为准 |
| `trxid` | 平台交易流水号 | `trxId` / `getTrxId()` | 基类 `AllinpayResp`；平台侧主键 |
| `chnltrxid` | 渠道流水号 | `chnlTrxId` / `getChnlTrxId()` | 微信/支付宝/银联渠道流水 |
| `fintime` | 交易完成时间 | `finTime` / `getFinTime()` | `yyyyMMddHHmmss` |
| `errmsg` | 错误原因 | `errMsg` / `getErrMsg()` | 以具体 `*Response` 为准；失败排查关键字段 |

## 三、枚举（已核验）

### 1) `retcode`（收银宝接口返回码）

适用范围：收银宝接口通用返回字段 `retcode`。

| 值 | 中文 |
|---|---|
| `SUCCESS` | 通信成功（不代表交易成功） |
| `PARAMERR` | 请求参数错误 |
| `SIGNAUTHERR` | 签名或 API 权限不足 |
| `FAIL` | 通信失败 |
| `SYSTEMERR` | 系统异常（实时交易建议查询确认） |

说明：部分文档按版本描述为“接口版本号为空或版本号 >=11”支持 `SUCCESS/FAIL/SYSTEMERR`，并在“接口版本号 >=11”补充 `PARAMERR/SIGNAUTHERR`。实际以接口返回为准，超出本表值禁止臆造语义。

### 2) `trxstatus`（收银宝交易状态码）

适用范围：收银宝交易结果字段 `trxstatus`。

| 值 | 中文 |
|---|---|
| `0000` | 交易成功 |
| `1001` | 交易不存在 |
| `2000` | 交易处理中 |
| `2008` | 交易处理中 |
| `3008` | 商户余额不足 |
| `3014` | 交易金额小于应收手续费 |
| `3024` | 退款频率限制（建议 30 秒后再试） |
| `3031` | 校验签名信息失败 |
| `3045` | 其他错误（原因看 `errmsg`） |
| `3050` | 交易已被撤销 |
| `3088` | 交易未支付（特定时窗可能触发错误退款处理） |
| `3089` | 撤销异常（特定时窗可能触发错误退款处理） |
| `3099` | 渠道商户错误 |
| `3888` | 流水号重复 |
| `3889` | 交易控制失败（原因看 `errmsg`） |
| `3999` | 其他错误（原因看 `errmsg`） |

说明：`2000/2008` 建议间隔约 10 秒发起查询；`trxstatus` 与 `retcode` 需联合判断，禁止仅按 `retcode=SUCCESS` 判定交易成功。

### 3) `signtype`（签名类型，SDK核验）

来源：`SignType` 枚举（SDK源码）。

| 值 | 中文 |
|---|---|
| `SM2` | 国密SM2签名 |
| `RSA` | RSA签名 |
| `RSA2` | RSA2签名 |
| `MD5` | MD5签名 |

### 4) `paytype`（交易方式，统一下单文集常用）

适用范围：统一下单文集（project 17）常见交易方式。

| 值 | 中文 |
|---|---|
| `W01` | 微信扫码支付（主扫） |
| `W02` | 微信JS支付 |
| `W03` | 微信APP支付 |
| `W06` | 微信小程序支付 |
| `W11` | 微信订单支付 |
| `A01` | 支付宝扫码支付（主扫） |
| `A02` | 支付宝JS支付 |
| `A03` | 支付宝APP支付 |
| `U01` | 云闪付扫码支付 |
| `U02` | 云闪付JS支付 |
| `S01` | 数字人民币扫码支付 |
| `S03` | 数字人民币APP/H5支付 |
| `N03` | 网联支付 |
| `SCAN` | 支付宝/微信/云闪付被扫（预消费场景） |

### 5) `limitpay`（支付限制）

适用范围：统一下单文集（project 17）字段说明。

| 值 | 中文 | 限制 |
|---|---|---|
| `no_credit` | 禁用信用卡支付 | 常见于微信/支付宝场景 |
| `hb_fq` | 指定花呗分期 | 仅支付宝 |
| `credit_fq` | 指定信用卡分期 | 仅支付宝 |
| `normal_pay` | 普通支付（非花呗分期） | 仅支付宝 |

### 6) `fqnum`（支付宝分期示例值）

适用范围：统一下单文集（project 17）分期填写示例。

| 值 | 中文 |
|---|---|
| `3`/`6`/`12`/`24` | 花呗分期3/6/12/24期 |
| `3-cc`/`6-cc`/`12-cc`/`24-cc` | 支付宝信用卡分期3/6/12/24期 |
| `3,1`/`6,1`/`12,1`/`24,1` | 花呗分期（商户贴息） |
| `3-cc,1`/`6-cc,1`/`12-cc,1`/`24-cc,1` | 信用卡分期（商户贴息） |

### 7) `idtype`（证件类型）

适用范围：统一下单文集（project 17）当前已确认值。

| 值 | 中文 |
|---|---|
| `0` | 身份证 |
| `1` | 户口本 |
| `2` | 护照 |
| `3` | 军官证 |
| `4` | 士兵证 |
| `5` | 港澳通行证 |
| `6` | 台湾通行证 |
| `7` | 临时身份证 |
| `8` | 外国人居留证 |
| `9` | 警官证 |
| `X` | 其他证件 |

说明：其他文集可能扩展更多证件类型；如接口文档存在更多枚举，必须以该接口文档为准。

### 8) `fileType`（`TrxFileGetRequest` 对账文件类型）

适用范围：`TrxFileGetRequest`（服务类 API，下载对账文件前置请求）。

| 值 | 中文 |
|---|---|
| 空值（未传） | 传统对账单 |
| `1` | 传统对账单 |
| `2` | 数币对账单 |
| `3` | 商户个性化日对账单 |
| `4` | 商户个性化月对账单 |
| `5` | B2B订单支付对账单 |
| `6` | 微信直连对账单 |

### 9) `filetype`（`FileUploadRequest` 文件类型）

适用范围：`FileUploadRequest`（文件上传）。

| 值 | 中文 |
|---|---|
| `png` | PNG 图片 |
| `jpg` | JPG 图片 |
| `zip` | ZIP 压缩包 |

说明：仅支持 `png`、`jpg`、`zip`。

### 10) `devicetype`（终端设备类型）

适用范围：统一下单文集终端信息字段说明（可见摘要）、`MerChantAddTermRequest.deviceType`。

| 值 | 中文 |
|---|---|
| `01` | 自动柜员机（含 ATM 和 CDM）及多媒体自助终端 |
| `02` | 传统 POS |
| `03` | mPOS |
| `04` | 智能 POS |
| `05` | II 型固定电话 |
| `06` | 云闪付终端 |
| `07` | 保留使用 |
| `08` | 手机 POS |
| `09` | 刷脸付终端 |
| `10` | 条码支付受理终端 |
| `11` | 条码支付相关终端（以文集原文为准） |
| `12` | 行业终端（公交、地铁用于指定行业的终端） |
| `13` | MIS 终端 |

### 42) `termoperation`（终端操作类型）

适用范围：`MerChantAddTermRequest.operaTion`。

| 值 | 中文说明 |
|---|---|
| `00` | 新增 |
| `01` | 修改 |
| `02` | 注销 |

### 43) `termstate`（终端状态）

适用范围：`MerChantAddTermRequest.termState`。

| 值 | 中文说明 |
|---|---|
| `00` | 启用 |
| `01` | 注销 |

### 44) `querytypeterm`（终端查询类型）

适用范围：`MerChantQryTermRequest.queryType`。

| 值 | 中文说明 |
|---|---|
| `AT` | 返回AT加银联报备状态（为空时默认） |
| `UAT` | 返回AT加银联报备状态 |

### 45) `filetypeagentexpired`（到期提醒文件类型）

适用范围：`MerChantAgentExpiredRequest.fileType`。

| 值 | 中文说明 |
|---|---|
| `90` | 90天到期商户文件 |
| `60` | 60天到期商户文件 |
| `30` | 30天到期商户文件 |

### 46) `electsigntypeprodfeeshare`（电子协议类型-分账/结算）

适用范围：`MerChantProdFeeShareQryRequest.electSignType`。

| 值 | 中文说明 |
|---|---|
| `12` | api授权修改协议 |
| `14` | 分账入金协议 |
| `15` | 分账出金协议 |
| `19` | 结算入协议 |

说明：为空表示进件协议。

### 47) `reqtypemerchantproduct`（商户产品请求类型）

适用范围：`MerChantProductRequest.reqType`。

| 值 | 中文说明 |
|---|---|
| `query` | 查询 |
| `add` | 新增 |
| `edit` | 修改 |
| `del` | 删除 |

### 48) `chnltypemerchant`（渠道类型）

适用范围：`MerChantQueryChnlCmIdRequest.chnlType`。

| 值 | 中文说明 |
|---|---|
| `WXP` | 微信 |
| `ALP` | 支付宝 |
| `UNP` | 银联 |
| `OL-UNP` | 银联线上 |

### 49) `pidwxverifystate`（产品类型）

适用范围：`MerChantQueryWxVerifyStateRequest.pid`。

| 值 | 中文说明 |
|---|---|
| `P0001` | 收银宝 |
| `P0002` | 当面付 |
| `P0003` | 网上收银 |

### 50) `reqtypemerchantterm`（商户终端请求类型）

适用范围：`MerChantTermRequest.reqType`。

| 值 | 中文说明 |
|---|---|
| `query` | 查询 |
| `add` | 新增 |

### 51) `configtypewxsubdev`（微信子商户配置类型）

适用范围：`MerChantWxSubDevConfigRequest.configType`。

| 值 | 中文说明 |
|---|---|
| `1` | 支付域名 |
| `2` | 支付appid |

### 52) `pagetypewxverify`（认证页面类型）

适用范围：`MerChantWxVerifyRequest.pageType`。

| 值 | 中文说明 |
|---|---|
| `wx` | 单独微信 |
| `ali` | 单独支付宝 |
| `all` | 微信+支付宝 |

### 53) `scenepayscorepay`（支付分交易场景）

适用范围：`PayScorePayRequest.scene`。

| 值 | 中文说明 |
|---|---|
| `PARKING` | 停车停车场景 |
| `PARKING_SPACE` | 车位停车场景 |
| `GAS` | 加油场景 |
| `HIGHWAY` | 高速场景 |
| `BRIDGE` | 路桥场景 |
| `LIFE_PAY` | 生活缴费行业 |
| `SHARABLE_BIKE` | 共享单车 |
| `SHARABLE_CHARGERS` | 共享充电宝 |
| `E-COMMERCE` | 电商 |
| `OTHERS` | 其他 |

### 54) `trancodepayscoreserviceorder`（支付分服务单接口编号）

适用范围：`PayScoreServiceOrderRequest.tranCode`。

| 值 | 中文说明 |
|---|---|
| `permissionsadd` | 预授权 |
| `permissionsget` | 预授权查询 |
| `permissionsdel` | 解除预授权 |
| `serviceorderadd` | 创建服务单 |
| `serviceordercomplete` | 完成服务单 |
| `serviceorderget` | 查询服务单 |
| `serviceordercancel` | 取消服务单 |

### 76) `trancodezhima`（芝麻信用交易组件接口编号）

适用范围：`ZhimaCreditMiniOrderRequest.tranCode`（JSON `trancode`）。

| 值 | 中文说明 |
|---|---|
| `alipay.open.mini.order.create` | 创建交易组件订单（`ZhimaCreditTCMiniOrderCreate`） |
| `alipay.open.mini.order.query` | 查询交易组件订单（`ZhimaCreditTCMiniOrderQuery`） |
| `alipay.open.mini.order.close` | 关闭交易组件订单（`ZhimaCreditTCMiniOrderClose`） |
| `alipay.open.mini.order.changed` | 交易组件订单变更通知（`ZhimaCreditTCMiniOrderChanged`） |
| `alipay.open.mini.order.installment.create` | 创建交易组件分期单（`ZhimaCreditTCMiniOrderInstallmentCreate`） |
| `zhima.credit.payafteruse.creditagreement.changed` | 信用协议状态变更通知（`ZhimaCreditTCMiniOrderCreditAgreeChanged`） |
| `zhima.credit.payafteruse.creditagreement.query` | 查询信用协议状态（`ZhimaCreditTCMiniOrderCreditAgreeQuery`） |

说明：`tranCode` 必须与 `bizData` 对应业务实体一一匹配，禁止占位值、默认值、或交叉错配。

### 76.1) `bizdatazhima`（芝麻信用 bizData 实体映射）

适用范围：`ZhimaCreditMiniOrderRequest.bizData`（`tranCode + bizData` 组合请求）。

| tranCode | 必须使用的 SDK 实体类 |
|---|---|
| `alipay.open.mini.order.create` | `ZhimaCreditTCMiniOrderCreate` |
| `alipay.open.mini.order.query` | `ZhimaCreditTCMiniOrderQuery` |
| `alipay.open.mini.order.close` | `ZhimaCreditTCMiniOrderClose` |
| `alipay.open.mini.order.changed` | `ZhimaCreditTCMiniOrderChanged` |
| `alipay.open.mini.order.installment.create` | `ZhimaCreditTCMiniOrderInstallmentCreate` |
| `zhima.credit.payafteruse.creditagreement.changed` | `ZhimaCreditTCMiniOrderCreditAgreeChanged` |
| `zhima.credit.payafteruse.creditagreement.query` | `ZhimaCreditTCMiniOrderCreditAgreeQuery` |

说明：`bizData` 必须先由 `JsonUtils.toJson(bizObj)` 生成 JSON（需 `import com.allinpay.syb.sdk.core.utils.JsonUtils;`），再按 `JSON -> UTF-8 -> Base64` 生成；禁止 `Map<String,Object>`、`JsonNode`、手写字符串或自定义同名类替代，禁止宣称 SDK 自动转 JSON。

### 77) `actiontypeyjhx`（银联以旧换新业务类型）

适用范围：`UnionPayYJHXCmnRequest.actionType`、`UnionPayYJHXCoupRequest.actionType`（JSON `actionType`）。

| 值 | 中文说明 |
|---|---|
| `AUDITQRY` | 审核查询（`UnionPayYJHXAuditQryUn`） |
| `AUDIT` | 审核上送（`UnionPayYJHXAuditUn`） |
| `AUDITUPDATE` | 审核信息更新（`UnionPayYJHXAuditUpdateUn`） |
| `CLEARANCE` | 清分（`UnionPayYJHXClearanceUn`） |
| `SNQUERY` | SN 查询（`UnionPayYJHXSnQueryUn`） |
| `SNOCCUPANCY` | SN 占用（`UnionPayYJHXSnOccupancyUn`） |
| `TRANSSYNC` | 交易同步（`UnionPayYJHXTransSyncUn`） |
| `COUPCHECK` | 领券资格校验（`UnionPayYJHXCoupCheck`） |
| `COUPRECEIVE` | 领券（`UnionPayYJHXCoupReceive`） |
| `COUPCANCEL` | 撤券（`UnionPayYJHXCoupCancel`） |

### 78) `trxchnlyjhx`（银联以旧换新受理渠道）

适用范围：`UnionPayYJHXCmnRequest.trxChnl`、`UnionPayYJHXCoupRequest.trxChnl`（JSON `trxChnl`）。

| 值 | 中文说明 |
|---|---|
| `ONLINE` | 线上 |
| `OFFLINE` | 线下 |

说明：`actionType`、`trxChnl`、`bizContent` 必须按三元组同时匹配，禁止单独设置其一或交叉组合。

### 78.1) `bizcontentyjhx`（银联以旧换新 bizContent 实体三元组）

适用范围：`UnionPayYJHXCmnRequest.bizContent`、`UnionPayYJHXCoupRequest.bizContent`。

| actionType | trxChnl | 必须使用的 SDK 实体类 |
|---|---|---|
| `AUDITQRY` | `ONLINE` | `UnionPayYJHXAuditQryUn` |
| `AUDIT` | `ONLINE` | `UnionPayYJHXAuditUn` |
| `AUDITUPDATE` | `ONLINE` | `UnionPayYJHXAuditUpdateUn` |
| `CLEARANCE` | `ONLINE` | `UnionPayYJHXClearanceUn` |
| `SNQUERY` | `OFFLINE/ONLINE` | `UnionPayYJHXSnQueryUn` |
| `SNOCCUPANCY` | `OFFLINE/ONLINE` | `UnionPayYJHXSnOccupancyUn` |
| `TRANSSYNC` | `ONLINE` | `UnionPayYJHXTransSyncUn` |
| `COUPCHECK` | `ONLINE` | `UnionPayYJHXCoupCheck` |
| `COUPRECEIVE` | `ONLINE` | `UnionPayYJHXCoupReceive` |
| `COUPCANCEL` | `ONLINE` | `UnionPayYJHXCoupCancel` |

说明：`bizContent` 必须为上表实体实例；禁止 `Map<String,Object>`、父类空对象 `new UnionPayYJHXVoBiz()`、或自定义 `extends UnionPayYJHXVoBiz` 类。
补充：`UnionPayYJHXVoUserEncryptData`、`UnionPayYJHXVoAuditEncryptData` 均按明文字段构造后直接作为 `encryptData` 赋值，禁止手工加密后上送（加密由 SDK 字段链路处理）。

### 78.2) `bizdatapayscore`（微信支付分 bizData 实体映射）

适用范围：`PayScoreServiceOrderRequest.bizData`（`tranCode + bizData` 组合请求）。

| tranCode | 必须使用的 SDK 实体类 |
|---|---|
| `serviceorderadd` | `PayScoreTCServiceOrderAdd` |
| `serviceordercancel` | `PayScoreTCServiceOrderCancel` |
| `serviceordercomplete` | `PayScoreTCServiceOrderComplete` |
| `serviceorderget` | `PayScoreTCServiceOrderGet` |
| `permissionsadd` | `PayScoreTCPermissionAdd` |
| `permissionsdel` | `PayScoreTCPermissionDel` |
| `permissionsget` | `PayScoreTCPermissionGet` |

说明：`bizData` 必须先由 `JsonUtils.toJson(bizObj)` 生成 JSON（需 `import com.allinpay.syb.sdk.core.utils.JsonUtils;`），再按 `JSON -> UTF-8 -> Base64` 生成；禁止 `Map<String,Object>`、`JsonNode`、手写字符串或自定义同名类替代，禁止宣称 SDK 自动转 JSON。

### 55) `accttypeqpay`（快捷支付卡类型）

适用范围：`QPayAgreeApplyRequest.acctType`、`QPayAgreeConfirmRequest.acctType`。

| 值 | 中文说明 |
|---|---|
| `00` | 借记卡 |
| `02` | 准贷记卡/贷记卡 |

### 11) `trxcode`（预消费交易类型，部分）

适用范围：网上收银预消费（project 33）可见摘要，仅收录已见值。

| 值 | 中文 |
|---|---|
| `VSP011` | 扫码预消费 |
| `VSP012` | 扫码预消费回退/撤销 |
| `VSP013` | 扫码预消费完成 |
| `VSP014` | 扫码预消费退货 |
| `VSP671` | 银联扫码预授权 |
| `VSP672` | 银联扫码预授权相关交易（以文集原文为准） |

### 12) `actid`（活动号）

适用范围：`ActivityActivityPageRequest.actId`（活动支付文集）。

| 环境 | 取值 | 中文说明 |
|---|---|---|
| 测试 | `581` | 教培 |
| 生产 | `501` | 教培 |
| 生产 | `681` | 教育行业非学校主体商户餐饮消费场景费率活动 |
| 生产 | `682` | 教育行业学校主体食堂场景费率活动 |
| 生产 | `702` | 商业医疗行业特殊费率报名 |
| 生产 | `703` | 停车行业特殊费率报名 |
| 生产 | `722` | 商业医疗行业返佣活动报名 |
| 生产 | `823` | 线上批发小程序特殊费率报名 |

说明：该字段“否（可选）”，但“若传入不能为空”；长度上限 15。

### 13) `acttype`（活动类型）

适用范围：`ActivityCusActivityRequest.actType`。

| 值 | 中文说明 |
|---|---|
| `03` | 饭堂活动 |
| `04` | 教培活动 |
| `07` | 教育行业非学校主体商户餐饮消费场景费率活动 |
| `08` | 教育行业学校主体食堂场景费率活动 |
| `09` | 微信商业医疗行业活动 |
| `10` | 微信停车行业优惠 |
| `11` | 微信商业医疗行业返佣活动 |
| `12` | 线上批发小程序特殊费率报名 |

说明：该字段“否（可选）”，但“若传入不能为空”；长度上限 2。`actdetail` 与该字段联动，详见字段规则。

### 14) `bankcodeb2bpay`（B2B付款银行代码）

适用范围：`B2bOrderPayRequest.bankCode`（B2B 订单支付收款接口，附录 5.3 付款银行代码）。

| 值 | 中文说明 |
|---|---|
| `0301` | 交通银行 |
| `0307` | 平安银行 |
| `0310` | 浦发银行 |
| `0305` | 民生银行 |
| `0302` | 中信银行 |
| `0308` | 招商银行 |
| `0100` | 邮储银行 |
| `0303` | 光大银行 |
| `0306` | 广发银行 |
| `0316` | 浙商银行 |
| `04240001` | 南京银行 |
| `04233310` | 杭州银行 |
| `04083320` | 宁波银行 |
| `04202220` | 大连银行 |
| `04721460` | 廊坊银行 |
| `05646710` | 宜宾商业银行 |
| `03231000` | 中关村银行 |

说明：仅允许使用附录 5.3 清单值，禁止臆造银行代码。

### 15) `bankcodeb2bdirectpay`（B2B收款银行代码）

适用范围：`B2bOrderDirectPayRequest.bankCode`（B2B 订单支付付款接口，附录 5.6 收款银行代码）。

| 值 | 中文说明 |
|---|---|
| `0102` | 工商银行 |
| `0103` | 农业银行 |
| `0104` | 中国银行 |
| `0105` | 建设银行 |
| `0301` | 交通银行 |
| `0302` | 中信银行 |
| `0303` | 光大银行 |
| `0305` | 民生银行 |
| `0306` | 广发银行 |
| `0307` | 平安银行 |
| `0308` | 招商银行 |
| `0309` | 兴业银行 |
| `0310` | 浦发银行 |
| `0403` | 邮储银行 |
| `03231000` | 北京中关村银行 |
| `04202220` | 大连银行 |
| `04233310` | 杭州银行 |
| `04240001` | 南京银行 |
| `04721460` | 廊坊银行 |
| `05646710` | 宜宾市商业银行 |

说明：该附录枚举量很大，以上为高频与交集值；完整取值必须以附录 5.6 原表为准，禁止超出附录表臆造代码。

### 16) `autopay`（是否自动扣款）

适用范围：`BillPayAddRequest.autoPay`。

| 值 | 中文说明 |
|---|---|
| `0` | 不自动扣款 |
| `1` | 自动扣款 |

说明：可空，默认 `0`。当 `autopay=1` 时，`autopaytime` 必填，格式 `yyyyMMdd`（8位）。

### 17) `accttype`（账户查询类型）

适用范围：`CusAcctQueryBalanceRequest.acctType`。

| 值 | 中文说明 |
|---|---|
| `01` | 余额户查询 |
| `02` | 冻结户查询 |

说明：长度 2，必填。

### 18) `deptype`（结算类型）

适用范围：`CusAcctWithDrawRequest.depType`。

| 值 | 中文说明 |
|---|---|
| `1` | 快速结算 |
| `2` | 标准结算 |

说明：长度 2，必填。

### 19) `trxtype`（交易查询类型）

适用范围：`CusAcctQueryTrxRequest.trxType`。

| 值 | 中文说明 |
|---|---|
| `01` | 账户余额转账 |

说明：长度 2，必填。

### 20) `confirmstatus`（审核状态）

适用范围：`DigitalConfirmAuthCusStateRequest.confirmStatus`。

| 值 | 中文说明 |
|---|---|
| `1` | 审核通过 |
| `3` | 审核不通过 |
| `4` | 终止服务 |

说明：可空，默认 `1`；长度 2。

### 21) `digitalwxstatus`（微信点餐订单状态）

适用范围：`DigitalWxCateringOrderSyncStatusRequest.status`。

| 值 | 中文说明 |
|---|---|
| `CREATE_DEAL` | 用户下单 |
| `PAY_SUCCESS` | 支付完成/结账成功 |

说明：当 `status=PAY_SUCCESS` 时，`paytime`、`chnltrxid`、`trxid` 必填。

### 22) `encrypttype`（加密方式）

适用范围：涉及敏感信息加密的请求字段 `encrypttype/encryptType`。

| 值 | 中文说明 |
|---|---|
| `SM4` | 国密SM4加密 |

说明：当前仅支持 `SM4`，禁止臆造其他加密方式。

### 23) `fqnumjdbt`（京东白条分期期数）

适用范围：`FqfJDBTPayRequest.fqNum`。

| 值 | 中文说明 |
|---|---|
| `1,1` | 京东白条支付 |
| `3` | 三期用户付息 |
| `3,1` | 三期商户贴息 |
| `6` | 六期用户付息 |
| `6,1` | 六期商户贴息 |
| `12` | 十二期用户付息 |
| `12,1` | 十二期商户贴息 |
| `24,1` | 二十四期商户贴息 |

说明：该字段为京东白条接口专用，禁止与通用 `fqnum`（支付宝分期）混用。

### 24) `senceflag`（场景标识）

适用范围：`FqfJfqPayRequest.senceFlag`。

| 值 | 中文说明 |
|---|---|
| `01` | 保险实名认证支付 |
| `02` | 联合登陆 |

说明：`01/02` 场景均需商户申请白名单权限。

### 25) `loginstatus`（登录状态）

适用范围：`FqfJfqPayRequest.loginStatus`。

| 值 | 中文说明 |
|---|---|
| `0` | 未登录 |
| `1` | 已登录 |

说明：不上传默认为 `0`。

### 26) `rettype`（同步返回请求方式）

适用范围：`FqfJfqPayRequest.retType`。

| 值 | 中文说明 |
|---|---|
| `01` | POST方式 |
| `02` | GET方式 |

说明：默认 `01`（POST）。

### 27) `comproperty`（商户性质）

适用范围：`MerChantAddRequest.comProperty`。

| 值 | 中文说明 |
|---|---|
| `1` | 企业 |
| `3` | 个体户 |
| `4` | 个人 |
| `5` | 其他组织 |
| `6` | 事业单位 |

### 28) `legalidtype`（法人证件类型）

适用范围：`MerChantAddRequest.legalIdType`、`MerChantEditRequest.legalIdType`。

| 值 | 中文说明 |
|---|---|
| `01` | 身份证 |
| `03` | 护照 |
| `04` | 港澳通行证 |
| `05` | 台湾通行证 |
| `11` | 港澳台居民居住证 |
| `12` | 外国人永居证 |
| `13` | 执行事务合伙人 |

说明：`MerChantEditRequest` 文档图示常用值为 `01/04/05`。

### 29) `clearmode`（结算方式）

适用范围：`MerChantAddRequest.clearMode`、`MerChantAcctEditRequest.clearMode`。

| 值 | 中文说明 |
|---|---|
| `0` | 商户自主提现 |
| `1` | 结算到银行卡 |
| `2` | 结算到通联电子账户 |

### 30) `accttypemerchant`（账户类型）

适用范围：`MerChantAddRequest.acctType`、`MerChantAcctEditRequest.acctType`。

| 值 | 中文说明 |
|---|---|
| `0` | 对私 |
| `1` | 对公 |

### 31) `accttp`（卡折类型）

适用范围：`MerChantAddRequest.acctTp`、`MerChantAcctEditRequest.acctTp`。

| 值 | 中文说明 |
|---|---|
| `00` | 借记卡 |
| `01` | 存折 |

### 32) `businessplace`（经营场所）

适用范围：`MerChantAddRequest.businessPlace`。

| 值 | 中文说明 |
|---|---|
| `1` | 独立门店/连锁店/专卖店 |
| `2` | 综合卖场 |
| `3` | 批发市场 |
| `4` | 其它 |

说明：为空默认 `1`。

### 33) `appscenario`（应用场景）

适用范围：`MerChantAddRequest.appScenario`。

| 值 | 中文说明 |
|---|---|
| `01` | PC网站 |
| `02` | APP/公众号/小程序（可复选） |

### 34) `quickcash`（快速提现开关）

适用范围：`MerChantAddRequest.quickCash`。

| 值 | 中文说明 |
|---|---|
| `0` | 开通 |
| `1` | 关闭 |

### 35) `agreetype`（无纸化标识）

适用范围：`MerChantAddRequest.agreeType`。

| 值 | 中文说明 |
|---|---|
| `1` | 电子协议 |
| `2` | 纸质协议 |

说明：非电子协议进件可不填。

### 36) `offlag`（线上线下业务场景）

适用范围：`MerChantAddRequest.ofFlag`。

| 值 | 中文说明 |
|---|---|
| `0` | 线下 |
| `1` | 线上 |

说明：为空默认线下（`0`）。

### 37) `registerfund`（注册资本区间）

适用范围：`MerChantAddRequest.registerFund`。

| 值 | 中文说明 |
|---|---|
| `1` | 注册资本 < 10万元 |
| `2` | 10万元 < 注册资本 < 20万元 |
| `3` | 20万元 < 注册资本 < 50万元 |
| `4` | 50万元 < 注册资本 < 100万元 |
| `5` | 注册资本 > 100万元 |

### 38) `stafftotal`（员工人数区间）

适用范围：`MerChantAddRequest.staffTotal`。

| 值 | 中文说明 |
|---|---|
| `1` | 员工数量 <= 10 |
| `2` | 10 < 员工数量 <= 20 |
| `3` | 20 < 员工数量 <= 50 |
| `4` | 50 < 员工数量 <= 100 |
| `5` | 员工数量 > 100 |

### 39) `operatelimit`（经营区域）

适用范围：`MerChantAddRequest.operateLimit`。

| 值 | 中文说明 |
|---|---|
| `1` | 城区 |
| `2` | 郊区 |
| `3` | 边远地区 |

### 40) `inspect`（经营地段）

适用范围：`MerChantAddRequest.inspect`。

| 值 | 中文说明 |
|---|---|
| `1` | 商业区 |
| `2` | 工业区 |
| `3` | 住宅区 |

### 41) `thrcertflag`（是否三证合一）

适用范围：`MerChantEditRequest.thrCertFlag`。

| 值 | 中文说明 |
|---|---|
| `1` | 是 |
| `0` | 否 |

### 56) `processcoderiskfeebackalicomplaintfinish`（支付宝投诉处理完成 — 商家处理结果码）

适用范围：`RiskFeeBackAliComplaintProcessFinishRequest.processCode`（JSON `process_code`）。

| 值 | 中文说明 |
|---|---|
| `CONSENSUS_WITH_CLIENT` | 已联系到用户，协商一致，无异议 |
| `ORTHER` | 其他（官方文档为该拼写；若渠道后续修正为 `OTHER` 以渠道为准） |
| `RECTIFICATION_NO_REFUND` | 不涉及退款，已针对投诉内容进行整改 |
| `REFUND` | 已退款，用户无异议 |
| `SUBMIT_PROOF_NOT_CONTACTED` | 已提交证明材料 |

### 57) `bussihandleriskfeebackwxapplet`（微信小程序投诉处理操作类型）

适用范围：`RiskFeeBackWxAppletBussiRespondComplaintRequest.bussiHandle`（JSON `bussihandle`）。

| 值 | 中文说明 |
|---|---|
| `1` | 同意和解 |
| `2` | 拒绝和解 |

### 58) `acceptreturnriskfeebackwxapplet`（微信小程序投诉退货处理结果）

适用范围：`RiskFeeBackWxAppletBussiSupplyRefundRequest.acceptReturn`（JSON `acceptreturn`）。

| 值 | 中文说明 |
|---|---|
| `1` | 确认收货 |
| `2` | 签收异常 |

### 59) `typeriskfeebackwxappletupload`（微信小程序投诉图片上传类型）

适用范围：`RiskFeeBackWxAppletUploadRequest.type`（JSON `type`）。

| 值 | 中文说明 |
|---|---|
| `image` | 图片 |
| `voice` | 语音 |
| `video` | 视频 |
| `thumb` | 缩略图 |

### 60) `actionriskfeebackwxcomplaintrefundprogress`（微信投诉退款审批动作）

适用范围：`RiskFeeBackWxComplaintSreFundProgressRequest.action`（JSON `action`）。

| 值 | 中文说明 |
|---|---|
| `REJECT` | 拒绝退款 |
| `APPROVE` | 同意退款 |

### 61) `openflagsybservicealinfcconfig`（支付宝 NFC 设备配置标识）

适用范围：`SybServiceAlinFcConfigRequest.openFlag`（JSON `openflag`）。

| 值 | 中文说明 |
|---|---|
| `0` | 解绑 |
| `1` | 绑定 |

### 62) `sharetypesybserviceasagreeconfig`（分账协议授权分账类型）

适用范围：`SybServiceAsAgreeConfigRequest.shareType`（JSON `sharetype`）。

| 值 | 中文说明 |
|---|---|
| `01` | 固额分账 |
| `02` | 固定比例分账 |
| `03` | 动态分账 |

### 63) `limittypesybserviceasagreeconfig`（分账协议授权限额类型）

适用范围：`SybServiceAsAgreeConfigRequest.limitType`（JSON `limittype`）。

| 值 | 中文说明 |
|---|---|
| `0` | 比例超限或资金超限都不通过 |
| `1` | 比例不超限或资金不超限都通过 |

### 64) `pidlistsybserviceiotdevconfig`（IOT 设备绑定产品名称）

适用范围：`SybServiceIotDevConfigRequest.pidList`（JSON `pidlist`）。

| 值 | 中文说明 |
|---|---|
| `P0002` | 当面付 |
| `P0003` | 网上收银 |

说明：支持多选，使用英文逗号分隔（如 `P0002,P0003`）；不传默认 `P0002`。

### 65) `openflagsybserviceiotdevconfig`（IOT 设备绑定标识）

适用范围：`SybServiceIotDevConfigRequest.openFlag`（JSON `openflag`）。

| 值 | 中文说明 |
|---|---|
| `0` | 解绑 |
| `1` | 绑定 |

### 66) `devicetypesybserviceiotdevconfig`（IOT 设备类型）

适用范围：`SybServiceIotDevConfigRequest.deviceType`（JSON `devicetype`）。

| 值 | 中文说明 |
|---|---|
| `01` | 音箱 |
| `02` | 打印机 |

说明：可空，默认 `01`（音箱）。

### 67) `resendnotifytranxqueryorder`（交易查询是否重发结果通知）

适用范围：`TranxQueryOrderRequest.resendNotify`（JSON `resendnotify`）。

| 值 | 中文说明 |
|---|---|
| `0` | 不重发 |
| `1` | 重发通知 |

### 68) `apptypeunywpay`（银联业务支付交易发起场景）

适用范围：`UnYwPayRequest.appType`（JSON `apptype`）。

| 值 | 中文说明 |
|---|---|
| `03` | 小程序 |
| `04` | 公众号 |

### 69) `apptypeunconscspayagreeapply`（银联无感支付签约应用类型）

适用范围：`UnConscsPayAgreeApplyRequest.appType`（JSON `apptype`）。

| 值 | 中文说明 |
|---|---|
| `01` | 微信小程序无感签约 |
| `02` | 云闪付 app |
| `03` | 微信公众号 |

### 70) `facetypeunconscspaytokenapply`（银联无感支付 token 申请人脸验证方式）

适用范围：`UnConscsPayTokenApplyRequest.faceType`（JSON `facetype`）。

| 值 | 中文说明 |
|---|---|
| `1` | 商户自验 |
| `2` | 银联或第三方 |

### 71) `invoketypeunconscspaytokenapply`（银联无感支付 token 申请拉起方式）

适用范围：`UnConscsPayTokenApplyRequest.invokeType`（JSON `invoketype`）。

| 值 | 中文说明 |
|---|---|
| `03` | 小程序 |
| `04` | 公众号 |

### 72) `opentypeunconscspaytokensetnover`（银联无感支付小额免检开启类型）

适用范围：`UnConscsPayTokenSetNoverRequest.openType`（JSON `opentype`）。

| 值 | 中文说明 |
|---|---|
| `00` | 开通 |
| `01` | 关闭 |

### 73) `authtypeunitorderauthcode2userid`（付款码转 userId 授权码类型）

适用范围：`UnitOrderAuthCode2UserIdRequset.authType`（JSON `authtype`）。

| 值 | 中文说明 |
|---|---|
| `01` | 微信付款码 |
| `02` | 银联 userAuth |

### 74) `zhitypeunitordercreatezhi`（创建支付宝口令类型）

适用范围：`UnitOrderCreateZhiRequest.zhiType`（JSON `zhitype`）。

| 值 | 中文说明 |
|---|---|
| `01` | 花呗分期 |
| `02` | 支付宝 |

说明：不填写默认 `01`。

### 75) `apptypewxopengetopenid`（微信开放能力获取 openid 公众号类型）

适用范围：`WxOpenGetOpenIdRequest.appType`（JSON `apptype`）。

| 值 | 中文说明 |
|---|---|
| `01` | 微信公众号 |

说明：当前仅支持 `01`。

## 四、字段取值规则（高价值）

以下为从收银宝文集可见摘要提取的字段取值规则，用于抑制参数格式臆造。

| 字段 | 规则 | 适用范围 |
|---|---|---|
| `out_order_no` | 最长 32；仅数字/大小写字母；同商户下唯一 | 微信支付分（project 22） |
| `termno` | 8 位数字 | 统一下单（project 17） |
| `discountCode` | 数字与字母，最长 20 | 网关支付拓展参数（project 30） |
| `cusip` | 需上送支付者网络 IP（用于风控校验） | 收银台小程序（project 32） |
| `cancelurl` | 有效回跳地址 URL | 收银台/H5 取消回跳（project 32） |
| `trxamt` | 单位分 | 通用交易金额 |
| 时间类字段（如 `txnTime/uploadTime/transTm`） | 使用文档给定时间格式（常见 `yyyyMMddHHmmss`） | 云闪付/银联相关场景 |
| `actdetail` | JSON字符串；`acttype=04/07/08/09/10/11` 必填；`acttype=12` 不填 | 活动支付（ActivityCusActivityRequest） |
| `autopaytime` | 格式 `yyyyMMdd`（8位）；`autopay=1` 时必填 | 应用服务商账单（BillPayAddRequest） |
| `acctdate` | 格式 `YYYYMMDD`（8位） | 账户历史余额查询（CusAcctQueryHisBalanceRequest） |
| `payercusid` | 当前仅支持与 `cusid` 相等的付款商户号；长度 15 | 账户余额转账（CusAcctTransferBalRequest） |
| `actiontime/paytime` | 格式 `yyyymmddhhmmss` | 微信点餐（DigitalWxCateringOrderSyncStatusRequest） |
| `reqtime` | 格式 `yyyyMMddHHmmss` | 统一分期（Fqf*） |
| `idno/acctname/mobile` | 需SM4加密后上送 | 统一分期（FqfApply/FqfPayConfirm/FqfJfqPay 条件场景） |
| `validtime` | 以分钟为单位；常见默认5；按接口上限约束（如60/1440） | 统一分期（Fqf*） |
## 五、高风险项（严禁泛化）

1. `trxstatus`：仅可使用本词典“收银宝交易状态码”已核验集合；不得扩写为“全接口全场景通用表”。  
2. `trxcode`：交易类型码跨度大，禁止在未逐接口核验前写“全量映射”。  
3. `idtype`：跨文集可能扩展，当前仅保留已确认值。  

## 六、Agent 使用约定

1. 生成代码时，先判定文集域，再引用本词典枚举。  
2. 对 `retcode` 与 `trxstatus` 同时判断，禁止仅按 `retcode` 判成功。  
3. 金额字段统一标注“单位分”。  
4. `notify_url` 必加“公网可达 + 验签 + 幂等”提示。  
5. 遇到上述“字段取值规则”时，优先按规则生成示例，不得用随机格式占位。  


