# Special Call Routing Map

Special routes that do not map to SDK request classes.

| Scenario | Call shape | Notes |
|---|---|---|
| Async notification parse/verify | `AllinpayApi.client().noticeHandle(noticeStr)` | 强约束：仅允许 `noticeHandle`，禁止改为 `execObj(...)`。 |
| File download | `AllinpayApi.client().downloadToByte(HttpConfig.build(), url)` / `downloadToFile(HttpConfig.build(), url, savePath)` | 强约束：下载只能使用上述方法；通常先用 `TrxFileGetRequest` 获取 url。 |
| File upload | `AllinpayApi.client().upload(HttpConfig.build(), request)` | 强约束：上传只能使用 `upload(...)`；禁止改为 `execObj(...)`。 |
