# 字段必填矩阵 - DigitalSend

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - DigitalSendCouponsRequest

> 类说明：微信代金券

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| digId | digid | R | 应用ID | high |
| stockId | stockid | R | 代金券批次ID | high |
| openId | openid | R | 用户OpenID（用户在appid下的唯一标识） | high |
| couponValue | couponvalue | C | 指定面额发券场景必填；单位分；其他场景不填 | high |
| couponMiniMum | couponminimum | C | 指定面额发券场景必填；单位分；其他场景不填 | high |


