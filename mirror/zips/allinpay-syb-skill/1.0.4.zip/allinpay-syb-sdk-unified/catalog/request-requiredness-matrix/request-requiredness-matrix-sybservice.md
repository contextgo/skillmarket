# 字段必填矩阵 - SybService

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - SybServiceAlinFcConfigRequest

> 类说明：支付宝NFC设备配置接口

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| termSn | termsn | R | 设备 SN 编号 | high |
| branchNo | branchno | R | 设备绑定门店号 | high |
| openFlag | openflag | R | 配置标识；取值见 field-enum-glossary.openflagsybservicealinfcconfig | high |

## 字段必填矩阵 - SybServiceAlinFcQueryRequest

> 类说明：支付宝NFC设备绑定查询接口

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| termSn | termsn | R | 设备 SN 编号 | high |
| branchNo | branchno | R | 设备绑定门店号 | high |

## 字段必填矩阵 - SybServiceAsAgreeConfigQryRequest

> 类说明：分账协议授权查询

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| payeeCusId | payeecusid | R | 入金商户号 | high |

## 字段必填矩阵 - SybServiceAsAgreeConfigRequest

> 类说明：分账协议授权配置

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| payeeCusId | payeecusid | R | 入金商户号 | high |
| shareType | sharetype | R | 分账类型；取值见 field-enum-glossary.sharetypesybserviceasagreeconfig | high |
| amtMax | amtmax | R | 最高金额；单位元 | high |
| rateMax | ratemax | R | 分账比例值；示例 `0.2513` 代表 `25.13%`；当 `shareType=02/03` 时百分比不能大于 1 | high |
| limitType | limittype | R | 限额类型；取值见 field-enum-glossary.limittypesybserviceasagreeconfig | high |
| asAgreeUrl | asagreeurl | R | 分账授权协议附件；图片链接（双方分账协议） | high |
| reason | reason | R | 分账事由；最大 50 个汉字 | high |

## 字段必填矩阵 - SybServiceIotDevConfigRequest

> 类说明：IOT设备绑定和解绑接口

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| branchNo | branchno | O | 门店编号；非必填 | high |
| deviceName | devicename | R | 设备 SN 编号 | high |
| pidList | pidlist | O | 产品名称；默认 `P0002`；支持多选逗号分隔（如 `P0002,P0003`）；取值见 field-enum-glossary.pidlistsybserviceiotdevconfig | high |
| openFlag | openflag | R | 绑定标识；取值见 field-enum-glossary.openflagsybserviceiotdevconfig | high |
| deviceType | devicetype | O | 设备类型；为空默认 `01`（音箱）；取值见 field-enum-glossary.devicetypesybserviceiotdevconfig | high |

## 字段必填矩阵 - SybServiceIotDevQueryRequest

> 类说明：IOT设备查询接口

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| branchNo | branchno | O | 门店编号；非必填 | high |
| deviceName | devicename | R | 设备 SN 编号 | high |

## 字段必填矩阵 - SybServiceQueryCouponDetailRequest

> 类说明：查询微信代金券详情

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|----|---|---|
| couponId | couponid | R  | 代金券id | high |
| wxOpenId | wxopenid | R  | 微信openid | high |

## 字段必填矩阵 - SybServiceQueryStockDetailRequest

> 类说明：查询微信代金券批次详情

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| stockId | stockid | R | 批次号 | high |

## 字段必填矩阵 - SybServiceQueryStockRefundFlowRequest

> 类说明：下载微信代金券批次退款明细

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| stockId | stockid | R | 批次号 | high |

## 字段必填矩阵 - SybServiceQueryStockUseFlowRequest

> 类说明：下载微信代金券批次核销明细

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|----|---|---|
| stockId | stockid | R  | 批次号 | high |

## 字段必填矩阵 - SybServiceSearchCusPackageRequest

> 类说明：商户套餐查询接口

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| startTime | starttime | O | 套餐购买日期范围开始；格式 yyyy-MM-dd HH:mm:ss | high |
| endTime | endtime | O | 套餐购买日期范围结束；格式 yyyy-MM-dd HH:mm:ss | high |

## 字段必填矩阵 - SybServiceSendCouponsRequest

> 类说明：微信发放代金券

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| stockId | stockid | R | 代金券批次 id（微信为每个批次分配的唯一 id） | high |
| openId | openid | R | 用户 openid；用户在 appid 下的唯一标识 | high |
| mchAppId | mchappid | R | 商户公众号 appid；应为公众号 appid（mp），不能为 APP 的 appid（open） | high |
| couponValue | couponvalue | O | 指定面额发券场景填写券面额，其他场景不填；单位分 | high |
| couponMinimum | couponminimum | O | 指定面额发券场景填写券门槛，其他场景不填；单位分 | high |

## 字段必填矩阵 - SybServiceUploadElectTicketRequest

> 类说明：上传微信电子小票

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxId | trxid | R | 交易单号 | high |
| chnlTrxId | chnltrxid | R | 渠道交易单号 | high |
| cmId | cmid | R | 微信子商户号 | high |
| openId | openid | R | 微信 OPENID | high |
| merChantContacts | merchantcontacts | O | 用户与商家联系渠道；JSON 对象，包含 `consultation_phone_number`（商户售后咨询电话），示例 `{\"consultation_phone_number\":\"18888888888\"}` | high |
| file | - | R | 图片文件流；不参与签名；文件大小不超过 200KB；仅支持 PNG/JPG | high |

## 字段必填矩阵 - SybServiceWxCateringOrderSyncStatusRequest

> 类说明：微信点餐同步

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| subAppId | sub_appid | R | 子商户在微信公众平台申请服务号对应的 APPID | high |
| outShopNo | outshopno | R | 商户旗下门店唯一编号 | high |
| subOpenId | subopenid | R | 用户子标识；用户在子商户 appid 下的 openid | high |
| loginToken | logintoken | R | 微信用户登录接口返回的登录票据；公众号填页面授权 access_token，小程序填写 session_key | high |
| orderEntry | orderentry | R | 点餐入口 | high |
| totalAmount | totalamount | R | 总价；单位分，数字类型 | high |
| discountAmount | discountamount | R | 优惠金额；单位分，数字类型 | high |
| userAmount | useramount | R | 实际支付金额；单位分，数字类型 | high |
| status | status | R | 订单状态；取值见 field-enum-glossary.digitalwxstatus | high |
| actionTime | actiontime | R | 状态发生变化时间；格式 yyyymmddhhmmss | high |
| payTime | paytime | C | 支付时间；格式 yyyymmddhhmmss（`status=PAY_SUCCESS` 时必填） | high |
| chnlTrxId | chnltrxid | C | 渠道平台交易单号（`status=PAY_SUCCESS` 时必填） | high |
| trxId | trxid | C | 收银宝平台交易流水号（`status=PAY_SUCCESS` 时必填） | high |
| reqSn | reqsn | R | 商户交易订单号 | high |
| dishList | dishlist | R | 菜品列表（`dish_list` 对象数组） | high |
| outTableNo | outtableno | O | 桌位号 | high |
| peopleCount | peoplecount | O | 消费人数，数字类型 | high |



