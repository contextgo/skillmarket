# 字段必填矩阵 - PosolQuery

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - PosolQueryRequest

> 类说明：交易查询

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqSn | reqsn | U | 本次请求流水 | high |
| trxId | trxid | U | 收银宝平台交易订单号 | high |


