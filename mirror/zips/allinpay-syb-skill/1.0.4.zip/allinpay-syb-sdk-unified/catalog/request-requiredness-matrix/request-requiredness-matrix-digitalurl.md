# 字段必填矩阵 - DigitalUrl

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - DigitalUrlRequest

> 类说明：获取应用访问链接

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| digitalId | digitalid | R | 应用ID | high |
| authUserId | authuserid | R | 用户ID（登录好老板的用户） | high |
| authCusId | authcusid | R | 需要授权的商户号 | high |
| branchNo | branchno | O | 门店号；门店收银员登录场景不可空 | high |
| branchName | branchname | O | 门店名称；门店收银员登录场景不可空 | high |


