# 字段必填矩阵 - DigitalWx

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - DigitalWxCateringOrderSyncStatusRequest

> 类说明：微信点餐

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| digId | digid | R | 应用ID | high |
| subAppid | sub_appid | R | 子商户在微信公众平台申请服务号对应的APPID | high |
| outShopNo | outshopno | R | 商户旗下门店唯一编号 | high |
| subOpenId | subopenid | R | 用户在子商户appid下的openid | high |
| loginToken | logintoken | R | 微信登录票据（公众号填access_token；小程序填session_key） | high |
| orderEntry | orderentry | R | 点餐入口 | high |
| totalAmount | totalamount | R | 总价；单位分 | high |
| discountAmount | discountamount | R | 优惠金额；单位分 | high |
| userAmount | useramount | R | 实际支付金额；单位分 | high |
| status | status | R | 订单状态；枚举见 field-enum-glossary.digitalwxstatus | high |
| actionTime | actiontime | R | 状态变化时间；格式yyyymmddhhmmss | high |
| payTime | paytime | C | status=PAY_SUCCESS 时必填；格式yyyymmddhhmmss | high |
| chnlTrxId | chnltrxid | C | status=PAY_SUCCESS 时必填；渠道平台交易单号 | high |
| trxId | trxid | C | status=PAY_SUCCESS 时必填；收银宝平台交易流水号 | high |
| reqSn | reqsn | R | 商户交易订单号 | high |
| dishList | dishlist | R | dish_list对象列表（字符串承载） | high |
| outTableNo | outtableno | O | 桌位号 | high |
| peopleCount | peoplecount | O | 消费人数 | high |



