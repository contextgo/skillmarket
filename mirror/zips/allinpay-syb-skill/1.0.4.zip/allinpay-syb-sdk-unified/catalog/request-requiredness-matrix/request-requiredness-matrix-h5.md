# 字段必填矩阵 - H5

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - H5BillPayBillPayRequest

> 类说明：H5账单付款（商户网站->账单付款页面）

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| digId | digid | R | 应用ID | high |
| payeeCusId | payeecusid | R | 收款商户号（当前仅支持与cusid相等） | high |
| billId | billid | R | 商户账单号 | high |

## 字段必填矩阵 - H5UnionPayOrderRequest

> 类说明：收银台-H5收银台

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 付款金额；单位分 | high |
| payType | paytype | O | 指定交易类型；F02=分期付 | high |
| fqNum | fqnum | C | payType=F02 且支付宝分期场景时上送；取值见 field-enum-glossary.fqnum | high |
| reqSn | reqsn | C | reqsn/unireqsn 二选一；两者并存时优先reqsn | high |
| uniReqSn | unireqsn | C | reqsn/unireqsn 二选一 | high |
| charset | charset | R | 字符编码；支持UTF-8/GBK | high |
| retUrl | returl | R | 同步通知地址；必须https且不能带参数 | high |
| notifyUrl | notify_url | O | 异步通知地址；若https需443默认端口 | high |
| body | body | R | 订单标题（收银台展示） | high |
| remark | remark | O | 订单备注（通知原样带回） | high |
| validTime | validtime | O | 有效时间；单位分钟；默认5 | high |
| expireTime | expiretime | O | 截止支付时间；格式yyyyMMddHHmmss | high |
| limitPay | limit_pay | O | 支付限制；如no_credit | high |
| goodsTag | goods_tag | O | 订单支付标识（优惠标签） | medium |
| benefitDetail | benefitdetail | O | 优惠信息；json字符串（String） | medium |
| asInfo | asinfo | O | 分账信息；需开通分账配置 | medium |
| subBranch | subbranch | O | 通联系统门店号 | medium |
| extendParams | extendparams | O | 拓展参数；json字符串（String） | medium |
| trueName | truename | C | 实名交易场景必填（与idNo配套） | high |
| idNo | idno | C | 实名交易场景必填（与trueName配套） | high |
| isHide | ishide | O | 是否直接支付；取值1时直接拉起密码框 | high |
| isPwdCancel | ispwdcancel | O | 取消支付是否通知；0否/1是（仅微信/支付宝） | high |
| unPid | unpid | O | 银联PID；仅代理商/服务商上送 | high |
| termInfo | terminfo | O | 终端信息；json字符串（String） | medium |


