# 字段必填矩阵 - CusAcct

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - CusAcctQueryAcctOverLimitRequest

> 类说明：商户授信资金查询接口

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|

## 字段必填矩阵 - CusAcctQueryBalanceRequest

> 类说明：商户账户余额查询

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| acctType | accttype | R | 查询类型；枚举见 field-enum-glossary.accttype | high |

## 字段必填矩阵 - CusAcctQueryHisBalanceRequest

> 类说明：商户账户历史余额查询

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| acctDate | acctdate | R | 历史日期；格式YYYYMMDD（8位） | high |

## 字段必填矩阵 - CusAcctQueryTrxRequest

> 类说明：商户余额转账交易查询

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxType | trxtype | R | 查询类型；枚举见 field-enum-glossary.trxtype | high |
| trxId | trxid | C | trxId/reqSn 二选一，优先trxId | high |
| reqSn | reqsn | C | trxId/reqSn 二选一 | high |

## 字段必填矩阵 - CusAcctTransferBalRequest

> 类说明：商户账户余额转账

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| payerCusId | payercusid | R | 付款商户号；当前仅支持与cusid相等；长度15 | high |
| payeeCusId | payeecusid | R | 转入方商户号 | high |
| trxAmt | trxamt | R | 转账金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 | high |
| remark | remark | O | 备注信息 | medium |

## 字段必填矩阵 - CusAcctWithDrawQueryRequest

> 类说明：商户账户余额结算查询

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxId | trxid | C | trxId/reqSn 二选一，优先trxId | high |
| reqSn | reqsn | C | trxId/reqSn 二选一 | high |

## 字段必填矩阵 - CusAcctWithDrawRequest

> 类说明：商户账户余额结算

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 提现金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 | high |
| depType | deptype | R | 结算类型；枚举见 field-enum-glossary.deptype | high |
| remark | remark | O | 备注信息 | medium |
| summary | summary | O | 摘要信息 | medium |


