# 字段必填矩阵 - UnConscsPay

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - UnConscsPayAgreeApplyRequest

> 类说明：云闪付支付API-无感支付-签约

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| merUserId | meruserid | R | 会员编号；签约持卡人在商户所属会员编号 | high |
| applyId | applyid | R | 申请 id；商户申请协议流水 | high |
| appType | apptype | R | 应用类型；取值见 field-enum-glossary.apptypeunconscspayagreeapply | high |
| appName | appname | R | 应用名称；`apptype=01` 填小程序 id，`apptype=02` 填包名，`apptype=03` 填公众号 id | high |
| appPath | apppath | O | 回调应用路径；`apptype=01` 填小程序 path，`apptype=02` 填应用 scheme，`apptype=03` 为空 | high |
| notifyUrl | notify_url | R | 签约完成通知地址；url 不能含参数 | high |
| planId | planid | R | 银联商户合约号 | high |

## 字段必填矩阵 - UnConscsPayAgreePayRequest

> 类说明：云闪付支付API-无感支付-支付

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| agreeId | agreeid | R | 协议号；签约协议号（签约结果通知获取） | high |
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 | high |
| subject | subject | O | 订单标题；最大 100 个字节（约 50 个中文字符） | high |
| remark | remark | O | 备注信息 | high |
| notifyUrl | notify_url | O | 交易结果通知地址；必须为直接可访问的 url，不能携带参数 | high |
| planId | planid | R | 银联商户合约号 | high |

## 字段必填矩阵 - UnConscsPayAgreeUnbindRequest

> 类说明：云闪付支付API-无感支付-解约

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|----|---|---|
| applyId | applyid | R  | 签约成功通联通知的协议编号 | high |

## 字段必填矩阵 - UnConscsPayAndSignRequest

> 类说明：云闪付支付API-无感支付-支付并签约

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 | high |
| subject | subject | O | 订单标题；最大 100 个字节（约 50 个中文字符） | high |
| remark | remark | O | 备注信息 | high |
| validTime | validtime | R | 订单有效时间；单位分钟；最大 60 | high |
| appType | apptype | R | 应用类型；取值见 field-enum-glossary.apptypeunconscspayagreeapply | high |
| appName | appname | R | 应用名称；`apptype=01` 填小程序 id，`apptype=02` 填包名，`apptype=03` 填公众号 id | high |
| appPath | apppath | O | 回调应用路径；`apptype=01` 填小程序 path，`apptype=02` 填应用 scheme，`apptype=03` 为空 | high |
| merUserId | meruserid | R | 会员编号；签约持卡人在商户所属会员编号（用于签约） | high |
| applyId | applyid | R | 申请 id；商户申请协议流水（用于签约） | high |
| notifyUrl | notify_url | O | 交易结果通知地址；必须为直接可访问的 url，不能携带参数 | high |
| agreeNotifyUrl | agree_notifyurl | R | 签约结果通知；必须为直接可访问的 url，不能携带参数 | high |
| planId | planid | R | 银联商户合约号 | high |

## 字段必填矩阵 - UnConscsPayTokenApplyRequest

> 类说明：云闪付支付API-签约支付-签约

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| merUserId | meruserid | R | 会员编号；签约持卡人在商户所属会员编号 | high |
| merUserRegitDate | meruserregitdate | R | 会员注册日期 | high |
| merUserLoginMet | meruserloginmet | R | 会员登录方式；录密码/动码/人脸（FACEID 指纹视为 1） | high |
| encryptType | encrypttype | R | 敏感字段加密方式；当前仅支持 `SM4` | high |
| acctNo | acctno | O | 银行卡号；SM4 加密；为空时在银联页面选择签约卡号 | high |
| idNo | idno | R | 证件号；SM4 加密 | high |
| idType | idtype | R | 证件类型；取值见 field-enum-glossary.idtype | high |
| acctName | acctname | R | 户名；SM4 加密 | high |
| mobile | mobile | R | 手机号码；SM4 加密 | high |
| bankCode | bankcode | O | 银行编码；为空时银联签约页面展示所有银行卡 | high |
| acctType | accttype | O | 卡类型；常见值 `00` 借记卡、`02` 贷记卡 | high |
| chnlTrId | chnltrid | R | 渠道标记 id（银联分配） | high |
| tokenType | tokentype | R | Token 类型（银联分配） | high |
| deviceId | deviceid | R | 设备 id | high |
| faceType | facetype | O | 人脸验证方式；取值见 field-enum-glossary.facetypeunconscspaytokenapply | high |
| faceOrder | faceorder | C | 人脸订单号；`faceType=2` 时上送 | high |
| faceApp | faceapp | C | 人脸云服务 ID；`faceType=2` 时上送 | high |
| invokeType | invoketype | O | 拉起方式；小程序上送；取值见 field-enum-glossary.invoketypeunconscspaytokenapply | high |
| wxAppId | wxappid | C | 小程序 id；小程序上送 | high |
| notifyUrl | notify_url | R | 签约完成通知地址；url 不能含参数 | high |
| retUrl | returl | R | 前端跳转地址；url 不能含参数 | high |

## 字段必填矩阵 - UnConscsPayTokenPayRequest

> 类说明：云闪付支付API-签约支付-支付

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| applyId | applyid | R | 协议号；签约协议号（签约结果通知获取） | high |
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 | high |
| subject | subject | O | 订单标题；最大 100 个字节（约 50 个中文字符） | high |
| remark | remark | O | 备注信息 | high |
| chnlTrId | chnltrid | R | 渠道标记 id（银联分配） | high |
| smsCode | smscode | O | 短信验证码；免校验支付时可空 | high |
| thpInfo | thpinfo | O | 校验信息；获取短信验证码接口原样返回的校验信息 | high |
| notifyUrl | notify_url | O | 交易结果通知地址；必须为直接可访问的 url，不能携带参数 | high |

## 字段必填矩阵 - UnConscsPayTokenSetNoverRequest

> 类说明：云闪付支付API-签约支付-小额免检申请

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| applyId | applyid | R | 协议号；签约协议号（签约结果通知获取） | high |
| chnlTrId | chnltrid | R | 渠道标记 id（银联分配） | high |
| openType | opentype | R | 开启类型；取值见 field-enum-glossary.opentypeunconscspaytokensetnover | high |

## 字段必填矩阵 - UnConscsPayTokenSmsRequest

> 类说明：云闪付支付API-签约支付-交易短信验证码申请

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| agreeId | agreeid | R | 协议号；签约协议号（签约结果通知获取） | high |
| chnlTrId | chnltrid | R | 渠道标记 id（银联分配） | high |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 | high |
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| subject | subject | O | 订单标题；最大 100 个字节（约 50 个中文字符） | high |
| remark | remark | O | 备注信息；最大 160 个字节（约 80 个中文字符） | high |

## 字段必填矩阵 - UnConscsPayTokenUnbindRequest

> 类说明：云闪付支付API-签约支付-解约

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| applyId | applyid | R | 协议号；签约协议号（签约结果通知获取） | high |
| chnlTrId | chnltrid | R | 渠道标记 id（银联分配） | high |



