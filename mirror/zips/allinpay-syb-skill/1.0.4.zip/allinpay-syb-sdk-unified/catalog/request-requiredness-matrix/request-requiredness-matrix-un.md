# 字段必填矩阵 - Un

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - UnYwPayRequest

> 类说明：云闪付支付API-云微支付

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 | high |
| body | body | R | 订单标题；最大 100 个字节（约 50 个中文字符） | high |
| remark | remark | R | 备注信息 | high |
| expireTime | expiretime | R | 订单超时时间；格式 yyyyMMddHHmmss；最晚 24 小时 | high |
| appName | appname | R | 应用名称；填写小程序 ID/公众号 ID | high |
| limitPay | limit_pay | O | 支付限制；当前可用值见 field-enum-glossary.limitpay（本场景常用 `no_credit`） | high |
| notifyUrl | notify_url | R | 交易结果通知地址；必须为直接可访问的 url，不能携带参数 | high |
| appType | apptype | R | 交易发起场景；取值见 field-enum-glossary.apptypeunywpay | high |
| cusIp | cusip | R | 终端 ip；用户下单和调起支付的终端 ip，不可为空 | high |
| asInfo | asinfo | C | 分账信息；开通此业务需开通分账配置；格式 `cusid:type:amount[,cusid:type:amount]` | high |
| idNo | idno | O | 证件号；需 SM4 加密后上送 | high |
| trueName | truename | O | 付款人真实姓名；需 SM4 加密后上送 | high |
| encryptType | encrypttype | C | 加密方式；当前仅支持 `SM4`；当上送 `idNo/trueName` 时必填 | high |
| extendParams | extendparams | O | 拓展参数；JSON 字符串 | high |



