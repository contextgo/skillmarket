# Project Domain Fill Spec

用于“先收敛场景、再精确路由、再填参”的执行导航。  
本文件只定义链路与边界，不承载字段细节。

## 1) 文件职责（防漂移）

1. 本文件仅用于检索收敛与执行顺序约束。  
2. 本文件不是路由真源、字段真源、枚举真源。  
3. 禁止在本文件维护“业务域 -> 请求类”大表、字段级清单、枚举明细。

## 2) 单一真源

1. 请求路由真源：`catalog/request-routing-map.md`（请求类单表）与 `catalog/special-call-routing-map.md`（特殊调用）。  
2. 请求字段真源：`catalog/request-requiredness-matrix/request-requiredness-matrix-*.md`。  
3. 枚举真源：`catalog/field-enum-glossary.md`。  
4. 响应字段真源：`catalog/response-field-matrix.md`。

## 3) 执行顺序（必须遵守）

1. 对自然语言输入先做最小澄清（如主扫/被扫、后端下单/前端跳转）。  
2. 读取 `request-routing-map` 主表并按接口行精确选择 request 类与 `Requiredness shard`。  
3. 若存在多个候选 request 类，返回候选并向用户确认，禁止按语义相似度自动拍板。  
4. 仅读命中的 `request-requiredness-matrix-*` 分片，按 `R/C/O/U + 条件` 填参。  
5. 枚举取值只读 `field-enum-glossary.md`；响应 getter 只读 `response-field-matrix.md`。  
6. 特殊调用（上传/下载/通知/前端）按 `special-call-routing-map.md` 执行。

## 4) 维护约束（防债务回流）

1. 若 `request-routing-map.md` 的路由策略或证据要求变更，本文件必须同步更新。  
2. 若本文件与任一真源冲突，以真源为准并优先修订本文件。  
3. 废弃入口保持禁用：`request-api-index*` 与 `request-requiredness-matrix.md` 总索引。

