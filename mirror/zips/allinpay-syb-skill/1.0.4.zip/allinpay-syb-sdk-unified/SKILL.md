﻿---
name: allinpay-syb-sdk-unified
display_name: 通联收银宝业务技能（全量接口路由 + Java Demo）
description: 通联收银宝（SYB）业务 Skill：覆盖 allinpay-syb-sdk-java 全量 request API，按场景自动选择请求类并生成可运行 Java Demo。它依赖共享协议层（签名/异步通知/凭据边界/运行时要求），并提供“仅看代码/工程落地”两种输出模式。
version: 1.0.4
author: "allinpay | 开放平台"
license: "Allinpay"
compatibility:
  - skillhub
dependencies: []
metadata:
  skillhub:
    requires:
      config:
        - SYB_CUS_ID
        - SYB_APP_ID
        - SYB_SIGN_TYPE
        - SYB_SM4_KEY
        - SYB_MD5_KEY
        - SYB_PRI_KEY
        - SYB_PUB_KEY
        - SYB_ENV
triggers:
  - allinpay
  - 收银宝
  - syb sdk
  - request api
  - demo
  - maven
  - pom
  - pom.xml
  - 依赖
  - 脚手架
  - 落地
  - 只看代码
  - 不落地
  - 不改工程
  - 参考代码
  - 示例代码
  - 只要代码
  - 帮我加依赖
  - 加到pom
  - 加到pom.xml
  - 改pom
  - 改pom.xml
  - 生成到工程
  - 生成到目录
  - 可运行
  - 可编译
---

# 通联收银宝业务 Skill（全量接口路由 + Java Demo）

依赖：`allinpay-syb-pay-shared-base`（签名/验签、异步通知、凭据边界、运行时要求、SDK FAQ）。

## 目标与模式

仅支持 **Java + Maven**，输出模式固定二选一：

- `show_code_only`：只给可运行 Java 示例，不改工程。
- `scaffold_java_maven_demo`：给工程落地步骤与 JSON 工单（改 `pom.xml`、写 Demo、分级校验）。

默认：用户未明确要求落地时，使用 `show_code_only`。

## 路由与检索（必须遵守）

1. 先读 `catalog/project-domain-fill-spec.md` 做域级收敛。  
2. 读 `catalog/request-routing-map.md` 主路由表，按接口行直接选择精确 request 类与 `Requiredness shard`。  
3. 路由阶段禁止用自由文本模糊匹配直接下结论；若用户是自然语言描述，先做最小澄清，再回到主表逐行命中。  
4. 仅加载路由命中的一个矩阵分片：`catalog/request-requiredness-matrix/request-requiredness-matrix-*.md`。  
5. 在该分片内直接定位目标请求类小节（不再下钻其他索引或中间文件）。  
6. 非用户明确要求，不得同时加载多个 `request-requiredness-matrix` 分片或整目录。  
7. 若 `request-requiredness-matrix/*` 的 `条件` 列出现 `格式提示：` 或 `文档提示：`，生成代码时必须逐字遵守提示，禁止自造示例格式。  
8. 若 `文档提示：` 明确为“分钟/时长”，禁止输出日期时间字符串（如 `2026-04-23 00:00:00`）；若明确为日期时间格式（如 `yyyyMMddHHmmss`），禁止输出分钟数。

## 数据边界

- 本技能当前请求字段规则单一真源：`catalog/request-requiredness-matrix/`；响应字段白名单单一真源：`catalog/response-field-matrix.md`；枚举单一真源：`catalog/field-enum-glossary.md`。
- 路由单一入口：`catalog/request-routing-map.md`（请求类） + `catalog/special-call-routing-map.md`（特殊调用）。
- 以上内容用于检索与示例生成；不是签约文档全文。
- `request-requiredness-matrix` 中 `U` 表示未完全静态确认，禁止直接断言“必填/可选”。
- `request-requiredness-matrix` 采用人工维护单一真源；禁止自动脚本覆盖生成，仅允许执行校验脚本。
- `response-field-matrix.md` 由 SDK `api/response` 源码生成；生成响应处理代码、读取响应字段、解释 getter 时必须先查该矩阵，禁止臆造 SDK response 类不存在的字段/getter。
- SDK 版本以仓库 `allinpay-syb-sdk-java/pom.xml` 为准。

## 代码生成硬规则

- `R01` 初始化必须完整输出两步且保持同一变量名：先 `MerchantConfig merchantConfig = MerchantConfig.builder()...`，再紧随 `AllinpayApi.initialize(merchantConfig)`；禁止只输出 `builder()` 片段或省略 `initialize(...)`（`MerchantConfig` 无 `build()` 方法）。且 `builder()` 链必须按骨架显式包含以下参数项（可用占位值但不得删项）：`orgId(...)`、`cusId(...)`、`appId(...)`、`sm4Key(...)`、`signType(...)`、`md5Key(...)`、`priKeyStr(...)`、`pubKeyStr(...)`、`environment(...)`。缺任一项即违规。
- `R02` `MerchantConfig.builder()` 是允许且推荐用法；禁止范围仅限 SDK `request` 包模型，不得臆造 `SomeRequest.builder()/build()` 形态。  
- `R03` 参数顺序：必填 -> 条件必填 -> 可选。  
- `R04` 日志包含：请求 URL、请求报文、响应报文。  
- `R05` 异常处理：`AllinpayException` + `Exception`。  
- `R06` 参数默认按明文传入；若字段存在 SDK 注解 `@EncryptField`，由 SDK 负责加密。禁止手工二次加密。  
- `R07` Java 代码仅使用 SDK Java 属性名与 getter/setter，禁止用 JSON 字段名拼方法。  
- `R08` `AllinpayResp` 基础 getter 固定：`getRetCode()` / `getRetMsg()` / `getTrxId()`；其他响应字段必须来自 `catalog/response-field-matrix.md` 中目标响应类或其父类链，禁止臆造字段/getter。  
- `R09` Request 入参类型：除 `reference/sdk-request-java-field-types.md` 白名单字段外，`setXxx(...)` 入参一律 `String`，禁止自行改成数值/布尔/VO。
- `R10` `execObj(...)` 返回值必须使用请求对应类型接收：后端请求用对应 `*Response` 子类（如 `TranxQueryRequest -> TranxQueryResponse`、`UnitOrderPayRequest -> UnitOrderPayResponse`）；前端跳转白名单请求可用 `AllinpayFrontResp`。禁止直接用 `AllinpayResp` 变量接收。  
- `R11` 对“接口编号映射实体承载请求”（同一 Request 同时包含 `tranCode` + `bizData`）统一要求：`bizData` 由对应 SDK 实体序列化后按 `JSON -> UTF-8 -> Base64` 生成，禁止直接传原始 JSON。  
- `R12` 对 `ZhimaCreditMiniOrderRequest.bizData` 与 `PayScoreServiceOrderRequest.bizData`，JSON 文本构造必须使用 `JsonUtils.toJson(bizObj)`，且必须显式导入 `import com.allinpay.syb.sdk.core.utils.JsonUtils;`；禁止宣称“SDK 会自动把实体转 JSON”。  
- `R13` 接口编号、实体映射、三元组映射不在本文件内联维护；统一从 `catalog/field-enum-glossary.md` 读取（`trancode_*`、`bizdata_entity_*`、`actiontype_*`、`trxchnl_*`、`bizcontent_entity_*`）。  
- `R14` `bizData`/`bizContent` 构造必须使用词典中声明的 SDK 实体映射，禁止 `Map<String,Object>`、`JsonNode`、手写 JSON 字符串、父类空对象或自定义同名类。对 `UnionPayYJHXVoUserEncryptData`、`UnionPayYJHXVoAuditEncryptData` 必须按明文字段构造对象并直接赋值，禁止手工加密后再上送（加密由 SDK 字段链路处理）。  
- `R15` 非 `AllinpayReq` 的同包实体类（如 `UnionPayYJHXVo*`、`ZhimaCreditTCMiniOrder*`、`PayScoreTC*`）同样属于 SDK 参数协议，禁止新增同名/近似自定义类替换，禁止自行扩展不存在字段。
- `R16` `AllinpayApi.client()` 调用仅允许以下白名单形态（按场景匹配其一）：`execObj(HttpConfig.build(), request)`、`execObj(preProcess, HttpConfig.build(), request)`、`upload(HttpConfig.build(), request)`、`downloadToByte(HttpConfig.build(), url)`、`downloadToFile(HttpConfig.build(), url, savePath)`、`noticeHandle(noticeStr)`；禁止新增参数、交换参数顺序、或改成自定义重载调用。
- `R17` `AllinpayApi.client()` 实参来源必须遵循优先级：骨架已有变量/实参 > 用户明确提供参数 > `YOUR_XXX` 占位；禁止为“让示例跑通”自行臆造额外参数、默认常量、mock URL/mock reqsn。
- `R18` 若用户提供骨架且骨架中已存在 `AllinpayApi.client()` 调用，必须复用其调用形态与参数变量名（含 `HttpConfig` 变量/`noticeStr`/`savePath` 等）；仅允许在可编辑区补齐缺失赋值，禁止改写调用签名。
- `R19` `request` 字段赋值必须与当前 request 类真实 setter 一一对应；禁止把无关字段、跨接口字段、或非当前场景参数塞入后再传 `execObj/upload`。
- `R20` 若无法从骨架与用户输入确定某个 `AllinpayApi.client()` 必需实参，必须保留占位并明确标注“待业务侧提供”；不得猜值后直接写入调用。
- `R21` `AllinpayFrontResp` 仅允许用于以下白名单请求类（来源：SDK `ApiMethod` 的 `ApiType=FRONT_*`）：`UserTransCusPayRequest`、`QPayolAgreeApplyRequest`、`QPayolBindCardApplyRequest`、`GateWayPCRequest`、`GateWayH5Request`、`H5UnionPayOrderRequest`、`MerChantRepairCusrgcRequest`、`MerChantSecondPageRequest`、`ActivityActivityPageRequest`、`MerChantWxVerifyRequest`、`WxOpenGetOpenIdRequest`、`H5BillPayBillPayRequest`。
- `R22` 非上述白名单请求类，一律禁止使用 `AllinpayFrontResp` 作为接收类型；必须使用请求对应的 `*Response` 子类。
- `R23` 任何“主扫/二维码/支付页”语义都不能替代白名单判定；例如 `UnitOrderNativePayRequest` 必须接 `UnitOrderNativePayResponse`，不得改接 `AllinpayFrontResp`。
- `R24` 响应字段读取必须命中 `catalog/response-field-matrix.md`：
   - 先定位当前 `*Response` 类，再沿 `Extends` 父类链补充基础字段；
   - Java 代码只能调用矩阵中列出的 getter；
   - JSON 字段名只用于理解平台报文，禁止用 JSON 名拼接 Java 方法；
   - SDK response 未声明但业务文档提到的字段，不得臆造 getter，只能打印完整响应对象/原始响应并提示以 SDK/官方文档为准。
- `R25` 仅针对 `catalog/response-field-matrix.md` 的“字段是否存在 / getter 是什么”类问题，必须按以下顺序执行并输出证据后再下结论：
   - 先执行“双条件检索”：`类名 + 字段名`，禁止仅按字段名判断存在性；
   - 命中后必须做列对齐复核：`类` / `字段` / `JSON名` / `Getter` / `说明`；
   - 输出结论前必须附原文证据（命中片段或行号区间）；
   - 未完成证据复核时，只能回答“未完成核验”，禁止回答“不存在”；
   - 结论格式固定二选一：`已确认存在：<类>.<字段> -> <getter>` 或 `未检出：在 response-field-matrix.md 内按 <检索条件> 未命中`。
- `R26` 涉及 request 路由、字段必填性、响应字段/getter 的结论，必须先输出“检索链路证据”后再给答案：至少包含命中源文件路径与命中类名；未给出证据前禁止直接下结论。
- `R27` 任何“不存在/未支持/未收录”类否定结论，必须附可复核依据（检索条件 + 命中文件范围）；未完成证据复核时统一回复“未完成核验”，禁止给否定结论。
- `R28` 若出现来源冲突（如路由索引、矩阵、示例代码表述不一致），必须先显式列出冲突点并向用户确认，不得自行拍板选择其一。
- `R29` 结论输出格式必须可复核：优先使用“已确认存在：<类>.<字段> -> <getter>”或“未检出：<文件> 内按 <检索条件> 未命中”；禁止仅给口语化判断。
- `R30` “统一支付”与“统一支付API”（含不带空格写法）均为固定术语，路由必须命中 `UnitOrderPayRequest`。禁止因“统一下单/扫码/支付”等泛词把路由改到 `UnitOrderNativePayRequest`、`UnitOrderScanOrderRequest` 或其他 `UnitOrder*`。仅当用户明确出现“统一主扫”或“统一被扫”时，才允许切换到对应请求类。
- `R31` 若示例代码包含初始化片段，必须同时出现 `MerchantConfig merchantConfig = ...` 与 `AllinpayApi.initialize(merchantConfig)` 两行（或等价连续代码块）；并且 `orgId/cusId/appId/sm4Key/signType/md5Key/priKeyStr/pubKeyStr/environment` 必须逐项显式赋值。缺任一行或任一参数视为不合规输出。
- `R32` 对 `catalog/field-enum-glossary.md`、`catalog/response-field-matrix.md`、`catalog/request-routing-map.md` 等长文件，禁止“单段读取后直接下全局结论”。必须先全文件检索（按完整 key/类名），再按命中位置分段读取上下文，最后给结论。
- `R33` 对键名类结论（如 `trancodezhima`）必须使用完整键精确匹配，禁止前缀截断或简写（如 `trancode`）。若仅命中前缀，必须继续检索直到确认完整键后才可输出。
- `R34` 任意“未找到/不存在”结论必须满足三条件：①全文件检索已执行；②至少一次变体检索（如下划线/大小写/去空格）已执行；③输出检索表达式与命中文件范围。缺任一项时仅可回复“未完成核验”。
- `R35` 文件与通知场景的方法签名为强约束，不可替换：文件上传只能使用 `AllinpayApi.client().upload(HttpConfig.build(), request)`；文件下载只能使用 `downloadToByte(HttpConfig.build(), url)` 或 `downloadToFile(HttpConfig.build(), url, savePath)`；异步通知只能使用 `noticeHandle(noticeStr)`。禁止以 `execObj(...)` 或任意自定义封装替代上述调用。
- `R36` 任何响应字段或 getter 输出前，必须先执行并通过“响应字段链路”：`request-routing-map.md`（确定请求类）-> 响应类映射 -> `response-field-matrix.md`（字段/getter证据）-> `field-enum-glossary.md`（`retcode`/`trxstatus` 枚举语义）。缺任一步骤即禁止输出字段结论。
- `R37` 若未在 `response-field-matrix.md` 命中目标字段或 getter，不得给出“猜测字段”或“经验 getter”；只能返回“未完成核验/矩阵未命中”并附已执行检索证据。

## 响应码枚举限定（防止臆造）

- `retcode`、`trxstatus` 的枚举与语义统一以 `catalog/field-enum-glossary.md` 为唯一来源，禁止在本文件或回答中另起一份并产生漂移。  
- 输出时必须先引用词典中的既有枚举；若返回值不在词典集合，只能原样透传并提示“以官方最新文档为准”，禁止补全新枚举含义。

## 骨架锁定模式（用户给骨架时）

- 本 Skill 中“骨架”默认特指以下两个参考文件：`reference/UniversalSybDemo.java`（标准同步调用骨架）与 `reference/SpecialSceneSybDemo.java`（通知/上传/下载/前端跳转骨架）。若用户未另行指定骨架文件，必须以这两者作为生成与 patch 基准。  
- 仅 patch 指定可编辑区，不重写整类。  
- `package`、类名、方法签名、已有结构与命名保持一致。  
- import 仅允许：骨架已有 + SDK 存在类型 + `java.*`。  
- 若骨架是 setter 风格，禁止改 Builder；反之亦然。  
- 若含 `[LOCK-BEGIN]/[LOCK-END]`，锁定区不可改。  
- 生成后必须执行一致性自检，不通过则重做。

## 特殊场景规则

- 标准接口示例参考：`reference/UniversalSybDemo.java`。  
- 特殊场景（通知/上传/下载/前端跳转）参考：`reference/SpecialSceneSybDemo.java`。  
- `AllinpayFrontResp` 必须按 `request.apiMethod().getApiType()` 处理：
  - `FRONT_URL` -> `urlJump`
  - `FRONT_HTML` -> `htmlJump`
  - `FRONT_BOTH` -> 同时兼容

## 输出结构（每次必含）

1. **Intent**：`show_code_only` 或 `scaffold_java_maven_demo`（含判定依据）  
2. **Routing**：命中 request 类与理由  
3. **Demo（Java）**：可运行示例  
4. **Production notes**：幂等、重试、验签、脱敏、终态确认（回调+查询）

若为 `scaffold_java_maven_demo`，追加：

5. **工程落地步骤（Java + Maven）**：`projectDir`、依赖处理、Demo 路径、分级校验策略  
6. **scaffold 工单（JSON）**：`intent`、`changes`、`validation`
7. **落地自检（Checklist）**：按下方 5 条固定清单逐条给出“通过/不通过 + 一句话证据”

若为 `show_code_only`，仍保留步骤与 JSON 小节，但写明“仅展示代码，不修改工程”，并将 `changes`/`validation` 置空数组。

## 工程落地约定（Maven only）

- 仅支持 Maven（`pom.xml`）；Gradle/其他构建工具直接说明不支持并给 Maven 方案。  
- 依赖 GAV：`com.allinpay.cus.sdk:allinpay-syb-sdk-java`（版本默认跟随仓库 SDK `pom.xml`，除非用户指定）。  
- 有工程则补依赖与 Demo；无工程则创建最小 Maven 工程。  
- Demo 默认包名：优先复用现有包；无法判断时用 `com.allinpay.syb.demo`。  
- 校验策略采用“分级校验”，避免无 Maven 或坏工程时长时间重试：  
  - `L1` 静态校验：import 与类型可解析、第三方包在 `pom.xml` 中可追溯、测试代码位于 `src/test/java`；  
  - `L2` 环境预检：仅当 `mvn -v` 成功时才进入 Maven 编译；  
  - `L3` Maven 校验：默认 `mvn -q -DskipTests compile`，用户明确要求打包时再执行 `package`。
- 落地风格默认“SDK 直连最小实现”：未被用户明确要求时，禁止新增通用封装层（如 Facade/Adapter/Gateway 等）。
- `execObj(...)` 返回值应使用请求对应类型：后端请求用对应 `*Response` 子类；前端跳转白名单请求可用 `AllinpayFrontResp`。禁止统一降级为 `AllinpayResp` 基类接收。

## 落地输出自检模板（scaffold 必填）

当 `intent=scaffold_java_maven_demo` 时，输出末尾必须追加如下 5 条自检：

1. **SDK 类型真实性**：未使用 SDK 中不存在的类/方法（如虚构 Builder 类型）。  
2. **响应/调用形态正确性**：  
   - 标准请求：每个 `execObj(...)` 都由请求对应类型接收（后端 `*Response` / 前端白名单 `AllinpayFrontResp`）；  
   - 前端跳转：仅白名单请求类可使用 `AllinpayFrontResp`，并按 `ApiType` 处理 `urlJump/htmlJump`；  
   - 异步通知：使用 `noticeHandle(noticeStr)`，不走普通 `execObj`；  
   - 文件能力：上传/下载使用 `upload(...)`、`downloadToByte(...)`/`downloadToFile(...)`。  
3. **初始化正确性**：`MerchantConfig.builder()` 链式赋值后直接传入 `initialize(...)`，且未出现 `MerchantConfig.builder()...build()`。  
4. **无过度封装**：未新增未授权的 Facade/Adapter/Gateway 等抽象层。  
5. **可编译校验**：已输出分级校验结果（`L1/L2/L3`），并说明是否执行 Maven 命令及未执行原因。  
6. **client 调用参数真实性**：所有 `AllinpayApi.client()` 调用均命中白名单签名，且实参来自骨架/用户输入/占位三类合法来源之一，无臆造参数。  

## 参考入口

- `catalog/project-domain-fill-spec.md`
- `catalog/request-routing-map.md`
- `catalog/request-requiredness-matrix/`
- `catalog/response-field-matrix.md`
- `catalog/field-enum-glossary.md`
- `catalog/scaffold-protocol.md`
- `reference/sdk-request-java-field-types.md`


