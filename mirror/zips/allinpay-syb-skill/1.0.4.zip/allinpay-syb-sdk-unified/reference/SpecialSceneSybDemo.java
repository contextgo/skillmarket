import com.allinpay.syb.sdk.api.AllinpayApi;
import com.allinpay.syb.sdk.api.enums.Environment;
import com.allinpay.syb.sdk.api.enums.SignType;
import com.allinpay.syb.sdk.api.request.FileUploadRequest;
import com.allinpay.syb.sdk.api.request.MerChantRepairCusrgcRequest;
import com.allinpay.syb.sdk.api.request.TrxFileGetRequest;
import com.allinpay.syb.sdk.api.response.AllinpayFrontResp;
import com.allinpay.syb.sdk.api.response.FileUploadResponse;
import com.allinpay.syb.sdk.api.response.TrxFileGetResponse;
import com.allinpay.syb.sdk.core.AllinpayException;
import com.allinpay.syb.sdk.core.config.HttpConfig;
import com.allinpay.syb.sdk.core.config.MerchantConfig;
import com.allinpay.syb.sdk.core.http.DownloadResult;
import com.allinpay.syb.sdk.core.utils.JsonUtils;
import com.allinpay.syb.sdk.core.utils.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Base64;
import java.util.Map;

public class SpecialSceneSybDemo {

    /**
     * SDK 原生初始化示例（应用启动时执行一次）
     */
    public static void initSdk() {
        AllinpayApi.initialize(MerchantConfig.builder()
                .orgId("")
                .cusId("YOUR_CUS_ID")
                .appId("YOUR_APP_ID")
                .sm4Key("YOUR_SM4_KEY")
                .signType(SignType.RSA)
                .md5Key("")
                .priKeyStr("YOUR_PRI_KEY")     // 非MD5签名必填
                .pubKeyStr("YOUR_PUB_KEY")     // 非MD5签名必填
                .environment(Environment.TEST)
        );
    }

    /**
     * 特殊场景1：异步通知报文验签与解析
     */
    public static Map<String, String> noticeHandle(String noticeStr) {
        initSdk();
        try {
            Map<String, String> handle = AllinpayApi.client().noticeHandle(noticeStr);
            System.out.println("通知报文：" + JsonUtils.toJson(handle));
            return handle;
        } catch (AllinpayException e) {
            System.out.println("通知报文解析异常：" + e.getMessage());
            return null;
        }
    }

    /**
     * 特殊场景2：文件上传
     */
    public static FileUploadResponse uploadFile(String fileType, String filePath) {
        initSdk();
        try {
            FileUploadRequest request = new FileUploadRequest();
            request.setFileType(fileType);
            request.setFilecontent(fileToBytes(new File(filePath)));
            FileUploadResponse response = AllinpayApi.client().upload(HttpConfig.build(), request);
            System.out.println("响应报文：" + JsonUtils.toJson(response));
            return response;
        } catch (AllinpayException e) {
            System.out.println("上传异常：" + e.getMessage());
        } catch (IOException e) {
            System.out.println("读取文件异常：" + e.getMessage());
        }
        return null;
    }

    /**
     * 特殊场景3：先获取对账文件下载地址，再下载
     */
    public static void downloadTrxFile(String date, String fileType, String savePath) {
        initSdk();
        try {
            TrxFileGetRequest request = new TrxFileGetRequest();
            request.setDate(date);
            request.setFileType(fileType);
            TrxFileGetResponse response = AllinpayApi.client().execObj(HttpConfig.build(), request);
            System.out.println("响应报文：" + JsonUtils.toJson(response));

            if (!StringUtils.isEmpty(response.getUrl())) {
                DownloadResult inMemory = AllinpayApi.client().downloadToByte(HttpConfig.build(), response.getUrl());
                System.out.println("内存下载字节长度：" + (inMemory.getFileData() == null ? 0 : inMemory.getFileData().length));

                DownloadResult localFile = AllinpayApi.client().downloadToFile(HttpConfig.build(), response.getUrl(), savePath);
                System.out.println("保存路径：" + localFile.getFilePath());
            }
        } catch (AllinpayException e) {
            System.out.println("下载异常：" + e.getMessage());
        } catch (Exception e) {
            System.out.println("系统异常：" + e.getMessage());
        }
    }

    /**
     * 特殊场景4：前端跳转（URL 与 HTML 片段）
     */
    public static AllinpayFrontResp frontJump(String jumpUrl) {
        initSdk();
        try {
            MerChantRepairCusrgcRequest request = new MerChantRepairCusrgcRequest();
            request.setJumpUrl(jumpUrl);
            AllinpayFrontResp response = AllinpayApi.client().execObj(HttpConfig.build(), request);
            System.out.println("响应报文：" + JsonUtils.toJson(response));
            // MERCHANT_REPAIR_CUSRGC 在 ApiMethod 中定义为 ApiType.FRONT_BOTH
            // 因此该接口示例固定输出 urlJump 与 htmlJump 两种结果
            System.out.println("URL: " + response.getUrlJump());
            if (!StringUtils.isEmpty(response.getHtmlJump())) {
                System.out.println("HTML: " + new String(Base64.getDecoder().decode(response.getHtmlJump()), StandardCharsets.UTF_8));
            }
            return response;
        } catch (AllinpayException e) {
            System.out.println("跳转异常：" + e.getMessage());
            return null;
        }
    }

    private static byte[] fileToBytes(File file) throws IOException {
        if (!file.exists()) {
            throw new FileNotFoundException("文件不存在：" + file.getAbsolutePath());
        }
        try (InputStream in = Files.newInputStream(file.toPath());
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024 * 8];
            int len;
            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }
            return out.toByteArray();
        }
    }
}

