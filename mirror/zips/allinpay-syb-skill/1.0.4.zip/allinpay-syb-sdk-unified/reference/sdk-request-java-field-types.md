# 收银宝 Java SDK — *Request 非 String 字段一览

本文档列出 `com.allinpay.syb.sdk.api.request` 包内各 `*Request` 与 `AllinpayReq` 中，**在类体上声明且非 `java.lang.String`** 的字段（与随附 `allinpay-syb-sdk-java` 源码版本一致）。便于集成时按正确 Java 类型调用 `setXxx(...)`。

## 对接约定

- 除下表所列字段外，其余在请求类上声明、通过 `setXxx(...)` 参与组包的成员，**Java 类型均为 `java.lang.String`**（含金额「分」、枚举码、期数、时间、流水号等）。
- 示例与业务代码中，对上述字符串字段请使用**字符串字面量或已规范化的字符串变量**传入 setter，**不要**改为 `int`/`long`/`BigDecimal`/`boolean` 等类型再传入。
- 仅下表允许非 `String`；其它字段不得自行改为 `byte[]`、业务 VO 等类型。
- 对实体类型字段（当前仅 `UnionPayYJHXCmnRequest.bizContent`、`UnionPayYJHXCoupRequest.bizContent`）必须按三元组赋值：`actionType` + `trxChnl` + `bizContent(UnionPayYJHXVoBiz 子类)`；禁止缺项与错配。

## 非 String 字段表

| 类 | 字段（Java 属性名） | Java 类型 | 说明 |
| --- | --- | --- | --- |
| AllinpayReq | specBody | Map<String, String> | 键值型扩展参数；常见支付请求通常无需设置，按业务文档或示例使用。 |
| FileUploadRequest | filecontent | byte[] | 文件上传类接口：请求体中的二进制正文（字节数组）。 |
| RiskFeeBackAliComplaintFileUploadRequest | file_content | byte[] | 文件上传类接口：请求体中的二进制正文（字节数组）。 |
| RiskFeeBackWxAppletUploadRequest | file | byte[] | 文件上传类接口：请求体中的二进制正文（字节数组）。 |
| RiskFeeBackWxMerchantImageUploadRequest | file | byte[] | 文件上传类接口：请求体中的二进制正文（字节数组）。 |
| SybServiceUploadElectTicketRequest | file | byte[] | 文件上传类接口：请求体中的二进制正文（字节数组）。 |
| UnionPayYJHXCmnRequest | bizContent | UnionPayYJHXVoBiz | 银联易加核销等场景的聚合业务对象，仅用于对应请求的 bizContent 字段组装。 |
| UnionPayYJHXCoupRequest | bizContent | UnionPayYJHXVoBiz | 银联易加核销等场景的聚合业务对象，仅用于对应请求的 bizContent 字段组装。 |

**说明**：`UnionPayYJHXVoBiz` 及其子类定义于同包，其内部还可包含 `byte[]` 与嵌套 VO 等；这些仅用于组装对应请求的 `bizContent`，**不要**把普通 `*Request` 上的字符串字段改成 VO 或二进制类型。

表中标记为 **AllinpayReq** 的条目为各请求类继承的**基类**字段。
