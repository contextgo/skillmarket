---
name: allinpay-syb-skill
description: 通联收银宝SYB一体化技能包，收银宝分诊导航，共享协议与业务接口路由、字段索引、Java与Maven示例及工程落地，面向接入与联调。
---

> **产品定位**：`allinpay-syb-skill` 是面向通联收银宝（SYB）接入与联调的官方技能包。根目录负责场景分诊与使用指引，`allinpay-syb-pay-shared-base/` 提供协议与安全治理能力，`allinpay-syb-sdk-unified/` 提供接口路由、字段规则与 Java 示例规范。建议先阅读本文件，再进入对应子模块。


# 通联收银宝接入总入口

用于分诊，不负责字段细节。目标是把请求快速路由到正确子技能。

## 路由规则

1. 签名/验签/异步通知/幂等/凭据边界/运行时 -> `allinpay-syb-pay-shared-base`  
2. 选 request 类、生成 Java 示例、工程落地 -> `allinpay-syb-sdk-unified`

## 交付模式

- `show_code_only`：只展示 Java 示例，不改工程  
- `scaffold_java_maven_demo`：输出工程落地步骤 + JSON 工单（Maven）

默认使用 `show_code_only`；仅当用户明确要求“生成到目录/改 pom/可编译运行”时切到 `scaffold_java_maven_demo`。  
落地场景的编译校验采用“分级校验（L1/L2/L3）”，避免无 Maven 或坏工程时长时间重试。

## 最短澄清问题

- 你要做哪个阶段：下单/查询/退款/回调/文件/前端跳转？  
- 你要只看代码，还是要落地到工程并执行 `mvn package`？

## 检索约束

- 本 Skill 只做路由，不展开大表。  
- 涉及字段或必填性时，直接转到 `allinpay-syb-sdk-unified`，由其按“索引 -> 单分片”读取。  
- 避免在入口层重复输出 shared/unified 的详细规则。
- 用户已指定本技能（或其子技能）时，必须先走技能内路由与本地真源链路，禁止先跳出到外部站点再反推结论。  
- 先在本地 `request-routing-map.md` 与 `request-requiredness-matrix-*` 内定位；未完成本地检索前，不得回答“不支持/未收录”。

