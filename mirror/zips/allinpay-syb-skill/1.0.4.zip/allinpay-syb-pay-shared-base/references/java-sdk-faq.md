# 收银宝 Java SDK — 常见问题（FAQ）

以下内容对应产品文档「收银宝 Java SDK」**第六章 FAQ** 的要点，放在**共享协议层**技能中维护：与加验签、敏感字段加密、凭据与运行时说明同属一条阅读路径；**本文不含任何外部网页链接**。

---

## 1. 如何加验签？

SDK 内部已对**请求报文**做加签，对**响应报文**做验签。开发者只需按说明配置好对应密钥等信息即可，**无需**再自行编写加签、验签逻辑。协议层通用约定另见本技能内 **签名与验签** 专篇。业务技能中另有 **Request 字段 Java 类型闭集白名单**（避免生成代码时擅自把 `String` 改成数值类型）。

---

## 2. 敏感字段如何加密？

SDK 内部已对敏感信息字段做加密处理。开发者只需按说明配置好对应密钥等信息即可，**无需**再自行加密；业务侧对敏感字段**上送明文**即可。

---

## 3. 多商户模式如何构建支付客户端？

单商户场景下，按「使用说明」初始化一次即可。若存在**多商户**，可对不同商户分别多次调用 `AllinpayApi.initialize(MerchantConfig.builder()...)`，为每个商户配置各自的基础参数与密钥（示例中仅突出 `cusId`，其余字段与单商户相同）。  
注意：`MerchantConfig` 本身无 `build()` 方法，不可写 `MerchantConfig.builder()...build()`。

```java
AllinpayApi.initialize(MerchantConfig.builder()
    .cusId("商户1")
    // ... 其它参数
);
AllinpayApi.initialize(MerchantConfig.builder()
    .cusId("商户2")
    // ... 其它参数
);
AllinpayApi.initialize(MerchantConfig.builder()
    .cusId("商户3")
    // ... 其它参数
);

// 发起请求时，在请求对象上指定本次使用的商户号
req.setCusId("指定请求的商户号");
// ... 其它业务参数
```

---

## 4. 想用 OkHttp、HttpClient 等自有 HTTP 客户端替代 SDK 内置实现，如何改造？

1. 初始化时在 `MerchantConfig.builder()` 上配置 `.customHttp(new CustomHttp())`（`CustomHttp` 为自行编写的实现类）。
2. 新建类**继承** `AbstractHttp`，**重写** `post` 方法：仅支持 POST；入参为已构造好的请求参数（`Map` 形态）；返回**响应体字符串**。SDK 已在调用链中处理加签与验签，实现类只需完成「发请求、读响应字符串」。
3. **重要**：**只有**调用 **`execRaw`** 时会走上述 `CustomHttp`；调用 **`execObj`** 或其它路径时，仍使用 SDK **内置** HTTP 客户端。

```java
AllinpayApi.initialize(MerchantConfig.builder()
    // ... 其它参数
    .customHttp(new CustomHttp())
);

// 自研 HTTP：继承 AbstractHttp，重写 post
public class CustomHttp extends AbstractHttp {
    /**
     * 仅支持 POST，返回响应字符串。
     * 加签、验签已由 SDK 处理，此处只实现网络传输。
     *
     * @param certsConfig 基础证书/密钥相关配置
     * @param httpConfig  URL、请求头等 HTTP 信息
     * @param request     已构造好的请求参数（Map）
     * @return 响应报文字符串
     */
    @Override
    public String post(CertsConfig certsConfig, HttpConfig httpConfig, Map<String, String> request)
            throws AllinpayException {
        // 使用 OkHttp / HttpClient 等自行实现
        String response = yourHttpClientPost(request);
        return response;
    }
}

// 调用方式与文档示例一致；须使用 execRaw 才会进入 CustomHttp
String response = AllinpayApi.client()
    .execRaw((httpConfig, readOnlyRequest) -> {
        // 可选：打印请求头、URL、报文等
    }, config, req);
```

---

## 5. `execObj` 与 `execRaw` 有什么区别？

| 方法 | 返回值 |
| --- | --- |
| **`execObj`** | SDK 内部封装的**响应对象**（如各类 `*Response`），便于按字段访问。 |
| **`execRaw`** | **原始报文**的**字符串**结果，便于接入自有解析或与 `CustomHttp` 配合。 |

---

## 与其它资料的衔接

- **请求路由与字段索引**：见业务技能模块中的路由表与按前缀分片的字段说明等；本专篇不替代接口字段级文档。  
- **Java 调用骨架（标准接口与特殊场景）**：见业务技能模块随附的同步调用示例与通知、上传、下载、前端跳转等示例代码。  
- **签名、异步通知、凭据边界、Java 与 Maven 运行时**：见本技能内同名专篇（与本文同一套资料）。
