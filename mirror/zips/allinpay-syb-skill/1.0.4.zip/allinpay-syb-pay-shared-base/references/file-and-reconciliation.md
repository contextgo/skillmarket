# 文件与对账（SYB）

本页是“共享协议层”的导航页，帮助你快速判断文件/对账相关能力应该怎么走。

## 常见诉求

| 你想做什么 | 典型做法 | 推荐入口 |
| --- | --- | --- |
| 下载对账文件 | 先获取下载链接，再下载到内存或文件 | 业务 Skill：`allinpay-syb-sdk-unified`（`TrxFileGetRequest` + `downloadToByte/file`） |
| 上传图片/材料 | 调用文件上传接口 | 业务 Skill：`allinpay-syb-sdk-unified`（`FileUploadRequest` + `upload`） |

## 重要提示

- 对账/文件能力属于“特殊调用方式”，不完全等同于普通 `execObj(request)`
- 生产上建议：
  - 下载文件做落盘校验（大小/哈希/重试）
  - 对账文件属于敏感数据，注意访问控制与保存周期

