# 签名与验签（通联收银宝 SYB）

> 本文是“协议层”说明，尽量语言无关。Java 具体初始化方式请看 `runtime/java-maven.md`。

## 1) 你需要知道的最小事实

- 收银宝请求一般包含：`cusid/appid/reqsn/randomstr/signtype/sign` 等通用字段
- **非 MD5 签名**（RSA/SM2/RSA2）通常需要配置私钥/公钥  
- 部分敏感字段使用 `@EncryptField`（SM4）由 SDK 自动加密，调用方传明文

## 2) 凭据与边界

所有密钥类配置（SM4Key、私钥、公钥、MD5Key）属于敏感信息：

- 只允许出现在服务端配置中心 / 环境变量 / 密钥管理系统
- 严禁硬编码进代码仓库
- 严禁输出到日志

详见：`governance/credential-boundary.md`。

## 3) Java（SDK）推荐姿势

Java 使用 SDK 原生初始化：

- `MerchantConfig merchantConfig = MerchantConfig.builder().cusId(...).appId(...).signType(...).environment(...); AllinpayApi.initialize(merchantConfig)`
- 请求发起：`AllinpayApi.client().execObj(HttpConfig.build(), request)`
- 通知验签与解析：`AllinpayApi.client().noticeHandle(noticeStr)`

注意：`MerchantConfig` 无 `build()` 方法，禁止写 `MerchantConfig.builder()...build()`。

> 业务 Skill 会生成可运行 Java demo，并统一带请求/响应日志与异常处理。

