# Java + Maven 运行时要求（通联收银宝 SYB）

## Maven 依赖

```xml
<dependency>
  <groupId>com.allinpay.cus.sdk</groupId>
  <artifactId>allinpay-syb-sdk-java</artifactId>
  <version>1.1.11</version>
</dependency>
```

- **Central 索引**：[com.allinpay.cus.sdk:allinpay-syb-sdk-java](https://central.sonatype.com/artifact/com.allinpay.cus.sdk/allinpay-syb-sdk-java)（与产品文档中心 [收银宝 Java SDK 接入指引](https://prodoc.allinpay.com/doc/2471/) 同一坐标体系）
- **传递依赖（文档中心常列）**：`jackson-databind` 2.10.1、`bcprov-jdk15on` 1.59；以工程 `mvn dependency:tree` 为准

## Java 版本

- 建议 Java 8+（产品文档要求 JDK 1.8 及以上）

## 初始化（SDK 原生）

业务 Skill 的 demo 统一使用：

- `AllinpayApi.initialize(MerchantConfig.builder()...)`

并强调：

- **非 MD5 签名必填**：`priKeyStr` / `pubKeyStr`
- `@EncryptField`：传明文，SDK 自动 SM4 加密

