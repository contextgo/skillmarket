﻿# Request API With Fields

Auto generated from SDK request classes.

Total request classes: **188**

## ActivityActivityPageRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| actId | actid | N | - | See project-domain-fill-spec and field-enum-glossary |
| userId | userid | N | - | See project-domain-fill-spec and field-enum-glossary |

## ActivityCusActivityRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| corpBusName | corpbusname | N | - | See project-domain-fill-spec and field-enum-glossary |
| branchName | branchname | N | - | See project-domain-fill-spec and field-enum-glossary |
| areaCode | areacode | N | - | See project-domain-fill-spec and field-enum-glossary |
| address | address | N | - | See project-domain-fill-spec and field-enum-glossary |
| actType | acttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| zipPicUrl | zippicurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| actDetail | actdetail | N | - | See project-domain-fill-spec and field-enum-glossary |

## ActivityQueryActivityRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| actType | acttype | N | - | See project-domain-fill-spec and field-enum-glossary |

## AllinpayReq

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| orgId | orgid | N | - | See project-domain-fill-spec and field-enum-glossary |
| cusId | cusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| appId | appid | N | - | See project-domain-fill-spec and field-enum-glossary |
| version | version | N | - | See project-domain-fill-spec and field-enum-glossary |
| randomStr | randomstr | N | - | See project-domain-fill-spec and field-enum-glossary |
| specBody | - | N | - | See project-domain-fill-spec and field-enum-glossary |

## AllinpayReqInf

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## B2bOrderDirectPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctNo | acctno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| acctName | acctname | Y | - | See project-domain-fill-spec and field-enum-glossary |
| acctType | accttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| bankCode | bankcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| goodsInfo | goodsinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| encrypttype | encrypttype | N | - | See project-domain-fill-spec and field-enum-glossary |

## B2bOrderPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctNo | acctno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| acctName | acctname | Y | - | See project-domain-fill-spec and field-enum-glossary |
| acctType | accttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| bankCode | bankcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| goodsInfo | goodsinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| encrypttype | encrypttype | N | - | See project-domain-fill-spec and field-enum-glossary |

## BillPayAddRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digId | digid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payerCusId | payercusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| billId | billid | N | - | See project-domain-fill-spec and field-enum-glossary |
| subject | subject | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| autoPay | autopay | N | - | See project-domain-fill-spec and field-enum-glossary |
| autoPayTime | autopaytime | N | - | See project-domain-fill-spec and field-enum-glossary |

## BillPayDelRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digId | digid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| billId | billid | N | - | See project-domain-fill-spec and field-enum-glossary |

## BillPayQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digId | digid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| billId | billid | N | - | See project-domain-fill-spec and field-enum-glossary |

## BillPayRefundRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digId | digid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| billId | billid | N | - | See project-domain-fill-spec and field-enum-glossary |
| refundAmt | refundamt | N | - | See project-domain-fill-spec and field-enum-glossary |

## BillPaySetOfflinePayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digId | digid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| billId | billid | N | - | See project-domain-fill-spec and field-enum-glossary |

## CusAcctQueryAcctOverLimitRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## CusAcctQueryBalanceRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| acctType | accttype | N | - | See project-domain-fill-spec and field-enum-glossary |

## CusAcctQueryHisBalanceRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| acctDate | acctdate | N | - | See project-domain-fill-spec and field-enum-glossary |

## CusAcctQueryTrxRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxType | trxtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |

## CusAcctTransferBalRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| payerCusId | payercusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |

## CusAcctWithDrawQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |

## CusAcctWithDrawRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| depType | deptype | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| summary | summary | N | - | See project-domain-fill-spec and field-enum-glossary |

## DigitalConfirmAuthCusStateRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digId | digid | N | - | See project-domain-fill-spec and field-enum-glossary |
| confirmStatus | confirmstatus | N | - | See project-domain-fill-spec and field-enum-glossary |

## DigitalQueryAuthCusStateRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digTalId | digtalid | N | - | See project-domain-fill-spec and field-enum-glossary |
| innerAppid | innerappid | N | - | See project-domain-fill-spec and field-enum-glossary |
| authCusId | authcusid | N | - | See project-domain-fill-spec and field-enum-glossary |

## DigitalSendCouponsRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digId | digid | N | - | See project-domain-fill-spec and field-enum-glossary |
| stockId | stockid | N | - | See project-domain-fill-spec and field-enum-glossary |
| openId | openid | N | - | See project-domain-fill-spec and field-enum-glossary |
| couponValue | couponvalue | N | - | See project-domain-fill-spec and field-enum-glossary |
| couponMiniMum | couponminimum | N | - | See project-domain-fill-spec and field-enum-glossary |

## DigitalUrlRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digitalId | digitalid | N | - | See project-domain-fill-spec and field-enum-glossary |
| authUserId | authuserid | N | - | See project-domain-fill-spec and field-enum-glossary |
| authCusId | authcusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| branchNo | branchno | N | - | See project-domain-fill-spec and field-enum-glossary |
| branchName | branchname | N | - | See project-domain-fill-spec and field-enum-glossary |

## DigitalWxCateringOrderSyncStatusRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digId | digid | N | - | See project-domain-fill-spec and field-enum-glossary |
| subAppid | sub_appid | N | - | See project-domain-fill-spec and field-enum-glossary |
| outShopNo | outshopno | N | - | See project-domain-fill-spec and field-enum-glossary |
| subOpenId | subopenid | N | - | See project-domain-fill-spec and field-enum-glossary |
| loginToken | logintoken | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderEntry | orderentry | N | - | See project-domain-fill-spec and field-enum-glossary |
| totalAmount | totalamount | N | - | See project-domain-fill-spec and field-enum-glossary |
| discountAmount | discountamount | N | - | See project-domain-fill-spec and field-enum-glossary |
| userAmount | useramount | N | - | See project-domain-fill-spec and field-enum-glossary |
| status | status | N | - | See project-domain-fill-spec and field-enum-glossary |
| actionTime | actiontime | N | - | See project-domain-fill-spec and field-enum-glossary |
| payTime | paytime | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlTrxId | chnltrxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| dishList | dishlist | N | - | See project-domain-fill-spec and field-enum-glossary |
| outTableNo | outtableno | N | - | See project-domain-fill-spec and field-enum-glossary |
| peopleCount | peoplecount | N | - | See project-domain-fill-spec and field-enum-glossary |

## FileUploadRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| fileType | filetype | N | - | See project-domain-fill-spec and field-enum-glossary |
| filecontent | - | N | - | See project-domain-fill-spec and field-enum-glossary |

## FqfApplyRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptType | encrypttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctNo | acctno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| fqNum | fqnum | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| idType | idtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctName | acctname | Y | - | See project-domain-fill-spec and field-enum-glossary |
| mobile | mobile | Y | - | See project-domain-fill-spec and field-enum-glossary |
| currency | currency | N | - | See project-domain-fill-spec and field-enum-glossary |
| subject | subject | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxReserve | trxreserve | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |

## FqfBbSignPageRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctNo | acctno | N | - | See project-domain-fill-spec and field-enum-glossary |
| feeNum | feenum | N | - | See project-domain-fill-spec and field-enum-glossary |

## FqfInfoRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctNo | acctno | N | - | See project-domain-fill-spec and field-enum-glossary |

## FqfJDBTCountFeeRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |

## FqfJDBTPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| fqNum | fqnum | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| cusIp | cusip | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| extendParams | extendparams | N | - | See project-domain-fill-spec and field-enum-glossary |

## FqfJfqPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptType | encrypttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| unPid | unpid | N | - | See project-domain-fill-spec and field-enum-glossary |
| maskedAcctNo | maskedacctno | N | - | See project-domain-fill-spec and field-enum-glossary |
| bankCode | bankcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| fqNum | fqnum | N | - | See project-domain-fill-spec and field-enum-glossary |
| senceFlag | senceflag | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| trueName | truename | Y | - | See project-domain-fill-spec and field-enum-glossary |
| mobile | mobile | Y | - | See project-domain-fill-spec and field-enum-glossary |
| loginStatus | loginstatus | N | - | See project-domain-fill-spec and field-enum-glossary |
| retType | rettype | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| frontUrl | front_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| extendParams | extendparams | N | - | See project-domain-fill-spec and field-enum-glossary |

## FqfPayConfirmRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptType | encrypttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctNo | acctno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| fqNum | fqnum | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| idType | idtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctName | acctname | Y | - | See project-domain-fill-spec and field-enum-glossary |
| mobile | mobile | Y | - | See project-domain-fill-spec and field-enum-glossary |
| currency | currency | N | - | See project-domain-fill-spec and field-enum-glossary |
| subject | subject | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxReserve | trxreserve | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| smsCode | smscode | N | - | See project-domain-fill-spec and field-enum-glossary |
| thpInfo | thpinfo | N | - | See project-domain-fill-spec and field-enum-glossary |

## GateWayH5Request

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| charset | charset | N | - | See project-domain-fill-spec and field-enum-glossary |
| retUrl | returl | N | - | See project-domain-fill-spec and field-enum-glossary |
| retType | rettype | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| limitPay | limit_pay | N | - | See project-domain-fill-spec and field-enum-glossary |
| asInfo | asinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| subBranch | subbranch | N | - | See project-domain-fill-spec and field-enum-glossary |
| gateId | gateid | N | - | See project-domain-fill-spec and field-enum-glossary |
| idType | idtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | N | - | See project-domain-fill-spec and field-enum-glossary |
| trueName | truename | N | - | See project-domain-fill-spec and field-enum-glossary |

## GateWayPCRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| charset | charset | N | - | See project-domain-fill-spec and field-enum-glossary |
| retUrl | returl | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| goodsId | goodsid | N | - | See project-domain-fill-spec and field-enum-glossary |
| goodsInf | goodsinf | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderId | orderid | N | - | See project-domain-fill-spec and field-enum-glossary |
| gateId | gateid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payType | paytype | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| limitPay | limitpay | N | - | See project-domain-fill-spec and field-enum-glossary |

## H5BillPayBillPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| digId | digid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| billId | billid | N | - | See project-domain-fill-spec and field-enum-glossary |

## H5UnionPayOrderRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| payType | paytype | N | - | See project-domain-fill-spec and field-enum-glossary |
| fqNum | fqnum | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| uniReqSn | unireqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| charset | charset | N | - | See project-domain-fill-spec and field-enum-glossary |
| retUrl | returl | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| expireTime | expiretime | N | - | See project-domain-fill-spec and field-enum-glossary |
| limitPay | limit_pay | N | - | See project-domain-fill-spec and field-enum-glossary |
| goodsTag | goods_tag | N | - | See project-domain-fill-spec and field-enum-glossary |
| benefitDetail | benefitdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| asInfo | asinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| subBranch | subbranch | N | - | See project-domain-fill-spec and field-enum-glossary |
| extendParams | extendparams | N | - | See project-domain-fill-spec and field-enum-glossary |
| trueName | truename | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | N | - | See project-domain-fill-spec and field-enum-glossary |
| isHide | ishide | N | - | See project-domain-fill-spec and field-enum-glossary |
| isPwdCancel | ispwdcancel | N | - | See project-domain-fill-spec and field-enum-glossary |
| unPid | unpid | N | - | See project-domain-fill-spec and field-enum-glossary |
| termInfo | terminfo | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantAcctEditRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| clearMode | clearmode | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctId | acctid | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctName | acctname | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctType | accttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctTp | accttp | N | - | See project-domain-fill-spec and field-enum-glossary |
| bankCode | bankcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| cnapsno | cnapsno | N | - | See project-domain-fill-spec and field-enum-glossary |
| pubAcctInfo | pubacctinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| picUrlJson | picurljson | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantAddRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| merChantId | merchantid | N | - | See project-domain-fill-spec and field-enum-glossary |
| merChantName | merchantname | N | - | See project-domain-fill-spec and field-enum-glossary |
| shortName | shortname | N | - | See project-domain-fill-spec and field-enum-glossary |
| cusEngName | cusengname | N | - | See project-domain-fill-spec and field-enum-glossary |
| cusEngShortName | cusengshortname | N | - | See project-domain-fill-spec and field-enum-glossary |
| servicePhone | servicephone | N | - | See project-domain-fill-spec and field-enum-glossary |
| mccId | mccid | N | - | See project-domain-fill-spec and field-enum-glossary |
| comProperty | comproperty | N | - | See project-domain-fill-spec and field-enum-glossary |
| corpBusName | corpbusname | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditCode | creditcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditCodeExpire | creditcodeexpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| legal | legal | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdType | legalidtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdNo | legalidno | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdExpire | legalidexpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| address | address | N | - | See project-domain-fill-spec and field-enum-glossary |
| contactPerson | contactperson | N | - | See project-domain-fill-spec and field-enum-glossary |
| contactPhone | contactphone | N | - | See project-domain-fill-spec and field-enum-glossary |
| clearMode | clearmode | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctId | acctid | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctName | acctname | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctType | accttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctTp | accttp | N | - | See project-domain-fill-spec and field-enum-glossary |
| bankCode | bankcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| cnapsno | cnapsno | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| corpBusPic | corpbuspic | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdPicFront | legalidpicfront | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdPicBack | legalidpicback | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalPic | legalpic | N | - | See project-domain-fill-spec and field-enum-glossary |
| storePic | storepic | N | - | See project-domain-fill-spec and field-enum-glossary |
| storeInnerPic | storeinnerpic | N | - | See project-domain-fill-spec and field-enum-glossary |
| bizPlacePic | bizplacepic | N | - | See project-domain-fill-spec and field-enum-glossary |
| otherFile | otherfile | N | - | See project-domain-fill-spec and field-enum-glossary |
| expandUser | expanduser | N | - | See project-domain-fill-spec and field-enum-glossary |
| subBranchList | subbranchlist | N | - | See project-domain-fill-spec and field-enum-glossary |
| prodList | prodlist | N | - | See project-domain-fill-spec and field-enum-glossary |
| addFaCusId | addfacusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| settIdNo | settidno | N | - | See project-domain-fill-spec and field-enum-glossary |
| holderName | holdername | N | - | See project-domain-fill-spec and field-enum-glossary |
| holderIdNo | holderidno | N | - | See project-domain-fill-spec and field-enum-glossary |
| holderExpire | holderexpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| registerFund | registerfund | N | - | See project-domain-fill-spec and field-enum-glossary |
| staffTotal | stafftotal | N | - | See project-domain-fill-spec and field-enum-glossary |
| operateLimit | operatelimit | N | - | See project-domain-fill-spec and field-enum-glossary |
| inspect | inspect | N | - | See project-domain-fill-spec and field-enum-glossary |
| thrCertFlag | thrcertflag | N | - | See project-domain-fill-spec and field-enum-glossary |
| organCode | organcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| organExpire | organexpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| busConActPerson | busconactperson | N | - | See project-domain-fill-spec and field-enum-glossary |
| busConActTel | busconacttel | N | - | See project-domain-fill-spec and field-enum-glossary |
| ofFlag | offlag | N | - | See project-domain-fill-spec and field-enum-glossary |
| unSdRemark | unsdremark | N | - | See project-domain-fill-spec and field-enum-glossary |
| agreeType | agreetype | N | - | See project-domain-fill-spec and field-enum-glossary |
| picUrlJson | picurljson | N | - | See project-domain-fill-spec and field-enum-glossary |
| cusUrl | cusurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| webName | webname | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalDetail | legaldetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| bnfDetail | bnfdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| taxDetail | taxdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| busDetail | busdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| businessPlace | businessplace | N | - | See project-domain-fill-spec and field-enum-glossary |
| busAddress | busaddress | N | - | See project-domain-fill-spec and field-enum-glossary |
| districtCode | districtcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqId | reqid | N | - | See project-domain-fill-spec and field-enum-glossary |
| settRemark | settremark | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditCodeType | creditCodeType | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditCodeStartDate | creditCodeStartdate | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdStartDate | legalidStartdate | N | - | See project-domain-fill-spec and field-enum-glossary |
| icpInfo | icpinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| pubAcctInfo | pubacctinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| appScenario | appscenario | N | - | See project-domain-fill-spec and field-enum-glossary |
| quickCash | quickcash | N | - | See project-domain-fill-spec and field-enum-glossary |
| clearTimeRule | cleartimerule | N | - | See project-domain-fill-spec and field-enum-glossary |
| electNotify | electnotify | N | - | See project-domain-fill-spec and field-enum-glossary |
| creDentCheckDate | credentcheckdate | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantAddTermRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| termNo | termno | N | - | See project-domain-fill-spec and field-enum-glossary |
| deviceType | devicetype | N | - | See project-domain-fill-spec and field-enum-glossary |
| termSn | termsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| operaTion | operation | N | - | See project-domain-fill-spec and field-enum-glossary |
| termState | termstate | N | - | See project-domain-fill-spec and field-enum-glossary |
| termAddress | termaddress | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantAgentExpiredRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| fileType | filetype | N | - | See project-domain-fill-spec and field-enum-glossary |
| endDate | enddate | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantBindCodeRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| qrCode | qrcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| branchNo | branchno | N | - | See project-domain-fill-spec and field-enum-glossary |
| latitude | latitude | N | - | See project-domain-fill-spec and field-enum-glossary |
| longitude | longitude | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantConfirmBindRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| qrCode | qrcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| branchNo | branchno | N | - | See project-domain-fill-spec and field-enum-glossary |
| latitude | latitude | N | - | See project-domain-fill-spec and field-enum-glossary |
| longitude | longitude | N | - | See project-domain-fill-spec and field-enum-glossary |
| smsCode | smscode | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantConfirmUnBindRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| qrCode | qrcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| smsCode | smscode | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantEditRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| shortName | shortname | N | - | See project-domain-fill-spec and field-enum-glossary |
| servicePhone | servicephone | N | - | See project-domain-fill-spec and field-enum-glossary |
| corpBusName | corpbusname | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditCode | creditcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditCodeExpire | creditcodeexpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| legal | legal | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdType | legalidtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdNo | legalidno | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdExpire | legalidexpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| address | address | N | - | See project-domain-fill-spec and field-enum-glossary |
| contactPerson | contactperson | N | - | See project-domain-fill-spec and field-enum-glossary |
| contactPhone | contactphone | N | - | See project-domain-fill-spec and field-enum-glossary |
| addFaCusId | addfacusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| zipUrl | zipurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| picsTrUrl | picstrurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| holderName | holdername | N | - | See project-domain-fill-spec and field-enum-glossary |
| holderIdNo | holderidno | N | - | See project-domain-fill-spec and field-enum-glossary |
| holderExpire | holderexpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| registerFund | registerfund | N | - | See project-domain-fill-spec and field-enum-glossary |
| staffTotal | stafftotal | N | - | See project-domain-fill-spec and field-enum-glossary |
| operateLimit | operatelimit | N | - | See project-domain-fill-spec and field-enum-glossary |
| inspect | inspect | N | - | See project-domain-fill-spec and field-enum-glossary |
| thrCertFlag | thrcertflag | N | - | See project-domain-fill-spec and field-enum-glossary |
| organCode | organcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| organExpire | organexpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| busConActPerson | busconactperson | N | - | See project-domain-fill-spec and field-enum-glossary |
| busConActTel | busconacttel | N | - | See project-domain-fill-spec and field-enum-glossary |
| unSdRemark | unsdremark | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalDetail | legaldetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| bnfDetail | bnfdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| taxDetail | taxdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| busDetail | busdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| cusUrl | cusurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| webName | webname | N | - | See project-domain-fill-spec and field-enum-glossary |
| businessPlace | businessplace | N | - | See project-domain-fill-spec and field-enum-glossary |
| busAddress | busaddress | N | - | See project-domain-fill-spec and field-enum-glossary |
| districtCode | districtcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| merChantName | merchantname | N | - | See project-domain-fill-spec and field-enum-glossary |
| tlBankNo | tlbankno | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditCodeType | creditCodeType | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditCodeStartDate | creditCodeStartdate | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdStartDate | legalidStartdate | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantElectSignRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| electSignType | electsigntype | N | - | See project-domain-fill-spec and field-enum-glossary |
| relatedCusId | relatedcusid | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantProdFeeShareQryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## MerChantProductRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqType | reqtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| prodList | prodlist | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantQrCodeQryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| qrCode | qrcode | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantQryTermRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| termNo | termno | N | - | See project-domain-fill-spec and field-enum-glossary |
| queryType | querytype | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantQueryChnlCmIdRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| chnlType | chnltype | N | - | See project-domain-fill-spec and field-enum-glossary |
| settId | settid | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantQueryCusRgcRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## MerChantQueryElectSignRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## MerChantQueryElectUrlRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| redirectUrl | redirecturl | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## MerChantQueryStatusRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| merChantId | merchantid | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqId | reqid | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantQueryWxSubDevRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## MerChantQueryWxVerifyStateRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| chnlType | chnltype | N | - | See project-domain-fill-spec and field-enum-glossary |
| pid | pid | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantRepairComplianceRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| cusShortName | cusshortname | N | - | See project-domain-fill-spec and field-enum-glossary |
| address | address | N | - | See project-domain-fill-spec and field-enum-glossary |
| creDentExpire | credentexpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdExpire | legalidexpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctId | acctid | N | - | See project-domain-fill-spec and field-enum-glossary |
| storePic | storepic | N | - | See project-domain-fill-spec and field-enum-glossary |
| innerPic | innerpic | N | - | See project-domain-fill-spec and field-enum-glossary |
| handPickPic | handpickpic | N | - | See project-domain-fill-spec and field-enum-glossary |
| peasonHeadPic | peasonheadpic | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditPic | creditpic | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdPicFront | legalidpicfront | N | - | See project-domain-fill-spec and field-enum-glossary |
| legalIdPicBack | legalidpicback | N | - | See project-domain-fill-spec and field-enum-glossary |
| rentCtPic | rentctpic | N | - | See project-domain-fill-spec and field-enum-glossary |
| registerPic | registerpic | N | - | See project-domain-fill-spec and field-enum-glossary |
| homePagePic | homepagepic | N | - | See project-domain-fill-spec and field-enum-glossary |
| finalPagePic | finalpagepic | N | - | See project-domain-fill-spec and field-enum-glossary |
| clearParamPic | clearparampic | N | - | See project-domain-fill-spec and field-enum-glossary |
| authorPic | authorpic | N | - | See project-domain-fill-spec and field-enum-glossary |
| certifiedPic | certifiedpic | N | - | See project-domain-fill-spec and field-enum-glossary |
| repairOtherPic | repairotherpic | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantRepairCusrgcRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| jumpUrl | jumpurl | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantSecondPageRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## MerChantSubBranchRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqType | reqtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| subBranchList | subbranchlist | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantTermRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqType | reqtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| termList | termlist | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantUnBindCodeRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| qrCode | qrcode | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantWxSubDevConfigRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| configType | configtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| configVal | configval | N | - | See project-domain-fill-spec and field-enum-glossary |

## MerChantWxVerifyRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| userId | userid | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| pageType | pagetype | N | - | See project-domain-fill-spec and field-enum-glossary |

## PayScorePayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| outOrderNo | out_order_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| serviceId | serviceid | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| scene | scene | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| acct | acct | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| termInfo | terminfo | N | - | See project-domain-fill-spec and field-enum-glossary |

## PayScoreServiceOrderRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| tranCode | trancode | N | - | See project-domain-fill-spec and field-enum-glossary |
| serviceId | serviceid | N | - | See project-domain-fill-spec and field-enum-glossary |
| bizData | bizdata | N | - | See project-domain-fill-spec and field-enum-glossary |

## PayScoreTCPermissionAdd

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| authorizationAode | authorization_code | N | - | See project-domain-fill-spec and field-enum-glossary |
| subAppid | sub_appid | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |

## PayScoreTCPermissionDel

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| authorizationAode | authorization_code | N | - | See project-domain-fill-spec and field-enum-glossary |
| reason | reason | N | - | See project-domain-fill-spec and field-enum-glossary |

## PayScoreTCPermissionGet

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| authorizationAode | authorization_code | N | - | See project-domain-fill-spec and field-enum-glossary |

## PayScoreTCServiceOrderAdd

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| outOrderNo | out_order_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| serviceIntroduction | service_introduction | N | - | See project-domain-fill-spec and field-enum-glossary |
| postPayments | post_payments | N | - | See project-domain-fill-spec and field-enum-glossary |
| postDiscounts | post_discounts | N | - | See project-domain-fill-spec and field-enum-glossary |
| riskFund | risk_fund | N | - | See project-domain-fill-spec and field-enum-glossary |
| timeRange | time_range | N | - | See project-domain-fill-spec and field-enum-glossary |
| location | location | N | - | See project-domain-fill-spec and field-enum-glossary |
| subAppid | sub_appid | N | - | See project-domain-fill-spec and field-enum-glossary |
| subOpenid | sub_openid | N | - | See project-domain-fill-spec and field-enum-glossary |
| needUserConfirm | need_user_confirm | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| attach | attach | N | - | See project-domain-fill-spec and field-enum-glossary |

## PayScoreTCServiceOrderCancel

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| outOrderNo | out_order_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| reason | reason | N | - | See project-domain-fill-spec and field-enum-glossary |

## PayScoreTCServiceOrderComplete

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| outOrderNo | out_order_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| postPayments | post_payments | N | - | See project-domain-fill-spec and field-enum-glossary |
| postDiscounts | post_discounts | N | - | See project-domain-fill-spec and field-enum-glossary |
| totalAmount | total_amount | N | - | See project-domain-fill-spec and field-enum-glossary |
| timeRange | time_range | N | - | See project-domain-fill-spec and field-enum-glossary |
| location | location | N | - | See project-domain-fill-spec and field-enum-glossary |
| completeTime | complete_time | N | - | See project-domain-fill-spec and field-enum-glossary |

## PayScoreTCServiceOrderGet

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| outOrderNo | out_order_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| queryId | query_id | N | - | See project-domain-fill-spec and field-enum-glossary |

## PosolAuthFinRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |

## PosolCancelRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## PosolQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## PreScanPayCancelRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldTrxId | oldtrxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## PreScanPayFinishRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| autoBack | autoback | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldTrxId | oldtrxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| asInfo | asinfo | N | - | See project-domain-fill-spec and field-enum-glossary |

## PreScanPayQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## PreScanPayRefundRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldTrxId | oldtrxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## PreScanPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| payType | paytype | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| expireTime | expiretime | N | - | See project-domain-fill-spec and field-enum-glossary |
| authCode | authcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| acct | acct | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| limitPay | limit_pay | N | - | See project-domain-fill-spec and field-enum-glossary |
| subAppid | sub_appid | N | - | See project-domain-fill-spec and field-enum-glossary |
| subBranch | subbranch | N | - | See project-domain-fill-spec and field-enum-glossary |
| termInfo | terminfo | N | - | See project-domain-fill-spec and field-enum-glossary |

## QPayAgreeApplyRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqIp | reqip | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| merUserId | meruserid | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctType | accttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctNo | acctno | N | - | See project-domain-fill-spec and field-enum-glossary |
| idType | idtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctName | acctname | N | - | See project-domain-fill-spec and field-enum-glossary |
| mobile | mobile | N | - | See project-domain-fill-spec and field-enum-glossary |
| validDate | validdate | N | - | See project-domain-fill-spec and field-enum-glossary |
| cvv2 | cvv2 | N | - | See project-domain-fill-spec and field-enum-glossary |

## QPayAgreeConfirmRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqIp | reqip | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| merUserId | meruserid | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctType | accttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctNo | acctno | N | - | See project-domain-fill-spec and field-enum-glossary |
| idType | idtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctName | acctname | N | - | See project-domain-fill-spec and field-enum-glossary |
| mobile | mobile | N | - | See project-domain-fill-spec and field-enum-glossary |
| validDate | validdate | N | - | See project-domain-fill-spec and field-enum-glossary |
| cvv2 | cvv2 | N | - | See project-domain-fill-spec and field-enum-glossary |
| smsCode | smscode | N | - | See project-domain-fill-spec and field-enum-glossary |
| thpInfo | thpinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| userAgreeNo | useragreeno | N | - | See project-domain-fill-spec and field-enum-glossary |

## QPayApplyRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| agreeId | agreeid | N | - | See project-domain-fill-spec and field-enum-glossary |
| amount | amount | N | - | See project-domain-fill-spec and field-enum-glossary |
| currency | currency | N | - | See project-domain-fill-spec and field-enum-glossary |
| subject | subject | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxReserve | trxreserve | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| asInfo | asinfo | N | - | See project-domain-fill-spec and field-enum-glossary |

## QPayConfirmRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqIp | reqip | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| agreeId | agreeid | N | - | See project-domain-fill-spec and field-enum-glossary |
| smsCode | smscode | N | - | See project-domain-fill-spec and field-enum-glossary |
| thpInfo | thpinfo | N | - | See project-domain-fill-spec and field-enum-glossary |

## QPayolAgreeApplyRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqIp | reqip | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |
| bankCode | bankcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptType | encrypttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctType | accttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| idType | idtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| acctName | acctname | Y | - | See project-domain-fill-spec and field-enum-glossary |
| mobile | mobile | Y | - | See project-domain-fill-spec and field-enum-glossary |
| acctNo | acctno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| retUrl | returl | N | - | See project-domain-fill-spec and field-enum-glossary |

## QPayolBindCardApplyRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqIp | reqip | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |
| merUserId | meruserid | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptType | encrypttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| retUrl | returl | N | - | See project-domain-fill-spec and field-enum-glossary |

## QPaySmsAgreeRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqIp | reqip | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderId | orderid | N | - | See project-domain-fill-spec and field-enum-glossary |
| agreeId | agreeid | N | - | See project-domain-fill-spec and field-enum-glossary |
| thpInfo | thpinfo | N | - | See project-domain-fill-spec and field-enum-glossary |

## QPayUnbindRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqIp | reqip | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqTime | reqtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| agreeId | agreeid | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackAliComplaintFileUploadRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| file_content | - | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackAliComplaintProcessFinishRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| timeStamp | timestamp | N | - | See project-domain-fill-spec and field-enum-glossary |
| idList | id_list | N | - | See project-domain-fill-spec and field-enum-glossary |
| processCode | process_code | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| imgFileList | img_file_list | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackAliComplaintQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| timeStamp | timestamp | N | - | See project-domain-fill-spec and field-enum-glossary |
| complainId | complain_id | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackAliComplaintQueryV2Request

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| timeStamp | timestamp | N | - | See project-domain-fill-spec and field-enum-glossary |
| currentPageNum | current_page_num | N | - | See project-domain-fill-spec and field-enum-glossary |
| pageSize | page_size | N | - | See project-domain-fill-spec and field-enum-glossary |
| gmtComplaintStart | gmt_complaint_start | N | - | See project-domain-fill-spec and field-enum-glossary |
| gmtComplaintEnd | gmt_complaint_end | N | - | See project-domain-fill-spec and field-enum-glossary |
| tradeNo | trade_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| taskId | task_id | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxAppletBussiAppealRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| timeStamp | timestamp | N | - | See project-domain-fill-spec and field-enum-glossary |
| complaintOrderId | complaintorderid | N | - | See project-domain-fill-spec and field-enum-glossary |
| content | content | N | - | See project-domain-fill-spec and field-enum-glossary |
| mediaIdList | mediaIdlist | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxAppletBussiRespondComplaintRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| timeStamp | timestamp | N | - | See project-domain-fill-spec and field-enum-glossary |
| complaintOrderId | complaintorderid | N | - | See project-domain-fill-spec and field-enum-glossary |
| content | content | N | - | See project-domain-fill-spec and field-enum-glossary |
| mediaIdList | mediaIdlist | N | - | See project-domain-fill-spec and field-enum-glossary |
| bussiHandle | bussihandle | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxAppletBussiSupplyProofRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| timeStamp | timestamp | N | - | See project-domain-fill-spec and field-enum-glossary |
| complaintOrderId | complaintorderid | N | - | See project-domain-fill-spec and field-enum-glossary |
| content | content | N | - | See project-domain-fill-spec and field-enum-glossary |
| mediaIdList | mediaIdlist | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxAppletBussiSupplyRefundRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| timeStamp | timestamp | N | - | See project-domain-fill-spec and field-enum-glossary |
| complaintOrderId | complaintorderid | N | - | See project-domain-fill-spec and field-enum-glossary |
| content | content | N | - | See project-domain-fill-spec and field-enum-glossary |
| mediaIdList | mediaIdlist | N | - | See project-domain-fill-spec and field-enum-glossary |
| acceptReturn | acceptreturn | N | - | See project-domain-fill-spec and field-enum-glossary |
| returnId | returnid | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxAppletComplaintOrderDetailRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| timeStamp | timestamp | N | - | See project-domain-fill-spec and field-enum-glossary |
| complaintOrderId | complaintorderid | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxAppletComplaintQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| timeStamp | timestamp | N | - | See project-domain-fill-spec and field-enum-glossary |
| currentPageNum | current_page_num | N | - | See project-domain-fill-spec and field-enum-glossary |
| pageSize | page_size | N | - | See project-domain-fill-spec and field-enum-glossary |
| gmtComplaintStart | gmt_complaint_start | N | - | See project-domain-fill-spec and field-enum-glossary |
| gmtComplaintEnd | gmt_complaint_end | N | - | See project-domain-fill-spec and field-enum-glossary |
| tradeNo | trade_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| taskId | task_id | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxAppletUploadRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| timeStamp | timestamp | N | - | See project-domain-fill-spec and field-enum-glossary |
| type | type | N | - | See project-domain-fill-spec and field-enum-glossary |
| file | - | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxComplaintCompleteRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| complaintId | complaint_id | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxComplaintDetailRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| complaintId | complaint_id | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxComplaintHistoryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| complaintId | complaint_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| limit | limit | N | - | See project-domain-fill-spec and field-enum-glossary |
| offset | offset | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxComplaintListQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| currentPageNum | current_page_num | N | - | See project-domain-fill-spec and field-enum-glossary |
| pageSize | page_size | N | - | See project-domain-fill-spec and field-enum-glossary |
| beginDate | begindate | N | - | See project-domain-fill-spec and field-enum-glossary |
| endDate | enddate | N | - | See project-domain-fill-spec and field-enum-glossary |
| updateBegin | updatebegin | N | - | See project-domain-fill-spec and field-enum-glossary |
| updateEnd | updateend | N | - | See project-domain-fill-spec and field-enum-glossary |
| groupAll | groupall | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxComplaintRespRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| complaintId | complaint_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| responseContent | response_content | N | - | See project-domain-fill-spec and field-enum-glossary |
| responseImages | response_images | N | - | See project-domain-fill-spec and field-enum-glossary |
| jumpUrl | jump_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| jumpUrlText | jump_url_text | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxComplaintSreFundProgressRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| complaintId | complaint_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| action | action | N | - | See project-domain-fill-spec and field-enum-glossary |
| launchRefundDay | launch_refund_day | N | - | See project-domain-fill-spec and field-enum-glossary |
| rejectReason | reject_reason | N | - | See project-domain-fill-spec and field-enum-glossary |
| rejectMediaList | reject_media_list | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxGetMerchantImageRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| imgUrl | imgurl | N | - | See project-domain-fill-spec and field-enum-glossary |

## RiskFeeBackWxMerchantImageUploadRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| file | - | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceAlinFcConfigRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| termSn | termsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| branchNo | branchno | N | - | See project-domain-fill-spec and field-enum-glossary |
| openFlag | openflag | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceAlinFcQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| termSn | termsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| branchNo | branchno | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceAsAgreeConfigQryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceAsAgreeConfigRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| shareType | sharetype | N | - | See project-domain-fill-spec and field-enum-glossary |
| amtMax | amtmax | N | - | See project-domain-fill-spec and field-enum-glossary |
| rateMax | ratemax | N | - | See project-domain-fill-spec and field-enum-glossary |
| limitType | limittype | N | - | See project-domain-fill-spec and field-enum-glossary |
| asAgreeUrl | asagreeurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| reason | reason | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceIotDevConfigRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| branchNo | branchno | N | - | See project-domain-fill-spec and field-enum-glossary |
| deviceName | devicename | N | - | See project-domain-fill-spec and field-enum-glossary |
| pidList | pidlist | N | - | See project-domain-fill-spec and field-enum-glossary |
| openFlag | openflag | N | - | See project-domain-fill-spec and field-enum-glossary |
| deviceType | devicetype | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceIotDevQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| branchNo | branchno | N | - | See project-domain-fill-spec and field-enum-glossary |
| deviceName | devicename | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceQueryCouponDetailRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| couponId | couponid | N | - | See project-domain-fill-spec and field-enum-glossary |
| wxOpenId | wxopenid | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceQueryStockDetailRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| stockId | stockid | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceQueryStockRefundFlowRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| stockId | stockid | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceQueryStockUseFlowRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| stockId | stockid | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceSearchCusPackageRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| startTime | starttime | N | - | See project-domain-fill-spec and field-enum-glossary |
| endTime | endtime | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceSendCouponsRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| stockId | stockid | N | - | See project-domain-fill-spec and field-enum-glossary |
| openId | openid | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchAppId | mchappid | N | - | See project-domain-fill-spec and field-enum-glossary |
| couponValue | couponvalue | N | - | See project-domain-fill-spec and field-enum-glossary |
| couponMinimum | couponminimum | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceUploadElectTicketRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlTrxId | chnltrxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| cmId | cmid | N | - | See project-domain-fill-spec and field-enum-glossary |
| openId | openid | N | - | See project-domain-fill-spec and field-enum-glossary |
| merChantContacts | merchantcontacts | N | - | See project-domain-fill-spec and field-enum-glossary |
| file | - | N | - | See project-domain-fill-spec and field-enum-glossary |

## SybServiceWxCateringOrderSyncStatusRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| subAppId | sub_appid | N | - | See project-domain-fill-spec and field-enum-glossary |
| outShopNo | outshopno | N | - | See project-domain-fill-spec and field-enum-glossary |
| subOpenId | subopenid | N | - | See project-domain-fill-spec and field-enum-glossary |
| loginToken | logintoken | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderEntry | orderentry | N | - | See project-domain-fill-spec and field-enum-glossary |
| totalAmount | totalamount | N | - | See project-domain-fill-spec and field-enum-glossary |
| discountAmount | discountamount | N | - | See project-domain-fill-spec and field-enum-glossary |
| userAmount | useramount | N | - | See project-domain-fill-spec and field-enum-glossary |
| status | status | N | - | See project-domain-fill-spec and field-enum-glossary |
| actionTime | actiontime | N | - | See project-domain-fill-spec and field-enum-glossary |
| payTime | paytime | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlTrxId | chnltrxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| dishList | dishlist | N | - | See project-domain-fill-spec and field-enum-glossary |
| outTableNo | outtableno | N | - | See project-domain-fill-spec and field-enum-glossary |
| peopleCount | peoplecount | N | - | See project-domain-fill-spec and field-enum-glossary |

## TlinvoiceCancleInvoiceRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |

## TlinvoiceGenerateInviteQRRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## TlinvoiceGenerateInvoiceQRRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| amt | amt | N | - | See project-domain-fill-spec and field-enum-glossary |
| faPiaoBillType | fapiaobilltype | N | - | See project-domain-fill-spec and field-enum-glossary |
| prodCode | prodcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| goodsName | goodsname | N | - | See project-domain-fill-spec and field-enum-glossary |
| quantity | quantity | N | - | See project-domain-fill-spec and field-enum-glossary |
| policyCode | policycode | N | - | See project-domain-fill-spec and field-enum-glossary |
| unit | unit | N | - | See project-domain-fill-spec and field-enum-glossary |
| specification | specification | N | - | See project-domain-fill-spec and field-enum-glossary |
| rate | rate | N | - | See project-domain-fill-spec and field-enum-glossary |
| termNo | termno | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |

## TlinvoiceGenerateInvoiceQRSimpleRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| amt | amt | N | - | See project-domain-fill-spec and field-enum-glossary |
| prodCode | prodcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| termNo | termno | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |

## TlinvoiceGetInvoiceDownloadUrlRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |

## TlinvoiceGetInvoiceOpenStatusRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## TlinvoiceGetInvoiceProdCodeListRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|

## TlinvoiceGetRecordStatusRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |

## TranxCancelRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldReqSn | oldreqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldTrxId | oldtrxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## TranxCloseRequset

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| oldReqSn | oldreqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldTrxId | oldtrxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| isIot | isiot | N | - | See project-domain-fill-spec and field-enum-glossary |

## TranxQueryConfirmRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## TranxQueryOrderRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxDate | trxdate | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderId | orderid | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| termNo | termno | N | - | See project-domain-fill-spec and field-enum-glossary |
| resendNotify | resendnotify | N | - | See project-domain-fill-spec and field-enum-glossary |

## TranxQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxId | trxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## TranxRefundRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldReqSn | oldreqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldTrxId | oldtrxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| benefitDetail | benefitdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |

## TrxFileGetRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| date | date | N | - | See project-domain-fill-spec and field-enum-glossary |
| fileType | filetype | N | - | See project-domain-fill-spec and field-enum-glossary |

## TrxFileSettTrxRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| settDate | settdate | N | - | See project-domain-fill-spec and field-enum-glossary |

## TrxShareQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| payerTrxId | payertrxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## TrxShareRevokeQueryRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| rkTrxId | rktrxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## TrxShareRevokeRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| payerTrxId | payertrxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payerReqSn | payerreqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |

## TrxShareShareRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldTrxId | oldtrxid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payeeCusId | payeecusid | N | - | See project-domain-fill-spec and field-enum-glossary |
| payeeReqSn | payeereqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnConscsPayAgreeApplyRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| merUserId | meruserid | N | - | See project-domain-fill-spec and field-enum-glossary |
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |
| appType | apptype | N | - | See project-domain-fill-spec and field-enum-glossary |
| appName | appname | N | - | See project-domain-fill-spec and field-enum-glossary |
| appPath | apppath | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| planId | planid | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnConscsPayAgreePayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| subject | subject | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| planId | planid | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnConscsPayAgreeUnbindRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnConscsPayAndSignRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| subject | subject | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| appType | apptype | N | - | See project-domain-fill-spec and field-enum-glossary |
| appName | appname | N | - | See project-domain-fill-spec and field-enum-glossary |
| appPath | apppath | N | - | See project-domain-fill-spec and field-enum-glossary |
| merUserId | meruserid | N | - | See project-domain-fill-spec and field-enum-glossary |
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| agreeNotifyUrl | agree_notifyurl | N | - | See project-domain-fill-spec and field-enum-glossary |
| planId | planid | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnConscsPayTokenApplyRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| merUserId | meruserid | N | - | See project-domain-fill-spec and field-enum-glossary |
| merUserRegitDate | meruserregitdate | N | - | See project-domain-fill-spec and field-enum-glossary |
| merUserLoginMet | meruserloginmet | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptType | encrypttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctNo | acctno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| idType | idtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctName | acctname | Y | - | See project-domain-fill-spec and field-enum-glossary |
| mobile | mobile | Y | - | See project-domain-fill-spec and field-enum-glossary |
| bankCode | bankcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| acctType | accttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlTrId | chnltrid | N | - | See project-domain-fill-spec and field-enum-glossary |
| tokenType | tokentype | N | - | See project-domain-fill-spec and field-enum-glossary |
| deviceId | deviceid | N | - | See project-domain-fill-spec and field-enum-glossary |
| faceType | facetype | N | - | See project-domain-fill-spec and field-enum-glossary |
| faceOrder | faceorder | N | - | See project-domain-fill-spec and field-enum-glossary |
| faceApp | faceapp | N | - | See project-domain-fill-spec and field-enum-glossary |
| invokeType | invoketype | N | - | See project-domain-fill-spec and field-enum-glossary |
| wxAppId | wxappid | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| retUrl | returl | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnConscsPayTokenPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| subject | subject | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlTrId | chnltrid | N | - | See project-domain-fill-spec and field-enum-glossary |
| smsCode | smscode | N | - | See project-domain-fill-spec and field-enum-glossary |
| thpInfo | thpinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnConscsPayTokenSetNoverRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlTrId | chnltrid | N | - | See project-domain-fill-spec and field-enum-glossary |
| openType | opentype | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnConscsPayTokenSmsRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| agreeId | agreeid | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlTrId | chnltrid | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| subject | subject | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnConscsPayTokenUnbindRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| applyId | applyid | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlTrId | chnltrid | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXAuditQryUn

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| orgNo | orgNo | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntOrderId | mchntOrderId | N | - | See project-domain-fill-spec and field-enum-glossary |
| uploadTime | uploadTime | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXAuditUn

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| orgNo | orgNo | N | - | See project-domain-fill-spec and field-enum-glossary |
| subMchntCd | subMchntCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| subMchntNm | subMchntNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| storeNm | storeNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| onlineNo | onlineNo | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntOrderId | mchntOrderId | N | - | See project-domain-fill-spec and field-enum-glossary |
| uploadTime | uploadTime | N | - | See project-domain-fill-spec and field-enum-glossary |
| prodId | prodId | N | - | See project-domain-fill-spec and field-enum-glossary |
| engGrade | engGrade | N | - | See project-domain-fill-spec and field-enum-glossary |
| brandNm | brandNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| prodModel | prodModel | N | - | See project-domain-fill-spec and field-enum-glossary |
| salesChnl | salesChnl | N | - | See project-domain-fill-spec and field-enum-glossary |
| platForm | platForm | N | - | See project-domain-fill-spec and field-enum-glossary |
| payerTp | payerTp | N | - | See project-domain-fill-spec and field-enum-glossary |
| tradeInOrderId | tradeInOrderId | N | - | See project-domain-fill-spec and field-enum-glossary |
| tradeInAt | tradeInAt | N | - | See project-domain-fill-spec and field-enum-glossary |
| isTradeIn | isTradeIn | N | - | See project-domain-fill-spec and field-enum-glossary |
| salesAt | salesAt | N | - | See project-domain-fill-spec and field-enum-glossary |
| actualAt | actualAt | N | - | See project-domain-fill-spec and field-enum-glossary |
| transTm | transTm | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntCd | mchntCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| merSubAt | merSubAt | N | - | See project-domain-fill-spec and field-enum-glossary |
| discountAt | discountAt | N | - | See project-domain-fill-spec and field-enum-glossary |
| image01 | image01 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image02 | image02 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image03 | image03 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image04 | image04 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image05 | image05 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image06 | image06 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image07 | image07 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image08 | image08 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image09 | image09 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image10 | image10 | N | - | See project-domain-fill-spec and field-enum-glossary |
| commitmentLetterPhoto | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| commitmentLetterPhotoFormat | commitmentLetterPhotoFormat | N | - | See project-domain-fill-spec and field-enum-glossary |
| devicePhoto | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| devicePhotoFormat | devicePhotoFormat | N | - | See project-domain-fill-spec and field-enum-glossary |
| packAndActivePhoto | packAndActivePhoto | N | - | See project-domain-fill-spec and field-enum-glossary |
| barCode | barCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| snCode | snCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| imei1 | imei1 | N | - | See project-domain-fill-spec and field-enum-glossary |
| imei2 | imei2 | N | - | See project-domain-fill-spec and field-enum-glossary |
| registerModel | registerModel | N | - | See project-domain-fill-spec and field-enum-glossary |
| recordNumber | recordNumber | N | - | See project-domain-fill-spec and field-enum-glossary |
| engGradeStandard | engGradeStandard | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptData | encryptData | N | - | See project-domain-fill-spec and field-enum-glossary |
| resv1 | resv1 | N | - | See project-domain-fill-spec and field-enum-glossary |
| resv2 | resv2 | N | - | See project-domain-fill-spec and field-enum-glossary |
| resv3 | resv3 | N | - | See project-domain-fill-spec and field-enum-glossary |
| resv4 | resv4 | N | - | See project-domain-fill-spec and field-enum-glossary |
| resv5 | resv5 | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXAuditUpdateUn

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| orgNo | orgNo | N | - | See project-domain-fill-spec and field-enum-glossary |
| subMchntCd | subMchntCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| subMchntNm | subMchntNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| storeNm | storeNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| onlineNo | onlineNo | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntOrderId | mchntOrderId | N | - | See project-domain-fill-spec and field-enum-glossary |
| uploadTime | uploadTime | N | - | See project-domain-fill-spec and field-enum-glossary |
| prodId | prodId | N | - | See project-domain-fill-spec and field-enum-glossary |
| engGrade | engGrade | N | - | See project-domain-fill-spec and field-enum-glossary |
| brandNm | brandNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| prodModel | prodModel | N | - | See project-domain-fill-spec and field-enum-glossary |
| salesChnl | salesChnl | N | - | See project-domain-fill-spec and field-enum-glossary |
| platForm | platForm | N | - | See project-domain-fill-spec and field-enum-glossary |
| payerTp | payerTp | N | - | See project-domain-fill-spec and field-enum-glossary |
| tradeInOrderId | tradeInOrderId | N | - | See project-domain-fill-spec and field-enum-glossary |
| tradeInAt | tradeInAt | N | - | See project-domain-fill-spec and field-enum-glossary |
| isTradeIn | isTradeIn | N | - | See project-domain-fill-spec and field-enum-glossary |
| salesAt | salesAt | N | - | See project-domain-fill-spec and field-enum-glossary |
| actualAt | actualAt | N | - | See project-domain-fill-spec and field-enum-glossary |
| transTm | transTm | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntCd | mchntCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| merSubAt | merSubAt | N | - | See project-domain-fill-spec and field-enum-glossary |
| discountAt | discountAt | N | - | See project-domain-fill-spec and field-enum-glossary |
| image01 | image01 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image02 | image02 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image03 | image03 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image04 | image04 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image05 | image05 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image06 | image06 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image07 | image07 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image08 | image08 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image09 | image09 | N | - | See project-domain-fill-spec and field-enum-glossary |
| image10 | image10 | N | - | See project-domain-fill-spec and field-enum-glossary |
| commitmentLetterPhoto | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| commitmentLetterPhotoFormat | commitmentLetterPhotoFormat | N | - | See project-domain-fill-spec and field-enum-glossary |
| devicePhoto | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| devicePhotoFormat | devicePhotoFormat | N | - | See project-domain-fill-spec and field-enum-glossary |
| packAndActivePhoto | packAndActivePhoto | N | - | See project-domain-fill-spec and field-enum-glossary |
| barCode | barCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| snCode | snCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| imei1 | imei1 | N | - | See project-domain-fill-spec and field-enum-glossary |
| imei2 | imei2 | N | - | See project-domain-fill-spec and field-enum-glossary |
| registerModel | registerModel | N | - | See project-domain-fill-spec and field-enum-glossary |
| recordNumber | recordNumber | N | - | See project-domain-fill-spec and field-enum-glossary |
| engGradeStandard | engGradeStandard | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptData | encryptData | N | - | See project-domain-fill-spec and field-enum-glossary |
| resv1 | resv1 | N | - | See project-domain-fill-spec and field-enum-glossary |
| resv2 | resv2 | N | - | See project-domain-fill-spec and field-enum-glossary |
| resv3 | resv3 | N | - | See project-domain-fill-spec and field-enum-glossary |
| resv4 | resv4 | N | - | See project-domain-fill-spec and field-enum-glossary |
| resv5 | resv5 | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXClearanceUn

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| txnTime | txnTime | N | - | See project-domain-fill-spec and field-enum-glossary |
| coupIssueId | coupIssueId | N | - | See project-domain-fill-spec and field-enum-glossary |
| regionCd | regionCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptData | encryptData | N | - | See project-domain-fill-spec and field-enum-glossary |
| cateCode | cateCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| txnAmt | txnAmt | N | - | See project-domain-fill-spec and field-enum-glossary |
| discountAmt | discountAmt | N | - | See project-domain-fill-spec and field-enum-glossary |
| transTm | transTm | N | - | See project-domain-fill-spec and field-enum-glossary |
| couponCd | couponCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| actId | actId | N | - | See project-domain-fill-spec and field-enum-glossary |
| operTp | operTp | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntCd | mchntCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntCnNm | mchntCnNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntResv | mchntResv | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqReserved | reqReserved | N | - | See project-domain-fill-spec and field-enum-glossary |
| recvRegionCd | recvRegionCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| saleModels | saleModels | N | - | See project-domain-fill-spec and field-enum-glossary |
| corpCnNm | corpCnNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| uniscId | uniscId | N | - | See project-domain-fill-spec and field-enum-glossary |
| pickUp | pickUp | N | - | See project-domain-fill-spec and field-enum-glossary |
| barCode | barCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| itemName | itemName | N | - | See project-domain-fill-spec and field-enum-glossary |
| brandNm | brandNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| specModel | specModel | N | - | See project-domain-fill-spec and field-enum-glossary |
| engGrade | engGrade | N | - | See project-domain-fill-spec and field-enum-glossary |
| snCode | snCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| imei1 | imei1 | N | - | See project-domain-fill-spec and field-enum-glossary |
| imei2 | imei2 | N | - | See project-domain-fill-spec and field-enum-glossary |
| logisticsNo | logisticsNo | N | - | See project-domain-fill-spec and field-enum-glossary |
| deliveryTime | deliveryTime | N | - | See project-domain-fill-spec and field-enum-glossary |
| invoiceNo | invoiceNo | N | - | See project-domain-fill-spec and field-enum-glossary |
| isAIProduct | isAIProduct | N | - | See project-domain-fill-spec and field-enum-glossary |
| serialNum | serialNum | N | - | See project-domain-fill-spec and field-enum-glossary |
| pcType | pcType | N | - | See project-domain-fill-spec and field-enum-glossary |
| channel | channel | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntOrderId | mchntOrderId | N | - | See project-domain-fill-spec and field-enum-glossary |
| acqInsNm | acqInsNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| payOrderId | payOrderId | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldThings | oldThings | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXCmnRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| actionType | actionType | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxChnl | trxChnl | N | - | See project-domain-fill-spec and field-enum-glossary |
| bizContent | bizContent | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXCoupCancel

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| txnTime | txnTime | N | - | See project-domain-fill-spec and field-enum-glossary |
| coupIssueId | coupIssueId | N | - | See project-domain-fill-spec and field-enum-glossary |
| regionCd | regionCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptData | encryptData | N | - | See project-domain-fill-spec and field-enum-glossary |
| scene | scene | N | - | See project-domain-fill-spec and field-enum-glossary |
| cateCode | cateCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| gps | gps | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqReserved | reqReserved | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXCoupCheck

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| txnTime | txnTime | N | - | See project-domain-fill-spec and field-enum-glossary |
| coupIssueId | coupIssueId | N | - | See project-domain-fill-spec and field-enum-glossary |
| regionCd | regionCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptData | encryptData | N | - | See project-domain-fill-spec and field-enum-glossary |
| scene | scene | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqReserved | reqReserved | N | - | See project-domain-fill-spec and field-enum-glossary |
| isRealName | isRealName | N | - | See project-domain-fill-spec and field-enum-glossary |
| isRealFace | isRealFace | N | - | See project-domain-fill-spec and field-enum-glossary |
| isExpire | isExpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| isCancel | isCancel | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXCoupReceive

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| txnTime | txnTime | N | - | See project-domain-fill-spec and field-enum-glossary |
| coupIssueId | coupIssueId | N | - | See project-domain-fill-spec and field-enum-glossary |
| regionCd | regionCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptData | encryptData | N | - | See project-domain-fill-spec and field-enum-glossary |
| scene | scene | N | - | See project-domain-fill-spec and field-enum-glossary |
| cateCode | cateCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| model | model | N | - | See project-domain-fill-spec and field-enum-glossary |
| engGrade | engGrade | N | - | See project-domain-fill-spec and field-enum-glossary |
| isRealName | isRealName | N | - | See project-domain-fill-spec and field-enum-glossary |
| isRealFace | isRealFace | N | - | See project-domain-fill-spec and field-enum-glossary |
| isExpire | isExpire | N | - | See project-domain-fill-spec and field-enum-glossary |
| isCancel | isCancel | N | - | See project-domain-fill-spec and field-enum-glossary |
| gps | gps | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqReserved | reqReserved | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXCoupRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| actionType | actionType | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxChnl | trxChnl | N | - | See project-domain-fill-spec and field-enum-glossary |
| bizContent | bizContent | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXSnOccupancyUn

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| txnTime | txnTime | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderId | orderId | N | - | See project-domain-fill-spec and field-enum-glossary |
| regionCd | regionCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntCd | mchntCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| postTmn | postTmn | N | - | See project-domain-fill-spec and field-enum-glossary |
| barcode | barcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| snCode | snCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqReserved | reqReserved | N | - | See project-domain-fill-spec and field-enum-glossary |
| imei1 | imei1 | N | - | See project-domain-fill-spec and field-enum-glossary |
| imei2 | imei2 | N | - | See project-domain-fill-spec and field-enum-glossary |
| mfrInfo | mfrInfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| brand | brand | N | - | See project-domain-fill-spec and field-enum-glossary |
| cateCode | cateCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| isAiProd | isAiProd | N | - | See project-domain-fill-spec and field-enum-glossary |
| specModel | specModel | N | - | See project-domain-fill-spec and field-enum-glossary |
| saleTm | saleTm | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXSnQueryUn

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| regionCd | regionCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| snCode | snCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqReserved | reqReserved | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXTransSyncUn

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| txnTime | txnTime | N | - | See project-domain-fill-spec and field-enum-glossary |
| coupIssueId | coupIssueId | N | - | See project-domain-fill-spec and field-enum-glossary |
| regionCd | regionCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| encryptData | encryptData | N | - | See project-domain-fill-spec and field-enum-glossary |
| cateCode | cateCode | N | - | See project-domain-fill-spec and field-enum-glossary |
| txnAmt | txnAmt | N | - | See project-domain-fill-spec and field-enum-glossary |
| discountAmt | discountAmt | N | - | See project-domain-fill-spec and field-enum-glossary |
| transTm | transTm | N | - | See project-domain-fill-spec and field-enum-glossary |
| couponCd | couponCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| actId | actId | N | - | See project-domain-fill-spec and field-enum-glossary |
| operTp | operTp | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntCd | mchntCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntCnNm | mchntCnNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| mchntResv | mchntResv | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqReserved | reqReserved | N | - | See project-domain-fill-spec and field-enum-glossary |
| recvRegionCd | recvRegionCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| saleModels | saleModels | N | - | See project-domain-fill-spec and field-enum-glossary |
| corpCnNm | corpCnNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| uniscId | uniscId | N | - | See project-domain-fill-spec and field-enum-glossary |
| brandNm | brandNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| engGrade | engGrade | N | - | See project-domain-fill-spec and field-enum-glossary |
| serialNum | serialNum | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXVoAuditEncryptData

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| invoiceInfo | invoiceInfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| trackInfo | trackInfo | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXVoBiz

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXVoInvoiceInfo

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| id | id | N | - | See project-domain-fill-spec and field-enum-glossary |
| invoiceTp | invoiceTp | N | - | See project-domain-fill-spec and field-enum-glossary |
| invoiceCd | invoiceCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| invoiceNo | invoiceNo | N | - | See project-domain-fill-spec and field-enum-glossary |
| invoiceDt | invoiceDt | N | - | See project-domain-fill-spec and field-enum-glossary |
| invoiceLink | invoiceLink | N | - | See project-domain-fill-spec and field-enum-glossary |
| invoiceCkCd | invoiceCkCd | N | - | See project-domain-fill-spec and field-enum-glossary |
| nm | nm | N | - | See project-domain-fill-spec and field-enum-glossary |
| tax | tax | N | - | See project-domain-fill-spec and field-enum-glossary |
| invoiceTaxAmt | invoiceTaxAmt | N | - | See project-domain-fill-spec and field-enum-glossary |
| salesEntNm | salesEntNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| taxPayer | taxPayer | N | - | See project-domain-fill-spec and field-enum-glossary |
| num | num | N | - | See project-domain-fill-spec and field-enum-glossary |
| serviceNm | serviceNm | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXVoTrackInfo

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| trackingNo | trackingNo | N | - | See project-domain-fill-spec and field-enum-glossary |
| trackingCompany | trackingCompany | N | - | See project-domain-fill-spec and field-enum-glossary |
| usrProv | usrProv | N | - | See project-domain-fill-spec and field-enum-glossary |
| usrCity | usrCity | N | - | See project-domain-fill-spec and field-enum-glossary |
| usrArea | usrArea | N | - | See project-domain-fill-spec and field-enum-glossary |
| usrAddr | usrAddr | N | - | See project-domain-fill-spec and field-enum-glossary |
| trackingType | trackingType | N | - | See project-domain-fill-spec and field-enum-glossary |
| deliveryMethod | deliveryMethod | N | - | See project-domain-fill-spec and field-enum-glossary |
| shippingAddr | shippingAddr | N | - | See project-domain-fill-spec and field-enum-glossary |
| deliveryTime | deliveryTime | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnionPayYJHXVoUserEncryptData

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| certifTp | certifTp | N | - | See project-domain-fill-spec and field-enum-glossary |
| certifId | certifId | N | - | See project-domain-fill-spec and field-enum-glossary |
| customerNm | customerNm | N | - | See project-domain-fill-spec and field-enum-glossary |
| usrId | usrId | N | - | See project-domain-fill-spec and field-enum-glossary |
| phoneNo | phoneNo | N | - | See project-domain-fill-spec and field-enum-glossary |
| addr | addr | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnitOrderAuthCode2UserIdRequset

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| authCode | authcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| authType | authtype | N | - | See project-domain-fill-spec and field-enum-glossary |
| identify | identify | N | - | See project-domain-fill-spec and field-enum-glossary |
| subAppid | sub_appid | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnitOrderCloseNativeRequset

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| oldReqSn | oldreqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| oldTrxId | oldtrxid | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnitOrderCreateZhiRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| bizLink | bizlink | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| title | title | N | - | See project-domain-fill-spec and field-enum-glossary |
| zhiType | zhitype | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnitOrderNativePayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| expireTime | expiretime | N | - | See project-domain-fill-spec and field-enum-glossary |
| subBranch | subbranch | N | - | See project-domain-fill-spec and field-enum-glossary |
| limitPay | limit_pay | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | N | - | See project-domain-fill-spec and field-enum-glossary |
| trueName | truename | N | - | See project-domain-fill-spec and field-enum-glossary |
| asInfo | asinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| goodsTag | goods_tag | N | - | See project-domain-fill-spec and field-enum-glossary |
| benefitDetail | benefitdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlStoreId | chnlstoreid | N | - | See project-domain-fill-spec and field-enum-glossary |
| fqNum | fqnum | N | - | See project-domain-fill-spec and field-enum-glossary |
| extendParams | extendparams | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| frontUrl | front_url | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnitOrderPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| uniReqSn | unireqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| payType | paytype | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |
| expireTime | expiretime | N | - | See project-domain-fill-spec and field-enum-glossary |
| acct | acct | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| limitPay | limit_pay | N | - | See project-domain-fill-spec and field-enum-glossary |
| subAppid | sub_appid | N | - | See project-domain-fill-spec and field-enum-glossary |
| goodsTag | goods_tag | N | - | See project-domain-fill-spec and field-enum-glossary |
| benefitDetail | benefitdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlStoreId | chnlstoreid | N | - | See project-domain-fill-spec and field-enum-glossary |
| subBranch | subbranch | N | - | See project-domain-fill-spec and field-enum-glossary |
| extendParams | extendparams | N | - | See project-domain-fill-spec and field-enum-glossary |
| cusIp | cusip | N | - | See project-domain-fill-spec and field-enum-glossary |
| frontUrl | front_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | N | - | See project-domain-fill-spec and field-enum-glossary |
| trueName | truename | N | - | See project-domain-fill-spec and field-enum-glossary |
| asInfo | asinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| fqNum | fqnum | N | - | See project-domain-fill-spec and field-enum-glossary |
| unPid | unpid | N | - | See project-domain-fill-spec and field-enum-glossary |
| finOrg | finorg | N | - | See project-domain-fill-spec and field-enum-glossary |
| operatorId | operatorid | N | - | See project-domain-fill-spec and field-enum-glossary |
| iscofee | iscofee | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnitOrderScanQrPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| authCode | authcode | N | - | See project-domain-fill-spec and field-enum-glossary |
| limitPay | limit_pay | N | - | See project-domain-fill-spec and field-enum-glossary |
| goodsTag | goods_tag | N | - | See project-domain-fill-spec and field-enum-glossary |
| benefitDetail | benefitdetail | N | - | See project-domain-fill-spec and field-enum-glossary |
| subAppid | sub_appid | N | - | See project-domain-fill-spec and field-enum-glossary |
| chnlStoreId | chnlstoreid | N | - | See project-domain-fill-spec and field-enum-glossary |
| subBranch | subbranch | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | N | - | See project-domain-fill-spec and field-enum-glossary |
| extendParams | extendparams | N | - | See project-domain-fill-spec and field-enum-glossary |
| trueName | truename | N | - | See project-domain-fill-spec and field-enum-glossary |
| asInfo | asinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| fqNum | fqnum | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| unPid | unpid | N | - | See project-domain-fill-spec and field-enum-glossary |
| termInfo | terminfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| operatorId | operatorid | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnitOrderWxFacePayInfoRequset

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| storeId | storeid | N | - | See project-domain-fill-spec and field-enum-glossary |
| storeName | storename | N | - | See project-domain-fill-spec and field-enum-glossary |
| deviceId | deviceid | N | - | See project-domain-fill-spec and field-enum-glossary |
| attach | attach | N | - | See project-domain-fill-spec and field-enum-glossary |
| rawData | rawdata | N | - | See project-domain-fill-spec and field-enum-glossary |
| subAppId | subappid | N | - | See project-domain-fill-spec and field-enum-glossary |

## UnYwPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| expireTime | expiretime | N | - | See project-domain-fill-spec and field-enum-glossary |
| appName | appname | N | - | See project-domain-fill-spec and field-enum-glossary |
| limitPay | limit_pay | N | - | See project-domain-fill-spec and field-enum-glossary |
| notifyUrl | notify_url | N | - | See project-domain-fill-spec and field-enum-glossary |
| appType | apptype | N | - | See project-domain-fill-spec and field-enum-glossary |
| cusIp | cusip | N | - | See project-domain-fill-spec and field-enum-glossary |
| asInfo | asinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| idNo | idno | Y | - | See project-domain-fill-spec and field-enum-glossary |
| trueName | truename | Y | - | See project-domain-fill-spec and field-enum-glossary |
| encryptType | encrypttype | N | - | See project-domain-fill-spec and field-enum-glossary |
| extendParams | extendparams | N | - | See project-domain-fill-spec and field-enum-glossary |

## UserTransCusPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| c | c | N | - | See project-domain-fill-spec and field-enum-glossary |
| oid | oid | N | - | See project-domain-fill-spec and field-enum-glossary |
| uniReqSn | unireqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| amt | amt | N | - | See project-domain-fill-spec and field-enum-glossary |
| retUrl | returl | N | - | See project-domain-fill-spec and field-enum-glossary |
| trxReserve | trxreserve | N | - | See project-domain-fill-spec and field-enum-glossary |
| submitTime | submittime | N | - | See project-domain-fill-spec and field-enum-glossary |
| extendParams | extendparams | N | - | See project-domain-fill-spec and field-enum-glossary |
| asInfo | asinfo | N | - | See project-domain-fill-spec and field-enum-glossary |

## WxOpenGetOpenIdRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| appType | apptype | N | - | See project-domain-fill-spec and field-enum-glossary |
| redirectUrl | redirecturl | N | - | See project-domain-fill-spec and field-enum-glossary |
| state | state | N | - | See project-domain-fill-spec and field-enum-glossary |

## ZhimaCreditMiniOrderRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| tranCode | trancode | N | - | See project-domain-fill-spec and field-enum-glossary |
| serviceId | serviceid | N | - | See project-domain-fill-spec and field-enum-glossary |
| bizData | bizdata | N | - | See project-domain-fill-spec and field-enum-glossary |
| id | id | N | - | See project-domain-fill-spec and field-enum-glossary |

## ZhimaCreditPayRequest

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| trxAmt | trxamt | N | - | See project-domain-fill-spec and field-enum-glossary |
| reqSn | reqsn | N | - | See project-domain-fill-spec and field-enum-glossary |
| body | body | N | - | See project-domain-fill-spec and field-enum-glossary |
| remark | remark | N | - | See project-domain-fill-spec and field-enum-glossary |
| asInfo | asinfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| extendParams | extendparams | N | - | See project-domain-fill-spec and field-enum-glossary |
| termInfo | terminfo | N | - | See project-domain-fill-spec and field-enum-glossary |
| validTime | validtime | N | - | See project-domain-fill-spec and field-enum-glossary |

## ZhimaCreditTCMiniOrderChanged

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| outOrderId | out_order_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderId | order_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| tradeNo | trade_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| status | status | N | - | See project-domain-fill-spec and field-enum-glossary |
| operateAppId | operate_app_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| authAppId | auth_app_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| totalAmount | total_amount | N | - | See project-domain-fill-spec and field-enum-glossary |
| receiptAmount | receipt_amount | N | - | See project-domain-fill-spec and field-enum-glossary |
| secureReason | secure_reason | N | - | See project-domain-fill-spec and field-enum-glossary |
| groupBuyInfo | group_buy_info | N | - | See project-domain-fill-spec and field-enum-glossary |
| userId | user_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| openId | open_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| settleType | settle_type | N | - | See project-domain-fill-spec and field-enum-glossary |
| voucherDetailList | voucher_detail_list | N | - | See project-domain-fill-spec and field-enum-glossary |

## ZhimaCreditTCMiniOrderClose

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| outOrderId | out_order_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderId | order_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| userId | user_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| openId | open_id | N | - | See project-domain-fill-spec and field-enum-glossary |

## ZhimaCreditTCMiniOrderCreate

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| outOrderId | out_order_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| title | title | N | - | See project-domain-fill-spec and field-enum-glossary |
| sourceId | source_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| merchantBizType | merchant_biz_type | N | - | See project-domain-fill-spec and field-enum-glossary |
| path | path | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderDetail | order_detail | N | - | See project-domain-fill-spec and field-enum-glossary |
| sellerId | seller_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| buyerId | buyer_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| buyerOpenId | buyer_open_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| buyerLogonId | buyer_logon_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| shopInfo | shop_info | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditInfo | credit_info | N | - | See project-domain-fill-spec and field-enum-glossary |
| stagePayPlans | stage_pay_plans | N | - | See project-domain-fill-spec and field-enum-glossary |
| contactInfo | contact_info | N | - | See project-domain-fill-spec and field-enum-glossary |
| addressInfo | address_info | N | - | See project-domain-fill-spec and field-enum-glossary |
| promoDetaiInfo | promo_detai_info | N | - | See project-domain-fill-spec and field-enum-glossary |
| extInfo | ext_info | N | - | See project-domain-fill-spec and field-enum-glossary |
| deliveryDetail | delivery_detail | N | - | See project-domain-fill-spec and field-enum-glossary |
| defaultReceivingAddress | default_receiving_address | N | - | See project-domain-fill-spec and field-enum-glossary |

## ZhimaCreditTCMiniOrderCreditAgreeChanged

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditAgreementId | credit_agreement_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| title | title | N | - | See project-domain-fill-spec and field-enum-glossary |
| agreementStatus | agreement_status | N | - | See project-domain-fill-spec and field-enum-glossary |
| outAgreementNo | out_agreement_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| bizTime | biz_time | N | - | See project-domain-fill-spec and field-enum-glossary |
| openChannel | open_channel | N | - | See project-domain-fill-spec and field-enum-glossary |
| alipayUserId | alipay_user_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| openId | open_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| extInfo | ext_info | N | - | See project-domain-fill-spec and field-enum-glossary |

## ZhimaCreditTCMiniOrderCreditAgreeQuery

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| outAgreementNo | out_agreement_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| creditAgreementId | credit_agreement_id | N | - | See project-domain-fill-spec and field-enum-glossary |

## ZhimaCreditTCMiniOrderInstallmentCreate

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| outInstallmentOrderId | out_installment_order_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| type | type | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderId | order_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| outOrderId | out_order_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| userId | user_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| openId | open_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| installmentPrice | installment_price | N | - | See project-domain-fill-spec and field-enum-glossary |
| installmentNo | installment_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| tradeNo | trade_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| isFinishPerformance | is_finish_performance | N | - | See project-domain-fill-spec and field-enum-glossary |
| payChannel | pay_channel | N | - | See project-domain-fill-spec and field-enum-glossary |
| stageNo | stage_no | N | - | See project-domain-fill-spec and field-enum-glossary |
| isSyncPay | is_sync_pay | N | - | See project-domain-fill-spec and field-enum-glossary |

## ZhimaCreditTCMiniOrderQuery

| Field | JSON Name | Encrypt | Description | Fill Guide |
|---|---|---|---|---|
| serialVersionUID | - | N | - | See project-domain-fill-spec and field-enum-glossary |
| outOrderId | out_order_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| orderId | order_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| userId | user_id | N | - | See project-domain-fill-spec and field-enum-glossary |
| openId | open_id | N | - | See project-domain-fill-spec and field-enum-glossary |


