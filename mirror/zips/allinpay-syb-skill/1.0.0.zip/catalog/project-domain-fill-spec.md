# Project Domain Fill Spec

按“文集 -> SDK 请求类 -> 填参规则”映射。

## 1) 顶级文集与项目号映射

| 页面 | 文集 | project |
|---|---|---|
| page=1 | 收银宝指引 | `12` |
| page=1 | 终端订单API | `15` |
| page=1 | 当面付订单API | `16` |
| page=1 | 统一下单API | `17` |
| page=1 | 支付宝先享后付 | `20` |
| page=1 | 统一分期API | `21` |
| page=1 | 微信支付分 | `22` |
| page=1 | 微信生活缴费 | `28` |
| page=1 | 快捷支付API | `29` |
| page=1 | 网关支付API | `30` |
| page=1 | 云闪付支付API | `31` |
| page=1 | 通联收银台 | `32` |
| page=2 | 网上收银预消费 | `33` |
| page=2 | B2B订单API | `34` |
| page=2 | 方案类API | `36` |
| page=2 | 服务类API | `37` |
| page=2 | 代理商服务API | `38` |
| page=2 | 终端类 | `39` |
| page=2 | 内部API | `43`（受权限控制） |
| page=2 | 应用服务商API | `49` |

## 2) 文集 -> SDK 请求类前缀映射

| 文集 | SDK 请求类前缀/类 |
|---|---|
| 统一下单API(`17`) | `UnitOrder*`, `Tranx*`, `UnYwPayRequest`, `UnitOrderCreateZhiRequest`, `UnitOrderAuthCode2UserIdRequset` |
| 统一分期API(`21`) | `Fqf*`（含 `FqfJfqPayRequest` 聚分期） |
| 快捷支付API(`29`) | `QPay*`, `QPayol*` |
| 网关支付API(`30`) | `GateWay*`, `H5*`, `B2bOrder*` |
| 云闪付支付API(`31`) | `UnConscsPay*`, `UnYwPayRequest` |
| 通联收银台(`32`) | 以收银台专用接口为主（SDK侧多通过统一下单/网关能力承接） |
| 网上收银预消费(`33`) | `PreScanPay*` |
| B2B订单API(`34`) | `B2bOrderPayRequest`, `B2bOrderDirectPayRequest` |
| 服务类API(`37`) | `SybService*`, `RiskFeeBack*`, `Tlinvoice*`, `TrxFile*` |
| 应用服务商API(`49`) | `BillPay*` |
| 终端类(`39`) | 终端协议为主，SDK直连接口与终端能力组合使用 |

## 3) 通用填参规则

1. `cusid/appid` 必传；`orgid` 按代理模式传。  
2. `reqsn` 保证全局唯一；金额统一“分”。  
3. `randomstr/signtype/sign` 按签名规范。  
4. `notify_url` 公网可达且不带参数。  
5. `@EncryptField` 传明文，SDK自动加密。  
6. 结果判定：响应 JSON 的 `retcode` + `trxstatus`（Java 代码对应 `getRetcode()` + `getTrxStatus()`；不要把 JSON 字段名直接拼成 getter）。  

## 4) 各域关键字段补充

### 4.1 统一下单域（`UnitOrder*`）

- 核心：`trxamt`, `paytype`, `reqsn/unireqsn`, `notify_url`
- 渠道差异：
  - JS/小程序：`acct`（openid/user_id/userId）
  - 微信APP/订单支付：`sub_appid`
  - 云闪付JS：`cusip` 必传
- 常见枚举：`paytype`, `limit_pay`, `fqnum`, `idtype`

### 4.2 交易后处理域（`Tranx*`）

- 查询：`reqsn` 与 `trxid` 二选一，优先 `trxid`
- 退款/撤销：`oldreqsn` 与 `oldtrxid` 二选一，优先 `oldtrxid`

### 4.3 统一分期域（`Fqf*`）

- 聚分期下单：`FqfJfqPayRequest`
- 关键字段：`reqsn`, `trxamt`, `idno`, `truename`, `mobile`, `notify_url`
- 期数/银行/场景等字段按业务开通能力选填：`fqnum`, `bankcode`, `senceflag`

### 4.4 快捷支付域（`QPay*`/`QPayol*`）

- 四步链路：签约申请 -> 签约确认 -> 支付申请 -> 支付确认
- `thpInfo` 必须原样透传到下一步
- `agreeId` 必须持久化

### 4.5 特殊域

- 文件上传：`FileUploadRequest` + `upload(...)`
- 对账文件：`TrxFileGetRequest` 先取下载链接，再 `downloadToByte/file(...)`
- 通知处理：`noticeHandle(noticeStr)` 解析+验签
- 前端跳转：`AllinpayFrontResp`（`urlJump/htmlJump`）

## 5) Agent 执行顺序

1. 先判文集域。  
2. 再选请求类。  
3. 最后补字段与枚举。  
4. 特殊域走 `SpecialSceneSybDemo`。  

