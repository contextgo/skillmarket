# Request Routing Map

用于把“业务描述”快速路由到具体请求类。

## 高频支付场景

| 关键词 | 请求类 |
|---|---|
| 统一下单、主扫、扫码支付 | `UnitOrderPayRequest` |
| 被扫、反扫、B扫C | `UnitOrderScanQrPayRequest` |
| 订单查询、查单、轮询 | `TranxQueryRequest` |
| 退款 | `TranxRefundRequest` |
| 撤销 | `TranxCancelRequest` |
| 关闭订单 | `TranxCloseRequset` |

## 快捷/分期

| 关键词 | 请求类 |
|---|---|
| 快捷签约申请 | `QPayAgreeApplyRequest` |
| 快捷签约确认 | `QPayAgreeConfirmRequest` |
| 快捷支付申请 | `QPayApplyRequest` |
| 快捷支付确认 | `QPayConfirmRequest` |
| 分期信息查询 | `FqfInfoRequest` |
| 分期申请 | `FqfApplyRequest` |
| 分期确认 | `FqfPayConfirmRequest` |

## 文件与对账

| 关键词 | 请求类/调用方式 |
|---|---|
| 文件上传、图片上传、材料上传 | `FileUploadRequest` + `AllinpayApi.client().upload(...)` |
| 对账文件下载链接获取 | `TrxFileGetRequest` |
| 对账文件下载 | `AllinpayApi.client().downloadToByte(...)` / `downloadToFile(...)` |

## 特殊非标准场景（不走普通 execObj<Request,Response>）

| 场景 | 调用方式 |
|---|---|
| 异步通知验签与解析 | `AllinpayApi.client().noticeHandle(noticeStr)` |
| 前端跳转（按 ApiType 处理） | `AllinpayApi.client().execObj(..., request)` -> `AllinpayFrontResp`，根据 `FRONT_URL`/`FRONT_HTML`/`FRONT_BOTH` 处理字段 |

## 常见前缀分组（索引补充）

- `UnitOrder*`: 收银主链路（下单、被扫、状态）
- `Tranx*`: 交易后处理（查询、退款、撤销、文件）
- `QPay*`: 快捷支付协议与支付
- `Fqf*`: 分期支付
- `MerChant*`: 商户进件/配置/修复
- `RiskFeeBack*`: 投诉与举证
- `SybService*`: 增值服务能力
- `UnionPay*` / `Un*`: 银联及联合场景扩展

