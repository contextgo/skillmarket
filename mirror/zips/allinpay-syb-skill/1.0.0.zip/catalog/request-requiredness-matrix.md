﻿# Request Requiredness Matrix

Full coverage for SDK request classes with conservative requiredness.

Version: v1.0
Generated At: 2026-04-16 18:46:21
Owner Note: Keep conservative to avoid false-requiredness complaints.

- R = Required
- C = Conditional
- O = Optional
- U = Unknown (not fully verified)

Total request classes: **188**

## ActivityActivityPageRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| actId | actid | U | not fully verified in docs yet | sdk-structure | low |
| userId | userid | U | not fully verified in docs yet | sdk-structure | low |

## ActivityCusActivityRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| corpBusName | corpbusname | U | not fully verified in docs yet | sdk-structure | low |
| branchName | branchname | U | not fully verified in docs yet | sdk-structure | low |
| areaCode | areacode | U | not fully verified in docs yet | sdk-structure | low |
| address | address | U | not fully verified in docs yet | sdk-structure | low |
| actType | acttype | U | not fully verified in docs yet | sdk-structure | low |
| zipPicUrl | zippicurl | U | not fully verified in docs yet | sdk-structure | low |
| notifyUrl | notifyurl | U | not fully verified in docs yet | sdk-structure | low |
| actDetail | actdetail | U | not fully verified in docs yet | sdk-structure | low |

## ActivityQueryActivityRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| actType | acttype | U | not fully verified in docs yet | sdk-structure | low |

## AllinpayReq

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| orgId | orgid | O | group/agent mode only | common | high |
| cusId | cusid | R | merchant id | common | high |
| appId | appid | R | application id | common | high |
| version | version | O | depends on api version rule | common | medium |
| randomStr | randomstr | R | random string | common | medium |
| specBody | - | U | not fully verified in docs yet | sdk-structure | low |

## AllinpayReqInf

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## B2bOrderDirectPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | needs per-api doc verification | project34 | low |
| reqSn | reqsn | U | needs per-api doc verification | project34 | low |
| body | body | U | needs per-api doc verification | project34 | low |
| remark | remark | U | needs per-api doc verification | project34 | low |
| validTime | validtime | U | needs per-api doc verification | project34 | low |
| acctNo | acctno | U | needs per-api doc verification | project34 | low |
| acctName | acctname | U | needs per-api doc verification | project34 | low |
| acctType | accttype | U | needs per-api doc verification | project34 | low |
| bankCode | bankcode | U | needs per-api doc verification | project34 | low |
| goodsInfo | goodsinfo | U | needs per-api doc verification | project34 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project34 | low |
| encrypttype | encrypttype | U | needs per-api doc verification | project34 | low |

## B2bOrderPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | needs per-api doc verification | project34 | low |
| payeeCusId | payeecusid | U | needs per-api doc verification | project34 | low |
| reqSn | reqsn | U | needs per-api doc verification | project34 | low |
| body | body | U | needs per-api doc verification | project34 | low |
| remark | remark | U | needs per-api doc verification | project34 | low |
| validTime | validtime | U | needs per-api doc verification | project34 | low |
| acctNo | acctno | U | needs per-api doc verification | project34 | low |
| acctName | acctname | U | needs per-api doc verification | project34 | low |
| acctType | accttype | U | needs per-api doc verification | project34 | low |
| bankCode | bankcode | U | needs per-api doc verification | project34 | low |
| goodsInfo | goodsinfo | U | needs per-api doc verification | project34 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project34 | low |
| encrypttype | encrypttype | U | needs per-api doc verification | project34 | low |

## BillPayAddRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digId | digid | U | needs per-api doc verification | project49 | low |
| payeeCusId | payeecusid | U | needs per-api doc verification | project49 | low |
| payerCusId | payercusid | U | needs per-api doc verification | project49 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project49 | low |
| billId | billid | U | needs per-api doc verification | project49 | low |
| subject | subject | U | needs per-api doc verification | project49 | low |
| remark | remark | U | needs per-api doc verification | project49 | low |
| notifyUrl | notifyurl | U | needs per-api doc verification | project49 | low |
| autoPay | autopay | U | needs per-api doc verification | project49 | low |
| autoPayTime | autopaytime | U | needs per-api doc verification | project49 | low |

## BillPayDelRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digId | digid | U | needs per-api doc verification | project49 | low |
| payeeCusId | payeecusid | U | needs per-api doc verification | project49 | low |
| billId | billid | U | needs per-api doc verification | project49 | low |

## BillPayQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digId | digid | U | needs per-api doc verification | project49 | low |
| payeeCusId | payeecusid | U | needs per-api doc verification | project49 | low |
| billId | billid | U | needs per-api doc verification | project49 | low |

## BillPayRefundRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digId | digid | U | needs per-api doc verification | project49 | low |
| payeeCusId | payeecusid | U | needs per-api doc verification | project49 | low |
| billId | billid | U | needs per-api doc verification | project49 | low |
| refundAmt | refundamt | U | needs per-api doc verification | project49 | low |

## BillPaySetOfflinePayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digId | digid | U | needs per-api doc verification | project49 | low |
| payeeCusId | payeecusid | U | needs per-api doc verification | project49 | low |
| billId | billid | U | needs per-api doc verification | project49 | low |

## CusAcctQueryAcctOverLimitRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## CusAcctQueryBalanceRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| acctType | accttype | U | not fully verified in docs yet | sdk-structure | low |

## CusAcctQueryHisBalanceRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| acctDate | acctdate | U | not fully verified in docs yet | sdk-structure | low |

## CusAcctQueryTrxRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxType | trxtype | U | not fully verified in docs yet | sdk-structure | low |
| trxId | trxid | U | not fully verified in docs yet | sdk-structure | low |
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |

## CusAcctTransferBalRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| payerCusId | payercusid | U | not fully verified in docs yet | sdk-structure | low |
| payeeCusId | payeecusid | U | not fully verified in docs yet | sdk-structure | low |
| trxAmt | trxamt | U | not fully verified in docs yet | sdk-structure | low |
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |

## CusAcctWithDrawQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxId | trxid | U | not fully verified in docs yet | sdk-structure | low |
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |

## CusAcctWithDrawRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | not fully verified in docs yet | sdk-structure | low |
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| depType | deptype | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |
| summary | summary | U | not fully verified in docs yet | sdk-structure | low |

## DigitalConfirmAuthCusStateRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digId | digid | U | not fully verified in docs yet | sdk-structure | low |
| confirmStatus | confirmstatus | U | not fully verified in docs yet | sdk-structure | low |

## DigitalQueryAuthCusStateRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digTalId | digtalid | U | not fully verified in docs yet | sdk-structure | low |
| innerAppid | innerappid | U | not fully verified in docs yet | sdk-structure | low |
| authCusId | authcusid | U | not fully verified in docs yet | sdk-structure | low |

## DigitalSendCouponsRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digId | digid | U | not fully verified in docs yet | sdk-structure | low |
| stockId | stockid | U | not fully verified in docs yet | sdk-structure | low |
| openId | openid | U | not fully verified in docs yet | sdk-structure | low |
| couponValue | couponvalue | U | not fully verified in docs yet | sdk-structure | low |
| couponMiniMum | couponminimum | U | not fully verified in docs yet | sdk-structure | low |

## DigitalUrlRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digitalId | digitalid | U | not fully verified in docs yet | sdk-structure | low |
| authUserId | authuserid | U | not fully verified in docs yet | sdk-structure | low |
| authCusId | authcusid | U | not fully verified in docs yet | sdk-structure | low |
| branchNo | branchno | U | not fully verified in docs yet | sdk-structure | low |
| branchName | branchname | U | not fully verified in docs yet | sdk-structure | low |

## DigitalWxCateringOrderSyncStatusRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digId | digid | U | not fully verified in docs yet | sdk-structure | low |
| subAppid | sub_appid | U | not fully verified in docs yet | sdk-structure | low |
| outShopNo | outshopno | U | not fully verified in docs yet | sdk-structure | low |
| subOpenId | subopenid | U | not fully verified in docs yet | sdk-structure | low |
| loginToken | logintoken | U | not fully verified in docs yet | sdk-structure | low |
| orderEntry | orderentry | U | not fully verified in docs yet | sdk-structure | low |
| totalAmount | totalamount | U | not fully verified in docs yet | sdk-structure | low |
| discountAmount | discountamount | U | not fully verified in docs yet | sdk-structure | low |
| userAmount | useramount | U | not fully verified in docs yet | sdk-structure | low |
| status | status | U | not fully verified in docs yet | sdk-structure | low |
| actionTime | actiontime | U | not fully verified in docs yet | sdk-structure | low |
| payTime | paytime | U | not fully verified in docs yet | sdk-structure | low |
| chnlTrxId | chnltrxid | U | not fully verified in docs yet | sdk-structure | low |
| trxId | trxid | U | not fully verified in docs yet | sdk-structure | low |
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| dishList | dishlist | U | not fully verified in docs yet | sdk-structure | low |
| outTableNo | outtableno | U | not fully verified in docs yet | sdk-structure | low |
| peopleCount | peoplecount | U | not fully verified in docs yet | sdk-structure | low |

## FileUploadRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| fileType | filetype | U | not fully verified in docs yet | sdk-structure | low |
| filecontent | - | U | not fully verified in docs yet | sdk-structure | low |

## FqfApplyRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqTime | reqtime | U | needs per-api doc verification | project21 | low |
| encryptType | encrypttype | U | needs per-api doc verification | project21 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project21 | low |
| reqSn | reqsn | U | needs per-api doc verification | project21 | low |
| acctNo | acctno | U | needs per-api doc verification | project21 | low |
| fqNum | fqnum | U | needs per-api doc verification | project21 | low |
| idNo | idno | U | needs per-api doc verification | project21 | low |
| idType | idtype | U | needs per-api doc verification | project21 | low |
| acctName | acctname | U | needs per-api doc verification | project21 | low |
| mobile | mobile | U | needs per-api doc verification | project21 | low |
| currency | currency | U | needs per-api doc verification | project21 | low |
| subject | subject | U | needs per-api doc verification | project21 | low |
| validTime | validtime | U | needs per-api doc verification | project21 | low |
| trxReserve | trxreserve | U | needs per-api doc verification | project21 | low |
| notifyUrl | notifyurl | U | needs per-api doc verification | project21 | low |

## FqfBbSignPageRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqTime | reqtime | U | needs per-api doc verification | project21 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project21 | low |
| acctNo | acctno | U | needs per-api doc verification | project21 | low |
| feeNum | feenum | U | needs per-api doc verification | project21 | low |

## FqfInfoRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | needs per-api doc verification | project21 | low |
| reqTime | reqtime | U | needs per-api doc verification | project21 | low |
| acctNo | acctno | U | needs per-api doc verification | project21 | low |

## FqfJDBTCountFeeRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | needs per-api doc verification | project21 | low |

## FqfJDBTPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | needs per-api doc verification | project21 | low |
| body | body | U | needs per-api doc verification | project21 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project21 | low |
| remark | remark | U | needs per-api doc verification | project21 | low |
| fqNum | fqnum | U | needs per-api doc verification | project21 | low |
| validTime | validtime | U | needs per-api doc verification | project21 | low |
| cusIp | cusip | U | needs per-api doc verification | project21 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project21 | low |
| extendParams | extendparams | U | needs per-api doc verification | project21 | low |

## FqfJfqPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | R | jfq core fields | project21 | high |
| encryptType | encrypttype | O | open-capability based optional | project21 | medium |
| trxAmt | trxamt | R | jfq core fields | project21 | high |
| unPid | unpid | O | open-capability based optional | project21 | medium |
| maskedAcctNo | maskedacctno | O | open-capability based optional | project21 | medium |
| bankCode | bankcode | O | open-capability based optional | project21 | medium |
| fqNum | fqnum | O | open-capability based optional | project21 | medium |
| senceFlag | senceflag | O | open-capability based optional | project21 | medium |
| idNo | idno | C | commonly required in risk/realname flow | project21 | medium |
| trueName | truename | C | commonly required in risk/realname flow | project21 | medium |
| mobile | mobile | C | commonly required in risk/realname flow | project21 | medium |
| loginStatus | loginstatus | O | open-capability based optional | project21 | medium |
| retType | rettype | O | open-capability based optional | project21 | medium |
| validTime | validtime | O | open-capability based optional | project21 | medium |
| frontUrl | front_url | O | open-capability based optional | project21 | medium |
| notifyUrl | notify_url | O | open-capability based optional | project21 | medium |
| extendParams | extendparams | O | open-capability based optional | project21 | medium |

## FqfPayConfirmRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqTime | reqtime | U | needs per-api doc verification | project21 | low |
| encryptType | encrypttype | U | needs per-api doc verification | project21 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project21 | low |
| reqSn | reqsn | U | needs per-api doc verification | project21 | low |
| acctNo | acctno | U | needs per-api doc verification | project21 | low |
| fqNum | fqnum | U | needs per-api doc verification | project21 | low |
| idNo | idno | U | needs per-api doc verification | project21 | low |
| idType | idtype | U | needs per-api doc verification | project21 | low |
| acctName | acctname | U | needs per-api doc verification | project21 | low |
| mobile | mobile | U | needs per-api doc verification | project21 | low |
| currency | currency | U | needs per-api doc verification | project21 | low |
| subject | subject | U | needs per-api doc verification | project21 | low |
| validTime | validtime | U | needs per-api doc verification | project21 | low |
| trxReserve | trxreserve | U | needs per-api doc verification | project21 | low |
| notifyUrl | notifyurl | U | needs per-api doc verification | project21 | low |
| smsCode | smscode | U | needs per-api doc verification | project21 | low |
| thpInfo | thpinfo | U | needs per-api doc verification | project21 | low |

## GateWayH5Request

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | needs per-api doc verification | project30 | low |
| reqSn | reqsn | U | needs per-api doc verification | project30 | low |
| charset | charset | U | needs per-api doc verification | project30 | low |
| retUrl | returl | U | needs per-api doc verification | project30 | low |
| retType | rettype | U | needs per-api doc verification | project30 | low |
| notifyUrl | notifyurl | U | needs per-api doc verification | project30 | low |
| body | body | U | needs per-api doc verification | project30 | low |
| remark | remark | U | needs per-api doc verification | project30 | low |
| validTime | validtime | U | needs per-api doc verification | project30 | low |
| limitPay | limit_pay | U | needs per-api doc verification | project30 | low |
| asInfo | asinfo | U | needs per-api doc verification | project30 | low |
| subBranch | subbranch | U | needs per-api doc verification | project30 | low |
| gateId | gateid | U | needs per-api doc verification | project30 | low |
| idType | idtype | U | needs per-api doc verification | project30 | low |
| idNo | idno | U | needs per-api doc verification | project30 | low |
| trueName | truename | U | needs per-api doc verification | project30 | low |

## GateWayPCRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| charset | charset | U | needs per-api doc verification | project30 | low |
| retUrl | returl | U | needs per-api doc verification | project30 | low |
| notifyUrl | notifyurl | U | needs per-api doc verification | project30 | low |
| goodsId | goodsid | U | needs per-api doc verification | project30 | low |
| goodsInf | goodsinf | U | needs per-api doc verification | project30 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project30 | low |
| orderId | orderid | U | needs per-api doc verification | project30 | low |
| gateId | gateid | U | needs per-api doc verification | project30 | low |
| payType | paytype | U | needs per-api doc verification | project30 | low |
| validTime | validtime | U | needs per-api doc verification | project30 | low |
| limitPay | limitpay | U | needs per-api doc verification | project30 | low |

## H5BillPayBillPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| digId | digid | U | needs per-api doc verification | project32 | low |
| payeeCusId | payeecusid | U | needs per-api doc verification | project32 | low |
| billId | billid | U | needs per-api doc verification | project32 | low |

## H5UnionPayOrderRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | needs per-api doc verification | project32 | low |
| payType | paytype | U | needs per-api doc verification | project32 | low |
| fqNum | fqnum | U | needs per-api doc verification | project32 | low |
| reqSn | reqsn | U | needs per-api doc verification | project32 | low |
| uniReqSn | unireqsn | U | needs per-api doc verification | project32 | low |
| charset | charset | U | needs per-api doc verification | project32 | low |
| retUrl | returl | U | needs per-api doc verification | project32 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project32 | low |
| body | body | U | needs per-api doc verification | project32 | low |
| remark | remark | U | needs per-api doc verification | project32 | low |
| validTime | validtime | U | needs per-api doc verification | project32 | low |
| expireTime | expiretime | U | needs per-api doc verification | project32 | low |
| limitPay | limit_pay | U | needs per-api doc verification | project32 | low |
| goodsTag | goods_tag | U | needs per-api doc verification | project32 | low |
| benefitDetail | benefitdetail | U | needs per-api doc verification | project32 | low |
| asInfo | asinfo | U | needs per-api doc verification | project32 | low |
| subBranch | subbranch | U | needs per-api doc verification | project32 | low |
| extendParams | extendparams | U | needs per-api doc verification | project32 | low |
| trueName | truename | U | needs per-api doc verification | project32 | low |
| idNo | idno | U | needs per-api doc verification | project32 | low |
| isHide | ishide | U | needs per-api doc verification | project32 | low |
| isPwdCancel | ispwdcancel | U | needs per-api doc verification | project32 | low |
| unPid | unpid | U | needs per-api doc verification | project32 | low |
| termInfo | terminfo | U | needs per-api doc verification | project32 | low |

## MerChantAcctEditRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| notifyUrl | notifyurl | U | not fully verified in docs yet | sdk-structure | low |
| clearMode | clearmode | U | not fully verified in docs yet | sdk-structure | low |
| acctId | acctid | U | not fully verified in docs yet | sdk-structure | low |
| acctName | acctname | U | not fully verified in docs yet | sdk-structure | low |
| acctType | accttype | U | not fully verified in docs yet | sdk-structure | low |
| acctTp | accttp | U | not fully verified in docs yet | sdk-structure | low |
| bankCode | bankcode | U | not fully verified in docs yet | sdk-structure | low |
| cnapsno | cnapsno | U | not fully verified in docs yet | sdk-structure | low |
| pubAcctInfo | pubacctinfo | U | not fully verified in docs yet | sdk-structure | low |
| picUrlJson | picurljson | U | not fully verified in docs yet | sdk-structure | low |

## MerChantAddRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| merChantId | merchantid | U | not fully verified in docs yet | sdk-structure | low |
| merChantName | merchantname | U | not fully verified in docs yet | sdk-structure | low |
| shortName | shortname | U | not fully verified in docs yet | sdk-structure | low |
| cusEngName | cusengname | U | not fully verified in docs yet | sdk-structure | low |
| cusEngShortName | cusengshortname | U | not fully verified in docs yet | sdk-structure | low |
| servicePhone | servicephone | U | not fully verified in docs yet | sdk-structure | low |
| mccId | mccid | U | not fully verified in docs yet | sdk-structure | low |
| comProperty | comproperty | U | not fully verified in docs yet | sdk-structure | low |
| corpBusName | corpbusname | U | not fully verified in docs yet | sdk-structure | low |
| creditCode | creditcode | U | not fully verified in docs yet | sdk-structure | low |
| creditCodeExpire | creditcodeexpire | U | not fully verified in docs yet | sdk-structure | low |
| legal | legal | U | not fully verified in docs yet | sdk-structure | low |
| legalIdType | legalidtype | U | not fully verified in docs yet | sdk-structure | low |
| legalIdNo | legalidno | U | not fully verified in docs yet | sdk-structure | low |
| legalIdExpire | legalidexpire | U | not fully verified in docs yet | sdk-structure | low |
| address | address | U | not fully verified in docs yet | sdk-structure | low |
| contactPerson | contactperson | U | not fully verified in docs yet | sdk-structure | low |
| contactPhone | contactphone | U | not fully verified in docs yet | sdk-structure | low |
| clearMode | clearmode | U | not fully verified in docs yet | sdk-structure | low |
| acctId | acctid | U | not fully verified in docs yet | sdk-structure | low |
| acctName | acctname | U | not fully verified in docs yet | sdk-structure | low |
| acctType | accttype | U | not fully verified in docs yet | sdk-structure | low |
| acctTp | accttp | U | not fully verified in docs yet | sdk-structure | low |
| bankCode | bankcode | U | not fully verified in docs yet | sdk-structure | low |
| cnapsno | cnapsno | U | not fully verified in docs yet | sdk-structure | low |
| notifyUrl | notifyurl | U | not fully verified in docs yet | sdk-structure | low |
| corpBusPic | corpbuspic | U | not fully verified in docs yet | sdk-structure | low |
| legalIdPicFront | legalidpicfront | U | not fully verified in docs yet | sdk-structure | low |
| legalIdPicBack | legalidpicback | U | not fully verified in docs yet | sdk-structure | low |
| legalPic | legalpic | U | not fully verified in docs yet | sdk-structure | low |
| storePic | storepic | U | not fully verified in docs yet | sdk-structure | low |
| storeInnerPic | storeinnerpic | U | not fully verified in docs yet | sdk-structure | low |
| bizPlacePic | bizplacepic | U | not fully verified in docs yet | sdk-structure | low |
| otherFile | otherfile | U | not fully verified in docs yet | sdk-structure | low |
| expandUser | expanduser | U | not fully verified in docs yet | sdk-structure | low |
| subBranchList | subbranchlist | U | not fully verified in docs yet | sdk-structure | low |
| prodList | prodlist | U | not fully verified in docs yet | sdk-structure | low |
| addFaCusId | addfacusid | U | not fully verified in docs yet | sdk-structure | low |
| settIdNo | settidno | U | not fully verified in docs yet | sdk-structure | low |
| holderName | holdername | U | not fully verified in docs yet | sdk-structure | low |
| holderIdNo | holderidno | U | not fully verified in docs yet | sdk-structure | low |
| holderExpire | holderexpire | U | not fully verified in docs yet | sdk-structure | low |
| registerFund | registerfund | U | not fully verified in docs yet | sdk-structure | low |
| staffTotal | stafftotal | U | not fully verified in docs yet | sdk-structure | low |
| operateLimit | operatelimit | U | not fully verified in docs yet | sdk-structure | low |
| inspect | inspect | U | not fully verified in docs yet | sdk-structure | low |
| thrCertFlag | thrcertflag | U | not fully verified in docs yet | sdk-structure | low |
| organCode | organcode | U | not fully verified in docs yet | sdk-structure | low |
| organExpire | organexpire | U | not fully verified in docs yet | sdk-structure | low |
| busConActPerson | busconactperson | U | not fully verified in docs yet | sdk-structure | low |
| busConActTel | busconacttel | U | not fully verified in docs yet | sdk-structure | low |
| ofFlag | offlag | U | not fully verified in docs yet | sdk-structure | low |
| unSdRemark | unsdremark | U | not fully verified in docs yet | sdk-structure | low |
| agreeType | agreetype | U | not fully verified in docs yet | sdk-structure | low |
| picUrlJson | picurljson | U | not fully verified in docs yet | sdk-structure | low |
| cusUrl | cusurl | U | not fully verified in docs yet | sdk-structure | low |
| webName | webname | U | not fully verified in docs yet | sdk-structure | low |
| legalDetail | legaldetail | U | not fully verified in docs yet | sdk-structure | low |
| bnfDetail | bnfdetail | U | not fully verified in docs yet | sdk-structure | low |
| taxDetail | taxdetail | U | not fully verified in docs yet | sdk-structure | low |
| busDetail | busdetail | U | not fully verified in docs yet | sdk-structure | low |
| businessPlace | businessplace | U | not fully verified in docs yet | sdk-structure | low |
| busAddress | busaddress | U | not fully verified in docs yet | sdk-structure | low |
| districtCode | districtcode | U | not fully verified in docs yet | sdk-structure | low |
| reqId | reqid | U | not fully verified in docs yet | sdk-structure | low |
| settRemark | settremark | U | not fully verified in docs yet | sdk-structure | low |
| creditCodeType | creditCodeType | U | not fully verified in docs yet | sdk-structure | low |
| creditCodeStartDate | creditCodeStartdate | U | not fully verified in docs yet | sdk-structure | low |
| legalIdStartDate | legalidStartdate | U | not fully verified in docs yet | sdk-structure | low |
| icpInfo | icpinfo | U | not fully verified in docs yet | sdk-structure | low |
| pubAcctInfo | pubacctinfo | U | not fully verified in docs yet | sdk-structure | low |
| appScenario | appscenario | U | not fully verified in docs yet | sdk-structure | low |
| quickCash | quickcash | U | not fully verified in docs yet | sdk-structure | low |
| clearTimeRule | cleartimerule | U | not fully verified in docs yet | sdk-structure | low |
| electNotify | electnotify | U | not fully verified in docs yet | sdk-structure | low |
| creDentCheckDate | credentcheckdate | U | not fully verified in docs yet | sdk-structure | low |

## MerChantAddTermRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| termNo | termno | U | not fully verified in docs yet | sdk-structure | low |
| deviceType | devicetype | U | not fully verified in docs yet | sdk-structure | low |
| termSn | termsn | U | not fully verified in docs yet | sdk-structure | low |
| operaTion | operation | U | not fully verified in docs yet | sdk-structure | low |
| termState | termstate | U | not fully verified in docs yet | sdk-structure | low |
| termAddress | termaddress | U | not fully verified in docs yet | sdk-structure | low |

## MerChantAgentExpiredRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| fileType | filetype | U | not fully verified in docs yet | sdk-structure | low |
| endDate | enddate | U | not fully verified in docs yet | sdk-structure | low |
| notifyUrl | notifyurl | U | not fully verified in docs yet | sdk-structure | low |

## MerChantBindCodeRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| qrCode | qrcode | U | not fully verified in docs yet | sdk-structure | low |
| branchNo | branchno | U | not fully verified in docs yet | sdk-structure | low |
| latitude | latitude | U | not fully verified in docs yet | sdk-structure | low |
| longitude | longitude | U | not fully verified in docs yet | sdk-structure | low |

## MerChantConfirmBindRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| qrCode | qrcode | U | not fully verified in docs yet | sdk-structure | low |
| branchNo | branchno | U | not fully verified in docs yet | sdk-structure | low |
| latitude | latitude | U | not fully verified in docs yet | sdk-structure | low |
| longitude | longitude | U | not fully verified in docs yet | sdk-structure | low |
| smsCode | smscode | U | not fully verified in docs yet | sdk-structure | low |

## MerChantConfirmUnBindRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| qrCode | qrcode | U | not fully verified in docs yet | sdk-structure | low |
| smsCode | smscode | U | not fully verified in docs yet | sdk-structure | low |

## MerChantEditRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| shortName | shortname | U | not fully verified in docs yet | sdk-structure | low |
| servicePhone | servicephone | U | not fully verified in docs yet | sdk-structure | low |
| corpBusName | corpbusname | U | not fully verified in docs yet | sdk-structure | low |
| creditCode | creditcode | U | not fully verified in docs yet | sdk-structure | low |
| creditCodeExpire | creditcodeexpire | U | not fully verified in docs yet | sdk-structure | low |
| legal | legal | U | not fully verified in docs yet | sdk-structure | low |
| legalIdType | legalidtype | U | not fully verified in docs yet | sdk-structure | low |
| legalIdNo | legalidno | U | not fully verified in docs yet | sdk-structure | low |
| legalIdExpire | legalidexpire | U | not fully verified in docs yet | sdk-structure | low |
| address | address | U | not fully verified in docs yet | sdk-structure | low |
| contactPerson | contactperson | U | not fully verified in docs yet | sdk-structure | low |
| contactPhone | contactphone | U | not fully verified in docs yet | sdk-structure | low |
| addFaCusId | addfacusid | U | not fully verified in docs yet | sdk-structure | low |
| notifyUrl | notifyurl | U | not fully verified in docs yet | sdk-structure | low |
| zipUrl | zipurl | U | not fully verified in docs yet | sdk-structure | low |
| picsTrUrl | picstrurl | U | not fully verified in docs yet | sdk-structure | low |
| holderName | holdername | U | not fully verified in docs yet | sdk-structure | low |
| holderIdNo | holderidno | U | not fully verified in docs yet | sdk-structure | low |
| holderExpire | holderexpire | U | not fully verified in docs yet | sdk-structure | low |
| registerFund | registerfund | U | not fully verified in docs yet | sdk-structure | low |
| staffTotal | stafftotal | U | not fully verified in docs yet | sdk-structure | low |
| operateLimit | operatelimit | U | not fully verified in docs yet | sdk-structure | low |
| inspect | inspect | U | not fully verified in docs yet | sdk-structure | low |
| thrCertFlag | thrcertflag | U | not fully verified in docs yet | sdk-structure | low |
| organCode | organcode | U | not fully verified in docs yet | sdk-structure | low |
| organExpire | organexpire | U | not fully verified in docs yet | sdk-structure | low |
| busConActPerson | busconactperson | U | not fully verified in docs yet | sdk-structure | low |
| busConActTel | busconacttel | U | not fully verified in docs yet | sdk-structure | low |
| unSdRemark | unsdremark | U | not fully verified in docs yet | sdk-structure | low |
| legalDetail | legaldetail | U | not fully verified in docs yet | sdk-structure | low |
| bnfDetail | bnfdetail | U | not fully verified in docs yet | sdk-structure | low |
| taxDetail | taxdetail | U | not fully verified in docs yet | sdk-structure | low |
| busDetail | busdetail | U | not fully verified in docs yet | sdk-structure | low |
| cusUrl | cusurl | U | not fully verified in docs yet | sdk-structure | low |
| webName | webname | U | not fully verified in docs yet | sdk-structure | low |
| businessPlace | businessplace | U | not fully verified in docs yet | sdk-structure | low |
| busAddress | busaddress | U | not fully verified in docs yet | sdk-structure | low |
| districtCode | districtcode | U | not fully verified in docs yet | sdk-structure | low |
| merChantName | merchantname | U | not fully verified in docs yet | sdk-structure | low |
| tlBankNo | tlbankno | U | not fully verified in docs yet | sdk-structure | low |
| creditCodeType | creditCodeType | U | not fully verified in docs yet | sdk-structure | low |
| creditCodeStartDate | creditCodeStartdate | U | not fully verified in docs yet | sdk-structure | low |
| legalIdStartDate | legalidStartdate | U | not fully verified in docs yet | sdk-structure | low |

## MerChantElectSignRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| electSignType | electsigntype | U | not fully verified in docs yet | sdk-structure | low |
| relatedCusId | relatedcusid | U | not fully verified in docs yet | sdk-structure | low |

## MerChantProdFeeShareQryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## MerChantProductRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqType | reqtype | U | not fully verified in docs yet | sdk-structure | low |
| prodList | prodlist | U | not fully verified in docs yet | sdk-structure | low |

## MerChantQrCodeQryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| qrCode | qrcode | U | not fully verified in docs yet | sdk-structure | low |

## MerChantQryTermRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| termNo | termno | U | not fully verified in docs yet | sdk-structure | low |
| queryType | querytype | U | not fully verified in docs yet | sdk-structure | low |

## MerChantQueryChnlCmIdRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| chnlType | chnltype | U | not fully verified in docs yet | sdk-structure | low |
| settId | settid | U | not fully verified in docs yet | sdk-structure | low |

## MerChantQueryCusRgcRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## MerChantQueryElectSignRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## MerChantQueryElectUrlRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| redirectUrl | redirecturl | U | not fully verified in docs yet | sdk-structure | low |

## MerChantQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## MerChantQueryStatusRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| merChantId | merchantid | U | not fully verified in docs yet | sdk-structure | low |
| reqId | reqid | U | not fully verified in docs yet | sdk-structure | low |

## MerChantQueryWxSubDevRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## MerChantQueryWxVerifyStateRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| chnlType | chnltype | U | not fully verified in docs yet | sdk-structure | low |
| pid | pid | U | not fully verified in docs yet | sdk-structure | low |

## MerChantRepairComplianceRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| cusShortName | cusshortname | U | not fully verified in docs yet | sdk-structure | low |
| address | address | U | not fully verified in docs yet | sdk-structure | low |
| creDentExpire | credentexpire | U | not fully verified in docs yet | sdk-structure | low |
| legalIdExpire | legalidexpire | U | not fully verified in docs yet | sdk-structure | low |
| acctId | acctid | U | not fully verified in docs yet | sdk-structure | low |
| storePic | storepic | U | not fully verified in docs yet | sdk-structure | low |
| innerPic | innerpic | U | not fully verified in docs yet | sdk-structure | low |
| handPickPic | handpickpic | U | not fully verified in docs yet | sdk-structure | low |
| peasonHeadPic | peasonheadpic | U | not fully verified in docs yet | sdk-structure | low |
| creditPic | creditpic | U | not fully verified in docs yet | sdk-structure | low |
| legalIdPicFront | legalidpicfront | U | not fully verified in docs yet | sdk-structure | low |
| legalIdPicBack | legalidpicback | U | not fully verified in docs yet | sdk-structure | low |
| rentCtPic | rentctpic | U | not fully verified in docs yet | sdk-structure | low |
| registerPic | registerpic | U | not fully verified in docs yet | sdk-structure | low |
| homePagePic | homepagepic | U | not fully verified in docs yet | sdk-structure | low |
| finalPagePic | finalpagepic | U | not fully verified in docs yet | sdk-structure | low |
| clearParamPic | clearparampic | U | not fully verified in docs yet | sdk-structure | low |
| authorPic | authorpic | U | not fully verified in docs yet | sdk-structure | low |
| certifiedPic | certifiedpic | U | not fully verified in docs yet | sdk-structure | low |
| repairOtherPic | repairotherpic | U | not fully verified in docs yet | sdk-structure | low |

## MerChantRepairCusrgcRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| jumpUrl | jumpurl | U | not fully verified in docs yet | sdk-structure | low |

## MerChantSecondPageRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## MerChantSubBranchRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqType | reqtype | U | not fully verified in docs yet | sdk-structure | low |
| subBranchList | subbranchlist | U | not fully verified in docs yet | sdk-structure | low |

## MerChantTermRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqType | reqtype | U | not fully verified in docs yet | sdk-structure | low |
| termList | termlist | U | not fully verified in docs yet | sdk-structure | low |

## MerChantUnBindCodeRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| qrCode | qrcode | U | not fully verified in docs yet | sdk-structure | low |

## MerChantWxSubDevConfigRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| configType | configtype | U | not fully verified in docs yet | sdk-structure | low |
| configVal | configval | U | not fully verified in docs yet | sdk-structure | low |

## MerChantWxVerifyRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| userId | userid | U | not fully verified in docs yet | sdk-structure | low |
| notifyUrl | notifyurl | U | not fully verified in docs yet | sdk-structure | low |
| pageType | pagetype | U | not fully verified in docs yet | sdk-structure | low |

## PayScorePayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| outOrderNo | out_order_no | U | not fully verified in docs yet | sdk-structure | low |
| serviceId | serviceid | U | not fully verified in docs yet | sdk-structure | low |
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| trxAmt | trxamt | U | not fully verified in docs yet | sdk-structure | low |
| scene | scene | U | not fully verified in docs yet | sdk-structure | low |
| body | body | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |
| acct | acct | U | not fully verified in docs yet | sdk-structure | low |
| notifyUrl | notify_url | U | not fully verified in docs yet | sdk-structure | low |
| termInfo | terminfo | U | not fully verified in docs yet | sdk-structure | low |

## PayScoreServiceOrderRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| tranCode | trancode | U | not fully verified in docs yet | sdk-structure | low |
| serviceId | serviceid | U | not fully verified in docs yet | sdk-structure | low |
| bizData | bizdata | U | not fully verified in docs yet | sdk-structure | low |

## PayScoreTCPermissionAdd

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| authorizationAode | authorization_code | U | not fully verified in docs yet | sdk-structure | low |
| subAppid | sub_appid | U | not fully verified in docs yet | sdk-structure | low |
| notifyUrl | notify_url | U | not fully verified in docs yet | sdk-structure | low |

## PayScoreTCPermissionDel

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| authorizationAode | authorization_code | U | not fully verified in docs yet | sdk-structure | low |
| reason | reason | U | not fully verified in docs yet | sdk-structure | low |

## PayScoreTCPermissionGet

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| authorizationAode | authorization_code | U | not fully verified in docs yet | sdk-structure | low |

## PayScoreTCServiceOrderAdd

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| outOrderNo | out_order_no | U | not fully verified in docs yet | sdk-structure | low |
| serviceIntroduction | service_introduction | U | not fully verified in docs yet | sdk-structure | low |
| postPayments | post_payments | U | not fully verified in docs yet | sdk-structure | low |
| postDiscounts | post_discounts | U | not fully verified in docs yet | sdk-structure | low |
| riskFund | risk_fund | U | not fully verified in docs yet | sdk-structure | low |
| timeRange | time_range | U | not fully verified in docs yet | sdk-structure | low |
| location | location | U | not fully verified in docs yet | sdk-structure | low |
| subAppid | sub_appid | U | not fully verified in docs yet | sdk-structure | low |
| subOpenid | sub_openid | U | not fully verified in docs yet | sdk-structure | low |
| needUserConfirm | need_user_confirm | U | not fully verified in docs yet | sdk-structure | low |
| notifyUrl | notify_url | U | not fully verified in docs yet | sdk-structure | low |
| attach | attach | U | not fully verified in docs yet | sdk-structure | low |

## PayScoreTCServiceOrderCancel

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| outOrderNo | out_order_no | U | not fully verified in docs yet | sdk-structure | low |
| reason | reason | U | not fully verified in docs yet | sdk-structure | low |

## PayScoreTCServiceOrderComplete

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| outOrderNo | out_order_no | U | not fully verified in docs yet | sdk-structure | low |
| postPayments | post_payments | U | not fully verified in docs yet | sdk-structure | low |
| postDiscounts | post_discounts | U | not fully verified in docs yet | sdk-structure | low |
| totalAmount | total_amount | U | not fully verified in docs yet | sdk-structure | low |
| timeRange | time_range | U | not fully verified in docs yet | sdk-structure | low |
| location | location | U | not fully verified in docs yet | sdk-structure | low |
| completeTime | complete_time | U | not fully verified in docs yet | sdk-structure | low |

## PayScoreTCServiceOrderGet

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| outOrderNo | out_order_no | U | not fully verified in docs yet | sdk-structure | low |
| queryId | query_id | U | not fully verified in docs yet | sdk-structure | low |

## PosolAuthFinRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| trxId | trxid | U | not fully verified in docs yet | sdk-structure | low |
| trxAmt | trxamt | U | not fully verified in docs yet | sdk-structure | low |

## PosolCancelRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | not fully verified in docs yet | sdk-structure | low |
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| trxId | trxid | U | not fully verified in docs yet | sdk-structure | low |

## PosolQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| trxId | trxid | U | not fully verified in docs yet | sdk-structure | low |

## PreScanPayCancelRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | needs per-api doc verification | project33 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project33 | low |
| oldTrxId | oldtrxid | U | needs per-api doc verification | project33 | low |

## PreScanPayFinishRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| autoBack | autoback | U | needs per-api doc verification | project33 | low |
| reqSn | reqsn | U | needs per-api doc verification | project33 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project33 | low |
| oldTrxId | oldtrxid | U | needs per-api doc verification | project33 | low |
| asInfo | asinfo | U | needs per-api doc verification | project33 | low |

## PreScanPayQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | needs per-api doc verification | project33 | low |
| trxId | trxid | U | needs per-api doc verification | project33 | low |

## PreScanPayRefundRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | needs per-api doc verification | project33 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project33 | low |
| oldTrxId | oldtrxid | U | needs per-api doc verification | project33 | low |

## PreScanPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | needs per-api doc verification | project33 | low |
| reqSn | reqsn | U | needs per-api doc verification | project33 | low |
| payType | paytype | U | needs per-api doc verification | project33 | low |
| body | body | U | needs per-api doc verification | project33 | low |
| remark | remark | U | needs per-api doc verification | project33 | low |
| validTime | validtime | U | needs per-api doc verification | project33 | low |
| expireTime | expiretime | U | needs per-api doc verification | project33 | low |
| authCode | authcode | U | needs per-api doc verification | project33 | low |
| acct | acct | U | needs per-api doc verification | project33 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project33 | low |
| limitPay | limit_pay | U | needs per-api doc verification | project33 | low |
| subAppid | sub_appid | U | needs per-api doc verification | project33 | low |
| subBranch | subbranch | U | needs per-api doc verification | project33 | low |
| termInfo | terminfo | U | needs per-api doc verification | project33 | low |

## QPayAgreeApplyRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqIp | reqip | U | needs per-api doc verification | project29 | low |
| reqTime | reqtime | U | needs per-api doc verification | project29 | low |
| merUserId | meruserid | U | needs per-api doc verification | project29 | low |
| acctType | accttype | U | needs per-api doc verification | project29 | low |
| acctNo | acctno | U | needs per-api doc verification | project29 | low |
| idType | idtype | U | needs per-api doc verification | project29 | low |
| idNo | idno | U | needs per-api doc verification | project29 | low |
| acctName | acctname | U | needs per-api doc verification | project29 | low |
| mobile | mobile | U | needs per-api doc verification | project29 | low |
| validDate | validdate | U | needs per-api doc verification | project29 | low |
| cvv2 | cvv2 | U | needs per-api doc verification | project29 | low |

## QPayAgreeConfirmRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqIp | reqip | U | needs per-api doc verification | project29 | low |
| reqTime | reqtime | U | needs per-api doc verification | project29 | low |
| merUserId | meruserid | U | needs per-api doc verification | project29 | low |
| acctType | accttype | U | needs per-api doc verification | project29 | low |
| acctNo | acctno | U | needs per-api doc verification | project29 | low |
| idType | idtype | U | needs per-api doc verification | project29 | low |
| idNo | idno | U | needs per-api doc verification | project29 | low |
| acctName | acctname | U | needs per-api doc verification | project29 | low |
| mobile | mobile | U | needs per-api doc verification | project29 | low |
| validDate | validdate | U | needs per-api doc verification | project29 | low |
| cvv2 | cvv2 | U | needs per-api doc verification | project29 | low |
| smsCode | smscode | U | needs per-api doc verification | project29 | low |
| thpInfo | thpinfo | U | needs per-api doc verification | project29 | low |
| userAgreeNo | useragreeno | U | needs per-api doc verification | project29 | low |

## QPayApplyRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | needs per-api doc verification | project29 | low |
| agreeId | agreeid | U | needs per-api doc verification | project29 | low |
| amount | amount | U | needs per-api doc verification | project29 | low |
| currency | currency | U | needs per-api doc verification | project29 | low |
| subject | subject | U | needs per-api doc verification | project29 | low |
| trxReserve | trxreserve | U | needs per-api doc verification | project29 | low |
| notifyUrl | notifyurl | U | needs per-api doc verification | project29 | low |
| asInfo | asinfo | U | needs per-api doc verification | project29 | low |

## QPayConfirmRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqIp | reqip | U | needs per-api doc verification | project29 | low |
| reqTime | reqtime | U | needs per-api doc verification | project29 | low |
| reqSn | reqsn | U | needs per-api doc verification | project29 | low |
| agreeId | agreeid | U | needs per-api doc verification | project29 | low |
| smsCode | smscode | U | needs per-api doc verification | project29 | low |
| thpInfo | thpinfo | U | needs per-api doc verification | project29 | low |

## QPayolAgreeApplyRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqIp | reqip | U | needs per-api doc verification | project29 | low |
| reqTime | reqtime | U | needs per-api doc verification | project29 | low |
| applyId | applyid | U | needs per-api doc verification | project29 | low |
| bankCode | bankcode | U | needs per-api doc verification | project29 | low |
| encryptType | encrypttype | U | needs per-api doc verification | project29 | low |
| acctType | accttype | U | needs per-api doc verification | project29 | low |
| idType | idtype | U | needs per-api doc verification | project29 | low |
| idNo | idno | U | needs per-api doc verification | project29 | low |
| acctName | acctname | U | needs per-api doc verification | project29 | low |
| mobile | mobile | U | needs per-api doc verification | project29 | low |
| acctNo | acctno | U | needs per-api doc verification | project29 | low |
| notifyUrl | notifyurl | U | needs per-api doc verification | project29 | low |
| retUrl | returl | U | needs per-api doc verification | project29 | low |

## QPayolBindCardApplyRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqIp | reqip | U | needs per-api doc verification | project29 | low |
| reqTime | reqtime | U | needs per-api doc verification | project29 | low |
| applyId | applyid | U | needs per-api doc verification | project29 | low |
| merUserId | meruserid | U | needs per-api doc verification | project29 | low |
| encryptType | encrypttype | U | needs per-api doc verification | project29 | low |
| notifyUrl | notifyurl | U | needs per-api doc verification | project29 | low |
| retUrl | returl | U | needs per-api doc verification | project29 | low |

## QPaySmsAgreeRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqIp | reqip | U | needs per-api doc verification | project29 | low |
| reqTime | reqtime | U | needs per-api doc verification | project29 | low |
| orderId | orderid | U | needs per-api doc verification | project29 | low |
| agreeId | agreeid | U | needs per-api doc verification | project29 | low |
| thpInfo | thpinfo | U | needs per-api doc verification | project29 | low |

## QPayUnbindRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqIp | reqip | U | needs per-api doc verification | project29 | low |
| reqTime | reqtime | U | needs per-api doc verification | project29 | low |
| agreeId | agreeid | U | needs per-api doc verification | project29 | low |

## RiskFeeBackAliComplaintFileUploadRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| file_content | - | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackAliComplaintProcessFinishRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| timeStamp | timestamp | U | not fully verified in docs yet | sdk-structure | low |
| idList | id_list | U | not fully verified in docs yet | sdk-structure | low |
| processCode | process_code | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |
| imgFileList | img_file_list | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackAliComplaintQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| timeStamp | timestamp | U | not fully verified in docs yet | sdk-structure | low |
| complainId | complain_id | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackAliComplaintQueryV2Request

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| timeStamp | timestamp | U | not fully verified in docs yet | sdk-structure | low |
| currentPageNum | current_page_num | U | not fully verified in docs yet | sdk-structure | low |
| pageSize | page_size | U | not fully verified in docs yet | sdk-structure | low |
| gmtComplaintStart | gmt_complaint_start | U | not fully verified in docs yet | sdk-structure | low |
| gmtComplaintEnd | gmt_complaint_end | U | not fully verified in docs yet | sdk-structure | low |
| tradeNo | trade_no | U | not fully verified in docs yet | sdk-structure | low |
| taskId | task_id | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxAppletBussiAppealRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| timeStamp | timestamp | U | not fully verified in docs yet | sdk-structure | low |
| complaintOrderId | complaintorderid | U | not fully verified in docs yet | sdk-structure | low |
| content | content | U | not fully verified in docs yet | sdk-structure | low |
| mediaIdList | mediaIdlist | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxAppletBussiRespondComplaintRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| timeStamp | timestamp | U | not fully verified in docs yet | sdk-structure | low |
| complaintOrderId | complaintorderid | U | not fully verified in docs yet | sdk-structure | low |
| content | content | U | not fully verified in docs yet | sdk-structure | low |
| mediaIdList | mediaIdlist | U | not fully verified in docs yet | sdk-structure | low |
| bussiHandle | bussihandle | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxAppletBussiSupplyProofRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| timeStamp | timestamp | U | not fully verified in docs yet | sdk-structure | low |
| complaintOrderId | complaintorderid | U | not fully verified in docs yet | sdk-structure | low |
| content | content | U | not fully verified in docs yet | sdk-structure | low |
| mediaIdList | mediaIdlist | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxAppletBussiSupplyRefundRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| timeStamp | timestamp | U | not fully verified in docs yet | sdk-structure | low |
| complaintOrderId | complaintorderid | U | not fully verified in docs yet | sdk-structure | low |
| content | content | U | not fully verified in docs yet | sdk-structure | low |
| mediaIdList | mediaIdlist | U | not fully verified in docs yet | sdk-structure | low |
| acceptReturn | acceptreturn | U | not fully verified in docs yet | sdk-structure | low |
| returnId | returnid | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxAppletComplaintOrderDetailRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| timeStamp | timestamp | U | not fully verified in docs yet | sdk-structure | low |
| complaintOrderId | complaintorderid | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxAppletComplaintQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| timeStamp | timestamp | U | not fully verified in docs yet | sdk-structure | low |
| currentPageNum | current_page_num | U | not fully verified in docs yet | sdk-structure | low |
| pageSize | page_size | U | not fully verified in docs yet | sdk-structure | low |
| gmtComplaintStart | gmt_complaint_start | U | not fully verified in docs yet | sdk-structure | low |
| gmtComplaintEnd | gmt_complaint_end | U | not fully verified in docs yet | sdk-structure | low |
| tradeNo | trade_no | U | not fully verified in docs yet | sdk-structure | low |
| taskId | task_id | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxAppletUploadRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| timeStamp | timestamp | U | not fully verified in docs yet | sdk-structure | low |
| type | type | U | not fully verified in docs yet | sdk-structure | low |
| file | - | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxComplaintCompleteRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| complaintId | complaint_id | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxComplaintDetailRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| complaintId | complaint_id | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxComplaintHistoryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| complaintId | complaint_id | U | not fully verified in docs yet | sdk-structure | low |
| limit | limit | U | not fully verified in docs yet | sdk-structure | low |
| offset | offset | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxComplaintListQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| currentPageNum | current_page_num | U | not fully verified in docs yet | sdk-structure | low |
| pageSize | page_size | U | not fully verified in docs yet | sdk-structure | low |
| beginDate | begindate | U | not fully verified in docs yet | sdk-structure | low |
| endDate | enddate | U | not fully verified in docs yet | sdk-structure | low |
| updateBegin | updatebegin | U | not fully verified in docs yet | sdk-structure | low |
| updateEnd | updateend | U | not fully verified in docs yet | sdk-structure | low |
| groupAll | groupall | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxComplaintRespRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| complaintId | complaint_id | U | not fully verified in docs yet | sdk-structure | low |
| responseContent | response_content | U | not fully verified in docs yet | sdk-structure | low |
| responseImages | response_images | U | not fully verified in docs yet | sdk-structure | low |
| jumpUrl | jump_url | U | not fully verified in docs yet | sdk-structure | low |
| jumpUrlText | jump_url_text | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxComplaintSreFundProgressRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| complaintId | complaint_id | U | not fully verified in docs yet | sdk-structure | low |
| action | action | U | not fully verified in docs yet | sdk-structure | low |
| launchRefundDay | launch_refund_day | U | not fully verified in docs yet | sdk-structure | low |
| rejectReason | reject_reason | U | not fully verified in docs yet | sdk-structure | low |
| rejectMediaList | reject_media_list | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxGetMerchantImageRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| imgUrl | imgurl | U | not fully verified in docs yet | sdk-structure | low |

## RiskFeeBackWxMerchantImageUploadRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| file | - | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceAlinFcConfigRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| termSn | termsn | U | not fully verified in docs yet | sdk-structure | low |
| branchNo | branchno | U | not fully verified in docs yet | sdk-structure | low |
| openFlag | openflag | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceAlinFcQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| termSn | termsn | U | not fully verified in docs yet | sdk-structure | low |
| branchNo | branchno | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceAsAgreeConfigQryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| payeeCusId | payeecusid | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceAsAgreeConfigRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| payeeCusId | payeecusid | U | not fully verified in docs yet | sdk-structure | low |
| shareType | sharetype | U | not fully verified in docs yet | sdk-structure | low |
| amtMax | amtmax | U | not fully verified in docs yet | sdk-structure | low |
| rateMax | ratemax | U | not fully verified in docs yet | sdk-structure | low |
| limitType | limittype | U | not fully verified in docs yet | sdk-structure | low |
| asAgreeUrl | asagreeurl | U | not fully verified in docs yet | sdk-structure | low |
| reason | reason | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceIotDevConfigRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| branchNo | branchno | U | not fully verified in docs yet | sdk-structure | low |
| deviceName | devicename | U | not fully verified in docs yet | sdk-structure | low |
| pidList | pidlist | U | not fully verified in docs yet | sdk-structure | low |
| openFlag | openflag | U | not fully verified in docs yet | sdk-structure | low |
| deviceType | devicetype | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceIotDevQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| branchNo | branchno | U | not fully verified in docs yet | sdk-structure | low |
| deviceName | devicename | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceQueryCouponDetailRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| couponId | couponid | U | not fully verified in docs yet | sdk-structure | low |
| wxOpenId | wxopenid | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceQueryStockDetailRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| stockId | stockid | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceQueryStockRefundFlowRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| stockId | stockid | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceQueryStockUseFlowRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| stockId | stockid | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceSearchCusPackageRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| startTime | starttime | U | not fully verified in docs yet | sdk-structure | low |
| endTime | endtime | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceSendCouponsRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| stockId | stockid | U | not fully verified in docs yet | sdk-structure | low |
| openId | openid | U | not fully verified in docs yet | sdk-structure | low |
| mchAppId | mchappid | U | not fully verified in docs yet | sdk-structure | low |
| couponValue | couponvalue | U | not fully verified in docs yet | sdk-structure | low |
| couponMinimum | couponminimum | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceUploadElectTicketRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxId | trxid | U | not fully verified in docs yet | sdk-structure | low |
| chnlTrxId | chnltrxid | U | not fully verified in docs yet | sdk-structure | low |
| cmId | cmid | U | not fully verified in docs yet | sdk-structure | low |
| openId | openid | U | not fully verified in docs yet | sdk-structure | low |
| merChantContacts | merchantcontacts | U | not fully verified in docs yet | sdk-structure | low |
| file | - | U | not fully verified in docs yet | sdk-structure | low |

## SybServiceWxCateringOrderSyncStatusRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| subAppId | sub_appid | U | not fully verified in docs yet | sdk-structure | low |
| outShopNo | outshopno | U | not fully verified in docs yet | sdk-structure | low |
| subOpenId | subopenid | U | not fully verified in docs yet | sdk-structure | low |
| loginToken | logintoken | U | not fully verified in docs yet | sdk-structure | low |
| orderEntry | orderentry | U | not fully verified in docs yet | sdk-structure | low |
| totalAmount | totalamount | U | not fully verified in docs yet | sdk-structure | low |
| discountAmount | discountamount | U | not fully verified in docs yet | sdk-structure | low |
| userAmount | useramount | U | not fully verified in docs yet | sdk-structure | low |
| status | status | U | not fully verified in docs yet | sdk-structure | low |
| actionTime | actiontime | U | not fully verified in docs yet | sdk-structure | low |
| payTime | paytime | U | not fully verified in docs yet | sdk-structure | low |
| chnlTrxId | chnltrxid | U | not fully verified in docs yet | sdk-structure | low |
| trxId | trxid | U | not fully verified in docs yet | sdk-structure | low |
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| dishList | dishlist | U | not fully verified in docs yet | sdk-structure | low |
| outTableNo | outtableno | U | not fully verified in docs yet | sdk-structure | low |
| peopleCount | peoplecount | U | not fully verified in docs yet | sdk-structure | low |

## TlinvoiceCancleInvoiceRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| applyId | applyid | U | not fully verified in docs yet | sdk-structure | low |

## TlinvoiceGenerateInviteQRRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## TlinvoiceGenerateInvoiceQRRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| amt | amt | U | not fully verified in docs yet | sdk-structure | low |
| faPiaoBillType | fapiaobilltype | U | not fully verified in docs yet | sdk-structure | low |
| prodCode | prodcode | U | not fully verified in docs yet | sdk-structure | low |
| goodsName | goodsname | U | not fully verified in docs yet | sdk-structure | low |
| quantity | quantity | U | not fully verified in docs yet | sdk-structure | low |
| policyCode | policycode | U | not fully verified in docs yet | sdk-structure | low |
| unit | unit | U | not fully verified in docs yet | sdk-structure | low |
| specification | specification | U | not fully verified in docs yet | sdk-structure | low |
| rate | rate | U | not fully verified in docs yet | sdk-structure | low |
| termNo | termno | U | not fully verified in docs yet | sdk-structure | low |
| notifyUrl | notifyurl | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |

## TlinvoiceGenerateInvoiceQRSimpleRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| amt | amt | U | not fully verified in docs yet | sdk-structure | low |
| prodCode | prodcode | U | not fully verified in docs yet | sdk-structure | low |
| termNo | termno | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |

## TlinvoiceGetInvoiceDownloadUrlRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| applyId | applyid | U | not fully verified in docs yet | sdk-structure | low |

## TlinvoiceGetInvoiceOpenStatusRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## TlinvoiceGetInvoiceProdCodeListRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|

## TlinvoiceGetRecordStatusRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| applyId | applyid | U | not fully verified in docs yet | sdk-structure | low |

## TranxCancelRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | R | cancel core fields | doc257 | high |
| reqSn | reqsn | R | cancel core fields | doc257 | high |
| oldReqSn | oldreqsn | C | one of oldreqsn/oldtrxid | doc257 | high |
| oldTrxId | oldtrxid | C | one of oldreqsn/oldtrxid, oldtrxid preferred | doc257 | high |

## TranxCloseRequset

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| oldReqSn | oldreqsn | U | needs per-api doc verification | project17 | low |
| oldTrxId | oldtrxid | U | needs per-api doc verification | project17 | low |
| isIot | isiot | U | needs per-api doc verification | project17 | low |

## TranxQueryConfirmRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | needs per-api doc verification | project17 | low |
| trxId | trxid | U | needs per-api doc verification | project17 | low |

## TranxQueryOrderRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxDate | trxdate | U | needs per-api doc verification | project17 | low |
| orderId | orderid | U | needs per-api doc verification | project17 | low |
| trxId | trxid | U | needs per-api doc verification | project17 | low |
| termNo | termno | U | needs per-api doc verification | project17 | low |
| resendNotify | resendnotify | U | needs per-api doc verification | project17 | low |

## TranxQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | C | one of reqsn/trxid | project17 | high |
| trxId | trxid | C | one of reqsn/trxid, trxid preferred | project17 | high |

## TranxRefundRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | R | refund core fields | doc258 | high |
| reqSn | reqsn | R | refund core fields | doc258 | high |
| oldReqSn | oldreqsn | C | one of oldreqsn/oldtrxid | doc258 | high |
| oldTrxId | oldtrxid | C | one of oldreqsn/oldtrxid, oldtrxid preferred | doc258 | high |
| remark | remark | O | scenario based optional | doc258 | medium |
| benefitDetail | benefitdetail | O | scenario based optional | doc258 | medium |
| notifyUrl | notify_url | O | scenario based optional | doc258 | medium |

## TrxFileGetRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| date | date | U | not fully verified in docs yet | sdk-structure | low |
| fileType | filetype | U | not fully verified in docs yet | sdk-structure | low |

## TrxFileSettTrxRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| settDate | settdate | U | not fully verified in docs yet | sdk-structure | low |

## TrxShareQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| payerTrxId | payertrxid | U | not fully verified in docs yet | sdk-structure | low |

## TrxShareRevokeQueryRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| rkTrxId | rktrxid | U | not fully verified in docs yet | sdk-structure | low |

## TrxShareRevokeRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| payerTrxId | payertrxid | U | not fully verified in docs yet | sdk-structure | low |
| payerReqSn | payerreqsn | U | not fully verified in docs yet | sdk-structure | low |
| trxAmt | trxamt | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |

## TrxShareShareRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| oldTrxId | oldtrxid | U | not fully verified in docs yet | sdk-structure | low |
| payeeCusId | payeecusid | U | not fully verified in docs yet | sdk-structure | low |
| payeeReqSn | payeereqsn | U | not fully verified in docs yet | sdk-structure | low |
| trxAmt | trxamt | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |

## UnConscsPayAgreeApplyRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| merUserId | meruserid | U | needs per-api doc verification | project31 | low |
| applyId | applyid | U | needs per-api doc verification | project31 | low |
| appType | apptype | U | needs per-api doc verification | project31 | low |
| appName | appname | U | needs per-api doc verification | project31 | low |
| appPath | apppath | U | needs per-api doc verification | project31 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project31 | low |
| planId | planid | U | needs per-api doc verification | project31 | low |

## UnConscsPayAgreePayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| applyId | applyid | U | needs per-api doc verification | project31 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project31 | low |
| reqSn | reqsn | U | needs per-api doc verification | project31 | low |
| subject | subject | U | needs per-api doc verification | project31 | low |
| remark | remark | U | needs per-api doc verification | project31 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project31 | low |
| planId | planid | U | needs per-api doc verification | project31 | low |

## UnConscsPayAgreeUnbindRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| applyId | applyid | U | needs per-api doc verification | project31 | low |

## UnConscsPayAndSignRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | needs per-api doc verification | project31 | low |
| reqSn | reqsn | U | needs per-api doc verification | project31 | low |
| subject | subject | U | needs per-api doc verification | project31 | low |
| remark | remark | U | needs per-api doc verification | project31 | low |
| validTime | validtime | U | needs per-api doc verification | project31 | low |
| appType | apptype | U | needs per-api doc verification | project31 | low |
| appName | appname | U | needs per-api doc verification | project31 | low |
| appPath | apppath | U | needs per-api doc verification | project31 | low |
| merUserId | meruserid | U | needs per-api doc verification | project31 | low |
| applyId | applyid | U | needs per-api doc verification | project31 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project31 | low |
| agreeNotifyUrl | agree_notifyurl | U | needs per-api doc verification | project31 | low |
| planId | planid | U | needs per-api doc verification | project31 | low |

## UnConscsPayTokenApplyRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| merUserId | meruserid | U | needs per-api doc verification | project31 | low |
| merUserRegitDate | meruserregitdate | U | needs per-api doc verification | project31 | low |
| merUserLoginMet | meruserloginmet | U | needs per-api doc verification | project31 | low |
| encryptType | encrypttype | U | needs per-api doc verification | project31 | low |
| acctNo | acctno | U | needs per-api doc verification | project31 | low |
| idNo | idno | U | needs per-api doc verification | project31 | low |
| idType | idtype | U | needs per-api doc verification | project31 | low |
| acctName | acctname | U | needs per-api doc verification | project31 | low |
| mobile | mobile | U | needs per-api doc verification | project31 | low |
| bankCode | bankcode | U | needs per-api doc verification | project31 | low |
| acctType | accttype | U | needs per-api doc verification | project31 | low |
| chnlTrId | chnltrid | U | needs per-api doc verification | project31 | low |
| tokenType | tokentype | U | needs per-api doc verification | project31 | low |
| deviceId | deviceid | U | needs per-api doc verification | project31 | low |
| faceType | facetype | U | needs per-api doc verification | project31 | low |
| faceOrder | faceorder | U | needs per-api doc verification | project31 | low |
| faceApp | faceapp | U | needs per-api doc verification | project31 | low |
| invokeType | invoketype | U | needs per-api doc verification | project31 | low |
| wxAppId | wxappid | U | needs per-api doc verification | project31 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project31 | low |
| retUrl | returl | U | needs per-api doc verification | project31 | low |

## UnConscsPayTokenPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| applyId | applyid | U | needs per-api doc verification | project31 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project31 | low |
| reqSn | reqsn | U | needs per-api doc verification | project31 | low |
| subject | subject | U | needs per-api doc verification | project31 | low |
| remark | remark | U | needs per-api doc verification | project31 | low |
| chnlTrId | chnltrid | U | needs per-api doc verification | project31 | low |
| smsCode | smscode | U | needs per-api doc verification | project31 | low |
| thpInfo | thpinfo | U | needs per-api doc verification | project31 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project31 | low |

## UnConscsPayTokenSetNoverRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| applyId | applyid | U | needs per-api doc verification | project31 | low |
| chnlTrId | chnltrid | U | needs per-api doc verification | project31 | low |
| openType | opentype | U | needs per-api doc verification | project31 | low |

## UnConscsPayTokenSmsRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| agreeId | agreeid | U | needs per-api doc verification | project31 | low |
| chnlTrId | chnltrid | U | needs per-api doc verification | project31 | low |
| reqSn | reqsn | U | needs per-api doc verification | project31 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project31 | low |
| subject | subject | U | needs per-api doc verification | project31 | low |
| remark | remark | U | needs per-api doc verification | project31 | low |

## UnConscsPayTokenUnbindRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| applyId | applyid | U | needs per-api doc verification | project31 | low |
| chnlTrId | chnltrid | U | needs per-api doc verification | project31 | low |

## UnionPayYJHXAuditQryUn

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| orgNo | orgNo | U | not fully verified in docs yet | sdk-structure | low |
| mchntOrderId | mchntOrderId | U | not fully verified in docs yet | sdk-structure | low |
| uploadTime | uploadTime | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXAuditUn

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| orgNo | orgNo | U | not fully verified in docs yet | sdk-structure | low |
| subMchntCd | subMchntCd | U | not fully verified in docs yet | sdk-structure | low |
| subMchntNm | subMchntNm | U | not fully verified in docs yet | sdk-structure | low |
| storeNm | storeNm | U | not fully verified in docs yet | sdk-structure | low |
| onlineNo | onlineNo | U | not fully verified in docs yet | sdk-structure | low |
| mchntOrderId | mchntOrderId | U | not fully verified in docs yet | sdk-structure | low |
| uploadTime | uploadTime | U | not fully verified in docs yet | sdk-structure | low |
| prodId | prodId | U | not fully verified in docs yet | sdk-structure | low |
| engGrade | engGrade | U | not fully verified in docs yet | sdk-structure | low |
| brandNm | brandNm | U | not fully verified in docs yet | sdk-structure | low |
| prodModel | prodModel | U | not fully verified in docs yet | sdk-structure | low |
| salesChnl | salesChnl | U | not fully verified in docs yet | sdk-structure | low |
| platForm | platForm | U | not fully verified in docs yet | sdk-structure | low |
| payerTp | payerTp | U | not fully verified in docs yet | sdk-structure | low |
| tradeInOrderId | tradeInOrderId | U | not fully verified in docs yet | sdk-structure | low |
| tradeInAt | tradeInAt | U | not fully verified in docs yet | sdk-structure | low |
| isTradeIn | isTradeIn | U | not fully verified in docs yet | sdk-structure | low |
| salesAt | salesAt | U | not fully verified in docs yet | sdk-structure | low |
| actualAt | actualAt | U | not fully verified in docs yet | sdk-structure | low |
| transTm | transTm | U | not fully verified in docs yet | sdk-structure | low |
| mchntCd | mchntCd | U | not fully verified in docs yet | sdk-structure | low |
| merSubAt | merSubAt | U | not fully verified in docs yet | sdk-structure | low |
| discountAt | discountAt | U | not fully verified in docs yet | sdk-structure | low |
| image01 | image01 | U | not fully verified in docs yet | sdk-structure | low |
| image02 | image02 | U | not fully verified in docs yet | sdk-structure | low |
| image03 | image03 | U | not fully verified in docs yet | sdk-structure | low |
| image04 | image04 | U | not fully verified in docs yet | sdk-structure | low |
| image05 | image05 | U | not fully verified in docs yet | sdk-structure | low |
| image06 | image06 | U | not fully verified in docs yet | sdk-structure | low |
| image07 | image07 | U | not fully verified in docs yet | sdk-structure | low |
| image08 | image08 | U | not fully verified in docs yet | sdk-structure | low |
| image09 | image09 | U | not fully verified in docs yet | sdk-structure | low |
| image10 | image10 | U | not fully verified in docs yet | sdk-structure | low |
| commitmentLetterPhoto | - | U | not fully verified in docs yet | sdk-structure | low |
| commitmentLetterPhotoFormat | commitmentLetterPhotoFormat | U | not fully verified in docs yet | sdk-structure | low |
| devicePhoto | - | U | not fully verified in docs yet | sdk-structure | low |
| devicePhotoFormat | devicePhotoFormat | U | not fully verified in docs yet | sdk-structure | low |
| packAndActivePhoto | packAndActivePhoto | U | not fully verified in docs yet | sdk-structure | low |
| barCode | barCode | U | not fully verified in docs yet | sdk-structure | low |
| snCode | snCode | U | not fully verified in docs yet | sdk-structure | low |
| imei1 | imei1 | U | not fully verified in docs yet | sdk-structure | low |
| imei2 | imei2 | U | not fully verified in docs yet | sdk-structure | low |
| registerModel | registerModel | U | not fully verified in docs yet | sdk-structure | low |
| recordNumber | recordNumber | U | not fully verified in docs yet | sdk-structure | low |
| engGradeStandard | engGradeStandard | U | not fully verified in docs yet | sdk-structure | low |
| encryptData | encryptData | U | not fully verified in docs yet | sdk-structure | low |
| resv1 | resv1 | U | not fully verified in docs yet | sdk-structure | low |
| resv2 | resv2 | U | not fully verified in docs yet | sdk-structure | low |
| resv3 | resv3 | U | not fully verified in docs yet | sdk-structure | low |
| resv4 | resv4 | U | not fully verified in docs yet | sdk-structure | low |
| resv5 | resv5 | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXAuditUpdateUn

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| orgNo | orgNo | U | not fully verified in docs yet | sdk-structure | low |
| subMchntCd | subMchntCd | U | not fully verified in docs yet | sdk-structure | low |
| subMchntNm | subMchntNm | U | not fully verified in docs yet | sdk-structure | low |
| storeNm | storeNm | U | not fully verified in docs yet | sdk-structure | low |
| onlineNo | onlineNo | U | not fully verified in docs yet | sdk-structure | low |
| mchntOrderId | mchntOrderId | U | not fully verified in docs yet | sdk-structure | low |
| uploadTime | uploadTime | U | not fully verified in docs yet | sdk-structure | low |
| prodId | prodId | U | not fully verified in docs yet | sdk-structure | low |
| engGrade | engGrade | U | not fully verified in docs yet | sdk-structure | low |
| brandNm | brandNm | U | not fully verified in docs yet | sdk-structure | low |
| prodModel | prodModel | U | not fully verified in docs yet | sdk-structure | low |
| salesChnl | salesChnl | U | not fully verified in docs yet | sdk-structure | low |
| platForm | platForm | U | not fully verified in docs yet | sdk-structure | low |
| payerTp | payerTp | U | not fully verified in docs yet | sdk-structure | low |
| tradeInOrderId | tradeInOrderId | U | not fully verified in docs yet | sdk-structure | low |
| tradeInAt | tradeInAt | U | not fully verified in docs yet | sdk-structure | low |
| isTradeIn | isTradeIn | U | not fully verified in docs yet | sdk-structure | low |
| salesAt | salesAt | U | not fully verified in docs yet | sdk-structure | low |
| actualAt | actualAt | U | not fully verified in docs yet | sdk-structure | low |
| transTm | transTm | U | not fully verified in docs yet | sdk-structure | low |
| mchntCd | mchntCd | U | not fully verified in docs yet | sdk-structure | low |
| merSubAt | merSubAt | U | not fully verified in docs yet | sdk-structure | low |
| discountAt | discountAt | U | not fully verified in docs yet | sdk-structure | low |
| image01 | image01 | U | not fully verified in docs yet | sdk-structure | low |
| image02 | image02 | U | not fully verified in docs yet | sdk-structure | low |
| image03 | image03 | U | not fully verified in docs yet | sdk-structure | low |
| image04 | image04 | U | not fully verified in docs yet | sdk-structure | low |
| image05 | image05 | U | not fully verified in docs yet | sdk-structure | low |
| image06 | image06 | U | not fully verified in docs yet | sdk-structure | low |
| image07 | image07 | U | not fully verified in docs yet | sdk-structure | low |
| image08 | image08 | U | not fully verified in docs yet | sdk-structure | low |
| image09 | image09 | U | not fully verified in docs yet | sdk-structure | low |
| image10 | image10 | U | not fully verified in docs yet | sdk-structure | low |
| commitmentLetterPhoto | - | U | not fully verified in docs yet | sdk-structure | low |
| commitmentLetterPhotoFormat | commitmentLetterPhotoFormat | U | not fully verified in docs yet | sdk-structure | low |
| devicePhoto | - | U | not fully verified in docs yet | sdk-structure | low |
| devicePhotoFormat | devicePhotoFormat | U | not fully verified in docs yet | sdk-structure | low |
| packAndActivePhoto | packAndActivePhoto | U | not fully verified in docs yet | sdk-structure | low |
| barCode | barCode | U | not fully verified in docs yet | sdk-structure | low |
| snCode | snCode | U | not fully verified in docs yet | sdk-structure | low |
| imei1 | imei1 | U | not fully verified in docs yet | sdk-structure | low |
| imei2 | imei2 | U | not fully verified in docs yet | sdk-structure | low |
| registerModel | registerModel | U | not fully verified in docs yet | sdk-structure | low |
| recordNumber | recordNumber | U | not fully verified in docs yet | sdk-structure | low |
| engGradeStandard | engGradeStandard | U | not fully verified in docs yet | sdk-structure | low |
| encryptData | encryptData | U | not fully verified in docs yet | sdk-structure | low |
| resv1 | resv1 | U | not fully verified in docs yet | sdk-structure | low |
| resv2 | resv2 | U | not fully verified in docs yet | sdk-structure | low |
| resv3 | resv3 | U | not fully verified in docs yet | sdk-structure | low |
| resv4 | resv4 | U | not fully verified in docs yet | sdk-structure | low |
| resv5 | resv5 | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXClearanceUn

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| txnTime | txnTime | U | not fully verified in docs yet | sdk-structure | low |
| coupIssueId | coupIssueId | U | not fully verified in docs yet | sdk-structure | low |
| regionCd | regionCd | U | not fully verified in docs yet | sdk-structure | low |
| encryptData | encryptData | U | not fully verified in docs yet | sdk-structure | low |
| cateCode | cateCode | U | not fully verified in docs yet | sdk-structure | low |
| txnAmt | txnAmt | U | not fully verified in docs yet | sdk-structure | low |
| discountAmt | discountAmt | U | not fully verified in docs yet | sdk-structure | low |
| transTm | transTm | U | not fully verified in docs yet | sdk-structure | low |
| couponCd | couponCd | U | not fully verified in docs yet | sdk-structure | low |
| actId | actId | U | not fully verified in docs yet | sdk-structure | low |
| operTp | operTp | U | not fully verified in docs yet | sdk-structure | low |
| mchntCd | mchntCd | U | not fully verified in docs yet | sdk-structure | low |
| mchntCnNm | mchntCnNm | U | not fully verified in docs yet | sdk-structure | low |
| mchntResv | mchntResv | U | not fully verified in docs yet | sdk-structure | low |
| reqReserved | reqReserved | U | not fully verified in docs yet | sdk-structure | low |
| recvRegionCd | recvRegionCd | U | not fully verified in docs yet | sdk-structure | low |
| saleModels | saleModels | U | not fully verified in docs yet | sdk-structure | low |
| corpCnNm | corpCnNm | U | not fully verified in docs yet | sdk-structure | low |
| uniscId | uniscId | U | not fully verified in docs yet | sdk-structure | low |
| pickUp | pickUp | U | not fully verified in docs yet | sdk-structure | low |
| barCode | barCode | U | not fully verified in docs yet | sdk-structure | low |
| itemName | itemName | U | not fully verified in docs yet | sdk-structure | low |
| brandNm | brandNm | U | not fully verified in docs yet | sdk-structure | low |
| specModel | specModel | U | not fully verified in docs yet | sdk-structure | low |
| engGrade | engGrade | U | not fully verified in docs yet | sdk-structure | low |
| snCode | snCode | U | not fully verified in docs yet | sdk-structure | low |
| imei1 | imei1 | U | not fully verified in docs yet | sdk-structure | low |
| imei2 | imei2 | U | not fully verified in docs yet | sdk-structure | low |
| logisticsNo | logisticsNo | U | not fully verified in docs yet | sdk-structure | low |
| deliveryTime | deliveryTime | U | not fully verified in docs yet | sdk-structure | low |
| invoiceNo | invoiceNo | U | not fully verified in docs yet | sdk-structure | low |
| isAIProduct | isAIProduct | U | not fully verified in docs yet | sdk-structure | low |
| serialNum | serialNum | U | not fully verified in docs yet | sdk-structure | low |
| pcType | pcType | U | not fully verified in docs yet | sdk-structure | low |
| channel | channel | U | not fully verified in docs yet | sdk-structure | low |
| mchntOrderId | mchntOrderId | U | not fully verified in docs yet | sdk-structure | low |
| acqInsNm | acqInsNm | U | not fully verified in docs yet | sdk-structure | low |
| payOrderId | payOrderId | U | not fully verified in docs yet | sdk-structure | low |
| oldThings | oldThings | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXCmnRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| actionType | actionType | U | not fully verified in docs yet | sdk-structure | low |
| trxChnl | trxChnl | U | not fully verified in docs yet | sdk-structure | low |
| bizContent | bizContent | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXCoupCancel

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| txnTime | txnTime | U | not fully verified in docs yet | sdk-structure | low |
| coupIssueId | coupIssueId | U | not fully verified in docs yet | sdk-structure | low |
| regionCd | regionCd | U | not fully verified in docs yet | sdk-structure | low |
| encryptData | encryptData | U | not fully verified in docs yet | sdk-structure | low |
| scene | scene | U | not fully verified in docs yet | sdk-structure | low |
| cateCode | cateCode | U | not fully verified in docs yet | sdk-structure | low |
| gps | gps | U | not fully verified in docs yet | sdk-structure | low |
| reqReserved | reqReserved | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXCoupCheck

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| txnTime | txnTime | U | not fully verified in docs yet | sdk-structure | low |
| coupIssueId | coupIssueId | U | not fully verified in docs yet | sdk-structure | low |
| regionCd | regionCd | U | not fully verified in docs yet | sdk-structure | low |
| encryptData | encryptData | U | not fully verified in docs yet | sdk-structure | low |
| scene | scene | U | not fully verified in docs yet | sdk-structure | low |
| reqReserved | reqReserved | U | not fully verified in docs yet | sdk-structure | low |
| isRealName | isRealName | U | not fully verified in docs yet | sdk-structure | low |
| isRealFace | isRealFace | U | not fully verified in docs yet | sdk-structure | low |
| isExpire | isExpire | U | not fully verified in docs yet | sdk-structure | low |
| isCancel | isCancel | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXCoupReceive

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| txnTime | txnTime | U | not fully verified in docs yet | sdk-structure | low |
| coupIssueId | coupIssueId | U | not fully verified in docs yet | sdk-structure | low |
| regionCd | regionCd | U | not fully verified in docs yet | sdk-structure | low |
| encryptData | encryptData | U | not fully verified in docs yet | sdk-structure | low |
| scene | scene | U | not fully verified in docs yet | sdk-structure | low |
| cateCode | cateCode | U | not fully verified in docs yet | sdk-structure | low |
| model | model | U | not fully verified in docs yet | sdk-structure | low |
| engGrade | engGrade | U | not fully verified in docs yet | sdk-structure | low |
| isRealName | isRealName | U | not fully verified in docs yet | sdk-structure | low |
| isRealFace | isRealFace | U | not fully verified in docs yet | sdk-structure | low |
| isExpire | isExpire | U | not fully verified in docs yet | sdk-structure | low |
| isCancel | isCancel | U | not fully verified in docs yet | sdk-structure | low |
| gps | gps | U | not fully verified in docs yet | sdk-structure | low |
| reqReserved | reqReserved | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXCoupRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| actionType | actionType | U | not fully verified in docs yet | sdk-structure | low |
| trxChnl | trxChnl | U | not fully verified in docs yet | sdk-structure | low |
| bizContent | bizContent | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXSnOccupancyUn

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| txnTime | txnTime | U | not fully verified in docs yet | sdk-structure | low |
| orderId | orderId | U | not fully verified in docs yet | sdk-structure | low |
| regionCd | regionCd | U | not fully verified in docs yet | sdk-structure | low |
| mchntCd | mchntCd | U | not fully verified in docs yet | sdk-structure | low |
| postTmn | postTmn | U | not fully verified in docs yet | sdk-structure | low |
| barcode | barcode | U | not fully verified in docs yet | sdk-structure | low |
| snCode | snCode | U | not fully verified in docs yet | sdk-structure | low |
| reqReserved | reqReserved | U | not fully verified in docs yet | sdk-structure | low |
| imei1 | imei1 | U | not fully verified in docs yet | sdk-structure | low |
| imei2 | imei2 | U | not fully verified in docs yet | sdk-structure | low |
| mfrInfo | mfrInfo | U | not fully verified in docs yet | sdk-structure | low |
| brand | brand | U | not fully verified in docs yet | sdk-structure | low |
| cateCode | cateCode | U | not fully verified in docs yet | sdk-structure | low |
| isAiProd | isAiProd | U | not fully verified in docs yet | sdk-structure | low |
| specModel | specModel | U | not fully verified in docs yet | sdk-structure | low |
| saleTm | saleTm | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXSnQueryUn

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| regionCd | regionCd | U | not fully verified in docs yet | sdk-structure | low |
| snCode | snCode | U | not fully verified in docs yet | sdk-structure | low |
| reqReserved | reqReserved | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXTransSyncUn

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| txnTime | txnTime | U | not fully verified in docs yet | sdk-structure | low |
| coupIssueId | coupIssueId | U | not fully verified in docs yet | sdk-structure | low |
| regionCd | regionCd | U | not fully verified in docs yet | sdk-structure | low |
| encryptData | encryptData | U | not fully verified in docs yet | sdk-structure | low |
| cateCode | cateCode | U | not fully verified in docs yet | sdk-structure | low |
| txnAmt | txnAmt | U | not fully verified in docs yet | sdk-structure | low |
| discountAmt | discountAmt | U | not fully verified in docs yet | sdk-structure | low |
| transTm | transTm | U | not fully verified in docs yet | sdk-structure | low |
| couponCd | couponCd | U | not fully verified in docs yet | sdk-structure | low |
| actId | actId | U | not fully verified in docs yet | sdk-structure | low |
| operTp | operTp | U | not fully verified in docs yet | sdk-structure | low |
| mchntCd | mchntCd | U | not fully verified in docs yet | sdk-structure | low |
| mchntCnNm | mchntCnNm | U | not fully verified in docs yet | sdk-structure | low |
| mchntResv | mchntResv | U | not fully verified in docs yet | sdk-structure | low |
| reqReserved | reqReserved | U | not fully verified in docs yet | sdk-structure | low |
| recvRegionCd | recvRegionCd | U | not fully verified in docs yet | sdk-structure | low |
| saleModels | saleModels | U | not fully verified in docs yet | sdk-structure | low |
| corpCnNm | corpCnNm | U | not fully verified in docs yet | sdk-structure | low |
| uniscId | uniscId | U | not fully verified in docs yet | sdk-structure | low |
| brandNm | brandNm | U | not fully verified in docs yet | sdk-structure | low |
| engGrade | engGrade | U | not fully verified in docs yet | sdk-structure | low |
| serialNum | serialNum | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXVoAuditEncryptData

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| invoiceInfo | invoiceInfo | U | not fully verified in docs yet | sdk-structure | low |
| trackInfo | trackInfo | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXVoBiz

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXVoInvoiceInfo

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| id | id | U | not fully verified in docs yet | sdk-structure | low |
| invoiceTp | invoiceTp | U | not fully verified in docs yet | sdk-structure | low |
| invoiceCd | invoiceCd | U | not fully verified in docs yet | sdk-structure | low |
| invoiceNo | invoiceNo | U | not fully verified in docs yet | sdk-structure | low |
| invoiceDt | invoiceDt | U | not fully verified in docs yet | sdk-structure | low |
| invoiceLink | invoiceLink | U | not fully verified in docs yet | sdk-structure | low |
| invoiceCkCd | invoiceCkCd | U | not fully verified in docs yet | sdk-structure | low |
| nm | nm | U | not fully verified in docs yet | sdk-structure | low |
| tax | tax | U | not fully verified in docs yet | sdk-structure | low |
| invoiceTaxAmt | invoiceTaxAmt | U | not fully verified in docs yet | sdk-structure | low |
| salesEntNm | salesEntNm | U | not fully verified in docs yet | sdk-structure | low |
| taxPayer | taxPayer | U | not fully verified in docs yet | sdk-structure | low |
| num | num | U | not fully verified in docs yet | sdk-structure | low |
| serviceNm | serviceNm | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXVoTrackInfo

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| trackingNo | trackingNo | U | not fully verified in docs yet | sdk-structure | low |
| trackingCompany | trackingCompany | U | not fully verified in docs yet | sdk-structure | low |
| usrProv | usrProv | U | not fully verified in docs yet | sdk-structure | low |
| usrCity | usrCity | U | not fully verified in docs yet | sdk-structure | low |
| usrArea | usrArea | U | not fully verified in docs yet | sdk-structure | low |
| usrAddr | usrAddr | U | not fully verified in docs yet | sdk-structure | low |
| trackingType | trackingType | U | not fully verified in docs yet | sdk-structure | low |
| deliveryMethod | deliveryMethod | U | not fully verified in docs yet | sdk-structure | low |
| shippingAddr | shippingAddr | U | not fully verified in docs yet | sdk-structure | low |
| deliveryTime | deliveryTime | U | not fully verified in docs yet | sdk-structure | low |

## UnionPayYJHXVoUserEncryptData

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| certifTp | certifTp | U | not fully verified in docs yet | sdk-structure | low |
| certifId | certifId | U | not fully verified in docs yet | sdk-structure | low |
| customerNm | customerNm | U | not fully verified in docs yet | sdk-structure | low |
| usrId | usrId | U | not fully verified in docs yet | sdk-structure | low |
| phoneNo | phoneNo | U | not fully verified in docs yet | sdk-structure | low |
| addr | addr | U | not fully verified in docs yet | sdk-structure | low |

## UnitOrderAuthCode2UserIdRequset

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| authCode | authcode | U | needs per-api doc verification | project17 | low |
| authType | authtype | U | needs per-api doc verification | project17 | low |
| identify | identify | U | needs per-api doc verification | project17 | low |
| subAppid | sub_appid | U | needs per-api doc verification | project17 | low |

## UnitOrderCloseNativeRequset

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| oldReqSn | oldreqsn | U | needs per-api doc verification | project17 | low |
| oldTrxId | oldtrxid | U | needs per-api doc verification | project17 | low |

## UnitOrderCreateZhiRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| reqSn | reqsn | U | needs per-api doc verification | project17 | low |
| bizLink | bizlink | U | needs per-api doc verification | project17 | low |
| trxAmt | trxamt | U | needs per-api doc verification | project17 | low |
| validTime | validtime | U | needs per-api doc verification | project17 | low |
| title | title | U | needs per-api doc verification | project17 | low |
| zhiType | zhitype | U | needs per-api doc verification | project17 | low |

## UnitOrderNativePayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | needs per-api doc verification | project17 | low |
| reqSn | reqsn | U | needs per-api doc verification | project17 | low |
| body | body | U | needs per-api doc verification | project17 | low |
| remark | remark | U | needs per-api doc verification | project17 | low |
| expireTime | expiretime | U | needs per-api doc verification | project17 | low |
| subBranch | subbranch | U | needs per-api doc verification | project17 | low |
| limitPay | limit_pay | U | needs per-api doc verification | project17 | low |
| idNo | idno | U | needs per-api doc verification | project17 | low |
| trueName | truename | U | needs per-api doc verification | project17 | low |
| asInfo | asinfo | U | needs per-api doc verification | project17 | low |
| goodsTag | goods_tag | U | needs per-api doc verification | project17 | low |
| benefitDetail | benefitdetail | U | needs per-api doc verification | project17 | low |
| chnlStoreId | chnlstoreid | U | needs per-api doc verification | project17 | low |
| fqNum | fqnum | U | needs per-api doc verification | project17 | low |
| extendParams | extendparams | U | needs per-api doc verification | project17 | low |
| notifyUrl | notify_url | U | needs per-api doc verification | project17 | low |
| frontUrl | front_url | U | needs per-api doc verification | project17 | low |

## UnitOrderPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | R | amount in fen | doc256 | high |
| reqSn | reqsn | C | one of reqsn/unireqsn | doc256 | high |
| uniReqSn | unireqsn | C | one of reqsn/unireqsn | doc256 | high |
| payType | paytype | R | payment channel | doc256 | high |
| body | body | O | scenario based optional | doc256 | medium |
| remark | remark | O | scenario based optional | doc256 | medium |
| validTime | validtime | O | scenario based optional | doc256 | medium |
| expireTime | expiretime | O | scenario based optional | doc256 | medium |
| acct | acct | C | required in js/miniapp scenarios | doc256 | medium |
| notifyUrl | notify_url | C | strongly required for async | doc256 | high |
| limitPay | limit_pay | O | scenario based optional | doc256 | medium |
| subAppid | sub_appid | C | required in wechat app/order scenarios | doc256 | medium |
| goodsTag | goods_tag | O | scenario based optional | doc256 | medium |
| benefitDetail | benefitdetail | O | scenario based optional | doc256 | medium |
| chnlStoreId | chnlstoreid | O | scenario based optional | doc256 | medium |
| subBranch | subbranch | O | scenario based optional | doc256 | medium |
| extendParams | extendparams | O | scenario based optional | doc256 | medium |
| cusIp | cusip | C | required when paytype=U02 | doc256 | high |
| frontUrl | front_url | O | scenario based optional | doc256 | medium |
| idNo | idno | O | scenario based optional | doc256 | medium |
| trueName | truename | O | scenario based optional | doc256 | medium |
| asInfo | asinfo | O | scenario based optional | doc256 | medium |
| fqNum | fqnum | O | scenario based optional | doc256 | medium |
| unPid | unpid | O | scenario based optional | doc256 | medium |
| finOrg | finorg | O | scenario based optional | doc256 | medium |
| operatorId | operatorid | O | scenario based optional | doc256 | medium |
| iscofee | iscofee | O | scenario based optional | doc256 | medium |

## UnitOrderScanQrPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | R | scan pay core fields | project17 | high |
| reqSn | reqsn | R | scan pay core fields | project17 | high |
| body | body | O | scenario based optional | project17 | medium |
| remark | remark | O | scenario based optional | project17 | medium |
| authCode | authcode | R | scan pay core fields | project17 | high |
| limitPay | limit_pay | O | scenario based optional | project17 | medium |
| goodsTag | goods_tag | O | scenario based optional | project17 | medium |
| benefitDetail | benefitdetail | O | scenario based optional | project17 | medium |
| subAppid | sub_appid | O | scenario based optional | project17 | medium |
| chnlStoreId | chnlstoreid | O | scenario based optional | project17 | medium |
| subBranch | subbranch | O | scenario based optional | project17 | medium |
| idNo | idno | O | scenario based optional | project17 | medium |
| extendParams | extendparams | O | scenario based optional | project17 | medium |
| trueName | truename | O | scenario based optional | project17 | medium |
| asInfo | asinfo | O | scenario based optional | project17 | medium |
| fqNum | fqnum | O | scenario based optional | project17 | medium |
| notifyUrl | notify_url | O | scenario based optional | project17 | medium |
| unPid | unpid | O | scenario based optional | project17 | medium |
| termInfo | terminfo | O | scenario based optional | project17 | medium |
| operatorId | operatorid | O | scenario based optional | project17 | medium |

## UnitOrderWxFacePayInfoRequset

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| storeId | storeid | U | needs per-api doc verification | project17 | low |
| storeName | storename | U | needs per-api doc verification | project17 | low |
| deviceId | deviceid | U | needs per-api doc verification | project17 | low |
| attach | attach | U | needs per-api doc verification | project17 | low |
| rawData | rawdata | U | needs per-api doc verification | project17 | low |
| subAppId | subappid | U | needs per-api doc verification | project17 | low |

## UnYwPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | not fully verified in docs yet | sdk-structure | low |
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| body | body | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |
| expireTime | expiretime | U | not fully verified in docs yet | sdk-structure | low |
| appName | appname | U | not fully verified in docs yet | sdk-structure | low |
| limitPay | limit_pay | U | not fully verified in docs yet | sdk-structure | low |
| notifyUrl | notify_url | U | not fully verified in docs yet | sdk-structure | low |
| appType | apptype | U | not fully verified in docs yet | sdk-structure | low |
| cusIp | cusip | U | not fully verified in docs yet | sdk-structure | low |
| asInfo | asinfo | U | not fully verified in docs yet | sdk-structure | low |
| idNo | idno | U | not fully verified in docs yet | sdk-structure | low |
| trueName | truename | U | not fully verified in docs yet | sdk-structure | low |
| encryptType | encrypttype | U | not fully verified in docs yet | sdk-structure | low |
| extendParams | extendparams | U | not fully verified in docs yet | sdk-structure | low |

## UserTransCusPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| c | c | U | not fully verified in docs yet | sdk-structure | low |
| oid | oid | U | not fully verified in docs yet | sdk-structure | low |
| uniReqSn | unireqsn | U | not fully verified in docs yet | sdk-structure | low |
| amt | amt | U | not fully verified in docs yet | sdk-structure | low |
| retUrl | returl | U | not fully verified in docs yet | sdk-structure | low |
| trxReserve | trxreserve | U | not fully verified in docs yet | sdk-structure | low |
| submitTime | submittime | U | not fully verified in docs yet | sdk-structure | low |
| extendParams | extendparams | U | not fully verified in docs yet | sdk-structure | low |
| asInfo | asinfo | U | not fully verified in docs yet | sdk-structure | low |

## WxOpenGetOpenIdRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| appType | apptype | U | not fully verified in docs yet | sdk-structure | low |
| redirectUrl | redirecturl | U | not fully verified in docs yet | sdk-structure | low |
| state | state | U | not fully verified in docs yet | sdk-structure | low |

## ZhimaCreditMiniOrderRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| tranCode | trancode | U | not fully verified in docs yet | sdk-structure | low |
| serviceId | serviceid | U | not fully verified in docs yet | sdk-structure | low |
| bizData | bizdata | U | not fully verified in docs yet | sdk-structure | low |
| id | id | U | not fully verified in docs yet | sdk-structure | low |

## ZhimaCreditPayRequest

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| trxAmt | trxamt | U | not fully verified in docs yet | sdk-structure | low |
| reqSn | reqsn | U | not fully verified in docs yet | sdk-structure | low |
| body | body | U | not fully verified in docs yet | sdk-structure | low |
| remark | remark | U | not fully verified in docs yet | sdk-structure | low |
| asInfo | asinfo | U | not fully verified in docs yet | sdk-structure | low |
| extendParams | extendparams | U | not fully verified in docs yet | sdk-structure | low |
| termInfo | terminfo | U | not fully verified in docs yet | sdk-structure | low |
| validTime | validtime | U | not fully verified in docs yet | sdk-structure | low |

## ZhimaCreditTCMiniOrderChanged

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| outOrderId | out_order_id | U | not fully verified in docs yet | sdk-structure | low |
| orderId | order_id | U | not fully verified in docs yet | sdk-structure | low |
| tradeNo | trade_no | U | not fully verified in docs yet | sdk-structure | low |
| status | status | U | not fully verified in docs yet | sdk-structure | low |
| operateAppId | operate_app_id | U | not fully verified in docs yet | sdk-structure | low |
| authAppId | auth_app_id | U | not fully verified in docs yet | sdk-structure | low |
| totalAmount | total_amount | U | not fully verified in docs yet | sdk-structure | low |
| receiptAmount | receipt_amount | U | not fully verified in docs yet | sdk-structure | low |
| secureReason | secure_reason | U | not fully verified in docs yet | sdk-structure | low |
| groupBuyInfo | group_buy_info | U | not fully verified in docs yet | sdk-structure | low |
| userId | user_id | U | not fully verified in docs yet | sdk-structure | low |
| openId | open_id | U | not fully verified in docs yet | sdk-structure | low |
| settleType | settle_type | U | not fully verified in docs yet | sdk-structure | low |
| voucherDetailList | voucher_detail_list | U | not fully verified in docs yet | sdk-structure | low |

## ZhimaCreditTCMiniOrderClose

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| outOrderId | out_order_id | U | not fully verified in docs yet | sdk-structure | low |
| orderId | order_id | U | not fully verified in docs yet | sdk-structure | low |
| userId | user_id | U | not fully verified in docs yet | sdk-structure | low |
| openId | open_id | U | not fully verified in docs yet | sdk-structure | low |

## ZhimaCreditTCMiniOrderCreate

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| outOrderId | out_order_id | U | not fully verified in docs yet | sdk-structure | low |
| title | title | U | not fully verified in docs yet | sdk-structure | low |
| sourceId | source_id | U | not fully verified in docs yet | sdk-structure | low |
| merchantBizType | merchant_biz_type | U | not fully verified in docs yet | sdk-structure | low |
| path | path | U | not fully verified in docs yet | sdk-structure | low |
| orderDetail | order_detail | U | not fully verified in docs yet | sdk-structure | low |
| sellerId | seller_id | U | not fully verified in docs yet | sdk-structure | low |
| buyerId | buyer_id | U | not fully verified in docs yet | sdk-structure | low |
| buyerOpenId | buyer_open_id | U | not fully verified in docs yet | sdk-structure | low |
| buyerLogonId | buyer_logon_id | U | not fully verified in docs yet | sdk-structure | low |
| shopInfo | shop_info | U | not fully verified in docs yet | sdk-structure | low |
| creditInfo | credit_info | U | not fully verified in docs yet | sdk-structure | low |
| stagePayPlans | stage_pay_plans | U | not fully verified in docs yet | sdk-structure | low |
| contactInfo | contact_info | U | not fully verified in docs yet | sdk-structure | low |
| addressInfo | address_info | U | not fully verified in docs yet | sdk-structure | low |
| promoDetaiInfo | promo_detai_info | U | not fully verified in docs yet | sdk-structure | low |
| extInfo | ext_info | U | not fully verified in docs yet | sdk-structure | low |
| deliveryDetail | delivery_detail | U | not fully verified in docs yet | sdk-structure | low |
| defaultReceivingAddress | default_receiving_address | U | not fully verified in docs yet | sdk-structure | low |

## ZhimaCreditTCMiniOrderCreditAgreeChanged

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| creditAgreementId | credit_agreement_id | U | not fully verified in docs yet | sdk-structure | low |
| title | title | U | not fully verified in docs yet | sdk-structure | low |
| agreementStatus | agreement_status | U | not fully verified in docs yet | sdk-structure | low |
| outAgreementNo | out_agreement_no | U | not fully verified in docs yet | sdk-structure | low |
| bizTime | biz_time | U | not fully verified in docs yet | sdk-structure | low |
| openChannel | open_channel | U | not fully verified in docs yet | sdk-structure | low |
| alipayUserId | alipay_user_id | U | not fully verified in docs yet | sdk-structure | low |
| openId | open_id | U | not fully verified in docs yet | sdk-structure | low |
| extInfo | ext_info | U | not fully verified in docs yet | sdk-structure | low |

## ZhimaCreditTCMiniOrderCreditAgreeQuery

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| outAgreementNo | out_agreement_no | U | not fully verified in docs yet | sdk-structure | low |
| creditAgreementId | credit_agreement_id | U | not fully verified in docs yet | sdk-structure | low |

## ZhimaCreditTCMiniOrderInstallmentCreate

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| outInstallmentOrderId | out_installment_order_id | U | not fully verified in docs yet | sdk-structure | low |
| type | type | U | not fully verified in docs yet | sdk-structure | low |
| orderId | order_id | U | not fully verified in docs yet | sdk-structure | low |
| outOrderId | out_order_id | U | not fully verified in docs yet | sdk-structure | low |
| userId | user_id | U | not fully verified in docs yet | sdk-structure | low |
| openId | open_id | U | not fully verified in docs yet | sdk-structure | low |
| installmentPrice | installment_price | U | not fully verified in docs yet | sdk-structure | low |
| installmentNo | installment_no | U | not fully verified in docs yet | sdk-structure | low |
| tradeNo | trade_no | U | not fully verified in docs yet | sdk-structure | low |
| isFinishPerformance | is_finish_performance | U | not fully verified in docs yet | sdk-structure | low |
| payChannel | pay_channel | U | not fully verified in docs yet | sdk-structure | low |
| stageNo | stage_no | U | not fully verified in docs yet | sdk-structure | low |
| isSyncPay | is_sync_pay | U | not fully verified in docs yet | sdk-structure | low |

## ZhimaCreditTCMiniOrderQuery

| Field | JSON Name | Level | Condition | Source | Confidence |
|---|---|---|---|---|---|
| serialVersionUID | - | U | not fully verified in docs yet | sdk-structure | low |
| outOrderId | out_order_id | U | not fully verified in docs yet | sdk-structure | low |
| orderId | order_id | U | not fully verified in docs yet | sdk-structure | low |
| userId | user_id | U | not fully verified in docs yet | sdk-structure | low |
| openId | open_id | U | not fully verified in docs yet | sdk-structure | low |


