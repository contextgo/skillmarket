# 工程落地协议（Java + Maven，通用版）

本文件用于“你控制不了 Agent 载体”的场景：Skill 只输出规范与工单，任何具备文件写入/命令执行能力的 Agent 都能按此落地。

## 1) 你只需要提供的信息（最少）

- 目标目录：`projectDir`（可选；不提供则默认当前工作区根目录）
- 你要的业务：例如“聚分期支付 demo”“退款 demo”“异步通知验签 demo”

## 2) 必须产出的两段内容（Skill 输出要求）

## 2.1 先判断：用户要不要“落地到工程”

常见两类意图：

- **仅查看代码**（不落地）：例如“给个示例/我先看看代码怎么写/不要改工程/不用引依赖”
- **需要落地**：例如“生成到某目录/帮我补 pom 引 SDK/创建新工程并能编译运行”

若用户是“仅查看代码”，则输出同样的两段内容，但：

- 步骤清单只写一句：**“本次仅展示代码，不对工程做任何修改。”**
- JSON 工单的 `intent` 使用 `show_code_only`，并令 `changes=[]`、`validation=[]`

### 高准确率判定规则（推荐直接照抄到对话/FAQ）

目标：**宁可不落地，也不要误判去改工程**。

#### 强制“仅查看代码”（高置信）

用户出现任一表述，即判为仅查看代码：

- `不落地/不要落地/不用落地`
- `不改工程/不要改工程/不修改工程`
- `不写文件/不要写文件/别写文件`
- `不用引依赖/不要引依赖`
- `不用创建工程/不要创建工程`
- `只看代码/看看代码/只要代码/示例代码/参考代码`

#### 强制“需要落地到工程”（高置信）

用户出现任一表述，即判为需要落地：

- `生成到工程/写到工程/落到工程/放到项目里/放到工程里`
- `生成到目录/写到目录/落地到目录`
- `帮我加依赖/补依赖/改pom/改pom.xml/pom.xml/maven`
- `新建工程/创建工程/能编译/可编译/能运行/可运行/跑起来`

#### 冲突消歧（最常见误判点）

- 同时出现“只看代码”和“要落地”时：**优先仅查看代码**（防误改）。  
- 仅提供路径/目录 **不等于** 要落地；必须出现“生成到/写到/落地到”才算要落地。  

### 典型话术示例（保证命中）

**仅查看代码（不会改工程）**

- “我只想看看代码示例，不要改工程。给我聚分期支付 Java demo（Maven 依赖也写出来）。”
- “先给示例代码，别写文件、不用创建工程、不用引依赖。”

**需要落地到工程（会改工程/写文件）**

- “把聚分期支付 demo 落地到 `D:\\work\\syb-demo`，没有 Maven 工程就创建，并补齐 pom 依赖。”
- “在我这个 Maven 项目里生成 demo 类并能 `mvn package` 通过。”

### A) 工程落地步骤（人类可读）

1. 目标目录：`<projectDir>`  
2. 检查 `<projectDir>/pom.xml` 是否存在  
3. 不存在：创建最小 Maven 工程（`pom.xml` + `src/main/java`）  
4. 存在：检查并确保依赖 `com.allinpay.cus.sdk:allinpay-syb-sdk-java:<version>`  
5. 生成 Demo 类到 `src/main/java/<packagePath>/<MainClass>.java`  
6. 在 `<projectDir>` 运行 `mvn -q -DskipTests package` 校验  

### B) scaffold 工单（JSON）

```json
{
  "intent": "scaffold_java_maven_demo",
  "constraints": { "language": "java", "buildTool": "maven" },
  "inputs": {
    "projectDir": "<projectDir>",
    "sdkGav": "com.allinpay.cus.sdk:allinpay-syb-sdk-java:1.1.10",
    "package": "com.allinpay.syb.demo",
    "mainClass": "SybDemoApp"
  },
  "changes": [
    { "type": "ensure_maven_project", "path": "<projectDir>" },
    { "type": "ensure_dependency", "path": "<projectDir>/pom.xml", "gav": "com.allinpay.cus.sdk:allinpay-syb-sdk-java:1.1.10" },
    { "type": "ensure_file", "path": "<projectDir>/src/main/java/com/allinpay/syb/demo/SybDemoApp.java" }
  ],
  "validation": [
    { "type": "command", "cwd": "<projectDir>", "run": "mvn -q -DskipTests package" }
  ]
}
```

## 3) 约束（必须遵守）

- 仅 Java + Maven；只修改/创建 `pom.xml`，不生成 Gradle/Kotlin。
- 依赖默认版本 `1.1.10`，用户指定则覆盖。
- 生成 demo 必须包含：SDK 原生初始化、请求/响应日志、异常处理、生产注意事项（幂等/重试/验签/脱敏）。

