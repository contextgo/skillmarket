---
name: allinpay-syb-sdk-unified
display_name: 通联收银宝业务技能（全量接口路由 + Java Demo）
description: 通联收银宝（SYB）业务 Skill：覆盖 allinpay-syb-sdk-java 全量 request API，按场景自动选择请求类并生成可运行 Java Demo。它依赖共享协议层（签名/异步通知/凭据边界/运行时要求），并提供“仅看代码/工程落地”两种输出模式。
version: 4.0.0
author: "allinpay | 开放平台"
license: "INTERNAL"
compatibility:
  - skillhub
dependencies:
  - allinpay-syb-pay-shared-base
metadata:
  skillhub:
    requires:
      config:
        - SYB_CUS_ID
        - SYB_APP_ID
        - SYB_SIGN_TYPE
        - SYB_SM4_KEY
        - SYB_MD5_KEY
        - SYB_PRI_KEY
        - SYB_PUB_KEY
        - SYB_ENV
triggers:
  - allinpay
  - 收银宝
  - syb sdk
  - 统一下单
  - 快捷支付
  - 分期付
  - 退款
  - 撤销
  - 查单
  - request api
  - demo
  - 异步通知
  - 文件上传
  - 文件下载
  - 前端跳转
  # 工程落地/依赖（用户常用说法）
  - maven
  - pom
  - pom.xml
  - 依赖
  - 引入sdk
  - 引入SDK
  - 创建工程
  - 新建工程
  - 脚手架
  - 落地
  - 写入工程
  # 仅查看（不落地）
  - 只看代码
  - 看看代码
  - 仅示例
  - 只要示例
  - 不落地
  - 不改工程
  - 不修改工程
  - 不写文件
  # 仅查看（更口语化）
  - 代码看看
  - 看下代码
  - 看下示例
  - 参考代码
  - 示例代码
  - 只要代码
  - 不用落地
  - 不要落地
  - 不要改工程
  - 别改工程
  - 别写文件
  - 不要写文件
  - 不要创建工程
  - 不用创建工程
  - 不用引依赖
  - 不要引依赖
  # 工程落地/依赖（更口语化）
  - 帮我加依赖
  - 补依赖
  - 加到pom
  - 加到pom.xml
  - 改pom
  - 改pom.xml
  - 生成到工程
  - 写到工程
  - 落到工程
  - 放到项目里
  - 放到工程里
  - 生成到目录
  - 写到目录
  - 新建maven工程
  - 创建maven工程
  - 能跑起来
  - 可运行
  - 可编译
---

# 通联收银宝业务 Skill（全量接口路由 + Java Demo）

> 共享协议层入口：请先看 `allinpay-syb-pay-shared-base`（签名/验签、异步通知、凭据边界、Java+Maven 运行时要求）。

## 面向开发的输出（两种交付，必须先判定）

本 Skill 的首要目标是“协助开发落地”，因此每次输出必须先判定 intent：

- `show_code_only`：只给你一份可复制粘贴的 Java demo（**不改工程**）
- `scaffold_java_maven_demo`：给“工程落地步骤 + JSON 工单”（用于 **改 pom/写文件/能编译运行**）

> 默认策略（准确率优先）：用户未明确要求落地时，默认 `show_code_only`。

## 输入理解与路由规则

1. 先按 `catalog/project-domain-fill-spec.md` 判定文集域。  
2. 再用 `catalog/request-routing-map.md` 选请求类。  
3. 最后用 `catalog/request-api-with-fields.md` 补字段细节。  

## 适配版本与复核信息

| 项目 | 内容 |
| --- | --- |
| Skill 版本 | `4.0.0` |
| 当前适配 SDK | `allinpay-syb-sdk-java`（以仓库 SDK 源码与索引生成结果为准） |
| 最后复核日期 | `2026-04-16` |
| 适用语言 | **Java**（仅） |
| 构建工具 | **Maven**（仅） |

## 代码生成统一规范

1. 初始化优先使用 SDK 原生 `AllinpayApi.initialize(MerchantConfig.builder()...)`。  
2. 对外示例统一给“SDK 原生初始化写法”。  
3. 参数顺序：必填 -> 条件必填 -> 可选。  
4. 日志输出：请求URL、请求报文、响应报文。  
5. 异常处理：`AllinpayException` + `Exception`。  
6. 敏感字段：`@EncryptField` 传明文，SDK自动加密。  
7. 字段大小写规则：**Java 代码一律以 SDK 的 Java 属性名 / getter / setter 为准**，不要用 JSON 字段名（如 `trxstatus/chnltrxid/trxamt`）去拼 `getXxx()/setXxx()`；需要对照时查 `catalog/request-api-with-fields.md`（请求）与 `catalog/field-enum-glossary.md`（常见响应字段 Java 名）。  

## Demo 生成骨架

- 标准接口：`reference/UniversalSybDemo.java`  
- 特殊场景：`reference/SpecialSceneSybDemo.java`（通知/上传/下载/前端跳转）

前端跳转响应规则（`AllinpayFrontResp`）：

- 必须按 `ApiType` 判断响应形态，不能默认同时存在 `urlJump` 和 `htmlJump`。
- 判定方式：使用 `request.apiMethod().getApiType()`。
- `FRONT_URL`：仅处理 `urlJump`。
- `FRONT_HTML`：仅处理 `htmlJump`。
- `FRONT_BOTH`：同时兼容 `urlJump` 与 `htmlJump`（优先级按业务自定）。

## 路由与索引

- `catalog/project-domain-fill-spec.md`
- `catalog/request-routing-map.md`
- `catalog/request-api-index.md`
- `catalog/request-api-with-fields.md`
- `catalog/field-enum-glossary.md`
- `catalog/request-requiredness-matrix.md`

## 依赖

```xml
<dependency>
    <groupId>com.allinpay.cus.sdk</groupId>
    <artifactId>allinpay-syb-sdk-java</artifactId>
    <version>1.1.10</version>
</dependency>
```

## 输出约定

1. 给出请求类名和理由。  
2. 生成可运行 demo（**仅 Java 语言**）。  
3. 给出生产注意事项（幂等、重试、验签、脱敏）。  
4. 特殊场景强制走 `SpecialSceneSybDemo`。  

## 开发交付格式（强约束）

无论哪个场景，每次输出至少包含以下小节（标题固定，便于开发者快速定位）：

1. **Intent**：`show_code_only` 或 `scaffold_java_maven_demo`（并说明依据）  
2. **Routing**：命中的 request 类 / 特殊调用方式（以及理由）  
3. **Demo（Java）**：可运行 demo（含初始化、必填参数占位符、异常处理、请求/响应日志）  
4. **Production notes**：幂等、重试、验签、脱敏、终态确认（回调+查询）  

若 intent 为 `scaffold_java_maven_demo`，额外必须包含：

5. **工程落地步骤（Java + Maven）**：明确 projectDir、pom 依赖、Demo 类路径、校验命令  
6. **scaffold 工单（JSON）**：changes/validation 可被工具直接执行  

## Reference 地图（你应该查哪些资料）

| 文件 | 内容 |
| --- | --- |
| `catalog/request-routing-map.md` | 业务关键词 -> 请求类（路由入口） |
| `catalog/request-api-index.md` | request 类全量索引 |
| `catalog/request-api-with-fields.md` | request 类字段索引（Java 字段名/JSON 名/加密标记） |
| `catalog/request-requiredness-matrix.md` | 必填/条件必填/选填矩阵（降低客诉） |
| `catalog/field-enum-glossary.md` | 常见字段/枚举（含 JSON->Java getter 对照） |
| `catalog/scaffold-protocol.md` | 工程落地协议（步骤清单 + JSON 工单） |

## 工程与依赖约定（仅 Maven）

当用户**指定目标项目/目录**（例如“在某某工程里生成 demo”或提供路径）时：

1. **只支持 Maven**：仅处理 `pom.xml`。如果目标是 Gradle/其他构建工具，直接提示“不支持”，并给出 Maven 方案。  
2. **自动引入 SDK**：若 `pom.xml` 中未包含 `com.allinpay.cus.sdk:allinpay-syb-sdk-java` 依赖，则自动追加（版本默认 `1.1.10`，除非用户指定）。  
3. **自动创建 demo 类**：在该工程的 `src/main/java/...` 下创建一个 `*Demo.java`（包名按项目现有包结构；若不存在则用 `com.allinpay.syb.demo`）。  
4. **工程不存在则创建新工程**：若目标目录下没有 `pom.xml`，则创建一个最小 Maven Java 工程（标准目录结构 + `pom.xml` + 可运行 `main` 类）。  
5. **仅 Java + Maven**：不生成 Kotlin/Scala，不生成 Gradle，不生成 Spring Boot 强绑定脚手架（除非用户明确要求且仍为 Maven）。  

## 工程落地输出协议（必须简单易懂）

说明：Skill 自身不直接改用户工程；但为了让任何 Agent 载体都能“照着做”，**每次输出必须包含两段**：①人类可读的步骤清单；②可选的 JSON 工单（更利于工具执行）。

### 0) 意图分流（先判断用户到底要不要落地）

先从用户话术中判断模式。目标：**宁可不落地，也不要误判去改工程**（准确率优先）。

#### 意图枚举（输出时也要显式写出 intent）

- `show_code_only`：仅展示代码/示例，不改工程、不写文件  
- `scaffold_java_maven_demo`：需要落地到工程（创建/修改 Maven 工程 + 生成 Demo 类）

#### 高置信规则（强命中词，优先级最高）

1) **强制 `show_code_only`（只看代码）**：用户出现任一表述即命中  
- 明确否定副作用：`不落地/不要落地/不用落地/不改工程/不要改工程/不修改工程/不写文件/不要写文件/别写文件/不用引依赖/不要引依赖/不用创建工程/不要创建工程/只看代码/看看代码/只要代码/示例代码/参考代码`

2) **强制 `scaffold_java_maven_demo`（要落地）**：用户出现任一表述即命中  
- 明确要落地：`生成到工程/写到工程/落到工程/放到项目里/放到工程里/生成到目录/写到目录/帮我加依赖/补依赖/改pom/改pom.xml/pom.xml/maven/新建工程/创建工程/能编译/可编译/能运行/可运行/跑起来`

#### 冲突消解（同时出现“只看代码”和“要落地”时怎么判）

- **默认以 `show_code_only` 为准**（避免误改工程）。  
- 只有当用户明确说“要落地”，且没有出现任何否定词（不落地/不改工程/不写文件/不用引依赖/不用创建工程）时，才判为 `scaffold_java_maven_demo`。  

#### 路径/目录是否等于“要落地”？

- **不是**。用户提供路径但同时说“只看代码/不改工程”，仍然判为 `show_code_only`。  
- 只有明确说“生成到/写到/落地到该目录”才判为落地。  

若判定为 `show_code_only`，则：

1. 仍输出“工程落地步骤（Java + Maven）”小节，但只写一句：**“本次仅展示代码，不对工程做任何修改。”**  
2. 仍输出 JSON，但 `intent` 改为 `show_code_only`，`changes` 为空数组，`validation` 为空数组。  
3. 同时输出完整 demo 代码（可直接复制粘贴到任意 Maven 工程运行）。  

若判定为 `scaffold_java_maven_demo`，则按下文 A/B 两段协议输出完整落地计划与工单。  

### A) 人类可读步骤清单（必填）

输出一个标题为 **“工程落地步骤（Java + Maven）”** 的小节，按下面格式写清楚：

1. **目标目录**：`<projectDir>`（用户给了就用；没给就写“当前工作区根目录”）。  
2. **是否已有 Maven 工程**：检查 `<projectDir>/pom.xml`。  
3. **如果没有 pom.xml**：创建最小 Maven 工程结构：  
   - `pom.xml`（包含 SDK 依赖）  
   - `src/main/java/`（标准目录）  
4. **如果已有 pom.xml**：  
   - 检查是否已包含依赖 `com.allinpay.cus.sdk:allinpay-syb-sdk-java`  
   - 若缺失：追加该依赖（版本默认 `1.1.10`，或用户指定版本）  
5. **创建 Demo 类**：  
   - 位置：`<projectDir>/src/main/java/<packagePath>/<MainClass>.java`  
   - 包名：优先复用项目已有包名；若无法判断，固定 `com.allinpay.syb.demo`  
   - 类要求：必须包含 `public static void main(String[] args)`；包含 SDK 原生初始化、请求/响应日志、`AllinpayException` 兜底  
6. **校验命令**（让 Agent 执行并回贴结果）：在 `<projectDir>` 下运行 `mvn -q -DskipTests package`。  

### B) 简化 JSON 工单（可选但强烈推荐）

同时附上一段标题为 **“scaffold 工单（JSON）”** 的 JSON（字段保持稳定，便于不同载体解析）：

```json
{
  "intent": "scaffold_java_maven_demo",
  "constraints": { "language": "java", "buildTool": "maven" },
  "inputs": {
    "projectDir": "<projectDir>",
    "sdkGav": "com.allinpay.cus.sdk:allinpay-syb-sdk-java:1.1.10",
    "package": "com.allinpay.syb.demo",
    "mainClass": "SybDemoApp"
  },
  "changes": [
    { "type": "ensure_maven_project", "path": "<projectDir>" },
    { "type": "ensure_dependency", "path": "<projectDir>/pom.xml", "gav": "com.allinpay.cus.sdk:allinpay-syb-sdk-java:1.1.10" },
    { "type": "ensure_file", "path": "<projectDir>/src/main/java/com/allinpay/syb/demo/SybDemoApp.java" }
  ],
  "validation": [
    { "type": "command", "cwd": "<projectDir>", "run": "mvn -q -DskipTests package" }
  ]
}
```

