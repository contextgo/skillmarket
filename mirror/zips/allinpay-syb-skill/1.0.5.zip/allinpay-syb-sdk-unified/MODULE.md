﻿---
name: allinpay-syb-sdk-unified
display_name: 通联收银宝业务技能（全量接口路由 + Java Demo）
description: 通联收银宝（SYB）业务 Skill：覆盖 allinpay-syb-sdk-java 全量 request API，按场景自动选择请求类并生成可运行 Java Demo。它依赖共享协议层（签名/异步通知/凭据边界/运行时要求），并提供“仅看代码/工程落地”两种输出模式。
version: 1.0.5
author: "allinpay | 开放平台"
license: "Allinpay"
compatibility:
  - skillhub
dependencies: []
metadata:
  skillhub:
    requires:
      config:
        - SYB_CUS_ID
        - SYB_APP_ID
        - SYB_SIGN_TYPE
        - SYB_SM4_KEY
        - SYB_MD5_KEY
        - SYB_PRI_KEY
        - SYB_PUB_KEY
        - SYB_ENV
triggers:
  - allinpay
  - 收银宝
  - syb sdk
  - request api
  - demo
  - maven
  - pom
  - pom.xml
  - 依赖
  - 脚手架
  - 落地
  - 只看代码
  - 不落地
  - 不改工程
  - 参考代码
  - 示例代码
  - 只要代码
  - 帮我加依赖
  - 加到pom
  - 加到pom.xml
  - 改pom
  - 改pom.xml
  - 生成到工程
  - 生成到目录
  - 可运行
  - 可编译
---

# 通联收银宝业务 Skill（全量接口路由 + Java Demo）

依赖：`allinpay-syb-pay-shared-base`（签名/验签、通知、凭据边界、运行时、SDK FAQ）。

---

## 0) 主链路（任何回答前先走完）

```
global-fill-spec → req-route → req-matrix(单分片) → resp-matrix → global-enum
```

| 步 | 文件 | 做什么 |
|---:|---|---|
| 1 | `catalog/global-fill-spec.md` | 域收敛与顺序边界 |
| 2 | `catalog/req-route.md` | 精确选 `*Request` + 对应 `req-matrix-*` 分片 |
| 3 | `catalog/req-matrix/req-matrix-*.md` | 单分片内定位小节；**响应类只认** `> 响应类：...` |
| 4 | `catalog/resp-matrix.md` | 用 `req-matrix` 给出的**完整**响应类名，在矩阵内 **唯一定位** 小节标题行 `## <类名>`（整行精确匹配）。**允许**用 `rg`/`grep` **仅**匹配 `^## <类名>\s*$` 取行号再 `read` 行窗，或编辑器大纲跳转——这是「键=类名」的一次线性扫描，**不是**缺索引；**禁止**的是用字段名/类名片段/模糊 `contains` 在全文乱搜 |
| 5 | `catalog/global-enum.md` | `retcode` / `trxstatus` 语义 |

**禁止绕行**：已从 `req-matrix` 得到确切响应类名时，**禁止**用字段名、JSON 名、类名片段或模糊规则对 `resp-matrix.md` **盲扫**抢结论。**应当**先用该类名做 **标题行键定位**：`^## <完整类名>\s*$`（可用 `rg`/`grep` 一次命中行号，再只读该节），与单独 `resp-index` 等价、不悖论。仅当类名仍不确定或确认无对应 `##` 小节时，才允许降级为更宽的全文/变体检索。

**可执行摘要（读响应字段）**：

```
readRespSection(className):   // className 须与 req-matrix「响应类」逐字一致
  line := rg '^## ' + className + '\s*$' 于 resp-matrix.md   // 或等价「仅标题行」定位
  Read(resp-matrix.md, offset≈line, limit≈小节高度)          // 禁止跳过此步直接用字段名全文 grep
  读同节 `> Extends:`；若需父类字段 → 对 Extends 递归同上（停于 AllinpayResp / AllinpayFrontResp）
```

**跨文件硬链（与上表等价）**：`req-matrix` 小节头响应类 → `resp-matrix` 对应 `##` 小节（含 `> Extends:`）→（必要时）父类小节重复 → `global-enum`。

**写 Java / Demo 前（与路由并列硬约束）**

1. `com.allinpay.syb.sdk.api.request.*` 下 **任意** `*Request`：**必须** `new XxxRequest()` + `setXxx(...)`；**严禁** `XxxRequest.builder()...build()`（禁止因「习惯/Lombok」使用 builder；与 R02、§3 自检第 2 条一致）。
2. **仅** `MerchantConfig` 用 `MerchantConfig.builder()...` 初始化，**且无** `.build()`。

---

## 1) 真源（防漂移）

| 内容 | 真源 |
|---|---|
| 域/填参顺序 | `global-fill-spec.md` |
| 路由 | `req-route.md` + `spec-route.md` |
| 请求字段 | `req-matrix/` |
| 响应字段/getter + 父类（`> Extends:`） | `resp-matrix.md` |
| 枚举 | `global-enum.md` |
| 特殊调用形态 | `spec-route.md` |
| 工程落地（步骤/工单/Maven） | **本 SKILL §5**（勿另找分散文档） |
| setter 类型白名单 | `reference/sdk-request-java-field-types.md` |

`req-matrix` 中 `U`：禁止口头断言必填/可选。`resp-matrix` 未出现字段/getter：只答「未完成核验/矩阵未命中」，禁止猜。

---

## 2) 初始化 + `client()`（唯一合法形态）

```java
MerchantConfig merchantConfig = MerchantConfig.builder()
    .orgId("YOUR_ORG_ID").cusId("YOUR_CUS_ID").appId("YOUR_APP_ID")
    .sm4Key("YOUR_SM4_KEY").signType("YOUR_SIGN_TYPE").md5Key("YOUR_MD5_KEY")
    .priKeyStr("YOUR_PRI_KEY").pubKeyStr("YOUR_PUB_KEY").environment("YOUR_ENV");
AllinpayApi.initialize(merchantConfig);
```

| 项 | 规则 |
|---|---|
| `MerchantConfig` | **无** `.build()`；禁止 `new MerchantConfig()` |
| `client()` 白名单 | 仅下面 6 种签名，禁止改参序/自创重载 |

1. `execObj(HttpConfig.build(), request)`
2. `execObj(preProcess, HttpConfig.build(), request)`
3. `upload(HttpConfig.build(), request)`
4. `downloadToByte(HttpConfig.build(), url)`
5. `downloadToFile(HttpConfig.build(), url, savePath)`
6. `noticeHandle(noticeStr)`

| 场景 | 用法 |
|---|---|
| 上传 | 只用 `upload` |
| 下载 | 只用 `downloadToByte` / `downloadToFile` |
| 通知 | 只用 `noticeHandle` |
| 禁止 | 用 `execObj` 顶替上三者 |

---

## 3) 骨架

| 默认骨架 | 用途 |
|---|---|
| `reference/UniversalSkeleton.java` | 标准同步 |
| `reference/SpecialSkeleton.java` | 通知/上传/下载/前端 |

| 规则 |
|---|
| 只补可编辑区；不重写整类；`package`/签名/已有变量名不改 |
| 骨架已有 `client()`：只补值，不改调用形态 |
| `*Request` **必须** `new XxxRequest()` + `setXxx(...)`；**严禁** `XxxRequest.builder()...build()`（技能输出与 Demo 一律遵守，不讨论 SDK 是否带 builder） |
| `show_code_only` 也必须做骨架一致性自检 |

**输出前自检（须逐条打勾，禁止合并省略）**

1. `MerchantConfig.builder()`：**无** `.build()`。
2. **任意** `*Request`：代码中 **不得出现** `.builder()` / `.build()`；须 **`new` + `setXxx`**（与 §0「写 Java 前」一致）。
3. `client()`：仅 §2 白名单形态。
4. `execObj`：返回值类型为对应 `*Response`（非 `AllinpayResp` 兜底）。
5. 响应结论：`req-matrix` 响应类 → `resp-matrix`（`##` + `Extends`）→ `global-enum`。
6. `bizData` 场景：R11–R14 词典链已命中。

---

## 4) 硬规则速查（R01–R38）

**通用**

| ID | 要点 |
|---|---|
| R01 | 初始化两步连续；`builder()` 链须含 orgId/cusId/appId/sm4Key/signType/md5Key/priKeyStr/pubKeyStr/environment |
| R02 | **仅** `MerchantConfig.builder()` 用于初始化（无 `.build()`）。**任意** `api.request.*` 的 `*Request` **必须** `new XxxRequest()` + `setXxx`；**严禁** `XxxRequest.builder()...build()`（技能与示例禁止，即使 SDK 存在 builder） |
| R03 | 填参顺序：R → C → O |
| R04 | 日志：URL + 请求报文 + 响应报文 |
| R05 | 异常：`AllinpayException` + `Exception` |
| R06 | `@EncryptField` 由 SDK 加密；禁止手工二次加密 |
| R07 | Java 只用 SDK 属性名与 getter/setter；禁止 JSON 名拼方法 |
| R08 | 基类 getter：`getRetCode/getRetMsg/getTrxId`；其余字段须 `resp-matrix`（+ 父类链）有证据 |
| R09 | `setXxx` 除 `sdk-request-java-field-types.md` 白名单外一律 `String` |

**调用与类型**

| ID | 要点 |
|---|---|
| R10 | `execObj` 返回值：后端用对应 `*Response`；**仅**白名单请求可用 `AllinpayFrontResp`；禁止 `AllinpayResp` 变量接 `execObj` |
| R16 | `client()` 仅白名单 6 形态 |
| R17 | 实参来源：骨架 > 用户 > `YOUR_*`；禁止 mock/臆造 |
| R18 | 用户给骨架且已有 `client()`：复用签名与变量名 |
| R19 | setter 与当前 request 一一对应；禁止塞跨接口字段 |
| R20 | 缺必需实参：占位 +「待业务侧提供」 |

**bizData / 枚举映射**

| ID | 要点 |
|---|---|
| R11 | `tranCode`+`bizData`：`JSON→UTF8→Base64`；禁止裸 JSON 字符串当 bizData |
| R12 | `ZhimaCreditMiniOrderRequest` / `PayScoreServiceOrderRequest` 的 `bizData`：`JsonUtils.toJson(bizObj)` + `import JsonUtils`；禁止说 SDK 自动转 JSON |
| R13 | 接口号/实体映射只读 `global-enum` 完整键 |
| R14 | 禁止 Map/JsonNode/手写 JSON/空父类占位；`UnionPayYJHXVo*` 明文字段赋值，禁止手工加密再上送 |
| R15 | 同包 VO 实体（`UnionPayYJHXVo*` 等）禁止自定义替换类 |

**前端 / 路由术语**

| ID | 要点 |
|---|---|
| R21 | `AllinpayFrontResp` 仅白名单：`UserTransCusPayRequest`、`QPayolAgreeApplyRequest`、`QPayolBindCardApplyRequest`、`GateWayPCRequest`、`GateWayH5Request`、`H5UnionPayOrderRequest`、`MerChantRepairCusrgcRequest`、`MerChantSecondPageRequest`、`ActivityActivityPageRequest`、`MerChantWxVerifyRequest`、`WxOpenGetOpenIdRequest`、`H5BillPayBillPayRequest` |
| R22 | 非白名单禁止 `AllinpayFrontResp` |
| R23 | 语义不能替代白名单（例：`UnitOrderNativePayRequest` → `UnitOrderNativePayResponse`） |
| R30 | 「统一支付」「统一支付API」→ `UnitOrderPayRequest`；仅用户明确「统一主扫/被扫」才切其它 `UnitOrder*` |

**检索与证据**

| ID | 要点 |
|---|---|
| R24 | 响应：`req-matrix` 得类名 → `resp-matrix` 的 `##` 小节 + `> Extends:` 父类链，至 `AllinpayResp`/`AllinpayFrontResp` 停 |
| R25 | 字段/getter 问题：`类名+字段` 双条件；结论须附原文片段；未完成核验禁止答「不存在」 |
| R26 | 路由/矩阵/getter 结论：先给「路径+类名」证据 |
| R27 | 否定结论须完整检索依据；否则「未完成核验」 |
| R28 | 多源冲突：列冲突点，问用户，禁止自决 |
| R29 | 结论格式：`已确认存在：类.字段 -> getter` 或 `未检出：条件` |
| R31 | 初始化片段两行齐全 + 九项参数逐项赋值 |
| R32 | 长文件禁止单段断言全局；响应须先唯一定位 `## 响应类名` 小节 |
| R33 | 词典键须完整键匹配，禁止前缀截断 |
| R34 | 「未找到」三条件：**标题行键**定位 `## 完整类名` 无果 + 变体检索 + 输出检索式；**允许**为取行号而对 `^## 类名\s*$` 做一次 `rg`；**禁**字段名/模糊规则抢读 `resp-matrix` |
| R35 | 上传/下载/通知形态同 §2 表，禁止 `execObj` 替代 |
| R36 | 字段结论链路：`req-route` → `req-matrix` 响应类 → `resp-matrix`（`##` + `Extends`）→ `global-enum` |
| R37 | 矩阵未命中：禁止猜 getter |

**R38 `retCode` / `trxStatus`（简表）**

| 检查 | 规则 |
|---|---|
| 比较 | `retCode` 对 `"SUCCESS"`；**禁止** `getRetCode()` 对 `"0000"` |
| `trxStatus` | 仅当 `resp-matrix` 在**本类或已 walk 的父类小节**中声明了该字段，才可 `getTrxStatus()` |
| 枚举 | 语义只读 `global-enum` |

有 `trxStatus`：

```java
if (!"SUCCESS".equals(resp.getRetCode())) { return; }
if (!"0000".equals(resp.getTrxStatus())) { return; }
```

无 `trxStatus`：

```java
if (!"SUCCESS".equals(resp.getRetCode())) { return; }
// 无 trxStatus：终态靠回调/查询
```

---

## 5) 模式、落地与 Maven（单文件真源）

### 5.1 模式与固定输出结构

| 模式 | 含义 |
|---|---|
| `show_code_only` | 只给可运行 Java，**不改工程**（默认） |
| `scaffold_java_maven_demo` | 人类可读步骤 + **JSON 工单** + **L1/L2/L3** |

每次输出须含：**Intent** → **Routing** → **Demo** → **Production notes**。`scaffold_*` 时另附：**步骤清单** + **JSON** + **分级校验结果/跳过理由**。

**与 §0–§4 的关系**：落地代码仍须遵守主链路、§2 `client()`、§3 自检、§4 **R01–R38**；**禁止**在本节臆造与 R 表冲突的「第二套规则」。`bizData` / `tranCode` / 银联 VO / `AllinpayFrontResp` / 响应 getter 等 **只认 §4**，此处不重复长清单。

### 5.2 意图判定（防误改工程）

| 判 `show_code_only`（任一） | 判 `scaffold`（任一） |
|---|---|
| 不落地、不改工程、只看/只要代码、不写文件、不引依赖、不创建工程… | 生成到目录/工程、改 pom、Maven、可编译/可运行、创建工程… |

**冲突**（同句既要看代码又要落地）：**优先 `show_code_only`**。仅路径不等于落地，须有「生成到/写到/落地到」类表述。

`show_code_only` 时：步骤写一句「本次仅展示代码」；工单 `intent=show_code_only`，`changes=[]`，`validation=[]`。

### 5.3 落地步骤（scaffold，人类可读）

1. 目标目录 `projectDir`（可选；默认当前工作区根）。  
2. 是否存在 `pom.xml`？否 → 最小 Maven 目录 + `pom.xml`。  
3. 确保依赖 **GAV**：`com.allinpay.cus.sdk:allinpay-syb-sdk-java:<version>`（**version 与仓库 SDK `pom.xml` 对齐**，用户指定可覆盖）。  
4. Demo 类落到 `src/main/java/<packagePath>/<Main>.java`。  
5. **L1** 静态自检 → **L2** `mvn -v`（失败则**停止** Maven，不重试）→ **L3** 默认 `mvn -q -DskipTests compile`；**`package` 仅用户明确要求**。  
6. 任何跳过须写明理由（如 `maven_missing`、`user_not_require_package`），写入回复或工单 `validation`。

### 5.4 JSON 工单（最小形状，字段可增不可删核心四块）

```json
{
  "intent": "scaffold_java_maven_demo",
  "constraints": { "language": "java", "buildTool": "maven" },
  "inputs": {
    "projectDir": "<path>",
    "sdkGav": "com.allinpay.cus.sdk:allinpay-syb-sdk-java:<与SDK pom一致>",
    "package": "com.example.syb",
    "mainClass": "SybDemoApp"
  },
  "changes": [
    { "type": "ensure_maven_project", "path": "<projectDir>" },
    { "type": "ensure_dependency", "path": "<projectDir>/pom.xml", "gav": "<同上>" },
    { "type": "ensure_file", "path": "<projectDir>/src/main/java/.../SybDemoApp.java" }
  ],
  "validation": [
    { "type": "precheck", "name": "maven_available", "run": "mvn -v" },
    { "type": "command", "cwd": "<projectDir>", "run": "mvn -q -DskipTests compile", "when": "maven_available=true" }
  ]
}
```

### 5.5 落地增量自检（在 §3 六条之后）

1. §3 自检已全部满足。  
2. 工单含 **`intent` + `inputs` + `changes` + `validation`**。  
3. **L1/L2/L3** 已执行或跳过理由已写清。  
4. **`mvn -v` 失败**：不进入 Maven 重试循环。  
5. **`compile` 失败**：最多再试 **1** 次；仍失败则输出可定位错误清单，不无限重跑。

### 5.6 实现边界（防过度封装）

仅 **Java + Maven**；只动 `pom.xml` 与约定源码路径。默认 **不新增** Facade/Adapter/Gateway/Template 等层；Demo 须含 **SDK 初始化 + 请求/响应日志 + 异常处理 + 生产注意**（幂等/验签/脱敏等见 shared-base）。未经用户要求 **不跑 `package`**。

---

## 6) 前端跳转（`AllinpayFrontResp`）

按 `request.apiMethod().getApiType()`：`FRONT_URL`→`urlJump`；`FRONT_HTML`→`htmlJump`；`FRONT_BOTH`→两者兼容。
