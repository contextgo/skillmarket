import com.allinpay.syb.sdk.api.AllinpayApi;
import com.allinpay.syb.sdk.api.enums.Environment;
import com.allinpay.syb.sdk.api.enums.SignType;
import com.allinpay.syb.sdk.api.request.AllinpayReq;
import com.allinpay.syb.sdk.api.response.AllinpayResp;
import com.allinpay.syb.sdk.core.AllinpayException;
import com.allinpay.syb.sdk.core.PreProcessRequest;
import com.allinpay.syb.sdk.core.config.HttpConfig;
import com.allinpay.syb.sdk.core.config.MerchantConfig;
import com.allinpay.syb.sdk.core.utils.JsonUtils;

public class UniversalSkeleton {

    /**
     * SDK 原生初始化示例（应用启动时执行一次）
     */
    public static void initSdk() {
        AllinpayApi.initialize(MerchantConfig.builder()
                .orgId("")                     // 可选：集团/代理商户号
                .cusId("YOUR_CUS_ID")          // 必填：商户号
                .appId("YOUR_APP_ID")          // 必填：应用ID
                .sm4Key("YOUR_SM4_KEY")        // 涉及敏感字段时必填
                .signType(SignType.RSA)        // 可选：RSA / SM2 / MD5 / RSA2
                .md5Key("")                    // signType=MD5 时填写
                .priKeyStr("YOUR_PRI_KEY")     // 非MD5签名必填
                .pubKeyStr("YOUR_PUB_KEY")     // 非MD5签名必填
                .environment(Environment.TEST) // TEST / PROD
        );
    }

    /**
     * 标准同步接口：{@link AllinpayApi#client()} 的三参数 {@code execObj}；
     * 预处理回调用于打印 URL 与签名前的只读参数字典（见 {@link PreProcessRequest}）。
     * 【响应判断强制规则 - 禁止违反】
     * 1) retCode == "SUCCESS" → 通信成功（仅表示通道通了，不代表交易成功）
     * 2) trxStatus == "0000"   → 交易成功（仅当响应类声明了 trxStatus 字段时可用）
     * 3) 判断前必须先查 resp-matrix.md 确认该响应类是否有 trxStatus
     * 4) 禁止把 "0000" 和 getRetCode() 比较
     */
    public static <R extends AllinpayResp> R execute(AllinpayReq<R> request) {
        try {
            HttpConfig config = HttpConfig.build();
            PreProcessRequest logParams = (httpConfig, readOnlyParams) -> {
                System.out.println("请求URL  : " + httpConfig.getUrl());
                System.out.println("请求报文  : " + JsonUtils.toJson(readOnlyParams));
            };
            R response = AllinpayApi.client().execObj(logParams, config, request);

            System.out.println("响应报文  : " + JsonUtils.toJson(response));
            return response;
        } catch (AllinpayException e) {
            System.out.println("请求异常：" + e.getMessage());
        } catch (Exception e) {
            System.out.println("系统异常：" + e.getMessage());
        }
        return null;
    }

    public static void main(String[] args) {
        // 1) 应用启动时只初始化一次
        initSdk();

        // 2) 按场景替换为具体请求类，例如：
        // UnitOrderPayRequest / TranxQueryRequest / QPayApplyRequest / FqfJDBTPayRequest
        // 3) 必须用 new XxxRequest() + setXxx(...) 填参，严禁 XxxRequest.builder()...build()
        // 4) 按 req-matrix 填充必填参数后调用 execute(request)
    }
}

