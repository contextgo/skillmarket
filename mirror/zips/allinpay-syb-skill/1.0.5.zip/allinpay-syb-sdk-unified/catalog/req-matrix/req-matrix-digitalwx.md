# 字段必填矩阵 - DigitalWx

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - DigitalWxCateringOrderSyncStatusRequest

> 类说明：微信点餐

> 响应类：DigitalWxCateringOrderSyncStatusResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| digId | digid | R | 应用ID |
| subAppid | sub_appid | R | 子商户在微信公众平台申请服务号对应的APPID |
| outShopNo | outshopno | R | 商户旗下门店唯一编号 |
| subOpenId | subopenid | R | 用户在子商户appid下的openid |
| loginToken | logintoken | R | 微信登录票据（公众号填access_token；小程序填session_key） |
| orderEntry | orderentry | R | 点餐入口 |
| totalAmount | totalamount | R | 总价；单位分 |
| discountAmount | discountamount | R | 优惠金额；单位分 |
| userAmount | useramount | R | 实际支付金额；单位分 |
| status | status | R | 订单状态；枚举见 global-enum.digitalwxstatus |
| actionTime | actiontime | R | 状态变化时间；格式yyyymmddhhmmss |
| payTime | paytime | C | status=PAY_SUCCESS 时必填；格式yyyymmddhhmmss |
| chnlTrxId | chnltrxid | C | status=PAY_SUCCESS 时必填；渠道平台交易单号 |
| trxId | trxid | C | status=PAY_SUCCESS 时必填；收银宝平台交易流水号 |
| reqSn | reqsn | R | 商户交易订单号 |
| dishList | dishlist | R | dish_list对象列表（字符串承载） |
| outTableNo | outtableno | O | 桌位号 |
| peopleCount | peoplecount | O | 消费人数 |



