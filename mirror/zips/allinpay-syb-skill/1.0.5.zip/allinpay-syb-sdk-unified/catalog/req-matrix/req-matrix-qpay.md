# 字段必填矩阵 - QPay

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - QPayAgreeApplyRequest

> 类说明：快捷支付API-签约申请

> 响应类：QPayAgreeApplyResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqIp | reqip | O | 请求ip |
| reqTime | reqtime | R | 本次请求时间；格式yyyyMMddHHmmss |
| merUserId | meruserid | R | 商户用户号（商户自定义） |
| acctType | accttype | R | 卡类型；取值见 global-enum.accttypeqpay |
| acctNo | acctno | R | 银行卡号 |
| idType | idtype | R | 证件类型；取值见 global-enum.idtype（本场景常用0/2/5/6） |
| idNo | idno | R | 证件号；若包含字母X必须大写 |
| acctName | acctname | R | 户名 |
| mobile | mobile | R | 手机号码 |
| validDate | validdate | O | 有效期；格式MMyy |
| cvv2 | cvv2 | O | 卡校验码 |

## 字段必填矩阵 - QPayAgreeConfirmRequest

> 类说明：快捷支付API-签约确认

> 响应类：QPayAgreeConfirmResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqIp | reqip | O | 请求ip |
| reqTime | reqtime | R | 本次请求时间；格式yyyyMMddHHmmss |
| merUserId | meruserid | R | 商户用户号（商户自定义） |
| acctType | accttype | R | 卡类型；取值见 global-enum.accttypeqpay |
| acctNo | acctno | R | 银行卡号 |
| idType | idtype | R | 证件类型；取值见 global-enum.idtype（本场景常用0/2/5/6） |
| idNo | idno | R | 证件号；若包含字母X必须大写 |
| acctName | acctname | R | 户名 |
| mobile | mobile | R | 手机号码 |
| validDate | validdate | O | 有效期；格式MMyy |
| cvv2 | cvv2 | O | 卡校验码 |
| smsCode | smscode | R | 短信验证码；签约确认短信验证码有效期5分钟 |
| thpInfo | thpinfo | C | 交易透传信息；签约申请返回不为空时，确认请求需原样透传 |
| userAgreeNo | useragreeno | O | 用户协议号；文档示例值241 |

## 字段必填矩阵 - QPayApplyRequest

> 类说明：快捷支付API-支付申请

> 响应类：QPayApplyResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | R | 商户订单号 |
| agreeId | agreeid | R | 协议编号（签约返回） |
| amount | amount | R | 订单金额；单位分 |
| currency | currency | R | 币种；暂仅支持CNY |
| subject | subject | R | 订单内容（展示标题） |
| trxReserve | trxreserve | O | 交易备注；用于用户订单个性化信息，交易完成通知会带上本字段 |
| notifyUrl | notifyurl | R | 交易结果通知地址；必须为可直接访问且不带参数的url |
| asInfo | asinfo | O | 分账信息,具体格式参考接口文档 |

## 字段必填矩阵 - QPayConfirmRequest

> 类说明：快捷支付API-支付确认

> 响应类：QPayConfirmResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqIp | reqip | O | 请求ip |
| reqTime | reqtime | R | 本次请求时间；格式yyyyMMddHHmmss |
| reqSn | reqsn | R | 订单号（商户订单号） |
| agreeId | agreeid | R | 协议编号 |
| smsCode | smscode | R | 短信验证码 |
| thpInfo | thpinfo | R | 交易透传信息；支付申请成功或错误码为1999返回时，确认请求需原样带上 |

## 字段必填矩阵 - QPayolAgreeApplyRequest

> 类说明：快捷支付API-一键绑卡申请

> 响应类：AllinpayFrontResp

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqIp | reqip | O | 请求ip |
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss |
| applyId | applyid | R | 申请单号 |
| bankCode | bankcode | R | 银行编码（见附录） |
| encryptType | encrypttype | R | 加密方式仅支持SM4 |
| acctType | accttype | R | 卡类型；取值见 global-enum.accttypeqpay |
| idType | idtype | R | 证件类型；取值见 global-enum.idtype；当前仅支持身份证（0） |
| idNo | idno | R | 证件号（敏感字段） |
| acctName | acctname | R | 户名（敏感字段） |
| mobile | mobile | C | 手机号（敏感字段）；招商银行场景必填 |
| acctNo | acctno | C | 卡号（敏感字段）；招商银行场景必填 |
| notifyUrl | notifyurl | R | 签约结果后端通知地址；必须为可直接访问且不带参数的url |
| retUrl | returl | R | 签约结果前端通知地址；必须为可直接访问且不带参数的url |

## 字段必填矩阵 - QPayolBindCardApplyRequest

> 类说明：快捷支付API-一绑卡签约H5

> 响应类：AllinpayFrontResp

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| orgId | orgid | O | 机构号；共享机构号参数时必填 |
| reqIp | reqip | O | 请求ip |
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss |
| applyId | applyid | R | 申请单号 |
| merUserId | meruserid | R | 用户编号（商户平台用户编号） |
| encryptType | encrypttype | R | 加密方式仅支持SM4 |
| notifyUrl | notifyurl | R | 签约结果后端通知地址；必须为可直接访问且不带参数的url |
| retUrl | returl | R | 签约结果前端通知地址；必须为可直接访问且不带参数的url |

## 字段必填矩阵 - QPaySmsAgreeRequest

> 类说明：快捷支付API-重新获取支付短信

> 响应类：QPaySmsAgreeResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqIp | reqip | O | 请求ip |
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss |
| orderId | orderid | R | 商户订单号 |
| agreeId | agreeid | C | 协议编号；协议支付场景必填 |
| thpInfo | thpinfo | C | 交易透传信息；提交支付时接口返回不为空时需原样带上 |

## 字段必填矩阵 - QPayUnbindRequest

> 类说明：快捷支付API-银行卡解绑

> 响应类：QPayUnbindResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqIp | reqip | U | 请求ip |
| reqTime | reqtime | U | 本次请求时间；格式yyyyMMddHHmmss |
| agreeId | agreeid | U | 协议编号 |



