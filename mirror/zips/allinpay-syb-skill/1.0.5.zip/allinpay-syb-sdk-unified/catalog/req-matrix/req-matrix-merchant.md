# 字段必填矩阵 - MerChant

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - MerChantAcctEditRequest

> 类说明：商户结算信息管理接口

> 响应类：MerChantAcctEditResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| notifyUrl | notifyurl | R | 回调url；回调结果格式请参照进件通知 |
| clearMode | clearmode | R | 结算方式；取值见 global-enum.clearmode |
| acctId | acctid | R | 账户号 |
| acctName | acctname | R | 账户名 |
| acctType | accttype | R | 账户类型；取值见 global-enum.accttypemerchant |
| acctTp | accttp | R | 卡折类型；取值见 global-enum.accttp |
| bankCode | bankcode | R | 所属银行（见附录） |
| cnapsno | cnapsno | R | 支付行号（见附录） |
| pubAcctInfo | pubacctinfo | C | 商户性质为法人及其他组织且结算账户为对私时必填；格式为“对公账户号#对公账户开户省#对公账户开户市#所属行#支付行号” |
| picUrlJson | picurljson | C | 修改acctid/acctname/clearmode时上送图片替换；图片json字符串 |

## 字段必填矩阵 - MerChantAddRequest

> 类说明：商户进件请求参数

> 响应类：MerChantAddResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| merChantId | merchantid | R | 代理商平台商户号（系统内唯一） |
| merChantName | merchantname | R | 商户名称 |
| shortName | shortname | R | 商户简称 |
| cusEngName | cusengname | C | 开通外卡产品时必填 |
| cusEngShortName | cusengshortname | C | 开通外卡产品时必填 |
| servicePhone | servicephone | R | 客服电话 |
| mccId | mccid | R | 所属行业（见附录） |
| comProperty | comproperty | R | 商户性质；枚举见 global-enum.comproperty |
| corpBusName | corpbusname | C | 商户性质非个人时必填 |
| creditCode | creditcode | C | 商户性质非个人时必填 |
| creditCodeExpire | creditcodeexpire | C | 商户性质非个人时必填；yyyy-mm-dd或长期 |
| legal | legal | R | 法人姓名 |
| legalIdType | legalidtype | R | 法人证件类型；枚举见 global-enum.legalidtype |
| legalIdNo | legalidno | R | 法人证件号 |
| legalIdExpire | legalidexpire | R | 法人证件有效期；yyyy-mm-dd或长期 |
| address | address | R | 注册地址（需包含省市） |
| contactPerson | contactperson | R | 财务联系人（收短信用） |
| contactPhone | contactphone | R | 财务联系人电话 |
| clearMode | clearmode | R | 结算方式；枚举见 global-enum.clearmode |
| acctId | acctid | R | 账户号 |
| acctName | acctname | R | 账户名 |
| acctType | accttype | R | 账户类型；枚举见 global-enum.accttypemerchant |
| acctTp | accttp | R | 卡折类型；枚举见 global-enum.accttp |
| bankCode | bankcode | R | 所属银行（见附录） |
| cnapsno | cnapsno | R | 支付行号（见附录） |
| notifyUrl | notifyurl | R | 进件成功回调通知url |
| corpBusPic | corpbuspic | C | 商户性质非个人时必填 |
| legalIdPicFront | legalidpicfront | R | 法人身份证人像面照片url |
| legalIdPicBack | legalidpicback | R | 法人身份证国徽面照片url |
| legalPic | legalpic | C | 商户性质为个人时必填 |
| storePic | storepic | R | 商户门头照片url |
| storeInnerPic | storeinnerpic | R | 经营内景照片url |
| bizPlacePic | bizplacepic | C | 商户性质为个人时必填 |
| otherFile | otherfile | O | 其他审核材料；必须zip文件且最大5M |
| expandUser | expanduser | R | 拓展人 |
| subBranchList | subbranchlist | R | 门店信息列表json数组；结构与取值见下方“商户进件复杂 JSON 字段约束” |
| prodList | prodlist | R | 支付产品信息列表json数组；结构与取值见下方“商户进件复杂 JSON 字段约束” |
| addFaCusId | addfacusid | C | 所在机构资金归集时必填 |
| settIdNo | settidno | C | 结算账户对私时必填 |
| holderName | holdername | C | 商户性质为企业/个体户时必填 |
| holderIdNo | holderidno | C | 商户性质为企业/个体户时必填 |
| holderExpire | holderexpire | C | 商户性质为企业/个体户时必填 |
| registerFund | registerfund | C | 商户性质为企业/个体户时必填；取值见 global-enum.registerfund |
| staffTotal | stafftotal | O | 可选；取值见 global-enum.stafftotal |
| operateLimit | operatelimit | O | 可选；取值见 global-enum.operatelimit |
| inspect | inspect | O | 可选；取值见 global-enum.inspect |
| thrCertFlag | thrcertflag | O | 是否三证合一；默认1 |
| organCode | organcode | C | 三证合一=否时必填 |
| organExpire | organexpire | C | 三证合一=否时必填；yyyy-mm-dd或长期 |
| busConActPerson | busconactperson | C | 非个人类商户必填 |
| busConActTel | busconacttel | C | 非个人类商户必填 |
| ofFlag | offlag | O | 线上线下业务场景；枚举见 global-enum.offlag |
| unSdRemark | unsdremark | O | 渠道备注信息 |
| agreeType | agreetype | O | 无纸化标识；枚举见 global-enum.agreetype |
| picUrlJson | picurljson | O | 图片json字符串（图片url键值对）；字段清单见下方“商户进件复杂 JSON 字段约束” |
| cusUrl | cusurl | C | 开通网关/快捷/云闪付APP或线上场景必填 |
| webName | webname | C | 开通网关/快捷/云闪付APP或线上场景必填 |
| legalDetail | legaldetail | R | 法人信息json字符串；字段与枚举见下方“商户进件复杂 JSON 字段约束” |
| bnfDetail | bnfdetail | R | 受益人信息json字符串；字段与枚举见下方“商户进件复杂 JSON 字段约束” |
| taxDetail | taxdetail | C | 企业且非三证合一时必填；字段约束见下方“商户进件复杂 JSON 字段约束” |
| busDetail | busdetail | R | 经营内容 |
| businessPlace | businessplace | O | 经营场所；枚举见 global-enum.businessplace |
| busAddress | busaddress | R | 商户经营地址 |
| districtCode | districtcode | R | 所在区（见附录） |
| reqId | reqid | O | 进件请求流水号 |
| settRemark | settremark | O | 结算摘要前缀；仅当非自主提现时获取 |
| creditCodeType | creditCodeType | O | 营业执照类型 |
| creditCodeStartDate | creditCodeStartdate | O | 营业证件成立日期；yyyy-MM-dd |
| legalIdStartDate | legalidStartdate | O | 法人证件生效日期；yyyy-MM-dd |
| icpInfo | icpinfo | O | ICP备案号 |
| pubAcctInfo | pubacctinfo | C | 企业/事业单位/其他组织且结算账户对私时必填；格式见文档 |
| appScenario | appscenario | O | 应用场景；枚举见 global-enum.appscenario |
| quickCash | quickcash | O | 快速提现开关；枚举见 global-enum.quickcash |
| clearTimeRule | cleartimerule | O | 结算时间；枚举参考附录8.8 |
| electNotify | electnotify | O | 电子协议签约回调地址；为空通知到进件回调url |
| creDentCheckDate | credentcheckdate | O | 营业执照核准日期；yyyy-mm-dd |

## 字段必填矩阵 - MerChantAddTermRequest

> 类说明：终端信息采集接口请求参数

> 响应类：MerChantAddTermResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| termNo | termno | R | 8位数字；商户下唯一 |
| deviceType | devicetype | R | 设备类型；取值见 global-enum.devicetype |
| termSn | termsn | C | 当 deviceType=02/03/04/05/06/08/09/10 时必填 |
| operaTion | operation | R | 操作类型；取值见 global-enum.termoperation；取值为02（注销）时，termsn/termstate 可空 |
| termState | termstate | C | 终端状态；取值见 global-enum.termstate；operaTion=02（注销）时可空 |
| termAddress | termaddress | C | 省-市-区-详细地址；详细地址长度控制在30个汉字以内；取值范围可参考省市区结构说明；operaTion=02（注销）时可空 |

## 字段必填矩阵 - MerChantAgentExpiredRequest

> 类说明：商户证件到期结果文件查询

> 响应类：MerChantAgentExpiredResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| fileType | filetype | R | 到期提醒文件类型；取值见 global-enum.filetypeagentexpired |
| endDate | enddate | O | 到期日；默认当前日期；格式yyyy-MM-dd |
| notifyUrl | notifyurl | R | 通知地址；按该地址回调调用方，详见进件通知 |

## 字段必填矩阵 - MerChantBindCodeRequest

> 类说明：商户二维码绑定申请接口

> 响应类：MerChantBindCodeResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| qrCode | qrcode | R | 当面付二维码（未绑定二维码ID） |
| branchNo | branchno | C | 二维码绑定为门店层时必填 |
| latitude | latitude | C | 二维码绑定为商户层时必填 |
| longitude | longitude | C | 二维码绑定为商户层时必填 |

## 字段必填矩阵 - MerChantConfirmBindRequest

> 类说明：商户二维码绑定确认接口

> 响应类：MerChantConfirmBindResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| qrCode | qrcode | R | 当面付二维码（与申请时一致） |
| branchNo | branchno | O | 商户门店号（与申请时一致） |
| latitude | latitude | O | 纬度（与申请时一致） |
| longitude | longitude | O | 经度（与申请时一致） |
| smsCode | smscode | R | 短信验证码 |

## 字段必填矩阵 - MerChantConfirmUnBindRequest

> 类说明：商户二维码解绑确认接口

> 响应类：MerChantConfirmUnBindResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| qrCode | qrcode | R | 当面付二维码（与申请时一致） |
| smsCode | smscode | R | 短信验证码 |

## 字段必填矩阵 - MerChantEditRequest

> 类说明：商户基本信息管理接口

> 响应类：MerChantEditResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| shortName | shortname | O | 可选；20个字内 |
| servicePhone | servicephone | O | 可选；业务联系人电话 |
| corpBusName | corpbusname | C | 商户性质非个人时需填写 |
| creditCode | creditcode | C | 商户性质非个人时需填写 |
| creditCodeExpire | creditcodeexpire | C | 商户性质非个人时需填写 |
| legal | legal | O | 可选；法人姓名 |
| legalIdType | legalidtype | O | 可选；取值见 global-enum.legalidtype（编辑场景常用01/04/05） |
| legalIdNo | legalidno | O | 可选；法人代表证件号 |
| legalIdExpire | legalidexpire | O | 可选；法人身份证有效期 |
| address | address | O | 可选；注册地址 |
| contactPerson | contactperson | O | 可选；财务联系人（收短信） |
| contactPhone | contactphone | O | 可选；财务联系人电话 |
| addFaCusId | addfacusid | O | 可选；所属父客户号 |
| notifyUrl | notifyurl | R | 回调url；回调结果格式请参照进件通知 |
| zipUrl | zipurl | O | 可选；附件url，仅支持zip压缩包 |
| picsTrUrl | picstrurl | O | 可选；图片url拼接，使用分号`;`分隔，最多5张 |
| holderName | holdername | C | 商户性质为企业/个体户时必填 |
| holderIdNo | holderidno | C | 商户性质为企业/个体户时必填 |
| holderExpire | holderexpire | C | 商户性质为企业/个体户时必填 |
| registerFund | registerfund | C | 商户性质为企业/个体户时必填；取值见 global-enum.registerfund |
| staffTotal | stafftotal | O | 可选；取值见 global-enum.stafftotal |
| operateLimit | operatelimit | O | 可选；取值见 global-enum.operatelimit |
| inspect | inspect | O | 可选；取值见 global-enum.inspect |
| thrCertFlag | thrcertflag | O | 可选；三证合一标识，取值见 global-enum.thrcertflag |
| organCode | organcode | C | 三证合一=否时需要填写 |
| organExpire | organexpire | C | 三证合一=否时需要填写 |
| busConActPerson | busconactperson | C | 非个人类商户必填 |
| busConActTel | busconacttel | C | 非个人类商户必填 |
| unSdRemark | unsdremark | O | 可选；渠道备注信息 |
| legalDetail | legaldetail | O | 可选；法人信息json（字段与枚举见下方“商户进件复杂 JSON 字段约束”） |
| bnfDetail | bnfdetail | O | 可选；受益人信息json（字段与枚举见下方“商户进件复杂 JSON 字段约束”） |
| taxDetail | taxdetail | O | 可选；税务登记详情json（字段约束见下方“商户进件复杂 JSON 字段约束”） |
| busDetail | busdetail | O | 可选；经营内容 |
| cusUrl | cusurl | O | 可选；网站url或下载地址 |
| webName | webname | O | 可选；网站名称/应用名称 |
| businessPlace | businessplace | O | 可选；经营场所，取值见 global-enum.businessplace |
| busAddress | busaddress | O | 可选；商户经营地址 |
| districtCode | districtcode | O | 可选；所在区 |
| merChantName | merchantname | O | 可选；商户名称 |
| tlBankNo | tlbankno | O | 可选；电子账号号 |
| creditCodeType | creditCodeType | O | 可选；营业执照类型 |
| creditCodeStartDate | creditCodeStartdate | O | 可选；营业证件成立日期，格式yyyy-MM-dd |
| legalIdStartDate | legalidStartdate | O | 可选；法人证件生效日期，格式yyyy-MM-dd |

## 字段必填矩阵 - MerChantElectSignRequest

> 类说明：电子协议重发接口

> 响应类：MerChantElectSignResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| electSignType | electsigntype | O | 电子协议类型；为空表示进件协议；取值见 global-enum.electsigntypeprodfeeshare |
| relatedCusId | relatedcusid | C | 关联商户号；electSignType=14/15 时不能为空；electSignType=14 时为出金商户号，electSignType=15 时为入金商户号 |

## 字段必填矩阵 - MerChantProdFeeShareQryRequest

> 类说明：商户手续费部分补贴配置查询

> 响应类：MerChantProdFeeShareQryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|

## 字段必填矩阵 - MerChantProductRequest

> 类说明：商户产品信息管理接口

> 响应类：MerChantProductResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqType | reqtype | R | 请求类型；取值见 global-enum.reqtypemerchantproduct |
| prodList | prodlist | C | 支付产品信息列表json；reqType=query 时可空，其它请求类型必填；结构见下方“商户进件复杂 JSON 字段约束” |

## 字段必填矩阵 - MerChantQrCodeQryRequest

> 类说明：商户二维码绑定关系查询

> 响应类：MerChantQrCodeQryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| qrCode | qrcode | R | 当面付二维码（当前商户绑定二维码） |

## 字段必填矩阵 - MerChantQryTermRequest

> 类说明：终端信息查询接口请求参数

> 响应类：MerChantQryTermResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| termNo | termno | R | 8位数字终端号 |
| queryType | querytype | O | 查询类型；取值见 global-enum.querytypeterm；为空时返回AT加银联报备状态 |

## 字段必填矩阵 - MerChantQueryChnlCmIdRequest

> 类说明：渠道子商户查询

> 响应类：MerChantQueryChnlCmIdResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| chnlType | chnltype | R | 渠道类型（中文大写缩写）；取值见 global-enum.chnltypemerchant |
| settId | settid | C | 结算id；仅当该商户存在多个结算id且无法创建建子商户号时传 |

## 字段必填矩阵 - MerChantQueryCusRgcRequest

> 类说明：合规性状态查询接口

> 响应类：MerChantQueryCusRgcResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|

## 字段必填矩阵 - MerChantQueryElectSignRequest

> 类说明：电子协议签约状态查询

> 响应类：MerChantQueryElectSignResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|

## 字段必填矩阵 - MerChantQueryElectUrlRequest

> 类说明：电子协议URL查询

> 响应类：MerChantQueryElectUrlResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| redirectUrl | redirecturl | U | 重定向url |

## 字段必填矩阵 - MerChantQueryRequest

> 类说明：进件成功商户信息查询

> 响应类：MerChantQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|

## 字段必填矩阵 - MerChantQueryStatusRequest

> 类说明：商户审核状态查询

> 响应类：MerChantQueryStatusResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| merChantId | merchantid | U | 代理商平台商户号（系统内唯一） |
| reqId | reqid | U | 请求流水号 |

## 字段必填矩阵 - MerChantQueryWxSubDevRequest

> 类说明：子商户微信配置信息查询

> 响应类：MerChantQueryWxSubDevResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|

## 字段必填矩阵 - MerChantQueryWxVerifyStateRequest

> 类说明：微信/支付宝认证状态查询

> 响应类：MerChantQueryWxVerifyStateResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| chnlType | chnltype | R | 渠道类型（中文大写缩写）；取值见 global-enum.chnltypemerchant |
| pid | pid | C | 产品类型；取值见 global-enum.pidwxverifystate |

## 字段必填矩阵 - MerChantRepairComplianceRequest

> 类说明：合规性补录API接口

> 响应类：MerChantRepairComplianceResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| cusShortName | cusshortname | C | 仅当门头照不合规时支持修改 |
| address | address | C | 仅当租赁合同（承租人）不合规时支持修改 |
| creDentExpire | credentexpire | C | 格式yyyy-MM-dd；仅creditresult不合规时可补录 |
| legalIdExpire | legalidexpire | C | 格式yyyy-MM-dd；仅legalidresult不合规时可补录 |
| acctId | acctid | C | 仅clearparamresult不合规且为对公结算信息项时可补录 |
| storePic | storepic | C | 图片url；仅headresult或headresulthd门头照不合规时可补录 |
| innerPic | innerpic | C | 图片url；仅innerresult或innerresulthd内部经营照不合规时可补录 |
| handPickPic | handpickpic | C | 图片url；仅handpickresult或handpickresulthd经营者手持身份证照片不合规时可补录 |
| peasonHeadPic | peasonheadpic | C | 图片url；仅peasonheadresult经营者与店铺门头合照不合规时可补录 |
| creditPic | creditpic | C | 图片url；仅creditresult或creditresulthd营业证件照不合规时可补录 |
| legalIdPicFront | legalidpicfront | C | 图片url；仅legalidresult或legalidresulthd身份证照不合规时可补录 |
| legalIdPicBack | legalidpicback | C | 图片url；仅legalidresult或legalidresulthd身份证照不合规时可补录 |
| rentCtPic | rentctpic | C | 图片url；仅rentctresult租赁合同不合规时可补录 |
| registerPic | registerpic | C | 图片url；仅paperresult纸质协议不合规时可补录 |
| homePagePic | homepagepic | C | 图片url；仅paperresult纸质协议不合规时可补录 |
| finalPagePic | finalpagepic | C | 图片url；仅paperresult纸质协议不合规时可补录 |
| clearParamPic | clearparampic | C | 图片url；仅clearparamresult或clearparamresulthd结算信息项不合规时可补录 |
| authorPic | authorpic | C | 图片url；仅authresult或authresulthd签字授权书不合规时可补录 |
| certifiedPic | certifiedpic | C | 图片url；仅certifiedresult执业证明材料不合规时可补录 |
| repairOtherPic | repairotherpic | O | 图片url；其他补充材料，可多张，以英文分号`;`拼接 |

## 字段必填矩阵 - MerChantRepairCusrgcRequest

> 类说明：合规性审核补录统一h5接口

> 响应类：AllinpayFrontResp

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| jumpUrl | jumpurl | U | 补录完成跳转地址 |

## 字段必填矩阵 - MerChantSecondPageRequest

> 类说明：秒到开通H5接口

> 响应类：AllinpayFrontResp

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|

## 字段必填矩阵 - MerChantSubBranchRequest

> 类说明：商户门店信息管理接口

> 响应类：MerChantSubBranchResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqType | reqtype | R | 请求类型；取值见 global-enum.reqtypemerchantproduct |
| subBranchList | subbranchlist | C | 门店列表json；长度不超过4000；reqType=query 时可空，其它请求类型必填 |

## 字段必填矩阵 - MerChantTermRequest

> 类说明：商户终端信息管理接口

> 响应类：MerChantTermResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqType | reqtype | R | 请求类型；取值见 global-enum.reqtypemerchantterm |
| termList | termlist | C | 终端信息列表json；长度不超过1000；reqType=query 时可空，reqType=add 时必填 |

## 字段必填矩阵 - MerChantUnBindCodeRequest

> 类说明：商户二维码解绑接口

> 响应类：MerChantUnBindCodeResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| qrCode | qrcode | U | 当面付二维码 |

## 字段必填矩阵 - MerChantWxSubDevConfigRequest

> 类说明：微信子商户参数配置

> 响应类：MerChantWxSubDevConfigResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| configType | configtype | R | 配置类型；取值见 global-enum.configtypewxsubdev |
| configVal | configval | R | 配置值；根据配置类型填写对应值（支付域名或支付appid）；支付域名与支付appid不支持同时配置 |

## 字段必填矩阵 - MerChantWxVerifyRequest

> 类说明：AT商户认证统一H5接口

> 响应类：AllinpayFrontResp

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| userId | userid | U | 文档尚未完全核实 |
| notifyUrl | notifyurl | U | 文档尚未完全核实 |
| pageType | pagetype | R | 页面类型；取值见 global-enum.pagetypewxverify |




## 商户进件复杂 JSON 字段约束

以下规则适用于 `subBranchList`、`prodList`、`rankFeeArr`、`picUrlJson`、`legalDetail`、`taxDetail`、`bnfDetail`。  
命中这些字段时，若未满足约束，必须返回“未完成核验/入参不合规”，禁止自行编造字段或枚举值。

### 1) subBranchList（门店信息数组）

| 字段 | 约束 |
|---|---|
| branchno | 可空（进件时可空）；长度 4 |
| branchname | 必填；长度 60；同一商户内门店名唯一 |
| branchaddr | 必填；长度 150 |
| contactperson | 必填；长度 30 |
| contactphone | 必填；长度 20 |
| districtcode | 必填；长度 10；区码见附录 |
| printnum | 可选；长度 2；默认 `2`（仅“商户进件并需配置终端”的门店有效） |
| termnum | 可选；长度 1；单门店最大终端数 10（仅“商户进件并需配置终端”的门店有效） |
| rejecttrxcodes | 可选；长度 100；交易类型白名单见下方“rejecttrxcodes 交易类型编码” |

### rejecttrxcodes 交易类型编码（禁止交易类型）

可取编码（按文档）：`VSP002`、`VSP003`、`VSP004`、`VSP005`、`VSP006`、`VSP007`、`VSP502`、`VSP503`、`VSP512`、`VSP513`、`VSP506`、`VSP507`、`VSP552`、`VSP553`、`VSP011`、`VSP013`、`VSP014`。  
示例：`VSP002,VSP003,VSP005`。

### 2) prodList（产品信息数组）

| 字段 | 约束 |
|---|---|
| pid | 必填；长度 8；可取：`P0001` 收银宝、`P0002` 当面付、`P0003` 网上收银、`P0004` 外卡收银 |
| mtrxcode | 必填；长度 20；交易类型见附录 |
| feerate | 必填；长度 8；单位千分之（如 `3.5` 表示千分之3.5） |
| creditrate | 可选；长度 8；单位千分之（贷贷分离商户必填） |
| feepen | 可选；长度 8；单位元/笔（仅网上收银-网关B2B等场景生效） |
| lowlimit | 可选；保底（元） |
| toplimit | 可选；封顶（元） |
| creditlowlimit | 可选；贷记卡保底（元） |
| credittoplimit | 可选；贷记卡封顶（元） |
| feecycle | 可选；如 `2` 日结、`4` 月结 |
| rankfeearr | 可选；阶梯费率 json 数组（字段见下方） |

### rankfeearr（阶梯费率数组）

| 字段 | 约束 |
|---|---|
| feerate | 可选；为千分比（如 `3.5` 表示千分之3.5） |
| creditrate | 可选；为千分比（如 `3.5` 表示千分之3.5） |
| lowlimit | 可选；保底（元） |
| toplimit | 可选；封顶（元） |
| creditlowlimit | 可选；贷记卡保底（元） |
| credittoplimit | 可选；贷记卡封顶（元） |
| rank | 可选；区间（元） |

### 3) picUrlJson（图片信息对象）

图片字段（值均为图片链接 URL，长度上限通常 256）：  
`settlebankpic`、`acctlicensepic`、`homepagepic`、`finalpagepic`、`peasonheadpic`、`orgcodepic`、`registerpic`、`authorpic`、`govercodepic`、`practiceprovepic`、`settauthpic`。  
约束：按文档要求上传对应类型图片；涉及“结算账户对私/对公不一致”等场景时对应字段必传，禁止随意置空。

### 4) legalDetail（法人信息对象）

| 字段 | 约束 |
|---|---|
| personTel | 必填；长度 11 |
| nationality | 必填；长度 50 |
| sex | 必填；长度 2；`1` 男，`2` 女 |
| occupation | 必填；长度 2；可取 `1~8`（国企机关人员/专业技术人员/办事人员/商业服务人员/农林牧渔人员/生产运输操作人员/军人/其他） |
| personAddr | 必填；长度 200 |

### 5) taxDetail（税务登记信息对象）

| 字段 | 约束 |
|---|---|
| taxregcode | 必填；长度 30 |
| taxcodeexpire | 必填；长度 10；日期格式 |
| taxcodepic | 必填；长度 256；税务登记证照片 URL |

### 6) bnfDetail（受益人信息对象）

| 字段 | 约束 |
|---|---|
| bnflag | 必填；长度 1；`0/1`（是否与法人信息一致） |
| bnfname | 与法人不一致时必填；长度 20 |
| bnftype | 必填；长度 2；`01` 身份证、`04` 港澳通行证、`05` 台胞证 |
| bnfidno | 与法人不一致时必填；长度 20 |
| bnfexpire | 与法人不一致时必填；长度 10；`yyyy-mm-dd` |
| mertype | 必填；长度 2；企业/事业单位/其他组织（按文档限定） |
| filetype | 必填；长度 2；材料类型编码（`61~68`，见下方） |
| fileurl | 必填；长度 256；证件材料 URL |
| personaddr | 必填；长度 200（与法人不一致时必填） |
| frnmgflag | 必填；长度 1；`0` 否、`1` 是 |
| bnflevel | 必填；长度 2；`1/2/3`（受益所有人判定层级） |
| nationality | 可选；长度 20 |
| sex | 可选；长度 2；`1` 男、`2` 女 |
| birthday | 可选；长度 10 |

#### bnfDetail.filetype 编码（mertype 联动）

`61` 注册证书(受益人)  
`62` 存续证明文件(受益人)  
`63` 公司章程(受益人)  
`64` 合伙协议(受益人)  
`65` 营业执照(受益人)  
`66` 授权书(控股受益人)  
`67` 年报(受益人)  
`68` 其他(受益人)

#### bnfDetail.mertype 说明（文档映射）

`1` 公司（不包含国有企业）  
`2` 合伙企业  
`3` 个人独资企业  
`4` 多政府控制的企业（国有企业）  
`5` 事业单位（不包含参照公务员法管理的事业单位）  
`6` 各级党的机关、国家权力机关、行政机关、司法机关、军事机关、人民政协机关和人民解放军、武警部队、参照公务员法管理的事业单位  
`7` 不具备法人资格的专业服务机构（如律师所、会计师事务所等）  
`8` 经营农林渔牧矿产业的非公司制农民专业合作组织  
`9` 社会团体、基金会、社会服务机构（民办非企业单位）和外国商会  
`10` 政府间国际组织、外国政府驻华使领馆及办事处等机构及组织


