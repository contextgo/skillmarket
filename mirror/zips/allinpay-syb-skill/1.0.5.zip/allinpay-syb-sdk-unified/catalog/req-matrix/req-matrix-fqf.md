# 字段必填矩阵 - Fqf

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - FqfApplyRequest

> 类说明：统一分期-分期付-分期支付申请

> 响应类：FqfApplyResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss |
| encryptType | encrypttype | R | 敏感信息加密方式；仅支持SM4 |
| trxAmt | trxamt | R | 交易金额；单位分 |
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 |
| acctNo | acctno | R | 分期账户号 |
| fqNum | fqnum | R | 分期期数,规则为3/6/9/12/18/24取值 |
| idNo | idno | R | 证件号；需SM4加密 |
| idType | idtype | R | 证件类型；取值见 global-enum.idtype |
| acctName | acctname | R | 户名；需SM4加密 |
| mobile | mobile | R | 手机号；需SM4加密 |
| currency | currency | R | 币种；当前仅支持CNY |
| subject | subject | R | 订单内容/订单标题 |
| validTime | validtime | O | 有效时间；以分钟为单位；默认5；最大1440 |
| trxReserve | trxreserve | O | 业务扩展字段 |
| notifyUrl | notifyurl | O | 异步通知地址；需公网可达 |

## 字段必填矩阵 - FqfBbSignPageRequest

> 类说明：统一分期-分期付-笔笔签协议获取

> 响应类：FqfBbSignPageResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss |
| trxAmt | trxamt | R | 交易金额；单位分 |
| acctNo | acctno | R | 银行卡号 |
| feeNum | feenum | R | 分期期数,规则为3/6/9/12/18/24取值 |

## 字段必填矩阵 - FqfInfoRequest

> 类说明：统一分期-分期付-获取分期信息

> 响应类：FqfInfoResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 |
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss |
| acctNo | acctno | R | 银行卡号 |

## 字段必填矩阵 - FqfJDBTCountFeeRequest

> 类说明：统一分期-分期付-京东白条利息计算

> 响应类：FqfJDBTCountFeeResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 金额；单位分 |

## 字段必填矩阵 - FqfJDBTPayRequest

> 类说明：统一分期-京东白条下单

> 响应类：FqfJDBTPayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 |
| body | body | O | 订单标题；为空则以商户名作为商品名称 |
| trxAmt | trxamt | R | 交易金额；单位分 |
| remark | remark | O | 备注信息 |
| fqNum | fqnum | R | 分期期数；取值见 global-enum.fqnumjdbt |
| validTime | validtime | O | 有效时间；以分钟为单位；不填默认5；最大60 |
| cusIp | cusip | R | 终端IP（用户下单和调起支付的终端IP地址） |
| notifyUrl | notify_url | O | 交易结果通知地址；需公网可达（刷卡支付场景该字段无效） |
| extendParams | extendparams | O | 扩展参数；Extendparams实体的json字符串 |

## 字段必填矩阵 - FqfJfqPayRequest

> 类说明：统一分期-聚分期下单

> 响应类：FqfJfqPayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | R | 分期核心字段 |
| encryptType | encrypttype | O | 按开通能力可选；若传入仅支持SM4 |
| trxAmt | trxamt | R | 分期核心字段; 格式提示： 金额单位为分 |
| unPid | unpid | O | 银联PID；仅支持代理商/服务商上送 |
| maskedAcctNo | maskedacctno | O | 卡号掩码；格式前6后4中间4个*；联合登录场景需同时上送手机号 |
| bankCode | bankcode | O | 指定银行分期支付时上送；指定单一银行时有效 |
| fqNum | fqnum | O | 商户指定分期期数，多个期数用&分隔，例如3&6&9 |
| senceFlag | senceflag | O | 场景标识；枚举见 global-enum.senceflag |
| idNo | idno | C | senceflag=01（保险实名认证）场景必填；需SM4加密 |
| trueName | truename | C | senceflag=01（保险实名认证）场景必填；需SM4加密 |
| mobile | mobile | C | 联合登录场景必填；手机号需SM4加密 |
| loginStatus | loginstatus | O | 登录状态；枚举见 global-enum.loginstatus；不上传默认为0 |
| retType | rettype | O | 同步返回请求方式；枚举见 global-enum.rettype；默认01 |
| validTime | validtime | O | 有效时间；以分钟为单位；不填默认5；最大1440 |
| frontUrl | front_url | O | 页面跳转同步通知地址 |
| notifyUrl | notify_url | R | 交易结果通知地址；通知url必须可直接访问且不能携带参数 |
| extendParams | extendparams | O | 拓展参数；json字符串（String） |

## 字段必填矩阵 - FqfPayConfirmRequest

> 类说明：统一分期-分期付-分期支付确认

> 响应类：FqfPayConfirmResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss |
| encryptType | encrypttype | R | 敏感信息加密方式；仅支持SM4 |
| trxAmt | trxamt | R | 交易金额；单位分 |
| reqSn | reqsn | R | 商户交易单号；与申请单保持一致 |
| acctNo | acctno | R | 分期账户号 |
| fqNum | fqnum | R | 分期期数,规则为3/6/9/12/18/24取值 |
| idNo | idno | R | 证件号；需SM4加密 |
| idType | idtype | R | 证件类型；取值见 global-enum.idtype |
| acctName | acctname | R | 户名；需SM4加密 |
| mobile | mobile | R | 手机号；需SM4加密 |
| currency | currency | R | 币种；当前仅支持CNY |
| subject | subject | R | 订单内容/订单标题 |
| validTime | validtime | O | 有效时间；以分钟为单位；不填默认5；最大1440 |
| trxReserve | trxreserve | O | 业务扩展字段 |
| notifyUrl | notifyurl | R | 交易结果通知地址；通知url必须可直接访问且不能携带参数 |
| smsCode | smscode | R | 短信验证码 |
| thpInfo | thpinfo | C | 交易透传信息；支付申请返回错误码1999时，需原样回传 |



