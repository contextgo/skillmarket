# 字段必填矩阵 - PreScanPay

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - PreScanPayCancelRequest

> 类说明：网上收银扫码预消费-扫码预消费交易回退

> 响应类：PreScanPayCancelResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | U | 本次请求流水 |
| trxAmt | trxamt | U | 交易金额,单位为分 |
| oldTrxId | oldtrxid | U | 预消费交易的收银宝平台流水 |

## 字段必填矩阵 - PreScanPayFinishRequest

> 类说明：网上收银扫码预消费-扫码预消费完成

> 响应类：PreScanPayFinishResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| autoBack | autoback | U | 需按接口文档核对 |
| reqSn | reqsn | U | 本次请求流水 |
| trxAmt | trxamt | U | 交易金额,单位为分 |
| oldTrxId | oldtrxid | U | 预消费交易的收银宝平台流水 |
| asInfo | asinfo | U | 分账信息；需开通分账配置 |

## 字段必填矩阵 - PreScanPayQueryRequest

> 类说明：网上收银扫码预消费-扫码预消费查询

> 响应类：PreScanPayQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | U | 本次请求流水 |
| trxId | trxid | U | 需按接口文档核对 |

## 字段必填矩阵 - PreScanPayRefundRequest

> 类说明：网上收银扫码预消费-扫码预消费完成交易退款

> 响应类：PreScanPayRefundResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | U | 本次请求流水 |
| trxAmt | trxamt | U | 交易金额,单位为分 |
| oldTrxId | oldtrxid | U | 预消费交易的收银宝平台流水 |

## 字段必填矩阵 - PreScanPayRequest

> 类说明：网上收银扫码预消费-扫码预消费

> 响应类：PreScanPayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 交易金额，单位为分 |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 |
| payType | paytype | R | 交易方式；取值见 global-enum.paytype |
| body | body | O | 订单标题；最大100个字节（约50个中文） |
| remark | remark | O | 备注信息；最大300个字节 |
| validTime | validtime | O | 订单有效时间（分钟）；不填默认5分钟；最大60分钟 |
| expireTime | expiretime | O | 绝对截止支付时间；格式yyyyMMddHHmmss |
| authCode | authcode | O | 支付授权码（微信/支付宝刷卡支付时的用户付款二维码） |
| acct | acct | O | 支付平台用户标识（如微信openid、支付宝user_id、小程序openid） |
| notifyUrl | notify_url | O | 交易结果通知地址；必须为可直接访问且不带参数的url；刷卡支付场景该字段无效 |
| limitPay | limit_pay | O | 支付限制；当前微信/支付宝场景常用no_credit；取值见 global-enum.limitpay |
| subAppid | sub_appid | O | 微信子appid（小程序/公众号/APP的appid）；仅对微信支付有效 |
| subBranch | subbranch | O | 门店号 |
| cusip | cusip | O | 终端ip（用户下单和调起支付的终端ip地址） |
| termInfo | terminfo | O | 终端信息json字符串；SCAN且支付宝/微信刷卡场景必填 |



