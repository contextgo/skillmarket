# 字段必填矩阵 - TrxShare

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TrxShareQueryRequest

> 类说明：分账交易查询

> 响应类：TrxShareQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | C | 商户平台分账流水号；与 `payerTrxId` 二选一 |
| payerTrxId | payertrxid | C | 分账成功的出金方通联交易单号；与 `reqSn` 二选一；同时上送时优先 `payerTrxId` |

## 字段必填矩阵 - TrxShareRevokeQueryRequest

> 类说明：分账回退交易查询

> 响应类：TrxShareRevokeQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | C | 商户平台分账回退流水号；与 `rkTrxId` 二选一 |
| rkTrxId | rktrxid | C | 通联分账回退交易单号；与 `reqSn` 二选一；同时上送时优先 `rkTrxId` |

## 字段必填矩阵 - TrxShareRevokeRequest

> 类说明：交易分账回退

> 响应类：TrxShareRevokeResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | R | 回退流水号；商户平台分账回退流水号；两个自然日内唯一 |
| payerTrxId | payertrxid | R | 出金交易单号；分账成功的出金方通联交易单号 |
| payerReqSn | payerreqsn | O | 出金方回退流水号；用于对账可空；回退的出金方则原分账交易的入金方 |
| trxAmt | trxamt | R | 回退金额；单位分 |
| remark | remark | R | 业务备注；最大 50 个文字 |

## 字段必填矩阵 - TrxShareShareRequest

> 类说明：交易分账

> 响应类：TrxShareShareResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | R | 分账流水号；商户平台分账流水号；两个自然日内唯一 |
| oldTrxId | oldtrxid | R | 交易单号；待分账交易的通联交易单号 |
| payeeCusId | payeecusid | R | 入金商户号 |
| payeeReqSn | payeereqsn | O | 入金商户流水号；用于对账，可空 |
| trxAmt | trxamt | R | 分账金额；单位分 |
| remark | remark | R | 分账备注；业务备注；最大 50 个文字 |


