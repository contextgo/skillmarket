# 字段必填矩阵 - PayScore

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - PayScorePayRequest

> 类说明：微信支付分-服务单扣款

> 响应类：PayScorePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outOrderNo | out_order_no | R | 商户系统内部服务订单号（非交易单号）；最长32位；仅数字和大小写字母；同一商户下唯一 |
| serviceId | serviceid | R | 服务id（微信分配） |
| reqSn | reqsn | R | 商户交易单号（扣款交易订单号）；保证商户平台唯一 |
| trxAmt | trxamt | R | 交易金额；单位为分；与支付单完成金额一致 |
| scene | scene | R | 交易场景；取值见 global-enum.scenepayscorepay |
| body | body | O | 订单标题；与创建服务单description一致；最大100个字节（约50个中文） |
| remark | remark | O | 备注信息；最大160个字节（约80个中文） |
| acct | acct | R | 支付平台用户标识；服务单中的微信sub_openid |
| notifyUrl | notify_url | O | 交易结果通知地址；必须为可直接访问且不带参数的url |
| termInfo | terminfo | R | 终端信息json字符串；详见附录 |
| randomStr | randomstr | R | 商户自行生成的随机字符串 |

## 字段必填矩阵 - PayScoreServiceOrderRequest

> 类说明：微信支付分请求接口 (bizData 需按 JSON->UTF8->Base64 编码，对应接口编号映射实体)

> 响应类：PayScoreServiceOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| tranCode | trancode | R | 接口编号；取值见 global-enum.trancodepayscoreserviceorder |
| serviceId | serviceid | R | 服务id（微信分配） |
| bizData | bizdata | R | 业务参数须使用 `JsonUtils.toJson(bizObj)` 生成 JSON（import `com.allinpay.syb.sdk.core.utils.JsonUtils`），再做 JSON -> UTF-8 -> Base64；实体映射见 global-enum.bizdatapayscore；禁止 Map/手写 JSON/宣称 SDK 自动转 JSON |

## 字段必填矩阵 - PayScoreTCPermissionAdd

> 类说明：微信支付分-服务单扣款 - 微信支付分-预授权(免确认服务单)

> 响应类：PayScorePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| authorizationAode | authorization_code | R | 授权协议号；预授权成功后的授权协议号 |
| subAppid | sub_appid | O | 子商户的公众号ID；微信公众平台分配且与传入子商户号建立支付绑定关系的AppID |
| notifyUrl | notify_url | R | 授权成功回调通知地址 |

## 字段必填矩阵 - PayScoreTCPermissionDel

> 类说明：微信支付分-服务单扣款 - 微信支付分-解除预授权(免确认服务单)

> 响应类：PayScorePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| authorizationAode | authorization_code | U | 授权协议号；预授权成功后的授权协议号 |
| reason | reason | U | 撤销原因 |

## 字段必填矩阵 - PayScoreTCPermissionGet

> 类说明：微信支付分-服务单扣款 - 微信支付分-预授权查询(免确认服务单)

> 响应类：PayScorePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| authorizationAode | authorization_code | U | 授权协议号；预授权成功后的授权协议号 |

## 字段必填矩阵 - PayScoreTCServiceOrderAdd

> 类说明：微信支付分-服务单扣款 - 微信支付分-创建支付分服务单

> 响应类：PayScorePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outOrderNo | out_order_no | R | 商户系统内部服务订单号（非交易单号）；最长32位；仅数字和大小写字母；同一商户下唯一 |
| serviceIntroduction | service_introduction | R | 服务信息，用于介绍本订单所提供的服务 |
| postPayments | post_payments | R | 后付费项目数组，最多100条；用于展示与完结订单总金额计算；name必填；name非空时amount/description二者至少填一项；完结订单接口中name和amount必填 |
| postDiscounts | post_discounts | O | 商户优惠数组，最多30条；用于展示与完结订单总金额计算；name和description选填但若填写则均需填写；完结订单中name和description非空时amount必填；优惠项目名称可重复 |
| riskFund | risk_fund | R | 服务风险金对象；用于微信支付分本次服务风险评估 |
| timeRange | time_range | R | 服务时间对象；用于用户侧展示 |
| location | location | O | 服务位置对象；用于用户侧展示 |
| subAppid | sub_appid | O | 子商户公众号ID；微信公众平台分配且与传入子商户号建立支付绑定关系的AppID |
| subOpenid | sub_openid | O | 子商户AppID下的用户标识 |
| needUserConfirm | need_user_confirm | O | 是否需要用户确认；true=需要确认，false=不需要（默认false） |
| notifyUrl | notify_url | R | 回调通知地址 |
| attach | attach | R | 附加数据；可作为自定义参数使用；上送前需先urlencode |

## 字段必填矩阵 - PayScoreTCServiceOrderCancel

> 类说明：微信支付分-服务单扣款 - 微信支付分-取消支付分服务单

> 响应类：PayScorePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outOrderNo | out_order_no | U | 商户系统内部服务订单号（不是交易单号）要求32个字符内，只能是数字、大小写字母 且在同一个商户号下唯一 |
| reason | reason | U | 撤销原因 |

## 字段必填矩阵 - PayScoreTCServiceOrderComplete

> 类说明：微信支付分-服务单扣款 - 微信支付分-完结支付分服务单

> 响应类：PayScorePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outOrderNo | out_order_no | R | 商户系统内部服务订单号（非交易单号）；最长32位；仅数字和大小写字母；同一商户下唯一 |
| postPayments | post_payments | R | 后付费项目数组，最多100条；创建/完结服务单格式一致；name必填；name非空时amount/description二者至少填一项；完结服务单中name和amount必填 |
| postDiscounts | post_discounts | O | 商户优惠数组，最多30条；创建/完结服务单格式一致；name和description选填但若填写则均需填写；完结服务单中name和description非空时amount必填；优惠项目名称可重复 |
| totalAmount | total_amount | R | 总金额（单位分，整数>=0）；计算公式：付费项目合计-商户优惠合计；风控上限：交押金模式需<=“订单风险金”，拒绝模式需<=“服务风险金额” |
| timeRange | time_range | O | 实际服务时间对象；创建单未填写服务结束时间时，完结时需补服务结束时间 |
| location | location | O | 实际服务位置对象；覆盖创建订单中的服务位置，用于用户侧展示 |
| completeTime | complete_time | R | 完结服务时间；必须使用ISO 8601格式（如 YYYY-MM-DDTHH:mm:ss.SSSZ / YYYY-MM-DDTHH:mm:ssZ / YYYY-MM-DDTHH:mm:ss.SSS+08:00 / YYYY-MM-DDTHH:mm:ss+08:00） |

## 字段必填矩阵 - PayScoreTCServiceOrderGet

> 类说明：微信支付分-服务单扣款 - 微信支付分-查询支付分服务单

> 响应类：PayScorePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outOrderNo | out_order_no | R | 商户系统内部服务订单号（非交易单号）；最长32位；仅数字和大小写字母；同一商户下唯一；与query_id二选一至少填一项 |
| queryId | query_id | R | 单据查询ID（微信回跳到商户前端时携带）；与out_order_no二选一至少填一项 |



