# 字段必填矩阵 - Activity

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - ActivityActivityPageRequest

> 类说明：活动报名h5接口

> 响应类：AllinpayFrontResp

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| actId | actid | O | 按场景可选，若传入则不能为空；取值见 global-enum.actid |
| userId | userid | U | 文档尚未完全核实 |

## 字段必填矩阵 - ActivityCusActivityRequest

> 类说明：商户活动报名API接口

> 响应类：ActivityCusActivityResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| corpBusName | corpbusname | U | 营业执照名称 |
| branchName | branchname | U | 门店名称 |
| areaCode | areacode | U | 所在地区,例如：广东省广州市荔湾区 |
| address | address | U | 详细 |
| actType | acttype | O | 按场景可选，若传入则不能为空；取值见 global-enum.acttype |
| zipPicUrl | zippicurl | U | 报送资料，图片压缩包url |
| notifyUrl | notifyurl | U | 回调url |
| actDetail | actdetail | C | acttype=04/07/08/09/10/11 时必填；acttype=12 时不填；JSON字符串; |

## 字段必填矩阵 - ActivityQueryActivityRequest

> 类说明：活动状态查询

> 响应类：ActivityQueryActivityResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| actType | acttype | U | 按场景可选，若传入则不能为空；取值见 global-enum.acttype |


