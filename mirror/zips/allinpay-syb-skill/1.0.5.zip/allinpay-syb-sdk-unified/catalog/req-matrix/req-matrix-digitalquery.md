# 字段必填矩阵 - DigitalQuery

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - DigitalQueryAuthCusStateRequest

> 类说明：查询商户授权关系接口

> 响应类：DigitalQueryAuthCusStateResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| digTalId | digtalid | R | 应用ID |
| innerAppid | innerappid | O | 通联分配的内部应用ID；innerappid模式下与商户号匹配使用 |
| authCusId | authcusid | R | 授权商户号 |


