# 字段必填矩阵 - UnConscsPay

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - UnConscsPayAgreeApplyRequest

> 类说明：云闪付支付API-无感支付-签约

> 响应类：UnConscsPayAgreeApplyResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| merUserId | meruserid | R | 会员编号；签约持卡人在商户所属会员编号 |
| applyId | applyid | R | 申请 id；商户申请协议流水 |
| appType | apptype | R | 应用类型；取值见 global-enum.apptypeunconscspayagreeapply |
| appName | appname | R | 应用名称；`apptype=01` 填小程序 id，`apptype=02` 填包名，`apptype=03` 填公众号 id |
| appPath | apppath | O | 回调应用路径；`apptype=01` 填小程序 path，`apptype=02` 填应用 scheme，`apptype=03` 为空 |
| notifyUrl | notify_url | R | 签约完成通知地址；url 不能含参数 |
| planId | planid | R | 银联商户合约号 |

## 字段必填矩阵 - UnConscsPayAgreePayRequest

> 类说明：云闪付支付API-无感支付-支付

> 响应类：UnConscsPayAgreePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| agreeId | agreeid | R | 协议号；签约协议号（签约结果通知获取） |
| trxAmt | trxamt | R | 交易金额；单位分 |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 |
| subject | subject | O | 订单标题；最大 100 个字节（约 50 个中文字符） |
| remark | remark | O | 备注信息 |
| notifyUrl | notify_url | O | 交易结果通知地址；必须为直接可访问的 url，不能携带参数 |
| planId | planid | R | 银联商户合约号 |

## 字段必填矩阵 - UnConscsPayAgreeUnbindRequest

> 类说明：云闪付支付API-无感支付-解约

> 响应类：UnConscsPayAgreeUnbindResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| applyId | applyid | R | 签约成功通联通知的协议编号 |

## 字段必填矩阵 - UnConscsPayAndSignRequest

> 类说明：云闪付支付API-无感支付-支付并签约

> 响应类：UnConscsPayAndSignResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 |
| subject | subject | O | 订单标题；最大 100 个字节（约 50 个中文字符） |
| remark | remark | O | 备注信息 |
| validTime | validtime | R | 订单有效时间；单位分钟；最大 60 |
| appType | apptype | R | 应用类型；取值见 global-enum.apptypeunconscspayagreeapply |
| appName | appname | R | 应用名称；`apptype=01` 填小程序 id，`apptype=02` 填包名，`apptype=03` 填公众号 id |
| appPath | apppath | O | 回调应用路径；`apptype=01` 填小程序 path，`apptype=02` 填应用 scheme，`apptype=03` 为空 |
| merUserId | meruserid | R | 会员编号；签约持卡人在商户所属会员编号（用于签约） |
| applyId | applyid | R | 申请 id；商户申请协议流水（用于签约） |
| notifyUrl | notify_url | O | 交易结果通知地址；必须为直接可访问的 url，不能携带参数 |
| agreeNotifyUrl | agree_notifyurl | R | 签约结果通知；必须为直接可访问的 url，不能携带参数 |
| planId | planid | R | 银联商户合约号 |

## 字段必填矩阵 - UnConscsPayTokenApplyRequest

> 类说明：云闪付支付API-签约支付-签约

> 响应类：UnConscsPayTokenApplyResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| merUserId | meruserid | R | 会员编号；签约持卡人在商户所属会员编号 |
| merUserRegitDate | meruserregitdate | R | 会员注册日期 |
| merUserLoginMet | meruserloginmet | R | 会员登录方式；录密码/动码/人脸（FACEID 指纹视为 1） |
| encryptType | encrypttype | R | 敏感字段加密方式；当前仅支持 `SM4` |
| acctNo | acctno | O | 银行卡号；SM4 加密；为空时在银联页面选择签约卡号 |
| idNo | idno | R | 证件号；SM4 加密 |
| idType | idtype | R | 证件类型；取值见 global-enum.idtype |
| acctName | acctname | R | 户名；SM4 加密 |
| mobile | mobile | R | 手机号码；SM4 加密 |
| bankCode | bankcode | O | 银行编码；为空时银联签约页面展示所有银行卡 |
| acctType | accttype | O | 卡类型；常见值 `00` 借记卡、`02` 贷记卡 |
| chnlTrId | chnltrid | R | 渠道标记 id（银联分配） |
| tokenType | tokentype | R | Token 类型（银联分配） |
| deviceId | deviceid | R | 设备 id |
| faceType | facetype | O | 人脸验证方式；取值见 global-enum.facetypeunconscspaytokenapply |
| faceOrder | faceorder | C | 人脸订单号；`faceType=2` 时上送 |
| faceApp | faceapp | C | 人脸云服务 ID；`faceType=2` 时上送 |
| invokeType | invoketype | O | 拉起方式；小程序上送；取值见 global-enum.invoketypeunconscspaytokenapply |
| wxAppId | wxappid | C | 小程序 id；小程序上送 |
| notifyUrl | notify_url | R | 签约完成通知地址；url 不能含参数 |
| retUrl | returl | R | 前端跳转地址；url 不能含参数 |

## 字段必填矩阵 - UnConscsPayTokenPayRequest

> 类说明：云闪付支付API-签约支付-支付

> 响应类：UnConscsPayTokenPayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| applyId | applyid | R | 协议号；签约协议号（签约结果通知获取） |
| trxAmt | trxamt | R | 交易金额；单位分 |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 |
| subject | subject | O | 订单标题；最大 100 个字节（约 50 个中文字符） |
| remark | remark | O | 备注信息 |
| chnlTrId | chnltrid | R | 渠道标记 id（银联分配） |
| smsCode | smscode | O | 短信验证码；免校验支付时可空 |
| thpInfo | thpinfo | O | 校验信息；获取短信验证码接口原样返回的校验信息 |
| notifyUrl | notify_url | O | 交易结果通知地址；必须为直接可访问的 url，不能携带参数 |

## 字段必填矩阵 - UnConscsPayTokenSetNoverRequest

> 类说明：云闪付支付API-签约支付-小额免检申请

> 响应类：UnConscsPayTokenSetNoverResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| applyId | applyid | R | 协议号；签约协议号（签约结果通知获取） |
| chnlTrId | chnltrid | R | 渠道标记 id（银联分配） |
| openType | opentype | R | 开启类型；取值见 global-enum.opentypeunconscspaytokensetnover |

## 字段必填矩阵 - UnConscsPayTokenSmsRequest

> 类说明：云闪付支付API-签约支付-交易短信验证码申请

> 响应类：UnConscsPayTokenSmsResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| agreeId | agreeid | R | 协议号；签约协议号（签约结果通知获取） |
| chnlTrId | chnltrid | R | 渠道标记 id（银联分配） |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 |
| trxAmt | trxamt | R | 交易金额；单位分 |
| subject | subject | O | 订单标题；最大 100 个字节（约 50 个中文字符） |
| remark | remark | O | 备注信息；最大 160 个字节（约 80 个中文字符） |

## 字段必填矩阵 - UnConscsPayTokenUnbindRequest

> 类说明：云闪付支付API-签约支付-解约

> 响应类：UnConscsPayTokenUnbindResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| applyId | applyid | R | 协议号；签约协议号（签约结果通知获取） |
| chnlTrId | chnltrid | R | 渠道标记 id（银联分配） |



