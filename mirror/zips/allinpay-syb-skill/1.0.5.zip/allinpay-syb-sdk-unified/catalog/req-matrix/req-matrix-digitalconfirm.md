# 字段必填矩阵 - DigitalConfirm

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - DigitalConfirmAuthCusStateRequest

> 类说明：应用授权审核状态变更接口

> 响应类：DigitalConfirmAuthCusStateResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| digId | digid | R | 应用ID |
| confirmStatus | confirmstatus | O | 审核状态；枚举见 global-enum.confirmstatus；默认1 |


