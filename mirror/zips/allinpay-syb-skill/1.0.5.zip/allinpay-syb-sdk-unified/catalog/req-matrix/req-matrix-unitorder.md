# 字段必填矩阵 - UnitOrder

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - UnitOrderAuthCode2UserIdRequset

> 类说明：支付宝吱口令生成请求参数 - 根据授权码(付款码)获取用户ID请求参数

> 响应类：UnitOrderAuthCode2UserIdResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| authCode | authcode | R | 授权码（付款码） |
| authType | authtype | R | 授权码类型；取值见 global-enum.authtypeunitorderauthcode2userid |
| identify | identify | O | 云闪付 UA 标识；`authType=02` 时建议上送 |
| subAppid | sub_appid | O | 微信支付 appid；仅对 `authType=01` 有效 |

## 字段必填矩阵 - UnitOrderCloseNativeRequset

> 类说明：支付宝吱口令生成请求参数 - 统一主扫关闭接口

适用场景：仅限统一主扫接口产生的“处理中”交易发起关闭，或使已生成的二维码即时失效。

> 响应类：UnitOrderCloseNativeResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| oldReqSn | oldreqsn | C | 原商户订单号；置二维码失效时可填写；与 `oldTrxId` 二选一 |
| oldTrxId | oldtrxid | C | 原通联平台交易流水；与 `oldReqSn` 二选一；同时上送时优先使用 `oldTrxId` |

## 字段必填矩阵 - UnitOrderCreateZhiRequest

> 类说明：支付宝吱口令生成请求参数

适用场景：生成支付宝口令。若交易源自“接口令导流”，下单接口（统一支付）的 `extendparams` 需增加 `direct_wx_source=indirect_wx_ALLINPAY`。

> 响应类：UnitOrderCreateZhiResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | O | 商户交易单号；保证商户平台唯一 |
| bizLink | bizlink | R | 跳转业务链接（初始商户支付页面） |
| trxAmt | trxamt | R | 需要支付的金额；单位分 |
| validTime | validtime | O | 有效期；单位秒 |
| title | title | O | 标题 |
| zhiType | zhitype | O | 口令类型；取值见 global-enum.zhitypeunitordercreatezhi；不填默认 `01` |

## 字段必填矩阵 - UnitOrderNativePayRequest

> 类说明：统一主扫请求参数

> 响应类：UnitOrderNativePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 |
| body | body | O | 订单标题；最大 100 个字节（约 50 个中文字符） |
| remark | remark | O | 备注信息；最大 160 个字节 |
| expireTime | expiretime | R | 订单超时时间；格式 `yyyyMMddHHmmss` |
| subBranch | subbranch | O | 门店号 |
| limitPay | limit_pay | O | 支付限制；当前仅支持 `no_credit`（暂对微信支付/支付宝有效） |
| idNo | idno | O | 证件号；实名交易必填，填写后校验证件号与姓名（暂仅支持支付宝） |
| trueName | truename | O | 付款人真实姓名；实名交易必填，填写后校验证件号与姓名（暂仅支持支付宝） |
| asInfo | asinfo | O | 分账信息；格式 `cusid:type:amount[,cusid:type:amount...]`；type：`01` 按金额、`02` 按比例（02 时 `0.5` 表示 50%） |
| goodsTag | goods_tag | O | 商品标志；用于区分是否可享受优惠（暂只对微信有效） |
| benefitDetail | benefitdetail | O | 优惠信息；String；填写格式详见附录（微信单品优惠/支付宝智慧门店） |
| chnlStoreId | chnlstoreid | O | 渠道门店编号 |
| fqNum | fqnum | O | 花呗分期；支持 `3/6/12` 期 |
| extendParams | extendparams | O | 扩展参数；String 类型 JSON 字符串 |
| notifyUrl | notify_url | O | 服务异步通知页面路径；可直接访问且不携带参数；若使用 https 需默认 443 端口 |
| frontUrl | front_url | O | 页面跳转同步通知页面路径；必须为 https 且不允许携带参数 |

## 字段必填矩阵 - UnitOrderPayRequest

> 类说明：统一支付请求参数

> 响应类：UnitOrderPayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 |
| reqSn | reqsn | C | 商户交易单号；与 `uniReqSn` 二选一；当两者并存时以 `reqSn` 原有逻辑处理 |
| uniReqSn | unireqsn | C | 唯一订单号；与 `reqSn` 二选一；可跨微信/支付宝/云闪付复用，存在未支付订单时会关单处理 |
| payType | paytype | R | 交易方式；详见附录交易方式（含 W11） |
| body | body | O | 订单标题；最大 100 个字节（约 50 中文） |
| remark | remark | O | 备注信息；最大 300；禁止 `+`、空格、`/`、`?`、`%`、`#`、`&`、`=` 等特殊符号 |
| validTime | validtime | O | 订单有效时间；单位分钟；不填默认 5；最大 1440；`W01` 最大 120 |
| expireTime | expiretime | O | 截止支付时间；格式 `yyyyMMddHHmmss` |
| acct | acct | C | 支付平台用户标识；`JS/小程序` 等场景使用（微信 openid / 支付宝 user_id / 云闪付 userId） |
| notifyUrl | notify_url | O | 交易结果异步通知地址；需直接可访问且不携带参数；https 支持默认端口 |
| limitPay | limit_pay | O | 支付限制；值见 global-enum.limitpay（微信/支付宝常用 `no_credit`） |
| subAppid | sub_appid | O | 微信子 appid；仅对微信支付有效 |
| goodsTag | goods_tag | O | 订单优惠标记；仅对微信有效，`W01` 不支持 |
| benefitDetail | benefitdetail | O | 优惠信息；JSON 字符串；微信单品优惠/支付宝单品优惠/智慧门店场景使用，`W01` 不支持 |
| chnlStoreId | chnlstoreid | O | 渠道门店编号；`W01` 不支持 |
| subBranch | subbranch | O | 门店号（通联系统门店号） |
| extendParams | extendparams | O | 拓展参数；JSON 字符串（String） |
| cusIp | cusip | C | 终端 IP；`payType=U02`（云闪付 JS 支付）不可为空 |
| frontUrl | front_url | C | 支付完成跳转地址；必须 https 且不能带参数；仅 `payType=U02` 或 `payType=W02` 场景支持 |
| idNo | idno | O | 证件号；实名交易必填；暂仅支持支付宝；微信仅刷卡支付例外 |
| trueName | truename | O | 付款人真实姓名；实名交易必填；暂仅支持支付宝；微信仅刷卡支付例外 |
| asInfo | asinfo | O | 分账信息；格式 `cusid:type:amount[,cusid:type:amount...]`；`W11` 不支持 |
| fqNum | fqnum | O | 分期；值见 global-enum.fqnum；支付宝花呗/信用卡分期（仅支持 A01/A02） |
| unPid | unpid | O | 银联 pid |
| finOrg | finorg | O | 金融机构号；`payType=N03` 必填（暂仅支持翼支付） |
| operatorId | operatorid | O | 收银员号 |
| iscofee | iscofee | O | 是否启用手续费补贴；`0` 否，`1` 商户累计补贴 |

## 字段必填矩阵 - UnitOrderScanQrPayRequest

> 类说明：统一被扫请求参数

> 响应类：UnitOrderScanQrPayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 |
| body | body | O | 订单标题；最大 100 个字节（约 50 个中文字符） |
| remark | remark | O | 备注信息；最大 160；禁止 `+`、空格、`/`、`?`、`%`、`#`、`&`、`=` 等特殊符号 |
| authCode | authcode | R | 支付授权码；如微信/支付宝/银联付款二维码 |
| limitPay | limit_pay | O | 支付限制；当前仅支持 `no_credit`，暂只对微信支付/支付宝有效 |
| goodsTag | goods_tag | O | 订单优惠标记；仅对微信支付有效 |
| benefitDetail | benefitdetail | O | 优惠信息；JSON 字符串（String）；微信单品优惠/支付宝智慧门店/银联云闪付单品优惠 |
| subAppid | sub_appid | O | 微信子 appid；仅对微信支付有效 |
| chnlStoreId | chnlstoreid | O | 渠道门店编号；用于支付宝/微信渠道门店号上送 |
| subBranch | subbranch | O | 门店号 |
| idNo | idno | O | 证件号；实名交易必填；暂只支持支付宝 |
| extendParams | extendparams | O | 拓展参数；JSON 字符串（String） |
| trueName | truename | O | 付款人真实姓名；实名交易必填；暂只支持支付宝 |
| asInfo | asinfo | O | 分账信息；格式 `cusid:type:amount[,cusid:type:amount...]`；type：`01` 按金额、`02` 按比例（0.5 表示 50%） |
| fqNum | fqnum | O | 分期；值见 global-enum.fqnum；暂仅支持支付宝花呗分期/支付宝信用卡分期 |
| notifyUrl | notify_url | O | 交易结果通知地址；需直接可访问且不携带参数；若使用 https 需默认 443 端口 |
| unPid | unpid | O | 银联 pid；仅支持代理商/服务商角色调用 |
| termInfo | terminfo | R | 终端信息；JSON 字符串，详见终端字段说明 |
| operatorId | operatorid | O | 收银员号 |

## 字段必填矩阵 - UnitOrderWxFacePayInfoRequset

> 类说明：支付宝吱口令生成请求参数 - 微信人脸授权码获取请求参数

> 响应类：UnitOrderWxFacePayInfoResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| storeId | storeid | R | 门店编号；由商户定义，各门店唯一 |
| storeName | storename | R | 门店名称；由商户定义 |
| deviceId | deviceid | O | 终端设备编号；由商户定义 |
| attach | attach | O | 附加字段；字符串格式，使用 JSON |
| rawData | rawdata | R | 初始化数据；由微信人脸 SDK 返回；可通过微信官方刷脸支付接口 `getWxpayfaceRawdata` 获取 |
| subAppId | subappid | O | 微信支付 appid |



