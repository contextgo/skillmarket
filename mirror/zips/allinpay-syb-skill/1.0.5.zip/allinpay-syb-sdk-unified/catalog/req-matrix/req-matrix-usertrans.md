# 字段必填矩阵 - UserTrans

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - UserTransCusPayRequest

> 类说明：自带参数的当面付订单接口

> 响应类：AllinpayFrontResp

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| c | c | R | 二维码 ID（通联分配） |
| oid | oid | C | 订单编号；与 `uniReqSn` 二选一 |
| uniReqSn | unireqsn | C | 唯一订单编号；与 `oid` 二选一；当两者并存时优先取 `oid` 原有逻辑 |
| amt | amt | R | 交易金额；单位分 |
| retUrl | returl | R | 成功支付跳转地址；必须 https 且不能携带参数；`trxReserve` 必填 |
| trxReserve | trxreserve | R | 业务备注信息；参见订单详情标签个性化说明 |
| submitTime | submittime | R | 截止支付时间；格式 `yyyyMMddHHmmss` |
| extendParams | extendparams | O | 扩展参数；JSON 字符串（String） |
| asInfo | asinfo | O | 分账参数；格式 `cusid:type:amount[,cusid:type:amount...]`；type：`01` 按金额、`02` 按比例（0.5 表示 50%） |


