# 字段必填矩阵 - TrxFile

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TrxFileGetRequest

> 类说明：获取对账单接口

> 响应类：TrxFileGetResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| date | date | R | 交易日期；格式 yyyymmdd |
| fileType | filetype | O | 对账单类型；当前值为 `1`；取值见 global-enum.fileType |

## 字段必填矩阵 - TrxFileSettTrxRequest

> 类说明：获取结算单接口

> 响应类：TrxFileSettTrxResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| settDate | settdate | R | 结算日期；格式 yyyymmdd |


