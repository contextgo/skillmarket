# 字段必填矩阵 - CusAcct

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - CusAcctQueryAcctOverLimitRequest

> 类说明：商户授信资金查询接口

> 响应类：CusAcctQueryAcctOverLimitResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|

## 字段必填矩阵 - CusAcctQueryBalanceRequest

> 类说明：商户账户余额查询

> 响应类：CusAcctQueryBalanceResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| acctType | accttype | R | 查询类型；枚举见 global-enum.accttype |

## 字段必填矩阵 - CusAcctQueryHisBalanceRequest

> 类说明：商户账户历史余额查询

> 响应类：CusAcctQueryHisBalanceResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| acctDate | acctdate | R | 历史日期；格式YYYYMMDD（8位） |

## 字段必填矩阵 - CusAcctQueryTrxRequest

> 类说明：商户余额转账交易查询

> 响应类：CusAcctQueryTrxResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxType | trxtype | R | 查询类型；枚举见 global-enum.trxtype |
| trxId | trxid | C | trxId/reqSn 二选一，优先trxId |
| reqSn | reqsn | C | trxId/reqSn 二选一 |

## 字段必填矩阵 - CusAcctTransferBalRequest

> 类说明：商户账户余额转账

> 响应类：CusAcctTransferBalResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| payerCusId | payercusid | R | 付款商户号；当前仅支持与cusid相等；长度15 |
| payeeCusId | payeecusid | R | 转入方商户号 |
| trxAmt | trxamt | R | 转账金额；单位分 |
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 |
| remark | remark | O | 备注信息 |

## 字段必填矩阵 - CusAcctWithDrawQueryRequest

> 类说明：商户账户余额结算查询

> 响应类：CusAcctWithDrawQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxId | trxid | C | trxId/reqSn 二选一，优先trxId |
| reqSn | reqsn | C | trxId/reqSn 二选一 |

## 字段必填矩阵 - CusAcctWithDrawRequest

> 类说明：商户账户余额结算

> 响应类：CusAcctWithDrawResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 提现金额；单位分 |
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 |
| depType | deptype | R | 结算类型；枚举见 global-enum.deptype |
| remark | remark | O | 备注信息 |
| summary | summary | O | 摘要信息 |


