# 字段必填矩阵 - ZhimaCredit

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

说明：ZhimaCredit 系列 request 字段较多且业务结构特殊，当前不强制约束字段是否必填，统一以 `U` 标记为待核实。

## 字段必填矩阵 - ZhimaCreditMiniOrderRequest

> 类说明：支付宝先享后付请求接口 (bizData 需按 JSON->UTF8->Base64 编码，对应接口编号映射实体)

> 响应类：ZhimaCreditMiniOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| tranCode | trancode | U | 接口编号；取值见 global-enum.trancodezhima，且必须与 bizData 业务实体一一对应 |
| serviceId | serviceid | U | 服务id |
| bizData | bizdata | U | 业务参数须使用 `JsonUtils.toJson(bizObj)` 生成 JSON（import `com.allinpay.syb.sdk.core.utils.JsonUtils`），再做 json->utf8->base64；实体映射见 global-enum.bizdatazhima；禁止 Map/手写 JSON/宣称 SDK 自动转 JSON |
| id | id | U | 本次通知流水 |

## 字段必填矩阵 - ZhimaCreditPayRequest

> 类说明：支付宝先享后付-业务订单扣款

> 响应类：ZhimaCreditPayOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | U | 交易金额 单位为分 |
| reqSn | reqsn | U | 商户交易单号 |
| body | body | U | 订单标题 |
| remark | remark | U | 备注 |
| asInfo | asinfo | U | 分账信息 |
| extendParams | extendparams | U | 扩展参数 |
| termInfo | terminfo | U | 终端信息 |
| validTime | validtime | U | 有效时间 |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderChanged

> 类说明：支付宝先享后付请求接口 - 接口编号映射实体 - 业务状态变更通知

> 响应类：ZhimaCreditMiniOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outOrderId | out_order_id | U | 商户订单号 |
| orderId | order_id | U | 交易组件订单号 |
| tradeNo | trade_no | U | 支付宝交易号 |
| status | status | U | 交易状态 |
| operateAppId | operate_app_id | U | 开发者应用ID |
| authAppId | auth_app_id | U | 授权方应用ID |
| totalAmount | total_amount | U | 订单金额 |
| receiptAmount | receipt_amount | U | 实收金额 |
| secureReason | secure_reason | U | 安全处置原因 |
| groupBuyInfo | group_buy_info | U | 拼团信息 |
| userId | user_id | U | 买家支付宝用户ID |
| openId | open_id | U | 用户openId |
| settleType | settle_type | U | 账期标识 |
| voucherDetailList | voucher_detail_list | U | 券明细 |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderClose

> 类说明：支付宝先享后付请求接口 - 接口编号映射实体 - 业务订单关闭

> 响应类：ZhimaCreditMiniOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outOrderId | out_order_id | U | 商户订单号 |
| orderId | order_id | U | 交易组件订单号 |
| userId | user_id | U | 买家支付宝用户 |
| openId | open_id | U | 支付宝用户open_id |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderCreate

> 类说明：支付宝先享后付请求接口 - 接口编号映射实体 - 业务订单创建

> 响应类：ZhimaCreditMiniOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outOrderId | out_order_id | U | 商户订单号 |
| title | title | U | 订单标题 |
| sourceId | source_id | U | 追踪ID |
| merchantBizType | merchant_biz_type | U | 订单类型 |
| path | path | U | 商家小程序对应的订单详情页路径地址 |
| orderDetail | order_detail | U | 订单信息 |
| sellerId | seller_id | U | 卖家支付宝用户ID |
| buyerId | buyer_id | U | 买家ID |
| buyerOpenId | buyer_open_id | U | 买家支付宝用户唯一标识 |
| buyerLogonId | buyer_logon_id | U | 买家支付宝登录账号 |
| shopInfo | shop_info | U | 门店信息 |
| creditInfo | credit_info | U | 芝麻信用信息 |
| stagePayPlans | stage_pay_plans | U | 阶段付款计划 |
| contactInfo | contact_info | U | 买家联系人信息 |
| addressInfo | address_info | U | 订单收货地址 |
| promoDetaiInfo | promo_detai_info | U | 订单优惠信息 |
| extInfo | ext_info | U | 订单扩展字段 |
| deliveryDetail | delivery_detail | U | 物流信息 |
| defaultReceivingAddress | default_receiving_address | U | 默认退货地址 |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderCreditAgreeChanged

> 类说明：支付宝先享后付请求接口 - 接口编号映射实体 - 服务开通/授权状态变更通知

> 响应类：ZhimaCreditMiniOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| creditAgreementId | credit_agreement_id | U | 开通/授权协议号 |
| title | title | U | 订单标题 |
| agreementStatus | agreement_status | U | 开通/授权状态 |
| outAgreementNo | out_agreement_no | U | 商户外部协议号 |
| bizTime | biz_time | U | 开通/授权状态变更的时间 |
| openChannel | open_channel | U | 开通渠道 |
| alipayUserId | alipay_user_id | U | 用户ID |
| openId | open_id | U | 开放ID |
| extInfo | ext_info | U | 扩展字段 |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderCreditAgreeQuery

> 类说明：支付宝先享后付请求接口 - 接口编号映射实体 - 使用商户外部协议号或开通/授权协议号，查询服务开通/授权信息

> 响应类：ZhimaCreditMiniOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outAgreementNo | out_agreement_no | U | 商户外部协议号 |
| creditAgreementId | credit_agreement_id | U | 开通/授权协议号 |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderInstallmentCreate

> 类说明：支付宝先享后付请求接口 - 接口编号映射实体 - 创建分期单

> 响应类：ZhimaCreditMiniOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outInstallmentOrderId | out_installment_order_id | U | 外部分期单号 |
| type | type | U | 分期类型 |
| orderId | order_id | U | 交易组件订单号 |
| outOrderId | out_order_id | U | 外部商户订单号 |
| userId | user_id | U | 买家ID |
| openId | open_id | U | 支付宝用户唯一标识 |
| installmentPrice | installment_price | U | 分期金额 |
| installmentNo | installment_no | U | 本次分期号 |
| tradeNo | trade_no | U | 交易号 |
| isFinishPerformance | is_finish_performance | U | 分期是否完结 |
| payChannel | pay_channel | U | 分期单支付渠道 |
| stageNo | stage_no | U | 分期阶段编码 |
| isSyncPay | is_sync_pay | U | 是否同步主动支付 |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderQuery

> 类说明：支付宝先享后付请求接口 - 接口编号映射实体 - 业务订单查询

> 响应类：ZhimaCreditMiniOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| outOrderId | out_order_id | U | 商户订单号 |
| orderId | order_id | U | 交易组件订单号 |
| userId | user_id | U | 买家支付宝用户 |
| openId | open_id | U | 支付宝用户open_id |


