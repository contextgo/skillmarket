# 字段必填矩阵 - SybService

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - SybServiceAlinFcConfigRequest

> 类说明：支付宝NFC设备配置接口

> 响应类：SybServiceAlinFcConfigResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| termSn | termsn | R | 设备 SN 编号 |
| branchNo | branchno | R | 设备绑定门店号 |
| openFlag | openflag | R | 配置标识；取值见 global-enum.openflagsybservicealinfcconfig |

## 字段必填矩阵 - SybServiceAlinFcQueryRequest

> 类说明：支付宝NFC设备绑定查询接口

> 响应类：SybServiceAlinFcQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| termSn | termsn | R | 设备 SN 编号 |
| branchNo | branchno | R | 设备绑定门店号 |

## 字段必填矩阵 - SybServiceAsAgreeConfigQryRequest

> 类说明：分账协议授权查询

> 响应类：SybServiceAsAgreeConfigQryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| payeeCusId | payeecusid | R | 入金商户号 |

## 字段必填矩阵 - SybServiceAsAgreeConfigRequest

> 类说明：分账协议授权配置

> 响应类：SybServiceAsAgreeConfigResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| payeeCusId | payeecusid | R | 入金商户号 |
| shareType | sharetype | R | 分账类型；取值见 global-enum.sharetypesybserviceasagreeconfig |
| amtMax | amtmax | R | 最高金额；单位元 |
| rateMax | ratemax | R | 分账比例值；示例 `0.2513` 代表 `25.13%`；当 `shareType=02/03` 时百分比不能大于 1 |
| limitType | limittype | R | 限额类型；取值见 global-enum.limittypesybserviceasagreeconfig |
| asAgreeUrl | asagreeurl | R | 分账授权协议附件；图片链接（双方分账协议） |
| reason | reason | R | 分账事由；最大 50 个汉字 |

## 字段必填矩阵 - SybServiceIotDevConfigRequest

> 类说明：IOT设备绑定和解绑接口

> 响应类：SybServiceIotDevConfigResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| branchNo | branchno | O | 门店编号；非必填 |
| deviceName | devicename | R | 设备 SN 编号 |
| pidList | pidlist | O | 产品名称；默认 `P0002`；支持多选逗号分隔（如 `P0002,P0003`）；取值见 global-enum.pidlistsybserviceiotdevconfig |
| openFlag | openflag | R | 绑定标识；取值见 global-enum.openflagsybserviceiotdevconfig |
| deviceType | devicetype | O | 设备类型；为空默认 `01`（音箱）；取值见 global-enum.devicetypesybserviceiotdevconfig |

## 字段必填矩阵 - SybServiceIotDevQueryRequest

> 类说明：IOT设备查询接口

> 响应类：SybServiceIotDevQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| branchNo | branchno | O | 门店编号；非必填 |
| deviceName | devicename | R | 设备 SN 编号 |

## 字段必填矩阵 - SybServiceQueryCouponDetailRequest

> 类说明：查询微信代金券详情

> 响应类：SybServiceQueryCouponDetailResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| couponId | couponid | R | 代金券id |
| wxOpenId | wxopenid | R | 微信openid |

## 字段必填矩阵 - SybServiceQueryStockDetailRequest

> 类说明：查询微信代金券批次详情

> 响应类：SybServiceQueryStockDetailResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| stockId | stockid | R | 批次号 |

## 字段必填矩阵 - SybServiceQueryStockRefundFlowRequest

> 类说明：下载微信代金券批次退款明细

> 响应类：SybServiceQueryStockRefundFlowResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| stockId | stockid | R | 批次号 |

## 字段必填矩阵 - SybServiceQueryStockUseFlowRequest

> 类说明：下载微信代金券批次核销明细

> 响应类：SybServiceQueryStockUseFlowResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| stockId | stockid | R | 批次号 |

## 字段必填矩阵 - SybServiceSearchCusPackageRequest

> 类说明：商户套餐查询接口

> 响应类：SybServiceSearchCusPackageResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| startTime | starttime | O | 套餐购买日期范围开始；格式 yyyy-MM-dd HH:mm:ss |
| endTime | endtime | O | 套餐购买日期范围结束；格式 yyyy-MM-dd HH:mm:ss |

## 字段必填矩阵 - SybServiceSendCouponsRequest

> 类说明：微信发放代金券

> 响应类：SybServiceSendCouponsResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| stockId | stockid | R | 代金券批次 id（微信为每个批次分配的唯一 id） |
| openId | openid | R | 用户 openid；用户在 appid 下的唯一标识 |
| mchAppId | mchappid | R | 商户公众号 appid；应为公众号 appid（mp），不能为 APP 的 appid（open） |
| couponValue | couponvalue | O | 指定面额发券场景填写券面额，其他场景不填；单位分 |
| couponMinimum | couponminimum | O | 指定面额发券场景填写券门槛，其他场景不填；单位分 |

## 字段必填矩阵 - SybServiceUploadElectTicketRequest

> 类说明：上传微信电子小票

> 响应类：SybServiceUploadElectTicketResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxId | trxid | R | 交易单号 |
| chnlTrxId | chnltrxid | R | 渠道交易单号 |
| cmId | cmid | R | 微信子商户号 |
| openId | openid | R | 微信 OPENID |
| merChantContacts | merchantcontacts | O | 用户与商家联系渠道；JSON 对象，包含 `consultation_phone_number`（商户售后咨询电话），示例 `{\"consultation_phone_number\":\"18888888888\"}` |
| file | - | R | 图片文件流；不参与签名；文件大小不超过 200KB；仅支持 PNG/JPG |

## 字段必填矩阵 - SybServiceWxCateringOrderSyncStatusRequest

> 类说明：微信点餐同步

> 响应类：SybServiceWxCateringOrderSyncStatusResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| subAppId | sub_appid | R | 子商户在微信公众平台申请服务号对应的 APPID |
| outShopNo | outshopno | R | 商户旗下门店唯一编号 |
| subOpenId | subopenid | R | 用户子标识；用户在子商户 appid 下的 openid |
| loginToken | logintoken | R | 微信用户登录接口返回的登录票据；公众号填页面授权 access_token，小程序填写 session_key |
| orderEntry | orderentry | R | 点餐入口 |
| totalAmount | totalamount | R | 总价；单位分，数字类型 |
| discountAmount | discountamount | R | 优惠金额；单位分，数字类型 |
| userAmount | useramount | R | 实际支付金额；单位分，数字类型 |
| status | status | R | 订单状态；取值见 global-enum.digitalwxstatus |
| actionTime | actiontime | R | 状态发生变化时间；格式 yyyymmddhhmmss |
| payTime | paytime | C | 支付时间；格式 yyyymmddhhmmss（`status=PAY_SUCCESS` 时必填） |
| chnlTrxId | chnltrxid | C | 渠道平台交易单号（`status=PAY_SUCCESS` 时必填） |
| trxId | trxid | C | 收银宝平台交易流水号（`status=PAY_SUCCESS` 时必填） |
| reqSn | reqsn | R | 商户交易订单号 |
| dishList | dishlist | R | 菜品列表（`dish_list` 对象数组） |
| outTableNo | outtableno | O | 桌位号 |
| peopleCount | peoplecount | O | 消费人数，数字类型 |



