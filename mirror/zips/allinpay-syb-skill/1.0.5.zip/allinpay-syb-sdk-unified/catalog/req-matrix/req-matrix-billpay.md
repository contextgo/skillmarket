# 字段必填矩阵 - BillPay

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - BillPayAddRequest

> 类说明：账单同步

> 响应类：BillPayAddResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| digId | digid | R | 应用ID |
| payeeCusId | payeecusid | R | 收款方商户号 |
| payerCusId | payercusid | R | 付款方商户号 |
| trxAmt | trxamt | R | 账单金额；单位分 |
| billId | billid | R | 账单ID；同商户下唯一 |
| subject | subject | R | 账单标题/摘要 |
| remark | remark | O | 备注信息 |
| notifyUrl | notifyurl | O | 交易结果通知地址；必须可直连访问且不能携带参数 |
| autoPay | autopay | O | 枚举见 global-enum.autopay（0不自动扣款/1自动扣款）；默认0 |
| autoPayTime | autopaytime | C | autoPay=1 时必填；格式yyyyMMdd |

## 字段必填矩阵 - BillPayDelRequest

> 类说明：账单删除

> 响应类：BillPayDelResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| digId | digid | R | 应用ID |
| payeeCusId | payeecusid | R | 收款方商户号 |
| billId | billid | R | 账单ID（仅未支付账单可删除） |

## 字段必填矩阵 - BillPayQueryRequest

> 类说明：账单查询

> 响应类：BillPayQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| digId | digid | R | 应用ID |
| payeeCusId | payeecusid | R | 收款方商户号 |
| billId | billid | R | 账单ID |

## 字段必填矩阵 - BillPayRefundRequest

> 类说明：账单退款

> 响应类：BillPayRefundResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| digId | digid | R | 应用ID |
| payeeCusId | payeecusid | R | 收款方商户号 |
| billId | billid | R | 账单ID（已支付） |
| refundAmt | refundamt | R | 退款金额；单位分；支持部分退款 |

## 字段必填矩阵 - BillPaySetOfflinePayRequest

> 类说明：账单设置已线下收款

> 响应类：BillPaySetOfflinePayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| digId | digid | R | 应用ID |
| payeeCusId | payeecusid | R | 收款方商户号 |
| billId | billid | R | 账单ID |


