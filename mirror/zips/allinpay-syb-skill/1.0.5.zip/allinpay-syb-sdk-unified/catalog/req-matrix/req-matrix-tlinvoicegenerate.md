# 字段必填矩阵 - TlinvoiceGenerate

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TlinvoiceGenerateInviteQRRequest

> 类说明：邀请二维码生成接口

> 响应类：TlinvoiceGenerateInviteQRResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|

## 字段必填矩阵 - TlinvoiceGenerateInvoiceQRRequest

> 类说明：电票二维码生成接口

> 响应类：TlinvoiceGenerateInvoiceQRResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| amt | amt | R | 金额；单位元 |
| prodCode | prodcode | R | 商品编码；jsonarray 格式，最多支持 8 个商品信息；数组元素字段与取值约束见下方“prodCode 商品信息对象约束” |
| cusOrderid | cusorderid | O | 商户开票流水号 |
| remark | remark | O | 备注 |

## 字段必填矩阵 - TlinvoiceGenerateInvoiceQRSimpleRequest

> 类说明：电票二维码生成接口（简易）

> 响应类：TlinvoiceGenerateInvoiceQRSimpleResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| amt | amt | R | 金额；单位元 |
| prodCode | prodcode | R | 商品编码；jsonarray 格式，最多支持 8 个商品信息；数组元素字段与取值约束见下方“prodCode 商品信息对象约束” |
| cusOrderid | cusorderid | O | 商户开票流水号 |
| cusOrderid | cusorderid | O | 商户开票流水号 |
| termNo | termno | O | 终端号 |

## prodCode 商品信息对象约束

`prodCode` 为 JSON 数组；每个元素是“商品信息对象”。以下字段按接口文档约束填写：

| 字段 | 含义 | 约束 |
|---|---|---|
| goodsname | 商品名称 | 必填；最大长度 128 |
| quantity | 数量 | 可选；Int；最小 1、最大 100000000（默认 100000000） |
| policycode | 优惠政策标识 | 可选；Int；可取：`1` 简易征收、`2` 稀土产品、`3` 免税、`4` 不征税、`5` 先征后退-6%、`6` 先征后退-7.50%、`8` 按3%简易征收、`9` 按5%简易征收、`10` 即征即退30%、`11` 即征即退50%、`13` 即征即退70%、`14` 即征即退100%、`15` 超税负3%即征即退、`16` 超税负8%即征即退、`17` 超税负12%即征即退、`18` 超税负6%即征即退 |
| taxcode | 税收分类编码 | 必填；最大长度 32 |
| unit | 单位 | 可选；最大长度 20 |
| specification | 规格型号 | 可选；最大长度 20 |
| rate | 税率 | 必填；Int；单位为万分之一（例如 `1300` 表示 13%）；支持税率：`0`、`1%`、`1.5%`、`3%`、`5%`、`6%`、`9%`、`10%`、`11%`、`13%`、`16%`、`17%` |
| discount | 是否折扣行 | 必填；`1`=是，`0`=否。若为 `1`：折扣行必须有对应被折扣行；折扣金额绝对值不能超过被折扣行金额；“商品名称/税率/税收分类编码/优惠政策标识”需与被折扣行一致；“单位/规格”必须为空 |
| samt | 单行金额合计 | 必填；double。单行金额与税额之和；折扣行为负数，非折扣行为正数 |

规则：`prodCode` 未按上述字段与枚举填写时，必须返回“未完成核验/入参不合规”，禁止模型自行编造字段或枚举值。


