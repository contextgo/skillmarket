# 字段必填矩阵 - PosolCancel

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - PosolCancelRequest

> 类说明：交易撤销

> 响应类：PosolCancelResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | U | 交易金额,单位为分 |
| reqSn | reqsn | U | 本次请求流水 |
| trxId | trxid | U | 收银宝平台交易订单号 |


