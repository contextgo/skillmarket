# 字段必填矩阵 - B2bOrder

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - B2bOrderDirectPayRequest

> 类说明：B2B订单API-付款

> 响应类：B2bOrderDirectPayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 |
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 |
| body | body | O | 订单标题；为空时默认商户名 |
| remark | remark | O | 备注信息 |
| validTime | validtime | R | 有效时间；单位分钟；最大43200 |
| acctNo | acctno | R | 收款账号；需SM4加密 |
| acctName | acctname | R | 收款户名；需SM4加密 |
| acctType | accttype | R | 收款账户类型：0对私/1对公（当前仅支持对公） |
| bankCode | bankcode | R | 收款银行代码；取值见 global-enum.bankcodeb2bdirectpay |
| goodsInfo | goodsinfo | R | 商品单元信息；List 的 JSON 字符串（注意字段类型为字符串） |
| notifyUrl | notify_url | O | 交易结果通知地址；必须可直连访问且不能携带参数 |
| encrypttype | encrypttype | R | 加密方式固定 SM4（国密） |

## 字段必填矩阵 - B2bOrderPayRequest

> 类说明：B2B订单API-收款

> 响应类：B2bOrderPayResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 |
| payeeCusId | payeecusid | R | 收款方商户号 |
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 |
| body | body | O | 订单标题；为空时默认商户名 |
| remark | remark | O | 备注信息 |
| validTime | validtime | R | 有效时间；单位分钟；最大43200 |
| acctNo | acctno | R | 付款账号；需SM4加密 |
| acctName | acctname | R | 付款户名；需SM4加密 |
| acctType | accttype | R | 付款账户类型：0对私/1对公（当前仅支持对公） |
| bankCode | bankcode | R | 付款银行代码；取值见 global-enum.bankcodeb2bpay |
| goodsInfo | goodsinfo | R | 商品单元信息；List 的 JSON 字符串（注意字段类型为字符串） |
| notifyUrl | notify_url | O | 交易结果通知地址；必须可直连访问且不能携带参数 |
| encrypttype | encrypttype | R | 加密方式固定 SM4（国密） |



