# 字段必填矩阵 - TlinvoiceGet

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TlinvoiceGetInvoiceDownloadUrlRequest

> 类说明：发票下载

> 响应类：TlinvoiceGetInvoiceDownloadUrlResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| applyId | applyid | U | 文档尚未完全核实 |

## 字段必填矩阵 - TlinvoiceGetInvoiceOpenStatusRequest

> 类说明：获取电票开通状态

> 响应类：TlinvoiceGetInvoiceOpenStatusResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|

## 字段必填矩阵 - TlinvoiceGetInvoiceProdCodeListRequest

> 类说明：获取电票商户开票品类

> 响应类：TlinvoiceGetInvoiceProdCodeListResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|

## 字段必填矩阵 - TlinvoiceGetRecordStatusRequest

> 类说明：发票状态查询

> 响应类：TlinvoiceGetRecordStatusResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| applyId | applyid | R | 发票申请单号 |


