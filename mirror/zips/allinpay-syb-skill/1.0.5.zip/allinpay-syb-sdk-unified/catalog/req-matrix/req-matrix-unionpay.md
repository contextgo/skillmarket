# 字段必填矩阵 - UnionPay

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

说明：UnionPay 系列 request 字段较多且业务结构特殊，当前不强制约束字段是否必填，统一以 `U` 标记为待核实。

## 字段必填矩阵 - UnionPayYJHXAuditQryUn

> 类说明：银联以旧换新一键接入-银联审核结果查询接口 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| orgNo | orgNo | U | 银联分公司机构代码 |
| mchntOrderId | mchntOrderId | U | 商户订单号 |
| uploadTime | uploadTime | U | 审核记录上传时间 |

## 字段必填矩阵 - UnionPayYJHXAuditUn

> 类说明：银联以旧换新一键接入-银联审核数据上送接口 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| orgNo | orgNo | U | 银联分公司机构代码 |
| subMchntCd | subMchntCd | U | 店铺编码 |
| subMchntNm | subMchntNm | U | 店铺名称 |
| storeNm | storeNm | U | 门店名称 |
| onlineNo | onlineNo | U | 线上平台订单号 |
| mchntOrderId | mchntOrderId | U | 商户订单号 |
| uploadTime | uploadTime | U | 审核记录上传时间 yyyyMMddHHmmss |
| prodId | prodId | U | 品类 |
| engGrade | engGrade | U | 能效 |
| brandNm | brandNm | U | 品牌 |
| prodModel | prodModel | U | 型号 |
| salesChnl | salesChnl | U | 销售方式 |
| platForm | platForm | U | 电商平台方 |
| payerTp | payerTp | U | 支付方式类型 |
| tradeInOrderId | tradeInOrderId | U | 收旧订单号 |
| tradeInAt | tradeInAt | U | 收旧价格 |
| isTradeIn | isTradeIn | U | 收旧价格 是否统计 |
| salesAt | salesAt | U | 订单金额 分为单位 |
| actualAt | actualAt | U | 实付金额 分为单位 |
| transTm | transTm | U | 交易时间 yyyyMMddHHmmss |
| mchntCd | mchntCd | U | 商户编码 |
| merSubAt | merSubAt | U | 商家优惠金额 |
| discountAt | discountAt | U | 国补优惠金额 |
| image01 | image01 | U | 其他图片1 |
| image02 | image02 | U | 其他图片2 |
| image03 | image03 | U | 其他图片3 |
| image04 | image04 | U | 其他图片4 |
| image05 | image05 | U | 其他图片5 |
| image06 | image06 | U | 其他图片6 |
| image07 | image07 | U | 其他图片7 |
| image08 | image08 | U | 其他图片8 |
| image09 | image09 | U | 其他图片9 |
| image10 | image10 | U | 其他图片10 |
| commitmentLetterPhoto | - | U | 文档尚未完全核实 |
| commitmentLetterPhotoFormat | commitmentLetterPhotoFormat | U | 收旧承诺函照片格式 |
| devicePhoto | - | U | 文档尚未完全核实 |
| devicePhotoFormat | devicePhotoFormat | U | 收旧设备外观照片格式 |
| packAndActivePhoto | packAndActivePhoto | U | 包含完整外包装及sn码的激活照片 |
| barCode | barCode | U | 商品条码 |
| snCode | snCode | U | SN码 |
| imei1 | imei1 | U | IMEI1 |
| imei2 | imei2 | U | IMEI2 |
| registerModel | registerModel | U | 能效或水效网备案登记型号 |
| recordNumber | recordNumber | U | 能效或水效备案号 |
| engGradeStandard | engGradeStandard | U | 能效或水效执行的国家标准名称 |
| encryptData | encryptData | U | 加密信息域；必须传 `UnionPayYJHXVoAuditEncryptData` 明文对象，禁止手工加密后上送 |
| resv1 | resv1 | U | 保留域1 |
| resv2 | resv2 | U | 保留域2 |
| resv3 | resv3 | U | 保留域3 |
| resv4 | resv4 | U | 保留域4 |
| resv5 | resv5 | U | 保留域5 |

## 字段必填矩阵 - UnionPayYJHXAuditUpdateUn

> 类说明：银联以旧换新一键接入-银联审核数据记录更新接口 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| orgNo | orgNo | U | 银联分公司机构代码 |
| subMchntCd | subMchntCd | U | 店铺编码 |
| subMchntNm | subMchntNm | U | 店铺名称 |
| storeNm | storeNm | U | 门店名称 |
| onlineNo | onlineNo | U | 线上平台订单号 |
| mchntOrderId | mchntOrderId | U | 商户订单号 |
| uploadTime | uploadTime | U | 审核记录上传时间 yyyyMMddHHmmss |
| prodId | prodId | U | 品类 |
| engGrade | engGrade | U | 能效 |
| brandNm | brandNm | U | 品牌 |
| prodModel | prodModel | U | 型号 |
| salesChnl | salesChnl | U | 销售方式 |
| platForm | platForm | U | 电商平台方 |
| payerTp | payerTp | U | 支付方式类型 |
| tradeInOrderId | tradeInOrderId | U | 收旧订单号 |
| tradeInAt | tradeInAt | U | 收旧价格 |
| isTradeIn | isTradeIn | U | 收旧价格 是否统计 |
| salesAt | salesAt | U | 订单金额 分为单位 |
| actualAt | actualAt | U | 实付金额 分为单位 |
| transTm | transTm | U | 交易时间 yyyyMMddHHmmss |
| mchntCd | mchntCd | U | 商户编码 |
| merSubAt | merSubAt | U | 商家优惠金额 |
| discountAt | discountAt | U | 国补优惠金额 |
| image01 | image01 | U | 其他图片1 |
| image02 | image02 | U | 其他图片2 |
| image03 | image03 | U | 其他图片3 |
| image04 | image04 | U | 其他图片4 |
| image05 | image05 | U | 其他图片5 |
| image06 | image06 | U | 其他图片6 |
| image07 | image07 | U | 其他图片7 |
| image08 | image08 | U | 其他图片8 |
| image09 | image09 | U | 其他图片9 |
| image10 | image10 | U | 其他图片10 |
| commitmentLetterPhoto | - | U | 文档尚未完全核实 |
| commitmentLetterPhotoFormat | commitmentLetterPhotoFormat | U | 收旧承诺函照片格式 |
| devicePhoto | - | U | 文档尚未完全核实 |
| devicePhotoFormat | devicePhotoFormat | U | 收旧设备外观照片格式 |
| packAndActivePhoto | packAndActivePhoto | U | 包含完整外包装及sn码的激活照片 |
| barCode | barCode | U | 商品条码 |
| snCode | snCode | U | SN码 |
| imei1 | imei1 | U | IMEI1 |
| imei2 | imei2 | U | IMEI2 |
| registerModel | registerModel | U | 能效或水效网备案登记型号 |
| recordNumber | recordNumber | U | 能效或水效备案号 |
| engGradeStandard | engGradeStandard | U | 能效或水效执行的国家标准名称 |
| encryptData | encryptData | U | 加密信息域；必须传 `UnionPayYJHXVoAuditEncryptData` 明文对象，禁止手工加密后上送 |
| resv1 | resv1 | U | 保留域1 |
| resv2 | resv2 | U | 保留域2 |
| resv3 | resv3 | U | 保留域3 |
| resv4 | resv4 | U | 保留域4 |
| resv5 | resv5 | U | 保留域5 |

## 字段必填矩阵 - UnionPayYJHXClearanceUn

> 类说明：银联以旧换新一键接入-银总联线上核销同步接口 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss |
| coupIssueId | coupIssueId | U | 发券方代码 |
| regionCd | regionCd | U | 地区码 |
| encryptData | encryptData | U | 用户敏感信息；必须传 `UnionPayYJHXVoUserEncryptData` 明文对象，禁止手工加密后上送 |
| cateCode | cateCode | U | 品类编码 |
| txnAmt | txnAmt | U | 销售金额 |
| discountAmt | discountAmt | U | 补贴金额 |
| transTm | transTm | U | 交易完成时间 yyyyMMddHHmmssSSS |
| couponCd | couponCd | U | 券码 |
| actId | actId | U | 活动编号 |
| operTp | operTp | U | 品类状态 |
| mchntCd | mchntCd | U | 核销商编 |
| mchntCnNm | mchntCnNm | U | 核销商户名称 |
| mchntResv | mchntResv | U | 核销商户保留域 |
| reqReserved | reqReserved | U | 请求方保留域 |
| recvRegionCd | recvRegionCd | U | 收货地区编码 |
| saleModels | saleModels | U | 销售方式 |
| corpCnNm | corpCnNm | U | 销售企业名称 |
| uniscId | uniscId | U | 统一社会信息代码 |
| pickUp | pickUp | U | 是否自提 |
| barCode | barCode | U | 商品条码 |
| itemName | itemName | U | 商品名称 |
| brandNm | brandNm | U | 家电品牌 |
| specModel | specModel | U | 规格型号 |
| engGrade | engGrade | U | 能耗等级 |
| snCode | snCode | U | S/N码 |
| imei1 | imei1 | U | IMEI1码 |
| imei2 | imei2 | U | IMEI2码 |
| logisticsNo | logisticsNo | U | 物流单号 |
| deliveryTime | deliveryTime | U | 签收时间 |
| invoiceNo | invoiceNo | U | 发票号 |
| isAIProduct | isAIProduct | U | 是否属于AI产品 |
| serialNum | serialNum | U | 数据流水号 |
| pcType | pcType | U | 电脑类型 |
| channel | channel | U | 线上销售渠道 |
| mchntOrderId | mchntOrderId | U | 商户订单号 |
| acqInsNm | acqInsNm | U | 收单机构名称 |
| payOrderId | payOrderId | U | 支付交易编号 |
| oldThings | oldThings | U | 交旧信息 |

## 字段必填矩阵 - UnionPayYJHXCmnRequest

> 类说明：银联以旧换新一键接入 (actionType+trxChnl+bizContent 三元组必填) (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| actionType | actionType | U | 业务类型；取值见 global-enum.actiontypeyjhx |
| trxChnl | trxChnl | U | 受理渠道；取值见 global-enum.trxchnlyjhx |
| bizContent | bizContent | U | 业务参数；实体三元组见 global-enum.bizcontentyjhx；禁止 Map/父类空对象/自定义扩展类 |

## 字段必填矩阵 - UnionPayYJHXCoupCancel

> 类说明：银联以旧换新发券相关API - 银联以旧换新发券相关-银总联线上资格查询及优惠券解绑接口 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCoupResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss |
| coupIssueId | coupIssueId | U | 发券方代码 |
| regionCd | regionCd | U | 地区码 |
| encryptData | encryptData | U | 用户敏感信息；必须传 `UnionPayYJHXVoUserEncryptData` 明文对象，禁止手工加密后上送 |
| scene | scene | U | 场景 |
| cateCode | cateCode | U | 品类编码 |
| gps | gps | U | GPS信息 |
| reqReserved | reqReserved | U | 请求方保留域 |

## 字段必填矩阵 - UnionPayYJHXCoupCheck

> 类说明：银联以旧换新发券相关API - 银联以旧换新发券相关-银总联线上资格查询接口 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCoupResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss |
| coupIssueId | coupIssueId | U | 发券方代码 |
| regionCd | regionCd | U | 地区码 |
| encryptData | encryptData | U | 用户敏感信息；必须传 `UnionPayYJHXVoUserEncryptData` 明文对象，禁止手工加密后上送 |
| scene | scene | U | 场景 |
| reqReserved | reqReserved | U | 请求方保留域 |
| isRealName | isRealName | U | 是否已实名 |
| isRealFace | isRealFace | U | 是否已人脸验证 |
| isExpire | isExpire | U | 证件是否在有效期内 |
| isCancel | isCancel | U | 证件是否已注销 |

## 字段必填矩阵 - UnionPayYJHXCoupReceive

> 类说明：银联以旧换新发券相关API - 银联以旧换新发券相关-银总联线上资格及优惠券领取 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCoupResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss |
| coupIssueId | coupIssueId | U | 发券方代码 |
| regionCd | regionCd | U | 地区码 |
| encryptData | encryptData | U | 用户敏感信息；必须传 `UnionPayYJHXVoUserEncryptData` 明文对象，禁止手工加密后上送 |
| scene | scene | U | 场景 |
| cateCode | cateCode | U | 品类编码 |
| model | model | U | 领取模式 |
| engGrade | engGrade | U | 能耗等级 |
| isRealName | isRealName | U | 是否已实名 |
| isRealFace | isRealFace | U | 是否已人脸验证 |
| isExpire | isExpire | U | 证件是否在有效期内 |
| isCancel | isCancel | U | 证件是否已注销 |
| gps | gps | U | GPS信息 |
| reqReserved | reqReserved | U | 请求方保留域 |

## 字段必填矩阵 - UnionPayYJHXCoupRequest

> 类说明：银联以旧换新发券相关API (actionType+trxChnl+bizContent 三元组必填) (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCoupResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| actionType | actionType | U | 业务类型；取值见 global-enum.actiontypeyjhx |
| trxChnl | trxChnl | U | 受理渠道；取值见 global-enum.trxchnlyjhx |
| bizContent | bizContent | U | 业务参数；实体三元组见 global-enum.bizcontentyjhx；禁止 Map/父类空对象/自定义扩展类 |

## 字段必填矩阵 - UnionPayYJHXSnOccupancyUn

> 类说明：银联以旧换新一键接入-银总联线下、银总联线上SN码占用变更接口 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss |
| orderId | orderId | U | 交易流水号 |
| regionCd | regionCd | U | 地区码 |
| mchntCd | mchntCd | U | 银联商户号 |
| postTmn | postTmn | U | 终端号 |
| barcode | barcode | U | 商品条码 |
| snCode | snCode | U | SN码 |
| reqReserved | reqReserved | U | 备注 |
| imei1 | imei1 | U | IMEI1码 |
| imei2 | imei2 | U | IMEI2码 |
| mfrInfo | mfrInfo | U | 厂商信息 |
| brand | brand | U | 具体品牌 |
| cateCode | cateCode | U | 品类编码 |
| isAiProd | isAiProd | U | 是否为AI产品 |
| specModel | specModel | U | 规格型号 |
| saleTm | saleTm | U | 销售时间 yyyy-MM-dd |

## 字段必填矩阵 - UnionPayYJHXSnQueryUn

> 类说明：银联以旧换新一键接入-银总联线下、银总联线上是否核销接口 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| regionCd | regionCd | U | 地区码 |
| snCode | snCode | U | SN码 |
| reqReserved | reqReserved | U | 备注 |

## 字段必填矩阵 - UnionPayYJHXTransSyncUn

> 类说明：银联以旧换新一键接入-银总联线上家电、数码和智能产品购新交易数据同步接口 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss |
| coupIssueId | coupIssueId | U | 发券方代码 |
| regionCd | regionCd | U | 地区码 |
| encryptData | encryptData | U | 用户敏感信息；必须传 `UnionPayYJHXVoUserEncryptData` 明文对象，禁止手工加密后上送 |
| cateCode | cateCode | U | 品类编码 |
| txnAmt | txnAmt | U | 销售金额 |
| discountAmt | discountAmt | U | 补贴金额 |
| transTm | transTm | U | 交易完成时间 yyyyMMddHHmmssSSS |
| couponCd | couponCd | U | 券码 |
| actId | actId | U | 活动编号 |
| operTp | operTp | U | 品类状态 |
| mchntCd | mchntCd | U | 核销商编 |
| mchntCnNm | mchntCnNm | U | 核销商户名称 |
| mchntResv | mchntResv | U | 核销商户保留域 |
| reqReserved | reqReserved | U | 请求方保留域 |
| recvRegionCd | recvRegionCd | U | 收货地区编码 |
| saleModels | saleModels | U | 销售方式 |
| corpCnNm | corpCnNm | U | 销售企业名称 |
| uniscId | uniscId | U | 统一社会信息代码 |
| brandNm | brandNm | U | 家电品牌 |
| engGrade | engGrade | U | 能耗等级 |
| serialNum | serialNum | U | 数据流水号 |

## 字段必填矩阵 - UnionPayYJHXVoAuditEncryptData

> 类说明：银联以旧换新一键接入业务参数-审核数据加密信息域 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| invoiceInfo | invoiceInfo | U | 发票信息域 |
| trackInfo | trackInfo | U | 物流信息域 |

## 字段必填矩阵 - UnionPayYJHXVoBiz

> 类说明：银联以旧换新一键接入 - 银联以旧换新业务参数父类 (特殊继承基类，仅用于 SDK 子类)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| serialVersionUID | - | U | 文档尚未完全核实 |

## 字段必填矩阵 - UnionPayYJHXVoInvoiceInfo

> 类说明：银联以旧换新一键接入业务参数-发票信息域 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| id | id | U | 发票id |
| invoiceTp | invoiceTp | U | 发票类型 |
| invoiceCd | invoiceCd | U | 发票代码 |
| invoiceNo | invoiceNo | U | 发票号码 |
| invoiceDt | invoiceDt | U | 开票日期 |
| invoiceLink | invoiceLink | U | 发票链接 |
| invoiceCkCd | invoiceCkCd | U | 发票校验码 |
| nm | nm | U | 发票上购买人姓名 |
| tax | tax | U | 税价合计 |
| invoiceTaxAmt | invoiceTaxAmt | U | 发票税额 |
| salesEntNm | salesEntNm | U | 销售企业名称 |
| taxPayer | taxPayer | U | 销售方纳税人识别号 |
| num | num | U | 数量 |
| serviceNm | serviceNm | U | 货物或应税劳务服务名称（含型号） |

## 字段必填矩阵 - UnionPayYJHXVoTrackInfo

> 类说明：银联以旧换新一键接入业务参数-物流信息域 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trackingNo | trackingNo | U | 物流单号 |
| trackingCompany | trackingCompany | U | 物流公司 |
| usrProv | usrProv | U | 收货省 |
| usrCity | usrCity | U | 收货市 |
| usrArea | usrArea | U | 收货区县 |
| usrAddr | usrAddr | U | 收货地址 |
| trackingType | trackingType | U | 物流类型 |
| deliveryMethod | deliveryMethod | U | 提货方式 |
| shippingAddr | shippingAddr | U | 发货地址 |
| deliveryTime | deliveryTime | U | 签收时间 yyyyMMddHHmmss |

## 字段必填矩阵 - UnionPayYJHXVoUserEncryptData

> 类说明：银联以旧换新一键接入业务参数-用户敏感信息 (继承 UnionPayYJHXVoBiz)

> 响应类：UnionPayYJHXCmnResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| certifTp | certifTp | U | 证件类型 |
| certifId | certifId | U | 证件号码 |
| customerNm | customerNm | U | 姓名 |
| usrId | usrId | U | 用户号码 |
| phoneNo | phoneNo | U | 手机号 |
| addr | addr | U | 收货地址 |


