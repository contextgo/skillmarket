# 字段必填矩阵 - PosolAuth

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - PosolAuthFinRequest

> 类说明：预授权完成

> 响应类：PosolAuthFinResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | U | 本次请求流水 |
| trxId | trxid | U | 收银宝平台交易订单号 |
| trxAmt | trxamt | U | 交易金额,单位为分 |


