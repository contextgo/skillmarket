# 字段必填矩阵 - RiskFeeBack

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - RiskFeeBackAliComplaintFileUploadRequest

> 类说明：支付宝投诉处理图片上传

> 响应类：RiskFeeBackAliComplaintFileUploadResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| file_content | - | R | 上传文件的二进制流（Java 为 byte[]）；单张图片文件大小请控制在 5M 以内 |

## 字段必填矩阵 - RiskFeeBackAliComplaintProcessFinishRequest

> 类说明：支付宝投诉处理消费者投诉

> 响应类：RiskFeeBackAliComplaintProcessFinishResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| timeStamp | timestamp | R | 调用时间戳；格式 yyyymmddhhmmss |
| idList | id_list | R | 投诉 id 列表，JSON 数组字符串；例 `[31304701,31304702]`；最长 1000；须为投诉列表返回的投诉主表主键 id，非 `task_id` |
| processCode | process_code | R | 商家处理投诉结果码；取值见 global-enum.processcoderiskfeebackalicomplaintfinish；文档示例 `REFUND` |
| remark | remark | O | 本次投诉处理备注；最长 1024 |
| imgFileList | img_file_list | O | 图片文件列表，JSON 数组字符串；例 `[{"img_url":"…","img_url_key":"…"}]`；最长 1024 |

## 字段必填矩阵 - RiskFeeBackAliComplaintQueryRequest

> 类说明：支付宝查询消费者投诉详情

> 响应类：RiskFeeBackAliComplaintQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| timeStamp | timestamp | R | 调用时间戳；格式 yyyymmddhhmmss |
| complainId | complain_id | R | 投诉主表主键id |

## 字段必填矩阵 - RiskFeeBackAliComplaintQueryV2Request

> 类说明：支付宝投诉查询消费者投诉列表

> 响应类：RiskFeeBackAliComplaintQueryV2Response

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| timeStamp | timestamp | R | 调用时间戳；格式 yyyymmddhhmmss |
| currentPageNum | current_page_num | R | 当前页码，默认 1 |
| pageSize | page_size | R | 每页条数，默认 10 |
| gmtComplaintStart | gmt_complaint_start | O | 开始投诉时间（区间筛选） |
| gmtComplaintEnd | gmt_complaint_end | O | 结束投诉时间（区间筛选） |
| tradeNo | trade_no | O | 交易单号 |
| taskId | task_id | O | 投诉单号 |

## 字段必填矩阵 - RiskFeeBackWxAppletBussiAppealRequest

> 类说明：微信小程序收银台商家申诉

> 响应类：RiskFeeBackWxAppletBussiAppealResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| timeStamp | timestamp | R | 调用时间戳；格式 yyyymmddhhmmss |
| complaintOrderId | complaintorderid | R | 投诉单号 |
| content | content | R | 申诉内容 |
| mediaIdList | mediaIdlist | R | 图片 id 列表，json 数组 |

## 字段必填矩阵 - RiskFeeBackWxAppletBussiRespondComplaintRequest

> 类说明：微信小程序收银台投诉商家回应投诉

> 响应类：RiskFeeBackWxAppletBussiRespondComplaintResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| timeStamp | timestamp | R | 调用时间戳；格式 yyyymmddhhmmss |
| complaintOrderId | complaintorderid | R | 投诉单号 |
| content | content | R | 回复投诉内容 |
| mediaIdList | mediaIdlist | R | 图片 id 列表，json 数组 |
| bussiHandle | bussihandle | R | 操作类型；取值见 global-enum.bussihandleriskfeebackwxapplet |

## 字段必填矩阵 - RiskFeeBackWxAppletBussiSupplyProofRequest

> 类说明：微信小程序收银台商家补充凭证

> 响应类：RiskFeeBackWxAppletBussiSupplyProofResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| timeStamp | timestamp | R | 调用时间戳；格式 yyyymmddhhmmss |
| complaintOrderId | complaintorderid | R | 投诉单号 |
| content | content | R | 申诉内容 |
| mediaIdList | mediaIdlist | R | 图片 id 列表，json 数组 |

## 字段必填矩阵 - RiskFeeBackWxAppletBussiSupplyRefundRequest

> 类说明：微信小程序收银台商家提交退款凭证

> 响应类：RiskFeeBackWxAppletBussiSupplyRefundResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| timeStamp | timestamp | R | 调用时间戳；格式 yyyymmddhhmmss |
| complaintOrderId | complaintorderid | R | 投诉单号 |
| content | content | R | 申诉内容 |
| mediaIdList | mediaIdlist | R | 图片 id 列表，json 数组 |
| acceptReturn | acceptreturn | C | 退款场景必填；取值见 global-enum.acceptreturnriskfeebackwxapplet |
| returnId | returnid | C | 退款场景必填；退货 id（通过查询投诉单详情接口获取） |

## 字段必填矩阵 - RiskFeeBackWxAppletComplaintOrderDetailRequest

> 类说明：微信小程序收银台投诉查询投诉单详情

> 响应类：RiskFeeBackWxAppletComplaintOrderDetailResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| timeStamp | timestamp | R | 调用时间戳；格式 yyyymmddhhmmss |
| complaintOrderId | complaintorderid | R | 投诉单号 |

## 字段必填矩阵 - RiskFeeBackWxAppletComplaintQueryRequest

> 类说明：微信小程序收银台投诉查询消费者投诉列表

> 响应类：RiskFeeBackWxAppletComplaintQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| timeStamp | timestamp | R | 调用时间戳；格式 yyyymmddhhmmss |
| currentPageNum | current_page_num | R | 当前页码，默认 1 |
| pageSize | page_size | R | 每页条数，默认 10 |
| beginDate | begindate | O | 开始投诉时间；格式 yyyy-MM-dd（示例：2020-01-01） |
| endDate | enddate | O | 结束投诉时间；格式 yyyy-MM-dd（示例：2020-01-01） |

## 字段必填矩阵 - RiskFeeBackWxAppletUploadRequest

> 类说明：微信小程序收银台上传附件

> 响应类：RiskFeeBackWxAppletUploadResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| timeStamp | timestamp | R | 调用时间戳；格式 yyyymmddhhmmss |
| type | type | R | 类型；取值见 global-enum.typeriskfeebackwxappletupload |
| file | - | R | 文件流 |

## 字段必填矩阵 - RiskFeeBackWxComplaintCompleteRequest

> 类说明：微信投诉反馈处理完成API

> 响应类：RiskFeeBackWxComplaintCompleteResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| complaintId | complaint_id | R | 投诉单号 |

## 字段必填矩阵 - RiskFeeBackWxComplaintDetailRequest

> 类说明：微信投诉查询投诉单详情API

> 响应类：RiskFeeBackWxComplaintDetailResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| complaintId | complaint_id | R | 投诉单号 |

## 字段必填矩阵 - RiskFeeBackWxComplaintHistoryRequest

> 类说明：微信投诉查询投诉协商历史

> 响应类：RiskFeeBackWxComplaintHistoryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| complaintId | complaint_id | R | 投诉单号 |
| limit | limit | O | 分页大小；可空，默认 100 |
| offset | offset | O | 分页开始位置；可空，默认 0 |

## 字段必填矩阵 - RiskFeeBackWxComplaintListQueryRequest

> 类说明：微信投诉查询投诉单列表API

> 响应类：RiskFeeBackWxComplaintListQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| currentPageNum | current_page_num | O | 分页查询页码；不传默认 1；参数值需大于 0 |
| pageSize | page_size | O | 分页查询每次查询的数据量；建议不超过 20；不传默认 10 |
| beginDate | begindate | R | 投诉发生开始日期；格式 yyyy-MM-DD HH:mm:ss；查询日期跨度不超过 30 天 |
| endDate | enddate | R | 投诉发生结束日期；格式 yyyy-MM-DD HH:mm:ss；查询日期跨度不超过 30 天 |
| updateBegin | updatebegin | R | 投诉发生更新开始日期；格式 yyyy-MM-DD HH:mm:ss；查询日期跨度不超过 30 天；仅支持从 2025-06-19 后发生更新记录 |
| updateEnd | updateend | R | 投诉发生更新结束日期；格式 yyyy-MM-DD HH:mm:ss；查询日期跨度不超过 30 天 |
| groupAll | groupall | C | 集团模式必填；当上送时取值 `groupall=1` |

## 字段必填矩阵 - RiskFeeBackWxComplaintRespRequest

> 类说明：微信投诉回复用户API

> 响应类：RiskFeeBackWxComplaintRespResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| complaintId | complaint_id | R | 投诉单号 |
| responseContent | response_content | R | 回复内容；不超过 200 字符 |
| responseImages | response_images | O | 回复图片；多张图片以 `#@#` 分隔；最多 3 张 |
| jumpUrl | jump_url | O | 跳转链接 |
| jumpUrlText | jump_url_text | O | 跳转链接文案 |

## 字段必填矩阵 - RiskFeeBackWxComplaintSreFundProgressRequest

> 类说明：微信投诉更新退款审批结果API

> 响应类：RiskFeeBackWxComplaintSreFundProgressResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| complaintId | complaint_id | R | 投诉单号 |
| action | action | R | 审批动作；取值见 global-enum.actionriskfeebackwxcomplaintrefundprogress |
| launchRefundDay | launch_refund_day | C | 同意退款时可回传；预计将在多少个工作日内发起，`0` 代表当天 |
| rejectReason | reject_reason | C | 拒绝退款原因；不超过 200 字符（`action=REJECT` 时填写） |
| rejectMediaList | reject_media_list | C | 拒绝退款的凭证图片列表；多张以 `#@#` 分隔，不超过 4 张（`action=REJECT` 时填写） |
| remark | remark | O | 备注；不超过 200 字符 |

## 字段必填矩阵 - RiskFeeBackWxGetMerchantImageRequest

> 类说明：微信投诉下载微信图片

> 响应类：RiskFeeBackWxGetMerchantImageResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| imgUrl | imgurl | R | 图片地址 |

## 字段必填矩阵 - RiskFeeBackWxMerchantImageUploadRequest

> 类说明：微信投诉商户上传反馈图片API

> 响应类：RiskFeeBackWxMerchantImageUploadResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| file | - | R | 文件流 |



