# 字段必填矩阵 - GateWay

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - GateWayH5Request

> 类说明：网关支付API-H5网关订单提交接口

> 响应类：AllinpayFrontResp

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 付款金额；单位分 |
| reqSn | reqsn | R | 商户唯一订单号 |
| charset | charset | R | 字符编码；支持UTF-8/GBK |
| retUrl | returl | R | 同步通知地址；必须https且不能带参数 |
| retType | rettype | O | 同步返回请求方式；枚举见 global-enum.rettype；默认01 |
| notifyUrl | notifyurl | O | 异步通知地址；若https需443默认端口 |
| body | body | R | 订单标题（收银台展示） |
| remark | remark | O | 订单备注信息 |
| validTime | validtime | O | 有效时间（分钟）；不填默认60；最大60 |
| limitPay | limit_pay | O | 支付限制；常见 no_credit |
| asInfo | asinfo | O | 分账信息；需开通分账配置 |
| subBranch | subbranch | O | 通联系统门店号 |
| gateId | gateid | O | 支付银行；不填则收银台展示银行列表 |
| idType | idtype | O | 证件类型；取值见 global-enum.idtype |
| idNo | idno | O | 证件号 |
| trueName | truename | O | 姓名 |

## 字段必填矩阵 - GateWayPCRequest

> 类说明：网关支付API-PC网关订单提交接口

> 响应类：AllinpayFrontResp

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| charset | charset | R | 字符编码；支持UTF-8/GBK/GB2312 |
| retUrl | returl | O | 同步通知地址；returl和notifyurl不能同时为空 |
| notifyUrl | notifyurl | O | 异步通知地址；returl和notifyurl不能同时为空 |
| goodsId | goodsid | O | 商品号；不允许特殊字符（| AllinpayFrontResp | high |
| goodsInf | goodsinf | O | 商品描述；不允许特殊字符（| AllinpayFrontResp | high |
| trxAmt | trxamt | R | 付款金额；单位分 |
| orderId | orderid | R | 商户唯一订单号 |
| gateId | gateid | O | 支付银行；不填则网关展示银行列表 |
| payType | paytype | R | 交易类型；B2C/B2B（默认B2C） |
| validTime | validtime | O | B2C场景分钟制（默认60，最大60）；B2B固定20天 |
| limitPay | limitpay | O | 仅B2C场景有效（如no_credit/to_credit） |


