# 字段必填矩阵 - WxOpen

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - WxOpenGetOpenIdRequest

> 类说明：H5获取微信OPENID

> 响应类：AllinpayFrontResp

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| appType | apptype | R | 公众号类型；取值见 global-enum.apptypewxopengetopenid |
| redirectUrl | redirecturl | R | 重定向 url（需做 urlEncode） |
| state | state | R | 开发者自定义参数；重定向后会带上 `state` 回传；可填写 `a-zA-Z0-9`；最大 128 字节 |



