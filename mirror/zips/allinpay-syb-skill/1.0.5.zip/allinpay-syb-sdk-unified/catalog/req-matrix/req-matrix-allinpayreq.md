# 字段必填矩阵 - AllinpayReq

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - AllinpayReq

> 类说明：基础请求接口

> 响应类：无（基类，不参与响应映射）

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| orgId | orgid | O | 仅集团/代理模式使用 |
| cusId | cusid | R | 商户号 |
| appId | appid | R | 应用ID |
| version | version | O | 取决于接口版本规则 |
| randomStr | randomstr | R | 随机串 |

## 字段必填矩阵 - AllinpayReqInf

> 类说明：基础请求接口

> 响应类：无（基类，不参与响应映射）

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
