# 字段必填矩阵 - Tranx

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TranxCancelRequest

> 类说明：统一撤销请求参数

> 响应类：TranxCancelResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 交易金额（原交易金额） |
| reqSn | reqsn | R | 商户撤销交易单号；商户平台唯一 |
| oldReqSn | oldreqsn | C | 原交易商户交易单号；与 `oldTrxId` 二选一 |
| oldTrxId | oldtrxid | C | 原交易收银宝平台流水；与 `oldReqSn` 二选一；同时上送时优先使用 `oldTrxId` |

## 字段必填矩阵 - TranxCloseRequset

> 类说明：统一关单请求参数

> 响应类：TranxCloseResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| oldReqSn | oldreqsn | C | 原交易商户交易单号；与 `oldTrxId` 二选一 |
| oldTrxId | oldtrxid | C | 原交易收银宝平台流水；与 `oldReqSn` 二选一；同时上送时优先使用 `oldTrxId` |

## 字段必填矩阵 - TranxQueryConfirmRequest

> 类说明：交易结果确认查询接口

> 响应类：TranxQueryConfirmResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | C | 商户交易订单号；与 `trxId` 二选一 |
| trxId | trxid | C | 平台交易流水（支付收银宝平台流水）；与 `reqSn` 二选一；同时上送时优先 `trxId` |

## 字段必填矩阵 - TranxQueryOrderRequest

> 类说明：订单交易结果查询

适用场景：当面付发起的订单消费支付交易查询。

> 响应类：TranxQueryOrderResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxDate | trxdate | O | 交易日期；格式 `mmdd`；当查询条件为 `trxId` 时可空 |
| orderId | orderid | C | 订单号（POS 订单支付输入的商户订单号）；与 `trxId` 不能同时为空 |
| trxId | trxid | C | 收银宝交易流水；与 `orderId` 不能同时为空 |
| termNo | termno | O | 终端号；8位数字 |
| resendNotify | resendnotify | R | 是否重发交易结果通知；取值见 global-enum.resendnotifytranxqueryorder |

## 字段必填矩阵 - TranxQueryRequest

> 类说明：统一查询请求参数

> 响应类：TranxQueryResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| reqSn | reqsn | C | 商户交易订单号；与 `trxId` 二选一 |
| trxId | trxid | C | 平台交易流水（支付收银宝平台流水）；与 `reqSn` 二选一；同时上送时优先 `trxId` |

## 字段必填矩阵 - TranxRefundRequest

> 类说明：统一撤销请求参数

> 响应类：TranxRefundResponse

| 字段 | JSON 名 | 级别 | 条件 |
|---|---|---|---|
| trxAmt | trxamt | R | 退款核心字段; 格式提示： 金额单位为分 |
| reqSn | reqsn | R | 退款核心字段 |
| oldReqSn | oldreqsn | C | oldreqsn/oldtrxid 二选一 |
| oldTrxId | oldtrxid | C | oldreqsn/oldtrxid 二选一, oldtrxid preferred |
| remark | remark | O | 按场景可选 |
| benefitDetail | benefitdetail | O | 按场景可选 |
| notifyUrl | notify_url | O | 按场景可选 |



