# Response Field Matrix

Total Response Classes: **151**
Total Fields: **661**

> 每类一节：## 类名；下一行 > Extends: 为父类链真源（与 SDK 源码一致）。字段表为 getter/字段真源。

## ActivityCusActivityResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |

## ActivityQueryActivityResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| actDetail | actdetail | getActDetail() | 报名详情 |
| auditStatus | auditstatus | getAuditStatus() | 审核状态 |
| chnlSubId | chnlsubid | getChnlSubId() | 渠道返回子商户号 |
| errMsg | errmsg | getErrMsg() | 错误信息 |

## AllinpayFrontResp

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| htmlJump | (无 @JsonProperty；按 Java 属性名/运行时序列化规则) | getHtmlJump() | html页面 |
| urlJump | (无 @JsonProperty；按 Java 属性名/运行时序列化规则) | getUrlJump() | URL跳转 |

## AllinpayResp

> Extends: -

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| retCode | retcode | getRetCode() | 返回码 |
| retMsg | retmsg | getRetMsg() | 返回码说明 |
| trxId | trxid | getTrxId() | 交易单号 |

## AllinpayRespMer

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| cusId | cusid | getCusId() | 商户号 |
| orgId | orgid | getOrgId() | 代理商号 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态码 |

## AllinpayRespRisk

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |

## AllinpayRespTranx

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| cusId | cusid | getCusId() | 商户号 |
| errMsg | errmsg | getErrMsg() | 错误原因 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| reqSn | reqsn | getReqSn() | 商户交易单号 |
| sign | sign | getSign() | 签名 |

## B2bOrderDirectPayResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## B2bOrderPayResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## BillPayAddResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxStatus | trxstatus | getTrxStatus() | 同步结果 |

## BillPayDelResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxStatus | trxstatus | getTrxStatus() | 同步结果 |

## BillPayQueryResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| autoPay | autopay | getAutoPay() | 是否自动扣款 |
| autoPayTime | autopaytime | getAutoPayTime() | 自动扣款日期 |
| billId | billid | getBillId() | 商户账单号 |
| billStatus | billstatus | getBillStatus() | 账单状态 |
| createTime | createtime | getCreateTime() | 创建时间 |
| notifyUrl | notifyurl | getNotifyUrl() | 通知地址 |
| payeeCusId | payeecusid | getPayeeCusId() | 收款商户号 |
| payerCusId | payercusid | getPayerCusId() | 付款商户号 |
| payTime | paytime | getPayTime() | 支付时间 |
| payTrxId | paytrxid | getPayTrxId() | 支付交易流水 |
| refundAmt | refundamt | getRefundAmt() | 退款金额 |
| remark | remark | getRemark() | 账单说明 |
| reserved | reserved | getReserved() | 账单备注信息 |
| trxAmt | trxamt | getTrxAmt() | 账单金额 |

## BillPayRefundResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxStatus | trxstatus | getTrxStatus() | 同步结果 |

## BillPaySetOfflinePayResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxStatus | trxstatus | getTrxStatus() | 同步结果 |

## CusAcctQueryAcctOverLimitResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| giveLimit | givelimit | getGiveLimit() | 授信额度 |
| leftAmt | leftamt | getLeftAmt() | 剩余额度 |
| overAmt | overamt | getOverAmt() | 透支额度 |

## CusAcctQueryBalanceResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| amount | amount | getAmount() | 账户金额 |

## CusAcctQueryHisBalanceResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| amount | amount | getAmount() | 历史金额 |

## CusAcctQueryTrxResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |
| fee | fee | getFee() | 手续费 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| payeeCusId | payeecusid | getPayeeCusId() | 收款商户号 |
| payeeTrxId | payeetrxid | getPayeeTrxId() | 入金交易单号 |
| payerCusId | payercusid | getPayerCusId() | 付款商户号 |
| remark | remark | getRemark() | 备注信息 |
| reqSn | reqsn | getReqSn() | 商户转账单号 |
| trxAmt | trxamt | getTrxAmt() | 交易金额 |

## CusAcctTransferBalResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误原因 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| payeeTrxId | payeetrxid | getPayeeTrxId() | 入金商户入金交易单号 |
| reqSn | reqsn | getReqSn() | 商户转账单号 |

## CusAcctWithDrawQueryResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| acct | acct | getAcct() | 支付平台用户标识 |
| acctType | accttype | getAcctType() | 借贷标识 |
| bankCode | bankcode | getBankCode() | 所属银行 |
| chnlTrxId | chnltrxid | getChnlTrxId() | 支付渠道交易单号 |
| fee | fee | getFee() | 手续费 |
| feeCycle | feecycle | getFeeCycle() | 结算周期 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| initAmt | initamt | getInitAmt() | 原交易金额 |
| trxAmt | trxamt | getTrxAmt() | 交易金额 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## CusAcctWithDrawResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 交易描述信息 |
| fee | fee | getFee() | 结算手续费 |
| reqSn | reqsn | getReqSn() | 请求流水号 |
| trxAmt | trxamt | getTrxAmt() | 实际结算到账金额 |

## DigitalConfirmAuthCusStateResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## DigitalQueryAuthCusStateResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| authStatus | authstatus | getAuthStatus() | 授权状态 |
| confirmStatus | confirmstatus | getConfirmStatus() | 审核状态 |

## DigitalSendCouponsResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## DigitalUrlResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| authStatus | authstatus | getAuthStatus() | 授权状态 |
| confirmStatus | confirmstatus | getConfirmStatus() | 审核状态 |

## DigitalWxCateringOrderSyncStatusResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## FileUploadResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| token | token | getToken() | 文件标识,在进件时对应字段传入 |

## FqfApplyResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| cusId | cusid | getCusId() | 商户号 |
| errMsg | errmsg | getErrMsg() | 错误原因 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| reqSn | reqsn | getReqSn() | 商户订单号 |
| sign | sign | getSign() | 签名 |
| thpInfo | thpinfo | getThpInfo() | 交易透传信息 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## FqfBbSignPageResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| bankName | bankname | getBankName() | 银行名称 |
| bbSignUrl | bbsignurl | getBbSignUrl() | 协议内容h5链接 |
| cusId | cusid | getCusId() | 商户号 |
| feeNum | feenum | getFeeNum() | 分期期数 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| yearRate | yearrate | getYearRate() | 预估年化率 |

## FqfInfoResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| bankCode | bankcode | getBankCode() | 银行代码 |
| bankName | bankname | getBankName() | 银行名称 |
| cusId | cusid | getCusId() | 商户号 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| rateList | ratelist | getRateList() | 分期信息 |
| sign | sign | getSign() | 签名 |

## FqfJDBTCountFeeResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| amt12 | amt12 | getAmt12() | 京东白条12期时每期还款 |
| amt3 | amt3 | getAmt3() | 京东白条3期时每期还款 |
| amt6 | amt6 | getAmt6() | 京东白条6期时每期还款 |
| cusId | cusid | getCusId() | 商户号 |
| fee12 | fee12 | getFee12() | 京东白条12期时每期利息 |
| fee3 | fee3 | getFee3() | 京东白条3期时每期利息 |
| fee6 | fee6 | getFee6() | 京东白条6期时每期利息 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |

## FqfJDBTPayResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误原因 |
| h52AppUrl | h52appurl | getH52AppUrl() | H5跳到京东白条app支付的url |
| h52MiniUrl | h52miniurl | getH52MiniUrl() | H5跳到京东微信小程序支付的url |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| reqSn | reqsn | getReqSn() | 商户订单号 |
| sign | sign | getSign() | 签名 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## FqfJfqPayResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| cusId | cusid | getCusId() | 商户号 |
| errMsg | errmsg | getErrMsg() | 错误原因 |
| payInfo | payinfo | getPayInfo() | 支付信息 |
| reqSn | reqsn | getReqSn() | 商户订单号 |
| sign | sign | getSign() | 签名 |

## FqfPayConfirmResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| chnlTrxId | chnltrxid | getChnlTrxId() | 渠道平台交易单号 |
| cusId | cusid | getCusId() | 商户号 |
| errMsg | errmsg | getErrMsg() | 错误原因 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| reqSn | reqsn | getReqSn() | 商户订单号 |
| sign | sign | getSign() | 签名 |
| thpInfo | thpinfo | getThpInfo() | 交易透传信息 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## MerChantAcctEditResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| auditStatus | auditstatus | getAuditStatus() | 审核状态 |
| errMsg | errmsg | getErrMsg() | 错误信息 |

## MerChantAddResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| auditStatus | auditstatus | getAuditStatus() | 审核状态 |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| merChantId | merchantid | getMerChantId() | 代理商商户号 |
| reqId | reqid | getReqId() | 进件请求流水号 |

## MerChantAddTermResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## MerChantAgentExpiredResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## MerChantBindCodeResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| branchNo | branchno | getBranchNo() | 当面付二维码 |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| latitude | latitude | getLatitude() | 纬度 |
| longitude | longitude | getLongitude() | 经度 |
| qrCode | qrcode | getQrCode() | 当面付二维码 |
| tel | tel | getTel() | 财务联系人手机号 |

## MerChantConfirmBindResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| branchNo | branchno | getBranchNo() | 当面付二维码 |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| latitude | latitude | getLatitude() | 纬度 |
| longitude | longitude | getLongitude() | 经度 |
| qrCode | qrcode | getQrCode() | 当面付二维码 |
| tel | tel | getTel() | 财务联系人手机号 |

## MerChantConfirmUnBindResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |
| qrCode | qrcode | getQrCode() | 当面付二维码 |

## MerChantEditResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| auditStatus | auditstatus | getAuditStatus() | 审核状态 |
| errMsg | errmsg | getErrMsg() | 错误信息 |

## MerChantElectSignResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |

## MerChantProdFeeShareQryResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| crLimitAmt | crlimitamt | getCrLimitAmt() | 消费-信用卡补贴总额度 |
| crLimitFlag | crlimitflag | getCrLimitFlag() | 是否限制消费-信用卡补贴总额度 |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| limitAmt | limitamt | getLimitAmt() | 单笔限额 |
| overPadFlag | overpadflag | getOverPadFlag() | 单笔超限是否补贴 |
| prodFeeShareList | prodfeesharelist | getProdFeeShareList() | 产品补贴费率列表json格式数组 |
| shareBalance | sharebalance | getShareBalance() | 补贴余额 |
| shareCrBalance | sharecrbalance | getShareCrBalance() | 信用卡补贴余额 |
| shareCusId | sharecusid | getShareCusId() | 承担方客户号 |
| shareDrBalance | sharedrbalance | getShareDrBalance() | 消费-借记卡补贴剩余额度 |
| shareQrBalance | shareqrbalance | getShareQrBalance() | 扫码交易补贴剩余额度 |
| shareSumAmt | sharesumamt | getShareSumAmt() | 手续费补贴总额度 |
| shareType | sharetype | getShareType() | 承担方类型 |
| validBegin | validbegin | getValidBegin() | 生效开始时间 |
| validEnd | validend | getValidEnd() | 生效结束时间 |
| validState | validstate | getValidState() | 是否生效状态 |

## MerChantProductResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| auditStatus | auditstatus | getAuditStatus() | 审核状态 |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| prodList | prodlist | getProdList() | 门店信息列表json格式 |

## MerChantQrCodeQryResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| branchNo | branchno | getBranchNo() | 门店号 |
| openFlag | openflag | getOpenFlag() | 绑定标识 |
| qrcodeList | qrcodelist | getQrcodeList() | 码牌列表数组 |
| qrcodeStatus | qrcodestatus | getQrcodeStatus() | 码牌状态 |
| qrType | qrtype | getQrType() | 码牌类型 |
| validTime | validtime | getValidTime() | 绑定时间 |

## MerChantQryTermResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| alMsg | almsg | getAlMsg() | 支付宝报备错误信息 |
| alState | alstate | getAlState() | 支付宝报备状态 |
| appId | appid | getAppId() | 应用ID |
| cusId | cusid | getCusId() | 商户号 |
| deviceType | devicetype | getDeviceType() | 设备类型 |
| sign | sign | getSign() | 签名 |
| termAddress | termaddress | getTermAddress() | 终端地址 |
| termNo | termno | getTermNo() | 终端号 |
| termSn | termsn | getTermSn() | 终端序列号 |
| termState | termstate | getTermState() | 终端状态 |
| unMsg | unmsg | getUnMsg() | 银联报备错误信息 |
| unState | unstate | getUnState() | 银联报备状态 |
| wxMsg | wxmsg | getWxMsg() | 微信报备错误信息 |
| wxState | wxstate | getWxState() | 微信报备状态 |

## MerChantQueryChnlCmIdResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| chnlType | chnltype | getChnlType() | 渠道类型 |
| cmId | cmid | getCmId() | 对应类型子商户号 |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| payChnl | paychnl | getPayChnl() | 渠道号 |
| settId | settid | getSettId() | 结算id |

## MerChantQueryCusRgcResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| cfState | cfstate | getCfState() | 审核状态 |
| handleDetail | handledetail | getHandleDetail() | 审核详情json数组 |
| handleMsg | handlemsg | getHandleMsg() | 审核异常错误信息 |
| handleState | handlestate | getHandleState() | 审核结果 |
| needRepair | needrepair | getNeedRepair() | 是否需要补录 |
| rgcType | rgctype | getRgcType() | 合规性类型 |

## MerChantQueryElectSignResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| electSignStatus | electsignstatus | getElectSignStatus() | 协议状态 |
| errMsg | errmsg | getErrMsg() | 错误信息 |

## MerChantQueryElectUrlResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |
| sybSignUrl | sybsignurl | getSybSignUrl() | 无纸化签约协议 |

## MerChantQueryResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| acctId | acctid | getAcctId() | 账户号 |
| acctName | acctname | getAcctName() | 账户名 |
| acctTp | accttp | getAcctTp() | 卡折类型 |
| acctType | accttype | getAcctType() | 账户类型 |
| addFaCusId | addfacusid | getAddFaCusId() | 所属父客户 |
| address | address | getAddress() | 注册地址 |
| agreeType | agreetype | getAgreeType() | 无纸化标识 |
| bankCode | bankcode | getBankCode() | 所属银行 |
| bnfDetail | bnfdetail | getBnfDetail() | 受益人信息json |
| busAddress | busaddress | getBusAddress() | 商户经营地址 |
| busConactPerson | busconactperson | getBusConactPerson() | 业务联系人姓名 |
| busConactTel | busconacttel | getBusConactTel() | 业务联系人电话 |
| busDetail | busdetail | getBusDetail() | 经营内容 |
| businessPlace | businessplace | getBusinessPlace() | 经营场所 |
| city | city | getCity() | 所在市 |
| clearMode | clearmode | getClearMode() | 结算方式 |
| clearTimeRule | cleartimerule | getClearTimeRule() | 结算时间 |
| cnapsno | cnapsno | getCnapsno() | 支付行号 |
| comProperty | comproperty | getComProperty() | 商户性质 |
| contactPerson | contactperson | getContactPerson() | 商户负责人 |
| contactPhone | contactphone | getContactPhone() | 商户负责人电话 |
| corpBusName | corpbusname | getCorpBusName() | 营业执照名称 |
| creditCode | creditcode | getCreditCode() | 统一社会信用代码证 |
| creditCodeExpire | creditcodeexpire | getCreditCodeExpire() | 社会信用代码证有效期 |
| cusUrl | cusurl | getCusUrl() | 网站url或下载地址或平台名称 |
| districtCode | districtcode | getDistrictCode() | 所在区 |
| expandUser | expanduser | getExpandUser() | 拓展人 |
| feeCycle | feecycle | getFeeCycle() | 加收手续费收费周期 |
| holderExpire | holderexpire | getHolderExpire() | 控股股东有效期 |
| holderIdNo | holderidno | getHolderIdNo() | 控股股东身份证 |
| holderName | holdername | getHolderName() | 控股股东姓名 |
| holidayFee | holidayfee | getHolidayFee() | 节假日手续费加收 |
| innerManage | innermanage | getInnerManage() | 签约类型 |
| inspect | inspect | getInspect() | 经营地段 |
| isCollect | iscollect | getIsCollect() | 是否归集 |
| legal | legal | getLegal() | 法人姓名 |
| legalDetail | legaldetail | getLegalDetail() | 法人信息json |
| legalIdExpire | legalidexpire | getLegalIdExpire() | 法人身份证有效期 |
| legalIdNo | legalidno | getLegalIdNo() | 法人代表证件号 |
| legalIdType | legalidtype | getLegalIdType() | 法人代表证件类型 |
| mccId | mccid | getMccId() | 所属行业 |
| merChantName | merchantname | getMerChantName() | 商户名称 |
| ofFlag | offlag | getOfFlag() | 线上线下业务场景 |
| operateLimit | operatelimit | getOperateLimit() | 经营区域 |
| organCode | organcode | getOrganCode() | 组织机构代码证号 |
| organExpire | organexpire | getOrganExpire() | 组织机构代码证有效期 |
| prodList | prodlist | getProdList() | 支付产品信息列表 |
| province | province | getProvince() | 所在省 |
| registerFund | registerfund | getRegisterFund() | 注册资本 |
| secondSwitch | secondswitch | getSecondSwitch() | 是否秒到 |
| servicePhone | servicephone | getServicePhone() | 客服电话 |
| settIdNo | settidno | getSettIdNo() | 结算人身份证号 |
| settRemark | settremark | getSettRemark() | 结算摘要前缀 |
| shortName | shortname | getShortName() | 商户简称 |
| staffTotal | stafftotal | getStaffTotal() | 员工人数 |
| status | status | getStatus() | 商户状态 |
| subBranchList | subbranchlist | getSubBranchList() | 门店信息 |
| taxDetail | taxdetail | getTaxDetail() | 税务登记详情json |
| thrCertFlag | thrcertflag | getThrCertFlag() | 是否三证合一 |
| unsdRemark | unsdremark | getUnsdRemark() | 渠道备注 |
| webName | webname | getWebName() | 网站名称/应用名称 |

## MerChantQueryStatusResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| auditStatus | auditstatus | getAuditStatus() | 审核状态 |
| errMsg | errmsg | getErrMsg() | 审核失败错误信息 |
| merId | merid | getMerId() | 进件平台商户号 |
| reqId | reqid | getReqId() | 进件平台商户号 |

## MerChantQueryWxSubDevResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appidConfigList | appid_config_list | getAppidConfigList() | 关联APPID与关注 |
| defAppId | def_appid | getDefAppId() | 默认APPID |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| jsapiPathList | jsapi_path_list | getJsapiPathList() | 授权目录 |
| wxMchId | wxmchid | getWxMchId() | 微信子商户号 |

## MerChantQueryWxVerifyStateResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| cmId | cmid | getCmId() | 对应类型子商户号 |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| payChnl | paychnl | getPayChnl() | 渠道号 |
| pid | pid | getPid() | 产品类型 |
| verifyState | verifystate | getVerifyState() | 微信认证状态 |

## MerChantRepairComplianceResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| trxStatus | trxstatus | getTrxStatus() | 状态 |

## MerChantSubBranchResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| addBranchs | addbranchs | getAddBranchs() | 新增门店结果 |
| auditStatus | auditstatus | getAuditStatus() | 审核状态 |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| subBranchList | subbranchlist | getSubBranchList() | 门店信息列表json格式 |

## MerChantTermResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| addTerms | addterms | getAddTerms() | 新增生成终端号#号分隔 |
| auditStatus | auditstatus | getAuditStatus() | 审核状态 |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| termList | termlist | getTermList() | 终端信息列表json格式 |

## MerChantUnBindCodeResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |
| qrCode | qrcode | getQrCode() | 当面付二维码 |
| tel | tel | getTel() | 财务联系人手机号 |

## MerChantWxSubDevConfigResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |

## MktForwardResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| bizData | bizdata | getBizData() | 业务参数(json字符串) |
| cusId | cusid | getCusId() | 商户号 |
| resultCode | result_code | getResultCode() | 业务结果码 |
| resultMsg | result_msg | getResultMsg() | 业务处理结果信息 |
| sign | sign | getSign() | 签名 |

## PayScorePayResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| chnlTrxId | chnltrxid | getChnlTrxId() | 渠道平台交易单号 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## PayScoreServiceOrderResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| bizCode | bizcode | getBizCode() | 业务错误码 |
| bizErrMsg | bizerrmsg | getBizErrMsg() | 错误原因 |
| bizRsp | bizrsp | getBizRsp() | 业务参数返回 |
| cusId | cusid | getCusId() | 商户号 |
| sign | sign | getSign() | 签名 |
| statusCode | statuscode | getStatusCode() | 状态码 |

## PosolAuthFinResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| acct | acct | getAcct() | 卡号 |
| aptCode | aptcode | getAptCode() | 收单机构 |
| bankName | bankname | getBankName() | 发卡机构 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| outTrxId | outtrxid | getOutTrxId() | 交易单号 |
| termAuthNo | termauthno | getTermAuthNo() | 授权码 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## PosolCancelResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| finTime | fintime | getFinTime() | 交易完成时间 |
| outTrxId | outtrxid | getOutTrxId() | 交易单号 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## PosolQueryResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| acct | acct | getAcct() | 交易账号 |
| chnlTrxId | chnltrxid | getChnlTrxId() | 支付渠道交易单号 |
| cusId | cusid | getCusId() | 商户号 |
| fee | fee | getFee() | 手续费 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| reqSn | reqsn | getReqSn() | 商户平台订单号 |
| srcTrxId | srctrxid | getSrcTrxId() | 原交易流水 |
| termAuthNo | termauthno | getTermAuthNo() | 授权码 |
| trxAmt | trxamt | getTrxAmt() | 交易金额 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## PreScanPayCancelResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## PreScanPayFinishResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## PreScanPayQueryResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| acct | acct | getAcct() | 支付平台用户标识 |
| backAmt | backamt | getBackAmt() | 预消费已回退金额 |
| chnlTrxId | chnltrxid | getChnlTrxId() | 支付渠道交易单号 |
| finishAmt | finishamt | getFinishAmt() | 预消费已完成金额 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxAmt | trxamt | getTrxAmt() | 预消费交易金额 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## PreScanPayRefundResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## PreScanPayResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| chnlTrxId | chnltrxid | getChnlTrxId() | 渠道平台交易单号 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| payInfo | payinfo | getPayInfo() | 支付串 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## QPayAgreeApplyResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| thpInfo | thpinfo | getThpInfo() | 交易透传信息 |
| trxStatus | trxstatus | getTrxStatus() | 状态 |

## QPayAgreeConfirmResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| agreeId | agreeid | getAgreeId() | 协议编号 |
| bankCode | bankcode | getBankCode() | 银行代码 |
| bankName | bankname | getBankName() | 银行名称 |
| errMsg | errmsg | getErrMsg() | 错误信息 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| trxStatus | trxstatus | getTrxStatus() | 状态 |

## QPayApplyResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| thpInfo | thpinfo | getThpInfo() | 交易透传信息 |
| trxStatus | trxstatus | getTrxStatus() | 状态 |

## QPayConfirmResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| thpInfo | thpinfo | getThpInfo() | 交易透传信息 |
| trxStatus | trxstatus | getTrxStatus() | 状态 |

## QPaySmsAgreeResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| thpInfo | thpinfo | getThpInfo() | 交易透传信息 |

## QPayUnbindResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |

## RiskFeeBackAliComplaintFileUploadResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| records | records | getRecords() | 结果 |

## RiskFeeBackAliComplaintProcessFinishResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| complaintProcessSuccess | complaint_process_success | getComplaintProcessSuccess() | 投诉处理是否成功 |

## RiskFeeBackAliComplaintQueryResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| records | records | getRecords() | 返回结果 |

## RiskFeeBackAliComplaintQueryV2Response

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| records | records | getRecords() | 记录 |

## RiskFeeBackWxAppletBussiAppealResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## RiskFeeBackWxAppletBussiRespondComplaintResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## RiskFeeBackWxAppletBussiSupplyProofResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## RiskFeeBackWxAppletBussiSupplyRefundResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## RiskFeeBackWxAppletComplaintOrderDetailResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| records | records | getRecords() | 记录 |

## RiskFeeBackWxAppletComplaintQueryResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| records | records | getRecords() | 返回结果 |

## RiskFeeBackWxAppletUploadResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## RiskFeeBackWxComplaintCompleteResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| handleMsg | handlemsg | getHandleMsg() | 提示语 |
| handleState | handlestate | getHandleState() | 处理状态 |

## RiskFeeBackWxComplaintDetailResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| records | records | getRecords() | 记录 |

## RiskFeeBackWxComplaintHistoryResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| records | records | getRecords() | 记录 |

## RiskFeeBackWxComplaintListQueryResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| records | records | getRecords() | 记录 |
| totalCount | total_count | getTotalCount() | 总条数 |

## RiskFeeBackWxComplaintRespResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## RiskFeeBackWxComplaintSreFundProgressResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## RiskFeeBackWxGetMerchantImageResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| imageBase64 | imagebase64 | getImageBase64() | 图片信息 |

## RiskFeeBackWxMerchantImageUploadResponse

> Extends: AllinpayRespRisk

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| mediaId | mediaid | getMediaId() | 图片id |

## SybServiceAlinFcConfigResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## SybServiceAlinFcQueryResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| branchNo | branchno | getBranchNo() | 门店号 |
| deviceList | devicelist | getDeviceList() | 设备列表数组 |
| openFlag | openflag | getOpenFlag() | 绑定标识 |

## SybServiceAsAgreeConfigQryResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| status | status | getStatus() | 授权状态 |

## SybServiceAsAgreeConfigResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## SybServiceIotDevConfigResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## SybServiceIotDevQueryResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| branchNo | branchno | getBranchNo() | 门店号 |
| deviceType | devicetype | getDeviceType() | 设备类型 |
| openFlag | openflag | getOpenFlag() | 绑定标识 |
| pidList | pidlist | getPidList() | 适用产品 |
| validTime | validtime | getValidTime() | 绑定时间 |

## SybServiceQueryCouponDetailResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| availableBeginTime | availablebegintime | getAvailableBeginTime() | 可用开始时间 |
| availableEndTime | availableendtime | getAvailableEndTime() | 可用结束时间 |
| couponId | couponid | getCouponId() | 代金券id |
| couponName | couponname | getCouponName() | 代金券名称 |
| couponType | coupontype | getCouponType() | 券类型 |
| createTime | createtime | getCreateTime() | 领券时间 |
| description | description | getDescription() | 使用说明 |
| noCash | nocash | getNoCash() | 是否无资金流 |
| normalCouponInformation | normalcouponinformation | getNormalCouponInformation() | 普通满减券面额、门槛信息 |
| singleItem | singleitem | getSingleItem() | 是否单品优惠 |
| status | status | getStatus() | 代金券状态 |
| stockCreatorMchId | stockcreatormchid | getStockCreatorMchId() | 创建批次的商户号 |
| stockId | stockid | getStockId() | 批次号 |

## SybServiceQueryStockDetailResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| availableBeginTime | availablebegintime | getAvailableBeginTime() | 可用开始时间 |
| availableEndTime | availableendtime | getAvailableEndTime() | 可用结束时间 |
| createTime | createtime | getCreateTime() | 创建时间 |
| description | description | getDescription() | 使用说明 |
| distributedCoupons | distributedcoupons | getDistributedCoupons() | 已发券数量 |
| noCash | nocash | getNoCash() | 是否无资金流 |
| singleItem | singleitem | getSingleItem() | 是否单品优惠 |
| status | status | getStatus() | 批次状态 |
| stockCreatorMchId | stockcreatormchid | getStockCreatorMchId() | 创建批次的商户号 |
| stockId | stockid | getStockId() | 批次号 |
| stockName | stockname | getStockName() | 批次名称 |
| stockType | stocktype | getStockType() | 批次类型 |
| stockUseRule | stockuserule | getStockUseRule() | 普通发券批次特定信息 |

## SybServiceQueryStockRefundFlowResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| hashType | hashtype | getHashType() | 哈希算法类型 |
| hashValue | hashvalue | getHashValue() | 安全校验码 |
| header | header | getHeader() | 头部类型 |
| url | url | getUrl() | 下载链接 |

## SybServiceQueryStockUseFlowResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| hashType | hashtype | getHashType() | 哈希算法类型 |
| hashValue | hashvalue | getHashValue() | 安全校验码 |
| header | header | getHeader() | 头部类型 |
| url | url | getUrl() | 下载链接 |

## SybServiceSearchCusPackageResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| pkgList | pkglist | getPkgList() | 套餐列表 |

## SybServiceSendCouponsResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |
| status | status | getStatus() | 操作状态 |

## SybServiceUploadElectTicketResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| (inherits only) | - | - | 本类未声明私有字段；请参考 Extends 父类字段。 |

## SybServiceWxCateringOrderSyncStatusResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误信息 |
| status | status | getStatus() | 操作状态 |

## TlinvoiceCancleInvoiceResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| sign | sign | getSign() | 签名 |
| status | status | getStatus() | 冲红状态 |

## TlinvoiceGenerateInviteQRResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| qrUrl | qrurl | getQrUrl() | 请求链接 |
| sign | sign | getSign() | 签名 |

## TlinvoiceGenerateInvoiceQRResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| applyId | applyid | getApplyId() | 发票申请单号 |
| qrUrl | qrurl | getQrUrl() | 电票链接 |
| sign | sign | getSign() | 签名 |

## TlinvoiceGenerateInvoiceQRSimpleResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| applyId | applyid | getApplyId() | 发票申请单号 |
| qrUrl | qrurl | getQrUrl() | 电票链接 |
| sign | sign | getSign() | 签名 |

## TlinvoiceGetInvoiceDownloadUrlResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| downloadUrl | downloadurl | getDownloadUrl() | 下载地址 |
| sign | sign | getSign() | 签名 |

## TlinvoiceGetInvoiceOpenStatusResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| code | code | getCode() | 开通状态 |
| message | message | getMessage() | 开通信息 |
| sign | sign | getSign() | 签名 |

## TlinvoiceGetInvoiceProdCodeListResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| prodcodeList | prodcodelist | getProdcodeList() | 开票品类列表 |
| sign | sign | getSign() | 签名 |

## TlinvoiceGetRecordStatusResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| errMsg | errmsg | getErrMsg() | 错误原因 |
| sign | sign | getSign() | 签名 |
| status | status | getStatus() | 状态 |

## TranxCancelResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| bankCode | bankcode | getBankCode() | 所属银行 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## TranxCloseResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## TranxQueryConfirmResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| acct | acct | getAcct() | 支付平台用户标识 |
| chnlId | chnlid | getChnlId() | 渠道商号 |
| chnlTrxId | chnltrxid | getChnlTrxId() | 支付渠道流水号 |
| cmId | cmid | getCmId() | 渠道子商户号 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxAmt | trxamt | getTrxAmt() | 交易金额 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易结果码 |

## TranxQueryOrderResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| amount | amount | getAmount() | 金额 |
| branchNo | branchno | getBranchNo() | 门店号 |
| chnlData | chnldata | getChnlData() | 渠道信息 |
| chnlTrxId | chnltrxid | getChnlTrxId() | 支付渠道流水号 |
| cmId | cmid | getCmId() | 渠道子商户号 |
| fee | fee | getFee() | 手续费 |
| feeCycle | feecycle | getFeeCycle() | 结算周期 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| fqNum | fqnum | getFqNum() | 分期数 |
| initAmt | initamt | getInitAmt() | 原交易金额 |
| orderId | orderid | getOrderId() | 商户平台订单号 |
| srcTrxId | srctrxid | getSrcTrxId() | 原交易流水 |
| termAuthNo | termauthno | getTermAuthNo() | 授权码 |
| termBatchId | termbatchid | getTermBatchId() | 终端批次号 |
| termNo | termno | getTermNo() | 终端号 |
| termRefNum | termrefnum | getTermRefNum() | 参考号 |
| traceNo | traceno | getTraceNo() | 终端流水 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxDate | trxdate | getTrxDate() | 交易请求日期 |
| trxErrMsg | trxerrmsg | getTrxErrMsg() | 交易错误信息 |
| trxReserve | trxreserve | getTrxReserve() | 交易备注 |
| trxStatus | trxstatus | getTrxStatus() | 交易结果码 |

## TranxQueryResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| acct | acct | getAcct() | 支付平台用户标识 |
| acctType | accttype | getAcctType() | 借贷标识 |
| bankCode | bankcode | getBankCode() | 所属银行 |
| chnlData | chnldata | getChnlData() | 渠道信息 |
| chnlId | chnlid | getChnlId() | 渠道号 |
| chnlTrxId | chnltrxid | getChnlTrxId() | 支付渠道交易单号 |
| cmId | cmid | getCmId() | 渠道子商户号 |
| fee | fee | getFee() | 手续费 |
| feeCycle | feecycle | getFeeCycle() | 结算周期 |
| feeFq | feefq | getFeeFq() | 分期商户贴息手续费 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| fqNum | fqnum | getFqNum() | 分期数 |
| initAmt | initamt | getInitAmt() | 原交易金额 |
| logonId | logonid | getLogonId() | 买家账号 |
| tlOpenId | tlopenid | getTlOpenId() | 通联渠道侧OPENID |
| trxAmt | trxamt | getTrxAmt() | 交易金额 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxReserve | trxreserve | getTrxReserve() | 交易备注 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## TranxRefundResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| bankCode | bankcode | getBankCode() | 所属银行 |
| chnlData | chnldata | getChnlData() | 渠道信息 |
| chnlTrxId | chnltrxid | getChnlTrxId() | 渠道流水号 |
| fee | fee | getFee() | 手续费 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## TrxFileGetResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| url | url | getUrl() | 下载对账文件的url |

## TrxFileSettTrxResponse

> Extends: AllinpayRespMer

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxList | trxlist | getTrxList() | 结算单列表 |

## TrxShareQueryResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| finTime | fintime | getFinTime() | 交易完成时间 |
| payeeCusId | payeecusid | getPayeeCusId() | 入金商户号 |
| payerTrxId | payertrxid | getPayerTrxId() | 回退出金交易单号 |
| reqSn | reqsn | getReqSn() | 商户平台订单号 |
| trxAmt | trxamt | getTrxAmt() | 分账金额 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## TrxShareRevokeQueryResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| finTime | fintime | getFinTime() | 交易完成时间 |
| payerCusId | payercusid | getPayerCusId() | 出金商户号 |
| reqSn | reqsn | getReqSn() | 商户平台订单号 |
| rkTrxId | rktrxid | getRkTrxId() | 回退交易单号 |
| trxAmt | trxamt | getTrxAmt() | 分账金额 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## TrxShareRevokeResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| finTime | fintime | getFinTime() | 交易完成时间 |
| payerTrxId | payertrxid | getPayerTrxId() | 回退出金交易单号 |
| reqSn | reqsn | getReqSn() | 商户平台订单号 |
| rkTrxId | rktrxid | getRkTrxId() | 回退交易单号 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## TrxShareShareResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| finTime | fintime | getFinTime() | 交易完成时间 |
| payeeTrxId | payeetrxid | getPayeeTrxId() | 入金商户入金交易单号 |
| payerTrxId | payertrxid | getPayerTrxId() | 出金交易单号 |
| reqSn | reqsn | getReqSn() | 商户平台订单号 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## UnConscsPayAgreeApplyResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| applyId | applyid | getApplyId() | 申请id |
| cusId | cusid | getCusId() | 商户号 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| signInfo | signinfo | getSignInfo() | 协议签约信息 |

## UnConscsPayAgreePayResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| applyId | applyid | getApplyId() | 申请id |
| cusId | cusid | getCusId() | 商户号 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| signInfo | signinfo | getSignInfo() | 协议签约信息 |

## UnConscsPayAgreeUnbindResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxStatus | trxstatus | getTrxStatus() | 结果错误码 |

## UnConscsPayAndSignResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| payInfo | payinfo | getPayInfo() | 支付信息 |
| trxStatus | trxstatus | getTrxStatus() | 结果错误码 |

## UnConscsPayTokenApplyResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| applyId | applyid | getApplyId() | 申请id |
| cusId | cusid | getCusId() | 商户号 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| signInfo | signinfo | getSignInfo() | 协议签约信息 |

## UnConscsPayTokenPayResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxStatus | trxstatus | getTrxStatus() | 结果错误码 |

## UnConscsPayTokenSetNoverResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxStatus | trxstatus | getTrxStatus() | 结果错误码 |

## UnConscsPayTokenSmsResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| thpInfo | thpinfo | getThpInfo() | 校验信息 |
| trxStatus | trxstatus | getTrxStatus() | 结果错误码 |

## UnConscsPayTokenUnbindResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxStatus | trxstatus | getTrxStatus() | 结果错误码 |

## UnionPayYJHXCmnResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| cusId | cusid | getCusId() | 商户号 |
| data | data | getData() | 业务处理详情 |
| handleDesc | handledesc | getHandleDesc() | 业务处理描述 |
| handleResult | handleresult | getHandleResult() | 业务处理码 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |

## UnionPayYJHXCoupResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| cusId | cusid | getCusId() | 商户号 |
| data | data | getData() | 业务处理详情 |
| handleDesc | handledesc | getHandleDesc() | 业务处理描述 |
| handleResult | handleresult | getHandleResult() | 业务处理码 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |

## UnitOrderAuthCode2UserIdResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| acct | acct | getAcct() | 支付平台用户标识 |
| appId | appid | getAppId() | 应用ID |
| cusId | cusid | getCusId() | 商户号 |
| sign | sign | getSign() | 签名 |

## UnitOrderCloseNativeResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## UnitOrderCreateZhiResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| cusId | cusid | getCusId() | 商户号 |
| expireDate | expiredate | getExpireDate() | 有效期 |
| shareToken | sharetoken | getShareToken() | 吱口令 |
| sign | sign | getSign() | 签名 |

## UnitOrderNativePayResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| payInfo | payinfo | getPayInfo() | 支付串 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## UnitOrderPayResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| chnlTrxId | chnltrxid | getChnlTrxId() | 渠道平台交易单号 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| payInfo | payinfo | getPayInfo() | 支付串 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## UnitOrderScanQrPayResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| acct | acct | getAcct() | 支付平台用户标识 |
| acctType | accttype | getAcctType() | 借贷标识 |
| bankCode | bankcode | getBankCode() | 发卡行号 |
| chnlData | chnldata | getChnlData() | 渠道信息 |
| chnlId | chnlid | getChnlId() | 渠道子商户号 |
| chnlTrxId | chnltrxid | getChnlTrxId() | 渠道平台交易单号 |
| cmId | cmid | getCmId() | 渠道子商户号 |
| fee | fee | getFee() | 手续费 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| initAmt | initamt | getInitAmt() | 原交易金额 |
| isCoFee | iscofee | getIsCoFee() | 是否启用手续费补贴 |
| tlOpenId | tlopenid | getTlOpenId() | 通联渠道侧OPENID |
| trxAmt | trxamt | getTrxAmt() | 实际交易金额 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

## UnitOrderWxFacePayInfoResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| authInfo | authinfo | getAuthInfo() | 授权信息 |
| cusId | cusid | getCusId() | 商户号 |
| expiresin | expiresin | getExpiresin() | 有效期 |
| sign | sign | getSign() | 签名 |
| wxAppId | wxappid | getWxAppId() | 通联微信appid |
| wxMchId | wxmchid | getWxMchId() | 通联微信商户mchid |
| wxSubMchId | wxsubmchid | getWxSubMchId() | 微信子商户sub_mchid_id |

## UnYwPayResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| applyId | applyid | getApplyId() | 申请id |
| cusId | cusid | getCusId() | 商户号 |
| randomStr | randomstr | getRandomStr() | 随机字符串 |
| sign | sign | getSign() | 签名 |
| signInfo | signinfo | getSignInfo() | 协议签约信息 |

## ZhimaCreditMiniOrderResponse

> Extends: AllinpayResp

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| appId | appid | getAppId() | 应用ID |
| bizCode | bizcode | getBizCode() | 支付宝网关返回码 |
| bizData | bizdata | getBizData() | 业务参数返回 |
| bizMsg | bizmsg | getBizMsg() | 支付宝网关返回错误信息 |
| bizSubCode | bizsubcode | getBizSubCode() | 支付宝业务错误码 |
| bizSubMsg | bizsubmsg | getBizSubMsg() | 支付宝业务错误原因 |
| cusId | cusid | getCusId() | 商户号 |
| sign | sign | getSign() | 签名 |

## ZhimaCreditPayOrderResponse

> Extends: AllinpayRespTranx

| Field | JSON Field | Getter | Description |
|---|---|---|---|
| acct | acct | getAcct() | 支付平台用户标识 |
| chnlExtendParams | chnlextendparams | getChnlExtendParams() | 渠道扩展字段 |
| chnlId | chnlid | getChnlId() | 渠道号 |
| chnlTrxId | chnltrxid | getChnlTrxId() | 渠道平台交易单号 |
| cmId | cmid | getCmId() | 渠道子商户号 |
| finTime | fintime | getFinTime() | 交易完成时间 |
| trxCode | trxcode | getTrxCode() | 交易类型 |
| trxStatus | trxstatus | getTrxStatus() | 交易状态 |

