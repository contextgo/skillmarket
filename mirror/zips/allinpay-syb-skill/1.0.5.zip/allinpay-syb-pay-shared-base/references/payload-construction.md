# 参数建模与请求构造规范（Payload Construction，SYB）

目标：让 Demo/集成代码“可读、可排查、可演进”，避免把一堆字段直接拼字符串导致联调困难。

## 1) 推荐顺序（先校验后发请求）

```text
1) 判定场景（选哪个 Request 类）
2) 根据必填矩阵填必填/条件必填字段
3) 做本地校验（格式/金额/URL/长度）
4) 记录请求关键字段日志（脱敏）
5) 调用 SDK 发起请求
6) 记录响应日志（脱敏）
7) 用“回调 + 查询”确认终态（重要交易）
```

## 2) Java SDK `*Request` 入参类型（闭集白名单）

- 业务技能 `reference/sdk-request-java-field-types.md` 已对 `allinpay-syb-sdk-java` 包 `com.allinpay.syb.sdk.api.request` 内全部 `*Request` 与 `AllinpayReq` 做枚举：**除该文档表列白名单字段外，所有 `setXxx(...)` 入参类型均为 `java.lang.String`**。  
- 生成或改写 Demo：**默认** `setXxx("…")`；**禁止**把金额、枚举、笔数等改成 `int`/`long`/`BigDecimal`/`boolean` 等再直传 setter。  
- 仅允许对白名单字段使用 `byte[]`、`Map<String,String>`、`UnionPayYJHXVoBiz` 等；**禁止**凭语义臆造其它非 `String` 类型。

## 3) 关键字段的本地校验建议（高收益）

| 字段 | 建议校验 | 说明 |
| --- | --- | --- |
| `reqsn` | 非空 + 全局唯一 | 幂等关键字段 |
| `trxamt` | 数字 + \>0 + 单位分 | 与业务金额一致 |
| `notify_url` | https 优先 + 公网可达 | 回调必须验签+幂等 |
| `signtype` | 枚举值合法 | 与平台开通一致 |

## 4) 关于加密字段（`@EncryptField`）

- 调用方**传明文**
- SDK 自动进行 SM4 加密（前提是已正确配置 `sm4Key`）
- 不要在日志打印明文敏感字段

## 5) Demo 输出不要“猜字段”

如果用户未提供运行时值来源：

- 必须使用 `YOUR_XXX` 占位符
- 并提示该值从哪里获取（见 `customer-preparation.md`）

## 6) 资料对照（在哪里查必填/字段名/驼峰）

- 必填矩阵：业务 Skill 的 `catalog/req-matrix/`
- 请求字段规则表：业务 Skill 的 `catalog/req-matrix/`
- 常见响应字段 JSON->Java getter 对照：业务 Skill 的 `catalog/global-enum.md`

