# Request Routing Map - GateWay

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| GateWayH5Request | 网关支付API-H5网关订单提交接口 | `request-requiredness-matrix/request-requiredness-matrix-gateway.md` |
| GateWayPCRequest | 网关支付API-PC网关订单提交接口 | `request-requiredness-matrix/request-requiredness-matrix-gateway.md` |
