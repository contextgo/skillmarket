# Request Routing Map - H5

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| H5BillPayBillPayRequest | H5账单付款（商户网站->账单付款页面） | `request-requiredness-matrix/request-requiredness-matrix-h5.md` |
| H5UnionPayOrderRequest | 收银台-H5收银台 | `request-requiredness-matrix/request-requiredness-matrix-h5.md` |
