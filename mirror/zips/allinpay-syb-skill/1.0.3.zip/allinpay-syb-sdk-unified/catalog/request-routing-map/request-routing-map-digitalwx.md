# Request Routing Map - DigitalWx

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| DigitalWxCateringOrderSyncStatusRequest | 微信点餐 | `request-requiredness-matrix/request-requiredness-matrix-digitalwx.md` |
