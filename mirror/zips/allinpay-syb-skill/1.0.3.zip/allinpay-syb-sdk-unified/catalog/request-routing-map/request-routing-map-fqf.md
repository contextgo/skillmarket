# Request Routing Map - Fqf

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| FqfApplyRequest | 统一分期-分期付-分期支付申请 | `request-requiredness-matrix/request-requiredness-matrix-fqf.md` |
| FqfBbSignPageRequest | 统一分期-分期付-笔笔签协议获取 | `request-requiredness-matrix/request-requiredness-matrix-fqf.md` |
| FqfInfoRequest | 统一分期-分期付-获取分期信息 | `request-requiredness-matrix/request-requiredness-matrix-fqf.md` |
| FqfJDBTCountFeeRequest | 统一分期-分期付-京东白条利息计算 | `request-requiredness-matrix/request-requiredness-matrix-fqf.md` |
| FqfJDBTPayRequest | 统一分期-京东白条下单 | `request-requiredness-matrix/request-requiredness-matrix-fqf.md` |
| FqfJfqPayRequest | 统一分期-聚分期下单 | `request-requiredness-matrix/request-requiredness-matrix-fqf.md` |
| FqfPayConfirmRequest | 统一分期-分期付-分期支付确认 | `request-requiredness-matrix/request-requiredness-matrix-fqf.md` |
