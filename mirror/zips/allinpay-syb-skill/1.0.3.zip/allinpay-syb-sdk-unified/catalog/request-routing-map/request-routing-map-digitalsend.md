# Request Routing Map - DigitalSend

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| DigitalSendCouponsRequest | 微信代金券 | `request-requiredness-matrix/request-requiredness-matrix-digitalsend.md` |
