# Request Routing Map - ZhimaCredit

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| ZhimaCreditMiniOrderRequest | 支付宝先享后付请求接口 (bizData json->utf8->base64 for api-code mapping entity) | `request-requiredness-matrix/request-requiredness-matrix-zhimacredit.md` |
| ZhimaCreditPayRequest | 支付宝先享后付-业务订单扣款 | `request-requiredness-matrix/request-requiredness-matrix-zhimacredit.md` |
| ZhimaCreditTCMiniOrderChanged | 支付宝先享后付请求接口 - api-code mapping entity - 业务状态变更通知 | `request-requiredness-matrix/request-requiredness-matrix-zhimacredit.md` |
| ZhimaCreditTCMiniOrderClose | 支付宝先享后付请求接口 - api-code mapping entity - 业务订单关闭 | `request-requiredness-matrix/request-requiredness-matrix-zhimacredit.md` |
| ZhimaCreditTCMiniOrderCreate | 支付宝先享后付请求接口 - api-code mapping entity - 业务订单创建 | `request-requiredness-matrix/request-requiredness-matrix-zhimacredit.md` |
| ZhimaCreditTCMiniOrderCreditAgreeChanged | 支付宝先享后付请求接口 - api-code mapping entity - 服务开通/授权状态变更通知 | `request-requiredness-matrix/request-requiredness-matrix-zhimacredit.md` |
| ZhimaCreditTCMiniOrderCreditAgreeQuery | 支付宝先享后付请求接口 - api-code mapping entity - zhima.credit.payafteruse.creditagreement.query | `request-requiredness-matrix/request-requiredness-matrix-zhimacredit.md` |
| ZhimaCreditTCMiniOrderInstallmentCreate | 支付宝先享后付请求接口 - api-code mapping entity - 创建分期单 | `request-requiredness-matrix/request-requiredness-matrix-zhimacredit.md` |
| ZhimaCreditTCMiniOrderQuery | 支付宝先享后付请求接口 - api-code mapping entity - 业务订单查询 | `request-requiredness-matrix/request-requiredness-matrix-zhimacredit.md` |
