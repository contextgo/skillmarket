# Request Routing Map - UnConscsPay

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| UnConscsPayAgreeApplyRequest | 云闪付支付API-无感支付-签约 | `request-requiredness-matrix/request-requiredness-matrix-unconscspay.md` |
| UnConscsPayAgreePayRequest | 云闪付支付API-无感支付-支付 | `request-requiredness-matrix/request-requiredness-matrix-unconscspay.md` |
| UnConscsPayAgreeUnbindRequest | 云闪付支付API-无感支付-解约 | `request-requiredness-matrix/request-requiredness-matrix-unconscspay.md` |
| UnConscsPayAndSignRequest | 云闪付支付API-无感支付-支付并签约 | `request-requiredness-matrix/request-requiredness-matrix-unconscspay.md` |
| UnConscsPayTokenApplyRequest | 云闪付支付API-签约支付-签约 | `request-requiredness-matrix/request-requiredness-matrix-unconscspay.md` |
| UnConscsPayTokenPayRequest | 云闪付支付API-签约支付-支付 | `request-requiredness-matrix/request-requiredness-matrix-unconscspay.md` |
| UnConscsPayTokenSetNoverRequest | 云闪付支付API-签约支付-小额免检申请 | `request-requiredness-matrix/request-requiredness-matrix-unconscspay.md` |
| UnConscsPayTokenSmsRequest | 云闪付支付API-签约支付-交易短信验证码申请 | `request-requiredness-matrix/request-requiredness-matrix-unconscspay.md` |
| UnConscsPayTokenUnbindRequest | 云闪付支付API-签约支付-解约 | `request-requiredness-matrix/request-requiredness-matrix-unconscspay.md` |
