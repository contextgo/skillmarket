# Request Routing Map - PreScanPay

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| PreScanPayCancelRequest | 网上收银扫码预消费-扫码预消费交易回退 | `request-requiredness-matrix/request-requiredness-matrix-prescanpay.md` |
| PreScanPayFinishRequest | 网上收银扫码预消费-扫码预消费完成 | `request-requiredness-matrix/request-requiredness-matrix-prescanpay.md` |
| PreScanPayQueryRequest | 网上收银扫码预消费-扫码预消费查询 | `request-requiredness-matrix/request-requiredness-matrix-prescanpay.md` |
| PreScanPayRefundRequest | 网上收银扫码预消费-扫码预消费完成交易退款 | `request-requiredness-matrix/request-requiredness-matrix-prescanpay.md` |
| PreScanPayRequest | 网上收银扫码预消费-扫码预消费 | `request-requiredness-matrix/request-requiredness-matrix-prescanpay.md` |
