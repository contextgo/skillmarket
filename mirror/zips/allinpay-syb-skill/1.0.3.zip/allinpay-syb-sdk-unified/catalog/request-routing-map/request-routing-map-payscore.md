# Request Routing Map - PayScore

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| PayScorePayRequest | 微信支付分-服务单扣款 | `request-requiredness-matrix/request-requiredness-matrix-payscore.md` |
| PayScoreServiceOrderRequest | 微信支付分请求接口 (bizData json->utf8->base64 for api-code mapping entity) | `request-requiredness-matrix/request-requiredness-matrix-payscore.md` |
| PayScoreTCPermissionAdd | 微信支付分-服务单扣款 - 接口编号：permissionsadd | `request-requiredness-matrix/request-requiredness-matrix-payscore.md` |
| PayScoreTCPermissionDel | 微信支付分-服务单扣款 - 接口编号：permissionsdel | `request-requiredness-matrix/request-requiredness-matrix-payscore.md` |
| PayScoreTCPermissionGet | 微信支付分-服务单扣款 - 接口编号：permissionsget | `request-requiredness-matrix/request-requiredness-matrix-payscore.md` |
| PayScoreTCServiceOrderAdd | 微信支付分-服务单扣款 - 接口编号：serviceorderadd | `request-requiredness-matrix/request-requiredness-matrix-payscore.md` |
| PayScoreTCServiceOrderCancel | 微信支付分-服务单扣款 - 接口编号：serviceordercancel | `request-requiredness-matrix/request-requiredness-matrix-payscore.md` |
| PayScoreTCServiceOrderComplete | 微信支付分-服务单扣款 - 接口编号：serviceordercomplete | `request-requiredness-matrix/request-requiredness-matrix-payscore.md` |
| PayScoreTCServiceOrderGet | 微信支付分-服务单扣款 - 接口编号：serviceorderget | `request-requiredness-matrix/request-requiredness-matrix-payscore.md` |
