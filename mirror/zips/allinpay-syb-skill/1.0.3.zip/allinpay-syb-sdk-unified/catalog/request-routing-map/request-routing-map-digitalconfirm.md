# Request Routing Map - DigitalConfirm

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| DigitalConfirmAuthCusStateRequest | 应用授权审核状态变更接口 | `request-requiredness-matrix/request-requiredness-matrix-digitalconfirm.md` |
