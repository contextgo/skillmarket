# Request Routing Map - UnitOrder

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| UnitOrderAuthCode2UserIdRequset | 支付宝吱口令生成请求参数 - 根据授权码(付款码)获取用户ID请求参数 | `request-requiredness-matrix/request-requiredness-matrix-unitorder.md` |
| UnitOrderCloseNativeRequset | 支付宝吱口令生成请求参数 - 统一主扫关闭接口 | `request-requiredness-matrix/request-requiredness-matrix-unitorder.md` |
| UnitOrderCreateZhiRequest | 支付宝吱口令生成请求参数 | `request-requiredness-matrix/request-requiredness-matrix-unitorder.md` |
| UnitOrderNativePayRequest | 统一主扫请求参数 | `request-requiredness-matrix/request-requiredness-matrix-unitorder.md` |
| UnitOrderPayRequest | 统一支付请求参数 | `request-requiredness-matrix/request-requiredness-matrix-unitorder.md` |
| UnitOrderScanQrPayRequest | 统一被扫请求参数 | `request-requiredness-matrix/request-requiredness-matrix-unitorder.md` |
| UnitOrderWxFacePayInfoRequset | 支付宝吱口令生成请求参数 - 微信人脸授权码获取请求参数 | `request-requiredness-matrix/request-requiredness-matrix-unitorder.md` |
