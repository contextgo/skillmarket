# Request Routing Map - FileUpload

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| FileUploadRequest | 文件上传接口 | `request-requiredness-matrix/request-requiredness-matrix-fileupload.md` |
