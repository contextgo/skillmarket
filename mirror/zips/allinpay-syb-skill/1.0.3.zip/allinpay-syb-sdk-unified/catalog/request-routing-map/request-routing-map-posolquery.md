# Request Routing Map - PosolQuery

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| PosolQueryRequest | 交易查询 | `request-requiredness-matrix/request-requiredness-matrix-posolquery.md` |
