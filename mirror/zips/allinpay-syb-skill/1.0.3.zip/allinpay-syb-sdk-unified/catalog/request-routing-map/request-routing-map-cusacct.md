# Request Routing Map - CusAcct

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| CusAcctQueryAcctOverLimitRequest | 商户授信资金查询接口 | `request-requiredness-matrix/request-requiredness-matrix-cusacct.md` |
| CusAcctQueryBalanceRequest | 商户账户余额查询 | `request-requiredness-matrix/request-requiredness-matrix-cusacct.md` |
| CusAcctQueryHisBalanceRequest | 商户账户历史余额查询 | `request-requiredness-matrix/request-requiredness-matrix-cusacct.md` |
| CusAcctQueryTrxRequest | 商户余额转账交易查询 | `request-requiredness-matrix/request-requiredness-matrix-cusacct.md` |
| CusAcctTransferBalRequest | 商户账户余额转账 | `request-requiredness-matrix/request-requiredness-matrix-cusacct.md` |
| CusAcctWithDrawQueryRequest | 商户账户余额结算查询 | `request-requiredness-matrix/request-requiredness-matrix-cusacct.md` |
| CusAcctWithDrawRequest | 商户账户余额结算 | `request-requiredness-matrix/request-requiredness-matrix-cusacct.md` |
