# Request Routing Map - RiskFeeBack

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| RiskFeeBackAliComplaintFileUploadRequest | 支付宝投诉处理图片上传 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackAliComplaintProcessFinishRequest | 支付宝投诉处理消费者投诉 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackAliComplaintQueryRequest | 支付宝查询消费者投诉详情 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackAliComplaintQueryV2Request | 支付宝投诉查询消费者投诉列表 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxAppletBussiAppealRequest | 微信小程序收银台商家申诉 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxAppletBussiRespondComplaintRequest | 微信小程序收银台投诉商家回应投诉 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxAppletBussiSupplyProofRequest | 微信小程序收银台商家补充凭证 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxAppletBussiSupplyRefundRequest | 微信小程序收银台商家提交退款凭证 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxAppletComplaintOrderDetailRequest | 微信小程序收银台投诉查询投诉单详情 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxAppletComplaintQueryRequest | 微信小程序收银台投诉查询消费者投诉列表 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxAppletUploadRequest | 微信小程序收银台上传附件 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxComplaintCompleteRequest | 微信投诉反馈处理完成API | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxComplaintDetailRequest | 微信投诉查询投诉单详情API | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxComplaintHistoryRequest | 微信投诉查询投诉协商历史 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxComplaintListQueryRequest | 微信投诉查询投诉单列表API | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxComplaintRespRequest | 微信投诉回复用户API | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxComplaintSreFundProgressRequest | 微信投诉更新退款审批结果API | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxGetMerchantImageRequest | 微信投诉下载微信图片 | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
| RiskFeeBackWxMerchantImageUploadRequest | 微信投诉商户上传反馈图片API | `request-requiredness-matrix/request-requiredness-matrix-riskfeeback.md` |
