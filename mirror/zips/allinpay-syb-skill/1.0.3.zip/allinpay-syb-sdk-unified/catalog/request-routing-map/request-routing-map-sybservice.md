# Request Routing Map - SybService

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| SybServiceAlinFcConfigRequest | 支付宝NFC设备配置接口 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceAlinFcQueryRequest | 支付宝NFC设备绑定查询接口 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceAsAgreeConfigQryRequest | 分账协议授权查询 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceAsAgreeConfigRequest | 分账协议授权配置 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceIotDevConfigRequest | IOT设备绑定和解绑接口 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceIotDevQueryRequest | IOT设备查询接口 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceQueryCouponDetailRequest | 查询微信代金券详情 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceQueryStockDetailRequest | 查询微信代金券批次详情 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceQueryStockRefundFlowRequest | 下载微信代金券批次退款明细 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceQueryStockUseFlowRequest | 下载微信代金券批次核销明细 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceSearchCusPackageRequest | 商户套餐查询接口 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceSendCouponsRequest | 微信发放代金券 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceUploadElectTicketRequest | 上传微信电子小票 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
| SybServiceWxCateringOrderSyncStatusRequest | 微信点餐同步 | `request-requiredness-matrix/request-requiredness-matrix-sybservice.md` |
