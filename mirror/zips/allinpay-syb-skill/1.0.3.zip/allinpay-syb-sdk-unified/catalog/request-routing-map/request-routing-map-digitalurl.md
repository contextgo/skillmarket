# Request Routing Map - DigitalUrl

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| DigitalUrlRequest | 获取应用访问链接 | `request-requiredness-matrix/request-requiredness-matrix-digitalurl.md` |
