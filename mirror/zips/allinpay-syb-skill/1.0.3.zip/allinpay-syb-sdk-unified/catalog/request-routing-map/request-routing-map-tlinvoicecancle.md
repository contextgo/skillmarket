# Request Routing Map - TlinvoiceCancle

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| TlinvoiceCancleInvoiceRequest | 发票冲红 | `request-requiredness-matrix/request-requiredness-matrix-tlinvoicecancle.md` |
