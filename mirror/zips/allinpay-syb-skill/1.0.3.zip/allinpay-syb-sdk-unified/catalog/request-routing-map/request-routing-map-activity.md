# Request Routing Map - Activity

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| ActivityActivityPageRequest | 活动报名h5接口 | `request-requiredness-matrix/request-requiredness-matrix-activity.md` |
| ActivityCusActivityRequest | 商户活动报名API接口 | `request-requiredness-matrix/request-requiredness-matrix-activity.md` |
| ActivityQueryActivityRequest | 活动状态查询 | `request-requiredness-matrix/request-requiredness-matrix-activity.md` |
