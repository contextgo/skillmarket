# Request Routing Map - Un

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| UnYwPayRequest | 云闪付支付API-云微支付 | `request-requiredness-matrix/request-requiredness-matrix-un.md` |
