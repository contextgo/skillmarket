# Request Routing Map - UnionPay

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| UnionPayYJHXAuditQryUn | 银联以旧换新一键接入 - 接口编号：actionType=AUDITQRY  , trxChnl= ONLINE (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXAuditUn | 银联以旧换新一键接入 - 接口编号：actionType=AUDIT, trxChnl= ONLINE (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXAuditUpdateUn | 银联以旧换新一键接入 - 接口编号：actionType=AUDITUPDATE, trxChnl= ONLINE (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXClearanceUn | 银联以旧换新一键接入 - 接口编号：actionType= CLEARANCE, trxChnl= ONLINE (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXCmnRequest | 银联以旧换新一键接入 (actionType+trxChnl+bizContent triad required) (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXCoupCancel | 银联以旧换新发券相关API - 接口编号：actionType= COUPCANCEL, trxChnl= ONLINE (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXCoupCheck | 银联以旧换新发券相关API - 接口编号：actionType= COUPCHECK, trxChnl= ONLINE (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXCoupReceive | 银联以旧换新发券相关API - 接口编号：actionType= COUPRECEIVE, trxChnl= ONLINE (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXCoupRequest | 银联以旧换新发券相关API (actionType+trxChnl+bizContent triad required) (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXSnOccupancyUn | 银联以旧换新一键接入 - 接口编号：actionType= SNOCCUPANCY, trxChnl= OFFLINE/ONLINE (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXSnQueryUn | 银联以旧换新一键接入 - 接口编号：actionType= SNQUERY, trxChnl= OFFLINE/ONLINE (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXTransSyncUn | 银联以旧换新一键接入 - 接口编号：actionType= TRANSSYNC, trxChnl= ONLINE (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXVoAuditEncryptData | 银联以旧换新一键接入业务参数-审核数据加密信息域 (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXVoBiz | 银联以旧换新一键接入 - 银联以旧换新业务参数父类 (special inheritance base; sdk subclasses only) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXVoInvoiceInfo | 银联以旧换新一键接入业务参数-发票信息域 (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXVoTrackInfo | 银联以旧换新一键接入业务参数-物流信息域 (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
| UnionPayYJHXVoUserEncryptData | 银联以旧换新一键接入业务参数-用户敏感信息 (extends UnionPayYJHXVoBiz) | `request-requiredness-matrix/request-requiredness-matrix-unionpay.md` |
