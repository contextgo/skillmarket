# Request Routing Map - QPay

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| QPayAgreeApplyRequest | 快捷支付API-签约申请 | `request-requiredness-matrix/request-requiredness-matrix-qpay.md` |
| QPayAgreeConfirmRequest | 快捷支付API-签约确认 | `request-requiredness-matrix/request-requiredness-matrix-qpay.md` |
| QPayApplyRequest | 快捷支付API-支付申请 | `request-requiredness-matrix/request-requiredness-matrix-qpay.md` |
| QPayConfirmRequest | 快捷支付API-支付确认 | `request-requiredness-matrix/request-requiredness-matrix-qpay.md` |
| QPayolAgreeApplyRequest | 快捷支付API-一键绑卡申请 | `request-requiredness-matrix/request-requiredness-matrix-qpay.md` |
| QPayolBindCardApplyRequest | 快捷支付API-一绑卡签约H5 | `request-requiredness-matrix/request-requiredness-matrix-qpay.md` |
| QPaySmsAgreeRequest | 快捷支付API-重新获取支付短信 | `request-requiredness-matrix/request-requiredness-matrix-qpay.md` |
| QPayUnbindRequest | 快捷支付API-银行卡解绑 | `request-requiredness-matrix/request-requiredness-matrix-qpay.md` |
