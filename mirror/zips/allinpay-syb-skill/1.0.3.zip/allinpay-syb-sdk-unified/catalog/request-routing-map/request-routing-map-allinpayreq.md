# Request Routing Map - AllinpayReq

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| AllinpayReq | 基础请求接口 | `request-requiredness-matrix/request-requiredness-matrix-allinpayreq.md` |
| AllinpayReqInf | 基础请求接口 | `request-requiredness-matrix/request-requiredness-matrix-allinpayreq.md` |
