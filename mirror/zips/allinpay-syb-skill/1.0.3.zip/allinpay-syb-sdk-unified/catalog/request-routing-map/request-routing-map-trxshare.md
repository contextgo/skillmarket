# Request Routing Map - TrxShare

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| TrxShareQueryRequest | 分账交易查询 | `request-requiredness-matrix/request-requiredness-matrix-trxshare.md` |
| TrxShareRevokeQueryRequest | 分账回退交易查询 | `request-requiredness-matrix/request-requiredness-matrix-trxshare.md` |
| TrxShareRevokeRequest | 交易分账回退 | `request-requiredness-matrix/request-requiredness-matrix-trxshare.md` |
| TrxShareShareRequest | 交易分账 | `request-requiredness-matrix/request-requiredness-matrix-trxshare.md` |
