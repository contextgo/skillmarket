# Request Routing Map - B2bOrder

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| B2bOrderDirectPayRequest | B2B订单API-付款 | `request-requiredness-matrix/request-requiredness-matrix-b2border.md` |
| B2bOrderPayRequest | B2B订单API-收款 | `request-requiredness-matrix/request-requiredness-matrix-b2border.md` |
