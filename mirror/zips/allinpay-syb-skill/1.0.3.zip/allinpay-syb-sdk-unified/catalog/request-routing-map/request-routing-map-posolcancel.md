# Request Routing Map - PosolCancel

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| PosolCancelRequest | 交易撤销 | `request-requiredness-matrix/request-requiredness-matrix-posolcancel.md` |
