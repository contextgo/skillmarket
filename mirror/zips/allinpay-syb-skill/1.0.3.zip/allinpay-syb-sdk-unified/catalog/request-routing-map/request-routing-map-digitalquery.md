# Request Routing Map - DigitalQuery

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| DigitalQueryAuthCusStateRequest | 查询商户授权关系接口 | `request-requiredness-matrix/request-requiredness-matrix-digitalquery.md` |
