# Request Routing Map - PosolAuth

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| PosolAuthFinRequest | 预授权完成 | `request-requiredness-matrix/request-requiredness-matrix-posolauth.md` |
