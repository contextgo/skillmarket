# Request Routing Map - WxOpen

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| WxOpenGetOpenIdRequest | H5获取微信OPENID | `request-requiredness-matrix/request-requiredness-matrix-wxopen.md` |
