# Request Routing Map - UserTrans

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| UserTransCusPayRequest | 自带参数的当面付订单接口 | `request-requiredness-matrix/request-requiredness-matrix-usertrans.md` |
