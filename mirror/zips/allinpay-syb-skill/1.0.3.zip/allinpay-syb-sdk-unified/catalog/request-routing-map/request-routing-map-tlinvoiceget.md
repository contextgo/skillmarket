# Request Routing Map - TlinvoiceGet

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| TlinvoiceGetInvoiceDownloadUrlRequest | 发票下载 | `request-requiredness-matrix/request-requiredness-matrix-tlinvoiceget.md` |
| TlinvoiceGetInvoiceOpenStatusRequest | 获取电票开通状态 | `request-requiredness-matrix/request-requiredness-matrix-tlinvoiceget.md` |
| TlinvoiceGetInvoiceProdCodeListRequest | 获取电票商户开票品类 | `request-requiredness-matrix/request-requiredness-matrix-tlinvoiceget.md` |
| TlinvoiceGetRecordStatusRequest | 发票状态查询 | `request-requiredness-matrix/request-requiredness-matrix-tlinvoiceget.md` |
