# Request Routing Map - MerChant

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| MerChantAcctEditRequest | 商户结算信息管理接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantAddRequest | 商户进件请求参数 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantAddTermRequest | 终端信息采集接口请求参数 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantAgentExpiredRequest | 商户证件到期结果文件查询 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantBindCodeRequest | 商户二维码绑定申请接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantConfirmBindRequest | 商户二维码绑定确认接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantConfirmUnBindRequest | 商户二维码解绑确认接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantEditRequest | 商户基本信息管理接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantElectSignRequest | 电子协议重发接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantProdFeeShareQryRequest | 商户手续费部分补贴配置查询 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantProductRequest | 商户产品信息管理接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantQrCodeQryRequest | 商户二维码绑定关系查询 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantQryTermRequest | 终端信息查询接口请求参数 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantQueryChnlCmIdRequest | 渠道子商户查询 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantQueryCusRgcRequest | 合规性状态查询接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantQueryElectSignRequest | 电子协议签约状态查询 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantQueryElectUrlRequest | 电子协议URL查询 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantQueryRequest | 进件成功商户信息查询 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantQueryStatusRequest | 商户审核状态查询 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantQueryWxSubDevRequest | 子商户微信配置信息查询 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantQueryWxVerifyStateRequest | 微信/支付宝认证状态查询 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantRepairComplianceRequest | 合规性补录API接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantRepairCusrgcRequest | 合规性审核补录统一h5接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantSecondPageRequest | 秒到开通H5接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantSubBranchRequest | 商户门店信息管理接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantTermRequest | 商户终端信息管理接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantUnBindCodeRequest | 商户二维码解绑接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantWxSubDevConfigRequest | 微信子商户参数配置 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
| MerChantWxVerifyRequest | AT商户认证统一H5接口 | `request-requiredness-matrix/request-requiredness-matrix-merchant.md` |
