# Request Routing Map - TlinvoiceGenerate

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| TlinvoiceGenerateInviteQRRequest | 邀请二维码生成接口 | `request-requiredness-matrix/request-requiredness-matrix-tlinvoicegenerate.md` |
| TlinvoiceGenerateInvoiceQRRequest | 电票二维码生成接口 | `request-requiredness-matrix/request-requiredness-matrix-tlinvoicegenerate.md` |
| TlinvoiceGenerateInvoiceQRSimpleRequest | 电票二维码生成接口（简易） | `request-requiredness-matrix/request-requiredness-matrix-tlinvoicegenerate.md` |
