# Request Routing Map - Tranx

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| TranxCancelRequest | 统一撤销请求参数 | `request-requiredness-matrix/request-requiredness-matrix-tranx.md` |
| TranxCloseRequset | 统一关单请求参数 | `request-requiredness-matrix/request-requiredness-matrix-tranx.md` |
| TranxQueryConfirmRequest | 交易结果确认查询接口 | `request-requiredness-matrix/request-requiredness-matrix-tranx.md` |
| TranxQueryOrderRequest | 订单交易结果查询 | `request-requiredness-matrix/request-requiredness-matrix-tranx.md` |
| TranxQueryRequest | 统一查询请求参数 | `request-requiredness-matrix/request-requiredness-matrix-tranx.md` |
| TranxRefundRequest | 统一撤销请求参数 | `request-requiredness-matrix/request-requiredness-matrix-tranx.md` |
