# Request Routing Map - TrxFile

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| TrxFileGetRequest | 获取对账单接口 | `request-requiredness-matrix/request-requiredness-matrix-trxfile.md` |
| TrxFileSettTrxRequest | 获取结算单接口 | `request-requiredness-matrix/request-requiredness-matrix-trxfile.md` |
