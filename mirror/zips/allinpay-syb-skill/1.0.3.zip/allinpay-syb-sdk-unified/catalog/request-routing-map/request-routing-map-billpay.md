# Request Routing Map - BillPay

| Request class | Keyword hint (javadoc) | Requiredness shard |
|---|---|---|
| BillPayAddRequest | 账单同步 | `request-requiredness-matrix/request-requiredness-matrix-billpay.md` |
| BillPayDelRequest | 账单删除 | `request-requiredness-matrix/request-requiredness-matrix-billpay.md` |
| BillPayQueryRequest | 账单查询 | `request-requiredness-matrix/request-requiredness-matrix-billpay.md` |
| BillPayRefundRequest | 账单退款 | `request-requiredness-matrix/request-requiredness-matrix-billpay.md` |
| BillPaySetOfflinePayRequest | 账单设置已线下收款 | `request-requiredness-matrix/request-requiredness-matrix-billpay.md` |
