# 工程落地协议（Java + Maven，通用版）

本文件用于“你控制不了 Agent 载体”的场景：Skill 只输出规范与工单，任何具备文件写入/命令执行能力的 Agent 都能按此落地。

## 1) 你只需要提供的信息（最少）

- 目标目录：`projectDir`（可选；不提供则默认当前工作区根目录）
- 你要的业务：例如“聚分期支付 demo”“退款 demo”“异步通知验签 demo”

## 2) 必须产出的两段内容（Skill 输出要求）

## 2.1 先判断：用户要不要“落地到工程”

常见两类意图：

- **仅查看代码**（不落地）：例如“给个示例/我先看看代码怎么写/不要改工程/不用引依赖”
- **需要落地**：例如“生成到某目录/帮我补 pom 引 SDK/创建新工程并能编译运行”

若用户是“仅查看代码”，则输出同样的两段内容，但：

- 步骤清单只写一句：**“本次仅展示代码，不对工程做任何修改。”**
- JSON 工单的 `intent` 使用 `show_code_only`，并令 `changes=[]`、`validation=[]`

### 高准确率判定规则（推荐直接照抄到对话/FAQ）

目标：**宁可不落地，也不要误判去改工程**。

#### 强制“仅查看代码”（高置信）

用户出现任一表述，即判为仅查看代码：

- `不落地/不要落地/不用落地`
- `不改工程/不要改工程/不修改工程`
- `不写文件/不要写文件/别写文件`
- `不用引依赖/不要引依赖`
- `不用创建工程/不要创建工程`
- `只看代码/看看代码/只要代码/示例代码/参考代码`

#### 强制“需要落地到工程”（高置信）

用户出现任一表述，即判为需要落地：

- `生成到工程/写到工程/落到工程/放到项目里/放到工程里`
- `生成到目录/写到目录/落地到目录`
- `帮我加依赖/补依赖/改pom/改pom.xml/pom.xml/maven`
- `新建工程/创建工程/能编译/可编译/能运行/可运行/跑起来`

#### 冲突消歧（最常见误判点）

- 同时出现“只看代码”和“要落地”时：**优先仅查看代码**（防误改）。  
- 仅提供路径/目录 **不等于** 要落地；必须出现“生成到/写到/落地到”才算要落地。  

### 典型话术示例（保证命中）

**仅查看代码（不会改工程）**

- “我只想看看代码示例，不要改工程。给我聚分期支付 Java demo（Maven 依赖也写出来）。”
- “先给示例代码，别写文件、不用创建工程、不用引依赖。”

**需要落地到工程（会改工程/写文件）**

- “把聚分期支付 demo 落地到 `D:\\work\\syb-demo`，没有 Maven 工程就创建，并补齐 pom 依赖。”
- “在我这个 Maven 项目里生成 demo 类并能 `mvn package` 通过。”

### A) 工程落地步骤（人类可读）

1. 目标目录：`<projectDir>`  
2. 检查 `<projectDir>/pom.xml` 是否存在  
3. 不存在：创建最小 Maven 工程（`pom.xml` + `src/main/java`）  
4. 存在：检查并确保依赖 `com.allinpay.cus.sdk:allinpay-syb-sdk-java:<version>`  
5. 生成 Demo 类到 `src/main/java/<packagePath>/<MainClass>.java`  
6. 按“分级校验”执行：  
   - `L1` 静态校验（不执行 Maven）  
   - `L2` 仅当 `mvn -v` 成功时进入 Maven  
   - `L3` 默认 `mvn -q -DskipTests compile`，仅在用户明确要求时再 `package`

### B) scaffold 工单（JSON）

```json
{
  "intent": "scaffold_java_maven_demo",
  "constraints": { "language": "java", "buildTool": "maven" },
  "inputs": {
    "projectDir": "<projectDir>",
    "sdkGav": "com.allinpay.cus.sdk:allinpay-syb-sdk-java:1.1.11",
    "package": "com.allinpay.syb.demo",
    "mainClass": "SybDemoApp"
  },
  "changes": [
    { "type": "ensure_maven_project", "path": "<projectDir>" },
    { "type": "ensure_dependency", "path": "<projectDir>/pom.xml", "gav": "com.allinpay.cus.sdk:allinpay-syb-sdk-java:1.1.11" },
    { "type": "ensure_file", "path": "<projectDir>/src/main/java/com/allinpay/syb/demo/SybDemoApp.java" }
  ],
  "validation": [
    { "type": "precheck", "name": "maven_available", "run": "mvn -v" },
    { "type": "command", "cwd": "<projectDir>", "run": "mvn -q -DskipTests compile", "when": "maven_available=true" },
    { "type": "command", "cwd": "<projectDir>", "run": "mvn -q -DskipTests package", "when": "user_requires_package=true" }
  ]
}
```

## 3) 约束（必须遵守）

- 仅 Java + Maven；只修改/创建 `pom.xml`，不生成 Gradle/Kotlin。
- 依赖默认版本与仓库 `allinpay-syb-sdk-java/pom.xml` 的 `<version>` 对齐（当前示例 `1.1.11`），用户指定则覆盖。
- 生成 demo 必须包含：SDK 原生初始化、请求/响应日志、异常处理、生产注意事项（幂等/重试/验签/脱敏）。

## 4) 落地实现风格（防过度包装）

### 4.1 默认策略：最小实现，优先 SDK 直连

- 目标是“先能对齐 SDK 能力、可联调、可编译”，不是先做平台化封装。
- 默认仅落地必要文件：配置类、1 个业务服务类（可选 1 个控制器）、必要请求/响应 VO（如确有必要）。
- 未经用户明确要求，不新增“通用网关层/抽象工厂/统一适配器”等二次封装。

### 4.2 禁止清单（未被需求明确授权时）

- 本文“骨架”默认仅指 `reference/UniversalSybDemo.java` 与 `reference/SpecialSceneSybDemo.java`；用户未显式指定其他骨架时，不得改用自定义模板替代。  
- 禁止新增与需求无关的抽象层：`*Facade`、`*Adapter`、`*Gateway`、`*Template` 等。
- 禁止把 SDK 已有能力再包装成“自定义协议对象”并改变调用语义。
- 禁止臆造 SDK 类型或方法（例如虚构 `MerchantConfig.Builder` 之类不存在类型）。
- `MerchantConfig.builder()` 允许且推荐用于初始化；禁止的是请求模型（`request` 包）臆造 `*.builder()/build()`。
- 禁止写 `MerchantConfig.builder()...build()`（`MerchantConfig` 无 `build()` 方法）。
- 禁止把 `execObj(...)` 返回值统一接到 `AllinpayResp` 基类后再到处转型；应直接用请求对应类型接收（后端 `*Response` 子类 / 前端白名单 `AllinpayFrontResp`）。
- 禁止对 `AllinpayApi.client()` 臆造调用签名：仅允许 `execObj(HttpConfig.build(), request)`、`execObj(preProcess, HttpConfig.build(), request)`、`upload(HttpConfig.build(), request)`、`downloadToByte(HttpConfig.build(), url)`、`downloadToFile(HttpConfig.build(), url, savePath)`、`noticeHandle(noticeStr)`。
- 禁止为 `AllinpayApi.client()` 调用硬塞“看起来合理”的额外参数（默认 URL、虚构 reqsn、mock path 等）；必需实参来源仅限“骨架已有变量 / 用户明确输入 / `YOUR_XXX` 占位”。
- 若用户提供骨架且骨架内已写 `AllinpayApi.client()`，禁止改方法名、参数个数、参数顺序、参数变量名（除可编辑区内补值外）。
- 禁止对白名单外请求类使用 `AllinpayFrontResp`。仅以下请求类允许：`UserTransCusPayRequest`、`QPayolAgreeApplyRequest`、`QPayolBindCardApplyRequest`、`GateWayPCRequest`、`GateWayH5Request`、`H5UnionPayOrderRequest`、`MerChantRepairCusrgcRequest`、`MerChantSecondPageRequest`、`ActivityActivityPageRequest`、`MerChantWxVerifyRequest`、`WxOpenGetOpenIdRequest`、`H5BillPayBillPayRequest`。
- 禁止使用语义猜测替代白名单判断（例如“主扫一般有二维码跳转”）；`UnitOrderNativePayRequest` 必须使用 `UnitOrderNativePayResponse`。

### 4.3 允许清单（鼓励保留）

- 允许最小必要封装：配置读取、参数校验、日志打印、异常统一处理。
- 允许与业务直接相关的轻量 VO/DTO（仅承载入参或出参，不改 SDK 语义）。
- 允许在控制层/服务层做最小职责分离，但不引入额外框架复杂度。

### 4.4 交付验收清单（落地前自检）

1. 每个业务调用都能映射到一个明确 SDK request 类与对应接收类型（后端 `*Response` / 前端白名单 `AllinpayFrontResp`）。  
2. 没有出现 SDK 中不存在的类/方法命名。  
3. `AllinpayApi.initialize(...)`、`execObj(...)`、`upload/download/noticeHandle` 等调用形态与 SDK 一致，且未出现 `MerchantConfig.builder()...build()`。  
4. 分级校验闭环完整：`L1` 静态校验完成，`L2` Maven 可用性预检已记录，`L3` Maven 命令执行与跳过原因已记录。  
5. 若未被用户要求，工程中不应出现新增的“通用封装层”文件。
6. 若命中“接口编号映射实体承载请求”（同一 Request 同时含 `tranCode` + `bizData`）：`bizData` 必须由 `JsonUtils.toJson(bizObj)` 生成 JSON（`import com.allinpay.syb.sdk.core.utils.JsonUtils;`），再做 `JSON -> UTF-8 -> Base64`，不得直接传原始 JSON 文本。
7. 同上场景：`tranCode` 必须与目标实体一一对应，不得使用占位值或与实体不匹配的接口编号。
8. 交付时必须给出本次命中的映射对（`实体类 -> tranCode`），并与代码中的 `setTranCode(...)` 保持一致。
9. 若使用银联以旧换新参数：`UnionPayYJHXVoBiz` 仅允许 SDK 既有子类，禁止新增自定义 `UnionPayYJHXVoBiz` 子类或替换为自定义 VO。
10. 若使用 `UnionPayYJHXCmnRequest` 或 `UnionPayYJHXCoupRequest`：必须同时校验并给出 `actionType + trxChnl + bizContent 子类` 三元组映射证据；禁止只设前两者、禁止 `bizContent` 置父类空对象、禁止三元组错配。
11. 对 `request` 包内非 `AllinpayReq` 实体类也必须做类型一致性校验：嵌套字段类型必须与 SDK 原类完全一致（例如 `UnionPayYJHXVoAuditEncryptData.invoiceInfo/trackInfo`、多类 `encryptData`），禁止替换为自定义 VO/Map/Object。
12. 所有 `AllinpayApi.client()` 调用都必须给出“签名命中证据 + 实参来源证据”（骨架/用户输入/占位）；若来源不明，保留占位并标注“待业务侧提供”，禁止猜值落地。
13. 若使用 `AllinpayFrontResp`，必须给出“请求类命中白名单”的证据；未命中白名单即判不通过。

## 5) Maven 校验防灾难策略（避免长时间重跑）

- 若 `mvn -v` 失败：立即停止 Maven 步骤，不做重复重试；输出“缺少 Maven 或环境异常”的明确提示与安装建议。  
- 若 `compile` 失败：最多再重试一次；若仍失败，输出“最小可定位错误清单”（缺依赖、包名冲突、测试类放错目录等），不再无限循环。  
- 默认不跑 `package`，除非用户明确要求“可打包/可发布”。  
- 任何跳过都必须有理由（例如 `maven_missing`、`user_not_require_package`），写入 scaffold validation 结果。

