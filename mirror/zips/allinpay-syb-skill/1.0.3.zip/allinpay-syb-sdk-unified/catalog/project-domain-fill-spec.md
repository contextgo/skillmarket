# Project Domain Fill Spec

用于“先分域、再路由、再填参”的轻量导航文件。  
执行链路固定为：`本文件(分域)` -> `request-routing-map(选请求类)` -> `request-requiredness-matrix(字段必填)` -> `field-enum-glossary(枚举)`。

> 本文件不是字段真源，不维护完整字段清单；仅维护“如何快速命中正确分片”的稳定规则。

## 1) 请求前缀域映射（与当前路由体系对齐）

| 业务域 | 常见请求前缀/类 | 说明 |
|---|---|---|
| 统一收单与交易后处理 | `UnitOrder*`, `Tranx*`, `Un*`, `UserTrans*`, `WxOpen*` | 覆盖下单、查询、退款、撤销、部分前端跳转 |
| 分期 | `Fqf*` | 含聚分期链路 |
| 快捷与网关 | `QPay*`, `GateWay*`, `H5*`, `B2bOrder*` | 覆盖快捷签约支付、PC/H5/B2B 网关 |
| 云闪付与银联扩展 | `UnConscsPay*`, `UnionPay*` | 云闪付与银联业务参数承载接口 |
| 预消费与终端联机 | `PreScanPay*`, `PosolAuth*`, `PosolCancel*`, `PosolQuery*` | 预消费、联机授权/撤销/查询 |
| 商户/账户/账单/服务 | `MerChant*`, `CusAcct*`, `BillPay*`, `SybService*` | 商户管理、账户能力、应用服务商账单、服务接口 |
| 风控/电子发票/对账文件 | `RiskFeeBack*`, `Tlinvoice*`, `TrxFile*`, `TrxShare*` | 风控反馈、发票、对账下载、分账 |
| 数字化与活动扩展 | `Digital*`, `Activity*`, `ZhimaCredit*`, `PayScore*` | 数字营销、活动、芝麻信用、支付分 |
| 文件与特殊调用 | `FileUpload*` + `noticeHandle/download/upload` | 上传、异步通知验签、文件下载不走常规 `execObj` |

补充规则：

1. 以上分域只用于“缩小搜索范围”，最终请求类与 `Requiredness shard` 必须以 `catalog/request-routing-map.md` 及其分片为准。  
2. 若一个场景命中多个域，优先按“请求类前缀精确匹配 > 业务语义匹配”处理。  
3. 若无法分域，直接从 `request-routing-map.md` 全量前缀索引反查，不得臆造请求类。

## 2) 通用填参规则（稳定口径）

1. `cusid/appid` 必传；`orgid` 按代理模式传。  
2. `reqsn` 保证全局唯一；金额统一“分”。  
3. `randomstr/signtype/sign` 按签名规范。  
4. `notify_url` 公网可达且不带参数。  
5. 参数默认明文传入；若字段存在 SDK 注解 `@EncryptField`，由 SDK 自动加密，禁止手工二次加密。  
6. 结果判定：响应 JSON 的 `retcode` + `trxstatus`（Java 对应 **`getRetCode()`** + **`getTrxStatus()`**，基类另有 **`getRetMsg()`** / **`getTrxId()`**；禁止把 JSON 小写字段名机械拼为错误 getter）。  
7. **Request setter 入参类型（闭集）**：以 `reference/sdk-request-java-field-types.md` 白名单为准；未列字段默认按 `java.lang.String` 调用 `setXxx`，不得凭语义改为数值/布尔类型。

## 3) 单一真源与废弃入口

1. 路由真源：`catalog/request-routing-map.md` + `catalog/request-routing-map/request-routing-map-*.md`。  
2. 字段必填真源：`catalog/request-requiredness-matrix/request-requiredness-matrix-*.md`。  
3. 枚举真源：`catalog/field-enum-glossary.md`。  
4. 响应字段真源：`catalog/response-field-matrix.md`。  
5. 废弃入口：`request-api-index*` 与 `request-requiredness-matrix.md` 总索引。

## 4) 典型域级补充（仅保留高频稳定规则）

### 4.1 统一收单/交易后处理（`UnitOrder*`/`Tranx*`）

- 常用核心：`trxamt`, `paytype`, `reqsn/unireqsn`, `notify_url`。  
- 查询：`reqsn` 与 `trxid` 二选一，优先 `trxid`。  
- 退款/撤销：`oldreqsn` 与 `oldtrxid` 二选一，优先 `oldtrxid`。

### 4.2 分期（`Fqf*`）

- 聚分期下单：`FqfJfqPayRequest`。  
- 高频字段：`reqsn`, `trxamt`, `idno`, `truename`, `mobile`, `notify_url`。

### 4.3 快捷（`QPay*`）

- 链路：签约申请 -> 签约确认 -> 支付申请 -> 支付确认。  
- `thpInfo` 必须跨步骤原样透传，`agreeId` 必须持久化。

### 4.4 特殊调用（上传/下载/通知/前端）

- 文件上传：`FileUploadRequest` + `upload(...)`。  
- 对账下载：`TrxFileGetRequest` 先取 URL，再 `downloadToByte(...)`/`downloadToFile(...)`。  
- 通知处理：`noticeHandle(noticeStr)`。  
- 前端跳转：仅前端白名单请求可使用 `AllinpayFrontResp`（详见业务 Skill 主文档）。

## 5) Agent 执行顺序（当前）

1. 先用本文件做“前缀域定位”（仅用于缩小范围）。  
2. 读 `request-routing-map` 命中目标请求类与 `Requiredness shard`。  
3. 仅读命中的 `request-requiredness-matrix-*` 分片，按 `R/C/O/U + 条件` 填参。  
4. 枚举仅从 `field-enum-glossary.md` 取值；响应 getter 仅从 `response-field-matrix.md` 取值。  
5. 遇到上传/下载/通知/前端跳转等特殊调用，按 `SpecialSceneSybDemo` 形态输出。

## 6) 维护约束（防滞后）

1. 当 `request-routing-map.md` 新增前缀分片时，本文件第 1 节必须同步更新。  
2. 本文件禁止新增“字段级必填表”与“枚举明细表”，避免与真源重复维护。  
3. 若本文件与任一真源冲突，以真源为准，并在本文件修订记录中注明修正原因。

