# Request Routing Map

Routes business intent to full SDK request classes.
Read order: this index -> one prefix shard -> requiredness shard.

## Prefix shards

- Activity* -> request-routing-map/request-routing-map-activity.md
- AllinpayReq* -> request-routing-map/request-routing-map-allinpayreq.md
- B2bOrder* -> request-routing-map/request-routing-map-b2border.md
- BillPay* -> request-routing-map/request-routing-map-billpay.md
- CusAcct* -> request-routing-map/request-routing-map-cusacct.md
- DigitalConfirm* -> request-routing-map/request-routing-map-digitalconfirm.md
- DigitalQuery* -> request-routing-map/request-routing-map-digitalquery.md
- DigitalSend* -> request-routing-map/request-routing-map-digitalsend.md
- DigitalUrl* -> request-routing-map/request-routing-map-digitalurl.md
- DigitalWx* -> request-routing-map/request-routing-map-digitalwx.md
- FileUpload* -> request-routing-map/request-routing-map-fileupload.md
- Fqf* -> request-routing-map/request-routing-map-fqf.md
- GateWay* -> request-routing-map/request-routing-map-gateway.md
- H5* -> request-routing-map/request-routing-map-h5.md
- MerChant* -> request-routing-map/request-routing-map-merchant.md
- PayScore* -> request-routing-map/request-routing-map-payscore.md
- PosolAuth* -> request-routing-map/request-routing-map-posolauth.md
- PosolCancel* -> request-routing-map/request-routing-map-posolcancel.md
- PosolQuery* -> request-routing-map/request-routing-map-posolquery.md
- PreScanPay* -> request-routing-map/request-routing-map-prescanpay.md
- QPay* -> request-routing-map/request-routing-map-qpay.md
- RiskFeeBack* -> request-routing-map/request-routing-map-riskfeeback.md
- SybService* -> request-routing-map/request-routing-map-sybservice.md
- TlinvoiceCancle* -> request-routing-map/request-routing-map-tlinvoicecancle.md
- TlinvoiceGenerate* -> request-routing-map/request-routing-map-tlinvoicegenerate.md
- TlinvoiceGet* -> request-routing-map/request-routing-map-tlinvoiceget.md
- Tranx* -> request-routing-map/request-routing-map-tranx.md
- TrxFile* -> request-routing-map/request-routing-map-trxfile.md
- TrxShare* -> request-routing-map/request-routing-map-trxshare.md
- Un* -> request-routing-map/request-routing-map-un.md
- UnConscsPay* -> request-routing-map/request-routing-map-unconscspay.md
- UnionPay* -> request-routing-map/request-routing-map-unionpay.md
- UnitOrder* -> request-routing-map/request-routing-map-unitorder.md
- UserTrans* -> request-routing-map/request-routing-map-usertrans.md
- WxOpen* -> request-routing-map/request-routing-map-wxopen.md
- ZhimaCredit* -> request-routing-map/request-routing-map-zhimacredit.md

## Special calls without request class

| Scenario | Call shape | Notes |
|---|---|---|
| Async notification parse/verify | AllinpayApi.client().noticeHandle(noticeStr) | Not an xecObj flow. |
| File download | AllinpayApi.client().downloadToByte(...) / downloadToFile(...) | Usually fetch url first via TrxFileGetRequest. |
