# 字段必填矩阵 - GateWay

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - GateWayH5Request

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 付款金额；单位分 | high |
| reqSn | reqsn | R | 商户唯一订单号 | high |
| charset | charset | R | 字符编码；支持UTF-8/GBK | high |
| retUrl | returl | R | 同步通知地址；必须https且不能带参数 | high |
| retType | rettype | O | 同步返回请求方式；枚举见 field-enum-glossary.rettype；默认01 | high |
| notifyUrl | notifyurl | O | 异步通知地址；若https需443默认端口 | high |
| body | body | R | 订单标题（收银台展示） | high |
| remark | remark | O | 订单备注信息 | high |
| validTime | validtime | O | 有效时间（分钟）；不填默认60；最大60 | high |
| limitPay | limit_pay | O | 支付限制；常见 no_credit | high |
| asInfo | asinfo | O | 分账信息；需开通分账配置 | medium |
| subBranch | subbranch | O | 通联系统门店号 | medium |
| gateId | gateid | O | 支付银行；不填则收银台展示银行列表 | high |
| idType | idtype | O | 证件类型；取值见 field-enum-glossary.idtype | high |
| idNo | idno | O | 证件号 | high |
| trueName | truename | O | 姓名 | high |

## 字段必填矩阵 - GateWayPCRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| charset | charset | R | 字符编码；支持UTF-8/GBK/GB2312 | high |
| retUrl | returl | O | 同步通知地址；returl和notifyurl不能同时为空 | high |
| notifyUrl | notifyurl | O | 异步通知地址；returl和notifyurl不能同时为空 | high |
| goodsId | goodsid | O | 商品号；不允许特殊字符（| % # ^） | high |
| goodsInf | goodsinf | O | 商品描述；不允许特殊字符（| % # ^） | high |
| trxAmt | trxamt | R | 付款金额；单位分 | high |
| orderId | orderid | R | 商户唯一订单号 | high |
| gateId | gateid | O | 支付银行；不填则网关展示银行列表 | high |
| payType | paytype | R | 交易类型；B2C/B2B（默认B2C） | high |
| validTime | validtime | O | B2C场景分钟制（默认60，最大60）；B2B固定20天 | high |
| limitPay | limitpay | O | 仅B2C场景有效（如no_credit/to_credit） | high |


