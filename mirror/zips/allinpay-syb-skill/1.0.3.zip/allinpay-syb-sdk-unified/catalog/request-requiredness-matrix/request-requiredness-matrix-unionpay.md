# 字段必填矩阵 - UnionPay

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

说明：UnionPay 系列 request 字段较多且业务结构特殊，当前不强制约束字段是否必填，统一以 `U` 标记为待核实。

## 字段必填矩阵 - UnionPayYJHXAuditQryUn

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| orgNo | orgNo | U | 银联分公司机构代码 | medium |
| mchntOrderId | mchntOrderId | U | 商户订单号 | medium |
| uploadTime | uploadTime | U | 审核记录上传时间 | medium |

## 字段必填矩阵 - UnionPayYJHXAuditUn

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| orgNo | orgNo | U | 银联分公司机构代码 | medium |
| subMchntCd | subMchntCd | U | 店铺编码 | medium |
| subMchntNm | subMchntNm | U | 店铺名称 | medium |
| storeNm | storeNm | U | 门店名称 | medium |
| onlineNo | onlineNo | U | 线上平台订单号 | medium |
| mchntOrderId | mchntOrderId | U | 商户订单号 | medium |
| uploadTime | uploadTime | U | 审核记录上传时间 yyyyMMddHHmmss | medium |
| prodId | prodId | U | 品类 | medium |
| engGrade | engGrade | U | 能效 | medium |
| brandNm | brandNm | U | 品牌 | medium |
| prodModel | prodModel | U | 型号 | medium |
| salesChnl | salesChnl | U | 销售方式 | medium |
| platForm | platForm | U | 电商平台方 | medium |
| payerTp | payerTp | U | 支付方式类型 | medium |
| tradeInOrderId | tradeInOrderId | U | 收旧订单号 | medium |
| tradeInAt | tradeInAt | U | 收旧价格 | medium |
| isTradeIn | isTradeIn | U | 收旧价格 是否统计 | medium |
| salesAt | salesAt | U | 订单金额 分为单位 | medium |
| actualAt | actualAt | U | 实付金额 分为单位 | medium |
| transTm | transTm | U | 交易时间 yyyyMMddHHmmss | medium |
| mchntCd | mchntCd | U | 商户编码 | medium |
| merSubAt | merSubAt | U | 商家优惠金额 | medium |
| discountAt | discountAt | U | 国补优惠金额 | medium |
| image01 | image01 | U | 其他图片1 | medium |
| image02 | image02 | U | 其他图片2 | medium |
| image03 | image03 | U | 其他图片3 | medium |
| image04 | image04 | U | 其他图片4 | medium |
| image05 | image05 | U | 其他图片5 | medium |
| image06 | image06 | U | 其他图片6 | medium |
| image07 | image07 | U | 其他图片7 | medium |
| image08 | image08 | U | 其他图片8 | medium |
| image09 | image09 | U | 其他图片9 | medium |
| image10 | image10 | U | 其他图片10 | medium |
| commitmentLetterPhoto | - | U | 文档尚未完全核实 | low |
| commitmentLetterPhotoFormat | commitmentLetterPhotoFormat | U | 收旧承诺函照片格式 | medium |
| devicePhoto | - | U | 文档尚未完全核实 | low |
| devicePhotoFormat | devicePhotoFormat | U | 收旧设备外观照片格式 | medium |
| packAndActivePhoto | packAndActivePhoto | U | 包含完整外包装及sn码的激活照片 | medium |
| barCode | barCode | U | 商品条码 | medium |
| snCode | snCode | U | SN码 | medium |
| imei1 | imei1 | U | IMEI1 | medium |
| imei2 | imei2 | U | IMEI2 | medium |
| registerModel | registerModel | U | 能效或水效网备案登记型号 | medium |
| recordNumber | recordNumber | U | 能效或水效备案号 | medium |
| engGradeStandard | engGradeStandard | U | 能效或水效执行的国家标准名称 | medium |
| encryptData | encryptData | U | 加密信息域；必须传 `UnionPayYJHXVoAuditEncryptData` 明文对象，禁止手工加密后上送 | high |
| resv1 | resv1 | U | 保留域1 | medium |
| resv2 | resv2 | U | 保留域2 | medium |
| resv3 | resv3 | U | 保留域3 | medium |
| resv4 | resv4 | U | 保留域4 | medium |
| resv5 | resv5 | U | 保留域5 | medium |

## 字段必填矩阵 - UnionPayYJHXAuditUpdateUn

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| orgNo | orgNo | U | 银联分公司机构代码 | medium |
| subMchntCd | subMchntCd | U | 店铺编码 | medium |
| subMchntNm | subMchntNm | U | 店铺名称 | medium |
| storeNm | storeNm | U | 门店名称 | medium |
| onlineNo | onlineNo | U | 线上平台订单号 | medium |
| mchntOrderId | mchntOrderId | U | 商户订单号 | medium |
| uploadTime | uploadTime | U | 审核记录上传时间 yyyyMMddHHmmss | medium |
| prodId | prodId | U | 品类 | medium |
| engGrade | engGrade | U | 能效 | medium |
| brandNm | brandNm | U | 品牌 | medium |
| prodModel | prodModel | U | 型号 | medium |
| salesChnl | salesChnl | U | 销售方式 | medium |
| platForm | platForm | U | 电商平台方 | medium |
| payerTp | payerTp | U | 支付方式类型 | medium |
| tradeInOrderId | tradeInOrderId | U | 收旧订单号 | medium |
| tradeInAt | tradeInAt | U | 收旧价格 | medium |
| isTradeIn | isTradeIn | U | 收旧价格 是否统计 | medium |
| salesAt | salesAt | U | 订单金额 分为单位 | medium |
| actualAt | actualAt | U | 实付金额 分为单位 | medium |
| transTm | transTm | U | 交易时间 yyyyMMddHHmmss | medium |
| mchntCd | mchntCd | U | 商户编码 | medium |
| merSubAt | merSubAt | U | 商家优惠金额 | medium |
| discountAt | discountAt | U | 国补优惠金额 | medium |
| image01 | image01 | U | 其他图片1 | medium |
| image02 | image02 | U | 其他图片2 | medium |
| image03 | image03 | U | 其他图片3 | medium |
| image04 | image04 | U | 其他图片4 | medium |
| image05 | image05 | U | 其他图片5 | medium |
| image06 | image06 | U | 其他图片6 | medium |
| image07 | image07 | U | 其他图片7 | medium |
| image08 | image08 | U | 其他图片8 | medium |
| image09 | image09 | U | 其他图片9 | medium |
| image10 | image10 | U | 其他图片10 | medium |
| commitmentLetterPhoto | - | U | 文档尚未完全核实 | low |
| commitmentLetterPhotoFormat | commitmentLetterPhotoFormat | U | 收旧承诺函照片格式 | medium |
| devicePhoto | - | U | 文档尚未完全核实 | low |
| devicePhotoFormat | devicePhotoFormat | U | 收旧设备外观照片格式 | medium |
| packAndActivePhoto | packAndActivePhoto | U | 包含完整外包装及sn码的激活照片 | medium |
| barCode | barCode | U | 商品条码 | medium |
| snCode | snCode | U | SN码 | medium |
| imei1 | imei1 | U | IMEI1 | medium |
| imei2 | imei2 | U | IMEI2 | medium |
| registerModel | registerModel | U | 能效或水效网备案登记型号 | medium |
| recordNumber | recordNumber | U | 能效或水效备案号 | medium |
| engGradeStandard | engGradeStandard | U | 能效或水效执行的国家标准名称 | medium |
| encryptData | encryptData | U | 加密信息域；必须传 `UnionPayYJHXVoAuditEncryptData` 明文对象，禁止手工加密后上送 | high |
| resv1 | resv1 | U | 保留域1 | medium |
| resv2 | resv2 | U | 保留域2 | medium |
| resv3 | resv3 | U | 保留域3 | medium |
| resv4 | resv4 | U | 保留域4 | medium |
| resv5 | resv5 | U | 保留域5 | medium |

## 字段必填矩阵 - UnionPayYJHXClearanceUn

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss | medium |
| coupIssueId | coupIssueId | U | 发券方代码 | medium |
| regionCd | regionCd | U | 地区码 | medium |
| encryptData | encryptData | U | 用户敏感信息；必须传 `UnionPayYJHXVoUserEncryptData` 明文对象，禁止手工加密后上送 | high |
| cateCode | cateCode | U | 品类编码 | medium |
| txnAmt | txnAmt | U | 销售金额 | medium |
| discountAmt | discountAmt | U | 补贴金额 | medium |
| transTm | transTm | U | 交易完成时间 yyyyMMddHHmmssSSS | medium |
| couponCd | couponCd | U | 券码 | medium |
| actId | actId | U | 活动编号 | medium |
| operTp | operTp | U | 品类状态 | medium |
| mchntCd | mchntCd | U | 核销商编 | medium |
| mchntCnNm | mchntCnNm | U | 核销商户名称 | medium |
| mchntResv | mchntResv | U | 核销商户保留域 | medium |
| reqReserved | reqReserved | U | 请求方保留域 | medium |
| recvRegionCd | recvRegionCd | U | 收货地区编码 | medium |
| saleModels | saleModels | U | 销售方式 | medium |
| corpCnNm | corpCnNm | U | 销售企业名称 | medium |
| uniscId | uniscId | U | 统一社会信息代码 | medium |
| pickUp | pickUp | U | 是否自提 | medium |
| barCode | barCode | U | 商品条码 | medium |
| itemName | itemName | U | 商品名称 | medium |
| brandNm | brandNm | U | 家电品牌 | medium |
| specModel | specModel | U | 规格型号 | medium |
| engGrade | engGrade | U | 能耗等级 | medium |
| snCode | snCode | U | S/N码 | medium |
| imei1 | imei1 | U | IMEI1码 | medium |
| imei2 | imei2 | U | IMEI2码 | medium |
| logisticsNo | logisticsNo | U | 物流单号 | medium |
| deliveryTime | deliveryTime | U | 签收时间 | medium |
| invoiceNo | invoiceNo | U | 发票号 | medium |
| isAIProduct | isAIProduct | U | 是否属于AI产品 | medium |
| serialNum | serialNum | U | 数据流水号 | medium |
| pcType | pcType | U | 电脑类型 | medium |
| channel | channel | U | 线上销售渠道 | medium |
| mchntOrderId | mchntOrderId | U | 商户订单号 | medium |
| acqInsNm | acqInsNm | U | 收单机构名称 | medium |
| payOrderId | payOrderId | U | 支付交易编号 | medium |
| oldThings | oldThings | U | 交旧信息 | medium |

## 字段必填矩阵 - UnionPayYJHXCmnRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| actionType | actionType | U | 业务类型；取值见 field-enum-glossary.actiontype_unionpay_yjhx | high |
| trxChnl | trxChnl | U | 受理渠道；取值见 field-enum-glossary.trxchnl_unionpay_yjhx | high |
| bizContent | bizContent | U | 业务参数；实体三元组见 field-enum-glossary.bizcontent_entity_unionpay_yjhx；禁止 Map/父类空对象/自定义扩展类 | high |

## 字段必填矩阵 - UnionPayYJHXCoupCancel

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss | medium |
| coupIssueId | coupIssueId | U | 发券方代码 | medium |
| regionCd | regionCd | U | 地区码 | medium |
| encryptData | encryptData | U | 用户敏感信息；必须传 `UnionPayYJHXVoUserEncryptData` 明文对象，禁止手工加密后上送 | high |
| scene | scene | U | 场景 | medium |
| cateCode | cateCode | U | 品类编码 | medium |
| gps | gps | U | GPS信息 | medium |
| reqReserved | reqReserved | U | 请求方保留域 | medium |

## 字段必填矩阵 - UnionPayYJHXCoupCheck

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss | medium |
| coupIssueId | coupIssueId | U | 发券方代码 | medium |
| regionCd | regionCd | U | 地区码 | medium |
| encryptData | encryptData | U | 用户敏感信息；必须传 `UnionPayYJHXVoUserEncryptData` 明文对象，禁止手工加密后上送 | high |
| scene | scene | U | 场景 | medium |
| reqReserved | reqReserved | U | 请求方保留域 | medium |
| isRealName | isRealName | U | 是否已实名 | medium |
| isRealFace | isRealFace | U | 是否已人脸验证 | medium |
| isExpire | isExpire | U | 证件是否在有效期内 | medium |
| isCancel | isCancel | U | 证件是否已注销 | medium |

## 字段必填矩阵 - UnionPayYJHXCoupReceive

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss | medium |
| coupIssueId | coupIssueId | U | 发券方代码 | medium |
| regionCd | regionCd | U | 地区码 | medium |
| encryptData | encryptData | U | 用户敏感信息；必须传 `UnionPayYJHXVoUserEncryptData` 明文对象，禁止手工加密后上送 | high |
| scene | scene | U | 场景 | medium |
| cateCode | cateCode | U | 品类编码 | medium |
| model | model | U | 领取模式 | medium |
| engGrade | engGrade | U | 能耗等级 | medium |
| isRealName | isRealName | U | 是否已实名 | medium |
| isRealFace | isRealFace | U | 是否已人脸验证 | medium |
| isExpire | isExpire | U | 证件是否在有效期内 | medium |
| isCancel | isCancel | U | 证件是否已注销 | medium |
| gps | gps | U | GPS信息 | medium |
| reqReserved | reqReserved | U | 请求方保留域 | medium |

## 字段必填矩阵 - UnionPayYJHXCoupRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| actionType | actionType | U | 业务类型；取值见 field-enum-glossary.actiontype_unionpay_yjhx | high |
| trxChnl | trxChnl | U | 受理渠道；取值见 field-enum-glossary.trxchnl_unionpay_yjhx | high |
| bizContent | bizContent | U | 业务参数；实体三元组见 field-enum-glossary.bizcontent_entity_unionpay_yjhx；禁止 Map/父类空对象/自定义扩展类 | high |

## 字段必填矩阵 - UnionPayYJHXSnOccupancyUn

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss | medium |
| orderId | orderId | U | 交易流水号 | medium |
| regionCd | regionCd | U | 地区码 | medium |
| mchntCd | mchntCd | U | 银联商户号 | medium |
| postTmn | postTmn | U | 终端号 | medium |
| barcode | barcode | U | 商品条码 | medium |
| snCode | snCode | U | SN码 | medium |
| reqReserved | reqReserved | U | 备注 | medium |
| imei1 | imei1 | U | IMEI1码 | medium |
| imei2 | imei2 | U | IMEI2码 | medium |
| mfrInfo | mfrInfo | U | 厂商信息 | medium |
| brand | brand | U | 具体品牌 | medium |
| cateCode | cateCode | U | 品类编码 | medium |
| isAiProd | isAiProd | U | 是否为AI产品 | medium |
| specModel | specModel | U | 规格型号 | medium |
| saleTm | saleTm | U | 销售时间 yyyy-MM-dd | medium |

## 字段必填矩阵 - UnionPayYJHXSnQueryUn

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| regionCd | regionCd | U | 地区码 | medium |
| snCode | snCode | U | SN码 | medium |
| reqReserved | reqReserved | U | 备注 | medium |

## 字段必填矩阵 - UnionPayYJHXTransSyncUn

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| txnTime | txnTime | U | 交易发送时间；格式为yyyyMMddHHmmss | medium |
| coupIssueId | coupIssueId | U | 发券方代码 | medium |
| regionCd | regionCd | U | 地区码 | medium |
| encryptData | encryptData | U | 用户敏感信息；必须传 `UnionPayYJHXVoUserEncryptData` 明文对象，禁止手工加密后上送 | high |
| cateCode | cateCode | U | 品类编码 | medium |
| txnAmt | txnAmt | U | 销售金额 | medium |
| discountAmt | discountAmt | U | 补贴金额 | medium |
| transTm | transTm | U | 交易完成时间 yyyyMMddHHmmssSSS | medium |
| couponCd | couponCd | U | 券码 | medium |
| actId | actId | U | 活动编号 | medium |
| operTp | operTp | U | 品类状态 | medium |
| mchntCd | mchntCd | U | 核销商编 | medium |
| mchntCnNm | mchntCnNm | U | 核销商户名称 | medium |
| mchntResv | mchntResv | U | 核销商户保留域 | medium |
| reqReserved | reqReserved | U | 请求方保留域 | medium |
| recvRegionCd | recvRegionCd | U | 收货地区编码 | medium |
| saleModels | saleModels | U | 销售方式 | medium |
| corpCnNm | corpCnNm | U | 销售企业名称 | medium |
| uniscId | uniscId | U | 统一社会信息代码 | medium |
| brandNm | brandNm | U | 家电品牌 | medium |
| engGrade | engGrade | U | 能耗等级 | medium |
| serialNum | serialNum | U | 数据流水号 | medium |

## 字段必填矩阵 - UnionPayYJHXVoAuditEncryptData

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| invoiceInfo | invoiceInfo | U | 发票信息域 | medium |
| trackInfo | trackInfo | U | 物流信息域 | medium |

## 字段必填矩阵 - UnionPayYJHXVoBiz

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| serialVersionUID | - | U | 文档尚未完全核实 | low |

## 字段必填矩阵 - UnionPayYJHXVoInvoiceInfo

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| id | id | U | 发票id | medium |
| invoiceTp | invoiceTp | U | 发票类型 | medium |
| invoiceCd | invoiceCd | U | 发票代码 | medium |
| invoiceNo | invoiceNo | U | 发票号码 | medium |
| invoiceDt | invoiceDt | U | 开票日期 | medium |
| invoiceLink | invoiceLink | U | 发票链接 | medium |
| invoiceCkCd | invoiceCkCd | U | 发票校验码 | medium |
| nm | nm | U | 发票上购买人姓名 | medium |
| tax | tax | U | 税价合计 | medium |
| invoiceTaxAmt | invoiceTaxAmt | U | 发票税额 | medium |
| salesEntNm | salesEntNm | U | 销售企业名称 | medium |
| taxPayer | taxPayer | U | 销售方纳税人识别号 | medium |
| num | num | U | 数量 | medium |
| serviceNm | serviceNm | U | 货物或应税劳务服务名称（含型号） | medium |

## 字段必填矩阵 - UnionPayYJHXVoTrackInfo

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| trackingNo | trackingNo | U | 物流单号 | medium |
| trackingCompany | trackingCompany | U | 物流公司 | medium |
| usrProv | usrProv | U | 收货省 | medium |
| usrCity | usrCity | U | 收货市 | medium |
| usrArea | usrArea | U | 收货区县 | medium |
| usrAddr | usrAddr | U | 收货地址 | medium |
| trackingType | trackingType | U | 物流类型 | medium |
| deliveryMethod | deliveryMethod | U | 提货方式 | medium |
| shippingAddr | shippingAddr | U | 发货地址 | medium |
| deliveryTime | deliveryTime | U | 签收时间 yyyyMMddHHmmss | medium |

## 字段必填矩阵 - UnionPayYJHXVoUserEncryptData

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| certifTp | certifTp | U | 证件类型 | medium |
| certifId | certifId | U | 证件号码 | medium |
| customerNm | customerNm | U | 姓名 | medium |
| usrId | usrId | U | 用户号码 | medium |
| phoneNo | phoneNo | U | 手机号 | medium |
| addr | addr | U | 收货地址 | medium |


