# 字段必填矩阵 - WxOpen

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - WxOpenGetOpenIdRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| appType | apptype | R | 公众号类型；取值见 field-enum-glossary.apptype_wxopen_getopenid | high |
| redirectUrl | redirecturl | R | 重定向 url（需做 urlEncode） | high |
| state | state | R | 开发者自定义参数；重定向后会带上 `state` 回传；可填写 `a-zA-Z0-9`；最大 128 字节 | high |


