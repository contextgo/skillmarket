# 字段必填矩阵 - DigitalQuery

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - DigitalQueryAuthCusStateRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| digTalId | digtalid | R | 应用ID | high |
| innerAppid | innerappid | O | 通联分配的内部应用ID；innerappid模式下与商户号匹配使用 | high |
| authCusId | authcusid | R | 授权商户号 | high |


