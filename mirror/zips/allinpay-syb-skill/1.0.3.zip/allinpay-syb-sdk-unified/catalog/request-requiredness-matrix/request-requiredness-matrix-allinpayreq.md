# 字段必填矩阵 - AllinpayReq

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - AllinpayReq

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| orgId | orgid | O | 仅集团/代理模式使用 | high |
| cusId | cusid | R | 商户号 | high |
| appId | appid | R | 应用ID | high |
| version | version | O | 取决于接口版本规则 | medium |
| randomStr | randomstr | R | 随机串 | medium |

## 字段必填矩阵 - AllinpayReqInf

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
