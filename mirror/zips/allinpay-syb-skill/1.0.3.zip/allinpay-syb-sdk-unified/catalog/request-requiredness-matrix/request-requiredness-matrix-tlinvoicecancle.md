﻿# 字段必填矩阵 - TlinvoiceCancle

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TlinvoiceCancleInvoiceRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|----|---|---|
| applyId | applyid | R  | 发票申请单号 | high |


