# 字段必填矩阵 - FileUpload

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - FileUploadRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| fileType | filetype | R | 文件类型；枚举见 field-enum-glossary.filetype（png/jpg/zip） | high |
| filecontent | - | R | 文件二进制字节流 | high |


