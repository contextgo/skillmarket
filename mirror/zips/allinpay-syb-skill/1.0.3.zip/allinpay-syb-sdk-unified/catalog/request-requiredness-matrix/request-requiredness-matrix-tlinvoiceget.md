﻿# 字段必填矩阵 - TlinvoiceGet

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TlinvoiceGetInvoiceDownloadUrlRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| applyId | applyid | U | 文档尚未完全核实 | low |

## 字段必填矩阵 - TlinvoiceGetInvoiceOpenStatusRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|

## 字段必填矩阵 - TlinvoiceGetInvoiceProdCodeListRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|

## 字段必填矩阵 - TlinvoiceGetRecordStatusRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|----|---|---|
| applyId | applyid | R  | 发票申请单号 | high |


