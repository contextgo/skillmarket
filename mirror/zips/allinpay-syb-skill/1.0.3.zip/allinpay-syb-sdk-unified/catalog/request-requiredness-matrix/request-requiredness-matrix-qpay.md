# 字段必填矩阵 - QPay

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - QPayAgreeApplyRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqIp | reqip | O | 请求ip | high |
| reqTime | reqtime | R | 本次请求时间；格式yyyyMMddHHmmss | high |
| merUserId | meruserid | R | 商户用户号（商户自定义） | high |
| acctType | accttype | R | 卡类型；取值见 field-enum-glossary.accttype_qpay | high |
| acctNo | acctno | R | 银行卡号 | high |
| idType | idtype | R | 证件类型；取值见 field-enum-glossary.idtype（本场景常用0/2/5/6） | high |
| idNo | idno | R | 证件号；若包含字母X必须大写 | high |
| acctName | acctname | R | 户名 | high |
| mobile | mobile | R | 手机号码 | high |
| validDate | validdate | O | 有效期；格式MMyy | high |
| cvv2 | cvv2 | O | 卡校验码 | high |

## 字段必填矩阵 - QPayAgreeConfirmRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqIp | reqip | O | 请求ip | high |
| reqTime | reqtime | R | 本次请求时间；格式yyyyMMddHHmmss | high |
| merUserId | meruserid | R | 商户用户号（商户自定义） | high |
| acctType | accttype | R | 卡类型；取值见 field-enum-glossary.accttype_qpay | high |
| acctNo | acctno | R | 银行卡号 | high |
| idType | idtype | R | 证件类型；取值见 field-enum-glossary.idtype（本场景常用0/2/5/6） | high |
| idNo | idno | R | 证件号；若包含字母X必须大写 | high |
| acctName | acctname | R | 户名 | high |
| mobile | mobile | R | 手机号码 | high |
| validDate | validdate | O | 有效期；格式MMyy | high |
| cvv2 | cvv2 | O | 卡校验码 | high |
| smsCode | smscode | R | 短信验证码；签约确认短信验证码有效期5分钟 | high |
| thpInfo | thpinfo | C | 交易透传信息；签约申请返回不为空时，确认请求需原样透传 | high |
| userAgreeNo | useragreeno | O | 用户协议号；文档示例值241 | medium |

## 字段必填矩阵 - QPayApplyRequest

| 字段 | JSON 名 | 级别 | 条件                            | 置信度 |
|---|---|---|-------------------------------|---|
| reqSn | reqsn | R | 商户订单号                         | high |
| agreeId | agreeid | R | 协议编号（签约返回）                    | high |
| amount | amount | R | 订单金额；单位分                      | high |
| currency | currency | R | 币种；暂仅支持CNY                    | high |
| subject | subject | R | 订单内容（展示标题）                    | high |
| trxReserve | trxreserve | O | 交易备注；用于用户订单个性化信息，交易完成通知会带上本字段 | high |
| notifyUrl | notifyurl | R | 交易结果通知地址；必须为可直接访问且不带参数的url    | high |
| asInfo | asinfo | O | 分账信息,具体格式参考接口文档               | high |

## 字段必填矩阵 - QPayConfirmRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqIp | reqip | O | 请求ip | high |
| reqTime | reqtime | R | 本次请求时间；格式yyyyMMddHHmmss | high |
| reqSn | reqsn | R | 订单号（商户订单号） | high |
| agreeId | agreeid | R | 协议编号 | high |
| smsCode | smscode | R | 短信验证码 | high |
| thpInfo | thpinfo | R | 交易透传信息；支付申请成功或错误码为1999返回时，确认请求需原样带上 | high |

## 字段必填矩阵 - QPayolAgreeApplyRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqIp | reqip | O | 请求ip | high |
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss | high |
| applyId | applyid | R | 申请单号 | medium |
| bankCode | bankcode | R | 银行编码（见附录） | high |
| encryptType | encrypttype | R | 加密方式仅支持SM4 | high |
| acctType | accttype | R | 卡类型；取值见 field-enum-glossary.accttype_qpay | high |
| idType | idtype | R | 证件类型；取值见 field-enum-glossary.idtype；当前仅支持身份证（0） | high |
| idNo | idno | R | 证件号（敏感字段） | high |
| acctName | acctname | R | 户名（敏感字段） | high |
| mobile | mobile | C | 手机号（敏感字段）；招商银行场景必填 | high |
| acctNo | acctno | C | 卡号（敏感字段）；招商银行场景必填 | high |
| notifyUrl | notifyurl | R | 签约结果后端通知地址；必须为可直接访问且不带参数的url | high |
| retUrl | returl | R | 签约结果前端通知地址；必须为可直接访问且不带参数的url | high |

## 字段必填矩阵 - QPayolBindCardApplyRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| orgId | orgid | O | 机构号；共享机构号参数时必填 | high |
| reqIp | reqip | O | 请求ip | high |
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss | high |
| applyId | applyid | R | 申请单号 | medium |
| merUserId | meruserid | R | 用户编号（商户平台用户编号） | high |
| encryptType | encrypttype | R | 加密方式仅支持SM4 | high |
| notifyUrl | notifyurl | R | 签约结果后端通知地址；必须为可直接访问且不带参数的url | high |
| retUrl | returl | R | 签约结果前端通知地址；必须为可直接访问且不带参数的url | high |

## 字段必填矩阵 - QPaySmsAgreeRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqIp | reqip | O | 请求ip | high |
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss | high |
| orderId | orderid | R | 商户订单号 | high |
| agreeId | agreeid | C | 协议编号；协议支付场景必填 | high |
| thpInfo | thpinfo | C | 交易透传信息；提交支付时接口返回不为空时需原样带上 | high |

## 字段必填矩阵 - QPayUnbindRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqIp | reqip | U | 请求ip | high |
| reqTime | reqtime | U | 本次请求时间；格式yyyyMMddHHmmss | high |
| agreeId | agreeid | U | 协议编号 | high |


