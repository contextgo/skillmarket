# 字段必填矩阵 - UnitOrder

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - UnitOrderAuthCode2UserIdRequset

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| authCode | authcode | R | 授权码（付款码） | high |
| authType | authtype | R | 授权码类型；取值见 field-enum-glossary.authtype_unitorder_authcode2userid | high |
| identify | identify | O | 云闪付 UA 标识；`authType=02` 时建议上送 | high |
| subAppid | sub_appid | O | 微信支付 appid；仅对 `authType=01` 有效 | high |

## 字段必填矩阵 - UnitOrderCloseNativeRequset

适用场景：仅限统一主扫接口产生的“处理中”交易发起关闭，或使已生成的二维码即时失效。

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| oldReqSn | oldreqsn | C | 原商户订单号；置二维码失效时可填写；与 `oldTrxId` 二选一 | high |
| oldTrxId | oldtrxid | C | 原通联平台交易流水；与 `oldReqSn` 二选一；同时上送时优先使用 `oldTrxId` | high |

## 字段必填矩阵 - UnitOrderCreateZhiRequest

适用场景：生成支付宝口令。若交易源自“接口令导流”，下单接口（统一支付）的 `extendparams` 需增加 `direct_wx_source=indirect_wx_ALLINPAY`。

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqSn | reqsn | O | 商户交易单号；保证商户平台唯一 | high |
| bizLink | bizlink | R | 跳转业务链接（初始商户支付页面） | high |
| trxAmt | trxamt | R | 需要支付的金额；单位分 | high |
| validTime | validtime | O | 有效期；单位秒 | high |
| title | title | O | 标题 | high |
| zhiType | zhitype | O | 口令类型；取值见 field-enum-glossary.zhitype_unitorder_create_zhi；不填默认 `01` | high |

## 字段必填矩阵 - UnitOrderNativePayRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 | high |
| body | body | O | 订单标题；最大 100 个字节（约 50 个中文字符） | high |
| remark | remark | O | 备注信息；最大 160 个字节 | high |
| expireTime | expiretime | R | 订单超时时间；格式 `yyyyMMddHHmmss` | high |
| subBranch | subbranch | O | 门店号 | high |
| limitPay | limit_pay | O | 支付限制；当前仅支持 `no_credit`（暂对微信支付/支付宝有效） | high |
| idNo | idno | O | 证件号；实名交易必填，填写后校验证件号与姓名（暂仅支持支付宝） | high |
| trueName | truename | O | 付款人真实姓名；实名交易必填，填写后校验证件号与姓名（暂仅支持支付宝） | high |
| asInfo | asinfo | O | 分账信息；格式 `cusid:type:amount[,cusid:type:amount...]`；type：`01` 按金额、`02` 按比例（02 时 `0.5` 表示 50%） | high |
| goodsTag | goods_tag | O | 商品标志；用于区分是否可享受优惠（暂只对微信有效） | high |
| benefitDetail | benefitdetail | O | 优惠信息；String；填写格式详见附录（微信单品优惠/支付宝智慧门店） | high |
| chnlStoreId | chnlstoreid | O | 渠道门店编号 | high |
| fqNum | fqnum | O | 花呗分期；支持 `3/6/12` 期 | high |
| extendParams | extendparams | O | 扩展参数；String 类型 JSON 字符串 | high |
| notifyUrl | notify_url | O | 服务异步通知页面路径；可直接访问且不携带参数；若使用 https 需默认 443 端口 | high |
| frontUrl | front_url | O | 页面跳转同步通知页面路径；必须为 https 且不允许携带参数 | high |

## 字段必填矩阵 - UnitOrderPayRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqSn | reqsn | C | 商户交易单号；与 `uniReqSn` 二选一；当两者并存时以 `reqSn` 原有逻辑处理 | high |
| uniReqSn | unireqsn | C | 唯一订单号；与 `reqSn` 二选一；可跨微信/支付宝/云闪付复用，存在未支付订单时会关单处理 | high |
| payType | paytype | R | 交易方式；详见附录交易方式（含 W11） | high |
| body | body | O | 订单标题；最大 100 个字节（约 50 中文） | high |
| remark | remark | O | 备注信息；最大 300；禁止 `+`、空格、`/`、`?`、`%`、`#`、`&`、`=` 等特殊符号 | high |
| validTime | validtime | O | 订单有效时间；单位分钟；不填默认 5；最大 1440；`W01` 最大 120 | high |
| expireTime | expiretime | O | 截止支付时间；格式 `yyyyMMddHHmmss` | high |
| acct | acct | C | 支付平台用户标识；`JS/小程序` 等场景使用（微信 openid / 支付宝 user_id / 云闪付 userId） | high |
| notifyUrl | notify_url | O | 交易结果异步通知地址；需直接可访问且不携带参数；https 支持默认端口 | high |
| limitPay | limit_pay | O | 支付限制；值见 field-enum-glossary.limit_pay（微信/支付宝常用 `no_credit`） | high |
| subAppid | sub_appid | O | 微信子 appid；仅对微信支付有效 | high |
| goodsTag | goods_tag | O | 订单优惠标记；仅对微信有效，`W01` 不支持 | high |
| benefitDetail | benefitdetail | O | 优惠信息；JSON 字符串；微信单品优惠/支付宝单品优惠/智慧门店场景使用，`W01` 不支持 | high |
| chnlStoreId | chnlstoreid | O | 渠道门店编号；`W01` 不支持 | high |
| subBranch | subbranch | O | 门店号（通联系统门店号） | high |
| extendParams | extendparams | O | 拓展参数；JSON 字符串（String） | high |
| cusIp | cusip | C | 终端 IP；`payType=U02`（云闪付 JS 支付）不可为空 | high |
| frontUrl | front_url | C | 支付完成跳转地址；必须 https 且不能带参数；仅 `payType=U02` 或 `payType=W02` 场景支持 | high |
| idNo | idno | O | 证件号；实名交易必填；暂仅支持支付宝；微信仅刷卡支付例外 | high |
| trueName | truename | O | 付款人真实姓名；实名交易必填；暂仅支持支付宝；微信仅刷卡支付例外 | high |
| asInfo | asinfo | O | 分账信息；格式 `cusid:type:amount[,cusid:type:amount...]`；`W11` 不支持 | high |
| fqNum | fqnum | O | 分期；值见 field-enum-glossary.fqnum；支付宝花呗/信用卡分期（仅支持 A01/A02） | high |
| unPid | unpid | O | 银联 pid | high |
| finOrg | finorg | O | 金融机构号；`payType=N03` 必填（暂仅支持翼支付） | high |
| operatorId | operatorid | O | 收银员号 | high |
| iscofee | iscofee | O | 是否启用手续费补贴；`0` 否，`1` 商户累计补贴 | high |

## 字段必填矩阵 - UnitOrderScanQrPayRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；保证商户平台唯一 | high |
| body | body | O | 订单标题；最大 100 个字节（约 50 个中文字符） | high |
| remark | remark | O | 备注信息；最大 160；禁止 `+`、空格、`/`、`?`、`%`、`#`、`&`、`=` 等特殊符号 | high |
| authCode | authcode | R | 支付授权码；如微信/支付宝/银联付款二维码 | high |
| limitPay | limit_pay | O | 支付限制；当前仅支持 `no_credit`，暂只对微信支付/支付宝有效 | high |
| goodsTag | goods_tag | O | 订单优惠标记；仅对微信支付有效 | high |
| benefitDetail | benefitdetail | O | 优惠信息；JSON 字符串（String）；微信单品优惠/支付宝智慧门店/银联云闪付单品优惠 | high |
| subAppid | sub_appid | O | 微信子 appid；仅对微信支付有效 | high |
| chnlStoreId | chnlstoreid | O | 渠道门店编号；用于支付宝/微信渠道门店号上送 | high |
| subBranch | subbranch | O | 门店号 | high |
| idNo | idno | O | 证件号；实名交易必填；暂只支持支付宝 | high |
| extendParams | extendparams | O | 拓展参数；JSON 字符串（String） | high |
| trueName | truename | O | 付款人真实姓名；实名交易必填；暂只支持支付宝 | high |
| asInfo | asinfo | O | 分账信息；格式 `cusid:type:amount[,cusid:type:amount...]`；type：`01` 按金额、`02` 按比例（0.5 表示 50%） | high |
| fqNum | fqnum | O | 分期；值见 field-enum-glossary.fqnum；暂仅支持支付宝花呗分期/支付宝信用卡分期 | high |
| notifyUrl | notify_url | O | 交易结果通知地址；需直接可访问且不携带参数；若使用 https 需默认 443 端口 | high |
| unPid | unpid | O | 银联 pid；仅支持代理商/服务商角色调用 | high |
| termInfo | terminfo | R | 终端信息；JSON 字符串，详见终端字段说明 | high |
| operatorId | operatorid | O | 收银员号 | high |

## 字段必填矩阵 - UnitOrderWxFacePayInfoRequset

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| storeId | storeid | R | 门店编号；由商户定义，各门店唯一 | high |
| storeName | storename | R | 门店名称；由商户定义 | high |
| deviceId | deviceid | O | 终端设备编号；由商户定义 | high |
| attach | attach | O | 附加字段；字符串格式，使用 JSON | high |
| rawData | rawdata | R | 初始化数据；由微信人脸 SDK 返回；可通过微信官方刷脸支付接口 `getWxpayfaceRawdata` 获取 | high |
| subAppId | subappid | O | 微信支付 appid | high |


