# 字段必填矩阵 - Fqf

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - FqfApplyRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss | high |
| encryptType | encrypttype | R | 敏感信息加密方式；仅支持SM4 | high |
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 | high |
| acctNo | acctno | R | 分期账户号 | high |
| fqNum | fqnum | R | 分期期数,规则为3/6/9/12/18/24取值 | high |
| idNo | idno | R | 证件号；需SM4加密 | high |
| idType | idtype | R | 证件类型；取值见 field-enum-glossary.idtype | high |
| acctName | acctname | R | 户名；需SM4加密 | high |
| mobile | mobile | R | 手机号；需SM4加密 | high |
| currency | currency | R | 币种；当前仅支持CNY | high |
| subject | subject | R | 订单内容/订单标题 | high |
| validTime | validtime | O | 有效时间；以分钟为单位；默认5；最大1440 | high |
| trxReserve | trxreserve | O | 业务扩展字段 | medium |
| notifyUrl | notifyurl | O | 异步通知地址；需公网可达 | medium |

## 字段必填矩阵 - FqfBbSignPageRequest

| 字段 | JSON 名 | 级别 | 条件                       | 置信度 |
|---|---|---|--------------------------|---|
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss  | high |
| trxAmt | trxamt | R | 交易金额；单位分                 | high |
| acctNo | acctno | R | 银行卡号                    | high |
| feeNum | feenum | R | 分期期数,规则为3/6/9/12/18/24取值 | high |

## 字段必填矩阵 - FqfInfoRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss | high |
| acctNo | acctno | R | 银行卡号 | high |

## 字段必填矩阵 - FqfJDBTCountFeeRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 金额；单位分 | high |

## 字段必填矩阵 - FqfJDBTPayRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 | high |
| body | body | O | 订单标题；为空则以商户名作为商品名称 | high |
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| remark | remark | O | 备注信息 | medium |
| fqNum | fqnum | R | 分期期数；取值见 field-enum-glossary.fqnum_jdbt | high |
| validTime | validtime | O | 有效时间；以分钟为单位；不填默认5；最大60 | high |
| cusIp | cusip | R | 终端IP（用户下单和调起支付的终端IP地址） | high |
| notifyUrl | notify_url | O | 交易结果通知地址；需公网可达（刷卡支付场景该字段无效） | high |
| extendParams | extendparams | O | 扩展参数；Extendparams实体的json字符串 | medium |

## 字段必填矩阵 - FqfJfqPayRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqSn | reqsn | R | 分期核心字段 | high |
| encryptType | encrypttype | O | 按开通能力可选；若传入仅支持SM4 | high |
| trxAmt | trxamt | R | 分期核心字段; 格式提示： 金额单位为分 | high |
| unPid | unpid | O | 银联PID；仅支持代理商/服务商上送 | high |
| maskedAcctNo | maskedacctno | O | 卡号掩码；格式前6后4中间4个*；联合登录场景需同时上送手机号 | high |
| bankCode | bankcode | O | 指定银行分期支付时上送；指定单一银行时有效 | high |
| fqNum | fqnum | O | 商户指定分期期数，多个期数用&分隔，例如3&6&9 | high |
| senceFlag | senceflag | O | 场景标识；枚举见 field-enum-glossary.senceflag | high |
| idNo | idno | C | senceflag=01（保险实名认证）场景必填；需SM4加密 | high |
| trueName | truename | C | senceflag=01（保险实名认证）场景必填；需SM4加密 | high |
| mobile | mobile | C | 联合登录场景必填；手机号需SM4加密 | high |
| loginStatus | loginstatus | O | 登录状态；枚举见 field-enum-glossary.loginstatus；不上传默认为0 | high |
| retType | rettype | O | 同步返回请求方式；枚举见 field-enum-glossary.rettype；默认01 | high |
| validTime | validtime | O | 有效时间；以分钟为单位；不填默认5；最大1440 | high |
| frontUrl | front_url | O | 页面跳转同步通知地址 | high |
| notifyUrl | notify_url | R | 交易结果通知地址；通知url必须可直接访问且不能携带参数 | high |
| extendParams | extendparams | O | 拓展参数；json字符串（String） | high |

## 字段必填矩阵 - FqfPayConfirmRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqTime | reqtime | O | 本次请求时间；格式yyyyMMddHHmmss | high |
| encryptType | encrypttype | R | 敏感信息加密方式；仅支持SM4 | high |
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；与申请单保持一致 | high |
| acctNo | acctno | R | 分期账户号 | high |
| fqNum | fqnum | R | 分期期数,规则为3/6/9/12/18/24取值 | high |
| idNo | idno | R | 证件号；需SM4加密 | high |
| idType | idtype | R | 证件类型；取值见 field-enum-glossary.idtype | high |
| acctName | acctname | R | 户名；需SM4加密 | high |
| mobile | mobile | R | 手机号；需SM4加密 | high |
| currency | currency | R | 币种；当前仅支持CNY | high |
| subject | subject | R | 订单内容/订单标题 | high |
| validTime | validtime | O | 有效时间；以分钟为单位；不填默认5；最大1440 | high |
| trxReserve | trxreserve | O | 业务扩展字段 | medium |
| notifyUrl | notifyurl | R | 交易结果通知地址；通知url必须可直接访问且不能携带参数 | high |
| smsCode | smscode | R | 短信验证码 | high |
| thpInfo | thpinfo | C | 交易透传信息；支付申请返回错误码1999时，需原样回传 | high |


