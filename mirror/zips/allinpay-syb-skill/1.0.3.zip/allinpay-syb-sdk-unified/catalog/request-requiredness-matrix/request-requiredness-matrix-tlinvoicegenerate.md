# 字段必填矩阵 - TlinvoiceGenerate

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TlinvoiceGenerateInviteQRRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|

## 字段必填矩阵 - TlinvoiceGenerateInvoiceQRRequest

| 字段            | JSON 名 | 级别 | 条件 | 置信度 |
|---------------|---|---|---|---|
| amt           | amt | R | 金额；单位元 | high |
| prodCode      | prodcode | R | 商品编码；jsonarray 格式，最多支持 8 个商品信息 | high |
| cusOrderid    | cusorderid | O | 商户开票流水号 | medium |
| remark        | remark | O | 备注 | high |

## 字段必填矩阵 - TlinvoiceGenerateInvoiceQRSimpleRequest

| 字段         | JSON 名 | 级别 | 条件 | 置信度 |
|------------|---|---|---|---|
| amt        | amt | R | 金额；单位元 | high |
| prodCode   | prodcode | R | 商品编码；jsonarray 格式，最多支持 8 个商品信息 | high |
| cusOrderid | cusorderid | O | 商户开票流水号 | medium |
| cusOrderid | cusorderid | O | 商户开票流水号 | medium |
| termNo     | termno | O | 终端号 | medium |


