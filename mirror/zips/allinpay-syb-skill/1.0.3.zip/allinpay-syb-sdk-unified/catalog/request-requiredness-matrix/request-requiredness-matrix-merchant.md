# 字段必填矩阵 - MerChant

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - MerChantAcctEditRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| notifyUrl | notifyurl | R | 回调url；回调结果格式请参照进件通知 | high |
| clearMode | clearmode | R | 结算方式；取值见 field-enum-glossary.clearmode | high |
| acctId | acctid | R | 账户号 | high |
| acctName | acctname | R | 账户名 | high |
| acctType | accttype | R | 账户类型；取值见 field-enum-glossary.accttype_merchant | high |
| acctTp | accttp | R | 卡折类型；取值见 field-enum-glossary.accttp | high |
| bankCode | bankcode | R | 所属银行（见附录） | high |
| cnapsno | cnapsno | R | 支付行号（见附录） | high |
| pubAcctInfo | pubacctinfo | C | 商户性质为法人及其他组织且结算账户为对私时必填；格式为“对公账户号#对公账户开户省#对公账户开户市#所属行#支付行号” | high |
| picUrlJson | picurljson | C | 修改acctid/acctname/clearmode时上送图片替换；图片json字符串 | high |

## 字段必填矩阵 - MerChantAddRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| merChantId | merchantid | R | 代理商平台商户号（系统内唯一） | high |
| merChantName | merchantname | R | 商户名称 | high |
| shortName | shortname | R | 商户简称 | high |
| cusEngName | cusengname | C | 开通外卡产品时必填 | high |
| cusEngShortName | cusengshortname | C | 开通外卡产品时必填 | high |
| servicePhone | servicephone | R | 客服电话 | high |
| mccId | mccid | R | 所属行业（见附录） | high |
| comProperty | comproperty | R | 商户性质；枚举见 field-enum-glossary.comproperty | high |
| corpBusName | corpbusname | C | 商户性质非个人时必填 | high |
| creditCode | creditcode | C | 商户性质非个人时必填 | high |
| creditCodeExpire | creditcodeexpire | C | 商户性质非个人时必填；yyyy-mm-dd或长期 | high |
| legal | legal | R | 法人姓名 | high |
| legalIdType | legalidtype | R | 法人证件类型；枚举见 field-enum-glossary.legalidtype | high |
| legalIdNo | legalidno | R | 法人证件号 | high |
| legalIdExpire | legalidexpire | R | 法人证件有效期；yyyy-mm-dd或长期 | high |
| address | address | R | 注册地址（需包含省市） | high |
| contactPerson | contactperson | R | 财务联系人（收短信用） | high |
| contactPhone | contactphone | R | 财务联系人电话 | high |
| clearMode | clearmode | R | 结算方式；枚举见 field-enum-glossary.clearmode | high |
| acctId | acctid | R | 账户号 | high |
| acctName | acctname | R | 账户名 | high |
| acctType | accttype | R | 账户类型；枚举见 field-enum-glossary.accttype_merchant | high |
| acctTp | accttp | R | 卡折类型；枚举见 field-enum-glossary.accttp | high |
| bankCode | bankcode | R | 所属银行（见附录） | high |
| cnapsno | cnapsno | R | 支付行号（见附录） | high |
| notifyUrl | notifyurl | R | 进件成功回调通知url | high |
| corpBusPic | corpbuspic | C | 商户性质非个人时必填 | high |
| legalIdPicFront | legalidpicfront | R | 法人身份证人像面照片url | high |
| legalIdPicBack | legalidpicback | R | 法人身份证国徽面照片url | high |
| legalPic | legalpic | C | 商户性质为个人时必填 | high |
| storePic | storepic | R | 商户门头照片url | high |
| storeInnerPic | storeinnerpic | R | 经营内景照片url | high |
| bizPlacePic | bizplacepic | C | 商户性质为个人时必填 | high |
| otherFile | otherfile | O | 其他审核材料；必须zip文件且最大5M | high |
| expandUser | expanduser | R | 拓展人 | high |
| subBranchList | subbranchlist | R | 门店信息列表json数组 | high |
| prodList | prodlist | R | 支付产品信息列表json数组 | high |
| addFaCusId | addfacusid | C | 所在机构资金归集时必填 | high |
| settIdNo | settidno | C | 结算账户对私时必填 | high |
| holderName | holdername | C | 商户性质为企业/个体户时必填 | high |
| holderIdNo | holderidno | C | 商户性质为企业/个体户时必填 | high |
| holderExpire | holderexpire | C | 商户性质为企业/个体户时必填 | high |
| registerFund | registerfund | C | 商户性质为企业/个体户时必填；取值见 field-enum-glossary.registerfund | high |
| staffTotal | stafftotal | O | 可选；取值见 field-enum-glossary.stafftotal | high |
| operateLimit | operatelimit | O | 可选；取值见 field-enum-glossary.operatelimit | high |
| inspect | inspect | O | 可选；取值见 field-enum-glossary.inspect | high |
| thrCertFlag | thrcertflag | O | 是否三证合一；默认1 | high |
| organCode | organcode | C | 三证合一=否时必填 | high |
| organExpire | organexpire | C | 三证合一=否时必填；yyyy-mm-dd或长期 | high |
| busConActPerson | busconactperson | C | 非个人类商户必填 | high |
| busConActTel | busconacttel | C | 非个人类商户必填 | high |
| ofFlag | offlag | O | 线上线下业务场景；枚举见 field-enum-glossary.offlag | high |
| unSdRemark | unsdremark | O | 渠道备注信息 | high |
| agreeType | agreetype | O | 无纸化标识；枚举见 field-enum-glossary.agreetype | high |
| picUrlJson | picurljson | O | 图片json字符串（图片url键值对） | high |
| cusUrl | cusurl | C | 开通网关/快捷/云闪付APP或线上场景必填 | high |
| webName | webname | C | 开通网关/快捷/云闪付APP或线上场景必填 | high |
| legalDetail | legaldetail | R | 法人信息json字符串 | high |
| bnfDetail | bnfdetail | R | 受益人信息json字符串 | high |
| taxDetail | taxdetail | C | 企业且非三证合一时必填 | high |
| busDetail | busdetail | R | 经营内容 | high |
| businessPlace | businessplace | O | 经营场所；枚举见 field-enum-glossary.businessplace | high |
| busAddress | busaddress | R | 商户经营地址 | high |
| districtCode | districtcode | R | 所在区（见附录） | high |
| reqId | reqid | O | 进件请求流水号 | high |
| settRemark | settremark | O | 结算摘要前缀；仅当非自主提现时获取 | high |
| creditCodeType | creditCodeType | O | 营业执照类型 | high |
| creditCodeStartDate | creditCodeStartdate | O | 营业证件成立日期；yyyy-MM-dd | high |
| legalIdStartDate | legalidStartdate | O | 法人证件生效日期；yyyy-MM-dd | high |
| icpInfo | icpinfo | O | ICP备案号 | high |
| pubAcctInfo | pubacctinfo | C | 企业/事业单位/其他组织且结算账户对私时必填；格式见文档 | high |
| appScenario | appscenario | O | 应用场景；枚举见 field-enum-glossary.appscenario | high |
| quickCash | quickcash | O | 快速提现开关；枚举见 field-enum-glossary.quickcash | high |
| clearTimeRule | cleartimerule | O | 结算时间；枚举参考附录8.8 | high |
| electNotify | electnotify | O | 电子协议签约回调地址；为空通知到进件回调url | high |
| creDentCheckDate | credentcheckdate | O | 营业执照核准日期；yyyy-mm-dd | high |

## 字段必填矩阵 - MerChantAddTermRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| termNo | termno | R | 8位数字；商户下唯一 | high |
| deviceType | devicetype | R | 设备类型；取值见 field-enum-glossary.devicetype | high |
| termSn | termsn | C | 当 deviceType=02/03/04/05/06/08/09/10 时必填 | high |
| operaTion | operation | R | 操作类型；取值见 field-enum-glossary.term_operation；取值为02（注销）时，termsn/termstate 可空 | high |
| termState | termstate | C | 终端状态；取值见 field-enum-glossary.term_state；operaTion=02（注销）时可空 | high |
| termAddress | termaddress | C | 省-市-区-详细地址；详细地址长度控制在30个汉字以内；取值范围可参考省市区结构说明；operaTion=02（注销）时可空 | high |

## 字段必填矩阵 - MerChantAgentExpiredRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| fileType | filetype | R | 到期提醒文件类型；取值见 field-enum-glossary.filetype_agentexpired | high |
| endDate | enddate | O | 到期日；默认当前日期；格式yyyy-MM-dd | high |
| notifyUrl | notifyurl | R | 通知地址；按该地址回调调用方，详见进件通知 | high |

## 字段必填矩阵 - MerChantBindCodeRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| qrCode | qrcode | R | 当面付二维码（未绑定二维码ID） | high |
| branchNo | branchno | C | 二维码绑定为门店层时必填 | high |
| latitude | latitude | C | 二维码绑定为商户层时必填 | high |
| longitude | longitude | C | 二维码绑定为商户层时必填 | high |

## 字段必填矩阵 - MerChantConfirmBindRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| qrCode | qrcode | R | 当面付二维码（与申请时一致） | high |
| branchNo | branchno | O | 商户门店号（与申请时一致） | high |
| latitude | latitude | O | 纬度（与申请时一致） | high |
| longitude | longitude | O | 经度（与申请时一致） | high |
| smsCode | smscode | R | 短信验证码 | high |

## 字段必填矩阵 - MerChantConfirmUnBindRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| qrCode | qrcode | R | 当面付二维码（与申请时一致） | high |
| smsCode | smscode | R | 短信验证码 | high |

## 字段必填矩阵 - MerChantEditRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| shortName | shortname | O | 可选；20个字内 | high |
| servicePhone | servicephone | O | 可选；业务联系人电话 | high |
| corpBusName | corpbusname | C | 商户性质非个人时需填写 | high |
| creditCode | creditcode | C | 商户性质非个人时需填写 | high |
| creditCodeExpire | creditcodeexpire | C | 商户性质非个人时需填写 | high |
| legal | legal | O | 可选；法人姓名 | high |
| legalIdType | legalidtype | O | 可选；取值见 field-enum-glossary.legalidtype（编辑场景常用01/04/05） | high |
| legalIdNo | legalidno | O | 可选；法人代表证件号 | high |
| legalIdExpire | legalidexpire | O | 可选；法人身份证有效期 | high |
| address | address | O | 可选；注册地址 | high |
| contactPerson | contactperson | O | 可选；财务联系人（收短信） | high |
| contactPhone | contactphone | O | 可选；财务联系人电话 | high |
| addFaCusId | addfacusid | O | 可选；所属父客户号 | high |
| notifyUrl | notifyurl | R | 回调url；回调结果格式请参照进件通知 | high |
| zipUrl | zipurl | O | 可选；附件url，仅支持zip压缩包 | high |
| picsTrUrl | picstrurl | O | 可选；图片url拼接，使用分号`;`分隔，最多5张 | high |
| holderName | holdername | C | 商户性质为企业/个体户时必填 | high |
| holderIdNo | holderidno | C | 商户性质为企业/个体户时必填 | high |
| holderExpire | holderexpire | C | 商户性质为企业/个体户时必填 | high |
| registerFund | registerfund | C | 商户性质为企业/个体户时必填；取值见 field-enum-glossary.registerfund | high |
| staffTotal | stafftotal | O | 可选；取值见 field-enum-glossary.stafftotal | medium |
| operateLimit | operatelimit | O | 可选；取值见 field-enum-glossary.operatelimit | medium |
| inspect | inspect | O | 可选；取值见 field-enum-glossary.inspect | medium |
| thrCertFlag | thrcertflag | O | 可选；三证合一标识，取值见 field-enum-glossary.thrcertflag | high |
| organCode | organcode | C | 三证合一=否时需要填写 | high |
| organExpire | organexpire | C | 三证合一=否时需要填写 | high |
| busConActPerson | busconactperson | C | 非个人类商户必填 | high |
| busConActTel | busconacttel | C | 非个人类商户必填 | high |
| unSdRemark | unsdremark | O | 可选；渠道备注信息 | high |
| legalDetail | legaldetail | O | 可选；法人信息json（详见文档） | high |
| bnfDetail | bnfdetail | O | 可选；受益人信息json | high |
| taxDetail | taxdetail | O | 可选；税务登记详情json | high |
| busDetail | busdetail | O | 可选；经营内容 | high |
| cusUrl | cusurl | O | 可选；网站url或下载地址 | high |
| webName | webname | O | 可选；网站名称/应用名称 | high |
| businessPlace | businessplace | O | 可选；经营场所，取值见 field-enum-glossary.businessplace | high |
| busAddress | busaddress | O | 可选；商户经营地址 | high |
| districtCode | districtcode | O | 可选；所在区 | high |
| merChantName | merchantname | O | 可选；商户名称 | high |
| tlBankNo | tlbankno | O | 可选；电子账号号 | high |
| creditCodeType | creditCodeType | O | 可选；营业执照类型 | high |
| creditCodeStartDate | creditCodeStartdate | O | 可选；营业证件成立日期，格式yyyy-MM-dd | high |
| legalIdStartDate | legalidStartdate | O | 可选；法人证件生效日期，格式yyyy-MM-dd | high |

## 字段必填矩阵 - MerChantElectSignRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| electSignType | electsigntype | O | 电子协议类型；为空表示进件协议；取值见 field-enum-glossary.electsigntype_prodfeeshare | high |
| relatedCusId | relatedcusid | C | 关联商户号；electSignType=14/15 时不能为空；electSignType=14 时为出金商户号，electSignType=15 时为入金商户号 | high |

## 字段必填矩阵 - MerChantProdFeeShareQryRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|

## 字段必填矩阵 - MerChantProductRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqType | reqtype | R | 请求类型；取值见 field-enum-glossary.reqtype_merchant_product | high |
| prodList | prodlist | C | 支付产品信息列表json；reqType=query 时可空，其它请求类型必填 | high |

## 字段必填矩阵 - MerChantQrCodeQryRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| qrCode | qrcode | R | 当面付二维码（当前商户绑定二维码） | high |

## 字段必填矩阵 - MerChantQryTermRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| termNo | termno | R | 8位数字终端号 | high |
| queryType | querytype | O | 查询类型；取值见 field-enum-glossary.querytype_term；为空时返回AT加银联报备状态 | high |

## 字段必填矩阵 - MerChantQueryChnlCmIdRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| chnlType | chnltype | R | 渠道类型（中文大写缩写）；取值见 field-enum-glossary.chnltype_merchant | high |
| settId | settid | C | 结算id；仅当该商户存在多个结算id且无法创建建子商户号时传 | high |

## 字段必填矩阵 - MerChantQueryCusRgcRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|

## 字段必填矩阵 - MerChantQueryElectSignRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|

## 字段必填矩阵 - MerChantQueryElectUrlRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| redirectUrl | redirecturl | U | 重定向url | low |

## 字段必填矩阵 - MerChantQueryRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|

## 字段必填矩阵 - MerChantQueryStatusRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| merChantId | merchantid | U | 代理商平台商户号（系统内唯一） | low |
| reqId | reqid | U | 请求流水号 | low |

## 字段必填矩阵 - MerChantQueryWxSubDevRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|

## 字段必填矩阵 - MerChantQueryWxVerifyStateRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| chnlType | chnltype | R | 渠道类型（中文大写缩写）；取值见 field-enum-glossary.chnltype_merchant | high |
| pid | pid | C | 产品类型；取值见 field-enum-glossary.pid_wxverifystate | high |

## 字段必填矩阵 - MerChantRepairComplianceRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| cusShortName | cusshortname | C | 仅当门头照不合规时支持修改 | high |
| address | address | C | 仅当租赁合同（承租人）不合规时支持修改 | high |
| creDentExpire | credentexpire | C | 格式yyyy-MM-dd；仅creditresult不合规时可补录 | high |
| legalIdExpire | legalidexpire | C | 格式yyyy-MM-dd；仅legalidresult不合规时可补录 | high |
| acctId | acctid | C | 仅clearparamresult不合规且为对公结算信息项时可补录 | high |
| storePic | storepic | C | 图片url；仅headresult或headresulthd门头照不合规时可补录 | high |
| innerPic | innerpic | C | 图片url；仅innerresult或innerresulthd内部经营照不合规时可补录 | high |
| handPickPic | handpickpic | C | 图片url；仅handpickresult或handpickresulthd经营者手持身份证照片不合规时可补录 | high |
| peasonHeadPic | peasonheadpic | C | 图片url；仅peasonheadresult经营者与店铺门头合照不合规时可补录 | high |
| creditPic | creditpic | C | 图片url；仅creditresult或creditresulthd营业证件照不合规时可补录 | high |
| legalIdPicFront | legalidpicfront | C | 图片url；仅legalidresult或legalidresulthd身份证照不合规时可补录 | high |
| legalIdPicBack | legalidpicback | C | 图片url；仅legalidresult或legalidresulthd身份证照不合规时可补录 | high |
| rentCtPic | rentctpic | C | 图片url；仅rentctresult租赁合同不合规时可补录 | high |
| registerPic | registerpic | C | 图片url；仅paperresult纸质协议不合规时可补录 | high |
| homePagePic | homepagepic | C | 图片url；仅paperresult纸质协议不合规时可补录 | high |
| finalPagePic | finalpagepic | C | 图片url；仅paperresult纸质协议不合规时可补录 | high |
| clearParamPic | clearparampic | C | 图片url；仅clearparamresult或clearparamresulthd结算信息项不合规时可补录 | high |
| authorPic | authorpic | C | 图片url；仅authresult或authresulthd签字授权书不合规时可补录 | high |
| certifiedPic | certifiedpic | C | 图片url；仅certifiedresult执业证明材料不合规时可补录 | high |
| repairOtherPic | repairotherpic | O | 图片url；其他补充材料，可多张，以英文分号`;`拼接 | high |

## 字段必填矩阵 - MerChantRepairCusrgcRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| jumpUrl | jumpurl | U | 补录完成跳转地址 | low |

## 字段必填矩阵 - MerChantSecondPageRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|

## 字段必填矩阵 - MerChantSubBranchRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqType | reqtype | R | 请求类型；取值见 field-enum-glossary.reqtype_merchant_product | high |
| subBranchList | subbranchlist | C | 门店列表json；长度不超过4000；reqType=query 时可空，其它请求类型必填 | high |

## 字段必填矩阵 - MerChantTermRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqType | reqtype | R | 请求类型；取值见 field-enum-glossary.reqtype_merchant_term | high |
| termList | termlist | C | 终端信息列表json；长度不超过1000；reqType=query 时可空，reqType=add 时必填 | high |

## 字段必填矩阵 - MerChantUnBindCodeRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| qrCode | qrcode | U | 当面付二维码 | low |

## 字段必填矩阵 - MerChantWxSubDevConfigRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| configType | configtype | R | 配置类型；取值见 field-enum-glossary.configtype_wxsubdev | high |
| configVal | configval | R | 配置值；根据配置类型填写对应值（支付域名或支付appid）；支付域名与支付appid不支持同时配置 | high |

## 字段必填矩阵 - MerChantWxVerifyRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| userId | userid | U | 文档尚未完全核实 | low |
| notifyUrl | notifyurl | U | 文档尚未完全核实 | low |
| pageType | pagetype | R | 页面类型；取值见 field-enum-glossary.pagetype_wxverify | high |



