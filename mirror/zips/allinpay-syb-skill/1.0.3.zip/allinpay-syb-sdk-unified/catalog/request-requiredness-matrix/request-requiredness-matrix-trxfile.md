# 字段必填矩阵 - TrxFile

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TrxFileGetRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| date | date | R | 交易日期；格式 yyyymmdd | high |
| fileType | filetype | O | 对账单类型；当前值为 `1`；取值见 field-enum-glossary.fileType | high |

## 字段必填矩阵 - TrxFileSettTrxRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|----|---|---|
| settDate | settdate | R  | 结算日期；格式 yyyymmdd | high |


