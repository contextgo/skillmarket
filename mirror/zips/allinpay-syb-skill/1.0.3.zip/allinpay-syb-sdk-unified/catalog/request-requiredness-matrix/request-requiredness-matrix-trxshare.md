# 字段必填矩阵 - TrxShare

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TrxShareQueryRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqSn | reqsn | C | 商户平台分账流水号；与 `payerTrxId` 二选一 | high |
| payerTrxId | payertrxid | C | 分账成功的出金方通联交易单号；与 `reqSn` 二选一；同时上送时优先 `payerTrxId` | high |

## 字段必填矩阵 - TrxShareRevokeQueryRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqSn | reqsn | C | 商户平台分账回退流水号；与 `rkTrxId` 二选一 | high |
| rkTrxId | rktrxid | C | 通联分账回退交易单号；与 `reqSn` 二选一；同时上送时优先 `rkTrxId` | high |

## 字段必填矩阵 - TrxShareRevokeRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqSn | reqsn | R | 回退流水号；商户平台分账回退流水号；两个自然日内唯一 | high |
| payerTrxId | payertrxid | R | 出金交易单号；分账成功的出金方通联交易单号 | high |
| payerReqSn | payerreqsn | O | 出金方回退流水号；用于对账可空；回退的出金方则原分账交易的入金方 | high |
| trxAmt | trxamt | R | 回退金额；单位分 | high |
| remark | remark | R | 业务备注；最大 50 个文字 | high |

## 字段必填矩阵 - TrxShareShareRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqSn | reqsn | R | 分账流水号；商户平台分账流水号；两个自然日内唯一 | high |
| oldTrxId | oldtrxid | R | 交易单号；待分账交易的通联交易单号 | high |
| payeeCusId | payeecusid | R | 入金商户号 | high |
| payeeReqSn | payeereqsn | O | 入金商户流水号；用于对账，可空 | high |
| trxAmt | trxamt | R | 分账金额；单位分 | high |
| remark | remark | R | 分账备注；业务备注；最大 50 个文字 | high |


