# 字段必填矩阵 - ZhimaCredit

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

说明：ZhimaCredit 系列 request 字段较多且业务结构特殊，当前不强制约束字段是否必填，统一以 `U` 标记为待核实。

## 字段必填矩阵 - ZhimaCreditMiniOrderRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| tranCode | trancode | U | 接口编号；取值见 field-enum-glossary.trancode_zhimacredit_miniorder，且必须与 bizData 业务实体一一对应 | high |
| serviceId | serviceid | U | 服务id | medium |
| bizData | bizdata | U | 业务参数须使用 `JsonUtils.toJson(bizObj)` 生成 JSON（import `com.allinpay.syb.sdk.core.utils.JsonUtils`），再做 json->utf8->base64；实体映射见 field-enum-glossary.bizdata_entity_zhimacredit_miniorder；禁止 Map/手写 JSON/宣称 SDK 自动转 JSON | high |
| id | id | U | 本次通知流水 | medium |

## 字段必填矩阵 - ZhimaCreditPayRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| trxAmt | trxamt | U | 交易金额 单位为分 | medium |
| reqSn | reqsn | U | 商户交易单号 | medium |
| body | body | U | 订单标题 | medium |
| remark | remark | U | 备注 | medium |
| asInfo | asinfo | U | 分账信息 | medium |
| extendParams | extendparams | U | 扩展参数 | medium |
| termInfo | terminfo | U | 终端信息 | medium |
| validTime | validtime | U | 有效时间 | medium |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderChanged

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| outOrderId | out_order_id | U | 商户订单号 | medium |
| orderId | order_id | U | 交易组件订单号 | medium |
| tradeNo | trade_no | U | 支付宝交易号 | medium |
| status | status | U | 交易状态 | medium |
| operateAppId | operate_app_id | U | 开发者应用ID | medium |
| authAppId | auth_app_id | U | 授权方应用ID | medium |
| totalAmount | total_amount | U | 订单金额 | medium |
| receiptAmount | receipt_amount | U | 实收金额 | medium |
| secureReason | secure_reason | U | 安全处置原因 | medium |
| groupBuyInfo | group_buy_info | U | 拼团信息 | medium |
| userId | user_id | U | 买家支付宝用户ID | medium |
| openId | open_id | U | 用户openId | medium |
| settleType | settle_type | U | 账期标识 | medium |
| voucherDetailList | voucher_detail_list | U | 券明细 | medium |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderClose

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| outOrderId | out_order_id | U | 商户订单号 | medium |
| orderId | order_id | U | 交易组件订单号 | medium |
| userId | user_id | U | 买家支付宝用户 | medium |
| openId | open_id | U | 支付宝用户open_id | medium |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderCreate

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| outOrderId | out_order_id | U | 商户订单号 | medium |
| title | title | U | 订单标题 | medium |
| sourceId | source_id | U | 追踪ID | medium |
| merchantBizType | merchant_biz_type | U | 订单类型 | medium |
| path | path | U | 商家小程序对应的订单详情页路径地址 | medium |
| orderDetail | order_detail | U | 订单信息 | medium |
| sellerId | seller_id | U | 卖家支付宝用户ID | medium |
| buyerId | buyer_id | U | 买家ID | medium |
| buyerOpenId | buyer_open_id | U | 买家支付宝用户唯一标识 | medium |
| buyerLogonId | buyer_logon_id | U | 买家支付宝登录账号 | medium |
| shopInfo | shop_info | U | 门店信息 | medium |
| creditInfo | credit_info | U | 芝麻信用信息 | medium |
| stagePayPlans | stage_pay_plans | U | 阶段付款计划 | medium |
| contactInfo | contact_info | U | 买家联系人信息 | medium |
| addressInfo | address_info | U | 订单收货地址 | medium |
| promoDetaiInfo | promo_detai_info | U | 订单优惠信息 | medium |
| extInfo | ext_info | U | 订单扩展字段 | medium |
| deliveryDetail | delivery_detail | U | 物流信息 | medium |
| defaultReceivingAddress | default_receiving_address | U | 默认退货地址 | medium |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderCreditAgreeChanged

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| creditAgreementId | credit_agreement_id | U | 开通/授权协议号 | medium |
| title | title | U | 订单标题 | medium |
| agreementStatus | agreement_status | U | 开通/授权状态 | medium |
| outAgreementNo | out_agreement_no | U | 商户外部协议号 | medium |
| bizTime | biz_time | U | 开通/授权状态变更的时间 | medium |
| openChannel | open_channel | U | 开通渠道 | medium |
| alipayUserId | alipay_user_id | U | 用户ID | medium |
| openId | open_id | U | 开放ID | medium |
| extInfo | ext_info | U | 扩展字段 | medium |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderCreditAgreeQuery

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| outAgreementNo | out_agreement_no | U | 商户外部协议号 | medium |
| creditAgreementId | credit_agreement_id | U | 开通/授权协议号 | medium |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderInstallmentCreate

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| outInstallmentOrderId | out_installment_order_id | U | 外部分期单号 | medium |
| type | type | U | 分期类型 | medium |
| orderId | order_id | U | 交易组件订单号 | medium |
| outOrderId | out_order_id | U | 外部商户订单号 | medium |
| userId | user_id | U | 买家ID | medium |
| openId | open_id | U | 支付宝用户唯一标识 | medium |
| installmentPrice | installment_price | U | 分期金额 | medium |
| installmentNo | installment_no | U | 本次分期号 | medium |
| tradeNo | trade_no | U | 交易号 | medium |
| isFinishPerformance | is_finish_performance | U | 分期是否完结 | medium |
| payChannel | pay_channel | U | 分期单支付渠道 | medium |
| stageNo | stage_no | U | 分期阶段编码 | medium |
| isSyncPay | is_sync_pay | U | 是否同步主动支付 | medium |

## 字段必填矩阵 - ZhimaCreditTCMiniOrderQuery

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
| --- | --- | --- | --- | --- |
| outOrderId | out_order_id | U | 商户订单号 | medium |
| orderId | order_id | U | 交易组件订单号 | medium |
| userId | user_id | U | 买家支付宝用户 | medium |
| openId | open_id | U | 支付宝用户open_id | medium |


