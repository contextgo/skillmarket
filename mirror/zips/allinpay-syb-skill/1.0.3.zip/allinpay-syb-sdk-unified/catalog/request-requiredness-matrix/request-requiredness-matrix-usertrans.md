# 字段必填矩阵 - UserTrans

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - UserTransCusPayRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| c | c | R | 二维码 ID（通联分配） | high |
| oid | oid | C | 订单编号；与 `uniReqSn` 二选一 | high |
| uniReqSn | unireqsn | C | 唯一订单编号；与 `oid` 二选一；当两者并存时优先取 `oid` 原有逻辑 | high |
| amt | amt | R | 交易金额；单位分 | high |
| retUrl | returl | R | 成功支付跳转地址；必须 https 且不能携带参数；`trxReserve` 必填 | high |
| trxReserve | trxreserve | R | 业务备注信息；参见订单详情标签个性化说明 | high |
| submitTime | submittime | R | 截止支付时间；格式 `yyyyMMddHHmmss` | high |
| extendParams | extendparams | O | 扩展参数；JSON 字符串（String） | high |
| asInfo | asinfo | O | 分账参数；格式 `cusid:type:amount[,cusid:type:amount...]`；type：`01` 按金额、`02` 按比例（0.5 表示 50%） | high |


