# 字段必填矩阵 - B2bOrder

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - B2bOrderDirectPayRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 | high |
| body | body | O | 订单标题；为空时默认商户名 | high |
| remark | remark | O | 备注信息 | high |
| validTime | validtime | R | 有效时间；单位分钟；最大43200 | high |
| acctNo | acctno | R | 收款账号；需SM4加密 | high |
| acctName | acctname | R | 收款户名；需SM4加密 | high |
| acctType | accttype | R | 收款账户类型：0对私/1对公（当前仅支持对公） | high |
| bankCode | bankcode | R | 收款银行代码；取值见 field-enum-glossary.bankcode_b2b_directpay | high |
| goodsInfo | goodsinfo | R | 商品单元信息；List 的 JSON 字符串（注意字段类型为字符串） | high |
| notifyUrl | notify_url | O | 交易结果通知地址；必须可直连访问且不能携带参数 | high |
| encrypttype | encrypttype | R | 加密方式固定 SM4（国密） | high |

## 字段必填矩阵 - B2bOrderPayRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 交易金额；单位分 | high |
| payeeCusId | payeecusid | R | 收款方商户号 | high |
| reqSn | reqsn | R | 商户交易单号；同商户下唯一 | high |
| body | body | O | 订单标题；为空时默认商户名 | high |
| remark | remark | O | 备注信息 | high |
| validTime | validtime | R | 有效时间；单位分钟；最大43200 | high |
| acctNo | acctno | R | 付款账号；需SM4加密 | high |
| acctName | acctname | R | 付款户名；需SM4加密 | high |
| acctType | accttype | R | 付款账户类型：0对私/1对公（当前仅支持对公） | high |
| bankCode | bankcode | R | 付款银行代码；取值见 field-enum-glossary.bankcode_b2b_pay | high |
| goodsInfo | goodsinfo | R | 商品单元信息；List 的 JSON 字符串（注意字段类型为字符串） | high |
| notifyUrl | notify_url | O | 交易结果通知地址；必须可直连访问且不能携带参数 | high |
| encrypttype | encrypttype | R | 加密方式固定 SM4（国密） | high |


