# 字段必填矩阵 - Tranx

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - TranxCancelRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 交易金额（原交易金额） | high |
| reqSn | reqsn | R | 商户撤销交易单号；商户平台唯一 | high |
| oldReqSn | oldreqsn | C | 原交易商户交易单号；与 `oldTrxId` 二选一 | high |
| oldTrxId | oldtrxid | C | 原交易收银宝平台流水；与 `oldReqSn` 二选一；同时上送时优先使用 `oldTrxId` | high |

## 字段必填矩阵 - TranxCloseRequset

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| oldReqSn | oldreqsn | C | 原交易商户交易单号；与 `oldTrxId` 二选一 | high |
| oldTrxId | oldtrxid | C | 原交易收银宝平台流水；与 `oldReqSn` 二选一；同时上送时优先使用 `oldTrxId` | high |

## 字段必填矩阵 - TranxQueryConfirmRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqSn | reqsn | C | 商户交易订单号；与 `trxId` 二选一 | high |
| trxId | trxid | C | 平台交易流水（支付收银宝平台流水）；与 `reqSn` 二选一；同时上送时优先 `trxId` | high |

## 字段必填矩阵 - TranxQueryOrderRequest

适用场景：当面付发起的订单消费支付交易查询。

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxDate | trxdate | O | 交易日期；格式 `mmdd`；当查询条件为 `trxId` 时可空 | high |
| orderId | orderid | C | 订单号（POS 订单支付输入的商户订单号）；与 `trxId` 不能同时为空 | high |
| trxId | trxid | C | 收银宝交易流水；与 `orderId` 不能同时为空 | high |
| termNo | termno | O | 终端号；8位数字 | high |
| resendNotify | resendnotify | R | 是否重发交易结果通知；取值见 field-enum-glossary.resendnotify_tranx_query_order | high |

## 字段必填矩阵 - TranxQueryRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| reqSn | reqsn | C | 商户交易订单号；与 `trxId` 二选一 | high |
| trxId | trxid | C | 平台交易流水（支付收银宝平台流水）；与 `reqSn` 二选一；同时上送时优先 `trxId` | high |

## 字段必填矩阵 - TranxRefundRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| trxAmt | trxamt | R | 退款核心字段; 格式提示： 金额单位为分 | high |
| reqSn | reqsn | R | 退款核心字段 | high |
| oldReqSn | oldreqsn | C | oldreqsn/oldtrxid 二选一 | high |
| oldTrxId | oldtrxid | C | oldreqsn/oldtrxid 二选一, oldtrxid preferred | high |
| remark | remark | O | 按场景可选 | medium |
| benefitDetail | benefitdetail | O | 按场景可选 | medium |
| notifyUrl | notify_url | O | 按场景可选 | medium |


