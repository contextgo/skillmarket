﻿# 字段必填矩阵 - Activity

- R = 必填
- C = 条件必填
- O = 可选
- U = 待核实（未完全验证）

## 字段必填矩阵 - ActivityActivityPageRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| actId | actid | O | 按场景可选，若传入则不能为空；取值见 field-enum-glossary.actid; 文档提示： 枚举见 field-enum-glossary.actid（活动号） | high |
| userId | userid | U | 文档尚未完全核实 | low |

## 字段必填矩阵 - ActivityCusActivityRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| corpBusName | corpbusname | U | 文档尚未完全核实 | low |
| branchName | branchname | U | 文档尚未完全核实 | low |
| areaCode | areacode | U | 文档尚未完全核实 | low |
| address | address | U | 文档尚未完全核实 | low |
| actType | acttype | O | 按场景可选，若传入则不能为空；取值见 field-enum-glossary.acttype; 文档提示： 枚举见 field-enum-glossary.acttype（活动类型） | high |
| zipPicUrl | zippicurl | U | 文档尚未完全核实 | low |
| notifyUrl | notifyurl | U | 文档尚未完全核实 | low |
| actDetail | actdetail | C | acttype=04/07/08/09/10/11 时必填；acttype=12 时不填；JSON字符串; 文档提示： JSON字符串；acttype=04/07/08/09/10/11 时必填；acttype=12 时不填 | high |

## 字段必填矩阵 - ActivityQueryActivityRequest

| 字段 | JSON 名 | 级别 | 条件 | 置信度 |
|---|---|---|---|---|
| actType | acttype | U | 按场景可选，若传入则不能为空；取值见 field-enum-glossary.acttype; 文档提示： 枚举见 field-enum-glossary.acttype（活动类型） | low |


