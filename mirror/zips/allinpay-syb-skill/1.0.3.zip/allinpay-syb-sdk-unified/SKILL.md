﻿---
name: allinpay-syb-sdk-unified
display_name: 通联收银宝业务技能（全量接口路由 + Java Demo）
description: 通联收银宝（SYB）业务 Skill：覆盖 allinpay-syb-sdk-java 全量 request API，按场景自动选择请求类并生成可运行 Java Demo。它依赖共享协议层（签名/异步通知/凭据边界/运行时要求），并提供“仅看代码/工程落地”两种输出模式。
version: 1.0.2
author: "allinpay | 开放平台"
license: "Allinpay"
compatibility:
  - skillhub
dependencies: []
metadata:
  skillhub:
    requires:
      config:
        - SYB_CUS_ID
        - SYB_APP_ID
        - SYB_SIGN_TYPE
        - SYB_SM4_KEY
        - SYB_MD5_KEY
        - SYB_PRI_KEY
        - SYB_PUB_KEY
        - SYB_ENV
triggers:
  - allinpay
  - 收银宝
  - syb sdk
  - request api
  - demo
  - maven
  - pom
  - pom.xml
  - 依赖
  - 脚手架
  - 落地
  - 只看代码
  - 不落地
  - 不改工程
  - 参考代码
  - 示例代码
  - 只要代码
  - 帮我加依赖
  - 加到pom
  - 加到pom.xml
  - 改pom
  - 改pom.xml
  - 生成到工程
  - 生成到目录
  - 可运行
  - 可编译
---

# 通联收银宝业务 Skill（全量接口路由 + Java Demo）

依赖：`allinpay-syb-pay-shared-base`（签名/验签、异步通知、凭据边界、运行时要求、SDK FAQ）。

## 目标与模式

仅支持 **Java + Maven**，输出模式固定二选一：

- `show_code_only`：只给可运行 Java 示例，不改工程。
- `scaffold_java_maven_demo`：给工程落地步骤与 JSON 工单（改 `pom.xml`、写 Demo、分级校验）。

默认：用户未明确要求落地时，使用 `show_code_only`。

## 路由与检索（必须遵守）

1. 先读 `catalog/project-domain-fill-spec.md` 判定文集域。  
2. 先读 `catalog/request-routing-map.md`，再按前缀进入 `catalog/request-routing-map/request-routing-map-*.md` 选择 request 类与 `Requiredness shard`。  
3. 仅加载路由命中的一个矩阵分片：`catalog/request-requiredness-matrix/request-requiredness-matrix-*.md`。  
4. 在该分片内直接定位目标请求类小节（不再下钻其他索引或中间文件）。  
5. 非用户明确要求，不得同时加载多个分片或整目录（包括 `request-routing-map/` 与 `request-requiredness-matrix/`）。
6. 若 `request-requiredness-matrix/*` 的 `条件` 列出现 `格式提示：` 或 `文档提示：`，生成代码时必须逐字遵守提示，禁止自造示例格式。
7. 若 `文档提示：` 明确为“分钟/时长”，禁止输出日期时间字符串（如 `2026-04-23 00:00:00`）；若明确为日期时间格式（如 `yyyyMMddHHmmss`），禁止输出分钟数。

## 数据边界

- 本技能当前请求字段规则单一真源：`catalog/request-requiredness-matrix/`；响应字段白名单单一真源：`catalog/response-field-matrix.md`；枚举单一真源：`catalog/field-enum-glossary.md`。
- 路由单一入口：`catalog/request-routing-map.md` 与其前缀分片。
- 以上内容用于检索与示例生成；不是签约文档全文。
- `request-requiredness-matrix` 中 `U` 表示未完全静态确认，禁止直接断言“必填/可选”。
- `request-requiredness-matrix` 采用人工维护单一真源；禁止自动脚本覆盖生成，仅允许执行校验脚本。
- `response-field-matrix.md` 由 SDK `api/response` 源码生成；生成响应处理代码、读取响应字段、解释 getter 时必须先查该矩阵，禁止臆造 SDK response 类不存在的字段/getter。
- SDK 版本以仓库 `allinpay-syb-sdk-java/pom.xml` 为准。

## 代码生成硬规则

1. 初始化使用以下形态：`MerchantConfig merchantConfig = MerchantConfig.builder().cusId(...).appId(...).signType(...).environment(...); AllinpayApi.initialize(merchantConfig);`（`MerchantConfig` 无 `build()` 方法）。  
2. `MerchantConfig.builder()` 是允许且推荐用法；禁止范围仅限 SDK `request` 包模型，不得臆造 `SomeRequest.builder()/build()` 形态。  
3. 参数顺序：必填 -> 条件必填 -> 可选。  
4. 日志包含：请求 URL、请求报文、响应报文。  
5. 异常处理：`AllinpayException` + `Exception`。  
6. 参数默认按明文传入；若字段存在 SDK 注解 `@EncryptField`，由 SDK 负责加密。禁止手工二次加密。  
7. Java 代码仅使用 SDK Java 属性名与 getter/setter，禁止用 JSON 字段名拼方法。  
8. `AllinpayResp` 基础 getter 固定：`getRetCode()` / `getRetMsg()` / `getTrxId()`；其他响应字段必须来自 `catalog/response-field-matrix.md` 中目标响应类或其父类链，禁止臆造字段/getter。  
9. Request 入参类型：除 `reference/sdk-request-java-field-types.md` 白名单字段外，`setXxx(...)` 入参一律 `String`，禁止自行改成数值/布尔/VO。
10. `execObj(...)` 返回值必须使用请求对应类型接收：后端请求用对应 `*Response` 子类（如 `TranxQueryRequest -> TranxQueryResponse`、`UnitOrderPayRequest -> UnitOrderPayResponse`）；前端跳转白名单请求可用 `AllinpayFrontResp`。禁止直接用 `AllinpayResp` 变量接收。  
11. 对“接口编号映射实体承载请求”（同一 Request 同时包含 `tranCode` + `bizData`）统一要求：`bizData` 由对应 SDK 实体序列化后按 `JSON -> UTF-8 -> Base64` 生成，禁止直接传原始 JSON。  
12. 对 `ZhimaCreditMiniOrderRequest.bizData` 与 `PayScoreServiceOrderRequest.bizData`，JSON 文本构造必须使用 `JsonUtils.toJson(bizObj)`，且必须显式导入 `import com.allinpay.syb.sdk.core.utils.JsonUtils;`；禁止宣称“SDK 会自动把实体转 JSON”。  
13. 接口编号、实体映射、三元组映射不在本文件内联维护；统一从 `catalog/field-enum-glossary.md` 读取（`trancode_*`、`bizdata_entity_*`、`actiontype_*`、`trxchnl_*`、`bizcontent_entity_*`）。  
14. `bizData`/`bizContent` 构造必须使用词典中声明的 SDK 实体映射，禁止 `Map<String,Object>`、`JsonNode`、手写 JSON 字符串、父类空对象或自定义同名类。对 `UnionPayYJHXVoUserEncryptData`、`UnionPayYJHXVoAuditEncryptData` 必须按明文字段构造对象并直接赋值，禁止手工加密后再上送（加密由 SDK 字段链路处理）。  
15. 非 `AllinpayReq` 的同包实体类（如 `UnionPayYJHXVo*`、`ZhimaCreditTCMiniOrder*`、`PayScoreTC*`）同样属于 SDK 参数协议，禁止新增同名/近似自定义类替换，禁止自行扩展不存在字段。
16. `AllinpayApi.client()` 调用仅允许以下白名单形态（按场景匹配其一）：`execObj(HttpConfig.build(), request)`、`execObj(preProcess, HttpConfig.build(), request)`、`upload(HttpConfig.build(), request)`、`downloadToByte(HttpConfig.build(), url)`、`downloadToFile(HttpConfig.build(), url, savePath)`、`noticeHandle(noticeStr)`；禁止新增参数、交换参数顺序、或改成自定义重载调用。
17. `AllinpayApi.client()` 实参来源必须遵循优先级：骨架已有变量/实参 > 用户明确提供参数 > `YOUR_XXX` 占位；禁止为“让示例跑通”自行臆造额外参数、默认常量、mock URL/mock reqsn。
18. 若用户提供骨架且骨架中已存在 `AllinpayApi.client()` 调用，必须复用其调用形态与参数变量名（含 `HttpConfig` 变量/`noticeStr`/`savePath` 等）；仅允许在可编辑区补齐缺失赋值，禁止改写调用签名。
19. `request` 字段赋值必须与当前 request 类真实 setter 一一对应；禁止把无关字段、跨接口字段、或非当前场景参数塞入后再传 `execObj/upload`。
20. 若无法从骨架与用户输入确定某个 `AllinpayApi.client()` 必需实参，必须保留占位并明确标注“待业务侧提供”；不得猜值后直接写入调用。
21. `AllinpayFrontResp` 仅允许用于以下白名单请求类（来源：SDK `ApiMethod` 的 `ApiType=FRONT_*`）：`UserTransCusPayRequest`、`QPayolAgreeApplyRequest`、`QPayolBindCardApplyRequest`、`GateWayPCRequest`、`GateWayH5Request`、`H5UnionPayOrderRequest`、`MerChantRepairCusrgcRequest`、`MerChantSecondPageRequest`、`ActivityActivityPageRequest`、`MerChantWxVerifyRequest`、`WxOpenGetOpenIdRequest`、`H5BillPayBillPayRequest`。
22. 非上述白名单请求类，一律禁止使用 `AllinpayFrontResp` 作为接收类型；必须使用请求对应的 `*Response` 子类。
23. 任何“主扫/二维码/支付页”语义都不能替代白名单判定；例如 `UnitOrderNativePayRequest` 必须接 `UnitOrderNativePayResponse`，不得改接 `AllinpayFrontResp`。
24. 响应字段读取必须命中 `catalog/response-field-matrix.md`：
   - 先定位当前 `*Response` 类，再沿 `Extends` 父类链补充基础字段；
   - Java 代码只能调用矩阵中列出的 getter；
   - JSON 字段名只用于理解平台报文，禁止用 JSON 名拼接 Java 方法；
   - SDK response 未声明但业务文档提到的字段，不得臆造 getter，只能打印完整响应对象/原始响应并提示以 SDK/官方文档为准。

## 响应码枚举限定（防止臆造）

- `retcode`、`trxstatus` 的枚举与语义统一以 `catalog/field-enum-glossary.md` 为唯一来源，禁止在本文件或回答中另起一份并产生漂移。  
- 输出时必须先引用词典中的既有枚举；若返回值不在词典集合，只能原样透传并提示“以官方最新文档为准”，禁止补全新枚举含义。

## 骨架锁定模式（用户给骨架时）

- 本 Skill 中“骨架”默认特指以下两个参考文件：`reference/UniversalSybDemo.java`（标准同步调用骨架）与 `reference/SpecialSceneSybDemo.java`（通知/上传/下载/前端跳转骨架）。若用户未另行指定骨架文件，必须以这两者作为生成与 patch 基准。  
- 仅 patch 指定可编辑区，不重写整类。  
- `package`、类名、方法签名、已有结构与命名保持一致。  
- import 仅允许：骨架已有 + SDK 存在类型 + `java.*`。  
- 若骨架是 setter 风格，禁止改 Builder；反之亦然。  
- 若含 `[LOCK-BEGIN]/[LOCK-END]`，锁定区不可改。  
- 生成后必须执行一致性自检，不通过则重做。

## 特殊场景规则

- 标准接口示例参考：`reference/UniversalSybDemo.java`。  
- 特殊场景（通知/上传/下载/前端跳转）参考：`reference/SpecialSceneSybDemo.java`。  
- `AllinpayFrontResp` 必须按 `request.apiMethod().getApiType()` 处理：
  - `FRONT_URL` -> `urlJump`
  - `FRONT_HTML` -> `htmlJump`
  - `FRONT_BOTH` -> 同时兼容

## 输出结构（每次必含）

1. **Intent**：`show_code_only` 或 `scaffold_java_maven_demo`（含判定依据）  
2. **Routing**：命中 request 类与理由  
3. **Demo（Java）**：可运行示例  
4. **Production notes**：幂等、重试、验签、脱敏、终态确认（回调+查询）

若为 `scaffold_java_maven_demo`，追加：

5. **工程落地步骤（Java + Maven）**：`projectDir`、依赖处理、Demo 路径、分级校验策略  
6. **scaffold 工单（JSON）**：`intent`、`changes`、`validation`
7. **落地自检（Checklist）**：按下方 5 条固定清单逐条给出“通过/不通过 + 一句话证据”

若为 `show_code_only`，仍保留步骤与 JSON 小节，但写明“仅展示代码，不修改工程”，并将 `changes`/`validation` 置空数组。

## 工程落地约定（Maven only）

- 仅支持 Maven（`pom.xml`）；Gradle/其他构建工具直接说明不支持并给 Maven 方案。  
- 依赖 GAV：`com.allinpay.cus.sdk:allinpay-syb-sdk-java`（版本默认跟随仓库 SDK `pom.xml`，除非用户指定）。  
- 有工程则补依赖与 Demo；无工程则创建最小 Maven 工程。  
- Demo 默认包名：优先复用现有包；无法判断时用 `com.allinpay.syb.demo`。  
- 校验策略采用“分级校验”，避免无 Maven 或坏工程时长时间重试：  
  - `L1` 静态校验：import 与类型可解析、第三方包在 `pom.xml` 中可追溯、测试代码位于 `src/test/java`；  
  - `L2` 环境预检：仅当 `mvn -v` 成功时才进入 Maven 编译；  
  - `L3` Maven 校验：默认 `mvn -q -DskipTests compile`，用户明确要求打包时再执行 `package`。
- 落地风格默认“SDK 直连最小实现”：未被用户明确要求时，禁止新增通用封装层（如 Facade/Adapter/Gateway 等）。
- `execObj(...)` 返回值应使用请求对应类型：后端请求用对应 `*Response` 子类；前端跳转白名单请求可用 `AllinpayFrontResp`。禁止统一降级为 `AllinpayResp` 基类接收。

## 落地输出自检模板（scaffold 必填）

当 `intent=scaffold_java_maven_demo` 时，输出末尾必须追加如下 5 条自检：

1. **SDK 类型真实性**：未使用 SDK 中不存在的类/方法（如虚构 Builder 类型）。  
2. **响应/调用形态正确性**：  
   - 标准请求：每个 `execObj(...)` 都由请求对应类型接收（后端 `*Response` / 前端白名单 `AllinpayFrontResp`）；  
   - 前端跳转：仅白名单请求类可使用 `AllinpayFrontResp`，并按 `ApiType` 处理 `urlJump/htmlJump`；  
   - 异步通知：使用 `noticeHandle(noticeStr)`，不走普通 `execObj`；  
   - 文件能力：上传/下载使用 `upload(...)`、`downloadToByte(...)`/`downloadToFile(...)`。  
3. **初始化正确性**：`MerchantConfig.builder()` 链式赋值后直接传入 `initialize(...)`，且未出现 `MerchantConfig.builder()...build()`。  
4. **无过度封装**：未新增未授权的 Facade/Adapter/Gateway 等抽象层。  
5. **可编译校验**：已输出分级校验结果（`L1/L2/L3`），并说明是否执行 Maven 命令及未执行原因。  
6. **client 调用参数真实性**：所有 `AllinpayApi.client()` 调用均命中白名单签名，且实参来自骨架/用户输入/占位三类合法来源之一，无臆造参数。  

## 参考入口

- `catalog/project-domain-fill-spec.md`
- `catalog/request-routing-map.md`
- `catalog/request-requiredness-matrix/`
- `catalog/response-field-matrix.md`
- `catalog/field-enum-glossary.md`
- `catalog/scaffold-protocol.md`
- `reference/sdk-request-java-field-types.md`


