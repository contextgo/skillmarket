﻿---
name: allinpay-syb-pay-shared-base
display_name: 通联收银宝共享协议层
description: 通联收银宝（SYB）共享协议层 Skill：签名/验签、异步通知、幂等、凭据边界、安全与日志脱敏、Java+Maven 运行时要求；含 Java SDK 第六章常见问题摘录（专篇）。所有业务场景（下单/查询/退款/文件/前端跳转）共用，不在业务 Skill 重复维护。
version: 1.0.2
author: "allinpay | 开放平台"
license: "Allinpay"
compatibility:
  - skillhub
metadata:
  skillhub:
    requires:
      config:
        - SYB_CUS_ID
        - SYB_APP_ID
        - SYB_SIGN_TYPE
        - SYB_SM4_KEY
        - SYB_MD5_KEY
        - SYB_PRI_KEY
        - SYB_PUB_KEY
        - SYB_ENV
triggers:
  - 签名
  - 验签
  - signtype
  - 异步通知
  - notify_url
  - webhook
  - 幂等
  - 重试
  - 脱敏
  - 密钥
  - 私钥
  - 公钥
  - SM4
  - RSA
  - SM2
  - MD5
  - maven
  - pom.xml
---

# 通联收银宝共享协议层

负责共享协议规则：签名/验签、回调幂等、凭据边界、运行时与排障。  
不负责 request 字段全集与必填矩阵（这些在 `allinpay-syb-sdk-unified/catalog`）。

## 先看哪里

- `protocol/signing.md`：签名与验签  
- `protocol/async-notify.md`：回调处理与幂等  
- `governance/credential-boundary.md`：凭据边界与安全  
- `runtime/java-maven.md`：Java + Maven 运行时要求  
- `references/faq.md`、Java SDK FAQ 专篇：常见问题  
- `references/troubleshooting.md`：排障  

## 硬规则

1. 密钥不硬编码，不入库，不下发前端。  
2. 回调必须验签并幂等处理，可重放。  
3. 同步返回不等于终态，需“回调为主 + 查询兜底”。  
4. 日志可排障但必须脱敏，禁止输出密钥与敏感信息。  
5. `acct/openid/user_id/authcode` 等运行时参数必须来自真实业务链路，不得臆造。

## 与业务 Skill 的边界

- 具体接口选型、字段清单、必填判断、Demo 落地由 `allinpay-syb-sdk-unified` 承担。  
- 若业务侧矩阵出现 `U`，不得在共享层直接下“必填/可选”绝对结论。

## 检索约束

- 本 Skill 仅引用相关专题文件，不展开业务 catalog 大表。  
- 涉及具体 request 字段时，直接路由到 unified 并按“索引 -> 单分片”读取。

