/**
 * 英语助教 · 配置文件
 *
 * 全部模块选填设计：
 *   - 填了环境变量 → 启用对应模块
 *   - 没填 → 静默跳过，不报错
 *   - 无任何默认值（避免误以为"已配置"）
 *
 * 生产环境：cron job 的 env 字段注入
 * 本地开发：.env 文件（不提交到仓库）
 */

const path = require('path');
const fs = require('fs');

// ===== 加载 .env（仅用于本地开发，生产靠 cron env 注入）=====
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  fs.readFileSync(envPath, 'utf8').split('\n').forEach(line => {
    const t = line.trim();
    if (!t || t.startsWith('#')) return;
    const ei = t.indexOf('=');
    if (ei < 0) return;
    const k = t.slice(0, ei).trim(), v = t.slice(ei + 1).trim();
    if (k && !process.env[k]) process.env[k] = v;
  });
}

// ===== 配置项（全部选填，无默认值）=====
// 任何一项缺失 → 对应模块静默跳过，不 warn，不报错

module.exports = {
  // ===== MiniMax TTS + Chat =====
  MINIMAX_API_KEY:  process.env.MINIMAX_API_KEY  || null,
  MINIMAX_GROUP_ID: process.env.MINIMAX_GROUP_ID || '',
  TTS_MODEL:        process.env.MINIMAX_TTS_MODEL     || 'speech-2.8-hd',
  TTS_SPEED:        parseFloat(process.env.MINIMAX_TTS_SPEED || '1.05'),
  TTS_ACCENT:      process.env.MINIMAX_TTS_ACCENT    || 'English',
  TTS_VOICE_ID:    process.env.MINIMAX_TTS_VOICE_ID  || 'male-qn-qingse',

  // ===== MiniMax ASR =====
  ASR_MODEL: process.env.MINIMAX_ASR_MODEL || 'speech-01-asr',

  // ===== 艾宾浩斯复习 =====
  EBINGHAUS:    [1, 3, 7, 15],
  DAILY_WORD_MAX: parseInt(process.env.DAILY_WORD_MAX || '15'),

  // ===== 多维表格（全部选填，不填则无记忆功能）=====
  BITABLE_APP_TOKEN:      process.env.BITABLE_APP_TOKEN      || null,
  BITABLE_WORDS_TABLE_ID: process.env.BITABLE_WORDS_TABLE_ID || null,
  BITABLE_CHAT_TABLE_ID:  process.env.BITABLE_CHAT_TABLE_ID  || null,

  // ===== 飞书（全部选填，不填则无飞书语音推送）=====
  FEISHU_APP_ID:       process.env.FEISHU_APP_ID       || null,
  FEISHU_APP_SECRET:   process.env.FEISHU_APP_SECRET   || null,
  FEISHU_USER_OPEN_ID: process.env.FEISHU_USER_OPEN_ID || null,
  FEISHU_WEBHOOK:      process.env.FEISHU_WEBHOOK      || '',

  // ===== 本地 TTS 兜底（可选）=====
  PIPER_BIN:   process.env.PIPER_BIN   || null,
  PIPER_MODEL: process.env.PIPER_MODEL || null,

  // ===== 本地 ASR（可选）=====
  SENSE_VOICE_MODEL_DIR: process.env.SENSE_VOICE_MODEL_DIR || null,
};