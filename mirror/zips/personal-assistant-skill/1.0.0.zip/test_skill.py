#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小右助理 - 快速测试脚本
测试整个意图识别 + 功能调用流程
"""

import sys
import os

base_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(base_path, 'src'))

from intent_recognizer import IntentRecognizer
from recommender import RecommendationEngine
from role_based_generator import RoleBasedMessageGenerator
from weight_tracker import WeightTracker
from health_report_generator import HealthReportGenerator
from feishu_pusher import FeishuPusher

print("=" * 60)
print("🤖 小右助理 - 完整功能测试")
print("=" * 60)
print()

# 初始化所有模块
print("🔧 初始化模块...")
recognizer = IntentRecognizer()
engine = RecommendationEngine(base_path)
generator = RoleBasedMessageGenerator(base_path)
tracker = WeightTracker(base_path)
pusher = FeishuPusher(base_path)
print("✅ 所有模块初始化完成！")
print()

# 测试用例
test_cases = [
    "小右，今天吃什么",
    "小右，切换到高冷御姐",
    "小右，给我生成周报",
    "小右，提醒我喝水",
    "小右，看看我的体重",
    "小右",  # 单独唤起
]

print("=" * 60)
print("🧪 开始测试意图识别 + 功能调用")
print("=" * 60)
print()

for i, test_message in enumerate(test_cases, 1):
    print(f"📝 测试 {i}/{len(test_cases)}: {test_message}")
    print("-" * 60)
    
    # 1. 意图识别
    result = recognizer.should_trigger_skill(test_message)
    
    print(f"   🎯 触发：{'✅ 是' if result['should_trigger'] else '❌ 否'}")
    print(f"   📊 置信度：{result['confidence']:.2f}")
    print(f"   🏷️  触发类型：{result['trigger_type']}")
    print(f"   🎭 意图识别：{result['intent']}")
    print(f"   📋 提取指令：{result['extracted_command'] or '无'}")
    print()
    
    # 2. 根据意图执行对应动作
    if result['should_trigger']:
        intent = result['intent']
        
        if intent == 'diet':
            print("   🍽️  执行：生成饮食推荐")
            menu = engine.get_daily_menu(scene='home')
            message = generator.generate_daily_recommendation(
                menu['breakfast'],
                menu['lunch'],
                menu['dinner']
            )
            pusher.push_message(message)
            print("   ✅ 已推送到飞书！")
        
        elif intent == 'role':
            print("   🎭 执行：切换角色")
            print("   ℹ️  （需要解析具体角色名，这里演示跳过）")
        
        elif intent == 'report':
            print("   📊 执行：生成健康报告")
            reporter = HealthReportGenerator(base_path)
            report = reporter.generate_weekly_report()
            pusher.push_message(report)
            print("   ✅ 周报复已推送到飞书！")
        
        elif intent == 'weight':
            print("   ⚖️  执行：查看体重数据")
            latest = tracker.get_latest_weight()
            print(f"   最新体重：{latest.get('weight', 0)} kg")
            print(f"   BMI：{latest.get('bmi', 0):.1f} ({latest.get('bmiStatus', '未知')})")
        
        elif intent == 'water':
            print("   💧 执行：推送喝水提醒")
            message = generator.generate_water_reminder()
            pusher.push_message(message)
            print("   ✅ 喝水提醒已推送到飞书！")
        
        elif intent == 'greeting':
            print("   👋 执行：返回欢迎语")
            welcome = recognizer.get_welcome_message()
            print(f"   欢迎语示例：{welcome[:100]}...")
        
        else:
            print(f"   ℹ️  意图 {intent} 暂未实现自动化测试")
    
    print()

print("=" * 60)
print("✅ 所有测试完成！")
print("=" * 60)
print()
print("💡 现在您可以直接在对话中测试：")
print('   说 "小右，今天吃什么" 试试！')
print('   说 "小右" 查看完整功能列表！')
