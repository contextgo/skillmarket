#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
用已验证成功的方式推送今日饮食推荐
"""

import sys
import os
import json
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from recommender import RecommendationEngine

# 直接复制 feishu_direct_push.py 中成功的推送逻辑
import subprocess

def push_via_stdin(content, user_id):
    """用stdin的方式推送，这是之前成功的方式"""
    try:
        cmd = ['openclaw', 'message', 'send', '--channel', 'feishu', '--to', user_id]
        result = subprocess.run(cmd, input=content.encode('utf-8'), capture_output=True, timeout=30)
        
        if result.returncode == 0:
            print("✅ 推送成功")
            return True
        else:
            print(f"❌ 方式1失败: {result.stderr.decode('utf-8', errors='ignore')}")
            
            # 试试另一种参数
            cmd2 = ['openclaw', 'message', 'send', '--channel', 'feishu', '-t', user_id]
            result2 = subprocess.run(cmd2, input=content.encode('utf-8'), capture_output=True, timeout=30)
            if result2.returncode == 0:
                print("✅ 方式2成功")
                return True
            else:
                print(f"❌ 方式2也失败: {result2.stderr.decode('utf-8', errors='ignore')}")
                return False
    except Exception as e:
        print(f"❌ 异常: {e}")
        return False

def main():
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 获取用户配置
    with open(os.path.join(base_path, 'data', 'config.json'), 'r') as f:
        config = json.load(f)
    
    user_id = config.get('push', {}).get('feishuUserId')
    
    # 获取推荐
    engine = RecommendationEngine(base_path)
    menu_home = engine.get_daily_menu(scene='home')
    menu_out = engine.get_daily_menu(scene='eating_out')
    
    bmi = menu_home.get('bmi', '-')
    bmi_status = menu_home.get('bmi_status', '-')
    
    # 推送内容 - 高冷御姐风格
    message = f"""📋 今日饮食推荐

【健康状态】
BMI: {bmi} ({bmi_status})

【在家做饭推荐】
🌅 早餐: {menu_home['breakfast']['dish']['name']}
   热量: {menu_home['breakfast']['dish']['calories']} 大卡

☀️ 午餐: {menu_home['lunch']['dish']['name']}
   热量: {menu_home['lunch']['dish']['calories']} 大卡

🌙 晚餐: {menu_home['dinner']['dish']['name']}
   热量: {menu_home['dinner']['dish']['calories']} 大卡

【在外就餐推荐】
🌅 早餐: {menu_out['breakfast']['dish']['name']}
   热量: {menu_out['breakfast']['dish']['calories']} 大卡

☀️ 午餐: {menu_out['lunch']['dish']['name']}
   热量: {menu_out['lunch']['dish']['calories']} 大卡

🌙 晚餐: {menu_out['dinner']['dish']['name']}
   热量: {menu_out['dinner']['dish']['calories']} 大卡

---

💡 提醒:
1. 碳水减半，多吃蛋白和蔬菜
2. 一天喝够 2L 水
3. 饭后走 30 分钟
4. 别熬夜

想吃什么直说。
"""
    
    print("正在推送今日饮食推荐...")
    print(f"目标用户: {user_id}")
    print()
    
    success = push_via_stdin(message, user_id)
    
    return 0 if success else 1

if __name__ == '__main__':
    sys.exit(main())
