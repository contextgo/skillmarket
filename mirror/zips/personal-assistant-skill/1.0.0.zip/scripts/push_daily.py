#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 每日推送脚本
生成每日饮食建议并通过飞书推送
支持：纯文本消息、飞书富文本卡片
"""

import sys
import os
import json
import subprocess
from datetime import datetime

# 添加 src 目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from recommender import RecommendationEngine
from role_system import RoleSystem
from card_builder import FeishuCardBuilder

class FeishuPush:
    """飞书推送类 - 封装 OpenClaw message 工具"""
    
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.base_path = base_path
        
        # 加载配置获取飞书用户 ID
        with open(os.path.join(base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        self.feishu_user_id = self.config.get('push', {}).get('feishuUserId')
        self.main_script = os.path.join(base_path, 'main.py')

    def push_text(self, content, title=None):
        """推送纯文本消息"""
        if not self.feishu_user_id:
            print("❌ 未配置飞书用户 ID")
            return False
        
        # 构建完整消息
        full_message = ""
        if title:
            full_message += f"{'='*40}\n"
            full_message += f"{title}\n"
            full_message += f"{'='*40}\n\n"
        
        full_message += content
        
        # 调用 OpenClaw message 工具
        try:
            # 方式1：直接用 subprocess 调用（已验证可以成功推送）
            cmd = ['openclaw', 'message', 'send', '--channel', 'feishu', '--to', self.feishu_user_id]
            
            result = subprocess.run(
                cmd,
                input=full_message.encode('utf-8'),
                capture_output=True,
                timeout=30
            )
            
            if result.returncode == 0:
                print(f"✅ [{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 推送成功")
                return True
            else:
                print(f"❌ 推送失败: {result.stderr.decode('utf-8')}")
                return False
                
        except subprocess.TimeoutExpired:
            print("❌ 推送超时")
            return False
        except Exception as e:
            print(f"❌ 推送出错: {e}")
            return False

    def push_card(self, card_data, title=None):
        """推送飞书卡片消息（简化版，用文本格式模拟卡片）"""
        # 目前 OpenClaw message 工具主要支持文本
        # 我们用结构化文本模拟卡片效果
        
        card_text = self._format_card_as_text(card_data, title)
        return self.push_text(card_text, title)

    def _format_card_as_text(self, card_data, title=None):
        """将卡片数据格式化为结构化文本"""
        lines = []
        
        # 标题
        if card_data.get('header'):
            header_title = card_data['header']['title']['content']
            lines.append(f"🎴 {header_title}")
            lines.append("─" * 40)
            lines.append("")
        
        # 内容模块
        if card_data.get('elements'):
            for element in card_data['elements']:
                if element.get('tag') == 'div' and 'text' in element:
                    # 文本模块
                    text = element['text'].get('content', '')
                    # 简单的 Lark MD 解析
                    text = text.replace('**', '')
                    text = text.replace('\n', '\n  ')
                    lines.append(text)
                
                elif element.get('tag') == 'hr':
                    # 分割线
                    lines.append("")
                    lines.append("─" * 40)
                    lines.append("")
                
                elif element.get('tag') == 'note':
                    # 备注
                    if element.get('elements'):
                        note_text = element['elements'][0].get('content', '')
                        lines.append(f"💡 {note_text}")
                
                elif element.get('tag') == 'action':
                    # 按钮（用文本表示）
                    lines.append("")
                    lines.append("🔘 操作按钮：")
                    for btn in element.get('actions', []):
                        btn_text = btn['text']['content']
                        lines.append(f"   [{btn_text}]")
        
        return "\n".join(lines)


def check_lock(lock_file):
    """检查锁文件，防止重复推送"""
    lock_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'push-status', lock_file)
    
    if os.path.exists(lock_path):
        print(f"⚠️  今日已推送过，跳过 (锁文件: {lock_file})")
        return False
    
    # 创建锁目录
    os.makedirs(os.path.dirname(lock_path), exist_ok=True)
    
    # 创建锁文件
    with open(lock_path, 'w') as f:
        f.write(datetime.now().isoformat())
    
    return True


def generate_daily_content(base_path, scene='home'):
    """生成每日推荐内容"""
    # 初始化推荐引擎和角色系统
    engine = RecommendationEngine(base_path)
    role_system = RoleSystem(base_path)
    
    # 获取当前角色
    with open(os.path.join(base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
        config = json.load(f)
    role_name = config['role']['current']
    
    # 获取推荐
    menu = engine.get_daily_menu(scene=scene)
    
    # 构建卡片
    card = FeishuCardBuilder.build_daily_recommendation_card(menu, role_name, scene)
    
    # 生成纯文本版本
    text_content = role_system.format_daily_recommendation(menu, role_name)
    
    return card, text_content, menu


def main():
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 检查是否初始化
    with open(os.path.join(base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    if not config.get('initialized'):
        print("❌ 私人助理尚未初始化，请先运行: python main.py init")
        return 1
    
    # 测试模式检查
    test_mode = '--test' in sys.argv
    
    if not test_mode:
        # 检查锁，防止重复推送
        today = datetime.now().strftime('%Y-%m-%d')
        lock_file = f'daily-{today}.lock'
        
        if not check_lock(lock_file):
            return 0
    
    # 确定场景（工作日默认在外就餐，周末默认在家做饭）
    weekday = datetime.now().weekday()
    if weekday >= 5:  # 周六周日
        scene = 'home'
    else:
        scene = 'eating_out'
    
    print(f"📋 生成 {scene == 'home' and '在家做饭' or '在外就餐'} 推荐...")
    
    # 生成内容
    card, text_content, menu = generate_daily_content(base_path, scene)
    
    # 测试模式：只打印不发送
    if test_mode:
        print("\n" + "="*50)
        print("📤 【测试模式】每日推荐内容预览")
        print("="*50 + "\n")
        print(text_content)
        print("\n" + "="*50)
        print(f"✅ 测试完成，未实际推送")
        return 0
    
    # 真实推送
    print(f"📤 开始推送到飞书...")
    
    pusher = FeishuPush(base_path)
    
    # 推送卡片形式（文本模拟）
    success = pusher.push_card(card, "每日饮食推荐")
    
    if success:
        # 保存推荐记录
        engine = RecommendationEngine(base_path)
        engine.save_recommendation(menu)
        print(f"✅ 推荐记录已保存")
        return 0
    else:
        # 推送失败，删除锁文件以便重试
        today = datetime.now().strftime('%Y-%m-%d')
        lock_path = os.path.join(base_path, 'data', 'push-status', f'daily-{today}.lock')
        if os.path.exists(lock_path):
            os.remove(lock_path)
        return 1


if __name__ == '__main__':
    sys.exit(main())
