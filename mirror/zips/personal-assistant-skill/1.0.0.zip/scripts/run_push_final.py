#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
最终版统一推送入口 - 专注于高质量文字报告
基于角色人设模板的消息生成，直接调用飞书 API
"""

import sys
import os
import json
import requests
from datetime import datetime

# 添加 src 目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from recommender import RecommendationEngine
from weight_tracker import WeightTracker
from role_based_generator import RoleBasedMessageGenerator
from health_report_generator import HealthReportGenerator


# ===== 飞书 API =====

def get_feishu_token():
    """获取飞书 tenant_access_token"""
    app_id = os.environ.get('FEISHU_APP_ID', 'cli_a742696027c8d010')
    app_secret = os.environ.get('FEISHU_APP_SECRET', 'd6f7bb81dca7896e265ae089adfa4faa')
    
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    payload = {"app_id": app_id, "app_secret": app_secret}
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 0:
                return data.get('tenant_access_token')
    except Exception as e:
        print(f"获取 token 异常: {e}")
    
    return None


def send_feishu_message(token, user_id, content):
    """发送文本消息到飞书"""
    url = "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "receive_id": user_id,
        "msg_type": "text",
        "content": json.dumps({"text": content})
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=15)
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 0:
                return True
    except Exception as e:
        print(f"发送消息异常: {e}")
    
    return False


def get_user_id():
    """获取用户 ID"""
    config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'config.json')
    with open(config_path, 'r') as f:
        config = json.load(f)
    return config.get('push', {}).get('feishuUserId')


# ===== 新版推荐逻辑已集成到 RecommendationEngine 中 =====


# ===== 推送入口 =====

def push_daily():
    """推送每日饮食推荐"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 防重复推送锁
    today = datetime.now().strftime('%Y-%m-%d')
    lock_path = os.path.join(base_path, 'data', 'push-status', f'daily-{today}.lock')
    os.makedirs(os.path.dirname(lock_path), exist_ok=True)
    
    if os.path.exists(lock_path):
        print(f"⚠️  今日已推送过")
        return 0
    
    token = get_feishu_token()
    user_id = get_user_id()
    if not token or not user_id:
        print("❌ 配置错误")
        return 1
    
    # 获取推荐（新版：早餐独立 + 3菜一汤）
    engine = RecommendationEngine(base_path)
    menu = engine.get_daily_menu(scene='home')
    
    # 基于角色生成消息
    generator = RoleBasedMessageGenerator(base_path)
    print(f"当前角色：{generator.current_role}")
    
    message = generator.generate_daily_recommendation(
        menu['breakfast'], 
        menu['lunch'], 
        menu['dinner']
    )
    
    print("正在推送每日推荐...")
    success = send_feishu_message(token, user_id, message)
    
    if success:
        print("✅ 推送成功")
        with open(lock_path, 'w') as f:
            f.write(datetime.now().isoformat())
        return 0
    else:
        print("❌ 推送失败")
        return 1


def push_water():
    """推送喝水提醒"""
    token = get_feishu_token()
    user_id = get_user_id()
    if not token or not user_id:
        return 1
    
    # 基于角色生成喝水提醒
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    generator = RoleBasedMessageGenerator(base_path)
    message = generator.generate_water_reminder()
    
    success = send_feishu_message(token, user_id, message)
    
    if success:
        print(f"✅ 喝水提醒推送成功")
        return 0
    else:
        print("❌ 推送失败")
        return 1


def push_weekly():
    """推送每周健康报告（增强版）"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    token = get_feishu_token()
    user_id = get_user_id()
    if not token or not user_id:
        return 1
    
    # 使用健康报告生成器生成增强版周报
    print("正在生成角色化周报...")
    generator = HealthReportGenerator(base_path)
    report = generator.generate_weekly_report()
    
    print(f"当前角色：{generator.current_role}")
    print("正在推送周报...")
    success = send_feishu_message(token, user_id, report)
    
    if success:
        print("✅ 周报推送成功")
        return 0
    else:
        print("❌ 推送失败")
        return 1


def push_monthly():
    """推送月度健康报告（增强版）"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    token = get_feishu_token()
    user_id = get_user_id()
    if not token or not user_id:
        return 1
    
    # 使用健康报告生成器生成增强版月报
    print("正在生成角色化月报...")
    generator = HealthReportGenerator(base_path)
    report = generator.generate_monthly_report()
    
    print(f"当前角色：{generator.current_role}")
    print("正在推送月报...")
    success = send_feishu_message(token, user_id, report)
    
    if success:
        print("✅ 月报推送成功")
        return 0
    else:
        print("❌ 推送失败")
        return 1


def push_weight_reminder():
    """推送体重记录提醒"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    token = get_feishu_token()
    user_id = get_user_id()
    if not token or not user_id:
        print("❌ 配置错误")
        return 1
    
    # 基于角色生成体重记录提醒消息
    generator = RoleBasedMessageGenerator(base_path)
    message = generator.generate_weight_reminder()
    
    success = send_feishu_message(token, user_id, message)
    
    if success:
        print("✅ 体重提醒推送成功")
        return 0
    else:
        print("❌ 推送失败")
        return 1


# ===== 主入口 =====

def main():
    if len(sys.argv) < 2:
        print("用法: python run_push_final.py [daily|water|weekly|monthly|weight]")
        return 1
    
    action = sys.argv[1]
    
    if action == 'daily':
        return push_daily()
    elif action == 'water':
        return push_water()
    elif action == 'weekly':
        return push_weekly()
    elif action == 'monthly':
        return push_monthly()
    elif action == 'weight':
        return push_weight_reminder()
    else:
        print(f"未知操作: {action}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
