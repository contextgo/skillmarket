#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
推送今日饮食推荐到飞书 - 用已验证成功的方式
"""

import sys
import os
import json
import subprocess
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from recommender import RecommendationEngine

base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 获取用户配置
with open(os.path.join(base_path, 'data', 'config.json'), 'r') as f:
    config = json.load(f)

user_id = config.get('push', {}).get('feishuUserId')

# 获取推荐
engine = RecommendationEngine(base_path)
menu_home = engine.get_daily_menu(scene='home')
menu_out = engine.get_daily_menu(scene='eating_out')

bmi = menu_home.get('bmi', '-')
bmi_status = menu_home.get('bmi_status', '-')

# 推送内容
message = f"""📋 今日饮食推荐

【健康状态】
BMI: {bmi} ({bmi_status})

【在家做饭推荐】
🌅 早餐: {menu_home['breakfast']['dish']['name']}
   热量: {menu_home['breakfast']['dish']['calories']} 大卡

☀️ 午餐: {menu_home['lunch']['dish']['name']}
   热量: {menu_home['lunch']['dish']['calories']} 大卡

🌙 晚餐: {menu_home['dinner']['dish']['name']}
   热量: {menu_home['dinner']['dish']['calories']} 大卡

【在外就餐推荐】
🌅 早餐: {menu_out['breakfast']['dish']['name']}
   热量: {menu_out['breakfast']['dish']['calories']} 大卡

☀️ 午餐: {menu_out['lunch']['dish']['name']}
   热量: {menu_out['lunch']['dish']['calories']} 大卡

🌙 晚餐: {menu_out['dinner']['dish']['name']}
   热量: {menu_out['dinner']['dish']['calories']} 大卡

---

💡 提醒:
1. 碳水减半，多吃蛋白和蔬菜
2. 一天喝够 2L 水
3. 饭后走 30 分钟
4. 别熬夜

想吃什么直说。
"""

# 用之前成功的方式推送
cmd = ['openclaw', 'message', 'send', '--channel', 'feishu', '--to', user_id]

print("正在推送今日饮食推荐...")
result = subprocess.run(cmd, input=message.encode('utf-8'), capture_output=True, timeout=30)

if result.returncode == 0:
    print("✅ 推送成功")
else:
    print(f"❌ 推送失败")
    print(f"stderr: {result.stderr.decode('utf-8', errors='ignore')}")
    print(f"stdout: {result.stdout.decode('utf-8', errors='ignore')}")
