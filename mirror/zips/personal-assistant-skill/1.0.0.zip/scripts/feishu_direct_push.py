#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 飞书直接推送脚本（不依赖 OpenClaw message CLI）
直接调用飞书 API 发送消息
"""

import sys
import os
import json
import requests
import subprocess
from datetime import datetime

class FeishuDirectPush:
    """飞书直接推送类 - 调用飞书 API"""
    
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.base_path = base_path
        
        # 加载配置
        with open(os.path.join(base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        self.feishu_user_id = self.config.get('push', {}).get('feishuUserId')
        
        # 获取飞书 token（通过 openclaw 网关或环境变量）
        self.token = self._get_token()

    def _get_token(self):
        """获取飞书访问 token"""
        # 方式1：尝试从环境变量获取
        if os.environ.get('FEISHU_TOKEN'):
            return os.environ.get('FEISHU_TOKEN')
        
        # 方式2：尝试通过 openclaw 工具获取
        try:
            result = subprocess.run(
                ['openclaw', 'feishu', 'token'],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except:
            pass
        
        # 方式3：如果有 app_id 和 app_secret，直接调用飞书 API
        if os.environ.get('FEISHU_APP_ID') and os.environ.get('FEISHU_APP_SECRET'):
            try:
                url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
                payload = {
                    "app_id": os.environ.get('FEISHU_APP_ID'),
                    "app_secret": os.environ.get('FEISHU_APP_SECRET')
                }
                response = requests.post(url, json=payload, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    return data.get('tenant_access_token')
            except:
                pass
        
        return None

    def push_text(self, content):
        """直接推送文本消息（飞书 API）"""
        if not self.feishu_user_id:
            print("❌ 未配置飞书用户 ID")
            return False
        
        # 如果没有 token，尝试用 openclaw 的 message 工具
        if not self.token:
            print("⚠️  未获取到飞书 token，尝试用 message 工具...")
            return self._push_via_message_tool(content)
        
        # 直接调用飞书 API
        try:
            url = "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id"
            
            headers = {
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "receive_id": self.feishu_user_id,
                "msg_type": "text",
                "content": json.dumps({"text": content})
            }
            
            response = requests.post(url, headers=headers, json=payload, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 0:
                    print(f"✅ [{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 飞书推送成功")
                    return True
                else:
                    print(f"❌ 飞书 API 返回错误: {data.get('msg')}")
                    return False
            else:
                print(f"❌ HTTP 请求失败: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ 推送出错: {e}")
            return False

    def _push_via_message_tool(self, content):
        """通过 openclaw message 工具推送（备用方式）"""
        try:
            # 尝试多种方式调用 message 工具
            ways = [
                # 方式1：直接调用（通过 stdin 输入内容）
                f'echo "{content}" | openclaw message send --channel feishu --to {self.feishu_user_id}',
                # 方式2：用 subprocess 传 stdin
                None,  # 特殊处理
                # 方式3：写入临时文件再发送
                None
            ]
            
            # 测试方式2：subprocess 传 stdin
            import subprocess
            cmd = ['openclaw', 'message', 'send', '--channel', 'feishu', '--to', self.feishu_user_id]
            result = subprocess.run(cmd, input=content.encode('utf-8'), capture_output=True, timeout=30)
            
            if result.returncode == 0:
                print(f"✅ [{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] message 工具推送成功")
                return True
            else:
                print(f"❌ message 工具失败: {result.stderr.decode('utf-8', errors='ignore')}")
                # 尝试另一种参数格式
                cmd2 = ['openclaw', 'message', 'send', '-t', 'feishu', '-d', self.feishu_user_id]
                result2 = subprocess.run(cmd2, input=content.encode('utf-8'), capture_output=True, timeout=30)
                if result2.returncode == 0:
                    print("✅ 第二种参数格式成功！")
                    return True
                else:
                    print(f"❌ 第二种方式也失败: {result2.stderr.decode('utf-8', errors='ignore')}")
                    return False
                    
        except Exception as e:
            print(f"❌ message 工具异常: {e}")
            return False


def test_push():
    """测试推送"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    pusher = FeishuDirectPush(base_path)
    
    test_message = f"""🤖 【私人助理推送测试】
时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

✅ 直接推送脚本测试成功！

📋 定时任务配置：
• 每天 8:00 - 每日饮食推荐
• 每天 9/11/13/15/17/19/21 点 - 喝水提醒
• 每周日 21:00 - 每周健康报告
• 每天 2:00 - 数据同步

🎉 私人助理 SKILL 全部完成！
"""
    
    print("="*60)
    print("📤 开始测试飞书直接推送...")
    print("="*60)
    print(f"\n推送内容:\n{test_message}\n")
    print(f"目标用户: {pusher.feishu_user_id}")
    print(f"Token: {'已获取' if pusher.token else '未获取'}")
    print()
    
    success = pusher.push_text(test_message)
    
    if success:
        print("\n" + "="*60)
        print("✅ 推送测试完成！请检查飞书消息")
        print("="*60)
        return 0
    else:
        print("\n" + "="*60)
        print("❌ 推送失败，请检查配置")
        print("="*60)
        return 1


if __name__ == '__main__':
    sys.exit(test_push())
