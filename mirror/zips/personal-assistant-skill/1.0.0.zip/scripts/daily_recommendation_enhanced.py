#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增强版每日饮食推荐生成器
包含：日历、天气、穿衣建议、BMI评估、详细食谱（食材、做法）
"""

import sys
import os
import json
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from recommender import RecommendationEngine


def get_calendar_info():
    """获取日历信息"""
    now = datetime.now()
    weekday_names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    
    return {
        'date': now.strftime('%Y年%m月%d日'),
        'weekday': weekday_names[now.weekday()],
        'weekday_num': now.weekday(),
        'is_weekend': now.weekday() >= 5
    }


def get_weather_info():
    """获取天气信息（模拟，后续可接入API）"""
    # 模拟北京春季天气
    return {
        'temperature': '15~25°C',
        'condition': '晴转多云',
        'wind': '微风',
        'humidity': '45%',
        'uv_index': '中等'
    }


def get_clothing_suggestion(weather, is_weekend):
    """根据天气和工作日/周末生成穿衣建议"""
    temp_range = weather['temperature']
    
    base_suggestions = [
        "早晚温差大，记得备件薄外套",
        "白天穿长袖衬衫或薄卫衣刚好",
        "建议穿长裤，早晚注意保暖",
    ]
    
    if is_weekend:
        weekend_extra = [
            "周末出门可以穿得休闲点",
            "运动鞋配牛仔裤很舒服",
            "记得带件外套，晚上可能有点凉",
        ]
        return base_suggestions + weekend_extra
    else:
        workday_extra = [
            "上班通勤的话，商务休闲风合适",
            "办公室记得备件开衫",
        ]
        return base_suggestions + workday_extra


def get_bmi_evaluation(bmi, bmi_status):
    """详细的BMI健康评估"""
    evaluation = {
        'status': bmi_status,
        'value': bmi,
        'analysis': [],
        'suggestions': []
    }
    
    if bmi >= 28:  # 肥胖
        evaluation['analysis'] = [
            "体重偏高，需要注意控制饮食热量",
            "建议减少精制碳水和高油食物的摄入",
            "适当增加有氧运动，帮助消耗多余脂肪",
        ]
        evaluation['suggestions'] = [
            "每餐七分饱，细嚼慢咽",
            "多吃蔬菜和蛋白质，增加饱腹感",
            "每天至少喝2000ml水",
            "保证7-8小时睡眠，避免熬夜导致代谢下降",
            "饭后散步30分钟，帮助消化",
        ]
    elif bmi >= 24:  # 偏胖
        evaluation['analysis'] = [
            "体重略高于正常范围，稍加控制即可",
            "注意饮食均衡，避免暴饮暴食",
        ]
        evaluation['suggestions'] = [
            "主食可以换成粗粮，增加饱腹感",
            "每周至少3次运动，每次30分钟以上",
        ]
    else:  # 正常或偏瘦
        evaluation['analysis'] = [
            "体重在正常范围内，继续保持",
            "注意营养均衡，不要刻意节食",
        ]
        evaluation['suggestions'] = [
            "保证蛋白质摄入，维持肌肉量",
            "规律作息，保持良好状态",
        ]
    
    return evaluation


def format_recipe_detail(dish, meal_type):
    """格式化详细菜谱"""
    lines = []
    
    # 菜品基本信息
    lines.append(f"【{meal_type}】{dish['name']}")
    lines.append(f"   热量：约 {dish['calories']} 大卡")
    lines.append(f"   烹饪时间：{dish['cookingTime']} 分钟")
    lines.append(f"   难度：{dish['difficulty']}")
    lines.append(f"   口味：{dish['taste']}")
    lines.append("")
    
    # 食材
    lines.append("   【食材清单】")
    ingredients_str = "、".join(dish['ingredients'])
    lines.append(f"   {ingredients_str}")
    lines.append("")
    
    # 做法步骤
    lines.append("   【做法步骤】")
    for step in dish['steps']:
        lines.append(f"   {step}")
    lines.append("")
    
    return "\n".join(lines)


def generate_enhanced_recommendation():
    """生成增强版每日推荐"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 1. 基础信息
    calendar = get_calendar_info()
    weather = get_weather_info()
    clothing = get_clothing_suggestion(weather, calendar['is_weekend'])
    
    # 2. 读取用户信息
    with open(os.path.join(base_path, 'data', 'user-profile.json'), 'r') as f:
        user_profile = json.load(f)
    
    bmi = user_profile['health']['bmi']
    bmi_status = user_profile['health']['bmiStatus']
    bmi_eval = get_bmi_evaluation(bmi, bmi_status)
    
    # 3. 获取菜谱推荐
    engine = RecommendationEngine(base_path)
    
    # 早餐推荐（偏健康低卡）
    breakfast_options = [d for d in engine.home_cooking_recipes if d['calories'] <= 300]
    if not breakfast_options:
        breakfast_options = engine.home_cooking_recipes
    breakfast = sorted(breakfast_options, key=lambda x: x['calories'])[0]
    
    # 午餐推荐
    lunch_options = [d for d in engine.home_cooking_recipes if 200 <= d['calories'] <= 400]
    if not lunch_options:
        lunch_options = engine.home_cooking_recipes
    lunch = lunch_options[len(lunch_options) // 2]
    
    # 晚餐推荐（偏清淡）
    dinner_options = [d for d in engine.home_cooking_recipes if d['calories'] <= 300]
    if not dinner_options:
        dinner_options = engine.home_cooking_recipes
    dinner = sorted(dinner_options, key=lambda x: x['calories'])[0]
    
    # 4. 构建完整消息（高冷御姐风格）
    message_parts = []
    
    # 头部 - 日历和天气
    message_parts.append(f"📅 {calendar['date']} {calendar['weekday']}")
    message_parts.append("")
    message_parts.append(f"🌤️  今日天气：{weather['condition']}")
    message_parts.append(f"   温度：{weather['temperature']}")
    message_parts.append(f"   湿度：{weather['humidity']}")
    message_parts.append("")
    
    # 穿衣建议
    message_parts.append("👗 穿衣建议：")
    for suggestion in clothing[:3]:
        message_parts.append(f"   • {suggestion}")
    message_parts.append("")
    
    # BMI健康评估
    message_parts.append(f"⚖️  健康状态评估")
    message_parts.append(f"   BMI：{bmi} ({bmi_status})")
    message_parts.append("")
    message_parts.append("   【分析】")
    for analysis in bmi_eval['analysis']:
        message_parts.append(f"   • {analysis}")
    message_parts.append("")
    message_parts.append("   【今日建议】")
    for suggestion in bmi_eval['suggestions'][:5]:
        message_parts.append(f"   • {suggestion}")
    message_parts.append("")
    
    # 分隔线
    message_parts.append("=" * 40)
    message_parts.append("")
    
    # 菜谱推荐 - 在家做饭
    message_parts.append("🍳 今日在家做饭推荐")
    message_parts.append("")
    
    # 早餐
    message_parts.append(format_recipe_detail(breakfast, "早餐"))
    
    # 午餐
    message_parts.append(format_recipe_detail(lunch, "午餐"))
    
    # 晚餐
    message_parts.append(format_recipe_detail(dinner, "晚餐"))
    
    # 分隔线
    message_parts.append("=" * 40)
    message_parts.append("")
    
    # 在外就餐备选
    menu_out = engine.get_daily_menu(scene='eating_out')
    message_parts.append("🍜 在外就餐备选")
    message_parts.append(f"   早餐：{menu_out['breakfast']['dish']['name']} ({menu_out['breakfast']['dish']['calories']} 大卡)")
    message_parts.append(f"   午餐：{menu_out['lunch']['dish']['name']} ({menu_out['lunch']['dish']['calories']} 大卡)")
    message_parts.append(f"   晚餐：{menu_out['dinner']['dish']['name']} ({menu_out['dinner']['dish']['calories']} 大卡)")
    message_parts.append("")
    
    # 今日总结
    total_calories = breakfast['calories'] + lunch['calories'] + dinner['calories']
    message_parts.append(f"📊 今日在家做饭预估总热量：约 {total_calories} 大卡")
    message_parts.append("")
    
    # 高冷御姐风格结尾
    message_parts.append("---")
    message_parts.append("")
    message_parts.append("💡 最后提醒：")
    message_parts.append("   碳水减半，多吃蔬菜。")
    message_parts.append("   喝够水，别熬夜。")
    message_parts.append("")
    message_parts.append("想吃什么说。")
    
    return "\n".join(message_parts)


if __name__ == '__main__':
    print(generate_enhanced_recommendation())
