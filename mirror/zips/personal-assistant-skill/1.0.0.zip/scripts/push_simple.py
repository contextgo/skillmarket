#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
简化版推送脚本 - 直接调用飞书API发送消息
不依赖 openclaw CLI，避免插件加载问题
"""

import sys
import os
import json
import requests
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from recommender import RecommendationEngine


def get_feishu_token():
    """获取飞书tenant_access_token"""
    # 从环境变量或配置中获取
    app_id = os.environ.get('FEISHU_APP_ID', 'cli_a742696027c8d010')
    app_secret = os.environ.get('FEISHU_APP_SECRET', 'd6f7bb81dca7896e265ae089adfa4faa')
    
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    payload = {"app_id": app_id, "app_secret": app_secret}
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 0:
                return data.get('tenant_access_token')
    except Exception as e:
        print(f"获取token失败: {e}")
    
    return None


def send_feishu_message(token, user_id, content):
    """发送文本消息到飞书"""
    url = "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "receive_id": user_id,
        "msg_type": "text",
        "content": json.dumps({"text": content})
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 0:
                return True, "成功"
            else:
                return False, f"API错误: {data.get('msg')}"
        else:
            return False, f"HTTP错误: {response.status_code}"
    except Exception as e:
        return False, f"异常: {e}"


def push_daily_menu():
    """推送今日饮食推荐"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 1. 获取token
    token = get_feishu_token()
    if not token:
        print("❌ 无法获取飞书token")
        return 1
    
    # 2. 获取用户ID
    with open(os.path.join(base_path, 'data', 'config.json'), 'r') as f:
        config = json.load(f)
    user_id = config.get('push', {}).get('feishuUserId')
    if not user_id:
        print("❌ 未配置用户ID")
        return 1
    
    # 3. 生成推荐
    engine = RecommendationEngine(base_path)
    menu = engine.get_daily_menu(scene='home')
    
    bmi = menu.get('bmi', '-')
    bmi_status = menu.get('bmi_status', '-')
    
    # 4. 构建消息（高冷御姐风格）
    message = f"""📋 今日饮食推荐

【健康状态】
BMI: {bmi} ({bmi_status})

【在家做饭推荐】
🌅 早餐: {menu['breakfast']['dish']['name']}
   热量: {menu['breakfast']['dish']['calories']} 大卡

☀️ 午餐: {menu['lunch']['dish']['name']}
   热量: {menu['lunch']['dish']['calories']} 大卡

🌙 晚餐: {menu['dinner']['dish']['name']}
   热量: {menu['dinner']['dish']['calories']} 大卡

---

💡 提醒:
1. 碳水减半，多吃蛋白和蔬菜
2. 一天喝够 2L 水
3. 饭后走 30 分钟
4. 别熬夜

想吃什么直说。
"""
    
    # 5. 发送
    print("正在推送...")
    success, msg = send_feishu_message(token, user_id, message)
    
    if success:
        print(f"✅ 推送成功！请检查飞书")
        return 0
    else:
        print(f"❌ 推送失败: {msg}")
        return 1


if __name__ == '__main__':
    sys.exit(push_daily_menu())
