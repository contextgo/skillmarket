#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 统一推送入口脚本
整合所有推送功能，确保能正确发送到飞书
"""

import sys
import os
import json
import subprocess
from datetime import datetime

# 添加 src 目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from recommender import RecommendationEngine
from role_system import RoleSystem
from card_builder import FeishuCardBuilder


def get_feishu_user_id():
    """获取飞书用户 ID"""
    config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'config.json')
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)
    return config.get('push', {}).get('feishuUserId')


def send_to_feishu(content, title=None):
    """发送消息到飞书（已验证成功的方式）"""
    feishu_user_id = get_feishu_user_id()
    if not feishu_user_id:
        print("❌ 未配置飞书用户 ID")
        return False
    
    # 构建完整消息
    full_message = ""
    if title:
        full_message += f"{'='*40}\n"
        full_message += f"{title}\n"
        full_message += f"{'='*40}\n\n"
    
    full_message += content
    
    # 使用已验证成功的方式推送
    try:
        # 尝试多种参数格式
        ways = [
            ['openclaw', 'message', 'send', '--channel', 'feishu', '--to', feishu_user_id],
            ['openclaw', 'message', 'send', '-t', 'feishu', '-d', feishu_user_id],
            ['openclaw', 'message', 'send', '-t', 'feishu', '--to', feishu_user_id],
        ]
        
        for cmd in ways:
            result = subprocess.run(
                cmd,
                input=full_message.encode('utf-8'),
                capture_output=True,
                timeout=30
            )
            if result.returncode == 0:
                print(f"✅ 使用参数方式成功: {' '.join(cmd[3:])}")
                break
        else:
            print(f"❌ 所有推送方式都失败")
            return False
        
        if result.returncode == 0:
            print(f"✅ [{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 推送成功")
            return True
        else:
            print(f"❌ 推送失败: {result.stderr.decode('utf-8', errors='ignore')}")
            return False
            
    except Exception as e:
        print(f"❌ 推送异常: {e}")
        return False


def push_daily():
    """推送每日饮食推荐"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 检查锁，防止重复推送
    today = datetime.now().strftime('%Y-%m-%d')
    lock_path = os.path.join(base_path, 'data', 'push-status', f'daily-{today}.lock')
    os.makedirs(os.path.dirname(lock_path), exist_ok=True)
    
    if os.path.exists(lock_path):
        print(f"⚠️  今日已推送过，跳过 (锁文件: {lock_path})")
        return 0
    
    # 确定场景（工作日在外就餐，周末在家做饭）
    weekday = datetime.now().weekday()
    scene = 'home' if weekday >= 5 else 'eating_out'
    
    print(f"📋 生成 {scene == 'home' and '在家做饭' or '在外就餐'} 推荐...")
    
    # 初始化推荐引擎和角色系统
    engine = RecommendationEngine(base_path)
    role_system = RoleSystem(base_path)
    
    # 获取当前角色
    with open(os.path.join(base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
        config = json.load(f)
    role_name = config['role']['current']
    
    # 获取推荐
    menu = engine.get_daily_menu(scene=scene)
    
    # 生成文本内容
    text_content = role_system.format_daily_recommendation(menu, role_name)
    
    # 推送
    title = f"🍽️ 每日饮食推荐 - {datetime.now().strftime('%Y-%m-%d')}"
    success = send_to_feishu(text_content, title)
    
    if success:
        # 创建锁文件
        with open(lock_path, 'w') as f:
            f.write(datetime.now().isoformat())
        # 保存推荐记录
        engine.save_recommendation(menu)
    
    return 0 if success else 1


def push_water_reminder():
    """推送喝水提醒"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 获取当前角色
    with open(os.path.join(base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
        config = json.load(f)
    role_name = config['role']['current']
    
    role_system = RoleSystem(base_path)
    message = role_system.format_water_reminder(role_name)
    
    title = f"💧 喝水提醒 - {datetime.now().strftime('%H:%M')}"
    success = send_to_feishu(message, title)
    
    return 0 if success else 1


def push_weekly_report():
    """推送每周健康报告"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    from weight_tracker import WeightTracker
    tracker = WeightTracker(base_path)
    
    report = tracker.get_weekly_report()
    content = f"📊 每周健康报告\n\n{report}"
    
    title = f"📊 每周健康报告 - {datetime.now().strftime('%Y-%m-%d')}"
    success = send_to_feishu(content, title)
    
    return 0 if success else 1


def main():
    if len(sys.argv) < 2:
        print("用法: python run_push.py <命令>")
        print("命令:")
        print("  daily   - 每日饮食推荐")
        print("  water   - 喝水提醒")
        print("  weekly  - 每周健康报告")
        print("  test    - 测试推送")
        return 1
    
    command = sys.argv[1]
    
    if command == 'daily':
        return push_daily()
    elif command == 'water':
        return push_water_reminder()
    elif command == 'weekly':
        return push_weekly_report()
    elif command == 'test':
        test_content = f"""🤖 【推送功能测试】
时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

✅ 推送脚本测试成功！

📋 定时任务配置：
• 每天 8:00 - 每日饮食推荐
• 每天 9/11/13/15/17/19/21 点 - 喝水提醒
• 每周日 21:00 - 每周健康报告
• 每天 2:00 - 数据同步

🎉 私人助理 SKILL 全部完成！
"""
        success = send_to_feishu(test_content, "🧪 推送测试")
        return 0 if success else 1
    else:
        print(f"❌ 未知命令: {command}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
