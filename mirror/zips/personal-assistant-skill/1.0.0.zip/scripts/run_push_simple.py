#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
可靠的统一推送入口 - 直接调用飞书API
不依赖 openclaw CLI，避免插件加载问题
"""

import sys
import os
import json
import requests
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from recommender import RecommendationEngine
from weight_tracker import WeightTracker


# ===== 飞书API基础 =====

def get_feishu_token():
    """获取飞书tenant_access_token"""
    app_id = os.environ.get('FEISHU_APP_ID', 'cli_a742696027c8d010')
    app_secret = os.environ.get('FEISHU_APP_SECRET', 'd6f7bb81dca7896e265ae089adfa4faa')
    
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    payload = {"app_id": app_id, "app_secret": app_secret}
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 0:
                return data.get('tenant_access_token')
    except:
        pass
    return None


def send_feishu_message(token, user_id, content):
    """发送文本消息到飞书"""
    url = "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "receive_id": user_id,
        "msg_type": "text",
        "content": json.dumps({"text": content})
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 0:
                return True
    except:
        pass
    return False


def get_user_id():
    """获取用户ID"""
    config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'config.json')
    with open(config_path, 'r') as f:
        config = json.load(f)
    return config.get('push', {}).get('feishuUserId')


# ===== 推送功能 =====

def push_daily():
    """推送每日饮食推荐"""
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 防重复推送锁
    today = datetime.now().strftime('%Y-%m-%d')
    lock_path = os.path.join(base_path, 'data', 'push-status', f'daily-{today}.lock')
    os.makedirs(os.path.dirname(lock_path), exist_ok=True)
    
    if os.path.exists(lock_path):
        print(f"⚠️  今日已推送过")
        return 0
    
    # 获取token和用户ID
    token = get_feishu_token()
    user_id = get_user_id()
    if not token or not user_id:
        print("❌ 配置错误")
        return 1
    
    # 生成推荐
    engine = RecommendationEngine(base_path)
    menu = engine.get_daily_menu(scene='home')
    
    bmi = menu.get('bmi', '-')
    bmi_status = menu.get('bmi_status', '-')
    
    # 构建消息（高冷御姐风格）
    message = f"""📋 今日饮食推荐

【健康状态】
BMI: {bmi} ({bmi_status})

【在家做饭推荐】
🌅 早餐: {menu['breakfast']['dish']['name']}
   热量: {menu['breakfast']['dish']['calories']} 大卡

☀️ 午餐: {menu['lunch']['dish']['name']}
   热量: {menu['lunch']['dish']['calories']} 大卡

🌙 晚餐: {menu['dinner']['dish']['name']}
   热量: {menu['dinner']['dish']['calories']} 大卡

---

💡 提醒:
1. 碳水减半，多吃蛋白和蔬菜
2. 一天喝够 2L 水
3. 饭后走 30 分钟
4. 别熬夜

想吃什么直说。
"""
    
    # 发送
    success = send_feishu_message(token, user_id, message)
    
    if success:
        print("✅ 每日推荐推送成功")
        # 创建锁文件
        with open(lock_path, 'w') as f:
            f.write(datetime.now().isoformat())
        return 0
    else:
        print("❌ 推送失败")
        return 1


def push_water():
    """推送喝水提醒"""
    token = get_feishu_token()
    user_id = get_user_id()
    if not token or not user_id:
        return 1
    
    message = """💧 喝水提醒

该喝水了。喝一杯水，保持清醒。
"""
    
    success = send_feishu_message(token, user_id, message)
    
    if success:
        print("✅ 喝水提醒推送成功")
        return 0
    else:
        print("❌ 推送失败")
        return 1


def push_weekly():
    """推送每周健康报告"""
    base_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    
    token = get_feishu_token()
    user_id = get_user_id()
    if not token or not user_id:
        return 1
    
    # 生成周报
    tracker = WeightTracker(base_path)
    report = tracker.generate_weekly_report()
    
    success = send_feishu_message(token, user_id, report)
    
    if success:
        print("✅ 周报推送成功")
        return 0
    else:
        print("❌ 推送失败")
        return 1


# ===== 主入口 =====

def main():
    if len(sys.argv) < 2:
        print("用法: python run_push_simple.py [daily|water|weekly]")
        return 1
    
    action = sys.argv[1]
    
    if action == 'daily':
        return push_daily()
    elif action == 'water':
        return push_water()
    elif action == 'weekly':
        return push_weekly()
    else:
        print(f"未知操作: {action}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
