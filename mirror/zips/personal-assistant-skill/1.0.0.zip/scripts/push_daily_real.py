#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 真实每日饮食推荐推送
"""

import sys
import os
import json
import subprocess
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from recommender import RecommendationEngine

def push_to_feishu(content, user_id):
    """直接推送消息到飞书"""
    try:
        cmd = ['openclaw', 'message', 'send', '--channel', 'feishu', '--to', user_id]
        result = subprocess.run(
            cmd,
            input=content.encode('utf-8'),
            capture_output=True,
            timeout=30
        )
        return result.returncode == 0
    except Exception as e:
        print(f"推送失败: {e}")
        return False

def main():
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 获取用户配置
    with open(os.path.join(base_path, 'data', 'config.json'), 'r') as f:
        config = json.load(f)
    
    user_id = config.get('push', {}).get('feishuUserId')
    if not user_id:
        print("未配置飞书用户ID")
        return 1
    
    # 获取推荐
    engine = RecommendationEngine(base_path)
    
    # 同时获取在家和在外的推荐
    menu_home = engine.get_daily_menu(scene='home')
    menu_out = engine.get_daily_menu(scene='eating_out')
    
    # 获取BMI信息
    bmi = menu_home.get('bmi', '-')
    bmi_status = menu_home.get('bmi_status', '-')
    
    # 构建高冷御姐风格的消息
    message = f"""📋 今日饮食推荐

【健康状态】
BMI: {bmi} ({bmi_status})

【在家做饭推荐】
🌅 早餐: {menu_home['breakfast']['dish']['name']}
   热量: {menu_home['breakfast']['dish']['calories']} 大卡

☀️ 午餐: {menu_home['lunch']['dish']['name']}
   热量: {menu_home['lunch']['dish']['calories']} 大卡

🌙 晚餐: {menu_home['dinner']['dish']['name']}
   热量: {menu_home['dinner']['dish']['calories']} 大卡

【在外就餐推荐】
🌅 早餐: {menu_out['breakfast']['dish']['name']}
   热量: {menu_out['breakfast']['dish']['calories']} 大卡

☀️ 午餐: {menu_out['lunch']['dish']['name']}
   热量: {menu_out['lunch']['dish']['calories']} 大卡

🌙 晚餐: {menu_out['dinner']['dish']['name']}
   热量: {menu_out['dinner']['dish']['calories']} 大卡

---

💡 提醒:
1. 碳水减半，多吃蛋白和蔬菜
2. 一天喝够 2L 水
3. 饭后走 30 分钟
4. 别熬夜

想吃什么直说。
"""
    
    print("正在推送今日饮食推荐...")
    success = push_to_feishu(message, user_id)
    
    if success:
        print("✅ 推送成功")
        return 0
    else:
        print("❌ 推送失败")
        return 1

if __name__ == '__main__':
    sys.exit(main())
