#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 喝水提醒推送脚本
"""

import sys
import os
import json
import subprocess
from datetime import datetime

# 添加 src 目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from role_system import RoleSystem
from card_builder import FeishuCardBuilder

class FeishuPush:
    """飞书推送类"""
    
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.base_path = base_path
        
        # 加载配置获取飞书用户 ID
        with open(os.path.join(base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        self.feishu_user_id = self.config.get('push', {}).get('feishuUserId')

    def push_text(self, content, title=None):
        """推送纯文本消息"""
        if not self.feishu_user_id:
            print("❌ 未配置飞书用户 ID")
            return False
        
        # 构建完整消息
        full_message = ""
        if title:
            full_message += f"{'='*40}\n"
            full_message += f"{title}\n"
            full_message += f"{'='*40}\n\n"
        
        full_message += content
        
        # 调用 OpenClaw message 工具
        try:
            # 用 -t 或 --target 参数
            cmd = f'openclaw message send -t feishu --to "{self.feishu_user_id}"'
            
            result = subprocess.run(
                cmd,
                input=full_message.encode('utf-8'),
                shell=True,
                capture_output=True,
                timeout=30
            )
            
            if result.returncode == 0:
                print(f"✅ [{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 喝水提醒已发送")
                return True
            else:
                print(f"❌ 推送失败: {result.stderr.decode('utf-8')}")
                return False
                
        except subprocess.TimeoutExpired:
            print("❌ 推送超时")
            return False
        except Exception as e:
            print(f"❌ 推送出错: {e}")
            return False

    def push_card(self, card_data, title=None):
        """推送卡片消息（文本格式模拟）"""
        # 提取卡片内容
        if card_data.get('header'):
            header_title = card_data['header']['title']['content']
            message = f"💧 {header_title}\n\n"
        
        if card_data.get('elements'):
            for element in card_data['elements']:
                if element.get('tag') == 'div' and 'text' in element:
                    text = element['text'].get('content', '')
                    text = text.replace('**', '')
                    message += f"{text}\n"
        
        return self.push_text(message, title)


def main():
    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 检查是否初始化
    with open(os.path.join(base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    if not config.get('initialized'):
        print("❌ 私人助理尚未初始化")
        return 1
    
    # 测试模式检查
    test_mode = '--test' in sys.argv
    
    # 获取当前角色
    role_name = config['role']['current']
    role_system = RoleSystem(base_path)
    
    # 生成喝水提醒卡片
    card = FeishuCardBuilder.build_water_reminder_card(role_name)
    
    if test_mode:
        # 测试模式：只打印不发送
        print("\n" + "="*50)
        print(f"💧 【测试模式】喝水提醒预览 (角色: {role_name})")
        print("="*50 + "\n")
        
        # 从卡片中提取内容
        if card.get('header'):
            print(f"标题: {card['header']['title']['content']}")
        
        if card.get('elements'):
            for element in card['elements']:
                if element.get('tag') == 'div' and 'text' in element:
                    text = element['text'].get('content', '')
                    print(f"\n内容:\n{text}")
        
        print("\n" + "="*50)
        print(f"✅ 测试完成，未实际推送")
        return 0
    
    # 真实推送
    print(f"💧 发送喝水提醒 (角色: {role_name})...")
    
    pusher = FeishuPush(base_path)
    success = pusher.push_card(card, "喝水提醒")
    
    return 0 if success else 1


if __name__ == '__main__':
    sys.exit(main())
