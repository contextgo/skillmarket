#!/bin/bash
# 私人助理 - 快速启动脚本

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    🤖 私人助理 Personal Assistant             ║"
echo "║           智能饮食推荐与健康管理系统 - v1.0.0                 ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 未找到 python3，请先安装 Python"
    exit 1
fi

# 显示菜单
echo "📋 快速开始菜单"
echo "══════════════════════════════════════════════════════════════"
echo ""
echo "  🟢 快速入门"
echo "     1. 系统诊断 - 检查所有功能是否正常"
echo "     2. 查看版本 - 显示版本信息"
echo "     3. 初始化向导 - 配置个人信息"
echo ""
echo "  🍽️  饮食推荐"
echo "     4. 在家做饭推荐"
echo "     5. 在外就餐推荐"
echo ""
echo "  ⚖️  体重管理"
echo "     6. 记录当前体重"
echo "     7. 查看体重历史"
echo "     8. 生成周报"
echo ""
echo "  ⏰ 定时任务"
echo "     9. 查看定时任务"
echo "    10. 一键添加所有定时任务"
echo "    11. 停止所有定时任务"
echo ""
echo "  🎭 角色设置"
echo "    12. 查看所有角色"
echo "    13. 切换角色"
echo ""
echo "  🚀 高级功能"
echo "    14. 创建多维表格数据看板"
echo "    15. 同步所有数据到表格"
echo ""
echo "  ❓ 帮助"
echo "    16. 查看所有命令"
echo "    0. 退出"
echo ""
echo "══════════════════════════════════════════════════════════════"
read -p "请选择操作 [0-16]: " choice

case $choice in
    1)
        python main.py diagnose --all
        ;;
    2)
        python main.py version
        ;;
    3)
        python main.py init
        ;;
    4)
        python main.py recommend --scene home
        ;;
    5)
        python main.py recommend --scene eating_out
        ;;
    6)
        read -p "请输入体重 (kg): " weight
        python main.py weight $weight
        ;;
    7)
        python main.py weight --history
        ;;
    8)
        python main.py weight --weekly
        ;;
    9)
        python main.py cron --list
        ;;
    10)
        python main.py cron --add all
        ;;
    11)
        python main.py cron --remove all
        ;;
    12)
        python main.py role --list
        ;;
    13)
        echo ""
        echo "可用角色:"
        echo "  • 可爱女友"
        echo "  • 高冷御姐"
        echo "  • 专业助手"
        echo "  • 邻家妹妹"
        echo "  • 佛系养生"
        echo ""
        read -p "请输入角色名称: " role
        python main.py role --set "$role"
        ;;
    14)
        python main.py bitable --create
        ;;
    15)
        python main.py bitable --sync-all
        ;;
    16)
        python main.py --help
        ;;
    0)
        echo ""
        echo "👋 再见！私人助理随时为你服务~"
        echo ""
        exit 0
        ;;
    *)
        echo ""
        echo "❌ 无效的选择，请重新运行脚本"
        exit 1
        ;;
esac
