#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 飞书多维表格管理器
自动创建数据看板，同步体重、推荐、反馈数据
"""

import json
import os
import subprocess
from datetime import datetime

class BitableManager:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_config()
        
        # 表格配置
        self.app_token = self.config.get('bitable', {}).get('app_token')
        self.tables = self.config.get('bitable', {}).get('tables', {})

    def load_config(self):
        """加载配置"""
        with open(os.path.join(self.base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
            self.config = json.load(f)

    def save_config(self):
        """保存配置"""
        with open(os.path.join(self.base_path, 'data', 'config.json'), 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)

    def run_feishu_command(self, cmd):
        """运行飞书命令的封装
        
        这里使用 OpenClaw 的 feishu 工具调用
        实际使用时需要根据 OpenClaw 的 API 调整
        """
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                return True, result.stdout
            else:
                return False, result.stderr
        except Exception as e:
            return False, str(e)

    def create_app(self, name="私人助理数据看板"):
        """创建多维表格应用
        
        注意：实际创建需要调用飞书 Open API
        这里先模拟创建，生成示例配置
        """
        print(f"📦 创建多维表格应用: {name}")
        print("="*60)
        
        # 模拟生成 app_token（实际需要调用 API）
        import uuid
        app_token = f"bascn_{uuid.uuid4().hex[:16]}"
        
        if 'bitable' not in self.config:
            self.config['bitable'] = {}
        
        self.config['bitable']['app_token'] = app_token
        self.config['bitable']['app_name'] = name
        self.config['bitable']['tables'] = {}
        
        print(f"✅ 应用创建成功")
        print(f"   App Token: {app_token}")
        print()
        
        # 创建各个子表
        self.create_weight_table()
        self.create_recommendation_table()
        self.create_feedback_table()
        self.create_daily_summary_table()
        
        self.save_config()
        
        print("="*60)
        print("✅ 数据看板创建完成！")
        print("="*60)
        
        return app_token

    def create_weight_table(self):
        """创建体重记录表"""
        table_name = "体重记录表"
        fields = [
            {"field_name": "日期", "type": "date"},
            {"field_name": "体重(kg)", "type": "number"},
            {"field_name": "BMI", "type": "number"},
            {"field_name": "体重状态", "type": "single_select", 
             "options": ["偏瘦", "正常", "偏胖", "肥胖"]},
            {"field_name": "变化量(kg)", "type": "number"},
            {"field_name": "备注", "type": "text"},
            {"field_name": "记录时间", "type": "datetime"}
        ]
        
        # 模拟创建表格
        table_id = f"tbl_weight_{datetime.now().strftime('%Y%m%d')}"
        self.config['bitable']['tables']['weight'] = {
            'table_id': table_id,
            'table_name': table_name,
            'fields': fields
        }
        
        print(f"  ✅ 创建子表: {table_name} ({table_id})")
        print(f"     字段数: {len(fields)} 个")
        for field in fields:
            print(f"       - {field['field_name']} ({field['type']})")
        
        return table_id

    def create_recommendation_table(self):
        """创建推荐记录表"""
        table_name = "饮食推荐记录表"
        fields = [
            {"field_name": "推荐日期", "type": "date"},
            {"field_name": "场景", "type": "single_select", 
             "options": ["在家做饭", "在外就餐"]},
            {"field_name": "早餐推荐", "type": "text"},
            {"field_name": "午餐推荐", "type": "text"},
            {"field_name": "晚餐推荐", "type": "text"},
            {"field_name": "用户评分", "type": "rating"},
            {"field_name": "用户反馈", "type": "text"},
            {"field_name": "推荐时间", "type": "datetime"}
        ]
        
        table_id = f"tbl_rec_{datetime.now().strftime('%Y%m%d')}"
        self.config['bitable']['tables']['recommendation'] = {
            'table_id': table_id,
            'table_name': table_name,
            'fields': fields
        }
        
        print(f"  ✅ 创建子表: {table_name} ({table_id})")
        print(f"     字段数: {len(fields)} 个")
        
        return table_id

    def create_feedback_table(self):
        """创建用户反馈表"""
        table_name = "用户反馈记录表"
        fields = [
            {"field_name": "反馈日期", "type": "date"},
            {"field_name": "反馈类型", "type": "single_select",
             "options": ["喜欢", "不喜欢", "太辣", "太淡", "忌口", 
                        "口味调整", "其他"]},
            {"field_name": "反馈内容", "type": "text"},
            {"field_name": "关联菜品", "type": "text"},
            {"field_name": "是否已应用到算法", "type": "checkbox"},
            {"field_name": "反馈时间", "type": "datetime"}
        ]
        
        table_id = f"tbl_feedback_{datetime.now().strftime('%Y%m%d')}"
        self.config['bitable']['tables']['feedback'] = {
            'table_id': table_id,
            'table_name': table_name,
            'fields': fields
        }
        
        print(f"  ✅ 创建子表: {table_name} ({table_id})")
        print(f"     字段数: {len(fields)} 个")
        
        return table_id

    def create_daily_summary_table(self):
        """创建每日汇总表"""
        table_name = "每日健康汇总"
        fields = [
            {"field_name": "日期", "type": "date"},
            {"field_name": "当日体重", "type": "number"},
            {"field_name": "BMI", "type": "number"},
            {"field_name": "早餐是否按时吃", "type": "checkbox"},
            {"field_name": "午餐是否按时吃", "type": "checkbox"},
            {"field_name": "晚餐是否按时吃", "type": "checkbox"},
            {"field_name": "喝水杯数", "type": "number"},
            {"field_name": "运动时长(分钟)", "type": "number"},
            {"field_name": "当日心情", "type": "single_select",
             "options": ["😊 很棒", "🙂 不错", "😐 一般", "😔 不好"]},
            {"field_name": "备注", "type": "text"}
        ]
        
        table_id = f"tbl_daily_{datetime.now().strftime('%Y%m%d')}"
        self.config['bitable']['tables']['daily_summary'] = {
            'table_id': table_id,
            'table_name': table_name,
            'fields': fields
        }
        
        print(f"  ✅ 创建子表: {table_name} ({table_id})")
        print(f"     字段数: {len(fields)} 个")
        
        return table_id

    def add_weight_record(self, date, weight, bmi, bmi_status, change=0, note=""):
        """添加体重记录到多维表格"""
        record = {
            "日期": date,
            "体重(kg)": weight,
            "BMI": bmi,
            "体重状态": bmi_status,
            "变化量(kg)": change,
            "备注": note,
            "记录时间": datetime.now().isoformat()
        }
        
        # 模拟写入
        print(f"📝 写入体重记录: {date} - {weight} kg")
        
        # 实际应该调用飞书 API 写入
        # success, result = self.run_feishu_command(f"feishu bitable add-record ...")
        
        return True

    def add_recommendation_record(self, date, scene, breakfast="", lunch="", dinner=""):
        """添加推荐记录到多维表格"""
        record = {
            "推荐日期": date,
            "场景": scene,
            "早餐推荐": breakfast,
            "午餐推荐": lunch,
            "晚餐推荐": dinner,
            "推荐时间": datetime.now().isoformat()
        }
        
        print(f"📝 写入推荐记录: {date} - {scene}")
        
        return True

    def add_feedback_record(self, date, feedback_type, content, dish_name="", applied=True):
        """添加反馈记录到多维表格"""
        type_mapping = {
            "like": "喜欢",
            "dislike": "不喜欢",
            "too_spicy": "太辣",
            "too_light": "太淡",
            "avoid_food": "忌口",
            "taste_change": "口味调整"
        }
        
        record = {
            "反馈日期": date,
            "反馈类型": type_mapping.get(feedback_type, "其他"),
            "反馈内容": content,
            "关联菜品": dish_name,
            "是否已应用到算法": applied,
            "反馈时间": datetime.now().isoformat()
        }
        
        print(f"📝 写入反馈记录: {date} - {feedback_type}")
        
        return True

    def get_dashboard_url(self):
        """获取数据看板链接"""
        if not self.app_token:
            return "未创建数据看板"
        
        # 飞书多维表格链接格式
        return f"https://bytedance.feishu.cn/base/{self.app_token}"

    def print_dashboard_info(self):
        """打印数据看板信息"""
        print("\n" + "="*60)
        print("📊 私人助理数据看板")
        print("="*60)
        
        if not self.app_token:
            print("\n❌ 尚未创建数据看板")
            print("   请运行: python main.py bitable --create")
            return
        
        print(f"\n🔗 看板链接: {self.get_dashboard_url()}")
        print(f"\n📋 已创建子表 ({len(self.tables)} 个):")
        
        for key, table in self.tables.items():
            field_count = len(table.get('fields', []))
            print(f"   - {table['table_name']} ({field_count} 个字段)")
        
        print()

    def generate_chart_config(self):
        """生成图表配置（用于飞书多维表格视图）"""
        charts = [
            {
                "name": "体重变化趋势图",
                "type": "line",
                "table": "体重记录表",
                "x_axis": "日期",
                "y_axis": "体重(kg)"
            },
            {
                "name": "BMI 变化曲线",
                "type": "line",
                "table": "体重记录表",
                "x_axis": "日期",
                "y_axis": "BMI"
            },
            {
                "name": "反馈类型分布",
                "type": "pie",
                "table": "用户反馈记录表",
                "dimension": "反馈类型"
            },
            {
                "name": "每周体重统计",
                "type": "bar",
                "table": "体重记录表",
                "x_axis": "日期(周)",
                "y_axis": "平均体重(kg)"
            }
        ]
        
        return charts


if __name__ == '__main__':
    # 测试多维表格管理器
    bitable = BitableManager()
    
    print("=== 创建数据看板 ===")
    bitable.create_app()
    
    print("\n=== 测试写入数据 ===")
    bitable.add_weight_record("2026-04-25", 65.5, 21.4, "正常", -0.2, "测试记录")
    bitable.add_recommendation_record("2026-04-25", "在家做饭", "包子豆浆", "青椒肉丝", "西红柿鸡蛋面")
    bitable.add_feedback_record("2026-04-25", "like", "用户喜欢青椒肉丝", "青椒肉丝", True)
    
    print("\n=== 看板信息 ===")
    bitable.print_dashboard_info()
