#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 智能推荐引擎（升级版）
- 早餐独立：外带食品，包子馒头豆浆面包牛奶手抓饼等
- 午餐/晚餐：3 菜一汤配置（1 荤 + 1 素 + 1 半荤半素 + 汤）
"""

import json
import random
import os
from datetime import datetime, timedelta

class RecommendationEngine:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_data()

    def load_data(self):
        """加载所有数据"""
        # 加载用户配置
        with open(os.path.join(self.base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        # 加载用户画像
        with open(os.path.join(self.base_path, 'data', 'user-profile.json'), 'r', encoding='utf-8') as f:
            self.user_profile = json.load(f)
        
        # 加载反馈记录
        with open(os.path.join(self.base_path, 'data', 'feedback-records.json'), 'r', encoding='utf-8') as f:
            self.feedback_records = json.load(f)
        
        # 加载推荐历史
        with open(os.path.join(self.base_path, 'data', 'recommendation-history.json'), 'r', encoding='utf-8') as f:
            self.recommendation_history = json.load(f)
        
        # 加载菜谱库 - 新版分类
        with open(os.path.join(self.base_path, 'recipes', 'breakfast.json'), 'r', encoding='utf-8') as f:
            self.breakfast_recipes = json.load(f)  # 早餐
        
        with open(os.path.join(self.base_path, 'recipes', 'home-cooking.json'), 'r', encoding='utf-8') as f:
            all_dishes = json.load(f)
            # 按类型分类
            self.meat_dishes = [d for d in all_dishes if d.get('type') == '荤菜']  # 荤菜
            self.veg_dishes = [d for d in all_dishes if d.get('type') == '素菜']   # 素菜
            self.mixed_dishes = [d for d in all_dishes if d.get('type') == '半荤半素']  # 半荤半素
            self.soup_dishes = [d for d in all_dishes if d.get('type') == '汤']     # 汤
            self.home_cooking_recipes = all_dishes  # 保留原接口
        
        with open(os.path.join(self.base_path, 'recipes', 'eating-out.json'), 'r', encoding='utf-8') as f:
            self.eating_out_recipes = json.load(f)

    def calculate_bmi(self):
        """计算 BMI"""
        if not self.user_profile['basicInfo']['height'] or not self.user_profile['basicInfo']['weight']:
            return None
        
        height = self.user_profile['basicInfo']['height'] / 100  # 转换为米
        weight = self.user_profile['basicInfo']['weight']
        bmi = weight / (height * height)
        return round(bmi, 1)

    def get_bmi_status(self, bmi):
        """获取 BMI 状态（中国标准）"""
        if bmi < 18.5:
            return "偏瘦"
        elif 18.5 <= bmi < 24:
            return "正常"
        elif 24 <= bmi < 28:
            return "偏胖"
        else:
            return "肥胖"

    def calculate_dish_weight(self, dish, bmi_status, is_eating_out=False):
        """计算菜品的推荐权重"""
        weight = dish['baseWeight']
        
        # 1. BMI 健康因子调整
        if bmi_status == "肥胖":
            # 肥胖用户，高热量菜权重降低
            if dish.get('calories', 300) > 400:
                weight *= 0.5
            # 低卡菜权重提升
            if dish.get('calories', 300) < 200:
                weight *= 1.3
        elif bmi_status == "偏胖":
            if dish.get('calories', 300) > 400:
                weight *= 0.7
        elif bmi_status == "偏瘦":
            # 偏瘦用户，高热量菜权重提升
            if dish.get('calories', 300) > 400:
                weight *= 1.2

        # 2. 忌口过滤
        avoid_foods = self.user_profile['diet'].get('avoidFoods', [])
        allergies = self.user_profile['health'].get('allergies', [])
        all_avoid = avoid_foods + allergies
        
        if 'ingredients' in dish:
            for ingredient in dish['ingredients']:
                if any(avoid in ingredient for avoid in all_avoid):
                    return 0  # 直接排除
        
        # 3. 健康状态匹配
        if bmi_status in dish.get('unsuitableFor', []):
            weight *= 0.5

        # 4. 历史反馈调整
        dish_feedbacks = [f for f in self.feedback_records if f.get('dishId') == dish['id']]
        for feedback in dish_feedbacks:
            feedback_days = (datetime.now() - datetime.fromisoformat(feedback['timestamp'])).days
            decay_days = self.config['recommendation']['feedbackDecayDays']['dish']
            
            # 反馈衰减，时间越久影响越小
            decay_factor = max(0, 1 - feedback_days / decay_days)
            
            if feedback.get('type') == 'like':
                weight *= 1 + 0.5 * decay_factor
            elif feedback.get('type') == 'dislike':
                weight *= 1 - 0.5 * decay_factor

        # 5. 近期推荐频率惩罚（避免重复推荐）
        recent_recommendations = self.get_recent_recommendations(days=7)
        recommend_count = recent_recommendations.count(dish['name'])
        if recommend_count >= 2:
            weight *= 0.5  # 7天内推荐过2次以上，权重减半
        elif recommend_count >= 1:
            weight *= 0.8

        # 6. 随机探索因子，避免总是推荐同样的菜
        diversity_factor = self.config['recommendation']['diversityFactor']
        random_factor = 0.9 + random.random() * diversity_factor * 2
        weight *= random_factor

        return weight

    def get_recent_recommendations(self, days=7):
        """获取近期推荐的菜品"""
        cutoff = datetime.now() - timedelta(days=days)
        recent_dishes = []
        
        for record in self.recommendation_history:
            record_time = datetime.fromisoformat(record['timestamp'])
            if record_time >= cutoff:
                if 'breakfast' in record:
                    recent_dishes.append(record['breakfast'].get('dish', ''))
                if 'lunch' in record:
                    # 午餐可能有多个菜
                    if isinstance(record['lunch'], list):
                        for dish in record['lunch']:
                            recent_dishes.append(dish.get('dish', ''))
                    else:
                        recent_dishes.append(record['lunch'].get('dish', ''))
                if 'dinner' in record:
                    if isinstance(record['dinner'], list):
                        for dish in record['dinner']:
                            recent_dishes.append(dish.get('dish', ''))
                    else:
                        recent_dishes.append(record['dinner'].get('dish', ''))
        
        return recent_dishes

    # ===== 早餐推荐（独立模块） =====
    
    def get_breakfast_recommendation(self):
        """获取早餐推荐（从外带早餐列表中随机选择）"""
        bmi = self.calculate_bmi()
        bmi_status = self.get_bmi_status(bmi)
        
        # 根据 BMI 过滤早餐
        candidates = self.breakfast_recipes.copy()
        
        # 简单的健康调整
        if bmi_status in ["肥胖", "偏胖"]:
            # 体重偏高，优先低卡早餐
            low_cal = [b for b in candidates if b.get('calories', 500) <= 400]
            if low_cal:
                candidates = low_cal
        
        # 避免近期重复
        recent_dishes = self.get_recent_recommendations(days=3)
        candidates = [b for b in candidates if b['name'] not in recent_dishes]
        
        if not candidates:
            candidates = self.breakfast_recipes.copy()
        
        # 随机选择
        return random.choice(candidates)

    # ===== 3 菜一汤组合推荐 =====
    
    def get_three_dishes_one_soup(self):
        """获取 3 菜一汤组合：1 荤 + 1 素 + 1 半荤半素 + 1 汤"""
        bmi = self.calculate_bmi()
        bmi_status = self.get_bmi_status(bmi)
        
        # 分别从各类中选菜
        meat_dish = self._select_dish_from_category(self.meat_dishes, bmi_status)
        veg_dish = self._select_dish_from_category(self.veg_dishes, bmi_status)
        mixed_dish = self._select_dish_from_category(self.mixed_dishes, bmi_status)
        soup_dish = self._select_dish_from_category(self.soup_dishes, bmi_status)
        
        # 确保都有值，如果某类没有，从其他类别补充
        if not meat_dish and self.mixed_dishes:
            meat_dish = self._select_dish_from_category(self.mixed_dishes, bmi_status)
        if not veg_dish and self.mixed_dishes:
            veg_dish = self._select_dish_from_category(self.mixed_dishes, bmi_status)
        if not mixed_dish and self.meat_dishes:
            mixed_dish = self._select_dish_from_category(self.meat_dishes, bmi_status)
        if not soup_dish:
            # 如果没有汤，用一个汤菜代替
            all_dishes = self.home_cooking_recipes
            soup_dish = self._select_dish_from_category(all_dishes, bmi_status)
        
        return {
            'meat': meat_dish,       # 荤菜
            'vegetable': veg_dish,    # 素菜
            'mixed': mixed_dish,      # 半荤半素
            'soup': soup_dish,        # 汤
            'total_calories': (meat_dish.get('calories', 0) if meat_dish else 0) + 
                              (veg_dish.get('calories', 0) if veg_dish else 0) +
                              (mixed_dish.get('calories', 0) if mixed_dish else 0) +
                              (soup_dish.get('calories', 0) if soup_dish else 0)
        }

    def _select_dish_from_category(self, dish_list, bmi_status):
        """从指定类别中选择菜品"""
        if not dish_list:
            return None
        
        recent_dishes = self.get_recent_recommendations(days=7)
        
        # 计算权重
        weighted_dishes = []
        for dish in dish_list:
            if dish['name'] in recent_dishes:
                continue  # 最近推荐过的跳过
            
            weight = self.calculate_dish_weight(dish, bmi_status)
            if weight > 0:
                weighted_dishes.append((dish, weight))
        
        if not weighted_dishes:
            # 如果都被过滤了，直接选一个
            return dish_list[0]
        
        # 按权重排序，返回权重最高的
        weighted_dishes.sort(key=lambda x: x[1], reverse=True)
        return weighted_dishes[0][0]

    # ===== 对外接口 =====
    
    def get_daily_menu(self, scene='home'):
        """获取一日三餐推荐菜单
        
        Args:
            scene: 'home' (在家做饭) or 'eating_out' (外食)
        """
        bmi = self.calculate_bmi()
        bmi_status = self.get_bmi_status(bmi)
        
        # 早餐：独立推荐
        breakfast = self.get_breakfast_recommendation()
        
        if scene == 'home':
            # 在家做饭：午餐和晚餐都是 3 菜一汤
            lunch = self.get_three_dishes_one_soup()
            
            # 晚餐和午餐不要重复
            lunch_meat_name = lunch['meat'].get('name', '') if lunch.get('meat') else ''
            lunch_veg_name = lunch['vegetable'].get('name', '') if lunch.get('vegetable') else ''
            lunch_mixed_name = lunch['mixed'].get('name', '') if lunch.get('mixed') else ''
            lunch_soup_name = lunch['soup'].get('name', '') if lunch.get('soup') else ''
            
            # 多次尝试获取不重复的晚餐
            for _ in range(10):
                dinner = self.get_three_dishes_one_soup()
                dinner_meat_name = dinner['meat'].get('name', '') if dinner.get('meat') else ''
                dinner_veg_name = dinner['vegetable'].get('name', '') if dinner.get('vegetable') else ''
                dinner_mixed_name = dinner['mixed'].get('name', '') if dinner.get('mixed') else ''
                dinner_soup_name = dinner['soup'].get('name', '') if dinner.get('soup') else ''
                
                # 检查是否有重复
                meat_dup = dinner_meat_name and dinner_meat_name == lunch_meat_name
                veg_dup = dinner_veg_name and dinner_veg_name == lunch_veg_name
                mixed_dup = dinner_mixed_name and dinner_mixed_name == lunch_mixed_name
                soup_dup = dinner_soup_name and dinner_soup_name == lunch_soup_name
                
                if not (meat_dup or veg_dup or mixed_dup or soup_dup):
                    break  # 找到不重复的，退出循环
        else:
            # 外食模式：从外食列表中选
            lunch = self._select_from_list(self.eating_out_recipes, bmi_status)
            dinner = self._select_from_list(self.eating_out_recipes, bmi_status)
        
        # 记录推荐历史
        history_record = {
            'date': datetime.now().strftime('%Y-%m-%d'),
            'timestamp': datetime.now().isoformat(),
            'scene': scene,
            'breakfast': {'dish': breakfast['name']},
            'lunch': {'dish': lunch, 'scene': scene},
            'dinner': {'dish': dinner, 'scene': scene}
        }
        self.recommendation_history.append(history_record)
        self._save_recommendation_history()
        
        return {
            'breakfast': breakfast,
            'lunch': lunch,
            'dinner': dinner,
            'bmi': bmi,
            'bmi_status': bmi_status,
            'cloth_tip': self._get_cloth_tip(),
            'weather_tip': self._get_weather_tip()
        }

    def _select_from_list(self, dish_list, bmi_status):
        """从列表中选菜"""
        recent_dishes = self.get_recent_recommendations(days=7)
        
        weighted_dishes = []
        for dish in dish_list:
            if dish['name'] in recent_dishes:
                continue
            
            weight = self.calculate_dish_weight(dish, bmi_status)
            if weight > 0:
                weighted_dishes.append((dish, weight))
        
        if not weighted_dishes:
            return dish_list[0]
        
        weighted_dishes.sort(key=lambda x: x[1], reverse=True)
        return weighted_dishes[0][0]

    def _save_recommendation_history(self):
        """保存推荐历史"""
        # 只保留最近 90 天
        cutoff = datetime.now() - timedelta(days=90)
        filtered = [r for r in self.recommendation_history 
                   if datetime.fromisoformat(r['timestamp']) >= cutoff]
        
        with open(os.path.join(self.base_path, 'data', 'recommendation-history.json'), 
                  'w', encoding='utf-8') as f:
            json.dump(filtered, f, ensure_ascii=False, indent=2)

    def get_recommendations(self, scene='home', count=3):
        """获取推荐菜品（保留旧接口，兼容）"""
        bmi = self.calculate_bmi()
        bmi_status = self.get_bmi_status(bmi)
        
        dish_list = self.home_cooking_recipes if scene == 'home' else self.eating_out_recipes
        
        weighted_dishes = []
        for dish in dish_list:
            weight = self.calculate_dish_weight(dish, bmi_status)
            if weight > 0:
                weighted_dishes.append((dish, weight))
        
        weighted_dishes.sort(key=lambda x: x[1], reverse=True)
        
        return [dish for dish, weight in weighted_dishes[:count]]

    def _get_cloth_tip(self):
        """穿衣建议"""
        # 简单版本，后续可以对接天气 API
        return "今日天气适宜，建议穿薄外套或长袖衬衫。"

    def _get_weather_tip(self):
        """天气建议"""
        return "天气不错，适合出门散步运动 30 分钟哦~"

    def get_cloth_recommendation(self, temperature=None, season=None):
        """穿衣建议（保留旧接口）"""
        return self._get_cloth_tip()


if __name__ == '__main__':
    engine = RecommendationEngine()
    
    print("=" * 60)
    print("测试新版推荐引擎 - 早餐独立 + 3菜一汤")
    print("=" * 60)
    print()
    
    menu = engine.get_daily_menu(scene='home')
    
    print("🍳 早餐推荐：")
    print(f"  {menu['breakfast']['name']}")
    print(f"  热量：{menu['breakfast']['calories']} 卡路里")
    print(f"  说明：{menu['breakfast']['description']}")
    print()
    
    print("🍱 午餐推荐（3 菜一汤）：")
    lunch = menu['lunch']
    print(f"  荤菜：{lunch['meat']['name']} ({lunch['meat']['calories']} 卡)")
    print(f"  素菜：{lunch['vegetable']['name']} ({lunch['vegetable']['calories']} 卡)")
    print(f"  半荤半素：{lunch['mixed']['name']} ({lunch['mixed']['calories']} 卡)")
    print(f"  汤：{lunch['soup']['name']} ({lunch['soup']['calories']} 卡)")
    print(f"  总热量：{lunch['total_calories']} 卡路里")
    print()
    
    print("🍽️ 晚餐推荐（3 菜一汤）：")
    dinner = menu['dinner']
    print(f"  荤菜：{dinner['meat']['name']} ({dinner['meat']['calories']} 卡)")
    print(f"  素菜：{dinner['vegetable']['name']} ({dinner['vegetable']['calories']} 卡)")
    print(f"  半荤半素：{dinner['mixed']['name']} ({dinner['mixed']['calories']} 卡)")
    print(f"  汤：{dinner['soup']['name']} ({dinner['soup']['calories']} 卡)")
    print(f"  总热量：{dinner['total_calories']} 卡路里")
    print()
    
    print("=" * 60)
    print("✅ 新版推荐引擎测试完成！")
    print("=" * 60)
