#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 初始化向导
交互式收集用户信息
"""

import json
import os
from datetime import datetime

class InitWizard:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_data()
        self.user_data = self._get_empty_profile()

    def load_data(self):
        """加载现有数据"""
        with open(os.path.join(self.base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        with open(os.path.join(self.base_path, 'data', 'user-profile.json'), 'r', encoding='utf-8') as f:
            self.existing_profile = json.load(f)
        
        self.is_initialized = self.config.get('initialized', False)

    def _get_empty_profile(self):
        """获取空的用户档案模板"""
        return {
            "basicInfo": {
                "height": None,
                "weight": None,
                "age": None,
                "gender": None,
                "birthday": None
            },
            "health": {
                "bmi": None,
                "bmiStatus": None,
                "chronicDiseases": [],
                "allergies": [],
                "notes": ""
            },
            "diet": {
                "tastePreference": "medium",
                "avoidFoods": [],
                "cookingFrequency": "sometimes"
            },
            "lifestyle": {
                "sleepTime": "23:00",
                "wakeTime": "07:00",
                "exerciseFrequency": "sometimes",
                "smoking": False,
                "drinking": False
            },
            "work": {
                "occupation": "",
                "overtimeFrequency": "sometimes",
                "commute": ""
            },
            "createdAt": None,
            "updatedAt": None
        }

    def calculate_bmi(self, height, weight):
        """计算 BMI"""
        if height and weight:
            height_m = height / 100
            bmi = weight / (height_m * height_m)
            return round(bmi, 1)
        return None

    def get_bmi_status(self, bmi):
        """获取 BMI 状态"""
        if bmi < 18.5:
            return "偏瘦"
        elif 18.5 <= bmi < 24:
            return "正常"
        elif 24 <= bmi < 28:
            return "偏胖"
        else:
            return "肥胖"

    def ask_question(self, question, validator=None, default=None):
        """询问问题并验证答案"""
        print(f"\n{question}")
        if default:
            print(f"(默认: {default})")
        
        while True:
            answer = input("请输入: ").strip()
            
            if not answer and default:
                return default
            
            if validator:
                try:
                    return validator(answer)
                except ValueError as e:
                    print(f"输入有误: {e}，请重新输入")
            else:
                return answer

    def step1_basic_info(self):
        """第一步：基本信息收集"""
        print("\n" + "="*50)
        print("📝 第一步：基本信息收集")
        print("="*50)

        # 身高
        def validate_height(h):
            try:
                h_num = int(h.replace('cm', ''))
                if 100 <= h_num <= 250:
                    return h_num
                else:
                    raise ValueError("身高应该在 100-250cm 之间")
            except ValueError:
                raise ValueError("请输入有效的数字，例如: 175")

        self.user_data['basicInfo']['height'] = self.ask_question(
            "请问你的身高是多少？(单位: cm)",
            validator=validate_height
        )

        # 体重
        def validate_weight(w):
            try:
                w_num = int(w.replace('kg', ''))
                if 30 <= w_num <= 200:
                    return w_num
                else:
                    raise ValueError("体重应该在 30-200kg 之间")
            except ValueError:
                raise ValueError("请输入有效的数字，例如: 65")

        self.user_data['basicInfo']['weight'] = self.ask_question(
            "请问你的体重是多少？(单位: kg)",
            validator=validate_weight
        )

        # 计算 BMI
        bmi = self.calculate_bmi(
            self.user_data['basicInfo']['height'],
            self.user_data['basicInfo']['weight']
        )
        self.user_data['health']['bmi'] = bmi
        self.user_data['health']['bmiStatus'] = self.get_bmi_status(bmi)

        print(f"\n✅ 你的 BMI 是: {bmi} ({self.user_data['health']['bmiStatus']})")

        # 年龄
        def validate_age(a):
            try:
                a_num = int(a)
                if 10 <= a_num <= 120:
                    return a_num
                else:
                    raise ValueError("年龄应该在 10-120 之间")
            except ValueError:
                raise ValueError("请输入有效的数字，例如: 28")

        self.user_data['basicInfo']['age'] = self.ask_question(
            "请问你的年龄是多少？",
            validator=validate_age
        )

        # 性别
        print("\n请选择性别:")
        print("1. 男")
        print("2. 女")
        print("3. 其他/不愿透露")
        
        def validate_gender(g):
            if g in ['1', '2', '3']:
                mapping = {'1': '男', '2': '女', '3': '其他'}
                return mapping[g]
            raise ValueError("请选择 1、2 或 3")

        self.user_data['basicInfo']['gender'] = self.ask_question(
            "请选择性别 (输入数字)",
            validator=validate_gender
        )

    def step2_health_info(self):
        """第二步：健康信息收集"""
        print("\n" + "="*50)
        print("🏥 第二步：健康信息收集")
        print("="*50)

        # 慢性疾病
        print("\n有什么慢性疾病需要注意的吗？")
        print("（没有的话直接回车，多个疾病用逗号分隔）")
        diseases = input("请输入: ").strip()
        if diseases:
            self.user_data['health']['chronicDiseases'] = [d.strip() for d in diseases.split('，')]

        # 过敏食物
        print("\n有什么食物过敏吗？")
        print("（没有的话直接回车，多个过敏用逗号分隔）")
        allergies = input("请输入: ").strip()
        if allergies:
            self.user_data['health']['allergies'] = [a.strip() for a in allergies.split('，')]

        # 其他健康注意事项
        print("\n还有其他需要注意的健康问题吗？")
        notes = input("请输入（可选，直接回车跳过）: ").strip()
        if notes:
            self.user_data['health']['notes'] = notes

    def step3_diet_preference(self):
        """第三步：饮食偏好收集"""
        print("\n" + "="*50)
        print("🍽️ 第三步：饮食偏好收集")
        print("="*50)

        # 口味偏好
        print("\n请选择你的口味偏好：")
        print("1. 清淡")
        print("2. 适中")
        print("3. 偏重")
        print("4. 超辣")
        
        def validate_taste(t):
            if t in ['1', '2', '3', '4']:
                mapping = {'1': 'light', '2': 'medium', '3': 'heavy', '4': 'spicy'}
                return mapping[t]
            raise ValueError("请选择 1-4")

        self.user_data['diet']['tastePreference'] = self.ask_question(
            "请选择口味 (输入数字)",
            validator=validate_taste,
            default="2"
        )

        # 忌口食物
        print("\n有什么忌口不吃的食物吗？")
        print("（没有的话直接回车，多个用逗号分隔）")
        avoid = input("请输入: ").strip()
        if avoid:
            self.user_data['diet']['avoidFoods'] = [a.strip() for a in avoid.split('，')]

        # 做饭频率
        print("\n你平时在家做饭的频率是？")
        print("1. 经常（几乎每天）")
        print("2. 有时（每周几次）")
        print("3. 偶尔（每月几次）")
        print("4. 几乎不做")
        
        def validate_cooking(c):
            if c in ['1', '2', '3', '4']:
                mapping = {'1': 'often', '2': 'sometimes', '3': 'rarely', '4': 'never'}
                return mapping[c]
            raise ValueError("请选择 1-4")

        self.user_data['diet']['cookingFrequency'] = self.ask_question(
            "请选择做饭频率 (输入数字)",
            validator=validate_cooking,
            default="2"
        )

    def step4_system_config(self):
        """第四步：系统配置"""
        print("\n" + "="*50)
        print("⚙️ 第四步：系统配置")
        print("="*50)

        # 推送目标 - 这里可以从消息上下文获取，但在命令行模式下需要手动输入
        print("\n飞书用户 ID 配置：")
        print("（这是消息推送给你的必要信息）")
        feishu_id = input("请输入你的飞书 Open ID: ").strip()
        if feishu_id:
            self.config['push']['feishuUserId'] = feishu_id

        # 选择角色
        print("\n请选择你的助女人设：")
        roles = ["可爱女友", "高冷御姐", "专业助手", "邻家妹妹", "佛系养生"]
        for i, role in enumerate(roles, 1):
            print(f"{i}. {role}")
        
        def validate_role(r):
            try:
                r_num = int(r)
                if 1 <= r_num <= len(roles):
                    return roles[r_num - 1]
                raise ValueError(f"请选择 1-{len(roles)}")
            except ValueError:
                raise ValueError(f"请选择 1-{len(roles)} 的数字")

        self.config['role']['current'] = self.ask_question(
            "请选择角色 (输入数字)",
            validator=validate_role,
            default="1"
        )

        print(f"\n✅ 已选择角色：{self.config['role']['current']}")

    def step5_confirm_and_save(self):
        """第五步：确认并保存"""
        print("\n" + "="*50)
        print("📋 信息确认")
        print("="*50)

        print("\n【基本信息】")
        print(f"  身高：{self.user_data['basicInfo']['height']} cm")
        print(f"  体重：{self.user_data['basicInfo']['weight']} kg")
        print(f"  BMI：{self.user_data['health']['bmi']} ({self.user_data['health']['bmiStatus']})")
        print(f"  年龄：{self.user_data['basicInfo']['age']} 岁")
        print(f"  性别：{self.user_data['basicInfo']['gender']}")

        print("\n【健康信息】")
        print(f"  慢性疾病：{', '.join(self.user_data['health']['chronicDiseases']) if self.user_data['health']['chronicDiseases'] else '无'}")
        print(f"  食物过敏：{', '.join(self.user_data['health']['allergies']) if self.user_data['health']['allergies'] else '无'}")
        print(f"  其他注意：{self.user_data['health']['notes'] or '无'}")

        print("\n【饮食偏好】")
        taste_map = {'light': '清淡', 'medium': '适中', 'heavy': '偏重', 'spicy': '超辣'}
        print(f"  口味偏好：{taste_map.get(self.user_data['diet']['tastePreference'], '适中')}")
        print(f"  忌口食物：{', '.join(self.user_data['diet']['avoidFoods']) if self.user_data['diet']['avoidFoods'] else '无'}")
        
        cooking_map = {'often': '经常', 'sometimes': '有时', 'rarely': '偶尔', 'never': '几乎不做'}
        print(f"  做饭频率：{cooking_map.get(self.user_data['diet']['cookingFrequency'], '有时')}")

        print("\n【系统配置】")
        print(f"  飞书推送 ID：{self.config['push'].get('feishuUserId', '未配置')}")
        print(f"  助手角色：{self.config['role']['current']}")

        print("\n以上信息是否正确？")
        confirm = input("请输入 'y' 确认，或其他任意键修改: ").strip().lower()
        
        if confirm == 'y':
            self.save()
            print("\n✅ 信息已保存！")
            print("\n🎉 私人助理初始化完成！")
            print("\n你现在可以：")
            print("  - 每天早上会自动推送饮食建议")
            print("  - 随时输入反馈，调整推荐")
            print("  - 切换不同的助手角色体验")
            return True
        else:
            print("\n❌ 已取消保存")
            return False

    def save(self):
        """保存配置和用户数据"""
        now = datetime.now().isoformat()
        
        # 更新用户档案
        self.user_data['createdAt'] = now
        self.user_data['updatedAt'] = now
        
        with open(os.path.join(self.base_path, 'data', 'user-profile.json'), 'w', encoding='utf-8') as f:
            json.dump(self.user_data, f, ensure_ascii=False, indent=2)
        
        # 更新配置
        self.config['initialized'] = True
        self.config['initializedAt'] = now
        
        with open(os.path.join(self.base_path, 'data', 'config.json'), 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)

    def run(self):
        """运行初始化向导"""
        if self.is_initialized:
            print("⚠️  私人助理已经初始化过了！")
            print("如需重新初始化，请删除 data/config.json 中的 initialized 字段")
            return False

        print("🎉 欢迎使用私人助理！")
        print("我将通过几个简单的问题，收集你的个人信息，为你提供个性化的饮食建议和健康提醒。")
        print("随时可以按 Ctrl+C 退出，已输入的信息不会保存。")

        try:
            self.step1_basic_info()
            self.step2_health_info()
            self.step3_diet_preference()
            self.step4_system_config()
            
            success = self.step5_confirm_and_save()
            return success
            
        except KeyboardInterrupt:
            print("\n\n❌ 已取消初始化")
            return False


if __name__ == '__main__':
    wizard = InitWizard()
    wizard.run()
