#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 飞书卡片构建器
生成精美的交互式消息卡片
"""

import json
from datetime import datetime

class FeishuCardBuilder:
    """飞书卡片构建器"""
    
    @staticmethod
    def build_daily_recommendation_card(menu, role_name, scene):
        """构建每日推荐卡片
        
        Args:
            menu: 推荐菜单数据
            role_name: 角色名称
            scene: 场景（在家做饭/在外就餐）
        """
        # 角色对应的问候语和配色
        role_configs = {
            "可爱女友": {
                "greeting": "亲爱的~ 早上好！💕",
                "color": "#FF6B9D",
                "subtitle": "今天也要好好吃饭哦~"
            },
            "高冷御姐": {
                "greeting": "早安。",
                "color": "#6366F1",
                "subtitle": "今天的饮食建议。"
            },
            "专业助手": {
                "greeting": "📅 每日饮食推荐",
                "color": "#10B981",
                "subtitle": f"BMI {menu.get('bmi', '-')} ({menu.get('bmi_status', '-')})"
            },
            "邻家妹妹": {
                "greeting": "哥哥/姐姐早上好呀！☀️",
                "color": "#FBBF24",
                "subtitle": "今天也要元气满满哦~"
            },
            "佛系养生": {
                "greeting": "施主，早安。🍵",
                "color": "#8B5CF6",
                "subtitle": "饮食有节，起居有常。"
            }
        }
        
        config = role_configs.get(role_name, role_configs["专业助手"])
        
        # 构建卡片
        card = {
            "config": {
                "wide_screen_mode": True
            },
            "header": {
                "title": {
                    "tag": "plain_text",
                    "content": config["greeting"]
                },
                "template": config["color"].lstrip("#")
            },
            "elements": []
        }
        
        # 副标题
        card["elements"].append({
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": f"**{config['subtitle']}**"
            }
        })
        
        # 场景标签
        card["elements"].append({
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": f"🍽️ 今日场景：**{scene}**\n"
            }
        })
        
        # 分割线
        card["elements"].append({"tag": "hr"})
        
        # 菜品推荐
        dishes = []
        if menu.get('breakfast'):
            dishes.append(("🌅 早餐", menu['breakfast']['dish']))
        if menu.get('lunch'):
            dishes.append(("☀️ 午餐", menu['lunch']['dish']))
        if menu.get('dinner'):
            dishes.append(("🌙 晚餐", menu['dinner']['dish']))
        
        for label, dish in dishes:
            dish_name = dish.get('name', '')
            calories = dish.get('calories', '')
            tags = "、".join(dish.get('tags', []))
            
            content = f"**{label}：{dish_name}**\n"
            if calories:
                content += f"热量：约 {calories} 大卡\n"
            if tags:
                content += f"标签：{tags}\n"
            
            card["elements"].append({
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": content
                }
            })
        
        # 分割线
        card["elements"].append({"tag": "hr"})
        
        # 健康小贴士
        health_tip = FeishuCardBuilder._get_health_tip(menu.get('bmi_status', ''))
        card["elements"].append({
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": f"💡 **健康小贴士**\n{health_tip}"
            }
        })
        
        # 分割线
        card["elements"].append({"tag": "hr"})
        
        # 反馈按钮区域
        card["elements"].append({
            "tag": "action",
            "actions": [
                {
                    "tag": "button",
                    "text": {
                        "tag": "plain_text",
                        "content": "👍 推荐很赞"
                    },
                    "type": "primary",
                    "value": {
                        "action": "feedback_like"
                    }
                },
                {
                    "tag": "button",
                    "text": {
                        "tag": "plain_text",
                        "content": "👎 不太喜欢"
                    },
                    "type": "default",
                    "value": {
                        "action": "feedback_dislike"
                    }
                },
                {
                    "tag": "button",
                    "text": {
                        "tag": "plain_text",
                        "content": "🔄 换一批推荐"
                    },
                    "type": "default",
                    "value": {
                        "action": "refresh_recommendation"
                    }
                }
            ]
        })
        
        # 底部备注
        card["elements"].append({
            "tag": "note",
            "elements": [
                {
                    "tag": "plain_text",
                    "content": f"📝 你的反馈会让推荐越来越准确哦~ | {datetime.now().strftime('%Y-%m-%d')}"
                }
            ]
        })
        
        return card

    @staticmethod
    def build_weight_card(record, trend=None):
        """构建体重记录卡片"""
        bmi_status = record.get('bmiStatus', '-')
        bmi = record.get('bmi', '-')
        weight = record.get('weight', '-')
        date = record.get('date', datetime.now().strftime('%Y-%m-%d'))
        
        # BMI 状态颜色
        status_colors = {
            "偏瘦": "#FBBF24",
            "正常": "#10B981",
            "偏胖": "#F59E0B",
            "肥胖": "#EF4444"
        }
        color = status_colors.get(bmi_status, "#9CA3AF")
        
        card = {
            "config": {
                "wide_screen_mode": True
            },
            "header": {
                "title": {
                    "tag": "plain_text",
                    "content": f"⚖️ 体重记录 - {date}"
                },
                "template": color.lstrip("#")
            },
            "elements": [
                {
                    "tag": "div",
                    "fields": [
                        {
                            "is_short": True,
                            "text": {
                                "tag": "lark_md",
                                "content": f"**体重**\n{weight} kg"
                            }
                        },
                        {
                            "is_short": True,
                            "text": {
                                "tag": "lark_md",
                                "content": f"**BMI**\n{bmi}"
                            }
                        },
                        {
                            "is_short": True,
                            "text": {
                                "tag": "lark_md",
                                "content": f"**状态**\n{bmi_status}"
                            }
                        }
                    ]
                }
            ]
        }
        
        # 如果有趋势数据
        if trend:
            change = trend.get('change', 0)
            change_symbol = "↑" if change > 0 else "↓" if change < 0 else "→"
            change_color = "#EF4444" if change > 0.3 else "#10B981" if change < -0.3 else "#F59E0B"
            
            card["elements"].append({"tag": "hr"})
            card["elements"].append({
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": f"**📈 近30天趋势**\n"
                               f"起始体重：{trend.get('start_weight')} kg\n"
                               f"结束体重：{trend.get('end_weight')} kg\n"
                               f"变化量：<font color='{change_color}'>{change_symbol} {abs(change)} kg</font> ({trend.get('trend', '-')})"
                }
            })
        
        # 健康建议
        health_tip = FeishuCardBuilder._get_weight_health_tip(bmi_status)
        card["elements"].append({"tag": "hr"})
        card["elements"].append({
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": f"💡 **健康建议**\n{health_tip}"
            }
        })
        
        return card

    @staticmethod
    def build_weekly_report_card(report_data):
        """构建周报卡片"""
        card = {
            "config": {
                "wide_screen_mode": True
            },
            "header": {
                "title": {
                    "tag": "plain_text",
                    "content": "📊 每周健康报告"
                },
                "template": "10B981"
            },
            "elements": [
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": f"**统计周期**：{report_data.get('start_date', '-')} ~ {report_data.get('end_date', '-')}"
                    }
                },
                {"tag": "hr"},
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": FeishuCardBuilder._format_weekly_content(report_data)
                    }
                },
                {"tag": "hr"},
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": "💪 **下周目标建议**\n"
                                   "- 继续保持规律作息\n"
                                   "- 每天至少喝 8 杯水\n"
                                   "- 坚持记录体重和饮食"
                    }
                }
            ]
        }
        
        return card

    @staticmethod
    def build_feedback_confirm_card(feedback_type, content):
        """构建反馈确认卡片"""
        type_text = {
            "like": "👍 已记录你喜欢这个推荐",
            "dislike": "👎 已记录你不太喜欢这个推荐",
            "refresh": "🔄 正在为你重新生成推荐..."
        }
        
        card = {
            "config": {
                "wide_screen_mode": True
            },
            "header": {
                "title": {
                    "tag": "plain_text",
                    "content": "✅ 反馈已收到"
                },
                "template": "10B981"
            },
            "elements": [
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": type_text.get(feedback_type, "感谢你的反馈！")
                    }
                },
                {"tag": "hr"},
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": f"**反馈内容**：{content}\n\n"
                                   "你的反馈会帮助我更好地学习你的喜好，"
                                   "以后的推荐会越来越准确哦~ 🎯"
                    }
                }
            ]
        }
        
        return card

    @staticmethod
    def build_water_reminder_card(role_name="可爱女友"):
        """构建喝水提醒卡片"""
        role_templates = {
            "可爱女友": {
                "title": "💧 喝水时间到啦~",
                "content": "亲爱的，记得喝杯水休息一下哦！\n"
                           "多喝水对皮肤好，还能促进新陈代谢呢~ 💕"
            },
            "高冷御姐": {
                "title": "💧 喝水提醒",
                "content": "该喝水了。\n保持充足水分摄入。"
            },
            "专业助手": {
                "title": "💧 定时喝水提醒",
                "content": "根据健康专家建议，每 2 小时补充一次水分。\n"
                           "建议饮水量：200-300 ml。"
            },
            "邻家妹妹": {
                "title": "💧 哥哥/姐姐该喝水啦~",
                "content": "工作学习再忙也要记得喝水哦！\n"
                           "喝杯水，休息一下吧~ 😊"
            },
            "佛系养生": {
                "title": "🍵 施主，喝口水吧",
                "content": "上善若水，水善利万物而不争。\n"
                           "喝杯水，静心养性。"
            }
        }
        
        template = role_templates.get(role_name, role_templates["专业助手"])
        
        card = {
            "config": {
                "wide_screen_mode": True
            },
            "header": {
                "title": {
                    "tag": "plain_text",
                    "content": template["title"]
                },
                "template": "3B82F6"
            },
            "elements": [
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": template["content"]
                    }
                }
            ]
        }
        
        return card

    @staticmethod
    def _get_health_tip(bmi_status):
        """根据 BMI 获取健康小贴士"""
        tips = {
            "偏瘦": "可以适当增加优质蛋白质的摄入，配合适量运动增加肌肉量哦~",
            "正常": "你的体重很标准！继续保持均衡饮食和规律运动就好~",
            "偏胖": "建议适当控制油脂和糖分的摄入，多吃蔬菜，配合适量有氧运动。",
            "肥胖": "建议咨询专业医生或营养师，制定科学的减重计划，加油！"
        }
        return tips.get(bmi_status, "保持均衡饮食，规律作息，健康生活每一天！")

    @staticmethod
    def _get_weight_health_tip(bmi_status):
        """根据 BMI 获取体重健康建议"""
        tips = {
            "偏瘦": "你的体重偏轻，建议：\n"
                   "- 增加优质蛋白质摄入（鸡蛋、牛奶、瘦肉等）\n"
                   "- 适当进行力量训练增加肌肉\n"
                   "- 保持规律作息，避免过度劳累",
            "正常": "你的体重在正常范围，很棒！建议：\n"
                   "- 继续保持当前的饮食习惯\n"
                   "- 坚持每周至少 3 次运动\n"
                   "- 保持充足睡眠",
            "偏胖": "你的体重略微偏高，建议：\n"
                   "- 减少高油高糖食物摄入\n"
                   "- 增加有氧运动（快走、慢跑、游泳等）\n"
                   "- 晚餐适量减少主食摄入",
            "肥胖": "你的体重需要重点关注，建议：\n"
                   "- 咨询专业医生或营养师\n"
                   "- 制定科学的减重计划（每周减重不超过 0.5-1 kg）\n"
                   "- 增加日常活动量，避免久坐"
        }
        return tips.get(bmi_status, "保持健康的生活方式，定期监测体重变化。")

    @staticmethod
    def _format_weekly_content(report_data):
        """格式化周报内容"""
        change = report_data.get('change', 0)
        change_symbol = "↑" if change > 0 else "↓" if change < 0 else "→"
        
        content = f"""
**📈 体重变化**
起始体重：{report_data.get('start_weight', '-')} kg
结束体重：{report_data.get('end_weight', '-')} kg
变化量：{change_symbol} {abs(change)} kg
整体趋势：{report_data.get('trend', '-')}

**📊 本周数据统计**
共记录 {report_data.get('record_count', 0)} 次体重
日均变化：{report_data.get('daily_change', 0):+.2f} kg
当前 BMI：{report_data.get('bmi', '-')} ({report_data.get('bmi_status', '-')})
"""
        return content.strip()

    @staticmethod
    def card_to_json(card):
        """将卡片转换为 JSON 字符串"""
        return json.dumps(card, ensure_ascii=False, indent=2)


if __name__ == '__main__':
    # 测试卡片构建
    builder = FeishuCardBuilder()
    
    # 测试每日推荐卡片
    print("=== 每日推荐卡片 ===")
    test_menu = {
        'bmi': 21.4,
        'bmi_status': '正常',
        'breakfast': {'dish': {'name': '包子豆浆', 'calories': 350, 'tags': ['早餐', '常见']}},
        'lunch': {'dish': {'name': '青椒肉丝', 'calories': 280, 'tags': ['下饭', '经典']}},
        'dinner': {'dish': {'name': '西红柿鸡蛋面', 'calories': 300, 'tags': ['家常', '简单']}}
    }
    
    card = builder.build_daily_recommendation_card(test_menu, "可爱女友", "在家做饭")
    print(builder.card_to_json(card))
    print()
    
    # 测试体重卡片
    print("=== 体重记录卡片 ===")
    test_record = {
        'date': '2026-04-25',
        'weight': 65.5,
        'bmi': 21.4,
        'bmiStatus': '正常'
    }
    test_trend = {
        'start_weight': 66.0,
        'end_weight': 65.5,
        'change': -0.5,
        'trend': '稳定'
    }
    weight_card = builder.build_weight_card(test_record, test_trend)
    print(builder.card_to_json(weight_card))
    print()
    
    # 测试喝水提醒卡片
    print("=== 喝水提醒卡片 ===")
    water_card = builder.build_water_reminder_card("可爱女友")
    print(builder.card_to_json(water_card))
