#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 反馈系统
收集用户反馈并自动调整推荐算法
"""

import json
import os
from datetime import datetime, timedelta

class FeedbackSystem:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_data()

    def load_data(self):
        """加载反馈数据"""
        feedback_file = os.path.join(self.base_path, 'data', 'feedback-records.json')
        if os.path.exists(feedback_file):
            with open(feedback_file, 'r', encoding='utf-8') as f:
                self.feedback_records = json.load(f)
        else:
            self.feedback_records = []
        
        # 加载菜谱库用于查找
        with open(os.path.join(self.base_path, 'recipes', 'home-cooking.json'), 'r', encoding='utf-8') as f:
            self.home_recipes = json.load(f)
        
        with open(os.path.join(self.base_path, 'recipes', 'eating-out.json'), 'r', encoding='utf-8') as f:
            self.out_recipes = json.load(f)
        
        self.all_recipes = self.home_recipes + self.out_recipes

    def save_feedback(self):
        """保存反馈数据"""
        feedback_file = os.path.join(self.base_path, 'data', 'feedback-records.json')
        with open(feedback_file, 'w', encoding='utf-8') as f:
            json.dump(self.feedback_records, f, ensure_ascii=False, indent=2)

    def find_dish_by_name(self, dish_name):
        """根据菜名查找菜品 ID"""
        for dish in self.all_recipes:
            if dish['name'] == dish_name or dish_name in dish['name']:
                return dish['id']
        return None

    def add_feedback(self, feedback_type, content, dish_id=None, dish_name=None, metadata=None):
        """添加反馈
        
        Args:
            feedback_type: 反馈类型 - 'like', 'dislike', 'too_spicy', 'too_light', 
                          'too_hard', 'too_boring', 'custom'
            content: 反馈内容
            dish_id: 菜品 ID (可选)
            dish_name: 菜品名称 (可选，会自动查找 ID)
            metadata: 额外元数据
        """
        # 如果给了菜名但没给 ID，自动查找
        if dish_name and not dish_id:
            dish_id = self.find_dish_by_name(dish_name)
        
        feedback = {
            'id': f'fb-{len(self.feedback_records) + 1:04d}',
            'type': feedback_type,
            'content': content,
            'dishId': dish_id,
            'dishName': dish_name,
            'timestamp': datetime.now().isoformat(),
            'applied': False,  # 是否已应用到推荐算法
            'metadata': metadata or {}
        }
        
        self.feedback_records.append(feedback)
        self.save_feedback()
        
        print(f"✅ 反馈已记录: {feedback_type} - {content}")
        if dish_id:
            print(f"   关联菜品: {dish_name} ({dish_id})")
        
        return feedback

    def like_dish(self, dish_name):
        """喜欢某道菜"""
        return self.add_feedback(
            feedback_type='like',
            content=f"用户喜欢 '{dish_name}'",
            dish_name=dish_name
        )

    def dislike_dish(self, dish_name):
        """不喜欢某道菜"""
        return self.add_feedback(
            feedback_type='dislike',
            content=f"用户不喜欢 '{dish_name}'",
            dish_name=dish_name
        )

    def add_avoid_food(self, food_name):
        """添加忌口食物"""
        # 更新用户配置
        profile_file = os.path.join(self.base_path, 'data', 'user-profile.json')
        with open(profile_file, 'r', encoding='utf-8') as f:
            profile = json.load(f)
        
        if food_name not in profile['diet']['avoidFoods']:
            profile['diet']['avoidFoods'].append(food_name)
            profile['updatedAt'] = datetime.now().isoformat()
            
            with open(profile_file, 'w', encoding='utf-8') as f:
                json.dump(profile, f, ensure_ascii=False, indent=2)
            
            self.add_feedback(
                feedback_type='avoid_food',
                content=f"用户添加忌口: '{food_name}'",
                metadata={'food': food_name}
            )
            
            print(f"✅ 已添加忌口: {food_name}")
            return True
        else:
            print(f"⚠️  '{food_name}' 已经在忌口列表中")
            return False

    def remove_avoid_food(self, food_name):
        """移除忌口食物"""
        profile_file = os.path.join(self.base_path, 'data', 'user-profile.json')
        with open(profile_file, 'r', encoding='utf-8') as f:
            profile = json.load(f)
        
        if food_name in profile['diet']['avoidFoods']:
            profile['diet']['avoidFoods'].remove(food_name)
            profile['updatedAt'] = datetime.now().isoformat()
            
            with open(profile_file, 'w', encoding='utf-8') as f:
                json.dump(profile, f, ensure_ascii=False, indent=2)
            
            self.add_feedback(
                feedback_type='remove_avoid',
                content=f"用户移除忌口: '{food_name}'",
                metadata={'food': food_name}
            )
            
            print(f"✅ 已移除忌口: {food_name}")
            return True
        else:
            print(f"⚠️  '{food_name}' 不在忌口列表中")
            return False

    def set_taste_preference(self, taste):
        """设置口味偏好"""
        valid_tastes = ['light', 'medium', 'heavy', 'spicy']
        if taste not in valid_tastes:
            print(f"❌ 无效的口味偏好，可选: {valid_tastes}")
            return False
        
        profile_file = os.path.join(self.base_path, 'data', 'user-profile.json')
        with open(profile_file, 'r', encoding='utf-8') as f:
            profile = json.load(f)
        
        old_taste = profile['diet']['tastePreference']
        profile['diet']['tastePreference'] = taste
        profile['updatedAt'] = datetime.now().isoformat()
        
        with open(profile_file, 'w', encoding='utf-8') as f:
            json.dump(profile, f, ensure_ascii=False, indent=2)
        
        self.add_feedback(
            feedback_type='taste_change',
            content=f"用户调整口味偏好: 从 '{old_taste}' 改为 '{taste}'",
            metadata={'old': old_taste, 'new': taste}
        )
        
        taste_names = {'light': '清淡', 'medium': '适中', 'heavy': '偏重', 'spicy': '超辣'}
        print(f"✅ 口味偏好已设置为: {taste_names[taste]}")
        return True

    def get_recent_feedback(self, days=30, feedback_type=None):
        """获取近期反馈"""
        cutoff = datetime.now() - timedelta(days=days)
        recent = []
        
        for fb in self.feedback_records:
            fb_time = datetime.fromisoformat(fb['timestamp'])
            if fb_time >= cutoff:
                if feedback_type is None or fb['type'] == feedback_type:
                    recent.append(fb)
        
        return recent

    def get_feedback_stats(self):
        """获取反馈统计"""
        stats = {
            'total': len(self.feedback_records),
            'by_type': {},
            'recent_7_days': 0,
            'recent_30_days': 0
        }
        
        for fb in self.feedback_records:
            # 按类型统计
            fb_type = fb['type']
            stats['by_type'][fb_type] = stats['by_type'].get(fb_type, 0) + 1
            
            # 时间统计
            fb_time = datetime.fromisoformat(fb['timestamp'])
            days_ago = (datetime.now() - fb_time).days
            
            if days_ago <= 7:
                stats['recent_7_days'] += 1
            if days_ago <= 30:
                stats['recent_30_days'] += 1
        
        return stats

    def print_feedback_stats(self):
        """打印反馈统计信息"""
        stats = self.get_feedback_stats()
        
        print("\n" + "="*50)
        print("📊 反馈统计信息")
        print("="*50)
        print(f"\n总反馈数: {stats['total']}")
        print(f"近 7 天: {stats['recent_7_days']}")
        print(f"近 30 天: {stats['recent_30_days']}")
        
        print("\n按类型分布:")
        for fb_type, count in stats['by_type'].items():
            print(f"  {fb_type}: {count} 条")
        
        print()

    def parse_natural_language(self, text):
        """解析自然语言反馈
        
        支持的表达方式：
        - "我不喜欢吃番茄炒蛋"
        - "这个菜太辣了"
        - "太油腻了"
        - "很好吃，下次继续推荐"
        - "我不吃香菜"
        """
        text = text.lower()
        
        # 不喜欢某道菜
        if '不喜欢' in text or '不好吃' in text or '讨厌' in text:
            # 尝试提取菜名
            for dish in self.all_recipes:
                if dish['name'] in text:
                    self.dislike_dish(dish['name'])
                    return True, f"已记录你不喜欢 '{dish['name']}'"
            
            return False, "我理解你不喜欢这道菜，但没识别出具体菜名，请告诉我菜名"
        
        # 喜欢某道菜
        if '好吃' in text or '喜欢' in text or '不错' in text or '很棒' in text:
            for dish in self.all_recipes:
                if dish['name'] in text:
                    self.like_dish(dish['name'])
                    return True, f"好的，我会多推荐 '{dish['name']}' 这类菜！"
            
            return True, "很高兴你喜欢！有具体喜欢的菜名可以告诉我哦~"
        
        # 太辣了
        if '太辣' in text or '太辣了' in text or '辣死了' in text:
            self.add_feedback('too_spicy', '用户觉得菜太辣了')
            # 自动调整口味偏好
            self.set_taste_preference('light')
            return True, "好的，我会减少推荐辣菜，以后推荐清淡一些的"
        
        # 太清淡了
        if '太淡' in text or '没味道' in text or '太清淡' in text:
            self.add_feedback('too_light', '用户觉得菜太清淡')
            self.set_taste_preference('heavy')
            return True, "好的，我会增加推荐口味重一些的菜"
        
        # 忌口食物
        if '不吃' in text or '忌口' in text or '对...过敏' in text:
            # 尝试提取食物名
            common_foods = ['香菜', '葱', '姜', '蒜', '辣椒', '青椒', '胡萝卜', 
                           '芹菜', '韭菜', '苦瓜', '香菜', '羊肉', '牛肉', '海鲜',
                           '鱼', '虾', '蟹', '鸡蛋', '牛奶']
            
            for food in common_foods:
                if food in text:
                    self.add_avoid_food(food)
                    return True, f"好的，我记住你不吃 {food} 了"
            
            return False, "我理解你有忌口，但没识别出具体食物，请告诉我具体不吃什么"
        
        return False, "抱歉，我没理解你的意思，可以换个说法吗？"
    
    # ============== 第四阶段新增功能 ==============
    
    def calculate_decay_factor(self, timestamp):
        """计算反馈衰减系数
        
        时间衰减公式:
        - 0-7天: 100% 权重
        - 7-30天: 每天衰减 3%
        - 30-90天: 每天衰减 5%
        - 90天以上: 基础权重 20%
        
        原理: 用户口味会变化，越新的反馈权重越高，旧的反馈影响逐渐降低
        """
        try:
            feedback_date = datetime.fromisoformat(timestamp)
            days_old = (datetime.now() - feedback_date).days
            
            if days_old <= 7:
                # 一周内：100% 权重
                return 1.0
            elif days_old <= 30:
                # 7-30天：每天衰减 3%
                return max(0.4, 1.0 - (days_old - 7) * 0.03)
            elif days_old <= 90:
                # 30-90天：每天衰减 5%
                return max(0.2, 0.4 - (days_old - 30) * 0.005)
            else:
                # 90天以上：保留基础权重 20%
                return 0.2
        except:
            return 1.0  # 默认 100%
    
    def apply_feedback_weights(self, dishes, weights):
        """应用反馈权重到菜品（带时间衰减）
        
        Args:
            dishes: 菜品列表
            weights: 当前权重列表
        Returns:
            更新后的权重列表
        """
        for fb in self.feedback_records:
            if not fb.get('applied', True):
                continue
            
            dish_name = fb.get('dishName', '')
            fb_type = fb.get('type', '')
            timestamp = fb.get('timestamp', '')
            
            if not dish_name:
                continue
            
            # 计算衰减系数
            decay = self.calculate_decay_factor(timestamp)
            
            # 找到对应的菜品
            for i, dish in enumerate(dishes):
                if dish['name'] == dish_name:
                    if fb_type == 'like':
                        # 喜欢：权重 +50%（带衰减）
                        boost = 1 + (0.5 * decay)
                        weights[i] *= boost
                    elif fb_type == 'dislike':
                        # 不喜欢：权重 -70%（带衰减，时间长了会慢慢恢复）
                        penalty = 1 - (0.7 * decay)
                        weights[i] *= penalty
                    break
        
        return weights
    
    def get_diversity_boost(self, dishes, weights, recent_recommendations):
        """推荐多样性优化
        
        原理: 如果某个菜最近已经推荐过，降低其权重，增加推荐其他菜的机会
        避免总是推荐相同的菜，增加新鲜感
        """
        if not recent_recommendations:
            return weights
        
        # 获取最近 7 天推荐过的菜
        recent_dishes = set()
        cutoff = (datetime.now() - timedelta(days=7))
        
        for rec in recent_recommendations:
            if isinstance(rec, dict):
                # 如果是字典格式
                for meal in ['breakfast', 'lunch', 'dinner']:
                    if meal in rec:
                        dish = rec[meal].get('dish', {}).get('name', '')
                        if dish:
                            recent_dishes.add(dish)
        
        # 对最近推荐过的菜施加惩罚
        for i, dish in enumerate(dishes):
            if dish['name'] in recent_dishes:
                # 最近推荐过：权重 × 0.5
                weights[i] *= 0.5
        
        return weights
    
    def get_skip_logic(self, dish, skip_count_threshold=3):
        """智能跳过逻辑
        
        如果一个菜连续 3 次出现在推荐中但用户没选/没反馈，降低权重
        
        Args:
            dish: 菜品
            skip_count_threshold: 跳过次数阈值
        Returns:
            权重乘数 (0.3 = 跳过)
        """
        # 这里可以结合实际使用统计
        # 如果用户连续多次没选某个菜，自动降低该菜推荐概率
        
        # 默认返回 1 表示正常推荐
        
        return 1.0


if __name__ == '__main__':
    # 测试反馈系统
    fb_system = FeedbackSystem()
    
    print("=== 测试自然语言解析 ===")
    test_cases = [
        "我不喜欢吃番茄炒蛋",
        "这个菜太辣了",
        "我不吃香菜",
        "青椒肉丝很好吃",
        "太清淡了，没味道"
    ]
    
    for test in test_cases:
        print(f"\n测试: {test}")
        success, msg = fb_system.parse_natural_language(test)
        print(f"结果: {msg}")
    
    print("\n=== 反馈统计 ===")
    fb_system.print_feedback_stats()
