#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
健康数据图表生成器
- 生成 ASCII 文本趋势图
- 生成详细数据统计表格
- 文本可视化展示
"""

from datetime import datetime, timedelta


class HealthChartGenerator:
    """健康数据图表生成器"""
    
    @staticmethod
    def generate_weight_trend_chart(records, width=50, height=10):
        """
        生成体重趋势 ASCII 图表
        
        Args:
            records: 体重记录列表，按日期排序
            width: 图表宽度
            height: 图表高度
        
        Returns:
            str: ASCII 图表文本
        """
        if not records or len(records) < 2:
            return "数据不足，无法生成趋势图"
        
        # 按日期排序
        sorted_records = sorted(records, key=lambda x: x.get('date', ''))
        
        # 提取体重数据
        weights = [r.get('weight', 0) for r in sorted_records]
        dates = [r.get('date', '') for r in sorted_records]
        
        if not weights:
            return "数据不足，无法生成趋势图"
        
        min_weight = min(weights)
        max_weight = max(weights)
        weight_range = max_weight - min_weight
        
        if weight_range == 0:
            weight_range = 1  # 避免除以 0
        
        # 生成图表
        chart_lines = []
        chart_lines.append("📈 体重趋势图")
        chart_lines.append("=" * width)
        
        # Y 轴刻度和数据点
        for i in range(height):
            y_value = max_weight - (weight_range * i / height)
            line = f"{y_value:5.1f} kg |"
            
            for j, weight in enumerate(weights):
                # 计算该点在 Y 轴的位置
                y_pos = int((max_weight - weight) / weight_range * (height - 1))
                
                if y_pos == i:
                    # 这是数据点位置
                    if j > 0 and j < len(weights) - 1:
                        line += "●"
                    elif j == 0:
                        line += "◉"  # 起点
                    else:
                        line += "◉"  # 终点
                else:
                    # 检查是否需要画连线
                    if j > 0:
                        prev_y_pos = int((max_weight - weights[j-1]) / weight_range * (height - 1))
                        if (prev_y_pos == i and y_pos > i) or (y_pos == i and prev_y_pos > i):
                            line += "╲"
                        elif (prev_y_pos == i and y_pos < i) or (y_pos == i and prev_y_pos < i):
                            line += "╱"
                        else:
                            line += " "
                    else:
                        line += " "
            
            chart_lines.append(line)
        
        # X 轴
        chart_lines.append(" " * 7 + "|" + "=" * (width - 8))
        
        # 日期标签（只显示首尾和中间）
        date_labels = " " * 7
        if len(dates) >= 3:
            date_labels += dates[0][5:] + " " * (width - 18 - len(dates[0][5:]) - len(dates[-1][5:]))
            date_labels += dates[-1][5:]
        chart_lines.append(date_labels)
        
        chart_lines.append("=" * width)
        
        return "\n".join(chart_lines)
    
    @staticmethod
    def generate_bmi_trend_chart(records, width=50, height=8):
        """
        生成 BMI 趋势 ASCII 图表
        
        Args:
            records: 体重记录列表
            width: 图表宽度
            height: 图表高度
        
        Returns:
            str: ASCII 图表文本
        """
        if not records or len(records) < 2:
            return "数据不足，无法生成趋势图"
        
        sorted_records = sorted(records, key=lambda x: x.get('date', ''))
        
        bmis = [r.get('bmi', 0) for r in sorted_records]
        dates = [r.get('date', '') for r in sorted_records]
        
        if not bmis:
            return "数据不足，无法生成趋势图"
        
        min_bmi = min(bmis)
        max_bmi = max(bmis)
        bmi_range = max_bmi - min_bmi
        
        if bmi_range == 0:
            bmi_range = 0.5
        
        chart_lines = []
        chart_lines.append("⚖️  BMI 趋势图")
        chart_lines.append("=" * width)
        
        # BMI 参考线标记
        ref_lines = {
            18.5: "偏瘦",
            24: "正常",
            28: "偏胖"
        }
        
        for i in range(height):
            y_value = max_bmi - (bmi_range * i / height)
            line = f"{y_value:5.1f} |"
            
            # 检查是否经过 BMI 参考线
            for ref_bmi, label in ref_lines.items():
                if abs(y_value - ref_bmi) < bmi_range / height:
                    line = f"{y_value:5.1f}─|─ {label}"
                    break
            
            for j, bmi in enumerate(bmis):
                y_pos = int((max_bmi - bmi) / bmi_range * (height - 1))
                
                if y_pos == i:
                    line += "●"
                else:
                    if j > 0:
                        prev_y_pos = int((max_bmi - bmis[j-1]) / bmi_range * (height - 1))
                        if (prev_y_pos == i and y_pos > i) or (y_pos == i and prev_y_pos > i):
                            line += "╲"
                        elif (prev_y_pos == i and y_pos < i) or (y_pos == i and prev_y_pos < i):
                            line += "╱"
                        else:
                            line += " "
                    else:
                        line += " "
            
            chart_lines.append(line)
        
        chart_lines.append(" " * 5 + "|" + "=" * (width - 6))
        chart_lines.append("=" * width)
        
        return "\n".join(chart_lines)
    
    @staticmethod
    def generate_summary_table(records):
        """
        生成数据汇总表格
        
        Args:
            records: 体重记录列表
        
        Returns:
            str: 汇总表格文本
        """
        if not records:
            return "暂无数据"
        
        sorted_records = sorted(records, key=lambda x: x.get('date', ''))
        weights = [r.get('weight', 0) for r in sorted_records]
        bmis = [r.get('bmi', 0) for r in sorted_records if r.get('bmi')]
        
        start_weight = weights[0]
        end_weight = weights[-1]
        change = end_weight - start_weight
        
        avg_weight = sum(weights) / len(weights) if weights else 0
        avg_bmi = sum(bmis) / len(bmis) if bmis else 0
        
        min_weight = min(weights)
        max_weight = max(weights)
        
        # 计算趋势
        if change > 0.5:
            trend = "↗️ 上升趋势"
        elif change < -0.5:
            trend = "↘️ 下降趋势"
        else:
            trend = "→ 保持稳定"
        
        table_width = 45
        
        table = []
        table.append("📊 数据统计汇总")
        table.append("=" * table_width)
        table.append(f" 统计周期：{sorted_records[0].get('date')} ~ {sorted_records[-1].get('date')}")
        table.append(f" 记录天数：{len(records)} 天")
        table.append("-" * table_width)
        table.append(f" 起始体重：{start_weight:.1f} kg")
        table.append(f" 结束体重：{end_weight:.1f} kg")
        table.append(f" 变化量：{change:+.1f} kg  {trend}")
        table.append(f" 平均体重：{avg_weight:.1f} kg")
        table.append(f" 最低体重：{min_weight:.1f} kg")
        table.append(f" 最高体重：{max_weight:.1f} kg")
        table.append("-" * table_width)
        
        if avg_bmi > 0:
            bmi_status = "偏瘦" if avg_bmi < 18.5 else "正常" if avg_bmi < 24 else "偏胖" if avg_bmi < 28 else "肥胖"
            table.append(f" 平均 BMI：{avg_bmi:.1f} ({bmi_status})")
        
        table.append("=" * table_width)
        
        return "\n".join(table)
    
    @staticmethod
    def generate_daily_detail(records, limit=7):
        """
        生成每日详细数据列表
        
        Args:
            records: 体重记录列表
            limit: 显示多少条记录
        
        Returns:
            str: 详细数据列表
        """
        if not records:
            return "暂无数据"
        
        sorted_records = sorted(records, key=lambda x: x.get('date', ''), reverse=True)
        sorted_records = sorted_records[:limit]
        
        table_width = 50
        
        table = []
        table.append("📋 每日体重详情")
        table.append("=" * table_width)
        table.append(f"  {'日期':<12} {'体重':>8} {'BMI':>8} {'状态':<8}")
        table.append("-" * table_width)
        
        for r in sorted_records:
            date = r.get('date', '')
            weight = r.get('weight', 0)
            bmi = r.get('bmi', 0)
            status = r.get('bmiStatus', '-') or '-'
            
            table.append(f"  {date:<12} {weight:>6.1f} kg {bmi:>6.1f} {status:<8}")
        
        table.append("=" * table_width)
        
        return "\n".join(table)


if __name__ == '__main__':
    # 测试图表生成器
    test_records = [
        {'date': '2026-04-18', 'weight': 89.7, 'bmi': 30.7, 'bmiStatus': '肥胖'},
        {'date': '2026-04-19', 'weight': 89.6, 'bmi': 30.7, 'bmiStatus': '肥胖'},
        {'date': '2026-04-20', 'weight': 89.5, 'bmi': 30.6, 'bmiStatus': '肥胖'},
        {'date': '2026-04-21', 'weight': 89.7, 'bmi': 30.7, 'bmiStatus': '肥胖'},
        {'date': '2026-04-22', 'weight': 89.6, 'bmi': 30.7, 'bmiStatus': '肥胖'},
        {'date': '2026-04-23', 'weight': 89.8, 'bmi': 30.7, 'bmiStatus': '肥胖'},
        {'date': '2026-04-24', 'weight': 90.0, 'bmi': 30.8, 'bmiStatus': '肥胖'},
    ]
    
    print(HealthChartGenerator.generate_weight_trend_chart(test_records))
    print()
    print(HealthChartGenerator.generate_summary_table(test_records))
    print()
    print(HealthChartGenerator.generate_daily_detail(test_records))
