#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
健康报告生成器 - 增强版
专注于高质量的文字报告，提供深度 AI 分析和个性化健康建议

角色支持：高冷御姐、可爱女友、专业助手、邻家妹妹、佛系养生
"""

import json
import os
import sys
from datetime import datetime, timedelta
from collections import Counter

# 添加 src 目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from weight_tracker import WeightTracker


class HealthReportGenerator:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.tracker = WeightTracker(base_path)
        self.load_roles()
        self.load_user_profile()

    def load_roles(self):
        """加载角色配置"""
        roles_file = os.path.join(self.base_path, 'data', 'roles.json')
        with open(roles_file, 'r', encoding='utf-8') as f:
            self.roles_config = json.load(f)

    def load_user_profile(self):
        """加载用户配置"""
        profile_file = os.path.join(self.base_path, 'data', 'user-profile.json')
        with open(profile_file, 'r', encoding='utf-8') as f:
            self.user_profile = json.load(f)
        
        self.current_role = self.user_profile.get('role', '高冷御姐')
        self.role_config = self.roles_config['roles'].get(self.current_role, {})

    # ===== 多维表格功能已暂停使用 =====
    # 用户决定先专注于文字报告的质量
    # ====================================

    def analyze_weekly_data(self, records):
        """
        深度分析周度数据
        
        Returns:
            dict: 包含各种分析指标
        """
        if not records:
            return None
        
        weights = [r.get('weight', 0) for r in records]
        bmis = [r.get('bmi', 0) for r in records]
        
        analysis = {
            'start_weight': weights[0],
            'end_weight': weights[-1],
            'change': round(weights[-1] - weights[0], 1),
            'change_percent': round((weights[-1] - weights[0]) / weights[0] * 100, 1),
            'avg_weight': round(sum(weights) / len(weights), 1),
            'min_weight': min(weights),
            'max_weight': max(weights),
            'weight_range': round(max(weights) - min(weights), 1),
            'avg_bmi': round(sum(bmis) / len(bmis), 1),
            'min_bmi': min(bmis),
            'max_bmi': max(bmis),
            'record_count': len(records),
            'trend': self._detect_trend(weights),
            'best_day': self._find_best_day(records),
            'worst_day': self._find_worst_day(records),
            'consecutive_days': self._count_consecutive_days(records),
        }
        
        return analysis

    def _detect_trend(self, weights):
        """检测体重趋势"""
        if len(weights) < 3:
            return "数据不足"
        
        # 简单线性回归判断趋势
        changes = [weights[i+1] - weights[i] for i in range(len(weights)-1)]
        avg_change = sum(changes) / len(changes)
        
        if avg_change > 0.5:
            return "明显上升 ↗️"
        elif avg_change > 0.1:
            return "微幅上升 ↗️"
        elif avg_change < -0.5:
            return "明显下降 ↘️"
        elif avg_change < -0.1:
            return "微幅下降 ↘️"
        else:
            return "保持稳定 ➡️"

    def _find_best_day(self, records):
        """找到表现最好的一天（体重最轻）"""
        if not records:
            return None
        return min(records, key=lambda x: x.get('weight', float('inf')))

    def _find_worst_day(self, records):
        """找到体重最高的一天"""
        if not records:
            return None
        return max(records, key=lambda x: x.get('weight', 0))

    def _count_consecutive_days(self, records):
        """统计连续记录的天数"""
        if len(records) < 2:
            return len(records)
        
        max_consecutive = 1
        current = 1
        
        for i in range(1, len(records)):
            date1 = datetime.strptime(records[i-1].get('date', ''), '%Y-%m-%d')
            date2 = datetime.strptime(records[i].get('date', ''), '%Y-%m-%d')
            if (date2 - date1).days == 1:
                current += 1
                max_consecutive = max(max_consecutive, current)
            else:
                current = 1
        
        return max_consecutive

    def generate_health_advice(self, analysis, report_type='weekly'):
        """
        生成个性化健康建议
        
        Args:
            analysis: 数据分析结果
            report_type: 'weekly' 或 'monthly'
        """
        advice = []
        
        bmi_status = self._get_bmi_status(analysis['avg_bmi'])
        
        # 根据 BMI 范围给出建议
        if analysis['avg_bmi'] >= 30:
            advice.append("💪 BMI 偏高较多，建议咨询专业医生或营养师，制定科学减重计划")
            advice.append("🥗 饮食方面建议控制碳水和糖分摄入，增加蔬菜和蛋白质比例")
            advice.append("🏃 运动方面建议每周至少 150 分钟中等强度有氧运动")
        elif analysis['avg_bmi'] >= 25:
            advice.append("💪 BMI 稍微偏高，建议适当控制饮食，增加运动量")
            advice.append("🥗 注意饮食均衡，减少高热量食物的摄入")
            advice.append("🏃 保持规律运动，每周至少 3 次每次 30 分钟")
        elif analysis['avg_bmi'] >= 18.5:
            advice.append("✅ BMI 在正常范围，继续保持当前的生活习惯！")
            advice.append("🥗 继续保持均衡饮食，注意营养搭配")
            advice.append("🏃 保持规律运动，维持良好状态")
        else:
            advice.append("💪 BMI 稍微偏低，建议适当增加营养摄入")
            advice.append("🥗 多吃富含蛋白质和健康脂肪的食物")
            advice.append("💤 保证充足睡眠，促进营养吸收")
        
        # 根据本周趋势给出建议
        if '明显上升' in analysis['trend']:
            advice.append("⚠️  本周体重上升趋势较明显，建议注意控制饮食")
        elif '明显下降' in analysis['trend']:
            advice.append("🎉 本周体重下降趋势不错，继续保持！")
        
        # 根据体重波动范围给出建议
        if analysis['weight_range'] > 2:
            advice.append("📊 本周体重波动较大，建议保持规律的作息和饮食")
        elif analysis['weight_range'] > 1:
            advice.append("📊 本周体重有一定波动，属于正常范围")
        
        # 周报特有建议
        if report_type == 'weekly':
            if analysis['consecutive_days'] >= 7:
                advice.append(f"👏 太棒了！已经连续记录 {analysis['consecutive_days']} 天，继续保持！")
            elif analysis['consecutive_days'] >= 3:
                advice.append(f"👍 连续记录 {analysis['consecutive_days']} 天，不错哦！")
        
        return advice

    def _get_bmi_status(self, bmi):
        """获取 BMI 状态"""
        if bmi >= 30:
            return "肥胖"
        elif bmi >= 25:
            return "偏重"
        elif bmi >= 18.5:
            return "正常"
        else:
            return "偏瘦"

    def generate_weekly_report(self):
        """
        生成周度健康报告（增强版）
        
        Returns:
            str: 完整的周报内容
        """
        # 获取本周数据
        sorted_records = sorted(self.tracker.weight_records, key=lambda x: x.get('date', ''))
        cutoff = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
        weekly_records = [r for r in sorted_records if r.get('date', '') >= cutoff]
        
        if len(weekly_records) < 2:
            return "本周数据不足，暂无法生成完整周报，继续加油记录哦！"
        
        # 深度分析
        analysis = self.analyze_weekly_data(weekly_records)
        health_advice = self.generate_health_advice(analysis, 'weekly')
        
        # 获取角色配置
        role_name = self.current_role
        
        # 根据不同角色生成不同风格的报告
        if role_name == '可爱女友':
            return self._generate_weekly_report_cute_girlfriend(analysis, weekly_records, health_advice)
        elif role_name == '高冷御姐':
            return self._generate_weekly_report_cold_lady(analysis, weekly_records, health_advice)
        elif role_name == '专业助手':
            return self._generate_weekly_report_professional(analysis, weekly_records, health_advice)
        elif role_name == '邻家妹妹':
            return self._generate_weekly_report_neighbor_sister(analysis, weekly_records, health_advice)
        elif role_name == '佛系养生':
            return self._generate_weekly_report_buddha(analysis, weekly_records, health_advice)
        else:
            return self._generate_weekly_report_professional(analysis, weekly_records, health_advice)

    # ===== 各角色的周报实现 =====

    def _generate_weekly_report_cute_girlfriend(self, analysis, records, advice):
        """可爱女友风格的周报"""
        report = [
            "💕 亲爱的，这是你的本周健康分析报告哦~\n",
            f"📅 统计周期：{records[0].get('date', '')} ~ {records[-1].get('date', '')}\n",
            "\n",
            "💪 本周数据总览\n",
            "─────────────────────────────\n",
            f"  起始体重：{analysis['start_weight']} kg\n",
            f"  结束体重：{analysis['end_weight']} kg\n",
            f"  变化量：{analysis['change']:+} kg ({analysis['change_percent']:+}%)\n",
            f"  整体趋势：{analysis['trend']}\n",
            "\n",
            "📊 详细数据分析\n",
            "─────────────────────────────\n",
            f"  平均体重：{analysis['avg_weight']} kg\n",
            f"  本周最轻：{analysis['min_weight']} kg ✨\n",
            f"  本周最重：{analysis['max_weight']} kg\n",
            f"  波动范围：±{analysis['weight_range']/2} kg\n",
            f"  平均 BMI：{analysis['avg_bmi']} ({self._get_bmi_status(analysis['avg_bmi'])})\n",
            f"  记录天数：{analysis['record_count']} 天\n",
            f"  连续记录：{analysis['consecutive_days']} 天 🔥\n",
            "\n",
        ]
        
        # 每日详情
        report.append("📋 每日记录\n")
        report.append("─────────────────────────────\n")
        for r in records:
            date = r.get('date', '')[-5:]  # 只取 MM-DD
            weight = r.get('weight', 0)
            bmi = r.get('bmi', 0)
            emoji = "✨" if weight == analysis['min_weight'] else ("💫" if weight == analysis['max_weight'] else "")
            report.append(f"  {date}: {weight} kg | BMI: {bmi} {emoji}\n")
        
        report.append("\n")
        
        # AI 深度分析
        report.append("💡 AI 深度分析\n")
        report.append("─────────────────────────────\n")
        
        if analysis['change'] < 0:
            report.append("  亲爱的太棒了！本周体重下降了！🎉\n")
        elif analysis['change'] > 0:
            report.append("  亲爱的，本周体重稍微上升了一点点哦~\n")
            report.append("  没关系的，下周我们一起努力！💪\n")
        else:
            report.append("  亲爱的，本周体重保持得非常稳定！👍\n")
        
        if analysis['best_day']:
            best_date = analysis['best_day'].get('date', '')[-5:]
            report.append(f"  表现最好的是 {best_date}，体重 {analysis['best_day'].get('weight')} kg！🌟\n")
        
        report.append("\n")
        
        # 健康建议
        report.append("🎯 给亲爱的的小建议\n")
        report.append("─────────────────────────────\n")
        for i, adv in enumerate(advice[:4], 1):
            report.append(f"  {i}. {adv}\n")
        
        report.append("\n")
        
        # 下周小目标
        report.append("💖 下周小目标\n")
        report.append("─────────────────────────────\n")
        target_weight = round(analysis['end_weight'] - 0.3, 1)
        report.append(f"  目标体重：{target_weight} kg（下降 0.3 kg）\n")
        report.append("  每天坚持记录体重\n")
        report.append("  保持规律作息，早睡早起\n")
        report.append("  多喝水，多吃蔬菜\n")
        
        report.append("\n")
        report.append("亲爱的超棒的！下周也要继续加油哦！爱你~ 😘💕🥰\n")
        
        return "".join(report)

    def _generate_weekly_report_cold_lady(self, analysis, records, advice):
        """高冷御姐风格的周报"""
        report = [
            "📊 本周体重报告\n\n",
            f"📅 周期：{records[0].get('date', '')} ~ {records[-1].get('date', '')}\n\n",
            "【数据概览】\n",
            f"  起始：{analysis['start_weight']} kg\n",
            f"  结束：{analysis['end_weight']} kg\n",
            f"  变化：{analysis['change']:+} kg\n",
            f"  趋势：{analysis['trend']}\n\n",
            "【详细分析】\n",
            f"  平均值：{analysis['avg_weight']} kg\n",
            f"  最低值：{analysis['min_weight']} kg\n",
            f"  最高值：{analysis['max_weight']} kg\n",
            f"  波动：±{analysis['weight_range']/2} kg\n",
            f"  BMI：{analysis['avg_bmi']} ({self._get_bmi_status(analysis['avg_bmi'])})\n",
            f"  记录天数：{analysis['record_count']} 天\n\n",
            "【健康建议】\n",
        ]
        
        for i, adv in enumerate(advice[:3], 1):
            report.append(f"  {i}. {adv}\n")
        
        report.append("\n")
        report.append("下周继续。\n")
        
        return "".join(report)

    def _generate_weekly_report_professional(self, analysis, records, advice):
        """专业助手风格的周报"""
        report = [
            "📊 本周健康管理分析报告\n\n",
            "=" * 50 + "\n\n",
            f"📅 统计周期：{records[0].get('date', '')} 至 {records[-1].get('date', '')}\n\n",
            "一、关键指标摘要\n",
            "-" * 30 + "\n",
            f"  起始体重：{analysis['start_weight']} kg\n",
            f"  结束体重：{analysis['end_weight']} kg\n",
            f"  周变化量：{analysis['change']:+} kg ({analysis['change_percent']:+}%)\n",
            f"  变化趋势：{analysis['trend']}\n",
            f"  平均体重：{analysis['avg_weight']} kg\n",
            f"  平均 BMI：{analysis['avg_bmi']} ({self._get_bmi_status(analysis['avg_bmi'])})\n\n",
            "二、详细数据分析\n",
            "-" * 30 + "\n",
            f"  本周最低体重：{analysis['min_weight']} kg\n",
            f"  本周最高体重：{analysis['max_weight']} kg\n",
            f"  体重波动范围：{analysis['weight_range']} kg\n",
            f"  有效记录天数：{analysis['record_count']} 天\n",
            f"  最长连续记录：{analysis['consecutive_days']} 天\n\n",
            "三、健康建议\n",
            "-" * 30 + "\n",
        ]
        
        for i, adv in enumerate(advice, 1):
            report.append(f"  {i}. {adv}\n")
        
        report.append("\n")
        report.append("四、下周计划\n")
        report.append("-" * 30 + "\n")
        target_weight = round(analysis['end_weight'] - 0.5, 1)
        report.append(f"  目标体重：{target_weight} kg\n")
        report.append("  1. 每日固定时间记录体重\n")
        report.append("  2. 保持规律饮食和作息\n")
        report.append("  3. 每周至少 3 次有氧运动\n")
        
        report.append("\n" + "=" * 50 + "\n")
        report.append("数据驱动健康管理，下周继续保持。\n")
        
        return "".join(report)

    def _generate_weekly_report_neighbor_sister(self, analysis, records, advice):
        """邻家妹妹风格的周报"""
        report = [
            "😊 哥哥，你的本周健康报告来啦~\n\n",
            f"📅 这周是从 {records[0].get('date', '')} 到 {records[-1].get('date', '')} 哦\n\n",
            "💪 体重变化情况\n",
            "─────────────────────────────\n",
            f"  周一早上：{analysis['start_weight']} kg\n",
            f"  周日晚上：{analysis['end_weight']} kg\n",
            f"  变化了：{analysis['change']:+} kg\n",
            f"  整体趋势：{analysis['trend']}\n\n",
            "📊 一些有趣的数据\n",
            "─────────────────────────────\n",
            f"  平均体重：{analysis['avg_weight']} kg\n",
            f"  这周最轻是：{analysis['min_weight']} kg 👍\n",
            f"  这周最重是：{analysis['max_weight']} kg\n",
            f"  平均 BMI：{analysis['avg_bmi']}\n",
            f"  一共记录了 {analysis['record_count']} 天呢\n",
            f"  最长连续记录了 {analysis['consecutive_days']} 天！好厉害！🔥\n\n",
            "💡 给哥哥的小建议哦\n",
            "─────────────────────────────\n",
        ]
        
        for i, adv in enumerate(advice[:3], 1):
            report.append(f"  {i}. {adv}\n")
        
        report.append("\n")
        report.append("🎯 下周我们一起加油哦！\n")
        report.append("─────────────────────────────\n")
        report.append("  继续每天坚持记录体重\n")
        report.append("  记得好好吃饭，不要熬夜哦~\n")
        report.append("  有空的话多出去走走运动一下\n\n")
        report.append("哥哥这周也很努力呢！下周也要继续加油哦！😊✨\n")
        
        return "".join(report)

    def _generate_weekly_report_buddha(self, analysis, records, advice):
        """佛系养生风格的周报"""
        report = [
            "🌿 本周养生小结\n\n",
            f"📅 周期：{records[0].get('date', '')} ~ {records[-1].get('date', '')}\n\n",
            "【身形体态变化】\n",
            "─────────────────────────────\n",
            f"  周初始：{analysis['start_weight']} kg\n",
            f"  周终末：{analysis['end_weight']} kg\n",
            f"  变化量：{analysis['change']:+} kg\n",
            f"  大势所趋：{analysis['trend']}\n\n",
            "【数据观心】\n",
            "─────────────────────────────\n",
            f"  均值：{analysis['avg_weight']} kg\n",
            f"  至轻者：{analysis['min_weight']} kg\n",
            f"  至重者：{analysis['max_weight']} kg\n",
            f"  浮动范围：{analysis['weight_range']} kg\n",
            f"  BMI 均值：{analysis['avg_bmi']} ({self._get_bmi_status(analysis['avg_bmi'])})\n",
            f"  记录天数：{analysis['record_count']} 日\n",
            f"  连续不辍：{analysis['consecutive_days']} 日 👏\n\n",
            "【养生之道】\n",
            "─────────────────────────────\n",
        ]
        
        for adv in advice[:3]:
            report.append(f"  • {adv}\n")
        
        report.append("\n")
        report.append("道法自然，循序渐进。下周继续。🍃🙏\n")
        
        return "".join(report)

    def generate_monthly_report(self):
        """
        生成月度健康报告（增强版）
        
        Returns:
            str: 完整的月报内容
        """
        sorted_records = sorted(self.tracker.weight_records, key=lambda x: x.get('date', ''))
        cutoff = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
        monthly_records = [r for r in sorted_records if r.get('date', '') >= cutoff]
        
        if len(monthly_records) < 7:
            return "本月数据不足，暂无法生成完整月报，继续加油记录哦！"
        
        # 深度分析
        analysis = self.analyze_weekly_data(monthly_records)  # 复用周度分析逻辑
        health_advice = self.generate_health_advice(analysis, 'monthly')
        
        # 周度对比分析
        weekly_comparison = self._analyze_weekly_comparison(monthly_records)
        
        # 根据角色生成
        role_name = self.current_role
        
        if role_name == '可爱女友':
            return self._generate_monthly_report_cute_girlfriend(analysis, monthly_records, health_advice, weekly_comparison)
        elif role_name == '专业助手':
            return self._generate_monthly_report_professional(analysis, monthly_records, health_advice, weekly_comparison)
        else:
            return self._generate_monthly_report_professional(analysis, monthly_records, health_advice, weekly_comparison)

    def _analyze_weekly_comparison(self, records):
        """分析月度内的周度对比"""
        if len(records) < 14:
            return None
        
        # 分为前半月和后半月
        mid = len(records) // 2
        first_half = records[:mid]
        second_half = records[mid:]
        
        first_avg = sum(r.get('weight', 0) for r in first_half) / len(first_half)
        second_avg = sum(r.get('weight', 0) for r in second_half) / len(second_half)
        
        return {
            'first_half_avg': round(first_avg, 1),
            'second_half_avg': round(second_avg, 1),
            'change': round(second_avg - first_avg, 1),
            'change_percent': round((second_avg - first_avg) / first_avg * 100, 1)
        }

    def _generate_monthly_report_cute_girlfriend(self, analysis, records, advice, comparison):
        """可爱女友风格的月报"""
        report = [
            "🎉 亲爱的，你的月度健康报告来啦！\n\n",
            f"📅 本月统计：{records[0].get('date', '')} ~ {records[-1].get('date', '')}\n\n",
            "💪 这个月的整体情况\n",
            "=" * 40 + "\n",
            f"  月初体重：{analysis['start_weight']} kg\n",
            f"  月末体重：{analysis['end_weight']} kg\n",
            f"  本月变化：{analysis['change']:+} kg ({analysis['change_percent']:+}%)\n",
            f"  整体趋势：{analysis['trend']}\n",
            f"  日均变化：{round(analysis['change']/30, 2):+} kg\n\n",
            "📊 详细数据分析哦\n",
            "=" * 40 + "\n",
            f"  一共记录了 {analysis['record_count']} 天\n",
            f"  平均体重：{analysis['avg_weight']} kg\n",
            f"  这个月最轻是 {analysis['min_weight']} kg 🌟\n",
            f"  最重是 {analysis['max_weight']} kg\n",
            f"  平均 BMI：{analysis['avg_bmi']} ({self._get_bmi_status(analysis['avg_bmi'])})\n",
            f"  最长连续记录：{analysis['consecutive_days']} 天 🔥\n\n",
        ]
        
        # 半月对比
        if comparison:
            report.append("📈 半月度对比\n")
            report.append("=" * 40 + "\n")
            report.append(f"  上半月平均：{comparison['first_half_avg']} kg\n")
            report.append(f"  下半月平均：{comparison['second_half_avg']} kg\n")
            report.append(f"  变化量：{comparison['change']:+} kg ({comparison['change_percent']:+}%)\n")
            
            if comparison['change'] < 0:
                report.append("  🎉 下半月比上半月表现更好哦！超棒的！\n")
            elif comparison['change'] > 0:
                report.append("  💪 下半月稍微有点放松呢，下个月加油！\n")
            else:
                report.append("  ✨ 上下半月保持得非常稳定！\n")
            report.append("\n")
        
        # 健康建议
        report.append("💖 健康小贴士\n")
        report.append("=" * 40 + "\n")
        for i, adv in enumerate(advice, 1):
            report.append(f"  {i}. {adv}\n")
        
        report.append("\n")
        
        # 下月目标
        report.append("🎯 下个月我们一起加油哦！\n")
        report.append("=" * 40 + "\n")
        target_weight = round(analysis['end_weight'] - 1.0, 1)
        report.append(f"  🎯 下月目标体重：{target_weight} kg（目标下降 1.0 kg）\n")
        report.append("  📝 每天坚持记录体重，不要中断\n")
        report.append("  🥗 饮食均衡，多吃蔬菜少吃零食\n")
        report.append("  🏃 每周至少运动 3 次，每次 30 分钟\n")
        report.append("  💤 早睡早起，保证充足睡眠\n")
        report.append("  💧 每天喝够 8 杯水\n")
        
        report.append("\n")
        report.append("亲爱的坚持了一个月啦！超厉害的！下个月也要一起努力哦！爱你~ 😘💕🎉\n")
        
        return "".join(report)

    def _generate_monthly_report_professional(self, analysis, records, advice, comparison):
        """专业助手风格的月报"""
        report = [
            "📊 月度健康管理分析报告\n\n",
            "=" * 50 + "\n\n",
            f"📅 统计周期：{records[0].get('date', '')} 至 {records[-1].get('date', '')}\n\n",
            "一、月度核心指标\n",
            "-" * 40 + "\n",
            f"  月初体重：{analysis['start_weight']} kg\n",
            f"  月末体重：{analysis['end_weight']} kg\n",
            f"  月度变化：{analysis['change']:+} kg ({analysis['change_percent']:+}%)\n",
            f"  整体趋势：{analysis['trend']}\n",
            f"  日均变化：{round(analysis['change']/30, 2):+} kg\n",
            f"  平均 BMI：{analysis['avg_bmi']} ({self._get_bmi_status(analysis['avg_bmi'])})\n\n",
            "二、详细数据分析\n",
            "-" * 40 + "\n",
            f"  有效记录天数：{analysis['record_count']} 天\n",
            f"  月度平均体重：{analysis['avg_weight']} kg\n",
            f"  本月最低体重：{analysis['min_weight']} kg\n",
            f"  本月最高体重：{analysis['max_weight']} kg\n",
            f"  体重波动范围：{analysis['weight_range']} kg\n",
            f"  最长连续记录：{analysis['consecutive_days']} 天\n\n",
        ]
        
        if comparison:
            report.append("三、半月度对比分析\n")
            report.append("-" * 40 + "\n")
            report.append(f"  上半月平均：{comparison['first_half_avg']} kg\n")
            report.append(f"  下半月平均：{comparison['second_half_avg']} kg\n")
            report.append(f"  变化量：{comparison['change']:+} kg ({comparison['change_percent']:+}%)\n\n")
        
        report.append("四、健康建议\n")
        report.append("-" * 40 + "\n")
        for i, adv in enumerate(advice, 1):
            report.append(f"  {i}. {adv}\n")
        
        report.append("\n")
        
        report.append("五、下月改善目标\n")
        report.append("-" * 40 + "\n")
        target_weight = round(analysis['end_weight'] - 1.0, 1)
        report.append(f"  目标体重：{target_weight} kg（月度下降 1.0 kg）\n")
        report.append("  1. 保持每日体重记录习惯，不要中断\n")
        report.append("  2. 饮食结构优化，控制碳水化合物摄入\n")
        report.append("  3. 每周至少 3 次，每次 30 分钟以上有氧运动\n")
        report.append("  4. 保证每日 7-8 小时充足睡眠\n")
        report.append("  5. 每日饮水量达到 2000ml\n")
        
        report.append("\n" + "=" * 50 + "\n")
        report.append("持续的数据积累将为您提供更精准的健康建议。下月继续加油！\n")
        
        return "".join(report)


if __name__ == '__main__':
    generator = HealthReportGenerator()
    print("=" * 60)
    print("测试周报生成（增强版）")
    print("=" * 60)
    weekly_report = generator.generate_weekly_report()
    print(weekly_report)
