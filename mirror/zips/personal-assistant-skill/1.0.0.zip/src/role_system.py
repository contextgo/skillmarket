#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 角色语气系统
支持多种人设的回复风格
"""

import json
import os

class RoleSystem:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_config()
        self.roles = self._init_roles()

    def load_config(self):
        """加载配置"""
        with open(os.path.join(self.base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        self.current_role = self.config['role']['current']

    def _init_roles(self):
        """初始化所有角色配置"""
        return {
            "可爱女友": {
                "greetings": [
                    "亲爱的~ 早安呀！😘",
                    "宝宝，起床了吗？今天也要元气满满哦~ 💕",
                    "小可爱，早上好！今天想吃什么呀？😋",
                    "亲爱的宝贝，早安！新的一天开始啦~ ☀️"
                ],
                "greeting_evening": [
                    "亲爱的~ 晚上好呀！今天过得怎么样？😘",
                    "宝宝，辛苦了一天，晚上好好休息哦~ 💕"
                ],
                "diet_intro": "今天为你精心挑选了这些菜哦，都是我觉得很适合你的~",
                "dish_prefix": "✨",
                "dish_suffix": "相信你一定会喜欢的~",
                "health_tips": [
                    "亲爱的，要记得按时吃饭哦，别饿着自己~",
                    "宝贝，今天也要多喝水哦，对皮肤好~",
                    "亲爱的，工作别太累啦，要注意休息哦~"
                ],
                "water_reminder": [
                    "亲爱的~ 该喝水啦！💧 多喝水对身体好哦~",
                    "宝宝，喝水时间到啦！记得喝杯水呀~ 💦"
                ],
                "feedback_prompt": "觉得今天的推荐怎么样呀？随时告诉我哦，我会越来越懂你的~ 😊",
                "closing": "爱你哦~ 💕",
                "emoji_style": "cute"
            },
            "高冷御姐": {
                "greetings": [
                    "早安。",
                    "新的一天，开始了。",
                    "今天的饮食建议，如下。"
                ],
                "greeting_evening": [
                    "晚上好。",
                    "一天结束了。"
                ],
                "diet_intro": "根据你的健康数据，推荐以下菜品。",
                "dish_prefix": "·",
                "dish_suffix": "",
                "health_tips": [
                    "注意控制饮食。",
                    "按时休息，不要熬夜。",
                    "保持规律作息。"
                ],
                "water_reminder": [
                    "该喝水了。",
                    "喝水时间。"
                ],
                "feedback_prompt": "有任何反馈可以告诉我。",
                "closing": "以上。",
                "emoji_style": "minimal"
            },
            "专业助手": {
                "greetings": [
                    "【每日健康提醒】\n尊敬的用户，早上好！",
                    "【私人助理日报】\n今日健康建议已生成。"
                ],
                "greeting_evening": [
                    "【晚间健康提醒】\n晚上好，今日总结已生成。"
                ],
                "diet_intro": "根据您的 BMI 指数、健康状况和偏好，为您智能推荐以下菜品：",
                "dish_prefix": "📋",
                "dish_suffix": "",
                "health_tips": [
                    "【健康提示】保持规律饮食，有助于维持健康体重。",
                    "【营养建议】每日饮水量建议 1500-2000ml。",
                    "【运动建议】每日建议进行至少 30 分钟中等强度运动。"
                ],
                "water_reminder": [
                    "【饮水提醒】当前时间建议补充水分，建议饮水量 200-300ml。",
                    "【健康提示】定时饮水有助于促进新陈代谢。"
                ],
                "feedback_prompt": "您的反馈将帮助我们持续优化推荐算法，欢迎提出宝贵意见。",
                "closing": "祝您健康每一天！",
                "emoji_style": "professional"
            },
            "邻家妹妹": {
                "greetings": [
                    "哥哥/姐姐早上好呀！☀️ 新的一天开始啦！",
                    "早安！今天也要加油哦！💪",
                    "嗨~ 早上好呀！今天想吃什么呢？😃"
                ],
                "greeting_evening": [
                    "哥哥/姐姐晚上好呀！🌙",
                    "嗨~ 一天辛苦了！晚上好好休息哦~"
                ],
                "diet_intro": "我帮你选了几道好吃又健康的菜，你看看喜欢吗？",
                "dish_prefix": "🌟",
                "dish_suffix": "超好吃的哦~",
                "health_tips": [
                    "要记得按时吃饭哦，不然会饿肚子的！",
                    "天气变化要注意增减衣服呀！",
                    "工作再忙也要记得休息哦！"
                ],
                "water_reminder": [
                    "喝水时间到啦！💧 要记得多喝水哦~",
                    "嘿！该喝水啦！对身体好的~"
                ],
                "feedback_prompt": "如果有什么想吃的或者不喜欢的，一定要告诉我哦！我下次就知道啦~ 😊",
                "closing": "今天也要开心哦！🎉",
                "emoji_style": "cheerful"
            },
            "佛系养生": {
                "greetings": [
                    "施主，早安。☀️",
                    "又是新的一天，平常心对待便好。",
                    "早安，今日饮食建议，施主请看。"
                ],
                "greeting_evening": [
                    "施主，晚上好。🌙",
                    "一日将尽，早点休息，养生要紧。"
                ],
                "diet_intro": "根据施主的身体状况，推荐以下清淡养生之选：",
                "dish_prefix": "🍵",
                "dish_suffix": "荤素搭配，营养均衡。",
                "health_tips": [
                    "饮食有节，起居有常，是养生之道。",
                    "不妄作劳，故能形与神俱。",
                    "心静则身安，身安则体健。"
                ],
                "water_reminder": [
                    "施主，该喝温水了。💧",
                    "喝水之时，亦是静心之时。"
                ],
                "feedback_prompt": "施主若有任何想法，随时告知老衲便可。",
                "closing": "愿施主身体健康，心态平和。🙏",
                "emoji_style": "zen"
            }
        }

    def get_role(self, role_name=None):
        """获取指定角色的配置"""
        if role_name is None:
            role_name = self.current_role
        
        return self.roles.get(role_name, self.roles["可爱女友"])

    def get_greeting(self, role_name=None, time_of_day="morning"):
        """获取问候语
        
        Args:
            time_of_day: 'morning' 早上, 'evening' 晚上
        """
        role = self.get_role(role_name)
        if time_of_day == "evening":
            greetings = role.get("greeting_evening", role["greetings"])
        else:
            greetings = role["greetings"]
        
        import random
        return random.choice(greetings)

    def get_water_reminder(self, role_name=None):
        """获取喝水提醒"""
        role = self.get_role(role_name)
        reminders = role["water_reminder"]
        
        import random
        return random.choice(reminders)

    def get_health_tip(self, role_name=None):
        """获取健康小贴士"""
        role = self.get_role(role_name)
        tips = role["health_tips"]
        
        import random
        return random.choice(tips)

    def format_daily_recommendation(self, menu, role_name=None):
        """格式化每日推荐消息
        
        Args:
            menu: 从推荐引擎获取的每日菜单
        """
        role = self.get_role(role_name)
        
        # 问候语
        message = self.get_greeting(role_name) + "\n\n"
        
        # BMI 信息（专业助手显示，其他角色可选）
        if role_name == "专业助手" and menu.get('bmi'):
            message += f"📊 当前 BMI：{menu['bmi']} ({menu['bmi_status']})\n\n"
        
        # 场景说明
        if menu['scene'] == 'home':
            scene_text = "🏠 今日在家做饭推荐："
        else:
            scene_text = "🍽️ 今日在外就餐推荐："
        
        message += scene_text + "\n\n"
        
        # 推荐介绍
        message += role["diet_intro"] + "\n\n"
        
        # 早餐推荐
        if menu['breakfast']:
            dish = menu['breakfast']['dish']
            message += f"{role['dish_prefix']} 早餐：{dish['name']}\n"
            if 'description' in dish:
                message += f"   {dish['description']}\n"
            if 'tags' in dish:
                message += f"   标签：{'、'.join(dish['tags'])}\n"
            if 'calories' in dish:
                message += f"   热量：约 {dish['calories']} 大卡\n"
            message += "\n"
        
        # 午餐推荐
        if menu['lunch']:
            dish = menu['lunch']['dish']
            message += f"{role['dish_prefix']} 午餐：{dish['name']}\n"
            if 'description' in dish:
                message += f"   {dish['description']}\n"
            if 'tags' in dish:
                message += f"   标签：{'、'.join(dish['tags'])}\n"
            if 'calories' in dish:
                message += f"   热量：约 {dish['calories']} 大卡\n"
            if 'steps' in dish and menu['scene'] == 'home':
                message += f"   做法：详见菜谱\n"
            message += "\n"
        
        # 晚餐推荐
        if menu['dinner']:
            dish = menu['dinner']['dish']
            message += f"{role['dish_prefix']} 晚餐：{dish['name']}\n"
            if 'description' in dish:
                message += f"   {dish['description']}\n"
            if 'tags' in dish:
                message += f"   标签：{'、'.join(dish['tags'])}\n"
            if 'calories' in dish:
                message += f"   热量：约 {dish['calories']} 大卡\n"
            if 'steps' in dish and menu['scene'] == 'home':
                message += f"   做法：详见菜谱\n"
            message += "\n"
        
        # 健康小贴士
        message += "💡 " + self.get_health_tip(role_name) + "\n\n"
        
        # 反馈提示
        message += role["feedback_prompt"] + "\n\n"
        
        # 结尾
        message += role["closing"]
        
        return message

    def list_available_roles(self):
        """列出所有可用角色"""
        return list(self.roles.keys())


if __name__ == '__main__':
    # 测试角色系统
    role_system = RoleSystem()
    
    print("=== 可用角色 ===")
    for role in role_system.list_available_roles():
        print(f"- {role}")
    
    print("\n=== 各角色问候语 ===")
    for role in role_system.list_available_roles():
        greeting = role_system.get_greeting(role)
        print(f"\n【{role}】")
        print(greeting)
    
    print("\n=== 喝水提醒 ===")
    for role in role_system.list_available_roles():
        reminder = role_system.get_water_reminder(role)
        print(f"【{role}】{reminder}")
