#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 体重跟踪系统
记录体重变化，计算 BMI，生成趋势分析
"""

import json
import os
from datetime import datetime, timedelta
from collections import OrderedDict

class WeightTracker:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_data()

    def load_data(self):
        """加载数据"""
        # 加载体重记录
        weight_file = os.path.join(self.base_path, 'data', 'weight-records.json')
        if os.path.exists(weight_file):
            with open(weight_file, 'r', encoding='utf-8') as f:
                self.weight_records = json.load(f)
        else:
            self.weight_records = []
        
        # 加载用户配置
        profile_file = os.path.join(self.base_path, 'data', 'user-profile.json')
        with open(profile_file, 'r', encoding='utf-8') as f:
            self.user_profile = json.load(f)

    def save_records(self):
        """保存体重记录"""
        weight_file = os.path.join(self.base_path, 'data', 'weight-records.json')
        with open(weight_file, 'w', encoding='utf-8') as f:
            json.dump(self.weight_records, f, ensure_ascii=False, indent=2)

    def calculate_bmi(self, weight, height=None):
        """计算 BMI"""
        if height is None:
            height = self.user_profile['basicInfo']['height']
        
        if not height or not weight:
            return None
        
        height_m = height / 100
        bmi = weight / (height_m * height_m)
        return round(bmi, 1)

    def get_bmi_status(self, bmi):
        """获取 BMI 状态（中国标准）"""
        if bmi < 18.5:
            return "偏瘦"
        elif 18.5 <= bmi < 24:
            return "正常"
        elif 24 <= bmi < 28:
            return "偏胖"
        else:
            return "肥胖"

    def get_bmi_health_tip(self, bmi):
        """获取 BMI 健康建议"""
        status = self.get_bmi_status(bmi)
        
        tips = {
            "偏瘦": "你的体重偏轻，建议适当增加营养摄入，多吃高蛋白食物，配合适量运动增加肌肉量。",
            "正常": "你的体重在正常范围内，继续保持良好的饮食习惯和规律运动哦！",
            "偏胖": "你的体重略微偏高，建议适当控制饮食，减少高油高糖食物摄入，增加有氧运动。",
            "肥胖": "你的体重偏高较多，建议咨询专业医生或营养师，制定科学的减重计划，注意饮食控制和规律运动。"
        }
        
        return tips.get(status, "")

    def record_weight(self, weight, date=None, note=""):
        """记录体重
        
        Args:
            weight: 体重 (kg)
            date: 日期，默认为今天
            note: 备注
        """
        if date is None:
            date = datetime.now().strftime('%Y-%m-%d')
        
        # 计算 BMI
        bmi = self.calculate_bmi(weight)
        bmi_status = self.get_bmi_status(bmi) if bmi else None
        
        # 检查是否已有当天记录
        existing_index = None
        for i, record in enumerate(self.weight_records):
            if record['date'] == date:
                existing_index = i
                break
        
        record = {
            'date': date,
            'weight': weight,
            'bmi': bmi,
            'bmiStatus': bmi_status,
            'note': note,
            'timestamp': datetime.now().isoformat()
        }
        
        if existing_index is not None:
            # 更新已有记录
            old_weight = self.weight_records[existing_index]['weight']
            self.weight_records[existing_index] = record
            print(f"✅ 已更新 {date} 的体重记录: {old_weight} kg → {weight} kg")
        else:
            # 添加新记录
            self.weight_records.append(record)
            print(f"✅ 已记录 {date} 的体重: {weight} kg")
        
        self.save_records()
        
        # 更新用户配置中的最新体重
        self.user_profile['basicInfo']['weight'] = weight
        self.user_profile['health']['bmi'] = bmi
        self.user_profile['health']['bmiStatus'] = bmi_status
        
        with open(os.path.join(self.base_path, 'data', 'user-profile.json'), 'w', encoding='utf-8') as f:
            json.dump(self.user_profile, f, ensure_ascii=False, indent=2)
        
        return record

    def get_latest_weight(self):
        """获取最新的体重记录"""
        if not self.weight_records:
            return None
        
        # 按日期排序，取最新的
        sorted_records = sorted(self.weight_records, key=lambda x: x['date'], reverse=True)
        return sorted_records[0]

    def get_weight_by_date(self, date):
        """获取指定日期的体重记录"""
        for record in self.weight_records:
            if record['date'] == date:
                return record
        return None

    def get_weight_trend(self, days=30):
        """获取体重趋势
        
        Args:
            days: 统计天数
        """
        if len(self.weight_records) < 2:
            return None
        
        # 按日期排序
        sorted_records = sorted(self.weight_records, key=lambda x: x['date'])
        
        # 取最近 days 天的数据
        cutoff = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        recent_records = [r for r in sorted_records if r['date'] >= cutoff]
        
        if len(recent_records) < 2:
            recent_records = sorted_records[-2:]  # 至少取 2 条
        
        first_weight = recent_records[0]['weight']
        last_weight = recent_records[-1]['weight']
        change = round(last_weight - first_weight, 1)
        
        # 计算变化趋势
        if change > 0.5:
            trend = "上升"
        elif change < -0.5:
            trend = "下降"
        else:
            trend = "稳定"
        
        # 计算日均变化
        days_between = (
            datetime.fromisoformat(recent_records[-1]['date']) - 
            datetime.fromisoformat(recent_records[0]['date'])
        ).days
        
        if days_between > 0:
            daily_change = round(change / days_between, 2)
        else:
            daily_change = 0
        
        return {
            'period_days': days,
            'start_weight': first_weight,
            'end_weight': last_weight,
            'change': change,
            'trend': trend,
            'daily_change': daily_change,
            'record_count': len(recent_records),
            'start_date': recent_records[0]['date'],
            'end_date': recent_records[-1]['date']
        }

    def get_weekly_average(self):
        """获取本周平均体重"""
        today = datetime.now()
        week_start = (today - timedelta(days=today.weekday())).strftime('%Y-%m-%d')
        
        this_week_records = [
            r for r in self.weight_records 
            if r['date'] >= week_start
        ]
        
        if not this_week_records:
            return None
        
        avg_weight = round(sum(r['weight'] for r in this_week_records) / len(this_week_records), 1)
        avg_bmi = round(sum(r['bmi'] for r in this_week_records if r['bmi']) / len(this_week_records), 1) if this_week_records else None
        
        return {
            'week_start': week_start,
            'average_weight': avg_weight,
            'average_bmi': avg_bmi,
            'record_count': len(this_week_records)
        }

    def print_weight_history(self, limit=10):
        """打印体重历史记录"""
        if not self.weight_records:
            print("📝 还没有体重记录")
            return
        
        sorted_records = sorted(self.weight_records, key=lambda x: x['date'], reverse=True)
        
        print("\n" + "="*60)
        print("📊 体重历史记录")
        print("="*60)
        
        print(f"\n{'日期':<12} {'体重(kg)':<10} {'BMI':<8} {'状态':<8} {'备注'}")
        print("-" * 60)
        
        for record in sorted_records[:limit]:
            bmi_str = f"{record['bmi']:.1f}" if record['bmi'] else "-"
            bmi_status = record.get('bmiStatus', '-') or "-"
            print(f"{record['date']:<12} {record['weight']:<10.1f} {bmi_str:<8} {bmi_status:<8} {record.get('note', '')}")
        
        print(f"\n共 {len(sorted_records)} 条记录")
        if len(sorted_records) > limit:
            print(f"(仅显示最近 {limit} 条)")
        
        # 显示趋势
        trend_30 = self.get_weight_trend(days=30)
        if trend_30:
            print("\n📈 30天趋势:")
            change_symbol = "↑" if trend_30['change'] > 0 else "↓" if trend_30['change'] < 0 else "→"
            print(f"   {trend_30['start_date']} → {trend_30['end_date']}")
            print(f"   {trend_30['start_weight']} kg → {trend_30['end_weight']} kg")
            print(f"   变化: {change_symbol} {abs(trend_30['change'])} kg ({trend_30['trend']})")
            
            if trend_30['daily_change'] != 0:
                print(f"   日均变化: {trend_30['daily_change']:+.2f} kg")

    def generate_weekly_report(self):
        """生成周报"""
        if len(self.weight_records) < 2:
            return "数据不足，暂无法生成周报"
        
        trend = self.get_weight_trend(days=7)
        if not trend:
            return "本周数据不足，暂无法生成周报"
        
        latest = self.get_latest_weight()
        health_tip = self.get_bmi_health_tip(latest['bmi'])
        
        report = f"""📊 每周健康报告

📅 统计周期：{trend['start_date']} ~ {trend['end_date']}

【体重变化】
  起始体重：{trend['start_weight']} kg
  结束体重：{trend['end_weight']} kg
  变化量：{trend['change']:+} kg
  趋势：{trend['trend']}

【当前状态】
  最新体重：{latest['weight']} kg
  BMI：{latest['bmi']} ({latest['bmiStatus']})

💡 健康建议：
  {health_tip}

继续加油，保持健康的生活习惯！💪
"""
        return report

    def generate_monthly_report(self):
        """生成月报"""
        if len(self.weight_records) < 5:
            return "数据不足，暂无法生成月报"
        
        trend = self.get_weight_trend(days=30)
        if not trend:
            return "本月数据不足，暂无法生成月报"
        
        latest = self.get_latest_weight()
        health_tip = self.get_bmi_health_tip(latest['bmi'])
        
        report = f"""📊 月度健康报告

📅 统计周期：最近 30 天

【体重变化趋势】
  起始体重：{trend['start_weight']} kg
  结束体重：{trend['end_weight']} kg
  变化量：{trend['change']:+} kg
  整体趋势：{trend['trend']}
  日均变化：{trend['daily_change']:+.2f} kg

【当前健康状态】
  最新体重：{latest['weight']} kg
  BMI 指数：{latest['bmi']}
  体重状态：{latest['bmiStatus']}

💡 健康建议：
  {health_tip}

【下月目标建议】
  • 继续保持规律记录体重
  • 每周至少 3 次有氧运动
  • 注意饮食均衡，多喝水
  • 保证充足睡眠

坚持就是胜利！下个月继续加油！🎉
"""
        return report


if __name__ == '__main__':
    # 测试体重跟踪系统
    tracker = WeightTracker()
    
    # 添加一些测试数据
    tracker.record_weight(68.5, '2026-04-01', '月初记录')
    tracker.record_weight(68.2, '2026-04-08')
    tracker.record_weight(67.8, '2026-04-15')
    tracker.record_weight(67.5, '2026-04-22')
    tracker.record_weight(67.3)  # 今天的体重
    
    # 打印历史
    tracker.print_weight_history()
    
    # 打印周报
    print("\n" + "="*60)
    print(tracker.generate_weekly_report())
    
    # 打印月报
    print("="*60)
    print(tracker.generate_monthly_report())
