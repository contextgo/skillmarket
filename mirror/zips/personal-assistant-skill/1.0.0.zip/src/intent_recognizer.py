#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
意图识别器 - 识别用户是否在调用小右助理
通过名称唤起机制，精准触发健康助理 SKILL
"""

import json
import os
import re

class IntentRecognizer:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_config()
        
    def load_config(self):
        """加载配置"""
        with open(os.path.join(self.base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        self.skill_name = self.config.get('skill', {}).get('name', '小右')
        self.nicknames = self.config.get('skill', {}).get('nicknames', ['小右助理', '小右', '右右'])
        self.description = self.config.get('skill', {}).get('description', '私人健康饮食助理')
        
    def should_trigger_skill(self, user_message):
        """
        判断是否应该触发小右助理 SKILL
        
        Args:
            user_message: 用户输入的消息
            
        Returns:
            dict: {
                'should_trigger': bool,  # 是否应该触发
                'confidence': float,     # 置信度 0-1
                'trigger_type': str,     # 触发类型：name / keyword / semantic
                'intent': str,           # 识别出的意图：diet / role / report / weight / water / feedback / help
                'extracted_command': str # 提取出的纯指令（去掉唤起词后的部分）
            }
        """
        msg = user_message.strip()
        msg_lower = msg.lower()
        
        # ========== 1. 名称唤起检测（最高优先级） ==========
        for nickname in self.nicknames:
            if nickname in msg:
                # 提取去掉唤起词后的纯指令
                command = msg
                for nn in self.nicknames:
                    # 移除昵称，以及后面的：、，、空格等
                    pattern = r'^' + re.escape(nn) + r'[\s，：:,]*'
                    command = re.sub(pattern, '', command)
                
                # 识别具体意图
                intent = self._recognize_intent(command)
                
                return {
                    'should_trigger': True,
                    'confidence': 1.0,
                    'trigger_type': 'name',
                    'intent': intent,
                    'extracted_command': command
                }
        
        # ========== 2. 关键词检测（次优先级） ==========
        keyword_result = self._check_keywords(msg_lower)
        if keyword_result['match']:
            return {
                'should_trigger': True,
                'confidence': keyword_result['confidence'],
                'trigger_type': 'keyword',
                'intent': keyword_result['intent'],
                'extracted_command': msg
            }
        
        # ========== 3. 语义检测（模糊匹配，低置信度，需要确认） ==========
        semantic_result = self._semantic_match(msg_lower)
        if semantic_result['match']:
            return {
                'should_trigger': True,
                'confidence': semantic_result['confidence'],
                'trigger_type': 'semantic',
                'intent': semantic_result['intent'],
                'extracted_command': msg,
                'need_confirm': True  # 需要用户确认
            }
        
        # ========== 不触发 ==========
        return {
            'should_trigger': False,
            'confidence': 0.0,
            'trigger_type': None,
            'intent': None,
            'extracted_command': None
        }
    
    def _recognize_intent(self, command):
        """识别具体意图"""
        cmd = command.lower()
        
        # 饮食推荐
        if any(k in cmd for k in ['吃什么', '菜谱', '饮食', '午餐', '晚餐', '早餐', '推荐', '菜']):
            return 'diet'
        
        # 角色切换
        if any(k in cmd for k in ['角色', '人设', '风格', '女友', '御姐', '助手', '妹妹', '养生']):
            return 'role'
        
        # 健康报告
        if any(k in cmd for k in ['周报', '月报', '报告', '分析', '健康']):
            return 'report'
        
        # 体重相关
        if any(k in cmd for k in ['体重', '记录', '称重', 'kg', '千克', 'bmi']):
            return 'weight'
        
        # 喝水提醒
        if any(k in cmd for k in ['喝水', '提醒']):
            return 'water'
        
        # 用户反馈
        if any(k in cmd for k in ['喜欢', '不错', '好吃', '不喜欢', '难吃']):
            return 'feedback'
        
        # 帮助
        if any(k in cmd for k in ['帮助', 'help', '功能', '做什么', '怎么用']):
            return 'help'
        
        # 打招呼
        if any(k in cmd for k in ['', '你好', 'hi', '嗨', '在吗', '在不在']):
            return 'greeting'
        
        return 'unknown'
    
    def _check_keywords(self, msg):
        """关键词检测"""
        
        # 强关键词（高置信度）
        strong_keywords = {
            'diet': ['3 菜一汤', '三菜一汤', '菜谱推荐', '饮食推荐', '今天吃什么'],
            'role': ['切换角色', '更换人设', '角色切换', '可爱女友', '高冷御姐'],
            'report': ['健康报告', '生成周报', '生成月报', '健康分析'],
            'weight': ['记录体重', '体重记录', '查看体重'],
            'water': ['喝水提醒', '提醒喝水'],
        }
        
        for intent, keywords in strong_keywords.items():
            for kw in keywords:
                if kw in msg:
                    return {'match': True, 'confidence': 0.9, 'intent': intent}
        
        # 中等关键词（中置信度）
        medium_keywords = {
            'diet': ['吃什么', '午餐', '晚餐', '早餐', '推荐菜'],
            'role': ['换个风格', '换角色'],
            'report': ['周报', '月报', '健康数据'],
            'weight': ['体重', 'bmi', '称重'],
            'water': ['喝水'],
        }
        
        for intent, keywords in medium_keywords.items():
            for kw in keywords:
                if kw in msg:
                    return {'match': True, 'confidence': 0.7, 'intent': intent}
        
        return {'match': False, 'confidence': 0.0, 'intent': None}
    
    def _semantic_match(self, msg):
        """语义模糊匹配"""
        
        # 疑似饮食相关
        if any(k in msg for k in ['饿了', '吃', '饭', '菜']):
            return {'match': True, 'confidence': 0.5, 'intent': 'diet'}
        
        # 疑似健康相关
        if any(k in msg for k in ['胖了', '减肥', '健身', '健康']):
            return {'match': True, 'confidence': 0.5, 'intent': 'health'}
        
        return {'match': False, 'confidence': 0.0, 'intent': None}
    
    def get_welcome_message(self):
        """获取欢迎消息"""
        return f"""😊 我在！我是 {self.skill_name}，您的私人健康饮食助理~

您可以这样和我说话：

🍽️ 饮食推荐
  • "{self.skill_name}，今天吃什么"
  • "{self.skill_name}，推荐一下午餐"

🎭 角色切换
  • "{self.skill_name}，切换到高冷御姐"
  • "{self.skill_name}，我想要可爱女友风格"

📊 健康报告
  • "{self.skill_name}，给我生成周报"
  • "{self.skill_name}，分析一下体重数据"

⚖️ 体重记录
  • "{self.skill_name}，提醒我记录体重"
  • "{self.skill_name}，我今天体重 89 kg"

💧 其他
  • "{self.skill_name}，提醒我喝水"
  • "{self.skill_name}，这道菜不错"
  • "{self.skill_name}，有什么功能"

需要什么帮助随时叫我~ 😊
"""


if __name__ == '__main__':
    recognizer = IntentRecognizer()
    
    print("=" * 60)
    print(f"🧠 {recognizer.skill_name} 意图识别器 - 测试")
    print("=" * 60)
    print()
    
    test_cases = [
        "小右助理，今天吃什么",
        "小右，切换到高冷御姐",
        "小右，给我生成周报",
        "小右，提醒我喝水",
        "小右，这道菜不好吃",
        "小右，看看我的体重",
        "小右",  # 单独唤起
        "今天吃什么",  # 关键词触发
        "切换到高冷御姐",  # 关键词触发
        "帮我写个 Python 脚本",  # 不触发
        "今天天气怎么样",  # 不触发
    ]
    
    for test in test_cases:
        result = recognizer.should_trigger_skill(test)
        print(f"📝 输入：{test}")
        print(f"   触发：{'✅ 是' if result['should_trigger'] else '❌ 否'}")
        print(f"   置信度：{result['confidence']:.2f}")
        print(f"   触发类型：{result['trigger_type']}")
        print(f"   意图：{result['intent']}")
        if result['extracted_command']:
            print(f"   提取指令：{result['extracted_command'][:30]}")
        print()
    
    print("=" * 60)
    print("✅ 测试完成！")
    print("=" * 60)
