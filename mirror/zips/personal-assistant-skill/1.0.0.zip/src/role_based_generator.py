#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基于角色人设的消息生成器（完整版）
- 早餐独立：外带食品（包子、馒头、豆浆、面包、牛奶、手抓饼等）
- 午餐/晚餐：3 菜一汤配置，每道菜带简单做法
- 增加外食推荐选项
- 最后提醒添加水果推荐
"""

import json
import os
from datetime import datetime

class RoleBasedMessageGenerator:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_roles()
        self.load_user_profile()

    def load_roles(self):
        """加载角色配置"""
        roles_file = os.path.join(self.base_path, 'data', 'roles.json')
        with open(roles_file, 'r', encoding='utf-8') as f:
            self.roles_config = json.load(f)

    def load_user_profile(self):
        """加载用户配置"""
        profile_file = os.path.join(self.base_path, 'data', 'user-profile.json')
        with open(profile_file, 'r', encoding='utf-8') as f:
            self.user_profile = json.load(f)
        
        self.current_role = self.user_profile.get('role', '高冷御姐')
        self.role_config = self.roles_config['roles'].get(self.current_role, {})
        self.format = self.role_config.get('daily_format', {})

    def generate_daily_recommendation(self, breakfast, lunch, dinner, eating_out_options=None):
        """
        生成每日饮食推荐消息（完整版）
        
        Args:
            breakfast: 早餐（单个菜品）
            lunch: 午餐（3 菜一汤组合）
            dinner: 晚餐（3 菜一汤组合）
            eating_out_options: 外食选项列表（可选）
        """
        # 获取当前日期
        today = datetime.now()
        date_str = today.strftime("%Y-%m-%d")
        weekday_names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
        weekday_str = weekday_names[today.weekday()]
        
        # 生成问候
        greeting = self.format.get('header', '📅 今日饮食推荐')
        if '{date}' in greeting:
            greeting = greeting.format(date=date_str, weekday=weekday_str)
        
        # 生成天气和穿衣建议
        location = self.user_profile['basicInfo'].get('location', '深圳')
        weather_info = self.format.get('weather', '📍 天气：晴朗，气温适宜')
        if '{location}' in weather_info:
            weather_info = weather_info.format(location=location, temperature='25°C', condition='晴朗')
        
        clothing_tip = "薄外套 + 长袖衬衫"
        cloth_tip = self.format.get('clothing', '👔 穿衣：建议穿薄外套')
        if '{clothing_tip}' in cloth_tip:
            cloth_tip = cloth_tip.format(clothing_tip=clothing_tip)
        
        # 生成 BMI 信息
        from recommender import RecommendationEngine
        engine = RecommendationEngine(self.base_path)
        bmi = engine.calculate_bmi()
        bmi_status = engine.get_bmi_status(bmi)
        
        bmi_title = self.format.get('bmi_title', '⚖️ BMI：{bmi_value} ({bmi_status})')
        bmi_title = bmi_title.format(bmi_value=bmi, bmi_status=bmi_status)
        
        bmi_notes = self.format.get('bmi_notes', '注意健康饮食哦~')
        if isinstance(bmi_notes, str):
            note1 = "控制热量摄入，避免高油高糖"
            note2 = "多吃蔬菜水果，保持营养均衡"
            note3 = "配合适量运动，保持健康体重"
            bmi_notes = bmi_notes.format(note1=note1, note2=note2, note3=note3)
        
        # 早餐推荐（新版：独立外带食品）
        recipe_title = self.format.get('recipe_title', '🍳 今日饮食推荐')
        
        # 生成早餐
        breakfast_text = self._format_breakfast(breakfast)
        
        # 生成午餐（3 菜一汤，带简单做法）
        lunch_text = self._format_three_dishes_one_soup("午餐", lunch)
        
        # 生成晚餐（3 菜一汤，带简单做法）
        dinner_text = self._format_three_dishes_one_soup("晚餐", dinner)
        
        # 外食建议（新增）
        eating_out_text = ""
        if eating_out_options:
            eo_text = self.format.get('eating_out', '🍜 外食备选：')
            eo_items = "\n".join(["  • " + opt.get('name', '') + " (" + str(opt.get('calories', 0)) + " 卡)" for opt in eating_out_options[:3]])
            eating_out_text = eo_text + "\n" + eo_items + "\n"
        else:
            # 默认外食推荐
            eating_out_text = """🍜 外吃备选（如果不想做饭可以选这些）
  • 兰州拉面 + 肉夹馍（约 700 卡）
  • 沙县小吃 - 飘香拌面 + 炖汤（约 600 卡）
  • 隆江猪脚饭（约 750 卡）
"""
        
        # 计算总热量
        total_cal = breakfast.get('calories', 0) + lunch.get('total_calories', 0) + dinner.get('total_calories', 0)
        total_text = self.format.get('total_cal', '📊 在家吃的话大概 {total} 大卡，很健康哒~')
        total_text = total_text.format(total=total_cal)
        
        # 最后提醒（新增水果推荐）
        reminder_text = ""
        if self.format.get('reminder'):
            reminder1 = "记得按时吃饭哦~"
            reminder2 = "多喝水，保持水分摄入"
            reminder3 = "饭后散步15分钟，帮助消化"
            reminder4 = "记得吃点水果哦（苹果/香蕉/橙子都不错）"
            reminder_text = self.format['reminder'].format(
                reminders="- " + reminder1 + "\n- " + reminder2 + "\n- " + reminder3 + "\n- " + reminder4
            )
        
        # 结尾
        closing_text = self.format.get('closing', '祝您用餐愉快！')
        
        # 组装整条消息
        message_parts = [
            greeting,
            "",
            weather_info,
            cloth_tip,
            "",
            bmi_title,
            bmi_notes,
            "",
            recipe_title,
            "",
            breakfast_text,
            "",
            lunch_text,
            "",
            dinner_text,
            "",
            eating_out_text,
            total_text,
            "",
            reminder_text,
            "",
            closing_text
        ]
        
        return "\n".join([p for p in message_parts if p])

    def _format_breakfast(self, breakfast):
        """格式化早餐（外带食品，不需要做法）"""
        name = breakfast.get('name', '')
        calories = breakfast.get('calories', 0)
        description = breakfast.get('description', '')
        price = breakfast.get('price', '')
        
        lines = [
            "☀️ 早餐推荐",
            "  └─ " + name,
            "      热量：约 " + str(calories) + " 卡路里",
            "      说明：" + description,
        ]
        
        if price:
            lines.append("      参考价格：" + price)
        
        return "\n".join(lines)

    def _format_three_dishes_one_soup(self, meal_name, dishes):
        """格式化 3 菜一汤，每道菜带简单做法"""
        lines = ["🍱 " + meal_name + "推荐（3 菜一汤）"]
        
        # 荤菜
        if dishes.get('meat'):
            meat = dishes['meat']
            meat_ingredients = ', '.join(meat.get('ingredients', [])[:5])
            meat_steps = meat.get('steps', [])
            # 取前3步简化做法
            simple_steps = meat_steps[:3] if len(meat_steps) >= 3 else meat_steps
            
            lines.append("  【荤菜】 " + meat.get('name', ''))
            lines.append("        热量：" + str(meat.get('calories', 0)) + " 卡路里")
            lines.append("        食材：" + meat_ingredients)
            if simple_steps:
                lines.append("        做法：")
                for step in simple_steps:
                    # 简化步骤描述（去掉序号）
                    step_text = step[2:] if len(step) > 2 and step[1] == '.' else step
                    lines.append("            " + step_text)
        
        # 素菜
        if dishes.get('vegetable'):
            veg = dishes['vegetable']
            veg_ingredients = ', '.join(veg.get('ingredients', [])[:5])
            veg_steps = veg.get('steps', [])
            simple_steps = veg_steps[:3] if len(veg_steps) >= 3 else veg_steps
            
            lines.append("  【素菜】 " + veg.get('name', ''))
            lines.append("        热量：" + str(veg.get('calories', 0)) + " 卡路里")
            lines.append("        食材：" + veg_ingredients)
            if simple_steps:
                lines.append("        做法：")
                for step in simple_steps:
                    step_text = step[2:] if len(step) > 2 and step[1] == '.' else step
                    lines.append("            " + step_text)
        
        # 半荤半素
        if dishes.get('mixed'):
            mixed = dishes['mixed']
            mixed_ingredients = ', '.join(mixed.get('ingredients', [])[:5])
            mixed_steps = mixed.get('steps', [])
            simple_steps = mixed_steps[:3] if len(mixed_steps) >= 3 else mixed_steps
            
            lines.append("  【半荤半素】 " + mixed.get('name', ''))
            lines.append("        热量：" + str(mixed.get('calories', 0)) + " 卡路里")
            lines.append("        食材：" + mixed_ingredients)
            if simple_steps:
                lines.append("        做法：")
                for step in simple_steps:
                    step_text = step[2:] if len(step) > 2 and step[1] == '.' else step
                    lines.append("            " + step_text)
        
        # 汤
        if dishes.get('soup'):
            soup = dishes['soup']
            soup_ingredients = ', '.join(soup.get('ingredients', [])[:5])
            soup_steps = soup.get('steps', [])
            simple_steps = soup_steps[:3] if len(soup_steps) >= 3 else soup_steps
            
            lines.append("  【汤品】 " + soup.get('name', ''))
            lines.append("        热量：" + str(soup.get('calories', 0)) + " 卡路里")
            lines.append("        食材：" + soup_ingredients)
            if simple_steps:
                lines.append("        做法：")
                for step in simple_steps:
                    step_text = step[2:] if len(step) > 2 and step[1] == '.' else step
                    lines.append("            " + step_text)
        
        # 总热量
        total = dishes.get('total_calories', 0)
        if total:
            lines.append("  " + meal_name + "总热量：约 " + str(total) + " 卡路里")
        
        return "\n".join(lines)

    def generate_weight_reminder(self):
        """生成体重记录提醒"""
        reminder_config = self.role_config.get('weight_reminder', {})
        
        # 获取最新体重
        from weight_tracker import WeightTracker
        tracker = WeightTracker(self.base_path)
        latest = tracker.get_latest_weight()
        bmi_value = latest.get('bmi', 0)
        bmi_status = latest.get('bmiStatus', '未知')
        
        header = reminder_config.get('header', '⚖️ 体重记录提醒\n\n')
        
        content_template = reminder_config.get('content', 
            "该记录今天的体重了哦~\n当前 BMI：{bmi_value} ({bmi_status})\n\n直接回复数字即可，比如：\"90\"\n\n")
        content = content_template.format(bmi_value=bmi_value, bmi_status=bmi_status)
        
        closing = reminder_config.get('closing', '记得每天坚持哦！')
        
        return header + content + closing

    def generate_water_reminder(self):
        """生成喝水提醒（按时间段选择不同文案）"""
        current_hour = datetime.now().hour
        
        water_config = self.role_config.get('water_reminders', {})
        
        if current_hour < 10:
            # 早晨
            return water_config.get('morning', '💧 早上喝杯水，清醒一下吧~')
        elif current_hour < 14:
            # 中午
            return water_config.get('noon', '💧 午饭过后，记得喝杯水哦~')
        elif current_hour < 17:
            # 下午
            return water_config.get('afternoon', '💧 下午容易困，喝杯水提提神~')
        elif current_hour < 20:
            # 傍晚
            return water_config.get('evening', '💧 晚饭前喝杯水，有助于控制食量哦~')
        else:
            # 晚上
            return water_config.get('night', '💧 最后一杯水，喝完准备休息啦~')


if __name__ == '__main__':
    generator = RoleBasedMessageGenerator()
    
    print("=" * 60)
    print("测试角色消息生成器 - 完整版")
    print("=" * 60)
    print()
    
    from recommender import RecommendationEngine
    engine = RecommendationEngine()
    menu = engine.get_daily_menu(scene='home')
    
    message = generator.generate_daily_recommendation(
        menu['breakfast'],
        menu['lunch'],
        menu['dinner']
    )
    
    print(message)
    print()
    print("=" * 60)
    print("✅ 测试完成！")
    print("=" * 60)
