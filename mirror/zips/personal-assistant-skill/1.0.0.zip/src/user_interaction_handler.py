#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
用户交互处理器 - 用户友好的自然语言接口
用户无需关注底层脚本，直接用日常语言即可触发所有功能
"""

import json
import os
import sys
from datetime import datetime

class UserInteractionHandler:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_user_profile()
        self.load_roles()
        
        # 导入各功能模块
        sys.path.insert(0, os.path.join(self.base_path, 'src'))
        from recommender import RecommendationEngine
        from role_based_generator import RoleBasedMessageGenerator
        from weight_tracker import WeightTracker
        from feishu_pusher import FeishuPusher
        
        self.engine = RecommendationEngine(self.base_path)
        self.generator = RoleBasedMessageGenerator(self.base_path)
        self.tracker = WeightTracker(self.base_path)
        self.pusher = FeishuPusher(self.base_path)

    def load_user_profile(self):
        """加载用户配置"""
        profile_file = os.path.join(self.base_path, 'data', 'user-profile.json')
        with open(profile_file, 'r', encoding='utf-8') as f:
            self.user_profile = json.load(f)

    def load_roles(self):
        """加载角色配置"""
        roles_file = os.path.join(self.base_path, 'data', 'roles.json')
        with open(roles_file, 'r', encoding='utf-8') as f:
            self.roles_config = json.load(f)
        self.available_roles = list(self.roles_config['roles'].keys())

    def handle_message(self, user_message):
        """
        处理用户消息，自动识别意图并响应
        
        Args:
            user_message: 用户输入的自然语言消息
            
        Returns:
            dict: {
                'action': 执行的动作,
                'message': 给用户的回复消息,
                'should_push': 是否需要推送飞书消息
            }
        """
        msg = user_message.strip().lower()
        
        # ========== 1. 获取饮食推荐 ==========
        if any(keyword in msg for keyword in ['吃什么', '推荐', '饮食', '午餐', '晚餐', '早餐', '菜谱']):
            return self._handle_get_recommendation()
        
        # ========== 2. 切换角色 ==========
        elif any(keyword in msg for keyword in ['角色', '切换', '风格', '人设']):
            return self._handle_switch_role(msg)
        
        # ========== 3. 查看体重/BMI ==========
        elif any(keyword in msg for keyword in ['体重', 'bmi', '重量', '记录']):
            return self._handle_get_weight()
        
        # ========== 4. 生成健康报告 ==========
        elif any(keyword in msg for keyword in ['周报', '月报', '报告', '分析', '健康']):
            return self._handle_get_report(msg)
        
        # ========== 5. 喝水提醒 ==========
        elif any(keyword in msg for keyword in ['喝水', '喝水提醒', '提醒喝水']):
            return self._handle_water_reminder()
        
        # ========== 6. 反馈菜品 ==========
        elif any(keyword in msg for keyword in ['喜欢', '不错', '好吃', '不喜欢', '难吃']):
            return self._handle_feedback(msg)
        
        # ========== 7. 帮助 ==========
        elif any(keyword in msg for keyword in ['帮助', 'help', '你能做什么', '怎么用', '功能']):
            return self._handle_help()
        
        # ========== 未识别：返回帮助 ==========
        else:
            return self._handle_help()

    def _handle_get_recommendation(self):
        """获取今日饮食推荐"""
        menu = self.engine.get_daily_menu(scene='home')
        message = self.generator.generate_daily_recommendation(
            menu['breakfast'],
            menu['lunch'],
            menu['dinner']
        )
        
        # 推送到飞书
        self.pusher.push_message(message)
        
        return {
            'action': '推送今日饮食推荐',
            'message': '✅ 已为您推送今日的 3 菜一汤饮食推荐到飞书！',
            'should_push': True
        }

    def _handle_switch_role(self, msg):
        """切换角色人设"""
        # 尝试匹配角色名
        for role in self.available_roles:
            if role in msg or role[:2] in msg:
                # 切换角色
                self.user_profile['role'] = role
                with open(os.path.join(self.base_path, 'data', 'user-profile.json'), 
                         'w', encoding='utf-8') as f:
                    json.dump(self.user_profile, f, ensure_ascii=False, indent=2)
                
                # 重新加载生成器
                from role_based_generator import RoleBasedMessageGenerator
                self.generator = RoleBasedMessageGenerator(self.base_path)
                
                return {
                    'action': f'切换角色为 {role}',
                    'message': f'✅ 已成功切换到 {role} 人设！\n后续所有推送都会用 {role} 的语气和您交流~',
                    'should_push': False
                }
        
        # 如果没有匹配到，返回可用角色列表
        role_list = '\n'.join([f"  • {role}" for role in self.available_roles])
        return {
            'action': '列出可用角色',
            'message': f'🎭 可用的角色人设：\n{role_list}\n\n您可以直接说："切换到高冷御姐" 来切换~',
            'should_push': False
        }

    def _handle_get_weight(self):
        """查看体重数据"""
        latest = self.tracker.get_latest_weight()
        records = self.tracker.weight_records
        
        if not records:
            return {
                'action': '查询体重数据',
                'message': '📝 您还没有记录过体重哦~\n直接回复数字即可记录，比如："90"',
                'should_push': False
            }
        
        # 取最近 7 条记录
        recent = records[-7:]
        history_text = '\n'.join([
            f"  {r['date']}: {r['weight']} kg (BMI: {r.get('bmi', 0):.1f})"
            for r in recent
        ])
        
        bmi_status = latest.get('bmiStatus', '未知')
        
        message = f"""⚖️ 您的体重数据：

📊 最新数据：
  • 体重：{latest.get('weight', 0)} kg
  • BMI：{latest.get('bmi', 0):.1f} ({bmi_status})

📋 最近记录：
{history_text}

💡 小贴士：记得每天坚持记录体重哦~
"""
        return {
            'action': '查询体重数据',
            'message': message,
            'should_push': False
        }

    def _handle_get_report(self, msg):
        """生成健康报告"""
        if '月' in msg or 'month' in msg:
            # 生成月报
            from health_report_generator import HealthReportGenerator
            reporter = HealthReportGenerator(self.base_path)
            report = reporter.generate_monthly_report()
            self.pusher.push_text(report)
            return {
                'action': '推送月度健康报告',
                'message': '✅ 已为您推送本月完整健康分析报告到飞书！',
                'should_push': True
            }
        else:
            # 默认生成周报
            from health_report_generator import HealthReportGenerator
            reporter = HealthReportGenerator(self.base_path)
            report = reporter.generate_weekly_report()
            self.pusher.push_text(report)
            return {
                'action': '推送周度健康报告',
                'message': '✅ 已为您推送本周完整健康分析报告到飞书！',
                'should_push': True
            }

    def _handle_water_reminder(self):
        """喝水提醒"""
        message = self.generator.generate_water_reminder()
        self.pusher.push_text(message)
        return {
            'action': '推送喝水提醒',
            'message': '💧 已为您推送喝水提醒！',
            'should_push': True
        }

    def _handle_feedback(self, msg):
        """用户反馈"""
        if '喜欢' in msg or '不错' in msg or '好吃' in msg:
            feedback_type = 'like'
            response = "😊 收到您的好评！后续会多推荐这类菜品~"
        else:
            feedback_type = 'dislike'
            response = "😅 不好意思您不喜欢！后续会优化推荐，减少这类菜品~"
        
        # 记录反馈（简化版）
        feedback_record = {
            'timestamp': datetime.now().isoformat(),
            'type': feedback_type,
            'message': msg
        }
        
        feedback_file = os.path.join(self.base_path, 'data', 'user-feedback.json')
        try:
            with open(feedback_file, 'r', encoding='utf-8') as f:
                feedbacks = json.load(f)
        except:
            feedbacks = []
        
        feedbacks.append(feedback_record)
        
        with open(feedback_file, 'w', encoding='utf-8') as f:
            json.dump(feedbacks, f, ensure_ascii=False, indent=2)
        
        return {
            'action': f'记录用户反馈：{feedback_type}',
            'message': response,
            'should_push': False
        }

    def _handle_help(self):
        """返回帮助说明"""
        help_text = """🤖 私人健康助理使用指南

📋 您可以这样和我说话：

🍽️ 获取饮食推荐
  • "今天吃什么"
  • "推荐一下午餐"
  • "给我发饮食推荐"

🎭 切换角色人设
  • "切换到高冷御姐"
  • "我想要可爱女友"
  • "换个角色风格"

⚖️ 查看体重数据
  • "看看我的体重"
  • "BMI 是多少"
  • "最近体重记录"

📊 获取健康报告
  • "生成周报"
  • "给我月报"
  • "健康分析报告"

💧 其他功能
  • "提醒我喝水"
  • "这个推荐不错"
  • "不喜欢这道菜"

❓ 帮助
  • "你能做什么"
  • "怎么用"
  • "功能列表"

💡 所有消息都会自动推送到您的飞书，无需额外操作~
"""
        return {
            'action': '返回使用帮助',
            'message': help_text,
            'should_push': False
        }


def interactive_shell():
    """交互式命令行测试"""
    print("=" * 60)
    print("🤖 私人健康助理 - 交互式测试")
    print("=" * 60)
    print()
    print("输入您的指令（输入 quit 退出）：")
    print()
    
    handler = UserInteractionHandler()
    
    while True:
        try:
            user_input = input(">>> ").strip()
            if not user_input:
                continue
            if user_input.lower() in ['quit', 'exit', 'q']:
                print("👋 再见！")
                break
            
            result = handler.handle_message(user_input)
            print()
            print("-" * 60)
            print(f"🎬 动作：{result['action']}")
            print("-" * 60)
            print()
            print(result['message'])
            print()
            
        except KeyboardInterrupt:
            print("\n👋 再见！")
            break
        except Exception as e:
            print(f"❌ 出错了：{e}")
            import traceback
            traceback.print_exc()


if __name__ == '__main__':
    interactive_shell()
