#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 飞书推送工具
统一管理所有飞书消息推送
"""

import os
import json
import subprocess
from datetime import datetime

class FeishuPusher:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_config()

    def load_config(self):
        """加载配置"""
        with open(os.path.join(self.base_path, 'data', 'config.json'), 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        self.user_id = self.config['push'].get('feishuUserId')
        self.initialized = self.config.get('initialized', False)

    def push_message(self, message, test_mode=False):
        """推送消息到飞书
        
        Args:
            message: 消息内容
            test_mode: 测试模式，只打印不发送
        """
        if not self.initialized:
            print("❌ 私人助理尚未初始化，无法推送")
            return False
        
        if not self.user_id:
            print("❌ 未配置飞书用户 ID，无法推送")
            return False
        
        if test_mode:
            print(f"\n📤 [测试模式] 推送到飞书用户: {self.user_id}")
            print("="*60)
            print(message)
            print("="*60)
            return True
        
        # 真实推送
        try:
            cmd = f'openclaw message send --channel feishu --to "{self.user_id}"'
            
            result = subprocess.run(
                cmd,
                input=message.encode('utf-8'),
                shell=True,
                capture_output=True,
                timeout=30
            )
            
            if result.returncode == 0:
                print(f"✅ 飞书推送成功")
                return True
            else:
                print(f"❌ 飞书推送失败: {result.stderr.decode('utf-8')}")
                return False
                
        except subprocess.TimeoutExpired:
            print("❌ 飞书推送超时")
            return False
        except Exception as e:
            print(f"❌ 飞书推送出错: {e}")
            return False

    def push_water_reminder(self, role_name=None, test_mode=False):
        """推送喝水提醒"""
        from role_system import RoleSystem
        
        if role_name is None:
            role_name = self.config['role']['current']
        
        role_system = RoleSystem(self.base_path)
        reminder = role_system.get_water_reminder(role_name)
        
        time_str = datetime.now().strftime('%H:%M')
        message = f"💧 喝水提醒 [{time_str}]\n\n{reminder}"
        
        return self.push_message(message, test_mode=test_mode)

    def push_daily_recommendation(self, menu, role_name=None, test_mode=False):
        """推送每日饮食推荐"""
        from role_system import RoleSystem
        
        if role_name is None:
            role_name = self.config['role']['current']
        
        role_system = RoleSystem(self.base_path)
        
        # 格式化消息
        message = role_system.format_daily_recommendation(menu, role_name)
        
        # 添加日期和场景
        date_str = datetime.now().strftime('%Y年%m月%d日')
        scene_text = "在家做饭 🏠" if menu['scene'] == 'home' else "在外就餐 🍽️"
        message = f"📅 {date_str}\n【{scene_text}】\n\n{message}"
        
        return self.push_message(message, test_mode=test_mode)

    def push_feedback_confirmation(self, feedback_type, content, test_mode=False):
        """推送反馈确认消息"""
        message = f"""✅ 反馈已收到！

反馈类型：{feedback_type}
反馈内容：{content}

感谢你的反馈，我会根据你的喜好调整后续推荐哦~ 😊
"""
        return self.push_message(message, test_mode=test_mode)

    def push_weight_recorded(self, weight, bmi, bmi_status, test_mode=False):
        """推送体重记录确认"""
        message = f"""✅ 体重已记录！

📊 今日体重：{weight} kg
🧮 BMI 指数：{bmi}
💪 体重状态：{bmi_status}

继续保持健康的生活方式哦！💪
"""
        return self.push_message(message, test_mode=test_mode)

    def push_weekly_report(self, report_data, test_mode=False):
        """推送周报"""
        message = f"""📊 每周健康报告

{report_data.get('summary', '')}

{report_data.get('details', '')}

祝你下周身体健康！💪
"""
        return self.push_message(message, test_mode=test_mode)


if __name__ == '__main__':
    # 测试推送工具
    pusher = FeishuPusher()
    
    print("=== 测试喝水提醒推送 ===")
    pusher.push_water_reminder(test_mode=True)
    
    print("\n=== 测试飞书用户 ID ===")
    print(f"用户 ID: {pusher.user_id}")
    print(f"已初始化: {pusher.initialized}")
