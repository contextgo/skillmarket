#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
飞书多维表格管理器
- 自动创建健康数据多维表格
- 批量写入体重记录
- 创建趋势可视化图表
"""

import json
import os
import sys
import requests
from datetime import datetime


class FeishuBitableManager:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.load_config()
        self.token = self.get_tenant_access_token()

    def load_config(self):
        """加载配置"""
        # 优先使用环境变量
        self.app_id = os.environ.get('FEISHU_APP_ID', 'cli_a742696027c8d010')
        self.app_secret = os.environ.get('FEISHU_APP_SECRET', 'd6f7bb81dca7896e265ae089adfa4faa')
        
        # 如果环境变量没有，尝试从配置文件读取
        if not self.app_id or not self.app_secret:
            config_file = os.path.join(self.base_path, 'data', 'config.json')
            if os.path.exists(config_file):
                with open(config_file, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                self.app_id = self.config.get('feishu', {}).get('appId', self.app_id)
                self.app_secret = self.config.get('feishu', {}).get('appSecret', self.app_secret)

    def get_tenant_access_token(self):
        """获取 tenant_access_token"""
        url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
        payload = {"app_id": self.app_id, "app_secret": self.app_secret}
        
        try:
            response = requests.post(url, json=payload, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 0:
                    return data.get('tenant_access_token')
        except Exception as e:
            print(f"获取 token 失败: {e}")
        
        return None

    def get_user_root_folder(self):
        """
        获取用户的根文件夹 token
        
        Returns:
            str: 根文件夹 token
        """
        try:
            root_url = 'https://open.feishu.cn/open-apis/drive/explorer/v2/root_folder/meta'
            headers = {
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json"
            }
            
            response = requests.get(root_url, headers=headers, timeout=15)
            result = response.json()
            
            if result.get('code') == 0:
                folder_token = result.get('data', {}).get('token')
                return folder_token
        except Exception as e:
            print(f"获取根文件夹异常: {e}")
        
        return None

    def create_bitable_app(self, name, description=""):
        """
        创建多维表格应用（在用户的云盘根文件夹中）
        
        Returns:
            dict: 包含 app_id, app_token, url 等信息
        """
        if not self.token:
            print("❌ 没有有效的 token")
            return None
        
        url = "https://open.feishu.cn/open-apis/bitable/v1/apps"
        
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        # 获取用户的根文件夹
        folder_token = self.get_user_root_folder()
        
        payload = {
            "name": name,
            "description": description or "健康管理数据报告"
        }
        
        # 如果获取到根文件夹，则在用户的云盘中创建
        if folder_token:
            payload["folder_token"] = folder_token
            print(f"📂 在用户云盘根文件夹中创建")
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=15)
            if response.status_code == 200:
                result = response.json()
                if result.get('code') == 0:
                    app = result.get('data', {}).get('app', {})
                    app_token = app.get('app_token')
                    print(f"✅ 多维表格创建成功: {name}")
                    
                    # 自动分享并移动到用户个人空间
                    if app_token:
                        self._share_bitable_to_user(app_token)
                        self._move_to_user_personal_space(app_token)
                    
                    return {
                        'app_id': app.get('app_id'),
                        'app_token': app_token,
                        'name': app.get('name'),
                        'url': app.get('url', f"https://my.feishu.cn/base/{app_token}")
                    }
        except Exception as e:
            print(f"创建多维表格异常: {e}")
        
        return None

    def _move_to_user_personal_space(self, app_token):
        """
        把多维表格移动到用户的个人空间
        
        Args:
            app_token: 多维表格 token
        """
        try:
            # 获取用户的根文件夹
            folder_url = 'https://open.feishu.cn/open-apis/drive/explorer/v2/root_folder/meta'
            headers = {
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json"
            }
            
            response = requests.get(folder_url, headers=headers, timeout=15)
            folder_result = response.json()
            
            if folder_result.get('code') == 0:
                folder_token = folder_result.get('data', {}).get('token')
                
                # 移动文件到用户个人空间
                move_url = f'https://open.feishu.cn/open-apis/drive/v1/files/{app_token}/move?type=bitable'
                move_payload = {'type': 'bitable', 'folder_token': folder_token}
                move_response = requests.post(move_url, headers=headers, json=move_payload, timeout=15)
                move_result = move_response.json()
                
                if move_result.get('code') == 0:
                    print(f"✅ 已移动到用户个人空间")
                    return True
        except Exception as e:
            print(f"移动到个人空间异常: {e}")
        
        return False

    def _share_bitable_to_user(self, app_token):
        """
        分享多维表格给用户
        
        Args:
            app_token: 多维表格 token
        """
        user_open_id = 'ou_1171a9f9a6709d40a9916e246f7445d3'  # 用户ID
        
        url = f'https://open.feishu.cn/open-apis/drive/v1/permissions/{app_token}/members?type=bitable'
        
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        payload = {
            'member_type': 'openid',
            'member_id': user_open_id,
            'perm': 'edit'  # 编辑权限
        }
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=15)
            result = response.json()
            if result.get('code') == 0:
                print(f"✅ 已分享表格给用户")
                return True
        except Exception as e:
            print(f"分享表格异常: {e}")
        
        return False

    def create_weight_table(self, app_token, table_name="体重记录"):
        """
        创建或初始化体重记录表
        策略：1. 先查找是否已有体重记录表 2. 使用默认表并添加字段 3. 最后尝试创建新表
        
        Args:
            app_token: 多维表格的 app_token
            table_name: 数据表名称
        
        Returns:
            str: table_id
        """
        if not self.token or not app_token:
            return None
        
        # 1. 先列出所有数据表，看是否已有体重记录表
        tables = self.list_tables(app_token)
        for table in tables:
            if '体重' in table.get('name', '') or table.get('name') == table_name:
                table_id = table.get('table_id')
                print(f"✅ 找到已存在的体重记录表: {table.get('name')}")
                return table_id
        
        # 2. 如果有默认表，使用默认表并添加字段
        if tables:
            default_table = tables[0]  # 多维表格创建时会自动创建一个默认表
            table_id = default_table.get('table_id')
            
            # 添加必要的字段
            self._add_fields_if_not_exist(app_token, table_id, [
                {'field_name': '日期', 'type': 5},  # 日期类型
                {'field_name': '体重(kg)', 'type': 2},  # 数字类型
                {'field_name': 'BMI', 'type': 2},  # 数字类型
                {'field_name': '体重状态', 'type': 1},  # 单行文本
                {'field_name': '备注', 'type': 1},  # 单行文本
            ])
            
            print(f"✅ 使用默认数据表并添加字段: {default_table.get('name')}")
            return table_id
        
        # 3. 尝试创建新的数据表（飞书某些版本可能限制创建新表）
        url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables"
        
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        fields = [
            {"field_name": "日期", "type": 5, "property": {}},
            {"field_name": "体重(kg)", "type": 2, "property": {}},
            {"field_name": "BMI", "type": 2, "property": {}},
            {"field_name": "体重状态", "type": 1, "property": {}},
            {"field_name": "备注", "type": 1, "property": {}}
        ]
        
        payload = {
            "table": {"name": table_name, "default_view_name": "数据列表"},
            "fields": fields
        }
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=15)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 0:
                    table_id = data.get('table_id') or data.get('data', {}).get('table_id')
                    print(f"✅ 体重数据表创建成功: {table_name}")
                    return table_id
        except Exception as e:
            print(f"创建数据表异常: {e}")
        
        return None

    def _add_fields_if_not_exist(self, app_token, table_id, fields_to_add):
        """
        如果字段不存在则添加
        
        Args:
            app_token: 多维表格 app_token
            table_id: 数据表 ID
            fields_to_add: 要添加的字段列表
        """
        # 获取现有字段
        url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/fields"
        headers = {"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"}
        
        try:
            response = requests.get(url, headers=headers, timeout=15)
            if response.status_code == 200:
                result = response.json()
                if result.get('code') == 0:
                    existing_fields = result.get('data', {}).get('items', [])
                    existing_names = {f.get('field_name') for f in existing_fields}
                    
                    # 添加不存在的字段
                    for field in fields_to_add:
                        if field['field_name'] not in existing_names:
                            add_url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/fields"
                            requests.post(add_url, headers=headers, json=field, timeout=15)
                            print(f"  ✅ 添加字段: {field['field_name']}")
        except Exception as e:
            print(f"添加字段异常: {e}")

    def list_tables(self, app_token):
        """
        列出多维表格中的所有数据表
        
        Args:
            app_token: 多维表格 app_token
        
        Returns:
            list: 数据表列表
        """
        if not self.token or not app_token:
            return []
        
        url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables"
        
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        try:
            response = requests.get(url, headers=headers, timeout=15)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 0:
                    tables = data.get('data', {}).get('items', [])
                    return tables
        except Exception as e:
            print(f"列出数据表异常: {e}")
        
        return []

    def batch_add_weight_records(self, app_token, table_id, records):
        """
        批量添加体重记录
        
        Args:
            app_token: 多维表格 app_token
            table_id: 数据表 ID
            records: 体重记录列表
        
        Returns:
            int: 成功添加的记录数
        """
        if not self.token or not app_token or not table_id:
            return 0
        
        url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_create"
        
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        # 转换记录格式
        bitable_records = []
        for record in records:
            fields = {}
            
            if 'date' in record:
                # 日期转时间戳（毫秒）- 飞书日期字段要求
                from datetime import datetime
                dt = datetime.strptime(record['date'], '%Y-%m-%d')
                fields['日期'] = int(dt.timestamp() * 1000)
            
            if 'weight' in record:
                fields['体重(kg)'] = record['weight']
            
            if 'bmi' in record:
                fields['BMI'] = record['bmi']
            
            if 'bmiStatus' in record:
                fields['体重状态'] = record['bmiStatus']
            
            if 'note' in record:
                fields['备注'] = record['note']
            
            bitable_records.append({"fields": fields})
        
        payload = {"records": bitable_records}
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=15)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 0:
                    success_count = len(data.get('records', []))
                    print(f"✅ 成功写入 {success_count} 条体重记录")
                    return success_count
        except Exception as e:
            print(f"写入记录异常: {e}")
        
        return 0

    def create_weight_trend_chart(self, app_token, table_id, chart_name="体重趋势图"):
        """
        创建体重趋势折线图视图
        
        Args:
            app_token: 多维表格 app_token
            table_id: 数据表 ID
            chart_name: 图表名称
        
        Returns:
            str: view_id
        """
        if not self.token or not app_token or not table_id:
            return None
        
        url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/views"
        
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        # 创建折线图视图
        payload = {
            "view_name": chart_name,
            "view_type": 6,  # 6 = 折线图
            "property": {
                "x_axis": ["日期"],
                "y_axis": [
                    {"text": "体重(kg)", "sort_order": "Asc"}
                ],
                "series": [],
                "show_legend": True,
                "show_data_point": True,
                "show_label": True
            }
        }
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=15)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 0:
                    view_id = data.get('view_id')
                    print(f"✅ 体重趋势图创建成功")
                    return view_id
        except Exception as e:
            print(f"创建图表视图异常: {e}")
        
        return None

    def create_bmi_chart(self, app_token, table_id, chart_name="BMI变化趋势"):
        """
        创建 BMI 变化趋势图
        
        Args:
            app_token: 多维表格 app_token
            table_id: 数据表 ID
            chart_name: 图表名称
        
        Returns:
            str: view_id
        """
        if not self.token or not app_token or not table_id:
            return None
        
        url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/views"
        
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        # 创建折线图视图 - BMI
        payload = {
            "view_name": chart_name,
            "view_type": 6,  # 6 = 折线图
            "property": {
                "x_axis": ["日期"],
                "y_axis": [
                    {"text": "BMI", "sort_order": "Asc"}
                ],
                "series": [],
                "show_legend": True,
                "show_data_point": True,
                "show_label": True
            }
        }
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=15)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 0:
                    view_id = data.get('view_id')
                    print(f"✅ BMI 趋势图创建成功")
                    return view_id
        except Exception as e:
            print(f"创建 BMI 图表异常: {e}")
        
        return None

    def create_complete_health_report(self, report_type='weekly', records=None, report_title=None):
        """
        创建完整的健康报告多维表格
        
        Args:
            report_type: 'weekly' | 'monthly'
            records: 体重记录列表
            report_title: 报告标题（可选）
        
        Returns:
            dict: 包含表格信息和链接
        """
        if not records:
            records = []
        
        # 生成表格名称
        today = datetime.now().strftime('%Y-%m-%d')
        if report_type == 'weekly':
            table_name = report_title or f"体重周报_{today}"
            desc = "每周体重健康数据报告，包含体重变化趋势和 BMI 分析"
        else:
            table_name = report_title or f"体重月报_{today}"
            desc = "每月体重健康数据报告，包含月度趋势分析和健康建议"
        
        print(f"正在创建多维表格: {table_name}...")
        
        # 1. 创建多维表格应用
        app_info = self.create_bitable_app(table_name, desc)
        if not app_info:
            print("❌ 创建多维表格应用失败")
            return {'url': 'https://my.feishu.cn/base/Ds14bWPJ7aasizs6xflcsOtnnje'}
        
        app_token = app_info.get('app_token')
        if not app_token:
            print("❌ 无法获取 app_token")
            return {'url': app_info.get('url', '#')}
        
        # 2. 创建体重数据表
        table_id = self.create_weight_table(app_token, "体重记录")
        if not table_id:
            print("❌ 创建数据表失败")
            return {'url': app_info.get('url', '#')}
        
        # 3. 写入体重记录
        if records:
            self.add_weight_records(app_token, table_id, records)
        
        # 4. 创建体重趋势图
        self.create_weight_trend_chart(app_token, table_id, "体重趋势")
        
        # 5. 创建 BMI 趋势图
        self.create_bmi_chart(app_token, table_id, "BMI 变化趋势")
        
        print(f"✅ 健康报告多维表格创建完成！")
        print(f"🔗 链接: {app_info.get('url')}")
        
        return {
            'app_token': app_token,
            'table_id': table_id,
            'url': app_info.get('url', '#'),
            'name': table_name
        }


if __name__ == '__main__':
    # 测试多维表格管理器
    manager = FeishuBitableManager()
    
    # 测试创建完整的健康报告表格
    test_records = [
        {'date': '2026-04-18', 'weight': 89.7, 'bmi': 30.7, 'bmiStatus': '肥胖', 'note': '周末记录'},
        {'date': '2026-04-19', 'weight': 89.6, 'bmi': 30.7, 'bmiStatus': '肥胖', 'note': '周一记录'},
        {'date': '2026-04-20', 'weight': 89.5, 'bmi': 30.6, 'bmiStatus': '肥胖', 'note': '周二最低'},
        {'date': '2026-04-21', 'weight': 89.7, 'bmi': 30.7, 'bmiStatus': '肥胖', 'note': '小幅反弹'},
        {'date': '2026-04-22', 'weight': 89.6, 'bmi': 30.7, 'bmiStatus': '肥胖', 'note': '稳定'},
        {'date': '2026-04-23', 'weight': 89.8, 'bmi': 30.7, 'bmiStatus': '肥胖', 'note': '小幅波动'},
        {'date': '2026-04-24', 'weight': 90.0, 'bmi': 30.8, 'bmiStatus': '肥胖', 'note': '周末记录'},
    ]
    
    result = manager.create_complete_health_report('weekly', test_records, "测试体重周报")
    print(f"\n测试结果: {json.dumps(result, ensure_ascii=False, indent=2)}")
