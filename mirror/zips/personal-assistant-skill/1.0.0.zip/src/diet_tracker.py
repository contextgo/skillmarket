#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 饮食打卡与学习系统
记录用户每天实际吃了什么，自动学习偏好，改进推荐
"""

import os
import json
from datetime import datetime, timedelta
from collections import Counter


class DietTracker:
    """饮食打卡与学习系统"""
    
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.data_path = os.path.join(base_path, 'data', 'diet-records.json')
        
        # 确保数据文件存在
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        if not os.path.exists(self.data_path):
            with open(self.data_path, 'w', encoding='utf-8') as f:
                json.dump([], f, ensure_ascii=False, indent=2)
        
        # 加载菜谱数据
        with open(os.path.join(base_path, 'recipes', 'home-cooking.json'), 'r', encoding='utf-8') as f:
            self.home_recipes = json.load(f)
        
        with open(os.path.join(base_path, 'recipes', 'eating-out.json'), 'r', encoding='utf-8') as f:
            self.out_recipes = json.load(f)
        
        # 所有菜品的索引
        self.all_dishes = {d['name']: d for d in self.home_recipes + self.out_recipes}
    
    def _load_records(self):
        """加载打卡记录"""
        with open(self.data_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def _save_records(self, records):
        """保存打卡记录"""
        with open(self.data_path, 'w', encoding='utf-8') as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
    
    def add_record(self, dish_name, meal_type='dinner', rating=5, note='', date=None):
        """添加饮食打卡记录
        
        Args:
            dish_name: 菜品名称
            meal_type: 餐次 (breakfast/lunch/dinner/snack)
            rating: 评分 1-5 (5 最喜欢)
            note: 备注
            date: 日期，默认今天
        """
        if date is None:
            date = datetime.now().strftime('%Y-%m-%d')
        
        # 查找菜品信息
        dish_info = self.all_dishes.get(dish_name, {
            'name': dish_name,
            'category': '自定义',
            'tags': [],
            'calories': None
        })
        
        record = {
            'date': date,
            'meal_type': meal_type,
            'dish_name': dish_name,
            'dish_info': dish_info,
            'rating': rating,
            'note': note,
            'timestamp': datetime.now().isoformat()
        }
        
        records = self._load_records()
        records.append(record)
        self._save_records(records)
        
        # 自动学习：根据评分调整菜品权重
        self._learn_from_rating(dish_name, rating)
        
        print(f"✅ 已记录: {dish_name} ({meal_type}) - 评分 {rating}/5")
        return record
    
    def _learn_from_rating(self, dish_name, rating):
        """根据评分自动学习用户偏好
        
        - 评分 4-5: 喜欢，增加推荐权重
        - 评分 2-3: 一般，权重不变
        - 评分 1: 不喜欢，减少推荐权重
        """
        feedback_path = os.path.join(self.base_path, 'data', 'feedback-records.json')
        
        if not os.path.exists(feedback_path):
            feedbacks = []
        else:
            with open(feedback_path, 'r', encoding='utf-8') as f:
                feedbacks = json.load(f)
        
        if rating >= 4:
            # 喜欢这道菜
            feedback = {
                'type': 'like',
                'content': f"打卡记录：喜欢 {dish_name}（评分 {rating}）",
                'dishName': dish_name,
                'applied': True,
                'auto_learn': True,
                'timestamp': datetime.now().isoformat()
            }
            feedbacks.append(feedback)
        elif rating <= 2:
            # 不喜欢
            feedback = {
                'type': 'dislike',
                'content': f"打卡记录：不喜欢 {dish_name}（评分 {rating}）",
                'dishName': dish_name,
                'applied': True,
                'auto_learn': True,
                'timestamp': datetime.now().isoformat()
            }
            feedbacks.append(feedback)
        
        with open(feedback_path, 'w', encoding='utf-8') as f:
            json.dump(feedbacks, f, ensure_ascii=False, indent=2)
    
    def get_day_records(self, date=None):
        """获取某天的打卡记录"""
        if date is None:
            date = datetime.now().strftime('%Y-%m-%d')
        
        records = self._load_records()
        day_records = [r for r in records if r['date'] == date]
        
        # 按餐次排序
        meal_order = {'breakfast': 0, 'lunch': 1, 'dinner': 2, 'snack': 3}
        day_records.sort(key=lambda x: meal_order.get(x['meal_type'], 99))
        
        return day_records
    
    def get_week_records(self, end_date=None):
        """获取最近一周的打卡记录"""
        if end_date is None:
            end_date = datetime.now()
        
        start_date = end_date - timedelta(days=6)
        records = self._load_records()
        
        week_records = []
        for i in range(7):
            day = (start_date + timedelta(days=i)).strftime('%Y-%m-%d')
            day_records = [r for r in records if r['date'] == day]
            week_records.append({
                'date': day,
                'records': day_records,
                'count': len(day_records)
            })
        
        return week_records
    
    def get_favorite_dishes(self, top_n=10):
        """获取最喜欢的菜品（基于评分统计）"""
        records = self._load_records()
        
        # 统计每个菜品的平均评分和出现次数
        dish_stats = {}
        for record in records:
            name = record['dish_name']
            rating = record['rating']
            
            if name not in dish_stats:
                dish_stats[name] = {'count': 0, 'total_rating': 0, 'avg_rating': 0}
            
            dish_stats[name]['count'] += 1
            dish_stats[name]['total_rating'] += rating
        
        # 计算平均分并排序
        for name in dish_stats:
            dish_stats[name]['avg_rating'] = dish_stats[name]['total_rating'] / dish_stats[name]['count']
        
        sorted_dishes = sorted(
            dish_stats.items(),
            key=lambda x: (x[1]['avg_rating'], x[1]['count']),
            reverse=True
        )
        
        return [{'name': name, **stats} for name, stats in sorted_dishes[:top_n]]
    
    def get_nutrition_summary(self, date=None):
        """获取某天的营养汇总"""
        records = self.get_day_records(date)
        
        total_calories = 0
        calorie_count = 0
        
        for record in records:
            calories = record['dish_info'].get('calories')
            if calories and isinstance(calories, (int, float)):
                total_calories += calories
                calorie_count += 1
        
        return {
            'total_calories': total_calories,
            'meal_count': len(records),
            'calorie_count': calorie_count,
            'avg_calories_per_meal': total_calories / max(1, calorie_count) if calorie_count else 0
        }
    
    def generate_diet_report(self, days=7):
        """生成饮食报告"""
        end_date = datetime.now()
        records = self._load_records()
        
        # 统计周期内的记录
        start_date = end_date - timedelta(days=days - 1)
        period_records = []
        for record in records:
            record_date = datetime.strptime(record['date'], '%Y-%m-%d')
            if start_date <= record_date <= end_date:
                period_records.append(record)
        
        # 统计信息
        total_meals = len(period_records)
        total_days = min(days, (end_date - start_date).days + 1)
        avg_meals_per_day = total_meals / total_days if total_days > 0 else 0
        
        # 最喜欢的菜品
        favorites = self.get_favorite_dishes(5)
        
        # 营养统计
        total_calories = 0
        for record in period_records:
            calories = record['dish_info'].get('calories')
            if calories and isinstance(calories, (int, float)):
                total_calories += calories
        
        report = f"""📊 近 {days} 天饮食报告

📈 统计信息：
• 打卡餐次：{total_meals} 次
• 平均每天：{avg_meals_per_day:.1f} 餐
• 总热量：约 {total_calories} 大卡
• 日均热量：约 {total_calories / max(1, total_days):.0f} 大卡

⭐ 最喜欢的菜品 Top 5：
"""
        
        for i, dish in enumerate(favorites, 1):
            report += f"{i}. {dish['name']} - 平均 {dish['avg_rating']:.1f}/5 分（{dish['count']} 次）\n"
        
        report += "\n💡 建议：\n"
        
        if avg_meals_per_day < 2:
            report += "• 建议每天按时吃三餐，保持规律饮食\n"
        elif avg_meals_per_day >= 3:
            report += "• 饮食很规律，继续保持！\n"
        
        daily_calories = total_calories / max(1, total_days)
        if daily_calories > 2000:
            report += "• 热量摄入偏高，建议适当控制\n"
        elif daily_calories < 1200:
            report += "• 热量摄入偏低，注意营养均衡\n"
        else:
            report += "• 热量摄入适中，很健康！\n"
        
        return report
    
    def print_day_summary(self, date=None):
        """打印某天的饮食汇总"""
        if date is None:
            date = datetime.now().strftime('%Y-%m-%d')
        
        records = self.get_day_records(date)
        nutrition = self.get_nutrition_summary(date)
        
        meal_names = {
            'breakfast': '🌅 早餐',
            'lunch': '☀️ 午餐',
            'dinner': '🌙 晚餐',
            'snack': '🍪 加餐'
        }
        
        print(f"\n{'='*60}")
        print(f"🍽️ {date} 饮食打卡")
        print(f"{'='*60}\n")
        
        if not records:
            print("  今天还没有打卡记录哦~\n")
            return
        
        for record in records:
            meal = meal_names.get(record['meal_type'], record['meal_type'])
            rating = '⭐' * record['rating']
            calories = record['dish_info'].get('calories', '')
            calories_str = f" ({calories} 大卡)" if calories else ""
            
            print(f"  {meal}: {record['dish_name']}")
            print(f"       评分: {rating} {calories_str}")
            if record.get('note'):
                print(f"       备注: {record['note']}")
            print()
        
        print(f"  📊 汇总: {nutrition['meal_count']} 餐，约 {nutrition['total_calories']} 大卡")
        print(f"{'='*60}\n")


if __name__ == '__main__':
    tracker = DietTracker()
    
    # 测试添加记录
    print("添加测试记录...")
    tracker.add_record('番茄炒蛋', 'lunch', 5, '很好吃！')
    tracker.add_record('青椒肉丝', 'dinner', 4)
    
    # 打印今天的汇总
    tracker.print_day_summary()
    
    # 打印喜欢的菜品
    print("\n最喜欢的菜品:")
    favorites = tracker.get_favorite_dishes(5)
    for i, dish in enumerate(favorites, 1):
        print(f"  {i}. {dish['name']} - {dish['avg_rating']:.1f}/5")
