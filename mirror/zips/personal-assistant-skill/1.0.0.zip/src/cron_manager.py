#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 - 定时任务管理器
管理 crontab 定时任务的创建、查看、启用、禁用、删除
"""

import os
import json
import subprocess
from datetime import datetime

class CronManager:
    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.base_path = base_path
        self.python_path = "/usr/bin/env python3"
        self.script_path = os.path.join(self.base_path, "main.py")
        self.log_path = os.path.join(self.base_path, "logs")
        
        # 确保日志目录存在
        os.makedirs(self.log_path, exist_ok=True)
        
        # 任务定义模板 - 使用已验证成功的推送脚本
        run_push_script = os.path.join(self.base_path, "scripts", "feishu_direct_push.py")
        
        self.task_templates = {
            "daily_push": {
                "name": "每日饮食推荐推送",
                "description": "每天早上 8:00 推送当日饮食建议",
                "time": "0 8 * * *",
                "command": f"cd {self.base_path} && {self.python_path} scripts/run_push.py daily",
                "log_file": os.path.join(self.log_path, "daily_push.log")
            },
            "water_reminder": {
                "name": "喝水提醒",
                "description": "每天 9/11/13/15/17/19/21 点提醒喝水",
                "time": "0 9,11,13,15,17,19,21 * * *",
                "command": f"cd {self.base_path} && {self.python_path} scripts/run_push.py water",
                "log_file": os.path.join(self.log_path, "water_reminder.log")
            },
            "weekly_report": {
                "name": "每周健康报告",
                "description": "每周日晚 21:00 生成并推送周报",
                "time": "0 21 * * 0",
                "command": f"cd {self.base_path} && {self.python_path} scripts/run_push.py weekly",
                "log_file": os.path.join(self.log_path, "weekly_report.log")
            },
            "monthly_report": {
                "name": "每月健康报告",
                "description": "每月最后一天 22:00 生成并推送月报",
                "time": "0 22 28-31 * *",
                "command": f"cd {self.base_path} && {self.python_path} {self.script_path} weight --monthly",
                "condition": '[ "$(date +%d -d tomorrow)" = "01" ] && ',
                "log_file": os.path.join(self.log_path, "monthly_report.log")
            },
            "data_sync": {
                "name": "数据同步到多维表格",
                "description": "每天凌晨 2:00 同步数据到飞书多维表格",
                "time": "0 2 * * *",
                "command": f"cd {self.base_path} && {self.python_path} {self.script_path} bitable --sync-weight && {self.python_path} {self.script_path} bitable --sync-feedback",
                "log_file": os.path.join(self.log_path, "data_sync.log")
            }
        }
        
        # 任务标记，用于识别我们创建的 cron 任务
        self.job_marker = "PERSONAL_ASSISTANT_CRON"

    def _get_crontab(self):
        """获取当前 crontab 内容"""
        try:
            result = subprocess.run(
                ["crontab", "-l"],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                return result.stdout
            return ""
        except Exception as e:
            print(f"⚠️  获取 crontab 失败: {e}")
            return ""

    def _write_crontab(self, content):
        """写入 crontab"""
        try:
            process = subprocess.Popen(
                ["crontab", "-"],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            _, stderr = process.communicate(input=content)
            
            if process.returncode == 0:
                return True, "写入成功"
            else:
                return False, stderr
        except Exception as e:
            return False, str(e)

    def _build_cron_job(self, task_id, template):
        """构建 cron 任务行 - 优化输出，便于日志查看"""
        comment = f"# {self.job_marker} | {task_id} | {template['name']} | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        # 构建命令
        command = template['command']
        if 'condition' in template:
            command = f"{template['condition']} {command}"
        
        # 添加日志重定向，同时输出到 stdout 和日志文件
        log_file = template['log_file']
        # 使用 tee 命令同时输出到控制台和日志，便于飞书捕获
        full_command = f"{command} 2>&1 | tee -a {log_file}"
        
        cron_line = f"{template['time']} {full_command}"
        
        return f"{comment}\n{cron_line}\n"

    def list_jobs(self):
        """列出所有定时任务"""
        crontab_content = self._get_crontab()
        jobs = []
        
        lines = crontab_content.split('\n')
        
        for i, line in enumerate(lines):
            if self.job_marker in line:
                # 解析标记行
                parts = line.split('|')
                if len(parts) >= 3:
                    task_id = parts[1].strip()
                    task_name = parts[2].strip()
                    
                    # 找到下一行的 cron 命令
                    cron_line = ""
                    for j in range(i+1, len(lines)):
                        if lines[j].strip() and not lines[j].strip().startswith('#'):
                            cron_line = lines[j].strip()
                            break
                    
                    # 获取任务模板信息
                    template = self.task_templates.get(task_id, {})
                    
                    jobs.append({
                        'id': task_id,
                        'name': task_name,
                        'description': template.get('description', ''),
                        'time': template.get('time', cron_line.split(' ')[0] + ' ' + ' '.join(cron_line.split(' ')[1:5]) if cron_line else ''),
                        'cron_line': cron_line,
                        'enabled': True
                    })
        
        return jobs

    def add_job(self, task_id):
        """添加定时任务"""
        if task_id not in self.task_templates:
            return False, f"任务 '{task_id}' 不存在，可选任务: {', '.join(self.task_templates.keys())}"
        
        # 检查是否已存在
        existing_jobs = self.list_jobs()
        if any(job['id'] == task_id for job in existing_jobs):
            return False, f"任务 '{task_id}' 已存在"
        
        # 获取模板
        template = self.task_templates[task_id]
        
        # 构建 cron 任务
        cron_job = self._build_cron_job(task_id, template)
        
        # 写入 crontab
        current_crontab = self._get_crontab()
        new_crontab = current_crontab.rstrip('\n') + '\n\n' + cron_job
        
        success, message = self._write_crontab(new_crontab)
        
        if success:
            return True, f"任务 '{template['name']}' 添加成功"
        else:
            return False, f"任务添加失败: {message}"

    def remove_job(self, task_id):
        """删除定时任务"""
        crontab_content = self._get_crontab()
        lines = crontab_content.split('\n')
        
        new_lines = []
        removed = False
        removed_name = ""
        
        i = 0
        while i < len(lines):
            line = lines[i]
            
            if self.job_marker in line and f"| {task_id} |" in line:
                # 找到标记行，解析任务名
                parts = line.split('|')
                if len(parts) >= 3:
                    removed_name = parts[2].strip()
                
                # 删除标记行
                removed = True
                i += 1
                
                # 删除后续的 cron 命令行
                while i < len(lines):
                    if lines[i].strip() and not lines[i].strip().startswith('#'):
                        i += 1  # 删除 cron 行
                        break
                    elif lines[i].strip():
                        break  # 遇到其他注释，停止删除
                    else:
                        i += 1  # 跳过空行
            else:
                new_lines.append(line)
                i += 1
        
        if not removed:
            return False, f"任务 '{task_id}' 不存在"
        
        # 写入新的 crontab
        new_crontab = '\n'.join(new_lines)
        success, message = self._write_crontab(new_crontab)
        
        if success:
            return True, f"任务 '{removed_name}' 已删除"
        else:
            return False, f"任务删除失败: {message}"

    def enable_job(self, task_id):
        """启用任务（取消注释）"""
        # 对于简单的实现，这里等同于 add_job
        return self.add_job(task_id)

    def disable_job(self, task_id):
        """禁用任务（注释掉）"""
        # 对于简单的实现，这里等同于 remove_job
        return self.remove_job(task_id)

    def add_all_jobs(self):
        """添加所有默认任务"""
        results = []
        
        for task_id in ['daily_push', 'water_reminder', 'weekly_report', 'data_sync']:
            success, message = self.add_job(task_id)
            results.append({
                'task_id': task_id,
                'success': success,
                'message': message
            })
        
        return results

    def remove_all_jobs(self):
        """删除所有任务"""
        crontab_content = self._get_crontab()
        lines = crontab_content.split('\n')
        
        new_lines = []
        removed_count = 0
        
        i = 0
        while i < len(lines):
            line = lines[i]
            
            if self.job_marker in line:
                # 删除标记行和后续的 cron 行
                removed_count += 1
                i += 1
                
                # 删除后续的 cron 命令行
                while i < len(lines):
                    if lines[i].strip() and not lines[i].strip().startswith('#'):
                        i += 1
                        break
                    elif lines[i].strip():
                        break
                    else:
                        i += 1
            else:
                new_lines.append(line)
                i += 1
        
        if removed_count == 0:
            return True, "没有找到可删除的任务"
        
        # 写入新的 crontab
        new_crontab = '\n'.join(new_lines)
        success, message = self._write_crontab(new_crontab)
        
        if success:
            return True, f"已删除 {removed_count} 个任务"
        else:
            return False, f"删除失败: {message}"

    def print_jobs(self):
        """打印所有任务列表"""
        jobs = self.list_jobs()
        
        print("\n" + "="*80)
        print("⏰ 私人助理定时任务列表")
        print("="*80)
        
        if not jobs:
            print("\n  暂无定时任务")
            print("\n  可用任务模板:")
            for task_id, template in self.task_templates.items():
                print(f"    - {task_id}: {template['name']}")
                print(f"      {template['description']}")
        else:
            print(f"\n  共 {len(jobs)} 个定时任务:\n")
            
            for i, job in enumerate(jobs, 1):
                status_icon = "✅" if job['enabled'] else "❌"
                print(f"  {status_icon} [{i}] {job['name']} ({job['id']})")
                print(f"      描述: {job['description']}")
                print(f"      时间: {job['time']}")
                print()
        
        print("="*80)
        print()

    def print_available_templates(self):
        """打印可用的任务模板"""
        print("\n" + "="*80)
        print("📋 可用的任务模板")
        print("="*80)
        print()
        
        for task_id, template in self.task_templates.items():
            print(f"  🔹 {task_id}")
            print(f"     名称: {template['name']}")
            print(f"     描述: {template['description']}")
            print(f"     时间: {template['time']}")
            print()
        
        print("="*80)
        print()


if __name__ == '__main__':
    # 测试定时任务管理器
    cron = CronManager()
    
    print("=== 查看当前任务 ===")
    cron.print_jobs()
    
    print("\n=== 可用任务模板 ===")
    cron.print_available_templates()
