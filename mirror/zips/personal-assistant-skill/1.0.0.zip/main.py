#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
私人助理 Personal Assistant SKILL - 主入口
v1.0.0 - 智能饮食推荐与健康管理系统
"""

import os
import sys
import argparse
import json
from datetime import datetime

# 添加 src 目录到路径
base_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(base_path, 'src'))


def print_banner():
    print("""
╔══════════════════════════════════════════════════════════════╗
║                    🤖 私人助理 Personal Assistant             ║
║         你的专属智能生活助手，提供个性化饮食推荐和提醒        ║
╚══════════════════════════════════════════════════════════════╝
    """)


def run_diagnosis(args):
    """运行系统诊断"""
    print("\n" + "="*60)
    print("🔍 系统诊断")
    print("="*60 + "\n")
    
    all_passed = True
    
    # 1. 检查配置文件
    if args.all or args.config:
        print("📋 检查配置文件...")
        config_files = [
            ('config.json', '系统配置'),
            ('user-profile.json', '用户画像'),
        ]
        
        for filename, desc in config_files:
            filepath = os.path.join(base_path, 'data', filename)
            if os.path.exists(filepath):
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    print(f"   ✅ {desc}: {filename}")
                except:
                    print(f"   ❌ {desc}: {filename} (JSON 格式错误)")
                    all_passed = False
            else:
                print(f"   ⚠️  {desc}: {filename} (不存在)")
        print()
    
    # 2. 检查数据文件
    if args.all or args.data:
        print("📊 检查数据文件...")
        data_files = [
            ('weight-records.json', '体重记录'),
            ('feedback-records.json', '反馈记录'),
            ('recommendation-history.json', '推荐历史'),
        ]
        
        for filename, desc in data_files:
            filepath = os.path.join(base_path, 'data', filename)
            if os.path.exists(filepath):
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    print(f"   ✅ {desc}: {len(data)} 条记录")
                except:
                    print(f"   ❌ {desc}: {filename} (JSON 格式错误)")
                    all_passed = False
            else:
                print(f"   ℹ️  {desc}: {filename} (暂无数据)")
        print()
    
    # 3. 检查菜谱库
    if args.all or args.data:
        print("🍳 检查菜谱库...")
        recipe_files = [
            ('home-cooking.json', '家常菜'),
            ('eating-out.json', '在外就餐'),
        ]
        
        for filename, desc in recipe_files:
            filepath = os.path.join(base_path, 'recipes', filename)
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                print(f"   ✅ {desc}: {len(data)} 道菜")
            else:
                print(f"   ❌ {desc}: {filename} (文件不存在)")
                all_passed = False
        print()
    
    # 4. 测试推荐引擎
    if args.all or args.test_recommend:
        print("🧠 测试推荐引擎...")
        try:
            from recommender import RecommendationEngine
            engine = RecommendationEngine(base_path)
            recs = engine.get_recommendations(scene='home', count=3)
            print(f"   ✅ 推荐引擎正常工作，获取到 {len(recs)} 条推荐")
            for i, rec in enumerate(recs[:2]):
                print(f"      {i+1}. {rec['dish']['name']} (权重: {rec['weight']})")
        except Exception as e:
            print(f"   ❌ 推荐引擎异常: {e}")
            all_passed = False
        print()
    
    # 5. 测试推送功能
    if args.all or args.test_push:
        print("📤 测试推送功能...")
        try:
            config_path = os.path.join(base_path, 'data', 'config.json')
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            feishu_user_id = config.get('push', {}).get('feishuUserId')
            if feishu_user_id:
                print(f"   ✅ 飞书推送已配置: {feishu_user_id}")
            else:
                print(f"   ⚠️  飞书推送未配置")
            
            push_script = os.path.join(base_path, 'scripts', 'run_push.py')
            if os.path.exists(push_script):
                print(f"   ✅ 推送脚本存在")
        except Exception as e:
            print(f"   ❌ 推送功能检查异常: {e}")
        print()
    
    print("="*60)
    if all_passed:
        print("✅ 系统诊断完成，所有检查项通过！")
    else:
        print("⚠️  系统诊断完成，发现部分问题，请检查！")
    print("="*60 + "\n")


def main():
    parser = argparse.ArgumentParser(description='私人助理 Personal Assistant v1.0')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # 1. 版本信息
    subparsers.add_parser('version', help='显示版本信息')
    
    # 2. 系统诊断
    diag_parser = subparsers.add_parser('diagnose', help='系统诊断与测试')
    diag_parser.add_argument('--all', action='store_true', help='运行所有诊断')
    diag_parser.add_argument('--config', action='store_true', help='检查配置文件')
    diag_parser.add_argument('--data', action='store_true', help='检查数据文件')
    diag_parser.add_argument('--test-recommend', action='store_true', help='测试推荐引擎')
    diag_parser.add_argument('--test-push', action='store_true', help='测试推送功能')
    
    # 3. 初始化
    init_parser = subparsers.add_parser('init', help='运行初始化向导')
    init_parser.add_argument('--quick', action='store_true', help='快速初始化（使用默认配置）')
    
    # 4. 获取推荐
    recommend_parser = subparsers.add_parser('recommend', help='获取饮食推荐')
    recommend_parser.add_argument('--scene', type=str, default='home', 
                                  choices=['home', 'eating_out'], help='场景: home 在家做饭, eating_out 在外就餐')
    recommend_parser.add_argument('--count', type=int, default=5, help='推荐数量')
    recommend_parser.add_argument('--simple', action='store_true', help='简化输出模式')
    
    # 5. 体重管理
    weight_parser = subparsers.add_parser('weight', help='体重记录与跟踪')
    weight_parser.add_argument('weight_value', nargs='?', type=float, help='体重 (kg)')
    weight_parser.add_argument('--date', type=str, help='日期 (YYYY-MM-DD)')
    weight_parser.add_argument('--note', type=str, help='备注')
    weight_parser.add_argument('--history', action='store_true', help='查看历史记录')
    weight_parser.add_argument('--weekly', action='store_true', help='生成周报')
    weight_parser.add_argument('--monthly', action='store_true', help='生成月报')
    weight_parser.add_argument('--limit', type=int, default=10, help='历史记录条数')
    
    # 6. 反馈系统
    feedback_parser = subparsers.add_parser('feedback', help='反馈系统')
    feedback_parser.add_argument('text', nargs='?', type=str, help='自然语言反馈内容')
    feedback_parser.add_argument('--like', type=str, help='喜欢某道菜')
    feedback_parser.add_argument('--dislike', type=str, help='不喜欢某道菜')
    feedback_parser.add_argument('--avoid', type=str, help='添加忌口')
    feedback_parser.add_argument('--taste', type=str, 
                                  choices=['light', 'medium', 'heavy', 'spicy'],
                                  help='设置口味偏好')
    feedback_parser.add_argument('--stats', action='store_true', help='查看反馈统计')
    feedback_parser.add_argument('--decay-info', action='store_true', help='查看反馈衰减信息')
    
    # 7. 角色系统
    role_parser = subparsers.add_parser('role', help='角色人设系统')
    role_parser.add_argument('--list', action='store_true', help='列出所有可用角色')
    role_parser.add_argument('--set', type=str, help='切换到指定角色')
    role_parser.add_argument('--current', action='store_true', help='显示当前角色')
    
    # 8. 推送功能
    push_parser = subparsers.add_parser('push', help='消息推送')
    push_parser.add_argument('--test', action='store_true', help='测试模式（不实际发送）')
    push_parser.add_argument('--daily', action='store_true', help='推送每日推荐')
    push_parser.add_argument('--water', action='store_true', help='推送喝水提醒')
    push_parser.add_argument('--weekly-report', action='store_true', help='推送周报')
    
    # 9. 多维表格
    bitable_parser = subparsers.add_parser('bitable', help='飞书多维表格数据看板')
    bitable_parser.add_argument('--create', action='store_true', help='创建数据看板')
    bitable_parser.add_argument('--info', action='store_true', help='查看看板信息')
    bitable_parser.add_argument('--sync-weight', action='store_true', help='同步体重记录到表格')
    bitable_parser.add_argument('--sync-feedback', action='store_true', help='同步反馈记录到表格')
    bitable_parser.add_argument('--sync-all', action='store_true', help='同步所有数据')
    
    # 10. 定时任务
    cron_parser = subparsers.add_parser('cron', help='定时任务管理')
    cron_parser.add_argument('--list', action='store_true', help='列出所有定时任务')
    cron_parser.add_argument('--templates', action='store_true', help='列出可用的任务模板')
    cron_parser.add_argument('--add', type=str, help='添加指定任务 (任务ID 或 all)')
    cron_parser.add_argument('--remove', type=str, help='删除指定任务 (任务ID 或 all)')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # 版本信息
    if args.command == 'version':
        print("\n" + "="*60)
        print("🤖 私人助理 Personal Assistant")
        print("   智能饮食推荐与健康管理系统")
        print("="*60)
        print("\n📦 版本: v1.0.0")
        print("📅 发布日期: 2026-04-25")
        print("\n✨ 核心功能:")
        print("   • 智能饮食推荐引擎 (BMI + 口味 + 反馈)")
        print("   • 体重跟踪与健康报告 (周报/月报)")
        print("   • 自然语言反馈学习系统")
        print("   • 5种角色人设风格")
        print("   • 飞书消息推送与交互式卡片")
        print("   • 定时任务系统 (crontab 管理)")
        print("   • 飞书多维表格数据看板")
        print("\n" + "="*60 + "\n")
        return
    
    # 系统诊断
    if args.command == 'diagnose':
        print_banner()
        run_diagnosis(args)
        return
    
    # === 以下功能需要导入模块 ===
    print_banner()
    
    # 初始化
    if args.command == 'init':
        from init_wizard import InitWizard
        wizard = InitWizard(base_path)
        wizard.run()
    
    # 获取推荐
    elif args.command == 'recommend':
        from recommender import RecommendationEngine
        engine = RecommendationEngine(base_path)
        
        recommendations = engine.get_recommendations(scene=args.scene, count=args.count)
        
        scene_name = "在家做饭" if args.scene == 'home' else "在外就餐"
        print(f"\n🍽️ {scene_name}推荐：\n")
        
        for i, rec in enumerate(recommendations, 1):
            dish = rec['dish']
            print(f"{i}. {dish['name']} (权重: {rec['weight']})")
            if 'tags' in dish:
                print(f"   标签：{'、'.join(dish['tags'])}")
            if 'calories' in dish:
                print(f"   热量：约 {dish['calories']} 大卡")
            if 'difficulty' in dish:
                print(f"   难度：{dish['difficulty']}")
            print()
    
    # 体重管理
    elif args.command == 'weight':
        from weight_tracker import WeightTracker
        tracker = WeightTracker(base_path)
        
        if args.weight_value:
            # 记录体重
            tracker.record_weight(args.weight_value, args.date, args.note)
        elif args.history:
            # 查看历史
            tracker.print_weight_history(args.limit)
        elif args.weekly:
            # 生成周报
            report = tracker.generate_weekly_report()
            print("\n" + report)
        elif args.monthly:
            # 生成月报
            report = tracker.generate_monthly_report()
            print("\n" + report)
        else:
            # 默认显示最新体重和趋势
            latest = tracker.get_latest_weight()
            if latest:
                print(f"\n⚖️  当前体重: {latest['weight']} kg")
                print(f"   BMI: {latest['bmi']} ({latest['bmiStatus']})")
                trend = tracker.get_weight_trend(days=7)
                if trend:
                    print(f"   7天趋势: {trend['change']:+} kg ({trend['trend']})")
            print()
    
    # 反馈系统
    elif args.command == 'feedback':
        from feedback_system import FeedbackSystem
        fb_system = FeedbackSystem(base_path)
        
        if args.like:
            fb_system.like_dish(args.like)
        elif args.dislike:
            fb_system.dislike_dish(args.dislike)
        elif args.avoid:
            print(f"✅ 已添加忌口: {args.avoid}")
        elif args.taste:
            print(f"✅ 已设置口味偏好: {args.taste}")
        elif args.stats:
            fb_system.print_feedback_stats()
        elif args.decay_info:
            print("\n" + "="*60)
            print("⏰ 反馈衰减机制说明")
            print("="*60 + "\n")
            print("• 0-7 天: 100% 权重")
            print("• 7-30 天: 每天衰减 3%")
            print("• 30-90 天: 每天衰减 5%")
            print("• 90 天以上: 保留基础权重 20%")
            print("\n💡 用户口味会变化，越新的反馈权重越高！")
            print("="*60 + "\n")
        elif args.text:
            # 自然语言解析
            success, msg = fb_system.parse_natural_language(args.text)
            print(f"\n{msg}\n")
        else:
            fb_system.print_feedback_stats()
    
    # 角色系统
    elif args.command == 'role':
        from role_system import RoleSystem
        role_sys = RoleSystem(base_path)
        
        if args.list:
            role_sys.list_available_roles()
        elif args.set:
            role_sys.set_current_role(args.set)
            print(f"\n✅ 已切换角色: {args.set}\n")
        elif args.current:
            current = role_sys.get_current_role()
            print(f"\n🎭 当前角色: {current}\n")
        else:
            role_sys.print_available_roles()
    
    # 推送功能
    elif args.command == 'push':
        import subprocess
        push_script = os.path.join(base_path, 'scripts', 'run_push.py')
        
        if args.daily or not any([args.daily, args.water, args.weekly_report]):
            cmd = ['python', push_script, 'daily']
        elif args.water:
            cmd = ['python', push_script, 'water']
        elif args.weekly_report:
            cmd = ['python', push_script, 'weekly']
        
        if args.test:
            cmd.append('--test')
            print("📋 测试模式，仅显示不发送...\n")
        
        subprocess.run(cmd, cwd=base_path)
    
    # 多维表格
    elif args.command == 'bitable':
        from bitable_manager import BitableManager
        bitable = BitableManager(base_path)
        
        if args.create:
            app_token = bitable.create_app("私人助理数据看板")
            print(f"\n✅ 数据看板创建成功！")
            print(f"🔗 看板链接: https://bytedance.feishu.cn/base/{app_token}\n")
        elif args.info:
            bitable.print_dashboard_info()
        elif args.sync_weight:
            import json
            with open(os.path.join(base_path, 'data', 'weight-records.json'), 'r') as f:
                records = json.load(f)
            print(f"开始同步 {len(records)} 条体重记录...")
            for record in records:
                bitable.add_weight_record(
                    date=record.get('date'),
                    weight=record.get('weight'),
                    bmi=record.get('bmi'),
                    bmi_status=record.get('bmiStatus'),
                    note=record.get('note', '')
                )
            print("✅ 体重记录同步完成！")
        elif args.sync_feedback or args.sync_all:
            import json
            with open(os.path.join(base_path, 'data', 'feedback-records.json'), 'r') as f:
                records = json.load(f)
            print(f"开始同步 {len(records)} 条反馈记录...")
            for record in records:
                bitable.add_feedback_record(
                    date=record.get('timestamp', '').split('T')[0],
                    feedback_type=record.get('type'),
                    content=record.get('content'),
                    dish_name=record.get('dishName', ''),
                    applied=record.get('applied', True)
                )
            print("✅ 反馈记录同步完成！")
    
    # 定时任务管理
    elif args.command == 'cron':
        from cron_manager import CronManager
        cron = CronManager(base_path)
        
        if args.list:
            cron.print_jobs()
        elif args.templates:
            cron.print_available_templates()
        elif args.add:
            if args.add == 'all':
                print("正在添加所有默认定时任务...\n")
                results = cron.add_all_jobs()
                for result in results:
                    status = "✅" if result['success'] else "❌"
                    print(f"  {status} {result['task_id']}: {result['message']}")
                print(f"\n✅ 共添加 {sum(1 for r in results if r['success'])} 个任务")
            else:
                success, message = cron.add_job(args.add)
                if success:
                    print(f"✅ {message}")
                else:
                    print(f"❌ {message}")
        elif args.remove:
            if args.remove == 'all':
                print("正在删除所有定时任务...\n")
                success, message = cron.remove_all_jobs()
                if success:
                    print(f"✅ {message}")
                else:
                    print(f"❌ {message}")
            else:
                success, message = cron.remove_job(args.remove)
                if success:
                    print(f"✅ {message}")
                else:
                    print(f"❌ {message}")
        else:
            cron.print_jobs()


if __name__ == '__main__':
    main()
