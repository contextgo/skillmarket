# 小右助理 - SKILL 调用接口文档

## 🎯 概述

用户无需关心底层脚本，只需用自然语言对话即可触发所有功能。

**SKILL 名称：** 小右（别名：小右助理、右右）

---

## 📋 调用方式

### 方式 1：名称唤起（推荐）⭐

用户直接在对话中说：

```
"小右，今天吃什么"
"小右助理，切换到高冷御姐"
"小右，给我生成周报"
"右右，提醒我喝水"
"小右"
```

**响应：** 自动识别意图，调用对应功能，返回结果。

---

### 方式 2：关键词触发

用户直接说功能关键词，无需带名称：

```
"今天吃什么"
"切换到高冷御姐"
"生成周报"
"提醒我喝水"
```

**响应：** 识别到关键词，自动调用功能。

---

## 🧠 意图识别结果

当 Agent 收到用户消息后，调用意图识别器：

```python
from src.intent_recognizer import IntentRecognizer

recognizer = IntentRecognizer()
result = recognizer.should_trigger_skill(user_message)
```

**返回结构：**

```python
{
  'should_trigger': bool,      # 是否应该触发此 SKILL
  'confidence': float,         # 置信度 0-1
  'trigger_type': str,         # 'name' / 'keyword' / 'semantic'
  'intent': str,               # 识别出的意图
  'extracted_command': str     # 纯指令内容
}
```

---

## 📋 完整意图清单

| 意图 (intent) | 说明 | 示例指令 | 处理方式 |
|--------------|------|---------|---------|
| `diet` | 饮食推荐 | "今天吃什么"、"推荐午餐" | 生成 3 菜一汤，推送飞书 |
| `role` | 角色切换 | "切换到高冷御姐"、"换角色" | 切换用户角色配置 |
| `report` | 健康报告 | "生成周报"、"给我月报" | 生成周/月度报告，推送飞书 |
| `weight` | 体重相关 | "看看我的体重"、"记录 89 kg" | 展示体重数据或记录新体重 |
| `water` | 喝水提醒 | "提醒我喝水" | 推送喝水提醒 |
| `feedback` | 用户反馈 | "这道菜不错"、"不喜欢番茄" | 记录用户偏好，优化算法 |
| `greeting` | 打招呼 | "小右"、"你好" | 返回欢迎语和功能列表 |
| `help` | 帮助 | "有什么功能"、"怎么用" | 返回帮助说明 |
| `unknown` | 未知意图 | 其他指令 | 确认用户需求，或返回帮助 |

---

## 🔧 调用流程

```
用户说一句话
    ↓
🧠 调用意图识别器
    ├─ ❌ should_trigger = False
    │       ↓
    │    不触发此 SKILL，走其他流程
    │
    └─ ✅ should_trigger = True
            ↓
    根据 intent 分发到对应功能：
    ├─ diet → 生成饮食推荐
    ├─ role → 切换角色
    ├─ report → 生成报告
    ├─ weight → 体重相关
    ├─ water → 喝水提醒
    ├─ feedback → 记录反馈
    ├─ greeting → 欢迎语
    └─ help → 帮助说明
```

---

## 📝 使用示例

### 示例 1：用户说 "小右，今天吃什么"

```python
# 识别结果
{
  'should_trigger': True,
  'confidence': 1.0,
  'trigger_type': 'name',
  'intent': 'diet',
  'extracted_command': '今天吃什么'
}

# 处理
→ 调用推荐引擎生成 3 菜一汤
→ 推送到飞书
→ 返回用户："✅ 已为您推送今日的 3 菜一汤饮食推荐到飞书！"
```

### 示例 2：用户说 "切换到高冷御姐"

```python
# 识别结果
{
  'should_trigger': True,
  'confidence': 0.9,
  'trigger_type': 'keyword',
  'intent': 'role',
  'extracted_command': '切换到高冷御姐'
}

# 处理
→ 修改 user-profile.json 中的角色配置
→ 返回用户："✅ 已成功切换到高冷御姐人设！"
```

### 示例 3：用户说 "帮我写个 Python 脚本"

```python
# 识别结果
{
  'should_trigger': False,
  'confidence': 0.0,
  'trigger_type': None,
  'intent': None,
  'extracted_command': None
}

# 处理
→ 不触发此 SKILL，走正常的代码生成流程
```

---

## 🔧 配置说明

### SKILL 名称配置

配置文件：`data/config.json`

```json
{
  "skill": {
    "name": "小右",
    "nicknames": ["小右助理", "小右", "右右"],
    "description": "私人健康饮食助理 - 懂你的健康管家"
  },
  ...
}
```

修改 `name` 和 `nicknames` 即可自定义唤起名称。

---

## 📦 核心模块

| 模块 | 文件 | 功能 |
|------|------|------|
| 意图识别 | `src/intent_recognizer.py` | 识别用户是否在调用此 SKILL |
| 推荐引擎 | `src/recommender.py` | 生成 3 菜一汤饮食推荐 |
| 消息生成 | `src/role_based_generator.py` | 生成角色化文案 |
| 体重跟踪 | `src/weight_tracker.py` | 记录和分析体重数据 |
| 报告生成 | `src/health_report_generator.py` | 生成周/月度健康报告 |
| 飞书推送 | `src/feishu_pusher.py` | 推送消息到飞书 |

---

## ✅ 功能清单

- ✅ 3 菜一汤饮食推荐（早餐独立外带食品）
- ✅ 5 种角色人设切换（可爱女友、高冷御姐、专业助手、邻家妹妹、佛系养生）
- ✅ 周度健康分析报告
- ✅ 月度健康分析报告
- ✅ 体重记录与数据分析
- ✅ 定时喝水提醒（分时段文案）
- ✅ 用户偏好反馈记录
- ✅ 飞书消息推送
- ✅ 5 个定时任务（每日推荐、喝水提醒、体重提醒、周报、月报）
