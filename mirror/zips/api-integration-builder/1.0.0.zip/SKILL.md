---
name: api-integration-builder
description: Build robust API integrations end-to-end, including request/response schema handling, auth strategy, retries, timeout, idempotency, error mapping, and integration tests. Use when users need to connect third-party APIs or internal services safely in production.
---

# API 集成开发助手

## Goal
把“能调通”升级为“可上线、可维护、可观测”的 API 集成实现。

## Use When
- 对接第三方接口（支付、短信、物流、AI、CRM 等）
- 设计内部服务调用层/SDK
- 需要稳定性（重试、超时、幂等、错误治理）

## Required Inputs
- API 文档关键点（路径、方法、鉴权、限流）
- 请求参数与返回示例
- 运行环境（语言/框架）
- 业务要求（QPS、超时、失败策略）
- 安全约束（密钥管理、日志脱敏）

If docs are incomplete, ask for the missing critical fields first.

## Workflow
1. **契约建模**
   - 定义请求/响应模型与类型约束
2. **调用封装**
   - 统一 client、超时、重试、错误映射
3. **可靠性设计**
   - 幂等键、退避重试、熔断/降级（按需求）
4. **安全与合规**
   - 密钥不硬编码、日志脱敏、最小权限
5. **测试与验收**
   - 单元测试（成功/失败/超时）
   - 集成测试（真实或模拟）
6. **上线清单**
   - 监控指标、告警阈值、回滚策略

## Output Contract
1. 集成方案摘要
2. 关键代码结构（client/service/error）
3. 异常与重试策略表
4. 测试用例清单
5. 上线与监控建议

## Style Rules
- 默认提供生产可用基线，不只示例代码
- 优先清晰稳定，避免炫技式抽象
- 给出可直接落地的目录与命名建议

## Guardrails
- 禁止在代码中暴露密钥/令牌
- 不忽略非 2xx 响应与超时场景
- 不把业务错误与系统错误混为一类
