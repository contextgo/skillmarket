# Skill Upload Guide - video-auto-creator

## 📦 Skill信息

**名称**: video-auto-creator  
**版本**: 1.0.0  
**作者**: OpenClaw  
**分类**: 视频制作 / 内容创作 / 自动化工具

## 📝 功能描述

全自动视频制作工具，实现从视频搜索到成片的一站式自动化流程：

1. **视频分析** - 自动提取视频标题、描述、标签等信息
2. **智能截图** - 按时间间隔自动截取视频关键帧
3. **脚本生成** - 生成结构化的视频脚本（场景、配音、字幕）
4. **AI配音** - 使用免费的Microsoft Edge TTS生成高质量配音
5. **字幕生成** - 自动创建SRT格式字幕文件
6. **视频合成** - 使用FFmpeg合成最终视频

## 🎯 使用场景

- 视频内容复用（将长视频转为短视频）
- 宣传视频制作
- 教程视频生成
- 视频脚本创作
- 多语言视频本地化

## 🔧 技术栈

- **Python 3.8+**
- **FFmpeg** - 视频处理
- **Edge TTS** - 文字转语音
- **OpenClaw Browser** - 浏览器自动化

## 📊 实际案例

### 司空2 AI智能体宣传视频

**输入**: B站视频 https://www.bilibili.com/video/BV19P9TB3E3r

**输出**: 60秒宣传视频
- 分辨率: 1920x1080
- 时长: 60秒
- 配音: AI生成（晓晓语音）
- 字幕: 已压制
- 文件大小: 1.35 MB

**执行步骤**:
1. 分析视频内容 ✓
2. 截取10张关键帧 ✓
3. 生成5个场景脚本 ✓
4. AI配音60秒 ✓
5. 生成字幕 ✓
6. 合成视频 ✓

## 📋 文件清单

```
video-auto-creator/
├── SKILL.md              # 详细文档 (11KB)
├── README.md             # 快速开始指南
├── create_video.py       # 主入口脚本 (10KB)
├── requirements.txt      # Python依赖
├── _meta.json           # 元数据配置
└── examples/
    └── sikong2_promo.py  # 完整示例 (10KB)
```

## 🚀 快速使用

### 安装

```bash
# 安装依赖
pip install edge-tts pillow requests

# 确保FFmpeg已安装
ffmpeg -version
```

### 基本用法

```python
from video_auto_creator import VideoAutoCreator

# 创建实例
creator = VideoAutoCreator(output_dir="output")

# 完整流程
video_info = creator.analyze_video("https://www.bilibili.com/video/BV1xx")
screenshots = creator.screenshot_video(video_url, count=10)
script_path = creator.generate_script(video_info, scenes=5)
audio_path = creator.generate_voiceover(script_path)
subtitles_path = creator.generate_subtitles(scenes_data)
final_video = creator.compose_video(screenshots, audio_path, subtitles_path)
```

### 命令行使用

```bash
# 完整自动化
python create_video.py --url "https://www.bilibili.com/video/BV1xx" --output "my_video.mp4"

# 分步执行
python create_video.py --url "https://www.bilibili.com/video/BV1xx" --step analyze
python create_video.py --url "https://www.bilibili.com/video/BV1xx" --step screenshot --count 10
```

## 💡 核心经验

### 1. 浏览器截图
- 使用OpenClaw内置浏览器管理
- 截图前等待2-3秒让画面稳定
- B站视频需要等待`.bilibili-player-video`元素加载

### 2. 编码问题
- Windows默认GBK编码，需设置`PYTHONIOENCODING=utf-8`
- 写文件时指定`encoding='utf-8'`
- FFmpeg输出重定向使用`errors='ignore'`

### 3. FFmpeg字幕
- 路径需要转义：`path.replace('\\', '\\\\').replace(':', '\\:')`
- 字体使用系统字体：`FontName=Microsoft YaHei`
- UTF-8编码保存SRT文件

### 4. TTS语音选择
- **专业解说**: zh-CN-YunyangNeural（云扬）
- **温柔女声**: zh-CN-XiaoxiaoNeural（晓晓）
- **年轻男声**: zh-CN-YunxiNeural（云希）

## ⚠️ 注意事项

1. **FFmpeg必需** - 确保FFmpeg已安装并添加到PATH
2. **网络连接** - Edge TTS需要联网
3. **浏览器权限** - 截图功能需要OpenClaw浏览器服务
4. **存储空间** - 视频合成需要足够的临时存储空间

## 🔄 版本历史

### v1.0.0 (2026-04-08)
- ✅ 初始版本发布
- ✅ 完整的视频制作流程
- ✅ B站视频分析支持
- ✅ Edge TTS集成
- ✅ FFmpeg视频合成
- ✅ 完整示例代码

## 📞 支持

- **文档**: 查看SKILL.md获取详细说明
- **示例**: examples/sikong2_promo.py
- **社区**: https://discord.gg/clawd

## 📄 许可证

MIT License

---

## 上传检查清单

- [x] SKILL.md 完整且格式正确
- [x] README.md 包含快速开始
- [x] requirements.txt 列出所有依赖
- [x] _meta.json 元数据完整
- [x] 示例代码可运行
- [x] 文档包含故障排除
- [x] 许可证信息完整
