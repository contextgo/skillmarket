#!/usr/bin/env python3
"""
Example: 司空2 AI智能体宣传视频制作
完整演示Video Auto Creator的使用流程
"""

import os
import sys
import subprocess
from pathlib import Path

# 设置编码
os.environ['PYTHONIOENCODING'] = 'utf-8'

# 配置
VIDEO_URL = "https://www.bilibili.com/video/BV19P9TB3E3r"
OUTPUT_DIR = Path("C:/Users/zheyu/Desktop/视频输出")
SCREENSHOT_DIR = OUTPUT_DIR / "screenshots"
AUDIO_DIR = OUTPUT_DIR / "audio"

# 场景配置（基于实际脚本）
SCENES = [
    {
        "name": "场景1_问题引入",
        "duration": 10,
        "voiceover": "山火突发，每一秒都关乎生命。但传统无人机操作繁琐复杂，在紧急时刻，我们往往错失黄金救援时间。",
        "subtitle": "山火突发 | 操作繁琐 | 错失良机"
    },
    {
        "name": "场景2_解决方案登场",
        "duration": 15,
        "voiceover": "现在，大疆司空 2 Copilot 智能体正式上线。深度软硬件融合，让复杂的无人机操控变得简单——只需一句话。",
        "subtitle": "司空 2 Copilot 智能体 | 深度软硬融合 | 一句话操控"
    },
    {
        "name": "场景3_核心功能演示",
        "duration": 20,
        "voiceover": "操作员只需说出：'立即飞往火场东侧，搜索受困人员'。AI智能体立即解析指令，自主规划最优航线，无人机自动起飞执行任务。",
        "subtitle": "语音指令 → AI解析 → 自主飞行 → 目标锁定"
    },
    {
        "name": "场景4_应用效果展示",
        "duration": 15,
        "voiceover": "实时画面传回，AI自动识别目标，坐标精准定位。整个流程从原来的数分钟缩短到数秒，真正实现秒级响应。",
        "subtitle": "实时画面 | AI识别 | 精准定位 | 秒级响应"
    },
    {
        "name": "场景5_结尾总结",
        "duration": 10,
        "voiceover": "司空 2 Copilot，让无人机操控进入AI时代。一句话，执飞急救任务。",
        "subtitle": "司空 2 Copilot | AI时代 | 一句话执飞"
    }
]

def create_directories():
    """创建输出目录"""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    SCREENSHOT_DIR.mkdir(exist_ok=True)
    AUDIO_DIR.mkdir(exist_ok=True)
    print(f"[OK] Directories created: {OUTPUT_DIR}")

def check_ffmpeg():
    """检查FFmpeg"""
    try:
        subprocess.run(['ffmpeg', '-version'], capture_output=True, check=True)
        print("[OK] FFmpeg is installed")
        return True
    except FileNotFoundError:
        print("[ERROR] FFmpeg not found. Please install FFmpeg first.")
        return False

def create_scene_video(scene_index, scene_data, screenshot):
    """创建单个场景视频"""
    print(f"\n--- Processing {scene_data['name']} ---")
    
    scene_output = OUTPUT_DIR / f"scene_{scene_index}.mp4"
    
    # FFmpeg命令：图片转视频
    cmd = [
        'ffmpeg', '-y',
        '-loop', '1',
        '-i', str(screenshot),
        '-c:v', 'libx264',
        '-t', str(scene_data['duration']),
        '-pix_fmt', 'yuv420p',
        '-vf', 'scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2',
        str(scene_output)
    ]
    
    try:
        subprocess.run(cmd, capture_output=True, check=True)
        print(f"[OK] Scene video created: {scene_output}")
        return scene_output
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Failed to create scene video: {e}")
        return None

def generate_voiceover():
    """生成配音"""
    print(f"\n{'='*60}")
    print("[4/6] Generating voiceover")
    print(f"{'='*60}")
    
    try:
        import edge_tts
    except ImportError:
        print("[INFO] Installing edge-tts...")
        subprocess.run([sys.executable, '-m', 'pip', 'install', 'edge-tts'], 
                     check=True, capture_output=True)
        import edge_tts
    
    # 合并所有配音文案
    full_text = "\n".join([s['voiceover'] for s in SCENES])
    
    audio_path = AUDIO_DIR / "voiceover.mp3"
    
    print(f"[INFO] Generating audio with Edge TTS (zh-CN-XiaoxiaoNeural)...")
    communicate = edge_tts.Communicate(full_text, "zh-CN-XiaoxiaoNeural")
    communicate.save_sync(str(audio_path))
    
    print(f"[OK] Voiceover created: {audio_path}")
    return audio_path

def create_subtitles():
    """创建字幕文件"""
    print(f"\n{'='*60}")
    print("[5/6] Creating subtitles")
    print(f"{'='*60}")
    
    srt_path = OUTPUT_DIR / "subtitles.srt"
    
    current_time = 0
    with open(srt_path, 'w', encoding='utf-8') as f:
        for i, scene in enumerate(SCENES, 1):
            start = current_time
            end = current_time + scene['duration']
            
            # 格式化时间戳
            start_h, start_rem = divmod(start, 3600)
            start_m, start_s = divmod(start_rem, 60)
            
            end_h, end_rem = divmod(end, 3600)
            end_m, end_s = divmod(end_rem, 60)
            
            f.write(f"{i}\n")
            f.write(f"{start_h:02d}:{start_m:02d}:{start_s:02d},000 --> ")
            f.write(f"{end_h:02d}:{end_m:02d}:{end_s:02d},000\n")
            f.write(f"{scene['subtitle']}\n\n")
            
            current_time = end
    
    print(f"[OK] Subtitles created: {srt_path}")
    return srt_path

def concatenate_videos(video_files, output_path):
    """合并视频片段"""
    print(f"\n{'='*60}")
    print(f"[6/6] Concatenating {len(video_files)} video clips")
    print(f"{'='*60}")
    
    # 创建文件列表
    file_list_path = OUTPUT_DIR / "filelist.txt"
    with open(file_list_path, 'w', encoding='utf-8') as f:
        for video in video_files:
            f.write(f"file '{video}'\n")
    
    # 合并
    cmd = [
        'ffmpeg', '-y',
        '-f', 'concat',
        '-safe', '0',
        '-i', str(file_list_path),
        '-c', 'copy',
        str(output_path)
    ]
    
    try:
        subprocess.run(cmd, capture_output=True, check=True)
        print(f"[SUCCESS] Video concatenation completed: {output_path}")
        file_list_path.unlink()
        return output_path
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Video concatenation failed: {e}")
        return None

def add_subtitles(video_path, srt_path, output_path):
    """添加字幕"""
    print(f"\n{'='*60}")
    print("Adding subtitles to video")
    print(f"{'='*60}")
    
    # 转义路径
    srt_escaped = str(srt_path).replace('\\', '\\\\').replace(':', '\\:')
    
    cmd = [
        'ffmpeg', '-y',
        '-i', str(video_path),
        '-vf', f"subtitles='{srt_escaped}':force_style='FontSize=24,FontName=Microsoft YaHei,PrimaryColour=&HFFFFFF&,OutlineColour=&H000000&,Outline=2,MarginV=50'",
        '-c:a', 'copy',
        str(output_path)
    ]
    
    try:
        subprocess.run(cmd, check=True)
        print(f"[SUCCESS] Video with subtitles created: {output_path}")
        return output_path
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Failed to add subtitles: {e}")
        return video_path

def combine_video_audio(video_path, audio_path, output_path):
    """合并视频和音频"""
    print(f"\n{'='*60}")
    print("Combining video and audio")
    print(f"{'='*60}")
    
    cmd = [
        'ffmpeg', '-y',
        '-i', str(video_path),
        '-i', str(audio_path),
        '-c:v', 'copy',
        '-c:a', 'aac',
        '-b:a', '192k',
        '-shortest',
        str(output_path)
    ]
    
    try:
        subprocess.run(cmd, check=True)
        print(f"[SUCCESS] Video with audio created: {output_path}")
        return output_path
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Failed to combine video and audio: {e}")
        return None

def main():
    print("=" * 60)
    print("Video Auto Creator - Example: 司空2 AI智能体宣传视频")
    print("=" * 60)
    
    # 检查依赖
    if not check_ffmpeg():
        sys.exit(1)
    
    create_directories()
    
    # 注意：这里假设截图已经存在
    # 实际使用时需要先用浏览器工具截图
    screenshot_files = sorted(SCREENSHOT_DIR.glob("*.png"))
    
    if len(screenshot_files) < len(SCENES):
        print(f"[WARNING] Not enough screenshots. Found {len(screenshot_files)}, need {len(SCENES)}")
        print(f"[INFO] Please run screenshot_video.py first or place screenshots in {SCREENSHOT_DIR}")
        # 创建示例截图（实际使用时删除）
        print("[INFO] Creating placeholder screenshots for demo...")
        # 这里可以添加创建示例图片的代码
    
    # 创建场景视频
    scene_videos = []
    for i, scene in enumerate(SCENES, 1):
        if i <= len(screenshot_files):
            scene_video = create_scene_video(i, scene, screenshot_files[i-1])
            if scene_video:
                scene_videos.append(scene_video)
    
    if not scene_videos:
        print("\n[ERROR] No scene videos were created")
        sys.exit(1)
    
    # 合并场景
    temp_video = OUTPUT_DIR / "temp_video.mp4"
    concatenate_videos(scene_videos, temp_video)
    
    # 生成配音
    audio_path = generate_voiceover()
    
    # 合并视频和音频
    video_with_audio = OUTPUT_DIR / "video_with_audio.mp4"
    combine_video_audio(temp_video, audio_path, video_with_audio)
    
    # 生成字幕
    srt_path = create_subtitles()
    
    # 添加字幕
    final_video = OUTPUT_DIR / "司空2_AI智能体_带字幕版.mp4"
    add_subtitles(video_with_audio, srt_path, final_video)
    
    # 清理临时文件
    temp_video.unlink(missing_ok=True)
    
    print("\n" + "=" * 60)
    print("[SUCCESS] Video production completed!")
    print(f"[OUTPUT] {final_video}")
    print(f"[SCENES] {len(scene_videos)}")
    print(f"[DURATION] {sum(s['duration'] for s in SCENES)} seconds")
    print("=" * 60)

if __name__ == '__main__':
    main()
