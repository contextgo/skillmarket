#!/usr/bin/env python3
"""
Test script for video-auto-creator skill
验证skill是否可以正常工作
"""

import os
import sys
from pathlib import Path

# 设置编码
os.environ['PYTHONIOENCODING'] = 'utf-8'

def test_imports():
    """测试依赖包导入"""
    print("\n[TEST 1] Checking Python dependencies...")
    
    errors = []
    
    # 测试edge-tts
    try:
        import edge_tts
        print("  [OK] edge-tts installed")
    except ImportError:
        print("  [FAIL] edge-tts not found")
        errors.append("edge-tts")
    
    # 测试PIL
    try:
        from PIL import Image
        print("  [OK] pillow installed")
    except ImportError:
        print("  [FAIL] pillow not found")
        errors.append("pillow")
    
    # 测试requests
    try:
        import requests
        print("  [OK] requests installed")
    except ImportError:
        print("  [FAIL] requests not found")
        errors.append("requests")
    
    if errors:
        print(f"\n[ERROR] Missing packages: {', '.join(errors)}")
        print("[FIX] Run: pip install " + " ".join(errors))
        return False
    
    return True

def test_ffmpeg():
    """测试FFmpeg"""
    print("\n[TEST 2] Checking FFmpeg...")
    
    import subprocess
    try:
        result = subprocess.run(['ffmpeg', '-version'], capture_output=True, check=True)
        version_line = result.stdout.decode('utf-8', errors='ignore').split('\n')[0]
        print(f"  [OK] FFmpeg found: {version_line}")
        return True
    except FileNotFoundError:
        print("  [FAIL] FFmpeg not found")
        print("[FIX] Install FFmpeg and add to PATH")
        return False
    except Exception as e:
        print(f"  [FAIL] FFmpeg error: {e}")
        return False

def test_skill_files():
    """测试skill文件完整性"""
    print("\n[TEST 3] Checking skill files...")
    
    skill_dir = Path(__file__).parent
    
    required_files = [
        'SKILL.md',
        'README.md',
        'create_video.py',
        'requirements.txt',
        '_meta.json'
    ]
    
    all_exist = True
    for file in required_files:
        file_path = skill_dir / file
        if file_path.exists():
            size = file_path.stat().st_size
            print(f"  [OK] {file} ({size} bytes)")
        else:
            print(f"  [FAIL] {file} NOT FOUND")
            all_exist = False
    
    return all_exist

def test_tts():
    """测试TTS功能"""
    print("\n[TEST 4] Testing TTS functionality...")
    
    try:
        import edge_tts
        print("  Testing TTS with sample text...")
        
        # 创建临时音频
        test_text = "测试音频生成"
        test_audio = Path("test_audio.mp3")
        
        communicate = edge_tts.Communicate(test_text, "zh-CN-XiaoxiaoNeural")
        communicate.save_sync(str(test_audio))
        
        if test_audio.exists():
            size = test_audio.stat().st_size
            print(f"  [OK] TTS works! Generated audio size: {size} bytes")
            test_audio.unlink()  # 清理
            return True
        else:
            print("  [FAIL] TTS failed to generate audio")
            return False
    
    except Exception as e:
        print(f"  [FAIL] TTS error: {e}")
        return False

def test_video_creation():
    """测试视频创建功能"""
    print("\n[TEST 5] Testing video creation...")
    
    try:
        from create_video import VideoAutoCreator
        print("  [OK] VideoAutoCreator class imported successfully")
        
        # 创建测试实例
        creator = VideoAutoCreator(output_dir="test_output")
        print(f"  [OK] VideoAutoCreator initialized")
        print(f"  [OK] Output directory: {creator.output_dir}")
        
        # 清理测试目录
        import shutil
        if creator.output_dir.exists():
            shutil.rmtree(creator.output_dir)
        
        return True
    
    except Exception as e:
        print(f"  [FAIL] Video creation error: {e}")
        return False

def main():
    print("=" * 60)
    print("Video Auto Creator - Test Suite")
    print("=" * 60)
    
    results = []
    
    # 运行所有测试
    results.append(("Dependencies", test_imports()))
    results.append(("FFmpeg", test_ffmpeg()))
    results.append(("Skill Files", test_skill_files()))
    results.append(("TTS", test_tts()))
    results.append(("Video Creation", test_video_creation()))
    
    # 总结
    print("\n" + "=" * 60)
    print("TEST RESULTS")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "[PASS]" if result else "[FAIL]"
        print(f"{name:20} {status}")
    
    print("=" * 60)
    print(f"Total: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n[SUCCESS] All tests passed! Skill is ready to use.")
        return 0
    else:
        print(f"\n[WARNING] {total - passed} test(s) failed. Please fix before using.")
        return 1

if __name__ == '__main__':
    sys.exit(main())
