---
name: video-auto-creator
description: "全自动视频制作工具。从搜索视频、截图、生成脚本到配音字幕，一站式完成。支持B站/YouTube等平台视频截图、AI配音（Edge TTS）、字幕生成、FFmpeg合成。适用于：视频脚本创作、内容复用、宣传视频制作、教程视频生成。触发词：视频制作、生成视频、视频脚本、自动视频、video creation、auto video"
version: "1.0.0"
author: "OpenClaw"
tags: [video, automation, screenshot, tts, ffmpeg, content-creation]
---

# Video Auto Creator - 全自动视频制作工具

一站式自动化视频制作：搜索视频 → 读取内容 → 截图采样 → 生成脚本 → AI配音 → 添加字幕 → 合成输出

## 核心能力

### 1. 视频搜索与内容读取
- **平台支持**: B站、YouTube、抖音等主流视频平台
- **内容提取**: 自动提取视频标题、描述、标签、字幕
- **智能分析**: 分析视频主题、关键信息、结构

### 2. 智能截图采样
- **自动采样**: 按时间间隔自动截取视频帧
- **场景识别**: 识别关键场景变化
- **质量控制**: 自动筛选清晰、信息量大的截图

### 3. 脚本生成
- **结构化脚本**: 场景描述、镜头运动、配音文案、字幕文本
- **AI提示词**: 生成Midjourney/Stable Diffusion风格的图像生成提示词
- **时长规划**: 自动计算每个场景时长

### 4. AI配音
- **Edge TTS**: 免费、高质量、多种语音
- **支持语言**: 中文、英文、日文等多语言
- **语音风格**: 专业、活泼、温暖等多种风格

### 5. 字幕生成
- **SRT格式**: 标准字幕文件
- **样式定制**: 字体、大小、颜色、位置
- **时间轴**: 自动对齐配音时长

### 6. 视频合成
- **FFmpeg**: 专业视频处理
- **分辨率**: 支持1080p/720p等
- **编码**: H.264 + AAC

## 快速开始

### 方式一：完整自动化（推荐）

```bash
# 一键生成视频
python skills/video-auto-creator/create_video.py --url "https://www.bilibili.com/video/BV1xx" --output "my_video.mp4"
```

### 方式二：分步执行

```bash
# 步骤1: 搜索并分析视频
python skills/video-auto-creator/analyze_video.py --url "https://www.bilibili.com/video/BV1xx"

# 步骤2: 截图采样
python skills/video-auto-creator/screenshot_video.py --url "https://www.bilibili.com/video/BV1xx" --count 10

# 步骤3: 生成脚本
python skills/video-auto-creator/generate_script.py --video-info video_info.json --output script.md

# 步骤4: 生成配音
python skills/video-auto-creator/generate_voiceover.py --script script.md --output voiceover.mp3

# 步骤5: 创建字幕
python skills/video-auto-creator/generate_subtitles.py --script script.md --output subtitles.srt

# 步骤6: 合成视频
python skills/video-auto-creator/compose_video.py --images screenshots/ --audio voiceover.mp3 --subtitles subtitles.srt --output final.mp4
```

## 核心脚本详解

### 1. analyze_video.py - 视频分析

**功能**：
- 使用浏览器工具打开视频页面
- 提取视频元数据（标题、描述、标签、时长等）
- 分析视频内容主题
- 保存为JSON格式

**输出示例**：
```json
{
  "title": "大疆司空2 Copilot智能体",
  "description": "一句话执飞急救任务...",
  "duration": 149,
  "author": "DJI大疆行业应用",
  "tags": ["AI", "无人机", "大疆司空2"],
  "platform": "bilibili",
  "url": "https://www.bilibili.com/video/BV19P9TB3E3r"
}
```

### 2. screenshot_video.py - 智能截图

**功能**：
- 打开视频页面
- 等待视频加载
- 按时间间隔截取帧
- 自动命名并保存

**参数**：
- `--url`: 视频URL
- `--count`: 截图数量（默认10）
- `--interval`: 截图间隔（秒）
- `--output`: 输出目录

**关键代码**：
```python
# 使用OpenClaw浏览器工具
from openclaw.browser import BrowserController

browser = BrowserController()
browser.navigate(video_url)
browser.wait_for_selector('.video-player')

for i, timestamp in enumerate(timestamps):
    browser.seek_to(timestamp)
    browser.wait(2)  # 等待画面稳定
    screenshot = browser.screenshot()
    save_screenshot(screenshot, f"scene_{i+1}.png")
```

### 3. generate_script.py - 脚本生成

**功能**：
- 基于视频内容生成结构化脚本
- 包含场景描述、配音文案、字幕
- 生成AI图像提示词

**脚本结构**：
```markdown
# 视频标题

## 场景 1：开场（0-10秒）

### 画面描述
- 镜头1：全景镜头，展示主题
- 镜头2：特写镜头，突出细节

### AI视频提示词
```
场景1-1: Drone shot flying over forest, cinematic, 4K --ar 16:9
```

### 配音文案
> 这是配音内容...

### 字幕
```
关键词1 | 关键词2 | 关键词3
```
```

### 4. generate_voiceover.py - AI配音

**功能**：
- 使用Microsoft Edge TTS
- 支持多种中文语音
- 自动分段配音

**可用语音**：
- `zh-CN-XiaoxiaoNeural` - 晓晓（女声，温柔）
- `zh-CN-YunxiNeural` - 云希（男声，阳光）
- `zh-CN-YunyangNeural` - 云扬（男声，专业）
- `zh-CN-XiaoyiNeural` - 晓伊（女声，活泼）

**使用示例**：
```python
import edge_tts

text = "欢迎观看本期视频..."
communicate = edge_tts.Communicate(text, "zh-CN-XiaoxiaoNeural")
communicate.save_sync("voiceover.mp3")
```

### 5. compose_video.py - 视频合成

**功能**：
- 将图片序列转换为视频
- 添加配音音频
- 烧录字幕
- 设置分辨率、码率

**FFmpeg命令模板**：
```bash
# 图片序列转视频
ffmpeg -loop 1 -i image.png -t 10 -c:v libx264 -pix_fmt yuv420p video.mp4

# 添加配音
ffmpeg -i video.mp4 -i audio.mp3 -c:v copy -c:a aac -shortest with_audio.mp4

# 添加字幕
ffmpeg -i with_audio.mp4 -vf "subtitles=subtitles.srt" final.mp4
```

## 完整示例：司空2宣传视频

### 输入
- **视频URL**: https://www.bilibili.com/video/BV19P9TB3E3r
- **目标**: 制作60秒宣传视频

### 执行流程

```bash
# 1. 分析视频
python analyze_video.py --url "https://www.bilibili.com/video/BV19P9TB3E3r"
# 输出: video_info.json

# 2. 截图10张
python screenshot_video.py --url "https://www.bilibili.com/video/BV19P9TB3E3r" --count 10
# 输出: screenshots/scene_1.png ~ scene_10.png

# 3. 生成脚本
python generate_script.py --video-info video_info.json --scenes 5
# 输出: video_script.md

# 4. 生成配音
python generate_voiceover.py --script video_script.md --voice zh-CN-XiaoxiaoNeural
# 输出: voiceover.mp3 (60秒)

# 5. 生成字幕
python generate_subtitles.py --script video_script.md --style professional
# 输出: subtitles.srt

# 6. 合成视频
python compose_video.py \
  --images screenshots/ \
  --audio voiceover.mp3 \
  --subtitles subtitles.srt \
  --resolution 1920x1080 \
  --output "司空2_AI智能体_宣传视频.mp4"
```

### 输出
- **文件**: 司空2_AI智能体_宣传视频.mp4
- **时长**: 60秒
- **分辨率**: 1920x1080
- **文件大小**: 1.35 MB

## 关键经验总结

### 1. 浏览器截图技巧

**问题**: Windows环境下浏览器控制复杂
**解决方案**: 使用OpenClaw内置的浏览器管理
```python
# 不推荐：手动启动Chrome
# chrome_path = "C:/Program Files/Google/Chrome/Application/chrome.exe"

# 推荐：使用OpenClaw浏览器工具
browser = BrowserController(profile="openclaw")
browser.navigate(url)
```

**经验**：
- 视频截图前等待2-3秒让画面稳定
- 使用CDP协议控制比Selenium更稳定
- B站视频需要等待`.bilibili-player-video`元素加载

### 2. 编码问题处理

**问题**: Windows默认GBK编码，中文输出报错
**解决方案**：
```python
# 方法1: 设置环境变量
import os
os.environ['PYTHONIOENCODING'] = 'utf-8'

# 方法2: 指定编码写入文件
with open(file, 'w', encoding='utf-8') as f:
    f.write(content)

# 方法3: FFmpeg输出重定向
result = subprocess.run(cmd, capture_output=True, encoding='utf-8', errors='ignore')
```

### 3. FFmpeg字幕处理

**问题**: 字幕路径包含中文和特殊字符导致失败
**解决方案**：
```python
# 错误：直接使用路径
# vf = f"subtitles={srt_path}"

# 正确：转义路径
srt_escaped = str(srt_path).replace('\\', '\\\\').replace(':', '\\:')
vf = f"subtitles='{srt_escaped}'"
```

### 4. TTS语音选择

**经验**：
- **专业解说**: `zh-CN-YunyangNeural`（云扬）
- **温柔女声**: `zh-CN-XiaoxiaoNeural`（晓晓）
- **年轻男声**: `zh-CN-YunxiNeural`（云希）
- **活泼女声**: `zh-CN-XiaoyiNeural`（晓伊）

**性能**：
- 100字约生成5秒音频
- 边缘TTS完全免费，无需API key
- 首次使用会自动安装`edge-tts`包

### 5. 视频时长计算

**公式**：
```python
# 配音时长决定视频时长
audio_duration = get_audio_duration(voiceover_path)

# 每个场景时长 = 总时长 / 场景数
scene_duration = audio_duration / len(scenes)

# 建议每个场景8-15秒，太快观众看不清
```

### 6. 文件管理

**最佳实践**：
```python
# 创建独立输出目录
output_dir = Path("output") / video_id
output_dir.mkdir(parents=True, exist_ok=True)

# 分类存放
screenshots_dir = output_dir / "screenshots"
audio_dir = output_dir / "audio"
final_dir = output_dir / "final"

# 清理临时文件
for temp_file in temp_files:
    if temp_file.exists():
        temp_file.unlink()
```

## 依赖安装

### 必需依赖
```bash
# FFmpeg (已包含在OpenClaw环境中)
ffmpeg -version

# Python包
pip install edge-tts pillow requests
```

### 可选依赖
```bash
# 图像增强（可选）
pip install opencv-python

# 更好的音频处理（可选）
pip install pydub
```

## 故障排除

### 问题1: 浏览器截图失败
```
解决方案：
1. 检查OpenClaw浏览器服务状态
2. 使用browser.status查看
3. 确保视频URL可访问
```

### 问题2: TTS生成失败
```
解决方案：
1. 检查网络连接（Edge TTS需要联网）
2. 确认edge-tts已安装: pip show edge-tts
3. 尝试其他语音角色
```

### 问题3: FFmpeg找不到
```
解决方案：
1. 检查PATH环境变量
2. 使用完整路径: H:\ffmpeg\bin\ffmpeg.exe
3. 或安装: winget install ffmpeg
```

### 问题4: 字幕乱码
```
解决方案：
1. 确保SRT文件UTF-8编码
2. FFmpeg指定字体: FontName=Microsoft YaHei
3. 避免使用特殊字符
```

## 扩展功能

### 1. 批量视频制作
```python
# 从CSV读取多个视频URL
import pandas as pd

videos = pd.read_csv('videos.csv')
for url in videos['url']:
    create_video(url)
```

### 2. 自定义模板
```python
# 使用Jinja2模板生成脚本
from jinja2 import Template

template = Template(open('template.md').read())
script = template.render(scenes=scenes, voiceover=text)
```

### 3. 多语言支持
```python
# 自动翻译配音文案
from translate import Translator

translator = Translator(to_lang="en")
english_text = translator.translate(chinese_text)
```

## 最佳实践

1. **内容优先**: 先分析视频内容，再规划场景
2. **时长控制**: 每场景8-15秒，总时长60-120秒最佳
3. **配音质量**: 选择适合内容风格的语音
4. **字幕简洁**: 每行字幕不超过15字
5. **文件命名**: 使用时间戳或视频ID，避免中文路径

## 许可证

MIT License

## 联系方式

- 作者：OpenClaw Team
- 网站：https://openclaw.ai
- 社区：https://discord.gg/clawd
