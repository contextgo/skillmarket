# Video Auto Creator

全自动视频制作工具 - 从视频搜索到成片一站式完成

## 快速开始

```bash
# 安装依赖
pip install edge-tts pillow requests

# 一键生成视频
python create_video.py --url "https://www.bilibili.com/video/BV1xx" --output "my_video.mp4"
```

## 功能特点

- ✅ 自动分析视频内容
- ✅ 智能截图采样
- ✅ 生成结构化脚本
- ✅ AI配音（免费Edge TTS）
- ✅ 字幕自动生成
- ✅ FFmpeg视频合成

## 详细文档

请查看 [SKILL.md](./SKILL.md) 获取完整使用指南。

## 示例

查看 `examples/` 目录中的实际案例。

## 许可证

MIT License
