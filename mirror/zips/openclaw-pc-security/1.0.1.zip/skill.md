# OpenClaw PC Security (Windows) / 个人电脑安全扫描（Windows）

## Description / 描述

### ZH
为个人电脑上安装的 OpenClaw 提供安全自检与风险告警，重点覆盖：
- Windows 系统安全态势（版本、最近补丁日期、支持状态、补丁滞后）
- OpenClaw / npm 版本落后风险提示
- 可选的本机/局域网 OpenClaw 端口探测与弱口令/暴露检测（仅授权环境）

当前阶段主要完成 Windows 版本相关逻辑，后续可扩展到更多 OS 与更丰富的本机安全项。

### EN
Security self-check and risk alerting for personal computers running OpenClaw, focusing on:
- Windows posture (version, last security update date, support status, patch lag)
- OpenClaw/npm outdated warnings
- Optional port probing and weak-credential/exposure checks for local/LAN OpenClaw targets (authorized use only)

Currently the Windows posture path is the primary completed scope; other OS and more checks can be added later.

## When to use / 何时使用

### ZH
当用户需要：
- 判断 Windows 是否落后补丁周期、是否已超出支持周期
- 发现 OpenClaw / npm 版本落后引发的不安全争议或使用风险
- 排查 token/配置泄露、端口暴露、弱口令导致的爆破风险

### EN
Use this skill when you need to:
- Check whether Windows is out of support or significantly behind patch cadence
- Detect outdated OpenClaw/npm versions that may cause security concerns
- Investigate token/config leaks, exposed ports, and weak-password brute-force risks

## Input / 输入
- Local Windows information (version/build, last hotfix date)
- Optional target host/IP and ports for OpenClaw probing

## Output / 输出
- Severity-based findings (Info/Medium/High/Critical)
- HTML/JSON report under `openclaw-pc-security/output/`
  - `openclaw-pc-security/output/scan_report.html`
  - `openclaw-pc-security/output/scan_report.json`

## Steps / 步骤

### 1) Local audit / 本机审计
```bash
python scripts/main.py --audit --npm-view-latest-openclaw --out-dir openclaw-pc-security/output
```

### 2) Scan a target / 扫描目标（授权环境）
```bash
python scripts/main.py <target-ip> --ports 18789,18790,18792 --out-dir openclaw-pc-security/output
```

## Notes / 注意事项

### ZH
- 仅在授权环境做目标扫描与弱口令探测。
- 不要把 token、凭据、报告（output/）上传到公共仓库。
- 若检测到 Windows 10：建议评估升级 Windows 11；若无法升级，考虑注册 Windows 10 ESU 计划以持续更新至 2026-10。
- 若 OpenClaw 版本落后：升级后部分或全部功能可能不可用，请谨慎判断。
- HTML 报告生成后，请在聊天窗口打印报告路径，并发送/上传 `openclaw-pc-security/output/scan_report.html`。

### EN
- Only scan/probe weak credentials in authorized environments.
- Do not upload tokens, credentials, or reports (output/) to public repositories.
- Reports are written under `openclaw-pc-security/output/` when using the provided scripts.
- If Windows 10 is detected: consider upgrading to Windows 11; if not eligible, enroll in Windows 10 ESU to continue receiving updates until 2026-10.
- If OpenClaw is outdated: after upgrading, some or all functions may be unavailable; assess carefully.
- After the HTML report is generated, print the report path in the chat and send/upload `openclaw-pc-security/output/scan_report.html`.
