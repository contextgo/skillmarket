# bilibili 视频监控 Skill

> 自动监控 B站 UP主投稿数据，生成周报并通过微信/QQ邮箱双通道推送。
> SkillHub Slug：`bibili-video-monitoring`

## ✨ 功能

- 🔐 读取 B站 Cookie，通过内置 **WBI 签名算法** 验证身份（无需额外依赖）
- 📹 获取 UP主（默认 UID: 3493115144964536）最新投稿列表
- 📊 统计每支稿件的播放、点赞、收藏、分享、评论数据
- 💬 获取最新 3 个视频的高赞评论（TOP5）
- 📄 生成结构化文字报告
- 📲 双通道自动推送（微信 + QQ邮箱）

## 📂 文件结构

```
bilibili-video-monitoring/
├── SKILL.md            # Skill 定义文件
├── bibili_weekly.js    # 主执行脚本（Node.js）
├── bibili_cookie.txt   # Cookie 配置模板（需填写真实值）
└── README.md           # 本文件
```

## 🚀 快速开始

### 第一步：配置 Cookie

编辑 `bibili_cookie.txt`，填入真实 Cookie 值：

```
SESSDATA=你的SESSDATA值
bili_jct=你的bili_jct值
DedeUserID=3493115144964536
DedeUserID__ckMd5=你的DedeUserID__ckMd5值
```

**获取方式：**
1. 浏览器登录 https://www.bilibili.com
2. 按 `F12` 打开开发者工具
3. 进入 **Application → Cookies → https://www.bilibili.com**
4. 找到上述四个字段，复制对应值填入

> ⚠️ Cookie 有效期约 30 天，过期后脚本会提示"Cookie 失效"，需重新获取并更新文件

### 第二步：手动运行测试

```bash
D:\node.exe "C:\Users\X270\.workbuddy\skills\bibili-video-monitoring\bibili_weekly.js"
```

运行后自动完成：
1. ✅ 验证 Cookie 有效性
2. 📹 拉取最新投稿数据
3. 💬 获取高赞评论
4. 📄 生成报告写入 `C:\Users\X270\WorkBuddy\Claw\.workbuddy\bibili_report.txt`
5. 📲 （若由 Skill 调用）自动双通道推送

### 第三步：接入 WorkBuddy 自动化

可通过 WorkBuddy 自动化功能配置每周定时运行，实现完全无人值守的周报推送。

示例使用场景：每周六 10:00 自动运行并推送。

## 📲 双通道推送说明

| 通道 | 实现方式 | 推送目标 |
|------|----------|----------|
| 通道1 | 微信 PC 端自动控制 Skill | 微信联系人「微光浮影」 |
| 通道2 | QQ邮箱 Skill（nodemailer） | 邮箱 1790219375@qq.com |

> 使用前需确保：
> - 微信 PC 端已登录（微信 Windows 客户端）
> - QQ邮箱授权码已配置（写入 `~/.workbuddy/.env` 的 `QQ_EMAIL_AUTH_CODE`）

## 📊 报告内容示例

```
🦞 B站每周播报
UP主：微光浮影_5903
数据周期：本周
─────────────────────
📹 投稿概览（共 2 个视频）

▎【视频标题】
  BV号：BV1xx411x7xx
  发布时间：2026-04-20
  播放：12.3万 | 点赞：8456 | 收藏：2345 | 分享：876 | 评论：1234

  💬 高赞评论 TOP5：
    1. 评论内容示例...
       👍 1234
    ...

─────────────────────
📊 本周合计
  总播放：XXX | 总点赞：XXX | 总评论：XXX

Powered by WorkBuddy 🦞
```

## 🔧 依赖要求

| 依赖 | 说明 |
|------|------|
| Node.js | 本机路径 `D:\node.exe` |
| WBI 签名 | 内置在脚本中，无需额外安装 |
| 微信 PC 端自动控制 Skill | 用于通道1推送 |
| QQ邮箱 Skill | 用于通道2推送 |

## ⚠️ 注意事项

1. **Cookie 安全**：Cookie 为敏感信息，请勿分享给他人
2. **Cookie 过期**：约 30 天后需重新获取，脚本会自动检测并提示
3. **无 npm 依赖**：脚本纯 Node.js 实现 WBI 签名，无需 `npm install`
4. **报告文件路径**：默认写入 `C:\Users\X270\WorkBuddy\Claw\.workbuddy\bibili_report.txt`

## 🐛 常见问题

**Q：脚本报错"Cookie 失效"**
→ Cookie 已过期，重新获取并填入 `bibili_cookie.txt`

**Q：推送没有收到**
→ 检查微信是否登录、QQ邮箱授权码是否配置正确

**Q：能监控其他 UP主吗**
→ 修改 `bibili_weekly.js` 第 17 行 `const UID = '...'` 为目标 UP主 UID

## 📜 更新日志

### v1.0.0（2026-04-27）
- ✅ 初始版本，提交 SkillHub 审核
- ✅ Slug：`bibili-video-monitoring`
- ✅ 内置 WBI 签名算法，无额外依赖
- ✅ 双通道推送（微信 + QQ邮箱）
- ✅ 适配 WorkBuddy Skill 规范

## 📄 许可证

MIT License — 可自由使用、修改、分发。

---
**作者**：微光浮影
**SkillHub**：https://skillhub.cn/skills/bibili-video-monitoring
