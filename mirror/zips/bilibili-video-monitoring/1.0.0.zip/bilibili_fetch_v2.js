const https = require('https');
const crypto = require('crypto');

const UID = '3493115144964536';
const COOKIE = 'SESSDATA=6dc5e3bf%2C1791268048%2C22aff%2A41CjDBevqQ2ID8e75szMzGjLiPBZlJ9TbA8VXiRgCBcUxiOa75NM9mXFKsSyOK2mlI0UESVmhEbGJBQmF2S2FCa2hYeDR5TEJ1ejhfellqb2FVS2xsOGpGQ01iRWlCVmVyR2JKSHN6ZVhVYWdGQndVYW1mUDEzRkpNdWRtaVZ2YU94TVJJZExJcnNRIIEC; bili_jct=b722fb0d03a84a3e61ef609b8b0a931f; DedeUserID=3493115144964536; DedeUserID__ckMd5=3a3d348301adb3a0';

// B站 wbi 签名 lookup table
const MIXIN_KEY_ENC_TAB = [
    46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49,
    33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55, 40,
    61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11,
    36, 20, 34, 44, 52
];

function getMixinKey(orig) {
    return MIXIN_KEY_ENC_TAB.map(i => orig[i]).join('').slice(0, 32);
}

function httpGet(url, extraHeaders = {}) {
    return new Promise((resolve, reject) => {
        const opts = new URL(url);
        https.request({
            hostname: opts.hostname,
            path: opts.pathname + opts.search,
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': 'https://www.bilibili.com',
                'Cookie': COOKIE,
                ...extraHeaders
            }
        }, res => {
            let d = '';
            res.on('data', c => d += c);
            res.on('end', () => {
                try { resolve(JSON.parse(d)); }
                catch(e) { resolve({_raw: d.substring(0, 500)}); }
            });
        }).on('error', reject).end();
    });
}

// wbi 签名
async function wbiSign(params) {
    // 1. 获取 wbi keys
    const nav = await httpGet('https://api.bilibili.com/x/web-interface/nav');
    const imgUrl = nav.data?.wbi_img?.img_url || '';
    const subUrl = nav.data?.wbi_img?.sub_url || '';
    const imgKey = imgUrl.match(/\/([^\/]+)\.png$/)?.[1] || '';
    const subKey = subUrl.match(/\/([^\/]+)\.png$/)?.[1] || '';

    // 2. 构造 mixin key
    const mixinKey = getMixinKey(imgKey + subKey);

    // 3. 添加时间戳
    const e = Math.floor(Date.now() / 1000);
    params = {...params, wts: e};

    // 4. 按 key 排序
    const sortedKeys = Object.keys(params).sort();

    // 5. 过滤特殊字符 !"()* 并编码
    const filtered = {};
    for (const k of sortedKeys) {
        const v = String(params[k]);
        // 过滤 !"()*#
        filtered[k] = v.replace(/[!"'()*#]/g, '');
    }

    const query = sortedKeys.map(k => `${encodeURIComponent(k)}=${encodeURIComponent(filtered[k])}`).join('&');

    // 6. MD5(query + mixinKey) = w_rid
    const wbiSignInput = query + mixinKey;
    const wbiSignResult = crypto.createHash('md5').update(wbiSignInput).digest('hex');

    return `${query}&w_rid=${wbiSignResult}`;
}

async function main() {
    console.log('=== B站数据播报脚本 ===\n');

    // 验证登录
    const nav = await httpGet('https://api.bilibili.com/x/web-interface/nav');
    console.log(`账号: ${nav.data?.uname || '?'} | ${nav.data?.isLogin ? '✅ 已登录' : '❌ 未登录'}`);
    if (!nav.data?.isLogin) { console.log('Cookie 失效，请重新获取！'); return; }

    // 获取投稿列表
    const params = {mid: UID, ps: 30, pn: 1, order: 'pubdate', jsonp: 'jsonp'};
    const signedQuery = await wbiSign(params);
    const videoResp = await httpGet(`https://api.bilibili.com/x/space/wbi/arc/search?${signedQuery}`);

    console.log(`\n--- 投稿视频 ---`);
    console.log(`code: ${videoResp.code} | ${videoResp.message}`);

    if (videoResp.code !== 0) {
        console.log('响应:', JSON.stringify(videoResp).substring(0, 300));
        return;
    }

    const videos = videoResp.data?.list?.vlist || [];
    const total = videoResp.data?.page?.count || 0;
    console.log(`总计: ${total} 个视频\n`);

    if (videos.length === 0) {
        console.log('暂无投稿，播报结束。');
        return;
    }

    // 打印视频列表
    for (const v of videos) {
        const date = new Date(v.created * 1000);
        const dateStr = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
        console.log(`[${v.bvid}] ${v.title}`);
        console.log(`  播放:${v.play}  点赞:${v.like}  收藏:${v.favorite}  分享:${v.share}  评论:${v.comment} | ${dateStr}`);
    }

    // 获取最新3个视频的高赞评论
    console.log('\n--- 高赞评论 ---');
    for (const v of videos.slice(0, 3)) {
        const aid = v.aid;
        const cmtResp = await httpGet(`https://api.bilibili.com/x/v2/reply?type=1&oid=${aid}&ps=5&pn=1&sort=2`);
        const comments = cmtResp.data?.replies || [];
        console.log(`\n《${v.title}》TOP评论:`);
        if (comments.length === 0) {
            console.log('  (暂无评论)');
        } else {
            comments.slice(0, 5).forEach((c, i) => {
                const msg = (c.content?.message || '(图片/语音)').substring(0, 100);
                console.log(`  ${i+1}. ${msg} (👍${c.like})`);
            });
        }
    }
}

main().catch(console.error);
