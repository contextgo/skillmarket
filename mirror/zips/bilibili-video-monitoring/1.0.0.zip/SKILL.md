---
name: bilibili 视频监控
description: 运行 B站每周播报脚本，读取生成的报告文件，将内容整理成文字，并通过双通道推送给用户（微光浮影，UID 3493115144964536）。触发场景：用户请求"查看B站播报"、"运行播报脚本"、"生成本周投稿报告"、或类似表达。也适用于自动化定时任务执行完毕后读取报告内容并推送。脚本路径：`C:\Users\X270\.workbuddy\skills\bibili-video-monitoring\bibili_weekly.js`；报告文件路径：`C:\Users\X270\WorkBuddy\Claw\.workbuddy\bibili_report.txt`；Cookie 文件路径：`C:\Users\X270\.workbuddy\skills\bibili-video-monitoring\bibili_cookie.txt`；推送通道1：调用 @skill://微信 PC 端自动控制 发送到微信联系人"微光浮影"；推送通道2：调用 @skill://QQ邮箱 发送 HTML 版报告到 1790219375@qq.com。
version: 1.0.0
author: 微光浮影
homepage: https://skillhub.cn/skills/bilibili-video-monitoring
license: MIT
tags: [bilibili, video, monitoring, automation, nodejs]
---

# bilibili 视频监控 v1.0.0

自动监控 B站 UP主投稿数据，生成周报并通过微信/QQ邮箱双通道推送。

## 功能

- 读取 B站 Cookie，通过内置 WBI 签名算法验证身份
- 获取 UP主最新投稿列表（默认 UID: 3493115144964536）
- 统计播放、点赞、收藏、分享、评论数据
- 获取最新3个视频的高赞评论（TOP5）
- 生成结构化文字报告，自动双通道推送

## 文件结构

```
bilibili-video-monitoring/
├── SKILL.md            # Skill 定义（本文件）
├── bibili_weekly.js    # 主执行脚本
├── bibili_cookie.txt   # Cookie 配置（需填写真实值）
└── README.md           # 详细使用说明
```

## 依赖

- Node.js（本机路径：`D:\node.exe`）
- 无额外 npm 依赖，WBI 签名纯 JS 实现
- 需提前配置「微信 PC 端自动控制」Skill
- 需提前配置「QQ邮箱」Skill

## 使用方法

### 1. 配置 Cookie

编辑同目录下的 `bibili_cookie.txt`，填入真实 Cookie：

```
SESSDATA=你的SESSDATA值
bili_jct=你的bili_jct值
DedeUserID=3493115144964536
DedeUserID__ckMd5=你的DedeUserID__ckMd5值
```

**获取方式：**
1. 浏览器登录 https://www.bilibili.com
2. F12 → Application → Cookies → https://www.bilibili.com
3. 找到上述四个字段，复制值填入

> ⚠️ Cookie 有效期约 30 天，过期后脚本会报错，需重新获取

### 2. 手动运行（测试）

```bash
D:\node.exe "C:\Users\X270\.workbuddy\skills\bibili-video-monitoring\bibili_weekly.js"
```

运行后自动：
1. 验证 Cookie 有效性
2. 拉取最新投稿数据
3. 生成报告写入 `C:\Users\X270\WorkBuddy\Claw\.workbuddy\bibili_report.txt`
4. （若由 Skill 调用）自动双通道推送

### 3. 触发词

以下表达均可触发本 Skill：
- 查看B站播报
- 运行播报脚本
- 生成本周投稿报告
- B站周报
- 检查我的B站投稿

## 双通道推送

| 通道 | 实现方式 | 推送目标 |
|------|----------|----------|
| 通道1 | 微信 PC 端自动控制 Skill | 微信联系人「微光浮影」 |
| 通道2 | QQ邮箱 Skill（nodemailer） | 1790219375@qq.com |

## 报告示例

```
🦞 B站每周播报
UP主：微光浮影_5903
数据周期：本周
─────────────────────
📹 投稿概览（共 2 个视频）

▎【视频标题】
  BV号：BV1xx411x7xx
  发布时间：2026-04-20
  播放：12.3万 | 点赞：8456 | 收藏：2345 | 分享：876 | 评论：1234

  💬 高赞评论 TOP5：
    1. 评论内容...
       👍 1234
...

─────────────────────
📊 本周合计
  总播放：XXX | 总点赞：XXX | 总评论：XXX

Powered by WorkBuddy 🦞
```

## 注意事项

1. Cookie 为敏感信息，勿泄露
2. 脚本内置 WBI 签名，无需安装任何 npm 包
3. 报告文件默认输出到 `C:\Users\X270\WorkBuddy\Claw\.workbuddy\bibili_report.txt`
4. 推送失败请检查：微信是否登录、QQ邮箱授权码是否配置

## 更新日志

### v1.0.0（2026-04-27）
- 初始版本，提交 SkillHub
- Slug：bilibili-video-monitoring
- 支持 WBI 签名自动生成
- 双通道推送（微信 + QQ邮箱）
