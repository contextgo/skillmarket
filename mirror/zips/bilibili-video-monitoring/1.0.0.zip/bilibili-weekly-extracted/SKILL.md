---
name: bilibili-weekly
description: |
  This skill should be used when the user asks to set up, run, or manage a Bilibili
  weekly report/notification, including fetching UP主投稿数据, 高赞评论, 播放/点赞/收藏/分享数据，
  or configuring a scheduled Bilibili data broadcast. It handles B站 Cookie management,
  WBI signature generation, and automated scheduled reporting via WorkBuddy automations.
---

# B站每周播报 Skill

## 功能概述

获取指定 B站 UP 主的投稿数据（播放/点赞/收藏/分享/评论），抓取高赞评论，并可配置为每周定时自动化推送。

## 核心脚本

**`scripts/bilibili_weekly.js`**

完整的数据获取脚本，包含：
- WBI 签名算法（lookup table 方式，已验证可用）
- Cookie 管理（从配置文件读取）
- 投稿列表获取 + 高赞评论抓取
- 格式化输出到报告文件

### 使用方式

```bash
node bilibili_weekly.js
```

### 依赖文件

| 文件 | 位置 | 说明 |
|------|------|------|
| Cookie 配置 | `~/.workbuddy/skills/bilibili-weekly/scripts/cookie.txt` | SESSDATA/bili_jct/DedeUserID 等 |
| 报告输出 | `~/.workbuddy/bilibili_report.txt` | 脚本运行后生成的报告文件 |

### Cookie 配置方法

用户需要从浏览器获取以下 Cookie 值（登录 bilibili.com 后 F12 → 存储 → Cookie → https://www.bilibili.com）：
- `SESSDATA`
- `bili_jct`
- `DedeUserID`
- `DedeUserID__ckMd5`

存入 `scripts/cookie.txt`，格式为每行 `key=value`。

### 自动化配置

如需配置每周定时播报，使用 WorkBuddy 自动化：

```toml
# 每周六 10:00 运行
rrule = "FREQ=WEEKLY;BYDAY=SA;BYHOUR=10;BYMINUTE=0"
prompt = "运行 bilibili_weekly.js，然后读取报告文件，将内容整理成文字发送给用户"
cwds = "~/.workbuddy/skills/bilibili-weekly/scripts"
```

### Cookie 失效处理

如果脚本报错 `Cookie 无效`，提示用户重新获取 Cookie 并更新 `cookie.txt` 文件。

### UID 和用户名

默认配置为老伙计的账号：
- UID: 3493115144964536
- 用户名: 微光浮影_5903

如需更换账号，修改脚本中的 `UID` 常量，并更新 Cookie 文件。
