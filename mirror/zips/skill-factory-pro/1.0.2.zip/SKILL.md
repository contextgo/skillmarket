---
name: skill-factory
version: 1.0.0
description: 技能工厂 · 元技能流水线+自学习进化引擎。触发：「做一个技能」「创建新技能」「技能开发」「合并技能」「优化技能描述」。7阶段：需求分析→Agent深挖→设计→生成→打包→Token优化→进化闭环。
---

## ⚠️ 技能存储路径

**查看 MEMORY.md 或询问用户。**

---

## 核心定位

**元技能**——生成技能的技能 + 自学习进化引擎。
**输出：** 可上架 SkillHub 的 .skill 包 + 变现方案。
**原则：** 每次只加载当前任务需要的文件，详细→references/。

---

## Phase 1：需求分析（3 问定位法）

| 问题 | 输出 |
|------|------|
| 触发场景 | 用户在什么场景下主动调用这个技能？ |
| 价值锚点 | 为什么比通用 AI 更好？ |
| 变现路径 | 用户为什么愿意为此付费？ |

**输出：** Skill 定位表（name / 触发词 / 价值 / 目标用户 / 定价）

---

## Phase 2：领域深挖（调用专业 Agent）

`sessions_spawn` + `runtime=subagent`：

| 领域 | Agent | 输出 |
|------|-------|------|
| 健康/中医/体质 | 赛华佗 | 知识体系 + 高频场景 |
| 财经/科技/热点 | 陶朱公 | 市场分析 + 机会信号 |
| 文案/观点 | 刀笔吏 | 通俗化框架 + 爆款公式 |

---

## Phase 3-5：设计·生成·打包

详见 `references/`：
- phase3-design.md（技能设计）
- phase4-content.md（内容生成）
- monetization.md（变现方案）

---

## Phase 6：Token 优化（每个技能必做）

**规范：**
- description ≤ 120字（前80功能+后40触发）
- SKILL.md ≤ 100行
- 动态加载：快速查询只读主体，深度分析按需加载

**自检清单：**
- [ ] description ≤ 120 字 ✓
- [ ] SKILL.md ≤ 100 行 ✓
- [ ] 详细知识移至 references/ ✓
- [ ] 脚本实测可用 ✓

---

## Phase 7：进化闭环

**五步闭环：** 经验提取 → 知识存储 → 检索 → 验证 → 改进

详见 `references/evolution-loop.md`

---

## 快速启动

当用户说「帮我做一个 xxx 技能」时：
1. Phase 1：3问定位法
2. Phase 2：Agent深挖
3. Phase 3：设计技能结构
4. Phase 4：生成 SKILL.md + references/
5. **Phase 4.5：完善技能描述**（确保 description ≤ 120字，含功能+触发场景）
6. Phase 5：打包 + 变现
7. Phase 6：Token自检
8. Phase 7：验证 + 交付

全流程约3-5轮，每个Phase完成后汇报。