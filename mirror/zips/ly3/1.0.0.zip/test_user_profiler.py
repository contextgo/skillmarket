# -*- coding: utf-8 -*-
"""
UserProfiler 测试脚本
测试用户画像构建、信息提取、长期记忆等核心功能
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from user_profiler import UserProfiler, UserProfile, InfoType


def test_profile_creation():
    """测试用户画像创建"""
    print("\n=== 测试1: 用户画像创建 ===")

    profiler = UserProfiler()

    profile = profiler.get_profile("user_001")
    print(f"  用户ID: {profile.get('user_id', profile.get('_user'))}")
    print(f"  创建时间: {profile.get('_created')}")

    status = "PASS" if profile.get('_user') == "user_001" else "FAIL"
    print(f"  [{status}] 用户画像正常")


def test_info_extraction():
    """测试信息提取"""
    print("\n=== 测试2: 信息提取 ===")

    profiler = UserProfiler()

    test_messages = [
        "我叫张三，平时用Python写代码",
        "我住在上海，喜欢打篮球",
        "我叫李四，讨厌香菜",
        "我今年25岁，在北京工作",
        "我喜欢机器学习和人工智能",
    ]

    for msg in test_messages:
        info = profiler.extract_info(msg)
        if info:
            print(f"  输入: {msg}")
            for item in info:
                print(f"    → [{item['type']}] {item['value']} (来源: {item['source'][:30]}...)")
        else:
            print(f"  输入: {msg} → 无提取")


def test_profile_update():
    """测试画像更新"""
    print("\n=== 测试3: 画像更新 ===")

    profiler = UserProfiler()
    user_id = "test_user"

    # 收集信息
    messages = [
        "我叫小明",
        "我住在深圳",
        "我是一名程序员",
        "我每天用Python工作",
    ]

    for msg in messages:
        info = profiler.extract_info(msg)
        for item in info:
            profiler.update_profile(user_id, item)

    # 获取更新后的画像
    profile = profiler.get_or_create_profile(user_id)
    print(f"  名字: {profile.name}")
    print(f"  位置: {profile.location}")
    print(f"  职业: {profile.occupation}")
    print(f"  偏好: {profile.preferences}")
    print(f"  已知事实数: {len(profile.facts)}")

    status = "PASS" if profile.name == "小明" else "FAIL"
    print(f"  [{status}] 画像更新正常")


def test_conversation_context():
    """测试对话上下文学习"""
    print("\n=== 测试4: 对话上下文学习 ===")

    profiler = UserProfiler()
    user_id = "learner_user"

    # 模拟对话
    conversation = [
        ("我想学Python，应该从哪里开始？", "ai"),
        ("你好，我是王老师", "user"),
        ("Python入门可以看《Python编程从入门到实践》", "ai"),
        ("谢谢王老师！", "user"),
    ]

    for msg, role in conversation:
        profiler.add_to_context(user_id, msg, role)

    # 获取上下文摘要
    summary = profiler.get_context_summary(user_id, limit=5)
    print(f"  上下文摘要: {summary[:100]}...")

    # 获取学习到的信息
    profile = profiler.get_or_create_profile(user_id)
    print(f"  学到的名字: {profile.name}")
    print(f"  学到的偏好: {profile.preferences}")


def test_facts_retrieval():
    """测试事实检索"""
    print("\n=== 测试5: 事实检索 ===")

    profiler = UserProfiler()
    user_id = "fact_user"

    # 添加一些事实
    facts = [
        {"type": InfoType.NAME, "value": "小李", "source": "用户自我介绍"},
        {"type": InfoType.LOCATION, "value": "广州", "source": "对话中提到"},
        {"type": InfoType.PREFERENCE, "value": "咖啡", "source": "聊天记录"},
    ]
    for fact in facts:
        profiler.update_profile(user_id, fact)

    # 检索
    retrieved = profiler.retrieve_facts(user_id, query="名字", top_k=3)
    print(f"  检索'名字': {[r['value'] for r in retrieved]}")

    retrieved = profiler.retrieve_facts(user_id, query="地点", top_k=3)
    print(f"  检索'地点': {[r['value'] for r in retrieved]}")


def test_profile_serialization():
    """测试画像序列化"""
    print("\n=== 测试6: 画像序列化 ===")

    profiler = UserProfiler()
    user_id = "serialize_user"

    # 添加数据
    profiler.update_profile(user_id, {"type": InfoType.NAME, "value": "测试用户", "source": "test"})
    profiler.update_profile(user_id, {"type": InfoType.PREFERENCE, "value": "测试偏好", "source": "test"})

    # 序列化
    data = profiler.export_profile(user_id)
    print(f"  序列化字段: {list(data.keys())}")
    print(f"  名字: {data.get('name')}")
    print(f"  偏好数: {len(data.get('preferences', []))}")

    # 反序列化
    new_profiler = UserProfiler()
    new_profiler.import_profile(user_id, data)
    profile = new_profiler.get_or_create_profile(user_id)
    print(f"  反序列化名字: {profile.name}")

    status = "PASS" if profile.name == "测试用户" else "FAIL"
    print(f"  [{status}] 序列化正常")


if __name__ == "__main__":
    print("=" * 60)
    print("UserProfiler 测试套件")
    print("=" * 60)

    test_profile_creation()
    test_info_extraction()
    test_profile_update()
    test_conversation_context()
    test_facts_retrieval()
    test_profile_serialization()

    print("\n" + "=" * 60)
    print("测试完成！")
    print("=" * 60)
