# UserProfiler 对话学习器

> 让AI越用越懂你，自动学习用户习惯和偏好

## 核心理念

每次对话都是学习的机会。用户不经意的一句话，可能包含了宝贵的个人信息。

- 用户说"我叫张三" → 学到名字
- 用户说"我讨厌香菜" → 学到饮食偏好
- 用户说"这个太高深了" → 学到解释风格偏好

## 核心功能

### 1. 自动信息提取
从对话中自动提取结构化信息：

| 信息类型 | 示例 | 说明 |
|---------|------|------|
| NAME | "我叫张三" | 用户名字 |
| LOCATION | "我住在深圳" | 所在地 |
| OCCUPATION | "我是程序员" | 职业 |
| PREFERENCE | "我喜欢Python" | 偏好 |
| HOBBY | "我爱打篮球" | 爱好 |
| HABIT | "我每天11点睡" | 习惯 |
| FEEDBACK | "解释太复杂了" | 反馈 |

### 2. 用户画像构建
- 累积式学习，越用越准
- 多维度画像：名字、位置、职业、偏好...
- 置信度评分，区分确定/不确定信息
- 来源追踪，知道信息来源

### 3. 对话上下文学习
- 短期对话记忆
- 学习用户的提问风格
- 学习用户的解释偏好
- 跨会话上下文延续

### 4. 长期记忆
- 持久化存储，重启不丢失
- 支持导出/导入
- 定期清理过时信息

### 5. 事实检索
- 语义搜索相关记忆
- 支持模糊匹配
- 返回相关度评分

## 安装

```bash
pip install -r requirements.txt
```

## 快速使用

```python
from user_profiler import UserProfiler, InfoType

# 初始化
profiler = UserProfiler()

# 处理用户消息
user_id = "user_001"

messages = [
    "我叫张三，平时用Python写代码",
    "我住在深圳南山区",
    "我是一名后端工程师",
    "我每天早上9点上班",
]

for msg in messages:
    info = profiler.extract_info(msg)
    for item in info:
        profiler.update_profile(user_id, item)

# 获取用户画像
profile = profiler.get_or_create_profile(user_id)
print(f"名字: {profile.name}")
print(f"位置: {profile.location}")
print(f"职业: {profile.occupation}")
print(f"偏好: {profile.preferences}")
print(f"已知事实: {len(profile.facts)} 条")

# 检索相关信息
results = profiler.retrieve_facts(user_id, query="工作相关", top_k=3)
for r in results:
    print(f"  - {r['value']}")
```

## 进阶配置

```python
profiler = UserProfiler(
    memory_days=30,           # 信息保留天数
    confidence_threshold=0.5, # 置信度阈值
    max_facts=100,            # 最大事实数
    auto_clean=True,          # 自动清理
)
```

## 信息提取示例

```python
test_messages = [
    "我叫李明",
    "我来自北京",
    "我是一名大学生",
    "我学习人工智能专业",
    "我喜欢听音乐和看电影",
    "我每天跑步半小时",
    "我讨厌加班",
    "我最近在学习React",
]

for msg in test_messages:
    info = profiler.extract_info(msg)
    if info:
        for item in info:
            print(f"[{item['type']}] {item['value']}")
```

## 适用场景

- 个人AI助手
- 客服对话系统
- 教育AI导师
- 社交聊天机器人
- CRM客户画像

## 与其他方案的区别

| 功能 | 纯上下文 | 关键词匹配 | UserProfiler |
|------|---------|-----------|-------------|
| 信息提取 | 无 | 简单匹配 | 智能理解 |
| 画像构建 | 无 | 无 | 完整画像 |
| 长期记忆 | 无 | 无 | 持久化 |
| 事实检索 | 无 | 精确匹配 | 语义搜索 |
| 置信度 | 无 | 无 | 完整追踪 |

## 信息提取原理

1. **正则匹配** — 识别固定格式（名字、电话、邮箱）
2. **句式分析** — 识别主谓宾结构（我+是/喜欢/讨厌+X）
3. **上下文理解** — 考虑前后文消除歧义
4. **置信度评估** — 根据信息来源和质量打分

## 数据格式

```python
@dataclass
class ExtractedInfo:
    type: InfoType           # 信息类型
    value: str              # 信息值
    confidence: float       # 置信度 0-1
    source: str             # 来源文本
    extracted_at: str       # 提取时间

@dataclass
class UserProfile:
    user_id: str
    name: str = ""
    location: str = ""
    occupation: str = ""
    preferences: List[str] = []
    facts: List[ExtractedInfo] = []
    last_updated: str = ""
```

## 技术细节

- 依赖：Python 3.8+
- 无需外部API，纯本地运行
- 数据持久化：JSON文件
- 内存占用 < 20MB
- 提取时间 < 5ms/条

## License

MIT License
