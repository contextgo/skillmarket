# -*- coding: utf-8 -*-
"""
UserProfiler - 对话学习器
版本: 1.0.0

自动从对话中提取用户信息，构建用户画像。
无外部依赖，纯标准库实现。
"""

import json
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any


# ============================================================================
# 提取规则库（模式 → 字段映射）
# ============================================================================
EXTRACT_RULES = [
    # 姓名
    {"field": "name", "patterns": [
        r"(?:我叫|我是|叫我|称呼我)[：:\s]*([^\s，。,!！\?？]+)",
        r"(?:我的名字是|名字叫)[：:\s]*([^\s，。,!！\?？]+)",
        r"(?:大家好|你好)[，,\s]*我(?:是|叫)([^\s，。,!！\?？]+)",
    ], "weight": 0.9},

    # 职业
    {"field": "job", "patterns": [
        r"我(?:是|做|当)([^\s，。,!！\?？]{2,8}(?:程序员|工程师|设计师|产品|运营|医生|律师|老师|学生|厨师))",
        r"我(?:是)?(?:一名|一个)([^\s，。,!！\?？]{2,8})",
        r"我(?:在)?(?:做|搞|干)([^\s，。,!！\?？]{2,8})(?:的|工作)",
    ], "weight": 0.8},

    # 地点
    {"field": "location", "patterns": [
        r"我(?:在|住在|位于)([^\s，。,!！\?？]{2,6}(?:省|市|区|县|镇))",
        r"我(?:在|住在)([^\s，。,!！\?？]{2,6})",
        r"(?:来自|老家在)([^\s，。,!！\?？]{2,8})",
    ], "weight": 0.75},

    # 偏好
    {"field": "prefer", "is_list": True, "patterns": [
        r"我(?:喜欢|爱|偏好|比较喜欢)[：:\s]*([^\s，。,!！\?？]+)",
        r"我(?:最喜欢)[：:\s]*([^\s，。,!！\?？]+)",
        r"我(?:觉得|认为)[：:\s]*(.{4,30})比较好",
    ], "weight": 0.7},

    # 不喜欢
    {"field": "dislike", "is_list": True, "patterns": [
        r"我(?:不喜欢|讨厌|不爱|不想要)[：:\s]*([^\s，。,!！\?？]+)",
        r"别(?:说|用|给我)[：:\s]*([^\s，。,!！\?？]+)",
        r"不(?:要|用|需要)[：:\s]*([^\s，。,!！\?？]+)",
    ], "weight": 0.7},

    # 技能/工具
    {"field": "skills", "is_list": True, "patterns": [
        r"我(?:会|懂|学过|用过)[：:\s]*([^\s，。,!！\?？]+)",
        r"我(?:在学|在用)[：:\s]*([^\s，。,!！\?？]+)",
    ], "weight": 0.65},

    # 习惯
    {"field": "habits", "is_list": True, "patterns": [
        r"我(?:每天|每周|平时|经常)[：:\s]*(.*?)(?:呢|哦|的|$)",
        r"我(?:习惯|喜欢)[：:\s]*(.*?)(?:呢|哦|的|$)",
    ], "weight": 0.6},
]


class UserProfiler:
    """
    UserProfiler - 对话学习器（一体化接口）

    用法：
        up = UserProfiler()
        up.learn("小明", "我叫小明，是个Python程序员，住在上海，喜欢写代码")
        profile = up.get_profile("小明")
        prompt = up.generate_system_prompt("小明")
    """

    def __init__(self, data_dir: str = "./profiler_data"):
        self._dir = Path(data_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._db: Dict[str, Dict] = self._load_all()

    def _file_for(self, user: str) -> Path:
        safe = re.sub(r'[^\w\u4e00-\u9fff]', '_', user)
        return self._dir / f"{safe}.json"

    def _load_all(self) -> Dict[str, Dict]:
        db = {}
        for f in self._dir.glob("*.json"):
            try:
                with open(f, "r", encoding="utf-8") as fp:
                    data = json.load(fp)
                    user = data.get("_user", f.stem)
                    db[user] = data
            except Exception:
                pass
        return db

    def _save(self, user: str):
        p = self._file_for(user)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(self._db[user], f, ensure_ascii=False, indent=2)

    def _ensure(self, user: str):
        if user not in self._db:
            self._db[user] = {
                "_user": user,
                "_created": datetime.now().isoformat(),
                "_updated": datetime.now().isoformat(),
                "_learn_count": 0,
            }

    def learn(self, user: str, text: str) -> Dict[str, List[str]]:
        """
        从文本中提取用户信息并存储

        Returns:
            本次提取到的新信息 {field: [values]}
        """
        self._ensure(user)
        learned: Dict[str, List[str]] = {}

        for rule in EXTRACT_RULES:
            field = rule["field"]
            is_list = rule.get("is_list", False)

            for pattern in rule["patterns"]:
                matches = re.findall(pattern, text)
                for match in matches:
                    val = match.strip()
                    if not val or len(val) > 30:
                        continue

                    if is_list:
                        existing = self._db[user].get(field, [])
                        if isinstance(existing, list) and val not in existing:
                            existing.append(val)
                            self._db[user][field] = existing
                            learned.setdefault(field, []).append(val)
                    else:
                        if field not in self._db[user]:
                            self._db[user][field] = val
                            learned.setdefault(field, []).append(val)

        self._db[user]["_updated"] = datetime.now().isoformat()
        self._db[user]["_learn_count"] = self._db[user].get("_learn_count", 0) + 1
        self._save(user)
        return learned

    def get_profile(self, user: str) -> Dict:
        """获取用户画像（过滤内部字段）"""
        data = self._db.get(user, {})
        return {k: v for k, v in data.items() if not k.startswith("_")}

    def get(self, user: str, field: str) -> Any:
        """获取特定字段"""
        return self._db.get(user, {}).get(field)

    def update(self, user: str, field: str, value: Any):
        """手动更新字段"""
        self._ensure(user)
        is_list_field = field in ("prefer", "dislike", "skills", "habits")
        if is_list_field:
            existing = self._db[user].get(field, [])
            if isinstance(existing, list) and value not in existing:
                existing.append(value)
            self._db[user][field] = existing
        else:
            self._db[user][field] = value
        self._db[user]["_updated"] = datetime.now().isoformat()
        self._save(user)

    def generate_system_prompt(self, user: str) -> str:
        """
        生成用于注入 AI 系统提示的用户画像描述

        Returns:
            可直接拼接到 system_prompt 的文字
        """
        profile = self.get_profile(user)
        if not profile:
            return ""

        parts = []
        if "name" in profile:
            parts.append(f"用户叫{profile['name']}")
        if "job" in profile:
            parts.append(f"职业是{profile['job']}")
        if "location" in profile:
            parts.append(f"住在{profile['location']}")
        if "skills" in profile and profile["skills"]:
            parts.append(f"会使用{'/'.join(profile['skills'][:3])}")
        if "prefer" in profile and profile["prefer"]:
            parts.append(f"偏好：{'、'.join(profile['prefer'][:3])}")
        if "dislike" in profile and profile["dislike"]:
            parts.append(f"不喜欢：{'、'.join(profile['dislike'][:3])}")

        if not parts:
            return ""

        intro = "。".join(parts) + "。"
        return f"[用户信息] {intro}请根据以上信息个性化回复。"

    def get_all_users(self) -> List[str]:
        return [u for u in self._db.keys() if not u.startswith("_")]

    def export(self, user: str, output_path: str):
        """导出用户画像到文件"""
        profile = self.get_profile(user)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(profile, f, ensure_ascii=False, indent=2)

    def clear(self, user: str):
        """清除用户画像"""
        if user in self._db:
            del self._db[user]
            p = self._file_for(user)
            if p.exists():
                p.unlink()
