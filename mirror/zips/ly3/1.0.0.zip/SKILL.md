---
name: user-profiler
version: 1.0.0
author: 玲瑶
description: |
  对话学习器：AI 自动从对话中提取用户偏好、身份、习惯，构建用户画像，越用越懂你。
  
  触发词：用户画像、自动学习、记住用户、了解用户、用户偏好、
  用户信息提取、对话学习、偏好学习、记住我的习惯、学习用户、
  用户身份、个性化助手、记住偏好、user profile、learn from chat、
  越用越懂我、记住我说的、提取用户信息、构建用户模型、
  持久化记忆、记住用户名字
  
  使用场景：
  - 个性化 AI 助手：记住用户的名字/喜好/习惯
  - 客服系统：积累用户信息减少重复询问
  - 教育助手：追踪学习进度和薄弱点
  - 推荐系统：基于聊天内容推断用户兴趣
---

# UserProfiler 对话学习器

## 能做什么

UserProfiler 让 AI 在聊天过程中自动学习用户信息——不需要用户主动填写，不需要问卷，只需要正常对话。

### 自动提取的信息类型

| 类别 | 示例提取 |
|------|---------|
| **身份** | "我叫小明" → `name: 小明` |
| **偏好** | "我喜欢Python" → `prefer: Python` |
| **地点** | "我在上海" → `location: 上海` |
| **职业** | "我是程序员" → `job: 程序员` |
| **负向反馈** | "别说那么正式" → `dislike: 正式口吻` |
| **习惯** | "我每天晚上11点睡" → `habit: 晚睡` |

## 快速使用

```python
from user_profiler import UserProfiler

profiler = UserProfiler()

# 1. 从对话中学习
profiler.learn("小明", "我叫小明，是个Python程序员，住在北京")
profiler.learn("小明", "我喜欢简洁的回复，别废话太多")

# 2. 获取用户画像
profile = profiler.get_profile("小明")
print(profile)
# {
#   "name": "小明",
#   "job": "Python程序员",
#   "location": "北京",
#   "prefer": ["简洁回复"],
#   "dislike": ["废话"]
# }

# 3. 生成个性化系统提示词
system_prompt = profiler.generate_system_prompt("小明")
# "用户叫小明，程序员，在北京。偏好：简洁回复。请注意：别废话太多。"

# 4. 查询某个字段
name = profiler.get("小明", "name")  # → "小明"

# 5. 手动更新
profiler.update("小明", "prefer", "用中文回复")

# 6. 导出画像
profiler.export("小明", "profile_小明.json")
```

## 学习原理

```
用户说话
    ↓ 关键词匹配 + 句式模板
提取实体（姓名/地点/职业/偏好）
    ↓ 置信度评估
写入用户画像（JSON持久化）
    ↓ 下次对话
自动注入到 AI 上下文
```

## 依赖

- Python 3.8+
- 无需第三方库（仅用标准库）
- 可选：`jieba` 提升中文分词效果
