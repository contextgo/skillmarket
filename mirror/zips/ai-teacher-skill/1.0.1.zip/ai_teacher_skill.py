# -*- coding: utf-8 -*-
"""
QClaw Skill - AI老师·知识成长树
跨平台：macOS / Linux / Windows
功能：轻量化科普 + 知识树 + 自动收录未知知识点 + 主动推荐
"""
import json
import random
import os

# 扩充后 超丰富 基础知识库
KNOWLEDGE_BASE = {
    "科技与AI": {
        "人工智能": ["大模型", "深度学习", "机器学习", "神经网络", "自然语言处理", "计算机视觉", "生成式AI", "AGI", "提示词工程", "AI幻觉"],
        "云计算": ["云计算", "云服务器", "云存储", "边缘计算", "容器", "微服务", "虚拟化", "分布式", "公有云", "私有云"],
        "互联网技术": ["区块链", "元宇宙", "Web3", "大数据", "5G", "6G", "物联网", "加密货币", "NFT", "数字孪生"],
        "编程与工具": ["Python", "Java", "算法", "数据结构", "API", "开源", "低代码", "自动化", "爬虫", "数据库"]
    },
    "心理学": {
        "行为心理": ["内卷", "禀赋效应", "从众心理", "破窗效应", "蝴蝶效应", "马太效应", "晕轮效应", "旁观者效应", "锚定效应", "鸵鸟心态"],
        "认知心理": ["认知失调", "潜意识", "思维定势", "注意力偏差", "自我效能感", "达克效应", "证实偏见", "情绪管理", "记忆曲线", "批判性思维"],
        "社会心理": ["社交恐惧", "讨好型人格", "精神内耗", "安全感", "同理心", "边界感", "自我认同", "压力管理", "拖延症", "习得性无助"]
    },
    "自然科学": {
        "物理": ["熵增定律", "量子纠缠", "相对论", "黑洞", "引力波", "暗物质", "热力学", "惯性", "电磁波", "量子力学"],
        "生物": ["进化论", "基因", "细胞", "DNA", "RNA", "新陈代谢", "免疫力", "微生物", "光合作用", "染色体"],
        "化学": ["元素周期表", "化学键", "氧化反应", "催化剂", "同位素", "高分子", "酸碱平衡", "晶体", "溶解", "燃烧"]
    },
    "经济学与商业": {
        "基础经济": ["供需关系", "通货膨胀", "通货紧缩", "GDP", "利率", "汇率", "市场调节", "垄断", "自由市场", "计划经济"],
        "商业思维": ["复利", "边际成本", "沉没成本", "机会成本", "护城河", "流量变现", "商业模式", "品牌溢价", "用户增长", "规模化"],
        "金融理财": ["基金", "股票", "债券", "保险", "复利理财", "资产配置", "风险控制", "定投", "信用", "流动性"]
    },
    "人文历史": {
        "世界历史": ["文艺复兴", "工业革命", "启蒙运动", "大航海时代", "冷战", "殖民时代", "罗马帝国", "古埃及", "中世纪", "二战"],
        "中国历史": ["诸子百家", "唐宋元明清", "丝绸之路", "四大发明", "辛亥革命", "长城", "故宫", "甲骨文", "科举制", "青铜器"],
        "文化常识": ["国学", "哲学", "礼仪", "神话", "宗教", "艺术", "文学", "诗词", "书法", "非遗文化"]
    },
    "法律常识": {
        "基础法律": ["民法典", "刑法", "宪法", "诉讼时效", "证据规则", "法律效力", "法人", "自然人", "侵权责任", "违约责任"],
        "生活法律": ["劳动合同", "消费维权", "借贷纠纷", "婚姻家事", "交通事故", "工伤认定", "隐私权", "肖像权", "名誉权", "知识产权"]
    },
    "健康与生活": {
        "身体健康": ["新陈代谢", "免疫力", "睡眠周期", "有氧运动", "无氧运动", "肌肉修复", "维生素", "矿物质", "血糖", "血压"],
        "生活方式": ["断舍离", "时间管理", "冥想", "自律", "专注力", "养生", "饮食健康", "补水", "护眼", "抗疲劳"],
        "情绪健康": ["抑郁症", "焦虑症", "心理疏导", "自我疗愈", "积极心态", "幸福感", "情绪稳定", "放松", "减压", "正念"]
    },
    "职场与成长": {
        "职场技能": ["沟通表达", "汇报技巧", "时间管理", "目标管理", "执行力", "复盘", "领导力", "团队协作", "谈判", "演讲"],
        "个人提升": ["学习力", "复盘思维", "复盘法", "刻意练习", "知识体系", "认知升级", "格局", "视野", "自律", "习惯养成"]
    }
}

# 跨平台用户数据路径
USER_DATA_DIR = os.path.join(os.path.dirname(__file__), "user_knowledge")
os.makedirs(USER_DATA_DIR, exist_ok=True)


class AITeacherSkill:
    def __init__(self):
        self.name = "AI老师·知识成长树"

    def _get_user_file(self, uid):
        return os.path.join(USER_DATA_DIR, f"{uid}.json")

    def get_user_data(self, uid):
        path = self._get_user_file(uid)
        if not os.path.exists(path):
            return {"uid": uid, "learned": {}, "total": 0}
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_user_data(self, uid, data):
        path = self._get_user_file(uid)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def add_knowledge(self, uid, domain, sub_domain, concept):
        data = self.get_user_data(uid)
        if domain not in data["learned"]:
            data["learned"][domain] = {}
        if sub_domain not in data["learned"][domain]:
            data["learned"][domain][sub_domain] = []
        if concept not in data["learned"][domain][sub_domain]:
            data["learned"][domain][sub_domain].append(concept)
            data["total"] += 1
        self.save_user_data(uid, data)

    def render_knowledge_tree(self, uid):
        data = self.get_user_data(uid)
        tree = "🌳 你的知识成长树\n\n"
        for domain, subs in data["learned"].items():
            tree += f"{domain}\n"
            for sub, concepts in subs.items():
                tree += f"  └─ {sub}：{'、'.join(concepts)}\n"
        tree += f"\n已点亮 {data['total']} 个知识点，继续探索更茂盛～"
        return tree

    def find_domain(self, concept):
        for domain, subs in KNOWLEDGE_BASE.items():
            for sub, cons in subs.items():
                if concept in cons:
                    return domain, sub
        return None, None

    def answer_concept(self, concept):
        return f"{concept}：通识知识点，简单了解即可拓宽知识边界。"

    def recommend_concept(self, uid):
        user = self.get_user_data(uid)
        for domain, subs in KNOWLEDGE_BASE.items():
            for sub, cons in subs.items():
                for c in cons:
                    if c not in user["learned"].get(domain, {}).get(sub, []):
                        return domain, sub, c
        return None, None, None

    def run_intent(self, intent, uid, params=None):
        params = params or {}
        concept = params.get("concept", "")

        if intent == "show_tree":
            return self.render_knowledge_tree(uid)

        if intent == "ask_concept":
            if not concept:
                return "请告诉我你想了解的知识点~"
            domain, sub = self.find_domain(concept)
            if not domain:
                domain = "通识知识"
                sub = "其他常识"
            self.add_knowledge(uid, domain, sub, concept)
            ans = self.answer_concept(concept)
            nd, ns, nc = self.recommend_concept(uid)
            if nc:
                ans += f"\n\n和它相关的【{nc}】也很有趣，要听听吗？"
            return ans

        if intent == "recommend":
            d, s, c = self.recommend_concept(uid)
            if not c:
                return "🎉 你已掌握当前所有知识点，继续探索新领域吧！"
            self.add_knowledge(uid, d, s, c)
            return f"为你推荐：【{c}】\n{c}：轻松了解，拓宽边界～"

        return "你好，我是AI老师，告诉我任意知识点，我来为你科普～"


skill = AITeacherSkill()