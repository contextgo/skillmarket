#!/bin/bash
set -e
echo "===== AI老师 Skill 部署（跨平台） ====="
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
mkdir -p "$DIR/user_knowledge"
echo "✅ 部署完成"
echo "✅ 用户数据目录：$DIR/user_knowledge"
echo "✅ 支持 macOS / Linux / Windows"