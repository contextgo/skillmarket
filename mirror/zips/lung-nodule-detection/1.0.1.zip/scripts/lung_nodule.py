#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
肺结节检测科研分析模型 - 调用脚本
接口路径:
  提交: /openapi/lungNoduleSubmit (异步)
  查询: /openapi/lungNoduleQuery  (异步)
数据要求: 胸部 CT 序列（ZIP）
"""

import sys
import os
import time
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shared_api import file_to_base64, api_post, print_response


def submit(file_path: str) -> dict:
    """提交肺结节检测任务。"""
    if not os.path.isfile(file_path):
        return {"code": -1, "message": f"文件不存在: {file_path}"}

    body = {
        "fileBase64": file_to_base64(file_path),
        "fileName": os.path.basename(file_path),
    }

    resp = api_post("/openapi/lungNoduleSubmit", body)
    print_response(resp, "肺结节检测任务提交")

    task_id = resp.get("head", {}).get("taskId", "")
    if task_id:
        print(f"  ✅ 任务提交成功，taskId: {task_id}")
        print(f"  请使用 taskId 查询结果")

    return resp


def query(task_id: str) -> dict:
    """查询肺结节检测结果。"""
    body = {"taskId": task_id}
    resp = api_post("/openapi/lungNoduleQuery", body)
    print_response(resp, "肺结节检测结果查询")

    task_status = resp.get("taskStatus", -1)
    status_map = {
        0: "已提交", 1: "处理中", 2: "处理成功",
        3: "处理失败", 4: "任务不存在"
    }
    print(f"  任务状态: {status_map.get(task_status, str(task_status))}")

    if task_status == 2:
        nodule_list = resp.get("lungNoduleList", [])
        if nodule_list:
            print(f"\n  检测到 {len(nodule_list)} 个肺结节:")
            for i, nodule in enumerate(nodule_list, 1):
                name = nodule.get("name", "未命名")
                ntype = nodule.get("type", "")
                labels = nodule.get("label", [])
                value = nodule.get("value", [])
                print(f"\n  结节 #{i}:")
                print(f"    名称: {name}")
                print(f"    可视化类型: {ntype}")
                print(f"    标签: {', '.join(labels) if labels else '无'}")
                if value:
                    print(f"    坐标/尺寸 [x,y,z,w,h,d]: {value}")
        else:
            print(f"\n  未检测到肺结节")

    return resp


def poll(task_id: str, interval: int = 10, max_wait: int = 600) -> dict:
    """
    轮询等待异步任务完成。

    Args:
        task_id:  任务 ID
        interval: 轮询间隔秒数（默认 10s）
        max_wait: 最大等待秒数（默认 600s）
    """
    elapsed = 0
    while elapsed < max_wait:
        resp = query(task_id)
        task_status = resp.get("taskStatus", -1)

        if task_status == 2:
            return resp
        elif task_status in (3, 4):
            return resp
        else:
            print(f"  等待处理中... ({elapsed}s/{max_wait}s)")
            time.sleep(interval)
            elapsed += interval

    return {"taskStatus": -1, "message": f"轮询超时（{max_wait}s），任务可能仍在处理中"}


def run(file_path: str, poll_result: bool = True) -> dict:
    """
    完整流程：提交任务 -> 轮询结果。

    Args:
        file_path:    胸部 CT ZIP 文件路径
        poll_result:  是否自动轮询结果（默认 True）
    """
    # Step 1: 提交任务
    submit_resp = submit(file_path)
    task_id = submit_resp.get("head", {}).get("taskId", "")
    code = submit_resp.get("head", {}).get("code", submit_resp.get("code", -1))

    if code != 0 or not task_id:
        return submit_resp

    if not poll_result:
        print(f"\n  提示: taskId={task_id}，可稍后使用查询功能获取结果")
        return submit_resp

    # Step 2: 等待并轮询结果
    print(f"\n  开始轮询结果（taskId: {task_id}）...")
    return poll(task_id)


if __name__ == "__main__":
    subcmd = sys.argv[1] if len(sys.argv) > 1 else "run"

    if subcmd == "submit":
        if len(sys.argv) != 3:
            print("用法: python lung_nodule.py submit <CT_ZIP文件路径>")
            sys.exit(1)
        result = submit(sys.argv[2])

    elif subcmd == "query":
        if len(sys.argv) != 3:
            print("用法: python lung_nodule.py query <taskId>")
            sys.exit(1)
        result = query(sys.argv[2])

    elif subcmd == "run":
        if len(sys.argv) != 3:
            print("用法: python lung_nodule.py run <CT_ZIP文件路径>")
            sys.exit(1)
        result = run(sys.argv[2])

    else:
        print("用法:")
        print("  python lung_nodule.py submit <文件路径>  # 提交任务")
        print("  python lung_nodule.py query <taskId>     # 查询结果")
        print("  python lung_nodule.py run <文件路径>     # 提交并等待结果")
        sys.exit(1)

    code = result.get("head", {}).get("code", result.get("code", -1))
    task_status = result.get("taskStatus", -1)
    sys.exit(0 if code == 0 and task_status == 2 else 1)
