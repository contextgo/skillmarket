#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
开放实验平台 AI 模型调用 - 共享工具库
提供 HMAC-SHA256 签名计算、鉴权请求、文件 base64 编码等通用能力。
"""

import hmac
import hashlib
import base64
import json
import os
import sys
import time
import urllib.request
import urllib.error

BASE_URL = "https://test.pacs.qq.com"

# 硬编码的鉴权凭据
DEFAULT_APP_ID = "100009"
DEFAULT_TOKEN = "156a9dd4-d69f-4f05-8141-af92835a5a5f"

# 输出中需要隐藏的字段
HIDDEN_FIELDS = {"resourceRemaining", "requestId", "studyInstanceUID", "seriesInstanceUID"}


def generate_signature(token: str, app_id: str) -> tuple:
    """
    生成鉴权所需的 timestamp 和 signature。
    signature = HMAC-SHA256(token, appId + timestamp)

    Returns:
        (timestamp, signature)
    """
    timestamp = str(int(time.time() * 1000))
    message = app_id + timestamp
    signature = hmac.new(
        token.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
    return timestamp, signature


def build_headers(app_id: str = None, token: str = None) -> dict:
    """构建带鉴权信息的请求头。"""
    app_id = app_id or DEFAULT_APP_ID
    token = token or DEFAULT_TOKEN
    timestamp, signature = generate_signature(token, app_id)
    return {
        "Content-Type": "application/json",
        "appId": app_id,
        "timestamp": timestamp,
        "signature": signature,
    }


def file_to_base64(file_path: str) -> str:
    """读取文件并编码为 base64 字符串。"""
    with open(file_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def api_post(path: str, body: dict, app_id: str = None, token: str = None, timeout: int = 120) -> dict:
    """
    发送 POST JSON 请求到开放实验平台。

    Args:
        path:    接口路径，如 /openapi/lungNoduleSubmit
        body:    请求体 dict
        app_id:  合作方 ID（默认使用硬编码值）
        token:   密钥（默认使用硬编码值）
        timeout: 超时秒数（同步接口默认 120s）

    Returns:
        响应 JSON dict
    """
    app_id = app_id or DEFAULT_APP_ID
    token = token or DEFAULT_TOKEN
    url = BASE_URL + path
    headers = build_headers(app_id, token)
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")

    req = urllib.request.Request(url, data=data, headers=headers, method="POST")

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8", errors="replace")
        return {
            "code": e.code,
            "message": f"HTTP {e.code}: {error_body}",
        }
    except urllib.error.URLError as e:
        return {
            "code": -1,
            "message": f"请求失败: {e.reason}",
        }
    except Exception as e:
        return {
            "code": -1,
            "message": f"未知错误: {str(e)}",
        }


def _filter_dict(d: dict) -> dict:
    """过滤掉隐藏字段，返回干净的 dict。"""
    if isinstance(d, dict):
        return {k: _filter_dict(v) for k, v in d.items() if k not in HIDDEN_FIELDS}
    if isinstance(d, list):
        return [_filter_dict(item) for item in d]
    return d


def print_response(resp: dict, label: str = "响应结果") -> None:
    """格式化打印响应结果（隐藏资源剩余次数、请求ID、DICOM UID等）。"""
    head = resp.get("head", {})
    code = head.get("code", resp.get("code", "N/A"))
    message = head.get("message", resp.get("message", ""))
    task_id = head.get("taskId", "")

    print(f"\n{'='*60}")
    print(f"  {label}")
    print(f"{'='*60}")
    print(f"  状态码: {code}")
    print(f"  描述:   {message}")
    if task_id:
        print(f"  任务ID: {task_id}")

    # 打印业务数据（过滤隐藏字段）
    filtered = _filter_dict({k: v for k, v in resp.items() if k != "head"})
    for key, val in filtered.items():
        if isinstance(val, (dict, list)):
            print(f"\n  {key}:")
            print(f"  {json.dumps(val, ensure_ascii=False, indent=2)}")
        else:
            print(f"  {key}: {val}")

    print(f"{'='*60}\n")
