#!/usr/bin/env python3
"""
NL2SQL 测试脚本
"""

import os
import sys
import tempfile
import unittest
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from scripts.config import Config, TIERS, FALLBACK_TIER
from scripts.parser import CSVParser, DataFrameExecutor, Schema, ColumnInfo, SQLExecutionError
from scripts.nl2sql import NL2SQL, GeneratedSQL
from scripts.display import TableRenderer, ChartGenerator, ResultFormatter
from scripts.api import NL2SQLService, QueryRequest, QueryResponse


class TestConfig(unittest.TestCase):
    """Config 模块测试"""
    
    def test_tiers_defined(self):
        """验证套餐定义完整"""
        expected_tiers = ["SQL-FREE", "SQL-BSC", "SQL-STD", "SQL-PRO", "SQL-ENT"]
        for tier in expected_tiers:
            self.assertIn(tier, TIERS)
    
    def test_fallback_tier_exists(self):
        """验证降级套餐存在"""
        self.assertIn(FALLBACK_TIER, TIERS)
    
    def test_validate_token_no_key(self):
        """无 API Key 时返回降级信息"""
        config = Config()
        info = config.validate_token("")
        
        self.assertFalse(info.valid)
        self.assertEqual(info.tier, FALLBACK_TIER)
        self.assertIn("FREE", info.tier)
    
    def test_validate_token_fallback_on_network_error(self):
        """网络错误时降级到 FREE"""
        config = Config()
        # 使用无效 URL 会触发网络错误
        info = config._fallback_info("test error")
        
        self.assertFalse(info.valid)
        self.assertEqual(info.tier, FALLBACK_TIER)
    
    def test_cache_clear(self):
        """缓存清除测试"""
        config = Config()
        config._cache["test"] = ("data", 0)
        config.clear_cache()
        self.assertEqual(len(config._cache), 0)


class TestCSVParser(unittest.TestCase):
    """CSV 解析器测试"""
    
    def setUp(self):
        """创建测试数据"""
        self.temp_dir = tempfile.mkdtemp()
        self.csv_file = os.path.join(self.temp_dir, "test.csv")
        
        # 创建测试 CSV
        with open(self.csv_file, "w") as f:
            f.write("name,age,city,salary\n")
            f.write("Alice,30,Beijing,15000\n")
            f.write("Bob,25,Shanghai,12000\n")
            f.write("Charlie,35,Beijing,18000\n")
    
    def tearDown(self):
        """清理测试文件"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_is_supported_csv(self):
        """支持 CSV 格式"""
        self.assertTrue(CSVParser.is_supported(self.csv_file))
    
    def test_is_not_supported(self):
        """不支持的格式"""
        self.assertFalse(CSVParser.is_supported("test.txt"))
    
    def test_load_csv(self):
        """加载 CSV 文件"""
        df = CSVParser.load_file(self.csv_file)
        
        self.assertEqual(len(df), 3)
        self.assertEqual(list(df.columns), ["name", "age", "city", "salary"])
    
    def test_infer_schema(self):
        """推断 Schema"""
        df = CSVParser.load_file(self.csv_file)
        schema = CSVParser.infer_schema(df, "employees")
        
        self.assertIn("employees", schema.tables)
        self.assertIn("employees", schema.columns)
        self.assertEqual(len(schema.columns["employees"]), 4)
    
    def test_schema_to_prompt(self):
        """Schema 转 Prompt"""
        df = CSVParser.load_file(self.csv_file)
        schema = CSVParser.infer_schema(df, "employees")
        prompt = schema.to_prompt()
        
        self.assertIn("employees", prompt)
        self.assertIn("name", prompt)
        self.assertIn("age", prompt)


class TestDataFrameExecutor(unittest.TestCase):
    """DataFrame 执行器测试"""
    
    def setUp(self):
        """创建测试数据"""
        import pandas as pd
        
        self.df = pd.DataFrame({
            "name": ["Alice", "Bob", "Charlie"],
            "age": [30, 25, 35],
            "city": ["Beijing", "Shanghai", "Beijing"],
            "salary": [15000, 12000, 18000]
        })
        
        schema = Schema(
            tables={"employees": self.df},
            columns={"employees": []},
            relationships=[]
        )
        self.executor = DataFrameExecutor(schema)
    
    def test_execute_simple_query(self):
        """执行简单查询"""
        try:
            result = self.executor.execute_sql("SELECT * FROM employees")
            self.assertEqual(len(result), 3)
        except SQLExecutionError:
            # pandas 模式可能不支持复杂 SQL
            pass
    
    def test_execute_empty_sql(self):
        """空 SQL 测试"""
        with self.assertRaises(SQLExecutionError):
            self.executor.execute_sql("")


class TestNL2SQL(unittest.TestCase):
    """NL2SQL 测试"""
    
    def test_generate_sql_no_api_key(self):
        """无 API Key 时使用规则方法"""
        import pandas as pd
        
        df = pd.DataFrame({
            "product": ["A", "B", "C"],
            "sales": [100, 200, 150]
        })
        schema = Schema(
            tables={"products": df},
            columns={"products": []},
            relationships=[]
        )
        
        nl2sql = NL2SQL()
        result = nl2sql.generate_sql("哪个产品销量最高", schema)
        
        self.assertIsInstance(result, GeneratedSQL)
        self.assertIn("SELECT", result.sql.upper())
        self.assertLess(result.confidence, 1.0)
    
    def test_explain_sql_no_api_key(self):
        """无 API Key 解释失败"""
        nl2sql = NL2SQL()
        result = nl2sql.explain_sql("SELECT * FROM test", "查询所有")
        
        self.assertIn("需要", result)


class TestTableRenderer(unittest.TestCase):
    """表格渲染器测试"""
    
    def setUp(self):
        import pandas as pd
        self.df = pd.DataFrame({
            "name": ["Alice", "Bob"],
            "age": [30, 25]
        })
        self.renderer = TableRenderer()
    
    def test_to_markdown(self):
        """转 Markdown"""
        md = self.renderer.to_markdown(self.df)
        
        self.assertIn("| name | age |", md)
        self.assertIn("Alice", md)
        self.assertIn("Bob", md)
    
    def test_to_csv(self):
        """转 CSV"""
        csv = self.renderer.to_csv(self.df)
        
        self.assertIn("name,age", csv)
        self.assertIn("Alice,30", csv)
    
    def test_to_html(self):
        """转 HTML"""
        html = self.renderer.to_html(self.df)
        
        self.assertIn("<table", html)
        self.assertIn("Alice", html)


class TestChartGenerator(unittest.TestCase):
    """图表生成器测试"""
    
    def setUp(self):
        import pandas as pd
        self.df = pd.DataFrame({
            "product": ["A", "B", "C"],
            "sales": [100, 200, 150]
        })
        self.gen = ChartGenerator()
    
    def test_supported_types(self):
        """支持的图表类型"""
        expected = ["bar", "line", "pie", "scatter", "area", "histogram"]
        for chart_type in expected:
            self.assertIn(chart_type, ChartGenerator.SUPPORTED_TYPES)
    
    def test_generate_bar_chart(self):
        """生成柱状图"""
        image_bytes = self.gen.generate(self.df, "bar")
        
        self.assertIsInstance(image_bytes, bytes)
        self.assertGreater(len(image_bytes), 0)
    
    def test_generate_line_chart(self):
        """生成折线图"""
        image_bytes = self.gen.generate(self.df, "line")
        
        self.assertIsInstance(image_bytes, bytes)
        self.assertGreater(len(image_bytes), 0)
    
    def test_unsupported_chart_type(self):
        """不支持的图表类型"""
        with self.assertRaises(ValueError):
            self.gen.generate(self.df, "invalid_type")
    
    def test_empty_dataframe(self):
        """空 DataFrame"""
        import pandas as pd
        empty_df = pd.DataFrame()
        
        with self.assertRaises(ValueError):
            self.gen.generate(empty_df, "bar")


class TestNL2SQLService(unittest.TestCase):
    """服务测试"""
    
    def setUp(self):
        """创建测试环境"""
        self.temp_dir = tempfile.mkdtemp()
        self.csv_file = os.path.join(self.temp_dir, "test.csv")
        
        with open(self.csv_file, "w") as f:
            f.write("name,age,salary\n")
            f.write("Alice,30,15000\n")
            f.write("Bob,25,12000\n")
    
    def tearDown(self):
        """清理"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_service_init(self):
        """服务初始化"""
        service = NL2SQLService()
        self.assertIsNotNone(service.config)
        self.assertIsNotNone(service.nl2sql)
    
    def test_query_request_creation(self):
        """创建查询请求"""
        request = QueryRequest(
            question="谁工资最高？",
            files=[self.csv_file]
        )
        
        self.assertEqual(request.question, "谁工资最高？")
        self.assertEqual(len(request.files), 1)
    
    def test_query_from_dict(self):
        """从字典创建请求"""
        service = NL2SQLService()
        
        data = {
            "question": "谁工资最高？",
            "files": [self.csv_file]
        }
        
        response = service.query_from_dict(data)
        
        self.assertIsInstance(response, QueryResponse)


class TestEndToEnd(unittest.TestCase):
    """端到端测试"""
    
    def setUp(self):
        """创建测试环境"""
        self.temp_dir = tempfile.mkdtemp()
        self.csv_file = os.path.join(self.temp_dir, "sales.csv")
        
        # 创建销售数据
        with open(self.csv_file, "w") as f:
            f.write("product,region,sales\n")
            f.write("A,North,100\n")
            f.write("B,South,200\n")
            f.write("C,North,150\n")
            f.write("A,South,120\n")
    
    def tearDown(self):
        """清理"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_full_workflow(self):
        """完整工作流"""
        # 1. 加载数据
        schema = CSVParser.build_schema_from_files([self.csv_file])
        self.assertIn("sales", schema.tables)
        
        # 2. 生成 SQL
        nl2sql = NL2SQL()
        result = nl2sql.generate_sql("每个产品的总销售额", schema)
        self.assertIsInstance(result.sql, str)
        
        # 3. 执行
        executor = DataFrameExecutor(schema)
        try:
            df = executor.execute_sql(result.sql)
            self.assertIsInstance(df, type(schema.tables["sales"]))
        except SQLExecutionError:
            pass  # 降级模式可能不支持
    
    def test_workflow_with_chart(self):
        """带图表的工作流"""
        schema = CSVParser.build_schema_from_files([self.csv_file])
        nl2sql = NL2SQL()
        result = nl2sql.generate_sql("每个区域销售", schema)
        
        executor = DataFrameExecutor(schema)
        try:
            df = executor.execute_sql(result.sql)
            
            # 生成图表
            gen = ChartGenerator()
            image = gen.generate(df, "bar")
            
            self.assertIsInstance(image, bytes)
        except SQLExecutionError:
            pass


if __name__ == "__main__":
    unittest.main(verbosity=2)
