"""
CSV/Excel 解析与 Schema 构建
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Optional, Dict, List, Any
from dataclasses import dataclass


@dataclass
class ColumnInfo:
    """列信息"""
    name: str
    dtype: str  # pandas dtype as string
    nullable: bool
    unique_count: Optional[int] = None
    sample_values: Optional[List[Any]] = None


@dataclass
class Schema:
    """数据库 Schema 描述"""
    tables: Dict[str, pd.DataFrame]
    columns: Dict[str, List[ColumnInfo]]
    relationships: List[Dict[str, str]]  # [{'table1': 'col1', 'table2': 'col2', 'type': 'many_to_one'}]
    
    def get_table_schema_sql(self, table_name: str) -> str:
        """生成表的 DDL 风格描述"""
        if table_name not in self.columns:
            return ""
        
        lines = [f"Table: {table_name}", "("]
        for col in self.columns[table_name]:
            nullable = "NULL" if col.nullable else "NOT NULL"
            samples = f", e.g. {col.sample_values[:3]}" if col.sample_values else ""
            lines.append(f"  {col.name} {col.dtype} {nullable}{samples}")
        lines.append(")")
        return "\n".join(lines)
    
    def to_prompt(self) -> str:
        """转换为 AI Prompt 格式"""
        parts = []
        for table_name in self.tables:
            parts.append(self.get_table_schema_sql(table_name))
        
        if self.relationships:
            parts.append("\nRelationships:")
            for rel in self.relationships:
                parts.append(f"  {rel.get('table1')}.{rel.get('col1')} -> {rel.get('table2')}.{rel.get('col2')}")
        
        return "\n".join(parts)


class CSVParser:
    """CSV/Excel 文件解析器"""
    
    SUPPORTED_EXTENSIONS = {".csv", ".xlsx", ".xls"}
    
    @classmethod
    def is_supported(cls, filepath: str) -> bool:
        """检查文件格式是否支持"""
        ext = Path(filepath).suffix.lower()
        return ext in cls.SUPPORTED_EXTENSIONS
    
    @classmethod
    def load_file(cls, filepath: str, sheet_name: Optional[str] = None) -> pd.DataFrame:
        """
        加载 CSV/Excel 文件
        """
        ext = Path(filepath).suffix.lower()
        
        if ext == ".csv":
            df = pd.read_csv(filepath)
        elif ext in {".xlsx", ".xls"}:
            df = pd.read_excel(filepath, sheet_name=sheet_name or 0)
        else:
            raise ValueError(f"Unsupported file format: {ext}")
        
        return df
    
    @classmethod
    def infer_schema(cls, df: pd.DataFrame, table_name: str = "data") -> Schema:
        """
        自动推断 DataFrame 的 Schema
        """
        columns: List[ColumnInfo] = []
        
        for col_name in df.columns:
            dtype = str(df[col_name].dtype)
            nullable = df[col_name].isna().any()
            unique_count = df[col_name].nunique()
            
            # 采样值（过滤 NA）
            samples = df[col_name].dropna().head(5).tolist()
            
            col_info = ColumnInfo(
                name=str(col_name),
                dtype=dtype,
                nullable=nullable,
                unique_count=unique_count,
                sample_values=samples
            )
            columns.append(col_info)
        
        return Schema(
            tables={table_name: df},
            columns={table_name: columns},
            relationships=[]
        )
    
    @classmethod
    def build_schema_from_files(cls, filepaths: List[str]) -> Schema:
        """
        从多个文件构建 Schema
        """
        tables: Dict[str, pd.DataFrame] = {}
        columns: Dict[str, List[ColumnInfo]] = {}
        all_relationships: List[Dict[str, str]] = []
        
        for filepath in filepaths:
            table_name = Path(filepath).stem  # 使用文件名作为表名
            
            # 如果同名表，加数字后缀
            if table_name in tables:
                counter = 1
                while f"{table_name}_{counter}" in tables:
                    counter += 1
                table_name = f"{table_name}_{counter}"
            
            df = cls.load_file(filepath)
            tables[table_name] = df
            columns[table_name] = []
            
            # 推断列信息
            for col_name in df.columns:
                dtype = str(df[col_name].dtype)
                nullable = df[col_name].isna().any()
                unique_count = df[col_name].nunique()
                samples = df[col_name].dropna().head(5).tolist()
                
                col_info = ColumnInfo(
                    name=str(col_name),
                    dtype=dtype,
                    nullable=nullable,
                    unique_count=unique_count,
                    sample_values=samples
                )
                columns[table_name].append(col_info)
            
            # 自动检测关系（同名列作为外键候选）
            for col_name in df.columns:
                if col_name.lower() in ["id", "user_id", "product_id", "order_id", "customer_id"]:
                    all_relationships.append({
                        "table1": table_name,
                        "col1": col_name,
                        "table2": table_name,
                        "col2": col_name,
                        "type": "primary_key"
                    })
        
        return Schema(
            tables=tables,
            columns=columns,
            relationships=all_relationships
        )


class DataFrameExecutor:
    """DataFrame SQL 执行器（安全沙箱）"""
    
    # 允许的列操作
    ALLOWED_OPS = {
        "select", "where", "and", "or", "not", "in", "like", "between",
        "order by", "group by", "having", "limit", "offset",
        "count", "sum", "avg", "min", "max", "distinct",
        "as", "join", "inner", "left", "right", "outer",
        "is null", "is not null", "!=", "<>", ">=", "<=", "="
    }
    
    def __init__(self, schema: Schema):
        self.schema = schema
    
    def execute_sql(self, sql: str, params: Optional[Dict] = None) -> pd.DataFrame:
        """
        在 DataFrame 上执行 SQL
        使用 pandasql 实现（完全离线，无数据库连接）
        """
        try:
            import pandasql as ps
            
            # 构建全局命名空间
            tables = self.schema.tables.copy()
            if params:
                tables.update(params)
            
            result = ps.sqldf(sql, tables)
            return result
            
        except ImportError:
            # 如果没有 pandasql，使用纯 pandas 实现
            return self._execute_pandas(sql)
        except Exception as e:
            raise SQLExecutionError(f"SQL execution failed: {str(e)}")
    
    def _execute_pandas(self, sql: str) -> pd.DataFrame:
        """纯 pandas 实现的简单 SQL 执行"""
        # 解析简单 SELECT 语句
        import re
        
        sql_upper = sql.upper().strip()
        
        # 简单 SELECT * FROM table WHERE ...
        select_match = re.match(r"SELECT\s+(.+?)\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+))?$", sql_upper, re.DOTALL)
        if select_match:
            cols = select_match.group(1).strip()
            table_name = select_match.group(2).lower()
            where_clause = select_match.group(3) if select_match.group(3) else None
            
            if table_name not in self.schema.tables:
                raise SQLExecutionError(f"Table '{table_name}' not found")
            
            df = self.schema.tables[table_name].copy()
            
            if cols == "*":
                result = df
            else:
                # 解析列名
                col_list = [c.strip().split()[-1] for c in cols.split(",")]
                result = df[col_list]
            
            if where_clause:
                # 简单 WHERE 处理
                result = self._apply_where(result, where_clause)
            
            return result
        
        raise SQLExecutionError("Complex SQL not supported in pandas mode. Please install pandasql.")
    
    def _apply_where(self, df: pd.DataFrame, where_clause: str) -> pd.DataFrame:
        """简单 WHERE 子句处理"""
        import re
        
        # 移除 ORDER BY/LIMIT 等
        where_clause = re.sub(r'\s+(ORDER\s+BY|LIMIT|OFFSET|GROUP\s+BY|HAVING).*$', '', where_clause, flags=re.IGNORECASE)
        
        # 处理 AND/OR
        if " AND " in where_clause.upper():
            parts = re.split(r'\s+AND\s+', where_clause, flags=re.IGNORECASE)
            result = df
            for part in parts:
                result = self._apply_condition(result, part.strip())
            return result
        elif " OR " in where_clause.upper():
            # OR 逻辑较复杂，返回原数据
            return df
        else:
            return self._apply_condition(df, where_clause.strip())
    
    def _apply_condition(self, df: pd.DataFrame, condition: str) -> pd.DataFrame:
        """应用单个条件"""
        import re
        
        # 解析 column op value
        match = re.match(r'(\w+)\s*(!=|<>|<=|>=|=|>|<)\s*(.+)', condition.strip())
        if not match:
            return df
        
        col, op, value = match.group(1), match.group(2), match.group(3).strip()
        col = col.lower()
        
        # 清理列名
        actual_col = None
        for c in df.columns:
            if c.lower() == col:
                actual_col = c
                break
        
        if not actual_col:
            return df
        
        # 解析值
        value = value.strip("'\"")
        try:
            if value.isdigit():
                value = int(value)
            elif value.replace(".", "", 1).isdigit():
                value = float(value)
        except:
            pass
        
        # 应用条件
        if op == "=":
            return df[df[actual_col] == value]
        elif op == "!=" or op == "<>":
            return df[df[actual_col] != value]
        elif op == ">":
            return df[df[actual_col] > value]
        elif op == "<":
            return df[df[actual_col] < value]
        elif op == ">=":
            return df[df[actual_col] >= value]
        elif op == "<=":
            return df[df[actual_col] <= value]
        
        return df


class SQLExecutionError(Exception):
    """SQL 执行错误"""
    pass
