"""
NL2SQL 主程序 - 命令行接口
"""

import sys
import argparse
import json
from pathlib import Path
from typing import Optional, List

from .config import Config
from .parser import CSVParser, DataFrameExecutor, SQLExecutionError
from .nl2sql import NL2SQL
from .display import ResultFormatter, ChartGenerator, TableRenderer


class NL2SQLCLI:
    """NL2SQL 命令行界面"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.config = Config()
        self.token_info = self.config.validate_token(api_key or "")
        self.nl2sql = NL2SQL(api_key=api_key)
        self.formatter = ResultFormatter()
        self.chart_gen = ChartGenerator()
    
    def load_data(self, filepaths: List[str]) -> CSVParser:
        """加载数据文件"""
        if not filepaths:
            raise ValueError("No files provided")
        
        for fp in filepaths:
            if not Path(fp).exists():
                raise FileNotFoundError(f"File not found: {fp}")
            if not CSVParser.is_supported(fp):
                raise ValueError(f"Unsupported file format: {fp}")
        
        return CSVParser.build_schema_from_files(filepaths)
    
    def query(
        self,
        question: str,
        filepaths: List[str],
        output_format: str = "markdown",
        chart_type: Optional[str] = None,
        explain: bool = False
    ):
        """执行查询"""
        # 1. 加载数据并构建 Schema
        schema = self.load_data(filepaths)
        
        # 2. 生成 SQL
        print("🤖 正在生成 SQL...", file=sys.stderr)
        result = self.nl2sql.generate_sql(question, schema)
        sql = result.sql
        print(f"✅ SQL 生成完成 (confidence: {result.confidence:.0%})", file=sys.stderr)
        
        # 3. 执行 SQL
        print("⚡ 正在执行查询...", file=sys.stderr)
        executor = DataFrameExecutor(schema)
        try:
            df = executor.execute_sql(sql)
            print(f"✅ 查询完成 ({len(df)} 行)", file=sys.stderr)
        except SQLExecutionError as e:
            print(f"❌ SQL 执行失败: {e}", file=sys.stderr)
            return None
        
        # 4. 可选：生成图表
        chart_base64 = None
        if chart_type and chart_type in ChartGenerator.SUPPORTED_TYPES:
            try:
                chart_base64 = self.chart_gen.to_base64(df, chart_type)
            except Exception as e:
                print(f"⚠️ 图表生成失败: {e}", file=sys.stderr)
        
        # 5. 可选：解释 SQL
        explanation = None
        if explain:
            print("📝 正在解释 SQL...", file=sys.stderr)
            explanation = self.nl2sql.explain_sql(sql, question)
        
        # 6. 输出结果
        if output_format == "markdown":
            output = self.formatter.format_markdown(df, sql, explanation, chart_base64)
            print(output)
        elif output_format == "json":
            output = self.formatter.format_json(df, sql, explanation)
            print(json.dumps(output, ensure_ascii=False, indent=2))
        elif output_format == "csv":
            print(TableRenderer.to_csv(df))
        else:
            print(TableRenderer.to_markdown(df))
        
        return df
    
    def export(
        self,
        df,
        output_path: str,
        format: str = "csv"
    ):
        """导出结果"""
        if format == "csv":
            df.to_csv(output_path, index=False)
        elif format == "excel":
            df.to_excel(output_path, index=False)
        else:
            raise ValueError(f"Unsupported export format: {format}")
        
        print(f"✅ 已导出到 {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="NL2SQL - Natural Language to SQL",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument("question", help="Natural language question")
    parser.add_argument("-f", "--file", nargs="+", required=True, help="CSV/Excel files")
    parser.add_argument("-k", "--api-key", help="API key for AI SQL generation")
    parser.add_argument("--format", choices=["markdown", "json", "csv"], default="markdown", help="Output format")
    parser.add_argument("--chart", choices=ChartGenerator.SUPPORTED_TYPES, help="Generate chart")
    parser.add_argument("--explain", action="store_true", help="Explain SQL")
    parser.add_argument("-o", "--output", help="Output file path")
    parser.add_argument("--export-format", choices=["csv", "excel"], default="csv", help="Export format")
    
    args = parser.parse_args()
    
    cli = NL2SQLCLI(api_key=args.api_key)
    
    try:
        df = cli.query(
            question=args.question,
            filepaths=args.file,
            output_format=args.format,
            chart_type=args.chart,
            explain=args.explain
        )
        
        if df is not None and args.output:
            cli.export(df, args.output, args.export_format)
            
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
