"""
NL2SQL API 服务模块
"""

import os
from typing import Optional, List, Dict, Any
from pathlib import Path
from dataclasses import dataclass

from .config import Config, TokenInfo
from .parser import CSVParser, DataFrameExecutor, Schema, SQLExecutionError
from .nl2sql import NL2SQL, GeneratedSQL
from .display import ResultFormatter, ChartGenerator, TableRenderer


@dataclass
class QueryRequest:
    """查询请求"""
    question: str
    files: List[str]  # 文件路径列表
    chart_type: Optional[str] = None
    explain: bool = False
    output_format: str = "markdown"


@dataclass
class QueryResponse:
    """查询响应"""
    success: bool
    sql: Optional[str] = None
    explanation: Optional[str] = None
    row_count: int = 0
    columns: Optional[List[str]] = None
    data: Optional[List[Dict]] = None
    chart_base64: Optional[str] = None
    error: Optional[str] = None
    token_info: Optional[TokenInfo] = None


class NL2SQLService:
    """NL2SQL 服务"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.config = Config()
        self.token_info = self.config.validate_token(api_key or "")
        self.nl2sql = NL2SQL(api_key=api_key)
        self.formatter = ResultFormatter()
        self.chart_gen = ChartGenerator()
    
    def query(self, request: QueryRequest) -> QueryResponse:
        """执行查询"""
        # 验证 token
        if not self.token_info.valid:
            return QueryResponse(
                success=False,
                error=self.token_info.error or "Invalid token"
            )
        
        try:
            # 1. 加载数据
            schema = CSVParser.build_schema_from_files(request.files)
            
            # 2. 生成 SQL
            result = self.nl2sql.generate_sql(request.question, schema)
            
            # 3. 执行 SQL
            executor = DataFrameExecutor(schema)
            df = executor.execute_sql(result.sql)
            
            # 4. 生成图表
            chart_base64 = None
            if request.chart_type and request.chart_type in ChartGenerator.SUPPORTED_TYPES:
                try:
                    chart_base64 = self.chart_gen.to_base64(
                        df, request.chart_type
                    )
                except Exception:
                    pass
            
            # 5. 解释 SQL
            explanation = None
            if request.explain:
                explanation = self.nl2sql.explain_sql(result.sql, request.question)
            
            return QueryResponse(
                success=True,
                sql=result.sql,
                explanation=explanation,
                row_count=len(df),
                columns=df.columns.tolist(),
                data=TableRenderer.to_dict_list(df),
                chart_base64=chart_base64,
                token_info=self.token_info
            )
            
        except Exception as e:
            return QueryResponse(
                success=False,
                error=str(e)
            )
    
    def query_from_dict(self, data: Dict[str, Any]) -> QueryResponse:
        """从字典创建请求并执行"""
        request = QueryRequest(
            question=data.get("question", ""),
            files=data.get("files", []),
            chart_type=data.get("chart_type"),
            explain=data.get("explain", False),
            output_format=data.get("output_format", "markdown")
        )
        return self.query(request)


def create_app(api_key: Optional[str] = None):
    """创建 Flask/FastAPI 应用（预留）"""
    service = NL2SQLService(api_key=api_key)
    
    # 这里可以添加 Flask/FastAPI 路由
    # 暂时返回 service 实例供直接调用
    
    return service
