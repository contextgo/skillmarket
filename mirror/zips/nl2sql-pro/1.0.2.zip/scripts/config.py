"""
配置管理模块
"""

import os
import time
import requests
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional, Dict

# API 配置
VALIDATE_API_URL = "https://api.yk-global.com/v1/verify"
API_CACHE_TTL = 300  # 5分钟缓存

# 套餐定义
TIERS = {
    "SQL-FREE": {"queries": 10, "databases": 1, "join": False, "chart": ["bar", "line", "pie"], "export": ["csv"]},
    "SQL-BSC": {"queries": 500, "databases": 5, "join": True, "chart": ["bar", "line", "pie"], "export": ["csv"]},
    "SQL-STD": {"queries": 500, "databases": 5, "join": True, "chart": ["bar", "line", "pie"], "export": ["csv"]},
    "SQL-PRO": {"queries": 3000, "databases": 20, "join": True, "chart": ["bar", "line", "pie", "scatter", "area"], "export": ["csv", "excel", "pdf"]},
    "SQL-ENT": {"queries": float("inf"), "databases": float("inf"), "join": True, "chart": ["bar", "line", "pie", "scatter", "area", "histogram"], "export": ["csv", "excel", "pdf"]},
}

# 降级套餐
FALLBACK_TIER = "SQL-FREE"

# API Key 前缀映射
KEY_PREFIXES = ["SQL-FREE", "SQL-BSC", "SQL-STD", "SQL-PRO", "SQL-ENT"]


@dataclass
class TokenInfo:
    """Token 验证结果"""
    valid: bool
    tier: str
    queries_remaining: int
    databases_allowed: int
    join_enabled: bool
    chart_types: list
    export_formats: list
    error: Optional[str] = None


class Config:
    """配置管理器"""
    
    def __init__(self):
        self._cache: Dict[str, tuple] = {}  # key: (info, timestamp)
    
    def validate_token(self, api_key: str) -> TokenInfo:
        """
        验证 API Token
        降级策略：网络错误 → FREE tier
        缓存：本地 5 分钟
        """
        if not api_key:
            return TokenInfo(
                valid=False,
                tier=FALLBACK_TIER,
                queries_remaining=TIERS[FALLBACK_TIER]["queries"],
                databases_allowed=TIERS[FALLBACK_TIER]["databases"],
                join_enabled=TIERS[FALLBACK_TIER]["join"],
                chart_types=TIERS[FALLBACK_TIER]["chart"],
                export_formats=TIERS[FALLBACK_TIER]["export"],
                error="No API key provided, using FREE tier"
            )
        
        # 检查缓存
        cache_key = api_key[:8] if len(api_key) > 8 else api_key
        if cache_key in self._cache:
            info, timestamp = self._cache[cache_key]
            if time.time() - timestamp < API_CACHE_TTL:
                return info
        
        # 检测前缀
        tier = FALLBACK_TIER
        for prefix in KEY_PREFIXES:
            if api_key.startswith(prefix):
                tier = prefix
                break
        
        # 调用验证 API
        try:
            headers = {"Authorization": f"Bearer {api_key}"}
            response = requests.post(
                VALIDATE_API_URL,
                headers=headers,
                json={},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                # 注意：响应字段是 valid 不是 success
                if data.get("valid", False):
                    tier = api_key.split("-")[0] if "-" in api_key else tier
                    if tier not in TIERS:
                        tier = FALLBACK_TIER
                    
                    info = TokenInfo(
                        valid=True,
                        tier=tier,
                        queries_remaining=TIERS[tier]["queries"],
                        databases_allowed=TIERS[tier]["databases"],
                        join_enabled=TIERS[tier]["join"],
                        chart_types=TIERS[tier]["chart"],
                        export_formats=TIERS[tier]["export"]
                    )
                else:
                    info = self._fallback_info("Token validation returned invalid")
            else:
                info = self._fallback_info(f"HTTP {response.status_code}")
        except requests.exceptions.RequestException as e:
            info = self._fallback_info(f"Network error: {str(e)}")
        
        # 缓存结果
        self._cache[cache_key] = (info, time.time())
        return info
    
    def _fallback_info(self, error: str) -> TokenInfo:
        """降级到 FREE tier"""
        return TokenInfo(
            valid=False,
            tier=FALLBACK_TIER,
            queries_remaining=TIERS[FALLBACK_TIER]["queries"],
            databases_allowed=TIERS[FALLBACK_TIER]["databases"],
            join_enabled=TIERS[FALLBACK_TIER]["join"],
            chart_types=TIERS[FALLBACK_TIER]["chart"],
            export_formats=TIERS[FALLBACK_TIER]["export"],
            error=error
        )
    
    def clear_cache(self, api_key: Optional[str] = None):
        """清除缓存"""
        if api_key:
            cache_key = api_key[:8] if len(api_key) > 8 else api_key
            self._cache.pop(cache_key, None)
        else:
            self._cache.clear()
