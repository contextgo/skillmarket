"""
结果展示模块 - 表格渲染与图表生成
"""

import io
import base64
from pathlib import Path
from typing import Optional, List, Dict, Any, Union

import pandas as pd
import matplotlib
matplotlib.use('Agg')  # 无头模式
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# 设置中文字体
try:
    plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans', 'Arial Unicode MS', 'sans-serif']
    plt.rcParams['axes.unicode_minus'] = False
except:
    pass


class TableRenderer:
    """表格渲染器"""
    
    @staticmethod
    def to_markdown(df: pd.DataFrame, max_rows: int = 100) -> str:
        """转换为 Markdown 表格"""
        if df.empty:
            return "（空结果）"
        
        # 限制行数
        display_df = df.head(max_rows)
        
        # 构建 Markdown 表头
        headers = display_df.columns.tolist()
        header_line = "| " + " | ".join(str(h) for h in headers) + " |"
        separator = "| " + " | ".join(["---"] * len(headers)) + " |"
        
        # 构建数据行
        rows = []
        for _, row in display_df.iterrows():
            row_str = "| " + " | ".join(str(v) for v in row.values) + " |"
            rows.append(row_str)
        
        result = [header_line, separator] + rows
        
        if len(df) > max_rows:
            note = "（显示前 {} 行，共 {} 行）".format(max_rows, len(df))
            result.append("_" + note + "_")
        
        return "\n".join(result)
    
    @staticmethod
    def to_csv(df: pd.DataFrame) -> str:
        """转换为 CSV 字符串"""
        return df.to_csv(index=False)
    
    @staticmethod
    def to_html(df: pd.DataFrame, max_rows: int = 100) -> str:
        """转换为 HTML 表格"""
        display_df = df.head(max_rows)
        
        html = ['<table style="border-collapse: collapse; width: 100%;">']
        
        # 表头
        html.append('<thead><tr>')
        for col in display_df.columns:
            html.append('<th style="border: 1px solid #ddd; padding: 8px; background-color: #f2f2f2;">' + str(col) + '</th>')
        html.append('</tr></thead>')
        
        # 数据行
        html.append('<tbody>')
        for _, row in display_df.iterrows():
            html.append('<tr>')
            for val in row.values:
                html.append('<td style="border: 1px solid #ddd; padding: 8px;">' + str(val) + '</td>')
            html.append('</tr>')
        html.append('</tbody></table>')
        
        if len(df) > max_rows:
            html.append('<p><em>（显示前 {} 行，共 {} 行）</em></p>'.format(max_rows, len(df)))
        
        return '\n'.join(html)
    
    @staticmethod
    def to_excel_bytes(df: pd.DataFrame, filename: str = "result.xlsx") -> bytes:
        """导出为 Excel 字节流"""
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Result')
        return output.getvalue()
    
    @staticmethod
    def to_dict_list(df: pd.DataFrame) -> List[Dict]:
        """转换为字典列表"""
        return df.to_dict(orient='records')


class ChartGenerator:
    """图表生成器"""
    
    SUPPORTED_TYPES = ["bar", "line", "pie", "scatter", "area", "histogram"]
    
    def __init__(self):
        self.figure_size = (10, 6)
        self.dpi = 100
        self.title_fontsize = 14
    
    def generate(
        self,
        df: pd.DataFrame,
        chart_type: str,
        x_column: Optional[str] = None,
        y_column: Optional[str] = None,
        title: Optional[str] = None,
        color: Optional[str] = None
    ) -> bytes:
        """
        生成图表
        返回图片字节流
        """
        if chart_type not in self.SUPPORTED_TYPES:
            raise ValueError("Unsupported chart type: " + chart_type)
        
        if df.empty:
            raise ValueError("Cannot generate chart for empty DataFrame")
        
        # 自动选择列
        columns = df.columns.tolist()
        if x_column is None:
            x_column = columns[0]
        if y_column is None and len(columns) > 1:
            y_column = columns[1]
        
        fig, ax = plt.subplots(figsize=self.figure_size, dpi=self.dpi)
        
        if chart_type == "bar":
            self._plot_bar(ax, df, x_column, y_column, color)
        elif chart_type == "line":
            self._plot_line(ax, df, x_column, y_column, color)
        elif chart_type == "pie":
            self._plot_pie(ax, df, x_column, y_column, color)
        elif chart_type == "scatter":
            self._plot_scatter(ax, df, x_column, y_column, color)
        elif chart_type == "area":
            self._plot_area(ax, df, x_column, y_column, color)
        elif chart_type == "histogram":
            self._plot_histogram(ax, df, x_column, color)
        
        if title:
            ax.set_title(title, fontsize=self.title_fontsize)
        
        plt.tight_layout()
        
        # 转为字节流
        output = io.BytesIO()
        plt.savefig(output, format='png', dpi=self.dpi, bbox_inches='tight')
        plt.close(fig)
        
        return output.getvalue()
    
    def generate_and_save(
        self,
        df: pd.DataFrame,
        chart_type: str,
        output_path: str,
        **kwargs
    ) -> str:
        """生成图表并保存到文件"""
        image_bytes = self.generate(df, chart_type, **kwargs)
        
        with open(output_path, 'wb') as f:
            f.write(image_bytes)
        
        return output_path
    
    def to_base64(self, df: pd.DataFrame, chart_type: str, **kwargs) -> str:
        """生成 base64 编码的图片"""
        image_bytes = self.generate(df, chart_type, **kwargs)
        return base64.b64encode(image_bytes).decode('utf-8')
    
    def _plot_bar(self, ax, df, x_col, y_col, color):
        """绘制柱状图"""
        if y_col:
            ax.bar(df[x_col].astype(str), df[y_col], color=color or 'steelblue')
            ax.set_xlabel(x_col)
            ax.set_ylabel(y_col)
        else:
            value_counts = df[x_col].value_counts()
            ax.bar(value_counts.index.astype(str), value_counts.values, color=color or 'steelblue')
            ax.set_xlabel(x_col)
            ax.set_ylabel('Count')
        ax.tick_params(axis='x', rotation=45)
    
    def _plot_line(self, ax, df, x_col, y_col, color):
        """绘制折线图"""
        if y_col:
            ax.plot(df[x_col].astype(str), df[y_col], marker='o', color=color or 'steelblue')
            ax.set_xlabel(x_col)
            ax.set_ylabel(y_col)
        else:
            ax.plot(range(len(df)), df[x_col], marker='o', color=color or 'steelblue')
            ax.set_xlabel('Index')
            ax.set_ylabel(x_col)
        ax.tick_params(axis='x', rotation=45)
    
    def _plot_pie(self, ax, df, x_col, y_col, color):
        """绘制饼图"""
        if y_col:
            ax.pie(df[y_col], labels=df[x_col].astype(str), autopct='%1.1f%%', colors=[color] if color else None)
        else:
            value_counts = df[x_col].value_counts()
            ax.pie(value_counts.values, labels=value_counts.index.astype(str), autopct='%1.1f%%')
        ax.axis('equal')
    
    def _plot_scatter(self, ax, df, x_col, y_col, color):
        """绘制散点图"""
        ax.scatter(df[x_col], df[y_col], c=color or 'steelblue', alpha=0.6)
        ax.set_xlabel(x_col)
        ax.set_ylabel(y_col)
    
    def _plot_area(self, ax, df, x_col, y_col, color):
        """绘制面积图"""
        if y_col:
            ax.fill_between(range(len(df)), df[y_col], alpha=0.3, color=color or 'steelblue')
            ax.plot(range(len(df)), df[y_col], color=color or 'steelblue')
        else:
            ax.fill_between(range(len(df)), df[x_col], alpha=0.3, color=color or 'steelblue')
            ax.plot(range(len(df)), df[x_col], color=color or 'steelblue')
        ax.set_xlabel('Index')
    
    def _plot_histogram(self, ax, df, x_col, color):
        """绘制直方图"""
        ax.hist(df[x_col].dropna(), bins=20, color=color or 'steelblue', edgecolor='black', alpha=0.7)
        ax.set_xlabel(x_col)
        ax.set_ylabel('Frequency')


class ResultFormatter:
    """结果格式化器"""
    
    def __init__(self):
        self.table_renderer = TableRenderer()
        self.chart_generator = ChartGenerator()
    
    def format_markdown(
        self,
        df: pd.DataFrame,
        sql: Optional[str] = None,
        explanation: Optional[str] = None,
        chart_image_base64: Optional[str] = None
    ) -> str:
        """格式化为 Markdown"""
        parts = []
        
        # SQL 语句
        if sql:
            parts.append("### 生成的 SQL")
            parts.append("```sql")
            parts.append(sql)
            parts.append("```")
            parts.append("")
        
        # 解释
        if explanation:
            parts.append("**解释**: " + explanation)
            parts.append("")
        
        # 图表
        if chart_image_base64:
            parts.append("### 图表")
            img_tag = '<img src="data:image/png;base64,' + chart_image_base64 + '" width="600"/>'
            parts.append(img_tag)
            parts.append("")
        
        # 表格
        parts.append("### 查询结果")
        parts.append(self.table_renderer.to_markdown(df))
        
        return "\n".join(parts)
    
    def format_json(
        self,
        df: pd.DataFrame,
        sql: Optional[str] = None,
        explanation: Optional[str] = None
    ) -> Dict[str, Any]:
        """格式化为 JSON"""
        return {
            "sql": sql,
            "explanation": explanation,
            "row_count": len(df),
            "columns": df.columns.tolist(),
            "data": self.table_renderer.to_dict_list(df)
        }
