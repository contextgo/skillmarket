"""
SQL 生成模块 - 使用 AI 将自然语言转换为 SQL
"""

import json
from typing import Optional, List, Dict, Any
from dataclasses import dataclass

from .parser import Schema, CSVParser


@dataclass
class GeneratedSQL:
    """生成的 SQL 结果"""
    sql: str
    explanation: str
    confidence: float  # 0.0 - 1.0


class PromptBuilder:
    """SQL 生成 Prompt 构建器"""
    
    @staticmethod
    def build_schema_prompt(schema: Schema, question: str, dialect: str = "SQLite") -> str:
        """
        构建 Schema 描述 Prompt
        """
        schema_desc = schema.to_prompt()
        
        prompt = f"""你是一个 SQL 专家。请根据以下数据库 Schema 和用户问题，生成对应的 SQL 查询。

## 数据库 Schema
{schema_desc}

## 用户问题
{question}

## 要求
1. 只返回 SQL 语句，不要其他解释
2. 使用 {dialect} 语法
3. 确保 SQL 可以正确执行
4. 不要使用 LIMIT 除非用户要求

请生成 SQL：
"""
        return prompt
    
    @staticmethod
    def build_explain_prompt(sql: str, question: str) -> str:
        """
        构建 SQL 解释 Prompt
        """
        prompt = f"""请解释以下 SQL 查询的含义：

SQL: {sql}

用户问题: {question}

请用简洁的中文解释这个 SQL 查询在做什么。
"""
        return prompt


class NL2SQL:
    """自然语言转 SQL 转换器"""
    
    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4"):
        self.api_key = api_key
        self.model = model
    
    def generate_sql(
        self,
        question: str,
        schema: Schema,
        dialect: str = "SQLite"
    ) -> GeneratedSQL:
        """
        生成 SQL
        """
        if not self.api_key:
            # 无 API Key，使用启发式规则
            return self._rule_based_sql(question, schema)
        
        try:
            import openai
            
            prompt = PromptBuilder.build_schema_prompt(schema, question, dialect)
            
            client = openai.OpenAI(api_key=self.api_key)
            response = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "你是一个 SQL 专家，只返回 SQL 语句，不要其他解释。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.1,
                max_tokens=500
            )
            
            sql = response.choices[0].message.content.strip()
            # 移除可能的 markdown 代码块
            if sql.startswith("```"):
                sql = sql.split("\n", 1)[1]
            sql = sql.strip("`").strip()
            
            return GeneratedSQL(
                sql=sql,
                explanation="",
                confidence=0.9
            )
            
        except Exception as e:
            # API 调用失败，降级到规则方法
            return self._rule_based_sql(question, schema)
    
    def explain_sql(self, sql: str, question: str) -> str:
        """
        解释 SQL 含义
        """
        if not self.api_key:
            return "需要 API Key 才能解释 SQL"
        
        try:
            import openai
            
            prompt = PromptBuilder.build_explain_prompt(sql, question)
            
            client = openai.OpenAI(api_key=self.api_key)
            response = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "你是一个 SQL 专家，擅长解释 SQL 查询的含义。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=300
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            return f"解释生成失败: {str(e)}"
    
    def _rule_based_sql(self, question: str, schema: Schema) -> GeneratedSQL:
        """
        基于规则的简单 SQL 生成（无 API Key 时使用）
        """
        question_lower = question.lower()
        table_name = list(schema.tables.keys())[0] if schema.tables else "data"
        columns = [col.name for col in schema.columns.get(table_name, [])]
        
        sql_parts = ["SELECT"]
        
        # 聚合检测
        if any(kw in question_lower for kw in ["总和", "sum", "总计", "total", "加起来"]):
            if any(kw in question_lower for kw in ["平均", "average", "avg", "均值"]):
                sql_parts[0] = "SELECT AVG(*) as avg_value"
            elif any(kw in question_lower for kw in ["最大", "max", "最高"]):
                sql_parts[0] = "SELECT MAX(*) as max_value"
            elif any(kw in question_lower for kw in ["最小", "min", "最低"]):
                sql_parts[0] = "SELECT MIN(*) as min_value"
            else:
                sql_parts[0] = "SELECT SUM(*) as sum_value"
        elif any(kw in question_lower for kw in ["数量", "count", "多少", "几个"]):
            sql_parts[0] = "SELECT COUNT(*) as count"
        elif "前" in question_lower or "top" in question_lower:
            # 提取数字
            import re
            num_match = re.search(r'(\d+)', question)
            limit = num_match.group(1) if num_match else "10"
            sql_parts.append(f" TOP {limit}")
        else:
            sql_parts.append(" *")
        
        sql_parts.append(f" FROM {table_name}")
        
        # WHERE 条件
        where_parts = []
        for col in columns:
            col_lower = col.lower()
            if col_lower in question_lower:
                # 检查比较类型
                if any(kw in question_lower for kw in ["大于", ">", "超过", "以上"]):
                    # 尝试提取数值
                    import re
                    num_match = re.search(r'(\d+\.?\d*)', question)
                    if num_match:
                        where_parts.append(f"{col} > {num_match.group(1)}")
                elif any(kw in question_lower for kw in ["小于", "<", "低于", "以下"]):
                    import re
                    num_match = re.search(r'(\d+\.?\d*)', question)
                    if num_match:
                        where_parts.append(f"{col} < {num_match.group(1)}")
                elif any(kw in question_lower for kw in ["等于", "是", "为", "=", "等于"]):
                    # 尝试提取值
                    where_parts.append(f"{col} = 'value'")
        
        if where_parts:
            sql_parts.append(" WHERE " + " AND ".join(where_parts[:3]))
        
        # GROUP BY
        if any(kw in question_lower for kw in ["每个", "每", "group by", "分组", "按"]):
            # 尝试找分组列
            for col in columns:
                if col.lower() in question_lower:
                    sql_parts.append(f" GROUP BY {col}")
                    break
        
        sql = " ".join(sql_parts)
        
        return GeneratedSQL(
            sql=sql,
            explanation="（无 API Key，使用启发式规则生成，可能不准确）",
            confidence=0.5
        )
