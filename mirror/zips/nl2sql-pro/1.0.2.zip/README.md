# NL2SQL - Natural Language to SQL Converter

用**自然语言提问**，AI 自动识别数据库结构，**生成并执行 SQL**，返回可读结果。

---

## 🎯 产品定位

| 传统方式 | NL2SQL |
|---------|--------|
| 需要懂 SQL 语法 | 说话就能查询 |
| 学习成本高 | 零门槛 |
| 耗时易错 | 秒级响应 |

---

## ✨ 核心能力

- 📤 **多格式支持**：CSV、Excel 文件上传
- 🌍 **双语支持**：中文/英文自然语言查询
- 🤖 **AI 驱动**：GPT-4 智能 SQL 生成
- 📊 **可视化**：柱状图、折线图、饼图一键生成
- 🔒 **安全设计**：完全离线，不连接真实数据库
- 💾 **多种导出**：CSV、Excel、Pdf

---

## 📦 功能套餐

| 套餐 | 月费 | 查询次数 | 数据库连接 | 多表 JOIN | 图表 | 导出 |
|------|------|---------|-----------|---------|------|------|
| **FREE** | 免费 | 10次/月 | 1个 | ❌ | 柱/线/饼 | CSV |
| **BSC/标准版** | ¥29 | 500次/月 | 5个 | ✅ | 基础 | CSV |
| **Pro/专业版** | ¥99 | 3000次/月 | 20个 | ✅ | 高级 | Excel/PDF |
| **Max/企业版** | ¥299 | 无限次 | 无限 | ✅ | 全部 | 全部 |

---

## 🚀 快速开始

### 安装依赖

```bash
pip install -r requirements.txt
```

### 配置 API Key（可选）

```bash
export OPENAI_API_KEY="your-api-key"
```

### 命令行使用

```bash
# 基本查询
python -m scripts.main "哪个产品的销量最高？" -f data/sales.csv

# 生成图表
python -m scripts.main "每月销售额趋势" -f data/sales.csv --chart line

# 导出结果
python -m scripts.main "查看前10名客户" -f data/customers.csv --format csv -o result.csv

# SQL 解释
python -m scripts.main "查找所有订单金额大于1000的客户" -f data/orders.csv --explain
```

### Python API

```python
from scripts import NL2SQLService, QueryRequest

# 初始化服务
service = NL2SQLService(api_key="your-api-key")

# 创建查询请求
request = QueryRequest(
    question="哪个产品的销量最高？",
    files=["data/sales.csv"],
    chart_type="bar",
    explain=True
)

# 执行查询
response = service.query(request)

if response.success:
    print(f"SQL: {response.sql}")
    print(f"结果: {response.data}")
    print(f"图表: {response.chart_base64}")
else:
    print(f"错误: {response.error}")
```

---

## 📁 项目结构

```
nl2sql/
├── scripts/
│   ├── __init__.py      # 包初始化
│   ├── config.py        # 配置与 Token 验证
│   ├── parser.py        # CSV/Excel 解析与 Schema 构建
│   ├── nl2sql.py        # 自然语言转 SQL
│   ├── display.py       # 结果展示与图表生成
│   ├── main.py          # 命令行入口
│   └── api.py           # API 服务接口
├── tests/
│   └── test_nl2sql.py   # 测试脚本
├── requirements.txt     # 依赖列表
├── README.md            # 本文档
└── SKILL.md             # Skill 配置
```

---

## 🔧 技术细节

### CSV/Excel 解析
- 使用 `pandas` 读取文件
- 自动推断列名、数据类型
- 检测表关系（同名列作为外键候选）

### SQL 生成
- 支持 GPT-4、GPT-3.5 等模型
- 无 API Key 时使用启发式规则降级
- 可解释生成的 SQL 含义

### 结果展示
- Markdown 表格（支持大表格截断）
- matplotlib 图表（柱/线/饼/散点/面积/直方图）
- 支持导出 CSV、Excel

### Token 验证
- API: `POST https://geo-api.yk-global.com/validate`
- 响应字段：`valid`（注意不是 success）
- 前缀格式：`SQL-FREE` / `SQL-BSC` / `SQL-STD` / `SQL-PRO` / `SQL-ENT`
- 降级策略：网络错误 → FREE tier（不阻断使用）
- 本地缓存：5 分钟

---

## 🧪 测试

```bash
# 运行所有测试
python -m pytest tests/ -v

# 运行特定测试
python -m pytest tests/test_nl2sql.py -v -k "test_csv"
```

---

## ❓ 常见问题

**Q: 需要 API Key 吗？**
A: 可选。有 API Key 使用 GPT 生成更准确的 SQL；无 API Key 使用启发式规则。

**Q: 数据安全吗？**
A: 完全安全。所有数据在本地处理，不上传到任何服务器。

**Q: 支持哪些图表类型？**
A: 柱状图、折线图、饼图、散点图、面积图、直方图（取决于套餐）。

**Q: 如何处理大数据文件？**
A: 结果默认显示前 100 行，可导出完整数据。

---

## 📄 License

MIT License

---

> 如需购买收费版，请访问 [YK-Global.com](https://yk-global.com)
