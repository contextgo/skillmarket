---
name: tcm-ai-cswmzy-mcp-connector
description: 当用户需要用中文配置、接入或排查中医 AI 引擎 MCP 服务时使用本 skill，包括中医知识图谱、健康档案、体检报告、资源推荐、中医自然语言处理、诊断服务，以及 Claude Desktop、OpenClaw、Cursor、Dify、LangChain 或其他 MCP/SSE 客户端接入。触发词包括：中医 MCP、中医知识图谱、健康档案、体检报告、医生推荐、资源推荐、症状标准化、中医 NLP、诊断服务、SSE 接入、MCP 鉴权、工具不显示、连接失败。
---

# 中医 MCP 集成

当用户要把中医 AI 引擎 MCP 服务接入 AI agent、MCP 客户端、IDE 或工作流引擎时，使用本 skill。

## 中文问答要求

- 用户交互必须使用简体中文：提问、解释、排查、验证步骤、注意事项都用中文。
- 不要输出中英双语说明，也不要在中文说明后附英文翻译。
- 必须保留机器可读内容的原文：JSON key、环境变量名、端点 URL、工具名、资源 URI、包名、命令、端口、HTTP header。
- 如果用户没有提供必要信息，用中文询问；如果只是在生成示例配置，优先使用占位符。
- 不要编造 host、API key、用户 ID、健康数据或其他敏感信息。

## 核心事实

所有中医 AI 引擎 MCP 服务都通过 SSE 暴露。

- 传输方式：`sse`
- 鉴权方式：HTTP Bearer token
- 请求头：`Authorization: Bearer sk-tcm-expert-ai-agent-v1-dev`
- 主机占位符：`111.22.12.157`
- 必要环境变量：`TCM_MCP_HOST`、`TCM_MCP_API_KEY`
- 不要在配置示例、日志、截图或提交到仓库的文件里暴露真实生产 API key。

如果用户没有提供 host 或 API key，先用占位符生成配置；只有在用户明确要做真实连通性测试时，才提示用户通过安全方式提供实际值。

## 服务目录

| 服务 | 端点 | 主要能力 |
| --- | --- | --- |
| 中医知识图谱 | `http://111.22.12.157:9991/sse` | 检索中医知识、查询实体推理路径、读取中药卡片 |
| 健康档案与体检报告 | `http://111.22.12.157:9992/sse` | 查询健康指标、总结年度体检报告、读取最新报告 |
| 资源与推荐 | `http://111.22.12.157:9993/sse` | 搜索医生、推荐健康服务包、检索文章和视频 |
| 中医自然语言处理与诊断 | `http://111.22.12.157:9994/sse` | 症状标准化、抽取中医实体 |

## 工具与资源

### 中医知识图谱服务

端点：`http://111.22.12.157:9991/sse`

- 工具：`search_tcm_knowledge`，查询症状、中药、方剂及相关概念之间的图谱关系。
- 工具：`get_entity_paths`，获取多个中医实体之间的推理路径。
- 资源：`tcm://herb/{name}`，读取结构化中药百科卡片。

### 健康档案与报告服务

端点：`http://111.22.12.157:9992/sse`

- 工具：`query_health_metrics`，查询血压、血糖等健康指标的近期趋势。
- 工具：`summarize_annual_report`，提取并总结体检报告中的异常项。
- 资源：`report://user/{uid}/latest`，返回用户最新完整体检报告的 Markdown 内容。

### 资源与推荐服务

端点：`http://111.22.12.157:9993/sse`

- 工具：`search_doctors`，按科室或症状搜索医生。
- 工具：`recommend_health_packages`，推荐相关中医调理服务包。
- 工具：`search_articles_videos`，搜索中医科普文章和视频。

### 中医自然语言处理与诊断服务

端点：`http://111.22.12.157:9994/sse`

- 工具：`normalize_symptoms`，将“睡不好、心慌”等口语化主诉标准化为“失眠”“心悸”等中医症状。
- 工具：`extract_tcm_entities`，从长文本中抽取中医实体，底层由 Aho-Corasick 自动机支持。

## 配置流程

1. 先确认用户要接入哪些中医 MCP 服务。
2. 再确认客户端类型，例如 Claude Desktop、OpenClaw、Cursor、Dify、LangChain 或其他支持 SSE 的 MCP 客户端。
3. 获取或推断 `TCM_MCP_HOST`；无法确认时使用 `111.22.12.157`。
4. 使用 `TCM_MCP_API_KEY`、密钥管理器或环境变量，不要把生产 token 写死到配置里。
5. 为目标客户端生成最小可用配置，不要默认一次性塞入所有服务。
6. 告诉用户如何验证：客户端初始化后应能发现对应 tools/resources。

## 客户端配置模式

### Claude Desktop 或 OpenClaw 通过 SSE 桥接器接入

当桌面客户端只支持本地 `stdio` MCP 进程时，使用此模式，通过本地 Node.js 桥接器连接远程 SSE 端点。

需要 Node.js 和 `npx`。

```json
{
  "mcpServers": {
    "tcm_knowledge": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/client-sse",
        "--url",
        "http://111.22.12.157:9991/sse",
        "--header",
        "Authorization: Bearer sk-tcm-expert-ai-agent-v1-dev"
      ]
    },
    "health_report": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/client-sse",
        "--url",
        "http://111.22.12.157:9992/sse",
        "--header",
        "Authorization: Bearer sk-tcm-expert-ai-agent-v1-dev"
      ]
    }
  }
}
```

只有需要资源推荐或中医自然语言处理能力时，再加入下面的服务：

```json
{
  "mcpServers": {
    "resource_recommendation": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/client-sse",
        "--url",
        "http://111.22.12.157:9993/sse",
        "--header",
        "Authorization: Bearer sk-tcm-expert-ai-agent-v1-dev"
      ]
    },
    "tcm_nlp": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/client-sse",
        "--url",
        "http://111.22.12.157:9994/sse",
        "--header",
        "Authorization: Bearer sk-tcm-expert-ai-agent-v1-dev"
      ]
    }
  }
}
```

### Cursor 或原生支持 SSE MCP 的 IDE

当客户端允许直接填写 MCP server URL 和 headers 时，使用此模式。

- 类型：`sse`
- 地址：`http://111.22.12.157:9991/sse`
- 请求头：

```json
{
  "Authorization": "Bearer sk-tcm-expert-ai-agent-v1-dev"
}
```

需要其他服务时，分别按端口 `9992`、`9993`、`9994` 增加对应 MCP server。

### 通用 JSON 配置

当客户端接受 SSE MCP server 的 JSON 配置时，使用此模式。

```json
{
  "mcpServers": {
    "tcm_knowledge": {
      "transport": "sse",
      "url": "http://111.22.12.157:9991/sse",
      "headers": {
        "Authorization": "Bearer sk-tcm-expert-ai-agent-v1-dev"
      }
    },
    "tcm_nlp": {
      "transport": "sse",
      "url": "http://111.22.12.157:9994/sse",
      "headers": {
        "Authorization": "Bearer sk-tcm-expert-ai-agent-v1-dev"
      }
    }
  }
}
```

如果某个客户端要求不同字段名，按客户端格式调整字段，但必须保留相同的端点、SSE transport 和 Authorization header。

## Schema 发现

不要让用户去找 Swagger 文档。MCP 客户端会在初始化时从服务端提供的 JSON Schema 中发现可用 tools 和 resources。

连接成功后，确认客户端里出现预期的工具或资源：

- `search_tcm_knowledge`
- `get_entity_paths`
- `query_health_metrics`
- `summarize_annual_report`
- `search_doctors`
- `recommend_health_packages`
- `search_articles_videos`
- `normalize_symptoms`
- `extract_tcm_entities`
- `tcm://herb/{name}`
- `report://user/{uid}/latest`

## 故障排查

- 如果没有 tools 出现，检查 SSE URL、端口、网络访问和 Authorization header。
- 如果鉴权失败，确认服务端环境变量里的 token，例如 `MCP_API_KEY`。
- 如果桌面客户端不能直接连接 SSE，使用 Node.js 的 `@modelcontextprotocol/client-sse` 桥接器。
- 如果只需要部分能力，只配置对应 MCP 服务，减少工具列表噪音。
- 如果客户端配置会进入代码仓库，密钥应放在环境变量或被忽略的本地配置文件里。
- 如果服务在 HTTPS、反向代理或网关后面，确认 `/sse` 路径和 Authorization header 被正确转发。
- 如果连接超时，先确认客户端所在机器能访问 `111.22.12.157` 的对应端口。

## 回答格式

帮助用户时，始终用中文给出：

1. 对应客户端的精确配置片段。
2. 已启用哪些服务的简短说明。
3. 用于确认 tools/resources 是否被发现的验证步骤。
4. 替换 host 和 API key 占位符的提醒，同时提醒不要暴露真实密钥。

如果信息不足，先用中文提出最少数量的必要问题。不要为了展示完整性而输出大段英文说明。
