# SkillHub 上传说明

## 📦 包信息

- **名称**: multi-platform-uploader
- **版本**: 2.0.0
- **分类**: 自动化工具 / 视频上传
- **标签**: video, upload, automation, douyin, xiaohongshu, bilibili

## 🚀 上传步骤

### 方法 1: 使用 skillhub CLI

```bash
# 1. 进入 skill 目录
cd C:\Users\caizheyu\Desktop\multi-platform-uploader-skill

# 2. 登录 skillhub
skillhub login

# 3. 发布 skill
skillhub publish
```

### 方法 2: 网页上传

1. 访问 https://skillhub.com
2. 登录账号
3. 点击 "发布 Skill"
4. 上传压缩包（见下方打包命令）
5. 填写信息并提交

## 📦 打包命令

```bash
# PowerShell
cd C:\Users\caizheyu\Desktop
Compress-Archive -Path multi-platform-uploader-skill -DestinationPath multi-platform-uploader-v2.0.0.zip -Force

# 或使用 7-Zip
"C:\Program Files\7-Zip\7z.exe" a -tzip multi-platform-uploader-v2.0.0.zip multi-platform-uploader-skill\*
```

## 📋 提交信息

**标题**: 多平台视频上传自动化技能 v2.0

**描述**: 
```
自动将视频上传到抖音、小红书、B 站并保存草稿。

核心特性:
- 智能页面分析（先分析后行动）
- 内容检查机制（保存前检查标题和描述）
- 自动重试机制（失败自动重试 2 次）
- 动态等待策略（每 2 秒检测进度）
- 自动截图保存

性能：3 个平台总计 2-3 分钟完成（比传统方法快 20 倍）

已测试平台：
✅ 抖音
✅ 小红书  
✅ B 站
```

**分类**: 自动化工具

**标签**: video, upload, automation, douyin, xiaohongshu, bilibili, chrome, crawler

**许可证**: MIT

## ✅ 检查清单

上传前确认：
- [ ] 所有文件已复制到 skill 目录
- [ ] README.md 包含完整使用说明
- [ ] SKILL.json 包含正确元数据
- [ ] 示例文件已包含
- [ ] 文档已复制
- [ ] 已本地测试运行正常

## 📁 包内容

```
multi-platform-uploader-skill/
├── index.js              # 主脚本
├── config.js             # 配置文件
├── README.md             # 使用说明
├── SKILL.json            # Skill 元数据
├── docs/
│   ├── GUIDE.md         # 完整指南
│   └── QUICK-REF.md     # 快速参考
└── examples/
    └── content-example.txt  # 内容格式示例
```

总文件大小：约 50KB

---

**准备完成时间**: 2026-04-24 14:49
**打包者**: 薯条 🍟
