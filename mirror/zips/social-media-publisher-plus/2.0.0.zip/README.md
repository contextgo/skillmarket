# multi-platform-uploader

**多平台视频上传自动化技能**

版本：2.0.0  
作者：薯条 (Morment)  
最后更新：2026-04-24

---

## 📋 功能说明

自动将视频上传到以下平台并保存草稿：
- ✅ 抖音 (Douyin)
- ✅ 小红书 (Xiaohongshu)
- ✅ B 站 (Bilibili)

**核心特性**：
- 🚀 智能页面分析（先分析后行动）
- ✅ 内容检查机制（保存前检查标题和描述）
- 🔄 自动重试机制（失败自动重试 2 次）
- ⏱️ 动态等待策略（每 2 秒检测进度）
- 📸 自动截图保存

**性能**：3 个平台总计 2-3 分钟完成（比传统方法快 20 倍）

---

## 🚀 快速开始

### 前提条件
1. Node.js 18+
2. Chrome 浏览器已安装
3. 已登录抖音、小红书、B 站账号

### 使用方法

```bash
# 1. 运行脚本
node index.js
```

### 自定义视频和内容

编辑 `config.js` 文件：
```javascript
module.exports = {
  videoPath: 'C:/Users/yourname/Desktop/video.mp4',
  contentPath: 'C:/Users/yourname/Desktop/content.txt',
  platforms: ['douyin', 'xiaohongshu', 'bilibili']
};
```

---

## 📁 文件结构

```
multi-platform-uploader/
├── index.js                 # 主脚本
├── config.js                # 配置文件
├── README.md                # 使用说明
├── SKILL.md                 # Skill 描述
├── docs/
│   ├── GUIDE.md            # 完整指南
│   └── QUICK-REF.md        # 快速参考
└── examples/
    └── content-example.txt  # 内容格式示例
```

---

## 📝 内容文件格式

创建文本文件（如 `content.txt`）：
```
标题：Kingsway 批量导出询盘

简介：
有 Kingsway 客户跟我们说，他们的视频开始稳定带来询盘之后，遇到一个新问题：询盘太多，只能一条一条复制，效率太低。
所以，我们直接做了一个功能：一键导出所有询盘。
你可以把某段时间内的询盘一次性导出来，交给团队或 CRM，让这些来自视频的线索更加高效的进入你的业务系统。

#B2B 获客
#视频获客
#视频营销
```

---

## ⚙️ 配置选项

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `videoPath` | string | 必填 | 视频文件路径 |
| `contentPath` | string | 必填 | 内容文件路径 |
| `platforms` | array | 全部 | 要上传的平台列表 |
| `chromePort` | number | 9222 | Chrome 远程调试端口 |
| `maxRetries` | number | 2 | 最大重试次数 |
| `timeout` | number | 120 | 上传超时时间（秒） |

---

## 🔍 平台特性

### 抖音
- 视频 input 索引：1（第 2 个）
- 保存按钮：暂存离开
- 特殊：有确认弹窗

### 小红书
- 视频 input 索引：0（第 1 个）
- 保存按钮：暂存离开
- 特殊：标题无 placeholder

### B 站
- 视频 input 索引：0（第 1 个）
- 保存按钮：存草稿
- 特殊：Quill 编辑器

---

## ⚠️ 常见问题

### 1. 脚本报错 "未找到文件上传元素"
**解决**：确保 Chrome 已启动并开启远程调试
```bash
# Windows 启动 Chrome 远程调试
chrome.exe --remote-debugging-port=9222
```

### 2. 内容未填写
**解决**：检查内容文件格式是否正确（标题 + 简介）

### 3. 保存失败
**解决**：检查是否已登录对应平台账号

---

## 📊 性能对比

| 版本 | 耗时 | 说明 |
|------|------|------|
| v1.0 | 45 分钟 | 初始版本 |
| v2.0 | 2-3 分钟 | 优化版本（20 倍提升） |

---

## 📄 许可证

MIT License

---

## 🙏 致谢

- OpenClaw 社区
- Kingsway Video 团队

---

**最后更新**: 2026-04-24  
**测试状态**: ✅ 已验证（抖音、小红书、B 站）
