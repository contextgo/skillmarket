// 多平台视频上传 - 最终优化版（带内容检查）
import fs from 'fs';
import path from 'path';

const WebSocket = globalThis.WebSocket;
let ws = null, cmdId = 0;
const pending = new Map(), sessions = new Map();

// ==================== CDP 基础连接 ====================

function discoverChromePort() {
  const p = process.env.LOCALAPPDATA + '/Google/Chrome/User Data/DevToolsActivePort';
  try {
    const lines = fs.readFileSync(p, 'utf-8').trim().split('\n');
    return { port: parseInt(lines[0]), wsPath: lines[1] || null };
  } catch { return { port: 9222, wsPath: null }; }
}

async function connect() {
  if (ws?.readyState === WebSocket.OPEN) return;
  const { port, wsPath } = discoverChromePort();
  const wsUrl = wsPath ? `ws://127.0.0.1:${port}${wsPath}` : `ws://127.0.0.1:${port}/devtools/browser`;
  console.log(`🔌 连接：${wsUrl}`);
  return new Promise((resolve, reject) => {
    ws = new WebSocket(wsUrl);
    ws.addEventListener('open', () => { console.log('✅ 连接成功'); resolve(); });
    ws.addEventListener('error', reject);
    ws.addEventListener('message', (event) => {
      const msg = JSON.parse(typeof event.data === 'string' ? event.data : event.data.toString());
      if (msg.method === 'Target.attachedToTarget') sessions.set(msg.params.targetInfo.targetId, msg.params.sessionId);
      if (msg.id && pending.has(msg.id)) { const { resolve: res, timer } = pending.get(msg.id); clearTimeout(timer); pending.delete(msg.id); res(msg); }
    });
  });
}

function sendCDP(method, params = {}, sessionId = null) {
  return new Promise((resolve, reject) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return reject(new Error('未连接'));
    const id = ++cmdId;
    const msg = { id, method, params };
    if (sessionId) msg.sessionId = sessionId;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error('超时')); }, 30000);
    pending.set(id, { resolve, timer });
    ws.send(JSON.stringify(msg));
  });
}

async function ensureSession(targetId) {
  if (sessions.has(targetId)) return sessions.get(targetId);
  const resp = await sendCDP('Target.attachToTarget', { targetId, flatten: true });
  if (resp.result?.sessionId) { sessions.set(targetId, resp.result.sessionId); return resp.result.sessionId; }
  throw new Error('attach 失败');
}

async function evalJS(sessionId, expr) {
  const resp = await sendCDP('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }, sessionId);
  if (resp.result?.exceptionDetails) throw new Error(resp.result.exceptionDetails.text);
  return resp.result?.result?.value;
}

async function screenshot(sessionId, savePath) {
  const result = await sendCDP('Page.captureScreenshot', { format: 'png' }, sessionId);
  if (result?.result?.data) { fs.writeFileSync(savePath, result.result.data, 'base64'); return savePath; }
}

// ==================== 智能页面分析 ====================

async function analyzePage(sessionId, platform) {
  console.log(`  🔍 分析 ${platform} 页面结构...`);
  
  const a = await evalJS(sessionId, `(() => {
    const inputs = [...document.querySelectorAll('input[type="file"]')].map((i, idx) => ({ 
      idx, accept: i.accept || '', 
      isVideo: (i.accept||'').toLowerCase().includes('video'),
      isImage: (i.accept||'').toLowerCase().includes('image')
    }));
    
    // 标题输入
    const titleInputs = [...document.querySelectorAll('input[type="text"], input[placeholder]')];
    const titleInput = titleInputs.find(i => 
      (i.placeholder||'').toLowerCase().includes('标题') || 
      (i.placeholder||'').toLowerCase().includes('title') ||
      (i.placeholder||'').toLowerCase().includes('作品标题')
    );
    
    // 描述编辑器
    const descEditors = document.querySelectorAll('div[contenteditable="true"], textarea, [role="textbox"]');
    
    // 保存按钮
    const saveBtns = [...document.querySelectorAll('button')].filter(b => 
      /暂存 | 草稿 | 保存 | 离开/.test(b.innerText)
    ).slice(0, 3).map(b => b.innerText);
    
    return {
      fileInputs: inputs,
      videoIdx: inputs.findIndex(i => i.isVideo),
      hasTitleInput: !!titleInput,
      titlePlaceholder: titleInput?.placeholder || '',
      descCount: descEditors.length,
      saveBtns,
      url: window.location.href
    };
  })()`);
  
  console.log(`  📊 ${platform}:`);
  console.log(`    文件输入：${a.fileInputs.length} 个 (${a.fileInputs.map(i => i.accept || 'any').join(', ')})`);
  console.log(`    视频 input: ${a.videoIdx >= 0 ? '索引 ' + a.videoIdx : '使用索引 0'}`);
  console.log(`    标题输入：${a.hasTitleInput ? '✓ (' + a.titlePlaceholder.substring(0, 20) + '...)' : '⚠️ 未找到'}`);
  console.log(`    描述编辑：${a.descCount} 个`);
  console.log(`    保存按钮：${a.saveBtns.join(', ') || '无'}`);
  
  return a;
}

// ==================== 上传核心函数 ====================

async function uploadVideo(sessionId, videoPath, idx = 0) {
  const q = await sendCDP('Runtime.evaluate', { 
    expression: `document.querySelectorAll('input[type="file"]')[${idx}]`, 
    returnByValue: false 
  }, sessionId);
  
  if (!q.result?.result?.objectId) throw new Error('未找到上传元素');
  
  await sendCDP('DOM.setFileInputFiles', { 
    objectId: q.result.result.objectId, 
    files: [videoPath] 
  }, sessionId);
  
  await evalJS(sessionId, `(() => { 
    const i = document.querySelectorAll('input[type="file"]')[${idx}]; 
    if(i) { 
      i.dispatchEvent(new Event('change',{bubbles:true})); 
      i.dispatchEvent(new Event('input',{bubbles:true})); 
    } 
  })()`);
}

async function waitForUpload(sessionId, platform, maxSeconds = 120) {
  console.log(`  ⏳ 等待上传完成...`);
  
  for (let i = 0; i < maxSeconds / 2; i++) {
    const s = await evalJS(sessionId, `(() => {
      const p = document.querySelector('[class*="progress"]')?.innerText || '';
      const isUploading = /上传中|%|MB/.test(p);
      const isDone = /100%/.test(p) || (!!document.querySelector('.video-name, [class*="video-name"], video') && !isUploading);
      return { uploading: isUploading, done: isDone, progress: p.substring(0, 100) };
    })()`);
    
    if (i % 5 === 0 || s.done) {
      console.log(`    ${platform}: ${s.progress || (s.done ? '✓ 视频已就绪' : '等待中...')}`);
    }
    
    if (s.done && !s.uploading) { 
      console.log(`  ✅ ${platform} 上传完成`); 
      return true; 
    }
    await new Promise(r => setTimeout(r, 2000));
  }
  
  console.log(`  ⚠️ ${platform} 等待超时，继续执行`);
  return false;
}

// ==================== 内容填写与检查 ====================

async function fillContent(sessionId, title, desc, platform) {
  console.log(`  ✏️ 填写 ${platform} 内容...`);
  
  // 填写标题
  const titleResult = await evalJS(sessionId, `(() => {
    const inputs = document.querySelectorAll('input[type="text"], input[placeholder]');
    for (const i of inputs) {
      const ph = (i.placeholder||'').toLowerCase();
      if (ph.includes('标题') || ph.includes('title') || ph.includes('作品标题')) {
        i.value = \`${title.replace(/`/g, '\\`')}\`;
        i.dispatchEvent(new Event('input',{bubbles:true}));
        i.dispatchEvent(new Event('change',{bubbles:true}));
        return { ok: true, value: i.value };
      }
    }
    // 备用：第一个 text input
    const first = document.querySelector('input[type="text"]');
    if (first) {
      first.value = \`${title.replace(/`/g, '\\`')}\`;
      first.dispatchEvent(new Event('input',{bubbles:true}));
      return { ok: true, value: first.value, fallback: true };
    }
    return { ok: false };
  })()`);
  
  console.log(`    标题：${titleResult.ok ? '✓ 已填写' : '⚠️ 未找到输入框'}`);
  
  // 填写描述
  const descResult = await evalJS(sessionId, `(() => {
    const editors = document.querySelectorAll('div[contenteditable="true"], textarea, [role="textbox"]');
    if (editors.length === 0) return { ok: false };
    const ed = editors[0];
    ed.focus();
    document.execCommand('insertText', false, \`${desc.substring(0, 500).replace(/`/g, '\\`')}\`);
    return { ok: true, text: ed.innerText?.substring(0, 30) };
  })()`);
  
  console.log(`    描述：${descResult.ok ? '✓ 已填写 (' + descResult.text + '...)' : '⚠️ 未找到编辑器'}`);
  
  return { titleOk: titleResult.ok, descOk: descResult.ok };
}

async function checkContent(sessionId, platform, expectedTitle) {
  console.log(`  🔍 检查 ${platform} 内容是否填写...`);
  
  const check = await evalJS(sessionId, `(() => {
    // 检查标题
    const titleInputs = document.querySelectorAll('input[type="text"], input[placeholder]');
    let titleValue = '';
    let titleFilled = false;
    
    for (const i of titleInputs) {
      const ph = (i.placeholder||'').toLowerCase();
      if (ph.includes('标题') || ph.includes('title') || ph.includes('作品标题')) {
        titleValue = i.value || '';
        titleFilled = titleValue.length > 0;
        break;
      }
    }
    
    // 检查描述
    const editors = document.querySelectorAll('div[contenteditable="true"], textarea, [role="textbox"]');
    let descValue = '';
    let descFilled = false;
    
    if (editors.length > 0) {
      descValue = editors[0].innerText || editors[0].value || '';
      descFilled = descValue.length > 0;
    }
    
    return {
      title: titleValue,
      titleFilled,
      titleLength: titleValue.length,
      desc: descValue.substring(0, 50),
      descFilled,
      descLength: descValue.length
    };
  })()`);
  
  console.log(`    标题：${check.titleFilled ? '✓ 已填写' : '❌ 未填写'} (${check.titleLength}字)`);
  console.log(`    描述：${check.descFilled ? '✓ 已填写' : '❌ 未填写'} (${check.descLength}字)`);
  
  // 如果没填写，返回 false
  if (!check.titleFilled || !check.descFilled) {
    console.log(`  ⚠️ ${platform} 内容未填写完整，需要重新填写`);
    return false;
  }
  
  console.log(`  ✅ ${platform} 内容已填写完整`);
  return true;
}

async function fillContentWithRetry(sessionId, title, desc, platform, maxRetries = 2) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    if (attempt > 1) {
      console.log(`  🔄 ${platform} 第 ${attempt} 次尝试填写内容...`);
      await new Promise(r => setTimeout(r, 1000));
    }
    
    await fillContent(sessionId, title, desc, platform);
    const ok = await checkContent(sessionId, platform, title);
    
    if (ok) return true;
  }
  
  console.log(`  ❌ ${platform} 内容填写失败（已尝试 ${maxRetries} 次）`);
  return false;
}

// ==================== 保存草稿 ====================

async function saveDraft(sessionId, platform) {
  console.log(`  💾 保存 ${platform} 草稿...`);
  
  const r = await evalJS(sessionId, `(() => {
    for (const b of document.querySelectorAll('button')) {
      const t = (b.innerText||'').toLowerCase();
      if (t.includes('暂存') || t.includes('草稿') || t.includes('保存') || t.includes('离开')) {
        b.scrollIntoView({ behavior: 'smooth' });
        setTimeout(() => b.click(), 300);
        return { ok: true, text: b.innerText };
      }
    }
    return { ok: false };
  })()`);
  
  if (r.ok) {
    await new Promise(r => setTimeout(r, 3000));
    
    // 处理确认弹窗
    await evalJS(sessionId, `(() => {
      for (const b of document.querySelectorAll('[role="dialog"] button, [class*="modal"] button')) {
        const t = (b.innerText||'').toLowerCase();
        if (t.includes('确认') || t.includes('确定') || t.includes('保存') || t.includes('暂存')) {
          b.click();
          return;
        }
      }
    })()`);
    
    console.log(`  ✅ ${platform} 草稿已保存 (${r.text})`);
    return true;
  }
  
  console.log(`  ⚠️ ${platform} 未找到保存按钮`);
  return false;
}

// ==================== 平台上传主流程 ====================

async function uploadPlatform(platform, url, videoPath, title, desc) {
  const start = Date.now();
  console.log(`\n${'='.repeat(60)}`);
  console.log(`🚀 ${platform} 上传开始`);
  console.log(`${'='.repeat(60)}`);
  
  try {
    // 创建 tab
    const resp = await sendCDP('Target.createTarget', { url, background: false });
    const sid = await ensureSession(resp.result.targetId);
    console.log(`  ✓ 创建新 tab`);
    
    // 等待加载
    await new Promise(r => setTimeout(r, 5000));
    
    // 分析页面
    const analysis = await analyzePage(sid, platform);
    const vidx = analysis.videoIdx >= 0 ? analysis.videoIdx : 0;
    
    // 上传视频
    console.log(`  📹 上传视频...`);
    await uploadVideo(sid, videoPath, vidx);
    console.log(`  ✓ 视频文件已设置`);
    
    // 等待上传完成
    await waitForUpload(sid, platform);
    
    // 填写内容
    await fillContent(sid, title, desc, platform);
    
    // 【关键】检查内容是否填写完整
    const contentOk = await checkContent(sid, platform, title);
    
    if (!contentOk) {
      console.log(`  🔄 ${platform} 内容未填写，重试...`);
      const retryOk = await fillContentWithRetry(sid, title, desc, platform);
      if (!retryOk) {
        console.log(`  ❌ ${platform} 内容填写失败，跳过保存`);
        const dur = Math.round((Date.now()-start)/1000);
        return { platform, success: false, error: '内容填写失败', duration: dur };
      }
    }
    
    // 截图
    await screenshot(sid, `C:\\Users\\caizheyu\\.openclaw\\workspace\\${platform.toLowerCase()}-result.png`);
    
    // 保存草稿
    await saveDraft(sid, platform);
    
    const dur = Math.round((Date.now()-start)/1000);
    console.log(`\n✅ ${platform} 完成！${dur}秒`);
    return { platform, success: true, duration: dur };
    
  } catch (e) {
    const dur = Math.round((Date.now()-start)/1000);
    console.error(`\n❌ ${platform} 失败：${e.message}`);
    return { platform, success: false, error: e.message, duration: dur };
  }
}

// ==================== 主函数 ====================

async function main() {
  const start = Date.now();
  
  // 动态获取文件
  const desktop = 'C:/Users/caizheyu/Desktop';
  const files = fs.readdirSync(desktop);
  const videoFile = files.find(f => f.includes('2026-04-22') && f.endsWith('.mp4'));
  const contentFile = files.find(f => f.includes('内容 (6)') && f.endsWith('.txt'));
  
  if (!videoFile) { console.error('❌ 未找到视频文件'); process.exit(1); }
  if (!contentFile) { console.error('❌ 未找到内容文件'); process.exit(1); }
  
  const videoPath = desktop + '/' + videoFile;
  const contentPath = desktop + '/' + contentFile;
  
  console.log(`\n${'█'.repeat(60)}`);
  console.log(`🎬 多平台视频上传 - 最终优化版（带内容检查）`);
  console.log(`${'█'.repeat(60)}`);
  console.log(`📹 视频：${videoFile}`);
  console.log(`📝 内容：${contentFile}`);
  
  // 读取内容
  const content = fs.readFileSync(contentPath, 'utf-8');
  const titleMatch = content.match(/标题：(.+)/);
  const descMatch = content.match(/简介：([\s\S]*?)(?=#|$)/);
  const title = titleMatch ? titleMatch[1].trim() : 'Kingsway 功能介绍';
  const desc = descMatch ? descMatch[1].trim() : '';
  
  console.log(`\n📋 标题：${title}`);
  console.log(`📝 描述：${desc.substring(0, 50)}...`);
  
  await connect();
  
  console.log(`\n${'─'.repeat(60)}`);
  console.log(`📋 顺序：抖音 → 小红书 → B 站`);
  console.log(`${'─'.repeat(60)}`);
  
  // 顺序上传
  const results = [];
  results.push(await uploadPlatform('抖音', 'https://creator.douyin.com/creator-micro/content/publish', videoPath, title, desc));
  await new Promise(r => setTimeout(r, 1000));
  results.push(await uploadPlatform('小红书', 'https://creator.xiaohongshu.com/publish/publish', videoPath, title, desc));
  await new Promise(r => setTimeout(r, 1000));
  results.push(await uploadPlatform('B 站', 'https://member.bilibili.com/platform/upload/video/frame', videoPath, title, desc));
  
  // 汇总
  const total = Math.round((Date.now()-start)/1000);
  console.log(`\n${'█'.repeat(60)}`);
  console.log(`📊 结果汇总`);
  console.log(`${'█'.repeat(60)}`);
  results.forEach(r => console.log(`${r.success?'✅':'❌'} ${r.platform}: ${r.success?'成功':r.error} (${r.duration}秒)`));
  console.log(`\n⏱️ 总耗时：${total}秒 (${Math.floor(total/60)}分${total%60}秒)`);
  
  ws.close();
  process.exit(0);
}

main().catch(err => { console.error('❌', err.message); console.error(err.stack); ws?.close(); process.exit(1); });
