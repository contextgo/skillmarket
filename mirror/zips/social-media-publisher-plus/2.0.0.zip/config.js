// 配置文件
module.exports = {
  // 视频文件路径
  videoPath: 'C:/Users/caizheyu/Desktop/2026-04-22 询盘导出 (1).mp4',
  
  // 内容文件路径（标题 + 简介）
  contentPath: 'C:/Users/caizheyu/Desktop/内容 (6).txt',
  
  // 要上传的平台
  platforms: ['douyin', 'xiaohongshu', 'bilibili'],
  
  // Chrome 远程调试端口
  chromePort: 9222,
  
  // 最大重试次数
  maxRetries: 2,
  
  // 上传超时时间（秒）
  timeout: 120,
  
  // 截图保存目录
  screenshotDir: 'C:/Users/caizheyu/.openclaw/workspace'
};
