# Multi Platform Uploader Skill

**多平台视频上传自动化技能**

---

## 📋 Skill 信息

- **名称**: multi-platform-uploader
- **版本**: 2.0.0
- **作者**: 薯条 (Morment)
- **许可证**: MIT
- **最后更新**: 2026-04-24

---

## 🎯 功能描述

自动将视频上传到以下平台并保存草稿：
- ✅ 抖音 (Douyin)
- ✅ 小红书 (Xiaohongshu)
- ✅ B 站 (Bilibili)

**核心特性**：
- 🚀 智能页面分析（先分析后行动）
- ✅ 内容检查机制（保存前检查标题和描述）
- 🔄 自动重试机制（失败自动重试 2 次）
- ⏱️ 动态等待策略（每 2 秒检测进度）
- 📸 自动截图保存

**性能**：3 个平台总计 2-3 分钟完成（比传统方法快 20 倍）

---

## 🚀 使用方法

### 前提条件
1. Node.js 18+
2. Chrome 浏览器已安装
3. 已登录抖音、小红书、B 站账号

### 运行步骤

```bash
# 1. 进入 skill 目录
cd multi-platform-uploader-skill

# 2. 编辑配置文件（可选）
# 修改 config.js 中的视频路径和内容路径

# 3. 运行脚本
node index.js
```

### 配置文件

编辑 `config.js`：
```javascript
module.exports = {
  // 视频文件路径
  videoPath: 'C:/Users/yourname/Desktop/video.mp4',
  
  // 内容文件路径（标题 + 简介）
  contentPath: 'C:/Users/yourname/Desktop/content.txt',
  
  // 要上传的平台
  platforms: ['douyin', 'xiaohongshu', 'bilibili'],
  
  // Chrome 远程调试端口
  chromePort: 9222,
  
  // 最大重试次数
  maxRetries: 2,
  
  // 上传超时时间（秒）
  timeout: 120
};
```

---

## 📝 内容文件格式

创建文本文件，格式如下：

```
标题：Kingsway 批量导出询盘

简介：
有 Kingsway 客户跟我们说，他们的视频开始稳定带来询盘之后，遇到一个新问题：询盘太多，只能一条一条复制，效率太低。
所以，我们直接做了一个功能：一键导出所有询盘。
你可以把某段时间内的询盘一次性导出来，交给团队或 CRM，让这些来自视频的线索更加高效的进入你的业务系统。

#B2B 获客
#视频获客
#视频营销
```

---

## 🔍 平台特性

### 抖音
- 视频 input 索引：1（第 2 个）
- 标题选择器：`input[placeholder*="作品标题"]`
- 描述选择器：`div[contenteditable="true"]`
- 保存按钮：暂存离开
- 特殊：有确认弹窗

### 小红书
- 视频 input 索引：0（第 1 个）
- 标题选择器：`input[type="text"]`
- 描述选择器：`div[contenteditable="true"]`
- 保存按钮：暂存离开
- 特殊：标题无 placeholder

### B 站
- 视频 input 索引：0（第 1 个）
- 标题选择器：`input[placeholder*="标题"]`
- 描述选择器：`.ql-editor`（Quill 编辑器）
- 保存按钮：存草稿
- 特殊：需要滚动到底部

---

## ⚠️ 常见问题

### 1. 脚本报错 "未找到文件上传元素"
**原因**: Chrome 未启动或未开启远程调试

**解决**:
```bash
# Windows 启动 Chrome 远程调试
chrome.exe --remote-debugging-port=9222
```

### 2. 内容未填写
**原因**: 内容文件格式不正确

**解决**: 确保文件包含"标题："和"简介："两部分

### 3. 保存失败
**原因**: 未登录对应平台账号

**解决**: 手动打开各平台确认已登录

### 4. B 站描述填写无效
**原因**: B 站使用 Quill 编辑器

**解决**: 脚本已自动处理，使用 `element.innerText` 而非 `execCommand`

---

## 📊 性能对比

| 版本 | 执行方式 | 耗时 | 成功率 |
|------|---------|------|--------|
| v1.0 | 串行 + 盲目 | 45 分钟 | 60% |
| v1.5 | 并行 | 5 分钟 | 40% |
| **v2.0** | **顺序 + 智能** | **2-3 分钟** | **100%** |

---

## 📁 文件结构

```
multi-platform-uploader/
├── index.js                 # 主脚本
├── config.js                # 配置文件
├── SKILL.md                 # 本文件
├── README.md                # 使用说明
├── docs/
│   ├── GUIDE.md            # 完整指南
│   └── QUICK-REF.md        # 快速参考
└── examples/
    └── content-example.txt  # 内容格式示例
```

---

## 🔧 技术细节

### CDP 连接
使用 Chrome DevTools Protocol (CDP) 通过 WebSocket 连接浏览器：
```javascript
const ws = new WebSocket(`ws://127.0.0.1:${port}/devtools/browser`);
```

### 文件上传
使用 CDP 的 `DOM.setFileInputFiles` 命令：
```javascript
await sendCDP('DOM.setFileInputFiles', {
  objectId: objectId,
  files: [videoPath]
}, sessionId);
```

### 内容检查
保存前检查标题和描述是否填写：
```javascript
const check = await evalJS(sessionId, `(() => {
  const titleVal = document.querySelector('input[type="text"]')?.value || '';
  const descVal = document.querySelector('div[contenteditable="true"]')?.innerText || '';
  return {
    titleFilled: titleVal.length > 0,
    descFilled: descVal.length > 0
  };
})()`);
```

---

## 📄 许可证

MIT License

---

## 🙏 致谢

- OpenClaw 社区
- Kingsway Video 团队

---

**最后更新**: 2026-04-24  
**测试状态**: ✅ 已验证（抖音、小红书、B 站）  
**包大小**: ~17 KB
