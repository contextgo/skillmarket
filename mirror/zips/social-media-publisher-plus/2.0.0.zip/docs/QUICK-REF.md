# 多平台视频上传 - 快速参考卡片

**版本**: 2.0 | **更新时间**: 2026-04-24 | **状态**: ✅ 已验证

---

## 🚀 一键执行

```bash
node "C:\Users\caizheyu\.openclaw\workspace\upload-final.mjs"
```

---

## 📋 核心流程（必读）

```
分析页面 → 上传视频 → 等待完成 → 填写内容 → 【检查内容】 → 保存草稿
                                    ↑
                              关键！未填写则重试
```

---

## 🎯 平台关键参数

| 平台 | 视频 input 索引 | 标题选择器 | 描述选择器 | 保存按钮 |
|------|---------------|-----------|-----------|---------|
| **抖音** | `1`（第 2 个） | `input[placeholder*="作品标题"]` | `div[contenteditable="true"]` | 暂存离开 |
| **小红书** | `0`（第 1 个） | `input[type="text"]` | `div[contenteditable="true"]` | 暂存离开 |
| **B 站** | `0`（第 1 个） | `input[placeholder*="标题"]` | `.ql-editor` | 存草稿 |

---

## ⚠️ 常见错误

### ❌ 错误 1: 抖音上传失败
**原因**: 用了 index 0（图片 input）  
**解决**: 必须用 index 1（视频 input）

```javascript
// 找视频 input
const videoIdx = inputs.findIndex(i => i.accept.includes('video'));
const useIdx = videoIdx >= 0 ? videoIdx : 1;
```

### ❌ 错误 2: 内容未填写就保存
**原因**: 填写后立即保存，内容未生效  
**解决**: 保存前必须检查

```javascript
await fillContent(sessionId, title, desc);
const ok = await checkContent(sessionId, platform); // ← 必填！
if (!ok) await fillContentWithRetry(sessionId, title, desc, platform);
```

### ❌ 错误 3: B 站描述填写无效
**原因**: 用了 execCommand（B 站用 Quill 编辑器）  
**解决**: 直接设置 innerText

```javascript
// B 站专用
document.querySelector('.ql-editor').innerText = '内容';
```

---

## 🔍 内容检查代码（复制即用）

```javascript
async function checkContent(sessionId, platform) {
  const check = await evalJS(sessionId, `(() => {
    const titleVal = document.querySelector('input[type="text"]')?.value || '';
    const descVal = document.querySelector('div[contenteditable="true"], textarea, .ql-editor')?.innerText || '';
    return {
      titleFilled: titleVal.length > 0,
      titleLength: titleVal.length,
      descFilled: descVal.length > 0,
      descLength: descVal.length
    };
  })()`);
  
  console.log(`标题：${check.titleFilled ? '✓' : '❌'} (${check.titleLength}字)`);
  console.log(`描述：${check.descFilled ? '✓' : '❌'} (${check.descLength}字)`);
  
  return check.titleFilled && check.descFilled;
}
```

---

## ⏱️ 性能参考

| 平台 | 正常耗时 | 说明 |
|------|---------|------|
| 抖音 | 30-50 秒 | 视频上传 + 内容填写 + 保存 |
| 小红书 | 10-20 秒 | 视频上传较快 |
| B 站 | 60-120 秒 | 视频较大，上传较慢 |
| **总计** | **2-3 分钟** | 顺序执行 |

---

## 📁 文件位置

- **主脚本**: `C:\Users\caizheyu\.openclaw\workspace\upload-final.mjs`
- **指南文档**: `C:\Users\caizheyu\.openclaw\workspace\skills\ZYKS-skills\UPLOAD-SKILL-GUIDE.md`
- **截图目录**: `C:\Users\caizheyu\.openclaw\workspace\*-result.png`

---

## ✅ 检查清单

### 执行前
- [ ] Chrome 已启动（端口 9222）
- [ ] 已登录抖音、小红书、B 站
- [ ] 视频文件存在
- [ ] 内容文件存在

### 执行后
- [ ] 检查截图确认上传状态
- [ ] B 站需手动点击"存草稿"（如未自动保存）

---

## 🆘 故障排除

| 问题 | 检查 | 解决 |
|------|------|------|
| 脚本报错 | Chrome 是否启动？ | 打开 Chrome，访问 `chrome://version` 确认 |
| 上传失败 | 登录状态？ | 手动打开各平台确认已登录 |
| 内容未填写 | 选择器是否正确？ | 查看脚本中的选择器是否匹配 |
| 保存失败 | 按钮是否可见？ | 截图检查按钮位置 |

---

**最后更新**: 2026-04-24 14:42  
**测试结果**: ✅ 抖音 (45 秒) | ✅ 小红书 (15 秒) | ✅ B 站 (126 秒)

