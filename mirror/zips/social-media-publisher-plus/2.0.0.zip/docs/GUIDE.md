# 多平台视频上传 Skill 指南

**版本**: 2.0（最终优化版）  
**最后更新**: 2026-04-24  
**测试状态**: ✅ 抖音 | ✅ 小红书 | ✅ B 站

---

## 📋 核心原则

### 1. 先分析，后行动
**不要盲目操作！** 先分析页面结构，找到正确的元素再执行。

```javascript
// ✅ 正确：先分析页面
async function analyzePage(sessionId, platform) {
  const analysis = await evalJS(sessionId, `(() => {
    const inputs = [...document.querySelectorAll('input[type="file"]')].map((i, idx) => ({
      idx, accept: i.accept || '',
      isVideo: (i.accept||'').toLowerCase().includes('video')
    }));
    return {
      fileInputs: inputs,
      videoIdx: inputs.findIndex(i => i.isVideo),
      hasTitle: !!document.querySelector('input[placeholder*="标题"]'),
      descCount: document.querySelectorAll('div[contenteditable="true"]').length
    };
  })()`);
  
  const vidx = analysis.videoIdx >= 0 ? analysis.videoIdx : 0;
  return { analysis, videoInputIndex: vidx };
}
```

### 2. 内容检查机制
**保存前必须检查**标题和描述是否填写完整！

```javascript
// ✅ 必填：内容检查
async function checkContent(sessionId, platform) {
  const check = await evalJS(sessionId, `(() => {
    const titleVal = document.querySelector('input[type="text"]')?.value || '';
    const descVal = document.querySelector('div[contenteditable="true"]')?.innerText || '';
    return {
      titleFilled: titleVal.length > 0,
      titleLength: titleVal.length,
      descFilled: descVal.length > 0,
      descLength: descVal.length
    };
  })()`);
  
  console.log(`标题：${check.titleFilled ? '✓' : '❌'} (${check.titleLength}字)`);
  console.log(`描述：${check.descFilled ? '✓' : '❌'} (${check.descLength}字)`);
  
  return check.titleFilled && check.descFilled;
}
```

### 3. 动态等待策略
**不要固定等待！** 每 2 秒检测一次状态，完成就继续。

```javascript
// ✅ 正确：动态检测
async function waitForUpload(sessionId, platform, maxSeconds = 120) {
  for (let i = 0; i < maxSeconds / 2; i++) {
    const status = await evalJS(sessionId, `(() => {
      const progress = document.querySelector('[class*="progress"]')?.innerText || '';
      const isUploading = /上传中|%|MB/.test(progress);
      const isDone = /100%/.test(progress) || 
                     (!!document.querySelector('.video-name,video') && !isUploading);
      return { uploading: isUploading, done: isDone };
    })()`);
    
    if (status.done && !status.uploading) return true;
    await new Promise(r => setTimeout(r, 2000));
  }
  return false; // 超时
}
```

### 4. 重试机制
**失败时自动重试**，最多 2 次。

```javascript
// ✅ 正确：带重试的内容填写
async function fillContentWithRetry(sessionId, title, desc, platform, maxRetries = 2) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    await fillContent(sessionId, title, desc, platform);
    const ok = await checkContent(sessionId, platform);
    if (ok) return true;
    console.log(`  🔄 第${attempt}次重试...`);
  }
  return false;
}
```

---

## 🚀 标准流程

### 完整上传流程
```
1. 打开上传页面
   ↓
2. 分析页面结构（找 input 索引、标题框、描述框）
   ↓
3. 上传视频（用正确的 input index）
   ↓
4. 动态等待上传完成（每 2 秒检测）
   ↓
5. 填写标题和描述
   ↓
6. 【关键】检查内容是否填写完整
   ↓
7. 如果未填写 → 重试填写（最多 2 次）
   ↓
8. 如果已填写 → 查找保存按钮
   ↓
9. 点击保存草稿
   ↓
10. 处理确认弹窗（如果有）
```

---

## 📊 平台特性总结

### 抖音 (Douyin)
| 特性 | 详情 |
|------|------|
| 上传页面 | `https://creator.douyin.com/creator-micro/content/publish` |
| 文件输入 | 2 个（index 0=图片，index 1=视频） |
| 视频 input | **必须用 index 1**（accept 包含 video/*） |
| 标题选择器 | `input[placeholder*="作品标题"]` |
| 描述选择器 | `div[contenteditable="true"]` |
| 保存按钮 | "暂存离开"（底部） |
| 特殊说明 | 有确认弹窗，需要再次点击确认 |

### 小红书 (Xiaohongshu)
| 特性 | 详情 |
|------|------|
| 上传页面 | `https://creator.xiaohongshu.com/publish/publish` |
| 文件输入 | 1 个（直接就是视频） |
| 视频 input | **使用 index 0** |
| 标题选择器 | `input[type="text"]`（无 placeholder） |
| 描述选择器 | `div[contenteditable="true"]` |
| 保存按钮 | "暂存离开"（底部白色按钮） |
| 特殊说明 | 标题输入框没有 placeholder，需要用 type="text" 查找 |

### B 站 (Bilibili)
| 特性 | 详情 |
|------|------|
| 上传页面 | `https://member.bilibili.com/platform/upload/video/frame` |
| 文件输入 | 3 个（第一个就是视频） |
| 视频 input | **使用 index 0** |
| 标题选择器 | `input[placeholder*="标题"]` |
| 描述选择器 | `.ql-editor`（Quill 富文本编辑器） |
| 保存按钮 | "存草稿"（底部，需要滚动） |
| 特殊说明 | 描述填写用 `element.innerText = '内容'`，不是 execCommand |

---

## ⚠️ 常见陷阱与解决方案

### 1. 找错 input 元素
**问题**: 抖音有 2 个 file input，一个图片一个视频

**解决**:
```javascript
const inputs = [...document.querySelectorAll('input[type="file"]')];
const videoIdx = inputs.findIndex(i => (i.accept||'').toLowerCase().includes('video'));
const useIdx = videoIdx >= 0 ? videoIdx : 0;
```

### 2. 内容未填写就保存
**问题**: 填写后立即保存，但内容还没生效

**解决**:
```javascript
// 填写后必须检查
await fillContent(sessionId, title, desc);
const ok = await checkContent(sessionId, platform);
if (!ok) {
  // 重试
  await fillContentWithRetry(sessionId, title, desc, platform);
}
```

### 3. 保存按钮找不到
**问题**: 按钮在页面底部，需要先滚动

**解决**:
```javascript
await evalJS(sessionId, `(() => {
  window.scrollTo(0, document.body.scrollHeight);
})()`);
await new Promise(r => setTimeout(r, 1000));

// 然后再查找按钮
```

### 4. 描述填写无效
**问题**: 直接用 `innerText` 或 `value` 设置，但平台不识别

**解决**:
```javascript
// 对于 contenteditable div，使用 execCommand
document.execCommand('insertText', false, '内容');

// 对于 Quill 编辑器（B 站），直接设置 innerText
document.querySelector('.ql-editor').innerText = '内容';
```

### 5. 等待时间过长或过短
**问题**: 固定等待 30 秒，有时视频已上传完成还在等，有时没完成就继续

**解决**:
```javascript
// 动态检测，每 2 秒检查一次
for (let i = 0; i < 60; i++) {
  const status = await checkUploadStatus();
  if (status.done) break;
  await sleep(2000);
}
```

---

## 📁 脚本文件

### 主脚本
```
C:\Users\caizheyu\.openclaw\workspace\upload-final.mjs
```

### 使用方法
```bash
# 默认上传（抖音→小红书→B 站）
node "C:\Users\caizheyu\.openclaw\workspace\upload-final.mjs"

# 自定义视频和内容
# 修改脚本中的 videoPath 和 contentPath 变量
```

### 依赖
- Node.js 18+
- Chrome 已启动并开启远程调试（端口 9222）
- 已在 Chrome 中登录各平台账号

---

## 📈 性能对比

| 版本 | 执行方式 | 总耗时 | 说明 |
|------|---------|--------|------|
| v1.0（初始） | 串行 + 盲目尝试 | ~45 分钟 | 无分析、无检查、固定等待 |
| v1.5（并行） | 并行执行 | ~5 分钟 | 同时上传三个平台，但错误率高 |
| v2.0（优化） | 顺序 + 智能分析 | **2-3 分钟** | 先分析、内容检查、动态等待 |

**性能提升**: 约 **20 倍** 🚀

---

## ✅ 检查清单

### 上传前
- [ ] Chrome 已启动并开启远程调试（端口 9222）
- [ ] 已在 Chrome 中登录抖音、小红书、B 站账号
- [ ] 视频文件存在
- [ ] 内容文件存在（标题 + 描述）

### 上传中
- [ ] 页面分析成功（找到 file input、标题框、描述框）
- [ ] 视频上传成功（使用正确的 input index）
- [ ] 等待上传完成（动态检测）
- [ ] 内容填写成功（标题 + 描述）
- [ ] **内容检查通过**（标题和描述都有内容）

### 上传后
- [ ] 截图保存
- [ ] 草稿保存成功（或提示手动保存）
- [ ] 检查各平台截图确认状态

---

## 🔧 故障排除

### 问题：脚本报错 "未找到文件上传元素"
**原因**: 页面还没加载完成

**解决**: 增加等待时间
```javascript
await new Promise(r => setTimeout(r, 8000)); // 从 5 秒增加到 8 秒
```

### 问题：内容检查失败（标题/描述未填写）
**原因**: 选择器不匹配或填写后未触发事件

**解决**:
```javascript
// 填写后触发 input 和 change 事件
input.value = '内容';
input.dispatchEvent(new Event('input', { bubbles: true }));
input.dispatchEvent(new Event('change', { bubbles: true }));
```

### 问题：保存按钮找不到
**原因**: 按钮在页面底部，需要先滚动

**解决**:
```javascript
// 滚动到底部
await evalJS(sessionId, `window.scrollTo(0, document.body.scrollHeight)`);
await new Promise(r => setTimeout(r, 1000));
// 再查找按钮
```

---

## 📝 更新日志

### v2.0 (2026-04-24)
- ✅ 新增内容检查机制（保存前检查标题和描述）
- ✅ 新增自动重试机制（最多 2 次）
- ✅ 优化页面分析（显示详细选择器信息）
- ✅ 优化等待策略（动态检测上传进度）
- ✅ 修复小红书标题选择器问题
- ✅ 修复 B 站描述填写问题

### v1.5 (2026-04-24)
- ✅ 并行执行三个平台上传
- ⚠️ 错误率较高，已弃用

### v1.0 (2026-04-23)
- ✅ 初始版本，支持三个平台
- ⚠️ 速度慢（45 分钟），无内容检查

---

**最后测试**: 2026-04-24 14:17  
**测试结果**: ✅ 抖音 | ✅ 小红书 | ✅ B 站  
**总耗时**: 2 分 59 秒

