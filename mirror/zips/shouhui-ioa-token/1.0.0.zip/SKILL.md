---
name: get-ioa-cookie
description: 根据用户提供的 ioa_token，调用 xinhulu.com 接口查询并返回对应的 ioa_expire、ioa_sess、ioa_userinfo 三个 IOA Cookie 值。当用户说"根据 token 获取 cookie"、"查询 IOA Cookie"、"我有一个 ioa_token 帮我查 cookie"、"帮我拿 IOA 登录凭证"时触发。
---

# 根据 Token 获取 IOA Cookie

## 功能说明

用户提供一个 `ioa_token`，通过调用接口查询数据库中对应的三个 IOA Cookie 字段，用于访问 xinhulu.com 相关内网域名时携带。

## 使用步骤

1. 请用户提供 `ioa_token` 值（格式如 `ioa_ak_erick_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`）
2. 执行以下 curl 命令：

```bash
curl -X POST "https://alpha.xinhulu.com/ioatoken/getCookieByToken" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "token=<用户输入的ioa_token>"
```

3. 解析返回的 JSON，将三个 cookie 字段展示给用户

## 返回字段说明

| 字段 | 含义 |
|------|------|
| `ioa_expire` | IOA 会话过期时间（Unix 时间戳） |
| `ioa_sess` | IOA 会话凭证 |
| `ioa_userinfo` | IOA 用户信息（Base64 编码的 JSON） |

## 响应示例

**成功：**
```json
{
  "ret": 0,
  "errmsg": "",
  "data": {
    "ioa_expire": "1777143600",
    "ioa_sess": "Jmz5Dj/EIdnElMSIOgfyouLpkb9FJs8DFglf0dn2IWVYBAt1/3N63Ek8AzKwFgrB",
    "ioa_userinfo": "eyJ1c2VyaWQi..."
  }
}
```

**失败 - token 不存在或已失效：**
```json
{
  "ret": 10002,
  "errmsg": "token 不存在或已失效",
  "data": null
}
```

**失败 - token 为空：**
```json
{
  "ret": 10001,
  "errmsg": "token 不能为空",
  "data": null
}
```

## 错误处理

| 错误码 | 含义 | 处理建议 |
|--------|------|----------|
| `10001` | token 为空或查询失败 | 提示用户重新输入 token |
| `10002` | token 不存在或已失效 | 提示用户到 xadmin/tokenService.php 管理页面重新生成或将 token 设为「生效」 |

## 输出格式

成功后，将三个 cookie 以如下格式展示给用户，方便直接使用：

```
访问 xinhulu.com 相关的域名时，需要带上以下 Cookie：
ioa_expire=<ioa_expire值>
ioa_sess=<ioa_sess值>
ioa_userinfo=<ioa_userinfo值>
```
