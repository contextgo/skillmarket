---
name: GeoIP
description: "Look up IP addresses for country, city, ISP, and geolocation coordinates. Use when tracing IP origins, checking locations, or verifying ISP details."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["geoip","geolocation","ip","location","lookup","country","city","network"]
categories: ["System Tools", "Utility"]
---

# GeoIP

System operations toolkit for scanning, monitoring, reporting, alerting, benchmarking, and managing infrastructure entries. All operations are logged with timestamps and stored locally for full traceability and audit trails.

## Commands

| Command | Usage | Description |
|---------|-------|-------------|
| `scan` | `geoip scan <input>` | Record a scan entry or view recent scans |
| `monitor` | `geoip monitor <input>` | Record a monitor entry or view recent monitoring data |
| `report` | `geoip report <input>` | Record a report entry or view recent reports |
| `alert` | `geoip alert <input>` | Record an alert entry or view recent alerts |
| `top` | `geoip top <input>` | Record a top entry or view recent top results |
| `usage` | `geoip usage <input>` | Record a usage entry or view recent usage data |
| `check` | `geoip check <input>` | Record a check entry or view recent checks |
| `fix` | `geoip fix <input>` | Record a fix entry or view recent fixes |
| `cleanup` | `geoip cleanup <input>` | Record a cleanup entry or view recent cleanup operations |
| `backup` | `geoip backup <input>` | Record a backup entry or view recent backups |
| `restore` | `geoip restore <input>` | Record a restore entry or view recent restores |
| `log` | `geoip log <input>` | Record a log entry or view recent log entries |
| `benchmark` | `geoip benchmark <input>` | Record a benchmark entry or view recent benchmarks |
| `compare` | `geoip compare <input>` | Record a compare entry or view recent comparisons |
| `stats` | `geoip stats` | Show summary statistics across all entry types |
| `export <fmt>` | `geoip export json\|csv\|txt` | Export all entries to JSON, CSV, or plain text |
| `search <term>` | `geoip search <term>` | Search across all log files for a keyword |
| `recent` | `geoip recent` | Show the 20 most recent history entries |
| `status` | `geoip status` | Health check — version, entry count, disk usage, last activity |
| `help` | `geoip help` | Show help with all available commands |
| `version` | `geoip version` | Print version string |

Each operational command (scan, monitor, report, alert, top, usage, check, fix, cleanup, backup, restore, log, benchmark, compare) works the same way:

- **With arguments:** Saves the input with a timestamp to `<command>.log` and logs to `history.log`.
- **Without arguments:** Displays the 20 most recent entries from `<command>.log`.

## Data Storage

All data is stored locally at `~/.local/share/geoip/`:

- `<command>.log` — Timestamped entries for each command (e.g., `scan.log`, `monitor.log`, `backup.log`)
- `history.log` — Unified activity log across all commands
- `export.json`, `export.csv`, `export.txt` — Generated export files

No cloud, no network calls, no API keys required. Fully offline.

## Requirements

- Bash 4+ (uses `set -euo pipefail`)
- Standard Unix utilities (`date`, `wc`, `du`, `grep`, `head`, `tail`)
- No external dependencies

## When to Use

1. **Recording infrastructure scans** — Use `geoip scan "port scan results for 192.168.1.0/24"` to log scan findings with timestamps, building an audit trail of network reconnaissance.
2. **Tracking monitoring events** — Use `geoip monitor "CPU usage 95% on web-server-03"` to record monitoring observations for later analysis and trend spotting.
3. **Managing backup and restore logs** — Use `geoip backup "full backup completed for db-prod"` and `geoip restore` to maintain a history of backup/restore operations.
4. **Benchmarking and comparison** — Use `geoip benchmark "nginx vs caddy latency test"` and `geoip compare "before/after optimization"` to track performance tests over time.
5. **Exporting operational data** — Use `geoip export json` to extract all logged entries as structured JSON for dashboards, compliance reports, or integration with other tools.

## Examples

```bash
# Record a scan entry
geoip scan "nmap scan 10.0.0.0/8 completed, 42 hosts found"

# Record a monitoring observation
geoip monitor "disk usage at 87% on storage-node-1"

# Set an alert note
geoip alert "memory threshold exceeded on app-server-02"

# Log a cleanup operation
geoip cleanup "removed 15GB of stale logs from /var/log"

# Record a backup
geoip backup "weekly backup of postgres completed successfully"

# View recent scan entries (no args = list mode)
geoip scan

# Search all logs for a keyword
geoip search "server-02"

# Export everything to CSV
geoip export csv

# View summary statistics
geoip stats

# Health check
geoip status

# View recent activity across all commands
geoip recent
```

## How It Works

GeoIP stores all data locally in `~/.local/share/geoip/`. Each command logs activity with timestamps in the format `YYYY-MM-DD HH:MM|<input>`, enabling full traceability. The unified `history.log` records every operation with `MM-DD HH:MM <command>: <input>` format for cross-command auditing.

---

Powered by BytesAgain | bytesagain.com | hello@bytesagain.com
