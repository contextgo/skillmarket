---
name: word-counter
description: word-counter - 实用工具（SkillPay 收费版）
metadata: {"openclaw":{"requires":{"bins":["node"]},"install":[{"id":"node","kind":"node","package":"node-fetch","label":"Install node-fetch"}]}}
---

# word-counter

word-counter - 实用工具（SkillPay 收费版）

## 使用方式

```bash
word-counter --help
```

## 功能特点

- ⚡ 快速执行
- 💰 SkillPay 收费集成
- 🔒 安全可靠

## 配置

在 `~/.openclaw/workspace/config/word-counter.json` 配置 SkillPay API Key。
