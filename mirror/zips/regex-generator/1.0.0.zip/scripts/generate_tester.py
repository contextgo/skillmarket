#!/usr/bin/env python3
"""
生成正则表达式可视化验证工具 HTML
用法: python generate_tester.py <pattern> <flags> <description> [test_cases]

示例:
  python generate_tester.py "^1[3-9]\\d{9}$" "" "手机号验证" "13800138000,23800138000"
  python generate_tester.py "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$" "" "密码验证" "HelloWorld1,HELLO123"
"""

import sys
import json
import html


HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>正则验证 - {description}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }}
        .container {{
            max-width: 800px;
            margin: 0 auto;
        }}
        h1 {{
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }}
        .card {{
            background: white;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .card-title {{
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .regex-display {{
            background: #1e1e1e;
            color: #d4d4d4;
            padding: 20px;
            border-radius: 8px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 18px;
            word-break: break-all;
            margin-bottom: 16px;
        }}
        .regex-pattern {{ color: #ce9178; }}
        .regex-flags {{ color: #569cd6; }}
        .input-group {{ margin-bottom: 16px; }}
        label {{
            display: block;
            font-size: 14px;
            color: #666;
            margin-bottom: 6px;
        }}
        input[type="text"] {{
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: border-color 0.2s;
            font-family: 'Consolas', 'Monaco', monospace;
        }}
        input[type="text"]:focus {{
            outline: none;
            border-color: #4a90d9;
        }}
        .test-item {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 8px;
            background: #f8f9fa;
        }}
        .test-item input[type="text"] {{
            flex: 1;
            margin: 0;
        }}
        .test-result {{
            min-width: 80px;
            text-align: center;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
        }}
        .test-result.match {{
            background: #d4edda;
            color: #155724;
        }}
        .test-result.no-match {{
            background: #f8d7da;
            color: #721c24;
        }}
        .test-result.error {{
            background: #fff3cd;
            color: #856404;
        }}
        .btn {{
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s;
        }}
        .btn-primary {{
            background: #4a90d9;
            color: white;
        }}
        .btn-primary:hover {{ background: #357abd; }}
        .btn-secondary {{
            background: #6c757d;
            color: white;
        }}
        .btn-secondary:hover {{ background: #5a6268; }}
        .btn-danger {{
            background: #dc3545;
            color: white;
        }}
        .btn-danger:hover {{ background: #c82333; }}
        .match-detail {{
            background: #f8f9fa;
            padding: 16px;
            border-radius: 8px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            line-height: 1.6;
        }}
        .highlight {{
            background: #ffeb3b;
            padding: 2px 0;
            border-radius: 2px;
        }}
        .code-block {{
            background: #1e1e1e;
            color: #d4d4d4;
            padding: 16px;
            border-radius: 8px;
            overflow-x: auto;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            margin-top: 8px;
        }}
        .empty-state {{
            text-align: center;
            color: #999;
            padding: 40px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🎯 正则表达式验证器</h1>
        
        <div class="card">
            <div class="card-title">✏️ 生成的正则</div>
            <div class="regex-display">
                /<span class="regex-pattern">{escaped_pattern}</span>/<span class="regex-flags">{flags}</span>
            </div>
            <div style="color: #666; font-size: 14px;">
                <strong>描述：</strong>{description}
            </div>
        </div>

        <div class="card">
            <div class="card-title">🧪 测试用例</div>
            <div id="test-cases">
                {test_cases_html}
            </div>
            <button class="btn btn-secondary" onclick="addTestCase()">+ 添加测试用例</button>
        </div>

        <div class="card">
            <div class="card-title">📖 匹配详情</div>
            <div id="match-details" class="empty-state">
                在测试用例中输入内容查看匹配详情
            </div>
        </div>

        <div class="card">
            <div class="card-title">💻 代码示例</div>
            <div class="input-group">
                <label>JavaScript</label>
                <div class="code-block">const regex = /{escaped_pattern}/{flags};
const result = regex.test("你的测试文本");
console.log(result); // true 或 false</div>
            </div>
            <div class="input-group">
                <label>Python</label>
                <div class="code-block">import re
regex = re.compile(r'{python_pattern}'{python_flags})
result = regex.match("你的测试文本")
print(bool(result))  # True 或 False</div>
            </div>
        </div>
    </div>

    <script>
        const PATTERN = '{js_pattern}';
        const FLAGS = '{flags}';
        
        function runTest(input) {{
            const testString = input.value;
            const resultDiv = input.parentElement.querySelector('.test-result');
            
            if (!testString) {{
                resultDiv.textContent = '等待';
                resultDiv.className = 'test-result';
                return;
            }}
            
            try {{
                const regex = new RegExp(PATTERN, FLAGS);
                const matches = testString.match(regex);
                const isMatch = matches !== null;
                
                if (isMatch) {{
                    resultDiv.textContent = '✅ 匹配';
                    resultDiv.className = 'test-result match';
                    showMatchDetails(testString, matches, regex);
                }} else {{
                    resultDiv.textContent = '❌ 不匹配';
                    resultDiv.className = 'test-result no-match';
                }}
            }} catch (e) {{
                resultDiv.textContent = '⚠️ 错误';
                resultDiv.className = 'test-result error';
            }}
        }}
        
        function showMatchDetails(testString, matches, regex) {{
            const container = document.getElementById('match-details');
            let html = '<div class="match-detail">';
            
            // 高亮显示匹配部分
            let highlighted = testString;
            if (matches && matches[0]) {{
                const matchStr = matches[0];
                highlighted = highlighted.replace(matchStr, '<span class="highlight">' + matchStr + '</span>');
            }}
            
            html += '<div style="margin-bottom: 12px;"><strong>原文：</strong>' + highlighted + '</div>';
            html += '<div style="margin-bottom: 12px;"><strong>匹配结果：</strong>' + (matches ? matches.join(', ') : '无') + '</div>';
            
            // 捕获组信息
            const execResult = regex.exec(testString);
            if (execResult && execResult.length > 1) {{
                html += '<div style="margin-bottom: 12px;"><strong>捕获组：</strong></div>';
                for (let i = 1; i < execResult.length; i++) {{
                    html += '<div style="margin-left: 20px;">$' + i + ': ' + (execResult[i] || '(空)') + '</div>';
                }}
            }}
            
            html += '<div><strong>索引位置：</strong>' + (matches ? matches.index : 'N/A') + '</div>';
            html += '</div>';
            
            container.innerHTML = html;
            container.className = '';
        }}
        
        function addTestCase(value = '') {{
            const container = document.getElementById('test-cases');
            const div = document.createElement('div');
            div.className = 'test-item';
            div.innerHTML = `
                <input type="text" placeholder="输入测试文本..." value="${{value}}" oninput="runTest(this)">
                <div class="test-result">等待</div>
                <button class="btn btn-danger" onclick="removeTest(this)">删除</button>
            `;
            container.appendChild(div);
            if (value) runTest(div.querySelector('input'));
        }}
        
        function removeTest(btn) {{
            const items = document.querySelectorAll('.test-item');
            if (items.length > 1) {{
                btn.parentElement.remove();
            }} else {{
                const input = btn.parentElement.querySelector('input');
                input.value = '';
                runTest(input);
            }}
        }}
    </script>
</body>
</html>'''


def generate_tester(pattern: str, flags: str, description: str, test_cases: list = None) -> str:
    """生成 HTML 验证工具"""
    
    # 转义 HTML
    escaped_pattern = html.escape(pattern)
    escaped_description = html.escape(description)
    
    # JavaScript 需要双反斜杠转义
    js_pattern = pattern.replace('\\', '\\\\').replace("'", "\\'")
    
    # Python 原始字符串
    python_pattern = pattern.replace('\\', '\\\\')
    
    # Python flags
    python_flags_str = ''
    if flags:
        flag_list = []
        if 'i' in flags:
            flag_list.append('re.IGNORECASE')
        if 'm' in flags:
            flag_list.append('re.MULTILINE')
        if 's' in flags:
            flag_list.append('re.DOTALL')
        if flag_list:
            python_flags_str = ', ' + ' | '.join(flag_list)
    
    # 生成测试用例 HTML
    test_cases_html = ''
    if test_cases:
        for test in test_cases:
            escaped_test = html.escape(test)
            test_cases_html += f'''
                <div class="test-item">
                    <input type="text" value="{escaped_test}" oninput="runTest(this)">
                    <div class="test-result">等待</div>
                    <button class="btn btn-danger" onclick="removeTest(this)">删除</button>
                </div>
            '''
    else:
        test_cases_html = '''
            <div class="test-item">
                <input type="text" placeholder="输入测试文本..." oninput="runTest(this)">
                <div class="test-result">等待</div>
                <button class="btn btn-danger" onclick="removeTest(this)">删除</button>
            </div>
        '''
    
    html_content = HTML_TEMPLATE.format(
        escaped_pattern=escaped_pattern,
        flags=html.escape(flags),
        description=escaped_description,
        js_pattern=js_pattern,
        python_pattern=python_pattern,
        python_flags=python_flags_str,
        test_cases_html=test_cases_html
    )
    
    return html_content


def main():
    if len(sys.argv) < 4:
        print("用法: python generate_tester.py <pattern> <flags> <description> [test_cases]", file=sys.stderr)
        print("", file=sys.stderr)
        print("示例:", file=sys.stderr)
        print('  python generate_tester.py "^1[3-9]\\\\d{9}$" "" "手机号验证" "13800138000,23800138000"', file=sys.stderr)
        print('  python generate_tester.py "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\\\d).{8,}$" "" "密码验证" "HelloWorld1,HELLO123"', file=sys.stderr)
        sys.exit(1)
    
    pattern = sys.argv[1]
    flags = sys.argv[2]
    description = sys.argv[3]
    
    # 解析测试用例
    test_cases = []
    if len(sys.argv) > 4:
        test_cases = [t.strip() for t in sys.argv[4].split(',') if t.strip()]
    
    html_content = generate_tester(pattern, flags, description, test_cases)
    
    # 输出到 stdout
    print(html_content)


if __name__ == "__main__":
    main()
