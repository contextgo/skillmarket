#!/usr/bin/env python3
"""
正则表达式验证脚本
用法: python validate.py <pattern> <test_string> [flags]

示例:
  python validate.py "^1[3-9]\\d{9}$" "13800138000"
  python validate.py "^[a-z]+$" "ABC" 2  # flags=2 表示 IGNORECASE
"""

import re
import sys
import json


def validate(pattern: str, test_string: str, flags: int = 0) -> dict:
    """
    验证正则表达式匹配结果
    
    Args:
        pattern: 正则表达式模式
        test_string: 测试字符串
        flags: 正则标志（整数）
    
    Returns:
        dict: 包含匹配结果的字典
    """
    try:
        regex = re.compile(pattern, flags)
        match = regex.search(test_string)
        
        result = {
            "match": bool(match),
            "groups": list(match.groups()) if match else [],
            "group_dict": match.groupdict() if match else {},
            "full_match": bool(regex.fullmatch(test_string)),
            "pattern": pattern,
            "test_string": test_string
        }
        
        return result
        
    except re.error as e:
        return {
            "error": f"正则语法错误: {str(e)}",
            "pattern": pattern,
            "test_string": test_string
        }
    except Exception as e:
        return {
            "error": f"验证失败: {str(e)}",
            "pattern": pattern,
            "test_string": test_string
        }


def main():
    if len(sys.argv) < 3:
        print("用法: python validate.py <pattern> <test_string> [flags]", file=sys.stderr)
        print("", file=sys.stderr)
        print("示例:", file=sys.stderr)
        print('  python validate.py "^1[3-9]\\\\d{9}$" "13800138000"', file=sys.stderr)
        print('  python validate.py "^[a-z]+$" "ABC" 2', file=sys.stderr)
        print("", file=sys.stderr)
        print("flags 值 (可组合，如 2+8=10):", file=sys.stderr)
        print("  2  = IGNORECASE (忽略大小写)", file=sys.stderr)
        print("  8  = MULTILINE (多行模式)", file=sys.stderr)
        print("  16 = DOTALL (.匹配换行)", file=sys.stderr)
        sys.exit(1)
    
    pattern = sys.argv[1]
    test_string = sys.argv[2]
    flags = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    
    result = validate(pattern, test_string, flags)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
