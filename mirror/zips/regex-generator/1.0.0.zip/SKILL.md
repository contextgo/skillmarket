---
name: regex-generator
description: |
  This skill should be used when the user needs to generate regular expressions from natural language descriptions, 
  validate regex patterns, or refine existing regex based on test feedback. 
  Trigger for requests such as "帮我写个正则", "匹配手机号", "验证邮箱格式", "提取链接", 
  "密码校验正则", "用户名验证", "generate a regex", "validate phone number", "regex for email", 
  "正则表达式", "手机号正则", "邮箱正则", or any regex-related validation tasks.
---

# 正则生成器 Skill

## 工作流

### 1. 提取关键信息

从用户输入中提取：
- **匹配目标**：手机号、邮箱、密码、URL、身份证号、日期等
- **约束条件**：
  - 长度限制（最少/最多字符数）
  - 字符类型（数字、字母、大小写、特殊字符）
  - 格式要求（开头/结尾、分隔符、固定前缀）
- **使用场景**：验证、提取、替换、分割

### 2. 识别意图

| 意图 | 描述 | 标志特点 |
|------|------|----------|
| **验证** | 判断输入是否符合规则 | 使用 `^` 和 `$` 锚点，确保完整匹配 |
| **提取** | 从文本中找出匹配内容 | 可能使用 `g` 全局标志，不需要锚点 |
| **处理** | 替换或分割内容 | 关注捕获组 `()` 和替换逻辑 |

### 3. 生成正则

根据提取的信息和意图，生成合适的正则表达式：
- 选择合适的元字符和量词
- 添加必要的转义
- 根据意图决定是否使用锚点

### 4. 生成可视化验证工具

**默认不自动生成网页**，而是主动询问用户：

> "需要我生成一个可视化验证网页吗？可以在浏览器中实时测试这个正则。"

如果用户明确说"要"、"生成"、"做个网页"等肯定词，再执行以下步骤：
1. **生成文件名**：使用`特征+UUID`格式，例如 `regex-phone-a1b2c3d4.html`，避免覆盖已有文件
2. **用 `open_result_view` 交付**（不要用 `preview_url`，会导致页面被覆盖）

如果用户说"不用"、"不需要网页"、"不要生成"等否定词，则跳过生成步骤。

验证工具包含：
- 生成的正则表达式预填充
- 可添加多个测试用例
- 实时显示匹配结果
- 高亮匹配内容
- 显示捕获组信息

生成命令：
```bash
# 生成带 UUID 的文件名（保留历史文件）
UUID=$(python3 -c "import uuid; print(str(uuid.uuid4())[:8])")
python3 scripts/generate_tester.py "<pattern>" "<flags>" "<描述>" "<test1,test2,...>" > "regex-<特征>-${UUID}.html"
```

文件名生成示例：
- 美国手机号正则 → `regex-usphone-a1b2c3d4.html`
- 密码验证正则 → `regex-password-e5f6g7h8.html`
- 邮箱验证正则 → `regex-email-i9j0k1l2.html`

**注意**：不再删除旧文件，每个新生成的验证工具都有唯一文件名，方便对比历史版本。

### 5. 输出格式

```
🎯 生成的正则

表达式：/<pattern>/<flags>
意图：<验证/提取/处理>
解释：<逐段解释正则含义>

📋 使用示例

JavaScript:
<code>

Python:
<code>

🔍 可视化验证工具

已生成验证工具：regex-tester.html
- 点击链接打开或运行：python scripts/generate_tester.py ...
- 在工具中添加测试用例，实时查看匹配结果

💡 反馈调整

如果验证结果不对，告诉我：
- "应该匹配但没匹配：<内容>"
- "不该匹配但匹配了：<内容>"
- "需要支持：<新需求>"
```

### 5. 验证反馈循环

用户测试后反馈问题 → 分析原因 → 调整正则 → 重新输出

常见调整场景：
- 漏匹配：放宽约束条件
- 误匹配：增加排除规则
- 需要捕获：添加捕获组
- 性能问题：优化贪婪/懒惰匹配

## 常见场景速查

| 场景 | 示例正则 |
|------|----------|
| 手机号 | `^1[3-9]\d{9}$` |
| 邮箱 | `^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$` |
| 密码(8位+大小写+数字) | `^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$` |
| URL | `^https?://[^\s/$.?#].[^\s]*$` |
| 身份证号 | `^\d{17}[\dXx]$` |
| 中文字符 | `[\u4e00-\u9fa5]+` |
| 日期(YYYY-MM-DD) | `^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$` |

## 调用验证脚本

```bash
# 基本用法
python scripts/validate.py "^1[3-9]\\d{9}$" "13800138000"

# 带标志（flags 为整数，如 re.IGNORECASE=2）
python scripts/validate.py "^[a-z]+$" "ABC" 2

# 输出示例
{"match": true, "groups": [], "full_match": true}
```

Python re 模块标志值：
- IGNORECASE = 2
- MULTILINE = 8
- DOTALL = 16
