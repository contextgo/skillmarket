# Wayve Tool Reference

Complete reference for all Wayve MCP tools. Consult this when you need exact parameter names, types, or action options.

## Table of Contents
- [Planning & Context](#planning--context)
- [Coaching Context](#coaching-context)
- [Activities](#activities)
- [Pillars](#pillars)
- [Projects](#projects)
- [Time Locks](#time-locks)
- [Week Reviews](#week-reviews)
- [Analytics](#analytics)
- [Knowledge Base](#knowledge-base)
- [Time Audits](#time-audits)
- [Checklist Items](#checklist-items)
- [Recurrence](#recurrence)
- [Focus Templates](#focus-templates)
- [User Settings](#user-settings)
- [Happiness Insights](#happiness-insights)
- [Pillar Frequencies](#pillar-frequencies)
- [Smart Suggestions](#smart-suggestions)
- [Automations](#automations)

---

## Planning & Context

### `wayve_get_planning_context`
Get everything needed to plan a user's week in one call. **Call this first** when helping plan.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `week` | int 1-53 | No | Week number (default: current) |
| `year` | int | No | Year (default: current) |
| `response_format` | "json" / "markdown" | No | Output format |

Returns: pillars, activities (scheduled/unscheduled/incomplete), time_locks, user_preferences, last_week_review, frequency_progress, perfect_week template, knowledge_summary.

### `wayve_get_availability`
Find free time slots for scheduling.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `week` | int 1-53 | No | Week number (default: current) |
| `year` | int | No | Year (default: current) |
| `slot_duration_minutes` | int 15-240 | No | Minimum slot size (default: 30) |
| `response_format` | "json" / "markdown" | No | Output format |

Returns: total_available_hours, total_scheduled_hours, by_day (with slots array showing start/end/duration).

**Energy hints:** If the user has stored energy patterns in their knowledge base (e.g., `energy_patterns` / `peak_energy_time: "7-10 AM"`), each slot includes an `energy_hint` field:
- `"peak"` — user's known high-energy window, ideal for demanding/creative work
- `"moderate"` — no specific pattern known for this time
- `"low"` — user's known low-energy window, ideal for routine/admin work
- `null` — no energy data stored yet

Use energy hints to schedule high-energy activities in peak slots and routine work in low-energy slots.

### `wayve_daily_brief`
Concise daily overview with today's schedule and priorities.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `date` | YYYY-MM-DD | No | Date (default: today) |
| `response_format` | "json" / "markdown" | No | Output format |

Returns: scheduled activities (sorted by time), completed_count, top 5 unscheduled, today's time_locks.

---

## Coaching Context

### `wayve_coaching_context`

Get a unified coaching context for proactive, personalized guidance — all in one call.

**When to use:** At session start for proactive coaching, before any flow, or when you need a quick health check on the user's journey.
**When NOT to use:** For detailed week planning data → `wayve_get_planning_context`. For specific analytics (producer score, patterns) → `wayve_get_analytics`. For today's schedule → `wayve_daily_brief`.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| week | int (1-53) | No | Week number. Defaults to current week. |
| year | int | No | Year. Defaults to current year. |
| response_format | string | No | "json" or "markdown". Default: "json" |

**Returns:**
- `journey` — stage (new/onboarded/active_rituals/power_user), weeks active, last wrap-up/fresh-start dates, time audit status, ritual consistency
- `pillar_health` — per pillar: completed/total activities, completion %, frequency on track, target hours
- `red_flags` — auto-generated warnings (e.g., "Health has 0 activities this week", "Producer score declining", "No Wrap Up in 3 weeks")
- `producer_score` — current % and trend (up/stable/down/unknown)
- `automation_coverage` — agent routines count, push notifications count (total and enabled)
- `coaching_themes` — stored coaching observations from knowledge base
- `active_commitments` — current commitments from knowledge base
- `knowledge_highlights` — key insights from energy_patterns, delegation_candidates, bucket_balance, weekly_patterns
- `pending_suggestions_count` — number of pending smart suggestions

---

## Activities

### `wayve_create_activity`
Create one or multiple activities.

**When NOT to use:** For recurring blocks → use `wayve_manage_timelock`. For updating existing → use `wayve_update_activity`.

**Single mode** — provide `title` + `bucket_id`:
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `title` | string (max 500) | Yes | Activity title |
| `bucket_id` | UUID | Yes | Pillar to assign to |
| `description` | string (max 5000) | No | Details |
| `scheduled_date` | YYYY-MM-DD | No | When |
| `scheduled_time` | HH:MM | No | What time |
| `duration_minutes` | int 1-480 | No | How long |
| `project_id` | UUID | No | Link to project |
| `priority` | int 1-5 | No | 1=lowest, 5=highest |
| `energy_required` | high/medium/low | No | Energy cost |
| `time_flexibility` | fixed/flexible | No | Can it move? |
| `location_context` | home/office/gym/outdoors/anywhere | No | Where |

**Batch mode** — provide `activities` array (max 100 items) with same fields per item.

### `wayve_update_activity`
Update an existing activity.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | UUID | Yes | Activity ID |
| `title` | string (max 500) | No | New title |
| `completed` | boolean | No | Mark done |
| `scheduled_date` | YYYY-MM-DD / null | No | Reschedule or unschedule |
| `scheduled_time` | HH:MM / null | No | Change time |
| `bucket_id` | UUID | No | Move to different pillar |
| `duration_minutes` | int 1-480 / null | No | Change duration |
| `priority` | int 1-5 / null | No | Change priority |
| `energy_required` | high/medium/low / null | No | Change energy |
| `project_id` | UUID / null | No | Link/unlink project |

### `wayve_delete_activity`
| Param | Type | Required |
|-------|------|----------|
| `id` | UUID | Yes |

### `wayve_search_activities`
Search activities by text, pillar, date range, or completion status.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `query` | string (max 200) | No | Text search in titles |
| `bucket_id` | UUID | No | Filter by pillar |
| `date_from` | YYYY-MM-DD | No | Start of range |
| `date_to` | YYYY-MM-DD | No | End of range |
| `completed` | boolean | No | Filter by status |
| `limit` | int 1-100 | No | Results (default: 20) |

---

## Pillars

### `wayve_manage_bucket`
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | create / update / reorder | Yes | What to do |
| `id` | UUID | For update | Pillar ID |
| `name` | string (max 100) | For create | Pillar name |
| `color` | hex string | For create | e.g., "#10B981" |
| `intention` | string (max 500) | No | Why this area matters |
| `target_hours_per_week` | number 0-168 | No | Weekly target |
| `preferred_time_slot` | morning/afternoon/evening/flexible | No | When |
| `is_focus` | boolean | For update | Set as focus pillar |
| `archived` | boolean | No | true=archive, false=restore |
| `bucket_ids` | UUID[] | For reorder | New order |

---

## Projects

### `wayve_manage_project`
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | create / update | Yes | What to do |
| `id` | UUID | For update | Project ID |
| `name` | string 1-200 | For create | Project name |
| `color` | hex string | For create | Color |
| `bucket_id` | UUID | No | Link to pillar |
| `description` | string (max 1000) | No | Details |
| `goal_type` | target / habit | No | Type (default: "target") |
| `target_value` | positive number | No | e.g., 100 pages |
| `target_unit` | string (max 50) | No | e.g., "hours", "pages" |
| `current_value` | number >= 0 | For update | Progress |
| `status` | active/completed/archived | For update | "archived" = soft delete |

---

## Time Locks

### `wayve_manage_timelock`
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | create / update / delete | Yes | What to do |
| `id` | UUID | For update/delete | Time lock ID |
| `name` | string 1-200 | For create | Name |
| `start_time` | HH:MM | For create | Start |
| `end_time` | HH:MM | For create | End |
| `bucket_id` | UUID / null | No | Link to pillar |
| `color` | hex string | No | Color |
| `recurrence_type` | daily/weekly/biweekly/monthly | No | Default: weekly |
| `days_of_week` | int[] (0-6) | No | 0=Sunday |
| `is_active` | boolean | No | Default: true |
| `start_date` | YYYY-MM-DD | No | When it begins |
| `recurrence_end_date` | YYYY-MM-DD / null | No | When it ends |

---

## Week Reviews

### `wayve_manage_week_review`
**Action: `save`**
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `week_number` | int 1-53 | Yes | Week |
| `year` | int | Yes | Year |
| `mood_rating` | int 1-5 | No | Overall mood |
| `energy_level` | int 1-5 | No | Energy |
| `fulfillment_rating` | int 1-5 | No | Fulfillment |
| `proud_of` | string (max 1000) | No | Wins |
| `what_worked` | string (max 1000) | No | Keep doing |
| `what_to_change` | string (max 1000) | No | Adjust |
| `focus_bucket_id` | UUID | No | Next week's focus pillar |
| `wrap_up_status` | enum | No | Ritual status |
| `fresh_start_status` | enum | No | Ritual status |

**Action: `save_buckets`**
| Param | Type | Required |
|-------|------|----------|
| `week_review_id` | UUID | Yes |
| `buckets` | array (max 20) | Yes |

Each pillar: `{ bucket_id (UUID), score (1-5), satisfaction (1-5), note (max 1000), hours_planned, hours_actual, activities_planned, activities_completed }`

---

## Analytics

### `wayve_get_analytics`

**When NOT to use:** For current week's pillar health → use `wayve_coaching_context`. For time audit analysis → use `wayve_manage_time_audit(action: report)`.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | producer_score / task_patterns / energy_skill_matrix | Yes | Type of analysis |
| `week` | int 1-53 | No | For producer_score only |
| `year` | int | No | For producer_score only |

- **producer_score**: completion rate (0-100), per-pillar breakdown, 12-week trend
- **task_patterns**: frequently incomplete activities, energy patterns by time, pillar distribution (4 weeks)
- **energy_skill_matrix**: activities grouped by energy/value, delegation candidates (8 weeks)

---

## Knowledge Base

### `wayve_manage_knowledge`

**When NOT to use:** For smart suggestions → use `wayve_manage_smart_suggestions`. For planning context → use `wayve_get_planning_context`.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | list/get/create/update/delete/summary/save_insight | Yes | What to do |
| `id` | UUID | For get/update/delete | Entry ID |
| `category` | string (max 100) | For create/save_insight/list filter | Category |
| `key` | string (max 200) | For create/save_insight | Key name |
| `value` | string (max 2000) | For create/save_insight | Content |
| `confidence` | float 0-1 | No | Default: 0.8 |
| `source` | string (max 200) | For create/update | Auto "ai_conversation" for save_insight |

**save_insight** is a shortcut for create with source auto-set to "ai_conversation".

---

## Time Audits

### `wayve_manage_time_audit`

**When NOT to use:** For ongoing time tracking (not an audit) → create regular activities instead.

**Action: `start`**
| Param | Type | Required |
|-------|------|----------|
| `start_date` | YYYY-MM-DD | Yes |
| `end_date` | YYYY-MM-DD | Yes |
| `name` | string (max 100) | No (default: "Time Audit") |
| `interval_minutes` | int 15-120 | No (default: 30) |
| `active_hours_start` | HH:MM | No (default: 08:00) |
| `active_hours_end` | HH:MM | No (default: 20:00) |

**Action: `log_entry`**
| Param | Type | Required |
|-------|------|----------|
| `audit_id` | UUID | Yes |
| `what_did_you_do` | string 1-500 | Yes |
| `energy_level` | int 1-5 | Yes | How much energy does this give? 1=draining, 5=energizing |
| `value_level` | int 1-5 | Yes | How much business value/revenue does this generate? 1=very low, 5=very high |
| `bucket_id` | UUID | No |
| `note` | string (max 500) | No |

**Action: `report`**
| Param | Type | Required |
|-------|------|----------|
| `audit_id` | UUID | Yes |

Returns: pillar_summary (with avg_energy + avg_value) + activity_matrix (all entries with energy x value data, grouped into quadrants: Focus, Optimize, Reconsider, Automate).

**Action: `delete`**
| Param | Type | Required |
|-------|------|----------|
| `audit_id` | UUID | Yes |

Permanently deletes the audit and all its entries.

---

## Checklist Items

### `wayve_manage_checklist`
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | list/create/update/delete/bulk_create | Yes | What to do |
| `activity_id` | UUID | Yes | Parent activity |
| `item_id` | UUID | For update/delete | Checklist item |
| `title` | string (max 500) | For create | Item text |
| `completed` | boolean | For update | Toggle |
| `sort_order` | int >= 0 | No | Position |
| `items` | array (max 50) | For bulk_create | `[{ title, completed?, sort_order? }]` |

---

## Recurrence

### `wayve_manage_recurrence`
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | get / set / delete | Yes | What to do |
| `activity_id` | UUID | Yes | Activity |
| `frequency` | daily/weekly/biweekly/monthly | For set | How often |
| `interval` | int 1-12 | No | Default: 1 |
| `days_of_week` | int[] (0-6) | No | For weekly/biweekly |
| `end_date` | YYYY-MM-DD | No | When to stop |

---

## Focus Templates

### `wayve_manage_focus_template`
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | list/get_active/create/update/activate/delete | Yes | What to do |
| `id` | UUID | For update/activate/delete | Template ID |
| `name` | string (max 100) | For create | Template name |
| `description` | string (max 500) | No | Details |
| `is_perfect_week` | boolean | No | Perfect Week template |
| `distribution` | `{ "bucket_id": hours }` | For create | Hours per pillar |
| `total_hours` | float 0-168 | No | Total weekly hours |

---

## User Settings

### `wayve_manage_settings`
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | get_preferences / update_preferences / get_profile / update_profile | Yes | What to do |
| `calendar_start_hour` | int 0-23 | No | Day starts at |
| `calendar_end_hour` | int 1-24 | No | Day ends at |
| `max_hours_per_day` | int 1-24 | No | Max schedulable |
| `sleep_hours_per_day` | float 0-24 | No | Sleep hours |
| `full_name` | string (max 100) | No | For update_profile |

---

## Happiness Insights

### `wayve_get_happiness_insights`

Analyze mood correlations: what activities, pillars, and patterns correlate with higher or lower mood ratings across weeks.

**When to use:** During Life Audits, or when the user wants to understand what makes them happiest.
**When NOT to use:** For current week mood → check last week's review via `wayve_get_planning_context`. For pillar health → use `wayve_coaching_context`.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `recalculate` | boolean | No | Force fresh calculation. Default: false (uses cached correlations). |

**Returns:** Array of correlations showing which activities/pillars/patterns correlate with higher or lower mood ratings. Use this to connect "you're happiest when you invest in Relationships" or "mood dips when Health is neglected."

---

## Pillar Frequencies

### `wayve_manage_bucket_frequency`
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | list / create / update / delete | Yes | What to do |
| `id` | UUID | For update/delete | Frequency target ID |
| `bucket_id` | UUID | For create | Pillar to set target for |
| `frequency_type` | weekly / daily / monthly | For create | Tracking period |
| `target_count` | int 1-100 | For create | Activities per period |

Examples: "exercise 3x/week" → bucket_id=Health, frequency_type=weekly, target_count=3

### `wayve_get_frequency_progress`
| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `week` | int 1-53 | No | Week number (default: current) |
| `year` | int | No | Year (default: current) |

Returns per-pillar frequency targets vs. actual completion for the week.

---

## Smart Suggestions

### `wayve_manage_smart_suggestions`
Track observational suggestions — patterns paired with proposals.

| Param | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | list/create/accept/dismiss/snooze/delete | Yes | What to do |
| `id` | UUID | For accept/dismiss/snooze/delete | Suggestion ID (knowledge entry ID) |
| `pattern` | string (max 1000) | For create | What was observed |
| `proposal` | string (max 1000) | For create | What is proposed |
| `source_data` | object | No | Supporting analytics data (for create) |
| `created_from` | string (max 100) | No | Context: "wrap_up", "fresh_start", "life_audit", "analytics" |
| `snooze_until` | YYYY-MM-DD | For snooze | Resurface after this date |
| `status_filter` | pending/accepted/dismissed/snoozed | No | Filter for list action |

**Stored JSON value:** `{ pattern, proposal, source_data, status, created_from, snoozed_until }`

**Status flow:** pending → accepted / dismissed / snoozed. After `accepted`, Wayve is done.

---

## Automations

### `wayve_manage_automations`

Manage AI agent routines and server-side push notifications. Agent routines are playbooks stored in Wayve (not executed server-side). Push notifications are scheduled messages delivered via Telegram, Discord, Slack, email, or pull model.

**When to use:** Setting up morning briefs, wrap-up reminders, agent routines, or any scheduled automation.
**When NOT to use:** For one-off reminders → create an activity instead. For knowledge persistence → use `wayve_manage_knowledge`.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `action` | string | Yes | `list` / `create` / `update` / `delete` / `create_bundle` / `get_pending` / `acknowledge` |
| `id` | string | For update/delete | Automation UUID |
| `automation_type` | string | For create | See types below |
| `name` | string | No | Display name |
| `schedule_cron` | string | For create | 5-field cron: `minute hour day month weekday` (e.g., `30 7 * * *` = 7:30 AM daily) |
| `timezone` | string | For create | IANA timezone (e.g., `Europe/Amsterdam`) |
| `enabled` | boolean | No | Enable/disable. Default: true |
| `config` | object | No | Type-specific config (see below) |
| `delivery_channel` | string | For create (except agent_routine) | `telegram` / `discord` / `slack` / `email` / `pull`. Defaults to `pull` for agent routines. |
| `delivery_config` | object | For create (if channel needs credentials) | Channel credentials (see below) |
| `bundle` | string | For create_bundle | `starter` or `full` |
| `type_filter` | string | For list | `agent_routine` / `push_notification` / `all` |
| `message_id` | string | For acknowledge | Message UUID (alternative: use `id`) |
| `response_format` | string | No | "json" or "markdown". Default: "json" |

**Automation Types:**

| Type | Category | Default Schedule | Description |
|------|----------|-----------------|-------------|
| `agent_routine` | Agent | None | AI playbook stored in Wayve. Not server-executed. |
| `morning_brief` | Push | 7:30 daily | Today's activity count and schedule overview |
| `evening_winddown` | Push | 21:00 daily | Day's completion summary |
| `wrap_up_reminder` | Push | Sunday 19:00 | Nudge to do the Wrap Up ritual |
| `fresh_start_reminder` | Push | Monday 8:30 | Nudge to plan the week |
| `mid_week_pulse` | Push | Wednesday 12:30 | Mid-week progress check |
| `friday_check` | Push | Friday 15:00 | Uncompleted activities reminder |
| `frequency_tracker` | Push | 20:00 daily | Off-track pillar frequency alerts |
| `monthly_audit` | Push | 1st of month 11:00 | Monthly review reminder |
| `time_audit_checkin` | Push | Per audit config | Time audit check-in prompt |

**Config structure per type:**
- `agent_routine`: `{ description, agent_instructions, skills: string[], pillar_id }`
- `time_audit_checkin`: `{ audit_id }`
- All others: no config needed (templates are built-in)

**Delivery config per channel:**
- `telegram`: `{ bot_token, chat_id }`
- `discord`: `{ webhook_url }`
- `slack`: `{ webhook_url }`
- `email`: `{ email }`
- `pull`: no config needed (messages stored for retrieval)

**Bundles:**
- `starter` (3 automations): morning_brief + wrap_up_reminder + fresh_start_reminder
- `full` (8 automations): starter + evening_winddown + mid_week_pulse + friday_check + frequency_tracker + monthly_audit
