# Synapse Wiki

智能知识库管理系统 — 让知识随时间复利增长。

## 核心理念

知识应该越用越聪明，而非越积越多乱。

| | 传统笔记 | Synapse Wiki |
|--|---------|--------------|
| **机制** | 手动整理 + 检索 | 自动编译原始资料成知识网络 |
| **知识形式** | 孤立文档 | 结构化、交叉链接的知识页面 |
| **随时间变化** | 越积越多，难以查找 | 越用越聪明，自动关联 |
| **维护者** | 人类 | AI（编译、交叉引用、归档） |

## 安装方式

### 方式 1：使用安装脚本（推荐）

```bash
cd ~/.claude/skills/synapse-wiki
./install.sh
```

### 方式 2：手动复制

```bash
cp -r synapse-wiki ~/.claude/skills/
```

### 方式 3：使用 OpenClaw

```bash
claude skill install synapse-wiki.skill
```

## 依赖要求

- Python 3.x ✓

## 快速开始

```bash
# 1. 初始化新知识库
/synapse-wiki init ~/my-wiki "AI 学习知识库"

# 2. 摄取资料
/synapse-wiki ingest ~/my-wiki raw/articles/article.md

# 3. 查询知识
/synapse-wiki query ~/my-wiki "LLM Wiki 的核心思想"

# 4. 健康检查
/synapse-wiki lint ~/my-wiki
```

## 三层架构

```
<wiki-root>/
├── CLAUDE.md              ← Schema 定义
├── log.md                 ← 时间线日志
├── raw/                   ← 原始资料层（LLM 只读）
│   ├── articles/          ← 网页文章
│   ├── papers/            ← 学术论文
│   └── notes/             ← 个人笔记
└── wiki/                  ← Wiki 知识层（LLM 编写）
    ├── index.md           ← 主目录
    ├── concepts/          ← 概念页面
    ├── entities/          ← 实体页面
    └── summaries/         ← 摘要页面
```

## 配置

编辑 `~/.claude/skills/synapse-wiki/config.json`（如有需要）。

## 快速开始

```bash
# 1. 初始化新知识库
/synapse-wiki init ~/my-wiki "AI 学习知识库"

# 2. 摄取资料
/synapse-wiki ingest ~/my-wiki raw/articles/article.md

# 3. 查询知识
/synapse-wiki query ~/my-wiki "LLM Wiki 的核心思想"

# 4. 健康检查
/synapse-wiki lint ~/my-wiki
```

## 基线测试

```bash
cd ~/.claude/skills/synapse-wiki/synapse-wiki
python3 tests/baseline_test.py
```

**测试结果**: 4/4 通过 (init, ingest, lint, query)

## 发布清单

- [x] SKILL.md 完成（OpenClaw 格式）
- [x] .skillhub.json 配置（platform: openclaw）
- [x] scripts/ 目录完整
- [x] commands/ 目录完整
- [x] 基线测试通过（4/4）
- [x] 安装脚本（install.sh）
- [x] 发布文档（CHANGELOG.md, RELEASE.md, README.md）

## 版本历史

- v1.0.0 (2026-04-08) — 初始公开发布版本

## 许可证

MIT License

详见 [CHANGELOG.md](CHANGELOG.md) 和 [RELEASE.md](RELEASE.md)。

## 许可证

MIT License
