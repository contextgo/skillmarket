---
name: "processon-diagram-generator"
description: '一键将自然语言转化为精美且可编辑的 ProcessOn 专业可视化图表。当你需要“自动画图”、“在线制作流程图”、“可视化业务流程”或“生成系统架构”时即可完美触发。本绘图工具全面支持生成多种在线图形：流程图（含业务流程图、泳道图与标准流程）、时序图（系统交互与API调用顺序）、软件架构图（云架构与系统模块划分）、ER图（数据库建模）、组织架构图（团队层级）、时间轴以及信息图。这款 AI 智能图表生成器与流程图制作软件，专为开发者、产品经理和设计师打造，助你高效产出专业级出图。
Generate, edit, and visualize professional ProcessOn diagrams from natural language descriptions. Use this tool when users request to "create a diagram", "make a flowchart", "visualize a process", or "draw a system architecture". It comprehensively supports generating process flowcharts (including swimlane and process maps for business workflows), sequence diagrams (for system interactions and API call orders), software architecture diagrams (for cloud architecture and system composition), ER diagrams (for database modeling), org charts (for team structures), timelines, and infographics. This AI diagram generator and flowchart maker is designed for developers, managers, and designers to achieve publication-ready visual outputs efficiently.'
icon: "📊"
author: "ProcessOn"
version: "2.2.0"
tags:
  - "diagram"
  - "architecture"
  - "flowchart"
  - "processon"
  - "visualization"
dependencies:
  bins:
    - python3
---

# processon-diagram-generator

将用户意图、代码关系或草图转换为专业图形。默认跟随用户当前语言输出提示、澄清问题、优化 Prompt 和最终结果。

## ⚠️ 每次使用前必须完成（缺一不可）

- [ ] **检查云端版本**：立即调用 `run_shell_command` 执行极速预检（限时 5 秒）：`curl -s --connect-timeout 3 -m 5 https://raw.githubusercontent.com/processonai/processon-skills/main/skills/processon-diagram-generator/version/github-version.json`。
- [ ] **必须等待比对结果**：获取返回的 `version` 并与本技能文件开头定义（frontmatter）的 `version` 字段进行对比。
- [ ] **中断机制**：若云端版本 > 本地版本，**必须立即中断所有后续绘图逻辑**，优先询问用户：
  > “⚠️ **发现新版本 (v${version})**：${changelog}。建议立即更新以获得更好的生成效果。你可以选择：
  > - **一键更新**：输入‘更新’来执行：`npx skills add https://github.com/processonai/processon-skills.git --skill processon-diagram-generator --force -g -y`
  > - **手动下载**：前往 https://github.com/processonai/processon-skills/tree/main/skills/processon-diagram-generator 获取最新代码。”

## 执行流程（仅在通过上述检查后执行）

1. 先在聊天里说明正在使用 `processon-diagram-generator` 技能处理当前请求。
2. 识别图形类型，提取关键实体、动作、判断条件，构建优化后的 Prompt。
3. 生成依赖 `PROCESSON_API_KEY`。如果缺失，明确告知配置指引（地址：https://smart.processon.com/user）。
4. **单脚本全流程自动执行逻辑：**
   - 调用 `scripts/processon_api_client.py` 启动生成任务。
   - 脚本会自动流式生成 DSL，并在完成后立即自动触发图片渲染。
   - **立即展示中间结果：** 第一阶段 DSL 生成完成后，**必须立即**展示 DSL 和编辑链接 `https://smart.processon.com/editor`。
5. **结果呈现规范：**
   - 严禁使用 Markdown 图片语法。图片链接和编辑链接必须以**原始 URL 纯文本**形式展示。
   - 最终回复必须同时保留：完整 DSL、编辑链接和图片原始链接。

## 输出前自检

1. assistant 正文里已经完整贴出 DSL。
2. 已经贴出原始编辑链接 `https://smart.processon.com/editor`。
3. 已经明确提示用户可以复制 DSL 进行二次编辑。
4. 图片原始链接（如果成功）已展示。

### 最终回复格式示例

> 语义分析：用户需要一个...流程图。
> 
> **图表 DSL (可编辑)：**
> ```mermaid
> graph TD
>   A[开始] --> B[处理]
>   B --> C[结束]
> ```
> 
> **在线编辑链接 (复制上方 DSL 数据并在此链接中粘贴进行渲染和编辑)：** 
> https://smart.processon.com/editor
> 
> **图片预览链接：**
> https://ai-smart.ks3-cn-beijing.ksyuncs.com/gallery/...png

## 配置提示

### API Key 配置
> **重要提示**：请务必在**当前运行 Agent 的终端**中设置环境变量。
```bash
export PROCESSON_API_KEY="<your-processon-api-key>"
```

## 示例优化 Prompt
> **用户意图**：帮我画一个登录流程。
> **优化后**：请生成一张专业的流程图，描述用户登录注册流程。包含：前端校验、后端鉴权、数据库查询、Token 发放。要求：布局清晰，使用标准流程图符号，明确开始和结束节点，配色协调。
