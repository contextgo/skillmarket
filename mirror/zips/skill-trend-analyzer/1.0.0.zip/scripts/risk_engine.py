#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - Core Risk Analysis Engine
企业所得税汇算风险扫描与分析引擎

Usage:
    python risk_engine.py --profile '{"industry":"制造业","region":"江苏","taxpayer_type":"一般纳税人"}'
    python risk_engine.py --profile profile.json --output report
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.2.2
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.

import sys
import io
import re
import json
import os
import argparse
from datetime import datetime
from pathlib import Path

# Windows GBK console compatibility - set once at entry point
# All sub-modules check sys._tax_risk_utf8_set to avoid re-wrapping
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
REFERENCES_DIR = SKILL_DIR / "references"
ASSETS_DIR = SKILL_DIR / "assets"

# Integrity check on startup
try:
    sys.path.insert(0, str(SKILL_DIR.parent))
    from integrity_guard import IntegrityGuard
    _guard = IntegrityGuard(str(SKILL_DIR))
    _integrity_ok, _msg = _guard.startup_check_with_message()
    if not _integrity_ok:
        print(f"[ERROR] {_msg}", flush=True)
        sys.exit(1)
except ImportError:
    pass  # integrity_guard not available, skip check


def log(msg: str):
    """Timestamped log, remove emoji for GBK compatibility"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean_msg = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{timestamp}] {clean_msg}", flush=True)


def load_risk_models() -> dict:
    """Load risk model knowledge base"""
    model_path = REFERENCES_DIR / "risk_models.json"
    if model_path.exists():
        with open(model_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    log(f"[WARNING] Risk models file not found: {model_path}")
    return {}


def load_learn_data() -> dict:
    """Load self-learning data"""
    learn_path = ASSETS_DIR / "learn_data.json"
    if learn_path.exists():
        with open(learn_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "version": "1.0.0",
        "last_updated": datetime.now().strftime("%Y-%m-%d"),
        "interaction_count": 0,
        "success_records": [],
        "failure_records": [],
        "discoveries": [],
        "policy_updates": [],
        "risk_model_evolution": [],
        "user_feedback_patterns": []
    }


def save_learn_data(data: dict):
    """Save self-learning data"""
    assets_dir = SKILL_DIR / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    learn_path = assets_dir / "learn_data.json"
    data["last_updated"] = datetime.now().strftime("%Y-%m-%d")
    with open(learn_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def calculate_risk_score(user_profile: dict, risk_models: dict, learn_data: dict) -> dict:
    """
    Core risk scoring engine
    
    Scoring formula:
    risk_score = SUM(risk_weight * hit_degree * time_factor)
    
    Returns:
        dict with total_score, risk_level, hit_items, etc.
    """
    industry = user_profile.get("basic_info", {}).get("industry", "")
    region = user_profile.get("basic_info", {}).get("region", "")
    taxpayer_type = user_profile.get("basic_info", {}).get("taxpayer_type", "")
    revenue_range = user_profile.get("basic_info", {}).get("revenue_range", "")
    
    tax_status = user_profile.get("tax_status", {})
    has_e_tax_reminder = tax_status.get("e_tax_reminder", False)
    has_tax_inquiry = tax_status.get("tax_inquiry", False)
    has_tax_check = tax_status.get("tax_check", False)
    has_tax_assessment = tax_status.get("tax_assessment", False)
    has_tax_audit = tax_status.get("tax_audit", False)
    
    # Time factor: 1.0 baseline, higher for recent policy changes
    time_factor = 1.0
    current_year = datetime.now().year
    
    # Status escalation factor
    status_factor = 1.0
    if has_tax_audit:
        status_factor = 1.5
    elif has_tax_assessment:
        status_factor = 1.3
    elif has_tax_check:
        status_factor = 1.2
    elif has_tax_inquiry:
        status_factor = 1.1
    elif has_e_tax_reminder:
        status_factor = 1.05
    
    # Industry risk profile
    industry_profiles = risk_models.get("industry_risk_profiles", {})
    region_profiles = risk_models.get("region_risk_profiles", {})
    
    # Matched industry key
    matched_industry = None
    for key in industry_profiles:
        if key in industry or industry in key:
            matched_industry = key
            break
    
    # Matched region key
    matched_region = None
    for key in region_profiles:
        if key in region or region in key:
            matched_region = key
            break
    
    # Scan all risk domains
    hit_items = []
    total_weighted_score = 0
    max_possible_score = 0
    
    for domain in risk_models.get("risk_domains", []):
        domain_weight = domain.get("weight", 0.5)
        
        for sub_risk in domain.get("sub_risks", []):
            risk_id = sub_risk.get("id", "")
            risk_name = sub_risk.get("name", "")
            risk_level = sub_risk.get("risk_level", "low")
            risk_weight = domain_weight
            
            # Calculate hit degree (0-1.0)
            hit_degree = 0.0
            hit_reasons = []
            
            # Industry match
            applicable_industries = sub_risk.get("applicable_industries", [])
            if "all" in applicable_industries or industry in applicable_industries:
                hit_degree += 0.3
                hit_reasons.append(f"行业匹配: {industry}")
            
            # Industry key risk
            if matched_industry and risk_id in industry_profiles.get(matched_industry, {}).get("key_risks", []):
                hit_degree += 0.25
                hit_reasons.append(f"行业重点风险")
            
            # Taxpayer type match
            applicable_types = sub_risk.get("applicable_taxpayer_types", [])
            if taxpayer_type in applicable_types:
                hit_degree += 0.15
                hit_reasons.append(f"纳税人类型匹配")
            
            # Region focus
            if matched_region:
                region_focus = region_profiles.get(matched_region, {}).get("focus_areas", [])
                risk_keywords = risk_name + sub_risk.get("description", "")
                for focus in region_focus:
                    if focus in risk_keywords:
                        hit_degree += 0.15
                        hit_reasons.append(f"地域重点: {focus}")
                        break
            
            # Tax status escalation
            if has_tax_audit or has_tax_assessment:
                hit_degree += 0.15
                hit_reasons.append("稽查/评估期间风险放大")
            elif has_tax_inquiry or has_tax_check:
                hit_degree += 0.1
                hit_reasons.append("问询/核查期间风险放大")
            
            # Cap hit_degree at 1.0
            hit_degree = min(hit_degree, 1.0)
            
            # Calculate risk score
            risk_score = risk_weight * hit_degree * time_factor * status_factor
            max_possible_score += risk_weight * 1.0 * 1.5 * 1.5  # max scenario
            
            # Only include if hit_degree > 0
            if hit_degree > 0.05:
                hit_items.append({
                    "risk_id": risk_id,
                    "risk_domain": domain.get("name", ""),
                    "risk_name": risk_name,
                    "risk_level": risk_level,
                    "domain_weight": risk_weight,
                    "hit_degree": round(hit_degree, 3),
                    "time_factor": time_factor,
                    "status_factor": status_factor,
                    "risk_score": round(risk_score, 3),
                    "hit_reasons": hit_reasons,
                    "policy_basis": sub_risk.get("policy_basis", []),
                    "risk_indicators": sub_risk.get("risk_indicators", []),
                    "scan_logic": sub_risk.get("scan_logic", ""),
                    "response_strategy": sub_risk.get("response_strategy", "")
                })
                total_weighted_score += risk_score
    
    # Normalize to 0-100 scale
    if max_possible_score > 0:
        normalized_score = round((total_weighted_score / max_possible_score) * 100, 1)
    else:
        normalized_score = 0
    
    normalized_score = min(normalized_score, 100)
    
    # Determine risk level
    if normalized_score >= 80:
        risk_level = "extreme_high"
        risk_label = "[EXTREME] 极高风险"
    elif normalized_score >= 60:
        risk_level = "high"
        risk_label = "[HIGH] 高风险"
    elif normalized_score >= 40:
        risk_level = "medium"
        risk_label = "[MEDIUM] 中风险"
    elif normalized_score >= 20:
        risk_level = "low"
        risk_label = "[LOW] 低风险"
    else:
        risk_level = "controllable"
        risk_label = "[SAFE] 风险可控"
    
    # Count by severity
    high_count = len([i for i in hit_items if i["risk_level"] == "high"])
    medium_count = len([i for i in hit_items if i["risk_level"] == "medium"])
    low_count = len([i for i in hit_items if i["risk_level"] == "low"])
    
    # Sort by score descending
    hit_items.sort(key=lambda x: x["risk_score"], reverse=True)
    
    # Industry/region specific notes
    industry_notes = ""
    if matched_industry:
        profile = industry_profiles.get(matched_industry, {})
        industry_notes = profile.get("special_attention", "")
    
    region_notes = ""
    if matched_region:
        profile = region_profiles.get(matched_region, {})
        region_notes = profile.get("notes", "")
    
    # Priority actions
    priority_items = []
    for i, item in enumerate(hit_items[:5]):
        urgency = "7天" if item["risk_score"] >= 0.3 else "30天" if item["risk_score"] >= 0.15 else "90天"
        priority_items.append({
            "rank": i + 1,
            "risk_name": item["risk_name"],
            "risk_score": item["risk_score"],
            "urgency": urgency
        })
    
    result = {
        "scan_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "user_profile_summary": {
            "industry": industry,
            "region": region,
            "taxpayer_type": taxpayer_type,
            "revenue_range": revenue_range,
            "tax_status": {
                "e_tax_reminder": has_e_tax_reminder,
                "tax_inquiry": has_tax_inquiry,
                "tax_check": has_tax_check,
                "tax_assessment": has_tax_assessment,
                "tax_audit": has_tax_audit
            }
        },
        "total_score": normalized_score,
        "risk_level": risk_level,
        "risk_label": risk_label,
        "hit_count": len(hit_items),
        "high_count": high_count,
        "medium_count": medium_count,
        "low_count": low_count,
        "hit_items": hit_items,
        "industry_notes": industry_notes,
        "region_notes": region_notes,
        "priority_items": priority_items
    }
    
    return result


def generate_report(result: dict) -> str:
    """Generate readable risk scan report"""
    lines = []
    lines.append("=" * 60)
    lines.append("[TaxRiskGuard] Qi Ye Suo De Shui Hui Suan Feng Xian Sao Miao Bao Gao")
    lines.append("=" * 60)
    lines.append("")
    
    # Summary
    lines.append("[SCAN SUMMARY]")
    lines.append(f"  Scan Time: {result['scan_time']}")
    profile = result['user_profile_summary']
    lines.append(f"  Industry: {profile['industry']}")
    lines.append(f"  Region: {profile['region']}")
    lines.append(f"  Taxpayer Type: {profile['taxpayer_type']}")
    lines.append(f"  Revenue Range: {profile['revenue_range']}")
    lines.append("")
    lines.append(f"  Total Score: {result['total_score']}/100")
    lines.append(f"  Risk Level: {result['risk_label']}")
    lines.append(f"  Hit Items: {result['hit_count']} (High:{result['high_count']} / Medium:{result['medium_count']} / Low:{result['low_count']})")
    lines.append("")
    
    # Hit items detail
    if result['hit_items']:
        lines.append("[RISK DETAILS - Sorted by Severity]")
        lines.append("-" * 60)
        for i, item in enumerate(result['hit_items']):
            level_icon = "[HIGH]" if item['risk_level'] == 'high' else "[MED]" if item['risk_level'] == 'medium' else "[LOW]"
            lines.append(f"  {i+1}. {level_icon} {item['risk_name']} | Score: {item['risk_score']:.3f}")
            lines.append(f"     Domain: {item['risk_domain']} | Hit: {item['hit_degree']:.1%}")
            for reason in item['hit_reasons']:
                lines.append(f"     - {reason}")
            if item['policy_basis']:
                lines.append(f"     Policy: {item['policy_basis'][0][:60]}...")
            lines.append("")
    
    # Industry/Region notes
    if result['industry_notes']:
        lines.append(f"[INDUSTRY NOTE] {result['industry_notes']}")
    if result['region_notes']:
        lines.append(f"[REGION NOTE] {result['region_notes']}")
    lines.append("")
    
    # Priority actions
    if result['priority_items']:
        lines.append("[PRIORITY ACTIONS]")
        for p in result['priority_items']:
            lines.append(f"  {p['rank']}. {p['risk_name']} - Handle within {p['urgency']}")
    
    lines.append("")
    lines.append("=" * 60)
    lines.append("Rose: Questions/Suggestions? Email QQ:1817694478 Group:972156177")
    lines.append("=" * 60)
    
    return "\n".join(lines)


def record_interaction(learn_data: dict, profile: dict, result: dict, feedback: str = ""):
    """Record interaction for self-learning"""
    record = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "industry": profile.get("basic_info", {}).get("industry", ""),
        "region": profile.get("basic_info", {}).get("region", ""),
        "risk_score": result["total_score"],
        "risk_level": result["risk_level"],
        "hit_count": result["hit_count"],
        "top_risk": result["hit_items"][0]["risk_name"] if result["hit_items"] else "",
        "feedback": feedback
    }
    
    if feedback and ("success" in feedback.lower() or "resolved" in feedback.lower()):
        learn_data["success_records"].append(record)
    elif feedback and ("fail" in feedback.lower() or "not resolved" in feedback.lower()):
        learn_data["failure_records"].append(record)
    
    # Keep only last 30 records
    for key in ["success_records", "failure_records"]:
        if len(learn_data.get(key, [])) > 30:
            learn_data[key] = learn_data[key][-30:]
    
    learn_data["interaction_count"] = learn_data.get("interaction_count", 0) + 1
    save_learn_data(learn_data)


def _init_auth_and_prefs():
    """初始化授权管理器和用户偏好系统
    
    Returns:
        (AuthManager instance, UserPreference instance)
    """
    auth_mgr = None
    pref_mgr = None
    
    try:
        sys.path.insert(0, str(SCRIPT_DIR))
        from auth_manager import AuthManager
        auth_mgr = AuthManager()
    except ImportError:
        log("[WARNING] auth_manager module not available")
    
    try:
        sys.path.insert(0, str(SCRIPT_DIR))
        from user_preference import UserPreference
        pref_mgr = UserPreference()
    except ImportError:
        log("[WARNING] user_preference module not available")
    
    return auth_mgr, pref_mgr


def _show_achievement_after_scan(result: dict, auth_mgr=None, pref_mgr=None):
    """扫描完成后展示成果和收集反馈
    
    Args:
        result: 风险扫描结果
        auth_mgr: 授权管理器实例
        pref_mgr: 用户偏好实例
    """
    achievement_report = None
    
    # 成果展示（根据用户偏好决定是否展示）
    show_achievement = True
    if pref_mgr:
        prefs = pref_mgr.preferences
        show_achievement = prefs.get("show_achievement_on_update", True)
    
    if show_achievement:
        try:
            sys.path.insert(0, str(SCRIPT_DIR))
            from achievement_display import AchievementDisplay
            display = AchievementDisplay()
            
            # 构建统计数据并加载
            stats = {
                "scan_count": result.get("hit_count", 0),
                "total_items_learned": result.get("hit_count", 0),
                "risk_score": result.get("total_score", 0),
                "risk_level": result.get("risk_level", "unknown")
            }
            
            # 从授权管理器获取更多统计
            if auth_mgr:
                usage = auth_mgr.config.get("usage_stats", {})
                stats["total_scans"] = usage.get("total_scans", 1)
                stats["total_queries"] = usage.get("total_queries", 0)
            
            display.load_stats(stats)
            achievement_report = display.generate_mini_report(
                new_items=result.get("hit_count", 0)
            )
            if achievement_report:
                print("\n" + achievement_report)
        except ImportError:
            log("[INFO] achievement_display module not available")
        except Exception as e:
            log(f"[WARNING] Achievement display failed: {e}")
    
    # 反馈收集（根据用户偏好决定是否收集）
    collect_feedback = True
    if pref_mgr:
        collect_feedback = pref_mgr.preferences.get("collect_feedback", True)
    
    if collect_feedback and achievement_report:
        try:
            sys.path.insert(0, str(SCRIPT_DIR))
            from feedback_collector import FeedbackCollector
            collector = FeedbackCollector()
            # 非交互式：记录自动反馈标记（实际评分在CLI交互时才触发）
            collector.record_auto_feedback(
                context="scan",
                batch_id=f"scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                risk_score=result.get("total_score", 0),
                risk_level=result.get("risk_level", "")
            )
        except ImportError:
            log("[INFO] feedback_collector module not available")
        except Exception as e:
            log(f"[WARNING] Feedback collection failed: {e}")
    
    return achievement_report


def main():
    parser = argparse.ArgumentParser(description="TaxRiskGuard Risk Engine")
    parser.add_argument("--profile", type=str, required=True,
                        help="User profile JSON string or path to JSON file")
    parser.add_argument("--output", choices=["report", "json"], default="report",
                        help="Output format: report (text) or json")
    parser.add_argument("--feedback", type=str, default="",
                        help="User feedback for self-learning")
    
    args = parser.parse_args()
    
    # ========== Phase 1: 初始化授权和偏好系统 ==========
    auth_mgr, pref_mgr = _init_auth_and_prefs()
    
    # 记录使用统计（扫描）
    if auth_mgr:
        auth_mgr.record_usage("scan")
    
    # ========== Phase 2: 执行核心风险扫描 ==========
    
    # Load user profile (with path validation)
    if os.path.isfile(args.profile):
        profile_path = Path(args.profile).resolve()
        skill_root = SKILL_DIR.resolve()
        if not str(profile_path).startswith(str(skill_root)):
            log("[ERROR] Profile file path must be within skill directory")
            sys.exit(1)
        with open(args.profile, 'r', encoding='utf-8') as f:
            user_profile = json.load(f)
    else:
        user_profile = json.loads(args.profile)
    
    log("[INFO] Loading risk models...")
    risk_models = load_risk_models()
    
    if not risk_models:
        log("[ERROR] Failed to load risk models")
        sys.exit(1)
    
    log(f"[INFO] Risk models loaded: {len(risk_models.get('risk_domains', []))} domains")
    
    # Load learn data
    learn_data = load_learn_data()
    log(f"[INFO] Learn data loaded: {learn_data.get('interaction_count', 0)} historical interactions")
    
    # Calculate risk
    log("[INFO] Calculating risk scores...")
    result = calculate_risk_score(user_profile, risk_models, learn_data)
    
    # Record interaction
    record_interaction(learn_data, user_profile, result, args.feedback)
    
    # ========== Phase 3: 云端同步（带授权容错） ==========
    
    # Cloud sync: upload local learn data and download updates from other users
    # 授权失败不影响主流程，silent=True表示后台静默同步
    log("[INFO] Triggering cloud sync...")
    cloud_sync_achievement = None
    try:
        sys.path.insert(0, str(SCRIPT_DIR))
        from learn_sync import bidirectional_sync
        sync_result = bidirectional_sync(silent=True)
        if sync_result.get("auth_error"):
            log("[NOTICE] 云同步授权问题，技能继续正常运行")
            # 在报告中添加授权提示
            notice = sync_result.get("notice", "")
            if notice:
                log(f"[NOTICE] {notice}")
                result["cloud_sync_notice"] = notice
        elif sync_result.get("upload", {}).get("success") and sync_result.get("download", {}).get("success"):
            log("[OK] Cloud sync completed successfully")
            # 保存成果报告
            if sync_result.get("merge", {}).get("achievement_report"):
                cloud_sync_achievement = sync_result["merge"]["achievement_report"]
        else:
            log("[WARNING] Cloud sync had issues, will retry next time")
    except Exception as e:
        log(f"[WARNING] Cloud sync failed: {e}")
    
    # ========== Phase 4: 成果展示与反馈收集 ==========
    
    scan_achievement = _show_achievement_after_scan(result, auth_mgr, pref_mgr)
    
    # ========== Phase 5: 智能授权提示（扫描完成后） ==========
    
    if auth_mgr and not auth_mgr.has_valid_key():
        should_prompt, reason = auth_mgr.should_prompt_for_auth("scan")
        if should_prompt:
            # 非阻塞方式：在报告末尾追加授权提示
            auth_tip = f"\n\n{'='*60}\n💡 {reason}\n📧 联系作者获取授权：QQ 1817694478 | Q群 972156177\n{'='*60}"
            result["auth_prompt"] = auth_tip
    
    # ========== Phase 6: 输出结果 ==========
    
    if args.output == "json":
        # JSON输出包含成果报告和授权提示
        if cloud_sync_achievement:
            result["cloud_sync_achievement"] = cloud_sync_achievement
        if scan_achievement:
            result["scan_achievement"] = scan_achievement
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        # 文本报告追加成果展示和授权提示
        report = generate_report(result)
        if cloud_sync_achievement:
            report += "\n\n" + cloud_sync_achievement
        if scan_achievement:
            report += "\n" + scan_achievement
        if result.get("auth_prompt"):
            report += result["auth_prompt"]
        print(report)
    
    log(f"[OK] Scan complete. Score: {result['total_score']}/100, Level: {result['risk_label']}")


if __name__ == "__main__":
    main()
