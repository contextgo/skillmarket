#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 报告生成器 (Report Generator)
定期生成学习成果报告

功能：
1. 周期性数据统计（周/月/季度）
2. PDF报告生成（使用HTML转换）
3. 历史报告管理

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import io
import json
import base64
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from pathlib import Path

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"
REPORTS_DIR = SKILL_DIR / "reports"
LEARN_DATA_PATH = ASSETS_DIR / "learn_data.json"


class ReportGenerator:
    """报告生成器"""
    
    REPORT_TYPES = {
        "weekly": {"name": "周报", "days": 7},
        "monthly": {"name": "月报", "days": 30},
        "quarterly": {"name": "季报", "days": 90}
    }
    
    def __init__(self):
        self.learn_data = self._load_learn_data()
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    
    def _load_learn_data(self) -> Dict[str, Any]:
        """加载学习数据"""
        if LEARN_DATA_PATH.exists():
            try:
                with open(LEARN_DATA_PATH, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {}
    
    def generate_report(self, report_type: str = "weekly", 
                       period_start: Optional[datetime] = None,
                       period_end: Optional[datetime] = None) -> Dict[str, Any]:
        """
        生成报告
        
        Args:
            report_type: 报告类型（weekly/monthly/quarterly）
            period_start: 报告周期开始时间
            period_end: 报告周期结束时间
        
        Returns:
            报告数据
        """
        if period_end is None:
            period_end = datetime.now()
        
        if period_start is None:
            days = self.REPORT_TYPES.get(report_type, {}).get("days", 7)
            period_start = period_end - timedelta(days=days)
        
        # 统计数据
        stats = self._calculate_period_stats(period_start, period_end)
        
        # 构建报告
        report = {
            "report_id": f"{report_type}_{period_end.strftime('%Y%m%d')}",
            "report_type": report_type,
            "report_name": self.REPORT_TYPES.get(report_type, {}).get("name", "报告"),
            "period_start": period_start.isoformat(),
            "period_end": period_end.isoformat(),
            "generated_at": datetime.now().isoformat(),
            "statistics": stats,
            "highlights": self._generate_highlights(stats),
            "suggestions": self._generate_suggestions(stats)
        }
        
        # 保存报告
        self._save_report(report)
        
        return report
    
    def _calculate_period_stats(self, start: datetime, end: datetime) -> Dict[str, Any]:
        """计算周期统计数据"""
        stats = {
            "new_discoveries": 0,
            "new_policies": 0,
            "new_cases": 0,
            "total_syncs": 0,
            "average_rating": 0,
            "feedback_count": 0
        }
        
        # 统计新增内容
        discoveries = self.learn_data.get("discoveries", [])
        for item in discoveries:
            item_date = self._parse_date(item.get("found_date", ""))
            if item_date and start <= item_date <= end:
                stats["new_discoveries"] += 1
        
        policies = self.learn_data.get("policy_updates", [])
        for item in policies:
            item_date = self._parse_date(item.get("effective_date", ""))
            if item_date and start <= item_date <= end:
                stats["new_policies"] += 1
        
        cases = self.learn_data.get("training_cases", [])
        for item in cases:
            item_date = self._parse_date(item.get("learning_date", ""))
            if item_date and start <= item_date <= end:
                stats["new_cases"] += 1
        
        # 累计数据
        stats["total_discoveries"] = len(discoveries)
        stats["total_policies"] = len(policies)
        stats["total_cases"] = len(cases)
        
        return stats
    
    def _parse_date(self, date_str: str) -> Optional[datetime]:
        """解析日期字符串"""
        if not date_str:
            return None
        try:
            return datetime.strptime(date_str[:10], "%Y-%m-%d")
        except:
            return None
    
    def _generate_highlights(self, stats: Dict[str, Any]) -> List[str]:
        """生成亮点"""
        highlights = []
        
        total_new = stats["new_discoveries"] + stats["new_policies"] + stats["new_cases"]
        if total_new > 0:
            highlights.append(f"本周新增 {total_new} 项学习内容")
        
        if stats["new_policies"] > 0:
            highlights.append(f"掌握 {stats['new_policies']} 项最新政策")
        
        if stats["new_cases"] > 0:
            highlights.append(f"学习 {stats['new_cases']} 个实战案例")
        
        if not highlights:
            highlights.append("持续学习中，建议定期同步云端数据")
        
        return highlights
    
    def _generate_suggestions(self, stats: Dict[str, Any]) -> List[str]:
        """生成学习建议"""
        suggestions = []
        
        if stats["total_policies"] < 10:
            suggestions.append("建议关注更多税收政策更新")
        
        if stats["total_cases"] < 5:
            suggestions.append("多进行风险扫描以积累实战经验")
        
        if not suggestions:
            suggestions.append("保持当前学习节奏，继续深入理解风险指标")
        
        return suggestions
    
    def _save_report(self, report: Dict[str, Any]):
        """保存报告到文件"""
        report_path = REPORTS_DIR / f"{report['report_id']}.json"
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
    
    def generate_html_report(self, report: Dict[str, Any]) -> str:
        """
        生成HTML格式报告
        
        Returns:
            HTML字符串
        """
        stats = report.get("statistics", {})
        highlights = report.get("highlights", [])
        suggestions = report.get("suggestions", [])
        
        html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>TaxRiskGuard 学习报告</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
               max-width: 800px; margin: 0 auto; padding: 20px; background: #f5f5f5; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                   color: white; padding: 30px; border-radius: 10px; margin-bottom: 20px; }}
        .header h1 {{ margin: 0; font-size: 28px; }}
        .header .subtitle {{ opacity: 0.9; margin-top: 10px; }}
        .card {{ background: white; padding: 20px; border-radius: 10px; 
                 margin-bottom: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .card h2 {{ color: #333; margin-top: 0; font-size: 18px; 
                    border-bottom: 2px solid #667eea; padding-bottom: 10px; }}
        .stat-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); 
                      gap: 15px; }}
        .stat-item {{ text-align: center; padding: 15px; background: #f8f9fa; 
                      border-radius: 8px; }}
        .stat-value {{ font-size: 32px; font-weight: bold; color: #667eea; }}
        .stat-label {{ color: #666; font-size: 14px; margin-top: 5px; }}
        .highlight {{ background: #e8f5e9; padding: 12px 15px; margin: 8px 0; 
                      border-left: 4px solid #4caf50; border-radius: 4px; }}
        .suggestion {{ background: #fff3e0; padding: 12px 15px; margin: 8px 0; 
                       border-left: 4px solid #ff9800; border-radius: 4px; }}
        .footer {{ text-align: center; color: #999; margin-top: 30px; 
                   padding-top: 20px; border-top: 1px solid #ddd; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>📊 TaxRiskGuard 学习报告</h1>
        <div class="subtitle">{report.get('report_name', '周报')} | 
            {report.get('period_start', '')[:10]} 至 {report.get('period_end', '')[:10]}</div>
    </div>
    
    <div class="card">
        <h2>📈 数据统计</h2>
        <div class="stat-grid">
            <div class="stat-item">
                <div class="stat-value">{stats.get('new_discoveries', 0)}</div>
                <div class="stat-label">新增发现</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">{stats.get('new_policies', 0)}</div>
                <div class="stat-label">新增政策</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">{stats.get('new_cases', 0)}</div>
                <div class="stat-label">新增案例</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">{stats.get('total_discoveries', 0)}</div>
                <div class="stat-label">累计学习</div>
            </div>
        </div>
    </div>
    
    <div class="card">
        <h2>🌟 本周亮点</h2>
        {''.join(f'<div class="highlight">{h}</div>' for h in highlights)}
    </div>
    
    <div class="card">
        <h2>💡 学习建议</h2>
        {''.join(f'<div class="suggestion">{s}</div>' for s in suggestions)}
    </div>
    
    <div class="footer">
        <p>报告生成时间：{report.get('generated_at', '')[:19]}</p>
        <p>TaxRiskGuard - 智能税务风险检测助手</p>
    </div>
</body>
</html>"""
        return html
    
    def save_html_report(self, report: Dict[str, Any]) -> Path:
        """保存HTML报告"""
        html = self.generate_html_report(report)
        html_path = REPORTS_DIR / f"{report['report_id']}.html"
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html)
        return html_path
    
    def list_reports(self) -> List[Dict[str, Any]]:
        """列出所有报告"""
        reports = []
        for report_file in REPORTS_DIR.glob("*.json"):
            try:
                with open(report_file, 'r', encoding='utf-8') as f:
                    report = json.load(f)
                    reports.append({
                        "id": report.get("report_id"),
                        "type": report.get("report_type"),
                        "name": report.get("report_name"),
                        "period": f"{report.get('period_start', '')[:10]} 至 {report.get('period_end', '')[:10]}",
                        "generated": report.get("generated_at", "")[:19],
                        "file": str(report_file)
                    })
            except:
                pass
        return sorted(reports, key=lambda x: x["generated"], reverse=True)
    
    def show_report_summary(self, report: Dict[str, Any]):
        """在CLI中展示报告摘要"""
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append(f"📊 {report.get('report_name', '学习报告')}")
        lines.append("=" * 60)
        
        period = f"{report.get('period_start', '')[:10]} 至 {report.get('period_end', '')[:10]}"
        lines.append(f"\n  统计周期：{period}")
        
        stats = report.get("statistics", {})
        lines.append(f"\n  📈 本期新增：")
        lines.append(f"     关键词发现：{stats.get('new_discoveries', 0)}")
        lines.append(f"     政策更新：{stats.get('new_policies', 0)}")
        lines.append(f"     训练案例：{stats.get('new_cases', 0)}")
        
        lines.append(f"\n  📚 累计学习：")
        lines.append(f"     总计：{stats.get('total_discoveries', 0)} 项")
        
        highlights = report.get("highlights", [])
        if highlights:
            lines.append(f"\n  🌟 本周亮点：")
            for h in highlights:
                lines.append(f"     • {h}")
        
        suggestions = report.get("suggestions", [])
        if suggestions:
            lines.append(f"\n  💡 学习建议：")
            for s in suggestions:
                lines.append(f"     • {s}")
        
        lines.append("=" * 60)
        print("\n".join(lines))


# ============================================================
# CLI入口
# ============================================================

def main():
    """测试入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='报告生成器')
    parser.add_argument('--generate', choices=['weekly', 'monthly', 'quarterly'],
                       help='生成报告')
    parser.add_argument('--list', action='store_true', help='列出历史报告')
    parser.add_argument('--latest', action='store_true', help='显示最新报告')
    
    args = parser.parse_args()
    
    generator = ReportGenerator()
    
    if args.generate:
        report = generator.generate_report(args.generate)
        generator.show_report_summary(report)
        html_path = generator.save_html_report(report)
        print(f"\n  📄 HTML报告已保存：{html_path}")
    elif args.list:
        reports = generator.list_reports()
        print("\n📋 历史报告：")
        for r in reports[:10]:
            print(f"   [{r['type']}] {r['period']} - {r['generated']}")
    elif args.latest:
        reports = generator.list_reports()
        if reports:
            with open(reports[0]["file"], 'r', encoding='utf-8') as f:
                report = json.load(f)
            generator.show_report_summary(report)
        else:
            print("  ℹ️ 暂无报告")
    else:
        # 生成测试周报
        report = generator.generate_report("weekly")
        generator.show_report_summary(report)


if __name__ == "__main__":
    main()
