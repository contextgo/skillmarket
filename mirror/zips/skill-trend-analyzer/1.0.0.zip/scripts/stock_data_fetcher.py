#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - Listed Company Financial Data Fetcher
Auto-fetch public financial reports from listed companies for:
- Real-data demo training
- Self-learning improvement
- Case reference generation

Data Sources:
- Tushare API (free tier, requires token)
- East Money (public web data)
- Sina Finance (public web data)
- CNInfo (official disclosure platform)

Usage:
    python stock_data_fetcher.py --stock 600519 --year 2024 --output result.json
    python stock_data_fetcher.py --industry "制造业" --random --output result.json
    python stock_data_fetcher.py --stock 000001 --report income --year 2024
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.2.2
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.

import sys
import io
import re
import json
import os
import argparse
import random
import time
from datetime import datetime
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from urllib.parse import quote

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
REFERENCES_DIR = SKILL_DIR / "references"


def log(msg: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean_msg = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{timestamp}] {clean_msg}", flush=True)


# ============================================================
# Industry to stock code mapping (seed data)
# ============================================================

INDUSTRY_STOCKS = {
    "制造业": [
        {"code": "600519", "name": "Guizhou Moutai", "ts_code": "600519.SH", "sub": "Food Manufacturing"},
        {"code": "000651", "name": "Gree Electric", "ts_code": "000651.SZ", "sub": "Electrical Equipment"},
        {"code": "600036", "name": "China Merchants Bank", "ts_code": "600036.SH", "sub": "Banking"},
        {"code": "000333", "name": "Midea Group", "ts_code": "000333.SZ", "sub": "Home Appliances"},
    ],
    "信息技术": [
        {"code": "000725", "name": "BOE Technology", "ts_code": "000725.SZ", "sub": "Display Panels"},
        {"code": "002415", "name": "Hikvision", "ts_code": "002415.SZ", "sub": "Security"},
        {"code": "300750", "name": "CATL", "ts_code": "300750.SZ", "sub": "Battery"},
    ],
    "电子商务": [
        {"code": "300059", "name": "East Money", "ts_code": "300059.SZ", "sub": "Internet Finance"},
        {"code": "002024", "name": "Suning", "ts_code": "002024.SZ", "sub": "Retail"},
    ],
    "医药医疗": [
        {"code": "600276", "name": "Jiangsu Hengrui", "ts_code": "600276.SH", "sub": "Pharmaceutical"},
        {"code": "300760", "name": "Mindray Medical", "ts_code": "300760.SZ", "sub": "Medical Devices"},
    ],
    "房地产": [
        {"code": "000002", "name": "Vanke", "ts_code": "000002.SZ", "sub": "Real Estate"},
        {"code": "600048", "name": "Poly Real Estate", "ts_code": "600048.SH", "sub": "Real Estate"},
    ],
    "直播电商": [
        {"code": "300059", "name": "East Money", "ts_code": "300059.SZ", "sub": "Internet"},
    ],
    "零售批发": [
        {"code": "601933", "name": "Yonghui Superstores", "ts_code": "601933.SH", "sub": "Retail"},
    ],
}


# ============================================================
# East Money public data fetcher
# ============================================================

def fetch_stock_info_eastmoney(stock_code: str) -> dict:
    """Fetch basic stock info from East Money public API"""
    result = {"source": "eastmoney", "stock_code": stock_code, "data": None, "error": None}

    # Strip exchange suffix for East Money API (needs pure numeric code)
    pure_code = re.sub(r'\.[SHSZ]+$', '', stock_code)

    # Determine market: 6xx = SH, 0xx/3xx = SZ
    if pure_code.startswith('6'):
        secid = f"1.{pure_code}"
    else:
        secid = f"0.{pure_code}"

    url = f"http://push2.eastmoney.com/api/qt/stock/get?secid={secid}&ut=fa5fd1943c7b386f172d6893dbbd1f0&fields=f57,f58,f59,f43,f44,f45,f46,f47,f48,f50,f51,f52,f55,f57,f58,f116,f117,f162,f163,f164,f167,f168,f169,f170,f171,f173"

    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0", "Referer": "http://quote.eastmoney.com/"})
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        if data.get("data"):
            d = data["data"]
            result["data"] = {
                "code": d.get("f57", ""),
                "name": d.get("f58", ""),
                "price": d.get("f43", 0) / 100 if isinstance(d.get("f43"), (int, float)) and d.get("f43", 0) > 10000 else d.get("f43", 0),
                "total_market_cap": d.get("f116", 0),  # Total market cap
                "circulating_market_cap": d.get("f117", 0),
                "pe_ratio": d.get("f162", 0) / 100 if isinstance(d.get("f162"), (int, float)) and d.get("f162", 0) > 100 else d.get("f162", 0),
                "pb_ratio": d.get("f167", 0) / 100 if isinstance(d.get("f167"), (int, float)) and d.get("f167", 0) > 100 else d.get("f167", 0),
            }
    except Exception as e:
        result["error"] = str(e)

    return result


def fetch_financial_report_eastmoney(stock_code: str, report_type: str = "income", year: int = 2024) -> dict:
    """Fetch financial report data from East Money public API

    report_type: income (income statement), balance (balance sheet), cashflow (cash flow)
    """
    result = {"source": "eastmoney", "stock_code": stock_code, "report_type": report_type, "data": None, "error": None}

    # Strip exchange suffix for East Money API (needs pure numeric code)
    pure_code = re.sub(r'\.[SHSZ]+$', '', stock_code)

    if pure_code.startswith('6'):
        secid = f"1.{pure_code}"
    else:
        secid = f"0.{pure_code}"

    # East Money financial report API
    # RPT_DMSK_FN_INCOME: income statement, RPT_DMSK_FN_BALANCE: balance sheet, RPT_DMSK_FN_CASHFLOW: cash flow
    report_map = {
        "income": "RPT_DMSK_FN_INCOME",
        "balance": "RPT_DMSK_FN_BALANCE",
        "cashflow": "RPT_DMSK_FN_CASHFLOW",
    }
    rpt_name = report_map.get(report_type, "RPT_DMSK_FN_INCOME")

    url = f"http://datacenter-web.eastmoney.com/api/data/v1/get?sortColumns=REPORT_DATE&sortTypes=-1&pageSize=4&pageNumber=1&reportName={rpt_name}&columns=ALL&filter=(SECURITY_CODE%3D%22{pure_code}%22)"

    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0", "Referer": "http://data.eastmoney.com/"})
        with urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        if data.get("result") and data["result"].get("data"):
            items = data["result"]["data"]
            if items:
                # Get the latest report
                latest = items[0]
                result["data"] = {
                    "report_date": latest.get("REPORT_DATE", ""),
                    "report_type_name": latest.get("REPORT_TYPE_NAME", ""),
                    "total_revenue": latest.get("TOTAL_OPERATE_INCOME", 0),
                    "operating_revenue": latest.get("OPERATE_INCOME", 0),
                    "total_profit": latest.get("TOTAL_PROFIT", 0),
                    "net_profit": latest.get("PARENT_NETPROFIT", 0),
                    "operating_cost": latest.get("TOTAL_OPERATE_COST", 0),
                    "rd_expenses": latest.get("RESEARCH_EXPENSE", 0),
                    "selling_expenses": latest.get("SALE_EXPENSE", 0),
                    "admin_expenses": latest.get("MANAGE_EXPENSE", 0),
                    "finance_expenses": latest.get("FINANCE_EXPENSE", 0),
                    "income_tax": latest.get("INCOME_TAX", 0),
                    "entertainment_expense": latest.get("BUSINESS_ENTERTAINMENT", 0),
                    "welfare_expense": latest.get("STAFF_WELFARE", 0),
                    "advertising_expense": latest.get("ADVERTISING_EXPENSE", 0),
                    "depreciation": latest.get("DEPRECIATION", 0),
                    "impairment_loss": latest.get("ASSET_IMPAIRMENT_LOSS", 0),
                }
    except Exception as e:
        result["error"] = str(e)

    return result


# ============================================================
# Simplified financial data extraction for risk analysis
# ============================================================

def extract_risk_indicators_from_report(stock_code: str, report_data: dict) -> dict:
    """Extract risk-relevant indicators from financial report data"""
    indicators = {"stock_code": stock_code, "risk_indicators": [], "financial_summary": {}}

    data = report_data.get("data", {})
    if not data:
        return indicators

    revenue = data.get("operating_revenue", 0) or data.get("total_revenue", 0)
    total_profit = data.get("total_profit", 0)
    net_profit = data.get("net_profit", 0)
    rd_expense = data.get("rd_expenses", 0)
    entertainment = data.get("entertainment_expense", 0)
    selling = data.get("selling_expenses", 0)
    welfare = data.get("welfare_expense", 0)
    advertising = data.get("advertising_expense", 0)
    depreciation = data.get("depreciation", 0)
    impairment = data.get("impairment_loss", 0)
    income_tax = data.get("income_tax", 0)

    indicators["financial_summary"] = {
        "revenue": revenue,
        "total_profit": total_profit,
        "net_profit": net_profit,
        "rd_expense": rd_expense,
        "entertainment": entertainment,
        "selling": selling,
        "welfare": welfare,
        "advertising": advertising,
        "depreciation": depreciation,
        "impairment": impairment,
        "income_tax": income_tax,
    }

    # Risk indicator checks
    if revenue and revenue > 0:
        # Entertainment expense ratio
        if entertainment and entertainment > 0:
            ent_ratio = entertainment / revenue * 100
            if ent_ratio > 0.5:
                indicators["risk_indicators"].append({
                    "type": "entertainment_excess",
                    "description": f"Entertainment/Revenue ratio: {ent_ratio:.2f}% (limit: 0.5%)",
                    "deduction_limit": revenue * 0.005,
                    "actual_expense": entertainment,
                    "potential_adjustment": max(0, entertainment * 0.6 - revenue * 0.005)
                })

        # R&D expense ratio
        if rd_expense and rd_expense > 0:
            rd_ratio = rd_expense / revenue * 100
            indicators["risk_indicators"].append({
                "type": "rd_deduction",
                "description": f"R&D/Revenue ratio: {rd_ratio:.2f}%",
                "rd_expense": rd_expense,
                "potential_deduction": rd_expense * 1.0,  # 100% additional deduction
            })

        # Welfare expense ratio (limit: 14% of salary)
        if welfare and welfare > 0:
            welfare_ratio = welfare / revenue * 100
            indicators["risk_indicators"].append({
                "type": "welfare_expense",
                "description": f"Welfare/Revenue ratio: {welfare_ratio:.2f}%",
                "welfare_expense": welfare,
            })

        # Advertising expense ratio
        if advertising and advertising > 0:
            ad_ratio = advertising / revenue * 100
            if ad_ratio > 15:
                indicators["risk_indicators"].append({
                    "type": "advertising_excess",
                    "description": f"Advertising/Revenue ratio: {ad_ratio:.2f}% (limit: 15% for most industries)",
                    "advertising_expense": advertising,
                    "deduction_limit": revenue * 0.15,
                })

        # Effective tax rate
        if total_profit and total_profit > 0 and income_tax and income_tax > 0:
            effective_rate = income_tax / total_profit * 100
            indicators["risk_indicators"].append({
                "type": "effective_tax_rate",
                "description": f"Effective tax rate: {effective_rate:.2f}% (statutory: 25%)",
                "effective_rate": effective_rate,
            })

    return indicators


# ============================================================
# Random stock selection for demo
# ============================================================

def get_random_stock(industry: str = None) -> dict:
    """Select a random listed company, optionally filtered by industry"""
    if industry and industry in INDUSTRY_STOCKS:
        stocks = INDUSTRY_STOCKS[industry]
    else:
        all_stocks = []
        for ind_stocks in INDUSTRY_STOCKS.values():
            all_stocks.extend(ind_stocks)
        stocks = all_stocks

    return random.choice(stocks)


# ============================================================
# Generate training case from public data
# ============================================================

def generate_training_case(stock_code: str, stock_name: str, report_data: dict,
                           risk_indicators: dict) -> dict:
    """Generate a training case from public listed company data"""
    case = {
        "source": "listed_company_public_data",
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "stock_code": stock_code,
        "stock_name": stock_name,
        "disclaimer": "All data from public disclosures. For training and reference only.",
        "financial_summary": risk_indicators.get("financial_summary", {}),
        "risk_indicators": risk_indicators.get("risk_indicators", []),
        "simulation_note": "This is a simulated risk analysis based on public financial data. "
                          "Actual enterprise risk assessment requires complete internal data.",
    }

    # Add report data context
    data = report_data.get("data", {})
    if data:
        case["report_context"] = {
            "report_date": data.get("report_date", ""),
            "total_revenue": data.get("total_revenue", 0),
            "net_profit": data.get("net_profit", 0),
        }

    return case


# ============================================================
# Save training data for self-learning
# ============================================================

def save_training_data(case: dict) -> str:
    """Save generated training case to learn_data.json"""
    learn_path = SKILL_DIR / "assets" / "learn_data.json"
    if learn_path.exists():
        with open(learn_path, 'r', encoding='utf-8') as f:
            learn = json.load(f)
    else:
        learn = {"version": "1.0.0", "training_cases": []}

    if "training_cases" not in learn:
        learn["training_cases"] = []

    learn["training_cases"].append(case)
    # Keep only last 30 training cases
    learn["training_cases"] = learn["training_cases"][-30:]
    learn["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(learn_path, 'w', encoding='utf-8') as f:
        json.dump(learn, f, ensure_ascii=False, indent=2)

    return str(learn_path)


# ============================================================
# CLI interface
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="TaxRiskGuard Listed Company Data Fetcher")
    parser.add_argument("--stock", default="", help="Stock code (e.g., 600519)")
    parser.add_argument("--industry", default="", help="Industry name for random selection")
    parser.add_argument("--random", action="store_true", help="Select random stock")
    parser.add_argument("--report", default="income", choices=["income", "balance", "cashflow", "all"],
                        help="Financial report type")
    parser.add_argument("--year", type=int, default=0, help="Report year (default: latest)")
    parser.add_argument("--output", default="", help="Output JSON file path")
    parser.add_argument("--save-training", action="store_true", help="Save as training data for self-learning")

    args = parser.parse_args()

    # Determine stock
    if args.random or args.industry:
        stock_info = get_random_stock(args.industry or None)
        stock_code = stock_info["code"]
        stock_name = stock_info["name"]
        log(f"[INFO] Random stock selected: {stock_code} ({stock_name})")
    elif args.stock:
        stock_code = args.stock
        stock_name = ""
    else:
        log("[ERROR] Please specify --stock or --random")
        sys.exit(1)

    result = {
        "fetch_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "stock_code": stock_code,
        "stock_name": stock_name,
        "reports": {},
        "risk_analysis": None,
    }

    # Fetch stock basic info
    log(f"[INFO] Fetching stock info: {stock_code}")
    info_result = fetch_stock_info_eastmoney(stock_code)
    result["stock_info"] = info_result
    if info_result.get("data") and not stock_name:
        result["stock_name"] = info_result["data"].get("name", "")

    # Fetch financial reports
    report_types = ["income", "balance", "cashflow"] if args.report == "all" else [args.report]
    for rpt_type in report_types:
        log(f"[INFO] Fetching {rpt_type} report: {stock_code}")
        report_result = fetch_financial_report_eastmoney(stock_code, rpt_type)
        result["reports"][rpt_type] = report_result
        time.sleep(0.5)  # Rate limit

    # Extract risk indicators from income statement
    income_data = result["reports"].get("income", {})
    if income_data and income_data.get("data"):
        log(f"[INFO] Extracting risk indicators from income statement")
        risk_indicators = extract_risk_indicators_from_report(stock_code, income_data)
        result["risk_analysis"] = risk_indicators
        log(f"[INFO] Found {len(risk_indicators.get('risk_indicators', []))} risk indicators")

    # Output
    output_json = json.dumps(result, ensure_ascii=False, indent=2, default=str)

    if args.output:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(output_json)
        log(f"[OK] Result saved to: {args.output}")
    else:
        # Print summary
        if result.get("risk_analysis"):
            indicators = result["risk_analysis"].get("risk_indicators", [])
            for ind in indicators:
                log(f"[RISK] {ind['type']}: {ind['description']}")

    # Save as training data
    if args.save_training and result.get("risk_analysis"):
        case = generate_training_case(
            stock_code, result.get("stock_name", ""),
            income_data, result["risk_analysis"]
        )
        path = save_training_data(case)
        log(f"[OK] Training case saved to: {path}")

    log("[OK] Data fetch completed")
