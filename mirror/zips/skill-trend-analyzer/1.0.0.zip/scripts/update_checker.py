#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 更新检测器 (Update Checker)
检测云端可更新内容，生成更新摘要和影响评估

功能：
1. 云端数据预览（调用/query预览模式）
2. 更新内容摘要生成
3. 更新影响评估（新增类型/数量）

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import io
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent


class UpdateChecker:
    """更新检测器"""
    
    # 数据类型中文映射
    DATA_TYPE_NAMES = {
        "discoveries": "🔍 关键词发现",
        "policy_updates": "📜 政策更新",
        "training_cases": "📚 训练案例",
        "user_profiles": "👤 用户画像",
        "model_parameters": "⚙️ 模型参数",
        "trigger_words": "🔔 触发词",
        "workflow_tuning": "🛠️ 工作流优化",
        "industry_features": "🏭 行业特征",
        "feedback_patterns": "💬 反馈模式",
        "failure_cases": "❌ 失败案例",
        "time_sensitive": "⏰ 时效提醒"
    }
    
    # 影响级别
    IMPACT_LEVELS = {
        "low": {"icon": "🟢", "desc": "低影响", "threshold": 10},
        "medium": {"icon": "🟡", "desc": "中等影响", "threshold": 30},
        "high": {"icon": "🟠", "desc": "高影响", "threshold": 50},
        "critical": {"icon": "🔴", "desc": "关键更新", "threshold": float('inf')}
    }
    
    def __init__(self, api_client=None):
        self.api_client = api_client
        self._api = None
    
    def _get_api(self):
        """延迟获取API客户端"""
        if self._api is None:
            if self.api_client:
                self._api = self.api_client
            else:
                try:
                    from learn_sync_v2 import LearningAPIClient
                    self._api = LearningAPIClient()
                except ImportError:
                    from learn_sync import LearningAPIClient
                    self._api = LearningAPIClient()
        return self._api
    
    def check_updates(self, api_key: str, local_package: Optional[Dict] = None) -> Dict[str, Any]:
        """
        检查云端更新
        
        Args:
            api_key: 授权key
            local_package: 本地学习包（用于对比）
        
        Returns:
            更新信息字典
        """
        try:
            api = self._get_api()
            # 使用预览模式查询（不消耗配额）
            cloud_data = api.query_cloud_data(api_key, preview=True)
            
            if not cloud_data:
                return {
                    "has_update": False,
                    "message": "暂无云端数据或查询失败",
                    "timestamp": datetime.now().isoformat()
                }
            
            # 计算更新差异
            diff = self._calculate_diff(local_package, cloud_data)
            
            return {
                "has_update": diff["total_new"] > 0,
                "total_new": diff["total_new"],
                "categories": diff["categories"],
                "impact_level": diff["impact_level"],
                "summary": self._generate_summary(diff),
                "details": diff,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "has_update": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def _calculate_diff(self, local: Optional[Dict], cloud: Dict) -> Dict[str, Any]:
        """计算本地与云端的差异"""
        if local is None:
            local = {"collections": {}}
        
        local_collections = local.get("collections", {})
        cloud_collections = cloud.get("collections", {})
        
        diff = {
            "total_new": 0,
            "categories": {},
            "by_type": {}
        }
        
        for data_type, cloud_coll in cloud_collections.items():
            cloud_items = cloud_coll.get("items", [])
            cloud_ids = {item.get("id") for item in cloud_items}
            
            local_items = local_collections.get(data_type, {}).get("items", [])
            local_ids = {item.get("id") for item in local_items}
            
            # 找出新增项
            new_ids = cloud_ids - local_ids
            new_items = [item for item in cloud_items if item.get("id") in new_ids]
            
            if new_items:
                diff["by_type"][data_type] = {
                    "count": len(new_items),
                    "items": new_items[:5],  # 只保留前5个详情
                    "has_more": len(new_items) > 5
                }
                diff["total_new"] += len(new_items)
        
        # 计算影响级别
        diff["impact_level"] = self._calculate_impact(diff)
        diff["categories"] = list(diff["by_type"].keys())
        
        return diff
    
    def _calculate_impact(self, diff: Dict) -> str:
        """计算更新影响级别"""
        total = diff["total_new"]
        
        # 检查是否有重要类型更新
        critical_types = ["policy_updates", "model_parameters"]
        has_critical = any(t in diff["by_type"] for t in critical_types)
        
        if has_critical and total > 0:
            return "critical"
        
        for level, info in self.IMPACT_LEVELS.items():
            if total <= info["threshold"]:
                return level
        
        return "critical"
    
    def _generate_summary(self, diff: Dict) -> str:
        """生成更新摘要"""
        total = diff["total_new"]
        if total == 0:
            return "暂无新更新"
        
        parts = [f"发现 {total} 项新内容："]
        
        for data_type, info in diff["by_type"].items():
            name = self.DATA_TYPE_NAMES.get(data_type, data_type)
            count = info["count"]
            parts.append(f"  {name}: +{count}")
        
        return "\n".join(parts)
    
    def format_update_preview(self, update_info: Dict[str, Any]) -> str:
        """格式化更新预览（用于CLI展示）"""
        lines = []
        
        if not update_info.get("has_update", False):
            lines.append("\n  ℹ️ 暂无可用更新")
            return "\n".join(lines)
        
        impact = update_info.get("impact_level", "low")
        impact_info = self.IMPACT_LEVELS.get(impact, self.IMPACT_LEVELS["low"])
        
        lines.append("\n" + "=" * 60)
        lines.append(f"{impact_info['icon']} 发现云端更新")
        lines.append("=" * 60)
        
        lines.append(f"\n📊 更新概览：")
        lines.append(f"   新增内容：{update_info.get('total_new', 0)} 项")
        lines.append(f"   影响级别：{impact_info['desc']}")
        
        details = update_info.get("details", {})
        by_type = details.get("by_type", {})
        
        if by_type:
            lines.append(f"\n📋 详细内容：")
            for data_type, info in by_type.items():
                name = self.DATA_TYPE_NAMES.get(data_type, data_type)
                lines.append(f"\n   {name}: +{info['count']}")
                
                # 显示部分详情
                for item in info.get("items", [])[:3]:
                    title = item.get("keyword") or item.get("title") or item.get("id", "未知")
                    lines.append(f"      • {title}")
                
                if info.get("has_more"):
                    lines.append(f"      ... 还有 {info['count'] - 3} 项")
        
        lines.append("\n" + "-" * 60)
        lines.append("操作选项：")
        lines.append("   [Y] 立即更新")
        lines.append("   [N] 稍后处理")
        lines.append("   [D] 查看详情")
        lines.append("=" * 60)
        
        return "\n".join(lines)
    
    def prompt_update_decision(self, update_info: Dict[str, Any]) -> str:
        """
        交互式提示用户决定更新操作
        
        Returns:
            用户选择："update" / "skip" / "details"
        """
        print(self.format_update_preview(update_info))
        
        try:
            choice = input("\n请选择 [Y/N/D] (默认: Y): ").strip().upper() or "Y"
            
            if choice == "Y":
                return "update"
            elif choice == "D":
                return "details"
            else:
                return "skip"
                
        except (KeyboardInterrupt, EOFError):
            return "skip"


# ============================================================
# CLI入口
# ============================================================

def main():
    """测试入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='更新检测器')
    parser.add_argument('--check', action='store_true', help='检查更新')
    parser.add_argument('--key', help='API Key')
    
    args = parser.parse_args()
    
    checker = UpdateChecker()
    
    if args.check:
        if not args.key:
            print("❌ 请提供API Key: --key <your_key>")
            return
        
        print("🔍 正在检查云端更新...")
        result = checker.check_updates(args.key)
        
        if result.get("has_update"):
            print(checker.format_update_preview(result))
        else:
            print(f"\n  ℹ️ {result.get('message', '暂无更新')}")
    else:
        # 测试模式
        test_update = {
            "has_update": True,
            "total_new": 15,
            "impact_level": "medium",
            "categories": ["discoveries", "policy_updates"],
            "details": {
                "total_new": 15,
                "impact_level": "medium",
                "by_type": {
                    "discoveries": {
                        "count": 10,
                        "items": [
                            {"id": "d1", "keyword": "研发费用"},
                            {"id": "d2", "keyword": "加计扣除"},
                            {"id": "d3", "keyword": "风险预警"}
                        ],
                        "has_more": True
                    },
                    "policy_updates": {
                        "count": 5,
                        "items": [
                            {"id": "p1", "title": "财税[2026]20号"}
                        ],
                        "has_more": True
                    }
                }
            }
        }
        print(checker.format_update_preview(test_update))


if __name__ == "__main__":
    main()
