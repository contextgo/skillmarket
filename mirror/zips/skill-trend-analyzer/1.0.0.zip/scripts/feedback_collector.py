#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 反馈收集器 (Feedback Collector)
收集用户对更新内容的反馈，用于改进系统

功能：
1. CLI星级评分（1-5星）
2. 文本反馈输入
3. 反馈关联到具体更新批次

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import io
import json
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"
FEEDBACK_PATH = ASSETS_DIR / "feedback_log.json"


class FeedbackCollector:
    """反馈收集器"""
    
    # 评分选项
    RATING_OPTIONS = {
        1: {"emoji": "⭐", "label": "很不满意", "desc": "内容完全没用"},
        2: {"emoji": "⭐⭐", "label": "不满意", "desc": "内容质量较差"},
        3: {"emoji": "⭐⭐⭐", "label": "一般", "desc": "勉强可用"},
        4: {"emoji": "⭐⭐⭐⭐", "label": "满意", "desc": "内容有帮助"},
        5: {"emoji": "⭐⭐⭐⭐⭐", "label": "非常满意", "desc": "内容很有价值"}
    }
    
    # 预设反馈标签
    FEEDBACK_TAGS = {
        "时效性": "内容很及时，正是我需要的",
        "准确性": "内容准确，解决了我的疑问",
        "完整性": "希望内容能更详细一些",
        "实用性": "非常实用，可以直接应用",
        "易懂性": "通俗易懂，很好理解",
        "重复性": "部分内容与已有知识重复"
    }
    
    def __init__(self):
        self.feedback_log = self._load_feedback()
    
    def _load_feedback(self) -> List[Dict[str, Any]]:
        """加载历史反馈"""
        if FEEDBACK_PATH.exists():
            try:
                with open(FEEDBACK_PATH, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return []
    
    def _save_feedback(self):
        """保存反馈记录"""
        ASSETS_DIR.mkdir(parents=True, exist_ok=True)
        with open(FEEDBACK_PATH, 'w', encoding='utf-8') as f:
            json.dump(self.feedback_log, f, ensure_ascii=False, indent=2)
    
    def collect_feedback(self, context: str = "sync", 
                        batch_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        交互式收集反馈
        
        Args:
            context: 反馈场景（sync/update/general）
            batch_id: 关联的更新批次ID
        
        Returns:
            反馈数据（如果用户取消则返回None）
        """
        print("\n" + "=" * 60)
        print("📝 用户反馈")
        print("=" * 60)
        print("\n您的反馈将帮助我们改进知识库质量\n")
        
        # 星级评分
        rating = self._prompt_rating()
        if rating is None:
            print("  已跳过反馈")
            return None
        
        # 文本反馈
        comment = self._prompt_comment()
        
        # 标签
        tags = self._prompt_tags()
        
        # 构建反馈数据
        feedback = {
            "id": f"fb_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "timestamp": datetime.now().isoformat(),
            "context": context,
            "batch_id": batch_id,
            "rating": rating,
            "comment": comment,
            "tags": tags
        }
        
        # 保存
        self.feedback_log.append(feedback)
        self._save_feedback()
        
        # 感谢信息
        print(f"\n  ✅ 感谢您的反馈！")
        print(f"     评分：{self.RATING_OPTIONS[rating]['emoji']} {self.RATING_OPTIONS[rating]['label']}")
        if comment:
            print(f"     评论：{comment[:30]}..." if len(comment) > 30 else f"     评论：{comment}")
        
        return feedback
    
    def _prompt_rating(self) -> Optional[int]:
        """提示用户评分"""
        print("请为本次更新评分：")
        for score, info in self.RATING_OPTIONS.items():
            print(f"   [{score}] {info['emoji']} {info['label']} - {info['desc']}")
        print("   [0] 跳过")
        
        try:
            choice = input("\n请选择 [0-5]: ").strip()
            if choice == "0" or choice == "":
                return None
            rating = int(choice)
            if 1 <= rating <= 5:
                return rating
        except (ValueError, KeyboardInterrupt, EOFError):
            pass
        
        return None
    
    def _prompt_comment(self) -> str:
        """提示用户输入评论"""
        print("\n请输入您的建议或意见（可选，直接回车跳过）：")
        try:
            comment = input("> ").strip()
            return comment
        except (KeyboardInterrupt, EOFError):
            return ""
    
    def _prompt_tags(self) -> List[str]:
        """提示用户选择标签"""
        print("\n请选择适用的标签（多选，用空格分隔，直接回车跳过）：")
        tags_list = list(self.FEEDBACK_TAGS.keys())
        for i, tag in enumerate(tags_list, 1):
            print(f"   [{i}] {tag}: {self.FEEDBACK_TAGS[tag]}")
        
        try:
            choices = input("\n请选择标签编号: ").strip()
            if not choices:
                return []
            
            selected = []
            for c in choices.split():
                try:
                    idx = int(c) - 1
                    if 0 <= idx < len(tags_list):
                        selected.append(tags_list[idx])
                except ValueError:
                    pass
            return selected
        except (KeyboardInterrupt, EOFError):
            return []
    
    def record_auto_feedback(self, context: str = "scan",
                            batch_id: Optional[str] = None,
                            risk_score: float = 0,
                            risk_level: str = "") -> Dict[str, Any]:
        """
        自动记录非交互式反馈标记（扫描/同步完成时自动调用）
        
        Args:
            context: 场景（scan/sync/update）
            batch_id: 批次ID
            risk_score: 风险分数
            risk_level: 风险等级
        """
        feedback = {
            "id": f"auto_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "timestamp": datetime.now().isoformat(),
            "context": context,
            "batch_id": batch_id,
            "rating": 0,  # 待用户评分
            "comment": "",
            "tags": [],
            "auto_metadata": {
                "risk_score": risk_score,
                "risk_level": risk_level,
                "type": "auto_record"
            }
        }
        
        self.feedback_log.append(feedback)
        self._save_feedback()
        
        return feedback
    
    def quick_feedback(self, rating: int, comment: str = "") -> Dict[str, Any]:
        """
        快速记录反馈（非交互式）
        
        Args:
            rating: 评分（1-5）
            comment: 评论
        """
        if rating < 1 or rating > 5:
            rating = 3
        
        feedback = {
            "id": f"fb_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "timestamp": datetime.now().isoformat(),
            "context": "quick",
            "rating": rating,
            "comment": comment,
            "tags": []
        }
        
        self.feedback_log.append(feedback)
        self._save_feedback()
        
        return feedback
    
    def get_feedback_stats(self) -> Dict[str, Any]:
        """获取反馈统计"""
        if not self.feedback_log:
            return {
                "total_count": 0,
                "average_rating": 0,
                "rating_distribution": {i: 0 for i in range(1, 6)}
            }
        
        ratings = [fb["rating"] for fb in self.feedback_log]
        distribution = {i: ratings.count(i) for i in range(1, 6)}
        
        return {
            "total_count": len(self.feedback_log),
            "average_rating": round(sum(ratings) / len(ratings), 2),
            "rating_distribution": distribution
        }
    
    def show_feedback_summary(self):
        """显示反馈汇总"""
        stats = self.get_feedback_stats()
        
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("📊 用户反馈汇总")
        lines.append("=" * 60)
        
        lines.append(f"\n  总反馈数：{stats['total_count']}")
        if stats['total_count'] > 0:
            lines.append(f"  平均评分：{stats['average_rating']:.1f} ⭐")
            
            lines.append(f"\n  评分分布：")
            for rating, count in sorted(stats['rating_distribution'].items(), reverse=True):
                bar = "█" * count + "░" * (10 - min(count, 10))
                emoji = self.RATING_OPTIONS[rating]['emoji']
                lines.append(f"    {emoji} [{bar}] {count}")
        
        # 最近反馈
        if self.feedback_log:
            lines.append(f"\n  最近反馈：")
            for fb in self.feedback_log[-3:]:
                rating = fb["rating"]
                emoji = self.RATING_OPTIONS[rating]['emoji']
                date = fb["timestamp"][:10]
                comment = fb.get("comment", "")[:20]
                lines.append(f"    {date} {emoji} {comment}...")
        
        lines.append("=" * 60)
        print("\n".join(lines))


# ============================================================
# CLI入口
# ============================================================

def main():
    """测试入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='反馈收集器')
    parser.add_argument('--collect', action='store_true', help='收集反馈')
    parser.add_argument('--summary', action='store_true', help='显示反馈汇总')
    parser.add_argument('--quick', type=int, help='快速记录评分')
    parser.add_argument('--comment', help='快速记录评论')
    
    args = parser.parse_args()
    
    collector = FeedbackCollector()
    
    if args.collect:
        feedback = collector.collect_feedback("test", "batch_001")
        if feedback:
            print(f"\n反馈已记录：{feedback['id']}")
    elif args.summary:
        collector.show_feedback_summary()
    elif args.quick:
        feedback = collector.quick_feedback(args.quick, args.comment or "")
        print(f"✅ 快速反馈已记录：{args.quick}星")
    else:
        collector.show_feedback_summary()


if __name__ == "__main__":
    main()
