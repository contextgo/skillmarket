#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 统一自学习数据同步引擎 v2.0
整合 Schema v2.0 + 聚合引擎 + 应用引擎

特性：
1. 统一数据Schema - 支持11种数据类型
2. 增量打包 - 仅同步变更数据
3. 智能聚合 - 云端去重+冲突解决
4. 本地应用 - 按类型路由到对应模块
5. 向后兼容 - 支持v1数据迁移

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import io
import re
import json
import os
import hashlib
import time
import base64
import argparse
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"
DATA_DIR = SKILL_DIR / "data"
REFERENCES_DIR = SKILL_DIR / "references"

# 导入新模块
try:
    from learn_schema import LearningPackage, DataType, validate_package, migrate_v1_to_v2
    from learn_aggregator import AggregationEngine, SmartMerger
    from learn_applier import LocalApplier
    SCHEMA_V2_AVAILABLE = True
except ImportError as e:
    SCHEMA_V2_AVAILABLE = False
    print(f"[WARNING] Schema v2模块导入失败: {e}")

# ============================================================
# 配置 - API Key混淆存储
# ============================================================
_OBFUSCATED_API_KEY = "QdI7X4yy/Ie432lRYgPSX5YHw7m56HsPTySAew=="
_OBFUSCATED_API_BASE = "FSkRDx8fDklMT0lRXVhXXR0eRklITUtGR0pJXVtOExwZTEVLSE1LRkdKSV1bTkxL"
SKILL_NAME = "tax-risk-guard"


def log(msg: str, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{ts}] [{level}] {clean}", flush=True)


def derive_key() -> bytes:
    """派生密钥"""
    return hashlib.sha256(b"TaxRiskGuard_Skill_Learning_Sync_2026").digest()


def _deobfuscate_string(obfuscated: str) -> str:
    """解密混淆字符串"""
    key = derive_key()
    try:
        xored = base64.b64decode(obfuscated)
        key_stream = key
        while len(key_stream) < len(xored):
            key_stream += hashlib.sha256(key_stream[-32:]).digest()
        plain_bytes = bytes(a ^ b for a, b in zip(xored, key_stream[:len(xored)]))
        return plain_bytes.decode('utf-8')
    except Exception as e:
        log(f"解密失败: {e}", "ERROR")
        return ""


def get_api_key() -> str:
    """获取解密后的API Key"""
    key = _deobfuscate_string(_OBFUSCATED_API_KEY)
    if not key:
        return "sk-stustar-test-key"
    return key


def get_api_base() -> str:
    """获取解密后的API基础URL"""
    base = _deobfuscate_string(_OBFUSCATED_API_BASE)
    if not base:
        return "https://gpt.cntaxs.com/stustar-api/api/skill/learning"
    return base


# ============================================================
# 数据脱敏
# ============================================================
def mask_uscc(uscc: str) -> str:
    """USCC脱敏"""
    if not uscc or len(uscc) < 10:
        return "***"
    return uscc[:6] + "********" + uscc[-4:]


def desensitize_data(data: dict) -> dict:
    """递归脱敏敏感字段"""
    safe = json.loads(json.dumps(data))
    
    def _mask(obj):
        if isinstance(obj, dict):
            sensitive_keys = {
                "uscc": mask_uscc,
                "tax_number": lambda x: "***MASKED***" if x else "",
                "credit_code": mask_uscc,
                "id_card": lambda x: x[:3] + "***********" + x[-4:] if x and len(x) > 7 else "***",
                "phone": lambda x: x[:3] + "****" + x[-4:] if x and len(x) > 7 else "***",
                "email": lambda x: x[:2] + "***@" + x.split("@")[-1] if x and "@" in x else "***",
            }
            for key in sensitive_keys:
                if key in obj and obj[key]:
                    obj[key] = sensitive_keys[key](str(obj[key]))
            
            for v in obj.values():
                if isinstance(v, dict):
                    _mask(v)
                elif isinstance(v, list):
                    for item in v:
                        if isinstance(item, dict):
                            _mask(item)
        return obj
    
    return _mask(safe)


# ============================================================
# v2.0 数据打包器
# ============================================================
class LearningPackager:
    """学习数据打包器 - 将本地数据打包为统一Schema"""
    
    def __init__(self):
        self.learn_data = self._load_learn_data()
    
    def _load_learn_data(self) -> Dict[str, Any]:
        """加载本地学习数据"""
        learn_path = ASSETS_DIR / "learn_data.json"
        if not learn_path.exists():
            return self._create_default_learn_data()
        
        try:
            with open(learn_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            log(f"加载本地数据失败: {e}", "ERROR")
            return self._create_default_learn_data()
    
    def _create_default_learn_data(self) -> Dict[str, Any]:
        """创建默认数据结构"""
        return {
            "version": "2.0.0",
            "schema_version": "2.0.0",
            "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "collections": {},
            "cloud_sync": {
                "last_upload_hash": None,
                "last_upload_time": None,
                "last_download_time": None,
                "merge_count": 0
            }
        }
    
    def package_all(self) -> Dict[str, Any]:
        """打包所有学习数据为统一Schema"""
        schema_version = self.learn_data.get("schema_version", "1.0.0")
        
        if schema_version == "2.0.0" and SCHEMA_V2_AVAILABLE:
            # v2格式直接返回
            return self._package_v2()
        else:
            # v1格式需要迁移
            return self._package_v1_migrated()
    
    def _package_v2(self) -> Dict[str, Any]:
        """打包v2格式数据"""
        collections = self.learn_data.get("collections", {})
        
        # 计算统计信息
        total_items = sum(
            len(c.get("items", [])) for c in collections.values()
        )
        
        package = {
            "schema_version": "2.0.0",
            "package_id": hashlib.md5(
                datetime.now().isoformat().encode()
            ).hexdigest()[:16],
            "created_at": datetime.now().isoformat(),
            "source_device": "local",
            "collections": collections,
            "total_items": total_items,
            "data_hash": "",
            "priority_score": 0.5
        }
        
        # 计算hash
        package["data_hash"] = self._calc_package_hash(package)
        
        return package
    
    def _package_v1_migrated(self) -> Dict[str, Any]:
        """打包v1格式数据（自动迁移）"""
        if not SCHEMA_V2_AVAILABLE:
            # 回退到v1格式
            return self._package_v1_legacy()
        
        # 使用迁移函数
        pkg = migrate_v1_to_v2(self.learn_data)
        return pkg.to_dict()
    
    def _package_v1_legacy(self) -> Dict[str, Any]:
        """v1遗留打包方式"""
        safe_data = desensitize_data(self.learn_data)
        return {
            "schema_version": "1.0.0",
            "skillJson": safe_data,
            "data_hash": hashlib.md5(
                json.dumps(safe_data, sort_keys=True).encode()
            ).hexdigest()
        }
    
    def _calc_package_hash(self, package: Dict[str, Any]) -> str:
        """计算包指纹"""
        data = json.dumps({
            "schema": package.get("schema_version"),
            "collections": {
                k: [item.get("id", "") for item in v.get("items", [])]
                for k, v in package.get("collections", {}).items()
            }
        }, sort_keys=True, ensure_ascii=False)
        return hashlib.md5(data.encode()).hexdigest()
    
    def package_incremental(self, since_hash: str) -> Optional[Dict[str, Any]]:
        """增量打包 - 仅打包自上次上传后的变更"""
        full_package = self.package_all()
        current_hash = full_package.get("data_hash", "")
        
        if current_hash == since_hash:
            return None  # 无变化
        
        # TODO: 实现真正的增量打包（基于变更记录）
        return full_package


# ============================================================
# API客户端
# ============================================================
class LearningAPIClient:
    """学习数据API客户端"""
    
    def __init__(self):
        self.api_base = get_api_base()
        self.api_key = get_api_key()
    
    def _request(self, method: str, endpoint: str, 
                data: dict = None, headers: dict = None,
                timeout: int = 15) -> dict:
        """通用API请求"""
        url = f"{self.api_base}{endpoint}"
        
        default_headers = {
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": "TaxRiskGuard/1.3.0"
        }
        if headers:
            default_headers.update(headers)
        
        try:
            if method == "GET":
                req = Request(url, headers=default_headers, method="GET")
            else:
                body = json.dumps(data, ensure_ascii=False).encode('utf-8') if data else b''
                default_headers["Content-Type"] = "application/json"
                req = Request(url, data=body, headers=default_headers, method="POST")
            
            with urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode('utf-8'))
        
        except HTTPError as e:
            if e.code in (401, 403):
                return {"code": e.code, "msg": f"授权失败", "data": None, "auth_error": True}
            return {"code": e.code, "msg": f"HTTP Error: {e.reason}", "data": None}
        except URLError as e:
            return {"code": -1, "msg": f"URL Error: {e.reason}", "data": None}
        except Exception as e:
            return {"code": -2, "msg": f"Request Error: {str(e)}", "data": None}
    
    def upload(self, package: Dict[str, Any], remark: str = "") -> Dict[str, Any]:
        """上传学习包"""
        payload = {
            "skillName": SKILL_NAME,
            "skillJson": package,
            "remark": remark or f"v2.0同步于 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        }
        
        result = self._request("POST", "/upload", payload)
        
        if result.get("auth_error"):
            return {"success": False, "auth_error": True, "error": result.get("msg")}
        
        if result.get("code") == 0:
            return {
                "success": True,
                "data": result.get("data", {}),
                "record_id": result.get("data", {}).get("id")
            }
        else:
            return {"success": False, "error": result.get("msg")}
    
    def query(self, last_hash: str = "") -> Dict[str, Any]:
        """查询云端数据"""
        headers = {}
        if last_hash:
            headers["If-None-Match"] = last_hash
        
        endpoint = f"/query?skillName={SKILL_NAME}"
        result = self._request("GET", endpoint, headers=headers)
        
        if result.get("auth_error"):
            return {"success": False, "auth_error": True, "error": result.get("msg")}
        
        if result.get("code") == 0:
            data = result.get("data", {})
            
            if not data.get("changed", True):
                return {"success": True, "changed": False}
            
            # 解析云端数据
            cloud_data = data.get("skillJson", {})
            if isinstance(cloud_data, str):
                try:
                    cloud_data = json.loads(cloud_data)
                except:
                    cloud_data = {}
            
            return {
                "success": True,
                "changed": True,
                "data": cloud_data,
                "data_hash": data.get("dataHash", ""),
                "quota": data.get("quotaRemaining")
            }
        else:
            return {"success": False, "error": result.get("msg")}


# ============================================================
# 统一同步引擎
# ============================================================
class UnifiedSyncEngine:
    """统一同步引擎 - 整合打包、上传、下载、聚合、应用"""
    
    def __init__(self):
        self.packager = LearningPackager()
        self.client = LearningAPIClient()
        self.applier = LocalApplier() if SCHEMA_V2_AVAILABLE else None
        self.aggregator = AggregationEngine() if SCHEMA_V2_AVAILABLE else None
    
    def sync(self, silent: bool = False, dry_run: bool = False) -> Dict[str, Any]:
        """
        执行完整同步流程
        
        Args:
            silent: 静默模式（授权失败不输出警告）
            dry_run: 模拟运行（不上传/不应用）
        
        Returns:
            同步结果
        """
        results = {
            "success": True,
            "upload": None,
            "download": None,
            "merge": None,
            "apply": None,
            "auth_error": False,
            "notice": ""
        }
        
        log("=" * 60)
        log("TaxRiskGuard 统一自学习同步 v2.0")
        log("=" * 60)
        
        # Step 1: 打包本地数据
        log("\n[Step 1/5] 打包本地学习数据...")
        package = self.packager.package_all()
        log(f"  打包完成: {package.get('total_items', 0)} 项数据")
        log(f"  Schema版本: {package.get('schema_version', '1.0.0')}")
        
        # Step 2: 上传
        log("\n[Step 2/5] 上传本地数据到云端...")
        if not dry_run:
            upload_result = self.client.upload(package)
            results["upload"] = upload_result
            
            if upload_result.get("auth_error"):
                results["auth_error"] = True
                if not silent:
                    log("  [WARNING] 上传授权失败，继续下载流程...")
            elif upload_result.get("success"):
                log(f"  ✅ 上传成功，记录ID: {upload_result.get('record_id')}")
            else:
                log(f"  ⚠️ 上传失败: {upload_result.get('error')}")
        else:
            log("  [DRY RUN] 跳过上传")
        
        # Step 3: 下载云端数据
        log("\n[Step 3/5] 查询云端聚合数据...")
        if not dry_run:
            # 获取上次缓存的hash
            cache = self._load_cache()
            last_hash = cache.get("cloud_data_hash", "")
            
            download_result = self.client.query(last_hash)
            results["download"] = download_result
            
            if download_result.get("auth_error"):
                results["auth_error"] = True
                if not silent:
                    log("  [WARNING] 下载授权失败")
                results["apply"] = {"skipped": True, "reason": "授权失败"}
            elif not download_result.get("success"):
                log(f"  ⚠️ 查询失败: {download_result.get('error')}")
                results["apply"] = {"skipped": True, "reason": "查询失败"}
            elif not download_result.get("changed"):
                log("  ℹ️ 云端数据无变化")
                results["apply"] = {"skipped": True, "reason": "无变化"}
            else:
                log(f"  ✅ 获取到新数据")
                cloud_data = download_result.get("data", {})
                
                # 保存新hash到缓存
                self._save_cache({
                    "cloud_data_hash": download_result.get("data_hash", ""),
                    "last_update_time": datetime.now().isoformat()
                })
                
                # Step 4: 聚合（如果有多个数据源）
                log("\n[Step 4/5] 聚合数据...")
                if self.aggregator and cloud_data.get("schema_version") == "2.0.0":
                    # v2数据使用聚合引擎
                    aggregated = self.aggregator.aggregate([cloud_data], package)
                    log("  ✅ 聚合完成")
                else:
                    # v1数据或聚合引擎不可用，直接合并
                    aggregated = cloud_data
                    log("  ℹ️ 使用简单合并")
                
                results["merge"] = {"success": True}
                
                # Step 5: 应用到本地
                log("\n[Step 5/5] 应用学习数据到本地系统...")
                if self.applier:
                    apply_results = self.applier.apply_package(aggregated, dry_run=False)
                    results["apply"] = {
                        "success": True,
                        "results": [
                            {
                                "data_type": r.data_type,
                                "items_applied": r.items_applied,
                                "success": r.success
                            }
                            for r in apply_results
                        ],
                        "total_applied": sum(r.items_applied for r in apply_results)
                    }
                    
                    # 显示应用报告
                    report = self.applier.get_application_report()
                    print(report)
                else:
                    # 回退到旧合并方式
                    log("  使用v1合并方式...")
                    results["apply"] = self._legacy_merge(cloud_data)
        else:
            log("  [DRY RUN] 跳过下载")
        
        # 汇总
        log("\n" + "=" * 60)
        log("同步完成!")
        
        if results["auth_error"]:
            results["notice"] = "如需获取最新知识库和持续迭代新功能请联系作者获取授权！"
            log(f"  [NOTICE] {results['notice']}")
        
        total_applied = results.get("apply", {}).get("total_applied", 0)
        if total_applied > 0:
            log(f"  📚 成功应用 {total_applied} 项新知识")
        
        log("=" * 60)
        
        return results
    
    def _load_cache(self) -> Dict[str, Any]:
        """加载缓存"""
        cache_file = DATA_DIR / "learn_sync_cache.json"
        if cache_file.exists():
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {}
    
    def _save_cache(self, data: Dict[str, Any]):
        """保存缓存"""
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        cache_file = DATA_DIR / "learn_sync_cache.json"
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache = json.load(f)
        except:
            cache = {}
        
        cache.update(data)
        
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    
    def _legacy_merge(self, cloud_data: Dict[str, Any]) -> Dict[str, Any]:
        """v1遗留合并方式"""
        # 这里调用原learn_sync.py的合并逻辑
        # 简化实现：直接返回成功
        return {"success": True, "total_applied": 0, "legacy": True}


# ============================================================
# CLI接口
# ============================================================
def main():
    parser = argparse.ArgumentParser(description="TaxRiskGuard 统一自学习同步 v2.0")
    parser.add_argument("--sync", action="store_true", help="双向同步")
    parser.add_argument("--upload", action="store_true", help="仅上传")
    parser.add_argument("--query", action="store_true", help="仅查询")
    parser.add_argument("--status", action="store_true", help="查看状态")
    parser.add_argument("--dry-run", action="store_true", help="模拟运行")
    parser.add_argument("--silent", action="store_true", help="静默模式")
    parser.add_argument("--remark", type=str, default="", help="上传备注")
    
    args = parser.parse_args()
    
    engine = UnifiedSyncEngine()
    
    if args.sync:
        results = engine.sync(silent=args.silent, dry_run=args.dry_run)
        print(json.dumps(results, ensure_ascii=False, indent=2))
    elif args.upload:
        package = engine.packager.package_all()
        result = engine.client.upload(package, args.remark)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.query:
        result = engine.client.query()
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.status:
        print(f"Schema v2.0 可用: {SCHEMA_V2_AVAILABLE}")
        # TODO: 显示更详细的状态
    else:
        # 默认执行同步
        results = engine.sync(silent=args.silent)
        print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
