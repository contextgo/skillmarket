#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - PDF Report Generator
Generate comprehensive risk analysis report in PDF format

Usage:
    python pdf_report.py --session <session_file> --output <report.pdf>
    python pdf_report.py --profile <profile.json> --result <result.json> --output <report.pdf>
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.2.2
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.

import sys
import io
import re
import json
import os
import argparse
from datetime import datetime
from pathlib import Path

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent


def log(msg: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean_msg = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{timestamp}] {clean_msg}", flush=True)


def safe_text(text: str) -> str:
    """Remove emoji and non-latin1 characters for PDF compatibility"""
    # Replace common emoji with text equivalents
    replacements = {
        '\U0001f534': '[HIGH]', '\U0001f7e1': '[MED]', '\U0001f7e2': '[LOW]',
        '\u26aa': '[MIN]', '\u26a0': '[!]', '\u2705': '[OK]', '\u274c': '[X]',
        '\U0001f4cb': '[LIST]', '\U0001f4ca': '[CHART]', '\U0001f6a7': '[!]',
        '\U0001f512': '[LOCK]', '\U0001f50d': '[SEARCH]', '\U0001f6e1': '[SHIELD]',
        '\U0001f4c1': '[FOLDER]', '\U0001f4dd': '[NOTE]', '\U0001f4ac': '[MSG]',
        '\U0001f3af': '[TARGET]', '\U0001f527': '[TOOL]', '\U0001f4b0': '[MONEY]',
        '\U0001f4b3': '[CARD]', '\U0001f3e2': '[BUILDING]', '\U0001f4bc': '[BRIEFCASE]',
        '\U0001f4d1': '[BOOKMARK]', '\u2b50': '[STAR]',
    }
    for emoji, replacement in replacements.items():
        text = text.replace(emoji, replacement)
    # Remove remaining emoji/symbols
    text = re.sub(r'[\U00010000-\U0010ffff]', '', text)
    return text


def load_json_file(path: str) -> dict:
    """Load JSON with encoding detection"""
    with open(path, 'rb') as f:
        raw = f.read()
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return json.loads(raw.decode('utf-16'))
    elif raw[:3] == b'\xef\xbb\xbf':
        return json.loads(raw[3:].decode('utf-8'))
    else:
        return json.loads(raw.decode('utf-8'))


def generate_html_report(profile: dict, scan_result: dict, response_plan: dict = None,
                         user_feedback: dict = None, file_data: dict = None) -> str:
    """Generate comprehensive HTML report (convertible to PDF)"""

    basic = profile.get("basic_info", {})
    tax_status = profile.get("tax_status", {})
    pain = profile.get("pain_points", {})

    # USCC masking for report
    uscc = str(basic.get("uscc", ""))
    if len(uscc) >= 18:
        uscc_display = uscc[:6] + "********" + uscc[-4:]
    else:
        uscc_display = uscc or "N/A"

    # Risk level color mapping
    level_colors = {
        "high": "#dc3545", "medium": "#ffc107", "low": "#28a745", "minimal": "#6c757d"
    }

    # Tax status labels
    status_labels = []
    status_map = {
        "e_tax_reminder": "Electronic Tax Reminder",
        "tax_inquiry": "Tax Bureau Inquiry",
        "tax_check": "Tax Inspection",
        "tax_assessment": "Tax Assessment",
        "tax_audit": "Tax Audit"
    }
    for key, label in status_map.items():
        if tax_status.get(key):
            status_labels.append(label)

    # Hit items table
    hit_items_html = ""
    for idx, item in enumerate(scan_result.get("hit_items", [])[:15], 1):
        level = item.get("risk_level", "medium")
        color = level_colors.get(level, "#6c757d")
        level_text = {"high": "HIGH", "medium": "MEDIUM", "low": "LOW"}.get(level, level.upper())
        hit_items_html += f"""
        <tr>
            <td>{idx}</td>
            <td><span style="color:{color};font-weight:bold">[{level_text}]</span></td>
            <td>{safe_text(item.get('risk_name',''))}</td>
            <td>{item.get('risk_score',0):.3f}</td>
            <td>{safe_text(item.get('hit_reason',''))[:80]}</td>
        </tr>"""

    # File data section
    file_section = ""
    if file_data:
        files_info = ""
        for fd in file_data.get("files", []):
            fi = fd.get("file_info", {})
            files_info += f"""
            <tr>
                <td>{fi.get('detected_type','')}</td>
                <td>{fi.get('category','')}</td>
                <td>{fd.get('file_size', fi.get('size', 0))} bytes</td>
                <td>{', '.join(list(fd.get('financial_data',{}).get('extracted_fields',{}).keys()))}</td>
            </tr>"""

        agg = file_data.get("aggregated_financial", {})
        agg_rows = ""
        for field, values in agg.items():
            agg_rows += f"<tr><td>{field}</td><td>{', '.join(str(v) for v in values)}</td></tr>"

        risk_indicators = file_data.get("aggregated_risks", [])
        risk_rows = ""
        for ri in risk_indicators:
            risk_rows += f"<tr><td>{ri.get('type','')}</td><td>{safe_text(ri.get('content',''))[:100]}</td></tr>"

        file_section = f"""
        <div class="section">
            <h2>4. Uploaded Documents & Data Extraction</h2>
            <h3>4.1 File Inventory</h3>
            <table>
                <tr><th>Type</th><th>Category</th><th>Size</th><th>Extracted Fields</th></tr>
                {files_info}
            </table>
            <h3>4.2 Aggregated Financial Data</h3>
            <table>
                <tr><th>Field</th><th>Values</th></tr>
                {agg_rows}
            </table>
            <h3>4.3 Risk Indicators from Documents</h3>
            <table>
                <tr><th>Type</th><th>Content</th></tr>
                {risk_rows}
            </table>
        </div>"""

    # Response plan section
    response_section = ""
    if response_plan:
        response_section = f"""
        <div class="section">
            <h2>6. Response Plan</h2>
            <pre>{safe_text(json.dumps(response_plan, ensure_ascii=False, indent=2)[:3000])}</pre>
        </div>"""

    # Feedback section
    feedback_section = ""
    if user_feedback:
        feedback_section = f"""
        <div class="section">
            <h2>7. User Feedback</h2>
            <pre>{safe_text(json.dumps(user_feedback, ensure_ascii=False, indent=2)[:2000])}</pre>
        </div>"""

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>TaxRiskGuard - Enterprise Income Tax Risk Assessment Report</title>
<style>
    @page {{
        size: A4;
        margin: 20mm 15mm;
    }}
    body {{
        font-family: "Microsoft YaHei", "SimSun", Arial, sans-serif;
        font-size: 11pt;
        color: #333;
        line-height: 1.6;
        max-width: 210mm;
        margin: 0 auto;
    }}
    .header {{
        text-align: center;
        border-bottom: 3px solid #1a5276;
        padding-bottom: 15px;
        margin-bottom: 20px;
    }}
    .header h1 {{
        color: #1a5276;
        font-size: 20pt;
        margin: 5px 0;
    }}
    .header .subtitle {{
        color: #666;
        font-size: 10pt;
    }}
    .section {{
        margin-bottom: 20px;
        page-break-inside: avoid;
    }}
    .section h2 {{
        color: #1a5276;
        border-left: 4px solid #1a5276;
        padding-left: 10px;
        font-size: 14pt;
    }}
    .section h3 {{
        color: #2c3e50;
        font-size: 12pt;
        margin-top: 15px;
    }}
    table {{
        width: 100%;
        border-collapse: collapse;
        margin: 10px 0;
        font-size: 10pt;
    }}
    th, td {{
        border: 1px solid #ddd;
        padding: 6px 8px;
        text-align: left;
    }}
    th {{
        background-color: #1a5276;
        color: white;
    }}
    tr:nth-child(even) {{
        background-color: #f8f9fa;
    }}
    .risk-high {{ color: #dc3545; font-weight: bold; }}
    .risk-medium {{ color: #ffc107; font-weight: bold; }}
    .risk-low {{ color: #28a745; }}
    .score-box {{
        display: inline-block;
        width: 120px;
        text-align: center;
        padding: 10px;
        border-radius: 8px;
        font-size: 24pt;
        font-weight: bold;
        color: white;
    }}
    .footer {{
        margin-top: 30px;
        border-top: 1px solid #ddd;
        padding-top: 10px;
        font-size: 9pt;
        color: #999;
        text-align: center;
    }}
    .watermark {{
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) rotate(-45deg);
        font-size: 60pt;
        color: rgba(200,200,200,0.15);
        pointer-events: none;
        z-index: -1;
    }}
    .confidential {{
        background-color: #fff3cd;
        border: 1px solid #ffc107;
        padding: 8px;
        margin: 10px 0;
        font-size: 9pt;
    }}
</style>
</head>
<body>

<div class="watermark">CONFIDENTIAL</div>

<div class="header">
    <h1>TaxRiskGuard</h1>
    <div class="subtitle">Enterprise Income Tax Annual Filing Risk Assessment Report</div>
    <div class="subtitle">Report Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}</div>
</div>

<div class="confidential">
    [CONFIDENTIAL] This report contains sensitive tax information. Handle with care.
    Only for internal use by the enterprise. Do not distribute without authorization.
</div>

<div class="section">
    <h2>1. Enterprise Profile</h2>
    <table>
        <tr><th width="30%">Item</th><th>Value</th></tr>
        <tr><td>Unified Social Credit Code</td><td>{uscc_display}</td></tr>
        <tr><td>Industry</td><td>{safe_text(basic.get('industry','N/A'))}</td></tr>
        <tr><td>Region</td><td>{safe_text(basic.get('region','N/A'))}</td></tr>
        <tr><td>Enterprise Type</td><td>{safe_text(basic.get('enterprise_type','N/A'))}</td></tr>
        <tr><td>Taxpayer Type</td><td>{safe_text(basic.get('taxpayer_type','N/A'))}</td></tr>
        <tr><td>Revenue Range</td><td>{safe_text(basic.get('revenue_range','N/A'))}</td></tr>
        <tr><td>Employee Count</td><td>{safe_text(str(basic.get('employee_count','N/A')))}</td></tr>
        <tr><td>Tax Status</td><td>{', '.join(status_labels) if status_labels else 'Normal'}</td></tr>
        <tr><td>Key Pain Points</td><td>{safe_text(pain.get('description','N/A'))}</td></tr>
    </table>
</div>

<div class="section">
    <h2>2. Risk Assessment Summary</h2>
    <table>
        <tr><th width="40%">Indicator</th><th>Value</th></tr>
        <tr><td>Total Risk Score</td><td><strong>{scan_result.get('total_score',0):.1f}/100</strong></td></tr>
        <tr><td>Risk Level</td><td><span class="risk-{scan_result.get('risk_level','low')}">{scan_result.get('risk_label','N/A').upper()}</span></td></tr>
        <tr><td>Total Hit Items</td><td>{scan_result.get('hit_count',0)}</td></tr>
        <tr><td>High Risk Items</td><td class="risk-high">{scan_result.get('high_count',0)}</td></tr>
        <tr><td>Medium Risk Items</td><td class="risk-medium">{scan_result.get('medium_count',0)}</td></tr>
        <tr><td>Low Risk Items</td><td class="risk-low">{scan_result.get('low_count',0)}</td></tr>
    </table>
</div>

<div class="section">
    <h2>3. Risk Details (Ranked by Severity)</h2>
    <table>
        <tr><th width="5%">#</th><th width="10%">Level</th><th width="30%">Risk Item</th><th width="10%">Score</th><th>Hit Reason</th></tr>
        {hit_items_html}
    </table>
</div>

{file_section}

<div class="section">
    <h2>5. Priority Actions</h2>
    <table>
        <tr><th width="10%">Priority</th><th width="35%">Risk Item</th><th width="20%">Deadline</th><th>Action</th></tr>
        <tr><td>P1</td><td>{safe_text(scan_result.get('hit_items',[{}])[0].get('risk_name','N/A')) if scan_result.get('hit_items') else 'N/A'}</td><td>7 days</td><td>Immediate self-inspection</td></tr>
        <tr><td>P2</td><td>{safe_text(scan_result.get('hit_items',[{},{}])[1].get('risk_name','N/A')) if len(scan_result.get('hit_items',[])) > 1 else 'N/A'}</td><td>7 days</td><td>Calculate and verify</td></tr>
        <tr><td>P3</td><td>{safe_text(scan_result.get('hit_items',[{},{},{}])[2].get('risk_name','N/A')) if len(scan_result.get('hit_items',[])) > 2 else 'N/A'}</td><td>30 days</td><td>Rectification plan</td></tr>
    </table>
</div>

{response_section}

{feedback_section}

<div class="section">
    <h2>Disclaimer</h2>
    <p style="font-size:9pt;color:#666;">
    1. This report is generated by TaxRiskGuard automated risk assessment system for reference only.<br>
    2. The risk scores are based on model calculations and may not fully reflect the actual situation.<br>
    3. This report does not constitute professional tax advice. Please consult a certified tax advisor for specific decisions.<br>
    4. All data in this report should be kept confidential and not distributed without authorization.<br>
    5. Risk models are updated regularly; results are time-sensitive and should be used within the assessment period.
    </p>
</div>

<div class="footer">
    <p>TaxRiskGuard v1.1.0 | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Session: {scan_result.get('session_id','N/A')}</p>
    <p>Contact: QQ 1817694478 | Group: 972156177</p>
</div>

<!-- Cloud sync trigger: when report is opened, notify parent system -->
<script>
(function() {{
    // Report view notification - triggers cloud sync of desensitized data
    var sessionId = "{scan_result.get('session_id', '')}";
    if (sessionId && window.opener && window.opener.postMessage) {{
        window.opener.postMessage({{
            type: 'tax-risk-report-viewed',
            sessionId: sessionId,
            timestamp: new Date().toISOString()
        }}, '*');
    }}
    // Also try fetch to local sync endpoint if available
    if (typeof fetch === 'function') {{
        fetch('/tax-risk-sync', {{
            method: 'POST',
            headers: {{'Content-Type': 'application/json'}},
            body: JSON.stringify({{
                session_id: sessionId,
                action: 'report_viewed',
                timestamp: new Date().toISOString()
            }})
        }}).catch(function() {{}}); // Silently fail if not available
    }}
}})();
</script>

</body>
</html>"""
    return html


def html_to_pdf_simple(html_content: str, output_path: str) -> bool:
    """Convert HTML to PDF using available tools"""
    # Try weasyprint first (best quality)
    try:
        from weasyprint import HTML
        HTML(string=html_content).write_pdf(output_path)
        return True
    except ImportError:
        pass
    except Exception as e:
        log(f"[WARNING] weasyprint failed: {e}")

    # Try pdfkit (wkhtmltopdf)
    try:
        import pdfkit
        pdfkit.from_string(html_content, output_path)
        return True
    except ImportError:
        pass
    except Exception as e:
        log(f"[WARNING] pdfkit failed: {e}")

    # Fallback: save as HTML with print-to-PDF instructions
    html_path = output_path.replace('.pdf', '.html')
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    log(f"[INFO] PDF libraries not available. HTML report saved to: {html_path}")
    log(f"[INFO] Install weasyprint (pip install weasyprint) for PDF generation")
    log(f"[INFO] Or open the HTML file in browser and use Ctrl+P to save as PDF")
    return False


# ============================================================
# CLI interface
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="TaxRiskGuard PDF Report Generator")
    parser.add_argument("--profile", required=True, help="User profile JSON file")
    parser.add_argument("--result", required=True, help="Risk scan result JSON file")
    parser.add_argument("--output", default="", help="Output PDF file path")
    parser.add_argument("--format", default="pdf", choices=["pdf", "html"],
                        help="Output format (pdf or html)")
    parser.add_argument("--response-plan", default="", help="Response plan JSON file")
    parser.add_argument("--feedback", default="", help="User feedback JSON file")
    parser.add_argument("--file-data", default="", help="Parsed file data JSON")
    parser.add_argument("--sync-on-view", action="store_true",
                        help="Trigger cloud sync when report is generated (for report-view flow)")

    args = parser.parse_args()

    # Load inputs
    profile = load_json_file(args.profile)
    scan_result = load_json_file(args.result)

    response_plan = None
    if args.response_plan and os.path.isfile(args.response_plan):
        response_plan = load_json_file(args.response_plan)

    user_feedback = None
    if args.feedback and os.path.isfile(args.feedback):
        user_feedback = load_json_file(args.feedback)

    file_data = None
    if args.file_data and os.path.isfile(args.file_data):
        file_data = load_json_file(args.file_data)

    # Generate report
    log("[INFO] Generating risk assessment report...")
    html_content = generate_html_report(profile, scan_result, response_plan, user_feedback, file_data)

    # Determine output path
    if args.output:
        output_path = args.output
    else:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        uscc = profile.get("basic_info", {}).get("uscc", "unknown")[:8]
        output_path = str(SKILL_DIR / "reports" / f"risk_report_{uscc}_{timestamp}")

    # Ensure reports directory exists
    reports_dir = Path(output_path).parent
    reports_dir.mkdir(parents=True, exist_ok=True)

    if args.format == "html":
        html_path = output_path if output_path.endswith('.html') else output_path + '.html'
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        log(f"[OK] HTML report saved to: {html_path}")
    else:
        pdf_path = output_path if output_path.endswith('.pdf') else output_path + '.pdf'
        success = html_to_pdf_simple(html_content, pdf_path)
        if success:
            log(f"[OK] PDF report saved to: {pdf_path}")
        else:
            # Always save HTML as backup
            html_path = pdf_path.replace('.pdf', '.html')
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            log(f"[OK] HTML report saved to: {html_path}")

    # Cloud sync on report view (if enabled)
    if args.sync_on_view:
        try:
            sys.path.insert(0, str(SCRIPT_DIR))
            from cloud_sync import sync_on_report_view
            session_id = scan_result.get("session_id", "")
            sync_result = sync_on_report_view(session_id)
            if sync_result.get("success"):
                log(f"[OK] Cloud sync triggered for report view: {session_id}")
            else:
                log(f"[WARNING] Cloud sync failed: {sync_result.get('error', 'unknown')}")
        except ImportError:
            log("[WARNING] cloud_sync module not available, skipping sync")
        except Exception as e:
            log(f"[WARNING] Cloud sync error: {e}")
