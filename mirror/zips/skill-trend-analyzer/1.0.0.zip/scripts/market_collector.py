#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 1.0.0
# Author: QQ 1817694478 | Q-Group: 972156177
"""
Market Data Collector for Skill Trend Analyzer
================================================
Periodically crawls skill marketplaces (ClawHub etc.) to collect
hot skill metadata: name, slug, description, keywords, triggers,
ratings, download counts. Stores as local JSON for trend analysis.

Features:
  - Multi-category search (40+ domain queries)
  - Incremental update (only fetch new/changed skills)
  - Data decay (older data gets less weight)
  - Rate limiting (respect API limits)
  - Deduplication (MD5 fingerprint)

Usage:
  python market_collector.py [--full] [--verbose]
  python market_collector.py --status
"""
import sys, io, os, re, json, hashlib, time, math
from pathlib import Path
from datetime import datetime, timedelta
from collections import Counter, defaultdict

# [Safe I/O: 5-layer anti-freeze system]
from safe_io import safe_print, safe_init, TimeoutGuard, safe_subprocess, safe_read_json
safe_init()

# ============================================================
# Configuration
# ============================================================

SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

# Cache files
MARKET_CACHE = DATA_DIR / "market_cache.json"        # Raw market skill data
KEYWORD_FREQ = DATA_DIR / "keyword_frequency.json"    # Aggregated keyword frequencies
TRIGGER_PATTERNS = DATA_DIR / "trigger_patterns.json"  # Extracted trigger patterns
TREND_HISTORY = DATA_DIR / "trend_history.json"       # Historical trend snapshots
COLLECT_LOG = DATA_DIR / "collect_log.json"           # Collection log

# Decay factor: data older than N days gets weight *= decay^N
DECAY_LAMBDA = 0.02  # ~50% weight after 35 days

# Rate limiting
SEARCH_DELAY = 1.5  # seconds between searches
MAX_SEARCHES_PER_RUN = 30

# Search query categories for comprehensive market coverage
SEARCH_CATEGORIES = {
    "tax_finance": [
        "tax finance accounting", "invoice billing receipt",
        "compliance audit regulation", "financial report analysis",
        "tax planning deduction", "corporate tax risk",
        "bookkeeping ledger", "payroll salary",
    ],
    "business_management": [
        "business management project", "contract agreement legal",
        "workflow automation process", "hr employee recruitment",
        "crm customer sales", "inventory warehouse supply",
    ],
    "ai_productivity": [
        "AI assistant chatbot", "productivity automation tools",
        "writing content generation", "data analysis visualization",
        "email communication management", "scheduling calendar task",
    ],
    "development": [
        "code developer programming", "testing deployment CI CD",
        "API integration webhook", "database SQL query",
        "security authentication encryption",
    ],
    "lifestyle": [
        "health fitness workout", "food recipe cooking",
        "travel booking hotel", "education learning study",
        "shopping ecommerce store",
    ],
    "chinese_domain": [
        "税务 发票 合规", "财务 会计 记账", "企业 管理 合同",
        "风险 预警 稽查", "社保 个税 工资", "银行 流水 对账",
        "学习 规划 目标", "搜索 资源 影视",
    ],
}


# ============================================================
# ClawHub Search Interface
# ============================================================

class ClawHubSearcher:
    """Interface to ClawHub search API via CLI."""

    def __init__(self, verbose=False):
        self.verbose = verbose

    def search(self, query, limit=20):
        """Execute ClawHub search and return parsed results."""
        import subprocess
        try:
            if sys.platform == 'win32':
                cmd = ["cmd", "/c", "npx", "clawdhub", "search", query,
                       "--limit", str(limit)]
            else:
                cmd = ["npx", "clawdhub", "search", query,
                       "--limit", str(limit)]

            result = safe_subprocess(cmd, timeout=30)
            if not result['success']:
                if result['timed_out']:
                    print(f"[TIMEOUT] npx clawdhub search stuck for '{query}'")
                return []

            entries = []
            for line in result['stdout'].strip().split('\n'):
                m = re.match(r'(\S+)\s+(.+?)\s+\(([0-9.]+)\)', line.strip())
                if m:
                    slug = m.group(1)
                    name = m.group(2).strip()
                    relevance = float(m.group(3))
                    entries.append({
                        'slug': slug,
                        'name': name,
                        'relevance': relevance,
                        'source': 'clawhub',
                        'query': query,
                        'collected_at': datetime.now().isoformat(),
                    })
            return entries
        except Exception as e:
            if self.verbose:
                print(f"[WARNING] Search error for '{query}': {e}")
            return []


# ============================================================
# Market Data Collector
# ============================================================

class MarketCollector:
    """Collect and cache market skill data with incremental updates."""

    def __init__(self, verbose=False):
        self.verbose = verbose
        self.searcher = ClawHubSearcher(verbose=verbose)
        self.cache = self._load_cache()
        self.log = self._load_log()
        self.stats = {'searches': 0, 'new': 0, 'updated': 0, 'skipped': 0}

    def collect(self, full_scan=False):
        """Run market data collection."""
        print(f"[INFO] Market collection started ({'full' if full_scan else 'incremental'})")
        print(f"[INFO] Cache: {len(self.cache)} skills already cached")

        queries = self._get_queries(full_scan)
        total = len(queries)
        print(f"[INFO] Search queries: {total}")

        for i, query in enumerate(queries):
            if self.stats['searches'] >= MAX_SEARCHES_PER_RUN and not full_scan:
                print(f"[INFO] Rate limit reached ({MAX_SEARCHES_PER_RUN} searches)")
                break

            if self.verbose:
                print(f"[{i+1}/{total}] Searching: '{query}'")

            results = self.searcher.search(query, limit=20)
            self.stats['searches'] += 1

            for entry in results:
                self._merge_entry(entry)

            # Rate limiting
            if i < total - 1:
                time.sleep(SEARCH_DELAY)

        # Save cache and compute analytics
        self._save_cache()
        self._compute_analytics()

        # Log this run
        self._log_run()

        print(f"\n[OK] Collection complete:")
        print(f"  Searches: {self.stats['searches']}")
        print(f"  New skills: {self.stats['new']}")
        print(f"  Updated: {self.stats['updated']}")
        print(f"  Skipped (unchanged): {self.stats['skipped']}")
        print(f"  Total cached: {len(self.cache)}")

        return self.cache

    def get_status(self):
        """Get current cache status."""
        if not self.cache:
            print("[INFO] No cached market data. Run collection first.")
            return

        total = len(self.cache)
        sources = Counter(v.get('source', 'unknown') for v in self.cache.values())
        ages = []
        now = datetime.now()
        for v in self.cache.values():
            try:
                dt = datetime.fromisoformat(v.get('collected_at', now.isoformat()))
                ages.append((now - dt).days)
            except:
                ages.append(0)

        print(f"[STATUS] Market Data Cache")
        print(f"  Total skills: {total}")
        print(f"  Sources: {dict(sources)}")
        print(f"  Age range: {min(ages)}-{max(ages)} days")
        print(f"  Avg age: {sum(ages)/len(ages):.1f} days")
        if self.log:
            last = self.log[-1]
            print(f"  Last collection: {last.get('timestamp', 'unknown')}")
            print(f"  Last stats: {last.get('stats', {})}")

    def _get_queries(self, full_scan):
        """Get search queries based on scan mode."""
        queries = []
        for cat, cat_queries in SEARCH_CATEGORIES.items():
            if full_scan:
                queries.extend(cat_queries)
            else:
                # Incremental: pick 1-2 per category
                queries.extend(cat_queries[:2])
        return queries

    def _merge_entry(self, entry):
        """Merge a new entry into cache (incremental update)."""
        slug = entry['slug']
        fingerprint = hashlib.md5(
            json.dumps(entry, sort_keys=True, ensure_ascii=False).encode()
        ).hexdigest()

        if slug in self.cache:
            old = self.cache[slug]
            if old.get('fingerprint') == fingerprint:
                self.stats['skipped'] += 1
                return
            # Update existing
            entry['fingerprint'] = fingerprint
            entry['first_seen'] = old.get('first_seen', entry['collected_at'])
            entry['update_count'] = old.get('update_count', 0) + 1
            self.cache[slug] = entry
            self.stats['updated'] += 1
        else:
            entry['fingerprint'] = fingerprint
            entry['first_seen'] = entry['collected_at']
            entry['update_count'] = 0
            self.cache[slug] = entry
            self.stats['new'] += 1

    def _compute_analytics(self):
        """Compute keyword frequency and trigger pattern analytics from cache."""
        kw_freq = Counter()          # keyword -> weighted frequency
        trigger_patterns = Counter() # trigger pattern -> frequency
        slug_keywords = defaultdict(list)  # keyword -> [slugs]

        now = datetime.now()

        for slug, entry in self.cache.items():
            # Compute time-decay weight
            try:
                collected = datetime.fromisoformat(entry.get('collected_at', now.isoformat()))
                age_days = max(0, (now - collected).days)
            except:
                age_days = 0
            decay_weight = math.exp(-DECAY_LAMBDA * age_days)

            # Extract from slug (kebab-case split)
            slug_parts = slug.replace('-', ' ').replace('_', ' ').split()
            for part in slug_parts:
                w = part.lower()
                if len(w) > 2:
                    kw_freq[w] += 2.0 * decay_weight
                    slug_keywords[w].append(slug)

            # Extract from name
            name = entry.get('name', '')
            # Chinese segments
            for zh in re.findall(r'[\u4e00-\u9fff]{2,8}', name):
                kw_freq[zh] += 3.0 * decay_weight
                slug_keywords[zh].append(slug)
            # English words
            for en in re.findall(r'[A-Z][a-zA-Z]{2,}', name):
                w = en.lower()
                if len(w) > 2:
                    kw_freq[w] += 2.5 * decay_weight
                    slug_keywords[w].append(slug)

            # Extract relevance as popularity signal
            relevance = entry.get('relevance', 0)
            if relevance > 1.0:
                # Higher relevance = more popular query match
                for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', name):
                    kw_freq[zh] += relevance * 0.5 * decay_weight

        # Trigger pattern mining: find common 2-3 word combos in names
        for slug, entry in self.cache.items():
            name = entry.get('name', '')
            words = re.findall(r'[A-Z][a-zA-Z]+|[\u4e00-\u9fff]{2,4}', name)
            for i in range(len(words) - 1):
                bigram = ' '.join(words[i:i+2]).lower()
                trigger_patterns[bigram] += 1
            for i in range(len(words) - 2):
                trigram = ' '.join(words[i:i+3]).lower()
                trigger_patterns[trigram] += 0.5  # Trigrams less common

        # Save keyword frequency
        kw_data = {
            "generated_at": datetime.now().isoformat(),
            "total_skills_analyzed": len(self.cache),
            "top_keywords": [
                {"keyword": kw, "score": round(score, 2),
                 "example_slugs": slugs[:5], "source": "clawhub_market"}
                for kw, score, slugs in [
                    (k, v, slug_keywords[k]) for k, v in kw_freq.most_common(500)
                ]
            ],
        }
        KEYWORD_FREQ.write_text(
            json.dumps(kw_data, ensure_ascii=False, indent=2), encoding='utf-8'
        )

        # Save trigger patterns
        tp_data = {
            "generated_at": datetime.now().isoformat(),
            "total_skills_analyzed": len(self.cache),
            "top_patterns": [
                {"pattern": p, "frequency": int(c), "source": "clawhub_market"}
                for p, c in trigger_patterns.most_common(200)
                if c >= 2  # Only patterns seen 2+ times
            ],
        }
        TRIGGER_PATTERNS.write_text(
            json.dumps(tp_data, ensure_ascii=False, indent=2), encoding='utf-8'
        )

        # Save trend history snapshot
        self._save_trend_snapshot(kw_freq)

        if self.verbose:
            print(f"[OK] Analytics: {len(kw_freq)} keywords, "
                  f"{len(trigger_patterns)} trigger patterns")

    def _save_trend_snapshot(self, kw_freq):
        """Save a timestamped snapshot for trend tracking."""
        history = []
        if TREND_HISTORY.exists():
            try:
                history = safe_read_json(TREND_HISTORY)
            except:
                history = []

        snapshot = {
            "timestamp": datetime.now().isoformat(),
            "total_skills": len(self.cache),
            "top_50_keywords": [
                {"keyword": kw, "score": round(score, 2)}
                for kw, score in kw_freq.most_common(50)
            ],
        }

        history.append(snapshot)

        # Keep last 90 snapshots (about 3 months of daily data)
        if len(history) > 90:
            history = history[-90:]

        TREND_HISTORY.write_text(
            json.dumps(history, ensure_ascii=False, indent=1), encoding='utf-8'
        )

    def _log_run(self):
        """Log this collection run."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "stats": self.stats,
            "cache_size": len(self.cache),
        }
        self.log.append(entry)
        if len(self.log) > 100:
            self.log = self.log[-100:]
        COLLECT_LOG.write_text(
            json.dumps(self.log, ensure_ascii=False, indent=1), encoding='utf-8'
        )

    def _load_cache(self):
        """Load market cache from disk."""
        if MARKET_CACHE.exists():
            try:
                return safe_read_json(MARKET_CACHE)
            except:
                return {}
        return {}

    def _save_cache(self):
        """Save market cache to disk."""
        MARKET_CACHE.write_text(
            json.dumps(self.cache, ensure_ascii=False, indent=1), encoding='utf-8'
        )

    def _load_log(self):
        """Load collection log from disk."""
        if COLLECT_LOG.exists():
            try:
                return safe_read_json(COLLECT_LOG)
            except:
                return []
        return []


# ============================================================
# CLI Entry Point
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Market Data Collector")
    parser.add_argument("--full", action="store_true",
                       help="Full scan (all category queries)")
    parser.add_argument("--status", action="store_true",
                       help="Show cache status")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    collector = MarketCollector(verbose=args.verbose)

    if args.status:
        collector.get_status()
    else:
        collector.collect(full_scan=args.full)


if __name__ == "__main__":
    main()
