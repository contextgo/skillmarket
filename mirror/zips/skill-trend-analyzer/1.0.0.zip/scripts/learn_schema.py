#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 统一自学习数据Schema (v2.0)
支持8种数据类型的结构化定义、验证和序列化

数据类型：
1. discoveries - 关键词发现
2. policy_updates - 政策更新
3. training_cases - 训练案例
4. user_profiles - 用户画像
5. model_parameters - 风险模型参数
6. trigger_words - 触发词优化
7. workflow_tuning - 工作流改进
8. industry_features - 行业/地区特征
9. feedback_patterns - 用户反馈学习
10. failure_cases - 失败案例库
11. time_sensitive - 时效性知识

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import io
import json
import hashlib
from datetime import datetime
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, field, asdict
from enum import Enum

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True


class DataType(Enum):
    """自学习数据类型枚举"""
    DISCOVERIES = "discoveries"
    POLICY_UPDATES = "policy_updates"
    TRAINING_CASES = "training_cases"
    USER_PROFILES = "user_profiles"
    MODEL_PARAMETERS = "model_parameters"
    TRIGGER_WORDS = "trigger_words"
    WORKFLOW_TUNING = "workflow_tuning"
    INDUSTRY_FEATURES = "industry_features"
    FEEDBACK_PATTERNS = "feedback_patterns"
    FAILURE_CASES = "failure_cases"
    TIME_SENSITIVE = "time_sensitive"


@dataclass
class BaseLearningItem:
    """基础学习项"""
    id: str
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    source: str = "local"  # local, cloud, merged
    version: str = "1.0.0"
    validation_count: int = 0  # 被验证/确认次数（用于可信度评分）
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    def get_fingerprint(self) -> str:
        """生成指纹用于去重"""
        data = json.dumps(self.to_dict(), sort_keys=True, ensure_ascii=False)
        return hashlib.md5(data.encode()).hexdigest()[:16]


@dataclass
class DiscoveryItem(BaseLearningItem):
    """关键词发现项"""
    keyword: str = ""
    context: str = ""
    found_date: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d"))
    related_risks: List[str] = field(default_factory=list)
    confidence: float = 0.5  # 置信度 0-1


@dataclass
class PolicyUpdateItem(BaseLearningItem):
    """政策更新项"""
    title: str = ""  # 如 "财税[2026]15号"
    context: str = ""
    effective_date: str = ""
    expiry_date: str = ""  # 政策截止日期
    source_url: str = ""
    related_domains: List[str] = field(default_factory=list)  # 关联风险域
    added_to_kb: bool = False


@dataclass
class TrainingCaseItem(BaseLearningItem):
    """训练案例项"""
    case_id: str = ""
    company: str = ""  # 脱敏后的企业名
    industry: str = ""
    region: str = ""
    uscc_masked: str = ""  # 脱敏的统一社会信用代码
    risk_areas: List[str] = field(default_factory=list)
    risk_score: float = 0.0
    learning_date: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d"))
    feedback: str = ""  # positive, negative, neutral
    key_learnings: List[str] = field(default_factory=list)


@dataclass
class UserProfileItem:
    """用户画像项（以USCC为key存储）"""
    industry: str = ""
    region: str = ""
    scan_count: int = 0
    avg_score: float = 0.0
    last_scan_date: str = ""
    preferred_depth: str = "standard"  # brief, standard, detailed
    common_risks: List[str] = field(default_factory=list)


@dataclass
class ModelParameterItem(BaseLearningItem):
    """风险模型参数项"""
    risk_domain: str = ""  # 风险域ID，如 "rd_expense"
    param_name: str = ""  # 参数名，如 "threshold_high"
    param_value: float = 0.0
    param_type: str = "threshold"  # threshold, weight, factor
    validation_cases: int = 0  # 基于多少案例验证
    confidence: float = 0.5
    previous_value: float = 0.0  # 用于回滚
    rollback_available: bool = False


@dataclass
class TriggerWordItem(BaseLearningItem):
    """触发词优化项"""
    word: str = ""
    word_type: str = "keyword"  # keyword, phrase, pattern
    trigger_count: int = 0  # 实际触发次数
    success_rate: float = 0.0  # 触发后成功解决问题的比例
    related_workflows: List[str] = field(default_factory=list)
    deprecated: bool = False
    deprecated_reason: str = ""


@dataclass
class WorkflowTuningItem(BaseLearningItem):
    """工作流改进项"""
    step_id: str = ""  # 如 "step_1_identify"
    parameter: str = ""  # 如 "skip_threshold"
    old_value: Any = None
    new_value: Any = None
    tuning_reason: str = ""
    step_context: str = ""  # 适用于哪个上下文
    performance_improvement: float = 0.0  # 性能提升百分比


@dataclass
class IndustryFeatureItem(BaseLearningItem):
    """行业/地区特征项"""
    feature_type: str = "industry"  # industry, region, sector
    feature_key: str = ""  # 如 "制造业-研发费用"
    industry: str = ""
    region: str = ""
    risk_patterns: List[Dict[str, Any]] = field(default_factory=list)
    # 如 [{"pattern": "研发人员占比异常", "weight": 1.5}]
    policy_exceptions: List[str] = field(default_factory=list)
    seasonal_factors: Dict[str, float] = field(default_factory=dict)
    # 如 {"Q4": 1.2} 表示Q4权重增加20%


@dataclass
class FeedbackPatternItem(BaseLearningItem):
    """用户反馈学习项"""
    pattern_hash: str = ""  # 查询模式的hash
    query_pattern: str = ""  # 查询关键词模式
    response_template: str = ""  # 有效回答模板
    context_type: str = ""  # 上下文类型
    satisfaction_score: float = 0.0  # 用户满意度 1-5
    helpful_count: int = 0  # 标记为有帮助的次数
    used_count: int = 0  # 使用次数


@dataclass
class FailureCaseItem(BaseLearningItem):
    """失败案例库项"""
    failure_type: str = ""  # parse_error, timeout, auth_error, etc.
    error_message: str = ""
    input_snapshot: str = ""  # 输入数据的摘要（脱敏）
    root_cause: str = ""
    workaround: str = ""  # 临时解决方案
    permanent_fix: str = ""  # 永久修复方案
    fix_applied: bool = False


@dataclass
class TimeSensitiveItem(BaseLearningItem):
    """时效性知识项"""
    knowledge_type: str = "deadline"  # deadline, expiry, seasonal, urgent
    title: str = ""
    description: str = ""
    start_date: str = ""
    end_date: str = ""
    reminder_days: List[int] = field(default_factory=list)  # 提前提醒天数
    affected_domains: List[str] = field(default_factory=list)
    urgency_level: str = "normal"  # low, normal, high, critical
    auto_remind: bool = True


@dataclass
class LearningCollection:
    """某一类型的学习数据集合"""
    data_type: str
    version: str = "1.0.0"
    items: List[Dict[str, Any]] = field(default_factory=list)
    last_updated: str = field(default_factory=lambda: datetime.now().isoformat())
    item_count: int = 0
    
    def __post_init__(self):
        self.item_count = len(self.items)


@dataclass
class LearningPackage:
    """统一学习包（v2.0 Schema）"""
    # 元数据
    schema_version: str = "2.0.0"
    package_id: str = field(default_factory=lambda: hashlib.md5(
        datetime.now().isoformat().encode()
    ).hexdigest()[:16])
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    source_device: str = "unknown"
    
    # 数据集合（8种核心类型）
    collections: Dict[str, LearningCollection] = field(default_factory=dict)
    
    # 统计信息
    total_items: int = 0
    data_hash: str = ""
    priority_score: float = 0.5  # 0-1，用于云端排序
    
    def __post_init__(self):
        self._calculate_stats()
    
    def _calculate_stats(self):
        """计算统计信息"""
        self.total_items = sum(
            c.item_count for c in self.collections.values()
        )
        self.data_hash = self._calculate_hash()
        # 优先级基于验证次数和内容新鲜度
        self.priority_score = self._calculate_priority()
    
    def _calculate_hash(self) -> str:
        """计算整体指纹"""
        data = json.dumps({
            "schema": self.schema_version,
            "collections": {
                k: [item.get("id", "") for item in v.items]
                for k, v in self.collections.items()
            }
        }, sort_keys=True, ensure_ascii=False)
        return hashlib.md5(data.encode()).hexdigest()
    
    def _calculate_priority(self) -> float:
        """计算优先级分数"""
        if not self.collections:
            return 0.5
        
        total_validation = 0
        total_items = 0
        
        for coll in self.collections.values():
            for item in coll.items:
                total_validation += item.get("validation_count", 0)
                total_items += 1
        
        if total_items == 0:
            return 0.5
        
        # 基础0.5 + 验证次数带来的加成（最多0.5）
        avg_validation = total_validation / total_items
        return min(0.5 + (avg_validation / 20) * 0.5, 1.0)
    
    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典"""
        return {
            "schema_version": self.schema_version,
            "package_id": self.package_id,
            "created_at": self.created_at,
            "source_device": self.source_device,
            "collections": {
                k: {
                    "data_type": v.data_type,
                    "version": v.version,
                    "last_updated": v.last_updated,
                    "item_count": v.item_count,
                    "items": v.items
                }
                for k, v in self.collections.items()
            },
            "total_items": self.total_items,
            "data_hash": self.data_hash,
            "priority_score": self.priority_score
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LearningPackage':
        """从字典反序列化"""
        collections = {}
        for key, coll_data in data.get("collections", {}).items():
            collections[key] = LearningCollection(
                data_type=coll_data.get("data_type", key),
                version=coll_data.get("version", "1.0.0"),
                items=coll_data.get("items", []),
                last_updated=coll_data.get("last_updated", datetime.now().isoformat())
            )
        
        return cls(
            schema_version=data.get("schema_version", "2.0.0"),
            package_id=data.get("package_id", ""),
            created_at=data.get("created_at", datetime.now().isoformat()),
            source_device=data.get("source_device", "unknown"),
            collections=collections,
            total_items=data.get("total_items", 0),
            data_hash=data.get("data_hash", ""),
            priority_score=data.get("priority_score", 0.5)
        )
    
    def add_item(self, data_type: str, item: Dict[str, Any]) -> bool:
        """添加学习项"""
        if data_type not in self.collections:
            self.collections[data_type] = LearningCollection(
                data_type=data_type,
                items=[]
            )
        
        # 检查ID是否已存在（简单去重）
        existing_ids = {i.get("id") for i in self.collections[data_type].items}
        if item.get("id") in existing_ids:
            return False
        
        self.collections[data_type].items.append(item)
        self.collections[data_type].item_count += 1
        self._calculate_stats()
        return True
    
    def get_merge_stats(self, other: 'LearningPackage') -> Dict[str, int]:
        """计算与其他包的合并统计"""
        stats = {}
        for data_type, coll in other.collections.items():
            if data_type not in self.collections:
                stats[data_type] = coll.item_count
            else:
                existing_ids = {i.get("id") for i in self.collections[data_type].items}
                new_count = sum(
                    1 for item in coll.items 
                    if item.get("id") not in existing_ids
                )
                stats[data_type] = new_count
        return stats


# ============================================================
# 数据验证函数
# ============================================================

def validate_discovery(item: Dict[str, Any]) -> bool:
    """验证发现项"""
    required = ["id", "keyword", "context"]
    return all(field in item for field in required)


def validate_policy(item: Dict[str, Any]) -> bool:
    """验证政策项"""
    required = ["id", "title", "context"]
    return all(field in item for field in required)


def validate_model_param(item: Dict[str, Any]) -> bool:
    """验证模型参数项"""
    required = ["id", "risk_domain", "param_name", "param_value"]
    return all(field in item for field in required)


def validate_trigger_word(item: Dict[str, Any]) -> bool:
    """验证触发词项"""
    required = ["id", "word"]
    return all(field in item for field in required)


VALIDATORS = {
    DataType.DISCOVERIES.value: validate_discovery,
    DataType.POLICY_UPDATES.value: validate_policy,
    DataType.MODEL_PARAMETERS.value: validate_model_param,
    DataType.TRIGGER_WORDS.value: validate_trigger_word,
}


def validate_package(package: LearningPackage) -> tuple[bool, List[str]]:
    """验证整个学习包
    
    Returns:
        (是否有效, 错误信息列表)
    """
    errors = []
    
    # 检查schema版本
    if package.schema_version != "2.0.0":
        errors.append(f"不支持的schema版本: {package.schema_version}")
    
    # 验证各集合
    for data_type, coll in package.collections.items():
        validator = VALIDATORS.get(data_type)
        if validator:
            invalid_items = [
                item.get("id", "unknown") 
                for item in coll.items 
                if not validator(item)
            ]
            if invalid_items:
                errors.append(f"{data_type}中有{len(invalid_items)}项验证失败: {invalid_items[:3]}")
    
    return len(errors) == 0, errors


# ============================================================
# 工具函数
# ============================================================

def create_empty_package(source_device: str = "local") -> LearningPackage:
    """创建空的学习包"""
    return LearningPackage(
        source_device=source_device,
        collections={}
    )


def migrate_v1_to_v2(v1_data: Dict[str, Any]) -> LearningPackage:
    """将v1数据迁移到v2格式"""
    package = create_empty_package(source_device="migrated_v1")
    
    # 迁移discoveries
    for item in v1_data.get("discoveries", []):
        if validate_discovery(item):
            package.add_item(DataType.DISCOVERIES.value, item)
    
    # 迁移policy_updates
    for item in v1_data.get("policy_updates", []):
        if validate_policy(item):
            package.add_item(DataType.POLICY_UPDATES.value, item)
    
    # 迁移training_cases
    for item in v1_data.get("training_cases", []):
        package.add_item(DataType.TRAINING_CASES.value, item)
    
    # 迁移user_profiles
    profiles = v1_data.get("user_profiles", {})
    for uscc, profile in profiles.items():
        profile["id"] = f"profile_{uscc}"
        profile["uscc_masked"] = uscc
        package.add_item(DataType.USER_PROFILES.value, profile)
    
    return package


if __name__ == "__main__":
    # 测试代码
    print("[TEST] Testing learn_schema.py...")
    
    # 创建空包
    pkg = create_empty_package("test_device")
    
    # 添加测试数据
    pkg.add_item(DataType.DISCOVERIES.value, {
        "id": "test_001",
        "keyword": "研发费用",
        "context": "制造业研发加计扣除",
        "confidence": 0.8
    })
    
    pkg.add_item(DataType.MODEL_PARAMETERS.value, {
        "id": "param_001",
        "risk_domain": "rd_expense",
        "param_name": "threshold_high",
        "param_value": 0.85,
        "confidence": 0.75
    })
    
    # 验证
    valid, errors = validate_package(pkg)
    print(f"[TEST] Package valid: {valid}")
    if errors:
        print(f"[TEST] Errors: {errors}")
    
    # 序列化测试
    data = pkg.to_dict()
    print(f"[TEST] Serialized keys: {list(data.keys())}")
    print(f"[TEST] Total items: {data['total_items']}")
    
    # 反序列化测试
    pkg2 = LearningPackage.from_dict(data)
    print(f"[TEST] Deserialized collections: {list(pkg2.collections.keys())}")
    
    print("[TEST] All tests passed!")
