#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 云端聚合引擎 (Cloud Aggregation Engine)
处理多用户数据的去重、冲突解决、智能合并

功能：
1. 指纹去重 - 基于内容hash去重
2. 冲突解决 - 时间戳优先 + 可信度评分
3. 智能合并 - 相似内容归一化
4. 信任评分 - 基于贡献者历史质量加权

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import io
import json
import hashlib
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Set
from collections import defaultdict

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True


# ============================================================
# 去重键生成策略
# ============================================================

class DedupKeyStrategy:
    """去重键生成策略"""
    
    @staticmethod
    def get_key_for_discovery(item: Dict[str, Any]) -> str:
        """关键词发现的去重键：keyword本身"""
        return item.get("keyword", "").lower().strip()
    
    @staticmethod
    def get_key_for_policy(item: Dict[str, Any]) -> str:
        """政策更新的去重键：title"""
        return item.get("title", "").lower().strip()
    
    @staticmethod
    def get_key_for_model_param(item: Dict[str, Any]) -> str:
        """模型参数的去重键：domain + param_name"""
        return f"{item.get('risk_domain', '')}:{item.get('param_name', '')}"
    
    @staticmethod
    def get_key_for_trigger_word(item: Dict[str, Any]) -> str:
        """触发词的去重键：word本身"""
        return item.get("word", "").lower().strip()
    
    @staticmethod
    def get_key_for_workflow_tuning(item: Dict[str, Any]) -> str:
        """工作流调优的去重键：step_id + parameter"""
        return f"{item.get('step_id', '')}:{item.get('parameter', '')}"
    
    @staticmethod
    def get_key_for_industry_feature(item: Dict[str, Any]) -> str:
        """行业特征的去重键：feature_key"""
        return item.get("feature_key", "")
    
    @staticmethod
    def get_key_for_feedback(item: Dict[str, Any]) -> str:
        """反馈模式的的去重键：pattern_hash"""
        return item.get("pattern_hash", "")
    
    @staticmethod
    def get_key_for_failure(item: Dict[str, Any]) -> str:
        """失败案例的去重键：failure_type + error_message前20字符"""
        msg = item.get("error_message", "")[:20]
        return f"{item.get('failure_type', '')}:{msg}"
    
    @staticmethod
    def get_key_for_time_sensitive(item: Dict[str, Any]) -> str:
        """时效性知识的去重键：title"""
        return item.get("title", "").lower().strip()
    
    @staticmethod
    def get_key_for_training_case(item: Dict[str, Any]) -> str:
        """训练案例的去重键：case_id"""
        return item.get("case_id", "")
    
    @staticmethod
    def get_key_for_user_profile(item: Dict[str, Any]) -> str:
        """用户画像的去重键：uscc_masked"""
        return item.get("uscc_masked", "")
    
    @classmethod
    def get_key(cls, data_type: str, item: Dict[str, Any]) -> str:
        """统一获取去重键"""
        strategies = {
            "discoveries": cls.get_key_for_discovery,
            "policy_updates": cls.get_key_for_policy,
            "model_parameters": cls.get_key_for_model_param,
            "trigger_words": cls.get_key_for_trigger_word,
            "workflow_tuning": cls.get_key_for_workflow_tuning,
            "industry_features": cls.get_key_for_industry_feature,
            "feedback_patterns": cls.get_key_for_feedback,
            "failure_cases": cls.get_key_for_failure,
            "time_sensitive": cls.get_key_for_time_sensitive,
            "training_cases": cls.get_key_for_training_case,
            "user_profiles": cls.get_key_for_user_profile,
        }
        strategy = strategies.get(data_type)
        if strategy:
            return strategy(item)
        return item.get("id", "")


# ============================================================
# 冲突解决策略
# ============================================================

class ConflictResolver:
    """冲突解决器"""
    
    def __init__(self):
        self.resolution_stats = {
            "total_conflicts": 0,
            "resolved": 0,
            "skipped": 0
        }
    
    def resolve(self, local_item: Dict[str, Any], 
                remote_item: Dict[str, Any], 
                data_type: str) -> Tuple[Dict[str, Any], str]:
        """
        解决冲突
        
        Returns:
            (胜出项, 解决策略)
        """
        self.resolution_stats["total_conflicts"] += 1
        
        # 策略1：版本号优先
        local_ver = self._parse_version(local_item.get("version", "1.0.0"))
        remote_ver = self._parse_version(remote_item.get("version", "1.0.0"))
        
        if remote_ver > local_ver:
            self.resolution_stats["resolved"] += 1
            return remote_item, "version_priority"
        elif local_ver > remote_ver:
            self.resolution_stats["resolved"] += 1
            return local_item, "local_newer"
        
        # 策略2：可信度评分优先
        local_conf = local_item.get("validation_count", 0) * local_item.get("confidence", 0.5)
        remote_conf = remote_item.get("validation_count", 0) * remote_item.get("confidence", 0.5)
        
        if remote_conf > local_conf * 1.2:  # 远程显著更高
            self.resolution_stats["resolved"] += 1
            return remote_item, "confidence_priority"
        elif local_conf > remote_conf * 1.2:
            self.resolution_stats["resolved"] += 1
            return local_item, "local_confidence"
        
        # 策略3：时间戳优先
        local_time = local_item.get("created_at", "2000-01-01")
        remote_time = remote_item.get("created_at", "2000-01-01")
        
        if remote_time > local_time:
            self.resolution_stats["resolved"] += 1
            return remote_item, "timestamp_priority"
        
        # 默认：保留本地
        self.resolution_stats["resolved"] += 1
        return local_item, "local_default"
    
    def _parse_version(self, version: str) -> Tuple[int, ...]:
        """解析版本号为元组以便比较"""
        try:
            parts = version.split(".")
            return tuple(int(p) for p in parts[:3])
        except:
            return (1, 0, 0)
    
    def get_stats(self) -> Dict[str, int]:
        """获取冲突解决统计"""
        return self.resolution_stats.copy()


# ============================================================
# 智能合并引擎
# ============================================================

class SmartMerger:
    """智能合并引擎"""
    
    def __init__(self):
        self.merge_stats = defaultdict(lambda: {"added": 0, "merged": 0, "skipped": 0})
    
    def merge_collections(self, local_coll: List[Dict[str, Any]], 
                         remote_coll: List[Dict[str, Any]], 
                         data_type: str) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
        """
        合并两个集合
        
        Returns:
            (合并后的集合, 统计信息)
        """
        resolver = ConflictResolver()
        result = []
        local_keys = {}
        
        # 建立本地索引
        for item in local_coll:
            key = DedupKeyStrategy.get_key(data_type, item)
            local_keys[key] = item
        
        # 先添加所有本地项
        result.extend(local_coll)
        
        # 处理远程项
        for remote_item in remote_coll:
            key = DedupKeyStrategy.get_key(data_type, remote_item)
            
            if key in local_keys:
                # 冲突：需要解决
                local_item = local_keys[key]
                winner, strategy = resolver.resolve(local_item, remote_item, data_type)
                
                # 替换本地项
                for i, item in enumerate(result):
                    if DedupKeyStrategy.get_key(data_type, item) == key:
                        result[i] = winner
                        break
                
                self.merge_stats[data_type]["merged"] += 1
            else:
                # 新增项
                result.append(remote_item)
                self.merge_stats[data_type]["added"] += 1
        
        stats = dict(self.merge_stats[data_type])
        return result, stats
    
    def merge_packages(self, local_pkg: Dict[str, Any], 
                      remote_pkg: Dict[str, Any]) -> Dict[str, Any]:
        """
        合并两个学习包
        
        Returns:
            合并后的包
        """
        result = {
            "schema_version": "2.0.0",
            "package_id": local_pkg.get("package_id", "merged"),
            "created_at": datetime.now().isoformat(),
            "source_device": "merged",
            "collections": {},
            "total_items": 0,
            "data_hash": "",
            "priority_score": 0.0
        }
        
        local_colls = local_pkg.get("collections", {})
        remote_colls = remote_pkg.get("collections", {})
        
        # 合并所有类型的集合
        all_types = set(local_colls.keys()) | set(remote_colls.keys())
        total_items = 0
        
        for data_type in all_types:
            local_items = local_colls.get(data_type, {}).get("items", [])
            remote_items = remote_colls.get(data_type, {}).get("items", [])
            
            merged_items, stats = self.merge_collections(local_items, remote_items, data_type)
            
            result["collections"][data_type] = {
                "data_type": data_type,
                "version": self._calculate_merged_version(
                    local_colls.get(data_type, {}).get("version", "1.0.0"),
                    remote_colls.get(data_type, {}).get("version", "1.0.0")
                ),
                "last_updated": datetime.now().isoformat(),
                "item_count": len(merged_items),
                "items": merged_items
            }
            
            total_items += len(merged_items)
        
        result["total_items"] = total_items
        result["data_hash"] = self._calculate_package_hash(result)
        result["priority_score"] = self._calculate_priority(result)
        
        return result
    
    def _calculate_merged_version(self, v1: str, v2: str) -> str:
        """计算合并后的版本号"""
        try:
            parts1 = [int(x) for x in v1.split(".")]
            parts2 = [int(x) for x in v2.split(".")]
            
            # 取较大版本号，patch+1
            max_ver = max(parts1, parts2)
            max_ver[2] += 1  # patch版本+1
            return ".".join(str(x) for x in max_ver)
        except:
            return "1.0.1"
    
    def _calculate_package_hash(self, pkg: Dict[str, Any]) -> str:
        """计算包的指纹"""
        data = json.dumps({
            "schema": pkg.get("schema_version"),
            "collections": {
                k: [item.get("id", "") for item in v.get("items", [])]
                for k, v in pkg.get("collections", {}).items()
            }
        }, sort_keys=True, ensure_ascii=False)
        return hashlib.md5(data.encode()).hexdigest()
    
    def _calculate_priority(self, pkg: Dict[str, Any]) -> float:
        """计算优先级分数"""
        total_validation = 0
        total_items = 0
        
        for coll in pkg.get("collections", {}).values():
            for item in coll.get("items", []):
                total_validation += item.get("validation_count", 0)
                total_items += 1
        
        if total_items == 0:
            return 0.5
        
        avg_validation = total_validation / total_items
        return min(0.5 + (avg_validation / 20) * 0.5, 1.0)
    
    def get_merge_report(self) -> str:
        """生成合并报告"""
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("📊 云端数据聚合报告")
        lines.append("=" * 60)
        
        total_added = sum(s["added"] for s in self.merge_stats.values())
        total_merged = sum(s["merged"] for s in self.merge_stats.values())
        
        lines.append(f"\n  ✅ 新增项: {total_added}")
        lines.append(f"  🔄 合并项: {total_merged}")
        
        for data_type, stats in self.merge_stats.items():
            if stats["added"] > 0 or stats["merged"] > 0:
                lines.append(f"\n  📁 {data_type}:")
                lines.append(f"     ├─ 新增: {stats['added']}")
                lines.append(f"     └─ 合并: {stats['merged']}")
        
        lines.append("\n" + "=" * 60)
        return "\n".join(lines)


# ============================================================
# 相似内容归一化
# ============================================================

class SimilarityNormalizer:
    """相似内容归一化器"""
    
    def __init__(self, similarity_threshold: float = 0.85):
        self.threshold = similarity_threshold
    
    def normalize_trigger_words(self, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """归一化触发词（合并变体）"""
        groups = defaultdict(list)
        
        # 按词根分组
        for item in items:
            word = item.get("word", "").lower()
            # 简单归一化：去除常见变体后缀
            root = self._get_word_root(word)
            groups[root].append(item)
        
        result = []
        for root, group in groups.items():
            if len(group) == 1:
                result.append(group[0])
            else:
                # 合并相似项
                merged = self._merge_similar_items(group, "trigger_words")
                result.append(merged)
        
        return result
    
    def normalize_discoveries(self, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """归一化关键词发现"""
        seen_keywords = set()
        result = []
        
        for item in sorted(items, 
                          key=lambda x: x.get("validation_count", 0), 
                          reverse=True):
            keyword = item.get("keyword", "").lower().strip()
            
            # 检查是否已被包含
            if any(self._is_similar(keyword, seen) for seen in seen_keywords):
                continue
            
            seen_keywords.add(keyword)
            result.append(item)
        
        return result
    
    def _get_word_root(self, word: str) -> str:
        """获取词根（简单实现）"""
        # 去除常见后缀
        suffixes = ["s", "es", "ing", "ed", "tion", "ment"]
        for suffix in suffixes:
            if word.endswith(suffix):
                return word[:-len(suffix)]
        return word
    
    def _is_similar(self, word1: str, word2: str) -> bool:
        """判断两个词是否相似"""
        # 包含关系
        if word1 in word2 or word2 in word1:
            return True
        # 编辑距离（简单实现）
        return self._levenshtein_ratio(word1, word2) > self.threshold
    
    def _levenshtein_ratio(self, s1: str, s2: str) -> float:
        """计算Levenshtein相似度"""
        if len(s1) < len(s2):
            return self._levenshtein_ratio(s2, s1)
        
        if len(s2) == 0:
            return 0.0
        
        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row
        
        distance = previous_row[-1]
        max_len = max(len(s1), len(s2))
        return 1 - (distance / max_len)
    
    def _merge_similar_items(self, items: List[Dict[str, Any]], 
                            data_type: str) -> Dict[str, Any]:
        """合并相似项"""
        # 取验证次数最高的作为基础
        base = max(items, key=lambda x: x.get("validation_count", 0))
        
        merged = base.copy()
        merged["validation_count"] = sum(i.get("validation_count", 0) for i in items)
        merged["merged_from"] = [i.get("id") for i in items]
        merged["merge_count"] = len(items)
        
        return merged


# ============================================================
# 信任评分系统
# ============================================================

class TrustScorer:
    """内容信任评分器"""
    
    def __init__(self):
        self.contributor_history = {}
    
    def calculate_item_trust(self, item: Dict[str, Any], 
                            contributor_id: str = "") -> float:
        """
        计算单项内容的信任分数
        
        Returns:
            0-1之间的信任分数
        """
        score = 0.5  # 基础分
        
        # 因素1：验证次数
        validation = item.get("validation_count", 0)
        score += min(validation / 10, 0.3)  # 最多+0.3
        
        # 因素2：置信度
        confidence = item.get("confidence", 0.5)
        score += (confidence - 0.5) * 0.2  # 根据置信度调整
        
        # 因素3：贡献者历史
        if contributor_id:
            contributor_trust = self._get_contributor_trust(contributor_id)
            score += contributor_trust * 0.2  # 贡献者信任度加成
        
        # 因素4：内容完整性
        completeness = self._calculate_completeness(item)
        score += completeness * 0.1
        
        return min(max(score, 0.0), 1.0)
    
    def _get_contributor_trust(self, contributor_id: str) -> float:
        """获取贡献者信任度"""
        history = self.contributor_history.get(contributor_id, {
            "submissions": 0,
            "validations": 0,
            "rejections": 0
        })
        
        total = history["submissions"]
        if total == 0:
            return 0.5
        
        # 基于验证/拒绝比例计算
        good = history["validations"]
        bad = history["rejections"]
        
        return (good + 1) / (good + bad + 2)  # Laplace平滑
    
    def _calculate_completeness(self, item: Dict[str, Any]) -> float:
        """计算内容完整度"""
        required_fields = ["id", "created_at", "source"]
        optional_fields = ["validation_count", "confidence", "context"]
        
        has_required = sum(1 for f in required_fields if f in item)
        has_optional = sum(1 for f in optional_fields if f in item)
        
        return (has_required / len(required_fields)) * 0.7 + \
               (has_optional / len(optional_fields)) * 0.3
    
    def update_contributor(self, contributor_id: str, 
                          submission_validated: bool = True):
        """更新贡献者历史"""
        if contributor_id not in self.contributor_history:
            self.contributor_history[contributor_id] = {
                "submissions": 0,
                "validations": 0,
                "rejections": 0
            }
        
        self.contributor_history[contributor_id]["submissions"] += 1
        if submission_validated:
            self.contributor_history[contributor_id]["validations"] += 1
        else:
            self.contributor_history[contributor_id]["rejections"] += 1


# ============================================================
# 聚合引擎主类
# ============================================================

class AggregationEngine:
    """云端聚合引擎主类"""
    
    def __init__(self):
        self.merger = SmartMerger()
        self.normalizer = SimilarityNormalizer()
        self.trust_scorer = TrustScorer()
    
    def aggregate(self, packages: List[Dict[str, Any]], 
                 base_package: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        聚合多个学习包
        
        Args:
            packages: 多个用户的学习包
            base_package: 基础包（可选，通常是本地数据）
        
        Returns:
            聚合后的学习包
        """
        if not packages:
            return base_package or {"schema_version": "2.0.0", "collections": {}}
        
        # 从基础包或第一个包开始
        result = base_package or packages[0]
        
        # 逐个合并
        for pkg in packages[1:] if base_package else packages[1:]:
            result = self.merger.merge_packages(result, pkg)
        
        # 归一化处理
        result = self._normalize_result(result)
        
        # 计算信任分数
        result = self._calculate_trust_scores(result)
        
        return result
    
    def _normalize_result(self, pkg: Dict[str, Any]) -> Dict[str, Any]:
        """对结果进行归一化"""
        collections = pkg.get("collections", {})
        
        # 归一化触发词
        if "trigger_words" in collections:
            items = collections["trigger_words"].get("items", [])
            normalized = self.normalizer.normalize_trigger_words(items)
            collections["trigger_words"]["items"] = normalized
            collections["trigger_words"]["item_count"] = len(normalized)
        
        # 归一化发现
        if "discoveries" in collections:
            items = collections["discoveries"].get("items", [])
            normalized = self.normalizer.normalize_discoveries(items)
            collections["discoveries"]["items"] = normalized
            collections["discoveries"]["item_count"] = len(normalized)
        
        pkg["collections"] = collections
        return pkg
    
    def _calculate_trust_scores(self, pkg: Dict[str, Any]) -> Dict[str, Any]:
        """为所有项计算信任分数"""
        for coll in pkg.get("collections", {}).values():
            for item in coll.get("items", []):
                trust = self.trust_scorer.calculate_item_trust(item)
                item["trust_score"] = round(trust, 3)
        
        return pkg
    
    def get_aggregation_report(self) -> Dict[str, Any]:
        """获取聚合报告"""
        return {
            "merge_stats": dict(self.merger.merge_stats),
            "report_text": self.merger.get_merge_report()
        }


# ============================================================
# CLI接口
# ============================================================

def main():
    """测试入口"""
    print("[TEST] Testing learn_aggregator.py...")
    
    # 创建测试数据
    pkg1 = {
        "schema_version": "2.0.0",
        "collections": {
            "discoveries": {
                "data_type": "discoveries",
                "items": [
                    {"id": "d1", "keyword": "研发费用", "confidence": 0.8, "validation_count": 5},
                    {"id": "d2", "keyword": "加计扣除", "confidence": 0.7, "validation_count": 3}
                ]
            },
            "trigger_words": {
                "data_type": "trigger_words",
                "items": [
                    {"id": "t1", "word": "汇算清缴", "trigger_count": 10}
                ]
            }
        }
    }
    
    pkg2 = {
        "schema_version": "2.0.0",
        "collections": {
            "discoveries": {
                "data_type": "discoveries",
                "items": [
                    {"id": "d3", "keyword": "研发费用", "confidence": 0.9, "validation_count": 8},  # 冲突
                    {"id": "d4", "keyword": "风险预警", "confidence": 0.6, "validation_count": 2}
                ]
            },
            "model_parameters": {
                "data_type": "model_parameters",
                "items": [
                    {"id": "m1", "risk_domain": "rd", "param_name": "threshold", "param_value": 0.85}
                ]
            }
        }
    }
    
    # 测试聚合
    engine = AggregationEngine()
    result = engine.aggregate([pkg1, pkg2])
    
    print(f"[TEST] Aggregated package_id: {result.get('package_id')}")
    print(f"[TEST] Total items: {result.get('total_items')}")
    print(f"[TEST] Collections: {list(result.get('collections', {}).keys())}")
    
    # 显示合并报告
    report = engine.get_aggregation_report()
    print(report["report_text"])
    
    print("[TEST] All tests passed!")


if __name__ == "__main__":
    main()
