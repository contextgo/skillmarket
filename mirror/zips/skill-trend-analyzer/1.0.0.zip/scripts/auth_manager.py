#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 授权管理器 (Auth Manager)
处理API Key的验证、加密存储和授权引导

功能：
1. 智能提示策略（基于使用频次/功能价值）
2. Key输入界面（CLI交互）
3. Key验证（调用/ping API）
4. 本地加密存储（XOR+Base64）

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import io
import os
import json
import base64
import hashlib
import getpass
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, Tuple

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"
CONFIG_PATH = ASSETS_DIR / "user_config.json"

# 派生密钥（与learn_sync.py保持一致）
def derive_key() -> bytes:
    """从环境派生加密密钥"""
    seed = f"tax-risk-guard-v2-{os.getenv('COMPUTERNAME', 'default')[:4]}"
    return hashlib.sha256(seed.encode()).digest()


def xor_encrypt(plaintext: str, key: bytes) -> str:
    """XOR加密+Base64编码"""
    data = plaintext.encode('utf-8')
    key_len = len(key)
    encrypted = bytes(data[i] ^ key[i % key_len] for i in range(len(data)))
    return base64.b64encode(encrypted).decode('ascii')


def xor_decrypt(ciphertext: str, key: bytes) -> str:
    """Base64解码+XOR解密"""
    try:
        encrypted = base64.b64decode(ciphertext)
        key_len = len(key)
        decrypted = bytes(encrypted[i] ^ key[i % key_len] for i in range(len(encrypted)))
        return decrypted.decode('utf-8')
    except Exception:
        return ""


class AuthManager:
    """授权管理器"""
    
    def __init__(self):
        self.config = self._load_config()
        self.key = derive_key()
        self._api_client = None
    
    def _load_config(self) -> Dict[str, Any]:
        """加载用户配置"""
        if CONFIG_PATH.exists():
            try:
                with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return self._default_config()
    
    def _save_config(self):
        """保存用户配置"""
        ASSETS_DIR.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
        
        # 设置文件权限（仅Windows支持）
        try:
            os.chmod(CONFIG_PATH, 0o600)
        except:
            pass
    
    def _default_config(self) -> Dict[str, Any]:
        """默认配置"""
        return {
            "version": "1.0.0",
            "auth": {
                "api_key_encrypted": None,
                "key_verified": False,
                "verified_at": None
            },
            "usage_stats": {
                "total_scans": 0,
                "total_queries": 0,
                "first_use_date": None,
                "last_use_date": None
            },
            "prompt_tracking": {
                "auth_prompt_count": 0,
                "last_prompt_date": None,
                "user_declined": False
            }
        }
    
    def _get_api_client(self):
        """延迟导入API客户端"""
        if self._api_client is None:
            try:
                from learn_sync_v2 import LearningAPIClient
                self._api_client = LearningAPIClient()
            except ImportError:
                from learn_sync import LearningAPIClient
                self._api_client = LearningAPIClient()
        return self._api_client
    
    # ============================================================
    # 核心API
    # ============================================================
    
    def has_valid_key(self) -> bool:
        """检查是否有有效的授权key"""
        auth = self.config.get("auth", {})
        return auth.get("key_verified", False) and auth.get("api_key_encrypted") is not None
    
    def get_key(self) -> Optional[str]:
        """获取解密后的key（谨慎使用）"""
        auth = self.config.get("auth", {})
        encrypted = auth.get("api_key_encrypted")
        if encrypted:
            return xor_decrypt(encrypted, self.key)
        return None
    
    def verify_and_store_key(self, api_key: str) -> Tuple[bool, str]:
        """
        验证key并存储
        
        Returns:
            (是否成功, 提示信息)
        """
        if not api_key or len(api_key) < 8:
            return False, "Key格式无效（至少需要8位字符）"
        
        # 验证key可用性
        print("  🔍 正在验证Key...")
        try:
            client = self._get_api_client()
            is_valid = client.verify_key(api_key)
        except Exception as e:
            return False, f"验证失败：{str(e)}"
        
        if not is_valid:
            return False, "Key验证失败，请检查Key是否正确或联系作者"
        
        # 加密存储
        encrypted = xor_encrypt(api_key, self.key)
        self.config["auth"]["api_key_encrypted"] = encrypted
        self.config["auth"]["key_verified"] = True
        self.config["auth"]["verified_at"] = datetime.now().isoformat()
        self._save_config()
        
        # 清除内存中的明文key
        del api_key
        
        return True, "✅ Key验证成功并已安全存储"
    
    def clear_key(self):
        """清除存储的key"""
        self.config["auth"]["api_key_encrypted"] = None
        self.config["auth"]["key_verified"] = False
        self.config["auth"]["verified_at"] = None
        self._save_config()
    
    # ============================================================
    # 智能提示策略
    # ============================================================
    
    def should_prompt_for_auth(self, context: str = "general") -> Tuple[bool, str]:
        """
        判断是否应该在当前场景提示授权
        
        Args:
            context: 场景类型（scan/query/general）
        
        Returns:
            (是否应该提示, 提示原因)
        """
        # 已有有效key，不提示
        if self.has_valid_key():
            return False, ""
        
        # 用户明确拒绝过，降低提示频率
        tracking = self.config.get("prompt_tracking", {})
        if tracking.get("user_declined", False):
            prompt_count = tracking.get("auth_prompt_count", 0)
            # 拒绝后每5次才提示一次
            if prompt_count % 5 != 0:
                return False, "user_declined"
        
        stats = self.config.get("usage_stats", {})
        total_usage = stats.get("total_scans", 0) + stats.get("total_queries", 0)
        
        # 场景化提示策略
        if context == "scan":
            # 扫描完成后提示（价值已体现）
            if total_usage >= 1:
                return True, f"已完成{total_usage}次风险扫描，授权后可获取更多知识库更新"
        
        elif context == "query":
            # 知识查询第3次后提示
            if stats.get("total_queries", 0) >= 3:
                return True, "已多次查询税务知识，授权可解锁云端共享数据"
        
        elif context == "general":
            # 首次使用或每10次使用后
            if total_usage == 0:
                return True, "首次使用，授权后可获取最新知识库和持续迭代新功能"
            elif total_usage % 10 == 0 and total_usage > 0:
                return True, f"已使用{total_usage}次，授权可获取更多功能"
        
        return False, ""
    
    def record_prompt_shown(self):
        """记录提示已展示"""
        tracking = self.config.get("prompt_tracking", {})
        tracking["auth_prompt_count"] = tracking.get("auth_prompt_count", 0) + 1
        tracking["last_prompt_date"] = datetime.now().isoformat()
        self.config["prompt_tracking"] = tracking
        self._save_config()
    
    def record_user_declined(self):
        """记录用户拒绝授权"""
        self.config["prompt_tracking"]["user_declined"] = True
        self._save_config()
    
    def record_usage(self, usage_type: str = "scan"):
        """记录使用统计"""
        stats = self.config.get("usage_stats", {})
        
        if stats.get("first_use_date") is None:
            stats["first_use_date"] = datetime.now().isoformat()
        
        stats["last_use_date"] = datetime.now().isoformat()
        
        if usage_type == "scan":
            stats["total_scans"] = stats.get("total_scans", 0) + 1
        elif usage_type == "query":
            stats["total_queries"] = stats.get("total_queries", 0) + 1
        
        self.config["usage_stats"] = stats
        self._save_config()
    
    # ============================================================
    # CLI交互界面
    # ============================================================
    
    def show_auth_guide(self, reason: str = ""):
        """展示授权引导"""
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("🔐 授权激活 - 解锁完整功能")
        lines.append("=" * 60)
        
        if reason:
            lines.append(f"\n💡 {reason}")
        
        lines.append("\n📋 授权后您将获得：")
        lines.append("   ✓ 云端知识库实时同步更新")
        lines.append("   ✓ 其他用户贡献的风险案例")
        lines.append("   ✓ 最新政策解读和应对策略")
        lines.append("   ✓ 智能学习优化的风险模型")
        lines.append("   ✓ 定期学习成果报告")
        
        lines.append("\n📧 获取授权方式：")
        lines.append("   QQ：1817694478")
        lines.append("   Q群：972156177")
        
        lines.append("\n💰 授权费用：")
        lines.append("   个人用户：免费（需加群申请）")
        lines.append("   企业用户：联系作者咨询")
        
        lines.append("\n" + "-" * 60)
        lines.append("选项：")
        lines.append("   [1] 我已获得Key，立即输入")
        lines.append("   [2] 稍后提醒")
        lines.append("   [3] 暂不需要")
        lines.append("=" * 60)
        
        print("\n".join(lines))
    
    def prompt_for_key(self) -> Tuple[bool, str]:
        """
        交互式提示用户输入key
        
        Returns:
            (是否成功获取并验证, 提示信息)
        """
        self.show_auth_guide()
        
        try:
            choice = input("\n请选择 [1/2/3]: ").strip()
        except (KeyboardInterrupt, EOFError):
            return False, "用户取消"
        
        if choice == "1":
            return self._input_key_interactive()
        elif choice == "2":
            self.record_prompt_shown()
            return False, "已设置稍后提醒"
        elif choice == "3":
            self.record_user_declined()
            return False, "用户暂不需要授权"
        else:
            return False, "无效选择"
    
    def _input_key_interactive(self) -> Tuple[bool, str]:
        """交互式输入key"""
        print("\n" + "-" * 60)
        print("请输入授权Key（输入将隐藏显示）：")
        
        try:
            api_key = getpass.getpass("Key: ").strip()
        except (KeyboardInterrupt, EOFError):
            return False, "用户取消输入"
        
        if not api_key:
            return False, "Key不能为空"
        
        success, message = self.verify_and_store_key(api_key)
        
        if success:
            print(f"\n{message}")
            print("\n🎉 授权成功！正在为您同步云端数据...")
            return True, api_key
        else:
            print(f"\n❌ {message}")
            retry = input("是否重试？[y/n]: ").strip().lower()
            if retry == 'y':
                return self._input_key_interactive()
            return False, message
    
    def prompt_if_needed(self, context: str = "general") -> Tuple[bool, str]:
        """
        如果需要，则提示授权
        
        Returns:
            (是否获得了新授权, 提示信息)
        """
        should_prompt, reason = self.should_prompt_for_auth(context)
        
        if not should_prompt:
            return False, ""
        
        self.show_auth_guide(reason)
        
        try:
            choice = input("\n请选择 [1/2/3]: ").strip()
        except (KeyboardInterrupt, EOFError):
            return False, "用户取消"
        
        if choice == "1":
            return self._input_key_interactive()
        elif choice == "2":
            self.record_prompt_shown()
            return False, "稍后提醒"
        elif choice == "3":
            self.record_user_declined()
            return False, "暂不需要"
        
        return False, "无效选择"
    
    # ============================================================
    # 状态显示
    # ============================================================
    
    def show_status(self):
        """显示授权状态"""
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("📊 授权状态")
        lines.append("=" * 60)
        
        if self.has_valid_key():
            lines.append("\n  ✅ 授权状态：已激活")
            verified_at = self.config["auth"].get("verified_at", "未知")
            lines.append(f"  🕐 验证时间：{verified_at}")
        else:
            lines.append("\n  ❌ 授权状态：未激活")
            lines.append("  💡 授权后可获取云端知识库同步和持续更新")
        
        stats = self.config.get("usage_stats", {})
        lines.append(f"\n  📈 使用统计：")
        lines.append(f"     - 风险扫描次数：{stats.get('total_scans', 0)}")
        lines.append(f"     - 知识查询次数：{stats.get('total_queries', 0)}")
        
        first_use = stats.get("first_use_date")
        if first_use:
            lines.append(f"     - 首次使用：{first_use}")
        
        lines.append("=" * 60)
        print("\n".join(lines))


# ============================================================
# CLI入口
# ============================================================

def main():
    """测试入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='授权管理器')
    parser.add_argument('--status', action='store_true', help='查看授权状态')
    parser.add_argument('--setup', action='store_true', help='设置授权Key')
    parser.add_argument('--clear', action='store_true', help='清除授权')
    parser.add_argument('--test', action='store_true', help='测试提示流程')
    
    args = parser.parse_args()
    
    auth = AuthManager()
    
    if args.status:
        auth.show_status()
    elif args.setup:
        success, msg = auth.prompt_for_key()
        print(f"\n结果：{msg}")
    elif args.clear:
        auth.clear_key()
        print("✅ 授权已清除")
    elif args.test:
        # 模拟扫描场景
        auth.record_usage("scan")
        success, msg = auth.prompt_if_needed("scan")
        print(f"\n结果：{msg}")
    else:
        auth.show_status()


if __name__ == "__main__":
    main()
