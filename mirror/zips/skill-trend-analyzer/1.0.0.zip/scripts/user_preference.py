#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 用户偏好系统 (User Preference System)
管理用户更新偏好、通知设置等个性化配置

功能：
1. 更新模式偏好（auto/ask/manual）
2. 通知频率设置
3. 本地JSON存储

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import io
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List
from enum import Enum

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"
PREF_PATH = ASSETS_DIR / "user_preference.json"


class UpdateMode(Enum):
    """更新模式"""
    AUTO = "auto"      # 自动更新，静默执行
    ASK = "ask"        # 询问模式，提示用户确认
    MANUAL = "manual"  # 手动模式，仅CLI触发


class NotificationFrequency(Enum):
    """通知频率"""
    ALWAYS = "always"   # 每次都有更新都通知
    DAILY = "daily"     # 每天汇总通知一次
    WEEKLY = "weekly"   # 每周汇总通知一次
    NEVER = "never"     # 不主动通知


class UserPreference:
    """用户偏好管理器"""
    
    # 默认值
    DEFAULTS = {
        "update_mode": UpdateMode.ASK.value,           # 默认询问模式
        "notification_frequency": NotificationFrequency.DAILY.value,
        "auto_sync_on_start": True,                    # 启动时自动同步
        "show_achievement_on_update": True,            # 更新后展示成果
        "collect_feedback": True,                      # 收集用户反馈
        "report_generation": "weekly",                 # 报告生成频率
        "quiet_hours": {                               # 免打扰时段
            "enabled": False,
            "start": "22:00",
            "end": "08:00"
        },
        "display_preferences": {
            "show_progress_bar": True,
            "show_emoji": True,
            "detail_level": "standard"  # brief/standard/detailed
        }
    }
    
    def __init__(self):
        self.preferences = self._load_preferences()
    
    def _load_preferences(self) -> Dict[str, Any]:
        """加载用户偏好"""
        if PREF_PATH.exists():
            try:
                with open(PREF_PATH, 'r', encoding='utf-8') as f:
                    loaded = json.load(f)
                    # 合并默认值（处理新增字段）
                    return self._merge_with_defaults(loaded)
            except Exception as e:
                print(f"[WARN] 加载偏好设置失败：{e}，使用默认设置")
        return self._default_preferences()
    
    def _save_preferences(self):
        """保存用户偏好"""
        ASSETS_DIR.mkdir(parents=True, exist_ok=True)
        with open(PREF_PATH, 'w', encoding='utf-8') as f:
            json.dump(self.preferences, f, ensure_ascii=False, indent=2)
    
    def _default_preferences(self) -> Dict[str, Any]:
        """默认偏好配置"""
        return {
            "version": "1.0.0",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            **self.DEFAULTS
        }
    
    def _merge_with_defaults(self, loaded: Dict[str, Any]) -> Dict[str, Any]:
        """将加载的配置与默认值合并"""
        merged = self._default_preferences()
        for key, value in loaded.items():
            if key in merged:
                if isinstance(value, dict) and isinstance(merged[key], dict):
                    merged[key].update(value)
                else:
                    merged[key] = value
            else:
                merged[key] = value
        return merged
    
    # ============================================================
    #  getter/setter
    # ============================================================
    
    def get(self, key: str, default=None) -> Any:
        """获取配置项"""
        return self.preferences.get(key, default)
    
    def set(self, key: str, value: Any):
        """设置配置项"""
        self.preferences[key] = value
        self.preferences["updated_at"] = datetime.now().isoformat()
        self._save_preferences()
    
    def get_update_mode(self) -> UpdateMode:
        """获取更新模式"""
        mode = self.preferences.get("update_mode", UpdateMode.ASK.value)
        try:
            return UpdateMode(mode)
        except ValueError:
            return UpdateMode.ASK
    
    def set_update_mode(self, mode: UpdateMode):
        """设置更新模式"""
        self.set("update_mode", mode.value)
    
    def get_notification_frequency(self) -> NotificationFrequency:
        """获取通知频率"""
        freq = self.preferences.get("notification_frequency", 
                                     NotificationFrequency.DAILY.value)
        try:
            return NotificationFrequency(freq)
        except ValueError:
            return NotificationFrequency.DAILY
    
    def set_notification_frequency(self, freq: NotificationFrequency):
        """设置通知频率"""
        self.set("notification_frequency", freq.value)
    
    def should_auto_sync(self) -> bool:
        """是否应该自动同步"""
        return self.preferences.get("auto_sync_on_start", True)
    
    def should_show_achievement(self) -> bool:
        """是否应该展示成果"""
        return self.preferences.get("show_achievement_on_update", True)
    
    def should_collect_feedback(self) -> bool:
        """是否应该收集反馈"""
        return self.preferences.get("collect_feedback", True)
    
    def is_quiet_hours(self) -> bool:
        """当前是否处于免打扰时段"""
        quiet = self.preferences.get("quiet_hours", {})
        if not quiet.get("enabled", False):
            return False
        
        from datetime import time
        now = datetime.now().time()
        start_str = quiet.get("start", "22:00")
        end_str = quiet.get("end", "08:00")
        
        start = datetime.strptime(start_str, "%H:%M").time()
        end = datetime.strptime(end_str, "%H:%M").time()
        
        if start > end:  # 跨午夜
            return now >= start or now <= end
        else:
            return start <= now <= end
    
    def get_detail_level(self) -> str:
        """获取详情级别"""
        display = self.preferences.get("display_preferences", {})
        return display.get("detail_level", "standard")
    
    # ============================================================
    # 更新决策
    # ============================================================
    
    def decide_update_action(self, update_info: Dict[str, Any]) -> str:
        """
        根据偏好决定更新操作
        
        Args:
            update_info: 更新信息（items_count, categories等）
        
        Returns:
            操作类型："auto" / "ask" / "skip"
        """
        mode = self.get_update_mode()
        
        if mode == UpdateMode.AUTO:
            return "auto"
        elif mode == UpdateMode.MANUAL:
            return "skip"
        else:  # ASK模式，根据更新规模决定
            items_count = update_info.get("items_count", 0)
            
            # 大量更新（>50项），建议询问
            if items_count > 50:
                return "ask"
            
            # 包含关键类型更新，建议询问
            critical_types = ["policy_updates", "model_parameters"]
            categories = update_info.get("categories", [])
            if any(cat in critical_types for cat in categories):
                return "ask"
            
            # 小规模更新，自动执行
            return "auto"
    
    def should_notify(self, last_notify_time: Optional[datetime] = None) -> bool:
        """
        根据通知频率判断是否应当发送通知
        
        Args:
            last_notify_time: 上次通知时间
        
        Returns:
            是否应该通知
        """
        # 免打扰时段
        if self.is_quiet_hours():
            return False
        
        freq = self.get_notification_frequency()
        
        if freq == NotificationFrequency.NEVER:
            return False
        elif freq == NotificationFrequency.ALWAYS:
            return True
        
        if last_notify_time is None:
            return True
        
        now = datetime.now()
        delta = now - last_notify_time
        
        if freq == NotificationFrequency.DAILY:
            return delta.days >= 1
        elif freq == NotificationFrequency.WEEKLY:
            return delta.days >= 7
        
        return True
    
    # ============================================================
    # CLI交互
    # ============================================================
    
    def show_preferences(self):
        """显示当前偏好设置"""
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("⚙️  用户偏好设置")
        lines.append("=" * 60)
        
        mode = self.get_update_mode()
        mode_desc = {
            UpdateMode.AUTO: "自动（静默更新）",
            UpdateMode.ASK: "询问（提示确认）",
            UpdateMode.MANUAL: "手动（仅CLI触发）"
        }
        lines.append(f"\n  🔄 更新模式：{mode_desc.get(mode, mode.value)}")
        
        freq = self.get_notification_frequency()
        freq_desc = {
            NotificationFrequency.ALWAYS: "每次",
            NotificationFrequency.DAILY: "每天",
            NotificationFrequency.WEEKLY: "每周",
            NotificationFrequency.NEVER: "从不"
        }
        lines.append(f"  🔔 通知频率：{freq_desc.get(freq, freq.value)}")
        
        lines.append(f"  🚀 启动同步：{'是' if self.should_auto_sync() else '否'}")
        lines.append(f"  🎉 展示成果：{'是' if self.should_show_achievement() else '否'}")
        lines.append(f"  📝 收集反馈：{'是' if self.should_collect_feedback() else '否'}")
        
        quiet = self.preferences.get("quiet_hours", {})
        if quiet.get("enabled", False):
            lines.append(f"  🌙 免打扰：{quiet.get('start', '22:00')} - {quiet.get('end', '08:00')}")
        
        lines.append("=" * 60)
        print("\n".join(lines))
    
    def interactive_setup(self):
        """交互式设置"""
        print("\n" + "=" * 60)
        print("⚙️  偏好设置向导")
        print("=" * 60)
        
        # 更新模式
        print("\n1️⃣  更新模式选择：")
        print("   [1] 自动 - 检测到更新后自动同步（推荐）")
        print("   [2] 询问 - 提示您确认后再同步")
        print("   [3] 手动 - 仅通过命令行手动触发")
        
        try:
            choice = input("\n请选择 [1/2/3] (默认: 2): ").strip() or "2"
            mode_map = {"1": UpdateMode.AUTO, "2": UpdateMode.ASK, "3": UpdateMode.MANUAL}
            if choice in mode_map:
                self.set_update_mode(mode_map[choice])
                print(f"   ✅ 已设置：{mode_map[choice].value}")
        except (KeyboardInterrupt, EOFError):
            print("\n   ⚠️ 取消设置")
            return
        
        # 通知频率
        print("\n2️⃣  通知频率选择：")
        print("   [1] 每次 - 有更新时立即通知")
        print("   [2] 每天 - 每天汇总通知一次（推荐）")
        print("   [3] 每周 - 每周汇总通知一次")
        print("   [4] 从不 - 不主动通知")
        
        try:
            choice = input("\n请选择 [1/2/3/4] (默认: 2): ").strip() or "2"
            freq_map = {
                "1": NotificationFrequency.ALWAYS,
                "2": NotificationFrequency.DAILY,
                "3": NotificationFrequency.WEEKLY,
                "4": NotificationFrequency.NEVER
            }
            if choice in freq_map:
                self.set_notification_frequency(freq_map[choice])
                print(f"   ✅ 已设置：{freq_map[choice].value}")
        except (KeyboardInterrupt, EOFError):
            pass
        
        # 其他选项
        print("\n3️⃣  其他设置：")
        try:
            auto_sync = input("   启动时自动同步？[y/n] (默认: y): ").strip().lower() != 'n'
            self.set("auto_sync_on_start", auto_sync)
            print(f"   ✅ 启动同步：{'是' if auto_sync else '否'}")
            
            show_ach = input("   更新后展示成果？[y/n] (默认: y): ").strip().lower() != 'n'
            self.set("show_achievement_on_update", show_ach)
            print(f"   ✅ 展示成果：{'是' if show_ach else '否'}")
        except (KeyboardInterrupt, EOFError):
            pass
        
        print("\n" + "=" * 60)
        print("✅ 偏好设置已保存！")
        print("=" * 60)
    
    # ============================================================
    # 快捷设置
    # ============================================================
    
    def set_quick_profile(self, profile_name: str):
        """
        快速应用预设配置
        
        Args:
            profile_name: 预设名称（minimal/standard/power-user）
        """
        profiles = {
            "minimal": {
                "update_mode": UpdateMode.MANUAL.value,
                "notification_frequency": NotificationFrequency.NEVER.value,
                "auto_sync_on_start": False,
                "show_achievement_on_update": False,
                "collect_feedback": False
            },
            "standard": self.DEFAULTS,
            "power-user": {
                "update_mode": UpdateMode.AUTO.value,
                "notification_frequency": NotificationFrequency.DAILY.value,
                "auto_sync_on_start": True,
                "show_achievement_on_update": True,
                "collect_feedback": True,
                "display_preferences": {
                    "show_progress_bar": True,
                    "show_emoji": True,
                    "detail_level": "detailed"
                }
            }
        }
        
        if profile_name in profiles:
            for key, value in profiles[profile_name].items():
                self.preferences[key] = value
            self.preferences["updated_at"] = datetime.now().isoformat()
            self._save_preferences()
            return True
        return False


# ============================================================
# CLI入口
# ============================================================

def main():
    """测试入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='用户偏好管理')
    parser.add_argument('--show', action='store_true', help='显示当前偏好')
    parser.add_argument('--setup', action='store_true', help='交互式设置')
    parser.add_argument('--profile', choices=['minimal', 'standard', 'power-user'],
                       help='应用预设配置')
    parser.add_argument('--set-mode', choices=['auto', 'ask', 'manual'],
                       help='设置更新模式')
    parser.add_argument('--set-freq', choices=['always', 'daily', 'weekly', 'never'],
                       help='设置通知频率')
    
    args = parser.parse_args()
    
    pref = UserPreference()
    
    if args.show:
        pref.show_preferences()
    elif args.setup:
        pref.interactive_setup()
    elif args.profile:
        if pref.set_quick_profile(args.profile):
            print(f"✅ 已应用预设配置：{args.profile}")
        else:
            print(f"❌ 未知预设：{args.profile}")
    elif args.set_mode:
        mode_map = {
            'auto': UpdateMode.AUTO,
            'ask': UpdateMode.ASK,
            'manual': UpdateMode.MANUAL
        }
        pref.set_update_mode(mode_map[args.set_mode])
        print(f"✅ 更新模式已设置为：{args.set_mode}")
    elif args.set_freq:
        freq_map = {
            'always': NotificationFrequency.ALWAYS,
            'daily': NotificationFrequency.DAILY,
            'weekly': NotificationFrequency.WEEKLY,
            'never': NotificationFrequency.NEVER
        }
        pref.set_notification_frequency(freq_map[args.set_freq])
        print(f"✅ 通知频率已设置为：{args.set_freq}")
    else:
        pref.show_preferences()


if __name__ == "__main__":
    main()
