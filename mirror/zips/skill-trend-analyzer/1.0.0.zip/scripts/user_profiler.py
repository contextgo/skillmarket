#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - User Profiler & History Manager
用户画像管理与历史回归分析
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: tax-risk-guard | Version: 1.2.2
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys, io, re, json, os, argparse, uuid
from datetime import datetime
from pathlib import Path

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent

def log(msg: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{ts}] {clean}", flush=True)

def ensure_data_dir():
    d = SKILL_DIR / "data"
    d.mkdir(parents=True, exist_ok=True)
    return d

def generate_user_id(profile: dict) -> str:
    """Generate random user ID (no sensitive data in hash)"""
    return "U" + uuid.uuid4().hex[:12]

def save_session(user_id, profile, scan_result, response_plan=None, feedback=None):
    data_dir = ensure_data_dir()
    hf = data_dir / f"{user_id}_history.json"
    history = {"user_id": user_id, "sessions": []}
    if hf.exists():
        with open(hf, 'r', encoding='utf-8') as f:
            history = json.load(f)
    # Sanitize profile: mask USCC and remove tax_number before persisting
    safe_profile = json.loads(json.dumps(profile))  # deep copy
    if "basic_info" in safe_profile:
        if "uscc" in safe_profile["basic_info"] and safe_profile["basic_info"]["uscc"]:
            # Mask: show first 6 + **** + last 4
            uscc = str(safe_profile["basic_info"]["uscc"])
            safe_profile["basic_info"]["uscc"] = uscc[:6] + "********" + uscc[-4:] if len(uscc) >= 18 else uscc[:3] + "***"
        if "tax_number" in safe_profile["basic_info"]:
            del safe_profile["basic_info"]["tax_number"]
    session = {
        "session_id": f"S{datetime.now().strftime('%Y%m%d%H%M%S')}",
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "user_profile": safe_profile,
        "risk_scan_result": {
            "total_score": scan_result.get("total_score",0),
            "risk_level": scan_result.get("risk_level",""),
            "hit_count": scan_result.get("hit_count",0),
            "high_count": scan_result.get("high_count",0),
            "medium_count": scan_result.get("medium_count",0),
            "low_count": scan_result.get("low_count",0),
            "top_risks": [i["risk_name"] for i in scan_result.get("hit_items",[])[:5]],
            "hit_items_summary": [{"risk_id":i.get("risk_id",""),"risk_name":i.get("risk_name",""),
                "risk_score":i.get("risk_score",0),"risk_level":i.get("risk_level","")}
                for i in scan_result.get("hit_items",[])]
        },
        "response_plan": response_plan or {},
        "user_feedback": feedback or {},
        "risk_elimination_status": "pending",
        "follow_up_items": []
    }
    history["sessions"].append(session)
    if len(history["sessions"]) > 50:
        history["sessions"] = history["sessions"][-50:]
    with open(hf, 'w', encoding='utf-8') as f:
        json.dump(history, f, ensure_ascii=False, indent=2)
    log(f"[OK] Session saved for {user_id}")
    return session["session_id"]

def get_history(user_id):
    data_dir = ensure_data_dir()
    hf = data_dir / f"{user_id}_history.json"
    if hf.exists():
        with open(hf, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"user_id": user_id, "sessions": []}

def regression_analysis(user_id):
    history = get_history(user_id)
    sessions = history.get("sessions", [])
    if not sessions:
        return {"user_id": user_id, "has_history": False, "message": "No history"}
    trends = [{"timestamp":s.get("timestamp",""),"total_score":s.get("risk_scan_result",{}).get("total_score",0),
               "risk_level":s.get("risk_scan_result",{}).get("risk_level",""),
               "hit_count":s.get("risk_scan_result",{}).get("hit_count",0)} for s in sessions]
    scores = [t["total_score"] for t in trends]
    score_trend = "improving" if len(scores)>=2 and scores[-1]<scores[0] else \
                  "worsening" if len(scores)>=2 and scores[-1]>scores[0] else "stable"
    unclosed = []
    for s in sessions:
        if s.get("risk_elimination_status")!="eliminated":
            for r in s.get("risk_scan_result",{}).get("hit_items_summary",[]):
                if r.get("risk_level") in ["high","medium"]:
                    unclosed.append({"session_id":s.get("session_id",""),"risk_name":r.get("risk_name",""),
                        "risk_level":r.get("risk_level",""),"since":s.get("timestamp",""),
                        "status":s.get("risk_elimination_status","pending")})
    seen = set(); unique_unclosed = []
    for i in unclosed:
        if i["risk_name"] not in seen: seen.add(i["risk_name"]); unique_unclosed.append(i)
    risk_counts = {}
    for s in sessions:
        for r in s.get("risk_scan_result",{}).get("hit_items_summary",[]):
            n = r.get("risk_name",""); risk_counts[n] = risk_counts.get(n,0)+1
    recurring = [{"name":n,"occurrence":c} for n,c in sorted(risk_counts.items(),key=lambda x:-x[1]) if c>=2]
    recs = []
    if score_trend=="worsening": recs.append("[ALERT] Risk score trending up - review needed")
    if unique_unclosed: recs.append(f"[ACTION] {len(unique_unclosed)} unclosed items need follow-up")
    for r in recurring[:3]: recs.append(f"[RECURRING] '{r['name']}' x{r['occurrence']} - systemic improvement suggested")
    return {"user_id":user_id,"has_history":True,"session_count":len(sessions),
            "latest_scan":trends[-1],"score_trend":score_trend,"trends":trends,
            "unclosed_items":unique_unclosed[:10],"recurring_risks":recurring[:5],
            "recommendations":recs,
            "latest_profile":sessions[-1].get("user_profile",{})}

def update_feedback(user_id, session_id, feedback):
    data_dir = ensure_data_dir()
    hf = data_dir / f"{user_id}_history.json"
    if not hf.exists(): return
    with open(hf,'r',encoding='utf-8') as f: history = json.load(f)
    for s in history.get("sessions",[]):
        if s.get("session_id")==session_id:
            s["user_feedback"] = feedback
            s["risk_elimination_status"] = "eliminated" if feedback.get("risk_eliminated") else \
                "in_progress" if feedback.get("partially_resolved") else s["risk_elimination_status"]
            break
    with open(hf,'w',encoding='utf-8') as f: json.dump(history,f,ensure_ascii=False,indent=2)
    log(f"[OK] Feedback updated for {session_id}")

def main():
    parser = argparse.ArgumentParser(description="TaxRiskGuard User Profiler")
    parser.add_argument("--action", choices=["save","history","regression","feedback"], required=True)
    parser.add_argument("--user-id", type=str, default="")
    parser.add_argument("--profile", type=str, default="")
    parser.add_argument("--result", type=str, default="")
    parser.add_argument("--session-id", type=str, default="")
    parser.add_argument("--feedback", type=str, default="")
    args = parser.parse_args()

    def load_json_file(path):
        """Load JSON with encoding detection; only allow files within skill directory"""
        resolved = Path(path).resolve()
        skill_root = SKILL_DIR.resolve()
        if not str(resolved).startswith(str(skill_root)):
            log(f"[ERROR] File path outside skill directory: {path}")
            sys.exit(1)
        with open(path, 'rb') as f:
            raw = f.read()
        if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
            return json.loads(raw.decode('utf-16'))
        elif raw[:3] == b'\xef\xbb\xbf':
            return json.loads(raw[3:].decode('utf-8'))
        else:
            return json.loads(raw.decode('utf-8'))

    if args.action == "save":
        profile = json.loads(args.profile) if not os.path.isfile(args.profile) else load_json_file(args.profile)
        uid = args.user_id or generate_user_id(profile)
        result = json.loads(args.result) if not os.path.isfile(args.result) else load_json_file(args.result)
        sid = save_session(uid, profile, result)
        print(json.dumps({"user_id":uid,"session_id":sid}, ensure_ascii=False))

    elif args.action == "history":
        uid = args.user_id
        h = get_history(uid)
        print(json.dumps(h, ensure_ascii=False, indent=2))

    elif args.action == "regression":
        uid = args.user_id
        analysis = regression_analysis(uid)
        print(json.dumps(analysis, ensure_ascii=False, indent=2))

    elif args.action == "feedback":
        uid = args.user_id; sid = args.session_id
        fb = json.loads(args.feedback) if args.feedback else {}
        update_feedback(uid, sid, fb)
        print(json.dumps({"status":"ok"}, ensure_ascii=False))

if __name__ == "__main__":
    main()
