# Skill Development Standards Reference

## Standard Skill Architecture

Based on analysis of 23 local skills + 685 market skills:

### Required Files (every skill must have)
| File | Weight | Description |
|------|--------|-------------|
| `SKILL.md` | 10 | Skill entry document (required for all skills) |
| `scripts/` | 5 | Core script directory |

### Standard Configurations (publish-ready skills must have)
| File | Weight | Description |
|------|--------|-------------|
| `manifest.json` | 8 | Integrity manifest (SHA256 hashes) |
| `scripts/integrity_guard.py` | 7 | Anti-tamper protection module |
| `scripts/learn_sync.py` | 6 | Cloud sync capability |
| `scripts/safe_io.py` | 4 | Anti-freeze I/O module (Windows compatibility) |
| `assets/learn_data.json` | 5 | Self-learning data |
| `references/` | 3 | Knowledge base directory |
| `assets/` | 3 | Static assets directory |
| `.clawdhubignore` | 3 | Package exclusion rules |

### Compliance Scoring (115 points total)
| Item | Weight | Description |
|------|--------|-------------|
| has_skill_md | 20 | SKILL.md exists |
| has_frontmatter | 15 | SKILL.md has valid frontmatter (name, description) |
| has_version | 10 | Version defined in frontmatter or SKILL.md |
| no_ad_in_skill_md | 10 | SKILL.md has no QQ/phone footer ads |
| has_manifest | 10 | manifest.json exists |
| has_integrity_guard | 10 | integrity_guard.py in scripts/ |
| has_learn_sync | 8 | learn_sync.py cloud sync capability |
| has_self_learning | 7 | Self-learning mechanism (learn_data.json) |
| has_safe_io | 5 | safe_io.py anti-freeze module |
| no_p0_risks | 15 | No critical security risks |
| no_p1_risks | 5 | No warning-level security risks |

### Grade System
| Grade | Score | Meaning |
|-------|-------|---------|
| A | >= 90% | Publish Ready |
| B | >= 75% | Almost Ready |
| C | >= 50% | Needs Work |
| D | < 50% | Not Ready |

## Security Risk Classification

### P0 Critical (must fix before publish)
- Hardcoded password/api_key/secret_key (use XOR+base64 obfuscation)
- eval() / exec() usage (potential code injection)
- subprocess with shell=True (command injection)
- Raw SQL string concatenation (SQL injection)

### P1 Warning (should fix)
- Hardcoded IP address (use config file)
- Hardcoded URL (consider config file or obfuscation)
- os.system() (prefer subprocess.run())
- pickle.loads() (deserialization attack)
- yaml.load without SafeLoader
- Non-ASCII in Python scripts (Windows GBK compatibility)

### P2 Info (good practice)
- Large files (>100KB, consider splitting)
- No copyright header
- No Windows encoding fix

## 5-Layer Anti-Freeze System

| Layer | Function | Protection Target | Implementation |
|-------|----------|-------------------|----------------|
| L0 | sys.path auto-fix | ImportError from cross-script imports | `_fix_sys_path()` |
| L1 | Shared encoding marker | double-wrap -> GC -> closed -> freeze | `safe_init()` |
| L2 | Global print hook | 152 print() calls intercepted, zero code changes | `_install_print_hook()` |
| L3 | Stream health monitor | I/O on closed file exception | `check_stream_health()` + `repair_streams()` |
| L4 | File read timeout | Big file read() blocking forever | `safe_read_text()` + `safe_read_json()` |
| L5 | TimeoutGuard + safe_subprocess | Code block/subprocess stuck | `TimeoutGuard()` + `safe_subprocess()` |

## Common Market Patterns (from 685 skills)

Top architecture patterns observed:
1. scripts/ directory (65.2% of skills)
2. references/ directory (52.2%)
3. manifest.json (26.1%)
4. integrity_guard.py (21.7%)
5. assets/ directory (21.7%)
6. Cloud sync (17.4%)
7. data/ directory (13.0%)
8. Release build script (13.0%)
9. Self-learning mechanism (13.0%)