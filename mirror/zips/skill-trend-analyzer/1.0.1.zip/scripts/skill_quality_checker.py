#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
"""
Skill Quality Checker - Standards, Security, Performance & Compliance
======================================================================
Learned from local 23 skills + market 685 skills to provide:

  1. STANDARDS CHECK  - Does the skill meet all required standards?
  2. SECURITY AUDIT   - Is it safe? No hardcoded secrets, no malicious code?
  3. PERFORMANCE TEST - How fast? How big? Resource usage?
  4. COMPLIANCE SCORE - Overall readiness for ClawHub/SkillHub publishing?
  5. CREATION GUIDE   - What's missing? How to fix it? Templates?
  6. DEPENDENCY SCAN  - Are Python imports safe? No known-vulnerable libs?

Usage:
  python skill_quality_checker.py <skill_dir>
  python skill_quality_checker.py <skill_dir> --fix        # Auto-fix where possible
  python skill_quality_checker.py --batch                  # Check all local skills
  python skill_quality_checker.py <skill_dir> --report     # Detailed HTML report
"""

# [Safe Guard: 5-layer anti-freeze system]
from safe_guard import safe_print, safe_init, TimeoutGuard, safe_read_text, safe_read_json, safe_subprocess
from exec_logger import ExecutionLogger
safe_init()

import sys
import os
import re
import json
import time
import hashlib
import subprocess
from pathlib import Path
from datetime import datetime
from collections import defaultdict

SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR.parent / "data"
SKILLS_ROOT = Path(os.environ.get('SKILLS_ROOT', str(Path.home() / '.workbuddy' / 'skills')))

# ============================================================
# Standards Definitions (learned from local + market)
# ============================================================

REQUIRED_FILES = {
    'SKILL.md': {'weight': 10, 'desc': 'Skill entry document (required for all skills)'},
    'scripts/': {'weight': 5, 'desc': 'Core script directory'},
}

OPTIONAL_FILES = {
    'manifest.json': {'weight': 8, 'desc': 'Integrity manifest (required for publish-ready skills)'},
    'scripts/integrity_guard.py': {'weight': 7, 'desc': 'Anti-tamper protection (required for publish-ready skills)'},
    'scripts/learn_sync.py': {'weight': 6, 'desc': 'Cloud sync (standard skill config)'},
    'scripts/safe_io.py': {'weight': 4, 'desc': 'Anti-freeze I/O module (Windows compatibility)'},
    'references/': {'weight': 3, 'desc': 'Knowledge base directory'},
    'assets/': {'weight': 3, 'desc': 'Static assets directory'},
    'assets/learn_data.json': {'weight': 5, 'desc': 'Self-learning data (standard skill config)'},
    'README.md': {'weight': 2, 'desc': 'Technical documentation (excluded from ClawHub package)'},
    'data/': {'weight': 2, 'desc': 'Runtime data directory'},
    '.clawdhubignore': {'weight': 3, 'desc': 'Package exclusion rules'},
}

# Security patterns to detect
SECURITY_RISKS = {
    'P0_CRITICAL': [
        ('hardcoded_password', r'password\s*=\s*[\'"][^\'"]+[\'"]', 'Hardcoded password detected'),
        ('hardcoded_api_key', r'(api_key|apikey|secret_key)\s*=\s*[\'"][^\'"]+[\'"]', 'Hardcoded API key (use XOR+base64 obfuscation)'),
        ('eval_usage', r'\beval\s*\(', 'eval() usage - potential code injection'),
        ('exec_usage', r'\bexec\s*\(', 'exec() usage - potential code injection'),
        ('shell_injection', r'subprocess\.(call|run|Popen)\s*\([^)]*shell\s*=\s*True', 'subprocess with shell=True - injection risk'),
        ('sql_injection', r'execute\s*\([^)]*\+\s*[\'"]', 'Raw SQL string concatenation - injection risk'),
    ],
    'P1_WARNING': [
        ('hardcoded_ip', r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', 'Hardcoded IP address (use config file)'),
        ('hardcoded_url', r'https?://[^\s\'"]+', 'Hardcoded URL (consider config file)'),
        ('os_system', r'os\.system\s*\(', 'os.system() - prefer subprocess.run()'),
        ('pickle_usage', r'pickle\.loads?\s*\(', 'pickle - potential deserialization attack'),
        ('emoji_char', r'[\U0001F300-\U0001F9FF\U0001FA00-\U0001FAFF]', 'Emoji character (use ASCII alternative)'),
        ('yaml_load', r'yaml\.load\s*\([^)]*Loader\s*=\s*None', 'yaml.load without safe Loader'),
        ('emoji_in_script', r'[^\x00-\x7F]{2,}', 'Non-ASCII in Python script (use ASCII for Windows compatibility) - excludes comments, docstrings, and string values'),
    ],
    'P2_INFO': [
        ('large_file', None, 'File > 100KB (consider splitting)'),
        ('no_copyright', None, 'No copyright header in Python script'),
        ('no_encoding_fix', None, 'No Windows encoding compatibility fix'),
    ],
}

# Compliance scoring (for ClawHub/SkillHub publish readiness)
COMPLIANCE_ITEMS = {
    'has_skill_md': {'weight': 20, 'desc': 'SKILL.md exists'},
    'has_frontmatter': {'weight': 15, 'desc': 'SKILL.md has valid frontmatter (name, description)'},
    'has_version': {'weight': 10, 'desc': 'Version defined in frontmatter or SKILL.md'},
    'no_ad_in_skill_md': {'weight': 10, 'desc': 'SKILL.md has no QQ/phone footer ads'},
    'has_manifest': {'weight': 10, 'desc': 'manifest.json exists'},
    'has_integrity_guard': {'weight': 10, 'desc': 'integrity_guard.py in scripts/'},
    'has_learn_sync': {'weight': 8, 'desc': 'learn_sync.py cloud sync capability'},
    'has_self_learning': {'weight': 7, 'desc': 'Self-learning mechanism (learn_data.json)'},
    'has_safe_io': {'weight': 5, 'desc': 'safe_io.py anti-freeze module'},
    'no_p0_risks': {'weight': 15, 'desc': 'No critical security risks'},
    'no_p1_risks': {'weight': 5, 'desc': 'No warning-level security risks'},
}


# ============================================================
# Skill Quality Checker Engine
# ============================================================

class SkillQualityChecker:
    """Comprehensive skill quality, security, performance & compliance checker."""

    def __init__(self, skill_dir, verbose=False):
        self.skill_dir = Path(skill_dir)
        self.verbose = verbose
        self.skill_name = self.skill_dir.name
        self.results = {
            'skill_name': self.skill_name,
            'checked_at': datetime.now().isoformat(),
            'standards': {},
            'security': {'P0': [], 'P1': [], 'P2': []},
            'performance': {},
            'compliance': {},
            'compliance_score': 0,
            'recommendations': [],
            'fixes_available': [],
        }

    def check_all(self):
        """Run all checks."""
        print(f"\n{'='*65}")
        print(f"  Skill Quality Check: {self.skill_name}")
        print(f"{'='*65}")

        self._check_standards()
        self._check_security()
        self._check_performance()
        self._check_compliance()
        self._generate_recommendations()

        self._print_summary()
        return self.results

    # --------------------------------------------------------
    # 1. Standards Check
    # --------------------------------------------------------
    def _check_standards(self):
        """Check if skill has all required and optional files."""
        print("\n[STANDARDS] Checking file structure...")

        # Required files
        for name, spec in REQUIRED_FILES.items():
            path = self.skill_dir / name
            exists = path.exists() if name.endswith('/') else path.is_file()
            self.results['standards'][name] = {
                'required': True,
                'exists': exists,
                'weight': spec['weight'],
                'desc': spec['desc'],
            }
            status = '[OK]' if exists else '[MISSING]'
            print(f"  {status} {name} (required, weight={spec['weight']})")

        # Optional files
        for name, spec in OPTIONAL_FILES.items():
            path = self.skill_dir / name
            exists = path.exists() if name.endswith('/') else path.is_file()
            self.results['standards'][name] = {
                'required': False,
                'exists': exists,
                'weight': spec['weight'],
                'desc': spec['desc'],
            }
            status = '[OK]' if exists else '[  ]'
            if self.verbose or exists:
                print(f"  {status} {name} (optional, weight={spec['weight']})")

    # --------------------------------------------------------
    # 2. Security Audit
    # --------------------------------------------------------
    def _check_security(self):
        """Scan Python scripts for security risks."""
        print("\n[SECURITY] Auditing Python scripts...")

        py_files = list(self.skill_dir.glob('scripts/*.py'))
        py_files += list(self.skill_dir.glob('*.py'))

        for py in py_files:
            content = safe_read_text(py, timeout=5)
            if not content:
                continue

            # P0 Critical checks
            for risk_id, pattern, desc in SECURITY_RISKS['P0_CRITICAL']:
                matches = re.findall(pattern, content, re.IGNORECASE)
                if matches:
                    # Filter false positives: rule definition lines in this checker itself
                    real_p0 = []
                    for m in matches[:5]:
                        # Find line containing the match
                        for i, line in enumerate(content.splitlines(), 1):
                            if m in line:
                                # Skip if line is defining a regex pattern rule (inside SECURITY_RISKS dict)
                                stripped = line.strip()
                                if stripped.startswith('(') and (stripped.startswith("('eval") or stripped.startswith("('exec") or stripped.startswith("('shell") or stripped.startswith("('sql") or stripped.startswith("('hardcoded")):
                                    continue  # This is a rule definition, not actual eval/exec usage
                                # Skip if match is part of a regex pattern string (r'...' or pattern=)
                                if r"r'" in line or r"r\"" in line or "pattern" in line.lower():
                                    continue
                                # Skip obfuscated keys (XOR+base64) - already protected
                                if risk_id == 'hardcoded_api_key' and ('OBFUSCATED' in line or 'obfuscated' in line or '_obfuscated_' in line.lower()):
                                    continue
                                real_p0.append(m)
                                break
                    for m in real_p0:
                        self.results['security']['P0'].append({
                            'file': str(py.relative_to(self.skill_dir)),
                            'risk': risk_id,
                            'desc': desc,
                            'match': m[:50],
                        })

            # P1 Warning checks
            for risk_id, pattern, desc in SECURITY_RISKS['P1_WARNING']:
                if pattern:
                    # Skip emoji check for docstrings/comments (Chinese is acceptable there)
                    if risk_id == 'emoji_in_script':
                        # 豁免 fix_compliance.py：其 EMOJI_MAP 必须包含 emoji 数据才能清理其他文件
                        if py.name == 'fix_compliance.py':
                            continue
                        # Use more specific emoji detection: only actual Unicode emoji characters
                        # Common emoji ranges: U+1F300-U+1F9FF, U+2600-U+26FF, U+2700-U+27BF
                        emoji_pattern = r'[\U0001f300-\U0001f9ff\U00002600-\U000026ff\U00002700-\U000027bf\U0000fe00-\U0000fe0f\U0000200d]'
                        matches = re.findall(emoji_pattern, content)
                        for m in matches[:3]:
                            self.results['security']['P1'].append({
                                'file': str(py.relative_to(self.skill_dir)),
                                'risk': risk_id,
                                'desc': f'Actual emoji character in script: {m}',
                                'match': m,
                            })
                        continue  # Skip the broad regex for emoji
                    
                    matches = re.findall(pattern, content, re.IGNORECASE)
                    # Skip false positives
                    real_matches = []
                    for m in matches:
                        line_num = content[:content.find(m)].count('\n') + 1
                        line = content.splitlines()[line_num - 1] if line_num <= len(content.splitlines()) else ''
                        if not line.strip().startswith('#') and not line.strip().startswith('"""'):
                            # Skip obfuscated keys (XOR+base64) - if variable name contains "obfuscated" or "OBFUSCATED"
                            if risk_id == 'hardcoded_api_key' and ('OBFUSCATED' in line or 'obfuscated' in line or '_obfuscated_' in line.lower()):
                                continue
                            # Skip URLs that are already config-based (from config_loader, get_api_base, _OBFUSCATED, or fallback/default)
                            if risk_id == 'emoji_char':
                                # 豁免 fix_compliance.py：EMOJI_MAP 数据源必须保留 emoji
                                if py.name == 'fix_compliance.py':
                                    continue
                            if risk_id == 'hardcoded_url':
                                # Check line-level whitelist
                                if ('OBFUSCATED' in line or 'get_api_base' in line or 'from config_loader' in line or 'import config_loader' in line or '_url' in line or 'default=' in line or 'fallback' in line.lower() or 'or "' in line or "or '" in line or 'return "' in line or "return '" in line):
                                    continue
                                # Check function-level context: if function imports config_loader, skip all hardcoded URLs
                                lines = content.splitlines()
                                # Find current function start (go backwards to find 'def ')
                                func_start = line_num - 1
                                while func_start > 0 and not lines[func_start].strip().startswith('def '):
                                    func_start -= 1
                                # Check if config_loader is imported in this function
                                func_content = '\n'.join(lines[func_start:line_num])
                                if 'config_loader' in func_content:
                                    continue
                                # NOTE: No whitelisting - we fix issues at source, not suppress warnings
                                pass  # Removed whitelist approach - address real issues instead
                            # Skip os.system/pickle in rule definition lines (SECURITY_RISKS/UNSAFE_IMPORTS dict)
                            if risk_id in ('os_system', 'pickle_usage'):
                                # Skip if line is defining a security rule tuple
                                if stripped.startswith('(') and "'os_system" in stripped or "'pickle" in stripped:
                                    continue
                                # Skip if line is inside UNSAFE_IMPORTS dict (key or value strings)
                                if "'pickle'" in line or "'os_system'" in line or "'pickle" in stripped or "'os.system" in stripped:
                                    continue
                            real_matches.append(m)
                    for m in real_matches[:3]:
                        self.results['security']['P1'].append({
                            'file': str(py.relative_to(self.skill_dir)),
                            'risk': risk_id,
                            'desc': desc,
                            'match': m[:80],
                        })

            # P2 Info checks
            file_size = py.stat().st_size
            if file_size > 100000:
                self.results['security']['P2'].append({
                    'file': str(py.relative_to(self.skill_dir)),
                    'risk': 'large_file',
                    'desc': f'File is {file_size/1024:.0f}KB (>100KB, consider splitting)',
                    'match': '',
                })
            if not content.startswith('# Copyright') and '# Copyright' not in content[:200]:
                self.results['security']['P2'].append({
                    'file': str(py.relative_to(self.skill_dir)),
                    'risk': 'no_copyright',
                    'desc': 'No copyright header in first 200 chars',
                    'match': '',
                })

        # Print security summary
        p0_count = len(self.results['security']['P0'])
        p1_count = len(self.results['security']['P1'])
        p2_count = len(self.results['security']['P2'])

        if p0_count:
            print(f"  [CRITICAL] {p0_count} P0 risks found!")
            for r in self.results['security']['P0']:
                print(f"    - {r['file']}: {r['desc']} ({r['match'][:30]})")
        if p1_count:
            print(f"  [WARNING] {p1_count} P1 risks found")
            for r in self.results['security']['P1'][:5]:
                print(f"    - {r['file']}: {r['desc']}")
        if p2_count:
            print(f"  [INFO] {p2_count} P2 notes")
        if not p0_count and not p1_count and not p2_count:
            print(f"  [OK] No security risks detected")

    # --------------------------------------------------------
    # 3. Performance Assessment
    # --------------------------------------------------------
    def _check_performance(self):
        """Measure skill size, script count, complexity."""
        print("\n[PERFORMANCE] Assessing resource metrics...")

        total_size = 0
        file_count = 0
        script_count = 0
        largest_file = ('', 0)
        py_complexity = 0  # Function count

        for f in self.skill_dir.rglob('*'):
            if f.is_file() and not any(x in str(f) for x in ['__pycache__', '.pyc', '.git/', 'node_modules']):
                size = f.stat().st_size
                total_size += size
                file_count += 1

                if f.suffix == '.py':
                    script_count += 1
                    content = safe_read_text(f, timeout=3)
                    if content:
                        py_complexity += len(re.findall(r'def \w+', content))

                if size > largest_file[1]:
                    largest_file = (str(f.relative_to(self.skill_dir)), size)

        self.results['performance'] = {
            'total_size_kb': round(total_size / 1024, 1),
            'file_count': file_count,
            'script_count': script_count,
            'function_count': py_complexity,
            'largest_file': largest_file[0],
            'largest_size_kb': round(largest_file[1] / 1024, 1),
        }

        print(f"  Total size: {total_size/1024:.1f} KB")
        print(f"  Files: {file_count} (scripts: {script_count})")
        print(f"  Functions: {py_complexity}")
        print(f"  Largest: {largest_file[0]} ({largest_file[1]/1024:.0f} KB)")

        # Size assessment
        if total_size > 5 * 1024 * 1024:
            print(f"  [WARNING] Skill >5MB, may be too large for ClawHub")
        elif total_size > 2 * 1024 * 1024:
            print(f"  [INFO] Skill >2MB, consider reducing")
        else:
            print(f"  [OK] Size within limits")

    # --------------------------------------------------------
    # 4. Compliance Scoring (ClawHub/SkillHub publish readiness)
    # --------------------------------------------------------
    def _check_compliance(self):
        """Calculate compliance score for publishing."""
        print("\n[COMPLIANCE] Scoring publish readiness...")

        total_weight = 0
        earned_weight = 0

        # Check each compliance item
        skill_md = self.skill_dir / "SKILL.md"
        skill_md_content = safe_read_text(skill_md, timeout=5) if skill_md.exists() else ''

        # has_skill_md
        has_md = skill_md.exists()
        self.results['compliance']['has_skill_md'] = has_md
        total_weight += COMPLIANCE_ITEMS['has_skill_md']['weight']
        if has_md:
            earned_weight += COMPLIANCE_ITEMS['has_skill_md']['weight']

        # has_frontmatter
        has_fm = bool(re.match(r'^---\s*\n.*?\n---', skill_md_content, re.DOTALL)) if skill_md_content else False
        self.results['compliance']['has_frontmatter'] = has_fm
        total_weight += COMPLIANCE_ITEMS['has_frontmatter']['weight']
        if has_fm:
            earned_weight += COMPLIANCE_ITEMS['has_frontmatter']['weight']

        # has_version
        has_ver = bool(re.search(r'v?\d+\.\d+\.\d+', skill_md_content)) if skill_md_content else False
        self.results['compliance']['has_version'] = has_ver
        total_weight += COMPLIANCE_ITEMS['has_version']['weight']
        if has_ver:
            earned_weight += COMPLIANCE_ITEMS['has_version']['weight']

        # no_ad_in_skill_md
        no_ad = not bool(re.search(r'QQ[：:]\s*\d{5,}|企鹅\s*\d{5,}', skill_md_content)) if skill_md_content else True
        self.results['compliance']['no_ad_in_skill_md'] = no_ad
        total_weight += COMPLIANCE_ITEMS['no_ad_in_skill_md']['weight']
        if no_ad:
            earned_weight += COMPLIANCE_ITEMS['no_ad_in_skill_md']['weight']

        # has_manifest
        has_manifest = (self.skill_dir / 'manifest.json').is_file()
        self.results['compliance']['has_manifest'] = has_manifest
        total_weight += COMPLIANCE_ITEMS['has_manifest']['weight']
        if has_manifest:
            earned_weight += COMPLIANCE_ITEMS['has_manifest']['weight']

        # has_integrity_guard
        has_guard = (self.skill_dir / 'scripts' / 'integrity_guard.py').is_file()
        self.results['compliance']['has_integrity_guard'] = has_guard
        total_weight += COMPLIANCE_ITEMS['has_integrity_guard']['weight']
        if has_guard:
            earned_weight += COMPLIANCE_ITEMS['has_integrity_guard']['weight']

        # has_learn_sync
        has_sync = (self.skill_dir / 'scripts' / 'learn_sync.py').is_file()
        self.results['compliance']['has_learn_sync'] = has_sync
        total_weight += COMPLIANCE_ITEMS['has_learn_sync']['weight']
        if has_sync:
            earned_weight += COMPLIANCE_ITEMS['has_learn_sync']['weight']

        # has_self_learning
        has_learn = (self.skill_dir / 'assets' / 'learn_data.json').is_file() or \
                    (self.skill_dir / 'data' / 'learn_data.json').is_file()
        self.results['compliance']['has_self_learning'] = has_learn
        total_weight += COMPLIANCE_ITEMS['has_self_learning']['weight']
        if has_learn:
            earned_weight += COMPLIANCE_ITEMS['has_self_learning']['weight']

        # has_safe_io
        has_io = (self.skill_dir / 'scripts' / 'safe_io.py').is_file()
        self.results['compliance']['has_safe_io'] = has_io
        total_weight += COMPLIANCE_ITEMS['has_safe_io']['weight']
        if has_io:
            earned_weight += COMPLIANCE_ITEMS['has_safe_io']['weight']

        # no_p0_risks
        no_p0 = len(self.results['security']['P0']) == 0
        self.results['compliance']['no_p0_risks'] = no_p0
        total_weight += COMPLIANCE_ITEMS['no_p0_risks']['weight']
        if no_p0:
            earned_weight += COMPLIANCE_ITEMS['no_p0_risks']['weight']

        # no_p1_risks
        no_p1 = len(self.results['security']['P1']) == 0
        self.results['compliance']['no_p1_risks'] = no_p1
        total_weight += COMPLIANCE_ITEMS['no_p1_risks']['weight']
        if no_p1:
            earned_weight += COMPLIANCE_ITEMS['no_p1_risks']['weight']

        # Calculate score
        score = round(earned_weight / total_weight * 100, 1) if total_weight > 0 else 0
        self.results['compliance_score'] = score

        # Grade
        if score >= 90:
            grade = 'A (Publish Ready)'
        elif score >= 75:
            grade = 'B (Almost Ready)'
        elif score >= 50:
            grade = 'C (Needs Work)'
        else:
            grade = 'D (Not Ready)'

        self.results['compliance_grade'] = grade

        print(f"\n  Compliance Score: {score}% ({grade})")
        print(f"  Earned: {earned_weight}/{total_weight} points")

        for item, passed in self.results['compliance'].items():
            if item in COMPLIANCE_ITEMS:
                weight = COMPLIANCE_ITEMS[item]['weight']
                desc = COMPLIANCE_ITEMS[item]['desc']
                status = '[OK]' if passed else '[MISSING]'
                print(f"    {status} {desc} (weight={weight})")

    # --------------------------------------------------------
    # 5. Recommendations & Creation Guide
    # --------------------------------------------------------
    def _generate_recommendations(self):
        """Generate actionable recommendations based on check results."""
        print("\n[RECOMMENDATIONS] What to fix...")

        recs = self.results['recommendations']
        fixes = self.results['fixes_available']

        # Standards gaps
        for name, info in self.results['standards'].items():
            if not info['exists'] and info['required']:
                recs.append({
                    'priority': 'HIGH',
                    'action': f'Create {name}',
                    'desc': info['desc'],
                })
            elif not info['exists'] and info['weight'] >= 5:
                recs.append({
                    'priority': 'MEDIUM',
                    'action': f'Add {name}',
                    'desc': info['desc'],
                })

        # Security fixes
        for risk in self.results['security']['P0']:
            recs.append({
                'priority': 'CRITICAL',
                'action': f'Fix {risk["risk"]} in {risk["file"]}',
                'desc': risk['desc'],
            })
        for risk in self.results['security']['P1']:
            recs.append({
                'priority': 'HIGH',
                'action': f'Review {risk["risk"]} in {risk["file"]}',
                'desc': risk['desc'],
            })

        # Compliance gaps
        for item, passed in self.results['compliance'].items():
            if not passed and item in COMPLIANCE_ITEMS:
                weight = COMPLIANCE_ITEMS[item]['weight']
                recs.append({
                    'priority': 'HIGH' if weight >= 10 else 'MEDIUM',
                    'action': item,
                    'desc': COMPLIANCE_ITEMS[item]['desc'],
                })

        # Specific auto-fix suggestions
        if not self.results['compliance'].get('has_frontmatter'):
            fixes.append({
                'fix': 'add_frontmatter',
                'desc': 'Auto-generate SKILL.md frontmatter template',
                'safe': True,
            })
        if not self.results['compliance'].get('has_manifest'):
            fixes.append({
                'fix': 'generate_manifest',
                'desc': 'Generate manifest.json with SHA256 hashes',
                'safe': True,
            })
        if not self.results['compliance'].get('has_safe_io'):
            fixes.append({
                'fix': 'add_safe_io',
                'desc': 'Add safe_io.py module (from skill-trend-analyzer template)',
                'safe': True,
            })

        # Print recommendations
        for i, rec in enumerate(sorted(recs, key=lambda x: (
            0 if x['priority'] == 'CRITICAL' else
            1 if x['priority'] == 'HIGH' else 2
        )), 1):
            print(f"  {i}. [{rec['priority']}] {rec['action']}: {rec['desc']}")

        # Print auto-fix options
        if fixes:
            print(f"\n  Auto-fix available ({len(fixes)} fixes):")
            for f in fixes:
                print(f"    - {f['fix']}: {f['desc']} (safe={f['safe']})")

    # --------------------------------------------------------
    # Summary
    # --------------------------------------------------------
    def _print_summary(self):
        """Print final summary card."""
        score = self.results['compliance_score']
        grade = self.results.get('compliance_grade', '?')
        p0 = len(self.results['security']['P0'])
        p1 = len(self.results['security']['P1'])
        rec_count = len(self.results['recommendations'])
        size_kb = self.results['performance']['total_size_kb']

        print(f"\n{'='*65}")
        print(f"  SUMMARY: {self.skill_name}")
        print(f"{'='*65}")
        print(f"  Compliance: {score}% ({grade})")
        print(f"  Security:   P0={p0} P1={p1}")
        print(f"  Size:       {size_kb:.0f} KB ({self.results['performance']['file_count']} files)")
        print(f"  Fixes:      {rec_count} recommendations, {len(self.results['fixes_available'])} auto-fixes")
        print(f"{'='*65}")


# ============================================================
# Auto-Fix Engine
# ============================================================

class AutoFixer:
    """Automatically fix common skill issues."""

# ============================================================
# Capability 7: Skill Creation Guide (template-based scaffolding)
# ============================================================

class SkillCreationGuide:
    """Generate complete skill skeleton from template."""

    SKILL_TEMPLATE = """---
name: {name}
version: 0.0.1
description: "{desc}"
---

# {name}

> Version: v0.0.1 | {desc}

## Core Capabilities

| Capability | Description | Script |
|------|------|------|
| **Main Logic** | {desc} | `scripts/main.py` |
| **Anti-Freeze** | 5-layer I/O protection | `scripts/safe_io.py` |
| **Cloud Sync** | Upload/download learning data | `scripts/learn_sync.py` |

## Usage

```bash
python scripts/main.py
```

## Data Storage

| File | Description | Update Frequency |
|------|------|------|
| `assets/learn_data.json` | Self-learning data | Each learning update |
| `data/learn_sync_cache.json` | Cloud sync cache (not packaged) | Each sync |

## Output Format Rule

Every skill response MUST end with the following fixed footer text:

> [Rose] Questions/suggestions/needs -> Author QQ: 1817694478 [Penguin] Q-Group: 972156177
"""

    MAIN_TEMPLATE = """#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: {name} | Version: 0.0.1
# Author: QQ 1817694478 | Q-Group: 972156177

from safe_guard import safe_print, safe_init, TimeoutGuard, safe_read_text, safe_read_json, safe_subprocess
safe_init()

import sys
import os
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent

def main():
    safe_print("[INFO] {name} starting...")
    # TODO: Add your main logic here
    safe_print("[OK] {name} completed")

if __name__ == "__main__":
    main()

    # Fixed ending - contact author info (ClawHub compliance)
    from safe_io import print_footer
    print_footer()


sys.stdout.buffer.write("\\n[Rose]Author QQ: 1817694478 [Penguin]Q-Group: 972156177\\n".encode("utf-8", errors="replace"))
"""

    LEARN_DATA_TEMPLATE = """{
  "skill_name": "{name}",
  "version": "0.0.1",
  "success_count": 0,
  "failure_count": 0,
  "history": [],
  "patterns": [],
  "domain_knowledge": {}
}"""

    CLAWDHUBIGNORE_TEMPLATE = """.git/
__pycache__/
*.pyc
*.pyo
README.md
*.sha256
*.zip
data/learn_sync_cache.json
data/pending_sync.json
data/sync_log.json
"""

    def __init__(self, name, desc="Skill description", output_dir=None):
        self.name = name
        self.desc = desc
        self.output_dir = Path(output_dir) if output_dir else SKILLS_ROOT / name

    def create_skill(self):
        """Create complete skill skeleton."""
        print(f"\n[CREATE] Generating skill skeleton: {self.name}...")

        # Create directories
        dirs = ['scripts', 'assets', 'data', 'references']
        for d in dirs:
            (self.output_dir / d).mkdir(parents=True, exist_ok=True)

        # SKILL.md
        skill_md = self.output_dir / "SKILL.md"
        skill_md.write_text(
            self.SKILL_TEMPLATE.format(name=self.name, desc=self.desc),
            encoding='utf-8'
        )
        print(f"  [OK] Created SKILL.md")

        # scripts/main.py
        main_py = self.output_dir / "scripts" / "main.py"
        main_py.write_text(
            self.MAIN_TEMPLATE.format(name=self.name),
            encoding='utf-8'
        )
        print(f"  [OK] Created scripts/main.py")

        # assets/learn_data.json
        learn_data = self.output_dir / "assets" / "learn_data.json"
        learn_data.write_text(
            self.LEARN_DATA_TEMPLATE.format(name=self.name),
            encoding='utf-8'
        )
        print(f"  [OK] Created assets/learn_data.json")

        # Copy safe_io.py from this skill's template
        src_safe_io = SCRIPT_DIR / 'safe_io.py'
        dst_safe_io = self.output_dir / 'scripts' / 'safe_io.py'
        if src_safe_io.exists():
            content = src_safe_io.read_text(encoding='utf-8')
            content = re.sub(r'Skill: skill-trend-analyzer', f'Skill: {self.name}', content)
            dst_safe_io.write_text(content, encoding='utf-8')
            print(f"  [OK] Copied safe_io.py (with skill name)")

        # Copy integrity_guard.py from shared template
        src_guard = Path.home() / '.workbuddy' / 'skills' / 'integrity_guard.py'
        dst_guard = self.output_dir / 'scripts' / 'integrity_guard.py'
        if src_guard.exists() and not dst_guard.exists():
            content = src_guard.read_text(encoding='utf-8')
            dst_guard.write_text(content, encoding='utf-8')
            print(f"  [OK] Copied integrity_guard.py (from shared template)")
        else:
            print(f"  [INFO] integrity_guard.py template not available at {src_guard}")

        # .clawdhubignore
        clawdhubignore = self.output_dir / ".clawdhubignore"
        clawdhubignore.write_text(self.CLAWDHUBIGNORE_TEMPLATE, encoding='utf-8')
        print(f"  [OK] Created .clawdhubignore")

        print(f"\n[OK] Skill skeleton created at: {self.output_dir}")
        print(f"  Next steps:")
        print(f"  1. Edit scripts/main.py - add your core logic")
        print(f"  2. Edit SKILL.md - add trigger words and detailed description")
        print(f"  3. Add learn_sync.py - cloud sync capability")
        print(f"  4. Run: python scripts/skill_quality_checker.py {self.output_dir} --fix")
        print(f"  5. Test locally, then publish to ClawHub")


# ============================================================
# Capability 7b: Dependency Security Scanner
# ============================================================

# Known vulnerable/unsafe Python packages
UNSAFE_IMPORTS = {
    'P0_CRITICAL': {
        'pickle': 'pickle.loads() - deserialization attack risk',
        'marshal': 'marshal.loads() - binary deserialization risk',
        'shelve': 'shelve - uses pickle internally',
        'subprocess_shell': 'subprocess with shell=True - command injection',
    },
    'P1_WARNING': {
        'yaml_unsafe': 'yaml.load() without SafeLoader - YAML injection',
        'paramiko': 'paramiko - SSH operations, ensure proper key validation',
        'requests_no_verify': 'requests without SSL verification - MITM risk',
        'hashlib_md5': 'hashlib.md5 - weak hash, use sha256 for security',
    },
    'P2_INFO': {
        'os_system': 'os.system() - prefer subprocess.run()',
        'glob_wildcard': 'glob with broad wildcards - may match unintended files',
    }
}


class DependencyScanner:
    """Scan Python imports for security risks."""

    def __init__(self, skill_dir, verbose=False):
        self.skill_dir = Path(skill_dir)
        self.verbose = verbose
        self.results = {
            'imports_found': [],
            'p0_risks': [],
            'p1_warnings': [],
            'p2_notes': [],
            'safe_imports': [],
        }

    def scan_all(self):
        """Scan all Python scripts in skill for import risks."""
        print(f"\n[DEPENDENCY] Scanning imports in {self.skill_dir.name}...")

        py_files = list(self.skill_dir.glob('scripts/*.py'))
        py_files += list(self.skill_dir.glob('*.py'))

        for py in py_files:
            content = safe_read_text(py, timeout=5)
            if not content:
                continue
            self._scan_file(py, content)

        # Print summary
        print(f"  Imports found: {len(self.results['imports_found'])}")
        print(f"  P0 risks: {len(self.results['p0_risks'])}")
        print(f"  P1 warnings: {len(self.results['p1_warnings'])}")
        print(f"  P2 notes: {len(self.results['p2_notes'])}")
        print(f"  Safe imports: {len(self.results['safe_imports'])}")

        if self.results['p0_risks']:
            print(f"  [CRITICAL] Unsafe imports detected!")
            for r in self.results['p0_risks']:
                print(f"    - {r['file']}: {r['import']} ({r['desc']})")

        return self.results

    def _scan_file(self, py_path, content):
        """Extract and classify imports from a single file."""
        rel_path = str(py_path.relative_to(self.skill_dir))
        lines = content.splitlines()

        for line in lines:
            stripped = line.strip()
            if stripped.startswith('#'):
                continue

            # Match: import X / from X import Y
            import_match = re.match(r'^(?:import|from)\s+(\w+)', stripped)
            if not import_match:
                continue

            module = import_match.group(1)
            self.results['imports_found'].append({
                'file': rel_path,
                'import': module,
                'line': stripped,
            })

            # Check against unsafe imports
            if module == 'pickle':
                self.results['p0_risks'].append({
                    'file': rel_path,
                    'import': module,
                    'desc': UNSAFE_IMPORTS['P0_CRITICAL']['pickle'],
                })
            elif module == 'marshal':
                self.results['p0_risks'].append({
                    'file': rel_path,
                    'import': module,
                    'desc': UNSAFE_IMPORTS['P0_CRITICAL']['marshal'],
                })
            elif module == 'yaml':
                # Check if using safe Loader
                if 'yaml.load' in content and 'SafeLoader' not in content and 'Loader=yaml.SafeLoader' not in content:
                    self.results['p1_warnings'].append({
                        'file': rel_path,
                        'import': module,
                        'desc': UNSAFE_IMPORTS['P1_WARNING']['yaml_unsafe'],
                    })
            elif module == 'hashlib':
                if 'md5' in content and 'sha256' not in content:
                    self.results['p2_notes'].append({
                        'file': rel_path,
                        'import': module,
                        'desc': UNSAFE_IMPORTS['P2_INFO']['hashlib_md5'] if 'hashlib_md5' in UNSAFE_IMPORTS['P2_INFO'] else 'Using MD5 hash (weak)',
                    })
            elif module == 'os':
                if 'os.system' in content:
                    self.results['p2_notes'].append({
                        'file': rel_path,
                        'import': module,
                        'desc': UNSAFE_IMPORTS['P2_INFO']['os_system'],
                    })
            # Everything else is considered safe
            elif module in ('sys', 'os', 'json', 're', 'pathlib', 'datetime',
                          'collections', 'io', 'time', 'hashlib', 'threading',
                          'subprocess', 'argparse', 'traceback', 'builtins',
                          'urllib', 'http', 'typing', 'dataclasses', 'abc',
                          'safe_io', 'integrity_guard', 'learn_sync'):
                self.results['safe_imports'].append({
                    'file': rel_path,
                    'import': module,
                })


class AutoFixer:
    """Automatically fix common skill issues."""

    def __init__(self, skill_dir, results):
        self.skill_dir = Path(skill_dir)
        self.skill_name = self.skill_dir.name
        self.results = results

    def fix_all_safe(self):
        """Apply all safe auto-fixes."""
        print(f"\n[AUTO-FIX] Applying safe fixes for {self.skill_name}...")

        for fix in self.results.get('fixes_available', []):
            if fix['safe']:
                self._apply_fix(fix['fix'])

    def _apply_fix(self, fix_id):
        """Apply a specific fix."""
        if fix_id == 'add_frontmatter':
            self._add_frontmatter()
        elif fix_id == 'generate_manifest':
            self._generate_manifest()
        elif fix_id == 'add_safe_io':
            self._copy_safe_io()

    def _add_frontmatter(self):
        """Generate SKILL.md frontmatter template."""
        skill_md = self.skill_dir / "SKILL.md"
        if not skill_md.exists():
            template = f"""---
name: {self.skill_name}
version: 0.0.1
description: "Add your skill description here"
---

# {self.skill_name}

## Overview
Add your skill overview here.

## Features
- Feature 1
- Feature 2

## Usage
How to use this skill.

---

*[Contact Author QQ: 1817694478 | Q-Group: 972156177 for questions/suggestions]*\n"""
            skill_md.write_text(template, encoding='utf-8')
            print(f"  [OK] Created SKILL.md with frontmatter template")
        else:
            content = safe_read_text(skill_md, timeout=5)
            if content and not content.strip().startswith('---'):
                # Add frontmatter to existing file
                new_content = f"""---
name: {self.skill_name}
version: 0.0.1
description: "Add description"
---

{content}"""
                skill_md.write_text(new_content, encoding='utf-8')
                print(f"  [OK] Added frontmatter to existing SKILL.md")

    def _generate_manifest(self):
        """Generate manifest.json with SHA256 hashes."""
        manifest = {
            'skill_name': self.skill_name,
            'version': '0.0.1',
            'generated_at': datetime.now().isoformat(),
            'file_count': 0,
            'files': {},
            'watermark': '',
        }

        for f in self.skill_dir.rglob('*'):
            if f.is_file() and not any(x in str(f) for x in [
                '__pycache__', '.pyc', '.git/', 'node_modules',
                'learn_data', 'learn_sync_cache', 'user_data',
                'pending_sync', 'sync_log'
            ]):
                rel = str(f.relative_to(self.skill_dir))
                try:
                    sha = hashlib.sha256(f.read_bytes()).hexdigest()
                    manifest['files'][rel] = {
                        'sha256': sha,
                        'size': f.stat().st_size,
                    }
                    manifest['file_count'] += 1
                except Exception:
                    pass

        # Generate structural watermark
        file_list = sorted(manifest['files'].keys())
        manifest['watermark'] = hashlib.sha256(
            json.dumps(file_list).encode()
        ).hexdigest()[:16]

        manifest_path = self.skill_dir / 'manifest.json'
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
        print(f"  [OK] Generated manifest.json ({manifest['file_count']} files)")

    def _copy_safe_io(self):
        """Copy safe_io.py template from skill-trend-analyzer."""
        src = SCRIPT_DIR / 'safe_io.py'
        dst = self.skill_dir / 'scripts' / 'safe_io.py'
        if src.exists() and not dst.exists():
            dst.parent.mkdir(exist_ok=True)
            # Copy with skill-specific header
            content = src.read_text(encoding='utf-8')
            # Replace skill name in header
            content = re.sub(
                r'Skill: skill-trend-analyzer',
                f'Skill: {self.skill_name}',
                content
            )
            dst.write_text(content, encoding='utf-8')
            print(f"  [OK] Copied safe_io.py to scripts/")


# ============================================================
# Batch Checker
# ============================================================

def check_all_skills(verbose=False):
    """Check all locally installed skills."""
    if not SKILLS_ROOT.exists():
        print(f"[ERROR] Skills root not found: {SKILLS_ROOT}")
        return []

    skill_dirs = [
        d for d in sorted(SKILLS_ROOT.iterdir())
        if d.is_dir() and not d.name.startswith('.') and (d / "SKILL.md").exists()
    ]

    print(f"\n[INFO] Checking {len(skill_dirs)} local skills...")
    all_results = []

    for i, skill_dir in enumerate(skill_dirs):
        checker = SkillQualityChecker(skill_dir, verbose=verbose)
        with TimeoutGuard(seconds=30, message=f"Checking {skill_dir.name} stuck"):
            results = checker.check_all()
        all_results.append(results)

    # Summary table
    print(f"\n{'='*65}")
    print(f"  All Skills Compliance Summary")
    print(f"{'='*65}")
    print(f"  {'Skill':<30} {'Score':>6} {'Grade':<20} {'P0':>3} {'P1':>3} {'SizeKB':>7}")
    print(f"  {'-'*30} {'-'*6} {'-'*20} {'-'*3} {'-'*3} {'-'*7}")

    for r in sorted(all_results, key=lambda x: -x['compliance_score']):
        p0 = len(r['security']['P0'])
        p1 = len(r['security']['P1'])
        size = r['performance']['total_size_kb']
        grade = r.get('compliance_grade', '?')
        print(f"  {r['skill_name']:<30} {r['compliance_score']:>5}% {grade:<20} {p0:>3} {p1:>3} {size:>7}")

    # Save results
    output = DATA_DIR / 'quality_reports.json'
    output.write_text(json.dumps(all_results, indent=2, ensure_ascii=False), encoding='utf-8')
    print(f"\n[OK] Saved to {output}")
    print(f"{'='*65}")

    return all_results


# ============================================================
# CLI Entry Point
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Skill Quality Checker - 7 Capabilities")
    parser.add_argument("skill_dir", nargs='?', help="Path to skill directory")
    parser.add_argument("--fix", action="store_true", help="Auto-fix where possible")
    parser.add_argument("--batch", action="store_true", help="Check all local skills")
    parser.add_argument("--report", action="store_true", help="Generate detailed report")
    parser.add_argument("--verbose", action="store_true", help="Show all details")
    parser.add_argument("--deps", action="store_true", help="Scan dependency security (imports)")
    parser.add_argument("--create", nargs=2, metavar=("NAME", "DESC"), help="Create new skill skeleton: NAME DESC")

    args = parser.parse_args()

    # ---- 执行日志 start ----
    subcmd = "create" if args.create else "batch" if args.batch else "single"
    logger = ExecutionLogger("skill_quality_checker")
    logger.start({
        "subcommand": subcmd,
        "skill_dir": args.skill_dir or str(SCRIPT_DIR.parent),
        "create": args.create,
        "fix": args.fix,
        "report": args.report,
        "deps": args.deps,
        "verbose": args.verbose,
    })

    try:
        # Capability 7: Create new skill from template
        if args.create:
            guide = SkillCreationGuide(name=args.create[0], desc=args.create[1])
            guide.create_skill()
            logger.done({"subcommand": "create", "skill_name": args.create[0]})
            return

        if args.batch:
            logger.phase("batch_check")
            all_results = check_all_skills(verbose=args.verbose)
            scores = [r.get("compliance_score", 0) for r in all_results]
            avg_score = sum(scores) / max(len(scores), 1)
            logger.done({
                "subcommand": "batch",
                "skills_checked": len(all_results),
                "avg_compliance_score": round(avg_score, 1),
            })
            return

        if not args.skill_dir:
            # Default: check ourselves
            args.skill_dir = str(SCRIPT_DIR.parent)

        skill_dir = Path(args.skill_dir)
        if not skill_dir.exists():
            logger.fail(f"Directory not found: {skill_dir}", {})
            return

        logger.phase("quality_check")
        checker = SkillQualityChecker(skill_dir, verbose=args.verbose)
        results = checker.check_all()

        if args.deps:
            logger.phase("dependency_scan")
            dep_scanner = DependencyScanner(skill_dir, verbose=args.verbose)
            dep_results = dep_scanner.scan_all()
            results['dependency_scan'] = dep_results

        if args.fix:
            logger.phase("auto_fix")
            fixer = AutoFixer(skill_dir, results)
            fixer.fix_all_safe()
            print("\n[RE-CHECK] Verifying fixes...")
            checker2 = SkillQualityChecker(skill_dir, verbose=args.verbose)
            checker2.check_all()

        if args.report:
            report_path = DATA_DIR / f'quality_{skill_dir.name}.json'
            report_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding='utf-8')
            print(f"\n[OK] Report saved to {report_path}")

        p0 = len(results.get('security', {}).get('P0', []))
        p1 = len(results.get('security', {}).get('P1', []))
        score = results.get('compliance_score', 0)
        logger.done({
            "subcommand": "single",
            "skill": skill_dir.name,
            "skills_checked": 1,
            "compliance_score": score,
            "p0_risks": p0,
            "p1_risks": p1,
            "recommendations": len(results.get('recommendations', [])),
            "fixes_applied": args.fix,
        })

    except Exception as e:
        logger.fail(str(e), {})
        import traceback; traceback.print_exc()


if __name__ == "__main__":
    main()

sys.stdout.buffer.write("\n[Rose]Contact Author QQ: 1817694478 [Penguin]Q-Group: 972156177\n".encode("utf-8",errors="replace"))