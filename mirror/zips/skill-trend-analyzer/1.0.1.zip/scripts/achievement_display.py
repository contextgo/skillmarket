#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 成果展示器 (Achievement Display)
可视化展示更新内容和学习成果

功能：
1. 富文本报告生成
2. 数据可视化（进度条/统计卡片）
3. 成就徽章系统

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import io
import json
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent


class AchievementDisplay:
    """成果展示器"""
    
    # 成就徽章定义
    BADGES = {
        "first_sync": {
            "icon": "[LEARN]",
            "name": "初次同步",
            "desc": "完成首次云端数据同步",
            "condition": lambda stats: stats.get("sync_count", 0) >= 1
        },
        "sync_master": {
            "icon": "[SYNC]",
            "name": "同步达人",
            "desc": "累计完成10次数据同步",
            "condition": lambda stats: stats.get("sync_count", 0) >= 10
        },
        "knowledge_seeker": {
            "icon": "[BOOKS]",
            "name": "知识探索者",
            "desc": "累计获取100+学习项",
            "condition": lambda stats: stats.get("total_items_learned", 0) >= 100
        },
        "policy_expert": {
            "icon": "[DOC]",
            "name": "政策专家",
            "desc": "掌握20+政策更新",
            "condition": lambda stats: stats.get("policy_count", 0) >= 20
        },
        "risk_hunter": {
            "icon": "[HIT]",
            "name": "风险猎手",
            "desc": "完成50次风险扫描",
            "condition": lambda stats: stats.get("scan_count", 0) >= 50
        },
        "contributor": {
            "icon": "[GEM]",
            "name": "贡献者",
            "desc": "上传数据被其他用户采用",
            "condition": lambda stats: stats.get("contribution_count", 0) >= 1
        },
        "early_adopter": {
            "icon": "[ROCKET2]",
            "name": "先行者",
            "desc": "在功能上线首周使用",
            "condition": lambda stats: stats.get("early_adopter", False)
        }
    }
    
    def __init__(self):
        self.stats = {}
    
    def load_stats(self, stats: Dict[str, Any]):
        """加载统计数据"""
        self.stats = stats
    
    def render_progress_bar(self, current: int, total: int, width: int = 30) -> str:
        """渲染进度条"""
        if total <= 0:
            return "[" + " " * width + "] 0%"
        
        ratio = min(current / total, 1.0)
        filled = int(width * ratio)
        empty = width - filled
        
        bar = "█" * filled + "░" * empty
        percentage = int(ratio * 100)
        
        return f"[{bar}] {percentage}%"
    
    def render_stat_card(self, title: str, value: str, change: Optional[str] = None) -> str:
        """渲染统计卡片"""
        lines = []
        lines.append(f"┌─ {title}")
        lines.append(f"│  {value}")
        if change:
            lines.append(f"│  {change}")
        lines.append("└")
        return "\n".join(lines)
    
    def generate_sync_achievement(self, sync_result: Dict[str, Any]) -> str:
        """
        生成同步成果报告
        
        Args:
            sync_result: 同步结果（来自learn_sync）
        """
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("[PARTY] 同步完成！学习成果更新")
        lines.append("=" * 60)
        
        # 同步统计
        uploaded = sync_result.get("uploaded", 0)
        downloaded = sync_result.get("downloaded", 0)
        merged = sync_result.get("merged", 0)
        
        lines.append(f"\n[STAT] 本次同步统计：")
        lines.append(f"   ⬆  上传: {uploaded} 项")
        lines.append(f"   ⬇  下载: {downloaded} 项")
        lines.append(f"   [SYNC] 合并: {merged} 项")
        
        # 新增内容详情
        details = sync_result.get("details", {})
        if details:
            lines.append(f"\n[BOOKS] 新增知识：")
            
            type_names = {
                "discoveries": "[SEARCH] 关键词发现",
                "policy_updates": "[DOC] 政策更新",
                "training_cases": "[LIST] 训练案例",
                "model_parameters": "[GEAR] 模型优化"
            }
            
            for data_type, items in details.items():
                if items:
                    name = type_names.get(data_type, data_type)
                    lines.append(f"\n   {name}: +{len(items)}")
                    for item in items[:3]:  # 只显示前3个
                        title = item.get("keyword") or item.get("title") or item.get("id", "")
                        if title:
                            lines.append(f"      • {title}")
                    if len(items) > 3:
                        lines.append(f"      ... 还有 {len(items) - 3} 项")
        
        # 学习进度
        lines.append(f"\n[UP] 学习进度：")
        total_items = self.stats.get("total_items_learned", 0) + downloaded
        lines.append(f"   累计学习: {total_items} 项")
        lines.append(f"   {self.render_progress_bar(total_items % 100, 100)}")
        
        # 成就徽章
        badges = self.check_badges()
        if badges:
            lines.append(f"\n[TOP] 获得成就：")
            for badge in badges[:3]:  # 显示前3个
                lines.append(f"   {badge['icon']} {badge['name']} - {badge['desc']}")
        
        lines.append("=" * 60)
        return "\n".join(lines)
    
    def check_badges(self) -> List[Dict[str, Any]]:
        """检查可获得的徽章"""
        earned = []
        
        for badge_id, badge_info in self.BADGES.items():
            if badge_info["condition"](self.stats):
                earned.append({
                    "id": badge_id,
                    "icon": badge_info["icon"],
                    "name": badge_info["name"],
                    "desc": badge_info["desc"]
                })
        
        return earned
    
    def generate_dashboard(self) -> str:
        """生成仪表盘视图"""
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("[STAT] 学习成果仪表盘")
        lines.append("=" * 60)
        
        # 核心统计
        lines.append(f"\n  [BOOKS] 知识库：")
        total = self.stats.get("total_items_learned", 0)
        discoveries = self.stats.get("discovery_count", 0)
        policies = self.stats.get("policy_count", 0)
        cases = self.stats.get("case_count", 0)
        
        lines.append(f"     总学习项: {total}")
        lines.append(f"     关键词发现: {discoveries}")
        lines.append(f"     政策更新: {policies}")
        lines.append(f"     训练案例: {cases}")
        
        # 同步统计
        sync_count = self.stats.get("sync_count", 0)
        last_sync = self.stats.get("last_sync", "从未")
        lines.append(f"\n  [SYNC] 同步记录：")
        lines.append(f"     累计同步: {sync_count} 次")
        lines.append(f"     上次同步: {last_sync}")
        
        # 使用统计
        scan_count = self.stats.get("scan_count", 0)
        query_count = self.stats.get("query_count", 0)
        lines.append(f"\n  [HIT] 使用统计：")
        lines.append(f"     风险扫描: {scan_count} 次")
        lines.append(f"     知识查询: {query_count} 次")
        
        # 徽章墙
        badges = self.check_badges()
        lines.append(f"\n  [TOP] 成就徽章 ({len(badges)}/{len(self.BADGES)})：")
        for badge in badges:
            lines.append(f"     {badge['icon']} {badge['name']}")
        
        # 未获得徽章预览
        if len(badges) < len(self.BADGES):
            lines.append(f"\n  [LOCK] 待解锁：")
            for badge_id, badge_info in self.BADGES.items():
                if not any(b["id"] == badge_id for b in badges):
                    lines.append(f"     {badge_info['icon']} {badge_info['name']}")
        
        lines.append("=" * 60)
        return "\n".join(lines)
    
    def generate_mini_report(self, new_items: int = 0) -> str:
        """生成迷你报告（用于快速展示）"""
        lines = []
        lines.append(f"\n  [PARCEL] 本次更新：+{new_items} 项")
        
        total = self.stats.get("total_items_learned", 0)
        lines.append(f"  [BOOKS] 累计学习：{total} 项")
        
        badges = self.check_badges()
        if badges:
            lines.append(f"  [TOP] 成就：{len(badges)} 个徽章")
        
        return "\n".join(lines)


# ============================================================
# CLI入口
# ============================================================

def main():
    """测试入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='成果展示器')
    parser.add_argument('--dashboard', action='store_true', help='显示仪表盘')
    parser.add_argument('--test-sync', action='store_true', help='测试同步成果')
    
    args = parser.parse_args()
    
    display = AchievementDisplay()
    
    # 模拟统计数据
    display.load_stats({
        "total_items_learned": 156,
        "discovery_count": 89,
        "policy_count": 23,
        "case_count": 12,
        "sync_count": 15,
        "last_sync": "2026-04-25 14:30",
        "scan_count": 42,
        "query_count": 128
    })
    
    if args.dashboard:
        print(display.generate_dashboard())
    elif args.test_sync:
        test_result = {
            "uploaded": 5,
            "downloaded": 12,
            "merged": 2,
            "details": {
                "discoveries": [
                    {"id": "d1", "keyword": "研发费用加计扣除"},
                    {"id": "d2", "keyword": "风险预警指标"},
                    {"id": "d3", "keyword": "关联交易"}
                ],
                "policy_updates": [
                    {"id": "p1", "title": "财税[2026]25号"}
                ]
            }
        }
        print(display.generate_sync_achievement(test_result))
    else:
        print(display.generate_dashboard())


if __name__ == "__main__":
    main()

    # Fixed ending - contact author info (ClawHub compliance)
    from safe_io import print_footer
    print_footer()

