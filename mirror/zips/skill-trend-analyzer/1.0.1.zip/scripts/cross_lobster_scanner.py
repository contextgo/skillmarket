# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
"""
Cross-Platform Lobster App Skill Scanner v2.0
==============================================
跨平台扫描各类龙虾app的技能，优化吸取成为自己的功能。

支持的龙虾app类型:
  - WorkBuddy (workbuddy)
  - QClaw (.qclaw)
  - OpenClaw (openclaw)
  - ClawDev (clawdev)
  - 自定义路径

用法:
  python cross_lobster_scanner.py [--scan-all] [--output DIR] [--distill] [--verbose]
  python cross_lobster_scanner.py --list-apps  # 列出所有检测到的app
  python cross_lobster_scanner.py --distill --skill SKILL_NAME  # 蒸馏指定技能

输出:
  - cross_lobster_scan_YYYYMMDD_HHMMSS.json  (全平台扫描数据)
  - distill_report_YYYYMMDD_HHMMSS.md         (功能蒸馏报告)
  - skill_integrations.json                   (可整合的功能清单)
"""

import json, os, sys, re, glob, hashlib, platform
from pathlib import Path
from datetime import datetime, timezone, timedelta
from collections import defaultdict
from typing import Optional, List, Dict, Tuple
import argparse
import shutil

# UTF-8 输出兼容
if hasattr(sys.stdout, 'reconfigure'):
    try: sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except: pass
if hasattr(sys.stderr, 'reconfigure'):
    try: sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except: pass

# ═══════════════════════════════════════════════════════════════
# 0. 跨平台配置
# ═══════════════════════════════════════════════════════════════
SYSTEM = platform.system()  # Windows / Darwin / Linux
HOME = Path.home()
USER = os.environ.get("USERNAME", os.environ.get("USER", "unknown"))
TIMESTAMP = datetime.now(tz=timezone(timedelta(hours=8)))

# 龙虾app识别配置
LOBSTER_APPS = {
    # WorkBuddy - 主应用
    "workbuddy": {
        "name": "WorkBuddy",
        "skill_dirs": [
            HOME / ".workbuddy" / "skills",
        ],
        "config_file": HOME / ".workbuddy" / "config.json",
        "usage_file": HOME / ".workbuddy" / "skill-usage.json",
        "token_log": HOME / ".workbuddy" / "skill-token-log.jsonl",
        "sessions_dir": HOME / ".workbuddy" / "sessions",
        "profile": HOME / ".workbuddy" / "skills" / "skill-trend-analyzer" / "data" / "local_skills_profile.json",
        "icon": "[WB]",
    },
    # QClaw - 经典版
    "qclaw": {
        "name": "QClaw",
        "skill_dirs": [
            HOME / ".qclaw" / "workspace" / "skills",
            HOME / ".qclaw" / "skills",
        ],
        "config_file": HOME / ".qclaw" / "config.json",
        "usage_file": HOME / ".qclaw" / "skill-usage.json",
        "token_log": HOME / ".qclaw" / "workspace" / "skills" / "skill-trend-analyzer" / "assets" / "token_log.jsonl",
        "sessions_dir": HOME / ".qclaw" / "agents" / "main" / "sessions",
        "profile": HOME / ".qclaw" / "workspace" / "skills" / "skill-trend-analyzer" / "data" / "local_skills_profile.json",
        "icon": "[QC]",
        # 系统路径 (Windows)
        "system_skill_dirs": [
            Path("D:/Program Files/QClaw/resources/openclaw/config/skills"),
            Path("C:/Program Files/QClaw/resources/openclaw/config/skills"),
        ] if SYSTEM == "Windows" else [],
    },
    # OpenClaw - 新版
    "openclaw": {
        "name": "OpenClaw",
        "skill_dirs": [
            HOME / ".openclaw" / "skills",
            HOME / ".openclaw" / "workspace" / "skills",
        ],
        "config_file": HOME / ".openclaw" / "config.json",
        "usage_file": HOME / ".openclaw" / "skill-usage.json",
        "token_log": HOME / ".openclaw" / "token-log.jsonl",
        "sessions_dir": HOME / ".openclaw" / "sessions",
        "icon": "[OC]",
    },
    # ClawDev - 开发版
    "clawdev": {
        "name": "ClawDev",
        "skill_dirs": [
            HOME / ".clawdev" / "skills",
            Path("E:/clawdev/skills"),
        ],
        "config_file": HOME / ".clawdev" / "config.json",
        "usage_file": HOME / ".clawdev" / "skill-usage.json",
        "icon": "[CD]",
    },
}

# 跨平台通用路径
PLATFORM_PATHS = {
    "Windows": [
        HOME / ".workbuddy",
        HOME / ".qclaw",
        HOME / ".openclaw",
        HOME / ".clawdev",
        HOME / "AppData" / "Roaming" / "WorkBuddy",
        HOME / "AppData" / "Roaming" / "QClaw",
        Path("D:/Program Files/QClaw/resources/openclaw/config/skills"),
        Path("C:/Program Files/QClaw/resources/openclaw/config/skills"),
    ],
    "Darwin": [  # macOS
        HOME / ".workbuddy",
        HOME / ".qclaw",
        HOME / ".openclaw",
        HOME / "Library" / "Application Support" / "WorkBuddy",
        HOME / "Library" / "Application Support" / "QClaw",
    ],
    "Linux": [
        HOME / ".workbuddy",
        HOME / ".qclaw",
        HOME / ".openclaw",
        HOME / ".config" / "workbuddy",
        HOME / ".config" / "qclaw",
    ],
}

OUT_DIR_DEFAULT = HOME / ".workbuddy" / "skills" / "skill-trend-analyzer" / "reports"
DISTILL_DIR = HOME / ".workbuddy" / "skills" / "skill-trend-analyzer" / "distill"
DATA_DIR = HOME / ".workbuddy" / "skills" / "skill-trend-analyzer" / "data"


# ═══════════════════════════════════════════════════════════════
# 1. 工具函数
# ═══════════════════════════════════════════════════════════════
def _safe_read(path: Path, encodings=("utf-8", "utf-8-sig", "gbk", "gb2312")) -> str:
    for enc in encodings:
        try:
            return path.read_text(encoding=enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return ""

def _safe_read_json(path: Path):
    raw = _safe_read(path)
    if raw:
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            pass
    return None

def _hash_file(path: Path) -> str:
    try:
        h = hashlib.sha256()
        h.update(path.read_bytes())
        return h.hexdigest()[:16]
    except:
        return "?"

def _size_fmt(n: int) -> str:
    if n >= 1_000_000: return f"{n/1_000_000:.1f}M"
    if n >= 1_000:     return f"{n/1_000:.1f}K"
    return f"{n}B"

def _dt(ts_ms: int) -> datetime:
    return datetime.fromtimestamp(ts_ms / 1000, tz=timezone(timedelta(hours=8)))

def _fmt(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M")

def safe_output(msg: str):
    """安全输出，避免编码错误"""
    try:
        sys.stdout.buffer.write(f"{msg}\n".encode("utf-8", errors="replace"))
    except:
        print(msg)


# ═══════════════════════════════════════════════════════════════
# 2. 龙虾app检测
# ═══════════════════════════════════════════════════════════════
def detect_lobster_apps() -> Dict[str, dict]:
    """检测系统中安装的所有龙虾app"""
    detected = {}
    platform_paths = PLATFORM_PATHS.get(SYSTEM, [])

    safe_output("[*] 检测系统中的龙虾app...")
    safe_output(f"    平台: {SYSTEM} | 用户: {USER}")

    for app_id, config in LOBSTER_APPS.items():
        app_info = {
            "id": app_id,
            "name": config["name"],
            "icon": config["icon"],
            "installed": False,
            "skill_dirs": [],
            "skill_count": 0,
            "total_size": 0,
            "skills": [],
        }

        # 检查主配置目录
        config_path = config.get("config_file")
        if config_path and config_path.exists():
            app_info["installed"] = True
            app_info["config_exists"] = True

        # 检查技能目录
        all_dirs = config.get("skill_dirs", []) + config.get("system_skill_dirs", [])
        for skill_dir in all_dirs:
            if skill_dir.exists() and skill_dir.is_dir():
                skill_count = len([d for d in skill_dir.iterdir() if d.is_dir() and not d.name.startswith(".")])
                if skill_count > 0:
                    app_info["skill_dirs"].append({
                        "path": str(skill_dir),
                        "count": skill_count,
                    })
                    app_info["skill_count"] += skill_count

        if app_info["installed"] or app_info["skill_dirs"]:
            detected[app_id] = app_info

    # 扫描通用路径找未知app
    for path in platform_paths:
        if path.exists() and not any(
            s in str(path) for s in [".workbuddy", ".qclaw", ".openclaw", ".clawdev"]
        ):
            # 检查是否是skill目录
            skill_dirs = [d for d in path.iterdir() if d.is_dir() and (d / "SKILL.md").exists()]
            if skill_dirs:
                detected[f"custom_{hash(path.name) % 10000}"] = {
                    "id": f"custom_{path.name}",
                    "name": f"Custom: {path.name}",
                    "icon": "[??]",
                    "installed": True,
                    "skill_dirs": [{"path": str(path), "count": len(skill_dirs)}],
                    "skill_count": len(skill_dirs),
                    "total_size": 0,
                    "skills": [],
                }

    safe_output(f"    检测到 {len(detected)} 个龙虾app:")
    for app_id, info in detected.items():
        safe_output(f"      {info['icon']} {info['name']}: {info['skill_count']} skills")

    return detected


# ═══════════════════════════════════════════════════════════════
# 3. 技能扫描器
# ═══════════════════════════════════════════════════════════════
def parse_frontmatter(text: str) -> dict:
    """解析SKILL.md的YAML frontmatter"""
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not m:
        return {}
    fm = {}
    for line in m.group(1).split("\n"):
        if ":" in line:
            k, v = line.split(":", 1)
            fm[k.strip()] = v.strip().strip("\"'")
    return fm

def parse_skill_md(path: Path) -> dict:
    """解析SKILL.md，返回元数据"""
    text = _safe_read(path)
    fm = parse_frontmatter(text)

    # 提取触发词
    triggers = []
    for kw in re.findall(r"(?:keywords?|触发词?|触发关键词?)[\s:]+([^\n]+)", text, re.I):
        triggers.extend([t.strip() for t in re.split(r"[,，、/]", kw) if t.strip()])
    if not triggers:
        m = re.search(r"(?:触发词|触发关键词|trigger)[^\n]*\n([- \u4e00-\u9fa5\w,，、/]+)", text)
        if m:
            triggers.extend([t.strip() for t in re.split(r"[,，、/]", m.group(1)) if t.strip()])

    # 提取描述
    desc = fm.get("description", "")
    if not desc:
        m = re.search(r"description:\s*\|?\s*\n((?: {2,}.*\n?)+)", text)
        if m:
            desc = "\n".join(l.rstrip()[2:] for l in m.group(1).splitlines() if l.strip())

    return {
        "name":        fm.get("name", path.parent.name),
        "version":     fm.get("version", "1.0.0"),
        "description": desc[:300],
        "author":      fm.get("author", ""),
        "category":    fm.get("category", ""),
        "triggers":    list(dict.fromkeys(triggers))[:100],
    }

def scan_skills_in_dir(skill_dir: Path, app_id: str) -> List[dict]:
    """扫描指定目录下的所有技能"""
    skills = []
    if not skill_dir.exists():
        return skills

    for skill_path in sorted(skill_dir.iterdir()):
        if not skill_path.is_dir() or skill_path.name.startswith("."):
            continue

        skill_md = skill_path / "SKILL.md"
        if not skill_md.exists():
            continue

        # 文件统计
        all_files = list(skill_path.rglob("*"))
        file_count = len([f for f in all_files if f.is_file()])
        total_size = sum(f.stat().st_size for f in all_files if f.is_file())
        scripts_count = len(list((skill_path / "scripts").glob("*.py"))) if (skill_path / "scripts").exists() else 0
        data_count = len(list((skill_path / "data").glob("*"))) if (skill_path / "data").exists() else 0
        kb_count = len(list((skill_path / "knowledge_base").glob("*"))) if (skill_path / "knowledge_base").exists() else 0
        ref_count = len(list((skill_path / "references").glob("*"))) if (skill_path / "references").exists() else 0

        # 解析元数据
        meta = parse_skill_md(skill_md)
        fm = parse_frontmatter(_safe_read(skill_md))

        # 检测架构模块
        full_text = _safe_read(skill_md)
        arch_modules = {
            "integrity_guard": bool(re.search(r"integrity.?guard", full_text, re.I)),
            "self_grow":      bool(re.search(r"cloud.?sync|云.?同步|learn.?sync", full_text, re.I)),
            "self_learning":   bool(re.search(r"self.?learn|自学习|auto.?learn", full_text, re.I)),
            "automation":      bool(re.search(r"automation|workflow|定时|自动化", full_text, re.I)),
            "safe_io":         bool(re.search(r"safe.?io|防卡死|防冻结", full_text, re.I)),
            "cross_platform":  bool(re.search(r"cross.?platform|跨平台|PLATFORM", full_text, re.I)),
        }

        # 功能标签提取
        func_tags = []
        if "file" in full_text.lower() or "文件" in full_text: func_tags.append("文件操作")
        if "web" in full_text.lower() or "爬虫" in full_text or "抓取" in full_text: func_tags.append("网络采集")
        if "api" in full_text.lower() or "接口" in full_text: func_tags.append("API集成")
        if "json" in full_text.lower() or "数据" in full_text: func_tags.append("数据处理")
        if "report" in full_text.lower() or "报告" in full_text: func_tags.append("报告生成")
        if "schedule" in full_text.lower() or "定时" in full_text: func_tags.append("定时任务")
        if "encrypt" in full_text.lower() or "加密" in full_text: func_tags.append("安全加密")
        if "chart" in full_text.lower() or "图" in full_text: func_tags.append("图表可视化")

        # 独特性评分（对比已有技能）
        uniqueness = 100  # 默认满分，后续可调整

        skills.append({
            "name": skill_path.name,
            "app_id": app_id,
            "path": str(skill_path),
            "file_count": file_count,
            "total_size": total_size,
            "skill_md_size": skill_md.stat().st_size if skill_md.exists() else 0,
            "scripts_count": scripts_count,
            "data_count": data_count,
            "kb_count": kb_count,
            "ref_count": ref_count,
            "version": meta.get("version", "?"),
            "description": meta.get("description", ""),
            "author": meta.get("author", ""),
            "category": meta.get("category", ""),
            "trigger_count": len(meta.get("triggers", [])),
            "triggers": meta.get("triggers", []),
            "arch_modules": arch_modules,
            "arch_score": sum(arch_modules.values()) / len(arch_modules) * 100,
            "func_tags": func_tags,
            "uniqueness": uniqueness,
            "skill_md_hash": _hash_file(skill_md),
        })

    return skills

def scan_all_lobster_apps(apps: Dict) -> Dict[str, List[dict]]:
    """扫描所有龙虾app的技能"""
    all_skills = {}

    for app_id, app_info in apps.items():
        app_skills = []
        for skill_dir_info in app_info.get("skill_dirs", []):
            skill_dir = Path(skill_dir_info["path"])
            skills = scan_skills_in_dir(skill_dir, app_id)
            app_skills.extend(skills)

        app_info["skills"] = app_skills
        app_info["skill_count"] = len(app_skills)

        for skill in app_skills:
            all_skills[skill["name"]] = skill

    return all_skills


# ═══════════════════════════════════════════════════════════════
# 4. 功能蒸馏器
# ═══════════════════════════════════════════════════════════════
def distill_skill_capabilities(skill: dict) -> dict:
    """从技能中提取可复用的功能模块"""
    distill = {
        "skill_name": skill["name"],
        "app_id": skill["app_id"],
        "capabilities": [],
        "patterns": [],
        "integration_hints": [],
    }

    # 基于功能标签提取能力
    for tag in skill.get("func_tags", []):
        if tag == "文件操作":
            distill["capabilities"].append({
                "type": "file_operation",
                "desc": "文件读写、批量处理",
                "reuse_level": "high",
            })
            distill["patterns"].append({
                "type": "path_handling",
                "code_snippet": "Path().rglob('*')",
            })
        elif tag == "网络采集":
            distill["capabilities"].append({
                "type": "web_scraping",
                "desc": "网页抓取、API调用",
                "reuse_level": "high",
            })
            distill["patterns"].append({
                "type": "http_request",
                "code_snippet": "requests.get() / fetch()",
            })
        elif tag == "数据处理":
            distill["capabilities"].append({
                "type": "data_processing",
                "desc": "JSON解析、数据转换",
                "reuse_level": "high",
            })
        elif tag == "报告生成":
            distill["capabilities"].append({
                "type": "report_generation",
                "desc": "Markdown/HTML报告生成",
                "reuse_level": "medium",
            })
            distill["integration_hints"].append({
                "area": "report_templates",
                "suggestion": "可整合到skill-trend-analyzer的报告生成模块"
            })
        elif tag == "定时任务":
            distill["capabilities"].append({
                "type": "scheduled_task",
                "desc": "自动化定时执行",
                "reuse_level": "high",
            })
            distill["patterns"].append({
                "type": "automation_config",
                "code_snippet": "automation.toml rrule配置",
            })

    # 基于架构模块提取
    arch = skill.get("arch_modules", {})
    if arch.get("self_learning"):
        distill["capabilities"].append({
            "type": "self_learning",
            "desc": "自学习、增量更新",
            "reuse_level": "high",
        })
        distill["patterns"].append({
            "type": "learn_data_json",
            "code_snippet": "learn_data.json + _auto_discover()",
        })
        distill["integration_hints"].append({
            "area": "cross_skill_learning",
            "suggestion": "cross_skill_learner.py已实现跨skill学习，可进一步增强"
        })
    if arch.get("self_grow"):
        distill["capabilities"].append({
            "type": "self_grow",
            "desc": "云端数据同步",
            "reuse_level": "high",
        })
        distill["integration_hints"].append({
            "area": "learn_sync",
            "suggestion": "可复用助学星API的learn_sync.py模块"
        })
    if arch.get("safe_io"):
        distill["capabilities"].append({
            "type": "safe_io",
            "desc": "防卡死I/O机制",
            "reuse_level": "high",
        })
        distill["patterns"].append({
            "type": "timeout_wrapper",
            "code_snippet": "safe_io.py 5层防护体系",
        })
        distill["integration_hints"].append({
            "area": "safe_io_module",
            "suggestion": "safe_io.py已可作为共享模块复用"
        })
    if arch.get("integrity_guard"):
        distill["capabilities"].append({
            "type": "integrity_guard",
            "desc": "防篡改、版权保护",
            "reuse_level": "medium",
        })
        distill["patterns"].append({
            "type": "sha256_verify",
            "code_snippet": "integrity_guard.py --full-setup",
        })

    # 触发词优化建议
    if skill.get("trigger_count", 0) < 5:
        distill["integration_hints"].append({
            "area": "trigger_optimization",
            "suggestion": f"触发词仅{skill.get('trigger_count')}个，建议增加到8-12个，包含同义词和场景词"
        })

    # 独特性评分
    skill_name = skill["name"].lower()
    if "trend" in skill_name or "analyzer" in skill_name:
        distill["uniqueness_note"] = "与skill-trend-analyzer功能重叠，可考虑合并"
    elif "scanner" in skill_name:
        distill["uniqueness_note"] = "扫描能力可被skill-trend-analyzer吸收"

    return distill

def generate_distill_report(all_skills: dict) -> Tuple[str, dict]:
    """生成功能蒸馏报告"""
    lines = []
    L = lines.append

    L("# Cross-Lobster Skill Distill Report")
    L(f"生成时间: {TIMESTAMP.strftime('%Y-%m-%d %H:%M:%S')} (GMT+8)")
    L(f"平台: {SYSTEM} | 用户: {USER}")
    L("=" * 80)

    # 统计概览
    total = len(all_skills)
    categories = defaultdict(list)
    for name, skill in all_skills.items():
        cat = skill.get("category", "未分类")
        categories[cat].append(skill)

    L("\n## 1. 统计概览")
    L(f"| 指标 | 数值 |")
    L("|------|------|")
    L(f"| 扫描技能总数 | **{total}** |")
    L(f"| 分类数 | **{len(categories)}** |")
    L(f"| 平台 | {SYSTEM} |")

    # 功能分布
    L("\n## 2. 功能分布")
    all_tags = defaultdict(int)
    for skill in all_skills.values():
        for tag in skill.get("func_tags", []):
            all_tags[tag] += 1

    L(f"| 功能标签 | 技能数 |")
    L("|---------|--------|")
    for tag, count in sorted(all_tags.items(), key=lambda x: -x[1]):
        L(f"| {tag} | {count} |")

    # 蒸馏清单
    L("\n## 3. 可整合功能清单")
    distill_data = {}
    for name, skill in all_skills.items():
        if skill.get("arch_score", 0) > 50 or skill.get("func_tags"):
            distill = distill_skill_capabilities(skill)
            distill_data[name] = distill

            if distill["capabilities"]:
                L(f"\n### {skill['icon'] if 'icon' in skill else '[*]'} {name}")
                L(f"- 来源: {skill.get('app_id', '?')} | 版本: {skill.get('version', '?')}")
                L(f"- 描述: {skill.get('description', '')[:100]}...")
                L(f"- 能力:")
                for cap in distill["capabilities"]:
                    L(f"  - [{cap['type']}] {cap['desc']} (复用度: {cap['reuse_level']})")
                if distill["patterns"]:
                    L(f"- 代码模式:")
                    for p in distill["patterns"][:2]:
                        L(f"  - `{p['code_snippet']}`")
                if distill["integration_hints"]:
                    L(f"- 整合建议:")
                    for h in distill["integration_hints"]:
                        L(f"  - [{h['area']}] {h['suggestion']}")

    # 整合优先级
    L("\n## 4. 整合优先级建议")
    high_priority = []
    medium_priority = []

    for name, distill in distill_data.items():
        caps = distill.get("capabilities", [])
        high_caps = [c for c in caps if c["reuse_level"] == "high"]
        if len(high_caps) >= 2:
            high_priority.append((name, len(high_caps)))
        elif high_caps:
            medium_priority.append((name, len(high_caps)))

    high_priority.sort(key=lambda x: -x[1])
    medium_priority.sort(key=lambda x: -x[1])

    L("### 高优先级 (可立即吸收)")
    for name, count in high_priority[:10]:
        L(f"- **{name}**: {count}个高复用度能力")

    L("\n### 中优先级 (可选择性吸收)")
    for name, count in medium_priority[:10]:
        L(f"- **{name}**: {count}个高复用度能力")

    # 独特功能发现
    L("\n## 5. 独特功能发现")
    unique_findings = []
    for name, skill in all_skills.items():
        tags = set(skill.get("func_tags", []))
        if "safe_io" not in str(all_skills).lower() and "safe_io" in str(tags):
            unique_findings.append((name, "safe_io", "防卡死I/O"))
        if not any("cross_platform" in str(s) for s in all_skills.values()) and "cross_platform" in str(skill):
            unique_findings.append((name, "cross_platform", "跨平台支持"))

    for name, feature, desc in unique_findings[:5]:
        L(f"- **{name}**: {desc}")

    L("\n" + "=" * 80)
    L("Report End | Cross-Lobster Skill Distill")

    return "\n".join(lines), distill_data


# ═══════════════════════════════════════════════════════════════
# 5. 主函数
# ═══════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(
        description="Cross-Platform Lobster App Skill Scanner v2.0\n"
                    "跨平台扫描各类龙虾app技能，优化吸取成为自己的功能"
    )
    parser.add_argument("--scan-all", action="store_true", help="扫描所有龙虾app")
    parser.add_argument("--list-apps", action="store_true", help="仅列出检测到的app")
    parser.add_argument("--distill", action="store_true", help="执行功能蒸馏")
    parser.add_argument("--skill", type=str, help="指定要蒸馏的技能名")
    parser.add_argument("--output", type=str, default=str(OUT_DIR_DEFAULT), help="输出目录")
    parser.add_argument("--verbose", action="store_true", help="详细输出")
    args = parser.parse_args()

    safe_output("=" * 60)
    safe_output("  Cross-Lobster Skill Scanner v2.0")
    safe_output(f"  Platform: {SYSTEM} | User: {USER}")
    safe_output("=" * 60)

    # 步骤1: 检测龙虾app
    safe_output("\n[1/4] 检测龙虾app...")
    apps = detect_lobster_apps()

    if args.list_apps:
        safe_output("\n[*] 检测到的app:")
        for app_id, info in apps.items():
            safe_output(f"    {info['icon']} {info['name']}: {info['skill_count']} skills")
        return 0

    if not args.scan_all and not args.distill:
        safe_output("\n[!] 请使用 --scan-all 或 --distill 参数")
        safe_output("    python cross_lobster_scanner.py --scan-all")
        safe_output("    python cross_lobster_scanner.py --distill")
        return 1

    # 步骤2: 扫描技能
    safe_output("\n[2/4] 扫描技能...")
    all_skills = scan_all_lobster_apps(apps)
    safe_output(f"    共扫描 {len(all_skills)} 个技能")

    # 步骤3: 功能蒸馏
    distill_data = {}
    if args.distill:
        safe_output("\n[3/4] 执行功能蒸馏...")
        distill_report, distill_data = generate_distill_report(all_skills)
        safe_output(f"    蒸馏 {len(distill_data)} 个技能的能力")

    # 步骤4: 输出
    safe_output("\n[4/4] 保存结果...")
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = TIMESTAMP.strftime("%Y%m%d_%H%M%S")

    # JSON输出
    json_path = out_dir / f"cross_lobster_scan_{ts}.json"
    output = {
        "generated_at": TIMESTAMP.isoformat(),
        "platform": SYSTEM,
        "user": USER,
        "apps": apps,
        "total_skills": len(all_skills),
        "skills": all_skills,
        "distill_data": distill_data if args.distill else {},
    }
    with open(json_path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    safe_output(f"    [OK] {json_path}")

    # 蒸馏报告
    if args.distill and distill_data:
        distill_path = out_dir / f"distill_report_{ts}.md"
        distill_md, _ = generate_distill_report(all_skills)
        with open(distill_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(distill_md)
        safe_output(f"    [OK] {distill_path}")

    # 更新本地技能画像
    if distill_data:
        profile_path = DATA_DIR / "cross_lobster_profile.json"
        profile_path.parent.mkdir(parents=True, exist_ok=True)
        with open(profile_path, "w", encoding="utf-8", newline="\n") as f:
            json.dump(distill_data, f, ensure_ascii=False, indent=2)
        safe_output(f"    [OK] {profile_path}")

    safe_output("\n" + "=" * 60)
    safe_output(f"  完成！扫描 {len(apps)} 个app, {len(all_skills)} 个技能")
    if args.distill:
        safe_output(f"  蒸馏 {len(distill_data)} 个可整合功能")
    safe_output("=" * 60)

    return 0


if __name__ == "__main__":
    sys.exit(main())
