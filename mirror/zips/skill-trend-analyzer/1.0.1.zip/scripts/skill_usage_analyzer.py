# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: skill-trend-analyzer | Version: 2.3.0
"""
skill_usage_analyzer.py
======================
全面扫描所有 Skill 的安装、使用、消耗、频率、命中、活跃度、名称、来源、路径等信息的分析报告生成器。

用法:
  python skill_usage_analyzer.py [--output DIR] [--format md|json|all] [--verbose]

输出:
  - skill_usage_report_YYYYMMDD_HHMMSS.md   (人类可读报告)
  - skill_usage_data_YYYYMMDD_HHMMSS.json  (原始数据)
"""

import json, os, sys, re, glob, hashlib
from pathlib import Path
from datetime import datetime, timezone, timedelta
from collections import defaultdict
from typing import Optional
import argparse

# ─────────────────────────────────────────────
# 0. 路径配置
# ─────────────────────────────────────────────
HOME = Path.home()
USER = os.environ.get("USERNAME", os.environ.get("USER", "unknown"))

SKILL_LOCATIONS = [
    ("本地工作区",  HOME / ".qclaw" / "workspace" / "skills"),
    ("托管技能",    HOME / ".qclaw" / "skills"),
    ("系统配置",    Path("D:/Program Files/QClaw/resources/openclaw/config/skills")),
    ("内置技能",    Path("D:/Program Files/QClaw/resources/openclaw/node_modules/openclaw/skills")),
]

DATA_SOURCES = {
    "usage":         HOME / ".qclaw" / "skill-usage.json",
    "sessions":      HOME / ".qclaw" / "agents" / "main" / "sessions" / "sessions.json",
    "token_log":     HOME / ".qclaw" / "workspace" / "skills" / "skill-trend-analyzer" / "assets" / "token_log.jsonl",
    "profile":       HOME / ".qclaw" / "workspace" / "skills" / "skill-trend-analyzer" / "data" / "local_skills_profile.json",
    "auto_memory":   HOME / ".qclaw" / ".auto-memory",
}

OUT_DIR_DEFAULT = HOME / ".qclaw" / "workspace" / "skills" / "skill-trend-analyzer" / "reports"


# ─────────────────────────────────────────────
# 1. 工具函数
# ─────────────────────────────────────────────
def _dt(ts_ms: int) -> datetime:
    return datetime.fromtimestamp(ts_ms / 1000, tz=timezone(timedelta(hours=8)))

def _fmt(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M")

def _days_since(ts_ms: int) -> int:
    return (datetime.now(tz=timezone(timedelta(hours=8))) - _dt(ts_ms)).days

def _safe_read(path: Path, encodings=("utf-8", "utf-8-sig", "gbk", "gb2312")) -> str:
    for enc in encodings:
        try:
            return path.read_text(encoding=enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return ""

def _safe_read_json(path: Path):
    raw = _safe_read(path)
    if raw:
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            pass
    return None

def _hash_file(path: Path) -> str:
    try:
        h = hashlib.sha256()
        h.update(path.read_bytes())
        return h.hexdigest()[:16]
    except:
        return "?"

def _size_fmt(n: int) -> str:
    if n >= 1_000_000: return f"{n/1_000_000:.1f}M"
    if n >= 1_000:     return f"{n/1_000:.1f}K"
    return f"{n}B"


# ─────────────────────────────────────────────
# 2. Frontmatter 解析
# ─────────────────────────────────────────────
def parse_frontmatter(text: str) -> dict:
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not m:
        return {}
    fm = {}
    for line in m.group(1).split("\n"):
        if ":" in line:
            k, v = line.split(":", 1)
            fm[k.strip()] = v.strip().strip("\"'")
    return fm

def parse_skill_md(path: Path) -> dict:
    """解析 SKILL.md，返回元数据字典"""
    text = _safe_read(path)
    fm = parse_frontmatter(text)

    # 提取触发词 (keywords / triggers / trigger phrases)
    triggers = []
    for kw in re.findall(r"(?:keywords?|触发词?|触发关键词?)[\s:]+([^\n]+)", text, re.I):
        triggers.extend([t.strip() for t in re.split(r"[,，、/]", kw) if t.strip()])
    trigger_section = re.search(r"(?:触发词|触发关键词|trigger)[^\n]*\n([- \u4e00-\u9fa5\w,，、/]+)", text)
    if trigger_section and not triggers:
        triggers.extend([t.strip() for t in re.split(r"[,，、/]", trigger_section.group(1)) if t.strip()])

    # 提取描述
    desc = fm.get("description", "")
    if not desc:
        m = re.search(r"description:\s*\|?\s*\n((?: {2,}.*\n?)+)", text)
        if m:
            desc = "\n".join(l.rstrip()[2:] for l in m.group(1).splitlines() if l.strip())

    # 提取作者
    author = fm.get("author", fm.get("作者", ""))
    version = fm.get("version", "1.0.0")

    # 提取分类/领域
    category = fm.get("category", fm.get("分类", ""))
    if not category:
        m = re.search(r"(?:分类|category|type)[\s:]+([^\n]+)", text)
        if m:
            category = m.group(1).strip().strip("\"'")

    return {
        "name":        fm.get("name", path.parent.name),
        "version":     version,
        "description": desc[:200],
        "author":      author,
        "category":    category,
        "triggers":    list(dict.fromkeys(triggers))[:100],
        "triggers_raw": fm.get("keywords", ""),
    }


# ─────────────────────────────────────────────
# 3. Skill 扫描器
# ─────────────────────────────────────────────
def scan_all_skills() -> dict[str, dict]:
    """扫描所有 Skill 目录，返回 {name: SkillInfo}"""
    results = {}

    for source_label, base_dir in SKILL_LOCATIONS:
        if not base_dir.exists():
            continue
        for skill_dir in sorted(base_dir.iterdir()):
            if skill_dir.is_file() or skill_dir.name.startswith("."):
                continue
            skill_md = skill_dir / "SKILL.md"
            if not skill_md.exists():
                continue

            name = skill_dir.name
            if name in results:
                # 已扫描过，跳过重复
                continue

            # 文件统计
            all_files = list(skill_dir.rglob("*"))
            file_count = len([f for f in all_files if f.is_file()])
            total_size = sum(f.stat().st_size for f in all_files if f.is_file())

            # 关键文件
            skill_md_size = skill_md.stat().st_size if skill_md.exists() else 0
            scripts_dir = skill_dir / "scripts"
            scripts_count = len(list(scripts_dir.glob("*.py"))) if scripts_dir.exists() else 0
            data_dir = skill_dir / "data"
            data_count = len(list(data_dir.glob("*"))) if data_dir.exists() else 0
            kb_dir = skill_dir / "knowledge_base"
            kb_count = len(list(kb_dir.glob("*"))) if kb_dir.exists() else 0

            # 目录创建时间 (近似)
            try:
                created = datetime.fromtimestamp(os.stat(skill_dir).st_ctime, tz=timezone(timedelta(hours=8)))
            except:
                created = datetime.now(tz=timezone(timedelta(hours=8)))

            # 解析 SKILL.md
            meta = parse_skill_md(skill_md)

            # SKILL.md SHA256 (用于版本追踪)
            md5 = _hash_file(skill_md)

            # 安装源路径
            install_path = str(skill_dir)

            # Frontmatter 字段
            fm = parse_frontmatter(_safe_read(skill_md))
            arch_modules = {
                "integrity_guard":  "integrity_guard" in skill_dir.name.lower() or bool(re.search(r"integrity.?guard", _safe_read(skill_md), re.I)),
                "self_grow":      "cloud" in str(skill_dir).lower() or bool(re.search(r"cloud.?sync|云.?同步", _safe_read(skill_md), re.I)),
                "self_learning":   bool(re.search(r"self.?learn|自学习|learn.?sync", _safe_read(skill_md), re.I)),
                "automation":      bool(re.search(r"automation|workflow.?engine|工作流", _safe_read(skill_md), re.I)),
            }

            results[name] = {
                "name":            name,
                "source":          source_label,
                "path":            install_path,
                "file_count":      file_count,
                "total_size":      total_size,
                "skill_md_size":   skill_md_size,
                "scripts_count":   scripts_count,
                "data_count":      data_count,
                "kb_count":        kb_count,
                "installed_at":    created.isoformat(),
                "skill_md_hash":   md5,
                "version":         meta.get("version", "?"),
                "description":     meta.get("description", ""),
                "author":          meta.get("author", ""),
                "category":        meta.get("category", ""),
                "trigger_count":   len(meta.get("triggers", [])),
                "triggers":        meta.get("triggers", []),
                "arch_modules":    arch_modules,
                "arch_score":      sum(arch_modules.values()) / len(arch_modules) * 100,
            }

    return results


# ─────────────────────────────────────────────
# 4. 数据加载器
# ─────────────────────────────────────────────
def load_usage_records() -> list[dict]:
    data = _safe_read_json(DATA_SOURCES["usage"])
    if data and "records" in data:
        return data["records"]
    return []

def load_session_tokens() -> dict[str, dict]:
    data = _safe_read_json(DATA_SOURCES["sessions"])
    if not data:
        return {}
    result = {}
    for key, val in data.items():
        if isinstance(val, dict):
            result[key] = {
                "input_tokens":  val.get("inputTokens", 0) or 0,
                "output_tokens": val.get("outputTokens", 0) or 0,
                "model":         val.get("model", "?"),
                "provider":      val.get("modelProvider", "?"),
                "updated":       val.get("updatedAt", ""),
                "label":         val.get("label", key),
                "session_id":    val.get("sessionId", key),
            }
    return result

def load_token_log() -> list[dict]:
    path = DATA_SOURCES["token_log"]
    records = []
    if path.exists():
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.strip():
                try:
                    records.append(json.loads(line))
                except:
                    pass
    return records

def load_scanner_profile() -> dict:
    data = _safe_read_json(DATA_SOURCES["profile"])
    if not data:
        return {}
    result = {}
    for name, val in data.get("skills", {}).items():
        result[name] = {
            "workflows":   len(val.get("workflows", [])),
            "algorithms": len(val.get("algorithms", [])),
            "kb_count":   len(val.get("knowledge_bases", [])),
            "arch_pct":   val.get("architecture", {}).get("completeness_pct", 0),
            "sections":   len(val.get("sections", [])),
        }
    return result


# ─────────────────────────────────────────────
# 5. 指标计算
# ─────────────────────────────────────────────
def calc_metrics(skills: dict, usage: list, sessions: dict, token_log: list, profile: dict) -> dict:
    # 技能使用次数
    skill_use_count = defaultdict(int)
    skill_first_use = {}
    skill_last_use = {}

    for r in usage:
        name = r["skillName"]
        ts = r["usedAt"]
        skill_use_count[name] += 1
        if name not in skill_first_use:
            skill_first_use[name] = ts
        skill_last_use[name] = ts

    now_ms = datetime.now(tz=timezone(timedelta(hours=8))).timestamp() * 1000
    total_days = 10  # 估算
    now_dt = datetime.now(tz=timezone(timedelta(hours=8)))

    metrics = {}
    for name, sinfo in skills.items():
        uc = skill_use_count.get(name, 0)
        first = skill_first_use.get(name)
        last = skill_last_use.get(name)

        # 命中/使用
        hit_rate = 100.0 if uc > 0 else 0.0

        # 频率 (次/天)
        freq = uc / max(total_days, 1)

        # 活跃天数
        if first and last:
            active_days = max(1, (_dt(last) - _dt(first)).days + 1)
        else:
            active_days = 0

        # 距今天数
        days_ago = _days_since(last) if last else 9999

        # 活跃度评分 (0-100)
        # 最近7天内用过=100, 30天内用过=60, 更久=30, 从未用=0
        if uc == 0:
            activity = 0
        elif days_ago <= 7:
            activity = 100
        elif days_ago <= 30:
            activity = 60
        else:
            activity = 30

        # 潜力评分 (未使用但触发词多/文件多 = 高潜力)
        potential = 0
        if uc == 0:
            potential = min(100, sinfo["trigger_count"] * 1.5 + sinfo["file_count"] * 0.5)

        # Token 消耗 (从 token_log 匹配)
        t_in = t_out = t_total = 0
        for t in token_log:
            if t.get("skill", "").startswith(name):
                t_in   += t.get("input_tokens", 0)
                t_out  += t.get("output_tokens", 0)
                t_total += t.get("total_tokens", 0)

        # Scanner profile 数据
        sc = profile.get(name, {})

        # 综合评分
        quality_score = (
            sinfo["arch_score"] * 0.2 +
            min(hit_rate, 100) * 0.25 +
            min(uc / 10 * 100, 100) * 0.2 +
            sinfo["trigger_count"] / 5 * 0.1 +
            (sinfo["file_count"] / 50 * 100) * 0.15 +
            (len([m for m in sinfo["arch_modules"].values() if m]) / 4 * 100) * 0.1
        )

        metrics[name] = {
            "use_count":      uc,
            "hit_rate":       round(hit_rate, 1),
            "frequency":      round(freq, 2),
            "active_days":    active_days,
            "days_ago":       days_ago,
            "activity_score": int(activity),
            "potential_score": int(potential),
            "quality_score":  int(min(quality_score, 100)),
            "first_used":     _fmt(_dt(first)) if first else "-",
            "last_used":      _fmt(_dt(last)) if last else "-",
            "token_in":       t_in,
            "token_out":      t_out,
            "token_total":    t_total,
            "workflows":      sc.get("workflows", 0),
            "algorithms":     sc.get("algorithms", 0),
            "scanner_kb":     sc.get("kb_count", 0),
            "scanner_arch":   sc.get("arch_pct", 0),
            "sections":       sc.get("sections", 0),
            "status":         "ACTIVE" if uc > 0 else "DORMANT",
        }

    return metrics


# ─────────────────────────────────────────────
# 6. Markdown 报告生成
# ─────────────────────────────────────────────
def gen_markdown(skills: dict, metrics: dict, usage: list, sessions: dict, token_log: list, profile: dict) -> str:
    now = datetime.now(tz=timezone(timedelta(hours=8)))
    lines = []
    L = lines.append

    def hr(c=100):
        L("-" * c)

    def h1(txt):
        L(f"\n## {txt}\n")

    def h2(txt):
        L(f"### {txt}\n")

    # 标题
    L("=" * 100)
    L(f"  Skill 全景分析报告")
    L(f"  生成时间: {now.strftime('%Y-%m-%d %H:%M:%S')} (GMT+8)")
    L(f"  操作员: {USER}")
    L("=" * 100)

    # ── 概览卡片 ──
    active   = [n for n, m in metrics.items() if m["status"] == "ACTIVE"]
    dormant  = [n for n, m in metrics.items() if m["status"] == "DORMANT"]
    total_t  = sum(m["token_total"] for m in metrics.values())
    total_in = sum(m["token_in"] for m in metrics.values())
    total_out= sum(m["token_out"] for m in metrics.values())
    sess_in  = sum(s.get("input_tokens", 0) for s in sessions.values())
    sess_out = sum(s.get("output_tokens", 0) for s in sessions.values())

    h1("[STAT] 概览")
    L(f"| 指标 | 数值 |")
    L("|------|------|")
    L(f"| 技能总数 | **{len(skills)}** |")
    L(f"| 活跃技能 (有使用记录) | **{len(active)}** |")
    L(f"| 沉睡技能 (从未使用) | **{len(dormant)}** |")
    L(f"| Token Logger 记录消耗 | {total_t:,} |")
    L(f"| 会话层 Token 消耗 | {sess_in + sess_out:,} (in:{sess_in:,} out:{sess_out:,}) |")
    L(f"| 技能加载总次数 | {len(usage)} |")

    # ── 活跃度排行榜 ──
    h1("[TOP] 活跃度 TOP 10")
    sorted_active = sorted(metrics.items(), key=lambda x: (-x[1]["activity_score"], x[1]["use_count"]))
    L(f"| 排名 | 技能名 | 状态 | 使用次数 | 活跃度 | 命中 | 频率(次/天) | 上次使用 | 距今 |")
    L("|------|--------|------|---------|--------|------|------------|---------|------|")
    for rank, (name, m) in enumerate(sorted_active[:10], 1):
        sinfo = skills.get(name, {})
        status_icon = "[GRN]" if m["activity_score"] >= 80 else ("[YEL]" if m["activity_score"] >= 40 else "[RED]")
        L(f"| {rank} | **{name}** | {status_icon}{m['status']} | {m['use_count']} | {m['activity_score']} | {m['hit_rate']}% | {m['frequency']:.2f} | {m['last_used']} | {m['days_ago']}天 |")

    # ── 沉睡技能 ──
    if dormant:
        h1(f"[SLEEP] 沉睡技能 ({len(dormant)}个 - 从未使用)")
        L(f"| 技能名 | 来源 | 触发词 | 文件数 | 潜力评分 | 架构完整度 | 路径 |")
        L("|--------|------|--------|--------|---------|-----------|------|")
        sorted_dormant = sorted(dormant, key=lambda n: -metrics[n]["potential_score"])
        for name in sorted_dormant:
            m = metrics[name]
            s = skills[name]
            L(f"| **{name}** | {s['source']} | {s['trigger_count']}个 | {s['file_count']} | {m['potential_score']} | {s['arch_score']:.0f}% | `{s['path'][:60]}...` |")

    # ── 完整列表 ──
    h1(f"[LIST] 完整技能列表 ({len(skills)}个)")
    L(f"| # | 技能名 | 状态 | 来源 | 使用 | 命中 | 活跃度 | 算法数 | 工作流 | 知识库 | Token消耗 | 触发词 | 路径 |")
    L("|---|--------|------|------|------|------|--------|--------|--------|--------|---------|--------|------|")
    for i, (name, sinfo) in enumerate(sorted(skills.items()), 1):
        m = metrics[name]
        sc = profile.get(name, {})
        status_emoji = "[GRN]" if m["status"]=="ACTIVE" else "[WHITE]"
        L(f"| {i} | **{name}** | {status_emoji}{m['status']} | {sinfo['source'][:6]} | {m['use_count']} | {m['hit_rate']}% | {m['activity_score']} | {m['algorithms']} | {m['workflows']} | {sinfo['kb_count']+m['scanner_kb']} | {m['token_total']:,} | {sinfo['trigger_count']} | `{sinfo['path'][:40]}` |")

    # ── Token 消耗分析 ──
    h1("[COST] Token 消耗分析")

    h2("会话级 Token (OpenClaw)")
    if sessions:
        sorted_sess = sorted(sessions.items(), key=lambda x: -(x[1].get("input_tokens",0)+x[1].get("output_tokens",0)))
        L(f"| 会话 | 模型 | Provider | Input | Output | 合计 |")
        L("|------|------|----------|-------|--------|------|")
        for key, s in sorted_sess[:15]:
            label = s.get("label", key)[:40]
            total = s.get("input_tokens", 0) + s.get("output_tokens", 0)
            L(f"| `{label}` | {s.get('model','?')} | {s.get('provider','?')} | {s.get('input_tokens',0):,} | {s.get('output_tokens',0):,} | **{total:,}** |")
    else:
        L("无会话数据")

    h2("技能级 Token (Logger)")
    if token_log:
        L(f"| 时间戳 | 技能 | 操作 | Input | Output | 合计 | 耗时 |")
        L("|--------|------|------|-------|--------|------|------|")
        for t in token_log:
            ts = t.get("timestamp", "?")[:26]
            L(f"| {ts} | {t.get('skill','?')} | {t.get('action','?')} | {t.get('input_tokens',0):,} | {t.get('output_tokens',0):,} | {t.get('total_tokens',0):,} | {t.get('duration_ms','?')}ms |")
    else:
        L("无 Logger 数据")

    # ── 触发词质量分析 ──
    h1("[HIT] 触发词质量分析 (TOP 10)")
    sorted_triggers = sorted(skills.items(), key=lambda x: x[1]["trigger_count"], reverse=True)
    L(f"| 技能名 | 触发词数 | 热门触发词 (前5) |")
    L("|--------|---------|------------------|")
    for name, sinfo in sorted_triggers[:10]:
        triggers = sinfo["triggers"][:5]
        L(f"| **{name}** | {sinfo['trigger_count']} | {', '.join(triggers) if triggers else '-'} |")

    # ── 架构完整性 ──
    h1("[BUILD] 架构完整性分析")
    L(f"| 技能名 | integrity_guard | self_grow | self_learning | automation | 架构评分 |")
    L("|--------|:--------------:|:-----------:|:-------------:|:----------:|----------|")
    for name, sinfo in sorted(skills.items()):
        am = sinfo["arch_modules"]
        ig = "[OK]" if am["integrity_guard"] else "[FAIL]"
        cs = "[OK]" if am["self_grow"] else "[FAIL]"
        sl = "[OK]" if am["self_learning"] else "[FAIL]"
        au = "[OK]" if am["automation"] else "[FAIL]"
        L(f"| **{name}** | {ig} | {cs} | {sl} | {au} | {sinfo['arch_score']:.0f}% |")

    # ── 使用时间线 ──
    h1("[DATE4] 使用时间线")
    sorted_usage = sorted(usage, key=lambda r: -r["usedAt"])
    L(f"| # | 日期时间 | 技能名 | 距今天数 |")
    L("|---|----------|--------|---------|")
    for i, r in enumerate(sorted_usage[:30], 1):
        dt = _dt(r["usedAt"])
        days = _days_since(r["usedAt"])
        L(f"| {i} | {_fmt(dt)} | {r['skillName']} | {days}天 |")

    # ── 综合评分 ──
    h1("[FAV] 综合评分榜 (TOP 20)")
    sorted_quality = sorted(metrics.items(), key=lambda x: -x[1]["quality_score"])
    L(f"| 排名 | 技能名 | 综合评分 | 活跃度 | 命中 | 架构 | 质量 |")
    L("|------|--------|---------|--------|------|------|------|")
    for rank, (name, m) in enumerate(sorted_quality[:20], 1):
        s = skills[name]
        L(f"| {rank} | **{name}** | {m['quality_score']} | {m['activity_score']} | {m['hit_rate']}% | {s['arch_score']:.0f}% | {'A' if m['quality_score']>=85 else 'B' if m['quality_score']>=70 else 'C' if m['quality_score']>=50 else 'D'} |")

    # ── 优化建议 ──
    h1("[TIP] 优化建议")
    suggestions = []

    never_used_high_potential = [n for n in dormant if metrics[n]["potential_score"] >= 50]
    if never_used_high_potential:
        suggestions.append(f"- [HOT] **{len(never_used_high_potential)}个高潜力技能从未使用**：{', '.join(never_used_high_potential[:5])}{'...' if len(never_used_high_potential)>5 else ''} — 建议探索这些技能的功能")

    low_arch = [n for n, m in metrics.items() if skills[n]["arch_score"] < 50]
    if low_arch:
        suggestions.append(f"- [BUILD] **{len(low_arch)}个技能架构不完整**：缺少 integrity_guard/self_grow/self_learning 模块，建议按 skill-trend-analyzer 的标准模板升级")

    no_triggers = [n for n, s in skills.items() if s["trigger_count"] == 0]
    if no_triggers:
        suggestions.append(f"- [HIT] **{len(no_triggers)}个技能缺少触发词**：{', '.join(no_triggers[:5])} — 无法被自然语言自动触发，建议添加描述和关键词")

    high_tokens = sorted(metrics.items(), key=lambda x: -x[1]["token_total"])
    if high_tokens and high_tokens[0][1]["token_total"] > 0:
        suggestions.append(f"- [COST] Token 消耗最高：{high_tokens[0][0]}（{high_tokens[0][1]['token_total']:,} tokens），建议评估是否可优化调用频率")

    if suggestions:
        for s in suggestions:
            L(s)
    else:
        L("暂无优化建议 [PARTY]")

    L("\n" + "=" * 100)
    L(f"  报告结束 | 共 {len(skills)} 个技能 | 数据来源: skill-usage.json, sessions.json, token_log.jsonl")
    L("=" * 100)

    return "\n".join(lines)


# ─────────────────────────────────────────────
# 7. JSON 导出
# ─────────────────────────────────────────────
def gen_json(skills: dict, metrics: dict, usage: list, sessions: dict, token_log: list, profile: dict) -> str:
    now = datetime.now(tz=timezone(timedelta(hours=8)))
    return json.dumps({
        "generated_at":  now.isoformat(),
        "operator":       USER,
        "skill_count":   len(skills),
        "active_count":  sum(1 for m in metrics.values() if m["status"] == "ACTIVE"),
        "dormant_count": sum(1 for m in metrics.values() if m["status"] == "DORMANT"),
        "skills": {
            name: {**sinfo, **metrics[name]}
            for name, sinfo in skills.items()
        },
        "session_tokens": sessions,
        "token_log":      token_log,
        "usage_records":   usage,
    }, ensure_ascii=False, indent=2)


# ─────────────────────────────────────────────
# 8. 主函数
# ─────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Skill 全景分析报告生成器")
    parser.add_argument("--output",   type=str, default=str(OUT_DIR_DEFAULT), help="输出目录")
    parser.add_argument("--format",    type=str, default="all", choices=["md","json","all"], help="输出格式")
    parser.add_argument("--verbose",   action="store_true", help="详细输出")
    parser.add_argument("--no-banner", action="store_true", help="跳过启动横幅")
    args = parser.parse_args()

    if not args.no_banner:
        print("=" * 60)
        print("  Skill Usage Analyzer v1.0")
        print("=" * 60)

    # 加载数据
    print("[1/5] 扫描 Skill 目录...")
    skills = scan_all_skills()
    print(f"      发现 {len(skills)} 个 Skill")

    print("[2/5] 加载使用记录...")
    usage = load_usage_records()
    print(f"      {len(usage)} 条加载记录")

    print("[3/5] 加载会话 Token...")
    sessions = load_session_tokens()
    print(f"      {len(sessions)} 个会话")

    print("[4/5] 加载 Token Log...")
    token_log = load_token_log()
    print(f"      {len(token_log)} 条记录")

    print("[5/5] 加载 Scanner Profile...")
    profile = load_scanner_profile()
    print(f"      {len(profile)} 个 Profile")

    # 计算指标
    print("\n[*] 计算指标...")
    metrics = calc_metrics(skills, usage, sessions, token_log, profile)

    # 输出
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(tz=timezone(timedelta(hours=8))).strftime("%Y%m%d_%H%M%S")

    if args.format in ("md", "all"):
        md_path = out_dir / f"skill_usage_report_{ts}.md"
        print(f"\n[*] 生成 Markdown 报告 → {md_path}")
        with open(md_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(gen_markdown(skills, metrics, usage, sessions, token_log, profile))
        print(f"      [OK] {md_path}")

    if args.format in ("json", "all"):
        json_path = out_dir / f"skill_usage_data_{ts}.json"
        print(f"\n[*] 生成 JSON 数据 → {json_path}")
        with open(json_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(gen_json(skills, metrics, usage, sessions, token_log, profile))
        print(f"      [OK] {json_path}")

    # 摘要
    print("\n" + "=" * 60)
    print(f"  完成！扫描 {len(skills)} 个 Skill")
    print(f"  活跃: {sum(1 for m in metrics.values() if m['status']=='ACTIVE')}")
    print(f"  沉睡: {sum(1 for m in metrics.values() if m['status']=='DORMANT')}")
    print("=" * 60)

    return 0


if __name__ == "__main__":
    sys.exit(main())
