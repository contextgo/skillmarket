#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
SkillTrendAnalyzer - Knowledge Search, Auto-Update & Self-Learning
知识搜索 + 联网自动提取 + 自更新本地JSON知识库

Core features:
1. Local knowledge search (skill patterns + paradigm library)
2. Web search keyword generation
3. Auto-extract new patterns/methods from search results
4. Auto-update local JSON knowledge base (pattern_library.json, paradigm_library.json)
5. Self-learning: track update effectiveness, evolve models

Usage:
    python knowledge_search.py --query "skill优化" --category "触发词"
    python knowledge_search.py --query "打包规范" --auto-update
    python knowledge_search.py --update-from-search results.json
    python knowledge_search.py --sync-status
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.
import sys, io, re, json, os, hashlib
from datetime import datetime
from pathlib import Path

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_skill_trend_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._skill_trend_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
REFERENCES_DIR = SKILL_DIR / "references"
ASSETS_DIR = SKILL_DIR / "assets"


def log(msg: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{ts}] {clean}", flush=True)


# ============================================================
# 1. Local Knowledge Search
# ============================================================

def search_local_knowledge(query: str, category: str = "all") -> list:
    """Search local risk models and case library"""
    results = []

    # Search risk models
    model_path = REFERENCES_DIR / "risk_models.json"
    if model_path.exists():
        with open(model_path, 'r', encoding='utf-8') as f:
            models = json.load(f)

        for domain in models.get("risk_domains", []):
            for sub in domain.get("sub_risks", []):
                searchable = f"{domain['name']} {sub['name']} {sub.get('description','')} " + \
                             " ".join(sub.get("policy_basis", [])) + " " + \
                             " ".join(i.get("indicator","") for i in sub.get("risk_indicators",[]))
                if query.lower() in searchable.lower():
                    results.append({
                        "source": "risk_models",
                        "id": sub["id"],
                        "domain": domain["name"],
                        "name": sub["name"],
                        "level": sub.get("risk_level",""),
                        "policy_basis": sub.get("policy_basis", []),
                        "risk_indicators": sub.get("risk_indicators", []),
                        "relevance": "high"
                    })

    # Search case library
    case_path = REFERENCES_DIR / "case_library.json"
    if case_path.exists():
        with open(case_path, 'r', encoding='utf-8') as f:
            cases = json.load(f)

        for case in cases.get("cases", []):
            searchable = f"{case['title']} {case.get('summary','')} " + \
                         " ".join(case.get("tags",[])) + " " + \
                         case.get("industry","") + " " + case.get("region","")
            if query.lower() in searchable.lower():
                results.append({
                    "source": "case_library",
                    "id": case["id"],
                    "title": case["title"],
                    "industry": case.get("industry",""),
                    "level": case.get("risk_level",""),
                    "relevance": "medium"
                })

    return results


# ============================================================
# 2. Web Search Keyword Generation
# ============================================================

def generate_search_keywords(industry: str, region: str, risk_area: str) -> list:
    """Generate web search keywords for latest policy/risk info"""
    year = datetime.now().year
    keywords = []

    if industry:
        keywords.append(f"{industry} 企业所得税 风险 {year}")
    if region:
        keywords.append(f"{region} 税务稽查 重点 {year}")
    if risk_area:
        keywords.append(f"企业所得税 {risk_area} 最新政策 {year}")

    keywords.append(f"金税四期 风险预警 最新指标 {year}")
    keywords.append(f"企业所得税 汇算清缴 常见问题 {year}")

    return keywords


# ============================================================
# 3. Auto-Extract from Web Search Results
# ============================================================

# Policy document number patterns
POLICY_PATTERNS = [
    r'(财税\[\d{4}\]\d+号)',
    r'(国家税务总局公告\d{4}年第\d+号)',
    r'(国税发\[\d{4}\]\d+号)',
    r'(国税函\[\d{4}\]\d+号)',
    r'(国家税务总局令第\d+号)',
    r'(国务院令第\d+号)',
]

# Risk keyword patterns for extraction
RISK_EXTRACT_PATTERNS = {
    "policy_basis": {
        "patterns": POLICY_PATTERNS,
        "extract": lambda m: m.group(1)
    },
    "risk_threshold": {
        "patterns": [
            r'(?:比例|限额|标准|阈值)[为是不得超过不低于不高于：:\s]*([\d.]+%?)',
            r'([\d.]+%?)(?:以内|以下|以上|不得超过|不得低于)',
            r'扣除限额[：:\s]*([\d.]+%?)',
            r'加计扣除比例[：:\s]*([\d.]+%?)',
        ],
        "extract": lambda m: m.group(1)
    },
    "risk_indicator": {
        "patterns": [
            r'([\u4e00-\u9fa5]{2,10}(?:率|比例|占比|占比率|差异率|偏离度|增幅|降幅))',
            r'(?:预警指标|监控指标|风险指标)[：:\s]*([\u4e00-\u9fa5]{2,15})',
            r'([\u4e00-\u9fa5]{2,10}(?:不达标|异常|超标|违规))',
        ],
        "extract": lambda m: m.group(1)
    },
    "risk_description": {
        "patterns": [
            r'([\u4e00-\u9fa5]{4,30}(?:不得扣除|应调增|应纳税调增|视同销售|应确认收入))',
            r'([\u4e00-\u9fa5]{4,30}(?:违规|不合规|未申报|虚假|偷税|漏税))',
        ],
        "extract": lambda m: m.group(1)
    }
}


def extract_from_web_results(search_results: list) -> dict:
    """Extract structured knowledge from web search results

    Returns dict with keys: policy_basis, risk_thresholds, risk_indicators,
    risk_descriptions, new_risks
    """
    extracted = {
        "policy_basis": [],      # New policy document numbers
        "risk_thresholds": [],   # New threshold values
        "risk_indicators": [],   # New indicator names
        "risk_descriptions": [], # New risk descriptions
        "new_risks": [],         # Raw new risk findings
    }

    for result in search_results:
        content = result.get("content", "") or result.get("snippet", "") or result.get("text", "")
        if not content:
            continue

        # Extract each category
        for category, config in RISK_EXTRACT_PATTERNS.items():
            for pattern in config["patterns"]:
                matches = re.finditer(pattern, content)
                for m in matches:
                    try:
                        value = config["extract"](m)
                        if value and len(value.strip()) > 1:
                            entry = {
                                "value": value.strip(),
                                "context": content[max(0,m.start()-20):m.end()+20].strip()[:100],
                                "source_url": result.get("url", ""),
                                "found_date": datetime.now().strftime("%Y-%m-%d")
                            }
                            # Dedup check
                            existing = [e["value"] for e in extracted[category]]
                            if value.strip() not in existing:
                                extracted[category].append(entry)
                    except Exception:
                        pass

        # Extract raw risk sentences
        risk_keywords = ["风险", "预警", "稽查", "处罚", "调增", "补税", "不合规", "超标"]
        sentences = re.split(r'[。！？\n]', content)
        for sent in sentences:
            for kw in risk_keywords:
                if kw in sent and len(sent.strip()) > 10:
                    extracted["new_risks"].append({
                        "keyword": kw,
                        "context": sent.strip()[:200],
                        "source": result.get("url", "web_search"),
                        "found_date": datetime.now().strftime("%Y-%m-%d")
                    })
                    break

    # Deduplicate new_risks by context similarity (first 50 chars)
    seen = set()
    unique = []
    for nr in extracted["new_risks"]:
        key = nr["context"][:50]
        if key not in seen:
            seen.add(key)
            unique.append(nr)
    extracted["new_risks"] = unique[:30]

    return extracted


# ============================================================
# 4. Auto-Update Local Knowledge Base
# ============================================================

def update_risk_models(new_data: dict) -> dict:
    """Auto-update risk_models.json with new extracted data

    Updates:
    - Add new policy_basis to matching risk items
    - Add new risk_indicators
    - Update risk_thresholds
    - Record update in version history
    """
    model_path = REFERENCES_DIR / "risk_models.json"
    if not model_path.exists():
        log("[WARNING] risk_models.json not found, cannot update")
        return {"updated": False, "reason": "file_not_found"}

    with open(model_path, 'r', encoding='utf-8') as f:
        models = json.load(f)

    update_stats = {
        "policies_added": 0,
        "indicators_added": 0,
        "thresholds_updated": 0,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    # 4.1 Add new policy_basis to matching risk items
    new_policies = new_data.get("policy_basis", [])
    for policy_entry in new_policies:
        policy_value = policy_entry.get("value", "")
        if not policy_value:
            continue

        # Find matching risk items by checking context keywords
        context = policy_entry.get("context", "")
        for domain in models.get("risk_domains", []):
            for sub in domain.get("sub_risks", []):
                # Check if policy context matches this risk item
                # Use meaningful keyword overlap (chars >= 2) not single char
                sub_name = sub.get("name", "")
                sub_desc = sub.get("description", "")
                sub_keywords = set()
                for phrase in [sub_name, sub_desc]:
                    # Extract 2+ char meaningful segments
                    for w in re.findall(r'[\u4e00-\u9fa5]{2,}', phrase):
                        sub_keywords.add(w)

                context_text = context + policy_value
                # Require at least 2 meaningful keyword matches in context
                match_count = sum(1 for kw in sub_keywords if kw in context_text)
                if match_count >= 2:
                    existing_policies = sub.get("policy_basis", [])
                    if policy_value not in existing_policies:
                        sub.setdefault("policy_basis", []).append(policy_value)
                        update_stats["policies_added"] += 1

    # 4.2 Add new risk_indicators to matching risk items
    new_indicators = new_data.get("risk_indicators", [])
    for ind_entry in new_indicators:
        ind_value = ind_entry.get("value", "")
        context = ind_entry.get("context", "")
        if not ind_value:
            continue

        for domain in models.get("risk_domains", []):
            for sub in domain.get("sub_risks", []):
                # Use meaningful keyword matching (2+ char segments)
                sub_name = sub.get("name", "")
                sub_keywords = set()
                for w in re.findall(r'[\u4e00-\u9fa5]{2,}', sub_name):
                    sub_keywords.add(w)

                context_text = context + ind_value
                match_count = sum(1 for kw in sub_keywords if kw in context_text)
                if match_count >= 2:
                    existing_indicators = [i.get("indicator", "") for i in sub.get("risk_indicators", [])]
                    if ind_value not in existing_indicators:
                        sub.setdefault("risk_indicators", []).append({
                            "indicator": ind_value,
                            "threshold": "TBD",
                            "calculation": "auto_discovered",
                            "source": "web_search",
                            "discovered_date": datetime.now().strftime("%Y-%m-%d")
                        })
                        update_stats["indicators_added"] += 1

    # 4.3 Update version and save
    old_version = models.get("version", "1.0.0")
    parts = old_version.split(".")
    if len(parts) == 3:
        parts[2] = str(int(parts[2]) + 1)
    new_version = ".".join(parts)
    models["version"] = new_version
    models["last_updated"] = datetime.now().strftime("%Y-%m-%d")
    models.setdefault("update_history", []).append({
        "version": new_version,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "stats": update_stats,
        "source": "auto_web_search"
    })

    # Keep only last 20 update history entries
    if len(models.get("update_history", [])) > 20:
        models["update_history"] = models["update_history"][-20:]

    with open(model_path, 'w', encoding='utf-8') as f:
        json.dump(models, f, ensure_ascii=False, indent=2)

    log(f"[OK] risk_models.json updated: v{old_version} -> v{new_version}")
    log(f"[OK] Stats: {update_stats}")
    return {"updated": True, "old_version": old_version, "new_version": new_version, "stats": update_stats}


def update_learn_data(extracted_data: dict, update_result: dict = None):
    """Update learn_data.json with extraction results and update stats"""
    learn_path = ASSETS_DIR / "assets" / "learn_data.json" if False else ASSETS_DIR / "learn_data.json"
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)

    learn_data = {}
    if learn_path.exists():
        with open(learn_path, 'r', encoding='utf-8') as f:
            learn_data = json.load(f)

    # Ensure all required fields exist
    for key in ["discoveries", "policy_updates", "risk_model_evolution", "knowledge_base_updates"]:
        learn_data.setdefault(key, [])

    # Add new discoveries
    for nr in extracted_data.get("new_risks", []):
        learn_data["discoveries"].append(nr)

    # Add policy updates
    for policy in extracted_data.get("policy_basis", []):
        learn_data["policy_updates"].append({
            "policy": policy.get("value", ""),
            "context": policy.get("context", "")[:100],
            "found_date": policy.get("found_date", ""),
            "source_url": policy.get("source_url", "")
        })

    # Record knowledge base update
    if update_result and update_result.get("updated"):
        learn_data["knowledge_base_updates"].append({
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "version": update_result.get("new_version", ""),
            "stats": update_result.get("stats", {})
        })

    # Increment interaction count
    learn_data["interaction_count"] = learn_data.get("interaction_count", 0) + 1
    learn_data["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Keep only last 30 entries per category
    for key in ["discoveries", "policy_updates", "knowledge_base_updates"]:
        if len(learn_data.get(key, [])) > 30:
            learn_data[key] = learn_data[key][-30:]

    with open(learn_path, 'w', encoding='utf-8') as f:
        json.dump(learn_data, f, ensure_ascii=False, indent=2)

    log(f"[OK] learn_data.json updated, interaction_count: {learn_data['interaction_count']}")


# ============================================================
# 5. Full Auto-Update Pipeline
# ============================================================

def auto_update_from_search(search_results: list, industry: str = "", region: str = "", 
                            enable_self_grow: bool = True) -> dict:
    """Full pipeline: extract from web results -> update knowledge base -> update learn data -> self grow

    This is the main entry point called by the AI agent after web search.

    Args:
        search_results: List of dicts with 'content'/'snippet'/'text' and 'url' keys
        industry: Industry for context matching
        region: Region for context matching
        enable_self_grow: Whether to enable self grow learn data to cloud

    Returns:
        Summary of what was updated
    """
    log(f"[INFO] Auto-update pipeline started, {len(search_results)} search results to process")

    # Step 1: Extract structured data
    extracted = extract_from_web_results(search_results)
    log(f"[INFO] Extracted: {len(extracted['policy_basis'])} policies, "
        f"{len(extracted['risk_indicators'])} indicators, "
        f"{len(extracted['risk_thresholds'])} thresholds, "
        f"{len(extracted['new_risks'])} raw risks")

    # Step 2: Update risk_models.json
    update_result = update_risk_models(extracted)

    # Step 3: Update learn_data.json
    update_learn_data(extracted, update_result)

    # Step 4: SelfGrow (upload + download + merge)
    self_grow_result = None
    auth_notice = None
    self_grow_achievement = None
    if enable_self_grow:
        log("[INFO] Starting self grow...")
        try:
            # Import here to avoid circular imports
            sys.path.insert(0, str(SCRIPT_DIR))
            from learn_sync import bidirectional_sync
            # 授权失败不影响主流程，silent=True后台静默同步
            self_grow_result = bidirectional_sync(silent=True)
            if self_grow_result.get("auth_error"):
                log("[NOTICE] 云同步授权问题，技能继续正常运行")
                # 提取授权提示信息
                auth_notice = self_grow_result.get("notice", "")
                if auth_notice:
                    log(f"[NOTICE] {auth_notice}")
            else:
                log("[OK] Cloud sync completed")
                # 保存成果报告
                if self_grow_result.get("merge", {}).get("achievement_report"):
                    self_grow_achievement = self_grow_result["merge"]["achievement_report"]
        except Exception as e:
            log(f"[WARNING] Self grow failed: {e}")
            self_grow_result = {"success": False, "error": str(e)}

    return {
        "status": "success",
        "extracted_counts": {
            "policies": len(extracted["policy_basis"]),
            "indicators": len(extracted["risk_indicators"]),
            "thresholds": len(extracted["risk_thresholds"]),
            "new_risks": len(extracted["new_risks"])
        },
        "update_result": update_result,
        "self_grow": self_grow_result,
        "self_grow_notice": auth_notice,  # 授权提示信息
        "self_grow_achievement": self_grow_achievement,  # 成果展示
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }


def auto_update_from_file(results_file: str, enable_self_grow: bool = True) -> dict:
    """Load web search results from JSON file and auto-update"""
    with open(results_file, 'r', encoding='utf-8') as f:
        search_results = json.load(f)

    if isinstance(search_results, dict):
        search_results = search_results.get("results", [search_results])

    return auto_update_from_search(search_results, enable_self_grow=enable_self_grow)


# ============================================================
# 6. Sync Status Check
# ============================================================

def get_sync_status() -> dict:
    """Get current knowledge base sync status"""
    status = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "risk_models": {},
        "learn_data": {},
        "case_library": {}
    }

    # Risk models info
    model_path = REFERENCES_DIR / "risk_models.json"
    if model_path.exists():
        with open(model_path, 'r', encoding='utf-8') as f:
            models = json.load(f)
        status["risk_models"] = {
            "version": models.get("version", ""),
            "last_updated": models.get("last_updated", ""),
            "domain_count": len(models.get("risk_domains", [])),
            "total_sub_risks": sum(len(d.get("sub_risks", [])) for d in models.get("risk_domains", [])),
            "update_history_count": len(models.get("update_history", [])),
            "last_update_source": models.get("update_history", [{}])[-1].get("source", "") if models.get("update_history") else ""
        }

    # Learn data info
    learn_path = ASSETS_DIR / "learn_data.json"
    if learn_path.exists():
        with open(learn_path, 'r', encoding='utf-8') as f:
            learn = json.load(f)
        status["learn_data"] = {
            "version": learn.get("version", ""),
            "last_updated": learn.get("last_updated", ""),
            "interaction_count": learn.get("interaction_count", 0),
            "discoveries_count": len(learn.get("discoveries", [])),
            "policy_updates_count": len(learn.get("policy_updates", [])),
            "training_cases_count": len(learn.get("training_cases", [])),
            "kb_updates_count": len(learn.get("knowledge_base_updates", []))
        }

    # Case library info
    case_path = REFERENCES_DIR / "case_library.json"
    if case_path.exists():
        with open(case_path, 'r', encoding='utf-8') as f:
            cases = json.load(f)
        status["case_library"] = {
            "version": cases.get("version", ""),
            "last_updated": cases.get("last_updated", ""),
            "case_count": len(cases.get("cases", []))
        }

    return status


# ============================================================
# CLI interface
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="TaxRiskGuard Knowledge Search & Auto-Update")
    parser.add_argument("--query", type=str, default="", help="Search query")
    parser.add_argument("--industry", type=str, default="", help="Industry filter")
    parser.add_argument("--region", type=str, default="", help="Region filter")
    parser.add_argument("--keywords-only", action="store_true", help="Only generate search keywords")
    parser.add_argument("--auto-update", action="store_true", help="Enable auto-update of knowledge base")
    parser.add_argument("--no-cloud-sync", action="store_true", help="Disable cloud sync (default: enabled)")
    parser.add_argument("--update-from-search", type=str, default="", help="JSON file with web search results")
    parser.add_argument("--sync-status", action="store_true", help="Show knowledge base sync status")
    parser.add_argument("--cloud-sync-now", action="store_true", help="Trigger cloud sync immediately")
    args = parser.parse_args()

    # ========== 初始化授权管理器 ==========
    auth_mgr = None
    pref_mgr = None
    try:
        sys.path.insert(0, str(SCRIPT_DIR))
        from auth_manager import AuthManager
        auth_mgr = AuthManager()
    except ImportError:
        pass
    try:
        sys.path.insert(0, str(SCRIPT_DIR))
        from user_preference import UserPreference
        pref_mgr = UserPreference()
    except ImportError:
        pass

    if args.sync_status:
        status = get_sync_status()
        print(json.dumps(status, ensure_ascii=False, indent=2))
        return

    # Trigger self grow immediately
    if args.self_grow_now:
        log("[INFO] Triggering self grow...")
        try:
            sys.path.insert(0, str(SCRIPT_DIR))
            from learn_sync import bidirectional_sync
            result = bidirectional_sync(silent=False)  # 手动触发时显示完整信息
            print(json.dumps(result, ensure_ascii=False, indent=2))
        except Exception as e:
            log(f"[ERROR] Cloud sync failed: {e}")
            print(json.dumps({"success": False, "error": str(e)}, ensure_ascii=False, indent=2))
        return

    if args.update_from_search:
        result = auto_update_from_file(args.update_from_search, enable_self_grow=not args.no_self_grow)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    if args.keywords_only:
        kws = generate_search_keywords(args.industry, args.region, args.query)
        print(json.dumps({"keywords": kws}, ensure_ascii=False, indent=2))
        return

    if args.query:
        # 记录查询统计
        if auth_mgr:
            auth_mgr.record_usage("query")
        
        results = search_local_knowledge(args.query)
        kws = generate_search_keywords(args.industry, args.region, args.query)
        output = {
            "local_results": results,
            "web_search_keywords": kws,
            "local_count": len(results),
            "auto_update_enabled": args.auto_update,
            "self_grow_enabled": not args.no_self_grow
        }
        
        # 成果展示（查询结果超过3条时展示迷你报告）
        if len(results) >= 3:
            try:
                sys.path.insert(0, str(SCRIPT_DIR))
                from achievement_display import AchievementDisplay
                display = AchievementDisplay()
                display.load_stats({
                    "total_items_learned": len(results),
                    "query_count": auth_mgr.config.get("usage_stats", {}).get("total_queries", 1) if auth_mgr else 1
                })
                mini = display.generate_mini_report(new_items=len(results))
                output["achievement"] = mini
            except ImportError:
                pass
        
        # 智能授权提示（查询第3次后）
        if auth_mgr and not auth_mgr.has_valid_key():
            should_prompt, reason = auth_mgr.should_prompt_for_auth("query")
            if should_prompt:
                output["auth_prompt"] = reason
        
        print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

    # Fixed ending - contact author info (ClawHub compliance)
    from safe_io import print_footer
    print_footer()

