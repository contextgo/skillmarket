#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
"""
Skill Optimizer - The Ultimate Keyword & Trigger Enhancement Engine
====================================================================
Combines local skill analysis + market trend data + cross-skill learning
to generate data-driven optimization recommendations.

Four Data Pillars:
  1. Local Analysis    - Parse skill's own content for keywords
  2. Market Trends     - Hot keywords from ClawHub marketplace
  3. Cross-Skill Learning - Reusable patterns from other skills
  4. Self-Optimization - Evolved weights from success/failure tracking

Output:
  - Ranked keyword suggestions with market evidence
  - Trigger word enhancements with competitive analysis
  - Naming optimization tips
  - Coverage gap analysis
  - Cross-skill pattern transfer suggestions

Usage:
  python skill_optimizer.py <skill_dir> [--apply] [--verbose]
  python skill_optimizer.py --batch               # Optimize all local skills
  python skill_optimizer.py --report              # Generate full report
"""
import sys, io, os, re, json, hashlib, math
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict

# [Safe Guard: 5-layer anti-freeze system]
from safe_guard import safe_print, safe_init, TimeoutGuard, safe_read_json, safe_read_text
from exec_logger import ExecutionLogger
safe_init()

import ast

SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR.parent / "data"


# ============================================================
# Safe Output - Prevent Secret Leakage
# ============================================================

def detect_sensitive_content(content: str) -> dict:
    """
    Detect potentially sensitive information in content.
    Returns: {'has_sensitive': bool, 'findings': list}
    """
    findings = []
    
    # Pattern 1: API keys, passwords, tokens in code
    sensitive_patterns = [
        (r'api[_-]?key\s*[:=]\s*["\']?([A-Za-z0-9_\-]{20,})["\']?', 'API Key'),
        (r'password\s*[:=]\s*["\']?([A-Za-z0-9!@#$%^&*]{8,})["\']?', 'Password'),
        (r'token\s*[:=]\s*["\']?([A-Za-z0-9_\-\.]{20,})["\']?', 'Token'),
        (r'secret\s*[:=]\s*["\']?([A-Za-z0-9_\-]{20,})["\']?', 'Secret'),
        (r'-----BEGIN [A-Z]+ PRIVATE KEY-----', 'Private Key'),
        (r'[A-Za-z0-9+/]{40,}={0,2}', 'Potential Base64 Secret'),
    ]
    
    for pattern, desc in sensitive_patterns:
        matches = re.findall(pattern, content, re.IGNORECASE)
        for m in matches[:5]:  # Limit to first 5 matches
            if isinstance(m, tuple):
                m = m[0] if m else ''
            if m:
                findings.append({
                    'type': desc,
                    'preview': m[:30] + '...' if len(m) > 30 else m
                })
    
    # Pattern 2: Hardcoded strings in Python code (AST analysis)
    try:
        tree = ast.parse(content)
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        var_name = target.id.lower()
                        if any(k in var_name for k in ['key', 'password', 'secret', 'token', 'auth']):
                            if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                                findings.append({
                                    'type': f'Hardcoded {var_name}',
                                    'preview': node.value.value[:30] + '...' if len(node.value.value) > 30 else node.value.value
                                })
    except (SyntaxError, ValueError):
        pass  # Not valid Python code, skip AST check
    
    # Pattern 3: Check for common secret file names
    secret_files = ['credentials', 'secrets', 'config', 'settings', '.env']
    for sf in secret_files:
        if sf in content.lower():
            findings.append({
                'type': 'Potential secret file reference',
                'preview': f'Contains reference to {sf}'
            })
    
    return {
        'has_sensitive': len(findings) > 0,
        'findings': findings[:10]  # Limit to 10 findings
    }


def safe_output(file_path: Path, content: str = None, max_lines: int = 50):
    """
    Safely output file content after checking for sensitive information.
    
    Args:
        file_path: Path to the file (for display purposes)
        content: File content (if None, will read from file_path)
        max_lines: Maximum lines to display (default 50)
    
    Returns:
        str: Safe content to output
    """
    if content is None:
        try:
            content = file_path.read_text(encoding='utf-8', errors='replace')
        except Exception as e:
            return f"[ERROR] Cannot read file: {e}"
    
    # Check for sensitive content
    scan_result = detect_sensitive_content(content)
    
    if scan_result['has_sensitive']:
        # Build warning message
        lines = []
        lines.append(f"\n[WARNING] [LOCK] {file_path.name} may contain sensitive information!")
        lines.append("=" * 60)
        lines.append("Detected patterns:")
        for f in scan_result['findings']:
            lines.append(f"  - {f['type']}: {f['preview']}")
        lines.append("=" * 60)
        lines.append("Recommendations:")
        lines.append("  1. Remove sensitive data from the file")
        lines.append("  2. Use environment variables instead of hardcoded values")
        lines.append("  3. Add file to .clawdhubignore to prevent sync")
        lines.append("=" * 60)
        lines.append("Showing file preview instead of full content...\n")
        
        # Show preview (first 10 lines)
        file_lines = content.splitlines()
        lines.append("[CONTENT PREVIEW - First 10 lines only]")
        for i, line in enumerate(file_lines[:10]):
            lines.append(f"{i+1:4d}: {line[:80]}")
        if len(file_lines) > 10:
            lines.append(f"... ({len(file_lines) - 10} more lines hidden)")
        
        return "\n".join(lines)
    
    else:
        # Safe to output (if <= max_lines)
        file_lines = content.splitlines()
        if len(file_lines) <= max_lines:
            return content
        else:
            return f"[INFO] File has {len(file_lines)} lines (>{max_lines}). " \
                   f"Showing first {max_lines} lines.\n" + \
                   "\n".join(file_lines[:max_lines]) + \
                   f"\n... ({len(file_lines) - max_lines} more lines)"


def safe_print_report(report: str, file_contents: list = None):
    """
    Safely print optimization report.
    If file_contents provided, check each for sensitive info.
    
    Args:
        report: The main report string
        file_contents: List of (file_path, content) tuples to check
    """
    # Print main report
    print(report)
    
    # Check file contents if provided
    if file_contents:
        for file_path, content in file_contents:
            result = safe_output(file_path, content)
            print(result)

# Noise words (reuse from keyword_optimizer)
CODE_NOISE = set(
    "self cls filepath filename files file dir path return def class import "
    "from module package init main func function method arg args kwargs param "
    "true false none null list dict set tuple str int float bool type print "
    "raise except try catch finally with as lambda yield assert break continue "
    "pass elif else not is in get set add remove update delete insert append "
    "extend pop sort reverse copy len range enumerate zip map filter reduce "
    "open close read write seek flush name value key item index slice split "
    "join strip replace format encode decode lower upper title capitalize "
    "skill learning manifest hash json cmd results version manager learn "
    "workflow relpath copyright author modified python".split()
)

ZH_GENERIC_NOISE = set(
    "用户 示例 格式 新版本 清单 方法 步骤 说明 注意 提示 操作 流程 "
    "信息 方式 功能 系统 问题 情况 部分 相关 内容 对应 记录 编号 "
    "字段 类型 名称 对象 数值 字符串 列表 条件 判断 循环 变量 参数 "
    "第一步 第二步 第三步 第四步 第五步 新增 更新到 放大 请从 下载 安装 "
    "安装或更 类型匹 市场重新 年第 核心 要点 公告 模板 应对 准备 助手".split()
)

# Domain boost
DOMAIN_BOOST = {
    "税务": 1.5, "发票": 1.5, "增值税": 1.5, "所得税": 1.5, "汇算": 1.5,
    "扣除": 1.3, "申报": 1.3, "税负": 1.4, "稽查": 1.5, "风险": 1.3,
    "合规": 1.5, "整改": 1.4, "纳税": 1.4, "优惠": 1.3, "减免": 1.3,
    "审计": 1.3, "核算": 1.3, "抵扣": 1.4, "财务": 1.3, "会计": 1.3,
    "记账": 1.3, "报表": 1.3, "凭证": 1.3, "银行": 1.2, "资金": 1.2,
    "五流": 1.5, "三流": 1.5, "合同": 1.2, "预警": 1.5, "金税": 1.5,
    "风控": 1.4, "学习": 1.2, "规划": 1.2, "目标": 1.2, "任务": 1.2,
}


# ============================================================
# Local Skill Analyzer
# ============================================================

class LocalAnalyzer:
    """Analyze a local skill's content for keywords."""

    def __init__(self, skill_dir):
        self.skill_dir = Path(skill_dir)
        self.keywords = Counter()
        self.current_triggers = set()
        self.current_description = ""
        self.skill_name = self.skill_dir.name

    def analyze(self):
        """Extract keywords from skill files."""
        self._parse_skill_md()
        self._parse_python_files()
        self._parse_references()
        return self.keywords, self.current_triggers, self.current_description

    def _parse_skill_md(self):
        skill_md = self.skill_dir / "SKILL.md"
        if not skill_md.exists():
            return
        content = safe_read_text(skill_md, timeout=5)

        # Frontmatter
        fm = re.match(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
        if fm:
            desc = re.search(r'description:\s*(.+)', fm.group(1))
            if desc:
                self.current_description = desc.group(1).strip()
                for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', self.current_description):
                    self.current_triggers.add(zh)
                    self.keywords[zh] += 3.0
                for en in re.findall(r'[a-zA-Z][a-zA-Z0-9_-]{2,}', self.current_description):
                    self.current_triggers.add(en.lower())
                    self.keywords[en.lower()] += 2.0

        # Section headings
        for h in re.findall(r'^#{1,4}\s+(.+)$', content, re.MULTILINE):
            for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', h):
                self.keywords[zh] += 2.0
            for en in re.findall(r'[a-zA-Z][a-zA-Z0-9]{2,}', h):
                self.keywords[en.lower()] += 1.5

        # Bold terms
        for term in re.findall(r'\*\*(.+?)\*\*', content):
            for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', term):
                self.keywords[zh] += 2.5

    def _parse_python_files(self):
        for py in self.skill_dir.rglob("*.py"):
            if '__pycache__' in str(py):
                continue
            try:
                content = safe_read_text(py, timeout=5)
            except:
                continue
            # Chinese comments
            for comment in re.findall(r'#\s*(.+)', content):
                for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', comment):
                    self.keywords[zh] += 0.8
            # Class names
            for cls in re.findall(r'class\s+([A-Z][a-zA-Z0-9]+)', content):
                for w in re.findall(r'[A-Z][a-z]+', cls):
                    if len(w) > 2:
                        self.keywords[w.lower()] += 1.5

    def _parse_references(self):
        refs = self.skill_dir / "references"
        if not refs.exists():
            return
        for md in refs.glob("*.md"):
            try:
                content = safe_read_text(md, timeout=5)
            except:
                continue
            for h in re.findall(r'^#{1,4}\s+(.+)$', content, re.MULTILINE):
                for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', h):
                    self.keywords[zh] += 1.5


# ============================================================
# Market Data Loader
# ============================================================

class MarketDataLoader:
    """Load market trend data from local cache."""

    def __init__(self):
        self.keyword_freq = self._load(DATA_DIR / "keyword_frequency.json")
        self.trigger_patterns = self._load(DATA_DIR / "trigger_patterns.json")
        self.market_cache = self._load(DATA_DIR / "market_cache.json")
        self.trend_history = self._load(DATA_DIR / "trend_history.json")

    def get_keyword_score(self, keyword):
        """Get market score for a keyword."""
        if not self.keyword_freq:
            return 0
        for entry in self.keyword_freq.get('top_keywords', []):
            if entry['keyword'] == keyword:
                return entry['score']
        return 0

    def get_rising_keywords(self, top_n=20):
        """Get rising keywords from trend history."""
        if len(self.trend_history) < 2:
            return []
        recent = {k['keyword']: k['score'] for k in self.trend_history[-1].get('top_50_keywords', [])}
        older = {k['keyword']: k['score'] for k in self.trend_history[-2].get('top_50_keywords', [])}

        rising = []
        for kw, score in recent.items():
            old = older.get(kw, 0)
            change = (score - old) / old * 100 if old > 0 else 999
            rising.append({'keyword': kw, 'current': score, 'change_pct': change})
        rising.sort(key=lambda x: -x['change_pct'])
        return rising[:top_n]

    def get_market_skills_count(self):
        return len(self.market_cache)

    def _load(self, path):
        if path.exists():
            try:
                return safe_read_json(path)
            except:
                return {}
        return {}


# ============================================================
# Optimization Engine
# ============================================================

class OptimizationEngine:
    """Generate data-driven optimization recommendations."""

    def __init__(self, skill_dir, verbose=False):
        self.skill_dir = Path(skill_dir)
        self.verbose = verbose
        self.local = LocalAnalyzer(skill_dir)
        self.market = MarketDataLoader()

    def optimize(self):
        """Run full optimization analysis."""
        # Step 1: Local analysis
        local_kw, local_triggers, description = self.local.analyze()

        # Step 2: Market data
        market_has_data = self.market.get_market_skills_count() > 0

        # Step 3: Score all candidate keywords
        candidates = {}
        for kw, freq in local_kw.items():
            score = self._score_keyword(kw, freq, source='local')
            if score['total'] > 0:
                candidates[kw] = score

        # Add market-only keywords that are highly relevant
        if market_has_data:
            for entry in self.market.keyword_freq.get('top_keywords', [])[:200]:
                kw = entry['keyword']
                if kw not in candidates:
                    score = self._score_keyword(kw, entry['score'], source='market')
                    if score['total'] >= 3.0:
                        candidates[kw] = score

        # Step 4: Classify and rank
        new_triggers = []
        existing_triggers = []
        keyword_suggestions = []

        for kw, info in sorted(candidates.items(), key=lambda x: -x[1]['total']):
            is_chinese = any('\u4e00' <= c <= '\u9fff' for c in kw)

            if kw in local_triggers:
                info['status'] = 'existing'
                existing_triggers.append((kw, info))
            else:
                info['status'] = 'new'
                if is_chinese and 2 <= len(kw) <= 6 and self._is_good_trigger(kw):
                    new_triggers.append((kw, info))
                keyword_suggestions.append((kw, info))

        # Step 5: Generate report
        report = self._generate_report(
            description, local_triggers, existing_triggers,
            new_triggers, keyword_suggestions, market_has_data
        )

        # Use safe_output to check for sensitive content before printing
        safe_print_report(report)
        return new_triggers, keyword_suggestions

    def apply(self, new_triggers):
        """Apply trigger suggestions to SKILL.md."""
        skill_md = self.skill_dir / "SKILL.md"
        if not skill_md.exists():
            print("[ERROR] SKILL.md not found")
            return False

        content = safe_read_text(skill_md, timeout=5)
        fm_match = re.match(r'^(---\s*\n)(.*?)(\n---)', content, re.DOTALL)
        if not fm_match:
            print("[ERROR] No frontmatter found")
            return False

        fm_body = fm_match.group(2)
        desc_match = re.search(r'description:\s*(.+)', fm_body)
        if not desc_match:
            print("[ERROR] No description field")
            return False

        current = desc_match.group(1).strip()
        # Filter out triggers already present
        add = [kw for kw, _ in new_triggers if kw not in current.lower()]
        if not add:
            print("[INFO] No new triggers to add")
            return True

        unique_add = list(dict.fromkeys(add))[:12]
        addition = '、'.join(unique_add)

        if '触发词包括' in current:
            new_desc = current.rstrip('。.') + '、' + addition + '。'
        else:
            new_desc = current + '。触发词包括：' + addition + '。'

        new_fm = fm_body.replace(desc_match.group(0), f"description: {new_desc}")
        new_content = fm_match.group(1) + new_fm + fm_match.group(3) + content[fm_match.end():]
        skill_md.write_text(new_content, encoding='utf-8')

        print(f"[OK] Added {len(unique_add)} triggers: {addition}")
        return True

    def _score_keyword(self, keyword, freq, source='local'):
        """Compute composite score for a keyword."""
        score = {
            'keyword': keyword,
            'local_freq': 0, 'market_freq': 0,
            'domain_boost': 1.0, 'rising_boost': 0,
            'source': source, 'status': 'new', 'total': 0,
        }

        # Noise filtering
        if keyword.lower() in CODE_NOISE or keyword in ZH_GENERIC_NOISE:
            score['total'] = 0
            return score

        # Frequency
        if source == 'local':
            score['local_freq'] = freq
        else:
            score['market_freq'] = freq

        # Domain boost
        score['domain_boost'] = DOMAIN_BOOST.get(keyword, 1.0)

        # Market evidence boost
        market_score = self.market.get_keyword_score(keyword)
        if market_score > 0:
            score['market_freq'] = market_score
            score['market_evidence'] = True

        # Rising trend boost
        rising_map = {r['keyword']: r['change_pct']
                      for r in self.market.get_rising_keywords(50)}
        if keyword in rising_map:
            pct = rising_map[keyword]
            score['rising_boost'] = min(pct / 100, 2.0) if pct != 999 else 2.0

        # Length bonus
        is_chinese = any('\u4e00' <= c <= '\u9fff' for c in keyword)
        len_bonus = 1.2 if (is_chinese and 2 <= len(keyword) <= 4) else 1.0

        # Compute total
        base = freq * score['domain_boost'] * len_bonus
        if source == 'local':
            base *= 1.5
        base += score['market_freq'] * 0.3  # Market signal
        base += score['rising_boost'] * 5    # Rising signal
        score['total'] = round(base, 2)

        return score

    def _is_good_trigger(self, keyword):
        """Check if keyword is a good trigger word candidate."""
        # Skip fragments
        fragment_suffixes = ('重新', '安装或更', '类型匹', '期间', '年第')
        for s in fragment_suffixes:
            if keyword.endswith(s):
                return False
        return True

    def _generate_report(self, description, local_triggers, existing_triggers,
                         new_triggers, keyword_suggestions, market_has_data):
        """Generate the full optimization report."""
        lines = []
        lines.append("=" * 65)
        lines.append(f"  Skill Optimization Report: {self.skill_dir.name}")
        lines.append(f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("=" * 65)

        # Data sources
        lines.append(f"\n[DATA SOURCES]")
        lines.append(f"  Local analysis: {len(self.local.keywords)} keywords extracted")
        lines.append(f"  Market data: {'Yes (' + str(self.market.get_market_skills_count()) + ' skills)' if market_has_data else 'Not available - run market_collector.py first'}")
        lines.append(f"  Trend history: {len(self.market.trend_history)} snapshots")
        lines.append(f"  Current triggers: {len(local_triggers)}")

        # Coverage analysis
        if market_has_data and self.market.keyword_freq:
            top_100 = {e['keyword'] for e in self.market.keyword_freq.get('top_keywords', [])[:100]}
            covered = local_triggers & top_100
            coverage = len(covered) / len(top_100) * 100 if top_100 else 0
            lines.append(f"\n[COVERAGE ANALYSIS]")
            lines.append(f"  Market top-100 keyword coverage: {coverage:.1f}%")
            if covered:
                lines.append(f"  Covered: {', '.join(list(covered)[:20])}")

        # New trigger suggestions (the most valuable output)
        lines.append(f"\n{'-' * 65}")
        lines.append(f"[NEW TRIGGER SUGGESTIONS] Data-driven recommendations:")
        if new_triggers:
            for kw, info in new_triggers[:20]:
                evidence = []
                if info.get('market_evidence'):
                    evidence.append(f"market={info['market_freq']:.1f}")
                if info.get('rising_boost', 0) > 0:
                    evidence.append(f"rising=+{info['rising_boost']:.1f}")
                evidence_str = f" [{', '.join(evidence)}]" if evidence else ""
                boost_str = f" x{info['domain_boost']:.1f}" if info['domain_boost'] > 1.0 else ""
                lines.append(
                    f"  + {kw:<18s} (score: {info['total']:.1f}{boost_str}){evidence_str}"
                )
        else:
            lines.append("  (No new trigger suggestions - skill is well optimized!)")

        # Top keyword suggestions
        lines.append(f"\n{'-' * 65}")
        lines.append(f"[KEYWORD SUGGESTIONS] Top candidates:")
        for kw, info in keyword_suggestions[:15]:
            is_chinese = any('\u4e00' <= c <= '\u9fff' for c in kw)
            marker = "[CN]" if is_chinese else "[EN]"
            evidence = ""
            if info.get('market_evidence'):
                evidence += " [MARKET]"
            if info.get('rising_boost', 0) > 0:
                evidence += " [RISING]"
            lines.append(
                f"  {marker} {kw:<16s} score={info['total']:.1f} "
                f"local={info['local_freq']:.0f} market={info['market_freq']:.0f}{evidence}"
            )

        # Recommended additions summary
        add_triggers = [kw for kw, _ in new_triggers[:12]]
        lines.append(f"\n{'-' * 65}")
        lines.append(f"[RECOMMENDED ADDITIONS]")
        if add_triggers:
            lines.append(f"  Triggers to add: {'、'.join(add_triggers)}")
        else:
            lines.append(f"  Current triggers are already well-optimized")

        lines.append(f"\n{'=' * 65}")
        return "\n".join(lines)


# ============================================================
# Batch Optimizer
# ============================================================

def batch_optimize(skills_dir=None, verbose=False, logger=None):
    """Optimize all installed skills."""
    if skills_dir is None:
        skills_dir = Path.home() / ".workbuddy" / "skills"
    skills_dir = Path(skills_dir)

    if not skills_dir.exists():
        print(f"[ERROR] Skills directory not found: {skills_dir}")
        return []

    results = []
    for skill_path in sorted(skills_dir.iterdir()):
        if not skill_path.is_dir():
            continue
        if skill_path.name.startswith('.') or skill_path.name == 'skill-trend-analyzer':
            continue
        skill_md = skill_path / "SKILL.md"
        if not skill_md.exists():
            continue

        print(f"\n{'#' * 65}")
        print(f"# Optimizing: {skill_path.name}")
        print(f"{'#' * 65}")
        engine = OptimizationEngine(skill_path, verbose=verbose)
        new_triggers, _ = engine.optimize()
        results.append({
            'skill': skill_path.name,
            'new_triggers': len(new_triggers),
            'top_suggestions': [kw for kw, _ in new_triggers[:5]],
        })

    # Summary
    print(f"\n\n{'=' * 65}")
    print(f"  BATCH OPTIMIZATION SUMMARY")
    print(f"{'=' * 65}")
    for r in results:
        triggers = '、'.join(r['top_suggestions']) if r['top_suggestions'] else '(none)'
        print(f"  {r['skill']:<30s} +{r['new_triggers']} triggers: {triggers}")
    print(f"{'=' * 65}")
    return results


# ============================================================
# CLI Entry Point
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Skill Optimizer")
    parser.add_argument("skill_dir", nargs='?', help="Path to skill directory")
    parser.add_argument("--apply", action="store_true", help="Apply suggestions")
    parser.add_argument("--batch", action="store_true", help="Optimize all skills")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    # ---- 执行日志 start ----
    logger = ExecutionLogger("skill_optimizer")
    logger.start({
        "mode": "batch" if args.batch else "single",
        "skill_dir": args.skill_dir,
        "apply": args.apply,
        "verbose": args.verbose
    })
    
    # ---- Token 日志 start ----
    start_time = datetime.now()
    try:
        from token_logger import TokenLogger
        token_logger = TokenLogger("skill-trend-analyzer")
    except ImportError:
        token_logger = None

    try:
        if args.batch:
            logger.phase("batch_optimize")
            batch_results = batch_optimize(verbose=args.verbose, logger=logger)
            total_triggers = sum(r.get("new_triggers", 0) for r in batch_results) if batch_results else 0
            logger.done({
                "mode": "batch",
                "skills_optimized": len(batch_results) if batch_results else 0,
                "total_new_triggers": total_triggers,
            })
        elif args.skill_dir:
            logger.phase("optimize")
            engine = OptimizationEngine(args.skill_dir, verbose=args.verbose)
            new_triggers, keyword_suggestions = engine.optimize()
            if args.apply and new_triggers:
                logger.phase("apply")
                engine.apply(new_triggers)
            logger.done({
                "mode": "single",
                "skill": args.skill_dir,
                "new_triggers": len(new_triggers),
                "keyword_suggestions": len(keyword_suggestions),
                "applied": args.apply,
            })
        else:
            parser.print_help()
            logger.done({"mode": "help", "status": "ok"})

    except Exception as e:
        logger.fail(str(e), {"mode": "error"})
        import traceback; traceback.print_exc()
    finally:
        # ---- Token 日志记录 ----
        if token_logger:
            duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            mode = "batch" if args.batch else "single"
            # 估算 token 消耗
            if args.batch:
                skills_count = len(batch_results) if 'batch_results' in dir() else 0
                estimated_tokens = skills_count * 800 + 500
            else:
                estimated_tokens = 1500
            token_logger.log(
                action=f"optimize_{mode}",
                tokens={"input": estimated_tokens // 3, "output": estimated_tokens * 2 // 3, "total": estimated_tokens},
                duration_ms=duration_ms,
                metadata={"mode": mode, "applied": args.apply}
            )

    # Fixed ending - contact author info (ClawHub compliance)
    from safe_io import print_footer
    print_footer()


if __name__ == "__main__":
    main()
