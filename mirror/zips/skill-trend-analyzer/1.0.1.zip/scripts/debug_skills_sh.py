# Test: 分析 skills.sh HTML 结构
import sys
sys.path.insert(0, r'C:\Users\Administrator\.workbuddy\skills\skill-trend-analyzer\scripts')
import requests
from bs4 import BeautifulSoup
import re

r = requests.get('https://skills.sh', verify=False, timeout=15,
    headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
print(f"Status: {r.status_code}, Length: {len(r.text)}")

# 找 __NEXT_DATA__
next_data = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', r.text, re.DOTALL)
if next_data:
    print("Found __NEXT_DATA__")
    import json
    try:
        data = json.loads(next_data.group(1))
        # 打印结构前两层
        def show(obj, depth=0):
            if depth > 4:
                return
            if isinstance(obj, dict):
                for k, v in list(obj.items())[:5]:
                    print("  " * depth + f"{k}: {type(v).__name__}")
                    show(v, depth+1)
            elif isinstance(obj, list):
                print("  " * depth + f"[list len={len(obj)}]")
                if obj:
                    show(obj[0], depth+1)
        show(data)
        # 尝试找 props.pageProps
        try:
            props = data.get('props', {}).get('pageProps', {})
            print("\n=== pageProps keys ===")
            for k, v in props.items():
                print(f"  {k}: {type(v).__name__}")
                if isinstance(v, list):
                    print(f"    First item: {str(v[0])[:200]}")
                elif isinstance(v, dict):
                    print(f"    Sample: {str(list(v.items())[:3])}")
        except:
            pass
    except Exception as e:
        print(f"Parse error: {e}")
else:
    print("No __NEXT_DATA__")
    # 找包含 skill 数据的 script
    scripts = re.findall(r'<script[^>]*>(.*?)</script>', r.text, re.DOTALL)
    for s in scripts:
        if len(s) > 1000:
            print(f"\nScript len={len(s)}")
            print(s[:3000])
