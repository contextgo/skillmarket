#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - 本地应用引擎 (Local Application Engine)
将从云端获取的学习数据按类型解析并应用到对应模块

应用模块：
1. discoveries -> 追加到本地discoveries列表
2. policy_updates -> 追加到本地policy_updates列表
3. training_cases -> 追加到本地training_cases列表
4. user_profiles -> 合并到本地user_profiles
5. model_parameters -> 更新到risk_models.json
6. trigger_words -> 更新到SKILL.md的触发词
7. workflow_tuning -> 更新到workflow配置
8. industry_features -> 更新到industry_db
9. feedback_patterns -> 更新到response_templates
10. failure_cases -> 追加到failure_case_db
11. time_sensitive -> 添加到reminder系统

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import io
import json
import re
import hashlib
from datetime import datetime
from typing import Dict, List, Any, Optional, Callable
from pathlib import Path
from dataclasses import dataclass, field

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
REFERENCES_DIR = SKILL_DIR / "references"
ASSETS_DIR = SKILL_DIR / "assets"


@dataclass
class ApplicationResult:
    """应用结果"""
    data_type: str
    success: bool
    items_applied: int = 0
    items_skipped: int = 0
    error: str = ""
    details: List[str] = field(default_factory=list)


class LocalApplier:
    """本地应用引擎"""
    
    def __init__(self):
        self.appliers = {
            "discoveries": self._apply_discoveries,
            "policy_updates": self._apply_policy_updates,
            "training_cases": self._apply_training_cases,
            "user_profiles": self._apply_user_profiles,
            "model_parameters": self._apply_model_parameters,
            "trigger_words": self._apply_trigger_words,
            "workflow_tuning": self._apply_workflow_tuning,
            "industry_features": self._apply_industry_features,
            "feedback_patterns": self._apply_feedback_patterns,
            "failure_cases": self._apply_failure_cases,
            "time_sensitive": self._apply_time_sensitive,
        }
        self.results: List[ApplicationResult] = []
    
    def apply_package(self, package: Dict[str, Any], 
                     dry_run: bool = False) -> List[ApplicationResult]:
        """
        应用学习包到本地系统
        
        Args:
            package: 云端获取的学习包
            dry_run: 如果True，只模拟应用不实际修改文件
        
        Returns:
            应用结果列表
        """
        self.results = []
        collections = package.get("collections", {})
        
        for data_type, coll in collections.items():
            items = coll.get("items", [])
            if not items:
                continue
            
            applier = self.appliers.get(data_type)
            if applier:
                result = applier(items, dry_run)
                self.results.append(result)
            else:
                self.results.append(ApplicationResult(
                    data_type=data_type,
                    success=False,
                    error=f"未知数据类型: {data_type}"
                ))
        
        return self.results
    
    # ============================================================
    # 应用策略1: 简单追加（去重）
    # ============================================================
    
    def _apply_discoveries(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用发现项 - 追加到learn_data.json"""
        return self._append_with_dedup(
            items, 
            "discoveries",
            key_func=lambda x: x.get("keyword", "").lower(),
            dry_run=dry_run
        )
    
    def _apply_policy_updates(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用政策更新 - 追加到learn_data.json"""
        return self._append_with_dedup(
            items,
            "policy_updates",
            key_func=lambda x: (x.get("title", ""), x.get("date", "")),
            dry_run=dry_run
        )
    
    def _apply_training_cases(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用训练案例 - 追加到learn_data.json"""
        return self._append_with_dedup(
            items,
            "training_cases",
            key_func=lambda x: x.get("case_id", ""),
            dry_run=dry_run
        )
    
    def _apply_failure_cases(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用失败案例 - 追加到failure_case_db"""
        return self._append_with_dedup(
            items,
            "failure_cases",
            key_func=lambda x: x.get("id", ""),
            dry_run=dry_run
        )
    
    def _append_with_dedup(self, items: List[Dict], 
                          data_type: str,
                          key_func: Callable,
                          dry_run: bool) -> ApplicationResult:
        """通用追加去重应用器"""
        result = ApplicationResult(data_type=data_type, success=True)
        
        # 读取现有数据
        learn_data = self._load_learn_data()
        existing = learn_data.get(data_type, [])
        existing_keys = {key_func(item) for item in existing}
        
        added = 0
        skipped = 0
        
        for item in items:
            key = key_func(item)
            if key in existing_keys:
                skipped += 1
                continue
            
            if not dry_run:
                existing.append(item)
            added += 1
            existing_keys.add(key)
        
        if not dry_run and added > 0:
            learn_data[data_type] = existing
            self._save_learn_data(learn_data)
        
        result.items_applied = added
        result.items_skipped = skipped
        result.details.append(f"新增: {added}, 跳过: {skipped}")
        
        return result
    
    # ============================================================
    # 应用策略2: 字典合并（按key）
    # ============================================================
    
    def _apply_user_profiles(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用用户画像 - 合并到user_profiles"""
        result = ApplicationResult(data_type="user_profiles", success=True)
        
        learn_data = self._load_learn_data()
        profiles = learn_data.get("user_profiles", {})
        
        added = 0
        merged = 0
        
        for item in items:
            uscc = item.get("uscc_masked", "")
            if not uscc:
                continue
            
            if uscc not in profiles:
                if not dry_run:
                    profiles[uscc] = item
                added += 1
            else:
                # 合并：累加scan_count，更新avg_score
                if not dry_run:
                    existing = profiles[uscc]
                    existing["scan_count"] = existing.get("scan_count", 0) + item.get("scan_count", 0)
                    existing["avg_score"] = (existing.get("avg_score", 0) + item.get("avg_score", 0)) / 2
                    profiles[uscc] = existing
                merged += 1
        
        if not dry_run:
            learn_data["user_profiles"] = profiles
            self._save_learn_data(learn_data)
        
        result.items_applied = added + merged
        result.details.append(f"新增画像: {added}, 合并画像: {merged}")
        
        return result
    
    # ============================================================
    # 应用策略3: 文件更新（risk_models.json）
    # ============================================================
    
    def _apply_model_parameters(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用模型参数 - 更新到risk_models.json"""
        result = ApplicationResult(data_type="model_parameters", success=True)
        
        risk_models_path = REFERENCES_DIR / "risk_models.json"
        if not risk_models_path.exists():
            result.success = False
            result.error = "risk_models.json不存在"
            return result
        
        try:
            with open(risk_models_path, 'r', encoding='utf-8') as f:
                risk_models = json.load(f)
        except Exception as e:
            result.success = False
            result.error = f"读取risk_models.json失败: {e}"
            return result
        
        updated = 0
        
        for item in items:
            domain = item.get("risk_domain", "")
            param_name = item.get("param_name", "")
            param_value = item.get("param_value")
            param_type = item.get("param_type", "threshold")
            
            if not domain or not param_name:
                continue
            
            # 查找对应的风险域
            for risk in risk_models.get("risks", []):
                if risk.get("domain") == domain:
                    if param_type == "threshold":
                        if "thresholds" not in risk:
                            risk["thresholds"] = {}
                        if not dry_run:
                            risk["thresholds"][param_name] = {
                                "value": param_value,
                                "source": "learned",
                                "updated_at": datetime.now().isoformat(),
                                "confidence": item.get("confidence", 0.5)
                            }
                    elif param_type == "weight":
                        if "weights" not in risk:
                            risk["weights"] = {}
                        if not dry_run:
                            risk["weights"][param_name] = param_value
                    
                    updated += 1
                    result.details.append(f"更新 {domain}.{param_name} = {param_value}")
                    break
        
        if not dry_run and updated > 0:
            try:
                with open(risk_models_path, 'w', encoding='utf-8') as f:
                    json.dump(risk_models, f, ensure_ascii=False, indent=2)
            except Exception as e:
                result.success = False
                result.error = f"保存risk_models.json失败: {e}"
                return result
        
        result.items_applied = updated
        return result
    
    # ============================================================
    # 应用策略4: SKILL.md更新（触发词）
    # ============================================================
    
    def _apply_trigger_words(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用触发词 - 更新到SKILL.md"""
        result = ApplicationResult(data_type="trigger_words", success=True)
        
        skill_md_path = SKILL_DIR / "SKILL.md"
        if not skill_md_path.exists():
            result.success = False
            result.error = "SKILL.md不存在"
            return result
        
        try:
            with open(skill_md_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            result.success = False
            result.error = f"读取SKILL.md失败: {e}"
            return result
        
        added_words = []
        
        for item in items:
            word = item.get("word", "")
            if not word or item.get("deprecated", False):
                continue
            
            # 检查是否已存在
            if word in content:
                continue
            
            added_words.append(word)
            
            if not dry_run:
                # 在触发词区域追加
                # 假设触发词区域格式：## 触发词 / 触发词：... 或 triggerKeywords
                trigger_pattern = r'(triggerKeywords:\s*\[)([^\]]*)'
                if re.search(trigger_pattern, content):
                    # 在数组中追加
                    content = re.sub(
                        trigger_pattern,
                        lambda m: f'{m.group(1)}{m.group(2).rstrip(", ")}, "{word}"',
                        content
                    )
                else:
                    # 在描述中追加
                    desc_pattern = r'(description:\s*"[^"]*)(")'
                    content = re.sub(
                        desc_pattern,
                        lambda m: f'{m.group(1)}，新增触发词：{word}"',
                        content
                    )
        
        if not dry_run and added_words:
            try:
                with open(skill_md_path, 'w', encoding='utf-8') as f:
                    f.write(content)
            except Exception as e:
                result.success = False
                result.error = f"保存SKILL.md失败: {e}"
                return result
        
        result.items_applied = len(added_words)
        result.details.append(f"新增触发词: {', '.join(added_words[:5])}")
        if len(added_words) > 5:
            result.details.append(f"... 还有 {len(added_words) - 5} 个")
        
        return result
    
    # ============================================================
    # 应用策略5: 配置文件更新（workflow）
    # ============================================================
    
    def _apply_workflow_tuning(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用工作流调优 - 更新到workflow配置"""
        result = ApplicationResult(data_type="workflow_tuning", success=True)
        
        config_path = ASSETS_DIR / "workflow_config.json"
        config = {}
        
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
            except:
                config = {}
        
        updated = 0
        
        for item in items:
            step_id = item.get("step_id", "")
            parameter = item.get("parameter", "")
            new_value = item.get("new_value")
            
            if not step_id or not parameter:
                continue
            
            if step_id not in config:
                config[step_id] = {}
            
            if not dry_run:
                config[step_id][parameter] = {
                    "value": new_value,
                    "old_value": item.get("old_value"),
                    "reason": item.get("tuning_reason", ""),
                    "updated_at": datetime.now().isoformat()
                }
            
            updated += 1
            result.details.append(f"{step_id}.{parameter} = {new_value}")
        
        if not dry_run and updated > 0:
            try:
                ASSETS_DIR.mkdir(parents=True, exist_ok=True)
                with open(config_path, 'w', encoding='utf-8') as f:
                    json.dump(config, f, ensure_ascii=False, indent=2)
            except Exception as e:
                result.success = False
                result.error = f"保存workflow_config失败: {e}"
                return result
        
        result.items_applied = updated
        return result
    
    # ============================================================
    # 应用策略6: industry_db更新
    # ============================================================
    
    def _apply_industry_features(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用行业特征 - 更新到industry_db"""
        result = ApplicationResult(data_type="industry_features", success=True)
        
        db_path = REFERENCES_DIR / "industry_features.json"
        db = {"industries": {}, "regions": {}}
        
        if db_path.exists():
            try:
                with open(db_path, 'r', encoding='utf-8') as f:
                    db = json.load(f)
            except:
                db = {"industries": {}, "regions": {}}
        
        added = 0
        
        for item in items:
            feature_type = item.get("feature_type", "industry")
            feature_key = item.get("feature_key", "")
            industry = item.get("industry", "")
            region = item.get("region", "")
            
            if feature_type == "industry" and industry:
                if industry not in db["industries"]:
                    db["industries"][industry] = {
                        "risk_patterns": [],
                        "policy_exceptions": [],
                        "seasonal_factors": {}
                    }
                if not dry_run:
                    db["industries"][industry]["risk_patterns"].extend(
                        item.get("risk_patterns", [])
                    )
                    db["industries"][industry]["policy_exceptions"].extend(
                        item.get("policy_exceptions", [])
                    )
                    db["industries"][industry]["seasonal_factors"].update(
                        item.get("seasonal_factors", {})
                    )
                added += 1
            
            elif feature_type == "region" and region:
                if region not in db["regions"]:
                    db["regions"][region] = {
                        "risk_patterns": [],
                        "policy_exceptions": []
                    }
                if not dry_run:
                    db["regions"][region]["risk_patterns"].extend(
                        item.get("risk_patterns", [])
                    )
                added += 1
        
        if not dry_run and added > 0:
            try:
                REFERENCES_DIR.mkdir(parents=True, exist_ok=True)
                with open(db_path, 'w', encoding='utf-8') as f:
                    json.dump(db, f, ensure_ascii=False, indent=2)
            except Exception as e:
                result.success = False
                result.error = f"保存industry_features失败: {e}"
                return result
        
        result.items_applied = added
        return result
    
    # ============================================================
    # 应用策略7: response_templates更新
    # ============================================================
    
    def _apply_feedback_patterns(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用反馈模式 - 更新到response_templates"""
        result = ApplicationResult(data_type="feedback_patterns", success=True)
        
        templates_path = REFERENCES_DIR / "response_templates.json"
        templates = {}
        
        if templates_path.exists():
            try:
                with open(templates_path, 'r', encoding='utf-8') as f:
                    templates = json.load(f)
            except:
                templates = {}
        
        added = 0
        
        for item in items:
            pattern_hash = item.get("pattern_hash", "")
            if not pattern_hash:
                continue
            
            if pattern_hash not in templates or item.get("satisfaction_score", 0) > \
               templates.get(pattern_hash, {}).get("satisfaction_score", 0):
                if not dry_run:
                    templates[pattern_hash] = {
                        "query_pattern": item.get("query_pattern", ""),
                        "response_template": item.get("response_template", ""),
                        "satisfaction_score": item.get("satisfaction_score", 0),
                        "helpful_count": item.get("helpful_count", 0),
                        "updated_at": datetime.now().isoformat()
                    }
                added += 1
        
        if not dry_run and added > 0:
            try:
                REFERENCES_DIR.mkdir(parents=True, exist_ok=True)
                with open(templates_path, 'w', encoding='utf-8') as f:
                    json.dump(templates, f, ensure_ascii=False, indent=2)
            except Exception as e:
                result.success = False
                result.error = f"保存response_templates失败: {e}"
                return result
        
        result.items_applied = added
        return result
    
    # ============================================================
    # 应用策略8: reminder系统（时效性知识）
    # ============================================================
    
    def _apply_time_sensitive(self, items: List[Dict], dry_run: bool) -> ApplicationResult:
        """应用时效性知识 - 添加到reminder系统"""
        result = ApplicationResult(data_type="time_sensitive", success=True)
        
        reminders_path = ASSETS_DIR / "reminders.json"
        reminders = []
        
        if reminders_path.exists():
            try:
                with open(reminders_path, 'r', encoding='utf-8') as f:
                    reminders = json.load(f)
            except:
                reminders = []
        
        added = 0
        
        for item in items:
            title = item.get("title", "")
            end_date = item.get("end_date", "")
            
            if not title or not end_date:
                continue
            
            # 检查是否已存在
            if any(r.get("title") == title for r in reminders):
                continue
            
            if not dry_run:
                reminders.append({
                    "title": title,
                    "description": item.get("description", ""),
                    "end_date": end_date,
                    "urgency_level": item.get("urgency_level", "normal"),
                    "reminder_days": item.get("reminder_days", [7, 3, 1]),
                    "added_at": datetime.now().isoformat(),
                    "reminded": []
                })
            
            added += 1
            result.details.append(f"添加提醒: {title} (截止: {end_date})")
        
        if not dry_run and added > 0:
            try:
                ASSETS_DIR.mkdir(parents=True, exist_ok=True)
                with open(reminders_path, 'w', encoding='utf-8') as f:
                    json.dump(reminders, f, ensure_ascii=False, indent=2)
            except Exception as e:
                result.success = False
                result.error = f"保存reminders失败: {e}"
                return result
        
        result.items_applied = added
        return result
    
    # ============================================================
    # 辅助方法
    # ============================================================
    
    def _load_learn_data(self) -> Dict[str, Any]:
        """加载learn_data.json"""
        learn_path = ASSETS_DIR / "learn_data.json"
        if not learn_path.exists():
            return self._create_default_learn_data()
        
        try:
            with open(learn_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return self._create_default_learn_data()
    
    def _save_learn_data(self, data: Dict[str, Any]):
        """保存learn_data.json"""
        learn_path = ASSETS_DIR / "learn_data.json"
        ASSETS_DIR.mkdir(parents=True, exist_ok=True)
        
        data["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        with open(learn_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def _create_default_learn_data(self) -> Dict[str, Any]:
        """创建默认learn_data结构"""
        return {
            "version": "2.0.0",
            "schema_version": "2.0.0",
            "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "discoveries": [],
            "policy_updates": [],
            "training_cases": [],
            "user_profiles": {},
            "failure_cases": [],
            "self_grow": {
                "last_upload_hash": None,
                "last_download_time": None,
                "merge_count": 0
            }
        }
    
    def get_application_report(self) -> str:
        """生成应用报告"""
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("[PARCEL] 学习数据应用报告")
        lines.append("=" * 60)
        
        total_applied = sum(r.items_applied for r in self.results)
        total_skipped = sum(r.items_skipped for r in self.results)
        success_count = sum(1 for r in self.results if r.success)
        fail_count = len(self.results) - success_count
        
        lines.append(f"\n  [OK] 成功应用: {success_count} 类型")
        lines.append(f"  [FAIL] 失败: {fail_count} 类型")
        lines.append(f"  [STAT] 总计应用: {total_applied} 项")
        lines.append(f"  ⏭  跳过: {total_skipped} 项")
        
        lines.append("\n  详细结果:")
        for r in self.results:
            status = "[OK]" if r.success else "[FAIL]"
            lines.append(f"    {status} {r.data_type}: {r.items_applied} 项")
            if r.details:
                for detail in r.details[:3]:  # 最多显示3条详情
                    lines.append(f"       └─ {detail}")
        
        lines.append("\n" + "=" * 60)
        return "\n".join(lines)


# ============================================================
# CLI接口
# ============================================================

def main():
    """测试入口"""
    print("[TEST] Testing learn_applier.py...")
    
    # 创建测试数据
    test_package = {
        "schema_version": "2.0.0",
        "collections": {
            "discoveries": {
                "data_type": "discoveries",
                "items": [
                    {"id": "d1", "keyword": "研发费用加计扣除", "context": "新政策", "confidence": 0.8}
                ]
            },
            "model_parameters": {
                "data_type": "model_parameters",
                "items": [
                    {"id": "m1", "risk_domain": "rd_expense", "param_name": "threshold_high", 
                     "param_value": 0.85, "param_type": "threshold", "confidence": 0.75}
                ]
            },
            "time_sensitive": {
                "data_type": "time_sensitive",
                "items": [
                    {"id": "t1", "title": "汇算清缴截止", "end_date": "2026-05-31", 
                     "urgency_level": "high", "reminder_days": [7, 3, 1]}
                ]
            }
        }
    }
    
    applier = LocalApplier()
    results = applier.apply_package(test_package, dry_run=True)
    
    print(f"[TEST] Applied {len(results)} data types")
    for r in results:
        print(f"  - {r.data_type}: {r.items_applied} items, success={r.success}")
    
    print("\n" + applier.get_application_report())
    
    print("[TEST] All tests passed!")


if __name__ == "__main__":
    main()

    # Fixed ending - contact author info (ClawHub compliance)
    from safe_io import print_footer
    print_footer()

