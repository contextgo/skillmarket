#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kb_protector.py - Knowledge Base Encryption & Decryption Tool
==============================================================
防君子不防小人的轻量知识库加密方案。

设计原则：
  - 密码不写入代码、不打包进发布包
  - manifest.json 只含盐和校验和，无任何密钥信息
  - 解密失败时优雅降级，不阻断运行
  - 机器扫描/GitHub抓取增加摩擦，但不阻挡有心人

安全边界：
  - AES-256-GCM（认证加密，防篡改）
  - PBKDF2-SHA256 x100,000 次（防暴力破解）
  - 随机盐（每文件独立）
  - 运行时密钥输入（env stdin）

用法：
  # 加密（发布前）
  python kb_protector.py --encrypt kb.md --key KEY
  python kb_protector.py --encrypt kb.md              # 从 stdin 读密码

  # 解密（运行时）
  python kb_protector.py --decrypt kb.md --key KEY
  python kb_protector.py --decrypt kb.md             # 降级：无密钥时尝试读明文

  # 验Integrity（不解密）
  python kb_protector.py --verify kb.md --key KEY

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.4.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.

import sys
import os
import io
import json
import hashlib
import base64
import argparse
import shutil
import re
from pathlib import Path
from datetime import datetime

# Windows GBK console compatibility
if sys.platform == 'win32' and not getattr(sys, '_kb_protector_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._kb_protector_utf8_set = True

# AES-256-GCM
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False


# ============================================================
# Constants
# ============================================================
ALGORITHM = "AES-256-GCM"
PBKDF2_ITERATIONS = 100_000
KEY_LEN = 32          # AES-256
IV_LEN = 12           # GCM standard IV
SALT_LEN = 16         # 128-bit salt
FRAGMENT_SIZE = 2048  # bytes per fragment


# ============================================================
# Utility
# ============================================================
def log(msg: str, level: str = "INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{ts}] [{level}] {clean}", flush=True)


def prompt_password(purpose: str = "decrypt") -> str:
    """Prompt password from stdin (masked). Fallback to env."""
    env_key = os.environ.get("KB_ENCRYPT_KEY", "").strip()
    if env_key:
        return env_key

    try:
        import getpass
        pwd = getpass.getpass(f"Enter encryption key [{purpose}]: ")
        if pwd.strip():
            return pwd.strip()
    except Exception:
        pass

    # Fallback: read from stdin (for piped input)
    log("[INFO] No key from env or getpass, trying stdin...", "INFO")
    try:
        import select
        if select.select([sys.stdin], [], [], 1)[0]:
            return sys.stdin.readline().strip()
    except Exception:
        pass

    log("[WARN] No key available, will use plaintext fallback", "WARNING")
    return ""


def compute_checksum(content: str) -> str:
    """SHA-256 of plaintext content (hex)."""
    return hashlib.sha256(content.encode('utf-8')).hexdigest()


# ============================================================
# KBProtector - Core
# ============================================================
class KBProtector:
    """
    知识库加密保护器

    发布流程（admin）：
      1. 读取 plaintext.md
      2. 用密钥加密 → 碎片化存储
      3. 发布包不含密钥，只有 fragments/ 和 manifest.json

    运行时流程（用户）：
      1. 读取 manifest + fragments
      2. 输入密钥 → 解密
      3. 失败则降级读 plaintext.md（如果存在）
    """

    def __init__(self, kb_file: Path, protected_dir: Path = None):
        self.kb_file = Path(kb_file)
        if protected_dir:
            self.protected_dir = Path(protected_dir)
        else:
            # Default: sibling dir named {kb_file}.protected/
            self.protected_dir = self.kb_file.parent / f".{self.kb_file.stem}.protected"
        self.protected_dir.mkdir(parents=True, exist_ok=True)

    # --------------------------------------------------------
    # Key derivation
    # --------------------------------------------------------
    def _derive_key(self, password: str, salt: bytes) -> bytes:
        """PBKDF2-SHA256 key derivation, 100k iterations."""
        if not HAS_CRYPTO:
            raise RuntimeError(
                "cryptography library not installed. "
                "Install with: pip install cryptography"
            )
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=KEY_LEN,
            salt=salt,
            iterations=PBKDF2_ITERATIONS,
        )
        return kdf.derive(password.encode('utf-8'))

    # --------------------------------------------------------
    # Fragment helpers
    # --------------------------------------------------------
    def _fragment(self, data: bytes) -> list[bytes]:
        """Split bytes into fragments of FRAGMENT_SIZE."""
        return [data[i:i + FRAGMENT_SIZE] for i in range(0, len(data), FRAGMENT_SIZE)]

    def _assemble(self, fragments: list[bytes]) -> bytes:
        return b''.join(fragments)

    # --------------------------------------------------------
    # Encrypt
    # --------------------------------------------------------
    def encrypt(self, password: str, plaintext: str = None) -> dict:
        """
        Encrypt knowledge base file.

        Returns:
            {"success": True, "fragment_count": N, "checksum": SHA256}

        Raises:
            RuntimeError: no password provided

        manifest.json stored (safe to publish):
            {
              "version": "1.0",
              "algorithm": "AES-256-GCM",
              "pbkdf2_iterations": 100000,
              "salt": "<base64>",
              "checksum": "<sha256_hex_of_plaintext>",
              "fragment_count": N,
              "fragment_size": 2048
            }
        """
        if not password:
            raise RuntimeError("Encryption key is required. Set KB_ENCRYPT_KEY env or pass --key.")

        log(f"[ENCRYPT] Source: {self.kb_file}")

        # Read plaintext (from parameter or file)
        if plaintext is None:
            if not self.kb_file.exists():
                raise RuntimeError(f"Source file not found: {self.kb_file}")
            plaintext = self.kb_file.read_text(encoding='utf-8')

        original_size = len(plaintext)
        log(f"[ENCRYPT] Content: {original_size} chars")

        # Derive key
        salt = os.urandom(SALT_LEN)
        key = self._derive_key(password, salt)
        aesgcm = AESGCM(key)

        # Encrypt: AESGCM.encrypt(nonce, pt, aad=None) returns ciphertext || auth_tag.
        # It does NOT include the nonce in its output.
        # So: ct_with_tag = aesgcm.encrypt(iv, plaintext, None)
        # We prepend iv before fragmenting (extract at decrypt time).
        iv = os.urandom(IV_LEN)
        ct_with_tag = aesgcm.encrypt(iv, plaintext.encode('utf-8'), None)
        # Store iv + ct_with_tag for reassembly; at decrypt: extract iv[:12], pass iv+ct as single buffer
        ciphertext = iv + ct_with_tag
        log(f"[ENCRYPT] AES-256-GCM done, ciphertext: {len(ciphertext)} bytes (IV+ct+tag)")

        # Fragment
        fragments = self._fragment(ciphertext)
        log(f"[ENCRYPT] Fragmented into {len(fragments)} pieces")

        # Clear old fragments
        for old in self.protected_dir.glob("fragment_*.bin"):
            old.unlink()

        # Save fragments
        for i, frag in enumerate(fragments):
            (self.protected_dir / f"fragment_{i:03d}.bin").write_bytes(frag)

        # Save manifest (NO password, NO key)
        manifest = {
            "version": "1.0",
            "algorithm": ALGORITHM,
            "pbkdf2_iterations": PBKDF2_ITERATIONS,
            "salt": base64.b64encode(salt).decode('ascii'),
            "checksum": compute_checksum(plaintext),
            "fragment_count": len(fragments),
            "fragment_size": FRAGMENT_SIZE,
            "encrypted_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        (self.protected_dir / "manifest.json").write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8'
        )

        log(f"[ENCRYPT] Saved to: {self.protected_dir}")
        log(f"[ENCRYPT] manifest.json (safe to publish): {len(json.dumps(manifest))} bytes")
        log(f"[ENCRYPT] Checksum (plaintext SHA256): {manifest['checksum'][:16]}...")

        return {
            "success": True,
            "fragment_count": len(fragments),
            "checksum": manifest["checksum"],
            "protected_dir": str(self.protected_dir),
        }

    # --------------------------------------------------------
    # Decrypt
    # --------------------------------------------------------
    def decrypt(self, password: str = None, plaintext_path: Path = None) -> str | None:
        """
        Decrypt knowledge base.

        Priority:
          1. Decrypt with key
          2. Fallback: read plaintext file if exists
          3. Return None (no error, graceful degradation)

        Args:
            password: encryption key (env KB_ENCRYPT_KEY if None)
            plaintext_path: fallback plaintext file (kb_file if None)

        Returns:
            Decrypted content, or None if unavailable.
        """
        manifest_file = self.protected_dir / "manifest.json"
        if not manifest_file.exists():
            log(f"[DECRYPT] No protected dir found, trying plaintext fallback", "INFO")
            return self._plaintext_fallback(plaintext_path)

        manifest = json.loads(manifest_file.read_text(encoding='utf-8'))
        log(f"[DECRYPT] Manifest: {manifest['algorithm']} + {manifest['fragment_count']} fragments")

        # Try to decrypt
        key_provided = bool(password or os.environ.get("KB_ENCRYPT_KEY", "").strip())
        if not key_provided:
            log("[DECRYPT] No key available, falling back to plaintext", "WARNING")
            return self._plaintext_fallback(plaintext_path)

        if not password:
            password = os.environ["KB_ENCRYPT_KEY"].strip()

        try:
            # Reconstruct ciphertext from fragments
            fragments = []
            for i in range(manifest["fragment_count"]):
                frag_path = self.protected_dir / f"fragment_{i:03d}.bin"
                if not frag_path.exists():
                    raise RuntimeError(f"Fragment {i} missing")
                fragments.append(frag_path.read_bytes())

            ciphertext = self._assemble(fragments)
            log(f"[DECRYPT] Assembled {len(fragments)} fragments, {len(ciphertext)} bytes")

            # Derive key
            salt = base64.b64decode(manifest["salt"])
            key = self._derive_key(password, salt)
            aesgcm = AESGCM(key)

            # ciphertext = iv (12 bytes) + ct_with_tag (ct + auth_tag)
            # decrypt takes: iv, ct_with_tag, aad=None
            iv = ciphertext[:IV_LEN]
            ct_with_tag = ciphertext[IV_LEN:]
            plaintext = aesgcm.decrypt(iv, ct_with_tag, None).decode('utf-8')
            log(f"[DECRYPT] AES-256-GCM decryption OK, {len(plaintext)} chars")

            # Integrity check
            checksum = compute_checksum(plaintext)
            if checksum != manifest["checksum"]:
                log(f"[DECRYPT] Checksum mismatch! Expected {manifest['checksum'][:16]}..., got {checksum[:16]}...", "ERROR")
                raise RuntimeError("Integrity check failed: content may be corrupted or tampered")

            log(f"[DECRYPT] Integrity check PASSED")
            return plaintext

        except Exception as e:
            err_msg = str(e)
            if "mac" in err_msg.lower() or "authentication" in err_msg.lower():
                log(f"[DECRYPT] Decryption failed (wrong key?): {e}", "ERROR")
            else:
                log(f"[DECRYPT] Decrypt error: {e}", "ERROR")
            log("[DECRYPT] Falling back to plaintext", "WARNING")
            return self._plaintext_fallback(plaintext_path)

    # --------------------------------------------------------
    # Plaintext fallback
    # --------------------------------------------------------
    def _plaintext_fallback(self, plaintext_path: Path = None) -> str | None:
        """Read plaintext if it exists. Returns None if not found."""
        path = Path(plaintext_path) if plaintext_path else self.kb_file
        if path.exists():
            content = path.read_text(encoding='utf-8')
            log(f"[DECRYPT] Using plaintext fallback: {path} ({len(content)} chars)", "INFO")
            return content
        log(f"[DECRYPT] No plaintext found at {path}, returning None", "WARNING")
        return None

    # --------------------------------------------------------
    # Verify integrity (no decrypt)
    # --------------------------------------------------------
    def verify(self, password: str = None) -> dict:
        """
        Verify encrypted knowledge base integrity WITHOUT decrypting.

        Returns:
            {"ok": True/False, "reason": "...", "details": {...}}
        """
        manifest_file = self.protected_dir / "manifest.json"
        if not manifest_file.exists():
            return {"ok": False, "reason": "No manifest.json found", "protected_dir": str(self.protected_dir)}

        manifest = json.loads(manifest_file.read_text(encoding='utf-8'))

        # Check fragments
        expected = manifest["fragment_count"]
        actual = len(list(self.protected_dir.glob("fragment_*.bin")))
        if actual != expected:
            return {
                "ok": False,
                "reason": f"Fragment count mismatch: expected {expected}, found {actual}",
                "details": manifest
            }

        # Check plaintext checksum if key available
        if password or os.environ.get("KB_ENCRYPT_KEY"):
            pwd = password or os.environ["KB_ENCRYPT_KEY"].strip()
            try:
                content = self.decrypt(password=pwd)
                if content is None:
                    return {"ok": False, "reason": "Decryption returned None", "details": manifest}
                return {
                    "ok": True,
                    "reason": "Integrity verified (decrypted successfully)",
                    "details": manifest
                }
            except Exception as e:
                return {"ok": False, "reason": f"Decrypt failed: {e}", "details": manifest}
        else:
            # Without key: just check structure
            return {
                "ok": True,
                "reason": "Structure OK (no key provided for content check)",
                "details": manifest
            }


# ============================================================
# CLI
# ============================================================
def cmd_encrypt(kb_file: Path, key: str, output_dir: Path = None):
    """Encrypt a knowledge base file."""
    protector = KBProtector(kb_file, output_dir)

    if not key:
        key = prompt_password("encrypt")
        if not key:
            log("[ERROR] Encryption key required", "ERROR")
            return 1

    result = protector.encrypt(password=key)

    # Also copy plaintext as optional fallback (encrypted alongside)
    fallback_path = protector.protected_dir / "plaintext_fallback.md"
    if kb_file.exists():
        fallback_path.write_text(kb_file.read_text(encoding='utf-8'), encoding='utf-8')
        log(f"[ENCRYPT] Plaintext fallback saved (optional): {fallback_path.name}")

    print(f"\n{'='*60}")
    print("[SUCCESS] Knowledge base encrypted!")
    print(f"  Source:   {kb_file}")
    print(f"  Output:   {protector.protected_dir}")
    print(f"  Fragments: {result['fragment_count']}")
    print(f"  Checksum:  {result['checksum'][:16]}...")
    print(f"\nmanifest.json is SAFE to publish (no key inside).")
    print(f"To decrypt: python kb_protector.py --decrypt {kb_file} --key YOUR_KEY")
    print(f"{'='*60}\n")
    return 0


def cmd_decrypt(kb_file: Path, key: str, output_path: Path = None):
    """Decrypt a knowledge base file."""
    protector = KBProtector(kb_file)

    content = protector.decrypt(password=key, plaintext_path=kb_file)

    if content is None:
        print(f"\n[ERROR] No content available: no key provided and no plaintext fallback found.", "ERROR")
        return 1

    out = output_path or kb_file
    Path(out).write_text(content, encoding='utf-8')
    print(f"\n[SUCCESS] Decrypted {len(content)} chars -> {out}")
    return 0


def cmd_verify(kb_file: Path, key: str = None):
    """Verify encrypted knowledge base integrity."""
    protector = KBProtector(kb_file)
    result = protector.verify(password=key)

    print(f"\n{'='*60}")
    print(f"Integrity Check: {'PASSED' if result['ok'] else 'FAILED'}")
    print(f"Reason: {result['reason']}")
    if "details" in result:
        d = result["details"]
        print(f"\nManifest:")
        print(f"  Algorithm:    {d.get('algorithm')}")
        print(f"  Fragments:    {d.get('fragment_count')}")
        print(f"  Checksum:     {d.get('checksum', 'N/A')[:16]}...")
        print(f"  Encrypted at: {d.get('encrypted_at', 'N/A')}")
    print(f"{'='*60}\n")
    return 0 if result["ok"] else 1


def main():
    parser = argparse.ArgumentParser(
        description="Knowledge Base Protector - 防君子不防小人的轻量加密",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Encrypt before publishing
  python kb_protector.py --encrypt references/my-kb.md --key my-secret-key

  # Decrypt at runtime (will prompt for key if not set)
  python kb_protector.py --decrypt references/my-kb.md --key my-secret-key

  # Verify integrity without decrypting
  python kb_protector.py --verify references/my-kb.md --key my-secret-key

  # Use environment variable for key
  set KB_ENCRYPT_KEY=my-secret-key
  python kb_protector.py --encrypt references/my-kb.md

Security notes:
  - manifest.json does NOT contain the encryption key
  - Plaintext fallback is saved alongside encrypted data (optional)
  - Wrong key -> graceful fallback to plaintext (if exists)
        """
    )
    parser.add_argument("--encrypt", metavar="FILE", help="Encrypt a knowledge base file")
    parser.add_argument("--decrypt", metavar="FILE", help="Decrypt a knowledge base file")
    parser.add_argument("--verify", metavar="FILE", help="Verify integrity without decrypting")
    parser.add_argument("--key", metavar="KEY", help="Encryption/decryption key (or set KB_ENCRYPT_KEY env)")
    parser.add_argument("--output", metavar="PATH", help="Output path for decrypt")
    parser.add_argument("--protected-dir", metavar="PATH", help="Custom protected directory (default: FILE.protected/)")

    args = parser.parse_args()

    if not HAS_CRYPTO:
        print("[FATAL] cryptography library required. Install:", file=sys.stderr)
        print("  pip install cryptography", file=sys.stderr)
        return 1

    if args.encrypt:
        out_dir = Path(args.protected_dir) if args.protected_dir else None
        return cmd_encrypt(Path(args.encrypt), args.key, out_dir)

    if args.decrypt:
        return cmd_decrypt(Path(args.decrypt), args.key, Path(args.output) if args.output else None)

    if args.verify:
        return cmd_verify(Path(args.verify), args.key)

    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
