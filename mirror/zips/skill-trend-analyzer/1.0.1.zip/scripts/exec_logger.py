#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
"""
Execution Logger v2 - Unified logging for all skill-trend-analyzer scripts
=============================================================================
统一执行日志模块：所有采集/扫描/分析脚本的全程日志记录

日志文件路径：data/logs/YYYY-MM/脚本名_YYYY-MM-DD.json
日志文件自动按年月分目录，方便管理。

每条日志包含：
  1. 执行开始/完成时间戳
  2. 运行参数（命令行参数）
  3. 各阶段进度（phase_start/phase_end）
  4. 完成时间戳 + 耗时
  5. 运行成果摘要（stats/结果数据）
  6. 自动化分析（anomaly_detected异常/慢阶段/失败）
  7. 自主改进建议（improvement_suggestions）

Usage:
  from exec_logger import ExecutionLogger
  logger = ExecutionLogger("market_collector")
  logger.start({"mode": "full"})  # 开始
  logger.phase("collecting")        # 阶段
  logger.phase("computing")        # 阶段
  logger.done({"searches": 30, "new": 5, "updated": 10})
"""
import sys
import os
import json
import time
import traceback
from pathlib import Path
from datetime import datetime
from collections import Counter

# [Safe Guard]
from safe_guard import safe_print, safe_init, safe_read_json
safe_init()

SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR.parent / "data"
LOGS_DIR = DATA_DIR / "logs"

# 确保logs目录存在
LOGS_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# 自动化分析引擎
# ============================================================

class LogAnalyzer:
    """对日志数据进行分析：异常检测 + 改进建议"""

    @staticmethod
    def analyze_run(entry):
        """
        分析单次运行结果，返回异常和改进建议。
        entry: 完整的日志条目 dict
        """
        anomalies = []
        suggestions = []

        duration_sec = entry.get("duration_sec", 0)
        stats = entry.get("stats", {})
        phases = entry.get("phases", [])
        mode = entry.get("args", {}).get("mode", "unknown")
        script = entry.get("script", "")
        status = entry.get("status", "unknown")

        # 1. 状态检查
        if status == "failed":
            anomalies.append({
                "type": "FAILURE",
                "severity": "CRITICAL",
                "message": f"脚本执行失败: {entry.get('error', '未知错误')}",
            })
            suggestions.append({
                "priority": 1,
                "action": "检查脚本错误日志，修复后重新运行",
                "reason": "执行失败，可能影响后续流程"
            })

        # 2. 耗时异常检测
        if duration_sec > 300:  # >5分钟
            anomalies.append({
                "type": "SLOW_EXECUTION",
                "severity": "WARNING",
                "message": f"执行耗时 {duration_sec:.0f}s (>5min)，可能存在性能问题",
            })
            suggestions.append({
                "priority": 2,
                "action": "检查是否有大量文件读取或网络请求，考虑添加超时保护",
                "reason": f"耗时 {duration_sec:.0f}s，超过预期阈值"
            })

        # 3. 慢阶段检测
        for phase in phases:
            if phase.get("duration_sec", 0) > 60:
                anomalies.append({
                    "type": "SLOW_PHASE",
                    "severity": "INFO",
                    "message": f"阶段 [{phase['name']}] 耗时 {phase['duration_sec']:.0f}s",
                })
                suggestions.append({
                    "priority": 3,
                    "action": f"优化 [{phase['name']}] 阶段逻辑，添加进度显示",
                    "reason": f"该阶段耗时较长: {phase['duration_sec']:.0f}s"
                })

        # 4. 数据量异常
        if script == "market_collector":
            searches = stats.get("searches", 0)
            new_skills = stats.get("new", 0)
            if searches == 0:
                anomalies.append({
                    "type": "NO_DATA",
                    "severity": "WARNING",
                    "message": "本次采集未执行任何搜索请求",
                })
                suggestions.append({
                    "priority": 1,
                    "action": "检查 ClawHub CLI 是否可用，或网络连接是否正常",
                    "reason": "searches=0，可能API调用失败"
                })
            if searches > 0 and new_skills == 0:
                anomalies.append({
                    "type": "ZERO_NEW",
                    "severity": "INFO",
                    "message": f"执行{searches}次搜索，但无新增技能（可能数据已缓存）",
                })
            cache_size = stats.get("cache_size", 0)
            if cache_size > 0:
                suggestions.append({
                    "priority": 4,
                    "action": "market cache 已积累数据，可以运行 trend_analyzer 分析趋势",
                    "reason": f"缓存 {cache_size} 个技能，数据充足"
                })

        if script == "local_skill_scanner":
            scanned = stats.get("scanned_count", 0)
            mode = entry.get("args", {}).get("mode", "")
            # status模式只是查看现有数据，不算"扫描"
            if scanned == 0 and mode not in ("status", "diff"):
                anomalies.append({
                    "type": "NO_SKILLS_SCANNED",
                    "severity": "CRITICAL",
                    "message": "未扫描到任何技能，可能技能目录不存在",
                })
                suggestions.append({
                    "priority": 1,
                    "action": "检查 SKILLS_ROOT 目录是否存在，技能是否有 SKILL.md",
                    "reason": "scanned=0"
                })
            elif scanned > 0:
                suggestions.append({
                    "priority": 4,
                    "action": "可以运行 skill_optimizer --batch 批量优化扫描到的技能",
                    "reason": f"扫描到 {scanned} 个技能"
                })

        if script == "trend_analyzer":
            market_size = stats.get("market_cache_size", 0)
            if market_size == 0:
                anomalies.append({
                    "type": "NO_MARKET_DATA",
                    "severity": "WARNING",
                    "message": "无市场数据，无法进行趋势分析",
                })
                suggestions.append({
                    "priority": 2,
                    "action": "先运行 market_collector 采集市场数据",
                    "reason": "trend_analyzer 依赖 market_cache.json"
                })
            trend_snaps = stats.get("trend_history_snapshots", 0)
            if trend_snaps < 2:
                suggestions.append({
                    "priority": 3,
                    "action": "需要至少2次采集快照才能分析趋势变化",
                    "reason": f"当前只有 {trend_snaps} 个快照"
                })

        if script == "skill_quality_checker":
            checked = stats.get("skills_checked", 0)
            if checked == 0:
                anomalies.append({
                    "type": "NO_CHECKS",
                    "severity": "WARNING",
                    "message": "未检查任何技能",
                })
            avg_score = stats.get("avg_compliance_score", 0)
            if avg_score > 0 and avg_score < 60:
                suggestions.append({
                    "priority": 3,
                    "action": "部分技能合规分数较低，建议运行 skill_quality_checker --fix 自动修复",
                    "reason": f"平均合规分数 {avg_score:.1f}%"
                })

        if script == "cross_skill_learner":
            optimized = stats.get("skills_optimized", 0)
            new_triggers = stats.get("total_new_triggers", 0)
            if optimized > 0:
                suggestions.append({
                    "priority": 4,
                    "action": f"学习了 {optimized} 个技能的优化，已添加 {new_triggers} 个触发词",
                    "reason": "跨技能学习完成，可以继续优化其他技能"
                })
            learn_data_size = stats.get("learn_data_entries", 0)
            if learn_data_size > 100:
                suggestions.append({
                    "priority": 3,
                    "action": "learn_data 已积累大量数据，建议运行 learn_sync --upload 上传云端",
                    "reason": f"已有 {learn_data_size} 条学习记录"
                })

        if script == "learn_sync":
            uploaded = stats.get("uploaded_count", 0)
            downloaded = stats.get("downloaded_count", 0)
            if uploaded > 0:
                suggestions.append({
                    "priority": 4,
                    "action": f"成功上传 {uploaded} 条数据进行自主改进",
                    "reason": "自主改进成功，数据已备份"
                })
            if downloaded > 0:
                suggestions.append({
                    "priority": 4,
                    "action": f"获取了 {downloaded} 条新数据进行自主改进",
                    "reason": "自主改进数据已合并到本地"
                })

        # 5. 通用改进建议
        if status == "success" and duration_sec < 10:
            suggestions.append({
                "priority": 5,
                "action": "执行速度快，可以增加采集量或优化更深的分析",
                "reason": f"耗时仅 {duration_sec:.1f}s，有余量做更多工作"
            })

        return {
            "anomalies": anomalies,
            "suggestions": suggestions
        }

    @staticmethod
    def analyze_history(log_file_path, days=7):
        """
        分析最近N天的历史日志，生成长期趋势报告。
        用于识别重复失败、性能退化等问题。
        """
        if not log_file_path.exists():
            return None

        try:
            logs = safe_read_json(log_file_path)
            if not isinstance(logs, list):
                return None

            # 过滤最近N天
            cutoff = datetime.now().timestamp() - days * 86400
            recent = [e for e in logs if e.get("start_time_ts", 0) > cutoff]

            if not recent:
                return {"message": f"最近{days}天无运行记录"}

            # 统计
            total_runs = len(recent)
            successes = sum(1 for e in recent if e.get("status") == "success")
            failures = sum(1 for e in recent if e.get("status") == "failed")
            avg_duration = sum(e.get("duration_sec", 0) for e in recent) / max(total_runs, 1)

            # 连续失败检测
            failed_runs = [e for e in recent if e.get("status") == "failed"]
            recent_failed_count = len(failed_runs)

            return {
                "period_days": days,
                "total_runs": total_runs,
                "successes": successes,
                "failures": failures,
                "success_rate": round(successes / total_runs * 100, 1),
                "avg_duration_sec": round(avg_duration, 1),
                "recent_failed_count": recent_failed_count,
                "alerts": [
                    {"type": "failure_spike", "count": recent_failed_count}
                    for _ in [1] if recent_failed_count >= 3
                ] if recent_failed_count >= 3 else []
            }
        except Exception:
            return None


# ============================================================
# Execution Logger 主类
# ============================================================

class ExecutionLogger:
    """
    统一执行日志记录器。

    每个脚本创建一个 logger 实例，start() 记录开始，
    phase() 记录各阶段，done() 记录完成+分析。

    日志文件：data/logs/YYYY-MM/<script>_YYYY-MM-DD.json
    每月一个子目录。
    """

    def __init__(self, script_name, log_subdir=None):
        """
        Args:
            script_name: 脚本标识名，如 "market_collector"
            log_subdir: 可选子目录，如 "market" -> data/logs/market/
        """
        self.script_name = script_name
        self.start_time = None
        self.start_ts = None
        self.phases = []          # [{name, start_ts, end_ts, duration_sec}]
        self.current_phase = None
        self.current_phase_start = None
        self.args = {}
        self.error = None
        self.status = "unknown"
        self._log_file = None

    # ---- 公共API ----

    def start(self, args=None):
        """
        记录执行开始。

        Args:
            args: dict，运行参数（如 {"mode": "full", "verbose": True}）
        """
        self.start_time = datetime.now()
        self.start_ts = self.start_time.timestamp()
        self.args = args or {}
        self.phases = []
        self.error = None
        self.status = "running"
        self._log_file = self._get_log_file()

        # 打印开始标记
        mode_str = self.args.get("mode", self.args.get("subcommand", "default"))
        safe_print(f"\n{'='*65}")
        safe_print(f"[START] {self.script_name} | {self.start_time.strftime('%Y-%m-%d %H:%M:%S')} | mode={mode_str}")
        safe_print(f"{'='*65}")

    def phase(self, phase_name):
        """
        标记阶段开始（同时结束上一阶段）。

        Args:
            phase_name: 阶段名称字符串，如 "collecting", "computing", "saving"
        """
        now = datetime.now()
        # 结束当前阶段
        if self.current_phase:
            duration = (now - self.current_phase_start).total_seconds()
            self.phases.append({
                "name": self.current_phase,
                "start_ts": self.current_phase_start.timestamp(),
                "end_ts": now.timestamp(),
                "duration_sec": round(duration, 2)
            })
            safe_print(f"  [PHASE] {self.current_phase} -> {duration:.2f}s")

        # 开始新阶段
        self.current_phase = phase_name
        self.current_phase_start = now
        safe_print(f"  >> {phase_name}...")

    def done(self, stats=None):
        """
        记录执行完成（含自动化分析）。

        Args:
            stats: dict，运行成果数据（如 {"searches": 30, "new": 5}）
        """
        now = datetime.now()
        end_ts = now.timestamp()

        # 结束最后一个阶段
        if self.current_phase and self.current_phase_start:
            duration = (now - self.current_phase_start).total_seconds()
            self.phases.append({
                "name": self.current_phase,
                "start_ts": self.current_phase_start.timestamp(),
                "end_ts": end_ts,
                "duration_sec": round(duration, 2)
            })
            self.current_phase = None

        # 计算总耗时
        if self.start_ts:
            total_duration = end_ts - self.start_ts
        else:
            total_duration = 0

        # 构建日志条目
        # 自动设置 status：未知→运行中→成功/失败
        if self.status == "running":
            self.status = "success"
        elif self.status == "unknown":
            self.status = "success"

        entry = {
            "script": self.script_name,
            "start_time": self.start_time.strftime("%Y-%m-%d %H:%M:%S") if self.start_time else "",
            "start_time_ts": self.start_ts or 0,
            "end_time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "end_time_ts": end_ts,
            "duration_sec": round(total_duration, 2),
            "status": self.status,
            "error": self.error,
            "args": self.args,
            "phases": self.phases,
            "stats": stats or {},
        }

        # 自动化分析
        analysis = LogAnalyzer.analyze_run(entry)
        entry["anomalies"] = analysis["anomalies"]
        entry["improvement_suggestions"] = analysis["suggestions"]

        # 保存到文件
        self._append_log(entry)

        # 打印完成报告
        self._print_completion_report(entry, analysis, stats or {})

        self.status = "done"
        return entry

    def fail(self, error_msg, stats=None):
        """
        记录执行失败。

        Args:
            error_msg: 错误信息字符串
            stats: dict，部分完成的统计
        """
        self.error = str(error_msg)
        self.status = "failed"
        return self.done(stats)

    # ---- 私有方法 ----

    def _get_log_file(self):
        """获取当前月份的日志文件路径。"""
        now = datetime.now()
        month_dir = LOGS_DIR / f"{now.year}-{now.month:02d}"
        month_dir.mkdir(parents=True, exist_ok=True)
        return month_dir / f"{self.script_name}.json"

    def _append_log(self, entry):
        """追加日志条目到文件。"""
        if not self._log_file:
            return
        try:
            logs = []
            if self._log_file.exists():
                try:
                    logs = safe_read_json(self._log_file) or []
                except Exception:
                    logs = []

            logs.append(entry)

            # 保留最近500条（按月分文件，已足够）
            if len(logs) > 500:
                logs = logs[-500:]

            self._log_file.write_text(
                json.dumps(logs, ensure_ascii=False, indent=1),
                encoding='utf-8'
            )
        except Exception as e:
            safe_print(f"[WARN] 日志写入失败: {e}")

    def _print_completion_report(self, entry, analysis, stats):
        """打印完成报告。"""
        status_icon = "[OK]" if entry["status"] == "success" else "[FAIL]"
        duration = entry["duration_sec"]

        safe_print(f"\n{'='*65}")
        safe_print(f"{status_icon} {self.script_name} 完成 | "
                   f"{entry['end_time']} | 耗时 {duration:.2f}s")
        safe_print(f"{'='*65}")

        # 成果摘要
        if stats:
            safe_print(f"[RESULTS]")
            for k, v in stats.items():
                safe_print(f"  {k}: {v}")

        # 阶段耗时
        if entry["phases"]:
            safe_print(f"\n[PHASES]")
            for p in entry["phases"]:
                safe_print(f"  {p['name']:<20s} {p['duration_sec']:>8.2f}s")

        # 异常告警
        anomalies = analysis.get("anomalies", [])
        if anomalies:
            safe_print(f"\n[ALERTS] ({len(anomalies)})")
            for a in anomalies:
                sev_icon = {"CRITICAL": "[!!]", "WARNING": "[!]", "INFO": "[i]"}.get(a["severity"], "[?]")
                safe_print(f"  {sev_icon} {a['type']}: {a['message']}")

        # 改进建议
        suggestions = analysis.get("improvement_suggestions", [])
        if suggestions:
            safe_print(f"\n[SUGGESTIONS] ({len(suggestions)})")
            for s in sorted(suggestions, key=lambda x: x.get("priority", 5)):
                safe_print(f"  [{s.get('priority', '?')}] {s['action']}")

        safe_print(f"{'='*65}")


# ============================================================
# 辅助函数
# ============================================================

def get_recent_logs(script_name, days=7):
    """获取指定脚本最近N天的所有日志。"""
    logs = []
    now = datetime.now()
    for _ in range(days):
        month_dir = LOGS_DIR / f"{now.year}-{now.month:02d}"
        log_file = month_dir / f"{script_name}.json"
        if log_file.exists():
            try:
                data = safe_read_json(log_file)
                if isinstance(data, list):
                    cutoff = (now.timestamp() - days * 86400)
                    logs.extend([e for e in data if e.get("start_time_ts", 0) > cutoff])
            except Exception:
                pass
        # 回退到上个月
        if now.day <= 1:
            # 上个月
            year = now.year if now.month > 1 else now.year - 1
            month = now.month - 1 if now.month > 1 else 12
            now = datetime(year, month, 28)
        else:
            break
    return sorted(logs, key=lambda x: x.get("start_time_ts", 0), reverse=True)


def print_log_summary(script_name, days=7):
    """打印最近N天的运行摘要。"""
    logs = get_recent_logs(script_name, days)
    if not logs:
        safe_print(f"[INFO] 最近{days}天无 {script_name} 运行记录")
        return

    safe_print(f"\n{'='*65}")
    safe_print(f"  {script_name} - 最近{days}天运行摘要 ({len(logs)}次)")
    safe_print(f"{'='*65}")

    for entry in logs:
        ts = entry.get("start_time", "??")
        dur = entry.get("duration_sec", 0)
        status = entry.get("status", "?")
        icon = "[OK]" if status == "success" else "[!!]" if status == "failed" else "[?]"
        stats = entry.get("stats", {})
        stats_str = " | ".join(f"{k}={v}" for k, v in list(stats.items())[:5])
        safe_print(f"  {icon} {ts} | {dur:.1f}s | {stats_str}")

    # 历史分析
    history_analysis = LogAnalyzer.analyze_history(None, days)
    if history_analysis and "message" not in history_analysis:
        safe_print(f"\n[HISTORY]")
        safe_print(f"  成功率: {history_analysis.get('success_rate', 0)}%")
        safe_print(f"  平均耗时: {history_analysis.get('avg_duration_sec', 0):.1f}s")
        if history_analysis.get("recent_failed_count", 0) >= 3:
            safe_print(f"  [!!] 警告: 最近{history_analysis['recent_failed_count']}次运行有失败")


def get_master_log_file():
    """获取总日志文件（汇总所有脚本）。"""
    now = datetime.now()
    month_dir = LOGS_DIR / f"{now.year}-{now.month:02d}"
    month_dir.mkdir(parents=True, exist_ok=True)
    return month_dir / "_master.json"


def append_master_log(entry):
    """追加到总日志文件。"""
    master = get_master_log_file()
    try:
        logs = []
        if master.exists():
            try:
                logs = safe_read_json(master) or []
            except Exception:
                logs = []
        logs.append(entry)
        if len(logs) > 2000:
            logs = logs[-2000:]
        master.write_text(json.dumps(logs, ensure_ascii=False, indent=1), encoding='utf-8')
    except Exception:
        pass
