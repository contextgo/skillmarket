#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
skill-trend-analyzer - 自动化设置系统 (Automation Setup)
=========================================================
根据用户偏好自动配置定时任务，提供交互式向导和智能推荐。

功能：
1. 自动化设置向导（交互式）
2. 智能推荐配置（根据用户级别）
3. 一键应用预设
4. 查看/修改/删除已设置的自动化任务

Author: QQ 1817694478 | Q-Group: 972156177
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177

import sys
import io
import json
import os
import argparse
from datetime import datetime
from pathlib import Path
from enum import Enum
from typing import Dict, Any, List, Optional

# ── UTF-8 safe ──────────────────────────────────────────────────────────────
if sys.platform == 'win32' and not getattr(sys, '_sta_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._sta_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"
PREF_PATH = ASSETS_DIR / "automation_preference.json"


# ── 更新模式枚举 ────────────────────────────────────────────────────────────
class UpdateMode(Enum):
    AUTO = "auto"      # 自动更新，静默执行
    ASK = "ask"        # 询问模式，提示用户确认
    MANUAL = "manual"  # 手动模式，仅CLI触发


class NotificationFrequency(Enum):
    ALWAYS = "always"   # 每次都有更新都通知
    DAILY = "daily"     # 每天汇总通知一次
    WEEKLY = "weekly"    # 每周汇总通知一次
    NEVER = "never"      # 不主动通知


# ── 预设配置模板 ────────────────────────────────────────────────────────────
PRESET_PROFILES = {
    "minimal": {
        "name": "极简模式",
        "description": "仅必要的定时同步，适合偶尔使用的用户",
        "update_mode": UpdateMode.MANUAL.value,
        "notification_frequency": NotificationFrequency.WEEKLY.value,
        "automations": [
            {"name": "每周自主改进", "task": "learn_sync", "schedule": "WEEKLY", "day": "SU", "hour": 22}
        ]
    },
    "standard": {
        "name": "标准模式",
        "description": "推荐配置，包含市场采集、扫描、质检、自主改进",
        "update_mode": UpdateMode.ASK.value,
        "notification_frequency": NotificationFrequency.DAILY.value,
        "automations": [
            {"name": "每日市场增量采集", "task": "market_collector", "schedule": "DAILY", "hour": 8},
            {"name": "每周本地扫描", "task": "local_skill_scanner", "schedule": "WEEKLY", "day": "SU", "hour": 9},
            {"name": "每周跨skill学习", "task": "cross_skill_learner", "schedule": "WEEKLY", "day": "SU", "hour": 9, "minute": 30},
            {"name": "每周质量自检", "task": "skill_quality_checker", "schedule": "WEEKLY", "day": "SU", "hour": 10},
            {"name": "每日云端同步", "task": "learn_sync", "schedule": "DAILY", "hour": 22}
        ]
    },
    "power-user": {
        "name": "强力用户模式",
        "description": "全功能自动化，适合深度用户",
        "update_mode": UpdateMode.AUTO.value,
        "notification_frequency": NotificationFrequency.ALWAYS.value,
        "automations": [
            {"name": "每日市场增量采集", "task": "market_collector", "schedule": "DAILY", "hour": 8},
            {"name": "每周全量市场采集", "task": "market_collector", "schedule": "WEEKLY", "day": "MO", "hour": 8},
            {"name": "每周本地扫描", "task": "local_skill_scanner", "schedule": "WEEKLY", "day": "SU", "hour": 9},
            {"name": "每周跨skill学习", "task": "cross_skill_learner", "schedule": "WEEKLY", "day": "SU", "hour": 9, "minute": 30},
            {"name": "每周质量自检", "task": "skill_quality_checker", "schedule": "WEEKLY", "day": "SU", "hour": 10},
            {"name": "每周趋势分析", "task": "trend_analyzer", "schedule": "WEEKLY", "day": "SU", "hour": 10, "minute": 30},
            {"name": "每日自主改进", "task": "learn_sync", "schedule": "DAILY", "hour": 22}
        ]
    },
    "custom": {
        "name": "自定义模式",
        "description": "完全自定义配置",
        "update_mode": UpdateMode.ASK.value,
        "notification_frequency": NotificationFrequency.DAILY.value,
        "automations": []
    }
}


# ── 任务定义 ───────────────────────────────────────────────────────────────
TASK_DEFINITIONS = {
    "market_collector": {
        "name": "市场数据采集",
        "script": "market_collector.py",
        "description": "采集ClawHub热门skill元数据",
        "type": "collector",
        "default_args": "",
        "typical_duration": "3-5分钟"
    },
    "local_skill_scanner": {
        "name": "本地skill扫描",
        "script": "local_skill_scanner.py",
        "description": "深度扫描本地已安装skill",
        "type": "scanner",
        "default_args": "",
        "typical_duration": "1-3分钟"
    },
    "cross_skill_learner": {
        "name": "跨skill学习",
        "script": "cross_skill_learner.py",
        "description": "从其他skill提取可复用模式",
        "type": "learner",
        "default_args": "",
        "typical_duration": "2-5分钟"
    },
    "skill_quality_checker": {
        "name": "质量合规自检",
        "script": "skill_quality_checker.py",
        "description": "7大质量检查能力",
        "type": "checker",
        "default_args": "--batch",
        "typical_duration": "5-10分钟"
    },
    "trend_analyzer": {
        "name": "趋势分析",
        "script": "trend_analyzer.py",
        "description": "分析市场趋势和上升关键词",
        "type": "analyzer",
        "default_args": "",
        "typical_duration": "1-2分钟"
    },
    "learn_sync": {
        "name": "自主改进",
        "script": "learn_sync.py",
        "description": "学习数据自主改进同步",
        "type": "sync",
        "default_args": "--sync",
        "typical_duration": "1-2分钟"
    }
}


# ── 自动化偏好管理器 ───────────────────────────────────────────────────────
class AutomationPreference:
    """自动化偏好管理器"""
    
    def __init__(self):
        self.preferences = self._load_preferences()
    
    def _load_preferences(self) -> Dict[str, Any]:
        """加载用户偏好"""
        if PREF_PATH.exists():
            try:
                with open(PREF_PATH, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"[WARN] Load failed: {e}")
        return self._default_preferences()
    
    def _save_preferences(self):
        """保存用户偏好"""
        ASSETS_DIR.mkdir(parents=True, exist_ok=True)
        with open(PREF_PATH, 'w', encoding='utf-8') as f:
            json.dump(self.preferences, f, ensure_ascii=False, indent=2)
    
    def _default_preferences(self) -> Dict[str, Any]:
        """默认偏好配置"""
        return {
            "version": "1.0.0",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "update_mode": UpdateMode.ASK.value,
            "notification_frequency": NotificationFrequency.DAILY.value,
            "active_profile": "standard",
            "automations": [],
            "auto_setup_completed": False
        }
    
    def set_profile(self, profile_name: str) -> bool:
        """设置预设配置"""
        if profile_name not in PRESET_PROFILES:
            return False
        
        profile = PRESET_PROFILES[profile_name]
        self.preferences["active_profile"] = profile_name
        self.preferences["update_mode"] = profile["update_mode"]
        self.preferences["notification_frequency"] = profile["notification_frequency"]
        self.preferences["automations"] = profile["automations"]
        self.preferences["updated_at"] = datetime.now().isoformat()
        self._save_preferences()
        return True
    
    def get_profile(self) -> str:
        """获取当前激活的配置"""
        return self.preferences.get("active_profile", "standard")
    
    def get_automations(self) -> List[Dict]:
        """获取自动化任务列表"""
        return self.preferences.get("automations", [])
    
    def add_automation(self, auto: Dict) -> bool:
        """添加自动化任务"""
        automations = self.get_automations()
        # 检查是否已存在同名任务
        for i, a in enumerate(automations):
            if a.get("task") == auto.get("task") and a.get("schedule") == auto.get("schedule"):
                automations[i] = auto  # 替换
                self.preferences["automations"] = automations
                self._save_preferences()
                return True
        
        automations.append(auto)
        self.preferences["automations"] = automations
        self._save_preferences()
        return True
    
    def remove_automation(self, task_name: str) -> bool:
        """移除自动化任务"""
        automations = [a for a in self.get_automations() if a.get("task") != task_name]
        self.preferences["automations"] = automations
        self._save_preferences()
        return True
    
    def set_update_mode(self, mode: str):
        """设置更新模式"""
        self.preferences["update_mode"] = mode
        self.preferences["updated_at"] = datetime.now().isoformat()
        self._save_preferences()
    
    def set_notification_frequency(self, freq: str):
        """设置通知频率"""
        self.preferences["notification_frequency"] = freq
        self.preferences["updated_at"] = datetime.now().isoformat()
        self._save_preferences()


# ── WorkBuddy自动化管理器 ───────────────────────────────────────────────────
class WorkBuddyAutomationManager:
    """WorkBuddy自动化任务管理器"""
    
    def __init__(self, skill_dir: Path = SKILL_DIR):
        self.skill_dir = skill_dir
        self.scripts_dir = skill_dir / "scripts"
    
    def _generate_automation_prompt(self, task_name: str, task: str, task_def: Dict, schedule_info: Dict) -> str:
        """生成自动化任务的prompt"""
        script = task_def.get("script", "")
        args = task_def.get("default_args", "")
        
        prompt = f"""执行 skill-trend-analyzer 的 {task_def['name']} 任务。

脚本路径: {self.skill_dir}/scripts/{script}
参数: {args}

执行完成后，记录执行结果到日志。"""
        return prompt
    
    def _build_rrule(self, schedule_info: Dict) -> str:
        """构建iCalendar RRULE"""
        schedule = schedule_info.get("schedule", "DAILY")
        
        if schedule == "DAILY":
            hour = schedule_info.get("hour", 8)
            return f"FREQ=DAILY;BYHOUR={hour};BYMINUTE=0"
        elif schedule == "WEEKLY":
            day = schedule_info.get("day", "SU")
            hour = schedule_info.get("hour", 9)
            minute = schedule_info.get("minute", 0)
            day_map = {"MO": "MO", "TU": "TU", "WE": "WE", "TH": "TH", "FR": "FR", "SA": "SA", "SU": "SU"}
            day_code = day_map.get(day, "SU")
            return f"FREQ=WEEKLY;BYDAY={day_code};BYHOUR={hour};BYMINUTE={minute}"
        elif schedule == "MONTHLY":
            day = schedule_info.get("day", 1)
            hour = schedule_info.get("hour", 8)
            return f"FREQ=MONTHLY;BYMONTHDAY={day};BYHOUR={hour};BYMINUTE=0"
        
        return f"FREQ=DAILY;BYHOUR=8;BYMINUTE=0"
    
    def create_automation(self, name: str, task: str, schedule: str, 
                         day: str = None, hour: int = 8, minute: int = 0) -> Dict[str, Any]:
        """创建单个自动化任务（返回配置供手动创建）"""
        task_def = TASK_DEFINITIONS.get(task, {})
        
        schedule_info = {"schedule": schedule, "day": day, "hour": hour, "minute": minute}
        rrule = self._build_rrule(schedule_info)
        prompt = self._generate_automation_prompt(name, task, task_def, schedule_info)
        
        return {
            "name": name,
            "task": task,
            "task_name": task_def.get("name", task),
            "script": task_def.get("script", ""),
            "description": task_def.get("description", ""),
            "schedule": schedule,
            "schedule_info": schedule_info,
            "rrule": rrule,
            "prompt": prompt,
            "typical_duration": task_def.get("typical_duration", "未知")
        }
    
    def plan_all_automations(self, automations: List[Dict]) -> List[Dict[str, Any]]:
        """计划所有自动化任务"""
        result = []
        for auto in automations:
            plan = self.create_automation(
                name=auto.get("name", ""),
                task=auto.get("task", ""),
                schedule=auto.get("schedule", "DAILY"),
                day=auto.get("day"),
                hour=auto.get("hour", 8),
                minute=auto.get("minute", 0)
            )
            result.append(plan)
        return result


# ── 自动化设置向导 ──────────────────────────────────────────────────────────
class AutomationSetupWizard:
    """交互式自动化设置向导"""
    
    def __init__(self):
        self.pref = AutomationPreference()
        self.manager = WorkBuddyAutomationManager()
        self.scheduled_automations = []
    
    def show_banner(self):
        """显示欢迎横幅"""
        print("\n" + "=" * 70)
        print("  SKILL-TREND-ANALYZER  自动化设置向导")
        print("  Automation Setup Wizard v1.0")
        print("=" * 70)
    
    def show_current_status(self):
        """显示当前状态"""
        profile = self.pref.get_profile()
        automations = self.pref.get_automations()
        
        print("\n[当前状态]")
        print(f"  配置模式: {PRESET_PROFILES.get(profile, {}).get('name', profile)}")
        print(f"  自动化任务数: {len(automations)}")
        print(f"  更新模式: {self.pref.preferences.get('update_mode', 'ask')}")
        print(f"  通知频率: {self.pref.preferences.get('notification_frequency', 'daily')}")
    
    def show_profile_menu(self):
        """显示配置模板菜单"""
        print("\n" + "-" * 70)
        print("  请选择配置模式：")
        print("-" * 70)
        
        for i, (key, profile) in enumerate(PRESET_PROFILES.items(), 1):
            icon = "[*]" if key == "custom" else f"[{i}]"
            print(f"  {icon} {profile['name']} ({key})")
            print(f"      {profile['description']}")
            if profile.get("automations"):
                task_names = [a["name"] for a in profile["automations"]]
                print(f"      包含: {', '.join(task_names[:3])}{'...' if len(task_names) > 3 else ''}")
        print()
    
    def show_task_menu(self):
        """显示任务菜单"""
        print("\n" + "-" * 70)
        print("  可用任务列表：")
        print("-" * 70)
        
        for i, (key, task) in enumerate(TASK_DEFINITIONS.items(), 1):
            print(f"  [{i}] {task['name']} - {task['description']}")
            print(f"      脚本: {task['script']} | 预计耗时: {task['typical_duration']}")
        print()
    
    def get_schedule_input(self) -> Dict[str, Any]:
        """获取调度配置输入"""
        print("\n  设置执行时间：")
        print("  [1] 每天")
        print("  [2] 每周一")
        print("  [3] 每周日")
        print("  [4] 每月1日")
        print("  [5] 自定义")
        
        try:
            choice = input("\n  请选择 [1-5]: ").strip() or "2"
        except (KeyboardInterrupt, EOFError):
            print("\n  [INFO] 已取消")
            return {"schedule": "WEEKLY", "day": "SU", "hour": 9, "minute": 0}
        
        default_hour = 8
        default_minute = 0
        
        if choice == "1":
            return {"schedule": "DAILY", "hour": default_hour, "minute": default_minute}
        elif choice == "2":
            return {"schedule": "WEEKLY", "day": "MO", "hour": default_hour, "minute": default_minute}
        elif choice == "3":
            return {"schedule": "WEEKLY", "day": "SU", "hour": default_hour, "minute": default_minute}
        elif choice == "4":
            return {"schedule": "MONTHLY", "day": 1, "hour": default_hour, "minute": default_minute}
        elif choice == "5":
            try:
                hour = int(input("  小时 (0-23): ").strip() or "8")
                return {"schedule": "DAILY", "hour": hour, "minute": 0}
            except (KeyboardInterrupt, EOFError, ValueError):
                return {"schedule": "DAILY", "hour": 8, "minute": 0}
        
        return {"schedule": "DAILY", "hour": 8, "minute": 0}
    
    def interactive_setup(self):
        """执行交互式设置"""
        self.show_banner()
        self.show_current_status()
        self.show_profile_menu()
        
        # 选择配置模板
        profile_keys = list(PRESET_PROFILES.keys())
        try:
            choice = input("\n请选择配置模式 [1-4] (默认: 2 标准模式): ").strip() or "2"
            idx = int(choice) - 1
            if 0 <= idx < len(profile_keys):
                selected_profile = profile_keys[idx]
            else:
                selected_profile = "standard"
        except (KeyboardInterrupt, EOFError, ValueError):
            print("\n[INFO] 使用标准配置")
            selected_profile = "standard"
        
        profile = PRESET_PROFILES[selected_profile]
        
        # 如果是自定义模式，引导用户选择任务
        if selected_profile == "custom":
            self.show_task_menu()
            selected_tasks = []
            
            print("\n  输入任务编号添加任务（多个用逗号分隔，如 1,3,5），输入 0 完成选择：")
            while True:
                try:
                    user_input = input("\n  > ").strip()
                    if user_input == "0":
                        break
                    if user_input:
                        for idx_str in user_input.split(","):
                            try:
                                idx = int(idx_str.strip()) - 1
                                if 0 <= idx < len(TASK_DEFINITIONS):
                                    task_key = list(TASK_DEFINITIONS.keys())[idx]
                                    if task_key not in selected_tasks:
                                        selected_tasks.append(task_key)
                                        print(f"  [+] 已添加: {TASK_DEFINITIONS[task_key]['name']}")
                            except ValueError:
                                pass
                except (KeyboardInterrupt, EOFError):
                    break
            
            # 为每个选中的任务配置调度
            automations = []
            for task_key in selected_tasks:
                task_def = TASK_DEFINITIONS[task_key]
                print(f"\n  配置 {task_def['name']}：")
                schedule_info = self.get_schedule_input()
                auto = {
                    "name": task_def["name"],
                    "task": task_key,
                    "schedule": schedule_info["schedule"],
                    "day": schedule_info.get("day"),
                    "hour": schedule_info.get("hour", 8),
                    "minute": schedule_info.get("minute", 0)
                }
                automations.append(auto)
            
            # 保存自定义配置
            self.pref.preferences["active_profile"] = "custom"
            self.pref.preferences["automations"] = automations
            self.pref.preferences["update_mode"] = UpdateMode.ASK.value
            self.pref.preferences["notification_frequency"] = NotificationFrequency.DAILY.value
            self.pref.preferences["updated_at"] = datetime.now().isoformat()
            self.pref._save_preferences()
        else:
            # 应用预设配置
            self.pref.set_profile(selected_profile)
            print(f"\n[OK] 已应用配置: {profile['name']}")
        
        # 生成预览
        self.show_preview()
    
    def show_preview(self):
        """显示自动化任务预览"""
        automations = self.pref.get_automations()
        if not automations:
            print("\n[INFO] 当前没有配置自动化任务")
            return
        
        print("\n" + "=" * 70)
        print("  自动化任务预览")
        print("=" * 70)
        
        plans = self.manager.plan_all_automations(automations)
        
        for i, plan in enumerate(plans, 1):
            print(f"\n  [{i}] {plan['name']}")
            print(f"      任务类型: {plan['task_name']}")
            print(f"      脚本: {plan['script']}")
            print(f"      调度: {plan['rrule']}")
            print(f"      预计耗时: {plan['typical_duration']}")
        
        self.scheduled_automations = plans
    
    def apply_and_generate_instructions(self) -> str:
        """生成应用自动化任务的指令"""
        plans = self.scheduled_automations
        
        if not plans:
            return ""
        
        lines = []
        lines.append("\n" + "=" * 70)
        lines.append("  自动化设置完成 - 请手动创建以下定时任务")
        lines.append("=" * 70)
        lines.append("\n在 WorkBuddy 中创建以下定时任务（设置 → 自动化 → 新建）：\n")
        
        for i, plan in enumerate(plans, 1):
            lines.append(f"任务 {i}: {plan['name']}")
            lines.append(f"  - 调度规则: {plan['rrule']}")
            lines.append(f"  - 执行脚本: {SKILL_DIR}/scripts/{plan['script']}")
            lines.append(f"  - Prompt内容:")
            lines.append(f"    \"\"\"")
            lines.append(f"    {plan['prompt']}")
            lines.append(f"    \"\"\"")
            lines.append("")
        
        lines.append("-" * 70)
        lines.append("或者在命令行使用 automation_update 工具创建：")
        lines.append("")
        
        for i, plan in enumerate(plans, 1):
            # 生成 automation_update 工具调用参数
            schedule_info = plan.get("schedule_info", {})
            rrule = plan.get("rrule", "")
            
            lines.append(f"# 任务 {i}: {plan['name']}")
            lines.append(f'automation_update create \\')
            lines.append(f'  --name "STA: {plan["name"]}" \\')
            lines.append(f'  --prompt "{plan["prompt"]}" \\')
            lines.append(f'  --rrule "{rrule}" \\')
            lines.append(f'  --cwds "{SKILL_DIR}" \\')
            lines.append(f'  --status ACTIVE')
            lines.append("")
        
        lines.append("=" * 70)
        
        return "\n".join(lines)


# ── CLI入口 ─────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description='skill-trend-analyzer 自动化设置系统',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --wizard              # 交互式设置向导
  %(prog)s --profile standard    # 应用标准预设
  %(prog)s --profile power-user  # 应用强力用户预设
  %(prog)s --show                # 显示当前配置
  %(prog)s --list                # 列出可用任务
  %(prog)s --apply               # 生成应用指令
        """
    )
    parser.add_argument('--wizard', action='store_true', help='启动交互式设置向导')
    parser.add_argument('--profile', choices=['minimal', 'standard', 'power-user', 'custom'],
                       help='应用预设配置')
    parser.add_argument('--show', action='store_true', help='显示当前配置')
    parser.add_argument('--list', action='store_true', help='列出可用任务')
    parser.add_argument('--apply', action='store_true', help='生成应用指令')
    parser.add_argument('--set-mode', choices=['auto', 'ask', 'manual'],
                       help='设置更新模式')
    parser.add_argument('--set-freq', choices=['always', 'daily', 'weekly', 'never'],
                       help='设置通知频率')
    
    args = parser.parse_args()
    
    wizard = AutomationSetupWizard()
    
    if args.list:
        # 列出可用任务
        print("\n" + "=" * 70)
        print("  可用任务列表")
        print("=" * 70)
        for key, task in TASK_DEFINITIONS.items():
            print(f"\n  [{key}]")
            print(f"    名称: {task['name']}")
            print(f"    描述: {task['description']}")
            print(f"    脚本: {task['script']} {task.get('default_args', '')}")
            print(f"    耗时: {task['typical_duration']}")
        print("\n" + "=" * 70)
        
    elif args.show:
        # 显示当前配置
        pref = AutomationPreference()
        profile = pref.get_profile()
        automations = pref.get_automations()
        
        print("\n" + "=" * 70)
        print("  当前自动化配置")
        print("=" * 70)
        print(f"\n  配置模式: {PRESET_PROFILES.get(profile, {}).get('name', profile)}")
        print(f"  更新模式: {pref.preferences.get('update_mode', 'ask')}")
        print(f"  通知频率: {pref.preferences.get('notification_frequency', 'daily')}")
        print(f"  自动化任务数: {len(automations)}")
        
        if automations:
            manager = WorkBuddyAutomationManager()
            plans = manager.plan_all_automations(automations)
            
            print("\n  任务列表:")
            for i, plan in enumerate(plans, 1):
                print(f"    [{i}] {plan['name']} - {plan['rrule']}")
        
        print("\n" + "=" * 70)
        
    elif args.wizard:
        # 交互式向导
        wizard.interactive_setup()
        if wizard.scheduled_automations:
            instructions = wizard.apply_and_generate_instructions()
            print(instructions)
        
    elif args.profile:
        # 应用预设配置
        pref = AutomationPreference()
        if pref.set_profile(args.profile):
            print(f"\n[OK] 已应用配置: {PRESET_PROFILES[args.profile]['name']}")
            wizard.pref = pref
            wizard.show_preview()
            
            # 生成应用指令
            if wizard.scheduled_automations:
                instructions = wizard.apply_and_generate_instructions()
                print(instructions)
        else:
            print(f"\n[ERROR] 未知配置: {args.profile}")
    
    elif args.set_mode:
        pref = AutomationPreference()
        pref.set_update_mode(args.set_mode)
        print(f"\n[OK] 更新模式已设置为: {args.set_mode}")
    
    elif args.set_freq:
        pref = AutomationPreference()
        pref.set_notification_frequency(args.set_freq)
        print(f"\n[OK] 通知频率已设置为: {args.set_freq}")
    
    elif args.apply:
        # 生成应用指令
        wizard.show_preview()
        if wizard.scheduled_automations:
            instructions = wizard.apply_and_generate_instructions()
            print(instructions)
    
    else:
        # 默认显示当前配置
        pref = AutomationPreference()
        profile = pref.get_profile()
        print(f"\n当前配置: {PRESET_PROFILES.get(profile, {}).get('name', profile)}")
        print(f"运行 --wizard 启动交互式设置向导")
        print(f"运行 --list 查看可用任务")
    
    # 结尾信息
    sys.stdout.buffer.write("\n[OK] skill-trend-analyzer automation setup\n".encode("utf-8", errors="replace"))
    sys.stdout.buffer.write("Contact: QQ 1817694478 | Q-Group 972156177\n".encode("utf-8", errors="replace"))


if __name__ == "__main__":
    main()
