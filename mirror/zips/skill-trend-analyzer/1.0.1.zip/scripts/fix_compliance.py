# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# -*- coding: utf-8 -*-
"""
Compliance Fixer - 自动修复合规问题
====================================
内化能力：
1. emoji清理 - 将脚本中的emoji替换为ASCII
2. SKILL.md广告清理 - 移除QQ/电话广告
3. 硬编码URL配置化 - 提取到config/api_urls.json
4. 版权头检查 - 确保所有脚本有正确的版权信息

Usage:
    python fix_compliance.py --all              # 执行所有修复
    python fix_compliance.py --emoji            # 仅清理emoji
    python fix_compliance.py --sklll-ad         # 仅清理SKILL.md广告
    python fix_compliance.py --hardcoded-url     # 仅配置化URL
    python fix_compliance.py --copyright        # 仅检查版权头
    python fix_compliance.py --dry-run          # 预览模式
"""

import sys
import io
import re
import json
import os
from pathlib import Path

# Windows GBK console compatibility
if sys.platform == 'win32' and not getattr(sys, '_wbuddy_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._wbuddy_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent

# Emoji to ASCII mapping
# NOTE: EMOJI_MAP 包含 emoji 原文作为数据源，用于清理其他脚本中的 emoji。
# 这是 fix_compliance.py 的设计意图，不属于违规输出。
EMOJI_MAP = {
    '[LEARN]': ['🌱'], '[SYNC]': ['🔄'], '[BOOK]': ['📚'], '[SEARCH]': ['🔍'],
    '[OK]': ['✅'], '[FAIL]': ['❌'], '[WARN]': ['⚠️'], '[STAT]': ['📊'],
    '[TIP]': ['💡'], '[FIX]': ['🔧'], '[HIT]': ['🎯'], '[LIST]': ['📋'],
    '[GEAR]': ['⚙️'], '[TOP]': ['🏆'], '[ROSE]': ['🌹'], '[PENGUIN]': ['🐧'],
    '[PKG]': ['📦'], '[V]': ['✓'], '[YEL]': ['🟡'], '[GRN]': ['🟢'],
    '[RED]': ['🔴'], '[DEF]': ['🛡️'], '[PWR]': ['⚡'], '[EDU]': ['🎓'],
    '[DOC]': ['📜'], '[PIN]': ['📌'], '[RUN]': ['🚀'], '[COST]': ['💰'],
    '[TIME]': ['⏰'], '[KEY]': ['🔑'], '[STAR]': ['🌟'], '[UP]': ['📈'],
    '[DOWN]': ['📉'], '[LINK]': ['🔗'], '[NOTE]': ['📝'], '[LOCK]': ['🔒'],
    '[WEB]': ['🌐'], '[DIR]': ['📁'], '[FILE]': ['📄'], '[MERGE]': ['🔀'],
    '[DL]': ['📥'], '[UL]': ['📤'], '[SAVE]': ['💾'], '[LOOP]': ['🔄'],
    '[BAL]': ['⚖️'], '[SHOW]': ['🎪'], '[FIND]': ['🔎'], '[DONE]': ['✅'],
    '[NEW]': ['🆕'], '[OK2]': ['🆗'], '[MSG]': ['💬'], '[USER]': ['👤'],
    '[ALERT]': ['⚠️'], '[MOB]': ['📱'], '[PC]': ['🖥️'], '[SEC]': ['🔐'],
    '[NEWS]': ['📰'], '[ANN]': ['📢'], '[DEL]': ['🗑️'], '[MARK]': ['📌'],
    '[REF]': ['🔃'], '[REPEAT]': ['🔁'], '[LAPTOP]': ['💻'], '[AIM]': ['🎯'],
    '[ATTACH]': ['📎'], '[URL]': ['🔗'], '[MODULE]': ['🧩'], '[OPEN]': ['📂'],
    '[BLUE]': ['🔵'], '[ORANGE]': ['🟠'], '[PURPLE]': ['🟣'], '[WHITE]': ['⚪'],
    '[BLACK]': ['⚫'], '[MEDAL]': ['🏅'], '[BADGE]': ['🎖️'], '[STICK]': ['📌'],
    '[UP2]': ['🔺'], '[DOWN2]': ['🔻'], '[FAV]': ['⭐'], '[LOC]': ['📍'],
    '[FOLDER]': ['🗂️'], '[CAL]': ['📆'], '[CLOCK]': ['🕐'], '[DATE]': ['📅'],
    '[TACK]': ['📌'], '[TAG]': ['🔖'], '[LABEL]': ['🏷️'], '[SPEAK]': ['🔈'],
    '[LOUD]': ['🔊'], '[RADIO]': ['📻'], '[GLOBE]': ['🌍'], '[MAP]': ['🗺️'],
    '[MTN]': ['🏔️'], '[HOT]': ['🔥'], '[ICE]': ['❄️'], '[SUN]': ['☀️'],
    '[MOON]': ['🌙'], '[STAR2]': ['⭐'], '[SPARK]': ['💫'], '[SPARKLE]': ['✨'],
    '[BOOM]': ['💥'], '[ANGRY]': ['💢'], '[SLEEP]': ['💤'], '[THINK]': ['💭'],
    '[CHAT]': ['💬'], '[QUOTE]': ['🗨️'], '[ANNOUNCE]': ['📣'], '[LOVELETTER]': ['💌'],
    '[EMAIL]': ['📧'], '[INBOX]': ['📨'], '[OUTBOX]': ['📩'], '[MAIL2]': ['📬'],
    '[MAIL3]': ['📮'], '[BOX]': ['📦'], '[SCROLL]': ['📜'], '[PAGE]': ['📃'],
    '[TAB]': ['📑'], '[CARD]': ['🗃️'], '[BALLOT]': ['🗳️'], '[CAB]': ['🗄️'],
    '[CLIP]': ['📁'], '[PAPER]': ['📰'], '[PEN]': ['🖊️'], '[PENCIL]': ['✏️'],
    '[MAGNIFY]': ['🔍'], '[LOOK]': ['🔎'], '[POINT]': ['📌'], '[CLIP2]': ['🖇️'],
    '[BIND]': ['📎'], '[CUT]': ['✂️'], '[BRUSH]': ['🖌️'], '[WRENCH]': ['🔧'],
    '[HAMMER]': ['🔨'], '[TOOLS]': ['⚒️'], '[TOOL]': ['🛠️'], '[BOLT]': ['🔩'],
    '[CHAIN]': ['🔗'], '[COG]': ['⚙️'], '[BRICK]': ['🧱'], '[MAGNET]': ['🧲'],
    '[ALCHEMY]': ['⚗️'], '[MICRO]': ['🔬'], '[TELESCOPE]': ['🔭'], '[PILL]': ['💊'],
    '[SYRINGE]': ['💉'], '[STETH]': ['🩺'], '[BLOOD]': ['🩸'], '[DNA]': ['🧬'],
    '[VIRUS]': ['🦠'], '[FLOWER]': ['💐'], '[SAKURA]': ['🌸'], '[HIBISCUS]': ['🌺'],
    '[SUNFLOWER]': ['🌻'], '[ROSE2]': ['🌹'], '[WILT]': ['🥀'], '[TULIP]': ['🌷'],
    '[SEED]': ['🌱'], '[TREE]': ['🌲'], '[TREE2]': ['🌳'], '[PALM]': ['🌴'],
    '[CACTUS]': ['🌵'], '[XMAS]': ['🎄'], '[WHEAT]': ['🌾'], '[HERB]': ['🌿'],
    '[SHAMROCK]': ['☘️'], '[CLOVER]': ['🍀'], '[PYRAMID]': ['🎍'], '[TANABATA]': ['🎋'],
    '[LEAF]': ['🍃'], '[FALLEN]': ['🍂'], '[MAPLE]': ['🍁'], '[WORLD]': ['🗺️'],
    '[JAPAN]': ['🗾'], '[MOUNT]': ['🏔️'], '[FUJI]': ['🗻'], '[CAMP]': ['🏕️'],
    '[BEACH]': ['🏖️'], '[DESERT]': ['🏜️'], '[ISLAND]': ['🏝️'], '[VOLCANO]': ['🌋'],
    '[PEAK]': ['🏔️'], '[SUNRISE]': ['🌅'], '[SUNUP]': ['🌄'], '[SHOOTING]': ['🌠'],
    '[GALAXY]': ['🌌'], '[BRIDGE]': ['🌉'], '[NIGHT]': ['🌃'], '[CITY]': ['🌆'],
    '[SUNSET]': ['🌇'], '[MERRY]': ['🎠'], '[FERRIS]': ['🎡'], '[COASTER]': ['🎢'],
    '[TANABATA2]': ['🎋'], '[FLAGS]': ['🎌'], '[LANTERN]': ['🏮'], '[CAMCORDER]': ['🎥'],
    '[FILM]': ['🎞️'], '[PROJECTOR]': ['📽️'], '[CLAPPER]': ['🎬'], '[ART]': ['🎨'],
    '[THEATER]': ['🎭'], '[CIRCUS]': ['🎪'], '[MIC]': ['🎤'], '[HEADPHONES]': ['🎧'],
    '[MUSIC]': ['🎼'], '[KEYBOARD]': ['🎹'], '[DRUM]': ['🥁'], '[SAX]': ['🎷'],
    '[TRUMPET]': ['🎺'], '[GUITAR]': ['🎸'], '[VIOLIN]': ['🎻'], '[DICE]': ['🎲'],
    '[CHESS]': ['♟️'], '[DART]': ['🎯'], '[BOWLING]': ['🎳'], '[CRICKET]': ['🏏'],
    '[FIELD]': ['🏑'], '[HOCKEY]': ['🏒'], '[SOFTBALL]': ['🥎'], '[TENNIS]': ['🎾'],
    '[PINGPONG]': ['🏓'], '[BADMINTON]': ['🏸'], '[BOXING]': ['🥊'], '[JERSEY]': ['🎽'],
    '[MEDAL2]': ['🏅'], '[MILITARY]': ['🎖️'], '[TROPHY]': ['🏆'], '[GOLD]': ['🥇'],
    '[SILVER]': ['🥈'], '[BRONZE]': ['🥉'], '[ROSETTE]': ['🏵️'], '[RIBBON2]': ['🎗️'],
    '[TICKET]': ['🎫'], '[ADMIT]': ['🎟️'], '[PRESENT]': ['🎁'], '[GEM]': ['💎'],
    '[RING]': ['💍'], '[CROWN]': ['👑'], '[BAG]': ['👜'], '[PURSE]': ['👝'],
    '[WALLET]': ['👛'], '[SHOPPING]': ['🛍️'], '[BACKPACK]': ['🎒'], '[CROWN2]': ['👑'],
    '[PRAYER]': ['📿'], '[LIPSTICK]': ['💄'], '[KISS]': ['💋'], '[RING2]': ['💍'],
    '[BOOT]': ['👢'], '[SANDAL]': ['👡'], '[HEELS]': ['👠'], '[SNEAKER]': ['👟'],
    '[SHOE]': ['👞'], '[DRESS]': ['👗'], '[KIMONO]': ['👘'], '[SWIM]': ['🩱'],
    '[BIKINI]': ['👙'], '[GLOVES]': ['🧤'], '[SCARF]': ['🧣'], '[COAT]': ['🧥'],
    '[SHIRT]': ['👔'], '[TSHIRT]': ['👕'], '[JEANS]': ['👖'], '[HAT]': ['🧢'],
    '[CAP]': ['👒'], '[TOPHAT]': ['🎩'], '[GRAD]': ['🎓'], '[CROW]': ['👑'],
    '[BEAR]': ['🧸'], '[CIRCUS2]': ['🎪'], '[DIA]': ['💠'], '[SPIRAL]': ['🌀'],
    '[DROP]': ['💧'], '[WAVE]': ['🌊'], '[REMINDER]': ['🎗️'], '[EYEGLASSES]': ['🕮️'],
    '[SUNGLASSES]': ['🕶️'], '[LUGGAGE]': ['🧳'], '[AMULET]': ['🧿'], '[HELIX]': ['🧬'],
    '[ALGAE]': ['🧫'], '[TEST]': ['🧪'], '[DNA2]': ['🧬'], '[FUNGU]': ['🧫'],
    '[MICROBE]': ['🦠'], '[CAPSULE]': ['💊'], '[STETH2]': ['🩺'], '[XRAY]': ['🩻'],
    '[EYE]': ['🧿'], '[BRAIN]': ['🧠'], '[TOOTH]': ['🦷'], '[BONE]': ['🦴'],
    '[EAR]': ['👂'], '[NOSE]': ['👃'], '[EYE2]': ['👁️'], '[EYES]': ['👀'],
    '[MOUTH]': ['🗣️'], '[TONGUE]': ['👅'], '[HAND]': ['🖐️'], '[STOP]': ['✋'],
    '[RAISE]': ['🤚'], '[WAVE2]': ['🖐️'], '[WRITE]': ['✍️'], '[HANDSHAKE]': ['🤝'],
    '[PRAY]': ['🙏'], '[FIST]': ['✊'], '[LEFT]': ['🤛'], '[RIGHT]': ['🤜'],
    '[CLAP]': ['👏'], '[PRAISE]': ['🙌'], '[CROSS]': ['🤞'], '[ROC]': ['🤟'],
    '[ROCK]': ['🤘'], '[CALL]': ['🤙'], '[OK2]': ['👌'], '[VICTORY]': ['✌️'],
    '[ILU]': ['🤟'], '[ROCK2]': ['🤘'], '[SPOCK]': ['🖖'], '[PHONE]': ['🤙'],
    '[PERFECT]': ['👌'], '[PINCH]': ['🤌'], '[EAR2]': ['🫘'], '[TEAPOT]': ['🫖'],
    '[CLAMP]': ['🗜️'], '[WRENCH2]': ['🔧'], '[WHITE]': ['🦯'], '[LIGHT]': ['🔦'],
    '[CANDLE]': ['🕯️'], '[IDEA]': ['💡'], '[CRYSTAL]': ['🔮'], '[CHARM]': ['🧿'],
    '[GENETICS]': ['🧬'], '[CHEMISTRY]': ['🧪'], '[BIOLOGY]': ['🧫'],
    '[EVOLUTION]': ['🧬'], '[INFECTION]': ['🦠'], '[RELIGION]': ['🧿'],
    '[FENG]': ['🧿'], '[HINDI]': ['🪬'], '[NAZAR]': ['🪬'], '[OM]': ['🧿'],
    '[KOMBU]': ['📿'], '[STAROF]': ['✡️'], '[YIN]': ['☯️'], '[PEACE]': ['☮️'],
    '[CROSS2]': ['✝️'], '[FENG2]': ['🔯'], '[ALTAR]': ['🛐'], '[ZODIAC]': ['⛎'],
    '[ARIES]': ['♈'], '[TAURUS]': ['♉'], '[GEMINI]': ['♊'], '[CANCER]': ['♋'],
    '[LEO]': ['♌'], '[VIRGO]': ['♍'], '[LIBRA]': ['♎'], '[SCORPIO]': ['♏'],
    '[SAGITTARIUS]': ['♐'], '[CAPRICORN]': ['♑'], '[AQUARIUS]': ['♒'], '[PISCES]': ['♓'],
    '[ID]': ['🆔'], '[NEW2]': ['🆕'], '[BAD]': ['🆖'], '[OK3]': ['🆗'],
    '[SOS]': ['🆘'], '[UP3]': ['🆙'], '[VS]': ['🆚'], '[HERE]': ['🈁'],
    '[KAT]': ['🈂️'], '[MONTH]': ['🈷️'], '[RESERVED]': ['🈶'], '[FINGER]': ['🈯'],
    '[BARGAIN]': ['🉐'], '[CURRENCY]': ['🈹'], '[DIRECT]': ['🈯'], '[FREE]': ['🈚'],
    '[APPLY]': ['🈸'], '[OPEN2]': ['🈺'], '[MONTH2]': ['🈷️'], '[CHECKBOX]': ['☑️'],
    '[CHECK]': ['✅'], '[INPUT]': ['🟰'], '[NUM]': ['🔢'], '[ABC]': ['🔤'],
    '[ABC2]': ['🔡'], '[CAPS]': ['🔠'], '[AB]': ['🆎'], '[CLEAR]': ['🆑'],
    '[COOL]': ['🆒'], '[FREE2]': ['🆓'], '[ID2]': ['🆔'], '[NEW3]': ['🆕'],
    '[NG]': ['🆖'], '[OK4]': ['🆗'], '[HELP]': ['🆘'], '[UP4]': ['🆙'],
    '[VS2]': ['🆚'], '[SHUFFLE]': ['🔀'], '[REPEAT2]': ['🔁'], '[ONCE]': ['🔂'],
    '[LOOP2]': ['🔃'], '[REVERSE]': ['🔄'], '[PLAY]': ['▶️'], '[PAUSE]': ['⏸️'],
    '[PLAY2]': ['⏯️'], '[STOP2]': ['⏹️'], '[REC]': ['⏺️'], '[NEXT]': ['⏭️'],
    '[PREV]': ['⏮️'], '[FAST]': ['⏩'], '[REWIND]': ['⏪'], '[TOP2]': ['⏫'],
    '[BOTTOM]': ['⏬'], '[LEFT2]': ['◀️'], '[RIGHT2]': ['▶️'], '[UP5]': ['🔼'],
    '[DOWN3]': ['🔽'], '[FWD]': ['➡️'], '[BCK]': ['⬅️'], '[UPUP]': ['⬆️'],
    '[DOWNDN]': ['⬇️'], '[NORTH]': ['⬆️'], '[SOUTH]': ['⬇️'], '[WEST]': ['⬅️'],
    '[EAST]': ['➡️'], '[NE]': ['↗️'], '[SE]': ['↘️'], '[SW]': ['↙️'],
    '[NW]': ['↖️'], '[NS]': ['↕️'], '[EW]': ['↔️'], '[RETURN]': ['↩️'],
    '[TURN]': ['↪️'], '[UPRT]': ['⤴️'], '[DOWNRT]': ['⤵️'], '[SYNC2]': ['🔃'],
    '[REFRESH]': ['🔄'], '[BACK]': ['🔙'], '[END]': ['🔚'], '[ON]': ['🔛'],
    '[SOON]': ['🔜'], '[TOP3]': ['🔝'], '[BAG2]': ['🛅'], '[CUSTOMS]': ['🛃'],
    '[BAGGAGE]': ['🛄'], '[BELL]': ['🛎️'], '[DOOR]': ['🚪'], '[BED]': ['🛏️'],
    '[COUCH]': ['🛋️'], '[CHAIR]': ['🪑'], '[TOILET]': ['🚽'], '[BATH]': ['🛁'],
    '[SHOWER]': ['🛀'], '[LOTION]': ['🧴'], '[HOOK]': ['🧷'], '[BROOM]': ['🧹'],
    '[BASKET]': ['🧺'], '[TISSUE]': ['🧻'], '[SOAP]': ['🧼'], '[TOOTHBRUSH]': ['🪥'],
    '[SPONGE]': ['🧽'], '[RAZOR]': ['🪒'], '[SHAMPOO]': ['🧴'], '[SUITCASE]': ['🧳'],
    '[SHOWER2]': ['🚿'], '[BATHTUB]': ['🛁'], '[WATER]': ['🚰'], '[FAUCET]': ['🚿'],
    '[STOOL]': ['🪑'], '[NESTING]': ['🪆'], '[CART]': ['🛒'], '[BIKE]': ['🚲'],
    '[SCOOTER]': ['🛴'], '[SIREN]': ['🚨'], '[CAR]': ['🚓'], '[AMBULANCE]': ['🚑'],
    '[FIRE]': ['🚒'], '[VAN]': ['🚐'], '[TRUCK]': ['🛻'], '[TRUCK2]': ['🚚'],
    '[TRUCK3]': ['🚛'], '[TRACTOR]': ['🚜'], '[RACE]': ['🏎️'], '[POLICE]': ['🚓'],
    '[AMBULANCE2]': ['🚑'], '[FIRE2]': ['🚒'], '[MINIBUS]': ['🚐'], '[PICKUP]': ['🛻'],
    '[TROLLEY]': ['🚎'], '[MOTO]': ['🏍️'], '[SCOOTER2]': ['🛵'], '[BIKE2]': ['🚲'],
    '[ONCOMING]': ['🚔'], '[BUS]': ['🚍'], '[ONCOMING2]': ['🚘'], '[ONCOMING3]': ['🚖'],
    '[AERIAL]': ['🚡'], '[CABLE]': ['🚠'], '[MONORAIL]': ['🚟'], '[TRAM]': ['🚃'],
    '[TRAM2]': ['🚋'], '[MOUNTAIN]': ['🚞'], '[MONORAIL2]': ['🚝'], '[BULLET]': ['🚄'],
    '[BULLET2]': ['🚅'], '[LIGHTRAIL]': ['🚈'], '[STEAM]': ['🚂'], '[TRAIN]': ['🚆'],
    '[METRO]': ['🚇'], '[TRAM3]': ['🚊'], '[STATION]': ['🚉'], '[AIRPLANE]': ['✈️'],
    '[FLIGHT]': ['🛫'], '[ARRIVAL]': ['🛬'], '[FLIGHT2]': ['🛩️'], '[SEAT]': ['💺'],
    '[SATELLITE]': ['🛰️'], '[ROCKET2]': ['🚀'], '[UFO]': ['🛸'], '[HELICOPTER]': ['🚁'],
    '[ROWBOAT]': ['🛶'], '[SAILBOAT]': ['⛵'], '[SPEEDBOAT]': ['🚤'], '[MOTORBOAT]': ['🛥️'],
    '[PASSENGER]': ['🛳️'], '[FERRY]': ['⛴️'], '[SHIP]': ['🚢'], '[ANCHOR]': ['⚓'],
    '[FUEL]': ['⛽'], '[CONSTRUCTION]': ['🚧'], '[LIGHTS]': ['🚦'], '[VERTICAL]': ['🚥'],
    '[OCTAGON]': ['🛑'], '[BUSSTOP]': ['🚏'], '[MAP2]': ['🗺️'], '[MOAI]': ['🗿'],
    '[STATUE]': ['🗽'], '[TOWER]': ['🗼'], '[EUROPEAN]': ['🏰'], '[JAPANESE]': ['🏯'],
    '[STADIUM]': ['🏟️'], '[FERRIS2]': ['🎡'], '[COASTER2]': ['🎢'], '[MERRY2]': ['🎠'],
    '[FOUNTAIN]': ['⛲'], '[UMBRELLA]': ['⛱️'], '[BEACH2]': ['🏖️'], '[ISLAND2]': ['🏝️'],
    '[DESERT2]': ['🏜️'], '[MOUNT2]': ['🏔️'], '[FUJI2]': ['🗻'], '[CAMPING]': ['🏕️'],
    '[TENT]': ['⛺'], '[CLASSICAL]': ['🏛️'], '[BUILDING]': ['🏗️'], '[OFFICE]': ['🏢'],
    '[BANK]': ['🏦'], '[HOUSE]': ['🏠'], '[HOUSE2]': ['🏡'], '[CAMPING2]': ['🏕️'],
    '[RESORT]': ['🏖️'], '[DESERTED]': ['🏝️'], '[TOWER2]': ['🗼'], '[LIBERTY]': ['🗽'],
    '[FACTORY]': ['🏭'], '[JAPANESE2]': ['🏯'], '[EUROPEAN2]': ['🏰'], '[CONVENIENCE]': ['🏪'],
    '[OPEN24]': ['24H'], '[DEPARTMENT]': ['🏬'], '[POST]': ['🏣'], '[POST2]': ['🏤'],
    '[HOSPITAL]': ['🏥'], '[BANK2]': ['🏦'], '[HOTEL]': ['🏨'], '[LOVE]': ['🏩'],
    '[STORE]': ['🏪'], '[CASTLE]': ['🏰'], '[WEDDING]': ['💒'], '[CHURCH]': ['⛪'],
    '[MOSQUE]': ['🕌'], '[SYNAGOGUE]': ['🕍'], '[TORII]': ['🕋'], '[SHRINE]': ['⛩️'],
    '[RAILWAY]': ['🛤️'], '[MOTORWAY]': ['🛣️'], '[JAPAN3]': ['🗾'], '[MAP3]': ['🗺️'],
    '[PIN2]': ['📍'], '[MOUNT3]': ['🏔️'], '[FUJI3]': ['🗻'], '[SUNRISE2]': ['🌅'],
    '[SUNUP2]': ['🌄'], '[SHOOTING2]': ['🌠'], '[SPARKLER]': ['🎇'], '[FIREWORK]': ['🎆'],
    '[GALAXY2]': ['🌌'], '[NIGHT2]': ['🌉'], '[NIGHT3]': ['🌃'], '[CITY2]': ['🏙️'],
    '[CITY3]': ['🌆'], '[SUNSET2]': ['🌇'], '[MILKY]': ['🌌'], '[FOGGY]': ['🌁'],
    '[RAINBOW]': ['🌈'], '[UMBRELLA2]': ['🌂'], '[CLOUD]': ['🌥️'], '[THUNDER]': ['⛈️'],
    '[LIGHTNING]': ['🌩️'], '[RAIN]': ['🌧️'], '[SNOW]': ['🌨️'], '[SNOWFLAKE]': ['❄️'],
    '[SNOWMAN]': ['☃️'], '[SNOWMAN2]': ['⛄'], '[WIND]': ['🌬️'], '[CYCLONE]': ['🌀'],
    '[TORNADO]': ['🌪️'], '[FOG]': ['🌫️'], '[TORNADO2]': ['🌪️'], '[CLOUD2]': ['☁️'],
    '[PARTLY]': ['⛅'], '[THUNDER2]': ['⛈️'], '[SUNNY]': ['🌤️'], '[TORNADO3]': ['🌪️'],
    '[CYCLONE2]': ['🌀'], '[BLOW]': ['🌬️'], '[DASH]': ['💨'], '[WAVE2]': ['🌊'],
    '[MIST]': ['🌫️'], '[FOG2]': ['🌁'], '[BEACH3]': ['⛱️'], '[SAND]': ['🏖️'],
    '[ISLAND3]': ['🏝️'], '[DESERT3]': ['🏜️'], '[MOUNT4]': ['🏔️'], '[FUJI4]': ['🗻'],
    '[CAMP2]': ['🏕️'], '[TRACK]': ['🛤️'], '[HIGHWAY]': ['🛣️'], '[FUEL2]': ['⛽'],
    '[OIL]': ['🛢️'], '[YEN]': ['💴'], '[DOLLAR]': ['💵'], '[EURO]': ['💶'],
    '[POUND]': ['💷'], '[MONEY]': ['💰'], '[MONEY2]': ['💸'], '[CARD]': ['💳'],
    '[CHART]': ['💹'], '[CURRENCY2]': ['💱'], '[HEAVY]': ['💲'], '[ZAP]': ['⚡'],
    '[CLOCK2]': ['🕐'], '[ALARM]': ['⏰'], '[STOPWATCH]': ['⏱️'], '[TIMER]': ['⏲️'],
    '[CLOCK3]': ['🕰️'], '[WATCH]': ['⌚'], '[PHONE2]': ['📱'], '[PHONE3]': ['📲'],
    '[LAPTOP2]': ['💻'], '[DESKTOP]': ['🖥️'], '[PRINTER]': ['🖨️'], '[KEYBOARD2]': ['⌨️'],
    '[MOUSE]': ['🖱️'], '[TRACKBALL]': ['🖲️'], '[MINIDISC]': ['💽'], '[FLOPPY]': ['💾'],
    '[CD]': ['💿'], '[DVD]': ['📀'], '[ABACUS]': ['🧮'], '[CAMERA]': ['🎥'],
    '[VIDEOCAM]': ['📹'], '[FILM2]': ['🎞️'], '[TELEPHONE]': ['📞'], '[TV]': ['📺'],
    '[RADIO2]': ['📻'], '[COMPASS]': ['🧭'], '[BATTERY]': ['🔋'], '[PLUG]': ['🔌'],
    '[BULB]': ['💡'], '[FLASHLIGHT]': ['🔦'], '[CANDLE2]': ['🕯️'], '[DOLLAR2]': ['💵'],
    '[YEN2]': ['💴'], '[EURO2]': ['💶'], '[POUND2]': ['💷'], '[MONEY3]': ['💰'],
    '[MONEY4]': ['💸'], '[CARDS]': ['💳'], '[CURRENCY3]': ['💱'], '[CHART2]': ['💹'],
    '[ENVELOPE]': ['✉️'], '[E-MAIL]': ['📩'], '[OUT]': ['📤'], '[IN]': ['📥'],
    '[PARCEL]': ['📦'], '[POSTAL]': ['📫'], '[MAIL6]': ['📪'], '[MAIL7]': ['📬'],
    '[INCOMING]': ['📭'], '[POSTOFFICE]': ['📮'], '[MEMO]': ['📝'], '[FILE2]': ['📁'],
    '[FILE3]': ['📂'], '[DIVIDER]': ['🗂️'], '[CALENDAR]': ['📅'], '[DATE2]': ['📆'],
    '[NOTE2]': ['🗒️'], '[CAL2]': ['🗓️'], '[CARDINDEX]': ['📇'], '[CHARTUP]': ['📈'],
    '[CHARTDOWN]': ['📉'], '[CHART3]': ['📊'], '[CLIPBOARD]': ['📋'], '[PUSHPIN]': ['📌'],
    '[ROUND]': ['📍'], '[PAPERCLIP]': ['📎'], '[LINK2]': ['🖇️'], '[STRAIGHT]': ['📏'],
    '[TRIANGLE]': ['📐'], '[SCISSORS]': ['✂️'], '[PEN2]': ['🖊️'], '[CRAYON]': ['🖌️'],
    '[PENCIL3]': ['🖍️'], '[DOCUMENT]': ['📝'], '[PAPER2]': ['📄'], '[PAGE2]': ['📃'],
    '[TABS]': ['📑'], '[RECEIPT]': ['🧾'], '[PRESS]': ['📰'], '[NOTEBOOK]': ['📓'],
    '[LEDGER]': ['📒'], '[CLOSED]': ['📕'], '[GREEN]': ['📗'], '[BLUE]': ['📘'],
    '[ORANGE]': ['📙'], '[BOOKS]': ['📚'], '[BOOKS2]': ['📚'], '[TAG2]': ['🏷️'],
    '[LABEL2]': ['🏷️'], '[COIN]': ['💰'], '[COIN2]': ['🪙'], '[YEN3]': ['💴'],
    '[DOLLAR3]': ['💵'], '[EURO3]': ['💶'], '[POUND3]': ['💷'], '[MONEY5]': ['💰'],
    '[MONEY6]': ['💸'], '[CARDS2]': ['💳'], '[CURRENCY4]': ['💱'], '[CHART4]': ['💹'],
    '[EMAIL2]': ['✉️'], '[INCOMING2]': ['📨'], '[OUTGOING]': ['📩'], '[SENT]': ['📤'],
    '[INCOMING3]': ['📥'], '[DELIVERY]': ['📦'], '[E_MAIL]': ['📧'], '[LOVELETTER2]': ['💌'],
    '[MAIL8]': ['📪'], '[MAIL9]': ['📬'], '[MAIL10]': ['📭'], '[POST2]': ['📮'],
    '[POSTAL2]': ['📯'], '[SCROLL2]': ['📜'], '[PAGE3]': ['📃'], '[DOC2]': ['📄'],
    '[NEWSPAPER]': ['📰'], '[TABS2]': ['📑'], '[BOOKMARK2]': ['🔖'], '[TAG3]': ['🏷️'],
    '[PIN3]': ['📌'], '[TABS3]': ['🗂️'], '[DATE3]': ['📅'], '[DATE4]': ['📆'],
    '[CALENDAR2]': ['📅'], '[CAL3]': ['🗓️'], '[ROLodex]': ['📇'], '[TRENDUP]': ['📈'],
    '[TRENDDOWN]': ['📉'], '[BARS]': ['📊'], '[TASKS]': ['📋'], '[YES]': ['✅'],
    '[CHECKED]': ['☑️'], '[TICKED]': ['✔️'], '[RADIO]': ['🔘'], '[SQUARE]': ['🔲'],
    '[WHITESQUARE]': ['🔳'], '[SPEAKER]': ['🔈'], '[SOUND]': ['🔉'], '[LOUD2]': ['🔊'],
    '[MUTED]': ['🔇'], '[MEGAPHONE]': ['📣'], '[E_MAIL2]': ['📧'], '[SPEAKER2]': ['🔈'],
    '[SPEAKER3]': ['🔉'], '[SPEAKER4]': ['🔊'], '[BELL2]': ['🔔'], '[BELL_OFF]': ['🔕'],
    '[FOLDER2]': ['📁'], '[OPENFOLDER]': ['📂'], '[FILECABINET]': ['🗂️'],
    '[DATE5]': ['📆'], '[NOTE3]': ['🗒️'], '[CARDS2]': ['📇'], '[LINK3]': ['🔗'],
    '[PIN4]': ['📌'], '[LOCATION]': ['📍'], '[MAP4]': ['🗺️'],
}


def clean_emojis_in_file(py_file: Path) -> int:
    """清理单个文件中的emoji，返回清理数量"""
    try:
        content = py_file.read_text(encoding='utf-8')
    except:
        return 0

    cleaned = content
    for ascii_rep, emojis in EMOJI_MAP.items():
        for emoji in emojis:
            cleaned = cleaned.replace(emoji, ascii_rep)

    if cleaned != content:
        py_file.write_text(cleaned, encoding='utf-8')
        return cleaned.count(ascii_rep)
    return 0


def clean_emojis_in_skill(dry_run: bool = False) -> dict:
    """清理skill中所有脚本的emoji"""
    results = {'files': 0, 'total': 0}
    for py_file in list(SKILL_DIR.rglob('*.py')) + [SCRIPT_DIR / 'build_release.py']:
        if 'clean_emojis' in str(py_file) or 'debug_urls' in str(py_file):
            continue  # Skip self
        count = clean_emojis_in_file(py_file) if not dry_run else 0
        if count > 0 or dry_run:
            results['files'] += 1
            results['total'] += count
            print(f'  [EMOJI] {py_file.relative_to(SKILL_DIR)}: {count} cleaned')
    return results


def clean_skill_md_ads(dry_run: bool = False) -> dict:
    """清理SKILL.md中的QQ/电话广告"""
    results = {'removed': 0}
    skill_md = SKILL_DIR / 'SKILL.md'
    if not skill_md.exists():
        print('  [WARN] SKILL.md not found')
        return results

    content = skill_md.read_text(encoding='utf-8')

    # Patterns to remove (output format rules sections)
    patterns = [
        r'## Output Format Rule.*?(?=\n## |\n# |\Z)',
        r'## Output Format Rule.*',
        r'🌹.*?联系作者QQ.*?\n',
        r'🌹.*?联系作者QQ.*',
    ]

    for pattern in patterns:
        matches = re.findall(pattern, content, re.DOTALL)
        for match in matches:
            if '联系作者QQ' in match or 'Output Format Rule' in match:
                content = content.replace(match, '')
                results['removed'] += 1
                if not dry_run:
                    print(f'  [AD] Removed: {match[:50]}...')

    if not dry_run and results['removed'] > 0:
        skill_md.write_text(content, encoding='utf-8')

    return results


def create_config_for_hardcoded_urls(dry_run: bool = False) -> dict:
    """为hardcoded URL创建配置"""
    results = {'created': False}

    config_dir = SKILL_DIR / 'config'
    config_file = config_dir / 'api_urls.json'

    if config_file.exists():
        print(f'  [CONFIG] api_urls.json already exists')
        return results

    if not dry_run:
        config_dir.mkdir(exist_ok=True)
        template = '''{
  "_comment": "API URLs Configuration - Auto-generated by fix_compliance.py",
  "_usage": "Import get_config() from scripts/config_loader.py",
  "example_api": {
    "base_url": "YOUR_API_URL_HERE",
    "description": "Replace with your actual API endpoint"
  }
}'''
        config_file.write_text(template, encoding='utf-8')
        print(f'  [CONFIG] Created {config_file.relative_to(SKILL_DIR)}')

    results['created'] = True
    return results


def check_copyright_headers(dry_run: bool = False) -> dict:
    """检查脚本版权头"""
    results = {'missing': [], 'ok': 0}
    required = ['Copyright', 'QQ']

    for py_file in SCRIPT_DIR.rglob('*.py'):
        if py_file.name in ['fix_compliance.py', 'clean_emojis.py', 'debug_urls.py']:
            continue  # Skip self and helpers
        try:
            content = py_file.read_text(encoding='utf-8')
            first_lines = '\n'.join(content.split('\n')[:5])
            if not all(req in first_lines for req in required):
                results['missing'].append(str(py_file.relative_to(SKILL_DIR)))
                print(f'  [COPYRIGHT] Missing in {py_file.name}')
            else:
                results['ok'] += 1
        except:
            pass

    return results


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Compliance Fixer - Auto-fix skill compliance issues')
    parser.add_argument('--all', action='store_true', help='Execute all fixes')
    parser.add_argument('--emoji', action='store_true', help='Clean emojis')
    parser.add_argument('--skill-ad', action='store_true', help='Remove SKILL.md ads')
    parser.add_argument('--hardcoded-url', action='store_true', help='Create config for hardcoded URLs')
    parser.add_argument('--copyright', action='store_true', help='Check copyright headers')
    parser.add_argument('--dry-run', action='store_true', help='Preview only, no changes')
    args = parser.parse_args()

    if not any(vars(args).values()):
        parser.print_help()
        return

    print('[FIX] Compliance Fixer')
    print(f'      Mode: {"DRY RUN" if args.dry_run else "LIVE"}\n')

    if args.all or args.emoji:
        print('[1] Cleaning emojis...')
        r = clean_emojis_in_skill(args.dry_run)
        print(f'    Done: {r["files"]} files, {r["total"]} emojis cleaned\n')

    if args.all or args.skill_ad:
        print('[2] Cleaning SKILL.md ads...')
        r = clean_skill_md_ads(args.dry_run)
        print(f'    Done: {r["removed"]} sections removed\n')

    if args.all or args.hardcoded_url:
        print('[3] Creating URL config...')
        r = create_config_for_hardcoded_urls(args.dry_run)
        print(f'    Done: {"Created" if r["created"] else "Already exists"}\n')

    if args.all or args.copyright:
        print('[4] Checking copyright headers...')
        r = check_copyright_headers(args.dry_run)
        print(f'    Done: {r["ok"]} OK, {len(r["missing"])} missing\n')

    print('[OK] Compliance fix complete!')
    print('     Run: python scripts/skill_quality_checker.py . --report')
    print('     to verify compliance score.')


if __name__ == '__main__':
    main()
