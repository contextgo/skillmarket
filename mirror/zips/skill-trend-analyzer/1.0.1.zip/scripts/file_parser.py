#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TaxRiskGuard - File Parser & Data Extractor
企业上传文件/图片解析与数据提取

Supports:
- Images: PNG/JPG/JPEG/BMP (OCR via PIL metadata + text extraction)
- PDF: Text-based PDF parsing
- Excel/CSV: Financial data extraction
- JSON/TXT: Structured data parsing

Usage:
    python file_parser.py --input <file_or_dir> --output <result.json>
    python file_parser.py --input image.png --type auto --extract financial
"""
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
# Unauthorized copying, modification, or distribution is prohibited.
# This software is provided "as is" without warranty of any kind.

import sys
import io
import re
import json
import os
import argparse
import hashlib
import base64
from datetime import datetime
from pathlib import Path

# Windows GBK console compatibility (skip if already set by entry module)
if sys.platform == 'win32' and not getattr(sys, '_tax_risk_utf8_set', False):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    sys._tax_risk_utf8_set = True

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent


def log(msg: str):
    """Timestamped log, remove emoji for GBK compatibility"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    clean_msg = re.sub(r'[\U00010000-\U0010ffff]', '', str(msg))
    print(f"[{timestamp}] {clean_msg}", flush=True)


# ============================================================
# File type detection
# ============================================================

FILE_SIGNATURES = {
    b'\x89PNG\r\n\x1a\n': 'png',
    b'\xff\xd8\xff': 'jpg',
    b'BM': 'bmp',
    b'%PDF': 'pdf',
    b'PK\x03\x04': 'xlsx',  # ZIP-based (xlsx/zip)
    b'\xd0\xcf\x11\xe0': 'xls',  # OLE2 (xls)
}

DOCUMENT_TYPES = {
    'png': 'image', 'jpg': 'image', 'jpeg': 'image', 'bmp': 'image', 'gif': 'image', 'webp': 'image',
    'pdf': 'pdf',
    'xlsx': 'excel', 'xls': 'excel', 'csv': 'excel',
    'json': 'json', 'txt': 'text', 'md': 'text',
}


def detect_file_type(filepath: str) -> dict:
    """Detect file type by extension and magic bytes"""
    ext = Path(filepath).suffix.lower().lstrip('.')
    result = {"path": filepath, "ext": ext, "detected_type": None, "category": None, "size": 0}

    if not os.path.isfile(filepath):
        result["error"] = "File not found"
        return result

    result["size"] = os.path.getsize(filepath)

    # Check magic bytes
    try:
        with open(filepath, 'rb') as f:
            header = f.read(8)
        for sig, ftype in FILE_SIGNATURES.items():
            if header[:len(sig)] == sig:
                result["detected_type"] = ftype
                break
    except Exception:
        pass

    # Fallback to extension
    if not result["detected_type"]:
        result["detected_type"] = ext

    result["category"] = DOCUMENT_TYPES.get(result["detected_type"], 'unknown')
    return result


# ============================================================
# Financial data patterns
# ============================================================

FINANCIAL_PATTERNS = {
    # Revenue related
    "revenue": [
        r'营业收入[：:\s]*([\d,，.]+)\s*万?元?',
        r'主营业务收入[：:\s]*([\d,，.]+)\s*万?元?',
        r'营业务收入[：:\s]*([\d,，.]+)\s*万?元?',
        r'sales\s*revenue[：:\s]*([\d,，.]+)',
    ],
    # Cost related
    "cost": [
        r'营业成本[：:\s]*([\d,，.]+)\s*万?元?',
        r'主营业务成本[：:\s]*([\d,，.]+)\s*万?元?',
    ],
    # Profit related
    "profit": [
        r'利润总额[：:\s]*([\d,，.]+)\s*万?元?',
        r'净利润[：:\s]*([\d,，.]+)\s*万?元?',
        r'应纳税所得额[：:\s]*([\d,，.]+)\s*万?元?',
    ],
    # Tax related
    "tax": [
        r'企业所得税[：:\s]*([\d,，.]+)\s*万?元?',
        r'应纳所得税额[：:\s]*([\d,，.]+)\s*万?元?',
        r'已缴所得税[：:\s]*([\d,，.]+)\s*万?元?',
    ],
    # Entertainment expense
    "entertainment": [
        r'业务招待费[：:\s]*([\d,，.]+)\s*万?元?',
        r'招待费[：:\s]*([\d,，.]+)\s*万?元?',
    ],
    # R&D expense
    "rd_expense": [
        r'研发费用[：:\s]*([\d,，.]+)\s*万?元?',
        r'研究开发费[：:\s]*([\d,，.]+)\s*万?元?',
    ],
    # Welfare expense
    "welfare": [
        r'职工福利费[：:\s]*([\d,，.]+)\s*万?元?',
        r'福利费[：:\s]*([\d,，.]+)\s*万?元?',
    ],
    # Advertising
    "advertising": [
        r'广告费[：:\s]*([\d,，.]+)\s*万?元?',
        r'业务宣传费[：:\s]*([\d,，.]+)\s*万?元?',
    ],
    # Depreciation
    "depreciation": [
        r'折旧[：:\s]*([\d,，.]+)\s*万?元?',
        r'累计折旧[：:\s]*([\d,，.]+)\s*万?元?',
    ],
    # Asset impairment
    "impairment": [
        r'减值准备[：:\s]*([\d,，.]+)\s*万?元?',
        r'资产减值损失[：:\s]*([\d,，.]+)\s*万?元?',
    ],
    # USCC
    "uscc": [
        r'统一社会信用代码[：:\s]*([A-Z0-9]{18})',
        r'信用代码[：:\s]*([A-Z0-9]{18})',
    ],
    # Company name
    "company_name": [
        r'([^\s,，]{2,20}(?:有限公司|股份公司|有限责任公司|合伙企业|个体工商户))',
    ],
}

TAX_RISK_PATTERNS = {
    # Tax bureau risk alerts
    "risk_alert": [
        r'风险[提示提醒预警][：:\s]*(.+)',
        r'异常[提示提醒][：:\s]*(.+)',
        r'预警指标[：:\s]*(.+)',
        r'风险等级[：:\s]*(\w+)',
    ],
    # Tax assessment
    "assessment": [
        r'纳税评估[通知函书][：:\s]*(.+)',
        r'税务事项通知书[：:\s]*(.+)',
        r'约谈[通知][：:\s]*(.+)',
    ],
    # Audit findings
    "audit": [
        r'稽查[发现结果][：:\s]*(.+)',
        r'检查[发现结果][：:\s]*(.+)',
        r'调增[：:\s]*([\d,，.]+)\s*万?元?',
        r'补税[：:\s]*([\d,，.]+)\s*万?元?',
        r'罚款[：:\s]*([\d,，.]+)\s*万?元?',
    ],
}


def parse_number(text: str) -> float:
    """Parse Chinese number format to float"""
    if not text:
        return 0.0
    text = text.replace(',', '').replace('，', '').replace(' ', '')
    try:
        val = float(text)
        # If contains '万', multiply by 10000
        return val
    except ValueError:
        return 0.0


def extract_financial_data(text: str) -> dict:
    """Extract financial data from text using patterns"""
    result = {"raw_text_length": len(text), "extracted_fields": {}, "risk_indicators": []}

    # Extract financial fields
    for field_name, patterns in FINANCIAL_PATTERNS.items():
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                if field_name not in result["extracted_fields"]:
                    result["extracted_fields"][field_name] = []
                for m in matches:
                    if isinstance(m, str):
                        val = parse_number(m)
                        if val > 0:
                            result["extracted_fields"][field_name].append(val)
                # Deduplicate
                result["extracted_fields"][field_name] = list(set(result["extracted_fields"][field_name]))

    # Extract risk indicators
    for risk_type, patterns in TAX_RISK_PATTERNS.items():
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                for m in matches:
                    if isinstance(m, str) and len(m.strip()) > 0:
                        result["risk_indicators"].append({
                            "type": risk_type,
                            "content": m.strip()[:200]  # Limit length
                        })

    return result


# ============================================================
# File parsers by type
# ============================================================

def parse_image(filepath: str) -> dict:
    """Parse image file - extract metadata and prepare for OCR"""
    result = {"file_type": "image", "path": filepath, "ocr_text": "", "metadata": {}}

    try:
        from PIL import Image
        img = Image.open(filepath)
        result["metadata"] = {
            "format": img.format,
            "size": img.size,
            "mode": img.mode,
        }
        # Extract EXIF if available
        if hasattr(img, '_getexif') and img._getexif():
            exif = img._getexif()
            result["metadata"]["has_exif"] = True
    except ImportError:
        result["metadata"]["note"] = "PIL not available, limited metadata extraction"
    except Exception as e:
        result["metadata"]["error"] = str(e)

    # For OCR: the actual text extraction is done by the AI agent
    # Here we prepare the base64 encoding for the agent to process
    try:
        with open(filepath, 'rb') as f:
            file_data = f.read()
        result["base64_preview"] = base64.b64encode(file_data[:1024]).decode('ascii')[:100] + "..."
        result["file_size"] = len(file_data)
        result["ocr_note"] = "Image requires AI agent OCR processing for text extraction"
    except Exception as e:
        result["error"] = str(e)

    return result


def parse_pdf(filepath: str) -> dict:
    """Parse PDF file - extract text content"""
    result = {"file_type": "pdf", "path": filepath, "text": "", "pages": 0}

    try:
        # Try PyPDF2 first
        import PyPDF2
        with open(filepath, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            result["pages"] = len(reader.pages)
            text_parts = []
            for page in reader.pages:
                text = page.extract_text()
                if text:
                    text_parts.append(text)
            result["text"] = "\n".join(text_parts)
    except ImportError:
        # Fallback: read raw bytes and extract printable text
        try:
            with open(filepath, 'rb') as f:
                raw = f.read()
            # Extract text between stream markers
            text_parts = re.findall(rb'stream\r?\n(.*?)\r?\nendstream', raw, re.DOTALL)
            decoded = []
            for part in text_parts:
                try:
                    decoded.append(part.decode('utf-8', errors='ignore'))
                except Exception:
                    pass
            result["text"] = "\n".join(decoded)
            result["note"] = "PyPDF2 not available, using raw text extraction (limited)"
        except Exception as e:
            result["error"] = str(e)
    except Exception as e:
        result["error"] = str(e)

    return result


def parse_excel(filepath: str) -> dict:
    """Parse Excel/CSV file - extract tabular data"""
    result = {"file_type": "excel", "path": filepath, "sheets": {}, "text": ""}

    ext = Path(filepath).suffix.lower()

    if ext == '.csv':
        try:
            import csv
            with open(filepath, 'r', encoding='utf-8-sig') as f:
                reader = csv.reader(f)
                rows = [row for row in reader]
            result["sheets"]["csv"] = {"rows": len(rows), "data": rows[:100]}  # Limit to 100 rows
            result["text"] = "\n".join([",".join(row) for row in rows[:100]])
        except Exception as e:
            result["error"] = str(e)
    else:
        try:
            import openpyxl
            wb = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                rows = []
                for row in ws.iter_rows(values_only=True):
                    rows.append([str(cell) if cell is not None else "" for cell in row])
                result["sheets"][sheet_name] = {"rows": len(rows), "data": rows[:100]}
                result["text"] += f"\n--- Sheet: {sheet_name} ---\n"
                result["text"] += "\n".join([",".join(row) for row in rows[:100]])
            wb.close()
        except ImportError:
            result["note"] = "openpyxl not available, install for Excel support"
            # Fallback to CSV conversion attempt
            try:
                import csv
                with open(filepath, 'r', encoding='utf-8-sig') as f:
                    reader = csv.reader(f)
                    rows = [row for row in reader]
                result["sheets"]["fallback"] = {"rows": len(rows), "data": rows[:50]}
                result["text"] = "\n".join([",".join(row) for row in rows[:50]])
            except Exception as e:
                result["error"] = str(e)
        except Exception as e:
            result["error"] = str(e)

    return result


def parse_json(filepath: str) -> dict:
    """Parse JSON file"""
    result = {"file_type": "json", "path": filepath, "data": None}
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        result["data"] = data
        result["text"] = json.dumps(data, ensure_ascii=False, indent=2)[:5000]
    except Exception as e:
        result["error"] = str(e)
    return result


def parse_text(filepath: str) -> dict:
    """Parse plain text file"""
    result = {"file_type": "text", "path": filepath, "text": ""}
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            result["text"] = f.read()
    except UnicodeDecodeError:
        try:
            with open(filepath, 'r', encoding='gbk') as f:
                result["text"] = f.read()
        except Exception as e:
            result["error"] = str(e)
    return result


# ============================================================
# Main parsing dispatcher
# ============================================================

PARSERS = {
    "image": parse_image,
    "pdf": parse_pdf,
    "excel": parse_excel,
    "json": parse_json,
    "text": parse_text,
}


def parse_file(filepath: str, extract_type: str = "all") -> dict:
    """Parse a single file and extract data"""
    file_info = detect_file_type(filepath)
    if file_info.get("error"):
        return file_info

    category = file_info.get("category", "unknown")
    parser = PARSERS.get(category, parse_text)
    result = parser(filepath)

    # Add file info
    result["file_info"] = file_info

    # Extract financial data from text
    text = result.get("text", "")
    if text:
        financial = extract_financial_data(text)
        result["financial_data"] = financial

    # Generate file hash for deduplication
    try:
        with open(filepath, 'rb') as f:
            result["file_hash"] = hashlib.sha256(f.read()).hexdigest()[:16]
    except Exception:
        result["file_hash"] = "unknown"

    return result


def parse_directory(dirpath: str, extract_type: str = "all") -> dict:
    """Parse all supported files in a directory"""
    results = {
        "directory": dirpath,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "files": [],
        "aggregated_financial": {},
        "aggregated_risks": [],
        "summary": {}
    }

    supported_exts = {'png', 'jpg', 'jpeg', 'bmp', 'gif', 'webp', 'pdf', 'xlsx', 'xls', 'csv', 'json', 'txt', 'md'}

    for item in Path(dirpath).iterdir():
        if item.is_file() and item.suffix.lower().lstrip('.') in supported_exts:
            log(f"[INFO] Parsing: {item.name}")
            file_result = parse_file(str(item), extract_type)
            results["files"].append(file_result)

            # Aggregate financial data
            if "financial_data" in file_result:
                for field, values in file_result["financial_data"].get("extracted_fields", {}).items():
                    if field not in results["aggregated_financial"]:
                        results["aggregated_financial"][field] = []
                    results["aggregated_financial"][field].extend(values)

                # Aggregate risk indicators
                for risk in file_result["financial_data"].get("risk_indicators", []):
                    results["aggregated_risks"].append(risk)

    # Generate summary
    results["summary"] = {
        "total_files": len(results["files"]),
        "financial_fields_found": len(results["aggregated_financial"]),
        "risk_indicators_found": len(results["aggregated_risks"]),
        "file_types": list(set(f["file_info"]["category"] for f in results["files"] if "file_info" in f)),
    }

    # Deduplicate aggregated data
    for field in results["aggregated_financial"]:
        results["aggregated_financial"][field] = list(set(results["aggregated_financial"][field]))

    return results


def generate_ocr_prompt(file_results: list) -> str:
    """Generate OCR prompts for AI agent to process images"""
    prompts = []
    for fr in file_results:
        if fr.get("file_info", {}).get("category") == "image":
            prompt = f"""[OCR Task] Image file: {fr.get('path','')}
Please extract the following from this image:
1. Document type (invoice/receipt/voucher/statement/notice/other)
2. All financial amounts with labels
3. Tax-related information (tax amounts, tax rates, tax periods)
4. Any risk alerts or warning indicators
5. Company name and USCC if visible
6. Date and reference numbers

Output as structured JSON with keys: document_type, amounts, tax_info, risk_alerts, company_info, dates"""
            prompts.append(prompt)
    return "\n\n---\n\n".join(prompts)


# ============================================================
# CLI interface
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="TaxRiskGuard File Parser")
    parser.add_argument("--input", required=True, help="Input file or directory path")
    parser.add_argument("--output", default="", help="Output JSON file path")
    parser.add_argument("--type", default="auto", choices=["auto", "financial", "risk", "all"],
                        help="Extraction type")
    parser.add_argument("--ocr-prompt", action="store_true", help="Generate OCR prompts for AI agent")

    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        log(f"[ERROR] Input path does not exist: {args.input}")
        sys.exit(1)

    # Validate path is within skill directory or temp area
    resolved = input_path.resolve()
    skill_root = SKILL_DIR.resolve()
    # Allow files in skill dir, temp dirs, or common download dirs
    allowed_prefixes = [str(skill_root), os.environ.get("TEMP", ""), os.environ.get("TMP", "")]
    if not any(str(resolved).startswith(p) for p in allowed_prefixes if p):
        log(f"[WARNING] File path outside skill directory: {args.input}")

    if input_path.is_dir():
        result = parse_directory(str(input_path), args.type)
    else:
        result = parse_file(str(input_path), args.type)

    # Add OCR prompts if requested
    if args.ocr_prompt:
        files = result.get("files", [result]) if input_path.is_dir() else [result]
        result["ocr_prompts"] = generate_ocr_prompt(files)

    # Output
    output_json = json.dumps(result, ensure_ascii=False, indent=2, default=str)

    if args.output:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(output_json)
        log(f"[OK] Result saved to: {args.output}")
    else:
        # Print summary only to stdout
        if "summary" in result:
            log(f"[INFO] Summary: {result['summary']}")
        elif "financial_data" in result:
            fields = result["financial_data"].get("extracted_fields", {})
            risks = result["financial_data"].get("risk_indicators", [])
            log(f"[INFO] Extracted fields: {list(fields.keys())}")
            log(f"[INFO] Risk indicators: {len(risks)}")
        log(f"[OK] File parsing completed")
