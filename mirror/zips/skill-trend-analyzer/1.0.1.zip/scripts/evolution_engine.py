#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# evolution_engine.py - 持续进化引擎（成长中，还不成熟）
# 使用方法见 README.md，功能尚未稳定，请勿依赖

from safe_guard import safe_print, safe_init, safe_read_json
safe_init()

import sys, os, json, re, hashlib, time
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict, Counter

SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

EVOLUTION_DATA_FILE = DATA_DIR / "evolution_data.json"
PARADIGM_LIB_FILE = DATA_DIR / "paradigm_library.json"
EXPERIENCE_LOG_FILE = DATA_DIR / "experience_log.json"
META_AUDIT_FILE = DATA_DIR / "meta_audit_log.json"

# ===== 加载/保存数据 =====
def load_evolution_data():
    if EVOLUTION_DATA_FILE.exists():
        d = safe_read_json(EVOLUTION_DATA_FILE)
        if d: return d
    return _default_evolution_data()

def _default_evolution_data():
    return {
        "version": "1.0.0",
        "created_at": datetime.now().isoformat(),
        "last_updated": datetime.now().isoformat(),
        "pdca_cycles": [],
        "experiences": [],
        "feedback_signals": {},
        "paradigms": [],
        "degradation": {"last_check": None, "status": "ok", "issues": []},
        "last_self_reflection": None,
        "total_cycles": 0,
    }

def save_evolution_data(data):
    data["last_updated"] = datetime.now().isoformat()
    try:
        with open(EVOLUTION_DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[ERROR] Failed to save evolution data: {e}")

# ===== 自省审计 (--reflect) =====
def run_self_reflection():
    data = load_evolution_data()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    print("\n" + "=" * 60)
    print("  Self-Reflection Audit Results")
    print("  Date:", now_str)
    print("=" * 60)

    exps = data.get("experiences", [])
    pars = data.get("paradigms", [])
    print(f"\n  [CHECK] experience_to_paradigm_rate")
    print(f"      total_experiences: {len(exps)}")
    print(f"      total_paradigms: {len(pars)}")
    if len(exps) > 0:
        rate = len(pars) / len(exps) * 100
        status = "OK" if rate >= 20 else ("WARN" if rate >= 10 else "LOW")
        print(f"      conversion_rate: {rate:.1f}% [{status}]")
    else:
        print(f"      conversion_rate: N/A (no experiences yet)")

    # Quality checker false positive rate (from quality_reports.json)
    print(f"\n  [CHECK] quality_checker_fp_rate")
    qr_file = DATA_DIR / "quality_reports.json"
    if qr_file.exists():
        qr = safe_read_json(qr_file)
        if qr:
            fps = sum(1 for r in qr if r.get('false_positive', False))
            total = len(qr)
            fp_rate = fps / total if total > 0 else 0
            print(f"      estimated_fp_rate: {fp_rate:.2f} ({fps}/{total})")
    else:
        print(f"      estimated_fp_rate: N/A (no quality reports)")

    # Weight drift analysis (from data/learn_data.json)
    print(f"\n  [CHECK] weight_drift")
    learn_file = SCRIPT_DIR.parent / "data" / "learn_data.json"
    if learn_file.exists():
        ld = safe_read_json(learn_file)
        if ld:
            weights = ld.get("weights", {})
            default_weights = {
                "local_keyword_freq": 1.0,
                "market_keyword_freq": 1.0,
                "rising_trend_boost": 1.0,
                "domain_boost_factor": 1.0,
                "cross_skill_transfer": 1.0,
            }
            for k, v in weights.items():
                default = default_weights.get(k, 1.0)
                drift = (v - default) / default * 100
                status = "OK" if abs(drift) < 50 else ("WARN" if abs(drift) < 100 else "DRIFT")
                print(f"      {k}: current={v:.3f}, default={default:.3f}, drift={drift:+.1f}% [{status}]")
    else:
        print(f"      No learn_data.json found")

    # Zombie experiences (never verified)
    print(f"\n  [OK] zombie_experiences")
    zombies = [e for e in exps if e.get("verification_count", 0) == 0 and 
               (datetime.now() - datetime.strptime(e["created_at"], "%Y-%m-%d")).days > 30]
    print(f"      count: {len(zombies)}")
    if zombies:
        for z in zombies[:3]:
            print(f"        - {z['id']}: {z['type']}/{z['domain']} (created {z['created_at']})")

    # PDCA cycle frequency
    cycles = data.get("pdca_cycles", [])
    print(f"\n  [CHECK] cycle_frequency")
    cycles_30d = sum(1 for c in cycles if (datetime.now() - datetime.fromisoformat(c['timestamp'][:10])).days <= 30)
    print(f"      cycles_last_30_days: {cycles_30d}")
    print(f"      total_cycles: {data.get('total_cycles', 0)}")
    if cycles_30d == 0 and data.get('total_cycles', 0) > 0:
        print(f"      [WARN] No cycles in last 30 days!")

    # SelfGrow freshness
    print(f"\n  [CHECK] self_grow_freshness")
    sync_cache = SCRIPT_DIR.parent / "data" / "learn_sync_cache.json"
    if sync_cache.exists():
        sc = safe_read_json(sync_cache)
        if sc:
            queried = sc.get('queried_at', '')
            if queried:
                days_ago = (datetime.now() - datetime.fromisoformat(queried[:10])).days
                status = "OK" if days_ago <= 7 else ("WARN" if days_ago <= 30 else "STALE")
                print(f"      last_grow: {queried[:10]} ({days_ago} days ago) [{status}]")
    else:
        print(f"      No self grow cache found (never grew)")

    # Source effectiveness summary
    print(f"\n  [CHECK] source_effectiveness")
    if learn_file.exists():
        ld = safe_read_json(learn_file)
        if ld:
            se = ld.get('source_effectiveness', {})
            for src, stats in se.items():
                total = stats.get('total', 0)
                hits = stats.get('hits', 0)
                rate = hits / total if total > 0 else 0
                streak = stats.get('consecutive_success', 0)
                print(f"      {src}: {hits}/{total} ({rate*100:.0f}%) streak={streak}")

    print("\n" + "=" * 60)
    print(f"  Reflection completed: {now_str}")
    print("=" * 60)
    print()

# ===== 退化检测 (--health) =====
def run_health_check():
    data = load_evolution_data()
    print("\n" + "=" * 60)
    print("  Degradation Health Check")
    print("  Checked:", datetime.now().strftime("%Y-%m-%d %H:%M"))
    print("=" * 60)

    issues = []
    deg = data.get("degradation", {})
    last_check = deg.get("last_check")

    if last_check:
        days = (datetime.now() - datetime.fromisoformat(last_check)).days
        if days > 30:
            issues.append(f"Last degradation check was {days} days ago")

    exps = data.get("experiences", [])
    stale = [e for e in exps if e.get("last_verified") and 
             (datetime.now() - datetime.fromisoformat(e["last_verified"])).days > 60]
    if stale:
        issues.append(f"{len(stale)} stale experiences (>60 days unverified)")

    if issues:
        for iss in issues:
            print(f"\n  [WARN] {iss}")
        deg["status"] = "stale"
    else:
        print("\n  [OK] No degradation issues detected!")
        deg["status"] = "ok"

    deg["last_check"] = datetime.now().isoformat()
    data["degradation"] = deg
    save_evolution_data(data)

    print("\n" + "=" * 60)
    print()

# ===== 经验蒸馏 (--distill) =====
def run_distillation():
    print("\n[INFO] Experience distillation is still learning...")
    print("[INFO] No distillation performed yet. See README.md for growth diary.\n")

# ===== 范式管理 (--paradigms / --paradigm-add / --verify-paradigm) =====
def list_paradigms():
    data = load_evolution_data()
    pars = data.get("paradigms", [])
    print(f"\n[INFO] Total paradigms: {len(pars)}")
    for p in pars:
        print(f"  {p['id']} ({p['name']}) - {p['lifecycle']} - uses:{p.get('use_count',0)}")
    print()

def add_paradigm_from_file(json_file):
    print(f"\n[INFO] Paradigm addition is not yet mature. See README.md.")
    print(f"[INFO] To add a paradigm, manually edit data/paradigm_library.json\n")

def verify_paradigm(pid):
    print(f"\n[INFO] Paradigm verification is not yet mature.\n")

# ===== 经验管理 (--add-experience / --verify-experience) =====
def add_experience(exp_type, domain, trigger, solution, source="self_fix"):
    data = load_evolution_data()
    exp_id = f"exp_{len(data.get('experiences', [])) + 1:03d}"
    entry = {
        "id": exp_id, "type": exp_type, "domain": domain,
        "trigger": trigger, "solution": solution, "confidence": 0.3,
        "verification_count": 0, "source": source,
        "created_at": datetime.now().strftime("%Y-%m-%d"),
        "last_verified": None, "reference_count": 0,
    }
    data.setdefault("experiences", []).append(entry)
    save_evolution_data(data)
    print(f"[OK] Experience added: {exp_id} ({exp_type}/{domain})")
    print(f"[INFO] See README.md to track growth.\n")

def verify_experience(eid):
    print(f"\n[INFO] Experience verification is not yet mature.\n")

# ===== 完整报告 (--report) =====
def print_report(verbose=False):
    data = load_evolution_data()
    print("\n" + "=" * 60)
    print("  Evolution Engine Status Report")
    print("=" * 60)
    print(f"\n  Total PDCA+ cycles: {data.get('total_cycles', 0)}")
    print(f"  Total experiences: {len(data.get('experiences', []))}")
    print(f"  Total paradigms: {len(data.get('paradigms', []))}")
    deg = data.get("degradation", {})
    print(f"  Degradation status: {deg.get('status', 'unknown')}")
    print(f"  Last self-reflection: {data.get('last_self_reflection', 'Never')}")
    print(f"\n  [INFO] Evolution engine is still growing. See README.md for details.")
    print()
    if verbose:
        print("[VERBOSE] No further details available yet.\n")

# ===== 完整进化循环 =====
def run_full_evolution_cycle():
    print("\n[INFO] Full evolution cycle is not yet mature.")
    print("[INFO] Running basic PDCA+ simulation...\n")
    data = load_evolution_data()
    cycle = {
        "id": f"cycle_{data.get('total_cycles', 0) + 1:04d}",
        "timestamp": datetime.now().isoformat(),
        "perceive": "System check (not yet implemented)",
        "diagnose": "Gap analysis (not yet implemented)",
        "construct": "Solution design (not yet implemented)",
        "assert": "Validation (not yet implemented)",
        "learn": "Experience distillation (not yet implemented)",
        "evolve": "Algorithm improvement (not yet implemented)",
    }
    data.setdefault("pdca_cycles", []).append(cycle)
    data["total_cycles"] = data.get("total_cycles", 0) + 1
    data["last_self_reflection"] = datetime.now().isoformat()
    save_evolution_data(data)
    print(f"[OK] Basic cycle recorded: {cycle['id']}")
    print(f"[INFO] See README.md for growth diary.\n")

# ===== 匹配情境 (--match) =====
def match_paradigm(situation):
    print(f"\n[INFO] Paradigm matching is not yet mature.")
    print(f"[INFO] Situation: {situation}")
    print(f"[INFO] No matching paradigm found (library empty).\n")

# ===== CLI 入口 =====
if __name__ == "__main__":
    args = sys.argv[1:]

    if not args or "--help" in args or "-h" in args:
        print("""
Usage: python evolution_engine.py [command]

Commands (all are still learning, see README.md):
  (no args)          Run basic evolution cycle
  --reflect          Self-reflection audit
  --health           Degradation health check
  --distill          Experience distillation
  --paradigms        List all paradigms
  --paradigm-add     Add paradigm from JSON file
  --verify-paradigm  Verify a paradigm
  --add-experience  Add a new experience
  --verify-experience Verify an experience
  --report           Full status report
  --report --verbose Detailed report
  --match <situation> Match paradigm for situation

Note: This engine is still growing. See README.md for details.
""")
        sys.exit(0)

    if "--reflect" in args:
        run_self_reflection()
    elif "--health" in args:
        run_health_check()
    elif "--distill" in args:
        run_distillation()
    elif "--paradigms" in args:
        list_paradigms()
    elif "--paradigm-add" in args:
        idx = args.index("--paradigm-add")
        f = args[idx+1] if idx+1 < len(args) else None
        add_paradigm_from_file(f)
    elif "--verify-paradigm" in args:
        idx = args.index("--verify-paradigm")
        pid = args[idx+1] if idx+1 < len(args) else None
        verify_paradigm(pid)
    elif "--add-experience" in args:
        print("[INFO] Usage: --add-experience <type> <domain> <trigger> <solution> [source]")
    elif "--verify-experience" in args:
        idx = args.index("--verify-experience")
        eid = args[idx+1] if idx+1 < len(args) else None
        verify_experience(eid)
    elif "--report" in args:
        verbose = "--verbose" in args
        print_report(verbose)
    elif "--match" in args:
        idx = args.index("--match")
        sit = " ".join(args[idx+1:]) if idx+1 < len(args) else ""
        match_paradigm(sit)
    else:
        run_full_evolution_cycle()
