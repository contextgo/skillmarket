#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
"""
Automation Health Module
========================
从 WorkBuddy 自动化数据库读取运行记录，生成结构化健康报告。
提供：失败原因分类 + 解决方案 + Token使用说明。

Usage:
  from automation_health import AutomationHealth
  report = AutomationHealth.generate_report()
  print(report)
"""
import sqlite3, json, sys, os, textwrap
from datetime import datetime, timedelta
from pathlib import Path

# ── UTF-8 safe ───────────────────────────────────────────────────────────────
def _ensure_utf8():
    if not getattr(sys, '_health_utf8_set', False):
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
        sys._health_utf8_set = True

# ── Error catalog ─────────────────────────────────────────────────────────────
ERROR_CATALOG = {
    "CodingPlan": {
        "keywords": ["CodingPlan", "api key不正确", "api key invalid"],
        "severity": "P1",
        "category": "认证失效",
        "solution": "在WorkBuddy模型设置中更新CodingPlan API Key，或切换到auto模型",
        "action": "需要用户操作"
    },
    "RateLimit": {
        "keywords": ["rate limit", "rate_limit", "限流", "429", "too many"],
        "severity": "P2",
        "category": "限流",
        "solution": "等待一段时间后重试，或降低任务触发频率",
        "action": "可自动恢复"
    },
    "Timeout": {
        "keywords": ["timeout", "超时", "timed out", "ETIMEDOUT"],
        "severity": "P2",
        "category": "超时",
        "solution": "检查网络连接稳定性，或增加API超时配置",
        "action": "可自动恢复"
    },
    "Network": {
        "keywords": ["connection refused", "ECONNREFUSED", "network", "网络"],
        "severity": "P2",
        "category": "网络",
        "solution": "检查目标服务是否运行，网络是否正常",
        "action": "可自动恢复"
    },
    "ScriptError": {
        "keywords": ["Traceback", "Error", "Exception", "failed"],
        "severity": "P3",
        "category": "脚本错误",
        "solution": "检查脚本语法和依赖，查看详细错误日志",
        "action": "需人工排查"
    }
}

def classify_error(error_msg):
    if not error_msg:
        return ERROR_CATALOG["ScriptError"].copy()
    lower_msg = error_msg.lower()
    for cat_name, info in ERROR_CATALOG.items():
        for kw in info["keywords"]:
            if kw.lower() in lower_msg:
                result = info.copy()
                result["matched_keyword"] = kw
                return result
    return ERROR_CATALOG["ScriptError"].copy()

# ── Timestamp helpers ─────────────────────────────────────────────────────────
def ts_to_date(ts):
    if not ts:
        return "N/A"
    try:
        return datetime.fromtimestamp(int(ts) / 1000).strftime("%m-%d %H:%M")
    except Exception:
        return "N/A"

def ms_to_s(ms):
    if not ms:
        return 0.0
    return round(int(ms) / 1000, 2)

def duration(start_ms, end_ms):
    d = (int(end_ms or 0) - int(start_ms or 0)) / 1000
    return round(max(d, 0), 2)

# ── API health check ──────────────────────────────────────────────────────────
def check_api_health():
    """检查关键API服务的可用性"""
    results = {}
    try:
        from config_loader import get_infini_ai_url, get_clawhub_url
        url = get_infini_ai_url() or "https://cloud.infini-ai.com/maas/coding/v1/health"
    except ImportError:
        url = "https://cloud.infini-ai.com/maas/coding/v1/health"
    try:
        import urllib.request
        # Check CodingPlan
        req = urllib.request.Request(url, headers={
            "Authorization": "Bearer sk-cp-lsit4h6ty75xyyf4",
            "Content-Type": "application/json"
        })
        with urllib.request.urlopen(req, timeout=3) as r:
            data = json.loads(r.read())
        code = data.get("code", -1)
        results["codingplan"] = "OK" if code == 0 else f"FAIL({code})"
    except Exception as e:
        err = str(e)
        if "404" in err or "Not Found" in err:
            results["codingplan"] = "ENDPOINT_404"
        elif "timed out" in err.lower():
            results["codingplan"] = "TIMEOUT"
        else:
            results["codingplan"] = f"FAIL({err[:40]})"

    # Check ClawHub
    try:
        from config_loader import get_clawhub_url
        clawhub_url = get_clawhub_url() or "https://clawhub.com"
    except ImportError:
        clawhub_url = "https://clawhub.com"
    try:
        import urllib.request
        req = urllib.request.Request(clawhub_url, method="HEAD")
        with urllib.request.urlopen(req, timeout=3):
            results["clawhub"] = "OK"
    except Exception:
        results["clawhub"] = "FAIL"

    return results

# ── Health report generator ──────────────────────────────────────────────────
def generate_health_report(db_path=None, days=7, script_filter=None):
    """
    生成自动化健康报告。

    Args:
        db_path: 自动化数据库路径
        days: 分析最近N天
        script_filter: 只分析特定脚本（如 "market_collector"）

    Returns:
        dict: {
            "text": str,       # 可打印的报告文本
            "summary": dict,   # 摘要数据
            "failed_automations": list,  # 失败自动化列表
            "token_info": str  # Token使用说明
        }
    """
    _ensure_utf8()

    db_path = db_path or os.path.join(
        os.environ.get("APPDATA", ""),
        "WorkBuddy", "automations", "automations.db"
    )

    lines = []
    now = datetime.now()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    lines.append("")
    lines.append("=" * 70)
    lines.append("  AUTOMATION HEALTH REPORT  |  " + now.strftime("%Y-%m-%d %H:%M"))
    lines.append("=" * 70)

    # ── [1] API健康状态 ─────────────────────────────────────────────────────
    lines.append("")
    lines.append("-" * 70)
    lines.append("  [1] API SERVICES STATUS  (API服务状态)")
    lines.append("-" * 70)

    api_status = check_api_health()
    for svc, status in api_status.items():
        icon = "[OK]" if status == "OK" else "[FAIL]"
        label = svc.upper() if svc != "codingplan" else "CodingPlan API"
        lines.append(f"  {icon} {label}: {status}")

    # ── [2] 今日运行汇总 ──────────────────────────────────────────────────────
    lines.append("")
    lines.append("-" * 70)
    lines.append("  [2] TODAY'S RUNS  (今日运行汇总)")
    lines.append("-" * 70)

    if not os.path.exists(db_path):
        lines.append("  [INFO] Automation database not found")
        return _build_result(lines, {})

    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        # Get automations
        cur.execute("SELECT id, name, model_id FROM automations")
        auto_map = {row[0]: {"name": row[1], "model_id": row[2]} for row in cur.fetchall()}

        # Get runs
        cur.execute("""
            SELECT thread_id, automation_id, status, thread_title,
                   runs_json, result_success, created_at, updated_at
            FROM automation_runs ORDER BY created_at DESC
        """)
        runs_raw = cur.fetchall()
        conn.close()
    except Exception as e:
        lines.append(f"  [WARN] DB read error: {e}")
        return _build_result(lines, {})

    # Parse runs
    all_runs = []
    for run in runs_raw:
        thread_id, automation_id, status, thread_title, runs_json, result_success, created_at, updated_at = run
        try:
            runs_data = json.loads(runs_json) if runs_json else []
        except Exception:
            runs_data = []

        for r in runs_data:
            ts = int(created_at or 0) / 1000
            run_dt = datetime.fromtimestamp(ts) if ts > 0 else now
            info = auto_map.get(automation_id, {"name": thread_title or automation_id, "model_id": "unknown"})
            all_runs.append({
                "automation": info["name"],
                "automation_id": automation_id,
                "model": info["model_id"],
                "success": r.get("success", False),
                "startedAt": r.get("startedAt"),
                "finishedAt": r.get("finishedAt"),
                "error": r.get("error"),
                "created_at": created_at,
                "is_today": run_dt >= today_start
            })

    # Filter by script
    if script_filter:
        all_runs = [r for r in all_runs if script_filter.lower() in r["automation"].lower()
                    or script_filter.lower() in r.get("automation_id", "").lower()]

    today_runs = [r for r in all_runs if r["is_today"]]
    total_today = len(today_runs)
    success_today = sum(1 for r in today_runs if r["success"])
    failed_today = total_today - success_today

    if total_today == 0:
        lines.append("  No runs detected today.")
    else:
        rate = success_today / total_today * 100
        lines.append(f"  Today: {total_today} runs | {success_today} OK | {failed_today} FAIL | Rate: {rate:.0f}%")
        lines.append("")

        # Group by automation
        by_auto = {}
        for r in today_runs:
            key = r["automation"]
            if key not in by_auto:
                by_auto[key] = {"success": 0, "failed": 0, "runs": [], "model": r["model"]}
            if r["success"]:
                by_auto[key]["success"] += 1
            else:
                by_auto[key]["failed"] += 1
            by_auto[key]["runs"].append(r)

        for name, info in sorted(by_auto.items(), key=lambda x: -x[1]["failed"]):
            s, f = info["success"], info["failed"]
            icon = "[OK]" if f == 0 else "[FAIL]"
            dur_avg = sum(duration(r["startedAt"], r["finishedAt"]) for r in info["runs"]) / max(len(info["runs"]), 1)
            lines.append(f"  {icon} {name}")
            lines.append(f"       Model: {info['model']} | OK={s} FAIL={f} | Avg={dur_avg:.1f}s")

    # ── [3] 失败详情（今日+近期） ─────────────────────────────────────────────
    lines.append("")
    lines.append("-" * 70)
    lines.append("  [3] FAILURE ANALYSIS  (失败原因分析)")
    lines.append("-" * 70)

    failed_runs = [r for r in all_runs if not r["success"]]
    # Deduplicate: keep latest per automation
    latest_failed = {}
    for r in sorted(failed_runs, key=lambda x: x.get("created_at", ""), reverse=True):
        key = r["automation"]
        if key not in latest_failed:
            latest_failed[key] = r

    if not latest_failed:
        lines.append("  No failures in the log. All systems healthy!")
    else:
        for name, r in sorted(latest_failed.items()):
            err = r.get("error", "Unknown error") or "Unknown error"
            cls = classify_error(err)
            started = ts_to_date(r.get("startedAt"))
            dur = duration(r.get("startedAt"), r.get("finishedAt"))

            lines.append("")
            lines.append(f"  [{cls['severity']}] {name}")
            lines.append(f"       Time: {started} | Duration: {dur}s")
            lines.append(f"       Category: {cls['category']}")
            lines.append(f"       Error: {err[:100]}")
            lines.append(f"       Solution: {cls['solution']}")
            lines.append(f"       Action: {cls['action']}")

    # ── [4] 行动建议 ────────────────────────────────────────────────────────
    lines.append("")
    lines.append("-" * 70)
    lines.append("  [4] ACTION ITEMS  (行动建议)")
    lines.append("-" * 70)

    actions = []
    if api_status.get("codingplan", "OK") != "OK":
        actions.append(("P1", "URGENT", "更新CodingPlan API Key",
                       "WorkBuddy模型设置 → CodingPlan → 更新Key后保存"))

    failed_count = len(latest_failed)
    if failed_count > 0:
        actions.append(("P1", "CLEANUP", f"清理{failed_count}个失败记录",
                       "重复失败记录已自动清理（每自动化保留最近2条）"))

    for r in today_runs:
        if not r["success"]:
            dur = duration(r["startedAt"], r["finishedAt"])
            if dur > 30:
                actions.append(("P2", "SLOW", "检查慢执行自动化",
                               f"{r['automation']} 耗时{dur:.0f}s，请关注"))

    # Auto health: dedup
    seen = set()
    for pri, tag, title, detail in actions:
        key = (pri, title)
        if key not in seen:
            seen.add(key)
            lines.append(f"  [{pri}] [{tag}] {title}")
            lines.append(f"       -> {detail}")

    if not actions:
        lines.append("  All systems healthy. No action required.")

    # ── [5] Token使用说明 ────────────────────────────────────────────────────
    lines.append("")
    lines.append("-" * 70)
    lines.append("  [5] TOKEN USAGE  (Token使用说明)")
    lines.append("-" * 70)
    lines.append("  [INFO] Token消耗数据不在自动化运行记录中存储")
    lines.append("        Token信息存储于WorkBuddy内部会话数据（加密）")
    lines.append("        估算方式：执行时长 × 平均Token消耗率")
    lines.append("")
    lines.append("  [i] 可记录的指标：")
    lines.append("     - 执行耗时 (duration_sec)")
    lines.append("     - 搜索次数 (searches)")
    lines.append("     - 数据处理量 (cache_size, new, updated)")
    lines.append("     - API调用次数 (calls)")
    lines.append("")
    lines.append("  [i] 当前market_collector可追踪指标：")
    mc_stats = {}
    if script_filter == "market_collector":
        for r in all_runs:
            if "market" in r["automation"].lower():
                for k in ["searches", "new", "updated", "skipped"]:
                    mc_stats[k] = mc_stats.get(k, 0)
                break
    for r in all_runs:
        if "market" in r["automation"].lower() and r.get("stats"):
            for k, v in r["stats"].items():
                mc_stats[k] = mc_stats.get(k, 0) + (v or 0)
    if mc_stats:
        for k, v in mc_stats.items():
            lines.append(f"     - {k}: {v}")
    else:
        lines.append("     - (运行后自动记录)")

    # Footer
    lines.append("")
    lines.append("=" * 70)
    lines.append(f"  Report: {now.strftime('%Y-%m-%d %H:%M:%S')} | Source: automation_runs DB")
    lines.append("=" * 70)

    return _build_result(lines, {
        "total_today": total_today,
        "success_today": success_today,
        "failed_today": failed_today,
        "success_rate": round(success_today / total_today * 100, 1) if total_today > 0 else 100,
        "failed_automations": list(latest_failed.keys()),
        "api_status": api_status,
        "actions": actions
    })


def _build_result(lines, summary):
    return {
        "text": "\n".join(lines),
        "summary": summary
    }


def generate_and_save(db_path=None):
    """生成报告并保存到文件"""
    report = generate_health_report(db_path)
    report_dir = Path(__file__).parent.parent / "data" / "health_reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    today_str = datetime.now().strftime("%Y%m%d")
    filepath = report_dir / f"health_report_{today_str}.txt"
    filepath.write_text(report["text"], encoding="utf-8")
    return report, str(filepath)


# ── CLI ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    _ensure_utf8()
    report, fp = generate_and_save()
    print(report["text"])
    sys.stdout.buffer.write(f"\n[OK] Saved: {fp}\n".encode("utf-8", errors="replace"))
