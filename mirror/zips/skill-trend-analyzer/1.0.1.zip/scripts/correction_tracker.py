# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# -*- coding: utf-8 -*-
"""
User Correction Tracker v1.0
=============================
用户修正自动记录器 - 借鉴 self-improving-agent 的核心理念

Features:
  - 自动识别用户修正 (Corrections)
  - 自动收集特性请求 (Feature Requests)
  - 自动发现知识缺口 (Knowledge Gaps)
  - 生成改进建议报告
  - 与 ValueDrivenEvolution 集成

Author: WorkBuddy AI | Inspired by self-improving-agent
"""
import sys
import os
import json
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum

# ============================================================
# Patterns & Configuration
# ============================================================

class CorrectionType(Enum):
    """修正类型"""
    CORRECTION = "correction"           # 用户修正AI错误
    FEATURE_REQUEST = "feature_request"  # 用户请求新功能
    KNOWLEDGE_GAP = "knowledge_gap"     # 用户补充AI不知道的知识
    WORKAROUND = "workaround"           # 用户提供替代方案
    STYLE_FEEDBACK = "style_feedback"   # 风格/表达反馈


@dataclass
class Correction:
    """修正记录"""
    correction_id: str
    correction_type: str
    original_content: str       # AI原始回答/行为
    corrected_content: str      # 用户修正内容
    context: str               # 上下文
    skill: str = ""            # 关联的skill
    pattern: str = ""          # 匹配到的模式
    timestamp: str = ""        # 发现时间
    adopted: bool = False      # 是否已被采纳
    tags: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)


class CorrectionPatterns:
    """修正识别模式"""
    
    # 用户修正AI错误的模式
    CORRECTION_PATTERNS = [
        # 中文修正
        r"不是[的得地]",
        r"应该是",
        r"应该是?[的得地]",
        r"不对",
        r"错了",
        r"错了[,，]",
        r"不是这样",
        r"应该是([^。，,]+)",
        r"不应该是",
        r"错了[,，]应该",
        r"实际上?是",
        r"事实上",
        # 英文修正
        r"No[,，]?\s*(that'?s?\s*)?(not|wrong|incorrect)",
        r"That'?s?\s*(not|wrong|incorrect)",
        r"It should be",
        r"The correct (way|answer|approach)",
    ]
    
    # 特性请求模式
    FEATURE_REQUEST_PATTERNS = [
        # 中文请求
        r"能不能",
        r"能否",
        r"可以[^做帮]",
        r"我希望",
        r"要是能",
        r"要是可以",
        r"要是能",
        r"能加个",
        r"加个功能",
        r"加个?([^功能])",
        r"帮我自动",
        r"帮我([^做干]+)",
        r"我想(要)?",
        r"我需要",
        r"加个?([^功]*)功能",
        # 英文请求
        r"Can you (also|add|create|make)",
        r"I wish (you|I could)",
        r"Is there a way (to|for)",
        r"Why can'?t you",
        r"Please (add|implement|support)",
        r"It would be (nice|great|helpful)",
    ]
    
    # 知识缺口模式
    KNOWLEDGE_GAP_PATTERNS = [
        # 中文
        r"其实([^你]+)",
        r"实际上([^你]+)",
        r"顺便说一下",
        r"补充一下",
        r"补充([^：:]+)",
        r"另外",
        r"还有",
        r"你不知道的是",
        r"这个([^不]+)不知道",
        r"根据([^，,]+)",
        r"最新的([^是]+)",
        # 英文
        r"You (may|do) n'?t know (that|this)",
        r"Actually[,，]?",
        r"Let me (add|clarify|补充)",
        r"For your information",
    ]


# ============================================================
# Core Tracker
# ============================================================

class CorrectionTracker:
    """
    用户修正追踪器
    自动识别、记录、分类用户对AI的修正
    """
    
    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = data_dir or Path(__file__).parent.parent / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.corrections: List[Correction] = []
        self.pattern_stats: Dict[str, int] = {
            "correction": 0,
            "feature_request": 0,
            "knowledge_gap": 0,
            "workaround": 0,
            "style_feedback": 0,
        }
        
        # 编译正则表达式
        self._compile_patterns()
        
        # 加载历史数据
        self._load_history()
    
    def _compile_patterns(self):
        """编译正则表达式"""
        self.correction_regexes = [
            re.compile(p, re.IGNORECASE) for p in CorrectionPatterns.CORRECTION_PATTERNS
        ]
        self.feature_request_regexes = [
            re.compile(p, re.IGNORECASE) for p in CorrectionPatterns.FEATURE_REQUEST_PATTERNS
        ]
        self.knowledge_gap_regexes = [
            re.compile(p, re.IGNORECASE) for p in CorrectionPatterns.KNOWLEDGE_GAP_PATTERNS
        ]
    
    def _load_history(self):
        """加载历史修正记录"""
        history_file = self.data_dir / "correction_history.json"
        if history_file.exists():
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for cdata in data.get("corrections", []):
                        correction = Correction(**cdata)
                        self.corrections.append(correction)
                        self.pattern_stats[correction.correction_type] += 1
            except Exception:
                pass
    
    def _save_history(self):
        """保存历史记录"""
        history_file = self.data_dir / "correction_history.json"
        data = {
            "last_updated": datetime.now().isoformat(),
            "total": len(self.corrections),
            "corrections": [
                {**vars(c), "metadata": c.metadata}
                for c in self.corrections[-100:]  # 保存最近100条
            ]
        }
        try:
            with open(history_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    
    def _generate_id(self, content: str) -> str:
        """生成修正ID"""
        import hashlib
        return hashlib.md5(content[:100].encode()).hexdigest()[:8]
    
    def detect(self, user_message: str, ai_response: str = "", context: str = "") -> Optional[Correction]:
        """
        检测用户消息中的修正意图
        
        Returns:
            Correction对象或None
        """
        timestamp = datetime.now().isoformat()
        
        # 1. 检测修正类
        for regex in self.correction_regexes:
            match = regex.search(user_message)
            if match:
                return self._create_correction(
                    correction_type=CorrectionType.CORRECTION,
                    user_message=user_message,
                    ai_response=ai_response,
                    context=context,
                    pattern=regex.pattern,
                    timestamp=timestamp
                )
        
        # 2. 检测特性请求
        for regex in self.feature_request_regexes:
            match = regex.search(user_message)
            if match:
                return self._create_correction(
                    correction_type=CorrectionType.FEATURE_REQUEST,
                    user_message=user_message,
                    ai_response=ai_response,
                    context=context,
                    pattern=regex.pattern,
                    timestamp=timestamp
                )
        
        # 3. 检测知识缺口
        for regex in self.knowledge_gap_regexes:
            match = regex.search(user_message)
            if match:
                return self._create_correction(
                    correction_type=CorrectionType.KNOWLEDGE_GAP,
                    user_message=user_message,
                    ai_response=ai_response,
                    context=context,
                    pattern=regex.pattern,
                    timestamp=timestamp
                )
        
        return None
    
    def _create_correction(
        self,
        correction_type: CorrectionType,
        user_message: str,
        ai_response: str,
        context: str,
        pattern: str,
        timestamp: str
    ) -> Correction:
        """创建修正记录"""
        return Correction(
            correction_id=self._generate_id(user_message + timestamp),
            correction_type=correction_type.value,
            original_content=ai_response,
            corrected_content=user_message,
            context=context,
            pattern=pattern,
            timestamp=timestamp
        )
    
    def record(self, correction: Correction) -> bool:
        """记录修正"""
        # 检查是否重复
        for existing in self.corrections:
            if existing.correction_id == correction.correction_id:
                return False
        
        self.corrections.append(correction)
        self.pattern_stats[correction.correction_type] += 1
        self._save_history()
        return True
    
    def record_from_message(
        self,
        user_message: str,
        ai_response: str = "",
        context: str = "",
        skill: str = ""
    ) -> Optional[Correction]:
        """从消息自动检测并记录"""
        correction = self.detect(user_message, ai_response, context)
        if correction:
            correction.skill = skill
            self.record(correction)
            return correction
        return None
    
    def get_corrections(
        self,
        correction_type: Optional[str] = None,
        skill: Optional[str] = None,
        limit: int = 50
    ) -> List[Correction]:
        """获取修正记录"""
        results = self.corrections
        
        if correction_type:
            results = [c for c in results if c.correction_type == correction_type]
        
        if skill:
            results = [c for c in results if c.skill == skill]
        
        return results[-limit:]
    
    def generate_improvements(self, top_n: int = 10) -> List[Dict[str, Any]]:
        """生成改进建议"""
        improvements = []
        
        # 按类型统计
        for ctype, count in self.pattern_stats.items():
            if count == 0:
                continue
            
            corrections = [c for c in self.corrections if c.correction_type == ctype]
            recent = corrections[-5:]  # 最近5条
            
            improvement = {
                "type": ctype,
                "count": count,
                "description": self._get_type_description(ctype),
                "recent_examples": [c.corrected_content[:100] for c in recent],
                "suggestions": self._generate_suggestions(ctype, corrections),
                "adoption_priority": self._calculate_priority(ctype, count)
            }
            improvements.append(improvement)
        
        # 按优先级排序
        improvements.sort(key=lambda x: x["adoption_priority"], reverse=True)
        
        return improvements[:top_n]
    
    def _get_type_description(self, ctype: str) -> str:
        """获取类型描述"""
        descriptions = {
            "correction": "用户纠正了AI的错误",
            "feature_request": "用户请求新功能",
            "knowledge_gap": "用户补充了AI的知识缺口",
            "workaround": "用户提供了替代方案",
            "style_feedback": "用户对表达风格提出反馈"
        }
        return descriptions.get(ctype, ctype)
    
    def _generate_suggestions(self, ctype: str, corrections: List[Correction]) -> List[str]:
        """生成改进建议"""
        suggestions = []
        
        if ctype == "correction":
            # 分析修正模式
            patterns = [c.pattern for c in corrections]
            if any("不是" in p for p in patterns):
                suggestions.append("考虑添加否定表达检测，减少误判")
            if any("应该是" in p for p in patterns):
                suggestions.append("添加正向表达模式识别")
        
        elif ctype == "feature_request":
            # 提取请求特征
            common_words = self._extract_keywords(
                " ".join(c.corrected_content for c in corrections)
            )
            if common_words:
                suggestions.append(f"建议添加相关能力: {', '.join(common_words[:5])}")
        
        elif ctype == "knowledge_gap":
            suggestions.append("建议更新知识库或添加外部搜索能力")
        
        return suggestions
    
    def _extract_keywords(self, text: str, top_n: int = 5) -> List[str]:
        """提取关键词"""
        # 简单的关键词提取
        words = re.findall(r'[\u4e00-\u9fa5]{2,}', text)
        word_freq = {}
        for word in words:
            if len(word) >= 2:
                word_freq[word] = word_freq.get(word, 0) + 1
        
        sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        return [w[0] for w in sorted_words[:top_n]]
    
    def _calculate_priority(self, ctype: str, count: int) -> float:
        """计算采纳优先级"""
        # 基础分数
        base_scores = {
            "correction": 1.0,        # 错误必须修复
            "feature_request": 0.8,   # 功能请求重要
            "knowledge_gap": 0.9,    # 知识缺口高优
            "workaround": 0.6,       # 替代方案次之
            "style_feedback": 0.3    # 风格反馈低优
        }
        
        # 频率加成
        frequency_bonus = min(count / 20, 0.5)
        
        return base_scores.get(ctype, 0.5) + frequency_bonus
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            "total": len(self.corrections),
            "by_type": dict(self.pattern_stats),
            "recent_count": len([c for c in self.corrections 
                                if datetime.fromisoformat(c.timestamp) > 
                                datetime.now().replace(hour=0, minute=0, second=0)]),
            "adopted_count": len([c for c in self.corrections if c.adopted]),
            "top_skills": self._get_top_skills()
        }
    
    def _get_top_skills(self, top_n: int = 5) -> List[Tuple[str, int]]:
        """获取修正最多的skill"""
        skill_counts = {}
        for c in self.corrections:
            if c.skill:
                skill_counts[c.skill] = skill_counts.get(c.skill, 0) + 1
        
        return sorted(skill_counts.items(), key=lambda x: x[1], reverse=True)[:top_n]
    
    def export_report(self) -> str:
        """导出报告"""
        improvements = self.generate_improvements()
        stats = self.get_stats()
        
        lines = [
            "=" * 60,
            "  User Correction Analysis Report",
            "=" * 60,
            f"\n统计概览:",
            f"  总修正数: {stats['total']}",
            f"  今日新增: {stats['recent_count']}",
            f"  已采纳数: {stats['adopted_count']}",
            f"\n按类型分布:",
        ]
        
        for ctype, count in stats["by_type"].items():
            bar = "=" * min(count, 20)
            lines.append(f"  {ctype:20s}: {count:3d} {bar}")
        
        lines.append("\n优先改进建议:")
        for i, imp in enumerate(improvements, 1):
            lines.append(f"\n  {i}. [{imp['type']}] (优先级: {imp['adoption_priority']:.2f})")
            lines.append(f"     {imp['description']}")
            for suggestion in imp['suggestions'][:2]:
                lines.append(f"     - {suggestion}")
        
        return "\n".join(lines)


# ============================================================
# CLI Interface
# ============================================================

def main():
    """CLI入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description="用户修正追踪器")
    parser.add_argument("--detect", "-d", help="检测消息中的修正")
    parser.add_argument("--list", "-l", action="store_true", help="列出修正记录")
    parser.add_argument("--stats", "-s", action="store_true", help="显示统计")
    parser.add_argument("--report", "-r", action="store_true", help="生成改进报告")
    parser.add_argument("--type", "-t", help="按类型过滤(correction/feature_request/knowledge_gap)")
    parser.add_argument("--skill", help="按skill过滤")
    parser.add_argument("--limit", type=int, default=10, help="限制显示数量")
    
    args = parser.parse_args()
    
    tracker = CorrectionTracker()
    
    if args.detect:
        correction = tracker.record_from_message(args.detect)
        if correction:
            print(f"\n[DETECTED] {correction.correction_type}")
            print(f"Pattern: {correction.pattern}")
            print(f"Content: {correction.corrected_content[:100]}")
            print(f"ID: {correction.correction_id}")
        else:
            print("\n[NO_MATCH] No correction pattern detected")
    
    if args.list:
        corrections = tracker.get_corrections(
            correction_type=args.type,
            skill=args.skill,
            limit=args.limit
        )
        print(f"\n[LIST] {len(corrections)} corrections:")
        for c in corrections:
            print(f"  [{c.correction_type}] {c.timestamp[:10]}: {c.corrected_content[:60]}...")
    
    if args.stats:
        stats = tracker.get_stats()
        print("\n" + "=" * 60)
        print("  Correction Tracker Stats")
        print("=" * 60)
        print(f"\nTotal: {stats['total']} | Today: {stats['recent_count']} | Adopted: {stats['adopted_count']}")
        print("\nBy Type:")
        for ctype, count in stats["by_type"].items():
            print(f"  {ctype:20s}: {count}")
        print("\nTop Skills:")
        for skill, count in stats["top_skills"]:
            print(f"  {skill:30s}: {count}")
    
    if args.report:
        print(tracker.export_report())
    
    if not any([args.detect, args.list, args.stats, args.report]):
        parser.print_help()


if __name__ == "__main__":
    main()
