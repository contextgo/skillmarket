# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# -*- coding: utf-8 -*-
"""
Configuration loader for skill-trend-analyzer.
Loads API URLs and other configurations from config/api_urls.json.
"""

import json
import os
from pathlib import Path

# Try multiple paths to find config directory
CONFIG_DIRS = [
    Path(__file__).parent.parent / "config",
    Path(__file__).parent / "config",
    Path("config"),
]

def find_config_dir():
    for d in CONFIG_DIRS:
        if d.exists():
            return d
    # Create config dir if not exists
    for d in CONFIG_DIRS:
        if d.parent.exists():
            d.mkdir(exist_ok=True)
            return d
    return CONFIG_DIRS[0]

def load_config():
    """Load API URLs configuration."""
    config_file = find_config_dir() / "api_urls.json"
    if config_file.exists():
        with open(config_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def get_api_url(category, key=None, default=None):
    """Get API URL from config."""
    config = load_config()
    if not config:
        return default
    cat = config.get(category, {})
    if key:
        return cat.get(key, default)
    return cat.get('health_check') or cat.get('stock_quote') or cat.get('skill_learning') or default

# Convenience functions for common APIs
def get_infini_ai_url():
    return get_api_url('infini_ai', 'health_check')

def get_clawhub_url():
    return get_api_url('clawhub', 'health_check')

def get_eastmoney_quote_url():
    return get_api_url('eastmoney', 'stock_quote')

def get_eastmoney_data_url():
    return get_api_url('eastmoney', 'stock_data')

def get_stustar_url():
    return get_api_url('stustar', 'skill_learning')

if __name__ == '__main__':
    import sys
    config = load_config()
    if config:
        sys.stdout.buffer.write(f"[CONFIG] Loaded config with {len(config)} categories\n".encode('utf-8', errors='replace'))
    else:
        sys.stdout.buffer.write("[CONFIG] Using defaults (config file not found)\n".encode('utf-8', errors='replace'))
