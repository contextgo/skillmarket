# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# -*- coding: utf-8 -*-
"""
Value-Driven Evolution Engine v1.0
====================================
价值驱动的自学习进化引擎 - 借鉴 Self Evolving Skill 的核心理念

Features:
  - 价值门控 (ValueGate): 只有提升价值超过阈值才接受改进
  - 经验回放 (ExperienceReplay): 缓存已学模式，降低重复触发
  - 残差金字塔 (ResidualPyramid): 量化认知缺口，自适应反思触发
  - 自进化循环: 自动评估、决策、执行、反馈

Author: WorkBuddy AI | Inspired by Self Evolving Skill
"""
import sys
import os
import json
import time
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from collections import deque

# ============================================================
# Configuration
# ============================================================

class EvolutionConfig:
    """进化引擎配置"""
    # 价值门控阈值
    VALUE_GAIN_THRESHOLD = 0.20      # 触发演化的最小价值增益
    MIN_ENERGY_RATIO = 0.10          # 触发反思的最小残差能量
    
    # 经验回放
    EXPERIENCE_CACHE_SIZE = 100      # 最大缓存模式数
    SIMILARITY_THRESHOLD = 0.85     # 模式相似度阈值
    
    # 演化参数
    ADAPTATION_RATE = 0.05          # 适应率
    DECAY_FACTOR = 0.95             # 衰减因子
    MAX_EVOLUTIONS_PER_CYCLE = 3    # 每周期最大演化次数
    
    # 演化循环
    REFLECTION_INTERVAL = 3600      # 反思间隔(秒)
    MIN_TRIGGER_RATE = 0.10        # 最小触发率
    
    @classmethod
    def load_from_file(cls, config_path: Path) -> 'EvolutionConfig':
        """从配置文件加载"""
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                cfg = cls()
                for k, v in data.items():
                    if hasattr(cfg, k.upper()):
                        setattr(cfg, k.upper(), v)
                return cfg
            except Exception:
                pass
        return cls()


@dataclass
class ExperiencePattern:
    """经验模式"""
    pattern_id: str
    pattern_type: str           # 'trigger' | 'optimization' | 'error_recovery'
    content: Dict[str, Any]
    value_score: float = 0.5    # 价值分数
    frequency: int = 1          # 使用频率
    success_count: int = 0      # 成功次数
    fail_count: int = 0         # 失败次数
    first_seen: str = ""        # 首次出现时间
    last_used: str = ""         # 最后使用时间
    source: str = ""            # 来源: 'user_feedback' | 'auto_discover' | 'competitor'
    tags: List[str] = field(default_factory=list)
    
    def get_success_rate(self) -> float:
        """计算成功率"""
        total = self.success_count + self.fail_count
        return self.success_count / total if total > 0 else 0.5
    
    def get_value(self) -> float:
        """计算综合价值"""
        success_rate = self.get_success_rate()
        recency = self._recency_score()
        frequency_bonus = min(self.frequency / 50, 0.2)  # 最多0.2加成
        return (success_rate * 0.5 + recency * 0.3 + frequency_bonus * 0.2) * self.value_score
    
    def _recency_score(self) -> float:
        """计算时效性分数"""
        if not self.last_used:
            return 0.5
        try:
            last = datetime.fromisoformat(self.last_used)
            days_ago = (datetime.now() - last).days
            return max(0, 1 - days_ago / 30)  # 30天后衰减为0
        except Exception:
            return 0.5


@dataclass
class EvolutionCandidate:
    """演化候选"""
    candidate_id: str
    improvement_type: str        # 'trigger_add' | 'trigger_remove' | 'weight_adjust' | 'new_capability'
    target: str                 # 目标skill或能力
    improvement: Dict[str, Any] # 具体改进内容
    predicted_gain: float       # 预测价值增益
    confidence: float = 0.5    # 置信度
    created_at: str = ""
    source: str = ""            # 来源


# ============================================================
# Core Classes
# ============================================================

class ValueGate:
    """
    价值门控 - 只有提升价值超过阈值才接受改进
    借鉴: Self Evolving Skill 的 ValueGate 理念
    """
    
    def __init__(self, threshold: float = 0.20):
        self.threshold = threshold
        self.history: List[Tuple[float, float, str]] = []  # (before, after, decision)
        self.accepted_count = 0
        self.rejected_count = 0
    
    def evaluate(self, improvement_score: float, current_score: float = 0.5) -> Tuple[bool, float]:
        """
        评估改进是否值得执行
        
        Returns:
            (是否接受, 实际增益)
        """
        gain = improvement_score - current_score
        normalized_gain = gain / max(current_score, 0.01)
        
        decision = normalized_gain >= self.threshold
        self.history.append((current_score, improvement_score, "ACCEPT" if decision else "REJECT"))
        
        if decision:
            self.accepted_count += 1
        else:
            self.rejected_count += 1
        
        return decision, gain
    
    def get_stats(self) -> Dict[str, Any]:
        """获取门控统计"""
        total = self.accepted_count + self.rejected_count
        return {
            "threshold": self.threshold,
            "total_evaluations": total,
            "accepted": self.accepted_count,
            "rejected": self.rejected_count,
            "accept_rate": self.accepted_count / total if total > 0 else 0
        }


class ExperienceReplay:
    """
    经验回放 - 缓存已学模式，降低重复触发
    借鉴: Self Evolving Skill 的 ExperienceReplay 机制
    """
    
    def __init__(self, max_size: int = 100):
        self.max_size = max_size
        self.patterns: Dict[str, ExperiencePattern] = {}
        self.access_order = deque(maxlen=max_size)
        self.hit_count = 0
        self.miss_count = 0
    
    def add(self, pattern: ExperiencePattern) -> bool:
        """添加新模式"""
        # 生成pattern_id
        if not pattern.pattern_id:
            content_str = json.dumps(pattern.content, sort_keys=True)
            pattern.pattern_id = hashlib.md5(content_str.encode()).hexdigest()[:12]
        
        if not pattern.first_seen:
            pattern.first_seen = datetime.now().isoformat()
        pattern.last_used = datetime.now().isoformat()
        
        if pattern.pattern_id in self.patterns:
            # 更新已有模式
            existing = self.patterns[pattern.pattern_id]
            existing.frequency += 1
            existing.value_score = (existing.value_score + pattern.value_score) / 2
            if pattern.success_count > 0:
                existing.success_count += 1
            if pattern.fail_count > 0:
                existing.fail_count += 1
            return False  # 已存在
        else:
            # 添加新模式
            if len(self.patterns) >= self.max_size:
                self._evict_lru()
            self.patterns[pattern.pattern_id] = pattern
            return True
    
    def find_similar(self, content: Dict, threshold: float = 0.85) -> Optional[ExperiencePattern]:
        """查找相似模式"""
        content_str = json.dumps(content, sort_keys=True)
        content_hash = hashlib.md5(content_str.encode()).hexdigest()[:12]
        
        if content_hash in self.patterns:
            self.hit_count += 1
            p = self.patterns[content_hash]
            self.access_order.append(p.pattern_id)
            return p
        
        # 模糊匹配
        for pid, pattern in self.patterns.items():
            similarity = self._compute_similarity(content, pattern.content)
            if similarity >= threshold:
                self.hit_count += 1
                pattern.frequency += 1
                pattern.last_used = datetime.now().isoformat()
                self.access_order.append(pid)
                return pattern
        
        self.miss_count += 1
        return None
    
    def get_hot_patterns(self, top_n: int = 10) -> List[ExperiencePattern]:
        """获取热门模式"""
        return sorted(
            self.patterns.values(),
            key=lambda p: (p.get_value(), p.frequency),
            reverse=True
        )[:top_n]
    
    def _evict_lru(self):
        """驱逐最少使用的模式"""
        if not self.access_order:
            return
        
        lru_id = self.access_order[0]
        if lru_id in self.patterns:
            del self.patterns[lru_id]
    
    def _compute_similarity(self, a: Dict, b: Dict) -> float:
        """计算两个模式的相似度"""
        if not a or not b:
            return 0.0
        
        # 简单的Jaccard相似度
        keys_a = set(a.keys())
        keys_b = set(b.keys())
        common_keys = keys_a & keys_b
        
        if not common_keys:
            return 0.0
        
        common = sum(1 for k in common_keys if a[k] == b[k])
        total = len(keys_a | keys_b)
        
        return common / total if total > 0 else 0.0
    
    def get_stats(self) -> Dict[str, Any]:
        """获取缓存统计"""
        total = self.hit_count + self.miss_count
        return {
            "cached_patterns": len(self.patterns),
            "max_size": self.max_size,
            "hit_count": self.hit_count,
            "miss_count": self.miss_count,
            "hit_rate": self.hit_count / total if total > 0 else 0,
            "avg_value": sum(p.get_value() for p in self.patterns.values()) / max(len(self.patterns), 1)
        }


class ResidualPyramid:
    """
    残差金字塔 - 量化认知缺口，自适应反思触发
    借鉴: Self Evolving Skill 的 ResidualPyramid 理念
    """
    
    def __init__(self, min_energy_ratio: float = 0.10):
        self.min_energy_ratio = min_energy_ratio
        self.layers = {
            "surface": 0.0,     # 表层残差 (表面错误)
            "structural": 0.0,   # 结构性残差 (架构问题)
            "semantic": 0.0,    # 语义残差 (理解偏差)
            "meta": 0.0,        # 元认知残差 (认知模式问题)
        }
        self.history: List[Dict] = []
    
    def add_residual(self, layer: str, energy: float):
        """添加残差"""
        if layer in self.layers:
            self.layers[layer] = max(self.layers[layer], energy)
            self._record_snapshot()
    
    def compute_energy(self) -> float:
        """计算总残差能量"""
        weights = {"surface": 0.2, "structural": 0.3, "semantic": 0.3, "meta": 0.2}
        total = sum(self.layers[k] * weights[k] for k in weights)
        return min(total, 1.0)  # 归一化到[0,1]
    
    def should_reflect(self) -> Tuple[bool, str]:
        """判断是否应该触发反思"""
        energy = self.compute_energy()
        if energy >= self.min_energy_ratio:
            dominant_layer = max(self.layers, key=self.layers.get)
            return True, f"能量={energy:.2f}, 主层={dominant_layer}"
        return False, ""
    
    def decay(self, factor: float = 0.95):
        """残差衰减"""
        for k in self.layers:
            self.layers[k] *= factor
        self._record_snapshot()
    
    def reset(self):
        """重置所有残差"""
        for k in self.layers:
            self.layers[k] = 0.0
        self._record_snapshot()
    
    def _record_snapshot(self):
        """记录快照"""
        self.history.append({
            "timestamp": datetime.now().isoformat(),
            "layers": dict(self.layers),
            "energy": self.compute_energy()
        })
        # 保留最近100条
        if len(self.history) > 100:
            self.history = self.history[-100:]
    
    def get_diagnosis(self) -> Dict[str, Any]:
        """获取诊断报告"""
        return {
            "energy": self.compute_energy(),
            "layers": self.layers,
            "should_reflect": self.should_reflect()[0],
            "dominant_layer": max(self.layers, key=self.layers.get),
            "history_length": len(self.history)
        }


class ValueDrivenEvolution:
    """
    价值驱动进化引擎 - 整合所有组件
    """
    
    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = data_dir or Path(__file__).parent.parent / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # 加载配置
        config_path = self.data_dir / "evolution_config.json"
        self.config = EvolutionConfig.load_from_file(config_path)
        
        # 初始化组件
        self.value_gate = ValueGate(threshold=self.config.VALUE_GAIN_THRESHOLD)
        self.experience_replay = ExperienceReplay(max_size=self.config.EXPERIENCE_CACHE_SIZE)
        self.residual_pyramid = ResidualPyramid(min_energy_ratio=self.config.MIN_ENERGY_RATIO)
        
        # 演化历史
        self.evolution_log: List[Dict] = []
        self.pending_candidates: List[EvolutionCandidate] = []
        
        # 加载持久化数据
        self._load_state()
    
    def _load_state(self):
        """加载持久化状态"""
        state_file = self.data_dir / "evolution_state.json"
        if state_file.exists():
            try:
                with open(state_file, 'r', encoding='utf-8') as f:
                    state = json.load(f)
                
                # 恢复经验模式
                for pdata in state.get("patterns", []):
                    pattern = ExperiencePattern(**pdata)
                    self.experience_replay.patterns[pattern.pattern_id] = pattern
                
                # 恢复演化历史
                self.evolution_log = state.get("log", [])
                
            except Exception:
                pass
    
    def _save_state(self):
        """保存状态"""
        state_file = self.data_dir / "evolution_state.json"
        state = {
            "patterns": [
                {**vars(p), "content": p.content} 
                for p in self.experience_replay.patterns.values()
            ],
            "log": self.evolution_log[-100:]  # 保留最近100条
        }
        try:
            with open(state_file, 'w', encoding='utf-8') as f:
                json.dump(state, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    
    def add_candidate(self, candidate: EvolutionCandidate) -> bool:
        """添加演化候选"""
        # 检查相似候选
        similar = self.experience_replay.find_similar(candidate.improvement)
        if similar and similar.get_success_rate() > 0.7:
            # 已有成功经验，跳过
            return False
        
        self.pending_candidates.append(candidate)
        return True
    
    def evaluate_and_evolve(self) -> List[Dict[str, Any]]:
        """评估候选并执行演化"""
        results = []
        
        # 检查是否应该反思
        should_reflect, reason = self.residual_pyramid.should_reflect()
        if not should_reflect:
            return results
        
        # 评估每个候选
        for candidate in self.pending_candidates[:self.config.MAX_EVOLUTIONS_PER_CYCLE]:
            # 通过价值门控
            accepted, gain = self.value_gate.evaluate(
                candidate.predicted_gain,
                current_score=0.5
            )
            
            result = {
                "candidate_id": candidate.candidate_id,
                "accepted": accepted,
                "gain": gain,
                "improvement": candidate.improvement,
                "timestamp": datetime.now().isoformat()
            }
            results.append(result)
            
            if accepted:
                # 记录到演化历史
                self.evolution_log.append({
                    "action": "EVOLVE",
                    "candidate": candidate.candidate_id,
                    "gain": gain,
                    "improvement": candidate.improvement,
                    "timestamp": datetime.now().isoformat()
                })
                
                # 添加到经验回放
                pattern = ExperiencePattern(
                    pattern_id="",
                    pattern_type=candidate.improvement_type,
                    content=candidate.improvement,
                    value_score=candidate.predicted_gain,
                    source=candidate.source
                )
                self.experience_replay.add(pattern)
        
        # 清空已处理的候选
        self.pending_candidates = self.pending_candidates[self.config.MAX_EVOLUTIONS_PER_CYCLE:]
        
        # 残差衰减
        self.residual_pyramid.decay(factor=self.config.DECAY_FACTOR)
        
        # 保存状态
        self._save_state()
        
        return results
    
    def record_success(self, improvement: Dict[str, Any]):
        """记录成功改进"""
        pattern = ExperiencePattern(
            pattern_id="",
            pattern_type="optimization",
            content=improvement,
            value_score=0.8,
            success_count=1,
            source="user_feedback"
        )
        self.experience_replay.add(pattern)
        
        # 添加正向残差
        self.residual_pyramid.add_residual("surface", -0.1)  # 减少表层错误
        self._save_state()
    
    def record_failure(self, improvement: Dict[str, Any], error: str = ""):
        """记录失败改进"""
        pattern = ExperiencePattern(
            pattern_id="",
            pattern_type="optimization",
            content=improvement,
            value_score=0.2,
            fail_count=1,
            source="user_feedback"
        )
        self.experience_replay.add(pattern)
        
        # 增加残差
        if "syntax" in error.lower():
            self.residual_pyramid.add_residual("surface", 0.3)
        elif "logic" in error.lower():
            self.residual_pyramid.add_residual("structural", 0.3)
        else:
            self.residual_pyramid.add_residual("semantic", 0.2)
        
        self._save_state()
    
    def get_status(self) -> Dict[str, Any]:
        """获取引擎状态"""
        return {
            "value_gate": self.value_gate.get_stats(),
            "experience_replay": self.experience_replay.get_stats(),
            "residual_pyramid": self.residual_pyramid.get_diagnosis(),
            "pending_candidates": len(self.pending_candidates),
            "evolution_count": len(self.evolution_log)
        }
    
    def generate_insights(self) -> List[str]:
        """生成洞察报告"""
        insights = []
        
        # 基于经验回放
        hot = self.experience_replay.get_hot_patterns(5)
        if hot:
            insights.append(f"热门模式Top5: {', '.join(p.pattern_type for p in hot[:3])}")
        
        # 基于残差诊断
        diag = self.residual_pyramid.get_diagnosis()
        if diag["should_reflect"]:
            insights.append(f"残差能量过高({diag['energy']:.2f})，建议执行反思")
        
        # 基于价值门控
        gate_stats = self.value_gate.get_stats()
        if gate_stats["accept_rate"] < 0.3:
            insights.append(f"价值门控接受率偏低({gate_stats['accept_rate']:.1%})，考虑调整阈值")
        
        return insights


# ============================================================
# CLI Interface
# ============================================================

def main():
    """CLI入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description="价值驱动进化引擎")
    parser.add_argument("--status", action="store_true", help="查看引擎状态")
    parser.add_argument("--candidates", help="添加候选(JSON字符串)")
    parser.add_argument("--success", help="记录成功(JSON字符串)")
    parser.add_argument("--failure", help="记录失败(JSON字符串)")
    parser.add_argument("--evolve", action="store_true", help="执行演化循环")
    parser.add_argument("--insights", action="store_true", help="生成洞察报告")
    
    args = parser.parse_args()
    
    # 初始化引擎
    engine = ValueDrivenEvolution()
    
    if args.status:
        status = engine.get_status()
        print("\n" + "=" * 60)
        print("  Value-Driven Evolution Status")
        print("=" * 60)
        print(f"\n[Value Gate]")
        print(f"  Threshold: {status['value_gate']['threshold']}")
        print(f"  Accept Rate: {status['value_gate']['accept_rate']:.1%}")
        print(f"  Accepted: {status['value_gate']['accepted']} / Rejected: {status['value_gate']['rejected']}")
        
        print(f"\n[Experience Replay]")
        print(f"  Cached: {status['experience_replay']['cached_patterns']}")
        print(f"  Hit Rate: {status['experience_replay']['hit_rate']:.1%}")
        print(f"  Avg Value: {status['experience_replay']['avg_value']:.2f}")
        
        print(f"\n[Residual Pyramid]")
        print(f"  Energy: {status['residual_pyramid']['energy']:.2f}")
        print(f"  Should Reflect: {status['residual_pyramid']['should_reflect']}")
        print(f"  Dominant: {status['residual_pyramid']['dominant_layer']}")
        
        print(f"\n[Evolution]")
        print(f"  Pending: {status['pending_candidates']}")
        print(f"  Total Evolutions: {status['evolution_count']}")
        print()
    
    if args.candidates:
        import json
        data = json.loads(args.candidates)
        candidate = EvolutionCandidate(
            candidate_id=data.get("id", ""),
            improvement_type=data.get("type", "optimization"),
            target=data.get("target", ""),
            improvement=data.get("improvement", {}),
            predicted_gain=data.get("gain", 0.5),
            source=data.get("source", "manual")
        )
        engine.add_candidate(candidate)
        print("[OK] Candidate added")
    
    if args.success:
        import json
        data = json.loads(args.success)
        engine.record_success(data)
        print("[OK] Success recorded")
    
    if args.failure:
        import json
        data = json.loads(args.failure)
        error = data.pop("error", "")
        engine.record_failure(data, error)
        print("[OK] Failure recorded")
    
    if args.evolve:
        results = engine.evaluate_and_evolve()
        print(f"[EVOLVE] {len(results)} evolutions executed")
        for r in results:
            print(f"  - {r['candidate_id']}: {'ACCEPT' if r['accepted'] else 'REJECT'}")
    
    if args.insights:
        insights = engine.generate_insights()
        print("\n[Insights]")
        for i, insight in enumerate(insights, 1):
            print(f"  {i}. {insight}")
        print()
    
    if not any([args.status, args.candidates, args.success, args.failure, args.evolve, args.insights]):
        parser.print_help()


if __name__ == "__main__":
    main()
