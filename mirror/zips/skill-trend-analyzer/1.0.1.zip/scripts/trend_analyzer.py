#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
"""
Trend Analyzer for Skill Trend Analyzer
=========================================
Analyzes collected market data to identify:
  - Rising/falling keywords
  - Hot trigger word patterns
  - Category-wise popularity
  - Cross-market comparisons
  - Seasonal/periodic trends

Usage:
  python trend_analyzer.py [--category <cat>] [--top <n>] [--verbose]
  python trend_analyzer.py --rising          # Keywords gaining momentum
  python trend_analyzer.py --compare <skill_dir>  # Compare with a specific skill
"""
import sys, io, os, re, json, math
from pathlib import Path
from datetime import datetime, timedelta
from collections import Counter, defaultdict

# [Safe Guard: 5-layer anti-freeze system]
from safe_guard import safe_print, safe_init, TimeoutGuard, safe_read_json, safe_read_text
from exec_logger import ExecutionLogger
safe_init()

SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR.parent / "data"


# ============================================================
# Trend Analyzer
# ============================================================

class TrendAnalyzer:
    """Analyze market trends from collected data."""

    def __init__(self, verbose=False):
        self.verbose = verbose
        self.market_cache = self._load_json(DATA_DIR / "market_cache.json")
        self.keyword_freq = self._load_json(DATA_DIR / "keyword_frequency.json")
        self.trigger_patterns = self._load_json(DATA_DIR / "trigger_patterns.json")
        self.trend_history = self._load_json(DATA_DIR / "trend_history.json")

    def analyze(self, category=None, top_n=30):
        """Generate comprehensive trend analysis."""
        print("=" * 65)
        print("  Skill Market Trend Analysis Report")
        print(f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 65)

        # 1. Market overview
        self._print_market_overview()

        # 2. Hot keywords
        self._print_hot_keywords(top_n, category)

        # 3. Hot trigger patterns
        self._print_trigger_patterns(top_n)

        # 4. Rising keywords (trend comparison)
        self._print_rising_keywords(top_n)

        # 5. Category distribution
        self._print_category_distribution()

        # 6. Naming pattern insights
        self._print_naming_insights()

        print("=" * 65)

    def get_rising_keywords(self, top_n=20):
        """Get keywords with rising trend scores."""
        if len(self.trend_history) < 2:
            return []

        recent = self.trend_history[-1].get('top_50_keywords', [])
        if len(self.trend_history) >= 2:
            older = self.trend_history[-2].get('top_50_keywords', [])
        else:
            older = []

        recent_map = {k['keyword']: k['score'] for k in recent}
        older_map = {k['keyword']: k['score'] for k in older}

        rising = []
        for kw, score in recent_map.items():
            old_score = older_map.get(kw, 0)
            if old_score > 0:
                change_pct = (score - old_score) / old_score * 100
            else:
                change_pct = 999  # New keyword
            rising.append({
                'keyword': kw,
                'current_score': round(score, 2),
                'previous_score': round(old_score, 2),
                'change_pct': round(change_pct, 1),
                'is_new': old_score == 0,
            })

        rising.sort(key=lambda x: -x['change_pct'])
        return rising[:top_n]

    def compare_skill(self, skill_dir):
        """Compare a specific skill's keywords against market trends."""
        from pathlib import Path
        skill_dir = Path(skill_dir)
        skill_md = skill_dir / "SKILL.md"

        if not skill_md.exists():
            print(f"[ERROR] SKILL.md not found: {skill_md}")
            return

        content = safe_read_text(skill_md, timeout=5)

        # Extract skill's current keywords
        skill_keywords = set()
        # From frontmatter description
        fm_match = re.match(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
        if fm_match:
            desc = re.search(r'description:\s*(.+)', fm_match.group(1))
            if desc:
                for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', desc.group(1)):
                    skill_keywords.add(zh)
                for en in re.findall(r'[a-zA-Z][a-zA-Z0-9_-]{2,}', desc.group(1)):
                    skill_keywords.add(en.lower())

        # From trigger sections
        for kw in re.findall(r'[\u4e00-\u9fff]{2,6}|[a-zA-Z][a-zA-Z0-9_-]{2,}', content):
            skill_keywords.add(kw.lower())

        # Market keywords map
        market_kw_map = {}
        if self.keyword_freq:
            for entry in self.keyword_freq.get('top_keywords', []):
                market_kw_map[entry['keyword']] = entry['score']

        print(f"\n{'=' * 65}")
        print(f"  Skill vs Market Comparison: {skill_dir.name}")
        print(f"  Skill keywords: {len(skill_keywords)}")
        print(f"{'=' * 65}")

        # Covered: skill has keyword that's in market top list
        covered = []
        missing_hot = []  # Market hot keywords not in skill
        unique = []       # Skill keywords not in market

        for kw in skill_keywords:
            if kw in market_kw_map:
                covered.append((kw, market_kw_map[kw]))
            else:
                unique.append(kw)

        for kw, score in sorted(market_kw_map.items(), key=lambda x: -x[1])[:100]:
            if kw not in skill_keywords:
                missing_hot.append((kw, score))

        print(f"\n[COVERED] Keywords matching market ({len(covered)}):")
        for kw, score in sorted(covered, key=lambda x: -x[1])[:15]:
            bar = '#' * int(min(score / 5, 20))
            print(f"  {kw:<20s} {score:>8.1f} {bar}")

        print(f"\n[MISSING HOT] Market keywords you should add ({len(missing_hot)}):")
        for kw, score in missing_hot[:20]:
            is_chinese = any('\u4e00' <= c <= '\u9fff' for c in kw)
            marker = "[CN]" if is_chinese else "[EN]"
            bar = '#' * int(min(score / 5, 20))
            print(f"  {marker} {kw:<18s} {score:>8.1f} {bar}")

        print(f"\n[UNIQUE] Keywords only in your skill ({len(unique)}):")
        for kw in sorted(unique)[:15]:
            print(f"  {kw}")

        # Coverage score
        if market_kw_map:
            top_100 = set(kw for kw, _ in sorted(
                market_kw_map.items(), key=lambda x: -x[1])[:100])
            covered_top = skill_keywords & top_100
            coverage = len(covered_top) / len(top_100) * 100 if top_100 else 0
            print(f"\n[COVERAGE] Your skill covers {coverage:.1f}% of top 100 market keywords")

        return {
            'covered': covered,
            'missing_hot': missing_hot,
            'unique': unique,
        }

    def _print_market_overview(self):
        """Print market overview stats."""
        total = len(self.market_cache)
        if not total:
            print("\n[WARNING] No market data. Run market_collector.py first.")
            return

        sources = Counter(v.get('source', 'unknown') for v in self.market_cache.values())

        # Age distribution
        now = datetime.now()
        ages = {'<1d': 0, '1-7d': 0, '7-30d': 0, '>30d': 0}
        for v in self.market_cache.values():
            try:
                dt = datetime.fromisoformat(v.get('collected_at', now.isoformat()))
                age = (now - dt).days
            except:
                age = 999
            if age < 1: ages['<1d'] += 1
            elif age < 7: ages['1-7d'] += 1
            elif age < 30: ages['7-30d'] += 1
            else: ages['>30d'] += 1

        print(f"\n[MARKET OVERVIEW]")
        print(f"  Total skills cached: {total}")
        print(f"  Sources: {dict(sources)}")
        print(f"  Data freshness: {ages}")

    def _print_hot_keywords(self, top_n, category=None):
        """Print hot keywords from market data."""
        if not self.keyword_freq:
            return

        keywords = self.keyword_freq.get('top_keywords', [])
        if category:
            # Filter by source category (future: per-category tags)
            pass

        print(f"\n[HOT KEYWORDS] Top {min(top_n, len(keywords))} in market:")
        print(f"  {'Keyword':<22s} {'Score':>8s} {'Source':>12s}")
        print(f"  {'-'*22:<22s} {'-'*8:>8s} {'-'*12:>12s}")
        for entry in keywords[:top_n]:
            kw = entry['keyword']
            score = entry['score']
            src = entry.get('source', 'market')
            is_chinese = any('\u4e00' <= c <= '\u9fff' for c in kw)
            marker = "[CN]" if is_chinese else "[EN]"
            print(f"  {marker} {kw:<18s} {score:>8.1f} {src:>12s}")

    def _print_trigger_patterns(self, top_n):
        """Print hot trigger word patterns."""
        if not self.trigger_patterns:
            return

        patterns = self.trigger_patterns.get('top_patterns', [])
        print(f"\n[TRIGGER PATTERNS] Top {min(top_n, len(patterns))} patterns:")
        print(f"  {'Pattern':<30s} {'Frequency':>10s}")
        print(f"  {'-'*30:<30s} {'-'*10:>10s}")
        for entry in patterns[:top_n]:
            print(f"  {entry['pattern']:<30s} {entry['frequency']:>10d}")

    def _print_rising_keywords(self, top_n):
        """Print rising keywords based on trend history."""
        rising = self.get_rising_keywords(top_n)
        if not rising:
            print(f"\n[RISING KEYWORDS] Need at least 2 trend snapshots")
            return

        print(f"\n[RISING KEYWORDS] Gaining momentum:")
        print(f"  {'Keyword':<20s} {'Current':>8s} {'Previous':>8s} {'Change':>8s}")
        print(f"  {'-'*20:<20s} {'-'*8:>8s} {'-'*8:>8s} {'-'*8:>8s}")
        for r in rising:
            change = f"+{r['change_pct']:.0f}%" if r['change_pct'] != 999 else "NEW!"
            print(f"  {r['keyword']:<20s} {r['current_score']:>8.1f} "
                  f"{r['previous_score']:>8.1f} {change:>8s}")

    def _print_category_distribution(self):
        """Print skill category distribution."""
        if not self.market_cache:
            return

        categories = Counter()
        for slug, entry in self.market_cache.items():
            # Infer category from slug
            slug_lower = slug.lower()
            if any(w in slug_lower for w in ['tax', 'finance', 'account', 'invoice', 'bank']):
                categories['Tax/Finance'] += 1
            elif any(w in slug_lower for w in ['business', 'management', 'crm', 'hr']):
                categories['Business'] += 1
            elif any(w in slug_lower for w in ['ai', 'chat', 'assistant', 'agent']):
                categories['AI/Agent'] += 1
            elif any(w in slug_lower for w in ['code', 'dev', 'api', 'test', 'deploy']):
                categories['Development'] += 1
            elif any(w in slug_lower for w in ['health', 'fitness', 'food', 'travel']):
                categories['Lifestyle'] += 1
            elif any(w in slug_lower for w in ['security', 'audit', 'compliance']):
                categories['Security/Compliance'] += 1
            else:
                categories['Other'] += 1

        print(f"\n[CATEGORY DISTRIBUTION]")
        for cat, count in categories.most_common():
            pct = count / len(self.market_cache) * 100
            bar = '#' * int(pct / 2)
            print(f"  {cat:<25s} {count:>5d} ({pct:>5.1f}%) {bar}")

    def _print_naming_insights(self):
        """Print naming pattern insights from market."""
        if not self.market_cache:
            return

        # Common slug structures
        slug_patterns = Counter()
        for slug in self.market_cache.keys():
            parts = slug.split('-')
            if len(parts) == 1:
                slug_patterns['single-word'] += 1
            elif len(parts) == 2:
                slug_patterns['two-words'] += 1
            elif len(parts) == 3:
                slug_patterns['three-words'] += 1
            else:
                slug_patterns['4+-words'] += 1

        print(f"\n[NAMING PATTERNS] Slug structure distribution:")
        for pat, count in slug_patterns.most_common():
            print(f"  {pat:<15s} {count:>5d}")

        # Top slug prefix words
        prefixes = Counter()
        for slug in self.market_cache.keys():
            parts = slug.split('-')
            if parts:
                prefixes[parts[0]] += 1

        print(f"\n  Top slug prefixes:")
        for prefix, count in prefixes.most_common(10):
            print(f"    {prefix:<20s} {count:>5d}")

    def _load_json(self, path):
        """Load JSON file safely."""
        if path.exists():
            try:
                return safe_read_json(path)
            except:
                return {}
        return {}


# ============================================================
# CLI Entry Point
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Trend Analyzer")
    parser.add_argument("--category", "-c", help="Filter by category")
    parser.add_argument("--top", "-n", type=int, default=30, help="Top N items")
    parser.add_argument("--rising", action="store_true", help="Show rising keywords")
    parser.add_argument("--compare", metavar="SKILL_DIR",
                       help="Compare a skill against market trends")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    # ---- 执行日志 start ----
    subcmd = "rising" if args.rising else "compare" if args.compare else "analyze"
    logger = ExecutionLogger("trend_analyzer")
    logger.start({
        "subcommand": subcmd,
        "category": args.category,
        "top": args.top,
        "compare": args.compare,
        "verbose": args.verbose
    })

    try:
        analyzer = TrendAnalyzer(verbose=args.verbose)

        if args.rising:
            logger.phase("get_rising")
            rising = analyzer.get_rising_keywords(args.top)
            if rising:
                print("[RISING KEYWORDS]")
                for r in rising:
                    change = f"+{r['change_pct']:.0f}%" if r['change_pct'] != 999 else "NEW!"
                    print(f"  {r['keyword']:<20s} {r['current_score']:>8.1f} {change}")
            else:
                print("[INFO] Need more trend snapshots for rising analysis")
            logger.done({
                "subcommand": "rising",
                "rising_count": len(rising),
                "market_cache_size": len(analyzer.market_cache),
                "trend_history_snapshots": len(analyzer.trend_history) if isinstance(analyzer.trend_history, list) else 0,
            })
        elif args.compare:
            logger.phase("compare")
            result = analyzer.compare_skill(args.compare)
            logger.done({
                "subcommand": "compare",
                "compare_target": args.compare,
                "market_cache_size": len(analyzer.market_cache),
            })
        else:
            logger.phase("analyze")
            analyzer.analyze(category=args.category, top_n=args.top)
            logger.phase("saving")
            logger.done({
                "subcommand": "analyze",
                "market_cache_size": len(analyzer.market_cache),
                "keyword_count": len(analyzer.keyword_freq.get("top_keywords", [])) if analyzer.keyword_freq else 0,
                "trigger_pattern_count": len(analyzer.trigger_patterns.get("top_patterns", [])) if analyzer.trigger_patterns else 0,
                "trend_history_snapshots": len(analyzer.trend_history) if isinstance(analyzer.trend_history, list) else 0,
            })

    except Exception as e:
        logger.fail(str(e), {"subcommand": subcmd})
        import traceback; traceback.print_exc()

    # Fixed ending - contact author info (ClawHub compliance)
    from safe_io import print_footer
    print_footer()


if __name__ == "__main__":
    main()

