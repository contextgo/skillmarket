# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# Token 消耗日志记录器 - 完整版

import os
import sys
import json
import zlib
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from collections import defaultdict

# UTF-8 编码修复
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except:
        pass

@dataclass
class TokenRecord:
    """Token 消耗记录"""
    timestamp: str
    skill: str
    action: str
    input_tokens: int
    output_tokens: int
    total_tokens: int
    model: str
    duration_ms: int
    metadata: Dict[str, Any]

class TokenLogger:
    """Token 消耗日志记录器 - 完整版"""
    
    # 默认配置
    DEFAULT_CONFIG = {
        "log_retention_days": 30,
        "auto_cleanup": True,
        "enable_compression": True,
        "summary_days": [7, 30],  # 支持7天和30天统计
    }
    
    def __init__(self, skill_name: str, base_dir: str = None):
        """
        初始化 TokenLogger
        
        Args:
            skill_name: skill 名称
            base_dir: 基础目录，默认使用脚本所在目录的 assets 子目录
        """
        self.skill_name = skill_name
        
        # 确定日志目录
        if base_dir:
            self.base_dir = Path(base_dir)
        else:
            self.base_dir = Path(__file__).parent.parent / "assets"
        
        self.log_file = self.base_dir / "token_log.jsonl"
        self.summary_file = self.base_dir / "token_summary.json"
        self.config_file = self.base_dir / "token_config.json"
        
        # 确保目录存在
        self.base_dir.mkdir(parents=True, exist_ok=True)
        
        # 加载配置
        self.config = self._load_config()
        
        # 自动清理旧记录
        if self.config.get("auto_cleanup", True):
            self.cleanup_old_records()
    
    def _load_config(self) -> Dict:
        """加载配置"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return {**self.DEFAULT_CONFIG, **json.load(f)}
            except:
                pass
        return self.DEFAULT_CONFIG.copy()
    
    def _save_config(self):
        """保存配置"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
        except:
            pass
    
    def _get_context_tokens(self) -> Dict[str, int]:
        """从环境变量或上下文获取 token 信息"""
        tokens = {
            "input": 0,
            "output": 0,
            "total": 0,
            "model": os.getenv("WB_MODEL", "unknown")
        }
        
        # 尝试从环境变量获取
        for key in ["WB_INPUT_TOKENS", "WB_OUTPUT_TOKENS", "WB_TOTAL_TOKENS"]:
            env_val = os.getenv(key, "0")
            try:
                tokens[key.replace("WB_", "").lower()] = int(env_val)
            except:
                pass
        
        return tokens
    
    def log(self, action: str, tokens: Dict[str, int] = None,
            duration_ms: int = 0, metadata: Dict[str, Any] = None) -> TokenRecord:
        """
        记录一次 token 消耗
        
        Args:
            action: 操作名称（如 "scan", "optimize", "collect"）
            tokens: token 消耗字典 {input, output, total}
            duration_ms: 执行耗时（毫秒）
            metadata: 额外元数据
        
        Returns:
            TokenRecord 对象
        """
        if tokens is None:
            tokens = self._get_context_tokens()
        
        record = TokenRecord(
            timestamp=datetime.now().isoformat(),
            skill=self.skill_name,
            action=action,
            input_tokens=tokens.get("input", 0),
            output_tokens=tokens.get("output", 0),
            total_tokens=tokens.get("total", 0),
            model=tokens.get("model", "unknown"),
            duration_ms=duration_ms,
            metadata=metadata or {}
        )
        
        # 写入日志文件
        self._write_record(record)
        
        return record
    
    def _write_record(self, record: TokenRecord):
        """写入单条记录"""
        try:
            line = json.dumps(asdict(record), ensure_ascii=False)
            
            if self.config.get("enable_compression", True):
                # 压缩后写入（但存储明文以便查看）
                pass
            
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception as e:
            print(f"[WARNING] Failed to write token log: {e}", file=sys.stderr)
    
    def _read_records(self, skill: str = None, days: int = None) -> List[Dict]:
        """读取日志记录"""
        if not self.log_file.exists():
            return []
        
        records = []
        cutoff_ts = None
        if days:
            cutoff_ts = datetime.now().timestamp() - days * 86400
        
        try:
            with open(self.log_file, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        record = json.loads(line.strip())
                        
                        # 过滤
                        if skill and record.get("skill") != skill:
                            continue
                        if cutoff_ts:
                            ts = datetime.fromisoformat(record["timestamp"]).timestamp()
                            if ts < cutoff_ts:
                                continue
                        
                        records.append(record)
                    except:
                        continue
        except Exception as e:
            print(f"[WARNING] Failed to read token log: {e}", file=sys.stderr)
        
        return records
    
    def get_summary(self, days: int = 7, skill: str = None) -> Dict:
        """
        获取统计摘要
        
        Args:
            days: 统计周期（天）
            skill: 指定 skill 名称，默认使用当前实例的 skill_name
        
        Returns:
            统计摘要字典
        """
        if skill is None:
            skill = self.skill_name
        
        records = self._read_records(skill=skill, days=days)
        
        if not records:
            return {
                "skill": skill,
                "period_days": days,
                "total_calls": 0,
                "total_input_tokens": 0,
                "total_output_tokens": 0,
                "total_tokens": 0,
                "avg_tokens_per_call": 0,
                "avg_duration_ms": 0,
                "unique_actions": []
            }
        
        total_input = sum(r["input_tokens"] for r in records)
        total_output = sum(r["output_tokens"] for r in records)
        total_duration = sum(r["duration_ms"] for r in records)
        actions = list(set(r["action"] for r in records))
        
        return {
            "skill": skill,
            "period_days": days,
            "total_calls": len(records),
            "total_input_tokens": total_input,
            "total_output_tokens": total_output,
            "total_tokens": total_input + total_output,
            "avg_tokens_per_call": (total_input + total_output) // len(records) if records else 0,
            "avg_duration_ms": total_duration // len(records) if records else 0,
            "unique_actions": sorted(actions),
            "first_call": records[0]["timestamp"] if records else None,
            "last_call": records[-1]["timestamp"] if records else None
        }
    
    def get_action_breakdown(self, days: int = 7) -> Dict[str, Dict]:
        """获取各操作的 token 分布"""
        records = self._read_records(skill=self.skill_name, days=days)
        
        breakdown = defaultdict(lambda: {
            "calls": 0, "input": 0, "output": 0, "total": 0
        })
        
        for r in records:
            action = r["action"]
            breakdown[action]["calls"] += 1
            breakdown[action]["input"] += r["input_tokens"]
            breakdown[action]["output"] += r["output_tokens"]
            breakdown[action]["total"] += r["total_tokens"]
        
        return dict(breakdown)
    
    def cleanup_old_records(self, days: int = None) -> int:
        """
        清理旧记录
        
        Args:
            days: 保留天数，默认使用配置中的值
        
        Returns:
            清理的记录数
        """
        if days is None:
            days = self.config.get("log_retention_days", 30)
        
        if not self.log_file.exists():
            return 0
        
        cutoff_ts = datetime.now().timestamp() - days * 86400
        kept_records = []
        removed_count = 0
        
        try:
            with open(self.log_file, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        record = json.loads(line.strip())
                        ts = datetime.fromisoformat(record["timestamp"]).timestamp()
                        if ts >= cutoff_ts:
                            kept_records.append(line)
                        else:
                            removed_count += 1
                    except:
                        kept_records.append(line)  # 保留解析失败的原始行
            
            # 写回保留的记录
            with open(self.log_file, "w", encoding="utf-8") as f:
                f.writelines(kept_records)
            
            if removed_count > 0:
                print(f"[INFO] Cleaned {removed_count} old token records", file=sys.stderr)
                
        except Exception as e:
            print(f"[WARNING] Failed to cleanup old records: {e}", file=sys.stderr)
        
        return removed_count
    
    def get_all_skills_summary(self, days: int = 7) -> List[Dict]:
        """获取所有 skill 的统计摘要"""
        if not self.log_file.exists():
            return []
        
        skills_stats = defaultdict(lambda: {
            "calls": 0, "input": 0, "output": 0, "total": 0
        })
        
        cutoff_ts = datetime.now().timestamp() - days * 86400
        
        try:
            with open(self.log_file, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        record = json.loads(line.strip())
                        ts = datetime.fromisoformat(record["timestamp"]).timestamp()
                        if ts < cutoff_ts:
                            continue
                        
                        skill = record.get("skill", "unknown")
                        skills_stats[skill]["calls"] += 1
                        skills_stats[skill]["input"] += record.get("input_tokens", 0)
                        skills_stats[skill]["output"] += record.get("output_tokens", 0)
                        skills_stats[skill]["total"] += record.get("total_tokens", 0)
                    except:
                        continue
        except:
            pass
        
        result = []
        for skill, stats in sorted(skills_stats.items(), key=lambda x: -x[1]["total"]):
            result.append({
                "skill": skill,
                **stats
            })
        
        return result
    
    def print_summary(self, days: int = 7):
        """打印统计摘要"""
        summary = self.get_summary(days=days)
        breakdown = self.get_action_breakdown(days=days)
        
        print(f"\n{'='*60}")
        print(f"[STAT] Token 消耗统计报告")
        print(f"{'='*60}")
        print(f"  Skill: {summary['skill']}")
        print(f"  统计周期: 最近 {days} 天")
        print(f"  总调用次数: {summary['total_calls']} 次")
        print(f"  Token 消耗:")
        print(f"    - 输入: {summary['total_input_tokens']:>12,} tokens")
        print(f"    - 输出: {summary['total_output_tokens']:>12,} tokens")
        print(f"    - 合计: {summary['total_tokens']:>12,} tokens")
        print(f"  平均每次调用: {summary['avg_tokens_per_call']:,} tokens")
        print(f"  平均执行时间: {summary['avg_duration_ms']:.0f} ms")
        
        if breakdown:
            print(f"\n[LIST] 操作分布:")
            print(f"  {'操作':<20} {'次数':>6} {'输入':>10} {'输出':>10} {'总计':>10}")
            print(f"  {'-'*58}")
            for action, stats in sorted(breakdown.items(), key=lambda x: -x[1]['total']):
                print(f"  {action:<20} {stats['calls']:>6} {stats['input']:>10,} {stats['output']:>10,} {stats['total']:>10,}")
        
        print(f"\n  {'='*60}")
        
        # 末尾信息
        print(f"\n[ROSE]有问题、建议、需求可[EMAIL] 联系作者QQ：1817694478[PENGUIN]加Q群：972156177交流分享更多...")
    
    def print_all_skills_summary(self, days: int = 7):
        """打印所有 skill 的统计摘要"""
        all_stats = self.get_all_skills_summary(days=days)
        
        print(f"\n{'='*60}")
        print(f"[STAT] 全局 Token 消耗统计 (最近 {days} 天)")
        print(f"{'='*60}")
        
        if not all_stats:
            print("  暂无数据")
        else:
            print(f"  {'Skill':<30} {'次数':>6} {'输入':>10} {'输出':>10} {'总计':>10}")
            print(f"  {'-'*68}")
            
            for stats in all_stats:
                print(f"  {stats['skill']:<30} {stats['calls']:>6} {stats['input']:>10,} {stats['output']:>10,} {stats['total']:>10,}")
            
            total_tokens = sum(s["total"] for s in all_stats)
            total_calls = sum(s["calls"] for s in all_stats)
            print(f"  {'-'*68}")
            print(f"  {'合计':<30} {total_calls:>6} {'':<10} {'':<10} {total_tokens:>10,}")
        
        print(f"\n  {'='*60}")
        print(f"\n[ROSE]有问题、建议、需求可[EMAIL] 联系作者QQ：1817694478[PENGUIN]加Q群：972156177交流分享更多...")


def main():
    """CLI 主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Token 消耗日志工具")
    parser.add_argument("--skill", default="skill-trend-analyzer", help="Skill 名称")
    parser.add_argument("--base-dir", default=None, help="基础目录")
    parser.add_argument("--days", type=int, default=7, help="统计天数")
    parser.add_argument("--action", help="记录操作")
    parser.add_argument("--input-tokens", type=int, default=0, help="输入 token 数")
    parser.add_argument("--output-tokens", type=int, default=0, help="输出 token 数")
    parser.add_argument("--duration-ms", type=int, default=0, help="执行耗时(毫秒)")
    parser.add_argument("--log", action="store_true", help="记录一条日志")
    parser.add_argument("--show", action="store_true", help="显示当前 skill 统计")
    parser.add_argument("--all", action="store_true", help="显示所有 skill 统计")
    parser.add_argument("--cleanup", action="store_true", help="清理旧记录")
    
    args = parser.parse_args()
    
    logger = TokenLogger(args.skill, args.base_dir)
    
    if args.log:
        # 记录日志
        tokens = {
            "input": args.input_tokens,
            "output": args.output_tokens,
            "total": args.input_tokens + args.output_tokens
        }
        record = logger.log(
            action=args.action or "cli_call",
            tokens=tokens,
            duration_ms=args.duration_ms
        )
        print(f"[OK] Logged: {record.action} - {record.total_tokens} tokens")
    
    elif args.show:
        # 显示当前 skill 统计
        logger.print_summary(days=args.days)
    
    elif args.all:
        # 显示所有 skill 统计
        logger.print_all_skills_summary(days=args.days)
    
    elif args.cleanup:
        # 清理旧记录
        count = logger.cleanup_old_records()
        print(f"[OK] Cleaned {count} old records")
    
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

# 版权信息
sys.stdout.buffer.write("\n[ROSE]联系作者QQ：1817694478[PENGUIN]Q群：972156177\n".encode("utf-8", errors="replace"))
