# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
# -*- coding: utf-8 -*-
"""
Skill Deep Cleaner v1.0 - 深度卸载 + 残余扫描清理
=====================================================
安全的skill深度卸载工具，具备完整确认机制、深度扫描、自动清理。

Features:
  - 7层安全检查 + 二次确认
  - 深度残余扫描：automations/config/logs/memory/cache/entries
  - 自动清理或预览模式
  - 使用 trash 而非 rm（可恢复）
  - 完整操作日志
  - --dry-run 预览模式
  - --deep-scan 深度扫描

Usage:
  python skill_cleaner.py <skill-name>           # 交互式卸载
  python skill_cleaner.py <skill-name> --dry-run # 预览所有操作
  python skill_cleaner.py <skill-name> --deep-scan --clean # 深度扫描并清理
  python skill_cleaner.py --list                 # 列出所有可卸载skill

Author: WorkBuddy AI
"""
import sys
import os
import json
import shutil
import subprocess
import argparse
import platform
import re
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Tuple, Optional

# ============================================================
# Configuration
# ============================================================

# 系统保护 skill 清单
PROTECTED_SKILLS = {
    "find-skills",           # skill发现工具
    "skillhub-preference",   # 偏好配置
}

# 敏感 skill 清单（额外警告）
SENSITIVE_SKILLS = {
    "skill-trend-analyzer",
    "student-goal-task-manager",
    "tax-risk-guard",
}

# Skill搜索路径（WorkBuddy标准路径）
SKILL_SEARCH_PATHS = [
    Path.home() / ".workbuddy" / "skills",
    Path.home() / ".qclaw" / "workspace" / "skills",
    Path.home() / ".qclaw" / "skills",
    Path.home() / ".openclaw" / "workspace" / "skills",
]

# WorkBuddy相关路径
WORKBUDDY_PATHS = {
    "automations": Path.home() / ".workbuddy" / "automations",
    "memory": Path.home() / ".workbuddy" / "memory",
    "logs": Path.home() / ".workbuddy" / "logs",
    "cache": Path.home() / ".workbuddy" / "cache",
    "config": Path.home() / ".workbuddy" / "config",
    "qclaw_logs": Path.home() / ".qclaw" / "logs",
}

# 日志文件
LOG_FILE = Path.home() / ".workbuddy" / "logs" / "skill_cleaner.log"

# ============================================================
# Safe I/O Utilities
# ============================================================

def safe_print(*args, **kwargs):
    """Safe print with encoding fallback for Windows."""
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        msg = " ".join(str(a) for a in args) + kwargs.get("end", "\n")
        sys.stdout.buffer.write(msg.encode("utf-8", errors="replace"))

def log_action(action: str, details: str = ""):
    """Log operation to file."""
    timestamp = datetime.now().isoformat()
    entry = f"[{timestamp}] {action}"
    if details:
        entry += f" | {details}"
    try:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8", errors="replace") as f:
            f.write(entry + "\n")
    except Exception:
        pass

# ============================================================
# Core Functions
# ============================================================

def find_skill_path(skill_name: str) -> Optional[Path]:
    """Find skill installation path."""
    for base_path in SKILL_SEARCH_PATHS:
        skill_path = base_path / skill_name
        if skill_path.exists() and skill_path.is_dir():
            return skill_path
    return None


def list_all_skills() -> List[Dict]:
    """List all installed skills with info."""
    skills = []
    for base_path in SKILL_SEARCH_PATHS:
        if not base_path.exists():
            continue
        for skill_dir in base_path.iterdir():
            if not skill_dir.is_dir():
                continue
            if skill_dir.name.startswith("."):
                continue
            info = get_skill_info(skill_dir)
            info["search_path"] = str(base_path)
            skills.append(info)
    return sorted(skills, key=lambda x: x["name"])


def get_skill_info(skill_path: Path) -> Dict:
    """Get skill metadata."""
    info = {
        "name": skill_path.name,
        "path": str(skill_path),
        "size_mb": 0,
        "file_count": 0,
        "version": "unknown",
        "description": "",
    }
    
    # Calculate size
    try:
        total = 0
        count = 0
        for root, _, files in os.walk(skill_path):
            for f in files:
                fp = Path(root) / f
                if fp.exists():
                    total += fp.stat().st_size
                    count += 1
        info["size_mb"] = round(total / (1024 * 1024), 2)
        info["file_count"] = count
    except Exception:
        pass
    
    # Read manifest
    manifest_path = skill_path / "manifest.json"
    if manifest_path.exists():
        try:
            with open(manifest_path, "r", encoding="utf-8", errors="replace") as f:
                manifest = json.load(f)
                info["version"] = manifest.get("version", "unknown")
        except Exception:
            pass
    
    # Read SKILL.md description
    skill_md = skill_path / "SKILL.md"
    if skill_md.exists():
        try:
            with open(skill_md, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
                for line in content.strip().split("\n")[:10]:
                    line = line.strip()
                    if line and not line.startswith("#") and not line.startswith("-"):
                        info["description"] = line[:80]
                        break
        except Exception:
            pass
    
    return info


def check_dependencies(skill_name: str) -> List[str]:
    """Check if other skills depend on this skill."""
    dependents = []
    for base_path in SKILL_SEARCH_PATHS:
        if not base_path.exists():
            continue
        for skill_dir in base_path.iterdir():
            if not skill_dir.is_dir() or skill_dir.name == skill_name:
                continue
            manifest_path = skill_dir / "manifest.json"
            if manifest_path.exists():
                try:
                    with open(manifest_path, "r", encoding="utf-8", errors="replace") as f:
                        manifest = json.load(f)
                        deps = manifest.get("dependencies", [])
                        if skill_name in deps:
                            dependents.append(skill_dir.name)
                except Exception:
                    pass
            # Check SKILL.md references
            skill_md = skill_dir / "SKILL.md"
            if skill_md.exists():
                try:
                    with open(skill_md, "r", encoding="utf-8", errors="replace") as f:
                        content = f.read()
                        if f"\"{skill_name}\"" in content or f"'{skill_name}'" in content:
                            if skill_dir.name not in dependents:
                                dependents.append(f"{skill_dir.name} (引用)")
                except Exception:
                    pass
    return dependents


def check_process_usage(skill_path: Path) -> List[str]:
    """Check if any process is using this skill's files."""
    usage_info = []
    test_file = skill_path / ".write_test"
    try:
        with open(test_file, "w") as f:
            f.write("test")
        test_file.unlink()
    except PermissionError:
        usage_info.append("文件被锁定（可能Python进程正在使用）")
    except Exception as e:
        if "denied" in str(e).lower():
            usage_info.append("权限被拒绝")
    return usage_info


def scan_residuals(skill_name: str) -> Dict[str, List[Dict]]:
    """
    Deep scan for residual files after skill uninstallation.
    
    Returns dict with categories:
      - automations: automation configs referencing this skill
      - memory: memory files mentioning this skill
      - logs: log files with this skill's name
      - cache: cache files
      - entries: skill entry points
      - configs: other config files
    """
    residuals = {
        "automations": [],
        "memory": [],
        "logs": [],
        "cache": [],
        "entries": [],
        "configs": [],
    }
    
    # Pattern: skill name with common separators
    patterns = [
        re.escape(skill_name),
        skill_name.replace("-", "[_\\-]"),
        skill_name.replace("-", ""),
    ]
    
    # 1. Scan automations
    auto_dir = WORKBUDDY_PATHS["automations"]
    if auto_dir.exists():
        for auto_path in auto_dir.rglob("*.toml"):
            try:
                content = auto_path.read_text(encoding="utf-8", errors="replace")
                if any(re.search(p, content, re.IGNORECASE) for p in patterns):
                    residuals["automations"].append({
                        "path": str(auto_path),
                        "reason": "automation引用此skill",
                    })
            except Exception:
                pass
    
    # 2. Scan memory files
    memory_dir = WORKBUDDY_PATHS["memory"]
    if memory_dir.exists():
        for mem_path in memory_dir.rglob("*.md"):
            try:
                content = mem_path.read_text(encoding="utf-8", errors="replace")
                if any(re.search(p, content, re.IGNORECASE) for p in patterns):
                    # Calculate relevance
                    matches = len(re.findall(re.escape(skill_name), content, re.IGNORECASE))
                    residuals["memory"].append({
                        "path": str(mem_path),
                        "reason": f"提及此skill {matches} 次",
                        "matches": matches,
                    })
            except Exception:
                pass
    
    # 3. Scan log files (last 30 days)
    log_dir = WORKBUDDY_PATHS["logs"]
    if log_dir.exists():
        cutoff = datetime.now() - timedelta(days=30)
        for log_path in log_dir.rglob("*.log"):
            try:
                mtime = datetime.fromtimestamp(log_path.stat().st_mtime)
                if mtime > cutoff:
                    content = log_path.read_text(encoding="utf-8", errors="replace")
                    if any(re.search(p, content, re.IGNORECASE) for p in patterns):
                        residuals["logs"].append({
                            "path": str(log_path),
                            "reason": "日志提及此skill",
                            "size_kb": round(log_path.stat().st_size / 1024, 1),
                        })
            except Exception:
                pass
    
    # 4. Scan QClaw logs
    qclaw_log_dir = WORKBUDDY_PATHS["qclaw_logs"]
    if qclaw_log_dir.exists():
        for log_path in qclaw_log_dir.rglob("*.log"):
            try:
                content = log_path.read_text(encoding="utf-8", errors="replace")
                if any(re.search(p, content, re.IGNORECASE) for p in patterns):
                    residuals["logs"].append({
                        "path": str(log_path),
                        "reason": "QClaw日志提及此skill",
                        "size_kb": round(log_path.stat().st_size / 1024, 1),
                    })
            except Exception:
                pass
    
    # 5. Scan cache
    cache_dir = WORKBUDDY_PATHS["cache"]
    if cache_dir.exists():
        for cache_path in cache_dir.rglob("*"):
            if cache_path.is_file() and skill_name.lower() in cache_path.name.lower():
                residuals["cache"].append({
                    "path": str(cache_path),
                    "reason": "缓存文件",
                    "size_kb": round(cache_path.stat().st_size / 1024, 1),
                })
    
    # 6. Scan skill entries (if skill removed but entry remains)
    for base_path in SKILL_SEARCH_PATHS:
        entries_dir = base_path.parent / "entries"
        if entries_dir.exists():
            for entry_path in entries_dir.rglob("*"):
                if skill_name.lower() in entry_path.name.lower():
                    residuals["entries"].append({
                        "path": str(entry_path),
                        "reason": "入口文件残留",
                        "size_kb": round(entry_path.stat().st_size / 1024, 1),
                    })
    
    # 7. Scan config files
    config_dir = WORKBUDDY_PATHS["config"]
    if config_dir.exists():
        for cfg_path in config_dir.rglob("*.json"):
            if skill_name.lower() in cfg_path.name.lower():
                residuals["configs"].append({
                    "path": str(cfg_path),
                    "reason": "配置文件残留",
                    "size_kb": round(cfg_path.stat().st_size / 1024, 1),
                })
    
    return residuals


def get_residual_size(residuals: Dict) -> Tuple[float, int]:
    """Calculate total size and count of residuals."""
    total_kb = 0
    count = 0
    for category, items in residuals.items():
        for item in items:
            total_kb += item.get("size_kb", 0)
            count += 1
    return round(total_kb / 1024, 2), count  # MB, count


def move_to_trash(path: Path) -> Tuple[bool, str]:
    """Move file/directory to trash (recoverable)."""
    system = platform.system()
    try:
        if system == "Windows":
            try:
                import send2trash
                send2trash.send2trash(str(path))
                return True, "回收站"
            except ImportError:
                trash_dir = Path.home() / ".workbuddy" / ".trash"
                trash_dir.mkdir(parents=True, exist_ok=True)
                dest = trash_dir / f"{path.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                shutil.move(str(path), str(dest))
                return True, str(dest)
        elif system == "Darwin":
            try:
                subprocess.run(["trash", str(path)], check=True, timeout=10)
                return True, "回收站"
            except Exception:
                pass
            trash_dir = Path.home() / ".Trash"
            dest = trash_dir / f"{path.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.move(str(path), str(dest))
            return True, str(dest)
        else:  # Linux
            try:
                subprocess.run(["gio", "trash", str(path)], check=True, timeout=10)
                return True, "回收站"
            except Exception:
                pass
            trash_dir = Path.home() / ".workbuddy" / ".trash"
            trash_dir.mkdir(parents=True, exist_ok=True)
            dest = trash_dir / f"{path.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.move(str(path), str(dest))
            return True, str(dest)
    except Exception as e:
        return False, str(e)


def create_backup(skill_path: Path) -> Tuple[bool, str]:
    """Create backup of skill before uninstall."""
    backup_dir = Path.home() / ".workbuddy" / "skill_backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"{skill_path.name}_{timestamp}.zip"
    try:
        shutil.make_archive(str(backup_path.with_suffix("")), "zip", str(skill_path))
        return True, str(backup_path)
    except Exception as e:
        return False, str(e)


def clean_residuals(residuals: Dict, dry_run: bool = True) -> Dict[str, bool]:
    """Clean up residual files."""
    results = {}
    for category, items in residuals.items():
        results[category] = True
        for item in items:
            path = Path(item["path"])
            if dry_run:
                safe_print(f"  [DRY] 将清理: {path}")
            else:
                try:
                    if path.is_file():
                        ok, msg = move_to_trash(path)
                    elif path.is_dir():
                        ok, msg = move_to_trash(path)
                    else:
                        ok, msg = False, "路径不存在"
                    if ok:
                        safe_print(f"  [OK] 已清理: {path.name}")
                    else:
                        safe_print(f"  [FAIL] 清理失败: {msg}")
                        results[category] = False
                except Exception as e:
                    safe_print(f"  [ERROR] {e}")
                    results[category] = False
    return results


# ============================================================
# Main Logic
# ============================================================

def uninstall_skill(skill_name: str, args) -> int:
    """Main uninstallation logic."""
    safe_print("\n" + "=" * 64)
    safe_print("  Skill Deep Cleaner v1.0")
    safe_print("=" * 64 + "\n")
    
    # Step 1: Check protected
    if skill_name in PROTECTED_SKILLS:
        safe_print("[ERROR] 此skill受系统保护，禁止卸载！")
        for s in sorted(PROTECTED_SKILLS):
            safe_print(f"  - {s}")
        return 1
    
    # Step 2: Find skill
    skill_path = find_skill_path(skill_name)
    if not skill_path:
        safe_print(f"[ERROR] 未找到skill: {skill_name}")
        safe_print("\n搜索路径:")
        for p in SKILL_SEARCH_PATHS:
            safe_print(f"  - {p}")
        return 1
    
    # Step 3: Get skill info
    info = get_skill_info(skill_path)
    safe_print("[INFO] Skill信息:")
    safe_print(f"  名称: {info['name']}")
    safe_print(f"  版本: {info['version']}")
    safe_print(f"  路径: {info['path']}")
    safe_print(f"  大小: {info['size_mb']} MB")
    safe_print(f"  文件: {info['file_count']} 个")
    if info['description']:
        safe_print(f"  描述: {info['description']}")
    safe_print()
    
    # Step 4: Dependency check
    dependents = check_dependencies(skill_name)
    if dependents:
        safe_print("[WARN] 依赖警告:")
        for d in dependents[:5]:
            safe_print(f"  - {d}")
        if len(dependents) > 5:
            safe_print(f"  ... 还有 {len(dependents) - 5} 个")
        safe_print()
    
    # Step 5: Process usage check
    usage = check_process_usage(skill_path)
    if usage:
        safe_print("[WARN] 进程占用:")
        for u in usage:
            safe_print(f"  - {u}")
        if not args.force:
            safe_print("[ERROR] 请先关闭相关进程")
            return 1
        safe_print()
    
    # Step 6: Sensitive skill warning
    if skill_name in SENSITIVE_SKILLS:
        safe_print("[CAUTION] 敏感skill警告:")
        safe_print(f"  '{skill_name}' 被标记为敏感，可能会影响其他功能")
        safe_print()
    
    # Step 7: Deep scan for residuals
    safe_print("[SCAN] 深度扫描残余文件...")
    residuals = scan_residuals(skill_name)
    total_mb, total_count = get_residual_size(residuals)
    
    if total_count > 0:
        safe_print(f"\n[FOUND] 发现 {total_count} 处残余:")
        for cat, items in residuals.items():
            if items:
                safe_print(f"\n  [{cat}] {len(items)} 项:")
                for item in items[:3]:  # Show first 3
                    safe_print(f"    - {Path(item['path']).name}: {item['reason']}")
                if len(items) > 3:
                    safe_print(f"    ... 还有 {len(items) - 3} 项")
    else:
        safe_print("[OK] 未发现残余文件")
    safe_print(f"\n残余总计: {total_mb:.2f} MB / {total_count} 项")
    safe_print()
    
    # Step 8: Backup if requested
    if args.backup and not args.dry_run:
        safe_print("[BACKUP] 创建备份...")
        ok, result = create_backup(skill_path)
        if ok:
            safe_print(f"[OK] 备份已创建: {result}")
            log_action("BACKUP", f"{skill_name} -> {result}")
        else:
            safe_print(f"[WARN] 备份失败: {result}")
        safe_print()
    
    # Step 9: Confirm
    if not args.yes and not args.dry_run:
        safe_print("[CONFIRM] 确认卸载:")
        safe_print(f"  Skill: {skill_name}")
        safe_print(f"  路径: {info['path']}")
        safe_print(f"  残余: {total_count} 项 ({total_mb:.2f} MB)")
        safe_print()
        if args.deep_scan:
            safe_print("  将执行: 1)卸载skill 2)清理残余")
        else:
            safe_print("  将执行: 仅卸载skill（使用 --deep-scan 清理残余）")
        safe_print()
        safe_print("输入 'YES' 确认，或其他内容取消:")
        try:
            confirm = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            safe_print("\n[ABORT] 已取消")
            return 2
        if confirm != "YES":
            safe_print("[ABORT] 已取消")
            return 2
        safe_print()
    
    # Step 10: Execute
    if args.dry_run:
        safe_print("[DRY-RUN] 预览模式:")
        safe_print(f"  1. [DRY] 将卸载: {skill_path}")
        if args.deep_scan and total_count > 0:
            safe_print(f"  2. [DRY] 将清理 {total_count} 处残余")
        return 0
    
    # Uninstall skill
    safe_print("[STEP 1/2] 卸载skill...")
    ok, msg = move_to_trash(skill_path)
    if ok:
        safe_print(f"[OK] Skill已移至: {msg}")
        log_action("UNINSTALLED", skill_name)
    else:
        safe_print(f"[FAIL] {msg}")
        return 1
    
    # Clean residuals
    if args.deep_scan and total_count > 0:
        safe_print("\n[STEP 2/2] 清理残余...")
        clean_residuals(residuals, dry_run=False)
    
    safe_print("\n" + "=" * 64)
    safe_print("  [SUCCESS] 卸载完成！")
    safe_print("=" * 64)
    safe_print("\n提示:")
    safe_print("  - 如需恢复，从回收站还原")
    safe_print("  - 如需彻底删除，清空回收站")
    
    return 0


def main():
    parser = argparse.ArgumentParser(
        description="Skill深度卸载工具 - 安全、可恢复、深度清理残余",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s skill-name --dry-run              # 预览卸载
  %(prog)s skill-name --deep-scan             # 深度扫描+卸载
  %(prog)s skill-name --deep-scan --clean     # 深度扫描+卸载+清理残余
  %(prog)s --list                             # 列出所有skill

安全机制:
  - 系统保护skill禁止卸载
  - 默认使用回收站（可恢复）
  - 7层安全检查 + 二次确认
  - 自动深度扫描残余文件
        """
    )
    
    parser.add_argument("skill_name", nargs="?", help="要卸载的skill名称")
    parser.add_argument("--list", "-l", action="store_true", help="列出所有已安装skill")
    parser.add_argument("--dry-run", "-n", action="store_true", help="预览模式")
    parser.add_argument("--yes", "-y", action="store_true", help="跳过确认")
    parser.add_argument("--force", "-f", action="store_true", help="强制模式")
    parser.add_argument("--backup", "-b", action="store_true", help="卸载前备份")
    parser.add_argument("--deep-scan", "-d", action="store_true", help="深度扫描残余")
    parser.add_argument("--clean", "-c", action="store_true", help="清理残余（需配合--deep-scan）")
    
    args = parser.parse_args()
    
    # List mode
    if args.list:
        safe_print("\n" + "=" * 64)
        safe_print("  已安装的Skills")
        safe_print("=" * 64 + "\n")
        skills = list_all_skills()
        if not skills:
            safe_print("[INFO] 未找到任何skill")
            return 0
        for i, s in enumerate(skills, 1):
            protected = "[PROTECTED]" if s["name"] in PROTECTED_SKILLS else ""
            safe_print(f"{i:2}. {s['name']} {protected}")
            safe_print(f"    版本: {s['version']} | 大小: {s['size_mb']} MB | 路径: {s.get('search_path', 'N/A')}")
            if s['description']:
                safe_print(f"    描述: {s['description']}")
            safe_print()
        return 0
    
    # Require skill name
    if not args.skill_name:
        safe_print("[ERROR] 请指定skill名称，或使用 --list 查看所有skill")
        return 1
    
    # Deep scan implies cleaning
    if args.deep_scan:
        args.clean = True
    
    # Execute
    exit_code = uninstall_skill(args.skill_name, args)
    
    safe_print("\n" + "-" * 64)
    safe_print("Skill Deep Cleaner v1.0 | 安全卸载，可恢复")
    safe_print("-" * 64)
    
    # Author footer (ASCII only)
    sys.stdout.buffer.write(b"\nAuthor: QQ 1817694478 | Q-Group 972156177\n")
    
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
