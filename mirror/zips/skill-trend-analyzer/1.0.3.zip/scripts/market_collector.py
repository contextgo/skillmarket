#!/usr/bin/env python3
# Copyright (c) 2026 ZXJ@DEVS. Author: QQ 1817694478 | Q-Group: 972156177
# Skill: skill-trend-analyzer | Version: 2.3.0
"""
Market Data Collector for Skill Trend Analyzer
================================================
Periodically crawls skill marketplaces to collect hot skill metadata:
name, slug, description, keywords, triggers, ratings, download counts.
Stores as local JSON for trend analysis.

Supported marketplaces (6 sources):
  1. clawhub       - ClawHub search CLI (clawdhub search)
  2. skills_sh     - skills.sh 静态HTML排行榜 (~269 skills)
  3. aiphys        - skill.aiphys.cn REST API (JSON)
  4. skillmarket   - skillmarket.cc 静态HTML
  5. skillmarket_pi - skill-market-pi.vercel.app (SPA, Playwright)
  6. trusttools    - trusttools.seebug.ai (SPA, Playwright)
  7. skillhub_cn   - skillhub.cn (SPA, Playwright)

Features:
  - Multi-source parallel collection
  - Multi-category search (40+ domain queries for ClawHub)
  - Incremental update (only fetch new/changed skills)
  - Data decay (older data gets less weight)
  - Rate limiting (respect API limits)
  - Deduplication (MD5 fingerprint)

Usage:
  python market_collector.py [--full] [--verbose]
  python market_collector.py --status
  python market_collector.py --sources skills_sh aiphys  # 指定数据源
  python market_collector.py --sources skillmarket_pi trusttools skillhub_cn  # SPA站
"""
import sys, io, os, re, json, hashlib, time, math, random
from pathlib import Path
from datetime import datetime, timedelta
from collections import Counter, defaultdict
from typing import Optional

# [Safe Guard: 5-layer anti-freeze system]
from safe_guard import safe_print, safe_init, TimeoutGuard, safe_subprocess, safe_read_json
from exec_logger import ExecutionLogger
safe_init()





# Optional: requests for REST API collectors
try:
    import requests as _requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False

# Optional: BeautifulSoup for HTML parsers
try:
    from bs4 import BeautifulSoup as _BS
    _HAS_BS4 = True
except ImportError:
    _HAS_BS4 = False

# ============================================================
# Configuration
# ============================================================

SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

# Cache files
MARKET_CACHE = DATA_DIR / "market_cache.json"        # Raw market skill data
KEYWORD_FREQ = DATA_DIR / "keyword_frequency.json"    # Aggregated keyword frequencies
TRIGGER_PATTERNS = DATA_DIR / "trigger_patterns.json"  # Extracted trigger patterns
TREND_HISTORY = DATA_DIR / "trend_history.json"       # Historical trend snapshots
COLLECT_LOG = DATA_DIR / "collect_log.json"           # Collection log

# Decay factor: data older than N days gets weight *= decay^N
DECAY_LAMBDA = 0.02  # ~50% weight after 35 days

# Rate limiting（已被 ClawHubRateLimiter 替代，此处保留兼容性）
MAX_SEARCHES_PER_RUN = 30  # 每轮最多搜索次数（由限流器控制分钟/小时硬限制）

# Search query categories for comprehensive market coverage
SEARCH_CATEGORIES = {
    "tax_finance": [
        "tax finance accounting", "invoice billing receipt",
        "compliance audit regulation", "financial report analysis",
        "tax planning deduction", "corporate tax risk",
        "bookkeeping ledger", "payroll salary",
    ],
    "business_management": [
        "business management project", "contract agreement legal",
        "workflow automation process", "hr employee recruitment",
        "crm customer sales", "inventory warehouse supply",
    ],
    "ai_productivity": [
        "AI assistant chatbot", "productivity automation tools",
        "writing content generation", "data analysis visualization",
        "email communication management", "scheduling calendar task",
    ],
    "development": [
        "code developer programming", "testing deployment CI CD",
        "API integration webhook", "database SQL query",
        "security authentication encryption",
    ],
    "lifestyle": [
        "health fitness workout", "food recipe cooking",
        "travel booking hotel", "education learning study",
        "shopping ecommerce store",
    ],
    "chinese_domain": [
        "税务 发票 合规", "财务 会计 记账", "企业 管理 合同",
        "风险 预警 稽查", "社保 个税 工资", "银行 流水 对账",
        "学习 规划 目标", "搜索 资源 影视",
    ],
}


# ============================================================
# ClawHub API 防封禁机制（移植自 dragon-skill-hub）
# ============================================================

_CLAWHUB_RATE_LIMIT = {
    "requests_per_minute": 3,   # 每分钟最多3次
    "requests_per_hour": 20,    # 每小时最多20次
    "min_interval": 1.0,       # 随机等待下限（秒）
    "max_interval": 3.0,        # 随机等待上限（秒）
    "cache_ttl": 300,           # 缓存有效期（秒）
}


class ClawHubRateLimiter:
    """ClawHub API 频率限制器，防止被封禁"""

    def __init__(self, skill_name="skill-trend-analyzer"):
        self.config = _CLAWHUB_RATE_LIMIT
        self.home = Path.home()
        state_dir = self.home / ".workbuddy" / "skills" / skill_name / "data"
        state_dir.mkdir(parents=True, exist_ok=True)
        self.state_file = state_dir / "clawhub_rate_limit.json"
        self.cache_file = state_dir / "clawhub_search_cache.json"
        self.state = self._load_state()
        self.cache = self._load_cache()
        self._check_cooldown()

    def _load_state(self) -> dict:
        if self.state_file.exists():
            try:
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return {"minute_requests": [], "hour_requests": [], "backoff_until": None, "backoff_count": 0}

    def _save_state(self):
        now = datetime.now()
        cutoff_minute = (now - timedelta(minutes=1)).isoformat()
        cutoff_hour = (now - timedelta(hours=1)).isoformat()
        self.state["minute_requests"] = [t for t in self.state.get("minute_requests", []) if t > cutoff_minute]
        self.state["hour_requests"] = [t for t in self.state.get("hour_requests", []) if t > cutoff_hour]
        with open(self.state_file, 'w', encoding='utf-8') as f:
            json.dump(self.state, f, ensure_ascii=False, indent=2)

    def _load_cache(self) -> dict:
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save_cache(self):
        now = datetime.now()
        cutoff = (now - timedelta(seconds=self.config["cache_ttl"])).isoformat()
        self.cache = {k: v for k, v in self.cache.items() if v.get("cached_at", "") > cutoff}
        with open(self.cache_file, 'w', encoding='utf-8') as f:
            json.dump(self.cache, f, ensure_ascii=False, indent=2)

    def _check_cooldown(self):
        backoff_until = self.state.get("backoff_until")
        if backoff_until:
            try:
                backoff_time = datetime.fromisoformat(backoff_until)
                if datetime.now() < backoff_time:
                    remaining = (backoff_time - datetime.now()).total_seconds()
                    safe_print(f"[WARNING] ClawHub API in cooldown: {remaining:.0f}s remaining")
            except Exception:
                pass

    def _make_cache_key(self, keyword: str) -> str:
        return hashlib.md5(keyword.encode()).hexdigest()[:12]

    def can_proceed(self) -> tuple:
        """检查是否可以发起请求，返回 (can_proceed, reason, wait_seconds)"""
        self._save_state()
        now = datetime.now()
        backoff_until = self.state.get("backoff_until")
        if backoff_until:
            try:
                backoff_time = datetime.fromisoformat(backoff_until)
                if now < backoff_time:
                    remaining = (backoff_time - now).total_seconds()
                    return False, "in_backoff", max(0.1, remaining)
            except Exception:
                pass
        minute_count = len(self.state.get("minute_requests", []))
        if minute_count >= self.config["requests_per_minute"]:
            oldest = min(self.state["minute_requests"])
            wait = (datetime.fromisoformat(oldest) + timedelta(minutes=1) - now).total_seconds()
            return False, "minute_limit", max(0.1, wait)
        hour_count = len(self.state.get("hour_requests", []))
        if hour_count >= self.config["requests_per_hour"]:
            oldest = min(self.state["hour_requests"])
            wait = (datetime.fromisoformat(oldest) + timedelta(hours=1) - now).total_seconds()
            return False, "hour_limit", max(0.1, wait)
        return True, "ok", 0

    def get_cached(self, keyword: str) -> Optional[list]:
        """获取缓存的搜索结果（返回 entry 列表）"""
        key = self._make_cache_key(keyword)
        entry = self.cache.get(key)
        if entry:
            cached_at = datetime.fromisoformat(entry["cached_at"])
            if datetime.now() - cached_at < timedelta(seconds=self.config["cache_ttl"]):
                return entry["result"]
        return None

    def set_cached(self, keyword: str, result: list):
        """缓存搜索结果"""
        key = self._make_cache_key(keyword)
        self.cache[key] = {
            "keyword": keyword,
            "result": result,
            "cached_at": datetime.now().isoformat(),
        }
        self._save_cache()

    def record_request(self):
        """记录一次请求"""
        self.state.setdefault("minute_requests", []).append(datetime.now().isoformat())
        self.state.setdefault("hour_requests", []).append(datetime.now().isoformat())
        self._save_state()

    def record_rate_limit(self):
        """记录遇到限流，触发指数退避"""
        backoff_seconds = 30 * (2 ** self.state.get("backoff_count", 0))
        backoff_seconds = min(backoff_seconds, 3600)
        self.state["backoff_count"] = self.state.get("backoff_count", 0) + 1
        self.state["backoff_until"] = (datetime.now() + timedelta(seconds=backoff_seconds)).isoformat()
        self._save_state()
        safe_print(f"[WARNING] ClawHub rate limited! Backoff {backoff_seconds}s, count: {self.state['backoff_count']}")

    def record_success(self):
        """请求成功，重置退避计数"""
        if self.state.get("backoff_count", 0) > 0:
            self.state["backoff_count"] = 0
            self.state["backoff_until"] = None
            self._save_state()

    def force_wait(self):
        """强制等待（随机间隔）"""
        can_proceed, reason, wait = self.can_proceed()
        if can_proceed:
            wait = random.uniform(self.config["min_interval"], self.config["max_interval"])
        if wait > 0:
            safe_print(f"[INFO] Waiting {wait:.1f}s before ClawHub request...")
            time.sleep(wait)

    def get_status(self) -> dict:
        """获取限流状态"""
        self._save_state()
        return {
            "minute_requests": len(self.state.get("minute_requests", [])),
            "hour_requests": len(self.state.get("hour_requests", [])),
            "in_cooldown": self.state.get("backoff_until") is not None,
            "backoff_until": self.state.get("backoff_until"),
            "backoff_count": self.state.get("backoff_count", 0),
            "cache_entries": len(self.cache),
        }


_rate_limiter = None


def _get_rate_limiter(skill_name="skill-trend-analyzer") -> ClawHubRateLimiter:
    global _rate_limiter
    if _rate_limiter is None:
        _rate_limiter = ClawHubRateLimiter(skill_name=skill_name)
    return _rate_limiter


# ============================================================
# ClawHub Search Interface
# ============================================================



class ClawHubSearcher:
    """Interface to ClawHub search API via CLI (with anti-ban rate limiter)."""

    def __init__(self, verbose=False):
        self.verbose = verbose
        self.limiter = _get_rate_limiter()

    def search(self, query, limit=20):
        """Execute ClawHub search with rate limiting and caching."""
        # 1. 命中缓存
        cached = self.limiter.get_cached(query)
        if cached is not None:
            if self.verbose:
                safe_print(f"  [CACHE] '{query}' -> {len(cached)} entries")
            return cached

        # 2. 频率检查
        can_proceed, reason, wait = self.limiter.can_proceed()
        if not can_proceed:
            safe_print(f"[WARNING] ClawHub search blocked ({reason}) for '{query}', try again later")
            return []

        # 3. 强制等待（随机间隔）
        self.limiter.force_wait()

        # 4. 记录请求
        self.limiter.record_request()

        # 5. 发起搜索
        import subprocess
        try:
            if sys.platform == 'win32':
                cmd = ["cmd", "/c", "npx", "clawdhub", "search", query,
                       "--limit", str(limit)]
            else:
                cmd = ["npx", "clawdhub", "search", query,
                       "--limit", str(limit)]

            result = safe_subprocess(cmd, timeout=30)
            if not result['success']:
                if result['timed_out']:
                    safe_print(f"[TIMEOUT] npx clawdhub search stuck for '{query}'")
                return []

            # 检测限流信号
            stderr_lower = result.get('stderr', '').lower()
            if "rate limit" in stderr_lower or "429" in stderr_lower or "banned" in stderr_lower:
                self.limiter.record_rate_limit()
                safe_print(f"[WARNING] ClawHub rate limit signal detected for '{query}'")
                return []

            # 解析结果
            entries = []
            for line in result['stdout'].strip().split('\n'):
                m = re.match(r'(\S+)\s+(.+?)\s+\(([0-9.]+)\)', line.strip())
                if m:
                    slug = m.group(1)
                    name = m.group(2).strip()
                    relevance = float(m.group(3))
                    entries.append({
                        'slug': slug,
                        'name': name,
                        'relevance': relevance,
                        'source': 'clawhub',
                        'query': query,
                        'collected_at': datetime.now().isoformat(),
                    })

            # 缓存成功结果
            if entries:
                self.limiter.set_cached(query, entries)
                self.limiter.record_success()

            return entries

        except Exception as e:
            if self.verbose:
                safe_print(f"[WARNING] Search error for '{query}': {e}")
            return []




# ============================================================
# 通用 HTTP 工具
# ============================================================

def _safe_fetch(url, timeout=15, headers=None):
    """通用的 HTTP GET，带超时和异常处理。"""
    if not _HAS_REQUESTS:
        return None
    try:
        resp = _requests.get(url, timeout=timeout, headers=headers or {}, verify=False)
        resp.raise_for_status()
        return resp
    except Exception as e:
        safe_print(f"[WARNING] HTTP fetch failed for {url}: {e}")
        return None


# ============================================================
# SPA 站点 Playwright 采集器（共享逻辑）
# ============================================================

# Playwright 辅助脚本模板（node.js）
_PLAYWRIGHT_SCRAPE_TEMPLATE = r"""
const {{ chromium }} = require('playwright');
const fs = require('fs');
const path = require('path');

async function scrapeSPA(url, selectors, outputPath) {{
    const browser = await chromium.launch({{ headless: true }});
    const page = await browser.newPage();

    // 设置 User-Agent
    await page.setExtraHTTPHeaders({{
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }});

    try {{
        await page.goto(url, {{ waitUntil: 'networkidle', timeout: 30000 }});
        // 额外等待内容渲染
        await page.waitForTimeout(3000);

        const results = [];

        // 按 selectors 提取
        for (const sel of selectors) {{
            const els = await page.$$(sel);
            for (const el of els) {{
                const name = await el.$eval('self, [class*="name"], [class*="title"], [class*="heading"], h1, h2, h3, a', e => e.innerText.trim()).catch(() => '');
                const desc = await el.$eval('[class*="desc"], [class*="description"], [class*="summary"], p', e => e.innerText.trim()).catch(() => '');
                const href = await el.$eval('a[href]', e => e.getAttribute('href')).catch(() => '');

                if (name && name.length < 200) {{
                    results.push({{ name, desc, href }});
                }}
            }}
        }}

        // 兜底：提取页面中所有链接文本
        if (results.length === 0) {{
            const links = await page.$$eval('a[href]', links =>
                links.map(a => ({{
                    name: a.innerText.trim(),
                    href: a.href,
                    desc: ''
                }})).filter(x => x.name && x.name.length < 100 && x.name.length > 1)
            );
            results.push(...links.slice(0, 200));
        }}

        fs.writeFileSync(outputPath, JSON.stringify(results, null, 2), 'utf-8');
        console.log('OK:' + results.length);
    }} catch (e) {{
        fs.writeFileSync(outputPath, JSON.stringify([]), 'utf-8');
        console.error('ERROR:' + e.message);
    }} finally {{
        await browser.close();
    }}
}}

const [url, selectorsStr, outputPath] = process.argv.slice(2);
const selectors = selectorsStr ? selectorsStr.split('|') : ['[class*="skill"]', '[class*="card"]', 'article'];
scrapeSPA(url, selectors, outputPath || '/tmp/spa_scrape.json');
"""


class SPACollector:
    """
    使用 Playwright 采集 SPA 动态渲染页面。
    先写临时 JS 脚本，再通过 subprocess 调用 node 执行。
    """

    SOURCE = 'spa_generic'

    def __init__(self, source_name, url, selectors=None, verbose=False):
        self.source_name = source_name
        self.url = url
        self.selectors = selectors or ['[class*="skill"]', '[class*="card"]', 'article']
        self.verbose = verbose

    def _run_playwright(self, tmp_js_path, tmp_out_path):
        """通过 node 执行 Playwright 脚本。"""
        node_cmd = (
            f'cd /d "{os.path.dirname(tmp_js_path)}" && '
            f'node "{tmp_js_path}" "{self.url}" "{"|".join(self.selectors)}" "{tmp_out_path}"'
        )
        if sys.platform == 'win32':
            result = safe_subprocess(['cmd', '/c', node_cmd], timeout=60)
        else:
            result = safe_subprocess(['bash', '-c', node_cmd], timeout=60)
        return result

    def collect(self):
        """执行 Playwright 采集。"""
        entries = []
        tmp_dir = os.environ.get('TEMP', os.environ.get('TMP', '/tmp'))
        tmp_js = os.path.join(tmp_dir, f'pw_scrape_{self.source_name}.js')
        tmp_out = os.path.join(tmp_dir, f'pw_out_{self.source_name}.json')

        # 写入 JS 脚本
        js_content = _PLAYWRIGHT_SCRAPE_TEMPLATE.replace('{', '{{').replace('}', '}}')
        js_content = js_content.replace('{{', '{').replace('}}', '}')
        js_content = _PLAYWRIGHT_SCRAPE_TEMPLATE

        try:
            Path(tmp_js).write_text(js_content, encoding='utf-8')
        except Exception as e:
            safe_print(f"[WARNING] {self.SOURCE}: Failed to write playwright script: {e}")
            return entries

        result = self._run_playwright(tmp_js, tmp_out)

        # 读取结果
        try:
            if Path(tmp_out).exists():
                data = json.loads(Path(tmp_out).read_text(encoding='utf-8'))
                for item in data:
                    href = item.get('href', '')
                    slug = href.strip('/').split('/')[-1] if href else item.get('name', '').lower().replace(' ', '-')
                    entries.append({
                        'slug': slug[:100],
                        'name': item.get('name', '')[:200],
                        'description': item.get('desc', '')[:500],
                        'relevance': 1.0,
                        'source': self.source_name,
                        'url': href if href.startswith('http') else f'{self.url.rstrip("/")}{href}',
                        'collected_at': datetime.now().isoformat(),
                    })
        except Exception as e:
            safe_print(f"[WARNING] {self.SOURCE}: Failed to read output: {e}")

        # 清理临时文件
        for fp in [tmp_js, tmp_out]:
            try:
                Path(fp).unlink(missing_ok=True)
            except:
                pass

        if self.verbose:
            safe_print(f"[OK] {self.source_name}: collected {len(entries)} skills")
        return entries


# ============================================================
# 具体 SPA 采集器快捷类
# ============================================================

class SkillMarketPiCollector(SPACollector):
    """采集 https://skill-market-pi.vercel.app/"""
    def __init__(self, verbose=False):
        super().__init__(
            source_name='skillmarket_pi',
            url='https://skill-market-pi.vercel.app/',
            selectors=['[class*="skill"]', '[class*="card"]', 'article', '[class*="item"]'],
            verbose=verbose,
        )


class TrustToolsCollector(SPACollector):
    """采集 https://trusttools.seebug.ai/"""
    def __init__(self, verbose=False):
        super().__init__(
            source_name='trusttools',
            url='https://trusttools.seebug.ai/',
            selectors=['[class*="skill"]', '[class*="card"]', 'article', '[class*="item"]', '[class*="list"]'],
            verbose=verbose,
        )


class SkillHubCnCollector(SPACollector):
    """采集 https://skillhub.cn/"""
    def __init__(self, verbose=False):
        super().__init__(
            source_name='skillhub_cn',
            url='https://skillhub.cn/',
            selectors=['[class*="skill"]', '[class*="card"]', 'article', '[class*="item"]', '[class*="list"]'],
            verbose=verbose,
        )


# ============================================================
# Skills.sh 静态 HTML 采集器
# ============================================================

class SkillsShCollector(SPACollector):
    """
    采集 https://skills.sh 排行榜页面的 skill 数据。
    该站为 Next.js 客户端渲染，数据在 JS 执行后出现在 DOM 中，
    需使用 Playwright 采集。
    """

    def __init__(self, verbose=False):
        super().__init__(
            source_name='skills_sh',
            url='https://skills.sh',
            selectors=['[class*="skill"]', 'table tr', 'article', '[class*="item"]', '[class*="card"]'],
            verbose=verbose,
        )


# ============================================================
# skill.aiphys.cn REST API 采集器
# ============================================================

class AIphysCollector:
    """
    采集 https://skill.aiphys.cn/v1/skills REST API 数据。
    返回 JSON，含 name/slug/description/tags/category/download_count。
    """

    SOURCE = 'aiphys'
    BASE_URL = 'https://skill.aiphys.cn/v1/skills'

    def __init__(self, verbose=False):
        self.verbose = verbose

    def collect(self):
        """通过 REST API 采集 skill 列表（支持分页）。"""
        entries = []
        page_num = 1
        page_size = 50
        has_more = True

        while has_more:
            url = f"{self.BASE_URL}?page={page_num}&page_size={page_size}"
            resp = _safe_fetch(url, timeout=15)
            if not resp:
                break

            try:
                data = resp.json()
            except Exception:
                break

            items = data.get('data', {}).get('items', [])
            if not items:
                break

            for item in items:
                entries.append({
                    'slug': item.get('slug', ''),
                    'name': item.get('name', ''),
                    'description': item.get('description', ''),
                    'tags': item.get('tags', []),
                    'category': item.get('category', ''),
                    'download_count': item.get('download_count', 0),
                    'relevance': item.get('download_count', 0),
                    'source': self.SOURCE,
                    'author': item.get('owner_name', ''),
                    'created_at': item.get('created_at', ''),
                    'collected_at': datetime.now().isoformat(),
                })

            has_more = data.get('data', {}).get('has_more', False)
            page_num += 1
            time.sleep(1.0)  # 礼貌限速

        if self.verbose:
            safe_print(f"[OK] {self.SOURCE}: collected {len(entries)} skills")
        return entries


# ============================================================
# skillmarket.cc 采集器（跟随重定向到 /en/）
# ============================================================

class SkillMarketCcCollector:
    """
    采集 https://skillmarket.cc/en/ 页面。
    该站重定向到 /en/，直接访问 /en/。
    """

    SOURCE = 'skillmarket_cc'
    BASE_URL = 'https://skillmarket.cc/en/'

    def __init__(self, verbose=False):
        self.verbose = verbose

    def collect(self):
        """抓取 skillmarket.cc/en/ 的 skill 列表。"""
        entries = []
        resp = _safe_fetch(self.BASE_URL, timeout=20)
        if not resp:
            safe_print(f"[WARNING] {self.SOURCE}: Failed to fetch page")
            return entries

        soup = _BS(resp.text, 'html.parser')

        # 尝试提取 skill 卡片列表
        cards = soup.select('[class*="skill-card"], [class*="card"], [class*="item"]')
        if not cards:
            # 兜底：所有含链接的 div
            cards = soup.select('div a[href*="/skill"], div a[href*="/skills"]')

        for card in cards:
            # 提取名称
            name_el = card.select_one('[class*="name"], [class*="title"], h1, h2, h3, strong')
            name = name_el.get_text(strip=True) if name_el else ''

            # 提取描述
            desc_el = card.select_one('[class*="desc"], [class*="description"], p')
            desc = desc_el.get_text(strip=True) if desc_el else ''

            # 提取链接
            link_el = card if card.name == 'a' else card.select_one('a[href]')
            href = link_el.get('href', '') if link_el else ''
            slug = href.strip('/').split('/')[-1] if href else name.lower().replace(' ', '-')

            if name and len(name) < 100:
                entries.append({
                    'slug': slug,
                    'name': name,
                    'description': desc,
                    'relevance': 1.0,
                    'source': self.SOURCE,
                    'url': f'https://skillmarket.cc{href}' if href and not href.startswith('http') else href,
                    'collected_at': datetime.now().isoformat(),
                })

        if self.verbose:
            safe_print(f"[OK] {self.SOURCE}: collected {len(entries)} skills")
        return entries


# ============================================================
# Market Data Collector
# ============================================================

class MarketCollector:
    """Collect and cache market skill data with incremental updates."""

    # 所有可用数据源
    ALL_SOURCES = {
        'clawhub':     ClawHubSearcher,
        'skills_sh':    SkillsShCollector,
        'aiphys':      AIphysCollector,
        'skillmarket': SkillMarketCcCollector,
        'skillmarket_pi': SkillMarketPiCollector,
        'trusttools':  TrustToolsCollector,
        'skillhub_cn': SkillHubCnCollector,
    }

    def __init__(self, verbose=False, sources=None):
        """
        sources: list of source names to collect from. None = all.
        """
        self.verbose = verbose
        self.sources = sources  # None = all sources
        self.searcher = ClawHubSearcher(verbose=self.verbose)  # ClawHub 搜索器（含防封限流）
        self.cache = self._load_cache()
        self.log = self._load_log()
        self.stats = {'searches': 0, 'new': 0, 'updated': 0, 'skipped': 0, 'by_source': {}}
        self.duration_sec = 0.0

    def collect(self, full_scan=False):
        """Run market data collection from all (or specified) sources."""
        collect_start = time.time()
        sources_to_run = self.sources or list(self.ALL_SOURCES.keys())

        print(f"[INFO] Market collection started ({'full' if full_scan else 'incremental'})")
        print(f"[INFO] Cache: {len(self.cache)} skills already cached")
        print(f"[INFO] Sources: {sources_to_run}")

        for src_name in sources_to_run:
            cls = self.ALL_SOURCES.get(src_name)
            if not cls:
                print(f"[WARNING] Unknown source: {src_name}")
                continue

            # ClawHub 使用 searcher 模式，其他使用 collect() 模式
            if src_name == 'clawhub':
                self._collect_clawhub(full_scan)
            else:
                self._collect_generic(cls, src_name)

        # Save cache and compute analytics
        self._save_cache()
        self._compute_analytics()

        # Log this run
        self._log_run()

        print(f"\n[OK] Collection complete:")
        print(f"  Sources run: {len(sources_to_run)}")
        print(f"  Total searches: {self.stats['searches']}")
        print(f"  New skills: {self.stats['new']}")
        print(f"  Updated: {self.stats['updated']}")
        print(f"  Skipped (unchanged): {self.stats['skipped']}")
        if self.stats.get('by_source'):
            for s, n in self.stats['by_source'].items():
                print(f"    {s}: {n} entries")
        print(f"  Total cached: {len(self.cache)}")

        # Track total duration
        self.duration_sec = time.time() - collect_start

        return self.cache

    def _collect_clawhub(self, full_scan):
        """Collect from ClawHub via searcher (with anti-ban rate limiter)."""
        queries = self._get_queries(full_scan)
        total = len(queries)
        print(f"\n[INFO] ClawHub: {total} search queries")

        for i, query in enumerate(queries):
            # 频率检查（由 ClawHubRateLimiter 控制分钟/小时硬限制）
            can_proceed, reason, wait = self.searcher.limiter.can_proceed()
            if not can_proceed:
                print(f"[INFO] ClawHub rate limit reached ({reason}), stop for now")
                break

            if self.verbose:
                print(f"  [{i+1}/{total}] Searching: '{query}'")

            results = self.searcher.search(query, limit=20)
            if results:
                self.stats['searches'] += 1
                for entry in results:
                    self._merge_entry(entry)
            elif results is None:
                # cache hit 但 entries 为空时不计次
                pass

        # 打印限流状态
        status = self.searcher.limiter.get_status()
        print(f"\n[INFO] ClawHub rate limit status:")
        print(f"       minute: {status['minute_requests']}/3 | hour: {status['hour_requests']}/20")
        print(f"       cooldown: {status['in_cooldown']} | backoff_count: {status['backoff_count']}")
        print(f"       cache: {status['cache_entries']} entries")

    def _collect_generic(self, collector_cls, src_name):
        """Collect from any generic collector (HTML/API/SPA)."""
        print(f"\n[INFO] Collecting from: {src_name}")
        try:
            collector = collector_cls(verbose=self.verbose)
            entries = collector.collect()

            # 统计
            self.stats['by_source'][src_name] = len(entries)
            for entry in entries:
                self._merge_entry(entry)

            print(f"[OK] {src_name}: collected {len(entries)} entries")

        except Exception as e:
            print(f"[ERROR] {src_name}: collection failed - {e}")
            if self.verbose:
                import traceback
                traceback.print_exc()


    def get_status(self):
        """Get current cache status."""
        if not self.cache:
            print("[INFO] No cached market data. Run collection first.")
            return

        total = len(self.cache)
        sources = Counter(v.get('source', 'unknown') for v in self.cache.values())
        ages = []
        now = datetime.now()
        for v in self.cache.values():
            try:
                dt = datetime.fromisoformat(v.get('collected_at', now.isoformat()))
                ages.append((now - dt).days)
            except:
                ages.append(0)

        print(f"[STATUS] Market Data Cache")
        print(f"  Total skills: {total}")
        print(f"  Sources: {dict(sources)}")
        print(f"  Age range: {min(ages)}-{max(ages)} days")
        print(f"  Avg age: {sum(ages)/len(ages):.1f} days")
        if self.log:
            last = self.log[-1]
            print(f"  Last collection: {last.get('timestamp', 'unknown')}")
            print(f"  Last stats: {last.get('stats', {})}")

    def _get_queries(self, full_scan):
        """Get search queries based on scan mode."""
        queries = []
        for cat, cat_queries in SEARCH_CATEGORIES.items():
            if full_scan:
                queries.extend(cat_queries)
            else:
                # Incremental: pick 1-2 per category
                queries.extend(cat_queries[:2])
        return queries

    def _merge_entry(self, entry):
        """Merge a new entry into cache (incremental update)."""
        slug = entry['slug']
        fingerprint = hashlib.md5(
            json.dumps(entry, sort_keys=True, ensure_ascii=False).encode()
        ).hexdigest()

        if slug in self.cache:
            old = self.cache[slug]
            if old.get('fingerprint') == fingerprint:
                self.stats['skipped'] += 1
                return
            # Update existing
            entry['fingerprint'] = fingerprint
            entry['first_seen'] = old.get('first_seen', entry['collected_at'])
            entry['update_count'] = old.get('update_count', 0) + 1
            self.cache[slug] = entry
            self.stats['updated'] += 1
        else:
            entry['fingerprint'] = fingerprint
            entry['first_seen'] = entry['collected_at']
            entry['update_count'] = 0
            self.cache[slug] = entry
            self.stats['new'] += 1

    def _compute_analytics(self):
        """Compute keyword frequency and trigger pattern analytics from cache."""
        kw_freq = Counter()          # keyword -> weighted frequency
        trigger_patterns = Counter() # trigger pattern -> frequency
        slug_keywords = defaultdict(list)  # keyword -> [slugs]

        now = datetime.now()

        for slug, entry in self.cache.items():
            # Compute time-decay weight
            try:
                collected = datetime.fromisoformat(entry.get('collected_at', now.isoformat()))
                age_days = max(0, (now - collected).days)
            except:
                age_days = 0
            decay_weight = math.exp(-DECAY_LAMBDA * age_days)

            # Extract from slug (kebab-case split)
            slug_parts = slug.replace('-', ' ').replace('_', ' ').split()
            for part in slug_parts:
                w = part.lower()
                if len(w) > 2:
                    kw_freq[w] += 2.0 * decay_weight
                    slug_keywords[w].append(slug)

            # Extract from name
            name = entry.get('name', '')
            # Chinese segments
            for zh in re.findall(r'[\u4e00-\u9fff]{2,8}', name):
                kw_freq[zh] += 3.0 * decay_weight
                slug_keywords[zh].append(slug)
            # English words
            for en in re.findall(r'[A-Z][a-zA-Z]{2,}', name):
                w = en.lower()
                if len(w) > 2:
                    kw_freq[w] += 2.5 * decay_weight
                    slug_keywords[w].append(slug)

            # Extract relevance as popularity signal
            relevance = entry.get('relevance', 0)
            if relevance > 1.0:
                # Higher relevance = more popular query match
                for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', name):
                    kw_freq[zh] += relevance * 0.5 * decay_weight

        # Trigger pattern mining: find common 2-3 word combos in names
        for slug, entry in self.cache.items():
            name = entry.get('name', '')
            words = re.findall(r'[A-Z][a-zA-Z]+|[\u4e00-\u9fff]{2,4}', name)
            for i in range(len(words) - 1):
                bigram = ' '.join(words[i:i+2]).lower()
                trigger_patterns[bigram] += 1
            for i in range(len(words) - 2):
                trigram = ' '.join(words[i:i+3]).lower()
                trigger_patterns[trigram] += 0.5  # Trigrams less common

        # Save keyword frequency
        kw_data = {
            "generated_at": datetime.now().isoformat(),
            "total_skills_analyzed": len(self.cache),
            "top_keywords": [
                {"keyword": kw, "score": round(score, 2),
                 "example_slugs": slugs[:5], "source": "clawhub_market"}
                for kw, score, slugs in [
                    (k, v, slug_keywords[k]) for k, v in kw_freq.most_common(500)
                ]
            ],
        }
        KEYWORD_FREQ.write_text(
            json.dumps(kw_data, ensure_ascii=False, indent=2), encoding='utf-8'
        )

        # Save trigger patterns
        tp_data = {
            "generated_at": datetime.now().isoformat(),
            "total_skills_analyzed": len(self.cache),
            "top_patterns": [
                {"pattern": p, "frequency": int(c), "source": "clawhub_market"}
                for p, c in trigger_patterns.most_common(200)
                if c >= 2  # Only patterns seen 2+ times
            ],
        }
        TRIGGER_PATTERNS.write_text(
            json.dumps(tp_data, ensure_ascii=False, indent=2), encoding='utf-8'
        )

        # Save trend history snapshot
        self._save_trend_snapshot(kw_freq)

        if self.verbose:
            print(f"[OK] Analytics: {len(kw_freq)} keywords, "
                  f"{len(trigger_patterns)} trigger patterns")

    def _save_trend_snapshot(self, kw_freq):
        """Save a timestamped snapshot for trend tracking."""
        history = []
        if TREND_HISTORY.exists():
            try:
                history = safe_read_json(TREND_HISTORY)
            except:
                history = []

        snapshot = {
            "timestamp": datetime.now().isoformat(),
            "total_skills": len(self.cache),
            "top_50_keywords": [
                {"keyword": kw, "score": round(score, 2)}
                for kw, score in kw_freq.most_common(50)
            ],
        }

        history.append(snapshot)

        # Keep last 90 snapshots (about 3 months of daily data)
        if len(history) > 90:
            history = history[-90:]

        TREND_HISTORY.write_text(
            json.dumps(history, ensure_ascii=False, indent=1), encoding='utf-8'
        )

    def _log_run(self):
        """Log this collection run."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "stats": self.stats,
            "cache_size": len(self.cache),
        }
        self.log.append(entry)
        if len(self.log) > 100:
            self.log = self.log[-100:]
        COLLECT_LOG.write_text(
            json.dumps(self.log, ensure_ascii=False, indent=1), encoding='utf-8'
        )

    def _load_cache(self):
        """Load market cache from disk."""
        if MARKET_CACHE.exists():
            try:
                return safe_read_json(MARKET_CACHE)
            except:
                return {}
        return {}

    def _save_cache(self):
        """Save market cache to disk."""
        MARKET_CACHE.write_text(
            json.dumps(self.cache, ensure_ascii=False, indent=1), encoding='utf-8'
        )

    def _load_log(self):
        """Load collection log from disk."""
        if COLLECT_LOG.exists():
            try:
                return safe_read_json(COLLECT_LOG)
            except:
                return []
        return []


# ============================================================
# CLI Entry Point
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Market Data Collector - Multi-Source Edition")
    parser.add_argument("--full", action="store_true",
                       help="Full scan (all category queries for ClawHub)")
    parser.add_argument("--status", action="store_true",
                       help="Show cache status")
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output")
    parser.add_argument("--sources", nargs='+', default=None,
                       help=(
                           "Which sources to collect from. Available: "
                           "clawhub skills_sh aiphys skillmarket "
                           "skillmarket_pi trusttools skillhub_cn. "
                           "Default: all sources. "
                           "Examples: --sources clawhub skills_sh | --sources aiphys trusttools"
                       ))
    args = parser.parse_args()

    # ---- 执行日志 start ----
    logger = ExecutionLogger("market_collector")
    logger.start({
        "mode": "full" if args.full else "incremental",
        "status": args.status,
        "verbose": args.verbose,
        "sources": args.sources,
    })

    # ---- Token 日志 start ----
    start_time = datetime.now()
    try:
        from token_logger import TokenLogger
        token_logger = TokenLogger("skill-trend-analyzer")
    except ImportError:
        token_logger = None

    # ---- 健康报告模块 ----
    from automation_health import generate_and_save

    # 检查可用依赖
    if args.sources and not _HAS_REQUESTS:
        print("[WARNING] requests library not installed. API/HTML collectors may fail.")
        print("[WARNING] Install with: pip install requests")
    if args.sources and not _HAS_BS4:
        print("[WARNING] BeautifulSoup4 not installed. HTML parsers may fail.")
        print("[WARNING] Install with: pip install beautifulsoup4 lxml")

    try:
        collector = MarketCollector(verbose=args.verbose, sources=args.sources)

        if args.status:
            collector.get_status()
            logger.phase("status_check")
            logger.done({"status": "ok", "cache_size": len(collector.cache), "searches": 0, "new": 0, "updated": 0})
        else:
            logger.phase("collecting")
            collector.collect(full_scan=args.full)
            logger.phase("saving")
            logger.done({
                "searches": collector.stats["searches"],
                "new": collector.stats["new"],
                "updated": collector.stats["updated"],
                "skipped": collector.stats["skipped"],
                "by_source": collector.stats.get("by_source", {}),
                "cache_size": len(collector.cache),
                "keyword_freq_entries": len(collector.cache) if hasattr(collector, 'cache') else 0,
            })

    except Exception as e:
        logger.fail(str(e), {"searches": 0, "new": 0, "updated": 0, "skipped": 0})
        import traceback; traceback.print_exc()

    # ── Token消耗估算（market_collector专用） ──────────────────────────
    searches = collector.stats.get("searches", 0) if 'collector' in dir() else 0
    by_source = collector.stats.get("by_source", {}) if 'collector' in dir() else {}
    duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)
    duration = collector.duration_sec if 'collector' in dir() and hasattr(collector, 'duration_sec') else 0

    # 估算 token 消耗（ClawHub按搜索次数，其他按条目数）
    clawhub_tokens = searches * 700
    other_entries = sum(by_source.values())
    other_tokens = other_entries * 50  # 其他源按50 tokens/条目估算（网页抓取/token化）
    token_estimate = clawhub_tokens + other_tokens
    input_tokens = token_estimate // 3
    output_tokens = token_estimate * 2 // 3

    # 记录到 token 日志
    if token_logger:
        token_logger.log(
            action="market_collect",
            tokens={"input": input_tokens, "output": output_tokens, "total": token_estimate},
            duration_ms=duration_ms,
            metadata={"searches": searches, "by_source": by_source, "full_scan": args.full}
        )

    print()
    print("─" * 70)
    print("  [TOKEN ESTIMATE]  (Token消耗估算)")
    print("─" * 70)
    print(f"  Duration: {duration:.1f}s | ClawHub searches: {searches}次")
    if by_source:
        for s, n in by_source.items():
            print(f"    {s}: {n} entries")
    print(f"  Token估算: ~{token_estimate:,} tokens")
    cost_estimate_usd = token_estimate / 1000 * 0.001
    cost_estimate_cny = cost_estimate_usd * 7.2
    print(f"  成本估算: ~${cost_estimate_usd:.4f} (约 ¥{cost_estimate_cny:.4f})")
    print(f"  Note: 不含WorkBuddy AI对话消耗，不含Playwright浏览器开销")
    print("─" * 70)

    # ── 成功/失败都输出健康报告 ───────────────────────────────────────────
    health_report, health_fp = generate_and_save()
    print()
    for line in health_report["text"].split("\n"):
        if line.strip():
            print(line)
    print(f"\n[OK] Health report saved: {health_fp}")

    # Fixed ending - contact author info (ClawHub compliance)
    print(f"\n[OK] Done! Market data collection complete.")
    print("[INFO] Contact: QQ 1817694478 | Q群 972156177\n")



if __name__ == "__main__":
    main()
