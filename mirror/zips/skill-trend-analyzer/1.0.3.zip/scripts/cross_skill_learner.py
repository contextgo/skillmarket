#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
"""
Cross-Skill Learner & Self-Optimizer
======================================
The brain of the skill-trend-analyzer ecosystem. Learns from:
  1. Local skill scans (architecture, keywords, algorithms)
  2. Market trend data (hot keywords, rising patterns)
  3. Cross-skill pattern transfer (reusable knowledge)
  4. Self-learning from own optimization history

Outputs:
  - data/learn_data.json      - Cumulative learning data
  - data/optimization_log.json - History of optimizations applied
  - data/pattern_library.json  - Reusable cross-skill patterns

Auto-self-optimization:
  - Adjusts scoring weights based on optimization success
  - Learns which keyword sources are most valuable
  - Evolves trigger word patterns from market + local evidence
  - Tracks accuracy of past recommendations

Usage:
  python cross_skill_learner.py                       # Full learning cycle
  python cross_skill_learner.py --skill <dir>          # Learn + optimize one skill
  python cross_skill_learner.py --apply <dir>          # Learn + apply optimizations
  python cross_skill_learner.py --report               # Learning progress report
  python cross_skill_learner.py --reset-weights        # Reset learned weights
"""
import sys, io, os, re, json, hashlib, math
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict

# [Safe Guard: 5-layer anti-freeze system]
from safe_guard import safe_print, safe_init, TimeoutGuard, safe_read_json, safe_read_text
from exec_logger import ExecutionLogger
safe_init()

SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR.parent / "data"
DATA_DIR.mkdir(exist_ok=True)
SKILLS_ROOT = Path.home() / ".workbuddy" / "skills"

# Learning data files
LEARN_DATA_FILE = DATA_DIR / "learn_data.json"
OPT_LOG_FILE = DATA_DIR / "optimization_log.json"
PATTERN_LIB_FILE = DATA_DIR / "pattern_library.json"

# Noise filters (shared with skill_optimizer)
CODE_NOISE = set(
    "self cls filepath filename files file dir path return def class import "
    "from module package init main func function method arg args kwargs param "
    "true false none null list dict set tuple str int float bool type print "
    "raise except try catch finally with as lambda yield assert break continue "
    "pass elif else not is in get set add remove update delete insert append "
    "extend pop sort reverse copy len range enumerate zip map filter reduce "
    "open close read write seek flush name value key item index slice split "
    "join strip replace format encode decode lower upper title capitalize "
    "skill learning manifest hash json cmd results version manager learn "
    "workflow relpath copyright author modified python global local "
    "static dynamic instance abstract base core sub "
    # 补充：通用英文单词，不能区分领域
    "system search app chat work buddy result operation step input source "
    "click target timeout generate report claw hub item manager generate".split()
)

ZH_GENERIC_NOISE = set(
    "用户 示例 格式 新版本 清单 方法 步骤 说明 注意 提示 操作 流程 "
    "信息 方式 功能 系统 问题 情况 部分 相关 内容 对应 记录 编号 "
    "字段 类型 名称 对象 数值 字符串 列表 条件 判断 循环 变量 参数 "
    "第一步 第二步 第三步 第四步 第五步 新增 更新到 放大 请从 下载 安装 "
    "安装或更 类型匹 市场重新 年第 核心 要点 公告 模板 应对 准备 助手 "
    # 补充：过于通用的动词/名词，无法区分skill领域
    "通过 排除 必须 平台 默认 支持 保留 使用 创建 文件 模块 说明 "
    "功能 规范 场景 列表 标准 要求 记录 结果 最多 最长 响应 机制 "
    "方案 类型 优先 策略 确认 推荐 任务 网址 颜色 风格 特点 可选 "
    "应用 执行 基数 安装 注意事项 案例 农村 季度 编码 地址 全量 "
    "一览 原样 清理 去除 注释 序列化 抓取 升级 变换 资源补充 "
    "编程开发 脚本 配置文件 参数 快捷 集成 认证 测试 合并 标签 "
    "分支 议题 服务器 笔记 学术研究 特色功能 踩坑 缺少 依赖 "
    "绕过 受限 静默 可用性 仅检查 追加内容 技能 "
    # MEMORY.md 操作指令片段
    "打包铁律 必须打包 双平台发布 发布流程 打包排除 禁打包 不打包 "
    "生成本地 展示发布预览 等待确认 确认后执行 明文数据库严 未声明但代码 "
    "认再提交 前先让用户确 ".split()
)


# ============================================================
# Learning Data Manager
# ============================================================

class LearningData:
    """Manage cumulative learning data with self-evolving weights."""

    def __init__(self):
        self.data = self._load()
        self._ensure_structure()

    def _ensure_structure(self):
        """Ensure learning data has all required sections."""
        defaults = {
            'version': '2.0.0',
            'created_at': datetime.now().isoformat(),
            'last_updated': datetime.now().isoformat(),
            'scan_count': 0,
            'optimization_count': 0,
            'success_count': 0,
            'failure_count': 0,

            # Self-evolving weights (adjusted by success/failure)
            'weights': {
                'local_keyword_freq': 1.5,
                'market_keyword_freq': 0.3,
                'rising_trend_boost': 5.0,
                'domain_boost_factor': 1.3,
                'cross_skill_transfer': 0.8,
                'architecture_completeness': 1.0,
                'trigger_length_2_4': 1.2,
                'market_evidence_bonus': 3.0,
            },

            # Track which weight adjustments worked
            'weight_adjustments': [],

            # Success patterns: which keyword sources led to good triggers
            'source_effectiveness': {
                'local_skill_md': {'hits': 0, 'total': 0},
                'local_python': {'hits': 0, 'total': 0},
                'local_references': {'hits': 0, 'total': 0},
                'market_search': {'hits': 0, 'total': 0},
                'market_trending': {'hits': 0, 'total': 0},
                'cross_skill_transfer': {'hits': 0, 'total': 0},
            },

            # Keyword history: track keyword scores over time
            'keyword_history': {},

            # Trigger effectiveness: which triggers got user adoption
            'trigger_effectiveness': {},

            # Cross-skill patterns learned
            'cross_skill_patterns': {},

            # Domain knowledge accumulated
            'domain_knowledge': {},

            # Auto-discovered relationships
            'discovered_relations': [],

            # ── Noise filter rules (self-learning) ──────────────────────────
            # dynamic_noise: words explicitly marked as noise (with reason/date)
            # noise_candidates: low-score words recurred but never adopted
            # cleanup_history: records of past bulk cleanup operations
            'noise_filter_rules': {
                'dynamic_noise': {},       # {word: {reason, added_at, count}}
                'noise_candidates': {},    # {word: {score_avg, seen_count, last_seen}}
                'cleanup_history': [],     # [{date, removed_count, noise_types}]
                'version': 1,
            },
        }

        for key, default_val in defaults.items():
            if key not in self.data:
                self.data[key] = default_val

    def record_success(self, source, keyword=None, context=None):
        """Record a successful optimization (user adopted suggestion)."""
        self.data['success_count'] += 1
        if source not in self.data.get('source_effectiveness', {}):
            self.data.setdefault('source_effectiveness', {})[source] = {
                'hits': 0, 'total': 0, 'consecutive_success': 0
            }
        self.data['source_effectiveness'][source]['hits'] += 1
        self.data['source_effectiveness'][source]['total'] += 1
        self.data['source_effectiveness'][source]['consecutive_success'] += 1
        # Reset failure streak
        if 'consecutive_failure' in self.data['source_effectiveness'][source]:
            del self.data['source_effectiveness'][source]['consecutive_failure']

        if keyword:
            self.data.setdefault('trigger_effectiveness', {})
            self.data['trigger_effectiveness'][keyword] = {
                'adopted': True,
                'source': source,
                'timestamp': datetime.now().isoformat(),
            }

        # Evolve weights: boost effective sources (accelerated on streak)
        if source in self.data.get('source_effectiveness', {}):
            se = self.data['source_effectiveness'][source]
            if se['total'] > 0 and se['hits'] / se['total'] > 0.5:
                weight_map = {
                    'local_skill_md': 'local_keyword_freq',
                    'local_python': 'local_keyword_freq',
                    'local_references': 'local_keyword_freq',
                    'market_search': 'market_keyword_freq',
                    'market_trending': 'rising_trend_boost',
                    'cross_skill_transfer': 'cross_skill_transfer',
                }
                if source in weight_map:
                    wkey = weight_map[source]
                    old = self.data['weights'].get(wkey, 1.0)
                    # Base 5% boost
                    boost = 0.05
                    # Accelerated boost: consecutive 3 successes → 10%
                    if se.get('consecutive_success', 0) >= 3:
                        boost = 0.10
                    # Super-accelerated: consecutive 5 successes → 15%
                    if se.get('consecutive_success', 0) >= 5:
                        boost = 0.15
                    new = old * (1 + boost)
                    new = min(new, old * 2.0)  # Cap at 2x
                    self.data['weights'][wkey] = round(new, 3)
                    self.data.setdefault('weight_adjustments', []).append({
                        'weight': wkey,
                        'old': old,
                        'new': round(new, 3),
                        'reason': f'source_{source}_success(streak={se["consecutive_success"]})',
                        'timestamp': datetime.now().isoformat(),
                    })

        self._save()

    def record_failure(self, source, keyword=None):
        """Record a failed optimization (user rejected suggestion)."""
        self.data['failure_count'] += 1
        if source not in self.data.get('source_effectiveness', {}):
            self.data.setdefault('source_effectiveness', {})[source] = {
                'hits': 0, 'total': 0, 'consecutive_failure': 0
            }
        self.data['source_effectiveness'][source]['total'] += 1
        self.data['source_effectiveness'][source]['consecutive_failure'] = \
            self.data['source_effectiveness'][source].get('consecutive_failure', 0) + 1
        # Reset success streak
        if 'consecutive_success' in self.data['source_effectiveness'][source]:
            del self.data['source_effectiveness'][source]['consecutive_success']

        if keyword:
            self.data.setdefault('trigger_effectiveness', {})
            self.data['trigger_effectiveness'][keyword] = {
                'adopted': False,
                'source': source,
                'timestamp': datetime.now().isoformat(),
            }

        # Evolve weights: reduce ineffective sources (accelerated on streak)
        if source in self.data.get('source_effectiveness', {}):
            se = self.data['source_effectiveness'][source]
            if se['total'] > 3 and se['hits'] / se['total'] < 0.3:
                weight_map = {
                    'local_skill_md': 'local_keyword_freq',
                    'local_python': 'local_keyword_freq',
                    'local_references': 'local_keyword_freq',
                    'market_search': 'market_keyword_freq',
                    'market_trending': 'rising_trend_boost',
                    'cross_skill_transfer': 'cross_skill_transfer',
                }
                if source in weight_map:
                    wkey = weight_map[source]
                    old = self.data['weights'].get(wkey, 1.0)
                    # Base 5% reduction
                    reduction = 0.05
                    # Accelerated reduction: consecutive 3 failures → 10%
                    if se.get('consecutive_failure', 0) >= 3:
                        reduction = 0.10
                    new = old * (1 - reduction)
                    new = max(new, old * 0.5)  # Floor at 50%
                    self.data['weights'][wkey] = round(new, 3)
                    self.data.setdefault('weight_adjustments', []).append({
                        'weight': wkey,
                        'old': old,
                        'new': round(new, 3),
                        'reason': f'source_{source}_failure(streak={se["consecutive_failure"]})',
                        'timestamp': datetime.now().isoformat(),
                    })

        self._save()

    # ── Noise self-learning API ──────────────────────────────────────────────

    def record_noise_keyword(self, kw, reason='manual'):
        """
        Explicitly mark a keyword as noise.
        This word will be rejected by _is_valid_keyword in future scans.
        reason: 'manual' | 'cleanup_batch' | 'auto_low_score' | 'sentence_fragment'
        """
        if not kw or not isinstance(kw, str):
            return
        kw = kw.strip()
        nfr = self.data.setdefault('noise_filter_rules', {})
        dn = nfr.setdefault('dynamic_noise', {})
        if kw in dn:
            dn[kw]['count'] = dn[kw].get('count', 1) + 1
            dn[kw]['last_marked'] = datetime.now().isoformat()
        else:
            dn[kw] = {
                'reason': reason,
                'added_at': datetime.now().isoformat(),
                'last_marked': datetime.now().isoformat(),
                'count': 1,
            }
        # Remove from keyword_history if present (clean up past contamination)
        self.data.get('keyword_history', {}).pop(kw, None)
        self._save()

    def auto_learn_noise_from_cleanup(self, removed_keywords, noise_type_map=None):
        """
        Bulk-register removed keywords as noise after a cleanup operation.
        removed_keywords: list of str
        noise_type_map: optional dict {word: noise_type_str}
        Records a cleanup_history entry and marks each word as dynamic_noise.
        """
        now = datetime.now().isoformat()
        nfr = self.data.setdefault('noise_filter_rules', {})
        dn = nfr.setdefault('dynamic_noise', {})
        noise_type_counts = {}

        for kw in removed_keywords:
            if not kw or not isinstance(kw, str):
                continue
            kw = kw.strip()
            noise_type = (noise_type_map or {}).get(kw, 'cleanup_batch')
            noise_type_counts[noise_type] = noise_type_counts.get(noise_type, 0) + 1
            if kw not in dn:
                dn[kw] = {
                    'reason': noise_type,
                    'added_at': now,
                    'last_marked': now,
                    'count': 1,
                }
            else:
                dn[kw]['count'] = dn[kw].get('count', 1) + 1
                dn[kw]['last_marked'] = now
            # Remove from keyword_history to clear historical contamination
            self.data.get('keyword_history', {}).pop(kw, None)

        # Record cleanup history (keep last 20)
        history = nfr.setdefault('cleanup_history', [])
        history.append({
            'date': now[:10],
            'timestamp': now,
            'removed_count': len(removed_keywords),
            'noise_type_breakdown': noise_type_counts,
        })
        nfr['cleanup_history'] = history[-20:]

        self._save()
        return len(removed_keywords)

    def get_dynamic_noise_set(self):
        """Return set of all dynamically learned noise words."""
        nfr = self.data.get('noise_filter_rules', {})
        return set(nfr.get('dynamic_noise', {}).keys())

    # ── Noise candidate tracking ─────────────────────────────────────────────

    def _maybe_add_noise_candidate(self, kw, score):
        """
        Internal: if a keyword has very low score, track it as a noise candidate.
        After seen_count >= 5 with avg_score < 1.5, auto-promote to dynamic_noise.
        """
        nfr = self.data.setdefault('noise_filter_rules', {})
        nc = nfr.setdefault('noise_candidates', {})
        now = datetime.now().strftime('%Y-%m-%d')

        if kw not in nc:
            nc[kw] = {'score_sum': score, 'seen_count': 1, 'last_seen': now}
        else:
            nc[kw]['score_sum'] = nc[kw].get('score_sum', 0) + score
            nc[kw]['seen_count'] = nc[kw].get('seen_count', 0) + 1
            nc[kw]['last_seen'] = now

        entry = nc[kw]
        seen = entry['seen_count']
        avg = entry['score_sum'] / seen if seen > 0 else 0

        # Auto-promote: seen >= 5 times, avg score still < 1.5 → noise
        if seen >= 5 and avg < 1.5:
            dn = nfr.setdefault('dynamic_noise', {})
            if kw not in dn:
                dn[kw] = {
                    'reason': 'auto_low_score',
                    'added_at': datetime.now().isoformat(),
                    'last_marked': datetime.now().isoformat(),
                    'count': seen,
                    'avg_score': round(avg, 3),
                }
                # Remove from keyword_history
                self.data.get('keyword_history', {}).pop(kw, None)
            # Remove from candidates once promoted
            del nc[kw]

    # Chinese sentence-fragment detectors (reject these as keywords)
    _SENTENCE_FRAGMENT_SUFFIXES = {
        '与', '和', '或', '的', '了', '是', '在', '有', '用', '相',
        '问', '提', '使', '当', '等', '及', '就', '要', '去', '到',
        '请', '为', '从', '对', '把', '被', '让', '给', '还', '能',
    }
    _SENTENCE_FRAGMENT_ENDS = {
        '时', '后', '前', '中', '上', '里', '外', '内', '间',
        '场', '相', '议', '配', '报', '审', '关', '更', '新', '护',
    }
    _MAX_KEYWORD_LEN = 10   # reject keywords longer than this

    # Regex patterns that indicate sentence fragments (not keywords)
    import re as _re
    _FRAGMENT_PATTERNS = _re.compile(
        r'当用户|提出与|关的问题时|使用此|先让用户|再提交|确认后执行|'
        r'展示发布|等待确认|明文数据库|未声明但|仅用退出|有则输出|'
        r'无则提示|未设置时|输入并写|适用于所有|根据.*类型|根据.*名称|'
        r'组织等数|城镇职工基|纳税人身份|年应纳税|企业所得税汇|'
        r'企业微信群机|列出所有公众|用人单位全额|省级电税局|各省市电子税|'
        r'高频涉税待办|待办事项订阅|自学习查询扩|源效果追踪|'
        r'绝对不能自动|验证凭证格式|严格遵循确认|本地全量扫描|'
        r'核心判断规则|笔记的内容|知识库的条目|描述笔记的|文件上传保持|'
        r'必须保持文件|多模块任务|用户口令示例|微信公众号发|'
        r'省份电税二|自动抓取待办|电税扫码版|引导用户配置|'
        r'策详解$|价核实$|器人$|维码获取$|到篡改$|禁打包$'
    )

    def _is_valid_keyword(self, kw):
        """Return True if kw looks like a real keyword, not a sentence fragment."""
        if not kw or not isinstance(kw, str):
            return False
        kw = kw.strip()
        if not kw:
            return False

        # Length check
        if len(kw) < 1 or len(kw) > self._MAX_KEYWORD_LEN:
            return False

        # Reject if contains whitespace (multi-word fragment)
        if any(c.isspace() for c in kw):
            return False

        # Reject if last char is a sentence-fragment suffix
        if kw[-1] in self._SENTENCE_FRAGMENT_SUFFIXES:
            return False

        # Reject known static noise words
        if kw in ZH_GENERIC_NOISE or kw.lower() in CODE_NOISE:
            return False

        # Reject dynamically learned noise words
        dynamic_noise = self.get_dynamic_noise_set()
        if kw in dynamic_noise:
            return False

        # Reject sentence fragment patterns
        if self._FRAGMENT_PATTERNS.search(kw):
            return False

        # Accept: looks like a real keyword
        return True

    def update_keyword_history(self, keywords_with_scores):
        """Track keyword score evolution over time (enhanced format with recurrence tracking)."""
        now = datetime.now().strftime('%Y-%m-%d')
        added = 0
        skipped = 0
        for kw, score in keywords_with_scores:
            if not self._is_valid_keyword(kw):
                skipped += 1
                # Track low-score rejected words as noise candidates
                if kw and isinstance(kw, str) and 1 < len(kw.strip()) <= self._MAX_KEYWORD_LEN:
                    self._maybe_add_noise_candidate(kw.strip(), score)
                continue

            # If score is very low, track as noise candidate even before rejecting
            if score < 1.5:
                self._maybe_add_noise_candidate(kw, score)
                # Still add to history, but only if it manages to pass threshold later
                # (don't skip it yet, let it accumulate — promotion happens after 5 sightings)

            added += 1
            kh = self.data.setdefault('keyword_history', {})
            if kw not in kh:
                # New keyword: initialize with enhanced format
                kh[kw] = {
                    'first_seen': now,
                    'last_seen': now,
                    'recurrence_count': 1,
                    'score_history': [{'date': now, 'score': round(score, 2)}]
                }
            else:
                entry = kh[kw]
                # Migrate old format to new format if needed
                if isinstance(entry, list):
                    # Old format: list of {'date': ..., 'score': ...}
                    # Convert to new format
                    kh[kw] = {
                        'first_seen': entry[0]['date'] if entry else now,
                        'last_seen': now,
                        'recurrence_count': len(entry),
                        'score_history': entry[:90]  # Keep last 90
                    }
                    entry = kh[kw]
                # Update existing keyword
                entry['last_seen'] = now
                entry['recurrence_count'] = entry.get('recurrence_count', 0) + 1
                score_hist = entry.setdefault('score_history', [])
                # Update today's entry or append
                if score_hist and score_hist[-1].get('date') == now:
                    score_hist[-1]['score'] = max(score_hist[-1]['score'], round(score, 2))
                else:
                    score_hist.append({'date': now, 'score': round(score, 2)})
                # Keep last 90 days
                entry['score_history'] = score_hist[-90:]
                # Accelerate weight if keyword recurs frequently
                if entry['recurrence_count'] >= 3:
                    # Boost keyword's historical scores slightly
                    for h in entry['score_history']:
                        h['score'] = round(h['score'] * 1.02, 2)

    def add_cross_skill_pattern(self, pattern_name, pattern_data):
        """Add a learned cross-skill pattern."""
        self.data.setdefault('cross_skill_patterns', {})
        self.data['cross_skill_patterns'][pattern_name] = {
            **pattern_data,
            'learned_at': datetime.now().isoformat(),
        }

    def add_domain_knowledge(self, domain, knowledge):
        """Add accumulated domain knowledge."""
        self.data.setdefault('domain_knowledge', {})
        if domain not in self.data['domain_knowledge']:
            self.data['domain_knowledge'][domain] = []
        self.data['domain_knowledge'][domain].append({
            'knowledge': knowledge,
            'learned_at': datetime.now().isoformat(),
        })
        # Keep top 50 per domain
        if len(self.data['domain_knowledge'][domain]) > 50:
            self.data['domain_knowledge'][domain] = \
                self.data['domain_knowledge'][domain][-50:]

    def _auto_discover(self):
        """Auto-discover relationships from accumulated data."""
        relations = []

        # Find keywords that co-occur across skills
        kw_skills = defaultdict(set)
        profile_data = self._load_profile()
        for name, profile in profile_data.get('skills', {}).items():
            for kw_entry in profile.get('keywords', []):
                kw_skills[kw_entry['keyword']].add(name)

        # Keywords present in 3+ skills = strong cross-skill signal
        for kw, skills in kw_skills.items():
            if len(skills) >= 3 and kw not in CODE_NOISE and kw not in ZH_GENERIC_NOISE:
                relations.append({
                    'type': 'cross_skill_keyword',
                    'keyword': kw,
                    'skills': sorted(skills),
                    'strength': len(skills),
                })

        # Find architecture patterns that correlate with completeness
        arch_completeness = {}
        for name, profile in profile_data.get('skills', {}).items():
            arch = profile.get('architecture', {})
            patterns = arch.get('patterns', [])
            completeness = arch.get('completeness_pct', 0)
            for p in patterns:
                if p not in arch_completeness:
                    arch_completeness[p] = []
                arch_completeness[p].append(completeness)

        for pattern, scores in arch_completeness.items():
            if len(scores) >= 2:
                avg = sum(scores) / len(scores)
                if avg >= 75:
                    relations.append({
                        'type': 'high_completeness_pattern',
                        'pattern': pattern,
                        'avg_completeness': round(avg, 1),
                        'skills_count': len(scores),
                    })

        self.data['discovered_relations'] = relations[-100:]  # Keep last 100
        return relations

    def get_weights(self):
        """Get current evolved weights."""
        return self.data.get('weights', {})

    def get_effectiveness_report(self):
        """Get source effectiveness summary."""
        report = {}
        for source, stats in self.data.get('source_effectiveness', {}).items():
            total = stats.get('total', 0)
            hits = stats.get('hits', 0)
            report[source] = {
                'total_recommendations': total,
                'adopted': hits,
                'success_rate': round(hits / total * 100, 1) if total > 0 else 0,
            }
        return report

    def reset_weights(self):
        """Reset all learned weights to defaults."""
        self.data['weights'] = {
            'local_keyword_freq': 1.5,
            'market_keyword_freq': 0.3,
            'rising_trend_boost': 5.0,
            'domain_boost_factor': 1.3,
            'cross_skill_transfer': 0.8,
            'architecture_completeness': 1.0,
            'trigger_length_2_4': 1.2,
            'market_evidence_bonus': 3.0,
        }
        self.data['weight_adjustments'] = []
        self._save()
        print("[OK] Weights reset to defaults")

    def increment_scan(self):
        self.data['scan_count'] += 1
        self._save()

    def _load(self):
        if LEARN_DATA_FILE.exists():
            try:
                return safe_read_json(LEARN_DATA_FILE)
            except:
                return {}
        return {}

    def _save(self):
        self.data['last_updated'] = datetime.now().isoformat()
        LEARN_DATA_FILE.write_text(
            json.dumps(self.data, ensure_ascii=False, indent=2),
            encoding='utf-8'
        )

    def _load_profile(self):
        profile_file = DATA_DIR / "local_skills_profile.json"
        if profile_file.exists():
            try:
                return safe_read_json(profile_file)
            except:
                return {}
        return {}


# ============================================================
# Cross-Skill Pattern Transfer Engine
# ============================================================

class CrossSkillTransfer:
    """Transfer useful patterns between skills."""

    def __init__(self, learn_data, verbose=False):
        self.learn_data = learn_data
        self.verbose = verbose
        self.profile = self._load_profile()
        self.market = self._load_market()

    def find_transferable_patterns(self, target_skill_dir):
        """Find patterns from other skills that could benefit target skill."""
        target_name = Path(target_skill_dir).name
        target_profile = self.profile.get('skills', {}).get(target_name, {})
        if not target_profile:
            print(f"[WARNING] No profile for {target_name}, run scan first")
            return []

        target_kw = {k['keyword'] for k in target_profile.get('keywords', [])}
        target_triggers = set(target_profile.get('trigger_words', []))
        target_arch = set(target_profile.get('architecture', {}).get('patterns', []))

        transfers = []

        for other_name, other_profile in self.profile.get('skills', {}).items():
            if other_name == target_name:
                continue

            other_kw = {k['keyword'] for k in other_profile.get('keywords', [])}
            other_triggers = set(other_profile.get('trigger_words', []))
            other_arch = set(other_profile.get('architecture', {}).get('patterns', []))

            # 1. Keyword overlap analysis
            shared_kw = target_kw & other_kw
            missing_kw = other_kw - target_kw  # Keywords in other but not target

            # High-value missing keywords (top-ranked in other skill)
            other_kw_ranked = {
                k['keyword']: k['score'] for k in other_profile.get('keywords', [])[:30]
            }
            valuable_missing = []
            for kw in missing_kw:
                if kw in other_kw_ranked and kw not in CODE_NOISE and kw not in ZH_GENERIC_NOISE:
                    score = other_kw_ranked[kw]
                    if score >= 2.0:
                        valuable_missing.append({
                            'keyword': kw,
                            'source_skill': other_name,
                            'source_score': round(score, 2),
                            'type': 'keyword_transfer',
                        })

            # 2. Trigger word transfer
            missing_triggers = other_triggers - target_triggers
            # Only transfer if domains overlap significantly
            if len(shared_kw) >= 3:
                for trigger in missing_triggers:
                    if trigger not in CODE_NOISE and trigger not in ZH_GENERIC_NOISE:
                        valuable_missing.append({
                            'keyword': trigger,
                            'source_skill': other_name,
                            'shared_keywords': len(shared_kw),
                            'type': 'trigger_transfer',
                        })

            # 3. Architecture pattern transfer (missing configs)
            missing_arch = other_arch - target_arch
            for arch in missing_arch:
                transfers.append({
                    'pattern': arch,
                    'source_skill': other_name,
                    'type': 'architecture_transfer',
                    'recommendation': f"Consider adding {arch} (present in {other_name})",
                })

            transfers.extend(valuable_missing[:10])  # Top 10 per other skill

        # Sort by value
        transfers.sort(key=lambda x: -x.get('source_score', x.get('shared_keywords', 1)))
        return transfers[:30]

    def build_pattern_library(self):
        """Build a reusable pattern library from all skills."""
        patterns = {
            'generated_at': datetime.now().isoformat(),
            'algorithm_patterns': [],
            'workflow_patterns': [],
            'architecture_templates': [],
            'trigger_word_templates': [],
            'knowledge_structures': [],
        }

        for name, profile in self.profile.get('skills', {}).items():
            # Algorithm patterns
            for algo in profile.get('algorithms', []):
                patterns['algorithm_patterns'].append({
                    'name': algo['name'],
                    'type': algo['type'],
                    'source_skill': name,
                    'reusable': any(kw in algo['name'].lower() for kw in [
                        'score', 'compute', 'analyze', 'validate', 'merge',
                        'dedup', 'search', 'encrypt', 'sync', 'check',
                    ]),
                })

            # Workflow patterns
            for wf in profile.get('workflows', []):
                patterns['workflow_patterns'].append({
                    'source_skill': name,
                    'type': wf['type'],
                    'step_count': len(wf.get('steps', [])),
                    'steps': wf.get('steps', [])[:10],
                })

            # Architecture templates
            arch = profile.get('architecture', {})
            if arch.get('completeness_pct', 0) >= 75:
                patterns['architecture_templates'].append({
                    'source_skill': name,
                    'patterns': arch.get('patterns', []),
                    'completeness': arch.get('completeness_pct', 0),
                })

            # Trigger word templates (from high-trigger-count skills)
            triggers = profile.get('trigger_words', [])
            if len(triggers) >= 5:
                patterns['trigger_word_templates'].append({
                    'source_skill': name,
                    'triggers': triggers,
                    'domain': profile.get('domain_tags', []),
                })

            # Knowledge structures
            for kb in profile.get('knowledge_bases', []):
                patterns['knowledge_structures'].append({
                    'source_skill': name,
                    'type': kb.get('type'),
                    'size_kb': kb.get('size_kb', 0),
                    'topics': kb.get('topics', [])[:10],
                })

        # Save
        PATTERN_LIB_FILE.write_text(
            json.dumps(patterns, ensure_ascii=False, indent=1),
            encoding='utf-8'
        )

        if self.verbose:
            print(f"[OK] Pattern library: "
                  f"{len(patterns['algorithm_patterns'])} algorithms, "
                  f"{len(patterns['workflow_patterns'])} workflows, "
                  f"{len(patterns['architecture_templates'])} templates, "
                  f"{len(patterns['trigger_word_templates'])} trigger templates")

        return patterns

    def _load_profile(self):
        f = DATA_DIR / "local_skills_profile.json"
        if f.exists():
            data = safe_read_json(f)
            return data if data else {}
        return {}

    def _load_market(self):
        f = DATA_DIR / "keyword_frequency.json"
        if f.exists():
            data = safe_read_json(f)
            return data if data else {}
        return {}


# ============================================================
# Self-Optimizing Keyword Engine
# ============================================================

class SelfOptimizingEngine:
    """Use learned data to optimize skill keywords/triggers with evolved weights."""

    DOMAIN_BOOST = {
        "税务": 1.5, "发票": 1.5, "增值税": 1.5, "所得税": 1.5, "汇算": 1.5,
        "扣除": 1.3, "申报": 1.3, "税负": 1.4, "稽查": 1.5, "风险": 1.3,
        "合规": 1.5, "整改": 1.4, "纳税": 1.4, "优惠": 1.3, "减免": 1.3,
        "审计": 1.3, "核算": 1.3, "抵扣": 1.4, "财务": 1.3, "会计": 1.3,
        "记账": 1.3, "报表": 1.3, "凭证": 1.3, "银行": 1.2, "资金": 1.2,
        "五流": 1.5, "三流": 1.5, "合同": 1.2, "预警": 1.5, "金税": 1.5,
        "风控": 1.4, "学习": 1.2, "规划": 1.2, "目标": 1.2, "任务": 1.2,
        "搜索": 1.2, "影视": 1.2, "资源": 1.1, "市场": 1.1, "趋势": 1.2,
        "优化": 1.2, "关键词": 1.3, "触发词": 1.3, "采集": 1.1, "分析": 1.1,
    }

    def __init__(self, learn_data, verbose=False):
        self.learn_data = learn_data
        self.verbose = verbose
        self.weights = learn_data.get_weights()
        self.market = self._load_market()
        self.trends = self._load_trends()

    def optimize_skill(self, skill_dir):
        """Generate optimization suggestions for a skill using all data sources."""
        skill_dir = Path(skill_dir)
        skill_name = skill_dir.name

        # Load skill profile
        profile = self._load_skill_profile(skill_name)

        # Collect all candidate keywords with scored evidence
        candidates = {}

        # Source 1: Local skill keywords
        for kw_entry in profile.get('keywords', []):
            kw = kw_entry['keyword']
            score = kw_entry['score']
            if kw in CODE_NOISE or kw in ZH_GENERIC_NOISE:
                continue
            candidates[kw] = {
                'keyword': kw,
                'local_score': score,
                'market_score': 0,
                'cross_skill_score': 0,
                'rising_boost': 0,
                'domain_boost': self.DOMAIN_BOOST.get(kw, 1.0),
                'source': 'local',
                'evidence': ['LOCAL'],
            }

        # Source 2: Market data
        if self.market:
            for entry in self.market.get('top_keywords', [])[:200]:
                kw = entry['keyword']
                if kw in CODE_NOISE or kw in ZH_GENERIC_NOISE:
                    continue
                if kw in candidates:
                    candidates[kw]['market_score'] = entry['score']
                    candidates[kw]['evidence'].append('MARKET')
                else:
                    candidates[kw] = {
                        'keyword': kw,
                        'local_score': 0,
                        'market_score': entry['score'],
                        'cross_skill_score': 0,
                        'rising_boost': 0,
                        'domain_boost': self.DOMAIN_BOOST.get(kw, 1.0),
                        'source': 'market',
                        'evidence': ['MARKET'],
                    }

        # Source 3: Cross-skill transfer
        transfer = CrossSkillTransfer(self.learn_data)
        for item in transfer.find_transferable_patterns(skill_dir)[:20]:
            kw = item.get('keyword', item.get('pattern', ''))
            if kw in CODE_NOISE or kw in ZH_GENERIC_NOISE:
                continue
            if kw in candidates:
                candidates[kw]['cross_skill_score'] += item.get('source_score', 2.0)
                candidates[kw]['evidence'].append(f'CROSS:{item["source_skill"]}')
            else:
                candidates[kw] = {
                    'keyword': kw,
                    'local_score': 0,
                    'market_score': 0,
                    'cross_skill_score': item.get('source_score', 2.0),
                    'rising_boost': 0,
                    'domain_boost': self.DOMAIN_BOOST.get(kw, 1.0),
                    'source': 'cross_skill',
                    'evidence': [f'CROSS:{item["source_skill"]}'],
                }

        # Source 4: Rising trends
        if self.trends and len(self.trends) >= 2:
            recent = {k['keyword']: k['score']
                      for k in self.trends[-1].get('top_50_keywords', [])}
            older = {k['keyword']: k['score']
                     for k in self.trends[-2].get('top_50_keywords', [])}
            for kw, score in recent.items():
                if kw in candidates:
                    old = older.get(kw, 0)
                    if old > 0:
                        pct = (score - old) / old
                        candidates[kw]['rising_boost'] = min(pct, 2.0)
                        candidates[kw]['evidence'].append('RISING')

        # Compute composite score using evolved weights
        w = self.weights
        for kw, info in candidates.items():
            is_chinese = any('\u4e00' <= c <= '\u9fff' for c in kw)
            len_bonus = w.get('trigger_length_2_4', 1.2) if (is_chinese and 2 <= len(kw) <= 4) else 1.0

            composite = (
                info['local_score'] * w.get('local_keyword_freq', 1.5) +
                info['market_score'] * w.get('market_keyword_freq', 0.3) +
                info['cross_skill_score'] * w.get('cross_skill_transfer', 0.8) +
                info['rising_boost'] * w.get('rising_trend_boost', 5.0) +
                (w.get('market_evidence_bonus', 3.0) if 'MARKET' in info['evidence'] else 0)
            ) * info['domain_boost'] * len_bonus

            info['composite_score'] = round(composite, 2)

        # Filter existing triggers
        existing_triggers = set(profile.get('trigger_words', []))
        new_triggers = []
        for kw, info in sorted(candidates.items(), key=lambda x: -x[1]['composite_score']):
            if kw in existing_triggers:
                continue
            is_chinese = any('\u4e00' <= c <= '\u9fff' for c in kw)
            if is_chinese and 2 <= len(kw) <= 6 and info['composite_score'] >= 4.0:
                new_triggers.append(info)
            elif not is_chinese and len(kw) >= 3 and info['composite_score'] >= 3.0:
                new_triggers.append(info)

        return new_triggers[:20], candidates

    def apply_optimization(self, skill_dir, new_triggers):
        """Apply optimized triggers to SKILL.md."""
        skill_dir = Path(skill_dir)
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            print("[ERROR] SKILL.md not found")
            return False

        content = safe_read_text(skill_md, timeout=5)
        fm_match = re.match(r'^(---\s*\n)(.*?)(\n---)', content, re.DOTALL)
        if not fm_match:
            print("[ERROR] No frontmatter found")
            return False

        fm_body = fm_match.group(2)
        desc_match = re.search(r'description:\s*(.+)', fm_body)
        if not desc_match:
            print("[ERROR] No description field")
            return False

        current = desc_match.group(1).strip()
        add = [t['keyword'] for t in new_triggers if t['keyword'] not in current.lower()]
        if not add:
            print("[INFO] No new triggers to add")
            return True

        unique_add = list(dict.fromkeys(add))[:12]
        addition = '、'.join(unique_add)

        if '触发词包括' in current:
            new_desc = current.rstrip('。.') + '、' + addition + '。'
        else:
            new_desc = current + '。触发词包括：' + addition + '。'

        new_fm = fm_body.replace(desc_match.group(0), f"description: {new_desc}")
        new_content = fm_match.group(1) + new_fm + fm_match.group(3) + content[fm_match.end():]
        skill_md.write_text(new_content, encoding='utf-8')

        # Log optimization
        self._log_optimization(skill_dir.name, unique_add)

        # Record success for each trigger (user confirmed by --apply)
        for t in new_triggers[:len(unique_add)]:
            source = t.get('source', 'unknown')
            self.learn_data.record_success(source, keyword=t['keyword'])

        print(f"[OK] Applied {len(unique_add)} triggers: {addition}")
        return True

    def _load_skill_profile(self, skill_name):
        profile_file = DATA_DIR / "local_skills_profile.json"
        if profile_file.exists():
            try:
                data = safe_read_json(profile_file)
                return data.get('skills', {}).get(skill_name, {})
            except:
                return {}
        return {}

    def _load_market(self):
        f = DATA_DIR / "keyword_frequency.json"
        if f.exists():
            data = safe_read_json(f)
            return data if data else {}
        return {}

    def _load_trends(self):
        f = DATA_DIR / "trend_history.json"
        if f.exists():
            data = safe_read_json(f)
            return data if isinstance(data, list) else []
        return []
        return []

    def _log_optimization(self, skill_name, triggers):
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'skill': skill_name,
            'triggers_added': triggers,
            'weights_used': dict(self.weights),
        }
        log = []
        if OPT_LOG_FILE.exists():
            try:
                log = safe_read_json(OPT_LOG_FILE)
            except:
                log = []
        log.append(log_entry)
        if len(log) > 200:
            log = log[-200:]
        OPT_LOG_FILE.write_text(
            json.dumps(log, ensure_ascii=False, indent=1),
            encoding='utf-8'
        )


# ============================================================
# Learning Report Generator
# ============================================================

def generate_report(learn_data, verbose=False):
    """Generate a comprehensive learning progress report."""
    weights = learn_data.get_weights()
    effectiveness = learn_data.get_effectiveness_report()

    lines = []
    lines.append("=" * 65)
    lines.append("  Cross-Skill Learning Progress Report")
    lines.append(f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("=" * 65)

    # Overall stats
    lines.append(f"\n[STATISTICS]")
    lines.append(f"  Total scans: {learn_data.data.get('scan_count', 0)}")
    lines.append(f"  Total optimizations: {learn_data.data.get('optimization_count', 0)}")
    lines.append(f"  Successes: {learn_data.data.get('success_count', 0)}")
    lines.append(f"  Failures: {learn_data.data.get('failure_count', 0)}")
    total = learn_data.data.get('success_count', 0) + learn_data.data.get('failure_count', 0)
    if total > 0:
        lines.append(f"  Overall success rate: {learn_data.data['success_count']/total*100:.1f}%")

    # Evolved weights
    lines.append(f"\n[EVOLVED WEIGHTS] (adjusted by learning)")
    for wkey, wval in sorted(weights.items()):
        default = {
            'local_keyword_freq': 1.5, 'market_keyword_freq': 0.3,
            'rising_trend_boost': 5.0, 'domain_boost_factor': 1.3,
            'cross_skill_transfer': 0.8, 'architecture_completeness': 1.0,
            'trigger_length_2_4': 1.2, 'market_evidence_bonus': 3.0,
        }.get(wkey, 1.0)
        change = ((wval - default) / default * 100) if default > 0 else 0
        marker = " [EVOLVED]" if abs(change) > 5 else ""
        lines.append(f"  {wkey:<30s} {wval:>6.3f} (default={default:.3f}, {change:+.1f}%){marker}")

    # Source effectiveness
    lines.append(f"\n[SOURCE EFFECTIVENESS]")
    for source, stats in effectiveness.items():
        rate = stats['success_rate']
        bar = '#' * int(rate / 5)
        lines.append(f"  {source:<25s} {stats['adopted']:>3d}/{stats['total_recommendations']:>3d} "
                     f"({rate:>5.1f}%) {bar}")

    # Cross-skill patterns
    patterns = learn_data.data.get('cross_skill_patterns', {})
    if patterns:
        lines.append(f"\n[CROSS-SKILL PATTERNS] {len(patterns)} learned")
        for name, data in list(patterns.items())[:10]:
            lines.append(f"  {name}: {json.dumps(data, ensure_ascii=False)[:80]}")

    # Discovered relations
    relations = learn_data.data.get('discovered_relations', [])
    if relations:
        lines.append(f"\n[DISCOVERED RELATIONS] {len(relations)} auto-discovered")
        for r in relations[:10]:
            if r['type'] == 'cross_skill_keyword':
                lines.append(f"  Keyword '{r['keyword']}' in {r['strength']} skills: "
                             f"{', '.join(r['skills'][:5])}")
            elif r['type'] == 'high_completeness_pattern':
                lines.append(f"  Pattern '{r['pattern']}' -> avg completeness "
                             f"{r['avg_completeness']}%")

    # Keyword history trends
    kw_history = learn_data.data.get('keyword_history', {})
    trending_up = []
    for kw, history in kw_history.items():
        if len(history) >= 2:
            recent = history[-1]['score']
            older = history[-2]['score'] if len(history) >= 2 else 0
            if older > 0 and recent > older * 1.2:
                trending_up.append((kw, older, recent))
    if trending_up:
        lines.append(f"\n[LEARNED KEYWORD TRENDS] Rising in your ecosystem:")
        trending_up.sort(key=lambda x: -x[2]/x[1])
        for kw, old, new in trending_up[:10]:
            lines.append(f"  {kw:<20s} {old:.1f} -> {new:.1f} (+{new/old*100-100:.0f}%)")

    lines.append(f"\n{'=' * 65}")
    print("\n".join(lines))


# ============================================================
# CLI Entry Point
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Cross-Skill Learner & Self-Optimizer")
    parser.add_argument("--skill", metavar="DIR", help="Optimize a specific skill")
    parser.add_argument("--apply", metavar="DIR", help="Apply optimizations to skill")
    parser.add_argument("--report", action="store_true", help="Learning progress report")
    parser.add_argument("--reset-weights", action="store_true", help="Reset learned weights")
    parser.add_argument("--build-patterns", action="store_true",
                       help="Build pattern library from all skills")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    # ---- 执行日志 start ----
    subcmd = "reset" if args.reset_weights else "report" if args.report else "build_patterns" if args.build_patterns else "apply" if args.apply else "skill" if args.skill else "full_cycle"
    logger = ExecutionLogger("cross_skill_learner")
    logger.start({
        "subcommand": subcmd,
        "skill": args.skill,
        "apply": args.apply,
        "verbose": args.verbose
    })
    
    # ---- Token 日志 start ----
    start_time = datetime.now()
    try:
        from token_logger import TokenLogger
        token_logger = TokenLogger("skill-trend-analyzer")
    except ImportError:
        token_logger = None

    try:
        learn_data = LearningData()

        if args.reset_weights:
            learn_data.reset_weights()
            logger.done({"subcommand": "reset_weights", "status": "ok"})
            return

        if args.report:
            generate_report(learn_data, args.verbose)
            logger.done({"subcommand": "report", "learn_data_entries": len(learn_data.data)})
            return

        if args.build_patterns:
            logger.phase("build_patterns")
            transfer = CrossSkillTransfer(learn_data, args.verbose)
            transfer.build_pattern_library()
            learn_data.increment_scan()
            logger.done({
                "subcommand": "build_patterns",
                "cross_skill_patterns": len(learn_data.data.get("cross_skill_patterns", {})),
                "learn_data_entries": len(learn_data.data),
            })
            return

        if args.apply:
            logger.phase("optimize")
            engine = SelfOptimizingEngine(learn_data, args.verbose)
            new_triggers, _ = engine.optimize_skill(args.apply)
            if new_triggers:
                print(f"\n[RECOMMENDATIONS] {len(new_triggers)} new triggers for "
                      f"{Path(args.apply).name}:")
                for t in new_triggers[:15]:
                    evidence = ', '.join(t['evidence'][:3])
                    print(f"  + {t['keyword']:<18s} score={t['composite_score']:.1f} "
                          f"domain=x{t['domain_boost']:.1f} [{evidence}]")
                logger.phase("apply")
                engine.apply_optimization(args.apply, new_triggers)
            else:
                print("[INFO] No new trigger suggestions - skill is well optimized!")
            learn_data.increment_scan()
            logger.done({
                "subcommand": "apply",
                "skill": args.apply,
                "new_triggers": len(new_triggers),
            })
            return

        if args.skill:
            logger.phase("optimize")
            engine = SelfOptimizingEngine(learn_data, args.verbose)
            new_triggers, all_candidates = engine.optimize_skill(args.skill)
            if new_triggers:
                print(f"\n[RECOMMENDATIONS] for {Path(args.skill).name}:")
                for t in new_triggers[:15]:
                    evidence = ', '.join(t['evidence'][:3])
                    print(f"  + {t['keyword']:<18s} score={t['composite_score']:.1f} "
                          f"domain=x{t['domain_boost']:.1f} [{evidence}]")
            else:
                print("[INFO] No new trigger suggestions")
            learn_data.increment_scan()
            logger.done({
                "subcommand": "skill",
                "skill": args.skill,
                "new_triggers": len(new_triggers),
            })
            return

        # Default: full learning cycle
        logger.phase("step1_scan")
        print("[INFO] Running full learning cycle...")

        # Step 1: Scan all local skills (with timeout & error recovery)
        print("\n[Step 1/4] Scanning local skills...")
        try:
            with TimeoutGuard(seconds=120, message="Full skill scan stuck (>120s)"):
                from local_skill_scanner import MultiSkillScanner
                scanner = MultiSkillScanner(verbose=args.verbose)
                scanner.scan_all()
        except Exception as e:
            safe_print(f"[WARNING] Step 1 scan failed: {e}, continuing with cached data")

        logger.phase("step2_patterns")
        # Step 2: Build pattern library
        print("\n[Step 2/4] Building pattern library...")
        try:
            with TimeoutGuard(seconds=60, message="Pattern library build stuck (>60s)"):
                transfer = CrossSkillTransfer(learn_data, args.verbose)
                transfer.build_pattern_library()
        except Exception as e:
            safe_print(f"[WARNING] Step 2 pattern build failed: {e}")

        logger.phase("step3_relations")
        # Step 3: Auto-discover relations
        print("\n[Step 3/4] Auto-discovering cross-skill relations...")
        try:
            with TimeoutGuard(seconds=60, message="Relation discovery stuck (>60s)"):
                relations = learn_data._auto_discover()
                print(f"[OK] Discovered {len(relations)} relations")
        except Exception as e:
            safe_print(f"[WARNING] Step 3 relation discovery failed: {e}")
            relations = []

        logger.phase("step4_keyword_history")
        # Step 4: Update keyword history
        print("\n[Step 4/4] Updating keyword history...")
        try:
            with TimeoutGuard(seconds=30, message="Keyword history update stuck (>30s)"):
                profile = learn_data._load_profile()
                for name, prof in profile.get('skills', {}).items():
                    keywords = [(k['keyword'], k['score']) for k in prof.get('keywords', [])[:30]]
                    learn_data.update_keyword_history(keywords)
        except Exception as e:
            safe_print(f"[WARNING] Step 4 keyword update failed: {e}")

        learn_data.increment_scan()
        print(f"\n[OK] Learning cycle complete. Scan #{learn_data.data['scan_count']}")

        logger.done({
            "subcommand": "full_cycle",
            "scan_count": learn_data.data['scan_count'],
            "relations_discovered": len(relations),
            "cross_skill_patterns": len(learn_data.data.get("cross_skill_patterns", {})),
            "keyword_history_entries": len(learn_data.data.get("keyword_history", {})),
            "learn_data_entries": len(learn_data.data),
        })

    except Exception as e:
        logger.fail(str(e), {"subcommand": subcmd})
        import traceback; traceback.print_exc()
    finally:
        # ---- Token 日志记录 ----
        if token_logger:
            duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            # 估算 token 消耗（基于 learn_data 条目数）
            learn_entries = len(learn_data.data) if 'learn_data' in dir() else 0
            estimated_tokens = learn_entries * 50 + 1000
            token_logger.log(
                action=f"cross_learn_{subcmd}",
                tokens={"input": estimated_tokens // 3, "output": estimated_tokens * 2 // 3, "total": estimated_tokens},
                duration_ms=duration_ms,
                metadata={"subcommand": subcmd, "learn_entries": learn_entries}
            )
    
    # Fixed ending - contact author info (ClawHub compliance)
    from safe_io import print_footer
    print_footer()


if __name__ == "__main__":
    main()

    # Fixed ending - contact author info (ClawHub compliance)
    from safe_io import print_footer
    print_footer()

