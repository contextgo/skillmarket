#!/usr/bin/env python3
# Copyright (c) 2026 WorkBuddy Skills. All rights reserved.
# Skill: skill-trend-analyzer | Version: 2.3.0
# Author: QQ 1817694478 | Q-Group: 972156177
"""
Local Skill Deep Scanner
=========================
Comprehensively scans all locally installed skills, extracting:
  - File structure & architecture patterns
  - Workflow logic & step definitions
  - Algorithm patterns from Python scripts
  - Knowledge base content from .md/.json references
  - Configuration & metadata from YAML/JSON/TOML
  - Usage patterns from logs & memory files
  - Cross-skill reusable patterns

Output: data/local_skills_profile.json (comprehensive skill ecosystem map)

Usage:
  python local_skill_scanner.py [--verbose]
  python local_skill_scanner.py --skill <skill_dir>   # Scan single skill
  python local_skill_scanner.py --status               # Show scan status
  python local_skill_scanner.py --diff                 # Show changes since last scan
"""
import sys, io, os, re, json, hashlib, math
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict

# [Safe Guard: 5-layer anti-freeze system]
from safe_guard import safe_print, safe_init, TimeoutGuard, safe_read_text, safe_read_json
from exec_logger import ExecutionLogger
safe_init()

SCRIPT_DIR = Path(__file__).parent
DATA_DIR = SCRIPT_DIR.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

SKILLS_ROOT = Path.home() / ".workbuddy" / "skills"
OUTPUT_FILE = DATA_DIR / "local_skills_profile.json"
SCAN_LOG = DATA_DIR / "scan_log.json"  # Scan log

# Skip these directories during scan
SKIP_DIRS = {'.git', '__pycache__', 'node_modules', '.vscode', '.idea', 'dist', 'build'}
# Skip these files (by name)
SKIP_FILES = {'.DS_Store', 'Thumbs.db', '.gitkeep'}
# Max file size to read (1MB)
MAX_FILE_SIZE = 1 * 1024 * 1024


# ============================================================
# Skill File Scanner
# ============================================================

class SkillScanner:
    """Deep-scan a single skill directory, extracting all useful patterns."""

    def __init__(self, skill_dir, verbose=False):
        self.skill_dir = Path(skill_dir)
        self.skill_name = self.skill_dir.name
        self.verbose = verbose
        self.profile = {
            'name': self.skill_name,
            'scanned_at': datetime.now().isoformat(),
            'file_structure': {},
            'architecture': {},
            'workflows': [],
            'algorithms': [],
            'knowledge_bases': [],
            'config_patterns': [],
            'trigger_words': [],
            'keywords': Counter(),
            'domain_tags': [],
            'quality_signals': {},
            'cross_skill_value': {},
            # Frontmatter增强字段
            'skill_version_yaml': '',
            'author': '',
            'homepage': '',
            'frontmatter_tags': [],
            'category': '',
            'license': '',
        }

    def scan(self):
        """Run full scan of skill directory."""
        if self.verbose:
            print(f"[SCAN] Scanning: {self.skill_name}")

        # Phase 1: File structure census
        self._scan_file_structure()

        # Phase 2: SKILL.md deep parse
        self._parse_skill_md()

        # Phase 3: Python script analysis
        self._parse_python_files()

        # Phase 4: Knowledge base extraction (.md/.json references)
        self._parse_references()

        # Phase 5: Config & metadata extraction
        self._parse_configs()

        # Phase 6: Log & memory analysis
        self._parse_logs_and_memory()

        # Phase 7: Architecture pattern detection
        self._detect_architecture_patterns()

        # Phase 8: Cross-skill value extraction
        # (runs before Counter conversion, so use Counter directly)
        self._extract_cross_skill_value()

        # Convert Counter to sorted list for JSON serialization
        self.profile['keywords'] = [
            {'keyword': kw, 'score': round(score, 2)}
            for kw, score in self.profile['keywords'].most_common(200)
        ]

        if self.verbose:
            total_files = sum(self.profile['file_structure'].get('stats', {}).values())
            print(f"[OK] {self.skill_name}: {total_files} files, "
                  f"{len(self.profile['workflows'])} workflows, "
                  f"{len(self.profile['algorithms'])} algorithms, "
                  f"{len(self.profile['knowledge_bases'])} knowledge bases")

        return self.profile

    # --------------------------------------------------------
    # Phase 1: File Structure Census
    # --------------------------------------------------------
    def _scan_file_structure(self):
        """Census all files, categorize by type and directory."""
        stats = Counter()
        dirs = set()
        key_files = {}

        for f in self.skill_dir.rglob("*"):
            if f.is_dir():
                continue
            rel = f.relative_to(self.skill_dir)
            parts = rel.parts

            # Skip unwanted
            if any(d in SKIP_DIRS for d in parts):
                continue
            if f.name in SKIP_FILES:
                continue
            if f.stat().st_size > MAX_FILE_SIZE:
                continue

            ext = f.suffix.lower()
            stats[ext] += 1

            # Track directory structure
            if len(parts) > 1:
                dirs.add(parts[0])

            # Key file detection
            fname = f.name.lower()
            if fname == 'skill.md':
                key_files['skill_md'] = str(rel)
            elif fname == 'manifest.json':
                key_files['manifest'] = str(rel)
            elif fname == '_meta.json':
                key_files['meta'] = str(rel)
            elif fname == 'integrity_guard.py':
                key_files['integrity_guard'] = str(rel)
            elif fname == 'learn_sync.py':
                key_files['learn_sync'] = str(rel)
            elif fname == 'build_release.py':
                key_files['build_release'] = str(rel)
            elif fname.startswith('learn_data'):
                key_files['learn_data'] = str(rel)
            elif fname == '.clawdhubignore':
                key_files['clawdhubignore'] = str(rel)

        self.profile['file_structure'] = {
            'stats': dict(stats),
            'directories': sorted(dirs),
            'key_files': key_files,
            'has_standard_config': all(
                k in key_files for k in ['skill_md', 'integrity_guard', 'learn_sync']
            ),
        }

    # --------------------------------------------------------
    # Phase 2: SKILL.md Deep Parse
    # --------------------------------------------------------
    def _parse_skill_md(self):
        """Parse SKILL.md for triggers, description, workflows, sections."""
        skill_md = self.skill_dir / "SKILL.md"
        if not skill_md.exists():
            return

        content = safe_read_text(skill_md, timeout=5)
        if not content:
            return

        # Frontmatter (增强版 - 支持更多字段)
        fm = re.match(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
        if fm:
            fm_text = fm.group(1)
            
            # 基础字段
            desc = re.search(r'description:\s*(.+)', fm_text)
            if desc:
                desc_text = desc.group(1).strip()
                self.profile['trigger_words'] = self._extract_triggers(desc_text)
                # Chinese keywords from description
                for zh in re.findall(r'[\u4e00-\u9fff]{2,8}', desc_text):
                    self.profile['keywords'][zh] += 3.0

            name_match = re.search(r'name:\s*(.+)', fm_text)
            if name_match:
                self.profile['skill_name_yaml'] = name_match.group(1).strip()
            
            # 增强: 解析更多frontmatter字段
            version_match = re.search(r'version:\s*(.+)', fm_text)
            if version_match:
                self.profile['skill_version_yaml'] = version_match.group(1).strip()
            
            author_match = re.search(r'author:\s*(.+)', fm_text)
            if author_match:
                self.profile['author'] = author_match.group(1).strip()
            
            homepage_match = re.search(r'homepage:\s*(.+)', fm_text)
            if homepage_match:
                self.profile['homepage'] = homepage_match.group(1).strip()
            
            tags_match = re.search(r'tags:\s*\[(.*?)\]', fm_text, re.DOTALL)
            if tags_match:
                tags = [t.strip().strip('"\'') for t in tags_match.group(1).split(',')]
                self.profile['frontmatter_tags'] = [t for t in tags if t]
            
            # YAML多行字段解析
            category_match = re.search(r'category:\s*(.+)', fm_text)
            if category_match:
                self.profile['category'] = category_match.group(1).strip()
            
            license_match = re.search(r'license:\s*(.+)', fm_text)
            if license_match:
                self.profile['license'] = license_match.group(1).strip()

        # Section headings
        sections = []
        for h in re.findall(r'^#{1,4}\s+(.+)$', content, re.MULTILINE):
            sections.append(h.strip())
            for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', h):
                self.profile['keywords'][zh] += 2.0
        self.profile['sections'] = sections

        # Bold terms (important concepts)
        for term in re.findall(r'\*\*(.+?)\*\*', content):
            for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', term):
                self.profile['keywords'][zh] += 2.5

        # Table content (key-value pairs)
        for row in re.findall(r'\|\s*(.+?)\s*\|\s*(.+?)\s*\|', content):
            for cell in row:
                for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', cell):
                    self.profile['keywords'][zh] += 1.5

        # Step/workflow detection from numbered lists
        step_pattern = re.findall(
            r'(?:Step|步骤|第[一二三四五六七八九十\d]+步)\s*[\d:：]*\s*(.+?)(?:\n|$)',
            content, re.IGNORECASE
        )
        if step_pattern:
            self.profile['workflows'].append({
                'source': 'SKILL.md',
                'type': 'step_workflow',
                'steps': [s.strip() for s in step_pattern if s.strip()],
            })

        # Version detection
        ver = re.search(r'v(\d+\.\d+\.\d+)', content)
        if ver:
            self.profile['version'] = ver.group(1)

    # --------------------------------------------------------
    # Phase 3: Python Script Analysis
    # --------------------------------------------------------
    def _parse_python_files(self):
        """Analyze Python scripts for algorithms, classes, functions."""
        for py in self.skill_dir.rglob("*.py"):
            if any(d in SKIP_DIRS for d in py.relative_to(self.skill_dir).parts):
                continue
            content = safe_read_text(py, timeout=5)
            if not content:
                continue

            rel = str(py.relative_to(self.skill_dir))

            # Class definitions
            for cls in re.findall(r'class\s+([A-Z][a-zA-Z0-9_]+)', content):
                self.profile['algorithms'].append({
                    'source': rel,
                    'type': 'class',
                    'name': cls,
                })
                # Split CamelCase into keywords
                for w in re.findall(r'[A-Z][a-z]+', cls):
                    if len(w) > 2:
                        self.profile['keywords'][w.lower()] += 1.5

            # Function definitions
            funcs = re.findall(r'def\s+([a-z_][a-zA-Z0-9_]*)\s*\(', content)
            for func in funcs:
                if func.startswith('_'):
                    continue
                # Detect algorithm-type functions
                algo_keywords = ['compute', 'calculate', 'analyze', 'score',
                               'evaluate', 'detect', 'predict', 'optimize',
                               'search', 'match', 'classify', 'generate',
                               'transform', 'validate', 'merge', 'dedup']
                if any(func.startswith(ak) or f'_{ak}' in func for ak in algo_keywords):
                    self.profile['algorithms'].append({
                        'source': rel,
                        'type': 'algorithm_function',
                        'name': func,
                    })
                    # Extract words from function name
                    for w in func.split('_'):
                        if len(w) > 2:
                            self.profile['keywords'][w] += 1.0

            # Chinese comments (domain knowledge)
            for comment in re.findall(r'#\s*(.+)', content):
                for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', comment):
                    self.profile['keywords'][zh] += 0.8

            # Docstrings (key knowledge)
            for doc in re.findall(r'"""(.+?)"""', content, re.DOTALL):
                for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', doc):
                    self.profile['keywords'][zh] += 1.2
                # Extract key concepts from docstrings
                for concept in re.findall(r'[A-Z][a-zA-Z]+(?:[A-Z][a-zA-Z]+)+', doc):
                    for w in re.findall(r'[A-Z][a-z]+', concept):
                        if len(w) > 2:
                            self.profile['keywords'][w.lower()] += 1.0

            # Workflow step detection in code
            if 'Step' in content or '步骤' in content:
                steps = re.findall(
                    r'(?:Step|STEP)\s*(\d+)[：:]\s*(.+?)(?:\n|$)',
                    content, re.IGNORECASE
                )
                if steps:
                    self.profile['workflows'].append({
                        'source': rel,
                        'type': 'code_workflow',
                        'steps': [f"Step {n}: {s.strip()}" for n, s in steps],
                    })

    # --------------------------------------------------------
    # Phase 4: Knowledge Base Extraction
    # --------------------------------------------------------
    def _parse_references(self):
        """Parse references/ directory for knowledge content."""
        refs_dir = self.skill_dir / "references"
        if not refs_dir.exists():
            return

        for ref_file in refs_dir.iterdir():
            if ref_file.is_dir():
                continue

            ext = ref_file.suffix.lower()
            rel = str(ref_file.relative_to(self.skill_dir))

            if ext == '.md':
                self._parse_md_reference(ref_file, rel)
            elif ext == '.json':
                self._parse_json_reference(ref_file, rel)

    def _parse_md_reference(self, fpath, rel):
        """Parse a markdown reference file."""
        content = safe_read_text(fpath, timeout=5)
        if not content:
            return

        # Headings as knowledge topics
        topics = []
        for h in re.findall(r'^#{1,4}\s+(.+)$', content, re.MULTILINE):
            topics.append(h.strip())
            for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', h):
                self.profile['keywords'][zh] += 1.5

        # Bold terms
        for term in re.findall(r'\*\*(.+?)\*\*', content):
            for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', term):
                self.profile['keywords'][zh] += 2.0

        # Tables (structured knowledge)
        tables = content.count('|---') + content.count('|:--')

        # Code blocks (algorithms/configs)
        code_blocks = re.findall(r'```(\w+)', content)

        kb_entry = {
            'source': rel,
            'type': 'markdown',
            'size_kb': round(fpath.stat().st_size / 1024, 1),
            'topics': topics[:20],
            'has_tables': tables > 0,
            'code_languages': code_blocks,
        }
        self.profile['knowledge_bases'].append(kb_entry)

    def _parse_json_reference(self, fpath, rel):
        """Parse a JSON reference file."""
        try:
            data = safe_read_json(fpath)
        except:
            return

        # Extract structure info
        entry = {
            'source': rel,
            'type': 'json',
            'size_kb': round(fpath.stat().st_size / 1024, 1),
            'top_keys': list(data.keys())[:20] if isinstance(data, dict) else [],
        }

        # If it's a list, count items
        if isinstance(data, list):
            entry['item_count'] = len(data)
            if data and isinstance(data[0], dict):
                entry['item_keys'] = list(data[0].keys())[:15]

        # Extract Chinese keywords from JSON keys/values
        if isinstance(data, dict):
            for key in data.keys():
                for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', str(key)):
                    self.profile['keywords'][zh] += 0.5
            # Recurse one level for values
            for val in data.values():
                if isinstance(val, str):
                    for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', val):
                        self.profile['keywords'][zh] += 0.3
                elif isinstance(val, list) and val and isinstance(val[0], dict):
                    for item in val[:10]:
                        for k, v in item.items():
                            for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', str(v)):
                                self.profile['keywords'][zh] += 0.2

        self.profile['knowledge_bases'].append(entry)

    # --------------------------------------------------------
    # Phase 5: Config & Metadata
    # --------------------------------------------------------
    def _parse_configs(self):
        """Parse config files (manifest.json, _meta.json, YAML, TOML)."""
        # manifest.json
        manifest = self.skill_dir / "manifest.json"
        if manifest.exists():
            try:
                data = safe_read_json(manifest)
                self.profile['config_patterns'].append({
                    'source': 'manifest.json',
                    'type': 'manifest',
                    'keys': list(data.keys())[:20],
                    'version': data.get('version', 'unknown'),
                })
            except:
                pass

        # _meta.json
        meta = self.skill_dir / "_meta.json"
        if meta.exists():
            try:
                data = safe_read_json(meta)
                self.profile['config_patterns'].append({
                    'source': '_meta.json',
                    'type': 'meta',
                    'keys': list(data.keys())[:15],
                })
                # Meta often has category/tags
                if 'category' in data:
                    self.profile['domain_tags'].append(data['category'])
                if 'tags' in data:
                    self.profile['domain_tags'].extend(
                        data['tags'] if isinstance(data['tags'], list) else [data['tags']]
                    )
            except:
                pass

        # .clawdhubignore → exclusion patterns
        ignore = self.skill_dir / ".clawdhubignore"
        if ignore.exists():
            try:
                lines = [l.strip() for l in safe_read_text(ignore, timeout=3).splitlines()
                        if l.strip() and not l.startswith('#')]
                self.profile['config_patterns'].append({
                    'source': '.clawdhubignore',
                    'type': 'ignore_patterns',
                    'patterns': lines[:20],
                })
            except:
                pass

    # --------------------------------------------------------
    # Phase 6: Log & Memory Analysis
    # --------------------------------------------------------
    def _parse_logs_and_memory(self):
        """Parse usage logs and memory files for usage patterns."""
        # Learn data (self-learning)
        for ld in self.skill_dir.rglob("learn_data*.json"):
            if any(d in SKIP_DIRS for d in ld.relative_to(self.skill_dir).parts):
                continue
            try:
                data = safe_read_json(ld)
                entry = {
                    'source': str(ld.relative_to(self.skill_dir)),
                    'type': 'learn_data',
                    'size_kb': round(ld.stat().st_size / 1024, 1),
                }
                if isinstance(data, dict):
                    entry['keys'] = list(data.keys())[:15]
                    # Success/failure counts
                    for k in ['success_count', 'failure_count', 'total_count']:
                        if k in data:
                            entry[k] = data[k]
                    # Record counts
                    for k, v in data.items():
                        if isinstance(v, list):
                            entry[f'{k}_count'] = len(v)
                self.profile['quality_signals']['learn_data'] = entry
            except:
                pass

        # Collect log
        cl = self.skill_dir / "data" / "collect_log.json"
        if not cl.exists():
            cl = self.skill_dir / "data" / "sync_log.json"
        if cl.exists():
            try:
                logs = safe_read_json(cl)
                if isinstance(logs, list):
                    self.profile['quality_signals']['log_entries'] = len(logs)
                    if logs:
                        self.profile['quality_signals']['last_log'] = logs[-1]
            except:
                pass

        # Working memory files
        # NOTE: memory files contain process instructions, not domain keywords.
        # We only count skill mentions as quality signals; we do NOT extract keywords
        # from these lines to avoid polluting the keyword pool with MEMORY.md fragments.
        mem_dir = Path("e:/AIwork/.workbuddy/memory")
        if mem_dir.exists():
            for mem_file in mem_dir.glob("*.md"):
                try:
                    content = safe_read_text(mem_file, timeout=3)
                    # Only count memory mentions as quality signal (no keyword extraction)
                    if self.skill_name in content:
                        self.profile['quality_signals']['memory_mentions'] = \
                            self.profile['quality_signals'].get('memory_mentions', 0) + 1
                except:
                    pass

    # --------------------------------------------------------
    # Phase 7: Architecture Pattern Detection
    # --------------------------------------------------------
    def _detect_architecture_patterns(self):
        """Detect architectural patterns used by the skill."""
        patterns = []
        fs = self.profile['file_structure']
        kf = fs.get('key_files', {})
        dirs = set(fs.get('directories', []))

        # Standard skill architecture
        if 'scripts' in dirs:
            patterns.append('scripts_dir')
        if 'references' in dirs:
            patterns.append('references_dir')
        if 'lib' in dirs:
            patterns.append('lib_dir')
        if 'assets' in dirs:
            patterns.append('assets_dir')
        if 'data' in dirs:
            patterns.append('data_dir')

        # Standard configurations
        if 'integrity_guard' in kf:
            patterns.append('integrity_guard')
        if 'learn_sync' in kf:
            patterns.append('self_grow')
        if 'learn_data' in kf:
            patterns.append('self_learning')
        if 'build_release' in kf:
            patterns.append('release_build')
        if 'manifest' in kf:
            patterns.append('manifest')

        # Completeness score
        required = {'integrity_guard', 'self_grow', 'self_learning', 'manifest'}
        present = {p for p in patterns if p in required}
        completeness = len(present) / len(required) * 100 if required else 0

        self.profile['architecture'] = {
            'patterns': patterns,
            'completeness_pct': round(completeness, 1),
            'has_standard_config': fs.get('has_standard_config', False),
        }

    # --------------------------------------------------------
    # Phase 8: Cross-Skill Value Extraction
    # --------------------------------------------------------
    def _extract_cross_skill_value(self):
        """Identify patterns/knowledge that could benefit other skills."""
        value = {}

        # 1. Reusable algorithms
        algo_names = [a['name'] for a in self.profile['algorithms']]
        reusable = []
        for algo in algo_names:
            # Commonly reusable patterns
            if any(kw in algo.lower() for kw in [
                'score', 'compute', 'analyze', 'validate', 'merge',
                'dedup', 'search', 'match', 'encrypt', 'decrypt',
                'sync', 'upload', 'download', 'check', 'guard',
            ]):
                reusable.append(algo)
        if reusable:
            value['reusable_algorithms'] = reusable

        # 2. Domain knowledge depth
        kb_total_size = sum(
            kb.get('size_kb', 0) for kb in self.profile['knowledge_bases']
        )
        if kb_total_size > 10:
            value['deep_domain_knowledge'] = {
                'total_size_kb': round(kb_total_size, 1),
                'knowledge_files': len(self.profile['knowledge_bases']),
            }

        # 3. Workflow patterns
        if self.profile['workflows']:
            value['workflow_patterns'] = [
                {'type': w['type'], 'step_count': len(w.get('steps', []))}
                for w in self.profile['workflows']
            ]

        # 4. Architecture patterns that others could adopt
        arch = self.profile['architecture'].get('patterns', [])
        if arch:
            value['architecture_patterns'] = arch

        # 5. Top domain keywords (for matching with similar skills)
        top_kw = [kw for kw, _ in self.profile['keywords'].most_common(20)]
        if top_kw:
            value['top_domain_keywords'] = top_kw

        self.profile['cross_skill_value'] = value

    # --------------------------------------------------------
    # Utility Methods
    # --------------------------------------------------------
    def _extract_triggers(self, desc_text):
        """Extract trigger words from SKILL.md description."""
        triggers = []
        # "触发词包括：X、Y、Z" pattern
        tm = re.search(r'触发词包括[：:]\s*(.+?)(?:[。.]|$)', desc_text)
        if tm:
            triggers = [t.strip() for t in re.split(r'[、,，;；]', tm.group(1)) if t.strip()]
        else:
            # Fallback: extract all Chinese and English words
            for zh in re.findall(r'[\u4e00-\u9fff]{2,6}', desc_text):
                triggers.append(zh)
        return triggers


# ============================================================
# Multi-Skill Scanner
# ============================================================

class MultiSkillScanner:
    """Scan all installed skills and build ecosystem profile."""

    def __init__(self, skills_root=None, verbose=False):
        self.skills_root = Path(skills_root) if skills_root else SKILLS_ROOT
        self.verbose = verbose
        self.profiles = {}
        self.ecosystem = {
            'scanned_at': datetime.now().isoformat(),
            'skills_root': str(self.skills_root),
            'skills': {},
            'ecosystem_insights': {},
        }

    def scan_all(self):
        """Scan all installed skills."""
        if not self.skills_root.exists():
            print(f"[ERROR] Skills root not found: {self.skills_root}")
            return

        skill_dirs = [
            d for d in sorted(self.skills_root.iterdir())
            if d.is_dir() and not d.name.startswith('.')
            and (d / "SKILL.md").exists()
        ]

        print(f"[INFO] Found {len(skill_dirs)} skills to scan")

        for i, skill_dir in enumerate(skill_dirs):
            if self.verbose:
                print(f"\n[{i+1}/{len(skill_dirs)}] {skill_dir.name}")

            # Timeout guard: single skill scan must not hang the whole process
            with TimeoutGuard(seconds=30, message=f"Scanning {skill_dir.name} stuck (>30s)"):
                scanner = SkillScanner(skill_dir, verbose=self.verbose)
                profile = scanner.scan()
                self.profiles[skill_dir.name] = profile

        # Build ecosystem insights
        self._build_ecosystem_insights()

        # Save
        self._save()

        # Report
        print(f"\n{'='*65}")
        print(f"  Local Skills Ecosystem Scan Complete")
        print(f"{'='*65}")
        print(f"  Skills scanned: {len(self.profiles)}")
        print(f"  Ecosystem insights generated")
        for name, p in self.profiles.items():
            arch = p.get('architecture', {})
            completeness = arch.get('completeness_pct', 0)
            algo_count = len(p.get('algorithms', []))
            kb_count = len(p.get('knowledge_bases', []))
            trigger_count = len(p.get('trigger_words', []))
            print(f"  {name:<30s} arch={completeness:.0f}%  "
                  f"algo={algo_count}  kb={kb_count}  triggers={trigger_count}")

        # Optimization suggestions for low-completeness skills
        missing_configs = self.ecosystem.get('ecosystem_insights', {}).get('missing_configs', {})
        if missing_configs:
            needs_upgrade = [n for n, missing in missing_configs.items()
                           if len(missing) >= 2]  # Only show skills missing 2+ configs
            if needs_upgrade:
                print(f"\n{'='*65}")
                print(f"  [OPTIMIZATION] {len(needs_upgrade)} skills need upgrade (missing 2+ configs)")
                print(f"{'='*65}")
                config_names = {
                    'integrity_guard': 'integrity_guard.py',
                    'self_grow': 'learn_sync.py',
                    'self_learning': 'learn_data.json'
                }
                for name in sorted(needs_upgrade):
                    missing = missing_configs[name]
                    missing_str = ', '.join(missing)
                    suggestions = [config_names.get(m, m) for m in missing]
                    print(f"  [{name}]")
                    print(f"    Missing: {missing_str}")
                    print(f"    Action: Add {', '.join(suggestions)} to achieve standard config")
                    print()

        return self.ecosystem

    def scan_single(self, skill_dir):
        """Scan a single skill directory."""
        from pathlib import Path
        skill_path = Path(skill_dir) if isinstance(skill_dir, str) else skill_dir
        scanner = SkillScanner(skill_path, verbose=self.verbose)
        profile = scanner.scan()
        self.profiles[skill_path.name] = profile
        return profile

    def get_status(self):
        """Show current scan status."""
        if not OUTPUT_FILE.exists():
            print("[INFO] No previous scan data. Run a scan first.")
            return

        data = safe_read_json(OUTPUT_FILE)
        if not data:
            print("[ERROR] Failed to load scan data")
            return

        skills = data.get('skills', {})
        scanned_at = data.get('scanned_at', 'unknown')
        insights = data.get('ecosystem_insights', {})

        print(f"[STATUS] Local Skills Profile")
        print(f"  Last scan: {scanned_at}")
        print(f"  Skills: {len(skills)}")
        for name, profile in skills.items():
            arch = profile.get('architecture', {})
            print(f"    {name:<30s}  arch={arch.get('completeness_pct', 0):.0f}%  "
                  f"version={profile.get('version', '?')}")
        if insights:
            print(f"  Common patterns: {insights.get('common_patterns', [])}")
            print(f"  Domain clusters: {list(insights.get('domain_clusters', {}).keys())}")

    def show_diff(self):
        """Show changes since last scan."""
        if not OUTPUT_FILE.exists():
            print("[INFO] No previous scan to diff against")
            return

        old_data = safe_read_json(OUTPUT_FILE)
        if not old_data:
            print("[ERROR] Failed to load previous scan data")
            return

        old_skills = set(old_data.get('skills', {}).keys())

        # Quick re-scan for comparison
        current_dirs = {
            d.name for d in self.skills_root.iterdir()
            if d.is_dir() and (d / "SKILL.md").exists()
        }

        new_skills = current_dirs - old_skills
        removed = old_skills - current_dirs

        if new_skills:
            print(f"[NEW] Skills added since last scan:")
            for s in sorted(new_skills):
                print(f"  + {s}")
        if removed:
            print(f"[REMOVED] Skills removed since last scan:")
            for s in sorted(removed):
                print(f"  - {s}")
        if not new_skills and not removed:
            print("[INFO] No skill additions/removals since last scan")

        # Check version changes
        for name in old_skills & current_dirs:
            old_ver = old_data['skills'].get(name, {}).get('version', '?')
            skill_md = self.skills_root / name / "SKILL.md"
            if skill_md.exists():
                content = safe_read_text(skill_md, timeout=3)
                ver = re.search(r'v(\d+\.\d+\.\d+)', content)
                new_ver = ver.group(1) if ver else '?'
                if old_ver != new_ver and old_ver != '?' and new_ver != '?':
                    print(f"  [UPDATED] {name}: {old_ver} -> {new_ver}")

    def _build_ecosystem_insights(self):
        """Build cross-skill ecosystem insights."""
        insights = {}

        # 1. Common architecture patterns
        pattern_counts = Counter()
        for profile in self.profiles.values():
            for p in profile.get('architecture', {}).get('patterns', []):
                pattern_counts[p] += 1
        insights['common_patterns'] = [
            {'pattern': p, 'count': c, 'pct': round(c / len(self.profiles) * 100, 1)}
            for p, c in pattern_counts.most_common(15)
        ]

        # 2. Domain clusters (group skills by shared keywords)
        domain_map = defaultdict(list)
        for name, profile in self.profiles.items():
            top_kw = [k['keyword'] for k in profile.get('keywords', [])[:10]]
            domain_map[name] = top_kw

        clusters = self._cluster_by_keywords(domain_map)
        insights['domain_clusters'] = clusters

        # 3. Reusable cross-skill algorithms
        all_reusable = {}
        for name, profile in self.profiles.items():
            for algo in profile.get('algorithms', []):
                algo_name = algo['name']
                if algo_name not in all_reusable:
                    all_reusable[algo_name] = []
                all_reusable[algo_name].append(name)
        # Algorithms used by 2+ skills
        shared_algos = {
            k: v for k, v in all_reusable.items() if len(v) >= 2
        }
        if shared_algos:
            insights['shared_algorithms'] = shared_algos

        # 4. Missing standard configurations
        missing_configs = {}
        required = ['integrity_guard', 'self_grow', 'self_learning']
        for name, profile in self.profiles.items():
            patterns = set(profile.get('architecture', {}).get('patterns', []))
            missing = [r for r in required if r not in patterns]
            if missing:
                missing_configs[name] = missing
        if missing_configs:
            insights['missing_configs'] = missing_configs

        # 5. Global keyword frequency across all skills
        global_kw = Counter()
        for profile in self.profiles.values():
            for kw_entry in profile.get('keywords', []):
                global_kw[kw_entry['keyword']] += kw_entry['score']
        insights['global_keyword_frequency'] = [
            {'keyword': kw, 'score': round(score, 2)}
            for kw, score in global_kw.most_common(100)
        ]

        self.ecosystem['ecosystem_insights'] = insights

    def _cluster_by_keywords(self, domain_map):
        """Simple keyword-overlap clustering."""
        clusters = {}
        names = list(domain_map.keys())
        assigned = set()

        for i, name_a in enumerate(names):
            if name_a in assigned:
                continue
            kw_a = set(domain_map[name_a])
            cluster_members = [name_a]

            for j, name_b in enumerate(names):
                if j <= i or name_b in assigned:
                    continue
                kw_b = set(domain_map[name_b])
                # Jaccard-like overlap
                overlap = len(kw_a & kw_b)
                if overlap >= 3:  # At least 3 shared keywords
                    cluster_members.append(name_b)
                    assigned.add(name_b)

            if len(cluster_members) > 1:
                # Use first skill's top keywords as cluster label
                label_keywords = domain_map[cluster_members[0]][:3]
                cluster_name = '/'.join(label_keywords)
                clusters[cluster_name] = cluster_members
                assigned.add(name_a)

        return clusters

    def _save(self):
        """Save ecosystem profile to disk."""
        self.ecosystem['skills'] = self.profiles
        OUTPUT_FILE.write_text(
            json.dumps(self.ecosystem, ensure_ascii=False, indent=1),
            encoding='utf-8'
        )
        if self.verbose:
            size_kb = OUTPUT_FILE.stat().st_size / 1024
            print(f"[OK] Saved to {OUTPUT_FILE} ({size_kb:.1f} KB)")


# ============================================================
# CLI Entry Point
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Local Skill Deep Scanner")
    parser.add_argument("--skill", metavar="DIR", help="Scan a single skill")
    parser.add_argument("--status", action="store_true", help="Show scan status")
    parser.add_argument("--diff", action="store_true", help="Show changes since last scan")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    # ---- 执行日志 start ----
    logger = ExecutionLogger("local_skill_scanner")
    run_mode = "status" if args.status else "diff" if args.diff else "single" if args.skill else "full"
    logger.start({"mode": run_mode, "skill": args.skill, "verbose": args.verbose})
    
    # ---- Token 日志 start ----
    start_time = datetime.now()
    try:
        from token_logger import TokenLogger
        token_logger = TokenLogger("skill-trend-analyzer")
    except ImportError:
        token_logger = None

    try:
        scanner = MultiSkillScanner(verbose=args.verbose)

        if args.status:
            scanner.get_status()
            logger.phase("status_check")
            logger.done({"status": "ok"})
        elif args.diff:
            scanner.show_diff()
            logger.phase("diff_check")
            logger.done({"status": "ok"})
        elif args.skill:
            logger.phase("single_scan")
            profile = scanner.scan_single(args.skill)
            logger.phase("saving")
            logger.done({
                "scanned_count": 1,
                "scan_mode": "single",
                "skill_name": args.skill,
            })
        else:
            logger.phase("full_scan")
            ecosystem = scanner.scan_all()
            logger.phase("saving")
            logger.done({
                "scanned_count": len(scanner.profiles),
                "scan_mode": "full",
                "skills_root": str(scanner.skills_root),
            })

    except Exception as e:
        logger.fail(str(e), {"scanned_count": 0})
        import traceback; traceback.print_exc()
    finally:
        # ---- Token 日志记录 ----
        if token_logger:
            duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            scanned_count = len(scanner.profiles) if hasattr(scanner, 'profiles') else (1 if args.skill else 0)
            # 估算 token 消耗（基于扫描的 skill 数量和文件数）
            estimated_tokens = scanned_count * 500 + 1000  # 简单估算
            token_logger.log(
                action=f"scan_{run_mode}",
                tokens={"input": estimated_tokens // 3, "output": estimated_tokens * 2 // 3, "total": estimated_tokens},
                duration_ms=duration_ms,
                metadata={"scanned_count": scanned_count, "mode": run_mode}
            )

    # Fixed ending - contact author info (ClawHub compliance)
    from safe_io import print_footer
    print_footer()


def _write_scan_log(args, scanner):
    """Write scan run to log file."""
    try:
        # Load existing log
        log = []
        if SCAN_LOG.exists():
            try:
                log = safe_read_json(SCAN_LOG) or []
            except:
                log = []
        
        # New entry
        entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "type": "scan",
            "mode": "status" if args.status else "diff" if args.diff else "single" if args.skill else "full",
            "skill": args.skill if args.skill else None,
            "scanner_count": len(scanner.profiles) if hasattr(scanner, 'profiles') else 0,
        }
        
        log.append(entry)
        # Keep last 100 entries
        if len(log) > 100:
            log = log[-100:]
        
        SCAN_LOG.write_text(json.dumps(log, ensure_ascii=False, indent=1), encoding='utf-8')
    except Exception as e:
        safe_print(f"[WARN] Failed to write scan log: {e}")


if __name__ == "__main__":
    main()
