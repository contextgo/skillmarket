#!/usr/bin/env python3
"""
待办事项Web应用生成器
生成包含完整CRUD功能的待办事项Web应用代码
"""

import argparse
import json
from datetime import datetime


def generate_html_app(title, primary_color, output_file):
    """
    生成完整的待办事项Web应用
    
    Args:
        title: 应用标题
        primary_color: 主色调（十六进制颜色值）
        output_file: 输出文件路径
    """
    
    html_content = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        
        .container {{
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }}
        
        .header {{
            background: {primary_color};
            color: white;
            padding: 30px;
            text-align: center;
        }}
        
        .header h1 {{
            font-size: 2rem;
            margin-bottom: 10px;
        }}
        
        .header p {{
            opacity: 0.9;
            font-size: 1rem;
        }}
        
        .stats {{
            display: flex;
            justify-content: space-around;
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }}
        
        .stat-item {{
            text-align: center;
        }}
        
        .stat-value {{
            font-size: 1.5rem;
            font-weight: bold;
            color: {primary_color};
        }}
        
        .stat-label {{
            font-size: 0.875rem;
            color: #6c757d;
            margin-top: 5px;
        }}
        
        .add-form {{
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }}
        
        .form-group {{
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }}
        
        .form-group:last-child {{
            margin-bottom: 0;
        }}
        
        .form-group input, .form-group select {{
            padding: 12px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            font-size: 1rem;
            flex: 1;
        }}
        
        .form-group input:focus, .form-group select:focus {{
            outline: none;
            border-color: {primary_color};
            box-shadow: 0 0 0 3px rgba({int(primary_color[1:3], 16)}, {int(primary_color[3:5], 16)}, {int(primary_color[5:7], 16)}, 0.1);
        }}
        
        .btn {{
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.2s;
            font-weight: 500;
        }}
        
        .btn-primary {{
            background: {primary_color};
            color: white;
            flex: 0 0 auto;
        }}
        
        .btn-primary:hover {{
            opacity: 0.9;
            transform: translateY(-1px);
        }}
        
        .btn-sm {{
            padding: 6px 12px;
            font-size: 0.875rem;
        }}
        
        .btn-danger {{
            background: #dc3545;
            color: white;
        }}
        
        .btn-success {{
            background: #28a745;
            color: white;
        }}
        
        .todo-list {{
            padding: 20px;
            max-height: 600px;
            overflow-y: auto;
        }}
        
        .todo-item {{
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 12px;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 12px;
        }}
        
        .todo-item:hover {{
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        
        .todo-item.completed {{
            opacity: 0.6;
            background: #f8f9fa;
        }}
        
        .todo-item.completed .todo-text {{
            text-decoration: line-through;
            color: #6c757d;
        }}
        
        .todo-checkbox {{
            width: 24px;
            height: 24px;
            cursor: pointer;
            flex-shrink: 0;
        }}
        
        .todo-content {{
            flex: 1;
        }}
        
        .todo-text {{
            font-size: 1rem;
            margin-bottom: 5px;
            word-break: break-word;
        }}
        
        .todo-meta {{
            font-size: 0.875rem;
            color: #6c757d;
            display: flex;
            gap: 15px;
            align-items: center;
        }}
        
        .priority-badge {{
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
        }}
        
        .priority-high {{
            background: #fee2e2;
            color: #dc2626;
        }}
        
        .priority-medium {{
            background: #fef3c7;
            color: #d97706;
        }}
        
        .priority-low {{
            background: #d1fae5;
            color: #059669;
        }}
        
        .todo-actions {{
            display: flex;
            gap: 5px;
            flex-shrink: 0;
        }}
        
        .empty-state {{
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }}
        
        .empty-state svg {{
            width: 80px;
            height: 80px;
            margin-bottom: 20px;
            opacity: 0.5;
        }}
        
        .filter-buttons {{
            display: flex;
            gap: 10px;
            padding: 15px 20px 0;
            margin-bottom: 15px;
        }}
        
        .filter-btn {{
            padding: 8px 16px;
            border: 2px solid #dee2e6;
            background: white;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.875rem;
            transition: all 0.2s;
        }}
        
        .filter-btn:hover {{
            border-color: {primary_color};
        }}
        
        .filter-btn.active {{
            background: {primary_color};
            color: white;
            border-color: {primary_color};
        }}
        
        @media (max-width: 600px) {{
            .form-group {{
                flex-direction: column;
            }}
            
            .todo-item {{
                flex-direction: column;
                align-items: flex-start;
            }}
            
            .todo-actions {{
                width: 100%;
                justify-content: flex-end;
            }}
            
            .stats {{
                flex-wrap: wrap;
                gap: 15px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{title}</h1>
            <p id="currentDate"></p>
        </div>
        
        <div class="stats">
            <div class="stat-item">
                <div class="stat-value" id="totalTasks">0</div>
                <div class="stat-label">全部任务</div>
            </div>
            <div class="stat-item">
                <div class="stat-value" id="completedTasks">0</div>
                <div class="stat-label">已完成</div>
            </div>
            <div class="stat-item">
                <div class="stat-value" id="pendingTasks">0</div>
                <div class="stat-label">待完成</div>
            </div>
        </div>
        
        <div class="add-form">
            <div class="form-group">
                <input type="text" id="taskInput" placeholder="添加新任务..." />
            </div>
            <div class="form-group">
                <select id="prioritySelect">
                    <option value="low">低优先级</option>
                    <option value="medium" selected>中优先级</option>
                    <option value="high">高优先级</option>
                </select>
                <input type="date" id="dueDateInput" />
                <button class="btn btn-primary" onclick="addTask()">添加任务</button>
            </div>
        </div>
        
        <div class="filter-buttons">
            <button class="filter-btn active" onclick="filterTasks('all')">全部</button>
            <button class="filter-btn" onclick="filterTasks('pending')">待完成</button>
            <button class="filter-btn" onclick="filterTasks('completed')">已完成</button>
        </div>
        
        <div class="todo-list" id="todoList">
            <!-- 待办事项将在这里动态生成 -->
        </div>
    </div>

    <script>
        // 数据存储
        let todos = JSON.parse(localStorage.getItem('todos')) || [];
        let currentFilter = 'all';

        // 初始化
        document.addEventListener('DOMContentLoaded', () => {{
            updateCurrentDate();
            renderTodos();
            updateStats();
        }});
        
        // 更新当前日期
        function updateCurrentDate() {{
            const now = new Date();
            const options = {{ year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' }};
            document.getElementById('currentDate').textContent = now.toLocaleDateString('zh-CN', options);
        }}

        // 添加任务
        function addTask() {{
            const taskInput = document.getElementById('taskInput');
            const prioritySelect = document.getElementById('prioritySelect');
            const dueDateInput = document.getElementById('dueDateInput');
            
            const text = taskInput.value.trim();
            if (!text) {{
                alert('请输入任务内容');
                return;
            }}
            
            const todo = {{
                id: Date.now(),
                text: text,
                completed: false,
                priority: prioritySelect.value,
                dueDate: dueDateInput.value || null,
                createdAt: new Date().toISOString()
            }};
            
            todos.unshift(todo);
            saveTodos();
            renderTodos();
            updateStats();
            
            // 清空输入框
            taskInput.value = '';
            dueDateInput.value = '';
        }}
        
        // 切换任务状态
        function toggleTodo(id) {{
            todos = todos.map(todo => 
                todo.id === id ? {{ ...todo, completed: !todo.completed }} : todo
            );
            saveTodos();
            renderTodos();
            updateStats();
        }}
        
        // 删除任务
        function deleteTodo(id) {{
            if (confirm('确定要删除这个任务吗？')) {{
                todos = todos.filter(todo => todo.id !== id);
                saveTodos();
                renderTodos();
                updateStats();
            }}
        }}
        
        // 编辑任务
        function editTodo(id) {{
            const todo = todos.find(t => t.id === id);
            if (!todo) return;
            
            const newText = prompt('编辑任务内容：', todo.text);
            if (newText && newText.trim()) {{
                todos = todos.map(t => 
                    t.id === id ? {{ ...t, text: newText.trim() }} : t
                );
                saveTodos();
                renderTodos();
            }}
        }}
        
        // 筛选任务
        function filterTasks(filter) {{
            currentFilter = filter;
            
            // 更新按钮状态
            document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            renderTodos();
        }}
        
        // 渲染任务列表
        function renderTodos() {{
            const todoList = document.getElementById('todoList');
            let filteredTodos = todos;
            
            // 应用筛选
            if (currentFilter === 'pending') {{
                filteredTodos = todos.filter(todo => !todo.completed);
            }} else if (currentFilter === 'completed') {{
                filteredTodos = todos.filter(todo => todo.completed);
            }}
            
            if (filteredTodos.length === 0) {{
                todoList.innerHTML = `
                    <div class="empty-state">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <path d="M8 12h8"></path>
                            <path d="M12 8v8"></path>
                        </svg>
                        <p>暂无任务，开始添加第一个任务吧！</p>
                    </div>
                `;
                return;
            }}
            
            todoList.innerHTML = filteredTodos.map(todo => `
                <div class="todo-item ${{todo.completed ? 'completed' : ''}}">
                    <input type="checkbox" 
                           class="todo-checkbox" 
                           ${{todo.completed ? 'checked' : ''}}
                           onchange="toggleTodo(${{todo.id}})" />
                    <div class="todo-content">
                        <div class="todo-text">${{escapeHtml(todo.text)}}</div>
                        <div class="todo-meta">
                            <span class="priority-badge priority-${{todo.priority}}">
                                ${{getPriorityText(todo.priority)}}
                            </span>
                            ${{todo.dueDate ? `<span>截止: ${{formatDate(todo.dueDate)}}</span>` : ''}}
                        </div>
                    </div>
                    <div class="todo-actions">
                        <button class="btn btn-sm btn-success" onclick="editTodo(${{todo.id}})">编辑</button>
                        <button class="btn btn-sm btn-danger" onclick="deleteTodo(${{todo.id}})">删除</button>
                    </div>
                </div>
            `).join('');
        }}
        
        // 更新统计
        function updateStats() {{
            const total = todos.length;
            const completed = todos.filter(todo => todo.completed).length;
            const pending = total - completed;
            
            document.getElementById('totalTasks').textContent = total;
            document.getElementById('completedTasks').textContent = completed;
            document.getElementById('pendingTasks').textContent = pending;
        }}
        
        // 保存到本地存储
        function saveTodos() {{
            localStorage.setItem('todos', JSON.stringify(todos));
        }}
        
        // 获取优先级文本
        function getPriorityText(priority) {{
            const texts = {{
                'high': '高',
                'medium': '中',
                'low': '低'
            }};
            return texts[priority] || priority;
        }}
        
        // 格式化日期
        function formatDate(dateString) {{
            const date = new Date(dateString);
            return date.toLocaleDateString('zh-CN', {{
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            }});
        }}
        
        // HTML转义
        function escapeHtml(text) {{
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }}
        
        // 回车添加任务
        document.getElementById('taskInput').addEventListener('keypress', function(e) {{
            if (e.key === 'Enter') {{
                addTask();
            }}
        }});
    </script>
</body>
</html>'''
    
    # 写入文件
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"✓ 待办事项应用已生成: {output_file}")
    print(f"  - 应用标题: {title}")
    print(f"  - 主色调: {primary_color}")
    print(f"  - 功能: 增删改查、优先级、截止日期、本地存储")
    print(f"\n使用方法: 直接在浏览器中打开 {output_file} 即可使用")


def main():
    parser = argparse.ArgumentParser(description='生成待办事项Web应用')
    parser.add_argument('--title', '-t', 
                       default='我的待办清单',
                       help='应用标题（默认：我的待办清单）')
    parser.add_argument('--color', '-c',
                       default='#3498db',
                       help='主色调，十六进制颜色值（默认：#3498db）')
    parser.add_argument('--output', '-o',
                       default='todo-app.html',
                       help='输出文件名（默认：todo-app.html）')
    
    args = parser.parse_args()
    
    # 验证颜色格式
    if not args.color.startswith('#') or len(args.color) != 7:
        print("错误: 颜色必须是7位十六进制格式，例如 #3498db")
        return
    
    generate_html_app(args.title, args.color, args.output)


if __name__ == '__main__':
    main()
