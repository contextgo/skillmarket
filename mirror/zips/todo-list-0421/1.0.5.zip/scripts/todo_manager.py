#!/usr/bin/env python3
"""
待办事项数据管理工具
提供命令行接口进行批量数据操作
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path


class TodoManager:
    """待办事项管理器"""
    
    def __init__(self, data_file='todos.json'):
        self.data_file = data_file
        self.todos = self.load_data()
    
    def load_data(self):
        """从文件加载数据"""
        if Path(self.data_file).exists():
            try:
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                print(f"错误: {self.data_file} 不是有效的JSON文件")
                sys.exit(1)
        return []
    
    def save_data(self):
        """保存数据到文件"""
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(self.todos, f, ensure_ascii=False, indent=2)
    
    def add(self, text, priority='medium', due_date=None):
        """添加任务"""
        todo = {
            'id': int(datetime.now().timestamp() * 1000),
            'text': text,
            'completed': False,
            'priority': priority,
            'dueDate': due_date,
            'createdAt': datetime.now().isoformat()
        }
        self.todos.append(todo)
        self.save_data()
        print(f"✓ 已添加任务: {text}")
    
    def list(self, filter_type='all'):
        """列出任务"""
        filtered_todos = self.todos
        
        if filter_type == 'pending':
            filtered_todos = [t for t in self.todos if not t['completed']]
        elif filter_type == 'completed':
            filtered_todos = [t for t in self.todos if t['completed']]
        
        if not filtered_todos:
            print("暂无任务")
            return
        
        print(f"\n任务列表 (共 {len(filtered_todos)} 项):\n")
        for i, todo in enumerate(filtered_todos, 1):
            status = "✓" if todo['completed'] else "○"
            priority_text = {'high': '高', 'medium': '中', 'low': '低'}.get(todo['priority'], '中')
            
            print(f"{i}. [{status}] {todo['text']}")
            print(f"   优先级: {priority_text}", end='')
            if todo.get('dueDate'):
                print(f" | 截止: {todo['dueDate']}", end='')
            print(f"\n")
    
    def complete(self, todo_id):
        """标记任务为完成"""
        for todo in self.todos:
            if todo['id'] == todo_id:
                todo['completed'] = True
                self.save_data()
                print(f"✓ 已完成任务: {todo['text']}")
                return
        print(f"错误: 未找到ID为 {todo_id} 的任务")
    
    def delete(self, todo_id):
        """删除任务"""
        for i, todo in enumerate(self.todos):
            if todo['id'] == todo_id:
                deleted_text = todo['text']
                self.todos.pop(i)
                self.save_data()
                print(f"✓ 已删除任务: {deleted_text}")
                return
        print(f"错误: 未找到ID为 {todo_id} 的任务")
    
    def stats(self):
        """显示统计信息"""
        total = len(self.todos)
        completed = sum(1 for t in self.todos if t['completed'])
        pending = total - completed
        
        priority_stats = {
            'high': sum(1 for t in self.todos if t['priority'] == 'high' and not t['completed']),
            'medium': sum(1 for t in self.todos if t['priority'] == 'medium' and not t['completed']),
            'low': sum(1 for t in self.todos if t['priority'] == 'low' and not t['completed'])
        }
        
        print("\n" + "="*50)
        print("待办事项统计报告")
        print("="*50)
        print(f"总任务数: {total}")
        print(f"已完成: {completed}")
        print(f"待完成: {pending}")
        print(f"完成率: {completed/total*100:.1f}%" if total > 0 else "完成率: 0%")
        print("\n待完成任务按优先级:")
        print(f"  高优先级: {priority_stats['high']}")
        print(f"  中优先级: {priority_stats['medium']}")
        print(f"  低优先级: {priority_stats['low']}")
        print("="*50)
    
    def export(self, output_file):
        """导出数据"""
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(self.todos, f, ensure_ascii=False, indent=2)
        print(f"✓ 已导出 {len(self.todos)} 个任务到 {output_file}")
    
    def import_data(self, input_file):
        """导入数据"""
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                imported_todos = json.load(f)
            
            if not isinstance(imported_todos, list):
                print("错误: 导入文件必须包含任务数组")
                return
            
            # 合并数据
            existing_ids = {t['id'] for t in self.todos}
            new_count = 0
            for todo in imported_todos:
                if todo.get('id') not in existing_ids:
                    self.todos.append(todo)
                    new_count += 1
            
            self.save_data()
            print(f"✓ 已导入 {new_count} 个新任务")
            
        except FileNotFoundError:
            print(f"错误: 文件 {input_file} 不存在")
        except json.JSONDecodeError:
            print(f"错误: {input_file} 不是有效的JSON文件")


def main():
    parser = argparse.ArgumentParser(description='待办事项数据管理工具')
    parser.add_argument('--file', '-f', 
                       default='todos.json',
                       help='数据文件路径（默认：todos.json）')
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # 添加任务命令
    add_parser = subparsers.add_parser('add', help='添加任务')
    add_parser.add_argument('text', help='任务内容')
    add_parser.add_argument('--priority', '-p',
                           choices=['low', 'medium', 'high'],
                           default='medium',
                           help='优先级（默认：medium）')
    add_parser.add_argument('--due-date', '-d',
                           help='截止日期（格式：YYYY-MM-DD）')
    
    # 列出任务命令
    list_parser = subparsers.add_parser('list', help='列出任务')
    list_parser.add_argument('--filter',
                           choices=['all', 'pending', 'completed'],
                           default='all',
                           help='筛选条件（默认：all）')
    
    # 完成任务命令
    complete_parser = subparsers.add_parser('complete', help='标记任务为完成')
    complete_parser.add_argument('id', type=int, help='任务ID')
    
    # 删除任务命令
    delete_parser = subparsers.add_parser('delete', help='删除任务')
    delete_parser.add_argument('id', type=int, help='任务ID')
    
    # 统计命令
    subparsers.add_parser('stats', help='显示统计信息')
    
    # 导出命令
    export_parser = subparsers.add_parser('export', help='导出数据')
    export_parser.add_argument('output', help='输出文件路径')
    
    # 导入命令
    import_parser = subparsers.add_parser('import', help='导入数据')
    import_parser.add_argument('input', help='输入文件路径')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    manager = TodoManager(args.file)
    
    if args.command == 'add':
        manager.add(args.text, args.priority, args.due_date)
    elif args.command == 'list':
        manager.list(args.filter)
    elif args.command == 'complete':
        manager.complete(args.id)
    elif args.command == 'delete':
        manager.delete(args.id)
    elif args.command == 'stats':
        manager.stats()
    elif args.command == 'export':
        manager.export(args.output)
    elif args.command == 'import':
        manager.import_data(args.input)


if __name__ == '__main__':
    main()
