# 待办事项功能扩展指南

## 目录
1. [高级功能](#高级功能)
2. [界面定制](#界面定制)
3. [数据同步](#数据同步)
4. [集成方案](#集成方案)
5. [最佳实践](#最佳实践)

## 高级功能

### 1. 任务分类（标签）

**实现方式**: 在任务对象中添加 `tags` 数组字段

```javascript
// 数据结构扩展
{
  id: 1234567890,
  text: "完成项目文档",
  completed: false,
  priority: "high",
  tags: ["工作", "文档", "紧急"],
  dueDate: "2024-01-20",
  createdAt: "2024-01-15T00:00:00.000Z"
}
```

**UI实现**:
```javascript
// 添加标签输入框
<div class="form-group">
  <input type="text" id="tagsInput" placeholder="标签（逗号分隔）" />
</div>

// 渲染标签
<span class="todo-tags">
  ${todo.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
</span>

// CSS样式
.tag {
  background: #e3f2fd;
  color: #1976d2;
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 0.75rem;
  margin: 2px;
}
```

### 2. 任务子任务

**实现方式**: 添加 `subtasks` 数组字段

```javascript
{
  id: 1234567890,
  text: "完成项目开发",
  subtasks: [
    { id: 1, text: "设计数据库", completed: true },
    { id: 2, text: "编写API", completed: false },
    { id: 3, text: "前端开发", completed: false }
  ]
}
```

**功能实现**:
```javascript
// 添加子任务
function addSubtask(parentId, text) {
  const parent = todos.find(t => t.id === parentId);
  if (parent) {
    if (!parent.subtasks) parent.subtasks = [];
    parent.subtasks.push({
      id: Date.now(),
      text: text,
      completed: false
    });
    saveTodos();
    renderTodos();
  }
}

// 切换子任务状态
function toggleSubtask(parentId, subtaskId) {
  const parent = todos.find(t => t.id === parentId);
  if (parent && parent.subtasks) {
    const subtask = parent.subtasks.find(st => st.id === subtaskId);
    if (subtask) {
      subtask.completed = !subtask.completed;
      
      // 检查是否所有子任务都完成
      parent.completed = parent.subtasks.every(st => st.completed);
      
      saveTodos();
      renderTodos();
    }
  }
}
```

### 3. 任务搜索

**实现方式**: 添加搜索框和过滤逻辑

```html
<!-- 添加搜索框 -->
<div class="search-box">
  <input type="text" id="searchInput" placeholder="搜索任务..." oninput="searchTasks()" />
</div>
```

```javascript
// 搜索功能
function searchTasks() {
  const searchText = document.getElementById('searchInput').value.toLowerCase();
  const filtered = todos.filter(todo => 
    todo.text.toLowerCase().includes(searchText)
  );
  renderFilteredTodos(filtered);
}

// 标签筛选
function filterByTag(tag) {
  const filtered = todos.filter(todo => 
    todo.tags && todo.tags.includes(tag)
  );
  renderFilteredTodos(filtered);
}
```

### 4. 任务提醒

**实现方式**: 使用浏览器通知API

```javascript
// 请求通知权限
function requestNotificationPermission() {
  if ('Notification' in window) {
    Notification.requestPermission().then(permission => {
      if (permission === 'granted') {
        console.log('通知权限已获取');
      }
    });
  }
}

// 检查并显示提醒
function checkReminders() {
  todos.forEach(todo => {
    if (todo.dueDate && !todo.completed) {
      const dueDate = new Date(todo.dueDate);
      const now = new Date();
      const diffDays = Math.ceil((dueDate - now) / (1000 * 60 * 60 * 24));
      
      if (diffDays <= 1) {
        showNotification(todo.text, `任务将在${diffDays}天后到期`);
      }
    }
  });
}

// 显示通知
function showNotification(title, body) {
  if (Notification.permission === 'granted') {
    new Notification(title, { body: body });
  }
}

// 定时检查提醒
setInterval(checkReminders, 60000); // 每分钟检查一次
```

### 5. 任务统计图表

**实现方式**: 使用Chart.js或纯CSS实现

```javascript
// 统计数据
function getStatsData() {
  const stats = {
    total: todos.length,
    completed: todos.filter(t => t.completed).length,
    pending: todos.filter(t => !t.completed).length,
    byPriority: {
      high: todos.filter(t => t.priority === 'high').length,
      medium: todos.filter(t => t.priority === 'medium').length,
      low: todos.filter(t => t.priority === 'low').length
    }
  };
  return stats;
}

// 渲染统计图表（纯CSS实现）
function renderStatsChart() {
  const stats = getStatsData();
  const container = document.createElement('div');
  container.className = 'stats-chart';
  
  const total = stats.total || 1;
  const completedPercent = (stats.completed / total) * 100;
  const pendingPercent = (stats.pending / total) * 100;
  
  container.innerHTML = `
    <div class="chart-bar">
      <div class="bar-segment completed" style="width: ${completedPercent}%"></div>
      <div class="bar-segment pending" style="width: ${pendingPercent}%"></div>
    </div>
    <div class="chart-legend">
      <span class="legend-item completed">已完成 ${stats.completed}</span>
      <span class="legend-item pending">待完成 ${stats.pending}</span>
    </div>
  `;
  
  return container;
}
```

```css
/* 图表样式 */
.stats-chart {
  margin: 20px 0;
}

.chart-bar {
  height: 30px;
  background: #f0f0f0;
  border-radius: 15px;
  overflow: hidden;
  display: flex;
}

.bar-segment {
  height: 100%;
  transition: width 0.3s ease;
}

.bar-segment.completed {
  background: #28a745;
}

.bar-segment.pending {
  background: #ffc107;
}

.chart-legend {
  margin-top: 10px;
  display: flex;
  gap: 20px;
  justify-content: center;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 0.875rem;
}

.legend-item.completed::before {
  content: '';
  display: inline-block;
  width: 12px;
  height: 12px;
  background: #28a745;
  border-radius: 2px;
}

.legend-item.pending::before {
  content: '';
  display: inline-block;
  width: 12px;
  height: 12px;
  background: #ffc107;
  border-radius: 2px;
}
```

## 界面定制

### 1. 主题切换

**实现方式**: CSS变量 + 主题切换按钮

```css
/* 定义CSS变量 */
:root {
  --primary-color: #3498db;
  --background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  --text-color: #333;
}

[data-theme="dark"] {
  --primary-color: #9b59b6;
  --background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
  --text-color: #fff;
}
```

```javascript
// 切换主题
function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-theme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
}

// 初始化主题
document.addEventListener('DOMContentLoaded', () => {
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
});
```

### 2. 自定义字体

```css
/* 导入Google Fonts */
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;500;700&display=swap');

body {
  font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
```

### 3. 动画效果

```css
/* 任务添加动画 */
@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.todo-item {
  animation: slideIn 0.3s ease;
}

/* 完成动画 */
@keyframes complete {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.02);
  }
  100% {
    transform: scale(1);
  }
}

.todo-item.completed {
  animation: complete 0.3s ease;
}
```

## 数据同步

### 1. 云存储集成

**实现方式**: 将数据同步到云存储服务

```javascript
// 导出到云存储
async function exportToCloud() {
  const data = JSON.stringify(todos);
  // 使用用户选择的云存储API
  // 例如：Dropbox、Google Drive、OneDrive等
}

// 从云存储导入
async function importFromCloud() {
  // 从云存储获取数据
  // const data = await fetchFromCloud();
  // todos = JSON.parse(data);
  // saveTodos();
  // renderTodos();
}
```

### 2. 多设备同步

**实现方式**: 使用后端服务存储数据

```javascript
// 同步到服务器
async function syncToServer() {
  const response = await fetch('/api/todos/sync', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ todos })
  });
  
  if (response.ok) {
    console.log('同步成功');
  }
}

// 从服务器获取
async function syncFromServer() {
  const response = await fetch('/api/todos');
  const data = await response.json();
  todos = data.todos;
  saveTodos();
  renderTodos();
}
```

## 集成方案

### 1. 与日历应用集成

```javascript
// 导出为iCal格式
function exportToICal() {
  let iCalContent = 'BEGIN:VCALENDAR\\nVERSION:2.0\\n';
  
  todos.forEach(todo => {
    if (todo.dueDate) {
      iCalContent += `BEGIN:VEVENT\\n`;
      iCalContent += `SUMMARY:${todo.text}\\n`;
      iCalContent += `DTSTART:${formatDateForICal(todo.dueDate)}\\n`;
      iCalContent += `END:VEVENT\\n`;
    }
  });
  
  iCalContent += 'END:VCALENDAR';
  
  // 下载文件
  downloadFile('tasks.ics', iCalContent);
}
```

### 2. 与GitHub Issues集成

```javascript
// 同步到GitHub Issues
async function syncToGitHubIssues(owner, repo, token) {
  for (const todo of todos.filter(t => !t.completed)) {
    const response = await fetch(`https://api.github.com/repos/${owner}/${repo}/issues`, {
      method: 'POST',
      headers: {
        'Authorization': `token ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        title: todo.text,
        labels: [todo.priority]
      })
    });
    
    if (response.ok) {
      console.log(`已创建Issue: ${todo.text}`);
    }
  }
}
```

## 最佳实践

### 1. 数据备份策略

- 定期导出数据到JSON文件
- 使用LocalStorage时，注意数据大小限制（通常5-10MB）
- 考虑实现自动备份功能

```javascript
// 自动备份（每天一次）
function autoBackup() {
  const lastBackup = localStorage.getItem('lastBackup');
  const now = Date.now();
  const oneDay = 24 * 60 * 60 * 1000;
  
  if (!lastBackup || now - lastBackup > oneDay) {
    const backup = {
      todos: todos,
      backupDate: new Date().toISOString()
    };
    localStorage.setItem('backup', JSON.stringify(backup));
    localStorage.setItem('lastBackup', now.toString());
  }
}
```

### 2. 性能优化

- 使用虚拟滚动处理大量任务（1000+）
- 懒加载历史任务
- 使用防抖处理搜索输入

```javascript
// 防抖函数
function debounce(func, wait) {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

// 使用防抖
document.getElementById('searchInput').addEventListener(
  'input',
  debounce(searchTasks, 300)
);
```

### 3. 用户体验优化

- 添加快捷键支持
- 实现拖拽排序
- 提供撤销/重做功能

```javascript
// 快捷键支持
document.addEventListener('keydown', (e) => {
  // Ctrl/Cmd + Enter: 添加任务
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    addTask();
  }
  
  // Esc: 取消编辑
  if (e.key === 'Escape') {
    cancelEdit();
  }
  
  // Delete: 删除选中的任务
  if (e.key === 'Delete' && selectedTaskId) {
    deleteTodo(selectedTaskId);
  }
});
```

### 4. 安全性考虑

- XSS防护：使用textContent而非innerHTML
- 数据验证：输入数据前进行验证
- 敏感信息处理：不在LocalStorage中存储密码等敏感信息

```javascript
// 安全的HTML转义
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// 使用示例
todoList.innerHTML += `
  <div class="todo-text">${escapeHtml(todo.text)}</div>
`;
```

## 扩展检查清单

在扩展功能时，请确保：

- [ ] 保持数据格式向后兼容
- [ ] 更新 `data_format.md` 文档
- [ ] 测试所有边界情况
- [ ] 优化性能（特别是大量数据时）
- [ ] 添加适当的错误处理
- [ ] 保持响应式设计
- [ ] 考虑可访问性（ARIA标签等）
- [ ] 编写清晰的注释
