# 待办事项数据格式

## 目录
1. [数据结构](#数据结构)
2. [字段说明](#字段说明)
3. [完整示例](#完整示例)
4. [验证规则](#验证规则)
5. [批量导入示例](#批量导入示例)

## 数据结构

待办事项数据采用JSON数组格式，每个任务对象包含以下字段：

```json
[
  {
    "id": 数字,
    "text": "任务内容字符串",
    "completed": 布尔值,
    "priority": "优先级字符串",
    "dueDate": "日期字符串或null",
    "createdAt": "ISO8601时间字符串"
  }
]
```

## 字段说明

### id（必需）
- **类型**: 数字（整数）
- **说明**: 任务的唯一标识符
- **建议**: 使用时间戳或自增ID
- **示例**: `1234567890123`

### text（必需）
- **类型**: 字符串
- **说明**: 任务的具体描述内容
- **约束**: 不能为空字符串
- **示例**: `"完成项目报告"`

### completed（必需）
- **类型**: 布尔值
- **说明**: 标记任务是否已完成
- **取值**: `true`（已完成）或 `false`（未完成）
- **示例**: `false`

### priority（必需）
- **类型**: 字符串
- **说明**: 任务优先级
- **取值**:
  - `"high"` - 高优先级
  - `"medium"` - 中优先级（默认）
  - `"low"` - 低优先级
- **示例**: `"medium"`

### dueDate（可选）
- **类型**: 字符串或 `null`
- **说明**: 任务截止日期
- **格式**: `YYYY-MM-DD`（ISO 8601日期格式）
- **示例**: `"2024-12-31"` 或 `null`

### createdAt（可选）
- **类型**: 字符串（ISO 8601时间格式）
- **说明**: 任务创建时间
- **格式**: `YYYY-MM-DDTHH:MM:SS.sssZ`
- **示例**: `"2024-01-15T10:30:00.000Z"`

## 完整示例

### 示例1：基础任务列表

```json
[
  {
    "id": 1705294200000,
    "text": "完成项目需求文档",
    "completed": false,
    "priority": "high",
    "dueDate": "2024-01-20",
    "createdAt": "2024-01-15T08:00:00.000Z"
  },
  {
    "id": 1705294260000,
    "text": "团队周会",
    "completed": true,
    "priority": "medium",
    "dueDate": "2024-01-17",
    "createdAt": "2024-01-15T08:01:00.000Z"
  },
  {
    "id": 1705294320000,
    "text": "学习新技术框架",
    "completed": false,
    "priority": "low",
    "dueDate": null,
    "createdAt": "2024-01-15T08:02:00.000Z"
  }
]
```

### 示例2：简化的任务列表（用于导入）

```json
[
  {
    "id": 1,
    "text": "购买生活用品",
    "completed": false,
    "priority": "medium",
    "dueDate": null,
    "createdAt": "2024-01-15T00:00:00.000Z"
  },
  {
    "id": 2,
    "text": "回复客户邮件",
    "completed": false,
    "priority": "high",
    "dueDate": "2024-01-16",
    "createdAt": "2024-01-15T00:00:00.000Z"
  }
]
```

## 验证规则

在使用 `todo_manager.py` 导入数据时，系统会自动进行以下验证：

### 必填字段检查
- `id` 必须存在且为数字
- `text` 必须存在且为非空字符串
- `completed` 必须存在且为布尔值
- `priority` 必须存在且为有效值（high/medium/low）

### 字段类型检查
- `id`: 必须是整数或可以转换为整数的数字
- `text`: 必须是字符串
- `completed`: 必须是布尔值
- `priority`: 必须是字符串，且为 high/medium/low 之一
- `dueDate`: 如果存在，必须是有效的日期格式（YYYY-MM-DD）或 null
- `createdAt`: 如果存在，必须是有效的ISO 8601时间格式

### 数据完整性
- JSON文件必须是有效的数组格式
- 数组中的每个元素必须是对象

## 批量导入示例

### 步骤1: 创建符合格式的JSON文件

创建一个名为 `tasks_to_import.json` 的文件：

```json
[
  {
    "id": 1001,
    "text": "准备季度报告PPT",
    "completed": false,
    "priority": "high",
    "dueDate": "2024-01-25",
    "createdAt": "2024-01-20T09:00:00.000Z"
  },
  {
    "id": 1002,
    "text": "更新个人简历",
    "completed": false,
    "priority": "medium",
    "dueDate": "2024-02-01",
    "createdAt": "2024-01-20T09:05:00.000Z"
  },
  {
    "id": 1003,
    "text": "整理桌面文件",
    "completed": false,
    "priority": "low",
    "dueDate": null,
    "createdAt": "2024-01-20T09:10:00.000Z"
  }
]
```

### 步骤2: 使用todo_manager.py导入

```bash
python scripts/todo_manager.py import tasks_to_import.json
```

### 步骤3: 验证导入结果

```bash
# 查看所有任务
python scripts/todo_manager.py list

# 查看统计信息
python scripts/todo_manager.py stats
```

## 注意事项

1. **ID唯一性**: 导入时，如果任务的ID已存在，该任务将被跳过
2. **日期格式**: `dueDate` 必须使用 `YYYY-MM-DD` 格式，例如 `2024-12-31`
3. **字符编码**: JSON文件应使用UTF-8编码保存
4. **文件扩展名**: 建议使用 `.json` 作为文件扩展名
5. **时间格式**: `createdAt` 使用ISO 8601标准格式，包含时区信息
