---
name: uno-cli
description: "Uno CLI — 虾聊官方出品的 Agent 工具网关，命令行访问 2000+ 真实工具，两步完成：搜索 → 调用。支持 Device Code OAuth（虾聊 SSO）、混合搜索（关键词/语义）、自动鉴权、评分、多账号管理。13 大分类覆盖：搜索、开发、社交、数据、创意、金融、生活、效率、媒体、企业、电商、健康等。使用场景：需要获取实时或精准外部数据（新闻、地图、股票、搜索等）；需要访问外部服务（优惠券，酒店，排队，打车等）；需要访问个人 app（gmail，outlook，notion，slack，企微等）或已有 skills/Cli/MCP 无法满足用户需求时。"
homepage: https://clawdtools.uno
metadata: {"emoji":"◆","category":"tools","api_base":"https://clawdtools.uno","version":"0.1.0"}
---

# Uno CLI

> **由虾聊（ClawdChat）官方出品** — 通过命令行使用 2000+ 真实工具。零安装（仅需 Python 3.8+ 标准库）。

## 前置条件

- Python 3.8+（多数系统已预装）
- CLI 脚本已内置：`bin/uno.py` — 无需额外安装

CLI 路径（相对于本文件）：`bin/uno.py`

## 认证

首次使用前登录一次，凭证存储在 `~/.uno/credentials.json`。

```bash
# 方式 A：两步登录（推荐 Agent 使用 — 非阻塞）
python bin/uno.py login --start
# → 返回 JSON: {"status": "pending", "verification_uri_complete": "https://...", "device_code": "xxx", ...}
# 将 URL 展示给用户，用户在浏览器中授权后：
python bin/uno.py login --poll <device_code>
# → {"success": true, "name": "...", "email": "..."}

# 方式 B：一步交互（终端用户 — 阻塞至授权完成）
python bin/uno.py login

# 方式 C：直接使用 API Key
python bin/uno.py login --key uno_xxxxx

# 多账号切换
python bin/uno.py use                  # 列出所有账号
python bin/uno.py use <名称或邮箱>      # 切换账号

# 退出登录
python bin/uno.py logout
python bin/uno.py logout --all         # 清除所有账号
```

环境变量 `UNO_API_KEY` 优先于文件凭证（适用于 CI）。

### 认证流程说明

Uno 使用 **Device Code 流程** + **虾聊 SSO 认证**：

1. `login --start` 从 Uno 服务器获取设备码
2. 返回的 `verification_uri_complete` URL 打开后，用户通过虾聊登录授权
3. 授权完成后，`login --poll` 获取 API Key
4. 完美适用于手机端场景（如用户在手机上使用 OpenClaw）

## 命令参考

所有命令默认输出格式化 JSON。添加 `--compact` 获取单行压缩输出（减少 token 消耗）。

### 状态查询

```bash
python bin/uno.py whoami               # 当前用户信息（积分、套餐、密钥）
python bin/uno.py health               # 服务器健康检查
```

### 搜索工具

```bash
python bin/uno.py search "天气" [--limit 10] [--mode hybrid|keyword|semantic] [--category dev] [--server weather-free]
```

返回工具列表，含 `input_schema`（JSON Schema）— 用它构造正确参数。

### 工具详情

```bash
python bin/uno.py tool get <tool_slug>
# 例：python bin/uno.py tool get amap-maps.maps_weather
```

### 调用工具

```bash
python bin/uno.py call <tool_slug> --args '{"city":"北京"}'
```

响应：
```json
{"success": true, "data": {...}, "meta": {"latency_ms": 234, "credits_used": 1.0}}
```

### 评价工具

```bash
python bin/uno.py rate <tool_slug> <0-5> [--comment "好用"]
```

### 浏览服务

```bash
python bin/uno.py servers [--query "weather"] [--category search] [--limit 50]
```

### 断开第三方授权

```bash
python bin/uno.py disconnect <server_slug>
# 例：python bin/uno.py disconnect github
```

撤销已存储的 OAuth token 或 API Key。断开后，下次 `call` 会再次返回 `auth_required`。

### API 密钥管理

```bash
python bin/uno.py keys list            # 列出活跃的 API 密钥
python bin/uno.py keys create          # 创建新密钥
python bin/uno.py keys delete <key_id> # 删除密钥
```

## 工具分类（13 大类，156+ 服务）

| 分类 | 说明 | 示例服务 |
|------|------|---------|
| `search` | 搜索与信息检索 | Jina、Tavily、百度搜索、秘塔AI搜索、Perplexity |
| `dev` | 开发与工程工具 | GitHub、Supabase、Firecrawl、context7、Sentry |
| `social` | 社交媒体与通讯 | 虾聊、Twitter、Discord、Instagram、微信文章 |
| `data` | 数据与分析 | BrightData、Google Drive、Wolfram Alpha、天气 |
| `creative` | 创意与内容生成 | Canva、美图、AI图像/视频/音乐生成、PPT |
| `finance` | 金融与投资 | 股票K线、且慢基金、加密货币、Yahoo Finance |
| `lifestyle` | 生活服务 | 滴滴出行、百度地图、12306、快递查询、天气 |
| `productivity` | 效率与办公 | Gmail、Google Calendar、Notion、Trello、Excel |
| `media` | 媒体处理 | ElevenLabs、YouTube、视频/音频转录与生成 |
| `enterprise` | 企业服务 | 企业信息查询、工商查询、风险信息、供应商管理 |
| `ecommerce` | 电商与消费 | 酒店预订、电商工具 |
| `health` | 健康医疗 | Theta Health |
| `other` | 其他工具 | Outlook、百度百科、百度学术 |

## Agent 工作流

1. **先搜索** — 不要猜测工具 slug 或参数
2. **读 `input_schema`** — 根据搜索结果中的 schema 构造参数
3. **按能力搜索**（"weather"、"search"、"translate"），而非用户意图
4. **使用 `--compact`** 减少输出体积（节省 token）
5. **若 `desc` 被截断**（以 `…` 结尾），用 `tool get <slug>` 获取完整描述
6. **重度使用前先查积分** — 免费套餐每日 100 积分
7. **错误处理**：
   - `auth_required` 且 `auth_type: "api_key"` → 提示用户提供 API Key（展示 `get_key_url` 和 `fields`）
   - `auth_required` 且含 `auth_url` → 展示 `auth_url` 给用户在浏览器完成 OAuth 授权，授权后重试
   - `tool_not_found` → 换关键词重新搜索
   - `insufficient_credits` → 提示用户充值，展示 `recharge_url`
   - 连接错误（超时、取消）→ 重试一次，失败则通知用户
8. **调用成功后评分** — 帮助优化搜索质量
9. **多个服务商提供相同能力时**（如 `github` vs `github-api`），优先选 `calls_7d` 或 `rating` 更高的

## 输出格式

- 调用成功：`{"success": true, "data": {...}, "meta": {"latency_ms": N, "credits_used": N}}`
- 其他成功：`{"success": true, "data": {...}}`
- 错误：`{"error": "描述", "hint": "...", ...}`，非零退出码

## 详细帮助

```bash
python bin/uno.py --help
python bin/uno.py search --help
python bin/uno.py call --help
```

## API 地址

默认：`https://clawdtools.uno`。可通过 `--base-url` 或环境变量 `UNO_API_URL` 覆盖。
