---
name: travel-butler
description: 旅行智能管家 - 全面的旅行规划和助手技能。提供行程规划、景点推荐、预算计算、攻略生成、天气查询、货币转换等功能，帮助用户轻松规划和执行旅行。
---

# Travel Butler - 旅行智能管家

## 概述

Travel Butler 是一款全面的旅行规划和助手技能，帮助用户从规划到执行完整管理旅行体验。支持多种语言，提供智能行程规划、景点推荐、预算管理、天气查询、文化指南等核心功能。

## 核心功能

### 📋 行程规划 (itinerary_planner.py)
- 根据目的地和时间生成详细行程
- 支持多种旅行节奏（轻松/适中/紧凑）
- 自动安排每日活动、餐厅、交通
- 生成可导出的行程文档

### 🗺️ 景点推荐 (attraction_recommender.py)
- 基于兴趣的个性化推荐
- 按类别分组（地标、博物馆、自然等）
- 评分和评论数据
- "必看"和"隐藏宝藏"分类

### 💰 预算计算 (budget_calculator.py)
- 多种预算模板（经济/中档/豪华）
- 按类别分解预算
- 费用追踪和对比
- 货币转换支持

### 📖 攻略生成 (guide_generator.py)
- 目的地综合指南
- 交通、餐饮、文化、安全信息
- 当地小贴士和注意事项
- 分活动类型的打包建议

### 🌤️ 天气查询 (weather_checker.py)
- 未来14天天气预报
- 基于气候的服装建议
- 打包推荐
- 活动适宜性评估

### 💱 货币转换 (currency_converter.py)
- 支持30+种主要货币
- 实时汇率转换
- 旅行费用估算
- 当地物价基准

### 🎒 打包清单 (packing_list.py)
- 基于目的地和活动的清单
- 气候适应性建议
- 分类整理（文件、电子产品、衣物等）
- 必选项/可选项区分

### 🗄️ 数据管理 (travel_db.py)
- 用户偏好存储
- 旅行历史记录
- 预算和支出追踪
- 旅行统计

## 使用方式

### 1. 初始化用户偏好
```bash
python3 scripts/travel_db.py is_initialized
```

### 2. 创建行程
```bash
python3 scripts/itinerary_planner.py \
  --destination "Tokyo" \
  --country "Japan" \
  --start 2024-06-01 \
  --end 2024-06-07 \
  --interests sightseeing food culture \
  --pace moderate \
  --output itinerary.md
```

### 3. 获取景点推荐
```bash
python3 scripts/attraction_recommender.py \
  --destination "Tokyo" \
  --country "Japan" \
  --interests sightseeing food \
  --num 10
```

### 4. 计算预算
```bash
python3 scripts/budget_calculator.py \
  --budget 2500 \
  --days 7 \
  --style mid-range \
  --travelers 2 \
  --currency USD
```

### 5. 生成完整攻略
```bash
python3 scripts/guide_generator.py \
  --destination "Tokyo" \
  --country "Japan" \
  --days 7 \
  --interests sightseeing food culture \
  --output guide.md
```

### 6. 查看天气
```bash
python3 scripts/weather_checker.py \
  --destination "Tokyo" \
  --country "Japan" \
  --start 2024-06-01 \
  --end 2024-06-07
```

### 7. 货币转换
```bash
python3 scripts/currency_converter.py \
  --amount 100 \
  --from USD \
  --to JPY
```

### 8. 生成打包清单
```bash
python3 scripts/packing_list.py \
  --destination "Tokyo" \
  --country "Japan" \
  --days 7 \
  --activities sightseeing food \
  --climate temperate
```

## 工作流程

### 完整旅行规划流程

```
1. 收集信息
   ├── 确定目的地和日期
   ├── 了解用户偏好和预算
   └── 确认旅行兴趣和活动

2. 生成计划
   ├── 创建详细行程
   ├── 推荐景点和餐厅
   └── 计算预算分解

3. 旅行准备
   ├── 生成打包清单
   ├── 提供天气和穿着建议
   └── 生成文化指南

4. 行程执行（可选）
   ├── 追踪实际支出
   ├── 提供每日提醒
   └── 解答实时问题

5. 行程回顾
   ├── 记录旅行数据
   └── 更新偏好和历史
```

## 数据存储

- **位置**: `~/.travel_butler/`
- **文件**:
  - `preferences.json` - 用户偏好
  - `trips.json` - 旅行记录
  - `bucket_list.json` - 愿望清单

## 模板文件

- `templates/itinerary_template.md` - 行程模板
- `templates/packing_template.md` - 打包清单模板
- `templates/budget_template.md` - 预算模板

## 数据文件

- `data/destinations.json` - 目的地数据库
- `data/travel_tips.json` - 旅行小贴士
- `data/common_phrases.json` - 常用语言短语

## 最佳实践

1. **提前规划**: 建议提前2-3个月开始规划国际旅行
2. **预订热门景点**: 热门景点提前预订
3. **预算缓冲**: 预留10-20%的额外预算
4. **文化尊重**: 提前了解当地文化习俗
5. **保持灵活**: 计划要有调整空间
6. **记录支出**: 每日追踪便于预算控制

## 示例对话

```
用户: 我想计划一次7天的东京之旅，6月出发，预算5000美元

助手: 好的！让我为您规划一次精彩的东京之旅。

首先，我需要了解一些偏好：
1. 您是独自旅行还是结伴？
2. 对哪些活动感兴趣？（美食、购物、文化、动漫等）
3. 住宿偏好？（经济酒店、中档酒店、豪华酒店）

用户: 和女朋友一起，预算5000美元，对美食和文化感兴趣

助手: 太棒了！让我为您生成详细计划...

[生成完整的东京7天行程、预算、景点推荐、打包清单等]
```

## 技术说明

- **语言**: Python 3
- **数据格式**: JSON
- **输出格式**: Markdown, JSON
- **依赖**: 无外部依赖（纯标准库）
- **兼容性**: 全平台支持

## 版本历史

- **1.0.2**: 脚本开发完成
  - 8个Python脚本，5043行代码
  - 涵盖行程规划、景点推荐、预算计算、攻略生成、天气查询、货币转换、打包清单、数据管理

- **1.0.0**: 初始版本
  - 行程规划
  - 景点推荐
  - 预算计算
  - 攻略生成
  - 天气查询
  - 货币转换
  - 打包清单
