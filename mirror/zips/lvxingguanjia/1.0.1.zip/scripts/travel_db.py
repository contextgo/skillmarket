#!/usr/bin/env python3
"""
Travel Butler - Database Manager

Manages travel preferences, trips, budgets, and expense tracking.
Stores data in local JSON files.
"""

import json
import os
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

# Database directory
DB_DIR = Path.home() / ".travel_butler"
PREFERENCES_FILE = DB_DIR / "preferences.json"
TRIPS_FILE = DB_DIR / "trips.json"
BUCKET_LIST_FILE = DB_DIR / "bucket_list.json"


def ensure_db_files() -> None:
    """Ensure all database files exist with default values."""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    
    # Default preferences
    if not PREFERENCES_FILE.exists():
        default_prefs = {
            "initialized": False,
            "created_at": datetime.now().isoformat(),
            "travel_style": "",
            "budget_level": "",
            "accommodation_preference": [],
            "interests": [],
            "dietary_restrictions": [],
            "accessibility_needs": [],
            "preferred_activities": [],
            "pace_preference": "",
            "travel_companions": "",
            "language_skills": [],
            "previous_destinations": [],
            "visited_countries": [],
            "visited_cities": [],
            "last_updated": None
        }
        PREFERENCES_FILE.write_text(json.dumps(default_prefs, indent=2))
    
    # Default trips
    if not TRIPS_FILE.exists():
        default_trips = {
            "current_trips": [],
            "past_trips": [],
            "trip_ideas": []
        }
        TRIPS_FILE.write_text(json.dumps(default_trips, indent=2))


def load_json(file_path: Path) -> Dict[str, Any]:
    """Load JSON from file."""
    ensure_db_files()
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return {}


def save_json(file_path: Path, data: Dict[str, Any]) -> None:
    """Save JSON to file."""
    ensure_db_files()
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


# ============================================================================
# PREFERENCES MANAGEMENT
# ============================================================================

def is_initialized() -> bool:
    """Check if travel preferences are initialized."""
    prefs = load_json(PREFERENCES_FILE)
    return prefs.get("initialized", False)


def get_preferences() -> Dict[str, Any]:
    """Get user travel preferences."""
    return load_json(PREFERENCES_FILE)


def save_preferences(preferences: Dict[str, Any]) -> None:
    """Save user travel preferences."""
    prefs = load_json(PREFERENCES_FILE)
    prefs.update(preferences)
    prefs["initialized"] = True
    prefs["last_updated"] = datetime.now().isoformat()
    save_json(PREFERENCES_FILE, prefs)


def update_preference(key: str, value: Any) -> None:
    """Update a specific preference."""
    prefs = load_json(PREFERENCES_FILE)
    prefs[key] = value
    prefs["last_updated"] = datetime.now().isoformat()
    save_json(PREFERENCES_FILE, prefs)


def add_to_bucket_list(destination: str, notes: str = "", priority: str = "medium") -> None:
    """Add destination to bucket list."""
    prefs = load_json(PREFERENCES_FILE)
    if "bucket_list" not in prefs:
        prefs["bucket_list"] = []
    
    # Check if already exists
    for item in prefs["bucket_list"]:
        if item["destination"].lower() == destination.lower():
            return  # Already exists
    
    prefs["bucket_list"].append({
        "destination": destination,
        "notes": notes,
        "priority": priority,
        "added_at": datetime.now().isoformat(),
        "status": "wishlist"
    })
    prefs["last_updated"] = datetime.now().isoformat()
    save_json(PREFERENCES_FILE, prefs)


def remove_from_bucket_list(destination: str) -> bool:
    """Remove destination from bucket list."""
    prefs = load_json(PREFERENCES_FILE)
    if "bucket_list" not in prefs:
        return False
    
    original_length = len(prefs["bucket_list"])
    prefs["bucket_list"] = [
        item for item in prefs["bucket_list"]
        if item["destination"].lower() != destination.lower()
    ]
    
    if len(prefs["bucket_list"]) < original_length:
        prefs["last_updated"] = datetime.now().isoformat()
        save_json(PREFERENCES_FILE, prefs)
        return True
    return False


def add_previous_destination(destination: str, country: str = "", city: str = "") -> None:
    """Add to list of previously visited destinations."""
    prefs = load_json(PREFERENCES_FILE)
    
    if "previous_destinations" not in prefs:
        prefs["previous_destinations"] = []
    if "visited_countries" not in prefs:
        prefs["visited_countries"] = []
    if "visited_cities" not in prefs:
        prefs["visited_cities"] = []
    
    if destination not in prefs["previous_destinations"]:
        prefs["previous_destinations"].append(destination)
    
    if country and country not in prefs["visited_countries"]:
        prefs["visited_countries"].append(country)
    
    if city and city not in prefs["visited_cities"]:
        prefs["visited_cities"].append(city)
    
    prefs["last_updated"] = datetime.now().isoformat()
    save_json(PREFERENCES_FILE, prefs)


# ============================================================================
# TRIP MANAGEMENT
# ============================================================================

def get_trips(status: str = "all") -> Dict[str, List[Dict]]:
    """Get trips by status."""
    trips = load_json(TRIPS_FILE)
    
    if status == "all":
        return trips
    elif status == "current":
        return {"current_trips": trips.get("current_trips", [])}
    elif status == "past":
        return {"past_trips": trips.get("past_trips", [])}
    elif status == "ideas":
        return {"trip_ideas": trips.get("trip_ideas", [])}
    return {}


def add_trip(trip: Dict[str, Any], status: str = "current") -> str:
    """Add a new trip."""
    trips = load_json(TRIPS_FILE)
    
    trip_id = str(datetime.now().timestamp())
    trip["id"] = trip_id
    trip["created_at"] = datetime.now().isoformat()
    trip["status"] = status
    
    if status == "current" or status == "upcoming":
        trips["current_trips"].append(trip)
    elif status == "past" or status == "completed":
        trips["past_trips"].append(trip)
    elif status == "idea" or status == "dream":
        trips["trip_ideas"].append(trip)
    
    save_json(TRIPS_FILE, trips)
    return trip_id


def update_trip(trip_id: str, updates: Dict[str, Any]) -> bool:
    """Update a trip."""
    trips = load_json(TRIPS_FILE)
    
    for trip_list in [trips["current_trips"], trips["past_trips"], trips["trip_ideas"]]:
        for i, trip in enumerate(trip_list):
            if trip.get("id") == trip_id:
                trip_list[i].update(updates)
                trip_list[i]["updated_at"] = datetime.now().isoformat()
                save_json(TRIPS_FILE, trips)
                return True
    return False


def get_trip_by_id(trip_id: str) -> Optional[Dict[str, Any]]:
    """Get a specific trip by ID."""
    trips = load_json(TRIPS_FILE)
    
    for trip_list in [trips["current_trips"], trips["past_trips"], trips["trip_ideas"]]:
        for trip in trip_list:
            if trip.get("id") == trip_id:
                return trip
    return None


def delete_trip(trip_id: str) -> bool:
    """Delete a trip."""
    trips = load_json(TRIPS_FILE)
    
    for trip_list in [trips["current_trips"], trips["past_trips"], trips["trip_ideas"]]:
        for i, trip in enumerate(trip_list):
            if trip.get("id") == trip_id:
                trip_list.pop(i)
                save_json(TRIPS_FILE, trips)
                return True
    return False


def move_trip_to_past(trip_id: str) -> bool:
    """Move a current trip to past trips."""
    trips = load_json(TRIPS_FILE)
    
    for i, trip in enumerate(trips["current_trips"]):
        if trip.get("id") == trip_id:
            trip["completed_at"] = datetime.now().isoformat()
            trip["status"] = "past"
            trips["current_trips"].pop(i)
            trips["past_trips"].append(trip)
            save_json(TRIPS_FILE, trips)
            
            # Add to previous destinations
            if trip.get("destination"):
                dest = trip["destination"]
                if isinstance(dest, dict):
                    add_previous_destination(
                        f"{dest.get('city', '')}, {dest.get('country', '')}",
                        dest.get("country", ""),
                        dest.get("city", "")
                    )
                else:
                    add_previous_destination(str(dest))
            
            return True
    return False


def convert_idea_to_trip(trip_id: str) -> bool:
    """Convert a trip idea to a current trip."""
    trips = load_json(TRIPS_FILE)
    
    for i, trip in enumerate(trips["trip_ideas"]):
        if trip.get("id") == trip_id:
            trip["status"] = "current"
            trips["trip_ideas"].pop(i)
            trips["current_trips"].append(trip)
            save_json(TRIPS_FILE, trips)
            return True
    return False


# ============================================================================
# BUDGET & EXPENSE TRACKING
# ============================================================================

def add_expense(trip_id: str, expense: Dict[str, Any]) -> bool:
    """Add an expense to a trip."""
    trips = load_json(TRIPS_FILE)
    
    for trip in trips["current_trips"] + trips["past_trips"]:
        if trip.get("id") == trip_id:
            if "expenses" not in trip:
                trip["expenses"] = []
            
            expense_id = str(datetime.now().timestamp())
            expense["id"] = expense_id
            expense["date"] = expense.get("date", datetime.now().date().isoformat())
            expense["created_at"] = datetime.now().isoformat()
            
            trip["expenses"].append(expense)
            
            # Update total spent
            total = sum(e.get("amount", 0) for e in trip["expenses"])
            if "budget" not in trip:
                trip["budget"] = {}
            trip["budget"]["spent"] = total
            
            save_json(TRIPS_FILE, trips)
            return True
    return False


def update_expense(trip_id: str, expense_id: str, updates: Dict[str, Any]) -> bool:
    """Update an expense."""
    trips = load_json(TRIPS_FILE)
    
    for trip in trips["current_trips"] + trips["past_trips"]:
        if trip.get("id") == trip_id:
            for expense in trip.get("expenses", []):
                if expense.get("id") == expense_id:
                    expense.update(updates)
                    
                    # Recalculate total
                    total = sum(e.get("amount", 0) for e in trip["expenses"])
                    trip["budget"]["spent"] = total
                    
                    save_json(TRIPS_FILE, trips)
                    return True
    return False


def delete_expense(trip_id: str, expense_id: str) -> bool:
    """Delete an expense."""
    trips = load_json(TRIPS_FILE)
    
    for trip in trips["current_trips"] + trips["past_trips"]:
        if trip.get("id") == trip_id:
            original_length = len(trip.get("expenses", []))
            trip["expenses"] = [
                e for e in trip.get("expenses", [])
                if e.get("id") != expense_id
            ]
            
            if len(trip["expenses"]) < original_length:
                # Recalculate total
                total = sum(e.get("amount", 0) for e in trip["expenses"])
                trip["budget"]["spent"] = total
                
                save_json(TRIPS_FILE, trips)
                return True
    return False


def get_budget_summary(trip_id: str) -> Dict[str, Any]:
    """Get budget summary for a trip."""
    trip = get_trip_by_id(trip_id)
    if not trip:
        return {"error": "Trip not found"}
    
    budget = trip.get("budget", {})
    expenses = trip.get("expenses", [])
    
    total_budget = budget.get("total", 0)
    spent = budget.get("spent", sum(e.get("amount", 0) for e in expenses))
    remaining = total_budget - spent
    
    # Category breakdown
    categories = {}
    for expense in expenses:
        category = expense.get("category", "Other")
        categories[category] = categories.get(category, 0) + expense.get("amount", 0)
    
    return {
        "trip_id": trip_id,
        "destination": trip.get("destination", {}),
        "total_budget": total_budget,
        "spent": spent,
        "remaining": remaining,
        "percentage_used": round((spent / total_budget * 100), 1) if total_budget > 0 else 0,
        "by_category": categories,
        "currency": budget.get("currency", "USD")
    }


# ============================================================================
# ITINERARY MANAGEMENT
# ============================================================================

def add_itinerary_item(trip_id: str, item: Dict[str, Any]) -> bool:
    """Add an item to trip itinerary."""
    trips = load_json(TRIPS_FILE)
    
    for trip in trips["current_trips"] + trips["past_trips"]:
        if trip.get("id") == trip_id:
            if "itinerary" not in trip:
                trip["itinerary"] = []
            
            item["id"] = str(datetime.now().timestamp())
            trip["itinerary"].append(item)
            
            # Sort by date
            trip["itinerary"].sort(key=lambda x: x.get("date", ""))
            
            save_json(TRIPS_FILE, trips)
            return True
    return False


def get_itinerary(trip_id: str) -> List[Dict[str, Any]]:
    """Get trip itinerary."""
    trip = get_trip_by_id(trip_id)
    if trip:
        return trip.get("itinerary", [])
    return []


# ============================================================================
# STATISTICS
# ============================================================================

def get_travel_stats() -> Dict[str, Any]:
    """Get travel statistics."""
    prefs = load_json(PREFERENCES_FILE)
    trips = load_json(TRIPS_FILE)
    
    past_trips = trips.get("past_trips", [])
    current_trips = trips.get("current_trips", [])
    
    # Calculate stats
    countries_visited = len(prefs.get("visited_countries", []))
    cities_visited = len(prefs.get("visited_cities", []))
    
    total_days = 0
    total_spent = 0
    
    for trip in past_trips:
        if trip.get("duration_days"):
            total_days += trip["duration_days"]
        total_spent += trip.get("budget", {}).get("spent", 0)
    
    # Average costs
    avg_trip_cost = total_spent / len(past_trips) if past_trips else 0
    avg_trip_duration = total_days / len(past_trips) if past_trips else 0
    
    return {
        "total_trips": len(past_trips),
        "upcoming_trips": len(current_trips),
        "countries_visited": countries_visited,
        "cities_visited": cities_visited,
        "total_days_traveled": total_days,
        "total_spent": round(total_spent, 2),
        "average_trip_cost": round(avg_trip_cost, 2),
        "average_trip_duration": round(avg_trip_duration, 1),
        "bucket_list_size": len(prefs.get("bucket_list", [])),
        "visited_countries": prefs.get("visited_countries", []),
        "visited_cities": prefs.get("visited_cities", []),
        "bucket_list": prefs.get("bucket_list", [])
    }


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def export_all() -> Dict[str, Any]:
    """Export all travel data."""
    return {
        "preferences": get_preferences(),
        "trips": get_trips("all"),
        "stats": get_travel_stats(),
        "exported_at": datetime.now().isoformat(),
        "version": "1.0"
    }


def import_data(data: Dict[str, Any]) -> bool:
    """Import travel data from export."""
    try:
        if "preferences" in data:
            save_json(PREFERENCES_FILE, data["preferences"])
        if "trips" in data:
            save_json(TRIPS_FILE, data["trips"])
        return True
    except Exception as e:
        return False


def reset_all() -> bool:
    """Reset all data (use with caution)."""
    try:
        for file_path in [PREFERENCES_FILE, TRIPS_FILE]:
            if file_path.exists():
                file_path.unlink()
        ensure_db_files()
        return True
    except Exception as e:
        return False


# ============================================================================
# CLI INTERFACE
# ============================================================================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Travel Butler Database Manager")
        print("\nUsage:")
        print("  python3 travel_db.py is_initialized")
        print("  python3 travel_db.py get_preferences")
        print("  python3 travel_db.py get_trips [current|past|ideas|all]")
        print("  python3 travel_db.py get_trip <trip_id>")
        print("  python3 travel_db.py stats")
        print("  python3 travel_db.py export")
        print("  python3 travel_db.py reset")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "is_initialized":
        print("true" if is_initialized() else "false")
    
    elif command == "get_preferences":
        print(json.dumps(get_preferences(), indent=2, ensure_ascii=False))
    
    elif command == "get_trips":
        status = sys.argv[2] if len(sys.argv) > 2 else "all"
        print(json.dumps(get_trips(status), indent=2, ensure_ascii=False))
    
    elif command == "get_trip":
        if len(sys.argv) < 3:
            print("Error: trip_id required")
            sys.exit(1)
        trip = get_trip_by_id(sys.argv[2])
        if trip:
            print(json.dumps(trip, indent=2, ensure_ascii=False))
        else:
            print("Trip not found")
    
    elif command == "stats":
        print(json.dumps(get_travel_stats(), indent=2, ensure_ascii=False))
    
    elif command == "export":
        print(json.dumps(export_all(), indent=2, ensure_ascii=False))
    
    elif command == "reset":
        confirm = input("Are you sure you want to reset all travel data? (yes/no): ")
        if confirm.lower() == "yes":
            if reset_all():
                print("All travel data has been reset.")
            else:
                print("Error resetting data.")
        else:
            print("Reset cancelled.")
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
