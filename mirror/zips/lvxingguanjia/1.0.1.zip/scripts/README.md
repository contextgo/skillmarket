# Travel Butler Scripts

This directory contains all core functionality scripts for the Travel Butler skill.

## Scripts Overview

| Script | Description | CLI Usage |
|--------|-------------|-----------|
| `itinerary_planner.py` | Generate detailed day-by-day travel itineraries | `--destination Tokyo --start 2024-06-01 --end 2024-06-07 --interests sightseeing food` |
| `attraction_recommender.py` | Recommend attractions based on interests | `--destination Tokyo --country Japan --interests sightseeing food` |
| `budget_calculator.py` | Calculate and track travel budgets | `--budget 2500 --days 7 --style mid-range --travelers 2` |
| `guide_generator.py` | Generate comprehensive travel guides | `--destination Tokyo --country Japan --days 7 --interests sightseeing` |
| `weather_checker.py` | Provide weather forecasts and recommendations | `--destination Tokyo --country Japan --start 2024-06-01 --end 2024-06-07` |
| `currency_converter.py` | Convert between currencies | `--amount 100 --from USD --to JPY` |
| `packing_list.py` | Generate customized packing lists | `--destination Tokyo --country Japan --days 7 --climate temperate` |
| `travel_db.py` | Manage travel preferences and trip data | `is_initialized`, `get_preferences`, `stats`, `export` |

## Common Commands

### Check if preferences are initialized
```bash
python3 scripts/travel_db.py is_initialized
```

### View travel statistics
```bash
python3 scripts/travel_db.py stats
```

### Generate a complete itinerary
```bash
python3 scripts/itinerary_planner.py \
  --destination "Tokyo" \
  --start 2024-06-01 \
  --end 2024-06-07 \
  --interests sightseeing food culture \
  --pace moderate \
  --output itinerary.md
```

### Get attraction recommendations
```bash
python3 scripts/attraction_recommender.py \
  --destination "Tokyo" \
  --country "Japan" \
  --interests sightseeing food \
  --num 10
```

### Calculate budget
```bash
python3 scripts/budget_calculator.py \
  --budget 2500 \
  --days 7 \
  --style mid-range \
  --travelers 2
```

### Check weather
```bash
python3 scripts/weather_checker.py \
  --destination "Tokyo" \
  --country "Japan" \
  --start 2024-06-01 \
  --end 2024-06-07
```

### Convert currency
```bash
python3 scripts/currency_converter.py \
  --amount 100 \
  --from USD \
  --to JPY
```

### Generate packing list
```bash
python3 scripts/packing_list.py \
  --destination "Tokyo" \
  --country "Japan" \
  --days 7 \
  --activities sightseeing food \
  --climate temperate
```

### Export all data
```bash
python3 scripts/travel_db.py export
```

## Data Storage

All user data is stored in `~/.travel_butler/`:
- `preferences.json` - User travel preferences
- `trips.json` - Trip history and current trips
- `bucket_list.json` - Travel bucket list

## Dependencies

All scripts use only Python standard library:
- `json` - Data storage
- `datetime` - Date handling
- `pathlib` - File paths
- `typing` - Type hints

No external packages required.
