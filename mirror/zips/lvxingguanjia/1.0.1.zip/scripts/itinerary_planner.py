#!/usr/bin/env python3
"""
Travel Butler - Itinerary Planner

Generates detailed day-by-day travel itineraries based on destination,
preferences, and constraints.
"""

import sys
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import json

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))


def parse_date_range(start_date: str, end_date: str) -> tuple:
    """Parse date range strings into datetime objects."""
    try:
        start = datetime.fromisoformat(start_date)
        end = datetime.fromisoformat(end_date)
        return start, end
    except ValueError:
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
            return start, end
        except:
            return None, None


def calculate_trip_duration(start_date: str, end_date: str) -> int:
    """Calculate number of days in trip."""
    start, end = parse_date_range(start_date, end_date)
    if start and end:
        return (end - start).days + 1
    return 0


def generate_time_slots() -> Dict[str, str]:
    """Generate standard time slots for itinerary."""
    return {
        "early_morning": "6:00 AM - 9:00 AM",
        "morning": "9:00 AM - 12:00 PM",
        "lunch": "12:00 PM - 2:00 PM",
        "afternoon": "2:00 PM - 5:00 PM",
        "evening": "5:00 PM - 8:00 PM",
        "dinner": "8:00 PM - 10:00 PM",
        "night": "10:00 PM - 12:00 AM"
    }


def suggest_activities_for_destination(destination: str, interests: List[str]) -> Dict[str, List[str]]:
    """Suggest activities based on destination and interests."""
    activity_map = {
        "sightseeing": [
            "Guided city tour",
            "Historic district walk",
            "Landmark visits",
            "Museum exploration",
            "Architecture tour"
        ],
        "food": [
            "Local food tour",
            "Cooking class",
            "Market visit",
            "Restaurant hopping",
            "Wine/Tea tasting"
        ],
        "adventure": [
            "Hiking",
            "Water sports",
            "Cycling tour",
            "Rock climbing",
            "Zip-lining"
        ],
        "culture": [
            "Local festival",
            "Art gallery visit",
            "Theater performance",
            "Cultural workshop",
            "Heritage site tour"
        ],
        "beach": [
            "Beach relaxation",
            "Snorkeling",
            "Beach volleyball",
            "Sunset viewing",
            "Water sports"
        ],
        "nature": [
            "National park visit",
            "Botanical garden",
            "Wildlife safari",
            "Nature trail hike",
            "Scenic viewpoint"
        ],
        "shopping": [
            "Local market",
            "Shopping district",
            "Artisan shops",
            "Antique stores",
            "Fashion boutiques"
        ],
        "nightlife": [
            "Pub crawl",
            "Live music venue",
            "Night market",
            "Rooftop bar",
            "Dance club"
        ],
        "wellness": [
            "Spa treatment",
            "Yoga class",
            "Meditation session",
            "Hot spring visit",
            "Massage"
        ]
    }
    
    suggestions = {}
    for interest in interests:
        interest_lower = interest.lower()
        for key, activities in activity_map.items():
            if key in interest_lower or interest_lower in key:
                suggestions[key] = activities
                break
        else:
            suggestions[interest_lower] = activity_map["sightseeing"]
    
    return suggestions


def generate_daily_schedule(
    day: int,
    date: datetime,
    destination: str,
    interests: List[str],
    pace: str = "moderate",
    weather: Optional[str] = None
) -> Dict[str, Any]:
    """Generate detailed schedule for a single day."""
    
    slots = generate_time_slots()
    
    # Adjust activities based on pace
    pace_multiplier = {
        "relaxed": 0.6,
        "moderate": 1.0,
        "packed": 1.4
    }
    
    activities_per_day = {
        "relaxed": 2,
        "moderate": 3,
        "packed": 4
    }
    
    num_activities = activities_per_day.get(pace, 3)
    
    schedule = {
        "day": day,
        "date": date.strftime("%Y-%m-%d"),
        "day_name": date.strftime("%A"),
        "theme": f"Exploring {destination}",
        "activities": [],
        "meals": {
            "breakfast": {"time": "8:00 AM", "suggestion": "Hotel restaurant or local cafe"},
            "lunch": {"time": "12:30 PM", "suggestion": "Local restaurant"},
            "dinner": {"time": "7:30 PM", "suggestion": "Fine dining or local favorite"}
        },
        "transportation": [],
        "notes": [],
        "booking_required": []
    }
    
    # Morning activities
    if num_activities >= 1:
        schedule["activities"].append({
            "time": slots["morning"],
            "title": f"Explore {destination} Old Town",
            "type": "sightseeing",
            "duration": "3 hours",
            "location": "Historic Center",
            "cost_estimate": "$15-25",
            "tips": "Wear comfortable walking shoes"
        })
    
    # Midday activities
    if num_activities >= 2:
        schedule["activities"].append({
            "time": slots["afternoon"],
            "title": "Local Market & Lunch",
            "type": "food",
            "duration": "2-3 hours",
            "location": "Central Market",
            "cost_estimate": "$20-40",
            "tips": "Try local specialties"
        })
    
    # Afternoon activities
    if num_activities >= 3:
        schedule["activities"].append({
            "time": slots["evening"],
            "title": "Cultural Museum Visit",
            "type": "culture",
            "duration": "2 hours",
            "location": "National Museum",
            "cost_estimate": "$10-20",
            "tips": "Audio guide recommended"
        })
    
    # Additional activities for packed pace
    if num_activities >= 4:
        schedule["activities"].append({
            "time": slots["night"],
            "title": "Evening Entertainment",
            "type": "nightlife",
            "duration": "2-3 hours",
            "location": "Entertainment District",
            "cost_estimate": "$30-50",
            "tips": "Check show schedules"
        })
    
    return schedule


def generate_itinerary(
    destination: str,
    start_date: str,
    end_date: str,
    interests: List[str],
    pace: str = "moderate",
    travelers: int = 1,
    special_requirements: Optional[List[str]] = None
) -> Dict[str, Any]:
    """Generate complete travel itinerary."""
    
    start, end = parse_date_range(start_date, end_date)
    if not start or not end:
        return {"error": "Invalid date format. Use YYYY-MM-DD."}
    
    duration = calculate_trip_duration(start_date, end_date)
    
    itinerary = {
        "destination": destination,
        "dates": {
            "start": start_date,
            "end": end_date,
            "duration": duration
        },
        "travelers": travelers,
        "pace": pace,
        "interests": interests,
        "days": [],
        "summary": {
            "total_activities": 0,
            "estimated_cost": "$0",
            "highlights": []
        },
        "created_at": datetime.now().isoformat()
    }
    
    suggestions = suggest_activities_for_destination(destination, interests)
    
    for day_num in range(1, duration + 1):
        current_date = start + timedelta(days=day_num - 1)
        daily_schedule = generate_daily_schedule(
            day_num,
            current_date,
            destination,
            interests,
            pace
        )
        itinerary["days"].append(daily_schedule)
        itinerary["summary"]["total_activities"] += len(daily_schedule["activities"])
    
    # Add summary highlights
    itinerary["summary"]["highlights"] = [
        f"{duration}-day adventure in {destination}",
        f"Explore {', '.join(interests[:3])}",
        f"{pace.capitalize()} pace travel style"
    ]
    
    return itinerary


def export_itinerary_to_markdown(itinerary: Dict[str, Any]) -> str:
    """Export itinerary as formatted markdown."""
    if "error" in itinerary:
        return f"Error: {itinerary['error']}"
    
    md = f"# 🗺️ {itinerary['destination']} Travel Itinerary\n\n"
    md += f"**Duration:** {itinerary['dates']['duration']} days\n"
    md += f"**Dates:** {itinerary['dates']['start']} to {itinerary['dates']['end']}\n"
    md += f"**Travelers:** {itinerary['travelers']}\n"
    md += f"**Pace:** {itinerary['pace'].capitalize()}\n"
    md += f"**Interests:** {', '.join(itinerary['interests'])}\n\n"
    
    md += "---\n\n"
    
    for day in itinerary["days"]:
        md += f"## Day {day['day']}: {day['day_name']} ({day['date']})\n\n"
        md += f"**Theme:** {day['theme']}\n\n"
        
        md += "### Activities\n\n"
        for activity in day["activities"]:
            md += f"#### ⏰ {activity['time']}: {activity['title']}\n"
            md += f"- **Type:** {activity['type']}\n"
            md += f"- **Duration:** {activity['duration']}\n"
            md += f"- **Location:** {activity['location']}\n"
            md += f"- **Cost:** {activity['cost_estimate']}\n"
            md += f"- **Tips:** {activity['tips']}\n\n"
        
        md += "### Meals\n\n"
        for meal, details in day["meals"].items():
            md += f"- **{meal.capitalize()}** ({details['time']}): {details['suggestion']}\n"
        
        if day["notes"]:
            md += "\n### Notes\n"
            for note in day["notes"]:
                md += f"- {note}\n"
        
        md += "\n---\n\n"
    
    md += "## Trip Summary\n\n"
    md += f"- **Total Activities:** {itinerary['summary']['total_activities']}\n"
    md += f"- **Estimated Cost:** {itinerary['summary']['estimated_cost']}\n\n"
    
    md += "### Highlights\n"
    for highlight in itinerary["summary"]["highlights"]:
        md += f"- {highlight}\n"
    
    return md


# CLI Interface
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Travel Itinerary Planner")
    parser.add_argument("--destination", "-d", required=True, help="Destination city/country")
    parser.add_argument("--start", "-s", required=True, help="Start date (YYYY-MM-DD)")
    parser.add_argument("--end", "-e", required=True, help="End date (YYYY-MM-DD)")
    parser.add_argument("--interests", "-i", nargs="+", default=["sightseeing", "food"],
                        help="Travel interests")
    parser.add_argument("--pace", "-p", choices=["relaxed", "moderate", "packed"],
                        default="moderate", help="Travel pace")
    parser.add_argument("--travelers", "-t", type=int, default=1, help="Number of travelers")
    parser.add_argument("--output", "-o", help="Output file path (JSON or MD)")
    parser.add_argument("--format", "-f", choices=["json", "markdown"], default="json",
                        help="Output format")
    
    args = parser.parse_args()
    
    itinerary = generate_itinerary(
        destination=args.destination,
        start_date=args.start,
        end_date=args.end,
        interests=args.interests,
        pace=args.pace,
        travelers=args.travelers
    )
    
    if args.output:
        if args.format == "markdown":
            content = export_itinerary_to_markdown(itinerary)
        else:
            content = json.dumps(itinerary, indent=2)
        
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✓ Itinerary saved to: {args.output}")
    else:
        if args.format == "markdown":
            print(export_itinerary_to_markdown(itinerary))
        else:
            print(json.dumps(itinerary, indent=2, ensure_ascii=False))
