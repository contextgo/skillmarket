#!/usr/bin/env python3
"""
Travel Butler - Weather Checker

Provides weather information and clothing recommendations
for travel destinations.
"""

import sys
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import json

sys.path.insert(0, str(Path(__file__).parent.parent))


# Climate data templates by region
CLIMATE_DATA = {
    "Mediterranean": {
        "spring": {"temp": "15-22°C", "rain": "Low", "clothing": "Light layers, jacket", "activities": "Ideal"},
        "summer": {"temp": "25-35°C", "rain": "Rare", "clothing": "Light, breathable", "activities": "Beach, morning/evening tours"},
        "autumn": {"temp": "15-25°C", "rain": "Moderate", "clothing": "Layers, light jacket", "activities": "Good"},
        "winter": {"temp": "8-15°C", "rain": "Moderate", "clothing": "Warm layers, raincoat", "activities": "Indoor focus"}
    },
    "Tropical": {
        "spring": {"temp": "25-32°C", "rain": "Variable", "clothing": "Light, quick-dry", "activities": "Indoor during rain"},
        "summer": {"temp": "25-35°C", "rain": "High", "clothing": "Very light, rain gear", "activities": "Early morning/evening"},
        "autumn": {"temp": "25-30°C", "rain": "Moderate", "clothing": "Light layers", "activities": "Good"},
        "winter": {"temp": "20-28°C", "rain": "Low", "clothing": "Light layers", "activities": "Ideal"}
    },
    "Temperate": {
        "spring": {"temp": "10-18°C", "rain": "Moderate", "clothing": "Layers, light jacket", "activities": "Good"},
        "summer": {"temp": "18-25°C", "rain": "Variable", "clothing": "Light layers", "activities": "Ideal"},
        "autumn": {"temp": "8-15°C", "rain": "Moderate", "clothing": "Warm layers, jacket", "activities": "Good"},
        "winter": {"temp": "0-10°C", "rain": "Snow/Rain", "clothing": "Heavy coat, boots", "activities": "Indoor/winter sports"}
    },
    "Desert": {
        "spring": {"temp": "15-30°C", "rain": "Rare", "clothing": "Layers, loose fitting", "activities": "Morning/evening"},
        "summer": {"temp": "30-45°C", "rain": "Rare", "clothing": "Light, protective", "activities": "Night activities only"},
        "autumn": {"temp": "15-30°C", "rain": "Rare", "clothing": "Layers", "activities": "Good"},
        "winter": {"temp": "5-20°C", "rain": "Rare", "clothing": "Warm layers for evening", "activities": "Ideal"}
    },
    "Subtropical": {
        "spring": {"temp": "18-25°C", "rain": "Moderate", "clothing": "Light layers", "activities": "Good"},
        "summer": {"temp": "25-32°C", "rain": "High", "clothing": "Light, rain gear", "activities": "Morning/evening"},
        "autumn": {"temp": "18-25°C", "rain": "Low", "clothing": "Light layers", "activities": "Ideal"},
        "winter": {"temp": "10-18°C", "rain": "Moderate", "clothing": "Light jacket", "activities": "Good"}
    }
}


def get_season(date_str: str) -> str:
    """Determine season from date string."""
    try:
        date = datetime.fromisoformat(date_str.replace("/", "-"))
    except:
        try:
            date = datetime.strptime(date_str, "%Y-%m-%d")
        except:
            return "spring"
    
    month = date.month
    
    if month in [3, 4, 5]:
        return "spring"
    elif month in [6, 7, 8]:
        return "summer"
    elif month in [9, 10, 11]:
        return "autumn"
    else:
        return "winter"


def get_climate_type(destination: str, country: str) -> str:
    """Determine climate type based on destination."""
    # This is a simplified mapping - in production, would use a database
    country_lower = country.lower()
    dest_lower = destination.lower()
    
    if any(x in country_lower for x in ["greece", "italy", "spain", "france", "portugal", "turkey", "croatia"]):
        return "Mediterranean"
    elif any(x in country_lower for x in ["thailand", "vietnam", "indonesia", "philippines", "singapore", "malaysia", "hawaii"]):
        return "Tropical"
    elif any(x in country_lower for x in ["japan", "korea", "china"]):
        return "Temperate"
    elif any(x in country_lower for x in ["morocco", "egypt", "uae", "qatar", "jordan", "israel"]):
        return "Desert"
    elif any(x in country_lower for x in ["australia", "brazil", "argentina", "india"]):
        return "Subtropical"
    else:
        return "Temperate"


def generate_weather_forecast(
    destination: str,
    country: str,
    start_date: str,
    end_date: str
) -> Dict[str, Any]:
    """Generate weather forecast for trip dates."""
    
    climate_type = get_climate_type(destination, country)
    climate = CLIMATE_DATA.get(climate_type, CLIMATE_DATA["Temperate"])
    
    try:
        start = datetime.fromisoformat(start_date.replace("/", "-"))
        end = datetime.fromisoformat(end_date.replace("/", "-"))
    except:
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
        except:
            return {"error": "Invalid date format"}
    
    days = (end - start).days + 1
    
    forecast = []
    current = start
    
    for i in range(min(days, 14)):  # Cap at 14 days
        date = current + timedelta(days=i)
        season = get_season(date.strftime("%Y-%m-%d"))
        season_data = climate.get(season, climate["spring"])
        
        forecast.append({
            "date": date.strftime("%Y-%m-%d"),
            "day_name": date.strftime("%A"),
            "season": season,
            "temperature": season_data["temp"],
            "rain_chance": season_data["rain"],
            "clothing": season_data["clothing"],
            "activities_outlook": season_data["activities"]
        })
    
    # Determine overall conditions
    seasons = [f["season"] for f in forecast]
    most_common_season = max(set(seasons), key=seasons.count)
    overall_conditions = climate.get(most_common_season, climate["spring"])
    
    return {
        "destination": destination,
        "country": country,
        "climate_type": climate_type,
        "dates": {
            "start": start_date,
            "end": end_date,
            "total_days": days
        },
        "forecast": forecast,
        "overall": {
            "best_season": most_common_season,
            "typical_temperature": overall_conditions["temp"],
            "rain_outlook": overall_conditions["rain"],
            "recommended_clothing": overall_conditions["clothing"],
            "activity_outlook": overall_conditions["activities"]
        },
        "generated_at": datetime.now().isoformat()
    }


def generate_packing_recommendations(weather: Dict[str, Any]) -> Dict[str, List[str]]:
    """Generate packing recommendations based on weather forecast."""
    
    if "error" in weather:
        return {"essentials": [], "clothing": [], "accessories": []}
    
    climate_type = weather.get("climate_type", "Temperate")
    overall = weather.get("overall", {})
    temp_range = overall.get("typical_temperature", "15-25°C")
    rain = overall.get("rain_outlook", "Moderate")
    
    recommendations = {
        "essentials": [
            "Passport and travel documents",
            "Phone charger and power bank",
            "Medications and first aid kit",
            "Travel insurance documents",
            "Cash and cards"
        ],
        "clothing": [],
        "accessories": [],
        "toiletries": [
            "Toothbrush and toothpaste",
            "Deodorant",
            "Sunscreen (SPF 30+)",
            "Personal hygiene items"
        ]
    }
    
    # Temperature-based clothing
    try:
        temps = temp_range.replace("°C", "").split("-")
        avg_temp = (int(temps[0]) + int(temps[1])) / 2
    except:
        avg_temp = 20
    
    if avg_temp > 28:
        recommendations["clothing"] = [
            "Light cotton t-shirts (4-5)",
            "Shorts or light pants (3-4)",
            "Light dresses/rompers (optional)",
            "Swimsuit",
            "Sandals",
            "Light cardigan for AC"
        ]
        recommendations["accessories"] = [
            "Sunglasses",
            "Sun hat",
            "Reusable water bottle"
        ]
    elif avg_temp > 15:
        recommendations["clothing"] = [
            "T-shirts and tops (5-6)",
            "Long pants (2-3)",
            "Light jacket or sweater",
            "Comfortable walking shoes",
            "Dressy outfit for evenings"
        ]
        recommendations["accessories"] = [
            "Light scarf",
            "Sunglasses",
            "Compact umbrella"
        ]
    else:
        recommendations["clothing"] = [
            "Warm layers (3-4 sweaters/long sleeves)",
            "Warm jacket or coat",
            "Pants (3-4)",
            "Comfortable boots",
            "Thermal underwear (optional)",
            "Beanie and gloves"
        ]
        recommendations["accessories"] = [
            "Warm scarf",
            "Gloves",
            "Warm hat/beanie",
            "Thermal flask"
        ]
    
    # Rain-based additions
    if rain.lower() in ["high", "moderate", "frequent"]:
        recommendations["accessories"].append("Waterproof jacket or raincoat")
        recommendations["accessories"].append("Umbrella")
        recommendations["accessories"].append("Waterproof bag for electronics")
    
    # Climate-specific additions
    if climate_type == "Tropical":
        recommendations["essentials"].append("Bug repellent")
        recommendations["essentials"].append("Anti-malaria precautions (if needed)")
        recommendations["toiletries"].append("Strong sunscreen")
        recommendations["toiletries"].append("Aloe vera gel")
    elif climate_type == "Desert":
        recommendations["essentials"].append("Lip balm")
        recommendations["toiletries"].append("Moisturizing lotion")
        recommendations["accessories"].append("Lip balm with SPF")
    elif climate_type == "Mediterranean":
        recommendations["accessories"].append("Comfortable walking shoes")
    
    return recommendations


def format_weather_as_markdown(weather: Dict[str, Any]) -> str:
    """Format weather forecast as markdown."""
    if "error" in weather:
        return f"Error: {weather['error']}"
    
    md = f"# 🌤️ Weather Forecast: {weather['destination']}, {weather['country']}\n\n"
    md += f"**Climate Type:** {weather['climate_type']}\n"
    md += f"**Dates:** {weather['dates']['start']} to {weather['dates']['end']} "
    md += f"({weather['dates']['total_days']} days)\n\n"
    
    md += "---\n\n"
    md += "## 📊 Overall Conditions\n\n"
    md += f"- **Best Season:** {weather['overall']['best_season'].capitalize()}\n"
    md += f"- **Typical Temperature:** {weather['overall']['typical_temperature']}\n"
    md += f"- **Rain Outlook:** {weather['overall']['rain_outlook']}\n"
    md += f"- **Recommended Clothing:** {weather['overall']['recommended_clothing']}\n"
    md += f"- **Activity Outlook:** {weather['overall']['activity_outlook']}\n\n"
    
    md += "---\n\n"
    md += "## 📅 Day-by-Day Forecast\n\n"
    md += "| Date | Day | Temp | Rain | Clothing | Activities |\n"
    md += "|------|-----|------|------|---------|------------|\n"
    
    for day in weather['forecast']:
        md += f"| {day['date']} | {day['day_name']} | "
        md += f"{day['temperature']} | {day['rain_chance']} | "
        md += f"{day['clothing'][:20]}... | {day['activities_outlook']} |\n"
    
    md += "\n"
    
    # Add packing recommendations
    packing = generate_packing_recommendations(weather)
    md += "---\n\n"
    md += "## 🎒 Packing Recommendations\n\n"
    
    md += "### Essentials\n"
    for item in packing.get("essentials", []):
        md += f"- [ ] {item}\n"
    
    md += "\n### Clothing\n"
    for item in packing.get("clothing", []):
        md += f"- [ ] {item}\n"
    
    md += "\n### Accessories\n"
    for item in packing.get("accessories", []):
        md += f"- [ ] {item}\n"
    
    md += "\n### Toiletries\n"
    for item in packing.get("toiletries", []):
        md += f"- [ ] {item}\n"
    
    return md


# CLI Interface
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Weather Checker")
    parser.add_argument("--destination", "-d", required=True, help="Destination")
    parser.add_argument("--country", "-c", required=True, help="Country")
    parser.add_argument("--start", "-s", required=True, help="Start date (YYYY-MM-DD)")
    parser.add_argument("--end", "-e", required=True, help="End date (YYYY-MM-DD)")
    parser.add_argument("--output", "-o", help="Output file path")
    
    args = parser.parse_args()
    
    weather = generate_weather_forecast(
        destination=args.destination,
        country=args.country,
        start_date=args.start,
        end_date=args.end
    )
    
    if args.output:
        content = format_weather_as_markdown(weather)
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✓ Weather forecast saved to: {args.output}")
    else:
        print(format_weather_as_markdown(weather))
