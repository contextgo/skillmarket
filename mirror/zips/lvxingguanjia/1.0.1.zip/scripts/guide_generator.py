#!/usr/bin/env python3
"""
Travel Butler - Guide Generator

Generates comprehensive travel guides for destinations including
local tips, transport info, safety advice, and cultural insights.
"""

import sys
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
import json

sys.path.insert(0, str(Path(__file__).parent.parent))


# Regional transport info
TRANSPORT_INFO = {
    "Europe": {
        "public_transit": "Extensive metro, bus, and tram networks. City cards available.",
        "taxi": "Uber/Bolt widely available. Check meters or agree on fare.",
        "rental": "International license required. Left-hand traffic in UK/Ireland.",
        "rail": "Eurail passes excellent for multi-country travel."
    },
    "Asia": {
        "public_transit": "Metro systems in major cities. Octopus card (HK), Suica (Japan).",
        "taxi": "Grab (SE Asia),滴滴 (China), local apps preferred.",
        "rental": "International license often accepted. Traffic varies by country.",
        "rail": "High-speed rail in Japan, China, South Korea excellent."
    },
    "North America": {
        "public_transit": "Metro in major cities. Limited in smaller towns.",
        "taxi": "Uber/Lyft widely available. Cabs expensive.",
        "rental": "International license OK. One-way fees common.",
        "rail": "Amtrak for scenic routes. Not ideal for speed."
    },
    "Southeast Asia": {
        "public_transit": "Songthaews, buses, and ferries. Cheap but slow.",
        "taxi": "Negotiate fare or use ride apps. Tuk-tuks iconic.",
        "rental": "Scooter rental popular. International license varies.",
        "rail": "Limited but scenic. Overnight trains in Thailand/Vietnam."
    }
}

# Tipping customs by region
TIPPING_CULTURE = {
    "North America": {"restaurant": "15-20%", "taxi": "10-15%", "hotel": "$2-5/bag", "cafe": "optional"},
    "Europe": {"restaurant": "5-10% if service not included", "taxi": "round up", "hotel": "€1-2/bag", "cafe": "not expected"},
    "Asia": {"restaurant": "not expected in local places", "taxi": "not expected", "hotel": "optional", "cafe": "not expected"},
    "Middle East": {"restaurant": "10-15%", "taxi": "round up", "hotel": "AED 5-10", "cafe": "optional"},
    "South America": {"restaurant": "10%", "taxi": "not expected", "hotel": "$1-2/bag", "cafe": "not expected"}
}


def generate_guide_metadata(destination: str, country: str, duration: int) -> Dict[str, Any]:
    """Generate basic guide metadata."""
    return {
        "destination": destination,
        "country": country,
        "duration": duration,
        "created_at": datetime.now().isoformat(),
        "version": "1.0"
    }


def generate_overview(destination: str, country: str, best_time: str) -> str:
    """Generate destination overview section."""
    return f"""## 📍 Destination Overview

### {destination}, {country}

**Best Time to Visit:** {best_time}

{destination} is a vibrant destination offering a unique blend of history, culture, and modern attractions. 
Whether you're interested in exploring ancient landmarks, tasting local cuisine, or immersing yourself 
in the local culture, this guide will help you make the most of your visit.

### Quick Facts
- **Country:** {country}
- **Language:** [Research local languages]
- **Currency:** [Check current currency]
- **Time Zone:** [Check time zone]
- **Emergency:** [Research local emergency numbers]
"""


def generate_transport_guide(destination: str, country: str) -> str:
    """Generate transportation guide section."""
    # Find regional transport info
    region = "Europe"  # Default
    for r in TRANSPORT_INFO.keys():
        if r.lower() in country.lower():
            region = r
            break
    
    transport = TRANSPORT_INFO.get(region, TRANSPORT_INFO["Europe"])
    
    return f"""## 🚇 Transportation Guide

### Getting Around {destination}

#### Public Transit
{transport['public_transit']}
**Pro Tip:** Get a local transit card for convenience and savings.

#### Taxis & Rideshare
{transport['taxi']}
**Pro Tip:** Always confirm the fare before starting your trip.

#### Car Rental
{transport['rental']}
**Pro Tip:** Book in advance for better rates.

#### Rail & Long Distance
{transport['rail']}
**Pro Tip:** Consider rail passes if visiting multiple cities.
"""


def generate_food_guide(destination: str, country: str) -> str:
    """Generate food and dining guide section."""
    return f"""## 🍽️ Food & Dining Guide

### Must-Try Local Dishes
- [Research signature dishes of {destination}]
- [Add local specialties]

### Restaurant Price Ranges
- **Budget:** $5-15/person (local eateries, street food)
- **Mid-range:** $20-50/person
- **Fine dining:** $75+/person

### Dining Customs
- **Breakfast:** [Typical breakfast time and foods]
- **Lunch:** [Typical lunch time - often 12-2 PM]
- **Dinner:** [Typical dinner time - often 7-9 PM]

### Dietary Accommodations
- Vegetarian/Vegan options: [Availability]
- Halal: [Availability]
- Gluten-free: [May be challenging]

### Restaurant Recommendations
1. **Local Favorite:** [Name & specialty]
2. **Hidden Gem:** [Name & specialty]
3. **Fine Dining:** [Name & specialty]
4. **Street Food:** [Location/type]
"""


def generate_cultural_guide(country: str) -> str:
    """Generate cultural etiquette guide section."""
    return f"""## 🎭 Cultural Etiquette

### Do's ✅
- Learn basic phrases in the local language
- Dress modestly when visiting religious sites
- Greet people with a smile
- Be patient - things may move at a different pace
- Try local customs and participate in traditions

### Don'ts ❌
- Don't point your feet at people or sacred objects
- Don't raise your voice in public
- Don't refuse hospitality when offered
- Don't discuss politics or religion unless invited
- Don't photograph people without permission

### Tipping Culture
- Restaurants: {TIPPING_CULTURE.get(country.split()[0], TIPPING_CULTURE['Europe'])['restaurant']}
- Taxis: {TIPPING_CULTURE.get(country.split()[0], TIPPING_CULTURE['Europe'])['taxi']}
- Hotels: {TIPPING_CULTURE.get(country.split()[0], TIPPING_CULTURE['Europe'])['hotel']}
"""


def generate_safety_guide(destination: str, country: str) -> str:
    """Generate safety and health guide section."""
    return f"""## ⚠️ Safety & Health

### General Safety
- [Research current travel advisories for {country}]
- Keep copies of important documents
- Stay aware of your surroundings
- Use hotel safes for valuables
- Trust your instincts

### Common Scams to Avoid
1. **Overcharging:** Always confirm prices before accepting services
2. **Taxi Meters:** Ensure taxi drivers use the meter
3. **Fake Officials:** Verify credentials of anyone claiming to be authority
4. **Street Games:** Avoid staged distraction schemes

### Health Precautions
- [Check required vaccinations]
- Drink bottled water if tap water is unsafe
- Use sunscreen and stay hydrated
- Know location of nearest hospital/clinic

### Emergency Contacts
- **Police:** [Research local number]
- **Ambulance:** [Research local number]
- **Fire:** [Research local number]
- **Embassy:** [Your country's embassy contact]
"""


def generate_packing_guide(destination: str, country: str, duration: int) -> str:
    """Generate packing guide section."""
    return f"""## 🎒 Packing Guide

### Essential Documents
- [ ] Passport (6+ months validity)
- [ ] Visa (if required)
- [ ] Travel insurance documents
- [ ] Flight/hotel confirmations
- [ ] Copies of all documents
- [ ] Emergency contact list

### Electronics
- [ ] Phone + charger
- [ ] Power bank
- [ ] Universal adapter
- [ ] Camera (optional)
- [ ] Headphones

### Clothing ({duration} days)
- [ ] Underwear (1 per day + 2 extra)
- [ ] Socks (comfortable walking)
- [ ] T-shirts/tops
- [ ] Pants/shorts
- [ ] Light jacket/layers
- [ ] Comfortable walking shoes
- [ ] Sleepwear

### Toiletries
- [ ] Toothbrush + toothpaste
- [ ] Deodorant
- [ ] Shampoo (travel size)
- [ ] Sunscreen
- [ ] Medications
- [ ] First aid kit

### Destination-Specific
- [ ] [Research climate and pack accordingly]
- [ ] [Research dress codes for religious sites]
"""


def generate_day_planning_guide(duration: int) -> str:
    """Generate daily planning tips section."""
    return f"""## 📅 Day Planning Tips

### Maximizing Your Time
1. **Start Early** - Beat crowds and heat
2. **Plan Meals** - Research restaurants ahead
3. **Group by Area** - Minimize backtracking
4. **Build in Buffer** - Leave 30-min per day unplanned
5. **Check Hours** - Verify opening times
6. **Book Ahead** - Popular attractions sell out

### Sample Daily Rhythm
- **Morning:** Major attractions (less crowded)
- **Lunch:** Midday break, local restaurant
- **Afternoon:** Indoor/museum activities (escape heat)
- **Evening:** Dinner, strolls, nightlife

### {duration}-Day Suggested Structure
""" + "\n".join([f"- **Day {i+1}:** [Suggested focus]" for i in range(min(duration, 7))])


def generate_comprehensive_guide(
    destination: str,
    country: str,
    duration: int,
    interests: List[str],
    best_time: str = "Spring or Fall"
) -> Dict[str, Any]:
    """Generate complete travel guide."""
    
    guide = {
        "metadata": generate_guide_metadata(destination, country, duration),
        "overview": generate_overview(destination, country, best_time),
        "transportation": generate_transport_guide(destination, country),
        "food": generate_food_guide(destination, country),
        "cultural_etiquette": generate_cultural_guide(country),
        "safety_health": generate_safety_guide(destination, country),
        "packing": generate_packing_guide(destination, country, duration),
        "day_planning": generate_day_planning_guide(duration)
    }
    
    # Add custom sections based on interests
    if "beach" in interests:
        guide["beach_tips"] = f"""
### 🏖️ Beach Tips for {destination}
- Best beaches: [Research local beaches]
- What to bring: Towel, sunscreen, water
- Beach hours: Typically 8 AM - 6 PM
- Safety: Check flags and lifeguard presence
"""
    
    if "hiking" in interests or "nature" in interests:
        guide["hiking_tips"] = f"""
### 🥾 Hiking & Nature Tips
- Trail conditions: [Research local trails]
- Gear needed: [Research requirements]
- Best times: Early morning or late afternoon
- Safety: Tell someone your plans, bring water
"""
    
    return guide


def export_guide_as_markdown(guide: Dict[str, Any]) -> str:
    """Export guide as formatted markdown."""
    md = "# 🌍 " + guide["metadata"]["destination"] + ", " + guide["metadata"]["country"] + "\n\n"
    md += f"*Generated: {guide['metadata']['created_at']}*\n\n"
    md += "---\n\n"
    
    sections = [
        ("overview", "📍 Overview"),
        ("transportation", "🚇 Transportation"),
        ("food", "🍽️ Food & Dining"),
        ("cultural_etiquette", "🎭 Cultural Etiquette"),
        ("safety_health", "⚠️ Safety & Health"),
        ("packing", "🎒 Packing Guide"),
        ("day_planning", "📅 Day Planning"),
        ("beach_tips", "🏖️ Beach Tips"),
        ("hiking_tips", "🥾 Hiking Tips")
    ]
    
    for section_key, section_title in sections:
        if section_key in guide:
            md += f"## {section_title}\n\n"
            md += guide[section_key]
            md += "\n\n---\n\n"
    
    return md


# CLI Interface
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Travel Guide Generator")
    parser.add_argument("--destination", "-d", required=True, help="Destination city")
    parser.add_argument("--country", "-c", required=True, help="Country")
    parser.add_argument("--days", required=True, type=int, help="Trip duration in days")
    parser.add_argument("--interests", "-i", nargs="+", 
                        default=["sightseeing", "food", "culture"],
                        help="User interests")
    parser.add_argument("--best-time", "-t", default="Spring or Fall",
                        help="Best time to visit")
    parser.add_argument("--output", "-o", help="Output file path")
    
    args = parser.parse_args()
    
    guide = generate_comprehensive_guide(
        destination=args.destination,
        country=args.country,
        duration=args.days,
        interests=args.interests,
        best_time=args.best_time
    )
    
    if args.output:
        content = export_guide_as_markdown(guide)
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✓ Guide saved to: {args.output}")
    else:
        print(export_guide_as_markdown(guide))
