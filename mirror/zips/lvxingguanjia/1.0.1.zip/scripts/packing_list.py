#!/usr/bin/env python3
"""
Travel Butler - Packing List Generator

Generates customized packing lists based on destination,
duration, activities, and weather conditions.
"""

import sys
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
import json

sys.path.insert(0, str(Path(__file__).parent.parent))


# Base checklist items
BASE_CHECKLIST = {
    "documents": [
        {"item": "Passport", "essential": True, "note": "Check 6+ months validity"},
        {"item": "Visa (if required)", "essential": True, "note": "Print copies"},
        {"item": "Travel insurance documents", "essential": True, "note": "Print and save digitally"},
        {"item": "Flight tickets/confirmations", "essential": True, "note": "Save offline copies"},
        {"item": "Hotel reservations", "essential": True, "note": "Confirm addresses"},
        {"item": "Car rental confirmations", "essential": False, "note": "If applicable"},
        {"item": "Tour/activity tickets", "essential": False, "note": "If pre-booked"},
        {"item": "International driving permit", "essential": False, "note": "If renting car"},
        {"item": "Vaccination records", "essential": False, "note": "Some countries require"},
        {"item": "Credit/debit cards", "essential": True, "note": "Notify bank of travel"},
        {"item": "Cash/local currency", "essential": True, "note": "Have small bills"},
        {"item": "Emergency contact list", "essential": True, "note": "Include embassy info"},
        {"item": "Copies of all documents", "essential": True, "note": "Cloud + physical copies"}
    ],
    "electronics": [
        {"item": "Phone", "essential": True, "note": "Charged and unlocked"},
        {"item": "Phone charger", "essential": True, "note": "Plus car charger"},
        {"item": "Power bank", "essential": False, "note": "10,000mAh recommended"},
        {"item": "Universal adapter", "essential": True, "note": "Check outlet types"},
        {"item": "Camera", "essential": False, "note": "If bringing dedicated camera"},
        {"item": "Camera charger/batteries", "essential": False, "note": "Spare batteries"},
        {"item": "Memory cards", "essential": False, "note": "Formatted and ready"},
        {"item": "Headphones", "essential": False, "note": "Noise-canceling recommended"},
        {"item": "Laptop/tablet", "essential": False, "note": "If work required"},
        {"item": "E-reader", "essential": False, "note": "Download books offline"}
    ],
    "toiletries": [
        {"item": "Toothbrush", "essential": True, "note": "Travel brush"},
        {"item": "Toothpaste", "essential": True, "note": "Travel size"},
        {"item": "Deodorant", "essential": True, "note": "Travel size"},
        {"item": "Shampoo", "essential": False, "note": "Solid or travel bottle"},
        {"item": "Conditioner", "essential": False, "note": "Often provided"},
        {"item": "Body wash/soap", "essential": False, "note": "Travel size"},
        {"item": "Face wash", "essential": False, "note": "If specific brand needed"},
        {"item": "Moisturizer", "essential": False, "note": "Climate-appropriate"},
        {"item": "Sunscreen", "essential": True, "note": "SPF 30+ for beach"},
        {"item": "Lip balm with SPF", "essential": False, "note": "Essential for cold/sunny"},
        {"item": " Razor", "essential": False, "note": "Plus spare blades"},
        {"item": " feminine products", "essential": False, "note": "If needed"},
        {"item": "Medications", "essential": True, "note": "Plus doctor's note"},
        {"item": "First aid kit", "essential": False, "note": "Basic supplies"},
        {"item": "Insect repellent", "essential": False, "note": "For tropical destinations"},
        {"item": "Prescription glasses/contacts", "essential": False, "note": "Plus solution"}
    ],
    "clothing_base": [
        {"item": "Underwear", "essential": True, "note": "1 per day + 2 spare"},
        {"item": "Socks", "essential": True, "note": "Comfortable for walking"},
        {"item": "Pajamas", "essential": False, "note": "Comfortable for sleeping"}
    ]
}


# Climate-specific clothing
CLIMATE_CLOTHING = {
    "tropical": {
        "tops": ["Light t-shirts (5-7)", "Tank tops (2-3)", "Light button-up shirt"],
        "bottoms": ["Shorts (3-4)", "Light pants (1-2)"],
        "outerwear": ["Light rain jacket"],
        "footwear": ["Sandals", "Flip-flops", "Water shoes"],
        "special": ["Swimsuit (2)", "Cover-up", "Sun hat"]
    },
    "warm": {
        "tops": ["T-shirts (5-7)", "Light blouses (2-3)"],
        "bottoms": ["Shorts (2-3)", "Light pants (2-3)", "Skirt (1-2)"],
        "outerwear": ["Light cardigan", "Denim jacket"],
        "footwear": ["Comfortable walking shoes", "Sandals", "Casual shoes"],
        "special": ["Swimsuit", "Beach towel", "Sun hat", "Sunglasses"]
    },
    "temperate": {
        "tops": ["T-shirts (4-5)", "Long-sleeve shirts (2-3)", "Light sweaters (2)"],
        "bottoms": ["Pants (3-4)", "Jeans (1-2)", "Skirt/dress (1-2)"],
        "outerwear": ["Light jacket", "Rain jacket", "Medium sweater"],
        "footwear": ["Comfortable walking shoes", "Casual shoes", "Light boots"],
        "special": ["Small umbrella", "Light scarf"]
    },
    "cold": {
        "tops": ["Thermal underlayers (3-4)", "Sweaters (3-4)", "Long-sleeve shirts (4-5)"],
        "bottoms": ["Warm pants (3-4)", "Jeans (2-3)", "Thermal underwear (2-3)"],
        "outerwear": ["Heavy winter coat", "Down jacket", "Waterproof shell"],
        "footwear": ["Winter boots", "Warm socks (multiple)", "Indoor shoes"],
        "special": ["Wool hat", "Gloves", "Scarf", "Hand warmers"]
    },
    "desert": {
        "tops": ["Light long-sleeve shirts (3-4)", "T-shirts (3-4)", "Lightweight fabrics"],
        "bottoms": ["Light pants (3-4)", "Shorts (1-2)"],
        "outerwear": ["Light jacket for evenings"],
        "footwear": ["Closed-toe shoes", "Sandals for beach"],
        "special": ["Sun hat", "Sunglasses", "Neck gaiter/scarf", "Lightweight robes for modesty"]
    }
}


# Activity-specific items
ACTIVITY_ITEMS = {
    "hiking": ["Hiking boots", "Hiking socks", "Backpack/daypack", "Water bottle", "Trail snacks", "Trekking poles", "First aid kit", "Map/GPS"],
    "beach": ["Swimsuit", "Beach towel", "Snorkel gear", "Waterproof bag", "Beach chair", "Beach umbrella", "Waterproof phone case"],
    "diving": ["Swimsuit", "Rash guard", "Towel", "Sea sickness pills", "Underwater camera", "Certification card"],
    "skiing": ["Ski jacket", "Ski pants", "Thermal layers", "Ski socks", "Gloves", "Goggles", "Helmet", "Hand/feet warmers"],
    "business": ["Business suits (1-2)", "Dress shirts (3-4)", "Dress shoes", "Ties/accessories", "Laptop", "Business cards", "Portfolio"],
    "photography": ["Camera body", "Lenses", "Tripod", "Memory cards", "Cleaning kit", "Camera bag", "Extra batteries", "Filters"],
    "camping": ["Tent", "Sleeping bag", "Sleeping pad", "Camp stove", "Flashlight/headlamp", "Multi-tool", "Fire starter", "Cooler"],
    "wellness": ["Yoga mat", "Comfortable clothes", "Reusable water bottle", "Healthy snacks", "Journal", "Meditation cushion"]
}


def get_climate_category(temperature: str, destination: str = "") -> str:
    """Determine climate category from temperature."""
    try:
        temps = temperature.replace("°C", "").replace("°F", "").replace("C", "").split("-")
        avg_temp = sum(int(t.replace("+", "")) for t in temps) / len(temps)
        
        # Convert F to C if needed
        if "°F" in temperature:
            avg_temp = (avg_temp - 32) * 5/9
    except:
        avg_temp = 20  # Default temperate
    
    if avg_temp > 28:
        return "tropical"
    elif avg_temp > 22:
        return "warm"
    elif avg_temp > 10:
        return "temperate"
    elif avg_temp > 0:
        return "cold"
    else:
        return "cold"


def generate_packing_list(
    destination: str,
    country: str,
    duration_days: int,
    activities: List[str],
    climate: str = "warm",
    special_needs: Optional[List[str]] = None
) -> Dict[str, Any]:
    """Generate comprehensive packing list."""
    
    if special_needs is None:
        special_needs = []
    
    # Determine clothing quantities based on duration
    underwear_count = duration_days + 2
    tops_count = min(duration_days, 7)
    
    checklist = {
        "destination": destination,
        "country": country,
        "duration": duration_days,
        "activities": activities,
        "categories": {}
    }
    
    # Documents
    checklist["categories"]["📄 Documents"] = BASE_CHECKLIST["documents"]
    
    # Electronics
    checklist["categories"]["🔌 Electronics"] = BASE_CHECKLIST["electronics"]
    
    # Toiletries
    toiletries = list(BASE_CHECKLIST["toiletries"])
    # Add climate-specific toiletries
    if climate in ["tropical", "desert"]:
        toiletries.append({"item": "Strong sunscreen (SPF 50+)", "essential": True, "note": "Reef-safe if beach"})
        toiletries.append({"item": "After-sun lotion", "essential": False, "note": "For sunburn relief"})
    if climate == "cold":
        toiletries.append({"item": "Lip balm", "essential": True, "note": "Moisturizing"})
        toiletries.append({"item": "Hand cream", "essential": False, "note": "Prevent dryness"})
    checklist["categories"]["🧴 Toiletries"] = toiletries
    
    # Clothing - base
    clothing = []
    clothing.append({"item": f"Underwear ({underwear_count} pairs)", "essential": True, "note": ""})
    clothing.append({"item": f"Socks ({underwear_count} pairs)", "essential": True, "note": "Merino wool recommended"})
    clothing.append({"item": "Pajamas", "essential": False, "note": "Comfortable"})
    
    # Add climate-specific clothing
    climate_data = CLIMATE_CLOTHING.get(climate, CLIMATE_CLOTHING["warm"])
    
    for item in climate_data.get("tops", []):
        clothing.append({"item": item, "essential": True, "note": ""})
    
    for item in climate_data.get("bottoms", []):
        clothing.append({"item": item, "essential": True, "note": ""})
    
    for item in climate_data.get("outerwear", []):
        clothing.append({"item": item, "essential": True, "note": ""})
    
    for item in climate_data.get("footwear", []):
        clothing.append({"item": item, "essential": True, "note": ""})
    
    for item in climate_data.get("special", []):
        clothing.append({"item": item, "essential": False, "note": ""})
    
    checklist["categories"]["👕 Clothing"] = clothing
    
    # Activity-specific items
    for activity in activities:
        activity_lower = activity.lower()
        activity_items = []
        
        for act_key, items in ACTIVITY_ITEMS.items():
            if act_key in activity_lower or activity_lower in act_key:
                for item in items:
                    activity_items.append({"item": item, "essential": True, "note": f"For {activity}"})
        
        if activity_items:
            activity_display = activity.capitalize()
            checklist["categories"][f"🏃 {activity_display} Gear"] = activity_items
    
    # Special needs
    if special_needs:
        special_items = []
        for need in special_needs:
            if "vegetarian" in need.lower():
                special_items.append({"item": "Snack bars (vegetarian)", "essential": False, "note": "Emergency food"})
            elif "vegan" in need.lower():
                special_items.append({"item": "Snack bars (vegan)", "essential": False, "note": "Emergency food"})
            elif "allergy" in need.lower():
                special_items.append({"item": "Allergy medication", "essential": True, "note": "Plus doctor's note"})
                special_items.append({"item": "EpiPen (if severe)", "essential": True, "note": "Carry on person"})
            elif "religious" in need.lower():
                special_items.append({"item": "Modest clothing items", "essential": True, "note": "For religious sites"})
        
        if special_items:
            checklist["categories"]["⚕️ Special Needs"] = special_items
    
    # Calculate totals
    total_items = sum(len(items) for items in checklist["categories"].values())
    essential_count = sum(
        1 for items in checklist["categories"].values() 
        for item in items if item.get("essential", False)
    )
    
    checklist["summary"] = {
        "total_items": total_items,
        "essential_items": essential_count,
        "optional_items": total_items - essential_count,
        "generated_at": datetime.now().isoformat()
    }
    
    return checklist


def format_checklist_as_markdown(checklist: Dict[str, Any]) -> str:
    """Format packing list as markdown."""
    md = f"# 🎒 Packing List: {checklist['destination']}, {checklist['country']}\n\n"
    md += f"**Duration:** {checklist['duration']} days\n"
    md += f"**Activities:** {', '.join(checklist['activities'])}\n\n"
    
    md += f"**Total Items:** {checklist['summary']['total_items']} "
    md += f"(Essential: {checklist['summary']['essential_items']}, "
    md += f"Optional: {checklist['summary']['optional_items']})\n\n"
    
    md += "---\n\n"
    
    for category, items in checklist["categories"].items():
        md += f"## {category}\n\n"
        for item in items:
            essential_marker = "⚠️" if item.get("essential", False) else "○"
            note = f" - *{item['note']}*" if item.get("note") else ""
            md += f"- [{essential_marker}] {item['item']}{note}\n"
        md += "\n"
    
    md += "---\n\n"
    md += f"*Generated: {checklist['summary']['generated_at']}*\n"
    
    return md


def export_checklist_to_json(checklist: Dict[str, Any], filepath: str) -> None:
    """Export checklist to JSON file."""
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(checklist, f, indent=2, ensure_ascii=False)
    print(f"✓ Checklist exported to: {filepath}")


# CLI Interface
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Packing List Generator")
    parser.add_argument("--destination", "-d", required=True, help="Destination")
    parser.add_argument("--country", "-c", required=True, help="Country")
    parser.add_argument("--days", type=int, required=True, help="Trip duration")
    parser.add_argument("--activities", "-a", nargs="+", 
                        default=["sightseeing", "dining"],
                        help="Planned activities")
    parser.add_argument("--climate", "-cl", choices=["tropical", "warm", "temperate", "cold", "desert"],
                        default="warm", help="Climate type")
    parser.add_argument("--special", "-s", nargs="+", help="Special needs")
    parser.add_argument("--output", "-o", help="Output file path")
    
    args = parser.parse_args()
    
    checklist = generate_packing_list(
        destination=args.destination,
        country=args.country,
        duration_days=args.days,
        activities=args.activities,
        climate=args.climate,
        special_needs=args.special
    )
    
    if args.output:
        if args.output.endswith('.json'):
            export_checklist_to_json(checklist, args.output)
        else:
            content = format_checklist_as_markdown(checklist)
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✓ Checklist saved to: {args.output}")
    else:
        print(format_checklist_as_markdown(checklist))
