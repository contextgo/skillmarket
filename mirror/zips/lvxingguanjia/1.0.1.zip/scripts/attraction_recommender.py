#!/usr/bin/env python3
"""
Travel Butler - Attraction Recommender

Recommends attractions and points of interest based on destination,
preferences, and travel style.
"""

import sys
from pathlib import Path
from typing import Dict, Any, List, Optional
import json

sys.path.insert(0, str(Path(__file__).parent.parent))


# Attraction categories with metadata
ATTRACTION_CATEGORIES = {
    "landmarks": {
        "icon": "🏛️",
        "typical_duration": "1-2 hours",
        "cost_range": "$0-50",
        "description": "Iconic buildings and architectural marvels"
    },
    "museums": {
        "icon": "🏺",
        "typical_duration": "2-4 hours",
        "cost_range": "$10-30",
        "description": "Art, history, and cultural exhibitions"
    },
    "nature": {
        "icon": "🌲",
        "typical_duration": "3-6 hours",
        "cost_range": "$0-25",
        "description": "Parks, gardens, and natural wonders"
    },
    "beaches": {
        "icon": "🏖️",
        "typical_duration": "Half to full day",
        "cost_range": "$0-10",
        "description": "Coastal spots for relaxation and water activities"
    },
    "markets": {
        "icon": "🛒",
        "typical_duration": "1-3 hours",
        "cost_range": "$ varies",
        "description": "Local markets for shopping and food experiences"
    },
    "food_districts": {
        "icon": "🍜",
        "typical_duration": "2-4 hours",
        "cost_range": "$20-80",
        "description": "Culinary destinations and food experiences"
    },
    "nightlife": {
        "icon": "🌙",
        "typical_duration": "Evening",
        "cost_range": "$20-100",
        "description": "Bars, clubs, and evening entertainment"
    },
    "religious": {
        "icon": "⛪",
        "typical_duration": "1-2 hours",
        "cost_range": "$0-10",
        "description": "Temples, churches, mosques, and spiritual sites"
    },
    " viewpoints": {
        "icon": "🌅",
        "typical_duration": "30 min - 1 hour",
        "cost_range": "$0-20",
        "description": "Scenic overlooks and photo spots"
    },
    "entertainment": {
        "icon": "🎭",
        "typical_duration": "2-3 hours",
        "cost_range": "$30-150",
        "description": "Shows, performances, and attractions"
    }
}


def get_default_attractions(destination: str, country: str) -> List[Dict[str, Any]]:
    """Get default attraction list for a destination."""
    # This would typically be loaded from a database or API
    # Returning a template structure that can be customized
    return [
        {
            "name": f"Historic {destination} Old Town",
            "category": "landmarks",
            "rating": 4.5,
            "reviews": 10000,
            "duration": "2-3 hours",
            "cost": "$0-15",
            "highlights": ["Architecture", "Street photography", "Local culture"],
            "tips": "Best visited in morning to avoid crowds"
        },
        {
            "name": f"{destination} National Museum",
            "category": "museums",
            "rating": 4.7,
            "reviews": 5000,
            "duration": "2-4 hours",
            "cost": "$10-25",
            "highlights": ["History", "Artifacts", "Guided tours"],
            "tips": "Free on first Sunday of month"
        },
        {
            "name": f"{destination} Central Park/Garden",
            "category": "nature",
            "rating": 4.6,
            "reviews": 8000,
            "duration": "2-4 hours",
            "cost": "$0-5",
            "highlights": ["Walking", "Picnic spots", "Scenery"],
            "tips": "Rent a rowboat for extra fun"
        },
        {
            "name": "Local Food Market",
            "category": "markets",
            "rating": 4.4,
            "reviews": 6000,
            "duration": "1-2 hours",
            "cost": "$10-40",
            "highlights": ["Street food", "Local produce", "Atmosphere"],
            "tips": "Go hungry and try everything"
        },
        {
            "name": f"Traditional {country} Restaurant Row",
            "category": "food_districts",
            "rating": 4.5,
            "reviews": 4000,
            "duration": "2-3 hours",
            "cost": "$25-60",
            "highlights": ["Local cuisine", "Traditional dishes", "Cultural experience"],
            "tips": "Ask locals for recommendations"
        }
    ]


def score_attraction(
    attraction: Dict[str, Any],
    user_interests: List[str],
    budget: Optional[str] = None,
    time_available: Optional[int] = None
) -> float:
    """Score an attraction based on user preferences."""
    score = 0.0
    
    # Category match
    category = attraction.get("category", "")
    for interest in user_interests:
        if interest.lower() in category.lower() or category.lower() in interest.lower():
            score += 5.0
            break
    
    # Rating contribution
    rating = attraction.get("rating", 4.0)
    score += rating
    
    # Review count (popularity)
    reviews = attraction.get("reviews", 0)
    if reviews > 10000:
        score += 1.0
    elif reviews > 5000:
        score += 0.5
    
    # Time constraint
    if time_available:
        duration = attraction.get("duration", "2 hours")
        # Simple parsing - could be enhanced
        try:
            hours = int(duration.split()[0])
            if hours <= time_available:
                score += 1.0
        except:
            pass
    
    return score


def recommend_attractions(
    destination: str,
    country: str,
    interests: List[str],
    num_recommendations: int = 10,
    budget: Optional[str] = None,
    time_available: Optional[int] = None,
    exclude_visited: Optional[List[str]] = None
) -> Dict[str, Any]:
    """Generate personalized attraction recommendations."""
    
    if exclude_visited is None:
        exclude_visited = []
    
    # Get base attractions
    attractions = get_default_attractions(destination, country)
    
    # Score and sort
    scored_attractions = []
    for attraction in attractions:
        if attraction["name"] not in exclude_visited:
            score = score_attraction(attraction, interests, budget, time_available)
            attraction["relevance_score"] = round(score, 2)
            scored_attractions.append(attraction)
    
    # Sort by score
    scored_attractions.sort(key=lambda x: x["relevance_score"], reverse=True)
    
    # Take top recommendations
    top_recommendations = scored_attractions[:num_recommendations]
    
    # Categorize recommendations
    by_category = {}
    for attraction in top_recommendations:
        category = attraction["category"]
        if category not in by_category:
            by_category[category] = []
        by_category[category].append(attraction)
    
    # Generate must-see list (top 3)
    must_see = [a["name"] for a in top_recommendations[:3]]
    
    # Generate hidden gems (lower scored but still good)
    hidden_gems = [
        a for a in scored_attractions 
        if a["relevance_score"] < 7.0 and a["relevance_score"] >= 5.0
    ][:3]
    
    return {
        "destination": destination,
        "country": country,
        "user_interests": interests,
        "total_found": len(scored_attractions),
        "recommendations": top_recommendations,
        "by_category": by_category,
        "must_see": must_see,
        "hidden_gems": hidden_gems,
        "generated_at": __import__('datetime').datetime.now().isoformat()
    }


def format_recommendations_as_markdown(recommendations: Dict[str, Any]) -> str:
    """Format recommendations as readable markdown."""
    md = f"# 🗺️ {recommendations['destination']}, {recommendations['country']}\n\n"
    md += f"**Based on your interests:** {', '.join(recommendations['user_interests'])}\n\n"
    
    md += "---\n\n"
    
    md += "## ⭐ Must-See Attractions\n\n"
    for i, name in enumerate(recommendations['must_see'], 1):
        md += f"{i}. **{name}**\n"
    md += "\n"
    
    md += "---\n\n"
    
    md += "## 📍 All Recommendations\n\n"
    for attraction in recommendations['recommendations']:
        category = attraction['category']
        cat_info = ATTRACTION_CATEGORIES.get(category, {})
        icon = cat_info.get('icon', '📍')
        
        md += f"### {icon} {attraction['name']}\n\n"
        md += f"- **Category:** {category.capitalize()}\n"
        md += f"- **Rating:** ⭐ {attraction['rating']} ({attraction['reviews']:,} reviews)\n"
        md += f"- **Duration:** {attraction['duration']}\n"
        md += f"- **Cost:** {attraction['cost']}\n"
        md += f"- **Relevance Score:** {attraction['relevance_score']}/10\n"
        md += f"- **Highlights:** {', '.join(attraction['highlights'])}\n"
        md += f"- **Tips:** {attraction['tips']}\n\n"
    
    if recommendations.get('hidden_gems'):
        md += "---\n\n"
        md += "## 💎 Hidden Gems\n\n"
        for gem in recommendations['hidden_gems']:
            md += f"- **{gem['name']}** - {gem['tips']}\n"
        md += "\n"
    
    return md


def export_attractions_to_json(recommendations: Dict[str, Any], filepath: str) -> None:
    """Export recommendations to JSON file."""
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(recommendations, f, indent=2, ensure_ascii=False)
    print(f"✓ Attractions exported to: {filepath}")


# CLI Interface
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Attraction Recommender")
    parser.add_argument("--destination", "-d", required=True, help="Destination")
    parser.add_argument("--country", "-c", required=True, help="Country")
    parser.add_argument("--interests", "-i", nargs="+", 
                        default=["sightseeing", "food", "culture"],
                        help="User interests")
    parser.add_argument("--num", "-n", type=int, default=10,
                        help="Number of recommendations")
    parser.add_argument("--output", "-o", help="Output file path")
    parser.add_argument("--format", "-f", choices=["json", "markdown"], default="markdown",
                        help="Output format")
    
    args = parser.parse_args()
    
    recommendations = recommend_attractions(
        destination=args.destination,
        country=args.country,
        interests=args.interests,
        num_recommendations=args.num
    )
    
    if args.output:
        if args.format == "json":
            export_attractions_to_json(recommendations, args.output)
        else:
            content = format_recommendations_as_markdown(recommendations)
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✓ Attractions exported to: {args.output}")
    else:
        print(format_recommendations_as_markdown(recommendations))
