#!/usr/bin/env python3
"""
Travel Butler - Budget Calculator

Comprehensive travel budget planning and expense tracking.
"""

import sys
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import json

sys.path.insert(0, str(Path(__file__).parent.parent))


# Budget allocation templates by travel style
BUDGET_TEMPLATES = {
    "budget": {
        "accommodation": 0.30,
        "food": 0.25,
        "transportation": 0.20,
        "activities": 0.15,
        "shopping": 0.05,
        "miscellaneous": 0.05
    },
    "mid-range": {
        "accommodation": 0.35,
        "food": 0.25,
        "transportation": 0.15,
        "activities": 0.15,
        "shopping": 0.05,
        "miscellaneous": 0.05
    },
    "luxury": {
        "accommodation": 0.45,
        "food": 0.20,
        "transportation": 0.15,
        "activities": 0.10,
        "shopping": 0.05,
        "miscellaneous": 0.05
    }
}

# Daily cost estimates by region (per person)
REGIONAL_COSTS = {
    "Southeast Asia": {"budget": 30, "mid-range": 60, "luxury": 150},
    "East Asia": {"budget": 50, "mid-range": 100, "luxury": 250},
    "Europe": {"budget": 80, "mid-range": 150, "luxury": 350},
    "North America": {"budget": 100, "mid-range": 200, "luxury": 400},
    "South America": {"budget": 40, "mid-range": 80, "luxury": 180},
    "Africa": {"budget": 45, "mid-range": 90, "luxury": 200},
    "Middle East": {"budget": 60, "mid-range": 120, "luxury": 280},
    "Oceania": {"budget": 90, "mid-range": 180, "luxury": 350},
    "Central Asia": {"budget": 35, "mid-range": 70, "luxury": 160}
}

# Currency exchange rates (base: USD)
EXCHANGE_RATES = {
    "USD": 1.0,
    "EUR": 0.92,
    "GBP": 0.79,
    "JPY": 149.50,
    "CNY": 7.24,
    "KRW": 1340.50,
    "THB": 35.80,
    "INR": 83.20,
    "AUD": 1.53,
    "CAD": 1.36,
    "SGD": 1.34,
    "MXN": 17.15,
    "BRL": 4.97,
    "ZAR": 18.90,
    "AED": 3.67
}


def get_regional_costs(region: str) -> Dict[str, int]:
    """Get daily cost estimates for a region."""
    return REGIONAL_COSTS.get(region, REGIONAL_COSTS["Europe"])


def calculate_budget_breakdown(
    total_budget: float,
    duration_days: int,
    travel_style: str = "mid-range",
    num_travelers: int = 1,
    currency: str = "USD"
) -> Dict[str, Any]:
    """Calculate detailed budget breakdown."""
    
    if travel_style not in BUDGET_TEMPLATES:
        travel_style = "mid-range"
    
    allocation = BUDGET_TEMPLATES[travel_style]
    daily_budget = total_budget / duration_days if duration_days > 0 else 0
    
    breakdown = {}
    for category, percentage in allocation.items():
        amount = total_budget * percentage
        per_day = amount / duration_days if duration_days > 0 else 0
        per_person = amount / num_travelers if num_travelers > 0 else 0
        
        breakdown[category] = {
            "amount": round(amount, 2),
            "percentage": round(percentage * 100, 1),
            "per_day": round(per_day, 2),
            "per_person": round(per_person, 2),
            "currency": currency
        }
    
    return {
        "total_budget": total_budget,
        "duration_days": duration_days,
        "num_travelers": num_travelers,
        "travel_style": travel_style,
        "daily_budget": round(daily_budget, 2),
        "per_person_total": round(total_budget / num_travelers, 2) if num_travelers > 0 else 0,
        "breakdown": breakdown,
        "currency": currency,
        "generated_at": datetime.now().isoformat()
    }


def estimate_trip_cost(
    destination: str,
    region: str,
    duration_days: int,
    travel_style: str = "mid-range",
    num_travelers: int = 1
) -> Dict[str, Any]:
    """Estimate total trip cost based on destination and style."""
    
    regional_costs = get_regional_costs(region)
    daily_cost = regional_costs.get(travel_style, regional_costs["mid-range"])
    
    total_per_person = daily_cost * duration_days
    
    # Flights estimate (rough)
    flight_estimate = estimate_flights(destination)
    
    # Accommodation estimate
    accommodation_daily = {
        "budget": 15,
        "mid-range": 50,
        "luxury": 150
    }
    accommodation_total = accommodation_daily.get(travel_style, 50) * duration_days
    
    # Total estimate
    total_estimate = total_per_person + flight_estimate + accommodation_total
    
    return {
        "destination": destination,
        "region": region,
        "duration_days": duration_days,
        "travel_style": travel_style,
        "estimates": {
            "flights": {
                "amount": flight_estimate,
                "currency": "USD",
                "note": "Estimated round-trip"
            },
            "daily_costs": {
                "amount": daily_cost,
                "currency": "USD",
                "note": f"Per person per day ({travel_style})"
            },
            "accommodation": {
                "amount": accommodation_total,
                "currency": "USD",
                "note": f"{duration_days} nights"
            },
            "total_per_person": {
                "amount": round(total_estimate, 2),
                "currency": "USD",
                "note": "Including flights"
            },
            "total_for_group": {
                "amount": round(total_estimate * num_travelers, 2),
                "currency": "USD",
                "note": f"{num_travelers} travelers"
            }
        },
        "daily_cost_breakdown": regional_costs,
        "generated_at": datetime.now().isoformat()
    }


def estimate_flights(destination: str) -> float:
    """Rough estimate of flight costs based on destination region."""
    # This is a simplified estimation
    # In production, would integrate with flight API
    flight_estimates = {
        "Europe": 800,
        "Asia": 1000,
        "North America": 400,
        "South America": 600,
        "Africa": 900,
        "Oceania": 1200,
        "Middle East": 850
    }
    
    for region, cost in flight_estimates.items():
        if region.lower() in destination.lower():
            return cost
    
    return 800  # Default estimate


def convert_currency(amount: float, from_currency: str, to_currency: str) -> Dict[str, Any]:
    """Convert amount between currencies."""
    if from_currency not in EXCHANGE_RATES or to_currency not in EXCHANGE_RATES:
        return {"error": "Currency not supported"}
    
    # Convert to USD first, then to target
    usd_amount = amount / EXCHANGE_RATES[from_currency]
    converted = usd_amount * EXCHANGE_RATES[to_currency]
    
    return {
        "original": {
            "amount": amount,
            "currency": from_currency
        },
        "converted": {
            "amount": round(converted, 2),
            "currency": to_currency
        },
        "rate": round(EXCHANGE_RATES[to_currency] / EXCHANGE_RATES[from_currency], 4)
    }


def track_expenses(
    expenses: List[Dict[str, Any]],
    budget_breakdown: Dict[str, Any]
) -> Dict[str, Any]:
    """Track and compare expenses against budget."""
    
    if not expenses:
        return {"error": "No expenses provided"}
    
    # Categorize expenses
    by_category = {}
    total_spent = 0
    
    for expense in expenses:
        category = expense.get("category", "miscellaneous")
        amount = expense.get("amount", 0)
        
        if category not in by_category:
            by_category[category] = []
        by_category[category].append(expense)
        total_spent += amount
    
    # Calculate category totals
    category_totals = {}
    for category, items in by_category.items():
        category_totals[category] = sum(item.get("amount", 0) for item in items)
    
    # Compare with budget
    breakdown = budget_breakdown.get("breakdown", {})
    comparison = {}
    
    for category, total in category_totals.items():
        budgeted = breakdown.get(category, {}).get("amount", 0)
        remaining = budgeted - total
        
        comparison[category] = {
            "spent": round(total, 2),
            "budgeted": round(budgeted, 2),
            "remaining": round(remaining, 2),
            "status": "over" if remaining < 0 else ("on_track" if remaining > budgeted * 0.5 else "ok")
        }
    
    total_budget = budget_breakdown.get("total_budget", 0)
    percentage_used = (total_spent / total_budget * 100) if total_budget > 0 else 0
    
    return {
        "total_spent": round(total_spent, 2),
        "total_budget": total_budget,
        "remaining": round(total_budget - total_spent, 2),
        "percentage_used": round(percentage_used, 1),
        "by_category": category_totals,
        "budget_comparison": comparison,
        "expense_count": len(expenses),
        "generated_at": datetime.now().isoformat()
    }


def format_budget_as_markdown(budget: Dict[str, Any]) -> str:
    """Format budget breakdown as markdown."""
    md = f"# 💰 Travel Budget Breakdown\n\n"
    md += f"**Total Budget:** {budget['currency']} {budget['total_budget']:,.2f}\n"
    md += f"**Duration:** {budget['duration_days']} days\n"
    md += f"**Travelers:** {budget['num_travelers']}\n"
    md += f"**Style:** {budget['travel_style'].capitalize()}\n\n"
    
    md += f"**Daily Budget:** {budget['currency']} {budget['daily_budget']:,.2f}\n"
    md += f"**Per Person Total:** {budget['currency']} {budget['per_person_total']:,.2f}\n\n"
    
    md += "---\n\n"
    md += "## 📊 Budget Allocation\n\n"
    md += "| Category | Amount | Daily | % | Status |\n"
    md += "|----------|--------|-------|---|--------|\n"
    
    breakdown = budget.get("breakdown", {})
    for category, data in breakdown.items():
        cat_icon = {
            "accommodation": "🏨",
            "food": "🍽️",
            "transportation": "✈️",
            "activities": "🎫",
            "shopping": "🛍️",
            "miscellaneous": "📝"
        }.get(category, "•")
        
        md += f"| {cat_icon} {category.capitalize()} | {data['currency']} {data['amount']:,.2f} | "
        md += f"{data['currency']} {data['per_day']:,.2f} | {data['percentage']}% | "
        md += f"{'✅' if data['percentage'] > 5 else '⚠️'} |\n"
    
    md += "\n"
    
    return md


def format_expense_report(tracking: Dict[str, Any]) -> str:
    """Format expense tracking report as markdown."""
    md = f"# 📝 Expense Report\n\n"
    md += f"**Total Spent:** ${tracking['total_spent']:,.2f}\n"
    md += f"**Budget:** ${tracking['total_budget']:,.2f}\n"
    md += f"**Remaining:** ${tracking['remaining']:,.2f}\n"
    md += f"**Usage:** {tracking['percentage_used']}%\n\n"
    
    md += "---\n\n"
    md += "## 📈 Category Breakdown\n\n"
    
    comparison = tracking.get("budget_comparison", {})
    for category, data in comparison.items():
        status_icon = {"over": "🔴", "ok": "🟡", "on_track": "🟢"}.get(data["status"], "⚪")
        md += f"### {category.capitalize()} {status_icon}\n\n"
        md += f"- **Spent:** ${data['spent']:,.2f}\n"
        md += f"- **Budgeted:** ${data['budgeted']:,.2f}\n"
        md += f"- **Remaining:** ${data['remaining']:,.2f}\n\n"
    
    return md


# CLI Interface
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Travel Budget Calculator")
    parser.add_argument("--budget", "-b", type=float, help="Total budget")
    parser.add_argument("--days", "-d", type=int, required=True, help="Number of days")
    parser.add_argument("--style", "-s", choices=["budget", "mid-range", "luxury"],
                        default="mid-range", help="Travel style")
    parser.add_argument("--travelers", "-t", type=int, default=1, help="Number of travelers")
    parser.add_argument("--currency", "-c", default="USD", help="Currency code")
    parser.add_argument("--estimate", "-e", help="Estimate for destination,region")
    parser.add_argument("--output", "-o", help="Output file path")
    
    args = parser.parse_args()
    
    if args.estimate:
        dest, region = args.estimate.split(",")
        result = estimate_trip_cost(
            destination=dest.strip(),
            region=region.strip(),
            duration_days=args.days,
            travel_style=args.style,
            num_travelers=args.travelers
        )
    elif args.budget:
        result = calculate_budget_breakdown(
            total_budget=args.budget,
            duration_days=args.days,
            travel_style=args.style,
            num_travelers=args.travelers,
            currency=args.currency
        )
        result = format_budget_as_markdown(result)
    else:
        result = {"error": "Please provide --budget or --estimate"}
    
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(str(result))
        print(f"✓ Budget saved to: {args.output}")
    else:
        print(result)
