#!/usr/bin/env python3
"""
Travel Butler - Currency Converter

Converts between currencies and provides exchange rate information
for travel budgeting.
"""

import sys
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
import json

sys.path.insert(0, str(Path(__file__).parent.parent))


# Major world currencies with metadata
CURRENCIES = {
    "USD": {"name": "US Dollar", "symbol": "$", "regions": ["United States"]},
    "EUR": {"name": "Euro", "symbol": "€", "regions": ["Eurozone", "Germany", "France", "Italy", "Spain"]},
    "GBP": {"name": "British Pound", "symbol": "£", "regions": ["United Kingdom"]},
    "JPY": {"name": "Japanese Yen", "symbol": "¥", "regions": ["Japan"]},
    "CNY": {"name": "Chinese Yuan", "symbol": "¥", "regions": ["China"]},
    "KRW": {"name": "South Korean Won", "symbol": "₩", "regions": ["South Korea"]},
    "THB": {"name": "Thai Baht", "symbol": "฿", "regions": ["Thailand"]},
    "VND": {"name": "Vietnamese Dong", "symbol": "₫", "regions": ["Vietnam"]},
    "INR": {"name": "Indian Rupee", "symbol": "₹", "regions": ["India"]},
    "AUD": {"name": "Australian Dollar", "symbol": "A$", "regions": ["Australia"]},
    "NZD": {"name": "New Zealand Dollar", "symbol": "NZ$", "regions": ["New Zealand"]},
    "CAD": {"name": "Canadian Dollar", "symbol": "C$", "regions": ["Canada"]},
    "SGD": {"name": "Singapore Dollar", "symbol": "S$", "regions": ["Singapore"]},
    "HKD": {"name": "Hong Kong Dollar", "symbol": "HK$", "regions": ["Hong Kong"]},
    "TWD": {"name": "Taiwan Dollar", "symbol": "NT$", "regions": ["Taiwan"]},
    "MYR": {"name": "Malaysian Ringgit", "symbol": "RM", "regions": ["Malaysia"]},
    "PHP": {"name": "Philippine Peso", "symbol": "₱", "regions": ["Philippines"]},
    "IDR": {"name": "Indonesian Rupiah", "symbol": "Rp", "regions": ["Indonesia"]},
    "MXN": {"name": "Mexican Peso", "symbol": "$", "regions": ["Mexico"]},
    "BRL": {"name": "Brazilian Real", "symbol": "R$", "regions": ["Brazil"]},
    "ZAR": {"name": "South African Rand", "symbol": "R", "regions": ["South Africa"]},
    "AED": {"name": "UAE Dirham", "symbol": "د.إ", "regions": ["UAE", "Dubai"]},
    "SAR": {"name": "Saudi Riyal", "symbol": "﷼", "regions": ["Saudi Arabia"]},
    "TRY": {"name": "Turkish Lira", "symbol": "₺", "regions": ["Turkey"]},
    "CHF": {"name": "Swiss Franc", "symbol": "CHF", "regions": ["Switzerland"]},
    "SEK": {"name": "Swedish Krona", "symbol": "kr", "regions": ["Sweden"]},
    "NOK": {"name": "Norwegian Krone", "symbol": "kr", "regions": ["Norway"]},
    "DKK": {"name": "Danish Krone", "symbol": "kr", "regions": ["Denmark"]},
    "PLN": {"name": "Polish Zloty", "symbol": "zł", "regions": ["Poland"]},
    "CZK": {"name": "Czech Koruna", "symbol": "Kč", "regions": ["Czech Republic"]},
    "HUF": {"name": "Hungarian Forint", "symbol": "Ft", "regions": ["Hungary"]},
    "RUB": {"name": "Russian Ruble", "symbol": "₽", "regions": ["Russia"]},
    "GBP": {"name": "British Pound", "symbol": "£", "regions": ["UK", "Ireland"]}
}

# Approximate exchange rates (USD base - for estimation)
# In production, would use live API
EXCHANGE_RATES_TO_USD = {
    "USD": 1.0,
    "EUR": 0.92,
    "GBP": 0.79,
    "JPY": 149.50,
    "CNY": 7.24,
    "KRW": 1340.50,
    "THB": 35.80,
    "VND": 24500.0,
    "INR": 83.20,
    "AUD": 1.53,
    "NZD": 1.63,
    "CAD": 1.36,
    "SGD": 1.34,
    "HKD": 7.82,
    "TWD": 31.50,
    "MYR": 4.72,
    "PHP": 56.20,
    "IDR": 15650.0,
    "MXN": 17.15,
    "BRL": 4.97,
    "ZAR": 18.90,
    "AED": 3.67,
    "SAR": 3.75,
    "TRY": 32.10,
    "CHF": 0.91,
    "SEK": 10.45,
    "NOK": 10.65,
    "DKK": 6.88,
    "PLN": 4.02,
    "CZK": 23.15,
    "HUF": 355.0,
    "RUB": 92.50
}

# Common cost items in different currencies
COST_BENCHMARKS = {
    "budget_meal": {"USD": 10, "EUR": 12, "THB": 150, "JPY": 1000, "MXN": 100},
    "mid_meal": {"USD": 25, "EUR": 30, "THB": 400, "JPY": 2500, "MXN": 250},
    "luxury_meal": {"USD": 75, "EUR": 85, "THB": 1200, "JPY": 8000, "MXN": 800},
    "hostel": {"USD": 20, "EUR": 22, "THB": 400, "JPY": 3000, "MXN": 200},
    "mid_hotel": {"USD": 80, "EUR": 90, "THB": 1500, "JPY": 12000, "MXN": 800},
    "luxury_hotel": {"USD": 250, "EUR": 280, "THB": 5000, "JPY": 40000, "MXN": 2500},
    "local_transit": {"USD": 2, "EUR": 2.5, "THB": 25, "JPY": 200, "MXN": 15},
    "museum": {"USD": 15, "EUR": 15, "THB": 200, "JPY": 1500, "MXN": 100}
}


def get_currency_info(currency_code: str) -> Optional[Dict[str, Any]]:
    """Get currency metadata."""
    return CURRENCIES.get(currency_code.upper())


def get_exchange_rate(from_currency: str, to_currency: str) -> float:
    """Calculate exchange rate between two currencies."""
    from_upper = from_currency.upper()
    to_upper = to_currency.upper()
    
    if from_upper not in EXCHANGE_RATES_TO_USD or to_upper not in EXCHANGE_RATES_TO_USD:
        return 0.0
    
    # Convert from source to USD, then to target
    from_rate = EXCHANGE_RATES_TO_USD[from_upper]
    to_rate = EXCHANGE_RATES_TO_USD[to_upper]
    
    return to_rate / from_rate


def convert_currency(amount: float, from_currency: str, to_currency: str) -> Dict[str, Any]:
    """Convert amount from one currency to another."""
    from_upper = from_currency.upper()
    to_upper = to_currency.upper()
    
    if from_upper not in EXCHANGE_RATES_TO_USD:
        return {"error": f"Currency {from_currency} not found"}
    
    if to_upper not in EXCHANGE_RATES_TO_USD:
        return {"error": f"Currency {to_currency} not found"}
    
    rate = get_exchange_rate(from_upper, to_upper)
    converted = amount * rate
    
    from_info = get_currency_info(from_upper)
    to_info = get_currency_info(to_upper)
    
    return {
        "from": {
            "amount": amount,
            "currency": from_upper,
            "symbol": from_info.get("symbol", from_upper) if from_info else from_upper
        },
        "to": {
            "amount": round(converted, 2),
            "currency": to_upper,
            "symbol": to_info.get("symbol", to_upper) if to_info else to_upper
        },
        "rate": round(rate, 4),
        "inverse_rate": round(1/rate, 4) if rate != 0 else 0,
        "timestamp": datetime.now().isoformat(),
        "note": "Exchange rate is approximate. Use for estimation only."
    }


def format_currency(amount: float, currency: str, include_symbol: bool = True) -> str:
    """Format currency amount for display."""
    currency_upper = currency.upper()
    info = get_currency_info(currency_upper)
    symbol = info.get("symbol", currency_upper) if info else currency_upper
    
    # Handle currencies that typically don't show decimals
    no_decimals = ["JPY", "KRW", "VND", "IDR"]
    
    if currency_upper in no_decimals:
        formatted = f"{symbol}{int(round(amount)):,}"
    else:
        formatted = f"{symbol}{amount:,.2f}"
    
    if not include_symbol:
        formatted = f"{amount:,.2f} {currency_upper}"
    
    return formatted


def convert_budget(
    budget: float,
    from_currency: str,
    to_currency: str,
    duration_days: int = 1
) -> Dict[str, Any]:
    """Convert and analyze budget across currencies."""
    conversion = convert_currency(budget, from_currency, to_currency)
    
    if "error" in conversion:
        return conversion
    
    # Calculate daily equivalents
    daily_original = budget / duration_days if duration_days > 0 else budget
    daily_converted = conversion["to"]["amount"] / duration_days if duration_days > 0 else conversion["to"]["amount"]
    
    return {
        "original": {
            "total": format_currency(budget, from_currency),
            "daily": format_currency(daily_original, from_currency),
            "currency": from_currency
        },
        "converted": {
            "total": format_currency(conversion["to"]["amount"], to_currency),
            "daily": format_currency(daily_converted, to_currency),
            "currency": to_currency
        },
        "rate": conversion["rate"],
        "duration_days": duration_days,
        "timestamp": conversion["timestamp"]
    }


def get_cost_benchmark(
    benchmark_type: str,
    target_currency: str
) -> Dict[str, Any]:
    """Get cost benchmarks in target currency."""
    if benchmark_type not in COST_BENCHMARKS:
        return {"error": f"Benchmark type {benchmark_type} not found"}
    
    benchmarks = COST_BENCHMARKS[benchmark_type]
    target_upper = target_currency.upper()
    
    # Find USD benchmark and convert
    usd_amount = benchmarks.get("USD")
    if usd_amount:
        converted = convert_currency(usd_amount, "USD", target_upper)
        if "error" not in converted:
            return {
                "type": benchmark_type,
                "amount": format_currency(converted["to"]["amount"], target_upper),
                "currency": target_upper,
                "note": f"Approximate cost in {target_currency}"
            }
    
    return {"error": "Could not calculate benchmark"}


def estimate_trip_cost_in_currency(
    trip_cost_usd: float,
    target_currency: str
) -> Dict[str, Any]:
    """Estimate total trip cost in target currency."""
    conversion = convert_currency(trip_cost_usd, "USD", target_currency)
    
    if "error" in conversion:
        return conversion
    
    breakdown = {
        "cost_category": "Estimated Cost",
        "original_usd": format_currency(trip_cost_usd, "USD"),
        "converted": format_currency(conversion["to"]["amount"], target_currency),
        "currency": target_currency,
        "rate_used": conversion["rate"]
    }
    
    return breakdown


def format_conversion_report(conversion: Dict[str, Any]) -> str:
    """Format currency conversion as readable text."""
    if "error" in conversion:
        return f"Error: {conversion['error']}"
    
    from_info = conversion["from"]
    to_info = conversion["to"]
    
    report = f"# 💱 Currency Conversion\n\n"
    report += f"## {from_info['symbol']}{from_info['amount']:,.2f} {from_info['currency']}\n\n"
    report += f"### Converts to:\n\n"
    report += f"## {to_info['symbol']}{to_info['amount']:,.2f} {to_info['currency']}\n\n"
    report += f"---\n\n"
    report += f"**Exchange Rate:** 1 {from_info['currency']} = {conversion['rate']:.4f} {to_info['currency']}\n"
    report += f"**Inverse Rate:** 1 {to_info['currency']} = {conversion['inverse_rate']:.4f} {from_info['currency']}\n\n"
    report += f"*Generated: {conversion['timestamp']}*\n"
    report += f"*Note: {conversion['note']}*\n"
    
    return report


def list_supported_currencies() -> List[Dict[str, Any]]:
    """List all supported currencies."""
    currencies = []
    for code, info in CURRENCIES.items():
        currencies.append({
            "code": code,
            "name": info["name"],
            "symbol": info["symbol"],
            "regions": info["regions"]
        })
    return currencies


# CLI Interface
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Currency Converter")
    parser.add_argument("--amount", "-a", type=float, required=True, help="Amount to convert")
    parser.add_argument("--from", "-f", dest="from_currency", required=True, help="Source currency code")
    parser.add_argument("--to", "-t", dest="to_currency", required=True, help="Target currency code")
    parser.add_argument("--list", "-l", action="store_true", help="List supported currencies")
    parser.add_argument("--benchmark", "-b", help="Cost benchmark type (budget_meal, mid_meal, etc.)")
    parser.add_argument("--output", "-o", help="Output file path")
    
    args = parser.parse_args()
    
    if args.list:
        currencies = list_supported_currencies()
        print("# 💱 Supported Currencies\n")
        for c in currencies:
            print(f"**{c['code']}** ({c['symbol']}): {c['name']}")
            print(f"  Regions: {', '.join(c['regions'])}\n")
    elif args.benchmark:
        result = get_cost_benchmark(args.benchmark, args.to_currency)
        if "error" in result:
            print(f"Error: {result['error']}")
        else:
            print(f"# 💰 Cost Benchmark: {result['type']}\n")
            print(f"**Amount:** {result['amount']}")
            print(f"**Currency:** {result['currency']}")
            print(f"**Note:** {result['note']}")
    else:
        conversion = convert_currency(args.amount, args.from_currency, args.to_currency)
        result = format_conversion_report(conversion)
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(result)
            print(f"✓ Conversion saved to: {args.output}")
        else:
            print(result)
