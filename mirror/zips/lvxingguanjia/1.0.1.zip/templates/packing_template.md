# 🎒 Packing Checklist: {destination}

## Trip Information
- **Destination:** {destination}, {country}
- **Dates:** {start_date} - {end_date}
- **Duration:** {duration} days
- **Climate:** {climate_description}
- **Activities:** {activity_list}

---

## ✅ Complete Packing List

### 📄 Documents & Money
- [ ] Passport (valid for 6+ months)
- [ ] Visa (if required)
- [ ] Travel insurance documents
- [ ] Flight tickets/boarding passes
- [ ] Hotel confirmation
- [ ] Car rental confirmation (if applicable)
- [ ] Tour/activity tickets
- [ ] Credit cards (notify bank)
- [ ] Debit card
- [ ] Cash ({local_currency})
- [ ] Emergency contact list
- [ ] Copies of all documents
- [ ] USB drive with document scans

**Money Tips:**
- Exchange rate: 1 USD = {exchange_rate} {local_currency}
- Budget: {daily_budget} {currency}/day
- ATMs widely available: {atm_note}

---

### 🔌 Electronics
- [ ] Phone + charger
- [ ] Power bank (10,000mAh)
- [ ] Universal adapter (Type {plug_type})
- [ ] Camera + memory cards
- [ ] Camera charger
- [ ] Headphones
- [ ] Laptop/tablet (if needed)
- [ ] E-reader (optional)

**Electrical Info:**
- Voltage: {voltage}
- Frequency: {frequency}
- Plug type: {plug_type}

---

### 🧴 Toiletries & Health
- [ ] Toothbrush + toothpaste
- [ ] Deodorant
- [ ] Shampoo (travel size)
- [ ] Body wash
- [ ] Face wash
- [ ] Moisturizer
- [ ] Sunscreen SPF {spf_rating}
- [ ] Lip balm with SPF
- [ ] Medications
- [ ] First aid kit
- [ ] Hand sanitizer
- [ ] Tissues/wet wipes
- [ ] Prescription medications (with doctor's note)

**Health Notes:**
- {health_advisories}
- {vaccination_requirements}

---

### 👕 Clothing

#### Essentials
- [ ] Underwear ({underwear_count} pairs)
- [ ] Socks ({sock_count} pairs)
- [ ] Pajamas

#### Tops
- [ ] T-shirts ({tshirt_count})
- [ ] Long-sleeve shirts ({longsleeve_count})
- [ ] {special_tops}

#### Bottoms
- [ ] Pants ({pants_count})
- [ ] Shorts ({shorts_count})
- [ ] {special_bottoms}

#### Outerwear
- [ ] {jacket_type}
- [ ] {rain_gear}

#### Footwear
- [ ] Walking shoes
- [ ] {additional_shoes}

#### Special Items
- [ ] {swimwear}
- [ ] {formal_clothing}

---

### 🏃 Activity-Specific Gear

#### {activity_name}
- [ ] {gear_item}
- [ ] {gear_item}
- [ ] {gear_item}

---

### 🎯 Day Bag / Carry-On Essentials
- [ ] Passport
- [ ] Wallet
- [ ] Phone
- [ ] Headphones
- [ ] Book/Kindle
- [ ] Snacks
- [ ] Water bottle
- [ ] Sunglasses
- [ ] Sunscreen
- [ ] Phone charger
- [ ] Change of clothes (for long flights)

---

### 🏨 Hotel Room Essentials
- [ ] Travel towel
- [ ] Padlock (for lockers)
- [ ] Door stop (security)
- [ ] Sleep mask
- [ ] Earplugs
- [ ] Travel pillow

---

### 📝 Before You Leave Checklist
- [ ] Passport in bag
- [ ] Phone charged
- [ ] Photos of documents uploaded
- [ ] Bank notified
- [ ] Mail held
- [ ] Plants watered
- [ ] Trash taken out
- [ ] Thermostat adjusted
- [ ] Home lights on timer
- [ ] Garage locked

---

## 💡 Packing Tips

1. **Roll clothes** instead of folding to save space
2. **Use packing cubes** to organize
3. **Wear heaviest items** on the plane
4. **Limit shoes** - 2-3 pairs max
5. **Pack liquids** in ziplock bags
6. **Leave room** for souvenirs

---

*Checklist generated: {date}*
