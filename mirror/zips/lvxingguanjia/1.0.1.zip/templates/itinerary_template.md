# 📅 {destination} Travel Itinerary

## Trip Overview

| Item | Details |
|------|---------|
| **Destination** | {destination}, {country} |
| **Travel Dates** | {start_date} - {end_date} |
| **Duration** | {duration} days |
| **Travelers** | {travelers} |
| **Travel Style** | {style} |
| **Budget** | {budget} {currency} |

## 🗺️ Daily Itinerary

### Day 1: Arrival & Settling In
**Theme:** Arrival and Orientation

**Morning (9:00 AM - 12:00 PM)**
- Arrive at {destination}
- Airport transfer to hotel
- Hotel check-in

**Afternoon (2:00 PM - 5:00 PM)**
- Light lunch
- Explore neighborhood
- Get bearings with a short walk

**Evening (7:00 PM - 10:00 PM)**
- Welcome dinner at local restaurant
- Early night to adjust to time zone

**Meals:**
- Breakfast: Hotel
- Lunch: {local_food_suggestion}
- Dinner: {restaurant_recommendation}

**Notes:**
- {booking_tips_day1}

---

### Day 2: {theme_day2}
**Theme:** {theme_description}

**Morning (9:00 AM - 12:00 PM)**
- {morning_activity_1}
- Duration: {duration}
- Location: {location}

**Afternoon (2:00 PM - 5:00 PM)**
- {afternoon_activity}
- Duration: {duration}
- Location: {location}

**Evening (7:00 PM - 10:00 PM)**
- {evening_activity}
- {additional_notes}

**Meals:**
- Breakfast: {breakfast_option}
- Lunch: {lunch_option}
- Dinner: {dinner_option}

**Transportation:**
- {transport_details}

**Notes:**
- {important_tips}

---

### Day {n}: {placeholder}

**Theme:** {theme}

**Schedule:**
- {time}: {activity}
- {time}: {activity}
- {time}: {activity}

**Meals:**
- Breakfast: {option}
- Lunch: {option}
- Dinner: {option}

---

## 🎫 Attractions & Tickets

### Must-Book in Advance
1. **{attraction_name}** - {booking_link}
   - Price: {price}
   - Book for: {date/time}

2. **{attraction_name}** - {booking_link}
   - Price: {price}
   - Book for: {date/time}

### On-the-Spot Attractions
- {attraction} - {notes}
- {attraction} - {notes}

---

## 🍽️ Restaurant Reservations

| Restaurant | Cuisine | Day | Time | Status |
|------------|---------|-----|------|--------|
| {name} | {type} | Day {n} | {time} | {status} |
| {name} | {type} | Day {n} | {time} | {status} |

---

## 📍 Location Quick Reference

### Hotel
- **Name:** {hotel_name}
- **Address:** {address}
- **Phone:** {phone}
- **Check-in:** {check_in_time}
- **Check-out:** {check_out_time}

### Important Addresses
- Airport: {airport_name} ({code})
- Train Station: {station_name}
- Embassy: {embassy_name} - {address}

---

## 📱 Useful Apps & Contacts

### Apps to Download
- {app_name} - {purpose}
- {app_name} - {purpose}

### Emergency Contacts
- Police: {number}
- Ambulance: {number}
- Fire: {number}
- Hotel: {number}
- Embassy: {number}

---

*Itinerary generated on {date}*
