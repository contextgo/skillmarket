# 💰 Travel Budget: {destination}

## Budget Overview

| Item | Amount |
|------|--------|
| **Total Budget** | {total_budget} {currency} |
| **Duration** | {duration} days |
| **Per Person** | {per_person} {currency} |
| **Daily Average** | {daily_average} {currency} |
| **Travel Style** | {style} |

---

## 📊 Budget Breakdown

### Category Allocation

| Category | Amount | Percentage | Daily | Notes |
|----------|--------|------------|-------|-------|
| 🏨 Accommodation | {accommodation_total} | {accommodation_pct}% | {accommodation_daily} | {accommodation_notes} |
| 🍽️ Food & Dining | {food_total} | {food_pct}% | {food_daily} | {food_notes} |
| ✈️ Transportation | {transport_total} | {transport_pct}% | {transport_daily} | {transport_notes} |
| 🎫 Activities | {activities_total} | {activities_pct}% | {activities_daily} | {activities_notes} |
| 🛍️ Shopping | {shopping_total} | {shopping_pct}% | {shopping_daily} | {shopping_notes} |
| 📝 Miscellaneous | {misc_total} | {misc_pct}% | {misc_daily} | {misc_notes} |

### Visual Breakdown
```
Accommodation  [{bar_accommodation}] {accommodation_pct}%
Food           [{bar_food}] {food_pct}%
Transportation [{bar_transport}] {transport_pct}%
Activities     [{bar_activities}] {activities_pct}%
Shopping       [{bar_shopping}] {misc_pct}%
Miscellaneous  [{bar_misc}] {misc_pct}%
```

---

## 🏨 Accommodation Budget

| Item | Cost |
|------|------|
| **Nightly Rate** | {hotel_rate} {currency} |
| **Number of Nights** | {num_nights} |
| **Total** | {hotel_total} {currency} |

**Hotel Notes:**
- {hotel_tips}

---

## 🍽️ Food & Dining Budget

| Meal | Daily Budget | Total |
|------|--------------|-------|
| Breakfast | {breakfast_budget} | {breakfast_total} |
| Lunch | {lunch_budget} | {lunch_total} |
| Dinner | {dinner_budget} | {dinner_total} |
| Snacks/Drinks | {snacks_budget} | {snacks_total} |
| **Subtotal** | {food_daily} | **{food_total}** |

**Dining Tips:**
- {dining_tips}

---

## ✈️ Transportation Budget

| Item | Cost |
|------|------|
| Flights | {flights_cost} |
| Airport Transfer | {airport_transfer} |
| Local Transit | {local_transit} |
| Taxis/Rides | {taxis} |
| Day Trips | {day_trips} |
| **Subtotal** | **{transport_total}** |

**Transport Tips:**
- {transport_tips}

---

## 🎫 Activities & Entertainment

| Activity | Cost | Notes |
|----------|------|-------|
| {activity_1} | {cost_1} | {notes} |
| {activity_2} | {cost_2} | {notes} |
| {activity_3} | {cost_3} | {notes} |
| {activity_4} | {cost_4} | {notes} |
| {activity_5} | {cost_5} | {notes} |
| **Subtotal** | **{activities_total}** | |

---

## 🛍️ Shopping Budget

| Category | Budget |
|----------|--------|
| Souvenirs | {souvenirs_budget} |
| Local Products | {local_products} |
| Gifts | {gifts} |
| **Subtotal** | **{shopping_total}** |

---

## 📝 Miscellaneous

| Item | Budget |
|------|--------|
| Tips | {tips_budget} |
| SIM Card | {sim_budget} |
| Travel Insurance | {insurance_budget} |
| Contingency | {contingency_budget} |
| **Subtotal** | **{misc_total}** |

---

## 💵 Currency Information

| Item | Details |
|------|---------|
| Local Currency | {local_currency} |
| Exchange Rate | 1 USD = {exchange_rate} |
| Budget in Local | {budget_local} {local_currency} |

**Exchange Tips:**
- {exchange_tips}

---

## 📈 Budget Tracking

### Day-by-Day Spending

| Day | Date | Spent | Budget | Remaining |
|-----|------|-------|--------|-----------|
| 1 | {date_1} | {spent_1} | {daily_budget} | {remaining_1} |
| 2 | {date_2} | {spent_2} | {daily_budget} | {remaining_2} |
| 3 | {date_3} | {spent_3} | {daily_budget} | {remaining_3} |
| ... | ... | ... | ... | ... |
| **Total** | | **{total_spent}** | **{total_budget}** | **{total_remaining}** |

---

## 💡 Money-Saving Tips

1. **{tip_1}**
2. **{tip_2}**
3. **{tip_3}**
4. **{tip_4}**
5. **{tip_5}**

---

## ⚠️ Important Reminders

- {reminder_1}
- {reminder_2}
- {reminder_3}

---

*Budget generated: {date}*
