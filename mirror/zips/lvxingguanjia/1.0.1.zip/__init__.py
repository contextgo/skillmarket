#!/usr/bin/env python3
"""
Travel Butler - 旅行智能管家

A comprehensive travel planning and assistant skill.
"""

__version__ = "1.0.0"
__author__ = "Travel Butler Team"

from . import scripts
from . import templates
from . import data
from . import references

__all__ = ["scripts", "templates", "data", "references"]
