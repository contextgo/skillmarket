/**
 * Travel Butler - 旅行智能管家
 * 
 * A comprehensive travel planning and assistant skill.
 * 
 * This skill provides:
 * - Itinerary planning
 * - Attraction recommendations
 * - Budget calculation
 * - Travel guides generation
 * - Weather information
 * - Currency conversion
 * - Packing lists
 */

module.exports = {
  name: 'travel-butler',
  description: '旅行智能管家 - 全面的旅行规划和助手技能',
  version: '1.0.0',
  
  // Skill metadata
  metadata: {
    category: 'lifestyle',
    tags: ['travel', 'planning', 'tourism', 'vacation'],
    languages: ['zh-CN', 'en-US']
  },
  
  // Main entry point
  main: async function(context) {
    const { message, userId, sessionId } = context;
    
    // Route to appropriate handler based on message content
    const handlers = {
      'itinerary': handleItinerary,
      'plan': handleItinerary,
      '行程': handleItinerary,
      '景点': handleAttraction,
      'attraction': handleAttraction,
      '推荐': handleAttraction,
      '预算': handleBudget,
      'budget': handleBudget,
      '花费': handleBudget,
      '天气': handleWeather,
      'weather': handleWeather,
      '攻略': handleGuide,
      'guide': handleGuide,
      '货币': handleCurrency,
      'currency': handleCurrency,
      '汇率': handleCurrency,
      '打包': handlePacking,
      'packing': handlePacking,
      '清单': handlePacking
    };
    
    // Find matching handler
    const lowerMessage = message.toLowerCase();
    for (const [keyword, handler] of Object.entries(handlers)) {
      if (lowerMessage.includes(keyword)) {
        return await handler(context);
      }
    }
    
    // Default: show help
    return showHelp(context);
  }
};

// Handler functions
async function handleItinerary(context) {
  const { message } = context;
  // Import and run the itinerary planner script
  // This would call the Python script or use the functions directly
  return {
    type: 'text',
    content: '正在为您规划行程...',
    actions: ['generate_itinerary']
  };
}

async function handleAttraction(context) {
  return {
    type: 'text',
    content: '正在为您推荐景点...',
    actions: ['recommend_attractions']
  };
}

async function handleBudget(context) {
  return {
    type: 'text',
    content: '正在计算预算...',
    actions: ['calculate_budget']
  };
}

async function handleWeather(context) {
  return {
    type: 'text',
    content: '正在查询天气...',
    actions: ['check_weather']
  };
}

async function handleGuide(context) {
  return {
    type: 'text',
    content: '正在生成旅行攻略...',
    actions: ['generate_guide']
  };
}

async function handleCurrency(context) {
  return {
    type: 'text',
    content: '正在进行货币转换...',
    actions: ['convert_currency']
  };
}

async function handlePacking(context) {
  return {
    type: 'text',
    content: '正在生成打包清单...',
    actions: ['generate_packing_list']
  };
}

async function showHelp(context) {
  return {
    type: 'text',
    content: `
# 🧳 旅行智能管家

您好！我是您的旅行智能管家，可以帮助您：

## 📋 我能做什么

1. **行程规划** - 根据您的目的地和时间生成详细行程
   - 用法：行程规划 / plan

2. **景点推荐** - 基于您的兴趣推荐热门景点
   - 用法：景点推荐 / 推荐景点

3. **预算计算** - 帮您规划旅行预算
   - 用法：预算计算 / 预算

4. **天气查询** - 查看目的地天气预报
   - 用法：查询天气 / weather

5. **攻略生成** - 生成完整旅行攻略
   - 用法：生成攻略 / guide

6. **货币转换** - 多种货币实时转换
   - 用法：货币转换 / 汇率

7. **打包清单** - 根据行程生成打包建议
   - 用法：打包清单 / packing

## 🚀 开始使用

只需告诉我：
- 您想去哪里？
- 什么时候去？
- 计划几天？
- 预算多少？

我会为您量身定制旅行计划！
    `
  };
}
