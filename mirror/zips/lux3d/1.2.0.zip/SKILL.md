---
name: lux3d
description: "Use Lux3D to generate 3D models from images or text. Trigger when the user asks for image to 3D, text to 3D, prompt to 3D, create a 3D model from a description, or create a 3D model from a description plus a reference image."
---

## What This Skill Does

Lux3D generates 3D assets through two documented asynchronous workflows:

- Image to 3D: submit an input image, poll the task, then download the ZIP result.
- Text to 3D: submit a prompt plus style, optionally with a reference image, poll the task, then download the ZIP result.

Both workflows require `LUX3D_API_KEY`, which is a base64 invitation code in the documented format:

```text
version:appkey:appsecret:appuid
```

## Setup

Apply for an API key:

- Form: https://forms.cloud.microsoft/pages/responsepage.aspx?id=DQSIkWdsW0yxEjajBLZtrQAAAAAAAAAAAAN__6yDykBUMDFaQzhKS1VLQlQ1UktQUU5TQjhYVkZTMS4u&route=shorturl
- Contact: lux3d@qunhemail.com

Set the environment variable before use:

```bash
export LUX3D_API_KEY="your_base64_invitation_code"
```

Optional API root override:

```bash
export LUX3D_BASE_URL="https://api.coohom.com/global"
```

Documented API roots:

- International: `https://api.coohom.com/global`
- Domestic: `https://api.kujiale.com/p/openapi/v2`

## Python Usage

Image to 3D:

```python
from lux3d_client import generate_3d_model

result = generate_3d_model("path/to/input.jpg")
print(result)
```

Text to 3D:

```python
from lux3d_client import generate_text_to_3d

result = generate_text_to_3d(
    "Generate a high-quality 3D wooden chair",
    style="photorealistic",
)
print(result)
```

Text plus reference image:

```python
from lux3d_client import generate_text_to_3d

result = generate_text_to_3d(
    "Generate a premium ceramic vase with a glossy glaze",
    style="glass",
    image_path="path/to/reference.png",
)
print(result)
```

Low-level task APIs:

```python
from lux3d_client import (
    create_task,
    create_text_to_3d_task,
    query_task_status,
    download_model,
)

image_task_id = create_task("path/to/input.jpg")
text_task_id = create_text_to_3d_task(
    "Generate a stylized toy robot",
    style="cartoon",
    image_path="path/to/reference.png",
)

image_model_url = query_task_status(image_task_id)
text_model_url = query_task_status(text_task_id)

download_model(image_model_url, "image_to_3d.zip")
download_model(text_model_url, "text_to_3d.zip")
```

## Command Line Usage

Historical image-to-3D form:

```bash
python lux3d_client.py input.jpg output.zip
```

Explicit image-to-3D command:

```bash
python lux3d_client.py image input.jpg output.zip
```

Text-to-3D command:

```bash
python lux3d_client.py text "Generate a high-quality 3D wooden chair" output.zip --style photorealistic
```

Text-to-3D with a reference image:

```bash
python lux3d_client.py text "Generate a futuristic desk lamp" output.zip --style cyberpunk --image ref.png
```

## Text-to-3D Styles

Supported documented styles:

- `photorealistic`
- `cartoon`
- `anime`
- `hand_painted`
- `cyberpunk`
- `fantasy`
- `glass`

## Output

The result URL typically points to a ZIP file. The package commonly contains:

- a GLB model file
- PBR texture assets

The documented result URL validity window is 2 hours.

## Notes

- The skill uses the documented signed API flow:
  `sign = MD5(appsecret + appkey + appuid + timestamp)`
- Image-to-3D and text-to-3D use different create endpoints.
- Both workflows share the same task query endpoint.
- `prompt` and `style` are required for text-to-3D.
- `img` is optional for text-to-3D and should be a full data URL after encoding.

## Requirements

```bash
pip install Pillow requests
```

## References

- ClawHub: https://clawhub.ai/violalulu/lux3d
- ComfyUI reference implementation: https://github.com/manycore-research/ComfyUI-Lux3D
- API contact: lux3d@qunhemail.com
