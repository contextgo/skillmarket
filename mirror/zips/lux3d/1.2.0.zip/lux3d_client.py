"""
Lux3D client for image-to-3D and text-to-3D generation.
"""

import argparse
import base64
import hashlib
import io
import os
import sys
import time
import urllib.parse

import requests
from PIL import Image


DOMESTIC_HOST = "https://api.kujiale.com"
DOMESTIC_PREFIX = "/p/openapi/v2"
INTERNATIONAL_HOST = "https://api.coohom.com"
INTERNATIONAL_PREFIX = "/global"
DEFAULT_BASE_URL = (
    os.environ.get("LUX3D_BASE_URL", "").strip()
    or INTERNATIONAL_HOST + INTERNATIONAL_PREFIX
)

REQUEST_TIMEOUT = 30
MAX_RETRIES = 3
RETRY_DELAY = 2
DEFAULT_POLL_ATTEMPTS = 60
DEFAULT_POLL_INTERVAL = 15
SUPPORTED_STYLES = {
    "photorealistic",
    "cartoon",
    "anime",
    "hand_painted",
    "cyberpunk",
    "fantasy",
    "glass",
}


def get_api_key():
    """Read the API key from the environment each time it is needed."""
    return os.environ.get("LUX3D_API_KEY", "").strip()


def validate_api_key():
    """Validate the configured API key and return it."""
    api_key = get_api_key()
    if not api_key or api_key in {"your_lux3d_api_key", "your_invitation_code_here"}:
        raise ValueError(
            "[ERROR] API key not configured.\n"
            "Please set LUX3D_API_KEY to the base64 invitation code."
        )
    return api_key


def validate_image_path(image_path):
    """Validate that an image path exists and is readable."""
    if not image_path:
        raise ValueError("Image path cannot be empty")
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image file not found: {image_path}")
    if not os.path.isfile(image_path):
        raise ValueError(f"Path is not a file: {image_path}")
    try:
        with open(image_path, "rb") as file_obj:
            file_obj.read(1)
    except PermissionError as exc:
        raise PermissionError(f"Permission denied reading: {image_path}") from exc


def validate_output_path(output_path):
    """Validate that the output path can be written."""
    output_dir = os.path.dirname(output_path) or "."
    if not os.path.isdir(output_dir):
        raise ValueError(f"Output directory does not exist: {output_dir}")

    test_path = os.path.join(output_dir, ".lux3d_write_test")
    try:
        with open(test_path, "w", encoding="utf-8") as file_obj:
            file_obj.write("ok")
    except OSError as exc:
        raise PermissionError(f"Cannot write to directory: {output_dir}") from exc
    finally:
        if os.path.exists(test_path):
            os.remove(test_path)


def validate_prompt(prompt):
    """Validate the text prompt for text-to-3D generation."""
    if not prompt or not prompt.strip():
        raise ValueError("Prompt cannot be empty")
    return prompt.strip()


def validate_style(style):
    """Validate the requested text-to-3D style."""
    if style not in SUPPORTED_STYLES:
        supported = ", ".join(sorted(SUPPORTED_STYLES))
        raise ValueError(f"Unsupported style '{style}'. Supported styles: {supported}")
    return style


def normalize_base_url(base_url):
    """Normalize the configured base URL to a documented Lux3D API root."""
    normalized = (base_url or DEFAULT_BASE_URL).rstrip("/")
    if normalized == DOMESTIC_HOST:
        return normalized + DOMESTIC_PREFIX
    if normalized == INTERNATIONAL_HOST:
        return normalized + INTERNATIONAL_PREFIX
    return normalized


def parse_invitation_code(code):
    """Parse a base64 encoded invitation code into its four components."""
    decoded = base64.b64decode(code).decode("utf-8")
    parts = decoded.split(":")
    if len(parts) != 4:
        raise ValueError(f"Invalid invitation code format: expected 4 parts, got {len(parts)}")
    return {
        "version": parts[0],
        "ak": parts[1],
        "sk": parts[2],
        "appuid": parts[3],
    }


def generate_sign(ak, sk, appuid):
    """Generate the documented Lux3D request signature."""
    timestamp = str(int(time.time() * 1000))
    raw = sk + ak + appuid + timestamp
    sign = hashlib.md5(raw.encode("utf-8")).hexdigest()
    return {
        "appkey": ak,
        "appuid": appuid,
        "timestamp": timestamp,
        "sign": sign,
    }


def secure_request(method, url, headers=None, data=None, timeout=None, retries=None):
    """Perform an HTTP request with bounded retries."""
    request_headers = headers or {"Content-Type": "application/json"}
    timeout = timeout or REQUEST_TIMEOUT
    retries = retries or MAX_RETRIES
    last_error = None

    for attempt in range(retries):
        try:
            response = requests.request(
                method=method.upper(),
                url=url,
                headers=request_headers,
                json=data,
                timeout=timeout,
            )
            response.raise_for_status()
            return response
        except requests.exceptions.Timeout as exc:
            last_error = f"Request timeout (attempt {attempt + 1}/{retries})"
            if attempt == retries - 1:
                break
            time.sleep(RETRY_DELAY)
        except requests.exceptions.RequestException as exc:
            last_error = f"Request failed: {exc}"
            if attempt == retries - 1:
                break
            time.sleep(RETRY_DELAY)

    raise Exception(f"Request failed after {retries} attempts: {last_error}")


def image_to_data_url(image_path):
    """Convert an image file to a JPEG data URL."""
    validate_image_path(image_path)
    image = Image.open(image_path)
    if image.mode != "RGB":
        image = image.convert("RGB")
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG", quality=85)
    image_bytes = buffer.getvalue()
    encoded = base64.b64encode(image_bytes).decode("utf-8")
    return f"data:image/jpeg;base64,{encoded}"


def build_signed_url(base_url, path, sign_params, extra_query=None):
    """Build a signed Lux3D API URL."""
    query = {
        "appuid": sign_params["appuid"],
        "appkey": sign_params["appkey"],
        "sign": sign_params["sign"],
        "timestamp": sign_params["timestamp"],
    }
    if extra_query:
        query.update(extra_query)
    return normalize_base_url(base_url) + path + "?" + urllib.parse.urlencode(query)


def ensure_success(result):
    """Validate the Lux3D API response format used in the documentation."""
    code = result.get("c")
    if code not in (None, "", 0, "0"):
        message = result.get("m") or "unknown error"
        raise Exception(f"API error: {message} (code={code})")

    legacy_code = result.get("code")
    if code is None and legacy_code not in (None, "", 0, "0"):
        message = result.get("message") or "unknown error"
        raise Exception(f"API error: {message} (code={legacy_code})")

    return result


def submit_task(path, payload, base_url=DEFAULT_BASE_URL):
    """Submit a Lux3D generation task and return its busid."""
    api_key = validate_api_key()
    code = parse_invitation_code(api_key)
    sign = generate_sign(code["ak"], code["sk"], code["appuid"])
    url = build_signed_url(base_url, path, sign)
    response = secure_request("POST", url, headers={"Content-Type": "application/json"}, data=payload)

    try:
        result = response.json()
    except ValueError as exc:
        raise Exception(f"Invalid JSON response: {response.text}") from exc

    ensure_success(result)
    task_id = result.get("d")
    if task_id in (None, ""):
        raise Exception(f"Missing task id in response: {result}")
    return str(task_id)


def create_task(image_path, base_url=DEFAULT_BASE_URL, lux3d_biz_type=None):
    """Submit an image-to-3D task."""
    payload = {"img": image_to_data_url(image_path)}
    if lux3d_biz_type is not None:
        payload["lux3dBizType"] = lux3d_biz_type
    return submit_task("/lux3d/generate/task/create", payload, base_url=base_url)


def create_text_to_3d_task(
    prompt,
    style="photorealistic",
    image_path=None,
    base_url=DEFAULT_BASE_URL,
    lux3d_biz_type=None,
):
    """Submit a text-to-3D task with an optional reference image."""
    payload = {
        "prompt": validate_prompt(prompt),
        "style": validate_style(style),
    }
    if image_path:
        payload["img"] = image_to_data_url(image_path)
    if lux3d_biz_type is not None:
        payload["lux3dBizType"] = lux3d_biz_type
    return submit_task("/lux3d/generate/text-to-3d/task/create", payload, base_url=base_url)


def query_task_status(task_id, base_url=DEFAULT_BASE_URL, max_attempts=DEFAULT_POLL_ATTEMPTS, interval=DEFAULT_POLL_INTERVAL):
    """Poll a Lux3D task until completion and return the download URL."""
    api_key = validate_api_key()
    code = parse_invitation_code(api_key)

    for _ in range(max_attempts):
        sign = generate_sign(code["ak"], code["sk"], code["appuid"])
        url = build_signed_url(
            base_url,
            "/lux3d/generate/task/get",
            sign,
            extra_query={"busid": task_id},
        )
        response = secure_request("GET", url, headers={"Content-Type": "application/json"})

        try:
            result = response.json()
        except ValueError as exc:
            raise Exception(f"Invalid JSON response: {response.text}") from exc

        ensure_success(result)
        task_data = result.get("d") or {}
        status = task_data.get("status")

        if status == 3:
            outputs = task_data.get("outputs") or []
            if outputs and outputs[0].get("content"):
                return outputs[0]["content"]
            raise Exception(f"Task succeeded without output content: {result}")
        if status == 4:
            raise Exception(f"Task execution failed: {result}")

        time.sleep(interval)

    raise Exception("Task timeout")


def download_model(model_url, output_path):
    """Download the generated ZIP file to the target path."""
    validate_output_path(output_path)
    response = secure_request("GET", model_url, headers={})
    with open(output_path, "wb") as file_obj:
        file_obj.write(response.content)
    return len(response.content)


def generate_3d_model(
    image_path,
    output_path=None,
    base_url=DEFAULT_BASE_URL,
    lux3d_biz_type=None,
    max_attempts=DEFAULT_POLL_ATTEMPTS,
    interval=DEFAULT_POLL_INTERVAL,
):
    """Run the full image-to-3D workflow."""
    validate_api_key()

    print("=== Submitting image-to-3D task ===")
    task_id = create_task(image_path, base_url=base_url, lux3d_biz_type=lux3d_biz_type)
    print(f"Task ID: {task_id}")

    print("\n=== Querying task result ===")
    model_url = query_task_status(
        task_id,
        base_url=base_url,
        max_attempts=max_attempts,
        interval=interval,
    )
    print(f"Model URL: {model_url}")

    output_name = output_path or image_path.rsplit(".", 1)[0] + "_3d.zip"
    print("\n=== Downloading model ===")
    size = download_model(model_url, output_name)
    print(f"Downloaded: {output_name} ({size} bytes)")
    return output_name


def generate_text_to_3d(
    prompt,
    output_path=None,
    style="photorealistic",
    image_path=None,
    base_url=DEFAULT_BASE_URL,
    lux3d_biz_type=None,
    max_attempts=DEFAULT_POLL_ATTEMPTS,
    interval=DEFAULT_POLL_INTERVAL,
):
    """Run the full text-to-3D workflow."""
    validate_api_key()

    print("=== Submitting text-to-3D task ===")
    task_id = create_text_to_3d_task(
        prompt,
        style=style,
        image_path=image_path,
        base_url=base_url,
        lux3d_biz_type=lux3d_biz_type,
    )
    print(f"Task ID: {task_id}")

    print("\n=== Querying task result ===")
    model_url = query_task_status(
        task_id,
        base_url=base_url,
        max_attempts=max_attempts,
        interval=interval,
    )
    print(f"Model URL: {model_url}")

    output_name = output_path or "lux3d_text_to_3d.zip"
    print("\n=== Downloading model ===")
    size = download_model(model_url, output_name)
    print(f"Downloaded: {output_name} ({size} bytes)")
    return output_name


def build_parser():
    """Build the CLI parser."""
    parser = argparse.ArgumentParser(
        description="Lux3D client for image-to-3D and text-to-3D generation."
    )
    subparsers = parser.add_subparsers(dest="command")

    image_parser = subparsers.add_parser("image", help="Generate a 3D model from an image.")
    image_parser.add_argument("image_path", help="Input image path")
    image_parser.add_argument("output_path", nargs="?", help="Output ZIP path")
    image_parser.add_argument("--base-url", default=DEFAULT_BASE_URL, help="Lux3D API base URL")
    image_parser.add_argument("--biz-type", dest="lux3d_biz_type", help="Optional business type")
    image_parser.add_argument("--max-attempts", type=int, default=DEFAULT_POLL_ATTEMPTS)
    image_parser.add_argument("--interval", type=int, default=DEFAULT_POLL_INTERVAL)

    text_parser = subparsers.add_parser("text", help="Generate a 3D model from text.")
    text_parser.add_argument("prompt", help="Text prompt")
    text_parser.add_argument("output_path", nargs="?", help="Output ZIP path")
    text_parser.add_argument("--style", default="photorealistic", help="Generation style")
    text_parser.add_argument("--image", dest="image_path", help="Optional reference image path")
    text_parser.add_argument("--base-url", default=DEFAULT_BASE_URL, help="Lux3D API base URL")
    text_parser.add_argument("--biz-type", dest="lux3d_biz_type", help="Optional business type")
    text_parser.add_argument("--max-attempts", type=int, default=DEFAULT_POLL_ATTEMPTS)
    text_parser.add_argument("--interval", type=int, default=DEFAULT_POLL_INTERVAL)

    return parser


def main():
    """CLI entrypoint."""
    parser = build_parser()
    args = parser.parse_args()

    # Keep the historical one-argument form for image-to-3D.
    if not args.command:
        if len(sys.argv) in (2, 3):
            image_path = sys.argv[1]
            output_path = sys.argv[2] if len(sys.argv) == 3 else None
            result = generate_3d_model(image_path, output_path=output_path)
            print(f"\n[SUCCESS] Model saved to: {result}")
            return
        parser.print_help()
        raise SystemExit(1)

    if args.command == "image":
        result = generate_3d_model(
            args.image_path,
            output_path=args.output_path,
            base_url=args.base_url,
            lux3d_biz_type=args.lux3d_biz_type,
            max_attempts=args.max_attempts,
            interval=args.interval,
        )
        print(f"\n[SUCCESS] Model saved to: {result}")
        return

    if args.command == "text":
        result = generate_text_to_3d(
            args.prompt,
            output_path=args.output_path,
            style=args.style,
            image_path=args.image_path,
            base_url=args.base_url,
            lux3d_biz_type=args.lux3d_biz_type,
            max_attempts=args.max_attempts,
            interval=args.interval,
        )
        print(f"\n[SUCCESS] Model saved to: {result}")
        return

    parser.print_help()
    raise SystemExit(1)


if __name__ == "__main__":
    try:
        main()
    except ValueError as exc:
        print(f"\n[ERROR] {exc}")
        raise SystemExit(1)
    except Exception as exc:
        print(f"\n[ERROR] {exc}")
        raise SystemExit(1)
