import datetime
import json

def generate_document(topic, doc_type="report", render_mode="typora_pro", depth="标准"):
    date = datetime.datetime.now().strftime("%Y-%m-%d")

    structure_map = {
        "report": [
            "行业背景",
            "市场现状",
            "竞争格局",
            "用户分析",
            "趋势预测",
            "结论建议"
        ],
        "analysis": [
            "问题定义",
            "数据拆解",
            "关键洞察",
            "结论"
        ],
        "sop": [
            "目标",
            "适用范围",
            "流程步骤",
            "注意事项"
        ],
        "brief": [
            "项目背景",
            "目标",
            "策略",
            "执行方案"
        ]
    }

    sections = structure_map.get(doc_type, structure_map["report"])

    doc = f"## {topic}\n\n"
    doc += f"<p style='text-align:center;'>自动生成文档</p>\n\n"

    doc += f"<div style='background:#e3f2fd; padding:10px;'>本报告围绕「{topic}」展开分析</div>\n\n"

    for sec in sections:
        doc += f"### {sec}\n\n"
        doc += f"- 内容生成中...\n\n"

    doc += f"<div style='background:linear-gradient(145deg,#bbdefb,#b2dfdb); padding:10px;'>总结内容</div>\n\n"
    doc += f"<p style='text-align:center; color:#777;'>Document Engine · {date}</p>"

    return doc


if __name__ == "__main__":
    result = generate_document("测试主题")
    print(result)