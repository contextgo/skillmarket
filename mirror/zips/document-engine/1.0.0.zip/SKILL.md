---
name: document-engine
description: 通用文档生成引擎，支持报告、分析、SOP、Brief等结构化Markdown输出，兼容Typora/GitHub/PDF
version: 2.0
author: Gervas
---

# 📄 Document Engine Skill

## 🧭 功能说明
本技能用于生成**高质量结构化 Markdown 文档**，支持：

- 市场调研报告
- 竞品分析
- 商业分析
- SOP流程文档
- Brief方案
- 任意主题结构化内容

---

## ⚙️ 渲染模式

```yaml
render_mode:
  typora_pro:   强视觉（推荐）
  github_safe:  兼容GitHub
  pure_md:      极简Markdown
```