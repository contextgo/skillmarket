# 工程升级模式库

> 常见的工程升级场景、策略选择与实施路径参考。

---

## 一、依赖升级

### 策略：小步快跑，优先安全

**依赖升级优先顺序**：
1. 安全漏洞（CVE）→ 立即升级，无论版本跨度
2. EOL（End of Life）框架/运行时 → 6 个月内完成
3. 落后 2 个大版本的核心依赖 → 纳入下个里程碑
4. 落后 1 个大版本 → 在功能迭代中顺带升级

**实施步骤**：
```
1. 运行 npm audit / pip-audit / snyk 生成依赖健康报告
2. 分级：安全漏洞 > EOL > 大版本落后 > 小版本落后
3. 为每个升级创建独立 PR/分支，避免混在功能开发中
4. 升级后运行完整测试套件，识别 breaking changes
5. 参考官方 Migration Guide 处理 breaking changes
```

**常见工具**：
- Node.js: `npm outdated`, `npx npm-check-updates`
- Python: `pip-audit`, `poetry show --outdated`
- Java: `mvn versions:display-dependency-updates`
- Go: `go list -m -u all`

---

## 二、技术栈迁移

### 模式：绞杀者模式（Strangler Fig Pattern）

最安全的迁移方式，核心思想：**新代码包裹旧代码，逐步替换，永远保持系统可运行**。

```
阶段 1：并存
  旧系统继续运行
  新代码在新目录/新分支中建立
  两套代码并行存在

阶段 2：路由切换
  通过 Feature Flag / API Gateway / 路由层
  逐步将流量从旧代码切换到新代码
  小模块先切，核心模块后切

阶段 3：删除旧代码
  确认新代码稳定后
  删除旧代码和兼容层
  完成迁移
```

**适用场景**：
- 前端框架迁移（jQuery → React，Vue 2 → Vue 3）
- 后端框架迁移（Express → Fastify，Flask → FastAPI）
- 单体 → 微服务（不推荐一次性拆分，逐模块剥离）

### 反模式：大爆炸重写（Big Bang Rewrite）

❌ **避免**：停止所有功能开发，全量重写，然后上线

风险：
- 重写期间业务需求继续累积，重写完成时已经落后
- 业务逻辑在重写中丢失（"隐性知识"无法完整迁移）
- 重写完成后发现新问题比解决的旧问题还多

---

## 三、架构改造

### 3.1 单体拆分为模块化单体（Modular Monolith）

**先做这个，再考虑微服务**。

步骤：
```
1. 识别业务领域边界（DDD 领域划分）
2. 在单体内建立清晰的模块目录（/modules/user, /modules/order）
3. 禁止模块间直接访问内部实现，只通过接口通信
4. 建立模块间依赖图，消除循环依赖
5. 为每个模块建立独立测试
```

### 3.2 从单体剥离微服务

**只在有明确理由时才做**（不同扩展需求、不同技术团队、不同发布节奏）。

正确剥离顺序：
```
1. 先在单体内实现模块化单体
2. 识别需要独立扩展的模块
3. 用 Strangler Fig 模式逐模块剥离
4. 建立服务间通信契约（API 契约测试）
5. 每次只剥离一个服务，验证稳定后再剥下一个
```

### 3.3 数据库重构

高风险操作，需要特别谨慎：

```
原则：
- 绝不做破坏性的 Schema 变更（直接改列名/删列）
- 采用扩展-迁移-清理三步法：
  Step 1: 新增字段/表（保留旧字段）
  Step 2: 双写新旧字段，迁移历史数据
  Step 3: 切换读取到新字段，确认无问题后删除旧字段

工具：
- Flyway / Liquibase（版本化 Schema 管理）
- 蓝绿部署保证回滚能力
```

---

## 四、代码质量提升

### 4.1 引入自动化质量门禁

```
最小可行质量工具链：
- Linter（ESLint / Pylint / golangci-lint）
- Formatter（Prettier / Black / gofmt）
- 类型检查（TypeScript / mypy）
- 测试覆盖率（Jest / pytest-cov）+ 覆盖率门槛
- Pre-commit Hook（自动在提交前运行上述检查）
```

### 4.2 遗留代码测试覆盖策略

接手无测试的存量代码时：

```
1. 不要追求 100% 覆盖率（成本过高）
2. 优先覆盖：核心业务逻辑 > 高频执行路径 > 历史 Bug 集中区域
3. 采用"特征测试"（Characterization Test）：
   - 先写测试验证现有行为（即使行为是错的）
   - 有了保护网，再做重构
4. 每次修复 Bug，先写测试复现 Bug，再修复
```

### 4.3 技术债管理

```
量化技术债：
- 统计 TODO/FIXME 数量和集中区域
- 用 SonarQube / CodeClimate 评估技术债指数
- 在 Bug 追踪系统（JIRA）中创建技术债 Epic

偿还策略：
- 童子军规则：让代码比你找到时更整洁（每次接触时顺手改一点）
- 20% 时间规则：每个 Sprint 留 20% 时间偿还技术债
- 技术债 Sprint：每季度一次专项治理 Sprint
```

---

## 五、性能优化路径

**先测量，再优化**。没有性能数据，不做优化决策。

```
步骤：
1. 建立性能基线（当前 P50/P95/P99 响应时间）
2. 用 Profiling 工具定位热路径（不靠猜）
3. 优先优化最热的 20% 代码（帕累托原则）
4. 每次优化后测量，确认改善再继续

常见高效优化（按 ROI 排序）：
1. 消除 N+1 查询（最高 ROI）
2. 添加数据库索引
3. 引入合理缓存（Redis/内存缓存）
4. 减少不必要的序列化/反序列化
5. 异步化非关键路径
6. 算法复杂度优化（O(n²) → O(n log n)）
```

---

## 六、运行时/语言版本升级

| 场景 | 建议策略 |
|------|----------|
| Node.js LTS 升级 | 每年 10 月 Node.js 新 LTS 发布后，3 个月内完成升级 |
| Python 大版本升级 | 用 `pyupgrade` 工具自动化语法升级 |
| Java 版本升级 | 先升到最近 LTS（11→17→21），不要跳跃升级 |
| 操作系统/容器基础镜像 | 固定版本标签，定期重建镜像获取安全补丁 |

**升级前必做**：
1. 在 CI 中临时增加新版本运行时的并行测试
2. 确认所有依赖支持新版本
3. 灰度发布（10% → 50% → 100%）

---

## 七、前端工程升级专项

### 7.1 构建工具迁移（Webpack → Vite）

适用场景：构建速度慢（> 30s）、HMR 迟缓、配置复杂难以维护。

```
迁移步骤：
1. 评估兼容性：检查 webpack-specific loader 是否有 Vite 等价替换
2. 创建 vite.config.ts，并行存在（不删除 webpack 配置）
3. 解决路径别名（@ 别名）、env 变量注入、静态资源处理差异
4. 迁移 CSS 方案（CSS Modules / PostCSS / Tailwind 均有官方支持）
5. 处理 CommonJS 依赖（Vite 默认 ESM，需用 vite-plugin-commonjs）
6. 验证生产构建产物大小和加载性能

常见坑：
- require() 语法在 Vite 中不支持，需改为 import()
- process.env.XXX 需改为 import.meta.env.VITE_XXX
- Glob import 语法不同（Vite 使用 import.meta.glob）
```

### 7.2 前端框架版本升级

**Vue 2 → Vue 3**：
```
工具：@vue/compat（兼容模式，允许 Vue 2/3 代码并存）
关键变化：
- Options API → Composition API（不强制，但推荐迁移）
- $children 移除、$listeners 合并到 $attrs
- v-model 语法变化（多 v-model 支持）
- 过滤器（filter）移除 → 改用 computed 或方法
迁移顺序：依赖库（vue-router/vuex/pinia）→ 组件 → 删除兼容模式
```

**React 16/17 → React 18**：
```
关键变化：
- 自动批处理（Automatic Batching）：setTimeout 中的 setState 也会批处理
- 并发模式：createRoot 替换 ReactDOM.render
- Suspense 增强：支持服务端渲染
- useId：生成稳定的唯一 ID

升级风险：
- 严格模式下 useEffect 会执行两次（开发环境），用于检测副作用
- 第三方库需确认兼容 React 18
```

### 7.3 CSS 方案升级

| 从 | 到 | 理由 |
|----|----|----|
| 全局 CSS | CSS Modules | 消除样式命名冲突 |
| Less/Sass | Tailwind CSS | 减少自定义 CSS 维护成本（适合组件化项目） |
| 手写响应式 | Tailwind 断点 | 统一断点标准 |
| CSS-in-JS (styled-components) | Tailwind / CSS Modules | 减少运行时开销 |

### 7.4 前端状态管理升级

```
Redux → Zustand/Jotai（简单场景）：
- 减少样板代码 80%+
- 无需 Provider 包裹
- 适合中小型应用

Vuex → Pinia：
- Vue 官方推荐替代
- TypeScript 支持更好
- 移除 mutations 概念，更简洁
- 支持 Composition API 风格
```

### 7.5 前端性能专项

```
Core Web Vitals 优化优先级：
1. LCP（最大内容绘制）< 2.5s
   - 图片懒加载 + 预加载关键图片
   - 服务端渲染关键屏内容

2. FID/INP（交互响应延迟）< 100ms
   - 减少主线程长任务（Long Tasks > 50ms）
   - 代码分割，按需加载

3. CLS（累积布局偏移）< 0.1
   - 图片/视频设置 width/height 属性
   - 避免动态插入影响布局的内容

工具链：
- Lighthouse CI：在 CI 中自动跑性能测试
- Bundle Analyzer：可视化分析产物大小
- React DevTools Profiler：定位渲染瓶颈
```

---

## 八、AI/ML 项目工程升级专项

### 8.1 Python 依赖管理升级

```
从 pip + requirements.txt 迁移到 Poetry 或 uv：

Poetry 优势：
- 依赖解析更可靠（避免版本冲突）
- 区分开发依赖和生产依赖
- 内置虚拟环境管理
- poetry.lock 保证可复现构建

uv 优势（2024+ 推荐）：
- 比 pip 快 10-100x
- 兼容 pip 接口
- Rust 编写，跨平台一致性好

迁移步骤：
1. pip freeze > requirements.txt（备份）
2. 安装 poetry / uv
3. poetry init 或 uv init
4. 逐步迁移依赖，验证功能
5. 删除 requirements.txt，统一用 pyproject.toml
```

### 8.2 模型版本管理

```
问题：模型文件大、二进制、难以用 Git 管理。

方案：
1. DVC（Data Version Control）
   - 模型文件存 S3/OSS，代码仓只存元数据指针
   - dvc pull 拉取对应版本模型
   - 与 Git 集成，代码和模型版本一一对应

2. MLflow Model Registry
   - 模型实验跟踪 + 版本管理
   - 支持 Staging/Production 阶段管理
   - 提供模型 API 服务

3. Hugging Face Hub（开源模型）
   - 标准化模型卡片（Model Card）
   - 内置版本控制
```

### 8.3 训练/推理环境隔离

```
常见问题：
- 训练环境 CUDA 版本与推理环境不一致
- 依赖版本在不同机器上不一致
- "在我本地能跑"问题

解决方案：
- Docker 镜像固定 CUDA + Python + 关键库版本
- 使用 nvidia/cuda 官方基础镜像
- 在 CI 中验证镜像可复现构建

Dockerfile 最佳实践：
  FROM nvidia/cuda:12.1-cudnn8-runtime-ubuntu22.04
  RUN pip install uv
  COPY pyproject.toml .
  RUN uv sync --no-dev
```

### 8.4 推理服务工程化

```
从 Flask/FastAPI 脚本 → 生产级推理服务：

1. 添加健康检查接口（/health, /ready）
2. 请求批处理（Dynamic Batching）提升吞吐
3. 模型预热（Warm-up）避免首请求延迟
4. 并发控制（防止 OOM）
5. 接入监控（推理延迟、GPU 利用率、错误率）

推荐框架：
- BentoML：Python 原生，易上手
- Triton Inference Server：高性能，支持多框架
- Ray Serve：分布式，适合复杂 DAG
```
