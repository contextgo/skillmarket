#!/usr/bin/env bash
# =============================================================================
# explore.sh — 存量项目快速摸底脚本
# 用法：bash explore.sh [项目根目录]  (不传则使用当前目录)
# 输出：项目现状快照，供第一性原理分析使用
# =============================================================================

PROJECT_DIR="${1:-.}"
cd "$PROJECT_DIR" || { echo "❌ 目录不存在: $PROJECT_DIR"; exit 1; }

echo "================================================================"
echo "  存量项目摸底报告"
echo "  路径: $(pwd)"
echo "  时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "================================================================"

# ----------------------------------------------------------------------------
# 1. 目录结构（前2层）
# ----------------------------------------------------------------------------
echo ""
echo "━━━ 1. 项目结构（前2层）━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if command -v tree &>/dev/null; then
    tree -L 2 -I "node_modules|.git|__pycache__|.venv|dist|build|*.egg-info" --dirsfirst
else
    find . -maxdepth 2 \
        ! -path "*/node_modules/*" \
        ! -path "*/.git/*" \
        ! -path "*/__pycache__/*" \
        ! -path "*/.venv/*" \
        ! -path "*/dist/*" \
        ! -path "*/build/*" \
        -print | sort
fi

# ----------------------------------------------------------------------------
# 2. 技术栈识别
# ----------------------------------------------------------------------------
echo ""
echo "━━━ 2. 技术栈识别 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Node.js
if [ -f "package.json" ]; then
    echo "【Node.js 项目】"
    echo "  Node 版本要求: $(node -e "const p=require('./package.json'); console.log(p.engines?.node || '未指定')" 2>/dev/null)"
    echo "  主要依赖数量:  $(node -e "const p=require('./package.json'); const d=Object.keys(p.dependencies||{}).length; const dd=Object.keys(p.devDependencies||{}).length; console.log('生产=' + d + ' 开发=' + dd)" 2>/dev/null)"
    echo "  框架识别:"
    node -e "
const p = require('./package.json');
const all = {...(p.dependencies||{}), ...(p.devDependencies||{})};
const frameworks = {
  'react': 'React', 'next': 'Next.js', 'vue': 'Vue', 'nuxt': 'Nuxt',
  'angular': 'Angular', 'svelte': 'Svelte', 'express': 'Express',
  'fastify': 'Fastify', 'koa': 'Koa', 'nestjs/core': 'NestJS',
  'electron': 'Electron', 'vite': 'Vite', 'webpack': 'Webpack',
  'typescript': 'TypeScript', 'jest': 'Jest', 'vitest': 'Vitest',
  'tailwindcss': 'Tailwind CSS', 'prisma': 'Prisma', 'sequelize': 'Sequelize',
  'svelte-kit': 'SvelteKit', '@remix-run/react': 'Remix', 'astro': 'Astro',
  'taro': 'Taro', 'uni-app': 'uni-app', 'supabase': 'Supabase'
};
Object.entries(frameworks).forEach(([k,v]) => {
  if (all[k] || all['@'+k]) console.log('    ✓ ' + v + ': ' + (all[k]||all['@'+k]));
});
" 2>/dev/null

    # 现代框架路由/页面结构检测
    echo ""
    echo "  框架特定结构:"
    [ -d "app" ] && echo "    ✓ app/ 目录存在（可能是 Next.js App Router / Nuxt 3）"
    [ -d "pages" ] && echo "    ✓ pages/ 目录存在（可能是 Next.js Pages Router / Nuxt 2）"
    [ -d "src/routes" ] && echo "    ✓ src/routes/ 存在（可能是 SvelteKit / Remix）"
    [ -d "src/app" ] && echo "    ✓ src/app/ 存在"
    [ -d "server" ] && echo "    ✓ server/ 目录存在（后端逻辑）"
    [ -d "server/api" ] && echo "    ✓ server/api/ 存在（API 路由）"
    [ -d "api" ] && echo "    ✓ api/ 目录存在（API 路由）"
    [ -d "middleware" ] && echo "    ✓ middleware/ 目录存在"
    [ -d "store" ] && echo "    ✓ store/ 目录存在（状态管理）"
    [ -d "composables" ] && echo "    ✓ composables/ 存在（Vue Composables）"
    [ -d "hooks" ] && echo "    ✓ hooks/ 目录存在（React Hooks）"
    [ -f "next.config.js" ] || [ -f "next.config.ts" ] || [ -f "next.config.mjs" ] && echo "    ✓ Next.js 配置文件存在"
    [ -f "nuxt.config.ts" ] || [ -f "nuxt.config.js" ] && echo "    ✓ Nuxt 配置文件存在"
    [ -f "svelte.config.js" ] && echo "    ✓ SvelteKit 配置文件存在"
    [ -f "vite.config.ts" ] || [ -f "vite.config.js" ] && echo "    ✓ Vite 配置文件存在"
    [ -f "electron/main.ts" ] || [ -f "electron/main.js" ] && echo "    ✓ Electron 主进程入口存在"
fi

# Python
if [ -f "requirements.txt" ] || [ -f "pyproject.toml" ] || [ -f "setup.py" ]; then
    echo "【Python 项目】"
    python3 --version 2>/dev/null || python --version 2>/dev/null
    if [ -f "requirements.txt" ]; then
        echo "  依赖数量: $(wc -l < requirements.txt | tr -d ' ') 条"
        echo "  关键依赖:"
        grep -iE "^(django|flask|fastapi|torch|tensorflow|numpy|pandas|sqlalchemy|celery|redis|boto)" requirements.txt 2>/dev/null | head -10 | sed 's/^/    /'
    fi
    if [ -f "pyproject.toml" ]; then
        echo "  pyproject.toml 存在（poetry/flit 项目）"
    fi
fi

# Go
if [ -f "go.mod" ]; then
    echo "【Go 项目】"
    head -3 go.mod
fi

# Java
if [ -f "pom.xml" ]; then
    echo "【Java/Maven 项目】"
    grep -m1 "<java.version>" pom.xml 2>/dev/null | sed 's/.*>\(.*\)<.*/  Java 版本: \1/'
    grep -m1 "<spring-boot.version>\|spring-boot-starter-parent" pom.xml 2>/dev/null | head -1 | sed 's/^/  /'
fi
if [ -f "build.gradle" ] || [ -f "build.gradle.kts" ]; then
    echo "【Java/Gradle 项目】"
fi

# Docker
if [ -f "Dockerfile" ] || [ -f "docker-compose.yml" ] || [ -f "docker-compose.yaml" ]; then
    echo "【容器化】"
    [ -f "Dockerfile" ] && echo "  ✓ Dockerfile 存在"
    [ -f "docker-compose.yml" ] || [ -f "docker-compose.yaml" ] && echo "  ✓ docker-compose 存在"
fi

# ----------------------------------------------------------------------------
# 3. 代码规模
# ----------------------------------------------------------------------------
echo ""
echo "━━━ 3. 代码规模估算 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

count_lines() {
    local ext="$1"
    local label="$2"
    local count
    count=$(find . \
        ! -path "*/node_modules/*" \
        ! -path "*/.git/*" \
        ! -path "*/__pycache__/*" \
        ! -path "*/.venv/*" \
        ! -path "*/dist/*" \
        ! -path "*/build/*" \
        ! -path "*/coverage/*" \
        -name "$ext" -exec cat {} \; 2>/dev/null | wc -l | tr -d ' ')
    [ "$count" -gt 0 ] 2>/dev/null && echo "  $label: ${count} 行"
}

count_lines "*.ts"  "TypeScript (.ts)"
count_lines "*.tsx" "TypeScript React (.tsx)"
count_lines "*.js"  "JavaScript (.js)"
count_lines "*.jsx" "JavaScript React (.jsx)"
count_lines "*.py"  "Python (.py)"
count_lines "*.go"  "Go (.go)"
count_lines "*.java" "Java (.java)"
count_lines "*.rs"  "Rust (.rs)"

# 文件数量
echo ""
echo "  文件数量统计（不含 node_modules/.git）:"
for ext in ts tsx js jsx py go java rs vue svelte; do
    n=$(find . ! -path "*/node_modules/*" ! -path "*/.git/*" ! -path "*/__pycache__/*" ! -path "*/.venv/*" ! -path "*/dist/*" ! -path "*/build/*" -name "*.${ext}" 2>/dev/null | wc -l | tr -d ' ')
    [ "$n" -gt 0 ] && echo "    .${ext}: ${n} 个文件"
done

# ----------------------------------------------------------------------------
# 4. Git 历史健康度
# ----------------------------------------------------------------------------
echo ""
echo "━━━ 4. Git 历史健康度 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if git rev-parse --git-dir &>/dev/null; then
    echo "  总提交数:    $(git rev-list --count HEAD 2>/dev/null)"
    echo "  贡献者数:    $(git shortlog -sn --no-merges 2>/dev/null | wc -l | tr -d ' ')"
    echo "  最近一次提交: $(git log -1 --format='%ar  %s' 2>/dev/null)"
    echo "  最早一次提交: $(git log --reverse --format='%ar' 2>/dev/null | head -1)"
    echo "  最近10条提交:"
    git log --oneline -10 2>/dev/null | sed 's/^/    /'
    echo ""
    echo "  提交信息质量（识别无意义提交）:"
    bad=$(git log --oneline --no-merges 2>/dev/null | grep -iE "^\w+ (fix|update|change|modify|temp|wip|test|ok|done|xxx|aaa|111)$" | wc -l | tr -d ' ')
    total=$(git rev-list --count HEAD 2>/dev/null)
    echo "    无意义提交: ${bad} / ${total} ($(( total > 0 ? bad*100/total : 0 ))%)"
else
    echo "  ⚠️  不是 Git 仓库或无提交历史"
fi

# ----------------------------------------------------------------------------
# 5. 工程规范检查
# ----------------------------------------------------------------------------
echo ""
echo "━━━ 5. 工程规范快速检查 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

check_file() {
    local file="$1"
    local label="$2"
    local critical="${3:-false}"
    if [ -f "$file" ] || [ -d "$file" ]; then
        echo "  ✅ $label ($file)"
    else
        local prefix="  ⚠️ "
        [ "$critical" = "true" ] && prefix="  🔴 "
        echo "${prefix}缺少 $label ($file)"
    fi
}

check_file "README.md"           "README 文档"           true
check_file ".gitignore"          ".gitignore"
check_file "package-lock.json"   "依赖锁文件 (npm)"
check_file "yarn.lock"           "依赖锁文件 (yarn)"
check_file "pnpm-lock.yaml"      "依赖锁文件 (pnpm)"
check_file "poetry.lock"         "依赖锁文件 (poetry)"
check_file ".env.example"        "环境变量示例"
check_file ".eslintrc*"          "ESLint 配置"
check_file "eslint.config.*"     "ESLint flat config (新版)"
check_file "tsconfig.json"       "TypeScript 配置"
check_file "jest.config*"        "Jest 配置"
check_file "vitest.config*"      "Vitest 配置"
check_file ".editorconfig"       "EditorConfig"
check_file ".prettierrc*"        "Prettier 配置"
check_file ".github/workflows"   "CI/CD (GitHub Actions)"
check_file ".gitlab-ci.yml"      "CI/CD (GitLab CI)"
check_file "Makefile"            "Makefile"
check_file "CHANGELOG.md"        "变更日志"

# 检查 .env 是否意外提交
if git rev-parse --git-dir &>/dev/null; then
    if git ls-files .env 2>/dev/null | grep -q "^\.env$"; then
        echo "  🔴 危险：.env 文件已被 Git 追踪（可能泄露密钥）"
    fi
    if git ls-files 2>/dev/null | grep -q "\.env\."; then
        echo "  🟡 警告：.env.* 文件被 Git 追踪（.env.local 等）"
    fi
fi

# 额外工程规范检查
check_file "husky"              "Git Hooks (husky)"
check_file ".husky"             "Git Hooks (.husky)"
check_file ".npmrc"             "npm 配置"
check_file ".dockerignore"      "Docker .dockerignore"
check_file ".nvmrc"             "Node 版本管理 (.nvmrc)"
check_file ".node-version"      "Node 版本管理 (.node-version)"
check_file "dockerignore"       "Docker ignore (旧格式)"

# TypeScript 严格模式检查
if [ -f "tsconfig.json" ]; then
    strict=$(grep -o '"strict"[[:space:]]*:[[:space:]]*true' tsconfig.json 2>/dev/null)
    if [ -n "$strict" ]; then
        echo "  ✅ TypeScript strict 模式已启用"
    else
        echo "  🟡 TypeScript strict 模式未启用（建议开启以获得更强类型安全）"
    fi
fi

# ----------------------------------------------------------------------------
# 6. 技术债快速扫描
# ----------------------------------------------------------------------------
echo ""
echo "━━━ 6. 技术债快速扫描 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

scan_keyword() {
    local keyword="$1"
    local label="$2"
    local count
    count=$(grep -r "$keyword" . \
        --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" \
        --include="*.py" --include="*.go" --include="*.java" \
        --exclude-dir=node_modules --exclude-dir=.git \
        --exclude-dir=dist --exclude-dir=build --exclude-dir=__pycache__ \
        2>/dev/null | wc -l | tr -d ' ')
    echo "  $label: ${count} 处"
}

scan_keyword "TODO"     "TODO"
scan_keyword "FIXME"    "FIXME"
scan_keyword "HACK"     "HACK"
scan_keyword "XXX"      "XXX (通常是问题标记)"
scan_keyword "any"      "TypeScript any 类型使用"
scan_keyword "console.log" "console.log（未清理的调试日志）"
scan_keyword "print("   "print()（未清理的调试输出）"
scan_keyword "@ts-ignore"  "TypeScript @ts-ignore（类型抑制）"
scan_keyword "@ts-nocheck" "TypeScript @ts-nocheck（全文件类型跳过）"

# ----------------------------------------------------------------------------
# 7. 依赖健康快速检查
# ----------------------------------------------------------------------------
echo ""
echo "━━━ 7. 依赖健康快速检查 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Node.js 依赖检查
if [ -f "package.json" ] && command -v npm &>/dev/null; then
    outdated=$(npm outdated --json 2>/dev/null | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    deps = data.get('dependencies', {}) or {}
    devDeps = data.get('devDependencies', {}) or {}
    all_deps = {**deps, **devDeps}
    if not all_deps:
        print('0')
        sys.exit(0)
    major = sum(1 for v in all_deps.values() if v.get('latest') and v['current'] != 'missing' and v.get('latest','').split('.')[0] != v.get('current','').split('.')[0])
    print(str(len(all_deps)) + ' total, ' + str(major) + ' major behind')
except:
    print('check failed')
" 2>/dev/null)
    echo "  npm 依赖: $outdated"

    # 检查安全漏洞
    vulns=$(npm audit --json 2>/dev/null | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    meta = data.get('metadata', {})
    v = meta.get('vulnerabilities', {})
    total = sum(info.get('count', 0) for info in v.values())
    if total > 0:
        critical = sum(info.get('count', 0) for sev, info in v.items() if info.get('severity') == 'critical')
        high = sum(info.get('count', 0) for sev, info in v.items() if info.get('severity') == 'high')
        result = str(total) + ' vulnerabilities'
        if critical > 0:
            result += ' (' + str(critical) + ' critical, ' + str(high) + ' high)'
        print(result)
    else:
        print('no known vulnerabilities')
except:
    print('check skipped')
" 2>/dev/null)
    echo "  npm audit: $vulns"
fi

# Python 依赖检查
if [ -f "requirements.txt" ] && command -v pip3 &>/dev/null; then
    echo "  pip 依赖: $(wc -l < requirements.txt | tr -d ' ') packages"
fi

# ----------------------------------------------------------------------------
# 8. 模块复杂度热点
# ----------------------------------------------------------------------------
echo ""
echo "━━━ 8. 模块复杂度热点（最大文件 TOP 10）━━━━━━━━━━━━━━━━━━━━━━━━━━"

for ext in ts tsx js jsx py go java; do
    largest=$(find . \
        ! -path "*/node_modules/*" \
        ! -path "*/.git/*" \
        ! -path "*/__pycache__/*" \
        ! -path "*/.venv/*" \
        ! -path "*/dist/*" \
        ! -path "*/build/*" \
        ! -path "*/coverage/*" \
        -name "*.${ext}" -exec wc -l {} \; 2>/dev/null | sort -rn | head -5)
    if [ -n "$largest" ]; then
        echo "  .${ext} 最大文件:"
        echo "$largest" | while read -r count file; do
            [ -n "$count" ] && [ "$count" -gt 200 ] 2>/dev/null && echo "    🔴 $count 行  $file"
            [ -n "$count" ] && [ "$count" -le 200 ] 2>/dev/null && [ "$count" -gt 100 ] 2>/dev/null && echo "    🟡 $count 行  $file"
            [ -n "$count" ] && [ "$count" -le 100 ] 2>/dev/null && echo "    🟢 $count 行  $file"
        done
    fi
done

echo ""
echo "━━━ 扫描完成 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  下一步：将以上输出交给 first-principles-refactor Skill 进行深度分析"
echo "================================================================"
