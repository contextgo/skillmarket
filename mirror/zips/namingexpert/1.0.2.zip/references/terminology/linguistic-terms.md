# 语言学术语 / Linguistic Terminology

## 目录 / Table of Contents

1. [语义学 / Semantics](#语义学)
2. [音韵学 / Phonetics](#音韵学)
3. [符号学 / Semiotics](#符号学)
4. [语用学 / Pragmatics](#语用学)

---

## 语义学 / Semantics

### 字义 / Character Meaning

#### 定义 / Definition

字义是指单个汉字所具有的含义，包括本义、引申义、比喻义等。

Character meaning refers to the meaning carried by a single Chinese character, including original meaning, extended meaning, figurative meaning, etc.

#### 类型 / Types

1. **本义 / Original Meaning**：
   - 字的最初含义 / The original meaning of a character
   - 示例："道"的本义是"道路" / Example: The original meaning of "道" is "road"
   - 引申为"道理、方法" / Extended to "reason, method"

2. **引申义 / Extended Meaning**：
   - 由本义衍生出来的含义 / Meaning derived from the original meaning
   - 示例："天"的本义是"天空" / Example: The original meaning of "天" is "sky"
   - 引申为"自然、至上" / Extended to "nature, supreme"

3. **比喻义 / Figurative Meaning**：
   - 通过比喻手法产生的含义 / Meaning produced through metaphor
   - 示例："云"本义是"云彩" / Example: The original meaning of "云" is "cloud"
   - 比喻为"网络" / Figuratively means "network"

#### 命名应用 / Naming Application

- 选择字义积极的字 / Choose characters with positive meanings
- 避免字义模糊或负面的字 / Avoid characters with vague or negative meanings
- 考虑字义与品牌定位的契合度 / Consider the fit between character meaning and brand positioning

---

### 词义 / Word Meaning

#### 定义 / Definition

词义是指词所表示的概念和意义，包括概念意义、联想意义等。

Word meaning refers to the concept and meaning expressed by a word, including conceptual meaning, associative meaning, etc.

#### 类型 / Types

1. **概念意义 / Conceptual Meaning**：
   - 词所表示的基本概念 / The basic concept represented by a word
   - 示例："智"的概念意义是"智慧" / Example: The conceptual meaning of "智" is "wisdom"

2. **联想意义 / Associative Meaning**：
   - 词所引发的联想和情感 / The associations and emotions triggered by a word
   - 示例："海"的联想意义是"宽广、深邃" / Example: The associative meaning of "海" is "broad, deep"

3. **情感意义 / Emotional Meaning**：
   - 词所携带的情感色彩 / The emotional color carried by a word
   - 示例："爱"的情感意义是"温暖、关怀" / Example: The emotional meaning of "爱" is "warm, caring"

#### 命名应用 / Naming Application

- 选择词义积极的词 / Choose words with positive meanings
- 考虑词的联想意义和情感意义 / Consider the associative and emotional meanings of words
- 避免词义冲突或混乱 / Avoid conflicting or confusing word meanings

---

### 语义场 / Semantic Field

#### 定义 / Definition

语义场是指意义相近、相关的词汇构成的集合。

A semantic field is a collection of words with similar and related meanings.

#### 示例 / Examples

1. **科技语义场 / Technology Semantic Field**：
   - 智、能、技、术、科、学 / Wisdom, ability, technique, art, science, learning

2. **自然语义场 / Nature Semantic Field**：
   - 山、水、风、云、日、月 / Mountain, water, wind, cloud, sun, moon

3. **美好语义场 / Beauty Semantic Field**：
   - 美、雅、优、佳、精、良 / Beauty, elegance, excellence, goodness, precision, goodness

#### 命名应用 / Naming Application

- 从语义场中选择词汇 / Choose vocabulary from semantic fields
- 确保词义的一致性和连贯性 / Ensure consistency and coherence of word meanings
- 创造语义场的延伸和扩展 / Create extensions and expansions of semantic fields

---

### 语义网络 / Semantic Network

#### 定义 / Definition

语义网络是指词汇之间的语义关联形成的网络结构。

A semantic network is a network structure formed by semantic associations between words.

#### 示例 / Examples

```
智
├── 智慧
├── 智能
├── 智能化
│   ├── 智能手机
│   ├── 智能家居
│   └── 智能汽车
└── 智慧城市
```

#### 命名应用 / Naming Application

- 利用语义网络创造品牌故事 / Use semantic networks to create brand stories
- 通过语义网络扩展品牌意义 / Extend brand meaning through semantic networks
- 确保品牌命名的语义连贯性 / Ensure semantic coherence of brand naming

---

## 音韵学 / Phonetics

### 声母 / Initial

#### 定义 / Definition

声母是汉语音节开头的辅音。

The initial is the consonant at the beginning of a Chinese syllable.

#### 分类 / Classification

1. **双唇音 / Bilabial**：b, p, m
2. **唇齿音 / Labiodental**：f
3. **舌尖前音 / Apical**：z, c, s
4. **舌尖后音 / Retroflex**：zh, ch, sh, r
5. **舌面音 / Palatal**：j, q, x
6. **舌根音 / Velar**：g, k, h
7. **零声母 / Zero Initial**：无声母的音节 / Syllables without initials

#### 命名应用 / Naming Application

- 选择发音部位适合的声母 / Choose initials with suitable articulation positions
- 考虑声母的音韵效果 / Consider the phonetic effect of initials
- 避免声母重复过多 / Avoid too much repetition of initials

---

### 韵母 / Final

#### 定义 / Definition

韵母是汉语音节中声母后面的部分，包括韵头、韵腹、韵尾。

The final is the part after the initial in a Chinese syllable, including medial, nucleus, and coda.

#### 分类 / Classification

1. **开口呼 / Open Mouth (Kāi Kǒu Hū)**：a, o, e, ai, ei, ao, ou, an, en, ang, eng
2. **齐齿呼 / Front Vowel (Qí Chǐ Hū)**：i, ia, ie, iao, iou, ian, in, iang, ing
3. **合口呼 / Round Lips (Hé Kǒu Hū)**：u, ua, uo, uai, uei, uan, un, uang, ong
4. **撮口呼 / Pursed Lips (Cuō Kǒu Hū)**：ü, üe, üan, ün

#### 命名应用 / Naming Application

- 选择开口度适合的韵母 / Choose vowels with suitable openness
- 考虑韵母的音韵效果 / Consider the phonetic effect of vowels
- 避免韵母冲突 / Avoid vowel conflicts

---

### 声调 / Tone

#### 定义 / Definition

声调是汉语音节的高低升降变化。

Tone is the pitch change of a Chinese syllable.

#### 分类 / Classification

1. **第一声 / First Tone (Yīn Píng)**：阴平，高平调 / Yin Ping, high level tone
   - 示例：妈 (mā)、天 (tiān)、飞 (fēi) / Examples: 妈 (mā), 天 (tiān), 飞 (fēi)

2. **第二声 / Second Tone (Yáng Píng)**：阳平，升调 / Yang Ping, rising tone
   - 示例：麻 (má)、田 (tián)、肥 (féi) / Examples: 麻 (má), 田 (tián), 肥 (féi)

3. **第三声 / Third Tone (Shǎng Shēng)**：上声，降升调 / Shang Sheng, falling-rising tone
   - 示例：马 (mǎ)、天 (tiǎn)、翡 (fěi) / Examples: 马 (mǎ), 天 (tiǎn), 翡 (fěi)

4. **第四声 / Fourth Tone (Qù Shēng)**：去声，降调 / Qu Sheng, falling tone
   - 示例：骂 (mà)、田 (tiàn)、废 (fèi) / Examples: 骂 (mà), 田 (tiàn), 废 (fèi)

#### 命名应用 / Naming Application

- 选择声调组合优美的音节 / Choose syllables with beautiful tone combinations
- 考虑平仄搭配 / Consider the combination of level (Ping) and oblique (Ze) tones
- 避免声调单一 / Avoid monotone tones

---

### 平仄 / Level and Oblique Tones

#### 定义 / Definition

平仄是指汉语声调的分类，平声为平，仄声为仄。

Level and oblique refer to the classification of Chinese tones, level tones are "Ping", oblique tones are "Ze".

#### 分类 / Classification

1. **平声 / Level (Ping)**：
   - 第一声（阴平） / First tone (Yin Ping)
   - 第二声（阳平） / Second tone (Yang Ping)
   - 特点：声调平缓、舒缓 / Characteristics: gentle, smooth

2. **仄声 / Oblique (Ze)**：
   - 第三声（上声） / Third tone (Shang Sheng)
   - 第四声（去声） / Fourth tone (Qu Sheng)
   - 特点：声调起伏、有力 / Characteristics: undulating, powerful

#### 常见平仄组合 / Common Tone Combinations

1. **平平 / Ping-Ping**：平缓、柔和 / Gentle, soft
   - 示例：春天 (chūn tiān) / Example: 春天 (chūn tiān)

2. **仄仄 / Ze-Ze**：有力、现代 / Powerful, modern
   - 示例：智慧 (zhì huì) / Example: 智慧 (zhì huì)

3. **平仄 / Ping-Ze**：平衡、和谐 / Balanced, harmonious
   - 示例：山水 (shān shuǐ) / Example: 山水 (shān shuǐ)

4. **仄平 / Ze-Ping**：有起伏、有活力 / Undulating, energetic
   - 示例：科技 (kē jì) / Example: 科技 (kē jì)

#### 命名应用 / Naming Application

- 选择适合品牌定位的平仄组合 / Choose tone combination suitable for brand positioning
- 考虑平仄搭配的音韵效果 / Consider the phonetic effect of tone combinations
- 避免平仄搭配混乱 / Avoid confusing tone combinations

---

## 符号学 / Semiotics

### 能指 / Signifier

#### 定义 / Definition

能指是符号的物质形式，包括语音、文字等。

The signifier is the material form of a sign, including sound, text, etc.

#### 示例 / Examples

- "智"字的能指是"zhì"这个发音和"智"这个字形 / The signifier of "智" is the pronunciation "zhì" and the character "智"
- "Apple"的能指是"Apple"这个单词 / The signifier of "Apple" is the word "Apple"

#### 命名应用 / Naming Application

- 选择能指优美的名称 / Choose names with beautiful signifiers
- 考虑能指的视觉和听觉效果 / Consider the visual and auditory effects of signifiers
- 确保能指的独特性 / Ensure the uniqueness of signifiers

---

### 所指 / Signified

#### 定义 / Definition

所指是符号所表示的概念和意义。

The signified is the concept and meaning represented by a sign.

#### 示例 / Examples

- "智"字的所指是"智慧、聪明" / The signified of "智" is "wisdom, cleverness"
- "Apple"的所指是"苹果" / The signified of "Apple" is "apple"

#### 命名应用 / Naming Application

- 确保所指积极、正面 / Ensure positive and favorable signifieds
- 考虑所指与品牌定位的契合度 / Consider the fit between signified and brand positioning
- 避免所指模糊或负面 / Avoid vague or negative signifieds

---

### 符号组合规则 / Sign Combination Rules

#### 定义 / Definition

符号组合规则是指符号之间的组合方式和逻辑。

Sign combination rules refer to the combination methods and logic between signs.

#### 示例 / Examples

1. **并列组合 / Parallel Combination**：
   - 智 + 跃 = 智跃 / Wisdom + Leap = SmartLeap
   - 两个符号并列，共同构成新意义 / Two signs in parallel, jointly creating new meaning

2. **主谓组合 / Subject-Predicate Combination**：
   - 云 + 动 = 云动 / Cloud + Move = CloudMotion
   - 前一个符号是主语，后一个符号是谓语 / The first sign is the subject, the second is the predicate

3. **偏正组合 / Modifier-Head Combination**：
   - 智 + 城 = 智城 / Smart + City = SmartCity
   - 前一个符号修饰后一个符号 / The first sign modifies the second sign

#### 命名应用 / Naming Application

- 利用符号组合规则创造新名称 / Use sign combination rules to create new names
- 确保符号组合的逻辑性 / Ensure the logic of sign combinations
- 避免符号组合混乱 / Avoid confusing sign combinations

---

## 语用学 / Pragmatics

### 语用含义 / Pragmatic Meaning

#### 定义 / Definition

语用含义是指语言在特定语境中产生的实际意义。

Pragmatic meaning refers to the actual meaning produced by language in a specific context.

#### 示例 / Examples

1. **时间语境 / Temporal Context**：
   - "云"在古代语境中指"云彩" / "云" in ancient context refers to "cloud"
   - "云"在现代语境中指"云计算" / "云" in modern context refers to "cloud computing"

2. **文化语境 / Cultural Context**：
   - "龙"在中国文化中象征"吉祥、权威" / "龙" in Chinese culture symbolizes "auspiciousness, authority"
   - "龙"在西方文化中可能象征"邪恶" / "龙" in Western culture may symbolize "evil"

#### 命名应用 / Naming Application

- 考虑语用含义与语境的适配性 / Consider the adaptability of pragmatic meaning to context
- 避免语用含义冲突 / Avoid conflicting pragmatic meanings
- 确保语用含义的积极性和正面性 / Ensure positive and favorable pragmatic meanings

---

### 语用推理 / Pragmatic Inference

#### 定义 / Definition

语用推理是指根据语境和背景知识，推断语言的实际含义。

Pragmatic inference refers to inferring the actual meaning of language based on context and background knowledge.

#### 示例 / Examples

1. **行业语境推理 / Industry Context Inference**：
   - 看到"芯"字，推断可能与"芯片"相关 / Seeing "芯", infer it may be related to "chips"
   - 看到"云"字，推断可能与"云计算"相关 / Seeing "云", infer it may be related to "cloud computing"

2. **文化语境推理 / Cultural Context Inference**：
   - 看到"龙"字，推断可能代表"权威、吉祥" / Seeing "龙", infer it may represent "authority, auspiciousness"
   - 看到"凤"字，推断可能代表"美好、高贵" / Seeing "凤", infer it may represent "beauty, nobility"

#### 命名应用 / Naming Application

- 考虑用户可能的语用推理 / Consider possible pragmatic inferences by users
- 确保语用推理与品牌意图一致 / Ensure pragmatic inferences align with brand intentions
- 避免语用推理混乱或错误 / Avoid confusing or incorrect pragmatic inferences

---

## 参考资源 / References

- 《现代汉语词典》/ Modern Chinese Dictionary
- 《汉语音韵学》/ Chinese Phonology
- 《语义学》/ Semantics
- 《符号学导论》/ Introduction to Semiotics
- 《语用学》/ Pragmatics
