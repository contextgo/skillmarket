# 品牌术语 / Branding Terminology

## 目录 / Table of Contents

1. [品牌定位 / Brand Positioning](#品牌定位)
2. [品牌个性 / Brand Personality](#品牌个性)
3. [品牌价值主张 / Brand Value Proposition](#品牌价值主张)
4. [目标受众 / Target Audience](#目标受众)
5. [品牌架构 / Brand Architecture](#品牌架构)
6. [品牌原型 / Brand Archetypes](#品牌原型)

---

## 品牌定位 / Brand Positioning

### 定义 / Definition

品牌定位是指在目标消费者心目中为品牌确立一个独特、有价值的位置。

Brand positioning refers to establishing a unique, valuable position for the brand in the minds of target consumers.

### 常见类型 / Common Types

- **高端定位 / High-end Positioning**：强调品质、奢华、独特性
  - Emphasizes quality, luxury, uniqueness
  - 案例：Louis Vuitton、Hermès

- **大众定位 / Mass Positioning**：强调性价比、普及性、可获得性
  - Emphasizes cost-effectiveness, popularity, accessibility
  - 案例：Coca-Cola、Unilever

- **年轻定位 / Young Positioning**：强调活力、创新、潮流
  - Emphasizes vitality, innovation, trends
  - 案例：Nike、Apple

- **成熟定位 / Mature Positioning**：强调稳重、可靠、专业
  - Emphasizes stability, reliability, professionalism
  - 案例：IBM、McKinsey

### 命名建议 / Naming Suggestions

- 高端定位：使用优雅、独特、有文化底蕴的词汇
- 大众定位：使用亲和、易记、传播性强的词汇
- 年轻定位：使用现代、活力、有创新感的词汇
- 成熟定位：使用稳重、专业、可靠的词汇

---

## 品牌个性 / Brand Personality

### 定义 / Definition

品牌个性是指品牌所具有的人格特征，是品牌与消费者情感连接的核心。

Brand personality refers to the personality traits that a brand possesses, serving as the core of the emotional connection between the brand and consumers.

### 常见类型 / Common Types

- **专业型 / Professional**：可靠、专业、权威
  - Reliable, professional, authoritative
  - 案例：IBM、Deloitte

- **亲和型 / Approachable**：温暖、友好、平易近人
  - Warm, friendly, approachable
  - 案例：Disney、IKEA

- **创新型 / Innovative**：创意、前沿、突破
  - Creative, cutting-edge, breakthrough
  - 案例：Apple、Google

- **传统型 / Traditional**：历史、传承、经典
  - Historical, heritage, classic
  - 案例：Mercedes-Benz、Rolex

### 命名建议 / Naming Suggestions

- 专业型：使用稳重、权威、专业的词汇
- 亲和型：使用温暖、友好、亲切的词汇
- 创新型：使用创意、前沿、突破的词汇
- 传统型：使用历史、传承、经典的词汇

---

## 品牌价值主张 / Brand Value Proposition

### 定义 / Definition

品牌价值主张是品牌向消费者承诺的核心价值，是消费者选择品牌的根本原因。

Brand value proposition is the core value that a brand promises to consumers, and is the fundamental reason why consumers choose the brand.

### 价值类型 / Value Types

- **功能性价值 / Functional Value**：产品或服务的实际功能和效用
  - Actual function and utility of products or services
  - 案例：IBM（企业级计算解决方案）

- **情感性价值 / Emotional Value**：品牌带来的情感体验和心理满足
  - Emotional experience and psychological satisfaction brought by the brand
  - 案例：Disney（快乐、梦想）

- **象征性价值 / Symbolic Value**：品牌所代表的身份认同和社会地位
  - Identity and social status represented by the brand
  - 案例：Louis Vuitton（奢华、地位）

### 命名建议 / Naming Suggestions

- 功能性价值：使用直接、明确、功能相关的词汇
- 情感性价值：使用情感丰富、有感染力的词汇
- 象征性价值：使用有象征意义、能代表身份的词汇

---

## 目标受众 / Target Audience

### 定义 / Definition

目标受众是品牌希望吸引和服务的特定人群。

Target audience is the specific group of people that a brand hopes to attract and serve.

### 分析维度 / Analysis Dimensions

- **年龄 / Age**：18-25（Z世代）、26-35（千禧一代）、36-50（X世代）、50+（婴儿潮一代）
- **性别 / Gender**：男性、女性、中性
- **收入 / Income**：低收入、中等收入、高收入
- **价值观 / Values**：传统、现代、保守、开放、环保、时尚等

### 命名建议 / Naming Suggestions

- 年轻受众：使用现代、潮流、易于社交媒体传播的词汇
- 成熟受众：使用稳重、专业、有文化底蕴的词汇
- 高收入受众：使用优雅、独特、高端的词汇
- 环保价值观：使用自然、绿色、可持续的词汇

---

## 品牌架构 / Brand Architecture

### 定义 / Definition

品牌架构是指企业内部品牌之间的关系结构。

Brand architecture refers to the structural relationship between brands within a company.

### 常见类型 / Common Types

- **单一品牌策略 / Monolithic Brand Strategy**：所有产品使用同一个品牌名称
  - All products use the same brand name
  - 优点：品牌聚焦、易于传播
  - 案例：Apple、Samsung

- **多品牌策略 / Multi-Brand Strategy**：每个产品使用独立的品牌名称
  - Each product uses an independent brand name
  - 优点：市场细分、风险分散
  - 案例：P&G、Unilever

- **背书品牌策略 / Endorsed Brand Strategy**：主品牌+子品牌组合
  - Master brand + sub-brand combination
  - 优点：平衡聚焦与细分
  - 案例：Marriott Hotels、Courtyard by Marriott

### 命名建议 / Naming Suggestions

- 单一品牌：使用简洁、易记、可扩展的名称
- 多品牌：每个子品牌使用独特的、符合目标市场的名称
- 背书品牌：主品牌简洁，子品牌突出产品特点

---

## 品牌原型 / Brand Archetypes

### 定义 / Definition

品牌原型是基于荣格心理学理论的品牌人格模型，用于描述品牌的深层动机和价值观。

Brand archetypes are brand personality models based on Jungian psychology, used to describe the brand's deep motivations and values.

### 12 种品牌原型 / 12 Brand Archetypes

#### 1. 英雄 / The Hero

- **特征 / Characteristics**：力量、勇气、胜利、征服
- **命名建议 / Naming Suggestions**：使用有力量的词汇
- **案例 / Examples**：Nike、Adidas

#### 2. 智者 / The Sage

- **特征 / Characteristics**：知识、智慧、洞察、真理
- **命名建议 / Naming Suggestions**：使用智慧相关的词汇
- **案例 / Examples**：Google、IBM

#### 3. 照顾者 / The Caregiver

- **特征 / Characteristics**：关怀、保护、服务、温暖
- **命名建议 / Naming Suggestions**：使用温暖、关怀的词汇
- **案例 / Examples**：Johnson & Johnson、Unilever

#### 4. 探险者 / The Explorer

- **特征 / Characteristics**：自由、探索、发现、冒险
- **命名建议 / Naming Suggestions**：使用探索相关的词汇
- **案例 / Examples**：Jeep、The North Face

#### 5. 创造者 / The Creator

- **特征 / Characteristics**：创新、创造、表达、艺术
- **命名建议 / Naming Suggestions**：使用创新、创造相关的词汇
- **案例 / Examples**：Apple、Adobe

#### 6. 统治者 / The Ruler

- **特征 / Characteristics**：权威、控制、领导、秩序
- **命名建议 / Naming Suggestions**：使用权威、领导相关的词汇
- **案例 / Examples**：Rolex、Mercedes-Benz

#### 7. 普通人 / The Regular Guy

- **特征 / Characteristics**：平等、归属、简单、实在
- **命名建议 / Naming Suggestions**：使用亲和、简单的词汇
- **案例 / Examples**：IKEA、Target

#### 8. 情人 / The Lover

- **特征 / Characteristics**：浪漫、激情、亲密、美丽
- **命名建议 / Naming Suggestions**：使用浪漫、美丽的词汇
- **案例 / Examples**：Victoria's Secret、Chanel

#### 9. 弄臣 / The Jester

- **特征 / Characteristics**：幽默、快乐、轻松、娱乐
- **命名建议 / Naming Suggestions**：使用幽默、快乐的词汇
- **案例 / Examples**：M&M's、Skittles

#### 10. 革命者 / The Revolutionary

- **特征 / Characteristics**：颠覆、叛逆、变革、自由
- **命名建议 / Naming Suggestions**：使用颠覆、变革的词汇
- **案例 / Examples**：Harley-Davidson、Virgin

#### 11. 魔法师 / The Magician

- **特征 / Characteristics**：魔法、奇迹、转变、愿景
- **命名建议 / Naming Suggestions**：使用魔法、愿景的词汇
- **案例 / Examples**：Disney、Tesla

#### 12. 无辜者 / The Innocent

- **特征 / Characteristics**：纯真、简单、安全、幸福
- **命名建议 / Naming Suggestions**：使用纯真、简单的词汇
- **案例 / Examples**：Dove、Cottonelle

### 使用建议 / Usage Recommendations

1. 确定品牌的核心动机和价值观
2. 选择最符合品牌定位的原型
3. 在命名时参考原型的特征和命名建议
4. 确保名称与品牌原型的一致性

---

## 参考资源 / References

- Aaker, J. L. (1997). Dimensions of brand personality. Journal of Marketing Research.
- Keller, K. L. (1993). Conceptualizing, measuring, and managing customer-based brand equity. Journal of Marketing.
- Jung, C. G. (1968). The Archetypes and the Collective Unconscious.
- Mark, M., & Pearson, C. S. (2001). The Hero and the Outlaw: Building Extraordinary Brands Through the Power of Archetypes.
