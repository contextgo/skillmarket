# 法律术语 / Legal Terminology

## 目录 / Table of Contents

1. [商标分类与显著性 / Trademark Classification & Distinctiveness](#商标分类与显著性)
2. [域名注册规则 / Domain Registration Rules](#域名注册规则)
3. [企业名称登记规则 / Enterprise Name Registration Rules](#企业名称登记规则)
4. [版权法 / Copyright Law](#版权法)
5. [反不正当竞争法 / Anti-Unfair Competition Law](#反不正当竞争法)

---

## 商标分类与显著性 / Trademark Classification & Distinctiveness

### 尼斯分类 / Nice Classification

商标注册采用尼斯分类，共 45 个类别。

Trademark registration uses the Nice Classification, with 45 categories.

#### 核心类别 / Core Categories

- **第 9 类**：科学仪器、软件、电子产品 / Scientific instruments, software, electronic products
- **第 35 类**：广告、商业经营、工商管理 / Advertising, business operation, business management
- **第 41 类**：教育、培训、娱乐 / Education, training, entertainment
- **第 42 类**：科学技术服务、计算机服务 / Scientific and technological services, computer services

#### 分类原则 / Classification Principles

1. **核心类别 / Core Categories**：根据主营业务确定
2. **辅助类别 / Auxiliary Categories**：根据未来发展确定
3. **跨类别保护 / Cross-Category Protection**：重要商标建议跨类别注册

### 商标显著性 / Trademark Distinctiveness

#### 固有显著性 / Inherent Distinctiveness

1. **臆造词 / Fanciful Terms**：
   - 完全创造的词汇
   - 完全创造的词汇
   - 案例：Kodak、Xerox
   - 保护性：最高

2. **任意词 / Arbitrary Terms**：
   - 现有词汇但与商品无关
   - 现有词汇但与商品无关
   - 案例：Apple（电脑）、Camel（香烟）
   - 保护性：高

3. **暗示词 / Suggestive Terms**：
   - 暗示商品特征的词汇
   - 暗示商品特征的词汇
   - 案例：Microsoft（微型软件）
   - 保护性：中等

#### 获得显著性 / Acquired Distinctiveness

1. **描述词 / Descriptive Terms**：
   - 描述商品特征的词汇
   - 描述商品特征的词汇
   - 案例："快速"、"优质"
   - 保护性：低，需要通过使用获得显著性

2. **获得显著性的途径 / Ways to Acquire Distinctiveness**：
   - 长期使用 / Long-term use
   - 大量宣传 / Extensive promotion
   - 建立品牌认知 / Building brand awareness

### 商标注册建议 / Trademark Registration Recommendations

1. **查询现有商标**：在注册前查询现有商标，避免冲突
2. **选择核心类别**：根据主营业务选择核心类别
3. **考虑跨类别保护**：重要商标建议跨类别注册
4. **选择具有显著性的名称**：优先选择臆造词、任意词、暗示词

---

## 域名注册规则 / Domain Registration Rules

### 域名类型 / Domain Types

#### 通用顶级域名 / gTLD

- **.com**：商业域名，最常用 / Commercial domain, most commonly used
- **.net**：网络服务域名 / Network service domain
- **.org**：组织机构域名 / Organization domain
- **.info**：信息网站域名 / Information website domain
- **.biz**：商业域名 / Business domain

#### 国家和地区顶级域名 / ccTLD

- **.cn**：中国 / China
- **.us**：美国 / United States
- **.uk**：英国 / United Kingdom
- **.jp**：日本 / Japan
- **.de**：德国 / Germany

#### 新顶级域名 / New gTLD

- **.xyz**：通用域名 / General domain
- **.online**：在线服务 / Online service
- **.shop**：电商 / E-commerce
- **.tech**：科技 / Technology

### 域名注册限制 / Domain Registration Restrictions

#### 长度限制 / Length Limits

- 通常 1-63 个字符 / Usually 1-63 characters
- 不同后缀可能有不同限制 / Different suffixes may have different restrictions

#### 字符限制 / Character Limits

- **允许的字符 / Allowed Characters**：
  - 字母：a-z（不区分大小写） / Letters: a-z (case-insensitive)
  - 数字：0-9 / Numbers: 0-9
  - 连字符：-（不能以连字符开头或结尾） / Hyphen: - (cannot start or end with hyphen)

- **禁止的字符 / Prohibited Characters**：
  - 空格 / Spaces
  - 特殊符号：! @ # $ % ^ & * ( ) _ + = [ ] { } | ; : ' " < > , . ? / ~ `
  - 中文字符（部分国家域名支持） / Chinese characters (some country domains support)

#### 禁止注册的词汇 / Prohibited Vocabulary

- 违禁词汇 / Prohibited vocabulary
- 保留词汇 / Reserved vocabulary
- 国家名称、国际组织名称（部分域名） / Country names, international organization names (some domains)

### 实名制要求 / Real-Name Requirement

#### .cn 域名实名制 / .cn Domain Real-Name System

- **需要实名认证**：注册 .cn 域名需要实名认证 / Requires real-name authentication
- **认证材料**：个人身份证或企业营业执照 / Authentication materials: personal ID or business license
- **认证流程**：提交材料 → 审核 → 完成 / Authentication process: submit materials → review → complete

### 域名注册建议 / Domain Registration Recommendations

1. **选择简短易记的域名**：简短、易拼写、易记忆
2. **选择合适的后缀**：根据目标市场选择合适的后缀
3. **避免使用特殊字符**：避免使用连字符等特殊字符
4. **考虑品牌一致性**：域名与品牌名称保持一致
5. **及时续费**：避免域名过期被抢注

---

## 企业名称登记规则 / Enterprise Name Registration Rules

### 企业名称结构 / Enterprise Name Structure

```
行政区划 + 字号 + 行业 + 组织形式
Administrative Division + Trade Name + Industry + Organizational Form
```

#### 示例 / Examples

- 北京市 + 华为 + 技术 + 有限公司 / Beijing + Huawei + Technology + Co., Ltd.
- 上海市 + 阿里巴巴 + 网络 + 科技 + 股份有限公司 / Shanghai + Alibaba + Network + Technology + Co., Ltd.

### 各组成部分规则 / Rules for Each Component

#### 1. 行政区划 / Administrative Division

- **要求 / Requirements**：
  - 必须包含行政区划 / Must include administrative division
  - 可以是省、市、县等 / Can be province, city, county, etc.
  - 可以使用缩写（如北京、上海） / Can use abbreviations (e.g., Beijing, Shanghai)

- **示例 / Examples**：
  - 北京、上海、广东、江苏 / Beijing, Shanghai, Guangdong, Jiangsu
  - 北京市、上海市、广东省、江苏省 / Beijing City, Shanghai City, Guangdong Province, Jiangsu Province

#### 2. 字号 / Trade Name

- **定义 / Definition**：
  - 字号是企业的核心标识 / Trade name is the core identifier of the enterprise
  - 可以是汉字、字母、数字 / Can be Chinese characters, letters, numbers

- **独占性规则 / Exclusivity Rules**：
  - 同行政区划同行业字号不能重复 / Trade names cannot be duplicated in the same administrative division and industry
  - 跨行政区划可以重复 / Can be duplicated across administrative divisions

- **禁止使用的字号 / Prohibited Trade Names**：
  - 与国家名称、国旗、国徽相同或近似的 / Same or similar to country names, national flags, national emblems
  - 与政党名称、党徽相同或近似的 / Same or similar to party names, party emblems
  - 与国际组织名称相同或近似的 / Same or similar to international organization names
  - 带有民族歧视、性别歧视的 / Carrying ethnic or gender discrimination

#### 3. 行业 / Industry

- **要求 / Requirements**：
  - 必须包含行业用语 / Must include industry terms
  - 行业用语应符合国家行业分类标准 / Industry terms should comply with national industry classification standards
  - 不得使用可能引起误解的行业用语 / Must not use industry terms that may cause misunderstanding

- **常见行业用语 / Common Industry Terms**：
  - 科技、技术、网络、信息 / Technology, Tech, Network, Information
  - 贸易、商贸、商业、销售 / Trade, Commerce, Business, Sales
  - 咨询、服务、管理、顾问 / Consulting, Service, Management, Consultant

#### 4. 组织形式 / Organizational Form

- **要求 / Requirements**：
  - 必须包含组织形式 / Must include organizational form
  - 组织形式应符合企业类型 / Organizational form should match enterprise type

- **常见组织形式 / Common Organizational Forms**：
  - **公司类型 / Company Types**：
    - 有限责任公司 / Limited Liability Company
    - 股份有限公司 / Joint Stock Limited Company

  - **合伙企业类型 / Partnership Types**：
    - 普通合伙企业 / General Partnership
    - 有限合伙企业 / Limited Partnership

  - **个人独资企业 / Sole Proprietorship**：
    - 个人独资企业 / Sole Proprietorship

### 企业名称登记建议 / Enterprise Name Registration Recommendations

1. **选择有独特性的字号**：避免使用过于普通的字号
2. **选择合适的行政区划**：根据业务范围选择
3. **准确选择行业用语**：根据主营业务选择
4. **选择合适的组织形式**：根据企业类型选择
5. **提前查询**：在登记前查询企业名称是否可用

---

## 版权法 / Copyright Law

### 名称的版权保护 / Copyright Protection of Names

#### 作品名称 / Work Titles

- **保护范围 / Scope of Protection**：
  - 独创性的作品名称可以受到版权保护 / Original work titles can be protected by copyright
  - 通用名称、描述性名称不受保护 / Generic names, descriptive names are not protected

- **保护期限 / Protection Period**：
  - 作者终生及死后 50 年 / Author's lifetime plus 50 years after death

#### 角色名称 / Character Names

- **保护范围 / Scope of Protection**：
  - 知名角色名称可以受到版权保护 / Well-known character names can be protected by copyright
  - 需要与角色形象、故事情节结合使用 / Need to be used in combination with character image, plot

- **保护条件 / Protection Conditions**：
  - 角色具有较高的知名度 / Character has high visibility
  - 角色名称与角色形象紧密结合 / Character name is closely integrated with character image

### 版权侵权 / Copyright Infringement

#### 禁止行为 / Prohibited Acts

- **抄袭作品名称**：擅自使用他人作品名称 / Unauthorized use of others' work titles
- **抄袭角色名称**：擅自使用他人知名角色名称 / Unauthorized use of others' well-known character names

#### 合理使用 / Fair Use

- **描述性使用**：为描述商品或服务而使用名称 / Using names to describe goods or services
- **评论性使用**：为评论、新闻报道而使用名称 / Using names for commentary, news reporting

### 版权保护建议 / Copyright Protection Recommendations

1. **选择原创名称**：避免使用现有作品名称
2. **注册版权**：重要名称可以注册版权保护
3. **保留创作证据**：保留创作过程、创作时间等证据
4. **监测侵权**：定期监测是否有人侵权使用

---

## 反不正当竞争法 / Anti-Unfair Competition Law

### 禁止行为 / Prohibited Acts

#### 1. 混淆行为 / Confusion Acts

- **定义 / Definition**：
  - 禁止使用与他人相同或近似的名称，引人误认为是他人商品或者服务
  - Prohibition of using names identical or similar to others to cause confusion

- **具体情形 / Specific Situations**：
  - 使用与他人注册商标相同或近似的名称 / Using names identical or similar to others' registered trademarks
  - 使用与他人企业名称相同或近似的名称 / Using names identical or similar to others' enterprise names
  - 使用与他人知名商品特有名称相同或近似的名称 / Using names identical or similar to others' well-known product unique names

- **法律责任 / Legal Liability**：
  - 停止侵权 / Stop infringement
  - 赔偿损失 / Compensate for losses
  - 消除影响 / Eliminate impact

#### 2. 虚假宣传 / False Advertising

- **定义 / Definition**：
  - 禁止引人误解的虚假宣传 / Prohibition of misleading false advertising
  - 使用不真实的名称进行宣传 / Using false names for advertising

- **具体情形 / Specific Situations**：
  - 夸大商品或服务的功效 / Exaggerating the efficacy of goods or services
  - 使用虚假的认证、荣誉 / Using false certifications, honors

#### 3. 擅自使用 / Unauthorized Use

- **定义 / Definition**：
  - 禁止擅自使用他人有一定影响的名称 / Prohibition of unauthorized use of others' influential names

- **具体情形 / Specific Situations**：
  - 擅自使用他人姓名 / Unauthorized use of others' personal names
  - 擅自使用他人笔名、艺名 / Unauthorized use of others' pen names, stage names
  - 擅自使用他人字号 / Unauthorized use of others' trade names

### 反不正当竞争法建议 / Anti-Unfair Competition Law Recommendations

1. **避免使用他人名称**：避免使用与他人相同或近似的名称
2. **确保宣传真实**：确保宣传内容真实，不夸大
3. **尊重他人权利**：尊重他人的姓名、笔名、艺名、字号等权利
4. **定期法律审查**：定期进行法律审查，确保合规

---

## 参考资源 / References

- 《中华人民共和国商标法》 / Trademark Law of the People's Republic of China
- 《中华人民共和国企业名称登记管理规定》 / Provisions on the Administration of Enterprise Name Registration
- 《中华人民共和国著作权法》 / Copyright Law of the People's Republic of China
- 《中华人民共和国反不正当竞争法》 / Anti-Unfair Competition Law of the People's Republic of China
- Nice Classification (NCL)
- ICANN Domain Name Rules
