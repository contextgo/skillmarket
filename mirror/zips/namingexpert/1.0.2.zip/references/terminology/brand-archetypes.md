# 品牌原型 / Brand Archetypes

## 目录 / Table of Contents

1. [原型概述 / Archetype Overview](#原型概述)
2. [12 大品牌原型 / 12 Brand Archetypes](#12-大品牌原型)
3. [原型选择指南 / Archetype Selection Guide](#原型选择指南)
4. [原型与命名 / Archetypes and Naming](#原型与命名)

---

## 原型概述 / Archetype Overview

### 定义 / Definition

品牌原型是指基于荣格心理学理论，品牌所具有的基本人格特征和象征意义。

Brand archetypes refer to the basic personality traits and symbolic meanings that brands possess based on Jungian psychology theory.

---

### 原型的作用 / Role of Archetypes

1. **建立品牌人格 / Establish Brand Personality**：
   - 赋予品牌人格化特征 / Endow brands with personalized traits
   - 增强品牌亲和力 / Enhance brand affinity
   - 提高品牌识别度 / Improve brand recognizability

2. **传递品牌价值 / Convey Brand Values**：
   - 通过原型传达品牌核心价值 / Convey brand core values through archetypes
   - 建立品牌情感连接 / Establish brand emotional connections
   - 强化品牌记忆点 / Strengthen brand memory points

3. **指导品牌行为 / Guide Brand Behavior**：
   - 指导品牌传播策略 / Guide brand communication strategies
   - 指导产品开发方向 / Guide product development directions
   - 指导命名风格选择 / Guide naming style selection

---

## 12 大品牌原型 / 12 Brand Archetypes

### 1. 天真 / The Innocent

#### 核心特征 / Core Characteristics

- **价值观 / Values**：纯真、乐观、简单 / Purity, optimism, simplicity
- **目标 / Goal**：保持纯真，追求快乐 / Maintain purity, pursue happiness
- **恐惧 / Fear**：被污染、被伤害 / Being polluted, being hurt
- **策略 / Strategy**：保持简单，追求美好 / Keep simple, pursue beauty

---

#### 典型品牌 / Typical Brands

- **Coca-Cola**：代表快乐和纯真 / Represents happiness and purity
- **Disney**：代表童话和梦想 / Represents fairy tales and dreams
- **Dove**：代表温柔和关怀 / Represents gentleness and care

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 天真、美好、纯净 / Innocent, beautiful, pure
  - 示例：天使、天使、天 / Examples: 天使, 天使, 天

- **音韵 / Phonetics**：
  - 柔和、舒缓 / Gentle, soothing
  - 示例：天真、美好、纯净 / Examples: 天真, 美好, 纯净

- **寓意 / Symbolism**：
  - 积极正面、充满希望 / Positive and hopeful
  - 示例：希望、快乐、美好 / Examples: 希望, 快乐, 美好

---

### 2. 普通人 / The Regular Guy

#### 核心特征 / Core Characteristics

- **价值观 / Values**：亲切、可靠、接地气 / Approachable, reliable, down-to-earth
- **目标 / Goal**：融入群体，获得归属感 / Integrate into groups, gain belonging
- **恐惧 / Fear**：被排斥、被孤立 / Being excluded, being isolated
- **策略 / Strategy**：保持平凡，追求真实 / Keep ordinary, pursue authenticity

---

#### 典型品牌 / Typical Brands

- **IKEA**：代表家居生活 / Represents home life
- **Walmart**：代表实惠可靠 / Represents value and reliability
- **Uniqlo**：代表简约实用 / Represents simplicity and practicality

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 普通、亲切、可靠 / Ordinary, approachable, reliable
  - 示例：家、友、邻 / Examples: 家, 友, 邻

- **音韵 / Phonetics**：
  - 平和、稳定 / Peaceful, stable
  - 示例：家、友、邻 / Examples: 家, 友, 邻

- **寓意 / Symbolism**：
  - 亲切友好、实用可靠 / Approachable and friendly, practical and reliable
  - 示例：家、友、邻 / Examples: 家, 友, 邻

---

### 3. 英雄 / The Hero

#### 核心特征 / Core Characteristics

- **价值观 / Values**：勇敢、有力、成就 / Bravery, power, achievement
- **目标 / Goal**：证明自己，获得认可 / Prove oneself, gain recognition
- **恐惧 / Fear**：失败、软弱 / Failure, weakness
- **策略 / Strategy**：挑战困难，追求卓越 / Challenge difficulties, pursue excellence

---

#### 典型品牌 / Typical Brands

- **Nike**：代表运动和突破 / Represents sports and breakthroughs
- **BMW**：代表驾驶和激情 / Represents driving and passion
- **Under Armour**：代表挑战和力量 / Represents challenge and power

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 勇敢、有力、突破 / Brave, powerful, breakthrough
  - 示例：英雄、勇士、胜 / Examples: 英雄, 勇士, 胜

- **音韵 / Phonetics**：
  - 有力、激昂 / Powerful, impassioned
  - 示例：胜、勇、强 / Examples: 胜, 勇, 强

- **寓意 / Symbolism**：
  - 勇敢坚强、追求卓越 / Brave and strong, pursuing excellence
  - 示例：胜、勇、强 / Examples: 胜, 勇, 强

---

### 4. 照顾者 / The Caregiver

#### 核心特征 / Core Characteristics

- **价值观 / Values**：关怀、保护、温暖 / Caring, protective, warm
- **目标 / Goal**：帮助他人，传递关爱 / Help others, convey love and care
- **恐惧 / Fear**：被忽视、被伤害 / Being ignored, being hurt
- **策略 / Strategy**：提供保护，传递温暖 / Provide protection, convey warmth

---

#### 典型品牌 / Typical Brands

- **Johnson & Johnson**：代表关爱和安全 / Represents care and safety
- **Volvo**：代表保护和安全 / Represents protection and safety
- **Nestlé**：代表营养和关怀 / Represents nutrition and care

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 关怀、保护、温暖 / Caring, protective, warm
  - 示例：爱、护、暖 / Examples: 爱, 护, 暖

- **音韵 / Phonetics**：
  - 温柔、舒缓 / Gentle, soothing
  - 示例：爱、护、暖 / Examples: 爱, 护, 暖

- **寓意 / Symbolism**：
  - 关怀温暖、保护安全 / Caring and warm, protective and safe
  - 示例：爱、护、暖 / Examples: 爱, 护, 暖

---

### 5. 探险家 / The Explorer

#### 核心特征 / Core Characteristics

- **价值观 / Values**：自由、冒险、发现 / Freedom, adventure, discovery
- **目标 / Goal**：探索未知，追求自由 / Explore the unknown, pursue freedom
- **恐惧 / Fear**：被束缚、被困住 / Being constrained, being trapped
- **策略 / Strategy**：勇于探索，不断发现 / Bravely explore, constantly discover

---

#### 典型品牌 / Typical Brands

- **Jeep**：代表冒险和探索 / Represents adventure and exploration
- **The North Face**：代表户外和挑战 / Represents outdoors and challenges
- **National Geographic**：代表发现和探索 / Represents discovery and exploration

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 自由、冒险、探索 / Freedom, adventure, exploration
  - 示例：探险、发现、自由 / Examples: 探险, 发现, 自由

- **音韵 / Phonetics**：
  - 自由、激昂 / Free, impassioned
  - 示例：自由、探索、发现 / Examples: 自由, 探索, 发现

- **寓意 / Symbolism**：
  - 自由探索、勇于冒险 / Free exploration, brave adventure
  - 示例：自由、探索、发现 / Examples: 自由, 探索, 发现

---

### 6. 反叛者 / The Rebel

#### 核心特征 / Core Characteristics

- **价值观 / Values**：颠覆、创新、打破常规 / Subversive, innovative, breaking conventions
- **目标 / Goal**：颠覆现状，改变世界 / Disrupt the status quo, change the world
- **恐惧 / Fear**：平庸、被同化 / Mediocrity, being assimilated
- **策略 / Strategy**：打破常规，追求创新 / Break conventions, pursue innovation

---

#### 典型品牌 / Typical Brands

- **Apple**：代表创新和颠覆 / Represents innovation and disruption
- **Harley-Davidson**：代表自由和反叛 / Represents freedom and rebellion
- **Virgin**：代表挑战和创新 / Represents challenge and innovation

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 颠覆、创新、突破 / Subversive, innovative, breakthrough
  - 示例：颠覆、创新、突破 / Examples: 颠覆, 创新, 突破

- **音韵 / Phonetics**：
  - 现代、有力 / Modern, powerful
  - 示例：颠覆、创新、突破 / Examples: 颠覆, 创新, 突破

- **寓意 / Symbolism**：
  - 颠覆创新、打破常规 / Subversive and innovative, breaking conventions
  - 示例：颠覆、创新、突破 / Examples: 颠覆, 创新, 突破

---

### 7. 情人 / The Lover

#### 核心特征 / Core Characteristics

- **价值观 / Values**：浪漫、激情、亲密 / Romantic, passionate, intimate
- **目标 / Goal**：建立亲密关系，获得爱 / Establish intimate relationships, gain love
- **恐惧 / Fear**：被拒绝、被孤立 / Being rejected, being isolated
- **策略 / Strategy**：追求浪漫，传递激情 / Pursue romance, convey passion

---

#### 典型品牌 / Typical Brands

- **Victoria's Secret**：代表浪漫和性感 / Represents romance and sexiness
- **Chanel**：代表优雅和浪漫 / Represents elegance and romance
- **Dior**：代表奢华和浪漫 / Represents luxury and romance

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 浪漫、激情、亲密 / Romantic, passionate, intimate
  - 示例：爱、情、恋 / Examples: 爱, 情, 恋

- **音韵 / Phonetics**：
  - 柔和、浪漫 / Gentle, romantic
  - 示例：爱、情、恋 / Examples: 爱, 情, 恋

- **寓意 / Symbolism**：
  - 浪漫激情、亲密关系 / Romantic and passionate, intimate relationships
  - 示例：爱、情、恋 / Examples: 爱, 情, 恋

---

### 8. 创造者 / The Creator

#### 核心特征 / Core Characteristics

- **价值观 / Values**：创造、创新、艺术 / Creativity, innovation, art
- **目标 / Goal**：创造新事物，实现愿景 / Create new things, realize vision
- **恐惧 / Fear**：平庸、缺乏创造力 / Mediocrity, lack of creativity
- **策略 / Strategy**：勇于创造，追求创新 / Bravely create, pursue innovation

---

#### 典型品牌 / Typical Brands

- **Adobe**：代表创造和艺术 / Represents creativity and art
- **LEGO**：代表创造和想象 / Represents creativity and imagination
- **Sony**：代表创新和创造 / Represents innovation and creativity

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 创造、创新、艺术 / Creativity, innovation, art
  - 示例：创造、创新、艺术 / Examples: 创造, 创新, 艺术

- **音韵 / Phonetics**：
  - 现代、独特 / Modern, unique
  - 示例：创造、创新、艺术 / Examples: 创造, 创新, 艺术

- **寓意 / Symbolism**：
  - 创新创造、艺术追求 / Innovative and creative, artistic pursuit
  - 示例：创造、创新、艺术 / Examples: 创造, 创新, 艺术

---

### 9. 智者 / The Sage

#### 核心特征 / Core Characteristics

- **价值观 / Values**：智慧、知识、真理 / Wisdom, knowledge, truth
- **目标 / Goal**：追求真理，传播知识 / Pursue truth, spread knowledge
- **恐惧 / Fear**：无知、被欺骗 / Ignorance, being deceived
- **策略 / Strategy**：探索知识，追求智慧 / Explore knowledge, pursue wisdom

---

#### 典型品牌 / Typical Brands

- **Google**：代表知识和智慧 / Represents knowledge and wisdom
- **BBC**：代表权威和真实 / Represents authority and truth
- **Wikipedia**：代表知识和共享 / Represents knowledge and sharing

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 智慧、知识、真理 / Wisdom, knowledge, truth
  - 示例：智、慧、知 / Examples: 智, 慧, 知

- **音韵 / Phonetics**：
  - 稳重、权威 / Steady, authoritative
  - 示例：智、慧、知 / Examples: 智, 慧, 知

- **寓意 / Symbolism**：
  - 智慧知识、追求真理 / Wisdom and knowledge, pursuing truth
  - 示例：智、慧、知 / Examples: 智, 慧, 知

---

### 10. 统治者 / The Ruler

#### 核心特征 / Core Characteristics

- **价值观 / Values**：掌控、稳定、权威 / Control, stability, authority
- **目标 / Goal**：掌控局面，维护秩序 / Control the situation, maintain order
- **恐惧 / Fear**：混乱、失控 / Chaos, loss of control
- **策略 / Strategy**：掌控局势，维护权威 / Control the situation, maintain authority

---

#### 典型品牌 / Typical Brands

- **Mercedes-Benz**：代表奢华和权威 / Represents luxury and authority
- **American Express**：代表地位和权威 / Represents status and authority
- **Rolex**：代表奢华和成功 / Represents luxury and success

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 掌控、稳定、权威 / Control, stability, authority
  - 示例：皇、王、霸 / Examples: 皇, 王, 霸

- **音韵 / Phonetics**：
  - 稳重、有力 / Steady, powerful
  - 示例：皇、王、霸 / Examples: 皇, 王, 霸

- **寓意 / Symbolism**：
  - 掌控权威、稳定地位 / Control and authority, stable status
  - 示例：皇、王、霸 / Examples: 皇, 王, 霸

---

### 11. 魔术师 / The Magician

#### 核心特征 / Core Characteristics

- **价值观 / Values**：变革、神奇、梦想 / Transformation, magic, dreams
- **目标 / Goal**：创造奇迹，实现梦想 / Create miracles, realize dreams
- **恐惧 / Fear**：平庸、无能为力 / Mediocrity, powerlessness
- **策略 / Strategy**：创造奇迹，实现梦想 / Create miracles, realize dreams

---

#### 典型品牌 / Typical Brands

- **Mastercard**：代表便捷和神奇 / Represents convenience and magic
- **Disney**：代表梦想和神奇 / Represents dreams and magic
- **Tesla**：代表变革和创新 / Represents transformation and innovation

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 变革、神奇、梦想 / Transformation, magic, dreams
  - 示例：梦、幻、奇 / Examples: 梦, 幻, 奇

- **音韵 / Phonetics**：
  - 神秘、独特 / Mysterious, unique
  - 示例：梦、幻、奇 / Examples: 梦, 幻, 奇

- **寓意 / Symbolism**：
  - 变革神奇、梦想成真 / Transformative and magical, dreams come true
  - 示例：梦、幻、奇 / Examples: 梦, 幻, 奇

---

### 12. 小丑 / The Jester

#### 核心特征 / Core Characteristics

- **价值观 / Values**：幽默、快乐、娱乐 / Humor, happiness, entertainment
- **目标 / Goal**：带来快乐，传播快乐 / Bring happiness, spread joy
- **恐惧 / Fear**：无聊、被忽视 / Boredom, being ignored
- **策略 / Strategy**：创造幽默，传播快乐 / Create humor, spread joy

---

#### 典型品牌 / Typical Brands

- **M&M's**：代表快乐和趣味 / Represents happiness and fun
- **Old Spice**：代表幽默和趣味 / Represents humor and fun
- **Ben & Jerry's**：代表快乐和创意 / Represents happiness and creativity

---

#### 命名风格 / Naming Style

- **词汇 / Vocabulary**：
  - 幽默、快乐、娱乐 / Humor, happiness, entertainment
  - 示例：乐、趣、笑 / Examples: 乐, 趣, 笑

- **音韵 / Phonetics**：
  - 愉快、轻松 / Pleasant, relaxed
  - 示例：乐、趣、笑 / Examples: 乐, 趣, 笑

- **寓意 / Symbolism**：
  - 幽默快乐、轻松娱乐 / Humorous and happy, relaxed entertainment
  - 示例：乐、趣、笑 / Examples: 乐, 趣, 笑

---

## 原型选择指南 / Archetype Selection Guide

### 选择步骤 / Selection Steps

1. **确定品牌核心价值观 / Determine Brand Core Values**：
   - 品牌最重视什么 / What does the brand value most?
   - 品牌想传递什么 / What does the brand want to convey?

2. **分析目标受众 / Analyze Target Audience**：
   - 目标受众的价值观是什么 / What are the values of the target audience?
   - 目标受众渴望什么 / What does the target audience desire?

3. **研究竞争对手 / Study Competitors**：
   - 竞争对手使用什么原型 / What archetypes do competitors use?
   - 如何差异化 / How to differentiate?

4. **选择品牌原型 / Choose Brand Archetype**：
   - 根据以上分析选择最合适的原型 / Choose the most suitable archetype based on the above analysis

---

### 原型组合 / Archetype Combinations

品牌可以选择 1-2 个原型组合，但不要超过 2 个。

Brands can choose 1-2 archetype combinations, but should not exceed 2.

#### 示例 / Examples

- **Apple**：创造者 + 反叛者 / Creator + Rebel
- **Nike**：英雄 + 探险家 / Hero + Explorer
- **Coca-Cola**：天真 + 小丑 / Innocent + Jester

---

## 原型与命名 / Archetypes and Naming

### 命名原则 / Naming Principles

1. **一致性 / Consistency**：命名与原型保持一致 / Naming should be consistent with the archetype
2. **适应性 / Adaptability**：命名适应目标文化 / Naming should adapt to target culture
3. **独特性 / Uniqueness**：命名具有独特性 / Naming should be unique

---

### 命名示例 / Naming Examples

| 原型 / Archetype | 中文名称 / Chinese Name | 英文名称 / English Name | 寓意 / Symbolism |
|----------------|-------------------|---------------------|----------------|
| 天真 / Innocent | 天真 / Tianzhen | PureSky | 纯真的天空 / Pure sky |
| 普通人 / Regular Guy | 友邻 / Youlin | Friendly | 友好的邻居 / Friendly neighbor |
| 英雄 / Hero | 胜者 / Shengzhe | Winner | 胜利者 / Winner |
| 照顾者 / Caregiver | 爱护 / Aihu | CareLove | 关爱和保护 / Care and love |
| 探险家 / Explorer | 探索 / Tansuo | Explore | 探索未知 / Explore the unknown |
| 反叛者 / Rebel | 颠覆 / Dianfu | Disrupt | 颠覆现状 / Disrupt the status quo |
| 情人 / Lover | 恋曲 / Lianqu | LoveSong | 爱的旋律 / Melody of love |
| 创造者 / Creator | 创想 / Chuangxiang | CreateIdeas | 创造想法 / Create ideas |
| 智者 / Sage | 智库 / Zhiku | WisdomHub | 智慧的宝库 / Treasury of wisdom |
| 统治者 / Ruler | 霸业 / Baye | Empire | 宏伟事业 / Grand undertaking |
| 魔术师 / Magician | 梦幻 / Menghuan | DreamMagic | 梦境般的神奇 / Dreamlike magic |
| 小丑 / Jester | 乐趣 / Lequ | FunJoy | 快乐和趣味 / Happiness and fun |

---

## 参考资源 / References

- Jung, C. G. "The Archetypes and The Collective Unconscious"
- Mark, M., & Pearson, C. "The Hero and the Outlaw: Building Extraordinary Brands Through the Power of Archetypes"
- Campbell, J. "The Hero with a Thousand Faces"
