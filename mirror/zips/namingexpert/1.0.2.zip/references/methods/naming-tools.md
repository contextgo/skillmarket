# 命名工具推荐 / Naming Tools Recommendations

## 目录 / Table of Contents

1. [商标查询工具 / Trademark Query Tools](#商标查询工具)
2. [域名查询工具 / Domain Query Tools](#域名查询工具)
3. [企业名称查询工具 / Enterprise Name Query Tools](#企业名称查询工具)
4. [音韵分析工具 / Phonetic Analysis Tools](#音韵分析工具)
5. [谐音检测工具 / Homophone Detection Tools](#谐音检测工具)
6. [命名生成工具 / Name Generation Tools](#命名生成工具)

---

## 商标查询工具 / Trademark Query Tools

### 1. 中国商标网 / China Trademark Online

- **网址 / URL**：http://sbj.cnipa.gov.cn/
- **功能 / Features**：
  - 商标查询 / Trademark query
  - 商标公告 / Trademark announcement
  - 商标申请 / Trademark application
- **优点 / Advantages**：
  - 官方权威 / Official and authoritative
  - 数据全面 / Comprehensive data
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 界面较为陈旧 / Relatively old interface
  - 查询速度较慢 / Slow query speed

---

### 2. 国家知识产权局商标局 / CNIPA Trademark Office

- **网址 / URL**：http://www.cnipa.gov.cn/
- **功能 / Features**：
  - 商标查询 / Trademark query
  - 商标注册 / Trademark registration
  - 商标公告 / Trademark announcement
- **优点 / Advantages**：
  - 官方权威 / Official and authoritative
  - 数据实时更新 / Real-time data updates
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 需要注册 / Registration required
  - 查询复杂 / Complex query

---

### 3. 第三方商标查询平台 / Third-Party Trademark Query Platforms

#### 企查查 / Qichacha

- **网址 / URL**：https://www.qichacha.com/
- **功能 / Features**：
  - 商标查询 / Trademark query
  - 企业查询 / Enterprise query
  - 知识产权查询 / Intellectual property query
- **优点 / Advantages**：
  - 界面友好 / User-friendly interface
  - 查询速度快 / Fast query speed
  - 数据全面 / Comprehensive data
- **缺点 / Disadvantages**：
  - 部分功能收费 / Some features are paid
  - 广告较多 / Many advertisements

#### 天眼查 / Tianyancha

- **网址 / URL**：https://www.tianyancha.com/
- **功能 / Features**：
  - 商标查询 / Trademark query
  - 企业查询 / Enterprise query
  - 知识产权查询 / Intellectual property query
- **优点 / Advantages**：
  - 界面友好 / User-friendly interface
  - 查询速度快 / Fast query speed
  - 数据全面 / Comprehensive data
- **缺点 / Disadvantages**：
  - 部分功能收费 / Some features are paid
  - 广告较多 / Many advertisements

---

## 域名查询工具 / Domain Query Tools

### 1. 阿里云域名查询 / Alibaba Cloud Domain Query

- **网址 / URL**：https://wanwang.aliyun.com/
- **功能 / Features**：
  - 域名查询 / Domain query
  - 域名注册 / Domain registration
  - 域名管理 / Domain management
- **优点 / Advantages**：
  - 官方权威 / Official and authoritative
  - 查询速度快 / Fast query speed
  - 价格优惠 / Preferential price
- **缺点 / Disadvantages**：
  - 仅支持 .cn 域名 / Only supports .cn domain
  - 部分域名价格较高 / Some domains have higher prices

---

### 2. 腾讯云域名查询 / Tencent Cloud Domain Query

- **网址 / URL**：https://dnspod.cloud.tencent.com/
- **功能 / Features**：
  - 域名查询 / Domain query
  - 域名注册 / Domain registration
  - 域名管理 / Domain management
- **优点 / Advantages**：
  - 官方权威 / Official and authoritative
  - 查询速度快 / Fast query speed
  - 价格优惠 / Preferential price
- **缺点 / Disadvantages**：
  - 仅支持 .cn 域名 / Only supports .cn domain
  - 部分域名价格较高 / Some domains have higher prices

---

### 3. 第三方域名查询平台 / Third-Party Domain Query Platforms

#### GoDaddy

- **网址 / URL**：https://www.godaddy.com/
- **功能 / Features**：
  - 域名查询 / Domain query
  - 域名注册 / Domain registration
  - 域名管理 / Domain management
- **优点 / Advantages**：
  - 支持 .com/.net/.org 等国际域名 / Supports international domains like .com/.net/.org
  - 价格透明 / Transparent pricing
  - 服务全面 / Comprehensive services
- **缺点 / Disadvantages**：
  - 需要国际支付 / Requires international payment
  - 语言主要为英语 / Language mainly in English

#### Namecheap

- **网址 / URL**：https://www.namecheap.com/
- **功能 / Features**：
  - 域名查询 / Domain query
  - 域名注册 / Domain registration
  - 域名管理 / Domain management
- **优点 / Advantages**：
  - 支持 .com/.net/.org 等国际域名 / Supports international domains like .com/.net/.org
  - 价格便宜 / Cheap price
  - 服务全面 / Comprehensive services
- **缺点 / Disadvantages**：
  - 需要国际支付 / Requires international payment
  - 语言主要为英语 / Language mainly in English

---

## 企业名称查询工具 / Enterprise Name Query Tools

### 1. 国家企业信用信息公示系统 / National Enterprise Credit Information Publicity System

- **网址 / URL**：http://www.gsxt.gov.cn/
- **功能 / Features**：
  - 企业名称查询 / Enterprise name query
  - 企业信息查询 / Enterprise information query
  - 企业信用查询 / Enterprise credit query
- **优点 / Advantages**：
  - 官方权威 / Official and authoritative
  - 数据全面 / Comprehensive data
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 界面较为陈旧 / Relatively old interface
  - 查询速度较慢 / Slow query speed

---

### 2. 第三方企业名称查询平台 / Third-Party Enterprise Name Query Platforms

#### 企查查 / Qichacha

- **网址 / URL**：https://www.qichacha.com/
- **功能 / Features**：
  - 企业名称查询 / Enterprise name query
  - 企业信息查询 / Enterprise information query
  - 企业信用查询 / Enterprise credit query
- **优点 / Advantages**：
  - 界面友好 / User-friendly interface
  - 查询速度快 / Fast query speed
  - 数据全面 / Comprehensive data
- **缺点 / Disadvantages**：
  - 部分功能收费 / Some features are paid
  - 广告较多 / Many advertisements

#### 天眼查 / Tianyancha

- **网址 / URL**：https://www.tianyancha.com/
- **功能 / Features**：
  - 企业名称查询 / Enterprise name query
  - 企业信息查询 / Enterprise information query
  - 企业信用查询 / Enterprise credit query
- **优点 / Advantages**：
  - 界面友好 / User-friendly interface
  - 查询速度快 / Fast query speed
  - 数据全面 / Comprehensive data
- **缺点 / Disadvantages**：
  - 部分功能收费 / Some features are paid
  - 广告较多 / Many advertisements

---

## 音韵分析工具 / Phonetic Analysis Tools

### 1. 汉语拼音工具 / Chinese Pinyin Tools

#### 拼音转换器 / Pinyin Converter

- **网址 / URL**：https://pinyin.sogou.com/
- **功能 / Features**：
  - 汉字转拼音 / Chinese to pinyin
  - 拼音转汉字 / Pinyin to Chinese
  - 多音字识别 / Polyphone recognition
- **优点 / Advantages**：
  - 准确性高 / High accuracy
  - 支持多音字 / Supports polyphones
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 仅支持普通话 / Only supports Mandarin
  - 不支持音韵分析 / Does not support phonetic analysis

---

#### 搜狗拼音输入法 / Sogou Pinyin Input

- **网址 / URL**：https://pinyin.sogou.com/
- **功能 / Features**：
  - 拼音输入 / Pinyin input
  - 汉字转拼音 / Chinese to pinyin
  - 音韵提示 / Phonetic hints
- **优点 / Advantages**：
  - 准确性高 / High accuracy
  - 支持多音字 / Supports polyphones
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 仅支持普通话 / Only supports Mandarin
  - 不支持音韵分析 / Does not support phonetic analysis

---

### 2. 国际音标工具 / IPA Tools

#### 国际音标转换器 / IPA Converter

- **网址 / URL**：https://www.internationalphoneticalphabet.org/
- **功能 / Features**：
  - 文本转国际音标 / Text to IPA
  - 国际音标转文本 / IPA to text
  - 多语言支持 / Multi-language support
- **优点 / Advantages**：
  - 准确性高 / High accuracy
  - 支持多种语言 / Supports multiple languages
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 需要专业知识 / Requires professional knowledge
  - 不支持中文音韵 / Does not support Chinese phonetics

---

## 谐音检测工具 / Homophone Detection Tools

### 1. 汉语谐音词典 / Chinese Homophone Dictionary

#### 汉典 / Zdic

- **网址 / URL**：https://www.zdic.net/
- **功能 / Features**：
  - 汉字查询 / Chinese character query
  - 词语查询 / Word query
  - 成语查询 / Idiom query
- **优点 / Advantages**：
  - 数据全面 / Comprehensive data
  - 准确性高 / High accuracy
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 不支持谐音检测 / Does not support homophone detection
  - 不支持跨语言检测 / Does not support cross-lingual detection

---

### 2. 跨语言谐音检测工具 / Cross-Lingual Homophone Detection Tools

#### 翻译工具 / Translation Tools

- **网址 / URL**：https://translate.google.com/
- **功能 / Features**：
  - 文本翻译 / Text translation
  - 发音提示 / Pronunciation hints
  - 多语言支持 / Multi-language support
- **优点 / Advantages**：
  - 支持多种语言 / Supports multiple languages
  - 发音准确 / Accurate pronunciation
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 不支持谐音检测 / Does not support homophone detection
  - 需要人工分析 / Requires manual analysis

---

## 命名生成工具 / Name Generation Tools

### 1. 中文名称生成工具 / Chinese Name Generation Tools

#### 中文名字生成器 / Chinese Name Generator

- **网址 / URL**：https://www.chinesenamegenerator.com/
- **功能 / Features**：
  - 中文名称生成 / Chinese name generation
  - 寓意解释 / Meaning explanation
  - 音韵分析 / Phonetic analysis
- **优点 / Advantages**：
  - 生成速度快 / Fast generation speed
  - 寓意丰富 / Rich meanings
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 生成质量一般 / Average generation quality
  - 不支持品牌名称生成 / Does not support brand name generation
  - 不支持专业评估 / Does not support professional evaluation

---

### 2. 英文名称生成工具 / English Name Generation Tools

#### Namelix

- **网址 / URL**：https://namelix.com/
- **功能 / Features**：
  - 英文名称生成 / English name generation
  - Logo 设计 / Logo design
  - 域名查询 / Domain query
- **优点 / Advantages**：
  - 生成质量高 / High generation quality
  - 支持多种风格 / Supports multiple styles
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 不支持中文名称生成 / Does not support Chinese name generation
  - 不支持专业评估 / Does not support professional evaluation
  - 部分功能收费 / Some features are paid

#### Shopify Business Name Generator

- **网址 / URL**：https://www.shopify.com/tools/business-name-generator
- **功能 / Features**：
  - 英文名称生成 / English name generation
  - 域名查询 / Domain query
  - 行业适配 / Industry adaptation
- **优点 / Advantages**：
  - 生成质量高 / High generation quality
  - 支持多种行业 / Supports multiple industries
  - 免费 / Free
- **缺点 / Disadvantages**：
  - 不支持中文名称生成 / Does not support Chinese name generation
  - 不支持专业评估 / Does not support professional evaluation
  - 主要是电商导向 / Mainly e-commerce oriented

---

### 3. 品牌名称生成工具 / Brand Name Generation Tools

#### Brandroot

- **网址 / URL**：https://brandroot.com/
- **功能 / Features**：
  - 品牌名称生成 / Brand name generation
  - 域名查询 / Domain query
  - Logo 设计 / Logo design
- **优点 / Advantages**：
  - 生成质量高 / High generation quality
  - 支持多种风格 / Supports multiple styles
  - 提供商标查询 / Provides trademark query
- **缺点 / Disadvantages**：
  - 不支持中文名称生成 / Does not support Chinese name generation
  - 部分功能收费 / Some features are paid
  - 需要国际支付 / Requires international payment

#### Squadhelp

- **网址 / URL**：https://www.squadhelp.com/
- **功能 / Features**：
  - 品牌名称生成 / Brand name generation
  - 域名查询 / Domain query
  - Logo 设计 / Logo design
  - 商标查询 / Trademark query
- **优点 / Advantages**：
  - 生成质量高 / High generation quality
  - 支持多种风格 / Supports multiple styles
  - 提供专业服务 / Provides professional services
- **缺点 / Disadvantages**：
  - 不支持中文名称生成 / Does not support Chinese name generation
  - 价格较高 / Higher price
  - 需要国际支付 / Requires international payment

---

## 工具使用建议 / Tool Usage Recommendations

### 1. 商标查询 / Trademark Query

- **推荐工具 / Recommended Tools**：
  - 中国商标网（官方权威）/ China Trademark Online (official and authoritative)
  - 企查查（查询速度快）/ Qichacha (fast query speed)
- **使用建议 / Usage Tips**：
  - 优先使用官方工具 / Prioritize official tools
  - 多个工具交叉验证 / Cross-validate with multiple tools
  - 定期查询 / Regular queries

---

### 2. 域名查询 / Domain Query

- **推荐工具 / Recommended Tools**：
  - 阿里云（.cn 域名）/ Alibaba Cloud (.cn domain)
  - GoDaddy（国际域名）/ GoDaddy (international domain)
- **使用建议 / Usage Tips**：
  - 优先查询核心域名 / Prioritize querying core domains
  - 考虑多种后缀 / Consider multiple suffixes
  - 及时注册 / Register in time

---

### 3. 企业名称查询 / Enterprise Name Query

- **推荐工具 / Recommended Tools**：
  - 国家企业信用信息公示系统（官方权威）/ National Enterprise Credit Information Publicity System (official and authoritative)
  - 企查查（查询速度快）/ Qichacha (fast query speed)
- **使用建议 / Usage Tips**：
  - 优先使用官方工具 / Prioritize official tools
  - 多个工具交叉验证 / Cross-validate with multiple tools
  - 定期查询 / Regular queries

---

### 4. 音韵分析 / Phonetic Analysis

- **推荐工具 / Recommended Tools**：
  - 拼音转换器（汉字转拼音）/ Pinyin Converter (Chinese to pinyin)
  - 国际音标转换器（多语言音标）/ IPA Converter (multi-language IPA)
- **使用建议 / Usage Tips**：
  - 结合专业知识 / Combine with professional knowledge
  - 多种工具交叉验证 / Cross-validate with multiple tools
  - 考虑方言音韵 / Consider dialectal phonetics

---

### 5. 谐音检测 / Homophone Detection

- **推荐工具 / Recommended Tools**：
  - 汉典（汉语谐音）/ Zdic (Chinese homophones)
  - 翻译工具（跨语言谐音）/ Translation tools (cross-lingual homophones)
- **使用建议 / Usage Tips**：
  - 多种语言检测 / Detect multiple languages
  - 结合专业知识 / Combine with professional knowledge
  - 人工验证 / Manual verification

---

### 6. 命名生成 / Name Generation

- **推荐工具 / Recommended Tools**：
  - 中文名字生成器（中文名称）/ Chinese Name Generator (Chinese names)
  - Namelix（英文名称）/ Namelix (English names)
  - Squadhelp（品牌名称）/ Squadhelp (brand names)
- **使用建议 / Usage Tips**：
  - 作为灵感来源 / Use as source of inspiration
  - 结合专业评估 / Combine with professional evaluation
  - 不完全依赖生成结果 / Do not fully rely on generation results

---

## 参考资源 / References

- 国家知识产权局商标局 / CNIPA Trademark Office
- 国家企业信用信息公示系统 / National Enterprise Credit Information Publicity System
- 国际音标协会 / International Phonetic Association
