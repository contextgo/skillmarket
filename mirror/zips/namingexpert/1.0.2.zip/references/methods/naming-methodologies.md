# 命名方法论 / Naming Methodologies

## 目录 / Table of Contents

1. [中文名策略 / Chinese Naming Strategies](#中文名策略)
2. [英文名策略 / English Naming Strategies](#英文名策略)
3. [跨语言命名策略 / Cross-Language Naming Strategies](#跨语言命名策略)

---

## 中文名策略 / Chinese Naming Strategies

### 1. 诗词典故法 / Literary Allusion Method

#### 定义 / Definition

从经典文献中提炼意象，使用诗词、成语、典故中的词汇作为名称。

Extracting imagery from classic literature, using words from poetry, idioms, and allusions as names.

#### 适用场景 / Suitable Scenarios

- 需要文化底蕴的品牌 / Brands needing cultural depth
- 传统行业、文化行业 / Traditional industries, cultural industries
- 追求优雅、品味的品牌 / Brands pursuing elegance, taste

#### 操作步骤 / Operational Steps

1. **选择文化来源 / Choose Cultural Source**：
   - 诗经、楚辞、唐诗、宋词 / Book of Songs, Songs of Chu, Tang Poetry, Song Ci
   - 四书五经 / Four Books and Five Classics
   - 历史典籍、神话传说 / Historical classics, myths and legends

2. **提取核心意象 / Extract Core Imagery**：
   - 选择与品牌定位相符的意象 / Choose imagery matching brand positioning
   - 考虑意象的情感色彩和象征意义 / Consider emotional color and symbolic meaning of imagery

3. **组合创新 / Creative Combination**：
   - 将提取的意象进行组合 / Combine extracted imagery
   - 可以是单字、双字或三字组合 / Can be single, double, or three-character combinations

#### 示例 / Examples

| 名称 / Name | 来源 / Source | 意象 / Imagery | 适用场景 / Suitable Scenes |
|-----------|------------|--------------|--------------------------|
| 启明 / Qǐ Míng | 诗经 / Book of Songs | 启明星、光明 / Morning star, brightness | 科技、教育 / Technology, education |
| 飞鸿 / Fēi Hóng | 诗词 / Poetry | 鸿雁、高飞 / Wild goose, flying high | 通讯、航空 / Communication, aviation |
| 云山 / Yún Shān | 诗词 / Poetry | 云雾、山水 / Clouds, mountains | 旅游、环保 / Tourism, environmental protection |

#### 优点 / Advantages

- 文化底蕴深厚 / Deep cultural depth
- 易于产生情感共鸣 / Easy to generate emotional resonance
- 品牌故事丰富 / Rich brand stories

#### 注意事项 / Precautions

- 确保意象与品牌定位相符 / Ensure imagery matches brand positioning
- 避免使用过于生僻的字 / Avoid using overly rare characters
- 考虑跨文化适应性 / Consider cross-cultural adaptability

---

### 2. 声韵和谐法 / Phonetic Harmony Method

#### 定义 / Definition

注重平仄搭配、韵母协调、声母配合，创造音韵优美的名称。

Focusing on tone combination, vowel coordination, and initial matching to create phonetically beautiful names.

#### 适用场景 / Suitable Scenarios

- 需要朗朗上口的品牌 / Brands needing to be catchy
- 消费品、服务行业 / Consumer goods, service industries
- 追求传播性的品牌 / Brands pursuing communicability

#### 操作步骤 / Operational Steps

1. **确定平仄组合 / Determine Tone Combination**：
   - 选择适合品牌定位的平仄组合 / Choose tone combination suitable for brand positioning
   - 参考：平平、仄仄、平仄、仄平 / Reference: Ping-Ping, Ze-Ze, Ping-Ze, Ze-Ping

2. **选择韵母 / Choose Vowels**：
   - 选择开口度适合的韵母 / Choose vowels with suitable openness
   - 参考：开口呼、齐齿呼、合口呼、撮口呼 / Reference: Open mouth, front vowel, round lips, pursed lips

3. **选择声母 / Choose Initials**：
   - 选择发音部位适合的声母 / Choose initials with suitable articulation position
   - 参考：双唇音、唇齿音、舌尖前音等 / Reference: Bilabial, labiodental, apical, etc.

#### 示例 / Examples

| 名称 / Name | 平仄 / Tones | 韵母 / Vowels | 声母 / Initials | 音韵效果 / Phonetic Effect |
|-----------|-----------|-------------|--------------|-------------------------|
| 春风 / Chūn Fēng | 平平 / Ping-Ping | un, eng | ch, f | 平缓、柔和 / Gentle, soft |
| 智慧 / Zhì Huì | 仄仄 / Ze-Ze | i, ui | zh, h | 有力、现代 / Powerful, modern |
| 山水 / Shān Shuǐ | 平仄 / Ping-Ze | an, ui | sh, sh | 平衡、和谐 / Balanced, harmonious |
| 科技 / Kē Jì | 平仄 / Ping-Ze | e, i | k, j | 有活力、现代 / Energetic, modern |

#### 优点 / Advantages

- 朗朗上口、易于记忆 / Catchy, easy to remember
- 传播性强 / Strong communicability
- 品牌辨识度高 / High brand distinctiveness

#### 注意事项 / Precautions

- 避免过于复杂的声韵组合 / Avoid overly complex phonetic combinations
- 考虑方言发音 / Consider dialectal pronunciation
- 确保音韵与品牌定位相符 / Ensure phonetics match brand positioning

---

### 3. 会意组合法 / Associative Composition Method

#### 定义 / Definition

用字义叠加创造新意境，通过字义组合传达品牌理念。

Creating new artistic conceptions through superimposing character meanings, conveying brand philosophy through character meaning combinations.

#### 适用场景 / Suitable Scenarios

- 需要明确品牌理念的品牌 / Brands needing clear brand philosophy
- 科技、创新行业 / Technology, innovative industries
- 追求寓意的品牌 / Brands pursuing symbolism

#### 操作步骤 / Operational Steps

1. **确定核心概念 / Determine Core Concepts**：
   - 明确品牌的核心价值和理念 / Clarify brand core values and philosophy
   - 提炼关键词 / Extract keywords

2. **选择字义 / Choose Character Meanings**：
   - 选择与核心概念相关的字 / Choose characters related to core concepts
   - 考虑字的内涵和外延 / Consider the connotation and extension of characters

3. **组合创新 / Creative Combination**：
   - 将选定的字进行组合 / Combine selected characters
   - 创造新的意境和寓意 / Create new artistic conceptions and symbolism

#### 示例 / Examples

| 名称 / Name | 组合方式 / Combination Method | 寓意 / Symbolism | 适用场景 / Suitable Scenes |
|-----------|---------------------------|----------------|--------------------------|
| 云启 / Yún Qǐ | 云（云技术）+ 启（开启） | 云端开启新时代 / Opening a new era from the cloud | 科技、云计算 / Technology, cloud computing |
| 智跃 / Zhì Yuè | 智（智慧）+ 跃（飞跃） | 智慧飞跃、突破 / Wisdom leap, breakthrough | 科技、创新 / Technology, innovation |
| 美好 / Měi Hǎo | 美（美丽）+ 好（优良） | 美好、优质 / Beautiful, excellent | 消费品、服务业 / Consumer goods, service industry |

#### 优点 / Advantages

- 寓意明确、易于理解 / Clear symbolism, easy to understand
- 品牌理念突出 / Brand philosophy prominent
- 品牌故事丰富 / Rich brand stories

#### 注意事项 / Precautions

- 避免字义冲突 / Avoid conflicting character meanings
- 确保组合后的寓意积极 / Ensure positive symbolism after combination
- 考虑跨语言适应性 / Consider cross-language adaptability

---

### 4. 行业映射法 / Industry Mapping Method

#### 定义 / Definition

将行业特征隐喻到名称中，通过名称传达行业属性。

Metaphorically embedding industry traits into names, conveying industry attributes through names.

#### 适用场景 / Suitable Scenarios

- 需要明确行业属性的品牌 / Brands needing clear industry attributes
- 传统行业、专业服务 / Traditional industries, professional services
- 追求专业性的品牌 / Brands pursuing professionalism

#### 操作步骤 / Operational Steps

1. **分析行业特征 / Analyze Industry Characteristics**：
   - 识别行业的关键特征 / Identify key characteristics of the industry
   - 提取行业关键词 / Extract industry keywords

2. **选择隐喻词汇 / Choose Metaphorical Vocabulary**：
   - 选择与行业特征相关的词汇 / Choose vocabulary related to industry characteristics
   - 考虑词汇的情感色彩 / Consider emotional color of vocabulary

3. **组合创新 / Creative Combination**：
   - 将隐喻词汇进行组合 / Combine metaphorical vocabulary
   - 创造体现行业特征的名称 / Create names reflecting industry characteristics

#### 示例 / Examples

| 行业 / Industry | 名称 / Name | 行业特征 / Industry Characteristics | 隐喻方式 / Metaphor Method |
|--------------|-----------|---------------------------------|-------------------------|
| 科技 / Technology | 芯界 / Xīn Jiè | 芯片、核心技术 / Chip, core technology | 芯（芯片）+ 界（世界） / Chip + World |
| 金融 / Finance | 金信 / Jīn Xìn | 金钱、信用 / Money, credit | 金（金）+ 信（信用） / Gold + Credit |
| 环保 / Environment | 绿源 / Lǜ Yuán | 绿色、源头 / Green, source | 绿（绿色）+ 源（源头） / Green + Source |
| 教育 / Education | 启明 / Qǐ Míng | 启迪、光明 / Enlightenment, brightness | 启（启迪）+ 明（光明） / Enlightenment + Brightness |

#### 优点 / Advantages

- 行业属性明确 / Clear industry attributes
- 专业性强 / Strong professionalism
- 易于目标受众识别 / Easy for target audience to identify

#### 注意事项 / Precautions

- 避免过于直白的行业词汇 / Avoid overly straightforward industry vocabulary
- 考虑品牌差异化 / Consider brand differentiation
- 确保隐喻的准确性 / Ensure accuracy of metaphors

---

## 英文名策略 / English Naming Strategies

### 1. 词根组合法 / Root Composition Method

#### 定义 / Definition

使用 Latin 或希腊词根构建新词，创造具有专业感的名称。

Building neologisms using Latin or Greek roots, creating names with a professional feel.

#### 适用场景 / Suitable Scenarios

- 科技、医药、学术等行业 / Technology, pharmaceutical, academic industries
- 需要专业感的品牌 / Brands needing professionalism
- 追求国际化的品牌 / Brands pursuing internationalization

#### 操作步骤 / Operational Steps

1. **选择词根 / Choose Roots**：
   - 选择与品牌定位相关的词根 / Choose roots related to brand positioning
   - 参考 Latin 或希腊词根 / Reference Latin or Greek roots

2. **组合创新 / Creative Combination**：
   - 将选定的词根进行组合 / Combine selected roots
   - 创造新词 / Create neologisms

3. **验证发音 / Verify Pronunciation**：
   - 确保发音优美、易于记忆 / Ensure pronunciation is beautiful and easy to remember
   - 避免复杂的拼写 / Avoid complex spelling

#### 常用词根 / Common Roots

| 词根 / Root | 含义 / Meaning | 示例 / Examples |
|-----------|-------------|----------------|
| Tech- | 科技、技术 / Technology, technique | Technology, Technical |
| Info- | 信息 / Information | Information, Informatics |
- | 智能、智慧 / Smart, intelligent | Intelligence, Smart
- | 云、天空 / Cloud, sky | Cloud, Skyward
- | 生命、生物 / Life, bio | Biology, Biotechnology

#### 示例 / Examples

| 名称 / Name | 词根组合 / Root Combination | 寓意 / Symbolism | 适用场景 / Suitable Scenes |
|-----------|------------------------|----------------|--------------------------|
| Microsoft | Micro- + Soft | 微型软件 / Micro software | 科技 / Technology |
| Intel | Intel- (Intelligence) | 智能 / Intelligence | 科技 / Technology |
- | -tech | 科技 / Technology | 科技 / Technology |
- | -soft | 软件 / Software | 软件 / Software |

#### 优点 / Advantages

- 专业感强 / Strong professionalism
- 国际化程度高 / High degree of internationalization
- 独特性强 / Strong uniqueness

#### 注意事项 / Precautions

- 确保词根含义准确 / Ensure accurate root meanings
- 避免过于复杂的词根组合 / Avoid overly complex root combinations
- 考虑发音和拼写 / Consider pronunciation and spelling

---

### 2. 缩写再造法 / Acronym Reinvention Method

#### 定义 / Definition

取核心词首字母组合，创造易于记忆的名称。

Combining initials of key words to create easy-to-remember names.

#### 适用场景 / Suitable Scenarios

- 多产品线的品牌 / Brands with multiple product lines
- 需要简洁名称的品牌 / Brands needing concise names
- 追求传播性的品牌 / Brands pursuing communicability

#### 操作步骤 / Operational Steps

1. **确定核心词 / Determine Core Words**：
   - 提取品牌或产品的核心词 / Extract core words of brand or products
   - 通常为 2-4 个词 / Usually 2-4 words

2. **提取首字母 / Extract Initials**：
   - 提取核心词的首字母 / Extract initials of core words
   - 考虑大小写组合 / Consider uppercase and lowercase combinations

3. **发音优化 / Pronunciation Optimization**：
   - 确保缩写可以发音 / Ensure acronym is pronounceable
   - 优化发音，使其朗朗上口 / Optimize pronunciation to make it catchy

#### 示例 / Examples

| 名称 / Name | 核心词 / Core Words | 首字母 / Initials | 发音优化 / Pronunciation Optimization |
|-----------|-------------------|-----------------|--------------------------------|
| IBM | International Business Machines | I-B-M | I-B-M |
| KFC | Kentucky Fried Chicken | K-F-C | K-F-C |
- | Search + Engine | S-E | She (she) |
- | Picture + Element | P-E | Pixel (像素) |

#### 优点 / Advantages

- 简洁易记 / Concise and easy to remember
- 传播性强 / Strong communicability
- 品牌故事丰富 / Rich brand stories

#### 注意事项 / Precautions

- 确保核心词与品牌定位相符 / Ensure core words match brand positioning
- 避免过于复杂的缩写 / Avoid overly complex acronyms
- 考虑跨文化发音 / Consider cross-cultural pronunciation

---

### 3. 隐喻联想法 / Metaphorical Association Method

#### 定义 / Definition

通过意象传达品牌精神，使用隐喻性词汇创造品牌名称。

Conveying brand spirit through imagery, using metaphorical vocabulary to create brand names.

#### 适用场景 / Suitable Scenarios

- 需要情感共鸣的品牌 / Brands needing emotional resonance
- 消费品、服务行业 / Consumer goods, service industries
- 追求品牌故事的品牌 / Brands pursuing brand stories

#### 操作步骤 / Operational Steps

1. **确定品牌精神 / Determine Brand Spirit**：
   - 明确品牌的核心精神和价值观 / Clarify brand core spirit and values
   - 提取关键情感词 / Extract key emotional words

2. **选择隐喻意象 / Choose Metaphorical Imagery**：
   - 选择与品牌精神相关的意象 / Choose imagery related to brand spirit
   - 考虑意象的情感色彩 / Consider emotional color of imagery

3. **创造品牌名称 / Create Brand Name**：
   - 将隐喻意象转化为品牌名称 / Convert metaphorical imagery into brand name
   - 确保名称与意象的关联性 / Ensure correlation between name and imagery

#### 常见隐喻意象 / Common Metaphorical Imagery

| 意象 / Imagery | 象征 / Symbolism | 示例 / Examples |
|--------------|----------------|----------------|
| Sun / 太阳 | 阳光、希望、活力 / Sunshine, hope, vitality | Sunny, Solar, Sunbright |
- | 星星 / Star | 指引、梦想、卓越 / Guidance, dream, excellence | Star, Stellar, Starlight |
- | 山脉 / Mountain | 稳定、力量、高度 / Stability, power, height | Mountain, Peak, Summit |
- | 海洋 / Ocean | 宽广、深邃、包容 / Broad, deep, inclusive | Ocean, Sea, Pacific |

#### 示例 / Examples

| 名称 / Name | 隐喻意象 / Metaphorical Imagery | 品牌精神 / Brand Spirit | 适用场景 / Suitable Scenes |
|-----------|----------------------------|----------------------|--------------------------|
| Apple | 苹果（知识、创新） / Apple (knowledge, innovation) | 创新、活力 / Innovation, vitality | 科技 / Technology |
- | 星星 / Star | 指引、梦想 / Guidance, dream | 导航、旅游 / Navigation, tourism |
- | 山峰 / Peak | 卓越、巅峰 / Excellence, peak | 体育、挑战 / Sports, challenge |

#### 优点 / Advantages

- 情感共鸣强 / Strong emotional resonance
- 品牌故事丰富 / Rich brand stories
- 品牌辨识度高 / High brand distinctiveness

#### 注意事项 / Precautions

- 确保隐喻意象与品牌精神相符 / Ensure metaphorical imagery matches brand spirit
- 避免过于抽象的隐喻 / Avoid overly abstract metaphors
- 考虑跨文化理解 / Consider cross-cultural understanding

---

### 4. 音韵模仿法 / Phonetic Neologism Method

#### 定义 / Definition

创造发音悦耳的 neologism，通过优美的音韵创造品牌名称。

Creating pleasant-sounding neologisms, creating brand names through beautiful phonetics.

#### 适用场景 / Suitable Scenarios

- 需要朗朗上口的品牌 / Brands needing to be catchy
- 消费品、服务行业 / Consumer goods, service industries
- 追求传播性的品牌 / Brands pursuing communicability

#### 操作步骤 / Operational Steps

1. **确定音韵风格 / Determine Phonetic Style**：
   - 选择适合品牌定位的音韵风格 / Choose phonetic style suitable for brand positioning
   - 参考：柔和、有力、现代、传统 / Reference: soft, powerful, modern, traditional

2. **创造音韵组合 / Create Phonetic Combination**：
   - 创造优美的音韵组合 / Create beautiful phonetic combinations
   - 确保发音流畅 / Ensure smooth pronunciation

3. **验证拼写 / Verify Spelling**：
   - 确保拼写简洁、易读 / Ensure concise, easy-to-read spelling
   - 避免复杂的拼写 / Avoid complex spelling

#### 示例 / Examples

| 名称 / Name | 音韵组合 / Phonetic Combination | 音韵效果 / Phonetic Effect | 适用场景 / Suitable Scenes |
|-----------|-----------------------------|-------------------------|--------------------------|
| Kodak | K-da-k | 简洁、有力 / Concise, powerful | 摄影 / Photography |
| Xerox | Ze-rox | 现代、科技 / Modern, technology | 办公 / Office |
| Rolex | Ro-lex | 优雅、高端 / Elegant, high-end | 奢侈品 / Luxury |

#### 优点 / Advantages

- 发音优美、朗朗上口 / Beautiful pronunciation, catchy
- 独特性强 / Strong uniqueness
- 传播性强 / Strong communicability

#### 注意事项 / Precautions

- 确保音韵与品牌定位相符 / Ensure phonetics match brand positioning
- 避免过于复杂的音韵组合 / Avoid overly complex phonetic combinations
- 考虑跨文化发音 / Consider cross-cultural pronunciation

---

## 跨语言命名策略 / Cross-Language Naming Strategies

### 1. 语音转写 / Transliteration

#### 定义 / Definition

保持原词发音，用目标语言文字表示。

Keep the original pronunciation, represent with target language characters.

#### 示例 / Examples

| 原名 / Original Name | 中文名 / Chinese Name | 转写方式 / Transliteration Method |
|-------------------|-------------------|-------------------------------|
| Coca-Cola | 可口可乐 | 语音转写 / Transliteration |
| McDonald's | 麦当劳 | 语音转写 / Transliteration |
- | 智跃 / SmartLeap | 语音转写 / Transliteration |

#### 优点 / Advantages

- 保持原品牌发音 / Keep original brand pronunciation
- 易于识别原品牌 / Easy to recognize original brand

#### 注意事项 / Precautions

- 检查跨语言谐音 / Check cross-lingual homophones
- 确保转写的汉字有积极寓意 / Ensure transliterated characters have positive meanings

---

### 2. 语义翻译 / Semantic Translation

#### 定义 / Definition

翻译原词含义，用目标语言表达相同含义。

Translate the meaning of the original word, express the same meaning in the target language.

#### 示例 / Examples

| 原名 / Original Name | 中文名 / Chinese Name | 翻译方式 / Translation Method |
|-------------------|-------------------|----------------------------|
| Microsoft | 微软 | 语义翻译 / Semantic translation |
| General Motors | 通用汽车 | 语义翻译 / Semantic translation |
- | 云启 / CloudInit | 语义翻译 / Semantic translation |

#### 优点 / Advantages

- 含义清晰 / Clear meaning
- 易于理解 / Easy to understand

#### 注意事项 / Precautions

- 确保翻译准确 / Ensure accurate translation
- 考虑文化差异 / Consider cultural differences

---

### 3. 文化适配 / Cultural Adaptation

#### 定义 / Definition

根据目标文化调整名称，适应目标市场的文化习惯。

Adjust the name according to the target culture, adapt to the cultural habits of the target market.

#### 示例 / Examples

| 原名 / Original Name | 中文名 / Chinese Name | 适配方式 / Adaptation Method |
|-------------------|-------------------|---------------------------|
| KFC | 肯德基 | 文化适配（适应中国饮食习惯） / Cultural adaptation (adapted to Chinese eating habits) |
- | 星澜 / StarWave | 文化适配（"澜"更优雅） / Cultural adaptation ("澜" is more elegant) |

#### 优点 / Advantages

- 适应目标市场文化 / Adapt to target market culture
- 更易被目标市场接受 / Easier to be accepted by target market

#### 注意事项 / Precautions

- 进行文化适应性测试 / Conduct cultural adaptability testing
- 避免文化冲突 / Avoid cultural conflicts

---

### 4. 完全重新命名 / Complete Renaming

#### 定义 / Definition

在目标市场使用完全不同的名称。

Use a completely different name in the target market.

#### 示例 / Examples

| 原名 / Original Name | 中文名 / Chinese Name | 命名方式 / Naming Method |
|-------------------|-------------------|-----------------------|
| Burberry | 巴宝莉 | 完全重新命名 / Complete renaming |
- | 芯界 / CoreVerse | 完全重新命名 / Complete renaming |

#### 优点 / Advantages

- 完全适应目标市场 / Completely adapt to target market
- 可以创造全新的品牌形象 / Can create a completely new brand image

#### 注意事项 / Precautions

- 确保新名称与原品牌精神相符 / Ensure new name matches original brand spirit
- 考虑品牌一致性 / Consider brand consistency

---

## 参考资源 / References

- 《汉语成语大词典》/ Dictionary of Chinese Idioms
- 《拉丁词根词典》/ Dictionary of Latin Roots
- 《希腊词根词典》/ Dictionary of Greek Roots
- Al Ries & Jack Trout. "Positioning: The Battle for Your Mind"
- Keller, K. L. "Strategic Brand Management"
