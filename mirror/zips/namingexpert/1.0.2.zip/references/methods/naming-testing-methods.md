# 命名测试方法论 / Naming Testing Methodologies

## 目录 / Table of Contents

1. [测试概述 / Testing Overview](#测试概述)
2. [联想测试 / Association Test](#联想测试)
3. [记忆测试 / Memory Test](#记忆测试)
4. [偏好测试 / Preference Test](#偏好测试)
5. [文化适应性测试 / Cultural Adaptability Test](#文化适应性测试)

---

## 测试概述 / Testing Overview

### 测试目的 / Testing Purpose

命名测试是验证候选名称在目标市场中的有效性、适应性和接受度的重要环节。

Naming testing is an important link to verify the effectiveness, adaptability, and acceptance of candidate names in the target market.

---

### 测试原则 / Testing Principles

1. **科学性 / Scientific**：测试方法科学可靠 / Testing methods are scientific and reliable
2. **系统性 / Systematic**：测试流程系统完整 / Testing process is systematic and complete
3. **客观性 / Objective**：测试结果客观公正 / Testing results are objective and fair
4. **实用性 / Practical**：测试结果具有实用价值 / Testing results have practical value

---

### 测试流程 / Testing Process

1. **测试设计 / Test Design**：
   - 确定测试目标 / Determine testing objectives
   - 选择测试方法 / Choose testing methods
   - 设计测试工具 / Design testing tools

2. **测试执行 / Test Execution**：
   - 招募测试对象 / Recruit test subjects
   - 执行测试 / Execute tests
   - 收集数据 / Collect data

3. **数据分析 / Data Analysis**：
   - 分析测试数据 / Analyze test data
   - 生成测试报告 / Generate test report
   - 提出建议 / Provide recommendations

---

## 联想测试 / Association Test

### 测试目的 / Testing Purpose

联想测试用于了解消费者看到名称时产生的联想和情感，评估名称的语义效果。

Association test is used to understand the associations and emotions generated when consumers see the name, evaluating the semantic effect of the name.

---

### 测试方法 / Testing Methods

#### 1. 自由联想 / Free Association

- **测试流程 / Testing Process**：
  1. 向测试对象展示候选名称 / Show candidate names to test subjects
  2. 要求测试对象记录下第一时间想到的所有词汇 / Ask test subjects to record all words that come to mind immediately
  3. 分析测试对象的联想词汇 / Analyze the association words of test subjects

- **测试示例 / Testing Example**：
  - 名称：智跃 / Name: 智跃
  - 测试对象联想 / Test subject association：
    - 科技、创新、智慧、飞跃、进步、未来 / Technology, innovation, wisdom, leap, progress, future

- **评估标准 / Evaluation Criteria**：
  - [ ] 联想积极 / Positive associations
  - [ ] 联想与品牌定位相符 / Associations match brand positioning
  - [ ] 联想一致 / Consistent associations

---

#### 2. 限定联想 / Restricted Association

- **测试流程 / Testing Process**：
  1. 向测试对象展示候选名称 / Show candidate names to test subjects
  2. 提供特定类别，要求测试对象在该类别下进行联想 / Provide specific categories, ask test subjects to associate within those categories
  3. 分析测试对象的联想词汇 / Analyze the association words of test subjects

- **测试示例 / Testing Example**：
  - 名称：智跃 / Name: 智跃
  - 联想类别：行业、产品、情感 / Association categories: Industry, Product, Emotion
  - 测试对象联想 / Test subject association：
    - 行业：科技、互联网 / Industry: Technology, Internet
    - 产品：软件、平台 / Product: Software, platform
    - 情感：兴奋、期待 / Emotion: Excited, expectant

- **评估标准 / Evaluation Criteria**：
  - [ ] 联想与预期一致 / Associations match expectations
  - [ ] 联想丰富 / Rich associations
  - [ ] 联想准确 / Accurate associations

---

#### 3. 图片联想 / Image Association

- **测试流程 / Testing Process**：
  1. 向测试对象展示候选名称 / Show candidate names to test subjects
  2. 要求测试对象绘制或描述名称引发的画面 / Ask test subjects to draw or describe the images triggered by the name
  3. 分析测试对象的画面 / Analyze the images of test subjects

- **测试示例 / Testing Example**：
  - 名称：云启 / Name: 云启
  - 测试对象画面 / Test subject image：
    - 蓝天白云中，一扇大门缓缓打开，象征着新的开始 / In blue sky and white clouds, a door slowly opens, symbolizing a new beginning

- **评估标准 / Evaluation Criteria**：
  - [ ] 画面积极 / Positive images
  - [ ] 画面与品牌定位相符 / Images match brand positioning
  - [ ] 画面一致 / Consistent images

---

## 记忆测试 / Memory Test

### 测试目的 / Testing Purpose

记忆测试用于评估名称的记忆度和识别度，确保名称易于记忆和识别。

Memory test is used to evaluate the memorability and recognizability of the name, ensuring the name is easy to remember and recognize.

---

### 测试方法 / Testing Methods

#### 1. 即时记忆测试 / Immediate Memory Test

- **测试流程 / Testing Process**：
  1. 向测试对象展示候选名称（展示 10 秒） / Show candidate names to test subjects (display for 10 seconds)
  2. 隐藏名称，要求测试对象记录下看到的名称 / Hide names, ask test subjects to record the names they saw
  3. 分析测试对象的记忆准确性 / Analyze the memory accuracy of test subjects

- **测试示例 / Testing Example**：
  - 展示名称：智跃、云启、星澜 / Displayed names: 智跃, 云启, 星澜
  - 测试对象记录 / Test subject recording：智跃、云启、星澜
  - 记忆准确率：100% / Memory accuracy: 100%

- **评估标准 / Evaluation Criteria**：
  - [ ] 记忆准确率高 / High memory accuracy
  - [ ] 记忆时间短 / Short memory time
  - [ ] 记忆一致 / Consistent memory

---

#### 2. 延时记忆测试 / Delayed Memory Test

- **测试流程 / Testing Process**：
  1. 向测试对象展示候选名称 / Show candidate names to test subjects
  2. 等待一段时间（如 1 小时、1 天、1 周） / Wait for a period of time (e.g., 1 hour, 1 day, 1 week)
  3. 要求测试对象记录下看到的名称 / Ask test subjects to record the names they saw
  4. 分析测试对象的记忆准确性 / Analyze the memory accuracy of test subjects

- **测试示例 / Testing Example**：
  - 展示名称：智跃 / Displayed name: 智跃
  - 延时：1 天 / Delay: 1 day
  - 测试对象记录 / Test subject recording：智跃
  - 记忆准确率：100% / Memory accuracy: 100%

- **评估标准 / Evaluation Criteria**：
  - [ ] 记忆持久性好 / Good memory persistence
  - [ ] 记忆准确率高 / High memory accuracy
  - [ ] 记忆一致 / Consistent memory

---

#### 3. 识别测试 / Recognition Test

- **测试流程 / Testing Process**：
  1. 向测试对象展示多个名称（包括候选名称和干扰项） / Show multiple names to test subjects (including candidate names and distractors)
  2. 要求测试对象识别出之前看到的名称 / Ask test subjects to identify the names they saw before
  3. 分析测试对象的识别准确性 / Analyze the recognition accuracy of test subjects

- **测试示例 / Testing Example**：
  - 展示名称：智跃、云启、星澜、飞鸿、山川 / Displayed names: 智跃, 云启, 星澜, 飞鸿, 山川
  - 识别任务：识别出"智跃" / Recognition task: Identify "智跃"
  - 识别准确率：100% / Recognition accuracy: 100%

- **评估标准 / Evaluation Criteria**：
  - [ ] 识别准确率高 / High recognition accuracy
  - [ ] 识别时间短 / Short recognition time
  - [ ] 识别一致 / Consistent recognition

---

## 偏好测试 / Preference Test

### 测试目的 / Testing Purpose

偏好测试用于了解消费者对候选名称的偏好度，评估名称的市场接受度。

Preference test is used to understand consumer preference for candidate names, evaluating market acceptance of the names.

---

### 测试方法 / Testing Methods

#### 1. 排序测试 / Ranking Test

- **测试流程 / Testing Process**：
  1. 向测试对象展示多个候选名称 / Show multiple candidate names to test subjects
  2. 要求测试对象对名称进行排序（从最喜欢到最不喜欢） / Ask test subjects to rank the names (from most liked to least liked)
  3. 分析测试对象的排序 / Analyze the ranking of test subjects

- **测试示例 / Testing Example**：
  - 候选名称：智跃、云启、星澜 / Candidate names: 智跃, 云启, 星澜
  - 测试对象排序 / Test subject ranking：智跃 > 云启 > 星澜

- **评估标准 / Evaluation Criteria**：
  - [ ] 排名靠前 / High ranking
  - [ ] 排序一致 / Consistent ranking
  - [ ] 偏好度高 / High preference

---

#### 2. 配对比较测试 / Paired Comparison Test

- **测试流程 / Testing Process**：
  1. 向测试对象展示候选名称两两组合 / Show candidate names in pairs to test subjects
  2. 要求测试对象选择每组中更喜欢的名称 / Ask test subjects to choose the preferred name in each pair
  3. 分析测试对象的选择 / Analyze the choices of test subjects

- **测试示例 / Testing Example**：
  - 配对：智跃 vs 云启 / Pair: 智跃 vs 云启
  - 测试对象选择 / Test subject choice：智跃

- **评估标准 / Evaluation Criteria**：
  - [ ] 选择率高 / High selection rate
  - [ ] 选择一致 / Consistent choice
  - [ ] 偏好度高 / High preference

---

#### 3. 评分测试 / Rating Test

- **测试流程 / Testing Process**：
  1. 向测试对象展示候选名称 / Show candidate names to test subjects
  2. 要求测试对象对名称进行评分（1-10 分） / Ask test subjects to rate the names (1-10 points)
  3. 分析测试对象的评分 / Analyze the ratings of test subjects

- **测试示例 / Testing Example**：
  - 候选名称：智跃 / Candidate name: 智跃
  - 测试对象评分 / Test subject rating：9/10

- **评估标准 / Evaluation Criteria**：
  - [ ] 评分高 / High rating
  - [ ] 评分一致 / Consistent rating
  - [ ] 偏好度高 / High preference

---

## 文化适应性测试 / Cultural Adaptability Test

### 测试目的 / Testing Purpose

文化适应性测试用于评估名称在目标文化中的适应性和接受度，避免文化冲突。

Cultural adaptability test is used to evaluate the adaptability and acceptance of the name in the target culture, avoiding cultural conflicts.

---

### 测试方法 / Testing Methods

#### 1. 语义测试 / Semantic Test

- **测试流程 / Testing Process**：
  1. 向测试对象展示候选名称 / Show candidate names to test subjects
  2. 要求测试对象解释名称的含义 / Ask test subjects to explain the meaning of the name
  3. 分析测试对象的解释 / Analyze the explanations of test subjects

- **测试示例 / Testing Example**：
  - 名称：智跃 / Name: 智跃
  - 测试对象解释 / Test subject explanation：智慧飞跃，代表智慧和进步 / Wisdom leap, representing wisdom and progress

- **评估标准 / Evaluation Criteria**：
  - [ ] 语义积极 / Positive semantics
  - [ ] 语义与品牌定位相符 / Semantics match brand positioning
  - [ ] 语义一致 / Consistent semantics

---

#### 2. 谐音测试 / Homophone Test

- **测试流程 / Testing Process**：
  1. 向测试对象展示候选名称 / Show candidate names to test subjects
  2. 要求测试对象列出名称的谐音 / Ask test subjects to list the homophones of the name
  3. 分析测试对象的谐音 / Analyze the homophones of test subjects

- **测试示例 / Testing Example**：
  - 名称：智跃 / Name: 智跃
  - 测试对象谐音 / Test subject homophones：智越、直跃、自越

- **评估标准 / Evaluation Criteria**：
  - [ ] 无不良谐音 / No bad homophones
  - [ ] 谐音积极 / Positive homophones
  - [ ] 谐音一致 / Consistent homophones

---

#### 3. 文化联想测试 / Cultural Association Test

- **测试流程 / Testing Process**：
  1. 向测试对象展示候选名称 / Show candidate names to test subjects
  2. 要求测试对象列出名称在目标文化中的联想 / Ask test subjects to list the associations of the name in the target culture
  3. 分析测试对象的联想 / Analyze the associations of test subjects

- **测试示例 / Testing Example**：
  - 名称：云启 / Name: 云启
  - 测试对象联想 / Test subject association：云彩、开启、新的开始 / Clouds, open, new beginning

- **评估标准 / Evaluation Criteria**：
  - [ ] 联想积极 / Positive associations
  - [ ] 联想与品牌定位相符 / Associations match brand positioning
  - [ ] 联想一致 / Consistent associations

---

## 测试报告 / Testing Report

### 报告格式 / Report Format

```
候选名称：_______________________
测试日期：_______________________

测试方法 / Testing Methods：
[ ] 联想测试 / Association Test
[ ] 记忆测试 / Memory Test
[ ] 偏好测试 / Preference Test
[ ] 文化适应性测试 / Cultural Adaptability Test

测试结果 / Testing Results：
联想测试 / Association Test：___ / 10
记忆测试 / Memory Test：___ / 10
偏好测试 / Preference Test：___ / 10
文化适应性测试 / Cultural Adaptability Test：___ / 10

总分 / Total Score：___ / 40

详细分析 / Detailed Analysis：
_______________________
_______________________

风险评估 / Risk Assessment：
[ ] 低风险 / Low Risk
[ ] 中风险 / Medium Risk
[ ] 高风险 / High Risk

建议 / Recommendations：
_______________________
_______________________
```

---

## 参考资源 / References

- Malhotra, N. K. "Marketing Research: An Applied Orientation"
- Aaker, D. A. "Building Strong Brands"
- Keller, K. L. "Strategic Brand Management"
- Kapferer, J.-N. "The New Strategic Brand Management"
