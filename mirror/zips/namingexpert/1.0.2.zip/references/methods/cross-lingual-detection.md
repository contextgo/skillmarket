# 跨语言谐音检测 / Cross-Lingual Homophone Detection

## 目录 / Table of Contents

1. [检测方法论 / Detection Methodology](#检测方法论)
2. [普通话检测 / Mandarin Detection](#普通话检测)
3. [粤语检测 / Cantonese Detection](#粤语检测)
4. [闽南语检测 / Minnan Detection](#闽南语检测)
5. [吴语检测 / Wu Detection](#吴语检测)
6. [英语检测 / English Detection](#英语检测)
7. [日语检测 / Japanese Detection](#日语检测)
8. [韩语检测 / Korean Detection](#韩语检测)

---

## 检测方法论 / Detection Methodology

### 检测流程 / Detection Process

1. **输入名称 / Input Name**：
   - 中文名称 / Chinese name
   - 英文名称 / English name
   - 拼音 / Pinyin

2. **选择目标语言 / Select Target Languages**：
   - 普通话 / Mandarin
   - 粤语 / Cantonese
   - 闽南语 / Minnan
   - 吴语 / Wu
   - 英语 / English
   - 日语 / Japanese
   - 韩语 / Korean

3. **音韵转换 / Phonetic Conversion**：
   - 将名称转换为目标语言的发音 / Convert the name to the target language pronunciation

4. **谐音分析 / Homophone Analysis**：
   - 分析发音在目标语言中的谐音 / Analyze homophones of the pronunciation in the target language

5. **风险评估 / Risk Assessment**：
   - 评估谐音的风险等级 / Assess the risk level of homophones

---

### 风险等级 / Risk Levels

| 风险等级 / Risk Level | 标准 / Standard | 示例 / Examples |
|-------------------|---------------|----------------|
| 高风险 / High Risk | 发音与负面词汇相似，可能引起误解或冒犯 | 发音与负面词汇相似，可能引起误解或冒犯 / Pronunciation similar to negative vocabulary, may cause misunderstanding or offense |
| 中风险 / Medium Risk | 发音与中性或不确定含义的词汇相似，需要进一步评估 / Pronunciation similar to neutral or uncertain meaning vocabulary, needs further evaluation | 发音与中性词汇相似 / Pronunciation similar to neutral vocabulary |
| 低风险 / Low Risk | 发音与积极词汇相似，或无不良谐音 / Pronunciation similar to positive vocabulary, or no bad homophones | 发音与积极词汇相似 / Pronunciation similar to positive vocabulary |

---

## 普通话检测 / Mandarin Detection

### 检测重点 / Detection Focus

- 负面词汇 / Negative vocabulary
- 禁用词汇 / Prohibited vocabulary
- 不雅词汇 / Vulgar vocabulary

---

### 常见不良谐音 / Common Bad Homophones

| 发音 / Pronunciation | 谐音 / Homophone | 风险等级 / Risk Level |
|------------------|----------------|-------------------|
| sǐ | 死 / Die | 高风险 / High Risk |
| shǐ | 屎 / Shit | 高风险 / High Risk |
| bǐ | 屄 / Cunt | 高风险 / High Risk |
| dài | 呆 / Stupid | 中风险 / Medium Risk |
| bèn | 笨 / Stupid | 中风险 / Medium Risk |
| chǔn | 蠢 / Stupid | 中风险 / Medium Risk |
| méi | 没 / No / None | 中风险 / Medium Risk |
| shī | 失 / Lose / Fail | 中风险 / Medium Risk |
| bài | 败 / Defeat | 中风险 / Medium Risk |
| sàng | 丧 / Mourn / Lose | 中风险 / Medium Risk |

---

### 检测方法 / Detection Method

1. **拼音分析 / Pinyin Analysis**：
   - 将中文名称转换为拼音 / Convert Chinese name to pinyin
   - 分析拼音的音韵组合 / Analyze the phonetic combination of pinyin

2. **谐音匹配 / Homophone Matching**：
   - 将拼音与常见不良谐音进行匹配 / Match pinyin with common bad homophones
   - 考虑声调变化 / Consider tone changes

3. **语义分析 / Semantic Analysis**：
   - 分析谐音的语义 / Analyze the semantics of homophones
   - 评估语义的风险 / Assess the risk of semantics

---

## 粤语检测 / Cantonese Detection

### 粤语音韵特点 / Cantonese Phonetics

- **声调 / Tones**：粤语有 6 个声调 / Cantonese has 6 tones
- **入声 / Entering Tone**：粤语保留了入声 / Cantonese preserves entering tones
- **声母 / Initials**：粤语有更多声母 / Cantonese has more initials

---

### 常见不良谐音 / Common Bad Homophones

| 发音 / Pronunciation | 谐音 / Homophone | 风险等级 / Risk Level |
|------------------|----------------|-------------------|
| sei2 | 死 / Die | 高风险 / High Risk |
| gau2 | 狗 / Dog | 高风险 / High Risk |
| lan2 | 懒 / Lazy | 中风险 / Medium Risk |
| hou2 | 吼 / Roar | 中风险 / Medium Risk |
| diu1 | 屌 / Fuck | 高风险 / High Risk |
| caa1 | 差 / Bad | 中风险 / Medium Risk |
| mou5 | 无 / No / None | 中风险 / Medium Risk |
| sai3 | 西 / West | 低风险 / Low Risk |

---

### 检测方法 / Detection Method

1. **粤语拼音转换 / Cantonese Pinyin Conversion**：
   - 将中文名称转换为粤语拼音 / Convert Chinese name to Cantonese pinyin
   - 使用粤拼系统 / Use Jyutping system

2. **谐音匹配 / Homophone Matching**：
   - 将粤语拼音与常见不良谐音进行匹配 / Match Cantonese pinyin with common bad homophones
   - 考虑粤语声调 / Consider Cantonese tones

3. **语义分析 / Semantic Analysis**：
   - 分析谐音的粤语语义 / Analyze the Cantonese semantics of homophones
   - 评估语义的风险 / Assess the risk of semantics

---

## 闽南语检测 / Minnan Detection

### 闽南语音韵特点 / Minnan Phonetics

- **声调 / Tones**：闽南语有 7-8 个声调 / Minnan has 7-8 tones
- **文白异读 / Literary and Colloquial Readings**：闽南语有文白异读现象 / Minnan has literary and colloquial readings
- **鼻化音 / Nasalization**：闽南语有鼻化音现象 / Minnan has nasalization

---

### 常见不良谐音 / Common Bad Homophones

| 发音 / Pronunciation | 谐音 / Homophone | 风险等级 / Risk Level |
|------------------|----------------|-------------------|
| si | 死 / Die | 高风险 / High Risk |
| ka | 嫁 / Marry | 中风险 / Medium Risk |
| ki | 惊 / Afraid | 中风险 / Medium Risk |
| lān | 懒 / Lazy | 中风险 / Medium Risk |
| cha | 差 / Bad | 中风险 / Medium Risk |

---

### 检测方法 / Detection Method

1. **闽南语拼音转换 / Minnan Pinyin Conversion**：
   - 将中文名称转换为闽南语拼音 / Convert Chinese name to Minnan pinyin
   - 使用白话字系统 / Use Pe̍h-ōe-jī system

2. **谐音匹配 / Homophone Matching**：
   - 将闽南语拼音与常见不良谐音进行匹配 / Match Minnan pinyin with common bad homophones
   - 考虑闽南语声调 / Consider Minnan tones

3. **语义分析 / Semantic Analysis**：
   - 分析谐音的闽南语语义 / Analyze the Minnan semantics of homophones
   - 评估语义的风险 / Assess the risk of semantics

---

## 吴语检测 / Wu Detection

### 吴语音韵特点 / Wu Phonetics

- **声调 / Tones**：吴语有 7-8 个声调 / Wu has 7-8 tones
- **浊音 / Voiced Consonants**：吴语保留了浊音 / Wu preserves voiced consonants
- **连读变调 / Tone Sandhi**：吴语有复杂的连读变调 / Wu has complex tone sandhi

---

### 常见不良谐音 / Common Bad Homophones

| 发音 / Pronunciation | 谐音 / Homophone | 风险等级 / Risk Level |
|------------------|----------------|-------------------|
| sy | 死 / Die | 高风险 / High Risk |
| ngu | 懒 / Lazy | 中风险 / Medium Risk |
| tshai | 差 / Bad | 中风险 / Medium Risk |
| go | 狗 / Dog | 高风险 / High Risk |

---

### 检测方法 / Detection Method

1. **吴语拼音转换 / Wu Pinyin Conversion**：
   - 将中文名称转换为吴语拼音 / Convert Chinese name to Wu pinyin
   - 使用吴语拼音系统 / Use Wu pinyin system

2. **谐音匹配 / Homophone Matching**：
   - 将吴语拼音与常见不良谐音进行匹配 / Match Wu pinyin with common bad homophones
   - 考虑吴语声调 / Consider Wu tones

3. **语义分析 / Semantic Analysis**：
   - 分析谐音的吴语语义 / Analyze the Wu semantics of homophones
   - 评估语义的风险 / Assess the risk of semantics

---

## 英语检测 / English Detection

### 检测重点 / Detection Focus

- 中文拼音在英语中的谐音 / Homophones of Chinese pinyin in English
- 英文名称在英语中的谐音 / Homophones of English names in English
- 文化敏感词汇 / Culturally sensitive vocabulary

---

### 常见不良谐音 / Common Bad Homophones

| 发音 / Pronunciation | 谐音 / Homophone | 风险等级 / Risk Level |
|------------------|----------------|-------------------|
| shit | Shit / 屎 | 高风险 / High Risk |
| damn | Damn / 该死 | 中风险 / Medium Risk |
| hell | Hell / 地狱 | 中风险 / Medium Risk |
| kill | Kill / 杀 | 中风险 / Medium Risk |
| die | Die / 死 | 高风险 / High Risk |
| bitch | Bitch / 母狗 | 高风险 / High Risk |
| fuck | Fuck / 操 | 高风险 / High Risk |
| suck | Suck / 糟糕 | 中风险 / Medium Risk |
| dumb | Dumb / 傻 | 中风险 / Medium Risk |
| stupid | Stupid / 愚蠢 | 中风险 / Medium Risk |

---

### 检测方法 / Detection Method

1. **拼音英语化 / Pinyin Anglicization**：
   - 将中文名称转换为拼音 / Convert Chinese name to pinyin
   - 分析拼音在英语中的发音 / Analyze the pronunciation of pinyin in English

2. **谐音匹配 / Homophone Matching**：
   - 将英语发音与常见不良谐音进行匹配 / Match English pronunciation with common bad homophones
   - 考虑英语发音变化 / Consider English pronunciation variations

3. **语义分析 / Semantic Analysis**：
   - 分析谐音的英语语义 / Analyze the English semantics of homophones
   - 评估语义的风险 / Assess the risk of semantics

---

## 日语检测 / Japanese Detection

### 日语音韵特点 / Japanese Phonetics

- **音节 / Syllables**：日语有 5 个元音 / Japanese has 5 vowels
- **促音 / Geminate Consonants**：日语有促音现象 / Japanese has geminate consonants
- **长音 / Long Vowels**：日语有长音现象 / Japanese has long vowels

---

### 常见不良谐音 / Common Bad Homophones

| 发音 / Pronunciation | 谐音 / Homophone | 风险等级 / Risk Level |
|------------------|----------------|-------------------|
| shi | 死 / Die | 高风险 / High Risk |
| shin | 死 / Die | 高风险 / High Risk |
| kurau | 食う / Eat / Eat up | 中风险 / Medium Risk |
| baka | 馬鹿 / Stupid | 中风险 / Medium Risk |
| aho | 阿呆 / Idiot | 中风险 / Medium Risk |

---

### 检测方法 / Detection Method

1. **日语罗马字转换 / Japanese Romanization**：
   - 将中文名称转换为日语罗马字 / Convert Chinese name to Japanese romaji
   - 使用赫本式罗马字 / Use Hepburn romanization

2. **谐音匹配 / Homophone Matching**：
   - 将日语罗马字与常见不良谐音进行匹配 / Match Japanese romaji with common bad homophones
   - 考虑日语声调 / Consider Japanese pitch accent

3. **语义分析 / Semantic Analysis**：
   - 分析谐音的日语语义 / Analyze the Japanese semantics of homophones
   - 评估语义的风险 / Assess the risk of semantics

---

## 韩语检测 / Korean Detection

### 韩语音韵特点 / Korean Phonetics

- **音节 / Syllables**：韩语有 10 个元音 / Korean has 10 vowels
- **收音 / Final Consonants**：韩语有收音现象 / Korean has final consonants
- **音变 / Sound Changes**：韩语有复杂的音变现象 / Korean has complex sound changes

---

### 常见不良谐音 / Common Bad Homophones

| 发音 / Pronunciation | 谐音 / Homophone | 风险等级 / Risk Level |
|------------------|----------------|-------------------|
| sa | 死 / Die | 高风险 / High Risk |
| bab | 飯 / Rice | 中风险 / Medium Risk |
| go | 狗 / Dog | 高风险 / High Risk |
| kkot | 花 / Flower | 低风险 / Low Risk |

---

### 检测方法 / Detection Method

1. **韩语罗马字转换 / Korean Romanization**：
   - 将中文名称转换为韩语罗马字 / Convert Chinese name to Korean romaji
   - 使用文化观光部罗马字 / Use Revised Romanization of Korean

2. **谐音匹配 / Homophone Matching**：
   - 将韩语罗马字与常见不良谐音进行匹配 / Match Korean romaji with common bad homophones
   - 考虑韩语音变 / Consider Korean sound changes

3. **语义分析 / Semantic Analysis**：
   - 分析谐音的韩语语义 / Analyze the Korean semantics of homophones
   - 评估语义的风险 / Assess the risk of semantics

---

## 检测报告 / Detection Report

### 报告格式 / Report Format

```
名称：_______________________
拼音：_______________________
英文：_______________________

检测语言 / Detected Languages：
- 普通话 / Mandarin：[ ] 通过 [ ] 未通过
- 粤语 / Cantonese：[ ] 通过 [ ] 未通过
- 闽南语 / Minnan：[ ] 通过 [ ] 未通过
- 吴语 / Wu：[ ] 通过 [ ] 未通过
- 英语 / English：[ ] 通过 [ ] 未通过
- 日语 / Japanese：[ ] 通过 [ ] 未通过
- 韩语 / Korean：[ ] 通过 [ ] 未通过

详细分析 / Detailed Analysis：
_______________________
_______________________

风险评估 / Risk Assessment：
[ ] 低风险 / Low Risk
[ ] 中风险 / Medium Risk
[ ] 高风险 / High Risk

建议 / Recommendations：
_______________________
_______________________
```

---

## 参考资源 / References

- 《现代汉语词典》/ Modern Chinese Dictionary
- 《粤拼方案》/ Jyutping Scheme
- 《白话字方案》/ Pe̍h-ōe-jī Scheme
- 《吴语拼音方案》/ Wu Pinyin Scheme
- 《日语罗马字方案》/ Japanese Romanization Schemes
- 《韩语罗马字方案》/ Korean Romanization Schemes
