# 决策矩阵模板 / Decision Matrix Template

## 使用说明 / Usage Instructions

本模板用于通过多维度评估，系统化地比较候选名称，做出最终决策。

This template is used to systematically compare candidate names through multi-dimensional evaluation to make final decisions.

---

## 候选名称 / Candidate Names

```
候选名称总数：_________
候选名称列表：
1. _______________________
2. _______________________
3. _______________________
4. _______________________
5. _______________________
...（继续添加）
```

---

## 评估维度 / Evaluation Dimensions

### 1. 品牌一致性 / Brand Consistency

- [ ] 符合品牌定位 / Matches brand positioning
- [ ] 符合品牌个性 / Matches brand personality
- [ ] 符合品牌价值观 / Matches brand values
- [ ] 符合命名风格 / Matches naming style

---

### 2. 市场适应性 / Market Adaptability

- [ ] 易于目标受众接受 / Easy for target audience to accept
- [ ] 符合行业规范 / Meets industry standards
- [ ] 具有差异化 / Differentiated
- [ ] 具有竞争力 / Competitive

---

### 3. 传播性 / Communicability

- [ ] 易于记忆 / Easy to remember
- [ ] 易于传播 / Easy to communicate
- [ ] 易于拼写 / Easy to spell
- [ ] 易于搜索 / Easy to search

---

### 4. 保护性 / Protectability

- [ ] 商标可注册 / Trademark registerable
- [ ] 域名可用 / Domain available
- [ ] 企业名称可登记 / Enterprise name registrable
- [ ] 法律风险低 / Low legal risk

---

### 5. 跨语言适应性 / Cross-Lingual Adaptability

- [ ] 英文发音优美 / Beautiful English pronunciation
- [ ] 英文寓意积极 / Positive English meaning
- [ ] 跨语言谐音良好 / Good cross-lingual homophones
- [ ] 文化适应性良好 / Good cultural adaptability

---

### 6. 成本效益 / Cost-Benefit

- [ ] 注册成本低 / Low registration cost
- [ ] 推广成本低 / Low promotion cost
- [ ] 维护成本低 / Low maintenance cost
- [ ] ROI 高 / High ROI

---

## 权重分配 / Weight Distribution

根据品牌需求，为每个评估维度分配权重（总和为 100%）。

Assign weights to each evaluation dimension based on brand needs (total 100%).

| 评估维度 / Evaluation Dimension | 权重 / Weight |
|-------------------------------|-------------|
| 品牌一致性 / Brand Consistency | ________% |
| 市场适应性 / Market Adaptability | ________% |
| 传播性 / Communicability | ________% |
| 保护性 / Protectability | ________% |
| 跨语言适应性 / Cross-Lingual Adaptability | ________% |
| 成本效益 / Cost-Benefit | ________% |
| **合计 / Total** | **100%** |

---

## 评分标准 / Scoring Criteria

每个维度的评分范围为 1-10 分。

The score range for each dimension is 1-10 points.

| 分数 / Score | 标准 / Standard |
|------------|---------------|
| 10 | 优秀 / Excellent |
| 9-8 | 良好 / Good |
| 7-6 | 一般 / Fair |
| 5-4 | 较差 / Poor |
| 3-1 | 很差 / Very Poor |

---

## 评估矩阵 / Evaluation Matrix

### 候选名称 1 / Candidate Name 1: _______________________

| 评估维度 / Evaluation Dimension | 权重 / Weight | 评分 / Score | 加权分数 / Weighted Score | 备注 / Notes |
|-------------------------------|-------------|-----------|----------------------|-----------|
| 品牌一致性 / Brand Consistency | ________% | _____ | __________ | __________ |
| 市场适应性 / Market Adaptability | ________% | _____ | __________ | __________ |
| 传播性 / Communicability | ________% | _____ | __________ | __________ |
| 保护性 / Protectability | ________% | _____ | __________ | __________ |
| 跨语言适应性 / Cross-Lingual Adaptability | ________% | _____ | __________ | __________ |
| 成本效益 / Cost-Benefit | ________% | _____ | __________ | __________ |
| **总分 / Total Score** | **100%** | | **__________** | |

---

### 候选名称 2 / Candidate Name 2: _______________________

| 评估维度 / Evaluation Dimension | 权重 / Weight | 评分 / Score | 加权分数 / Weighted Score | 备注 / Notes |
|-------------------------------|-------------|-----------|----------------------|-----------|
| 品牌一致性 / Brand Consistency | ________% | _____ | __________ | __________ |
| 市场适应性 / Market Adaptability | ________% | _____ | __________ | __________ |
| 传播性 / Communicability | ________% | _____ | __________ | __________ |
| 保护性 / Protectability | ________% | _____ | __________ | __________ |
| 跨语言适应性 / Cross-Lingual Adaptability | ________% | _____ | __________ | __________ |
| 成本效益 / Cost-Benefit | ________% | _____ | __________ | __________ |
| **总分 / Total Score** | **100%** | | **__________** | |

---

### 候选名称 3 / Candidate Name 3: _______________________

| 评估维度 / Evaluation Dimension | 权重 / Weight | 评分 / Score | 加权分数 / Weighted Score | 备注 / Notes |
|-------------------------------|-------------|-----------|----------------------|-----------|
| 品牌一致性 / Brand Consistency | ________% | _____ | __________ | __________ |
| 市场适应性 / Market Adaptability | ________% | _____ | __________ | __________ |
| 传播性 / Communicability | ________% | _____ | __________ | __________ |
| 保护性 / Protectability | ________% | _____ | __________ | __________ |
| 跨语言适应性 / Cross-Lingual Adaptability | ________% | _____ | __________ | __________ |
| 成本效益 / Cost-Benefit | ________% | _____ | __________ | __________ |
| **总分 / Total Score** | **100%** | | **__________** | |

---

### 候选名称 4 / Candidate Name 4: _______________________

| 评估维度 / Evaluation Dimension | 权重 / Weight | 评分 / Score | 加权分数 / Weighted Score | 备注 / Notes |
|-------------------------------|-------------|-----------|----------------------|-----------|
| 品牌一致性 / Brand Consistency | ________% | _____ | __________ | __________ |
| 市场适应性 / Market Adaptability | ________% | _____ | __________ | __________ |
| 传播性 / Communicability | ________% | _____ | __________ | __________ |
| 保护性 / Protectability | ________% | _____ | __________ | __________ |
| 跨语言适应性 / Cross-Lingual Adaptability | ________% | _____ | __________ | __________ |
| 成本效益 / Cost-Benefit | ________% | _____ | __________ | __________ |
| **总分 / Total Score** | **100%** | | **__________** | |

---

### 候选名称 5 / Candidate Name 5: _______________________

| 评估维度 / Evaluation Dimension | 权重 / Weight | 评分 / Score | 加权分数 / Weighted Score | 备注 / Notes |
|-------------------------------|-------------|-----------|----------------------|-----------|
| 品牌一致性 / Brand Consistency | ________% | _____ | __________ | __________ |
| 市场适应性 / Market Adaptability | ________% | _____ | __________ | __________ |
| 传播性 / Communicability | ________% | _____ | __________ | __________ |
| 保护性 / Protectability | ________% | _____ | __________ | __________ |
| 跨语言适应性 / Cross-Lingual Adaptability | ________% | _____ | __________ | __________ |
| 成本效益 / Cost-Benefit | ________% | _____ | __________ | __________ |
| **总分 / Total Score** | **100%** | | **__________** | |

---

## 综合排名 / Comprehensive Ranking

| 排名 / Rank | 名称 / Name | 总分 / Total Score | 核心优势 / Core Advantages | 核心劣势 / Core Disadvantages |
|-----------|-----------|------------------|--------------------------|----------------------------|
| 1 | ________ | _________ | _________________________ | _________________________ |
| 2 | ________ | _________ | _________________________ | _________________________ |
| 3 | ________ | _________ | _________________________ | _________________________ |
| 4 | ________ | _________ | _________________________ | _________________________ |
| 5 | ________ | _________ | _________________________ | _________________________ |

---

## 最终决策 / Final Decision

### 推荐方案 / Recommended Solution

**首选名称 / Primary Choice**: _______________________

**选择理由 / Selection Reason**:
```
_______________________
_______________________
_______________________
```

---

### 备选方案 / Alternative Solutions

**备选名称 1 / Alternative Name 1**: _______________________

**选择理由 / Selection Reason**:
```
_______________________
```

---

**备选名称 2 / Alternative Name 2**: _______________________

**选择理由 / Selection Reason**:
```
_______________________
```

---

## 风险提示 / Risk Warning

- [ ] 首选名称存在法律风险 / Primary choice has legal risks
- [ ] 首选名称存在文化风险 / Primary choice has cultural risks
- [ ] 首选名称存在传播风险 / Primary choice has communication risks
- [ ] 首选名称存在成本风险 / Primary choice has cost risks

**说明 / Description**:
```
_______________________
_______________________
```

---

## 参考资源 / References

- `six-dimension-evaluation-template.md`
- `risk-assessment-template.md`
- `naming-screening-template.md`
