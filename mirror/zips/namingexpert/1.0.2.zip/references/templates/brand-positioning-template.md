# 品牌定位模板 / Brand Positioning Template

## 使用说明 / Usage Instructions

本模板用于明确品牌定位，为命名提供清晰的方向。

This template is used to clarify brand positioning, providing clear direction for naming.

---

## 基本信息 / Basic Information

```
品牌名称（暂定）：_______________________
所属行业：_______________________
目标市场：_______________________
创建日期：_______________________
```

---

## 品牌核心 / Brand Core

### 1. 品牌愿景 / Brand Vision

#### 定义 / Definition

品牌未来想成为什么样子，品牌的终极目标。

What the brand wants to become in the future, the ultimate goal of the brand.

#### 示例 / Examples

- **阿里巴巴 / Alibaba**：让天下没有难做的生意 / Let no one have no business to do
- **华为 / Huawei**：构建万物互联的智能世界 / Build a fully connected, intelligent world
- **苹果 / Apple**：通过创新改变世界 / Change the world through innovation

#### 你的品牌愿景 / Your Brand Vision
```
_______________________
_______________________
```

---

### 2. 品牌使命 / Brand Mission

#### 定义 / Definition

品牌存在的意义，品牌为用户创造的价值。

The meaning of the brand's existence, the value the brand creates for users.

#### 示例 / Examples

- **阿里巴巴 / Alibaba**：让商业更简单 / Make business simpler
- **华为 / Huawei**：把数字世界带入每个人、每个家庭、每个组织 / Bring the digital world to every person, home, and organization
- **苹果 / Apple**：通过创新的硬件、软件和服务为用户创造最佳体验 / Create the best experience for users through innovative hardware, software, and services

#### 你的品牌使命 / Your Brand Mission
```
_______________________
_______________________
```

---

### 3. 品牌价值观 / Brand Values

#### 定义 / Definition

品牌坚持的原则和信念，指导品牌行为的准则。

The principles and beliefs the brand upholds, guidelines guiding brand behavior.

#### 示例 / Examples

- **阿里巴巴 / Alibaba**：客户第一、团队合作、拥抱变化、诚信、激情、敬业 / Customer first, teamwork, embrace change, integrity, passion, dedication
- **华为 / Huawei**：以客户为中心，以奋斗者为本 / Customer-centric, dedication-oriented
- **苹果 / Apple**：创新、简约、完美 / Innovation, simplicity, perfection

#### 你的品牌价值观 / Your Brand Values
```
1. _______________________
2. _______________________
3. _______________________
4. _______________________
5. _______________________
```

---

### 4. 品牌个性 / Brand Personality

#### 定义 / Definition

如果品牌是一个人，它是什么样的性格。

If the brand were a person, what kind of personality would it have.

#### 品牌原型 / Brand Archetypes

根据荣格心理学，品牌原型分为 12 类：

According to Jungian psychology, brand archetypes are divided into 12 types:

1. **天真 / The Innocent**：纯真、乐观、简单 / Pure, optimistic, simple
   - 示例：Coca-Cola, Disney / Examples: Coca-Cola, Disney

2. **普通人 / The Regular Guy**：亲切、可靠、接地气 / Approachable, reliable, down-to-earth
   - 示例：IKEA, Walmart / Examples: IKEA, Walmart

3. **英雄 / The Hero**：勇敢、有力、成就 / Brave, powerful, achievement
   - 示例：Nike, BMW / Examples: Nike, BMW

4. **照顾者 / The Caregiver**：关怀、保护、温暖 / Caring, protective, warm
   - 示例：Johnson & Johnson, Volvo / Examples: Johnson & Johnson, Volvo

5. **探险家 / The Explorer**：自由、冒险、发现 / Free, adventurous, discovery
   - 示例：Jeep, The North Face / Examples: Jeep, The North Face

6. **反叛者 / The Rebel**：颠覆、创新、打破常规 / Subversive, innovative, breaking conventions
   - 示例：Apple, Harley-Davidson / Examples: Apple, Harley-Davidson

7. **情人 / The Lover**：浪漫、激情、亲密 / Romantic, passionate, intimate
   - 示例：Victoria's Secret, Chanel / Examples: Victoria's Secret, Chanel

8. **创造者 / The Creator**：创造、创新、艺术 / Creative, innovative, artistic
   - 示例：Adobe, LEGO / Examples: Adobe, LEGO

9. **智者 / The Sage**：智慧、知识、真理 / Wise, knowledgeable, truth
   - 示例：Google, BBC / Examples: Google, BBC

10. **统治者 / The Ruler**：掌控、稳定、权威 / Controlling, stable, authoritative
    - 示例：Mercedes-Benz, American Express / Examples: Mercedes-Benz, American Express

11. **魔术师 / The Magician**：变革、神奇、梦想 / Transformative, magical, dreamy
    - 示例：Mastercard, Disney / Examples: Mastercard, Disney

12. **小丑 / The Jester**：幽默、快乐、娱乐 / Humorous, happy, entertaining
    - 示例：M&M's, Old Spice / Examples: M&M's, Old Spice

#### 你的品牌个性 / Your Brand Personality

**品牌原型 / Brand Archetype**: _______________________

**个性特征 / Personality Traits**:
```
1. _______________________
2. _______________________
3. _______________________
4. _______________________
5. _______________________
```

**个性描述 / Personality Description**:
```
_______________________
_______________________
```

---

### 5. 品牌价值主张 / Brand Value Proposition

#### 定义 / Definition

品牌为用户提供的独特价值，为什么用户选择你而不是竞争对手。

The unique value the brand provides to users, why users choose you instead of competitors.

#### 示例 / Examples

- **阿里巴巴 / Alibaba**：让天下没有难做的生意 / Let no one have no business to do
- **华为 / Huawei**：为世界提供无处不在的智能连接 / Provide ubiquitous intelligent connectivity to the world
- **苹果 / Apple**：通过创新的硬件、软件和服务为用户创造最佳体验 / Create the best experience for users through innovative hardware, software, and services

#### 你的品牌价值主张 / Your Brand Value Proposition
```
_______________________
_______________________
```

---

## 目标受众 / Target Audience

### 1. 人口统计学特征 / Demographic Characteristics

- **年龄 / Age**: _______________________
- **性别 / Gender**: _______________________
- **收入 / Income**: _______________________
- **教育 / Education**: _______________________
- **职业 / Occupation**: _______________________
- **地理位置 / Geography**: _______________________

---

### 2. 心理特征 / Psychographic Characteristics

- **生活方式 / Lifestyle**: _______________________
- **兴趣爱好 / Interests**: _______________________
- **价值观 / Values**: _______________________
- **个性 / Personality**: _______________________

---

### 3. 行为特征 / Behavioral Characteristics

- **购买动机 / Purchase Motivation**: _______________________
- **使用场景 / Usage Scenarios**: _______________________
- **购买频率 / Purchase Frequency**: _______________________
- **品牌忠诚度 / Brand Loyalty**: _______________________

---

### 4. 目标受众画像 / Target Audience Persona

```
姓名：_______________________
年龄：_______________________
职业：_______________________
收入：_______________________
家庭状况：_______________________

兴趣爱好：_______________________
生活态度：_______________________
购买动机：_______________________

痛点：_______________________
需求：_______________________
期望：_______________________
```

---

## 竞争分析 / Competitive Analysis

### 1. 主要竞争对手 / Main Competitors

| 竞争对手 / Competitor | 优势 / Strengths | 劣势 / Weaknesses | 市场份额 / Market Share |
|---------------------|-----------------|-----------------|----------------------|
| ____________________ | _________________ | _________________ | ____________________ |
| ____________________ | _________________ | _________________ | ____________________ |
| ____________________ | _________________ | _________________ | ____________________ |

---

### 2. 竞争优势 / Competitive Advantage

#### 成本优势 / Cost Advantage

- [ ] 有 / Yes
- [ ] 无 / No

**说明 / Description**:
```
_______________________
```

---

#### 差异化优势 / Differentiation Advantage

- [ ] 有 / Yes
- [ ] 无 / No

**说明 / Description**:
```
_______________________
```

---

#### 专注优势 / Focus Advantage

- [ ] 有 / Yes
- [ ] 无 / No

**说明 / Description**:
```
_______________________
```

---

### 3. 竞争策略 / Competitive Strategy

- [ ] 成本领先 / Cost Leadership
- [ ] 差异化 / Differentiation
- [ ] 专注 / Focus

**说明 / Description**:
```
_______________________
```

---

## 品牌命名方向 / Brand Naming Direction

### 1. 命名目标 / Naming Goals

- [ ] 建立品牌认知 / Build brand awareness
- [ ] 传达品牌价值 / Convey brand value
- [ ] 区分竞争对手 / Differentiate from competitors
- [ ] 适应国际化 / Adapt to internationalization
- [ ] 保护品牌资产 / Protect brand assets

**其他 / Others**:
```
_______________________
```

---

### 2. 命名风格 / Naming Style

- [ ] 现代 / Modern
- [ ] 传统 / Traditional
- [ ] 科技 / Technology
- [ ] 亲和 / Approachable
- [ ] 高端 / High-end
- [ ] 活力 / Energetic
- [ ] 稳重 / Steady
- [ ] 优雅 / Elegant

**其他 / Others**:
```
_______________________
```

---

### 3. 命名语言 / Naming Language

- [ ] 中文 / Chinese
- [ ] 英文 / English
- [ ] 中英双语 / Chinese-English bilingual
- [ ] 其他语言 / Other languages: _______________________

---

### 4. 命名偏好 / Naming Preferences

#### 字数偏好 / Character Count Preference

- [ ] 单字 / Single character
- [ ] 双字 / Two characters
- [ ] 三字 / Three characters
- [ ] 四字 / Four characters
- [ ] 其他 / Others: _______________________

---

#### 音韵偏好 / Phonetic Preference

- [ ] 平缓 / Gentle
- [ ] 有力 / Powerful
- [ ] 柔和 / Soft
- [ ] 明亮 / Bright
- [ ] 其他 / Others: _______________________

---

#### 寓意偏好 / Symbolism Preference

- [ ] 文化典故 / Literary allusion
- [ ] 行业特征 / Industry characteristics
- [ ] 抽象概念 / Abstract concepts
- [ ] 具体意象 / Concrete imagery
- [ ] 其他 / Others: _______________________

---

## 参考资源 / References

- Al Ries & Jack Trout. "Positioning: The Battle for Your Mind"
- Keller, K. L. "Strategic Brand Management"
- Aaker, D. A. "Building Strong Brands"
- 荣格心理学 / Jungian Psychology
