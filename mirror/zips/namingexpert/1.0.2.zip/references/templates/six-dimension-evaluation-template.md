# 六维度评估模板 / Six-Dimension Evaluation Template

## 使用说明 / Usage Instructions

本模板用于从六个维度全面评估候选名称，确保名称的质量和适配性。

This template is used to comprehensively evaluate candidate names from six dimensions, ensuring name quality and suitability.

---

## 候选名称 / Candidate Name

```
名称：_______________________
拼音：_______________________
英文：_______________________
来源：_______________________
```

---

## 评估维度 / Evaluation Dimensions

### 1. 语义学 / Semantics

#### 评分标准 / Scoring Criteria

| 评分 / Score | 标准 / Standard |
|-----------|---------------|
| 10-8 / Excellent | 字义精准，内涵丰富，与品牌定位完美契合 / Precise meaning, rich connotation, perfectly matches brand positioning |
| 7-6 / Good | 字义准确，内涵明确，与品牌定位基本契合 / Accurate meaning, clear connotation, basically matches brand positioning |
| 5-4 / Fair | 字义尚可，内涵一般，与品牌定位部分契合 / Acceptable meaning, general connotation, partially matches brand positioning |
| 3-0 / Poor | 字义模糊，内涵混乱，与品牌定位不符 / Vague meaning, confusing connotation, does not match brand positioning |

#### 评估问题 / Evaluation Questions

- [ ] 名称的字义是否准确？ / Is the character meaning accurate?
- [ ] 名称的内涵是否丰富？ / Is the connotation rich?
- [ ] 名称与品牌定位是否契合？ / Does the name match brand positioning?
- [ ] 名称是否有负面联想？ / Does the name have negative associations?

#### 评分 / Score: _____ / 10

#### 备注 / Notes:
```
_______________________
_______________________
```

---

### 2. 文化象征与符号学 / Cultural Symbolism & Semiotics

#### 评分标准 / Scoring Criteria

| 评分 / Score | 标准 / Standard |
|-----------|---------------|
| 10-8 / Excellent | 文化符号积极，象征意义明确，无文化冲突 / Positive cultural symbols, clear symbolic meaning, no cultural conflicts |
| 7-6 / Good | 文化符号正面，象征意义清晰，基本无文化冲突 / Positive cultural symbols, clear symbolic meaning, basically no cultural conflicts |
| 5-4 / Fair | 文化符号一般，象征意义模糊，可能存在文化冲突 / General cultural symbols, vague symbolic meaning, possible cultural conflicts |
| 3-0 / Poor | 文化符号负面，象征意义混乱，存在明显文化冲突 / Negative cultural symbols, confusing symbolic meaning, obvious cultural conflicts |

#### 评估问题 / Evaluation Questions

- [ ] 名称的文化符号是否积极？ / Are the cultural symbols positive?
- [ ] 名称的象征意义是否明确？ / Is the symbolic meaning clear?
- [ ] 名称是否存在文化冲突？ / Are there cultural conflicts?
- [ ] 名称在不同文化中的含义是否一致？ / Are the meanings consistent across different cultures?

#### 评分 / Score: _____ / 10

#### 备注 / Notes:
```
_______________________
_______________________
```

---

### 3. 音韵学 / Phonetics

#### 评分标准 / Scoring Criteria

| 评分 / Score | 标准 / Standard |
|-----------|---------------|
| 10-8 / Excellent | 音韵优美，朗朗上口，无不良谐音，跨语言发音一致 / Beautiful phonetics, catchy, no bad homophones, consistent cross-lingual pronunciation |
| 7-6 / Good | 音韵流畅，易于记忆，基本无不良谐音，跨语言发音基本一致 / Smooth phonetics, easy to remember, basically no bad homophones, basically consistent cross-lingual pronunciation |
| 5-4 / Fair | 音韵一般，较难记忆，可能存在不良谐音，跨语言发音存在差异 / General phonetics, hard to remember, possible bad homophones, differences in cross-lingual pronunciation |
| 3-0 / Poor | 音韵拗口，难以记忆，存在明显不良谐音，跨语言发音差异明显 / Awkward phonetics, hard to remember, obvious bad homophones, significant differences in cross-lingual pronunciation |

#### 评估问题 / Evaluation Questions

- [ ] 名称的音韵是否优美？ / Is the phonetics beautiful?
- [ ] 名称是否朗朗上口？ / Is the name catchy?
- [ ] 名称是否存在不良谐音？ / Are there bad homophones?
- [ ] 跨语言发音是否一致？ / Is cross-lingual pronunciation consistent?

#### 评分 / Score: _____ / 10

#### 备注 / Notes:
```
_______________________
_______________________
```

---

### 4. 跨语言谐音 / Cross-Lingual Homophones

#### 评分标准 / Scoring Criteria

| 评分 / Score | 标准 / Standard |
|-----------|---------------|
| 10-8 / Excellent | 多语言无不良谐音，跨语言兼容性完美 / No bad homophones in multiple languages, perfect cross-lingual compatibility |
| 7-6 / Good | 主要语言无不良谐音，跨语言兼容性良好 / No bad homophones in major languages, good cross-lingual compatibility |
| 5-4 / Fair | 部分语言可能存在不良谐音，跨语言兼容性一般 / Possible bad homophones in some languages, general cross-lingual compatibility |
| 3-0 / Poor | 主要语言存在明显不良谐音，跨语言兼容性差 / Obvious bad homophones in major languages, poor cross-lingual compatibility |

#### 评估问题 / Evaluation Questions

- [ ] 中文名称在英语中是否有不良谐音？ / Does the Chinese name have bad homophones in English?
- [ ] 中文名称在日语、韩语中是否有不良谐音？ / Does the Chinese name have bad homophones in Japanese, Korean?
- [ ] 中文名称在粤语、闽南语等方言中是否有不良谐音？ / Does the Chinese name have bad homophones in Cantonese, Minnan, etc.?
- [ ] 英文名称在中文中是否有不良谐音？ / Does the English name have bad homophones in Chinese?

#### 评分 / Score: _____ / 10

#### 备注 / Notes:
```
_______________________
_______________________
```

---

### 5. 品牌传播 / Brand Communication

#### 评分标准 / Scoring Criteria

| 评分 / Score | 标准 / Standard |
|-----------|---------------|
| 10-8 / Excellent | 易于记忆，易于传播，社交媒体一致性完美，SEO 友好 / Easy to remember, easy to communicate, perfect social media consistency, SEO friendly |
| 7-6 / Good | 较易记忆，较易传播，社交媒体一致性良好，基本 SEO 友好 | Relatively easy to remember, relatively easy to communicate, good social media consistency, basically SEO friendly |
| 5-4 / Fair | 记忆度一般，传播性一般，社交媒体一致性一般，SEO 性能一般 / General memorability, general communicability, general social media consistency, general SEO performance |
| 3-0 / Poor | 难以记忆，难以传播，社交媒体一致性差，SEO 性能差 / Hard to remember, hard to communicate, poor social media consistency, poor SEO performance |

#### 评估问题 / Evaluation Questions

- [ ] 名称是否易于记忆？ / Is the name easy to remember?
- [ ] 名称是否易于传播？ / Is the name easy to communicate?
- [ ] 社交媒体账号名称是否可用？ / Are social media account names available?
- [ ] 名称是否 SEO 友好？ / Is the name SEO friendly?

#### 评分 / Score: _____ / 10

#### 备注 / Notes:
```
_______________________
_______________________
```

---

### 6. 保护性 / Protectability

#### 评分标准 / Scoring Criteria

| 评分 / Score | 标准 / Standard |
|-----------|---------------|
| 10-8 / Excellent | 商标可注册，域名可用，企业名称可登记，法律风险极低 / Trademark registerable, domain available, enterprise name registrable, very low legal risk |
| 7-6 / Good | 商标基本可注册，域名基本可用，企业名称基本可登记，法律风险较低 / Trademark basically registerable, domain basically available, enterprise name basically registrable, relatively low legal risk |
| 5-4 / Fair | 商标注册困难，域名注册困难，企业名称登记困难，法律风险较高 / Trademark registration difficult, domain registration difficult, enterprise name registration difficult, relatively high legal risk |
| 3-0 / Poor | 商标无法注册，域名已被注册，企业名称已被占用，法律风险极高 / Trademark cannot be registered, domain already registered, enterprise name already occupied, very high legal risk |

#### 评估问题 / Evaluation Questions

- [ ] 名称的商标是否可注册？ / Is the trademark registerable?
- [ ] 名称的域名是否可用？ / Is the domain available?
- [ ] 名称的企业名称是否可登记？ / Is the enterprise name registrable?
- [ ] 名称是否存在法律风险？ / Are there legal risks?

#### 评分 / Score: _____ / 10

#### 备注 / Notes:
```
_______________________
_______________________
```

---

## 总评分 / Total Score

```
语义学 / Semantics: _____ / 10
文化象征与符号学 / Cultural Symbolism & Semiotics: _____ / 10
音韵学 / Phonetics: _____ / 10
跨语言谐音 / Cross-Lingual Homophones: _____ / 10
品牌传播 / Brand Communication: _____ / 10
保护性 / Protectability: _____ / 10

总分 / Total Score: _____ / 60
平均分 / Average Score: _____ / 10
```

---

## 评估结论 / Evaluation Conclusion

### 综合评级 / Comprehensive Rating

| 总分 / Total Score | 评级 / Rating | 建议 / Recommendation |
|------------------|-------------|---------------------|
| 60-54 / 9.0-10.0 | 优秀 / Excellent | 强烈推荐 / Highly recommended |
| 53-48 / 8.0-8.9 | 良好 / Good | 推荐 / Recommended |
| 47-36 / 6.0-7.9 | 一般 / Fair | 谨慎考虑 / Consider with caution |
| 35-0 / 0-5.9 | 较差 / Poor | 不推荐 / Not recommended |

### 核心优势 / Core Advantages
```
_______________________
_______________________
```

### 核心劣势 / Core Disadvantages
```
_______________________
_______________________
```

### 优化建议 / Optimization Suggestions
```
_______________________
_______________________
```

### 最终决策 / Final Decision
- [ ] 采用 / Adopt
- [ ] 修改后采用 / Adopt after modification
- [ ] 不采用 / Do not adopt

---

## 参考资源 / References

- 商标查询系统 / Trademark Query System
- 域名注册平台 / Domain Registration Platform
- 企业名称查询系统 / Enterprise Name Query System
- 《商标法》/ Trademark Law
- 《企业名称登记管理规定》/ Provisions on the Administration of Enterprise Name Registration
