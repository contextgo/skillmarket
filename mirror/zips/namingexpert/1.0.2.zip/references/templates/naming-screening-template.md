# 命名筛选流程模板 / Naming Screening Process Template

## 使用说明 / Usage Instructions

本模板用于系统化地筛选候选名称，从初步筛选到最终决策。

This template is used to systematically screen candidate names, from preliminary screening to final decision-making.

---

## 候选名称池 / Candidate Name Pool

```
名称总数：_________
候选名称列表：
1. _______________________
2. _______________________
3. _______________________
4. _______________________
5. _______________________
6. _______________________
7. _______________________
8. _______________________
9. _______________________
10. _______________________
11. _______________________
12. _______________________
13. _______________________
14. _______________________
15. _______________________
...（继续添加）
```

---

## 第一轮：初步筛选 / Round 1: Preliminary Screening

### 筛选标准 / Screening Criteria

#### 1. 基本合规性 / Basic Compliance

- [ ] 无敏感内容 / No sensitive content
- [ ] 无负面联想 / No negative associations
- [ ] 无禁用词汇 / No prohibited vocabulary
- [ ] 符合命名规范 / Meets naming standards

#### 2. 品牌一致性 / Brand Consistency

- [ ] 符合品牌定位 / Matches brand positioning
- [ ] 符合品牌个性 / Matches brand personality
- [ ] 符合命名风格 / Matches naming style

#### 3. 基本可用性 / Basic Usability

- [ ] 易于记忆 / Easy to remember
- [ ] 易于发音 / Easy to pronounce
- [ ] 易于拼写 / Easy to spell

---

### 筛选结果 / Screening Results

| 序号 / No. | 名称 / Name | 合规性 / Compliance | 一致性 / Consistency | 可用性 / Usability | 通过 / Pass | 备注 / Notes |
|----------|-----------|-------------------|-------------------|------------------|----------|-----------|
| 1 | ________ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 2 | ________ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 3 | ________ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 4 | ________ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 5 | ________ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 6 | ________ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 7 | ________ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 8 | ________ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 9 | ________ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 10 | ________ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |

---

### 第一轮通过名单 / Round 1 Passed List

```
通过数量：_________
通过名称：
1. _______________________
2. _______________________
3. _______________________
4. _______________________
5. _______________________
6. _______________________
7. _______________________
8. _______________________
...（继续添加）
```

---

## 第二轮：深度筛选 / Round 2: Deep Screening

### 筛选标准 / Screening Criteria

#### 1. 六维度评估 / Six-Dimension Evaluation

参考 `six-dimension-evaluation-template.md` 进行详细评估。

Refer to `six-dimension-evaluation-template.md` for detailed evaluation.

#### 2. 法律合规性 / Legal Compliance

- [ ] 商标查询 / Trademark query
- [ ] 域名查询 / Domain query
- [ ] 企业名称查询 / Enterprise name query
- [ ] 版权查询 / Copyright query

#### 3. 跨语言适应性 / Cross-Lingual Adaptability

- [ ] 英文发音 / English pronunciation
- [ ] 英文寓意 / English meaning
- [ ] 跨语言谐音 / Cross-lingual homophones
- [ ] 文化适应性 / Cultural adaptability

---

### 筛选结果 / Screening Results

| 序号 / No. | 名称 / Name | 六维度评估 / Six-Dimension Eval | 法律合规 / Legal Compliance | 跨语言适应 / Cross-Lingual Adapt | 通过 / Pass | 备注 / Notes |
|----------|-----------|----------------------------|-------------------------|------------------------------|----------|-----------|
| 1 | ________ | ___ / 60 | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 2 | ________ | ___ / 60 | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 3 | ________ | ___ / 60 | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 4 | ________ | ___ / 60 | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |
| 5 | ________ | ___ / 60 | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | [ ] ✓ [ ] ✗ | __________ |

---

### 第二轮通过名单 / Round 2 Passed List

```
通过数量：_________
通过名称：
1. _______________________
2. _______________________
3. _______________________
4. _______________________
5. _______________________
...（继续添加）
```

---

## 第三轮：最终筛选 / Round 3: Final Screening

### 筛选标准 / Screening Criteria

#### 1. 命名测试 / Naming Testing

参考 `naming-testing-methods.md` 进行用户测试。

Refer to `naming-testing-methods.md` for user testing.

#### 2. 决策矩阵评估 / Decision Matrix Evaluation

参考 `decision-matrix-template.md` 进行决策评估。

Refer to `decision-matrix-template.md` for decision evaluation.

#### 3. 风险评估 / Risk Assessment

参考 `risk-assessment-template.md` 进行风险评估。

Refer to `risk-assessment-template.md` for risk assessment.

---

### 筛选结果 / Screening Results

| 序号 / No. | 名称 / Name | 命名测试 / Naming Testing | 决策矩阵 / Decision Matrix | 风险评估 / Risk Assessment | 通过 / Pass | 备注 / Notes |
|----------|-----------|----------------------|----------------------|----------------------|----------|-----------|
| 1 | ________ | ___ / 10 | ___ / 10 | [ ] 低 [ ] 中 [ ] 高 | [ ] ✓ [ ] ✗ | __________ |
| 2 | ________ | ___ / 10 | ___ / 10 | [ ] 低 [ ] 中 [ ] 高 | [ ] ✓ [ ] ✗ | __________ |
| 3 | ________ | ___ / 10 | ___ / 10 | [ ] 低 [ ] 中 [ ] 高 | [ ] ✓ [ ] ✗ | __________ |

---

## 最终决策 / Final Decision

### 最终通过名单 / Final Passed List

```
通过数量：_________
通过名称：
1. _______________________
2. _______________________
3. _______________________
```

---

### 最终推荐 / Final Recommendation

#### 推荐顺序 / Recommended Order

| 排名 / Rank | 名称 / Name | 总评分 / Total Score | 推荐理由 / Recommendation Reason |
|-----------|-----------|-------------------|------------------------------|
| 1 | ________ | _________ | _________________________ |
| 2 | ________ | _________ | _________________________ |
| 3 | ________ | _________ | _________________________ |

---

### 最终选择 / Final Selection

**选择名称 / Selected Name**: _______________________

**选择理由 / Selection Reason**:
```
_______________________
_______________________
_______________________
```

---

### 备选方案 / Alternative Options

**备选名称 1 / Alternative Name 1**: _______________________

**备选理由 / Alternative Reason**:
```
_______________________
```

---

**备选名称 2 / Alternative Name 2**: _______________________

**备选理由 / Alternative Reason**:
```
_______________________
```

---

## 参考资源 / References

- `six-dimension-evaluation-template.md`
- `decision-matrix-template.md`
- `risk-assessment-template.md`
- `naming-testing-methods.md`
