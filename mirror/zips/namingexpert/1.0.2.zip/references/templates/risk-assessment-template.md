# 风险评估模板 / Risk Assessment Template

## 使用说明 / Usage Instructions

本模板用于评估候选名称的潜在风险，确保品牌命名决策的安全性和可持续性。

This template is used to assess potential risks of candidate names, ensuring the safety and sustainability of brand naming decisions.

---

## 候选名称 / Candidate Name

```
名称：_______________________
拼音：_______________________
英文：_______________________
行业：_______________________
评估日期：_______________________
```

---

## 风险分类 / Risk Classification

### 1. 法律风险 / Legal Risk

#### 商标风险 / Trademark Risk

| 风险类型 / Risk Type | 风险等级 / Risk Level | 说明 / Description | 应对措施 / Mitigation Measures |
|-------------------|-------------------|------------------|-----------------------------|
| 商标冲突 / Trademark conflict | [ ] 低 [ ] 中 [ ] 高 | 与现有商标相似 / Similar to existing trademarks | _______________________ |
| 商标显著性不足 / Insufficient distinctiveness | [ ] 低 [ ] 中 [ ] 高 | 商标显著性不足 / Insufficient distinctiveness | _______________________ |
| 商标分类错误 / Wrong trademark classification | [ ] 低 [ ] 中 [ ] 高 | 商标分类错误 / Wrong trademark classification | _______________________ |

**总体评估 / Overall Assessment**: [ ] 低风险 [ ] 中风险 [ ] 高风险

**备注 / Notes**:
```
_______________________
_______________________
```

---

#### 域名风险 / Domain Risk

| 风险类型 / Risk Type | 风险等级 / Risk Level | 说明 / Description | 应对措施 / Mitigation Measures |
|-------------------|-------------------|------------------|-----------------------------|
| 域名已被注册 / Domain already registered | [ ] 低 [ ] 中 [ ] 高 | 域名已被注册 / Domain already registered | _______________________ |
| 域名价格过高 / Domain price too high | [ ] 低 [ ] 中 [ ] 高 | 域名价格过高 / Domain price too high | _______________________ |
| 域名后缀限制 / Domain suffix restriction | [ ] 低 [ ] 中 [ ] 高 | 域名后缀限制 / Domain suffix restriction | _______________________ |

**总体评估 / Overall Assessment**: [ ] 低风险 [ ] 中风险 [ ] 高风险

**备注 / Notes**:
```
_______________________
_______________________
```

---

#### 企业名称风险 / Enterprise Name Risk

| 风险类型 / Risk Type | 风险等级 / Risk Level | 说明 / Description | 应对措施 / Mitigation Measures |
|-------------------|-------------------|------------------|-----------------------------|
| 企业名称已被占用 / Enterprise name already occupied | [ ] 低 [ ] 中 [ ] 高 | 企业名称已被占用 / Enterprise name already occupied | _______________________ |
| 企业名称不符合规范 / Enterprise name does not meet standards | [ ] 低 [ ] 中 [ ] 高 | 企业名称不符合规范 / Enterprise name does not meet standards | _______________________ |
| 企业名称字号重复 / Enterprise trade name duplication | [ ] 低 [ ] 中 [ ] 高 | 企业名称字号重复 / Enterprise trade name duplication | _______________________ |

**总体评估 / Overall Assessment**: [ ] 低风险 [ ] 中风险 [ ] 高风险

**备注 / Notes**:
```
_______________________
_______________________
```

---

### 2. 文化风险 / Cultural Risk

| 风险类型 / Risk Type | 风险等级 / Risk Level | 说明 / Description | 应对措施 / Mitigation Measures |
|-------------------|-------------------|------------------|-----------------------------|
| 负面文化联想 / Negative cultural association | [ ] 低 [ ] 中 [ ] 高 | 存在负面文化联想 / Exists negative cultural association | _______________________ |
| 文化冲突 / Cultural conflict | [ ] 低 [ ] 中 [ ] 高 | 存在文化冲突 / Exists cultural conflict | _______________________ |
| 文化误解 / Cultural misunderstanding | [ ] 低 [ ] 中 [ ] 高 | 存在文化误解 / Exists cultural misunderstanding | _______________________ |
| 宗教敏感 / Religious sensitivity | [ ] 低 [ ] 中 [ ] 高 | 存在宗教敏感 / Exists religious sensitivity | _______________________ |

**总体评估 / Overall Assessment**: [ ] 低风险 [ ] 中风险 [ ] 高风险

**备注 / Notes**:
```
_______________________
_______________________
```

---

### 3. 语言风险 / Linguistic Risk

#### 谐音风险 / Homophone Risk

| 语言 / Language | 谐音检查 / Homophone Check | 风险等级 / Risk Level | 说明 / Description | 应对措施 / Mitigation Measures |
|--------------|------------------------|-------------------|------------------|-----------------------------|
| 普通话 / Mandarin | [ ] 通过 [ ] 未通过 | [ ] 低 [ ] 中 [ ] 高 | _______________________ | _______________________ |
| 粤语 / Cantonese | [ ] 通过 [ ] 未通过 | [ ] 低 [ ] 中 [ ] 高 | _______________________ | _______________________ |
| 闽南语 / Minnan | [ ] 通过 [ ] 未通过 | [ ] 低 [ ] 中 [ ] 高 | _______________________ | _______________________ |
| 英语 / English | [ ] 通过 [ ] 未通过 | [ ] 低 [ ] 中 [ ] 高 | _______________________ | _______________________ |
| 日语 / Japanese | [ ] 通过 [ ] 未通过 | [ ] 低 [ ] 中 [ ] 高 | _______________________ | _______________________ |

**总体评估 / Overall Assessment**: [ ] 低风险 [ ] 中风险 [ ] 高风险

**备注 / Notes**:
```
_______________________
_______________________
```

---

#### 发音风险 / Pronunciation Risk

| 风险类型 / Risk Type | 风险等级 / Risk Level | 说明 / Description | 应对措施 / Mitigation Measures |
|-------------------|-------------------|------------------|-----------------------------|
| 发音困难 / Difficult to pronounce | [ ] 低 [ ] 中 [ ] 高 | 发音困难 / Difficult to pronounce | _______________________ |
| 发音歧义 / Pronunciation ambiguity | [ ] 低 [ ] 中 [ ] 高 | 发音歧义 / Pronunciation ambiguity | _______________________ |
| 跨语言发音不一致 / Cross-lingual pronunciation inconsistency | [ ] 低 [ ] 中 [ ] 高 | 跨语言发音不一致 / Cross-lingual pronunciation inconsistency | _______________________ |

**总体评估 / Overall Assessment**: [ ] 低风险 [ ] 中风险 [ ] 高风险

**备注 / Notes**:
```
_______________________
_______________________
```

---

### 4. 市场风险 / Market Risk

| 风险类型 / Risk Type | 风险等级 / Risk Level | 说明 / Description | 应对措施 / Mitigation Measures |
|-------------------|-------------------|------------------|-----------------------------|
| 市场认知度低 / Low market awareness | [ ] 低 [ ] 中 [ ] 高 | 市场认知度低 / Low market awareness | _______________________ |
| 与竞争对手名称相似 / Similar to competitor names | [ ] 低 [ ] 中 [ ] 高 | 与竞争对手名称相似 / Similar to competitor names | _______________________ |
| 市场接受度低 / Low market acceptance | [ ] 低 [ ] 中 [ ] 高 | 市场接受度低 / Low market acceptance | _______________________ |
| 品牌差异化不足 / Insufficient brand differentiation | [ ] 低 [ ] 中 [ ] 高 | 品牌差异化不足 / Insufficient brand differentiation | _______________________ |

**总体评估 / Overall Assessment**: [ ] 低风险 [ ] 中风险 [ ] 高风险

**备注 / Notes**:
```
_______________________
_______________________
```

---

### 5. 传播风险 / Communication Risk

| 风险类型 / Risk Type | 风险等级 / Risk Level | 说明 / Description | 应对措施 / Mitigation Measures |
|-------------------|-------------------|------------------|-----------------------------|
| 社交媒体账号名称不可用 / Social media account name unavailable | [ ] 低 [ ] 中 [ ] 高 | 社交媒体账号名称不可用 / Social media account name unavailable | _______________________ |
| SEO 性能差 / Poor SEO performance | [ ] 低 [ ] 中 [ ] 高 | SEO 性能差 / Poor SEO performance | _______________________ |
| 传播成本高 / High communication cost | [ ] 低 [ ] 中 [ ] 高 | 传播成本高 / High communication cost | _______________________ |
| 记忆度低 / Low memorability | [ ] 低 [ ] 中 [ ] 高 | 记忆度低 / Low memorability | _______________________ |

**总体评估 / Overall Assessment**: [ ] 低风险 [ ] 中风险 [ ] 高风险

**备注 / Notes**:
```
_______________________
_______________________
```

---

## 综合风险评估 / Comprehensive Risk Assessment

### 风险矩阵 / Risk Matrix

| 风险类别 / Risk Category | 风险等级 / Risk Level | 权重 / Weight | 加权风险等级 / Weighted Risk Level |
|----------------------|-------------------|-------------|-----------------------------|
| 法律风险 / Legal Risk | [ ] 低 [ ] 中 [ ] 高 | 40% | _______________________ |
| 文化风险 / Cultural Risk | [ ] 低 [ ] 中 [ ] 高 | 20% | _______________________ |
| 语言风险 / Linguistic Risk | [ ] 低 [ ] 中 [ ] 高 | 15% | _______________________ |
| 市场风险 / Market Risk | [ ] 低 [ ] 中 [ ] 高 | 15% | _______________________ |
| 传播风险 / Communication Risk | [ ] 低 [ ] 中 [ ] 高 | 10% | _______________________ |
| **综合风险等级 / Comprehensive Risk Level** | **_______________________** | **100%** | |

---

### 风险评级 / Risk Rating

| 综合风险等级 / Comprehensive Risk Level | 评级 / Rating | 建议 / Recommendation |
|--------------------------------------|-------------|---------------------|
| 低风险 / Low Risk | 安全 / Safe | 推荐使用 / Recommended for use |
| 中风险 / Medium Risk | 谨慎 / Cautious | 评估后使用 / Use after evaluation |
| 高风险 / High Risk | 危险 / Dangerous | 不推荐使用 / Not recommended for use |

---

### 风险应对策略 / Risk Mitigation Strategy

#### 风险规避 / Risk Avoidance

- [ ] 放弃该名称 / Abandon this name
- [ ] 选择低风险备选方案 / Choose low-risk alternative solutions

**说明 / Description**:
```
_______________________
```

---

#### 风险缓解 / Risk Mitigation

- [ ] 进行法律咨询 / Conduct legal consultation
- [ ] 进行文化测试 / Conduct cultural testing
- [ ] 进行语言测试 / Conduct linguistic testing
- [ ] 进行市场测试 / Conduct market testing

**说明 / Description**:
```
_______________________
```

---

#### 风险转移 / Risk Transfer

- [ ] 购买域名保险 / Purchase domain insurance
- [ ] 购买商标保险 / Purchase trademark insurance

**说明 / Description**:
```
_______________________
```

---

## 风险监控 / Risk Monitoring

- [ ] 定期监测商标注册情况 / Regularly monitor trademark registration status
- [ ] 定期监测域名注册情况 / Regularly monitor domain registration status
- [ ] 定期监测市场反馈 / Regularly monitor market feedback
- [ ] 定期监测文化变化 / Regularly monitor cultural changes

**监控周期 / Monitoring Cycle**: _______________________

**监控方式 / Monitoring Method**: _______________________

---

## 最终决策 / Final Decision

### 决策结论 / Decision Conclusion

- [ ] 通过 / Pass
- [ ] 有条件通过 / Conditional pass
- [ ] 不通过 / Fail

**决策理由 / Decision Reason**:
```
_______________________
_______________________
```

---

### 决策条件 / Decision Conditions

**通过条件 / Pass Conditions**:
```
1. _______________________
2. _______________________
3. _______________________
```

**不通过条件 / Fail Conditions**:
```
1. _______________________
2. _______________________
3. _______________________
```

---

## 参考资源 / References

- 商标查询系统 / Trademark Query System
- 域名注册平台 / Domain Registration Platform
- 企业名称查询系统 / Enterprise Name Query System
- 《商标法》/ Trademark Law
- 《企业名称登记管理规定》/ Provisions on the Administration of Enterprise Name Registration
