# 行业命名规范 / Industry Naming Standards

## 目录 / Table of Contents

1. [科技行业 / Technology Industry](#科技行业)
2. [金融行业 / Financial Industry](#金融行业)
3. [消费品行业 / Consumer Goods Industry](#消费品行业)
4. [奢侈品行业 / Luxury Industry](#奢侈品行业)
5. [教育行业 / Education Industry](#教育行业)
6. [医疗健康行业 / Healthcare Industry](#医疗健康行业)

---

## 科技行业 / Technology Industry

### 命名特点 / Naming Characteristics

- 简洁、现代、技术感 / Concise, modern, technological feel
- 易于全球化传播 / Easy for global communication
- 常用词汇：科技、智能、云、芯、数、联 / Common vocabulary: tech, smart, cloud, chip, data, link

---

### 行业案例 / Industry Examples

- Apple（苹果）、Google（谷歌）、Huawei（华为）、Xiaomi（小米）
- Alibaba（阿里巴巴）、Tencent（腾讯）、ByteDance（字节跳动）

---

### 命名建议 / Naming Suggestions

- 避免过于古典、传统 / Avoid overly classical, traditional
- 使用科技相关词汇 / Use technology-related vocabulary
- 考虑英文发音和拼写 / Consider English pronunciation and spelling

---

## 金融行业 / Financial Industry

### 命名特点 / Naming Characteristics

- 稳重、专业、信任感 / Steady, professional, trustworthy
- 强调稳定性、安全性 / Emphasize stability, security
- 常用词汇：金、银、信、稳、安、通 / Common vocabulary: gold, silver, trust, steady, safe, connect

---

### 行业案例 / Industry Examples

- 中国银行、招商银行、平安保险、中信证券
- ICBC、CITIC、Ping An

---

### 命名建议 / Naming Suggestions

- 强调稳定性、安全性 / Emphasize stability, security
- 避免过于激进、冒险 / Avoid overly aggressive, adventurous
- 考虑监管要求 / Consider regulatory requirements

---

## 消费品行业 / Consumer Goods Industry

### 命名特点 / Naming Characteristics

- 亲和、活力、记忆度 / Approachable, energetic, memorable
- 易于传播、易于记忆 / Easy to communicate, easy to remember
- 常用词汇：乐、喜、美、佳、优、鲜 / Common vocabulary: joy, happiness, beauty, good, excellent, fresh

---

### 行业案例 / Industry Examples

- 可口可乐、宝洁、联合利华、海尔
- Coca-Cola、P&G、Unilever、Haier

---

### 命名建议 / Naming Suggestions

- 易于记忆、易于传播 / Easy to remember, easy to communicate
- 避免过于复杂、晦涩 / Avoid overly complex, obscure
- 考虑消费者心理 / Consider consumer psychology

---

## 奢侈品行业 / Luxury Industry

### 命名特点 / Naming Characteristics

- 优雅、独特、高端 / Elegant, unique, high-end
- 体现品质、历史、文化 / Reflect quality, history, culture
- 常用词汇：皇、帝、爵、雅、臻、奢 / Common vocabulary: emperor, king, duke, elegant, ultimate, luxury

---

### 行业案例 / Industry Examples

- Louis Vuitton、Hermès、Chanel、Gucci
- 宝马、奔驰、奥迪

---

### 命名建议 / Naming Suggestions

- 体现品质、历史、文化 / Reflect quality, history, culture
- 避免过于大众化 / Avoid overly mass-market
- 考虑国际品牌形象 / Consider international brand image

---

## 教育行业 / Education Industry

### 命名特点 / Naming Characteristics

- 启迪、成长、知识 / Enlightenment, growth, knowledge
- 体现教育理念、育人目标 / Reflect educational philosophy, nurturing goals
- 常用词汇：启、智、学、育、成、长 / Common vocabulary: enlighten, wisdom, learn, nurture, succeed, grow

---

### 行业案例 / Industry Examples

- 新东方、学而思、好未来、猿辅导
- New Oriental, Xueersi, TAL Education, Yuanfudao

---

### 命名建议 / Naming Suggestions

- 体现教育理念、育人目标 / Reflect educational philosophy, nurturing goals
- 避免过于功利、商业化 / Avoid overly utilitarian, commercial
- 考虑家长和学生心理 / Consider parent and student psychology

---

## 医疗健康行业 / Healthcare Industry

### 命名特点 / Naming Characteristics

- 专业、关怀、信任 / Professional, caring, trustworthy
- 体现健康、生命、关怀 / Reflect health, life, care
- 常用词汇：康、健、医、疗、护、生 / Common vocabulary: health, fitness, medicine, therapy, care, life

---

### 行业案例 / Industry Examples

- 康美药业、爱尔眼科、美年大健康
- Kangmei Pharmaceutical, Aier Eye Hospital, Meinian Onehealth

---

### 命名建议 / Naming Suggestions

- 体现健康、生命、关怀 / Reflect health, life, care
- 避免过于严肃、冷漠 / Avoid overly serious, cold
- 考虑监管要求和患者心理 / Consider regulatory requirements and patient psychology

---

## 参考资源 / References

- 《行业分类标准》/ Industry Classification Standards
- 《品牌命名案例集》/ Brand Naming Case Collection
