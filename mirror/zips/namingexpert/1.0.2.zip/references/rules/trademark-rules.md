# 商标规则 / Trademark Rules

## 目录 / Table of Contents

1. [商标基本概念 / Trademark Basic Concepts](#商标基本概念)
2. [商标分类 / Trademark Classification](#商标分类)
3. [商标显著性 / Trademark Distinctiveness](#商标显著性)
4. [商标注册流程 / Trademark Registration Process](#商标注册流程)
5. [商标侵权判定 / Trademark Infringement Determination](#商标侵权判定)

---

## 商标基本概念 / Trademark Basic Concepts

### 商标定义 / Trademark Definition

商标是指能够将商品或服务与他人的商品或服务区别开的标志，包括文字、图形、字母、数字、三维标志、颜色组合和声音等，以及上述要素的组合。

A trademark is a sign capable of distinguishing the goods or services of one enterprise from those of other enterprises, including words, graphics, letters, numbers, three-dimensional symbols, color combinations, and sounds, as well as combinations of the above elements.

---

### 商标功能 / Trademark Functions

1. **标识来源 / Identify Source**：标识商品或服务的来源 / Identify the source of goods or services
2. **质量保证 / Quality Assurance**：保证商品或服务的质量 / Guarantee the quality of goods or services
3. **广告宣传 / Advertising**：用于广告宣传 / Used for advertising
4. **品牌建设 / Brand Building**：建立品牌认知 / Build brand awareness

---

## 商标分类 / Trademark Classification

### 尼斯分类 / Nice Classification

商标注册采用尼斯分类，共 45 个类别。

Trademark registration uses the Nice Classification, with 45 categories.

---

### 核心类别 / Core Categories

#### 第 9 类：科学仪器、软件、电子产品 / Class 9: Scientific instruments, software, electronic products

- **包括 / Includes**：
  - 计算机、计算机软件 / Computers, computer software
  - 电子产品、电子设备 / Electronic products, electronic equipment
  - 科学仪器、测量仪器 / Scientific instruments, measuring instruments

- **示例 / Examples**：
  - 智能手机 / Smartphones
  - 计算机软件 / Computer software
  - 电子芯片 / Electronic chips

---

#### 第 35 类：广告、商业经营、工商管理 / Class 35: Advertising, business operation, business management

- **包括 / Includes**：
  - 广告服务 / Advertising services
  - 商业管理、商业经营 / Business management, business operation
  - 办公事务、办公服务 / Office affairs, office services

- **示例 / Examples**：
  - 广告代理 / Advertising agency
  - 商业管理咨询 / Business management consulting
  - 办公服务 / Office services

---

#### 第 41 类：教育、培训、娱乐 / Class 41: Education, training, entertainment

- **包括 / Includes**：
  - 教育服务 / Education services
  - 培训服务 / Training services
  - 娱乐服务 / Entertainment services

- **示例 / Examples**：
  - 在线教育 / Online education
  - 职业培训 / Vocational training
  - 文化娱乐 / Cultural entertainment

---

#### 第 42 类：科学技术服务、计算机服务 / Class 42: Scientific and technological services, computer services

- **包括 / Includes**：
  - 科学研究 / Scientific research
  - 技术服务 / Technical services
  - 计算机服务 / Computer services

- **示例 / Examples**：
  - 软件开发 / Software development
  - 技术咨询 / Technical consulting
  - 云计算服务 / Cloud computing services

---

### 分类原则 / Classification Principles

1. **核心类别 / Core Categories**：根据主营业务确定 / Determine based on main business
2. **辅助类别 / Auxiliary Categories**：根据未来发展确定 / Determine based on future development
3. **跨类别保护 / Cross-Category Protection**：重要商标建议跨类别注册 / Important trademarks are recommended to be registered across categories

---

## 商标显著性 / Trademark Distinctiveness

### 固有显著性 / Inherent Distinctiveness

#### 1. 臆造词 / Fanciful Terms

- **定义 / Definition**：完全创造的词汇 / Completely created vocabulary
- **特点 / Characteristics**：无字典含义，显著性最高 / No dictionary meaning, highest distinctiveness
- **示例 / Examples**：Kodak、Xerox
- **保护性 / Protectability**：最高 / Highest

---

#### 2. 任意词 / Arbitrary Terms

- **定义 / Definition**：现有词汇但与商品无关 / Existing vocabulary but unrelated to goods
- **特点 / Characteristics**：有字典含义，但与商品无关 / Has dictionary meaning, but unrelated to goods
- **示例 / Examples**：Apple（电脑）、Camel（香烟）
- **保护性 / Protectability**：高 / High

---

#### 3. 暗示词 / Suggestive Terms

- **定义 / Definition**：暗示商品特征的词汇 / Vocabulary suggesting product characteristics
- **特点 / Characteristics**：需要联想才能理解含义 / Requires association to understand meaning
- **示例 / Examples**：Microsoft（微型软件）
- **保护性 / Protectability**：中等 / Medium

---

### 获得显著性 / Acquired Distinctiveness

#### 1. 描述词 / Descriptive Terms

- **定义 / Definition**：描述商品特征的词汇 / Vocabulary describing product characteristics
- **特点 / Characteristics**：显著性低，需要通过使用获得显著性 / Low distinctiveness, needs to acquire distinctiveness through use
- **示例 / Examples**："快速"、"优质" / "Fast", "High Quality"
- **保护性 / Protectability**：低 / Low

---

#### 2. 获得显著性的途径 / Ways to Acquire Distinctiveness

- **长期使用 / Long-Term Use**：长期使用获得认知 / Gain recognition through long-term use
- **大量宣传 / Extensive Promotion**：大量宣传获得认知 / Gain recognition through extensive promotion
- **建立品牌认知 / Build Brand Awareness**：建立品牌认知获得显著性 / Acquire distinctiveness by building brand awareness

---

## 商标注册流程 / Trademark Registration Process

### 1. 商标查询 / Trademark Query

- **查询目的 / Query Purpose**：避免与现有商标冲突 / Avoid conflicts with existing trademarks
- **查询方式 / Query Methods**：
  - 中国商标网 / China Trademark Online
  - 国家知识产权局商标局 / CNIPA Trademark Office
  - 第三方商标查询平台 / Third-party trademark query platforms

- **查询内容 / Query Content**：
  - 相似商标 / Similar trademarks
  - 相同类别 / Same category
  - 相似商品或服务 / Similar goods or services

---

### 2. 商标申请 / Trademark Application

- **申请材料 / Application Materials**：
  - 商标图样 / Trademark design
  - 商标申请书 / Trademark application form
  - 申请人身份证明 / Applicant identity proof

- **申请流程 / Application Process**：
  1. 提交申请 / Submit application
  2. 形式审查 / Formal examination
  3. 实质审查 / Substantive examination
  4. 公告 / Publication
  5. 注册 / Registration

---

### 3. 商标审查 / Trademark Examination

#### 形式审查 / Formal Examination

- **审查内容 / Examination Content**：
  - 申请材料是否齐全 / Whether application materials are complete
  - 申请手续是否完备 / Whether application procedures are complete
  - 费用是否缴纳 / Whether fees are paid

- **审查结果 / Examination Result**：
  - 通过 / Pass
  - 补正 / Correction
  - 驳回 / Rejection

---

#### 实质审查 / Substantive Examination

- **审查内容 / Examination Content**：
  - 是否违反禁用条款 / Whether it violates prohibited clauses
  - 是否与在先商标冲突 / Whether it conflicts with prior trademarks
  - 是否具有显著性 / Whether it has distinctiveness

- **审查结果 / Examination Result**：
  - 通过 / Pass
  - 驳回 / Rejection
  - 部分驳回 / Partial rejection

---

### 4. 商标公告 / Trademark Publication

- **公告内容 / Publication Content**：
  - 商标名称 / Trademark name
  - 商标图样 / Trademark design
  - 申请人信息 / Applicant information
  - 商品或服务列表 / List of goods or services

- **公告期限 / Publication Period**：3 个月 / 3 months

- **异议期 / Opposition Period**：公告期内，任何人可以提出异议 / During the publication period, anyone can file an opposition

---

### 5. 商标注册 / Trademark Registration

- **注册条件 / Registration Conditions**：
  - 通过实质审查 / Passed substantive examination
  - 无异议或异议不成立 / No opposition or opposition not established
  - 缴纳注册费 / Pay registration fee

- **注册有效期 / Registration Validity Period**：10 年 / 10 years

- **续展 / Renewal**：到期前 6 个月内可以申请续展，每次续展有效期 10 年 / Can apply for renewal within 6 months before expiration, each renewal valid for 10 years

---

## 商标侵权判定 / Trademark Infringement Determination

### 侵权判定标准 / Infringement Determination Standards

1. **相同或近似 / Same or Similar**：
   - 商标相同或近似 / Trademark is same or similar
   - 商品或服务相同或类似 / Goods or services are same or similar

2. **混淆可能性 / Likelihood of Confusion**：
   - 容易导致相关公众混淆 / Easy to cause confusion among relevant public
   - 误认为商品或服务来源相同 / Mistakenly believe goods or services are from the same source

---

### 侵权类型 / Infringement Types

#### 1. 相同商品或服务使用相同商标 / Using Same Trademark on Same Goods or Services

- **判定标准 / Determination Standard**：
  - 商标相同 / Trademark is same
  - 商品或服务相同 / Goods or services are same

- **示例 / Examples**：
  - 在相同商品上使用相同的商标 / Using same trademark on same goods
  - 在相同服务上使用相同的商标 / Using same trademark on same services

---

#### 2. 相似商品或服务使用相同商标 / Using Same Trademark on Similar Goods or Services

- **判定标准 / Determination Standard**：
  - 商标相同 / Trademark is same
  - 商品或服务类似 / Goods or services are similar

- **示例 / Examples**：
  - 在类似商品上使用相同的商标 / Using same trademark on similar goods
  - 在类似服务上使用相同的商标 / Using same trademark on similar services

---

#### 3. 相同商品或服务使用相似商标 / Using Similar Trademark on Same Goods or Services

- **判定标准 / Determination Standard**：
  - 商标相似 / Trademark is similar
  - 商品或服务相同 / Goods or services are same

- **示例 / Examples**：
  - 在相同商品上使用相似的商标 / Using similar trademark on same goods
  - 在相同服务上使用相似的商标 / Using similar trademark on same services

---

#### 4. 相似商品或服务使用相似商标 / Using Similar Trademark on Similar Goods or Services

- **判定标准 / Determination Standard**：
  - 商标相似 / Trademark is similar
  - 商品或服务类似 / Goods or services are similar

- **示例 / Examples**：
  - 在类似商品上使用相似的商标 / Using similar trademark on similar goods
  - 在类似服务上使用相似的商标 / Using similar trademark on similar services

---

### 不侵权抗辩 / Non-Infringement Defenses

1. **合理使用 / Fair Use**：
   - 描述性使用 / Descriptive use
   - 指示性使用 / Indicative use

2. **先用权 / Prior Use Right**：
   - 在商标注册前已经使用 / Used before trademark registration
   - 在原使用范围内继续使用 / Continue to use within original scope

3. **商标权用尽 / Trademark Rights Exhaustion**：
   - 商品首次销售后，商标权用尽 / Trademark rights exhausted after first sale of goods

---

## 参考资源 / References

- 《中华人民共和国商标法》/ Trademark Law of the People's Republic of China
- 《中华人民共和国商标法实施条例》/ Regulations for the Implementation of the Trademark Law of the People's Republic of China
- 尼斯分类表 / Nice Classification Table
- 中国商标网 / China Trademark Online
- 国家知识产权局商标局 / CNIPA Trademark Office
