# 音韵学规则 / Phonetic Rules

## 目录 / Table of Contents

1. [平仄组合规律 / Tone Combination Patterns](#平仄组合规律)
2. [韵母开口度 / Vowel Openness](#韵母开口度)
3. [声母发音部位 / Articulation Position](#声母发音部位)
4. [音节结构分析 / Syllable Structure Analysis](#音节结构分析)

---

## 平仄组合规律 / Tone Combination Patterns

### 平仄定义 / Definition of Tones

在中文音韵学中，声调分为平声和仄声：

In Chinese phonology, tones are divided into level (Ping) and oblique (Ze):

- **平声 / Level (Ping)**：第一声（阴平）、第二声（阳平）
  - First tone (Yin Ping), Second tone (Yang Ping)
  - 特点：声调平缓、舒缓 / Characteristics: gentle, smooth

- **仄声 / Oblique (Ze)**：第三声（上声）、第四声（去声）
  - Third tone (Shang Sheng), Fourth tone (Qu Sheng)
  - 特点：声调起伏、有力 / Characteristics: undulating, powerful

### 常见平仄组合 / Common Tone Combinations

#### 1. 平平 / Ping-Ping

- **组合 / Combination**：第一声 + 第一声 / First tone + First tone
- **特点 / Characteristics**：平缓、柔和、舒缓 / Gentle, soft, smooth
- **示例 / Examples**：春天 (chūn tiān)、飞翔 (fēi xiáng)、高山 (gāo shān)
- **命名建议 / Naming Suggestions**：适合需要柔和、平缓感的名称 / Suitable for names needing gentle, smooth feeling

#### 2. 仄仄 / Ze-Ze

- **组合 / Combination**：第三声 + 第三声、第四声 + 第四声等 / Third tone + Third tone, Fourth tone + Fourth tone, etc.
- **特点 / Characteristics**：有力、现代、坚定 / Powerful, modern, firm
- **示例 / Examples**：智慧 (zhì huì)、创造 (chuàng zào)、突破 (tū pò)
- **命名建议 / Naming Suggestions**：适合需要有力、现代感的名称 / Suitable for names needing powerful, modern feeling

#### 3. 平仄 / Ping-Ze

- **组合 / Combination**：平声 + 仄声 / Level tone + Oblique tone
- **特点 / Characteristics**：平衡、和谐、自然 / Balanced, harmonious, natural
- **示例 / Examples**：山水 (shān shuǐ)、光明 (guāng míng)、飞翔 (fēi xiáng)
- **命名建议 / Naming Suggestions**：适合需要平衡、和谐感的名称 / Suitable for names needing balanced, harmonious feeling

#### 4. 仄平 / Ze-Ping

- **组合 / Combination**：仄声 + 平声 / Oblique tone + Level tone
- **特点 / Characteristics**：有起伏、有活力、现代 / Undulating, energetic, modern
- **示例 / Examples**：科技 (kē jì)、超越 (chāo yuè)、创新 (chuàng xīn)
- **命名建议 / Naming Suggestions**：适合需要活力、现代感的名称 / Suitable for names needing energetic, modern feeling

### 平仄组合命名建议 / Naming Suggestions Based on Tone Combinations

| 组合 / Combination | 特点 / Characteristics | 适合场景 / Suitable Scenes |
|-------------------|----------------------|--------------------------|
| 平平 / Ping-Ping | 平缓、柔和、舒缓 / Gentle, soft, smooth | 亲和、温暖的品牌 / Approachable, warm brands |
| 仄仄 / Ze-Ze | 有力、现代、坚定 / Powerful, modern, firm | 科技、创新的品牌 / Technology, innovative brands |
| 平仄 / Ping-Ze | 平衡、和谐、自然 / Balanced, harmonious, natural | 平衡、自然的品牌 / Balanced, natural brands |
| 仄平 / Ze-Ping | 有起伏、有活力、现代 / Undulating, energetic, modern | 活力、现代的品牌 / Energetic, modern brands |

---

## 韵母开口度 / Vowel Openness

### 韵母分类 / Vowel Classification

在中文音韵学中，韵母按开口度分为四类：

In Chinese phonology, vowels are classified into four types based on openness:

#### 1. 开口呼 / Open Mouth (Kāi Kǒu Hū)

- **定义 / Definition**：没有韵头或韵头是 i、u、ü 以外的韵母 / Vowels without medial or with medial other than i, u, ü
- **韵母 / Vowels**：a, o, e, ai, ei, ao, ou, an, en, ang, eng
- **特点 / Characteristics**：开口度大，声音响亮 / Large openness, loud sound
- **示例 / Examples**：
  - 大 (dà)、歌 (gē)、河 (hé)
  - 海 (hǎi)、飞 (fēi)、高 (gāo)
- **命名建议 / Naming Suggestions**：适合需要响亮、有力度的名称 / Suitable for names needing loud, powerful sound

#### 2. 齐齿呼 / Front Vowel (Qí Chǐ Hū)

- **定义 / Definition**：韵头或韵母是 i 的韵母 / Vowels with medial i or vowel i
- **韵母 / Vowels**：i, ia, ie, iao, iou, ian, in, iang, ing
- **特点 / Characteristics**：开口度较小，声音细腻 / Small openness, delicate sound
- **示例 / Examples**：
  - 里 (lǐ)、西 (xī)、低 (dī)
  - 家 (jiā)、街 (jiē)、骄 (jiāo)
- **命名建议 / Naming Suggestions**：适合需要细腻、精致的名称 / Suitable for names needing delicate, exquisite sound

#### 3. 合口呼 / Round Lips (Hé Kǒu Hū)

- **定义 / Definition**：韵头或韵母是 u 的韵母 / Vowels with medial u or vowel u
- **韵母 / Vowels**：u, ua, uo, uai, uei, uan, un, uang, ong
- **特点 / Characteristics**：嘴唇呈圆形，声音圆润 / Lips rounded, round sound
- **示例 / Examples**：
  - 古 (gǔ)、女 (nǚ)、图 (tú)
  - 花 (huā)、多 (duō)、宽 (kuān)
- **命名建议 / Naming Suggestions**：适合需要圆润、温和的名称 / Suitable for names needing round, gentle sound

#### 4. 撮口呼 / Pursed Lips (Cuō Kǒu Hū)

- **定义 / Definition**：韵头或韵母是 ü 的韵母 / Vowels with medial ü or vowel ü
- **韵母 / Vowels**：ü, üe, üan, ün
- **特点 / Characteristics**：嘴唇撮起，声音尖锐 / Lips pursed, sharp sound
- **示例 / Examples**：
  - 女 (nǚ)、雨 (yǔ)、鱼 (yú)
  - 月 (yuè)、圈 (quān)、军 (jūn)
- **命名建议 / Naming Suggestions**：适合需要精致、独特的名称 / Suitable for names needing exquisite, unique sound

### 韵母开口度命名建议 / Naming Suggestions Based on Vowel Openness

| 类型 / Type | 开口度 / Openness | 特点 / Characteristics | 适合场景 / Suitable Scenes |
|------------|------------------|----------------------|--------------------------|
| 开口呼 / Open Mouth | 大 / Large | 响亮、有力 / Loud, powerful | 科技、体育品牌 / Technology, sports brands |
| 齐齿呼 / Front Vowel | 小 / Small | 细腻、精致 / Delicate, exquisite | 奢侈品、时尚品牌 / Luxury, fashion brands |
| 合口呼 / Round Lips | 中 / Medium | 圆润、温和 / Round, gentle | 亲和、温暖的品牌 / Approachable, warm brands |
| 撮口呼 / Pursed Lips | 小 / Small | 尖锐、独特 / Sharp, unique | 独特、创新的品牌 / Unique, innovative brands |

---

## 声母发音部位 / Articulation Position

### 声母分类 / Initial Classification

在中文音韵学中，声母按发音部位分为七类：

In Chinese phonology, initials are classified into seven types based on articulation position:

#### 1. 双唇音 / Bilabial (Shuāng Chún Yīn)

- **发音方法 / Articulation Method**：双唇闭合，气流冲破双唇发出
- **声母 / Initials**：b, p, m
- **特点 / Characteristics**：声音饱满、有力 / Full, powerful sound
- **示例 / Examples**：
  - 波 (bō)、坡 (pō)、摸 (mō)
  - 白 (bái)、皮 (pí)、美 (měi)
- **命名建议 / Naming Suggestions**：适合需要饱满、有力度的名称 / Suitable for names needing full, powerful sound

#### 2. 唇齿音 / Labiodental (Chún Chǐ Yīn)

- **发音方法 / Articulation Method**：上齿接触下唇，气流从齿唇间发出
- **声母 / Initials**：f
- **特点 / Characteristics**：声音轻柔、清晰 / Soft, clear sound
- **示例 / Examples**：
  - 飞 (fēi)、风 (fēng)、发 (fā)
  - 佛 (fó)、福 (fú)、方 (fāng)
- **命名建议 / Naming Suggestions**：适合需要轻柔、清晰的名称 / Suitable for names needing soft, clear sound

#### 3. 舌尖前音 / Apical (Shé Jiān Qián Yīn)

- **发音方法 / Articulation Method**：舌尖接触上齿背，气流从舌尖和齿背间发出
- **声母 / Initials**：z, c, s
- **特点 / Characteristics**：声音尖锐、清晰 / Sharp, clear sound
- **示例 / Examples**：
  - 资 (zī)、词 (cí)、思 (sī)
  - 紫 (zǐ)、刺 (cì)、四 (sì)
- **命名建议 / Naming Suggestions**：适合需要尖锐、现代感的名称 / Suitable for names needing sharp, modern feeling

#### 4. 舌尖后音 / Retroflex (Shé Jiān Hòu Yīn)

- **发音方法 / Articulation Method**：舌尖上翘，接触硬腭前部，气流从舌尖和硬腭间发出
- **声母 / Initials**：zh, ch, sh, r
- **特点 / Characteristics**：声音有力、浑厚 / Powerful, thick sound
- **示例 / Examples**：
  - 知 (zhī)、吃 (chī)、师 (shī)、日 (rì)
  - 智 (zhì)、赤 (chì)、时 (shí)、荣 (róng)
- **命名建议 / Naming Suggestions**：适合需要有力、浑厚的名称 / Suitable for names needing powerful, thick sound

#### 5. 舌面音 / Palatal (Shé Miàn Yīn)

- **发音方法 / Articulation Method**：舌面前部接触硬腭前部，气流从舌面和硬腭间发出
- **声母 / Initials**：j, q, x
- **特点 / Characteristics**：声音清脆、明亮 / Crisp, bright sound
- **示例 / Examples**：
  - 机 (jī)、奇 (qī)、西 (xī)
  - 景 (jǐng)、巧 (qiǎo)、星 (xīng)
- **命名建议 / Naming Suggestions**：适合需要清脆、明亮的名称 / Suitable for names needing crisp, bright sound

#### 6. 舌根音 / Velar (Shé Gēn Yīn)

- **发音方法 / Articulation Method**：舌根接触软腭，气流从舌根和软腭间发出
- **声母 / Initials**：g, k, h
- **特点 / Characteristics**：声音深沉、厚重 / Deep, heavy sound
- **示例 / Examples**：
  - 哥 (gē)、科 (kē)、喝 (hē)
  - 高 (gāo)、空 (kōng)、红 (hóng)
- **命名建议 / Naming Suggestions**：适合需要深沉、厚重的名称 / Suitable for names needing deep, heavy sound

#### 7. 零声母 / Zero Initial

- **发音方法 / Articulation Method**：没有声母，直接以韵母开始
- **特点 / Characteristics**：声音柔和、自然 / Soft, natural sound
- **示例 / Examples**：
  - 爱 (ài)、欧 (ōu)、安 (ān)
  - 雅 (yǎ)、优 (yōu)、远 (yuǎn)
- **命名建议 / Naming Suggestions**：适合需要柔和、自然的名称 / Suitable for names needing soft, natural sound

### 声母发音部位命名建议 / Naming Suggestions Based on Articulation Position

| 类型 / Type | 发音部位 / Articulation Position | 特点 / Characteristics | 适合场景 / Suitable Scenes |
|------------|--------------------------------|----------------------|--------------------------|
| 双唇音 / Bilabial | 双唇 / Both lips | 饱满、有力 / Full, powerful | 科技、体育品牌 / Technology, sports brands |
| 唇齿音 / Labiodental | 上齿下唇 / Upper teeth lower lip | 轻柔、清晰 / Soft, clear | 时尚、文化品牌 / Fashion, cultural brands |
| 舌尖前音 / Apical | 舌尖上齿背 / Tongue tip upper teeth | 尖锐、清晰 / Sharp, clear | 科技、创新品牌 / Technology, innovative brands |
| 舌尖后音 / Retroflex | 舌尖上翘 / Tongue tip curled up | 有力、浑厚 / Powerful, thick | 传统、稳重品牌 / Traditional, steady brands |
| 舌面音 / Palatal | 舌面前部 / Front of tongue | 清脆、明亮 / Crisp, bright | 年轻、时尚品牌 / Young, fashionable brands |
| 舌根音 / Velar | 舌根软腭 | 深沉、厚重 / Deep, heavy | 高端、稳重品牌 / High-end, steady brands |
| 零声母 / Zero Initial | 无声母 / No initial | 柔和、自然 / Soft, natural | 亲和、温暖的品牌 / Approachable, warm brands |

---

## 音节结构分析 / Syllable Structure Analysis

### 中文音节结构 / Chinese Syllable Structure

中文音节由声母、韵母和声调组成：

Chinese syllables are composed of initial, final, and tone:

```
音节 = 声母 + 韵母 + 声调
Syllable = Initial + Final + Tone
```

#### 示例 / Examples

| 音节 / Syllable | 声母 / Initial | 韵母 / Final | 声调 / Tone | 拼音 / Pinyin |
|---------------|--------------|-------------|-----------|-------------|
| 智 / zhì | zh | i | ˋ（去声） / 4th tone | zhì |
| 跃 / yuè | 零声母 / Zero initial | üe | ˋ（去声） / 4th tone | yuè |
| 云 / yún | 零声母 / Zero initial | un | ˊ（阳平） / 2nd tone | yún |
| 启 / qǐ | q | i | ˇ（上声） / 3rd tone | qǐ |

### 英文音节结构 / English Syllable Structure

英文音节由首音（onset）和韵核（nucleus）组成，韵核后可以有尾音（coda）：

English syllables are composed of onset, nucleus, and optional coda:

```
音节 = 首音 + 韵核 + 尾音（可选）
Syllable = Onset + Nucleus + Coda (optional)
```

#### 示例 / Examples

| 单词 / Word | 首音 / Onset | 韵核 / Nucleus | 尾音 / Coda | 音节 / Syllable |
|------------|-------------|--------------|-----------|---------------|
| Smart | sm | a | rt | Smart |
| Leap | l | ea | p | Leap |
| Cloud | cl | ou | d | Cloud |
| Init | ɪ (i) | n | it | Init |

### 音节结构命名建议 / Naming Suggestions Based on Syllable Structure

#### 中文音节

1. **双音节名称 / Two-Syllable Names**：
   - 特点：节奏明快、易于记忆 / Characteristics: brisk rhythm, easy to remember
   - 示例：华为、腾讯、百度 / Examples: Huawei, Tencent, Baidu
   - 建议场景：企业名称、品牌名称 / Suggested scenes: enterprise names, brand names

2. **三音节名称 / Three-Syllable Names**：
   - 特点：节奏舒缓、有层次感 / Characteristics: soothing rhythm, layered feeling
   - 示例：阿里巴巴、京东 / Examples: Alibaba, JD
   - 建议场景：企业名称、产品名称 / Suggested scenes: enterprise names, product names

3. **四音节名称 / Four-Syllable Names**：
   - 特点：节奏丰富、有气势 / Characteristics: rich rhythm, imposing
   - 示例：中国平安、招商银行 / Examples: China Ping An, China Merchants Bank
   - 建议场景：大型企业名称 / Suggested scenes: large enterprise names

#### 英文音节

1. **单音节名称 / One-Syllable Names**：
   - 特点：简洁有力、易于记忆 / Characteristics: concise and powerful, easy to remember
   - 示例：Nike, Dell, Ford / Examples: Nike, Dell, Ford
   - 建议场景：品牌名称、产品名称 / Suggested scenes: brand names, product names

2. **双音节名称 / Two-Syllable Names**：
   - 特点：节奏平衡、朗朗上口 / Characteristics: balanced rhythm, catchy
   - 示例：Apple, Google, Amazon / Examples: Apple, Google, Amazon
   - 建议场景：品牌名称、产品名称 / Suggested scenes: brand names, product names

3. **三音节名称 / Three-Syllable Names**：
   - 特点：节奏丰富、有特色 / Characteristics: rich rhythm, distinctive
   - 示例：Microsoft, Coca-Cola / Examples: Microsoft, Coca-Cola
   - 建议场景：品牌名称、企业名称 / Suggested scenes: brand names, enterprise names

---

## 参考资源 / References

- 《现代汉语音韵学》/ Modern Chinese Phonology
- 《汉语音韵学》/ Chinese Phonology
- 国际音标（IPA）/ International Phonetic Alphabet (IPA)
