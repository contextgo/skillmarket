# 文字设计提示词生成指南 / Text Design Prompt Generation Guide

## 目录 / Table of Contents

1. [功能概述 / Function Overview](#功能概述--function-overview)
2. [创意风格集合 / Creative Style Collection](#创意风格集合--creative-style-collection)
3. [版式构图风格集合 / Layout Composition Style Collection](#版式构图风格集合--layout-composition-style-collection)
4. [智能匹配规则 / Intelligent Matching Rules](#智能匹配规则--intelligent-matching-rules)
5. [生成工作流程 / Generation Workflow](#生成工作流程--generation-workflow)
6. [示例输出 / Example Output](#示例输出--example-output)

---

## 功能概述 / Function Overview

本指南用于为命名方案生成AI文字设计提示词，帮助用户将命名转化为视觉设计。提示词融合了文字风格设计与版式构图的专业知识，可直接用于AI图像生成工具，创建高质量的品牌视觉设计作品。

This guide is used to generate AI text design prompts for naming proposals, helping users transform names into visual designs. The prompts integrate professional knowledge of text style design and layout composition, and can be directly applied to AI image generation tools to create high-quality brand visual design works.

**核心功能 / Core Functions：**
- 分析命名的语义特征、情感基调、行业属性 / Analyze naming's semantic features, emotional tone, and industry attributes
- 智能匹配创意风格和版式构图 / Intelligently match creative styles and layout compositions
- 生成结构化的AI绘图提示词 / Generate structured AI image generation prompts
- 提供多种风格组合选项 / Provide multiple style combination options

---

## 创意风格集合 / Creative Style Collection

### 1. 光韵夜影 / Neon Flow
轮廓式霓虹勾勒，线条飘逸纤细，弧度自然，呈现透明质感与内部发光效果 / Contour-style neon outlining, flowing and slender lines, natural curves, presenting transparent texture and internal glowing effect

### 2. 工业质朴 / Industrial Rust
金属粗砺纹理，铁锈斑驳装饰，浮雕立体结构，机械工艺感，点缀铆钉细节 / Metal rough texture, mottled rust decoration, embossed three-dimensional structure, mechanical craftsmanship feel, dotted with rivet details

### 3. 童趣涂绘 / Playful Sketch
线条随性不拘，手绘自然质感，笔触欢快灵动，边缘圆润，多彩渐变装饰 / Casual and unrestrained lines, hand-drawn natural texture, lively and agile strokes, rounded edges, colorful gradient decoration

### 4. 甜心风潮 / Sweet Trend
梦幻少女气息，圆弧柔和字形，融入泡泡糖果元素，字体可爱圆润，点缀星星心形 / Dreamy girly atmosphere, soft curved font shapes, incorporating bubble candy elements, cute and rounded fonts, dotted with stars and hearts

### 5. 动漫爆炸 / Anime Explosion
漫画式震撼效果，线条张力延伸，笔画放射状爆发，营造强烈视觉冲击 / Manga-style shocking effect, line tension extending, stroke radial explosion, creating strong visual impact

### 6. 科技方块 / Tech Block
结构对比鲜明、几何分割重组，排列规整，未来科技感强烈 / Sharp structural contrast, geometric segmentation and reorganization, neat arrangement, strong futuristic technology feel

### 7. 清逸笔迹 / Graceful Script
手写风格自然舒展，线条均衡流畅，微妙拖尾效果，构造带几何美感，起收笔干净利落 / Handwriting style naturally spreading, balanced and smooth lines, subtle trailing effect, geometric beauty in structure, clean start and end strokes

### 8. 文艺钢笔 / Artistic Pen
优雅连笔设计，细线交错变化，双行排布结构，字体飘逸富有情感 / Elegant connected stroke design, fine line interlacing changes, double-line layout structure,飘逸字体 full of emotion

### 9. 金属科幻 / Metal Sci-Fi
机械边缘结合流线设计，霓虹点缀装饰，转角锐利分明，金属质感突出，融入编码芯片图案 / Mechanical edges combined with streamlined design, neon dotted decoration, sharp and distinct corners, prominent metal texture, incorporating coding chip patterns

### 10. 虚拟空间 / Virtual Space
深色背景衬托，字体结构数字解构风格，切割感线条，创造未来科技视觉体验 / Dark background衬托, font structure digital deconstruction style, cutting-feel lines, creating futuristic technology visual experience

### 11. 复刻年代 / Retro Era
字体厚重带颗粒感，老式印刷机效果，墨色不均匀，边缘微损，浓厚怀旧气息 / Thick font with grainy texture, old printing press effect, uneven ink color, slightly damaged edges, strong nostalgic atmosphere

### 12. 狂放书艺 / Bold Calligraphy
草书奔放风格，飞白技法应用，节奏富有变化，笔触刚劲有力 / Cursive bold style, feibai technique application, rich rhythmic changes, powerful strokes

### 13. 西方古典 / Western Classic
哥特风格变体，垂直比例修长，字形笔直尖锐，装饰细节丰富，透露神秘庄重氛围 / Gothic style variant, slender vertical proportion, straight and sharp font shapes, rich decorative details, revealing mysterious and solemn atmosphere

### 14. 动感秀逸 / Dynamic Elegance
笔触由粗到细，结构紧密流畅，飞白技法明显，强对比突显字体动态美感 / Strokes from thick to thin, tight and smooth structure, obvious feibai technique, strong contrast highlighting font dynamic beauty

### 15. 解构粗笔 / Deconstructed Brush
夸张多变笔触，自由连笔技法，结构错位变形，展现活力张扬跳脱视觉效果 / Exaggerated and varied strokes, free connection technique, structure dislocation and deformation, showing vibrant and bold visual effect

### 16. 简约留白 / Minimalist White
极致纤细无衬线设计，留白空间充足，字距呼吸感十足，现代日式构成理念 / Extremely slender sans-serif design, sufficient white space, breathing sense in character spacing, modern Japanese composition concept

### 17. 行草题韵 / Running Calligraphy
毛笔行书韵味，结构丰满均衡，起笔有力果断，传统标题设计风范 / Brush running script charm, full and balanced structure, powerful and decisive start strokes, traditional title design style

### 18. 冰晶破裂 / Ice Crystal Crack
字体边缘呈冰晶裂纹效果，如同冻结破碎的玻璃，笔触锋利冷峻 / Font edges show ice crystal crack effect, like frozen and broken glass, sharp and cold strokes

### 19. 科幻光切 / Sci-Fi Light Cut
字体由光切割面构成，高光边缘闪烁炫彩，融合机械感与未来科技感 / Font composed of light-cut surfaces, high-light edges flickering with brilliant colors, fusing mechanical feel and futuristic technology feel

### 20. 街区涂鸦 / Street Graffiti
多彩涂鸦艺术，粗线厚重描边，结构跃动有层次，手写印刷风格混合 / Colorful graffiti art, thick and heavy strokes, dynamic and layered structure, mixed hand-drawn and printed style

### 21. 自然木刻 / Natural Woodcut
字形边缘自然毛边，木质雕刻感强烈，整体氛围温暖质朴 / Font edges with natural fraying, strong wood carving feel, overall atmosphere warm and rustic

### 22. 电竞动力 / E-Sports Power
黑红强对比色调，笔画尖锐犀利，高亮边框装饰，能量条元素点缀，营造竞技紧张感 / Black-red strong contrast color scheme, sharp and sharp strokes, high-light frame decoration, energy bar elements dotted, creating competitive tension

---

## 版式构图风格集合 / Layout Composition Style Collection

### 1. 居中对称 / Center Symmetry
经典平衡构图，庄重稳定，适用于正式、经典场合，例如海报标题、Logo设计 / Classic balanced composition, solemn and stable, suitable for formal and classic occasions, such as poster titles, Logo design

### 2. 黄金分割 / Golden Ratio
符合视觉美学，比例协调，吸引目光，可用于强调主体，营造舒适的视觉节奏 / Conforms to visual aesthetics, coordinated proportion, attracts attention, can be used to emphasize the subject, creating comfortable visual rhythm

### 3. 三分法 / Rule of Thirds
简洁实用，平衡画面元素，突出重点，适合多元素信息排布，例如Banner设计、杂志封面 / Simple and practical, balances screen elements, highlights key points, suitable for multi-element information layout, such as Banner design, magazine covers

### 4. 对角线 / Diagonal Line
活泼动感，打破平衡，引导视线，增加画面张力，适用于需要动感和视觉冲击力的设计 / Lively and dynamic, breaks balance, guides vision, increases screen tension, suitable for designs requiring dynamic and visual impact

### 5. 重复与节奏 / Repetition and Rhythm
统一视觉风格，强化品牌感，产生韵律美，适用于系列海报、品牌宣传等 / Unified visual style, strengthens brand sense, produces rhythmic beauty, suitable for series posters, brand promotion, etc.

### 6. 留白艺术 / White Space Art
突出主体，营造呼吸感，提升画面高级感和意境，适用于需要强调文字内容或营造极简风格的设计 / Highlights subject, creates breathing sense, enhances screen high-level feel and artistic conception, suitable for designs that need to emphasize text content or create minimalist style

### 7. 网格系统 / Grid System
逻辑清晰，规范信息层级，提升专业感和秩序感，适用于信息量大、结构复杂的排版，例如书籍、杂志内页 / Clear logic, standardized information hierarchy, enhances professional and orderly sense, suitable for layouts with large information and complex structure, such as books and magazine pages

### 8. 对比与强调 / Contrast and Emphasis
突出重点信息，制造视觉焦点，提升信息层级，适用于海报、广告等需要快速抓住用户眼球的设计 / Highlights key information, creates visual focus, enhances information hierarchy, suitable for designs such as posters and advertisements that need to quickly capture user attention

### 9. 非对称平衡 / Asymmetric Balance
灵动不死板，活泼有设计感，在非对称中寻求平衡，更具现代感和创意性 / Flexible and not rigid, lively with design sense, seeks balance in asymmetry, more modern and creative

### 10. 视觉引导 / Visual Guidance
通过线条、色块、元素方向等引导视线，控制阅读顺序，适用于信息层级复杂，需要引导用户逐步阅读的设计 / Guides vision through lines, color blocks, element directions, etc., controls reading order, suitable for designs with complex information hierarchy that need to guide users to read step by step

---

## 智能匹配规则 / Intelligent Matching Rules

### 文字风格匹配规则 / Text Style Matching Rules

#### 命名类型分析 / Naming Type Analysis

| 命名类型 / Naming Type | 推荐风格 / Recommended Styles |
|----------------------|----------------------------|
| **品牌名 / Brand Name** | 科技方块、金属科幻、工业质朴、简约留白、西方古典 |
| **产品名 / Product Name** | 童趣涂绘、甜心风潮、动漫爆炸、光韵夜影、清逸笔迹 |
| **人名 / Person Name** | 文艺钢笔、清逸笔迹、简约留白、行草题韵、自然木刻 |
| **公司名 / Company Name** | 工业质朴、科技方块、金属科幻、复刻年代、简约留白 |
| **IP角色名 / IP Character Name** | 动漫爆炸、童趣涂绘、甜心风潮、街区涂鸦、解构粗笔 |
| **项目代号 / Project Codename** | 电竞动力、科幻光切、虚拟空间、金属科幻、冰晶破裂 |

#### 行业属性分析 / Industry Attribute Analysis

| 行业 / Industry | 推荐风格 / Recommended Styles |
|----------------|----------------------------|
| **科技 / Technology** | 科技方块、金属科幻、虚拟空间、科幻光切、电竞动力 |
| **金融 / Finance** | 西方古典、复刻年代、工业质朴、简约留白、行草题韵 |
| **消费品 / Consumer Goods** | 甜心风潮、童趣涂绘、光韵夜影、清逸笔迹、街区涂鸦 |
| **奢侈品 / Luxury** | 西方古典、简约留白、金属科幻、行草题韵、狂放书艺 |
| **教育 / Education** | 文艺钢笔、行草题韵、简约留白、自然木刻、清逸笔迹 |
| **医疗健康 / Healthcare** | 清逸笔迹、简约留白、自然木刻、文艺钢笔、工业质朴 |
| **娱乐 / Entertainment** | 动漫爆炸、甜心风潮、光韵夜影、街区涂鸦、电竞动力 |
| **文化 / Culture** | 行草题韵、狂放书艺、西方古典、复刻年代、自然木刻 |

#### 情感基调分析 / Emotional Tone Analysis

| 情感基调 / Emotional Tone | 推荐风格 / Recommended Styles |
|-------------------------|----------------------------|
| **庄重 / Solemn** | 西方古典、复刻年代、工业质朴、行草题韵、简约留白 |
| **活泼 / Lively** | 童趣涂绘、甜心风潮、动漫爆炸、街区涂鸦、解构粗笔 |
| **科技感 / Technological** | 科技方块、金属科幻、虚拟空间、科幻光切、电竞动力 |
| **文艺 / Artistic** | 文艺钢笔、清逸笔迹、行草题韵、简约留白、自然木刻 |
| **温馨 / Warm** | 甜心风潮、清逸笔迹、自然木刻、光韵夜影、文艺钢笔 |
| **激昂 / Passionate** | 动漫爆炸、电竞动力、狂放书艺、金属科幻、对角线 |
| **神秘 / Mysterious** | 西方古典、光韵夜影、虚拟空间、冰晶破裂、科幻光切 |
| **自然 / Natural** | 自然木刻、清逸笔迹、简约留白、文艺钢笔、狂放书艺 |

### 版式构图匹配规则 / Layout Composition Matching Rules

#### 命名类型与版式匹配 / Naming Type & Layout Matching

| 命名类型 / Naming Type | 推荐版式 / Recommended Layout |
|----------------------|---------------------------|
| **标题/Logo / Title/Logo** | 居中对称、黄金分割、简约留白、对比与强调 |
| **广告语/宣传语 / Slogan** | 对比与强调、对角线、三分法、视觉引导 |
| **长段文案 / Long Copy** | 网格系统、视觉引导、留白艺术、三分法 |
| **品牌名称 / Brand Name** | 居中对称、黄金分割、简约留白、对比与强调 |
| **产品名称 / Product Name** | 非对称平衡、对角线、对比与强调、留白艺术 |

#### 情感基调与版式匹配 / Emotional Tone & Layout Matching

| 情感基调 / Emotional Tone | 推荐版式 / Recommended Layout |
|-------------------------|---------------------------|
| **庄重 / Solemn** | 居中对称、网格系统、三分法、黄金分割 |
| **活泼 / Lively** | 非对称平衡、对角线、重复与节奏、视觉引导 |
| **科技感 / Technological** | 非对称平衡、网格系统、对角线、视觉引导 |
| **文艺 / Artistic** | 留白艺术、黄金分割、居中对称、三分法 |
| **简约 / Minimalist** | 简约留白、黄金分割、网格系统、三分法 |

---

## 生成工作流程 / Generation Workflow

### 步骤1：命名分析 / Step 1: Naming Analysis

- **命名类型 / Naming Type**：品牌名/产品名/人名/IP角色名等
- **行业属性 / Industry Attributes**：科技/金融/消费品/奢侈品/教育/医疗健康等
- **情感基调 / Emotional Tone**：庄重/活泼/科技感/文艺/温馨/激昂等
- **字数特征 / Character Count**：简短有力（1-4字）/ 适中（5-8字）/ 较长（9字以上）

### 步骤2：智能匹配 / Step 2: Intelligent Matching

基于智能匹配规则，推荐2-3种风格组合：

- **风格组合1 / Style Combination 1**：[创意风格] + [版式构图] + [推荐理由]
- **风格组合2 / Style Combination 2**：[创意风格] + [版式构图] + [推荐理由]
- **风格组合3 / Style Combination 3**：[创意风格] + [版式构图] + [推荐理由]（可选）

### 步骤3：生成提示词 / Step 3: Generate Prompts

按照标准格式生成提示词：

```
"{命名中文}"/"{英文}", [主要文字风格特征描述], [版式构图风格描述], [背景设置], [文字排版特点], [视觉效果描述], [情感氛围], [高级感/艺术感描述], [品质细节描述]
```

### 步骤4：质量检查 / Step 4: Quality Check

- 提示词是否结构完整 / Is the prompt structure complete?
- 风格描述是否准确到位 / Is the style description accurate and in place?
- 版式描述是否具体可执行 / Is the layout description specific and executable?
- 是否符合命名特征和情感基调 / Does it match the naming characteristics and emotional tone?

---

## 示例输出 / Example Output

### 示例1：科技品牌命名 / Example 1: Technology Brand Naming

**命名 / Naming**：灵犀 / LINGXI

**风格推荐 / Style Recommendation**：
- 推荐风格：科技方块 + 居中对称
- 推荐理由：科技品牌需要体现未来感和专业度，科技方块风格符合行业属性，居中对称强化品牌稳定感

**文字设计提示词 / Text Design Prompt**：
```
📝 文字设计提示词（推荐风格：科技方块 + 居中对称）
"灵犀"/"LINGXI"，科技方块风格字体设计，几何切割重组，排列规整，未来科技感强烈；版式构图采用居中对称式，文字水平居中，上下留白，强化Logo的稳定感和专业感；背景为深色科技纹理背景，点缀光效元素；视觉效果简洁有力，情感氛围专业创新，高级感，细节精致，高清。
```

---

### 示例2：宠物命名 / Example 2: Pet Naming

**命名 / Naming**：团团 / TUANTUAN

**风格推荐 / Style Recommendation**：
- 推荐风格：童趣涂绘 + 非对称平衡
- 推荐理由：宠物名称需要亲切可爱，童趣涂绘风格温暖活泼，非对称平衡增加趣味性

**文字设计提示词 / Text Design Prompt**：
```
📝 文字设计提示词（推荐风格：童趣涂绘 + 非对称平衡）
"团团"/"TUANTUAN"，童趣涂绘风格字体设计，线条随性不拘，手绘自然质感，笔触欢快灵动，边缘圆润，多彩渐变装饰；版式构图采用非对称平衡式，文字略微向右倾斜，增加活泼动感；背景为柔和的渐变色背景，点缀可爱装饰元素；视觉效果温暖亲切，情感氛围快乐温馨，艺术感，细节柔和，高清。
```

---

### 示例3：教育机构命名 / Example 3: Education Institution Naming

**命名 / Naming**：博雅书院 / BOYA ACADEMY

**风格推荐 / Style Recommendation**：
- 推荐风格：文艺钢笔 + 留白艺术
- 推荐理由：教育机构需要体现文化底蕴和专业性，文艺钢笔风格优雅知性，留白艺术营造高级感

**文字设计提示词 / Text Design Prompt**：
```
📝 文字设计提示词（推荐风格：文艺钢笔 + 留白艺术）
"博雅书院"/"BOYA ACADEMY"，文艺钢笔风格字体设计，优雅连笔设计，细线交错变化，双行排布结构，字体飘逸富有情感；版式构图采用留白艺术，文字四周充足留白，营造呼吸感和高级感；背景为米白色纹理背景，点缀传统元素装饰；视觉效果优雅知性，情感氛围学术专业，高级感，细节精致，高清。
```

---

### 示例4：电竞战队命名 / Example 4: E-Sports Team Naming

**命名 / Naming**：无畏 / FEARLESS

**风格推荐 / Style Recommendation**：
- 推荐风格：电竞动力 + 居中对称
- 推荐理由：电竞战队需要体现竞技精神和力量感，电竞动力风格充满能量，居中对称强化稳定性

**文字设计提示词 / Text Design Prompt**：
```
📝 文字设计提示词（推荐风格：电竞动力 + 居中对称）
"无畏"/"FEARLESS"，电竞动力风格字体设计，黑红强对比色调，笔画尖锐犀利，高亮边框装饰，能量条元素点缀；版式构图采用居中对称式，文字水平居中，强化Logo的稳定感和力量感；背景为深色科技纹理背景，营造竞技氛围；视觉效果充满能量感和科技感，情感氛围激昂，高级感，细节精致，高清。
```

---

### 示例5：咖啡品牌命名 / Example 5: Coffee Brand Naming

**命名 / Naming**：慢时光 / SLOW TIME

**风格推荐 / Style Recommendation**：
- 推荐风格：清逸笔迹 + 留白艺术
- 推荐理由：咖啡品牌需要体现轻松惬意的氛围，清逸笔迹风格自然舒适，留白艺术营造高级感

**文字设计提示词 / Text Design Prompt**：
```
📝 文字设计提示词（推荐风格：清逸笔迹 + 留白艺术）
"慢时光"/"SLOW TIME"，清逸笔迹风格字体设计，手写风格自然舒展，线条均衡流畅，微妙拖尾效果，构造带几何美感；版式构图采用留白艺术，文字四周充足留白，营造呼吸感和高级感；背景为温暖米白色背景，点缀咖啡豆元素装饰；视觉效果自然舒适，情感氛围轻松惬意，高级感，细节精致，高清。
```

---

## 使用建议 / Usage Suggestions

1. **多风格尝试 / Try Multiple Styles**：为同一命名提供2-3种不同风格的提示词，供用户选择
2. **场景适配 / Scene Adaptation**：根据具体使用场景（Logo、海报、Banner等）调整版式构图
3. **用户反馈 / User Feedback**：根据用户对视觉效果的反馈，调整风格和版式选择
4. **持续优化 / Continuous Optimization**：积累使用数据，不断优化智能匹配规则

---

## 注意事项 / Important Notes

- 所有提示词遵循标准格式，确保AI能够准确理解 / All prompts follow standard format to ensure AI can understand accurately
- 风格描述要具体可执行，避免模糊词汇 / Style descriptions should be specific and executable, avoiding vague vocabulary
- 版式描述要包含构图原则和视觉引导信息 / Layout descriptions should include composition principles and visual guidance information
- 背景设置要与风格和情感基调相协调 / Background settings should coordinate with style and emotional tone
- 细节描述要强调品质感和专业度 / Detail descriptions should emphasize quality and professionalism
