---
name: "AI月结智能检查"
description: "企业财务月末结账智能核查系统，支持多账套管理、自定义检查规则、自动数据导入和结构化报告输出。适用于财务核算人员、总账会计、财务主管等岗位在月结关账环节进行账务合规性、数据平衡性、科目异常性智能核查。"
---

# AI月结智能检查

企业财务月末结账智能核查系统，全自动完成多账套账务合规性、数据平衡性、科目异常性智能核查，替代人工逐条核对，提升月结效率与账务核查准确率。

## 触发场景

当用户有以下需求时触发本Skill：
- "帮我做月结检查"
- "导入财务数据"
- "创建检查规则"
- "查看检查结果"
- "财务报表核对"
- "账套管理"
- "月结智能核查"

## 核心能力

### 1. 数据接入
支持多格式财务数据导入：
- Excel (.xlsx, .xls)：科目余额表、明细账、财务报表
- CSV (.csv)：标准化数据文件
- PDF：扫描件PDF（需OCR支持）
- 图片：发票、凭证图片（需OCR支持）

**智能字段映射**：自动识别科目编码、科目名称、期初余额、本期发生额、期末余额等字段。

### 2. 规则引擎
**预置检查规则**：
| 规则类型 | 说明 |
|---------|------|
| bank_reconciliation | 银企对账：银行科目余额核对 |
| asset_negative | 资产风控：资产类科目不得为负 |
| accounting_equation | 会计恒等式：资产=负债+权益 |
| expense_fluctuation | 费用波动：环比/同比波动预警 |
| completeness | 完整性：漏记、异常挂账、红字余额 |

**自定义规则**：支持自然语言录入规则，自动识别目标科目、阈值、适用账套。

### 3. 多账套管理
- 每条规则可绑定单个、多个或全部账套
- 自动匹配当前操作账套与规则适用范围
- 数据按账套和会计期间分区存储

### 4. 检查执行
- 一键执行全部生效规则
- 实时显示检查进度和结果
- 自动标注合规项、异常项、预警项

### 5. 结果输出
- Markdown格式检查清单
- Excel导出
- 自然语言交互查询

## 使用方法

### 初始化规则库
首次使用需初始化预置规则：
```bash
python scripts/main.py init-rules
```

### 导入财务数据
```bash
# 导入科目余额表
python scripts/main.py import data.xlsx --type account_balances --book-code BK001 --book-name "主账套" --period 2024-03

# 导入明细账
python scripts/main.py import detail.xlsx --type detail_ledger --book-code BK001 --book-name "主账套" --period 2024-03

# 导入财务报表
python scripts/main.py import report.xlsx --type financial_report --book-code BK001 --book-name "主账套" --period 2024-03
```

### 预览文件
```bash
python scripts/main.py preview data.xlsx
```

### 执行月结检查
```bash
python scripts/main.py check --book-code BK001 --book-name "主账套" --period 2024-03
```

### 查看检查报告
```bash
# 查看报告
python scripts/main.py report --session CHK_20240301000000_xxxxxxxx

# 导出Excel
python scripts/main.py export --session CHK_20240301000000_xxxxxxxx --output report.xlsx
```

### 管理规则
```bash
# 列出所有规则
python scripts/main.py rules

# 列出生效规则
python scripts/main.py rules --active

# 创建规则
python scripts/main.py create-rule --name "自定义费用检查" --content "检查管理费用是否超出预算" --type custom --accounts 6602 --books BK001 --threshold 10

# 删除规则
python scripts/main.py delete-rule 6
```

### 自然语言查询
```bash
python scripts/main.py query "查看所有生效规则"
python scripts/main.py query "有哪些异常项"
python scripts/main.py query "科目1002的余额" --book-code BK001 --period 2024-03
```

## 数据存储

**数据库位置**：`~/.workbuddy/month_end_check/month_end_check.db`

**数据表结构**：
- `account_balances`：科目余额表
- `detail_ledger`：明细账
- `financial_reports`：财务报表
- `check_rules`：检查规则库
- `check_results`：检查结果
- `operation_logs`：操作日志

## 规则类型说明

### bank_reconciliation（银企对账）
检查银行存款科目余额是否正常，识别负余额等异常情况。

### asset_negative（资产风控）
检查资产类科目（1开头）是否出现负余额。

### accounting_equation（会计恒等式）
验证 资产总额 = 负债总额 + 所有者权益总额。

### expense_fluctuation（费用波动）
检查费用类科目月度环比波动是否超出阈值。
- 默认阈值：10%
- 支持科目：销售费用(6601)、管理费用(6602)、财务费用(6603)

### completeness（完整性）
检查账务完整性问题：
- 红字余额：资产类科目出现贷方余额
- 空发生额：本期无发生额但有余额
- 长期挂账：异常挂账识别

## 数据更新规则

| 数据类型 | 更新规则 |
|---------|---------|
| 科目余额表 | 同期间覆盖更新 |
| 明细账 | 强制防重复录入（凭证号+科目编码+日期唯一） |
| 财务报表 | 同期间覆盖更新 |

## 前置检查

执行检查前自动校验：
1. 检查账套和期间数据是否存在
2. 检查是否已创建规则库
3. 检查是否有生效规则

若未满足条件，系统将引导用户完成数据导入和规则配置。

## 依赖要求

```
pandas>=1.3.0
openpyxl>=3.0.0
```

## 注意事项

1. **数据库独立存储**：财务数据库存放在用户目录下的独立文件夹，与Skill程序分离
2. **数据安全**：所有操作均记录日志，满足审计追溯要求
3. **多账套支持**：规则可灵活配置适用账套范围
4. **智能识别**：支持多种字段命名方式的自动映射
5. **重复防护**：明细账采用多字段唯一约束，防止重复录入
