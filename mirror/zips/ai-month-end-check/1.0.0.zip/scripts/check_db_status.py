#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""检查数据库当前状态"""

import sqlite3, os

db_path = os.path.join(os.path.expanduser('~'), '.workbuddy', 'month_end_check', 'month_end_check.db')
conn = sqlite3.connect(db_path)

# 各表数据量
for table in ['detail_ledger', 'account_balances', 'financial_reports', 'check_rules', 'check_results', 'operation_logs']:
    cnt = conn.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]
    print(f'{table}: {cnt} 条')

# 金融服务9月明细行数
cnt = conn.execute("SELECT COUNT(*) FROM detail_ledger WHERE book_code='BK_64007EF1' AND period='2025-09'").fetchone()[0]
print(f'\n金融服务 2025-09 明细: {cnt} 行')

# 查看当前唯一约束
schema = conn.execute("SELECT sql FROM sqlite_master WHERE name='detail_ledger'").fetchone()[0]
print(f'\n当前 detail_ledger 表结构:\n{schema}')

conn.close()
