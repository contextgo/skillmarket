#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""核对金融服务账套2025年9月财务费用数据"""

import sys
import sqlite3
import os
from pathlib import Path

sys.path.insert(0, os.path.dirname(__file__))
from db_manager import get_db_manager

db = get_db_manager()

# 直接用sqlite3查询，不走上下文管理器
db_path = db.db_path
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row

book_code = 'BK_64007EF1'

# 1. 查看所有期间
print("=" * 60)
print("金融服务账套 - 所有期间分布")
print("=" * 60)
cur = conn.execute('SELECT DISTINCT period FROM detail_ledger WHERE book_code = ? ORDER BY period', (book_code,))
periods = [r['period'] for r in cur.fetchall()]
for p in periods:
    cur = conn.execute('SELECT COUNT(*) as cnt FROM detail_ledger WHERE book_code = ? AND period = ?', (book_code, p))
    cnt = cur.fetchone()['cnt']
    print(f"  {p}: {cnt} 条")

print(f"\n共 {len(periods)} 个期间")

# 2. 重点查 2025-09 财务费用(6603) 全部明细
print("\n" + "=" * 60)
print("2025-09 财务费用(6603) 全部明细账")
print("=" * 60)
cur = conn.execute('''
    SELECT voucher_no, voucher_date, account_code, account_name, summary, debit_amount, credit_amount
    FROM detail_ledger 
    WHERE book_code = ? AND period = ? AND account_code LIKE '6603%'
    ORDER BY account_code, voucher_date, voucher_no
''', (book_code, '2025-09'))

total_debit = 0
total_credit = 0
for row in cur.fetchall():
    print(f"  凭证:{row['voucher_no']} 日期:{row['voucher_date']} 科目:{row['account_code']} {row['account_name']}")
    print(f"    摘要: {row['summary']}")
    print(f"    借方:{row['debit_amount']:.2f}  贷方:{row['credit_amount']:.2f}")
    total_debit += row['debit_amount']
    total_credit += row['credit_amount']

print(f"\n  财务费用6603 - 9月借方合计: {total_debit:.2f}")
print(f"  财务费用6603 - 9月贷方合计: {total_credit:.2f}")
print(f"  财务费用6603 - 9月净发生额: {total_debit - total_credit:.2f}")

# 3. 查看 2025-08 财务费用
print("\n" + "=" * 60)
print("2025-08 财务费用(6603) 全部明细账")
print("=" * 60)
cur = conn.execute('''
    SELECT voucher_no, voucher_date, account_code, account_name, summary, debit_amount, credit_amount
    FROM detail_ledger 
    WHERE book_code = ? AND period = ? AND account_code LIKE '6603%'
    ORDER BY account_code, voucher_date, voucher_no
''', (book_code, '2025-08'))

total_debit_08 = 0
total_credit_08 = 0
for row in cur.fetchall():
    print(f"  凭证:{row['voucher_no']} 日期:{row['voucher_date']} 科目:{row['account_code']} {row['account_name']}")
    print(f"    摘要: {row['summary']}")
    print(f"    借方:{row['debit_amount']:.2f}  贷方:{row['credit_amount']:.2f}")
    total_debit_08 += row['debit_amount']
    total_credit_08 += row['credit_amount']

print(f"\n  财务费用6603 - 8月借方合计: {total_debit_08:.2f}")
print(f"  财务费用6603 - 8月贷方合计: {total_credit_08:.2f}")
print(f"  财务费用6603 - 8月净发生额: {total_debit_08 - total_credit_08:.2f}")

# 4. 检查是否存在结转损益分录（6603在贷方被结转的情况）
print("\n" + "=" * 60)
print("2025-09 财务费用 - 按科目汇总")
print("=" * 60)
cur = conn.execute('''
    SELECT account_code, account_name, 
           SUM(debit_amount) as total_debit, 
           SUM(credit_amount) as total_credit,
           SUM(debit_amount) - SUM(credit_amount) as net
    FROM detail_ledger 
    WHERE book_code = ? AND period = ? AND account_code LIKE '6603%'
    GROUP BY account_code, account_name
    ORDER BY account_code
''', (book_code, '2025-09'))
for row in cur.fetchall():
    print(f"  {row['account_code']} {row['account_name']}: 借方={row['total_debit']:.2f}, 贷方={row['total_credit']:.2f}, 净额={row['net']:.2f}")

print("\n" + "=" * 60)
print("2025-08 财务费用 - 按科目汇总")
print("=" * 60)
cur = conn.execute('''
    SELECT account_code, account_name, 
           SUM(debit_amount) as total_debit, 
           SUM(credit_amount) as total_credit,
           SUM(debit_amount) - SUM(credit_amount) as net
    FROM detail_ledger 
    WHERE book_code = ? AND period = ? AND account_code LIKE '6603%'
    GROUP BY account_code, account_name
    ORDER BY account_code
''', (book_code, '2025-08'))
for row in cur.fetchall():
    print(f"  {row['account_code']} {row['account_name']}: 借方={row['total_debit']:.2f}, 贷方={row['total_credit']:.2f}, 净额={row['net']:.2f}")

conn.close()
