#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI月结智能检查 - 规则引擎模块
处理规则校验逻辑、检查执行
"""

import re
import json
import uuid
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any, Callable
from dataclasses import dataclass
from enum import Enum

# 导入数据库管理器
from db_manager import get_db_manager, CheckRule


class CheckStatus(Enum):
    """检查状态"""
    PASS = "pass"           # 通过
    FAIL = "fail"           # 失败（异常）
    WARNING = "warning"     # 警告
    SKIP = "skip"          # 跳过


@dataclass
class CheckResult:
    """检查结果数据类"""
    rule_id: int
    rule_name: str
    status: CheckStatus
    message: str
    details: Dict[str, Any]


class RuleEngine:
    """规则引擎"""
    
    def __init__(self):
        self.db = get_db_manager()
        self.check_handlers = {
            'bank_reconciliation': self._check_bank_reconciliation,
            'asset_negative': self._check_asset_negative,
            'accounting_equation': self._check_accounting_equation,
            'expense_fluctuation': self._check_expense_fluctuation,
            'completeness': self._check_completeness
        }
    
    def execute_check(self, book_code: str, book_name: str, period: str,
                     rule_ids: Optional[List[int]] = None) -> Tuple[str, List[CheckResult]]:
        """
        执行月结检查
        
        Args:
            book_code: 账套编码
            book_name: 账套名称
            period: 会计期间
            rule_ids: 指定规则ID列表（None则执行所有生效规则）
        
        Returns:
            (检查会话ID, 检查结果列表)
        """
        # 生成检查会话ID
        session_id = f"CHK_{datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:8]}"
        
        # 获取要执行的规则
        if rule_ids:
            rules = []
            for rid in rule_ids:
                rule = self.db.get_rule_by_id(rid)
                if rule:
                    rules.append(rule)
        else:
            # 获取适用于当前账套的所有生效规则
            rules = self.db.get_rules(active_only=True, book_code=book_code)
        
        if not rules:
            return session_id, []
        
        results = []
        
        for rule in rules:
            try:
                result = self._execute_single_rule(rule, book_code, book_name, period)
                results.append(result)
                
                # 保存结果到数据库
                self.db.save_check_result(
                    session_id, book_code, period,
                    rule['rule_id'], rule['rule_name'],
                    result.status.value, result.message, result.details
                )
            except Exception as e:
                # 规则执行异常
                result = CheckResult(
                    rule_id=rule['rule_id'],
                    rule_name=rule['rule_name'],
                    status=CheckStatus.SKIP,
                    message=f"规则执行异常: {str(e)}",
                    details={"error": str(e)}
                )
                results.append(result)
                
                self.db.save_check_result(
                    session_id, book_code, period,
                    rule['rule_id'], rule['rule_name'],
                    result.status.value, result.message, result.details
                )
        
        return session_id, results
    
    def _execute_single_rule(self, rule: Dict, book_code: str, 
                            book_name: str, period: str) -> CheckResult:
        """执行单个规则检查"""
        rule_type = rule.get('rule_type', '')
        handler = self.check_handlers.get(rule_type)
        
        if handler:
            return handler(rule, book_code, book_name, period)
        else:
            # 自定义规则 - 尝试解析规则内容
            return self._check_custom_rule(rule, book_code, book_name, period)
    
    # ==================== 预置规则实现 ====================
    
    def _check_bank_reconciliation(self, rule: Dict, book_code: str,
                                    book_name: str, period: str) -> CheckResult:
        """
        银企对账规则
        检查：银行存款科目余额与实际银行账户余额是否一致
        """
        # 获取银行存款科目余额
        bank_accounts = self.db.get_account_balances(book_code, period)
        bank_accounts = [a for a in bank_accounts if str(a['account_code']).startswith('1002')]
        
        if not bank_accounts:
            return CheckResult(
                rule_id=rule['rule_id'],
                rule_name=rule['rule_name'],
                status=CheckStatus.SKIP,
                message="未找到银行存款科目数据",
                details={"accounts_checked": []}
            )
        
        # 模拟对账检查（实际应用需要接入银行API或人工导入银行对账单）
        # 这里检查银行存款科目是否有异常（如负数余额）
        issues = []
        total_balance = 0
        
        for account in bank_accounts:
            balance = account.get('closing_debit', 0) - account.get('closing_credit', 0)
            total_balance += balance
            
            if balance < 0:
                issues.append({
                    'account_code': account['account_code'],
                    'account_name': account['account_name'],
                    'balance': balance,
                    'issue': '银行存款科目余额为负数'
                })
        
        if issues:
            return CheckResult(
                rule_id=rule['rule_id'],
                rule_name=rule['rule_name'],
                status=CheckStatus.WARNING,
                message=f"发现 {len(issues)} 个银行存款科目异常",
                details={
                    'accounts_checked': len(bank_accounts),
                    'total_balance': total_balance,
                    'issues': issues
                }
            )
        
        return CheckResult(
            rule_id=rule['rule_id'],
            rule_name=rule['rule_name'],
            status=CheckStatus.PASS,
            message=f"银行存款科目检查通过，共 {len(bank_accounts)} 个科目，总余额 {total_balance:,.2f}",
            details={
                'accounts_checked': len(bank_accounts),
                'total_balance': total_balance
            }
        )
    
    def _check_asset_negative(self, rule: Dict, book_code: str,
                             book_name: str, period: str) -> CheckResult:
        """
        资产类科目风控规则
        检查：所有资产类科目余额不得为负数
        """
        # 资产类科目代码范围：1开头
        target_accounts = rule.get('target_accounts', '').split(',')
        
        # 获取科目余额
        all_balances = self.db.get_account_balances(book_code, period)
        
        # 筛选资产类科目
        asset_accounts = []
        for account in all_balances:
            code = str(account['account_code'])
            if code.startswith('1') or any(code.startswith(t.strip()) for t in target_accounts if t.strip()):
                asset_accounts.append(account)
        
        issues = []
        
        for account in asset_accounts:
            # 计算期末余额
            debit = account.get('closing_debit', 0)
            credit = account.get('closing_credit', 0)
            balance = debit - credit
            
            if balance < 0:
                issues.append({
                    'account_code': account['account_code'],
                    'account_name': account['account_name'],
                    'balance': balance,
                    'debit': debit,
                    'credit': credit
                })
        
        if issues:
            return CheckResult(
                rule_id=rule['rule_id'],
                rule_name=rule['rule_name'],
                status=CheckStatus.FAIL,
                message=f"发现 {len(issues)} 个资产类科目余额为负数",
                details={
                    'accounts_checked': len(asset_accounts),
                    'issue_count': len(issues),
                    'issues': issues
                }
            )
        
        return CheckResult(
            rule_id=rule['rule_id'],
            rule_name=rule['rule_name'],
            status=CheckStatus.PASS,
            message=f"资产类科目检查通过，共检查 {len(asset_accounts)} 个科目",
            details={'accounts_checked': len(asset_accounts)}
        )
    
    def _check_accounting_equation(self, rule: Dict, book_code: str,
                                   book_name: str, period: str) -> CheckResult:
        """
        会计恒等式校验规则
        检查：资产总额 = 负债总额 + 所有者权益总额
        """
        # 获取所有科目余额
        balances = self.db.get_account_balances(book_code, period)
        
        # 计算各类总额
        assets = 0      # 资产类（1开头）
        liabilities = 0 # 负债类（2开头）
        equity = 0      # 所有者权益（4开头）
        
        for account in balances:
            code = str(account['account_code'])
            balance = account.get('closing_debit', 0) - account.get('closing_credit', 0)
            
            if code.startswith('1'):
                assets += balance
            elif code.startswith('2'):
                liabilities += abs(balance)
            elif code.startswith('4'):
                equity += abs(balance)
        
        # 检查恒等式
        left = assets
        right = liabilities + equity
        diff = abs(left - right)
        tolerance = 0.01  # 容差
        
        if diff > tolerance:
            return CheckResult(
                rule_id=rule['rule_id'],
                rule_name=rule['rule_name'],
                status=CheckStatus.FAIL,
                message=f"会计恒等式不成立：资产({left:,.2f}) ≠ 负债({liabilities:,.2f}) + 权益({equity:,.2f})，差额 {diff:,.2f}",
                details={
                    'assets': assets,
                    'liabilities': liabilities,
                    'equity': equity,
                    'difference': diff
                }
            )
        
        return CheckResult(
            rule_id=rule['rule_id'],
            rule_name=rule['rule_name'],
            status=CheckStatus.PASS,
            message=f"会计恒等式校验通过：资产({left:,.2f}) = 负债({liabilities:,.2f}) + 权益({equity:,.2f})",
            details={
                'assets': assets,
                'liabilities': liabilities,
                'equity': equity,
                'difference': diff
            }
        )
    
    def _check_expense_fluctuation(self, rule: Dict, book_code: str,
                                   book_name: str, period: str) -> CheckResult:
        """
        费用波动预警规则
        检查：各项费用月度环比波动是否超出阈值
        """
        threshold = rule.get('threshold_value', 10.0)  # 默认10%
        target_accounts = rule.get('target_accounts', '6601,6602,6603').split(',')
        
        # 解析期间，获取上月期间
        try:
            year, month = int(period[:4]), int(period[5:7])
            if month == 1:
                prev_period = f"{year-1}-12"
            else:
                prev_period = f"{year}-{month-1:02d}"
        except:
            prev_period = None
        
        current_balances = self.db.get_account_balances(book_code, period)
        
        warnings = []
        
        for account in current_balances:
            code = str(account['account_code'])
            # 匹配费用类科目
            if any(code.startswith(t.strip()) for t in target_accounts if t.strip()):
                current_amount = account.get('current_debit', 0)
                
                # 获取上期金额
                prev_amount = 0
                if prev_period:
                    prev_balances = self.db.get_account_balances(book_code, prev_period)
                    for prev in prev_balances:
                        if prev['account_code'] == code:
                            prev_amount = prev.get('current_debit', 0)
                            break
                
                # 计算环比波动
                if prev_amount > 0:
                    fluctuation = abs(current_amount - prev_amount) / prev_amount * 100
                elif current_amount > 0:
                    fluctuation = 100  # 上期无发生，本期有发生
                else:
                    fluctuation = 0
                
                if fluctuation > threshold:
                    warnings.append({
                        'account_code': code,
                        'account_name': account['account_name'],
                        'current_amount': current_amount,
                        'previous_amount': prev_amount,
                        'fluctuation': round(fluctuation, 2),
                        'threshold': threshold
                    })
        
        if warnings:
            return CheckResult(
                rule_id=rule['rule_id'],
                rule_name=rule['rule_name'],
                status=CheckStatus.WARNING,
                message=f"发现 {len(warnings)} 项费用超出 {threshold}% 波动阈值",
                details={
                    'threshold': threshold,
                    'warning_count': len(warnings),
                    'warnings': warnings
                }
            )
        
        return CheckResult(
            rule_id=rule['rule_id'],
            rule_name=rule['rule_name'],
            status=CheckStatus.PASS,
            message=f"费用波动检查通过，未超出 {threshold}% 阈值",
            details={'threshold': threshold, 'warnings': []}
        )
    
    def _check_completeness(self, rule: Dict, book_code: str,
                           book_name: str, period: str) -> CheckResult:
        """
        账务完整性核查规则
        检查：科目漏记、异常挂账、红字余额等
        """
        balances = self.db.get_account_balances(book_code, period)
        
        issues = {
            'red_balance': [],      # 红字余额
            'long_hanging': [],     # 长期挂账
            'empty_movement': [],   # 无发生额但有余额
            'inconsistent': []       # 借贷不平
        }
        
        for account in balances:
            code = str(account['account_code'])
            name = account['account_name']
            
            closing_debit = account.get('closing_debit', 0)
            closing_credit = account.get('closing_credit', 0)
            current_debit = account.get('current_debit', 0)
            current_credit = account.get('current_credit', 0)
            
            balance = closing_debit - closing_credit
            
            # 检查1：红字余额（资产类科目期末贷方余额，负债类期末借方余额）
            if code.startswith('1') and balance < 0:
                issues['red_balance'].append({
                    'account_code': code,
                    'account_name': name,
                    'balance': balance,
                    'issue': '资产类科目出现贷方余额'
                })
            elif code.startswith(('2', '3')) and balance > 0:
                issues['red_balance'].append({
                    'account_code': code,
                    'account_name': name,
                    'balance': balance,
                    'issue': '负债/权益类科目出现借方余额'
                })
            
            # 检查2：无发生额但有期末余额
            if current_debit == 0 and current_credit == 0 and balance != 0:
                issues['empty_movement'].append({
                    'account_code': code,
                    'account_name': name,
                    'balance': balance,
                    'issue': '本期无发生额但有余额'
                })
        
        # 统计问题
        total_issues = sum(len(v) for v in issues.values())
        
        if total_issues > 0:
            return CheckResult(
                rule_id=rule['rule_id'],
                rule_name=rule['rule_name'],
                status=CheckStatus.WARNING,
                message=f"发现 {total_issues} 项账务完整性问题",
                details={
                    'red_balance_count': len(issues['red_balance']),
                    'long_hanging_count': len(issues['long_hanging']),
                    'empty_movement_count': len(issues['empty_movement']),
                    'issues': issues
                }
            )
        
        return CheckResult(
            rule_id=rule['rule_id'],
            rule_name=rule['rule_name'],
            status=CheckStatus.PASS,
            message="账务完整性检查通过，未发现异常",
            details={'accounts_checked': len(balances)}
        )
    
    def _check_custom_rule(self, rule: Dict, book_code: str,
                          book_name: str, period: str) -> CheckResult:
        """
        自定义规则检查
        解析规则内容并执行
        """
        # 简单实现：根据规则内容关键字匹配
        content = rule.get('rule_content', '').lower()
        
        if '余额' in content and '负数' in content:
            # 类似资产负数检查
            return self._check_asset_negative(rule, book_code, book_name, period)
        
        # 其他自定义规则解析...
        
        return CheckResult(
            rule_id=rule['rule_id'],
            rule_name=rule['rule_name'],
            status=CheckStatus.SKIP,
            message=f"自定义规则暂不支持自动执行: {content[:50]}",
            details={'rule_content': content}
        )
    
    # ==================== 规则管理方法 ====================
    
    def create_rule_from_natural_language(self, description: str, 
                                         applicable_books: str = "all") -> Tuple[bool, str, Optional[int]]:
        """
        从自然语言描述创建规则
        
        Args:
            description: 规则描述
            applicable_books: 适用账套
        
        Returns:
            (成功状态, 消息, 规则ID)
        """
        # 解析自然语言
        rule_type = self._parse_rule_type(description)
        rule_name = self._generate_rule_name(description)
        target_accounts = self._parse_target_accounts(description)
        threshold = self._parse_threshold(description)
        
        rule = CheckRule(
            rule_name=rule_name,
            rule_content=description,
            rule_type=rule_type,
            target_accounts=target_accounts,
            threshold_value=threshold,
            applicable_books=applicable_books
        )
        
        return self.db.create_rule(rule)
    
    def _parse_rule_type(self, description: str) -> str:
        """从描述中解析规则类型"""
        desc = description.lower()
        
        if '银行' in desc or '存款' in desc:
            return 'bank_reconciliation'
        elif '资产' in desc and ('负' in desc or '贷方' in desc):
            return 'asset_negative'
        elif '恒等' in desc or '资产=负债' in desc or '平衡' in desc:
            return 'accounting_equation'
        elif '费用' in desc and ('波动' in desc or '变动' in desc or '增减' in desc):
            return 'expense_fluctuation'
        elif '完整' in desc or '漏记' in desc or '挂账' in desc:
            return 'completeness'
        else:
            return 'custom'
    
    def _generate_rule_name(self, description: str) -> str:
        """生成规则名称"""
        # 提取前20个字符作为名称
        if len(description) <= 20:
            return description
        return description[:20] + "..."
    
    def _parse_target_accounts(self, description: str) -> str:
        """从描述中解析目标科目"""
        # 匹配科目代码模式如 "1002", "6601", "1001.01" 等
        pattern = r'\b\d{4}(?:\.\d{2,3})*\b'
        codes = re.findall(pattern, description)
        return ','.join(codes) if codes else ""
    
    def _parse_threshold(self, description: str) -> Optional[float]:
        """从描述中解析阈值"""
        # 匹配百分比数字
        pattern = r'(\d+(?:\.\d+)?)\s*%'
        matches = re.findall(pattern, description)
        if matches:
            return float(matches[0])
        return None
    
    def update_rule_by_description(self, rule_id: int, 
                                   description: str) -> Tuple[bool, str]:
        """通过自然语言描述更新规则"""
        updates = {}
        
        # 解析更新内容
        if '名称' in description or '改名' in description:
            # 提取新名称
            pass
        if '适用账套' in description or '账套' in description:
            # 更新适用账套
            pass
        if '阈值' in description or '比例' in description:
            threshold = self._parse_threshold(description)
            if threshold:
                updates['threshold_value'] = threshold
        
        return self.db.update_rule(rule_id, updates)


# 单例
_engine = None

def get_rule_engine() -> RuleEngine:
    """获取规则引擎单例"""
    global _engine
    if _engine is None:
        _engine = RuleEngine()
    return _engine


if __name__ == '__main__':
    # 测试代码
    engine = RuleEngine()
    print("规则引擎初始化完成")
