#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
修复数据库：重建 detail_ledger 表（加 row_seq 唯一约束），然后重新导入全部数据
"""

import sqlite3, os

db_path = os.path.join(os.path.expanduser('~'), '.workbuddy', 'month_end_check', 'month_end_check.db')
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# 备份旧数据量
old_count = cursor.execute('SELECT COUNT(*) FROM detail_ledger').fetchone()[0]
print(f'旧表 detail_ledger 记录数: {old_count}')

# 删除旧表
cursor.execute('DROP TABLE IF EXISTS detail_ledger')
print('旧表已删除')

# 重建表（新结构，包含 row_seq）
cursor.execute('''
    CREATE TABLE detail_ledger (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        book_code TEXT NOT NULL,
        book_name TEXT NOT NULL,
        period TEXT NOT NULL,
        row_seq INTEGER NOT NULL,
        voucher_no TEXT,
        voucher_date DATE,
        account_code TEXT NOT NULL,
        account_name TEXT,
        summary TEXT,
        debit_amount REAL DEFAULT 0,
        credit_amount REAL DEFAULT 0,
        direction TEXT,
        balance REAL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(book_code, period, row_seq)
    )
''')
print('新表已创建（含 row_seq 唯一约束）')

# 重建索引
cursor.execute('CREATE INDEX IF NOT EXISTS idx_detail_book_period ON detail_ledger(book_code, period)')
print('索引已重建')

conn.commit()
conn.close()

print('\n数据库修复完成！可以重新导入了。')
