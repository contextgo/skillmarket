#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""费用波动分析V2 - 按二级科目细化分析 + 正确科目名称"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from db_manager import get_db_manager
from collections import defaultdict

db = get_db_manager()
book_code = 'BK_64007EF1'

data_09 = db.get_detail_ledger(book_code, '2025-09')
data_08 = db.get_detail_ledger(book_code, '2025-08')

def get_level2_info(code, name):
    """获取二级科目编码和名称"""
    parts = code.split('.')
    level2_code = parts[0] if len(parts) < 2 else f"{parts[0]}.{parts[1]}"
    # 从全名中提取前两级
    name_parts = name.split('_') if '_' in name else [name]
    level2_name = name_parts[0] if len(name_parts) < 2 else f"{name_parts[0]}_{name_parts[1]}"
    return level2_code, level2_name

def summarize_expenses_v2(data, period_label):
    """按二级科目汇总费用类科目发生额"""
    expenses = defaultdict(lambda: {'debit': 0.0, 'credit': 0.0, 'name': '', 'count': 0})
    for row in data:
        code = row.get('account_code', '')
        name = row.get('account_name', '')
        if code.startswith('6'):
            level2_code, level2_name = get_level2_info(code, name)
            expenses[level2_code]['debit'] += float(row.get('debit_amount', 0) or 0)
            expenses[level2_code]['credit'] += float(row.get('credit_amount', 0) or 0)
            expenses[level2_code]['count'] += 1
            if not expenses[level2_code]['name']:
                expenses[level2_code]['name'] = level2_name
    
    print(f"\n{'='*95}")
    print(f"  {period_label} 费用科目汇总（二级科目）")
    print(f"{'='*95}")
    
    result = {}
    for code in sorted(expenses.keys()):
        info = expenses[code]
        net = info['debit'] - info['credit']
        result[code] = {'name': info['name'], 'debit': info['debit'], 'credit': info['credit'], 'net': net, 'count': info['count']}
        print(f"  {code:<12} {info['name']:<24} 借方:{info['debit']:>15,.2f}  贷方:{info['credit']:>15,.2f}  净额:{net:>15,.2f}")
    
    print(f"{'='*95}")
    return result

exp_09 = summarize_expenses_v2(data_09, "2025年9月")
exp_08 = summarize_expenses_v2(data_08, "2025年8月")

# 科目名称映射表
CODE_NAMES = {
    '6001': '主营业务收入', '6051': '其他业务收入',
    '6111': '公允价值变动损益', '6117': '资产处置损益',
    '6401': '主营业务成本', '6403': '税金及附加',
    '6405': '税金及附加(旧)', '6601': '销售费用',
    '6602': '管理费用', '6603': '财务费用',
    '6601.01': '销售费用_职工薪酬', '6601.07': '销售费用_差旅费',
    '6601.08': '销售费用_交通费', '6601.14': '销售费用_业务招待费',
    '6601.15': '销售费用_办公费', '6601.04': '销售费用_福利费',
    '6602.01': '管理费用_职工薪酬', '6602.02': '管理费用_办公费',
    '6602.04': '管理费用_福利费', '6602.05': '管理费用_折旧费',
    '6602.06': '管理费用_无形资产摊销', '6602.08': '管理费用_咨询服务费',
    '6602.09': '管理费用_差旅费', '6602.10': '管理费用_交通费',
    '6602.11': '管理费用_业务招待费', '6602.13': '管理费用_房租',
    '6602.14': '管理费用_劳务费', '6602.15': '管理费用_审计费',
    '6602.17': '管理费用_培训费', '6602.18': '管理费用_水电费',
    '6602.19': '管理费用_其他', '6602.20': '管理费用_通讯费',
    '6602.22': '管理费用_车辆使用费', '6602.24': '管理费用_诉讼费',
    '6603.01': '财务费用_利息支出', '6603.02': '财务费用_利息收入',
    '6603.04': '财务费用_手续费', '6603.05': '财务费用_汇兑损益',
}

def get_name(code):
    if code in CODE_NAMES:
        return CODE_NAMES[code]
    return exp_08.get(code, {}).get('name', exp_09.get(code, {}).get('name', code))

# 波动对比
print(f"\n{'='*100}")
print(f"  费用波动分析: 2025年9月 vs 8月（二级科目）")
print(f"{'='*100}")
print(f"{'科目编码':<14} {'科目名称':<20} {'8月净额':>16} {'9月净额':>16} {'变动额':>16} {'波动率':>10} {'状态':<8}")
print(f"{'-'*100}")

anomalies = []
all_codes = sorted(set(list(exp_09.keys()) + list(exp_08.keys())))

for code in all_codes:
    name = get_name(code)
    net_08 = abs(exp_08.get(code, {}).get('net', 0))
    net_09 = abs(exp_09.get(code, {}).get('net', 0))
    change = net_09 - net_08
    
    if net_08 > 0.01:
        rate = (change / net_08) * 100
    elif net_09 > 0.01:
        rate = float('inf')
    else:
        rate = 0
    
    if net_08 < 0.01 and net_09 < 0.01:
        status = '--'
        rate_display = '--'
    elif net_08 < 0.01 and net_09 > 0.01:
        status = '!! 新增'
        rate_display = '新增'
        anomalies.append({'code': code, 'name': name, 'net_08': net_08, 'net_09': net_09, 'change': change, 'rate': rate, 'status': status})
    elif net_09 < 0.01 and net_08 > 0.01:
        status = '!! 消失'
        rate_display = '消失'
        anomalies.append({'code': code, 'name': name, 'net_08': net_08, 'net_09': net_09, 'change': change, 'rate': rate, 'status': status})
    elif abs(rate) >= 50:
        status = '!! 异常'
        rate_display = f'{rate:+.1f}%'
        anomalies.append({'code': code, 'name': name, 'net_08': net_08, 'net_09': net_09, 'change': change, 'rate': rate, 'status': status})
    elif abs(rate) >= 30:
        status = '! 预警'
        rate_display = f'{rate:+.1f}%'
    elif abs(rate) >= 10:
        status = '关注'
        rate_display = f'{rate:+.1f}%'
    else:
        status = '正常'
        rate_display = f'{rate:+.1f}%'
    
    print(f"{code:<14} {name:<20} {net_08:>16,.2f} {net_09:>16,.2f} {change:>+16,.2f} {rate_display:>10} {status:<8}")

print(f"{'-'*100}")

# 汇总费用（6601+6602+6603）
fee_codes_08 = {k: v for k, v in exp_08.items() if k.startswith('66')}
fee_codes_09 = {k: v for k, v in exp_09.items() if k.startswith('66')}
total_fee_08 = sum(abs(v['net']) for v in fee_codes_08.values())
total_fee_09 = sum(abs(v['net']) for v in fee_codes_09.values())
fee_change = total_fee_09 - total_fee_08
fee_rate = (fee_change / total_fee_08 * 100) if total_fee_08 > 0 else 0

print(f"{'三项费用合计':<34} {total_fee_08:>16,.2f} {total_fee_09:>16,.2f} {fee_change:>+16,.2f} {fee_rate:>+9.1f}%")

# 异常科目下钻
if anomalies:
    print(f"\n{'='*100}")
    print(f"  异常科目明细分析")
    print(f"{'='*100}")
    for a in anomalies:
        print(f"\n  [{a['status']}] {a['code']} - {a['name']}")
        print(f"    8月净额: {a['net_08']:,.2f}  ->  9月净额: {a['net_09']:,.2f}  变动: {a['change']:+,.2f}")
        
        # 查看波动大的那个月的明细
        if a['net_09'] >= a['net_08']:
            period = '2025-09'
            data_detail = data_09
        else:
            period = '2025-08'
            data_detail = data_08
        
        level1 = a['code'].split('.')[0]
        level2 = a['code']
        matching = []
        for d in data_detail:
            dc = d.get('account_code', '')
            # 匹配二级科目
            if dc == level2 or dc.startswith(level2 + '.') or (dc.startswith(level1 + '.') and '.' not in dc.replace(level1 + '.', '', 1)):
                matching.append(d)
        
        if not matching:
            # 回退到一级匹配
            matching = [d for d in data_detail if d.get('account_code', '').startswith(level1)]
        
        if matching:
            # 按摘要分组统计
            summary_group = defaultdict(float)
            for d in matching:
                sm = d.get('summary', '其他')[:30]
                debit = float(d.get('debit_amount', 0) or 0)
                credit = float(d.get('credit_amount', 0) or 0)
                summary_group[sm] += max(debit, credit)
            
            print(f"    --- {period} 主要摘要分布（Top 10）---")
            for sm, amt in sorted(summary_group.items(), key=lambda x: -x[1])[:10]:
                print(f"    {amt:>14,.2f}  | {sm}")
            if len(summary_group) > 10:
                print(f"    ... 共 {len(summary_group)} 个摘要类别")

print(f"\n分析完成。")
