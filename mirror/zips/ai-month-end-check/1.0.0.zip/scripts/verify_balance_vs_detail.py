#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""核对科目余额表 vs 明细账数据差异"""
import sqlite3
import os

db_path = os.path.join(os.path.expanduser('~'), '.workbuddy', 'month_end_check', 'month_end_check.db')
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row

BOOK_CODE = 'BK_64007EF1'

print("=" * 90)
print("  核对：科目余额表 vs 明细账（2025年9月 销售费用6601）")
print("=" * 90)
print()

# 1. 从明细账计算（借方发生额，排除结转损益）
cur = conn.execute('''
    SELECT account_code, account_name, SUM(debit_amount) as total_debit, SUM(credit_amount) as total_credit
    FROM detail_ledger 
    WHERE book_code = ? AND period = ? AND account_code LIKE '6601%' 
          AND summary NOT LIKE '%结转%' AND summary NOT LIKE '%损益%'
    GROUP BY account_code, account_name
    ORDER BY account_code
''', (BOOK_CODE, '2025-09'))

detail_data = {r['account_code']: {
    'name': r['account_name'],
    'debit': r['total_debit'],
    'credit': r['total_credit'],
    'net': r['total_debit'] - r['total_credit']
} for r in cur.fetchall()}

# 2. 从科目余额表取数
cur = conn.execute('''
    SELECT account_code, account_name, current_debit, current_credit
    FROM account_balances 
    WHERE book_code = ? AND period = ? AND account_code LIKE '6601%'
    ORDER BY account_code
''', (BOOK_CODE, '2025-09'))

balance_data = {r['account_code']: {
    'name': r['account_name'],
    'debit': r['current_debit'],
    'credit': r['current_credit'],
    'net': r['current_debit'] - r['current_credit']
} for r in cur.fetchall()}

# 3. 对比关键科目
print("  关键科目对比（2025年9月）：")
print(f"  {'科目编码':<15} {'科目名称':<30} {'明细账借方':>14} {'余额表借方':>14} {'差异':>14}")
print(f"  {'-'*90}")

key_codes = [
    '6601.01.01', '6601.02.01', '6601.02.02', '6601.02.99', '6601.03.02',
    '6601.05', '6601.07', '6601.08', '6601.09.01', '6601.10', '6601.11',
    '6601.12', '6601.13.01', '6601.13.02', '6601.13.99', '6601.14', '6601.16',
    '6601.17', '6601.18', '6601.19', '6601.21', '6601.25'
]

total_detail = 0
total_balance = 0

for code in key_codes:
    d = detail_data.get(code, {})
    b = balance_data.get(code, {})
    d_debit = d.get('debit', 0) or 0
    b_debit = b.get('debit', 0) or 0
    diff = d_debit - b_debit
    name = d.get('name') or b.get('name') or code
    name_short = name[:28]
    total_detail += d_debit
    total_balance += b_debit
    print(f"  {code:<15} {name_short:<30} {d_debit:>14,.2f} {b_debit:>14,.2f} {diff:>+14,.2f}")

print(f"  {'-'*90}")
print(f"  {'合计':<15} {'':<30} {total_detail:>14,.2f} {total_balance:>14,.2f} {total_detail-total_balance:>+14,.2f}")
print()

# 4. 检查是否有只在余额表存在的科目
print("  只在科目余额表中存在的科目（明细账缺失）：")
only_in_balance = set(balance_data.keys()) - set(detail_data.keys())
if only_in_balance:
    for code in sorted(only_in_balance):
        b = balance_data[code]
        print(f"    {code}: {b['name']} 借方={b['debit']:,.2f}")
else:
    print("    无")
print()

# 5. 检查是否有只在明细账存在的科目
print("  只在明细账中存在的科目（余额表缺失）：")
only_in_detail = set(detail_data.keys()) - set(balance_data.keys())
if only_in_detail:
    for code in sorted(only_in_detail):
        d = detail_data[code]
        print(f"    {code}: {d['name']} 借方={d['debit']:,.2f}")
else:
    print("    无")
print()

# 6. 用户截图中的数据（2025年9月）
print("=" * 90)
print("  用户截图数据（2025年9月）vs 数据库余额表对比：")
print("=" * 90)
print()

user_data = {
    '6601.01.01': 1528116.13,  # 销售费用_工资_基础工资
    '6601.02.01': 70.00,        # 销售费用_办公费_办公用品
    '6601.02.02': 51.20,        # 销售费用_办公费_快递费
    '6601.02.99': 4822.23,      # 销售费用_办公费_其他
    '6601.03.02': 87855.75,     # 销售费用_房租物业费_物业费
    '6601.05': 1653.11,         # 销售费用_累计折旧
    '6601.07': 251041.15,       # 销售费用_差旅费
    '6601.08': 31259.09,        # 销售费用_市内交通费
    '6601.09.01': 9619.22,      # 销售费用_车辆使用费_油费及停车费
    '6601.10': 0.00,            # 销售费用_水电费
    '6601.11': 213826.82,       # 销售费用_社会保险
    '6601.12': 57982.00,        # 销售费用_公积金
    '6601.13.01': 296.70,       # 销售费用_福利费_餐费及下午茶
    '6601.13.02': 29451.32,     # 销售费用_福利费_月福利
    '6601.13.99': 18386.00,     # 销售费用_福利费_其他
    '6601.14': 178388.31,       # 销售费用_招待费
    '6601.16': 496.15,          # 销售费用_业务宣传费
    '6601.17': 26930.18,        # 销售费用_会务费
    '6601.18': 0.00,            # 销售费用_咨询费
    '6601.19': 816175.59,       # 销售费用_服务费
    '6601.21': 0.00,            # 销售费用_招聘费用
    '6601.25': 34313.32,        # 销售费用_团队活动费
}

print(f"  {'科目编码':<15} {'用户数据':>14} {'余额表数据':>14} {'差异':>14} {'说明':<20}")
print(f"  {'-'*80}")

total_user = 0
total_db = 0
for code, user_amt in user_data.items():
    db_amt = balance_data.get(code, {}).get('debit', 0) or 0
    diff = user_amt - db_amt
    total_user += user_amt
    total_db += db_amt
    note = ""
    if abs(diff) > 1:
        note = "数据不一致!"
    print(f"  {code:<15} {user_amt:>14,.2f} {db_amt:>14,.2f} {diff:>+14,.2f} {note}")

print(f"  {'-'*80}")
print(f"  {'合计':<15} {total_user:>14,.2f} {total_db:>14,.2f} {total_user-total_db:>+14,.2f}")
print()

conn.close()
