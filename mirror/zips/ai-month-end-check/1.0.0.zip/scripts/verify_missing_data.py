#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""核查明细账唯一约束导致的数据丢失问题"""
import sqlite3, os, pandas as pd

db_path = os.path.join(os.path.expanduser('~'), '.workbuddy', 'month_end_check', 'month_end_check.db')
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row

BOOK_CODE = 'BK_64007EF1'

# 1. 查看数据库中6601.01.01的所有记录
print("=" * 80)
print("  数据库中 6601.01.01 的所有记录（2025-09）")
print("=" * 80)
cur = conn.execute('''
    SELECT voucher_no, voucher_date, account_code, account_name, summary, debit_amount, credit_amount
    FROM detail_ledger 
    WHERE book_code = ? AND period = ? AND account_code = '6601.01.01'
    ORDER BY voucher_no
''', (BOOK_CODE, '2025-09'))

for r in cur.fetchall():
    print(f"  凭证:{r['voucher_no']}  日期:{r['voucher_date']}  摘要:{r['summary']}")
    print(f"    借方:{r['debit_amount']:,.2f}  贷方:{r['credit_amount']:,.2f}")

# 2. 查看用户的完整数据
print()
print("=" * 80)
print("  用户文件数据（工作簿2.xlsx）")
print("=" * 80)
df = pd.read_excel(r'C:/Users/bianjing/Downloads/工作簿2.xlsx')
for _, row in df.iterrows():
    print(f"  凭证:{row['凭证号']}  日期:{row['日期']}  摘要:{row['摘要']}  核算维度:{row['核算维度']}")
    debit = row['借方金额'] if pd.notna(row['借方金额']) else 0
    credit = row['贷方金额'] if pd.notna(row['贷方金额']) else 0
    print(f"    借方:{debit:,.2f}  贷方:{credit:,.2f}")

# 3. 分析根本原因
print()
print("=" * 80)
print("  差异分析")
print("=" * 80)
print()
print("  数据库唯一约束: (book_code, period, voucher_no, voucher_date, account_code)")
print()
print("  用户的凭证507有两条6601.01.01分录:")
print("    第1条: 外设机构(BM000098) -> 借方 898,641.02")
print("    第2条: 公司(BM000317)     -> 借方 629,475.11")
print()
print("  这两条的唯一约束字段完全相同: (BK_xxx, 2025-09, 507, 2025/9/30, 6601.01.01)")
print("  所以第2条被当作重复数据跳过了!")
print()
print("  缺失金额: 629,475.11 (公司主体的工资分摊)")
print("  实际应有: 898,641.02 + 629,475.11 = 1,528,116.13")
print("  数据库只有: 898,641.02")
print("  差异: 629,475.11")

# 4. 全面评估影响范围
print()
print("=" * 80)
print("  全面评估：有多少凭证存在同号多核算维度的情况")
print("=" * 80)
cur = conn.execute('''
    SELECT voucher_no, account_code, COUNT(*) as cnt, SUM(debit_amount) as total_debit, SUM(credit_amount) as total_credit
    FROM detail_ledger 
    WHERE book_code = ? AND period = ? AND account_code LIKE '6601%'
    GROUP BY voucher_no, account_code
    HAVING cnt = 1
''', (BOOK_CODE, '2025-09'))
single = cur.fetchall()

cur = conn.execute('''
    SELECT voucher_no, account_code, COUNT(*) as cnt, SUM(debit_amount) as total_debit, SUM(credit_amount) as total_credit
    FROM detail_ledger 
    WHERE book_code = ? AND period = ? AND account_code LIKE '6601%'
    GROUP BY voucher_no, account_code
    HAVING cnt > 1
''', (BOOK_CODE, '2025-09'))
multi = cur.fetchall()

print(f"  单条记录的(凭证+科目)组合: {len(single)}")
print(f"  多条记录的(凭证+科目)组合: {len(multi)}")
print()
if multi:
    print("  多条记录的凭证+科目组合（可能存在丢失数据）:")
    for r in sorted(multi, key=lambda x: -x[3]):
        print(f"    凭证:{r[0]}  科目:{r[1]}  记录数:{r[2]}  借方合计:{r[3]:,.2f}")

conn.close()
