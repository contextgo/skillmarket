#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""销售费用波动分析 - 金融服务 2025年9月 vs 8月
费用金额 = 借方发生额合计（排除结转损益分录）
"""
import sys
import os
import sqlite3
import json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from collections import defaultdict

db_path = os.path.join(os.path.expanduser('~'), '.workbuddy', 'month_end_check', 'month_end_check.db')
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row

BOOK_CODE = 'BK_64007EF1'

def get_level2_code(code):
    parts = code.split('.')
    return parts[0] if len(parts) < 2 else f"{parts[0]}.{parts[1]}"

def is_transfer(summary):
    s = str(summary or '')
    return '结转' in s or '损益' in s

def load_period_data(period):
    """加载某期间6601开头的明细，排除结转损益"""
    cur = conn.execute('''
        SELECT account_code, account_name, summary, debit_amount, credit_amount, voucher_no, voucher_date
        FROM detail_ledger 
        WHERE book_code = ? AND period = ? AND account_code LIKE '6601%'
        ORDER BY account_code, voucher_date, voucher_no
    ''', (BOOK_CODE, period))
    return [dict(r) for r in cur.fetchall()]

def summarize(data):
    """按二级科目汇总，只取借方发生额（费用科目的正常方向）"""
    result = defaultdict(lambda: {'debit': 0.0, 'credit': 0.0, 'name': '', 'details': []})
    for row in data:
        code = row['account_code']
        name = row['account_name']
        summary = row['summary']
        
        # 排除结转损益
        if is_transfer(summary):
            continue
        
        level2 = get_level2_code(code)
        debit = float(row['debit_amount'] or 0)
        credit = float(row['credit_amount'] or 0)
        
        result[level2]['debit'] += debit
        result[level2]['credit'] += credit
        if debit > 0:
            result[level2]['details'].append({
                'voucher_no': row['voucher_no'],
                'date': row['voucher_date'],
                'summary': summary,
                'amount': debit
            })
        # 记录科目名称（取末级名称中最长的那个，包含下划线分隔）
        if len(name) > len(result[level2]['name']):
            result[level2]['name'] = name
    
    # 费用科目金额 = 借方发生额（这是费用科目的正常发生方向）
    out = {}
    for code, info in sorted(result.items()):
        out[code] = {
            'name': info['name'],
            'debit': info['debit'],
            'credit': info['credit'],
            'amount': info['debit'],  # 费用=借方发生额
            'details': info['details']
        }
    return out

# 科目名称映射
CODE_NAMES = {
    '6601': '销售费用',
    '6601.01': '销售费用_职工薪酬',
    '6601.02': '销售费用_福利费',
    '6601.03': '销售费用_社保',
    '6601.05': '销售费用_折旧',
    '6601.07': '销售费用_差旅费',
    '6601.08': '销售费用_交通费',
    '6601.09': '销售费用_办公费',
    '6601.11': '销售费用_广告宣传费',
    '6601.12': '销售费用_业务招待费',
    '6601.13': '销售费用_服务费',
    '6601.14': '销售费用_咨询服务费',
    '6601.15': '销售费用_其他',
    '6601.16': '销售费用_维修费',
    '6601.17': '销售费用_折旧摊销',
    '6601.18': '销售费用_邮寄费',
    '6601.19': '销售费用_通讯费',
    '6601.21': '销售费用_培训费',
    '6601.22': '销售费用_招聘费',
    '6601.23': '销售费用_团建',
    '6601.24': '销售费用_保险费',
    '6601.25': '销售费用_车辆费',
}

def get_name(code, data):
    if code in CODE_NAMES:
        return CODE_NAMES[code]
    if code in data and data[code]['name']:
        return data[code]['name']
    return code

# 加载数据
data_09 = load_period_data('2025-09')
data_08 = load_period_data('2025-08')
exp_09 = summarize(data_09)
exp_08 = summarize(data_08)

total_09 = sum(v['amount'] for v in exp_09.values())
total_08 = sum(v['amount'] for v in exp_08.values())
total_chg = total_09 - total_08
total_rate = (total_chg / total_08 * 100) if total_08 > 0 else 0

print("=" * 110)
print("  金融服务账套 | 销售费用波动分析报告")
print("  对比期间: 2025年9月 vs 2025年8月 | 结转损益已排除")
print("  计算口径: 费用 = 借方发生额合计（不含结转损益贷方分录）")
print("=" * 110)
print()
print(f"  销售费用总计: 8月 {total_08:>14,.2f}  |  9月 {total_09:>14,.2f}  |  变动 {total_chg:>+14,.2f}  |  波动 {total_rate:+.1f}%")
print()

# 二级科目明细
print("=" * 110)
print("  二级科目明细对比")
print("=" * 110)
print(f"  {'科目编码':<12} {'科目名称':<24} {'8月金额':>14} {'9月金额':>14} {'变动额':>14} {'波动率':>10} {'状态':<10}")
print(f"  {'-'*100}")

all_codes = sorted(set(list(exp_08.keys()) + list(exp_09.keys())))
anomalies = []

for code in all_codes:
    name = get_name(code, exp_09 if code in exp_09 else exp_08)
    amt_08 = exp_08.get(code, {}).get('amount', 0)
    amt_09 = exp_09.get(code, {}).get('amount', 0)
    change = amt_09 - amt_08
    
    if amt_08 > 1:
        rate = (change / amt_08) * 100
    elif amt_09 > 1:
        rate = float('inf')
    else:
        rate = 0
    
    if amt_08 < 1 and amt_09 < 1:
        status = '--'
        rate_str = '--'
    elif amt_08 < 1 and amt_09 > 1:
        status = '!! 新增'
        rate_str = '新增'
        anomalies.append({'code': code, 'name': name, 'a08': amt_08, 'a09': amt_09, 'chg': change, 'rate': rate, 'status': status})
    elif amt_09 < 1 and amt_08 > 1:
        status = '!! 消失'
        rate_str = '消失'
        anomalies.append({'code': code, 'name': name, 'a08': amt_08, 'a09': amt_09, 'chg': change, 'rate': rate, 'status': status})
    elif abs(rate) >= 50:
        status = '!! 异常'
        rate_str = f'{rate:+.1f}%'
        anomalies.append({'code': code, 'name': name, 'a08': amt_08, 'a09': amt_09, 'chg': change, 'rate': rate, 'status': status})
    elif abs(rate) >= 30:
        status = '! 预警'
        rate_str = f'{rate:+.1f}%'
    elif abs(rate) >= 10:
        status = '关注'
        rate_str = f'{rate:+.1f}%'
    else:
        status = '正常'
        rate_str = f'{rate:+.1f}%'
    
    print(f"  {code:<12} {name:<24} {amt_08:>14,.2f} {amt_09:>14,.2f} {change:>+14,.2f} {rate_str:>10} {status:<10}")

print(f"  {'-'*100}")
print(f"  {'合计':<12} {'销售费用':<24} {total_08:>14,.2f} {total_09:>14,.2f} {total_chg:>+14,.2f} {total_rate:>+9.1f}%")
print()

# 异常科目下钻
if anomalies:
    print("=" * 110)
    print("  异常科目下钻分析")
    print("=" * 110)
    
    for a in sorted(anomalies, key=lambda x: -abs(x['chg'])):
        print()
        print(f"  >> [{a['status']}] {a['code']} - {a['name']}")
        print(f"     8月: {a['a08']:,.2f}  ->  9月: {a['a09']:,.2f}  |  变动: {a['chg']:+,.2f}")
        
        # 9月明细下钻
        details_09 = exp_09.get(a['code'], {}).get('details', [])
        details_08 = exp_08.get(a['code'], {}).get('details', [])
        
        # 按摘要归类9月
        if details_09:
            sg_09 = defaultdict(lambda: {'amount': 0.0, 'count': 0})
            for d in details_09:
                sm = d['summary'][:40]
                sg_09[sm]['amount'] += d['amount']
                sg_09[sm]['count'] += 1
            top_09 = sorted(sg_09.items(), key=lambda x: -x[1]['amount'])[:6]
            print(f"     --- 2025-09 借方发生 Top {len(top_09)} ---")
            for sm, info in top_09:
                print(f"       {info['amount']:>12,.2f} ({info['count']:>2}笔) | {sm}")
        
        # 按摘要归类8月
        if details_08:
            sg_08 = defaultdict(lambda: {'amount': 0.0, 'count': 0})
            for d in details_08:
                sm = d['summary'][:40]
                sg_08[sm]['amount'] += d['amount']
                sg_08[sm]['count'] += 1
            top_08 = sorted(sg_08.items(), key=lambda x: -x[1]['amount'])[:6]
            print(f"     --- 2025-08 借方发生 Top {len(top_08)} ---")
            for sm, info in top_08:
                print(f"       {info['amount']:>12,.2f} ({info['count']:>2}笔) | {sm}")

print()
print("=" * 110)
print("  分析完成")
print("=" * 110)

conn.close()
