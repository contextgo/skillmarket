#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""验证修复后数据：核对金融服务 2025-09 销售费用各科目"""

import sqlite3, os

db_path = os.path.join(os.path.expanduser('~'), '.workbuddy', 'month_end_check', 'month_end_check.db')
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row

BOOK_CODE = 'BK_64007EF1'
PERIOD = '2025-09'

# 1. 金融服务 9月总行数
total = conn.execute(
    "SELECT COUNT(*) FROM detail_ledger WHERE book_code=? AND period=?",
    (BOOK_CODE, PERIOD)
).fetchone()[0]
print(f'金融服务 2025-09 总行数: {total}')

# 2. 排除结转损益后的费用汇总
print('\n=== 排除结转损益后，6601 销售费用各科目借方汇总 ===')

cur = conn.execute('''
    SELECT 
        SUBSTR(account_code, 1, 8) AS code_2,
        MAX(CASE WHEN LENGTH(account_code) > 4 THEN 
            SUBSTR(account_code, 1, INSTR(SUBSTR(account_code, 5), '.') + 4) 
            ELSE account_code END) AS display_code,
        account_name,
        SUM(CASE WHEN summary NOT LIKE '%结转本期损益%' THEN debit_amount ELSE 0 END) AS debit_total,
        COUNT(*) AS cnt
    FROM detail_ledger
    WHERE book_code = ? AND period = ? AND account_code LIKE '6601%'
    GROUP BY SUBSTR(account_code, 1, 8)
    ORDER BY debit_total DESC
''', (BOOK_CODE, PERIOD))

grand_total = 0
print(f'{"科目":<20} {"借方发生额":>14} {"行数":>6}')
print('-' * 44)
for r in cur.fetchall():
    debit = r['debit_total']
    grand_total += debit
    print(f'{r["code_2"]:<20} {debit:>14,.2f} {r["cnt"]:>6}')

print('-' * 44)
print(f'{"合计":<20} {grand_total:>14,.2f}')

# 3. 对比 6601.01.01 工资科目
print('\n=== 6601.01.01 工资科目明细 ===')
cur = conn.execute('''
    SELECT voucher_no, account_name, summary, debit_amount, credit_amount
    FROM detail_ledger
    WHERE book_code = ? AND period = ? AND account_code = '6601.01.01'
    ORDER BY voucher_no
''', (BOOK_CODE, PERIOD))
total_debit = 0
for r in cur.fetchall():
    debit = r['debit_amount'] or 0
    credit = r['credit_amount'] or 0
    total_debit += debit
    print(f'  凭证{r["voucher_no"]:<8} {str(r["account_name"])[:16]:<18} 借方={debit:>12,.2f}  贷方={credit:>12,.2f}')
print(f'  借方合计: {total_debit:,.2f}')
print(f'  期望值:   1,528,116.13')

conn.close()
