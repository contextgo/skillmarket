#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""费用波动分析 - 金融服务 2025年9月 vs 8月"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from db_manager import get_db_manager
from collections import defaultdict

db = get_db_manager()
book_code = 'BK_64007EF1'

# 查询两个期间的明细账
data_09 = db.get_detail_ledger(book_code, '2025-09')
data_08 = db.get_detail_ledger(book_code, '2025-08')

print(f"2025-09 明细账行数: {len(data_09)}")
print(f"2025-08 明细账行数: {len(data_08)}")

# 提取费用类科目（6开头）的发生额汇总
def summarize_expenses(data, period_label):
    """汇总费用类科目的借方发生额"""
    expenses = defaultdict(lambda: {'debit': 0.0, 'credit': 0.0, 'name': ''})
    for row in data:
        code = row.get('account_code', '')
        name = row.get('account_name', '')
        # 费用类科目以6开头
        if code.startswith('6'):
            # 取一级科目
            level1_code = code.split('.')[0]
            expenses[level1_code]['debit'] += float(row.get('debit_amount', 0) or 0)
            expenses[level1_code]['credit'] += float(row.get('credit_amount', 0) or 0)
            if name and not expenses[level1_code]['name']:
                expenses[level1_code]['name'] = name.split('_')[0] if '_' in name else name
    
    print(f"\n{'='*80}")
    print(f"  {period_label} 费用科目汇总（一级科目）")
    print(f"{'='*80}")
    
    result = {}
    for code in sorted(expenses.keys()):
        info = expenses[code]
        net = info['debit'] - info['credit']
        result[code] = {'name': info['name'], 'debit': info['debit'], 'credit': info['credit'], 'net': net}
        print(f"  {code:<8} {info['name']:<20} 借方:{info['debit']:>15,.2f}  贷方:{info['credit']:>15,.2f}  净额:{net:>15,.2f}")
    
    print(f"{'='*80}")
    return result

exp_09 = summarize_expenses(data_09, "2025年9月")
exp_08 = summarize_expenses(data_08, "2025年8月")

# 波动对比分析
print(f"\n{'='*90}")
print(f"  费用波动分析: 2025年9月 vs 8月")
print(f"{'='*90}")
print(f"{'科目编码':<10} {'科目名称':<22} {'8月净额':>16} {'9月净额':>16} {'变动额':>16} {'波动率':>10} {'状态':<8}")
print(f"{'-'*90}")

anomalies = []
all_codes = sorted(set(list(exp_09.keys()) + list(exp_08.keys())))

for code in all_codes:
    name_08 = exp_08.get(code, {}).get('name', exp_09.get(code, {}).get('name', ''))
    net_08 = abs(exp_08.get(code, {}).get('net', 0))
    net_09 = abs(exp_09.get(code, {}).get('net', 0))
    
    change = net_09 - net_08
    
    if net_08 > 0:
        rate = (change / net_08) * 100
    elif net_09 > 0:
        rate = float('inf')  # 新增科目
    else:
        rate = 0
    
    # 状态判定
    if net_08 == 0 and net_09 == 0:
        status = '--'
        rate_display = '--'
    elif net_08 == 0 and net_09 > 0:
        status = '!! 新增'
        rate_display = '新增'
        anomalies.append({'code': code, 'name': name_08, 'net_08': net_08, 'net_09': net_09, 'change': change, 'rate': rate, 'status': status})
    elif net_09 == 0 and net_08 > 0:
        status = '!! 消失'
        rate_display = '消失'
        anomalies.append({'code': code, 'name': name_08, 'net_08': net_08, 'net_09': net_09, 'change': change, 'rate': rate, 'status': status})
    elif abs(rate) >= 50:
        status = '!! 异常'
        rate_display = f'{rate:+.1f}%'
        anomalies.append({'code': code, 'name': name_08, 'net_08': net_08, 'net_09': net_09, 'change': change, 'rate': rate, 'status': status})
    elif abs(rate) >= 30:
        status = '! 预警'
        rate_display = f'{rate:+.1f}%'
    elif abs(rate) >= 10:
        status = '关注'
        rate_display = f'{rate:+.1f}%'
    else:
        status = '正常'
        rate_display = f'{rate:+.1f}%'
    
    print(f"{code:<10} {name_08:<22} {net_08:>16,.2f} {net_09:>16,.2f} {change:>+16,.2f} {rate_display:>10} {status:<8}")

print(f"{'-'*90}")

# 合计
total_08 = sum(abs(v.get('net', 0)) for v in exp_08.values())
total_09 = sum(abs(v.get('net', 0)) for v in exp_09.values())
total_change = total_09 - total_08
total_rate = (total_change / total_08 * 100) if total_08 > 0 else 0
print(f"{'合  计':<32} {total_08:>16,.2f} {total_09:>16,.2f} {total_change:>+16,.2f} {total_rate:>+9.1f}%")

# 异常明细
if anomalies:
    print(f"\n{'='*90}")
    print(f"  异常科目明细（波动>=50% 或 新增/消失）")
    print(f"{'='*90}")
    for a in anomalies:
        print(f"\n  [{a['status']}] {a['code']} - {a['name']}")
        print(f"    8月: {a['net_08']:,.2f}  ->  9月: {a['net_09']:,.2f}  变动: {a['change']:+,.2f}  ({a['rate']:+.1f}%)")
        
        # 查看具体凭证明细
        period = '2025-09' if a['net_09'] > 0 else '2025-08'
        detail = db.get_detail_ledger(book_code, period)
        level1 = a['code'].split('.')[0]
        matching = [d for d in detail if d.get('account_code', '').startswith(level1)]
        
        if matching:
            print(f"    --- {period} 明细（前10条）---")
            for d in matching[:10]:
                debit = float(d.get('debit_amount', 0) or 0)
                credit = float(d.get('credit_amount', 0) or 0)
                if debit > 0 or credit > 0:
                    summary = d.get('summary', '')[:40]
                    print(f"    {d['voucher_date']} {d['voucher_no']:<6} {d['account_code']:<16} 借:{debit:>12,.2f} 贷:{credit:>12,.2f} | {summary}")
            if len(matching) > 10:
                print(f"    ... 共 {len(matching)} 条记录")

print(f"\n分析完成。")
