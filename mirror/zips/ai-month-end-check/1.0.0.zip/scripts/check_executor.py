#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI月结智能检查 - 检查执行与结果输出模块
处理检查流程、结果生成、交互查询
"""

import json
import pandas as pd
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path

# 导入其他模块
from db_manager import get_db_manager, DatabaseManager
from rule_engine import get_rule_engine, RuleEngine, CheckStatus


class CheckExecutor:
    """检查执行器"""
    
    def __init__(self):
        self.db = get_db_manager()
        self.engine = get_rule_engine()
    
    def run_month_end_check(self, book_code: str, book_name: str, 
                           period: str, rule_ids: Optional[List[int]] = None) -> Dict:
        """
        执行月结检查
        
        Args:
            book_code: 账套编码
            book_name: 账套名称
            period: 会计期间 (YYYY-MM)
            rule_ids: 指定规则ID列表（None则执行所有生效规则）
        
        Returns:
            检查结果字典
        """
        # 前置检查
        if not self.db.check_has_data(book_code, period):
            return {
                'success': False,
                'message': f'账套 {book_name} 在 {period} 期间暂无数据，请先导入财务数据',
                'session_id': None,
                'results': []
            }
        
        if not self.db.check_has_rules():
            return {
                'success': False,
                'message': '当前尚未建立月结检查规则库，请您先创建并配置对应的账务核查规则、绑定适用账套后，再启动智能检查',
                'session_id': None,
                'results': [],
                'needs_init': True
            }
        
        # 执行检查
        session_id, results = self.engine.execute_check(book_code, book_name, period, rule_ids)
        
        # 统计结果
        stats = self._calculate_stats(results)
        
        return {
            'success': True,
            'message': f'月结检查完成，共执行 {len(results)} 条规则',
            'session_id': session_id,
            'book_name': book_name,
            'period': period,
            'stats': stats,
            'results': [self._result_to_dict(r) for r in results]
        }
    
    def _calculate_stats(self, results: List[Any]) -> Dict:
        """计算检查结果统计"""
        stats = {
            'total': len(results),
            'pass': 0,
            'fail': 0,
            'warning': 0,
            'skip': 0
        }
        
        for r in results:
            if r.status == CheckStatus.PASS:
                stats['pass'] += 1
            elif r.status == CheckStatus.FAIL:
                stats['fail'] += 1
            elif r.status == CheckStatus.WARNING:
                stats['warning'] += 1
            elif r.status == CheckStatus.SKIP:
                stats['skip'] += 1
        
        return stats
    
    def _result_to_dict(self, result: Any) -> Dict:
        """转换结果为字典"""
        return {
            'rule_id': result.rule_id,
            'rule_name': result.rule_name,
            'status': result.status.value,
            'status_text': self._get_status_text(result.status),
            'message': result.message,
            'details': result.details
        }
    
    def _get_status_text(self, status: CheckStatus) -> str:
        """获取状态中文文本"""
        status_map = {
            CheckStatus.PASS: '✅ 通过',
            CheckStatus.FAIL: '❌ 异常',
            CheckStatus.WARNING: '⚠️ 警告',
            CheckStatus.SKIP: '⏭️ 跳过'
        }
        return status_map.get(status, str(status))
    
    def get_check_report(self, session_id: str) -> Optional[Dict]:
        """
        获取检查报告
        
        Args:
            session_id: 检查会话ID
        
        Returns:
            检查报告字典
        """
        results = self.db.get_check_results(session_id)
        
        if not results:
            return None
        
        # 解析详情
        for r in results:
            if r.get('details'):
                try:
                    r['details_parsed'] = json.loads(r['details'])
                except:
                    r['details_parsed'] = {}
        
        # 统计
        stats = {
            'total': len(results),
            'pass': sum(1 for r in results if r['check_status'] == 'pass'),
            'fail': sum(1 for r in results if r['check_status'] == 'fail'),
            'warning': sum(1 for r in results if r['check_status'] == 'warning'),
            'skip': sum(1 for r in results if r['check_status'] == 'skip')
        }
        
        return {
            'session_id': session_id,
            'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'stats': stats,
            'results': results
        }
    
    def export_check_list(self, session_id: str, output_path: str) -> Tuple[bool, str]:
        """
        导出检查清单为Excel
        
        Args:
            session_id: 检查会话ID
            output_path: 输出文件路径
        
        Returns:
            (成功状态, 消息)
        """
        try:
            report = self.get_check_report(session_id)
            
            if not report:
                return False, "检查会话不存在"
            
            # 准备数据
            rows = []
            for r in report['results']:
                status_text = {
                    'pass': '合规',
                    'fail': '异常',
                    'warning': '预警',
                    'skip': '跳过'
                }.get(r['check_status'], r['check_status'])
                
                rows.append({
                    '规则编号': r['rule_id'],
                    '规则名称': r['rule_name'],
                    '检查状态': status_text,
                    '检查信息': r['check_message'],
                    '检查时间': r['created_at']
                })
            
            df = pd.DataFrame(rows)
            
            # 保存Excel
            df.to_excel(output_path, index=False, sheet_name='月结检查清单')
            
            return True, f"检查清单已导出到: {output_path}"
        
        except Exception as e:
            return False, f"导出失败: {str(e)}"
    
    def query_by_natural_language(self, query: str, book_code: Optional[str] = None,
                                   period: Optional[str] = None) -> Dict:
        """
        自然语言查询
        
        Args:
            query: 查询语句
            book_code: 账套编码（可选）
            period: 会计期间（可选）
        
        Returns:
            查询结果
        """
        query_lower = query.lower()
        
        # 规则相关查询
        if '规则' in query or 'rule' in query:
            return self._query_rules(query_lower)
        
        # 检查结果相关
        if '检查' in query or '结果' in query or '报告' in query:
            return self._query_results(query_lower, book_code, period)
        
        # 数据相关
        if '科目' in query or '余额' in query or '明细' in query:
            return self._query_data(query_lower, book_code, period)
        
        # 统计相关
        if '统计' in query or '汇总' in query or '多少' in query:
            return self._query_stats(query_lower, book_code, period)
        
        # 默认返回帮助信息
        return {
            'type': 'help',
            'message': '''支持的查询类型：
1. 规则查询："查看所有规则"、"有哪些生效规则"、"XX规则的适用账套是什么"
2. 检查结果："查看最近的检查结果"、"XX账套的月结检查报告"
3. 数据查询："XX科目的余额"、"查看明细账"
4. 统计查询："检查通过率"、"有多少个异常项"'''
        }
    
    def _query_rules(self, query: str) -> Dict:
        """查询规则"""
        if '全部' in query or '所有' in query or 'list' in query:
            rules = self.db.get_rules()
            return {
                'type': 'rules',
                'message': f'共有 {len(rules)} 条规则',
                'data': rules
            }
        
        if '生效' in query or 'active' in query:
            rules = self.db.get_rules(active_only=True)
            return {
                'type': 'rules',
                'message': f'共有 {len(rules)} 条生效规则',
                'data': rules
            }
        
        # 其他规则查询...
        rules = self.db.get_rules()
        return {
            'type': 'rules',
            'message': f'找到 {len(rules)} 条规则',
            'data': rules[:10]  # 只返回前10条
        }
    
    def _query_results(self, query: str, book_code: Optional[str],
                      period: Optional[str]) -> Dict:
        """查询检查结果"""
        # 这里简化实现，实际应该查询数据库
        return {
            'type': 'results',
            'message': '请提供检查会话ID以查看详细结果',
            'data': []
        }
    
    def _query_data(self, query: str, book_code: Optional[str],
                   period: Optional[str]) -> Dict:
        """查询数据"""
        if not book_code or not period:
            return {
                'type': 'error',
                'message': '查询数据需要指定账套和期间'
            }
        
        # 提取科目编码
        import re
        account_codes = re.findall(r'\d{4}(?:\.\d+)*', query)
        
        if account_codes:
            code = account_codes[0]
            balances = self.db.get_account_balances(book_code, period, code)
            return {
                'type': 'data',
                'message': f'科目 {code} 余额信息',
                'data': balances
            }
        
        return {
            'type': 'data',
            'message': '请指定具体的科目编码进行查询'
        }
    
    def _query_stats(self, query: str, book_code: Optional[str],
                    period: Optional[str]) -> Dict:
        """查询统计"""
        return {
            'type': 'stats',
            'message': '统计功能开发中...',
            'data': {}
        }
    
    def generate_check_list_table(self, session_id: str) -> str:
        """
        生成检查清单表格（Markdown格式）
        
        Args:
            session_id: 检查会话ID
        
        Returns:
            Markdown格式表格
        """
        report = self.get_check_report(session_id)
        
        if not report:
            return "未找到检查记录"
        
        lines = [
            f"## 月结检查清单",
            f"",
            f"**账套**: {report['results'][0].get('book_code', 'N/A')}  ",
            f"**期间**: {report['results'][0].get('period', 'N/A')}  ",
            f"**生成时间**: {report['generated_at']}  ",
            f"",
            f"### 检查统计",
            f"",
            f"- ✅ 通过: {report['stats']['pass']} 项",
            f"- ❌ 异常: {report['stats']['fail']} 项",
            f"- ⚠️ 警告: {report['stats']['warning']} 项",
            f"- ⏭️ 跳过: {report['stats']['skip']} 项",
            f"- 总计: {report['stats']['total']} 项",
            f"",
            f"### 详细结果",
            f"",
            f"| 规则名称 | 检查状态 | 检查信息 | 详情 |",
            f"|----------|----------|----------|------|"
        ]
        
        for r in report['results']:
            status = {
                'pass': '✅ 通过',
                'fail': '❌ 异常',
                'warning': '⚠️ 警告',
                'skip': '⏭️ 跳过'
            }.get(r['check_status'], r['check_status'])
            
            # 简化详情展示
            details = r.get('details_parsed', {})
            detail_str = str(details)[:50] + "..." if len(str(details)) > 50 else str(details)
            
            lines.append(f"| {r['rule_name']} | {status} | {r['check_message']} | {detail_str} |")
        
        return '\n'.join(lines)


# 单例
_executor = None

def get_executor() -> CheckExecutor:
    """获取检查执行器单例"""
    global _executor
    if _executor is None:
        _executor = CheckExecutor()
    return _executor


if __name__ == '__main__':
    # 测试代码
    executor = CheckExecutor()
    print("检查执行器初始化完成")
