#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI月结智能检查 - 主程序入口
提供命令行和API接口
"""

import os
import sys
import json
import argparse
from typing import Optional, List

# 确保当前目录在路径中
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from db_manager import get_db_manager, CheckRule
from data_importer import get_importer
from rule_engine import get_rule_engine
from check_executor import get_executor


def init_rules():
    """初始化预置规则"""
    db = get_db_manager()
    success, message = db.init_preset_rules()
    print(message)
    return success


def import_data(file_path: str, data_type: str, book_code: str,
                book_name: str, period: str, **kwargs):
    """导入数据"""
    importer = get_importer()
    success, message = importer.import_file(
        file_path, data_type, book_code, book_name, period, **kwargs
    )
    print(message)
    return success


def preview_file(file_path: str):
    """预览文件"""
    importer = get_importer()
    success, result = importer.preview_file(file_path)
    
    if success:
        print(f"文件类型: {result['file_type']}")
        print(f"数据行数: {result['row_count']}")
        print(f"建议数据类型: {result['suggested_data_type']}")
        print(f"列名: {', '.join(result['columns'])}")
        print("\n预览数据:")
        print(json.dumps(result['preview'], ensure_ascii=False, indent=2))
    else:
        print(f"预览失败: {result}")


def run_check(book_code: str, book_name: str, period: str, 
              rule_ids: Optional[List[int]] = None):
    """执行检查"""
    executor = get_executor()
    result = executor.run_month_end_check(book_code, book_name, period, rule_ids)
    
    if not result['success']:
        print(f"❌ {result['message']}")
        if result.get('needs_init'):
            print("\n提示: 您可以通过以下命令初始化预置规则:")
            print("  python main.py init-rules")
        return False
    
    print(f"✅ {result['message']}")
    print(f"\n检查会话ID: {result['session_id']}")
    
    # 输出统计
    stats = result['stats']
    print(f"\n检查结果统计:")
    print(f"  ✅ 通过: {stats['pass']} 项")
    print(f"  ❌ 异常: {stats['fail']} 项")
    print(f"  ⚠️ 警告: {stats['warning']} 项")
    print(f"  ⏭️ 跳过: {stats['skip']} 项")
    
    # 输出详细结果
    if result['results']:
        print(f"\n详细结果:")
        for r in result['results']:
            print(f"\n{r['status_text']} {r['rule_name']}")
            print(f"   {r['message']}")
    
    return True


def show_report(session_id: str):
    """显示检查报告"""
    executor = get_executor()
    report = executor.get_check_report(session_id)
    
    if not report:
        print("未找到检查记录")
        return
    
    print(executor.generate_check_list_table(session_id))


def export_report(session_id: str, output_path: str):
    """导出报告"""
    executor = get_executor()
    success, message = executor.export_check_list(session_id, output_path)
    print(message)


def list_rules(active_only: bool = False):
    """列出规则"""
    db = get_db_manager()
    rules = db.get_rules(active_only=active_only)
    
    print(f"共 {len(rules)} 条规则:\n")
    print(f"{'ID':<5} {'规则名称':<30} {'类型':<20} {'适用账套':<15} {'状态':<6}")
    print("-" * 80)
    
    for rule in rules:
        status = "生效" if rule['is_active'] else "停用"
        applicable = rule['applicable_books'][:12] + "..." if len(rule['applicable_books']) > 15 else rule['applicable_books']
        rule_type = rule['rule_type'][:17] + "..." if len(rule['rule_type']) > 20 else rule['rule_type']
        name = rule['rule_name'][:27] + "..." if len(rule['rule_name']) > 30 else rule['rule_name']
        
        print(f"{rule['rule_id']:<5} {name:<30} {rule_type:<20} {applicable:<15} {status:<6}")


def create_rule(name: str, content: str, rule_type: str = "custom",
                target_accounts: str = "", applicable_books: str = "all",
                threshold: Optional[float] = None):
    """创建规则"""
    db = get_db_manager()
    
    rule = CheckRule(
        rule_name=name,
        rule_content=content,
        rule_type=rule_type,
        target_accounts=target_accounts,
        applicable_books=applicable_books,
        threshold_value=threshold
    )
    
    success, message, rule_id = db.create_rule(rule)
    print(message)
    if success:
        print(f"规则ID: {rule_id}")
    return success


def delete_rule(rule_id: int):
    """删除规则"""
    db = get_db_manager()
    success, message = db.delete_rule(rule_id)
    print(message)
    return success


def query(query_text: str, book_code: Optional[str] = None, period: Optional[str] = None):
    """自然语言查询"""
    executor = get_executor()
    result = executor.query_by_natural_language(query_text, book_code, period)
    
    print(result['message'])
    
    if result.get('data'):
        print("\n查询结果:")
        print(json.dumps(result['data'], ensure_ascii=False, indent=2))


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='AI月结智能检查系统')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # init-rules 命令
    subparsers.add_parser('init-rules', help='初始化预置规则')
    
    # preview 命令
    preview_parser = subparsers.add_parser('preview', help='预览文件')
    preview_parser.add_argument('file', help='文件路径')
    
    # import 命令
    import_parser = subparsers.add_parser('import', help='导入数据')
    import_parser.add_argument('file', help='文件路径')
    import_parser.add_argument('--type', required=True, choices=['account_balances', 'detail_ledger', 'financial_report'],
                              help='数据类型')
    import_parser.add_argument('--book-code', required=True, help='账套编码')
    import_parser.add_argument('--book-name', required=True, help='账套名称')
    import_parser.add_argument('--period', required=True, help='会计期间(YYYY-MM)')
    
    # check 命令
    check_parser = subparsers.add_parser('check', help='执行月结检查')
    check_parser.add_argument('--book-code', required=True, help='账套编码')
    check_parser.add_argument('--book-name', required=True, help='账套名称')
    check_parser.add_argument('--period', required=True, help='会计期间(YYYY-MM)')
    
    # report 命令
    report_parser = subparsers.add_parser('report', help='查看检查报告')
    report_parser.add_argument('--session', required=True, help='检查会话ID')
    
    # export 命令
    export_parser = subparsers.add_parser('export', help='导出检查报告')
    export_parser.add_argument('--session', required=True, help='检查会话ID')
    export_parser.add_argument('--output', required=True, help='输出文件路径')
    
    # rules 命令
    rules_parser = subparsers.add_parser('rules', help='列出规则')
    rules_parser.add_argument('--active', action='store_true', help='仅显示生效规则')
    
    # create-rule 命令
    create_parser = subparsers.add_parser('create-rule', help='创建规则')
    create_parser.add_argument('--name', required=True, help='规则名称')
    create_parser.add_argument('--content', required=True, help='规则内容')
    create_parser.add_argument('--type', default='custom', help='规则类型')
    create_parser.add_argument('--accounts', default='', help='目标科目(逗号分隔)')
    create_parser.add_argument('--books', default='all', help='适用账套(逗号分隔或all)')
    create_parser.add_argument('--threshold', type=float, help='阈值')
    
    # delete-rule 命令
    delete_parser = subparsers.add_parser('delete-rule', help='删除规则')
    delete_parser.add_argument('id', type=int, help='规则ID')
    
    # query 命令
    query_parser = subparsers.add_parser('query', help='自然语言查询')
    query_parser.add_argument('text', help='查询文本')
    query_parser.add_argument('--book-code', help='账套编码')
    query_parser.add_argument('--period', help='会计期间')
    
    args = parser.parse_args()
    
    if args.command == 'init-rules':
        init_rules()
    elif args.command == 'preview':
        preview_file(args.file)
    elif args.command == 'import':
        import_data(args.file, args.type, args.book_code, args.book_name, args.period)
    elif args.command == 'check':
        run_check(args.book_code, args.book_name, args.period)
    elif args.command == 'report':
        show_report(args.session)
    elif args.command == 'export':
        export_report(args.session, args.output)
    elif args.command == 'rules':
        list_rules(args.active)
    elif args.command == 'create-rule':
        create_rule(args.name, args.content, args.type, args.accounts, args.books, args.threshold)
    elif args.command == 'delete-rule':
        delete_rule(args.id)
    elif args.command == 'query':
        query(args.text, args.book_code, args.period)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
