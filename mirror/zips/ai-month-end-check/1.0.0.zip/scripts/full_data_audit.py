#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""全面评估唯一约束导致的数据丢失，并修复"""
import sqlite3, os, pandas as pd
from collections import defaultdict

db_path = os.path.join(os.path.expanduser('~'), '.workbuddy', 'month_end_check', 'month_end_check.db')
conn = sqlite3.connect(db_path)

BOOK_CODE = 'BK_64007EF1'

# 1. 从原始Excel统计每个(凭证号+科目+期间)组合有多少条
print("=" * 80)
print("  Step 1: 从原始Excel分析核算维度导致的重复")
print("=" * 80)

df = pd.read_excel(r'C:/Users/bianjing/Downloads/明细账.xlsx')

# 只看金融服务账套
df_fs = df[df['账簿'] == '金融服务'].copy()
print(f"  金融服务账套原始数据: {len(df_fs)} 行")

# 筛选2025年9月
df_09 = df_fs[(df_fs['会计年度'] == 2025) & (df_fs['期间'] == 9)].copy()
print(f"  2025年9月数据: {len(df_09)} 行")

# 按(凭证号+科目编码+日期)分组，看每组有多少条
groups = df_09.groupby(['凭证号', '科目编码', '日期']).size().reset_index(name='count')
multi_groups = groups[groups['count'] > 1]
print(f"  存在多核算维度的(凭证+科目+日期)组合: {len(multi_groups)} 组")

# 计算这些多核算维度组涉及的总行数
multi_total = multi_groups['count'].sum()
single_total = len(df_09) - multi_total
print(f"  多核算维度涉及总行数: {multi_total}")
print(f"  单条行数: {single_total}")
print()

# 2. 按科目汇总原始数据 vs 数据库数据
print("=" * 80)
print("  Step 2: 按科目编码对比（原始Excel vs 数据库）")
print("=" * 80)

# 原始Excel 2025-09 借方发生额（排除结转损益）
df_09_real = df_09[~df_09['摘要'].astype(str).str.contains('结转|损益', na=False)]
excel_summary = df_09_real.groupby('科目编码').agg(
    excel_debit=('借方金额', 'sum'),
    excel_count=('借方金额', 'count')
).reset_index()

# 数据库 2025-09 借方发生额（排除结转损益）
cur = conn.execute('''
    SELECT account_code, SUM(debit_amount) as db_debit, COUNT(*) as db_count
    FROM detail_ledger 
    WHERE book_code = ? AND period = '2025-09'
      AND summary NOT LIKE '%结转%' AND summary NOT LIKE '%损益%'
    GROUP BY account_code
''', (BOOK_CODE,))
db_rows = cur.fetchall()

db_summary = pd.DataFrame(db_rows, columns=['科目编码', 'db_debit', 'db_count'])

# 合并对比
merged = excel_summary.merge(db_summary, on='科目编码', how='outer').fillna(0)
merged['diff'] = merged['excel_debit'] - merged['db_debit']
merged['missing'] = merged['diff'].abs()

# 按差异金额排序，只显示有差异的
has_diff = merged[merged['missing'] > 0.01].sort_values('missing', ascending=False)

print(f"\n  {'科目编码':<15} {'Excel借方':>16} {'数据库借方':>16} {'差异':>16} {'说明':<20}")
print(f"  {'-'*85}")

total_excel = 0
total_db = 0
for _, row in has_diff.iterrows():
    code = row['科目编码']
    note = ''
    if row['excel_count'] > row['db_count'] and row['diff'] > 0:
        missing_rows = int(row['excel_count'] - row['db_count'])
        note = f'缺失{missing_rows}条'
    elif row['db_count'] > row['excel_count']:
        note = '数据库多出'
    elif abs(row['diff']) > 0.01:
        note = '金额不匹配'
    
    total_excel += row['excel_debit']
    total_db += row['db_debit']
    print(f"  {str(code):<15} {row['excel_debit']:>16,.2f} {row['db_debit']:>16,.2f} {row['diff']:>+16,.2f} {note:<20}")

print(f"  {'-'*85}")
print(f"  {'差异合计':<15} {total_excel:>16,.2f} {total_db:>16,.2f} {total_excel-total_db:>+16,.2f}")

# 3. 统计数据库中缺失的总行数
print()
print("=" * 80)
print("  Step 3: 数据缺失统计")
print("=" * 80)

cur = conn.execute('''
    SELECT COUNT(*) FROM detail_ledger WHERE book_code = ? AND period = '2025-09'
''', (BOOK_CODE,))
db_total = cur.fetchone()[0]

missing_rows_total = len(df_09) - db_total
print(f"  Excel 2025-09 总行数: {len(df_09)}")
print(f"  数据库 2025-09 总行数: {db_total}")
print(f"  缺失行数: {missing_rows_total}")
print(f"  缺失比例: {missing_rows_total/len(df_09)*100:.1f}%")

# 如果需要修复
print()
print("=" * 80)
print("  修复建议")
print("=" * 80)
print(f"  唯一约束 (book_code, period, voucher_no, voucher_date, account_code)")
print(f"  不包含核算维度字段，导致同凭证不同核算维度的分录被跳过")
print(f"  需要将唯一约束修改为包含核算维度")
print(f"  或者删除现有数据重新导入")

conn.close()
