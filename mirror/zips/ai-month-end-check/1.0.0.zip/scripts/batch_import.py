#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量导入明细账 - 按账簿自动拆分，支持多年多期间
"""

import sys
import os
import re
import hashlib
import pandas as pd
from pathlib import Path
from datetime import datetime

# 添加脚本目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from db_manager import get_db_manager


def clean_dataframe(df):
    """清洗DataFrame"""
    df = df.dropna(how='all').dropna(axis=1, how='all')
    df.columns = [str(col).strip() if pd.notna(col) else '' for col in df.columns]
    return df


def parse_detail_ledger(df):
    """解析明细账行数据，保留 Excel 原始行序号作为 row_seq"""
    column_mapping = {
        'voucher_no': ['凭证号', '凭证编号', 'voucher_no'],
        'voucher_date': ['凭证日期', '日期', '业务日期', 'voucher_date'],
        'account_code': ['科目编码', '科目编号', '科目代码', 'account_code'],
        'account_name': ['科目名称', '科目', '科目全名', 'account_name'],
        'summary': ['摘要', '说明', 'summary'],
        'debit_amount': ['借方', '借方金额', '借方发生额', 'debit_amount'],
        'credit_amount': ['贷方', '贷方金额', '贷方发生额', 'credit_amount'],
    }

    mapped_columns = {}
    for standard_name, possible_names in column_mapping.items():
        for col in df.columns:
            if any(name in str(col) for name in possible_names):
                mapped_columns[standard_name] = col
                break

    result = []
    for idx, row in df.iterrows():
        item = {}
        # row_seq 使用 DataFrame 的原始索引（即 Excel 行号），确保每行唯一
        item['row_seq'] = int(idx) + 2  # +2 因为 Excel 第1行是表头，第2行开始是数据，pandas 0-indexed
        for standard_name, col_name in mapped_columns.items():
            value = row.get(col_name)
            if pd.isna(value):
                if standard_name in ['debit_amount', 'credit_amount']:
                    value = 0
                else:
                    value = ''

            # 日期格式处理
            if standard_name == 'voucher_date' and value:
                if isinstance(value, pd.Timestamp):
                    value = value.strftime('%Y-%m-%d')
                elif isinstance(value, str):
                    value = str(value)[:10]

            item[standard_name] = value
        result.append(item)

    return result


def generate_book_code(book_name):
    """根据账簿名称生成账套编码"""
    # 简化规则：取拼音首字母缩写或直接用hash
    name_clean = book_name.replace('分公司', '').replace('办事处', '').strip()
    # 使用md5前8位作为编码
    hash_code = hashlib.md5(book_name.encode('utf-8')).hexdigest()[:8].upper()
    return f"BK_{hash_code}"


def batch_import_detail_ledger(file_path):
    """批量导入明细账，按账簿拆分"""
    print(f"开始读取文件: {file_path}")
    df = pd.read_excel(file_path)
    df = clean_dataframe(df)

    print(f"总数据行数: {len(df)}")

    # 获取所有账簿
    books = df['账簿'].unique()
    print(f"发现 {len(books)} 个账簿\n")

    db = get_db_manager()
    total_inserted = 0
    total_skipped = 0
    total_rows = 0

    # 按账簿名称排序
    books_sorted = sorted(books, key=lambda x: df[df['账簿'] == x].shape[0], reverse=True)

    for i, book_name in enumerate(books_sorted, 1):
        book_df = df[df['账簿'] == book_name].copy()
        book_code = generate_book_code(book_name)
        total_rows += len(book_df)

        # 获取该账簿涉及的所有年度和期间
        book_df['会计年度'] = book_df['会计年度'].astype(int)
        book_df['期间'] = book_df['期间'].astype(int)
        periods = book_df['会计年度'].astype(str) + '-' + book_df['期间'].astype(str).str.zfill(2)
        unique_periods = sorted(periods.unique())

        print(f"[{i}/{len(books)}] {book_name} ({len(book_df)}行, {len(unique_periods)}个期间)")

        # 按期间逐个导入
        book_inserted = 0
        book_skipped = 0

        for period in unique_periods:
            period_df = book_df[periods == period]

            # 提取需要的列进行解析
            parse_cols = ['凭证号', '日期', '科目编码', '科目全名', '摘要', '借方金额', '贷方金额']
            available_cols = [c for c in parse_cols if c in period_df.columns]
            sub_df = period_df[available_cols].copy()

            try:
                data = parse_detail_ledger(sub_df)

                success, msg = db.import_detail_ledger(data, book_code, book_name, period)
                if success:
                    # 解析成功消息中的数字
                    match = re.search(r'成功导入 (\d+) 条，跳过重复 (\d+) 条', msg)
                    if match:
                        book_inserted += int(match.group(1))
                        book_skipped += int(match.group(2))
                    else:
                        book_inserted += len(data)
            except Exception as e:
                print(f"  [!] 期间 {period} 导入失败: {e}")

        print(f"  [OK] 导入 {book_inserted} 条, 跳过重复 {book_skipped} 条")
        total_inserted += book_inserted
        total_skipped += book_skipped

    print(f"\n{'='*60}")
    print(f"导入完成！")
    print(f"  总行数: {total_rows}")
    print(f"  成功导入: {total_inserted}")
    print(f"  跳过重复: {total_skipped}")
    print(f"  账簿数: {len(books)}")
    print(f"{'='*60}")

    # 输出账簿清单
    print(f"\n已导入账簿清单:")
    for book_name in books_sorted:
        book_code = generate_book_code(book_name)
        row_count = len(df[df['账簿'] == book_name])
        print(f"  {book_code} | {book_name} ({row_count}行)")


if __name__ == '__main__':
    file_path = sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\bianjing\Downloads\明细账.xlsx"
    batch_import_detail_ledger(file_path)
