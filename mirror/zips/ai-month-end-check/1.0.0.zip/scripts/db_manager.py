#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI月结智能检查 - 数据库管理模块
处理SQLite数据库创建、数据表管理、规则库管理、日志记录
"""

import sqlite3
import os
import json
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
from contextlib import contextmanager

@dataclass
class CheckRule:
    """检查规则数据类"""
    rule_id: Optional[int] = None
    rule_name: str = ""
    rule_content: str = ""
    rule_type: str = ""  # 'bank_reconciliation', 'asset_negative', 'accounting_equation', 'expense_fluctuation', 'completeness'
    target_accounts: str = ""  # 目标科目，逗号分隔
    threshold_value: Optional[float] = None  # 阈值（如费用波动百分比）
    applicable_books: str = "all"  # 适用账套范围，逗号分隔或'all'
    is_active: bool = True
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

@dataclass
class OperationLog:
    """操作日志数据类"""
    log_id: Optional[int] = None
    operation_type: str = ""  # 'data_import', 'rule_create', 'rule_update', 'rule_delete', 'check_execute'
    operation_detail: str = ""
    book_name: str = ""
    period: str = ""
    operator: str = "system"
    created_at: Optional[str] = None

class DatabaseManager:
    """数据库管理器"""
    
    def __init__(self, db_path: Optional[str] = None):
        """
        初始化数据库管理器
        
        Args:
            db_path: 数据库文件路径，默认为用户目录下的 .workbuddy/month_end_check/month_end_check.db
        """
        if db_path is None:
            # 默认数据库路径：用户目录下独立文件夹
            home_dir = Path.home()
            db_dir = home_dir / ".workbuddy" / "month_end_check"
            db_dir.mkdir(parents=True, exist_ok=True)
            db_path = db_dir / "month_end_check.db"
        
        self.db_path = str(db_path)
        self._init_database()
    
    @contextmanager
    def _get_connection(self):
        """获取数据库连接上下文管理器"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def _init_database(self):
        """初始化数据库表结构"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. 科目余额表 - 按账套和会计期间分区
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS account_balances (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    book_code TEXT NOT NULL,           -- 账套编码
                    book_name TEXT NOT NULL,           -- 账套名称
                    period TEXT NOT NULL,              -- 会计期间 (YYYY-MM)
                    account_code TEXT NOT NULL,        -- 科目编码
                    account_name TEXT NOT NULL,        -- 科目名称
                    account_level INTEGER,             -- 科目级次
                    parent_code TEXT,                  -- 上级科目编码
                    opening_debit REAL DEFAULT 0,      -- 期初借方余额
                    opening_credit REAL DEFAULT 0,     -- 期初贷方余额
                    current_debit REAL DEFAULT 0,      -- 本期借方发生额
                    current_credit REAL DEFAULT 0,     -- 本期贷方发生额
                    closing_debit REAL DEFAULT 0,      -- 期末借方余额
                    closing_credit REAL DEFAULT 0,     -- 期末贷方余额
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(book_code, period, account_code)
                )
            ''')
            
            # 2. 明细账表 - 按 Excel 行序号唯一性约束
            # 注意：同一凭证号+科目编码可能对应多个核算维度（如不同部门），
            # 因此唯一约束使用 row_seq（Excel 原始行序号）而非凭证维度组合
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS detail_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    book_code TEXT NOT NULL,           -- 账套编码
                    book_name TEXT NOT NULL,           -- 账套名称
                    period TEXT NOT NULL,              -- 会计期间
                    row_seq INTEGER NOT NULL,          -- Excel原始行序号（用于唯一标识，支持同凭证多核算维度）
                    voucher_no TEXT,                   -- 凭证号
                    voucher_date DATE,                 -- 凭证日期
                    account_code TEXT NOT NULL,        -- 科目编码
                    account_name TEXT,                 -- 科目名称
                    summary TEXT,                      -- 摘要
                    debit_amount REAL DEFAULT 0,       -- 借方金额
                    credit_amount REAL DEFAULT 0,      -- 贷方金额
                    direction TEXT,                    -- 余额方向
                    balance REAL DEFAULT 0,            -- 余额
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(book_code, period, row_seq)
                )
            ''')
            
            # 3. 财务报表表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS financial_reports (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    book_code TEXT NOT NULL,           -- 账套编码
                    book_name TEXT NOT NULL,           -- 账套名称
                    period TEXT NOT NULL,              -- 会计期间
                    report_type TEXT NOT NULL,         -- 报表类型: balance_sheet, income_statement, cash_flow
                    item_name TEXT NOT NULL,           -- 项目/科目名称
                    item_code TEXT,                    -- 项目编码
                    opening_amount REAL DEFAULT 0,     -- 期初金额
                    closing_amount REAL DEFAULT 0,     -- 期末金额
                    current_amount REAL DEFAULT 0,     -- 本期金额
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(book_code, period, report_type, item_code)
                )
            ''')
            
            # 4. 自定义台账表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS custom_ledgers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    book_code TEXT NOT NULL,           -- 账套编码
                    book_name TEXT NOT NULL,           -- 账套名称
                    period TEXT NOT NULL,              -- 会计期间
                    ledger_name TEXT NOT NULL,         -- 台账名称
                    custom_fields TEXT,                -- 自定义字段 (JSON格式)
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 5. 检查规则库表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS check_rules (
                    rule_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    rule_name TEXT NOT NULL,           -- 规则名称
                    rule_content TEXT NOT NULL,        -- 规则内容描述
                    rule_type TEXT NOT NULL,           -- 规则类型
                    target_accounts TEXT,              -- 目标科目
                    threshold_value REAL,              -- 阈值
                    applicable_books TEXT DEFAULT 'all', -- 适用账套范围
                    is_active BOOLEAN DEFAULT 1,       -- 是否生效
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 6. 操作日志表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS operation_logs (
                    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation_type TEXT NOT NULL,        -- 操作类型
                    operation_detail TEXT,             -- 操作详情
                    book_name TEXT,                    -- 相关账套
                    period TEXT,                       -- 相关期间
                    operator TEXT DEFAULT 'system',    -- 操作人
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 7. 检查结果表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS check_results (
                    result_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    check_session_id TEXT NOT NULL,    -- 检查会话ID
                    book_code TEXT NOT NULL,           -- 账套编码
                    period TEXT NOT NULL,              -- 会计期间
                    rule_id INTEGER,                   -- 规则ID
                    rule_name TEXT,                    -- 规则名称
                    check_status TEXT,                 -- 状态: pass, fail, warning
                    check_message TEXT,                -- 检查信息
                    details TEXT,                      -- 详细信息 (JSON)
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (rule_id) REFERENCES check_rules(rule_id)
                )
            ''')
            
            # 创建索引优化查询
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_balances_book_period ON account_balances(book_code, period)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_detail_book_period ON detail_ledger(book_code, period)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_report_book_period ON financial_reports(book_code, period)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_results_session ON check_results(check_session_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_rules_active ON check_rules(is_active)')
            
            conn.commit()
    
    # ==================== 数据导入方法 ====================
    
    def import_account_balances(self, data: List[Dict], book_code: str, book_name: str, period: str) -> Tuple[bool, str]:
        """
        导入科目余额表（同期间覆盖更新）
        
        Args:
            data: 科目余额数据列表
            book_code: 账套编码
            book_name: 账套名称
            period: 会计期间 (YYYY-MM)
        
        Returns:
            (成功状态, 消息)
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # 删除该账套该期间的旧数据
                cursor.execute(
                    'DELETE FROM account_balances WHERE book_code = ? AND period = ?',
                    (book_code, period)
                )
                
                # 插入新数据
                for item in data:
                    cursor.execute('''
                        INSERT INTO account_balances 
                        (book_code, book_name, period, account_code, account_name, account_level, 
                         parent_code, opening_debit, opening_credit, current_debit, current_credit,
                         closing_debit, closing_credit)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        book_code, book_name, period,
                        item.get('account_code'), item.get('account_name'), item.get('account_level'),
                        item.get('parent_code'), item.get('opening_debit', 0), item.get('opening_credit', 0),
                        item.get('current_debit', 0), item.get('current_credit', 0),
                        item.get('closing_debit', 0), item.get('closing_credit', 0)
                    ))
                
                # 记录日志
                self._log_operation(conn, 'data_import', 
                    f'导入科目余额表，共{len(data)}条记录', book_name, period)
                
                return True, f"成功导入 {len(data)} 条科目余额记录"
        
        except Exception as e:
            return False, f"导入失败: {str(e)}"
    
    def import_detail_ledger(self, data: List[Dict], book_code: str, book_name: str, period: str) -> Tuple[bool, str]:
        """
        导入明细账（强制防重复）
        
        Args:
            data: 明细账数据列表
            book_code: 账套编码
            book_name: 账套名称
            period: 会计期间
        
        Returns:
            (成功状态, 消息)
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                inserted = 0
                skipped = 0
                
                for item in data:
                    try:
                        cursor.execute('''
                            INSERT INTO detail_ledger 
                            (book_code, book_name, period, row_seq, voucher_no, voucher_date, account_code,
                             account_name, summary, debit_amount, credit_amount, direction, balance)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ''', (
                            book_code, book_name, period,
                            item.get('row_seq', 0),
                            item.get('voucher_no'), item.get('voucher_date'), item.get('account_code'),
                            item.get('account_name'), item.get('summary'), item.get('debit_amount', 0),
                            item.get('credit_amount', 0), item.get('direction'), item.get('balance', 0)
                        ))
                        inserted += 1
                    except sqlite3.IntegrityError:
                        # 重复记录（相同行序号），跳过
                        skipped += 1
                
                self._log_operation(conn, 'data_import',
                    f'导入明细账，成功{inserted}条，跳过重复{skipped}条', book_name, period)
                
                return True, f"成功导入 {inserted} 条，跳过重复 {skipped} 条"
        
        except Exception as e:
            return False, f"导入失败: {str(e)}"
    
    def import_financial_report(self, data: List[Dict], book_code: str, book_name: str, 
                                 period: str, report_type: str) -> Tuple[bool, str]:
        """
        导入财务报表（同期间覆盖更新）
        
        Args:
            data: 报表数据列表
            book_code: 账套编码
            book_name: 账套名称
            period: 会计期间
            report_type: 报表类型
        
        Returns:
            (成功状态, 消息)
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # 删除旧数据
                cursor.execute(
                    'DELETE FROM financial_reports WHERE book_code = ? AND period = ? AND report_type = ?',
                    (book_code, period, report_type)
                )
                
                for item in data:
                    cursor.execute('''
                        INSERT INTO financial_reports 
                        (book_code, book_name, period, report_type, item_name, item_code,
                         opening_amount, closing_amount, current_amount)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        book_code, book_name, period, report_type,
                        item.get('item_name'), item.get('item_code'),
                        item.get('opening_amount', 0), item.get('closing_amount', 0),
                        item.get('current_amount', 0)
                    ))
                
                self._log_operation(conn, 'data_import',
                    f'导入{report_type}报表，共{len(data)}条记录', book_name, period)
                
                return True, f"成功导入 {len(data)} 条报表记录"
        
        except Exception as e:
            return False, f"导入失败: {str(e)}"
    
    # ==================== 规则库管理方法 ====================
    
    def create_rule(self, rule: CheckRule) -> Tuple[bool, str, Optional[int]]:
        """
        创建检查规则
        
        Args:
            rule: 规则数据对象
        
        Returns:
            (成功状态, 消息, 规则ID)
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                cursor.execute('''
                    INSERT INTO check_rules 
                    (rule_name, rule_content, rule_type, target_accounts, threshold_value,
                     applicable_books, is_active, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    rule.rule_name, rule.rule_content, rule.rule_type, rule.target_accounts,
                    rule.threshold_value, rule.applicable_books, rule.is_active, now, now
                ))
                
                rule_id = cursor.lastrowid
                self._log_operation(conn, 'rule_create', 
                    f'创建规则: {rule.rule_name}', '', '')
                
                return True, "规则创建成功", rule_id
        
        except Exception as e:
            return False, f"创建失败: {str(e)}"
    
    def update_rule(self, rule_id: int, updates: Dict[str, Any]) -> Tuple[bool, str]:
        """
        更新检查规则
        
        Args:
            rule_id: 规则ID
            updates: 更新字段字典
        
        Returns:
            (成功状态, 消息)
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # 检查规则是否存在
                cursor.execute('SELECT rule_name FROM check_rules WHERE rule_id = ?', (rule_id,))
                if not cursor.fetchone():
                    return False, "规则不存在"
                
                # 构建更新SQL
                allowed_fields = ['rule_name', 'rule_content', 'rule_type', 'target_accounts',
                                  'threshold_value', 'applicable_books', 'is_active']
                
                set_clauses = []
                values = []
                
                for field, value in updates.items():
                    if field in allowed_fields:
                        set_clauses.append(f"{field} = ?")
                        values.append(value)
                
                if not set_clauses:
                    return False, "没有可更新的字段"
                
                set_clauses.append("updated_at = ?")
                values.append(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                values.append(rule_id)
                
                sql = f"UPDATE check_rules SET {', '.join(set_clauses)} WHERE rule_id = ?"
                cursor.execute(sql, values)
                
                self._log_operation(conn, 'rule_update',
                    f'更新规则ID: {rule_id}', '', '')
                
                return True, "规则更新成功"
        
        except Exception as e:
            return False, f"更新失败: {str(e)}"
    
    def delete_rule(self, rule_id: int) -> Tuple[bool, str]:
        """
        删除检查规则
        
        Args:
            rule_id: 规则ID
        
        Returns:
            (成功状态, 消息)
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('SELECT rule_name FROM check_rules WHERE rule_id = ?', (rule_id,))
                row = cursor.fetchone()
                if not row:
                    return False, "规则不存在"
                
                cursor.execute('DELETE FROM check_rules WHERE rule_id = ?', (rule_id,))
                
                self._log_operation(conn, 'rule_delete',
                    f'删除规则: {row["rule_name"]} (ID: {rule_id})', '', '')
                
                return True, "规则删除成功"
        
        except Exception as e:
            return False, f"删除失败: {str(e)}"
    
    def get_rules(self, active_only: bool = False, book_code: Optional[str] = None) -> List[Dict]:
        """
        获取规则列表
        
        Args:
            active_only: 仅返回生效规则
            book_code: 指定账套编码，返回适用于该账套的规则
        
        Returns:
            规则列表
        """
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            sql = 'SELECT * FROM check_rules WHERE 1=1'
            params = []
            
            if active_only:
                sql += ' AND is_active = 1'
            
            if book_code:
                sql += ' AND (applicable_books = ? OR applicable_books = "all" OR applicable_books LIKE ?)'
                params.extend([book_code, f'%{book_code}%'])
            
            sql += ' ORDER BY rule_id'
            
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            
            return [dict(row) for row in rows]
    
    def get_rule_by_id(self, rule_id: int) -> Optional[Dict]:
        """根据ID获取规则详情"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM check_rules WHERE rule_id = ?', (rule_id,))
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def init_preset_rules(self) -> Tuple[bool, str]:
        """
        初始化预置规则
        
        Returns:
            (成功状态, 消息)
        """
        preset_rules = [
            CheckRule(
                rule_name="银企对账规则",
                rule_content="各银行科目账面余额与实际银行账户余额完全核对一致",
                rule_type="bank_reconciliation",
                target_accounts="1002",  # 银行存款科目
                applicable_books="all"
            ),
            CheckRule(
                rule_name="资产类科目风控规则",
                rule_content="所有资产类科目余额不得为负数",
                rule_type="asset_negative",
                target_accounts="1001,1002,1012,1101,1121,1122,1131,1132,1221,1401,1403,1405,1408,1411,1471,1501,1503,1511,1521,1601,1602,1604,1605,1606,1611,1621,1622,1623,1624,1625,1626,1701,1702,1703,1711,1801,1811",
                applicable_books="all"
            ),
            CheckRule(
                rule_name="会计恒等式校验规则",
                rule_content="资产总额=负债总额+所有者权益总额",
                rule_type="accounting_equation",
                target_accounts="",
                applicable_books="all"
            ),
            CheckRule(
                rule_name="费用波动预警规则",
                rule_content="各项费用月度环比、同比波动超出自定义阈值（默认5%/10%），自动触发预警提示",
                rule_type="expense_fluctuation",
                target_accounts="6601,6602,6603",  # 销售费用、管理费用、财务费用
                threshold_value=10.0,  # 默认10%阈值
                applicable_books="all"
            ),
            CheckRule(
                rule_name="账务完整性核查规则",
                rule_content="智能识别科目漏记、少记、高频异常挂账、红字余额等账务问题",
                rule_type="completeness",
                target_accounts="",
                applicable_books="all"
            )
        ]
        
        created_count = 0
        for rule in preset_rules:
            success, _, _ = self.create_rule(rule)
            if success:
                created_count += 1
        
        return True, f"成功初始化 {created_count}/{len(preset_rules)} 条预置规则"
    
    # ==================== 数据查询方法 ====================
    
    def get_account_balances(self, book_code: str, period: str, 
                              account_code: Optional[str] = None) -> List[Dict]:
        """获取科目余额"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            sql = 'SELECT * FROM account_balances WHERE book_code = ? AND period = ?'
            params = [book_code, period]
            
            if account_code:
                sql += ' AND account_code = ?'
                params.append(account_code)
            
            cursor.execute(sql, params)
            return [dict(row) for row in cursor.fetchall()]
    
    def get_detail_ledger(self, book_code: str, period: str,
                           account_code: Optional[str] = None) -> List[Dict]:
        """获取明细账"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            sql = 'SELECT * FROM detail_ledger WHERE book_code = ? AND period = ? ORDER BY voucher_date, voucher_no'
            params = [book_code, period]
            
            if account_code:
                sql = 'SELECT * FROM detail_ledger WHERE book_code = ? AND period = ? AND account_code = ? ORDER BY voucher_date, voucher_no'
                params.append(account_code)
            
            cursor.execute(sql, params)
            return [dict(row) for row in cursor.fetchall()]
    
    def get_financial_report(self, book_code: str, period: str, 
                            report_type: str) -> List[Dict]:
        """获取财务报表"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM financial_reports 
                WHERE book_code = ? AND period = ? AND report_type = ?
            ''', (book_code, period, report_type))
            return [dict(row) for row in cursor.fetchall()]
    
    # ==================== 检查结果方法 ====================
    
    def save_check_result(self, session_id: str, book_code: str, period: str,
                          rule_id: int, rule_name: str, status: str, 
                          message: str, details: Dict) -> bool:
        """保存检查结果"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO check_results 
                    (check_session_id, book_code, period, rule_id, rule_name,
                     check_status, check_message, details)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (session_id, book_code, period, rule_id, rule_name,
                      status, message, json.dumps(details, ensure_ascii=False)))
                return True
        except Exception:
            return False
    
    def get_check_results(self, session_id: str) -> List[Dict]:
        """获取检查结果"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM check_results WHERE check_session_id = ? ORDER BY result_id
            ''', (session_id,))
            return [dict(row) for row in cursor.fetchall()]
    
    # ==================== 日志方法 ====================
    
    def _log_operation(self, conn: sqlite3.Connection, operation_type: str,
                       detail: str, book_name: str, period: str):
        """记录操作日志"""
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO operation_logs (operation_type, operation_detail, book_name, period, operator)
            VALUES (?, ?, ?, ?, ?)
        ''', (operation_type, detail, book_name, period, 'system'))
    
    def get_operation_logs(self, limit: int = 100) -> List[Dict]:
        """获取操作日志"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM operation_logs ORDER BY created_at DESC LIMIT ?
            ''', (limit,))
            return [dict(row) for row in cursor.fetchall()]
    
    # ==================== 工具方法 ====================
    
    def check_has_data(self, book_code: str, period: str) -> bool:
        """检查指定账套和期间是否有数据"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT COUNT(*) as cnt FROM account_balances WHERE book_code = ? AND period = ?
            ''', (book_code, period))
            return cursor.fetchone()['cnt'] > 0
    
    def check_has_rules(self) -> bool:
        """检查是否有生效的规则"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) as cnt FROM check_rules WHERE is_active = 1')
            return cursor.fetchone()['cnt'] > 0
    
    def get_all_books(self) -> List[str]:
        """获取所有账套名称"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT DISTINCT book_name FROM account_balances')
            return [row['book_name'] for row in cursor.fetchall()]
    
    def get_all_periods(self, book_code: str) -> List[str]:
        """获取指定账套的所有期间"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                'SELECT DISTINCT period FROM account_balances WHERE book_code = ? ORDER BY period DESC',
                (book_code,)
            )
            return [row['period'] for row in cursor.fetchall()]


# 单例模式
_db_manager = None

def get_db_manager(db_path: Optional[str] = None) -> DatabaseManager:
    """获取数据库管理器单例"""
    global _db_manager
    if _db_manager is None:
        _db_manager = DatabaseManager(db_path)
    return _db_manager


if __name__ == '__main__':
    # 测试代码
    db = DatabaseManager()
    print(f"数据库路径: {db.db_path}")
    
    # 初始化预置规则
    result = db.init_preset_rules()
    print(result)
    
    # 查看规则
    rules = db.get_rules()
    for rule in rules:
        print(f"- {rule['rule_name']}: {rule['rule_content']}")
