#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""费用波动分析V3 - 排除结转损益，聚焦真实业务费用"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from db_manager import get_db_manager
from collections import defaultdict

db = get_db_manager()
book_code = 'BK_64007EF1'

data_09 = db.get_detail_ledger(book_code, '2025-09')
data_08 = db.get_detail_ledger(book_code, '2025-08')

def get_level2_code(code):
    parts = code.split('.')
    return parts[0] if len(parts) < 2 else f"{parts[0]}.{parts[1]}"

def is_transfer_entry(summary):
    return '结转' in str(summary) or '损益' in str(summary)

def summarize_real_expenses(data, period_label):
    """按二级科目汇总，排除结转损益分录"""
    expenses = defaultdict(lambda: {'debit': 0.0, 'credit': 0.0, 'name': ''})
    for row in data:
        code = row.get('account_code', '')
        name = row.get('account_name', '')
        summary = row.get('summary', '')
        if not code.startswith('6'):
            continue
        if is_transfer_entry(summary):
            continue
        
        level2 = get_level2_code(code)
        expenses[level2]['debit'] += float(row.get('debit_amount', 0) or 0)
        expenses[level2]['credit'] += float(row.get('credit_amount', 0) or 0)
        if not expenses[level2]['name']:
            name_parts = name.split('_') if '_' in name else [name]
            expenses[level2]['name'] = name_parts[0] if len(name_parts) < 2 else f"{name_parts[0]}_{name_parts[1]}"
    
    result = {}
    for code in sorted(expenses.keys()):
        info = expenses[code]
        net = info['debit'] - info['credit']
        result[code] = {'name': info['name'], 'net': net}
    return result

exp_09 = summarize_real_expenses(data_09, "2025-09")
exp_08 = summarize_real_expenses(data_08, "2025-08")

# 科目名称映射
CODE_NAMES = {
    '6111': '公允价值变动损益', '6117': '资产处置损益',
    '6401': '主营业务成本', '6401.04': '主营业务成本_业务成本',
    '6405': '税金及附加',
    '6601': '销售费用', '6601.01': '销售费用_职工薪酬',
    '6601.02': '销售费用_福利费', '6601.03': '销售费用_社保',
    '6601.05': '销售费用_折旧', '6601.07': '销售费用_差旅费',
    '6601.08': '销售费用_交通费', '6601.09': '销售费用_办公费',
    '6601.11': '销售费用_广告宣传费', '6601.12': '销售费用_业务招待费',
    '6601.13': '销售费用_服务费', '6601.14': '销售费用_咨询服务费',
    '6601.15': '销售费用_其他', '6601.16': '销售费用_维修费',
    '6601.17': '销售费用_折旧摊销', '6601.18': '销售费用_邮寄费',
    '6601.19': '销售费用_通讯费', '6601.21': '销售费用_培训费',
    '6601.22': '销售费用_招聘费', '6601.23': '销售费用_团建',
    '6601.24': '销售费用_保险费', '6601.25': '销售费用_车辆费',
    '6602': '管理费用', '6602.01': '管理费用_职工薪酬',
    '6602.02': '管理费用_办公费', '6602.04': '管理费用_福利费',
    '6602.05': '管理费用_折旧费', '6602.06': '管理费用_无形资产摊销',
    '6602.08': '管理费用_咨询服务费', '6602.09': '管理费用_差旅费',
    '6602.10': '管理费用_交通费', '6602.11': '管理费用_业务招待费',
    '6602.13': '管理费用_房租', '6602.14': '管理费用_劳务费',
    '6602.15': '管理费用_审计费', '6602.16': '管理费用_维修费',
    '6602.17': '管理费用_培训费', '6602.18': '管理费用_水电费',
    '6602.19': '管理费用_其他', '6602.20': '管理费用_通讯费',
    '6602.22': '管理费用_车辆使用费', '6602.24': '管理费用_诉讼费',
    '6602.27': '管理费用_残疾人就业', '6602.33': '管理费用_其他2',
    '6603': '财务费用', '6603.01': '财务费用_利息支出',
    '6603.02': '财务费用_利息收入', '6603.04': '财务费用_手续费',
}

def get_name(code):
    if code in CODE_NAMES:
        return CODE_NAMES[code]
    return exp_08.get(code, {}).get('name', exp_09.get(code, {}).get('name', code))

# 只聚焦三项费用 6601/6602/6603
fee_codes = ['6601', '6602', '6603']
all_fee_08 = {k: v for k, v in exp_08.items() if any(k.startswith(fc) for fc in fee_codes)}
all_fee_09 = {k: v for k, v in exp_09.items() if any(k.startswith(fc) for fc in fee_codes)}

print("=" * 105)
print("  金融服务账套 | 费用波动分析报告")
print("  对比期间: 2025年9月 vs 2025年8月 | 已排除结转本期损益分录")
print("=" * 105)
print()

# 一级科目汇总
for fc in fee_codes:
    fc_name = CODE_NAMES.get(fc, fc)
    sub_08 = {k: v for k, v in all_fee_08.items() if k.startswith(fc)}
    sub_09 = {k: v for k, v in all_fee_09.items() if k.startswith(fc)}
    t08 = sum(abs(v['net']) for v in sub_08.values())
    t09 = sum(abs(v['net']) for v in sub_09.values())
    chg = t09 - t08
    rate = (chg / t08 * 100) if t08 > 0 else (float('inf') if t09 > 0 else 0)
    rate_str = f"{rate:+.1f}%" if t08 > 0 else ("新增" if t09 > 0 else "--")
    
    print(f"  {fc_name}: 8月 {t08:>14,.2f}  |  9月 {t09:>14,.2f}  |  变动 {chg:>+14,.2f}  |  波动 {rate_str}")

total_08 = sum(abs(v['net']) for v in all_fee_08.values())
total_09 = sum(abs(v['net']) for v in all_fee_09.values())
total_chg = total_09 - total_08
total_rate = (total_chg / total_08 * 100) if total_08 > 0 else 0

print(f"  {'-'*85}")
print(f"  三项费用合计: 8月 {total_08:>11,.2f}  |  9月 {total_09:>11,.2f}  |  变动 {total_chg:>+11,.2f}  |  波动 {total_rate:+.1f}%")
print()

# 二级科目明细对比
print("=" * 105)
print("  二级科目明细对比")
print("=" * 105)
print(f"  {'科目编码':<12} {'科目名称':<22} {'8月金额':>14} {'9月金额':>14} {'变动额':>14} {'波动率':>10} {'状态':<10}")
print(f"  {'-'*96}")

anomalies = []
all_codes = sorted(set(list(all_fee_08.keys()) + list(all_fee_09.keys())))

for code in all_codes:
    name = get_name(code)
    net_08 = all_fee_08.get(code, {}).get('net', 0)
    net_09 = all_fee_09.get(code, {}).get('net', 0)
    abs_08 = abs(net_08)
    abs_09 = abs(net_09)
    change = abs_09 - abs_08
    
    if abs_08 > 1:
        rate = (change / abs_08) * 100
    elif abs_09 > 1:
        rate = float('inf')
    else:
        rate = 0
    
    if abs_08 < 1 and abs_09 < 1:
        status = '--'
        rate_display = '--'
    elif abs_08 < 1 and abs_09 > 1:
        status = '!! 新增'
        rate_display = '新增'
        anomalies.append({'code': code, 'name': name, 'abs_08': abs_08, 'abs_09': abs_09, 'change': change, 'rate': rate, 'status': status})
    elif abs_09 < 1 and abs_08 > 1:
        status = '!! 消失'
        rate_display = '消失'
        anomalies.append({'code': code, 'name': name, 'abs_08': abs_08, 'abs_09': abs_09, 'change': change, 'rate': rate, 'status': status})
    elif abs(rate) >= 50:
        status = '!! 异常'
        rate_display = f'{rate:+.1f}%'
        anomalies.append({'code': code, 'name': name, 'abs_08': abs_08, 'abs_09': abs_09, 'change': change, 'rate': rate, 'status': status})
    elif abs(rate) >= 30:
        status = '! 预警'
        rate_display = f'{rate:+.1f}%'
    elif abs(rate) >= 10:
        status = '关注'
        rate_display = f'{rate:+.1f}%'
    else:
        status = '正常'
        rate_display = f'{rate:+.1f}%'
    
    print(f"  {code:<12} {name:<22} {abs_08:>14,.2f} {abs_09:>14,.2f} {change:>+14,.2f} {rate_display:>10} {status:<10}")

print(f"  {'-'*96}")

# 异常科目下钻分析
if anomalies:
    print()
    print("=" * 105)
    print("  异常科目下钻分析")
    print("=" * 105)
    
    for a in sorted(anomalies, key=lambda x: -abs(x['change'])):
        print()
        print(f"  >> [{a['status']}] {a['code']} - {a['name']}")
        print(f"     8月: {a['abs_08']:,.2f}  ->  9月: {a['abs_09']:,.2f}  |  变动: {a['change']:+,.2f}")
        
        # 选择金额较大的期间查看明细
        if a['abs_09'] >= a['abs_08']:
            period = '2025-09'
            src = data_09
        else:
            period = '2025-08'
            src = data_08
        
        level2 = a['code']
        level1 = level2.split('.')[0]
        
        matching = []
        for d in src:
            dc = d.get('account_code', '')
            sm = d.get('summary', '')
            if is_transfer_entry(sm):
                continue
            if dc == level2 or dc.startswith(level2 + '.'):
                matching.append(d)
        
        if not matching:
            matching = [d for d in src if d.get('account_code', '').startswith(level1) and not is_transfer_entry(d.get('summary', ''))]
        
        if matching:
            # 按摘要分组
            summary_group = defaultdict(lambda: {'amount': 0.0, 'count': 0})
            for d in matching:
                sm = d.get('summary', '其他')[:35]
                debit = float(d.get('debit_amount', 0) or 0)
                credit = float(d.get('credit_amount', 0) or 0)
                amt = max(debit, credit)
                if amt > 0:
                    summary_group[sm]['amount'] += amt
                    summary_group[sm]['count'] += 1
            
            top_items = sorted(summary_group.items(), key=lambda x: -x[1]['amount'])[:8]
            print(f"     --- {period} 业务摘要 Top {len(top_items)} ---")
            for sm, info in top_items:
                print(f"       {info['amount']:>12,.2f} ({info['count']:>2}笔) | {sm}")

print()
print("=" * 105)
print("  分析完成")
print("=" * 105)
