#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI月结智能检查 - 数据接入模块
支持Excel、PDF、CSV、图片格式导入
"""

import os
import re
import json
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime
import hashlib

# 导入数据库管理器
from db_manager import get_db_manager


class DataImporter:
    """数据导入器"""
    
    def __init__(self):
        self.db = get_db_manager()
        self.supported_formats = ['.xlsx', '.xls', '.csv', '.pdf', '.png', '.jpg', '.jpeg']
    
    def detect_file_type(self, file_path: str) -> str:
        """
        检测文件类型
        
        Args:
            file_path: 文件路径
        
        Returns:
            文件类型字符串
        """
        ext = Path(file_path).suffix.lower()
        if ext in ['.xlsx', '.xls']:
            return 'excel'
        elif ext == '.csv':
            return 'csv'
        elif ext == '.pdf':
            return 'pdf'
        elif ext in ['.png', '.jpg', '.jpeg']:
            return 'image'
        else:
            return 'unknown'
    
    def import_file(self, file_path: str, data_type: str, book_code: str, 
                   book_name: str, period: str, **kwargs) -> Tuple[bool, str]:
        """
        导入文件主入口
        
        Args:
            file_path: 文件路径
            data_type: 数据类型 (account_balances, detail_ledger, financial_report)
            book_code: 账套编码
            book_name: 账套名称
            period: 会计期间 (YYYY-MM)
            **kwargs: 额外参数
        
        Returns:
            (成功状态, 消息)
        """
        if not os.path.exists(file_path):
            return False, f"文件不存在: {file_path}"
        
        file_type = self.detect_file_type(file_path)
        
        if file_type == 'unknown':
            return False, f"不支持的文件格式，请上传: {', '.join(self.supported_formats)}"
        
        try:
            if file_type in ['excel', 'csv']:
                return self._import_tabular(file_path, data_type, book_code, book_name, period, **kwargs)
            elif file_type == 'pdf':
                return self._import_pdf(file_path, data_type, book_code, book_name, period, **kwargs)
            elif file_type == 'image':
                return self._import_image(file_path, data_type, book_code, book_name, period, **kwargs)
        except Exception as e:
            return False, f"导入失败: {str(e)}"
        
        return False, "未知错误"
    
    def _import_tabular(self, file_path: str, data_type: str, book_code: str,
                       book_name: str, period: str, **kwargs) -> Tuple[bool, str]:
        """
        导入表格文件（Excel/CSV）
        
        Args:
            file_path: 文件路径
            data_type: 数据类型
            book_code: 账套编码
            book_name: 账套名称
            period: 会计期间
            sheet_name: Excel工作表名称（可选）
            header_row: 表头行号（可选，从0开始）
        
        Returns:
            (成功状态, 消息)
        """
        # 读取文件
        ext = Path(file_path).suffix.lower()
        
        if ext == '.csv':
            # CSV文件
            df = pd.read_csv(file_path, encoding='utf-8')
        else:
            # Excel文件
            sheet_name = kwargs.get('sheet_name', 0)
            header_row = kwargs.get('header_row', 0)
            df = pd.read_excel(file_path, sheet_name=sheet_name, header=header_row)
        
        # 清洗数据
        df = self._clean_dataframe(df)
        
        # 根据数据类型进行字段映射
        if data_type == 'account_balances':
            data = self._parse_account_balances(df)
            return self.db.import_account_balances(data, book_code, book_name, period)
        
        elif data_type == 'detail_ledger':
            data = self._parse_detail_ledger(df)
            return self.db.import_detail_ledger(data, book_code, book_name, period)
        
        elif data_type == 'financial_report':
            report_type = kwargs.get('report_type', 'balance_sheet')
            data = self._parse_financial_report(df, report_type)
            return self.db.import_financial_report(data, book_code, book_name, period, report_type)
        
        else:
            return False, f"未知数据类型: {data_type}"
    
    def _import_pdf(self, file_path: str, data_type: str, book_code: str,
                   book_name: str, period: str, **kwargs) -> Tuple[bool, str]:
        """
        导入PDF文件
        
        注：PDF导入需要OCR识别，这里提供基本框架
        实际使用时需要结合OCR服务（如百度云OCR、Azure OCR等）
        """
        try:
            # 尝试使用tabula读取表格型PDF
            import tabula
            dfs = tabula.read_pdf(file_path, pages='all', multiple_tables=True)
            
            if not dfs:
                return False, "PDF中未检测到表格数据，请尝试使用图片格式上传"
            
            # 使用第一个表格
            df = dfs[0]
            df = self._clean_dataframe(df)
            
            if data_type == 'account_balances':
                data = self._parse_account_balances(df)
                return self.db.import_account_balances(data, book_code, book_name, period)
            elif data_type == 'detail_ledger':
                data = self._parse_detail_ledger(df)
                return self.db.import_detail_ledger(data, book_code, book_name, period)
            elif data_type == 'financial_report':
                report_type = kwargs.get('report_type', 'balance_sheet')
                data = self._parse_financial_report(df, report_type)
                return self.db.import_financial_report(data, book_code, book_name, period, report_type)
            
        except ImportError:
            return False, "PDF表格解析需要安装tabula-py: pip install tabula-py"
        except Exception as e:
            return False, f"PDF解析失败: {str(e)}。建议转换为Excel格式后上传"
    
    def _import_image(self, file_path: str, data_type: str, book_code: str,
                     book_name: str, period: str, **kwargs) -> Tuple[bool, str]:
        """
        导入图片文件（需要OCR识别）
        
        注：图片导入需要OCR服务，这里提供框架
        实际使用时需要接入OCR API
        """
        return False, "图片OCR识别需要配置OCR服务（如百度云OCR），建议使用Excel/CSV格式上传"
    
    def _clean_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """清洗DataFrame"""
        # 去除完全空行空列
        df = df.dropna(how='all').dropna(axis=1, how='all')
        
        # 去除列名空格
        df.columns = [str(col).strip() if pd.notna(col) else '' for col in df.columns]
        
        # 转换数值列
        for col in df.columns:
            if df[col].dtype == 'object':
                # 尝试转换为数值
                try:
                    # 去除千分位逗号
                    df[col] = df[col].astype(str).str.replace(',', '', regex=False)
                    df[col] = pd.to_numeric(df[col], errors='ignore')
                except:
                    pass
        
        return df
    
    def _parse_account_balances(self, df: pd.DataFrame) -> List[Dict]:
        """
        解析科目余额表
        
        支持的列名映射：
        - 科目编码: account_code, 科目编号, 科目代码, 科目号, 编码
        - 科目名称: account_name, 科目, 名称
        - 科目级次: account_level, 级次, 层级
        - 上级科目: parent_code, 上级科目, 上级编码
        - 期初借方: opening_debit, 期初余额借方, 期初借方余额
        - 期初贷方: opening_credit, 期初余额贷方, 期初贷方余额
        - 本期借方: current_debit, 本期发生借方, 借方发生额
        - 本期贷方: current_credit, 本期发生贷方, 贷方发生额
        - 期末借方: closing_debit, 期末余额借方, 期末借方余额
        - 期末贷方: closing_credit, 期末余额贷方, 期末贷方余额
        """
        # 列名映射
        column_mapping = {
            'account_code': ['科目编码', '科目编号', '科目代码', '科目号', '编码', 'account_code'],
            'account_name': ['科目名称', '科目', '名称', 'account_name'],
            'account_level': ['科目级次', '级次', '层级', 'account_level'],
            'parent_code': ['上级科目', '上级科目编码', '上级编码', 'parent_code'],
            'opening_debit': ['期初借方', '期初余额借方', '期初借方余额', 'opening_debit'],
            'opening_credit': ['期初贷方', '期初余额贷方', '期初贷方余额', 'opening_credit'],
            'current_debit': ['本期借方', '本期发生借方', '借方发生额', 'current_debit'],
            'current_credit': ['本期贷方', '本期发生贷方', '贷方发生额', 'current_credit'],
            'closing_debit': ['期末借方', '期末余额借方', '期末借方余额', 'closing_debit'],
            'closing_credit': ['期末贷方', '期末余额贷方', '期末贷方余额', 'closing_credit']
        }
        
        # 自动匹配列
        mapped_columns = {}
        for standard_name, possible_names in column_mapping.items():
            for col in df.columns:
                if any(name in str(col) for name in possible_names):
                    mapped_columns[standard_name] = col
                    break
        
        # 检查必需列
        if 'account_code' not in mapped_columns or 'account_name' not in mapped_columns:
            raise ValueError("无法识别科目编码和科目名称列，请检查文件格式")
        
        # 转换数据
        result = []
        for _, row in df.iterrows():
            item = {}
            for standard_name, col_name in mapped_columns.items():
                value = row.get(col_name)
                if pd.isna(value):
                    if standard_name in ['opening_debit', 'opening_credit', 'current_debit', 
                                        'current_credit', 'closing_debit', 'closing_credit']:
                        value = 0
                    else:
                        value = ''
                item[standard_name] = value
            result.append(item)
        
        return result
    
    def _parse_detail_ledger(self, df: pd.DataFrame) -> List[Dict]:
        """
        解析明细账
        
        支持的列名映射：
        - 凭证号: voucher_no, 凭证编号, 凭证
        - 凭证日期: voucher_date, 日期, 业务日期
        - 科目编码: account_code
        - 科目名称: account_name
        - 摘要: summary
        - 借方金额: debit_amount
        - 贷方金额: credit_amount
        - 方向: direction, 借贷方向
        - 余额: balance
        """
        column_mapping = {
            'voucher_no': ['凭证号', '凭证编号', '凭证', 'voucher_no'],
            'voucher_date': ['凭证日期', '日期', '业务日期', 'voucher_date', 'date'],
            'account_code': ['科目编码', '科目编号', '科目代码', 'account_code'],
            'account_name': ['科目名称', '科目', 'account_name'],
            'summary': ['摘要', '说明', 'summary'],
            'debit_amount': ['借方', '借方金额', '借方发生额', 'debit_amount'],
            'credit_amount': ['贷方', '贷方金额', '贷方发生额', 'credit_amount'],
            'direction': ['方向', '借贷方向', '余额方向', 'direction'],
            'balance': ['余额', 'balance']
        }
        
        mapped_columns = {}
        for standard_name, possible_names in column_mapping.items():
            for col in df.columns:
                if any(name in str(col) for name in possible_names):
                    mapped_columns[standard_name] = col
                    break
        
        if 'voucher_no' not in mapped_columns or 'voucher_date' not in mapped_columns:
            raise ValueError("无法识别凭证号和日期列，请检查文件格式")
        
        # 转换数据
        result = []
        for _, row in df.iterrows():
            item = {}
            for standard_name, col_name in mapped_columns.items():
                value = row.get(col_name)
                if pd.isna(value):
                    if standard_name in ['debit_amount', 'credit_amount', 'balance']:
                        value = 0
                    else:
                        value = ''
                
                # 日期格式处理
                if standard_name == 'voucher_date' and value:
                    if isinstance(value, pd.Timestamp):
                        value = value.strftime('%Y-%m-%d')
                    elif isinstance(value, str):
                        # 尝试统一日期格式
                        value = str(value)[:10]
                
                item[standard_name] = value
            result.append(item)
        
        return result
    
    def _parse_financial_report(self, df: pd.DataFrame, report_type: str) -> List[Dict]:
        """
        解析财务报表
        
        Args:
            df: DataFrame
            report_type: 报表类型 (balance_sheet, income_statement, cash_flow)
        """
        column_mapping = {
            'item_name': ['项目', '项目名称', '科目', 'item_name', 'name'],
            'item_code': ['项目编码', '项目代码', '编码', 'item_code', 'code'],
            'opening_amount': ['期初金额', '年初余额', '上期金额', '期初数', 'opening_amount'],
            'closing_amount': ['期末金额', '期末余额', '本期金额', '期末数', 'closing_amount'],
            'current_amount': ['本期发生额', '本期金额', '当月金额', 'current_amount']
        }
        
        mapped_columns = {}
        for standard_name, possible_names in column_mapping.items():
            for col in df.columns:
                if any(name in str(col) for name in possible_names):
                    mapped_columns[standard_name] = col
                    break
        
        if 'item_name' not in mapped_columns:
            raise ValueError("无法识别项目名称列，请检查文件格式")
        
        # 转换数据
        result = []
        for _, row in df.iterrows():
            item = {}
            for standard_name, col_name in mapped_columns.items():
                value = row.get(col_name)
                if pd.isna(value):
                    if standard_name in ['opening_amount', 'closing_amount', 'current_amount']:
                        value = 0
                    else:
                        value = ''
                item[standard_name] = value
            result.append(item)
        
        return result
    
    def preview_file(self, file_path: str, max_rows: int = 10) -> Tuple[bool, Dict]:
        """
        预览文件内容
        
        Args:
            file_path: 文件路径
            max_rows: 最大预览行数
        
        Returns:
            (成功状态, 预览数据字典)
        """
        try:
            file_type = self.detect_file_type(file_path)
            
            if file_type in ['excel', 'csv']:
                ext = Path(file_path).suffix.lower()
                if ext == '.csv':
                    df = pd.read_csv(file_path, encoding='utf-8')
                else:
                    df = pd.read_excel(file_path)
                
                df = self._clean_dataframe(df)
                
                return True, {
                    'file_type': file_type,
                    'columns': list(df.columns),
                    'row_count': len(df),
                    'preview': df.head(max_rows).to_dict('records'),
                    'suggested_data_type': self._suggest_data_type(df)
                }
            
            else:
                return False, {"error": f"暂不支持预览 {file_type} 格式"}
        
        except Exception as e:
            return False, {"error": str(e)}
    
    def _suggest_data_type(self, df: pd.DataFrame) -> str:
        """根据列名智能推测数据类型"""
        columns = ' '.join([str(c).lower() for c in df.columns])
        
        if '凭证' in columns or 'voucher' in columns:
            return 'detail_ledger'
        elif '余额' in columns and '发生额' in columns:
            return 'account_balances'
        elif '资产负债表' in columns or 'balance' in columns or ('资产' in columns and '负债' in columns):
            return 'financial_report:balance_sheet'
        elif '利润表' in columns or '损益表' in columns or 'income' in columns:
            return 'financial_report:income_statement'
        elif '现金流量' in columns or 'cash flow' in columns:
            return 'financial_report:cash_flow'
        else:
            return 'unknown'


# 单例
_importer = None

def get_importer() -> DataImporter:
    """获取数据导入器单例"""
    global _importer
    if _importer is None:
        _importer = DataImporter()
    return _importer


if __name__ == '__main__':
    # 测试代码
    importer = DataImporter()
    print(f"支持格式: {importer.supported_formats}")
