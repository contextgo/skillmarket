original SOUL.md content
