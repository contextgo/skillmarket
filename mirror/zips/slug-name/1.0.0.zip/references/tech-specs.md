# 技术规范参考

供写 PRD 时参考，根据产品技术栈选用对应部分。

---

## 常见技术栈组合建议

### 全栈 Web（推荐 Indie/小团队）
- 前端：Next.js + TypeScript + Tailwind CSS
- 后端：Next.js API Routes 或 Node.js (Fastify)
- 数据库：PostgreSQL + Prisma ORM
- 认证：NextAuth.js / Clerk
- 支付：Stripe
- 部署：Vercel + PlanetScale / Supabase

### 前后端分离（推荐中等规模）
- 前端：React / Vue 3 + TypeScript
- 后端：Node.js (Express/Fastify) / Python (FastAPI) / Go (Gin)
- 数据库：PostgreSQL（关系型）/ MongoDB（文档型）
- 缓存：Redis
- 队列：BullMQ / RabbitMQ
- 部署：AWS / GCP / 阿里云

### Mobile App
- 跨平台：React Native / Flutter
- 原生 iOS：Swift + SwiftUI
- 原生 Android：Kotlin + Jetpack Compose
- 后端：同上

---

## 认证方案对比

| 方案 | 适合场景 | 优点 | 缺点 |
|-----|--------|-----|-----|
| JWT（无状态） | API 为主，移动端 | 无需服务端存储 | Token 无法主动失效 |
| Session（有状态） | 传统 Web | 易控制登出 | 需要 Redis 存储 |
| OAuth2 / OIDC | 有第三方登录 | 标准化 | 实现复杂 |
| Clerk / Auth0 | 快速上线 | 开箱即用 | 成本/厂商锁定 |

---

## 文件存储方案

| 场景 | 推荐方案 |
|-----|--------|
| 用户上传图片/文件 | AWS S3 / 阿里云 OSS / Cloudflare R2 |
| 头像等小图 | 同上，配合 CDN |
| 大文件（视频等） | 分片上传 + CDN |

---

## 支付集成

### Stripe（国际用户）
- 订阅：`stripe.subscriptions.create()`
- Webhook：监听 `customer.subscription.updated`、`invoice.payment_failed`
- 必须处理：支付失败重试、订阅取消、退款

### 国内支付
- 微信支付 / 支付宝：使用官方 SDK
- 聚合支付：Ping++（已停止）/ 通联支付 / 杉德支付

---

## 邮件发送

| 服务 | 免费额度 | 适合场景 |
|-----|--------|--------|
| Resend | 3000封/月 | 开发者友好，推荐 |
| SendGrid | 100封/天 | 成熟稳定 |
| AWS SES | 62000封/月（EC2内） | 大量发送 |
| 阿里云邮件推送 | 按量计费 | 国内 |

---

## 监控与日志

### 错误监控
- Sentry（推荐，有免费版）
- Datadog（企业级）

### 性能监控
- Vercel Analytics（如用 Vercel）
- New Relic / Datadog APM

### 用户行为埋点
- PostHog（开源，可自建）
- Mixpanel（付费，功能强）
- Google Analytics 4（免费）
- 自建埋点表（最简单）

---

## 数据库索引建议

需要索引的场景：
- 外键字段（user_id, project_id 等）
- 高频查询的过滤字段（status, created_at）
- 唯一约束字段（email, slug）
- 全文搜索字段（用 PostgreSQL 全文索引或接 Elasticsearch）

---

## API 版本管理

推荐在 URL 中加版本：`/api/v1/...`

升级规则：
- 破坏性变更 → 升主版本（v1 → v2）
- 新增字段/端点 → 向后兼容，不升版本
- 废弃字段 → 保留 6 个月后删除，提前在响应头中告知
