# Linjiangxian — Simulated OpenClaw Brand Distillation Run

This example is written to feel like a real founder-to-skill interaction, with the skill asking calibrated questions instead of requiring a JSON form.

---

## Stage 1 — Calibration Interview

### Turn 1 — Brand name handling

**Skill**
Do you already have a brand name?

**Client**
Yes. The name is “临江仙”.

**Skill**
Why did you choose this name?

**Client**
Because it has a Chinese poetic feeling. It feels quiet, elegant, and has some distance from everyday noise.

**Skill**
What do you want this name to convey?

**Client**
Not loud culture. More like a restrained Oriental feeling. Something with mood, not preaching.

**Skill**
What do people actually feel when they see this name?

**Client**
Some people feel it’s beautiful. Some think it may be too literary or too far away from daily consumption.

**Skill**
What do you worry people might misunderstand?

**Client**
That it becomes too fake, too decorative, or too “cultural packaging”.

---

### Turn 2 — Cultural motif check

**Skill**
This name appears to have a strong cultural motif. Where does it come from for you — poetry, history, personal memory, or something else?

**Client**
Mainly from the emotional tone of the词牌名. It evokes a scene, a sense of time, distance, and restraint.

**Skill**
When people hear this name, what should they feel?

**Client**
They should feel a slight quietness, a little bit of留白, something elegant but not cold.

**Skill**
If this brand becomes wrong, what would it look like?

**Client**
It would look like cheap “new Chinese style”, overdecorated packaging, or empty cultural talk.

---

### Turn 3 — Open sampling

**Skill**
Please describe in the simplest way: what business are you doing, what are you selling, and who is buying from you?

**Client**
This is a culturally inflected consumer brand, likely in the alcohol/lifestyle direction. We want something with cultural atmosphere, but it still has to sell. I don’t want it to become a fake high-end culture product.

---

### Turn 4 — Target-user calibration

**Skill**
If you could sell to only one person, who would your ideal customer be?
Please describe one concrete person.

**Client**
A woman or man around 30 to 45, probably lives in a city, has some taste, reads a bit, does not like noisy consumerism, and is willing to pay for something with feeling — but hates pretentiousness.

**Skill**
Now describe one real customer who is actually likely to buy from you today.

**Client**
A 35 to 55-year-old with spending power, often buying in social or gifting contexts, still somewhat traditional in purchase logic.

**Skill**
Why is there a difference between the person you want and the person who buys today?

**Client**
Because the ideal user is driven more by aesthetic recognition, while the current real buyer is still partly driven by product category habits, gifting, or practical purchase logic.

---

### Turn 5 — Contradiction reveal

**Skill**
I see a contradiction:
- You want the brand to feel restrained, cultural, and non-pretentious.
- But it still has to sell in a market where buyers often use functional or social purchasing logic.

Which side should be primary?

**Client**
The cultural-emotional side should be primary, but it cannot become detached from real consumption.

---

### Turn 6 — Calibration confirmation

**Skill**
Let me confirm what I understand so far:
- This is a culturally loaded consumer brand.
- The name carries a poetic, restrained, quiet emotional field.
- The ideal goal is not “cultural display”, but “cultural feeling that can be sensed”.
- The biggest risk is drifting into decorative culture or fake high-end expression.
- The core tension is: how to keep subtle cultural tone while remaining commercially usable.

Which parts are accurate, and which are not?

**Client**
That’s accurate.

---

## Stage 1 output

```yaml
business_model: Culturally inflected consumer brand, likely in alcohol/lifestyle
customer: Taste-aware but anti-pretentious urban consumers
price_band: not yet fixed
usage_scenario: solitary drinking / small social setting / gifting-adjacent but not gifting-first

ideal_customer: 30–45, urban, taste-aware, dislikes noisy consumerism, values feeling over loud branding
real_customer: 35–55, has spending power, still partly buying through traditional category logic
customer_gap: ideal customer is aesthetic/emotional; real customer is more socially/functional motivated

core_problem: how to make a subtle cultural brand commercially legible
misunderstanding: may be seen as too literary, too decorative, too distant from purchase
why_not_choose_us: may not be immediately legible in market terms

real_difference: cultural restraint without empty cultural packaging

ambition: become a culturally resonant but commercially real brand
constraint: must not become pretentious, decorative, or fake high-end

brand_name_analysis:
  name: 临江仙
  source: ci pai / poetic-cultural motif
  intended_meaning: quiet oriental feeling, restraint, elegance, distance from noise
  perceived_meaning: beautiful but potentially too literary or too distant
  risk:
    - too decorative
    - too abstract
    - too detached from consumption

cultural_analysis:
  source: classical poetic naming
  emotional_tone: quiet, restrained, slightly distant, lingering
  symbolic_imagery:
    - riverside
    - wind
    - passage of time
    - gentle solitude
  perceived_risk:
    - cheap new-Chinese aesthetic
    - decorative packaging
    - empty cultural preaching
  should_not_become:
    - fake cultural luxury
    - visual over-decoration
    - slogan-heavy traditionalism
  modern_translation:
    - culture should be sensed, not explained
    - emotion should remain restrained
    - use lived scenes instead of abstract claims

detected_conflicts:
  - emotional subtlety vs commercial legibility
  - cultural tone vs real-world conversion

confidence_level: high
```

---

## Stage 2 — Brand Type Classification & Routing

**Skill (internal classification)**
- Brand type: symbolic
- Primary axis: emotional
- Secondary axis: functional
- Recommended route: symbolic → controlled commercial translation

**Skill**
Recommended strategic direction:
Use culture to build height, but use product and scenario to complete conversion.

**Client**
Agreed.

---

## Stage 3 — Distillation Engine

### Brand core convergence

**Skill**
I will now converge the brand core into one direction.

**Output**
> 让东方的“留白与克制”，在今天被真正感知，而不是被消费。

### Four-layer structure

```yaml
brand_structure:
  core: 让东方的“留白与克制”，在今天被真正感知，而不是被消费
  values:
    - 克制表达（不过度渲染）
    - 真实体验（不做文化装饰）
    - 可感知（必须让人感觉到）
  personality:
    - 安静
    - 克制
    - 有余味
  stance:
    - 不做“文化包装”的商品
    - 不用传统文化做溢价工具
    - 不迎合低级审美
    - 不解释文化，让人自己感受
```

### Positioning and expression

```yaml
brand_positioning: >-
  面向对“文化消费”已经疲惫的人群，提供一种不解释、不装饰，
  但可以真实感受到的东方体验。

brand_story_long: >-
  “临江仙”不是一个讲文化的品牌，而是一个让文化被感知的品牌。
  它来自一种很轻的情绪——不是浓烈，不是表达，而是一种留白。
  我们不试图解释文化，也不试图教育用户，
  我们只做一件事：让你在某个瞬间，感受到它。

brand_intro_short: 不是讲文化，是让你在某个瞬间，突然感觉到它。
```

### Expression constraints

```yaml
expression_rules:
  should:
    - 用具体场景表达
    - 用感受替代解释
    - 保持语言克制
  should_not:
    - 不用“匠心、传承、品质”等空词
    - 不做文化说教
    - 不做视觉堆砌
    - 不做国潮套路表达
```

### Conversion trigger

```yaml
conversion_trigger:
  - 场景：独处、小范围聚会
  - 心理：不想热闹，但希望有一点“感觉”
  - 触发：一种“刚刚好”的状态
```

---

## Stage 4 — Refinement

**Skill**
Please classify your feedback:
1. Which parts are correct?
2. Which parts are incorrect?
3. Which parts are missing?

**Client**
I agree with the assumptions and I agree with the output.

**Skill**
Since the user agrees with the core, no major contradiction remains, and the output can guide execution, the brand is ready for execution.

---

## Final delivery snapshot

```yaml
brand_name: 临江仙
brand_type: symbolic
primary_axis: emotional
secondary_axis: functional

brand_core: 让东方的“留白与克制”，在今天被真正感知，而不是被消费

brand_structure:
  values:
    - 克制表达（不过度渲染）
    - 真实体验（不做文化装饰）
    - 可感知（必须让人感觉到）
  personality:
    - 安静
    - 克制
    - 有余味
  stance:
    - 不做“文化包装”的商品
    - 不用传统文化做溢价工具
    - 不迎合低级审美
    - 不解释文化，让人自己感受

brand_positioning: >-
  面向对“文化消费”已经疲惫的人群，提供一种不解释、不装饰，
  但可以真实感受到的东方体验。

brand_story_long: >-
  “临江仙”不是一个讲文化的品牌，而是一个让文化被感知的品牌。
  它来自一种很轻的情绪——不是浓烈，不是表达，而是一种留白。
  我们不试图解释文化，也不试图教育用户，
  我们只做一件事：让你在某个瞬间，感受到它。

brand_intro_short: 不是讲文化，是让你在某个瞬间，突然感觉到它。

value_layers:
  functional_value: 通过场景和产品完成真实消费与转化
  emotional_value: 让用户感受到一种克制、安静、有余味的东方气质

cultural_layer:
  source: 词牌名“临江仙”
  emotional_tone: 留白、克制、淡淡的情绪、时间感
  symbolic_imagery:
    - 江边
    - 风
    - 时间流动
    - 独处/微社交
  perceived_risk:
    - 过于文艺
    - 距离消费过远
    - 缺乏转化抓手
  modern_translation:
    - 不做解释型文化
    - 做“可感知的体验”
    - 用场景代替概念
  forbidden_directions:
    - 低级国潮
    - 假高端文化包装
    - 空洞文化输出

expression_rules:
  should:
    - 用具体场景表达
    - 用感受替代解释
    - 保持语言克制
  should_not:
    - 不用“匠心、传承、品质”等空词
    - 不做文化说教
    - 不做视觉堆砌
    - 不做国潮套路表达

conversion_trigger:
  - 场景：独处、小范围聚会
  - 心理：不想热闹，但希望有一点“感觉”
  - 触发：一种“刚刚好”的状态

execution_guidelines:
  - 所有内容必须可感知，而不是可理解
  - 优先做场景，而不是概念
  - 所有表达必须统一情绪基调

feedback:
  correct:
    - 假设输入方向正确
    - 输出方向认可
  incorrect: []
  missing: []

status: ready_for_execution
confidence: high
```
