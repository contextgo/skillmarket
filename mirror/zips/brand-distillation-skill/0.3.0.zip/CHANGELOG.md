# Changelog

## v0.3.0 — Brand Stress Test Upgrade

### Added
- New `05-stress-test.md` module
- Full Brand Stress Test layer inside `SKILL.md`
- Stress-test fields in `schema.yaml`

### System change
- Final brand output is no longer delivered automatically after refinement
- Brand must pass pressure testing on:
  - target user
  - perception
  - differentiation
  - focus
  - strategy

### Core principle
If a brand cannot withstand pressure, it should not be executed.

## v0.2.0
- Calibration interview
- Brand type routing
- Structured distillation
- Iterative refinement
