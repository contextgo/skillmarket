# Brand Distillation Skill

A consultant-style OpenClaw skill for moving a founder or team from brand confusion to a clear, executable brand system.

## What it does

This skill is designed for four stages:

1. **Calibration interview** — identify facts, contradictions, wish-vs-reality gaps, and the real target customer.
2. **Brand-type routing** — choose the correct distillation path: functional, symbolic, or hybrid.
3. **Structured distillation** — converge toward a single brand core, values, personality, stance, positioning, and expression constraints.
4. **Refinement** — improve only what is wrong, unclear, or missing until the brand is ready for execution.

## Why it exists

Most AI branding outputs fail because they:
- ask for too many structured fields too early
- accept vague founder language at face value
- treat all brands as the same type
- generate pretty outputs without a decision framework
- lack iteration

This skill behaves more like a senior strategic advisor than a one-shot generator.

## Suggested repository structure

```text
brand-distillation-skill/
├── SKILL.md
├── README.md
├── schema.yaml
├── prompts/
│   ├── 01-calibration.md
│   ├── 02-routing.md
│   ├── 03-distillation.md
│   └── 04-refinement.md
└── examples/
    ├── linjiangxian-case.md
    └── linjiangxian-output.yaml
```

## OpenClaw compatibility

OpenClaw skills are AgentSkills-compatible folders that contain a `SKILL.md` with YAML frontmatter and instructions, and ClawHub publishes text-based skills as a `SKILL.md` plus supporting files. This repository follows that pattern. citeturn883754view0turn883754view2

## Installation notes

Place this folder in one of OpenClaw's supported skill locations, such as:
- `<workspace>/skills`
- `<workspace>/.agents/skills`
- `~/.agents/skills`
- `~/.openclaw/skills` citeturn883754view0

## Positioning of the skill

This is **not** a logo generator, art-director replacement, or one-shot naming tool.
It is a **brand convergence workflow**.

## Best use cases

- founder brands
- new product brands
- repositioning projects
- culturally loaded or emotionally loaded brands
- brand-to-content system building

## Not ideal for

- pure visual design without strategy
- large corporate multi-brand architectures
- zero-context naming-only requests

## v0.3.0 upgrade

This release adds a **Brand Stress Test** layer before final output.

The skill now:
- calibrates
- routes
- distills
- refines
- pressure-tests the brand before execution

A brand is no longer considered ready just because the structure sounds good.
It must survive a deliberate stress test first.
