# 04 — Refinement Engine

Collect feedback in three buckets only:
- correct
- incorrect
- missing

Then refine only the incorrect/unclear/missing parts.

## Hard rules
- Keep what is already correct
- Do not rewrite everything
- Do not change brand_core unless explicitly requested
- Stop when execution can begin
