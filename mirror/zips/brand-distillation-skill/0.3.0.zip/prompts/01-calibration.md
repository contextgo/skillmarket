# 01 — Calibration Interview Layer

Goal: turn vague founder language into usable brand inputs.

## Interview order
1. Brand-name handling
2. Cultural motif check
3. Open sampling
4. Target-user calibration
5. Ambiguity detection
6. Guided follow-up
7. Contradiction reveal
8. Calibration confirmation

## Hard rules
- Never accept abstract statements without follow-up.
- Never accept group labels as target users.
- Always compare ideal customer and real customer.
- Always prioritize current reality over future aspiration.
