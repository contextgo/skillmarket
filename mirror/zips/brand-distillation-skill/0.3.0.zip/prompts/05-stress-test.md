# 05 — Brand Stress Test Layer

Goal: pressure-test the distilled brand before execution.

## Core principle
If a brand cannot withstand pressure, it should not be executed.

This layer does NOT validate.
It challenges the brand and attempts to break weak logic.

## Test dimensions

### 1. Target User Stress Test
Check:
- Is the target user concrete?
- Is this user real and reachable?
- Does this user have a clear reason to buy now?
- Does product / price / channel match the user?

Fail if:
- target user is abstract
- target user is purely aspirational
- purchase motivation is weak or unclear

### 2. Perception Stress Test
Check:
- Can the intended feeling be perceived without explanation?
- Is it carried by product / packaging / experience?
- Does it match the usage scenario?

Fail if:
- perception depends on slogans or explanation
- the feeling is generic or decorative
- the product cannot actually carry the feeling

### 3. Differentiation Stress Test
Check:
- Is the difference real?
- Can users understand it?
- Does it affect choice?
- Is it defensible?

Fail if:
- competitors can say the same thing
- it is only language, not decision-relevant difference

### 4. Focus Stress Test
Check:
- Is there one clear strategic axis?
- Are strengths concentrated?
- Is expression consistent?

Fail if:
- multiple competing core ideas exist
- brand tries to win on too many things

### 5. Strategic Stability Stress Test
Check:
- Will this logic still hold in 3–5 years?
- Can it guide product / channel / communication decisions?
- Can it define what NOT to do?

Fail if:
- the logic depends on short-term trends
- it cannot guide execution choices

## Output structure

```yaml
brand_stress_test:
  target_user:
    result: pass | weak | fail
    key_issue:
    explanation:

  perception:
    result: pass | weak | fail
    key_issue:
    explanation:

  differentiation:
    result: pass | weak | fail
    key_issue:
    explanation:

  focus:
    result: pass | weak | fail
    key_issue:
    explanation:

  strategy:
    result: pass | weak | fail
    key_issue:
    explanation:

overall_verdict:
  status: ready | weak | collapse
  strongest_part:
  weakest_part:
  critical_risk:
  must_fix_before_execution:
  final_comment:
```

## Rules
- Do not be polite.
- Challenge assumptions.
- Prefer real-world logic over narrative.
- If any core dimension fails, trigger refinement.
- Only allow final execution output when the brand is ready.
