# 02 — Brand Type Routing

## Types
- functional
- symbolic
- hybrid

## Classification hints
- Purchase driven by utility/problem → functional
- Purchase driven by feeling/identity/culture → symbolic
- Both are needed → hybrid

## Hard rule
Do not allow mixed positioning without a dominant axis.
