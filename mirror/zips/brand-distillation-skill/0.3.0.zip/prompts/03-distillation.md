# 03 — Distillation Engine

Goal: converge, do not brainstorm endlessly.

## Required outputs
- brand_core
- values
- personality
- stance
- positioning
- long story
- short intro
- expression rules

## Hard rules
- Only one core
- No vague values
- Stance is mandatory
- Every output must guide execution
