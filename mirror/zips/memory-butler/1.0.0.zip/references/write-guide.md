# 记忆写入规范指南

## 通用原则

### 1. 什么时候写

- 用户说"记住" → 立即写，不要等
- 实质性工作完成 → 写 task-summary + 日记
- 有新认知/经验 → 写 MEMORY.md
- 用户偏好变化 → 写 USER.md + MEMORY.md
- 不确定时 → 先写文件，不靠脑子记

### 2. 怎么写 MEMORY.md

**格式要求：**
```markdown
## YYYY-MM-DD：事件标题

### 背景（可选）
[一句话上下文]

### 关键内容
- 具体事实A
- 具体事实B（带原文路径/命令/配置）

### 结果
[结论]
```

**示例：**
```markdown
## 2026-05-01：网易云音乐数据提取

### 技术方案
- 最终方案：Playwright CDP 连接 Edge，浏览器内 fetch() 调用 API
- 关键 Cookie：MUSIC_U（HttpOnly，含完整签名）
- 重跑命令：`node netease_browser_fetch.js`

### 结果
- ✅ 收藏歌单 600 首，含艺人/专辑
- ❌ 用户资料/等级（WEAPI 签名缺失，未解）
```

### 3. 怎么写每日日记

**格式要求：**
```markdown
# YYYY-MM-DD 日记

## 今日事项
- [x] 完成事项1
- [ ] 进行中事项2
- [待确认] 等待用户确认

## 技术笔记
- [经验/教训]

## 待处理
- [ ] 未完成项1
- [ ] 未完成项2
```

### 4. 常见错误

| 错误写法 | 正确写法 |
|---|---|
| "搞了很久终于弄好了" | "win32 API 截图方案：先 GetDesktopWindow，再 BitBlt" |
| "用户喜欢听歌" | "用户常听艺人：Billie Eilish(18)、Kanye West(12)" |
| "API 调用失败" | "Node.js https 直调 API 返回 404，MUSIC_U 签名缺失" |
| "配置好了" | "Edge 调试端口：9223，需开启开发者模式" |
