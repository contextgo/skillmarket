# MOVA Agent Contract Schema Reference

This file contains the two schemas that the output contract must conform to.
Read this when you need to verify field names, types, and required fields.

## ds.mova_schema_core_v1 (base)

Base fields inherited by all MOVA data schemas:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `schema_id` | string | no | Canonical schema id, e.g. `ds.mova_agent_contract_core_v1` |
| `schema_version` | string | no | Version of schema used, e.g. `1.0.0` |
| `meta` | object | no | Human-oriented metadata (see below) |
| `ext` | object | no | Machine-oriented extensions |

### meta object

| Field | Type | Description |
|-------|------|-------------|
| `title` | string | Short human-readable title |
| `description` | string | Longer description or notes |
| `tags` | array of strings | Tags for searching/grouping |
| `lang` | string | IETF language tag (e.g., `en`, `uk`, `de`) |

`meta` allows additionalProperties. `ext` allows additionalProperties.

---

## ds.mova_agent_contract_core_v1

Extends `ds.mova_schema_core_v1` via `allOf`. `additionalProperties: false`.

### Required fields

| Field | Type | Description |
|-------|------|-------------|
| `agent_id` | string (minLength: 1) | Canonical agent identifier |
| `agent_version` | string (minLength: 1) | Agent version string |
| `status` | enum: `draft`, `active`, `deprecated`, `revoked` | Contract status |
| `owner` | object (see below) | Agent owner |
| `task_domains` | array of strings (minItems: 1) | Business domains |
| `runtime_binding_ref` | string (minLength: 1) | Reference to runtime binding |
| `policy_profile_ref` | string (minLength: 1) | Reference to policy profile |
| `observability_profile` | object (see below) | Observability requirements |
| `determinism_controls` | object (see below) | Determinism settings |

### Optional fields

| Field | Type | Description |
|-------|------|-------------|
| `capability_tags` | array of strings | Agent capabilities |
| `input_envelope_ids` | array of strings | Allowed input envelope ids (env.*) |
| `output_envelope_ids` | array of strings | Produced output envelope ids (env.*) |
| `connector_refs` | array of strings | References to connectors |
| `limits` | object (see below) | Resource limits |

### owner object (required fields: owner_id, owner_kind)

| Field | Type | Values |
|-------|------|--------|
| `owner_id` | string (minLength: 1) | — |
| `owner_kind` | enum | `individual`, `organization`, `service` |

### observability_profile object (all fields required)

| Field | Type |
|-------|------|
| `compact_required` | boolean |
| `semantic_required` | boolean |
| `otel_correlation_required` | boolean |
| `required_artifacts` | array of strings |

### determinism_controls object (all fields required)

| Field | Type |
|-------|------|
| `seed_required` | boolean |
| `replay_supported` | boolean |

### limits object (all fields optional)

| Field | Type | Constraint |
|-------|------|------------|
| `max_tokens` | integer | minimum: 0 |
| `max_duration_ms` | integer | minimum: 0 |
| `max_tool_calls` | integer | minimum: 0 |
