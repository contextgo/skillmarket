"""
向量数据修复工具
检测并修复 TF-IDF 向量维度不一致的问题
"""

import json
import numpy as np
import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from memory_core import get_memory_db


def diagnose_vectors(owner_id: str = None):
    """诊断向量问题"""
    db = get_memory_db()
    cursor = db.conn.cursor()

    if owner_id:
        cursor.execute(
            """
            SELECT page_id, vector_json, vocab_json 
            FROM tfidf_index 
            WHERE owner_id = ? AND page_id NOT LIKE 'profile-%'
            """,
            (owner_id,),
        )
    else:
        cursor.execute(
            """
            SELECT page_id, vector_json, vocab_json, owner_id 
            FROM tfidf_index 
            WHERE page_id NOT LIKE 'profile-%'
            """
        )

    stats = {
        "total": 0,
        "empty": 0,
        "invalid_json": 0,
        "dimension_mismatch": {},
        "by_owner": {}
    }

    for row in cursor.fetchall():
        stats["total"] += 1
        page_id = row[0]
        vec_json = row[1]
        vocab_json = row[2]
        owner = row[3] if len(row) > 3 else owner_id

        try:
            vector = json.loads(vec_json) if vec_json else []
        except (json.JSONDecodeError, TypeError):
            stats["invalid_json"] += 1
            print(f"JSON解析失败: page_id={page_id}")
            continue

        if not vector or len(vector) == 0:
            stats["empty"] += 1
            print(f"空向量: page_id={page_id}")
            continue

        try:
            vocab = json.loads(vocab_json) if vocab_json else []
            expected_dim = len(vocab)
            actual_dim = len(vector)

            if expected_dim != actual_dim:
                dim_key = f"{actual_dim}/{expected_dim}"
                stats["dimension_mismatch"][dim_key] = stats["dimension_mismatch"].get(dim_key, 0) + 1
                print(f"维度不匹配: page_id={page_id}, actual={actual_dim}, expected={expected_dim}")

            if owner not in stats["by_owner"]:
                stats["by_owner"][owner] = {
                    "total": 0, "valid": 0, "issues": 0
                }
            stats["by_owner"][owner]["total"] += 1
            if expected_dim == actual_dim:
                stats["by_owner"][owner]["valid"] += 1
            else:
                stats["by_owner"][owner]["issues"] += 1
        except Exception as e:
            print(f"检查失败: page_id={page_id}, error={e}")

    return stats


def fix_vectors(owner_id: str, rebuild: bool = False):
    """修复向量问题"""
    db = get_memory_db()

    if rebuild:
        print(f"重建索引: owner_id={owner_id}")
        success = db.build_tfidf_index(owner_id)
        if success:
            print("索引重建成功")
        else:
            print("索引重建失败")
        return

    cursor = db.conn.cursor()
    cursor.execute(
        """
        SELECT page_id, vector_json, vocab_json 
        FROM tfidf_index 
        WHERE owner_id = ? AND page_id NOT LIKE 'profile-%'
        """,
        (owner_id,),
    )

    rows = cursor.fetchall()
    if not rows:
        print("没有找到向量数据")
        return

    dimensions = []
    for row in rows:
        try:
            vec = json.loads(row[1]) if row[1] else []
            if vec:
                dimensions.append(len(vec))
        except:
            continue

    if not dimensions:
        print("所有向量都是空的，建议重建索引")
        return

    import collections
    target_dim = collections.Counter(dimensions).most_common(1)[0][0]
    print(f"目标维度: {target_dim}")

    fixed_count = 0
    for row in rows:
        try:
            vec = json.loads(row[1]) if row[1] else []
            if len(vec) != target_dim:
                new_vec = np.zeros(target_dim, dtype=np.float32)
                if len(vec) > target_dim:
                    new_vec = np.array(vec[:target_dim], dtype=np.float32)
                else:
                    new_vec[:len(vec)] = vec

                norm = np.linalg.norm(new_vec)
                if norm > 0:
                    new_vec = new_vec / norm

                cursor.execute(
                    "UPDATE tfidf_index SET vector_json = ? WHERE page_id = ?",
                    (json.dumps(new_vec.tolist()), row[0]),
                )
                fixed_count += 1
                print(f"修复: page_id={row[0]}, old_dim={len(vec)} -> new_dim={target_dim}")
        except Exception as e:
            print(f"修复失败: page_id={row[0]}, error={e}")

    db.conn.commit()
    print(f"修复完成: 共修复 {fixed_count} 个向量")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="向量数据修复工具")
    parser.add_argument("--diagnose", action="store_true", help="诊断向量问题")
    parser.add_argument("--fix", action="store_true", help="修复向量问题")
    parser.add_argument("--rebuild", action="store_true", help="重建索引")
    parser.add_argument("--owner-id", help="指定用户ID")

    args = parser.parse_args()

    if args.diagnose:
        stats = diagnose_vectors(args.owner_id)
        print("\n诊断结果:")
        print(f"总向量数: {stats['total']}")
        print(f"空向量: {stats['empty']}")
        print(f"JSON解析失败: {stats['invalid_json']}")
        print(f"维度不匹配: {stats['dimension_mismatch']}")
        print(f"\n按用户统计:")
        for owner, data in stats["by_owner"].items():
            print(f"  {owner}: total={data['total']}, valid={data['valid']}, issues={data['issues']}")

    elif args.fix:
        if not args.owner_id:
            print("错误: 修复需要指定 --owner-id")
            exit(1)
        fix_vectors(args.owner_id, args.rebuild)

    else:
        parser.print_help()
