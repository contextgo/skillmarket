import threading
import time
from typing import List, Dict, Optional, Tuple
from logger import get_logger
from priority_detector import Priority, get_priority_detector
from config import Config


class TokenPlanProcessor:
    """
    Token 计划处理器（智能优先级版本）
    - 关键对话立即处理
    - 普通对话累积批量处理
    """

    def __init__(
        self,
        llm_processor,
        window_size: int = None,
        max_wait_seconds: float = None,
        enable_priority: bool = True,
        max_queue_high_size: int = None,
    ):
        self.llm = llm_processor
        self.window_size = window_size or Config.BATCH_WINDOW_SIZE
        self.max_wait = max_wait_seconds or Config.BATCH_MAX_WAIT_SECONDS
        self.enable_priority = enable_priority
        self.max_queue_high_size = (
            max_queue_high_size or Config.BATCH_MAX_QUEUE_HIGH_SIZE
        )
        self.high_priority_threshold = Config.BATCH_HIGH_PRIORITY_THRESHOLD

        self.priority_detector = get_priority_detector() if enable_priority else None

        self._queue_normal: List[List[Dict[str, str]]] = []  # ✅ 队列存储完整对话列表
        self._queue_high: List[List[Dict[str, str]]] = []  # ✅ 队列存储完整对话列表
        self._lock = threading.Lock()
        self._last_process_time = time.time()

        self.logger = get_logger("batch_processor")
        self._stats = {
            "immediate_processed": 0,
            "batch_processed": 0,
            "total_conversations": 0,
        }

    def add_conversation(
        self, conversation: List[Dict[str, str]]
    ) -> Optional[Tuple[Dict, Priority]]:
        """
        添加对话，智能决策处理方式

        Returns:
            (result, priority) 如果立即处理
            None 如果加入批量队列
        """
        if self.enable_priority and self.priority_detector:
            priority = self.priority_detector.detect_priority(conversation)

            if priority == Priority.CRITICAL:
                self.logger.info(
                    "IMMEDIATE_PROCESS",
                    reason="critical_keywords",
                    preview=conversation[-1].get("content", "")[:50],
                )
                with self._lock:
                    self._stats["total_conversations"] += 1
                    self._stats["immediate_processed"] += 1
                result = self.llm.process_conversation(conversation)
                return (result, priority)

        with self._lock:
            self._stats["total_conversations"] += 1

            if self.enable_priority and self.priority_detector:
                priority = self.priority_detector.detect_priority(conversation)

                if priority == Priority.HIGH:
                    if len(self._queue_high) >= self.max_queue_high_size:
                        self.logger.warning(
                            "HIGH_PRIORITY_QUEUE_FULL",
                            queue_size=len(self._queue_high),
                            action="immediate_process",
                        )
                        result = self.llm.process_conversation(conversation)
                        return (result, priority)
                    self._queue_high.append(conversation)  # ✅ 修复：保持对话完整
                    self.logger.debug(
                        "HIGH_PRIORITY_QUEUED", queue_size=len(self._queue_high)
                    )
                else:
                    self._queue_normal.append(conversation)  # ✅ 修复：保持对话完整
                    self.logger.debug(
                        "NORMAL_PRIORITY_QUEUED", queue_size=len(self._queue_normal)
                    )
            else:
                self._queue_normal.append(conversation)  # ✅ 修复：保持对话完整
                self.logger.debug(
                    "QUEUED_NO_PRIORITY", queue_size=len(self._queue_normal)
                )

            should_process = (
                len(self._queue_high) >= self.high_priority_threshold
                or len(self._queue_normal) >= self.window_size
                or (time.time() - self._last_process_time) >= self.max_wait
            )

            if should_process:
                result = self._process_batch()
                if result:
                    self._stats["batch_processed"] += 1
                    return (result, Priority.NORMAL)

        return None

    def flush(self) -> Optional[Dict]:
        """强制处理所有累积对话"""
        with self._lock:
            if self._queue_high or self._queue_normal:
                return self._process_batch()
        return None

    def _process_batch(self) -> Optional[Dict]:
        """处理累积的对话批次（真正批量合并处理）"""

        all_conversations = []
        processed_count = 0

        while self._queue_high and processed_count < self.high_priority_threshold:
            conv = self._queue_high.pop(0)
            all_conversations.extend(conv)
            processed_count += 1

        while self._queue_normal and processed_count < self.window_size:
            conv = self._queue_normal.pop(0)
            all_conversations.extend(conv)
            processed_count += 1

        if not all_conversations:
            return None

        self.logger.info(
            "BATCH_PROCESS_REAL",
            merged_conversations=processed_count,
            total_messages=len(all_conversations),
            high_remaining=len(self._queue_high),
            normal_remaining=len(self._queue_normal),
        )

        # ✅ 合并后的对话一次性处理
        result = self.llm.process_conversation(all_conversations)
        self._last_process_time = time.time()

        return result

    def get_stats(self) -> Dict:
        """获取统计信息"""
        with self._lock:
            immediate_rate = self._stats["immediate_processed"] / max(
                self._stats["total_conversations"], 1
            )
            return {
                **self._stats,
                "normal_queue_size": len(self._queue_normal),
                "high_queue_size": len(self._queue_high),
                "immediate_rate": f"{immediate_rate:.2%}",
            }


_processor: Optional[TokenPlanProcessor] = None
_processor_lock = threading.Lock()


def get_batch_processor(llm_processor=None) -> TokenPlanProcessor:
    """获取批量处理器单例"""
    global _processor
    if _processor is None:
        with _processor_lock:
            if _processor is None:
                if llm_processor is None:
                    from llm_processor import get_llm_processor

                    llm_processor = get_llm_processor()
                _processor = TokenPlanProcessor(llm_processor)
    return _processor
