"""
Agent Memory CLI
命令行工具，用于测试和手动操作记忆数据库
"""

import sys
import json
import argparse
from .api import get_memory_api, MemoryAPI


def cmd_process(args):
    """处理对话"""
    try:
        api = get_memory_api()
        conversation = json.loads(args.conversation) if args.conversation else []
        result = api.process_conversation(conversation, args.owner_id, args.session_id)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except json.JSONDecodeError as e:
        print(f"错误: 无效的 JSON 格式 - {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_search(args):
    """搜索记忆"""
    try:
        api = get_memory_api()
        result = api.search_events(
            args.query, args.owner_id, max_results=args.max_results
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_read(args):
    """读取页面"""
    try:
        api = get_memory_api()
        layers = (
            [int(x.strip()) for x in args.layers.split(",")]
            if args.layers
            else [1, 2, 3]
        )
        result = api.read_page(args.page_id, layers)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except ValueError as e:
        print(f"错误: 无效的层级格式 - {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_merge(args):
    """合并页面"""
    try:
        api = get_memory_api()
        page_ids = [x.strip() for x in args.page_ids.split(",")]
        result = api.merge_pages(page_ids, args.merge_type, args.reason, args.owner_id)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_profile(args):
    """获取/更新画像"""
    try:
        api = get_memory_api()
        if args.update:
            updates = json.loads(args.update)
            result = api.update_profile(args.owner_id, updates)
        else:
            result = api.get_profile(args.owner_id)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except json.JSONDecodeError as e:
        print(f"错误: 无效的 JSON 格式 - {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_stats(args):
    """获取统计"""
    api = get_memory_api()
    result = api.get_stats(args.owner_id)
    print(json.dumps(result, indent=2, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description="Agent Memory Database CLI")
    subparsers = parser.add_subparsers(dest="command", help="子命令")

    # process 命令
    p_process = subparsers.add_parser("process", help="处理对话并存储记忆")
    p_process.add_argument("--conversation", required=True, help="对话 JSON")
    p_process.add_argument("--owner-id", required=True, help="用户ID")
    p_process.add_argument("--session-id", help="会话ID")

    # search 命令
    p_search = subparsers.add_parser("search", help="搜索记忆")
    p_search.add_argument("--query", required=True, help="搜索关键词")
    p_search.add_argument("--owner-id", help="用户ID")
    p_search.add_argument("--max-results", type=int, default=10, help="最大结果数")

    # read 命令
    p_read = subparsers.add_parser("read", help="读取页面")
    p_read.add_argument("--page-id", required=True, help="页面ID")
    p_read.add_argument("--layers", default="1,2,3", help="层级，逗号分隔")

    # merge 命令
    p_merge = subparsers.add_parser("merge", help="合并页面")
    p_merge.add_argument("--page-ids", required=True, help="页面ID，逗号分隔")
    p_merge.add_argument(
        "--merge-type", required=True, choices=["same_event", "update", "related"]
    )
    p_merge.add_argument("--reason", default="", help="合并原因")
    p_merge.add_argument("--owner-id", help="用户ID")

    # profile 命令
    p_profile = subparsers.add_parser("profile", help="获取/更新画像")
    p_profile.add_argument("--owner-id", required=True, help="用户ID")
    p_profile.add_argument("--update", help="更新内容 JSON")

    # stats 命令
    p_stats = subparsers.add_parser("stats", help="获取统计")
    p_stats.add_argument("--owner-id", help="用户ID")

    args = parser.parse_args()

    if args.command == "process":
        cmd_process(args)
    elif args.command == "search":
        cmd_search(args)
    elif args.command == "read":
        cmd_read(args)
    elif args.command == "merge":
        cmd_merge(args)
    elif args.command == "profile":
        cmd_profile(args)
    elif args.command == "stats":
        cmd_stats(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
