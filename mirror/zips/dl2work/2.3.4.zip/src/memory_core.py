"""
Agent Memory Database - 核心记忆库
三层页表结构的 AI Agent 记忆管理系统

核心设计：
- 第三层 (L3): 完整对话内容
- 第二层 (L2): 事件摘要
- 第一层 (L1): 关键词索引
- 画像区: 用户偏好独立存储
"""

import json
import os
import sqlite3
import uuid
import threading
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import Optional, List, Dict, Any
from enum import Enum

from errors import get_logger, DatabaseError
from config import STOPWORDS, SecurityConfig, Config

logger = get_logger("core")


def now_utc() -> str:
    """获取当前 UTC 时间（ISO 格式字符串）"""
    return datetime.now(timezone.utc).isoformat()


class PageStatus(Enum):
    ACTIVE = "active"
    MERGED = "merged"
    ARCHIVED = "archived"
    DELETED = "deleted"


class InfoType(Enum):
    WASTE = "waste"  # 无用聊天
    PROFILE = "profile"  # 画像信息
    EVENT = "event"  # 事件信息


@dataclass
class L3Page:
    """第三层：完整对话页"""

    page_id: str
    content: str
    source_type: str = "conversation"
    owner_id: str = "default"
    created_at: str = field(default_factory=now_utc)
    status: str = "active"
    version: int = 1
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class L2Page:
    """第二层：摘要页"""

    page_id: str
    full_page_id: str
    summary: str
    entities: List[Dict] = field(default_factory=list)
    key_facts: List[str] = field(default_factory=list)
    conclusion: str = ""
    implied_preferences: List[str] = field(default_factory=list)
    status: str = "active"
    created_at: str = field(default_factory=now_utc)

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class L1Page:
    """第一层：关键词页"""

    page_id: str
    full_page_id: str
    summary_page_id: str
    owner_id: str = "default"  # 所属用户，用于搜索隔离
    created_at: str = field(default_factory=now_utc)
    keywords: Dict[str, List[str]] = field(default_factory=dict)
    time_hint: str = ""
    event_date: str = ""  # 对话发生的绝对日期
    similarity_seeds: List[str] = field(default_factory=list)
    is_archived: bool = False

    def to_dict(self) -> Dict:
        data = asdict(self)
        # SQLite 不支持直接存储 dict，转为 JSON 字符串
        data["keywords_json"] = json.dumps(self.keywords)
        data["similarity_seeds_json"] = json.dumps(self.similarity_seeds)
        del data["keywords"]
        del data["similarity_seeds"]
        return data

    @classmethod
    def from_dict(cls, data: Dict) -> "L1Page":
        if "keywords_json" in data:
            try:
                data["keywords"] = json.loads(data["keywords_json"])
            except (json.JSONDecodeError, TypeError):
                data["keywords"] = {}
            del data["keywords_json"]
        if "similarity_seeds_json" in data:
            try:
                data["similarity_seeds"] = json.loads(data["similarity_seeds_json"])
            except (json.JSONDecodeError, TypeError):
                data["similarity_seeds"] = []
            del data["similarity_seeds_json"]
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class Profile:
    """用户画像"""

    profile_id: str
    owner_id: str
    content: Dict[str, Any]
    evidence: List[Dict[str, str]] = field(default_factory=list)
    version: int = 1
    created_at: str = field(default_factory=now_utc)
    updated_at: str = field(default_factory=now_utc)
    is_archived: bool = False

    def to_dict(self) -> Dict:
        data = asdict(self)
        data["content_json"] = json.dumps(self.content)
        data["evidence_json"] = json.dumps(self.evidence)
        del data["content"]
        del data["evidence"]
        return data

    @classmethod
    def from_dict(cls, data: Dict) -> "Profile":
        if "content_json" in data:
            try:
                data["content"] = json.loads(data["content_json"])
            except (json.JSONDecodeError, TypeError):
                data["content"] = {}
            del data["content_json"]
        if "evidence_json" in data:
            try:
                data["evidence"] = json.loads(data["evidence_json"])
            except (json.JSONDecodeError, TypeError):
                data["evidence"] = []
            del data["evidence_json"]
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class MergeRecord:
    """合并记录"""

    merge_id: str
    source_pages: List[str]
    target_page_id: str
    reason: str
    merge_type: str
    merged_at: str = field(default_factory=now_utc)

    def to_dict(self) -> Dict:
        data = asdict(self)
        data["source_pages_json"] = json.dumps(self.source_pages)
        del data["source_pages"]
        return data

    @classmethod
    def from_dict(cls, data: Dict) -> "MergeRecord":
        if "source_pages_json" in data:
            try:
                data["source_pages"] = json.loads(data["source_pages_json"])
            except (json.JSONDecodeError, TypeError):
                data["source_pages"] = []
            del data["source_pages_json"]
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


class AgentMemoryDB:
    """AI Agent 记忆数据库主类"""

    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self._lock = threading.RLock()
        self._init_db()
        self._apply_security_pragmas()

    @staticmethod
    def with_lock(func):
        """线程锁装饰器 - 确保数据库操作的线程安全"""

        @wraps(func)
        def wrapper(self, *args, **kwargs):
            with self._lock:
                return func(self, *args, **kwargs)

        return wrapper

    def __enter__(self):
        """进入上下文"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出上下文，确保连接关闭"""
        self.close()
        return False

    def __del__(self):
        """析构时关闭连接"""
        try:
            self.close()
        except Exception:
            pass

    def _init_db(self):
        """初始化数据库表结构"""
        cursor = self.conn.cursor()

        # 第三层：完整对话页
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS l3_pages (
                page_id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                source_type TEXT DEFAULT 'conversation',
                owner_id TEXT DEFAULT 'default',
                created_at TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                version INTEGER DEFAULT 1,
                metadata_json TEXT
            )
        """)

        # 第二层：摘要页
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS l2_pages (
                page_id TEXT PRIMARY KEY,
                full_page_id TEXT NOT NULL,
                summary TEXT NOT NULL,
                entities_json TEXT,
                key_facts_json TEXT,
                conclusion TEXT DEFAULT '',
                implied_preferences_json TEXT,
                status TEXT DEFAULT 'active',
                created_at TEXT NOT NULL,
                FOREIGN KEY (full_page_id) REFERENCES l3_pages(page_id)
            )
        """)

        # 第一层：关键词页
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS l1_pages (
                page_id TEXT PRIMARY KEY,
                full_page_id TEXT NOT NULL,
                summary_page_id TEXT NOT NULL,
                owner_id TEXT DEFAULT 'default',
                created_at TEXT NOT NULL,
                keywords_json TEXT NOT NULL,
                time_hint TEXT DEFAULT '',
                event_date TEXT DEFAULT '',
                similarity_seeds_json TEXT,
                is_archived INTEGER DEFAULT 0,
                vector_json TEXT,
                FOREIGN KEY (full_page_id) REFERENCES l3_pages(page_id),
                FOREIGN KEY (summary_page_id) REFERENCES l2_pages(page_id)
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tfidf_index (
                page_id TEXT PRIMARY KEY,
                full_page_id TEXT NOT NULL,
                owner_id TEXT NOT NULL,
                text_content TEXT NOT NULL,
                vector_json TEXT NOT NULL,
                vocab_json TEXT,
                idf_json TEXT,
                FOREIGN KEY (page_id) REFERENCES l2_pages(page_id)
            )
        """)
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_tfidf_owner ON tfidf_index(owner_id)"
        )
        # 补充新列（已有表升级）
        try:
            cursor.execute("ALTER TABLE tfidf_index ADD COLUMN vocab_json TEXT")
            cursor.execute("ALTER TABLE tfidf_index ADD COLUMN idf_json TEXT")
        except Exception as e:
            if "duplicate column name" not in str(e).lower():
                logger.warning(f"数据库迁移警告: {e}")

        # 迁移：为已有 L1 页补充 owner_id（从 L3 的 participant_ids 读取）
        try:
            cursor.execute(
                "ALTER TABLE l1_pages ADD COLUMN owner_id TEXT DEFAULT 'default'"
            )
            cursor.execute("""
                UPDATE l1_pages
                SET owner_id = COALESCE(
                    json_extract(l3.metadata_json, '$."participant_ids"[0]'),
                    'default'
                )
                FROM l3_pages l3
                WHERE l3.page_id = l1_pages.full_page_id
                  AND (l1_pages.owner_id = 'default' OR l1_pages.owner_id IS NULL)
            """)
        except Exception as e:
            if "duplicate column name" not in str(e).lower():
                logger.warning(f"数据库迁移警告: {e}")  # 列已存在则忽略

        # l3_pages 表迁移：添加 owner_id 列
        try:
            cursor.execute(
                "ALTER TABLE l3_pages ADD COLUMN owner_id TEXT DEFAULT 'default'"
            )
        except Exception as e:
            if "duplicate column name" not in str(e).lower():
                logger.warning(f"数据库迁移警告: {e}")  # 列已存在则忽略

        # l3_pages 表迁移：添加 merged_at 列
        try:
            cursor.execute("ALTER TABLE l3_pages ADD COLUMN merged_at TEXT")
        except Exception as e:
            if "duplicate column name" not in str(e).lower():
                logger.warning(f"数据库迁移警告: {e}")

        # l2_pages 表迁移：添加 merged_at 列
        try:
            cursor.execute("ALTER TABLE l2_pages ADD COLUMN merged_at TEXT")
        except Exception as e:
            if "duplicate column name" not in str(e).lower():
                logger.warning(f"数据库迁移警告: {e}")

        # l1_pages 表迁移：添加 event_date 列
        try:
            cursor.execute("ALTER TABLE l1_pages ADD COLUMN event_date TEXT DEFAULT ''")
        except Exception as e:
            if "duplicate column name" not in str(e).lower():
                logger.warning(f"数据库迁移警告: {e}")

        # 用户画像
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS profiles (
                profile_id TEXT PRIMARY KEY,
                owner_id TEXT NOT NULL,
                content_json TEXT NOT NULL,
                evidence_json TEXT,
                version INTEGER DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                is_archived INTEGER DEFAULT 0
            )
        """)

        try:
            cursor.execute("ALTER TABLE profiles ADD COLUMN evidence_json TEXT")
        except Exception as e:
            if "duplicate column name" not in str(e).lower():
                logger.warning(f"数据库迁移警告: {e}")

        # 合并记录
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS merge_records (
                merge_id TEXT PRIMARY KEY,
                source_pages_json TEXT NOT NULL,
                target_page_id TEXT NOT NULL,
                reason TEXT,
                merge_type TEXT,
                merged_at TEXT NOT NULL
            )
        """)

        # 归档配置表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS archive_config (
                config_id TEXT PRIMARY KEY,
                owner_id TEXT NOT NULL,
                retention_days INTEGER DEFAULT 180,
                auto_archive_enabled INTEGER DEFAULT 0,
                archive_threshold_score REAL DEFAULT 0.1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)

        # 归档页面记录表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS archived_pages (
                archive_id TEXT PRIMARY KEY,
                page_id TEXT NOT NULL,
                owner_id TEXT NOT NULL,
                archived_at TEXT NOT NULL,
                reason TEXT,
                original_created_at TEXT NOT NULL,
                l3_content_json TEXT,
                l2_summary_json TEXT,
                l1_keywords_json TEXT
            )
        """)

        # 创建索引
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_l1_seeds ON l1_pages(similarity_seeds_json)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_l1_archived ON l1_pages(is_archived)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_l1_owner_archived ON l1_pages(owner_id, is_archived)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_l1_full_page_id ON l1_pages(full_page_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_profile_owner ON profiles(owner_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_l3_created ON l3_pages(created_at)"
        )
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_l3_status ON l3_pages(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_l3_page_id ON l3_pages(page_id)")
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_l3_owner_created ON l3_pages(owner_id, created_at)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_archive_owner ON archive_config(owner_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_archived_page_owner ON archived_pages(owner_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_archived_page_date ON archived_pages(archived_at)"
        )

        # 审计日志表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                audit_id TEXT PRIMARY KEY,
                operation_type TEXT NOT NULL,
                owner_id TEXT NOT NULL,
                target_id TEXT,
                target_type TEXT,
                details_json TEXT,
                timestamp TEXT NOT NULL,
                ip_address TEXT,
                user_agent TEXT
            )
        """)
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_audit_owner ON audit_log(owner_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_audit_type ON audit_log(operation_type)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_log(timestamp)"
        )

        self.conn.commit()
        logger.info("数据库索引初始化完成")

    def _apply_security_pragmas(self):
        """应用安全相关的 SQLite PRAGMA 配置"""
        cursor = self.conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA secure_delete=ON")
        cursor.execute("PRAGMA busy_timeout=5000")
        logger.info("SQLite 安全配置已应用: WAL, foreign_keys, secure_delete")

    @with_lock
    def _log_audit(
        self,
        operation_type: str,
        owner_id: str,
        target_id: Optional[str] = None,
        target_type: Optional[str] = None,
        details: Optional[Dict] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> str:
        """
        记录审计日志

        Args:
            operation_type: 操作类型 (archive|restore|merge|profile_update|page_create)
            owner_id: 操作者ID
            target_id: 目标对象ID
            target_type: 目标类型 (page|profile)
            details: 操作详情
            ip_address: IP地址
            user_agent: 用户代理

        Returns:
            audit_id
        """
        cursor = self.conn.cursor()
        audit_id = str(uuid.uuid4())
        timestamp = now_utc()

        cursor.execute(
            """
            INSERT INTO audit_log
                (audit_id, operation_type, owner_id, target_id, target_type, 
                 details_json, timestamp, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                audit_id,
                operation_type,
                owner_id,
                target_id,
                target_type,
                json.dumps(details) if details else None,
                timestamp,
                ip_address,
                user_agent,
            ),
        )
        self.conn.commit()
        logger.debug(f"审计日志已记录: {operation_type} by {owner_id}")
        return audit_id

    @with_lock
    def save_l3_page(self, page: L3Page) -> str:
        """保存第三层页面"""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            INSERT INTO l3_pages (page_id, content, source_type, owner_id, created_at, status, version, metadata_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                page.page_id,
                page.content,
                page.source_type,
                page.owner_id,
                page.created_at,
                page.status,
                page.version,
                json.dumps(page.metadata),
            ),
        )
        self.conn.commit()
        logger.debug(f"L3页面已保存: {page.page_id}")
        return page.page_id

    @with_lock
    def save_l2_page(self, page: L2Page) -> str:
        """保存第二层页面"""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            INSERT INTO l2_pages (page_id, full_page_id, summary, entities_json, key_facts_json,
                                  conclusion, implied_preferences_json, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                page.page_id,
                page.full_page_id,
                page.summary,
                json.dumps(page.entities),
                json.dumps(page.key_facts),
                page.conclusion,
                json.dumps(page.implied_preferences),
                page.status,
                page.created_at,
            ),
        )
        self.conn.commit()
        logger.debug(f"L2页面已保存: {page.page_id}")
        return page.page_id

    @with_lock
    def save_l1_page(self, page: L1Page) -> str:
        """保存第一层页面"""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            INSERT INTO l1_pages (page_id, full_page_id, summary_page_id, owner_id, created_at,
                                  keywords_json, time_hint, event_date, similarity_seeds_json, is_archived)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                page.page_id,
                page.full_page_id,
                page.summary_page_id,
                page.owner_id,
                page.created_at,
                json.dumps(page.keywords),
                page.time_hint,
                page.event_date,
                json.dumps(page.similarity_seeds),
                1 if page.is_archived else 0,
            ),
        )
        self.conn.commit()
        return page.page_id

    @with_lock
    def save_profile(self, profile: Profile) -> str:
        """保存用户画像"""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            INSERT OR REPLACE INTO profiles (profile_id, owner_id, content_json, evidence_json, version, created_at, updated_at, is_archived)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                profile.profile_id,
                profile.owner_id,
                json.dumps(profile.content),
                json.dumps(profile.evidence),
                profile.version,
                profile.created_at,
                profile.updated_at,
                1 if profile.is_archived else 0,
            ),
        )
        self.conn.commit()

        # 记录审计日志
        self._log_audit(
            operation_type="profile_update",
            owner_id=profile.owner_id,
            target_id=profile.profile_id,
            target_type="profile",
            details={"version": profile.version},
        )

        return profile.profile_id

    @with_lock
    def save_merge_record(self, record: MergeRecord) -> str:
        """保存合并记录"""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            INSERT INTO merge_records (merge_id, source_pages_json, target_page_id, reason, merge_type, merged_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """,
            (
                record.merge_id,
                json.dumps(record.source_pages),
                record.target_page_id,
                record.reason,
                record.merge_type,
                record.merged_at,
            ),
        )
        self.conn.commit()

        # 记录审计日志
        self._log_audit(
            operation_type="merge",
            owner_id="system",
            target_id=record.merge_id,
            target_type="merge_record",
            details={
                "source_pages": record.source_pages,
                "target_page_id": record.target_page_id,
                "merge_type": record.merge_type,
                "reason": record.reason,
            },
        )

        return record.merge_id

    @with_lock
    def get_profile(self, owner_id: str) -> Optional[Profile]:
        """获取用户画像"""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            SELECT * FROM profiles WHERE owner_id = ? AND is_archived = 0
            ORDER BY version DESC LIMIT 1
        """,
            (owner_id,),
        )
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            data = dict(zip(columns, row))
            return Profile.from_dict(data)
        return None

    # ─────────────────────────────────────────────────────────────────
    # TF-IDF 向量检索（混合搜索：向量 + 关键词）
    # 核心：词汇表顺序固定并持久化，保证存储向量与查询向量维度一致
    # ─────────────────────────────────────────────────────────────────

    def _tokenize(self, text: str) -> List[str]:
        import re

        tokens = re.split(r'[\s,.!?;:，。（）、；：""' "《》【】+\\-]+", text)
        result = []
        for t in tokens:
            t = t.strip()
            if not t:
                continue
            chinese = sum(1 for c in t if "\u4e00" <= c <= "\u9fff")
            if chinese == len(t):
                # 纯中文：生成 2-4 字 n-gram 滑动窗口，不过滤停用词
                # （重要地名如"上海""北京"不应该被停用词过滤）
                for i in range(len(t) - 1):
                    for n in (2, 3, 4):
                        if i + n <= len(t):
                            result.append(t[i : i + n])
            elif chinese >= 2:
                result.append(t.lower())
            elif len(t) >= 3:
                if t.lower() not in STOPWORDS:
                    result.append(t.lower())
        return result

    def _compute_tfidf(self, corpus_tokens: List[List[str]]):
        import numpy as np
        import math

        all_words = set()
        for doc in corpus_tokens:
            all_words.update(doc)
        vocab_list = sorted(all_words)
        vocab_index = {w: i for i, w in enumerate(vocab_list)}
        V = len(vocab_list)
        if V == 0:
            return None, [], []

        N = len(corpus_tokens)
        tf_mat = np.zeros((N, V), dtype=np.float32)
        for di, doc in enumerate(corpus_tokens):
            freq = {}
            for w in doc:
                freq[w] = freq.get(w, 0) + 1
            for w, cnt in freq.items():
                tf_mat[di, vocab_index[w]] = 1.0 + math.log(cnt)

        df_vec = np.zeros(V)
        for doc in corpus_tokens:
            for w in set(doc):
                df_vec[vocab_index[w]] += 1.0

        idf_vec = np.array(
            [math.log(N / d) if d > 0 else 0.0 for d in df_vec], dtype=np.float32
        )

        tfidf = tf_mat * idf_vec[np.newaxis, :]
        norms = np.linalg.norm(tfidf, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1, norms)
        tfidf_norm = (tfidf / norms).astype(np.float32)
        tfidf_norm = np.nan_to_num(tfidf_norm, nan=0.0)  # ✅ 防止NaN
        return tfidf_norm.tolist(), vocab_list, idf_vec.tolist()

    @with_lock
    def build_tfidf_index(self, owner_id: str = None) -> bool:
        import numpy as np
        import math

        cursor = self.conn.cursor()
        if owner_id:
            cursor.execute(
                """
                SELECT l2.page_id, l2.summary, l2.key_facts_json
                FROM l2_pages l2
                JOIN l1_pages l1 ON l1.summary_page_id = l2.page_id
                WHERE l1.owner_id = ? AND l1.is_archived = 0
            """,
                (owner_id,),
            )
        else:
            cursor.execute("""
                SELECT l2.page_id, l2.summary, l2.key_facts_json
                FROM l2_pages l2
                JOIN l1_pages l1 ON l1.summary_page_id = l2.page_id
                WHERE l1.is_archived = 0
            """)

        rows = cursor.fetchall()
        if not rows:
            return False

        page_ids, texts = [], []
        for r in rows:
            summary = r[1] or ""
            key_facts = []
            if r[2]:
                try:
                    key_facts = json.loads(r[2])
                except (json.JSONDecodeError, TypeError):
                    key_facts = []
            texts.append(summary + "。" + "。".join(key_facts))
            page_ids.append(r[0])

        tokenized = [self._tokenize(t) for t in texts]
        tfidf_list, vocab_list, idf_list = self._compute_tfidf(tokenized)
        if tfidf_list is None:
            return False

        vocab_json = json.dumps(vocab_list)
        idf_json = json.dumps(idf_list)

        for i, pid in enumerate(page_ids):
            cursor.execute(
                """
                INSERT OR REPLACE INTO tfidf_index
                    (page_id, full_page_id, owner_id, text_content, vector_json, vocab_json, idf_json)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    pid,
                    pid,
                    owner_id or "default",
                    texts[i],
                    json.dumps(tfidf_list[i]),
                    vocab_json,
                    idf_json,
                ),
            )
        self.conn.commit()
        return True

    @with_lock
    def fix_tfidf_foreign_key(self) -> bool:
        """修复 tfidf_index 外键约束错误（指向 l1_pages 而非 l2_pages）"""
        cursor = self.conn.cursor()
        cursor.execute("PRAGMA foreign_keys = OFF")
        
        try:
            cursor.execute("CREATE TABLE IF NOT EXISTS tfidf_backup AS SELECT * FROM tfidf_index")
            cursor.execute("DROP TABLE IF EXISTS tfidf_index")
            cursor.execute("""
                CREATE TABLE tfidf_index (
                    page_id TEXT PRIMARY KEY,
                    full_page_id TEXT NOT NULL,
                    owner_id TEXT NOT NULL,
                    text_content TEXT NOT NULL,
                    vector_json TEXT NOT NULL,
                    vocab_json TEXT,
                    idf_json TEXT,
                    FOREIGN KEY (page_id) REFERENCES l2_pages(page_id)
                )
            """)
            cursor.execute("INSERT INTO tfidf_index SELECT * FROM tfidf_backup")
            cursor.execute("DROP TABLE tfidf_backup")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tfidf_owner ON tfidf_index(owner_id)")
            cursor.execute("PRAGMA foreign_keys = ON")
            self.conn.commit()
            logger.info("tfidf_index 外键约束已修复")
            return True
        except Exception as e:
            cursor.execute("PRAGMA foreign_keys = ON")
            logger.error(f"修复 tfidf_index 外键约束失败: {e}")
            return False

    @with_lock
    def get_l3_id_from_l2_id(self, l2_page_id: str) -> Optional[str]:
        """通过 L2 page_id 获取对应的 L3 page_id"""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT full_page_id FROM l2_pages WHERE page_id = ?",
            (l2_page_id,)
        )
        row = cursor.fetchone()
        return row[0] if row else None

    @with_lock
    def update_tfidf_index_incremental(self, page_id: str, owner_id: str) -> bool:
        """增量更新 TF-IDF 索引（单页更新，避免全量重建）"""
        import numpy as np
        import math

        cursor = self.conn.cursor()

        cursor.execute(
            """
            SELECT l2.summary, l2.key_facts_json
            FROM l2_pages l2
            WHERE l2.page_id = ?
        """,
            (page_id,),
        )

        row = cursor.fetchone()
        if not row:
            return False

        summary = row[0] or ""
        key_facts = []
        if row[1]:
            try:
                key_facts = json.loads(row[1])
            except (json.JSONDecodeError, TypeError):
                key_facts = []
        new_text = summary + "。" + "。".join(key_facts)
        new_tokens = self._tokenize(new_text)

        cursor.execute(
            """
            SELECT vocab_json, idf_json FROM tfidf_index
            WHERE owner_id = ? LIMIT 1
        """,
            (owner_id,),
        )

        vocab_row = cursor.fetchone()
        if not vocab_row or not vocab_row[0]:
            return self.build_tfidf_index(owner_id)

        try:
            vocab_list = json.loads(vocab_row[0]) if vocab_row[0] else []
            idf_list = json.loads(vocab_row[1]) if vocab_row[1] else []
        except (json.JSONDecodeError, TypeError):
            return self.build_tfidf_index(owner_id)
        V = len(vocab_list)

        vocab_index = {w: i for i, w in enumerate(vocab_list)}
        idf_arr = np.array(idf_list, dtype=np.float32)

        new_words = set(new_tokens) - set(vocab_list)
        if new_words:
            vocab_list = vocab_list + sorted(new_words)
            vocab_index = {w: i for i, w in enumerate(vocab_list)}
            V = len(vocab_list)

            cursor.execute(
                "SELECT COUNT(*) FROM tfidf_index WHERE owner_id = ?", (owner_id,)
            )
            N = cursor.fetchone()[0] + 1

            old_idf = idf_arr
            idf_arr = np.zeros(V, dtype=np.float32)
            for i, w in enumerate(vocab_list):
                if i < len(old_idf):
                    idf_arr[i] = old_idf[i]
                else:
                    idf_arr[i] = math.log(N / 1)

        freq = {}
        for w in new_tokens:
            freq[w] = freq.get(w, 0) + 1

        tf_vec = np.zeros(V, dtype=np.float32)
        for w, cnt in freq.items():
            if w in vocab_index:
                tf_vec[vocab_index[w]] = 1.0 + math.log(cnt)

        tfidf_vec = tf_vec * idf_arr
        norm = np.linalg.norm(tfidf_vec)
        if norm > 0:
            tfidf_vec = tfidf_vec / norm
        tfidf_vec = np.nan_to_num(tfidf_vec, nan=0.0)  # ✅ 防止NaN

        cursor.execute(
            """
            INSERT OR REPLACE INTO tfidf_index
                (page_id, full_page_id, owner_id, text_content, vector_json, vocab_json, idf_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
            (
                page_id,
                page_id,
                owner_id,
                new_text,
                json.dumps(tfidf_vec.tolist()),
                json.dumps(vocab_list),
                json.dumps(idf_arr.tolist()),
            ),
        )

        self.conn.commit()
        return True

    @with_lock
    def compute_query_vector(self, query_text: str, owner_id: Optional[str] = None):
        import numpy as np
        import math

        cursor = self.conn.cursor()
        if owner_id:
            cursor.execute(
                """
                SELECT vocab_json, idf_json FROM tfidf_index
                WHERE owner_id = ? LIMIT 1
            """,
                (owner_id,),
            )
        else:
            cursor.execute("SELECT vocab_json, idf_json FROM tfidf_index LIMIT 1")

        row = cursor.fetchone()
        if not row or not row[0]:
            return None, 0

        try:
            vocab_list = json.loads(row[0]) if row[0] else []
            idf_list = json.loads(row[1]) if row[1] else []
        except (json.JSONDecodeError, TypeError):
            return None, 0
        V = len(vocab_list)
        if V == 0:
            return None, 0

        vocab_index = {w: i for i, w in enumerate(vocab_list)}
        idf_arr = np.array(idf_list, dtype=np.float32)

        q_tokens = self._tokenize(query_text)
        if not q_tokens:
            return None, 0

        freq = {}
        for w in q_tokens:
            freq[w] = freq.get(w, 0) + 1
        q_tf = np.zeros(V, dtype=np.float32)
        for w, cnt in freq.items():
            if w in vocab_index:
                q_tf[vocab_index[w]] = 1.0 + math.log(cnt)

        q_tfidf = q_tf * idf_arr
        norm = np.linalg.norm(q_tfidf)
        if norm > 0:
            q_tfidf = q_tfidf / norm

        return q_tfidf.tolist(), V

    @with_lock
    def build_profile_tfidf(self, owner_id: str, profile_content: dict):
        """
        将用户画像写入 TF-IDF 索引，使画像信息可被搜索到。
        方案：画像值原始文本 + 统一_tokenize 分词构建 TF-IDF 向量
        """
        import numpy as np
        import math

        def flatten(obj, prefix=""):
            parts = []
            if isinstance(obj, dict):
                for k, v in obj.items():
                    parts.extend(flatten(v, f"{prefix}{k}="))
            elif isinstance(obj, list):
                for v in obj:
                    parts.extend(flatten(v, prefix))
            elif obj is not None:
                s = str(obj).strip()
                if s and s not in ("[]", "{}"):
                    parts.append(s)
            return parts

        raw_parts = flatten(profile_content)
        raw_text = " ".join(raw_parts)
        if not raw_text.strip():
            return

        tokens = self._tokenize(raw_text)
        if not tokens:
            return

        cursor = self.conn.cursor()
        if owner_id:
            cursor.execute(
                "SELECT text_content FROM tfidf_index WHERE owner_id = ?", (owner_id,)
            )
        else:
            cursor.execute("SELECT text_content FROM tfidf_index")
        corpus = [raw_text] + [r[0] for r in cursor.fetchall()]
        corp_toks = [self._tokenize(t) for t in corpus]

        all_w = set()
        for doc in corp_toks:
            all_w.update(doc)
        vocab = sorted(all_w)
        vind = {w: i for i, w in enumerate(vocab)}
        V = len(vocab)
        if V == 0:
            return

        N = len(corpus)
        df = {w: 0 for w in vocab}
        for doc in corp_toks:
            for w in set(doc):
                df[w] = df.get(w, 0) + 1
        idf_arr = [math.log(N / d) if d > 0 else 0.0 for w, d in df.items()]

        freq = {}
        for w in tokens:
            freq[w] = freq.get(w, 0) + 1
        vec = np.zeros(V, dtype=np.float32)
        for w, c in freq.items():
            if w in vind:
                vec[vind[w]] = 1.0 + math.log(c)
        vec = vec * np.array(idf_arr, dtype=np.float32)
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        vec = np.nan_to_num(vec, nan=0.0)  # ✅ 防止NaN

        pid = f"profile-{owner_id}"
        cursor.execute(
            """
            INSERT OR REPLACE INTO tfidf_index
                (page_id, full_page_id, owner_id, text_content, vector_json, vocab_json, idf_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
            (
                pid,
                pid,
                owner_id,
                raw_text,
                json.dumps(vec.tolist()),
                json.dumps(vocab),
                json.dumps(idf_arr),
            ),
        )
        self.conn.commit()

    @with_lock
    def search_l1_pages(
        self,
        query_keywords: List[str],
        owner_id: Optional[str] = None,
        limit: int = 10,
        query_text: Optional[str] = None,
        time_range: Optional[Dict] = None,
    ) -> List[Dict]:
        cursor = self.conn.cursor()

        # 1. 向量相似度检索
        vector_score = {}
        if query_text:
            q_vec, q_dim = self.compute_query_vector(query_text, owner_id)
            if q_vec and q_dim > 0:
                if owner_id:
                    cursor.execute(
                        "SELECT page_id, vector_json, text_content FROM tfidf_index WHERE owner_id = ?",
                        (owner_id,),
                    )
                else:
                    cursor.execute(
                        "SELECT page_id, vector_json, text_content FROM tfidf_index"
                    )
                for row in cursor.fetchall():
                    try:
                        stored = json.loads(row[1]) if row[1] else []
                    except (json.JSONDecodeError, TypeError):
                        continue

                    # ✅ 维度检查：如果不匹配，跳过该向量（未来可考虑重新计算）
                    if len(stored) != q_dim:
                        # 向量维度不匹配，可能是词汇表更新导致
                        # 这里跳过该向量，避免计算错误
                        logger.debug(
                            f"向量维度不匹配: page_id={row[0]}, "
                            f"stored_dim={len(stored)}, query_dim={q_dim}"
                        )
                        continue

                    sim = sum(a * b for a, b in zip(q_vec, stored))
                    vector_score[row[0]] = sim

        # 2. 关键词子串匹配
        keyword_score = {}

        # 3. 画像文本兜底搜索（不用 TF-IDF，直接子串匹配）
        #    解决中文分词停用词导致的向量匹配失败问题
        profile_text_score = {}
        for q in query_keywords or []:
            q_lower = q.lower()
            cursor.execute(
                "SELECT page_id, text_content FROM tfidf_index WHERE page_id LIKE 'profile-%' AND owner_id = ?",
                (owner_id or "default",),
            )
            for row in cursor.fetchall():
                pid, text = row
                if q_lower in text.lower():
                    profile_text_score[pid] = profile_text_score.get(pid, 0) + 1
        if profile_text_score:
            for pid, score in profile_text_score.items():
                vector_score[pid] = max(vector_score.get(pid, 0), score / 10.0)

        if query_keywords:
            if owner_id:
                cursor.execute(
                    """
                    SELECT page_id, keywords_json, similarity_seeds_json
                    FROM l1_pages WHERE is_archived = 0 AND owner_id = ?
                """,
                    (owner_id,),
                )
            else:
                cursor.execute("""
                    SELECT page_id, keywords_json, similarity_seeds_json
                    FROM l1_pages WHERE is_archived = 0
                """)
            for row in cursor.fetchall():
                page_id, kw_json, seeds_json = row
                try:
                    keywords = json.loads(kw_json) if kw_json else {}
                except (json.JSONDecodeError, TypeError):
                    keywords = {}
                try:
                    seeds = json.loads(seeds_json) if seeds_json else []
                except (json.JSONDecodeError, TypeError):
                    seeds = []
                all_terms = []
                for kw_list in keywords.values():
                    all_terms.extend(kw_list)
                all_terms.extend(seeds)
                q_set = {q.lower() for q in query_keywords}
                matched = sum(
                    1
                    for t in all_terms
                    if any(q in t.lower() or t.lower() in q for q in q_set)
                )
                if matched > 0:
                    keyword_score[page_id] = matched

        all_ids = set(vector_score) | set(keyword_score)
        if not all_ids:
            return []

        max_v = max(vector_score.values()) if vector_score else 1.0
        max_k = max(keyword_score.values()) if keyword_score else 1.0

        scored = []
        for pid in all_ids:
            vs = (vector_score.get(pid, 0.0) / max_v) if max_v > 0 else 0.0
            ks = (keyword_score.get(pid, 0) / max_k) if max_k > 0 else 0.0
            if vs == 0 and ks == 0:
                continue
            combined_score = (
                Config.VECTOR_SCORE_WEIGHT * vs + Config.KEYWORD_SCORE_WEIGHT * ks
            )
            scored.append((pid, combined_score))

        scored.sort(key=lambda x: x[1], reverse=True)

        # 4. 填充页面详情（支持时间范围过滤）
        result = []
        for page_id, score in scored[: limit * 2]:  # 多取一些，因为时间过滤可能淘汰部分
            # 先在 l1_pages 查找（事件页面）
            cursor.execute(
                """
                SELECT l1.page_id, l1.full_page_id, l1.keywords_json, l1.time_hint, l3.created_at
                FROM l1_pages l1
                JOIN l3_pages l3 ON l3.page_id = l1.full_page_id
                WHERE l1.page_id = ?
            """,
                (page_id,),
            )
            row = cursor.fetchone()
            if row:
                created_at = row[4]

                # 时间范围过滤
                if time_range:
                    start_date = time_range.get("start")
                    end_date = time_range.get("end")

                    try:
                        from datetime import datetime

                        page_date = datetime.fromisoformat(
                            created_at.replace("Z", "+00:00")
                        ).date()

                        if start_date:
                            start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
                            if page_date < start_dt:
                                continue
                        if end_date:
                            end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()
                            if page_date > end_dt:
                                continue
                    except (ValueError, AttributeError) as e:
                        logger.warning(f"时间范围过滤失败: {e}")
                        continue

                try:
                    keywords = json.loads(row[2]) if row[2] else {}
                except (json.JSONDecodeError, TypeError):
                    keywords = {}
                result.append(
                    {
                        "page_id": row[0],
                        "full_page_id": row[1],
                        "keywords": keywords,
                        "time_hint": row[3],
                        "created_at": created_at,
                        "score": round(score, 4),
                        "vector_score": round(vector_score.get(page_id, 0) / max_v, 4)
                        if max_v > 0
                        else 0.0,
                        "keyword_score": keyword_score.get(page_id, 0),
                    }
                )
                if len(result) >= limit:
                    break
                continue

            # 如果 l1_pages 里找不到，在 tfidf_index 里查找（画像页面）
            cursor.execute(
                """
                SELECT text_content FROM tfidf_index
                WHERE page_id = ? AND owner_id = ?
            """,
                (page_id, owner_id or "default"),
            )
            tfidf_row = cursor.fetchone()
            if tfidf_row:
                raw_text = tfidf_row[0]
                # 提取关键词：从文本中找匹配 query 的片段
                matched_kw = []
                for kw in query_keywords:
                    if kw.lower() in raw_text.lower():
                        matched_kw.append(kw)
                result.append(
                    {
                        "page_id": page_id,
                        "full_page_id": page_id,
                        "keywords": {"matched_text": matched_kw, "source": "profile"},
                        "time_hint": "",
                        "score": round(score, 4),
                        "vector_score": round(vector_score.get(page_id, 0) / max_v, 4)
                        if max_v > 0
                        else 0.0,
                        "keyword_score": keyword_score.get(page_id, 0),
                        "is_profile": True,
                    }
                )

        return result

    @with_lock
    def get_l2_page(self, page_id: str) -> Optional[L2Page]:
        """获取第二层页面"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM l2_pages WHERE page_id = ?", (page_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            data = dict(zip(columns, row))
            # 解析 JSON 字段
            if "entities_json" in data and data["entities_json"]:
                try:
                    data["entities"] = json.loads(data["entities_json"])
                except (json.JSONDecodeError, TypeError):
                    data["entities"] = []
            if "key_facts_json" in data and data["key_facts_json"]:
                try:
                    data["key_facts"] = json.loads(data["key_facts_json"])
                except (json.JSONDecodeError, TypeError):
                    data["key_facts"] = []
            if "implied_preferences_json" in data and data["implied_preferences_json"]:
                try:
                    data["implied_preferences"] = json.loads(
                        data["implied_preferences_json"]
                    )
                except (json.JSONDecodeError, TypeError):
                    data["implied_preferences"] = []
            return L2Page(
                **{k: v for k, v in data.items() if k in L2Page.__dataclass_fields__}
            )
        return None

    def _get_l3_page_unsafe(self, page_id: str) -> Optional[L3Page]:
        """获取第三层页面（不加锁，用于事务内部调用）"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM l3_pages WHERE page_id = ?", (page_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            data = dict(zip(columns, row))
            if "metadata_json" in data and data["metadata_json"]:
                data["metadata"] = json.loads(data["metadata_json"])
            return L3Page(
                **{k: v for k, v in data.items() if k in L3Page.__dataclass_fields__}
            )
        return None

    @with_lock
    def get_l3_page(self, page_id: str) -> Optional[L3Page]:
        """获取第三层页面"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM l3_pages WHERE page_id = ?", (page_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            data = dict(zip(columns, row))
            if "metadata_json" in data and data["metadata_json"]:
                data["metadata"] = json.loads(data["metadata_json"])
            return L3Page(
                **{k: v for k, v in data.items() if k in L3Page.__dataclass_fields__}
            )
        return None

    def _get_l2_page_by_full_unsafe(self, full_page_id: str) -> Optional[L2Page]:
        """通过 full_page_id 获取第二层页面（不加锁，用于事务内部调用）"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM l2_pages WHERE full_page_id = ?", (full_page_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            data = dict(zip(columns, row))
            if "entities_json" in data and data["entities_json"]:
                data["entities"] = json.loads(data["entities_json"])
            if "key_facts_json" in data and data["key_facts_json"]:
                data["key_facts"] = json.loads(data["key_facts_json"])
            if "implied_preferences_json" in data and data["implied_preferences_json"]:
                data["implied_preferences"] = json.loads(
                    data["implied_preferences_json"]
                )
            return L2Page(
                **{k: v for k, v in data.items() if k in L2Page.__dataclass_fields__}
            )
        return None

    @with_lock
    def get_l2_page_by_full(self, full_page_id: str) -> Optional[L2Page]:
        """通过 full_page_id 获取第二层页面"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM l2_pages WHERE full_page_id = ?", (full_page_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            data = dict(zip(columns, row))
            if "entities_json" in data and data["entities_json"]:
                data["entities"] = json.loads(data["entities_json"])
            if "key_facts_json" in data and data["key_facts_json"]:
                data["key_facts"] = json.loads(data["key_facts_json"])
            if "implied_preferences_json" in data and data["implied_preferences_json"]:
                data["implied_preferences"] = json.loads(
                    data["implied_preferences_json"]
                )
            return L2Page(
                **{k: v for k, v in data.items() if k in L2Page.__dataclass_fields__}
            )
        return None

    @with_lock
    def get_l1_page(self, page_id: str) -> Optional[L1Page]:
        """通过 page_id 获取第一层页面"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM l1_pages WHERE page_id = ?", (page_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            data = dict(zip(columns, row))
            if "keywords_json" in data:
                data["keywords"] = json.loads(data["keywords_json"])
            if "similarity_seeds_json" in data:
                data["similarity_seeds"] = json.loads(data["similarity_seeds_json"])
            return L1Page(
                **{k: v for k, v in data.items() if k in L1Page.__dataclass_fields__}
            )
        return None

    def _get_l1_page_by_full_unsafe(self, full_page_id: str) -> Optional[L1Page]:
        """通过 full_page_id 获取第一层页面（不加锁，用于事务内部调用）"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM l1_pages WHERE full_page_id = ?", (full_page_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            data = dict(zip(columns, row))
            if "keywords_json" in data:
                data["keywords"] = json.loads(data["keywords_json"])
            if "similarity_seeds_json" in data:
                data["similarity_seeds"] = json.loads(data["similarity_seeds_json"])
            return L1Page(
                **{k: v for k, v in data.items() if k in L1Page.__dataclass_fields__}
            )
        return None

    @with_lock
    def get_l1_page_by_full(self, full_page_id: str) -> Optional[L1Page]:
        """通过 full_page_id 获取第一层页面"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM l1_pages WHERE full_page_id = ?", (full_page_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            data = dict(zip(columns, row))
            if "keywords_json" in data:
                data["keywords"] = json.loads(data["keywords_json"])
            if "similarity_seeds_json" in data:
                data["similarity_seeds"] = json.loads(data["similarity_seeds_json"])
            return L1Page(
                **{k: v for k, v in data.items() if k in L1Page.__dataclass_fields__}
            )
        return None

    @with_lock
    def mark_page_merged(self, page_id: str, merged_into: str):
        """标记页面已合并"""
        cursor = self.conn.cursor()
        merged_at = datetime.now(timezone.utc).isoformat()
        cursor.execute(
            """
            UPDATE l3_pages SET status = 'merged', merged_at = ? WHERE page_id = ?
        """,
            (merged_at, page_id),
        )
        cursor.execute(
            """
            UPDATE l2_pages SET status = 'merged', merged_at = ? WHERE full_page_id = ?
        """,
            (merged_at, page_id),
        )

        # 清理 TF-IDF 索引：删除合并页面的向量记录
        l2_page = self._get_l2_page_by_full_unsafe(page_id)
        if l2_page:
            cursor.execute(
                "DELETE FROM tfidf_index WHERE page_id = ?",
                (l2_page.page_id,),
            )

        self.conn.commit()
        logger.debug(f"页面已标记为合并: {page_id} -> {merged_into}, TF-IDF 索引已清理")

    @with_lock
    def get_stats(self, owner_id: Optional[str] = None) -> Dict:
        """获取详细统计信息"""
        cursor = self.conn.cursor()

        cursor.execute("SELECT COUNT(*) FROM l3_pages WHERE status = 'active'")
        active_pages = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM l3_pages WHERE status = 'merged'")
        merged_pages = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM l3_pages WHERE status = 'archived'")
        archived_pages = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM profiles WHERE is_archived = 0")
        active_profiles = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM merge_records")
        total_merges = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM archived_pages")
        total_archived = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM tfidf_index")
        indexed_pages = cursor.fetchone()[0]

        cursor.execute("""
            SELECT MIN(created_at), MAX(created_at) FROM l3_pages WHERE status = 'active'
        """)
        date_range = cursor.fetchone()
        earliest = date_range[0] if date_range and date_range[0] else None
        latest = date_range[1] if date_range and date_range[1] else None

        owner_stats = {}
        if owner_id:
            cursor.execute(
                "SELECT COUNT(*) FROM l1_pages WHERE owner_id = ? AND is_archived = 0",
                (owner_id,),
            )
            owner_active = cursor.fetchone()[0]

            cursor.execute(
                "SELECT COUNT(*) FROM archived_pages WHERE owner_id = ?", (owner_id,)
            )
            owner_archived = cursor.fetchone()[0]

            owner_stats = {
                "owner_id": owner_id,
                "active_pages": owner_active,
                "archived_pages": owner_archived,
            }

        return {
            "event_pages": {
                "active": active_pages,
                "merged": merged_pages,
                "archived": archived_pages,
            },
            "profiles": {"active": active_profiles},
            "merges": {"total": total_merges},
            "archives": {"total": total_archived},
            "search_index": {"indexed_pages": indexed_pages},
            "date_range": {"earliest": earliest, "latest": latest},
            "owner_stats": owner_stats if owner_id else None,
        }

    @with_lock
    def archive_page(self, page_id: str, owner_id: str, reason: str = "manual") -> Dict:
        """归档指定页面（事务保护 + 所有权验证）"""
        cursor = self.conn.cursor()

        try:
            l3 = self._get_l3_page_unsafe(page_id)
            if not l3:
                return {"success": False, "error": "Page not found"}

            page_owner = getattr(l3, "owner_id", None) or "default"
            if page_owner != owner_id:
                logger.warning(
                    f"权限拒绝: 用户 {owner_id} 试图归档用户 {page_owner} 的页面 {page_id}"
                )
                return {
                    "success": False,
                    "error": "Permission denied: you can only archive your own pages",
                }

            l2 = self._get_l2_page_by_full_unsafe(page_id)
            l1 = self._get_l1_page_by_full_unsafe(page_id)

            archive_id = str(uuid.uuid4())
            cursor.execute(
                """
                INSERT INTO archived_pages 
                    (archive_id, page_id, owner_id, archived_at, reason, original_created_at,
                     l3_content_json, l2_summary_json, l1_keywords_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    archive_id,
                    page_id,
                    owner_id,
                    now_utc(),
                    reason,
                    l3.created_at,
                    json.dumps(l3.to_dict()),
                    json.dumps(l2.to_dict()) if l2 else None,
                    json.dumps(l1.to_dict()) if l1 else None,
                ),
            )

            cursor.execute(
                "UPDATE l3_pages SET status = 'archived' WHERE page_id = ?", (page_id,)
            )
            cursor.execute(
                "UPDATE l2_pages SET status = 'archived' WHERE full_page_id = ?",
                (page_id,),
            )
            cursor.execute(
                "UPDATE l1_pages SET is_archived = 1 WHERE full_page_id = ?", (page_id,)
            )

            self.conn.commit()
            logger.info(
                f"页面已归档: {page_id}, archive_id: {archive_id}, reason: {reason}"
            )

            self._log_audit(
                operation_type="archive",
                owner_id=owner_id,
                target_id=page_id,
                target_type="page",
                details={"archive_id": archive_id, "reason": reason},
            )

            return {"success": True, "archive_id": archive_id, "page_id": page_id}

        except Exception as e:
            self.conn.rollback()
            logger.error(f"归档页面失败: {e}")
            return {
                "success": False,
                "error": SecurityConfig.sanitize_error_message(
                    f"Archive failed: {str(e)}"
                ),
            }

    @with_lock
    def get_archive_config(self, owner_id: str) -> Dict:
        """获取归档配置"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM archive_config WHERE owner_id = ?", (owner_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            return dict(zip(columns, row))
        return {
            "owner_id": owner_id,
            "retention_days": 180,
            "auto_archive_enabled": False,
            "archive_threshold_score": 0.1,
        }

    @with_lock
    def set_archive_config(self, owner_id: str, config: Dict) -> Dict:
        """设置归档配置"""
        cursor = self.conn.cursor()
        config_id = f"config-{owner_id}"
        now = now_utc()

        cursor.execute(
            """
            INSERT OR REPLACE INTO archive_config
                (config_id, owner_id, retention_days, auto_archive_enabled, 
                 archive_threshold_score, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
            (
                config_id,
                owner_id,
                config.get("retention_days", 180),
                1 if config.get("auto_archive_enabled", False) else 0,
                config.get("archive_threshold_score", 0.1),
                now,
                now,
            ),
        )

        self.conn.commit()
        return {"success": True, "config_id": config_id}

    @with_lock
    def get_archived_pages(self, owner_id: str = None, limit: int = 50) -> List[Dict]:
        """获取归档页面列表"""
        cursor = self.conn.cursor()
        if owner_id:
            cursor.execute(
                """
                SELECT archive_id, page_id, owner_id, archived_at, reason, original_created_at
                FROM archived_pages WHERE owner_id = ?
                ORDER BY archived_at DESC LIMIT ?
            """,
                (owner_id, limit),
            )
        else:
            cursor.execute(
                """
                SELECT archive_id, page_id, owner_id, archived_at, reason, original_created_at
                FROM archived_pages
                ORDER BY archived_at DESC LIMIT ?
            """,
                (limit,),
            )

        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        return [dict(zip(columns, row)) for row in rows]

    @with_lock
    def restore_page(self, archive_id: str, authorized_owner_id: str = None) -> Dict:
        """恢复归档页面（事务保护 + 权限验证 + 完整数据恢复）"""
        cursor = self.conn.cursor()

        try:
            cursor.execute(
                "SELECT * FROM archived_pages WHERE archive_id = ?", (archive_id,)
            )
            row = cursor.fetchone()
            if not row:
                return {"success": False, "error": "Archive not found"}

            columns = [desc[0] for desc in cursor.description]
            data = dict(zip(columns, row))

            if authorized_owner_id is not None:
                archived_owner = data.get("owner_id", "unknown")
                if archived_owner != authorized_owner_id:
                    logger.warning(
                        f"权限拒绝: 用户 {authorized_owner_id} 试图恢复用户 {archived_owner} 的归档页面"
                    )
                    return {
                        "success": False,
                        "error": "Permission denied: you can only restore your own archived pages",
                    }

            page_id = data["page_id"]

            # 恢复 L3 页面数据（如果页面不存在则插入，存在则更新）
            if data.get("l3_content_json"):
                l3_data = json.loads(data["l3_content_json"])
                cursor.execute(
                    "SELECT page_id FROM l3_pages WHERE page_id = ?", (page_id,)
                )
                existing = cursor.fetchone()
                if existing:
                    cursor.execute(
                        """
                        UPDATE l3_pages SET 
                            content = ?, source_type = ?, owner_id = ?,
                            created_at = ?, status = 'active', version = ?,
                            metadata_json = ?
                        WHERE page_id = ?
                    """,
                        (
                            l3_data.get("content"),
                            l3_data.get("source_type", "conversation"),
                            l3_data.get("owner_id", "default"),
                            l3_data.get("created_at"),
                            l3_data.get("version", 1),
                            json.dumps(l3_data.get("metadata", {}))
                            if l3_data.get("metadata")
                            else None,
                            page_id,
                        ),
                    )
                else:
                    cursor.execute(
                        """
                        INSERT INTO l3_pages 
                            (page_id, content, source_type, owner_id, created_at, 
                             status, version, metadata_json)
                        VALUES (?, ?, ?, ?, ?, 'active', ?, ?)
                    """,
                        (
                            page_id,
                            l3_data.get("content"),
                            l3_data.get("source_type", "conversation"),
                            l3_data.get("owner_id", "default"),
                            l3_data.get("created_at"),
                            l3_data.get("version", 1),
                            json.dumps(l3_data.get("metadata", {}))
                            if l3_data.get("metadata")
                            else None,
                        ),
                    )

            # 恢复 L2 页面数据
            if data.get("l2_summary_json"):
                l2_data = json.loads(data["l2_summary_json"])
                l2_page_id = l2_data.get("page_id") or page_id
                cursor.execute(
                    "SELECT page_id FROM l2_pages WHERE full_page_id = ?", (page_id,)
                )
                existing = cursor.fetchone()
                if existing:
                    cursor.execute(
                        """
                        UPDATE l2_pages SET 
                            summary = ?, entities_json = ?, key_facts_json = ?,
                            conclusion = ?, implied_preferences_json = ?,
                            status = 'active'
                        WHERE full_page_id = ?
                    """,
                        (
                            l2_data.get("summary", ""),
                            json.dumps(l2_data.get("entities", []))
                            if l2_data.get("entities")
                            else None,
                            json.dumps(l2_data.get("key_facts", []))
                            if l2_data.get("key_facts")
                            else None,
                            l2_data.get("conclusion", ""),
                            json.dumps(l2_data.get("implied_preferences", []))
                            if l2_data.get("implied_preferences")
                            else None,
                            page_id,
                        ),
                    )
                else:
                    cursor.execute(
                        """
                        INSERT INTO l2_pages 
                            (page_id, full_page_id, summary, entities_json, key_facts_json,
                             conclusion, implied_preferences_json, status, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?)
                    """,
                        (
                            l2_page_id,
                            page_id,
                            l2_data.get("summary", ""),
                            json.dumps(l2_data.get("entities", []))
                            if l2_data.get("entities")
                            else None,
                            json.dumps(l2_data.get("key_facts", []))
                            if l2_data.get("key_facts")
                            else None,
                            l2_data.get("conclusion", ""),
                            json.dumps(l2_data.get("implied_preferences", []))
                            if l2_data.get("implied_preferences")
                            else None,
                            l2_data.get("created_at", now_utc()),
                        ),
                    )

            # 恢复 L1 页面数据
            if data.get("l1_keywords_json"):
                l1_data = json.loads(data["l1_keywords_json"])
                l1_page_id = l1_data.get("page_id") or str(uuid.uuid4())
                l1_summary_page_id = l1_data.get("summary_page_id") or ""

                # 处理 keywords_json 和 similarity_seeds_json
                keywords_json = l1_data.get("keywords_json")
                if not keywords_json and "keywords" in l1_data:
                    keywords_json = json.dumps(l1_data.get("keywords", {}))

                similarity_seeds_json = l1_data.get("similarity_seeds_json")
                if not similarity_seeds_json and "similarity_seeds" in l1_data:
                    similarity_seeds_json = json.dumps(
                        l1_data.get("similarity_seeds", [])
                    )

                cursor.execute(
                    "SELECT page_id FROM l1_pages WHERE full_page_id = ?", (page_id,)
                )
                existing = cursor.fetchone()
                if existing:
                    cursor.execute(
                        """
                        UPDATE l1_pages SET 
                            keywords_json = ?, time_hint = ?, similarity_seeds_json = ?,
                            is_archived = 0, owner_id = ?
                        WHERE full_page_id = ?
                    """,
                        (
                            keywords_json or "{}",
                            l1_data.get("time_hint", ""),
                            similarity_seeds_json,
                            l1_data.get("owner_id", "default"),
                            page_id,
                        ),
                    )
                else:
                    cursor.execute(
                        """
                        INSERT INTO l1_pages 
                            (page_id, full_page_id, summary_page_id, owner_id, created_at,
                             keywords_json, time_hint, similarity_seeds_json, is_archived)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
                    """,
                        (
                            l1_page_id,
                            page_id,
                            l1_summary_page_id,
                            l1_data.get("owner_id", "default"),
                            l1_data.get("created_at", now_utc()),
                            keywords_json or "{}",
                            l1_data.get("time_hint", ""),
                            similarity_seeds_json,
                        ),
                    )
            else:
                cursor.execute(
                    "UPDATE l1_pages SET is_archived = 0 WHERE full_page_id = ?",
                    (page_id,),
                )

            # 删除归档记录
            cursor.execute(
                "DELETE FROM archived_pages WHERE archive_id = ?", (archive_id,)
            )

            self.conn.commit()
            logger.info(f"页面已恢复: {page_id}")

            self._log_audit(
                operation_type="restore",
                owner_id=data.get("owner_id", "unknown"),
                target_id=page_id,
                target_type="page",
                details={"archive_id": archive_id},
            )

            return {"success": True, "page_id": page_id}

        except Exception as e:
            self.conn.rollback()
            logger.error(f"恢复页面失败: {e}")
            return {
                "success": False,
                "error": SecurityConfig.sanitize_error_message(
                    f"Restore failed: {str(e)}"
                ),
            }

    def compute_similarity(self, page1_keywords: Dict, page2_keywords: Dict) -> float:
        """
        计算两个页面的相似度（Jaccard相似度）

        Args:
            page1_keywords: 页面1的关键词字典
            page2_keywords: 页面2的关键词字典

        Returns:
            相似度分数 (0.0 - 1.0)
        """
        all_kw1 = []
        all_kw2 = []

        for category, keywords in page1_keywords.items():
            if isinstance(keywords, list):
                all_kw1.extend([kw.lower() for kw in keywords])

        for category, keywords in page2_keywords.items():
            if isinstance(keywords, list):
                all_kw2.extend([kw.lower() for kw in keywords])

        if not all_kw1 or not all_kw2:
            return 0.0

        set1 = set(all_kw1)
        set2 = set(all_kw2)
        intersection = set1 & set2
        union = set1 | set2

        jaccard = len(intersection) / len(union) if union else 0.0
        return jaccard

    @with_lock
    def find_similar_pages(
        self, new_page_id: str, owner_id: str, threshold: float = None
    ) -> List[Dict]:
        """
        查找与新页面相似的已存在页面

        Args:
            new_page_id: 新页面ID（L3的page_id）
            owner_id: 用户ID
            threshold: 相似度阈值（0.0-1.0），默认使用 Config.SIMILARITY_THRESHOLD

        Returns:
            相似页面列表，按相似度降序排列
        """
        threshold = threshold or Config.SIMILARITY_THRESHOLD
        cursor = self.conn.cursor()

        new_l1 = self.get_l1_page_by_full(new_page_id)
        if not new_l1:
            return []

        cursor.execute(
            """
            SELECT page_id, keywords_json, time_hint, full_page_id
            FROM l1_pages
            WHERE owner_id = ? AND is_archived = 0 AND full_page_id != ?
        """,
            (owner_id, new_page_id),
        )

        similar_pages = []
        for row in cursor.fetchall():
            page_id = row[0]
            keywords_json = row[1]
            time_hint = row[2]
            full_page_id = row[3]

            try:
                keywords = json.loads(keywords_json)
                similarity = self.compute_similarity(new_l1.keywords, keywords)

                if similarity >= threshold:
                    similar_pages.append(
                        {
                            "page_id": full_page_id,
                            "l1_page_id": page_id,
                            "similarity": round(similarity, 3),
                            "keywords": keywords,
                            "time_hint": time_hint,
                        }
                    )
            except Exception:
                continue

        similar_pages.sort(key=lambda x: x["similarity"], reverse=True)
        return similar_pages

    @with_lock
    def auto_archive_old_pages(self, owner_id: str, days: int = 180) -> Dict:
        """自动归档超过指定天数的页面"""
        from datetime import timedelta

        cursor = self.conn.cursor()
        cutoff_date = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

        cursor.execute(
            """
            SELECT page_id FROM l3_pages 
            WHERE created_at < ? AND status = 'active' AND owner_id = ?
        """,
            (cutoff_date, owner_id),
        )

        old_pages = cursor.fetchall()
        archived_count = 0

        for page_row in old_pages:
            page_id = page_row[0]
            result = self.archive_page(page_id, owner_id, f"auto_archive_{days}days")
            if result.get("success"):
                archived_count += 1

        return {
            "success": True,
            "archived_count": archived_count,
            "cutoff_date": cutoff_date,
        }

    @with_lock
    def get_tfidf_vectors(self, owner_id: str) -> List[Dict]:
        """
        获取指定用户的所有 TF-IDF 向量（线程安全）

        Args:
            owner_id: 用户ID

        Returns:
            向量列表 [{"page_id": str, "vector": List[float]}, ...]
        """
        cursor = self.conn.cursor()
        cursor.execute(
            """
            SELECT page_id, vector_json, vocab_json 
            FROM tfidf_index 
            WHERE owner_id = ? AND page_id NOT LIKE 'profile-%'
            """,
            (owner_id,),
        )

        first_row = cursor.fetchone()
        if not first_row:
            return []

        try:
            vocab_list = json.loads(first_row[2]) if first_row[2] else []
        except (json.JSONDecodeError, TypeError):
            vocab_list = []

        expected_dim = len(vocab_list)

        cursor.execute(
            """
            SELECT page_id, vector_json, vocab_json 
            FROM tfidf_index 
            WHERE owner_id = ? AND page_id NOT LIKE 'profile-%'
            """,
            (owner_id,),
        )

        results = []
        for row in cursor.fetchall():
            try:
                vector = json.loads(row[1]) if row[1] else []
                if not vector or len(vector) == 0:
                    logger.warning(f"跳过空向量: page_id={row[0]}")
                    continue

                if expected_dim > 0 and len(vector) != expected_dim:
                    logger.warning(
                        f"跳过维度不匹配向量: page_id={row[0]}, "
                        f"expected_dim={expected_dim}, actual_dim={len(vector)}"
                    )
                    continue

                results.append({"page_id": row[0], "vector": vector})
            except (json.JSONDecodeError, TypeError) as e:
                logger.warning(f"跳过解析失败的向量: page_id={row[0]}, error={e}")
                continue

        return results

    def close(self):
        """关闭数据库连接（线程安全）"""
        with self._lock:
            self.conn.close()
            logger.info("数据库连接已关闭")


def _get_default_db_path() -> str:
    """获取默认数据库路径（使用 XDG 规范）"""
    xdg_data_home = os.getenv("XDG_DATA_HOME")
    if xdg_data_home:
        db_dir = Path(xdg_data_home) / "agent-memory"
    else:
        db_dir = Path.home() / ".local" / "share" / "agent-memory"

    db_dir.mkdir(parents=True, exist_ok=True)
    db_path = db_dir / "memory.db"
    return str(db_path)


DEFAULT_DB_PATH = _get_default_db_path()
logger.info(f"默认数据库路径: {DEFAULT_DB_PATH}")


_db_instance: Optional[AgentMemoryDB] = None
_db_lock = threading.Lock()
_db_init_failed = False


def get_memory_db(db_path: Optional[str] = None) -> AgentMemoryDB:
    """
    获取记忆数据库单例（线程安全）

    Args:
        db_path: 数据库路径，如果为None则使用默认路径

    Returns:
        AgentMemoryDB 实例

    Raises:
        DatabaseError: 如果数据库初始化失败
    """
    global _db_instance, _db_init_failed

    if _db_instance is None:
        with _db_lock:
            if _db_init_failed:
                raise DatabaseError(
                    "数据库初始化失败，请检查配置和权限",
                    {"hint": "查看日志获取详细错误信息"},
                )
            if _db_instance is None:
                final_path = db_path or DEFAULT_DB_PATH
                try:
                    logger.info(f"初始化数据库: {final_path}")
                    _db_instance = AgentMemoryDB(final_path)
                except Exception as e:
                    # 标记初始化失败，防止重复尝试
                    _db_init_failed = True
                    logger.error(f"数据库初始化失败: {e}", exc_info=True)
                    raise DatabaseError(
                        "数据库初始化失败",
                        {
                            "error": SecurityConfig.sanitize_error_message(str(e)),
                            "path": final_path,
                        },
                    )
    return _db_instance


def reset_memory_db():
    """重置数据库实例（用于测试或重新初始化）"""
    global _db_instance
    with _db_lock:
        if _db_instance:
            try:
                _db_instance.close()
            except Exception as e:
                logger.warning(f"关闭数据库时出错: {e}")
        _db_instance = None
        logger.info("数据库实例已重置")
