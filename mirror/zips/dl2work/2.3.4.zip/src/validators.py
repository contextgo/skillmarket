"""
输入验证模块
提供统一的输入验证函数
"""

import re
from typing import List, Dict, Optional
from errors import ValidationError
from config import Config, SecurityConfig


def validate_page_id(page_id: str) -> None:
    """
    验证 page_id 格式

    Args:
        page_id: 页面ID

    Raises:
        ValidationError: 如果验证失败
    """
    if not page_id:
        raise ValidationError("page_id 不能为空", {"field": "page_id"})

    if not isinstance(page_id, str):
        raise ValidationError(
            "page_id 必须是字符串", {"field": "page_id", "type": type(page_id).__name__}
        )

    if len(page_id) > Config.MAX_PAGE_ID_LENGTH:
        raise ValidationError(
            f"page_id 长度不能超过 {Config.MAX_PAGE_ID_LENGTH} 字符",
            {"field": "page_id", "length": len(page_id)},
        )

    if not re.match(r"^[a-zA-Z0-9\-_]+$", page_id):
        raise ValidationError(
            "page_id 包含无效字符",
            {"field": "page_id", "hint": "只允许字母、数字、连字符和下划线"},
        )


def validate_owner_id(owner_id: str) -> None:
    """
    验证 owner_id 格式

    Args:
        owner_id: 用户/所有者ID

    Raises:
        ValidationError: 如果验证失败
    """
    if not owner_id:
        raise ValidationError("owner_id 不能为空", {"field": "owner_id"})

    if not isinstance(owner_id, str):
        raise ValidationError(
            "owner_id 必须是字符串",
            {"field": "owner_id", "type": type(owner_id).__name__},
        )

    if len(owner_id) > 128:
        raise ValidationError(
            "owner_id 长度不能超过 128 字符",
            {"field": "owner_id", "length": len(owner_id)},
        )


def validate_query(query: str) -> None:
    """
    验证搜索查询

    Args:
        query: 搜索查询字符串

    Raises:
        ValidationError: 如果验证失败
    """
    if not query:
        raise ValidationError("query 不能为空", {"field": "query"})

    if not isinstance(query, str):
        raise ValidationError(
            "query 必须是字符串", {"field": "query", "type": type(query).__name__}
        )

    if len(query) > Config.MAX_QUERY_LENGTH:
        raise ValidationError(
            f"query 长度不能超过 {Config.MAX_QUERY_LENGTH} 字符",
            {"field": "query", "length": len(query)},
        )


def validate_conversation(conversation: List[Dict[str, str]]) -> None:
    """
    验证对话格式

    Args:
        conversation: 对话列表

    Raises:
        ValidationError: 如果验证失败
    """
    if not isinstance(conversation, list):
        raise ValidationError(
            "conversation 必须是列表", {"type": type(conversation).__name__}
        )

    if len(conversation) == 0:
        raise ValidationError("conversation 不能为空列表")

    if len(conversation) > SecurityConfig.MAX_CONVERSATION_LENGTH:
        raise ValidationError(
            f"conversation 长度不能超过 {SecurityConfig.MAX_CONVERSATION_LENGTH}",
            {"length": len(conversation)},
        )

    for i, msg in enumerate(conversation):
        if not isinstance(msg, dict):
            raise ValidationError(
                f"conversation[{i}] 必须是字典",
                {"index": i, "type": type(msg).__name__},
            )

        if "role" not in msg:
            raise ValidationError(f"conversation[{i}] 缺少 role 字段", {"index": i})

        if msg["role"] not in ("user", "agent"):
            raise ValidationError(
                f"conversation[{i}] role 必须是 user 或 agent",
                {"index": i, "role": msg["role"]},
            )

        if "content" not in msg:
            raise ValidationError(f"conversation[{i}] 缺少 content 字段", {"index": i})

        if not isinstance(msg["content"], str):
            raise ValidationError(
                f"conversation[{i}] content 必须是字符串", {"index": i}
            )

        if len(msg["content"].strip()) == 0:
            raise ValidationError(
                f"conversation[{i}] content 不能为空",
                {"index": i},
            )

        if len(msg["content"]) > SecurityConfig.MAX_MESSAGE_LENGTH:
            raise ValidationError(
                f"conversation[{i}] content 长度超过限制",
                {"index": i, "max_length": SecurityConfig.MAX_MESSAGE_LENGTH},
            )


def validate_merge_reason(merge_reason: str) -> None:
    """
    验证合并原因

    Args:
        merge_reason: 合并原因说明

    Raises:
        ValidationError: 如果验证失败
    """
    if merge_reason is not None:
        if not isinstance(merge_reason, str):
            raise ValidationError(
                "merge_reason 必须是字符串",
                {"field": "merge_reason", "type": type(merge_reason).__name__},
            )

        if len(merge_reason) > Config.MAX_MERGE_REASON_LENGTH:
            raise ValidationError(
                f"merge_reason 长度不能超过 {Config.MAX_MERGE_REASON_LENGTH} 字符",
                {"field": "merge_reason", "length": len(merge_reason)},
            )


def validate_page_ids(page_ids: List[str]) -> None:
    """
    验证页面ID列表

    Args:
        page_ids: 页面ID列表

    Raises:
        ValidationError: 如果验证失败
    """
    if not isinstance(page_ids, list):
        raise ValidationError("page_ids 必须是列表", {"type": type(page_ids).__name__})

    if len(page_ids) == 0:
        raise ValidationError("page_ids 不能为空列表")

    for i, page_id in enumerate(page_ids):
        try:
            validate_page_id(page_id)
        except ValidationError as e:
            raise ValidationError(
                f"page_ids[{i}] 无效: {e.message}", {"index": i, "details": e.details}
            )


def validate_time_range(time_range: Optional[Dict]) -> None:
    """
    验证时间范围

    Args:
        time_range: 时间范围字典 {"start": "YYYY-MM-DD", "end": "YYYY-MM-DD"}

    Raises:
        ValidationError: 如果验证失败
    """
    if time_range is None:
        return

    if not isinstance(time_range, dict):
        raise ValidationError(
            "time_range 必须是字典", {"type": type(time_range).__name__}
        )

    date_pattern = r"^\d{4}-\d{2}-\d{2}$"

    if "start" in time_range:
        if not isinstance(time_range["start"], str):
            raise ValidationError("time_range.start 必须是字符串")
        if not re.match(date_pattern, time_range["start"]):
            raise ValidationError(
                "time_range.start 格式无效", {"hint": "应为 YYYY-MM-DD 格式"}
            )

    if "end" in time_range:
        if not isinstance(time_range["end"], str):
            raise ValidationError("time_range.end 必须是字符串")
        if not re.match(date_pattern, time_range["end"]):
            raise ValidationError(
                "time_range.end 格式无效", {"hint": "应为 YYYY-MM-DD 格式"}
            )

    if "start" in time_range and "end" in time_range:
        if time_range["start"] > time_range["end"]:
            raise ValidationError(
                "time_range.start 不能大于 time_range.end",
                {"start": time_range["start"], "end": time_range["end"]},
            )
