import re
import threading
from enum import Enum
from typing import List, Dict, Optional
from logger import get_logger


class Priority(Enum):
    """对话处理优先级"""

    CRITICAL = "critical"
    HIGH = "high"
    NORMAL = "normal"


class PriorityDetector:
    """优先级检测器 - 根据内容判断处理优先级"""

    CRITICAL_PATTERNS = [
        r"(紧急|重要|立刻|马上|现在|快|急)",
        r"(记住|别忘了|一定要|必须)",
        r"(密码|账号|安全|隐私)",
        r"(错误|失败|异常|问题)",
        r"(明天的日程|今天的安排|日程提醒)",
    ]

    HIGH_PATTERNS = [
        r"(计划|安排|会议|约会)",
        r"(生日|纪念日|节日)",
        r"(地址|电话|邮箱)",
        r"(喜欢|偏好|习惯)",
        r"(下周|这个月|今年)",
    ]

    IMPORTANT_TOPICS = [
        "项目",
        "工作",
        "任务",
        "会议",
        "日程",
        "偏好",
        "习惯",
        "名字",
        "生日",
        "旅行",
        "计划",
        "目标",
    ]

    def __init__(self):
        self._critical_re = [
            re.compile(p, re.IGNORECASE) for p in self.CRITICAL_PATTERNS
        ]
        self._high_re = [re.compile(p, re.IGNORECASE) for p in self.HIGH_PATTERNS]
        self.logger = get_logger("priority_detector")
        self._stats = {
            "total_detected": 0,
            "critical_count": 0,
            "high_count": 0,
            "normal_count": 0,
        }

    def detect_priority(self, conversation: List[Dict[str, str]]) -> Priority:
        """检测对话优先级"""
        if not conversation:
            return Priority.NORMAL

        self._stats["total_detected"] += 1

        user_messages = [
            msg.get("content", "") for msg in conversation if msg.get("role") == "user"
        ]
        full_text = " ".join(user_messages)

        for pattern in self._critical_re:
            if pattern.search(full_text):
                self._stats["critical_count"] += 1
                self.logger.debug(
                    "CRITICAL_DETECTED", pattern=pattern.pattern, preview=full_text[:30]
                )
                return Priority.CRITICAL

        for pattern in self._high_re:
            if pattern.search(full_text):
                self._stats["high_count"] += 1
                self.logger.debug(
                    "HIGH_PRIORITY_DETECTED",
                    pattern=pattern.pattern,
                    preview=full_text[:30],
                )
                return Priority.HIGH

        for topic in self.IMPORTANT_TOPICS:
            if topic in full_text:
                self._stats["high_count"] += 1
                self.logger.debug(
                    "IMPORTANT_TOPIC_DETECTED", topic=topic, preview=full_text[:30]
                )
                return Priority.HIGH

        self._stats["normal_count"] += 1
        return Priority.NORMAL

    def get_stats(self) -> Dict:
        """获取统计信息"""
        critical_rate = self._stats["critical_count"] / max(
            self._stats["total_detected"], 1
        )
        high_rate = self._stats["high_count"] / max(self._stats["total_detected"], 1)
        return {
            **self._stats,
            "critical_rate": f"{critical_rate:.2%}",
            "high_rate": f"{high_rate:.2%}",
        }

    def reset_stats(self):
        """重置统计"""
        self._stats = {
            "total_detected": 0,
            "critical_count": 0,
            "high_count": 0,
            "normal_count": 0,
        }


_detector: Optional[PriorityDetector] = None
_detector_lock = threading.Lock()


def get_priority_detector() -> PriorityDetector:
    """获取优先级检测器单例"""
    global _detector
    if _detector is None:
        with _detector_lock:
            if _detector is None:
                _detector = PriorityDetector()
    return _detector
