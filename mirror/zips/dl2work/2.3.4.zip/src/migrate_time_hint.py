"""
数据迁移脚本：修复现有数据的 time_hint 字段
将相对时间转换为绝对时间
"""

import sys
import os
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(__file__))

from memory_core import get_memory_db


def migrate_time_hints():
    """迁移现有数据的 time_hint"""
    db = get_memory_db()
    cursor = db.conn.cursor()

    # 查询所有使用相对时间的记录
    relative_time_keywords = [
        "今天",
        "明天",
        "昨天",
        "本周",
        "下周",
        "上周",
        "本月",
        "下月",
        "上月",
        "一周后",
        "一周前",
        "一个月后",
    ]

    cursor.execute(
        "SELECT page_id, time_hint, created_at FROM l1_pages WHERE is_archived = 0"
    )
    rows = cursor.fetchall()

    updates = []
    stats = {
        "total_scanned": len(rows),
        "relative_time_found": 0,
        "migrated": 0,
        "skipped": 0,
    }

    for row in rows:
        page_id, old_hint, created_at = row

        is_relative = any(kw in old_hint for kw in relative_time_keywords)

        if not is_relative and old_hint:
            stats["skipped"] += 1
            continue

        if is_relative:
            stats["relative_time_found"] += 1

        try:
            if not created_at:
                print(f"警告: page_id={page_id} 缺少 created_at，使用当前日期")
                created_date = datetime.now().date()
            else:
                created_date = datetime.fromisoformat(
                    created_at.replace("Z", "+00:00")
                ).date()

            if "今天" in old_hint or not old_hint:
                event_date = created_date
                new_hint = event_date.strftime("%Y-%m-%d")
            elif "明天" in old_hint:
                event_date = created_date + timedelta(days=1)
                new_hint = event_date.strftime("%Y-%m-%d")
            elif "昨天" in old_hint:
                event_date = created_date - timedelta(days=1)
                new_hint = event_date.strftime("%Y-%m-%d")
            elif "一周后" in old_hint:
                event_date = created_date + timedelta(days=7)
                new_hint = event_date.strftime("%Y-%m-%d")
            elif "一周前" in old_hint:
                event_date = created_date - timedelta(days=7)
                new_hint = event_date.strftime("%Y-%m-%d")
            elif any(kw in old_hint for kw in ["本周", "本月", "上月", "下周", "下月"]):
                new_hint = created_date.strftime("%Y-%m")
                event_date = created_date
            else:
                new_hint = created_date.strftime("%Y-%m-%d")
                event_date = created_date

            updates.append((new_hint, event_date.strftime("%Y-%m-%d"), page_id))
            stats["migrated"] += 1

        except Exception as e:
            print(f"迁移失败 page_id={page_id}: {e}")
            stats["skipped"] += 1

    # 批量更新
    if updates:
        cursor.executemany(
            "UPDATE l1_pages SET time_hint = ?, event_date = ? WHERE page_id = ?",
            updates,
        )
        db.conn.commit()

    print("\n=== 迁移统计 ===")
    print(f"扫描记录总数: {stats['total_scanned']}")
    print(f"发现相对时间: {stats['relative_time_found']}")
    print(f"成功迁移: {stats['migrated']}")
    print(f"跳过: {stats['skipped']}")

    return stats


if __name__ == "__main__":
    print("开始迁移 time_hint 数据...")
    migrate_time_hints()
    print("迁移完成！")
