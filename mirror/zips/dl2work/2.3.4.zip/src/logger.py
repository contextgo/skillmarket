import logging
import json
import time
import threading
from pathlib import Path
from functools import wraps
from typing import Optional, Dict, Any


class StructuredLogger:
    """结构化日志记录器"""

    def __init__(
        self,
        name: str,
        level: int = logging.INFO,
        log_dir: str = "logs",
        enable_console: bool = True,
    ):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)
        self.logger.handlers.clear()

        log_path = Path(log_dir)
        log_path.mkdir(exist_ok=True)

        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
        )

        if enable_console:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)

        file_handler = logging.FileHandler(
            log_path / f"{name}_{time.strftime('%Y%m%d')}.log"
        )
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)

    def log(self, level: int, message: str, **kwargs):
        """结构化日志输出"""
        if kwargs:
            extra = " | " + " | ".join(f"{k}={v}" for k, v in kwargs.items())
            message = message + extra
        self.logger.log(level, message)

    def debug(self, message: str, **kwargs):
        self.log(logging.DEBUG, message, **kwargs)

    def info(self, message: str, **kwargs):
        self.log(logging.INFO, message, **kwargs)

    def warning(self, message: str, **kwargs):
        self.log(logging.WARNING, message, **kwargs)

    def error(self, message: str, **kwargs):
        self.log(logging.ERROR, message, **kwargs)


def performance_log(logger: StructuredLogger, operation: str):
    """性能埋点装饰器"""

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.time()
            try:
                result = func(*args, **kwargs)
                elapsed = time.time() - start
                logger.debug(
                    f"PERF | {operation}",
                    duration_ms=f"{elapsed * 1000:.2f}",
                    status="success",
                )
                return result
            except Exception as e:
                elapsed = time.time() - start
                logger.error(
                    f"PERF | {operation}",
                    duration_ms=f"{elapsed * 1000:.2f}",
                    status="error",
                    error=type(e).__name__,
                )
                raise

        return wrapper

    return decorator


_loggers: Dict[str, StructuredLogger] = {}
_logger_lock = threading.Lock()


def get_logger(
    name: str = "agent-memory", level: int = logging.INFO
) -> StructuredLogger:
    """获取结构化日志记录器单例"""
    if name not in _loggers:
        with _logger_lock:
            if name not in _loggers:
                _loggers[name] = StructuredLogger(name, level)
    return _loggers[name]
