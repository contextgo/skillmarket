"""
Agent Memory 自定义异常类
提供标准化的错误处理机制
"""

import logging
from typing import Optional, Dict, Any


class MemoryBaseError(Exception):
    """记忆系统异常基类"""

    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "error": self.__class__.__name__,
            "message": self.message,
            "details": self.details,
        }


class ConfigurationError(MemoryBaseError):
    """配置错误"""
    pass


class DatabaseError(MemoryBaseError):
    """数据库操作错误"""
    pass


class LLMError(MemoryBaseError):
    """LLM 调用错误"""
    pass


class ValidationError(MemoryBaseError):
    """数据验证错误"""
    pass


class NotFoundError(MemoryBaseError):
    """资源未找到错误"""
    pass


class ArchiveError(MemoryBaseError):
    """归档操作错误"""
    pass


class MergeError(MemoryBaseError):
    """页面合并错误"""
    pass


class RateLimitError(MemoryBaseError):
    """速率限制错误"""
    pass


def setup_logging(level: str = "INFO", log_file: Optional[str] = None) -> logging.Logger:
    """
    配置日志系统

    Args:
        level: 日志级别 (DEBUG, INFO, WARNING, ERROR)
        log_file: 可选的日志文件路径

    Returns:
        配置好的 logger 实例
    """
    logger = logging.getLogger("agent_memory")

    if logger.handlers:
        logger.debug("日志系统已配置，跳过重复设置")
        return logger

    valid_levels = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
    if level.upper() not in valid_levels:
        logger.warning(f"无效的日志级别 '{level}'，使用 INFO")
        level = "INFO"

    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    if log_file:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    获取 logger 实例

    Args:
        name: 可选的 logger 名称

    Returns:
        logger 实例
    """
    base_name = "agent_memory"
    if name:
        return logging.getLogger(f"{base_name}.{name}")
    return logging.getLogger(base_name)
