import threading
import time
from typing import Callable, Dict, Optional, Any
from logger import get_logger


class MemoryPersistenceScheduler:
    """
    记忆持久化定时调度器

    功能：
    - 定时保存未持久化的记忆
    - 支持动态调整保存间隔
    - 异步执行不阻塞主流程
    """

    def __init__(
        self,
        save_handler: Callable,
        initial_interval_hours: float = 1.0,
        max_interval_hours: float = 5.0,
        min_interval_hours: float = 0.5,
    ):
        self.save_handler = save_handler
        self.interval_hours = initial_interval_hours  # ✅ 保持小时单位
        self.max_interval_hours = max_interval_hours
        self.min_interval_hours = min_interval_hours

        # ✅ 转换为秒用于实际睡眠
        self.interval_seconds = initial_interval_hours * 3600
        self.max_interval_seconds = max_interval_hours * 3600
        self.min_interval_seconds = min_interval_hours * 3600

        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

        self.logger = get_logger("memory_scheduler")
        self._save_stats = {
            "total_saves": 0,
            "saved_pages": 0,
            "failed_saves": 0,
            "last_save_time": None,
        }

    def start(self):
        """启动定时任务"""
        with self._lock:
            if self._running:
                self.logger.warning("SCHEDULER_ALREADY_RUNNING")
                return

            self._running = True
            self._thread = threading.Thread(target=self._run_scheduler, daemon=True)
            self._thread.start()
            self.logger.info("SCHEDULER_STARTED", interval_hours=self.interval_hours)

    def stop(self, force_save: bool = True):
        """停止定时任务

        Args:
            force_save: 是否在停止前强制保存一次（推荐True）
        """
        with self._lock:
            self._running = False

            # ✅ 强制保存一次，防止数据丢失
            if force_save:
                self.logger.info("EXIT_SAVE_TRIGGERED")
                try:
                    self._execute_save()
                except Exception as e:
                    self.logger.error("EXIT_SAVE_FAILED", error=str(e))

            if self._thread:
                self._thread.join(timeout=30)  # ✅ 增加等待时间到30秒
                if self._thread.is_alive():
                    self.logger.warning("THREAD_STILL_RUNNING_AFTER_TIMEOUT")

            self.logger.info("SCHEDULER_STOPPED")

    def adjust_interval(self, new_interval_hours: float):
        """
        动态调整保存间隔

        策略：
        - 记忆增长快 → 缩短间隔（更频繁保存）
        - 记忆增长慢 → 延长间隔（节省资源）
        """
        with self._lock:
            new_interval_hours = max(
                self.min_interval_hours,
                min(self.max_interval_hours, new_interval_hours),
            )

            if new_interval_hours != self.interval_hours:
                old_interval_hours = self.interval_hours
                self.interval_hours = new_interval_hours
                self.interval_seconds = new_interval_hours * 3600  # ✅ 同步更新秒数
                self.logger.info(
                    "INTERVAL_ADJUSTED",
                    old_hours=old_interval_hours,
                    new_hours=new_interval_hours,
                    reason="dynamic_adjustment",
                )

    def force_save(self) -> Dict[str, int]:
        """强制立即保存（用于重要时刻）"""
        self.logger.info("FORCE_SAVE_TRIGGERED")
        return self._execute_save()

    def _run_scheduler(self):
        """调度器主循环"""
        while self._running:
            try:
                time.sleep(self.interval_seconds)  # ✅ 修复：使用秒数

                if not self._running:
                    break

                self._execute_save()
                self._auto_adjust_interval()

            except Exception as e:
                self.logger.error("SCHEDULER_ERROR", error=str(e))
                time.sleep(60)

    def _execute_save(self) -> Dict[str, int]:
        """执行保存操作"""
        try:
            start = time.time()

            saved_count = self.save_handler()

            elapsed = time.time() - start

            self._save_stats["total_saves"] += 1
            self._save_stats["saved_pages"] += saved_count
            self._save_stats["last_save_time"] = time.strftime("%Y-%m-%d %H:%M:%S")

            self.logger.info(
                "MEMORY_SAVED",
                saved_pages=saved_count,
                duration_ms=f"{elapsed * 1000:.1f}",
                total_saves=self._save_stats["total_saves"],
                last_save_time=self._save_stats["last_save_time"],
            )

            return {"saved": saved_count, "success": True}

        except Exception as e:
            self._save_stats["failed_saves"] += 1
            self.logger.error("SAVE_FAILED", error=str(e))
            return {"saved": 0, "success": False}

    def _auto_adjust_interval(self):
        """
        根据保存数据量自动调整间隔

        规则：
        - 保存页面数 > 10 → 缩短间隔（活跃期）
        - 保存页面数 < 2  → 延长间隔（低活跃期）
        """
        recent_saved = self._save_stats.get("saved_pages", 0)

        if recent_saved > 10:
            new_interval_hours = self.interval_hours * 0.8  # ✅ 修复：使用小时单位
            self.adjust_interval(new_interval_hours)

        elif recent_saved < 2:
            new_interval_hours = self.interval_hours * 1.2  # ✅ 修复：使用小时单位
            self.adjust_interval(new_interval_hours)

    def get_stats(self) -> Dict:
        """获取统计信息"""
        with self._lock:
            return {
                **self._save_stats,
                "current_interval_hours": self.interval_hours,  # ✅ 修复：使用小时单位
                "current_interval_seconds": self.interval_seconds,
                "is_running": self._running,
            }


_scheduler: Optional[MemoryPersistenceScheduler] = None
_scheduler_lock = threading.Lock()


def get_memory_scheduler(
    save_handler: Optional[Callable] = None,
    db_instance: Optional[Any] = None,
) -> MemoryPersistenceScheduler:
    """获取记忆调度器单例

    Args:
        save_handler: 保存回调函数，返回保存的页面数量
        db_instance: 数据库实例（可选）

    Returns:
        MemoryPersistenceScheduler 实例
    """
    global _scheduler
    if _scheduler is None:
        with _scheduler_lock:
            if _scheduler is None:
                if save_handler is None:
                    _db = db_instance

                    def default_save_handler() -> int:
                        """
                        默认保存逻辑：执行自动归档检查
                        返回归档的页面数量
                        """
                        nonlocal _db
                        if _db is None:
                            from memory_core import get_memory_db
                            _db = get_memory_db()

                        saved_count = 0
                        try:
                            cursor = _db.conn.cursor()
                            cursor.execute("SELECT DISTINCT owner_id FROM l1_pages WHERE is_archived = 0")
                            owners = [row[0] for row in cursor.fetchall()]

                            for owner_id in owners:
                                result = _db.auto_archive_old_pages(
                                    owner_id,
                                    days=180
                                )
                                if result.get("success"):
                                    saved_count += result.get("archived_count", 0)
                        except Exception as e:
                            _logger = get_logger("memory_scheduler")
                            _logger.error("AUTO_ARCHIVE_FAILED", error=str(e))
                        return saved_count

                    save_handler = default_save_handler
                _scheduler = MemoryPersistenceScheduler(save_handler)
    return _scheduler
