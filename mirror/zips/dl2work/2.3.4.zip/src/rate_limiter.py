"""
速率限制模块
基于滑动窗口的请求频率控制
"""

import time
import threading
from collections import defaultdict
from typing import Dict, Optional
from functools import wraps
from config import SecurityConfig
from errors import get_logger, RateLimitError

logger = get_logger("rate_limiter")


class RateLimiter:
    """滑动窗口速率限制器"""

    def __init__(
        self,
        requests_per_minute: int = SecurityConfig.RATE_LIMIT_REQUESTS_PER_MINUTE,
        window_seconds: int = 60,
        cleanup_interval_seconds: int = 300,
    ):
        self.requests_per_minute = requests_per_minute
        self.window_seconds = window_seconds
        self._buckets: Dict[str, list] = defaultdict(list)
        self._lock = threading.Lock()
        self._last_cleanup = time.time()
        self._cleanup_interval = cleanup_interval_seconds

    def _clean_old_requests(self, key: str, now: float) -> None:
        cutoff = now - self.window_seconds
        self._buckets[key] = [t for t in self._buckets[key] if t > cutoff]

    def _cleanup_empty_buckets(self) -> None:
        """清理空的或过期的 bucket，防止内存无限增长"""
        now = time.time()
        if now - self._last_cleanup < self._cleanup_interval:
            return

        self._last_cleanup = now
        cutoff = now - self.window_seconds * 2

        keys_to_delete = []
        for key, timestamps in self._buckets.items():
            if not timestamps or all(t < cutoff for t in timestamps):
                keys_to_delete.append(key)

        for key in keys_to_delete:
            del self._buckets[key]

        if keys_to_delete:
            logger.debug(f"清理了 {len(keys_to_delete)} 个过期的速率限制 bucket")

    def check_rate_limit(self, identifier: str) -> tuple[bool, int]:
        """
        检查是否超过速率限制

        Args:
            identifier: 客户端标识符（如 owner_id 或 API key）

        Returns:
            (是否允许, 剩余请求数)
        """
        if not SecurityConfig.RATE_LIMIT_ENABLED:
            return True, self.requests_per_minute

        now = time.time()
        with self._lock:
            self._cleanup_empty_buckets()
            self._clean_old_requests(identifier, now)
            current_count = len(self._buckets[identifier])
            remaining = max(0, self.requests_per_minute - current_count)

            if self.requests_per_minute == 0:
                return False, 0

            if current_count >= self.requests_per_minute:
                oldest = min(self._buckets[identifier])
                retry_after = int(oldest + self.window_seconds - now) + 1
                retry_after = max(1, retry_after)
                logger.warning(f"速率限制触发: {identifier}, 剩余 {retry_after} 秒")
                return False, 0

            self._buckets[identifier].append(now)
            return True, remaining - 1

    def reset(self, identifier: str) -> None:
        """重置指定标识符的速率限制"""
        with self._lock:
            if identifier in self._buckets:
                del self._buckets[identifier]


_rate_limiter: Optional[RateLimiter] = None


def get_rate_limiter() -> RateLimiter:
    global _rate_limiter
    if _rate_limiter is None:
        _rate_limiter = RateLimiter()
    return _rate_limiter


def rate_limit(identifier_func=None):
    """
    速率限制装饰器

    Args:
        identifier_func: 从函数参数提取标识符的函数，默认使用 owner_id

    使用方式:
        @rate_limit()
        def api_method(owner_id, ...):
            pass

        @rate_limit(lambda args: args.get("api_key"))
        def api_method(**kwargs):
            pass
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            limiter = get_rate_limiter()

            if identifier_func:
                identifier = identifier_func(kwargs)
            else:
                identifier = kwargs.get("owner_id") or kwargs.get(
                    "auth_context", {}
                ).get("owner_id", "anonymous")

            allowed, remaining = limiter.check_rate_limit(identifier)

            if not allowed:
                raise RateLimitError(
                    "请求过于频繁，请稍后再试",
                    {
                        "retry_after": 60,
                        "limit": SecurityConfig.RATE_LIMIT_REQUESTS_PER_MINUTE,
                    },
                )

            kwargs["rate_limit_remaining"] = remaining
            return func(*args, **kwargs)

        return wrapper

    return decorator
