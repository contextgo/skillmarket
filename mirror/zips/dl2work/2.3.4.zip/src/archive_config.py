"""
归档策略配置
符合设计蓝图 §5.2 的归档规则
"""

import logging
from typing import Dict, Any, Optional
from datetime import datetime, timezone
from config import Config

logger = logging.getLogger("archive")


class ArchiveConfig:
    """归档配置管理"""

    DEFAULT_RULES = {
        "page_idle_days": Config.DEFAULT_PAGE_IDLE_DAYS,
        "merged_page_grace_days": Config.DEFAULT_MERGED_PAGE_GRACE_DAYS,
        "profile_max_versions": Config.DEFAULT_PROFILE_MAX_VERSIONS,
        "max_active_pages_per_user": Config.DEFAULT_MAX_ACTIVE_PAGES_PER_USER,
        "archive_retention_days": Config.DEFAULT_ARCHIVE_RETENTION_DAYS,
    }

    def __init__(self, custom_rules: Optional[Dict[str, Any]] = None):
        self.rules = {**self.DEFAULT_RULES, **(custom_rules or {})}

    def should_archive_page(self, page_data: Dict) -> bool:
        """判断页面是否应该归档"""
        created_at_str = page_data.get("created_at")
        if not created_at_str:
            return False

        try:
            created_at = datetime.fromisoformat(created_at_str)
            now = datetime.now(timezone.utc)

            idle_days = (now - created_at).days
            if idle_days >= self.rules["page_idle_days"]:
                return True

            if page_data.get("status") == "merged":
                merged_at_str = page_data.get("merged_at")
                if merged_at_str:
                    merged_at = datetime.fromisoformat(merged_at_str)
                    merged_days = (now - merged_at).days
                    if merged_days >= self.rules["merged_page_grace_days"]:
                        return True

            return False
        except ValueError as e:
            logger.warning(f"日期解析失败: {created_at_str}, 错误: {e}")
            return False
        except TypeError as e:
            logger.warning(f"类型错误: {e}")
            return False
        except Exception as e:
            logger.error(f"判断页面归档时发生未知错误: {e}", exc_info=True)
            return False

    def should_archive_profile(self, profile_data: Dict) -> bool:
        """判断画像是否应该归档"""
        version = profile_data.get("version", 0)
        updated_at_str = profile_data.get("updated_at")

        if not updated_at_str:
            return False

        try:
            updated_at = datetime.fromisoformat(updated_at_str)
            now = datetime.now(timezone.utc)
            inactive_days = (now - updated_at).days

            if inactive_days >= self.rules["page_idle_days"]:
                return True
        except ValueError:
            pass

        return False

    def update_rules(self, new_rules: Dict[str, Any]):
        """更新归档规则"""
        self.rules.update(new_rules)

    def get_rules(self) -> Dict[str, Any]:
        """获取当前规则"""
        return self.rules.copy()
