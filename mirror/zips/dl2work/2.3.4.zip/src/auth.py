"""
身份验证和授权模块
提供 API Key 认证和权限检查
"""

import os
import hashlib
import secrets
from typing import Optional, Dict, Callable
from functools import wraps
from errors import get_logger, ValidationError

logger = get_logger("auth")


class AuthManager:
    """身份验证管理器"""

    def __init__(self):
        self._key_hashes: Dict[str, str] = {}
        self._load_api_keys()

    def _load_api_keys(self) -> None:
        for key, value in os.environ.items():
            if key.startswith("API_KEY_"):
                owner_id = key[8:].lower()
                key_hash = self.hash_api_key(value)
                self._key_hashes[key_hash] = owner_id

    def verify_api_key(self, api_key: str) -> Optional[str]:
        if not api_key:
            return None

        key_hash = self.hash_api_key(api_key)
        owner_id = self._key_hashes.get(key_hash)
        if owner_id:
            logger.debug(f"API Key 验证成功")
        else:
            logger.warning(f"无效的 API Key")

        return owner_id

    @staticmethod
    def generate_api_key() -> str:
        return secrets.token_urlsafe(32)

    @staticmethod
    def hash_api_key(api_key: str) -> str:
        return hashlib.sha256(api_key.encode()).hexdigest()


class AuthorizationError(ValidationError):
    """授权错误"""

    pass


class AuthenticationError(ValidationError):
    """认证错误"""

    pass


# 全局认证管理器实例
_auth_manager: Optional[AuthManager] = None


def get_auth_manager() -> AuthManager:
    """获取认证管理器单例"""
    global _auth_manager
    if _auth_manager is None:
        _auth_manager = AuthManager()
    return _auth_manager


def require_auth(func: Callable) -> Callable:
    """
    认证装饰器 - 要求调用者提供有效的 API Key

    使用方式:
        @require_auth
        def some_api_method(self, ..., auth_context: Dict = None):
            owner_id = auth_context["owner_id"]
            ...

    调用时传入 auth_context 参数:
        result = api.some_method(..., auth_context={"api_key": "xxx"})
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        # 从 kwargs 提取 auth_context
        auth_context = kwargs.pop("auth_context", {})
        api_key = auth_context.get("api_key")

        if not api_key:
            raise AuthenticationError(
                "缺少认证信息", {"hint": "请在 auth_context 中提供 api_key"}
            )

        auth_manager = get_auth_manager()
        owner_id = auth_manager.verify_api_key(api_key)

        if not owner_id:
            raise AuthenticationError("认证失败", {"hint": "无效的 API Key"})

        # 将 owner_id 注入到 kwargs
        kwargs["auth_context"] = {"owner_id": owner_id, "authenticated": True}

        return func(*args, **kwargs)

    return wrapper


def verify_owner_access(requested_owner_id: str, auth_context: Dict) -> None:
    """
    验证调用者是否有权限访问指定 owner_id 的数据

    Args:
        requested_owner_id: 请求访问的 owner_id
        auth_context: 认证上下文（包含已认证的 owner_id）

    Raises:
        AuthorizationError: 如果权限验证失败
    """
    if not auth_context.get("authenticated"):
        raise AuthorizationError("未认证的请求", {"hint": "请先通过身份验证"})

    authenticated_owner = auth_context.get("owner_id")

    if authenticated_owner != requested_owner_id:
        logger.warning(
            f"跨用户访问尝试: authenticated={authenticated_owner}, requested={requested_owner_id}"
        )
        raise AuthorizationError(
            "无权访问该资源",
            {
                "hint": "您只能访问自己的数据",
                "requested_owner": requested_owner_id,
            },
        )


def optional_auth(func: Callable) -> Callable:
    """
    可选认证装饰器 - 如果提供了 API Key 则验证，否则继续执行

    用于向后兼容或某些不需要强制认证的端点
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        auth_context = kwargs.pop("auth_context", {})
        api_key = auth_context.get("api_key")

        if api_key:
            auth_manager = get_auth_manager()
            owner_id = auth_manager.verify_api_key(api_key)
            if owner_id:
                kwargs["auth_context"] = {"owner_id": owner_id, "authenticated": True}
            else:
                kwargs["auth_context"] = {"authenticated": False}
        else:
            kwargs["auth_context"] = {"authenticated": False}

        return func(*args, **kwargs)

    return wrapper
