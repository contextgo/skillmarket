"""
LLM 处理模块
负责调用 LLM 进行信息分类、摘要生成、关键词提取
使用 MiniMax API（OpenAI 兼容格式，urllib 实现）
"""

import hashlib
import threading
import time
import json
import os
import urllib.request
import urllib.error
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field

from errors import get_logger, LLMError, ConfigurationError, ValidationError
from config import Config, SecurityConfig
from retry_utils import retry_with_backoff
from logger import get_logger as get_structured_logger

logger = get_logger("llm")
structured_logger = get_structured_logger("llm_processor")


@dataclass
class ProcessResult:
    """处理结果"""

    info_type: str  # waste, profile, event
    profile_updates: Optional[List[Dict]] = field(default_factory=list)
    event_data: Optional[Dict] = field(default_factory=dict)
    summary: str = ""
    keywords: Optional[Dict[str, List[str]]] = field(default_factory=dict)
    entities: Optional[List[Dict]] = field(default_factory=list)
    key_facts: Optional[List[str]] = field(default_factory=list)
    conclusion: str = ""
    implied_preferences: Optional[List[str]] = field(default_factory=list)
    error: Optional[str] = field(default=None)


class LLMProcessor:
    """LLM 处理器 - MiniMax API 版本"""

    # MiniMax API 端点（OpenAI 兼容格式）
    API_BASE = "https://api.minimaxi.com/v1"
    MODEL = "MiniMax-M2.7"

    # 系统提示词
    CLASSIFY_PROMPT = """你是一个信息分类专家。请分析用户对话，识别其中的信息类型。

信息类型定义：
- waste: 无意义的闲聊、问候、客套话等
- profile: 用户偏好、习惯、背景信息等（这些对理解用户很重要）
- event: 有意义的事件、行动、决定等

【重要】你必须只返回一个纯净的 JSON 对象，不要包含任何思考过程、代码块标记或额外文字。
格式：
{"type": "waste"|"profile"|"event","reason": "分类理由"}
"""

    # 画像提取提示词
    PROFILE_EXTRACT_PROMPT = """从对话中提取用户偏好和背景信息。

返回 JSON 格式：
{
    "preferences": {
        "communication_style": "直接/委婉/简洁/详细",
        "response_length": "短/中/长",
        "topics_interest": ["话题1", "话题2"],
        "topics_avoid": ["避免话题"]
    },
    "habits": {
        "work_hours": "工作时间描述",
        "preferred_language": "首选语言"
    },
    "background": {
        "occupation": "职业",
        "expertise_areas": ["专业领域"],
        "interests": ["兴趣爱好"]
    },
    "facts": {
        "location": "地理位置",
        "custom_facts": {}
    }
}

如果没有提取到任何信息，返回空对象 {}。
"""

    # 事件摘要提示词
    EVENT_SUMMARY_PROMPT = """分析对话，提取关键事件信息。

返回 JSON 格式：
{
    "summary": "用1-3句话概括事件",
    "entities": [
        {"type": "person/object/location/action", "name": "名称", "role": "角色"}
    ],
    "key_facts": ["关键事实1", "关键事实2"],
    "conclusion": "如果有明确结论，记录在此",
    "implied_preferences": ["从事件推断的用户偏好"]
}

时间信息请用 time_hint 字段描述，如 "2026-04" 或 "上周" 等。
"""

    # 关键词提取提示词
    KEYWORDS_EXTRACT_PROMPT = """从事件摘要中提取关键词，用于信息检索。

【重要】time_hint 规则更新（强制转换为绝对时间）：
- 必须转换为绝对时间，格式：YYYY-MM-DD 或 YYYY-MM
- 例如：
  - 对话中"今天" → 转换为对话发生当天的日期（YYYY-MM-DD）
  - 对话中"一周后" → 计算具体日期（YYYY-MM-DD）
  - 对话中"上周" → 转换为具体月份（YYYY-MM）
  - 对话中"本月" → 转换为具体月份（YYYY-MM）
- 禁止存储相对时间词（今天/明天/下周/上周等）
- 如果无法确定具体日期，使用当前日期作为基准

返回 JSON 格式（严格纯净 JSON，不要思考过程）：
{
    "event_type": ["事件类型关键词"],
    "who": ["参与者关键词"],
    "where": ["地点关键词"],
    "what": ["动作/对象关键词"],
    "when": ["时间关键词（已转换为绝对时间）"],
    "why": ["原因/目的关键词"],
    "merge_hints": ["可能需要合并的相关关键词"],
    "time_hint": "绝对时间 YYYY-MM-DD 或 YYYY-MM（禁止相对时间词）",
    "event_date": "对话发生的日期 YYYY-MM-DD",
    "similarity_seeds": ["用于相似度计算的种子词（核心概念）"]
}
"""

    UNIFIED_PROCESS_PROMPT = """分析以下对话，完成信息分类和关键信息提取。

【输入】
对话内容：
{conversation}
当前日期（用于时间转换）：{current_date}

【任务】
1. 分类：判断是 waste(无意义闲聊)、profile(用户画像)、还是 event(重要事件)

2. 如果是 event，额外提取：
   - summary: 1-3句话概括事件
   - entities: 关键人物/对象/地点
   - key_facts: 关键事实列表
   - conclusion: 结论（如果有）
   - keywords: 关键词（event_type, who, where, what, when, why）
   - time_hint: 绝对时间（YYYY-MM-DD 或 YYYY-MM），将相对时间转换为绝对时间
   - event_date: 对话发生的日期（YYYY-MM-DD）
   - similarity_seeds: 相似度计算种子词

3. 如果是 profile，提取：
   - preferences: 用户偏好
   - habits: 用户习惯
   - background: 背景信息

【time_hint 转换规则】（重要）
- 相对时间 → 绝对时间转换
- 以当前日期 {current_date} 为基准计算
- "今天" → {current_date}
- "明天" → {current_date} + 1天
- "一周后" → {current_date} + 7天
- "上周" → 上周的月份 YYYY-MM
- 禁止返回相对时间词（今天/明天/下周等）

【输出格式】（严格纯净JSON，不要思考过程）
{
    "type": "waste"|"profile"|"event",
    "reason": "分类理由",
    "summary": "事件摘要（仅event）",
    "entities": [...],
    "key_facts": [...],
    "conclusion": "...",
    "implied_preferences": [...],
    "keywords": {
        "event_type": [...],
        "who": [...],
        "where": [...],
        "what": [...],
        "when": [...],
        "why": [...],
        "merge_hints": [...],
        "time_hint": "YYYY-MM-DD（绝对时间）",
        "event_date": "YYYY-MM-DD",
        "similarity_seeds": [...]
    },
    "preferences": {...},
    "habits": {...},
    "background": {...}
}

【重要】只返回纯净JSON，不要思考过程，不要代码块标记。
"""

    def __init__(self, api_key: str = None, model: str = None, validate: bool = True):
        self.model = model or self.MODEL
        # 安全加载 API Key - 不存储在实例变量中
        self._api_key_hash = None  # 仅存储哈希值用于验证
        api_key_source = (
            api_key or os.getenv("MINIMAX_API_KEY") or os.getenv("OPENAI_API_KEY")
        )

        if api_key_source:
            self._api_key_hash = hashlib.sha256(api_key_source.encode()).hexdigest()
            self._validated = True
            if validate:
                try:
                    self.validate_api_key(api_key_source)
                except ConfigurationError:
                    raise
                except Exception as e:
                    logger.warning("API Key 验证过程中出错")
                    self._validated = False
            # 清空明文密钥引用
            api_key_source = None
        else:
            logger.warning("未找到 API Key，LLM 调用将会失败")
            self._validated = False

    def _get_api_key(self) -> str:
        """从环境变量获取 API Key（不存储在实例中）"""
        return os.getenv("MINIMAX_API_KEY") or os.getenv("OPENAI_API_KEY")

    def validate_api_key(self, api_key: str = None) -> bool:
        """验证 API Key 是否有效（使用 /chat/completions 端点测试）"""
        api_key = api_key or self._get_api_key()
        if not api_key:
            raise ConfigurationError(
                "API Key 未设置",
                {"hint": "请设置 MINIMAX_API_KEY 或 OPENAI_API_KEY 环境变量"},
            )
        try:
            url = f"{self.API_BASE}/chat/completions"
            payload = {
                "model": self.model,
                "messages": [{"role": "user", "content": "Hi"}],
                "max_tokens": 5,
            }
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                method="POST",
            )
            with urllib.request.urlopen(
                req, timeout=Config.LLM_TIMEOUT_SECONDS
            ) as response:
                if response.status == 200:
                    self._validated = True
                    logger.info("API Key 验证成功")
                    return True
        except urllib.error.HTTPError as e:
            error_msg = SecurityConfig.sanitize_error_message(str(e.reason))
            logger.error(f"API Key 验证失败 (HTTP {e.code})")
            raise ConfigurationError(
                "API Key 验证失败",
                {"hint": "请检查 API Key 是否正确"},
            )
        except urllib.error.URLError as e:
            logger.warning("API Key 验证超时")
        except Exception as e:
            logger.warning(f"API Key 验证出错: {e}")

        self._validated = False
        return False

    @retry_with_backoff(max_retries=3, base_delay=1.0, max_delay=10.0)
    def _estimate_tokens(self, text: str) -> int:
        """
        估算 Token 数量（改进估算）
        - 中文: 约 1.5-1.8 字符/token (取 1.65)
        - 英文: 约 3-4 字符/token (取 3.5)
        - 数字/符号: 约 2-3 字符/token (取 2.5)
        """
        chinese_chars = sum(1 for c in text if "\u4e00" <= c <= "\u9fff")
        ascii_chars = sum(1 for c in text if c.isascii() and not c.isspace())
        other_chars = (
            len(text)
            - chinese_chars
            - ascii_chars
            - sum(1 for c in text if c.isspace())
        )
        return int(chinese_chars * 1.65 + ascii_chars * 0.29 + other_chars * 0.4)

    def _call_llm(self, system_prompt: str, user_prompt: str) -> str:
        """调用 MiniMax LLM（OpenAI 兼容格式，带日志）"""
        start = time.time()

        api_key = self._get_api_key()
        if not api_key:
            structured_logger.warning("LLM_CALL_FAILED", reason="api_key_missing")
            return "{}"

        input_tokens = self._estimate_tokens(system_prompt + user_prompt)
        structured_logger.info(
            "LLM_REQUEST",
            model=self.model,
            input_tokens=input_tokens,
            prompt_preview=user_prompt[:50] + "..."
            if len(user_prompt) > 50
            else user_prompt,
        )

        url = f"{self.API_BASE}/chat/completions"
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": Config.LLM_TEMPERATURE,
            "max_tokens": Config.LLM_MAX_TOKENS,
        }

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(
                req, timeout=Config.LLM_TIMEOUT_SECONDS * 3
            ) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                content = result["choices"][0]["message"]["content"]

                elapsed = time.time() - start
                output_tokens = self._estimate_tokens(content)

                structured_logger.info(
                    "LLM_RESPONSE",
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                    duration_ms=f"{elapsed * 1000:.1f}",
                    response_length=len(content),
                )

                return content
        except urllib.error.HTTPError as e:
            elapsed = time.time() - start
            error_msg = SecurityConfig.sanitize_error_message(str(e.reason))
            structured_logger.error(
                "LLM_HTTP_ERROR",
                http_code=e.code,
                duration_ms=f"{elapsed * 1000:.1f}",
                error_preview=error_msg[:50],
            )
            raise LLMError("API 调用失败", {"http_code": e.code})
        except urllib.error.URLError as e:
            elapsed = time.time() - start
            structured_logger.error(
                "LLM_NETWORK_ERROR",
                duration_ms=f"{elapsed * 1000:.1f}",
                error_type="url_error",
            )
            raise LLMError("网络错误", {"hint": "请检查网络连接"})
        except (KeyError, IndexError) as e:
            elapsed = time.time() - start
            structured_logger.error(
                "LLM_FORMAT_ERROR",
                duration_ms=f"{elapsed * 1000:.1f}",
                error_type="format_error",
            )
            raise LLMError("响应格式错误", {"hint": "API 返回了意外的响应格式"})
        except json.JSONDecodeError as e:
            elapsed = time.time() - start
            structured_logger.error(
                "LLM_JSON_ERROR",
                duration_ms=f"{elapsed * 1000:.1f}",
                error_type="json_decode_error",
            )
            raise LLMError("JSON 解析错误", {"hint": "API 返回了无效的 JSON"})

    def classify(self, conversation: List[Dict[str, str]]) -> str:
        """分类对话内容"""
        formatted_conv = "\n".join(
            [
                f"{msg.get('role', 'unknown')}: {msg.get('content', '')}"
                for msg in conversation
            ]
        )

        result = self._call_llm(self.CLASSIFY_PROMPT, formatted_conv)

        try:
            # 尝试从思考块中提取 JSON
            import re

            # 去掉 <think>...</think> 块
            cleaned = re.sub(r"<think>.*?</think>", "", result, flags=re.DOTALL).strip()
            data = json.loads(cleaned)
            return data.get("type", "waste")
        except json.JSONDecodeError:
            # 最后一搏：直接搜索 type 值
            import re

            m = re.search(r'"type"\s*:\s*"(waste|profile|event)"', result)
            return m.group(1) if m else "waste"

    def _parse_json(self, raw: str) -> dict:
        """安全解析 LLM 返回的 JSON，处理思考块和 markdown"""
        import re

        cleaned = raw.strip()

        # 处理各种格式的思考块
        think_patterns = [
            r"<think>.*?</think>",
            r"<think>.*?</think>",
            r"\[THINKING\].*?\[/THINKING\]",
            r"\{thought\}.*?\{/thought\}",
        ]
        for pattern in think_patterns:
            cleaned = re.sub(pattern, "", cleaned, flags=re.DOTALL | re.IGNORECASE)

        # 去掉 markdown 代码块（更健壮的处理）
        # 移除 ```json 或 ``` 开头的代码块标记
        cleaned = re.sub(r"^```(?:json)?\s*\n?", "", cleaned.strip())
        # 移除结尾的 ```
        cleaned = re.sub(r"\n?\s*```\s*$", "", cleaned)
        # 如果整个字符串被 ``` 包裹（没有换行）
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)

        # 去掉可能的前缀（如 "Here is the JSON:"）
        cleaned = re.sub(
            r"^(Here is|JSON:|Result:|Answer:)\s*", "", cleaned, flags=re.IGNORECASE
        )

        cleaned = cleaned.strip()

        if not cleaned:
            logger.warning("JSON 解析失败: 响应为空")
            return {}

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            logger.warning(
                f"JSON 解析失败: {e}, 响应长度={len(cleaned)}, "
                f"前50字符={cleaned[:50] if len(cleaned) > 50 else cleaned}"
            )

            json_match = re.search(r"\{[\s\S]*\}", cleaned)
            if json_match:
                try:
                    result = json.loads(json_match.group(0))
                    logger.info("JSON 提取成功（通过正则匹配）")
                    return result
                except json.JSONDecodeError as e2:
                    logger.warning(f"JSON 正则提取失败: {e2}")

            logger.error("JSON 解析完全失败，返回空字典")
            return {}

    def extract_profile(self, conversation: List[Dict[str, str]]) -> Dict:
        """提取用户画像"""
        formatted_conv = "\n".join(
            [
                f"{msg.get('role', 'unknown')}: {msg.get('content', '')}"
                for msg in conversation
            ]
        )

        result = self._call_llm(self.PROFILE_EXTRACT_PROMPT, formatted_conv)
        parsed = self._parse_json(result)
        return parsed if parsed else {}

    def summarize_event(self, conversation: List[Dict[str, str]]) -> Dict:
        """生成事件摘要"""
        formatted_conv = "\n".join(
            [
                f"{msg.get('role', 'unknown')}: {msg.get('content', '')}"
                for msg in conversation
            ]
        )

        result = self._call_llm(self.EVENT_SUMMARY_PROMPT, formatted_conv)
        parsed = self._parse_json(result)
        return (
            parsed
            if parsed
            else {
                "summary": "",
                "entities": [],
                "key_facts": [],
                "conclusion": "",
                "implied_preferences": [],
            }
        )

    def extract_keywords(self, summary_data: Dict) -> Dict:
        """提取关键词"""
        summary_text = json.dumps(summary_data, ensure_ascii=False)

        result = self._call_llm(self.KEYWORDS_EXTRACT_PROMPT, summary_text)
        parsed = self._parse_json(result)
        return (
            parsed
            if parsed
            else {
                "event_type": [],
                "who": [],
                "where": [],
                "what": [],
                "when": [],
                "why": [],
                "merge_hints": [],
                "time_hint": "",
                "event_date": "",
                "similarity_seeds": [],
            }
        )

    def process_conversation_unified(
        self, conversation: List[Dict[str, str]], current_date: str = None
    ) -> ProcessResult:
        """
        统一处理对话（单次LLM调用）
        合并classify+summarize+keywords为一个调用

        Args:
            conversation: 对话列表
            current_date: 当前日期（用于时间转换），格式 YYYY-MM-DD

        Returns:
            ProcessResult 处理结果
        """
        from datetime import datetime

        if current_date is None:
            current_date = datetime.now().strftime("%Y-%m-%d")

        formatted_conv = "\n".join(
            [f"{msg.get('role', '')}: {msg.get('content', '')}" for msg in conversation]
        )

        result = self._call_llm(
            self.UNIFIED_PROCESS_PROMPT.format(
                conversation=formatted_conv, current_date=current_date
            ),
            "",
        )

        data = self._parse_json(result)

        if not data:
            structured_logger.warning(
                "UNIFIED_PROCESS_PARSE_FAILED", reason="empty_json"
            )
            return ProcessResult(info_type="waste")

        info_type = data.get("type", "waste")

        result_obj = ProcessResult(info_type=info_type)

        if info_type == "waste":
            return result_obj

        elif info_type == "profile":
            result_obj.profile_updates = [
                {
                    "preferences": data.get("preferences", {}),
                    "habits": data.get("habits", {}),
                    "background": data.get("background", {}),
                }
            ]
            return result_obj

        elif info_type == "event":
            result_obj.summary = data.get("summary", "")
            result_obj.entities = data.get("entities", [])
            result_obj.key_facts = data.get("key_facts", [])
            result_obj.conclusion = data.get("conclusion", "")
            result_obj.implied_preferences = data.get("implied_preferences", [])

            keywords = data.get("keywords", {})
            result_obj.keywords = {
                "event_type": keywords.get("event_type", []),
                "who": keywords.get("who", []),
                "where": keywords.get("where", []),
                "what": keywords.get("what", []),
                "when": keywords.get("when", []),
                "why": keywords.get("why", []),
                "merge_hints": keywords.get("merge_hints", []),
                "time_hint": keywords.get("time_hint", ""),
                "event_date": keywords.get("event_date", ""),
                "similarity_seeds": keywords.get("similarity_seeds", []),
            }

            result_obj.event_data = {
                "content": formatted_conv,
                "summary": result_obj.summary,
                "entities": result_obj.entities,
                "key_facts": result_obj.key_facts,
                "conclusion": result_obj.conclusion,
                "implied_preferences": result_obj.implied_preferences,
                "keywords": result_obj.keywords,
            }

            return result_obj

        return ProcessResult(info_type="waste")

    def process_conversation(self, conversation: List[Dict[str, str]]) -> ProcessResult:
        """
        处理对话的完整流程
        一次调用完成分类、提取

        Args:
            conversation: 对话列表

        Returns:
            ProcessResult 处理结果

        Raises:
            ValidationError: 输入验证失败
        """
        # 输入验证
        if not conversation or not isinstance(conversation, list):
            raise ValidationError("conversation 必须是非空列表")

        if len(conversation) > SecurityConfig.MAX_CONVERSATION_LENGTH:
            raise ValidationError(
                f"对话长度超过限制 ({SecurityConfig.MAX_CONVERSATION_LENGTH})",
                {"length": len(conversation)},
            )

        for i, msg in enumerate(conversation):
            if not isinstance(msg, dict):
                raise ValidationError(f"conversation[{i}] 必须是字典")

            if "role" not in msg or "content" not in msg:
                raise ValidationError(f"conversation[{i}] 缺少必要字段")

            if msg["role"] not in ("user", "agent"):
                raise ValidationError(
                    f"conversation[{i}] role 必须是 user 或 agent",
                    {"index": i, "role": msg["role"]},
                )

            if len(msg.get("content", "")) > SecurityConfig.MAX_MESSAGE_LENGTH:
                raise ValidationError(
                    f"消息{i}长度超过限制",
                    {"index": i, "max_length": SecurityConfig.MAX_MESSAGE_LENGTH},
                )

        # 1. 分类
        info_type = self.classify(conversation)

        result = ProcessResult(info_type=info_type)

        if info_type == "waste":
            return result

        elif info_type == "profile":
            profile_data = self.extract_profile(conversation)
            result.profile_updates = [profile_data] if profile_data else []
            return result

        else:  # event
            summary_data = self.summarize_event(conversation)

            result.summary = summary_data.get("summary", "")
            result.entities = summary_data.get("entities", [])
            result.key_facts = summary_data.get("key_facts", [])
            result.conclusion = summary_data.get("conclusion", "")
            result.implied_preferences = summary_data.get("implied_preferences", [])

            keywords_data = self.extract_keywords(summary_data)
            result.keywords = {
                "event_type": keywords_data.get("event_type", []),
                "who": keywords_data.get("who", []),
                "where": keywords_data.get("where", []),
                "what": keywords_data.get("what", []),
                "when": keywords_data.get("when", []),
                "why": keywords_data.get("why", []),
                "merge_hints": keywords_data.get("merge_hints", []),
                "time_hint": keywords_data.get("time_hint", ""),
                "event_date": keywords_data.get("event_date", ""),
                "similarity_seeds": keywords_data.get("similarity_seeds", []),
            }

            result.event_data = {
                "content": "\n".join(
                    [
                        f"{msg.get('role', '')}: {msg.get('content', '')}"
                        for msg in conversation
                    ]
                ),
                "summary": result.summary,
                "entities": result.entities,
                "key_facts": result.key_facts,
                "conclusion": result.conclusion,
                "implied_preferences": result.implied_preferences,
                "keywords": result.keywords,
            }

            return result

    def merge_summaries(self, summaries: List[Dict]) -> Dict:
        """
        合并多个事件摘要

        Args:
            summaries: 摘要列表，每个包含 summary, entities, key_facts 等

        Returns:
            合并后的摘要字典
        """
        merge_prompt = """合并多个事件摘要，生成一个统一的事件描述。

要求：
1. 合并关键事实，去重并保留最重要的信息
2. 合并实体列表，保留所有重要角色
3. 提炼统一的结论（如果有矛盾，说明矛盾点）
4. 保留所有隐含的用户偏好

返回 JSON 格式（严格纯净 JSON，不要思考过程）：
{
    "summary": "合并后的摘要（1-3句话）",
    "entities": [
        {"type": "person/object/location/action", "name": "名称", "role": "角色"}
    ],
    "key_facts": ["关键事实1", "关键事实2"],
    "conclusion": "如果有多条结论，整合或说明矛盾",
    "implied_preferences": ["从事件推断的用户偏好"]
}
"""

        input_text = json.dumps(summaries, ensure_ascii=False, indent=2)
        result = self._call_llm(merge_prompt, input_text)
        parsed = self._parse_json(result)

        return (
            parsed
            if parsed
            else {
                "summary": "合并的事件",
                "entities": [],
                "key_facts": [],
                "conclusion": "",
                "implied_preferences": [],
            }
        )


_processor: Optional[LLMProcessor] = None
_processor_lock = threading.Lock()


def get_llm_processor() -> LLMProcessor:
    """获取 LLM 处理器单例"""
    global _processor
    if _processor is None:
        with _processor_lock:
            if _processor is None:
                _processor = LLMProcessor()
    return _processor
