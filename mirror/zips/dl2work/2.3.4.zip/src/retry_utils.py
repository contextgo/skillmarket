"""
重试工具模块
提供指数退避重试装饰器
"""

import time
import functools
from typing import Callable
from errors import get_logger
from config import Config

logger = get_logger("retry")


def retry_with_backoff(
    max_retries: int = 3, base_delay: float = 1.0, max_delay: float = 10.0
):
    """
    指数退避重试装饰器

    Args:
        max_retries: 最大重试次数
        base_delay: 基础延迟时间（秒）
        max_delay: 最大延迟时间（秒）

    Returns:
        装饰器函数
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            retries = 0
            last_exception = None
            retry_after = None

            while True:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    retries += 1

                    if retries > max_retries:
                        break

                    should_retry = False
                    error_str = str(e).lower()
                    retry_after = None

                    if "429" in error_str or "rate limit" in error_str:
                        should_retry = True
                        retry_after = _extract_retry_after(e)
                    elif any(str(code) in error_str for code in [500, 502, 503, 504]):
                        should_retry = True
                    elif "timeout" in error_str or "timed out" in error_str:
                        should_retry = True
                    elif "connection" in error_str or "network" in error_str:
                        should_retry = True

                    if not should_retry:
                        logger.error(f"操作失败，不再重试: {e}")
                        raise

                    if retries >= max_retries:
                        break

                    if retry_after:
                        delay = min(retry_after, max_delay * 4)
                        logger.warning(
                            f"API 速率限制，等待 {delay:.1f}秒后重试 (Retry-After)"
                        )
                    else:
                        delay = min(base_delay * (2 ** (retries - 1)), max_delay)
                        logger.warning(
                            f"操作失败，{delay:.1f}秒后重试 "
                            f"(尝试 {retries}/{max_retries}): {e}"
                        )
                    time.sleep(delay)

            if last_exception is not None:
                logger.error(f"重试{max_retries}次后仍然失败")
                raise last_exception

        return wrapper

    return decorator


def _extract_retry_after(error: Exception) -> float:
    """
    从错误响应中提取 Retry-After 值

    Args:
        error: 异常对象，可能包含 HTTP 响应头信息

    Returns:
        Retry-After 秒数，如果未找到返回默认值
    """
    error_str = str(error)
    import re

    patterns = [
        r"retry-after:\s*(\d+)",
        r"Retry-After:\s*(\d+)",
        r"retry[-_]?after[:\s]+(\d+)",
        r"wait\s+(\d+)\s+seconds",
    ]

    for pattern in patterns:
        match = re.search(pattern, error_str, re.IGNORECASE)
        if match:
            return float(match.group(1))

    return Config.RETRY_DEFAULT_RETRY_AFTER_SECONDS
