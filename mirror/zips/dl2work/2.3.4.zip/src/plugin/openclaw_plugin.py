"""
OpenClaw Plugin - Agent Memory Tools
为 OpenClaw 注册记忆数据库工具
"""

import sys
import os
import json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from api import get_memory_api, MemoryAPI


def register(api):
    """
    OpenClaw 插件入口函数
    注册记忆数据库相关的工具
    """
    memory_api = MemoryAPI()

    api.registerTool(
        {
            "name": "memory_process",
            "description": """处理对话内容，提取并存储记忆。

输入是对话消息数组，系统会自动：
1. 分类信息：无用聊天 / 画像信息 / 事件信息
2. 画像信息存入独立区域
3. 事件信息生成三层页表（完整→摘要→关键词）
4. 无用信息直接丢弃

调用时机：
- 对话结束后调用
- 涉及重要信息时调用
- 需要记住用户偏好时调用

输入格式：
{
  "conversation": [
    {"role": "user", "content": "我今天去看了医生"},
    {"role": "agent", "content": "看医生是为了什么？"}
  ],
  "owner_id": "用户ID"
}""",
            "parameters": {
                "type": "object",
                "properties": {
                    "conversation": {
                        "type": "array",
                        "description": "对话内容数组",
                        "items": {
                            "type": "object",
                            "properties": {
                                "role": {"type": "string", "enum": ["user", "agent"]},
                                "content": {"type": "string"},
                            },
                        },
                    },
                    "owner_id": {
                        "type": "string",
                        "description": "用户或Agent的ID，用于标识记忆的拥有者",
                    },
                    "session_id": {"type": "string", "description": "可选的会话ID"},
                },
                "required": ["conversation", "owner_id"],
            },
            "handler": lambda params, ctx: _handle_process(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_search",
            "description": """搜索记忆事件。

根据关键词搜索相关的事件记忆，返回按相似度排序的候选页面列表。

调用时机：
- 需要查找历史信息时
- 用户询问过去的事情时
- 需要引用之前的对话内容时

输入格式：
{
  "query": "咖啡 项目 会议",
  "owner_id": "用户ID",
  "max_results": 10
}

返回：按相似度排序的事件列表，每条包含 page_id、关键词、相似度分数。
AI 可以进一步调用 memory_read 获取详细内容。""",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "搜索关键词，可以用逗号分隔多个词",
                    },
                    "owner_id": {"type": "string", "description": "可选的用户ID"},
                    "max_results": {
                        "type": "integer",
                        "description": "最大返回数量，默认10",
                        "default": 10,
                    },
                },
                "required": ["query"],
            },
            "handler": lambda params, ctx: _handle_search(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_read",
            "description": """读取记忆页面的详细内容。

读取指定页面的各层级内容，用于获取事件的完整信息。

调用时机：
- memory_search 返回候选后
- 需要查看具体对话内容时
- 需要了解事件详情时

输入格式：
{
  "page_id": "页面ID",
  "layers": [2, 3],
  "include_related": true
}

layers 说明：
- 1: 关键词层（最简洁）
- 2: 摘要层（推荐优先查看）
- 3: 完整内容层""",
            "parameters": {
                "type": "object",
                "properties": {
                    "page_id": {"type": "string", "description": "要读取的页面ID"},
                    "layers": {
                        "type": "array",
                        "description": "要读取的层级 [1, 2, 3]，默认全部",
                        "items": {"type": "integer"},
                    },
                    "include_related": {
                        "type": "boolean",
                        "description": "是否包含关联的画像信息",
                        "default": False,
                    },
                },
                "required": ["page_id"],
            },
            "handler": lambda params, ctx: _handle_read(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_merge",
            "description": """合并多个相关的事件记忆页面。

当多个页面描述的是同一事件或相关事件时，可以合并为一个页面。

调用时机：
- 发现重复或相关的记忆页面时
- 需要整合分散的信息时

输入格式：
{
  "source_page_ids": ["page_id_1", "page_id_2"],
  "merge_type": "same_event",
  "merge_reason": "描述合并原因"
}

merge_type 选项：
- same_event: 完全相同的事件
- update: 同一事件的更新
- related: 相关但不完全相同的事件""",
            "parameters": {
                "type": "object",
                "properties": {
                    "source_page_ids": {
                        "type": "array",
                        "description": "要合并的页面ID列表",
                        "items": {"type": "string"},
                    },
                    "merge_type": {
                        "type": "string",
                        "description": "合并类型",
                        "enum": ["same_event", "update", "related"],
                    },
                    "merge_reason": {"type": "string", "description": "合并原因说明"},
                    "owner_id": {"type": "string", "description": "用户ID"},
                },
                "required": ["source_page_ids", "merge_type"],
            },
            "handler": lambda params, ctx: _handle_merge(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_profile_get",
            "description": """获取用户画像信息。

读取用户的偏好、习惯等结构化信息，用于提供个性化服务。

调用时机：
- 开始与用户对话时
- 需要了解用户偏好时
- 生成个性化回复时

输入格式：
{
  "owner_id": "用户ID"
}

返回用户的画像内容，包括偏好、习惯、背景等信息。""",
            "parameters": {
                "type": "object",
                "properties": {"owner_id": {"type": "string", "description": "用户ID"}},
                "required": ["owner_id"],
            },
            "handler": lambda params, ctx: _handle_profile_get(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_profile_update",
            "description": """更新用户画像信息。

更新用户的偏好、习惯等结构化信息。

调用时机：
- 发现新的用户偏好时
- 用户明确表示喜好/厌恶时
- 需要更新用户信息时

输入格式：
{
  "owner_id": "用户ID",
  "updates": {
    "preferences": {
      "topics_interest": ["新兴趣话题"]
    }
  }
}""",
            "parameters": {
                "type": "object",
                "properties": {
                    "owner_id": {"type": "string", "description": "用户ID"},
                    "updates": {"type": "object", "description": "要更新的画像内容"},
                },
                "required": ["owner_id", "updates"],
            },
            "handler": lambda params, ctx: _handle_profile_update(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_stats",
            "description": """获取记忆数据库统计信息。

查看当前记忆的使用情况，包括页面数量、存储大小等。""",
            "parameters": {
                "type": "object",
                "properties": {
                    "owner_id": {"type": "string", "description": "可选的用户ID"}
                },
            },
            "handler": lambda params, ctx: _handle_stats(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_archive",
            "description": """归档指定的记忆页面。

将不再需要频繁访问的记忆页面移动到归档存储，释放活跃存储空间。

调用时机：
- 记忆页面已过时或不再相关时
- 需要清理活跃存储空间时
- 用户明确要求归档时

输入格式：
{
  "page_id": "页面ID",
  "owner_id": "用户ID",
  "reason": "归档原因（可选）"
}""",
            "parameters": {
                "type": "object",
                "properties": {
                    "page_id": {"type": "string", "description": "要归档的页面ID"},
                    "owner_id": {"type": "string", "description": "用户ID"},
                    "reason": {"type": "string", "description": "归档原因说明"},
                },
                "required": ["page_id", "owner_id"],
            },
            "handler": lambda params, ctx: _handle_archive(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_restore",
            "description": """恢复已归档的记忆页面。

将归档的页面恢复到活跃存储，重新变为可搜索状态。

调用时机：
- 需要引用已归档的历史信息时
- 用户要求查看归档内容时
- 需要更新归档页面的信息时

输入格式：
{
  "archive_id": "归档ID"
}""",
            "parameters": {
                "type": "object",
                "properties": {
                    "archive_id": {"type": "string", "description": "归档记录ID"},
                },
                "required": ["archive_id"],
            },
            "handler": lambda params, ctx: _handle_restore(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_archived_list",
            "description": """获取已归档的记忆页面列表。

查看当前用户的所有归档页面，支持分页和筛选。

调用时机：
- 需要查看归档内容概览时
- 清理归档空间时
- 查找特定归档页面时

输入格式：
{
  "owner_id": "用户ID",
  "limit": 50
}

返回归档页面列表，包含归档时间、原因等信息。""",
            "parameters": {
                "type": "object",
                "properties": {
                    "owner_id": {"type": "string", "description": "用户ID"},
                    "limit": {
                        "type": "integer",
                        "description": "返回数量限制，默认50",
                        "default": 50,
                    },
                },
                "required": ["owner_id"],
            },
            "handler": lambda params, ctx: _handle_archived_list(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_auto_archive",
            "description": """自动归档超过指定时间的旧页面。

系统会自动将超过指定天数的非活跃页面移动到归档存储。

调用时机：
- 定期清理活跃存储时
- 存储空间不足时
- 系统维护任务

输入格式：
{
  "owner_id": "用户ID",
  "days": 180
}

days 参数：超过该天数的页面将被归档，默认180天（6个月）。""",
            "parameters": {
                "type": "object",
                "properties": {
                    "owner_id": {"type": "string", "description": "用户ID"},
                    "days": {
                        "type": "integer",
                        "description": "超过天数后自动归档，默认180天",
                        "default": 180,
                    },
                },
                "required": ["owner_id"],
            },
            "handler": lambda params, ctx: _handle_auto_archive(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_detect_similar",
            "description": """检测相似的记忆页面。

基于 TF-IDF 向量相似度检测可能重复或相关的记忆页面，提供合并建议。

调用时机：
- 定期检查记忆去重时
- 发现可能重复的记忆时
- 需要整合相关信息时

输入格式：
{
  "owner_id": "用户ID",
  "threshold": 0.7,
  "limit": 10
}

threshold：相似度阈值，0.0-1.0，默认为0.7。高于0.85建议 same_event，低于0.85建议 related。

返回相似的页面对及相似度分数，可用于调用 memory_merge。""",
            "parameters": {
                "type": "object",
                "properties": {
                    "owner_id": {"type": "string", "description": "用户ID"},
                    "threshold": {
                        "type": "number",
                        "description": "相似度阈值（0.0-1.0），默认0.7",
                        "default": 0.7,
                    },
                    "limit": {
                        "type": "integer",
                        "description": "返回结果数量限制，默认10",
                        "default": 10,
                    },
                },
                "required": ["owner_id"],
            },
            "handler": lambda params, ctx: _handle_detect_similar(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_fix_tfidf",
            "description": """修复 TF-IDF 索引外键约束错误。

修复 tfidf_index 表外键指向错误表（l1_pages → l2_pages）的问题。
此问题会导致 rebuild 等操作失败，并触发 SQLite 外键约束错误。

调用时机：
- 首次使用 detect_similar 功能前
- rebuild 操作失败时
- 迁移旧数据库后

输入格式：
{
  "owner_id": "用户ID"  // 可选
}

返回值：
- success: true 表示修复成功
- success: false 表示修复失败，请查看日志""",
            "parameters": {
                "type": "object",
                "properties": {
                    "owner_id": {"type": "string", "description": "用户ID（可选）"},
                },
            },
            "handler": lambda params, ctx: _handle_fix_tfidf(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_manage_archive",
            "description": """统一的归档管理接口。

提供综合的归档管理能力，支持多种操作类型。

调用时机：
- 需要批量管理归档时
- 复杂的归档操作场景
- 统一入口偏好场景

输入格式：
{
  "action": "操作类型",
  "owner_id": "用户ID",
  "target": {}
}

支持的 action：
- archive: 归档页面，需要 target.page_id
- restore: 恢复页面，需要 target.archive_id
- list: 列出归档，需要 target.limit（可选）
- auto_archive: 自动归档，需要 target.days（可选）

示例 - 归档页面：
{
  "action": "archive",
  "owner_id": "user123",
  "target": {"page_id": "abc123", "reason": "已过时"}
}

示例 - 恢复页面：
{
  "action": "restore",
  "owner_id": "user123",
  "target": {"archive_id": "xyz789"}
}""",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "description": "操作类型",
                        "enum": ["archive", "restore", "list", "auto_archive"],
                    },
                    "owner_id": {"type": "string", "description": "用户ID"},
                    "target": {"type": "object", "description": "操作目标参数"},
                },
                "required": ["action", "owner_id"],
            },
            "handler": lambda params, ctx: _handle_manage_archive(memory_api, params),
        }
    )

    api.registerTool(
        {
            "name": "memory_archive_config",
            "description": """获取或设置归档规则配置。

管理归档策略，包括自动归档的时间阈值、保留期限等参数。

调用时机：
- 配置归档策略时
- 查看当前归档设置时
- 调整归档行为时

输入格式（获取配置）：
{
  "action": "config_get",
  "owner_id": "用户ID"
}

输入格式（设置配置）：
{
  "action": "config_set",
  "owner_id": "用户ID",
  "config": {
    "page_idle_days": 90,
    "merged_page_grace_days": 30,
    "archive_retention_days": 365
  }
}

config 参数说明：
- page_idle_days: 页面闲置天数阈值，默认180
- merged_page_grace_days: 合并页面宽限期，默认30
- archive_retention_days: 归档保留天数，默认365

返回当前的归档配置或设置结果。""",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "description": "操作类型",
                        "enum": ["config_get", "config_set"],
                    },
                    "owner_id": {"type": "string", "description": "用户ID"},
                    "config": {
                        "type": "object",
                        "description": "归档配置参数（config_set时必填）",
                        "properties": {
                            "page_idle_days": {
                                "type": "integer",
                                "description": "页面闲置天数阈值",
                            },
                            "merged_page_grace_days": {
                                "type": "integer",
                                "description": "合并页面宽限期（天）",
                            },
                            "archive_retention_days": {
                                "type": "integer",
                                "description": "归档保留天数",
                            },
                        },
                    },
                },
                "required": ["action", "owner_id"],
            },
            "handler": lambda params, ctx: _handle_archive_config(memory_api, params),
        }
    )

    api.logger.info("Agent Memory plugin loaded successfully")


def _handle_process(memory_api, params):
    try:
        result = memory_api.process_conversation(
            conversation=params.get("conversation", []),
            owner_id=params.get("owner_id", "default"),
            session_id=params.get("session_id"),
        )
        return {"success": True, "result": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_search(memory_api, params):
    try:
        result = memory_api.search_events(
            query=params.get("query", ""),
            owner_id=params.get("owner_id"),
            max_results=params.get("max_results", 10),
        )
        return {"success": True, "results": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_read(memory_api, params):
    try:
        layers = params.get("layers", [1, 2, 3])
        result = memory_api.read_page(
            page_id=params.get("page_id"),
            layers=layers,
            include_related=params.get("include_related", False),
        )
        return {"success": True, "content": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_merge(memory_api, params):
    try:
        result = memory_api.merge_pages(
            source_page_ids=params.get("source_page_ids", []),
            merge_type=params.get("merge_type", "related"),
            merge_reason=params.get("merge_reason", ""),
            owner_id=params.get("owner_id"),
        )
        return {"success": True, "result": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_profile_get(memory_api, params):
    try:
        result = memory_api.get_profile(owner_id=params.get("owner_id", "default"))
        return {"success": True, "profile": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_profile_update(memory_api, params):
    try:
        result = memory_api.update_profile(
            owner_id=params.get("owner_id", "default"),
            updates=params.get("updates", {}),
        )
        return {"success": True, "result": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_stats(memory_api, params):
    try:
        result = memory_api.get_stats(owner_id=params.get("owner_id"))
        return {"success": True, "stats": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_archive(memory_api, params):
    try:
        result = memory_api.archive_page(
            page_id=params.get("page_id"),
            owner_id=params.get("owner_id", "default"),
            reason=params.get("reason", "manual"),
        )
        return {"success": True, "result": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_restore(memory_api, params):
    try:
        result = memory_api.restore_page(archive_id=params.get("archive_id"))
        return {"success": True, "result": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_archived_list(memory_api, params):
    try:
        result = memory_api.get_archived_pages(
            owner_id=params.get("owner_id", "default"),
            limit=params.get("limit", 50),
        )
        return {"success": True, "archives": result, "count": len(result)}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_auto_archive(memory_api, params):
    try:
        result = memory_api.auto_archive(
            owner_id=params.get("owner_id", "default"),
            days=params.get("days", 180),
        )
        return {"success": True, "result": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_detect_similar(memory_api, params):
    try:
        result = memory_api.detect_similar_pages(
            owner_id=params.get("owner_id", "default"),
            threshold=params.get("threshold", 0.7),
            limit=params.get("limit", 10),
        )
        return {"success": True, "result": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_fix_tfidf(memory_api, params):
    try:
        result = memory_api.fix_tfidf_foreign_key()
        return result
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_manage_archive(memory_api, params):
    try:
        action = params.get("action")
        owner_id = params.get("owner_id", "default")
        target = params.get("target", {})

        if action == "archive":
            result = memory_api.archive_page(
                page_id=target.get("page_id"),
                owner_id=owner_id,
                reason=target.get("reason", "manual"),
            )
        elif action == "restore":
            result = memory_api.restore_page(archive_id=target.get("archive_id"))
        elif action == "list":
            result = memory_api.get_archived_pages(
                owner_id=owner_id,
                limit=target.get("limit", 50),
            )
            return {"success": True, "archives": result, "count": len(result)}
        elif action == "auto_archive":
            result = memory_api.auto_archive(
                owner_id=owner_id,
                days=target.get("days", 180),
            )
        else:
            return {
                "success": False,
                "error": f"Unknown action: {action}",
            }

        return {"success": True, "result": result}
    except Exception as error:
        return {"success": False, "error": str(error)}


def _handle_archive_config(memory_api, params):
    try:
        action = params.get("action")
        owner_id = params.get("owner_id", "default")

        if action == "config_get":
            result = memory_api.get_archive_config(owner_id=owner_id)
        elif action == "config_set":
            config = params.get("config", {})
            result = memory_api.set_archive_config(owner_id=owner_id, config=config)
        else:
            return {
                "success": False,
                "error": f"Unknown action: {action}. Supported actions: config_get, config_set",
            }

        return {"success": True, "result": result}
    except Exception as error:
        return {"success": False, "error": str(error)}
