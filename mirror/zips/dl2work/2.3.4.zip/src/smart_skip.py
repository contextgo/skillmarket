import re
import threading
from typing import List, Dict, Optional
from logger import get_logger
from config import Config


class SmartSkipFilter:
    """
    智能跳过过滤器
    减少不必要的 LLM 调用
    """

    WASTE_PATTERNS = [
        r"^你好[吗呢？?]*$",
        r"^嗨[呀!]*$",
        r"^在吗[？?]*$",
        r"^谢谢[啦啊]?$",
        r"^[Hh]i+$",
        r"^[Hh]ey+$",
        r"^OK+$",
        r"^好的?$",
        r"^没问题$",
        r"^收到$",
        r"^明白$",
        r"^懂了$",
        r"^知道了$",
        r"^了解$",
        r"^清楚$",
    ]

    MEANINGFUL_SHORT_MESSAGES = [
        "好",
        "是",
        "嗯",
        "对",
        "行",
        "可以",
        "不",
        "不是",
        "不行",
        "不要",
    ]

    def __init__(self):
        self._patterns = [re.compile(p) for p in self.WASTE_PATTERNS]
        self._meaningful_short = set(self.MEANINGFUL_SHORT_MESSAGES)
        self.logger = get_logger("smart_skip")
        self._stats = {
            "total_checked": 0,
            "skipped_count": 0,
            "pattern_matched": 0,
            "length_filtered": 0,
        }

    def is_waste(self, conversation: List[Dict[str, str]]) -> bool:
        """快速判断是否为无意义对话"""
        if not conversation:
            return True

        self._stats["total_checked"] += 1

        last_user_msg = ""
        for msg in reversed(conversation):
            if msg.get("role") == "user":
                last_user_msg = msg.get("content", "").strip()
                break

        if not last_user_msg:
            return True

        if last_user_msg in self._meaningful_short:
            return False

        for pattern in self._patterns:
            if pattern.match(last_user_msg):
                self._stats["skipped_count"] += 1
                self._stats["pattern_matched"] += 1
                self.logger.debug(
                    "SKIP_PATTERN_MATCHED",
                    pattern=pattern.pattern,
                    message_preview=last_user_msg[:20],
                )
                return True

        total_length = sum(len(m.get("content", "")) for m in conversation)

        if total_length < Config.SMART_SKIP_MIN_LENGTH:
            self._stats["skipped_count"] += 1
            self._stats["length_filtered"] += 1
            self.logger.debug(
                "SKIP_LENGTH_FILTER",
                total_length=total_length,
                threshold=Config.SMART_SKIP_MIN_LENGTH,
            )
            return True

        return False

    def get_stats(self) -> Dict:
        """获取统计信息"""
        skip_rate = self._stats["skipped_count"] / max(self._stats["total_checked"], 1)
        return {
            **self._stats,
            "skip_rate": f"{skip_rate:.2%}",
        }

    def reset_stats(self):
        """重置统计"""
        self._stats = {
            "total_checked": 0,
            "skipped_count": 0,
            "pattern_matched": 0,
            "length_filtered": 0,
        }


_skip_filter: Optional[SmartSkipFilter] = None
_filter_lock = threading.Lock()


def get_skip_filter() -> SmartSkipFilter:
    """获取跳过过滤器单例"""
    global _skip_filter
    if _skip_filter is None:
        with _filter_lock:
            if _skip_filter is None:
                _skip_filter = SmartSkipFilter()
    return _skip_filter
