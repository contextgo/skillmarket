"""
Agent Memory 配置管理
集中管理所有配置常量，避免魔法数字
"""


class Config:
    """全局配置"""

    # 相似度阈值
    SIMILARITY_THRESHOLD = 0.6
    HIGH_SIMILARITY_THRESHOLD = 0.8
    VERY_HIGH_SIMILARITY_THRESHOLD = 0.85
    VECTOR_SCORE_WEIGHT = 0.7
    KEYWORD_SCORE_WEIGHT = 0.3

    # 默认限制
    DEFAULT_MAX_RESULTS = 10
    DEFAULT_LIMIT = 50
    MAX_PAGE_ID_LENGTH = 64
    MAX_QUERY_LENGTH = 1000
    MAX_MERGE_REASON_LENGTH = 500

    # 归档配置
    DEFAULT_RETENTION_DAYS = 180
    DEFAULT_PAGE_IDLE_DAYS = 90
    DEFAULT_MERGED_PAGE_GRACE_DAYS = 30
    DEFAULT_PROFILE_MAX_VERSIONS = 10
    DEFAULT_MAX_ACTIVE_PAGES_PER_USER = 500
    DEFAULT_ARCHIVE_RETENTION_DAYS = 365

    # 字符串长度限制
    MAX_SUMMARY_LENGTH = 200
    MAX_LOG_TRUNCATION = 50
    MAX_ERROR_MESSAGE_TRUNCATION = 100

    # LLM 配置
    LLM_TIMEOUT_SECONDS = 10
    LLM_MAX_TOKENS = 2000
    LLM_TEMPERATURE = 0.3

    # N-gram 配置
    NGRAM_SIZES = [2, 3, 4]

    # 中文字符范围
    CHINESE_CHAR_START = "\u4e00"
    CHINESE_CHAR_END = "\u9fff"

    # API 配置
    API_TIMEOUT_MS = 30000

    # 批处理配置
    BATCH_WINDOW_SIZE = 5
    BATCH_MAX_WAIT_SECONDS = 30.0
    BATCH_MAX_QUEUE_HIGH_SIZE = 20
    BATCH_HIGH_PRIORITY_THRESHOLD = 3

    # 智能跳过配置
    SMART_SKIP_MIN_LENGTH = 5

    # 重试配置
    RETRY_DEFAULT_RETRY_AFTER_SECONDS = 60

    @classmethod
    def validate_page_id(cls, page_id: str) -> bool:
        """验证 page_id 格式"""
        import re

        if not page_id or len(page_id) > cls.MAX_PAGE_ID_LENGTH:
            return False
        return bool(re.match(r"^[a-zA-Z0-9\-_]+$", page_id))

    @classmethod
    def validate_query_length(cls, query: str) -> bool:
        """验证查询长度"""
        return query is not None and len(query) <= cls.MAX_QUERY_LENGTH


# 中文停用词列表
STOPWORDS = {
    "的",
    "了",
    "在",
    "是",
    "我",
    "有",
    "和",
    "就",
    "不",
    "人",
    "都",
    "一",
    "一个",
    "上",
    "也",
    "很",
    "到",
    "说",
    "要",
    "去",
    "你",
    "会",
    "着",
    "没有",
    "看",
    "好",
    "自己",
    "这",
    "那",
    "他",
    "她",
    "它",
    "吗",
    "吧",
    "啊",
    "呢",
    "哦",
    "嗯",
    "啦",
    "呀",
}


class SecurityConfig:
    """安全配置"""

    # API Key 验证
    REQUIRE_API_KEY = True
    API_KEY_HEADER = "X-API-Key"

    # 速率限制
    RATE_LIMIT_ENABLED = True
    RATE_LIMIT_REQUESTS_PER_MINUTE = 60

    # 输入验证
    MAX_CONVERSATION_LENGTH = 100  # 对话消息数量
    MAX_MESSAGE_LENGTH = 10000  # 单条消息长度

    @classmethod
    def sanitize_error_message(cls, error: str) -> str:
        """清理错误消息，移除敏感信息"""
        import re

        # 移除文件路径
        error = re.sub(r"/[\w/\-\.]+", "[PATH]", error)
        # 移除 API keys
        error = re.sub(r"Bearer\s+[\w\-]+", "Bearer [REDACTED]", error)
        error = re.sub(
            r"(api[_-]?key[=:]\s*)[\w\-]+", r"\1[REDACTED]", error, flags=re.IGNORECASE
        )
        return error
