"""
Agent Memory API
提供统一的 API 接口供 OpenClaw 插件调用
"""

import json
import uuid
import os
from typing import Dict, List, Any, Optional
from datetime import datetime, timezone

from memory_core import (
    AgentMemoryDB,
    L3Page,
    L2Page,
    L1Page,
    Profile,
    MergeRecord,
    get_memory_db,
)
from llm_processor import LLMProcessor, get_llm_processor
from auth import verify_owner_access
from validators import (
    validate_page_id,
    validate_query,
    validate_page_ids,
    validate_merge_reason,
    validate_conversation,
)
from config import SecurityConfig, Config


class MemoryAPI:
    """记忆数据库 API"""

    def __init__(self, db_path: str = None):
        self.db = get_memory_db(db_path)
        self.llm = get_llm_processor()

    def process_conversation(
        self, conversation: List[Dict[str, str]], owner_id: str, session_id: str = None
    ) -> Dict:
        """
        处理对话的核心接口
        一次调用完成：分类 -> 存储 -> 派生三层

        Args:
            conversation: 对话内容 [{"role": "user/agent", "content": "..."}]
            owner_id: 用户或 Agent ID
            session_id: 可选的会话 ID

        Returns:
            处理结果字典
        """
        validate_conversation(conversation)

        result = {
            "success": True,
            "processed": {
                "skipped_count": 0,
                "profile_updates": [],
                "new_pages": [],
                "merges": [],
            },
        }

        # ✅ 新增：智能跳过检测（减少不必要的 LLM 调用）
        from smart_skip import get_skip_filter

        skip_filter = get_skip_filter()

        if skip_filter.is_waste(conversation):
            result["processed"]["skipped_count"] = len(conversation)
            result["processed"]["skip_reason"] = "waste_detected"
            return result

        # ✅ 新增：使用 batch_processor（对话缓冲和优先级处理）
        from batch_processor import get_batch_processor

        batch_processor = get_batch_processor(self.llm)

        # 尝试加入缓冲队列
        batch_result = batch_processor.add_conversation(conversation)

        if batch_result is None:
            # 加入队列等待批量处理
            result["processed"]["queued"] = True
            result["processed"]["queue_status"] = batch_processor.get_stats()
            return result

        # 立即处理（CRITICAL 或队列已满）
        process_result, priority = batch_result
        result["processed"]["priority"] = (
            priority.value if hasattr(priority, "value") else str(priority)
        )

        # 1. 调用 LLM 处理（已通过 batch_processor 处理）
        # process_result = self.llm.process_conversation(conversation)

        if process_result.info_type == "waste":
            # 无用信息，丢弃
            result["processed"]["skipped_count"] = len(conversation)
            return result

        elif process_result.info_type == "profile":
            if process_result.profile_updates:
                profile_data = process_result.profile_updates[0]
                existing = self.db.get_profile(owner_id)

                evidence_entry = {
                    "page_id": str(uuid.uuid4()),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "source": "conversation",
                }

                if existing:
                    new_version = existing.version + 1
                    merged_content = {**existing.content, **profile_data}
                    new_evidence = existing.evidence + [evidence_entry]
                    profile = Profile(
                        profile_id=existing.profile_id,
                        owner_id=owner_id,
                        content=merged_content,
                        evidence=new_evidence,
                        version=new_version,
                        created_at=existing.created_at,
                        updated_at=datetime.now(timezone.utc).isoformat(),
                    )
                else:
                    profile = Profile(
                        profile_id=str(uuid.uuid4()),
                        owner_id=owner_id,
                        content=profile_data,
                        evidence=[evidence_entry],
                    )

                self.db.save_profile(profile)
                self.db.build_profile_tfidf(owner_id, profile.content)
                result["processed"]["profile_updates"].append(
                    {"fact": "画像已更新", "profile_id": profile.profile_id}
                )

            return result

        else:  # event
            # 事件信息，生成三层页表
            event_data = process_result.event_data

            # 生成页面 ID
            page_id = str(uuid.uuid4())

            # 2. 创建第三层（完整内容）
            l3_page = L3Page(
                page_id=page_id,
                content=event_data["content"],
                metadata={"session_id": session_id, "participant_ids": [owner_id]},
            )
            self.db.save_l3_page(l3_page)

            # 3. 派生第二层（摘要）
            l2_page = L2Page(
                page_id=str(uuid.uuid4()),
                full_page_id=page_id,
                summary=event_data["summary"],
                entities=event_data["entities"],
                key_facts=event_data["key_facts"],
                conclusion=event_data["conclusion"],
                implied_preferences=event_data["implied_preferences"],
            )
            self.db.save_l2_page(l2_page)

            # 4. 派生第一层（关键词）
            keywords = event_data["keywords"]
            l1_page = L1Page(
                page_id=str(uuid.uuid4()),
                full_page_id=page_id,
                summary_page_id=l2_page.page_id,
                owner_id=owner_id,
                keywords={
                    "event_type": keywords.get("event_type", []),
                    "who": keywords.get("who", []),
                    "where": keywords.get("where", []),
                    "what": keywords.get("what", []),
                    "when": keywords.get("when", []),
                    "why": keywords.get("why", []),
                    "merge_hints": keywords.get("merge_hints", []),
                },
                time_hint=keywords.get("time_hint", ""),
                event_date=keywords.get("event_date", ""),
                similarity_seeds=keywords.get("similarity_seeds", []),
            )
            self.db.save_l1_page(l1_page)
            self.db.update_tfidf_index_incremental(l2_page.page_id, owner_id)

            similar_pages = self.db.find_similar_pages(
                new_page_id=page_id,
                owner_id=owner_id,
                threshold=Config.SIMILARITY_THRESHOLD,
            )

            if similar_pages:
                result["processed"]["merge_candidates"] = similar_pages[:3]

                best_match = similar_pages[0]
                if best_match["similarity"] > Config.HIGH_SIMILARITY_THRESHOLD:
                    result["processed"]["merge_recommendation"] = {
                        "new_page_id": page_id,
                        "similar_page_id": best_match["page_id"],
                        "similarity_score": best_match["similarity"],
                        "recommendation": "consider_merge",
                        "reason": f"关键词相似度 {best_match['similarity']:.2f}，建议合并",
                    }

            result["processed"]["new_pages"].append(
                {
                    "page_id": page_id,
                    "l2_page_id": l2_page.page_id,
                    "l1_page_id": l1_page.page_id,
                    "summary": event_data["summary"],
                    "is_merged": False,
                }
            )

            return result

    def search_events(
        self,
        query: str,
        owner_id: str = None,
        time_range: Dict = None,
        max_results: int = 10,
    ) -> Dict:
        """
        搜索事件记忆（支持时间范围过滤）

        Args:
            query: 查询关键词（可以是逗号分隔的多个词）
            owner_id: 可选的用户 ID
            time_range: 可选的时间范围 {"start": "2026-01-01", "end": "2026-04-01"}
            max_results: 最大返回数量

        Returns:
            搜索结果列表
        """
        validate_query(query)
        keywords = [k.strip() for k in query.replace(",", " ").split() if k.strip()]

        candidates = self.db.search_l1_pages(
            keywords,
            owner_id=owner_id,
            limit=max_results * 2,
            query_text=query,
            time_range=time_range,
        )

        scored_results = []
        for candidate in candidates:
            if candidate["score"] > 0:
                if time_range:
                    l3_page = self.db.get_l3_page(candidate["full_page_id"])
                    if l3_page:
                        page_time = l3_page.created_at[:10]
                        start = time_range.get("start", "")
                        end = time_range.get("end", "")
                        if start and page_time < start:
                            continue
                        if end and page_time > end:
                            continue

                scored_results.append(
                    {
                        "page_id": candidate["page_id"],
                        "full_page_id": candidate["full_page_id"],
                        "keywords": candidate["keywords"],
                        "time_hint": candidate["time_hint"],
                        "similarity_score": round(candidate["score"], 3),
                    }
                )

        scored_results.sort(key=lambda x: x["similarity_score"], reverse=True)

        return {
            "results": scored_results[:max_results],
            "total_candidates": len(scored_results),
            "query_keywords": keywords,
            "time_range": time_range,
        }

    def read_page(
        self,
        page_id: str,
        layers: List[int] = None,
        include_related: bool = False,
        owner_id: str = None,
        auth_context: Optional[Dict] = None,
    ) -> Dict:
        """
        读取页面内容

        Args:
            page_id: 页面 ID（可以是 L1、L2 或 L3 的 page_id）
            layers: 要读取的层级 [1, 2, 3]，默认全部
            include_related: 是否包含关联的画像信息
            owner_id: 用户ID（用于权限验证）
            auth_context: 认证上下文

        Returns:
            页面内容
        """
        validate_page_id(page_id)
        if layers is None:
            layers = [1, 2, 3]

        # 权限验证：先获取页面确定 owner
        l3_check = self.db.get_l3_page(page_id)
        if l3_check:
            page_owner = l3_check.owner_id
            if auth_context and auth_context.get("authenticated"):
                verify_owner_access(page_owner, auth_context)
            elif owner_id and page_owner != owner_id:
                return {"page_id": page_id, "error": "Permission denied"}

        result = {"page_id": page_id, "content": {}}

        # 先尝试把 page_id 当作 L3 page_id 处理
        l3_page = self.db.get_l3_page(page_id)
        if l3_page:
            if 3 in layers:
                result["content"]["layer3"] = {
                    "content": l3_page.content,
                    "created_at": l3_page.created_at,
                    "status": l3_page.status,
                    "metadata": l3_page.metadata,
                }
            # 如果请求了 L2/L1 但没有结果，用 L3 的 page_id 作为入口去查
            l2_page = self.db.get_l2_page(page_id)
            if not l2_page:
                l2_page = self.db.get_l2_page_by_full(page_id)
            if 2 in layers and l2_page:
                result["content"]["layer2"] = {
                    "summary": l2_page.summary,
                    "entities": l2_page.entities,
                    "key_facts": l2_page.key_facts,
                    "conclusion": l2_page.conclusion,
                    "implied_preferences": l2_page.implied_preferences,
                    "created_at": l2_page.created_at,
                }
            l1_page = self.db.get_l1_page(page_id)
            if not l1_page:
                l1_page = self.db.get_l1_page_by_full(page_id)
            if 1 in layers and l1_page:
                result["content"]["layer1"] = {
                    "keywords": l1_page.keywords,
                    "time_hint": l1_page.time_hint,
                    "similarity_seeds": l1_page.similarity_seeds,
                }

            if include_related and l1_page:
                profile = self.db.get_profile(l1_page.owner_id)
                if profile:
                    result["related_profile"] = {
                        "profile_id": profile.profile_id,
                        "owner_id": profile.owner_id,
                        "content": profile.content,
                        "evidence": profile.evidence,
                    }

            return result

        # page_id 不在 L3，尝试 L2
        l2_page = self.db.get_l2_page(page_id)
        if l2_page:
            if 2 in layers:
                result["content"]["layer2"] = {
                    "summary": l2_page.summary,
                    "entities": l2_page.entities,
                    "key_facts": l2_page.key_facts,
                    "conclusion": l2_page.conclusion,
                    "implied_preferences": l2_page.implied_preferences,
                    "created_at": l2_page.created_at,
                }
            if 3 in layers:
                l3 = self.db.get_l3_page(l2_page.full_page_id)
                if l3:
                    result["content"]["layer3"] = {
                        "content": l3.content,
                        "created_at": l3.created_at,
                        "status": l3.status,
                        "metadata": l3.metadata,
                    }
            if 1 in layers:
                l1 = self.db.get_l1_page_by_full(l2_page.full_page_id)
                if l1:
                    result["content"]["layer1"] = {
                        "keywords": l1.keywords,
                        "time_hint": l1.time_hint,
                        "similarity_seeds": l1.similarity_seeds,
                    }

            if include_related:
                l1 = self.db.get_l1_page_by_full(l2_page.full_page_id)
                if l1:
                    profile = self.db.get_profile(l1.owner_id)
                    if profile:
                        result["related_profile"] = {
                            "profile_id": profile.profile_id,
                            "owner_id": profile.owner_id,
                            "content": profile.content,
                            "evidence": profile.evidence,
                        }

            return result

        # 尝试 L1
        l1_page = self.db.get_l1_page(page_id)
        if l1_page:
            if 1 in layers:
                result["content"]["layer1"] = {
                    "keywords": l1_page.keywords,
                    "time_hint": l1_page.time_hint,
                    "similarity_seeds": l1_page.similarity_seeds,
                }
            if 2 in layers:
                l2 = self.db.get_l2_page(l1_page.summary_page_id)
                if l2:
                    result["content"]["layer2"] = {
                        "summary": l2.summary,
                        "entities": l2.entities,
                        "key_facts": l2.key_facts,
                        "conclusion": l2.conclusion,
                        "implied_preferences": l2.implied_preferences,
                        "created_at": l2.created_at,
                    }
            if 3 in layers:
                l3 = self.db.get_l3_page(l1_page.full_page_id)
                if l3:
                    result["content"]["layer3"] = {
                        "content": l3.content,
                        "created_at": l3.created_at,
                        "status": l3.status,
                        "metadata": l3.metadata,
                    }

            if include_related:
                profile = self.db.get_profile(l1_page.owner_id)
                if profile:
                    result["related_profile"] = {
                        "profile_id": profile.profile_id,
                        "owner_id": profile.owner_id,
                        "content": profile.content,
                        "evidence": profile.evidence,
                    }

            return result

        return result

    def get_page_summary(
        self, page_id: str, auth_context: Optional[Dict] = None
    ) -> Optional[str]:
        """获取页面的摘要（第二层内容）"""
        validate_page_id(page_id)

        l3_page = self.db.get_l3_page(page_id)
        if l3_page:
            owner_id = l3_page.owner_id
            if auth_context and auth_context.get("authenticated"):
                verify_owner_access(owner_id, auth_context)

            content = l3_page.content[:200]
            if len(l3_page.content) > 200:
                content += "..."
            return content
        return None

    def merge_pages(
        self,
        source_page_ids: List[str],
        merge_type: str = "related",
        merge_reason: str = "",
        owner_id: str = None,
    ) -> Dict:
        """
        合并页面（完整流程：L3 -> L2 -> L1）

        Args:
            source_page_ids: 要合并的页面 ID 列表
            merge_type: 合并类型 same_event/update/related
            merge_reason: 合并原因
            owner_id: 用户 ID

        Returns:
            合并结果
        """
        validate_page_ids(source_page_ids)
        validate_merge_reason(merge_reason)
        if len(source_page_ids) < 2:
            return {"success": False, "error": "需要至少两个页面才能合并"}

        contents = []
        actual_l3_ids = []
        for page_id in source_page_ids:
            l3_page = self.db.get_l3_page(page_id)
            if l3_page:
                contents.append({"role": "merged", "content": l3_page.content})
                actual_l3_ids.append(page_id)
            else:
                l3_id = self.db.get_l3_id_from_l2_id(page_id)
                if l3_id:
                    l3_page = self.db.get_l3_page(l3_id)
                    if l3_page:
                        contents.append({"role": "merged", "content": l3_page.content})
                        actual_l3_ids.append(l3_id)

        if not contents:
            return {"success": False, "error": "未找到有效的源页面"}

        new_page_id = str(uuid.uuid4())
        merged_content = "\n\n---\n\n".join([c["content"] for c in contents])

        l3_page = L3Page(
            page_id=new_page_id,
            content=merged_content,
            metadata={"merged_from": source_page_ids, "merge_type": merge_type},
        )
        self.db.save_l3_page(l3_page)

        summary_data = self.llm.summarize_event(contents)
        l2_page = L2Page(
            page_id=str(uuid.uuid4()),
            full_page_id=new_page_id,
            summary=summary_data.get("summary", ""),
            entities=summary_data.get("entities", []),
            key_facts=summary_data.get("key_facts", []),
            conclusion=summary_data.get("conclusion", ""),
            implied_preferences=summary_data.get("implied_preferences", []),
        )
        self.db.save_l2_page(l2_page)

        keywords_data = self.llm.extract_keywords(summary_data)
        l1_page = L1Page(
            page_id=str(uuid.uuid4()),
            full_page_id=new_page_id,
            summary_page_id=l2_page.page_id,
            owner_id=owner_id or "default",
            keywords={
                "event_type": keywords_data.get("event_type", []),
                "who": keywords_data.get("who", []),
                "where": keywords_data.get("where", []),
                "what": keywords_data.get("what", []),
                "when": keywords_data.get("when", []),
                "why": keywords_data.get("why", []),
                "merge_hints": keywords_data.get("merge_hints", []),
            },
            time_hint=keywords_data.get("time_hint", ""),
            similarity_seeds=keywords_data.get("similarity_seeds", []),
        )
        self.db.save_l1_page(l1_page)

        for page_id in source_page_ids:
            self.db.mark_page_merged(page_id, new_page_id)

        merge_record = MergeRecord(
            merge_id=str(uuid.uuid4()),
            source_pages=source_page_ids,
            target_page_id=new_page_id,
            reason=merge_reason,
            merge_type=merge_type,
        )
        self.db.save_merge_record(merge_record)

        self.db.update_tfidf_index_incremental(l2_page.page_id, owner_id or "default")

        return {
            "success": True,
            "new_page_id": new_page_id,
            "l2_page_id": l2_page.page_id,
            "l1_page_id": l1_page.page_id,
            "source_pages": source_page_ids,
            "merge_type": merge_type,
            "summary": summary_data.get("summary", ""),
        }

    def get_profile(self, owner_id: str) -> Optional[Dict]:
        """获取用户画像"""
        profile = self.db.get_profile(owner_id)
        if profile:
            return {
                "profile_id": profile.profile_id,
                "owner_id": profile.owner_id,
                "content": profile.content,
                "evidence": profile.evidence,
                "version": profile.version,
                "updated_at": profile.updated_at,
            }
        return None

    def update_profile(
        self,
        owner_id: str,
        updates: Dict,
        evidence: List[Dict] = None,
        confidence: float = 1.0,
        auth_context: Optional[Dict] = None,
    ) -> Dict:
        """更新用户画像"""
        if auth_context and auth_context.get("authenticated"):
            verify_owner_access(owner_id, auth_context)

        existing = self.db.get_profile(owner_id)

        evidence_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "manual_update",
        }
        if evidence:
            evidence_entry["details"] = evidence

        if existing:
            new_content = {**existing.content, **updates}
            new_evidence = existing.evidence + [evidence_entry]
            profile = Profile(
                profile_id=existing.profile_id,
                owner_id=owner_id,
                content=new_content,
                evidence=new_evidence,
                version=existing.version + 1,
                created_at=existing.created_at,
                updated_at=datetime.now(timezone.utc).isoformat(),
            )
        else:
            profile = Profile(
                profile_id=str(uuid.uuid4()),
                owner_id=owner_id,
                content=updates,
                evidence=[evidence_entry],
            )

        self.db.save_profile(profile)

        return {"success": True, "profile_id": profile.profile_id}

    def archive_page(self, page_id: str, owner_id: str, reason: str = "manual") -> Dict:
        """归档页面"""
        return self.db.archive_page(page_id, owner_id, reason)

    def get_archive_config(
        self, owner_id: str, auth_context: Optional[Dict] = None
    ) -> Dict:
        """获取归档配置"""
        if auth_context and auth_context.get("authenticated"):
            verify_owner_access(owner_id, auth_context)
        return self.db.get_archive_config(owner_id)

    def set_archive_config(
        self, owner_id: str, config: Dict, auth_context: Optional[Dict] = None
    ) -> Dict:
        """设置归档配置"""
        if auth_context and auth_context.get("authenticated"):
            verify_owner_access(owner_id, auth_context)
        return self.db.set_archive_config(owner_id, config)

    def get_archived_pages(self, owner_id: str = None, limit: int = 50) -> List[Dict]:
        """获取归档页面列表"""
        return self.db.get_archived_pages(owner_id, limit)

    def restore_page(self, archive_id: str, authorized_owner_id: str = None) -> Dict:
        """恢复归档页面"""
        return self.db.restore_page(archive_id, authorized_owner_id)

    def auto_archive(self, owner_id: str, days: int = 180) -> Dict:
        """自动归档超过指定天数的页面"""
        return self.db.auto_archive_old_pages(owner_id, days)

    def detect_similar_pages(
        self, owner_id: str, threshold: float = 0.7, limit: int = 10
    ) -> Dict:
        """检测相似页面，返回合并建议"""
        import numpy as np
        import collections

        vectors_data = self.db.get_tfidf_vectors(owner_id)

        if len(vectors_data) < 2:
            return {
                "suggestions": [],
                "message": "Not enough pages to compare",
                "total_vectors": len(vectors_data),
                "skipped_invalid": 0
            }

        valid_vectors = []
        valid_page_ids = []
        skipped = 0

        for item in vectors_data:
            vector = item["vector"]
            if not vector or len(vector) == 0:
                skipped += 1
                continue

            try:
                vec_arr = np.array(vector, dtype=np.float32)
                if vec_arr.ndim != 1 or vec_arr.size == 0:
                    skipped += 1
                    continue

                valid_vectors.append(vec_arr)
                valid_page_ids.append(item["page_id"])
            except (ValueError, TypeError) as e:
                logger.warning(f"向量转换失败: page_id={item['page_id']}, error={e}")
                skipped += 1
                continue

        if len(valid_vectors) < 2:
            return {
                "suggestions": [],
                "message": f"Not enough valid vectors to compare (skipped {skipped} invalid)",
                "total_vectors": len(vectors_data),
                "valid_vectors": len(valid_vectors),
                "skipped_invalid": skipped
            }

        dimensions = [len(v) for v in valid_vectors]
        if len(set(dimensions)) > 1:
            most_common_dim = collections.Counter(dimensions).most_common(1)[0][0]

            filtered_vectors = []
            filtered_ids = []
            for v, pid in zip(valid_vectors, valid_page_ids):
                if len(v) == most_common_dim:
                    filtered_vectors.append(v)
                    filtered_ids.append(pid)
                else:
                    skipped += 1

            valid_vectors = filtered_vectors
            valid_page_ids = filtered_ids

            if len(valid_vectors) < 2:
                return {
                    "suggestions": [],
                    "message": "Vector dimensions are inconsistent",
                    "dimension_stats": {
                        "expected": most_common_dim,
                        "found": list(set(dimensions)),
                        "counts": dict(collections.Counter(dimensions))
                    },
                    "skipped_invalid": skipped
                }

        try:
            vectors_matrix = np.array(valid_vectors)
            norms = np.linalg.norm(vectors_matrix, axis=1, keepdims=True)
            norms = np.where(norms == 0, 1, norms)
            normalized = vectors_matrix / norms

            similarity_matrix = np.dot(normalized, normalized.T)
        except ValueError as e:
            return {
                "suggestions": [],
                "message": f"Matrix construction failed: {str(e)}",
                "total_vectors": len(vectors_data),
                "valid_vectors": len(valid_vectors),
                "skipped_invalid": skipped
            }

        suggestions = []
        for i in range(len(valid_page_ids)):
            for j in range(i + 1, len(valid_page_ids)):
                sim = similarity_matrix[i, j]
                if sim >= threshold:
                    l2_id_1 = valid_page_ids[i]
                    l2_id_2 = valid_page_ids[j]
                    l3_id_1 = self.db.get_l3_id_from_l2_id(l2_id_1)
                    l3_id_2 = self.db.get_l3_id_from_l2_id(l2_id_2)
                    suggestions.append(
                        {
                            "page_id_1": l2_id_1,
                            "page_id_2": l2_id_2,
                            "l3_page_id_1": l3_id_1,
                            "l3_page_id_2": l3_id_2,
                            "similarity": round(float(sim), 3),
                            "suggested_merge_type": "related"
                            if sim < Config.VERY_HIGH_SIMILARITY_THRESHOLD
                            else "same_event",
                        }
                    )

        suggestions.sort(key=lambda x: x["similarity"], reverse=True)
        return {
            "suggestions": suggestions[:limit],
            "total_pairs_checked": len(valid_page_ids) * (len(valid_page_ids) - 1) // 2,
            "threshold": threshold,
            "stats": {
                "total_vectors": len(vectors_data),
                "valid_vectors": len(valid_vectors),
                "skipped_invalid": skipped
            }
        }

    def get_stats(self, owner_id: str = None) -> Dict:
        """获取统计信息"""
        return self.db.get_stats(owner_id)

    def fix_tfidf_foreign_key(self) -> Dict:
        """修复 tfidf_index 外键约束错误"""
        success = self.db.fix_tfidf_foreign_key()
        if success:
            return {"success": True, "message": "tfidf_index 外键约束已修复"}
        else:
            return {"success": False, "error": "修复失败，请查看日志"}

    def manage_archive(
        self,
        action: str,
        target: Dict = None,
        owner_id: str = None,
        auth_context: Optional[Dict] = None,
    ) -> Dict:
        """
        管理归档操作

        Args:
            action: 操作类型
            target: 操作目标参数
            owner_id: 用户ID
            auth_context: 认证上下文

        Returns:
            操作结果
        """
        if target is None:
            target = {}

        if action == "archive":
            page_id = target.get("page_id")
            if not page_id:
                return {"success": False, "error": "page_id required"}

            reason = target.get("reason", "manual")
            result = self.db.archive_page(page_id, owner_id or "default", reason)
            return result

        elif action == "restore":
            archive_id = target.get("archive_id")
            if not archive_id:
                return {"success": False, "error": "archive_id required"}

            authorized_owner = None
            if auth_context and auth_context.get("authenticated"):
                authorized_owner = auth_context.get("owner_id")

            result = self.db.restore_page(archive_id, authorized_owner)
            return result

        elif action == "list":
            limit = target.get("limit", 50)
            archives = self.db.get_archived_pages(owner_id=owner_id, limit=limit)
            return {"success": True, "archives": archives, "count": len(archives)}

        elif action == "auto_archive":
            days = target.get("days", 180)
            result = self.db.auto_archive_old_pages(owner_id or "default", days)
            return result

        elif action == "config_get":
            config = self.db.get_archive_config(owner_id or "default")
            return {"success": True, "config": config}

        elif action == "config_set":
            config = target.get("config", {})
            result = self.db.set_archive_config(owner_id or "default", config)
            return result

        else:
            return {"success": False, "error": f"Unknown action: {action}"}


# 全局 API 实例
_api_instance: Optional[MemoryAPI] = None


def get_memory_api() -> MemoryAPI:
    """获取记忆 API 单例"""
    global _api_instance
    if _api_instance is None:
        _api_instance = MemoryAPI()
    return _api_instance


# 便捷函数
def process_and_store(conversation, owner_id, session_id=None):
    """处理并存储对话的便捷函数"""
    api = get_memory_api()
    return api.process_conversation(conversation, owner_id, session_id)


def search_memory(query, owner_id=None, max_results=10):
    """搜索记忆的便捷函数"""
    api = get_memory_api()
    return api.search_events(query, owner_id, max_results=max_results)


def get_user_profile(owner_id):
    """获取用户画像的便捷函数"""
    api = get_memory_api()
    return api.get_profile(owner_id)


ALLOWED_METHODS = frozenset(
    [
        "process_conversation",
        "search_events",
        "read_page",
        "merge_pages",
        "get_profile",
        "update_profile",
        "get_stats",
        "manage_archive",
        "archive_page",
        "get_archive_config",
        "set_archive_config",
        "get_archived_pages",
        "restore_page",
        "auto_archive",
        "detect_similar_pages",
    ]
)


def cli_require_auth(method_name: str, params: dict, api_key: str = None) -> dict:
    from auth import get_auth_manager, AuthorizationError, AuthenticationError

    auth_manager = get_auth_manager()

    if not api_key:
        raise AuthenticationError(
            "缺少认证信息", {"hint": f"方法 {method_name} 需要 --api-key 参数"}
        )

    owner_id = auth_manager.verify_api_key(api_key)
    if not owner_id:
        raise AuthenticationError("认证失败", {"hint": "无效的 API Key"})

    if method_name in (
        "manage_archive",
        "archive_page",
        "restore_page",
        "auto_archive",
    ):
        requested_owner = params.get("owner_id")
        if requested_owner and requested_owner != owner_id:
            raise AuthorizationError("无权访问该资源", {"hint": "您只能操作自己的数据"})
        params["owner_id"] = owner_id

    return {"owner_id": owner_id, "authenticated": True}


if __name__ == "__main__":
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="Agent Memory API")
    parser.add_argument("--method", required=True, help="要调用的方法名")
    parser.add_argument("--params", default="{}", help="JSON 参数")
    parser.add_argument(
        "--api-key", "--api_key", dest="api_key", help="API Key 认证令牌"
    )
    parser.add_argument(
        "--admin", action="store_true", help="管理员模式（跳过 owner_id 验证）"
    )
    args = parser.parse_args()

    method_name = args.method

    if method_name not in ALLOWED_METHODS:
        print(json.dumps({"success": False, "error": f"未知方法: {method_name}"}))
        sys.exit(1)

    try:
        params = json.loads(args.params)
    except json.JSONDecodeError:
        print(json.dumps({"success": False, "error": "参数 JSON 格式错误"}))
        sys.exit(1)

    auth_context = {"authenticated": False, "owner_id": None}

    if args.admin:
        admin_disabled = os.environ.get("ADMIN_MODE_DISABLED", "").lower() in (
            "true",
            "1",
            "yes",
        )
        admin_enabled = os.environ.get("ADMIN_MODE_ENABLED", "").lower() in (
            "true",
            "1",
            "yes",
        )
        is_production = os.environ.get("NODE_ENV") == "production"

        if admin_disabled or (is_production and not admin_enabled):
            print(
                json.dumps(
                    {
                        "success": False,
                        "error": "Admin mode is disabled in this environment",
                    }
                )
            )
            sys.exit(1)
        auth_context = {"authenticated": True, "owner_id": None, "admin": True}
    else:
        try:
            auth_result = cli_require_auth(method_name, params, args.api_key)
            auth_context = auth_result

            # 速率限制检查
            from rate_limiter import get_rate_limiter, RateLimitError

            limiter = get_rate_limiter()
            allowed, remaining = limiter.check_rate_limit(
                auth_context.get("owner_id", "anonymous")
            )
            if not allowed:
                raise RateLimitError("请求过于频繁，请稍后再试", {"retry_after": 60})
        except Exception as e:
            print(
                json.dumps(
                    {
                        "success": False,
                        "error": SecurityConfig.sanitize_error_message(
                            f"{type(e).__name__}: {e}"
                        ),
                    }
                )
            )
            sys.exit(1)

    api = get_memory_api()

    # 方法分发（使用认证后的 owner_id）
    def get_owner_id(default: str = None) -> str:
        if auth_context.get("admin"):
            return params.get("owner_id", default or "default")
        owner = auth_context.get("owner_id")
        if not owner:
            owner_id_param = params.get("owner_id")
            if owner_id_param:
                raise AuthorizationError(
                    "无权访问该资源", {"hint": "您只能访问自己的数据"}
                )
            return default or "default"
        requested = params.get("owner_id")
        if requested and requested != owner:
            raise AuthorizationError("无权访问该资源", {"hint": "您只能访问自己的数据"})
        return owner

    try:
        if method_name == "process_conversation":
            result = api.process_conversation(
                conversation=params.get("conversation", []),
                owner_id=get_owner_id("default"),
                session_id=params.get("session_id"),
            )
        elif method_name == "search_events":
            result = api.search_events(
                query=params.get("query", ""),
                owner_id=get_owner_id(),
                max_results=min(params.get("max_results", 10), 100),
            )
        elif method_name == "read_page":
            result = api.read_page(
                page_id=params.get("page_id"),
                layers=params.get("layers", [1, 2, 3]),
                include_related=params.get("include_related", False),
                owner_id=get_owner_id(),
                auth_context=auth_context,
            )
        elif method_name == "merge_pages":
            result = api.merge_pages(
                source_page_ids=params.get("source_page_ids", []),
                merge_type=params.get("merge_type", "related"),
                merge_reason=params.get("merge_reason", ""),
                owner_id=get_owner_id(),
            )
        elif method_name == "get_profile":
            result = api.get_profile(owner_id=get_owner_id("default"))
        elif method_name == "update_profile":
            result = api.update_profile(
                owner_id=get_owner_id("default"),
                updates=params.get("updates", {}),
            )
        elif method_name == "get_stats":
            result = api.get_stats(owner_id=get_owner_id())
        elif method_name == "manage_archive":
            result = api.manage_archive(
                action=params.get("action"),
                target=params.get("target", {}),
                owner_id=get_owner_id(),
            )
        elif method_name == "archive_page":
            result = api.archive_page(
                page_id=params.get("page_id"),
                owner_id=get_owner_id("default"),
                reason=params.get("reason", "manual"),
            )
        elif method_name == "get_archive_config":
            result = api.get_archive_config(owner_id=get_owner_id("default"))
        elif method_name == "set_archive_config":
            result = api.set_archive_config(
                owner_id=get_owner_id("default"), config=params.get("config", {})
            )
        elif method_name == "get_archived_pages":
            result = api.get_archived_pages(
                owner_id=get_owner_id(), limit=min(params.get("limit", 50), 200)
            )
        elif method_name == "restore_page":
            authorized_owner = get_owner_id() if not auth_context.get("admin") else None
            result = api.restore_page(
                archive_id=params.get("archive_id"),
                authorized_owner_id=authorized_owner,
            )
        elif method_name == "auto_archive":
            result = api.auto_archive(
                owner_id=get_owner_id("default"), days=params.get("days", 180)
            )
        elif method_name == "detect_similar_pages":
            threshold = params.get("threshold", 0.7)
            threshold = max(0.0, min(1.0, threshold))
            result = api.detect_similar_pages(
                owner_id=get_owner_id("default"),
                threshold=threshold,
                limit=min(params.get("limit", 10), 50),
            )
    except Exception as e:
        result = {
            "success": False,
            "error": SecurityConfig.sanitize_error_message(f"{type(e).__name__}: {e}"),
        }

    print(json.dumps(result, ensure_ascii=False))
