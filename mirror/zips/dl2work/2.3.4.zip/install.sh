#!/bin/bash
# Agent Memory Database 安装脚本
# 用法: ./install.sh [--uninstall]
#
# 安装: ./install.sh
# 卸载: ./install.sh --uninstall

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_NAME="agent-memory"
DATA_DIR="$HOME/.local/share/$PROJECT_NAME"

if [ "$1" = "--uninstall" ]; then
    echo "========================================"
    echo "  Agent Memory Database 卸载"
    echo "========================================"
    echo ""
    
    echo "[1/4] 卸载 Python 依赖..."
    if [ -f "$SCRIPT_DIR/requirements.txt" ]; then
        while IFS= read -r package; do
            if [[ "$package" =~ ^# ]] || [[ -z "$package" ]]; then
                continue
            fi
            pkg_name=$(echo "$package" | sed 's/[<>=!].*//' | xargs)
            if [ -n "$pkg_name" ]; then
                pip3 uninstall -y "$pkg_name" 2>/dev/null || true
            fi
        done < "$SCRIPT_DIR/requirements.txt"
    fi
    echo "✓ Python 依赖已卸载"
    
    echo "[2/4] 清理数据文件..."
    rm -rf "$DATA_DIR"
    rm -f /tmp/agent_memory.db
    echo "✓ 数据文件已清理"
    
    echo "[3/4] 清理配置..."
    rm -rf "$HOME/.agent-memory"
    echo "✓ 配置已清理"
    
    echo "[4/4] 清理项目文件..."
    rm -rf "$SCRIPT_DIR"
    echo "✓ 项目文件已删除"
    
    echo ""
    echo "========================================"
    echo "  卸载完成！"
    echo "========================================"
    echo ""
    echo "注意：如设置了永久环境变量，请手动编辑 ~/.bashrc 删除相关行"
    echo "  grep -E 'MINIMAX|API_KEY|AGENT_MEMORY' ~/.bashrc"
    exit 0
fi

echo "========================================"
echo "  Agent Memory Database 安装"
echo "========================================"
echo ""

if ! command -v python3 &> /dev/null; then
    echo "❌ 错误: 未找到 python3，请先安装 Python 3.8+"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "✓ Python 版本: $PYTHON_VERSION"

if ! command -v pip3 &> /dev/null; then
    echo "❌ 错误: 未找到 pip3"
    exit 1
fi
echo "✓ pip3 已就绪"

cd "$SCRIPT_DIR"

echo "[1/3] 安装 Python 依赖..."
pip3 install -r requirements.txt --quiet 2>/dev/null || pip3 install -r requirements.txt
echo "✓ 依赖安装完成"

echo "[2/3] 创建数据目录..."
mkdir -p "$DATA_DIR"
echo "✓ 数据目录: $DATA_DIR"

echo "[3/3] 验证安装..."
if python3 -c "import sys; sys.path.insert(0, 'src'); from memory_core import AgentMemoryDB; print('OK')" 2>/dev/null; then
    echo "✓ 核心模块验证通过"
else
    echo "⚠️  模块导入测试失败，请检查依赖"
fi

echo ""
echo "========================================"
echo "  安装完成！"
echo "========================================"
echo ""
echo "必需环境变量:"
echo "  export MINIMAX_API_KEY='your_api_key'"
echo ""
echo "可选环境变量:"
echo "  export AGENT_MEMORY_DB_PATH='/custom/path/memory.db'"
echo "  export ADMIN_MODE_DISABLED=true"
echo ""
echo "快速测试:"
echo "  python3 -c \"import sys; sys.path.insert(0, 'src'); from api import get_memory_api; print('OK')\""