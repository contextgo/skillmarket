#!/bin/bash
# Agent Memory Database 卸载脚本
# 用法: ./uninstall.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_NAME="agent-memory"
DATA_DIR="$HOME/.local/share/$PROJECT_NAME"

echo "========================================"
echo "  Agent Memory Database 卸载"
echo "========================================"
echo ""

echo "[1/4] 卸载 Python 依赖..."
if [ -f "$SCRIPT_DIR/requirements.txt" ]; then
    while IFS= read -r package; do
        if [[ "$package" =~ ^# ]] || [[ -z "$package" ]]; then
            continue
        fi
        pkg_name=$(echo "$package" | sed 's/[<>=!].*//' | xargs)
        if [ -n "$pkg_name" ]; then
            pip3 uninstall -y "$pkg_name" 2>/dev/null || true
        fi
    done < "$SCRIPT_DIR/requirements.txt"
fi
echo "✓ Python 依赖已卸载"

echo "[2/4] 清理数据文件..."
rm -rf "$DATA_DIR"
rm -f /tmp/agent_memory.db
echo "✓ 数据文件已清理"

echo "[3/4] 清理配置..."
rm -rf "$HOME/.agent-memory"
echo "✓ 配置已清理"

echo "[4/4] 清理项目文件..."
rm -rf "$SCRIPT_DIR"
echo "✓ 项目文件已删除"

echo ""
echo "========================================"
echo "  卸载完成！"
echo "========================================"
echo ""
echo "注意：如设置了永久环境变量，请手动编辑 ~/.bashrc 删除相关行"
echo "  grep -E 'MINIMAX|API_KEY|AGENT_MEMORY' ~/.bashrc"