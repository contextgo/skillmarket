# Agent Memory Database

> 模拟人类记忆的 AI Agent 记忆系统 | 版本: v2.3.3 | 更新: 2026-04-07

---

## 核心特性

- 🧠 **三层记忆结构**: 关键词(L1) → 摘要(L2) → 完整内容(L3)
- 🔍 **智能搜索**: TF-IDF 向量相似度 + 关键词匹配
- 🎯 **自动分类**: 浪费/画像/事件智能识别
- 🔗 **相似度检测**: 自动发现相似事件并提供合并建议
- 🗄️ **归档系统**: 自动归档旧记忆，支持恢复
- 🔐 **安全机制**: API Key 认证、权限隔离、速率限制
- ⚡ **性能优化**: Token 节省 60-70%，写入减少 99%

---

## 5分钟快速开始

### 1. 安装

```bash
cd agent-memory
./install.sh
```

### 2. 配置 API Key

```bash
export MINIMAX_API_KEY="your-api-key"
```

### 3. 测试运行

```python
import sys
sys.path.insert(0, 'src')
from api import get_memory_api

api = get_memory_api()
result = api.process_conversation(
    conversation=[{"role": "user", "content": "我喜欢喝咖啡"}],
    owner_id="user_001"
)
print(result)
```

### 4. 搜索记忆

```python
results = api.search_events(query="咖啡", owner_id="user_001")
print(results)
```

**✅ 完成！开始使用记忆系统。**

---

## 核心架构

```
┌─────────────────────────────────────┐
│        三层页表记忆结构              │
│                                     │
│  L1: 关键词 (200B)                  │
│  └─→ L2: 摘要 (2KB)                │
│      └─→ L3: 完整内容 (20KB)       │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│      用户画像区（独立存储）          │
│  preferences | habits | background  │
└─────────────────────────────────────┘
```

---

## 文档导航

### 📚 完整文档

| 文档 | 功能 | 适用场景 |
|------|------|---------|
| [GUIDE.md](GUIDE.md) | 用户使用指南 | API 使用、数据结构、最佳实践 |
| [DEPLOYMENT.md](DEPLOYMENT.md) | 部署运维手册 | 安装、配置、生产部署、监控 |
| [API.md](API.md) | API 参考手册 | 所有 API 返回格式、参数说明 |
| [SECURITY.md](SECURITY.md) | 安全手册 | 安全配置、安全检查清单 |
| [CHANGELOG.md](CHANGELOG.md) | 版本历史 | 版本更新记录 |

### 🚀 按场景导航

**新手入门**:
1. 本文档（README.md）- 5分钟快速开始
2. [GUIDE.md](GUIDE.md) - 学习完整 API

**生产部署**:
1. [DEPLOYMENT.md](DEPLOYMENT.md) - 完整部署流程
2. [SECURITY.md](SECURITY.md) - 安全配置

**API 集成**:
1. [GUIDE.md](GUIDE.md) - API 使用说明
2. [API.md](API.md) - API 返回格式

---

## 核心功能演示

### 1. 处理对话并存储记忆

```python
result = api.process_conversation(
    conversation=[
        {"role": "user", "content": "我今天学习了 Python"},
        {"role": "agent", "content": "学习 Python 的哪个部分？"}
    ],
    owner_id="user_001"
)
```

### 2. 搜索记忆

```python
results = api.search_events(
    query="Python 学习",
    owner_id="user_001",
    max_results=10
)
```

### 3. 读取记忆详情

```python
page = api.read_page(
    page_id="page_xxx",
    layers=[1, 2, 3]  # L1:关键词, L2:摘要, L3:完整
)
```

### 4. 用户画像

```python
# 获取画像
profile = api.get_profile(owner_id="user_001")

# 更新画像
api.update_profile(
    owner_id="user_001",
    updates={"preferences": {"language": "Python"}}
)
```

### 5. 相似度检测与合并

```python
# 检测相似页面
similar = api.detect_similar_pages(owner_id="user_001", threshold=0.7)

# 合并相似页面
api.merge_pages(
    source_page_ids=["page_1", "page_2"],
    merge_type="same_event",
    owner_id="user_001"
)
```

---

## 性能指标

| 指标 | 数值 |
|------|------|
| Token 节省 | 60-70% |
| LLM 调用减少 | 66% |
| 关键对话延迟降低 | 96% |
| 数据写入减少 | 99% |

---

## 项目结构

```
agent-memory/
├── src/                   # 源代码（纯Python）
│   ├── api.py             # API 主入口
│   ├── memory_core.py     # 核心数据库
│   ├── llm_processor.py   # LLM 处理器
│   └── plugin/            # OpenClaw 插件
├── tests/                 # 测试
├── docs/                  # 文档
├── install.sh             # 安装脚本
└── requirements.txt       # Python依赖
```

---

## 快速链接

- 📖 [完整使用指南](GUIDE.md)
- 🚀 [部署运维手册](DEPLOYMENT.md)
- 📋 [API 参考手册](API.md)
- 🔐 [安全手册](SECURITY.md)
- 📝 [版本历史](CHANGELOG.md)

---

## 许可证

MIT License

---

**版本**: v2.3.3 | **状态**: ✅ 生产就绪 | **安全评分**: 9.8/10