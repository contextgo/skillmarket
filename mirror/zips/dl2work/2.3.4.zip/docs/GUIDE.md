# Agent Memory 用户使用指南

> 版本: v2.3.3 | 更新: 2026-04-07

---

## 核心 API 使用

### 1. 处理对话并存储记忆

```python
from api import get_memory_api

api = get_memory_api()

result = api.process_conversation(
    conversation=[
        {"role": "user", "content": "我今天学习了 Python"},
        {"role": "agent", "content": "学习 Python 的哪个部分？"},
        {"role": "user", "content": "学习了基础语法和列表操作"}
    ],
    owner_id="user_001",
    session_id="session_xxx"  # 可选
)
```

**自动处理流程**:
1. 智能分类：识别为 waste/画像/event
2. 画像信息：更新用户偏好
3. 事件信息：生成三层页表
4. 相似度检测：返回合并建议

---

### 2. 搜索记忆

```python
# 基础搜索
results = api.search_events(
    query="Python 学习",
    owner_id="user_001",
    max_results=10
)

# 时间范围搜索
results = api.search_events(
    query="Python",
    owner_id="user_001",
    time_range={"start": "2026-01-01", "end": "2026-04-01"},
    max_results=10
)
```

**返回字段**:
- `page_id`: 页面 ID
- `similarity_score`: 混合评分 (0.7 * vector + 0.3 * keyword)
- `time_hint`: 绝对时间 YYYY-MM-DD
- `keywords`: 关键词字典

---

### 3. 读取记忆详情

```python
# 读取所有层级
page = api.read_page(
    page_id="page_xxx",
    layers=[1, 2, 3]
)

# 只读取摘要层
page = api.read_page(
    page_id="page_xxx",
    layers=[2]
)
```

**层级说明**:
- **L1 (关键词层)**: 最简洁，用于快速筛选
- **L2 (摘要层)**: 推荐优先查看
- **L3 (完整内容层)**: 完整对话内容

---

### 4. 用户画像管理

```python
# 获取画像
profile = api.get_profile(owner_id="user_001")
# 返回: preferences, habits, background, evidence

# 更新画像
api.update_profile(
    owner_id="user_001",
    updates={
        "preferences": {"language": "Python"},
        "habits": ["每晚学习"]
    }
)
```

---

### 5. 相似度检测与合并

```python
# 检测相似页面
similar = api.detect_similar_pages(
    owner_id="user_001",
    threshold=0.7,  # 相似度阈值
    limit=10
)

# 合并相似页面
api.merge_pages(
    source_page_ids=["page_1", "page_2"],
    merge_type="same_event",  # same_event/update/related
    merge_reason="描述同一事件",
    owner_id="user_001"
)
```

**相似度阈值建议**:
- `> 0.8`: 建议合并 (same_event)
- `0.7 - 0.8`: 可考虑合并
- `< 0.7`: 保持独立

---

### 6. 归档管理

```python
# 归档单个页面
api.archive_page(
    page_id="page_xxx",
    owner_id="user_001",
    reason="manual"
)

# 自动归档（保留180天）
api.auto_archive(owner_id="user_001", days=180)

# 查看归档列表
archives = api.get_archived_pages(owner_id="user_001", limit=50)

# 恢复归档
api.restore_page(archive_id="archive_xxx")
```

---

### 7. 统计信息

```python
# 全局统计
stats = api.get_stats()

# 用户统计
stats = api.get_stats(owner_id="user_001")
```

**返回字段**:
- `event_pages`: 活跃/已合并/已归档页面数
- `profiles`: 活跃画像数
- `search_index`: 已索引页面数
- `date_range`: 数据时间范围

---

## 数据结构说明

### 三层页表结构

```
L1 (关键词层) ~200B
├─ event_type: ["事件类型"]
├─ who: ["参与者"]
├─ where: ["地点"]
├─ what: ["事件"]
├─ time_hint: "2026-04-05"
└─ event_date: "2026-04-05"

L2 (摘要层) ~2KB
├─ summary: "摘要内容"
├─ entities: [{"type": "person", "name": "..."}]
├─ key_facts: ["关键事实"]
└─ conclusion: "结论"

L3 (完整内容层) ~20KB
├─ content: "完整对话"
├─ created_at: "2026-04-05T10:00:00+00:00"
└─ status: "active"
```

### 用户画像结构

```python
{
    "profile_id": "xxx",
    "owner_id": "user_001",
    "content": {
        "preferences": {"response_style": "简洁"},
        "habits": ["每晚学习"],
        "background": {"职业": "工程师"}
    },
    "evidence": [{"page_id": "...", "source": "conversation"}],
    "version": 5
}
```

---

## 最佳实践

### 1. 及时存储重要对话

```python
# ✅ 推荐：重要信息及时存储
api.process_conversation(
    conversation=[
        {"role": "user", "content": "我下周三有个重要会议"},
        {"role": "agent", "content": "好的，我记住了"}
    ],
    owner_id="user_001"
)
```

### 2. 使用准确的关键词搜索

```python
# ✅ 推荐：使用具体关键词
api.search_events(query="会议 下周三", owner_id="user_001")

# ❌ 不推荐：过于宽泛
api.search_events(query="事情", owner_id="user_001")
```

### 3. 优先查看摘要层

```python
# ✅ 推荐：先看摘要，必要时再看完整内容
page = api.read_page(page_id="xxx", layers=[2])  # 摘要层

if need_details:
    page = api.read_page(page_id="xxx", layers=[2, 3])  # 摘要+完整
```

### 4. 定期整理记忆

```python
# 检测相似页面
similar = api.detect_similar_pages(owner_id="user_001", threshold=0.7)

# 合并相似页面
for suggestion in similar["suggestions"]:
    if suggestion["similarity"] > 0.8:
        api.merge_pages(
            source_page_ids=[suggestion["page_id_1"], suggestion["page_id_2"]],
            merge_type="same_event",
            owner_id="user_001"
        )
```

### 5. 使用归档而非删除

```python
# ✅ 推荐：归档旧记忆（可恢复）
api.auto_archive(owner_id="user_001", days=180)

# ❌ 不推荐：直接删除（不可恢复）
```

---

## 常见问题

### Q1: 搜索返回空结果？

**原因**: owner_id 不匹配或关键词不准确

**解决**:
```python
# 检查统计
stats = api.get_stats(owner_id="user_001")

# 使用正确 owner_id
results = api.search_events(query="关键词", owner_id="user_001")
```

### Q2: time_hint 显示相对时间？

**原因**: 旧数据未迁移

**解决**:
```bash
# 运行迁移脚本
python src/migrate_time_hint.py
```

### Q3: 相似度检测没有结果？

**原因**: 页面数量不足或阈值过高

**解决**:
```python
# 降低阈值
similar = api.detect_similar_pages(owner_id="user_001", threshold=0.6)
```

### Q4: 归档后如何恢复？

**解决**:
```python
# 查看归档列表
archives = api.get_archived_pages(owner_id="user_001")

# 恢复指定归档
api.restore_page(archive_id="archive_xxx")
```

---

## 性能优化建议

### 1. 批量处理对话

```python
# 使用 batch_processor
from batch_processor import get_batch_processor

processor = get_batch_processor()
processor.add_conversation(conversation)
```

### 2. 使用智能跳过

```python
# 自动过滤无意义对话
from smart_skip import get_skip_filter

skip_filter = get_skip_filter()
if not skip_filter.is_waste(conversation):
    api.process_conversation(conversation, owner_id)
```

---

## 相关文档

- [API 参考手册](API.md) - 所有 API 返回格式
- [部署运维手册](DEPLOYMENT.md) - 安装、配置、部署
- [安全手册](SECURITY.md) - 安全配置

---

**版本**: v2.3.3 | **更新**: 2026-04-07