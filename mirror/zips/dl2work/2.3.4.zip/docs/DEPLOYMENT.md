# Agent Memory 部署运维手册

> 版本: v2.3.3 | 更新: 2026-04-07

---

## 一、安装与卸载

### 安装

```bash
cd agent-memory
./install.sh
```

**安装内容**:
- Python 依赖 (numpy, openai)
- 数据库初始化
- 环境检查

### 卸载

```bash
# 方式一：使用 install.sh
./install.sh --uninstall

# 方式二：使用 uninstall.sh
./uninstall.sh
```

---

## 二、环境配置

### 系统要求

| 项目 | 要求 |
|------|------|
| Python | 3.8+ |
| 操作系统 | Linux / macOS |
| 内存 | ≥ 512MB |
| 存储 | ≥ 1GB |

### 必需配置

```bash
# MiniMax API Key（必需）
export MINIMAX_API_KEY="your-minimax-api-key"

# 或 OpenAI API Key
export OPENAI_API_KEY="your-openai-api-key"
```

### 可选配置

```bash
# 用户认证密钥（多用户场景）
export API_KEY_user001="secure-random-key-32chars"
export API_KEY_user002="another-secure-key-32chars"

# 数据库路径
export AGENT_MEMORY_DB_PATH="/data/agent-memory/memory.db"

# 生产环境保护
export ADMIN_MODE_DISABLED=true
export NODE_ENV=production
```

### 配置持久化

```bash
# 添加到 ~/.bashrc
echo "export MINIMAX_API_KEY='your-key'" >> ~/.bashrc
source ~/.bashrc
```

---

## 三、生产部署

### 本地服务部署

```bash
# 安装
./install.sh

# 配置环境变量（参考上方）

# 测试运行
python3 src/api.py --method get_stats --admin --params '{}'

# 正式运行（后台服务）
nohup python3 -m src.api &
```

### OpenClaw 插件部署

```bash
# 安装
./install.sh

# 插件入口: src/plugin/openclaw_plugin.py

# 在 OpenClaw 配置中添加插件路径
# 重启 OpenClaw
openclaw gateway restart
```

---

## 四、验证部署

### 功能验证

```bash
# 创建测试数据
python3 src/api.py \
    --method process_conversation \
    --api-key your-user-key \
    --params '{"conversation":[{"role":"user","content":"test"}],"owner_id":"test"}'

# 搜索测试
python3 src/api.py \
    --method search_events \
    --api-key your-user-key \
    --params '{"query":"test","owner_id":"test"}'

# 统计信息
python3 src/api.py \
    --method get_stats \
    --admin \
    --params '{}'
```

### 安全验证

```bash
# 测试认证失败（应返回"缺少认证信息"）
python3 src/api.py --method search_events --params '{"query":"test"}'

# 测试跨用户访问拒绝（应返回"无权访问该资源"）
python3 src/api.py \
    --method search_events \
    --api-key user001_key \
    --params '{"query":"test","owner_id":"user002"}'
```

---

## 五、监控与维护

### 日志监控

```bash
# 查看日志
tail -f logs/agent_memory_*.log

# 关键日志事件
# - 权限拒绝: "无权访问该资源"
# - 速率限制: "速率限制触发"
# - 认证失败: "无效的 API Key"
# - 归档操作: "页面已归档"
```

### 数据库维护

```bash
# 查看数据库位置
ls -lh ~/.local/share/agent-memory/memory.db

# 定期备份（建议每日）
cp /data/agent-memory/memory.db \
   /data/agent-memory/memory.db.backup-$(date +%Y%m%d)

# 自动归档旧数据（保留180天）
python3 src/api.py \
    --method auto_archive \
    --admin \
    --params '{"days":180}'
```

### 性能监控

```bash
# 获取统计信息
python3 src/api.py --method get_stats --admin --params '{}'

# 输出示例:
# {
#   "event_pages": {"active": 150, "merged": 20, "archived": 35},
#   "profiles": {"active": 5},
#   "search_index": {"indexed_pages": 130}
# }
```

---

## 六、故障排查

### 常见问题

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| "缺少认证信息" | 未提供 API Key | 添加 `--api-key` 参数 |
| "无效的 API Key" | API Key 不匹配 | 检查环境变量 `API_KEY_*` |
| "无权访问该资源" | 跨用户访问 | 使用正确的 owner_id |
| "请求过于频繁" | 速率限制触发 | 等待60秒后重试 |
| "Admin mode disabled" | 生产环境保护 | 设置 `ADMIN_MODE_ENABLED=true` |

### 日志分析

```bash
# 查看错误日志
grep ERROR logs/agent_memory_*.log

# 查看审计日志（数据库）
sqlite3 /data/agent-memory/memory.db \
    "SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT 10"
```

---

## 七、安全配置

### 数据库安全

```bash
# 创建数据目录并设置权限
mkdir -p /data/agent-memory
chmod 700 /data/agent-memory

# 数据库文件权限
chmod 600 /data/agent-memory/memory.db

# 日志目录权限
mkdir -p logs
chmod 700 logs
```

### 安全检查清单

#### 必需配置 ✅

- [ ] `MINIMAX_API_KEY` 已配置
- [ ] `ADMIN_MODE_DISABLED=true` 已设置
- [ ] `NODE_ENV=production` 已设置
- [ ] 数据库文件权限 `600`
- [ ] 数据目录权限 `700`

#### 功能验证 ✅

- [ ] 认证机制正常工作
- [ ] 权限隔离有效
- [ ] 速率限制生效
- [ ] 数据存储正常

---

## 八、性能优化

### 批量处理

```python
from batch_processor import get_batch_processor

processor = get_batch_processor()
processor.add_conversation(conversation, owner_id)
```

### 定时保存

```python
from memory_scheduler import get_scheduler

scheduler = get_scheduler()
scheduler.start(save_interval_hours=1)
```

---

## 九、升级与回滚

### 升级流程

```bash
# 备份数据
cp /data/agent-memory/memory.db /data/agent-memory/memory.db.bak

# 更新代码
git pull origin main

# 重新安装
./install.sh

# 验证升级
python3 tests/test_integration.py --test all
```

### 回滚操作

```bash
# 恢复数据
cp /data/agent-memory/memory.db.bak /data/agent-memory/memory.db

# 回退代码
git checkout v2.3.2

# 重启服务
```

---

## 十、常用命令速查

### 安装相关

```bash
./install.sh                          # 安装
./install.sh --uninstall              # 卸载
./uninstall.sh                        # 快速卸载
pip3 list | grep -E "openai|numpy"   # 验证安装
```

### 测试相关

```bash
python3 tests/test_integration.py --test all      # 所有测试
python3 tests/test_integration.py --test basic    # 基础测试
python3 tests/test_integration.py --test similarity  # 相似度测试
```

### 运维相关

```bash
tail -f logs/agent_memory_*.log                   # 查看日志
sqlite3 memory.db "SELECT * FROM audit_log"      # 审计日志
python3 src/api.py --method get_stats --admin    # 统计信息
```

---

## 相关文档

- [用户使用指南](GUIDE.md) - API 使用说明
- [安全手册](SECURITY.md) - 安全配置详情
- [API 参考手册](API.md) - API 返回格式

---

**版本**: v2.3.3 | **更新**: 2026-04-07