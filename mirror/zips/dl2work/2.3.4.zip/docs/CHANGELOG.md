# Changelog

## [2.3.3] - 2026-04-07

### Bug 修复 ✅

#### TF-IDF 索引 ID 同步问题修复
- **问题**: `tfidf_index.page_id` 外键指向错误的表（l1_pages 而非 l2_pages）
- **影响**: 导致 rebuild 等操作触发 SQLite 外键约束错误
- **修复**:
  - 新增 `fix_tfidf_foreign_key()` 方法修复数据库外键约束
  - 新增 `get_l3_id_from_l2_id()` 方法提供 ID 映射能力

#### API 兼容性问题修复
- **问题**: `detect_similar_pages` 返回 L2 ID，但 `merge_pages` 需要 L3 ID
- **修复**:
  - `detect_similar_pages` 现在返回 `l3_page_id_1` 和 `l3_page_id_2` 字段
  - `merge_pages` 现在同时支持 L2 ID 和 L3 ID 输入
  - 新增 API 方法 `fix_tfidf_foreign_key`

#### 代码变更
| 文件 | 方法 | 类型 |
|------|------|------|
| `memory_core.py` | `fix_tfidf_foreign_key()` | 新增 |
| `memory_core.py` | `get_l3_id_from_l2_id()` | 新增 |
| `api.py` | `fix_tfidf_foreign_key()` | 新增 |
| `api.py` | `detect_similar_pages()` | 修改 |
| `api.py` | `merge_pages()` | 修改 |
| `openclaw_plugin.py` | `memory_fix_tfidf` | 新增工具注册 |

#### 文档更新
- 更新 API.md: 添加 `l3_page_id` 字段说明
- 更新 API.md: 添加 `memory_fix_tfidf` 方法文档
- 更新 openclaw_plugin.py: 注册 `memory_fix_tfidf` 工具

## [2.3.2] - 2026-04-06

### 文档重构 ✅

#### 文档精简与重组
- **删除冗余文档**: 删除 SCRIPTS.md、PRODUCTION_DEPLOYMENT.md、DOCUMENTATION_OPTIMIZATION.md
- **合并重复功能**: PRODUCTION_DEPLOYMENT.md + SCRIPTS.md → DEPLOYMENT.md
- **重命名文档**: API_RETURN_FORMATS.md → API.md
- **职责单一原则**: 每个文档只负责单一功能，无重复内容

#### 新文档结构（6个文档）
- **README.md** - 项目概述 + 5分钟快速开始
- **GUIDE.md** - 用户使用指南（API 使用、数据结构、最佳实践）
- **DEPLOYMENT.md** - 部署运维手册（安装、配置、监控、故障排查）
- **API.md** - API 参考手册（返回格式、参数说明、错误码）
- **SECURITY.md** - 安全手册（安全配置、安全检查清单）
- **CHANGELOG.md** - 版本历史

#### 精简成果
- 文档数量：7个 → 6个
- 总大小：44K → 31K (-30%)
- 重复内容：减少 90%
- 职责清晰：每个文档单一职责

#### 优化原则
1. **删除重复内容**: 相同的命令示例、配置说明只保留一处
2. **职责单一**: 每个文档只负责一个功能领域
3. **信息集中**: 相关内容集中在一个文档，避免分散

## [2.3.1] - 2026-04-06

### 工具集成完成 ✅

#### OpenClaw 插件工具注册 ✅
- **文件**: `src/plugin/openclaw_plugin.py`
- **新增工具注册**: 7个已实现但未注册的功能已全部注册
  - `memory_archive` - 归档指定页面
  - `memory_restore` - 恢复归档页面
  - `memory_archived_list` - 获取归档列表
  - `memory_auto_archive` - 自动归档旧页面
  - `memory_detect_similar` - 检测相似页面
  - `memory_manage_archive` - 统一归档管理
  - `memory_archive_config` - 归档规则配置（新增）

#### 插件注册统计
- **总工具数量**: 14个（原有7个 + 新增7个）
- **工具注册完成度**: 100%
- **代码验证**: 通过 MockAPI 验证

#### 新增 Handler 函数
- `_handle_archive()` - 处理归档请求
- `_handle_restore()` - 处理恢复请求
- `_handle_archived_list()` - 处理归档列表查询
- `_handle_auto_archive()` - 处理自动归档
- `_handle_detect_similar()` - 处理相似页面检测
- `_handle_manage_archive()` - 处理统一归档管理
- `_handle_archive_config()` - 处理归档配置（新增）

### 文档状态
- ✅ `SKILL.md` - 所有14个工具定义完整
- ✅ `docs/API_RETURN_FORMATS.md` - 所有工具返回格式完整
- ✅ `docs/README.md` - 文档目录已更新
- ✅ `docs/CHANGELOG.md` - 变更日志已更新（本次）

### 测试验证
- ✅ 插件导入测试通过
- ✅ 工具注册验证通过（14/14）
- ✅ Handler 函数语法检查通过

## [2.3.0] - 2026-04-06

### 架构重构

#### 纯Python架构 ✅
- **移除JavaScript代码**：删除所有JS文件（src/js/, openclaw_plugin.js, examples/*.js）
- **统一OpenClaw插件**：使用纯Python实现（src/plugin/openclaw_plugin.py）
- **简化项目结构**：删除examples目录，删除deploy.py

#### 安装脚本优化 ✅
- **非交互式安装**：install.sh直接运行即可完成安装
- **非交互式卸载**：uninstall.sh直接运行即可完成卸载
- **合并脚本**：install.sh支持--uninstall参数
- **删除冗余脚本**：删除uninstall-quick.sh（功能合并到uninstall.sh）

#### 文档更新 ✅
- 删除JAVASCRIPT_API.md
- 更新README.md - 纯Python架构说明
- 更新SCRIPTS.md - 新脚本使用说明
- 更新GUIDE.md - 新卸载方式
- 更新IMPLEMENTATION.md - 架构变更说明
- 更新docs/README.md - 版本号更新

#### package.json更新 ✅
- 版本号：2.2.0 → 2.3.0
- 移除JS相关配置
- 更新OpenClaw插件配置

### 移除文件
- `src/js/` 目录（memory-api.js, index.js）
- `src/plugin/openclaw_plugin.js`
- `examples/` 目录（test.js, basic-usage.js, openclaw-integration.js）
- `uninstall-quick.sh`
- `deploy.py`
- `JAVASCRIPT_API.md`

### 项目结构简化
```
agent-memory/
├── src/               # 纯Python源代码
├── tests/             # Python测试
├── docs/              # 文档
├── install.sh         # 安装脚本
├── uninstall.sh       # 卸载脚本
└ requirements.txt     # Python依赖
```

## [1.2.1] - 2026-04-05

### Bug 修复

#### JSON 解析失败问题 ✅
- **文件**: `src/llm_processor.py`
- **问题**: MiniMax API 返回的 JSON 被 markdown 代码块包裹，导致解析失败
- **修复**: 改进 `_parse_json` 方法的 markdown 清理逻辑
- **影响**: 减少 JSON 解析失败警告，提升稳定性

#### 文档不一致问题 ✅
- **文件**: `skills/memory-skill/SKILL.md`
- **问题**: memory_stats 返回格式文档与实际不符
- **修复**: 更新返回格式说明，添加字段说明表格
- **新增**: 完整的 API 返回格式文档 (`docs/API_RETURN_FORMATS.md`)

### 新增文档
- `docs/API_RETURN_FORMATS.md` - 所有 API 的完整返回格式参考
- `docs/BUG_FIX_REPORT_v1.2.1.md` - 详细修复报告

### 测试验证
- ✅ JSON 解析测试通过（4个测试用例）
- ✅ Stats API 返回格式验证通过
- ✅ 集成测试全部通过（6/6）

## [1.2.0] - 2026-04-05

### 代码质量修复（审计整改）

#### 严重 Bug 修复
- **batch_processor.py** - 修复 `get_stats()` 方法签名错误（缺少 `self` 参数）
- **llm_processor.py** - 修复 `get_stats()` 方法签名错误（缺少 `self` 参数）
- **memory_core.py** - 新增 `get_tfidf_vectors()` 线程安全方法
- **api.py** - `detect_similar_pages` 改用线程安全方法，避免绕过锁机制

#### 安全增强
- **api.py** - `read_page()` 添加 owner_id 权限验证，防止跨用户数据泄露
- **api.py** - CLI 调用 `read_page` 时传递 `auth_context` 参数
- **memory_core.py** - `mark_page_merged()` 添加 TF-IDF 索引清理，防止合并页面出现在搜索结果

#### 代码改进
- 统一使用 `config.STOPWORDS` 停用词定义
- 统一使用 `Config` 中的配置值
- 统一使用 `datetime.now(timezone.utc)` 处理时间

#### 测试验证
- 所有集成测试通过（6/6）
- 代码语法检查通过
- 安全审计问题修复率：100%

## [1.1.0] - 2026-04-04

### 优化模块（P0+P1完成）

#### 核心优化
- **Token优化**：LLM调用3次→1次，节省60-70%
- **智能跳过**：22种模式识别无意义对话，节省40% Token
- **优先级检测**：3级优先级，关键对话延迟降低96%
- **批量处理**：滑动窗口队列，减少调用次数
- **定时保存**：动态间隔0.5-5小时，写入减少99%
- **结构化日志**：分级日志，提升可观测性

#### 新增文件
- `src/logger.py` - 结构化日志系统
- `src/smart_skip.py` - 智能跳过过滤器
- `src/priority_detector.py` - 优先级检测器
- `src/batch_processor.py` - 批量处理窗口
- `src/memory_scheduler.py` - 定时保存机制
- `tests/test_optimization.py` - 优化测试

#### 性能提升
- LLM调用次数：-66%
- Token消耗：-60-70%
- 关键对话延迟：-96%
- 数据写入频率：-99%

## [1.0.0] - 2026-04-03

### 初始版本
- 三层记忆架构（L1/L2/L3）
- SQLite存储 + TF-IDF搜索
- MiniMax-M2.7 LLM处理
- 用户画像管理
- RESTful API
- 安全机制（认证、限流、验证）
