# Agent Memory 实用指南

> 基于实际使用经验编写 | 版本: v2.3.3 | 更新: 2026-04-07

---

## 目录

1. [快速开始](#快速开始)
2. [环境配置](#环境配置)
3. [日常使用场景](#日常使用场景)
4. [CLI 命令行工具](#cli-命令行工具)
5. [Python API 调用](#python-api-调用)
6. [常见问题与解决](#常见问题与解决)
7. [最佳实践](#最佳实践)

---

## 快速开始

### 1. 设置 API Key

```bash
export MINIMAX_API_KEY=your-api-key
```

### 2. 基础调用示例

```python
import sys
sys.path.insert(0, '/path/to/agent-memory/src')

from api import get_memory_api
api = get_memory_api(owner_id='daivy')

# 存储对话
conversation = [
    {'role': 'user', 'content': '今天做了什么事情'},
    {'role': 'agent', 'content': '我来帮你记录'}
]
result = api.process_conversation(conversation, 'daivy')

# 搜索记忆
results = api.search_events('生日 礼物', max_results=5)

# 读取详情
detail = api.read_page(page_id, layers=[2, 3])

# 获取统计
stats = api.get_stats('daivy')
```

> 更多 API 详细说明请查看 [API 参考手册](API.md)

---

## 环境配置

### 数据库位置

默认数据库路径: `~/.local/share/agent-memory/memory.db`

### 首次使用检查清单

1. **设置 API Key**（必需）
2. **运行外键修复**（如果是从旧版本升级）
   ```python
   from memory_core import get_memory_db
   db = get_memory_db()
   db.fix_tfidf_foreign_key()
   ```
3. **检查向量索引**（如果搜索/合并有问题）
   ```bash
   cd /path/to/agent-memory
   PYTHONPATH=src python3 -c "
   from fix_vectors import diagnose_vectors
   diagnose_vectors('daivy')
   "
   ```

---

## 日常使用场景

### 场景1: 保存日常对话记忆

```python
api.process_conversation([
    {'role': 'user', 'content': '今天我们去看了电影'},
    {'role': 'agent', 'content': '什么类型的电影呀？'},
    {'role': 'user', 'content': '是一部爱情片，很浪漫'}
], 'daivy', 'session_123')
```

### 场景2: 搜索历史记忆

```python
results = api.search_events('浪漫 约会', max_results=5)
for r in results['results']:
    print(f"相似度: {r['similarity_score']:.2f}")
    print(f"时间: {r['time_hint']}")
    print(f"关键词: {r['keywords']['what']}")
```

### 场景3: 读取记忆详情

```python
summary = api.read_page(page_id, layers=[2])
full = api.read_page(page_id, layers=[3])
all_layers = api.read_page(page_id, layers=[1, 2, 3])
```

### 场景4: 定期整理记忆（定时任务）

```python
# 1. 获取统计
stats = api.get_stats('daivy')

# 2. 检测相似页面
similar = api.detect_similar_pages('daivy', threshold=0.8)

# 3. 自动合并高相似页面
for pair in similar['suggestions']:
    if pair['similarity'] >= 0.85:
        api.merge_pages(
            [pair['l3_page_id_1'], pair['l3_page_id_2']],
            pair['suggested_merge_type'],
            '自动合并相似记忆',
            'daivy'
        )

# 4. 归档旧页面
api.auto_archive('daivy', days=90)
```

### 场景5: 更新用户画像

```python
api.update_profile('daivy', {
    'preferences': {
        '食物': '甜食',
        '颜色': '蓝色'
    },
    'habits': ['每天早上喝咖啡', '晚上运动'],
    'facts': ['喜欢小动物', '计划年底旅行']
})
```

---

## CLI 命令行工具

```bash
cd /path/to/agent-memory
export MINIMAX_API_KEY=your-api-key
export PYTHONPATH=src

# 获取统计
python3 -m src stats --owner-id daivy

# 搜索记忆
python3 -m src search --query "生日 礼物" --owner-id daivy

# 读取页面
python3 -m src read --page-id <page_id> --layers "1,2,3"

# 处理对话
python3 -m src process --conversation '[{"role":"user","content":"hello"}]' --owner-id daivy
```

### 向量修复工具

```bash
# 诊断向量问题
PYTHONPATH=src python3 -c "
from fix_vectors import diagnose_vectors
diagnose_vectors('daivy')
"

# 修复向量维度
PYTHONPATH=src python3 -c "
from fix_vectors import fix_vectors
fix_vectors('daivy', rebuild=False)  # 不重建
fix_vectors('daivy', rebuild=True)  # 完全重建
"
```

---

## Python API 调用

### 完整调用示例

```python
import sys
import json
sys.path.insert(0, '/path/to/agent-memory/src')

from api import get_memory_api

api = get_memory_api()

# === 1. 存储记忆 ===
conversation = [
    {'role': 'user', 'content': '今天我们约会了'},
    {'role': 'agent', 'content': '去哪里了呀？'},
    {'role': 'user', 'content': '去了一家咖啡店，很浪漫'}
]
result = api.process_conversation(conversation, 'daivy')

# === 2. 搜索记忆 ===
results = api.search_events('咖啡店 约会', max_results=3)

# === 3. 读取详情 ===
if results['results']:
    page_id = results['results'][0]['page_id']
    detail = api.read_page(page_id, layers=[2])

# === 4. 检测相似 ===
similar = api.detect_similar_pages('daivy', threshold=0.8)

# === 5. 合并 ===
for pair in similar['suggestions'][:2]:
    api.merge_pages(
        [pair['l3_page_id_1'], pair['l3_page_id_2']],
        'related',
        '手动合并相似记忆',
        'daivy'
    )

# === 6. 获取统计 ===
stats = api.get_stats('daivy')
```

> API 详细参数和返回格式请查看 [API 参考手册](API.md)

---

## 常见问题与解决

### Q1: merge_pages 报 "FOREIGN KEY constraint failed"

**原因**: `tfidf_index` 表的外键约束指向了错误的表

**解决**:
```python
from memory_core import get_memory_db
db = get_memory_db()
db.fix_tfidf_foreign_key()
```

### Q2: detect_similar_pages 维度不匹配

**原因**: 向量维度不一致

**解决**:
```python
from fix_vectors import fix_vectors
fix_vectors('daivy', rebuild=False)
```

### Q3: LLM 调用超时

**解决**: 检查 API Key 是否正确，等待后重试

### Q4: detect_similar_pages 返回空但实际有相似页面

**解决**:
```python
from memory_core import get_memory_db
db = get_memory_db()
db.build_tfidf_index('daivy')
```

---

## 最佳实践

### 1. 定期整理

建议设置每日定时任务（如 22:30）执行:
1. `get_stats` 查看当前状态
2. `detect_similar_pages` 检测相似
3. `merge_pages` 合并高相似页面 (>0.8)
4. `auto_archive` 归档旧页面 (>90天)

### 2. 对话存储时机

- 重要事件发生时立即存储
- 不要等对话结束才处理
- 使用 `session_id` 追踪同一会话

### 3. 画像更新策略

- 只增不减（保留历史偏好）
- 定期从对话中提取新偏好
- 使用 `evidence` 记录更新来源

### 4. 合并阈值建议

| 相似度 | 建议操作 | merge_type |
|--------|---------|------------|
| >0.85 | 必须合并 | same_event |
| 0.75-0.85 | 建议合并 | same_event |
| 0.65-0.75 | 可选合并 | related |
| <0.65 | 保持独立 | - |

---

## 📚 相关文档

- **[API 参考手册](API.md)** - 所有 API 的详细返回格式
- **[部署运维手册](DEPLOYMENT.md)** - 安装、配置、生产部署
- **[安全手册](SECURITY.md)** - 安全配置、安全检查清单
- **[版本历史](CHANGELOG.md)** - 版本更新记录

---

**文档版本**: v2.3.3 | **更新**: 2026-04-07
