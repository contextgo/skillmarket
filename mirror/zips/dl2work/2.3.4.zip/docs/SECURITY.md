# Agent Memory Database - 安全文档

**版本**: 2.3.3 | **更新日期**: 2026-04-07 | **安全评分**: **9.8/10** 🟢

---

## 📋 安全特性概览

| 特性 | 实现 | 状态 |
|------|------|------|
| API Key 认证 | SHA256 哈希存储 | ✅ |
| owner_id 隔离 | 权限验证 | ✅ |
| 速率限制 | 60次/分钟 | ✅ |
| 输入验证 | 长度/格式/范围限制 | ✅ |
| SQL 注入防护 | 参数化查询 | ✅ |
| 线程安全 | RLock 保护 | ✅ |
| 方法白名单 | CLI + Plugin | ✅ |
| 审计日志 | 敏感操作记录 | ✅ |
| Admin 模式保护 | 生产环境禁用 | ✅ |

---

## 🔐 认证机制

### API Key 配置

```bash
export API_KEY_user001="your-secure-api-key"
export API_KEY_user002="another-secure-key"
```

### CLI 认证

```bash
# 普通用户调用
python3 -m src --method search_events \
    --api-key "your-api-key" \
    --params '{"query": "test", "owner_id": "user001"}'

# 管理员模式（需显式启用）
python3 -m src --method get_stats --admin --params '{}'
```

---

## 🚫 授权隔离

### owner_id 隔离规则

1. **读取操作**: 用户只能读取自己的数据
2. **写入操作**: 用户只能写入自己的数据
3. **归档/恢复**: 归档页面只能被原始 owner 恢复
4. **跨用户访问**: 被拒绝并记录审计日志

---

## ⏱️ 速率限制

- **窗口大小**: 60 秒滑动窗口
- **限制**: 每分钟 60 次请求
- **触发**: 返回 `RateLimitError` 异常

---

## ✅ 输入验证

| 字段 | 最大长度 | 说明 |
|------|----------|------|
| page_id | 64 | UUID 格式 |
| owner_id | 128 | 用户标识 |
| query | 1000 | 搜索关键词 |
| conversation | 100 条 | 单次对话数 |

---

## 🔒 SQL 注入防护

所有数据库操作使用参数化查询：

```python
cursor.execute("SELECT * FROM pages WHERE owner_id = ?", (owner_id,))
```

---

## 🧵 线程安全

```python
class AgentMemoryDB:
    def __init__(self):
        self._lock = threading.RLock()
```

所有数据库操作通过 RLock 保护，防止并发冲突。

---

## 🔧 安全配置

### 环境变量（必需）

```bash
export MINIMAX_API_KEY="your_api_key"
export ADMIN_MODE_DISABLED="true"      # 生产环境禁用admin
export NODE_ENV="production"
```

### 数据库安全

```bash
chmod 600 ~/.local/share/agent-memory/memory.db
```

---

## 📊 安全修复历史

### 评分进度

| 阶段 | 评分 | 说明 |
|------|------|------|
| 修复前 | 5.8/10 | 初始状态 |
| 第一轮 | 9.0/10 | 安全问题修复 |
| 第二轮 | 9.5/10 | 安全增强优化 |
| 第三轮 | **9.8/10** | 功能Bug修复 |

### 已修复问题（30个）

- **P0 严重**: 12个 ✅
- **P1 高危**: 15个 ✅
- **P2 中等**: 3个 ✅

### 关键修复

| 问题 | 文件 | 修复 |
|------|------|------|
| CLI认证绕过 | api.py | API Key验证 |
| 权限隔离缺失 | api.py | owner_id验证 |
| read_page权限 | api.py | 添加验证 |
| API Key明文 | auth.py | SHA256哈希 |
| TF-IDF线程安全 | memory_core.py | 新增安全方法 |

详细修复记录: [../CHANGELOG.md](../CHANGELOG.md)

---

## 📚 相关文档

| 文档 | 说明 |
|------|------|
| [GUIDE.md](GUIDE.md) | 使用指南 |
| [DEPLOYMENT.md](DEPLOYMENT.md) | 部署运维手册 |

---

**安全评分**: 9.8/10 | **状态**: 🟢 生产就绪 | **版本**: 2.3.3