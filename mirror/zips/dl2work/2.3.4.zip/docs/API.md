# Agent Memory API 返回格式参考

> 版本: v2.3.3 | 更新: 2026-04-07

---

## 核心方法返回格式

### 1. memory_process - 处理对话

**成功返回**:
```json
{
  "success": true,
  "processed": {
    "skipped_count": 0,
    "profile_updates": [{"fact": "画像已更新", "profile_id": "xxx"}],
    "new_pages": [{
      "page_id": "xxx",
      "l2_page_id": "yyy",
      "l1_page_id": "zzz",
      "summary": "摘要内容",
      "is_merged": false
    }],
    "merge_candidates": [{"page_id": "aaa", "similarity": 0.75}],
    "merge_recommendation": {
      "new_page_id": "xxx",
      "similar_page_id": "aaa",
      "similarity_score": 0.85,
      "recommendation": "consider_merge"
    }
  }
}
```

---

### 2. memory_search - 搜索记忆

```json
{
  "results": [{
    "page_id": "xxx",
    "full_page_id": "yyy",
    "keywords": {"event_type": [], "who": [], "what": []},
    "time_hint": "2026-04",
    "similarity_score": 0.85
  }],
  "total_candidates": 5,
  "query_keywords": ["关键词1", "关键词2"]
}
```

**字段说明**:
- `similarity_score`: 混合评分 (0.7 * vector + 0.3 * keyword)
- `time_hint`: 绝对时间 YYYY-MM-DD 或 YYYY-MM

---

### 3. memory_read - 读取页面

```json
{
  "page_id": "xxx",
  "content": {
    "layer1": {
      "keywords": {"event_type": [], "who": [], "what": []},
      "time_hint": "2026-04-05",
      "event_date": "2026-04-05"
    },
    "layer2": {
      "summary": "摘要内容",
      "entities": [{"type": "person", "name": "依雁"}],
      "key_facts": ["关键事实"]
    },
    "layer3": {
      "content": "完整对话内容",
      "created_at": "2026-04-05T05:45:19+00:00",
      "status": "active"
    }
  }
}
```

---

### 4. memory_stats - 统计信息

```json
{
  "event_pages": {"active": 150, "merged": 20, "archived": 35},
  "profiles": {"active": 5},
  "merges": {"total": 18},
  "archives": {"total": 35},
  "search_index": {"indexed_pages": 130},
  "date_range": {
    "earliest": "2026-01-15T10:00:00+00:00",
    "latest": "2026-04-05T13:45:00+00:00"
  }
}
```

---

### 5. memory_profile_get - 获取画像

```json
{
  "profile_id": "xxx",
  "owner_id": "daivy",
  "content": {
    "preferences": {"response_style": "简洁"},
    "habits": ["每晚学习"],
    "background": {"职业": "工程师"}
  },
  "version": 5,
  "updated_at": "2026-04-05T10:00:00+00:00"
}
```

---

### 6. memory_merge - 合并页面

```json
{
  "success": true,
  "new_page_id": "xxx",
  "l2_page_id": "yyy",
  "l1_page_id": "zzz",
  "source_pages": ["aaa", "bbb"],
  "merge_type": "related",
  "summary": "合并后的新摘要"
}
```

---

### 7. memory_detect_similar - 检测相似页面

```json
{
  "suggestions": [{
    "page_id_1": "xxx",
    "page_id_2": "yyy",
    "l3_page_id_1": "zzz",
    "l3_page_id_2": "www",
    "similarity": 0.85,
    "suggested_merge_type": "same_event"
  }],
  "total_pairs_checked": 45,
  "threshold": 0.7
}
```

**字段说明**:
- `page_id_1` / `page_id_2`: L2 层页面 ID（用于 tfidf_index 索引）
- `l3_page_id_1` / `l3_page_id_2`: L3 层页面 ID（用于 memory_merge 等操作）
- `similarity`: TF-IDF 向量余弦相似度 (0.0-1.0)

**阈值建议**: `>0.8` 合并(same_event) | `0.7-0.8` 可考虑(related) | `<0.7` 独立

---

### 8. memory_fix_tfidf - 修复 TF-IDF 外键约束

```json
{
  "success": true,
  "message": "tfidf_index 外键约束已修复"
}
```

**说明**: 修复 `tfidf_index` 表外键指向错误表（l1_pages → l2_pages）的问题。此问题会导致 rebuild 等操作失败。建议在首次使用 detect_similar 或 rebuild 功能前调用一次。

---

### 9. 归档相关方法

**memory_archive**:
```json
{"success": true, "archive_id": "aaa", "page_id": "xxx", "archived_at": "2026-04-05T10:00:00+00:00"}
```

**memory_restore**:
```json
{"success": true, "page_id": "xxx", "restored_at": "2026-04-05T10:00:00+00:00"}
```

**memory_archived_list**:
```json
{
  "success": true,
  "archives": [{"archive_id": "aaa", "page_id": "xxx", "archived_at": "2026-04-05"}],
  "count": 5
}
```

**memory_auto_archive**:
```json
{"success": true, "archived_count": 10, "cutoff_date": "2025-09-01"}
```

**memory_archive_config**:
```json
{
  "success": true,
  "config": {
    "retention_days": 180,
    "auto_archive_enabled": 0,
    "archive_threshold_score": 0.1
  }
}
```

---

## 错误返回格式

### 认证错误
```json
{"success": false, "error": "AuthenticationError: 缺少认证信息"}
```

### 权限错误
```json
{"success": false, "error": "AuthorizationError: 无权访问该资源"}
```

### 速率限制
```json
{"success": false, "error": "RateLimitError: 请求过于频繁", "details": {"retry_after": 60}}
```

### 验证错误
```json
{"success": false, "error": "ValidationError: conversation 不能为空列表"}
```

---

## 重要说明

**时间格式**: ISO 8601 带时区 (`2026-04-05T05:45:19+00:00`)

**ID 格式**: UUID v4 (`550e8400-e29b-41d4-a716-446655440000`)

**页面层级 ID 说明**:
- **L1 ID**: 关键词层 ID，存储于 `l1_pages.page_id`
- **L2 ID**: 摘要层 ID，存储于 `l2_pages.page_id`，同时作为 `tfidf_index.page_id`
- **L3 ID**: 完整内容层 ID，存储于 `l3_pages.page_id`，对应 `l2_pages.full_page_id`

**ID 关系**: `l1_pages.full_page_id` → `l2_pages.page_id` → `l3_pages.page_id`

**API 兼容性**: `memory_merge` 和 `memory_detect_similar` 现在同时支持 L2 ID 和 L3 ID 作为输入。

**相似度分数**: 0.0-1.0 (`>0.8` 高, `0.6-0.8` 中, `<0.6` 低)

**页面状态**: `active` | `merged` | `archived` | `deleted`

**归档原因**: `manual` | `auto_archive` | `threshold_exceeded`

---

**文档版本**: v2.3.3 | **更新**: 2026-04-07