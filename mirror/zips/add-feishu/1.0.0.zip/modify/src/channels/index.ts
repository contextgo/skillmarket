// Channel self-registration barrel file.
// Each import triggers the channel module's registerChannel() call.

// discord

// feishu
import './feishu.js';

// gmail

// slack

// telegram
import './telegram.js';

// whatsapp
