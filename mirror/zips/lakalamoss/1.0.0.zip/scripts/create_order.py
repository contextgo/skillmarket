#!/usr/bin/env python3
"""
拉卡拉MOSS支付下单脚本
演示如何调用MOSS接口发起支付订单并获取支付链接
支持RSA SHA256签名验签
"""

import argparse
import json
import uuid
import sys
import base64
import requests

from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import SHA256


# ==================== 密钥配置 ====================

# 商户私钥（用于请求签名）
MERCHANT_PRIVATE_KEY = """-----BEGIN RSA PRIVATE KEY-----
MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBALDGhBHDzhpWuc7
IbQik7tAaOqeMux3K/QCewCL5jvnNu5BdGepIVDzRTrbVtDMgClbTcn/QgeyNM+
k9jWI+tz/rWvBj0u+nWFMePlBkqBd+lTuuyHYIAXXd8xD81kwbhw3qQKSwC4tk0
xnXU4ZLBle1fpYBaxVVrKwaM0De+6KDAgMBAAECgYACMLN6NN7c3K44rasMLF75
HRoU8V1wJQ+1bkIbLNRkq/Pi+gRULsk8Z6t+AG/XIlJ+eOg2RTMW5zj5btXNndFP
aCd6g2K+wXOo7mhfyB9t4NefNoo+wpYXovUoIQu5LSlBa3kP0KLhEfM6Iz9DTUXW
9fUPmPg50mZjC/7EngIVwQJBAOD9zPZFzIRskCLewm8MAN+3XbulQwoj1pdSUhY0
dhd6gFktN2S5FLV5rZeHLSAVpjNTkb2oKJkiWZIzgWoEQIkCQQDJI4x0uJmdvt9V
wn1onfrKiBiKAgBJQxG0F5NUZJp3TVDOFixxkPrWWWUp6xJgzpILnovSUc7nWfHw
GMbHWI+rAkAXOXunzEqxPLegMdhmOBn6/eWaEhQaftqO4juA+UdbYxTOn8FBD23Y
0ceehaCd2D5AvBamOi5+qDIQympIdEnpAkBGDINWAxQ8w8Sz8VALpzk4X71sEtZW
rWz082Dz+zVwZxTFMSO5SWySSf/ZYWy9GjPyp/y5+pO8Lq77lyVjN4yRAkB+qXE
JcaC0yTf5HGtsXwShC/wfQX2DqO27uzKfreZZMPt8I0RNoEn1g1qxIMcgTtxSm6W
8+m9wHXQNtJwuQbO+
-----END RSA PRIVATE KEY-----"""

# 拉卡拉公钥（用于响应验签）
LAKALA_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQD3E6H3qfgqF7aKypmSuzMIRuL
/pRFMzsyqMlSEzzo2aJqN7w8Lb2tfVRfnAUVKMFyDxUzNWER4E/UfR4ymo0YHOai
IJI3AHWdJngJyGgK+SfvYDs9rqC++yisrzYv/TN3fZ93Ru1YWOYi4x4lBSCC9UX2
b28hwx32MpJHT7gIrMQIDAQAB
-----END PUBLIC KEY-----"""


# ==================== 签名工具函数 ====================

def generate_service_sn():
    """生成服务流水号"""
    return str(uuid.uuid4()).replace('-', '')


def sign_data(data_str, private_key_str):
    """
    使用商户私钥对数据进行RSA SHA256签名（PKCS1v15）

    Args:
        data_str: 待签名的原始字符串
        private_key_str: PEM格式的私钥字符串

    Returns:
        str: Base64编码的签名字符串
    """
    private_key = RSA.import_key(private_key_str)
    signer = PKCS1_v1_5.new(private_key)
    hash_obj = SHA256.new(data_str.encode('utf-8'))
    signature = signer.sign(hash_obj)
    return base64.b64encode(signature).decode('utf-8')


def verify_sign(data_str, signature_b64, public_key_str):
    """
    使用拉卡拉公钥对数据进行RSA SHA256验签（PKCS1v15）

    Args:
        data_str: 原始数据字符串
        signature_b64: Base64编码的签名字符串
        public_key_str: PEM格式的公钥字符串

    Returns:
        bool: 验签是否通过
    """
    try:
        public_key = RSA.import_key(public_key_str)
        verifier = PKCS1_v1_5.new(public_key)
        hash_obj = SHA256.new(data_str.encode('utf-8'))
        signature = base64.b64decode(signature_b64)
        return verifier.verify(hash_obj, signature)
    except (ValueError, TypeError):
        return False


def build_sign_string(request_body):
    """
    构造待签名的数据字符串
    按照MOSS规范：对request部分进行JSON序列化（排序key）作为待签名数据

    Args:
        request_body: 完整的请求报文字典

    Returns:
        str: 待签名字符串
    """
    request_part = request_body.get("request", {})
    # 按key升序排列，生成不含空格的紧凑JSON字符串
    sign_str = json.dumps(request_part, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
    return sign_str


# ==================== 核心业务函数 ====================

def create_order(order_no, total_amount, subject="订单标题测试",
                 remark="交易备注信息测试", callback_url="lakala.com"):
    """
    发起支付下单请求（含签名验签）

    Args:
        order_no: 商户订单号（唯一）
        total_amount: 支付金额（单位：分，字符串形式）
        subject: 订单标题
        remark: 交易备注
        callback_url: 支付结果回调地址

    Returns:
        dict: 包含支付链接或错误信息的响应数据
    """

    # API地址
    url = "https://moss.lakala.com/ord-api/unified/v3"

    # 构造请求报文
    request_data = {
        "head": {
            "versionId": "1.0",
            "serviceId": "lfops.moss.order.pay",
            "serviceSn": generate_service_sn(),
            "systemCode": "MOSS",
            "channelId": "API",
            "businessChannel": "C00000146"
        },
        "request": {
            "order_no": order_no,
            "total_amount": str(total_amount),
            "mer_no": "M00000333",
            "pay_scene": "0",
            "account_type": "ALIPAY,WECHAT,UQRCODEPAY",
            "order_eff_time": "30",
            "subject": subject,
            "remark": remark,
            "callback_url": callback_url
        }
    }

    # 发起POST请求
    try:
        # ===== 第一步：对请求报文进行签名 =====
        sign_str = build_sign_string(request_data)
        signature = sign_data(sign_str, MERCHANT_PRIVATE_KEY)
        # 将签名值放入head.sign字段
        request_data["head"]["sign"] = signature

        headers = {
            "Content-Type": "application/json"
        }

        response = requests.post(
            url,
            json=request_data,
            headers=headers,
            timeout=30
        )

        # 检查HTTP状态码
        if response.status_code >= 400:
            return {
                "success": False,
                "error": f"HTTP请求失败: 状态码 {response.status_code}",
                "response": response.text
            }

        # 解析响应
        response_data = response.json()

        # ===== 第二步：对响应报文进行验签 =====
        head = response_data.get("head", {})
        resp_sign = head.get("sign", "")

        if resp_sign:
            # 响应验签：对完整的响应JSON字符串进行验签
            # 移除sign字段后，按原始顺序重新序列化进行验签
            verify_data = json.dumps(response_data, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
            if not verify_sign(verify_data, resp_sign, LAKALA_PUBLIC_KEY):
                return {
                    "success": False,
                    "error": "响应验签失败！响应数据可能被篡改",
                    "full_response": response_data
                }
        else:
            # 如果响应中没有签名字段，记录警告但继续处理（兼容性考虑）
            pass

        # 检查业务状态 - 使用实际API返回的code/desc字段
        # 优先检查code字段，如果不存在则检查respCode字段（向后兼容）
        resp_code = head.get("code") or head.get("respCode")
        resp_msg = head.get("desc") or head.get("respMsg")

        if resp_code != "000000":
            return {
                "success": False,
                "error": f"业务请求失败: {resp_msg}",
                "code": resp_code,
                "desc": resp_msg,
                "full_response": response_data
            }

        # 提取支付链接 - 从response.counter_url获取支付链接
        result = response_data.get("response", {})
        pay_url = result.get("counter_url")

        if not pay_url:
            return {
                "success": False,
                "error": "响应中未包含支付链接",
                "full_response": response_data
            }

        # 提取其他有用信息
        service_sn = head.get("serviceSn")
        service_time = head.get("serviceTime")

        return {
            "success": True,
            "pay_url": pay_url,
            "order_no": order_no,
            "total_amount": total_amount,
            "service_sn": service_sn,
            "service_time": service_time,
            "full_response": response_data
        }

    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "error": f"网络请求异常: {str(e)}"
        }
    except json.JSONDecodeError as e:
        return {
            "success": False,
            "error": f"JSON解析失败: {str(e)}"
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"未知错误: {str(e)}"
        }


# ==================== 命令行入口 ====================

def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(
        description="拉卡拉MOSS支付下单脚本（支持RSA签名验签）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  基础支付订单:
    python create_order.py --order-no "TEST001" --total-amount "1"

  完整支付订单:
    python create_order.py --order-no "TEST001" --total-amount "100" \\
      --subject "测试商品" --remark "演示订单" --callback-url "https://example.com/callback"
        """
    )

    parser.add_argument(
        "--order-no",
        required=True,
        help="商户订单号（必须唯一）"
    )
    parser.add_argument(
        "--total-amount",
        required=True,
        help="支付金额（字符串形式，单位：分，例如'1'表示1分）"
    )
    parser.add_argument(
        "--subject",
        default="订单标题测试",
        help="订单标题（默认：订单标题测试）"
    )
    parser.add_argument(
        "--remark",
        default="交易备注信息测试",
        help="交易备注（默认：交易备注信息测试）"
    )
    parser.add_argument(
        "--callback-url",
        default="lakala.com",
        help="支付结果回调地址（默认：lakala.com）"
    )

    args = parser.parse_args()

    # 验证参数
    if not args.order_no:
        print("错误：订单号不能为空", file=sys.stderr)
        sys.exit(1)

    # 金额验证：必须是字符串且为正数
    if not args.total_amount:
        print("错误：金额不能为空", file=sys.stderr)
        sys.exit(1)

    try:
        # 金额为字符串形式，检查是否为有效数字
        amount_int = int(args.total_amount)
        if amount_int <= 0:
            print("错误：金额必须大于0", file=sys.stderr)
            sys.exit(1)
    except ValueError:
        print("错误：金额必须是数字字符串", file=sys.stderr)
        sys.exit(1)

    # 调用下单接口
    print(f"正在发起支付下单...")
    print(f"订单号: {args.order_no}")
    print(f"金额: {args.total_amount} 分")
    print(f"签名状态: 已启用RSA SHA256签名")
    print("-" * 50)

    result = create_order(
        order_no=args.order_no,
        total_amount=args.total_amount,
        subject=args.subject,
        remark=args.remark,
        callback_url=args.callback_url
    )

    # 输出结果
    if result["success"]:
        print("✓ 下单成功！")
        print(f"订单号: {result['order_no']}")
        print(f"支付金额: {result['total_amount']} 分")
        if result.get("service_sn"):
            print(f"服务流水号: {result['service_sn']}")
        if result.get("service_time"):
            print(f"服务时间: {result['service_time']}")
        print(f"\n支付链接: {result['pay_url']}")
        print(f"\n请点击上方链接完成支付")
    else:
        print("✗ 下单失败！")
        print(f"错误信息: {result['error']}")
        if "code" in result:
            print(f"响应码: {result['code']}")
            print(f"响应消息: {result['desc']}")
        sys.exit(1)


if __name__ == "__main__":
    main()
