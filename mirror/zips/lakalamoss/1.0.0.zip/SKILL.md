---
name: lakala-moss
description: 拉卡拉MOSS支付下单；当用户需要发起支付订单、生成支付链接或测试拉卡拉MOSS接口时使用
dependency:
  python:
    - requests>=2.28.0
    - pycryptodome>=3.19.0
---

# 拉卡拉MOSS支付下单

## 任务目标
- 本Skill用于：通过拉卡拉MOSS接口发起支付下单请求，获取支付链接
- 能力包含：构造支付报文、RSA SHA256签名、调用MOSS API、响应验签、提取支付链接
- 触发条件：用户需要发起支付订单、测试支付接口或生成支付链接时

## 前置准备
- 依赖说明：
  ```
  requests>=2.28.0
  pycryptodome>=3.19.0   # 用于RSA签名验签
  ```
- 密钥配置：脚本中已内置商户私钥和拉卡拉公钥（生产环境需替换为真实密钥）

## 操作步骤

### 标准流程

1. **第一步：接收用户输入的订单参数**
   - 调用 `scripts/create_order.py` 脚本
   - 必需参数：订单号（--order-no）、金额（--total-amount，字符串形式，单位：分）
   - 可选参数：主题（--subject）、备注（--remark）、回调地址（--callback-url）

2. **第二步：构造符合MOSS规范的请求报文**
   - 脚本自动生成服务流水号（serviceSn）
   - 构造包含head和request的完整请求报文
   - 设置默认商户号、支付方式等参数

3. **第三步：对请求报文进行RSA SHA256签名**
   - 使用商户私钥对request部分进行SHA256WithRSA签名（PKCS1v15）
   - 签名结果Base64编码后放入head.sign字段
   - 签名算法：对request JSON按key排序后序列化，再进行RSA签名

4. **第四步：调用MOSS API发起支付请求**
   - 发送POST请求到 `https://moss.lakala.com/ord-api/unified/v3`
   - 设置正确的Content-Type和超时时间
   - 获取API响应数据

5. **第五步：对响应报文进行RSA SHA256验签**
   - 使用拉卡拉公钥验证响应数据的签名（head.sign字段）
   - 验签失败则拒绝响应，防止数据被篡改

6. **第六步：解析API响应，提取支付链接**
   - 解析响应JSON数据
   - 检查业务状态码（code字段，000000表示成功）
   - 从response.counter_url提取支付链接
   - 提取服务流水号和服务时间等附加信息

7. **第七步：返回支付结果**
   - 返回包含支付链接的完整订单信息
   - 用户点击链接即可完成支付

### 参数说明

| 参数 | 必需 | 说明 | 示例 |
|------|------|------|------|
| --order-no | 是 | 商户订单号（必须唯一） | TEST001、202401010001 |
| --total-amount | 是 | 支付金额（字符串形式，单位：分） | "1"表示1分、"100"表示1元 |
| --subject | 否 | 订单标题 | 测试商品 |
| --remark | 否 | 交易备注 | 演示订单 |
| --callback-url | 否 | 支付结果回调地址 | https://example.com/callback |

### API响应格式

**成功响应示例：**
```json
{
  "head": {
    "code": "000000",
    "desc": "成功",
    "serviceSn": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    "serviceTime": "20260413145512",
    "sign": "Base64编码的RSA签名值..."
  },
  "response": {
    "order_no": "TEST001",
    "counter_url": "https://moss.lakala.com/counter/#/r/0000?business_channel=xxx&order_no=TEST001"
  }
}
```

**失败响应示例：**
```json
{
  "head": {
    "code": "E10001",
    "desc": "订单号重复"
  }
}
```

## 资源索引
- 必要脚本：见 [scripts/create_order.py](scripts/create_order.py)（用途：发起支付下单请求，获取支付链接和订单信息）
- 领域参考：见 [references/moss-api-guide.md](references/moss-api-guide.md)（何时读取：需要了解API详细说明、参数格式、错误码时）

## 注意事项

### 当前配置信息
- **商户号**：M00000333
- **业务渠道编码**：C00000146
- **签名算法**：RSA SHA256（SHA256WithRSA / PKCS1v15）
- **签名状态**：✅ 已启用签名验签功能

### 密钥安全（重要）
- **商户私钥**：已内置在脚本中（`MERCHANT_PRIVATE_KEY`），用于请求签名
- **拉卡拉公钥**：已内置在脚本中（`LAKALA_PUBLIC_KEY`），用于响应验签
- ⚠️ **生产环境建议**：将密钥存储在安全的位置（如环境变量、密钥管理服务），避免明文硬编码

### 生产环境部署要求
- **商户配置**：确保使用真实的商户号和业务渠道编码
- **密钥替换**：将脚本中的测试密钥替换为真实的商户私钥和拉卡拉公钥
- **接口安全**：所有请求必须通过HTTPS加密传输
- **回调地址**：确保支付结果回调地址可公网访问且具备安全验证机制
- **日志审计**：记录所有交易请求和响应，便于问题排查和安全审计
- **金额校验**：在客户端和服务器端双重校验订单金额，防止篡改

### 通用注意事项
- 订单号必须唯一，重复订单号会导致失败
- 金额必须以字符串形式传入，单位为分（例如："1"表示1分）
- 支付方式默认支持支付宝、微信、银联二维码
- 订单有效时间为30分钟，超时后支付链接失效
- 响应解析遵循MOSS API标准格式，从response.counter_url提取支付链接

## 使用示例

### 示例1：发起1元支付订单（最常用）
```bash
python scripts/create_order.py \
  --order-no "TEST001" \
  --total-amount "100"
```

### 示例2：发起1分支付订单（最小测试金额）
```bash
python scripts/create_order.py \
  --order-no "TEST002" \
  --total-amount "1"
```

### 示例3：带完整参数的支付订单
```bash
python scripts/create_order.py \
  --order-no "202401010001" \
  --total-amount "100" \
  --subject "测试商品" \
  --remark "演示订单" \
  --callback-url "https://example.com/pay/callback"
```

### 预期输出（成功）
```
正在发起支付下单...
订单号: TEST001
金额: 100 分
签名状态: 已启用RSA SHA256签名
--------------------------------------------------
✓ 下单成功！
订单号: TEST001
支付金额: 100 分
服务流水号: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
服务时间: 20260413145512

支付链接: https://moss.lakala.com/counter/#/r/0000?business_channel=xxx&order_no=TEST001

请点击上方链接完成支付
```

## 标准化工作流程
1. **第一步：构造请求** - 根据用户输入的订单号和金额构造支付请求
2. **第二步：请求签名** - 使用商户私钥对请求报文进行RSA SHA256签名
3. **第三步：调用API** - 调用拉卡拉MOSS API发起支付下单
4. **第四步：响应验签** - 使用拉卡拉公钥验证响应数据完整性
5. **第五步：解析响应** - 解析API响应，从response.counter_url提取支付链接
6. **第六步：返回信息** - 返回包含支付链接、订单号、服务流水号等完整订单信息
