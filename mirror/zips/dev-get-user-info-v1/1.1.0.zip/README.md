# 用户信息查询 Skill

[![Version](https://img.shields.io/badge/version-1.1.0-blue.svg)](./SKILL.md)
[![Python](https://img.shields.io/badge/python-3.6+-green.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-yellow.svg)](./LICENSE)

通过 REST API 查询企业内部用户信息，支持 userId、username、mobile 三种查询方式。

## ✨ 特性

- 🔍 **多维度查询** - 支持 userId、username、mobile 三种方式
- 💬 **纯对话交互** - AI 直接在对话中收集配置，**无需本地配置文件**
- 🔧 **多种配置方式** - 支持命令行参数、环境变量、本地文件（按需选择）
- 📝 **友好输出** - 格式化展示用户信息，同时保留原始 JSON

## 📦 安装

### 方式一：项目级安装（推荐）

```bash
# 解压到项目目录
cd your-project
unzip get-user-info.zip -d .workbuddy/skills/
```

### 方式二：用户级安装

```bash
# 解压到用户目录
unzip get-user-info.zip -d ~/.workbuddy/skills/
```

### 依赖安装

```bash
pip install requests
```

## 🚀 快速开始

### 方式一：无文件模式（推荐，AI 直接使用）

直接在命令行传入配置参数，**无需任何本地文件**：

```bash
# 通过 username 查询
python scripts/get_user_info.py name stu_013 \
  --host uh.51tyty.com \
  --token xxx \
  --apptype 6 \
  --devicetype 0

# 通过 userId 查询
python scripts/get_user_info.py id 19857 \
  --host uh.51tyty.com \
  --token xxx

# 通过 mobile 查询
python scripts/get_user_info.py mobile 13800138000 \
  --host uh.51tyty.com \
  --token xxx
```

### 方式二：环境变量配置

```bash
# 设置环境变量（Windows PowerShell）
$env:USER_API_HOST="uh.51tyty.com"
$env:USER_API_TOKEN="xxx"
$env:USER_API_APPTYPE="6"
$env:USER_API_DEVICETYPE="0"

# 然后直接查询
python scripts/get_user_info.py name stu_013
```

### 方式三：本地配置文件（传统方式）

如需使用本地配置文件：

```bash
# 创建/更新配置文件
python scripts/get_user_info.py config

# 按提示输入 Headers（每行一个 key: value 格式）
host: uh.51tyty.com
apptype: 6
devicetype: 0
token: xxx
content-type: application/json

# 配置将保存到 ~/.workbuddy/skills/get-user-info/config.json

# 后续查询无需再传参数
python scripts/get_user_info.py id 19857
```

## 📖 使用示例

### 示例 1：首次配置

```bash
$ python scripts/get_user_info.py id 19857

首次使用，需要进行配置。

==================================================
  用户信息查询 Skill - 首次配置
==================================================

请提供 API 请求 Headers（每行一个，格式: key: value）
必须包含 host 字段，例如: host: api.example.com
输入空行结束

   Header (key: value): host: uh.51tyty.com
   Header (key: value): apptype: 6
   Header (key: value): devicetype: 0
   Header (key: value): token: 48:1838193998:xxx
   Header (key: value):

配置已保存到: ~/.workbuddy/skills/get-user-info/config.json

配置完成！提取到 API Domain: uh.51tyty.com
现在可以使用以下命令查询用户信息：
  python get_user_info.py id <userId>
  python get_user_info.py name <username>
  python get_user_info.py mobile <mobile>
```

### 示例 2：查询用户

```bash
$ python scripts/get_user_info.py id 19857

使用配置: domain=uh.51tyty.com

正在通过 userId 查询: 19857 ...
==================================================
  用户信息查询结果
==================================================
  用户 ID     : 19857
  用户名      : stu_013
  昵称        : 13
  性别        : 男
  手机号      : 未填写
  角色        : groupMember
  机构 ID     : 170573
  校区        : 唐 (主校区)
  账号状态    : 有效 / 未过期
  激活时间    : 2020-04-01 21:57:59
  有效期      : 2020-04-01 ~ 2099-01-01
  积分 (总/可用/已用): 0 / 0 / 0
  头像 URL    : 未设置
==================================================

[原始 JSON 响应]
{
  "code": "0",
  "message": "Success",
  "user": { ... }
}
```

### 示例 3：在 WorkBuddy / CodeBuddy 中使用（纯对话模式）

**这是 v1.1.0 推荐的方式** —— AI 直接在对话中收集配置，无需本地文件：

```
@skill://get-user-info 查询用户名 stu_013 的信息
```

AI 会这样处理：
1. 询问查询方式（id/name/mobile）和查询值
2. 直接在对话中询问 API 配置（host、token 等）
3. 将配置作为参数传入脚本执行
4. 返回格式化结果

**整个过程不生成任何本地配置文件**，配置信息仅在当次对话中有效。

### 示例 4：在 WorkBuddy 中使用（传统方式）

如果已配置本地文件：

```
@skill://get-user-info 查询用户 ID 为 19857 的信息
```

## ⚙️ 配置说明

### 配置文件位置

```
~/.workbuddy/skills/get-user-info/config.json
```

### 配置文件格式

```json
{
  "host": "uh.51tyty.com",
  "apptype": "6",
  "devicetype": "0",
  "token": "48:1838193998:xxx",
  "Content-Type": "application/json"
}
```

### 配置项说明

| 配置项 | 必填 | 说明 |
|--------|------|------|
| `host` | **是** | API 域名，用于构建请求 URL |
| 其他 headers | 否 | 根据你的 API 认证要求填写 |

**注意**：`host` 字段是必须的，脚本会自动从中提取 API Domain。

## 📚 API 文档

详见 [references/api_doc.md](./references/api_doc.md)

### 接口列表

| 查询方式 | 接口地址 |
|----------|----------|
| userId | `http://{host}/user/services/rest/user/{userId}` |
| username/mobile | `http://{host}/user/services/rest/user/Name/{name}` |

### 响应字段

| 字段 | 说明 |
|------|------|
| `userId` | 用户 ID |
| `username` | 登录用户名 |
| `nickname` | 用户昵称 |
| `gender` | 性别：`"0"` = 男，`"1"` = 女 |
| `mobile` | 手机号 |
| `role` | 角色 |
| `isvalidate` | 是否有效：`"true"` / `"false"` |
| `expiredStatus` | 过期状态：`"0"` = 未过期 |
| `campusTitle` | 校区名称 |
| `total/available/consuming` | 积分信息 |

完整字段列表请参考 API 文档。

## 🔧 故障排除

### 问题：提示"Headers 中未找到 'host' 字段"

**解决**：重新配置并确保包含 host 字段：
```bash
python scripts/get_user_info.py config
# 输入: host: api.example.com
```

### 问题：提示"配置错误: 配置文件不存在"

**解决**：运行任意查询命令，按提示完成首次配置。

### 问题：提示"错误: 无法连接到服务器"

**解决**：
1. 检查网络连接
2. 确认 host 配置正确：`python scripts/get_user_info.py config`
3. 确认 API 服务正常运行

### 问题：提示"API 返回错误"

**解决**：
1. 检查 headers 中的认证信息是否过期
2. 确认用户 ID / 用户名 / 手机号存在
3. 查看完整的错误信息，联系 API 提供方

## 📄 文件结构

```
get-user-info/
├── SKILL.md                 # Skill 元数据和核心说明
├── README.md                # 本文件
├── manifest.json            # SkillHub 上传元数据
├── assets/
│   └── icon.svg             # Skill 图标
├── scripts/
│   └── get_user_info.py     # 主脚本
└── references/
    └── api_doc.md           # API 文档
```

## 🤝 贡献

欢迎提交 Issue 和 PR！

## 📜 许可证

MIT License

## 🙏 致谢

- 基于 WorkBuddy Skill 框架开发
- 使用 Python requests 库进行 HTTP 请求
