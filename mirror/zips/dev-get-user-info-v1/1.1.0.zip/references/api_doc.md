# 用户信息查询 API 文档

## 配置说明

本 Skill 采用**交互式配置**，首次使用时会自动引导用户输入 API 信息。

### 配置存储位置

```
~/.workbuddy/skills/get-user-info/config.json
```

### 配置内容

```json
{
  "domain": "api.example.com",
  "headers": {
    "Content-Type": "application/json",
    "Authorization": "Bearer xxx",
    ...
  }
}
```

### 配置方式

**首次使用自动配置**：
```bash
python scripts/get_user_info.py id 19857
# 提示输入 domain 和 headers
```

**手动重新配置**：
```bash
python scripts/get_user_info.py config
```

---

## 接口信息

### 接口 1：通过 userId 查询

| 项目 | 内容 |
|------|------|
| **接口地址** | `http://{domain}/user/services/rest/user/{userId}` |
| **请求方法** | GET |
| **认证方式** | 用户配置的 Headers |

#### 路径参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `userId` | string | 是 | 用户唯一 ID |

---

### 接口 2：通过 username 或 mobile 查询

| 项目 | 内容 |
|------|------|
| **接口地址** | `http://{domain}/user/services/rest/user/Name/{name}` |
| **请求方法** | GET |
| **认证方式** | 用户配置的 Headers |

#### 路径参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `name` | string | 是 | 用户名或手机号 |

---

## 响应结构

### 外层字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | string | 响应码，`"0"` 表示成功 |
| `message` | string | 响应描述，成功时为 `"Success"` |
| `user` | object | 用户详情对象（见下方） |
| `startPos` | string | 分页起始位置 |
| `count` | string | 当前返回数量 |
| `total` | string | 总记录数 |
| `unactivated` | string | 未激活用户数 |
| `activated` | string | 已激活用户数 |
| `searchCounts` | string | 搜索结果总数 |

### user 对象字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `userId` | string | 用户 ID |
| `serverId` | string | 服务器 ID |
| `nickname` | string | 用户昵称 |
| `username` | string | 登录用户名 |
| `nicknameNote` | string | 昵称备注 |
| `photourl` | string | 头像 URL |
| `instId` | string | 机构 ID |
| `role` | string | 角色（如 `groupMember`） |
| `mobile` | string | 手机号 |
| `txImUserId` | string | 腾讯 IM 用户 ID |
| `gender` | string | 性别：`"0"` = 男，`"1"` = 女 |
| `lastAccessTime` | string | 最后访问时间（Unix 时间戳） |
| `hxUsername` | string | 环信用户名 |
| `isvalidate` | string | 是否有效（`"true"` / `"false"`） |
| `activeDate` | string | 激活时间（格式：`yyyy-MM-dd HH:mm:ss`） |
| `startDate` | string | 有效期开始（格式：`yyyy-MM-dd`） |
| `endDate` | string | 有效期结束（格式：`yyyy-MM-dd`） |
| `awarded` | string | 获奖次数 |
| `headUserId` | string | 班主任/负责人用户 ID |
| `wyAccid` | string | 网易云信账号 ID |
| `instCode` | string | 机构代码 |
| `roleId` | string | 角色 ID |
| `age` | string | 年龄 |
| `expiredStatus` | string | 过期状态（`"0"` = 未过期） |
| `campusId` | string | 校区 ID |
| `campusTitle` | string | 校区名称 |
| `campusShortTitle` | string | 校区简称 |
| `campusType` | string | 校区类型（如 `main_campus` = 主校区） |
| `total` | string | 总积分 |
| `available` | string | 可用积分 |
| `consuming` | string | 已消耗积分 |

---

## 成功响应示例

```json
{
    "code": "0",
    "message": "Success",
    "user": {
        "userId": "19857",
        "serverId": "0",
        "nickname": "13",
        "username": "stu_013",
        "nicknameNote": "13",
        "photourl": "",
        "instId": "170573",
        "role": "groupMember",
        "mobile": "",
        "txImUserId": "1301_19857",
        "gender": "0",
        "lastAccessTime": "0",
        "hxUsername": "y_19857",
        "isvalidate": "true",
        "activeDate": "2020-04-01 21:57:59",
        "startDate": "2020-04-01",
        "endDate": "2099-01-01",
        "awarded": "0",
        "headUserId": "19427",
        "wyAccid": "y_19857",
        "instCode": "",
        "roleId": "0",
        "age": "0",
        "expiredStatus": "0",
        "campusId": "2326",
        "campusTitle": "唐",
        "campusShortTitle": "",
        "campusType": "main_campus",
        "total": "0",
        "available": "0",
        "consuming": "0"
    },
    "startPos": "10",
    "count": "8",
    "total": "18",
    "unactivated": "0",
    "activated": "18",
    "searchCounts": "18"
}
```

## 错误响应

当 `code` 不为 `"0"` 时，表示请求失败，需检查 `message` 字段获取错误原因。
