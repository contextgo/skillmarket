#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
get_user_info.py
通过 userId、username 或 mobile 查询用户信息

配置来源（优先级从高到低）：
  1. 命令行参数  --host / --token / --apptype / --devicetype（无文件模式，适合 AI 直接调用）
  2. 环境变量    USER_API_HOST / USER_API_TOKEN / USER_API_APPTYPE / USER_API_DEVICETYPE
  3. 本地配置文件  ~/.codebuddy/skills/dev-get-user-info-v1/config.json
                  ~/.workbuddy/skills/get-user-info/config.json
  4. 交互式输入  （命令行手动使用时的兜底方案）

用法:
  # ── 无文件模式（AI 直接调用，推荐）──────────────────────────────
  python get_user_info.py name studentuhqqt --host uh.51tyty.com --token xxx
  python get_user_info.py id 19857 --host uh.51tyty.com --token xxx --apptype 6
  python get_user_info.py mobile 13800138000 --host uh.51tyty.com --token xxx

  # ── 使用本地配置文件 ─────────────────────────────────────────────
  python get_user_info.py name stu_013
  python get_user_info.py id 19857

  # ── 初始化/更新配置文件 ──────────────────────────────────────────
  python get_user_info.py config

  # ── 查看当前配置（不执行查询）────────────────────────────────────
  python get_user_info.py show-config

依赖:
  pip install requests
"""

import sys
import json
import os
import argparse
from pathlib import Path

# ── Windows 控制台编码修复 ────────────────────────────────────────
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

import requests

# ── 配置文件候选路径（按优先级） ──────────────────────────────────
_CONFIG_PATHS = [
    Path.home() / ".codebuddy" / "skills" / "dev-get-user-info-v1" / "config.json",
    Path.home() / ".workbuddy" / "skills" / "get-user-info" / "config.json",
]
DEFAULT_CONFIG_FILE = _CONFIG_PATHS[0]

# ── 字段映射 ──────────────────────────────────────────────────────
GENDER_MAP = {"0": "男", "1": "女"}
CAMPUS_TYPE_MAP = {"main_campus": "主校区"}


# ═════════════════════════════════════════════════════════════════
# 配置加载
# ═════════════════════════════════════════════════════════════════

def load_config_from_file() -> dict | None:
    """从本地配置文件加载，返回 None 表示不存在。"""
    for path in _CONFIG_PATHS:
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"⚠ 读取配置文件失败 ({path}): {e}", file=sys.stderr)
    return None


def load_config_from_env() -> dict | None:
    """从环境变量加载，返回 None 表示未配置。"""
    host = os.environ.get("USER_API_HOST")
    token = os.environ.get("USER_API_TOKEN")
    if not (host and token):
        return None
    return {
        "host": host,
        "token": token,
        "apptype": os.environ.get("USER_API_APPTYPE", "6"),
        "devicetype": os.environ.get("USER_API_DEVICETYPE", "0"),
        "Content-Type": "application/json",
    }


def build_config_from_args(args) -> dict | None:
    """从命令行参数构建配置，返回 None 表示参数中没有提供 host/token。"""
    if not (getattr(args, "host", None) and getattr(args, "token", None)):
        return None
    return {
        "host": args.host,
        "token": args.token,
        "apptype": getattr(args, "apptype", "6") or "6",
        "devicetype": getattr(args, "devicetype", "0") or "0",
        "Content-Type": "application/json",
    }


def resolve_config(args) -> dict:
    """
    按优先级解析配置：
      命令行参数 > 环境变量 > 本地文件 > 交互式输入
    """
    # 1. 命令行参数（无文件模式）
    cfg = build_config_from_args(args)
    if cfg:
        return cfg

    # 2. 环境变量
    cfg = load_config_from_env()
    if cfg:
        return cfg

    # 3. 本地配置文件
    cfg = load_config_from_file()
    if cfg:
        return cfg

    # 4. 交互式输入（兜底，仅限人工命令行场景）
    return interactive_config()


def extract_domain(config: dict) -> str:
    """从配置中提取 host 字段作为 API 域名。"""
    for key, value in config.items():
        if key.lower() == "host":
            return value
    raise ValueError("配置中未找到 'host' 字段")


# ═════════════════════════════════════════════════════════════════
# 配置文件管理
# ═════════════════════════════════════════════════════════════════

def save_config(config: dict, path: Path = None):
    """保存配置到本地文件。"""
    target = path or DEFAULT_CONFIG_FILE
    target.parent.mkdir(parents=True, exist_ok=True)
    with open(target, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    print(f"✔ 配置已保存到: {target}")


def interactive_config() -> dict:
    """交互式配置（命令行手动使用时的兜底方案）。"""
    print("=" * 52)
    print("  用户信息查询 - 配置向导")
    print("=" * 52)
    print()
    print("请逐行输入 API Headers（格式: key: value），")
    print("必须包含 host 字段。输入空行结束。")
    print()

    headers: dict = {}

    while True:
        try:
            line = input("  Header> ").strip()
        except EOFError:
            _print_no_interactive_help()
            sys.exit(2)

        if not line:
            break
        if ":" not in line:
            print("  ✗ 格式错误，请使用 'key: value'")
            continue
        key, _, value = line.partition(":")
        headers[key.strip()] = value.strip()

    if not any(k.lower() == "host" for k in headers):
        print("\n✗ 必须包含 host 字段，请重试。\n")
        return interactive_config()

    if not any(k.lower() == "content-type" for k in headers):
        headers["Content-Type"] = "application/json"

    save_config(headers)
    domain = extract_domain(headers)
    print(f"\n✔ 配置完成，API 域名: {domain}\n")
    return headers


def _print_no_interactive_help():
    """当 AI 环境中 input() 失败时，打印配置说明。"""
    print()
    print("✗ 当前环境不支持交互式输入（AI 代理模式）。")
    print()
    print("请通过命令行参数直接传入配置（无需任何文件）：")
    print()
    print("  python get_user_info.py name <用户名> \\")
    print("    --host uh.51tyty.com \\")
    print("    --token <your_token> \\")
    print("    --apptype 6 --devicetype 0")
    print()
    print("或设置环境变量后再运行：")
    print("  Windows: $env:USER_API_HOST='uh.51tyty.com'; $env:USER_API_TOKEN='xxx'")
    print("  Linux/Mac: export USER_API_HOST=uh.51tyty.com USER_API_TOKEN=xxx")


# ═════════════════════════════════════════════════════════════════
# API 查询
# ═════════════════════════════════════════════════════════════════

def query_by_id(user_id: str, config: dict, domain: str) -> dict:
    url = f"http://{domain}/user/services/rest/user/{user_id}"
    r = requests.get(url, headers=config, timeout=10)
    r.raise_for_status()
    return r.json()


def query_by_name(name: str, config: dict, domain: str) -> dict:
    url = f"http://{domain}/user/services/rest/user/Name/{name}"
    r = requests.get(url, headers=config, timeout=10)
    r.raise_for_status()
    return r.json()


# ═════════════════════════════════════════════════════════════════
# 结果格式化
# ═════════════════════════════════════════════════════════════════

def format_user(user: dict) -> str:
    gender = GENDER_MAP.get(user.get("gender", ""), "未知")
    campus = CAMPUS_TYPE_MAP.get(user.get("campusType", ""), user.get("campusType", ""))
    is_valid = "有效" if user.get("isvalidate") == "true" else "无效"
    expired = "已过期" if user.get("expiredStatus") != "0" else "未过期"

    lines = [
        "=" * 52,
        "  用户信息查询结果",
        "=" * 52,
        f"  用户 ID     : {user.get('userId', '-')}",
        f"  用户名      : {user.get('username', '-')}",
        f"  昵称        : {user.get('nickname', '-')}",
        f"  性别        : {gender}",
        f"  手机号      : {user.get('mobile') or '未填写'}",
        f"  角色        : {user.get('role', '-')}",
        f"  机构 ID     : {user.get('instId', '-')}",
        f"  校区        : {user.get('campusTitle', '-')} ({campus})",
        f"  账号状态    : {is_valid} / {expired}",
        f"  激活时间    : {user.get('activeDate', '-')}",
        f"  有效期      : {user.get('startDate', '-')} ~ {user.get('endDate', '-')}",
        f"  积分(总/可用/已用): {user.get('total',0)} / {user.get('available',0)} / {user.get('consuming',0)}",
        f"  头像        : {user.get('photourl') or '未设置'}",
        "=" * 52,
    ]
    return "\n".join(lines)


def check_response(data: dict):
    if data.get("code") != "0":
        raise ValueError(
            f"API 错误 code={data.get('code')}: {data.get('message', '未知错误')}"
        )


# ═════════════════════════════════════════════════════════════════
# CLI 入口
# ═════════════════════════════════════════════════════════════════

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="get_user_info.py",
        description="查询企业内部用户信息（支持无文件模式）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例（无文件模式，AI 直接调用）：
  python get_user_info.py name studentuhqqt --host uh.51tyty.com --token xxx
  python get_user_info.py id 19857 --host uh.51tyty.com --token xxx
  python get_user_info.py mobile 13800138000 --host uh.51tyty.com --token xxx

示例（使用本地配置文件）：
  python get_user_info.py name stu_013
  python get_user_info.py id 19857

其他命令：
  python get_user_info.py config        # 交互式创建/更新配置文件
  python get_user_info.py show-config   # 查看当前配置（脱敏显示）
        """,
    )

    parser.add_argument(
        "command",
        choices=["id", "name", "mobile", "config", "show-config"],
        help="查询方式：id / name / mobile；或管理命令：config / show-config",
    )
    parser.add_argument(
        "value",
        nargs="?",
        help="查询值（id/name/mobile 模式必填）",
    )

    # ── 无文件模式参数 ──────────────────────────────────────
    group = parser.add_argument_group("无文件模式（直接传入配置，无需本地文件）")
    group.add_argument("--host", metavar="DOMAIN",
                       help="API 域名，如 uh.51tyty.com")
    group.add_argument("--token", metavar="TOKEN",
                       help="认证令牌")
    group.add_argument("--apptype", metavar="N", default="6",
                       help="应用类型（默认 6）")
    group.add_argument("--devicetype", metavar="N", default="0",
                       help="设备类型（默认 0）")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    # ── config / show-config 管理命令 ─────────────────────
    if args.command == "config":
        interactive_config()
        sys.exit(0)

    if args.command == "show-config":
        cfg = load_config_from_file()
        if not cfg:
            print("未找到本地配置文件。")
            for p in _CONFIG_PATHS:
                print(f"  候选路径: {p}")
        else:
            # 脱敏展示 token
            display = {k: ("***已设置***" if k.lower() == "token" else v) for k, v in cfg.items()}
            print(json.dumps(display, ensure_ascii=False, indent=2))
        sys.exit(0)

    # ── 查询命令 ──────────────────────────────────────────
    if not args.value:
        parser.error(f"命令 '{args.command}' 需要提供查询值，例如：... {args.command} 19857")

    # 解析配置
    try:
        config = resolve_config(args)
        domain = extract_domain(config)
    except ValueError as e:
        print(f"✗ 配置错误: {e}")
        sys.exit(1)

    # 是否使用了本地文件（用于提示）
    using_file = (build_config_from_args(args) is None
                  and load_config_from_env() is None
                  and load_config_from_file() is not None)
    src = "本地配置文件" if using_file else ("命令行参数" if build_config_from_args(args) else "环境变量")
    print(f"▶ 配置来源: {src}  |  domain: {domain}")
    print()

    # 执行查询
    try:
        if args.command == "id":
            print(f"正在通过 userId 查询: {args.value} ...")
            data = query_by_id(args.value, config, domain)
        else:  # name or mobile
            label = "用户名" if args.command == "name" else "手机号"
            print(f"正在通过{label}查询: {args.value} ...")
            data = query_by_name(args.value, config, domain)

        check_response(data)
        user = data.get("user", {})
        if not user:
            print("✗ 未找到该用户。")
            sys.exit(1)

        print(format_user(user))
        print("\n[原始 JSON]")
        print(json.dumps(data, ensure_ascii=False, indent=2))

    except requests.ConnectionError:
        print(f"✗ 无法连接服务器，请检查网络或 host 配置（当前: {domain}）")
        sys.exit(1)
    except requests.HTTPError as e:
        print(f"✗ HTTP 错误: {e}")
        sys.exit(1)
    except ValueError as e:
        print(f"✗ 业务错误: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"✗ 未知错误: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
