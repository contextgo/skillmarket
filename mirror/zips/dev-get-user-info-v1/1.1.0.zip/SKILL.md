---
name: get-user-info
version: 1.1.0
author: WorkBuddy User
description: >
  This skill should be used when the user needs to query user information from
  an internal REST API by user ID, username, or mobile number. It provides the
  complete workflow for calling the user info API, handling authentication headers
  provided interactively by the user, and interpreting the response fields.
  The API domain is automatically extracted from the 'host' header.
  Trigger phrases include: "查询用户信息", "获取用户信息", "根据用户ID查用户",
  "根据用户名查用户", "根据手机号查用户", "get user info", "fetch user details",
  or any request involving user lookup by ID, username, or mobile.
tags: [api, user-query, enterprise, rest]
---

# get-user-info Skill

## 用途

通过 userId、username 或 mobile 调用企业内部 REST API，获取并展示用户的基本信息、账号状态、校区、积分等数据。

> **v1.1.0 变化**：支持纯对话模式——配置信息直接在对话中收集，**不依赖本地配置文件**，也不会向磁盘写入任何内容。

---

## AI 执行指南（严格按步骤执行）

### Step 1：收集查询目标

若用户未明确说明，依次询问：

1. **查询方式**：`id`（用户ID）、`name`（用户名）、`mobile`（手机号）
2. **查询值**：对应的具体内容

> 若用户在触发语句中已包含信息（如"查询用户名 stu_013"），直接提取，无需再问。

---

### Step 2：收集 API 配置

**直接在对话中询问用户**，不检查、不读取、不写入任何本地文件：

```
请提供 API 连接信息（查询一次即可，无需保存）：
- host（API 域名，如：uh.51tyty.com）
- token（认证令牌）
- apptype（应用类型，默认 6，可跳过）
- devicetype（设备类型，默认 0，可跳过）
```

> **如果用户在上文已经提供过这些信息**（本次对话中），直接复用，不要重复询问。

---

### Step 3：执行查询（无文件模式）

收到配置后，**将配置作为命令行参数直接传入脚本**，一条命令完成查询，不写任何文件：

**Windows（PowerShell）：**
```powershell
$env:PYTHONIOENCODING="utf-8"
python "C:\Users\<用户名>\.codebuddy\skills\dev-get-user-info-v1\scripts\get_user_info.py" `
  <查询方式> <查询值> `
  --host <host> `
  --token <token> `
  --apptype <apptype> `
  --devicetype <devicetype>
```

**macOS / Linux（bash）：**
```bash
PYTHONIOENCODING=utf-8 \
python3 ~/.codebuddy/skills/dev-get-user-info-v1/scripts/get_user_info.py \
  <查询方式> <查询值> \
  --host <host> \
  --token <token> \
  --apptype <apptype> \
  --devicetype <devicetype>
```

**实际示例（用户名查询）：**
```powershell
$env:PYTHONIOENCODING="utf-8"
python "C:\Users\demo\.codebuddy\skills\dev-get-user-info-v1\scripts\get_user_info.py" `
  name studentuhqqt `
  --host uh.51tyty.com `
  --token abc123 `
  --apptype 6 `
  --devicetype 0
```

> **脚本路径说明**：使用 `execute_command` 工具时，先用 `$env:USERPROFILE` 获取用户目录，
> 拼接得到完整路径 `$env:USERPROFILE\.codebuddy\skills\dev-get-user-info-v1\scripts\get_user_info.py`

---

### Step 4：解读并展示结果

| 输出特征 | 含义 | 处理方式 |
|----------|------|----------|
| 打印用户信息表格 | 查询成功 | 格式化展示给用户 |
| `code=-3100` / "用户未找到" | 用户不存在 | 告知用户，建议换查询方式 |
| `✗ 无法连接服务器` | 网络/host 错误 | 请用户确认 host 是否正确 |
| `✗ HTTP 错误 401/403` | token 无效或过期 | 请用户重新提供 token |
| 乱码 / UnicodeError | 编码问题 | 确认已设置 `PYTHONIOENCODING=utf-8` |

---

### ⚠️ 关键原则

1. **不写文件**：整个查询过程不向本地磁盘写入任何配置文件
2. **不读文件**：不检查、不依赖本地配置文件（即使存在也忽略）
3. **配置当次有效**：配置信息仅在当次查询中使用，下次查询重新收集
4. **token 保密**：在展示给用户的执行命令中，将 token 脱敏显示为 `***`，但实际执行命令中使用真实值

---

### 备用方案（脚本路径找不到时）

若脚本文件路径无法确定，直接用 Python 内联代码完成查询（零文件依赖）：

```python
import sys, io, json, requests
if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

host   = "<host>"
token  = "<token>"
name   = "<查询值>"

headers = {
    "host": host,
    "token": token,
    "apptype": "6",
    "devicetype": "0",
    "Content-Type": "application/json",
}
# name/mobile 查询：
resp = requests.get(f"http://{host}/user/services/rest/user/Name/{name}", headers=headers, timeout=10)
# id 查询：
# resp = requests.get(f"http://{host}/user/services/rest/user/{user_id}", headers=headers, timeout=10)
data = resp.json()
print(json.dumps(data, ensure_ascii=False, indent=2))
```

---

## 接口信息

| 查询方式 | 接口地址 |
|----------|----------|
| userId | `http://{host}/user/services/rest/user/{userId}` |
| username / mobile | `http://{host}/user/services/rest/user/Name/{name}` |

---

## 响应字段解读

| 字段 | 说明 |
|------|------|
| `code == "0"` | 成功，用户信息在 `data["user"]` 中 |
| `code != "0"` | 失败，查看 `message` |
| `gender` | `"0"` = 男，`"1"` = 女 |
| `isvalidate` | `"true"` = 账号有效 |
| `expiredStatus` | `"0"` = 未过期 |
| `campusType` | `"main_campus"` = 主校区 |

完整字段说明 → `references/api_doc.md`

---

## 文件索引

| 文件 | 说明 |
|------|------|
| `scripts/get_user_info.py` | 主脚本，支持 `--host/--token` 无文件模式 |
| `references/api_doc.md` | 完整 API 文档 |
| `README.md` | 使用说明 |

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-04-03 | 初始版本 |
| 1.0.1 | 2026-04-07 | 修复编码、配置路径兼容、AI 执行指南 |
| 1.1.0 | 2026-04-07 | 新增无文件模式（`--host/--token` 参数），SKILL.md 改为纯对话交互流程 |
