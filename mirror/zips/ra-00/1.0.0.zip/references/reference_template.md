# 参考文献格式模板（GB/T 7714-2015）

## 中文文献格式

### 期刊论文 [J]
```
[序号] 作者. 文献标题[J]. 期刊名, 出版年份, 卷号(期号): 页码.
```
示例：
```
[1] 李明, 王强. 人工智能技术发展现状研究[J]. 科技导报, 2024, 42(5): 20-28.
```

### 学位论文 [D]
```
[序号] 作者. 论文题目[D]. 学位授予单位, 学位年份.
```

### 报告 [R]
```
[序号] 研究机构. 报告标题[R]. 出版年份.
```
示例：
```
[2] 中国信息通信研究院. 人工智能产业发展白皮书[R]. 2024.
```

### 标准 [S]
```
[序号] 标准编号. 标准名称[S]. 发布年份.
```
示例：
```
[3] GB/T XXXX-XXXX. 人工智能术语标准[S]. 2023.
```

### 专利 [P]
```
[序号] 专利申请者. 专利名称[P]. 专利号, 公开日期.
```

## 英文文献格式

### 期刊论文 [J]
```
[序号] Author A, Author B. Title of the paper[J]. Journal Name, Year, Volume(Issue): Pages.
```
示例：
```
[4] Smith J, Johnson M. Advances in deep learning techniques[J]. Nature Machine Intelligence, 2023, 5(2): 45-58.
```

### 会议论文 [C]
```
[序号] Author A. Title of the conference paper[C]//Proceedings of Conference Name. Year: Pages.
```

### 报告 [R]
```
[序号] Organization. Report Title[R]. Year.
```

### 标准 [S]
```
[序号] Standard Number. Standard Name[S]. Year.
```

## 参考文献排序要求

- 中文文献：按作者姓氏拼音字母顺序排列
- 英文文献：按作者姓氏字母顺序排列
- 中英文混合：中文在前，英文在后

## 常见期刊缩写

- IEEE Trans. on ... → IEEE Transactions on ...
- J. of ... → Journal of ...
- Proc. of ... → Proceedings of ...

## 注意事项

1. 作者姓名：姓在前，名缩写在后（如"李明"写作"Li M."）
2. 多个作者：用逗号分隔，超过3个用"等"或"et al."
3. 页码：连续页码用波浪线（如"20-28"），不连续用逗号
4. 增刊、特刊：需标注"增刊1"或"Spec. Issue 1"