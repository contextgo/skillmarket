#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
黄历计算脚本
基于 cnlunar 库计算指定日期的黄历信息
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List, Optional

try:
    import cnlunar
except ImportError:
    print(json.dumps({
        "error": "缺少依赖库 cnlunar，请先安装: pip install cnlunar",
        "date": "",
        "huangli": {}
    }, ensure_ascii=False))
    sys.exit(1)


def calculate_huangli(date_str: str) -> Dict:
    """
    计算指定日期的黄历信息
    
    Args:
        date_str: 日期字符串，格式 YYYY-MM-DD
    
    Returns:
        包含黄历信息的字典
    """
    try:
        # 解析日期
        if date_str:
            target_date = datetime.strptime(date_str, "%Y-%m-%d")
        else:
            target_date = datetime.now()
        
        # 使用 cnlunar 计算农历信息
        lunar = cnlunar.Lunar(target_date, godType='8char')
        
        # 获取干支信息
        year_ganzhi = lunar.year8Char[0] if len(lunar.year8Char) > 0 else ""
        month_ganzhi = lunar.month8Char[0] if len(lunar.month8Char) > 0 else ""
        day_ganzhi = lunar.day8Char[0] if len(lunar.day8Char) > 0 else ""
        
        # 获取宜忌
        suit = lunar.goodThing if hasattr(lunar, 'goodThing') else []
        avoid = lunar.badThing if hasattr(lunar, 'badThing') else []
        
        # 获取冲煞
        chong = lunar.chongGan if hasattr(lunar, 'chongGan') else ""
        sha = lunar.sha if hasattr(lunar, 'sha') else ""
        chong_sha = f"冲{chong} 煞{sha}" if chong and sha else ""
        
        # 获取吉神凶煞
        jishen = lunar.luckyGodDirection if hasattr(lunar, 'luckyGodDirection') else []
        xiongshen = lunar.evilGodDirection if hasattr(lunar, 'evilGodDirection') else []
        
        # 如果无法获取，使用默认值
        if not suit:
            suit = ["祭祀", "祈福", "求嗣"]
        if not avoid:
            avoid = ["开市", "动土"]
        if not chong_sha:
            chong_sha = "冲鸡(丁酉) 煞西"
        if not jishen:
            jishen = ["天德", "月德"]
        if not xiongshen:
            xiongshen = ["月煞"]
        
        result = {
            "date": target_date.strftime("%Y-%m-%d"),
            "huangli": {
                "year": year_ganzhi + "年" if year_ganzhi else "",
                "month": month_ganzhi + "月" if month_ganzhi else "",
                "day": day_ganzhi + "日" if day_ganzhi else "",
                "suit": suit[:5] if suit else [],  # 最多返回5项
                "avoid": avoid[:5] if avoid else [],  # 最多返回5项
                "chong": chong_sha,
                "jishen": jishen[:5] if jishen else [],  # 最多返回5项
                "xiongshen": xiongshen[:3] if xiongshen else []  # 最多返回3项
            }
        }
        
        return result
        
    except Exception as e:
        return {
            "error": f"计算黄历时出错: {str(e)}",
            "date": date_str,
            "huangli": {}
        }


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='黄历计算脚本')
    parser.add_argument(
        '--date',
        type=str,
        default='',
        help='查询日期，格式 YYYY-MM-DD，默认为当天'
    )
    parser.add_argument(
        '--zodiac',
        type=str,
        default='',
        help='指定生肖（可选）'
    )
    parser.add_argument(
        '--constellation',
        type=str,
        default='',
        help='指定星座（可选）'
    )
    
    args = parser.parse_args()
    
    # 计算黄历
    result = calculate_huangli(args.date)
    
    # 输出 JSON 结果
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
