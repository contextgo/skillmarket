#!/usr/bin/env python3
"""
Email Writer - Interactive L3 SimpleSequentialChain with State Management

Usage:
  # Start new session
  python email_writer.py --start --input "帮我写封感谢信"
  
  # Continue after user answers
  python email_writer.py --continue --session <session_id> --answers '{"recipient":"...", "reason":"..."}'
"""

import json
import argparse
import os
import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from pathlib import Path


class EmailWriterStateMachine:
    """L3 Multi-step email generator with state persistence."""
    
    STATE_DIR = Path(__file__).parent.parent / "state"
    
    EMAIL_TYPES = {
        "resignation": {"name": "辞职信", "required": ["recipient", "lastDay"], "optional": ["reason", "thanks", "transition"], "tone": "formal"},
        "meeting": {"name": "会议邀请", "required": ["recipient", "meetingTime", "meetingTopic"], "optional": ["location", "agenda", "duration", "preparation"], "tone": "business"},
        "thankyou": {"name": "感谢信", "required": ["recipient", "reason"], "optional": ["specificDetails", "futureAction"], "tone": "friendly"},
        "apology": {"name": "致歉信", "required": ["recipient", "apologyReason"], "optional": ["impact", "correctiveAction", "prevention"], "tone": "formal"},
        "inquiry": {"name": "咨询邮件", "required": ["recipient", "inquiryTopic"], "optional": ["background", "timeline", "contact"], "tone": "business"},
    }
    
    def __init__(self, session_id: Optional[str] = None):
        self.session_id = session_id or str(uuid.uuid4())[:8]
        self.state = self._load_state() or self._init_state()
    
    def _get_state_file(self) -> Path:
        self.STATE_DIR.mkdir(parents=True, exist_ok=True)
        return self.STATE_DIR / f"{self.session_id}.json"
    
    def _load_state(self) -> Optional[Dict]:
        state_file = self._get_state_file()
        if state_file.exists():
            with open(state_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None
    
    def _save_state(self):
        state_file = self._get_state_file()
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(self.state, f, ensure_ascii=False, indent=2)
    
    def _init_state(self) -> Dict:
        return {
            "session_id": self.session_id,
            "created_at": datetime.now().isoformat(),
            "current_step": 0,
            "user_input": "",
            "analysis": {},
            "collected_fields": {},
            "outline": {},
            "draft": "",
            "final_email": {},
            "status": "initialized"
        }
    
    def step1_analyze(self, user_input: str) -> Dict:
        """Step 1: Analyze user intent and determine email type."""
        self.state["user_input"] = user_input
        self.state["current_step"] = 1
        self.state["status"] = "analyzing"
        
        # Return instruction for LLM to analyze
        result = {
            "step": 1,
            "instruction": f"""
分析用户的邮件需求: "{user_input}"

请输出 JSON 格式的分析结果:
{{
  "analysis": {{
    "intent": "resignation|meeting|thankyou|apology|inquiry|custom",
    "tone": "formal|business|friendly|urgent",
    "requiredFields": ["字段名"],
    "optionalFields": ["字段名"]
  }}
}}

参考:
- resignation: 辞职信 (required: recipient, lastDay)
- meeting: 会议邀请 (required: recipient, meetingTime, meetingTopic)
- thankyou: 感谢信 (required: recipient, reason)
- apology: 致歉信 (required: recipient, apologyReason)
- inquiry: 咨询邮件 (required: recipient, inquiryTopic)
""",
            "next_action": "等待 LLM 返回分析结果，然后调用 --analyze-result 传入结果"
        }
        
        self._save_state()
        return result
    
    def step1_set_analysis(self, analysis_result: Dict):
        """Set analysis result from LLM."""
        # Handle nested analysis structure
        if "analysis" in analysis_result:
            self.state["analysis"] = analysis_result["analysis"]
        else:
            self.state["analysis"] = analysis_result
        self.state["status"] = "analysis_complete"
        self._save_state()
        return self._prepare_collection()
    
    def _prepare_collection(self) -> Dict:
        """Prepare Step 2: Information collection."""
        self.state["current_step"] = 2
        self.state["status"] = "collecting"
        
        analysis = self.state["analysis"]
        required = analysis.get("requiredFields", [])
        optional = analysis.get("optionalFields", [])
        
        # Build questions
        questions = []
        for field in required:
            questions.append({"id": field, "question": self._get_field_label(field), "required": True})
        for field in optional:
            questions.append({"id": field, "question": self._get_field_label(field) + "（可选）", "required": False})
        
        result = {
            "step": 2,
            "instruction": "需要收集以下信息",
            "questions": questions,
            "next_action": "调用 ask_followup_question 工具展示表单，然后等待用户提交",
            "session_id": self.session_id
        }
        
        self._save_state()
        return result
    
    def _get_field_label(self, field: str) -> str:
        labels = {
            "recipient": "收件人是谁？",
            "lastDay": "最后工作日是？",
            "reason": "原因是什么？",
            "thanks": "想感谢什么？",
            "transition": "交接安排是？",
            "meetingTime": "会议时间？",
            "meetingTopic": "会议主题？",
            "location": "地点/链接？",
            "agenda": "会议议程？",
            "specificDetails": "具体细节？",
            "futureAction": "后续行动？",
            "apologyReason": "致歉原因？",
            "correctiveAction": "补救措施？",
            "inquiryTopic": "咨询主题？",
            "background": "背景信息？"
        }
        return labels.get(field, field)
    
    def step2_set_answers(self, answers: Dict):
        """Set collected answers from user."""
        self.state["collected_fields"] = answers
        self.state["status"] = "collection_complete"
        self._save_state()
        return self.step3_plan()
    
    def step3_plan(self) -> Dict:
        """Step 3: Content planning."""
        self.state["current_step"] = 3
        self.state["status"] = "planning"
        
        email_type = self.state["analysis"].get("intent", "custom")
        fields = self.state["collected_fields"]
        tone = self.state["analysis"].get("tone", "business")
        
        result = {
            "step": 3,
            "instruction": f"""
根据以下信息生成邮件大纲:

邮件类型: {email_type}
语气: {tone}
收集的信息: {json.dumps(fields, ensure_ascii=False)}

请输出 JSON 格式的大纲:
{{
  "outline": {{
    "subject": "邮件主题",
    "sections": [
      {{"type": "greeting", "content": "称呼"}},
      {{"type": "opening", "content": "开场"}},
      {{"type": "body", "content": "正文要点"}},
      {{"type": "closing", "content": "结尾"}},
      {{"type": "signature", "content": "签名"}}
    ]
  }}
}}
""",
            "next_action": "等待 LLM 返回大纲，然后调用 --outline-result 传入结果"
        }
        
        self._save_state()
        return result
    
    def step3_set_outline(self, outline: Dict):
        """Set outline from LLM."""
        self.state["outline"] = outline
        self.state["status"] = "planning_complete"
        self._save_state()
        return self.step4_generate()
    
    def step4_generate(self) -> Dict:
        """Step 4: Generate draft."""
        self.state["current_step"] = 4
        self.state["status"] = "generating"
        
        result = {
            "step": 4,
            "instruction": f"""
根据大纲撰写完整邮件:

大纲: {json.dumps(self.state["outline"], ensure_ascii=False)}
语气: {self.state["analysis"].get("tone", "business")}

请输出完整的邮件正文（纯文本格式）。
""",
            "next_action": "等待 LLM 返回草稿，然后调用 --draft-result 传入结果"
        }
        
        self._save_state()
        return result
    
    def step4_set_draft(self, draft: str):
        """Set draft from LLM."""
        self.state["draft"] = draft
        self.state["status"] = "generation_complete"
        self._save_state()
        return self.step5a_polish_plain()
    
    def step5a_polish_plain(self) -> Dict:
        """Step 5a: Polish and generate plain text version."""
        self.state["current_step"] = "5a"
        self.state["status"] = "polishing_plain"
        
        result = {
            "step": "5a",
            "instruction": f"""
润色邮件并生成纯文本版本:

草稿:
{self.state["draft"]}

请:
1. 润色措辞，确保语气一致
2. 生成纯文本格式（NO HTML tags, NO CSS, NO styling）
3. 使用适当的段落分隔和间距
4. 只返回纯文本内容

输出 JSON:
{{
  "subject": "邮件主题",
  "plainText": "纯文本邮件内容，无任何HTML标签"
}}
""",
            "next_action": "等待 LLM 返回纯文本结果，然后调用 --plain-result 进入 Step 5b"
        }
        
        self._save_state()
        return result
    
    def step5a_set_plain(self, plain_result: Dict):
        """Set plain text result and move to Step 5b."""
        self.state["plain_result"] = plain_result
        self.state["status"] = "plain_complete"
        self._save_state()
        return self.step5b_generate_html()
    
    def step5b_generate_html(self) -> Dict:
        """Step 5b: Generate HTML version based on plain text."""
        self.state["current_step"] = "5b"
        self.state["status"] = "generating_html"
        
        plain_text = self.state["plain_result"].get("plainText", "")
        subject = self.state["plain_result"].get("subject", "")
        
        result = {
            "step": "5b",
            "instruction": f"""
基于纯文本版本生成 HTML 邮件:

主题: {subject}
纯文本内容:
{plain_text}

请:
1. 使用 assets/email-template.html 作为模板
2. 应用专业的内联 CSS 样式
3. 确保邮件客户端兼容性
4. 保持内容与纯文本版本一致，只添加 HTML 结构

输出 JSON:
{{
  "html": "完整的 HTML 邮件文档，包含内联CSS"
}}
""",
            "next_action": "等待 LLM 返回 HTML 结果，然后调用 --html-result 完成"
        }
        
        self._save_state()
        return result
    
    def step5b_set_html(self, html_result: Dict):
        """Set HTML result and complete."""
        final_email = {
            "subject": self.state["plain_result"].get("subject", ""),
            "plainText": self.state["plain_result"].get("plainText", ""),
            "html": html_result.get("html", ""),
            "metadata": {
                "type": self.state["analysis"].get("intent", "custom"),
                "tone": self.state["analysis"].get("tone", "business"),
                "generatedAt": datetime.now().isoformat()
            }
        }
        return self.step5_set_final(final_email)
    
    def step5_set_final(self, final_email: Dict):
        """Set final email and complete."""
        self.state["final_email"] = final_email
        self.state["status"] = "completed"
        self.state["completed_at"] = datetime.now().isoformat()
        self._save_state()
        
        return {
            "step": 5,
            "status": "completed",
            "result": final_email,
            "session_id": self.session_id
        }
    
    def get_status(self) -> Dict:
        """Get current status."""
        return {
            "session_id": self.session_id,
            "current_step": self.state["current_step"],
            "status": self.state["status"],
            "state": self.state
        }


def main():
    parser = argparse.ArgumentParser(description='Email Writer - Interactive L3 Chain')
    parser.add_argument('--start', action='store_true', help='Start new session')
    parser.add_argument('--continue', dest='continue_session', action='store_true', help='Continue existing session')
    parser.add_argument('--session', type=str, help='Session ID')
    parser.add_argument('--input', type=str, help='User input (for --start)')
    parser.add_argument('--answers', type=str, help='User answers JSON (for --continue)')
    parser.add_argument('--analyze-result', type=str, help='Step 1 analysis result JSON')
    parser.add_argument('--outline-result', type=str, help='Step 3 outline result JSON')
    parser.add_argument('--draft-result', type=str, help='Step 4 draft result')
    parser.add_argument('--plain-result', type=str, help='Step 5a plain text result JSON')
    parser.add_argument('--html-result', type=str, help='Step 5b HTML result JSON')
    parser.add_argument('--status', action='store_true', help='Get session status')
    
    args = parser.parse_args()
    
    if args.start and args.input:
        # Start new session
        sm = EmailWriterStateMachine()
        result = sm.step1_analyze(args.input)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.analyze_result and args.session:
        # Set analysis result
        sm = EmailWriterStateMachine(args.session)
        analysis = json.loads(args.analyze_result)
        result = sm.step1_set_analysis(analysis)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.continue_session and args.session and args.answers:
        # Continue with user answers
        sm = EmailWriterStateMachine(args.session)
        answers = json.loads(args.answers)
        result = sm.step2_set_answers(answers)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.outline_result and args.session:
        # Set outline result
        sm = EmailWriterStateMachine(args.session)
        outline = json.loads(args.outline_result)
        result = sm.step3_set_outline(outline)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.draft_result and args.session:
        # Set draft result
        sm = EmailWriterStateMachine(args.session)
        result = sm.step4_set_draft(args.draft_result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.plain_result and args.session:
        # Set Step 5a plain text result
        sm = EmailWriterStateMachine(args.session)
        plain = json.loads(args.plain_result)
        result = sm.step5a_set_plain(plain)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.html_result and args.session:
        # Set Step 5b HTML result
        sm = EmailWriterStateMachine(args.session)
        html = json.loads(args.html_result)
        result = sm.step5b_set_html(html)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.status and args.session:
        # Get status
        sm = EmailWriterStateMachine(args.session)
        result = sm.get_status()
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
