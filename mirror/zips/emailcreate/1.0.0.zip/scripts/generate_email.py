#!/usr/bin/env python3
"""
Email Generator - L3 SimpleSequentialChain Implementation
Multi-step email generation with format compliance.
"""

import json
import argparse
from datetime import datetime
from typing import Dict, List, Optional, Any


class EmailGenerator:
    """L3 Multi-step email generator."""
    
    EMAIL_TYPES = {
        "resignation": {
            "name": "辞职信",
            "required_fields": ["recipient", "lastDay"],
            "optional_fields": ["reason", "thanks", "transition"],
            "default_tone": "formal"
        },
        "meeting": {
            "name": "会议邀请",
            "required_fields": ["recipient", "meetingTime", "meetingTopic"],
            "optional_fields": ["location", "agenda", "duration", "preparation"],
            "default_tone": "business"
        },
        "thankyou": {
            "name": "感谢信",
            "required_fields": ["recipient", "reason"],
            "optional_fields": ["specificDetails", "futureAction"],
            "default_tone": "friendly"
        },
        "apology": {
            "name": "致歉信",
            "required_fields": ["recipient", "apologyReason"],
            "optional_fields": ["impact", "correctiveAction", "prevention"],
            "default_tone": "formal"
        },
        "inquiry": {
            "name": "咨询邮件",
            "required_fields": ["recipient", "inquiryTopic"],
            "optional_fields": ["background", "timeline", "contact"],
            "default_tone": "business"
        }
    }
    
    TONE_LABELS = {
        "formal": "正式",
        "business": "商务",
        "friendly": "友好",
        "urgent": "紧急"
    }
    
    def __init__(self):
        self.data = {}
    
    def step1_analyze_intent(self, user_input: str) -> Dict[str, Any]:
        """
        Step 1: Analyze user intent and determine email type and required fields.
        
        Returns analysis result for LLM to process.
        """
        # This is a template - actual analysis should be done by LLM
        result = {
            "step": 1,
            "action": "analyze_intent",
            "user_input": user_input,
            "instruction": """
            Analyze the user's request and output JSON:
            {
              "analysis": {
                "intent": "resignation|meeting|thankyou|apology|inquiry|custom",
                "tone": "formal|business|friendly|urgent",
                "requiredFields": ["field names"],
                "optionalFields": ["field names"]
              },
              "collection": {
                "strategy": "tool_call|text",
                "reasoning": "explain why"
              }
            }
            """
        }
        return result
    
    def step2_plan_content(self, email_type: str, fields: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 2: Generate email outline based on collected information.
        """
        result = {
            "step": 2,
            "action": "plan_content",
            "email_type": email_type,
            "fields": fields,
            "instruction": """
            Generate email outline following format specifications.
            Output JSON:
            {
              "outline": {
                "subject": "email subject line",
                "sections": [
                  {"type": "greeting", "content": "..."},
                  {"type": "opening", "content": "..."},
                  {"type": "body", "content": "..."},
                  {"type": "closing", "content": "..."},
                  {"type": "signature", "content": "..."}
                ]
              }
            }
            """
        }
        return result
    
    def step3_generate_draft(self, outline: Dict[str, Any], tone: str) -> Dict[str, Any]:
        """
        Step 3: Generate complete email content based on outline.
        """
        result = {
            "step": 3,
            "action": "generate_draft",
            "outline": outline,
            "tone": tone,
            "instruction": """
            Generate complete email content following the outline.
            Ensure proper formatting and tone consistency.
            Output the full email text.
            """
        }
        return result
    
    def step4_polish(self, draft: str, email_type: str) -> Dict[str, Any]:
        """
        Step 4: Polish and format the final email.
        """
        result = {
            "step": 4,
            "action": "polish",
            "draft": draft,
            "email_type": email_type,
            "instruction": """
            Polish the email and generate both HTML and plain text versions.
            Apply professional styling according to email-formats.md specifications.
            Output JSON:
            {
              "subject": "email subject",
              "html": "HTML formatted email",
              "plainText": "plain text version",
              "metadata": {
                "type": "email type",
                "tone": "tone used",
                "generatedAt": "timestamp"
              }
            }
            """
        }
        return result
    
    def generate_html_email(self, subject: str, content: str, 
                           sender_name: str, sender_title: str = "",
                           sender_contact: str = "") -> str:
        """
        Generate HTML email using the template.
        """
        date_str = datetime.now().strftime("%Y年%m月%d日")
        
        # Simple template substitution (in production, use proper templating)
        html_template = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{subject}</title>
  <style>
    body {{ margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif; }}
    .email-wrapper {{ width: 100%; max-width: 600px; margin: 0 auto; background-color: #ffffff; }}
    .email-container {{ padding: 40px 30px; }}
    .email-header {{ border-bottom: 3px solid #4a90e2; padding-bottom: 20px; margin-bottom: 30px; }}
    .email-subject {{ font-size: 20px; font-weight: 600; color: #1a1a1a; margin: 0; }}
    .email-meta {{ font-size: 12px; color: #888; margin-top: 8px; }}
    .email-content {{ font-size: 15px; line-height: 1.8; color: #333; }}
    .email-content p {{ margin: 0 0 16px 0; }}
    .email-signature {{ margin-top: 40px; padding-top: 25px; border-top: 1px solid #e8e8e8; }}
    .signature-name {{ font-weight: 600; color: #1a1a1a; margin-bottom: 4px; }}
    .signature-title {{ font-size: 13px; color: #666; margin-bottom: 4px; }}
    .signature-contact {{ font-size: 13px; color: #888; }}
    @media screen and (max-width: 600px) {{
      .email-container {{ padding: 30px 20px; }}
      .email-subject {{ font-size: 18px; }}
      .email-content {{ font-size: 14px; }}
    }}
  </style>
</head>
<body>
  <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
    <tr>
      <td align="center" style="padding: 20px 0;">
        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" class="email-wrapper" style="max-width: 600px; width: 100%;">
          <tr>
            <td class="email-header" style="padding: 40px 30px 20px; border-bottom: 3px solid #4a90e2;">
              <h1 class="email-subject" style="margin: 0; font-size: 20px; font-weight: 600; color: #1a1a1a;">{subject}</h1>
              <div class="email-meta" style="font-size: 12px; color: #888; margin-top: 8px;">{date}</div>
            </td>
          </tr>
          <tr>
            <td class="email-container" style="padding: 30px;">
              <div class="email-content" style="font-size: 15px; line-height: 1.8; color: #333;">
                {content}
              </div>
              <div class="email-signature" style="margin-top: 40px; padding-top: 25px; border-top: 1px solid #e8e8e8;">
                <div class="signature-name" style="font-weight: 600; color: #1a1a1a; margin-bottom: 4px;">{sender_name}</div>
                {sender_title_html}
                {sender_contact_html}
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>"""
        
        sender_title_html = f'<div class="signature-title" style="font-size: 13px; color: #666; margin-bottom: 4px;">{sender_title}</div>' if sender_title else ''
        sender_contact_html = f'<div class="signature-contact" style="font-size: 13px; color: #888;">{sender_contact}</div>' if sender_contact else ''
        
        return html_template.format(
            subject=subject,
            date=date_str,
            content=content,
            sender_name=sender_name,
            sender_title_html=sender_title_html,
            sender_contact_html=sender_contact_html
        )
    
    def plain_text_from_html(self, html_content: str) -> str:
        """
        Convert HTML to plain text.
        """
        import re
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', '', html_content)
        # Remove extra whitespace
        text = re.sub(r'\n\s*\n', '\n\n', text)
        # Decode HTML entities
        import html
        text = html.unescape(text)
        return text.strip()


def main():
    parser = argparse.ArgumentParser(description='Email Generator - L3 Multi-step Chain')
    parser.add_argument('--step', type=int, required=True, help='Step number (1-4)')
    parser.add_argument('--input', type=str, help='Input JSON string')
    parser.add_argument('--file', type=str, help='Input JSON file')
    
    args = parser.parse_args()
    
    # Load input data
    if args.file:
        with open(args.file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    elif args.input:
        data = json.loads(args.input)
    else:
        data = {}
    
    generator = EmailGenerator()
    
    # Execute requested step
    if args.step == 1:
        user_input = data.get('user_input', '')
        result = generator.step1_analyze_intent(user_input)
    elif args.step == 2:
        email_type = data.get('email_type', 'custom')
        fields = data.get('fields', {})
        result = generator.step2_plan_content(email_type, fields)
    elif args.step == 3:
        outline = data.get('outline', {})
        tone = data.get('tone', 'business')
        result = generator.step3_generate_draft(outline, tone)
    elif args.step == 4:
        draft = data.get('draft', '')
        email_type = data.get('email_type', 'custom')
        result = generator.step4_polish(draft, email_type)
    else:
        result = {"error": "Invalid step number. Use 1-4."}
    
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
