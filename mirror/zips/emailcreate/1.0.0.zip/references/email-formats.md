# Email Format Specifications

## General Structure

All professional emails should follow this structure:

1. **Subject Line** - Clear, concise, actionable
2. **Greeting** - Appropriate for relationship and tone
3. **Opening** - Context or purpose statement
4. **Body** - Main content with clear paragraphs
5. **Closing** - Call to action or wrap-up
6. **Signature** - Professional sign-off with contact info

## Email Types

### Resignation Letter

**Subject**: 辞职申请 - [Your Name] / Resignation Letter - [Your Name]

**Structure**:
- Greeting: 尊敬的领导 / Dear [Manager's Name]
- Opening: State resignation intention clearly
- Body: Last working day, brief reason (optional), gratitude
- Closing: Transition commitment, well wishes
- Signature: Full name, date, contact

**Tone**: Formal, respectful, professional

**Required Fields**:
- recipient: Who receives the letter
- lastDay: Final working date

**Optional Fields**:
- reason: Brief reason for leaving
- thanks: Specific thanks to company/team
- transition: Handover plan

---

### Meeting Invitation

**Subject**: 【会议邀请】[Meeting Topic] / Meeting Invitation: [Topic]

**Structure**:
- Greeting: Hi [Name] / 您好
- Opening: Meeting purpose
- Body: Time, location/link, agenda, preparation needed
- Closing: RSVP request, contact for questions
- Signature: Organizer info

**Tone**: Business, clear, organized

**Required Fields**:
- recipient: Attendee(s)
- meetingTime: Date and time
- meetingTopic: Meeting subject

**Optional Fields**:
- location: Physical location or video link
- agenda: List of topics
- duration: Expected length
- preparation: Pre-reading or prep tasks

---

### Thank You Email

**Subject**: 感谢[具体事项] / Thank You for [Specific Thing]

**Structure**:
- Greeting: Personal but professional
- Opening: Express gratitude immediately
- Body: Specific details about what you're thankful for, impact
- Closing: Future relationship/offer to help
- Signature: Your info

**Tone**: Warm, sincere, professional

**Required Fields**:
- recipient: Who you're thanking
- reason: What you're thankful for

**Optional Fields**:
- specificDetails: Specific examples or impact
- futureAction: How you'll use their help/offer reciprocity

---

### Apology Email

**Subject**: 关于[事项]的致歉 / Apology Regarding [Matter]

**Structure**:
- Greeting: Professional
- Opening: Direct apology without excuses
- Body: Acknowledge impact, brief explanation (not excuse), corrective action
- Closing: Commitment to prevent recurrence, request for understanding
- Signature: Your info

**Tone**: Sincere, accountable, professional

**Required Fields**:
- recipient: Who you're apologizing to
- apologyReason: What you're apologizing for

**Optional Fields**:
- impact: Acknowledgment of consequences
- correctiveAction: Steps taken/to take
- prevention: How you'll avoid recurrence

---

### Inquiry Email

**Subject**: 关于[主题]的咨询 / Inquiry About [Subject]

**Structure**:
- Greeting: Professional
- Opening: State inquiry purpose
- Body: Background context, specific questions (numbered if multiple)
- Closing: Timeline for response, appreciation
- Signature: Your info

**Tone**: Polite, clear, concise

**Required Fields**:
- recipient: Who you're contacting
- inquiryTopic: What you're asking about

**Optional Fields**:
- background: Context for the inquiry
- timeline: When you need a response
- contact: Preferred contact method

---

## HTML Styling Guidelines

### CSS Standards

```css
/* Container */
.email-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  line-height: 1.6;
  color: #333;
}

/* Subject */
.subject {
  font-size: 18px;
  font-weight: bold;
  color: #1a1a1a;
  border-bottom: 2px solid #e0e0e0;
  padding-bottom: 10px;
  margin-bottom: 20px;
}

/* Content */
.content {
  color: #444;
  font-size: 14px;
}

.content p {
  margin: 12px 0;
}

/* Signature */
.signature {
  margin-top: 30px;
  padding-top: 20px;
  border-top: 1px solid #e0e0e0;
  color: #666;
  font-size: 13px;
}

/* Highlights */
.highlight {
  background-color: #fff3cd;
  padding: 2px 4px;
  border-radius: 3px;
}
```

### Email Client Compatibility

- Use inline styles for maximum compatibility
- Avoid external CSS files
- Use table-based layouts for complex structures
- Test in major clients: Gmail, Outlook, Apple Mail
- Keep width under 600px

## Tone Guidelines

### Formal
- Use full titles and last names
- Complete sentences, no contractions
- Professional vocabulary
- Structured paragraphs

### Business
- Professional but approachable
- May use first names if relationship established
- Clear and concise
- Action-oriented

### Friendly
- Warm and personable
- First names
- Conversational but still professional
- Shows personality

### Urgent
- Clear priority indicators
- Immediate action requests
- Concise, scannable format
- Contact information prominent
