---
name: email-writer
description: This skill should be used when the user needs to write professional emails. It guides users through a multi-step process to generate well-formatted HTML emails with proper structure, tone, and styling. Trigger phrases include "帮我写封邮件", "生成邮件", "写辞职信", "写会议邀请", "email writer", "draft an email".
---

# Email Writer

## Overview

This skill helps users write professional emails through a guided multi-step process (L3 SimpleSequentialChain). It analyzes user intent, collects necessary information dynamically, and generates well-formatted HTML emails with proper structure and styling.

## How to Use This Skill

This skill uses an interactive state machine. Execute commands in order:

### Quick Start

```bash
# 1. Start new session
python scripts/email_writer.py --start --input "帮我写封感谢信"

# 2. After getting analysis instruction, run LLM analysis, then:
python scripts/email_writer.py --session <id> --analyze-result '{"intent":"thankyou",...}'

# 3. This will output questions. Use appropriate tool to collect answers, then:
python scripts/email_writer.py --continue --session <id> --answers '{"recipient":"...",...}'

# 4. After getting outline instruction, run LLM, then:
python scripts/email_writer.py --session <id> --outline-result '{"outline":{...}}'

# 5. After getting draft instruction, run LLM, then:
python scripts/email_writer.py --session <id> --draft-result '邮件正文...'

# 6. After getting Step 5a (plain text) instruction, run LLM, then:
python scripts/email_writer.py --session <id> --plain-result '{"subject":"...","plainText":"..."}'

# 7. After getting Step 5b (HTML) instruction, run LLM, then:
python scripts/email_writer.py --session <id> --html-result '{"html":"..."}'
```

### State Management

Each session has a state file in `state/{session_id}.json`. The script manages:
- Current step (1-5)
- Collected information
- Intermediate results
- Final output

**Important:** Always use the script to manage state. Do not manually edit state files.

## Workflow

### Step 1: Intent Analysis

Analyze the user's request to determine:
- Email type (resignation, meeting invitation, thank you, apology, inquiry, custom)
- Required tone (formal, business, friendly, urgent)
- Required fields to collect
- Optional fields that enhance the email

Output format:
```json
{
  "analysis": {
    "intent": "resignation|meeting|thankyou|apology|inquiry|custom",
    "tone": "formal|business|friendly|urgent",
    "requiredFields": ["fieldName"],
    "optionalFields": ["fieldName"]
  },
  "collection": {
    "strategy": "tool_call|text",
    "reasoning": "why this strategy was chosen"
  }
}
```

### Step 2: Information Collection

**CRITICAL: You MUST collect missing information before proceeding.**

Based on Step 1 analysis, identify missing required fields and collect them:

**Collection Strategy (MUST choose one):**

1. **Tool Call Strategy** (Preferred if tools available)
   - 使用支持结构化表单交互的工具，如 `ask_followup_question` 等多选/单选/文本输入工具
   - 理想工具特征：支持多字段表单、单选/多选选项、必填/选填标记、交互式问答
   - 将缺失的字段组织成结构化问题（多选题、单选题、文本输入框），然后调用工具
   - **CRITICAL: After calling the tool, STOP and wait for user response**
   - Only proceed to Step 3 after receiving the answers

2. **Text Strategy** (Fallback)
   - If no tools available, ask user directly in natural language
   - List all required fields clearly
   - **STOP and wait for user to provide the information**
   - Only proceed to Step 3 after receiving all required fields

**⚠️ IMPORTANT: You MUST stop after requesting information. Do not generate example content or proceed to the next step until the user provides the actual information.**

Common fields by email type:
- **Resignation**: recipient, lastDay, reason (optional), thanks (optional)
- **Meeting**: recipient, meetingTime, meetingTopic, location (optional), agenda
- **Thank You**: recipient, reason, specificDetails (optional)
- **Apology**: recipient, apologyReason, correctiveAction (optional)
- **Inquiry**: recipient, inquiryTopic, background (optional)

### Step 3: Content Planning

Generate email outline based on collected information:

```json
{
  "outline": {
    "subject": "email subject line",
    "sections": [
      {"type": "greeting", "content": "..."},
      {"type": "opening", "content": "..."},
      {"type": "body", "content": "..."},
      {"type": "closing", "content": "..."},
      {"type": "signature", "content": "..."}
    ]
  }
}
```

### Step 4: Email Generation

Generate the complete email content following format specifications from references/email-formats.md.

### Step 5: Polish and Format

Generate final output in TWO separate substeps:

**Step 5a: Generate Plain Text Version**
- Polish the draft for clarity and tone consistency
- Output clean, formatted plain text
- No HTML tags, no CSS, no styling
- Proper paragraph breaks and spacing

**Step 5b: Generate HTML Version**
- Take the polished plain text from Step 5a
- Apply professional HTML email styling
- Use the template from assets/email-template.html
- Inline CSS for email client compatibility
- Keep content identical to plain text version, only add HTML structure

**Output Format:**
```json
{
  "subject": "email subject",
  "plainText": "Clean plain text version without any HTML",
  "html": "Full HTML with inline CSS styling",
  "metadata": {
    "type": "email type",
    "tone": "tone used",
    "generatedAt": "timestamp"
  }
}
```

**Important:** The plainText field must contain NO HTML tags. The html field must contain the complete HTML document with styling.

## Output Format

Always provide both formats:

1. **HTML Version**: Rich text with professional styling
2. **Plain Text Version**: Compatible with all email clients

Include a copy button or clear separation for easy use.

## Resources

### references/email-formats.md

Email format specifications and templates. Load this file when generating emails to ensure proper structure and styling.

### scripts/generate_email.py

Python script that executes the L3 multi-step chain. Use this for deterministic email generation when needed.

### assets/email-template.html

HTML email template with professional CSS styling.
