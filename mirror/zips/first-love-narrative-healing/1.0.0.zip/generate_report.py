#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
初恋叙事和解报告生成器
生成Word格式的《初恋叙事和解报告》
"""

import json
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

class FirstLoveReportGenerator:
    """初恋叙事和解报告生成器"""
    
    def __init__(self, user_data):
        self.user_data = user_data
        self.doc = Document()
        self.setup_styles()
    
    def setup_styles(self):
        """设置文档样式"""
        # 设置默认字体
        self.doc.styles['Normal'].font.name = 'Microsoft YaHei'
        self.doc.styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        
    def add_cover(self):
        """添加封面"""
        # 添加空行
        for _ in range(6):
            self.doc.add_paragraph()
        
        # 标题
        title = self.doc.add_paragraph()
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = title.add_run('初恋叙事和解报告')
        run.font.size = Pt(36)
        run.font.bold = True
        run.font.color.rgb = RGBColor(102, 78, 99)  # 暖紫色调
        
        # 副标题
        subtitle = self.doc.add_paragraph()
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = subtitle.add_run('用数字技术安放青春记忆')
        run.font.size = Pt(16)
        run.font.color.rgb = RGBColor(150, 120, 140)
        
        # 空行
        for _ in range(4):
            self.doc.add_paragraph()
        
        # 日期
        date_para = self.doc.add_paragraph()
        date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = date_para.add_run(f'生成日期：{datetime.now().strftime("%Y年%m月%d日")}')
        run.font.size = Pt(12)
        run.font.color.rgb = RGBColor(120, 120, 120)
        
        self.doc.add_page_break()
    
    def add_memory_archive(self):
        """添加记忆叙事档案"""
        # 标题
        heading = self.doc.add_heading('一、记忆叙事档案', level=1)
        heading.runs[0].font.color.rgb = RGBColor(102, 78, 99)
        
        # 核心记忆场景
        self.doc.add_heading('核心记忆场景', level=2)
        scenes = self.user_data.get('scenes', [])
        for i, scene in enumerate(scenes, 1):
            p = self.doc.add_paragraph()
            p.add_run(f'场景{i}：').bold = True
            p.add_run(scene.get('description', ''))
            
            if 'emotion' in scene:
                p = self.doc.add_paragraph()
                p.add_run('情感标签：').bold = True
                p.add_run(scene['emotion'])
            
            if 'significance' in scene:
                p = self.doc.add_paragraph()
                p.add_run('重要意义：').bold = True
                p.add_run(scene['significance'])
            
            self.doc.add_paragraph()
        
        # 情感脉络
        self.doc.add_heading('情感脉络时间线', level=2)
        emotions = self.user_data.get('emotions', [])
        for emotion in emotions:
            p = self.doc.add_paragraph(style='List Bullet')
            p.add_run(emotion)
        
        # 关系本质解读
        self.doc.add_heading('关系本质解读', level=2)
        p = self.doc.add_paragraph(self.user_data.get('relationship_insight', ''))
        
        self.doc.add_page_break()
    
    def add_growth_comparison(self):
        """添加当年的我 vs 现在的我"""
        heading = self.doc.add_heading('二、当年的我 vs 现在的我', level=1)
        heading.runs[0].font.color.rgb = RGBColor(102, 78, 99)
        
        # 创建对比表格
        table = self.doc.add_table(rows=5, cols=3)
        table.style = 'Light Grid Accent 1'
        
        # 表头
        headers = ['维度', '当年的我', '现在的我']
        for i, header in enumerate(headers):
            cell = table.rows[0].cells[i]
            cell.text = header
            cell.paragraphs[0].runs[0].font.bold = True
        
        # 数据行
        dimensions = [
            ('性格特点', 'personality'),
            ('认知方式', 'cognition'),
            ('情感表达', 'emotional_expression'),
            ('关系处理', 'relationship_handling')
        ]
        
        for i, (label, key) in enumerate(dimensions, 1):
            table.rows[i].cells[0].text = label
            table.rows[i].cells[1].text = self.user_data.get(f'past_{key}', '')
            table.rows[i].cells[2].text = self.user_data.get(f'present_{key}', '')
        
        self.doc.add_paragraph()
        
        # 关键成长点
        self.doc.add_heading('关键成长点', level=2)
        growth_points = self.user_data.get('growth_points', [])
        for point in growth_points:
            p = self.doc.add_paragraph(style='List Number')
            p.add_run(point)
        
        self.doc.add_page_break()
    
    def add_regret_reconstruction(self):
        """添加遗憾重构解读"""
        heading = self.doc.add_heading('三、遗憾重构解读', level=1)
        heading.runs[0].font.color.rgb = RGBColor(102, 78, 99)
        
        # 核心遗憾
        self.doc.add_heading('核心遗憾', level=2)
        p = self.doc.add_paragraph(self.user_data.get('core_regret', ''))
        
        # 遗憾本质
        self.doc.add_heading('遗憾本质分析', level=2)
        p = self.doc.add_paragraph(self.user_data.get('regret_essence', ''))
        
        # 转化为行动
        self.doc.add_heading('转化为当下行动', level=2)
        actions = self.user_data.get('actions', [])
        for action in actions:
            p = self.doc.add_paragraph(style='List Bullet')
            p.add_run(action)
        
        self.doc.add_page_break()
    
    def add_youth_message(self):
        """添加青春寄语"""
        heading = self.doc.add_heading('四、青春寄语', level=1)
        heading.runs[0].font.color.rgb = RGBColor(102, 78, 99)
        
        # 寄语内容（引用格式）
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(self.user_data.get('youth_message', ''))
        run.font.italic = True
        run.font.size = Pt(14)
        run.font.color.rgb = RGBColor(102, 78, 99)
        
        self.doc.add_paragraph()
        
        # 和解确认
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run('✓ 和解确认')
        run.font.size = Pt(16)
        run.font.bold = True
        run.font.color.rgb = RGBColor(76, 175, 80)
        
        # 日期
        self.doc.add_paragraph()
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f'确认日期：{datetime.now().strftime("%Y年%m月%d日")}')
        run.font.size = Pt(12)
        run.font.color.rgb = RGBColor(120, 120, 120)
        
        self.doc.add_page_break()
    
    def add_appendix(self):
        """添加附录"""
        heading = self.doc.add_heading('附录：对话摘要', level=1)
        heading.runs[0].font.color.rgb = RGBColor(102, 78, 99)
        
        # 对话摘要
        dialogue_summary = self.user_data.get('dialogue_summary', [])
        for item in dialogue_summary:
            p = self.doc.add_paragraph()
            p.add_run(f'【{item.get("role", "")}】').bold = True
            p.add_run(item.get('content', ''))
        
        # 数据来源说明
        self.doc.add_paragraph()
        p = self.doc.add_paragraph()
        p.add_run('数据来源说明：').bold = True
        p.add_run('本报告基于用户与"初恋"Skill的对话交互数据生成，仅包含用户主动分享的记忆叙事、情感表达和成长反思。不涉及具体隐私细节（如真实姓名、具体地点等）。')
    
    def generate(self, output_path):
        """生成完整报告"""
        self.add_cover()
        self.add_memory_archive()
        self.add_growth_comparison()
        self.add_regret_reconstruction()
        self.add_youth_message()
        self.add_appendix()
        
        self.doc.save(output_path)
        return output_path


def generate_sample_report():
    """生成示例报告"""
    sample_data = {
        'scenes': [
            {
                'description': '那个下雨的傍晚，在车站告别',
                'emotion': '遗憾、温柔、不舍',
                'significance': '代表了我想要勇敢却最终沉默的瞬间'
            },
            {
                'description': '第一次牵手的那天',
                'emotion': '紧张、甜蜜、期待',
                'significance': '青春里最纯粹的心动时刻'
            },
            {
                'description': '最后一次见面的咖啡馆',
                'emotion': '悲伤、释然、成长',
                'significance': '学会接受分离，开始理解爱的另一种形式'
            }
        ],
        'emotions': [
            '初识时的好奇与心动',
            '相处中的甜蜜与忐忑',
            '分离前的挣扎与不舍',
            '告别后的遗憾与怀念',
            '回望时的理解与释然'
        ],
        'relationship_insight': '这段关系是青春里最真诚的相遇。两个人都带着原生家庭给的情感模板，笨拙地摸索着爱的形状。分开不是因为谁不够好，而是成长的节奏刚好不同。这段经历让我学会了尊重他人的节奏，也坚守自己的方向。',
        'past_personality': '敏感、犹豫、害怕被拒绝',
        'present_personality': '自信、勇敢、接纳自己',
        'past_cognition': '非黑即白，认为爱就是永远在一起',
        'present_cognition': '理解爱的多种形式，尊重每个人的成长节奏',
        'past_emotional_expression': '压抑、回避、不敢表达真实感受',
        'present_emotional_expression': '坦诚、直接、敢于脆弱',
        'past_relationship_handling': '被动等待，害怕主动会失去',
        'present_relationship_handling': '主动沟通，珍惜当下，尊重边界',
        'growth_points': [
            '从"害怕被拒绝"到"敢于表达"——学会了情感诚实',
            '从"追求永远"到"珍惜当下"——理解了爱的流动性',
            '从"自我否定"到"自我接纳"——建立了健康的自我认知',
            '从"被动等待"到"主动选择"——掌握了关系的主导权'
        ],
        'core_regret': '没能在那个下雨的傍晚，把想说的话说完',
        'regret_essence': '这个遗憾的本质，不是"没和TA走到最后"，而是遗憾当年那个"不够勇敢表达自己"的自己。',
        'actions': [
            '对身边的人多一份珍惜——及时表达爱与感谢',
            '在想要表达的时候，先对自己诚实',
            '接受分离是成长的一部分，不执着于永远',
            '把当年的遗憾转化为现在的勇气'
        ],
        'youth_message': '那段感情，已经完成了它的使命——它把你从一个敏感犹豫的人，变成了一个自信勇敢的人。现在，你可以带着这份成长的礼物，继续走向前面的人生了。初恋会永远留在你滚烫的青春里，成为你生命的一部分。但你的故事，还在继续。',
        'dialogue_summary': [
            {'role': '用户', 'content': '我想聊聊我的初恋...'},
            {'role': 'Skill', 'content': '欢迎来到青春锚点。我们将一起梳理那段关于初恋的记忆...'},
            {'role': '用户', 'content': '我常常想起那个下雨的傍晚...'},
            {'role': 'Skill', 'content': '那个傍晚留在你的记忆里，带着湿润的气息和未完成的心情...'}
        ]
    }
    
    generator = FirstLoveReportGenerator(sample_data)
    output_path = '初恋叙事和解报告_示例.docx'
    generator.generate(output_path)
    print(f'示例报告已生成: {output_path}')
    return output_path


if __name__ == '__main__':
    generate_sample_report()
