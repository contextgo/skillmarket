# Meservey Validation

用途：发布前验证、回归测试、校准。  
定位：列出结构验证、触发验证、行为校准，不放实现细节。

## 结构验证

- `SKILL.md` frontmatter 合法
- 目录名与 `name: meservey-pr-review` 一致
- `references/` 中被引用文件全部存在
- `agents/openai.yaml` 存在且字段完整
- `description` 维持短版、平台安全版

## 触发验证

### 应触发

- `用 Meservey 标准帮我审这篇危机声明`
- `review this founder letter with Meservey style`
- `帮我看看这篇产品发布稿哪里 corporate`
- `给这篇融资公告做 PR audit`
- `按 Meservey 方法改这篇 CEO 演讲稿`

### 不应触发

- `Lulu Cheng Meservey 是谁`
- `帮我写一份媒体投放计划`
- `帮我看下这个合同`
- `解释这段 Python 代码`
- `给我讲讲公关行业趋势`

## 行为校准

### 正向校准

- 风格鲜明、有人声、有行动导向的 founder text 不应被误判为低分
- 真实、具体、带场景的 launch 文案应该在 `P3/P4/P10` 上表现良好

### 反向校准

- 没有署名负责人的危机声明必须触发红线
- 全是形容词、没有用户场景的产品稿必须在 `P3/P4/P10` 上明显失分
- 完全 corporate 的文本不应被“礼貌地”打成高分

### 边界校准

- 缺少 audience / belief / action / channel 时，输出预审版
- 多版本输入时，必须先比较再选基底
- 用户要原话依据时，必须回链 `meservey-core-originals.md`

## 黄金测试

用途：每次 Codex 修改 `SKILL.md`、`meservey-core-principles.md`、`meservey-redlines.md`、`meservey-case-library.md` 或 `meservey-quotes-library.md` 后，都用下面 4 个固定样本回归一次。  
通过标准：输出结果必须大体符合 `预期评级 / 预期红线 / 预期结论重点`。  
失败标准：如果评级明显漂移、漏掉关键红线、或者把边界样本看反，说明 skill 校准被破坏了。

### 脚本化入口

- Fixtures: [references/meservey-golden-tests.json](../references/meservey-golden-tests.json)
- Harness: [scripts/run_golden_tests.py](../scripts/run_golden_tests.py)

常用命令：

```bash
python scripts/run_golden_tests.py list
python scripts/run_golden_tests.py emit --all --out-dir /tmp/meservey-golden
python scripts/run_golden_tests.py check --results-dir /path/to/filled-results
```

建议流程：

1. 运行 `emit --all` 生成 4 个固定测试 prompt。
2. 用当前 skill 分别产出 4 份结果文件，命名为 `GT-1.md` 到 `GT-4.md`。
3. 运行 `check --results-dir ...` 做基础回归检查。
4. 对 `FAIL` 的条目再人工复核一次，判断是 skill 漂移，还是 checker 关键词需要更新。

### GT-1 好稿样本

- 目标：验证 skill 不会把强 founder text 错判成“太主观”或“太不 corporate”
- 预期评级：`A`
- 预期特征：
  - `P1/P2/P3/P5/P6/P10` 应明显高分
  - 不应触发红线
  - 结论应肯定其 human voice、具体性、业务导向和 conviction
- 失败信号：
  - 被打成 `B` 以下
  - 主要批评点集中在“太直接”“太锋利”
  - 没有识别出 `audience / belief / action`
- 测试输入：

```text
请用 Meservey 标准评审下面这篇创始人招聘信。

背景：
- audience: 资深基础设施工程师
- belief: 现在加入我们是一个不对称收益机会；问题真实且重要；团队认真、有速度
- action: 申请加入，或者转给会感兴趣的人
- channel: 创始人 LinkedIn 长文 + 官网职位页

正文：
Three years ago, our team spent a week inside a regional hospital trying to understand why nurses were still faxing patient updates in 2026. The answer was not that people were lazy. It was that the software around them was slow, brittle, and built by people who never had to use it at 2 a.m.

We started Aster not because healthcare "needs innovation," but because we were tired of watching good clinicians lose hours to software that should have saved them time. Since launching our first product, 48 clinics have switched from legacy systems, average intake time is down 31%, and support tickets are resolved in under 12 minutes.

Now we need two senior infrastructure engineers.

You should not join us if you want a comfortable maintenance job, or if you need every decision to move through three committees before anyone writes code. You should talk to us if you want to build software that gets used in high-stakes environments, if you care about speed and reliability at the same time, and if you want direct feedback from customers who will absolutely tell you when something is broken.

This is not a company where the founder disappears behind a comms team or a management layer. I still review product notes, I still join customer calls, and when we ship something important, I explain why we built it in public under my own name.

If that sounds intense, good. It is. But if you're the kind of person who wants to do the best work of your career on a problem that actually matters, email me directly.
```

### GT-2 烂稿样本

- 目标：验证 skill 会明确识别典型 corporate mush，而不是“礼貌性给个 B”
- 预期评级：`D` 或 `F`
- 预期红线：
  - `没有明确发声主体`
  - `全文被企业官话、模糊套话主导`
  - `不知道写给谁看，也不知道想让读者做什么`
  - `新闻稿 / 产品发布` 场景下应指出 `P3/P4/P10` 明显失分
- 预期结论重点：
  - 明确指出“谁都可以发这篇稿”
  - 明确指出“只有抽象形容词，没有场景、动作、后果”
  - 明确建议重写，而不是小修小补
- 失败信号：
  - 给出 `C` 以上
  - 没提红线
  - 把问题主要归因于“句子还可以更精炼”
- 测试输入：

```text
请用 Meservey 标准评审下面这篇产品发布稿。

背景：
- audience: 未提供
- belief: 未提供
- action: 未提供
- channel: 新闻稿

正文：
今日，NovaMind 正式宣布推出其全新一代智能协同平台。该平台依托前沿人工智能能力与行业领先的大模型架构，全面赋能企业客户实现数字化转型升级，进一步提升组织协同效率与运营韧性。

NovaMind 始终坚持以客户为中心的发展理念，持续深耕核心技术创新，不断完善产品矩阵，为客户创造长期价值。本次发布的新平台整合了先进的自动化能力、智能分析能力以及多场景协同能力，可广泛应用于众多行业场景，帮助客户实现高质量发展。

未来，NovaMind 将继续秉承开放、合作、共赢的理念，携手生态伙伴共同推动产业创新升级，加快构建智能协同新范式，为行业带来更多可能。
```

### GT-3 边界样本

- 目标：验证 skill 能正确处理“看起来不差，但还不够 Meservey”的中间稿
- 预期评级：`B`
- 预期降档理由：
  - 不应触发最重红线
  - 但应指出 `P1/P3/P6/P8` 至少有部分失分
  - 应明确说明它“有业务方向，但仍偏 safe / generic / not founder-enough”
- 预期结论重点：
  - 认可 business objective 和基本清晰度
  - 指出缺少 sharp edge、个人 stakes、记忆点
  - 给出 2-3 个高优先级重写方向
- 失败信号：
  - 被打成 `A`
  - 被打成 `D/F`
  - 没解释清楚为什么只是 `B`
- 测试输入：

```text
请用 Meservey 标准评审下面这篇融资公告。

背景：
- audience: 潜在候选人、潜在客户、现有投资人、行业观察者
- belief: 公司增长真实、市场机会足够大、团队值得关注
- action: 愿意进一步了解公司、申请职位、与销售接触
- channel: 公司博客 + 创始人 X 线程

正文：
今天，我们宣布完成 4500 万美元 B 轮融资，由 North Peak 领投，现有投资人继续跟投。

过去两年，我们专注于帮助制造业团队更快发现供应链异常并提前响应。我们的系统现在被 120 多家工厂使用，平均帮助客户把关键异常响应时间缩短了 18%。

这笔资金将主要用于扩展产品和招聘团队。我们很感谢客户和投资人的支持，也对接下来的阶段感到兴奋。

我们相信，全球制造业未来十年的核心竞争力之一，将取决于谁能更快看到风险、理解风险并采取行动。我们想打造的，不只是一个提醒系统，而是制造团队每天都会依赖的决策界面。

接下来，我们会继续投资产品、市场拓展和客户成功。如果你对这个方向感兴趣，欢迎关注我们后续的更新。
```

### GT-4 危机声明样本

- 目标：验证 skill 会把危机文本当作高风险特殊场景处理，而不是按普通公告逻辑轻轻带过
- 预期评级：`D`
- 预期红线：
  - `无明确署名负责人发声`
  - `只有“高度重视 / 正在调查”，没有具体责任、动作或后续时间点`
  - `语气像律师函，而不是像承担责任的人`
- 预期结论重点：
  - 明确指出这是典型“程序性回应”而非真正承担责任的声明
  - 明确指出 `P1/P6/P9/P10` 失分
  - 明确建议先补 `speaker / ownership / next step / internal-first`
- 失败信号：
  - 给出 `B` 或 `C`
  - 把主要问题说成“语气还可以更真诚”
  - 没提内部沟通和署名责任
- 测试输入：

```text
请用 Meservey 标准评审下面这篇危机声明。

背景：
- audience: 员工、客户、合作伙伴、媒体
- belief: 公司已经严肃处理此事，情况在控制中，后续会有可信更新
- action: 暂时不要恐慌，等待进一步更新
- channel: 官网声明 + 邮件同步

正文：
针对近期网络上流传的有关我司数据访问权限管理的讨论，公司已第一时间成立专项工作组进行全面核查。

公司始终高度重视信息安全与用户隐私保护，并已在内部启动相关流程，对有关情况展开调查。对于可能给用户和合作伙伴带来的影响，我们深表关切。

目前，相关工作正在有序推进中。公司将继续本着审慎、负责的态度，积极配合各方要求，并在适当时候同步进一步进展。

感谢社会各界的关注与监督。
```

## 回归用法

每次修改 skill 后，至少做这 4 步：

1. 用 `GT-1` 跑一次，确认好稿仍能拿到 `A`。
2. 用 `GT-2` 跑一次，确认烂稿会被明确降到 `D/F` 且点出红线。
3. 用 `GT-3` 跑一次，确认边界稿会停在 `B` 左右，并给出具体降档原因。
4. 用 `GT-4` 跑一次，确认危机声明会被按高风险文本处理，而不是温和放行。

如果有任一测试失真，优先检查：

- `P1 / P2 / P10` 的评分口径是否被冲淡
- `redlines` 是否被写得太软
- `workflow` 是否跳过了 `Preflight` 或 `Fit Check`
- `quotes / cases` 是否引入了过多“会说但不够硬”的材料

## 维护规则

- 核心层保持稳定：
  - 第一性原理
  - 十项原则
  - workflow
- 可迭代层允许更新：
  - redlines
  - case library
  - quotes
  - examples
- 新增素材优先落在 `references/`，原则上不膨胀主 `SKILL.md`
