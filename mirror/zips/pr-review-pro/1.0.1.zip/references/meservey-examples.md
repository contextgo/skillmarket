# Meservey Examples

用途：帮助模型稳定触发和稳定输出。  
定位：只放标准输入输出范例，不放长解释。

## Example 1: 危机声明评审

### Input

用户说：

`用 Meservey 标准帮我审这篇危机声明，重点看是不是太官话。`

并附上一段危机声明文本。

### Expected Behavior

- 触发 skill
- 先识别这是 `危机声明`
- 检查是否缺少 audience / belief / action / channel
- 先做红线检查
- 对 `P1/P6/P9/P10` 重点评分
- 如果没有署名负责人，要明确压低评级上限
- 默认应调用 `1` 条相关原话和 `1` 个危机类案例；如果没有调用，必须解释为什么

## Example 2: 创始人信改写

### Input

用户说：

`review this founder letter with Meservey style and rewrite the opening`

并附上英文 founder letter。

### Expected Behavior

- 触发 skill
- 输出中文诊断，保留英文引语
- 指出是否缺少真人口吻、具体故事、明确立场
- 给 opening rewrite
- 解释改写对应哪条原则
- 默认应至少引用 `1` 条 founder / go-direct 原话

## Example 3: 产品发布稿 corporate 化诊断

### Input

用户说：

`帮我看看这篇产品发布稿哪里太 corporate，给我一个 Meservey 式评分卡。`

### Expected Behavior

- 触发 skill
- 输出紧凑版 `scorecard`
- 明确指出形容词堆砌、空话、so what 缺失
- 给 Top 3 fixes，不展开完整重写骨架
- 即便是 `scorecard`，也应尽量给 `1` 条最贴切原话或说明为何没有调用

## Example 4: 多版本对比

### Input

用户说：

`下面有 3 个版本的融资公告，帮我选一个最适合做基底。`

### Expected Behavior

- 触发 skill
- 先出版本对比表
- 明确推荐一个 base version
- 然后只对推荐版本做更深入诊断
- 深入诊断阶段，仍应调用 quote / case 作为依据

## Example 5: 不应正式触发

### Input

用户说：

`Lulu Cheng Meservey 是谁？`

### Expected Behavior

- 不进入文本评审模式
- 直接按普通问答处理
- 不加载整套诊断 workflow

## Example 6: 缺少实质产出的 founder 发言

### Input

用户说：

`帮我看这篇 CEO 长帖为什么看起来很吵但没什么说服力。`

### Expected Behavior

- 触发 skill
- 识别可能存在 `ship-to-yap ratio` 失衡
- 如果文本只有情绪和观点，没有实际进展、产品、结果或明确 funnel，需在 `P2/P10` 上明显扣分
- 不能把“高频发声”本身误判为好传播
- 优先调用 `ship-to-yap ratio` 原话或 Anduril attention conversion 案例

## Example 7: 注意力没有转化

### Input

用户说：

`这次产品 campaign 很火，但我怀疑文案只是追流量，没有帮到业务。用 Meservey 标准看看。`

### Expected Behavior

- 触发 skill
- 检查 attention 是否被导向 recruiting、sales、fundraise、trust 或其他具体结果
- 如果只有 viral moment 没有转化路径，明确指出这是结构性问题
- 优先调用 attention conversion 相关案例，而不是只做抽象批评
