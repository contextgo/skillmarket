# Meservey Quotes Library

用途：输出结论时精准引用。
定位：按原则分类，每类只留高代表性短句，避免语录堆砌。

核实状态说明：
- `✓ 已核实`：可追溯到具体来源，确认为她本人原话或高度接近原话
- `⚠ 待核实`：来源指向明确但当前无法直接访问验证（Flack/X 均被网络封锁）
- `✗ 无法核实`：无法找到可靠来源，疑似释义或二次加工，禁止在评审中作为原话引用

---

## P1 Go Direct

- "Traditional PR is dead."
  来源：GO DIRECT: THE MANIFESTO / Flack + X @lulumeservey / 2024-03-19 ✓ 已核实（X 原文确认）

- "Corporate communications itself is now an oxymoron, as nothing meaningful can be communicated by a faceless committee."
  来源：GO DIRECT: THE MANIFESTO / X @lulumeservey / 2024-03-19 ✓ 已核实（X 原文确认完整句）

- "If press releases read like they were written by a baker's dozen of middle managers, that's because they were."
  来源：GO DIRECT: THE MANIFESTO / X @lulumeservey / 2024-03-19 ✓ 已核实（X 原文）
  备注：新增，旧版未收录

- "The best spokesperson for any endeavor is not the one who has the most polish, the longest tenure, or the 'right' credentials. It's the person who holds the secret knowledge upon which the enterprise is built, the person who can not only describe the idea but, in the face of inevitable opposition, fight for it and win."
  来源：GO DIRECT: THE MANIFESTO / X @lulumeservey / 2024-03-19 ✓ 已核实（X 原文确认完整句）

- "Outsourcing comms is as bad as outsourcing code."
  来源：GO DIRECT: THE MANIFESTO / X @lulumeservey / 2024-03-19 ✓ 已核实（X 原文）
  备注：新增，旧版未收录

- "Going direct means crafting and telling your own story, without being dependent on intermediaries."
  来源：GO DIRECT: THE MANIFESTO / X @lulumeservey / 2024-03-19 ✓ 已核实（X 原文）
  备注：新增，旧版未收录

- "My core idea is for the founder, the originator of the project, to speak directly to the audience without middlemen or PR filtering."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube；亦由 David Perell @david_perell 2025-04-08 转发确认 ✓ 已核实

- "The crux of it has to come directly from you speaking in the first person."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 165）

- "Even if it's mid, at least it'll be mid in your voice."
  来源：PR agencies thread / X @lulumeservey / 2025-03-15 ✓ 已核实（X 原文）
  备注：新增，旧版未收录。语境：讨论 PR agency 的写作问题

---

## P2 Vector / Ends

- "Communication is a vector, not a scalar."
  来源：Comms Foundation #1: Strategy / Flack / 2022-08-23 ⚠ 待核实（Flack 被网络封锁，来源指向明确）

- "The entire job of a comms strategy is to make those people believe those things that are going to make them make those decisions."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 477）

- "Anything that doesn't help the business succeed is wasted motion."
  来源：Comms Foundation #1 或 The 5 ingredients of a great fundraising announcement / Flack ⚠ 待核实（知识库标注来源明确，Flack 被封锁）

- "You're not owed anyone's attention."
  来源：⚠ 待核实（多处引用归于 Comms Foundation #1，无法直接验证）

---

## P3 Stories

- "Your first product is the story about your product."
  来源：GO DIRECT: THE MANIFESTO / Flack / 2024-03-19 ⚠ 待核实（知识库标注此来源，Flack 被封锁）

- "It's better for it to be bad and honest."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 211；David Perell @david_perell 2025-04-08 亦确认）

- "It's better to break the rules than to release something dead, boring, and stiff. That kind of writing won't break through."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube；David Perell @david_perell 2025-04-08 转发确认 ✓ 已核实
  备注：新增，旧版未收录

- "Emotional resonance comes through in ways that can be surprising and illogical. Emotions make us write things that aren't grammatical, sublime, or beautiful; they break writing rules."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube；David Perell @david_perell 2025-04-08 确认 ✓ 已核实
  备注：新增，旧版未收录

- "It's like finding product market fit with a message where the message is the product."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 487）
  备注：新增，旧版未收录，价值很高

---

## P5 Human Voice

- "Read it out loud — you can feel the cringe if it's corporate speak."
  来源：⚠ 待核实（概念在逐字稿中有对应表述，但此句精确措辞未在可访问来源中找到）

- "If you wouldn't say it at a dinner table, don't write it."
  来源：✗ 无法核实（网络搜索无结果，疑似释义或二次加工，不得在评审中作为原话引用）

- "It's better for it to be bad and honest."
  来源：同 P3，Learn Marketing in 80 Minutes ✓ 已核实

---

## P6 Conviction

- "If you're pleasing everybody, something is wrong."
  来源：⚠ 待核实（Persuasion Community 访谈有近似表述："if you're trying to make nobody mad, you end up making everybody mad"，措辞有差异，不确认为原话）

- "The risks of being bland, boring, or business as usual far outweigh the risk of a misstep."
  来源：⚠ 待核实（多处引用归于 GO DIRECT 或 Lenny's Newsletter，无法直接验证精确措辞）

- "There has to be a ship-to-yap ratio."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 341；David Perell X 转发亦确认）

- "Conviction beats logic."
  来源：How To Build A Cult / The Knowledge Project / 2025-09-16 ✓ 已核实

---

## P7 Foil / Tension

- "Convert FUD to fuel."
  来源：✗ 无法核实（网络搜索无结果，无可追溯来源，不得作为原话引用）

- "Current Things can't overcome conviction."
  来源：✗ 无法核实（网络搜索无结果，无可追溯来源，不得作为原话引用）

- "Either get on the bus or get the heck out of here."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 396）

- "Being surrounded by sycophancy and monoculture makes you soft. The best communicators hone their persuasion skills by constantly sparring and having to defend their positions."
  来源：X @lulumeservey / 2025-09-19 ✓ 已核实（X 原文，回应 Shane Parrish 播客）
  备注：新增，旧版未收录。语境：对 conviction 和 tension 的深层阐释

---

## P8 Message Design

- "The message is the highest leverage thing to get right."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 480）

- "It should be so simple that a five year old can say it back to you."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 519）

- "It was the memes."
  来源：How to go viral: Barbie's billion dollar meme machine / Flack / 2023-08-09 ✓ 已核实

- "In order of how much it matters: the hook is first, then how you tell your story, and finally where you tell it."
  来源：How To Build A Cult / The Knowledge Project / 2025-09-16 ✓ 已核实

- "You have to say it in a lot of different ways and a lot of different places and over time it has to feel omnipresent and inevitable."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 513）
  备注：新增，旧版未收录

- "To increase your pressure, reduce your surface area. If you're trying to puncture a board with the same amount of force, slapping it with both hands won't work as well as driving a nail into it."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube；David Perell @david_perell 2025-04-08 确认 ✓ 已核实
  备注：新增，旧版未收录。这是她的物理学比喻：进攻时集中力量，防守时分散表面积

---

## P9 Inner Circle

- "An external crisis is inconvenient, but an internal crisis is existential."
  来源：⚠ 待核实（The art of the apology 或 80 分钟访谈相关段落，Flack 被封锁）

- "If you're going to get one thing right, let it be the apology."
  来源：The art of the apology / Flack / 2022-12-29 ⚠ 待核实（来源指向明确，但当前未直接完成原文核对）

- "People remember 2-3 things about you. Don't let them be random."
  来源：How To Build A Cult / The Knowledge Project / 2025-09-16 ✓ 已核实

---

## Late-stage Upgrades（2025-2026 新观点）

- "Resistance is escalation."
  来源：When someone says they hate your product with a burning passion / Flack / 2025-12-29 ⚠ 待核实（来源指向明确，但当前未直接完成原文核对）

- "Everything is fake now."
  来源：Standing Out / X @lulumeservey Article / 2026-01-05 ✓ 已核实（X 原文确认）
  备注：注意：旧版写的是"It's 2026 and everything is fake"，为不精确改写，正确原话是"Everything is fake now."

- "The real has never been more precious, refreshing, special, rare."
  来源：Standing Out / X @lulumeservey Article / 2026-01-05 ✓ 已核实（X 原文确认完整句）
  备注：旧版只收录了前半句，已补全

- "In 2026, narrative alpha will come from doing real things."
  来源：Standing Out / X @lulumeservey Article / 2026-01-05 ✓ 已核实（X 原文）
  备注：新增，旧版未收录

- "Real narratives take 6, 12, 18 months to build. They require sustained effort and consistency — and patience! There are no shortcuts, but it's worth it."
  来源：Standing Out / X @lulumeservey Article / 2026-01-05 ✓ 已核实（X 原文）
  备注：新增，旧版未收录

- "AI cannot have conviction."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 551）

- "When you talk about something from your personal experience, you are creating a monopoly."
  来源：Learn Marketing in 80 Minutes / David Perell YouTube ✓ 已核实（逐字稿 line 569）

---

## 核实摘要

| 状态 | 数量 | 说明 |
|---|---|---|
| ✓ 已核实 | 28 条 | 可安全引用（含 X 原文核实 8 条新增）|
| ⚠ 待核实 | 8 条 | 来源明确但未直接核对，谨慎引用，标注出处 |
| ✗ 无法核实 | 3 条 | 禁止作为原话引用（"dinner table" / "Convert FUD" / "Current Things"） |

主要更新（本轮通过 Chrome 读取 X 原文新增确认）：
- GO DIRECT MANIFESTO 全文原话：5 条新增核实
- Standing Out 全文：修正 "It's 2026 and everything is fake"（原话是 "Everything is fake now."）；新增 3 条
- David Perell 转发 zingers：2 条新增核实
- PR agencies 长推：1 条新增核实（"Even if it's mid, at least it'll be mid in your voice."）

---

## 使用规则

- 每次输出最多引用 `1-2` 句。
- 只引用与当前问题强相关的句子。
- `✗ 无法核实` 的条目绝对不得作为原话引用，可作为"Inference"类表述。
- `⚠ 待核实` 的条目引用时，优先标注来源方向，不宜用引号强调"原话"。
