# Meservey Core Originals

用途：仅当用户明确追问"她原文怎么说"或需要溯源时调用。
定位：核心一手来源索引，不在日常评审时全文展开。

访问状态说明：
- `可访问`：已验证当前环境可直接访问
- `抓取不稳定`：当前环境下可搜索到或间接访问，但直接抓取不稳定，不宜下绝对判断
- `本地可用`：已有工作级转录底稿

---

## 一、核心文章（Flack）

> 注意：getflack.com 在当前环境下抓取不稳定。不要默认视为“完全不可访问”，但做原话核实时应保持保守。

- `Comms Foundation #1: Strategy`
  - 日期：2022-08-23
  - URL：https://www.getflack.com/p/comms-foundation-1-strategy
  - 核心内容：Ends/Ways/Means 框架，comms equation，business objective 倒推
  - 可引用原话来源：`P2 Vector`、`P10 Start With the Ends`

- `Comms Foundation #2: Tactics`
  - 日期：2022-09-08
  - URL：https://www.getflack.com/p/tactics
  - 核心内容：comms equation 母式，战术选择逻辑

- `Press so bad it's good`
  - 日期：2022-08-10
  - URL：https://www.getflack.com/p/hit-pieces
  - 核心内容：Substack vs Wired 打击事件；hit piece / deterrence / home turf 反击逻辑
  - 对应原则：`P6` `P7` `P9`

- `Build your fanbase using the K-pop method`
  - 日期：2022-09-29
  - URL：https://www.getflack.com/p/fandom
  - 核心内容：movement building，fandom，identity，内圈扩散

- `The art of the apology`
  - 日期：2022-12-29
  - URL：https://www.getflack.com/p/apologizing
  - 核心内容：危机道歉三要素，Say the actual words，Take responsibility specifically
  - 可引用原话来源：`P1`、`P6`、`P9`

- `Flack's crisis communications playbook`
  - 日期：2023-03-14
  - URL：https://www.getflack.com/p/crisis-comms-playbook
  - 核心内容："Don't get ready, stay ready"；危机准备与流程

- `The 5 ingredients of a great fundraising announcement`
  - 日期：2023-08-23
  - URL：https://www.getflack.com/p/nail-your-fundraising-announcement
  - 核心内容：objectives / audience / message / execution / validation；"Publicity for its own sake is wasted motion"
  - 对应原则：`P2` `P4` `P10`

- `How to go viral: Barbie's billion dollar meme machine`
  - 日期：2023-08-09
  - URL：https://www.getflack.com/p/how-barbie-went-viral
  - 核心内容：meme 系统，surround-sound buzz，病毒传播机制
  - 可引用原话来源：`P7` `P8`（"It was the memes."）

- `"Please just take the checkmark away!" How Twitter devalued a status symbol`
  - 日期：2023-04-06
  - URL：https://www.getflack.com/p/please-just-take-the-checkmark-away
  - 核心内容：status signaling，稀缺性，符号系统设计

- `GO DIRECT: THE MANIFESTO`
  - 日期：2024-03-19
  - URL：https://www.getflack.com/p/go-direct-the-manifesto
  - 核心内容：她最核心的旗帜性文本；"Traditional PR is dead"、"Corporate communications is an oxymoron"、"The best spokesperson is the person who holds the secret knowledge"
  - 可引用原话来源：`P1`（多条已核实原话）

- `Should you hire a PR agency?`
  - 日期：2025-03-14
  - URL：https://www.getflack.com/p/should-you-hire-a-pr-agency
  - 核心内容：agency vs in-house vs founder-led 边界判断

- `How to Win the AI Talent War`
  - 日期：2025-07-30
  - URL：https://www.getflack.com/p/how-to-win-the-ai-talent-war
  - 核心内容：人才吸引作为传播战争；mission、momentum、belief 驱动顶级 AI 人才

- `The DOD Rebrand`
  - 日期：2025-09-05
  - URL：https://www.getflack.com/p/palmer-dept-of-war
  - 核心内容：Palmer / Anduril 的 narrative engineering；slogan-driven agenda setting

- `When someone says they hate your product with a burning passion`
  - 日期：2025-12-29
  - URL：https://www.getflack.com/p/responding-to-negative-feedback
  - 核心内容："Resistance is escalation"；reputation thermostat / set point 框架

- `Kevin Spacey vs The Telegraph`
  - 日期：2025-11-25
  - URL：https://www.getflack.com/p/this-is-how-you-correct-a-bad-headline
  - 核心内容：坏标题纠偏；地位关系翻转；局部事实纠正策略

- `Standing Out`
  - 日期：2026-01-05
  - URL：https://www.getflack.com/p/standing-out
  - 核心内容："It's 2026 and everything is fake"；real / taste / craftsmanship / zero tolerance for slop；narrative alpha 概念

---

## 二、核心访谈（S+ 级，内容最密集）

- `Learn Marketing in 80 Minutes`
  - 来源：David Perell YouTube
  - 日期：2024 前后（官方 URL 待补）
  - 本地工作底稿：已有完整中英对照逐字稿 ✓ 本地可用
  - 核心内容：Go Direct 完整阐释、ship-to-yap ratio、message/medium/messenger、message-market fit、attention conversion（Anduril case）、AI 时代如何脱颖而出
  - 已核实原话数量：12 条（见 quotes-library ✓ 标注条目）
  - 备注：目前所有 ✓ 已核实原话中，此来源贡献最多

- `Inside Anduril's Comms Strategy: 10 Rules for Mission-Driven Founders`
  - 来源：Pirate Wires（文章+播客）
  - 日期：2024-02-07
  - URL：https://www.piratewires.com/p/anduril-comms-strategy-early-days（抓取不稳定）
  - Spotify 播客：https://open.spotify.com/episode/3leP3AND2rl5Fc1lyRuoJQ
  - 核心内容：Anduril 10条传播规则；mission-driven founder comms 最强实战案例

---

## 三、重要补充访谈（S/A 级）

- `Going Direct: What Founders can learn from K-Pop, Crypto, and the Early Christians`
  - 来源：Infinite Loops EP.133
  - 日期：2022-11-17
  - URL：https://www.infiniteloopspodcast.com/lulu-cheng-meservey-going-direct-what-founders-can-learn-from-k-pop-crypto-and-the-early-christians-ep133/
  - 核心内容：insurgent comms、underdog 传播、movement 三步骤

- `Navigating comms and PR`
  - 来源：Lenny's Newsletter / Podcast
  - 日期：2023-03-23
  - URL：https://www.lennysnewsletter.com/p/navigating-comms-and-pr-lulu-cheng（抓取不稳定）
  - 核心内容：concentric circles（同心圆传播）、cultural erogenous zones、physics-based framework

- `PR lessons from K-Pop, Jesus, Substack, and Internet Haters`
  - 来源：How I Write / David Perell
  - 日期：2023-09-06
  - URL：https://dexa.ai/howiwrite/d/e2b99dc0-7ed2-11ee-8f3a-a76175c676fb

- `Secrets of Reality Distortion Fields`
  - 来源：Garry Tan YouTube / Glasp transcript mirror
  - URL：https://glasp.co/youtube/Z1vqzWfC_sA（抓取不稳定）
  - 核心内容：foil、部落选择、reality distortion 叙事

- `Transforming Company Narrative`
  - 来源：Invest Like the Best
  - 日期：2024-09-24
  - URL：https://joincolossus.com/episode/transforming-company-narrative/（抓取不稳定）
  - 核心内容：narrative、launch、fundraising、crisis、partner selection

- `Lulu Cheng Meservey: Go Direct`
  - 来源：Generative Now
  - 日期：2024-10-31
  - URL：https://podcasts.apple.com/us/podcast/lulu-cheng-meservey-go-direct/id1709773028?i=1000675185267

- `How To Build A Cult`
  - 来源：The Knowledge Project / Shane Parrish
  - 日期：2025-09-16
  - URL：https://fs.blog/knowledge-project-podcast/lulu-cheng-meservey/（抓取不稳定）
  - Spotify 可访问：https://open.spotify.com/episode/3iWfm8IrzOuV0iJQOB7RAw
  - 核心内容：conviction beats logic、hook/story/where 优先级、people remember 2-3 things、trust building、PR attack 处理
  - 已核实原话：3 条（见 quotes-library ✓ 标注）

- `The New Rules of Founder Comms (Encore)`
  - 来源：Generative Now
  - 日期：2025-03-27
  - URL：https://podcasts.apple.com/us/podcast/lulu-cheng-meservey-the-new-rules-of-founder-comms-encore/id1709773028?i=1000701040985

- `Uncapped #25 | Lulu Cheng Meservey`
  - 来源：Uncapped with Jack Altman
  - 日期：2025-09-24
  - URL：https://podcasts.apple.com/sg/podcast/uncapped-25-lulu-cheng-meservey/id1801867202?i=1000728194692
  - 核心内容：story arcs、reputational set point、word choice、recruiting

- `Lulu Meservey on How Media Has Changed`
  - 来源：The Good Fight / Persuasion Community
  - 日期：2025-10
  - URL：https://www.persuasion.community/p/lulu-meservey（抓取不稳定）
  - 核心内容：传统传播手册失效；"if you're trying to make nobody mad, you end up making everybody mad"（近似 P6 表述）

---

## 四、当前数据可信度快照

| 类别 | 数量 | 说明 |
|---|---|---|
| Flack 文章（抓取不稳定） | 16 篇 | 来源指向明确，但原话核实时必须保守，不应只靠二手知识库断言 |
| 本地可用逐字稿 | 1 份 | 80 分钟 David Perell 访谈，最高密度已核实来源 |
| 可访问播客页面 | 部分 | Apple Podcasts 目录页可访问，但通常无逐字稿 |
| X/Twitter | 抓取不稳定 | @lulumeservey 账号已确认，但当前环境下不适合把 X 内容当稳定自动源 |

---

## 使用规则

- 日常评审不展开全文。
- 只有用户要求原文依据、出处核查、或要做 skill 校准时再用。
- 用户如需核查 Flack 文章，请直接在浏览器打开对应 URL。
