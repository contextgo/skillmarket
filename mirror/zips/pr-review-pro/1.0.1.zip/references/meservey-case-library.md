# Meservey Case Library

用途：写诊断时按场景匹配 1-2 个案例作支撑。  
定位：只保留“案例标签 + 核心动作 + 她的判断 + 对应原则”，不堆长篇复述。

## 案例卡

### 动视暴雪危机与内部信任

- 案例标签：`internal-comms` `crisis` `leadership`
- 核心动作：把内部信任和领导者直接发声放在极高优先级。
- Meservey 式判断：外部危机只是麻烦，内部危机才可能伤及根本。
- 来源：待核实
- 对应原则：`P1` `P9`

### FTX 媒体打法

- 案例标签：`media-playbook` `founder-comms` `case-analysis`
- 核心动作：她把 FTX 当作媒体操作能力很强、但实质严重错误的反面样本。
- Meservey 式判断：会讲故事不等于值得信任，传播放大的是已有叙事，不会替代真实基本面。
- 来源：待核实
- 对应原则：`P2` `P7` `P10`

### Twitter Blue / 蓝标

- 案例标签：`status` `signaling` `product-narrative`
- 核心动作：分析一个符号系统如何因错误设计而失去地位价值。
- Meservey 式判断：传播不是抽象词藻，而是 status、稀缺性、身份信号的实际管理。
- 来源："Please just take the checkmark away!" How Twitter devalued a status symbol / 2023-04-06
- 对应原则：`P3` `P7`

### Barbie 病毒式传播

- 案例标签：`virality` `meme` `culture`
- 核心动作：把电影营销做成文化事件与 meme 机器。
- Meservey 式判断：高传播不是靠“多发内容”，而是靠可参与、可复述、可表态的叙事系统。
- 来源：How to go viral: Barbie’s billion dollar meme machine / 2023-08-09
- 对应原则：`P7` `P8`

### Ramp 融资公告

- 案例标签：`fundraising` `announcement`
- 核心动作：把融资新闻写成更大的业务与市场叙事。
- Meservey 式判断：融资公告不是“我们又融资了”，而是借新闻强化为什么这家公司值得被相信。
- 来源：待核实
- 对应原则：`P2` `P4` `P10`

### 负反馈与信誉温控器

- 案例标签：`negative-feedback` `reputation`
- 核心动作：把公众反馈理解为一种 reputational thermostat。
- Meservey 式判断：当外界认为你声誉高于应得水平时，硬顶往往会升级冲突。
- 来源：When someone says they hate your product with a burning passion / 2025-12-29
- 对应原则：`P6` `P10`

### AI 人才竞争

- 案例标签：`recruiting` `mission` `belief`
- 核心动作：把人才竞争写成使命、历史感、胜利预期的竞争。
- Meservey 式判断：顶级人才要被“值得加入的叙事”吸引，而不只是被薪资吸引。
- 来源：How to Win the AI Talent War / 2025-07-30
- 对应原则：`P2` `P7` `P10`

### Anduril “Don't Work at Anduril”

- 案例标签：`attention-conversion` `recruiting` `campaign`
- 核心动作：不是做一个单次 viral video，而是配套网站、设计、传播与招聘 funnel，把 attention 变成 recruiting inbound。
- Meservey 式判断：真正懂传播的人不会停留在“我们拿到注意力了”，而是会把 attention 转成 hires、money、sales 或 investor interest。
- 来源：待核实
- 对应原则：`P2` `P8` `P10`

### Anduril / Palmer “Department of War”

- 案例标签：`offense` `agenda-setting` `palmer`
- 核心动作：用强 slogan 和多年铺垫，把本来边缘化的主张推进公共议程。
- Meservey 式判断：如果目标足够清楚、表达足够锋利、执行足够持久，传播可以先于共识到来。
- 来源：The DOD Rebrand / 2025-09-05
- 对应原则：`P6` `P7` `P8`

### Substack vs Wired 更正战

- 案例标签：`hit-piece` `deterrence` `substack`
- 核心动作：公开反击一篇她认定 bad faith 的报道，不以 correction 为唯一目标，而是以员工 resolve、supporter activation 和 deterrence 为目标。
- Meservey 式判断：面对越界攻击，最优结果不只是“媒体改了”，而是外界知道你不是软柿子。
- 来源：Press so bad it's good / 2022-08-10
- 对应原则：`P6` `P7` `P9`

### Activision Blizzard perception gap

- 案例标签：`narrative-reset` `activision` `reputation`
- 核心动作：明确点出公司存在 perception 与 reality 的 gap，并把沟通任务定义为分享 true story。
- Meservey 式判断：高争议公司需要的不是表面灭火，而是系统性的 narrative reset。
- 来源：Activision Blizzard Board Member Lulu Cheng Meservey Joins Executive Leadership Team / 2022-10-06
- 对应原则：`P1` `P2` `P10`

### Message / Medium / Messenger

- 案例标签：`framework` `message-market-fit`
- 核心动作：先定义业务目标，再定义受众要相信什么，然后才去匹配 message、messenger 与 medium。
- Meservey 式判断：如果 message 不对，再好的媒介与信使都是浪费。
- 来源：待核实
- 对应原则：`P2` `P8` `P10`

### 道歉优先级

- 案例标签：`crisis` `apology` `ownership`
- 核心动作：把“道歉”视为危机文里最不能搞砸的部分，并要求由承担责任的人说人话。
- Meservey 式判断：如果危机文本只有流程语言和律师腔，再完整的背景说明也救不回来。
- 来源：The art of the apology / 2022-12-29
- 对应原则：`P1` `P6` `P9`

### K-pop fanbase 方法

- 案例标签：`fandom` `movement` `identity`
- 核心动作：把受众从被动 followers 变成愿意自我认同、愿意传播、愿意站队的 fanbase。
- Meservey 式判断：真正强的传播不是“被看到”，而是让别人愿意把支持你当成自己身份的一部分。
- 来源：待核实
- 对应原则：`P2` `P7` `P8`

### 融资公告五要素

- 案例标签：`fundraising` `announcement` `validation`
- 核心动作：围绕 objectives、audience、message、execution、validation 设计 announcement，而不是只写“我们宣布融资”。
- Meservey 式判断：融资稿既要服务新闻本身，也要服务更大的公司叙事和信任建构。
- 来源：The 5 ingredients of a great fundraising announcement / 2023-08-23
- 对应原则：`P2` `P4` `P10`

### Substack 同心圆传播

- 案例标签：`audience-layering` `distribution` `substack`
- 核心动作：先识别最关键的内圈，再利用同心圆式扩散让信息逐层向外传播。
- Meservey 式判断：传播失败往往不是内容不够多，而是没搞清楚第一圈该是谁。
- 来源：待核实
- 对应原则：`P2` `P8` `P9`

### Hook / Story / Where

- 案例标签：`hook` `distribution` `story-structure`
- 核心动作：先磨 hook，再磨 story，再决定在哪里讲。
- Meservey 式判断：很多团队把“发在哪”看得太重，但真正的杠杆常常在标题、开场和 story shape。
- 来源：How To Build A Cult / 2025-09-16
- 对应原则：`P3` `P5` `P8`

### 进攻型传播

- 案例标签：`offense` `underdog` `agency`
- 核心动作：不要只是等事情发生在自己身上，而要主动制造 narrative 先手。
- Meservey 式判断：在高阻力环境里，过度防守会让你永久落后一步。
- 来源：Going Direct: What Founders can learn from K-Pop, Crypto, and the Early Christians / 2022-11-17
- 对应原则：`P6` `P7` `P10`

### 坏标题纠偏

- 案例标签：`headline-correction` `status-reversal`
- 核心动作：纠 bad headline 时，不只是做事实修补，而是先翻转 framing 和地位关系。
- Meservey 式判断：你不该在低位、慌张、羞耻的位置上请求媒体改标题。
- 来源：Kevin Spacey vs The Telegraph / 2025-11-25
- 对应原则：`P5` `P6` `P8`

## 使用规则

- 每次正式评审，最多引用 `1-2` 个最贴切案例。
- 不要为了显得懂而硬塞案例。
- 案例只用于支撑判断，不替代对当前文本的逐句分析。
