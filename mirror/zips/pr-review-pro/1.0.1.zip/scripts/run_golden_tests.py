#!/usr/bin/env python3
"""Meservey golden test harness.

Usage:
  python scripts/run_golden_tests.py list
  python scripts/run_golden_tests.py emit --id GT-1
  python scripts/run_golden_tests.py emit --all --out-dir /tmp/meservey-tests
  python scripts/run_golden_tests.py check --id GT-1 --result-file /path/to/result.md
  python scripts/run_golden_tests.py check --results-dir /path/to/results
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FIXTURE_PATH = ROOT / "references" / "meservey-golden-tests.json"


def load_fixtures() -> list[dict]:
    data = json.loads(FIXTURE_PATH.read_text())
    return data["tests"]


def find_test(test_id: str) -> dict:
    for test in load_fixtures():
        if test["id"] == test_id:
            return test
    raise SystemExit(f"Unknown test id: {test_id}")


def extract_grade(text: str) -> str | None:
    patterns = [
        r"最终评级[：:\s`]*([ABCDF])",
        r"评级[：:\s`]*([ABCDF])",
        r"\b([ABCDF])\b"
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return match.group(1).upper()
    return None


def score_result(test: dict, text: str) -> tuple[bool, list[str]]:
    notes: list[str] = []
    ok = True

    grade = extract_grade(text)
    if grade is None:
        ok = False
        notes.append("未识别到评级字母。")
    elif grade not in test["expected_grade"]:
        ok = False
        notes.append(
            f"评级不匹配：期望 {test['expected_grade']}，实际 {grade}。"
        )
    else:
        notes.append(f"评级匹配：{grade}")

    lowered = text.lower()
    for keyword in test["expected_keywords"]:
        if keyword.lower() not in lowered:
            ok = False
            notes.append(f"缺少预期关键词：{keyword}")

    for principle in test["expected_principles"]:
        if principle.lower() not in lowered:
            ok = False
            notes.append(f"缺少预期原则：{principle}")

    for keyword in test["forbidden_keywords"]:
        if keyword.lower() in lowered:
            ok = False
            notes.append(f"出现禁用关键词：{keyword}")

    return ok, notes


def emit_test(test: dict) -> str:
    expected = ", ".join(test["expected_grade"])
    lines = [
        f"# {test['id']} {test['name']}",
        "",
        f"- 预期评级：{expected}",
        f"- 预期原则：{', '.join(test['expected_principles'])}",
        f"- 预期关键词：{', '.join(test['expected_keywords'])}",
    ]
    if test["forbidden_keywords"]:
        lines.append(f"- 禁用关键词：{', '.join(test['forbidden_keywords'])}")
    lines.extend(["", "## Prompt", "", test["prompt"], ""])
    return "\n".join(lines)


def cmd_list() -> int:
    for test in load_fixtures():
        print(f"{test['id']}: {test['name']} -> expected {','.join(test['expected_grade'])}")
    return 0


def cmd_emit(test_id: str | None, emit_all: bool, out_dir: Path | None) -> int:
    tests = load_fixtures() if emit_all else [find_test(test_id or "")]
    if out_dir:
        out_dir.mkdir(parents=True, exist_ok=True)
        for test in tests:
            path = out_dir / f"{test['id']}.md"
            path.write_text(emit_test(test))
            print(f"Wrote {path}")
        return 0
    for idx, test in enumerate(tests):
        if idx:
            print("\n" + "=" * 80 + "\n")
        print(emit_test(test))
    return 0


def check_one(test: dict, result_file: Path) -> tuple[bool, list[str]]:
    if not result_file.exists():
        return False, [f"结果文件不存在：{result_file}"]
    return score_result(test, result_file.read_text())


def cmd_check(test_id: str | None, results_dir: Path | None, result_file: Path | None) -> int:
    failures = 0
    tests = load_fixtures() if results_dir else [find_test(test_id or "")]
    for test in tests:
        path = result_file if result_file else results_dir / f"{test['id']}.md"
        ok, notes = check_one(test, path)
        status = "PASS" if ok else "FAIL"
        print(f"[{status}] {test['id']} -> {path}")
        for note in notes:
            print(f"  - {note}")
        if not ok:
            failures += 1
    return 1 if failures else 0


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list")

    emit = sub.add_parser("emit")
    emit.add_argument("--id")
    emit.add_argument("--all", action="store_true")
    emit.add_argument("--out-dir", type=Path)

    check = sub.add_parser("check")
    check.add_argument("--id")
    check.add_argument("--result-file", type=Path)
    check.add_argument("--results-dir", type=Path)

    args = parser.parse_args()
    if args.cmd == "list":
        return cmd_list()
    if args.cmd == "emit":
        if not args.all and not args.id:
            raise SystemExit("emit requires --id or --all")
        return cmd_emit(args.id, args.all, args.out_dir)
    if args.cmd == "check":
        if not args.results_dir and not (args.id and args.result_file):
            raise SystemExit("check requires --results-dir or both --id and --result-file")
        return cmd_check(args.id, args.results_dir, args.result_file)
    return 0


if __name__ == "__main__":
    sys.exit(main())
