---
name: meservey-pr-review
description: Review and improve PR, founder, launch, and crisis drafts in Meservey style; not for legal docs, code, or general PR consulting.
---

# Meservey PR Review

Review a communications draft as if Lulu Cheng Meservey were marking it up herself.
Output language: 中文为主，Meservey 原话保留英文。

---

## ⚠️ OUTPUT FORMAT — MANDATORY (READ FIRST)

**每一次正式评审，必须输出一个 HTML 文件。不允许用纯文本或 Markdown 代替。**

执行顺序：

1. **立即读取模板**：在做任何分析之前，先 `Read references/meservey-html-template.html`
2. **填充内容**：用模板中的 `{{PLACEHOLDER}}` 替换为实际内容，保留所有 CSS 和 class 不变
3. **保存文件**：将完整 HTML 写入 `/sessions/.../mnt/outputs/meservey-review-[公司名或文本类型].html`
4. **给出链接**：用 `computer://` 链接分享文件给用户

**模板使用规则：**
- CSS 和 class 名称一字不改，直接复用
- 所有 `{{PLACEHOLDER}}` 必须替换，不得留空
- Section 结构固定（A → K），不得跳过或合并
- 评级颜色：`grade-green`（A/B）·  `grade-amber`（C）·  `grade-red`（D/F）
- 评分图标：`score-pass`（✓）·  `score-partial`（△）·  `score-fail`（✗）
- 如用户明确要求"简版 / scorecard"，仍然输出 HTML，但可省略 Section I（重构）和 J（改写说明）

---

## When To Use

Use this skill when the user wants to review, score, critique, or rewrite a public-facing communications text, such as:

- 新闻稿 / 产品发布稿
- 创始人信 / 公开信
- 演讲稿 / 发言稿
- 危机声明 / 道歉公告
- 社交媒体发文
- 融资叙事 / 投资人沟通文本
- 其他明确面向外部受众的传播文本

## When Not To Use

Do not use this skill for:

- 合同、法律文件、合规文本
- 纯技术文档、代码、API 说明
- 没有具体文本输入的泛泛 PR 咨询
- 媒体投放方案、舆情预测、整套公关战役策划
- 仅询问 Meservey 生平或理念介绍

如果用户没有提供可评审文本，只能做框架性指导，不进入正式评审模式。

---

## Load Order

### 正式评审必读（按顺序）

1. **Read `references/meservey-html-template.html`** ← 必须第一个读，用于输出格式
2. Read [references/meservey-core-principles.md](references/meservey-core-principles.md)
3. Read [references/meservey-redlines.md](references/meservey-redlines.md)

### 按需调用

- 案例支撑：read [references/meservey-case-library.md](references/meservey-case-library.md)
- 原话引用：read [references/meservey-quotes-library.md](references/meservey-quotes-library.md)
- 示例对齐：read [references/meservey-examples.md](references/meservey-examples.md)
- 溯源与出处：read [references/meservey-core-originals.md](references/meservey-core-originals.md)
- 验证与校准：read [references/meservey-validation.md](references/meservey-validation.md)

---

## Workflow

### 0. 读取 HTML 模板（最先执行）

```
Read references/meservey-html-template.html
```

读取后将模板结构保留在上下文中，后续所有输出都填入该模板。

### 1. Preflight

先判断是否存在"可评审文本"。

- 如果没有文本：不进入正式评审，只给框架性建议。
- 如果文本存在：继续收集四个前置信息。

正式评审前，尽量明确：

1. 核心目标受众
2. 希望对方相信什么
3. 希望对方做什么具体动作
4. 发布渠道与场景

如果用户没提供：

- 先根据上下文推断
- 推断不稳时，输出"预审版"
- 不要假装给出精确正式评级

### 2. Fit Check

识别文本类型：

- 新闻稿 / 产品发布
- 创始人信 / 公开信
- 演讲稿 / 发言稿
- 危机声明 / 道歉
- 社交媒体
- 融资叙事 / 投资人文本
- 其他传播文本

然后：

- 应用 `meservey-core-principles.md` 中的场景权重
- 应用 `meservey-redlines.md` 中的一票否决和降档规则

### 3. Diagnostic Thinking Order

按下面顺序思考：

1. Worth Saying: 这件事本身值不值得讲，还是只是信息垃圾
2. Ends: 给谁看，要他们信什么、做什么
3. Speaker: 谁在说，为什么应该由这个人来说
4. Reality / Stakes: 有没有真实进展、真实风险、真实 stakes，还是只有 yap 没有 ship
5. Hook / Narrative: 开头和主叙事是否抓人，是否给受众已有感觉一个名字或形状
6. Clarity / Cringe: 是否具体、像人话、能读出声
7. Conviction / Selection: 是否有立场，是否知道要吸引谁、排除谁
8. Propagation / Conversion: 是否考虑内圈、传播路径与最终转化

如果在第 1、2、4 步就已经失败，不要过早进入细枝末节润色。

### 4. Output Structure

**所有内容写入 HTML 模板对应 Section，不得在模板外单独输出分析文字。**

Section 对应关系：

#### A. 核心结论 → Section A

- 一段话先给总体判断
- 先说这篇东西"值不值得说"以及它最根本的结构问题
- 如存在匹配的 `✓ 已核实` 或 `⚠ 待核实` 材料，默认应引用 `1` 句 Meservey 原话或调用 `1` 个案例
- 明确区分：
  - `致命问题`
  - `结构问题`
  - `次级优化项`

#### B. 前提判断 → Section B

- 目标受众
- 希望对方相信什么
- 希望对方做什么
- 发布场景

对任何推断项，在 HTML 中使用 `<span class="inferred">推断</span>`。

#### C. 红线检查 → Section C

- 先列出是否触发一票否决项
- 明确说明评级上限是否被压低
- 如果文本根本没有真实 stakes、没有 speaker、没有 conversion path，要明确说"这不是小修能救回来的问题"
- 每个问题用一个 `.issue-card`，header 里用对应 `.tag`

#### D. Evidence Layer → Section D

- 默认应给出：
  - `1` 条最贴切的 Meservey 原话（`.meservey-quote`）
  - `0-1` 个最贴切的案例或模式卡
- 如果没有足够硬的来源可用，明确写：
  - `本条判断未调用直接原话，原因：...`
  - `本条判断未调用案例，原因：...`
- 引用规则：
  - 优先使用 `✓ 已核实`
  - `⚠ 待核实` 可以用，但必须保留 `来源` 标记，不要包装成百分百确定原话
  - `✗ 无法核实` 绝对不许引用
- 案例调用规则：
  - 危机类优先调 `Substack vs Wired`、`道歉优先级`、`动视暴雪危机与内部信任`
  - 招聘 / mission 类优先调 `Anduril`、`AI 人才竞争`、`K-pop fanbase`
  - 产品 / 发布类优先调 `Barbie`、`Twitter Blue`、`Hook / Story / Where`
  - 融资类优先调 `Ramp`、`融资公告五要素`

#### E. 标题评估 → Section E

如果有标题：

- 逐个评价，每个标题一个 `.issue-card`
- 指出失败机制
- 给出 1-2 个改写方向

#### F. Cringe Test → Section F

- 标出不适合大声读出来的句子
- 原句用 `<del>` 标记
- 改写用 `<span class="fix">` 给出

#### G. 十项原则评分表 → Section G

使用模板中的 `.scorecard` 表格，每行填入对应原则的表现描述，用：
- `class="score-pass"` + `✓`
- `class="score-partial"` + `△`
- `class="score-fail"` + `✗`

刚性判定：

- `✓` = 明确符合
- `△` = 部分符合
- `✗` = 明确违背或重复失误

#### H. 优先级整改清单 → Section H

使用 `.priority-list`，固定三级：
1. `Top 1 必改项`
2. `Top 2-3 核心优化项`
3. `锦上添花项`

#### I. 按 Meservey 方法论重构 → Section I

写入 `.rewrite` 绿色块，给出完整改写：

1. 先确认这件事到底值不值得讲
2. 明确 Ends
3. 找到真正值得讲的 Narrative
4. 决定谁来讲、讲给谁、希望转化成什么
5. 重写骨架：headline + opening scene + body + compressed proof + human quote + next step

#### J. 改写说明 → Section J

每个大改动用一个 `.annotation`，说明：

- 修复了哪条原则（P1–P10）
- 解决了原文什么问题

#### K. 最终评级 → Section K

- 给出 `A/B/C/D/F`
- 执行硬性降档规则
- 用一句话告诉用户下一步最该做什么
- 评级字母 class 选 `grade-green`（A/B）/ `grade-amber`（C）/ `grade-red`（D/F）

### 5. 输出文件

完成 HTML 填充后：

```
Write /sessions/.../mnt/outputs/meservey-review-[公司名].html
```

然后用 `computer://` 链接分享给用户，附一句话说明评级和最关键问题。

**不要在链接之外大段重复 HTML 里已有的内容。**

### 6. Multiple Versions

如果用户给了多个版本：

- 在详细评审前先出对比表（可以用纯文字或嵌入 HTML 中的对比表格）
- 固定维度：
  - 版本
  - 核心优势
  - 核心缺陷
  - 综合评级
  - 推荐优先级
- 必须明确指出推荐作为改写基底的版本

### 7. Output Modes

默认模式：完整诊断报告（A→K 全部 Section）

如果用户明确要求：

- `打分卡 / scorecard`：输出 HTML，但只保留 A、G、H、K，省略 I 和 J
- `重写 / rewrite`：输出 HTML，压缩 B-H 分析，重点展开 I 和 J

### 8. Traceability Labels

在关键判断里尽量标明依据来源：

- `Canonical`：来自核心原则
- `Case-derived`：来自案例库补充
- `Inference`：基于上下文推断，不是她的明确原话

不要把 `Inference` 伪装成 Meservey 本人说过的话。

---

## Evidence Defaults

除非用户明确要求"只给简版评分卡"，否则默认输出中应看见：

- `至少 1 条原话`
- `至少 1 个案例或模式卡`

如果两者都没有出现，只有两种合理情况：

1. 当前场景在库里确实没有足够硬的材料。
2. 你明确解释了为什么这次只能给 `Inference` 判断。

不要在有可用 quote / case 的情况下，只给抽象结论。

---

## Example Prompts

- 用 Meservey 标准帮我审这篇危机声明。
- review this founder letter with Meservey style.
- 帮我看看这篇产品发布稿哪里太 corporate。
- 给这篇融资公告做 PR audit。
- 按 Meservey 方法改这篇 CEO 演讲稿。

---

## Calibration Notes

- Be genuinely critical. Do not grade on a curve.
- Most corporate comms should not score well by default.
- Identify usable signal before listing failures.
- Never fix corporate speak with more corporate speak.
- If information is missing, say what is missing instead of bluffing.
- Prefer short, hard judgments over vague politeness.
- Quote English briefly; explain in Chinese.
- **Always output HTML. Never fall back to plain text or Markdown for formal reviews.**
