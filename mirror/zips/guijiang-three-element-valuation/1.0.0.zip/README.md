# guijiang-three-element-valuation

基于布鲁斯·格林沃尔德《价值投资（第2版）》与归江价值投资思路的“三要素估值”技能。

## 适用场景

- 单家公司内在价值评估
- 资产价值、EPV、成长价值分离式分析
- 安全边际与击球区测算
- 需要生成 HTML 报告并邮件发送的估值任务

## 文件结构

```text
guijiang-three-element-valuation/
├── SKILL.md
├── README.md
├── references/
│   ├── framework.md
│   └── data-sourcing-and-assumptions.md
├── scripts/
│   ├── generate_html.py
│   ├── send_email.py
│   └── run_three_element_valuation.py
└── assets/
    └── sample_report_payload.json
```

## 使用方式

1. 在实际分析时，先获取计算机当前时间。
2. 先取最新价格和财务数据，再完成六步估值框架分析。
3. 按 `assets/sample_report_payload.json` 结构组织结果。
4. 运行脚本生成 HTML，必要时再发邮件。

### 只生成 HTML

```powershell
& "C:\Program Files\Python312\python.exe" "C:\Users\Administrator\.workbuddy\skills\guijiang-three-element-valuation\scripts\run_three_element_valuation.py" --input "payload.json" --output "report.html"
```

### 生成 HTML 并发送邮件

```powershell
& "C:\Program Files\Python312\python.exe" "C:\Users\Administrator\.workbuddy\skills\guijiang-three-element-valuation\scripts\run_three_element_valuation.py" --input "payload.json" --output "report.html" --send-email --recipient "hncjit@qq.com"
```

## 设计原则

- 先资产，后盈利，最后成长。
- 默认保守假设，不给乐观故事估值。
- 报告必须适合邮件正文直接阅读。
- 使用计算机当前时间与当下可获取的最新财务期次。

## 注意事项

- 邮件配置复用 `C:\Users\Administrator\WorkBuddy\Claw\email_config.py`。
- 若数据不足，宁可给区间与风险提示，不要伪精确。
- 若用户没有明确要求发送邮件，只生成 HTML 报告即可。
