#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""发送三要素估值 HTML 邮件。"""

from __future__ import annotations

import argparse
import smtplib
import sys
from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Iterable

CONFIG_DIR = Path(r"C:\Users\Administrator\WorkBuddy\Claw")
if str(CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(CONFIG_DIR))


def _load_config() -> dict[str, object]:
    try:
        import email_config as cfg  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError(f"无法加载邮件配置文件：{exc}") from exc

    smtp_server = getattr(cfg, "SMTP_SERVER", getattr(cfg, "EMAIL_HOST", "smtp.qq.com"))
    smtp_port = int(getattr(cfg, "SMTP_PORT", getattr(cfg, "EMAIL_PORT", 587)))
    sender_email = getattr(cfg, "SENDER_EMAIL", getattr(cfg, "EMAIL_USER", ""))
    sender_name = getattr(cfg, "SENDER_NAME", "归江价值精选")
    password = getattr(cfg, "EMAIL_PASSWORD", "")
    receiver_email = getattr(cfg, "RECEIVER_EMAIL", getattr(cfg, "EMAIL_USER", ""))

    if not sender_email or not password:
        raise RuntimeError("邮件配置不完整，缺少发件人邮箱或授权码。")

    return {
        "smtp_server": smtp_server,
        "smtp_port": smtp_port,
        "sender_email": sender_email,
        "sender_name": sender_name,
        "password": password,
        "receiver_email": receiver_email,
    }


def _split_recipients(recipient_text: str | None, default_recipient: str) -> list[str]:
    source = recipient_text or default_recipient
    return [item.strip() for item in source.split(",") if item.strip()]


def _plain_fallback(subject: str) -> str:
    return f"{subject}\n\n请查收 HTML 格式的三要素估值报告。"


def send_html_email(subject: str, html_content: str, recipient_text: str | None = None) -> bool:
    cfg = _load_config()
    recipients = _split_recipients(recipient_text, str(cfg["receiver_email"]))
    if not recipients:
        raise RuntimeError("未找到有效收件人。")

    msg = MIMEMultipart("alternative")
    sender_name = str(cfg["sender_name"])
    sender_email = str(cfg["sender_email"])
    msg["Subject"] = subject
    msg["From"] = f"{Header(sender_name).encode()} <{sender_email}>"
    msg["To"] = ", ".join(recipients)
    msg.attach(MIMEText(_plain_fallback(subject), "plain", "utf-8"))
    msg.attach(MIMEText(html_content, "html", "utf-8"))

    server = smtplib.SMTP(str(cfg["smtp_server"]), int(cfg["smtp_port"]))
    try:
        server.starttls()
        server.login(sender_email, str(cfg["password"]))
        server.sendmail(sender_email, recipients, msg.as_string())
        return True
    finally:
        server.quit()


def main() -> None:
    parser = argparse.ArgumentParser(description="发送三要素估值 HTML 邮件")
    parser.add_argument("--subject", required=True, help="邮件主题")
    parser.add_argument("--html-file", required=True, help="HTML 文件路径")
    parser.add_argument("--recipient", help="收件人，多个用逗号分隔")
    args = parser.parse_args()

    html_path = Path(args.html_file)
    html_content = html_path.read_text(encoding="utf-8")
    ok = send_html_email(args.subject, html_content, args.recipient)
    if ok:
        print(f"邮件发送成功：{args.recipient or '默认收件人'}")
    else:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
