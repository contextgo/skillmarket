#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""三要素估值 HTML 报告生成器。"""

from __future__ import annotations

import argparse
import json
from datetime import datetime
from html import escape
from pathlib import Path
from typing import Any, Iterable


def _safe_text(value: Any, default: str = "—") -> str:
    if value is None:
        return default
    text = str(value).strip()
    return text if text else default


def _safe_html(value: Any, default: str = "—") -> str:
    return escape(_safe_text(value, default))


def _fmt_num(value: Any, digits: int = 2) -> str:
    if value in (None, "", "—"):
        return "—"
    try:
        return f"{float(value):,.{digits}f}"
    except (TypeError, ValueError):
        return _safe_text(value)


def _fmt_money(value: Any, currency: str = "元") -> str:
    if value in (None, "", "—"):
        return "—"
    return f"{_fmt_num(value)} {currency}" if currency else _fmt_num(value)


def _fmt_pct(value: Any, digits: int = 1) -> str:
    if value in (None, "", "—"):
        return "—"
    try:
        return f"{float(value):.{digits}f}%"
    except (TypeError, ValueError):
        return _safe_text(value)


def _list_items(items: Iterable[Any], empty_text: str = "暂无补充。") -> str:
    cleaned = []
    for item in items or []:
        if isinstance(item, dict):
            title = _safe_html(item.get("title"))
            desc = _safe_html(item.get("description"))
            if desc == "—":
                cleaned.append(f"<li>{title}</li>")
            else:
                cleaned.append(f"<li><strong>{title}</strong>：{desc}</li>")
        else:
            cleaned.append(f"<li>{_safe_html(item)}</li>")
    if not cleaned:
        cleaned.append(f"<li>{_safe_html(empty_text)}</li>")
    return "\n".join(cleaned)


def _render_adjustment_rows(rows: list[dict[str, Any]], currency: str) -> str:
    if not rows:
        return '<tr><td colspan="4">暂无明细</td></tr>'
    html_rows = []
    for row in rows:
        html_rows.append(
            "<tr>"
            f"<td>{_safe_html(row.get('item'))}</td>"
            f"<td>{_fmt_money(row.get('book_value'), currency)}</td>"
            f"<td>{_fmt_money(row.get('adjusted_value'), currency)}</td>"
            f"<td>{_safe_html(row.get('note'))}</td>"
            "</tr>"
        )
    return "\n".join(html_rows)


def _render_bridge_rows(rows: list[dict[str, Any]], currency: str) -> str:
    if not rows:
        return '<tr><td colspan="3">暂无桥接明细</td></tr>'
    html_rows = []
    for row in rows:
        html_rows.append(
            "<tr>"
            f"<td>{_safe_html(row.get('item'))}</td>"
            f"<td>{_fmt_money(row.get('value'), currency)}</td>"
            f"<td>{_safe_html(row.get('note'))}</td>"
            "</tr>"
        )
    return "\n".join(html_rows)


def _render_reference_rows(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "<li>未单列来源，请在正式使用时补足。</li>"
    refs = []
    for row in rows:
        title = _safe_html(row.get("title"))
        url = _safe_text(row.get("url"), "")
        if url and url != "—":
            refs.append(f'<li><a href="{escape(url, quote=True)}" target="_blank">{title}</a></li>')
        else:
            refs.append(f"<li>{title}</li>")
    return "\n".join(refs)


def render_three_element_report(payload: dict[str, Any]) -> str:
    now = payload.get("report_datetime") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    company_name = _safe_text(payload.get("company_name"))
    company_code = _safe_text(payload.get("company_code"))
    market = _safe_text(payload.get("market"))
    currency = _safe_text(payload.get("currency"), "元")
    price_date = _safe_text(payload.get("price_date"), now[:10])
    current_price = payload.get("current_price")
    latest_report_period = _safe_text(payload.get("latest_report_period"))
    core_conclusion = _safe_text(payload.get("core_conclusion"), "尚未填写核心结论。")
    final_call = _safe_text(payload.get("final_call"), "观察")

    strategic = payload.get("strategic_judgment", {}) or {}
    valuation = payload.get("valuation", {}) or {}
    growth_assessment = payload.get("growth_assessment", {}) or {}

    asset_value = valuation.get("asset_value_per_share")
    epv_value = valuation.get("epv_per_share")
    growth_value = valuation.get("growth_value_per_share")
    intrinsic_anchor = valuation.get("intrinsic_anchor")
    batting_zone_upper = valuation.get("batting_zone_upper")
    ideal_buy_point = valuation.get("ideal_buy_point")
    margin_of_safety = valuation.get("margin_of_safety_pct")
    expected_dividend_yield = valuation.get("expected_dividend_yield_at_batting_zone")
    capital_cost = valuation.get("capital_cost_pct")
    diagnosis_case = _safe_text(valuation.get("diagnosis_case"), "—")
    diagnosis_text = _safe_text(valuation.get("diagnosis_text"), "未提供诊断说明。")
    current_discount = valuation.get("current_discount_to_anchor_pct")

    call_class = {
        "买入": "call-buy",
        "观察": "call-watch",
        "规避": "call-avoid",
    }.get(final_call, "call-watch")

    growth_applicable = bool(growth_assessment.get("applicable"))
    growth_summary = _safe_text(
        growth_assessment.get("summary"),
        "若未证明存在经济特许权，则成长价值按零或极低值处理。",
    )

    report_title = f"{company_name}（{company_code}）三要素估值诊断书"

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{escape(report_title)}</title>
  <style>
    body {{
      margin: 0;
      padding: 0;
      background: #f3f6fb;
      color: #16202a;
      font-family: "Microsoft YaHei", "PingFang SC", Arial, sans-serif;
      line-height: 1.7;
    }}
    .page {{
      max-width: 980px;
      margin: 24px auto;
      background: #ffffff;
      border-radius: 18px;
      overflow: hidden;
      box-shadow: 0 12px 40px rgba(15, 23, 42, 0.12);
    }}
    .hero {{
      padding: 40px 42px 28px;
      background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 52%, #7c3aed 100%);
      color: #ffffff;
    }}
    .eyebrow {{
      display: inline-block;
      padding: 6px 12px;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.14);
      font-size: 13px;
      letter-spacing: 0.5px;
      margin-bottom: 14px;
    }}
    h1 {{
      margin: 0;
      font-size: 32px;
      line-height: 1.3;
      font-weight: 700;
    }}
    .subline {{
      margin-top: 14px;
      font-size: 15px;
      color: rgba(255, 255, 255, 0.9);
    }}
    .hero-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 14px;
      margin-top: 26px;
    }}
    .hero-card {{
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.16);
      border-radius: 16px;
      padding: 16px 18px;
    }}
    .hero-card .label {{
      font-size: 13px;
      color: rgba(255, 255, 255, 0.72);
      margin-bottom: 8px;
    }}
    .hero-card .value {{
      font-size: 26px;
      font-weight: 700;
    }}
    .hero-card .note {{
      font-size: 13px;
      color: rgba(255, 255, 255, 0.82);
      margin-top: 6px;
    }}
    .body {{
      padding: 30px 42px 42px;
    }}
    .summary-box {{
      border: 1px solid #dbe5ff;
      background: linear-gradient(180deg, #f8fbff 0%, #eef4ff 100%);
      border-radius: 16px;
      padding: 20px 22px;
      margin-bottom: 26px;
    }}
    .call-badge {{
      display: inline-block;
      padding: 7px 14px;
      border-radius: 999px;
      font-size: 13px;
      font-weight: 700;
      margin-bottom: 12px;
    }}
    .call-buy {{ background: #ffe3e3; color: #b42318; }}
    .call-watch {{ background: #fff2cc; color: #9a6700; }}
    .call-avoid {{ background: #e7ecf3; color: #475467; }}
    .section {{ margin-top: 30px; }}
    .section h2 {{
      margin: 0 0 14px;
      font-size: 23px;
      color: #102a43;
      padding-left: 14px;
      border-left: 5px solid #4f46e5;
    }}
    .grid-2 {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 16px;
    }}
    .metric-card {{
      border: 1px solid #e6ebf4;
      border-radius: 16px;
      padding: 18px 20px;
      background: #ffffff;
    }}
    .metric-card .title {{ font-size: 14px; color: #53627a; }}
    .metric-card .value {{ font-size: 28px; font-weight: 700; margin-top: 8px; color: #111827; }}
    .metric-card .desc {{ font-size: 13px; color: #667085; margin-top: 8px; }}
    table {{
      width: 100%;
      border-collapse: collapse;
      background: #ffffff;
      border-radius: 14px;
      overflow: hidden;
      border: 1px solid #e6ebf4;
    }}
    th, td {{
      padding: 12px 14px;
      border-bottom: 1px solid #e6ebf4;
      text-align: left;
      vertical-align: top;
      font-size: 14px;
    }}
    th {{
      background: #eef3ff;
      color: #213547;
      font-weight: 700;
    }}
    tr:last-child td {{ border-bottom: none; }}
    .note-card {{
      background: #fffaf0;
      border: 1px solid #f8d59b;
      border-radius: 14px;
      padding: 16px 18px;
      color: #7a4a00;
    }}
    .risk-card {{
      background: #fff5f5;
      border: 1px solid #fecaca;
      border-radius: 14px;
      padding: 16px 18px;
    }}
    ul {{ margin: 10px 0 0 18px; padding: 0; }}
    li {{ margin-bottom: 8px; }}
    .footer {{
      margin-top: 32px;
      padding-top: 18px;
      border-top: 1px dashed #d7deea;
      color: #667085;
      font-size: 13px;
    }}
    a {{ color: #1d4ed8; text-decoration: none; }}
    @media (max-width: 640px) {{
      .hero, .body {{ padding: 24px 18px; }}
      h1 {{ font-size: 26px; }}
      .hero-card .value, .metric-card .value {{ font-size: 22px; }}
    }}
  </style>
</head>
<body>
  <div class="page">
    <div class="hero">
      <div class="eyebrow">归江价值精选 · 三要素估值诊断</div>
      <h1>{escape(report_title)}</h1>
      <div class="subline">估值时点：{_safe_html(now)} ｜ 市场：{_safe_html(market)} ｜ 最新财报期：{_safe_html(latest_report_period)} ｜ 当前价格日期：{_safe_html(price_date)}</div>
      <div class="hero-grid">
        <div class="hero-card">
          <div class="label">当前价格</div>
          <div class="value">{_fmt_money(current_price, currency)}</div>
          <div class="note">相对保守价值锚：{_fmt_pct(current_discount)}</div>
        </div>
        <div class="hero-card">
          <div class="label">保守内在价值锚</div>
          <div class="value">{_fmt_money(intrinsic_anchor, currency)}</div>
          <div class="note">优先以 A、B 中更稳妥者落锚</div>
        </div>
        <div class="hero-card">
          <div class="label">击球区上限</div>
          <div class="value">{_fmt_money(batting_zone_upper, currency)}</div>
          <div class="note">安全边际要求：{_fmt_pct(margin_of_safety)}</div>
        </div>
        <div class="hero-card">
          <div class="label">最终结论</div>
          <div class="value">{_safe_html(final_call)}</div>
          <div class="note">诊断情形：{_safe_html(diagnosis_case)}</div>
        </div>
      </div>
    </div>

    <div class="body">
      <div class="summary-box">
        <div class="call-badge {call_class}">{_safe_html(final_call)}</div>
        <div style="font-size: 18px; font-weight: 700; margin-bottom: 10px;">核心战略判断与周期定位</div>
        <div>{_safe_html(core_conclusion)}</div>
        <div style="margin-top: 14px; color: #425466; font-size: 14px;">
          行业可持续性：{_safe_html(strategic.get('industry_sustainable'))}；
          经济特许权判断：{_safe_html(strategic.get('company_franchise'))}；
          当前周期阶段：{_safe_html(strategic.get('cycle_stage'))}。
        </div>
      </div>

      <div class="section">
        <h2>三要素估值结果</h2>
        <div class="grid-2">
          <div class="metric-card">
            <div class="title">资产价值 A</div>
            <div class="value">{_fmt_money(asset_value, currency)}</div>
            <div class="desc">调整后每股净资产 / 重置成本口径。关键说明：{_safe_html(valuation.get('asset_value_note'))}</div>
          </div>
          <div class="metric-card">
            <div class="title">盈利能力价值 B（EPV）</div>
            <div class="value">{_fmt_money(epv_value, currency)}</div>
            <div class="desc">可持续盈利能力 ÷ 资本成本。资本成本假设：{_fmt_pct(capital_cost)}</div>
          </div>
          <div class="metric-card">
            <div class="title">成长价值 G</div>
            <div class="value">{_fmt_money(growth_value, currency)}</div>
            <div class="desc">{_safe_html('适用' if growth_applicable else '不适用')}。{_safe_html(growth_summary)}</div>
          </div>
          <div class="metric-card">
            <div class="title">A / B 诊断</div>
            <div class="value">情形 {_safe_html(diagnosis_case)}</div>
            <div class="desc">{_safe_html(diagnosis_text)}</div>
          </div>
        </div>
      </div>

      <div class="section">
        <h2>资产价值关键调整</h2>
        <table>
          <thead>
            <tr>
              <th>项目</th>
              <th>账面值</th>
              <th>调整后价值</th>
              <th>说明</th>
            </tr>
          </thead>
          <tbody>
            {_render_adjustment_rows(payload.get('asset_adjustments', []), currency)}
          </tbody>
        </table>
      </div>

      <div class="section">
        <h2>可持续盈利能力桥接</h2>
        <table>
          <thead>
            <tr>
              <th>项目</th>
              <th>金额</th>
              <th>说明</th>
            </tr>
          </thead>
          <tbody>
            {_render_bridge_rows(payload.get('normalized_earnings_bridge', []), currency)}
          </tbody>
        </table>
      </div>

      <div class="section">
        <h2>非核心资产、表外负债与成长评估</h2>
        <div class="grid-2">
          <div class="metric-card">
            <div class="title">非核心资产 / 负债</div>
            <ul>{_list_items(payload.get('non_core_assets', []), '未单列非核心资产。')}</ul>
            <div style="margin-top: 12px; font-size: 13px; color: #667085;">表外负债：</div>
            <ul>{_list_items(payload.get('off_balance_liabilities', []), '未发现重大表外负债或暂未获取。')}</ul>
          </div>
          <div class="metric-card">
            <div class="title">成长价值评估</div>
            <div style="font-size: 14px; color: #425466; margin-top: 6px;">
              股息 / 现金流回报：{_fmt_pct(growth_assessment.get('dividend_yield_pct'))}<br />
              有机增长：{_fmt_pct(growth_assessment.get('organic_growth_pct'))}<br />
              留存收益再投资回报率：{_fmt_pct(growth_assessment.get('reinvestment_return_pct'))}
            </div>
            <ul>{_list_items(growth_assessment.get('notes', []), '若缺乏高质量证据，则成长价值保持保守。')}</ul>
          </div>
        </div>
      </div>

      <div class="section">
        <h2>安全边际与击球区</h2>
        <div class="grid-2">
          <div class="metric-card">
            <div class="title">保守内在价值锚</div>
            <div class="value">{_fmt_money(intrinsic_anchor, currency)}</div>
            <div class="desc">击球区上限：{_fmt_money(batting_zone_upper, currency)}；理想买点：{_fmt_money(ideal_buy_point, currency)}</div>
          </div>
          <div class="metric-card">
            <div class="title">击球区下的现金流回报验证</div>
            <div class="value">{_fmt_pct(expected_dividend_yield)}</div>
            <div class="desc">要求显著高于无风险利率；若做不到，说明价格还不够便宜。</div>
          </div>
        </div>
        <div class="note-card" style="margin-top: 16px;">
          归江式判断不是追求“算得很漂亮”，而是追求“买得很安全”。如果资产价值不托底、EPV 不稳、成长又讲不清，就不要轻易下结论。
        </div>
      </div>

      <div class="section">
        <h2>主要风险提示</h2>
        <div class="risk-card">
          <ul>{_list_items(payload.get('risks', []), '请补充最不确定的假设，例如维护性资本开支、特许权持续性、管理层再投资能力。')}</ul>
        </div>
      </div>

      <div class="section">
        <h2>数据来源与限制</h2>
        <div class="metric-card">
          <div style="font-size: 14px; color: #425466;">{_safe_html(payload.get('limitations'), '若部分数据未披露或口径不一致，请在正式报告中明确披露限制。')}</div>
          <ol style="margin: 14px 0 0 20px; padding: 0;">{_render_reference_rows(payload.get('references', []))}</ol>
        </div>
      </div>

      <div class="footer">
        本报告适合直接作为邮件正文发送。若要发送邮件，请使用同目录下的 `run_three_element_valuation.py` 或 `send_email.py`。
      </div>
    </div>
  </div>
</body>
</html>
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="根据 JSON 数据生成三要素估值 HTML 报告")
    parser.add_argument("--input", required=True, help="输入 JSON 文件路径")
    parser.add_argument("--output", required=True, help="输出 HTML 文件路径")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)

    payload = json.loads(input_path.read_text(encoding="utf-8"))
    html = render_three_element_report(payload)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    print(f"HTML 报告已生成：{output_path}")


if __name__ == "__main__":
    main()
