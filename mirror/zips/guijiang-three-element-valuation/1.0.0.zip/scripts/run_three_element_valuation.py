#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""读取估值 JSON，生成 HTML，并可选发送邮件。"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from generate_html import render_three_element_report
from send_email import send_html_email


def _default_subject(payload: dict) -> str:
    company_name = str(payload.get("company_name", "未命名公司")).strip()
    company_code = str(payload.get("company_code", "")).strip()
    report_date = str(payload.get("report_datetime", datetime.now().strftime("%Y-%m-%d %H:%M:%S")))[:10]
    if company_code:
        return f"[三要素估值诊断] {company_name}({company_code}) - {report_date}"
    return f"[三要素估值诊断] {company_name} - {report_date}"


def main() -> None:
    parser = argparse.ArgumentParser(description="生成三要素估值 HTML 报告，并可选发送邮件")
    parser.add_argument("--input", required=True, help="输入 JSON 文件路径")
    parser.add_argument("--output", required=True, help="输出 HTML 文件路径")
    parser.add_argument("--send-email", action="store_true", help="是否发送邮件")
    parser.add_argument("--recipient", help="收件人，多个收件人用逗号分隔")
    parser.add_argument("--subject", help="自定义邮件主题")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)

    payload = json.loads(input_path.read_text(encoding="utf-8"))
    payload.setdefault("report_datetime", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    html = render_three_element_report(payload)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    print(f"HTML 报告已生成：{output_path}")

    if args.send_email:
        subject = args.subject or _default_subject(payload)
        recipient = args.recipient or payload.get("recipient")
        send_html_email(subject, html, recipient)
        print(f"邮件已发送：{recipient or '默认收件人'}")


if __name__ == "__main__":
    main()
