# 技能摘要：guijiang-three-element-valuation

## 定位

一个面向单家公司估值分析的归江式三要素估值技能，核心目标是按“资产价值 A、盈利能力价值 B、成长价值 G”拆分内在价值，并据此测算安全边际与击球区。

## 已实现能力

1. 六步估值流程说明，覆盖持续经营判断、资产负债表保守调整、EPV、A/B/C 诊断、成长价值、击球区。
2. 强制要求使用计算机当前时间与当下最新可获得的财报期。
3. 明确了金融数据优先级：先 `neodata-financial-search`，再 `finance-data-retrieval`，最后公开网页补充。
4. 提供 HTML 报告渲染脚本，支持邮件正文直接阅读。
5. 提供邮件发送脚本，复用现有 QQ 邮箱配置并默认支持发送到 `hncjit@qq.com`。
6. 提供一键主脚本，可根据 JSON 输入生成 HTML，并按需发送邮件。

## 主要文件

- `SKILL.md`：主技能说明与执行纪律
- `references/framework.md`：三要素估值口径细化
- `references/data-sourcing-and-assumptions.md`：数据源优先级与保守假设
- `scripts/generate_html.py`：HTML 报告生成器
- `scripts/send_email.py`：HTML 邮件发送器
- `scripts/run_three_element_valuation.py`：主执行入口
- `assets/sample_report_payload.json`：样例输入数据
- `test_report.html`：用样例数据生成的测试报告

## 技能路径

`C:\Users\Administrator\.workbuddy\skills\guijiang-three-element-valuation`

## 当前状态

- 技能说明：已完成
- HTML 生成：已测试通过
- 邮件脚本：已实现，未主动发送测试邮件
- 打包文件：可在工作区直接分发使用
