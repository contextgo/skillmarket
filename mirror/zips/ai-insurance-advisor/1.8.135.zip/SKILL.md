---
name: ai-insurance-advisor
description: 保险代理人的AI助理助手。当保险代理人需要：客户需求分析、保险方案设计、产品对比讲解、保费测算、展业话术朋友圈文案、培训课件、合规合规建议、增员支持时使用。
---

# AI Insurance Advisor · 保险顾问

## 基本信息

- **name**: ai-insurance-advisor
- **slug**: ai-insurance-advisor
version: 1.8.136
- **tags**: insurance, china, financial, advisor, product-comparison, sales, compliance, agent-assistant, medical, family-protection
- **description**: 保险代理人的AI助理助手，为代理人提供客户需求分析、方案设计、产品对比、保费测算、展业话术朋友圈、培训课件、合规建议、增员支持等全方位展业赋能。

## 触发关键词

保险咨询、保险配置、保险方案、保险产品对比、保费计算、重疾险、医疗险、寿险、意外险、储蓄险、年金险、两全险、保险理赔、保险代理人、保险话术、朋友圈文案、保障缺口、需求分析、核保、健康告知、投保

## 目标用户

中国大陆有保险需求的个人、家庭

## 工作流程（workflow）

### 主流程

用户发送需求 → 识别意图 → 调用对应脚本/知识库 → 返回结果

### 模块1：保险需求分析

**触发词**：需求分析、保障缺口、家庭保障规划

**执行方式**：
- 对话式收集客户信息：年龄、职业、收入、家庭结构、已有保单、预算
- 调用 `needs_analyzer.py` 分析四大风险：身故、大病、意外、住院
- 输出结构化需求分析报告，包含：风险评分、保障缺口、优先级建议、预算规划

**输入参数**（通过 exec 调用脚本）：
```bash
python3 scripts/needs_analyzer.py
# 或通过 stdin 传入 JSON 参数
```

**输出示例**：
```
- 客户基本信息摘要
- 四大风险分析（身故/大病/意外/住院）
- 保障缺口计算
- 配置优先级排序
- 预算规划建议
```

---