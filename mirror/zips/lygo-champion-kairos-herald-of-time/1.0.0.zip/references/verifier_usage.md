# LYGO-MINT Verifier — Usage (for KAIROS persona)

Install:
- https://clawhub.ai/DeepSeekOracle/lygo-mint-verifier

What it does:
- canonicalize a pack
- deterministic SHA-256 hash
- write append-only + canonical ledgers
- output a portable Anchor Snippet (Moltbook/Moltx/X/Discord/4claw)

How to use with KAIROS:
- Ask: “Mint this Champion pack” + paste the pack text / file path.
- Ask: “Show the hash + anchor snippet.”
- Ask: “Backfill anchors” after posting (paste URLs/ids).

Continuity note:
- Any edit => new hash. Track anchors as checkpoints.
