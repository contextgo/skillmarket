#!/bin/bash
echo "==================================="
echo " 跨境电商评论自动回复 - 安装脚本"
echo "==================================="

pip install --upgrade requests openclaw

echo "✅ 安装完成！"
echo "运行命令：python cross_border_review_skill.py"