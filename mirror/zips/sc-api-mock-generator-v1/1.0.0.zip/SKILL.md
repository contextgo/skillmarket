---
name: api-mock-generator
description: 根据 API 接口描述（接口地址、请求方式、响应 TS 类型）生成 Chrome DevTools Local Overrides 格式的 Mock 数据文件，并直接创建到指定目录。当用户提到"mock 数据"、"本地替换"、"接口 mock"、"Chrome Overrides"、"API 调试"等关键词时使用此技能。
---

# API Mock Data Generator（Chrome Local Overrides）

## 工作流程

1. **解析输入**：提取接口地址、请求方式、环境、响应类型
2. **生成 Mock JSON**：按响应类型和字段语义生成逼真数据
3. **创建文件**：直接使用 Write 工具将 mock 文件写入 overrides 目录
4. **输出摘要**：展示文件路径、关键数据预览、Chrome 配置提示

## 环境域名

未指定环境时默认 `test`。

| 环境 | 域名 |
|------|------|
| test（默认） | `test-sino-gateway.sinoclick.com` |
| pre | `pre-sino-gateway.sinoclick.com` |

## 输入字段

| 字段 | 必须 | 说明 |
|------|------|------|
| 接口地址 | ✅ | 如 `/api/user/list` |
| 请求方式 | ✅ | GET / POST / PUT / DELETE |
| 响应参数 TS 类型 | ✅ | TypeScript interface 或 JSON 结构 |
| 接口环境 | 可选 | `test` / `pre`，默认 `test` |
| 接口描述 | 可选 | 功能说明 |
| 数组条数 | 可选 | 数组字段生成条数，默认 5 |
| mock 场景 | 可选 | `success`（默认）/ `error` / `empty` |

## 文件路径规则

格式：`{OVERRIDES_DIR}/{域名}/{url路径段...}/{最末段}`

- 文件名**无扩展名**（Chrome Local Overrides 约定）
- `OVERRIDES_DIR` 默认为项目根目录下的 `overrides/`（即 `{项目根目录}/overrides`）
- 路径参数（如 `{id}`）替换为示例值（如 `12345`）

示例：`/api/user/list` + test 环境 →

```
{项目根目录}/overrides/test-sino-gateway.sinoclick.com/api/user/list
```

## Mock JSON 生成规则

### 响应外层结构（固定）

每个 mock 响应**必须**包含以下固定外层，无论用户的 TS 类型是否声明：

```json
{
  "code": 0,
  "message": "成功",
  "success": true,
  "result": "...按 TS 类型生成...",
  "traceId": "生成 UUID"
}
```

### mock 场景变体

| 场景 | result 值 | code | message |
|------|-----------|------|---------|
| success（默认） | 按类型生成 | `0` | `"成功"` |
| error | `null` | `500` | `"服务器内部错误"` |
| empty | `[]` 或 `null`（视类型） | `0` | `"成功"` |

### 字段语义推断

根据字段名自动推断合理的 mock 值：

| 字段名模式 | 生成策略 |
|------------|---------|
| `*url*` / `*Url*` / `*link*` | 合法 URL |
| `*imageUrl*` / `*img*` / `*cover*` / `*thumbnail*` | `https://picsum.photos/id/{固定数字}/宽/高`，数字从 10~200 中按字段索引递增选取（如第 1 个图片字段用 10，第 2 个用 11），确保同一接口内不重复且每次生成结果一致 |
| `*videoUrl*` / `*video*` | 从以下列表中按字段索引顺序依次选取：`http://vjs.zencdn.net/v/oceans.mp4`、`https://sf1-cdn-tos.huoshanstatic.com/obj/media-fe/xgplayer_doc_video/mp4/xgplayer-demo-360p.mp4`、`http://www.w3school.com.cn/example/html5/mov_bbb.mp4`、`https://media.w3.org/2010/05/sintel/trailer.mp4` |
| `*signUrl*` / `*SignUrl*` / `*ossUrl*` / `*OssUrl*` | 视为媒体资源 URL，需根据上下文判断类型：若同一类型中存在 `video`/`Video` 相关字段名提示，或字段注释/描述含"视频"，则按 **videoUrl** 策略生成；否则默认按 **imageUrl** 策略生成 |
| `*avatar*` | `https://i.pravatar.cc/150?u={随机}` |
| `*date*` / `*time*` / `*Time*` / `*Date*` | ISO 日期或 `yyyy-MM-dd HH:mm:ss` |
| `*id*` / `*Id*` / `*uuid*` | UUID 或 6 位数字 ID |
| `*name*` / `*Name*` / `*title*` | 合理的中文/英文名称 |
| `*email*` | 合理邮箱 |
| `*phone*` / `*mobile*` | 合理手机号 |
| `*amount*` / `*price*` / `*spend*` / `*cost*` | 100~10000，保留 2 位小数 |
| `*count*` / `*num*` / `*quantity*` | 1~500 整数 |
| `*rate*` / `*ratio*` / `*roas*` / `*roi*` | 0.1~10，保留 2 位小数 |
| `*status*` | 枚举值中随机选一个 |
| `*description*` / `*desc*` / `*remark*` | 一段合理的描述文本 |

### 数组与分页

- 数组默认 **5 条**，每条数据应有合理差异
- 联合类型枚举值在数组中尽量覆盖
- 若存在 `total` / `totalCount` 字段，值设为大于数组长度（如数组 5 条，total 设 23）

## 执行方式

### 首选：直接创建文件

使用 Shell 工具执行 `mkdir -p` 创建目录，再使用 Write 工具写入 mock JSON 文件：

```
1. Shell: mkdir -p {项目根目录}/overrides/{域名}/{路径目录}
2. Write: 写入 mock JSON 到目标文件路径
3. 输出确认信息
```

### 备选：输出 shell 脚本

当用户明确要求"给我脚本"或在非 Cursor 环境时，输出可执行脚本：

```bash
#!/bin/bash
OVERRIDES_DIR="{项目根目录}/overrides"
DOMAIN="{域名}"

mkdir -p "${OVERRIDES_DIR}/${DOMAIN}/{路径目录}"

tee "${OVERRIDES_DIR}/${DOMAIN}/{完整路径}" > /dev/null << 'MOCKEOF'
{...mock JSON...}
MOCKEOF

echo "✅ Mock 文件已创建"
```

## 批量处理

当用户提供多个接口时：
1. 逐个生成 mock JSON
2. 合并为一个 shell 脚本（共享配置区），或依次使用 Write 工具创建
3. 最后汇总输出所有文件路径

## 输出格式

每次输出包含以下部分：

### 1. 文件目录结构

用 tree 格式展示：

```
overrides/
└── {域名}/
    └── api/
        └── user/
            └── list          ← 无扩展名
```

### 2. Mock 文件内容

展示完整 JSON（供用户确认）。

### 3. 创建确认

文件创建后输出路径和环境信息。

### 4. Chrome 配置提示（仅首次）

首次生成时附上配置步骤：
1. DevTools (F12) → Sources → Overrides
2. 点击 + Select folder for overrides → 选择项目根目录下的 `overrides` 文件夹
3. 允许访问权限
4. 勾选 Enable Local Overrides
5. 刷新页面验证（Network 面板中被替换请求带 ⚠️ 标记）
