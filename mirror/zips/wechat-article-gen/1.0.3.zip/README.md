# wechat-article-gen

微信公众号智能配图 + 一键发布。生成 1~4 张配图并推送草稿箱，图片自动上传 CDN。

---

## 一、凭证配置

首次使用需填写 4 个凭证字段，其余字段保持默认即可。

**配置文件路径**：`.openclaw` 或 `.qclaw` 目录 → `workspace` → `skills` → `wechat-article-gen` → `config.env`

> 找不到文件？直接在对话框告诉 AI：「帮我打开 wechat-article-gen技能的配置文件 config.env 」，AI 会自动定位并打开，你只需填入凭证即可。

---

### 1-1. 即梦AI 凭证（生成封面和配图）

**填写位置**：config.env 第 7~8 行

```
JIMENG_ACCESS_KEY_ID=your_access_key_id
JIMENG_SECRET_ACCESS_KEY=your_secret_access_key
```

**获取地址**：https://console.volcengine.cn/ → 右上角头像 → API 访问密钥

> 如果没有账号：先注册火山引擎账号并完成实名认证，然后在"即梦AI"产品页面开通权限。

---

### 1-2. 微信公众号凭证（发布到草稿箱）

**填写位置**：config.env 第 28~29 行

```
WECHAT_APP_ID=your_app_id
WECHAT_APP_SECRET=your_app_secret
```

**获取地址**：登录 https://mp.weixin.qq.com/ → 设置与开发 → 基本配置

---

### 1-3. IP 白名单设置

获取凭证后还需将本机公网 IP 添加到白名单，否则会报 45166 错误。

**设置地址**：微信开发者后台 -> 公众平台 -> 基本配置 -> IP 白名单

**查看本机公网 IP**：
- 方式一：浏览器百度"IP"，回车即可看到
- 方式二：命令行执行 `curl ifconfig.me`

---

## 二、快速开始

```bash
# 生成 1~4 张配图（自动 16:9 + 圆角）
python3 scripts/generate_images.py --article article.md --output ./images/

# 发布到草稿箱
./scripts/publish.sh article.md
```

---

## 三、发布命令

```bash
./scripts/publish.sh article.md                    # 默认 lapis 主题
./scripts/publish.sh article.md phycat           # 指定主题
./scripts/publish.sh article.md lapis solarized-light  # 指定主题 + 高亮
```

**主题**：lapis（推荐）、phycat、default 等
**代码高亮**：solarized-light（推荐）、monokai、github、dracula 等

---

## 四、Markdown 格式

文件顶部必须有 frontmatter：

```markdown
---
title: 文章标题（必填！）
cover: ./cover.png  # 封面图（必填！）
---

# 正文

![配图](images/img01.png)
```

---

## 五、常见问题

**Q: wenyan: command not found**
-> `npm install -g @wenyan-md/cli`

**Q: 未能找到文章封面**
-> frontmatter 缺少 title 或 cover 字段

**Q: IP不在白名单（45166）**
-> 微信开发者后台 -> 公众平台 -> 基本配置 -> IP白名单 -> 添加公网 IP

**Q: 调试模式**
```bash
wenyan render -f article.md -t lapis   # 仅渲染，不发布
```
