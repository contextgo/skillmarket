#!/usr/bin/env python3
"""
即梦AI（Jimeng AI）图片生成 4.0 - Python SDK

基于火山引擎 VisualService SDK，调用即梦AI文生图4.0 API。

Usage:
    python3 jimeng.py "一个穿着汉服的少女在樱花树下" -o ./images/
    python3 jimeng.py "未来城市设计图" -o ./ --width 2560 --height 1440
    python3 jimeng.py "科技感数据图表" -o ./ --size 16777216

配置文件: config.env（同目录上级）
"""

import argparse
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request

# ============== 颜色输出 ==============
RED = '\033[0;31m'
GREEN = '\033[0;32m'
YELLOW = '\033[1;33m'
BLUE = '\033[0;34m'
NC = '\033[0m'


def color_print(color, msg):
    print(f"{color}{msg}{NC}")


# ============== 默认配置 ==============
DEFAULT_CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config.env')
DEFAULT_SIZE = 4194304  # 2048×2048（稳定可用）
DEFAULT_TIMEOUT = 120
POLL_INTERVAL = 5


# ============== 读取配置 ==============
def load_config():
    """从 config.env 读取配置"""
    config = {}
    config_file = os.environ.get('JIMENG_CONFIG_FILE', DEFAULT_CONFIG_FILE)

    if not os.path.exists(config_file):
        return None

    with open(config_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '=' in line:
                key, val = line.split('=', 1)
                # 去除行内 # 注释
                val = val.split('#')[0].strip()
                config[key.strip()] = val

    return config


# ============== 初始化 SDK ==============
def get_visual_service(config):
    """创建并配置 VisualService 实例"""
    try:
        from volcengine.visual.VisualService import VisualService
    except ImportError:
        color_print(RED, "❌ 未安装 volcengine SDK！请运行: pip install volcengine")
        sys.exit(1)

    ak = (
        config.get('JIMENG_ACCESS_KEY_ID') or
        os.environ.get('JIMENG_ACCESS_KEY_ID') or
        os.environ.get('VOLC_ACCESS_KEY_ID')
    )
    sk = (
        config.get('JIMENG_SECRET_ACCESS_KEY') or
        os.environ.get('JIMENG_SECRET_ACCESS_KEY') or
        os.environ.get('VOLC_SECRET_ACCESS_KEY')
    )

    if not ak or not sk:
        raise Exception(
            "未找到即梦AI凭证！\n"
            "请在 config.env 中配置:\n"
            "  JIMENG_ACCESS_KEY_ID=your_access_key_id\n"
            "  JIMENG_SECRET_ACCESS_KEY=your_secret_access_key"
        )

    vs = VisualService()
    vs.set_ak(ak)
    vs.set_sk(sk)
    return vs


# ============== 提交任务 ==============
def submit_task(prompt, config, size=None, width=None, height=None,
                scale=None, force_single=None, return_url=None,
                min_ratio=None, max_ratio=None):
    """提交即梦AI图片生成任务，返回 task_id"""

    vs = get_visual_service(config)

    body = {
        "req_key": config.get('JIMENG_REQ_KEY', 'jimeng_t2i_v40'),
        "prompt": prompt,
    }

    # 尺寸参数（优先用 width/height，否则用 size）
    # 注意：即梦API对 width/height 有内部校验，width≥1024 且 height≥1024
    # 为确保稳定，使用 size 参数（API内部自动处理为最优分辨率）
    if size:
        body["size"] = size
    elif width and height:
        # API要求宽高均 ≥ 1024，否则用 size 回退
        if width >= 1024 and height >= 1024:
            body["width"] = width
            body["height"] = height
        else:
            body["size"] = int(config.get('JIMENG_CONTENT_SIZE', 4194304))
    else:
        body["size"] = int(config.get('JIMENG_CONTENT_SIZE', 4194304))

    # 可选参数
    if scale is not None:
        body["scale"] = scale
    elif config.get('JIMENG_SCALE'):
        body["scale"] = float(config['JIMENG_SCALE'])

    if force_single is not None:
        body["force_single"] = force_single

    if return_url is None:
        return_url = config.get('JIMENG_RETURN_URL', 'true').lower() == 'true'

    # API 调用（SDK自动处理签名）
    resp = vs.cv_sync2async_submit_task(body)

    code = resp.get('code')
    if code != 10000:
        raise Exception(f"API错误 code={code}: {resp.get('message', 'Unknown error')}")

    task_id = resp.get('data', {}).get('task_id')
    if not task_id:
        raise Exception(f"未返回 task_id: {resp}")

    color_print(GREEN, f"✅ 任务提交成功！task_id: {task_id}")
    return task_id


# ============== 查询任务结果 ==============
def get_task_result(task_id, config, return_url=None):
    """查询即梦AI图片生成任务结果"""

    vs = get_visual_service(config)

    if return_url is None:
        return_url = config.get('JIMENG_RETURN_URL', 'true').lower() == 'true'

    body = {
        "req_key": config.get('JIMENG_REQ_KEY', 'jimeng_t2i_v40'),
        "task_id": task_id,
    }

    resp = vs.cv_sync2async_get_result(body)

    code = resp.get('code')
    if code != 10000:
        raise Exception(f"API错误 code={code}: {resp.get('message', 'Unknown error')}")

    data = resp.get('data', {})
    status = data.get('status')

    return {
        'status': status,
        'image_urls': data.get('image_urls', []),
        'binary_data_base64': data.get('binary_data_base64', []),
        'request_id': resp.get('request_id'),
    }


# ============== 轮询等待结果 ==============
def wait_for_result(task_id, config, poll_interval=POLL_INTERVAL, max_wait=300):
    """轮询等待图片生成完成"""

    color_print(YELLOW, f"⏳ 等待图片生成（最多 {max_wait}s）...")

    start_time = time.time()
    while True:
        elapsed = time.time() - start_time
        if elapsed > max_wait:
            raise Exception(f"等待超时（{max_wait}秒），请稍后重试")

        result = get_task_result(task_id, config)
        status = result['status']

        if status == 'done':
            color_print(GREEN, f"✅ 图片生成完成！")
            return result
        elif status in ('in_queue', 'generating'):
            color_print(BLUE, f"   状态: {status}，已等待 {int(elapsed)}s，继续等待...")
            time.sleep(poll_interval)
        elif status in ('not_found', 'expired'):
            raise Exception(f"任务状态异常: {status}，请重新提交任务")
        else:
            raise Exception(f"未知状态: {status}")


# ============== 保存图片 ==============
def save_image_from_url(url, output_path):
    """从 URL 下载图片"""
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        data = resp.read()
    with open(output_path, 'wb') as f:
        f.write(data)
    return output_path


def save_image_from_base64(b64_data, output_path):
    """保存 base64 图片"""
    image_data = base64.b64decode(b64_data)
    with open(output_path, 'wb') as f:
        f.write(image_data)
    return output_path


# ============== 主流程：生成图片 ==============
def generate_image(
    prompt,
    output_path=None,
    config=None,
    size=None,
    width=None,
    height=None,
    scale=None,
    force_single=None,
    return_url=None,
    poll_interval=POLL_INTERVAL,
    max_wait=300,
):
    """
    生成图片完整流程：提交任务 → 轮询结果 → 保存图片

    Args:
        prompt: 图像描述（中英文均可）
        output_path: 图片保存路径（含文件名）
        config: 配置字典
        size: 生图面积（与 width/height 二选一）
        width, height: 宽高（优先于 size）
        scale: 文本影响程度 0~1
        force_single: 是否强制单张
        return_url: 是否返回 URL
        poll_interval: 轮询间隔（秒）
        max_wait: 最大等待时间（秒）

    Returns:
        保存的本地路径列表
    """
    if config is None:
        config = load_config()
    if config is None:
        raise Exception(
            "未找到 config.env 配置文件！\n"
            "请在 config.env 中配置 JIMENG_ACCESS_KEY_ID 和 JIMENG_SECRET_ACCESS_KEY"
        )

    os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)

    # 提交任务
    color_print(BLUE, f"🎨 生成图片: {prompt[:50]}{'...' if len(prompt) > 50 else ''}")
    task_id = submit_task(
        prompt, config,
        size=size, width=width, height=height,
        scale=scale, force_single=force_single, return_url=return_url
    )

    # 等待结果
    result = wait_for_result(task_id, config, poll_interval, max_wait)

    # 保存图片
    saved_paths = []
    base_name = output_path
    name, ext = os.path.splitext(base_name)
    if not ext:
        ext = '.png'

    if result['image_urls']:
        urls = result['image_urls']
        for i, url in enumerate(urls):
            path = f"{name}_{i+1}{ext}" if len(urls) > 1 else f"{name}{ext}"
            save_image_from_url(url, path)
            saved_paths.append(path)
            color_print(GREEN, f"   📁 保存: {path}")

    elif result['binary_data_base64']:
        b64_list = result['binary_data_base64']
        for i, b64_data in enumerate(b64_list):
            path = f"{name}_{i+1}{ext}" if len(b64_list) > 1 else f"{name}{ext}"
            save_image_from_base64(b64_data, path)
            saved_paths.append(path)
            color_print(GREEN, f"   📁 保存: {path}")

    return saved_paths


# ============== CLI 入口 ==============
def main():
    parser = argparse.ArgumentParser(
        description="即梦AI图片生成 4.0 - 基于火山引擎 VisualService SDK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python3 jimeng.py "一个穿着汉服的少女在樱花树下" -o ./images/result.png
  python3 jimeng.py "未来城市设计图" -o ./city.png --width 2560 --height 1440
  python3 jimeng.py "极简风格数据图表" -o ./chart.png --size 16777216

配置文件 config.env（上级目录），填写 JIMENG_ACCESS_KEY_ID 和 JIMENG_SECRET_ACCESS_KEY
        """
    )

    parser.add_argument('prompt', help='图片描述（中英文均可）')
    parser.add_argument('-o', '--output', default='./jimeng_output.png',
                        help='输出图片路径（默认 ./jimeng_output.png）')
    parser.add_argument('--aspect-ratio', '-r', default=None,
                        help='图片宽高比，如 "16:9"（横向）、"2.35:1"（封面）、"4:3"、"1:1"。示例: --aspect-ratio 16:9')
    parser.add_argument('--size', type=int, default=None,
                        help=f'生图面积，默认 {DEFAULT_SIZE}（2048x2048）')
    parser.add_argument('--width', type=int, default=None,
                        help='图片宽度（与 size 二选一，优先用宽高）')
    parser.add_argument('--height', type=int, default=None,
                        help='图片高度（与 size 二选一，优先用宽高）')
    parser.add_argument('--scale', type=float, default=None,
                        help='文本影响程度 0~1（默认 0.5）')
    parser.add_argument('--force-single', dest='force_single', action='store_true',
                        help='强制只生成一张图片')
    parser.add_argument('--no-url', dest='return_url', action='store_false',
                        help='不返回图片URL，只返回base64')
    parser.add_argument('--poll-interval', type=int, default=POLL_INTERVAL,
                        help=f'轮询间隔秒数（默认 {POLL_INTERVAL}）')
    parser.add_argument('--max-wait', type=int, default=300,
                        help='最大等待秒数（默认 300）')
    parser.add_argument('--config', default=None,
                        help='配置文件路径（默认 ./config.env）')

    args = parser.parse_args()

    if args.config:
        os.environ['JIMENG_CONFIG_FILE'] = args.config

    config = load_config()
    if config is None:
        color_print(RED, "❌ 未找到 config.env 配置文件！")
        color_print(YELLOW, "")
        color_print(YELLOW, "请在 config.env（上级目录）中添加：")
        print("")
        print("JIMENG_ACCESS_KEY_ID=你的AccessKeyID")
        print("JIMENG_SECRET_ACCESS_KEY=你的SecretAccessKey")
        sys.exit(1)

    try:
        # 将宽高比指令加入 prompt 开头，引导模型生成正确比例
        prompt = args.prompt
        if args.aspect_ratio:
            ratio_label = {
                '16:9': 'landscape wide screen (16:9)',
                '2.35:1': 'ultra-wide cinematic (2.35:1)',
                '4:3': 'standard (4:3)',
                '1:1': 'square (1:1)',
                '9:16': 'portrait (9:16)',
                '3:4': 'portrait (3:4)',
            }.get(args.aspect_ratio, args.aspect_ratio)
            prompt = f"The image must be in {ratio_label} aspect ratio. {args.prompt}"
            color_print(BLUE, f"📐 宽高比: {args.aspect_ratio} ({ratio_label})")

        paths = generate_image(
            prompt=prompt,
            output_path=args.output,
            config=config,
            size=args.size,
            width=args.width,
            height=args.height,
            scale=args.scale,
            force_single=args.force_single,
            return_url=args.return_url,
            poll_interval=args.poll_interval,
            max_wait=args.max_wait,
        )

        print("")
        color_print(GREEN, f"🎉 完成！共保存 {len(paths)} 张图片")
        for p in paths:
            print(f"   {p}")

    except Exception as e:
        color_print(RED, f"❌ 错误: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
