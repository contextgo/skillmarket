---
name: wechat-article-gen
description: "微信公众号智能配图 + 一键发布。基于 wenyan-cli，支持本地图片自动上传到微信 CDN。"
metadata:
  {
    "openclaw":
      {
        "emoji": "📱",
      },
  }
---

# wechat-article-gen

微信公众号智能配图 + 一键发布。自动生成 1~4 张配图并发布到草稿箱，图片自动上传微信 CDN。

## 功能

- 智能配图：分析文章结构，生成 1~4 张 16:9 配图（自动圆角）
- 一键发布：Markdown 渲染 + 图片上传 + 推送到草稿箱
- 多主题：lapis、phycat、default 等主题 + 代码高亮

## 快速开始

### 安装

```bash
npm install -g @wenyan-md/cli
cp config.env.example config.env
# 填写微信公众号凭证 + 即梦AI凭证
```

凭证获取：
- 微信公众号：https://mp.weixin.qq.com/ → 设置与开发 → 基本配置
- 即梦AI：https://console.volcengine.cn/ → 找到"即梦AI"

### 配图 + 发布

```bash
# 生成 1~4 张配图（自动 16:9 + 圆角）
python3 scripts/generate_images.py --article article.md --output ./images/

# 发布到草稿箱
./scripts/publish.sh article.md
```

---

## 脚本说明

| 脚本 | 作用 |
|------|------|
| `publish.sh` | 发布到草稿箱（wenyan publish） |
| `setup.sh` | 加载凭证到环境变量 |
| `generate_images.py` | 智能配图（1~4张，16:9，自动圆角） |
| `jimeng.py` | 即梦AI 生图（--aspect-ratio 指定比例） |

---

## Markdown 格式

文件顶部必须有 frontmatter：

```markdown
---
title: 文章标题（必填！）
cover: ./cover.png  # 封面图（必填！推荐 1080x864）
---

# 正文

![配图](images/img01.png)
```

---

## 发布命令

```bash
./scripts/publish.sh article.md              # 默认 lapis 主题
./scripts/publish.sh article.md phycat       # 指定主题
./scripts/publish.sh article.md lapis solarized-light  # 指定高亮
```

主题：lapis（推荐）、phycat、default 等
代码高亮：solarized-light（推荐）、monokai、github、dracula 等

查看全部主题：`wenyan theme -l`

其他选项：
```bash
wenyan publish -f article.md -t lapis --no-mac-style   # 关闭Mac风格代码块
wenyan publish -f article.md -t lapis --no-footnote    # 关闭链接转脚注
```

---

## 配图规则

wenyan publish 自动将正文图片上传到微信 CDN。

| 章节数 | 配图数 | 尺寸 |
|--------|--------|------|
| 6节以上 | 4张 | 16:9 |
| 4~5节 | 3张 | 16:9 |
| 2~3节 | 2张 | 16:9 |
| 1节 | 1张 | 16:9 |

封面图：2.35:1（超宽电影感）
内容配图：自动加 4px 圆角

---

## 新手常见问题

### 1. 执行后报"wenyan: command not found"
wenyan-cli 未安装。运行：
```bash
npm install -g @wenyan-md/cli
```

### 2. 执行后报"未能找到文章封面"
frontmatter 缺少 title 或 cover 字段。确保文件顶部有：
```markdown
---
title: 文章标题
cover: ./cover.png
---
```

### 3. 执行后报"IP不在白名单"（错误码 45166）
微信公众号后台未添加本机 IP。
1. 查本机公网 IP：`curl ifconfig.me`
2. 登录 https://mp.weixin.qq.com/
3. 设置与开发 → 基本配置 → IP白名单 → 添加该 IP

### 4. 执行后报"即梦AI凭证无效"或配图全白
检查 config.env 中的 JIMENG_ACCESS_KEY_ID 和 JIMENG_SECRET_ACCESS_KEY 是否正确。
获取地址：https://console.volcengine.cn/ → 右上角用户名 → Access Key

### 5. 配图生成成功但文章图片显示空白
这是历史 bug（add_rounded_corners 函数错误），请确认 scripts/generate_images.py 已更新到最新版本。最新版本修复了图片被错误处理为全白的问题。

### 6. 发布成功但草稿箱看不到文章
微信草稿箱 API 有延迟，稍等几秒后刷新页面。

调试命令：
```bash
wenyan render -f article.md -t lapis   # 仅渲染，不发布
```
