---
name: market-sentiment-overview
description: '分析A股整体市场状态，包括大盘行情、恐贪指数、市场温度、热门板块和后市展望。当用户询问大盘状况、市场情绪、热点板块或后市判断时触发。Use when: "今天大盘怎么样", "现在市场情绪如何", "最近哪些板块最热". Calls tools: mktLatestSummary, aShareMarketQuotes, aShareFearGreedIndex, aShareTemperature, queryHotSector, mktForwardLook.'
compatibility: 'Requires DeepQ MCP Server. Preferred: streamableHttp with access_token. Fallback: stdio via npx @deepqtech/mcp-server-js. DEEPQ_API_KEY env var or default sWxMywZpIt8N62JXGNng.'
metadata:
  author: deepqtech
  version: "1.0"
---

# 市场情绪与概况

## MCP Server 配置

本技能依赖 **DeepQ MCP Server** 提供数据工具。使用前请确保已在 agent 中配置 MCP Server。

### 推荐：Streamable HTTP（无需本地安装）

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-streamable": {
      "type": "streamableHttp",
      "url": "https://cgi.deepq.tech:9198/mcp-servers/mcp?access_token=sWxMywZpIt8N62JXGNng"
    }
  }
}
```

> `access_token` 优先使用环境变量 `DEEPQ_API_KEY` 的值，未设置时使用默认值 `sWxMywZpIt8N62JXGNng`。

### 备选：Stdio 本地进程

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-stdio": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@deepqtech/mcp-server-js@latest", "start"],
      "env": {
        "DEEPQ_API_KEY": "sWxMywZpIt8N62JXGNng"
      }
    }
  }
}
```

---

## 功能说明

从宏观视角把握 A 股当前市场状态：
- **大盘行情**：主要指数涨跌、成交额概览
- **恐贪指数**：量化市场短期情绪（恐慌 / 贪婪程度）
- **市场温度计**：综合评估市场热度与拥挤度
- **热门板块榜单**：当前资金关注的热点方向
- **后市展望**：机构对后续市场走势的综合观点

## 触发场景

- "今天大盘怎么样？"
- "现在市场情绪如何？适合入场吗？"
- "最近哪些板块最热？"
- "市场整体还有多大上涨空间？"

## 执行步骤

### 场景 A：快速市场概览

并行调用以下工具，`date` 可省略（默认当天）：

```json
调用工具: mktLatestSummary
参数: {}

调用工具: aShareMarketQuotes
参数: { "date": "YYYY-MM-DD" }

调用工具: aShareFearGreedIndex
参数: { "date": "YYYY-MM-DD" }

调用工具: aShareTemperature
参数: { "date": "YYYY-MM-DD" }

调用工具: queryHotSector
参数: {}
```

### 场景 B：后市展望

```json
调用工具: mktForwardLook
参数: { "date": "YYYY-MM-DD" }
```

### 场景 C：完整市场分析报告

依次执行场景 A 的所有工具 + 场景 B，整合输出以下章节：

1. **大盘行情** —— 来自 `mktLatestSummary` + `aShareMarketQuotes`
2. **市场情绪** —— 恐贪指数（`aShareFearGreedIndex`）+ 温度计（`aShareTemperature`）
3. **热门板块** —— 来自 `queryHotSector`
4. **后市观点** —— 来自 `mktForwardLook`
5. **综合研判** —— 结合以上数据给出简明判断

## 恐贪指数解读参考

| 指数区间 | 情绪含义 | 操作参考 |
|---|---|---|
| 0 – 20 | 极度恐慌 | 历史上往往是低点区域 |
| 20 – 40 | 恐慌 | 市场悲观，需关注超跌机会 |
| 40 – 60 | 中性 | 情绪均衡，关注结构性机会 |
| 60 – 80 | 贪婪 | 市场乐观，注意风险控制 |
| 80 – 100 | 极度贪婪 | 警惕高位回调风险 |

## 注意事项

- 数据仅反映当天市场状态，历史数据需指定 `date` 参数。
- 情绪指标为辅助参考，不构成买卖信号。
