---
name: browser-use
description: AI驱动的浏览器自动化 - 用自然语言描述任务，让AI自动控制浏览器完成网页操作。
allowed-tools: Bash(browser-use:*) Bash(npx:*) Bash(node:*)
---

# 浏览器自动化 (browser-use)

## 简介

browser-use 是一个基于 TypeScript 的 AI 浏览器自动化库，通过 LLM 让 AI 自主完成网页浏览、数据提取、表单填写等任务。与 playwright-cli（手动命令式）不同，browser-use 通过自然语言描述任务，AI 会自动决定如何操作浏览器。

## 快速上手

```bash
# 设置 API key（必需）
export ANTHROPIC_API_KEY=sk-ant-...  # 或 OPENAI_API_KEY 等

# 交互模式 - 启动 AI 浏览器会话
browser-use

# 单次任务 - AI 自动完成任务
browser-use "打开 example.com 并提取页面标题"

# 指定模型
browser-use --model claude-sonnet-4-20250514 -p "搜索 AI 新闻"

# 无头模式（不显示浏览器窗口）
browser-use --headless -p "查看天气"
```

## 支持的 LLM 提供商

- **OpenAI**: `OPENAI_API_KEY`
- **Anthropic**: `ANTHROPIC_API_KEY`
- **Google Gemini**: `GOOGLE_API_KEY`
- **AWS Bedrock**: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`
- **Azure**: `AZURE_OPENAI_API_KEY` 等
- **Groq**、**Ollama**、**DeepSeek**、**OpenRouter**、**Mistral**、**Cerebras**

## 环境配置

```bash
# 创建 .env 文件配置 API key
echo "ANTHROPIC_API_KEY=sk-ant-..." > .env

# 或直接导出
export OPENAI_API_KEY=sk-your-key
```

## 命令行选项

```bash
# 指定模型
browser-use --model gpt-4o -p "你的任务"
browser-use --model claude-sonnet-4-20250514 -p "你的任务"

# 无头模式（无可视化浏览器）
browser-use --headless -p "自动化任务"

# MCP 服务模式
browser-use --mcp

# 查看所有选项
browser-use --help
```

## 编程使用（JavaScript/TypeScript）

```javascript
import { Agent } from 'browser-use';
import { ChatAnthropic } from 'browser-use/llm/anthropic';

const agent = new Agent({
  task: '打开 google.com 搜索 "TypeScript 教程"',
  llm: new ChatAnthropic({
    model: 'claude-sonnet-4-20250514',
    apiKey: process.env.ANTHROPIC_API_KEY,
  }),
});

const history = await agent.run();
console.log('结果:', history.final_result());
console.log('成功:', history.is_successful());
```

## 示例任务

```bash
# 提取网页数据
browser-use "打开 news.ycombinator.com 列出前5条热门故事"

# 填写表单
browser-use "打开 example.com/login 填写登录表单"

# 多步骤工作流
browser-use "在亚马逊搜索一个产品，找到最便宜的并提取价格"

# 截图分析
browser-use "截取 example.com 的截图并描述你看到的内容"
```

## 与 playwright-cli 的区别

| playwright-cli | browser-use |
|----------------|-------------|
| 手动输入命令（点击、输入、跳转） | 自然语言描述任务 |
| 你控制每个操作 | AI 自主决定操作 |
| 基于快照的元素定位 | AI 理解页面上下文 |
| 不需要 LLM | 需要 LLM API key |

## 安装检查

```bash
# 验证 browser-use 是否已安装
npx browser-use --version

# 全局安装
npm install -g browser-use

# 未安装全局时使用 npx
npx browser-use "你的任务"
```

## 安全注意事项

- API key 是敏感信息 - 切勿提交 `.env` 文件
- 使用 `--allowed-domains` 限制浏览器访问范围
- 敏感数据可通过 `sensitive_data` 选项传递
