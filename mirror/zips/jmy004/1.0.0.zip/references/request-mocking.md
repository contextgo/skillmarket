# LLM Providers

browser-use supports 10+ LLM providers with a unified interface.

## Provider Configuration

```javascript
import { Agent } from 'browser-use';

// OpenAI
import { ChatOpenAI } from 'browser-use/llm/openai';
const llm = new ChatOpenAI({ model: 'gpt-4o', apiKey: process.env.OPENAI_API_KEY });

// Anthropic
import { ChatAnthropic } from 'browser-use/llm/anthropic';
const llm = new ChatAnthropic({ model: 'claude-sonnet-4-20250514', apiKey: process.env.ANTHROPIC_API_KEY });

// Google Gemini
import { ChatGoogle } from 'browser-use/llm/google';
const llm = new ChatGoogle('gemini-2.5-flash');

// AWS Bedrock
import { ChatAnthropicBedrock } from 'browser-use/llm/aws/chat-anthropic';

// Ollama (local)
import { ChatOllama } from 'browser-use/llm/ollama';
const llm = new ChatOllama('llama3', 'http://localhost:11434');
```

## Provider Comparison

| Provider | Vision | Reasoning Models | Local |
|----------|--------|------------------|-------|
| OpenAI | ✅ | o1/o3/o4 | ❌ |
| Anthropic | ✅ | Claude | ❌ |
| Google Gemini | ✅ | ✅ | ❌ |
| AWS Bedrock | ✅ | ✅ | ❌ |
| Groq | ❌ | ❌ | ❌ |
| Ollama | ❌ | ❌ | ✅ |
| DeepSeek | ❌ | ❌ | ❌ |

## Environment Variables

```bash
# API Keys
export OPENAI_API_KEY=sk-...
export ANTHROPIC_API_KEY=sk-ant-...
export GOOGLE_API_KEY=...
export AZURE_OPENAI_API_KEY=...
export OLLAMA_HOST=http://localhost:11434

# AWS (for Bedrock)
export AWS_ACCESS_KEY_ID=...
export AWS_SECRET_ACCESS_KEY=...
export AWS_REGION=us-east-1
```
