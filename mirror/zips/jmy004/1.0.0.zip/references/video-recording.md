# CLI Reference

Command-line interface for browser-use.

## Interactive Mode

```bash
# Start interactive session
browser-use

# Set model
browser-use --model claude-sonnet-4-20250514
```

## One-shot Tasks

```bash
# Single task
browser-use "Go to example.com and extract the title"

# With model
browser-use --model gpt-4o -p "Search for news"

# Headless
browser-use --headless -p "Check weather"
```

## Options

```bash
--model <name>        # LLM model to use
--headless           # Run without visible browser
--mcp                # Start as MCP server
--allowed-domains    # Comma-separated domain patterns
--max-steps          # Maximum steps per task
--debug              # Enable debug logging
```

## MCP Server Mode

```bash
# Start MCP server
browser-use --mcp

# With domain restrictions
browser-use --mcp --allowed-domains "*.google.com,*.github.com"
```

## Environment

```bash
# API key via environment
export ANTHROPIC_API_KEY=sk-ant-...
browser-use -p "your task"

# Or create .env file
echo "ANTHROPIC_API_KEY=sk-ant-..." > .env
```
