# MCP Server

browser-use can run as a Model Context Protocol (MCP) server, allowing integration with Claude Desktop and other MCP clients.

## Start MCP Server

```bash
# Start browser-use MCP server
browser-use --mcp
```

## MCP Tools Available

When connected as MCP server, the following tools are available:

- `browser_use_agent` - Run a browser automation task
- `browser_use_screenshot` - Take a screenshot
- `browser_use_navigate` - Navigate to URL
- `browser_use_click` - Click an element
- `browser_use_type` - Type text

## Claude Desktop Configuration

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "browser-use": {
      "command": "browser-use",
      "args": ["--mcp"]
    }
  }
}
```

## Security

- MCP server requires API key via environment variable
- Consider using `--allowed-domains` to restrict access
