# Observability

browser-use provides event system, telemetry, and session recording for debugging and analysis.

## Event System

Subscribe to agent events:

```javascript
import { Agent } from 'browser-use';

const agent = new Agent({ task, llm });

agent.on('action', (action) => {
  console.log('Action:', action.name, action.params);
});

agent.on('state', (state) => {
  console.log('State:', state.url, state.title);
});

agent.on('error', (error) => {
  console.error('Error:', error);
});

await agent.run();
```

## Agent History

After run, access full history:

```javascript
const history = await agent.run();

console.log('Final result:', history.final_result());
console.log('Success:', history.is_successful());
console.log('Steps:', history.steps);
console.log('Actions:', history.actions);
console.log('Errors:', history.errors);
```

## GIF Recording

Record agent sessions as GIF:

```javascript
const agent = new Agent({
  task,
  llm,
  enableRecording: true,
  recordingPath: './session.gif',
});

await agent.run();
```

## Debug Mode

Enable verbose logging:

```bash
# Via environment
export DEBUG=browser-use:*

# Via CLI
browser-use -p "task" --debug
```
