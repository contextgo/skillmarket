# Sensitive Data

browser-use provides secure handling for sensitive data like passwords and API keys.

## Sensitive Data in Tasks

```javascript
const agent = new Agent({
  task: 'Login to the dashboard',
  llm,
  sensitiveData: {
    '*.example.com': {
      username: process.env.SITE_USERNAME!,
      password: process.env.SITE_PASSWORD!,
    },
  },
});
```

## How It Works

- Sensitive data is masked in logs and outputs
- Only injected into pages matching the domain pattern
- Automatically redacted from screenshots and DOM snapshots

## Security Best Practices

1. Use environment variables for all secrets
2. Never commit `.env` files
3. Use domain-specific patterns (`*.example.com`)
4. Let browser-use handle injection automatically

## Cookies and Storage

For programmatic cookie management:

```javascript
import { Agent } from 'browser-use';

const agent = new Agent({
  task: 'Extract cookies from example.com',
  llm,
});

// Access cookies through the controller after run
const controller = agent.controller;
const cookies = await controller.browser.getCookies();
```
