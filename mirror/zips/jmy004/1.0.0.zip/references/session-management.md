# Programmatic Usage

Complete examples for using browser-use in JavaScript/TypeScript.

## Basic Example

```javascript
import { Agent } from 'browser-use';
import { ChatAnthropic } from 'browser-use/llm/anthropic';

const llm = new ChatAnthropic({
  model: 'claude-sonnet-4-20250514',
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const agent = new Agent({
  task: 'Go to google.com and search for "TypeScript tutorials"',
  llm,
});

const history = await agent.run();
console.log('Result:', history.final_result());
```

## Data Extraction

```javascript
const agent = new Agent({
  task: `Go to amazon.com, search for "wireless keyboard",
         extract the name, price, and rating of the first 5 products as JSON`,
  llm,
  useVision: true,
});

const history = await agent.run(30); // max 30 steps
console.log(history.final_result());
```

## Form Filling

```javascript
const agent = new Agent({
  task: 'Login to example.com with username and password',
  llm,
  sensitiveData: {
    '*.example.com': {
      username: 'user@example.com',
      password: 'secret123',
    },
  },
});

const history = await agent.run();
```

## Multi-step Workflows

```javascript
const agent = new Agent({
  task: `Search for weather in Tokyo,
         then search for attractions,
         then extract the top 3 recommendations`,
  llm,
  maxSteps: 50,
});

const history = await agent.run();
```

## With Custom Actions

```javascript
import { Agent, Controller } from 'browser-use';
import { z } from 'zod';

const controller = new Controller();

controller.registry.registerAction({
  name: 'take_notes',
  description: 'Save information to a notes file',
  schema: z.object({
    content: z.string(),
    filename: z.string().optional(),
  }),
  handler: async ({ content, filename = 'notes.txt' }) => {
    await Bun.write(filename, content);
    return { success: true };
  },
});

const agent = new Agent({
  task: 'Browse to docs.example.com and save the main headings to notes.txt',
  llm,
  controller,
});

const history = await agent.run();
```

## Headless Mode

```javascript
const agent = new Agent({
  task: 'Take a screenshot of example.com',
  llm,
  headless: true,
});
```

## With Vision

```javascript
const agent = new Agent({
  task: 'Describe what you see on the homepage',
  llm,
  useVision: true,
});
```
