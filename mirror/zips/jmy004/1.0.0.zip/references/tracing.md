# Custom Actions

browser-use has an extensible action registry with Zod schema validation.

## Built-in Actions

45+ built-in actions covering:
- **Navigation**: go_back, go_forward, reload, navigate
- **Interaction**: click, double_click, hover, type, fill, select, check, uncheck
- **Content**: extract_content, get_title, get_url, get_visible_text
- **Storage**: get_cookies, set_cookies, get_local_storage, set_local_storage
- **Page**: screenshot, scroll, resize
- **Tabs**: new_tab, close_tab, switch_tab
- **Dialogs**: accept_dialog, dismiss_dialog

## Using Actions

Actions are triggered by natural language - the LLM decides which action to use based on the task.

```javascript
const agent = new Agent({
  task: 'Click the submit button and take a screenshot',
  llm,
});

// Agent will use:
// 1. extract_content to find the submit button
// 2. click action to click it
// 3. screenshot action to capture the result
```

## Custom Action Registry

For advanced use cases, extend the registry:

```javascript
import { Controller } from 'browser-use';

const controller = new Controller();

controller.registry.registerAction({
  name: 'my_custom_action',
  description: 'Does something specific',
  schema: z.object({
    param: z.string(),
  }),
  handler: async (params, context) => {
    // Custom logic
    return { success: true };
  },
});
```
