# Browser-Use Architecture

browser-use uses an AI Agent to autonomously control the browser. The Agent follows an observe → think → act loop.

## Core Components

| Component | Description |
|-----------|-------------|
| **Agent** | Central orchestrator - runs the observe → think → act loop |
| **Controller** | Manages action registration and execution via Registry |
| **BrowserSession** | Playwright wrapper - browser lifecycle, tab management, screenshots |
| **DomService** | Extracts interactive elements with indexed mapping for LLM |
| **MessageManager** | Manages LLM conversation history with token optimization |
| **LLM Providers** | Unified interface across 10+ providers |

## How It Works

1. **Agent** receives a natural language task
2. **DomService** extracts current page state (elements + screenshot)
3. **LLM** analyzes state and returns actions
4. **Controller** validates and executes actions through Registry
5. Results feed back to LLM for next step
6. Loop continues until `done` action or `max_steps`

## Available Actions

browser-use has 45+ built-in actions including:
- Navigation: `go_back`, `go_forward`, `reload`
- Interaction: `click`, `type`, `fill`, `hover`, `select`
- Content: `extract_content`, `get_title`, `get_url`
- Storage: `get_cookies`, `set_cookies`, `get_local_storage`
- And more...
