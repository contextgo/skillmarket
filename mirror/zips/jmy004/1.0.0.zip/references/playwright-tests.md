# Session Management

browser-use manages browser sessions automatically through the Agent. You don't manually control sessions - the Agent handles browser lifecycle.

## Programmatic Session Control

```javascript
import { Agent } from 'browser-use';
import { BrowserSession } from 'browser-use/browser';

const agent = new Agent({
  task: 'your task',
  llm,
  maxSteps: 50,
});

// Agent.run() handles browser open/close automatically
const history = await agent.run();
```

## Direct BrowserSession Usage

For advanced control:

```javascript
import { BrowserSession } from 'browser-use/browser';

const session = await BrowserSession.launch({
  headless: true,
  profileName: 'default',
});

await session.navigate('https://example.com');
const screenshot = await session.screenshot();
const dom = await session.getDom();

await session.close();
```

## Browser Options

```javascript
// Headless mode
const session = await BrowserSession.launch({ headless: true });

// Specific browser
const session = await BrowserSession.launch({ 
  browser: 'chromium', // chromium, firefox, webkit
});

// With profile
const session = await BrowserSession.launch({
  persistent: true,
  profilePath: './my-profile',
});

// Window size
const session = await BrowserSession.launch({
  viewport: { width: 1920, height: 1080 },
});
```

## Multiple Agents

Run multiple agents concurrently for parallel tasks:

```javascript
const [agent1, agent2, agent3] = await Promise.all([
  new Agent({ task: 'Task 1', llm }).run(),
  new Agent({ task: 'Task 2', llm }).run(),
  new Agent({ task: 'Task 3', llm }).run(),
]);
```
