"""
《西游记》原文导入脚本
支持多种格式的文本文件，自动解析并导入数据库
"""

import json
import re
import os
from pathlib import Path

class XiYouJiImporter:
    """《西游记》原文导入器"""
    
    def __init__(self, db_path: str = "data/原文库/original_texts.json"):
        self.db_path = db_path
        self.texts = []
        self.index = {
            "theme": {},
            "person": {},
            "keyword": {}
        }
        
        # 尝试加载现有数据
        self.load_existing()
    
    def load_existing(self):
        """加载现有数据库"""
        if os.path.exists(self.db_path):
            with open(self.db_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.texts = data.get('texts', [])
                self.index = data.get('index', {"theme": {}, "person": {}, "keyword": {}})
            print(f"✓ 已加载现有数据库，包含 {len(self.texts)} 个切片")
        else:
            print("⚠ 数据库文件不存在，将创建新数据库")
    
    def parse_text_file(self, file_path: str) -> list:
        """
        解析文本文件
        
        支持格式：
        1. 标准回目格式：第X回 回目名称
        2. 简单格式：每行一段原文
        """
        print(f"📖 正在解析文件：{file_path}")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 尝试检测格式
        if "第" in content and "回" in content:
            return self._parse_hui_format(content)
        else:
            return self._parse_simple_format(content)
    
    def _parse_hui_format(self, content: str) -> list:
        """解析回目格式（中华书局/人民文学出版社等）"""
        slices = []
        
        # 使用正则表达式分割回目
        # 匹配模式：第X回 + 回目名称
        pattern = r'(第[一二三四五六七八九十百]+回\s*[^\n]*)'
        
        # 按回目分割
        parts = re.split(pattern, content)
        
        print(f"  检测到回目格式，找到 {(len(parts) - 1) // 2} 个回目")
        
        # 重组：parts[0]是前言，之后是 回目名+内容 交替
        i = 1
        while i < len(parts):
            if i + 1 < len(parts):
                hui_name = parts[i].strip()
                hui_content = parts[i + 1].strip()
                
                # 切片（按300-800字切片）
                sub_slices = self._slice_text(hui_content)
                
                for j, slice_text in enumerate(sub_slices):
                    slices.append({
                        'hui': hui_name,
                        'text': slice_text,
                        'index': len(slices)
                    })
                
                i += 2
            else:
                break
        
        print(f"  共生成 {len(slices)} 个切片")
        return slices
    
    def _parse_simple_format(self, content: str) -> list:
        """解析简单格式"""
        slices = []
        
        # 按双换行分割段落
        paragraphs = content.split('\n\n')
        
        for i, para in enumerate(paragraphs):
            para = para.strip()
            if not para:
                continue
            
            slices.append({
                'hui': f"未命名回目_{i+1}",
                'text': para,
                'index': i
            })
        
        print(f"  检测到简单格式，找到 {len(slices)} 个段落")
        return slices
    
    def _slice_text(self, text: str, min_len: int = 300, max_len: int = 800) -> list:
        """将长文切片"""
        slices = []
        
        # 按句子分割（以句号、感叹号、问号分割）
        sentences = re.split(r'([。！？])', text)
        
        current_slice = ""
        i = 0
        while i < len(sentences):
            sentence = sentences[i]
            if i + 1 < len(sentences):
                sentence += sentences[i + 1]  # 加上标点符号
            i += 2
            
            if len(current_slice) + len(sentence) <= max_len:
                current_slice += sentence
            else:
                if len(current_slice) >= min_len:
                    slices.append(current_slice)
                    current_slice = sentence
                else:
                    current_slice += sentence
        
        if current_slice:
            slices.append(current_slice)
        
        return slices if slices else [text[:max_len]]
    
    def create_slices(self, parsed_data: list, source: str = "《西游记》", 
                      version: str = "中华书局本") -> int:
        """
        根据解析的数据创建切片
        返回创建的切片数量
        """
        count = 0
        
        for item in parsed_data:
            # 生成切片ID
            slice_id = f"xyj_{len(self.texts) + 1:05d}"
            
            # 创建切片对象
            text_slice = {
                "id": slice_id,
                "来源": source,
                "回目": item.get('hui', '未知回目'),
                "版本": version,
                "原文": item.get('text', ''),
                "切片起始": item.get('index', 0) * 100,  # 估算位置
                "切片结束": (item.get('index', 0) + 1) * 100,
                "字数": len(item.get('text', '')),
                "主题标签": self._extract_themes(item.get('text', '')),
                "难度标签": "入门",
                "人物": self._extract_persons(item.get('text', '')),
                "异文标注": [],
                "注疏引用": [],
                "解读状态": "未解读"
            }
            
            self.texts.append(text_slice)
            self._update_index(slice_id, text_slice)
            count += 1
        
        print(f"✓ 成功创建 {count} 个切片")
        return count
    
    def _extract_themes(self, text: str) -> list:
        """从文本中提取主题标签"""
        themes = []
        
        keywords = {
            "修行": ["修行", "悟", "禅", "佛", "道", "心猿", "意马"],
            "战斗": ["打", "战", "斗", "败", "胜", "擒", "拿"],
            "人性": ["心", "欲", "贪", "嗔", "痴", "爱", "恨"],
            "师徒": ["师父", "徒弟", "唐僧", "悟空", "八戒", "沙僧"],
            "神仙": ["仙", "佛", "菩萨", "天王", "星君"],
            "妖怪": ["妖", "精", "怪", "魔"],
            "社会讽刺": ["官", "君", "臣", "权", "势", "俸", "禄"]
        }
        
        for theme, words in keywords.items():
            if any(word in text for word in words):
                themes.append(theme)
        
        return themes if themes else ["未分类"]
    
    def _extract_persons(self, text: str) -> list:
        """从文本中提取人名"""
        persons = ["孙悟空", "唐僧", "猪八戒", "沙僧", "白龙马", 
                   "观音", "如来", "玉帝", "老君", "佛祖"]
        found = []
        for person in persons:
            if person in text and person not in found:
                found.append(person)
        return found
    
    def _update_index(self, slice_id: str, slice_data: dict):
        """更新索引"""
        # 主题索引
        for theme in slice_data.get("主题标签", []):
            if theme not in self.index["theme"]:
                self.index["theme"][theme] = []
            if slice_id not in self.index["theme"][theme]:
                self.index["theme"][theme].append(slice_id)
        
        # 人物索引
        for person in slice_data.get("人物", []):
            if person not in self.index["person"]:
                self.index["person"][person] = []
            if slice_id not in self.index["person"][person]:
                self.index["person"][person].append(slice_id)
    
    def save(self):
        """保存到数据库"""
        data = {
            "texts": self.texts,
            "index": self.index
        }
        
        # 确保目
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        
        with open(self.db_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        print(f"✓ 数据库已保存：{self.db_path}")
        print(f"  总计 {len(self.texts)} 个切片")
    
    def print_stats(self):
        """打印统计信息"""
        print("\n📊 数据库统计：")
        print(f"  总切片数：{len(self.texts)}")
        print(f"  主题分类：{len(self.index['theme'])} 个")
        print(f"  人物索引：{len(self.index['person'])} 个")
        
        # 按来源统计
        sources = {}
        for text in self.texts:
            source = text.get("来源", "未知")
            sources[source] = sources.get(source, 0) + 1
        
        print("\n  按来源统计：")
        for source, count in sources.items():
            print(f"    {source}: {count} 个切片")


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='导入《西游记》原文到数据库')
    parser.add_argument('--file', '-f', help='文本文件路径', required=True)
    parser.add_argument('--source', '-s', help='来源名称', default='《西游记》')
    parser.add_argument('--version', '-v', help='版本信息', default='中华书局本')
    parser.add_argument('--db', '-d', help='数据库路径', default='data/原文库/original_texts.json')
    
    args = parser.parse_args()
    
    # 检查文件是否存在
    if not os.path.exists(args.file):
        print(f"❌ 错误：文件不存在 - {args.file}")
        return
    
    # 创建导入器
    importer = XiYouJiImporter(args.db)
    
    # 解析文件
    parsed_data = importer.parse_text_file(args.file)
    
    if not parsed_data:
        print("⚠ 警告：没有解析到任何内容")
        return
    
    # 创建切片
    count = importer.create_slices(parsed_data, args.source, args.version)
    
    # 保存
    importer.save()
    
    # 打印统计
    importer.print_stats()


if __name__ == "__main__":
    main()
