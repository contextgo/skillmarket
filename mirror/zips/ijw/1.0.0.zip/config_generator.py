#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置文件生成器
为西游记虾配套工具生成各种配置文件
"""

import json
from pathlib import Path

class ConfigGenerator:
    """配置文件生成器类"""
    
    def __init__(self, base_dir: str = "C:/Workbuddy/skills/西游记"):
        self.base_dir = Path(base_dir)
        self.config_dir = self.base_dir / "config"
        self.config_dir.mkdir(parents=True, exist_ok=True)
    
    def generate_main_config(self) -> dict:
        """
        生成主配置文件 config.json
        
        Returns:
            dict: 配置字典
        """
        config = {
            "数据库路径": {
                "原文库": str(self.base_dir / "data/原文库"),
                "角度库": str(self.base_dir / "data/角度库"),
                "关联库": str(self.base_dir / "data/关联库"),
                "版本对照": str(self.base_dir / "data/版本对照")
            },
            "默认版本": "中华书局本",
            "备用版本": "人民文学出版社本",
            "切片长度范围": [300, 800],
            "异文处理策略": "正文用通行本，异文注脚注",
            "置信度阈值": {
                "高": "有明确版本依据和注疏支持",
                "中": "有注疏支持但存在争议",
                "低": "仅凭推测或单一来源"
            },
            "自动标注": {
                "主题标签": True,
                "人物提取": True,
                "难度评估": True
            },
            "标注格式": {
                "公众号长文": "脚注式",
                "知乎": "括号式",
                "今日头条": "括号式",
                "初稿": "独立标注式"
            },
            "角度分类权重": {
                "人物角度": 0.9,
                "社会讽刺角度": 0.95,
                "修行隐喻角度": 0.85,
                "权力结构角度": 0.9,
                "人性角度": 0.9
            },
            "关联类型权重": {
                "人物对照": 0.4,
                "人性共通": 0.3,
                "社会结构同构": 0.2,
                "反常识对照": 0.1
            },
            "质量评级标准": {
                "S级": "总分≥4.5",
                "A级": "总分≥3.5 且 <4.5",
                "B级": "总分≥2.5 且 <3.5",
                "C级": "总分≥1.5 且 <2.5",
                "D级": "总分<1.5"
            },
            "推荐数量": {
                "角度": 5,
                "关联": 5
            },
            "电视剧情节处理": {
                "六小龄童版": "标注为'电视剧改编'",
                "张纪中版": "标注为'电视剧改编'",
                "原著区分": "强制——电视剧情节不能当原著引用"
            }
        }
        
        # 保存配置
        config_path = self.config_dir / "config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 成功生成主配置文件：{config_path}")
        return config
    
    def generate_version_config(self) -> dict:
        """
        生成版本配置文件 version_config.json
        
        Returns:
            dict: 版本配置字典
        """
        config = {
            "主要版本": {
                "中华书局本": {
                    "全称": "《西游记》（中华书局）",
                    "出版社": "中华书局",
                    "出版年": "2005年",
                    "可靠性": "高",
                    "特点": "以世德堂本为底本，有注释",
                    "推荐使用场景": "主要参考版本"
                },
                "人民文学出版社本": {
                    "全称": "《西游记》（人民文学出版社）",
                    "出版社": "人民文学出版社",
                    "出版年": "1980年",
                    "可靠性": "高",
                    "特点": "通行本，注释丰富",
                    "推荐使用场景": "对照参考版本"
                },
                "世德堂本": {
                    "全称": "明万历世德堂本《新刻出像官板大字西游记》",
                    "出版社": "（古籍刻本）",
                    "出版年": "明万历",
                    "可靠性": "高",
                    "特点": "现存最早的完整刻本",
                    "推荐使用场景": "学术研究参考"
                }
            },
            "异文处理策略": {
                "默认策略": "正文用通行本，异文注脚注",
                "置信度阈值": {
                    "高": "有明确版本依据和注疏支持",
                    "中": "有注疏支持但存在争议",
                    "低": "仅凭推测或单一来源"
                }
            },
            "标注格式": {
                "公众号长文": "脚注式",
                "知乎": "括号式",
                "今日头条": "括号式",
                "初稿": "独立标注式"
            },
            "电视剧区分": {
                "强制规则": "电视剧情节不能当原著引用",
                "六小龄童版": "标注为'电视剧改编'",
                "张纪中版": "标注为'电视剧改编'"
            }
        }
        
        # 保存配置
        config_path = self.config_dir / "version_config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 成功生成版本配置文件：{config_path}")
        return config
    
    def generate_angle_config(self) -> dict:
        """
        生成角度配置文件 angle_config.json
        
        Returns:
            dict: 角度配置字典
        """
        config = {
            "角度分类": {
                "人物角度": {
                    "权重": 0.9,
                    "适用平台": ["公众号长文", "知乎"],
                    "最小字数": 1500,
                    "描述": "孙悟空/唐僧/猪八戒/沙僧的性格与成长"
                },
                "社会讽刺角度": {
                    "权重": 0.95,
                    "适用平台": ["公众号长文"],
                    "最小字数": 1500,
                    "描述": "吴承恩对明朝官场的讽刺"
                },
                "修行隐喻角度": {
                    "权重": 0.85,
                    "适用平台": ["公众号长文", "知乎"],
                    "最小字数": 1200,
                    "描述": "佛法修行的隐喻（断三毒、修戒定慧）"
                },
                "权力结构角度": {
                    "权重": 0.9,
                    "适用平台": ["公众号长文", "知乎"],
                    "最小字数": 1200,
                    "描述": "天庭/佛界/妖界的权力关系"
                },
                "人性角度": {
                    "权重": 0.9,
                    "适用平台": ["公众号长文", "今日头条"],
                    "最小字数": 800,
                    "描述": "人物心理、动机分析、团队协作"
                }
            },
            "匹配规则": {
                "主题匹配权重": 0.4,
                "难度匹配权重": 0.3,
                "历史数据权重": 0.3
            },
            "自动推荐数量": 5
        }
        
        # 保存配置
        config_path = self.config_dir / "angle_config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 成功生成角度配置文件：{config_path}")
        return config
    
    def generate_connection_config(self) -> dict:
        """
        生成关联配置文件 connection_config.json
        
        Returns:
            dict: 关联配置字典
        """
        config = {
            "关联类型权重": {
                "人物对照": 0.4,
                "人性共通": 0.3,
                "社会结构同构": 0.2,
                "反常识对照": 0.1
            },
            "质量评级标准": {
                "S级": "总分≥4.5",
                "A级": "总分≥3.5 且 <4.5",
                "B级": "总分≥2.5 且 <3.5",
                "C级": "总分≥1.5 且 <2.5",
                "D级": "总分<1.5"
            },
            "伪关联检测规则": {
                "表面相似陷阱": True,
                "强行附会陷阱": True,
                "时代错误陷阱": True,
                "电视剧情节陷阱": True
            },
            "推荐数量": 5,
            "质量检测维度": {
                "人物相似性": {
                    "权重": 0.4,
                    "描述": "西游人物与现代角色的相似性？"
                },
                "人性共通性": {
                    "权重": 0.3,
                    "描述": "人性反应是否相同？"
                },
                "社会结构同构性": {
                    "权重": 0.2,
                    "描述": "社会结构是否相同？"
                },
                "反常识性": {
                    "权重": 0.1,
                    "描述": "是否有反常识洞察？"
                }
            }
        }
        
        # 保存配置
        config_path = self.config_dir / "connection_config.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 成功生成关联配置文件：{config_path}")
        return config
    
    def generate_all_configs(self) -> dict:
        """
        生成所有配置文件
        
        Returns:
            dict: 所有配置的字典
        """
        print("开始生成所有配置文件...")
        
        configs = {
            "config.json": self.generate_main_config(),
            "version_config.json": self.generate_version_config(),
            "angle_config.json": self.generate_angle_config(),
            "connection_config.json": self.generate_connection_config()
        }
        
        print("✅ 所有配置文件生成完成！")
        return configs


def main():
    """主函数"""
    generator = ConfigGenerator()
    generator.generate_all_configs()


if __name__ == "__main__":
    main()
