#!/usr/bin/env python3
"""
Cache Manager for Arshis-memory-pro

Provides caching for:
- Embedding vectors (avoid recomputation)
- Search results (avoid repeated queries)
- LLM responses (avoid repeated generation)

Features:
- LRU eviction
- TTL expiration
- Memory limit
- Disk persistence (optional)
"""

import hashlib
import json
import os
import time
from collections import OrderedDict
from typing import Any, Dict, List, Optional


class LRUCache:
    """LRU Cache with TTL support"""
    
    def __init__(self, max_size: int = 1000, ttl: int = 3600):
        """
        Initialize LRU Cache
        
        Args:
            max_size: Maximum number of items
            ttl: Time to live in seconds (default: 1 hour)
        """
        self.cache: OrderedDict = OrderedDict()
        self.timestamps: Dict[str, float] = {}
        self.max_size = max_size
        self.ttl = ttl
        self.hits = 0
        self.misses = 0
    
    def _generate_key(self, data: Any) -> str:
        """Generate cache key from data"""
        if isinstance(data, str):
            return hashlib.md5(data.encode()).hexdigest()
        elif isinstance(data, dict):
            return hashlib.md5(json.dumps(data, sort_keys=True).encode()).hexdigest()
        else:
            return hashlib.md5(str(data).encode()).hexdigest()
    
    def get(self, key: str) -> Optional[Any]:
        """Get item from cache"""
        if key not in self.cache:
            self.misses += 1
            return None
        
        # Check TTL
        if time.time() - self.timestamps[key] > self.ttl:
            del self.cache[key]
            del self.timestamps[key]
            self.misses += 1
            return None
        
        # Move to end (most recently used)
        self.cache.move_to_end(key)
        self.hits += 1
        return self.cache[key]
    
    def set(self, key: str, value: Any):
        """Set item in cache"""
        if key in self.cache:
            self.cache.move_to_end(key)
        
        self.cache[key] = value
        self.timestamps[key] = time.time()
        
        # Evict oldest if over limit
        while len(self.cache) > self.max_size:
            oldest_key = next(iter(self.cache))
            del self.cache[oldest_key]
            del self.timestamps[oldest_key]
    
    def delete(self, key: str):
        """Delete item from cache"""
        if key in self.cache:
            del self.cache[key]
            del self.timestamps[key]
    
    def clear(self):
        """Clear all items from cache"""
        self.cache.clear()
        self.timestamps.clear()
        self.hits = 0
        self.misses = 0
    
    def stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total = self.hits + self.misses
        hit_rate = (self.hits / total * 100) if total > 0 else 0
        
        return {
            "size": len(self.cache),
            "max_size": self.max_size,
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": f"{hit_rate:.2f}%",
            "ttl": self.ttl
        }


class CacheManager:
    """Cache Manager for Arshis-memory-pro"""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize Cache Manager
        
        Args:
            config: Cache configuration
        """
        self.config = config or {
            "enabled": True,
            "max_size": 1000,
            "ttl": 3600,
            "persist": False,
            "persist_path": "/root/.openclaw/data/memory-custom/cache.json"
        }
        
        self.enabled = self.config.get("enabled", True)
        
        # Initialize caches
        self.embedding_cache = LRUCache(
            max_size=self.config.get("max_size", 1000),
            ttl=self.config.get("ttl", 3600)
        )
        
        self.search_cache = LRUCache(
            max_size=500,
            ttl=self.config.get("ttl", 1800)
        )
        
        self.llm_cache = LRUCache(
            max_size=200,
            ttl=self.config.get("ttl", 7200)
        )
        
        # Load persistent cache if enabled
        if self.config.get("persist", False):
            self._load_cache()
    
    def get_embedding(self, text: str) -> Optional[List[float]]:
        """Get cached embedding"""
        if not self.enabled:
            return None
        
        key = self.embedding_cache._generate_key(text)
        return self.embedding_cache.get(key)
    
    def set_embedding(self, text: str, embedding: List[float]):
        """Cache embedding"""
        if not self.enabled:
            return
        
        key = self.embedding_cache._generate_key(text)
        self.embedding_cache.set(key, embedding)
    
    def get_search(self, query: str) -> Optional[List[Dict]]:
        """Get cached search results"""
        if not self.enabled:
            return None
        
        key = self.search_cache._generate_key(query)
        return self.search_cache.get(key)
    
    def set_search(self, query: str, results: List[Dict]):
        """Cache search results"""
        if not self.enabled:
            return
        
        key = self.search_cache._generate_key(query)
        self.search_cache.set(key, results)
    
    def get_llm(self, prompt: str) -> Optional[str]:
        """Get cached LLM response"""
        if not self.enabled:
            return None
        
        key = self.llm_cache._generate_key(prompt)
        return self.llm_cache.get(key)
    
    def set_llm(self, prompt: str, response: str):
        """Cache LLM response"""
        if not self.enabled:
            return
        
        key = self.llm_cache._generate_key(prompt)
        self.llm_cache.set(key, response)
    
    def clear_all(self):
        """Clear all caches"""
        self.embedding_cache.clear()
        self.search_cache.clear()
        self.llm_cache.clear()
    
    def stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        return {
            "enabled": self.enabled,
            "embedding": self.embedding_cache.stats(),
            "search": self.search_cache.stats(),
            "llm": self.llm_cache.stats()
        }
    
    def _load_cache(self):
        """Load persistent cache from disk"""
        persist_path = self.config.get("persist_path")
        if not os.path.exists(persist_path):
            return
        
        try:
            with open(persist_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Restore caches
            # (Implementation depends on persistence format)
            print(f"[INFO] Loaded persistent cache from {persist_path}")
        
        except Exception as e:
            print(f"[WARN] Failed to load cache: {e}")
    
    def _save_cache(self):
        """Save persistent cache to disk"""
        persist_path = self.config.get("persist_path")
        
        try:
            os.makedirs(os.path.dirname(persist_path), exist_ok=True)
            
            with open(persist_path, 'w', encoding='utf-8') as f:
                json.dump({
                    "embedding": dict(self.embedding_cache.cache),
                    "search": dict(self.search_cache.cache),
                    "llm": dict(self.llm_cache.cache)
                }, f, indent=2, ensure_ascii=False)
            
            print(f"[INFO] Saved persistent cache to {persist_path}")
        
        except Exception as e:
            print(f"[WARN] Failed to save cache: {e}")


def main():
    """Main function for testing"""
    
    print("Arshis-memory-pro Cache Manager")
    print("=" * 60)
    
    # Initialize cache manager
    cache = CacheManager({
        "enabled": True,
        "max_size": 100,
        "ttl": 60
    })
    
    # Test embedding cache
    print("\n[TEST] Embedding Cache")
    text = "This is a test sentence"
    embedding = [0.1, 0.2, 0.3, 0.4, 0.5]
    
    cache.set_embedding(text, embedding)
    cached = cache.get_embedding(text)
    
    print(f"  Set: {text}")
    print(f"  Get: {cached}")
    print(f"  Match: {cached == embedding}")
    
    # Test search cache
    print("\n[TEST] Search Cache")
    query = "test query"
    results = [{"id": 1, "score": 0.9}, {"id": 2, "score": 0.8}]
    
    cache.set_search(query, results)
    cached = cache.get_search(query)
    
    print(f"  Set: {query}")
    print(f"  Get: {cached}")
    print(f"  Match: {cached == results}")
    
    # Test stats
    print("\n[TEST] Cache Statistics")
    stats = cache.stats()
    print(f"  Enabled: {stats['enabled']}")
    print(f"  Embedding: {stats['embedding']}")
    print(f"  Search: {stats['search']}")
    print(f"  LLM: {stats['llm']}")
    
    print("\n" + "=" * 60)
    print("[OK] Cache Manager test completed")


if __name__ == "__main__":
    main()
