#!/usr/bin/env python3
"""
HTTP API Server for Arshis-memory-pro

Provides REST API for platform integration:
- GET /api/dreaming - Get dreaming data
- POST /api/wiki/importInsights - Import sleep/dream data
- GET /api/wiki/palace - Platform status check
- GET /api/stats - Get statistics
- GET /api/plugin/info - Get plugin info

Usage:
    python3 api_server.py [--port 8080]
"""

import json
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

# Import plugin functions
sys.path.insert(0, '/root/.openclaw/workspace/策划 skill/Arshis-memory-pro/scripts')
from hook_integration import (
    get_dreaming_data,
    wiki_importInsights,
    wiki_palace,
    get_stats,
    get_plugin_info
)


class APIHandler(BaseHTTPRequestHandler):
    """HTTP API Handler"""
    
    def do_GET(self):
        """Handle GET requests"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        try:
            if path == '/api/dreaming':
                data = get_dreaming_data()
                self.send_response(200, data)
            
            elif path == '/api/wiki/palace':
                data = wiki_palace()
                self.send_response(200, data)
            
            elif path == '/api/stats':
                data = get_stats()
                self.send_response(200, data)
            
            elif path == '/api/plugin/info':
                data = get_plugin_info()
                self.send_response(200, data)
            
            else:
                self.send_response(404, {"error": "Not found"})
        
        except Exception as e:
            self.send_response(500, {"error": str(e)})
    
    def do_POST(self):
        """Handle POST requests"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        try:
            # Read request body
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8')) if post_data else {}
            
            if path == '/api/wiki/importInsights':
                result = wiki_importInsights(data)
                self.send_response(200, result)
            
            else:
                self.send_response(404, {"error": "Not found"})
        
        except Exception as e:
            self.send_response(500, {"error": str(e)})
    
    def send_response(self, status_code, data):
        """Send JSON response"""
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2).encode('utf-8'))
    
    def log_message(self, format, *args):
        """Suppress default logging"""
        pass


def run_server(port=8080):
    """Run HTTP API server"""
    server_address = ('', port)
    httpd = HTTPServer(server_address, APIHandler)
    
    print(f"Arshis-memory-pro API Server")
    print(f"=" * 60)
    print(f"Listening on port {port}")
    print(f"")
    print(f"Available endpoints:")
    print(f"  GET  /api/dreaming           - Get dreaming data")
    print(f"  GET  /api/wiki/palace        - Platform status")
    print(f"  POST /api/wiki/importInsights - Import sleep/dream data")
    print(f"  GET  /api/stats              - Get statistics")
    print(f"  GET  /api/plugin/info        - Get plugin info")
    print(f"")
    print(f"Press Ctrl+C to stop")
    print(f"=" * 60)
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
        httpd.shutdown()


if __name__ == "__main__":
    port = 8080
    
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print(f"Invalid port: {sys.argv[1]}")
            sys.exit(1)
    
    run_server(port)
