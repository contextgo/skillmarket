#!/usr/bin/env python3
"""
Dream Manager for Arshis-memory-pro

Features:
- Record dreams and inspirations
- Automatic consolidation during "sleep"
- Morning briefing generation
- Creative incubation tracking
- Dream pattern analysis
"""

import json
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional


class DreamManager:
    """Dream Manager"""
    
    def __init__(self, dreams_path: str = "/root/.openclaw/data/memory-custom/dreams.json"):
        """
        Initialize Dream Manager
        
        Args:
            dreams_path: Path to dreams file
        """
        self.dreams_path = dreams_path
        self.dreams = self._load_dreams()
        self.improvements = []
    
    def _load_dreams(self) -> List[Dict]:
        """Load dreams from file"""
        if not os.path.exists(self.dreams_path):
            return []
        
        try:
            with open(self.dreams_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"[WARN] Failed to load dreams: {e}")
            return []
    
    def _save_dreams(self):
        """Save dreams to file"""
        try:
            os.makedirs(os.path.dirname(self.dreams_path), exist_ok=True)
            
            with open(self.dreams_path, 'w', encoding='utf-8') as f:
                json.dump(self.dreams, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[WARN] Failed to save dreams: {e}")
    
    def record(self, content: str, tags: List[str] = None, category: str = "梦境/灵感"):
        """
        Record a dream
        
        Args:
            content: Dream content
            tags: Tags for categorization
            category: Dream category
        """
        dream = {
            "id": len(self.dreams) + 1,
            "content": content,
            "created_at": datetime.now().isoformat(),
            "category": category,
            "tags": tags or [],
            "consolidated": False,
            "improvements": []
        }
        
        self.dreams.append(dream)
        self._save_dreams()
        
        print(f"[OK] Dream recorded: {content[:50]}...")
        return dream
    
    def incubate(self, question: str):
        """
        Set creative incubation question
        
        Args:
            question: Question to incubate
        """
        dream = {
            "id": len(self.dreams) + 1,
            "content": f"[Incubation] {question}",
            "created_at": datetime.now().isoformat(),
            "category": "创意孵化",
            "tags": ["incubation", "question"],
            "consolidated": False,
            "improvements": []
        }
        
        self.dreams.append(dream)
        self._save_dreams()
        
        print(f"[OK] Incubation question recorded: {question}")
        return dream
    
    def consolidate(self):
        """
        Consolidate dreams (simulate sleep processing)
        
        This is a simplified version. In future versions,
        this will use LLM to analyze and consolidate dreams.
        """
        unconsolidated = [d for d in self.dreams if not d.get('consolidated', False)]
        
        if not unconsolidated:
            print("[INFO] No unconsolidated dreams")
            return []
        
        improvements = []
        for dream in unconsolidated:
            # Simple consolidation logic
            # In v4.0.0, this will use LLM for analysis
            improvement = {
                "dream_id": dream['id'],
                "consolidated_at": datetime.now().isoformat(),
                "type": "basic_consolidation",
                "note": "Dream consolidated (basic)"
            }
            
            dream['consolidated'] = True
            dream['improvements'].append(improvement)
            improvements.append(improvement)
        
        self._save_dreams()
        
        print(f"[OK] Consolidated {len(improvements)} dreams")
        return improvements
    
    def morning_brief(self) -> str:
        """
        Generate morning briefing
        
        Returns:
            Morning briefing text
        """
        # Get dreams from last night (after 6 PM yesterday)
        yesterday = datetime.now() - timedelta(days=1)
        yesterday_6pm = yesterday.replace(hour=18, minute=0, second=0)
        
        nights_dreams = [
            d for d in self.dreams
            if datetime.fromisoformat(d['created_at']) > yesterday_6pm
        ]
        
        if not nights_dreams:
            return "No dreams recorded last night."
        
        briefing = "Morning Briefing\n"
        briefing += "=" * 60 + "\n\n"
        
        # Dreams
        briefing += f"Dreams Recorded: {len(nights_dreams)}\n\n"
        for i, dream in enumerate(nights_dreams, 1):
            briefing += f"{i}. {dream['content'][:100]}...\n"
            if dream.get('tags'):
                briefing += f"   Tags: {', '.join(dream['tags'])}\n"
        
        # Consolidation status
        consolidated_count = sum(1 for d in nights_dreams if d.get('consolidated', False))
        briefing += f"\nConsolidated: {consolidated_count}/{len(nights_dreams)}\n"
        
        # Improvements
        total_improvements = sum(len(d.get('improvements', [])) for d in nights_dreams)
        briefing += f"Improvements: {total_improvements}\n"
        
        briefing += "\n" + "=" * 60 + "\n"
        briefing += "Have a productive day!\n"
        
        return briefing
    
    def list_dreams(self, limit: int = 10, category: str = None) -> List[Dict]:
        """
        List dreams
        
        Args:
            limit: Maximum number of dreams to return
            category: Filter by category
        
        Returns:
            List of dreams
        """
        dreams = self.dreams
        
        if category:
            dreams = [d for d in dreams if d.get('category') == category]
        
        # Sort by created_at (newest first)
        dreams = sorted(dreams, key=lambda x: x['created_at'], reverse=True)
        
        return dreams[:limit]
    
    def search(self, keyword: str) -> List[Dict]:
        """
        Search dreams
        
        Args:
            keyword: Search keyword
        
        Returns:
            List of matching dreams
        """
        results = []
        for dream in self.dreams:
            content = dream.get('content', '').lower()
            tags = ' '.join(dream.get('tags', [])).lower()
            
            if keyword.lower() in content or keyword.lower() in tags:
                results.append(dream)
        
        return results
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get dream statistics
        
        Returns:
            Statistics dictionary
        """
        total = len(self.dreams)
        consolidated = sum(1 for d in self.dreams if d.get('consolidated', False))
        total_improvements = sum(len(d.get('improvements', [])) for d in self.dreams)
        
        # By category
        by_category = {}
        for dream in self.dreams:
            category = dream.get('category', 'Unknown')
            by_category[category] = by_category.get(category, 0) + 1
        
        # By date (last 7 days)
        by_date = {}
        seven_days_ago = datetime.now() - timedelta(days=7)
        for dream in self.dreams:
            date = dream['created_at'][:10]
            dream_date = datetime.fromisoformat(dream['created_at'])
            if dream_date > seven_days_ago:
                by_date[date] = by_date.get(date, 0) + 1
        
        return {
            "total_dreams": total,
            "consolidated": consolidated,
            "unconsolidated": total - consolidated,
            "total_improvements": total_improvements,
            "by_category": by_category,
            "by_date_last_7_days": by_date
        }
    
    def clear(self):
        """Clear all dreams"""
        self.dreams = []
        self._save_dreams()
        print("[INFO] All dreams cleared")
    
    def print_report(self):
        """Print dream report"""
        stats = self.get_stats()
        
        print("\n" + "=" * 60)
        print("Arshis-memory-pro Dream Statistics")
        print("=" * 60)
        
        print(f"\nTotal Dreams: {stats['total_dreams']}")
        print(f"Consolidated: {stats['consolidated']}")
        print(f"Unconsolidated: {stats['unconsolidated']}")
        print(f"Total Improvements: {stats['total_improvements']}")
        
        print("\nBy Category:")
        for category, count in stats['by_category'].items():
            print(f"  {category}: {count}")
        
        print("\nLast 7 Days:")
        for date, count in sorted(stats['by_date_last_7_days'].items()):
            print(f"  {date}: {count} dreams")
        
        print("\n" + "=" * 60)


def main():
    """Main function for testing"""
    import sys
    
    dreams = DreamManager()
    
    if len(sys.argv) < 2:
        print("\nArshis-memory-pro Dream Manager")
        print("=" * 60)
        print("\nUsage:")
        print("  python3 dream_manager.py record <content>     # Record dream")
        print("  python3 dream_manager.py incubate <question>  # Set incubation")
        print("  python3 dream_manager.py consolidate          # Consolidate dreams")
        print("  python3 dream_manager.py morning-brief        # Morning briefing")
        print("  python3 dream_manager.py list [limit]         # List dreams")
        print("  python3 dream_manager.py search <keyword>     # Search dreams")
        print("  python3 dream_manager.py stats                # View statistics")
        print()
        return
    
    command = sys.argv[1]
    
    if command == "record":
        if len(sys.argv) < 3:
            print("[ERROR] Please provide dream content")
            return
        content = ' '.join(sys.argv[2:])
        dreams.record(content)
    
    elif command == "incubate":
        if len(sys.argv) < 3:
            print("[ERROR] Please provide incubation question")
            return
        question = ' '.join(sys.argv[2:])
        dreams.incubate(question)
    
    elif command == "consolidate":
        dreams.consolidate()
    
    elif command == "morning-brief":
        briefing = dreams.morning_brief()
        print(briefing)
    
    elif command == "list":
        limit = int(sys.argv[2]) if len(sys.argv) > 2 else 10
        dream_list = dreams.list_dreams(limit=limit)
        print(f"\nRecent Dreams ({len(dream_list)}):\n")
        for i, dream in enumerate(dream_list, 1):
            print(f"{i}. {dream['content'][:80]}...")
            print(f"   Date: {dream['created_at'][:10]}")
            print(f"   Tags: {', '.join(dream['tags']) if dream.get('tags') else 'None'}")
            print()
    
    elif command == "search":
        if len(sys.argv) < 3:
            print("[ERROR] Please provide search keyword")
            return
        keyword = ' '.join(sys.argv[2:])
        results = dreams.search(keyword)
        print(f"\nSearch Results for '{keyword}' ({len(results)}):\n")
        for i, dream in enumerate(results, 1):
            print(f"{i}. {dream['content'][:80]}...")
            print()
    
    elif command == "stats":
        dreams.print_report()
    
    else:
        print(f"[ERROR] Unknown command: {command}")


if __name__ == "__main__":
    main()
