#!/usr/bin/env python3
"""
Context Injection Control for Arshis-Memory-Pro v5.0.0

Prevents context explosion by controlling how much memory gets injected
into the conversation context.

Features:
- Default: summary-only mode (not full memory text)
- Max injection limit (default: 8 memories)
- Relevance threshold filtering (default: 0.72)
- Max context token limit (default: 12000)
- Low-relevance memories excluded from injection

Security: No network, no external calls. Purely local logic.
"""

import os
import sys
import json
from typing import Dict, List, Any, Optional

# Configuration from environment
CONFIG = {
    'max_injection': int(os.environ.get('MAX_MEMORY_INJECTION', '8')),
    'summary_only': os.environ.get('SUMMARY_ONLY_MODE', 'true').lower() == 'true',
    'relevance_threshold': float(os.environ.get('RELEVANCE_THRESHOLD', '0.72')),
    'max_context_tokens': int(os.environ.get('MAX_CONTEXT_TOKENS_FOR_MEMORY', '12000')),
}


def estimate_token_count(text: str) -> int:
    """Rough token count estimate (1 token ~= 4 chars for English, ~1.5 for Chinese)."""
    if not text:
        return 0
    # Simple heuristic: count Chinese chars separately
    chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    other_chars = len(text) - chinese_chars
    return int(chinese_chars * 1.5 + other_chars * 0.25)


def summarize_memory(memory: Dict) -> str:
    """Create a brief summary of a memory entry."""
    text = memory.get('text', '')
    importance = memory.get('importance', 0)
    category = memory.get('category', 'unknown')
    recall_count = memory.get('recall_count', 0)

    # Truncate text for summary
    if len(text) > 200:
        text = text[:200] + '...'

    return f"[{category}] (importance: {importance:.1f}, recalled: {recall_count}x) {text}"


def inject_memories(memories: List[Dict], query: str = None) -> Dict[str, Any]:
    """
    Process memories for context injection.

    Args:
        memories: List of memory entries (from retrieval)
        query: The original query that triggered recall (for relevance filtering)

    Returns:
        Dict with:
        - injected: List of memory summaries/texts to inject
        - total_tokens: Estimated token count
        - filtered_count: Number of memories filtered out
        - within_limit: Whether the injection is within token limit
        - mode: 'summary' or 'full' based on relevance
    """
    if not memories:
        return {
            'injected': [],
            'total_tokens': 0,
            'filtered_count': 0,
            'within_limit': True,
            'mode': 'none',
            'message': 'No memories to inject.',
        }

    # Step 1: Apply relevance threshold
    threshold = CONFIG['relevance_threshold']
    filtered = [m for m in memories if m.get('score', 0) >= threshold]
    filtered_count = len(memories) - len(filtered)

    if not filtered:
        return {
            'injected': [],
            'total_tokens': 0,
            'filtered_count': len(memories),
            'within_limit': True,
            'mode': 'filtered_all',
            'message': f'All {len(memories)} memories below relevance threshold ({threshold:.2f}). Nothing injected.',
        }

    # Step 2: Limit by max injection count
    max_count = CONFIG['max_injection']
    limited = filtered[:max_count]

    # Step 3: Determine summary vs full mode based on average relevance
    avg_score = sum(m.get('score', 0) for m in limited) / len(limited)
    use_summary = CONFIG['summary_only'] or avg_score < 0.85

    # Step 4: Build injection content
    injected = []
    total_tokens = 0
    for m in limited:
        if use_summary:
            content = summarize_memory(m)
        else:
            content = m.get('text', '')
        tokens = estimate_token_count(content)
        injected.append({
            'content': content,
            'tokens': tokens,
            'memory_id': m.get('id', ''),
            'importance': m.get('importance', 0),
            'category': m.get('category', 'unknown'),
        })
        total_tokens += tokens

    # Step 5: Check token limit
    within_limit = total_tokens <= CONFIG['max_context_tokens']

    # If over limit, progressively remove lowest-relevance memories
    while not within_limit and len(injected) > 1:
        injected.pop()  # Remove last (lowest relevance)
        total_tokens = sum(item['tokens'] for item in injected)
        within_limit = total_tokens <= CONFIG['max_context_tokens']

    return {
        'injected': injected,
        'total_tokens': total_tokens,
        'filtered_count': filtered_count,
        'within_limit': within_limit,
        'mode': 'summary' if use_summary else 'full',
        'config': CONFIG,
    }


def main():
    """CLI entry point."""
    if len(sys.argv) < 2:
        print(json.dumps({
            'usage': 'python3 context_injection.py <command>',
            'commands': {
                'test': 'Test injection with sample data',
                'config': 'Show current configuration',
            },
        }, indent=2))
        return

    cmd = sys.argv[1]

    if cmd == 'config':
        print(json.dumps(CONFIG, indent=2))

    elif cmd == 'test':
        # Test with sample memories
        sample = [
            {'id': '1', 'text': 'Test memory about game design patterns', 'score': 0.85, 'importance': 0.8, 'category': 'design', 'recall_count': 3},
            {'id': '2', 'text': 'Memory about Unity component architecture and singleton patterns', 'score': 0.72, 'importance': 0.6, 'category': 'technical', 'recall_count': 1},
            {'id': '3', 'text': 'Short note', 'score': 0.5, 'importance': 0.3, 'category': 'general', 'recall_count': 0},
        ]
        result = inject_memories(sample, query='game design')
        print(json.dumps(result, indent=2, ensure_ascii=False))

    else:
        print(f'Unknown command: {cmd}')
        sys.exit(1)


if __name__ == '__main__':
    main()
