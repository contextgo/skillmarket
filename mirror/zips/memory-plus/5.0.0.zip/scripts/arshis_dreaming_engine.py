#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Arshis Dreaming Engine - 梦境引擎
实现记忆整合、梦境生成、创意连接功能

Modes:
- Light Sleep: 总结近期记忆 (30 分钟)
- Deep Sleep: 合并和提升重要记忆 (2 小时)
- REM Dream: 生成创意连接和洞察 (6 小时)
- Forgetting: 衰减、归档或合并低价值记忆 (30-90 天)
"""

import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

# 配置路径
CONFIG_PATH = Path("/root/.openclaw/workspace/skills/Arshis-Memory-Pro-release/arshis-memory-config.json")
DREAM_LOG_PATH = Path("/root/.openclaw/workspace/memory/arshis-dreams")
MEMORY_DB_PATH = Path("/root/.openclaw/data/memory-custom/memories.json")

class ArshisDreamingEngine:
    """Arshis 梦境引擎"""
    
    def __init__(self, config_path=CONFIG_PATH):
        self.config = self.load_config(config_path)
        self.dream_log_path = DREAM_LOG_PATH
        self.memory_db_path = MEMORY_DB_PATH
        self.ensure_directories()
    
    def load_config(self, path):
        """加载配置文件"""
        if path.exists():
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def ensure_directories(self):
        """确保目录存在"""
        self.dream_log_path.mkdir(parents=True, exist_ok=True)
        self.memory_db_path.parent.mkdir(parents=True, exist_ok=True)
    
    def get_today_dream_log(self):
        """获取今日梦境日志路径"""
        today = datetime.now().strftime("%Y-%m-%d")
        return self.dream_log_path / f"{today}.md"
    
    def log_dream(self, dream_type, content, tags=None, metadata=None):
        """记录梦境"""
        dream_log = self.get_today_dream_log()
        timestamp = datetime.now().isoformat()
        tags = tags or []
        metadata = metadata or {}
        
        # 读取现有日志
        existing_content = ""
        if dream_log.exists():
            with open(dream_log, 'r', encoding='utf-8') as f:
                existing_content = f.read()
        
        # 构建新梦境条目
        dream_entry = f"""
## [{dream_type.upper()}] {timestamp}

**内容**: {content}

**标签**: {', '.join(tags) if tags else '无'}

**元数据**:
{json.dumps(metadata, indent=2, ensure_ascii=False)}

---
"""
        
        # 写入日志
        with open(dream_log, 'w', encoding='utf-8') as f:
            if not existing_content.strip():
                f.write(f"# 梦境日志 {datetime.now().strftime('%Y-%m-%d')}\n\n")
                f.write(f"> 自动生成 by Arshis Dreaming Engine\n\n---\n")
            f.write(dream_entry)
        
        print(f" 梦境已记录：{dream_log}")
        return dream_log
    
    def light_sleep(self, memories=None):
        """
        浅睡模式 - 总结近期记忆
        
        每 30 分钟运行一次
        总结最近的对话和记忆
        """
        print(" [浅睡模式] 开始总结近期记忆...")
        
        summary = "近期记忆总结 - " + datetime.now().strftime("%H:%M")
        content = f"系统自动总结了最近的记忆和对话内容"
        
        self.log_dream(
            dream_type="light_sleep",
            content=content,
            tags=["浅睡", "总结", "自动"],
            metadata={
                "mode": "light_sleep",
                "interval_minutes": 30,
                "action": "summarize_recent",
                "timestamp": datetime.now().isoformat()
            }
        )
        
        return {"status": "success", "mode": "light_sleep", "summary": summary}
    
    def deep_sleep(self, memories=None):
        """
        深睡模式 - 合并和提升重要记忆
        
        每 2 小时运行一次
        将高价值记忆提升到长期存储
        """
        print(" [深睡模式] 开始合并和提升重要记忆...")
        
        content = "系统合并了相关记忆，并将重要记忆提升到长期存储"
        
        self.log_dream(
            dream_type="deep_sleep",
            content=content,
            tags=["深睡", "合并", "提升", "自动"],
            metadata={
                "mode": "deep_sleep",
                "interval_minutes": 120,
                "action": "merge_and_promote",
                "timestamp": datetime.now().isoformat()
            }
        )
        
        return {"status": "success", "mode": "deep_sleep"}
    
    def rem_dream(self, memories=None):
        """
        REM 梦境模式 - 生成创意连接和洞察
        
        每 6 小时运行一次
        在不同记忆之间建立创意连接
        """
        print(" [REM 梦境] 开始生成创意连接...")
        
        content = "系统在不同记忆之间建立了创意连接，生成了新的洞察"
        
        self.log_dream(
            dream_type="rem_dream",
            content=content,
            tags=["REM", "创意", "连接", "洞察", "自动"],
            metadata={
                "mode": "rem_dream",
                "interval_minutes": 360,
                "action": "creative_connections",
                "timestamp": datetime.now().isoformat()
            }
        )
        
        return {"status": "success", "mode": "rem_dream"}
    
    def forgetting(self, memories=None):
        """
        遗忘模式 - 衰减、归档或合并低价值记忆
        
        30 天衰减，90 天归档
        """
        print(" [遗忘模式] 开始处理低价值记忆...")
        
        content = "系统对低价值记忆进行了衰减、归档或合并处理"
        
        self.log_dream(
            dream_type="forgetting",
            content=content,
            tags=["遗忘", "衰减", "归档", "自动"],
            metadata={
                "mode": "forgetting",
                "decay_days": 30,
                "archive_days": 90,
                "action": "decay_archive_merge",
                "timestamp": datetime.now().isoformat()
            }
        )
        
        return {"status": "success", "mode": "forgetting"}
    
    def run_dream_cycle(self, mode=None):
        """运行梦境周期"""
        if mode is None:
            # 根据时间自动选择模式
            hour = datetime.now().hour
            if hour % 6 == 0:
                mode = "rem_dream"
            elif hour % 2 == 0:
                mode = "deep_sleep"
            else:
                mode = "light_sleep"
        
        if mode == "light_sleep":
            return self.light_sleep()
        elif mode == "deep_sleep":
            return self.deep_sleep()
        elif mode == "rem_dream":
            return self.rem_dream()
        elif mode == "forgetting":
            return self.forgetting()
        else:
            return {"status": "error", "message": f"未知模式：{mode}"}
    
    def get_dreaming_status(self):
        """获取梦境引擎状态"""
        today_log = self.get_today_dream_log()
        dreams_count = 0
        
        if today_log.exists():
            with open(today_log, 'r', encoding='utf-8') as f:
                content = f.read()
                dreams_count = content.count("## [")
        
        config = self.config.get("dreaming_engine", {})
        
        return {
            "enabled": config.get("enabled", True),
            "today_dreams": dreams_count,
            "dream_log": str(today_log),
            "modes": {
                "light_sleep": config.get("light_sleep", {}).get("enabled", True),
                "deep_sleep": config.get("deep_sleep", {}).get("enabled", True),
                "rem_dream": config.get("rem_dream", {}).get("enabled", True),
                "forgetting": config.get("forgetting", {}).get("enabled", True)
            }
        }


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Arshis Dreaming Engine")
    parser.add_argument("action", choices=["run", "light", "deep", "rem", "forget", "status", "log"],
                       help="执行动作")
    parser.add_argument("--mode", choices=["light_sleep", "deep_sleep", "rem_dream", "forgetting"],
                       help="梦境模式")
    parser.add_argument("--content", type=str, help="梦境内容 (用于 log 动作)")
    parser.add_argument("--tags", type=str, help="标签 (逗号分隔)")
    
    args = parser.parse_args()
    
    engine = ArshisDreamingEngine()
    
    if args.action == "run":
        result = engine.run_dream_cycle(args.mode)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif args.action == "light":
        result = engine.light_sleep()
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif args.action == "deep":
        result = engine.deep_sleep()
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif args.action == "rem":
        result = engine.rem_dream()
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif args.action == "forget":
        result = engine.forgetting()
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif args.action == "status":
        status = engine.get_dreaming_status()
        print(json.dumps(status, indent=2, ensure_ascii=False))
    
    elif args.action == "log":
        if not args.content:
            print(" 错误：--content 参数必需")
            sys.exit(1)
        tags = args.tags.split(",") if args.tags else []
        engine.log_dream("manual", args.content, tags)
        print(" 梦境已记录")


if __name__ == "__main__":
    main()
