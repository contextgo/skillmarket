#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Arshis-Memory 模式切换脚本
在 helper mode 和 primary mode 之间切换
"""

import json
import os
import sys
from pathlib import Path
from datetime import datetime

# 路径配置
OPENCLAW_CONFIG = Path("/root/.openclaw/openclaw.json")
ARSHIS_CONFIG = Path("/root/.openclaw/workspace/skills/Arshis-Memory-Pro-release/arshis-memory-config.json")
BACKUP_DIR = Path("/root/.openclaw/workspace/backup-configs")

class ArshisModeSwitcher:
    """Arshis 模式切换器"""
    
    def __init__(self):
        self.openclaw_config = self.load_json(OPENCLAW_CONFIG)
        self.arshis_config = self.load_json(ARSHIS_CONFIG)
        self.ensure_backup_dir()
    
    def load_json(self, path):
        """加载 JSON 文件"""
        if path.exists():
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def save_json(self, path, data):
        """保存 JSON 文件"""
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f" 配置已保存：{path}")
    
    def ensure_backup_dir(self):
        """确保备份目录存在"""
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    
    def backup_config(self, name="pre-switch"):
        """备份当前配置"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = BACKUP_DIR / f"openclaw_config_{name}_{timestamp}.json"
        
        with open(backup_path, 'w', encoding='utf-8') as f:
            json.dump(self.openclaw_config, f, indent=2, ensure_ascii=False)
        
        print(f" 配置已备份：{backup_path}")
        return backup_path
    
    def check_compatibility(self, mode):
        """兼容性检查"""
        print("\n 兼容性检查...")
        
        issues = []
        warnings = []
        
        if mode == "primary":
            # 主模式检查
            current_slot = self.openclaw_config.get("plugins", {}).get("slots", {}).get("memory", "memory-core")
            
            if current_slot != "arshis-memory-pro":
                warnings.append(f"当前 memory 插槽：{current_slot} → 将改为 arshis-memory-pro")
            
            # 检查 memory-core 是否启用
            plugins = self.openclaw_config.get("plugins", {}).get("entries", {})
            if "memory-core" in plugins:
                warnings.append("memory-core 插件存在，将被替换")
            
            # 安全警告
            if self.arshis_config.get("safety", {}).get("show_config_warnings", True):
                print("\n️  安全警告:")
                print("  - 主模式将替换 memory-core 作为主要记忆插件")
                print("  - OpenClaw 原生 Dreaming 将被禁用")
                print("  - Arshis Dreaming Engine 将启用")
                print("  - 此操作可逆，可通过切换回 helper 模式恢复")
        
        elif mode == "helper":
            # 辅助模式检查
            current_slot = self.openclaw_config.get("plugins", {}).get("slots", {}).get("memory", None)
            
            if current_slot == "arshis-memory-pro":
                warnings.append("当前使用 arshis-memory-pro 作为主记忆，切换后将改用 memory-core")
        
        if issues:
            print("\n 发现以下问题:")
            for issue in issues:
                print(f"  - {issue}")
            return False
        
        if warnings:
            print("\n️  注意:")
            for warning in warnings:
                print(f"  - {warning}")
        
        print(" 兼容性检查通过")
        return True
    
    def switch_to_helper_mode(self, confirm=True):
        """切换到辅助模式"""
        print("\n 切换到辅助模式 (helper mode)...")
        
        if not self.check_compatibility("helper"):
            return False
        
        if confirm:
            print("\n 确认切换到辅助模式？(y/N): ", end="")
            response = input().strip().lower()
            if response not in ['y', 'yes']:
                print(" 已取消")
                return False
        
        # 备份配置
        self.backup_config("to-helper")
        
        # 修改配置
        if "plugins" not in self.openclaw_config:
            self.openclaw_config["plugins"] = {}
        
        if "slots" not in self.openclaw_config["plugins"]:
            self.openclaw_config["plugins"]["slots"] = {}
        
        # 辅助模式：不占用 memory 插槽，让 memory-core 工作
        # 如果之前设置了 arshis-memory-pro，移除它
        if self.openclaw_config["plugins"]["slots"].get("memory") == "arshis-memory-pro":
            del self.openclaw_config["plugins"]["slots"]["memory"]
            print(" 已移除 memory 插槽设置 (将使用 memory-core)")
        
        # 更新 Arshis 配置
        self.arshis_config["mode"] = "helper"
        self.arshis_config["helper_mode"]["occupy_memory_slot"] = False
        self.arshis_config["helper_mode"]["replace_memory_core"] = False
        self.arshis_config["environment"]["ARSHIS_MEMORY_MODE"] = "helper"
        self.arshis_config["environment"]["REPLACE_MEMORY_CORE"] = False
        
        # 保存配置
        self.save_json(OPENCLAW_CONFIG, self.openclaw_config)
        self.save_json(ARSHIS_CONFIG, self.arshis_config)
        
        print("\n 辅助模式已启用!")
        print("\n 当前状态:")
        print("  - Memory 插槽：memory-core (原生)")
        print("  - Arshis-Memory: 辅助增强模式")
        print("  - Dreaming: OpenClaw 原生 + Arshis 增强")
        print("  - 自动捕获：禁用")
        
        return True
    
    def switch_to_primary_mode(self, confirm=True):
        """切换到主模式"""
        print("\n 切换到主模式 (primary mode)...")
        
        if not self.check_compatibility("primary"):
            return False
        
        if confirm:
            print("\n 确认切换到主模式？此操作将替换 memory-core！(yes 确认): ", end="")
            response = input().strip().lower()
            if response not in ['yes']:
                print(" 已取消")
                return False
        
        # 备份配置
        self.backup_config("to-primary")
        
        # 修改配置
        if "plugins" not in self.openclaw_config:
            self.openclaw_config["plugins"] = {}
        
        if "slots" not in self.openclaw_config["plugins"]:
            self.openclaw_config["plugins"]["slots"] = {}
        
        # 主模式：占用 memory 插槽
        self.openclaw_config["plugins"]["slots"]["memory"] = "arshis-memory-pro"
        print(" 已设置 memory 插槽：arshis-memory-pro")
        
        # 更新 Arshis 配置
        self.arshis_config["mode"] = "primary"
        self.arshis_config["primary_mode"]["occupy_memory_slot"] = True
        self.arshis_config["primary_mode"]["replace_memory_core"] = True
        self.arshis_config["primary_mode"]["disable_native_dreaming"] = True
        self.arshis_config["primary_mode"]["enable_arshis_dreaming"] = True
        self.arshis_config["environment"]["ARSHIS_MEMORY_MODE"] = "primary"
        self.arshis_config["environment"]["ARSHIS_PRIMARY_MEMORY"] = True
        self.arshis_config["environment"]["REPLACE_MEMORY_CORE"] = True
        
        # 保存配置
        self.save_json(OPENCLAW_CONFIG, self.openclaw_config)
        self.save_json(ARSHIS_CONFIG, self.arshis_config)
        
        print("\n 主模式已启用!")
        print("\n 当前状态:")
        print("  - Memory 插槽：arshis-memory-pro")
        print("  - memory-core: 已替换")
        print("  - Dreaming: Arshis Dreaming Engine")
        print("  - 自动捕获：禁用 (需手动启用)")
        print("  - 梦境日志：/root/.openclaw/workspace/memory/arshis-dreams/")
        
        print("\n️  提示：需要重启 OpenClaw 网关以应用配置")
        print("  运行：openclaw gateway restart")
        
        return True
    
    def show_status(self):
        """显示当前状态"""
        print("\n Arshis-Memory 状态")
        print("=" * 50)
        
        mode = self.arshis_config.get("mode", "unknown")
        print(f"当前模式：{mode.upper()}")
        
        memory_slot = self.openclaw_config.get("plugins", {}).get("slots", {}).get("memory", "memory-core")
        print(f"Memory 插槽：{memory_slot}")
        
        dreaming = self.arshis_config.get("dreaming_engine", {}).get("enabled", False)
        print(f"梦境引擎：{' 启用' if dreaming else ' 禁用'}")
        
        auto_capture = self.arshis_config.get("helper_mode", {}).get("auto_capture", False)
        if mode == "primary":
            auto_capture = self.arshis_config.get("primary_mode", {}).get("auto_capture", False)
        print(f"自动捕获：{' 启用' if auto_capture else ' 禁用'}")
        
        dream_log = Path("/root/.openclaw/workspace/memory/arshis-dreams")
        if dream_log.exists():
            today = datetime.now().strftime("%Y-%m-%d")
            today_log = dream_log / f"{today}.md"
            if today_log.exists():
                with open(today_log, 'r', encoding='utf-8') as f:
                    content = f.read()
                    dreams_count = content.count("## [")
                print(f"今日梦境：{dreams_count} 条")
        
        print("=" * 50)


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Arshis-Memory 模式切换")
    parser.add_argument("action", choices=["helper", "primary", "status", "check"],
                       help="执行动作")
    parser.add_argument("--no-confirm", action="store_true",
                       help="跳过确认 (用于自动化)")
    
    args = parser.parse_args()
    
    switcher = ArshisModeSwitcher()
    
    if args.action == "helper":
        success = switcher.switch_to_helper_mode(confirm=not args.no_confirm)
        sys.exit(0 if success else 1)
    
    elif args.action == "primary":
        success = switcher.switch_to_primary_mode(confirm=not args.no_confirm)
        sys.exit(0 if success else 1)
    
    elif args.action == "status":
        switcher.show_status()
    
    elif args.action == "check":
        print("兼容性检查模式")
        switcher.check_compatibility("primary")


if __name__ == "__main__":
    main()
