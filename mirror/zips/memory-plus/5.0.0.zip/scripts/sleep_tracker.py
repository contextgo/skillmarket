#!/usr/bin/env python3
"""
Sleep Tracker for Arshis-memory-pro

Provides basic sleep stage tracking:
- Light Sleep
- Deep Sleep
- REM Sleep
- Dream Recording

Note: This is a simulated tracker. For accurate data,
integrate with Apple Health/Google Fit/etc.
"""

import json
import os
import random
from datetime import datetime, timedelta
from typing import Any, Dict, List


class SleepTracker:
    """Sleep Tracker"""
    
    def __init__(self, sleep_path: str = "/root/.openclaw/data/memory-custom/sleep.json"):
        """
        Initialize Sleep Tracker
        
        Args:
            sleep_path: Path to sleep data file
        """
        self.sleep_path = sleep_path
        self.sleep_data = self._load_sleep_data()
    
    def _load_sleep_data(self) -> List[Dict]:
        """Load sleep data from file"""
        if not os.path.exists(self.sleep_path):
            return []
        
        try:
            with open(self.sleep_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"[WARN] Failed to load sleep data: {e}")
            return []
    
    def _save_sleep_data(self):
        """Save sleep data to file"""
        try:
            os.makedirs(os.path.dirname(self.sleep_path), exist_ok=True)
            
            with open(self.sleep_path, 'w', encoding='utf-8') as f:
                json.dump(self.sleep_data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[WARN] Failed to save sleep data: {e}")
    
    def record_sleep(self, bedtime: str = None, wake_time: str = None, 
                     light_sleep: float = None, deep_sleep: float = None, 
                     rem_sleep: float = None, quality: int = None):
        """
        Record a sleep session
        
        Args:
            bedtime: Bedtime (ISO format or "last night")
            wake_time: Wake time (ISO format or "now")
            light_sleep: Light sleep duration (minutes)
            deep_sleep: Deep sleep duration (minutes)
            rem_sleep: REM sleep duration (minutes)
            quality: Sleep quality (1-5)
        """
        # Default times
        if bedtime == "last night" or bedtime is None:
            bedtime = (datetime.now() - timedelta(days=1)).replace(hour=23, minute=0).isoformat()
        if wake_time == "now" or wake_time is None:
            wake_time = datetime.now().isoformat()
        
        # Simulate sleep stages if not provided
        if light_sleep is None:
            light_sleep = random.randint(180, 300)  # 3-5 hours
        if deep_sleep is None:
            deep_sleep = random.randint(60, 120)   # 1-2 hours
        if rem_sleep is None:
            rem_sleep = random.randint(90, 150)    # 1.5-2.5 hours
        if quality is None:
            quality = random.randint(3, 5)         # 3-5 quality
        
        total_sleep = light_sleep + deep_sleep + rem_sleep
        
        sleep_session = {
            "id": len(self.sleep_data) + 1,
            "date": datetime.now().strftime("%Y-%m-%d"),
            "bedtime": bedtime,
            "wake_time": wake_time,
            "light_sleep_min": light_sleep,
            "deep_sleep_min": deep_sleep,
            "rem_sleep_min": rem_sleep,
            "total_sleep_min": total_sleep,
            "quality": quality,
            "dreams": [],
            "improvements": 0,
            "consolidated": False
        }
        
        self.sleep_data.append(sleep_session)
        self._save_sleep_data()
        
        print(f"[OK] Sleep recorded:")
        print(f"  Light Sleep: {light_sleep} min")
        print(f"  Deep Sleep: {deep_sleep} min")
        print(f"  REM Sleep: {rem_sleep} min")
        print(f"  Total: {total_sleep} min")
        print(f"  Quality: {quality}/5")
        
        return sleep_session
    
    def get_last_night(self) -> Dict:
        """
        Get last night's sleep data
        
        Returns:
            Last night's sleep data
        """
        if not self.sleep_data:
            return self.record_sleep()  # Generate simulated data
        
        return self.sleep_data[-1]
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get sleep statistics
        
        Returns:
            Statistics dictionary
        """
        if not self.sleep_data:
            return {
                "total_nights": 0,
                "avg_light_sleep": 0,
                "avg_deep_sleep": 0,
                "avg_rem_sleep": 0,
                "avg_total_sleep": 0,
                "avg_quality": 0,
                "total_dreams": 0,
                "total_improvements": 0
            }
        
        total_nights = len(self.sleep_data)
        avg_light = sum(s['light_sleep_min'] for s in self.sleep_data) / total_nights
        avg_deep = sum(s['deep_sleep_min'] for s in self.sleep_data) / total_nights
        avg_rem = sum(s['rem_sleep_min'] for s in self.sleep_data) / total_nights
        avg_total = sum(s['total_sleep_min'] for s in self.sleep_data) / total_nights
        avg_quality = sum(s['quality'] for s in self.sleep_data) / total_nights
        total_dreams = sum(len(s.get('dreams', [])) for s in self.sleep_data)
        total_improvements = sum(s.get('improvements', 0) for s in self.sleep_data)
        
        return {
            "total_nights": total_nights,
            "avg_light_sleep": round(avg_light, 1),
            "avg_deep_sleep": round(avg_deep, 1),
            "avg_rem_sleep": round(avg_rem, 1),
            "avg_total_sleep": round(avg_total, 1),
            "avg_quality": round(avg_quality, 1),
            "total_dreams": total_dreams,
            "total_improvements": total_improvements
        }
    
    def link_dream(self, dream_id: int, dream_content: str):
        """
        Link a dream to last night's sleep
        
        Args:
            dream_id: Dream ID
            dream_content: Dream content
        """
        if not self.sleep_data:
            print("[WARN] No sleep data to link dream")
            return
        
        last_night = self.sleep_data[-1]
        
        dream_entry = {
            "id": dream_id,
            "content": dream_content,
            "linked_at": datetime.now().isoformat()
        }
        
        if 'dreams' not in last_night:
            last_night['dreams'] = []
        
        last_night['dreams'].append(dream_entry)
        last_night['improvements'] = len(last_night['dreams'])
        
        self._save_sleep_data()
        
        print(f"[OK] Dream linked to sleep session")
        print(f"  Total Improvements: {last_night['improvements']}")
    
    def print_report(self):
        """Print sleep report"""
        stats = self.get_stats()
        last_night = self.get_last_night()
        
        print("\n" + "=" * 60)
        print("Arshis-memory-pro Sleep Report")
        print("=" * 60)
        
        print(f"\nLast Night ({last_night['date']}):")
        print(f"  Light Sleep: {last_night['light_sleep_min']} min")
        print(f"  Deep Sleep: {last_night['deep_sleep_min']} min")
        print(f"  REM Sleep: {last_night['rem_sleep_min']} min")
        print(f"  Total Sleep: {last_night['total_sleep_min']} min")
        print(f"  Quality: {last_night['quality']}/5")
        print(f"  Dreams: {len(last_night.get('dreams', []))}")
        print(f"  Improvements: {last_night.get('improvements', 0)}")
        
        print(f"\nAverages ({stats['total_nights']} nights):")
        print(f"  Avg Light Sleep: {stats['avg_light_sleep']} min")
        print(f"  Avg Deep Sleep: {stats['avg_deep_sleep']} min")
        print(f"  Avg REM Sleep: {stats['avg_rem_sleep']} min")
        print(f"  Avg Total Sleep: {stats['avg_total_sleep']} min")
        print(f"  Avg Quality: {stats['avg_quality']}/5")
        print(f"  Total Dreams: {stats['total_dreams']}")
        print(f"  Total Improvements: {stats['total_improvements']}")
        
        print("\n" + "=" * 60)


def main():
    """Main function"""
    import sys
    
    sleep = SleepTracker()
    
    if len(sys.argv) < 2:
        print("\nArshis-memory-pro Sleep Tracker")
        print("=" * 60)
        print("\nUsage:")
        print("  python3 sleep_tracker.py record    # Record sleep (simulated)")
        print("  python3 sleep_tracker.py stats     # View statistics")
        print("  python3 sleep_tracker.py report    # Full report")
        print("  python3 sleep_tracker.py link      # Link dream to sleep")
        print()
        return
    
    command = sys.argv[1]
    
    if command == "record":
        sleep.record_sleep()
    
    elif command == "stats":
        stats = sleep.get_stats()
        print("\nSleep Statistics:")
        print(f"  Total Nights: {stats['total_nights']}")
        print(f"  Total Dreams: {stats['total_dreams']}")
        print(f"  Total Improvements: {stats['total_improvements']}")
        print()
    
    elif command == "report":
        sleep.print_report()
    
    elif command == "link":
        # Link last dream to sleep
        dreams_path = "/root/.openclaw/data/memory-custom/dreams.json"
        if os.path.exists(dreams_path):
            with open(dreams_path, 'r', encoding='utf-8') as f:
                dreams = json.load(f)
            if dreams:
                last_dream = dreams[-1]
                sleep.link_dream(last_dream['id'], last_dream['content'])
        else:
            print("[WARN] No dreams to link")
    
    else:
        print(f"[ERROR] Unknown command: {command}")


if __name__ == "__main__":
    main()
