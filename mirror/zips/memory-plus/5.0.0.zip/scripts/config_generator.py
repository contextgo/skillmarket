#!/usr/bin/env python3
"""
Configuration Generator for Arshis-memory-pro

Generates configuration files for different use cases:
- Single provider (simple)
- Multi-provider (recommended)
- Local only (offline)

Usage:
    python3 config_generator.py
"""

import json
import os
import sys

# Use placeholder path (user should modify)
DEFAULT_DB_PATH = "~/.openclaw/data/memory-custom"

TEMPLATES = {
    "single": {
        "name": "Single Provider (SiliconFlow)",
        "description": "Simple configuration using only SiliconFlow",
        "config": {
            "version": "3.2.0",
            "multiProvider": False,
            "embedding": {
                "provider": "siliconflow",
                "model": "BAAI/bge-m3",
                "baseURL": "https://api.siliconflow.cn/v1",
                "dimensions": 1024,
                "timeout": 30
            },
            "retrieval": {
                "mode": "hybrid",
                "vectorWeight": 0.7,
                "bm25Weight": 0.3,
                "rerank": {
                    "enabled": True,
                    "provider": "siliconflow",
                    "model": "BAAI/bge-reranker-v2-m3"
                }
            },
            "llm": {
                "provider": "siliconflow",
                "model": "Qwen/Qwen2.5-72B-Instruct",
                "baseURL": "https://api.siliconflow.cn/v1",
                "maxTokens": 4096,
                "temperature": 0.7,
                "timeout": 60
            },
            "database": {
                "type": "json",
                "path": DEFAULT_DB_PATH,
                "note": "IMPORTANT: Modify this path for your system",
                "backup": {
                    "enabled": True,
                    "interval": "daily",
                    "maxBackups": 7
                }
            },
            "features": {
                "autoCapture": False,
                "autoRecall": True,
                "selfEvolution": True,
                "dreaming": False,
                "shortTerm": True
            }
        }
    },
    
    "multi": {
        "name": "Multi-Provider (Recommended)",
        "description": "Multiple providers with auto-failover",
        "config": {
            "version": "3.2.0",
            "multiProvider": True,
            "embedding": {
                "provider": "auto",
                "autoFailover": True,
                "providers": {
                    "siliconflow": {
                        "enabled": True,
                        "priority": 1,
                        "apiKey": "${SILICONFLOW_API_KEY}",
                        "model": "BAAI/bge-m3",
                        "baseURL": "https://api.siliconflow.cn/v1",
                        "dimensions": 1024,
                        "timeout": 30
                    },
                    "dashscope": {
                        "enabled": False,
                        "priority": 2,
                        "apiKey": "${DASHSCOPE_API_KEY}",
                        "model": "text-embedding-v3",
                        "baseURL": "https://dashscope.aliyuncs.com/api/v1",
                        "dimensions": 1536,
                        "timeout": 30
                    },
                    "jina": {
                        "enabled": False,
                        "priority": 3,
                        "apiKey": "${JINA_API_KEY}",
                        "model": "jina-embeddings-v3",
                        "baseURL": "https://api.jina.ai/v1",
                        "dimensions": 1024,
                        "timeout": 30
                    }
                }
            },
            "retrieval": {
                "mode": "hybrid",
                "vectorWeight": 0.7,
                "bm25Weight": 0.3,
                "rerank": {
                    "enabled": True,
                    "provider": "auto",
                    "providers": {
                        "siliconflow": {
                            "enabled": True,
                            "model": "BAAI/bge-reranker-v2-m3",
                            "baseURL": "https://api.siliconflow.cn/v1"
                        },
                        "jina": {
                            "enabled": True,
                            "model": "jina-reranker-v2-base-multilingual",
                            "baseURL": "https://api.jina.ai/v1"
                        }
                    }
                }
            },
            "llm": {
                "provider": "auto",
                "autoFailover": True,
                "providers": {
                    "siliconflow": {
                        "enabled": True,
                        "priority": 1,
                        "apiKey": "${SILICONFLOW_API_KEY}",
                        "model": "Qwen/Qwen2.5-72B-Instruct",
                        "baseURL": "https://api.siliconflow.cn/v1",
                        "maxTokens": 4096,
                        "temperature": 0.7,
                        "timeout": 60
                    },
                    "dashscope": {
                        "enabled": False,
                        "priority": 2,
                        "apiKey": "${DASHSCOPE_API_KEY}",
                        "model": "qwen-max",
                        "baseURL": "https://dashscope.aliyuncs.com/api/v1",
                        "maxTokens": 4096,
                        "temperature": 0.7,
                        "timeout": 60
                    }
                }
            },
            "database": {
                "type": "json",
                "path": DEFAULT_DB_PATH,
                "note": "IMPORTANT: Modify this path for your system",
                "backup": {
                    "enabled": True,
                    "interval": "daily",
                    "maxBackups": 7
                }
            },
            "features": {
                "autoCapture": False,
                "autoRecall": True,
                "selfEvolution": True,
                "dreaming": False,
                "shortTerm": True
            }
        }
    },
    
    "local": {
        "name": "Local Only (Offline)",
        "description": "Local Ollama provider for offline use",
        "config": {
            "version": "3.2.0",
            "multiProvider": False,
            "embedding": {
                "provider": "ollama",
                "model": "nomic-embed-text",
                "baseURL": "http://localhost:11434/api",
                "dimensions": 768,
                "timeout": 60
            },
            "retrieval": {
                "mode": "hybrid",
                "vectorWeight": 0.7,
                "bm25Weight": 0.3,
                "rerank": {
                    "enabled": False
                }
            },
            "llm": {
                "provider": "ollama",
                "model": "qwen2.5:7b",
                "baseURL": "http://localhost:11434/api",
                "maxTokens": 4096,
                "temperature": 0.7,
                "timeout": 120
            },
            "database": {
                "type": "json",
                "path": DEFAULT_DB_PATH,
                "note": "IMPORTANT: Modify this path for your system",
                "backup": {
                    "enabled": True,
                    "interval": "daily",
                    "maxBackups": 7
                }
            },
            "features": {
                "autoCapture": False,
                "autoRecall": True,
                "selfEvolution": True,
                "dreaming": False,
                "shortTerm": True
            }
        }
    }
}


def generate_config(template_name="multi", output_path=None):
    """Generate configuration file from template"""
    
    if template_name not in TEMPLATES:
        print(f"[ERROR] Unknown template: {template_name}")
        print(f"[INFO] Available templates: {', '.join(TEMPLATES.keys())}")
        return False
    
    template = TEMPLATES[template_name]
    
    if output_path is None:
        output_path = f"memory-custom-config-{template_name}.json"
    
    config = template["config"]
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    
    print(f"[OK] Configuration generated: {output_path}")
    print(f"[INFO] Template: {template['name']}")
    print(f"[INFO] Description: {template['description']}")
    print(f"[WARN] IMPORTANT: Edit the 'database.path' in the generated config!")
    print(f"[WARN] IMPORTANT: Set required environment variables!")
    
    return True


def list_templates():
    """List available configuration templates"""
    
    print("\nAvailable Configuration Templates:\n")
    print("=" * 60)
    
    for name, template in TEMPLATES.items():
        print(f"\n{name.upper()}")
        print(f"  Name: {template['name']}")
        print(f"  Description: {template['description']}")
        print(f"  Usage: python3 config_generator.py {name}")
    
    print("\n" + "=" * 60)
    print("\nEnvironment Variables Required:")
    print("  SILICONFLOW_API_KEY  - Required for SiliconFlow provider")
    print("  DASHSCOPE_API_KEY    - Optional for DashScope provider")
    print("  JINA_API_KEY         - Optional for Jina AI provider")
    print("  OPENAI_API_KEY       - Optional for OpenAI provider")
    print("  COHERE_API_KEY       - Optional for Cohere provider")
    print("\nExamples:")
    print("  export SILICONFLOW_API_KEY=\"your-api-key\"")
    print("  python3 config_generator.py multi")
    print()


def validate_config(config_path):
    """Validate configuration file"""
    
    if not os.path.exists(config_path):
        print(f"[ERROR] Configuration file not found: {config_path}")
        return False
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        required_fields = ["version", "embedding", "retrieval", "llm", "database", "features"]
        missing = [field for field in required_fields if field not in config]
        
        if missing:
            print(f"[WARN] Missing fields: {', '.join(missing)}")
            return False
        
        # Check for placeholder path
        db_path = config["database"].get("path", "")
        if db_path.startswith("/root/") or db_path.startswith("C:\\\\Users"):
            print(f"[WARN] Database path needs modification: {db_path}")
            print(f"[INFO] Please edit config and change 'database.path'")
        
        # Check for environment variables
        config_str = json.dumps(config)
        env_vars = ["${SILICONFLOW_API_KEY}", "${DASHSCOPE_API_KEY}", 
                    "${JINA_API_KEY}", "${OPENAI_API_KEY}"]
        found_vars = [v for v in env_vars if v in config_str]
        
        if found_vars:
            print(f"[INFO] Environment variables used: {', '.join(found_vars)}")
            print(f"[INFO] Make sure to set these before running")
        
        print(f"[OK] Configuration valid: {config_path}")
        print(f"[INFO] Version: {config['version']}")
        print(f"[INFO] Provider: {config['embedding'].get('provider', 'unknown')}")
        
        return True
    
    except json.JSONDecodeError as e:
        print(f"[ERROR] Invalid JSON: {e}")
        return False


def main():
    """Main function"""
    
    if len(sys.argv) < 2:
        print("\nArshis-memory-pro Configuration Generator")
        print("=" * 60)
        print("\nUsage:")
        print("  python3 config_generator.py <template>    # Generate config")
        print("  python3 config_generator.py list          # List templates")
        print("  python3 config_generator.py validate <file>  # Validate config")
        print()
        list_templates()
        return
    
    command = sys.argv[1]
    
    if command == "list":
        list_templates()
    
    elif command == "validate":
        if len(sys.argv) < 3:
            print("[ERROR] Please specify config file path")
            return
        validate_config(sys.argv[2])
    
    else:
        generate_config(command)


if __name__ == "__main__":
    main()
