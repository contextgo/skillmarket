/**
 * Arshis-Memory-Pro - OpenClaw Primary Memory Plugin
 * 
 * Advanced memory management system with:
 * - LanceDB vector database + hybrid retrieval
 * - Primary mode (replaces memory-core) / Helper mode (coexists)
 * - Arshis Dreaming Engine (Light/Deep/REM/Forgetting/Promotion)
 * - Context injection control (prevents context explosion)
 * - Privacy-first (no external network, no data upload)
 * 
 * @version 5.0.0
 * @author Arshis
 * @license MIT-0
 */

import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Fixed script paths - never constructed from user input
const SCRIPTS_DIR = path.join(__dirname, 'scripts');
const MEMORY_CORE = path.join(SCRIPTS_DIR, 'memory_core.py');
const DREAMING_ENGINE = path.join(SCRIPTS_DIR, 'arshis_dreaming_engine.py');
const SELF_EVOLUTION = path.join(SCRIPTS_DIR, 'self_evolution.py');

// Default configuration (overridden by environment variables)
const DEFAULT_CONFIG = {
  // Mode: 'primary' or 'helper'
  ARSHIS_MEMORY_MODE: process.env.ARSHIS_MEMORY_MODE || 'primary',
  ARSHIS_PRIMARY_MEMORY: process.env.ARSHIS_PRIMARY_MEMORY === 'true',
  REPLACE_MEMORY_CORE: process.env.REPLACE_MEMORY_CORE === 'true',
  ARSHIS_DREAMING_ENABLED: process.env.ARSHIS_DREAMING_ENABLED !== 'false',

  // Context injection control
  MAX_MEMORY_INJECTION: parseInt(process.env.MAX_MEMORY_INJECTION || '8', 10),
  SUMMARY_ONLY_MODE: process.env.SUMMARY_ONLY_MODE !== 'false',
  RELEVANCE_THRESHOLD: parseFloat(process.env.RELEVANCE_THRESHOLD || '0.72'),
  MAX_CONTEXT_TOKENS_FOR_MEMORY: parseInt(process.env.MAX_CONTEXT_TOKENS_FOR_MEMORY || '12000', 10),

  // Privacy and safety
  AUTO_CAPTURE_ENABLED: process.env.AUTO_CAPTURE_ENABLED === 'true',
  REQUIRE_USER_CONFIRMATION: process.env.REQUIRE_USER_CONFIRMATION !== 'false',
  LOCAL_ONLY: process.env.LOCAL_ONLY !== 'false',

  // Data paths
  DATA_DIR: process.env.ARSHIS_MEMORY_DATA_DIR || path.join(process.env.HOME || '/root/.openclaw', 'data', 'memory-custom'),
};

/**
 * Execute a Python script safely.
 * Security: Only spawns fixed, local script paths.
 */
function runPythonScript(script, args = [], timeout = 30000) {
  return new Promise((resolve, reject) => {
    const proc = spawn('python3', [script, ...args], {
      timeout,
      env: { ...process.env, PYTHONIOENCODING: 'utf-8' },
    });
    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', (data) => { stdout += data.toString(); });
    proc.stderr.on('data', (data) => { stderr += data.toString(); });

    proc.on('close', (code) => {
      if (code === 0) {
        try {
          resolve(JSON.parse(stdout));
        } catch {
          resolve({ output: stdout.trim() });
        }
      } else {
        resolve({ error: `Script exited ${code}: ${stderr.trim()}` });
      }
    });

    proc.on('error', (err) => {
      resolve({ error: `Failed to spawn: ${err.message}` });
    });
  });
}

// ==================== Memory API ====================

/**
 * Store a memory entry.
 * Usage: store_memory({ text: "...", importance: 0.8, category: "knowledge" })
 */
export async function store_memory(args, context) {
  try {
    const { text, importance = 0.5, category = 'general' } = args || {};
    if (!text) return { error: 'text is required' };
    return await runPythonScript(MEMORY_CORE, ['store', text, String(importance), category]);
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Recall memories by query.
 * Usage: recall_memory({ query: "...", limit: 5 })
 * Respects MAX_MEMORY_INJECTION and RELEVANCE_THRESHOLD.
 */
export async function recall_memory(args, context) {
  try {
    const { query, limit = DEFAULT_CONFIG.MAX_MEMORY_INJECTION, memory_range } = args || {};
    if (!query) return { error: 'query is required' };
    const result = await runPythonScript(MEMORY_CORE, ['recall', query, String(limit)]);
    
    // Apply relevance threshold filter
    if (Array.isArray(result)) {
      const threshold = DEFAULT_CONFIG.RELEVANCE_THRESHOLD;
      const filtered = result.filter(r => (r.score || 0) >= threshold);
      return { results: filtered.slice(0, limit), threshold, total_before_filter: result.length };
    }
    return result;
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Delete a memory by ID.
 * Usage: delete_memory({ memory_id: "..." })
 */
export async function delete_memory(args, context) {
  try {
    const { memory_id } = args || {};
    if (!memory_id) return { error: 'memory_id is required' };
    return await runPythonScript(MEMORY_CORE, ['delete', memory_id]);
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * List all memories (with limit).
 * Usage: list_memories({ limit: 20 })
 */
export async function list_memories(args, context) {
  try {
    const { limit = 20 } = args || {};
    return await runPythonScript(MEMORY_CORE, ['list', String(limit)]);
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Get memory statistics.
 * Usage: memory_stats()
 */
export async function memory_stats(args, context) {
  try {
    return await runPythonScript(MEMORY_CORE, ['stats']);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Dreaming Engine API ====================

/**
 * Run a dream cycle.
 * Usage: run_dream_cycle({ mode: "light" })
 * Modes: light, deep, rem, forgetting, promotion
 */
export async function run_dream_cycle(args, context) {
  try {
    const { mode = 'light' } = args || {};
    const validModes = ['light', 'deep', 'rem', 'forgetting', 'promotion'];
    if (!validModes.includes(mode)) {
      return { error: `Invalid mode: ${mode}. Valid: ${validModes.join(', ')}` };
    }
    return await runPythonScript(DREAMING_ENGINE, [mode]);
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Get dreaming status.
 * Usage: dreaming_status()
 */
export async function dreaming_status(args, context) {
  try {
    return await runPythonScript(DREAMING_ENGINE, ['status']);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Self-Evolution API ====================

/**
 * Get evolution status.
 * Usage: evolution_status()
 */
export async function evolution_status(args, context) {
  try {
    return await runPythonScript(SELF_EVOLUTION, ['status']);
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Get evolution report.
 * Usage: evolution_report()
 */
export async function evolution_report(args, context) {
  try {
    return await runPythonScript(SELF_EVOLUTION, ['report']);
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Privacy API ====================

/**
 * Export all memories to a JSON file.
 * Usage: export_memories({ filepath: "/path/to/export.json" })
 */
export async function export_memories(args, context) {
  try {
    const { filepath } = args || {};
    if (!filepath) return { error: 'filepath is required' };
    const memories = await runPythonScript(MEMORY_CORE, ['list', '1000']);
    if (memories && Array.isArray(memories)) {
      fs.writeFileSync(filepath, JSON.stringify(memories, null, 2), 'utf-8');
      return { success: true, exported: memories.length, filepath };
    }
    return { error: 'Failed to retrieve memories' };
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Clear all memories (requires confirmation in primary mode).
 * Usage: clear_memories({ confirm: true })
 */
export async function clear_memories(args, context) {
  try {
    const { confirm } = args || {};
    if (!confirm && DEFAULT_CONFIG.REQUIRE_USER_CONFIRMATION) {
      return { error: 'Confirmation required. Pass { confirm: true } to proceed.' };
    }
    // Delete all memory files
    const dataDir = DEFAULT_CONFIG.DATA_DIR;
    if (fs.existsSync(dataDir)) {
      const files = fs.readdirSync(dataDir);
      let deleted = 0;
      for (const file of files) {
        if (file.endsWith('.json') || file.endsWith('.lance')) {
          const fpath = path.join(dataDir, file);
          if (fs.statSync(fpath).isFile()) {
            fs.unlinkSync(fpath);
            deleted++;
          }
        }
      }
      return { success: true, deleted };
    }
    return { success: true, deleted: 0, message: 'No data directory found' };
  } catch (error) {
    return { error: error.message };
  }
}

// ==================== Plugin Info ====================

export async function get_plugin_info(args, context) {
  return {
    name: 'Arshis-Memory-Pro',
    version: '5.0.0',
    mode: DEFAULT_CONFIG.ARSHIS_MEMORY_MODE,
    primary_mode: DEFAULT_CONFIG.ARSHIS_PRIMARY_MEMORY,
    dreaming_enabled: DEFAULT_CONFIG.ARSHIS_DREAMING_ENABLED,
    auto_capture: DEFAULT_CONFIG.AUTO_CAPTURE_ENABLED,
    local_only: DEFAULT_CONFIG.LOCAL_ONLY,
    data_dir: DEFAULT_CONFIG.DATA_DIR,
    max_injection: DEFAULT_CONFIG.MAX_MEMORY_INJECTION,
    relevance_threshold: DEFAULT_CONFIG.RELEVANCE_THRESHOLD,
    summary_only: DEFAULT_CONFIG.SUMMARY_ONLY_MODE,
    max_context_tokens: DEFAULT_CONFIG.MAX_CONTEXT_TOKENS_FOR_MEMORY,
    features: [
      'lancedb_vector_db',
      'hybrid_retrieval',
      'self_evolution',
      'dreaming_engine',
      'context_injection_control',
      'privacy_first',
    ],
    privacy: {
      network_requests: false,
      data_upload: false,
      external_llm: false,
      api_keys_required: false,
      local_storage_only: true,
    },
  };
}

// ==================== Default Export ====================

export default {
  store_memory,
  recall_memory,
  delete_memory,
  list_memories,
  memory_stats,
  run_dream_cycle,
  dreaming_status,
  evolution_status,
  evolution_report,
  export_memories,
  clear_memories,
  get_plugin_info,
};
