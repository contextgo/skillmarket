# Privacy and Security Policy - Arshis-Memory-Pro v5.0.0

## Network Activity

This plugin does NOT make outbound network requests.
All memory storage, retrieval, dreaming, and evolution processing happens locally.

## Data Collection

This plugin does NOT collect or upload user data.
- No analytics
- No telemetry
- No user profiling
- No external logging

## Data Storage

All memory data is stored locally in:
- ~/.openclaw/data/memory-custom/ (memory database)
- ~/.openclaw/workspace/memory/arshis-dreams/ (dream logs)

No data is sent to external servers, cloud databases, or third-party services.

## External LLM Calls

This plugin does NOT call external LLM services.
All processing (embedding generation, retrieval scoring, dreaming, evolution) uses local algorithms.

## API Keys

This plugin does NOT require any API keys to function.

## Memory Slot Takeover

By default, this plugin operates in PRIMARY mode, which replaces OpenClaw's built-in memory-core plugin.
This can be switched to HELPER mode at any time, which coexists with memory-core without taking over.

To switch modes:
- Primary mode: ARSHIS_MEMORY_MODE=primary
- Helper mode: ARSHIS_MEMORY_MODE=helper

## How to Disable Memory

1. Switch to helper mode: set ARSHIS_MEMORY_MODE=helper
2. Or disable auto-capture: set AUTO_CAPTURE_ENABLED=false (already the default)
3. Or uninstall the plugin entirely

## How to Delete Memory

1. Delete individual memories: delete_memory({ memory_id: "..." })
2. Clear all memories: clear_memories({ confirm: true })
3. Delete data directory: rm -rf ~/.openclaw/data/memory-custom/

## How to Export Memory

export_memories({ filepath: "/path/to/backup.json" })

## Child Process Usage

This plugin uses Node.js child_process.spawn() to run local Python scripts:
- Only scripts bundled with this plugin (scripts/*.py)
- Fixed script paths, never constructed from user input
- User input passed as arguments, never executed as commands

## Third-Party Dependencies

| Dependency | Purpose | Network? |
|-----------|---------|----------|
| lancedb | Vector database storage | No |
| rank-bm25 | Keyword search | No |
| numpy | Numeric computations | No |
| requests | Available but NOT used by this plugin | No |

## Summary

| Question | Answer |
|----------|--------|
| Does it connect to the internet? | No |
| Does it upload data? | No |
| Does it call external APIs? | No |
| Does it require API keys? | No |
| Does it replace memory-core? | Only in primary mode (configurable) |
| Where is data stored? | Local filesystem only |
| How to delete all data? | clear_memories({ confirm: true }) or delete data directory |
