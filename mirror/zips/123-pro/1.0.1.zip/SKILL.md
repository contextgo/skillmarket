---
description: Extracts visual assets (figures, tables, equations) from an Arxiv paper, packages them into a zip file, and generates a structured Xiaohongshu post strictly referencing the extracted images without outputting text-based formulas.
name: generating-xiaohongshu-graph-post
---

# 小红书论文图文生成技能

## 技能概述

本技能专门用于从Arxiv论文中提取视觉资产（图表、公式），并生成符合小红书排版规范的图文帖子。技能通过自动化流程完成论文获取、视觉元素提取、文案撰写与验证，确保输出内容严格引用原文图片，不包含任何文本形式的数学公式。

**核心价值：**

- 将复杂学术论文转化为适合小红书传播的视觉内容
- 确保内容准确性：所有图表严格引用原文
- 零公式违规：数学公式仅以截图形式呈现

## 触发条件（Boundaries）

### Use this skill when（适用场景）

- 用户说要生成小红书长图文，并且给了论文题目或者论文的模型名称

### Do NOT use this skill when（不适用场景）

- 用户只是要求简单总结论文大意，不需要提取图片
- 用户询问论文中某一段落的具体含义（此时应使用通用阅读分析能力）

## 接口定义（Interface）

### 输入（Input）

| 参数 | 类型 | 说明 |
|------|------|------|
| `paper_reference` | string | Arxiv链接（如 `https://arxiv.org/abs/2301.12345`）、论文ID（如 `2301.12345`）或论文标题（如 `Attention Is All You Need`） |

### 输出（Output）

| 参数 | 类型 | 说明 |
|------|------|------|
| `assets_zip_path` | string | 包含所有精确裁剪的图表、公式的ZIP文件路径 |
| `post_content` | string | 严格遵循排版模板、无文本公式的小红书文案 |

## 执行步骤（Steps）

### Step 1: 获取论文（Retrieve Paper）

1. 解析 `paper_reference`，识别输入类型：
   - **Arxiv链接**：从URL中提取论文ID（如从 `https://arxiv.org/abs/2301.12345` 提取 `2301.12345`）
   - **论文ID**：直接使用
   - **论文标题**：使用Arxiv API搜索获取论文ID

2. 使用Arxiv API下载论文PDF：
   - 接口：`http://export.arxiv.org/api/query?id_list={paper_id}`
   - 下载PDF格式版本
   - 保存PDF到临时工作目录

**重试策略：** 若下载失败，等待2秒后重试，最多尝试3次。

### Step 2: 视觉资产提取（Extract Visuals）

**核心原则：绝对禁止截图整个页面，必须精确裁剪目标元素区域，禁止使用AI生成图片。**

1. **遍历PDF每一页**，使用PDF解析工具识别页面内容

2. **识别定位视觉元素：**

   **Figure识别：**
   - 查找文本模式：`Figure 1:`、`Figure 2:` ... `Figure n:`（n为论文的Figure总数）
   - Figure一般为架构图、结果图等，一般存在于Figure文本的上方空间
   - 注意！需要截图完整的图片，同时避免截图到图片上下左右的文字部分

   **Table识别：**
   - 查找文本模式：`Table 1:`、`Table 2:` ... `Table m:`（m为论文的Table总数）
   - Table一般为对比实验表、消融实验表等
   - 定位表格完整区域

   **Equation识别（重点）：**
   - 识别定位到所有的Equation
   - 公式一般在其右侧会存在一个中间带数字的括号，类似 **(k)**（k为1到l的数字，l为论文的Equation总数）
   - Equation一般为数学公式、定理、推导等
   - 注意！需要截图完整的公式，同时避免截图到上下左右的文字部分

3. **精确裁剪规则：**
   - 仅截图目标元素区域，绝对禁止截图整个页面
   - 图片边距：上下左右各保留5-10像素padding
   - 分辨率：最低300 DPI
   - 禁止使用AI生成或推断图片内容

4. **规范命名保存：**
   ```
   Figure_1_Architecture.png    # 架构图
   Figure_2_Results.png        # 结果图
   Table_1_Ablation.png        # 消融实验表
   Table_2_Comparison.png     # 对比实验表
   Eq_3_Attention.png          # 公式3（注意力机制）
   Eq_7_Loss.png               # 公式7（损失函数）
   ```

5. **打包ZIP：**
   - 将所有截图按命名排序打包
   - ZIP文件名：`{paper_id}_assets.zip`

### Step 3: 撰写草稿（Draft Content）

1. **仔细阅读论文核心章节：**
   - 问题定义（Introduction）
   - 方法介绍（Method）
   - 模型架构（Model Architecture）
   - 实验部分（Experiments）

2. **按以下结构生成文案草稿：**

   ```
   [标题]
   一句话概括论文核心贡献，吸引用户点击
   
   [TLDR]（问题+解决方法+收益）
   用通俗语言说明：解决了什么问题、怎么解决的、带来了什么提升
   
   [过去面临的问题]
   简要描述该领域之前存在的痛点或局限性（内容简洁）
   
   [本文的解决方法]
   简洁介绍论文提出的核心方法或创新点（内容简洁）
   
   [核心收益]
   此处必须有实验表格截图
   格式：[图片名称]
   
   [模型架构]
   进行详细拆解：输入 → 模块 → 输出；这需要你详细阅读每一段文字，输出的内容也要详细
   必须包含公式截图
   格式：[图片名称]
   
   [实验部分]
   用图片展示实验结果
   格式：[图片名称]
   ```

3. **占位符规则（强制执行）：**
   - 所有需要展示图表的地方，强制使用 `[图片名称]` 占位符
   - 所有数学公式位置，必须用公式截图占位符替换
   - 禁止在任何位置写入LaTeX代码或Unicode数学符号

### Step 4: 反思与验证检查单（Validate Checklist）

**在输出最终内容前，必须逐项执行以下检查并修正：**

#### 检查项 1：视觉内容校验（最高优先级）

- [ ] 检查ZIP包中每个 `Figure_X` 文件是否包含完整的图表元素
- [ ] 检查每个 `Table_X` 文件是否包含完整的表格内容
- [ ] 检查每个 `Eq_X` 文件是否为纯公式区域（若为无关文本，则剔除并且重新截图）

#### 检查项 2：多模态对齐校验

- [ ] 检查草稿中每个 `[图片名称]` 是否在ZIP包中存在对应文件
- [ ] 检查文件名是否完全一致（区分大小写）
- [ ] 检查图片内容与上下文描述是否绝对匹配

#### 检查项 3：零公式违规校验

- [ ] 全局扫描草稿文本
- [ ] 确认不存在任何形式数学公式：
  - LaTeX代码（如 `$...$`、`$$...$$`、`\frac{}{}`、`\begin{align}`）
  - Unicode数学符号（如 ∑、∫、√、α、β、θ、λ）
  - 纯文本描述的公式（如 `loss = ...`、`accuracy = ...`）
- [ ] 若发现残留公式，立即替换为通俗文字描述或 `[图片名称]` 占位符

#### 检查项 4：格式完整性校验

- [ ] 标题存在且简洁（20字以内）
- [ ] TLDR包含问题、解决方法、收益三要素
- [ ] 模型架构部分，从头到尾清晰且详细，包含完整公式
- [ ] 每个章节都有对应的图片支撑

**验证失败处理：** 如果以上任何一个检查项未通过，都需要重新运行Step 4！直到完全通过为止。

### Step 5: 最终输出（Execute Final Output）

1. 确认Step 4所有检查项通过后
2. 输出打包好的ZIP文件路径：`{assets_zip_path}`
3. 输出最终定稿的文案：`{post_content}`

## 失败处理策略（On Failure）

### 论文下载失败

```
尝试次数：最多3次
间隔时间：每次失败后等待2秒
最终处理：若3次均失败，终止流程

错误提示："未能在Arxiv获取该论文，请直接提供PDF文件。"
```

### 截图或打包失败

```
原因排查：
- 网络原因导致工具调用失败 → 重新执行截图动作
- PDF解析失败 → 尝试使用备用解析方法

禁止行为：
- 禁止生成占位假图
- 禁止使用AI推断内容填充
```

### 验证检查失败

```
处理流程：
1. 记录失败的具体检查项
2. 返回Step 3修改局部草稿
3. 重新执行Step 4验证
4. 重复直到所有检查通过

注意：必须完整通过验证才能输出，禁止跳过验证步骤
```

## 示例

### 示例1：基础使用

**输入：**
```
paper_reference: "Attention Is All You Need"
```

**处理过程：**
1. 搜索论文，获取ID：1706.03762
2. 下载PDF并解析
3. 提取视觉资产：
   - Figure_1: Transformer架构图
   - Figure_2-5: 实验结果图
   - Table_1-3: 对比实验表
   - Eq_1-12: 注意力公式等
4. 生成文案草稿
5. 执行验证检查
6. 验证通过后输出

**输出：**
```json
{
  "assets_zip_path": "/workspace/1706.03762_assets.zip",
  "post_content": "【标题】Attention Is All You Need\n\n[完整小红书文案，包含所有图片占位符]..."
}
```

### 示例2：使用Arxiv ID

**输入：**
```
paper_reference: "2301.12345"
```

**输出格式相同，技能自动处理ID解析**

### 示例3：使用Arxiv链接

**输入：**
```
paper_reference: "https://arxiv.org/abs/2301.12345"
```

**输出格式相同，技能自动从URL提取论文ID**

## 注意事项

1. **绝对禁止事项：**
   - 禁止使用AI生成图表内容
   - 禁止在文案中写入任何形式的数学公式（包括LaTeX、Unicode符号）
   - 禁止截图整个PDF页面，必须精确裁剪目标元素

2. **图片质量要求：**
   - 分辨率：最低300 DPI
   - 格式：PNG
   - 命名：严格遵循 `{Type}_{Number}_{Description}.png` 格式

3. **文案风格要求：**
   - 通俗易懂，适合小红书用户阅读
   - 避免过于专业的术语堆砌
   - 强调实用价值和直观收益

4. **验证重要性：**
   - Step 4的验证检查必须逐项执行
   - 不得跳过任何检查步骤
   - 验证失败必须返回修改草稿，直到所有检查通过

5. **文件名规范：**
   - ZIP文件名：`{paper_id}_assets.zip`
   - 图片文件名：`{Type}_{Number}_{Description}.png`
   - Type可选值：Figure、Table、Eq

## 拓展说明

### 相关技能推荐

- `arxiv-paper-summary`：纯文本论文总结技能
- `academic-to-social-media`：多平台学术内容适配
- `figure-extraction`：仅提取图表的独立技能

### 技能迭代方向

1. **支持的论文源扩展：**
   - 添加对其他预印本平台的支持（ACL Anthology、IEEE等）

2. **多语言支持：**
   - 添加中文论文适配
   - 添加英文/日文等语言输出

3. **输出格式扩展：**
   - 支持生成视频脚本
   - 支持生成短视频分镜

4. **批量处理：**
   - 支持一次处理多篇论文
   - 支持生成论文系列合集