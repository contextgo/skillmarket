# 行情数据查询

## current - 查询当前行情快照

```python
current(symbols, fields='', include_call_auction=False)
```

| 参数 | 类型 | 说明 |
|------|------|------|
| symbols | str or list | 标的代码 |
| fields | str | 返回字段，默认所有 |
| include_call_auction | bool | 是否支持集合竞价(09:15-09:25)取数，默认 False |

**返回值**：`list[dict]`，每项是一个 tick 字典

```python
from gm.api import *
set_token('YOUR_TOKEN')

result = current(symbols='SZSE.000001,SHSE.600000')
for item in result:
    print(item['symbol'], item['price'])
```

**注意**：
- 实时模式返回最新 tick，回测模式只有 symbol/price/created_at 有效
- 集合竞价阶段有效字段只有 quotes

---

## history - 查询历史行情

```python
history(symbol, frequency, start_time, end_time,
        fields=None, skip_suspended=True, fill_missing=None,
        adjust=ADJUST_NONE, adjust_end_time='', df=True)
```

| 参数 | 类型 | 说明 |
|------|------|------|
| symbol | str or list | 标的代码，支持多标的 |
| frequency | str | 频率：`'tick'`、`'60s'`、`'300s'`、`'1d'` 等 |
| start_time | str/datetime | 开始时间 `%Y-%m-%d %H:%M:%S` |
| end_time | str/datetime | 结束时间 `%Y-%m-%d %H:%M:%S` |
| fields | str | 指定字段，默认全部 |
| adjust | int | 复权：`ADJUST_NONE=0`、`ADJUST_PREV=1`、`ADJUST_POST=2` |
| adjust_end_time | str | 复权基点时间，默认当前 |
| df | bool | True=返回 DataFrame，False=返回 list[dict] |

```python
# 查询日线（前复权），返回 DataFrame
df = history(symbol='SHSE.600000', frequency='1d',
             start_time='2024-01-01', end_time='2024-12-31',
             fields='open,high,low,close,volume,eob',
             adjust=ADJUST_PREV, df=True)

# 查询多标的
df = history(symbol='SHSE.600000,SZSE.000001', frequency='1d',
             start_time='2024-01-01', end_time='2024-01-31',
             df=True)

# 返回 list[dict]
data = history(symbol='SHSE.000300', frequency='1d',
               start_time='2024-01-01', end_time='2024-01-05',
               adjust=ADJUST_PREV, df=False)
```

**注意**：
- 数据区间采用**前开后闭**方式，按 eob 升序排序
- 单次最多返回 33000 条
- start_time/end_time 输入不存在的日期会报错
- `skip_suspended` 和 `fill_missing` 目前暂不支持

---

## history_n - 查询最新 N 条历史行情

```python
history_n(symbol, frequency, count, end_time=None,
          fields=None, skip_suspended=True, fill_missing=None,
          adjust=ADJUST_NONE, adjust_end_time='', df=False)
```

| 参数 | 说明 |
|------|------|
| symbol | 单标的代码（不支持多标的） |
| count | 取最新 N 条 |
| end_time | 结束时间，默认 None（取实际当前时间，非回测时间） |

```python
# 取最新100条日线（前复权）
df = history_n(symbol='SHSE.600519', frequency='1d', count=100,
               end_time='2024-12-31 15:30:00',
               fields='symbol,open,close,high,low,eob',
               adjust=ADJUST_PREV, df=True)
print(df.tail())
```

---

## context.data - 获取订阅数据滑窗

> 必须先调用 `subscribe` 才能使用

```python
data = context.data(symbol, frequency, count, fields)
```

| 参数 | 说明 |
|------|------|
| symbol | 单标的（不支持多标的） |
| frequency | 必须是已订阅的频率 |
| count | 必须 ≤ subscribe 里的 count |
| fields | 必须在 subscribe 的 fields 范围内 |

返回格式与 subscribe 的 format 参数一致：
- `format='df'`（默认）→ DataFrame
- `format='row'` → list[dict]
- `format='col'` → dict（col 模式下 tick 的 quotes 被拆分，只有买卖一档）

```python
def init(context):
    subscribe(symbols='SHSE.600519', frequency='60s', count=50,
              fields='symbol,close,eob', format='df')

def on_bar(context, bars):
    data = context.data(symbol=bars[0]['symbol'], frequency='60s', count=20)
    ma5 = data['close'].rolling(5).mean()
    print(ma5.tail())
```
