#!/usr/bin/env python3
"""
Competition Skill Generator - HTML Builder

将结构化的 Skill 方案内容填充到长图文 HTML 模板中，生成可直接浏览器打开并截图的完整 HTML 文件。

Usage:
    python generate_html.py --input content.json --output result.html
    python generate_html.py --input content.md --output result.html

Content Format (JSON):
{
    "skill_name": "手术麻醉总控助手.Skill",
    "distill_target": "三甲医院麻醉科主任，在手术过程中对病人生命体征变化的风险预判与应急处置能力",
    "risk_description": "在手术麻醉场景中，每一次判断都直接影响患者生命安全...",
    "why_choose": "手术麻醉阶段是外科手术的'生死线'...",
    "tags": {"risk": "生命安全", "barrier": "经验壁垒", "distillable": "规则清晰"},
    "standards": ["《临床麻醉学指南》：规定麻醉评估指标与操作规范", "《手术安全核查制度》：明确术前、术中、术后的标准核查流程"],
    "cases": ["某医院因麻醉深度监测不足导致术中知晓事件，暴露出'个体化麻醉方案缺失'的问题"],
    "dimensions": ["生命体征稳定性", "麻醉深度适宜性", "并发症预警及时性", "应急处置规范性"],
    "agents": [
        {"name": "术前评估Agent", "icon": "🔍", "desc": "基于患者病史、检验数据，自动评估麻醉风险等级，生成个性化麻醉方案建议。"},
        {"name": "术中预警Agent", "icon": "⚡", "desc": "实时监测生命体征数据，识别异常趋势，提前预警潜在风险。"}
    ],
    "steps": [
        {"title": "上传病历", "desc": "用户上传患者病历、检查报告等基础资料。"},
        {"title": "自动评估", "desc": "术前评估Agent分析数据，输出风险等级与麻醉方案建议。"}
    ]
}
"""

import argparse
import json
import re
import sys
from pathlib import Path


def load_content(input_path):
    """Load content from JSON or Markdown file."""
    path = Path(input_path)
    if not path.exists():
        print(f"Error: Input file not found: {input_path}")
        sys.exit(1)
    
    if path.suffix.lower() == '.json':
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    elif path.suffix.lower() in ('.md', '.markdown'):
        return parse_markdown(path.read_text(encoding='utf-8'))
    else:
        print(f"Error: Unsupported file format: {path.suffix}")
        sys.exit(1)


def parse_markdown(md_text):
    """Parse markdown content into structured data."""
    data = {}
    
    # Extract skill name
    name_match = re.search(r'[#\s]*Skill\s*名称[：:]\s*\n?\s*(.+)', md_text)
    if name_match:
        data['skill_name'] = name_match.group(1).strip()
    
    # Extract distill target
    target_match = re.search(r'蒸馏对象.*?[：:]\s*\n?\s*(.+)', md_text)
    if target_match:
        data['distill_target'] = target_match.group(1).strip()
    
    # Extract why choose
    why_match = re.search(r'选题理由.*?\n([\s\S]*?)(?=##|\n\n#)', md_text)
    if why_match:
        data['why_choose'] = why_match.group(1).strip()
    
    # Extract risk description
    risk_match = re.search(r'高风险[：:]\s*\n?\s*(.+)', md_text)
    if risk_match:
        data['risk_description'] = risk_match.group(1).strip()
    
    return data


def render_list_items(items):
    """Render list items HTML."""
    if not items:
        return '<li>待补充</li>'
    return '\n'.join(f'<li>{item}</li>' for item in items)


def render_agent_cards(agents):
    """Render agent cards HTML."""
    if not agents:
        return ''
    
    cards = []
    for agent in agents:
        name = agent.get('name', '未命名Agent')
        icon = agent.get('icon', '🤖')
        desc = agent.get('desc', '待补充职责说明')
        cards.append(f'''<div class="agent-card">
    <div class="agent-name">
        <div class="agent-icon">{icon}</div>
        {name}
    </div>
    <div class="agent-desc">{desc}</div>
</div>''')
    return '\n'.join(cards)


def render_flow_steps(steps):
    """Render flow steps HTML."""
    if not steps:
        return ''
    
    html_steps = []
    for step in steps:
        title = step.get('title', '未命名步骤')
        desc = step.get('desc', '待补充步骤说明')
        html_steps.append(f'''<div class="flow-step">
    <div class="flow-step-title">{title}</div>
    <div class="flow-step-desc">{desc}</div>
</div>''')
    return '\n'.join(html_steps)


def build_html(content, template_path):
    """Fill template with content data."""
    template = Path(template_path).read_text(encoding='utf-8')
    
    # Basic replacements
    template = template.replace('{{SKILL_NAME}}', content.get('skill_name', '未命名Skill'))
    template = template.replace('{{DISTILL_TARGET}}', content.get('distill_target', '待补充蒸馏对象'))
    template = template.replace('{{RISK_DESCRIPTION}}', content.get('risk_description', '待补充风险描述'))
    template = template.replace('{{WHY_CHOOSE}}', content.get('why_choose', '待补充选题理由'))
    
    # Tags
    tags = content.get('tags', {})
    template = template.replace('{{TAG_RISK}}', tags.get('risk', '高风险'))
    template = template.replace('{{TAG_BARRIER}}', tags.get('barrier', '高门槛'))
    template = template.replace('{{TAG_DISTILLABLE}}', tags.get('distillable', '可蒸馏'))
    
    # Lists
    template = template.replace('{{STANDARDS_LIST}}', render_list_items(content.get('standards', [])))
    template = template.replace('{{CASES_LIST}}', render_list_items(content.get('cases', [])))
    template = template.replace('{{DIMENSIONS_LIST}}', render_list_items(content.get('dimensions', [])))
    
    # Complex components
    template = template.replace('{{AGENT_CARDS}}', render_agent_cards(content.get('agents', [])))
    template = template.replace('{{FLOW_STEPS}}', render_flow_steps(content.get('steps', [])))
    
    return template


def main():
    parser = argparse.ArgumentParser(description='Build competition skill HTML from content')
    parser.add_argument('--input', '-i', required=True, help='Input content file (JSON or Markdown)')
    parser.add_argument('--output', '-o', required=True, help='Output HTML file path')
    parser.add_argument('--template', '-t', default=None, help='Custom HTML template path')
    
    args = parser.parse_args()
    
    # Determine template path
    if args.template:
        template_path = args.template
    else:
        script_dir = Path(__file__).parent
        template_path = script_dir.parent / 'assets' / 'long-image-template.html'
    
    if not Path(template_path).exists():
        print(f"Error: Template not found: {template_path}")
        sys.exit(1)
    
    # Load content and build HTML
    content = load_content(args.input)
    html = build_html(content, template_path)
    
    # Write output
    output_path = Path(args.output)
    output_path.write_text(html, encoding='utf-8')
    print(f"Successfully generated: {output_path.absolute()}")


if __name__ == '__main__':
    main()
