# {{SKILL_NAME}}

> **蒸馏对象**：{{DISTILL_TARGET}}

---

## 一、为什么选它

### 高风险场景
{{RISK_DESCRIPTION}}

### 选题理由
{{WHY_CHOOSE}}

**关键词**：`{{TAG_RISK}}` | `{{TAG_BARRIER}}` | `{{TAG_DISTILLABLE}}`

---

## 二、知识底座

### 规范与标准
{{STANDARDS_LIST}}

### 典型案例
{{CASES_LIST}}

### 核心判断维度
{{DIMENSIONS_LIST}}

---

## 三、子 Agent 协作设计

本 Skill 采用多 Agent 协作架构，各子 Agent 分工明确、协同工作：

{{AGENT_TABLE}}

---

## 四、使用流程

{{FLOW_STEPS}}

---

*AI 能力蒸馏大赛参赛作品*
