#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
未来15天逐日天气预报查询脚本
支持全国3343个区县级城市
"""

import sys
import json
import ssl
import urllib.request
import urllib.error
from datetime import datetime

# 导入内置城市映射表
from cities import CITY_MAP

# 腾讯云COS基础URL
COS_BASE_URL = "https://diga2026-1252033877.cos.ap-beijing.myqcloud.com/cww15d/"

# 创建SSL上下文
SSL_CONTEXT = ssl.create_default_context()
SSL_CONTEXT.check_hostname = False
SSL_CONTEXT.verify_mode = ssl.CERT_NONE


def fuzzy_match_city(city_name, city_map):
    """
    模糊匹配城市名
    支持：精确匹配、包含匹配、前缀匹配
    """
    if not city_name:
        return None, None
    
    # 精确匹配
    if city_name in city_map:
        return city_map[city_name], city_name
    
    # 包含匹配
    matches = [(name, cid) for name, cid in city_map.items() if city_name in name]
    if matches:
        return matches[0][1], matches[0][0]
    
    # 前缀匹配
    matches = [(name, cid) for name, cid in city_map.items() if name.startswith(city_name)]
    if matches:
        return matches[0][1], matches[0][0]
    
    return None, None


def fetch_weather_data(city_id):
    """
    从COS获取天气数据
    """
    url = f"{COS_BASE_URL}{city_id}.json"
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        with urllib.request.urlopen(req, timeout=15, context=SSL_CONTEXT) as response:
            data = json.loads(response.read().decode("utf-8"))
            return data
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise Exception(f"HTTP错误: {e.code}")
    except Exception as e:
        raise Exception(f"获取数据失败: {str(e)}")


def get_weather_emoji(weather_desc):
    """
    根据天气描述获取emoji
    """
    weather_lower = weather_desc.lower() if weather_desc else ""
    
    if "晴" in weather_desc:
        return "☀️"
    elif "多云" in weather_desc:
        return "⛅"
    elif "阴" in weather_desc and "阴天" not in weather_desc:
        return "☁️"
    elif "阴天" in weather_desc:
        return "☁️"
    elif "小雨" in weather_desc:
        return "🌧️"
    elif "中雨" in weather_desc:
        return "🌧️"
    elif "大雨" in weather_desc:
        return "⛈️"
    elif "暴雨" in weather_desc:
        return "⛈️"
    elif "雷" in weather_desc:
        return "⛈️"
    elif "雪" in weather_desc and "小雪" in weather_desc:
        return "🌨️"
    elif "雪" in weather_desc and "中雪" in weather_desc:
        return "❄️"
    elif "雪" in weather_desc and "大雪" in weather_desc:
        return "❄️"
    elif "雪" in weather_desc:
        return "🌨️"
    elif "雾" in weather_desc or "霾" in weather_desc:
        return "🌫️"
    elif "沙尘" in weather_desc or "扬沙" in weather_desc:
        return "🌪️"
    elif "雨夹雪" in weather_desc:
        return "🌨️"
    elif "阵雨" in weather_desc:
        return "🌦️"
    elif "雷阵雨" in weather_desc:
        return "⛈️"
    else:
        return "🌡️"


def get_week_day(date_str):
    """
    获取星期几
    """
    try:
        date = datetime.strptime(date_str, "%Y-%m-%d")
        week_days = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"]
        return week_days[date.weekday()]
    except:
        return ""


def query_15day_weather(city_name):
    """
    查询未来15天逐日天气预报
    """
    # 城市匹配
    city_id, matched_name = fuzzy_match_city(city_name, CITY_MAP)
    if not city_id:
        # 尝试模糊搜索建议
        suggestions = [name for name in CITY_MAP.keys() if city_name.lower() in name.lower()]
        if suggestions:
            raise ValueError(f"未找到城市: {city_name}\n您是否想找: {', '.join(suggestions[:5])}")
        raise ValueError(f"未找到城市: {city_name}")
    
    # 获取数据
    data = fetch_weather_data(city_id)
    if data is None:
        raise Exception(f"城市 {matched_name}({city_id}) 的15天预报数据不存在")
    
    return {
        "code": 0,
        "message": "success",
        "data": {
            "city_id": city_id,
            "city_name": matched_name,
            "forecast_days": len(data) if isinstance(data, list) else 0,
            "weather_data": data
        }
    }


def print_result(result):
    """
    打印格式化结果
    """
    if result.get("code") != 0:
        print(f"❌ 错误: {result.get('message', '未知错误')}")
        return
    
    data = result["data"]
    weather_list = data.get("weather_data", [])
    
    print(f"\n{'='*60}")
    print(f"📍 城市: {data['city_name']} (ID: {data['city_id']})")
    print(f"📅 预报: 未来 {data['forecast_days']} 天")
    print(f"{'='*60}")
    
    for item in weather_list:
        date = item.get("date", "未知日期")
        week = get_week_day(date)
        weather = item.get("wea", "未知")
        max_temp = item.get("maxtem", "-")
        min_temp = item.get("mintem", "-")
        wind_dir = item.get("windd", "-")
        wind_speed = item.get("winds", "-")
        
        # 获取天气emoji
        emoji = get_weather_emoji(weather)
        
        # 打印日期和星期
        print(f"\n📆 {date} {week}")
        print("-" * 50)
        print(f"  {emoji} 天气: {weather}")
        print(f"  🌡️ 温度: {min_temp}°C ~ {max_temp}°C")
        print(f"  💨 风力: {wind_dir} {wind_speed}级")
    
    print(f"\n{'='*60}")


def main():
    """
    主函数
    """
    if len(sys.argv) < 2:
        print("用法: python3 query.py <城市名>")
        print("\n示例:")
        print("  python3 query.py 北京")
        print("  python3 query.py 上海")
        print("  python3 query.py 广州")
        print("  python3 query.py 深圳")
        print("  python3 query.py 杭州")
        print(f"\n支持 {len(CITY_MAP)} 个城市/区县")
        sys.exit(1)
    
    city_name = sys.argv[1]
    
    try:
        result = query_15day_weather(city_name)
        print_result(result)
    except Exception as e:
        print(f"❌ 查询失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
