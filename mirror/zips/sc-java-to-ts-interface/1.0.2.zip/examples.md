# 示例集

## 示例 1：POST 请求 + 嵌套对象

### 输入

```
领取积分(sinoclick-ads-service)
接口地址: /api/aigc/adDelivery/claim-credit
请求方式: POST
请求数据类型: application/json

支持三种领取模式:
  单个领取: videoUuids传入单个UUID
  批量领取: videoUuids传入多个UUID
  全部领取: claimAll=true (服务端自动查询所有未领取视频)

请求参数:
参数名称    Schema              参数说明                              是否必须  数据类型
userId      Header (LoginUser)  用户ID                               true     string
videoUuids  Body                视频UUID列表 (与claimAll二选一)        false    List<String>
claimAll    Body                是否全部领取 (与videoUuids二选一)       false    Boolean

响应参数:
参数名称                参数说明                              类型
code                                                         integer
message                                                      string
result                                                       ClaimCreditResultBO
totalClaimedCredit      本次成功领取的总积分                    int
totalfailClaimedCredit  本次失败领取积分                       int
successList             成功领取明细列表                       List<ClaimDetailBO>
failList                失败明细列表                           List<ClaimDetailBO>
skipList                跳过明细列表                           List<ClaimDetailBO>

ClaimDetailBO:
参数        类型     说明
videoUuid   String   视频UUID
taskId      String   任务ID
credit      int      积分数
rewardType  String   奖励类型: BASIC_RETURN / DOUBLE_RETURN
reason      String   原因说明（仅失败时有值）
expireTime  String   过期时间，格式: yyyy-MM-dd HH:mm:ss
```

### 输出

**领取积分**

- **接口地址：** `/api/aigc/adDelivery/claim-credit`
- **请求方式：** `POST`
- **接口描述：** 用户领取视频奖励积分，支持单个、批量及全部领取三种模式
- **请求参数：**

```typescript
/** 领取积分 - 请求体 */
export interface ClaimCreditRequestBody {
  /** 视频 UUID 列表（单个或批量领取时传入，与 claimAll 二选一） */
  videoUuids?: string[];
  /** 是否全部领取（true 时服务端自动查询所有未领取视频，与 videoUuids 二选一） */
  claimAll?: boolean;
}
```

- **响应结果：**

```typescript
/** 单条领取明细 */
export interface ClaimDetailBO {
  /** 视频 UUID */
  videoUuid: string;
  /** 任务 ID */
  taskId: string;
  /** 积分数 */
  credit: number;
  /** 奖励类型: BASIC_RETURN / DOUBLE_RETURN */
  rewardType: string;
  /** 原因说明（仅失败时有值） */
  reason?: string;
  /** 过期时间，格式: yyyy-MM-dd HH:mm:ss */
  expireTime: string;
}

/** 领取积分 - 响应结果 */
export interface ClaimCreditResultBO {
  /** 本次成功领取的总积分 */
  totalClaimedCredit: number;
  /** 本次失败领取积分 */
  totalfailClaimedCredit: number;
  /** 成功领取明细列表 */
  successList: ClaimDetailBO[];
  /** 失败明细列表 */
  failList: ClaimDetailBO[];
  /** 跳过明细列表 */
  skipList: ClaimDetailBO[];
}
```

---

## 示例 2：GET 分页查询

### 输入

```
视频列表(sinoclick-ads-service)
接口地址: /api/aigc/video/list
请求方式: GET

请求参数:
参数名称    Schema    参数说明       是否必须  数据类型
userId      Header    用户ID         true     string
current     Query     当前页码       true     int
size        Query     每页大小       true     int
status      Query     视频状态       false    String (枚举: PENDING / PROCESSING / COMPLETED / FAILED)
keyword     Query     搜索关键词     false    String

响应参数:
参数名称    参数说明       类型
code                      integer
message                   string
result                    PageResult<VideoItemBO>

VideoItemBO:
参数          类型            说明
videoUuid     String          视频UUID
title         String          视频标题
status        String          视频状态: PENDING / PROCESSING / COMPLETED / FAILED
duration      Integer         视频时长（秒）
coverUrl      String          封面URL
createdTime   LocalDateTime   创建时间，格式: yyyy-MM-dd HH:mm:ss
```

### 输出

**视频列表**

- **接口地址：** `/api/aigc/video/list`
- **请求方式：** `GET`
- **接口描述：** 分页查询视频列表，支持按状态和关键词筛选
- **请求参数：**

```typescript
/** 视频列表 - 查询参数 */
export interface ListVideoRequestParams {
  /** 当前页码 */
  current: number;
  /** 每页大小 */
  size: number;
  /** 视频状态: PENDING / PROCESSING / COMPLETED / FAILED */
  status?: string;
  /** 搜索关键词 */
  keyword?: string;
}
```

- **响应结果：**

```typescript
/** 视频列表项 */
export interface VideoItemBO {
  /** 视频 UUID */
  videoUuid: string;
  /** 视频标题 */
  title: string;
  /** 视频状态: PENDING / PROCESSING / COMPLETED / FAILED */
  status: string;
  /** 视频时长（秒） */
  duration: number;
  /** 封面 URL */
  coverUrl: string;
  /** 创建时间，格式: yyyy-MM-dd HH:mm:ss */
  createdTime: string;
}

/** 视频列表 - 分页响应结果 */
export interface ListVideoPageResultBO {
  /** 总记录数 */
  total: number;
  /** 数据列表 */
  result: VideoItemBO[];
}
```

---

## 示例 3：Path 参数 + 无请求体

### 输入

```
视频详情
接口地址: /api/aigc/video/{videoUuid}
请求方式: GET

请求参数:
参数名称    Schema    参数说明    是否必须  数据类型
videoUuid   Path      视频UUID    true     String

响应参数:
参数名称      参数说明              类型
code                               integer
message                            string
result                             VideoDetailBO

VideoDetailBO:
参数          类型            说明
videoUuid     String          视频UUID
title         String          视频标题
description   String          视频描述
status        String          视频状态: PENDING / PROCESSING / COMPLETED / FAILED
fileUrl       String          视频文件URL
duration      Integer         视频时长（秒）
fileSize      Long            文件大小（字节）
createdTime   LocalDateTime   创建时间，格式: yyyy-MM-dd HH:mm:ss
updatedTime   LocalDateTime   更新时间，格式: yyyy-MM-dd HH:mm:ss
```

### 输出

**视频详情**

- **接口地址：** `/api/aigc/video/{videoUuid}`
- **请求方式：** `GET`
- **接口描述：** 根据视频 UUID 获取视频详细信息
- **响应结果：**

```typescript
/** 视频详情 - 响应结果 */
export interface VideoDetailBO {
  /** 视频 UUID */
  videoUuid: string;
  /** 视频标题 */
  title: string;
  /** 视频描述 */
  description: string;
  /** 视频状态: PENDING / PROCESSING / COMPLETED / FAILED */
  status: string;
  /** 视频文件 URL */
  fileUrl: string;
  /** 视频时长（秒） */
  duration: number;
  /** 文件大小（字节） */
  fileSize: number;
  /** 创建时间，格式: yyyy-MM-dd HH:mm:ss */
  createdTime: string;
  /** 更新时间，格式: yyyy-MM-dd HH:mm:ss */
  updatedTime: string;
}
```

> 注意：此接口仅有 Path 参数，无请求体，因此省略「请求参数」部分。
