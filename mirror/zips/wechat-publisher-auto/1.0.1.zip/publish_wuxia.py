import os
import sys
import json
import requests

# 动态路径探测
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from core.config_manager import ConfigManager
from core.image_generator import ImageGenerator

def main():
    root_dir = os.path.dirname(os.path.abspath(__file__))
    cm = ConfigManager(root_dir)
    config = cm.load()
    
    if not config.get('app_id') or not config.get('app_secret'):
        print("❌ 未找到公众号凭证，请先运行配置向导。")
        return

    # 1. 准备内容
    title = "江湖不远，就在指尖：数字时代的武侠梦"
    html_content = """<section style="margin: 0px auto; text-align: justify; line-height: 1.75; letter-spacing: 1px;"><p style="font-size: 15px; color: #333;"><strong>江湖是什么？</strong></p><p style="font-size: 15px; color: #333;">在金庸笔下，江湖是快意恩仇，是刀光剑影。而在数字时代，江湖或许就藏在你我指尖滑动的屏幕里。</p><section style="margin: 20px 0; padding: 15px; background-color: #f9f9f9; border-left: 4px solid #ff7f50;"><p style="font-size: 14px; color: #666; margin: 0;">“有人的地方，就有江湖。”</p></section><p style="font-size: 15px; color: #333;">当我们谈论武侠时，我们谈论的不仅仅是一种文学体裁，更是一种关于<strong>自由、正义与自我实现</strong>的精神图腾。</p><p style="font-size: 15px; color: #333;">在这个代码构建的新世界里，每一个开发者都是侠客，每一行代码都是剑招。我们在这片数字江湖中，寻找着属于自己的“独孤九剑”。</p><p style="font-size: 15px; color: #333; text-align: center; margin-top: 30px;"><span style="color: #ff7f50;">— END —</span></p></section>"""
    
    # 2. 获取 Token
    token_url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={config['app_id']}&secret={config['app_secret']}"
    resp = requests.get(token_url)
    resp.encoding = 'utf-8'
    token_data = resp.json()
    
    if 'access_token' not in token_data:
        print(f"❌ 获取 Token 失败: {token_data}")
        return
        
    access_token = token_data['access_token']
    print("✅ 成功获取 Access Token")

    # 3. 上传封面图 (安全修复：移除硬编码 OSS URL，改为使用本地图片或动态生成)
    # 方案 A: 使用 ImageGenerator 动态生成 (推荐)
    print("🎨 正在生成封面图...")
    img_gen = ImageGenerator(model=config.get('image_model', 'wanx-v1'), api_key=config['image_api_key'])
    cover_prompt = "扁平插画风格，温暖橘色调，武侠与科技融合的场景，极简主义，16:9 构图"
    cover_path = img_gen.generate(cover_prompt)
    
    if not cover_path or not os.path.exists(cover_path):
        print("❌ 封面图生成失败，请检查 API Key 配置。")
        return
        
    temp_img_path = cover_path # 直接使用生成的图片
        
    upload_url = f"https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={access_token}&type=image"
    files = {'media': ('cover.jpg', open(temp_img_path, 'rb'), 'image/jpeg')}
    upload_resp = requests.post(upload_url, files=files)
    upload_resp.encoding = 'utf-8'
    upload_data = upload_resp.json()
    
    thumb_media_id = upload_data.get('media_id')
    if not thumb_media_id:
        print(f"❌ 封面图上传失败: {upload_data}")
        return
    print(f"✅ 封面图上传成功，Media ID: {thumb_media_id}")

    # 4. 发布到草稿箱
    draft_url = f"https://api.weixin.qq.com/cgi-bin/draft/add?access_token={access_token}"
    payload = {
        "articles": [{
            "title": title,
            "author": "Mobius",
            "content": html_content,
            "thumb_media_id": thumb_media_id,
            "need_open_comment": 0,
            "only_fans_can_comment": 0
        }]
    }
    
    headers = {'Content-Type': 'application/json; charset=utf-8'}
    data_bytes = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    
    draft_resp = requests.post(draft_url, data=data_bytes, headers=headers)
    draft_resp.encoding = 'utf-8'
    result = draft_resp.json()
    
    if 'media_id' in result:
        print(f"🎉 发布成功！草稿箱 Media ID: {result['media_id']}")
    else:
        print(f"❌ 发布失败: {result}")

if __name__ == "__main__":
    main()
