import os
import requests
from .image_adapters import WanxAdapter, Dalle3Adapter

class ImageGenerator:
    def __init__(self, model='wanx-v1', api_key=''):
        self.model = model
        if model == 'dall-e-3':
            self.adapter = Dalle3Adapter(api_key)
        else:
            self.adapter = WanxAdapter(api_key)

    def generate(self, prompt):
        """生成图片并返回本地路径"""
        return self.adapter.generate(prompt)

    def upload_to_wechat(self, token, image_path):
        """上传图片到微信并获取 media_id"""
        url = f"https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={token}&type=image"
        with open(image_path, 'rb') as f:
            files = {'media': f}
            response = requests.post(url, files=files)
            result = response.json()
            if 'media_id' in result:
                return result['media_id']
            else:
                print(f"❌ 封面图上传失败: {result}")
                return None
