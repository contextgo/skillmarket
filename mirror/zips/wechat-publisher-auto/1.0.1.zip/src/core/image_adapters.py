import os
import time
import requests

class WanxAdapter:
    def __init__(self, api_key):
        self.api_key = api_key
        self.url = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis"

    def generate(self, prompt, output_dir="output"):
        """生成图片并返回本地路径"""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "X-DashScope-Async": "enable"
        }
        payload = {
            "model": "wanx-v1",
            "input": {"prompt": prompt},
            "parameters": {"size": "1024*1024", "n": 1}
        }
        response = requests.post(self.url, json=payload, headers=headers)
        result = response.json()
        
        # 异步任务处理（简化版：实际需轮询 task_id）
        if 'output' in result and 'task_id' in result['output']:
            task_id = result['output']['task_id']
            return self._poll_task(task_id, output_dir)
        return None

    def _poll_task(self, task_id, output_dir):
        fetch_url = f"https://dashscope.aliyuncs.com/api/v1/tasks/{task_id}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        for _ in range(30): # 最多等待 30 次
            time.sleep(2)
            resp = requests.get(fetch_url, headers=headers)
            data = resp.json()
            if data.get('output', {}).get('task_status') == 'SUCCEEDED':
                img_url = data['output']['results'][0]['url']
                return self._download_image(img_url, output_dir)
        return None

    def _download_image(self, url, output_dir):
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        path = os.path.join(output_dir, f"cover_{int(time.time())}.png")
        with open(path, 'wb') as f:
            f.write(requests.get(url).content)
        return path

class Dalle3Adapter:
    def __init__(self, api_key):
        self.api_key = api_key
        self.url = "https://api.openai.com/v1/images/generations"

    def generate(self, prompt, output_dir="output"):
        """生成图片并返回本地路径"""
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {"model": "dall-e-3", "prompt": prompt, "n": 1, "size": "1024x1024"}
        response = requests.post(self.url, json=payload, headers=headers)
        result = response.json()
        if 'data' in result:
            img_url = result['data'][0]['url']
            return self._download_image(img_url, output_dir)
        return None

    def _download_image(self, url, output_dir):
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        path = os.path.join(output_dir, f"cover_{int(time.time())}.png")
        with open(path, 'wb') as f:
            f.write(requests.get(url).content)
        return path
