import requests
import json

class WechatApiClient:
    def __init__(self, app_id, app_secret):
        self.app_id = app_id
        self.app_secret = app_secret
        self.base_url = "https://api.weixin.qq.com"
        self.access_token = None

    def get_token(self):
        url = f"{self.base_url}/cgi-bin/token?grant_type=client_credential&appid={self.app_id}&secret={self.app_secret}"
        resp = requests.get(url)
        data = resp.json()
        if 'access_token' in data:
            self.access_token = data['access_token']
        return self.access_token

    def publish_to_draft(self, title, content, thumb_media_id):
        if not self.access_token:
            self.get_token()
        url = f"{self.base_url}/cgi-bin/draft/add?access_token={self.access_token}"
        
        payload = {
            "articles": [{
                "title": title,
                "author": "Mobius",
                "content": content,
                "thumb_media_id": thumb_media_id,
                "need_open_comment": 0,
                "only_fans_can_comment": 0
            }]
        }
        
        # 字节流直传，防止中文乱码
        headers = {'Content-Type': 'application/json; charset=utf-8'}
        data_bytes = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        
        resp = requests.post(url, data=data_bytes, headers=headers)
        resp.encoding = 'utf-8'
        return resp.json()
