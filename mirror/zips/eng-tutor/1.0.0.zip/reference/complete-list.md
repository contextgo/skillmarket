# 英语常用词根、前缀、后缀总结

## 目录
1. 前缀 (Prefixes)
2. 后缀 (Suffixes)
3. 词根 (Roots)

---

## 前缀 (Prefixes)

前缀加在词根前面，改变单词的含义。

### 否定前缀

| 前缀 | 含义 | 例词 |
|------|------|------|
| **a-/an-** | 无，不 | amoral (adj.非道德的), anonymous (adj.匿名的), atypical (adj.非典型的), anaerobic (adj.厌氧的) |
| | | *His decision was **amoral**, not immoral.* (他的决定是非道德的，不是不道德的。) |
| | | *The author wishes to remain **anonymous**.* (作者希望保持匿名。) |
| **anti-** | 反对，相反 | antiwar (adj.反战的), antibiotic (n.抗生素), antisocial (adj.反社会的), antifreeze (n.防冻剂) |
| | | *She joined an **antiwar** protest.* (她参加了一场反战抗议。) |
| | | *The doctor prescribed an **antibiotic** for my infection.* (医生为我的感染开了抗生素。) |
| **counter-** | 相反，对抗 | counteract (v.抵消), counterattack (n.反击), counterargument (n.反驳) |
| | | *We need to **counteract** the negative effects.* (我们需要抵消这些负面影响。) |
| | | *The army launched a **counterattack** at dawn.* (军队在黎明时发动了反击。) |
| **dis-** | 不，相反 | disagree (v.不同意), disappear (v.消失), disable (v.使残疾), distrust (v.不信任) |
| | | *I have to **disagree** with you on this point.* (在这一点上我不得不不同意你。) |
| | | *The sun **disappeared** behind the clouds.* (太阳消失在云层后面。) |
| **il-/im-/in-/ir-** | 不，非 | illegal (adj.非法的), impossible (adj.不可能的), inactive (adj.不活跃的), irregular (adj.不规则的) |
| | | *It's **illegal** to park here.* (在这里停车是违法的。) |
| | | *Nothing is **impossible** if you try hard enough.* (如果你足够努力，没有什么是不可能的。) |
| **mis-** | 错误，坏 | misunderstand (v.误解), mislead (v.误导), mistake (n.错误), misfortune (n.不幸) |
| | | *I think you **misunderstand** what I mean.* (我想你误解了我的意思。) |
| | | *I'm sorry, I made a **mistake**.* (对不起，我犯了个错误。) |
| **non-** | 不，非 | nonsense (n.胡说), nonstop (adj.直达的), nonprofit (adj.非营利的), nonfiction (n.非虚构) |
| | | *That's absolute **nonsense**!* (那完全是胡说八道！) |
| | | *We took a **nonstop** flight to Tokyo.* (我们乘坐直达航班飞往东京。) |
| **un-** | 不，非 | unhappy (adj.不快乐的), unfair (adj.不公平的), unable (adj.不能的), unknown (adj.未知的) |
| | | *She looked **unhappy** with the result.* (她看起来对结果不满意。) |
| | | *It's **unfair** to blame him for everything.* (把一切都怪在他头上是不公平的。) |

### 数量前缀

| 前缀 | 含义 | 例词 |
|------|------|------|
| **mono-** | 一，单一 | monologue (n.独白), monopoly (n.垄断), monochrome (adj.单色的), monotonous (adj.单调的) |
| | | *He delivered a 10-minute **monologue**.* (他发表了一段 10 分钟的独白。) |
| | | *The company had a **monopoly** on the market.* (该公司在市场上拥有垄断地位。) |
| **bi-** | 二，双 | bicycle (n.自行车), bilingual (adj.双语的), bilateral (adj.双边的), biennial (adj.两年一次的) |
| | | *She rides her **bicycle** to work every day.* (她每天骑自行车上班。) |
| | | *He is **bilingual** in English and French.* (他能说流利的英语和法语。) |
| **di-** | 二，双 | dioxide (n.二氧化物), dilemma (n.困境), dichotomy (n.二分法), digraph (n.双字母) |
| | | *Carbon **dioxide** is a greenhouse gas.* (二氧化碳是一种温室气体。) |
| | | *I'm in a **dilemma** about which job to take.* (我在选择哪份工作上有两难。) |
| **tri-** | 三 | triangle (n.三角形), tricycle (n.三轮车), trilogy (n.三部曲), triathlon (n.铁人三项) |
| | | *Draw a right **triangle** on the board.* (在黑板上画一个直角三角形。) |
| | | *The movie **trilogy** was very popular.* (这部电影三部曲很受欢迎。) |
| **multi-** | 多 | multiple (adj.多个的), multicultural (adj.多元文化的), multimedia (n.多媒体), multiply (v.乘) |
| | | *She has **multiple** interests.* (她有多种兴趣爱好。) |
| | | *New York is a **multicultural** city.* (纽约是一个多元文化的城市。) |
| **poly-** | 多 | polygon (n.多边形), polytechnic (adj.多工艺的), polygamy (n.一夫多妻), polyphonic (adj.复调的) |
| | | *A pentagon is a **polygon** with five sides.* (五边形是有五条边的多边形。) |
| **semi-** | 半 | semicircle (n.半圆), semiconductor (n.半导体), semifinal (n.半决赛), semiautomatic (adj.半自动的) |
| | | *The players are in the **semifinal**.* (选手们正在参加半决赛。) |
| **pan-** | 全，泛 | panorama (n.全景), pandemic (adj.大流行的), pantheon (n.万神殿), panacea (n.万能药) |
| | | *The **pandemic** affected the whole world.* (这场大流行影响了全世界。) |
| | | *There is no **panacea** for all problems.* (没有解决所有问题的万能药。) |

### 位置/方向前缀

| 前缀 | 含义 | 例词 |
|------|------|------|
| **ante-** | 前，先 | anteroom (n.前厅), antedate (v.早于), antebellum (adj.战前的), antechamber (n.前室) |
| | | *The guests waited in the **anteroom**.* (客人们在前厅等候。) |
| **anti-** | 反对 | antidote (n.解毒剂), antibody (n.抗体), antithesis (n.对立面) |
| | | *There is no **antidote** for this poison.* (这种毒药没有解毒剂。) |
| | | *The body produces **antibodies** to fight infection.* (身体产生抗体来对抗感染。) |
| **circum-** | 环绕 | circumference (n.圆周), circumnavigate (v.环球航行), circumspect (adj.谨慎的) |
| | | *Calculate the **circumference** of the circle.* (计算圆的周长。) |
| | | *Magellan was the first to **circumnavigate** the globe.* (麦哲伦是第一个环球航行的人。) |
| **ex-/e-/ef-** | 出，外 | exit (n.出口), eject (v.喷射), emit (v.发出), exhale (v.呼气), efface (v.抹去) |
| | | *Where is the nearest **exit**?* (最近的出口在哪里？) |
| | | *Take a deep breath and **exhale** slowly.* (深呼吸，慢慢呼气。) |
| **extra-** | 超出 | extraordinary (adj.非凡的), extracurricular (adj.课外的), extraterrestrial (adj.外星的) |
| | | *She has **extraordinary** talent.* (她有非凡的才能。) |
| | | *He joined several **extracurricular** activities.* (他参加了几个课外活动。) |
| **fore-** | 前，预先 | foretell (v.预言), forecast (n.预测), forehead (n.前额), foreword (n.前言) |
| | | *The weather **forecast** says it will rain.* (天气预报说会下雨。) |
| | | *She touched her **forehead** nervously.* (她紧张地摸了摸额头。) |
| **in-/im-/il-** | 向内 | input (n.输入), import (v.进口), include (v.包括), illuminate (v.照亮), illegal (adj.非法的) |
| | | *We need more **input** from the team.* (我们需要团队更多的投入。) |
| | | *Does the price **include** tax?* (这个价格含税吗？) |
| **inter-** | 在...之间 | international (adj.国际的), interact (v.互动), intervene (v.干预), interchange (n.交换) |
| | | *It's an **international** conference.* (这是一个国际会议。) |
| | | *The teacher **interacted** with the students.* (老师与学生们互动。) |
| **intra-** | 在...内部 | intranet (n.内联网), intravenous (adj.静脉内的), intramural (adj.内部的) |
| | | *The company uses an **intranet** for communication.* (公司使用内联网进行通讯。) |
| **meta-** | 超越，变化 | metaphysics (n.形而上学), metamorphosis (n.变形), metaphor (n.隐喻) |
| | | *The caterpillar undergoes **metamorphosis**.* (毛毛虫经历变形。) |
| | | *He often speaks in **metaphor**.* (他经常用隐喻说话。) |
| **out-** | 超过，在外 | outdo (v.超过), outrun (v.超过), outlook (n.展望), outpatient (n.门诊病人) |
| | | *She always tries to **outdo** her competitors.* (她总是试图超过竞争对手。) |
| | | *He is an **outpatient** at the hospital.* (他是医院的门诊病人。) |
| **over-** | 超过，过度 | overeat (v.暴食), overwork (v.过度工作), overlook (v.忽视), overflow (v.溢出) |
| | | *Don't **overeat** at dinner.* (晚餐不要暴饮暴食。) |
| | | *I tend to **overlook** small details.* (我 tends to 忽视小细节。) |
| **para-** | 旁边，辅助 | parallel (adj.平行的), parachute (n.降落伞), paramedic (n.护理人员), paraphrase (v.释义) |
| | | *The roads run **parallel** to each other.* (这两条路互相平行。) |
| | | *The **paramedic** treated the injured.* (护理人员治疗了伤者。) |
| **per-** | 穿过，完全 | permeate (v.渗透), permanent (adj.永久的), perfect (adj.完美的), persist (v.坚持) |
| | | *This is a **permanent** solution.* (这是一个永久的解决方案。) |
| | | *Nobody is **perfect**.* (没有人是完美的。) |
| | | *If problems **persist**, seek help.* (如果问题持续存在，请寻求帮助。) |
| **post-** | 后 | postwar (adj.战后的), postpone (v.推迟), postscript (n.附言), postgraduate (n.研究生) |
| | | *We need to **postpone** the meeting.* (我们需要推迟会议。) |
| | | *She is a **postgraduate** student.* (她是一名研究生。) |
| **pre-** | 前，预先 | preview (n.预览), predict (v.预测), prepare (v.准备), precede (v.先于) |
| | | *Can I have a **preview** of the report?* (我能预览一下报告吗？) |
| | | *It's hard to **predict** the future.* (很难预测未来。) |
| | | *Please **prepare** for the exam.* (请准备考试。) |
| **pro-** | 向前，赞成 | progress (n.进步), promote (v.促进), propose (v.提议), pro-American (adj.亲美的) |
| | | *We are making good **progress**.* (我们正在取得良好进展。) |
| | | *He **proposed** a new plan.* (他提出了一个新计划。) |
| **re-/red-** | 回，再 | return (v.返回), recall (v.回忆), rebuild (v.重建), redo (v.重做), reduce (v.减少) |
| | | *When will you **return**?* (你什么时候回来？) |
| | | *I can't **recall** his name.* (我想不起他的名字了。) |
| | | *Try to **reduce** your sugar intake.* (尽量减少糖分摄入。) |
| **retro-** | 向后 | retroactive (adj.追溯的), retrospect (n.回顾), retrograde (adj.倒退的) |
| | | *In **retrospect**, I made a mistake.* (回想起来，我犯了个错误。) |
| **sub-** | 在下，次 | subway (n.地铁), subdivide (v.细分), submarine (n.潜艇), substandard (adj.不合格的) |
| | | *Take the **subway** to downtown.* (乘地铁去市中心。) |
>
> | 变体 | 出现位置 | 例词 |
> |------|---------|------|
> | **sub-** | 大多数情况 | **sub**way (地铁), **sub**divide (细分), **sub**marine (潜艇) |
> | **suc-** | 在 **c** 前 | **suc**ceed (成功), **suc**cumb (屈服) |
> | **suf-** | 在 **f** 前 | **suf**fer (忍受), **suf**fix (后缀), **suf**focate (窒息) |
> | **sug-** | 在 **g** 前 | **sug**gest (建议), **sug**gestive (暗示的) |
> | **sum-** | 在 **m** 前 | **sum**mon (召唤) |
> | **sup-** | 在 **p** 前 | **sup**port (支持), **sup**pose (假设), **sup**press (压制) |
> | **sus-** | 在 **c, p, t** 前 | **sus**pect (怀疑), **sus**pend (悬挂), **sus**tain (维持) |

| 前缀 | 含义 | 例词 |
|------|------|------|
| **super-** | 在上，超 | superman (n.超人), superpower (n.超级大国), supervise (v.监督), supernatural (adj.超自然的) |
| **supra-** | 在上，超越 | supranational (adj.超国家的), supramolecular (adj.超分子的) |
| **sur-** | 在上，超过 | surface (n.表面), surpass (v.超越), surcharge (n.附加费), surmount (v.克服) |
| **trans-** | 穿过，转移 | transport (v.运输), transform (v.转变), transmit (v.传输), translate (v.翻译) |
| **ultra-** | 极端，超 | ultraviolet (adj.紫外的), ultrasound (n.超声波), ultramodern (adj.超现代的) |
| **under-** | 在下，不足 | underground (adj.地下的), underestimate (v.低估), underpaid (adj.报酬过低的) |

### 程度/大小前缀

| 前缀 | 含义 | 例词 |
|------|------|------|
| **arch-** | 首要，大 | archbishop (n.大主教), archetype (n.原型), archenemy (n.头号敌人) |
| **hyper-** | 超过，过度 | hyperactive (adj.多动症的), hypersensitive (adj.过敏的), hyperbole (n.夸张) |
| **hypo-** | 在下，少于 | hypothesis (n.假设), hypodermic (adj.皮下的), hypothermia (n.体温过低) |
| **macro-** | 大 | macroeconomics (n.宏观经济学), macroscopic (adj.宏观的) |
| **micro-** | 小 | microscope (n.显微镜), microwave (n.微波), microorganism (n.微生物) |
| **mini-** | 小 | miniskirt (n.迷你裙), minivan (n.小型货车), minicomputer (n.小型计算机) |
| **mega-** | 大，百万 | megaphone (n.扩音器), megabyte (n.兆字节), megaton (n.兆吨) |

### 时间/顺序前缀

| 前缀 | 含义 | 例词 |
|------|------|------|
| **ante-** | 前 | anteroom (n.前厅), antedate (v.早于) |
| **pre-** | 预先 | prepay (v.预付), preschool (n.幼儿园), preheat (v.预热) |
| **post-** | 后 | postwar (adj.战后的), postdate (v.日期填后) |
| **fore-** | 预先 | foretell (v.预言), forewarn (v.预先警告) |
| **ex-** | 前任 | ex-president (n.前总统), ex-husband (n.前夫) |

### 关系前缀

| 前缀 | 含义 | 例词 |
|------|------|------|
| **co-/com-/con-** | 共同 | cooperate (v.合作), combine (v.结合), connect (v.连接), collaborate (v.协作) |

> **co-/com-/con- 的变体规则**（同化现象）
>
> 这些都是 **com-** 的变体，为了发音方便：
>
> | 变体 | 出现位置 | 例词 |
> |------|---------|------|
> | **com-** | 在 **b, m, p** 前 | **com**bine (结合), **com**ment (评论), **com**press (压缩) |
> | **con-** | 大多数情况 | **con**nect (连接), **con**firm (确认), **con**tain (包含) |
> | **col-** | 在 **l** 前 | **col**lect (收集), **col**lapse (倒塌), **col**lide (碰撞) |
> | **cor-** | 在 **r** 前 | **cor**rect (纠正), **cor**respond (通信), **cor**relate (相关) |
> | **co-** | 在元音或 **h** 前 | **co**operate (合作), **co**exist (共存), **co**here (连贯) |
> | **cog-** | 在 **n** 前 | **cog**nate (同源的), **cog**nitive (认知的) |

| 前缀 | 含义 | 例词 |
|------|------|------|
| **syn-/sym-** | 共同，一起 | synonym (n.同义词), sympathy (n.同情), synchronize (v.同步), symphony (n.交响乐) |

> **syn-/sym- 的变体**：**sym-** 在 **b, m, p** 前，如 **sym**pathy (同情), **sym**bol (符号), **sym**metry (对称)

| 前缀 | 含义 | 例词 |
|------|------|------|
| **dia-** | 穿过，对角 | dialogue (n.对话), diameter (n.直径), diagram (n.图表), diagnose (v.诊断) |

### 其他常用前缀

| 前缀 | 含义 | 例词 |
|------|------|------|
| **ab-/abs-** | 离开，远离 | absent (adj.缺席的), absorb (v.吸收), abnormal (adj.异常的), abduct (v.绑架) |

> **ab- 的变体**：**abs-** 在 **c, t** 前，如 **abs**tract (抽象), **abs**tain (克制)

| 前缀 | 含义 | 例词 |
|------|------|------|
| **ad-** | 向，朝 | advance (v.前进), adapt (v.适应), adhere (v.粘附), adjust (v.调整) |

> **ad- 的变体规则**（同化现象）
>
> **ad-** 为了发音方便，在不同字母前会发生变化：
>
> | 变体 | 出现位置 | 例词 |
> |------|---------|------|
> | **ad-** | 大多数情况 | ad**v**ance (前进), ad**d**ress (地址), ad**m**it (承认) |
> | **ac-** | 在 **c, k, q** 前 | **ac**cess (进入), **ac**company (陪伴), **ac**quire (获得), **ac**knowledge (承认) |
> | **af-** | 在 **f** 前 | **af**fect (影响), **af**firm (肯定), **af**fix (附加) |
> | **ag-** | 在 **g** 前 | **ag**gress (侵略), **ag**gravate (加重), **ag**gregate (聚集) |
> | **al-** | 在 **l** 前 | **al**low (允许), **al**lege (声称), **al**lure (引诱) |
> | **an-** | 在 **n** 前 | **an**nex (兼并), **an**nounce (宣布), **an**nul (废除) |
> | **ap-** | 在 **p** 前 | **ap**pear (出现), **ap**ply (应用), **ap**pose (对立) |
> | **as-** | 在 **s** 前 | **as**sent (同意), **as**sure (保证), **as**sociate (联想) |
> | **at-** | 在 **t** 前 | **at**tract (吸引), **at**tain (达到), **at**tempt (尝试) |
>
> **记忆口诀**：ad- 前缀真多变，遇到 c/k/q 变成 ac-，遇到 f 变成 af-，遇到 g 变成 ag-，遇到 l 变成 al-，遇到 n 变成 an-，遇到 p 变成 ap-，遇到 s 变成 as-，遇到 t 变成 at-。

| 前缀 | 含义 | 例词 |
|------|------|------|
| **amb-/amphi-** | 两，双 | ambiguous (adj.模棱两可的), amphibian (n.两栖动物), amphitheater (n.圆形剧场) |
| **ana-** | 向上，再，分开 | analysis (n.分析), anabaptism (n.再洗礼), anagram (n.回文), anabolism (n.合成代谢) |
| **apo-** | 远离，脱离 | apology (n.道歉), apostle (n.使徒), apogee (n.远地点), apocryphal (adj.伪的) |
| **cata-** | 向下，完全 | catastrophe (n.灾难), catalyst (n.催化剂), catalog (n.目录), cataract (n.白内障) |
| **dys-** | 不良，困难 | dysfunction (n.功能障碍), dyslexia (n.阅读障碍), dyspnea (n.呼吸困难) |
| **ec-/ect-** | 外，出 | eccentric (adj.古怪的), ectoderm (n.外胚层), ectopic (adj.异位的) |
| **em-/en-** | 使进入，使... | empower (v.授权), enclose (v.围住), enable (v.使能够), enrich (v.使丰富) |
| **endo-** | 内 | endogenous (adj.内生的), endoskeleton (n.内骨骼), endoscope (n.内窥镜) |
| **epi-** | 在...上，周围 | epidemic (adj.流行的), epilogue (n.结语), epidermis (n.表皮), epitome (n.缩影) |
| **eu-** | 好，优 | eulogy (n.颂词), euphemism (n.委婉语), eugenics (n.优生学), euphoria (n.欣快感) |
| **infra-** | 在下，低于 | infrastructure (n.基础设施), infrared (adj.红外的), infrasonic (adj.次声的) |
| **ob-** | 朝向，反对 | object (v.反对), observe (v.观察), obstacle (n.障碍), obscure (adj.模糊的) |
| **peri-** | 周围 | perimeter (n.周长), periscope (n.潜望镜), period (n.周期), pericardium (n.心包) |
| **proto-** | 原始，第一 | prototype (n.原型), protocol (n.协议), proton (n.质子), protozoa (n.原生动物) |
| **pseudo-** | 假，伪 | pseudonym (n.笔名), pseudoscience (n.伪科学), pseudopod (n.伪足) |
| **subter-** | 在下，秘密 | subterfuge (n.托词), subterranean (adj.地下的) |
| **out-** | 超过，向外 | outweigh (v.超过), outlive (v.比...活得长), outnumber (v.数量超过) |

---

## 后缀 (Suffixes)

后缀加在词根后面，改变单词的词性或含义。

### 名词后缀

#### 表示人

| 后缀 | 含义 | 例词 |
|------|------|------|
| **-er/-or** | ...的人 | teacher (n.教师), worker (n.工人), actor (n.演员), doctor (n.医生) |
| | | *My **teacher** is very patient.* (我的老师很有耐心。) |
| | | *He wants to be an **actor**.* (他想成为一名演员。) |
| **-ist** | ...主义者/专家 | artist (n.艺术家), scientist (n.科学家), pianist (n.钢琴家), socialist (n.社会主义者) |
| | | *She is a talented **artist**.* (她是一位有才华的艺术家。) |
| | | *The **scientist** made a breakthrough.* (这位科学家取得了突破。) |
| **-ant/-ent** | ...的人 | assistant (n.助手), student (n.学生), president (n.总统), accountant (n.会计师) |
| | | *The **assistant** helped me with the form.* (助手帮我填了表格。) |
| | | *She is a high school **student**.* (她是一名高中生。) |
| | | *The **president** gave a speech.* (总统发表了演讲。) |
| **-ian** | ...的人 | musician (n.音乐家), politician (n.政治家), technician (n.技术员), magician (n.魔术师) |
| | | *He is a professional **musician**.* (他是一位职业音乐家。) |
| | | *The **technician** fixed the computer.* (技术员修好了电脑。) |
| **-ee** | 被...的人 | employee (n.雇员), interviewee (n.受访者), addressee (n.收件人) |
| | | *The **employee** received a bonus.* (雇员收到了奖金。) |
| | | *The **interviewee** answered all questions.* (受访者回答了所有问题。) |
| **-eer** | 从事...的人 | engineer (n.工程师), volunteer (n.志愿者), mountaineer (n.登山者) |
| | | *She works as an **engineer**.* (她是一名工程师。) |
| | | *The **volunteer** helped at the shelter.* (志愿者在收容所帮忙。) |
| **-ese** | ...国人/语言 | Chinese (n.中国人), Japanese (n.日本人), Portuguese (n.葡萄牙人) |
| | | *He is **Chinese**.* (他是中国人。) |
| | | *She speaks **Japanese** fluently.* (她能说流利的日语。) |
| **-ess** | 女性 | actress (n.女演员), waitress (n.女服务员), hostess (n.女主人), princess (n.公主) |
| | | *The **actress** won an award.* (这位女演员获奖了。) |
| | | *The **waitress** brought us the menu.* (女服务员给我们拿来菜单。) |

#### 表示状态、性质

| 后缀 | 含义 | 例词 |
|------|------|------|
| **-tion/-sion** | 状态，行为 | action (n.行动), decision (n.决定), education (n.教育), discussion (n.讨论) |
| | | *We need to take **action** now.* (我们需要立即采取行动。) |
| | | *It's time to make a **decision**.* (是时候做决定了。) |
| | | *She works in **education**.* (她从事教育工作。) |
| **-ment** | 行为，状态 | movement (n.运动), government (n.政府), development (n.发展) |
| | | *The **movement** was very slow.* (进展非常缓慢。) |
| | | *The **government** announced a new policy.* (政府宣布了一项新政策。) |
| **-ness** | 性质，状态 | happiness (n.幸福), kindness (n.善良), darkness (n.黑暗), illness (n.疾病) |
| | | *Money can't buy **happiness**.* (金钱买不到幸福。) |
| | | *Thank you for your **kindness**.* (谢谢你的好意。) |
| **-ity/-ty** | 性质，状态 | ability (n.能力), reality (n.现实), safety (n.安全), quality (n.质量) |
| | | *She has the **ability** to succeed.* (她有成功的能力。) |
| | | *Face **reality**.* (面对现实吧。) |
| | | *Your **safety** is our priority.* (你的安全是我们的首要任务。) |
| **-ance/-ence** | 状态，性质 | importance (n.重要性), difference (n.差异), existence (n.存在), tolerance (n.宽容) |
| | | *I understand the **importance** of this.* (我明白这的重要性。) |
| | | *What's the **difference**?* (有什么区别？) |
| **-cy** | 状态，性质 | accuracy (n.准确), democracy (n.民主), urgency (n.紧急), privacy (n.隐私) |
| | | *Check the **accuracy** of the data.* (检查数据的准确性。) |
| | | *We live in a **democracy**.* (我们生活在民主国家。) |
| | | *Your **privacy** is protected.* (你的隐私受保护。) |
| **-dom** | 状态，领域 | freedom (n.自由), kingdom (n.王国), wisdom (n.智慧), boredom (n.无聊) |
| | | *We value our **freedom**.* (我们珍视自由。) |
| | | *He gave me some good **wisdom**.* (他给了我一些明智的建议。) |
| **-hood** | 状态，时期 | childhood (n.童年), brotherhood (n.兄弟情谊), likelihood (n.可能性) |
| | | *I had a happy **childhood**.* (我有一个幸福的童年。) |
| | | *There's no **likelihood** of rain today.* (今天不太可能下雨。) |
| **-ship** | 关系，身份 | friendship (n.友谊), leadership (n.领导), scholarship (n.奖学金) |
| | | *Their **friendship** lasted for years.* (他们的友谊持续了多年。) |
| | | *She showed great **leadership**.* (她展现了出色的领导能力。) |
| **-th** | 状态，性质 | warmth (n.温暖), length (n.长度), strength (n.力量), depth (n.深度) |
| | | *The **warmth** of the sun felt good.* (阳光的温暖让人舒服。) |
| | | *What's the **length** of the river?* (这条河有多长？) |
| | | *He has great **strength**.* (他力气很大。) |

#### 表示小

| 后缀 | 含义 | 例词 |
|------|------|------|
| **-let** | 小 | booklet (n.小册子), droplet (n.小滴), eyelet (n.小孔) |
| | | *Pick up a **booklet** at the desk.* (在柜台拿一本小册子。) |
| **-ette** | 小，女性 | cigarette (n.香烟), kitchenette (n.小厨房), suffragette (n.争取选举权者) |
| | | *He quit smoking **cigarettes**.* (他戒了香烟。) |
| **-ling** | 小，幼 | duckling (n.小鸭子), sapling (n.树苗), fledgling (n.雏鸟) |
| | | *The **duckling** followed its mother.* (小鸭子跟着妈妈。) |
| **-y/-ie** | 小，亲昵 | doggy (n.小狗), kitty (n.小猫), mommy (n.妈妈), daddy (n.爸爸) |
| | | *Look at that cute **doggy**!* (看那只可爱的小狗！) |
| | | *Where's **mommy**?* (妈妈在哪里？) |

### 形容词后缀

| 后缀 | 含义 | 例词 |
|------|------|------|
| **-able/-ible** | 能...的 | capable (adj.有能力的), visible (adj.可见的), possible (adj.可能的), readable (adj.可读的) |
| | | *She is **capable** of doing the job.* (她有能力做这份工作。) |
| | | *Is the star **visible** tonight?* (今晚能看到那颗星星吗？) |
| | | *I'll come if **possible**.* (如果可能的话我会来。) |
| **-al** | ...的 | natural (adj.自然的), national (adj.国家的), logical (adj.逻辑的), musical (adj.音乐的) |
| | | *It's a **natural** reaction.* (这是自然反应。) |
| | | *It's a **national** holiday.* (这是一个国家法定假日。) |
| **-an/-ian** | ...的 | urban (adj.城市的), suburban (adj.郊区的), Canadian (adj.加拿大的), Italian (adj.意大利的) |
| | | *He lives in an **urban** area.* (他住在市区。) |
| | | *She is **Canadian**.* (她是加拿大人。) |
| **-ar** | ...的 | similar (adj.相似的), popular (adj.流行的), regular (adj.规律的), particular (adj.特别的) |
| | | *Your case is **similar** to mine.* (你的情况和我的相似。) |
| | | *This song is very **popular**.* (这首歌很流行。) |
| | | *He exercises on a **regular** basis.* (他定期锻炼。) |
| **-ary** | ...的 | secondary (adj.次要的), imaginary (adj.想象的), voluntary (adj.自愿的) |
| | | *This is of **secondary** importance.* (这是次要重要的。) |
| | | *The story is **imaginary**.* (这个故事是虚构的。) |
| **-ent/-ant** | ...的 | different (adj.不同的), important (adj.重要的), excellent (adj.优秀的), pleasant (adj.愉快的) |
| | | *That's **different** from what I expected.* (那和我预期的不同。) |
| | | *This is **important**.* (这很重要。) |
| | | *She did an **excellent** job.* (她做得很出色。) |
| | | *Have a **pleasant** day!* (祝你今天愉快！) |
| **-ful** | 充满...的 | beautiful (adj.美丽的), careful (adj.小心的), helpful (adj.有帮助的), wonderful (adj.精彩的) |
| | | *What a **beautiful** day!* (多美好的一天！) |
| | | *Be **careful** with that vase.* (小心那个花瓶。) |
| | | *Thank you, that's very **helpful**.* (谢谢，那很有帮助。) |
| | | *We had a **wonderful** time.* (我们玩得很开心。) |
| **-ic** | ...的 | basic (adj.基本的), economic (adj.经济的), historic (adj.历史的), poetic (adj.诗的) |
| | | *Let me explain the **basic** idea.* (让我解释一下基本想法。) |
| | | *The **economic** situation is improving.* (经济形势正在好转。) |
| **-ical** | ...的 | historical (adj.历史的), logical (adj.逻辑的), practical (adj.实用的), magical (adj.神奇的) |
| | | *This is a **historical** event.* (这是一个历史事件。) |
| | | *That's a **logical** conclusion.* (那是一个合乎逻辑的结论。) |
| | | *Be **practical**.* (实际一点。) |
| **-ish** | 稍...的，...式的 | childish (adj.幼稚的), selfish (adj.自私的), British (adj.英国的), foolish (adj.愚蠢的) |
| | | *Don't be so **childish**.* (别这么幼稚。) |
| | | *That was a **selfish** thing to do.* (那样做很自私。) |
| | | *He is **British**.* (他是英国人。) |
| **-ive** | 有...性质的 | active (adj.积极的), creative (adj.有创造力的), effective (adj.有效的), sensitive (adj.敏感的) |
| | | *She is very **active**.* (她很活跃。) |
| | | *He has a **creative** mind.* (他很有创造力。) |
| | | *The medicine is **effective**.* (这药很有效。) |
| | | *She is **sensitive** to criticism.* (她对批评很敏感。) |
| **-less** | 无...的 | hopeless (adj.绝望的), careless (adj.粗心的), useless (adj.无用的), endless (adj.无尽的) |
| | | *The situation is not **hopeless**.* (情况并非无望。) |
| | | *Don't be so **careless**.* (别这么粗心。) |
| | | *It's **useless** to try.* (尝试是没用的。) |
| **-ous/-ious** | 多...的 | dangerous (adj.危险的), famous (adj.著名的), serious (adj.严肃的), curious (adj.好奇的) |
| | | *It's **dangerous** to swim here.* (在这里游泳很危险。) |
| | | *He is a **famous** writer.* (他是一位著名作家。) |
| | | *Are you **serious**?* (你是认真的吗？) |
| | | *I'm just **curious**.* (我只是好奇。) |
| **-y** | 多...的，有...的 | sunny (adj.阳光充足的), rainy (adj.多雨的), dirty (adj.脏的), healthy (adj.健康的) |
| | | *It's a **sunny** day.* (今天是晴天。) |
| | | *My hands are **dirty**.* (我的手脏了。) |
| | | *Eat **healthy** food.* (吃健康的食物。) |
| **-some** | 产生...的 | troublesome (adj.麻烦的), handsome (adj.英俊的), awesome (adj.令人敬畏的), lonesome (adj.孤独的) |
| | | *The kid can be **troublesome**.* (这孩子有时很麻烦。) |
| | | *He is a **handsome** man.* (他是个英俊的男人。) |
| | | *That's **awesome**!* (太棒了！) |
| **-wise** | 方向的，方式的 | clockwise (adj.顺时针的), otherwise (adv.否则), likewise (adv.同样地) |
| | | *Turn the knob **clockwise**.* (顺时针转动旋钮。) |
| | | *Hurry up, **otherwise** we'll be late.* (快点，否则我们要迟到了。) |

### 动词后缀

| 后缀 | 含义 | 例词 |
|------|------|------|
| **-ate** | 使... | activate (v.激活), create (v.创造), educate (v.教育), celebrate (v.庆祝) |
| | | *Click to **activate** the account.* (点击激活账户。) |
| | | *Let's **create** something new.* (让我们创造一些新东西。) |
| | | *He was **educated** at Harvard.* (他在哈佛接受教育。) |
| | | *We **celebrated** her birthday.* (我们庆祝了她的生日。) |
| **-en** | 使... | strengthen (v.加强), widen (v.加宽), shorten (v.缩短), brighten (v.使变亮) |
| | | *Exercise will **strengthen** your muscles.* (锻炼会增强你的肌肉。) |
| | | *They plan to **widen** the road.* (他们计划拓宽道路。) |
| | | *Can you **shorten** these pants?* (你能把这条裤子改短吗？) |
| **-ify/-fy** | 使...，...化 | simplify (v.简化), beautify (v.美化), classify (v.分类), modify (v.修改) |
| | | *Let me **simplify** this for you.* (让我为你简化一下。) |
| | | *They want to **beautify** the park.* (他们想美化公园。) |
| | | *Please **classify** these documents.* (请分类这些文件。) |
| | | *I need to **modify** my order.* (我需要修改订单。) |
| **-ize/-ise** | 使...，...化 | realize (v.实现), organize (v.组织), modernize (v.现代化), specialize (v.专攻) |
| | | *I finally **realized** my mistake.* (我终于意识到了我的错误。) |
| | | *Let's **organize** a meeting.* (让我们组织一次会议。) |
| | | *The factory was **modernized** last year.* (这家工厂去年实现了现代化。) |
| | | *She **specializes** in tax law.* (她专攻税法。) |

### 副词后缀

| 后缀 | 含义 | 例词 |
|------|------|------|
| **-ly** | ...地 | quickly (adv.快速地), happily (adv.快乐地), carefully (adv.仔细地), slowly (adv.缓慢地) |
| | | *Come **quickly**!* (快点来！) |
| | | *She smiled **happily**.* (她快乐地笑了。) |
| | | *Read the instructions **carefully**.* (仔细阅读说明。) |
| | | *Walk **slowly**.* (慢慢走。) |
| **-ward/-wards** | 向... | forward (adv.向前), backward (adv.向后), homeward (adv.向家), upwards (adv.向上) |
| | | *Move **forward**, please.* (请向前移动。) |
| | | *He glanced **backward**.* (他回头看了一眼。) |
| | | *We're heading **homeward**.* (我们正在回家的路上。) |
| | | *Look **upwards**.* (向上看。) |
| **-wise** | 在...方面 | clockwise (adv.顺时针), otherwise (adv.否则), lengthwise (adv.纵向) |
| | | *Turn **clockwise**.* (顺时针转动。) |
| | | *Hurry up, **otherwise** we'll miss the train.* (快点，否则我们要错过火车了。) |

### 补充后缀

#### 名词后缀补充

| 后缀 | 含义 | 例词 |
|------|------|------|
| **-age** | 集合，状态，费用 | baggage (n.行李), shortage (n.短缺), marriage (n.婚姻), postage (n.邮资) |
| | | *Where is my **baggage**?* (我的行李在哪里？) |
| | | *There is a **shortage** of water.* (缺水。) |
| | | *They announced their **marriage**.* (他们宣布了婚讯。) |
| **-ery/-ry** | 场所，状态，行业 | bakery (n.面包店), nursery (n.托儿所), bravery (n.勇敢), jewelry (n.珠宝) |
| | | *The **bakery** smells wonderful.* (面包店闻起来很香。) |
| | | *She dropped the kids at the **nursery**.* (她把孩子送到托儿所。) |
| | | *He was awarded for his **bravery**.* (他因勇敢而获奖。) |
| **-ism** | 主义，学说，状态 | capitalism (n.资本主义), Buddhism (n.佛教), criticism (n.批评) |
| | | ***Capitalism** has its critics.* (资本主义有其批评者。) |
| | | *He practices **Buddhism**.* (他信奉佛教。) |
| | | *I can't take all this **criticism**.* (我受不了这些批评。) |
| **-logy** | 学科，研究 | biology (n.生物学), psychology (n.心理学), geology (n.地质学) |
| | | *She studies **biology** at university.* (她在大学学习生物学。) |
| | | *He's interested in **psychology**.* (他对心理学感兴趣。) |
| **-sis/-y** | 状态，过程，结果 | analysis (n.分析), therapy (n.治疗), diagnosis (n.诊断) |
| | | *The **analysis** is complete.* (分析完成了。) |
| | | *She's in **therapy**.* (她正在接受治疗。) |
| | | *What's the **diagnosis**?* (诊断结果是什么？) |
| **-ure/-ture** | 行为，状态，结果 | pressure (n.压力), structure (n.结构), nature (n.自然), culture (n.文化) |
| | | *I'm under a lot of **pressure**.* (我压力很大。) |
| | | *The **structure** is stable.* (这个结构很稳定。) |
| | | *It's human **nature**.* (这是人之常情。) |
| | | *We learned about Japanese **culture**.* (我们学习了日本文化。) |

#### 形容词后缀补充

| 后缀 | 含义 | 例词 |
|------|------|------|
| **-acious** | 多...的，有...性质的 | tenacious (adj.顽强的), loquacious (adj.健谈的), sagacious (adj.睿智的) |
| | | *He is **tenacious** in his efforts.* (他非常执着。) |
| **-aneous** | 属于...的，相关的 | spontaneous (adj.自发的), simultaneous (adj.同时的), miscellaneous (adj.混杂的) |
| | | *The applause was **spontaneous**.* (掌声是自发的。) |
| | | *The two events were **simultaneous**.* (这两件事同时发生。) |
| **-esque** | ...风格的，如...的 | picturesque (adj.如画的), grotesque (adj.怪诞的), statuesque (adj.雕像般的) |
| | | *The village is **picturesque**.* (这个村庄风景如画。) |
| **-ulent** | 充满...的 | fraudulent (adj.欺诈的), corpulent (adj.肥胖的), opulent (adj.富裕的) |
| | | *The deal was **fraudulent**.* (这笔交易是欺诈性的。) |
| **-ory** | ...性质的 | compulsory (adj.强制的), illusory (adj.虚幻的), sensory (adj.感觉的) |
| | | *Education is **compulsory**.* (教育是强制性的。) |

---

## 词根 (Roots)

词根是单词的核心部分，承载单词的基本含义。

### 希腊语词根的连接元音 **o**

**希腊语来源的词根**常带连接元音 **o**，用于连接词根与后缀或其他词根：

| 词根 | 原形 | + 连接元音 o | 例词 |
|------|------|-------------|------|
| **path** (感觉) | path- | patho- | path**ology** (病理学), sym**pathy** (同情) |
| **log** (说) | log- | logo- | log**ic** (逻辑), bio**logy** (生物学), dialo**gue** (对话) |
| **graph** (写) | graph- | grapho- | graph**ic** (图形的), photo**graphy** (摄影), pro**gram** (节目单) |
| **scope** (看) | scope- | scope- | scope (范围), tele**scope** (望远镜), micro**scope** (显微镜) |
| **phon** (声音) | phon- | phono- | phon**ic** (声音的), sym**phony** (交响乐) |
| **bio** (生命) | bio- | bio- | bio**logy** (生物学), bio**graphy** (传记) |
| **geo** (地球) | geo- | geo- | geo**logy** (地质学), geo**graphy** (地理学) |

**注意**：很多希腊语词根本身就带 **o**，如 **bio-**、**geo-**、**neo-** 等。

### 常见基础词根

| 词根 | 含义 | 例词 |
|------|------|------|
| **act** | 做，行动 | act (v.行动), action (n.行动), active (adj.积极的), react (v.反应) |
| | | *Let's **act** now.* (我们现在就行动吧。) |
| | | *The **action** was successful.* (这次行动很成功。) |
| | | *She is very **active**.* (她很活跃。) |
| | | *How did he **react**?* (他有什么反应？) |
| **aud** | 听 | audio (n.音频), audience (n.观众), audit (v.审计), audible (adj.可听见的) |
| | | *Check the **audio** settings.* (检查音频设置。) |
| | | *The **audience** applauded.* (观众鼓掌了。) |
| **bio** | 生命 | biology (n.生物学), biography (n.传记), biosphere (n.生物圈) |
| | | *She studies **biology**.* (她学习生物学。) |
| | | *He wrote a **biography** of Lincoln.* (他写了林肯的传记。) |
| **ced/ceed/cess** | 走，行进 | proceed (v.进行), succeed (v.成功), process (n.过程), access (v.访问) |
| | | *Please **proceed** to the gate.* (请前往登机口。) |
| | | *I hope you **succeed**.* (我希望你成功。) |
| | | *The **process** is simple.* (这个过程很简单。) |
| | | *I can't **access** the file.* (我无法访问这个文件。) |
| **cept** | 拿，取 | accept (v.接受), concept (n.概念), except (prep.除了), intercept (v.拦截) |
| | | *I **accept** your apology.* (我接受你的道歉。) |
| | | *The **concept** is interesting.* (这个概念很有趣。) |
| | | *Everyone went **except** me.* (除了我，大家都去了。) |
| **chron** | 时间 | chronic (adj.慢性的), chronicle (n.编年史), chronology (n.年代学) |
| | | *He has a **chronic** illness.* (他患有慢性病。) |
| **cid/cis** | 切，杀 | decide (v.决定), precise (adj.精确的), suicide (n.自杀), homicide (n.他杀) |
| | | *I can't **decide**.* (我无法决定。) |
| | | *Be more **precise**.* (更精确一点。) |
| **circ** | 圆，环 | circle (n.圆), circuit (n.电路), circulate (v.循环), circumference (n.圆周) |
| | | *Draw a **circle**.* (画一个圆。) |
| | | *The news **circulated** quickly.* (消息传得很快。) |
| **cred** | 相信 | credit (n.信用), credible (adj.可信的), incredible (adj.难以置信的), credential (n.凭证) |
| | | *Put it on my **credit** card.* (用我的信用卡支付。) |
| | | *That's **incredible**!* (太不可思议了！) |
| **dict** | 说 | dictate (v.口述), predict (v.预测), contradict (v.反驳), dictionary (n.词典) |
| | | *I **predict** rain tomorrow.* (我预测明天下雨。) |
| | | *Don't **contradict** me.* (不要反驳我。) |
| | | *Look it up in the **dictionary**.* (查字典。) |
| **duc/duct** | 引导 | conduct (v.引导), produce (v.生产), reduce (v.减少), educate (v.教育) |
| | | *They **conduct** experiments.* (他们做实验。) |
| | | *This factory **produces** cars.* (这家工厂生产汽车。) |
| | | *We need to **reduce** costs.* (我们需要降低成本。) |
| **fac/fact/fect** | 做，制造 | fact (n.事实), effect (n.效果), perfect (adj.完美的), manufacture (v.制造) |
| | | *That's a **fact**.* (那是事实。) |
| | | *What's the **effect**?* (效果是什么？) |
| | | *Nobody is **perfect**.* (没有人是完美的。) |
| **fer** | 携带，运送 | transfer (v.转移), refer (v.参考), prefer (v.更喜欢), conference (n.会议) |
| | | *I need to **transfer** money.* (我需要转账。) |
| | | *You can **refer** to the manual.* (你可以参考手册。) |
| | | *I **prefer** tea to coffee.* (比起咖啡我更喜欢茶。) |
| **fin** | 结束，界限 | final (adj.最终的), finish (v.完成), finite (adj.有限的), define (v.定义) |
| | | *This is my **final** answer.* (这是我的最终答案。) |
| | | *I **finished** my homework.* (我完成了作业。) |
| | | *How do you **define** success?* (你如何定义成功？) |
| **form** | 形状 | form (n.形式), format (n.格式), transform (v.转变), uniform (n.制服) |
| | | *Fill out this **form**.* (填写这张表格。) |
| | | *What's the file **format**?* (文件格式是什么？) |
| | | *The caterpillar **transformed** into a butterfly.* (毛毛虫变成了蝴蝶。) |
| **gen** | 产生，出生 | generate (v.产生), genesis (n.起源), genetic (adj.基因的), generous (adj.慷慨的) |
| | | *The solar panels **generate** electricity.* (太阳能板发电。) |
| | | *He is **generous** with his time.* (他很慷慨地花时间帮忙。) |
| **geo** | 地球，土地 | geography (n.地理), geology (n.地质学), geometry (n.几何), geocentric (adj.地心的) |
| | | *We studied **geography** in school.* (我们在学校学了地理。) |
| | | ***Geometry** is my favorite subject.* (几何是我最喜欢的科目。) |
| **grad/gress** | 步，走 | grade (n.等级), progress (n.进步), aggressive (adj.侵略性的), graduate (v.毕业) |
| | | *What **grade** are you in?* (你上几年级？) |
| | | *You're making **progress**.* (你在进步。) |
| | | *She will **graduate** next year.* (她明年毕业。) |
| **graph/gram** | 写，画 | graph (n.图表), program (n.程序), photograph (n.照片), diagram (n.图表) |
| | | *Look at this **graph**.* (看这个图表。) |
| | | *Show me the **program**.* (给我看看节目单。) |
| | | *Take a **photograph**.* (拍张照片。) |

> **graph/gram 的变体形式**：
> - **graph-**：词根原形，如 **graph**ic (图形的), **graph**ite (石墨), **graph**ology (笔迹学)
> - **-graphy**：连接元音 o + 词根，表示"书写/记录/学科"，如 photo**graphy** (摄影术), bio**graphy** (传记), geo**graphy** (地理学)
> - **-gram**：连接元音 o + 词根，表示"写的东西/记录"，如 pro**gram** (节目单), dia**gram** (图表), tele**gram** (电报)

| 词根 | 含义 | 例词 |
|------|------|------|
| **hab/hib** | 有，持有 | habit (n.习惯), exhibit (v.展览), inhibit (v.抑制), habitual (adj.习惯的) |
| | | *Smoking is a bad **habit**.* (吸烟是个坏习惯。) |
| | | *The museum will **exhibit** the paintings.* (博物馆将展出这些画作。) |
| **ject** | 投，掷 | project (n.项目), reject (v.拒绝), inject (v.注射), subject (n.主题) |
| | | *We started a new **project**.* (我们开始了一个新项目。) |
| | | *They **rejected** our proposal.* (他们拒绝了我们的提议。) |
| | | *What's the **subject**?* (主题是什么？) |
| **jud/judic** | 判断 | judge (n.法官), judgment (n.判断), judicial (adj.司法的), prejudice (n.偏见) |
| | | *The **judge** made a decision.* (法官做出了裁决。) |
| | | *Use your own **judgment**.* (用你自己的判断。) |
| **jung/junct** | 连接 | junction (n.连接点), conjunction (n.连词), adjunct (n. adjunct), injunction (n.禁令) |
| | | *Turn right at the **junction**.* (在路口右转。) |
| **leg/lect** | 选择，读 | select (v.选择), collect (v.收集), elect (v.选举), lecture (n.讲座) |
| | | *Please **select** an option.* (请选择一个选项。) |
| | | *I **collect** stamps.* (我收集邮票。) |
| | | *They **elected** a new president.* (他们选举了一位新总统。) |
| | | *The **lecture** was interesting.* (讲座很有趣。) |
| **lev** | 举起，升起 | elevate (v.提升), leverage (n.杠杆), levitate (v.漂浮), relevant (adj.相关的) |
| | | *This is not **relevant**.* (这不相关。) |
| **log** | 说，研究 | logic (n.逻辑), biology (n.生物学), dialogue (n.对话), apology (n.道歉) |
| | | *That makes **logic** sense.* (那合乎逻辑。) |
| | | *We need to have a **dialogue**.* (我们需要对话。) |
| | | *He owed me an **apology**.* (他欠我一个道歉。) |
| **manu** | 手 | manual (adj.手动的), manufacture (v.制造), manuscript (n.手稿), manicure (n.美甲) |
| | | *Read the **manual** first.* (先读手册。) |
| | | *The product is **manu**factured locally.* (这个产品是本地制造的。) |
| **mar** | 海 | marine (adj.海洋的), maritime (adj.海事的), mariner (n.水手), submarine (n.潜艇) |
| | | *The **marine** life is diverse.* (海洋生物种类繁多。) |
| | | *The **submarine** dove deep.* (潜艇潜入深处。) |
| **memor** | 记忆 | memory (n.记忆), memorize (v.记住), commemorate (v.纪念), memorial (n.纪念碑) |
| | | *I have a bad **memory**.* (我记性不好。) |
| | | *I need to **memorize** this.* (我需要记住这个。) |
| **ment** | 心智 | mental (adj.精神的), mention (v.提及), comment (n.评论), dementia (n.痴呆) |
| | | *He has **mental** issues.* (他有精神问题。) |
| | | *Did he **mention** anything?* (他有提到什么吗？) |
| | | *Any **comments**?* (有什么评论吗？) |
| **migr** | 迁移 | migrate (v.迁移), immigrant (n.移民), emigrant (n.移居者), migration (n.迁徙) |
| | | *Birds **migrate** south in winter.* (鸟冬天迁徙到南方。) |
| | | *He is an **immigrant**.* (他是个移民。) |
| **min** | 小 | minor (adj.较小的), minute (n.分钟), diminish (v.减少), minimum (n.最小值) |
| | | *It's a **minor** issue.* (这是个小问题。) |
| | | *Wait a **minute**.* (等一下。) |
| | | *The **minimum** wage is $15.* (最低工资是 15 美元。) |
| **miss/mit** | 送，派 | mission (n.使命), admit (v.承认), submit (v.提交), transmit (v.传输) |
| | | *What's your **mission**?* (你的使命是什么？) |
| | | *I **admit** I made a mistake.* (我承认我犯了个错误。) |
| | | *Please **submit** your report.* (请提交你的报告。) |
| **mot/mob** | 动 | motion (n.运动), mobile (adj.移动的), promote (v.促进), emotion (n.情感) |
| | | *The **motion** was approved.* (动议通过了。) |
| | | *She is very **mobile**.* (她行动很方便。) |
| | | *He was **promoted** to manager.* (他被提升为经理了。) |
| | | *Don't show **emotion**.* (不要表露情感。) |
| **nom** | 名字，法则 | name (n.名字), nominal (adj.名义的), nomenclature (n.命名法), astronomy (n.天文学) |
| | | *What's your **name**?* (你叫什么名字？) |
| | | *She studies **astronomy**.* (她学习天文学。) |
| **nov** | 新 | novel (n.小说), innovate (v.创新), novice (n.新手), renovate (v.翻新) |
| | | *I'm reading a **novel**.* (我在读小说。) |
| | | *We need to **innovate**.* (我们需要创新。) |
| | | *They **renovated** the house.* (他们翻新了房子。) |
| **oper** | 工作 | operate (v.操作), operation (n.手术), cooperate (v.合作), operator (n.操作员) |
| | | *How do I **operate** this?* (我怎么操作这个？) |
| | | *The **operation** was successful.* (手术很成功。) |
| | | *Let's **cooperate**.* (让我们合作吧。) |
| **opt** | 选择，看 | option (n.选项), opt (v.选择), adopt (v.采用), optical (adj.光学的) |
| | | *What are my **options**?* (我有什么选择？) |
| | | *I **opt** for the second choice.* (我选择第二个选项。) |
| | | *They **adopted** a child.* (他们收养了一个孩子。) |
| **ord/ordin** | 秩序，顺序 | order (n.顺序), ordinary (adj.普通的), coordinate (v.协调), subordinate (adj.下级的) |
| | | *Put these in **order**.* (把这些按顺序排好。) |
| | | *It's nothing **ordinary**.* (这可不普通。) |
| **ori** | 升起，东方 | orient (v.定向), origin (n.起源), oriental (adj.东方的), orientation (n.方向) |
| | | *What's the **origin** of this tradition?* (这个传统的起源是什么？) |
| | | *We had an **orientation** session.* (我们参加了迎新会。) |
| **pac** | 和平 | peace (n.和平), pacify (v.安抚), pacific (adj.和平的), pacifist (n.和平主义者) |
| | | *We want **peace**.* (我们想要和平。) |
| | | *The **Pacific** Ocean is huge.* (太平洋很大。) |
| **part** | 部分 | part (n.部分), particle (n.粒子), participate (v.参与), depart (v.离开) |
| | | *This is only a **part** of it.* (这只是其中一部分。) |
| | | *Everyone can **participate**.* (每个人都可以参与。) |
| | | *The train **departs** at 9.* (火车 9 点出发。) |
| **path** | 感觉，疾病 | pathos (n.悲情), sympathy (n.同情), pathology (n.病理学), empathetic (adj.有同理心的) |
| | | *I feel **sympathy** for him.* (我为他感到同情。) |
| **pel/puls** | 推动 | propel (v.推进), repel (v.排斥), impulse (n.冲动), pulse (n.脉搏) |
| | | *I bought it on **impulse**.* (我一时冲动买了它。) |
| | | *Check your **pulse**.* (检查一下你的脉搏。) |
| **pend/pens** | 悬挂，花费 | depend (v.依赖), suspend (v.暂停), expense (n.费用), pension (n.养老金) |
| | | *It **depends** on the weather.* (这要看天气而定。) |
| | | *His account was **suspended**.* (他的账户被暂停了。) |
| | | *What's the **expense**?* (费用是多少？) |
| | | *He lives on a **pension**.* (他靠养老金生活。) |
| **phon** | 声音 | phone (n.电话), phonics (n.语音学), symphony (n.交响乐), telephone (n.电话) |
| | | *Answer the **phone**.* (接电话。) |
| | | *The **symphony** was beautiful.* (交响乐很美。) |
| **plic/ply** | 折叠 | apply (v.申请), imply (v.暗示), complex (adj.复杂的), multiply (v.乘) |
| | | *I want to **apply** for this job.* (我想申请这份工作。) |
| | | *What are you **imply**ing?* (你在暗示什么？) |
| | | *It's too **complex**.* (这太复杂了。) |
| | | *Two **multiply** by three is six.* (二乘以三等于六。) |
| **pon/pos** | 放置 | position (n.位置), compose (v.作曲), propose (v.提议), deposit (v.存款) |
| | | *What's your **position**?* (你的位置在哪里？/ 你的立场是什么？) |
| | | *Mozart **composed** this piece.* (莫扎特创作了这首曲子。) |
| | | *I **propose** a toast.* (我提议干杯。) |
| | | *You need to **deposit** $100.* (你需要存入 100 美元。) |
| **port** | 携带，运送 | port (n.港口), transport (v.运输), import (v.进口), portable (adj.便携的) |
| | | *The ship arrived at the **port**.* (船抵达了港口。) |
| | | *Buses **transport** passengers.* (公交车运送乘客。) |
| | | *We **import** oil from abroad.* (我们从国外进口石油。) |
| | | *This laptop is **portable**.* (这台笔记本电脑很便携。) |
| **prim** | 第一 | prime (adj.主要的), primary (adj.初级的), primitive (adj.原始的), premier (adj.首要的) |
| | | *This is of **prime** importance.* (这是首要重要的。) |
| | | *My **primary** concern is safety.* (我主要关心的是安全。) |
| **pris/prehend** | 抓，握 | prison (n.监狱), comprehend (v.理解), apprehend (v.逮捕), surprise (n.惊喜) |
| | | *He was sent to **prison**.* (他被送进监狱了。) |
| | | *I can't **comprehend** this.* (我无法理解这个。) |
| | | *What a **surprise**!* (真是个惊喜！) |
| **prob/prov** | 测试，证明 | prove (v.证明), probe (v.探查), probable (adj.可能的), approve (v.批准) |
| | | *Can you **prove** it?* (你能证明吗？) |
| | | *It's **probable** to rain.* (很可能会下雨。) |
| | | *My boss **approved** the plan.* (老板批准了这个计划。) |
| **quer/quis** | 询问，寻求 | question (n.问题), inquire (v.询问), acquire (v.获得), require (v.要求) |
| | | *Do you have any **question**s?* (你有什么问题吗？) |
| | | *I need to **inquire** about the price.* (我需要询问价格。) |
| | | *She **acquired** the skills.* (她掌握了这些技能。) |
| | | *This **requires** attention.* (这需要关注。) |
| **rect** | 直，正 | rectify (v.纠正), correct (adj.正确的), direct (adj.直接的), rectangle (n.矩形) |
| | | *Let me **rectify** the mistake.* (让我纠正这个错误。) |
| | | *That's **correct**.* (那是对的。) |
| | | *Can you **direct** me to the station?* (你能告诉我去车站的路吗？) |
| **rupt** | 打破，破裂 | rupture (n.破裂), interrupt (v.打断), corrupt (adj.腐败的), erupt (v.爆发) |
| | | *Don't **interrupt** me.* (不要打断我。) |
| | | *The volcano **erupted**.* (火山爆发了。) |
| **sci** | 知道 | science (n.科学), conscious (adj.有意识的), omniscient (adj.全知的), prescient (adj.预知的) |
| | | *She studies **science**.* (她学习科学。) |
| | | *I'm not **conscious** of that.* (我没有意识到那个。) |
| **scrib/script** | 写 | scribe (n.抄写员), script (n.剧本), describe (v.描述), prescribe (v.开处方) |
| | | *Read the **script**.* (读剧本。) |
| | | *Can you **describe** it?* (你能描述一下吗？) |
| | | *The doctor **prescribed** medicine.* (医生开了药。) |
| **sec/sequ** | 跟随 | second (num.第二), sequence (n.序列), consequence (n.结果), subsequent (adj.随后的) |
| | | *This is the **second** time.* (这是第二次。) |
| | | *What's the **sequence**?* (顺序是什么？) |
| | | *Accept the **consequences**.* (接受后果吧。) |
| **sed/sess** | 坐 | sedentary (adj.久坐的), session (n.会议), possess (v.拥有), sediment (n.沉淀物) |
| | | *I have a **sedentary** job.* (我的工作需要久坐。) |
| | | *The **session** starts at 2pm.* (会议下午 2 点开始。) |
| | | *He **possesses** great skill.* (他拥有高超的技艺。) |
| **sens/sent** | 感觉 | sense (n.感觉), sentiment (n.情感), consent (v.同意), sensitive (adj.敏感的) |
| | | *I lost my **sense** of smell.* (我失去了嗅觉。) |
| | | *What's your **sentiment**?* (你的看法是什么？) |
| | | *I **consent** to this.* (我同意这个。) |
| | | *She is **sensitive**.* (她很敏感。) |
| **sign** | 标记，信号 | sign (n.标志), signal (n.信号), signature (n.签名), designate (v.指定) |
| | | *Look at the **sign**.* (看标志。) |
| | | *Wait for the **signal**.* (等信号。) |
| | | *Put your **signature** here.* (在这里签名。) |
| **simil/simul** | 相似，同时 | similar (adj.相似的), simulate (v.模拟), assemble (v.集合), simultaneous (adj.同时的) |
| | | *Your case is **similar**.* (你的情况类似。) |
| | | *Let's **assemble** here.* (让我们在这里集合。) |
| **sist/stat** | 站立，存在 | exist (v.存在), consist (v.组成), persist (v.坚持), obstacle (n.障碍) |
| | | *Do ghosts **exist**?* (鬼魂存在吗？) |
| | | *The team **consists** of five members.* (团队由五名成员组成。) |
| | | *If problems **persist**, call me.* (如果问题持续，打电话给我。) |
| **soci** | 同伴，社会 | social (adj.社会的), society (n.社会), associate (v.联想), sociable (adj.好交际的) |
| | | *She is very **social**.* (她很善于社交。) |
| | | *He is **sociable**.* (他很合群。) |
| **solv/solut** | 解开，解决 | solve (v.解决), solution (n.解决方案), resolve (v.决心), dissolve (v.溶解) |
| | | *Can you **solve** this problem?* (你能解决这个问题吗？) |
| | | *What's the **solution**?* (解决方案是什么？) |
| | | *I **resolve** to do better.* (我决心做得更好。) |
| **spect/spic** | 看 | inspect (v.检查), respect (v.尊重), suspect (v.怀疑), perspective (n.视角) |
| | | *Please **inspect** the goods.* (请检查货物。) |
| | | *I **respect** your opinion.* (我尊重你的意见。) |
| | | *I **suspect** something is wrong.* (我怀疑有问题。) |
| **spir** | 呼吸 | spirit (n.精神), inspire (v.鼓舞), expire (v.到期), conspire (v.密谋) |
| | | *Keep your **spirit** up.* (保持精神振奋。) |
| | | *You **inspire** me.* (你鼓舞了我。) |
| **struct** | 建造 | structure (n.结构), construct (v.建造), instruct (v.指导), destruct (v.破坏) |
| | | *The **structure** is solid.* (这个结构很坚固。) |
| | | *They **constructed** a bridge.* (他们建造了一座桥。) |
| | | *Follow the **instruct**ions.* (按照说明操作。) |
| **tang/tact** | 接触 | tangible (adj.有形的), contact (n.联系), intact (adj.完整的), tangent (n.切线) |
| | | *Keep in **contact** with me.* (和我保持联系。) |
| | | *The package is **intact**.* (包裹完好无损。) |
| **tect** | 覆盖，保护 | protect (v.保护), detect (v.发现), architecture (n.建筑) |
| | | *Wear a mask to **protect** yourself.* (戴口罩保护自己。) |
| | | *Did you **detect** any problem?* (你发现什么问题了吗？) |
| **tele** | 远 | telephone (n.电话), telescope (n.望远镜), television (n.电视), telepathy (n.心灵感应) |
| | | *Answer the **telephone**.* (接电话。) |
| | | *Turn on the **television**.* (打开电视。) |
| **tempor** | 时间 | temporal (adj.暂时的), temporary (adj.临时的), contemporary (adj.当代的) |
| | | *This is **temporary**.* (这是暂时的。) |
| **tend/tens/tent** | 伸展 | tend (v.趋向), extend (v.扩展), tension (n.紧张), intention (n.意图) |
| | | *Prices **tend** to rise.* (价格往往会上涨。) |
| | | *Can you **extend** the deadline?* (你能延长截止日期吗？) |
| | | *What's your **intention**?* (你的意图是什么？) |
| **terr** | 土地，陆地 | terra (n.陆地), territory (n.领土), terrain (n.地形), terrestrial (adj.陆地的) |
| | | *This is our **territory**.* (这是我们的领地。) |
| **text** | 编织 | text (n.文本), textile (n.纺织品), context (n.上下文), texture (n.质地) |
| | | *Read the **text**.* (阅读课文。) |
| | | *Look at the **context**.* (看看上下文。) |
| **therm** | 热 | thermal (adj.热的), thermometer (n.温度计), thermostat (n.恒温器), thermos (n.保温瓶) |
| | | *Use a **thermometer** to check.* (用温度计检查一下。) |
| **tract** | 拉，拖 | tract (n.道), attract (v.吸引), contract (n.合同), distract (v.分心) |
| | | *It **attract**s attention.* (它引起注意。) |
| | | *Sign the **contract**.* (签合同。) |
| | | *Don't **distract** me.* (不要让我分心。) |
| **tribut** | 给予 | tribute (n.贡品), contribute (v.贡献), distribute (v.分配), attribute (v.归因) |
| | | *Pay **tribute** to him.* (向他致敬。) |
| | | *Everyone should **contribute**.* (每个人都应该贡献。) |
| | | *How do you **distribute** the work?* (你如何分配工作？) |
| **turb** | 搅乱 | turbid (adj.浑浊的), disturb (v.打扰), turbulent (adj.湍流的), turbulence (n.动荡) |
| | | *Don't **disturb** me.* (不要打扰我。) |
| **vac/van** | 空 | vacant (adj.空缺的), vanish (v.消失), vanity (n.虚荣), vacuum (n.真空) |
| | | *Is the room **vacant**?* (房间空着吗？) |
| | | *He **vanished** suddenly.* (他突然消失了。) |
| **val** | 强壮，价值 | value (n.价值), valid (adj.有效的), evaluate (v.评估), prevail (v.盛行) |
| | | *What's the **value**?* (价值是多少？) |
| | | *Is this ticket **valid**?* (这张票有效吗？) |
| **vari** | 变化 | vary (v.变化), variable (adj.可变的), variety (n.多样性) |
| | | *Prices **vary** by season.* (价格随季节变化。) |
| | | *There is a **variety** of options.* (有多种选择。) |
| **ven/vent** | 来 | venture (n.冒险), convene (v.召集), prevent (v.预防), adventure (n.冒险) |
| | | *It's a business **venture**.* (这是一次商业冒险。) |
| | | *Let's go on an **adventure**.* (我们去冒险吧。) |
| | | *Can we **prevent** this?* (我们能阻止这个吗？) |
| **verb** | 词，字 | verbal (adj.口头的), verb (n.动词), proverb (n.谚语), verbiage (n.冗词) |
| | | *What's a **verb**?* (什么是动词？) |
| **ver** | 真实 | verify (v.核实), verdict (n.裁决), veritable (adj.真正的), veracity (n.诚实) |
| | | *Please **verify** your email.* (请验证你的邮箱。) |
| **vert/vers** | 转 | convert (v.转换), reverse (v.逆转), divert (v.转移), versatile (adj.多才多艺的) |
| | | *Can we **convert** this?* (我们能转换这个吗？) |
| | | *Put it in **reverse**.* (把它倒过来。) |
| **vid/vis** | 看 | video (n.视频), vision (n.视力), visible (adj.可见的), provide (v.提供) |
| | | *Watch this **video**.* (看这个视频。) |
| | | *Is it **visible**?* (看得见吗？) |
| | | *We **provide** service.* (我们提供服务。) |
| **vit/viv** | 生命 | vital (adj.至关重要的), vivid (adj.生动的), survive (v.幸存), revive (v.复苏) |
| | | *This is **vital**.* (这至关重要。) |
| | | *She had a **vivid** dream.* (她做了一个生动的梦。) |
| | | *He **survived** the accident.* (他在事故中幸存下来。) |
| **voc/vok** | 声音，呼叫 | voice (n.声音), vocal (adj.嗓音的), evoke (v.唤起), provoke (v.挑衅) |
| | | *Use your **voice**.* (用你的声音。) |
| | | *She is **vocal** about it.* (她直言不讳。) |
| **vol** | 意志，意愿 | will (v.将), voluntary (adj.自愿的), volition (n.意志), volunteer (n.志愿者) |
| | | *I **will** do it.* (我会做的。) |
| | | *He is a **volunteer**.* (他是志愿者。) |
| **volv/volut** | 滚动，转动 | revolve (v.旋转), evolve (v.进化), involve (v.涉及), revolution (n.革命) |
| | | *The earth **revolves** around the sun.* (地球绕着太阳转。) |
| | | *Species **evolve** over time.* (物种随时间进化。) |
| | | *Don't **involve** me.* (不要把我卷进去。) |
| **rect** | 直，正 | rectify (v.纠正), correct (adj.正确的), direct (adj.直接的), rectangle (n.矩形) |
| | | *Let me **rectify** the error.* (让我纠正这个错误。) |
| | | *Your answer is **correct**.* (你的答案是正确的。) |
| | | *Go **direct** to the office.* (直接去办公室。) |
| | | *Draw a **rectangle**.* (画一个矩形。) |
| **rog** | 问，求 | interrogate (v.审问), arrogant (adj.傲慢的), derogatory (adj.贬低的), surrogate (n.代理人) |
| | | *The police **interrogated** the suspect.* (警察审问了嫌疑人。) |
| | | *Don't be so **arrogant**.* (别这么傲慢。) |
| **rupt** | 打破，破裂 | rupture (n.破裂), interrupt (v.打断), corrupt (adj.腐败的), erupt (v.爆发) |
| | | *Don't **interrupt** me when I'm speaking.* (我说话时不要打断我。) |
| | | *The government is **corrupt**.* (政府是腐败的。) |
| | | *The volcano may **erupt**.* (火山可能会爆发。) |
| **sci** | 知道 | science (n.科学), conscious (adj.有意识的), omniscient (adj.全知的), prescient (adj.预知的) |
| | | *He studies **science**.* (他学习科学。) |
| | | *I'm not **conscious** of any problem.* (我没有意识到有什么问题。) |
| **scrib/script** | 写 | scribe (n.抄写员), script (n.剧本), describe (v.描述), prescribe (v.开处方) |
| | | *Follow the **script**.* (按照剧本。) |
| | | *Can you **describe** what happened?* (你能描述一下发生了什么吗？) |
| | | *The doctor **prescribed** some medicine.* (医生开了一些药。) |
| **sec/sequ** | 跟随 | second (num.第二), sequence (n.序列), consequence (n.结果), subsequent (adj.随后的) |
| | | *This is my **second** attempt.* (这是我第二次尝试。) |
| | | *What's the **sequence** of events?* (事件的顺序是什么？) |
| | | *Think about the **consequences**.* (想想后果。) |
| **sed/sess** | 坐 | sedentary (adj.久坐的), session (n.会议), possess (v.拥有), sediment (n.沉淀物) |
| | | *Most office jobs are **sedentary**.* (大多数办公室工作都需要久坐。) |
| | | *The training **session** starts at 9.* (培训课程 9 点开始。) |
| | | *He **possesses** great knowledge.* (他拥有丰富的知识。) |
| **sens/sent** | 感觉 | sense (n.感觉), sentiment (n.情感), consent (v.同意), sensitive (adj.敏感的) |
| | | *I lost my **sense** of taste.* (我失去了味觉。) |
| | | *What's your **sentiment** on this?* (你对此有什么看法？) |
| | | *I **consent** to the proposal.* (我同意这个提议。) |
| | | *She is very **sensitive**.* (她很敏感。) |
| **sign** | 标记，信号 | sign (n.标志), signal (n.信号), signature (n.签名), designate (v.指定) |
| | | *Look at the traffic **sign**.* (看交通标志。) |
| | | *Wait for my **signal**.* (等我的信号。) |
| | | *Add your **signature** at the bottom.* (在底部加上你的签名。) |
| **simil/simul** | 相似，同时 | similar (adj.相似的), simulate (v.模拟), assemble (v.集合), simultaneous (adj.同时的) |
| | | *Your situation is **similar** to mine.* (你的情况和我的相似。) |
| | | *The computer can **simulate** reality.* (电脑可以模拟现实。) |
| | | *Please **assemble** in the hall.* (请在大厅集合。) |
| | | *The two explosions were **simultaneous**.* (两次爆炸是同时发生的。) |
| **sist/stat** | 站立，存在 | exist (v.存在), consist (v.组成), persist (v.坚持), obstacle (n.障碍) |
| | | *Does life **exist** on Mars?* (火星上有生命存在吗？) |
| | | *The team **consists** of 10 people.* (团队由 10 人组成。) |
| | | *If symptoms **persist**, see a doctor.* (如果症状持续，请就医。) |
| | | *We overcame many **obstacles**.* (我们克服了许多障碍。) |
| **soci** | 同伴，社会 | social (adj.社会的), society (n.社会), associate (v.联想), sociable (adj.好交际的) |
| | | *She is very **social**.* (她很善于社交。) |
| | | *We live in a complex **society**.* (我们生活在一个复杂的社会。) |
| | | *He is easy to **associate** with.* (他很容易相处。) |
| **sol** | 太阳，单独 | solar (adj.太阳的), solitary (adj.孤独的), solo (n.独奏), consolidate (v.巩固) |
| | | *We installed **solar** panels.* (我们安装了太阳能电池板。) |
| | | *He lives a **solitary** life.* (他过着独居生活。) |
| | | *She performed a piano **solo**.* (她表演了钢琴独奏。) |
| **solv/solut** | 解开，解决 | solve (v.解决), solution (n.解决方案), resolve (v.决心), dissolve (v.溶解) |
| | | *Can you **solve** this puzzle?* (你能解开这个谜题吗？) |
| | | *We need a quick **solution**.* (我们需要一个快速的解决方案。) |
| | | *I **resolve** to work harder.* (我决心更加努力工作。) |
| **son** | 声音 | sonar (n.声纳), sonic (adj.音速的), consonant (n.辅音), dissonant (adj.不和谐的) |
| | | *The ship uses **sonar** to navigate.* (船用声纳导航。) |
| | | *B is a **consonant**.* (B 是辅音。) |
| **spect/spic** | 看 | inspect (v.检查), respect (v.尊重), suspect (v.怀疑), perspective (n.视角) |
| | | *Please **inspect** the product carefully.* (请仔细检查产品。) |
| | | *I **respect** your decision.* (我尊重你的决定。) |
| | | *I **suspect** he is lying.* (我怀疑他在撒谎。) |
| | | *From my **perspective**, it's wrong.* (从我的角度来看，这是错的。) |
| **spher** | 球，圈 | sphere (n.球体), atmosphere (n.大气), hemisphere (n.半球) |
| | | *The earth is a **sphere**.* (地球是一个球体。) |
| | | *The **atmosphere** is getting polluted.* (大气正在被污染。) |
| **spir** | 呼吸 | spirit (n.精神), inspire (v.鼓舞), expire (v.到期), conspire (v.密谋) |
| | | *Keep your **spirit** up.* (保持精神振奋。) |
| | | *You **inspire** me to do better.* (你激励我做得更好。) |
| | | *My passport **expires** next month.* (我的护照下个月到期。) |
| **struct** | 建造 | structure (n.结构), construct (v.建造), instruct (v.指导), destruct (v.破坏) |
| | | *The **structure** is stable.* (这个结构很稳定。) |
| | | *They **constructed** a new building.* (他们建造了一栋新楼。) |
| | | *Follow the **instruct**ions carefully.* (仔细阅读说明。) |
| **sum/sumpt** | 拿，取 | assume (v.假设), consume (v.消耗), presume (v.推测), consumption (n.消费) |
| | | *I **assume** you're right.* (我假设你是对的。) |
| | | *This **consumes** a lot of energy.* (这消耗很多能量。) |
| | | *I **presume** so.* (我推测是这样。) |
| **tang/tact** | 接触 | tangible (adj.有形的), contact (n.联系), intact (adj.完整的), tangent (n.切线) |
| | | *We need **tangible** results.* (我们需要有形的结果。) |
| | | *Keep in **contact** with us.* (和我们保持联系。) |
| | | *The box arrived **intact**.* (箱子完好无损地送达了。) |
| **tect** | 覆盖，保护 | protect (v.保护), detect (v.发现), architecture (n.建筑) |
| | | *Wear sunscreen to **protect** your skin.* (涂防晒霜保护你的皮肤。) |
| | | *Did you **detect** any error?* (你发现什么错误了吗？) |
| **tele** | 远 | telephone (n.电话), telescope (n.望远镜), television (n.电视), telepathy (n.心灵感应) |
| | | *Pick up the **telephone**.* (拿起电话。) |
| | | *Turn off the **television**.* (关掉电视。) |
| **tempor** | 时间 | temporal (adj.暂时的), temporary (adj.临时的), contemporary (adj.当代的) |
| | | *This is just **temporary**.* (这只是暂时的。) |
| | | *It's a **contemporary** art exhibition.* (这是一个当代艺术展。) |
| **tend/tens/tent** | 伸展 | tend (v.趋向), extend (v.扩展), tension (n.紧张), intention (n.意图) |
| | | *Prices **tend** to go up.* (价格往往会上涨。) |
| | | *Can you **extend** the deadline?* (你能延长截止日期吗？) |
| | | *There is a lot of **tension** here.* (这里气氛很紧张。) |
| | | *What's your **intention**?* (你的意图是什么？) |
| **terr** | 土地，陆地 | terra (n.陆地), territory (n.领土), terrain (n.地形), terrestrial (adj.陆地的) |
| | | *This is our **territory**.* (这是我们的领地。) |
| | | *The **terrain** is rough.* (地形崎岖。) |
| **text** | 编织 | text (n.文本), textile (n.纺织品), context (n.上下文), texture (n.质地) |
| | | *Read the **text** carefully.* (仔细阅读课文。) |
| | | *You need to understand the **context**.* (你需要理解上下文。) |
| | | *The **texture** is smooth.* (质地很光滑。) |
| **therm** | 热 | thermal (adj.热的), thermometer (n.温度计), thermostat (n.恒温器), thermos (n.保温瓶) |
| | | *Check your temperature with a **thermometer**.* (用温度计测量你的体温。) |
| **tim** | 害怕 | timid (adj.胆小的), timorous (adj.胆怯的), intimidate (v.恐吓), timidity (n.胆怯) |
| | | *He is too **timid** to speak up.* (他太胆小了，不敢说出来。) |
| | | *Don't try to **intimidate** me.* (不要试图恐吓我。) |
| **tract** | 拉，拖 | tract (n.道), attract (v.吸引), contract (n.合同), distract (v.分心) |
| | | *The show **attracted** a large audience.* (这个表演吸引了大量观众。) |
| | | *Sign the **contract** here.* (在这里签合同。) |
| | | *Don't **distract** the driver.* (不要分散司机的注意力。) |
| **tribut** | 给予 | tribute (n.贡品), contribute (v.贡献), distribute (v.分配), attribute (v.归因) |
| | | *Pay **tribute** to the hero.* (向英雄致敬。) |
| | | *Everyone should **contribute** something.* (每个人都应该贡献一些东西。) |
| | | *Please **distribute** the handouts.* (请分发讲义。) |
| | | *She **attributes** her success to hard work.* (她把自己的成功归因于努力工作。) |
| **turb** | 搅乱 | turbid (adj.浑浊的), disturb (v.打扰), turbulent (adj.湍流的), turbulence (n.动荡) |
| | | *Don't **disturb** him while he's working.* (他工作时不要打扰他。) |
| | | *We experienced some **turbulence** on the flight.* (我们在飞行中遇到了一些颠簸。) |
| **umbr** | 阴影 | umbrella (n.雨伞), umbrage (n.不快), penumbra (n.半影), somber (adj.阴沉的) |
| | | *Take an **umbrella**, it's raining.* (带把伞，下雨了。) |
| **un** | 一，统一 | union (n.联盟), unite (v.团结), unique (adj.独特的), uniform (n.制服) |
| | | *The **union** represents the workers.* (工会代表工人。) |
| | | *We must **unite**.* (我们必须团结。) |
| | | *This species is **unique**.* (这个物种是独特的。) |
| | | *Students wear **uniform**.* (学生穿校服。) |
| **urb** | 城市 | urban (adj.城市的), suburb (n.郊区), urbane (adj.文雅的), suburban (adj.郊区的) |
| | | *He lives in an **urban** area.* (他住在市区。) |
| | | *They moved to the **suburbs**.* (他们搬到了郊区。) |
| **us/ut** | 使用 | use (v.使用), utility (n.效用), utilize (v.利用), usual (adj.通常的) |
| | | *Can I **use** your phone?* (我可以用你的电话吗？) |
| | | *We need to **utilize** our resources.* (我们需要利用我们的资源。) |
| | | *It's my **usual** routine.* (这是我的日常惯例。) |
| **vac/van** | 空 | vacant (adj.空缺的), vanish (v.消失), vanity (n.虚荣), vacuum (n.真空) |
| | | *Is this seat **vacant**?* (这个座位空着吗？) |
| | | *He **vanished** without a trace.* (他消失得无影无踪。) |
| | | *She's full of **vanity**.* (她很虚荣。) |
| **vad/vas** | 走，进 | invade (v.入侵), evade (v.逃避), pervasive (adj.普遍的), invasion (n.入侵) |
| | | *The army **invaded** the country.* (军队入侵了这个国家。) |
| | | *He tried to **evade** the question.* (他试图回避这个问题。) |
| **val** | 强壮，价值 | value (n.价值), valid (adj.有效的), evaluate (v.评估), prevail (v.盛行) |
| | | *What's the **value** of this?* (这个的价值是多少？) |
| | | *Is your passport **valid**?* (你的护照有效吗？) |
| | | *We need to **evaluate** the results.* (我们需要评估结果。) |
| **vari** | 变化 | vary (v.变化), variable (adj.可变的), variety (n.多样性) |
| | | *Prices **vary** depending on the season.* (价格随季节变化。) |
| | | *There is a **variety** of choices.* (有多种选择。) |
| **ven/vent** | 来 | venture (n.冒险), convene (v.召集), prevent (v.预防), adventure (n.冒险) |
| | | *It's a risky **venture**.* (这是一次冒险的尝试。) |
| | | *We can **prevent** accidents.* (我们可以预防事故。) |
| | | *Life is an **adventure**.* (生活是一场冒险。) |
| **verb** | 词，字 | verbal (adj.口头的), verb (n.动词), proverb (n.谚语), verbiage (n.冗词) |
| | | *Give **verbal** instructions.* (给出口头指示。) |
| | | *Find the **verb** in this sentence.* (找出这句话中的动词。) |
| **ver** | 真实 | verify (v.核实), verdict (n.裁决), veritable (adj.真正的), veracity (n.诚实) |
| | | *Please **verify** your identity.* (请核实你的身份。) |
| | | *The jury reached a **verdict**.* (陪审团做出了裁决。) |
| **vert/vers** | 转 | convert (v.转换), reverse (v.逆转), divert (v.转移), versatile (adj.多才多艺的) |
| | | *We need to **convert** to a new system.* (我们需要转换到新系统。) |
| | | *Put the car in **reverse**.* (把车挂倒挡。) |
| | | *She is very **versatile**.* (她多才多艺。) |
| **vest** | 衣服，投资 | vest (n.背心), invest (v.投资), divest (v.剥夺) |
| | | *He wore a bulletproof **vest**.* (他穿了防弹背心。) |
| | | *I want to **invest** in stocks.* (我想投资股票。) |
| **vid/vis** | 看 | video (n.视频), vision (n.视力), visible (adj.可见的), provide (v.提供) |
| | | *Watch this **video**.* (看这个视频。) |
| | | *My **vision** is blurry.* (我的视力模糊。) |
| | | *Is the star **visible** tonight?* (今晚能看到那颗星星吗？) |
| | | *We **provide** free shipping.* (我们提供免费送货。) |
| **vit/viv** | 生命 | vital (adj.至关重要的), vivid (adj.生动的), survive (v.幸存), revive (v.复苏) |
| | | *Water is **vital** for life.* (水对生命至关重要。) |
| | | *She had a **vivid** imagination.* (她有生动的想象力。) |
| | | *Few **survived** the earthquake.* (很少有人在地震中幸存。) |
| **voc/vok** | 声音，呼叫 | voice (n.声音), vocal (adj.嗓音的), evoke (v.唤起), provoke (v.挑衅) |
| | | *Raise your **voice**.* (提高你的声音。) |
| | | *She is very **vocal** about her opinions.* (她直言不讳地表达自己的观点。) |
| | | *The music **evokes** memories.* (这首音乐唤起了回忆。) |
| | | *Don't **provoke** him.* (不要挑衅他。) |
| **vol** | 意志，意愿 | will (v.将), voluntary (adj.自愿的), volition (n.意志), volunteer (n.志愿者) |
| | | *I **will** help you.* (我会帮助你。) |
| | | *It's a **voluntary** organization.* (这是一个志愿组织。) |
| | | *He is a **volunteer**.* (他是一名志愿者。) |
| **volv/volut** | 滚动，转动 | revolve (v.旋转), evolve (v.进化), involve (v.涉及), revolution (n.革命) |
| | | *The earth **revolves** around the sun.* (地球绕太阳转。) |
| | | *Species **evolve** over millions of years.* (物种经过数百万年进化。) |
| | | *Don't **involve** me in this.* (不要把我卷进这件事。) |
| | | *The industrial **revolution** changed the world.* (工业革命改变了世界。) |
| **vor** | 吃 | voracious (adj.贪婪的), carnivore (n.食肉动物), herbivore (n.食草动物), devour (v.吞食) |
| | | *He has a **voracious** appetite.* (他胃口很大。) |
| | | *A lion is a **carnivore**.* (狮子是食肉动物。) |
| | | *A cow is an **herbivore**.* (牛是食草动物。) |
| | | *He **devoured** the book in one day.* (他一天就读完了这本书。) |

### 人体相关词根

| 词根 | 含义 | 例词 |
|------|------|------|
| **capit/cap/cep** | 头 | capital (n.首都), captain (n.队长), decapitate (v.斩首), cephalic (adj.头的) |
| | | *Beijing is the **capital** of China.* (北京是中国的首都。) |
| | | *The **captain** led the team.* (队长带领了团队。) |
| **cardi/cord** | 心 | cardiac (adj.心脏的), concord (n.和谐), discord (n.不和), cardiologist (n.心脏病专家) |
| | | *He has a **cardiac** condition.* (他有心脏问题。) |
| | | *They lived in **concord**.* (他们和睦相处。) |
| **corpor** | 身体 | corporation (n.公司), corporal (adj.身体的), incorporate (v.合并), corpulent (adj.肥胖的) |
| | | *He works for a large **corporation**.* (他在一家大公司工作。) |
| **derm/dermat** | 皮肤 | dermatology (n.皮肤科), epidermis (n.表皮), dermatitis (n.皮炎) |
| | | *She specializes in **dermatology**.* (她专攻皮肤科。) |
| **dent** | 牙齿 | dentist (n.牙医), dental (adj.牙齿的), denture (n.假牙), trident (n.三叉戟) |
| | | *I need to see a **dentist**.* (我需要看牙医。) |
| | | *Practice good **dental** hygiene.* (保持良好的口腔卫生。) |
| **gastr** | 胃 | gastric (adj.胃的), gastritis (n.胃炎), gastroenterology (n.胃肠病学) |
| | | *He has **gastric** problems.* (他有胃部问题。) |
| **lingu** | 舌头，语言 | linguistics (n.语言学), language (n.语言), bilingual (adj.双语的) |
| | | *She studies **linguistics**.* (她学习语言学。) |
| | | *How many **language**s do you speak?* (你会说几种语言？） |
| **neur/nerve** | 神经 | neural (adj.神经的), nervous (adj.紧张的), neuron (n.神经元), neuritis (n.神经炎) |
| | | *I'm feeling **nervous**.* (我感到紧张。) |
| | | *The brain has billions of **neurons**.* (大脑有数十亿个神经元。) |
| **ocul** | 眼睛 | ocular (adj.眼睛的), binocular (adj.双目的), oculist (n.眼科医生) |
| | | *Use **binocular** vision.* (使用双眼视觉。) |
| **ped/pod** | 脚 | pedal (n.踏板), tripod (n.三脚架), centipede (n.蜈蚣), podiatry (n.足病学) |
| | | *Press the brake **pedal**.* (踩下刹车踏板。) |
| | | *Use a **tripod** for the camera.* (用三脚架固定相机。) |
| **pulm** | 肺 | pulmonary (adj.肺的), pulmonologist (n.肺病专家) |
| | | *He has **pulmonary** disease.* (他患有肺病。) |
| **ren** | 肾 | renal (adj.肾脏的), reniform (adj.肾形的) |
| | | *She has **renal** failure.* (她有肾衰竭。) |
| **rhin** | 鼻 | rhinoceros (n.犀牛), rhinitis (n.鼻炎), rhinoplasty (n.隆鼻术) |
| | | *A **rhinoceros** has a horn.* (犀牛有角。) |
| **somat** | 身体 | somatic (adj.身体的), psychosomatic (adj.身心的), somatotype (n.体型) |
| | | *He has **somatic** symptoms.* (他有身体症状。) |
| **spin** | 脊柱 | spinal (adj.脊柱的), spine (n.脊柱), spinous (adj.多刺的) |
| | | *He suffered a **spinal** injury.* (他脊柱受伤了。) |
| | | *The book runs down your **spine**.* (这本书让你毛骨悚然。) |
| **thorac** | 胸 | thoracic (adj.胸部的), thorax (n.胸廓), thoracotomy (n.开胸术) |
| | | *He has **thoracic** pain.* (他胸部疼痛。) |
| **vas/vascul** | 血管 | vascular (adj.血管的), cardiovascular (adj.心血管的), vasculature (n.血管系统) |
| | | *Exercise improves **vascular** health.* (运动改善血管健康。) |
| | | ***Cardiovascular** disease is common.* (心血管疾病很常见。) |

### 自然元素词根

| 词根 | 含义 | 例词 |
|------|------|------|
| **aer** | 空气 | aerial (adj.空中的), aerate (v.通气), aerosol (n.气溶胶), aerodynamics (n.空气动力学) |
| | | *The **aerial** view was amazing.* (空中景色令人惊叹。) |
| **agri/agro** | 田地，农业 | agriculture (n.农业), agronomy (n.农学), agribusiness (n.农业综合企业) |
| | | *He works in **agriculture**.* (他从事农业工作。) |
| **aqu** | 水 | aquatic (adj.水生的), aquarium (n.水族馆), aqueduct (n.渡槽), aquifer (n.含水层) |
| | | *Fish are **aquatic** animals.* (鱼是水生动物。) |
| | | *We visited the **aquarium**.* (我们参观了水族馆。) |
| **arbor** | 树 | arbor (n.树), arboretum (n.植物园), arboreal (adj.树栖的) |
| | | *The **arboretum** has many trees.* (植物园有很多树。) |
| **astr/aster** | 星 | astronomy (n.天文学), asteroid (n.小行星), disaster (n.灾难), asterisk (n.星号) |
| | | *She studies **astronomy**.* (她学习天文学。) |
| | | *An **asteroid** hit the earth.* (小行星撞击了地球。) |
| | | *The earthquake was a **disaster**.* (地震是一场灾难。) |
| **botan** | 植物 | botany (n.植物学), botanical (adj.植物的), botanist (n.植物学家) |
| | | *He is a **botanist**.* (他是一位植物学家。) |
| **cult** | 耕种 | cultivate (v.培养), agriculture (n.农业), horticulture (n.园艺) |
| | | *She **cultivates** roses.* (她种植玫瑰。) |
| **cycl** | 圆，轮 | cycle (n.循环), bicycle (n.自行车), cyclone (n.气旋), encyclopedia (n.百科全书) |
| | | *The water **cycle** is important.* (水循环很重要。) |
| | | *I ride my **bicycle** to work.* (我骑自行车上班。) |
| | | *Look it up in the **encyclopedia**.* (在百科全书中查找。) |
| **flor** | 花 | floral (adj.花的), florist (n.花商), flora (n.植物群), florid (adj.华丽的) |
| | | *The dress has a **floral** pattern.* (这条裙子有花卉图案。) |
| | | *Buy flowers from the **florist**.* (从花店买花。) |
| **flu/flux** | 流动 | fluid (n.液体), flux (n.流动), influence (n.影响), affluent (adj.富裕的) |
| | | *Drink plenty of **fluid**s.* (多喝水。) |
| | | *He has a lot of **influence**.* (他很有影响力。) |
| | | *They live in an **affluent** neighborhood.* (他们住在富裕的社区。) |
| **foss** | 挖掘 | fossil (n.化石), fossorial (adj.掘土的) |
| | | *The **fossil** is millions of years old.* (这个化石有数百万年历史了。) |
| **fum** | 烟 | fume (n.烟), fumigate (v.熏蒸), perfume (n.香水) |
| | | *The exhaust **fumes** are toxic.* (废气有毒。) |
| | | *What **perfume** are you wearing?* (你喷了什么香水？） |
| **glaci** | 冰 | glacier (n.冰川), glacial (adj.冰河的), glaciate (v.使结冰) |
| | | *The **glacier** is melting.* (冰川正在融化。) |
| **hydr** | 水 | hydrant (n.消防栓), hydrate (v.水合), carbohydrate (n.碳水化合物) |
| | | *Call the fire department to open the **hydrant**.* (叫消防部门打开消防栓。) |
| | | *Stay **hydrated** during exercise.* (运动时保持水分。) |
| **ign** | 火 | ignite (v.点燃), ignition (n.点火), igneous (adj.火成的) |
| | | *The spark **ignited** the fuel.* (火花点燃了燃料。) |
| **insul** | 岛 | insulate (v.隔离), insulation (n.绝缘), island (n.岛) |
| | | *We live on an **island**.* (我们住在岛上。) |
| | | ***Insulate** the house to save energy.* (给房子隔热以节约能源。) |
| **lac/lact** | 奶 | lactate (v.分泌乳汁), lactose (n.乳糖), lactation (n.哺乳) |
| | | *I'm **lactose** intolerant.* (我乳糖不耐受。) |
| **laps** | 滑，倒 | lapse (n.失误), collapse (v.倒塌), relapse (v.复发) |
| | | *It was a memory **lapse**.* (那是记忆失误。) |
| | | *The building **collapsed**.* (建筑物倒塌了。) |
| **lat** | 边 | lateral (adj.侧面的), latitude (n.纬度), bilateral (adj.双边的) |
| | | *The **lateral** movement is limited.* (侧向移动受限。) |
| | | *What **latitude** are we at?* (我们在什么纬度？） |
| **lith** | 石 | lithograph (n.石版画), monolith (n.巨石), lithosphere (n.岩石圈) |
| | | *The **monolith** is ancient.* (这个巨石很古老。) |
| **luc/lum/lus** | 光 | lucid (adj.清晰的), luminous (adj.发光的), illustrate (v.说明), translucent (adj.半透明的) |
| | | *She gave a **lucid** explanation.* (她给出了清晰的解释。) |
| | | *The stars are **luminous**.* (星星会发光。) |
| | | *Can you **illustrate** this point?* (你能说明这一点吗？） |
| **mar** | 海 | marine (adj.海洋的), maritime (adj.海事的), mariner (n.水手) |
| | | ***Marine** life is diverse.* (海洋生物种类繁多。) |
| **materi** | 物质，材料 | material (n.材料), materialize (v.实现), immaterial (adj.不重要的) |
| | | *What **material** is this made of?* (这是什么材料做的？） |
| | | *His dream **materialized**.* (他的梦想实现了。) |
| **mech** | 机器 | mechanic (n.技工), mechanism (n.机制), mechanical (adj.机械的) |
| | | *The **mechanic** fixed my car.* (技工修好了我的车。) |
| | | *The **mechanism** is complex.* (这个机制很复杂。) |
| **melan** | 黑 | melanin (n.黑色素), melanoma (n.黑色素瘤), melancholy (n.忧郁) |
| | | ***Melanin** gives skin its color.* (黑色素赋予皮肤颜色。) |
| | | *He felt a sense of **melancholy**.* (他感到一阵忧郁。) |
| **mes** | 中 | mesoderm (n.中胚层), mesosphere (n.中间层), mesolithic (adj.中石器时代的) |
| | | *The **mesoderm** forms muscles.* (中胚层形成肌肉。) |
| **metall** | 金属 | metal (n.金属), metallic (adj.金属的), metallurgy (n.冶金学) |
| | | *Gold is a precious **metal**.* (金是贵金属。) |
| **meteor** | 天空，气象 | meteor (n.流星), meteorology (n.气象学), meteorite (n.陨石) |
| | | *I saw a **meteor** last night.* (我昨晚看到了一颗流星。) |
| | | *She studies **meteorology**.* (她学习气象学。) |
| **mineral** | 矿物 | mineral (n.矿物), mineralize (v.矿化), mineralogy (n.矿物学) |
| | | *This **mineral** is rare.* (这种矿物很稀有。) |
| **mont** | 山 | mount (v.登上), mountain (n.山), paramount (adj.至高无上的) |
| | | ***Mount** the horse.* (上马。） |
| | | *The **mountain** is high.* (这座山很高。) |
| | | *Safety is **paramount**.* (安全至上。) |
| **nebul** | 云，雾 | nebula (n.星云), nebulous (adj.模糊的) |
| | | *The **nebula** is beautiful.* (这个星云很美。) |
| | | *His ideas are **nebulous**.* (他的想法很模糊。) |
| **nect/nex** | 连接 | connect (v.连接), nexus (n.联系), annex (v.兼并) |
| | | *Can you **connect** me to the manager?* (你能帮我转接经理吗？） |
| | | *There is a **nexus** between the two.* (两者之间有联系。) |
| **nigr** | 黑 | negro (n.黑人), nigrescent (adj.变黑的), denigrate (v.诋毁) |
| | | *Don't **denigrate** his work.* (不要诋毁他的工作。) |
| **nucle** | 核 | nucleus (n.核), nuclear (adj.核的), nucleotide (n.核苷酸) |
| | | *The **nucleus** of an atom.* (原子的原子核。) |
| | | ***Nuclear** energy is powerful.* (核能很强大。) |
| **ole** | 油 | oil (n.油), oleaginous (adj.含油的), petroleum (n.石油) |
| | | *Cook with olive **oil**.* (用橄榄油烹饪。) |
| | | ***Petroleum** is a fossil fuel.* (石油是化石燃料。) |
| **petr/petro** | 石 | petroleum (n.石油), petrology (n.岩石学), petrous (adj.岩石般的) |
| | | ***Petrology** studies rocks.* (岩石学研究岩石。) |
| **phos/phosph** | 光 | phosphorus (n.磷), phosphate (n.磷酸盐), phosphorescent (adj.磷光的) |
| | | ***Phosphorus** glows in the dark.* (磷在黑暗中发光。) |
| **pisc** | 鱼 | piscivorous (adj.食鱼的), piscine (adj.鱼的), Pisces (n.双鱼座) |
| | | *Eagles are **piscivorous**.* (鹰是食鱼的。) |
| **plasm** | 形成物 | plasma (n.血浆), cytoplasm (n.细胞质), protoplasm (n.原生质) |
| | | *Blood **plasma** is yellow.* (血浆是黄色的。) |
| **plumb** | 铅 | plumb (v.探测), plumber (n.水管工), plumb line (n.铅垂线) |
| | | *Call a **plumber** to fix the leak.* (叫水管工来修漏水。) |
| **pluvi** | 雨 | pluvial (adj.雨期的), pluviometer (n.雨量计) |
| | | *The **pluvial** season is coming.* (雨季要来了。) |
| **pneum/pneumon** | 肺，呼吸 | pneumonia (n.肺炎), pneumonic (adj.肺炎的), pneumothorax (n.气胸) |
| | | *He died of **pneumonia**.* (他死于肺炎。) |
| **pyr/pyro** | 火 | pyre (n.火葬柴堆), pyrotechnics (n.烟火), pyromania (n.纵火癖) |
| | | *The **pyrotechnics** display was amazing.* (烟火表演很精彩。) |
| **quadr** | 四 | quadrangle (n.四边形), quadrant (n.象限), quadruped (n.四足动物) |
| | | *A **quadrangle** has four sides.* (四边形有四条边。) |
| **radi** | 射线，半径 | radio (n.收音机), radius (n.半径), radiant (adj.辐射的), irradiate (v.照射) |
| | | *Listen to the **radio**.* (听收音机。) |
| | | *What's the **radius**?* (半径是多少？） |
| | | *She looked **radiant**.* (她容光焕发。) |
| **riv** | 河 | river (n.河), rivulet (n.小溪), arrive (v.到达) |
| | | *The **river** is wide.* (这条河很宽。) |
| | | *When will you **arrive**?* (你什么时候到？） |
| **silv** | 森林 | silviculture (n.造林学), silvan (adj.森林的) |
| | | ***Silviculture** is important.* (造林学很重要。) |
| **sider** | 星 | sidereal (adj.恒星的), consider (v.考虑) |
| | | *Let me **consider** it.* (让我考虑一下。) |
| **solar** | 太阳 | solar (adj.太阳的), solstice (n.至日) |
| | | ***Solar** energy is renewable.* (太阳能是可再生的。) |
| | | *The **solstice** is in June.* (至日在六月。) |
| **spong** | 海绵 | sponge (n.海绵), spongy (adj.海绵状的), spongiform (adj.海绵状的) |
| | | *Use a **sponge** to clean.* (用海绵清洁。) |
| **stell** | 星 | stellar (adj.恒星的), constellation (n.星座), interstellar (adj.星际的) |
| | | *She gave a **stellar** performance.* (她表现出色。) |
| | | *What's your **constellation**?* (你是什么星座？） |
| **strat** | 层 | stratum (n.地层), stratify (v.分层), strategy (n.战略) |
| | | *There is a **stratum** of clouds.* (有一层云。) |
| | | *What's your **strategy**?* (你的策略是什么？） |
| **sulfur** | 硫 | sulfur (n.硫), sulfurate (v.硫化), sulfide (n.硫化物) |
| | | ***Sulfur** smells bad.* (硫闻起来很臭。) |
| **talass** | 海 | thalassic (adj.海的), thalassocracy (n.海权) |
| | | *The **thalassic** environment is unique.* (海洋环境很独特。) |
| **tellur** | 地球 | telluric (adj.地球的), tellurian (n.地球人) |
| | | ***Telluric** currents exist.* (地电流存在。) |
| **tempest** | 风暴 | tempest (n.暴风雨), tempestuous (adj.暴风雨的) |
| | | *A **tempest** is coming.* (暴风雨要来了。) |
| **therm** | 热 | thermal (adj.热的), thermometer (n.温度计), thermos (n.保温瓶) |
| | | *Use a **thermometer** to check.* (用温度计检查一下。) |
| **top** | 地方 | topic (n.主题), topology (n.拓扑学), utopia (n.乌托邦) |
| | | *What's the **topic**?* (主题是什么？） |
| | | *It's a **utopia**.* (那是个乌托邦。) |
| **und** | 波浪 | undulate (v.波动), abound (v.丰富), redundant (adj.多余的) |
| | | *The field **undulates**.* (田野起伏不平。) |
| | | *Fish **abound** in this lake.* (这个湖里鱼很多。) |
| | | *This information is **redundant**.* (这个信息是多余的。) |
| **urb** | 城市 | urban (adj.城市的), suburb (n.郊区), urbane (adj.文雅的) |
| | | *He lives in an **urban** area.* (他住在市区。) |
| | | *They moved to the **suburbs**.* (他们搬到了郊区。) |
| **vap** | 蒸汽 | vapor (n.蒸汽), evaporate (v.蒸发), vaporize (v.汽化) |
| | | *Water **vapor** is invisible.* (水蒸气是看不见的。) |
| | | *The water will **evaporate**.* (水会蒸发。） |
| **verd** | 绿 | verdant (adj.翠绿的), verdigris (n.铜绿) |
| | | *The **verdant** hills are beautiful.* (翠绿的山丘很美。) |
| **verm** | 虫 | vermin (n.害虫), vermicelli (n.细面条), vermiform (adj.蠕虫状的) |
| | | *Get rid of the **vermin**.* (除掉害虫。) |
| **vern** | 春 | vernal (adj.春天的), vernation (n.叶序) |
| | | *The **vernal** equinox is in March.* (春分在三月。） |
| **vi/via** | 路 | via (prep.通过), viable (adj.可行的), viaduct (n.高架桥), trivial (adj.琐碎的) |
| | | *Go **via** London.* (经伦敦去。） |
| | | *Is this **viable**?* (这可行吗？） |
| | | *Don't be **trivial**.* (不要琐碎。) |
| **vill** | 村庄 | village (n.村庄), villager (n.村民), villa (n.别墅) |
| | | *They live in a **village**.* (他们住在村庄里。) |
| | | *She has a **villa** in France.* (她在法国有栋别墅。) |
| **vin** | 酒 | vine (n.葡萄藤), vinegar (n.醋), vintage (n.年份酒) |
| | | *The **vine** is growing.* (葡萄藤正在生长。) |
| | | *Add some **vinegar**.* (加些醋。） |
| **vir** | 毒 | virus (n.病毒), viral (adj.病毒的), virulent (adj.剧毒的) |
| | | *The **virus** is spreading.* (病毒正在传播。) |
| | | *The video went **viral**.* (这个视频疯传了。) |
| **volc** | 火山 | volcano (n.火山), volcanic (adj.火山的), vulcanize (v.硫化) |
| | | *The **volcano** erupted.* (火山爆发了。) |
| **xylo** | 木 | xylophone (n.木琴), xylograph (n.木版画), xyloid (adj.木质的) |
| | | *Play the **xylophone**.* (弹奏木琴。） |
| **zoo/zo** | 动物 | zoo (n.动物园), zoology (n.动物学), zoologist (n.动物学家) |
| | | *We visited the **zoo**.* (我们参观了动物园。) |
| | | *He studies **zoology**.* (他学习动物学。) |

### 抽象概念词根

| 词根 | 含义 | 例词 |
|------|------|------|
| **agon** | 竞争 | agony (n.痛苦), antagonist (n.对手), protagonist (n.主角) |
| **alg** | 痛 | neuralgia (n.神经痛), nostalgia (n.怀旧), analgesic (n.止痛药) |
| **amat** | 爱 | amateur (n.业余爱好者), amatory (adj.爱的) |
| **anim** | 精神，生命 | animal (n.动物), animate (v.使有生气), unanimous (adj.一致的) |
| **ann/enn** | 年 | annual (adj.每年的), anniversary (n.周年纪念日), perennial (adj.永久的) |
| **anthrop** | 人 | anthropology (n.人类学), philanthropy (n.慈善), misanthrope (n.厌世者) |
| **apt** | 适合 | apt (adj.恰当的), adapt (v.适应), aptitude (n.能力) |
| **arch** | 统治 | monarch (n.君主), hierarchy (n.等级制度), anarchy (n.无政府状态) |
| **axi** | 价值 | axiom (n.公理), axiomatic (adj.不言自明的) |
| **bellic** | 战争 | bellicose (adj.好战的), rebel (n.反叛者), belligerent (adj.交战的) |
| **bene/bon** | 好 | benefit (n.利益), benevolent (adj.仁慈的), bonus (n.奖金) |
| **brev** | 短 | brief (adj.简短的), brevity (n.简洁), abbreviate (v.缩写) |
| **cad/cas** | 落下 | cadence (n.节奏), cascade (n.小瀑布), accidental (adj.意外的) |
| **caut** | 小心 | caution (n.谨慎), cautious (adj.小心的), precaution (n.预防措施) |
| **celer** | 快 | celerity (n.迅速), accelerate (v.加速) |
| **cert** | 确定 | certain (adj.确定的), certify (v.证明), certainty (n.确定性) |
| **cogn** | 知道 | cognize (v.认识), recognize (v.认出), cognition (n.认知) |
| **coher/cohes** | 粘着 | cohere (v.连贯), coherent (adj.连贯的), cohesion (n.凝聚力) |
| **crac/crat** | 统治 | democracy (n.民主), democrat (n.民主党人), autocrat (n.独裁者) |
| **culp** | 罪 | culpable (adj.有罪的), exculpate (v.开脱) |
| **cur/cours** | 跑 | current (adj.当前的), course (n.课程), cursor (n.光标), occur (v.发生) |
| **damn** | 伤害 | damn (v.诅咒), condemn (v.谴责), damnation (n.诅咒) |
| **debt** | 债 | debt (n.债务), debtor (n.债务人), indebted (adj.负债的) |
| **dign** | 值得 | dignify (v.使高贵), dignity (n.尊严), indignant (adj.愤慨的) |
| **dol** | 痛 | doleful (adj.悲哀的), condole (v.吊唁) |
| **domin** | 统治 | dominate (v.支配), dominant (adj.占优势的), dominion (n.领土) |
| **don** | 给 | donate (v.捐赠), donor (n.捐赠者), pardon (v.原谅) |
| **dorm** | 睡 | dormitory (n.宿舍), dormant (adj.休眠的) |
| **dub** | 怀疑 | dubious (adj.可疑的), dubiety (n.怀疑) |
| **dur** | 硬，持续 | durable (adj.耐用的), duration (n.持续时间), endure (v.忍受) |
| **dynam** | 力量 | dynamic (adj.动态的), dynamite (n.炸药), dynasty (n.王朝) |
| **equ** | 平等 | equal (adj.平等的), equity (n.公平), equator (n.赤道) |
| **err** | 错 | error (n.错误), errant (adj.错误的), aberrant (adj.异常的) |
| **eth** | 道德 | ethics (n.伦理), ethical (adj.道德的), unethical (adj.不道德的) |
| **fabl/fabul** | 说 | fable (n.寓言), fabulous (adj.极好的) |
| **facil** | 容易 | facile (adj.容易的), facilitate (v.促进), facility (n.设施) |
| **fall/fals** | 欺骗 | fallacy (n.谬论), false (adj.错误的), falsify (v.伪造) |
| **fam** | 名声 | fame (n.名声), famous (adj.著名的), infamous (adj.臭名昭著的) |
| **fasc** | 捆 | fascicle (n.小束), fascinate (v.迷住), fascia (n.筋膜) |
| **fat** | 命运 | fate (n.命运), fatal (adj.致命的), fatality (n.死亡) |
| **fatig** | 疲劳 | fatigue (n.疲劳), indefatigable (adj.不知疲倦的) |
| **feder** | 联盟 | federal (adj.联邦的), federation (n.联盟), confederate (n.同盟者) |
| **fel** | 快乐 | felicity (n.幸福), felicitate (v.祝贺) |
| **fend/fens** | 打击 | defend (v.辩护), offense (n.进攻), defense (n.防御) |
| **ferv** | 沸腾 | fervent (adj.热情的), fervid (adj.炽热的), fervor (n.热情) |
| **fess** | 说 | confess (v.承认), profession (n.职业), professor (n.教授) |
| **fidel** | 忠诚 | fidelity (n.忠诚), confide (v.信任) |
| **figur** | 形状 | figure (n.数字), figurative (adj.比喻的), configuration (n.配置) |
| **firm** | 坚固 | firm (adj.坚固的), confirm (v.确认), firmament (n.天空) |
| **flect/flex** | 弯曲 | reflect (v.反射), flexible (adj.灵活的), reflex (n.反射) |
| **flict** | 打击 | conflict (n.冲突), afflict (v.折磨), inflict (v.施加) |
| **forc/fort** | 强壮 | force (n.力量), fort (n.堡垒), fortify (v.加强) |
| **form** | 形状 | form (n.形式), formal (adj.正式的), transform (v.转变) |
| **frag/fract** | 打破 | fragment (n.碎片), fracture (n.骨折), fragile (adj.脆弱的) |
| **fratr** | 兄弟 | fraternity (n.兄弟会), fratricide (n.杀兄弟), fraternal (adj.兄弟的) |
| **fraud** | 欺骗 | fraud (n.欺诈), fraudulent (adj.欺诈的), defraud (v.欺骗) |
| **fug** | 逃跑 | fugitive (n.逃犯), refuge (n.避难所), centrifuge (n.离心机) |
| **fund/found** | 底，基础 | fund (n.基金), found (v.建立), foundation (n.基础) |
| **fus** | 倒，融化 | fuse (v.融合), fusion (n.融合), confuse (v.混淆) |
| **gam** | 婚姻 | gamete (n.配子), polygamy (n.一夫多妻), monogamy (n.一夫一妻) |
| **gel** | 冻 | gel (n.凝胶), gelatin (n.明胶), congeal (v.凝结) |
| **gener** | 种类 | general (adj.一般的), generate (v.产生), generous (adj.慷慨的) |
| **ger/gest** | 携带 | gesture (n.手势), suggest (v.建议), digest (v.消化) |
| **geront** | 老 | gerontology (n.老年学), geriatric (adj.老年的) |
| **glori** | 荣耀 | glory (n.荣耀), glorify (v.赞美), glorious (adj.光荣的) |
| **gnost** | 知道 | agnostic (n.不可知论者), diagnosis (n.诊断), prognosis (n.预后) |
| **govern** | 统治 | govern (v.统治), government (n.政府), governor (n.州长) |
| **grat** | 高兴 | grateful (adj.感激的), gratify (v.使高兴), gratitude (n.感激) |
| **grav** | 重 | gravity (n.重力), grave (adj.严重的), gravitate (v.受吸引) |
| **greg** | 群 | gregarious (adj.群居的), congregate (v.集合), aggregate (v.聚集) |
| **gust** | 味道 | gust (n.一阵风), gusto (n.兴致), disgusting (adj.令人厌恶的) |
| **habit** | 居住 | habitat (n.栖息地), inhabit (v.居住), inhabitant (n.居民) |
| **hes/her** | 粘 | hesitate (v.犹豫), adhere (v.粘附), cohesion (n.凝聚力) |
| **honor** | 荣誉 | honor (n.荣誉), honorable (adj.光荣的), honorarium (n.酬金) |
| **horror** | 恐惧 | horror (n.恐怖), horrible (adj.可怕的), horrid (adj.令人毛骨悚然的) |
| **hospit** | 客人 | hospital (n.医院), hospitable (adj.好客的), hospice (n.收容所) |
| **host** | 敌人/客人 | host (n.主人), hostile (adj.敌对的), hostage (n.人质) |
| **hum** | 人 | human (n.人类), humane (adj.人道的), humanity (n.人性) |
| **humor** | 液体，幽默 | humor (n.幽默), humorous (adj.幽默的), humorist (n.幽默作家) |
| **icon** | 图像 | icon (n.图标), iconic (adj.标志性的), iconoclasm (n.偶像破坏) |
| **ide** | 思想 | idea (n.想法), ideal (adj.理想的), ideology (n.意识形态) |
| **idi** | 特殊 | idiom (n.习语), idiot (n.白痴), idiosyncrasy (n.特质) |
| **idol** | 偶像 | idol (n.偶像), idolize (v.崇拜), idolatry (n.偶像崇拜) |
| **imag** | 图像 | image (n.图像), imagine (v.想象), imaginary (adj.虚构的) |
| **imit** | 模仿 | imitate (v.模仿), imitation (n.模仿), imitator (n.模仿者) |
| **imper** | 命令 | emperor (n.皇帝), empire (n.帝国), imperial (adj.帝国的) |
| **impl** | 填充 | implement (v.实施), implication (n.含义), implicit (adj.含蓄的) |
| **import** | 携带 | import (v.进口), important (adj.重要的), importance (n.重要性) |
| **impos** | 放置 | impose (v.强加), impossible (adj.不可能的), impostor (n.骗子) |
| **impot** | 能力 | impotent (adj.无能的), potent (adj.有效的) |
| **improv** | 准备 | improvise (v.即兴创作), improvisation (n.即兴创作) |
| **inan** | 空 | inane (adj.空洞的), inanity (n.空洞) |
| **inclin** | 倾斜 | incline (v.倾斜), inclination (n.倾向), decline (v.下降) |
| **inclu** | 关闭 | include (v.包括), inclusion (n.包含) |
| **incub** | 躺 | incubate (v.孵化), incubation (n.孵化期) |
| **indemn** | 保护 | indemnity (n.赔偿), indemnify (v.赔偿) |
| **indic** | 指示 | indicate (v.指示), index (n.索引), indicator (n.指示器) |
| **indig** | 需要 | indigent (adj.贫困的), indigence (n.贫困) |
| **indign** | 不值得 | indignant (adj.愤慨的), indignation (n.愤慨) |
| **indul** | 宽容 | indulge (v.纵容), indulgent (adj.纵容的), indulgence (n.纵容) |
| **indust** | 勤奋 | industry (n.工业), industrious (adj.勤奋的), industrial (adj.工业的) |
| **inert** | 不动 | inert (adj.惰性的), inertia (n.惯性) |
| **infer** | 带来 | infer (v.推断), inference (n.推断) |
| **infest** | 攻击 | infest (v.骚扰), infestation (n.侵扰) |
| **infin** | 无限 | infinite (adj.无限的), infinity (n.无限) |
| **inflam** | 燃烧 | inflame (v.发炎), inflammation (n.炎症) |
| **inflect** | 弯曲 | inflect (v.使弯曲), inflection (n.转折) |
| **informat** | 形状 | inform (v.通知), information (n.信息) |
| **infus** | 倒入 | infuse (v.注入), infusion (n.输液), transfuse (v.输血) |
| **ingest** | 携带 | ingest (v.摄入), ingestion (n.摄入) |
| **inher** | 粘着 | inherit (v.继承), inheritance (n.遗产), inherent (adj.固有的) |
| **inhibit** | 阻止 | inhibit (v.抑制), inhibition (n.抑制) |
| **init** | 开始 | initiate (v.发起), initial (adj.最初的), initiative (n.主动性) |
| **inocul** | 芽 | inoculate (v.接种), inoculation (n.接种) |
| **inquir** | 询问 | inquire (v.询问), inquiry (n.询问) |
| **inscrib** | 写 | inscribe (v.题写), inscription (n.铭文) |
| **insist** | 站立 | insist (v.坚持), insistence (n.坚持), insistent (adj.坚持的) |
| **inspec** | 看 | inspect (v.检查), inspection (n.检查), inspector (n.检查员) |
| **inspir** | 呼吸 | inspire (v.鼓舞), inspiration (n.灵感) |
| **instal** | 安装 | install (v.安装), installation (n.安装) |
| **instig** | 刺激 | instigate (v.煽动), instigation (n.煽动) |
| **institut** | 建立 | institute (n.学会), institution (n.机构) |
| **instruc** | 建造 | instruct (v.指导), instruction (n.说明), instructor (n.教练) |
| **insul** | 岛 | insulate (v.隔离), insulation (n.绝缘) |
| **insur** | 保护 | insure (v.保险), insurance (n.保险) |
| **integr** | 完整 | integrate (v.整合), integral (adj.完整的), integrity (n.正直) |
| **intend** | 伸展 | intend (v.打算), intention (n.意图), intense (adj.强烈的) |
| **inter** | 之间 | inter (v.埋葬), interest (n.兴趣), interrupt (v.打断) |
| **interrog** | 问 | interrogate (v.审问), interrogation (n.审问) |
| **intervene** | 介入 | intervene (v.干预), intervention (n.干预) |
| **intim** | 内部 | intimate (adj.亲密的), intimacy (n.亲密) |
| **intric** | 复杂 | intricate (adj.复杂的), intricacy (n.复杂) |
| **intrud** | 推入 | intrude (v.侵入), intrusion (n.侵入) |
| **intuit** | 看 | intuit (v.直觉), intuition (n.直觉), intuitive (adj.直观的) |
| **invad** | 进入 | invade (v.入侵), invasion (n.入侵), invader (n.入侵者) |
| **invent** | 来 | invent (v.发明), invention (n.发明), inventor (n.发明家) |
| **invert** | 转 | invert (v.倒置), inversion (n.倒置), inverse (adj.相反的) |
| **invest** | 衣服 | invest (v.投资), investment (n.投资) |
| **invit** | 邀请 | invite (v.邀请), invitation (n.邀请) |
| **involve** | 卷入 | involve (v.涉及), involvement (n.参与) |
| **irasc** | 愤怒 | irascible (adj.易怒的), irascibility (n.易怒) |
| **irrit** | 刺激 | irritate (v.激怒), irritation (n.刺激) |
| **isol** | 隔离 | isolate (v.隔离), isolation (n.隔离) |
| **itiner** | 路线 | itinerary (n.行程), itinerant (adj.流动的) |
| **jac/jec** | 投掷 | eject (v.喷射), inject (v.注射), project (v.投射) |
| **jacent** | 躺 | adjacent (adj.相邻的), recumbent (adj.躺着的) |
| **joc** | 玩笑 | joke (n.笑话), jocular (adj.爱开玩笑的), jocose (adj.诙谐的) |
| **join** | 连接 | join (v.加入), joint (n.关节), junction (n.连接点) |
| **journ** | 天，日 | journal (n.日记), journey (n.旅程), adjourn (v.休会) |
| **judg** | 判断 | judge (n.法官), judgment (n.判断) |
| **jug** | 连接 | jugate (adj.连接的), conjugate (v.结合) |
| **junc** | 连接 | junction (n.连接点), conjunction (n.连词) |
| **jur/jus** | 法律 | jury (n.陪审团), justice (n.正义), justify (v.证明正当) |
| **juven** | 年轻 | juvenile (adj.青少年的), rejuvenate (v.使年轻), junior (adj.年少的) |
| **juxt** | 旁边 | juxtapose (v.并列) |
| **labor** | 劳动 | labor (n.劳动), laborious (adj.费力的), collaborate (v.合作) |
| **laps** | 滑倒 | lapse (n.失误), collapse (v.倒塌), relapse (v.复发) |
| **larg** | 慷慨 | large (adj.大的), largess (n.慷慨), enlarge (v.扩大) |
| **laud** | 赞美 | laud (v.赞美), laudable (adj.值得赞扬的), applaud (v.鼓掌) |
| **lect** | 选择 | select (v.选择), collect (v.收集), elect (v.选举) |
| **leg** | 法律 | legal (adj.合法的), legislate (v.立法), legacy (n.遗产) |
| **leg** | 读 | lecture (n.讲座), legible (adj.清晰的), legend (n.传说) |
| **len** | 缓和 | lenient (adj.宽大的), lenity (n.宽大) |
| **lev** | 轻 | levity (n.轻浮), levitate (v.漂浮), alleviate (v.减轻) |
| **lex** | 词，法律 | lexicon (n.词典), lexical (adj.词汇的) |
| **liber** | 自由 | liberty (n.自由), liberal (adj.自由的), liberate (v.解放) |
| **libr** | 书，平衡 | library (n.图书馆), librate (v.平衡), equilibrium (n.平衡) |
| **lic** | 允许 | license (n.许可证), illicit (adj.非法的) |
| **lig** | 绑 | ligament (n.韧带), oblige (v.强迫), religion (n.宗教) |
| **lin** | 线 | line (n.线), linear (adj.线性的), lineage (n.血统) |
| **liqu** | 液体 | liquid (n.液体), liquefy (v.液化), liquor (n.酒) |
| **liter** | 字母，文学 | literal (adj.字面的), literary (adj.文学的), literature (n.文学) |
| **litig** | 诉讼 | litigate (v.诉讼), litigation (n.诉讼) |
| **loc** | 地方 | local (adj.当地的), locate (v.定位), location (n.位置) |
| **locut** | 说 | locution (n.措辞), elocution (n.演讲) |
| **log** | 说，研究 | logic (n.逻辑), biology (n.生物学), dialogue (n.对话) |
| **loqu** | 说 | loquacious (adj.健谈的), eloquent (adj.雄辩的), soliloquy (n.独白) |
| **lubric** | 滑 | lubricate (v.润滑), lubrication (n.润滑) |
| **luc** | 光 | lucid (adj.清晰的), elucidate (v.阐明), translucent (adj.半透明的) |
| **lud/lus** | 玩 | ludic (adj.游戏的), ludicrous (adj.荒谬的), allude (v.暗指) |
| **lun** | 月亮 | lunar (adj.月亮的), lunatic (adj.疯狂的), lunation (n.朔望月) |
| **lustr** | 照亮 | illustrate (v.说明), lustre (n.光泽) |
| **lyr** | 琴 | lyric (n.抒情诗), lyre (n.七弦琴), lyrical (adj.抒情的) |
| **magn** | 大 | magnify (v.放大), magnificent (adj.壮丽的), magnitude (n.大小) |
| **magnet** | 磁 | magnet (n.磁铁), magnetic (adj.磁的) |
| **mal** | 坏 | malice (n.恶意), malignant (adj.恶性的), malfunction (n.故障) |
| **mand** | 命令 | mandate (n.授权), command (n.命令), demand (v.要求) |
| **man** | 手 | manual (adj.手动的), manage (v.管理), manifest (v.显示) |
| **manip** | 手 | manipulate (v.操纵), manipulation (n.操纵) |
| **marc** | 标记 | mark (n.标记), margin (n.边缘), marginal (adj.边缘的) |
| **mass** | 团块 | mass (n.质量), massive (adj.大量的), amass (v.积累) |
| **mat** | 母亲 | maternal (adj.母亲的), maternity (n. maternity) |
| **math** | 学习 | math (n.数学), mathematics (n.数学) |
| **matur** | 成熟 | mature (adj.成熟的), maturity (n.成熟), premature (adj.早产的) |
| **maxim** | 最大 | maximum (n.最大值), maximize (v.最大化) |
| **med** | 中间 | median (n.中位数), medium (n.媒体), mediate (v.调解) |
| **medic** | 治疗 | medical (adj.医学的), medicine (n.药) |
| **medit** | 思考 | meditate (v.冥想), meditation (n.冥想) |
| **membr** | 膜 | membrane (n.膜), membranous (adj.膜的) |
| **memor** | 记忆 | memory (n.记忆), memorize (v.记住), remember (v.记得) |
| **mend** | 修正 | mend (v.修理), amend (v.修正), emend (v.校订) |
| **mens** | 测量 | measure (v.测量), dimension (n.尺寸) |
| **merc** | 商业 | merchant (n.商人), commerce (n.商业) |
| **merg/mers** | 沉 | merge (v.合并), immerse (v.沉浸), submerge (v.淹没) |
| **merit** | 值得 | merit (n.优点), meritorious (adj.有功的) |
| **milit** | 士兵 | military (adj.军事的), militia (n.民兵) |
| **mill** | 千，磨 | mill (n.磨坊), millimeter (n.毫米), millennium (n.千年) |
| **min** | 小 | minor (adj.较小的), minute (n.分钟), diminish (v.减少) |
| **minim** | 最小 | minimum (n.最小值), minimize (v.最小化) |
| **minister** | 仆人 | minister (n.部长), administer (v.管理) |
| **mir** | 惊奇 | miracle (n.奇迹), mirror (n.镜子), admire (v.钦佩) |
| **misc** | 混合 | misc (n.杂项), miscible (adj.可混溶的) |
| **mis** | 恨 | misanthrope (n.厌世者), misogyny (n.厌女症) |
| **miss** | 送 | mission (n.使命), missile (n.导弹), dismiss (v.解雇) |
| **mit** | 送 | admit (v.承认), submit (v.提交), transmit (v.传输) |
| **mix** | 混合 | mix (v.混合), mixture (n.混合物) |
| **mnem** | 记忆 | mnemonic (n.助记符), amnesia (n.失忆) |
| **mob** | 移动 | mobile (adj.移动的), mobility (n.流动性) |
| **mod** | 方式，测量 | mode (n.模式), model (n.模型), modify (v.修改) |
| **moder** | 节制 | moderate (adj.适度的), moderation (n.适度) |
| **modul** | 测量 | module (n.模块), modulate (v.调节) |
| **moll** | 软 | mollify (v.安抚), mollusk (n.软体动物) |
| **moment** | 移动 | moment (n.时刻), momentum (n.动力) |
| **mon** | 警告 | admonish (v.告诫), monitor (n.监视器) |
| **monarch** | 统治者 | monarch (n.君主), monarchy (n.君主制) |
| **monet** | 钱 | money (n.钱), monetary (adj.货币的) |
| **monstr** | 显示 | demonstrate (v.演示), monster (n.怪物) |
| **mor** | 习俗 | moral (adj.道德的), morale (n.士气), morality (n.道德) |
| **morph** | 形状 | morphology (n.形态学), metamorphosis (n.变形) |
| **mort** | 死 | mortal (adj.必死的), mortality (n.死亡率), mortify (v.使羞愧) |
| **mot** | 移动 | motion (n.运动), motive (n.动机), promote (v.促进) |
| **mourn** | 哀悼 | mourn (v.哀悼), mourning (n.哀悼) |
| **mov** | 移动 | move (v.移动), movement (n.运动), remove (v.移除) |
| **multi** | 多 | multiple (adj.多个的), multiply (v.乘) |
| **mut** | 改变 | mutate (v.突变), mutation (n.突变), mutual (adj.相互的) |
| **myth** | 神话 | myth (n.神话), mythology (n.神话学) |
| **nasc/nat** | 出生 | nascent (adj.初期的), native (adj.本地的), natal (adj.出生的) |
| **nav** | 船 | navy (n.海军), naval (adj.海军的), navigate (v.导航) |
| **nect/nex** | 连接 | connect (v.连接), nexus (n.联系), annex (v.兼并) |
| **neg** | 否认 | negate (v.否定), negative (adj.负面的), deny (v.否认) |
| **nihil** | 无 | nihilism (n.虚无主义), nihilist (n.虚无主义者) |
| **noc/nox** | 伤害 | noxious (adj.有害的), innocent (adj.无辜的) |
| **nomin** | 名字 | nominal (adj.名义的), nominate (v.提名), nomenclature (n.命名法) |
| **norm** | 规范 | normal (adj.正常的), norm (n.规范), normalize (v.标准化) |
| **nostalg** | 思乡 | nostalgia (n.怀旧), nostalgic (adj.怀旧的) |
| **not** | 标记 | note (n.笔记), notice (v.注意), notify (v.通知) |
| **nox** | 夜 | nocturnal (adj.夜间的), nocturne (n.夜曲) |
| **null** | 无 | null (adj.无效的), nullify (v.使无效), annul (v.废除) |
| **numer** | 数字 | number (n.数字), numerical (adj.数值的), enumerate (v.列举) |
| **nunc/nunci** | 报告 | announce (v.宣布), denounce (v.谴责) |
| **nutr** | 营养 | nutrition (n.营养), nutrient (n.营养素) |
| **oblig** | 约束 | oblige (v.强迫), obligation (n.义务) |
| **obscur** | 黑暗 | obscure (adj.模糊的), obscurity (n.模糊) |
| **observ** | 观察 | observe (v.观察), observer (n.观察者) |
| **obsess** | 迷恋 | obsess (v.迷恋), obsession (n.痴迷) |
| **obstin** | 固执 | obstinate (adj.固执的), obstinacy (n.固执) |
| **obstruct** | 阻塞 | obstruct (v.阻塞), obstruction (n.障碍) |
| **obtain** | 获得 | obtain (v.获得) |
| **occup** | 占据 | occupy (v.占据), occupation (n.职业) |
| **odi** | 恨 | odium (n.憎恨), odious (adj.可憎的) |
| **odor** | 气味 | odor (n.气味), deodorant (n.除臭剂) |
| **offend** | 冒犯 | offend (v.冒犯), offense (n.冒犯) |
| **offer** | 提供 | offer (v.提供) |
| **offic** | 工作 | office (n.办公室), officer (n.官员), official (adj.官方的) |
| **omit** | 省略 | omit (v.省略), omission (n.省略) |
| **oper** | 工作 | operate (v.操作), operation (n.手术), cooperate (v.合作) |
| **opin** | 认为 | opinion (n.意见), opine (v.认为) |
| **opt** | 选择，看 | option (n.选项), opt (v.选择), adopt (v.采用) |
| **optim** | 最好 | optimal (adj.最佳的), optimize (v.优化), optimism (n.乐观) |
| **or** | 说 | orator (n.演说家), oracle (n.神谕), oral (adj.口头的) |
| **ordin** | 秩序 | order (n.顺序), ordinary (adj.普通的), coordinate (v.协调) |
| **org** | 器官 | organ (n.器官), organize (v.组织), organism (n.生物体) |
| **orient** | 东方 | orient (v.定向), oriental (adj.东方的), orientation (n.方向) |
| **origin** | 起源 | origin (n.起源), original (adj.原始的), originate (v.起源) |
| **orph** | 孤儿 | orphan (n.孤儿), orphanage (n.孤儿院) |
| **pac** | 和平 | peace (n.和平), pacify (v.安抚), pacific (adj.和平的) |
| **pag** | 固定 | page (n.页), pagan (n.异教徒) |
| **pain** | 惩罚 | pain (n.疼痛), painful (adj.疼痛的), penal (adj.刑罚的) |
| **palat** | 上颚 | palate (n.上颚), palatal (adj.腭的) |
| **palp** | 触摸 | palpable (adj.可触摸的), palpitate (v.心悸) |
| **pand** | 展开 | expand (v.扩展), pandemic (adj.大流行的) |
| **par** | 平等 | parity (n.平等), compare (v.比较) |
| **part** | 部分 | part (n.部分), particle (n.粒子), participate (v.参与) |
| **pass** | 走/感情 | pass (v.通过), passage (n.通道), passion (n.激情) |
| **past** | 喂养 | pasture (n.牧场), pastor (n.牧师) |
| **pat** | 父亲/忍受 | paternal (adj.父亲的), patient (adj.耐心的) |
| **path** | 感觉，疾病 | pathos (n.悲情), sympathy (n.同情), pathology (n.病理学) |
| **patr** | 父亲 | patriot (n.爱国者), patron (n.赞助人) |
| **pauc** | 少 | paucity (n.缺乏), pauper (n.穷人) |
| **pec** | 钱 | pecuniary (adj.金钱的) |
| **pect** | 看 | expect (v.期待), inspect (v.检查) |
| **ped** | 脚/教育 | pedal (n.踏板), pedagogy (n.教学法) |
| **pel/puls** | 驱动 | expel (v.开除), compel (v.强迫), impulse (n.冲动) |
| **pen** | 几乎/惩罚/悬挂 | peninsula (n.半岛), penal (adj.刑罚的), pendant (n.吊坠) |
| **pend/pens** | 悬挂，花费 | depend (v.依赖), suspend (v.暂停), expense (n.费用) |
| **per** | 通过 | per (prep.每), permeate (v.渗透), permanent (adj.永久的) |
| **peril** | 危险 | peril (n.危险), perilous (adj.危险的) |
| **perm** | 允许 | permit (v.允许), permission (n.许可) |
| **persuad** | 说服 | persuade (v.说服), persuasion (n.说服) |
| **pertin** | 属于 | pertinent (adj.相关的) |
| **pet** | 寻求 | petition (n.请愿), compete (v.竞争) |
| **phag** | 吃 | phagocyte (n.吞噬细胞) |
| **phan** | 显示 | phantom (n.幽灵), phenomenon (n.现象) |
| **pharm** | 药 | pharmacy (n.药房), pharmaceutical (adj.制药的) |
| **phil** | 爱 | philosophy (n.哲学), philanthropy (n.慈善) |
| **phob** | 恐惧 | phobia (n.恐惧症), claustrophobia (n.幽闭恐惧症) |
| **phon** | 声音 | phone (n.电话), phonics (n.语音学), symphony (n.交响乐) |
| **phot** | 光 | photo (n.照片), photograph (n.照片) |
| **phys** | 自然 | physics (n.物理), physical (adj.身体的) |
| **pict** | 绘画 | picture (n.图片), depict (v.描绘) |
| **pil** | 毛发/药丸 | pilose (adj.有毛的), pill (n.药丸) |
| **ping/pict** | 绘画 | paint (v.绘画), picture (n.图片) |
| **pisc** | 鱼 | piscivorous (adj.食鱼的) |
| **pit** | 同情 | pity (n.怜悯), pitiable (adj.可怜的) |
| **plac** | 取悦/放置 | please (v.请), place (n.地方) |
| **plan** | 平坦/漫游 | plain (n.平原), planet (n.行星) |
| **plast** | 形成 | plastic (n.塑料) |
| **ple** | 满 | please (v.请), complete (adj.完整的) |
| **plect/plex** | 编织 | complex (adj.复杂的), perplex (v.使困惑) |
| **plen** | 满 | plenty (n.大量), plenary (adj.全体的) |
| **plic/ply** | 折叠 | apply (v.申请), imply (v.暗示), complex (adj.复杂的) |
| **plor** | 呼喊 | explore (v.探索), implore (v.恳求) |
| **plumb** | 铅 | plumb (v.探测), plumber (n.水管工) |
| **plur** | 多 | plural (adj.复数的), plurality (n.多数) |
| **plut** | 财富 | plutocracy (n.富豪政治) |
| **pneum** | 呼吸 | pneumonia (n.肺炎), pneumatic (adj.气动的) |
| **pod** | 脚 | tripod (n.三脚架), podiatry (n.足病学) |
| **poet** | 诗人 | poet (n.诗人), poetry (n.诗歌) |
| **pogon** | 胡子 | pogon (n.胡子) |
| **pol** | 城市/磨光 | polis (n.城邦), polish (v.抛光) |
| **polem** | 战争 | polemic (n.论战) |
| **polit** | 城市 | politics (n.政治), political (adj.政治的) |
| **pollu** | 污染 | pollute (v.污染) |
| **ponder** | 重量 | ponder (v.沉思), ponderous (adj.笨重的) |
| **pont** | 桥 | pontoon (n.浮桥), pontiff (n.教皇) |
| **popul** | 人民 | people (n.人民), population (n.人口), popular (adj.流行的) |
| **port** | 携带 | port (n.港口), transport (v.运输), import (v.进口) |
| **pos** | 放置 | position (n.位置), compose (v.作曲), propose (v.提议) |
| **posit** | 放置 | position (n.位置), deposit (v.存款) |
| **poss** | 能够 | possible (adj.可能的), possess (v.拥有) |
| **post** | 后 | post (n.邮件), posterior (adj.后面的) |
| **pot** | 能够 | potent (adj.有效的), potential (adj.潜在的) |
| **pract** | 做 | practice (n.练习) |
| **prehens** | 抓 | prehensile (adj.能抓握的), apprehend (v.逮捕) |
| **press** | 压 | press (v.压), pressure (n.压力) |
| **pret** | 价值 | price (n.价格), appreciate (v.欣赏) |
| **prim** | 第一 | prime (adj.主要的), primary (adj.初级的) |
| **princ** | 第一 | prince (n.王子), principal (adj.主要的) |
| **pris** | 抓 | prison (n.监狱), surprise (n.惊喜) |
| **priv** | 私人 | private (adj.私人的), deprive (v.剥夺) |
| **prob** | 测试 | prove (v.证明), probe (v.探查) |
| **proced** | 走 | proceed (v.进行) |
| **proclaim** | 呼喊 | proclaim (v.宣布) |
| **produc** | 引导 | produce (v.生产) |
| **profess** | 说 | profess (v.声称) |
| **profit** | 收益 | profit (n.利润) |
| **progn** | 知道 | prognosis (n.预后) |
| **prohib** | 禁止 | prohibit (v.禁止) |
| **project** | 投掷 | project (n.项目) |
| **prol** | 后代 | progeny (n.后代), prolific (adj.多产的) |
| **promis** | 发送 | promise (n.承诺) |
| **promot** | 移动 | promote (v.促进) |
| **pronounc** | 说 | pronounce (v.发音) |
| **prop** | 支撑 | prop (n.支柱), support (v.支持) |
| **propel** | 驱动 | propel (v.推进) |
| **prophet** | 预言 | prophet (n.先知) |
| **propon** | 放置 | propose (v.提议) |
| **propr** | 自己的 | proper (adj.适当的), property (n.财产) |
| **prosecut** | 跟随 | prosecute (v.起诉) |
| **prosper** | 繁荣 | prosper (v.繁荣) |
| **protect** | 覆盖 | protect (v.保护) |
| **protest** | 见证 | protest (v.抗议) |
| **protract** | 拉 | protract (v.延长) |
| **proxim** | 接近 | proximity (n.接近) |
| **prud** | 谨慎 | prudent (adj.谨慎的) |
| **psalm** | 诗歌 | psalm (n.圣歌) |
| **pseud** | 假 | pseudonym (n.笔名) |
| **psych** | 心灵 | psychology (n.心理学) |
| **public** | 公共 | public (adj.公共的), publish (v.出版) |
| **pugn** | 战斗 | pugnacious (adj.好斗的) |
| **pull** | 拉 | pull (v.拉), repel (v.排斥) |
| **puls** | 驱动 | pulse (n.脉搏), compel (v.强迫) |
| **punct** | 刺 | puncture (n.刺孔), punctual (adj.准时的) |
| **punish** | 惩罚 | punish (v.惩罚) |
| **pup** | 保护 | pupil (n.学生), puppet (n.木偶) |
| **pur** | 纯净 | pure (adj.纯净的), purify (v.净化) |
| **pursu** | 跟随 | pursue (v.追求) |
| **put** | 思考 | putative (adj.所谓的), compute (v.计算) |
| **pyr** | 火 | pyre (n.火葬柴堆), pyramid (n.金字塔) |
| **quadr** | 四 | square (n.正方形), quadrant (n.象限) |
| **qual** | 质量 | quality (n.质量) |
| **quant** | 数量 | quantity (n.数量) |
| **quer/quis** | 询问，寻求 | query (n.查询), question (n.问题), acquire (v.获得) |
| **quest** | 寻求 | quest (n.探索), question (n.问题) |
| **quiet** | 安静 | quiet (adj.安静的), quietus (n.解脱) |
| **quint** | 第五 | quintet (n.五重奏) |
| **quir** | 询问 | inquire (v.询问) |
| **quit** | 自由 | quit (v.退出), acquit (v.宣告无罪) |
| **quot** | 多少 | quote (v.引用), quotient (n.商) |
| **rab** | 疯狂 | rabies (n.狂犬病), rabid (adj.狂热的) |
| **rac** | 种族 | race (n.种族), racial (adj.种族的) |
| **rad** | 根 | radical (adj.激进的), radish (n.萝卜) |
| **radi** | 射线 | radio (n.收音机), radius (n.半径) |
| **rap/rav** | 抢夺 | rape (n.强奸), ravage (v.毁坏), ravish (v.使陶醉) |
| **rat** | 计算 | rate (n.比率), ratio (n.比例) |
| **react** | 反应 | react (v.反应) |
| **reason** | 理性 | reason (n.理由) |
| **rebell** | 反叛 | rebel (n.反叛者) |
| **reced** | 退 | recede (v.后退) |
| **recept** | 接收 | receive (v.接收), receipt (n.收据) |
| **recit** | 背诵 | recite (v.背诵) |
| **recogn** | 知道 | recognize (v.认出) |
| **reconcil** | 和解 | reconcile (v.和解) |
| **record** | 心 | record (n.记录) |
| **recover** | 覆盖 | recover (v.恢复) |
| **rect** | 直，正 | rectify (v.纠正), correct (adj.正确的), direct (adj.直接的) |
| **recuper** | 恢复 | recuperate (v.恢复) |
| **recur** | 跑 | recur (v.重现) |
| **red** | 给 | render (v.渲染) |
| **reduc** | 引导 | reduce (v.减少) |
| **refer** | 携带 | refer (v.参考) |
| **reflect** | 弯曲 | reflect (v.反射) |
| **reform** | 形状 | reform (v.改革) |
| **refug** | 逃跑 | refuge (n.避难所) |
| **reg** | 统治 | rule (v.统治), regal (adj.王室的) |
| **regener** | 产生 | regenerate (v.再生) |
| **regret** | 遗憾 | regret (v.后悔) |
| **regul** | 规则 | rule (n.规则), regular (adj.规律的) |
| **rehab** | 有 | rehabilitate (v.康复) |
| **reign** | 统治 | reign (v.统治) |
| **reject** | 投掷 | reject (v.拒绝) |
| **relat** | 携带 | relate (v.联系) |
| **relax** | 松开 | relax (v.放松) |
| **releas** | 释放 | release (v.释放) |
| **relev** | 举起 | relieve (v.缓解), relevant (adj.相关的) |
| **reli** | 绑 | rely (v.依赖), reliable (adj.可靠的) |
| **relig** | 绑 | religion (n.宗教) |
| **relinqu** | 离开 | relinquish (v.放弃) |
| **remain** | 保持 | remain (v.保持) |
| **remed** | 治疗 | remedy (n.补救) |
| **remember** | 记忆 | remember (v.记得) |
| **reminisc** | 记忆 | reminisce (v.回忆) |
| **remit** | 送 | remit (v.汇款) |
| **remonstr** | 显示 | remonstrate (v.抗议) |
| **remov** | 移动 | remove (v.移除) |
| **renov** | 更新 | renovate (v.翻新) |
| **renunc** | 说 | renounce (v.放弃) |
| **rep** | 洞穴 | reptile (n.爬行动物) |
| **repeal** | 呼喊 | repeal (v.废除) |
| **repeat** | 寻求 | repeat (v.重复) |
| **repel** | 驱动 | repel (v.排斥) |
| **repercuss** | 打击 | repercussion (n.反响) |
| **repet** | 寻求 | repeat (v.重复) |
| **replac** | 放置 | replace (v.替换) |
| **replet** | 满 | replete (adj.充满的) |
| **replic** | 折叠 | replicate (v.复制) |
| **reply** | 满 | reply (v.回答) |
| **repose** | 放置 | repose (v.休息) |
| **represent** | 呈现 | represent (v.代表) |
| **repress** | 压 | repress (v.压制) |
| **reprim** | 按压 | reprimand (v.谴责) |
| **reprob** | 测试 | reprobate (n.堕落者) |
| **reproduc** | 引导 | reproduce (v.复制) |
| **rept** | 爬 | reptile (n.爬行动物) |
| **republic** | 公共 | republic (n.共和国) |
| **repudi** | 拒绝 | repudiate (v.拒绝) |
| **repugn** | 战斗 | repugnant (adj.令人反感的) |
| **repuls** | 驱动 | repulse (v.击退) |
| **reput** | 思考 | repute (v.名誉) |
| **request** | 寻求 | request (n.请求) |
| **requir** | 询问 | require (v.要求) |
| **rescind** | 切 | rescind (v.废除) |
| **rescu** | 拯救 | rescue (v.救援) |
| **resembl** | 相似 | resemble (v.相似) |
| **resent** | 感觉 | resent (v.怨恨) |
| **reserv** | 保持 | reserve (v.保留) |
| **resid** | 坐 | reside (v.居住) |
| **resign** | 标记 | resign (v.辞职) |
| **resist** | 站立 | resist (v.抵抗) |
| **resolv** | 解开 | resolve (v.决心) |
| **reson** | 声音 | resonate (v.共鸣) |
| **resort** | 出去 | resort (n.度假村) |
| **respec** | 看 | respect (v.尊重) |
| **respir** | 呼吸 | respire (v.呼吸) |
| **respond** | 回答 | respond (v.回应) |
| **rest** | 站立 | rest (v.休息) |
| **restor** | 恢复 | restore (v.恢复) |
| **restrain** | 拉紧 | restrain (v.抑制) |
| **restrict** | 拉紧 | restrict (v.限制) |
| **result** | 跳 | result (n.结果) |
| **resum** | 拿 | resume (v.恢复) |
| **retail** | 切割 | retail (n.零售) |
| **retain** | 保持 | retain (v.保留) |
| **retard** | 延迟 | retard (v.延迟) |
| **retent** | 保持 | retention (n.保留) |
| **retic** | 网 | reticle (n.十字线) |
| **retir** | 拉回 | retire (v.退休) |
| **retort** | 扭转 | retort (v.反驳) |
| **retract** | 拉回 | retract (v.撤回) |
| **retreat** | 拉回 | retreat (v.撤退) |
| **retribu** | 给予 | retribution (n.报应) |
| **retriev** | 找到 | retrieve (v.检索) |
| **return** | 转动 | return (v.返回) |
| **reun** | 一 | reunite (v.重聚) |
| **revel** | 反叛 | revel (v.狂欢) |
| **revenge** | 复仇 | revenge (n.复仇) |
| **rever** | 敬畏 | revere (v.尊敬) |
| **revers** | 转动 | reverse (v.逆转) |
| **revert** | 转动 | revert (v.恢复) |
| **review** | 看见 | review (v.回顾) |
| **revis** | 看 | revise (v.修订) |
| **reviv** | 活 | revive (v.复苏) |
| **revoc** | 呼叫 | revoke (v.撤销) |
| **revolt** | 滚动 | revolt (v.反叛) |
| **revolv** | 滚动 | revolve (v.旋转) |
| **rhaps** | 缝合 | rhapsody (n.狂想曲) |
| **rhe** | 流动 | rheumatism (n.风湿病) |
| **rhetor** | 演讲 | rhetoric (n.修辞) |
| **rhiz** | 根 | rhizome (n.根茎) |
| **rhythm** | 节奏 | rhythm (n.节奏) |
| **rid** | 嘲笑/骑 | ridicule (v.嘲笑), ride (v.骑) |
| **rig** | 直 | rigid (adj.僵硬的) |
| **rit** | 仪式 | rite (n.仪式), ritual (n.仪式) |
| **riv** | 河 | river (n.河) |
| **rob** | 抢劫 | rob (v.抢劫) |
| **rod** | 咬 | rodent (n.啮齿动物) |
| **rog** | 问 | rogation (n.祈祷) |
| **rol** | 滚动 | roll (v.滚动) |
| **rom** | 罗马 | romance (n.浪漫) |
| **root** | 根 | root (n.根) |
| **ros** | 玫瑰/露水 | rose (n.玫瑰), rosid (n.蔷薇类) |
| **rot** | 轮/腐烂 | rotate (v.旋转), rot (v.腐烂) |
| **roy** | 国王 | royal (adj.皇家的) |
| **rub** | 摩擦 | rub (v.摩擦) |
| **rud** | 粗糙 | rude (adj.粗鲁的) |
| **ruin** | 倒塌 | ruin (v.毁坏) |
| **rul** | 统治 | rule (n.规则) |
| **rum** | 喧闹 | rumor (n.谣言) |
| **rumin** | 反刍 | ruminate (v.反刍) |
| **rupt** | 打破 | rupture (n.破裂), interrupt (v.打断) |
| **rur** | 乡村 | rural (adj.农村的) |
| **sac** | 袋子/神圣 | sac (n.囊), sacred (adj.神圣的) |
| **sacr** | 神圣 | sacred (adj.神圣的), sacrifice (n.牺牲) |
| **saf** | 安全 | safe (adj.安全的) |
| **sag** | 下垂/智慧 | sag (v.下垂), sage (n.圣人) |
| **sal** | 盐/跳跃/健康 | salt (n.盐), salient (adj.显著的), salute (v.敬礼) |
| **salv** | 拯救 | save (v.保存) |
| **san** | 健康 | sane (adj.神志清醒的) |
| **sanct** | 神圣 | sacred (adj.神圣的) |
| **sangu** | 血 | sanguine (adj.乐观的) |
| **sap** | 智慧 | sapient (adj.聪明的) |
| **sarc** | 肉 | sarcasm (n.讽刺) |
| **sat** | 足够 | satisfy (v.满足) |
| **satur** | 足够 | saturate (v.饱和) |
| **sav** | 味道/知道 | savor (v.品味), savvy (adj.精明的) |
| **scal** | 爬 | scale (n.规模) |
| **scand** | 爬 | scandal (n.丑闻) |
| **scap** | 逃跑 | escape (v.逃跑) |
| **scat** | 分散 | scatter (v.分散) |
| **scent** | 气味 | scent (n.气味) |
| **sched** | 纸片 | schedule (n.时间表) |
| **schem** | 形状 | scheme (n.计划) |
| **schiz** | 分裂 | schism (n.分裂) |
| **schol** | 学校 | school (n.学校) |
| **sci** | 知道 | science (n.科学) |
| **scind** | 切 | scission (n.分裂) |
| **sciss** | 切 | scissor (n.剪刀) |
| **scop** | 看 | scope (n.范围) |
| **scrib/script** | 写 | scribe (n.抄写员), script (n.剧本), describe (v.描述) |
| **sculpt** | 雕刻 | sculpt (v.雕刻) |
| **se** | 分开 | separate (v.分开) |
| **seclud** | 关闭 | seclude (v.隔离) |
| **sec** | 跟随/切 | second (num.第二), section (n.部分) |
| **secre** | 分开 | secret (n.秘密) |
| **sect** | 切 | section (n.部分) |
| **secur** | 关心 | secure (adj.安全的) |
| **sed** | 坐/安抚 | sedentary (adj.久坐的), sedate (adj.安静的) |
| **semin** | 种子 | seminar (n.研讨会) |
| **sen** | 老 | senior (adj.年长的) |
| **sens/sent** | 感觉 | sense (n.感觉), sentiment (n.情感) |
| **separ** | 分开 | separate (v.分开) |
| **sept** | 腐烂 | septic (adj.腐败的) |
| **sequ** | 跟随 | sequence (n.序列) |
| **ser** | 系列 | series (n.系列) |
| **seren** | 平静 | serene (adj.宁静的) |
| **seri** | 严肃 | serious (adj.严肃的) |
| **serm** | 说 | sermon (n.布道) |
| **serp** | 爬 | serpent (n.蛇) |
| **sert** | 插入 | insert (v.插入) |
| **serv** | 服务/保持 | serve (v.服务), preserve (v.保存) |
| **sess** | 坐 | session (n.会议) |
| **set** | 放置 | set (v.放置) |
| **sett** | 放置 | settle (v.解决) |
| **sever** | 严肃/切 | severe (adj.严重的), sever (v.切断) |
| **sex** | 性别 | sex (n.性别) |
| **sign** | 标记 | sign (n.标志), signal (n.信号) |
| **sil** | 安静 | silent (adj.安静的) |
| **silic** | 石头 | silica (n.二氧化硅) |
| **silv** | 森林 | silvan (adj.森林的) |
| **simil/simul** | 相似，同时 | similar (adj.相似的), simulate (v.模拟) |
| **sin** | 罪 | sin (n.罪) |
| **sinc** | 纯净 | sincere (adj.真诚的) |
| **sing** | 唱/一个 | sing (v.唱), single (adj.单一的) |
| **sinistr** | 左 | sinister (adj.邪恶的) |
| **sinu** | 弯曲 | sinus (n.窦) |
| **sist/stat** | 站立，存在 | exist (v.存在), consist (v.组成), persist (v.坚持) |
| **sit** | 坐 | sit (v.坐) |
| **situ** | 放置 | situate (v.位于) |
| **soci** | 同伴，社会 | social (adj.社会的), society (n.社会), associate (v.联想) |
| **sol** | 太阳，单独 | solar (adj.太阳的), solitary (adj.孤独的), solo (n.独奏) |
| **solv/solut** | 解开，解决 | solve (v.解决), solution (n.解决方案), resolve (v.决心) |
| **somn** | 睡 | somnolent (adj.困倦的), insomnia (n.失眠) |
| **son** | 声音 | son (n.儿子), sonic (adj.音速的) |
| **soph** | 智慧 | sophist (n.诡辩家), philosophy (n.哲学) |
| **sopor** | 睡 | soporific (adj.催眠的) |
| **sorb** | 吸收 | absorb (v.吸收) |
| **sord** | 肮脏 | sordid (adj.肮脏的) |
| **sort** | 种类 | sort (n.种类) |
| **sound** | 声音 | sound (n.声音) |
| **sourc** | 来源 | source (n.来源) |
| **sovran** | 统治 | sovereign (adj.主权的) |
| **space** | 空间 | space (n.空间) |
| **span** | 跨越 | span (v.跨越) |
| **spark** | 火花 | spark (n.火花) |
| **spars** | 稀疏 | sparse (adj.稀疏的) |
| **spasm** | 痉挛 | spasm (n.痉挛) |
| **spat** | 争吵/空间 | spat (n.争吵), spatial (adj.空间的) |
| **speak** | 说 | speak (v.说) |
| **spec/spic** | 看 | inspect (v.检查), respect (v.尊重), suspect (v.怀疑) |
| **spell** | 咒语 | spell (n.咒语) |
| **spend** | 花费 | spend (v.花费) |
| **sperm** | 种子 | sperm (n.精子) |
| **sphere** | 球 | sphere (n.球体) |
| **spic** | 看 | inspect (v.检查) |
| **spice** | 香料 | spice (n.香料) |
| **spin** | 旋转/刺 | spin (v.旋转), spine (n.脊柱) |
| **spir** | 呼吸 | spirit (n.精神), inspire (v.鼓舞), expire (v.到期) |
| **spit** | 吐/旋转 | spit (v.吐) |
| **splend** | 发光 | splendid (adj.辉煌的) |
| **spong** | 海绵 | sponge (n.海绵) |
| **spons** | 承诺 | sponsor (n.赞助者) |
| **spor** | 种子 | spore (n.孢子) |
| **sport** | 携带 | sport (n.运动) |
| **sprawl** | 伸展 | sprawl (v.蔓延) |
| **spread** | 展开 | spread (v.展开) |
| **spring** | 跳 | spring (n.春天) |
| **sprinkle** | 洒 | sprinkle (v.洒) |
| **sprint** | 冲刺 | sprint (v.冲刺) |
| **sprout** | 发芽 | sprout (v.发芽) |
| **spur** | 马刺 | spur (n.马刺) |
| **squab** | 争吵 | squabble (v.争吵) |
| **squad** | 小队 | squad (n.小队) |
| **square** | 正方形 | square (n.正方形) |
| **squash** | 压扁 | squash (v.压扁) |
| **squat** | 蹲 | squat (v.蹲) |
| **squeez** | 压 | squeeze (v.挤压) |
| **stabil** | 稳定 | stable (adj.稳定的) |
| **stack** | 堆 | stack (n.堆) |
| **staff** | 手杖 | staff (n.员工) |
| **stage** | 舞台 | stage (n.舞台) |
| **stagn** | 停滞 | stagnate (v.停滞) |
| **stain** | 污渍 | stain (n.污渍) |
| **stall** | 摊位 | stall (n.摊位) |
| **stamen** | 雄蕊 | stamen (n.雄蕊) |
| **stamin** | 线 | stamina (n.耐力) |
| **stamp** | 邮票 | stamp (n.邮票) |
| **stance** | 站立 | stance (n.立场) |
| **stand** | 站立 | stand (v.站立) |
| **stap** | 堆 | staple (n.主食) |
| **star** | 星 | star (n.星星) |
| **starch** | 淀粉 | starch (n.淀粉) |
| **stare** | 凝视 | stare (v.凝视) |
| **start** | 开始 | start (v.开始) |
| **starv** | 饥饿 | starve (v.挨饿) |
| **stat** | 站立 | state (n.状态), statue (n.雕像) |
| **station** | 站立 | station (n.车站) |
| **staunch** | 忠诚 | staunch (adj.坚定的) |
| **stay** | 停留 | stay (v.停留) |
| **stead** | 地方 | steady (adj.稳定的) |
| **steal** | 偷 | steal (v.偷) |
| **steam** | 蒸汽 | steam (n.蒸汽) |
| **steel** | 钢 | steel (n.钢) |
| **steep** | 陡峭 | steep (adj.陡峭的) |
| **steer** | 驾驶 | steer (v.驾驶) |
| **stem** | 茎 | stem (n.茎) |
| **stencil** | 模板 | stencil (n.模板) |
| **stenos** | 窄 | stenosis (n.狭窄) |
| **step** | 步 | step (n.步骤) |
| **ster** | 星/不育 | star (n.星星), sterile (adj.不育的) |
| **stern** | 船尾/严肃 | stern (adj.严厉的) |
| **stew** | 炖 | stew (n.炖菜) |
| **stick** | 刺 | stick (v.粘) |
| **stiff** | 僵硬 | stiff (adj.僵硬的) |
| **still** | 静止 | still (adj.静止的) |
| **stimul** | 刺 | stimulate (v.刺激) |
| **sting** | 刺 | sting (v.刺) |
| **stink** | 臭 | stink (v.发臭) |
| **stint** | 限制 | stint (n.限制) |
| **stip** | 刺 | stipple (v.点画) |
| **stipend** | 工资 | stipend (n.津贴) |
| **stipul** | 规定 | stipulate (v.规定) |
| **stir** | 搅拌 | stir (v.搅拌) |
| **stitch** | 缝 | stitch (n.针脚) |
| **stock** | 库存 | stock (n.库存) |
| **stoic** | 斯多葛 | stoic (n.斯多葛学派) |
| **stoke** | 添煤 | stoke (v.添煤) |
| **stomach** | 胃 | stomach (n.胃) |
| **stone** | 石头 | stone (n.石头) |
| **stoop** | 弯腰 | stoop (v.弯腰) |
| **stop** | 停止 | stop (v.停止) |
| **stor** | 商店 | store (n.商店) |
| **storm** | 风暴 | storm (n.风暴) |
| **story** | 故事/楼层 | story (n.故事) |
| **stout** | 粗壮 | stout (adj.粗壮的) |
| **stow** | 装载 | stow (v.装载) |
| **strag** | 偏离 | straggle (v.掉队) |
| **strain** | 拉紧 | strain (v.拉紧) |
| **strait** | 狭窄 | strait (n.海峡) |
| **strand** | 岸 | strand (n. Strand) |
| **strange** | 奇怪 | strange (adj.奇怪的) |
| **strap** | 带 | strap (n.带子) |
| **strat** | 层 | stratum (n.地层), strategy (n.战略) |
| **straw** | 稻草 | straw (n.稻草) |
| **stray** | 迷路 | stray (v.迷路) |
| **streak** | 条纹 | streak (n.条纹) |
| **stream** | 溪流 | stream (n.溪流) |
| **street** | 街道 | street (n.街道) |
| **strength** | 力量 | strength (n.力量) |
| **stress** | 压力 | stress (n.压力) |
| **stretch** | 伸展 | stretch (v.伸展) |
| **strict** | 拉紧 | strict (adj.严格的) |
| **stride** | 大步 | stride (v.大步走) |
| **strike** | 打击 | strike (v.打击) |
| **string** | 弦 | string (n.弦) |
| **strip** | 剥 | strip (v.剥) |
| **stripe** | 条纹 | stripe (n.条纹) |
| **strive** | 努力 | strive (v.努力) |
| **stroke** | 击打 | stroke (n.中风) |
| **stroll** | 漫步 | stroll (v.漫步) |
| **strong** | 强壮 | strong (adj.强壮的) |
| **struct** | 建造 | structure (n.结构), construct (v.建造) |
| **strugg** | 挣扎 | struggle (v.挣扎) |
| **strut** | 支柱 | strut (n.支柱) |
| **stub** | 树桩 | stub (n.存根) |
| **stud** | 螺柱/学习 | stud (n.螺柱), study (v.学习) |
| **stuff** | 填充 | stuff (n.东西) |
| **stumble** | 绊倒 | stumble (v.绊倒) |
| **stump** | 树桩 | stump (n.树桩) |
| **stun** | 打晕 | stun (v.使昏迷) |
| **stunt** | 特技 | stunt (n.特技) |
| **stup** | 愚蠢/麻木 | stupid (adj.愚蠢的), stupor (n.昏迷) |
| **style** | 风格 | style (n.风格) |
| **suad/suas** | 说服 | persuade (v.说服) |
| **sub** | 在下 | sub (n.替补) |
| **sublim** | 高 | sublime (adj.崇高的) |
| **submiss** | 发送/放下 | submit (v.提交), submissive (adj.顺从的) |
| **substitu** | 放置 | substitute (n.替代品) |
| **subtil** | 精细 | subtle (adj.微妙的) |
| **subtrah** | 拉 | subtract (v.减去) |
| **subvers** | 转 | subvert (v.颠覆) |
| **succ** | 吸 | suck (v.吸) |
| **succed** | 跟随 | succeed (v.成功) |
| **success** | 跟随 | success (n.成功) |
| **succumb** | 屈服 | succumb (v.屈服) |
| **suffer** | 忍受 | suffer (v.遭受) |
| **suffic** | 足够 | suffice (v.足够) |
| **suffix** | 固定 | suffix (n.后缀) |
| **suffoc** | 窒息 | suffocate (v.窒息) |
| **suggest** | 携带 | suggest (v.建议) |
| **suit** | 跟随 | suit (n.西装) |
| **sulfur** | 硫 | sulfur (n.硫) |
| **sultan** | 苏丹 | sultan (n.苏丹) |
| **sum** | 拿 | sum (n.总和) |
| **summar** | 摘要 | summary (n.摘要) |
| **summit** | 顶 | summit (n.峰会) |
| **summon** | 召唤 | summon (v.召唤) |
| **sumpt** | 拿 | sumptuous (adj.豪华的) |
| **sunder** | 分开 | sunder (v.分裂) |
| **super** | 在上 | super (adj.超级的) |
| **superb** | 华丽 | superb (adj.极好的) |
| **superfl** | 流动 | superfluous (adj.多余的) |
| **superv** | 看 | supervise (v.监督) |
| **suppl** | 满/请求 | supply (v.供应), supplicate (v.恳求) |
| **suppos** | 放置 | suppose (v.假设) |
| **suppress** | 压 | suppress (v.压制) |
| **suprem** | 最高 | supreme (adj.最高的) |
| **sur** | 在上 | sur (prep.在...上) |
| **sure** | 确定 | sure (adj.确定的) |
| **surf** | 表面 | surface (n.表面) |
| **surge** | 波浪 | surge (n.汹涌) |
| **surmis** | 发送 | surmise (v.推测) |
| **surmount** | 山 | surmount (v.克服) |
| **surpass** | 步 | surpass (v.超越) |
| **surpl** | 满 | surplus (n.盈余) |
| **surpris** | 抓住 | surprise (n.惊喜) |
| **surrend** | 给予 | surrender (v.投降) |
| **surrog** | 问 | surrogate (n.代理人) |
| **surround** | 圆 | surround (v.包围) |
| **survey** | 看 | survey (v.调查) |
| **surviv** | 活 | survive (v.幸存) |
| **suscept** | 拿 | susceptible (adj.易感的) |
| **suspect** | 看 | suspect (v.怀疑) |
| **suspend** | 悬挂 | suspend (v.暂停) |
| **sustain** | 保持 | sustain (v.维持) |
| **swallow** | 吞 | swallow (v.吞) |
| **swamp** | 沼泽 | swamp (n.沼泽) |
| **swap** | 交换 | swap (v.交换) |
| **swarm** | 群 | swarm (n.群) |
| **sway** | 摇摆 | sway (v.摇摆) |
| **swear** | 发誓 | swear (v.发誓) |
| **sweat** | 汗 | sweat (n.汗) |
| **sweep** | 扫 | sweep (v.扫) |
| **sweet** | 甜 | sweet (adj.甜的) |
| **swell** | 膨胀 | swell (v.膨胀) |
| **swerve** | 转向 | swerve (v.转向) |
| **swift** | 快 | swift (adj.迅速的) |
| **swim** | 游 | swim (v.游泳) |
| **swindle** | 欺骗 | swindle (v.诈骗) |
| **swing** | 摇摆 | swing (v.摇摆) |
| **switch** | 开关 | switch (n.开关) |
| **symbol** | 一起 | symbol (n.符号) |
| **symm** | 对称 | symmetry (n.对称) |
| **sympath** | 感觉 | sympathy (n.同情) |
| **symphon** | 声音 | symphony (n.交响乐) |
| **syn** | 一起 | syn (n. syn) |
| **synchr** | 时间 | synchronize (v.同步) |
| **synod** | 路 | synod (n.宗教会议) |
| **synonym** | 名字 | synonym (n.同义词) |
| **synthes** | 放置 | synthesize (v.合成) |
| **system** | 站立 | system (n.系统) |
| **tab** | 板 | tab (n.标签) |
| **tabl** | 板 | table (n.桌子) |
| **taboo** | 禁忌 | taboo (n.禁忌) |
| **tabul** | 板 | tabulate (v.列表) |
| **tac** | 沉默 | tacit (adj.默许的) |
| **tack** | 钉 | tack (n.图钉) |
| **tact/tang** | 触摸 | tact (n.机智), contact (n.联系), tangible (adj.有形的) |
| **tactic** | 排列 | tactic (n.战术) |
| **tail** | 切 | tail (n.尾巴), tailor (n.裁缝) |
| **tain** | 保持 | retain (v.保留) |
| **taint** | 污染 | taint (v.污染) |
| **talent** | 才能 | talent (n.才能) |
| **tall** | 高 | tall (adj.高的) |
| **tally** | 计数 | tally (v.计数) |
| **tame** | 驯服 | tame (v.驯服) |
| **tang** | 触摸 | tangent (n.切线) |
| **tangl** | 纠缠 | tangle (v.纠缠) |
| **tard** | 慢 | tardy (adj.迟缓的) |
| **task** | 任务 | task (n.任务) |
| **taste** | 味道 | taste (n.味道) |
| **taught** | 教 | taught (v.教) |
| **taunt** | 嘲笑 | taunt (v.嘲笑) |
| **taut** | 拉紧 | taut (adj.拉紧的) |
| **tax** | 税/排列 | tax (n.税), taxonomy (n.分类学) |
| **teach** | 教 | teach (v.教) |
| **team** | 队 | team (n.队) |
| **tear** | 泪/撕裂 | tear (n.眼泪) |
| **tease** | 戏弄 | tease (v.取笑) |
| **techn** | 技术 | technique (n.技巧) |
| **tect** | 覆盖 | protect (v.保护), detect (v.发现) |
| **tedi** | 厌倦 | tedious (adj.乏味的) |
| **teem** | 充满 | teem (v.充满) |
| **tell** | 告诉 | tell (v.告诉) |
| **tellur** | 地球 | tellurium (n.碲) |
| **temer** | 大胆 | temerity (n.鲁莽) |
| **temper** | 混合 | temper (v.调和) |
| **tempest** | 风暴 | tempest (n.暴风雨) |
| **templ** | 寺庙 | temple (n.寺庙) |
| **tempor** | 时间 | temporal (adj.暂时的), temporary (adj.临时的) |
| **tempt** | 尝试 | tempt (v.诱惑) |
| **ten** | 十/保持 | ten (num.十), ten (v.保持) |
| **tenac** | 保持 | tenacious (adj.顽强的) |
| **tend/tens/tent** | 伸展 | tend (v.趋向), extend (v.扩展), tension (n.紧张) |
| **tenebr** | 黑暗 | tenebrous (adj.黑暗的) |
| **tener** | 温柔 | tender (adj.温柔的) |
| **tens** | 伸展 | tense (adj.紧张的) |
| **tent** | 帐篷/伸展 | tent (n.帐篷) |
| **tenu** | 薄 | tenuous (adj.脆弱的) |
| **tenur** | 保持 | tenure (n.任期) |
| **tepid** | 温 | tepid (adj.微温的) |
| **terg** | 背 | tergiversate (v.变节) |
| **term** | 边界 | term (n.术语) |
| **termin** | 边界 | terminate (v.终止) |
| **terr** | 土地/害怕 | terra (n.陆地), terror (n.恐怖) |
| **terrest** | 地球 | terrestrial (adj.陆地的) |
| **territ** | 土地 | territory (n.领土) |
| **terror** | 害怕 | terror (n.恐怖) |
| **ters** | 擦干 | terse (adj.简洁的) |
| **test** | 见证/壳 | test (n.测试), testify (v.作证) |
| **testament** | 见证 | testament (n.遗嘱) |
| **testif** | 见证 | testify (v.作证) |
| **testim** | 见证 | testimony (n.证词) |
| **text** | 编织 | text (n.文本), textile (n.纺织品), context (n.上下文) |
| **thalass** | 海 | thalassic (adj.海的) |
| **thanat** | 死 | thanatosis (n.假死) |
| **thank** | 感谢 | thank (v.感谢) |
| **thaw** | 融化 | thaw (v.融化) |
| **the** | 神 | theology (n.神学) |
| **theatr** | 看 | theatre (n.剧院) |
| **theft** | 偷 | theft (n.盗窃) |
| **theme** | 主题 | theme (n.主题) |
| **theolog** | 神 | theology (n.神学) |
| **theorem** | 看 | theorem (n.定理) |
| **theor** | 看 | theory (n.理论) |
| **ther** | 野兽 | therapy (n.治疗) |
| **therm** | 热 | thermal (adj.热的), thermometer (n.温度计) |
| **thes** | 放置 | thesis (n.论文) |
| **thesaur** | 宝藏 | thesaurus (n.同义词词典) |
| **thesis** | 放置 | thesis (n.论文) |
| **thick** | 厚 | thick (adj.厚的) |
| **thiev** | 偷 | thief (n.小偷) |
| **thin** | 薄 | thin (adj.薄的) |
| **think** | 想 | think (v.想) |
| **thirst** | 渴 | thirst (n.渴) |
| **thorn** | 刺 | thorn (n.刺) |
| **thorough** | 彻底 | thorough (adj.彻底的) |
| **thought** | 想 | thought (n.想法) |
| **thread** | 线 | thread (n.线) |
| **threat** | 威胁 | threat (n.威胁) |
| **thresh** | 打谷 | thresh (v.打谷) |
| **thrift** | 节约 | thrift (n.节约) |
| **thrill** | 颤抖 | thrill (v.使兴奋) |
| **thrive** | 繁荣 | thrive (v.繁荣) |
| **throat** | 喉咙 | throat (n.喉咙) |
| **throb** | 跳动 | throb (v.跳动) |
| **thromb** | 血块 | thrombus (n.血栓) |
| **throne** | 王座 | throne (n.王座) |
| **throng** | 群 | throng (n.人群) |
| **through** | 通过 | through (prep.通过) |
| **throw** | 扔 | throw (v.扔) |
| **thrust** | 刺 | thrust (v.刺) |
| **thumb** | 拇指 | thumb (n.拇指) |
| **thump** | 重击 | thump (v.重击) |
| **thunder** | 雷 | thunder (n.雷) |
| **thwart** | 阻止 | thwart (v.阻止) |
| **tick** | 滴答 | tick (v.发出滴答声) |
| **tickl** | 痒 | tickle (v.使发痒) |
| **tide** | 潮汐 | tide (n.潮汐) |
| **tidy** | 整洁 | tidy (adj.整洁的) |
| **tie** | 绑 | tie (v.绑) |
| **tier** | 层 | tier (n.层) |
| **tim** | 时间/害怕 | time (n.时间), timid (adj.胆小的) |
| **timbr** | 音色 | timbre (n.音色) |
| **tin** | 锡 | tin (n.锡) |
| **tinct** | 染色 | tincture (n.酊剂) |
| **ting** | 发出声音 | ting (n.叮声) |
| **tingl** | 刺痛 | tingle (v.刺痛) |
| **tint** | 颜色 | tint (n.色调) |
| **tiny** | 小 | tiny (adj.微小的) |
| **tip** | 尖端 | tip (n.尖端) |
| **tire** | 疲劳 | tire (v.疲劳) |
| **tissu** | 编织 | tissue (n.组织) |
| **tit** | 小 | tit (n.山雀) |
| **tithe** | 十一 | tithe (n.十一奉献) |
| **titl** | 标题 | title (n.标题) |
| **toad** | 蟾蜍 | toad (n.蟾蜍) |
| **toast** | 烤 | toast (n.吐司) |
| **tobacc** | 烟草 | tobacco (n.烟草) |
| **toe** | 脚趾 | toe (n.脚趾) |
| **tog** | 衣服 | toga (n.托加长袍) |
| **toil** | 辛苦 | toil (v.辛苦工作) |
| **token** | 标记 | token (n.代币) |
| **toler** | 忍受 | tolerate (v.容忍) |
| **toll** | 过路费 | toll (n.通行费) |
| **tom** | 切 | tome (n.大册) |
| **tomb** | 坟墓 | tomb (n.坟墓) |
| **ton** | 吨/声音 | ton (n.吨), tone (n.音调) |
| **tongu** | 舌头 | tongue (n.舌头) |
| **tonsil** | 扁桃体 | tonsil (n.扁桃体) |
| **tool** | 工具 | tool (n.工具) |
| **tooth** | 牙齿 | tooth (n.牙齿) |
| **top** | 顶部/地方 | top (n.顶部), topic (n.主题) |
| **topaz** | 黄玉 | topaz (n.黄玉) |
| **topograph** | 写 | topography (n.地形) |
| **topolog** | 研究 | topology (n.拓扑学) |
| **tor** | 岩石/扭转 | tor (n.岩石), torque (n.扭矩) |
| **torch** | 火炬 | torch (n.火炬) |
| **torment** | 折磨 | torment (v.折磨) |
| **torp** | 麻木 | torpid (adj.麻木的) |
| **torqu** | 扭转 | torque (n.扭矩) |
| **torrent** | 流动 | torrent (n.激流) |
| **torrid** | 热 | torrid (adj.炎热的) |
| **tors** | 扭转 | torsion (n.扭转) |
| **tort** | 扭转 | torture (n.酷刑) |
| **tortu** | 扭转 | tortuous (adj.曲折的) |
| **tortur** | 折磨 | torture (n.酷刑) |
| **toss** | 投掷 | toss (v.投掷) |
| **total** | 全部 | total (adj.全部的) |
| **touch** | 触摸 | touch (v.触摸) |
| **tough** | 坚韧 | tough (adj.坚韧的) |
| **tour** | 旅行 | tour (n.旅行) |
| **tow** | 拖 | tow (v.拖) |
| **towel** | 毛巾 | towel (n.毛巾) |
| **tower** | 塔 | tower (n.塔) |
| **town** | 城镇 | town (n.城镇) |
| **toxic** | 毒 | toxic (adj.有毒的) |
| **tox** | 毒 | toxin (n.毒素) |
| **toy** | 玩具 | toy (n.玩具) |
| **trac/track** | 追踪 | trace (v.追踪), track (n.轨道) |
| **tract** | 拉 | tract (n.道), attract (v.吸引), contract (n.合同) |
| **trade** | 贸易 | trade (n.贸易) |
| **tradit** | 给予 | tradition (n.传统) |
| **traffic** | 交通 | traffic (n.交通) |
| **tragedy** | 山羊 | tragedy (n.悲剧) |
| **trail** | 踪迹 | trail (n.小径) |
| **train** | 拉 | train (n.火车) |
| **trait** | 拉 | trait (n.特征) |
| **tramp** | 踩踏 | tramp (v.踩踏) |
| **tranc** | 越过 | trance (n.出神) |
| **tranquil** | 安静 | tranquil (adj.宁静的) |
| **transact** | 做 | transact (v.交易) |
| **transcend** | 爬 | transcend (v.超越) |
| **transcrib** | 写 | transcribe (v.转录) |
| **transfer** | 携带 | transfer (v.转移) |
| **transform** | 形状 | transform (v.转变) |
| **transfus** | 倒 | transfuse (v.输血) |
| **transgress** | 走 | transgress (v.违反) |
| **transit** | 走 | transit (n.运输) |
| **translat** | 携带 | translate (v.翻译) |
| **transluc** | 光 | translucent (adj.半透明的) |
| **transm** | 送 | transmit (v.传输) |
| **transpar** | 出现 | transparent (adj.透明的) |
| **transpir** | 呼吸 | transpire (v.散发) |
| **transplant** | 种植 | transplant (v.移植) |
| **transport** | 携带 | transport (v.运输) |
| **transpos** | 放置 | transpose (v.调换) |
| **trap** | 陷阱 | trap (n.陷阱) |
| **trash** | 垃圾 | trash (n.垃圾) |
| **trauma** | 创伤 | trauma (n.创伤) |
| **travail** | 痛苦 | travail (n.辛苦) |
| **travel** | 旅行 | travel (v.旅行) |
| **treach** | 背叛 | treachery (n.背叛) |
| **treas** | 宝藏 | treasure (n.财富) |
| **treat** | 对待 | treat (v.对待) |
| **trebl** | 三倍 | treble (n.三倍) |
| **tree** | 树 | tree (n.树) |
| **trek** | 旅行 | trek (n.艰苦旅程) |
| **trell** | 格子 | trellis (n.格架) |
| **trem** | 震动 | tremble (v.颤抖), tremor (n.震颤) |
| **trench** | 切 | trench (n.沟) |
| **trend** | 伸展 | trend (n.趋势) |
| **trepid** | 害怕 | trepidation (n.恐惧) |
| **tres** | 三 | tres (n.三) |
| **tress** | 头发 | tress (n.发束) |
| **trestl** | 支架 | trestle (n.支架) |
| **tri** | 三 | tri (n.三) |
| **trial** | 尝试 | trial (n.审判) |
| **tribe** | 部落 | tribe (n.部落) |
| **tribut** | 给予 | tribute (n.贡品), contribute (v.贡献) |
| **trick** | 诡计 | trick (n.诡计) |
| **trid** | 三 | trident (n.三叉戟) |
| **trienn** | 三年 | triennial (adj.三年一次的) |
| **trifl** | 琐碎 | trifle (n.琐事) |
| **trig** | 三 | trigon (n.三角形) |
| **trigon** | 三角形 | trigon (n.三角形) |
| **trilat** | 边 | trilateral (adj.三边的) |
| **trim** | 三 | trim (v.修剪) |
| **trimestr** | 月 | trimester (n.三个月) |
| **trin** | 三 | trine (adj.三倍的) |
| **trinit** | 三 | trinity (n.三位一体) |
| **trip** | 三 | trip (n.旅行) |
| **tripl** | 三倍 | triple (adj.三倍的) |
| **triangl** | 三角形 | triangle (n.三角形) |
| **trib** | 部落 | tribe (n.部落) |
| **triumph** | 胜利 | triumph (n.胜利) |
| **triv** | 三 | trivial (adj.琐碎的) |
| **troop** | 群 | troop (n.部队) |
| **troph** | 营养 | trophy (n.奖杯) |
| **trop** | 转 | trope (n.比喻) |
| **trot** | 小跑 | trot (v.小跑) |
| **troub** | 搅乱 | trouble (n.麻烦) |
| **trough** | 槽 | trough (n.槽) |
| **trous** | 裤子 | trousers (n.裤子) |
| **truck** | 卡车 | truck (n.卡车) |
| **true** | 真实 | true (adj.真实的) |
| **trump** | 喇叭 | trumpet (n.喇叭) |
| **trunk** | 树干 | trunk (n.树干) |
| **trust** | 信任 | trust (n.信任) |
| **truth** | 真实 | truth (n.真相) |
| **try** | 尝试 | try (v.尝试) |
| **tub** | 桶 | tub (n.桶) |
| **tubercul** | 小肿 | tubercle (n.结节) |
| **tuber** | 块茎 | tuber (n.块茎) |
| **tubul** | 小管 | tubule (n.小管) |
| **tuck** | 塞 | tuck (v.塞) |
| **tuft** | 簇 | tuft (n.簇) |
| **tug** | 拉 | tug (v.拉) |
| **tuition** | 保护 | tuition (n.学费) |
| **tulip** | 郁金香 | tulip (n.郁金香) |
| **tumb** | 肿胀 | tumble (v.跌倒) |
| **tum** | 肿胀 | tumor (n.肿瘤) |
| **tumult** | 骚动 | tumult (n.骚动) |
| **tun** | 桶 | tun (n.大桶) |
| **tund** | 切 | tund (v.切) |
| **tune** | 音调 | tune (n.音调) |
| **tunic** | 束腰外衣 | tunic (n.束腰外衣) |
| **tunnel** | 隧道 | tunnel (n.隧道) |
| **turb** | 搅乱 | turbid (adj.浑浊的), disturb (v.打扰), turbulent (adj.湍流的) |
| **turbin** | 旋转 | turbine (n.涡轮机) |
| **turf** | 草皮 | turf (n.草皮) |
| **turg** | 肿胀 | turgid (adj.肿胀的) |
| **turn** | 转 | turn (v.转) |
| **turp** | 可耻 | turpitude (n.堕落) |
| **turr** | 塔 | turret (n.炮塔) |
| **turtl** | 海龟 | turtle (n.海龟) |
| **tusk** | 象牙 | tusk (n.长牙) |
| **tussl** | 争斗 | tussle (v.争斗) |
| **tut** | 保护 | tutor (n.导师) |
| **tutel** | 保护 | tutelage (n.监护) |
| **tutor** | 教师 | tutor (n.导师) |
| **twain** | 二 | twain (n.二) |
| **twang** | 嗡嗡声 | twang (n.嗡嗡声) |
| **tweak** | 拧 | tweak (v.拧) |
| **tweed** | 粗花呢 | tweed (n.粗花呢) |
| **tweez** | 镊子 | tweezers (n.镊子) |
| **twelv** | 十二 | twelve (num.十二) |
| **twenti** | 二十 | twenty (num.二十) |
| **twice** | 两次 | twice (adv.两次) |
| **twig** | 小枝 | twig (n.小枝) |
| **twilight** | 黄昏 | twilight (n.黄昏) |
| **twill** | 斜纹布 | twill (n.斜纹布) |
| **twin** | 双胞胎 | twin (n.双胞胎) |
| **twine** | 捻 | twine (n.细绳) |
| **twinge** | 剧痛 | twinge (n.剧痛) |
| **twinkl** | 闪烁 | twinkle (v.闪烁) |
| **twirl** | 旋转 | twirl (v.旋转) |
| **twist** | 扭转 | twist (v.扭转) |
| **twitch** | 抽搐 | twitch (v.抽搐) |
| **two** | 二 | two (num.二) |
| **ty** | 类型 | ty (n.类型) |
| **tycoon** | 大亨 | tycoon (n.大亨) |
| **tying** | 绑 | tying (v.绑) |
| **type** | 类型 | type (n.类型) |
| **typh** | 烟 | typhoon (n.台风) |
| **tyrann** | 暴君 | tyrant (n.暴君) |
| **tyre** | 轮胎 | tyre (n.轮胎) |
| **ubiqu** | 到处 | ubiquitous (adj.无处不在的) |
| **udder** | 乳房 | udder (n.乳房) |
| **ugl** | 丑 | ugly (adj.丑的) |
| **ulcer** | 溃疡 | ulcer (n.溃疡) |
| **ulna** | 尺骨 | ulna (n.尺骨) |
| **ultim** | 最后 | ultimate (adj.最终的) |
| **ultr** | 极端 | ultra (adj.极端的) |
| **umbilic** | 脐 | umbilical (adj.脐带的) |
| **umbr** | 阴影 | umbrella (n.雨伞), umbrage (n.不快) |
| **umpir** | 裁判 | umpire (n.裁判) |
| **un** | 一 | union (n.联盟), unite (v.团结) |
| **unct** | 油膏 | unctuous (adj.油腻的) |
| **und** | 波浪 | undulate (v.波动) |
| **under** | 在下 | under (prep.在...下) |
| **undul** | 波浪 | undulate (v.波动) |
| **unemploy** | 就业 | unemployed (adj.失业的) |
| **unexpect** | 期望 | unexpected (adj.意外的) |
| **unfortun** | 运气 | unfortunate (adj.不幸的) |
| **unif** | 一 | uniform (n.制服) |
| **uniqu** | 唯一 | unique (adj.独特的) |
| **unit** | 一 | unit (n.单位) |
| **univers** | 转 | universe (n.宇宙) |
| **unk** | 未知 | unknown (adj.未知的) |
| **unl** | 不 | unless (conj.除非) |
| **unmov** | 移动 | immovable (adj.不可移动的) |
| **unn** | 年 | annual (adj.每年的) |
| **unpleas** | 高兴 | unpleasant (adj.令人不快的) |
| **unsuccess** | 跟随 | unsuccessful (adj.不成功的) |
| **unsure** | 确定 | unsure (adj.不确定的) |
| **unt** | 不 | until (conj.直到) |
| **unus** | 一 | unusual (adj.不寻常的) |
| **unusu** | 通常 | unusual (adj.不寻常的) |
| **up** | 向上 | up (adv.向上) |
| **upbraid** | 责骂 | upbraid (v.责骂) |
| **upcom** | 来 | upcoming (adj.即将到来的) |
| **upd** | 向上 | update (v.更新) |
| **upgrad** | 等级 | upgrade (v.升级) |
| **uphold** | 保持 | uphold (v.支持) |
| **uplift** | 举起 | uplift (v.提升) |
| **upmost** | 最上 | uppermost (adj.最上面的) |
| **uppers** | 在上 | upper (adj.上面的) |
| **upright** | 直 | upright (adj.直立的) |
| **uproar** | 喧闹 | uproar (n.喧嚣) |
| **uproot** | 根 | uproot (v.连根拔起) |
| **upset** | 放置 | upset (v.打翻) |
| **upshot** | 射击 | upshot (n.结果) |
| **upside** | 边 | upside (n.上面) |
| **upstair** | 楼梯 | upstairs (adv.在楼上) |
| **upstand** | 站立 | understand (v.理解) |
| **upstart** | 开始 | upstart (n.暴发户) |
| **upstat** | 状态 | upstate (adj.北部的) |
| **upstream** | 溪流 | upstream (adv.向上游) |
| **upstrok** | 击打 | upstroke (n.上冲程) |
| **upsurg** | 波浪 | upsurge (n.高涨) |
| **upswing** | 摇摆 | upswing (n.上升) |
| **uptak** | 拿 | uptake (n.吸收) |
| **upthrust** | 刺 | upthrust (v.向上推) |
| **uptown** | 城镇 | uptown (adj.市区的) |
| **upturn** | 转 | upturn (v.向上翻转) |
| **upward** | 向 | upward (adv.向上) |
| **urb** | 城市 | urban (adj.城市的), suburb (n.郊区) |
| **urg** | 工作 | urge (v.敦促) |
| **urin** | 尿 | urine (n.尿) |
| **urn** | 瓮 | urn (n.瓮) |
| **us** | 我们 | us (pron.我们) |
| **usabl** | 使用 | usable (adj.可用的) |
| **usag** | 使用 | usage (n.使用) |
| **use** | 使用 | use (v.使用) |
| **ush** | 推动 | usher (v.引导) |
| **usurp** | 篡夺 | usurp (v.篡夺) |
| **utens** | 使用 | utensil (n.器具) |
| **uter** | 子宫 | uterus (n.子宫) |
| **util** | 使用 | utility (n.效用) |
| **utmost** | 最 | utmost (adj.极度的) |
| **utopi** | 乌托邦 | utopia (n.乌托邦) |
| **utter** | 完全 | utter (v.说出) |
| **uvul** | 小舌 | uvula (n.小舌) |
| **vac/van** | 空 | vacant (adj.空缺的), vanish (v.消失), vanity (n.虚荣) |
| **vacill** | 摇摆 | vacillate (v.摇摆) |
| **vacu** | 空 | vacuum (n.真空) |
| **vad/vas** | 走，进 | invade (v.入侵), evade (v.逃避) |
| **vag** | 漫游 | vague (adj.模糊的) |
| **vagr** | 漫游 | vagrant (n.流浪者) |
| **vail** | 价值 | avail (v.利用) |
| **val** | 强壮，价值 | value (n.价值), valid (adj.有效的), evaluate (v.评估) |
| **valenc** | 强壮 | valence (n.价) |
| **valet** | 仆人 | valet (n.男仆) |
| **vali** | 强壮 | valid (adj.有效的) |
| **valor** | 勇气 | valor (n.勇气) |
| **valu** | 价值 | value (n.价值) |
| **valv** | 门 | valve (n.阀门) |
| **vamp** | 吸血鬼 | vampire (n.吸血鬼) |
| **van** | 空 | vanish (v.消失) |
| **vand** | 破坏 | vandal (n.故意破坏者) |
| **vanish** | 消失 | vanish (v.消失) |
| **vanit** | 虚荣 | vanity (n.虚荣) |
| **vap** | 蒸汽 | vapor (n.蒸汽) |
| **vari** | 变化 | vary (v.变化), variable (adj.可变的) |
| **varnish** | 清漆 | varnish (n.清漆) |
| **vary** | 变化 | vary (v.变化) |
| **vas** | 血管 | vascular (adj.血管的) |
| **vasc** | 船 | vessel (n.船) |
| **vast** | 巨大 | vast (adj.巨大的) |
| **vat** | 桶 | vat (n.大桶) |
| **vault** | 拱顶 | vault (n.拱顶) |
| **vaunt** | 吹嘘 | vaunt (v.吹嘘) |
| **veal** | 小牛 | veal (n.小牛肉) |
| **vect** | 携带 | vector (n.向量) |
| **veg** | 生长 | vegetate (v.生长) |
| **veh** | 携带 | vehicle (n.车辆) |
| **veil** | 面纱 | veil (n.面纱) |
| **vein** | 血管 | vein (n.血管) |
| **vel** | 快速 | velocity (n.速度) |
| **veloc** | 快速 | velocity (n.速度) |
| **velv** | 天鹅绒 | velvet (n.天鹅绒) |
| **ven/vent** | 来 | venture (n.冒险), convene (v.召集), prevent (v.预防) |
| **vend** | 卖 | vend (v.出售) |
| **venen** | 毒 | venom (n.毒液) |
| **vener** | 尊敬 | venerate (v.尊敬) |
| **venge** | 复仇 | vengeance (n.复仇) |
| **venom** | 毒 | venom (n.毒液) |
| **vent** | 风 | vent (n.通风口) |
| **ventur** | 来 | venture (n.冒险) |
| **venu** | 来 | venue (n.场地) |
| **verb** | 词，字 | verbal (adj.口头的), verb (n.动词) |
| **ver** | 真实 | verify (v.核实), verdict (n.裁决) |
| **verbos** | 话多 | verbose (adj.冗长的) |
| **verd** | 绿 | verdant (adj.翠绿的) |
| **verdict** | 说 | verdict (n.裁决) |
| **verg** | 倾斜 | verge (n.边缘) |
| **verif** | 真实 | verify (v.核实) |
| **verit** | 真实 | verity (n.真实) |
| **verm** | 虫 | vermin (n.害虫) |
| **vern** | 春 | vernal (adj.春天的) |
| **vers/vert** | 转 | convert (v.转换), reverse (v.逆转) |
| **vertebr** | 脊椎 | vertebrate (n.脊椎动物) |
| **vertex** | 顶 | vertex (n.顶点) |
| **vertic** | 顶 | vertical (adj.垂直的) |
| **very** | 真实 | very (adv.非常) |
| **vesic** | 泡 | vesicle (n.小泡) |
| **vesp** | 晚上 | vespers (n.晚祷) |
| **vess** | 船 | vessel (n.船) |
| **vest** | 衣服，投资 | vest (n.背心), invest (v.投资) |
| **vestib** | 入口 | vestibule (n.前厅) |
| **vestr** | 西 | vesture (n.衣服) |
| **vet** | 老 | veteran (n.老兵) |
| **veter** | 老 | veteran (n.老兵) |
| **veto** | 否决 | veto (v.否决) |
| **vex** | 烦恼 | vex (v.使烦恼) |
| **vi/via** | 路 | via (prep.通过), viable (adj.可行的) |
| **viabl** | 活 | viable (adj.可行的) |
| **viand** | 食物 | viand (n.食物) |
| **vibr** | 震动 | vibrate (v.振动) |
| **vic** | 代替 | vicar (n.教区牧师), vicinity (n.附近) |
| **vict** | 征服 | victor (n.胜利者) |
| **victual** | 食物 | victual (n.食物) |
| **vid/vis** | 看 | video (n.视频), vision (n.视力), visible (adj.可见的) |
| **vide** | 看 | video (n.视频) |
| **vidu** | 分开 | widow (n.寡妇) |
| **vie** | 竞争 | vie (v.竞争) |
| **view** | 看 | view (v.看) |
| **vigil** | 清醒 | vigilant (adj.警惕的) |
| **vigor** | 活力 | vigor (n.活力) |
| **vile** | 卑鄙 | vile (adj.卑鄙的) |
| **vill** | 村庄 | village (n.村庄) |
| **villain** | 恶棍 | villain (n.恶棍) |
| **vim** | 活力 | vim (n.活力) |
| **vinc** | 征服 | convince (v.说服) |
| **vind** | 声称 | vindicate (v.辩护) |
| **vine** | 葡萄藤 | vine (n.葡萄藤) |
| **vin** | 酒 | vine (n.葡萄藤), vintage (n. vintage) |
| **viol** | 暴力 | violate (v.违反) |
| **vir** | 毒/男人 | virus (n.病毒), virile (adj.有男子气概的) |
| **virg** | 少女 | virgin (n.处女) |
| **virt** | 力量 | virtue (n.美德) |
| **vis** | 看 | visit (v.访问) |
| **visc** | 内脏 | visceral (adj.内脏的) |
| **viscount** | 子爵 | viscount (n.子爵) |
| **visibl** | 看 | visible (adj.可见的) |
| **visit** | 看 | visit (v.访问) |
| **visor** | 面罩 | visor (n.面罩) |
| **vist** | 看 | vista (n.景色) |
| **vit/viv** | 生命 | vital (adj.至关重要的), vivid (adj.生动的), survive (v.幸存) |
| **vit** | 生命 | vital (adj.至关重要的) |
| **vitam** | 生命 | vitamin (n.维生素) |
| **vitiat** | 腐败 | vitiate (v.损害) |
| **vitr** | 玻璃 | vitreous (adj.玻璃状的) |
| **vitri** | 硫酸 | vitriol (n.硫酸) |
| **vittl** | 食物 | victuals (n.食物) |
| **viv** | 活 | vivid (adj.生动的), survive (v.幸存) |
| **vivac** | 活泼 | vivacious (adj.活泼的) |
| **vivipar** | 胎生 | viviparous (adj.胎生的) |
| **vix** | 母狐 | vixen (n.母狐) |
| **vocab** | 呼叫 | vocabulary (n.词汇) |
| **vocal** | 声音 | vocal (adj.嗓音的) |
| **voc/vok** | 声音，呼叫 | voice (n.声音), vocal (adj.嗓音的), evoke (v.唤起) |
| **vocat** | 呼叫 | vocation (n.职业) |
| **vocifer** | 呼喊 | vociferate (v.大叫) |
| **void** | 空 | void (adj.空的) |
| **vol** | 意志，意愿 | will (v.将), voluntary (adj.自愿的) |
| **volatil** | 飞 | volatile (adj.易挥发的) |
| **volcan** | 火山 | volcano (n.火山) |
| **volunt** | 意志 | voluntary (adj.自愿的) |
| **volv/volut** | 滚动，转动 | revolve (v.旋转), evolve (v.进化) |
| **volt** | 转 | volt (n.伏特) |
| **volub** | 转 | voluble (adj.健谈的) |
| **volum** | 滚动 | volume (n.体积) |
| **volupt** | 快乐 | voluptuous (adj. luxuri ous) |
| **vomit** | 呕吐 | vomit (v.呕吐) |
| **vor** | 吃 | voracious (adj.贪婪的) |
| **vort** | 转 | vortex (n.漩涡) |
| **vot** | 发誓 | vote (v.投票) |
| **vouch** | 保证 | vouch (v.保证) |
| **vow** | 发誓 | vow (n.誓言) |
| **vowel** | 元音 | vowel (n.元音) |
| **vulcan** | 火神 | vulcan (n.火神) |
| **vulg** | 普通 | vulgar (adj.粗俗的) |
| **vulner** | 伤 | vulnerable (adj.脆弱的) |
| **vulpin** | 狐狸 | vulpine (adj.狐狸的) |
| **vultur** | 秃鹰 | vulture (n.秃鹰) |
| **vying** | 竞争 | vying (v.竞争) |

### 补充词根

#### 常见基础词根补充

| 词根 | 含义 | 例词 |
|------|------|------|
| **ac/acr** | 尖，酸，苦 | acid (n.酸), acute (adj.尖锐的), acrimony (n.刻薄), acrobat (n.杂技演员) |
| **acu** | 尖，敏锐 | acupuncture (n.针灸), acumen (n.敏锐), acute (adj.急性的) |
| **ag/act** | 做，驱动 | agent (n.代理人), agenda (n.议程), agile (adj.敏捷的), actuate (v.驱动) |
| **am** | 爱 | amiable (adj.和蔼的), amorous (adj.多情的), enamor (v.使迷恋) |
| **ambul** | 走 | ambulance (n.救护车), ambulatory (adj.流动的), perambulate (v.漫步) |
| **andri** | 男人 | android (n.机器人), polyandry (n.一妻多夫), androgen (n.雄激素) |
| **anim** | 精神，生命，心灵 | animal (n.动物), animate (v.使有生气), unanimous (adj.一致的), equanimity (n.平静) |
| **ann/enn** | 年 | annual (adj.每年的), anniversary (n.周年纪念日), perennial (adj.永久的), annuity (n.年金) |
| **anthrop** | 人，人类 | anthropology (n.人类学), philanthropy (n.慈善), misanthrope (n.厌世者) |
| **apex** | 顶点 | apex (n.顶点), apical (adj.顶端的) |
| **aqu** | 水 | aquatic (adj.水生的), aquarium (n.水族馆), aqueduct (n.渡槽), aqueous (adj.水的) |
| **arachn** | 蜘蛛 | arachnid (n.蛛形纲动物), arachnophobia (n.蜘蛛恐惧症) |
| **arbitr** | 判断 | arbitrary (adj.任意的), arbitrator (n.仲裁者), arbitrate (v.仲裁) |
| **arc** | 弓，弧 | arc (n.弧), arch (n.拱门), archer (n.弓箭手), arcade (n.拱廊) |
| **archae** | 古代，原始 | archaeology (n.考古学), archaic (adj.古老的), archetype (n.原型) |
| **arm** | 武器，手臂 | arm (n.手臂), armor (n.盔甲), armistice (n.停战), disarm (v.解除武装) |
| **arteri** | 动脉 | artery (n.动脉), arterial (adj.动脉的), arteriosclerosis (n.动脉硬化) |
| **artic** | 关节 | articulate (v.清晰表达), arthritis (n.关节炎), articular (adj.关节的) |
| **asthen** | 弱 | asthenia (n.虚弱), asthenosphere (n.软流层), neurasthenia (n.神经衰弱) |
| **astr/aster** | 星 | astronomy (n.天文学), asteroid (n.小行星), disaster (n.灾难), asterisk (n.星号) |
| **ather** | 粥状物 | atherosclerosis (n.动脉硬化), atheroma (n.动脉粥样硬化) |
| **athl** | 竞赛 | athlete (n.运动员), athletic (adj.运动的), decathlon (n.十项全能) |
| **atm** | 蒸汽，空气 | atmosphere (n.大气), atmospheric (adj.大气的) |
| **atri** | 入口，心房 | atrium (n.心房), atrial (adj.心房的) |
| **audi** | 听 | audio (n.音频), audience (n.观众), audit (v.审计), audible (adj.可听见的) |
| **aug** | 增加，增大 | augment (v.增加), augmentation (n.增加), augur (n.占卜者) |
| **aur** | 耳 | auricle (n.耳廓), aural (adj.耳的), auricular (adj.耳的) |
| **ausp** | 鸟（占卜） | auspicious (adj.吉祥的), auspices (n.赞助) |
| **aut** | 自己 | auto (n.汽车), autonomous (adj.自治的), autobiography (n.自传), autopsy (n.尸检) |
| **axi** | 轴，价值 | axis (n.轴), axial (adj.轴的), axiom (n.公理), axiomatic (adj.不言自明的) |

#### 补充人体相关词根

| 词根 | 含义 | 例词 |
|------|------|------|
| **blephar** | 眼睑 | blepharitis (n.睑缘炎) |
| **bronch** | 气管 | bronchitis (n.支气管炎), bronchus (n.支气管) |
| **carp** | 腕 | carpal (n.腕骨) |
| **caul** | 膜 | caul (n.胎膜) |
| **celi** | 腹 | celiac (adj.腹的) |
| **cheil** | 唇 | cheilitis (n.唇炎) |
| **chir** | 手 | chiropody (n.足病学) |
| **cholecyst** | 胆囊 | cholecystitis (n.胆囊炎) |
| **chondr** | 软骨 | chondritis (n.软骨炎) |
| **col** | 结肠 | colitis (n.结肠炎) |
| **cost** | 肋 | costal (adj.肋的) |
| **crani** | 颅 | cranium (n.颅骨), cranial (adj.颅的) |
| **cyst** | 囊，膀胱 | cyst (n.囊), cystitis (n.膀胱炎) |
| **duoden** | 十二指肠 | duodenum (n.十二指肠) |
| **encephal** | 脑 | encephalitis (n.脑炎), encephalopathy (n.脑病) |
| **esophag** | 食管 | esophagus (n.食管) |
| **gingiv** | 牙龈 | gingivitis (n.牙龈炎) |
| **gloss** | 舌 | glossitis (n.舌炎), glossary (n.词汇表) |
| **glott** | 声门 | glottis (n.声门) |
| **hyster** | 子宫 | hysteria (n.癔症) |
| **irid** | 虹膜 | iritis (n.虹膜炎) |
| **isch** | 髋 | ischium (n.坐骨) |
| **labi** | 唇 | labial (adj.唇的) |
| **laryng** | 喉 | laryngitis (n.喉炎), larynx (n.喉) |
| **leuk** | 白 | leukemia (n.白血病), leukocyte (n.白细胞) |
| **lip** | 脂 | lipid (n.脂质), liposuction (n.吸脂术) |
| **myel** | 骨髓，脊髓 | myelitis (n.脊髓炎) |
| **myring** | 鼓膜 | myringitis (n.鼓膜炎) |
| **omphal** | 脐 | omphalitis (n.脐炎) |
| **onych** | 甲 | onychomycosis (n.甲癣) |
| **oophor** | 卵巢 | oophoritis (n.卵巢炎) |
| **orchid** | 睾丸 | orchiditis (n.睾丸炎) |
| **palat** | 腭 | palatitis (n.腭炎) |
| **pancreat** | 胰腺 | pancreatitis (n.胰腺炎) |
| **parotid** | 腮腺 | parotitis (n.腮腺炎) |
| **pharyng** | 咽 | pharyngitis (n.咽炎) |
| **pleur** | 胸膜 | pleurisy (n.胸膜炎) |
| **proct** | 肛门 | proctitis (n.直肠炎) |
| **pyel** | 肾盂 | pyelitis (n.肾盂炎) |
| **pylor** | 幽门 | pylorus (n.幽门) |
| **retin** | 视网膜 | retinitis (n.视网膜炎) |
| **salping** | 输卵管 | salpingitis (n.输卵管炎) |
| **scler** | 硬 | sclerosis (n.硬化), sclera (n.巩膜) |
| **scrot** | 阴囊 | scrotum (n.阴囊) |
| **splen** | 脾 | splenitis (n.脾炎) |
| **stern** | 胸骨 | sternum (n.胸骨) |
| **thym** | 胸腺 | thymus (n.胸腺) |
| **tonsill** | 扁桃体 | tonsillitis (n.扁桃体炎) |
| **trache** | 气管 | trachea (n.气管) |
| **tympan** | 鼓室 | tympanitis (n.鼓室炎) |
| **urethr** | 尿道 | urethritis (n.尿道炎) |
| **urin** | 尿 | urine (n.尿), urinary (adj.尿的) |
| **uter** | 子宫 | uterus (n.子宫) |
| **vagin** | 阴道 | vaginitis (n.阴道炎) |
| **vas** | 血管，管 | vascular (adj.血管的), vas deferens (n.输精管) |

#### 补充自然元素词根

| 词根 | 含义 | 例词 |
|------|------|------|
| **alb** | 白 | albino (n.白化病), album (n.相册) |
| **chlor** | 绿 | chlorine (n.氯), chlorophyll (n.叶绿素) |
| **chrom** | 颜色 | chromosome (n.染色体), monochrome (n.单色) |
| **crystall** | 水晶 | crystal (n.水晶), crystallize (v.结晶) |
| **ferr** | 铁 | ferrous (adj.含铁的), ferrite (n.铁氧体) |
| **fulmin** | 雷 | fulminate (v.爆发) |
| **galact** | 乳 | galaxy (n.银河), galactic (adj.银河的) |
| **hal** | 盐 | halogen (n.卤素) |
| **hygr** | 湿 | hygrometer (n.湿度计) |
| **limn** | 湖 | limnology (n.湖沼学) |
| **magnet** | 磁 | magnet (n.磁铁), magnetic (adj.磁的) |
| **necr** | 死 | necrosis (n.坏死), necromancy (n.通灵术) |
| **nitro** | 氮 | nitrogen (n.氮), nitrate (n.硝酸盐) |
| **osm** | 气味 | osmosis (n.渗透), osmotic (adj.渗透的) |
| **platin** | 铂 | platinum (n.铂) |
| **rhod** | 玫瑰红 | rhododendron (n.杜鹃花) |
| **rubr** | 红 | rubric (n.红字) |
| **sider** | 星，铁 | sidereal (adj.恒星的), siderite (n.菱铁矿) |
| **silic** | 硅 | silica (n.二氧化硅), silicone (n.硅酮) |
| **stell** | 星 | stellar (adj.恒星的), constellation (n.星座) |
| **titan** | 钛 | titanium (n.钛) |
| **tungst** | 钨 | tungsten (n.钨) |
| **uran** | 铀，天 | uranium (n.铀), uranus (n.天王星) |
| **vanad** | 钒 | vanadium (n.钒) |
| **xanth** | 黄 | xanthophyll (n.叶黄素) |
| **zinc** | 锌 | zinc (n.锌) |

#### 补充抽象概念词根

| 词根 | 含义 | 例词 |
|------|------|------|
| **adequ** | 平等 | adequate (adj.足够的), inadequate (adj.不足的) |
| **adip** | 脂肪 | adipose (adj.脂肪的) |
| **aesthet** | 感觉 | aesthetic (adj.美学的), anesthesia (n.麻醉) |
| **affabl** | 说话 | affable (adj.和蔼的) |
| **aggreg** | 聚集 | aggregate (v.聚集), aggregation (n.集合) |
| **alacr** | 迅速 | alacrity (n.敏捷) |
| **alien** | 外国的 | alien (n.外国人), alienate (v.疏远) |
| **alleg** | 声称 | allege (v.声称), allegation (n.指控) |
| **allur** | 引诱 | allure (v.引诱), alluring (adj.诱人的) |
| **alter** | 其他 | alter (v.改变), alternate (adj.交替的) |
| **alt** | 高 | altitude (n.高度), altimeter (n.高度计) |
| **ambig** | 说 | ambiguous (adj.模棱两可的) |
| **amic** | 朋友 | amicable (adj.友好的) |
| **ampl** | 大 | ample (adj.充足的), amplify (v.放大) |
| **anachron** | 时间 | anachronism (n.时代错误) |
| **anal** | 比例 | analogy (n.类比), analyze (v.分析) |
| **anch** | 锚 | anchor (n.锚) |
| **ang** | 狭窄，焦虑 | angle (n.角), anxiety (n.焦虑), anguish (n.痛苦) |
| **anomal** | 不规则 | anomaly (n.异常) |
| **antagon** | 竞争 | antagonist (n.对手), antagonize (v.敌对) |
| **antiqu** | 古代 | antique (n.古董), antiquity (n.古代) |
| **apath** | 感觉 | apathy (n.冷漠), apathetic (adj.冷漠的) |
| **apolog** | 说 | apologize (v.道歉), apology (n.道歉) |
| **appar** | 出现 | appear (v.出现), apparent (adj.明显的) |
| **applic** | 折叠 | apply (v.申请), application (n.申请) |
| **apprehend** | 抓 | apprehend (v.逮捕), apprehension (n.理解) |
| **approxim** | 接近 | approximate (adj.大约的) |
| **arbitr** | 判断 | arbitrate (v.仲裁), arbitrary (adj.任意的) |
| **ard** | 燃烧 | ardent (adj.热情的) |
| **argent** | 银 | argentine (adj.银的) |
| **argu** | 证明 | argue (v.争论), argument (n.论据) |
| **arist** | 最好 | aristocrat (n.贵族) |
| **arithm** | 数 | arithmetic (n.算术) |
| **ascend** | 爬 | ascend (v.上升) |
| **ascrib** | 写 | ascribe (v.归因于) |
| **aspir** | 呼吸 | aspire (v.渴望), aspiration (n.抱负) |
| **assert** | 声称 | assert (v.断言) |
| **assess** | 坐 | assess (v.评估) |
| **assign** | 标记 | assign (v.分配) |
| **assimil** | 相似 | assimilate (v.同化) |
| **assist** | 站立 | assist (v.协助) |
| **associ** | 同伴 | associate (v.联想) |
| **assuag** | 缓和 | assuage (v.缓和) |
| **assum** | 拿 | assume (v.假设) |
| **assur** | 确定 | assure (v.保证) |
| **asthm** | 喘 | asthma (n.哮喘) |
| **asyl** | 庇护 | asylum (n.庇护所) |
| **atav** | 祖先 | atavism (n.返祖现象) |
| **atom** | 不可分割 | atom (n.原子), atomic (adj.原子的) |
| **attach** | 系 | attach (v.系) |
| **attain** | 达到 | attain (v.达到) |
| **attempt** | 尝试 | attempt (v.尝试) |
| **attend** | 伸展 | attend (v.参加) |
| **attent** | 伸展 | attention (n.注意) |
| **attest** | 见证 | attest (v.证明) |
| **attir** | 装备 | attire (n.服装) |
| **attribut** | 给予 | attribute (v.归因) |
| **attrit** | 摩擦 | attrition (n.磨损) |
| **audac** | 大胆 | audacious (adj.大胆的) |
| **augur** | 占卜 | augur (n.占卜者) |
| **auster** | 南 | austere (adj.严峻的) |
| **auth** | 作者 | author (n.作者), authority (n.权威) |
| **auxil** | 帮助 | auxiliary (adj.辅助的) |
| **avail** | 价值 | avail (v.利用) |
| **avar** | 贪婪 | avarice (n.贪婪) |
| **aveng** | 复仇 | avenge (v.报仇) |
| **avers** | 转 | avert (v.避免) |
| **avid** | 渴望 | avid (adj.渴望的) |
| **avoid** | 空 | avoid (v.避免) |
| **avow** | 说 | avow (v.声明) |
| **await** | 等待 | await (v.等待) |
| **awak** | 唤醒 | awake (v.醒来) |
| **award** | 给予 | award (n.奖励) |
| **aware** | 知道 | aware (adj.意识到的) |
| **awry** | 扭曲 | awry (adj.扭曲的) |
| **azur** | 蓝 | azure (n.天蓝色) |

---

## 学习技巧

### 1. 词根词缀记忆法
- 将单词拆解为：**前缀 + 词根 + 后缀**
- 例如：**unpredictable** = un-(不) + pre-(前) + dict(说) + -able(能...的) = 无法预测的

### 2. 常见组合
| 组合 | 含义 | 例词 |
|------|------|------|
| **re- + -ion** | 再次...的行为 | reunion (n.重聚), revision (n.修订) |
| **in- + -tion** | 进入...状态 | information (n.信息), invitation (n.邀请) |
| **ex- + -ion** | 出去...的行为 | expansion (n.扩张), expression (n.表达) |

### 3. 同根词族
以 **spect**(看) 为例：
- inspect (v.检查), respect (v.尊重), suspect (v.怀疑)
- spectator (n.观众), spectacle (n.景象), perspective (n.视角)

以 **port**(携带) 为例：
- **基础词**: port (n.港口), portable (adj.便携的)
- **带前缀**: transport (v.运输), import (v.进口), export (v.出口)
- **其他派生**: porter (n.搬运工), portfolio (n.文件夹), portal (n.入口)

---

## 参考资源

- **词根词典**: Etymonline.com
- **词汇书籍**: 《Word Power Made Easy》
- **学习方法**: 通过阅读积累，结合上下文理解

---

*文档创建日期：2026 年 4 月 20 日*
