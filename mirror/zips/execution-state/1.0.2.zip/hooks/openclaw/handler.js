/**
 * Execution-State Hook for OpenClaw
 *
 * Injects a recovery reminder during agent bootstrap when there is an
 * unfinished execution state in runtime/execution-state/current.json.
 */

const fs = require('fs');
const path = require('path');

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || process.cwd();
const CURRENT_FILE = path.join(WORKSPACE, 'runtime', 'execution-state', 'current.json');

function loadCurrentState() {
  try {
    const raw = fs.readFileSync(CURRENT_FILE, 'utf8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function shouldRemind(state) {
  if (!state || typeof state !== 'object') return false;
  const status = state.status || 'idle';
  return !['idle', 'completed', 'abandoned', ''].includes(status);
}

function buildReminder(state) {
  const lines = [
    '## Execution-State Recovery Reminder',
    '',
    '检测到存在一个未收口的执行态任务。开始新一轮回复前，优先判断是否需要恢复它。',
    '',
    `- 状态：${state.status || 'unknown'}`,
    `- 进入时间：${state.entered_at || ''}`,
    `- 最近进展时间：${state.last_progress_at || ''}`,
    `- 最近进展：${state.last_progress_summary || ''}`,
    `- 承载方式：${state.executor_mode || 'main'}`,
  ];

  if (state.trigger_phrase) lines.push(`- 触发语句：${state.trigger_phrase}`);
  if (state.subagent_id) lines.push(`- 子代理：${state.subagent_id}`);
  if (state.blocker) lines.push(`- Blocker：${state.blocker}`);

  lines.push('', '### 恢复规则', '', '- 如果任务仍应继续：优先恢复执行，不要重新从空白开始。', '- 如果任务已经结束但未收口：先补完成回执，再清理状态。', '- 如果当前必须等待用户：明确切到 waiting-user，不要假装继续执行。');

  return lines.join('\n');
}

const handler = async (event) => {
  if (!event || typeof event !== 'object') return;
  if (event.type !== 'agent' || event.action !== 'bootstrap') return;
  if (!event.context || typeof event.context !== 'object') return;
  if (!Array.isArray(event.context.bootstrapFiles)) return;

  const state = loadCurrentState();
  if (!shouldRemind(state)) return;

  event.context.bootstrapFiles.push({
    path: 'EXECUTION_STATE_REMINDER.md',
    content: buildReminder(state),
    virtual: true,
  });
};

module.exports = handler;
module.exports.default = handler;
