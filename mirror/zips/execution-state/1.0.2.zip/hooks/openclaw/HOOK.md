---
name: execution-state
description: "Injects an execution-state recovery reminder during agent bootstrap when an unfinished task exists"
---

# execution-state Hook

## 作用

当 `runtime/execution-state/current.json` 中存在未收口执行态（例如 `executing` / `blocked` / `waiting-user`）时，
在 `agent:bootstrap` 阶段注入一个虚拟提醒文件 `EXECUTION_STATE_REMINDER.md`，提醒代理优先判断是否需要恢复该任务。

## 安装方式

将本目录复制到：

```bash
~/.openclaw/hooks/execution-state/
```

然后启用：

```bash
openclaw hooks enable execution-state
```

## 设计原则

- 只做轻提醒，不直接改写任务状态
- 不替代 memory 系统
- 不替代 longtask-reporting
- 目标是让“未收口执行态”在新一轮会话开始时更容易被恢复，而不是再次被遗忘
