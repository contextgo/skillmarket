#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || path.resolve(__dirname, '..', '..', '..');
const RUNTIME_DIR = path.join(WORKSPACE, 'runtime', 'execution-state');
const REPORT_DIR = path.join(RUNTIME_DIR, 'reports');
const ARCHIVE_BASE = path.join(RUNTIME_DIR, 'archive', 'reports');

function parseArgs(argv) {
  const opts = {
    hours: 24,
    dryRun: true,
    verbose: false,
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--apply') opts.dryRun = false;
    else if (arg === '--dry-run') opts.dryRun = true;
    else if (arg === '--verbose') opts.verbose = true;
    else if (arg === '--hours') {
      const v = Number(argv[i + 1]);
      if (Number.isFinite(v) && v > 0) opts.hours = v;
      i += 1;
    }
  }
  return opts;
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function isoDateFromFile(name) {
  const m = name.match(/^(\d{4}-\d{2}-\d{2})T/);
  return m ? m[1] : 'unknown-date';
}

function ageHours(stat) {
  return (Date.now() - stat.mtimeMs) / 3600000;
}

function listCandidates(hours) {
  if (!fs.existsSync(REPORT_DIR)) return [];
  return fs.readdirSync(REPORT_DIR)
    .filter((name) => name.endsWith('.json'))
    .map((name) => {
      const fullPath = path.join(REPORT_DIR, name);
      const stat = fs.statSync(fullPath);
      return {
        name,
        fullPath,
        stat,
        ageHours: ageHours(stat),
        date: isoDateFromFile(name),
      };
    })
    .filter((item) => item.ageHours > hours)
    .sort((a, b) => a.stat.mtimeMs - b.stat.mtimeMs);
}

function moveFile(file, dryRun) {
  const targetDir = path.join(ARCHIVE_BASE, file.date);
  const targetPath = path.join(targetDir, file.name);
  if (!dryRun) {
    ensureDir(targetDir);
    fs.renameSync(file.fullPath, targetPath);
  }
  return targetPath;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const candidates = listCandidates(opts.hours);
  const moved = [];

  for (const file of candidates) {
    const targetPath = moveFile(file, opts.dryRun);
    moved.push({
      file: file.name,
      from: file.fullPath,
      to: targetPath,
      ageHours: Number(file.ageHours.toFixed(2)),
    });
  }

  const summary = {
    ok: true,
    reportDir: REPORT_DIR,
    archiveBase: ARCHIVE_BASE,
    thresholdHours: opts.hours,
    dryRun: opts.dryRun,
    totalCandidates: candidates.length,
    moved,
  };

  if (opts.verbose || opts.dryRun) {
    console.log(JSON.stringify(summary, null, 2));
  } else {
    console.log(JSON.stringify({
      ok: true,
      dryRun: false,
      thresholdHours: opts.hours,
      totalMoved: moved.length,
    }, null, 2));
  }
}

main();
