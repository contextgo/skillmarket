#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || path.resolve(__dirname, '..', '..', '..');
const STATE_FILE = path.join(WORKSPACE, 'runtime', 'execution-state', 'current.json');
const REPORT_DIR = path.join(WORKSPACE, 'runtime', 'execution-state', 'reports');
const OPENCLAW_BIN = process.env.OPENCLAW_BIN || '/root/.local/share/pnpm/openclaw';
const DELIVERY_CHANNEL = process.env.EXECUTION_STATE_DELIVERY_CHANNEL || process.env.EXECUTION_STATE_CHANNEL || '';
const DELIVERY_TARGET = process.env.EXECUTION_STATE_DELIVERY_TARGET || process.env.EXECUTION_STATE_TARGET || '';
const DELIVERY_ACCOUNT_ID = process.env.EXECUTION_STATE_DELIVERY_ACCOUNT_ID || process.env.EXECUTION_STATE_ACCOUNT_ID || '';
const OPENCLAW_AGENT_ID = process.env.EXECUTION_STATE_AGENT_ID || 'main';

function nowIso() {
  return new Date().toISOString();
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function readState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  } catch {
    return null;
  }
}

function writeState(state) {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2) + '\n', 'utf8');
}

function minutesSince(iso) {
  if (!iso) return null;
  const ts = Date.parse(iso);
  if (Number.isNaN(ts)) return null;
  return Math.floor((Date.now() - ts) / 60000);
}

function plusMinutes(iso, minutes) {
  const base = iso ? new Date(iso) : new Date();
  return new Date(base.getTime() + minutes * 60000).toISOString();
}

function writeReport(result) {
  ensureDir(REPORT_DIR);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const file = path.join(REPORT_DIR, `${stamp}-dispatcher.json`);
  fs.writeFileSync(file, JSON.stringify(result, null, 2) + '\n', 'utf8');
  return file;
}

function emptyAction() {
  return {
    type: '',
    message: '',
    detail: '',
    step_index: null,
    command: '',
    args: [],
    timeout_seconds: 30,
    artifact_path: '',
    prompt: ''
  };
}

function normalizeEvents(events = []) {
  if (!Array.isArray(events)) return [];
  return events
    .filter((item) => item && typeof item === 'object')
    .map((item) => ({
      id: item.id || '',
      type: item.type || '',
      created_at: item.created_at || '',
      consumed_at: item.consumed_at || '',
      payload: item.payload && typeof item.payload === 'object' ? item.payload : {}
    }));
}

function normalizeState(state) {
  if (!state) return state;
  if (!state.next_check_at && state.last_progress_at) {
    state.next_check_at = plusMinutes(state.last_progress_at, 10);
  }
  if (!('last_user_report_at' in state)) {
    state.last_user_report_at = '';
  }
  if (!state.auto_state) {
    state.auto_state = state.status === 'executing' ? 'active' : state.status || 'idle';
  }
  if (!('recovery_suggestion' in state)) {
    state.recovery_suggestion = '';
  }
  if (!('next_action_hint' in state)) {
    state.next_action_hint = '';
  }
  if (!state.plan || typeof state.plan !== 'object') {
    state.plan = {
      goal: '',
      current_step: 0,
      steps: [],
      next_action: emptyAction(),
      action_queue: [],
      verification_status: 'pending',
      retry_count: 0,
      last_attempt_at: '',
      artifacts: []
    };
  }
  if (!state.plan.next_action || typeof state.plan.next_action !== 'object') {
    state.plan.next_action = emptyAction();
  }
  if (!Array.isArray(state.plan.action_queue)) {
    state.plan.action_queue = [];
  }
  if (!state.meta || typeof state.meta !== 'object') {
    state.meta = {};
  }
  state.events = normalizeEvents(state.events || []);
  if (!('last_dispatch_message' in state.meta)) {
    state.meta.last_dispatch_message = '';
  }
  if (!('last_dispatch_at' in state.meta)) {
    state.meta.last_dispatch_at = '';
  }
  return state;
}

function sendUserUpdate(text) {
  if (!text || !text.trim()) return { ok: false, skipped: true, reason: 'empty-message' };
  if (!DELIVERY_CHANNEL || !DELIVERY_TARGET || !DELIVERY_ACCOUNT_ID) {
    return { ok: false, skipped: true, reason: 'missing-delivery-env' };
  }
  const result = spawnSync(OPENCLAW_BIN, [
    'message', 'send',
    '--channel', DELIVERY_CHANNEL,
    '--account', DELIVERY_ACCOUNT_ID,
    '--target', DELIVERY_TARGET,
    '--message', text,
  ], { cwd: WORKSPACE, encoding: 'utf8' });
  return {
    ok: result.status === 0,
    status: result.status,
    stderr: (result.stderr || '').trim(),
    stdout: (result.stdout || '').trim(),
  };
}

function shouldDispatch(state, message, minMinutes = 10) {
  if (!message || !message.trim()) return { allow: false, reason: 'empty-message' };
  const lastMsg = state?.meta?.last_dispatch_message || '';
  const lastAt = state?.meta?.last_dispatch_at || '';
  const age = minutesSince(lastAt);
  if (lastMsg === message && age !== null && age < minMinutes) {
    return { allow: false, reason: `duplicate-within-${minMinutes}m` };
  }
  return { allow: true, reason: 'dispatch-allowed' };
}

function dispatchWithDedupe(state, message, minMinutes = 10) {
  const decision = shouldDispatch(state, message, minMinutes);
  if (!decision.allow) {
    return { ok: false, skipped: true, reason: decision.reason };
  }
  const delivery = sendUserUpdate(message);
  if (delivery.ok) {
    state.meta.last_dispatch_message = message;
    state.meta.last_dispatch_at = nowIso();
    writeState(state);
  }
  return delivery;
}

function currentPlannedStep(state) {
  const idx = Number.isInteger(state?.plan?.current_step) ? state.plan.current_step : 0;
  const steps = Array.isArray(state?.plan?.steps) ? state.plan.steps : [];
  return steps[idx] || '';
}

function effectiveAction(state) {
  const queue = Array.isArray(state?.plan?.action_queue) ? state.plan.action_queue : [];
  if (queue.length > 0 && queue[0] && typeof queue[0] === 'object' && queue[0].type) {
    return queue[0];
  }
  const action = state?.plan?.next_action;
  if (action && typeof action === 'object' && action.type) return action;
  if (typeof action === 'string' && action) return { type: 'hint', message: action };
  return null;
}

function nextActionMessage(state) {
  const action = effectiveAction(state);
  if (action && typeof action === 'object' && action.message) return action.message;
  return currentPlannedStep(state);
}

function clearExecutedAction(state, action) {
  const queue = Array.isArray(state?.plan?.action_queue) ? state.plan.action_queue : [];
  if (queue.length > 0 && action && queue[0] && queue[0].type === action.type && queue[0].message === action.message) {
    state.plan.action_queue.shift();
    return;
  }
  state.plan.next_action = emptyAction();
}

function parseJsonObject(text) {
  const raw = String(text || '').trim();
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {}
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start >= 0 && end > start) {
    try {
      return JSON.parse(raw.slice(start, end + 1));
    } catch {}
  }
  return null;
}

function extractSubtaskSuccess(result) {
  const parsed = parseJsonObject(result?.stdout || '');
  if (!parsed || parsed.status !== 'ok') return null;
  const payloads = Array.isArray(parsed?.result?.payloads) ? parsed.result.payloads : [];
  const payloadTexts = payloads
    .map((item) => (item && typeof item.text === 'string' ? item.text.trim() : ''))
    .filter(Boolean);
  return {
    parsed,
    payloadTexts,
    summary: parsed.summary || '',
    runId: parsed.runId || ''
  };
}

function executePlannedAction(state) {
  const action = effectiveAction(state);
  if (!action || typeof action !== 'object' || !action.type) {
    return { ok: false, skipped: true, reason: 'no-structured-action' };
  }

  if (action.type === 'spawn_subtask') {
    const prompt = action.prompt || action.message;
    if (!prompt) return { ok: false, skipped: true, reason: 'missing-prompt' };
    const subtaskTimeoutSeconds = Number(action.timeout_seconds) || 60;
    const result = spawnSync(OPENCLAW_BIN, [
      'agent', '--json', '--agent', OPENCLAW_AGENT_ID,
      '--message', prompt,
      '--timeout', String(subtaskTimeoutSeconds)
    ], {
      cwd: WORKSPACE,
      encoding: 'utf8',
      timeout: Math.max(subtaskTimeoutSeconds * 1000 + 30000, 45000),
    });
    state.plan.last_attempt_at = nowIso();
    state.last_progress_at = state.plan.last_attempt_at;
    state.plan.retry_count = (state.plan.retry_count || 0) + 1;

    const success = extractSubtaskSuccess(result);
    const artifactHints = [];
    if (Array.isArray(state.plan?.action_queue) && state.plan.action_queue.length > 1) {
      const next = state.plan.action_queue[1];
      if (next?.type === 'verify_artifact' && next?.artifact_path) artifactHints.push(next.artifact_path);
    }
    const artifactFallback = artifactHints.find((p) => p && fs.existsSync(p));
    if (result.status === 0 || success || artifactFallback) {
      const stdout = (result.stdout || '').trim();
      state.last_progress_summary = `已执行子任务动作：${action.message || prompt}`;
      const artifactCandidates = success ? success.payloadTexts : [];
      const mergedArtifacts = [...(state.plan.artifacts || [])];
      for (const item of artifactCandidates) {
        if (item && !mergedArtifacts.includes(item)) mergedArtifacts.push(item);
      }
      if (artifactFallback && !mergedArtifacts.includes(artifactFallback)) mergedArtifacts.push(artifactFallback);
      if (!success && stdout) mergedArtifacts.push(stdout.slice(0, 1000));
      state.plan.artifacts = mergedArtifacts;
      clearExecutedAction(state, action);
      writeState(state);
      return {
        ok: true,
        action: 'spawn_subtask',
        prompt,
        stdout,
        acceptedFrom: artifactFallback ? 'artifact-fallback' : (success && result.status !== 0 ? 'stdout-json-after-timeout' : 'normal-exit'),
        runId: success?.runId || ''
      };
    }
    state.status = 'blocked';
    state.auto_state = 'blocked';
    state.blocker = `spawn_subtask failed: ${action.message || prompt}`;
    state.last_progress_summary = state.blocker;
    state.next_check_at = plusMinutes(state.last_progress_at, 30);
    writeState(state);
    return {
      ok: false,
      action: 'spawn_subtask',
      reason: result.error?.code === 'ETIMEDOUT' ? 'subtask-timeout-without-valid-json' : 'subtask-failed',
      prompt,
      error: result.error ? { message: result.error.message, code: result.error.code } : null,
      stderr: (result.stderr || '').trim(),
      stdout: (result.stdout || '').trim()
    };
  }

  if (action.type === 'run_script') {
    const cmd = action.command;
    const args = Array.isArray(action.args) ? action.args : [];
    if (!cmd) return { ok: false, skipped: true, reason: 'missing-command' };
    const result = spawnSync(cmd, args, {
      cwd: WORKSPACE,
      encoding: 'utf8',
      timeout: (Number(action.timeout_seconds) || 30) * 1000,
    });
    state.plan.last_attempt_at = nowIso();
    state.last_progress_at = state.plan.last_attempt_at;
    state.plan.retry_count = (state.plan.retry_count || 0) + 1;
    if (result.status === 0) {
      state.last_progress_summary = `已执行脚本动作：${action.message || cmd}`;
      const stdout = (result.stdout || '').trim();
      if (stdout) state.plan.artifacts = [...(state.plan.artifacts || []), stdout.split('\n').pop()];
      clearExecutedAction(state, action);
      writeState(state);
      return { ok: true, action: 'run_script', command: cmd, stdout };
    }
    state.status = 'blocked';
    state.auto_state = 'blocked';
    state.blocker = `run_script failed: ${action.message || cmd}`;
    state.last_progress_summary = state.blocker;
    state.next_check_at = plusMinutes(state.last_progress_at, 30);
    writeState(state);
    return { ok: false, action: 'run_script', reason: 'script-failed', command: cmd, stderr: (result.stderr || '').trim(), stdout: (result.stdout || '').trim() };
  }

  if (action.type === 'verify_artifact') {
    const target = action.artifact_path || (Array.isArray(state.plan.artifacts) ? state.plan.artifacts.slice(-1)[0] : '');
    state.plan.last_attempt_at = nowIso();
    state.last_progress_at = state.plan.last_attempt_at;
    state.plan.retry_count = (state.plan.retry_count || 0) + 1;
    if (target && fs.existsSync(target)) {
      state.plan.verification_status = 'verified';
      state.last_progress_summary = `已验证产物存在：${target}`;
      clearExecutedAction(state, action);
      writeState(state);
      return { ok: true, action: 'verify_artifact', artifact: target };
    }
    state.status = 'blocked';
    state.auto_state = 'blocked';
    state.blocker = `artifact missing: ${target || 'unknown artifact'}`;
    state.last_progress_summary = state.blocker;
    state.next_check_at = plusMinutes(state.last_progress_at, 30);
    state.plan.verification_status = 'failed';
    writeState(state);
    return { ok: false, action: 'verify_artifact', reason: 'artifact-missing', artifact: target };
  }

  if (action.type === 'advance_step') {
    const steps = Array.isArray(state.plan.steps) ? state.plan.steps : [];
    const target = Number.isInteger(action.step_index) ? action.step_index : state.plan.current_step + 1;
    state.plan.current_step = target;
    state.plan.last_attempt_at = nowIso();
    state.last_progress_at = state.plan.last_attempt_at;
    state.last_progress_summary = `自动推进到步骤 ${target}: ${steps[target] || action.message || 'next step'}`;
    clearExecutedAction(state, action);
    writeState(state);
    return { ok: true, action: 'advance_step', targetStep: target };
  }

  if (action.type === 'mark_blocked') {
    state.status = 'blocked';
    state.auto_state = 'blocked';
    state.blocker = action.detail || action.message || 'dispatcher marked blocked';
    state.last_progress_at = nowIso();
    state.next_check_at = plusMinutes(state.last_progress_at, 30);
    state.last_progress_summary = `blocked: ${state.blocker}`;
    state.plan.last_attempt_at = state.last_progress_at;
    writeState(state);
    return { ok: true, action: 'mark_blocked' };
  }

  if (action.type === 'ask_user') {
    state.status = 'waiting-user';
    state.auto_state = 'waiting-user';
    state.blocker = action.detail || action.message || 'dispatcher requires user input';
    state.last_progress_at = nowIso();
    state.next_check_at = plusMinutes(state.last_progress_at, 30);
    state.last_progress_summary = state.blocker;
    state.plan.last_attempt_at = state.last_progress_at;
    writeState(state);
    return { ok: true, action: 'ask_user' };
  }

  return { ok: false, skipped: true, reason: `unsupported-action:${action.type}` };
}

function buildRecoverySuggestion(state, progressAge) {
  if (state.status === 'waiting-user') return state.blocker || '等待用户提供确认或补充信息';
  if (state.status === 'blocked') return state.blocker || '需要解除当前 blocker 后再继续';
  if (state.status === 'stale') {
    if (nextActionMessage(state)) return `建议先执行恢复动作：${nextActionMessage(state)}；若仍无进展，再决定恢复 / 阻塞 / 关闭。`;
    const planned = currentPlannedStep(state);
    if (planned) return `建议基于当前步骤重新装填恢复动作：${planned}`;
    return '建议先回看最近进展，再决定是恢复执行、转 blocked，还是明确关闭任务。';
  }
  if (state.status === 'executing' && progressAge !== null && progressAge >= 10) {
    if (nextActionMessage(state)) return `建议优先执行下一步：${nextActionMessage(state)}`;
    return '建议立刻补一条真实进展；如果没有新进展，就应主动说明 blocker 或收口。';
  }
  return '';
}

function buildNextActionHint(state) {
  const planned = nextActionMessage(state);
  if (state.status === 'waiting-user') return planned ? `等你回复后，我下一步会执行：${planned}` : '等你回复后，我下一步会按你的确认继续推进。';
  if (state.status === 'blocked') return planned ? `blocker 解除后，我会执行：${planned}` : '当前先不硬推，等 blocker 解除后继续。';
  if (state.status === 'stale') return planned ? `下一步优先恢复动作：${planned}` : '下一步应该先决定：恢复 / 阻塞 / 关闭。';
  if (state.status === 'executing') return planned ? `下一步我会执行：${planned}` : '下一步应产出新的真实进展，而不是重复说明“还在做”。';
  return planned || '';
}

function rehydrateActionForState(state) {
  const action = effectiveAction(state);
  if (action && typeof action === 'object' && action.type) {
    return { changed: false, action };
  }

  const idx = Number.isInteger(state?.plan?.current_step) ? state.plan.current_step : 0;
  const steps = Array.isArray(state?.plan?.steps) ? state.plan.steps : [];
  const current = steps[idx] || '';
  if (!current) return { changed: false, reason: 'no-current-step' };

  const synthesized = {
    type: 'advance_step',
    message: `恢复后推进当前步骤：${current}`,
    detail: 'auto rehydrated from current step',
    step_index: idx + 1,
    command: '',
    args: [],
    timeout_seconds: 30,
    artifact_path: '',
    prompt: ''
  };
  if (Array.isArray(state.plan.action_queue)) {
    state.plan.action_queue.unshift(synthesized);
  } else {
    state.plan.next_action = synthesized;
  }
  state.next_action_hint = buildNextActionHint(state);
  state.recovery_suggestion = buildRecoverySuggestion(state, minutesSince(state.last_progress_at));
  writeState(state);
  return { changed: true, action: synthesized };
}

function nextPendingEvent(state, type = '') {
  const events = Array.isArray(state?.events) ? state.events : [];
  return events.find((item) => item && !item.consumed_at && (!type || item.type === type)) || null;
}

function consumeEvent(state, eventId) {
  if (!Array.isArray(state?.events)) return false;
  const target = state.events.find((item) => item && item.id === eventId && !item.consumed_at);
  if (!target) return false;
  target.consumed_at = nowIso();
  return true;
}

function pushEvent(state, type, payload = {}) {
  if (!Array.isArray(state.events)) state.events = [];
  state.events.push({
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    type,
    created_at: nowIso(),
    consumed_at: '',
    payload,
  });
}

function renderStatusMessage(state, action, progressAge) {
  if (action === 'needs-report') return `我还在继续处理，当前进展：${state.last_progress_summary}。下一步：${state.next_action_hint}`;
  if (action === 'auto-stale') return `执行态超时自动收口：${state.last_progress_summary}。建议：${state.recovery_suggestion}`;
  if (state.status === 'blocked') return `当前卡住了：${state.blocker || '缺少 blocker 细节'}。建议：${state.recovery_suggestion}`;
  if (state.status === 'waiting-user') return `这一步需要你回我：${state.blocker || '缺少用户输入说明'}。${state.next_action_hint}`;
  if (state.status === 'stale') return `这条执行态目前已标记为 stale：${state.last_progress_summary || '长时间无新进展'}。下一步建议：${state.recovery_suggestion}`;
  if (state.status === 'executing' && progressAge !== null && progressAge >= 10) return `我还在继续处理，这条任务距上次明确进展已经 ${progressAge} 分钟。当前进展：${state.last_progress_summary}。下一步：${state.next_action_hint}`;
  return '';
}

function shouldAutoComplete(state) {
  const queueEmpty = !Array.isArray(state?.plan?.action_queue) || state.plan.action_queue.length === 0;
  const noNextAction = !effectiveAction(state);
  const verifiedOrNone = ['verified', 'passed', 'done', 'completed', 'pending'].includes(state?.plan?.verification_status || 'pending');
  return state.status === 'executing' && queueEmpty && noNextAction && verifiedOrNone;
}

function applyAutoComplete(state) {
  state.status = 'completed';
  state.auto_state = 'completed';
  state.completed_at = nowIso();
  state.last_progress_at = state.completed_at;
  state.next_check_at = '';
  state.recovery_suggestion = '';
  state.next_action_hint = '';
  return state;
}

function main() {
  const state = normalizeState(readState());
  if (!state) {
    const result = { ok: true, status: 'missing', action: 'noop', reason: 'no current execution state' };
    result.report = writeReport(result);
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  const status = state.status || 'idle';
  const progressAge = minutesSince(state.last_progress_at);
  const due = state.next_check_at ? Date.parse(state.next_check_at) <= Date.now() : false;
  writeState(state);

  state.recovery_suggestion = buildRecoverySuggestion(state, progressAge);
  state.next_action_hint = buildNextActionHint(state);
  writeState(state);

  const result = {
    ok: true,
    status,
    action: 'noop',
    progressAgeMinutes: progressAge,
    due,
    state
  };

  const startedEvent = nextPendingEvent(state, 'execution_started');
  const blockedEvent = nextPendingEvent(state, 'execution_blocked');
  const waitingUserEvent = nextPendingEvent(state, 'execution_waiting_user');
  const staleEvent = nextPendingEvent(state, 'execution_stale_detected');
  const completedEvent = nextPendingEvent(state, 'execution_completed');
  const checkpointEvent = nextPendingEvent(state, 'execution_checkpoint_completed');
  if (status === 'executing' && startedEvent) {
    const trigger = startedEvent.payload?.trigger_phrase || state.trigger_phrase || '继续执行';
    const message = `已开工：${trigger}。当前已进入执行态，下一步会继续推进并在状态变化时回你。`;
    const delivery = dispatchWithDedupe(state, message, 1);
    if (delivery.ok || delivery.skipped) {
      consumeEvent(state, startedEvent.id);
      state.last_user_report_at = nowIso();
      state.meta.last_dispatch_message = message;
      state.meta.last_dispatch_at = state.last_user_report_at;
      writeState(state);
      result.action = 'report-execution-started';
      result.state = state;
      result.delivery = delivery;
    }
  } else if (status === 'blocked' && blockedEvent) {
    const blocker = blockedEvent.payload?.blocker || state.blocker || '当前出现 blocker';
    const message = `卡住了：${blocker}。我会先按 blocker 处理，或在需要你决策时明确告诉你。`;
    const delivery = dispatchWithDedupe(state, message, 1);
    if (delivery.ok || delivery.skipped) {
      consumeEvent(state, blockedEvent.id);
      state.last_user_report_at = nowIso();
      state.meta.last_dispatch_message = message;
      state.meta.last_dispatch_at = state.last_user_report_at;
      writeState(state);
      result.action = 'report-execution-blocked';
      result.state = state;
      result.delivery = delivery;
    }
  } else if (status === 'waiting-user' && waitingUserEvent) {
    const blocker = waitingUserEvent.payload?.blocker || state.blocker || '等待你的输入';
    const message = `这一步在等你：${blocker}。你一回复，我就继续往下走。`;
    const delivery = dispatchWithDedupe(state, message, 1);
    if (delivery.ok || delivery.skipped) {
      consumeEvent(state, waitingUserEvent.id);
      state.last_user_report_at = nowIso();
      state.meta.last_dispatch_message = message;
      state.meta.last_dispatch_at = state.last_user_report_at;
      writeState(state);
      result.action = 'report-execution-waiting-user';
      result.state = state;
      result.delivery = delivery;
    }
  } else if (status === 'stale' && staleEvent) {
    const summary = staleEvent.payload?.summary || state.last_progress_summary || '执行态已 stale';
    const message = `这条执行态已 stale：${summary}。我会优先给出恢复建议或明确收口。`;
    const delivery = dispatchWithDedupe(state, message, 1);
    if (delivery.ok || delivery.skipped) {
      consumeEvent(state, staleEvent.id);
      state.last_user_report_at = nowIso();
      state.meta.last_dispatch_message = message;
      state.meta.last_dispatch_at = state.last_user_report_at;
      writeState(state);
      result.action = 'report-execution-stale';
      result.state = state;
      result.delivery = delivery;
    }
  } else if (status === 'completed' && completedEvent) {
    const summary = completedEvent.payload?.result_summary || completedEvent.payload?.summary || state.last_progress_summary || '任务已完成';
    const message = `已完成：${summary}。如果有后续，我会在下一步继续收口。`;
    const delivery = dispatchWithDedupe(state, message, 1);
    if (delivery.ok || delivery.skipped) {
      consumeEvent(state, completedEvent.id);
      state.last_user_report_at = nowIso();
      state.meta.last_dispatch_message = message;
      state.meta.last_dispatch_at = state.last_user_report_at;
      writeState(state);
      result.action = 'report-execution-completed';
      result.state = state;
      result.delivery = delivery;
    }
  } else if (status === 'executing' && due) {
    const executed = executePlannedAction(state);
    if (executed.ok) {
      state.recovery_suggestion = buildRecoverySuggestion(state, minutesSince(state.last_progress_at));
      state.next_action_hint = buildNextActionHint(state);
      if (shouldAutoComplete(state)) {
        applyAutoComplete(state);
        writeState(state);
        result.action = 'completed-after-actions';
        result.state = state;
        result.execution = executed;
        result.delivery = dispatchWithDedupe(state, `动作链已自动收口完成：${state.last_progress_summary}`, 5);
      } else {
        pushEvent(state, 'execution_checkpoint_completed', {
          task_id: state.task_id,
          summary: state.last_progress_summary,
          result_summary: state.last_progress_summary,
          verification_status: state.plan?.verification_status || 'pending',
          current_step: state.plan?.current_step || 0,
          next_action_hint: state.next_action_hint || buildNextActionHint(state),
          report_style: 'short',
          visibility_required: true,
        });
        writeState(state);
        result.action = `executed-${executed.action}`;
        result.state = state;
        result.execution = executed;
        result.delivery = dispatchWithDedupe(state, `已自动执行下一步动作：${state.last_progress_summary}`, 5);
      }
    } else if (progressAge !== null && progressAge >= 30) {
      state.status = 'stale';
      state.auto_state = 'stale';
      state.blocker = state.blocker || 'dispatcher auto-staled due to no fresh progress';
      state.completed_at = nowIso();
      state.last_progress_at = state.completed_at;
      state.last_progress_summary = `dispatcher auto-staled after ${progressAge} min without fresh progress`;
      state.next_check_at = '';
      writeState(state);
      result.action = 'auto-stale';
      result.state = state;
      result.delivery = dispatchWithDedupe(state, renderStatusMessage(state, result.action, progressAge), 30);
    } else {
      state.auto_state = 'needs-report';
      state.last_user_report_at = nowIso();
      state.next_check_at = plusMinutes(state.last_user_report_at, 10);
      state.last_progress_summary = state.last_progress_summary || 'dispatcher requested progress report';
      writeState(state);
      result.action = 'needs-report';
      result.state = state;
      result.delivery = dispatchWithDedupe(state, renderStatusMessage(state, result.action, progressAge), 10);
    }
  } else if (status === 'executing' && checkpointEvent) {
    const summary = checkpointEvent.payload?.result_summary || checkpointEvent.payload?.summary || state.last_progress_summary || '当前阶段已完成';
    const nextHint = checkpointEvent.payload?.next_action_hint || state.next_action_hint || buildNextActionHint(state);
    const message = `阶段完成：${summary}。下一步：${nextHint || '继续推进后续步骤。'}`;
    const delivery = dispatchWithDedupe(state, message, 1);
    if (delivery.ok || delivery.skipped) {
      consumeEvent(state, checkpointEvent.id);
      state.last_user_report_at = nowIso();
      state.meta.last_dispatch_message = message;
      state.meta.last_dispatch_at = state.last_user_report_at;
      writeState(state);
      result.action = 'report-execution-checkpoint-completed';
      result.state = state;
      result.delivery = delivery;
    }
  } else if (status === 'blocked' || status === 'waiting-user' || status === 'stale') {
    if (status === 'stale') {
      const rehydrated = rehydrateActionForState(state);
      if (rehydrated.changed) {
        state.status = 'executing';
        state.auto_state = 'active';
        state.blocker = '';
        state.completed_at = '';
        state.last_progress_summary = `stale 恢复器已重新装填动作：${rehydrated.action.message}`;
        state.next_check_at = plusMinutes(nowIso(), 5);
        writeState(state);
        result.action = 'rehydrate-stale';
        result.state = state;
        result.delivery = dispatchWithDedupe(state, `我已从 stale 恢复并重新装填动作：${rehydrated.action.message}`, 10);
      }
    }

    const reportAge = minutesSince(state.last_user_report_at);
    if (result.action === 'noop' && (reportAge === null || reportAge >= 30)) {
      state.last_user_report_at = nowIso();
      state.next_check_at = plusMinutes(state.last_user_report_at, 30);
      writeState(state);
      result.action = `report-${status}`;
      result.state = state;
      result.delivery = dispatchWithDedupe(state, renderStatusMessage(state, result.action, progressAge), 30);
    }
  }

  result.report = writeReport(result);
  console.log(JSON.stringify(result, null, 2));
}

main();
