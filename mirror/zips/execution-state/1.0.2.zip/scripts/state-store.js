#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || path.resolve(__dirname, '..', '..', '..');
const STATE_DIR = path.join(WORKSPACE, 'runtime', 'execution-state');
const HISTORY_DIR = path.join(STATE_DIR, 'history');
const CURRENT_FILE = path.join(STATE_DIR, 'current.json');

function ensureDirs() {
  fs.mkdirSync(HISTORY_DIR, { recursive: true });
}

function now() {
  return new Date().toISOString();
}

function readJson(file, fallback = null) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n', 'utf8');
}

function pushEvent(current, type, payload = {}) {
  if (!Array.isArray(current.events)) current.events = [];
  current.events.push({
    id: crypto.randomUUID(),
    type,
    created_at: now(),
    consumed_at: '',
    payload,
  });
}

function archiveCurrent(reason = 'snapshot') {
  const current = readJson(CURRENT_FILE, null);
  if (!current) return null;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const id = current.task_id || crypto.randomUUID();
  const out = path.join(HISTORY_DIR, `${stamp}-${reason}-${id}.json`);
  writeJson(out, current);
  return out;
}

function plusMinutes(iso, minutes) {
  const base = iso ? new Date(iso) : new Date();
  return new Date(base.getTime() + minutes * 60000).toISOString();
}

function normalizeAction(action) {
  if (!action) return { type: '', message: '', detail: '', step_index: null, command: '', args: [], timeout_seconds: 30, artifact_path: '', prompt: '' };
  if (typeof action === 'string') {
    return { type: 'hint', message: action, detail: '', step_index: null, command: '', args: [], timeout_seconds: 30, artifact_path: '', prompt: '' };
  }
  return {
    type: action.type || '',
    message: action.message || '',
    detail: action.detail || '',
    step_index: Number.isInteger(action.step_index) ? action.step_index : null,
    command: action.command || '',
    args: Array.isArray(action.args) ? action.args : [],
    timeout_seconds: Number.isFinite(action.timeout_seconds) ? action.timeout_seconds : 30,
    artifact_path: action.artifact_path || '',
    prompt: action.prompt || ''
  };
}

function normalizePlan(fields = {}) {
  return {
    goal: fields.goal || '',
    current_step: Number.isInteger(fields.current_step) ? fields.current_step : 0,
    steps: Array.isArray(fields.steps) ? fields.steps : [],
    next_action: normalizeAction(fields.next_action || ''),
    action_queue: Array.isArray(fields.action_queue) ? fields.action_queue.map((a) => normalizeAction(a)) : [],
    verification_status: fields.verification_status || 'pending',
    retry_count: Number.isInteger(fields.retry_count) ? fields.retry_count : 0,
    last_attempt_at: fields.last_attempt_at || '',
    artifacts: Array.isArray(fields.artifacts) ? fields.artifacts : []
  };
}

function normalizeEvents(events = []) {
  if (!Array.isArray(events)) return [];
  return events
    .filter((item) => item && typeof item === 'object')
    .map((item) => ({
      id: item.id || crypto.randomUUID(),
      type: item.type || '',
      created_at: item.created_at || now(),
      consumed_at: item.consumed_at || '',
      payload: item.payload && typeof item.payload === 'object' ? item.payload : {}
    }));
}

function baseState(fields = {}) {
  const enteredAt = fields.entered_at || now();
  const lastProgressAt = fields.last_progress_at || enteredAt;
  return {
    task_id: fields.task_id || crypto.randomUUID(),
    status: fields.status || 'executing',
    entered_at: enteredAt,
    source_message: fields.source_message || '',
    trigger_phrase: fields.trigger_phrase || '',
    executor_mode: fields.executor_mode || 'main',
    subagent_id: fields.subagent_id || '',
    last_progress_at: lastProgressAt,
    last_progress_summary: fields.last_progress_summary || '',
    blocker: fields.blocker || '',
    completed_at: fields.completed_at || '',
    next_check_at: fields.next_check_at || plusMinutes(lastProgressAt, 10),
    last_user_report_at: fields.last_user_report_at || '',
    auto_state: fields.auto_state || 'active',
    recovery_suggestion: fields.recovery_suggestion || '',
    next_action_hint: fields.next_action_hint || '',
    plan: normalizePlan(fields.plan || {}),
    events: normalizeEvents(fields.events || []),
    meta: fields.meta || {}
  };
}

function cmdStart(args) {
  const summary = args.slice(0).join(' ').trim();
  archiveCurrent('pre-start');
  const state = baseState({
    status: 'executing',
    last_progress_summary: summary || 'entered execution state'
  });
  writeJson(CURRENT_FILE, state);
  console.log(JSON.stringify({ ok: true, action: 'start', current: CURRENT_FILE, task_id: state.task_id }, null, 2));
}

function cmdUpdate(args) {
  const current = readJson(CURRENT_FILE, null);
  if (!current) {
    console.error('No current execution state found.');
    process.exit(1);
  }
  current.last_progress_at = now();
  current.next_check_at = plusMinutes(current.last_progress_at, 10);
  current.auto_state = 'active';
  if (!current.plan) current.plan = normalizePlan();
  current.plan.last_attempt_at = current.last_progress_at;
  if (args.length) current.last_progress_summary = args.join(' ').trim();
  if (current.status !== 'blocked' && current.status !== 'waiting-user') current.status = 'executing';
  writeJson(CURRENT_FILE, current);
  console.log(JSON.stringify({ ok: true, action: 'update', current: CURRENT_FILE, task_id: current.task_id }, null, 2));
}

function cmdBlock(args) {
  const current = readJson(CURRENT_FILE, null);
  if (!current) {
    console.error('No current execution state found.');
    process.exit(1);
  }
  current.status = 'blocked';
  current.auto_state = 'blocked';
  current.blocker = args.join(' ').trim() || 'unspecified blocker';
  current.last_progress_at = now();
  current.next_check_at = plusMinutes(current.last_progress_at, 30);
  current.last_progress_summary = `blocked: ${current.blocker}`;
  pushEvent(current, 'execution_blocked', {
    task_id: current.task_id,
    status: current.status,
    summary: current.last_progress_summary,
    blocker: current.blocker,
    recovery_suggestion: current.recovery_suggestion || '',
    report_style: 'short',
    visibility_required: true,
  });
  writeJson(CURRENT_FILE, current);
  console.log(JSON.stringify({ ok: true, action: 'block', current: CURRENT_FILE, task_id: current.task_id }, null, 2));
}

function cmdWait(args) {
  const current = readJson(CURRENT_FILE, null);
  if (!current) {
    console.error('No current execution state found.');
    process.exit(1);
  }
  current.status = 'waiting-user';
  current.auto_state = 'waiting-user';
  current.blocker = args.join(' ').trim() || 'waiting for user input';
  current.last_progress_at = now();
  current.next_check_at = plusMinutes(current.last_progress_at, 30);
  current.last_progress_summary = current.blocker;
  pushEvent(current, 'execution_waiting_user', {
    task_id: current.task_id,
    status: current.status,
    summary: current.last_progress_summary,
    blocker: current.blocker,
    next_action_hint: current.next_action_hint || '',
    report_style: 'short',
    visibility_required: true,
  });
  writeJson(CURRENT_FILE, current);
  console.log(JSON.stringify({ ok: true, action: 'wait', current: CURRENT_FILE, task_id: current.task_id }, null, 2));
}

function cmdComplete(args) {
  const current = readJson(CURRENT_FILE, null);
  if (!current) {
    console.error('No current execution state found.');
    process.exit(1);
  }
  current.status = 'completed';
  current.auto_state = 'completed';
  current.completed_at = now();
  current.last_progress_at = current.completed_at;
  current.next_check_at = '';
  if (args.length) current.last_progress_summary = args.join(' ').trim();
  pushEvent(current, 'execution_completed', {
    task_id: current.task_id,
    status: current.status,
    summary: current.last_progress_summary,
    result_summary: current.last_progress_summary,
    verification_status: current.plan?.verification_status || 'pending',
    report_style: 'short',
    visibility_required: true,
  });
  writeJson(CURRENT_FILE, current);
  const archived = archiveCurrent('completed');
  console.log(JSON.stringify({ ok: true, action: 'complete', current: CURRENT_FILE, archived, task_id: current.task_id }, null, 2));
}

function cmdStatus() {
  const current = readJson(CURRENT_FILE, null);
  console.log(JSON.stringify({ ok: true, current }, null, 2));
}

function cmdDueNow(args) {
  const current = readJson(CURRENT_FILE, null);
  if (!current) {
    console.error('No current execution state found.');
    process.exit(1);
  }
  current.next_check_at = '2000-01-01T00:00:00.000Z';
  current.last_progress_at = now();
  if (args.length) current.last_progress_summary = args.join(' ').trim();
  writeJson(CURRENT_FILE, current);
  console.log(JSON.stringify({ ok: true, action: 'due-now', current: CURRENT_FILE, task_id: current.task_id, next_check_at: current.next_check_at }, null, 2));
}

function cmdStale(args) {
  const current = readJson(CURRENT_FILE, null);
  if (!current) {
    console.error('No current execution state found.');
    process.exit(1);
  }
  current.status = 'stale';
  current.auto_state = 'stale';
  current.completed_at = now();
  current.last_progress_at = current.completed_at;
  current.next_check_at = '';
  current.blocker = current.blocker || 'stale execution state';
  current.last_progress_summary = args.length ? args.join(' ').trim() : 'auto-staled due to missing fresh progress';
  pushEvent(current, 'execution_stale_detected', {
    task_id: current.task_id,
    status: current.status,
    summary: current.last_progress_summary,
    blocker: current.blocker,
    recovery_suggestion: current.recovery_suggestion || '',
    report_style: 'short',
    visibility_required: true,
  });
  writeJson(CURRENT_FILE, current);
  const archived = archiveCurrent('stale');
  console.log(JSON.stringify({ ok: true, action: 'stale', current: CURRENT_FILE, archived, task_id: current.task_id }, null, 2));
}

function cmdPlan(args) {
  const current = readJson(CURRENT_FILE, null);
  if (!current) {
    console.error('No current execution state found.');
    process.exit(1);
  }
  const raw = args.join(' ').trim();
  if (!raw) {
    console.error('Usage: node ... plan "{\"goal\":...,\"steps\":[...] }"');
    process.exit(1);
  }
  let patch;
  try {
    patch = JSON.parse(raw);
  } catch (err) {
    console.error(`Invalid JSON for plan: ${err.message}`);
    process.exit(1);
  }
  current.plan = normalizePlan({ ...(current.plan || {}), ...patch });
  current.last_progress_at = now();
  current.next_check_at = plusMinutes(current.last_progress_at, 10);
  if (current.plan.next_action && current.plan.next_action.message) current.next_action_hint = current.plan.next_action.message;
  writeJson(CURRENT_FILE, current);
  console.log(JSON.stringify({ ok: true, action: 'plan', current: CURRENT_FILE, task_id: current.task_id, plan: current.plan }, null, 2));
}

function cmdClear() {
  const archived = archiveCurrent('clear');
  if (fs.existsSync(CURRENT_FILE)) fs.unlinkSync(CURRENT_FILE);
  console.log(JSON.stringify({ ok: true, action: 'clear', archived }, null, 2));
}

function usage() {
  console.log(`Usage:
  node skills/execution-state/scripts/state-store.js start [summary]
  node skills/execution-state/scripts/state-store.js update [summary]
  node skills/execution-state/scripts/state-store.js block [reason]
  node skills/execution-state/scripts/state-store.js wait [reason]
  node skills/execution-state/scripts/state-store.js complete [summary]
  node skills/execution-state/scripts/state-store.js stale [summary]
  node skills/execution-state/scripts/state-store.js due-now [summary]
  node skills/execution-state/scripts/state-store.js plan '{"goal":"...","steps":["a","b"],"next_action":{"type":"advance_step","message":"do a","step_index":1},"action_queue":[{"type":"verify_artifact","message":"check out"}]}'
  node skills/execution-state/scripts/state-store.js status
  node skills/execution-state/scripts/state-store.js clear`);
}

function main() {
  ensureDirs();
  const [, , command, ...args] = process.argv;
  switch (command) {
    case 'start': return cmdStart(args);
    case 'update': return cmdUpdate(args);
    case 'block': return cmdBlock(args);
    case 'wait': return cmdWait(args);
    case 'complete': return cmdComplete(args);
    case 'stale': return cmdStale(args);
    case 'due-now': return cmdDueNow(args);
    case 'plan': return cmdPlan(args);
    case 'status': return cmdStatus();
    case 'clear': return cmdClear();
    default:
      usage();
      process.exit(command ? 1 : 0);
  }
}

main();
