#!/usr/bin/env node

const { spawnSync } = require('child_process');
const path = require('path');

const ROOT = __dirname;
const scripts = {
  promise: path.join(ROOT, 'promise-detector.js'),
  start: path.join(ROOT, 'state-store.js'),
  update: path.join(ROOT, 'state-store.js'),
  block: path.join(ROOT, 'state-store.js'),
  wait: path.join(ROOT, 'state-store.js'),
  complete: path.join(ROOT, 'state-store.js'),
  stale: path.join(ROOT, 'state-store.js'),
  'due-now': path.join(ROOT, 'state-store.js'),
  status: path.join(ROOT, 'state-store.js'),
  clear: path.join(ROOT, 'state-store.js'),
  watchdog: path.join(ROOT, 'fake-execution-watchdog.js'),
  dispatch: path.join(ROOT, 'execution-dispatcher.js')
};

function usage() {
  console.log(`Usage:
  node skills/execution-state/scripts/execution-state-cli.js promise "我继续做这个问题"
  node skills/execution-state/scripts/execution-state-cli.js start "entered execution state"
  node skills/execution-state/scripts/execution-state-cli.js update "checked logs and config"
  node skills/execution-state/scripts/execution-state-cli.js block "waiting for permission"
  node skills/execution-state/scripts/execution-state-cli.js wait "waiting for user input"
  node skills/execution-state/scripts/execution-state-cli.js complete "usable version delivered"
  node skills/execution-state/scripts/execution-state-cli.js stale "auto-staled due to missing fresh progress"
  node skills/execution-state/scripts/execution-state-cli.js due-now "force due checkpoint"
  node skills/execution-state/scripts/execution-state-cli.js status
  node skills/execution-state/scripts/execution-state-cli.js clear
  node skills/execution-state/scripts/execution-state-cli.js watchdog 10
  node skills/execution-state/scripts/execution-state-cli.js dispatch
  node skills/execution-state/scripts/cleanup-reports.js --dry-run --hours 24
  node skills/execution-state/scripts/cleanup-reports.js --apply --hours 24`);
}

function main() {
  const [, , command, ...args] = process.argv;
  if (!command || !scripts[command]) {
    usage();
    process.exit(command ? 1 : 0);
  }

  const script = scripts[command];
  const forwardArgs = ['watchdog', 'dispatch'].includes(command)
    ? [script, ...args]
    : script.endsWith('state-store.js')
      ? [script, command, ...args]
      : [script, ...args];

  const result = spawnSync(process.execPath, forwardArgs, { stdio: 'inherit' });
  process.exit(result.status ?? 1);
}

main();
