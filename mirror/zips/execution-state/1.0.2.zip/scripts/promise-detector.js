#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || path.resolve(__dirname, '..', '..', '..');
const STATE_DIR = path.join(WORKSPACE, 'runtime', 'execution-state');
const CURRENT_FILE = path.join(STATE_DIR, 'current.json');

const TRIGGERS = [
  '我继续做',
  '我接着处理',
  '我来收尾',
  '我下一步去做',
  '不需要你再同意我继续做',
  '我继续推进',
  '我接着查',
  '我继续处理',
  '我来继续推进'
];

function ensureDir() {
  fs.mkdirSync(STATE_DIR, { recursive: true });
}

function readJson(file, fallback = null) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n', 'utf8');
}

function now() {
  return new Date().toISOString();
}

function plusMinutes(iso, minutes) {
  const base = iso ? new Date(iso) : new Date();
  return new Date(base.getTime() + minutes * 60000).toISOString();
}

function findTrigger(text) {
  if (!text) return null;
  return TRIGGERS.find((p) => text.includes(p)) || null;
}

function isActive(state) {
  if (!state) return false;
  return ['executing', 'blocked', 'waiting-user'].includes(state.status);
}

function baseState() {
  const ts = now();
  return {
    task_id: crypto.randomUUID(),
    status: 'executing',
    entered_at: ts,
    source_message: '',
    trigger_phrase: '',
    executor_mode: 'main',
    subagent_id: '',
    last_progress_at: ts,
    last_progress_summary: 'promise detected and execution state entered',
    blocker: '',
    completed_at: '',
    next_check_at: plusMinutes(ts, 10),
    last_user_report_at: '',
    auto_state: 'active',
    recovery_suggestion: '',
    next_action_hint: '',
    meta: {}
  };
}

function main() {
  ensureDir();
  const text = process.argv.slice(2).join(' ').trim();
  if (!text) {
    console.error('Usage: node skills/execution-state/scripts/promise-detector.js "assistant reply text"');
    process.exit(1);
  }

  const trigger = findTrigger(text);
  if (!trigger) {
    console.log(JSON.stringify({ ok: true, matched: false }, null, 2));
    return;
  }

  const current = readJson(CURRENT_FILE, null);
  const state = isActive(current) ? current : baseState();
  if (!isActive(current)) {
    state.entered_at = now();
    state.status = 'executing';
  }

  state.trigger_phrase = trigger;
  state.source_message = text;
  state.last_progress_at = now();
  state.next_check_at = plusMinutes(state.last_progress_at, 10);
  state.auto_state = 'active';
  state.last_progress_summary = `promise detected: ${trigger}`;
  state.next_action_hint = state.next_action_hint || '已进入执行态，下一步应立刻给出开工动作或阶段回执。';
  if (!state.plan || typeof state.plan !== 'object') {
    state.plan = {
      goal: '',
      current_step: 0,
      steps: [],
      next_action: { type: '', message: '', detail: '', step_index: null, command: '', args: [], timeout_seconds: 30, artifact_path: '', prompt: '' },
      action_queue: [],
      verification_status: 'pending',
      retry_count: 0,
      last_attempt_at: '',
      artifacts: []
    };
  }
  if (!Array.isArray(state.events)) state.events = [];
  state.events.push({
    id: crypto.randomUUID(),
    type: 'execution_started',
    created_at: state.last_progress_at,
    consumed_at: '',
    payload: {
      trigger_phrase: trigger,
      source_message: text,
      report_style: 'short',
      visibility_required: true
    }
  });
  writeJson(CURRENT_FILE, state);

  console.log(JSON.stringify({
    ok: true,
    matched: true,
    trigger,
    current: CURRENT_FILE,
    task_id: state.task_id,
    status: state.status
  }, null, 2));
}

main();
