#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || path.resolve(__dirname, '..', '..', '..');
const STATE_FILE = path.join(WORKSPACE, 'runtime', 'execution-state', 'current.json');
const REPORT_DIR = path.join(WORKSPACE, 'runtime', 'execution-state', 'reports');

const GENERIC_PROGRESS_PATTERNS = [
  /^entered execution state$/i,
  /^i will continue$/i,
  /^continuing$/i,
  /^processing$/i,
  /^working on it$/i,
  /^bootstrap reminder test$/i,
  /^entered execution state for mvp test$/i,
  /^我继续做$/,
  /^我接着处理$/,
  /^我来收尾$/,
  /^我继续推进$/,
  /^继续处理中?$/,
  /^正在处理$/
];

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function readState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  } catch {
    return null;
  }
}

function minutesSince(iso) {
  if (!iso) return null;
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return null;
  return Math.floor((Date.now() - t) / 60000);
}

function isGenericSummary(text) {
  if (!text || !text.trim()) return true;
  const s = text.trim();
  return GENERIC_PROGRESS_PATTERNS.some((re) => re.test(s));
}

function evaluate(state, staleMinutes = 10) {
  if (!state) {
    return { ok: false, status: 'missing', severity: 'warn', issues: ['state file missing'] };
  }

  const status = state.status || 'idle';
  const progressAge = minutesSince(state.last_progress_at);
  const enteredAge = minutesSince(state.entered_at);
  const genericSummary = isGenericSummary(state.last_progress_summary || '');
  const issues = [];
  let severity = 'ok';

  if (status === 'executing') {
    if (progressAge !== null && progressAge >= staleMinutes) {
      issues.push(`executing for ${progressAge} min without fresh progress`);
      severity = 'warn';
    }
    if (genericSummary) {
      issues.push('last progress summary is generic or missing');
      severity = severity === 'warn' ? 'warn' : 'info';
    }
  }

  if (status === 'blocked' || status === 'waiting-user') {
    if (!state.blocker || !state.blocker.trim()) {
      issues.push(`${status} state missing blocker detail`);
      severity = 'warn';
    }
  }

  if (status === 'completed') {
    if (!state.completed_at) {
      issues.push('completed state missing completed_at');
      severity = 'warn';
    }
  }

  if (['executing', 'blocked', 'waiting-user'].includes(status) && !state.entered_at) {
    issues.push('active state missing entered_at');
    severity = 'warn';
  }

  return {
    ok: issues.length === 0,
    status,
    severity,
    enteredAgeMinutes: enteredAge,
    progressAgeMinutes: progressAge,
    genericSummary,
    issues,
    state
  };
}

function writeReport(result) {
  ensureDir(REPORT_DIR);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const out = path.join(REPORT_DIR, `${stamp}-watchdog.json`);
  fs.writeFileSync(out, JSON.stringify(result, null, 2) + '\n', 'utf8');
  return out;
}

function staleCurrent(summary) {
  const current = readState();
  if (!current) return null;
  const ts = new Date().toISOString();
  current.status = 'stale';
  current.completed_at = ts;
  current.last_progress_at = ts;
  current.blocker = current.blocker || 'stale execution state';
  current.last_progress_summary = summary || 'auto-staled by watchdog';
  if (!Array.isArray(current.events)) current.events = [];
  current.events.push({
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    type: 'execution_stale_detected',
    created_at: ts,
    consumed_at: '',
    payload: {
      task_id: current.task_id || '',
      status: current.status,
      summary: current.last_progress_summary,
      blocker: current.blocker,
      recovery_suggestion: current.recovery_suggestion || '',
      report_style: 'short',
      visibility_required: true,
    }
  });
  fs.writeFileSync(STATE_FILE, JSON.stringify(current, null, 2) + '\n', 'utf8');
  return current;
}

function main() {
  const staleArg = process.argv[2] ? Number(process.argv[2]) : 10;
  const staleMinutes = Number.isFinite(staleArg) && staleArg > 0 ? staleArg : 10;
  const autoStale = process.argv.includes('--auto-stale');
  const state = readState();
  const result = evaluate(state, staleMinutes);

  if (autoStale && result.severity === 'warn' && result.status === 'executing') {
    const updated = staleCurrent(`auto-staled by watchdog after ${result.progressAgeMinutes} min without fresh progress`);
    if (updated) {
      result.autoStaled = true;
      result.state = updated;
      result.status = updated.status;
      result.severity = 'info';
      result.ok = true;
      result.issues = (result.issues || []).concat(['state auto-staled by watchdog']);
    }
  }

  const report = writeReport(result);
  console.log(JSON.stringify({ ...result, report }, null, 2));

  if (result.severity === 'warn') process.exit(2);
  if (result.severity === 'info') process.exit(0);
  if (!result.ok) process.exit(1);
}

main();
