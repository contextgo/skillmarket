# 执行态状态机

## 状态定义

- `idle`：空闲，未进入执行态
- `planning`：正在规划，还没进入执行承诺
- `executing`：已进入执行态，正在持续推进
- `blocked`：遇到 blocker，需要汇报或等待外部条件
- `waiting-user`：必须等待用户确认或输入
- `completed`：本轮任务已完成并已收口
- `abandoned`：明确终止、放弃或被替代

## 状态切换规则

### idle → executing
触发条件：
- 代理说出承诺词
- 且任务路径已清晰、无需新的外部授权

### executing → blocked
触发条件：
- 外部依赖失败
- 方向分叉且必须用户拍板
- 数据源不可用
- 权限不足

### executing → waiting-user
触发条件：
- 必须等待用户回复才能继续
- 该等待是**真实依赖**，不是偷懒挂起

### executing → completed
触发条件：
- 主任务完成
- 已给出结果
- 已说明验收情况

### blocked / waiting-user → executing
触发条件：
- blocker 解除
- 或用户给出继续所需信息

## 使用说明

当任务涉及“说了继续做却未必真的继续”时，优先按本状态机判断当前处于哪一层。

如果已经明确说出承诺词，应默认从 `idle/planning` 切换到 `executing`，而不是停留在口头承诺层。

如果无法继续，必须明确切到 `blocked` 或 `waiting-user`，不能模糊挂起。

## 收口要求

### blocked
- 必须带具体 `blocker`
- 必须说明已做到哪
- 默认 30 分钟内要有下一次复查或升级

### waiting-user
- 只能用于真实依赖用户输入/确认
- 必须写清“等什么”
- 必须给出 `next_action_hint`

### stale
- 表示执行态悬空过久，不表示任务自然完成
- 必须带 `recovery_suggestion`
- 恢复时优先：重新装填动作 → 回到 `executing`

### completed
- 必须写 `completed_at`
- 必须清空 `next_check_at`
- 若动作链已跑完，应清空 `action_queue / next_action_hint`
- 必须已有结果与验收说明

更细验收规则见：
- `references/lifecycle-acceptance.md`
