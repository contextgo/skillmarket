# 阶段完成事件设计（stage_completed）

## 目标

解决这一类典型问题：

- 任务还没整体完成
- 但已经完成了一个明确阶段
- 已经有产物 / 验证 / 结论
- 用户理应收到阶段回执
- 系统却没有把它当成标准事件

结果就是：
- 代理觉得“我还在继续做，等会一起说”
- 用户感受到的是“怎么又没回我”

---

## 问题定义

当前 execution-state 的统一事件层第一版覆盖了：
- `execution_started`
- `execution_blocked`
- `execution_waiting_user`
- `execution_stale_detected`
- `execution_completed`

但缺少：

> **阶段完成事件（stage_completed / execution_checkpoint_completed）**

这导致“任务中间阶段已经完成，但整体还没 completed”时，系统没有义务主动外显。

---

## 正确抽象

### 新事件：`execution_checkpoint_completed`

表示：
- 当前阶段已经明确完成
- 已产出阶段结果
- 已有最小验证
- 整体任务未必 completed
- 但必须产生一条阶段回执

---

## 事件字段建议

- `id`
- `type = execution_checkpoint_completed`
- `created_at`
- `consumed_at`
- `payload`

### payload 建议字段
- `task_id`
- `summary`：本阶段完成了什么
- `result_summary`：阶段结果
- `verification_status`
- `current_step`
- `next_action_hint`
- `report_style = short|standard`
- `visibility_required = true`

---

## 谁负责生产

### 推荐生产者
1. `execution-dispatcher.js`
   - 当动作链完成一个明确阶段时
   - 当 current_step 被推进且上一步已形成阶段结果时
2. 未来的显式阶段推进动作
   - 例如 `advance_step` 完成后
3. 手动状态工具（后续可选）
   - 如果未来支持 `checkpoint` 命令

---

## 谁负责消费

### 第一消费者：`execution-dispatcher.js`
职责：
- 识别未消费的 `execution_checkpoint_completed`
- 生成一条短阶段回执
- 做节流
- 标记 consumed

### 第二消费者：`longtask-reporting`
职责：
- 在需要更丰富模板时输出更完整阶段汇报

---

## 和 completed 的区别

### `execution_completed`
表示：
- 整个任务已经完成
- 已经进入最终收口

### `execution_checkpoint_completed`
表示：
- 只是完成了一个阶段
- 还要继续推进
- 但这个完成点本身必须外显

---

## 推荐回执话术

### 短回执
- `阶段完成：<summary>。下一步：<next_action_hint>`

### 标准回执
- 已完成什么
- 如何验证的
- 下一步做什么
- 当前是否还存在 blocker

---

## 最小落地顺序

### Phase 3.1
- 定义 `execution_checkpoint_completed` 事件
- 先不引入新命令
- 只在 dispatcher 内部明确阶段完成点时产事件

### Phase 3.2
- 为动作链/step 体系补统一 checkpoint 生产逻辑

### Phase 3.3
- 再考虑是否增加显式 `checkpoint` 状态工具入口

---

## 验收标准

当任务满足以下条件时：
- 某个阶段已经完成
- 有最小结果
- 有下一步
- 整体任务未完成

系统应满足：

1. 生成 `execution_checkpoint_completed`
2. dispatcher 识别并消费该事件
3. 用户收到阶段回执
4. 整个任务仍保持 `executing`
5. 事件不会重复无限发送

---

## 一句话结论

> 要真正解决“我其实做完了一个阶段，但你没感知到”的问题，就必须把阶段完成提升成一个标准事件，而不是继续靠代理自觉汇报。
