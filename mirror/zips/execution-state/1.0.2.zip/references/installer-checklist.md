# 安装与验收清单

## 一、安装前检查
- [ ] 已知自己的 workspace 路径
- [ ] 已知自己的消息目标 ID（如果要自动回报）
- [ ] 已知自己的账号 ID（如果要自动回报）
- [ ] 已确认 OpenClaw 运行正常

## 二、最小安装
- [ ] 将 `execution-state/` 目录放入 skills 目录
- [ ] 设置 `OPENCLAW_WORKSPACE`
- [ ] （可选）设置：
  - [ ] `EXECUTION_STATE_DELIVERY_CHANNEL`
  - [ ] `EXECUTION_STATE_DELIVERY_TARGET`
  - [ ] `EXECUTION_STATE_DELIVERY_ACCOUNT_ID`
  - [ ] `EXECUTION_STATE_AGENT_ID`

## 三、可选启用项
- [ ] 启用 bootstrap 恢复提醒 Hook
- [ ] 接入 dispatcher 定时任务（推荐 5 分钟）
- [ ] 接入 watchdog 定时任务（推荐 15 分钟）

## 四、最小自测
### 目标
验证完整动作链：
- run_script
- verify_artifact
- auto complete

### 通过标准
- [ ] 脚本动作被执行
- [ ] 产物文件存在
- [ ] `verification_status = verified`
- [ ] `queue_len = 0`
- [ ] `status = completed`
- [ ] `next_action_hint = ""`

### 发布前统一回归
- [ ] 已运行 `node skills/execution-state/scripts/test-release-acceptance.js`
- [ ] `waiting-user` 验收通过
- [ ] 多次 `blocked/recover` 验收通过
- [ ] `spawn_subtask` 验收通过
- [ ] 通道无关主动汇报验收通过

## 五、发布前检查
- [ ] skill 文档没有作者私人目标 ID
- [ ] skill 文档没有作者私人账号 ID
- [ ] skill 本体没有硬编码作者收件目标
- [ ] 自动消息在未配置环境变量时会安全跳过
- [ ] references 中已说明能力边界
- [ ] references 中已说明最小验收方式

## 六、建议的发布说明
发布时建议明确说明：
- 这是轻量 durable execution 层
- 主闭环已可用
- 适合多步骤/巡检/修复/研究任务
- 不等价于通用工作流平台
