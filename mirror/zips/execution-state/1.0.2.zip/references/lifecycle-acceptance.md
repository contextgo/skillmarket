# execution-state 状态收口与验收规则

## 目标

把 `blocked / waiting-user / stale / completed` 从“标签”收紧成“可判断、可恢复、可验收”的状态。

---

## 1. blocked

### 进入条件
必须至少满足以下之一：
- 外部依赖失败
- 权限不足
- 数据源不可用
- 方向分叉且必须先决定方案
- 自动动作执行失败，并且当前不能安全重试

### 必填字段
- `status = blocked`
- `blocker`：必须是具体问题，不能写“处理中”
- `last_progress_summary`：必须说明已做到哪
- `next_check_at`：默认 30 分钟内复查

### 合格样例
- `artifact missing: /path/to/file`
- `run_script failed: build assets`
- `缺少生产环境权限，无法继续发布`

### 不合格样例
- `有点问题`
- `先等等`
- 空字符串

### 恢复条件
以下任一成立可回到 `executing`：
- blocker 已解除
- 已切换到可执行的替代路径
- 用户已给出必须的决策/授权

---

## 2. waiting-user

### 进入条件
只有在**真的必须等用户**时才能进入：
- 需要用户确认发送 / 发布 / 删除 / 对外操作
- 需要用户提供关键输入
- 需要用户在多个方案里拍板

### 必填字段
- `status = waiting-user`
- `blocker`：明确写出“等用户什么”
- `next_action_hint`：用户回复后下一步做什么

### 合格样例
- `等待你确认是否直接发布`
- `等待你提供目标仓库地址`
- `等待你在 A/B 两个恢复方案中选一个`

### 不合格样例
- `waiting`
- `等回复`
- `需要确认`（没说明确认什么）

### 恢复条件
- 用户已回复关键输入
- 已拿到必要确认

---

## 3. stale

### 进入条件
执行态长时间没有真实新进展，且没有合法转成 `blocked / waiting-user / completed`。

### 判定信号
- `executing` 超过阈值仍无 fresh progress
- 最近进展是空话/泛话
- 没有动作执行证据
- 没有 blocker 说明

### stale 的目标
不是“结束任务”，而是强制把悬空执行态拉回可恢复状态。

### 必填字段
- `status = stale`
- `last_progress_summary`：说明为什么 stale
- `recovery_suggestion`：下一步怎么恢复

### 恢复条件
- 重新装填动作
- 明确下一步并重新进入 `executing`
- 或转 `blocked / waiting-user`

---

## 4. completed

### 进入条件
必须同时满足：
- 主任务已完成
- 已给出结果
- 已说明验收情况
- 没有遗留中的动作队列

### 最低验收
至少满足以下 4 项：
1. `status = completed`
2. `completed_at` 已写入
3. `next_check_at = ""`
4. `next_action_hint = ""`

### 如果是动作链任务，再加 3 项
5. `action_queue.length = 0`
6. `next_action` 为空
7. `verification_status` 不是失败态

### 不允许 completed 的情况
- 还有明确未消费动作
- 还在等用户，但偷切 completed
- 没有结果摘要
- 没有任何验收说明

---

## 5. 汇报规则

### blocked
必须主动说：
- 卡在哪
- 已试过什么
- 下一步怎么解

### waiting-user
必须主动说：
- 等你给什么
- 你一回我就做什么

### stale
必须主动说：
- 为什么判 stale
- 接下来恢复动作是什么

### completed
必须主动说：
- 完成了什么
- 改了什么
- 怎么验证的
- 还剩什么（若无写无）

---

## 6. 一句话标准

如果一个状态让人看不出：
- 为什么在这里
- 怎么离开这里
- 现在缺什么

那这个状态就是**没收口干净**。
