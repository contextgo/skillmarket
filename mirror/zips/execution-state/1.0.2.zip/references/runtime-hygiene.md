# execution-state 运行卫生与归档规则

## 目标

避免 `runtime/execution-state/` 因长时间运行而变成噪音堆，保证：
- 当前执行态易读
- 最近报告易排查
- 历史报告可归档
- 自动恢复不依赖海量旧文件

## 目录职责

- `current.json`：唯一当前执行态
- `history/*.json`：状态切换后的历史快照
- `reports/*.json`：watchdog / dispatcher 运行报告（高频产物）
- `archive/reports/YYYY-MM-DD/`：归档后的旧报告

## 保留策略

### reports/
- 默认只保留最近 **24 小时** 的热数据
- 超过阈值的旧报告移动到 `archive/reports/<date>/`
- 若同一天报告过多，优先归档旧小时段，不影响最近排查

### history/
- 默认保留最近 **14 天**
- 更旧的历史可按天归档；不要和 `reports/` 混在一起

## 执行原则

1. **运行态优先可读**
   - `reports/` 不是永久仓库，是热数据区
2. **归档优先移动，不优先删除**
   - 先归档，确认无用后再清
3. **按日期归档**
   - 方便按故障日回看，不要全堆一个目录
4. **不要影响 current.json**
   - 清理脚本不得改动当前执行态
5. **清理必须可 dry-run**
   - 先看会移动哪些文件，再真正执行

## 建议节奏

- 手动整理：问题爆量时立即执行一次
- 自动整理：可接 cron，每小时或每天跑一次
- 大改前：先保留最近热数据，避免把排查证据一起清掉

## 验收标准

- `reports/` 中只保留最近热数据
- 旧报告被移动到 `archive/reports/YYYY-MM-DD/`
- `current.json` 未被修改
- 最近一次 dispatcher / watchdog 报告仍能直接查看
- dry-run 与真实执行结果一致
