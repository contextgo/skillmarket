# 承诺词 → 执行态 → 可见事件：统一机制设计

## 目标

解决这一类典型失守：

- 代理说了“我继续做 / 我下一步去做”
- execution-state 可能已经写入
- 但用户侧没有立即感知到“已经开始执行”

问题不在话术，而在链路少了一层统一事件机制。

---

## 当前断点

当前系统大致是：

1. `promise-detector` 识别承诺词
2. 写入 `runtime/execution-state/current.json`
3. 进入 `executing`
4. 等后续动作或 dispatcher 周期推进

缺失点：

> **“进入执行态”本身还没有被提升为一个标准可消费事件。**

于是就会出现：
- 状态有了
- 用户体感却没有立刻变化

---

## 正确抽象

不要把问题理解成“某次该多发一句话”。

应该理解成：

> **当承诺词将任务从 planning / idle 推进到 executing 时，系统应生成一个标准事件：`execution_started`。**

这个事件再由通知层决定如何对用户外显。

---

## 事件层设计

### 1. 标准事件

#### `execution_started`
表示：
- 任务已从口头承诺切入真实执行态
- 后续必须出现可见动作、阶段回执或 blocker 说明

建议最小字段：
- `event_type = execution_started`
- `task_id`
- `trigger_phrase`
- `source_message`
- `entered_at`
- `visibility_required = true|false`
- `report_style = short|standard`

---

### 2. 谁负责生成事件

#### 接入层负责“生成”
例如：
- `promise-detector.js`
- 恢复 hook
- 未来可能的 UI/命令入口

#### 状态层负责“落状态”
例如：
- `state-store.js`

#### 通知层负责“消费事件并决定是否外显”
例如：
- `execution-dispatcher.js`
- `longtask-reporting`

---

## 推荐分层

### 状态层
职责：
- 进入 `executing`
- 保留 `trigger_phrase`
- 保留 `source_message`
- 保留 `next_action_hint`

### 事件层
职责：
- 记录 `execution_started`
- 标记是否必须立刻回执
- 供 dispatcher / reporting 消费

### 通知层
职责：
- 判断当前渠道/节流状态
- 生成开工短回执
- 决定是否直接发送，或只留待下一步统一回执

---

## 为什么不能直接在 promise-detector 里硬发消息

因为那会把：
- 触发识别
- 状态落盘
- 用户可见通知

三件事重新耦死到一个脚本里。

结果就是：
- 难测
- 难节流
- 难换渠道
- 难和 longtask-reporting 分层

所以正确做法不是“promise-detector 直接发消息”，而是：

> promise-detector 负责产生 `execution_started` 事件，dispatcher / reporting 再消费它。

---

## 最小落地方案

### Phase 1
- promise-detector 进入执行态时，写入一个最小事件标记
- dispatcher 识别到这个事件后，优先生成一条短开工回执
- 回执发送后，事件标记清空或标记为 consumed

### Phase 2
- 把状态变化事件统一成一套事件表：
  - `execution_started`
  - `blocked`
  - `waiting_user`
  - `stale_detected`
  - `execution_completed`

### Phase 3
- 引入节流与模式配置：
  - strict
  - balanced
  - quiet

---

## 验收标准

当出现以下话术：
- 我继续做
- 我接着处理
- 我下一步去做

系统应满足：

1. execution-state 已进入 `executing`
2. 已生成 `execution_started` 事件
3. 在允许外显的场景下，产生至少一条短开工回执
4. 若未外显，也必须能在状态中明确看出“等待立即回执/动作”
5. 后续事件由统一 dispatcher / reporting 层消费，而不是 promise-detector 单独特判

---

## 一句话结论

> 真正该补的不是“多发一句话”，而是把“承诺词进入执行态”升级成一个统一标准事件，然后再让通知层去消费它。
