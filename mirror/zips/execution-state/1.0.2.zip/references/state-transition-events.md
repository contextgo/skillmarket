# execution-state 统一事件层（二期）设计

## 目标

在 `execution_started` 之后，把 execution-state 的关键状态变化统一抽象成可消费事件层，避免：

- 每个状态各自长脚本特判
- 通知逻辑散在多个地方
- 状态变化有了，但用户侧不可见

---

## 核心原则

> 状态机是真源，事件层是可消费的变化协议，通知层只消费事件，不反向定义状态。

也就是说：
- 先有状态变化
- 再产出标准事件
- 最后由 dispatcher / reporting 决定如何外显

---

## 推荐事件集合

### 1. `execution_started`
表示：
- 承诺词已推动任务进入 `executing`
- 用户侧应感知“已经开工”

### 2. `execution_blocked`
表示：
- 任务已进入 `blocked`
- 必须向外明确 blocker、已试过什么、下一步怎么解

### 3. `execution_waiting_user`
表示：
- 任务已进入 `waiting-user`
- 必须明确“在等用户什么”

### 4. `execution_stale_detected`
表示：
- 执行态已被判定为 stale
- 必须给恢复建议或外显为“当前已悬空”

### 5. `execution_completed`
表示：
- 任务已进入 `completed`
- 必须给结果、改动、验证、剩余项（若无写无）

---

## 事件字段建议

每个事件建议至少包含：

- `id`
- `type`
- `created_at`
- `consumed_at`
- `payload`

### payload 推荐字段

#### 通用字段
- `task_id`
- `status`
- `summary`
- `report_style`
- `visibility_required`

#### blocked 特有字段
- `blocker`
- `recovery_suggestion`

#### waiting-user 特有字段
- `blocker`
- `next_action_hint`

#### completed 特有字段
- `result_summary`
- `verification_status`

---

## 谁负责生产事件

### `execution_started`
生产者：
- `promise-detector.js`
- 未来的恢复入口（如果是“恢复即开工”场景）

### `execution_blocked`
生产者：
- `execution-dispatcher.js`
- `state-store block`

### `execution_waiting_user`
生产者：
- `execution-dispatcher.js`
- `state-store wait`

### `execution_stale_detected`
生产者：
- `fake-execution-watchdog.js`
- `execution-dispatcher.js`（auto-stale 场景）

### `execution_completed`
生产者：
- `execution-dispatcher.js`
- `state-store complete`

---

## 谁负责消费事件

### 第一消费者：`execution-dispatcher.js`
职责：
- 读取未消费事件
- 做节流判断
- 生成最小用户可见回执
- 标记事件已消费

### 第二消费者：`longtask-reporting`
职责：
- 在需要更丰富模板时，根据事件类型输出更完整回执
- 不直接定义状态，只消费事件

---

## 为什么不要把每个状态变化直接写死在 dispatcher 分支里

因为那会导致：
- 状态逻辑和通知逻辑耦死
- 新增事件类型时需要改很多 if/else
- 很难统一节流和模板

统一事件层的好处是：
- 状态变化协议统一
- dispatcher 只消费事件
- reporting 只管模板
- 后续支持 strict / balanced / quiet 模式也更自然

---

## 最小落地顺序

### Phase 2.1
- 定义事件集合
- 明确生产者/消费者
- 不急着一次性全实现

### Phase 2.2
- 补 `execution_blocked`
- 补 `execution_waiting_user`

### Phase 2.3
- 补 `execution_stale_detected`
- 补 `execution_completed`

### Phase 2.4
- 统一节流/模板/模式配置

---

## 验收标准

当状态变化发生时，应满足：

1. 状态已经正确写入
2. 对应事件已生成
3. dispatcher 能识别未消费事件
4. 在允许外显场景下，能发出最小回执
5. 事件被消费后不会无限重复发送
6. 状态层仍然保持单一真源

---

## 一句话结论

> execution-state 二期真正该做的，不是继续给每个状态加特判，而是把关键状态变化统一升级成标准事件协议。
