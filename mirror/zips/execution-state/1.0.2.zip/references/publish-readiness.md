# 发布准备说明

## 目标
把 `execution-state` 作为一个可复用技能发布给别人使用时，优先保证：
- 不携带作者私人目标 ID / 账号 ID
- 不依赖作者本地私有路径以外的隐式环境
- 安装后能跑最小闭环自测

## 已满足

### 1) 技能本体默认值已去私人化
`skills/execution-state/scripts/execution-dispatcher.js` 现在默认：
- `EXECUTION_STATE_DELIVERY_CHANNEL=''`
- `EXECUTION_STATE_DELIVERY_TARGET=''`
- `EXECUTION_STATE_DELIVERY_ACCOUNT_ID=''`

如果未设置环境变量：
- dispatcher 仍可运行
- 自动对外消息会安全跳过（`missing-delivery-env`）
- 不会误发给作者本人

### 2) 最小闭环已验证通过
已跑通的主链路：
- `run_script`
- `verify_artifact`
- 队列自动消费
- stale 自动恢复
- 动作队列跑完后自动 `completed`

## 发布给别人前建议

### 必配环境变量（如果希望有自动对外回报）
```bash
export OPENCLAW_WORKSPACE="/your/workspace"
export EXECUTION_STATE_DELIVERY_CHANNEL="<your-channel>"
export EXECUTION_STATE_DELIVERY_TARGET="<your-target-id>"
export EXECUTION_STATE_DELIVERY_ACCOUNT_ID="<your-account-id>"
export EXECUTION_STATE_AGENT_ID="main"
```

### 如果不需要自动回报
可以只设置：
```bash
export OPENCLAW_WORKSPACE="/your/workspace"
```

这样技能仍然可以：
- 管理 execution-state
- 执行动作
- 恢复 stale
- 自动 completed

只是不会自动发用户可见消息。

### 通道无关原则
- skill 不应默认假设自己运行在微信/飞书/任一固定渠道
- 主动汇报必须回到**触发该 skill 的当前渠道**
- 因此投递信息应由运行时注入：`channel + target + accountId`

## 推荐的最小发布验收
安装后至少自测 1 次：

1. 初始化一条 action_queue：
   - `run_script`
   - `verify_artifact`
2. 强制 dispatcher 到检查点
3. 确认最终结果：
   - `status = completed`
   - `verification_status = verified`
   - `queue_len = 0`
   - `next_action_hint = ""`

## 当前能力边界
这个技能已经是轻量 durable execution 层，但不是完整工作流平台。

更适合：
- 多步骤任务执行态治理
- 长任务回报 / 恢复 / 收口
- 小中型动作链编排

暂不等价于：
- 通用 BPM / Temporal / Airflow
- 大规模分布式任务系统
- 高并发多租户编排平台
