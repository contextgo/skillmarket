---
name: execution-state
description: 将“我继续做 / 我接着处理”这类口头承诺落成真实执行的技能。用于多步骤任务、巡检、排查、修复链路、研究任务与长任务续接；负责承诺识别、执行态切换、复杂度判断、承载方式决策、假执行识别、恢复与收口。目标不是更会说，而是让执行可见、可恢复、可验收。
---

# execution-state

## 这是什么

`execution-state` 是一个**执行态治理 + 轻量 durable execution** 技能。

它专门修下面这类问题：

- 助手说了“我继续做”，但实际上没有继续执行
- 长任务没有切到合适的承载方式（尤其是 `longtask-reporting + 子代理`）
- 执行中断后，下一轮无法稳定恢复
- 已经进入执行态，但没有阶段回报、没有 blocker 外显、没有明确收口

一句话：

> **把“承诺 → 执行态 → 承载方式 → 推进/回报 → 收口”接成一条真的能跑的链路。**

它不是通用工作流平台，也不替代 OpenClaw 现有能力；它补的是“执行纪律和状态治理”这一层。

---

## 它负责什么，不负责什么

### `execution-state` 负责
- 承诺词识别
- 执行态切换
- 复杂度判断
- 承载方式决策
- 假执行识别
- stale / 中断后的恢复优先级
- 最小状态机与动作队列

### 它不替代这些能力
- **子代理执行** → `sessions_spawn` / `subagents`
- **长任务回执** → `longtask-reporting`
- **历史续接与记忆召回** → `continuity` / `memory_search`
- **外部 Hook 框架** → OpenClaw hooks

换句话说：
- `execution-state` 管“是不是已经进入真实执行，以及该怎么承载”
- `longtask-reporting` 管“怎么把执行过程对用户讲清楚”
- `continuity` 管“上次做到哪、为什么停、下一步是什么”

---

## 适用场景

当出现以下任一信号时，优先触发本技能：

### 1) 说出了执行承诺
包括但不限于：
- 我继续做
- 我接着处理
- 我来收尾
- 我下一步去做
- 我继续推进
- 我接着查
- 不需要你再同意我继续做

这些话**不是礼貌结束语**；一旦说出口，默认视为**进入执行态**。

### 2) 任务天然不是一步完成
典型场景：
- 多步骤任务
- 巡检
- 排查
- 修复链路
- 研究 / 调研
- 需要持续推进而主会话还要保持可交流
- 用户明确要求“实时汇报 / 不要等我催”

### 3) 用户抱怨执行纪律失守
例如：
- “你老说继续做但没做”
- “你为什么停了”
- “别等我提醒”
- “你怎么又失忆了 / 又断了”

---

## 不适用场景

以下情况一般**不需要**专门切入本技能：

- 单步、可立刻完成的小动作
- 纯问答、纯解释、纯判断题
- 明确需要先等用户授权/补充信息，且还没进入执行
- 只是给建议，还没承诺“我现在去做”

判断标准很简单：

> **如果任务不需要“持续推进、恢复、回报、收口”，就别把它搞复杂。**

---

## 核心原则

如果你只记一件事，就记这一句：**说了继续做，就必须进入真实执行。**


### 1. 承诺即执行
说了“继续做”，就必须真的进入执行，而不是停在语言层。

### 2. 执行态必须推进到一个真实节点
进入执行态后，至少推进到以下三者之一：
- 下一个状态变化点
- blocker
- 完成点

### 3. 重任务要切对承载方式
多步骤、巡检、排查、修复链路、研究任务，默认优先：
- `longtask-reporting`
- 子代理

### 4. 所有进展都要有执行证据
不能只说“我在做”；要能指向：
- 改了哪些文件
- 查了哪些日志 / 状态
- 跑了哪些命令 / 脚本
- 得到了什么结果

### 5. 先交可用版，再做优化版
先让任务收口，再考虑打磨。不要把“优化中”当成迟迟不交付的借口。

---

## 标准决策流程

## 第一步：判断是否进入执行态
如果已经说出承诺词，且任务路径清晰、无需新的外部授权，默认进入执行态。

## 第二步：判断复杂度
参考 `references/complexity-and-routing.md`：

- **轻任务**：主会话直接执行
- **中任务**：主会话执行 + `longtask-reporting`
- **重任务**：`longtask-reporting + 子代理`

### 默认优先开子代理的任务
- 多步骤任务
- 巡检
- 排查
- 修复链路
- 研究 / 调研
- 需要长时间跑，但主会话还要保持可交流
- 用户要求实时汇报
- 已经说了“我继续做”，且客观上不可能一步完成

## 第三步：保持执行可见性
一旦进入执行态：
- 开工要回
- 状态变化要回
- blocker 立即回
- 完成必须收口

## 第四步：防止假执行
如果已经说了继续做，但后面没有：
- 真正启动执行
- 切到正确承载方式
- 给出执行证据
- 给出有信息量的阶段回执
- 或合法 blocker 说明

那就属于**假执行风险高**，必须立即修正。

---

## 最小状态模型

本技能至少围绕这些状态工作：

- `idle`
- `executing`
- `blocked`
- `waiting-user`
- `stale`
- `completed`

如果你需要更精确地判断状态流转，读：
- `references/state-machine.md`

---

## 当前最小能力

当前版本已经不只是文档，还带了最小可用执行层：

### 状态层
- `runtime/execution-state/current.json`
- `runtime/execution-state/history/*.json`
- `runtime/execution-state/reports/*.json`
- `next_check_at / last_user_report_at / auto_state`
- `blocker / recovery_suggestion / next_action_hint / completed_at`

### 动作层
- `advance_step`
- `ask_user`
- `mark_blocked`
- `run_script`
- `verify_artifact`
- `spawn_subtask`

### 编排层
- `next_action`
- `action_queue`
- stale 自动恢复并再装填动作
- 队列跑完后自动 `completed`

### 通知层
- 自动阶段回报
- blocked / waiting-user / stale 外显
- 去重 / 节流
- 微信/私聊场景优先短汇报模板，避免长段废话

### 运行卫生
- `reports/` 只应作为热数据区，不应长期堆积
- 旧报告应按日期归档到 `archive/reports/YYYY-MM-DD/`
- 清理前优先 dry-run，避免误动当前排查证据
- 参考：`references/runtime-hygiene.md`

---

## 安装

### 最小安装
把整个 `execution-state/` 目录放进 skills 目录即可，建议保留结构：

```text
execution-state/
├── SKILL.md
├── references/
├── scripts/
└── hooks/
```

### 建议环境变量
如果工作区不是当前进程目录，建议设置：

```bash
export OPENCLAW_WORKSPACE="/your/workspace/path"
```

如果希望自动做用户可见回报，再补：

```bash
export EXECUTION_STATE_DELIVERY_CHANNEL="<your-channel>"
export EXECUTION_STATE_DELIVERY_TARGET="<your-target-id>"
export EXECUTION_STATE_DELIVERY_ACCOUNT_ID="<your-account-id>"
export EXECUTION_STATE_AGENT_ID="main"
```

### 可选启用项
- 启用 bootstrap 恢复提醒 Hook
- 接入 `execution-state-dispatcher`（建议每 5 分钟）
- 接入 `execution-state-watchdog`（建议每 15 分钟）

---

## 最小验收

安装后建议至少跑一次闭环自测：

### 单链路最小自测
1. 初始化一条 `action_queue`：
   - `run_script`
   - `verify_artifact`
2. 强制 dispatcher 到检查点
3. 确认最终结果：
   - `status = completed`
   - `verification_status = verified`
   - `queue_len = 0`
   - `next_action_hint = ""`

### 正式发布回归入口
如果你是在做发布前验收，直接跑：

```bash
node skills/execution-state/scripts/test-release-acceptance.js
```

当前会覆盖：
- 最小主链路
- `waiting-user` 分支
- 多次 `blocked -> recover`
- `spawn_subtask`
- 通道无关主动汇报（缺投递环境时安全跳过）

如果这组回归没跑通，就别急着说“技能可发布”。

---

## 常用脚本与命令

### 关键脚本
- `scripts/state-store.js`
- `scripts/promise-detector.js`
- `scripts/execution-state-cli.js`
- `scripts/execution-dispatcher.js`
- `scripts/fake-execution-watchdog.js`
- `scripts/test-release-acceptance.js`

### 发布前自查参考
- `references/release-preflight-checklist.md`

### 常用命令
```bash
node skills/execution-state/scripts/execution-state-cli.js promise "我继续做这个问题，先去排查日志和配置"
node skills/execution-state/scripts/execution-state-cli.js start "entered execution state"
node skills/execution-state/scripts/execution-state-cli.js update "checked logs and config"
node skills/execution-state/scripts/execution-state-cli.js block "waiting for permission"
node skills/execution-state/scripts/execution-state-cli.js complete "usable version delivered"
node skills/execution-state/scripts/execution-state-cli.js status
node skills/execution-state/scripts/execution-state-cli.js watchdog 10
node skills/execution-state/scripts/execution-state-cli.js dispatch
node skills/execution-state/scripts/state-store.js plan '{"goal":"...","steps":["a","b"],"action_queue":[{"type":"run_script","message":"do a","command":"/abs/path/script.sh"}]}'
```

---

## 推荐阅读路径

按问题读，不要一上来全读。

### 1) 要判断主会话做还是切子代理
读：
- `references/complexity-and-routing.md`

### 2) 要判断是不是假执行
读：
- `references/fake-execution.md`

### 3) 要看状态怎么流转
读：
- `references/state-machine.md`
- `references/lifecycle-acceptance.md`

### 4) 要继续把技能往自动化落地
读：
- `references/mvp-plan.md`

### 5) 要准备发布给别人用
读：
- `references/publish-readiness.md`
- `references/platform-publish-kit.md`
- `references/installer-checklist.md`
- `references/release-preflight-checklist.md`

### 6) 要接进我们自己的真实工作流
读：
- `references/real-workflow-integration.md`

### 7) 要持续演进而不是打补丁
读：
- `references/evolution-principles.md`

### 8) 要解决“说了继续做但用户没感知到开工”
读：
- `references/promise-to-visible-event.md`

### 9) 要把关键状态变化升级成统一事件层
读：
- `references/state-transition-events.md`

### 10) 要解决“阶段完成了但用户没感知到”
读：
- `references/stage-completion-event.md`

---

## 启用 Hook（可选）

如果你需要 bootstrap 恢复提醒，可将：

```text
hooks/openclaw/
```

复制到：

```text
~/.openclaw/hooks/execution-state/
```

然后执行：

```bash
openclaw hooks enable execution-state
```

---

## 发布给别人前，先清这几项

发布前至少确认：

1. **移除私人默认值**
   - 用户 ID
   - 账号 ID
   - 私有路径
   - 私有频道名

2. **通道相关配置改成环境变量驱动**
   - 不要把你自己的微信/飞书目标写死在技能里

3. **保留能力边界说明**
   - 它是轻量 durable execution 层，不是 BPM / Temporal / Airflow

4. **附最小验收用例**
   - `run_script -> verify_artifact -> auto complete`

5. **优先保证可移植性**
   - 默认让别人一装就能跑最小闭环
   - 自动对外通知缺少环境变量时，应该安全跳过，而不是误发

更细的发布检查见：
- `references/publish-readiness.md`

---

## 适用边界

这个技能适合：
- 多步骤任务执行态治理
- 长任务回报 / 恢复 / 收口
- 小中型动作链编排
- 防止“嘴上继续做，手上没执行”

这个技能**不等价于**：
- 通用 BPM 平台
- Airflow / Temporal 一类大型工作流系统
- 高并发多租户编排平台

别把它吹过头；它的价值就在于：**够轻、够准、够接地气。**

---

## 一句话总结

> `execution-state` 不是让代理“显得更主动”，而是让“继续做”这句话真的对应一段可见、可恢复、可验收的执行过程。
