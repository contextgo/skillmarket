"""
core/crypto.py — AES-256-GCM 加密/解密 + PBKDF2 密钥派生
所有加密操作集中在此模块
"""
from __future__ import annotations

import os, hashlib, base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

ITERATIONS = 100_000  # PBKDF2 迭代次数


def derive_key(master_password: str, salt: bytes) -> bytes:
    """PBKDF2-HMAC-SHA256 → 32 字节 AES-256 密钥"""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=ITERATIONS,
    )
    return kdf.derive(master_password.encode("utf-8"))


def encrypt_content(plaintext: bytes, key: bytes) -> tuple[bytes, bytes]:
    """
    AES-256-GCM 加密。
    返回 (ciphertext, nonce)
    - ciphertext: 密文（含 auth tag）
    - nonce: 12 字节随机数
    """
    nonce = os.urandom(12)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext, None)
    return ciphertext, nonce


def decrypt_content(ciphertext: bytes, key: bytes, nonce: bytes) -> bytes | None:
    """
    AES-256-GCM 解密。
    成功返回明文，失败返回 None（密钥错误或密文被篡改）
    """
    try:
        aesgcm = AESGCM(key)
        return aesgcm.decrypt(nonce, ciphertext, None)
    except Exception:
        return None


def generate_salt() -> bytes:
    """生成 16 字节随机盐"""
    return os.urandom(16)


def check_password(plaintext: bytes, ciphertext: bytes, nonce: bytes, salt: bytes, password: str) -> bool:
    """用给定密码验证密文能否正确解密"""
    key = derive_key(password, salt)
    result = decrypt_content(ciphertext, key, nonce)
    return result == plaintext


# ── DID 身份层 v1.2.20 ───────────────────────────────────────────

import secrets as _secrets
import hmac as _hmac
from cryptography.hazmat.primitives.asymmetric import ed25519 as _ed25519

# BIP-39 wordlist (2048 words)
_BIP39 = [
    "abandon","ability","able","about","above","absent","absorb","abstract","absurd","abuse",
    "access","accident","account","accuse","achieve","acid","acoustic","acquire","across","act",
    "action","actor","actress","actual","adapt","add","addict","address","adjust","admit","adult",
    "advance","advice","aerobic","affair","afford","afraid","again","age","agent","agree","ahead",
    "aim","air","airport","aisle","alarm","album","alcohol","alert","alien","all","alley","allow",
    "almost","alone","alpha","already","also","alter","always","amateur","amazing","among","amount",
    "amused","analyst","anchor","ancient","anger","angle","angry","animal","ankle","announce","annual",
    "another","answer","antenna","antique","anxiety","any","apart","apology","appear","apple","approve",
    "april","arch","arctic","area","arena","argue","arm","armed","armor","army","around","arrange",
    "arrest","arrive","arrow","art","artefact","artist","artwork","ask","aspect","assault","asset",
    "assist","assume","asthma","athlete","atom","attack","attend","attitude","attract","auction","audit",
    "august","aunt","author","auto","autumn","average","avocado","avoid","awake","aware","away","awesome",
    "awful","awkward","axis","baby","bachelor","bacon","badge","bag","balance","balcony","ball","bamboo",
    "banana","banner","bar","barely","bargain","barrel","base","basic","basket","battle","beach","bean",
    "beauty","because","become","beef","before","begin","behave","behind","believe","below","belt","bench",
    "benefit","best","betray","better","between","beyond","bicycle","bid","bike","bind","biology","bird",
    "birth","bitter","black","blade","blame","blanket","blast","bleak","bless","blind","blood","blossom",
    "blouse","blue","blur","blush","board","boat","body","boil","bomb","bone","bonus","book","boost",
    "border","boring","borrow","boss","bottom","bounce","box","boy","bracket","brain","brand","brass",
    "brave","bread","breeze","brick","bridge","brief","bright","bring","brisk","broccoli","broken","bronze",
    "broom","brother","brown","brush","bubble","buddy","budget","buffalo","build","bulb","bulk","bullet",
    "bundle","bunker","burden","burger","burst","bus","business","busy","butter","buyer","buzz","cabbage",
    "cabin","cable","cactus","cage","cake","call","calm","camera","camp","can","canal","cancel","candy",
    "cannon","canoe","canvas","canyon","capable","capital","captain","car","carbon","card","cargo","carpet",
    "carry","cart","case","cash","casino","castle","casual","cat","catalog","catch","category","cattle",
    "caught","cause","caution","cave","ceiling","celery","cement","census","century","cereal","certain",
    "chair","chalk","champion","change","chaos","chapter","charge","chase","chat","cheap","check","cheese",
    "chef","cherry","chest","chicken","chief","child","chimney","choice","choose","chronic","chuckle",
    "chunk","churn","cigar","cinnamon","circle","citizen","city","civil","claim","clap","clarify","claw",
    "clay","clean","clerk","clever","click","client","cliff","climb","clinic","clip","clock","clog","close",
    "cloth","cloud","clown","club","clump","cluster","clutch","coach","coast","coconut","code","coffee",
    "coil","coin","collect","color","column","combine","come","comfort","comic","common","company","concert",
    "conduct","confirm","congress","connect","consider","control","convince","cook","cool","copper","copy",
    "coral","core","corn","correct","cost","cotton","couch","country","couple","course","cousin","cover",
    "coyote","crack","cradle","craft","cram","crane","crash","crater","crawl","crazy","cream","credit",
    "creek","crew","cricket","crime","crisp","critic","crop","cross","crouch","crowd","crucial","cruel",
    "cruise","crumble","crunch","crush","cry","crystal","cube","culture","cup","cupboard","curious",
    "current","curtain","curve","cushion","custom","cute","cycle","dad","damage","damp","dance","danger",
    "daring","dash","daughter","dawn","day","deal","debate","debris","decade","december","decide","decline",
    "decorate","decrease","deer","defense","define","defy","degree","delay","deliver","demand","demise",
    "denial","dentist","deny","depart","depend","deposit","depth","deputy","derive","describe","desert",
    "design","desk","despair","destroy","detail","detect","develop","device","devote","diagram","dial",
    "diamond","diary","dice","diesel","diet","differ","digital","dignity","dilemma","dinner","dinosaur",
    "direct","dirt","disagree","discover","disease","dish","dismiss","disorder","display","distance",
    "divert","divide","divorce","dizzy","doctor","document","dog","doll","dolphin","domain","donate",
    "donkey","donor","door","dose","double","dove","draft","dragon","drama","drastic","draw","dream",
    "dress","drift","drill","drink","drip","drive","drop","drum","dry","duck","dumb","dune","during",
    "dust","dutch","duty","dwarf","dynamic","eager","eagle","early","earn","earth","easily","east","easy",
    "echo","ecology","economy","edge","edit","educate","effort","egg","eight","either","elbow","elder",
    "electric","elegant","element","elephant","elevator","elite","else","embark","embody","embrace","emerge",
    "emotion","employ","empower","empty","enable","enact","end","endless","endorse","enemy","energy",
    "enforce","engage","engine","enhance","enjoy","enlist","enough","enrich","enroll","ensure","enter",
    "entire","entry","envelope","episode","equal","equip","era","erase","erode","erosion","error","erupt",
    "escape","essay","essence","estate","eternal","ethics","evidence","evil","evoke","evolve","exact",
    "example","excess","exchange","excite","exclude","excuse","execute","exercise","exhaust","exhibit",
    "exile","exist","exit","exotic","expand","expect","expire","explain","expose","express","extend",
    "extra","eye","eyebrow","fabric","face","faculty","fade","faint","faith","fall","false","fame",
    "family","famous","fan","fancy","fantasy","farm","fashion","fat","fatal","father","fatigue","fault",
    "favorite","feature","february","federal","fee","feed","feel","female","fence","festival","fetch",
    "fever","few","fiber","fiction","field","figure","file","film","filter","final","find","fine",
    "finger","finish","fire","firm","first","fiscal","fish","fit","fitness","fix","flag","flame",
    "flash","flat","flavor","flee","flight","flip","float","flock","floor","flower","fluid","flush",
    "fly","foam","focus","fog","foil","fold","follow","food","foot","force","forest","forget","fork",
    "fortune","forum","forward","fossil","foster","found","fox","fragile","frame","frequent","fresh",
    "friend","fringe","frog","front","frost","frown","frozen","fruit","fuel","fun","funny","furnace",
    "fury","future","gadget","gain","galaxy","gallery","game","gap","garage","garbage","garden","garlic",
    "garment","gas","gasp","gate","gather","gauge","gaze","general","genius","genre","gentle","genuine",
    "gesture","ghost","giant","gift","giggle","ginger","giraffe","girl","give","glad","glance","glare",
    "glass","glide","glimpse","globe","gloom","glory","glove","glow","glue","goat","goddess","gold",
    "good","goose","gorilla","gospel","gossip","govern","gown","grab","grace","grain","grant","grape",
    "grass","gravity","great","green","grid","grief","grit","grocery","group","grow","grunt","guard",
    "guess","guide","guilt","guitar","gun","gym","habit","hair","half","hammer","hamster","hand",
    "happy","harbor","hard","harsh","harvest","hat","have","hawk","hazard","head","health","heart",
    "heavy","hedgehog","height","hello","helmet","help","hen","hero","hidden","high","hill","hint",
    "hip","hire","history","hobby","hockey","hold","hole","holiday","hollow","home","honey","hood",
    "hope","horn","horror","horse","hospital","host","hotel","hour","hover","hub","huge","human",
    "humble","humor","hundred","hungry","hunt","hurdle","hurry","hurt","husband","hybrid","ice","icon",
    "idea","identify","idle","ignore","ill","illegal","illness","image","imitate","immense","immune",
    "impact","impose","improve","impulse","inch","include","income","increase","index","indicate",
    "indoor","industry","infant","inflict","inform","inhale","inherit","initial","inject","injury",
    "inmate","inner","innocent","input","inquiry","insane","insect","inside","inspire","install",
    "intact","interest","into","invest","invite","involve","iron","island","isolate","issue","item",
    "ivory","jacket","jaguar","jar","jazz","jealous","jeans","jelly","jewel","job","join","joke",
    "journey","joy","judge","juice","jump","jungle","junior","junk","just","kangaroo","keen","keep",
    "ketchup","key","kick","kid","kidney","kind","kingdom","kiss","kit","kitchen","kite","kitten",
    "kiwi","knee","knife","knock","know","lab","label","labor","ladder","lady","lake","lamp",
    "language","laptop","large","later","latin","laugh","laundry","lava","law","lawn","lawsuit","layer",
    "lazy","leader","leaf","learn","leave","lecture","left","leg","legal","legend","leisure","lemon",
    "lend","length","lens","leopard","lesson","letter","level","liar","liberty","library","license",
    "life","lift","light","like","limb","limit","link","lion","liquid","list","little","live",
    "lizard","load","loan","lobster","local","lock","logic","lonely","long","loop","lottery","loud",
    "lounge","love","loyal","lucky","luggage","lumber","lunar","lunch","luxury","lyrics","machine",
    "mad","magic","magnet","maid","mail","main","major","make","mammal","man","manage","mandate",
    "mango","mansion","manual","maple","marble","march","margin","marine","market","marriage","mask",
    "mass","master","match","material","math","matrix","matter","maximum","maze","meadow","mean",
    "measure","meat","mechanic","medal","media","melody","melt","member","memory","mention","menu",
    "mercy","merge","merit","merry","mesh","message","metal","method","middle","midnight","milk",
    "million","mimic","mind","minimum","minor","minute","miracle","mirror","misery","miss","mistake",
    "mix","mixed","mixture","mobile","model","modify","mom","moment","monitor","monkey","monster",
    "month","moon","moral","more","morning","mosquito","mother","motion","motor","mountain","mouse",
    "move","movie","much","muffin","mule","multiply","muscle","museum","mushroom","music","must",
    "mutual","myself","mystery","myth","naive","name","napkin","narrow","nasty","nation","nature",
    "near","neck","need","negative","neglect","neither","nephew","nerve","nest","net","network",
    "neutral","never","news","next","nice","night","noble","noise","nominee","noodle","normal","north",
    "nose","notable","note","nothing","notice","novel","now","nuclear","number","nurse","nut","oak",
    "obey","object","oblige","obscure","observe","obtain","obvious","occur","ocean","october","odor",
    "off","offer","office","often","oil","okay","old","olive","olympic","omit","once","one","onion",
    "online","only","open","opera","opinion","oppose","option","orange","orbit","orchard","order",
    "ordinary","organ","orient","original","orphan","ostrich","other","outdoor","outer","output",
    "outside","oval","oven","over","own","owner","oxygen","oyster","ozone","pact","paddle","page",
    "pair","palace","palm","panda","panel","panic","panther","paper","parade","parent","park",
    "parrot","party","pass","patch","path","patient","patrol","pattern","pause","pave","payment",
    "peace","peanut","pear","peasant","pelican","pen","penalty","pencil","people","pepper","perfect",
    "permit","person","pet","phone","photo","phrase","physical","piano","picnic","picture","piece",
    "pig","pigeon","pill","pilot","pink","pioneer","pipe","pistol","pitch","pizza","place",
    "planet","plastic","plate","play","please","pledge","pluck","plug","plunge","poem","poet",
    "point","polar","pole","police","pond","pony","pool","popular","portion","position","possible",
    "post","potato","pottery","poverty","powder","power","practice","praise","predict","prefer",
    "prepare","present","pretty","prevent","price","pride","primary","print","priority","prison",
    "private","prize","problem","process","produce","profit","program","project","promote","proof",
    "property","prosper","protect","proud","provide","public","pudding","pull","pulp","pulse",
    "pumpkin","punch","pupil","puppy","purchase","purity","purpose","purse","push","put","puzzle",
    "pyramid","quality","quantum","quarter","question","quick","quit","quiz","quote","rabbit",
    "raccoon","race","rack","radar","radio","rail","rain","raise","rally","ramp","ranch","random",
    "range","rapid","rare","rate","rather","raven","raw","razor","ready","real","reason","rebel",
    "rebuild","recall","receive","recipe","record","recycle","reduce","reflect","reform","refuse",
    "region","regret","regular","reject","relax","release","relief","rely","remain","remember",
    "remind","remove","render","renew","rent","reopen","repair","repeat","replace","report",
    "require","rescue","resemble","resist","resource","response","result","retire","retreat",
    "return","reunion","reveal","review","reward","rhythm","rib","ribbon","rice","rich","ride",
    "ridge","rifle","right","rigid","ring","riot","ripple","risk","ritual","rival","river","road",
    "roast","robot","robust","rocket","romance","roof","rookie","room","rose","rotate","rough",
    "round","route","royal","rubber","rude","rug","rule","run","runway","rural","sad","saddle",
    "sadness","safe","sail","salad","salmon","salon","salt","salute","same","sample","sand",
    "satisfy","satoshi","sauce","sausage","save","say","scale","scan","scare","scatter","scene",
    "scheme","school","science","scissors","scorpion","scout","scrap","screen","script","scrub",
    "sea","search","season","seat","second","secret","section","security","seed","seek","segment",
    "select","sell","seminar","senior","sense","sentence","series","service","session","settle",
    "setup","seven","shadow","shaft","shallow","share","shed","shell","sheriff","shield","shift",
    "shine","ship","shiver","shock","shoe","shoot","shop","short","shoulder","shove","shrimp",
    "shrug","shuffle","shy","sibling","sick","side","siege","sight","sign","silent","silk",
    "silly","silver","similar","simple","since","sing","siren","sister","situate","six","size",
    "skate","sketch","ski","skill","skin","skirt","skull","slab","slam","sleep","slender","slice",
    "slide","slight","slim","slogan","slot","slow","slush","small","smart","smile","smoke",
    "smooth","snack","snake","snap","sniff","snow","soap","soccer","social","sock","soda","soft",
    "solar","soldier","solid","solution","solve","someone","song","soon","sorry","sort","soul",
    "sound","soup","source","south","space","spare","spatial","spawn","speak","special","speed",
    "spell","spend","sphere","spice","spider","spike","spin","spirit","split","spoil","sponsor",
    "spoon","sport","spot","spray","spread","spring","spy","square","squeeze","squirrel","stable",
    "stadium","staff","stage","stairs","stamp","stand","start","state","stay","steak","steel",
    "stem","step","stereo","stick","still","sting","stock","stomach","stone","stool","story",
    "stove","strategy","street","strike","strong","struggle","student","stuff","stumble","style",
    "subject","submit","subway","success","such","sudden","suffer","sugar","suggest","suit",
    "summer","sun","sunny","sunset","super","supply","supreme","sure","surface","surge","surprise",
    "surround","survey","suspect","sustain","swallow","swamp","swap","swarm","swear","sweet",
    "swift","swim","swing","switch","sword","symbol","symptom","syrup","system","table","tackle",
    "tag","tail","talent","talk","tank","tape","target","task","taste","tattoo","taxi","teach",
    "team","tell","ten","tenant","tennis","tent","term","test","text","thank","that","theme","then",
    "theory","there","they","thing","this","thought","three","thrive","throw","thumb","thunder",
    "ticket","tide","tiger","tilt","timber","time","tiny","tip","tired","tissue","title","toast",
    "tobacco","today","toddler","toe","together","toilet","token","tomato","tomorrow","tone",
    "tongue","tonight","tool","tooth","top","topic","topple","torch","tornado","tortoise","toss",
    "total","tourist","toward","tower","town","toy","track","trade","traffic","tragic","train",
    "transfer","trap","trash","travel","tray","treat","tree","trend","trial","tribe","trick",
    "trigger","trim","trip","trophy","trouble","truck","true","truly","trumpet","trust","truth",
    "try","tube","tuition","tumble","tuna","tunnel","turkey","turn","turtle","twelve","twenty",
    "twice","twin","twist","two","type","typical","ugly","umbrella","unable","unaware","uncle",
    "uncover","under","undo","unfair","unfold","unhappy","uniform","unique","unit","universe",
    "unknown","unlock","until","unusual","unveil","update","upgrade","uphold","upon","upper",
    "upset","urban","urge","usage","use","used","useful","useless","usual","utility","vacant",
    "vacuum","vague","valid","valley","valve","van","vanish","vapor","various","vast","vault",
    "vehicle","velvet","vendor","venture","venue","verb","verify","version","very","vessel","veteran",
    "viable","vibrant","vicious","victory","video","view","village","vintage","violin","virtual",
    "virus","visa","visit","visual","vital","vivid","vocal","voice","void","volcano","volume",
    "vote","voyage","wage","wagon","wait","walk","wall","walnut","want","warfare","warm","warrior",
    "wash","wasp","waste","water","wave","way","wealth","weapon","wear","weasel","weather","web",
    "wedding","weekend","weird","welcome","west","wet","whale","what","wheat","wheel","when",
    "where","whip","whisper","wide","width","wife","wild","will","win","window","wine","wing",
    "wink","winner","winter","wire","wisdom","wise","wish","witness","wolf","woman","wonder",
    "wood","wool","word","work","world","worry","worth","wrap","wreck","wrestle","wrist","write",
    "wrong","yard","year","yellow","you","young","youth","zebra","zero","zone","zoo",
]


def generate_mnemonic(bits: int = 256) -> str:
    """生成 BIP-39 助记词（24词=256-bit）"""
    raw = _secrets.token_bytes(bits // 8)
    h_hex = hashlib.sha256(raw).hexdigest()
    cs_bits = len(raw) // 4
    h_bin = bin(int.from_bytes(raw, "big"))[2:].zfill(len(raw) * 8)
    chk_bin = "".join(f"{int(c, 16):04b}" for c in h_hex)
    full_bin = h_bin + chk_bin[:cs_bits]
    indices = [int(full_bin[i:i+11], 2) for i in range(0, len(full_bin), 11)]
    return " ".join(_BIP39[i] for i in indices)


def validate_mnemonic(mnemonic: str) -> bool:
    """验证 BIP-39 助记词有效性"""
    wlist = mnemonic.lower().split()
    if len(wlist) not in (12, 24):
        return False
    if not all(w in _BIP39 for w in wlist):
        return False
    bits = len(wlist) * 11
    cs_bits = bits // 32
    ent_bits = bits - cs_bits
    idx = 0
    for w in wlist:
        idx = (idx << 11) | _BIP39.index(w)
    ent_bytes = (idx >> cs_bits).to_bytes(ent_bits // 8, "big")
    expected_cs = hashlib.sha256(ent_bytes).digest()[0] >> (8 - cs_bits)
    actual_cs = idx & ((1 << cs_bits) - 1)
    return actual_cs == expected_cs


def mnemonic_to_master(mnemonic: str, email: str = "") -> bytes:
    """从助记词派生主密钥（PBKDF2-SHA512, 2048轮）"""
    salt = ("mnemonic" + email).encode("utf-16-le")
    return hashlib.pbkdf2_hmac("sha512", mnemonic.encode(), salt, 2048, dklen=32)


def derive_identity_keypair(master_secret: bytes):
    """派生身份密钥对"""
    priv_bytes = _hmac.new(master_secret, b"amber-identity-key", hashlib.sha256).digest()
    priv = _ed25519.Ed25519PrivateKey.from_private_bytes(priv_bytes)
    return priv, priv.public_key()


def derive_device_key(master_secret: bytes, device_uuid: str):
    """派生设备密钥"""
    priv_bytes = _hmac.new(master_secret, ("amber-device-key" + device_uuid).encode(), hashlib.sha256).digest()
    priv = _ed25519.Ed25519PrivateKey.from_private_bytes(priv_bytes)
    return priv, priv.public_key()


def pubkey_to_did(pub_key) -> str:
    """公钥转 DID 字符串"""
    from cryptography.hazmat.primitives import serialization
    raw = pub_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    b64 = base64.urlsafe_b64encode(raw).rstrip(b"=").decode()
    return "did:amber:" + b64


def privkey_to_hex(priv_key) -> str:
    """私钥转十六进制字符串"""
    return priv_key.private_bytes_raw().hex()


def pubkey_to_hex(pub_key) -> str:
    """公钥转十六进制字符串"""
    from cryptography.hazmat.primitives import serialization
    raw = pub_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    return raw.hex()


def derive_capsule_key(device_priv_hex: str, capsule_id: str) -> tuple:
    """
    从设备私钥（hex）和胶囊 ID 派生胶囊加密密钥。
    与 did.py 的 derive_capsule_key 等价（本地版本）。
    返回 (aes_key, mac_key)：aes_key 用于 AES-256-GCM，mac_key 备用。
    """
    import hmac as _hmac
    priv_bytes = bytes.fromhex(device_priv_hex)
    key = _hmac.new(priv_bytes, ("amber-capsule-key" + capsule_id).encode(), hashlib.sha256).digest()
    aes_key = key[:32]    # AES-256
    mac_key = key[32:64]  # HMAC key (备用)
    return aes_key, mac_key
