---
description: Schedule tasks, manage priorities, resolve conflicts, and handle time zones. Auto-optimizes your agent's workload and prevents double-booking.
keywords: task scheduler, priority queue, calendar management, timezone conversion, conflict detection, schedule optimization, deadline tracking
name: intelligent-scheduler
triggers: schedule task, add to calendar, check conflicts, reschedule, priority queue, timezone convert
---

# intelligent-scheduler

> Schedule tasks intelligently. Handle priorities, time zones, and conflicts automatically — never miss a deadline or double-book again.

## What It Does

Manage your agent's time like a pro:

- **Task scheduling** — Add tasks with deadlines and priorities
- **Priority queues** — Critical tasks always come first
- **Conflict detection** — Auto-detect overlapping commitments
- **Timezone handling** — Schedule across multiple time zones seamlessly
- **Smart rescheduling** — Auto-fill gaps and optimize your calendar

---

## Quick Start

```bash
# 1. Schedule a high-priority task
node scheduler.js add "Review PR #42" --time "14:00" --priority high

# 2. Check for conflicts today
node scheduler.js check-conflicts --date today

# 3. View prioritized queue
node scheduler.js queue --sort priority

# 4. Convert meeting time for remote team
node scheduler.js convert "14:00 Asia/Shanghai" --to "America/New_York"
# → 01:00 EDT (next day)
```

---

## Common Use Cases

### 📋 Daily Task Prioritization
```bash
# Add tasks with priorities
node scheduler.js add "Fix critical bug" --priority critical
node scheduler.js add "Update documentation" --priority medium
node scheduler.js add "Research new library" --priority low

# View queue sorted by priority
node scheduler.js queue --sort priority
# → 1. Fix critical bug (critical)
# → 2. Update documentation (medium)
# → 3. Research new library (low)
```

### 🌍 Multi-Timezone Meeting Coordination
```bash
# Schedule meeting in your timezone
node scheduler.js add "Client call" --time "2024-03-15 09:00" --tz "America/New_York"

# Check what time that is for your teammate in Tokyo
node scheduler.js convert "2024-03-15 09:00 America/New_York" --to "Asia/Tokyo"
# → 22:00 JST (same day)
```

### ⚠️ Prevent Double-Booking
```bash
# Add two overlapping events
node scheduler.js add "Team standup" --time "09:00" --duration 30
node scheduler.js add "Client call" --time "09:15" --duration 45

# Detect conflicts
node scheduler.js check-conflicts --date today
# → CONFLICT: "Team standup" (09:00-09:30) overlaps "Client call" (09:15-10:00)
```

### 🔄 Auto-Optimize Schedule
```bash
# Fill gaps and reschedule around priorities
node scheduler.js auto-reschedule --fill-gaps --respect-priority
# Moves low-priority tasks to fill empty slots
# Keeps critical tasks at preferred times
```

---

## All Commands

| Command | Purpose |
|---------|---------|
| `add "task" --time X` | Schedule a task |
| `queue --sort priority` | View prioritized task list |
| `promote "task" --to critical` | Change task priority |
| `check-conflicts --date X` | Find scheduling conflicts |
| `convert "time" --to TZ` | Convert between time zones |
| `auto-reschedule` | Optimize schedule automatically |

---

## Priority Levels

```
critical > high > medium > low > deferred
```

Use `critical` for outages and deadlines. Use `deferred` for "someday" tasks.

---

## Configuration

```json
// .scheduler/config.json
{
  "timezone": "Asia/Shanghai",
  "workHours": { "start": "09:00", "end": "18:00" },
  "bufferMinutes": 15,
  "rules": [
    "No meetings before 10:00 on Mondays",
    "Reserve Friday afternoons for deep work",
    "Critical tasks always scheduled first"
  ]
}
```

---

## Examples

**Schedule with dependency:**
```bash
node scheduler.js add "Review PR" --time "14:00" --priority high
node scheduler.js add "Deploy after review" --time "16:00" --depends "Review PR"
```

**Filter today's tasks:**
```bash
node scheduler.js queue --filter today
```

**Respect work hours:**
```bash
node scheduler.js add "Urgent task" --time "20:00" --respect-work-hours false
```
