# 发票经济风控指标 V2 使用指南 📊
> 一键扫描发票风险，智能评级，助力合规经营
---
## 🚨 重要声明
本工具仅用于**合规性自查与风险预警**，所有测试案例中的企业名称均已做**脱敏处理**，不代表任何实际企业的信用状况，如有雷同纯属巧合。使用本工具即表示您同意合规使用，作者不承担因不当使用带来的任何法律责任。
---
## 🚀 快速开始：三步完成一次风险扫描
### Step 1: 环境准备
确保您已解压压缩包，并进入项目目录：
```bash
cd invoice-economy-risk-ctrl
```
Python 环境要求：Python 3.8+，无需额外安装依赖（仅使用标准库）。
### Step 2: 运行扫描脚本
我们提供了**开箱即用**的测试脚本，直接运行即可看到效果：
```bash
# AiPy 环境兼容版
python scripts/run_risk_scan.py
```
> 💡 如果遇到 `__file__ not defined` 错误，请使用修复版：
> ```bash
> python run_risk_scan_fixed.py
> ```
### Step 3: 查看报告
脚本会自动输出风险扫描报告，格式如下：
```
==============================
📊 风险扫描报告
==============================
综合得分：50 分
风险等级：【P2_MEDIUM】
命中风险点数：2
------------------------------
🔴 指标 R003: 顶格开票占比 80.00%
🔴 指标 R002: 当前税负率 1.00%, 警戒线 2%
------------------------------
💡 专家建议：⚡ 限期补充资料，核实业务真实性！
==============================
```
---
## 📋 如何接入您自己的数据？
### 方式一：从 CSV/Excel 文件读取
修改 `scripts/run_risk_scan.py` 中的数据读取部分：
```python
import pandas as pd
# 从 Excel 读取
df = pd.read_excel('your_invoices.xlsx')
invoices = df.to_dict('records')
# 从 CSV 读取
df = pd.read_csv('your_invoices.csv')
invoices = df.to_dict('records')
# 填入上下文信息
context = {
    "sales": 1000000,   # 年销售额
    "tax": 10000        # 已缴税额
}
```
### 方式二：Python 代码集成调用
在您自己的项目中直接调用风控引擎：
```python
import sys
import os
# 添加 core 路径
sys.path.insert(0, os.path.join(os.getcwd(), 'invoice-economy-risk-ctrl', 'core'))
from risk_engine import RiskEngine
from scoring_model import RiskScoringModel
# 1. 初始化引擎（只需要初始化一次）
engine = RiskEngine()
model = RiskScoringModel()
# 2. 准备您的数据
invoices = [
    {"id": 1, "amount": 99999.99, "item": "品名1"},
    {"id": 2, "amount": 15000.00, "item": "品名2"},
    # ... more
]
context = {"sales": 1000000, "tax": 15000}
# 3. 执行计算 & 获取结果
calc_results = engine.calculate(invoices, context)
report = model.evaluate(calc_results)
print(f"风险等级：{report['level']}")
print(f"命中风险：{report['risk_count']}")
print(f"专家建议：{report['suggestion']}")
```
### 方式三：部署为 Web API（进阶）
使用 Flask 快速封装成 API 服务：
```python
from flask import Flask, request, jsonify
app = Flask(__name__)
engine = RiskEngine()
model = RiskScoringModel()
@app.route('/api/scan', methods=['POST'])
def scan():
    data = request.json
    results = engine.calculate(data['invoices'], data['context'])
    report = model.evaluate(results)
    return jsonify(report)
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
```
访问 `http://localhost:5000` 即可通过 HTTP 调用。
---
## 🎯 风险等级说明
| 等级 | 得分范围 | 含义 | 建议 |
|------|----------|------|------|
| P0 **SAFE** | 80 ~ 100 | 低风险 | ✅ 合规，正常经营 |
| P1 **LOW** | 65 ~ 79 | 轻度风险 | ⚠️ 关注指标变化 |
| P2 **MEDIUM** | 40 ~ 64 | 中度风险 | ⚡ 限期核实业务 |
| P3 **HIGH** | 0 ~ 39 | 高度风险 | 🚨 暂停开票，全面自查 |
---
## 🔍 支持的风险指标
目前内置 **13 项核心风险指标**，覆盖：
- ✅ **金额异常类**：顶格开票、整额开票、销货方顶额
- ✅ **进销项不匹配**：品名差异、金额偏差、产能不符
- ✅ **占比异常类**：顶占比偏离、夜间开票率
- ✅ **税负异常类**：税负率偏离、长期零申报
完整指标列表见 `docs/knowledge-base/indicators-v2.md`
---
## 📌 脱敏说明
为保护企业隐私，本知识库所有测试案例中：
- 真实企业名称已替换为 `**县 ***商贸有限公司` 格式
- 真实税号已隐去，仅保留脱敏格式
- 数据均为模拟数据，不对应任何实际企业
如果您需要使用真实数据进行自查，请确保您已获得合法授权。
---
## ❓ 常见问题
**Q1: 运行提示模块找不到怎么办？**
A: 请确保你在正确的目录，并将 `core` 目录加入 `sys.path`，本文提供的 `run_risk_scan_fixed.py` 已修复此问题。
**Q2: 我可以自定义指标吗？**
A: 当然可以！在 `indicators-v2.md` 中按照原有格式添加新指标，引擎会自动读取并计算，无需修改代码。
**Q3: 这个工具可以替代税务师吗？**
A: 不能。本工具仅提供风险预警和辅助分析，最终判断仍需由专业税务人员或法务人员确认。
---
## 💬 联系方式
🌹有问题、建议、需求可📧 联系作者QQ：1817694478🐧加Q群：972156177交流分享更多...