# Install OpenClaw Master Skills

The full collection of 1,209+ skills is available at:
https://github.com/LeoYeAI/openclaw-master-skills

## Quick install
```bash
git clone https://github.com/LeoYeAI/openclaw-master-skills
cp -r openclaw-master-skills/skills/* ~/.openclaw/workspace/skills/
```

## Or browse and install individual skills via ClawHub
Each skill in the collection is from the openclaw/skills archive.
