"""Integrations for Novada Search."""
