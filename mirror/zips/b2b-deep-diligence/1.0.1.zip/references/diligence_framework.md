# B2B客户深度背调7步框架

## 框架总览

```
Step 1: 公司基本信息  ──→  Step 2: 产品与供应链  ──→  Step 3: 市场与竞争
                                                              │
                                                              ▼
Step 7: 输出Word报告  ←──  Step 6: 开发建议  ←──  Step 5: 痛点推断
         ↑                          ↑
         └── Step 4: 财务与风险评估 ─┘
```

## Step 1: 公司基本信息

### 1.1 公司身份与架构

| 检查项 | 搜索关键词示例 | 优先数据源 |
|--------|----------------|------------|
| 公司全称 | `"{公司名} company full name legal entity"` | 官网About Us、LinkedIn |
| 成立年份 | `"{公司名} founded year established"` | 官网、RocketReach |
| 公司性质 | `"{公司名} private public LLC Inc."` | 州商务局、LinkedIn |
| 总部地址 | `"{公司名} headquarters address location"` | 官网、Google Maps |
| 仓库/办公 | `"{公司名} warehouse office locations"` | 官网、Google搜索 |
| CEO/高管 | `"{公司名} CEO owner founder leadership team"` | LinkedIn、RocketReach、The Org |
| 员工数 | `"{公司名} employees headcount {当前年份}"` | RocketReach、Growjo、LinkedIn |
| 联系方式 | `"{公司名} phone email contact"` | 官网 |
| 母公司/子公司 | `"{公司名} parent company subsidiary acquisition"` | Crunchbase、The Org |
| 注册信息 | `"{公司名} incorporation state filing"` | 州务卿网站（US）、Companies House（UK） |

### 1.2 营收规模

| 检查项 | 搜索关键词示例 | 优先数据源 |
|--------|----------------|------------|
| 营收估算 | `"{公司名} revenue annual sales {当前年份}"` | RocketReach、Growjo、Owler、ZoomInfo |
| 增长率 | `"{公司名} growth rate fastest growing"` | 本地商业期刊、Inc. 5000 |
| 融资 | `"{公司名} funding investment raised series"` | Crunchbase、PitchBook |
| 估值 | `"{公司名} valuation worth"` | PitchBook、Forbes |

**营收交叉验证规则：**
- 至少获取3个来源的数据
- 如果最高值/最低值差异>3倍，取中位数区间
- 标注每个来源的可信度：RocketReach > Growjo > Owler > ZoomInfo预估
- 区分"营收(Revenue)"和"GMV(交易额)"——电商企业尤需注意

### 1.3 发展历程

| 检查项 | 搜索关键词 |
|--------|-----------|
| 关键里程碑 | `"{公司名} history milestone timeline"` |
| 渠道演变 | `"{公司名} eBay Amazon platform evolution"` |
| 产品线扩展 | `"{公司名} product line expansion new category launch"` |
| 收购/合并 | `"{公司名} acquisition merger buyout"` |
| 管理层变动 | `"{公司名} CEO change leadership transition"` |

### 1.4 商业模式

分析框架：
- **自有品牌 vs 代理品牌**比例
- **直销 vs 分销**渠道比例
- **设备 vs 耗材**收入比例（"剃须刀+刀片"模型）
- **B2B vs B2C**客户结构
- **线上 vs 线下**渠道占比

## Step 2: 产品与供应链

### 2.1 产品线分析

对每个产品品类需采集：

| 维度 | 内容 |
|------|------|
| 品牌/系列名 | 自有品牌 vs 代理品牌 |
| 型号示例 | 具体型号和规格 |
| 价格区间 | 最低价-最高价(USD) |
| 市场定位 | 入门级/中端/专业级/工业级 |
| 库存状态 | In Stock / Out of Stock / Pre-order |
| 折扣信息 | 原价 vs 现价，折扣率 |
| 新品标记 | 标注"NEW"的品类→新增供应商线索 |

### 2.2 供应链推断

| 维度 | 推断方法 |
|------|----------|
| 自有品牌制造来源 | 对比Alibaba/1688同款产品→中国OEM |
| 代理品牌 | 查官网授权经销商页面 |
| 新增供应商 | 产品标注"NEW"的品类 |
| 电商平台 | 查技术栈（BuiltWith/Wappalyzer） |
| 物流体系 | 查仓库地址→FedEx/UPS枢纽推断 |
| 多渠道 | 搜索品牌+Amazon/eBay/Walmart |
| 原产地标识 | 产品页面是否标注"Made in China"/"Made in USA"等 |

### 2.3 供应链风险信号

| 信号 | 含义 |
|------|------|
| 大量产品缺货 | 库存管理混乱或供应链中断 |
| 同一品类多个品牌 | 供应商分散，替换空间大 |
| 产品图片为Alibaba通用图 | 高度依赖中间商 |
| 频繁折扣促销 | 库存周转慢或现金流压力 |
| 品牌突然消失 | 供应商关系断裂 |

## Step 3: 市场与竞争

### 3.1 市场规模

| 检查项 | 搜索关键词 |
|--------|-----------|
| 全球市场规模 | `"{行业} market size global {当前年份}"` |
| 增长率 | `"{行业} CAGR growth forecast {当前年份+5}"` |
| 区域市场规模 | `"{行业} {区域} market size revenue"` |
| 细分市场 | `"{行业} segment share distribution"` |

### 3.2 竞争格局

对每个竞争对手采集：

| 维度 | 内容 |
|------|------|
| 公司名称 | 全称 |
| 公司性质 | 制造商/分销商/电商/零售商 |
| 规模/营收 | 估算 |
| 优势 | 核心竞争力 |
| 劣势 | 短板 |
| 市场份额 | 估算（如有） |
| 与目标客户关系 | 合作/竞争/替代 |

### 3.3 口碑分析

必须检查的平台：

| 平台 | 搜索关键词 | 重要性 | 适用市场 |
|------|-----------|--------|----------|
| Trustpilot | `"{公司名} site:trustpilot.com"` | 高 | 全球 |
| ResellerRatings | `"{公司名} site:resellerratings.com"` | 高 | 北美电商 |
| BBB | `"{公司名} site:bbb.org"` | 高 | 北美权威 |
| Google Reviews | `"{公司名} reviews"` | 中 | 全球 |
| Yelp | `"{公司名} site:yelp.com"` | 中 | 北美 |
| Reddit | `"{公司名} site:reddit.com"` | 中 | 真实用户反馈 |
| Glassdoor | `"{公司名} site:glassdoor.com"` | 中 | 员工/内部视角 |
| Amazon Reviews | `"{公司名} site:amazon.com"` | 中 | 产品口碑 |
| 行业论坛 | `"{公司名} site:{行业论坛域名}"` | 低-中 | 深度用户 |

### 3.4 行业趋势

| 检查项 | 搜索关键词 |
|--------|-----------|
| 技术趋势 | `"{行业} technology trend innovation {当前年份}"` |
| 政策法规 | `"{行业} regulation compliance {目标市场}"` |
| 消费者行为 | `"{行业} consumer trend demand shift"` |
| 供应链变化 | `"{行业} supply chain disruption {当前年份}"` |

## Step 4: 财务与风险评估（新增）

### 4.1 财务健康度

| 检查项 | 搜索关键词 | 数据源 |
|--------|-----------|--------|
| 营收趋势 | `"{公司名} revenue growth trend year over year"` | RocketReach、ZoomInfo |
| 利润率推断 | `"{公司名} profit margin industry average"` | 行业报告 |
| 现金流信号 | `"{公司名} funding round investment debt"` | Crunchbase、PitchBook |
| 融资历史 | `"{公司名} raised funding series"` | Crunchbase |
| 信用评级 | `"{公司名} credit rating D&B"` | Dun & Bradstreet |

### 4.2 关税与贸易风险

| 检查项 | 搜索关键词 |
|--------|-----------|
| 适用的关税税率 | `"{产品类别} HS code tariff rate {目标国} {当前年份}"` |
| 反倾销调查 | `"{产品类别} antidumping duty {目标国}"` |
| 贸易政策变化 | `"{目标国} trade policy import regulation {当前年份}"` |
| 自由贸易协定 | `"{原产国} {目标国} FTA free trade agreement"` |

### 4.3 法律与合规风险

| 检查项 | 搜索关键词 |
|--------|-----------|
| 诉讼记录 | `"{公司名} lawsuit litigation court case"` |
| 监管处罚 | `"{公司名} FTC FDA violation fine penalty"` |
| 知识产权 | `"{公司名} patent trademark infringement"` |
| 数据合规 | `"{公司名} GDPR CCPA data privacy"` |

### 4.4 ESG评估

| 检查项 | 搜索关键词 |
|--------|-----------|
| 环保认证 | `"{公司名} ISO 14001 sustainability green"` |
| 社会责任 | `"{公司名} CSR social responsibility community"` |
| 治理结构 | `"{公司名} board governance compliance"` |

### 4.5 风险矩阵

| 可能性 \ 影响度 | 低影响 | 中影响 | 高影响 |
|----------------|--------|--------|--------|
| **高可能性** | 🟡监控 | 🟠重视 | 🔴关键 |
| **中可能性** | 🟢关注 | 🟡监控 | 🟠重视 |
| **低可能性** | ⚪忽略 | 🟢关注 | 🟡监控 |

## Step 5: 痛点推断

### 痛点评级标准

| 级别 | 标识 | 紧急度 | 重要度 | 说明 |
|------|------|--------|--------|------|
| 高 | 🔴 | ★★★★★ | ★★★★★ | 必须立即解决，影响核心业务 |
| 中 | 🟡 | ★★★★☆ | ★★★★☆ | 重要但不紧急，需持续关注 |
| 低 | 🟢 | ★★★☆☆ | ★★★☆☆ | 长期风险，可延后处理 |

### 通用痛点检查清单（扩展版）

1. **关税/政策风险** — 进口关税、贸易政策变化、反倾销
2. **品质/口碑问题** — 差评率、DOA率、退货率
3. **库存管理** — 缺货率、SKU数量、折扣频率
4. **产品同质化** — OEM产品与市场同款对比
5. **技术迭代** — 新技术对现有产品线的冲击
6. **客服能力** — 团队规模vs业务量
7. **供应链依赖** — 单一供应商风险、交期不稳
8. **财务压力** — 现金流、利润率压缩
9. **合规风险** — 产品认证缺失、数据合规
10. **人才/组织** — 关键岗位流失、管理混乱
11. **渠道冲突** — 线上线下价格战、代理矛盾
12. **市场收缩** — 细分市场萎缩、需求转移

### 每个痛点需包含

- 痛点表现（具体描述）
- 推断依据（数据+逻辑）
- 客户需求（从痛点反推）
- 建议切入点（具体方案）

## Step 6: 开发建议

### 6.1 联系话术

准备2-3套话术，每套针对不同痛点切入：
- 话术1：成本/效率角度（推荐首选）
- 话术2：品质/服务改善角度
- 话术3：差异化/新品角度

**话术撰写原则：**
- 不提客户差评（避坑原则）
- 不在首次沟通中暴露背调信息
- 从客户痛点出发，而非从自己的产品出发
- 给出具体数字而非空洞承诺
- 5秒原则：开头5秒必须抓住注意力

### 6.2 产品推荐

按优先级排序，每项包含：
- 优先级（第一→第四）
- 推荐产品/服务
- 推荐理由
- 预估单笔订单额

### 6.3 顾虑应对

| 常见顾虑 | 分析 | 应对思路 |
|---------|------|---------|
| 已有稳定供应商 | 既有关系深 | 从"补充供应商"切入 |
| 价格极度敏感 | 低价定位 | 强调"总拥有成本(TCO)" |
| 关税不确定性 | 政策波动 | 灵活贸易条款 |
| 信任门槛高 | 新供应商考察期长 | 免费样品+工厂参观+视频验厂 |
| 品牌保护 | 担心代工厂竞争 | NDA+品牌保护协议 |
| 交期要求严 | 季节性/促销备货 | 安全库存+快速响应机制 |
| 认证要求高 | 目标市场准入 | 提供认证支持+合规文档 |
| 起订量高 | 小批量试单需求 | 阶梯式MOQ+样品单 |

### 6.4 决策链推断

| 角色 | 关注KPI | 采购关注点 |
|------|---------|-----------|
| CEO/总裁 | 营收增长、利润率 | 总体战略、风险控制 |
| 采购总监 | 成本降低%、交期准时率 | 价格、交期、质量 |
| 营销总监 | 销售额、客户满意度 | 产品差异化、市场响应速度 |
| 运营总监 | 库存周转率、缺货率 | 供应链稳定性、响应速度 |
| 技术总监 | 产品合格率、技术领先 | 技术参数、创新速度 |

### 6.5 联系渠道建议

| 渠道 | 适用场景 | 优先级 |
|------|---------|--------|
| LinkedIn | 决策人直接触达 | ★★★★★ |
| Email | 正式商业沟通 | ★★★★☆ |
| 展会 | 行业面对面 | ★★★★☆ |
| 电话 | 紧急/跟进 | ★★★☆☆ |
| 社交媒体 | 品牌认知预热 | ★★☆☆☆ |

## Step 7: 供应商匹配度分析（可选，需用户配置）

### 7.1 匹配逻辑

仅当用户已配置 `assets/user_profile.json` 时执行此步骤：
1. 读取用户产品品类列表
2. 逐一与目标客户的产品线比对
3. 标记可供应（✅）/ 不可供应（❌）/ 部分可供应（🔶）
4. 对可供应品类评估匹配强度

### 7.2 匹配评估维度

| 维度 | 权重 | 评估方法 |
|------|------|---------|
| 产品匹配度 | 30% | 品类重合度 × 供应强度 |
| 规模匹配度 | 20% | 客户体量 vs 供应商产能 |
| 痛点匹配度 | 25% | 客户痛点 vs 供应商优势 |
| 竞争匹配度 | 15% | 供应商 vs 现有供应商的差异化 |
| 合作难度 | 10% | 关税/物流/认证门槛 |

## 数据时效与更新规则

### 数据标注要求

| 数据类型 | 更新频率 | 过期判定 |
|---------|---------|---------|
| 营收/员工 | 每年 | >2年未更新 |
| 市场规模 | 每年 | >1年未更新 |
| 关税税率 | 每季度 | 政策变更即过期 |
| 口碑评分 | 每月 | >6个月未更新 |
| 竞争格局 | 每半年 | >1年未更新 |
| 技术趋势 | 每季度 | >1年未更新 |
| 法律/合规 | 实时 | 任何变更即过期 |

### 搜索年份策略

搜索关键词必须包含年份标记以确保数据时效性：
- 当前数据：使用当前年份和上一年份
- 趋势数据：使用近3年范围
- 预测数据：标注预测机构和预测基准年

示例：
- ✅ `"USCutter revenue 2025 2026"`
- ✅ `"heat press market size CAGR 2024-2030"`
- ❌ `"USCutter revenue"` (无年份，可能返回过时数据)

## JSON数据文件Schema

```json
{
  "country": "美国",
  "company_domain": "example.com",
  "website": "www.example.com",
  "report_date": "2026-05-06",
  "data_validity_date": "2026-05-06",
  "next_update_suggested": "2026-08-06",

  "basic_info": {
    "公司全称": "Example Corp, Inc.",
    "成立时间": "2005年",
    "公司性质": "Private / LLC",
    "总部地址": "...",
    "仓库/办公": "...",
    "CEO/总裁": "...",
    "员工数": "...",
    "联系方式": "..."
  },

  "revenue_data": [
    ["RocketReach", "$25.8M", "57人", "可能包含GMV", "2025-12"]
  ],
  "revenue_conclusion": "...",
  "revenue_trend": "增长/持平/下降",

  "timeline": [
    ["2005年", "公司成立"]
  ],

  "business_model_desc": "...",
  "business_model_formula": "自有品牌 + 代理品牌 + 电商直销",
  "business_model_points": ["..."],

  "product_lines": [
    {
      "title": "2.1 产品线名称",
      "headers": ["品牌/系列", "型号", "价格", "定位", "特征"],
      "rows": [["...", "...", "...", "...", "..."]],
      "col_widths": [3, 3, 3, 2.5, 4],
      "findings": ["..."]
    }
  ],

  "supply_chain": [
    ["维度", "推断结论", "依据"]
  ],
  "supply_chain_risks": [
    ["风险信号", "具体表现", "推断含义"]
  ],

  "market_size": [
    ["指标", "数据", "来源", "数据年份"]
  ],
  "market_conclusion": "...",

  "competitors": [
    ["竞争对手", "公司性质", "规模/营收", "优势", "劣势"]
  ],

  "swot": [
    ["维度", "优势", "劣势"]
  ],

  "industry_trends": [
    ["趋势类别", "具体趋势", "影响评估", "数据来源"]
  ],

  "reviews": [
    ["平台", "评分", "评论数", "主要问题", "数据日期"]
  ],
  "review_conclusion": "...",

  "financial_health": [
    ["指标", "数据/推断", "依据", "数据日期"]
  ],

  "tariff_risks": [
    ["产品类别", "HS Code", "关税税率", "政策变化风险"]
  ],

  "legal_risks": [
    ["风险类型", "描述", "严重程度", "数据来源"]
  ],

  "risk_matrix": [
    ["风险项", "可能性", "影响度", "等级", "应对建议"]
  ],

  "pain_points": [
    {
      "title": "痛点1：...",
      "level": "high",
      "urgency": "★★★★★",
      "importance": "★★★★★",
      "symptom": "...",
      "evidence": "...",
      "need": "...",
      "entry_point": "..."
    }
  ],

  "core_conclusion": "...",
  "pain_summary": "...",

  "pitches": [
    {"title": "话术1：...", "content": "..."}
  ],

  "recommendations": [
    ["优先级", "推荐产品/服务", "理由", "预估单笔订单额"]
  ],

  "concerns": [
    ["顾虑", "分析", "应对思路"]
  ],

  "decision_makers": [
    ["角色", "可能负责人", "推测KPI", "采购关注点"]
  ],

  "contact_channels": [
    ["渠道", "目标人", "建议动作", "优先级"]
  ],

  "product_match": [
    ["客户品类", "可供应？", "匹配度", "备注"]
  ],
  "overall_match": [
    ["评估维度", "评分", "说明"]
  ],
  "entry_priority": [
    ["优先级", "切入方向", "具体动作", "预期效果"]
  ],

  "en_background": [
    ["Key Facts", "Details"]
  ],
  "en_pain_points": [
    ["#", "Pain Point", "Analysis"]
  ],
  "en_approach": ["..."],

  "data_sources": [
    ["序号", "检索关键词", "数据来源", "关键发现", "数据日期"]
  ],

  "disclaimer": "本报告基于公开网络信息编制，所有推断内容已标注"推测"并附依据。...",
  "disclaimer_en": "This report is compiled from publicly available information..."
}
```
