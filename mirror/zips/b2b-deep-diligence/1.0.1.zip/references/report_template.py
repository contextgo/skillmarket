# -*- coding: utf-8 -*-
"""
B2B客户深度背调报告模板参考 (v2.0 通用版)

这是通用版报告的完整代码模板，作为样式和结构的参考。
新客户报告可基于此模板修改数据部分即可。

使用方法：
1. 复制本文件到工作目录
2. 替换所有【占位符】中的数据
3. 如有用户公司配置（user_profile.json），匹配度章节自动生成
4. 运行生成Word报告

依赖：pip install python-docx
"""

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml
import os
from datetime import date

doc = Document()

# ── Page Setup ──
for section in doc.sections:
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(2.54)
    section.right_margin = Cm(2.54)

# ── Style Constants ──
BLUE = RGBColor(0x1F, 0x4E, 0x79)
DARK = RGBColor(0x33, 0x33, 0x33)
RED = RGBColor(0xC0, 0x39, 0x2B)
ORANGE = RGBColor(0xE6, 0x7E, 0x22)
GREEN = RGBColor(0x27, 0xAE, 0x60)
LIGHT_GREY_BG = "F2F2F0"

# ── Style Setup ──
style = doc.styles['Normal']
style.font.name = 'Calibri'
style.font.size = Pt(11)
style.font.color.rgb = DARK
style.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
pf = style.paragraph_format
pf.space_after = Pt(6)
pf.line_spacing = 1.15

# ══════════════════════════════════════════════════
# 样式工具函数（可直接复用）
# ══════════════════════════════════════════════════

def set_heading_style(heading, level=1):
    heading.alignment = WD_ALIGN_PARAGRAPH.LEFT
    for run in heading.runs:
        run.font.color.rgb = BLUE
        if level == 0:
            run.font.size = Pt(32)
        elif level == 1:
            run.font.size = Pt(22)
        elif level == 2:
            run.font.size = Pt(16)
        elif level == 3:
            run.font.size = Pt(13)
        run.font.bold = True
        run.font.name = 'Calibri'
        run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')

def add_styled_table(doc, headers, rows, col_widths=None):
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = table.rows[0]
    for i, h in enumerate(headers):
        cell = hdr.cells[i]
        cell.text = ''
        p = cell.paragraphs[0]
        run = p.add_run(h)
        run.bold = True
        run.font.size = Pt(10)
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        run.font.name = 'Calibri'
        run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="1F4E79"/>')
        cell._tc.get_or_add_tcPr().append(shading)
    for r_idx, row_data in enumerate(rows):
        row = table.rows[r_idx + 1]
        bg = LIGHT_GREY_BG if r_idx % 2 == 0 else "FFFFFF"
        for c_idx, val in enumerate(row_data):
            cell = row.cells[c_idx]
            cell.text = ''
            p = cell.paragraphs[0]
            run = p.add_run(str(val))
            run.font.size = Pt(9.5)
            run.font.name = 'Calibri'
            run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
            shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{bg}"/>')
            cell._tc.get_or_add_tcPr().append(shading)
    if col_widths:
        for i, w in enumerate(col_widths):
            for row in table.rows:
                row.cells[i].width = Cm(w)
    return table

def add_bold_text(para, text, color=DARK, size=Pt(11)):
    run = para.add_run(text)
    run.bold = True
    run.font.color.rgb = color
    run.font.size = size
    run.font.name = 'Calibri'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    return run

def add_normal_text(para, text, color=DARK, size=Pt(11)):
    run = para.add_run(text)
    run.font.color.rgb = color
    run.font.size = size
    run.font.name = 'Calibri'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    return run

# ══════════════════════════════════════════════════
# 以下为报告内容模板
# 替换【占位符】中的内容即可生成新客户报告
# ══════════════════════════════════════════════════

# ── 标题页 ──
doc.add_paragraph()
doc.add_paragraph()
doc.add_paragraph()

title = doc.add_heading('【国家】客户深度背调报告', level=0)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
for run in title.runs:
    run.font.size = Pt(32)
    run.font.color.rgb = BLUE
    run.font.name = 'Calibri'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')

subtitle = doc.add_paragraph()
subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = subtitle.add_run('【公司域名/名称】')
run.font.size = Pt(20)
run.font.color.rgb = RGBColor(0x7F, 0x8C, 0x8D)
run.font.name = 'Calibri'

doc.add_paragraph()

# 元信息
meta_table = doc.add_table(rows=5, cols=2)
meta_table.alignment = WD_TABLE_ALIGNMENT.CENTER
meta_data = [
    ('目标客户网站', '【填入】'),
    ('报告日期', f'{date.today().year}年{date.today().month}月{date.today().day}日'),
    ('分析师', '【用户公司名】 - AI背调助手'),
    ('报告版本', 'V2.0'),
    ('密级', '内部机密'),
]
for i, (k, v) in enumerate(meta_data):
    c0 = meta_table.rows[i].cells[0]
    c1 = meta_table.rows[i].cells[1]
    c0.text = ''
    c1.text = ''
    p0 = c0.paragraphs[0]
    p0.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r0 = p0.add_run(k)
    r0.bold = True
    r0.font.size = Pt(11)
    r0.font.color.rgb = BLUE
    r0.font.name = 'Calibri'
    r0.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    p1 = c1.paragraphs[0]
    r1 = p1.add_run(v)
    r1.font.size = Pt(11)
    r1.font.name = 'Calibri'
    r1.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    c0.width = Cm(5)
    c1.width = Cm(9)

doc.add_page_break()

# ── 一、客户基本信息 ──
h = doc.add_heading('一、客户基本信息', level=1)
set_heading_style(h, 1)

p = doc.add_paragraph()
add_normal_text(p, f'📊 数据截止日期：【YYYY-MM-DD】  |  建议下次更新：【YYYY-MM-DD】', color=BLUE, size=Pt(9))

h2 = doc.add_heading('1.1 公司身份与架构', level=2)
set_heading_style(h2, 2)

add_styled_table(doc,
    ['项目', '信息'],
    [
        ['公司全称', '【填入】'],
        ['网站', '【填入】'],
        ['成立时间', '【填入】'],
        ['公司性质', '【填入】'],
        ['总部', '【填入】'],
        ['仓库', '【填入】'],
        ['CEO/总裁', '【填入】'],
        ['员工数', '【填入】'],
    ],
    col_widths=[4, 12]
)

doc.add_paragraph()
h2 = doc.add_heading('1.2 公司营收规模', level=2)
set_heading_style(h2, 2)

add_styled_table(doc,
    ['来源', '营收估算', '员工数', '备注', '数据日期'],
    [
        ['【来源1】', '【营收】', '【人数】', '【备注】', '【YYYY-MM】'],
        ['【来源2】', '【营收】', '【人数】', '【备注】', '【YYYY-MM】'],
        ['综合推断', '【中位值】', '【中位数】', '结合多源数据取中位值', '【YYYY-MM】'],
    ],
    col_widths=[3.5, 3, 3, 5, 2]
)

doc.add_paragraph()
p = doc.add_paragraph()
add_bold_text(p, '关键判断：', color=RED)
add_normal_text(p, '【填入综合判断】')

p = doc.add_paragraph()
add_bold_text(p, '营收趋势：【📈增长/➡️持平/📉下降】', color=BLUE)

doc.add_page_break()

# ── 二、产品与供应链分析 ──
h = doc.add_heading('二、产品与供应链分析', level=1)
set_heading_style(h, 1)

# 【按产品品类逐一添加表格和发现】

doc.add_page_break()

# ── 三、市场与竞争环境分析 ──
h = doc.add_heading('三、市场与竞争环境分析', level=1)
set_heading_style(h, 1)

# 【市场规模、竞争格局、SWOT、口碑、行业趋势】

doc.add_page_break()

# ── 四、财务与风险评估（v2新增） ──
h = doc.add_heading('四、财务与风险评估', level=1)
set_heading_style(h, 1)

# 4.1 财务健康度
h2 = doc.add_heading('4.1 财务健康度', level=2)
set_heading_style(h2, 2)
# 【财务指标表】

# 4.2 关税与贸易风险
h2 = doc.add_heading('4.2 关税与贸易风险', level=2)
set_heading_style(h2, 2)
# 【关税表】

# 4.3 法律与合规风险
h2 = doc.add_heading('4.3 法律与合规风险', level=2)
set_heading_style(h2, 2)
# 【法律风险表】

# 4.4 风险矩阵
h2 = doc.add_heading('4.4 风险矩阵总览', level=2)
set_heading_style(h2, 2)
# 【风险矩阵表：风险项、可能性、影响度、等级、应对建议】

doc.add_page_break()

# ── 五、痛点推断 ──
h = doc.add_heading('五、深度推断——客户的主要需求与痛点', level=1)
set_heading_style(h, 1)

# 【每个痛点一个章节，包含🔴🟡🟢评级、4维度分析表】

doc.add_page_break()

# ── 六、开发建议 ──
h = doc.add_heading('六、背调结论与开发建议', level=1)
set_heading_style(h, 1)

# 【核心结论、话术、推荐产品、顾虑应对、决策链、联系渠道】

doc.add_page_break()

# ── 七、供应商匹配度分析（需用户配置） ──
h = doc.add_heading('七、【用户公司名】 vs 客户匹配度分析', level=1)
set_heading_style(h, 1)

# 7.1 产品匹配矩阵
h2 = doc.add_heading('7.1 产品匹配矩阵', level=2)
set_heading_style(h2, 2)
# 【品类匹配表】

# 7.2 综合匹配度评估
h2 = doc.add_heading('7.2 综合匹配度评估', level=2)
set_heading_style(h2, 2)
# 【5维度评估表】

# 7.3 切入优先级排序
h2 = doc.add_heading('7.3 切入优先级排序', level=2)
set_heading_style(h2, 2)
# 【优先级表】

doc.add_page_break()

# ── 附录：English Summary ──
h = doc.add_heading('Appendix: English Summary', level=1)
set_heading_style(h, 1)

# 【英文Summary表、痛点、推荐策略】

doc.add_page_break()

# ── 数据来源 ──
h = doc.add_heading('数据来源与检索关键词', level=1)
set_heading_style(h, 1)

# 【搜索关键词+来源+关键发现+数据日期表】

doc.add_paragraph()
p = doc.add_paragraph()
add_bold_text(p, '报告声明：', color=RED, size=Pt(10))
add_normal_text(p, '本报告基于公开网络信息编制，所有推断内容已标注"推测"并附依据。建议后续通过LinkedIn联系目标客户采购团队确认具体采购需求，并通过海关数据验证其进口记录。报告数据具有时效性，建议定期更新。', size=Pt(10))

doc.add_paragraph()
p = doc.add_paragraph()
add_bold_text(p, '📅 建议下次更新时间：【YYYY-MM-DD】', color=BLUE, size=Pt(10))

# ── Save ──
desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
output_path = os.path.join(desktop, '【国家】客户背调报告_【公司域名】.docx')
doc.save(output_path)
print(f'Report saved to: {output_path}')
