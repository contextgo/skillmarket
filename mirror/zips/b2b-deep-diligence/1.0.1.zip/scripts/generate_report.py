# -*- coding: utf-8 -*-
"""
B2B客户深度背调报告生成器 (v2.0 通用版)

用法:
    python generate_report.py --data data.json --output report.docx
    python generate_report.py --data data.json --profile user_profile.json

数据文件格式见 references/diligence_framework.md 中的 JSON Schema 部分。
用户配置文件格式见 assets/user_profile.example.json。
"""

import json
import os
import sys
from datetime import date
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml

# ══════════════════════════════════════════════════
# 颜色常量
# ══════════════════════════════════════════════════
BLUE = RGBColor(0x1F, 0x4E, 0x79)
DARK = RGBColor(0x33, 0x33, 0x33)
RED = RGBColor(0xC0, 0x39, 0x2B)
ORANGE = RGBColor(0xE6, 0x7E, 0x22)
GREEN = RGBColor(0x27, 0xAE, 0x60)
LIGHT_GREY_BG = "F2F2F0"


# ══════════════════════════════════════════════════
# 样式工具函数
# ══════════════════════════════════════════════════
def setup_document():
    """创建文档并设置页面和默认样式"""
    doc = Document()
    for section in doc.sections:
        section.page_width = Cm(21)
        section.page_height = Cm(29.7)
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)
        section.left_margin = Cm(2.54)
        section.right_margin = Cm(2.54)

    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(11)
    style.font.color.rgb = DARK
    style.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    pf = style.paragraph_format
    pf.space_after = Pt(6)
    pf.line_spacing = 1.15
    return doc


def set_heading_style(heading, level=1):
    """设置标题样式"""
    heading.alignment = WD_ALIGN_PARAGRAPH.LEFT
    for run in heading.runs:
        run.font.color.rgb = BLUE
        if level == 0:
            run.font.size = Pt(32)
        elif level == 1:
            run.font.size = Pt(22)
        elif level == 2:
            run.font.size = Pt(16)
        elif level == 3:
            run.font.size = Pt(13)
        run.font.bold = True
        run.font.name = 'Calibri'
        run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')


def add_styled_table(doc, headers, rows, col_widths=None):
    """添加带样式的表格"""
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    # 表头
    hdr = table.rows[0]
    for i, h in enumerate(headers):
        cell = hdr.cells[i]
        cell.text = ''
        p = cell.paragraphs[0]
        run = p.add_run(h)
        run.bold = True
        run.font.size = Pt(10)
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        run.font.name = 'Calibri'
        run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="1F4E79"/>')
        cell._tc.get_or_add_tcPr().append(shading)
    # 数据行
    for r_idx, row_data in enumerate(rows):
        row = table.rows[r_idx + 1]
        bg = LIGHT_GREY_BG if r_idx % 2 == 0 else "FFFFFF"
        for c_idx, val in enumerate(row_data):
            cell = row.cells[c_idx]
            cell.text = ''
            p = cell.paragraphs[0]
            run = p.add_run(str(val))
            run.font.size = Pt(9.5)
            run.font.name = 'Calibri'
            run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
            shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{bg}"/>')
            cell._tc.get_or_add_tcPr().append(shading)
    # 列宽
    if col_widths:
        for i, w in enumerate(col_widths):
            for row in table.rows:
                row.cells[i].width = Cm(w)
    return table


def add_bold_text(para, text, color=DARK, size=Pt(11)):
    """添加加粗文本"""
    run = para.add_run(text)
    run.bold = True
    run.font.color.rgb = color
    run.font.size = size
    run.font.name = 'Calibri'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    return run


def add_normal_text(para, text, color=DARK, size=Pt(11)):
    """添加普通文本"""
    run = para.add_run(text)
    run.font.color.rgb = color
    run.font.size = size
    run.font.name = 'Calibri'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    return run


def add_data_validity_note(doc, data):
    """添加数据时效标注"""
    validity = data.get('data_validity_date', data.get('report_date', ''))
    if validity:
        p = doc.add_paragraph()
        add_normal_text(p, f'📊 数据截止日期：{validity}', color=BLUE, size=Pt(9))
        next_update = data.get('next_update_suggested', '')
        if next_update:
            add_normal_text(p, f'  |  建议下次更新：{next_update}', color=BLUE, size=Pt(9))


# ══════════════════════════════════════════════════
# 报告章节生成函数
# ══════════════════════════════════════════════════

def add_title_page(doc, data, user_profile=None):
    """生成标题页"""
    doc.add_paragraph()
    doc.add_paragraph()
    doc.add_paragraph()

    title = doc.add_heading(f'{data.get("country", "海外")}客户深度背调报告', level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in title.runs:
        run.font.size = Pt(32)
        run.font.color.rgb = BLUE
        run.font.name = 'Calibri'
        run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')

    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run(data.get('company_domain', 'N/A'))
    run.font.size = Pt(20)
    run.font.color.rgb = RGBColor(0x7F, 0x8C, 0x8D)
    run.font.name = 'Calibri'

    doc.add_paragraph()

    # 元信息表
    meta_table = doc.add_table(rows=5, cols=2)
    meta_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    analyst = 'AI背调助手'
    if user_profile:
        analyst = f"{user_profile.get('company_name_zh', '')} - AI背调助手"
    meta_data = [
        ('目标客户网站', data.get('website', 'N/A')),
        ('报告日期', f'{date.today().year}年{date.today().month}月{date.today().day}日'),
        ('分析师', analyst),
        ('报告版本', 'V2.0'),
        ('密级', '内部机密'),
    ]
    for i, (k, v) in enumerate(meta_data):
        c0 = meta_table.rows[i].cells[0]
        c1 = meta_table.rows[i].cells[1]
        c0.text = ''
        c1.text = ''
        p0 = c0.paragraphs[0]
        p0.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        r0 = p0.add_run(k)
        r0.bold = True
        r0.font.size = Pt(11)
        r0.font.color.rgb = BLUE
        r0.font.name = 'Calibri'
        r0.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
        p1 = c1.paragraphs[0]
        r1 = p1.add_run(v)
        r1.font.size = Pt(11)
        r1.font.name = 'Calibri'
        r1.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
        c0.width = Cm(5)
        c1.width = Cm(9)

    doc.add_page_break()


def add_section_company(doc, data):
    """章节一：客户基本信息"""
    h = doc.add_heading('一、客户基本信息', level=1)
    set_heading_style(h, 1)
    add_data_validity_note(doc, data)

    h2 = doc.add_heading('1.1 公司身份与架构', level=2)
    set_heading_style(h2, 2)

    basic_info = data.get('basic_info', {})
    rows = [[k, v] for k, v in basic_info.items()]
    add_styled_table(doc, ['项目', '信息'], rows, col_widths=[4, 12])

    doc.add_paragraph()
    h2 = doc.add_heading('1.2 公司营收规模', level=2)
    set_heading_style(h2, 2)

    revenue_data = data.get('revenue_data', [])
    if revenue_data:
        headers = ['来源', '营收估算', '员工数', '备注']
        # 检查是否有日期列（v2格式有5列）
        if len(revenue_data) > 0 and len(revenue_data[0]) > 4:
            headers.append('数据日期')
        add_styled_table(doc, headers, revenue_data,
                         col_widths=[3.5, 3.5, 3, 5, 2] if len(headers) > 4 else [3.5, 3.5, 3, 6.5])

    doc.add_paragraph()
    p = doc.add_paragraph()
    add_bold_text(p, '关键判断：', color=RED)
    add_normal_text(p, data.get('revenue_conclusion', ''))

    if data.get('revenue_trend'):
        p = doc.add_paragraph()
        trend_icon = {'增长': '📈', '持平': '➡️', '下降': '📉'}.get(data['revenue_trend'], '❓')
        add_bold_text(p, f'营收趋势：{trend_icon} {data["revenue_trend"]}', color=BLUE)

    doc.add_paragraph()
    h2 = doc.add_heading('1.3 公司发展历程', level=2)
    set_heading_style(h2, 2)

    timeline = data.get('timeline', [])
    if timeline:
        add_styled_table(doc, ['时间', '里程碑'], timeline, col_widths=[3, 13])

    doc.add_paragraph()
    h2 = doc.add_heading('1.4 商业模式定位', level=2)
    set_heading_style(h2, 2)

    p = doc.add_paragraph()
    add_normal_text(p, data.get('business_model_desc', ''))

    if data.get('business_model_formula'):
        p = doc.add_paragraph()
        add_bold_text(p, data['business_model_formula'], color=BLUE, size=Pt(12))

    for item in data.get('business_model_points', []):
        p = doc.add_paragraph(style='List Bullet')
        add_normal_text(p, item, size=Pt(10.5))

    doc.add_page_break()


def add_section_products(doc, data):
    """章节二：产品与供应链分析"""
    h = doc.add_heading('二、产品与供应链分析', level=1)
    set_heading_style(h, 1)

    for product_line in data.get('product_lines', []):
        h2 = doc.add_heading(product_line.get('title', ''), level=2)
        set_heading_style(h2, 2)

        add_styled_table(doc,
                         product_line.get('headers', []),
                         product_line.get('rows', []),
                         col_widths=product_line.get('col_widths'))

        doc.add_paragraph()
        if product_line.get('findings'):
            p = doc.add_paragraph()
            add_bold_text(p, '关键发现：', color=RED)
            for finding in product_line['findings']:
                p = doc.add_paragraph(style='List Bullet')
                add_normal_text(p, finding, size=Pt(10.5))
            doc.add_paragraph()

    h2 = doc.add_heading('2.x 供应链模式推断', level=2)
    set_heading_style(h2, 2)

    supply_chain = data.get('supply_chain', [])
    if supply_chain:
        add_styled_table(doc, ['维度', '推断结论', '依据'],
                         supply_chain, col_widths=[3, 5.5, 7.5])

    doc.add_paragraph()
    supply_chain_risks = data.get('supply_chain_risks', [])
    if supply_chain_risks:
        h3 = doc.add_heading('供应链风险信号', level=3)
        set_heading_style(h3, 3)
        add_styled_table(doc, ['风险信号', '具体表现', '推断含义'],
                         supply_chain_risks, col_widths=[3.5, 5.5, 6.5])

    doc.add_page_break()


def add_section_market(doc, data):
    """章节三：市场与竞争环境分析"""
    h = doc.add_heading('三、市场与竞争环境分析', level=1)
    set_heading_style(h, 1)

    h2 = doc.add_heading('3.1 市场规模', level=2)
    set_heading_style(h2, 2)

    market_size = data.get('market_size', [])
    if market_size:
        headers = ['指标', '数据', '来源']
        if len(market_size) > 0 and len(market_size[0]) > 3:
            headers.append('数据年份')
        add_styled_table(doc, headers, market_size,
                         col_widths=[4, 4, 4, 3] if len(headers) > 3 else [5, 5, 5])

    if data.get('market_conclusion'):
        p = doc.add_paragraph()
        add_bold_text(p, '结论：', color=RED)
        add_normal_text(p, data['market_conclusion'])

    doc.add_paragraph()
    h2 = doc.add_heading('3.2 竞争格局', level=2)
    set_heading_style(h2, 2)

    competitors = data.get('competitors', [])
    if competitors:
        add_styled_table(doc, ['竞争对手', '公司性质', '规模/营收', '优势', '劣势'],
                         competitors, col_widths=[3, 2.5, 3, 4, 3.5])

    doc.add_paragraph()
    h2 = doc.add_heading('3.3 目标客户优劣势分析', level=2)
    set_heading_style(h2, 2)

    swot = data.get('swot', [])
    if swot:
        add_styled_table(doc, ['维度', '优势', '劣势'],
                         swot, col_widths=[2.5, 6.5, 6.5])

    doc.add_paragraph()
    h2 = doc.add_heading('3.4 口碑分析', level=2)
    set_heading_style(h2, 2)

    reviews = data.get('reviews', [])
    if reviews:
        headers = ['平台', '评分', '评论数', '主要问题']
        if len(reviews) > 0 and len(reviews[0]) > 4:
            headers.append('数据日期')
        add_styled_table(doc, headers, reviews,
                         col_widths=[3.5, 2, 2, 6, 2.5] if len(headers) > 4 else [3.5, 2, 2, 8])

    if data.get('review_conclusion'):
        doc.add_paragraph()
        p = doc.add_paragraph()
        add_bold_text(p, '口碑分析结论：', color=RED)
        add_normal_text(p, data['review_conclusion'])

    doc.add_paragraph()
    h2 = doc.add_heading('3.5 行业趋势', level=2)
    set_heading_style(h2, 2)

    industry_trends = data.get('industry_trends', [])
    if industry_trends:
        add_styled_table(doc, ['趋势类别', '具体趋势', '影响评估', '数据来源'],
                         industry_trends, col_widths=[2.5, 5, 4, 4])

    doc.add_page_break()


def add_section_finance_risk(doc, data):
    """章节四：财务与风险评估（v2新增）"""
    h = doc.add_heading('四、财务与风险评估', level=1)
    set_heading_style(h, 1)

    # 4.1 财务健康度
    h2 = doc.add_heading('4.1 财务健康度', level=2)
    set_heading_style(h2, 2)

    financial_health = data.get('financial_health', [])
    if financial_health:
        add_styled_table(doc, ['指标', '数据/推断', '依据', '数据日期'],
                         financial_health, col_widths=[3, 4, 5, 3])
    else:
        p = doc.add_paragraph()
        add_normal_text(p, '（公开信息有限，以下为基于行业基准的推断）', color=ORANGE, size=Pt(10))

    # 4.2 关税与贸易风险
    doc.add_paragraph()
    h2 = doc.add_heading('4.2 关税与贸易风险', level=2)
    set_heading_style(h2, 2)

    tariff_risks = data.get('tariff_risks', [])
    if tariff_risks:
        add_styled_table(doc, ['产品类别', 'HS Code', '关税税率', '政策变化风险'],
                         tariff_risks, col_widths=[3.5, 3, 3, 6])

    # 4.3 法律与合规风险
    doc.add_paragraph()
    h2 = doc.add_heading('4.3 法律与合规风险', level=2)
    set_heading_style(h2, 2)

    legal_risks = data.get('legal_risks', [])
    if legal_risks:
        add_styled_table(doc, ['风险类型', '描述', '严重程度', '数据来源'],
                         legal_risks, col_widths=[3, 5.5, 2.5, 5])
    else:
        p = doc.add_paragraph()
        add_normal_text(p, '未发现重大公开法律风险记录', color=GREEN, size=Pt(10))

    # 4.4 风险矩阵
    doc.add_paragraph()
    h2 = doc.add_heading('4.4 风险矩阵总览', level=2)
    set_heading_style(h2, 2)

    risk_matrix = data.get('risk_matrix', [])
    if risk_matrix:
        add_styled_table(doc, ['风险项', '可能性', '影响度', '等级', '应对建议'],
                         risk_matrix, col_widths=[3.5, 2, 2, 2, 6])

    doc.add_page_break()


def add_section_pain_points(doc, data):
    """章节五：痛点推断"""
    h = doc.add_heading('五、深度推断——客户的主要需求与痛点', level=1)
    set_heading_style(h, 1)

    pain_points = data.get('pain_points', [])
    level_icons = {'high': '🔴', 'medium': '🟡', 'low': '🟢'}
    level_colors = {'high': RED, 'medium': ORANGE, 'low': GREEN}

    for pp in pain_points:
        doc.add_paragraph()
        icon = level_icons.get(pp.get('level', 'medium'), '🟡')
        h2 = doc.add_heading(f'{icon} {pp.get("title", "")}', level=2)
        set_heading_style(h2, 2)

        p = doc.add_paragraph()
        color = level_colors.get(pp.get('level', 'medium'), ORANGE)
        add_bold_text(p, f'紧急程度：{pp.get("urgency", "")}  |  重要程度：{pp.get("importance", "")}', color=color)

        rows = []
        if pp.get('symptom'):
            rows.append(['痛点表现', pp['symptom']])
        if pp.get('evidence'):
            rows.append(['推断依据', pp['evidence']])
        if pp.get('need'):
            rows.append(['客户需求', pp['need']])
        # 通用字段名 entry_point，兼容旧字段名 auplex_entry
        entry = pp.get('entry_point', pp.get('auplex_entry', ''))
        if entry:
            rows.append(['建议切入点', entry])

        add_styled_table(doc, ['维度', '分析'], rows, col_widths=[3, 13])
        doc.add_paragraph()

    doc.add_page_break()


def add_section_strategy(doc, data):
    """章节六：开发建议"""
    h = doc.add_heading('六、背调结论与开发建议', level=1)
    set_heading_style(h, 1)

    h2 = doc.add_heading('6.1 核心结论', level=2)
    set_heading_style(h2, 2)

    if data.get('core_conclusion'):
        p = doc.add_paragraph()
        add_bold_text(p, data['core_conclusion'], color=BLUE, size=Pt(12))

    if data.get('pain_summary'):
        p = doc.add_paragraph()
        add_bold_text(p, data['pain_summary'], color=RED, size=Pt(12))

    doc.add_paragraph()
    h2 = doc.add_heading('6.2 初次联系话术方向', level=2)
    set_heading_style(h2, 2)

    for pitch in data.get('pitches', []):
        p = doc.add_paragraph()
        add_bold_text(p, pitch.get('title', ''), color=BLUE)
        p = doc.add_paragraph()
        add_normal_text(p, pitch.get('content', ''), size=Pt(10))
        doc.add_paragraph()

    h2 = doc.add_heading('6.3 建议推荐的产品/服务', level=2)
    set_heading_style(h2, 2)

    recommendations = data.get('recommendations', [])
    if recommendations:
        add_styled_table(doc, ['优先级', '推荐产品/服务', '理由', '预估单笔订单额'],
                         recommendations, col_widths=[2, 5, 5.5, 3])

    doc.add_paragraph()
    h2 = doc.add_heading('6.4 可能阻碍合作的顾虑及应对', level=2)
    set_heading_style(h2, 2)

    concerns = data.get('concerns', [])
    if concerns:
        add_styled_table(doc, ['顾虑', '分析', '应对思路'],
                         concerns, col_widths=[3.5, 5, 7])

    doc.add_paragraph()
    h2 = doc.add_heading('6.5 决策链推断与联系建议', level=2)
    set_heading_style(h2, 2)

    decision_makers = data.get('decision_makers', [])
    if decision_makers:
        add_styled_table(doc, ['角色', '可能负责人', '推测KPI', '采购关注点'],
                         decision_makers, col_widths=[2.5, 3, 4.5, 5.5])

    if data.get('contact_advice'):
        doc.add_paragraph()
        p = doc.add_paragraph()
        add_bold_text(p, '联系建议：', color=BLUE)
        for item in data['contact_advice']:
            p = doc.add_paragraph(style='List Bullet')
            add_normal_text(p, item, size=Pt(10.5))

    # 联系渠道建议（v2新增）
    contact_channels = data.get('contact_channels', [])
    if contact_channels:
        doc.add_paragraph()
        h3 = doc.add_heading('联系渠道优先级', level=3)
        set_heading_style(h3, 3)
        add_styled_table(doc, ['渠道', '目标人', '建议动作', '优先级'],
                         contact_channels, col_widths=[3, 3, 6.5, 3])

    doc.add_page_break()


def add_section_matching(doc, data, user_profile):
    """章节七：供应商匹配度分析（需用户配置）"""
    if not user_profile:
        return  # 未配置用户信息则跳过

    company_name = user_profile.get('company_name_zh', user_profile.get('company_name_en', '供应商'))
    h = doc.add_heading(f'七、{company_name} vs 客户匹配度分析', level=1)
    set_heading_style(h, 1)

    h2 = doc.add_heading('7.1 产品匹配矩阵', level=2)
    set_heading_style(h2, 2)

    product_match = data.get('product_match', [])
    if product_match:
        # 替换表格头中的硬编码名称
        add_styled_table(doc, ['客户品类', f'{company_name}可供应？', '匹配度', '备注'],
                         product_match, col_widths=[4, 3, 2, 7])

    doc.add_paragraph()
    h2 = doc.add_heading('7.2 综合匹配度评估', level=2)
    set_heading_style(h2, 2)

    overall_match = data.get('overall_match', [])
    if overall_match:
        add_styled_table(doc, ['评估维度', '评分', '说明'],
                         overall_match, col_widths=[3, 2, 11])

    doc.add_paragraph()
    h2 = doc.add_heading('7.3 切入优先级排序', level=2)
    set_heading_style(h2, 2)

    entry_priority = data.get('entry_priority', [])
    if entry_priority:
        add_styled_table(doc, ['优先级', '切入方向', '具体动作', '预期效果'],
                         entry_priority, col_widths=[2, 3.5, 5.5, 5])
    else:
        # 兼容旧格式 recommendations
        recommendations = data.get('recommendations', [])
        if recommendations:
            add_styled_table(doc, ['优先级', '切入方向', '理由', '预估效果'],
                             recommendations, col_widths=[2, 4, 5.5, 4.5])

    doc.add_page_break()


def add_english_appendix(doc, data, user_profile=None):
    """附录：English Summary"""
    h = doc.add_heading('Appendix: English Summary', level=1)
    set_heading_style(h, 1)

    h2 = doc.add_heading('Company Background', level=2)
    set_heading_style(h2, 2)

    en_background = data.get('en_background', [])
    if en_background:
        add_styled_table(doc, ['Key Facts', 'Details'], en_background, col_widths=[4, 12])

    doc.add_paragraph()
    h3 = doc.add_heading('Key Pain Points & Opportunities', level=3)
    set_heading_style(h3, 3)

    en_pain_points = data.get('en_pain_points', [])
    if en_pain_points:
        add_styled_table(doc, ['#', 'Pain Point', 'Analysis'],
                         en_pain_points, col_widths=[1, 3.5, 11])

    doc.add_paragraph()
    company_en = ''
    if user_profile:
        company_en = user_profile.get('company_name_en', '')
    h3 = doc.add_heading(f'Recommended Approach{" for " + company_en if company_en else ""}', level=3)
    set_heading_style(h3, 3)

    for item in data.get('en_approach', []):
        p = doc.add_paragraph(style='List Bullet')
        add_normal_text(p, item, size=Pt(10.5))

    doc.add_page_break()


def add_data_sources(doc, data):
    """数据来源"""
    h = doc.add_heading('数据来源与检索关键词', level=1)
    set_heading_style(h, 1)

    sources = data.get('data_sources', [])
    if sources:
        headers = ['序号', '检索关键词', '数据来源', '关键发现']
        # v2格式有5列（含数据日期）
        if len(sources) > 0 and len(sources[0]) > 4:
            headers.append('数据日期')
        add_styled_table(doc, headers, sources,
                         col_widths=[1.5, 3.5, 4, 5, 2.5] if len(headers) > 4 else [1.5, 4, 4.5, 6])

    doc.add_paragraph()
    p = doc.add_paragraph()
    add_bold_text(p, '报告声明：', color=RED, size=Pt(10))
    add_normal_text(p, data.get('disclaimer',
        '本报告基于公开网络信息编制，所有推断内容已标注"推测"并附依据。'
        '建议后续通过LinkedIn联系目标客户采购团队确认具体采购需求，'
        '并通过海关数据验证其进口记录。'
        '报告数据具有时效性，建议定期更新。'), size=Pt(10))

    if data.get('disclaimer_en'):
        doc.add_paragraph()
        p = doc.add_paragraph()
        add_normal_text(p, data['disclaimer_en'], size=Pt(9))

    # 下次更新建议
    next_update = data.get('next_update_suggested', '')
    if next_update:
        doc.add_paragraph()
        p = doc.add_paragraph()
        add_bold_text(p, f'📅 建议下次更新时间：{next_update}', color=BLUE, size=Pt(10))


# ══════════════════════════════════════════════════
# 主函数
# ══════════════════════════════════════════════════
def generate_report(data, output_path, user_profile=None):
    """根据数据字典生成完整的背调报告"""
    doc = setup_document()

    add_title_page(doc, data, user_profile)
    add_section_company(doc, data)
    add_section_products(doc, data)
    add_section_market(doc, data)
    add_section_finance_risk(doc, data)  # v2新增
    add_section_pain_points(doc, data)
    add_section_strategy(doc, data)
    add_section_matching(doc, data, user_profile)  # v2改为可选
    add_english_appendix(doc, data, user_profile)
    add_data_sources(doc, data)

    doc.save(output_path)
    return output_path


def load_user_profile(profile_path=None):
    """加载用户公司配置文件"""
    if profile_path is None:
        # 默认路径：脚本所在目录的 assets/user_profile.json
        script_dir = os.path.dirname(os.path.abspath(__file__))
        default_path = os.path.join(script_dir, '..', 'assets', 'user_profile.json')
        profile_path = os.path.normpath(default_path)

    if os.path.exists(profile_path):
        with open(profile_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None


def main():
    import argparse
    parser = argparse.ArgumentParser(description='B2B客户深度背调报告生成器 v2.0')
    parser.add_argument('--data', required=True, help='JSON数据文件路径')
    parser.add_argument('--output', default=None, help='输出文件路径（默认保存到桌面）')
    parser.add_argument('--profile', default=None, help='用户公司配置文件路径')
    args = parser.parse_args()

    with open(args.data, 'r', encoding='utf-8') as f:
        data = json.load(f)

    user_profile = load_user_profile(args.profile)
    if user_profile:
        print(f'已加载用户配置：{user_profile.get("company_name_zh", "")} ({user_profile.get("company_name_en", "")})')
    else:
        print('未找到用户配置文件，将跳过匹配度分析章节')

    if args.output is None:
        desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
        country = data.get('country', '海外')
        domain = data.get('company_domain', 'unknown')
        args.output = os.path.join(desktop, f'{country}客户背调报告_{domain}.docx')

    result = generate_report(data, args.output, user_profile)
    print(f'Report saved to: {result}')


if __name__ == '__main__':
    main()
