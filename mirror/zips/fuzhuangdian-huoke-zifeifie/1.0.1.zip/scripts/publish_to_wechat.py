#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信公众号文章发布脚本
支持多账号管理（订阅号/服务号）
将 Markdown 格式的文章发布到微信公众号草稿箱
"""

import argparse
import json
import os
import re
import sys
from typing import Optional

import requests


class WeChatPublisher:
    """微信公众号发布器"""
    
    BASE_URL = "https://api.weixin.qq.com/cgi-bin"
    
    def __init__(
        self,
        appid: Optional[str] = None,
        appsecret: Optional[str] = None,
        account_name: Optional[str] = None
    ):
        """
        初始化发布器
        
        Args:
            appid: 公众号 AppID，默认从环境变量或配置文件读取
            appsecret: 公众号 AppSecret，默认从环境变量或配置文件读取
            account_name: 账号名称（如"订阅号"、"服务号"），从配置文件读取对应凭证
        """
        self.access_token = None
        
        # 如果指定了账号名称，从配置文件读取
        if account_name:
            config = self._load_full_config()
            accounts = config.get('accounts', {})
            if account_name in accounts:
                account = accounts[account_name]
                self.appid = account.get('appid')
                self.appsecret = account.get('appsecret')
            else:
                raise ValueError(f"配置文件中找不到账号: {account_name}")
        else:
            # 优先使用传入的参数，其次环境变量，最后配置文件
            self.appid = appid or os.getenv('WECHAT_APPID') or self._load_config('appid')
            self.appsecret = appsecret or os.getenv('WECHAT_APPSECRET') or self._load_config('appsecret')
        
        if not self.appid or not self.appsecret:
            raise ValueError("请提供 AppID 和 AppSecret，或通过环境变量/配置文件设置")
    
    def _load_full_config(self) -> dict:
        """加载完整配置文件"""
        config_path = os.path.join(os.path.dirname(__file__), 'config.json')
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _load_config(self, key: str) -> Optional[str]:
        """从配置文件加载凭证（兼容旧格式）"""
        config = self._load_full_config()
        
        # 新格式：支持多账号
        if 'accounts' in config:
            default_account = config.get('default_account', '订阅号')
            accounts = config.get('accounts', {})
            if default_account in accounts:
                return accounts[default_account].get(key)
        
        # 旧格式：直接读取
        return config.get(key)
    
    @staticmethod
    def list_accounts() -> list:
        """列出配置文件中所有可用的账号"""
        config_path = os.path.join(os.path.dirname(__file__), 'config.json')
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                accounts = config.get('accounts', {})
                default = config.get('default_account', '订阅号')
                return [(name, name == default) for name in accounts.keys()]
        return []
    
    def _get_access_token(self) -> str:
        """获取 Access Token"""
        if self.access_token:
            return self.access_token
            
        url = f"{self.BASE_URL}/token"
        params = {
            'grant_type': 'client_credential',
            'appid': self.appid,
            'secret': self.appsecret
        }
        
        response = requests.get(url, params=params)
        data = response.json()
        
        if 'access_token' in data:
            self.access_token = data['access_token']
            return self.access_token
        else:
            raise Exception(f"获取 Access Token 失败: {data}")
    
    def _markdown_to_html(self, markdown_content: str) -> str:
        """
        将 Markdown 转换为公众号支持的 HTML
        
        公众号支持的标签有限，需要转换：
        - 标题：h1, h2
        - 段落：p
        - 强调：strong, em
        - 列表：ul, ol, li
        - 链接：a
        - 图片：img（需要上传到微信素材库）
        """
        html = markdown_content
        
        # 处理标题
        html = re.sub(r'^### (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        html = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
        
        # 处理粗体和斜体
        html = re.sub(r'\*\*\*(.+?)\*\*\*', r'<strong><em>\1</em></strong>', html)
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)
        
        # 处理链接
        html = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', html)
        
        # 处理无序列表
        html = re.sub(r'^\s*[-*] (.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
        html = re.sub(r'(<li>.+</li>\n)+', r'<ul>\g<0></ul>', html)
        
        # 处理有序列表
        html = re.sub(r'^\s*\d+\. (.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
        
        # 处理段落（简单处理，将空行分隔的内容包装为段落）
        paragraphs = html.split('\n\n')
        processed_paragraphs = []
        for p in paragraphs:
            p = p.strip()
            if p and not p.startswith('<') and not p.endswith('>'):
                p = f'<p>{p}</p>'
            processed_paragraphs.append(p)
        html = '\n\n'.join(processed_paragraphs)
        
        # 处理换行
        html = html.replace('\n', '<br/>')
        
        return html
    
    def _extract_digest(self, content: str, max_length: int = 120) -> str:
        """从内容中提取摘要"""
        # 移除 Markdown 标记
        text = re.sub(r'[#*_\[\]()]', '', content)
        # 移除多余空白
        text = ' '.join(text.split())
        # 截取前 max_length 个字符
        if len(text) > max_length:
            return text[:max_length] + '...'
        return text
    
    def publish_draft(
        self,
        title: str,
        content: str,
        cover_url: Optional[str] = None,
        author: Optional[str] = None,
        digest: Optional[str] = None
    ) -> dict:
        """
        发布文章到草稿箱
        
        Args:
            title: 文章标题
            content: 文章内容（Markdown 格式）
            cover_url: 封面图片 URL（需要先上传到微信素材库）
            author: 作者名称
            digest: 摘要，默认自动提取
            
        Returns:
            发布结果，包含 media_id
        """
        access_token = self._get_access_token()
        
        # 转换内容格式
        html_content = self._markdown_to_html(content)
        
        # 构建文章数据
        article = {
            'title': title,
            'content': html_content,
            'content_source_url': '',
            'need_open_comment': 1,
            'only_fans_can_comment': 0
        }
        
        if author:
            article['author'] = author
            
        if digest:
            article['digest'] = digest
        else:
            article['digest'] = self._extract_digest(content)
            
        if cover_url:
            # 如果提供了封面图 URL，需要上传到微信素材库获取 media_id
            # 这里简化处理，实际使用时需要先上传图片
            article['thumb_media_id'] = cover_url
        
        # 发布草稿
        url = f"{self.BASE_URL}/draft/add"
        params = {'access_token': access_token}
        data = {'articles': [article]}
        
        response = requests.post(url, params=params, json=data)
        result = response.json()
        
        if 'media_id' in result:
            return {
                'success': True,
                'media_id': result['media_id'],
                'message': '文章已成功发布到草稿箱'
            }
        else:
            return {
                'success': False,
                'error': result.get('errmsg', '未知错误'),
                'error_code': result.get('errcode', -1)
            }


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='发布文章到微信公众号草稿箱')
    parser.add_argument('--title', required=True, help='文章标题')
    parser.add_argument('--content', help='文章内容（Markdown 格式）')
    parser.add_argument('--cover', help='封面图片 URL')
    parser.add_argument('--author', help='作者名称')
    parser.add_argument('--digest', help='文章摘要')
    parser.add_argument('--appid', help='公众号 AppID')
    parser.add_argument('--appsecret', help='公众号 AppSecret')
    parser.add_argument('--account', help='账号名称（如"订阅号"、"服务号"）')
    parser.add_argument('--file', help='从文件读取内容')
    parser.add_argument('--list-accounts', action='store_true', help='列出所有配置的账号')
    
    args = parser.parse_args()
    
    # 列出所有账号
    if args.list_accounts:
        accounts = WeChatPublisher.list_accounts()
        if accounts:
            print("已配置的账号：")
            for name, is_default in accounts:
                default_mark = " (默认)" if is_default else ""
                print(f"  - {name}{default_mark}")
        else:
            print("未配置任何账号")
        return
    
    # 检查必要参数
    if not args.content and not args.file:
        print("❌ 错误: 请提供 --content 或 --file 参数")
        sys.exit(1)
    
    try:
        # 初始化发布器
        publisher = WeChatPublisher(
            appid=args.appid,
            appsecret=args.appsecret,
            account_name=args.account
        )
        
        # 读取内容
        content = args.content or ""
        if args.file:
            with open(args.file, 'r', encoding='utf-8') as f:
                content = f.read()
        
        # 发布文章
        result = publisher.publish_draft(
            title=args.title,
            content=content,
            cover_url=args.cover,
            author=args.author,
            digest=args.digest
        )
        
        # 输出结果
        if result['success']:
            print(f"✅ {result['message']}")
            print(f"📄 Media ID: {result['media_id']}")
            print("\n💡 提示：请在公众号后台的'素材管理'中查看并发布")
        else:
            print(f"❌ 发布失败: {result['error']} (错误码: {result['error_code']})")
            sys.exit(1)
            
    except Exception as e:
        print(f"❌ 错误: {str(e)}")
        sys.exit(1)


if __name__ == '__main__':
    main()
