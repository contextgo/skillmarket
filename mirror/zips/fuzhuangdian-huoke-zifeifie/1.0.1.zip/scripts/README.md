# 公众号发布脚本使用说明

## 安装依赖

```bash
pip install requests
```

## 配置方式（三选一）

### 方式1：配置文件
编辑 `config.json` 文件：
```json
{
  "appid": "你的AppID",
  "appsecret": "你的AppSecret"
}
```

### 方式2：环境变量
```bash
export WECHAT_APPID="你的AppID"
export WECHAT_APPSECRET="你的AppSecret"
```

### 方式3：命令行参数
```bash
python publish_to_wechat.py --title "标题" --content "内容" --appid "你的AppID" --appsecret "你的AppSecret"
```

## 获取 AppID 和 AppSecret

1. 登录微信公众号后台：https://mp.weixin.qq.com
2. 进入「设置与开发」→「基本配置」
3. 获取 AppID 和 AppSecret
4. 注意：AppSecret 只显示一次，请妥善保存

## 使用示例

### 直接发布
```bash
python publish_to_wechat.py \
  --title "为什么你总是存不下钱？" \
  --content "文章内容..." \
  --author "小明"
```

### 从文件发布
```bash
python publish_to_wechat.py \
  --title "为什么你总是存不下钱？" \
  --file article.md \
  --author "小明"
```

## 注意事项

1. **未认证公众号**有每日发布次数限制（通常为1次/天）
2. **封面图片**需要先上传到微信素材库，获取 media_id
3. **草稿箱文章**需要在公众号后台手动发布
4. **内容格式**会自动从 Markdown 转换为公众号支持的 HTML

## 支持的 Markdown 语法

- 标题：# ## ###
- 粗体：**文字**
- 斜体：*文字*
- 链接：[文字](URL)
- 列表：- 或 *
- 段落：自动转换

## 常见问题

**Q: 发布失败，提示 access_token 错误？**
A: 检查 AppID 和 AppSecret 是否正确，以及公众号是否有接口权限。

**Q: 封面图片怎么设置？**
A: 需要先调用微信素材上传接口获取 media_id，然后传入 --cover 参数。

**Q: 可以同时发布到多个公众号吗？**
A: 需要分别配置不同的 AppID 和 AppSecret，多次执行脚本。
