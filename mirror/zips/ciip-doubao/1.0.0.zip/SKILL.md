---
name: doubao-share-extractor
description: 豆包分享链接内容提取与 Word 导出工具。当用户提供豆包(Doubao)分享链接并要求提取、导出、保存内容时触发此技能。支持对话分享、智能体分享、文件分享等所有豆包分享类型，输出为结构化排版的 Word 文档。触发词：豆包链接、豆包分享、提取豆包、导出豆包对话、豆包转Word、doubao share、豆包对话记录、保存豆包聊天、豆包导出、导出对话、提取对话、豆包内容、豆包转文档、doubao export、豆包聊天记录、豆包保存。
---

# Doubao Share Extractor

## Overview

从豆包（Doubao）分享链接中提取对话内容，生成结构化排版的 Word 文档。支持所有分享类型（对话、智能体、文件等），保留文字、代码块、表格、图片、LaTeX 等全部内容。

## 工作流程

### 决策树

```
用户提供豆包分享链接
    ↓
1. 依赖检查：Python 依赖是否已安装？
    ├── 否 → 运行 install_deps.py 安装依赖
    └── 是 → 继续
    ↓
2. 选择抓取模式
    ├── --playwright 模式（推荐）：启动浏览器渲染 + 自动拦截 API 响应
    │   → 运行 extract_doubao.py --url ... --playwright
    └── 静态抓取模式：直接 HTTP 请求，尝试从 HTML 提取嵌入数据
        → 运行 extract_doubao.py --url ...
    ↓
3. 数据提取是否成功？（5种方式依次尝试）
    ├── 是 → 解析消息数据 → 生成 Word
    └── 否（静态模式失败时）
        ├── 添加 --playwright 参数重试
        │   ├── Playwright 成功 → 生成 Word
        │   └── Playwright 也失败 → 回退到 Browser Automation
        └── 使用 Browser Automation 技能获取渲染后 HTML
              → 运行 extract_doubao.py --html → 生成 Word
    ↓
4. 输出 .docx 文件路径给用户
```

### Step 1: 检查并安装依赖

首次使用时需安装 Python 依赖。运行安装脚本：

```bash
python scripts/install_deps.py
```

或手动安装：

```bash
pip install requests beautifulsoup4 lxml python-docx Pillow playwright
playwright install chromium
```

> ⚠️ Playwright 和 Chromium 是可选依赖，仅 `--playwright` 模式需要。如磁盘空间有限可跳过，但大多数豆包分享页需要 JS 渲染。

### Step 2: 提取并生成 Word 文档

**模式 A：Playwright 模式（推荐，适用于大多数豆包分享链接）**

```bash
python scripts/extract_doubao.py --url "https://www.doubao.com/thread/xxxxx" --output "输出文件名.docx" --playwright
```

**模式 B：静态抓取模式（仅对部分内嵌数据的页面有效）**

```bash
python scripts/extract_doubao.py --url "https://www.doubao.com/thread/xxxxx" --output "输出文件名.docx"
```

**模式 C：本地 HTML 文件解析（浏览器渲染后）**

配合 Browser Automation 技能使用：

```bash
python scripts/extract_doubao.py --html "page.html" --output "输出文件名.docx"
```

**可选参数**：
- `--image-dir`：指定图片保存目录（默认：输出文件名_images/）

### Step 3: 回退策略

当 `--url` 静态模式报错时，按以下顺序尝试：

1. **添加 `--playwright` 参数**：大多数豆包页面需要 JS 渲染
2. **使用 Browser Automation 技能**：加载 [skill:Browser Automation]，打开链接获取渲染后 HTML
3. **手动保存 HTML**：在浏览器中打开链接，Ctrl+S 保存完整网页，用 `--html` 模式解析

## 数据提取原理

豆包分享页面将完整对话数据嵌入 HTML 中（SSR），代码按以下优先级依次尝试 5 种提取方式：

1. **modern-run-router-data-fn**（优先级1）：从 `<script data-script-src="modern-run-router-data-fn" data-fn-args="...">` 标签中提取 HTML 实体编码的 JSON 数据，遍历数组找到含 `data.message_snapshot` 的对象
2. **modern-run-window-fn**（优先级2）：从 `<script data-script-src="modern-run-window-fn" data-fn-args="...">` 标签的 `routerDataFnArgs` 中提取 JSON 数据，支持 `shareInfo`（驼峰）和 `share_info`（下划线）双格式
3. **window._ROUTER_DATA**（优先级3）：从全局对象 `loaderData` 中按路由键优先级提取路由数据
4. **__NEXT_DATA__**（优先级4）：从 Next.js 数据（`__NEXT_DATA__` 或 `self.__next_f.push`）中提取
5. **DOM 直接解析**（优先级5，最终回退）：从渲染后的 DOM 结构中提取消息节点

### 角色检测规则

消息角色判断按以下优先级回退：

| 优先级 | 字段 | 判断逻辑 |
|--------|------|----------|
| 1 | `role` | `"user"` 或 `"assistant"`（最常见格式） |
| 2 | `user_type` | `1` = 用户，`2` = AI（新格式常见） |
| 3 | `ext.agent_id` | 非空则为 AI 回复 |
| 4 | 交替分配 | 以上均无时，奇数序号为用户、偶数序号为 AI |

### content JSON 数组格式

部分新格式消息中，`content` 字段为 JSON 数组（而非纯文本），包含 block_type 为数字编码的块：

| block_type | 含义 | 对应 content_v2 类型 |
|-----------|------|---------------------|
| 10000 | 文本块 | `"text"` |
| 10001 | 代码块（行内） | `"code"` |
| 10002 | 代码块（完整） | `"code"` |
| 10003 | 图片块 | `"image"` |

每个 block 的 `content` 字段为**嵌套 JSON 字符串**，需二次解析。同时兼容 `content_v2` 字符串格式（block_type 为字符串），两种格式共存。

详细的数据结构说明见 `references/doubao-page-structure.md`。

## Word 文档排版规范

| 内容类型 | 排版方式 |
|----------|----------|
| 文档标题 | 蓝色大标题居中，含对话主题摘要 |
| 用户消息 | 👤 用户 + 蓝色标签 + 加粗 |
| AI 回复 | 🤖 豆包 + 青色标签 + 加粗 + 分隔线 |
| 普通文本 | 微软雅黑 11pt，支持 Markdown 加粗/斜体/链接/行内代码 |
| 代码块 | Consolas 9.5pt + 浅灰背景 + 语言标签 |
| 表格 | Word 原生 Table + 表头加粗蓝色 |
| 图片 | 居中嵌入，最大宽度 15cm |
| LaTeX | 紫色 Consolas + 浅紫背景 + 🔺标记 |
| 引用 | 灰色斜体 + 左缩进 + ▎标记 |
| 列表 | 有序/无序列表，带缩进 |

## 支持的链接类型

| 类型 | URL 格式 | 提取方式 |
|------|----------|----------|
| 对话分享（线程） | `doubao.com/thread/{token}` | SSR 数据提取 |
| 对话分享（ID） | `doubao.com/chat/share?shareId={id}` | SSR 或浏览器渲染 |
| 智能体分享 | `doubao.com/bot/{id}` | 含智能体元信息 |
| 文件分享 | 云盘分享链接 | 通常需浏览器渲染 |
| 其他豆包链接 | 任意 doubao.com 域名 | 自动检测并尝试 |

## 错误处理

| 错误场景 | 处理方式 |
|----------|----------|
| 静态抓取失败（网络/403） | 提示使用 `--playwright` 模式或 Browser Automation 获取渲染页面 |
| 页面无嵌入数据（需 JS 渲染） | 回退到 `--playwright` 模式或 `--html` 模式 |
| content_v2 解析失败 | 回退到 `content` 字段（纯文本或 JSON 数组格式） |
| content 为 JSON 数组格式 | 按 block_type 数字编码（10000/10001/10002/10003）解析，嵌套 JSON 二次解码 |
| 角色字段缺失 | 按 `role` → `user_type` → `ext.agent_id` → 交替分配 顺序回退 |
| 图片下载失败 | 显示 URL 占位符，不阻断流程 |
| 单条消息解析异常 | 跳过该消息，继续处理后续消息 |

## Resources

### scripts/
- **extract_doubao.py**：核心提取脚本，支持 --url（静态）、--url --playwright（浏览器渲染）、--html 三种输入模式，输出结构化 Word 文档
- **install_deps.py**：依赖安装脚本，一键安装所需 Python 包
- **requirements.txt**：Python 依赖声明（含 playwright 可选依赖）

### references/
- **doubao-page-structure.md**：豆包页面数据结构详细文档，包含 JSON 嵌套结构、block 类型定义、图片数据格式等
