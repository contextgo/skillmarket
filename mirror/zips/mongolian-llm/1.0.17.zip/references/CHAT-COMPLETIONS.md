# 对话 / 表达 / 解释：`POST /chat/completions`

用户意图是「蒙古语表达 / 蒙古语对话 / 文化或语言解释」时，统一调用：

`POST /chat/completions`

- **互译不要用本接口**：**中文、传统蒙古文、西里尔蒙古文互译**（含「译成蒙文」「把这段翻成蒙古文」「西里尔转传统」等）一律使用 **`POST /translation`**，**禁止**用 `POST /chat/completions` 代替翻译（计费与契约不同，且易产生非严格译文）。本接口仅用于对话、说明、从零撰写蒙文内容等，见 [INTERFACE-ROUTING.md](./INTERFACE-ROUTING.md) 中「关键词与接口优先」。

## 推荐脚本调用

若当前 OpenClaw 环境可执行 `node`，优先使用本 Skill 附带脚本调用对话接口：

```bash
node {baseDir}/scripts/mongolian-api.js chat --lang mw --text "用户问题或创作要求"
```

中文回复场景必须指定中文模板：

```bash
node {baseDir}/scripts/mongolian-api.js chat --lang zh --text "中文回答我：用户问题或蒙文内容"
```

脚本会使用固定参数 `model: gpt-5-mw`、`temperature: 0.5`、`max_tokens: 8192`，并只输出 `response.choices[0].message.content`。`--lang mw` 使用纯传统蒙古文模板，`--lang zh` 使用中文回复模板。若未传 `--lang`，脚本会根据输入中是否包含"中文回答"、"用中文"、"中文回复"、"简体中文"等中文输出指令自动选择中文回复模板，否则默认纯传统蒙古文模板。不得再附加解释、JSON、模型名、token 或任何修饰词。若当前环境没有 `node`，再按下方接口说明直接调用 API，并手动只提取 `response.choices[0].message.content`。

## 必填 / 固定参数（本技能须按此填写）

| 参数 | 是否必填 | 取值 | 说明 |
|------|----------|------|------|
| **`model`** | **必填** | 必须为 **`gpt-5-mw`** | 蒙语专用模型标识；**不是** OpenAI 控制台里的模型名，勿替换为 `gpt-4` 等 |
| **`messages`** | **必填** | 非空数组 | 至少包含一条用户消息；可含 `system` + `user`（见下模板） |
| **`temperature`** | **须按本技能** | **`0.5`** | 不要省略或随意改为其它值（除非用户另有明确约定） |
| **`max_tokens`** | **须按本技能** | **`8192`** | 统一按详细模式；不要擅自改得过小 |

- 默认单次请求完成，不做多次续写。

## 请求体模板（纯传统蒙古文 + 详细）

```json
{
  "model": "gpt-5-mw",
  "messages": [
    {"role": "system", "content": "请只用纯传统蒙古文回答，不要包含任何中文汉字。"},
    {"role": "user", "content": "<用户问题>"}
  ],
  "temperature": 0.5,
  "max_tokens": 8192
}
```

## 请求体模板（中文回复）

仅当用户明确要求"中文回答我"、"用中文回答"、"用中文回复"、"请用中文解释"等中文输出时使用：

```json
{
  "model": "gpt-5-mw",
  "messages": [
    {"role": "system", "content": "请使用简体中文回答。若用户输入包含传统蒙古文，请先理解原文语义，再直接给出针对用户请求的中文回复正文。只输出最终中文回复正文；禁止添加问候、自我介绍、解释过程、标题、原文复述或无关补充。若用户明确要求翻译，请不要使用本模板，应改用 POST /translation。"},
    {"role": "user", "content": "<用户问题>"}
  ],
  "temperature": 0.5,
  "max_tokens": 8192
}
```

## 语言判定（简化）

- 若用户要求「用传统蒙古文 / 蒙古文 / 蒙文全程回答」，使用上面的“纯传统蒙古文模板”。
- 若用户要求「中文回答 / 用中文回答 / 用中文回复 / 请用中文解释」，使用“中文回复模板”，脚本调用时必须加 `--lang zh`。
- 若用户明确要求双语，按用户指定输出双语。

语言约束与输出自检见 [BEHAVIOR-RULES.md](./BEHAVIOR-RULES.md)。
