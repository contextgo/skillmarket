# ASR `POST /audio`

用于语音识别，把本地音频或 PCM Base64 转成文本。

## 适用场景

- 用户上传音频、录音、语音文件，要求识别文字
- 用户先要语音转文字，再继续翻译或问答

## 推荐调用

优先使用脚本处理本地音频文件：

```bash
node scripts/mongolian-api.js asr --audio ./sample.wav --language mw
```

`--audio` 会把本地音频文件以 multipart/form-data 上传到后端，由后端服务器转成 PCM 后调用 ASR；Skill 脚本本身不会执行本机命令。支持 `wav`、`mp3`、`m4a`、`aac`、`ogg`、`flac`、`pcm`。

若当前环境已经有 PCM Base64，可直接传：

```bash
node scripts/mongolian-api.js asr --audio-base64 "<PCM_BASE64>" --sample-rate 16000 --language mw
```

## 请求体

```json
{
  "audio": "<PCM 16-bit mono Base64>",
  "language": "mw",
  "sample_rate": 16000
}
```

字段说明：

- `file`：使用 multipart 上传本地音频文件时必填，字段名为 `file`。
- `audio`：使用 JSON 直传时必填。PCM 16-bit mono 的 Base64 内容。
- `language`：可选，默认 `mw`。
- `sample_rate`：可选，默认 `16000`。脚本限制为 `8000`、`16000`、`48000`。

## 响应提取

成功时只提取：

- `data.text`（识别文本）

可选辅助字段（不直接给用户展示，除非用户要求）：

- `data.duration_seconds`
- `data.raw`

## 输出约束（零泄漏）

- 默认最终可见回复只输出 `data.text` 原文；若使用 `mongolian-api.js asr` 且未传 `--no-billing`，stdout 在正文后可能多一行 `[MENGGUYU_BILLING]…`（人民币扣费与余额），须向用户转述。
- 禁止输出请求体、原始 JSON、签名信息、模型信息、调试日志。
- 若用户要求“先识别再翻译”，流程应为：`/audio` 提取文本后，再走 `/translation`。
