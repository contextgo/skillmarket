# API Key 配置

如果用户说 **"配置蒙语API" 或 "蒙语API"**，区分两层：

## 对用户可见（简洁）

- 如用户还没有 Key，先告知获取路径：访问 `https://mongol.open-idea.net` 注册/登录账号。
- 登录后进入后台 API Key 页面，创建并复制完整 Key。
- 再告诉用户：请在输入框粘贴完整 API Key（含前缀，如 `1|xxxx...`）。
- 不向用户展开命令细节（env / 检查步骤由程序自动执行）。

## 程序内部执行（不对用户展开）

1. 写入环境变量：  
   `openclaw config set env.MENGGUYU_API_KEY "<完整API Key>"`

2. **不得使用 `openclaw config get` 核对密钥**：该命令输出会被 OpenClaw **自动脱敏**，无法与用户提供值逐字比对（见下文「OpenClaw 环境变量获取注意事项」）。

3. **检查变量是否已注入（按运行环境选择方法）**：

   OpenClaw 运行时注入的 `MENGGUYU_API_KEY` 为真实值，不会脱敏。根据当前执行环境选用对应方式：

   **Shell / Bash（最常用）**
   ```bash
   # 判断是否设置且非空
   [ -n "$MENGGUYU_API_KEY" ] && echo "已配置" || echo "未配置"

   # 或查看字符数（不暴露内容）
   echo "${#MENGGUYU_API_KEY}"   # 0 = 未设置
   ```

   **Node.js / JavaScript**
   ```js
   const key = process.env.MENGGUYU_API_KEY;
   console.log(key ? "已配置" : "未配置");
   ```

   **Python**
   ```python
   import os
   key = os.environ.get("MENGGUYU_API_KEY", "")
   print("已配置" if key else "未配置")
   ```

   - 任一方式返回非空值 → 变量已注入，继续调用接口
   - 返回空 / `未配置` → 变量未注入，引导用户完成 `config set`，重启 Gateway 后再试

4. 变量确认非空后，立即调用接口，无需再做其他核验。

如果未检测到 `MENGGUYU_API_KEY`，先向用户索取 API Key，不要先做业务回答。

本技能不是插件（plugin），不依赖 `plugins.entries.mongolian-llm.apiKey`。  
API Key 只通过环境变量 `MENGGUYU_API_KEY` 配置，忽略 `plugins.entries` 即可。

## 发现阶段与调用阶段

本 Skill 不在 `metadata.openclaw.requires.env` 中声明强依赖 `MENGGUYU_API_KEY`，目的是让技能在未配置 Key 时也能被 OpenClaw 发现和触发。

但这不代表可以跳过 Key。任何业务调用前仍必须检查 `MENGGUYU_API_KEY` 是否存在且非空：

- 已配置：正常调用 `/translation`、`/chat/completions` 或 `/ocr`
- 未配置：先引导用户配置 API Key，不得直接翻译、识别图片文字或凭模型自身能力解读蒙文

## OpenClaw 环境变量获取注意事项

当在 OpenClaw 中调用蒙语 API 时：

1. **不能使用 `openclaw config get`**：OpenClaw 的安全机制在通过 **`openclaw config get`** 输出敏感信息时会**自动脱敏**，你看到的**不是**完整 API Key，因此**既不能**用该命令做密钥核对，**也不能**把其输出拼进脚本或请求里。
2. **环境变量可直接访问真实值**：运行时可用的 **`MENGGUYU_API_KEY`**（Shell 中常写作 `$MENGGUYU_API_KEY`）为**未脱敏的真实密钥**；调用接口、判断「是否已配置」均应**只认环境变量**，不要硬编码到正文。
3. **调用前检查**：先发请求前确认 **`MENGGUYU_API_KEY` 已存在且非空**；未设置时按上文引导用户完成 `config set` 并确保宿主已注入环境变量，勿用空密钥调用。
