#!/usr/bin/env node

'use strict';

const https = require('https');
const fs = require('fs');
const path = require('path');

const DEFAULT_BASE_URL = 'https://mongol.open-idea.net/api/v1';

/** 与 RelayController 中 X-Mengguyu-Billing-* 响应头一致（Node 中为全小写）。 */
const HDR_BILLING_CURRENCY = 'x-mengguyu-billing-currency';
const HDR_BILLING_CHARGED = 'x-mengguyu-billing-charged';
const HDR_BILLING_BALANCE = 'x-mengguyu-billing-balance';

const MONGOLIAN_SYSTEM_PROMPT = '请只用纯传统蒙古文回答，不要包含任何中文汉字。';
const CHINESE_REPLY_SYSTEM_PROMPT = '请使用简体中文回答。若用户输入包含传统蒙古文，请先理解原文语义，再直接给出针对用户请求的中文回复正文。只输出最终中文回复正文；禁止添加问候、自我介绍、解释过程、标题、原文复述或无关补充。若用户明确要求翻译，请不要使用本模板，应改用 POST /translation。';
const MISSING_API_KEY_MESSAGE = [
  'MENGGUYU_API_KEY 未配置。请按以下步骤操作：',
  '1. 访问 https://mongol.open-idea.net 注册/登录账号',
  '2. 进入后台 API Key 页面，创建并复制完整 Key（含前缀如 `1|xxxx...`）',
  '3. 在本对话中发送以下命令配置密钥（替换为你的完整 Key）：',
  '   openclaw config set env.MENGGUYU_API_KEY "<完整API Key>"',
  '4. 配置后重启 Gateway 或重新开启 OpenClaw 会话，使环境变量生效'
].join('\n');

class CliError extends Error {
  constructor(message, exitCode = 1) {
    super(message);
    this.name = 'CliError';
    this.exitCode = exitCode;
  }
}

function printHelp() {
  process.stdout.write(`mongolian-api.js

Usage:
  node scripts/mongolian-api.js translate --from zh --to mw --text "你好"
  node scripts/mongolian-api.js translate --from mn --to mw --text "Сайн байна уу"
  node scripts/mongolian-api.js translate --text "ᠰᠠᠢᠢᠨ"
  node scripts/mongolian-api.js chat --text "ᠰᠠᠢᠢᠨ ᠪᠠᠢᠢᠨ᠎ᠠ"
  node scripts/mongolian-api.js chat --lang zh --text "中文回答我：ᠰᠠᠢᠢᠨ"
  node scripts/mongolian-api.js ocr --image ./sample.jpg --language mn
  node scripts/mongolian-api.js asr --audio ./sample.wav --language mw
  node scripts/mongolian-api.js word-translate --file ./sample.docx --from auto --to zh
  node scripts/mongolian-api.js pdf-translate --file ./sample.pdf --from auto --to zh
  echo "你好" | node scripts/mongolian-api.js translate --from zh --to mw

Commands:
  translate   Call POST /translation; print data.tgtText and optional [MENGGUYU_BILLING] line.
  chat        Call POST /chat/completions; print message content and optional billing line.
  ocr         Call POST /ocr; print data.text and optional billing line.
  asr         Upload local audio to POST /audio; print data.text and billing line.
  word-translate  Upload .docx to POST /word/translation; print data.text and optional billing line.
  pdf-translate   Upload .pdf to POST /pdf/translation; print data.text and optional billing line.

Options:
  --text <text>       Input text. If omitted, stdin is used.
  --from <zh|mw|mn>   Source language for translate. Auto-detected when omitted.
  --to <zh|mw|mn>     Target language for translate. Auto-detected when omitted.
  --lang <mw|zh>      Output language template for chat. Defaults to mw.
  --system <prompt>   System prompt for chat.
  --image <path>      Local image path for OCR (jpg/png/webp/bmp/tif/tiff/gif).
  --image-base64 <b64>  Direct base64 image content for OCR.
  --language <code>    OCR/ASR language hint. OCR defaults to mn; ASR defaults to mw.
  --image-encoding <ext> OCR image encoding. Auto-detected from --image.
  --audio <path>      Local audio path for ASR (wav/mp3/m4a/aac/ogg/flac/pcm).
  --audio-base64 <b64>  Direct base64 PCM 16-bit mono audio for ASR.
  --sample-rate <n>   ASR PCM sample rate: 8000, 16000, or 48000. Defaults to 16000.
  --file <path>       Local .docx/.pdf path for document translation.
  --mode <mongolian_only|all_text>  Document translation mode. Defaults to mongolian_only.
  --no-billing        Machine piping only. Agents must not use; users need balance notice.
  --help              Show this help.

Environment:
  MENGGUYU_API_KEY    Required API key.
`);
}

function parseArgs(argv) {
  const result = { _: [] };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];

    if (!arg.startsWith('--')) {
      result._.push(arg);
      continue;
    }

    const eq = arg.indexOf('=');
    if (eq !== -1) {
      result[arg.slice(2, eq)] = arg.slice(eq + 1);
      continue;
    }

    const key = arg.slice(2);
    const next = argv[i + 1];
    if (!next || next.startsWith('--')) {
      result[key] = true;
      continue;
    }

    result[key] = next;
    i += 1;
  }

  return result;
}

function readStdin() {
  return new Promise((resolve, reject) => {
    let data = '';
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', chunk => {
      data += chunk;
    });
    process.stdin.on('end', () => resolve(data.replace(/\r?\n$/, '')));
    process.stdin.on('error', reject);
  });
}

function hasTraditionalMongolian(text) {
  return /[\u1800-\u18AF]/u.test(text);
}

function hasCyrillic(text) {
  return /[\u0400-\u04FF]/u.test(text);
}

function inferSourceLanguage(text) {
  if (hasTraditionalMongolian(text)) return 'mw';
  if (hasCyrillic(text)) return 'mn';
  return 'zh';
}

function defaultTargetForSource(source) {
  return source === 'zh' ? 'mw' : 'zh';
}

function inferDirection(text, from, to) {
  const source = from || inferSourceLanguage(text);

  return {
    from: source,
    to: to || defaultTargetForSource(source)
  };
}

function validateTranslationLanguage(value, name) {
  if (value !== 'zh' && value !== 'mw' && value !== 'mn') {
    throw new CliError(`${name} must be "zh", "mw", or "mn".`);
  }
}

function validateChatLanguage(value, name) {
  if (value !== 'zh' && value !== 'mw') {
    throw new CliError(`${name} must be "zh" or "mw".`);
  }
}

function hasChineseOutputInstruction(text) {
  return /(?:中文(?:回答|回复|解释|输出|说|讲)|用中文|简体中文)/iu.test(text);
}

function getChatSystemPrompt(args, text) {
  if (args.system) {
    return String(args.system);
  }

  const lang = args.lang || (hasChineseOutputInstruction(text) ? 'zh' : 'mw');
  validateChatLanguage(lang, '--lang');

  return lang === 'zh' ? CHINESE_REPLY_SYSTEM_PROMPT : MONGOLIAN_SYSTEM_PROMPT;
}

function readImageAsBase64(filePath) {
  const absolutePath = path.resolve(String(filePath));
  if (!fs.existsSync(absolutePath)) {
    throw new CliError(`Image file not found: ${absolutePath}`);
  }

  const buffer = fs.readFileSync(absolutePath);
  if (!buffer.length) {
    throw new CliError('Image file is empty.');
  }

  return {
    base64: buffer.toString('base64'),
    ext: path.extname(absolutePath).replace('.', '').toLowerCase()
  };
}

function validateAsrSampleRate(value) {
  const sampleRate = Number.parseInt(String(value || '16000'), 10);
  if (![8000, 16000, 48000].includes(sampleRate)) {
    throw new CliError('--sample-rate must be 8000, 16000, or 48000.');
  }
  return sampleRate;
}

function pickHeader(headers, name) {
  const v = headers[name];
  if (v === undefined || v === null) {
    return null;
  }
  return Array.isArray(v) ? v[0] : String(v);
}

/** @returns {{ currency: string, charged: string, balance: string } | null} */
function parseBillingFromHeaders(headers) {
  if (!headers || typeof headers !== 'object') {
    return null;
  }
  const balance = pickHeader(headers, HDR_BILLING_BALANCE);
  if (balance === null || balance === '') {
    return null;
  }
  return {
    currency: pickHeader(headers, HDR_BILLING_CURRENCY) || 'CNY',
    charged: pickHeader(headers, HDR_BILLING_CHARGED) || '0',
    balance: String(balance)
  };
}

/**
 * @param {{ currency: string, charged: string, balance: string }} billing
 */
function formatBillingLine(billing) {
  return `[MENGGUYU_BILLING] 本次扣费 ¥${billing.charged}，当前账户余额 ¥${billing.balance}（${billing.currency}，与控制台「充值」页当前余额一致）。`;
}

function normalizeImageEncoding(rawEncoding, fallbackExt) {
  const source = String(rawEncoding || fallbackExt || 'jpg').toLowerCase();
  if (source === 'jpeg') {
    return 'jpg';
  }

  const allowed = new Set(['jpg', 'png', 'bmp', 'webp', 'tif', 'tiff', 'gif']);
  if (!allowed.has(source)) {
    throw new CliError(`Unsupported image encoding: ${source}`);
  }
  return source;
}

function buildOcrPayload(args) {
  let imageBase64 = args['image-base64'] ? String(args['image-base64']) : '';
  let ext = '';

  if (args.image) {
    const image = readImageAsBase64(args.image);
    imageBase64 = image.base64;
    ext = image.ext;
  }

  if (!imageBase64) {
    throw new CliError('OCR requires --image <path> or --image-base64 <base64>.');
  }

  return {
    image_base64: imageBase64,
    language: String(args.language || 'mn').toLowerCase(),
    image_encoding: normalizeImageEncoding(args['image-encoding'], ext)
  };
}

function buildAsrPayload(args) {
  const sampleRate = validateAsrSampleRate(args['sample-rate']);
  let audioBase64 = args['audio-base64'] ? String(args['audio-base64']) : '';

  if (!audioBase64) {
    throw new CliError('ASR requires --audio <path> or --audio-base64 <pcm-base64>.');
  }

  return {
    audio: audioBase64,
    language: String(args.language || 'mw').toLowerCase(),
    sample_rate: sampleRate
  };
}

function detectAudioContentType(filePath) {
  const ext = path.extname(String(filePath)).replace('.', '').toLowerCase();
  const map = {
    wav: 'audio/wav',
    mp3: 'audio/mpeg',
    m4a: 'audio/mp4',
    aac: 'audio/aac',
    ogg: 'audio/ogg',
    oga: 'audio/ogg',
    flac: 'audio/flac',
    pcm: 'application/octet-stream'
  };
  return map[ext] || 'application/octet-stream';
}

function postJson(urlString, apiKey, body, attempt = 1) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlString);
    const payload = JSON.stringify(body);
    if (url.protocol !== 'https:' || url.hostname !== 'mongol.open-idea.net') {
      reject(new CliError('Refusing to send API credentials to a non-official HTTPS endpoint.'));
      return;
    }

    const req = https.request(
      {
        method: 'POST',
        hostname: url.hostname,
        port: url.port || undefined,
        path: `${url.pathname}${url.search}`,
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: 60000
      },
      res => {
        let raw = '';
        res.setEncoding('utf8');
        res.on('data', chunk => {
          raw += chunk;
        });
        res.on('end', () => {
          const billing = parseBillingFromHeaders(res.headers);
          let parsed;
          try {
            parsed = raw ? JSON.parse(raw) : {};
          } catch (error) {
            reject(new CliError(`API returned invalid JSON (HTTP ${res.statusCode}).`));
            return;
          }

          if (res.statusCode >= 500 && attempt < 3) {
            setTimeout(() => {
              postJson(urlString, apiKey, body, attempt + 1).then(resolve, reject);
            }, attempt * 1000);
            return;
          }

          if (res.statusCode < 200 || res.statusCode >= 300) {
            const message = parsed.message || parsed.error || `HTTP ${res.statusCode}`;
            const err = new CliError(`API request failed: ${message}`);
            if (billing) {
              err.billing = billing;
            }
            reject(err);
            return;
          }

          resolve({ json: parsed, billing });
        });
      }
    );

    req.on('timeout', () => {
      req.destroy(new CliError('API request timed out.'));
    });

    req.on('error', error => {
      if (attempt < 3) {
        setTimeout(() => {
          postJson(urlString, apiKey, body, attempt + 1).then(resolve, reject);
        }, attempt * 1000);
        return;
      }
      reject(error);
    });

    req.write(payload);
    req.end();
  });
}

function postMultipart(urlString, apiKey, fields, fileField, attempt = 1) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlString);
    if (url.protocol !== 'https:' || url.hostname !== 'mongol.open-idea.net') {
      reject(new CliError('Refusing to send API credentials to a non-official HTTPS endpoint.'));
      return;
    }

    const boundary = `----MENGGUYU${Date.now().toString(16)}${Math.random().toString(16).slice(2)}`;
    const parts = [];
    for (const [name, value] of Object.entries(fields)) {
      if (value === undefined || value === null) continue;
      parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${String(value)}\r\n`, 'utf8'));
    }

    const absolutePath = path.resolve(String(fileField.path));
    if (!fs.existsSync(absolutePath)) {
      reject(new CliError(`File not found: ${absolutePath}`));
      return;
    }
    const fileBuffer = fs.readFileSync(absolutePath);
    if (!fileBuffer.length) {
      reject(new CliError('File is empty.'));
      return;
    }
    const filename = path.basename(absolutePath).replace(/"/g, '');
    const contentType = fileField.contentType || 'application/octet-stream';
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${fileField.name}"; filename="${filename}"\r\nContent-Type: ${contentType}\r\n\r\n`, 'utf8'));
    parts.push(fileBuffer);
    parts.push(Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8'));

    const payload = Buffer.concat(parts);
    const req = https.request(
      {
        method: 'POST',
        hostname: url.hostname,
        port: url.port || undefined,
        path: `${url.pathname}${url.search}`,
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': `multipart/form-data; boundary=${boundary}`,
          'Content-Length': payload.length
        },
        timeout: 120000
      },
      res => {
        let raw = '';
        res.setEncoding('utf8');
        res.on('data', chunk => {
          raw += chunk;
        });
        res.on('end', () => {
          const billing = parseBillingFromHeaders(res.headers);
          let parsed;
          try {
            parsed = raw ? JSON.parse(raw) : {};
          } catch (error) {
            reject(new CliError(`API returned invalid JSON (HTTP ${res.statusCode}).`));
            return;
          }

          if (res.statusCode >= 500 && attempt < 3) {
            setTimeout(() => {
              postMultipart(urlString, apiKey, fields, fileField, attempt + 1).then(resolve, reject);
            }, attempt * 1000);
            return;
          }

          if (res.statusCode < 200 || res.statusCode >= 300) {
            const message = parsed.message || (parsed.error && parsed.error.message) || parsed.error || `HTTP ${res.statusCode}`;
            const err = new CliError(`API request failed: ${message}`);
            if (billing) {
              err.billing = billing;
            }
            reject(err);
            return;
          }

          resolve({ json: parsed, billing });
        });
      }
    );

    req.on('timeout', () => {
      req.destroy(new CliError('API request timed out.'));
    });

    req.on('error', error => {
      if (attempt < 3) {
        setTimeout(() => {
          postMultipart(urlString, apiKey, fields, fileField, attempt + 1).then(resolve, reject);
        }, attempt * 1000);
        return;
      }
      reject(error);
    });

    req.write(payload);
    req.end();
  });
}

function extractTranslation(response) {
  const text = response && response.data && response.data.tgtText;
  if (typeof text !== 'string') {
    throw new CliError('API response missing data.tgtText.');
  }
  return text;
}

function extractChatContent(response) {
  const content = response &&
    response.choices &&
    response.choices[0] &&
    response.choices[0].message &&
    response.choices[0].message.content;

  if (typeof content !== 'string') {
    throw new CliError('API response missing choices[0].message.content.');
  }

  return content;
}

function extractOcrText(response) {
  const text = response && response.data && response.data.text;
  if (typeof text !== 'string') {
    throw new CliError('API response missing data.text.');
  }
  return text;
}

function extractAsrText(response) {
  const text = response && response.data && response.data.text;
  if (typeof text !== 'string') {
    throw new CliError('API response missing data.text.');
  }
  return text;
}

function extractWordTranslationText(response) {
  const text = response && response.data && response.data.text;
  if (typeof text !== 'string') {
    throw new CliError('API response missing data.text.');
  }
  return text;
}

function extractPdfTranslationText(response) {
  const text = response && response.data && response.data.text;
  if (typeof text !== 'string') {
    throw new CliError('API response missing data.text.');
  }
  return text;
}

function appendBillingIfNeeded(text, billing, args) {
  if (args['no-billing'] || !billing) {
    return text;
  }
  const line = formatBillingLine(billing);
  const base = text.endsWith('\n') ? text.slice(0, -1) : text;
  return `${base}\n${line}`;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));

  if (args.help || args._[0] === 'help' || !args._[0]) {
    printHelp();
    return;
  }

  const command = args._[0];
  const apiKey = process.env.MENGGUYU_API_KEY;
  if (!apiKey) {
    process.stdout.write(`${MISSING_API_KEY_MESSAGE}\n`);
    return;
  }

  const baseUrl = DEFAULT_BASE_URL;

  if (command === 'translate') {
    const text = args.text !== undefined ? String(args.text) : await readStdin();
    if (!text) {
      throw new CliError('Input text is required. Use --text or pipe content through stdin.');
    }

    const { from, to } = inferDirection(text, args.from, args.to);
    validateTranslationLanguage(from, '--from');
    validateTranslationLanguage(to, '--to');

    const { json, billing } = await postJson(`${baseUrl}/translation`, apiKey, {
      from,
      to,
      content: text
    });
    const body = appendBillingIfNeeded(extractTranslation(json), billing, args);
    process.stdout.write(`${body}\n`);
    return;
  }

  if (command === 'chat') {
    const text = args.text !== undefined ? String(args.text) : await readStdin();
    if (!text) {
      throw new CliError('Input text is required. Use --text or pipe content through stdin.');
    }

    const { json, billing } = await postJson(`${baseUrl}/chat/completions`, apiKey, {
      model: 'gpt-5-mw',
      messages: [
        { role: 'system', content: getChatSystemPrompt(args, text) },
        { role: 'user', content: text }
      ],
      temperature: 0.5,
      max_tokens: 8192
    });
    const body = appendBillingIfNeeded(extractChatContent(json), billing, args);
    process.stdout.write(`${body}\n`);
    return;
  }

  if (command === 'ocr') {
    const payload = buildOcrPayload(args);
    const { json, billing } = await postJson(`${baseUrl}/ocr`, apiKey, payload);
    const body = appendBillingIfNeeded(extractOcrText(json), billing, args);
    process.stdout.write(`${body}\n`);
    return;
  }

  if (command === 'asr') {
    const sampleRate = validateAsrSampleRate(args['sample-rate']);
    let result;
    if (args.audio) {
      result = await postMultipart(`${baseUrl}/audio`, apiKey, {
        language: String(args.language || 'mw').toLowerCase(),
        sample_rate: sampleRate
      }, {
        name: 'file',
        path: args.audio,
        contentType: detectAudioContentType(args.audio)
      });
    } else {
      const payload = buildAsrPayload(args);
      result = await postJson(`${baseUrl}/audio`, apiKey, payload);
    }
    const { json, billing } = result;
    const body = appendBillingIfNeeded(extractAsrText(json), billing, args);
    process.stdout.write(`${body}\n`);
    return;
  }

  if (command === 'word-translate') {
    if (!args.file) {
      throw new CliError('word-translate requires --file <path-to-docx>.');
    }
    const from = String(args.from || 'auto').toLowerCase();
    if (from !== 'auto') {
      validateTranslationLanguage(from, '--from');
    }
    const to = String(args.to || 'zh').toLowerCase();
    validateTranslationLanguage(to, '--to');
    const mode = String(args.mode || 'mongolian_only');
    if (mode !== 'mongolian_only' && mode !== 'all_text') {
      throw new CliError('--mode must be "mongolian_only" or "all_text".');
    }

    const { json, billing } = await postMultipart(`${baseUrl}/word/translation`, apiKey, {
      from,
      to,
      mode
    }, {
      name: 'file',
      path: args.file,
      contentType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    });
    const body = appendBillingIfNeeded(extractWordTranslationText(json), billing, args);
    process.stdout.write(`${body}\n`);
    return;
  }

  if (command === 'pdf-translate') {
    if (!args.file) {
      throw new CliError('pdf-translate requires --file <path-to-pdf>.');
    }
    const from = String(args.from || 'auto').toLowerCase();
    if (from !== 'auto') {
      validateTranslationLanguage(from, '--from');
    }
    const to = String(args.to || 'zh').toLowerCase();
    validateTranslationLanguage(to, '--to');
    const mode = String(args.mode || 'mongolian_only');
    if (mode !== 'mongolian_only' && mode !== 'all_text') {
      throw new CliError('--mode must be "mongolian_only" or "all_text".');
    }

    const { json, billing } = await postMultipart(`${baseUrl}/pdf/translation`, apiKey, {
      from,
      to,
      mode
    }, {
      name: 'file',
      path: args.file,
      contentType: 'application/pdf'
    });
    const body = appendBillingIfNeeded(extractPdfTranslationText(json), billing, args);
    process.stdout.write(`${body}\n`);
    return;
  }

  throw new CliError(`Unknown command: ${command}`);
}

main().catch(error => {
  let message = error instanceof Error ? error.message : String(error);
  if (error && error.billing && !process.argv.includes('--no-billing')) {
    message += `\n${formatBillingLine(error.billing)}`;
  }
  process.stderr.write(`${message}\n`);
  process.exit(error.exitCode || 1);
});
