#!/usr/bin/env node

'use strict';

const fs = require('fs');
const path = require('path');

class CliError extends Error {
  constructor(message, exitCode = 1) {
    super(message);
    this.name = 'CliError';
    this.exitCode = exitCode;
  }
}

function printHelp() {
  process.stdout.write(`image-to-base64.js

Usage:
  node scripts/image-to-base64.js --image ./sample.jpg
  node scripts/image-to-base64.js --image ./sample.png --data-uri
  node scripts/image-to-base64.js --image ./sample.webp --json

Options:
  --image <path>     Required local image path.
  --json             Print JSON object output.
  --data-uri         Include data:image/...;base64, prefix.
  --help             Show this help.
`);
}

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (!arg.startsWith('--')) {
      args._.push(arg);
      continue;
    }

    const eq = arg.indexOf('=');
    if (eq !== -1) {
      args[arg.slice(2, eq)] = arg.slice(eq + 1);
      continue;
    }

    const key = arg.slice(2);
    const next = argv[i + 1];
    if (!next || next.startsWith('--')) {
      args[key] = true;
      continue;
    }

    args[key] = next;
    i += 1;
  }

  return args;
}

function normalizeEncoding(ext) {
  const value = String(ext || '').replace(/^\./, '').toLowerCase();
  const map = {
    jpeg: 'jpg',
    tif: 'tif',
    tiff: 'tiff',
    jpg: 'jpg',
    png: 'png',
    webp: 'webp',
    bmp: 'bmp',
    gif: 'gif'
  };

  if (!map[value]) {
    throw new CliError(`Unsupported image extension: ${value || '(empty)'}`);
  }

  return map[value];
}

function mimeFromEncoding(encoding) {
  return encoding === 'jpg' ? 'jpeg' : encoding;
}

function readImage(imagePath) {
  const absolutePath = path.resolve(String(imagePath || ''));
  if (!absolutePath) {
    throw new CliError('--image is required.');
  }

  if (!fs.existsSync(absolutePath)) {
    throw new CliError(`Image file not found: ${absolutePath}`);
  }

  const buffer = fs.readFileSync(absolutePath);
  if (!buffer.length) {
    throw new CliError('Image file is empty.');
  }

  const encoding = normalizeEncoding(path.extname(absolutePath));
  return {
    image_encoding: encoding,
    image_base64: buffer.toString('base64')
  };
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    printHelp();
    return;
  }

  const payload = readImage(args.image);
  const useDataUri = Boolean(args['data-uri']);

  if (useDataUri) {
    payload.image_base64 = `data:image/${mimeFromEncoding(payload.image_encoding)};base64,${payload.image_base64}`;
  }

  if (args.json) {
    process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`);
    return;
  }

  process.stdout.write(`image_encoding=${payload.image_encoding}\n`);
  process.stdout.write(`image_base64=${payload.image_base64}\n`);
}

try {
  main();
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exit(error && error.exitCode ? error.exitCode : 1);
}

