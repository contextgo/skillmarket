#!/usr/bin/env node

'use strict';

const https = require('https');
const fs = require('fs');
const path = require('path');

const DEFAULT_BASE_URL = 'https://mongol.open-idea.net/api/v1';
const MONGOLIAN_SYSTEM_PROMPT = '请只用纯传统蒙古文回答，不要包含任何中文汉字。';
const CHINESE_REPLY_SYSTEM_PROMPT = '请使用简体中文回答。若用户输入包含传统蒙古文，请先理解原文语义，再直接给出针对用户请求的中文回复正文。只输出最终中文回复正文；禁止添加问候、自我介绍、解释过程、标题、原文复述或无关补充。若用户明确要求翻译，请不要使用本模板，应改用 POST /translation。';
const MISSING_API_KEY_MESSAGE = [
  'MENGGUYU_API_KEY 未配置。请按以下步骤操作：',
  '1. 访问 https://mongol.open-idea.net 注册/登录账号',
  '2. 进入后台 API Key 页面，创建并复制完整 Key（含前缀如 `1|xxxx...`）',
  '3. 在本对话中发送以下命令配置密钥（替换为你的完整 Key）：',
  '   openclaw config set env.MENGGUYU_API_KEY "<完整API Key>"',
  '4. 配置后重启 Gateway 或重新开启 OpenClaw 会话，使环境变量生效'
].join('\n');

class CliError extends Error {
  constructor(message, exitCode = 1) {
    super(message);
    this.name = 'CliError';
    this.exitCode = exitCode;
  }
}

function printHelp() {
  process.stdout.write(`mongolian-api.js

Usage:
  node scripts/mongolian-api.js translate --from zh --to mw --text "你好"
  node scripts/mongolian-api.js translate --from mn --to mw --text "Сайн байна уу"
  node scripts/mongolian-api.js translate --text "ᠰᠠᠢᠢᠨ"
  node scripts/mongolian-api.js chat --text "ᠰᠠᠢᠢᠨ ᠪᠠᠢᠢᠨ᠎ᠠ"
  node scripts/mongolian-api.js chat --lang zh --text "中文回答我：ᠰᠠᠢᠢᠨ"
  node scripts/mongolian-api.js ocr --image ./sample.jpg --language mn
  echo "你好" | node scripts/mongolian-api.js translate --from zh --to mw

Commands:
  translate   Call POST /translation and print only data.tgtText.
  chat        Call POST /chat/completions and print only choices[0].message.content.
  ocr         Call POST /ocr and print only data.text.

Options:
  --text <text>       Input text. If omitted, stdin is used.
  --from <zh|mw|mn>   Source language for translate. Auto-detected when omitted.
  --to <zh|mw|mn>     Target language for translate. Auto-detected when omitted.
  --lang <mw|zh>      Output language template for chat. Defaults to mw.
  --system <prompt>   System prompt for chat.
  --image <path>      Local image path for OCR (jpg/png/webp/bmp/tif/tiff/gif).
  --image-base64 <b64>  Direct base64 image content for OCR.
  --language <mn|zh|en> OCR language hint. Defaults to mn.
  --image-encoding <ext> OCR image encoding. Auto-detected from --image.
  --help              Show this help.

Environment:
  MENGGUYU_API_KEY    Required API key.
`);
}

function parseArgs(argv) {
  const result = { _: [] };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];

    if (!arg.startsWith('--')) {
      result._.push(arg);
      continue;
    }

    const eq = arg.indexOf('=');
    if (eq !== -1) {
      result[arg.slice(2, eq)] = arg.slice(eq + 1);
      continue;
    }

    const key = arg.slice(2);
    const next = argv[i + 1];
    if (!next || next.startsWith('--')) {
      result[key] = true;
      continue;
    }

    result[key] = next;
    i += 1;
  }

  return result;
}

function readStdin() {
  return new Promise((resolve, reject) => {
    let data = '';
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', chunk => {
      data += chunk;
    });
    process.stdin.on('end', () => resolve(data.replace(/\r?\n$/, '')));
    process.stdin.on('error', reject);
  });
}

function hasTraditionalMongolian(text) {
  return /[\u1800-\u18AF]/u.test(text);
}

function hasCyrillic(text) {
  return /[\u0400-\u04FF]/u.test(text);
}

function inferSourceLanguage(text) {
  if (hasTraditionalMongolian(text)) return 'mw';
  if (hasCyrillic(text)) return 'mn';
  return 'zh';
}

function defaultTargetForSource(source) {
  return source === 'zh' ? 'mw' : 'zh';
}

function inferDirection(text, from, to) {
  const source = from || inferSourceLanguage(text);

  return {
    from: source,
    to: to || defaultTargetForSource(source)
  };
}

function validateTranslationLanguage(value, name) {
  if (value !== 'zh' && value !== 'mw' && value !== 'mn') {
    throw new CliError(`${name} must be "zh", "mw", or "mn".`);
  }
}

function validateChatLanguage(value, name) {
  if (value !== 'zh' && value !== 'mw') {
    throw new CliError(`${name} must be "zh" or "mw".`);
  }
}

function hasChineseOutputInstruction(text) {
  return /(?:中文(?:回答|回复|解释|输出|说|讲)|用中文|简体中文)/iu.test(text);
}

function getChatSystemPrompt(args, text) {
  if (args.system) {
    return String(args.system);
  }

  const lang = args.lang || (hasChineseOutputInstruction(text) ? 'zh' : 'mw');
  validateChatLanguage(lang, '--lang');

  return lang === 'zh' ? CHINESE_REPLY_SYSTEM_PROMPT : MONGOLIAN_SYSTEM_PROMPT;
}

function readImageAsBase64(filePath) {
  const absolutePath = path.resolve(String(filePath));
  if (!fs.existsSync(absolutePath)) {
    throw new CliError(`Image file not found: ${absolutePath}`);
  }

  const buffer = fs.readFileSync(absolutePath);
  if (!buffer.length) {
    throw new CliError('Image file is empty.');
  }

  return {
    base64: buffer.toString('base64'),
    ext: path.extname(absolutePath).replace('.', '').toLowerCase()
  };
}

function normalizeImageEncoding(rawEncoding, fallbackExt) {
  const source = String(rawEncoding || fallbackExt || 'jpg').toLowerCase();
  if (source === 'jpeg') {
    return 'jpg';
  }

  const allowed = new Set(['jpg', 'png', 'bmp', 'webp', 'tif', 'tiff', 'gif']);
  if (!allowed.has(source)) {
    throw new CliError(`Unsupported image encoding: ${source}`);
  }
  return source;
}

function buildOcrPayload(args) {
  let imageBase64 = args['image-base64'] ? String(args['image-base64']) : '';
  let ext = '';

  if (args.image) {
    const image = readImageAsBase64(args.image);
    imageBase64 = image.base64;
    ext = image.ext;
  }

  if (!imageBase64) {
    throw new CliError('OCR requires --image <path> or --image-base64 <base64>.');
  }

  return {
    image_base64: imageBase64,
    language: String(args.language || 'mn').toLowerCase(),
    image_encoding: normalizeImageEncoding(args['image-encoding'], ext)
  };
}

function postJson(urlString, apiKey, body, attempt = 1) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlString);
    const payload = JSON.stringify(body);
    if (url.protocol !== 'https:' || url.hostname !== 'mongol.open-idea.net') {
      reject(new CliError('Refusing to send API credentials to a non-official HTTPS endpoint.'));
      return;
    }

    const req = https.request(
      {
        method: 'POST',
        hostname: url.hostname,
        port: url.port || undefined,
        path: `${url.pathname}${url.search}`,
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: 60000
      },
      res => {
        let raw = '';
        res.setEncoding('utf8');
        res.on('data', chunk => {
          raw += chunk;
        });
        res.on('end', () => {
          let parsed;
          try {
            parsed = raw ? JSON.parse(raw) : {};
          } catch (error) {
            reject(new CliError(`API returned invalid JSON (HTTP ${res.statusCode}).`));
            return;
          }

          if (res.statusCode >= 500 && attempt < 3) {
            setTimeout(() => {
              postJson(urlString, apiKey, body, attempt + 1).then(resolve, reject);
            }, attempt * 1000);
            return;
          }

          if (res.statusCode < 200 || res.statusCode >= 300) {
            const message = parsed.message || parsed.error || `HTTP ${res.statusCode}`;
            reject(new CliError(`API request failed: ${message}`));
            return;
          }

          resolve(parsed);
        });
      }
    );

    req.on('timeout', () => {
      req.destroy(new CliError('API request timed out.'));
    });

    req.on('error', error => {
      if (attempt < 3) {
        setTimeout(() => {
          postJson(urlString, apiKey, body, attempt + 1).then(resolve, reject);
        }, attempt * 1000);
        return;
      }
      reject(error);
    });

    req.write(payload);
    req.end();
  });
}

function extractTranslation(response) {
  const text = response && response.data && response.data.tgtText;
  if (typeof text !== 'string') {
    throw new CliError('API response missing data.tgtText.');
  }
  return text;
}

function extractChatContent(response) {
  const content = response &&
    response.choices &&
    response.choices[0] &&
    response.choices[0].message &&
    response.choices[0].message.content;

  if (typeof content !== 'string') {
    throw new CliError('API response missing choices[0].message.content.');
  }

  return content;
}

function extractOcrText(response) {
  const text = response && response.data && response.data.text;
  if (typeof text !== 'string') {
    throw new CliError('API response missing data.text.');
  }
  return text;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));

  if (args.help || args._[0] === 'help' || !args._[0]) {
    printHelp();
    return;
  }

  const command = args._[0];
  const apiKey = process.env.MENGGUYU_API_KEY;
  if (!apiKey) {
    process.stdout.write(`${MISSING_API_KEY_MESSAGE}\n`);
    return;
  }

  const baseUrl = DEFAULT_BASE_URL;

  if (command === 'translate') {
    const text = args.text !== undefined ? String(args.text) : await readStdin();
    if (!text) {
      throw new CliError('Input text is required. Use --text or pipe content through stdin.');
    }

    const { from, to } = inferDirection(text, args.from, args.to);
    validateTranslationLanguage(from, '--from');
    validateTranslationLanguage(to, '--to');

    const response = await postJson(`${baseUrl}/translation`, apiKey, {
      from,
      to,
      content: text
    });
    process.stdout.write(`${extractTranslation(response)}\n`);
    return;
  }

  if (command === 'chat') {
    const text = args.text !== undefined ? String(args.text) : await readStdin();
    if (!text) {
      throw new CliError('Input text is required. Use --text or pipe content through stdin.');
    }

    const response = await postJson(`${baseUrl}/chat/completions`, apiKey, {
      model: 'gpt-5-mw',
      messages: [
        { role: 'system', content: getChatSystemPrompt(args, text) },
        { role: 'user', content: text }
      ],
      temperature: 0.5,
      max_tokens: 8192
    });
    process.stdout.write(`${extractChatContent(response)}\n`);
    return;
  }

  if (command === 'ocr') {
    const payload = buildOcrPayload(args);
    const response = await postJson(`${baseUrl}/ocr`, apiKey, payload);
    process.stdout.write(`${extractOcrText(response)}\n`);
    return;
  }

  throw new CliError(`Unknown command: ${command}`);
}

main().catch(error => {
  const message = error instanceof Error ? error.message : String(error);
  process.stderr.write(`${message}\n`);
  process.exit(error.exitCode || 1);
});
