# 翻译：`POST /translation`

如果用户要求 **中文、传统蒙古文、西里尔蒙古文互译**：使用 **`POST /translation`**（按字符计费；不要用 `POST /chat/completions` 代替翻译）。

## 推荐脚本调用

若当前 OpenClaw 环境可执行 `node`，优先使用本 Skill 附带脚本调用翻译接口：

```bash
node {baseDir}/scripts/mongolian-api.js translate --from zh --to mw --text "待译正文"
node {baseDir}/scripts/mongolian-api.js translate --from mn --to mw --text "Сайн байна уу"
```

也可以省略 `--from` / `--to`，脚本会根据文本字符自动判断默认方向：

```bash
node {baseDir}/scripts/mongolian-api.js translate --text "待译正文"
```

脚本只输出 `data.tgtText`，不得再附加解释、JSON、模型名、token 或任何修饰词。若当前环境没有 `node`，再按下方接口说明直接调用 API，并手动只提取 `data.tgtText`。

调用

`POST /translation`

（Base URL 同站：`…/api/v1`，JSON body；认证方式与其它接口一致。）

## 必填参数（须全部提供，缺一不可）

| 参数 | 类型 | 取值 | 说明 |
|------|------|------|------|
| **`from`** | string | `zh`、`mw` 或 `mn` | 源语言：中文为 `zh`，传统蒙古文为 `mw`，西里尔蒙古文为 `mn` |
| **`to`** | string | `zh`、`mw` 或 `mn` | 目标语言：与 `from` 组合表示翻译方向 |
| **`content`** | string | 待译正文 | 须遵守下文「请求体中的换行」规则 |

示例 JSON（字段名与上表一致）：

```json
{
  "from": "zh|mw|mn",
  "to": "zh|mw|mn",
  "content": "文本"
}
```

## 蒙蒙互译（经中文中转）

- 传统蒙古文 `mw` 与西里尔蒙古文 `mn` 互译时，调用方仍只请求一次本站 `POST /translation`。
- 后台会按科大讯飞能力经中文中转执行两次上游调用：`mw -> zh -> mn` 或 `mn -> zh -> mw`。
- 最终仍只输出响应中的 `data.tgtText`，不得展示中间中文译文、上游响应或调用过程。
- 该方向会产生两次上游翻译调用成本，费用估算时应按两段调用考虑。

## 请求体中的换行（必须）

- 组装 `POST /translation` 的 JSON 时，`content` **不得**把「真实换行符」直接嵌进请求体（易导致 body 截断、解析失败或上游报错）。
- 正确做法：按 **JSON 字符串规则** 转义——原文里的换行在 JSON 里写成 **`\n`（反斜杠 + 字母 n，两个字符）**，由 JSON 库 / `json_encode` / `JSON.stringify` 等自动生成即可。
- 若用手写 `curl` 或拼接字符串，务必先得到**合法单行 JSON**（换行已变为 `\n`），再作为请求体发送；不要用未闭合引号跨多行拼 `content`。
- 分段逻辑里仍可按语义在「换行处」切分原文；每一段在填入 `content` 前，把段内换行统一转为 JSON 所需的 `\n` 转义（或由序列化器处理）。

## JSON 请求体构建最佳实践（脚本 / curl）

构建翻译等 JSON 请求时：

1. **使用 Python 等生成 JSON 字符串，避免手写转义错误**（示例：仅将正文编码为 JSON 字符串字面量）：

```bash
CONTENT=$(echo "文本内容" | python3 -c "import json, sys; print(json.dumps(sys.stdin.read()))")
```

此处 `CONTENT` 为**一整段合法 JSON 字符串值**（含外层双引号及内部转义），可直接作为对象里 `content` 字段的「值」占位使用。

2. **避免双重引号**：若 `CONTENT` 已由 `json.dumps` 得到（外层已是 JSON 字符串的引号），**不要再**用外层 `\"…\"` 把它包第二层，否则会破坏 JSON。

错误示例（在 `CONTENT` 已是 `"…"` 形式时仍再包引号）：

```bash
# 错误：易导致非法 JSON
curl ... -d "{\"content\": \"$CONTENT\"}"
```

更稳妥：用 Python **一次性**生成整个请求体（推荐），或对「整段 body」使用 `json.dumps({...})`，避免在 shell 里拼接嵌套引号。

若确需手工拼接且 `CONTENT` 为 `json.dumps` 的完整字符串输出，则**不要再**给该值加额外引号，例如：

```bash
# 仅当 CONTENT 已是带引号的 JSON 字符串字面量时，按字段位置直接接入（注意逗号与其它必填字段）
curl ... -d "{\"from\":\"zh\",\"to\":\"mw\",\"content\":$CONTENT}"
```

3. **换行符**：与上文「请求体中的换行」一致——真实换行必须变为 JSON 中的 `\n`；用序列化库生成 body 时一般由库自动处理。

## 翻译方向（自动判定）

- 若待译文本包含传统蒙古文字符（U+1800–U+18AF）→ `from`: `mw`，`to`: `zh`。
- 若待译文本包含西里尔字符（U+0400–U+04FF）→ `from`: `mn`，`to`: `zh`。
- 否则视为中文原文 → `from`: `zh`，`to`: `mw`。
- 若用户明确要求“西里尔转传统”“传统转西里尔”“蒙蒙互译”，必须显式传入 `--from mn --to mw` 或 `--from mw --to mn`。

## 分段翻译（高优先级）

- **何时必须分段**：以 **整段待译正文**（一次准备送入 `content` 的字符串）在 **UTF-8 下的字节长度** 为准，**不是**主观感觉「比较长」就必须拆。若该长度 **≤ 1870 字节** → **只发一次** `POST /translation`；**> 1870 字节** → 必须先按下文规则切成多段，**逐段请求**后再按顺序拼接各段 `tgtText`。
- **单段上限**：每一段请求的 `content` 在 **UTF-8 编码下的字节长度不得超过 1870**（按字节计，不是 Unicode 码位数）。整体待译文本的 UTF-8 字节数 **不超过 1870** 时，**只发一次** `POST /translation`，不要强行拆段。
- **网页等长正文**：从网页摘录的大段文字若 **总 UTF-8 字节数超过 1870**，**须由调用方在发请求前按规则切分**，再对每一段分别调用 `/translation`；**接口不会**根据 URL 或正文自动替你分段，也不会单次请求内隐式拆分。
- 分段时优先在「句子/停顿」边界落刀，再保证每段 UTF-8 字节数 ≤ 1870。

分段边界（优先顺序）：

- 换行 `\n`、段落空行。
- 句末/大停顿：`。！？`、英文 `!.?`、分号 `；;`。
- 传统蒙古文标点：**᠃**（U+1803）、**᠂**（U+1802）等。
- 次级：`，、,:`；若单句在 UTF-8 下仍超过 1870 字节，再按次级分隔符切分；仍超长则按 **UTF-8 字节**硬切，保证每段不超过 1870 字节且不丢弃字符。

分段后保留原有语序与段落顺序，不得改写原文语义。

## 响应解析（必须）

毅金云成功响应体为 JSON，结构示例：

```json
{
  "success": true,
  "data": {
    "from": "mw",
    "to": "zh",
    "srcText": "<本段原文>",
    "tgtText": "<本段译文>"
  },
  "requestId": "..."
}
```

- **`data.tgtText`**：本段**译文**；分段时对每一段取 `tgtText`，再按段顺序拼接为最终结果。
- **`data.srcText`**：本段原文回显（应与该段请求的 `content` 一致），用于核对；不要把它当成译文输出。

返回 **译文即可**（最终输出为合并后的译文字符串，除非用户明确要求原始 JSON）。

说明：蒙古文 → 中文的译文为**中文**，不适用 [BEHAVIOR-RULES.md](./BEHAVIOR-RULES.md) 中「全程传统蒙古文 / 禁止汉字」类自检；中文 → 传统蒙古文或西里尔蒙古文时，每段 `tgtText` 须符合目标文字体系；`mn <-> mw` 互译时只输出最终目标文字。
