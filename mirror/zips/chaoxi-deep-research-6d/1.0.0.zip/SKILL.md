---
name: deepresearch-6d-prompt
description: "Generate ready-to-use Deep Research prompts using the 6D workflow: Define, Decompose, Design Fields, Discover, Digest, and Deliver. Use when the user wants to turn a research topic, business question, course exercise, consulting request, market scan, competitive analysis, user research brief, policy research question, or any vague research need into a structured Deep Research prompt containing all six 6D sections and clear deliverable requirements."
---

# DeepResearch 6D Prompt

## Overview

Use this skill to convert a research need into a complete Deep Research prompt. The output should be a prompt that another AI research agent can execute, not the research answer itself.

## Source Methodology

Extracted 6D Deep Research Workflow:

1. D1 Define - 定义目标
   - 研究什么？
   - 为什么研究？
   - 用于什么决策？
2. D2 Decompose - 拆解结构
   - 要拆成哪些维度、地区、对象或问题？
3. D3 Design Fields - 设计字段
   - 每一项要收集哪些字段？
   - 什么算完整？
4. D4 Discover - 有组织搜索
   - 去哪里搜？
   - 怎么多源检索？
5. D5 Digest - 消化汇总
   - 如何去重、清洗、归纳、求证？
6. D6 Deliver - 交付输出
   - 最终交付表格、报告还是建议方案？

Core principles:

- 流程设计优先于提示词编写
- 先有交付物，后有搜索
- 先有业务结构，后有 Skill 配置

## Workflow

When the user provides a topic or rough research request:

1. Identify the likely decision, audience, and expected deliverable.
2. If essential details are missing, make conservative assumptions and include them in the generated prompt under "Assumptions". Ask a clarifying question only when the missing detail changes the research scope materially.
3. Design the deliverable before designing the search plan.
4. Decompose the business or research structure before writing source queries.
5. Generate one complete prompt with exactly six major 6D sections.
6. Include concrete requirements for source quality, verification, output format, and citations.

## Output Requirements

Always output in Chinese unless the user requests another language.

Start with a short line: `以下是根据 6D Deep Research Workflow 生成的可执行提示词：`

Then provide a fenced prompt block. The prompt inside the block must be written as direct instructions to the future Deep Research agent.

Use this structure:

```text
你是一名 Deep Research 研究员。请围绕以下任务完成系统性研究，并严格按照 6D Deep Research Workflow 执行。

研究主题：
[Rewrite the user's task clearly]

Assumptions:
[List assumptions only if needed; otherwise write "无"]

D1 Define｜定义目标
- 研究对象：
- 研究背景：
- 核心问题：
- 使用场景/决策场景：
- 成功标准：
- 范围边界：

D2 Decompose｜拆解结构
- 研究维度：
- 地区/市场/人群/对象拆分：
- 关键子问题：
- 对比对象或基准：
- 优先级：

D3 Design Fields｜设计字段
请为每个研究对象或维度收集以下字段，并说明缺失字段如何处理：
| 字段 | 含义 | 必填/可选 | 完整性标准 | 推荐来源 |
|---|---|---|---|---|
| [field] | [meaning] | [required/optional] | [completion rule] | [source type] |

D4 Discover｜有组织搜索
- 优先来源：
- 检索渠道：
- 中英文/多语言关键词：
- 检索顺序：
- 交叉验证方式：
- 排除来源或低质量信号：

D5 Digest｜消化汇总
- 去重规则：
- 清洗规则：
- 可信度评估：
- 冲突信息处理：
- 归纳框架：
- 引用要求：

D6 Deliver｜交付输出
- 最终交付物类型：
- 输出结构：
- 表格字段：
- 结论与建议：
- 风险、不确定性与信息缺口：
- 可执行下一步：

质量要求：
- 优先使用一手来源、官方文件、权威数据库、行业报告、学术资料或可信媒体。
- 对关键事实进行多源交叉验证。
- 明确区分事实、推断和建议。
- 对时间敏感信息标注发布日期或数据时间。
- 在最终结果中列出来源链接。
```

## Adaptation Rules

Tailor each 6D section to the user's domain:

- For market or competitor research, emphasize market segmentation, players, pricing, channels, customer groups, and trend evidence.
- For product or user research, emphasize user segments, scenarios, pain points, jobs-to-be-done, feature comparisons, and evidence confidence.
- For policy or legal research, emphasize jurisdiction, effective dates, primary legal texts, enforcement bodies, and compliance implications.
- For academic or technical research, emphasize definitions, methods, benchmark papers, datasets, evaluation metrics, and reproducibility.
- For internal business research, emphasize stakeholder decision, available data, operating constraints, risks, and recommended action.

Do not add decorative commentary after the prompt. If useful, add a brief "可选补充问题" section before the fenced prompt with no more than three questions.
