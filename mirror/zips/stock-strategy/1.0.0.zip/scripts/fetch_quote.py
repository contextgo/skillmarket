#!/usr/bin/env python3
import sys, json, urllib.request
def _f(v):
try: return float(v)
except: return 0.0
def _i(v):
try: return int(float(v))
except: return 0
def _sina_req(url):
req = urllib.request.Request(url)
req.add_header("Referer", "https://finance.sina.com.cn")
req.add_header("User-Agent", "Mozilla/5.0")
with urllib.request.urlopen(req, timeout=10) as resp:
return resp.read().decode("gbk", errors="replace")
def _parse_line(text):
for line in text.strip().split("\n"):
if '="' not in line: continue
yield line.split('="')[1].rstrip('";')
def fetch_a(codes):
r = {}
try:
text = sina_req("https://hq.sinajs.cn/list=" + ",".join(codes))
for line in text.strip().split("\n"):
if '="' not in line: continue
code = line.split("=")[0].split("")[-1]
d = line.split('="')[1].rstrip('";')
if not d: continue
f = d.split(",")
if len(f) < 32: continue
r[code] = {"code":code,"name":f[0],"open":_f(f[1]),"prev_close":_f(f[2]),
"current":_f(f[3]),"high":_f(f[4]),"low":_f(f[5]),"volume":_i(f[8]),
"amount":_f(f[9]),"date":f[30] if len(f)>30 else "","time":f[31] if len(f)>31 else "",
"change_pct":round((_f(f[3])-_f(f[2]))/_f(f[2])*100,2) if _f(f[2])!=0 else 0}
except Exception as e: r["_a_error"] = str(e)
return r
def fetch_hk(code):
try:
text = _sina_req("https://hq.sinajs.cn/list=rt_hk" + code[2:])
for d in _parse_line(text):
if not d: continue
f = d.split(",")
if len(f) < 13: continue
cur, prev = _f(f[6]), _f(f[3])
return {"code":code,"name":f[1],"current":cur,"prev_close":prev,
"open":_f(f[2]),"high":_f(f[4]),"low":_f(f[5]),
"change_pct":round((cur-prev)/prev*100,2) if prev!=0 else 0}
except Exception as e: return {"code":code,"error":str(e)}
def fetch_us(code):
try:
text = sina_req("https://hq.sinajs.cn/list=gb" + code[2:].lower())
for d in _parse_line(text):
if not d: continue
f = d.split(",")
if len(f) < 8: continue
cur, prev = _f(f[1]), _f(f[3])
return {"code":code,"name":f[0],"current":cur,"prev_close":prev,
"open":_f(f[5]) if len(f)>5 else None,
"high":_f(f[6]) if len(f)>6 else None,
"low":_f(f[7]) if len(f)>7 else None,
"change_pct":round((cur-prev)/prev*100,2) if prev!=0 else 0}
except Exception as e: return {"code":code,"error":str(e)}
if name == "main":
if len(sys.argv) < 2:
print("用法: python3 fetch_quote.py sh600519 sz000858 hk00700 usAAPL")
sys.exit(1)
codes = sys.argv[1:]
r = {}
a = [c for c in codes if c.startswith("sh") or c.startswith("sz")]
if a: r.update(fetch_a(a))
for c in codes:
if c.startswith("hk"): r[c] = fetch_hk(c)
elif c.startswith("us"): r[c] = fetch_us(c)
print(json.dumps(r, ensure_ascii=False, indent=2))

---