#!/usr/bin/env python3
"""
邮箱订阅管理脚本

功能：
- add: 添加订阅（邮箱、股票代码列表、频率）
- remove: 取消订阅
- list: 查看所有订阅
- send: 发送策略邮件给指定订阅者

用法：
    python3 subscribe.py add user@example.com sh600519,sz000858 daily
    python3 subscribe.py remove user@example.com
    python3 subscribe.py list
    python3 subscribe.py send user@example.com --report /path/to/report.md

订阅数据存储在 subscribe_db.json
"""

import sys
import os
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "subscribe_db.json")


def load_db():
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"subscribers": []}


def save_db(db):
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)


def add_subscription(email, codes_str, frequency="daily"):
    db = load_db()
    codes = [c.strip() for c in codes_str.split(",")]

    for sub in db["subscribers"]:
        if sub["email"] == email:
            sub["codes"] = codes
            sub["frequency"] = frequency
            sub["updated_at"] = datetime.now().isoformat()
            save_db(db)
            print(f"已更新订阅: {email} | 股票: {codes} | 频率: {frequency}")
            return

    db["subscribers"].append({
        "email": email,
        "codes": codes,
        "frequency": frequency,
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
    })
    save_db(db)
    print(f"添加订阅成功: {email} | 股票: {codes} | 频率: {frequency}")


def remove_subscription(email):
    db = load_db()
    before = len(db["subscribers"])
    db["subscribers"] = [s for s in db["subscribers"] if s["email"] != email]
    save_db(db)
    after = len(db["subscribers"])
    if before > after:
        print(f"已取消订阅: {email}")
    else:
        print(f"未找到订阅: {email}")


def list_subscriptions():
    db = load_db()
    if not db["subscribers"]:
        print("暂无订阅")
        return
    print(f"共 {len(db['subscribers'])} 个订阅：\n")
    for i, sub in enumerate(db["subscribers"], 1):
        print(f"  {i}. {sub['email']}")
        print(f"     股票: {', '.join(sub['codes'])}")
        print(f"     频率: {sub['frequency']}")
        print(f"     创建: {sub['created_at']}")
        print()


def send_email(email, report_path, subject="投资策略日报"):
    if not os.path.exists(report_path):
        print(f"报告文件不存在: {report_path}")
        return False

    with open(report_path, "r", encoding="utf-8") as f:
        content = f.read()

    html_content = markdown_to_html(content)

    smtp_config = os.environ.get("SMTP_CONFIG", "")
    if not smtp_config:
        print("=" * 50)
        print("邮件发送需要配置SMTP，请设置环境变量：")
        print("  export SMTP_CONFIG='host|port|user|password|from_addr'")
        print()
        print("常见邮箱配置：")
        print("  QQ邮箱:   smtp.qq.com|465|QQ号|授权码|QQ号@qq.com")
        print("  163邮箱:  smtp.163.com|465|账号|授权码|账号@163.com")
        print("  Gmail:    smtp.gmail.com|587|账号|应用密码|账号@gmail.com")
        print()
        print("报告已生成但未发送，文件路径: " + report_path)
        print("=" * 50)
        return False

    try:
        parts = smtp_config.split("|")
        host, port, user, password, from_addr = parts
        port = int(port)

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = from_addr
        msg["To"] = email

        msg.attach(MIMEText(content, "plain", "utf-8"))
        msg.attach(MIMEText(html_content, "html", "utf-8"))

        if port == 465:
            server = smtplib.SMTP_SSL(host, port)
        else:
            server = smtplib.SMTP(host, port)
            server.starttls()

        server.login(user, password)
        server.sendmail(from_addr, email, msg.as_string())
        server.quit()
        print(f"邮件发送成功: {email}")
        return True
    except Exception as e:
        print(f"邮件发送失败: {e}")
        return False


def markdown_to_html(md_text):
    lines = md_text.split("\n")
    html_lines = []
    in_table = False

    for line in lines:
        stripped = line.strip()

        if stripped.startswith("### "):
            html_lines.append(f"<h3>{stripped[4:]}</h3>")
        elif stripped.startswith("## "):
            html_lines.append(f"<h2>{stripped[3:]}</h2>")
        elif stripped.startswith("# "):
            html_lines.append(f"<h1>{stripped[2:]}</h1>")
        elif stripped == "---":
            html_lines.append("<hr>")
        elif "|" in stripped and stripped.startswith("|"):
            if not in_table:
                html_lines.append("<table border='1' cellpadding='8' cellspacing='0' style='border-collapse:collapse;'>")
                in_table = True
            cells = [c.strip() for c in stripped.split("|") if c.strip()]
            if all(set(c) <= set("-: ") for c in cells):
                continue
            tag = "th" if len([l for l in html_lines if "<tr>" in l]) == 0 else "td"
            row = "<tr>" + "".join(f"<{tag}>{c}</{tag}>" for c in cells) + "</tr>"
            html_lines.append(row)
        else:
            if in_table:
                html_lines.append("</table>")
                in_table = False
            import re
            line = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', line)
            if stripped.startswith("- ") or stripped.startswith("* "):
                html_lines.append(f"<li>{stripped[2:]}</li>")
            else:
                html_lines.append(f"<p>{line}</p>")

    if in_table:
        html_lines.append("</table>")

    return f"""
<html>
<head>
<style>
body {{ font-family: -apple-system, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; color: #333; }}
h1 {{ color: #1a1a1a; border-bottom: 2px solid #e74c3c; padding-bottom: 10px; }}
h2 {{ color: #2c3e50; border-bottom: 1px solid #bdc3c7; padding-bottom: 8px; margin-top: 30px; }}
h3 {{ color: #34495e; }}
table {{ width: 100%; margin: 15px 0; }}
th {{ background: #2c3e50; color: white; padding: 10px; text-align: left; }}
td {{ padding: 8px 10px; border-bottom: 1px solid #ecf0f1; }}
tr:hover {{ background: #f8f9fa; }}
strong {{ color: #e74c3c; }}
hr {{ border: none; border-top: 1px solid #bdc3c7; margin: 20px 0; }}
li {{ margin: 5px 0; }}
</style>
</head>
<body>
{"".join(html_lines)}
</body>
</html>
"""


def main():
    if len(sys.argv) < 2:
        print("用法:")
        print("  python3 subscribe.py add 邮箱 股票代码,逗号分隔 [daily|weekly]")
        print("  python3 subscribe.py remove 邮箱")
        print("  python3 subscribe.py list")
        print("  python3 subscribe.py send 邮箱 --report 报告文件路径")
        sys.exit(1)

    command = sys.argv[1]

    if command == "add":
        if len(sys.argv) < 4:
            print("用法: python3 subscribe.py add 邮箱 股票代码 [daily|weekly]")
            sys.exit(1)
        email = sys.argv[2]
        codes = sys.argv[3]
        freq = sys.argv[4] if len(sys.argv) > 4 else "daily"
        add_subscription(email, codes, freq)

    elif command == "remove":
        if len(sys.argv) < 3:
            print("用法: python3 subscribe.py remove 邮箱")
            sys.exit(1)
        remove_subscription(sys.argv[2])

    elif command == "list":
        list_subscriptions()

    elif command == "send":
        if len(sys.argv) < 3:
            print("用法: python3 subscribe.py send 邮箱 --report 报告文件")
            sys.exit(1)
        email = sys.argv[2]
        report_path = None
        if "--report" in sys.argv:
            idx = sys.argv.index("--report")
            if idx + 1 < len(sys.argv):
                report_path = sys.argv[idx + 1]
        if not report_path:
            print("请指定报告文件: --report 路径")
            sys.exit(1)
        send_email(email, report_path)

    else:
        print(f"未知命令: {command}")
        print("支持: add, remove, list, send")


if __name__ == "__main__":
    main()