---
name: apple-notes
category: 通用
platform: macOS
description: 通过 osascript 管理 Apple 备忘录（创建、查看、编辑、删除、搜索、移动）。当用户提及"备忘录"、"笔记"、"notes"、或需要与 Apple Notes 应用交互时使用此技能。数据通过 iCloud 同步到所有 Apple 设备。仅限 macOS。
humanDescription: "通过命令行管理 Apple 备忘录。"
---

# Apple Notes (osascript)

通过 `osascript` 直接操作 Apple 备忘录，无需安装额外工具。数据通过 iCloud 同步到 iPhone/iPad/Mac。

## 适用场景

- 用户提到"备忘录"、"笔记"或 Apple Notes
- 记录想法、会议纪要、技术笔记
- 创建富文本内容（标题、列表、表格、链接、代码块）
- 管理备忘录文件夹

## 不适用场景

- 待办事项/提醒 → 使用 Apple Reminders skill
- Markdown 文件编辑 → 直接操作文件系统
- 第三方笔记应用（Notion、Obsidian）→ 使用对应工具

## 授权

首次使用需要 macOS 备忘录权限。在 IDE 嵌入式终端中运行：

```bash
osascript -e 'tell application "Notes" to get name of every folder'
```

系统会弹出授权对话框，用户点击"允许"后即可正常使用。

## 常用操作

### 查看备忘录

```bash
# 列出所有备忘录（标题）
osascript -e 'tell application "Notes" to get name of every note'

# 列出指定文件夹中的备忘录
osascript -e 'tell application "Notes" to get name of every note of folder "工作"'

# 查看备忘录内容（返回 HTML）
osascript -e 'tell application "Notes" to get body of note "标题"'

# 查看纯文本内容
osascript -e 'tell application "Notes" to get plaintext of note "标题"'

# 列出所有文件夹
osascript -e 'tell application "Notes" to get name of every folder'
```

### 创建备忘录

备忘录内容使用 HTML 格式，支持丰富的排版。

```bash
# 简单备忘录
osascript -e 'tell application "Notes" to make new note at folder "Notes" with properties {name:"标题", body:"<p>内容</p>"}'

# 指定文件夹（文件夹不存在会报错，需先创建）
osascript -e 'tell application "Notes" to make new note at folder "工作" with properties {name:"会议纪要", body:"<p>讨论内容...</p>"}'
```

对于较长的内容，使用 heredoc 传入：

```bash
osascript << 'EOF'
tell application "Notes"
    make new note at folder "Notes" with properties {name:"周报", body:"
<h1>本周工作</h1>
<ul>
<li>完成功能 A</li>
<li>修复 Bug B</li>
</ul>
<h2>下周计划</h2>
<ol>
<li>开始功能 C</li>
<li>代码审查</li>
</ol>
"}
end tell
EOF
```

### 编辑备忘录

```bash
# 替换整个内容
osascript -e 'tell application "Notes" to set body of note "标题" to "<p>新内容</p>"'

# 追加内容（先读后拼接）
osascript << 'EOF'
tell application "Notes"
    set oldBody to body of note "标题"
    set body of note "标题" to oldBody & "<p>追加的内容</p>"
end tell
EOF
```

### 删除备忘录

```bash
osascript -e 'tell application "Notes" to delete note "标题"'
```

### 搜索备忘录

```bash
# 按标题搜索（模糊匹配）
osascript -e 'tell application "Notes" to get name of every note whose name contains "关键词"'

# 搜索并返回匹配数量
osascript -e 'tell application "Notes" to count (every note whose name contains "关键词")'
```

### 管理文件夹

```bash
# 创建文件夹
osascript -e 'tell application "Notes" to make new folder with properties {name:"新文件夹"}'

# 移动备忘录到另一个文件夹
osascript -e 'tell application "Notes" to move note "标题" to folder "目标文件夹"'
```

## HTML 格式参考

Apple Notes 的 body 使用 HTML，以下是常用标签：

| 元素 | HTML | 效果 |
|------|------|------|
| 一级标题 | `<h1>标题</h1>` | 大号粗体 |
| 二级标题 | `<h2>标题</h2>` | 中号粗体 |
| 三级标题 | `<h3>标题</h3>` | 小号粗体 |
| 段落 | `<p>文本</p>` | 普通段落 |
| 粗体 | `<b>文本</b>` | **粗体** |
| 斜体 | `<i>文本</i>` | *斜体* |
| 无序列表 | `<ul><li>项目</li></ul>` | 圆点列表 |
| 有序列表 | `<ol><li>项目</li></ol>` | 编号列表 |
| 代码块 | `<pre>code</pre>` | 等宽字体 |
| 链接 | `<a href="url">文本</a>` | 可点击链接 |
| 表格 | `<table><tr><td>...</td></tr></table>` | 表格 |
| 换行 | `<br>` | 换行 |

### 特殊字符转义

在 osascript 中传递 HTML 时，注意转义：
- `<` → `&lt;`（在 HTML 内容中如需显示尖括号）
- `>` → `&gt;`
- `"` → `&quot;` 或 `\"`（取决于上下文）
- `&` → `&amp;`

## 操作验证与重试

每次写操作（创建、编辑、删除、移动）完成后，**必须**验证结果。不要仅凭命令未报错就认为成功。

### 验证流程

1. **创建后**：用 `get name of every note` 确认新备忘录出现在列表中
2. **编辑后**：用 `get plaintext of note "标题"` 读取内容，确认关键文本已更新。注意 Notes 会重新格式化 HTML，不要用 `get body` 做精确匹配，用 `plaintext` 检查文本内容是否正确
3. **删除后**：用 `get name of every note` 确认目标备忘录已不在列表中
4. **移动后**：用 `get name of every note of folder "目标文件夹"` 确认备忘录已出现在目标文件夹

### 编辑失败的常见原因

- **部分替换失效**：Notes 内部 HTML 与原始输入差异很大（Notes 会自动添加 `<div>`、`<font>`、`<span>` 等标签），AppleScript 字符串匹配很容易失败。解决方案：编辑时优先使用**整体替换** `set body` 而非局部查找替换
- **特殊字符问题**：单引号 `'` 在 AppleScript 字符串中需要特殊处理，建议使用 heredoc（`osascript << 'EOF'`）传入包含引号的内容
- **权限被拒**：如果命令返回权限错误，重新运行授权命令

### 重试策略

如果验证发现操作未生效：
1. 先检查错误原因（权限、标题不匹配、HTML 格式问题）
2. 针对原因调整命令后重试
3. 编辑操作建议直接用 `set body` 整体重写，这是最可靠的方式

## 注意事项

- 所有操作通过 `osascript` 调用 Apple Events，完全非交互
- 备忘录内容通过 iCloud 自动同步到用户的所有 Apple 设备
- `get body` 返回 Notes 内部的 HTML（可能与原始输入不同，Notes 会重新格式化）
- `get plaintext` 返回纯文本版本，适合内容提取和验证
- 默认文件夹名为 `"Notes"`（英文系统）或 `"备忘录"`（中文系统），建议先用 `get name of every folder` 确认
