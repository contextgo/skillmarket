---
name:tencent-internal-mcp
description:让任意智能体接入 TAPD、iWiki、工蜂三大内部服务的配置指南。
---



# 腾讯内部服务 MCP 接入指南

让任意智能体接入 TAPD、iWiki、工蜂三大内部服务的配置指南。

---

## 前置准备：获取太湖令牌

1. 访问 https://tai.it.woa.com/user/pat
2. 点击「创建个人令牌」
3. 复制生成的令牌（格式：`tai_pat_xxxxx`）

⚠️ **注意**：令牌只显示一次，请妥善保存。

---

## 方式一：官方远程 MCP（推荐）

无需安装任何包，直接配置 URL + Bearer Token 即可使用。

### MCP 配置

在 `~/.workbuddy/mcp.json` 中添加以下配置：

```json
{
  "mcpServers": {
    "iwiki": {
      "url": "https://prod.mcp.it.woa.com/app_iwiki_mcp/mcp3",
      "headers": {
        "Authorization": "Bearer <你的太湖令牌>"
      }
    },
    "gongfeng": {
      "url": "https://prod.mcp.it.woa.com/gongfeng/api/mcp/mcp",
      "headers": {
        "Authorization": "Bearer <你的太湖令牌>"
      }
    },
    "tapd": {
      "url": "https://prod.mcp.it.woa.com/tapdwoa/tapdmcp",
      "headers": {
        "Authorization": "Bearer <你的太湖令牌>"
      }
    }
  }
}
```

将 `<你的太湖令牌>` 替换为实际令牌值（例如 `tai_pat_xxxxx`）。

---

## 方式二：本地 MCP Server（备选）

如果远程 MCP 不可用，可以使用本地安装方式。

### 环境准备

```bash
# 1. 确认 Node.js >= 18
node -v

# 2. 切换 npm 到腾讯内网源（必须）
npm config set registry https://mirrors.tencent.com/npm/

# 3. 确认 uv 已安装（TAPD 需要）
which uv || curl -LsSf https://astral.sh/uv/install.sh | sh
```

### 安装 MCP Server 包

```bash
npm install -g @tencent/iwiki-mcp@latest
npm install -g @tencent/tgit-mcp-server@latest
# TAPD 通过 uvx 按需拉取，无需提前安装
```

### MCP 配置

```json
{
  "mcpServers": {
    "iwiki": {
      "command": "npx",
      "args": ["-y", "@tencent/iwiki-mcp@latest"],
      "env": { "IWIKI_TOKEN": "<你的太湖令牌>" }
    },
    "gongfeng": {
      "command": "npx",
      "args": ["-y", "@tencent/tgit-mcp-server@latest"],
      "env": { "TGIT_TOKEN": "<你的太湖令牌>" }
    },
    "tapd": {
      "command": "uvx",
      "args": ["mcp-server-tapd"],
      "env": { "TAPD_TOKEN": "<你的太湖令牌>" }
    }
  }
}
```

---

## 服务说明

| 服务 | 远程 URL | 功能 |
|------|----------|------|
| **iWiki** | `https://prod.mcp.it.woa.com/app_iwiki_mcp/mcp3` | 读取/搜索/创建 iWiki 文档 |
| **工蜂** | `https://prod.mcp.it.woa.com/gongfeng/api/mcp/mcp` | 代码仓库管理、MR、Issue、KM 搜索 |
| **TAPD** | `https://prod.mcp.it.woa.com/tapdwoa/tapdmcp` | 需求/任务/缺陷管理 |

---

## 使用示例

### iWiki - 读取文档
```
用户：读取这个文档 https://iwiki.woa.com/p/4016401215
助手：调用 getDocument 工具，返回文档内容
```

### TAPD - 查询需求
```
用户：查看这个需求 https://tapd.woa.com/tapd_fe/70135431/story/detail/1070135431133122643
助手：调用 stories_get 工具，返回需求详情
```

### 工蜂 - 查看 MR
```
用户：帮我看看工蜂项目 xxx 的 MR 列表
助手：调用 search_merge_request 工具
```

---

## 常见问题

| 问题 | 解决 |
|------|------|
| npm install 超时 | 确认已切换到 `mirrors.tencent.com/npm/` 内网源 |
| MCP 调用报 401 | 太湖 PAT 令牌过期，去 https://tai.it.woa.com/user/pat 续期 |
| 远程 MCP 连接失败 | 尝试本地 MCP Server 方式 |
| uvx 命令找不到 | 运行 `curl -LsSf https://astral.sh/uv/install.sh \| sh` 安装 uv |

---

## 参考资料

- 太湖 MCP 统一认证介绍：https://iwiki.woa.com/p/4016401215
- 太湖个人令牌管理：https://tai.it.woa.com/user/pat
- WorkBuddy MCP 配置文档：https://www.codebuddy.cn/docs/workbuddy/Overview

---

更新时间：2026-03-31
