---
name: pass-credential-manager
description: 安全存储 API Key、数据库密码、授权码等敏感信息。使用 GPG 加密，本地存储，Git 备份加密后文件。替代硬编码密码，防止密钥泄露。触发词：密码管理、API Key 存储、密钥管理、凭据加密、password manager、secret management、pass、password-store。
---

# Pass 凭据管理器

> 🔐 把你的密码和密钥安全地存在本地，再也不用担心泄露

## 这是什么？

**pass** 是一个命令行密码管理器，用 GPG 加密你的敏感信息：
- API Key（OpenAI、Claude 等）
- 数据库密码
- 邮箱授权码
- SSH 密钥
- 任何不想写在代码里的秘密

**核心特点**：
- ✅ 本地存储 - 数据在你自己机器上
- ✅ 加密保护 - 没有密钥谁都看不了
- ✅ 免费开源 - 无订阅费用
- ✅ Git 备份 - 可同步加密后文件到私有仓库

## 5 分钟上手

### 安装
```bash
# Ubuntu/Debian
sudo apt install pass

# macOS
brew install pass
```

### 存一个密码
```bash
pass insert openai/api-key
# 输入密码，回车确认
```

### 读取密码
```bash
pass show openai/api-key
# 输出：sk-xxxxxxxxxxxx
```

### 在脚本里用
```bash
# 不再写死密码
API_KEY=$(pass show openai/api-key)
```

## 常用场景

### 场景 1：管理 LLM API Key
```bash
# 存储
pass insert openai/api-key
pass insert anthropic/api-key

# 使用
export OPENAI_API_KEY=$(pass show openai/api-key)
```

### 场景 2：数据库密码
```bash
# 存储
pass insert postgres/mydb-password

# Python 使用
import subprocess
import psycopg2

password = subprocess.check_output(
    ["pass", "show", "postgres/mydb-password"]
).decode().strip()

conn = psycopg2.connect(
    host="localhost",
    database="mydb",
    password=password
)
```

### 场景 3：邮箱授权码
```bash
pass insert qq-mail/auth-code
```

## 所有命令

| 命令 | 作用 |
|------|------|
| `pass ls` | 列出所有密码 |
| `pass show <名称>` | 显示密码 |
| `pass show -c <名称>` | 复制到剪贴板（45秒后清除） |
| `pass insert <名称>` | 新增密码 |
| `pass edit <名称>` | 编辑密码 |
| `pass rm <名称>` | 删除密码 |
| `pass find <关键词>` | 搜索密码 |

## 推荐的命名规范

```
~/.password-store/
├── llm/
│   ├── openai-api-key
│   ├── anthropic-api-key
│   └── deepseek-api-key
├── database/
│   ├── postgres-password
│   └── mysql-password
├── mail/
│   ├── qq-auth-code
│   └── gmail-app-password
└── cloud/
    ├── aws-access-key
    └── aliyun-access-key
```

## 备份到 Git（安全吗？）

### 为什么安全？

```
你输入的密码: "my-secret-password"
        ↓
    GPG 加密
        ↓
存储到文件: "password.gpg" (乱码，无法读取)
        ↓
    Git push
        ↓
GitHub 上的内容: 仍然是乱码
```

**关键点**：
1. **GPG 加密在 Git 之前** - 推送到 GitHub 的已经是加密内容
2. **即使仓库泄露** - 没有 GPG 密钥，看到的是乱码
3. **GPG 密钥不在仓库里** - 只有你本机有解密密钥

### 类比说明

| 情况 | 相当于 |
|------|--------|
| Git 仓库泄露 | 小偷拿到了保险箱，但没钥匙 |
| 有 GPG 密钥 | 有钥匙能开保险箱 |
| 没有 GPG 密钥 | 保险箱打不开，内容安全 |

### 操作步骤

```bash
# 初始化（第一次）
cd ~/.password-store
git init
git remote add origin git@github.com:YOUR_NAME/secrets.git
git push -u origin main

# 日常同步
git pull && git add -A && git commit -m "update" && git push
```

### 安全清单

| 检查项 | 状态 |
|--------|------|
| ✅ 使用私有仓库 | 必须 |
| ✅ GPG 密钥已备份 | 建议 |
| ✅ GPG 密钥密码够复杂 | 建议 |
| ❌ GPG 密钥放仓库 | 禁止 |

**GPG 密钥备份**：
```bash
# 导出私钥（离线保存）
gpg --export-secret-keys YOUR_EMAIL > ~/backup/private.key

# 导出公钥（可分享）
gpg --export YOUR_EMAIL > ~/backup/public.key
```

## 安全说明

| 问题 | 答案 |
|------|------|
| 密码存在哪？ | 本地 `~/.password-store/`，GPG 加密 |
| 会同步到云端吗？ | 只有你自己配置 Git 才会 |
| 忘了 GPG 密码怎么办？ | 密码库无法恢复，请妥善保管 |
| 多台电脑怎么同步？ | Git push/pull 同步密码库 |

## 为什么不用其他工具？

| 工具 | 优点 | 缺点 |
|------|------|------|
| **pass** | 免费、本地、CLI 友好 | 需要学命令行 |
| 1Password | 界面友好 | 订阅费、云存储 |
| Bitwarden | 免费 | 云存储 |
| 环境变量 | 简单 | 明文、易泄露 |
| 写在代码里 | 最简单 | ❌ 绝对禁止 |

## 许可证

MIT License
