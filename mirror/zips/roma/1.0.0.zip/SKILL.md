---
name: decline-fall-rome
version: 1.0.0
description: 罗马帝国衰亡史每日学习
license: PROPRIETARY

slash_commands:
  /rome-today: 今日学习内容
  /rome-day: 指定某天学习
  /rome-search: 搜索历史事件
  /rome-progress: 学习进度

capabilities:
  - daily_lesson
  - search_events
  - track_progress

dependencies: []

---

# 罗马帝国衰亡史每日学习

按照吉本《罗马帝国衰亡史》原书顺序，每天推送一篇学习内容，包含英文原文、中文翻译、历史解读。

## 功能
1. **每日学习**：按顺序推送原文 + 翻译 + 解读 + 故事
2. **跳转学习**：指定章节学习
3. **搜索查询**：搜索历史事件、人物
4. **学习进度**：跟踪学习记录

## 使用
```
/rome-today          # 今日学习
/rome-day 1          # 学习第 1 章
/rome-search Caesar  # 搜索相关事件
/rome-progress       # 查看学习进度
```

## 内容结构
每篇文档包含：
- **原文**：英文原文（吉本原著）
- **翻译**：中文翻译
- **解读**：历史背景、事件分析
- **故事**：相关历史故事

## 学习周期
- 精选 365 篇核心内容，一年学完
- 每天一篇，循序渐进
