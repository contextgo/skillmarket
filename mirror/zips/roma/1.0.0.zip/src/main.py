#!/usr/bin/env python3
"""
罗马帝国衰亡史每日学习 - 每天一篇西方历史经典
基于爱德华·吉本《The History of the Decline and Fall of the Roman Empire》
"""

import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any, List


# 罗马帝国衰亡史部分数据（示例）
DECLINE_FALL_ROME_DATA = [
    {
        "day": 1,
        "chapter": "Chapter 1",
        "title": "The Extent of the Roman Empire",
        "section": "Introduction",
        "original": """In the second century of the Christian Era, the Empire of Rome comprehended the fairest part of the earth, and the most civilized portion of mankind. The frontiers of that extensive monarchy were guarded by ancient renown and disciplined valor. The gentle but powerful influence of laws and manners had gradually cemented the union of the provinces. Their peaceful inhabitants enjoyed and abused the advantages of wealth and luxury. The image of a free constitution was preserved with decent reverence: the Roman senate appeared to possess the sovereign authority, and devolved on the emperors all the executive powers of government.

During a happy period of more than fourscore years, the public administration was conducted by the virtue and abilities of Nerva, Trajan, Hadrian, and the two Antonines. It is the design of this, and of the two succeeding chapters, to describe the prosperous condition of their empire; and afterwards, from the death of Marcus Antoninus, to deduce the most important circumstances of its decline and fall; a revolution which will ever be remembered, and is still felt by the nations of the earth.""",
        "translation": """在基督纪元的第二个世纪，罗马帝国涵盖了地球上最美好的土地和人类最文明的部分。这个广阔帝国的边境由古老的声望和训练有素的勇气守护着。法律和风俗习惯温和而强大的影响力逐渐巩固了各行省的联盟。它们的和平居民享受并滥用着财富和奢侈的优势。自由宪政的形象被体面地保留着：罗马元老院似乎拥有最高权威，并将政府的所有行政权力移交给皇帝。

在八十多年的幸福时期里，公共行政由涅尔瓦、图拉真、哈德良和两位安东尼努斯的美德和能力来管理。本章及接下来两章的目的，是描述他们帝国的繁荣状况；然后，从马可·安东尼努斯之死开始，推导出帝国衰落和灭亡的最重要情况；这场革命将永远被铭记，并且至今仍被世界各国的人民所感受。""",
        "interpretation": """### 历史背景

这是吉本《罗马帝国衰亡史》的开篇段落，描绘了罗马帝国在公元 2 世纪的鼎盛时期。

### 核心内容

1. **帝国疆域**：罗马帝国在 2 世纪达到了最大版图，涵盖了欧洲、北非和中东的大部分地区。

2. **五贤帝时代**：涅尔瓦（96-98 年）、图拉真（98-117 年）、哈德良（117-138 年）、安东尼·庇护（138-161 年）、马可·奥勒留（161-180 年），这五位皇帝被称为"五贤帝"，他们的统治时期被认为是罗马帝国的黄金时代。

3. **政治制度**：表面上保留了共和制的外衣，元老院拥有名义上的最高权威，但实际权力掌握在皇帝手中。

### 核心启示

1. **盛极而衰**：吉本在此描绘了帝国的鼎盛时期，为后续的衰落埋下伏笔。即使是最强大的帝国，也难逃衰亡的命运。

2. **法治与文明**：吉本强调"法律和风俗习惯"的力量，这是维系帝国统一的重要因素。

3. **明君治国**：五贤帝的统治证明，领导者的品德和能力对国家兴衰至关重要。

### 关键人物

- **涅尔瓦**：开创养子继承制度
- **图拉真**：帝国疆域达到最大
- **哈德良**：修建哈德良长城
- **马可·奥勒留**：哲学家皇帝，《沉思录》作者

### 现代启示

1. 任何强大的组织都可能衰落，需要持续警惕
2. 法治和文明是维系社会的关键
3. 领导者的选拔机制至关重要""",
        "story": """### 图拉真纪功柱的故事

图拉真柱是罗马最著名的纪念碑之一，高 38 米，用大理石建成，柱身环绕着 200 多米长的浮雕带，描绘了图拉真征服达西亚（今罗马尼亚）的战争场景。

这根柱子不仅是一件艺术品，更是罗马帝国鼎盛的象征。图拉真在位期间（98-117 年），罗马帝国的疆域达到了最大范围。他征服了达西亚，获得了大量的黄金和财富，用于建设罗马城。

有趣的是，图拉真柱的内部是中空的，有螺旋楼梯通向顶端。 originally, the column was topped with a statue of Trajan himself. 后来在中世纪，雕像被换成了圣彼得的雕像，一直保留至今。

图拉真的骨灰被安放在柱子底部的金色骨灰盒中，这是罗马城内唯一允许埋葬皇帝遗体的地方。""",
    },
    {
        "day": 2,
        "chapter": "Chapter 1",
        "title": "The Integration of the Provinces",
        "section": "Unity and Diversity",
        "original": """The principal conquests of the Romans were achieved under the republic; and the emperors, for the most part, were satisfied with preserving those dominions which had been acquired by the policy of the senate, the active emulations of the consuls, and the martial enthusiasm of the people. The seven first centuries were filled with a rapid succession of triumphs; but it was reserved for Augustus to relinquish the ambitious design of subduing the whole earth, and to introduce a spirit of moderation into the public councils. Inclined to peace by his temper and situation, it was easy for him to discover that Rome, in her present exalted situation, had much less to hope than to fear from the chance of arms; and that, in the prosecution of remote wars, the undertaking became every day more difficult, the event more doubtful, and the possession more precarious, and less beneficial. The experience of Augustus added weight to these salutary reflections, and effectually convinced him that, by the prudent vigor of his counsels, all the violent and ambitious projects of Antony and Caesar would be easily parried.""",
        "translation": """罗马人的主要征服成就都是在共和国时期取得的；而皇帝们大多满足于保守由元老院的政策、执政官的积极竞争和人民的军事热情所获得的领土。最初的七个世纪充满了接连不断的凯旋；但留给奥古斯都的是放弃征服整个地球的雄心勃勃的计划，并在公共议事中引入一种节制的精神。由于他的天性和处境都倾向于和平，他很容易发现，处于当时崇高地位的罗马，从战争机遇中得到的希望远少于恐惧；而且，在进行遥远地区的战争时，事业每天都变得更加困难，结果更加可疑，占有更加不稳定，益处也更少。奥古斯都的经验增加了这些有益思考的分量，并有效地使他相信，凭借他明智而有力的谋划，安东尼和凯撒的所有暴力和野心勃勃的计划都可以轻易挫败。""",
        "interpretation": """### 历史背景

这段讲述了罗马从共和国扩张到帝国守成的转变，特别是奥古斯都确立的"节制"政策。

### 核心内容

1. **共和国扩张**：罗马的主要征服都是在共和国时期完成的，包括高卢、希腊、小亚细亚等地。

2. **奥古斯都的转变**：奥古斯都（公元前 27 年 - 公元 14 年在位）放弃了继续扩张的政策，转而采取守势。

3. **战略收缩**：奥古斯都认识到，过度扩张会使帝国陷入困境，因此确立了以防御为主的战略。

### 核心启示

1. **知止而后有定**：奥古斯都的伟大之处在于他知道何时停止扩张，这是大智慧。

2. **守成比创业更难**：打天下难，守天下更难。维持庞大帝国需要的是智慧而非武力。

3. **战略耐心**：有时候，不行动比行动更需要勇气和智慧。

### 关键人物

- **奥古斯都**：罗马帝国第一位皇帝，开创了"罗马和平"（Pax Romana）
- **凯撒**：被刺杀后，其养子奥古斯都继承其事业
- **安东尼**：与奥古斯都争夺权力，最终失败

### 现代启示

1. 企业扩张也需要节制，盲目扩张可能导致失败
2. 懂得适时止损是重要的战略智慧
3. 守成需要与创业不同的能力""",
        "story": """### 奥古斯都的遗嘱

奥古斯都在临终前留下了一份政治遗嘱《Res Gestae Divi Augusti》（奥古斯都功绩录），其中记录了他的治国理念。

他写道："我发现罗马是一座砖城，我离开时它是一座大理石城。"这句话不仅指物质建设，也指制度和文明的建设。

奥古斯都在位 41 年，他做了一件前无古人的事：在扩张达到极限时主动停止。他在日耳曼尼亚战役失败后（公元 9 年，条顿堡森林战役），永久放弃了征服日耳曼的计划，将帝国边境定在莱茵河。

据说他在临终时对朋友说："我接手的是陶土做的罗马，留下的是大理石做的罗马。"他去世时，罗马境内和平繁荣，贸易发达，这就是著名的"罗马和平"（Pax Romana）的开端。""",
    },
    {
        "day": 3,
        "chapter": "Chapter 1",
        "title": "The System of Despotism",
        "section": "Power and Liberty",
        "original": """But the sovereignty of the people was gradually lost in the concentration of power, and the shadow of the constitution survived the substance. The arts of policy and war had been perfected under the republic; but the virtues which had adorned those times were no more. The spirit of liberty was extinguished with the death of Brutus and Cassius; and the Romans, who had been the tyrants of the world, became the slaves of a single master. The name of liberty was still pronounced with reverence, but the thing itself was forgotten. The senate, which had once been the council of the nation, was now reduced to a servile obedience; and the emperor, who was once the first citizen of the republic, became the absolute master of the world.""",
        "translation": """但人民的主权逐渐在权力集中中丧失，宪政的影子在实质消失后仍然存在。政治和战争的艺术在共和国时期已经完善；但装饰那些时代的美德已不复存在。自由精神随着布鲁图斯和卡西乌斯之死而熄灭；曾经是世界暴君的罗马人，成为了单一主人的奴隶。自由的名字仍然被恭敬地念出，但自由本身已被遗忘。曾经是国民议会的元老院，如今沦为奴性的服从；曾经是共和国第一公民的皇帝，成为了世界的绝对主宰。""",
        "interpretation": """### 历史背景

这段描述了罗马从共和制向帝制转变过程中，自由精神的丧失和专制制度的建立。

### 核心内容

1. **共和制的消亡**：罗马共和国时期的权力制衡制度逐渐被皇帝的绝对权力所取代。

2. **自由的丧失**：布鲁图斯和卡西乌斯刺杀凯撒后自杀，标志着共和派最后的反抗失败。

3. **元老院的衰落**：从最高权力机构沦为皇帝的橡皮图章。

### 核心启示

1. **制度的脆弱性**：再好的制度，如果没有人捍卫，也会逐渐消亡。

2. **自由需要守护**：自由不是天生的，需要每一代人去争取和捍卫。

3. **权力的腐蚀**：绝对的权力导致绝对的腐败，这是罗马共和国灭亡的教训。

### 关键人物

- **布鲁图斯**：刺杀凯撒的主谋之一，共和派的最后代表
- **卡西乌斯**：与布鲁图斯一起刺杀凯撒
- **凯撒**：独裁官，被刺杀后罗马进入帝国时代

### 现代启示

1. 民主制度需要公民的积极参与来维护
2. 权力制衡是防止专制的关键
3. 自由一旦失去，很难再夺回""",
        "story": """### 布鲁图斯的最后时刻

公元前 42 年，腓立比战役，布鲁图斯和卡西乌斯的共和派军队被安东尼和屋大维（后来的奥古斯都）的联军击败。

据普鲁塔克记载，布鲁图斯在战败后，对他的朋友说：" virtue, thou art but a name."（美德，你不过是个空名。）然后他请求他的仆人斯特拉托用剑刺入他的胸膛。

凯撒在被刺杀时，看到布鲁图斯也参与了阴谋，说出了那句名言："Et tu, Brute?"（还有你吗，布鲁图斯？）

布鲁图斯是凯撒最信任的人之一，凯撒甚至有人说布鲁图斯可能是他的私生子。但布鲁图斯选择了共和国，选择了刺杀他的恩人。这是一个关于理想主义与现实政治的悲剧故事。

后来，但丁在《神曲》中将布鲁图斯和卡西乌斯放在地狱的最底层，与出卖耶稣的犹大在一起，永远被撒旦咀嚼。""",
    },
]


class DeclineFallRomeSkill:
    """罗马帝国衰亡史学习助手"""

    def __init__(self, data_dir: str = None):
        self.data_dir = data_dir or os.path.join(os.path.dirname(__file__), 'data')
        self.progress_file = os.path.join(self.data_dir, 'progress.json')
        self._load_progress()

    def _load_progress(self):
        """加载学习进度"""
        if os.path.exists(self.progress_file):
            with open(self.progress_file, 'r', encoding='utf-8') as f:
                self.progress = json.load(f)
        else:
            self.progress = {
                'current_day': 1,
                'completed_days': [],
                'start_date': datetime.now().strftime('%Y-%m-%d'),
                'last_study_date': None,
            }

    def _save_progress(self):
        """保存学习进度"""
        os.makedirs(self.data_dir, exist_ok=True)
        with open(self.progress_file, 'w', encoding='utf-8') as f:
            json.dump(self.progress, f, ensure_ascii=False, indent=2)

    def get_today_lesson(self) -> Optional[Dict]:
        """获取今日学习内容"""
        day = self.progress['current_day']
        return self.get_lesson_by_day(day)

    def get_lesson_by_day(self, day: int) -> Optional[Dict]:
        """获取指定天的学习内容"""
        for lesson in DECLINE_FALL_ROME_DATA:
            if lesson['day'] == day:
                return lesson
        return None

    def get_random_lesson(self) -> Dict:
        """获取随机一篇学习内容"""
        import random
        return random.choice(DECLINE_FALL_ROME_DATA)

    def search_lessons(self, keyword: str) -> List[Dict]:
        """搜索相关学习内容"""
        results = []
        for lesson in DECLINE_FALL_ROME_DATA:
            keyword_lower = keyword.lower()
            if (keyword_lower in lesson.get('title', '').lower() or
                keyword_lower in lesson.get('chapter', '').lower() or
                keyword_lower in lesson.get('original', '').lower() or
                keyword_lower in lesson.get('translation', '').lower() or
                keyword_lower in lesson.get('interpretation', '').lower() or
                keyword_lower in lesson.get('story', '').lower()):
                results.append(lesson)
        return results

    def mark_completed(self, day: int):
        """标记某天学习完成"""
        if day not in self.progress['completed_days']:
            self.progress['completed_days'].append(day)
        self.progress['current_day'] = day + 1
        self.progress['last_study_date'] = datetime.now().strftime('%Y-%m-%d')
        self._save_progress()

    def get_progress_summary(self) -> Dict:
        """获取学习进度汇总"""
        total_lessons = len(DECLINE_FALL_ROME_DATA)
        completed = len(self.progress['completed_days'])
        current = self.progress['current_day']

        return {
            'current_day': current,
            'completed_days': completed,
            'total_lessons': total_lessons,
            'progress_percent': f"{completed / total_lessons * 100:.1f}%" if total_lessons > 0 else "0%",
            'start_date': self.progress['start_date'],
            'last_study_date': self.progress['last_study_date'],
        }


def main():
    import argparse

    parser = argparse.ArgumentParser(description='罗马帝国衰亡史每日学习')
    subparsers = parser.add_subparsers(dest='action')

    # today 命令 - 今日学习
    today_parser = subparsers.add_parser('today', help='今日学习内容')
    today_parser.add_argument('--complete', '-c', action='store_true', help='标记为已完成')

    # day 命令 - 指定某天学习
    day_parser = subparsers.add_parser('day', help='指定某天学习')
    day_parser.add_argument('day', type=int, help='第几天')
    day_parser.add_argument('--complete', '-c', action='store_true', help='标记为已完成')

    # search 命令 - 搜索
    search_parser = subparsers.add_parser('search', help='搜索历史事件')
    search_parser.add_argument('keyword', help='搜索关键词（英文或中文）')

    # progress 命令 - 学习进度
    progress_parser = subparsers.add_parser('progress', help='学习进度')

    # random 命令 - 随机学习
    random_parser = subparsers.add_parser('random', help='随机学习一篇')

    args = parser.parse_args()

    skill = DeclineFallRomeSkill()

    if args.action == 'today':
        lesson = skill.get_today_lesson()
        if lesson:
            print_lesson(lesson)
            if args.complete:
                skill.mark_completed(lesson['day'])
                print("\n✅ 已标记为已完成")
        else:
            print("🎉 恭喜！你已经学完了所有内容！")

    elif args.action == 'day':
        lesson = skill.get_lesson_by_day(args.day)
        if lesson:
            print_lesson(lesson)
            if args.complete:
                skill.mark_completed(args.day)
                print("\n✅ 已标记为已完成")
        else:
            print(f"❌ 未找到第{args.day}天的学习内容")

    elif args.action == 'search':
        results = skill.search_lessons(args.keyword)
        if results:
            print(f"\n📚 搜索到 {len(results)} 篇相关内容：\n")
            for i, lesson in enumerate(results, 1):
                print(f"{i}. 【{lesson['chapter']}】{lesson['title']}")
        else:
            print(f"❌ 未找到与「{args.keyword}」相关的内容")

    elif args.action == 'progress':
        summary = skill.get_progress_summary()
        print("\n📊 学习进度")
        print("=" * 50)
        print(f"当前天数：第{summary['current_day']}天")
        print(f"已完成：{summary['completed_days']}篇")
        print(f"总篇数：{summary['total_lessons']}篇")
        print(f"进度：{summary['progress_percent']}")
        print(f"开始日期：{summary['start_date']}")
        print(f"上次学习：{summary['last_study_date'] or '尚未学习'}")
        print("=" * 50)

    elif args.action == 'random':
        lesson = skill.get_random_lesson()
        print_lesson(lesson)

    else:
        parser.print_help()


def print_lesson(lesson: Dict):
    """打印学习内容"""
    print(f"\n{'='*70}")
    print(f"🏛️ 罗马帝国衰亡史 - 第{lesson['day']}天")
    print(f"{'='*70}")
    print(f"【{lesson['chapter']}】{lesson['title']}")
    print(f"章节：{lesson['section']}")
    print(f"{'='*70}")

    print("\n📜 英文原文")
    print("-" * 70)
    print(lesson['original'])

    print("\n📝 中文翻译")
    print("-" * 70)
    print(lesson['translation'])

    print("\n💡 历史解读")
    print("-" * 70)
    print(lesson['interpretation'])

    print("\n📖 历史故事")
    print("-" * 70)
    print(lesson['story'])

    print(f"\n{'='*70}")
    print("使用 --complete 或 -c 标记为已完成")
    print(f"{'='*70}\n")


if __name__ == '__main__':
    main()
