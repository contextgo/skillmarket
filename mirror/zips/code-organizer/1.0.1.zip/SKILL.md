---
name: code-organizer
description: 代码整理与项目重构技能。当用户要求"帮我整理一下这个项目"、"让代码结构更清晰"、"统一命名规范"或类似请求时，请主动使用此技能对 Python（尤其是 PyTorch）项目进行系统性整理和重构。包括：目录结构重组、代码风格统一、冗余代码清理、注释规范化，以及生成项目文档。
---

# Code Organizer — 代码整理与项目重构技能

## 概述

本技能用于对小型 Python 项目（特别是 PyTorch 深度学习项目）进行系统性整理和重构。**重要原则：始终先生成整理建议，等待用户批准后再执行任何文件修改。**

---

## 工作流程

### ⚠️ 重要：防中断架构设计

**核心原则：使用并行子代理拆分任务，避免单会话超时导致的中断。**

对于复杂项目重构（超过5个文件需要修改），必须采用以下模式：

```python
# 错误做法：串行执行所有操作
for file in files_to_modify:
    read(file)       # 阻塞等待
    edit(file)       # 阻塞等待
    
# 正确做法：并行子代理 + 进度持久化
phases = [
    {"id": "phase-a", "task": "创建目录结构"},
    {"id": "phase-b", "task": "移动文件到对应目录"},
    {"id": "phase-c", "task": "更新所有import路径"},
    {"id": "phase-d", "task": "统一变量命名和类型提示"},
    {"id": "phase-e", "task": "生成三个文档文件"}
]

for phase in phases:
    spawn_sub_agent(phase["id"], phase["task"])  # 并行启动
```

### Phase 1: 分析与建议（主会话）

**由主会话执行，轻量级操作：**

1. **扫描项目** — 了解当前目录结构、代码规模、模块依赖关系
   - 使用 `exec` 的 `background=true` 模式进行耗时操作（如 robocopy, tree）
   ```bash
   # 推荐：后台执行长时间任务
   cmd /c "robocopy E:\\LPR E:\\LPR_backup /MIR" > backup.log 2>&1 &
   ```

2. **识别问题** — 找出以下类别的问题：
   - 目录结构混乱（文件散落各处）
   - 命名不一致（变量/函数/类命名风格混杂）
   - 代码重复或未使用
   - 注释缺失或格式不统一

3. **制定建议** — 生成一份结构化的整理计划，包含：
   - 新的目录结构建议
   - 需要修改的文件列表及修改类型
   - 预计可移除的无用代码/依赖
   - **子代理任务拆分方案**（关键！）

### Phase 2: 执行修改（需用户批准 + 并行子代理）

在收到明确批准后，**按以下顺序通过 sub-agents 并行执行**：

```python
# 主会话调度逻辑伪代码
tasks = {
    "create-structure": "创建目录结构和.gitignore",
    "move-files-phase1": "移动核心脚本到src/",
    "move-files-phase2": "移动模型文件到models/",
    "move-files-phase3": "移动工具模块到utils/",
    "update-imports": "更新所有Python文件的import路径",
    "code-cleanup": "统一命名规范和添加类型提示",
    "generate-readme": "生成README.md文档",
    "generate-modifications": "生成MODIFICATIONS.md文档",
    "generate-note": "生成NOTE.md文档"
}

# 分批启动子代理（避免token溢出）
batch_size = 3  # 每批最多3个子代理
for i in range(0, len(tasks), batch_size):
    batch = tasks[i:i+batch_size]
    for task_id, task_desc in batch.items():
        sessions_spawn(
            agentId="main", 
            label=task_id,
            task=f"""执行代码整理任务：{task_desc}
            
            注意事项：
            1. 使用相对路径操作文件
            2. 每个子代理只负责自己的任务
            3. 完成后将结果写入进度文件 memory/organize-progress.json
            4. 如果任何步骤失败，记录错误并继续其他步骤
            
            输出格式：
            {{"status": "success|failed", "task": "{task_id}", 
              "files_modified": [...], "errors": [...]}}"""
        )
```

#### A. 目录结构调整（子代理任务）
- 按功能模块重新组织文件（如 `models/`, `data/`, `utils/`, `configs/`, `experiments/`）
- PyTorch 项目常用结构参考：
  ```
  project-root/
  ├── models/          # 模型定义
  ├── data/            # 数据处理
  ├── utils/           # 工具函数
  ├── configs/         # 配置文件
  ├── experiments/     # 实验脚本
  ├── scripts/         # 辅助脚本
  └── ...
  ```

#### B. 代码风格统一（子代理任务）
- **命名规范**：类名使用 PascalCase，变量/函数使用 snake_case，常量使用 UPPER_CASE
- **格式**：确保 import 排序（标准库 → 第三方 → 本地），按字母顺序排列
- **注释规范**：统一使用 docstring 格式，添加类型标注

#### C. 代码清理
- 移除未使用的 import 和变量
- 合并重复功能
- 标记过时的依赖

#### D. 冗余代码清理（新增）
深入分析并优化：

1. **Dead Code Detection** — 检测死代码：
   - 从未调用的函数/类
   - 条件分支中永远不会执行的代码路径
   - 被注释掉的遗留代码块

2. **残余目录清理** — 删除重构后留下的空目录和旧文件：
   - **识别并删除空目录**：原算法目录（重构迁移后遗留的空子目录应在清理阶段移除
   - **移动或移除原始输入数据**：如测试样本、演示文件等，根据项目原则放入 data/ 目录或删除
   - **清理 \.idea/\ 和 \__pycache__/\**：确保所有 IDE 缓存和 Python 字节码被排除在版本控制外
   - **确认无重复文件**：避免新旧代码在同一目录下共存

3. **Duplicate Logic Removal** — 消除重复逻辑：
   - 识别相似功能模块（如多个文件中的日志初始化）
   - 提取为公共工具函数放入 `utils/`
   
3. **Legacy Code Marking** — 标记过时依赖：
   - Python 2 兼容代码
   - 已废弃的 API 调用
   - 过时的第三方库版本

#### E. 配置参数化（新增）
将硬编码值提取为可配置项：

1. **Magic Number Extraction** — 魔法数字提取：
   ```python
   # ❌ 改进前
   model = create_model("convnext", pretrained=True, feature_dim=512)
   
   # ✅ 改进后 - 通过配置文件
   config = load_config("configs/train.yaml")
   model = create_model(config.model.name, **config.model.params)
   ```

2. **YAML Configuration Structure** — 标准配置格式：
   ```yaml
   # configs/default.yaml
   training:
     batch_size: 32
     num_epochs: 40
     lr: 1.0e-4
     optimizer: adam
     weight_decay: 1.0e-5
   
   model:
     architecture: convnext
     pretrained: true
     feature_dim: 512
     
   data:
     train_dir: data/train
     val_dir: data/val
     img_size: [224, 224]
   ```

3. **Command Line Override** — 命令行参数优先：
   - 使用 argparse 支持运行时覆盖配置
   - 优先级：CLI > config file > defaults

#### F. 单元测试补充（新增）
为核心逻辑添加测试用例：

1. **Critical Path Coverage** — 关键路径测试：
   - 数据加载与预处理
   - 模型前向传播
   - 损失计算与反向传播
   
2. **Test Structure** — 推荐测试结构：
   ```
   tests/
   ├── __init__.py
   ├── conftest.py          # pytest fixtures
   ├── test_dataset.py      # 数据集相关测试
   ├── test_model.py        # 模型架构测试
   └── test_utils.py        # 工具函数测试
   ```

3. **Test Framework Selection** — 推荐框架：
   - `pytest` + `unittest.mock` — 灵活且功能强大
   - `torch.testing.make_tensor` — PyTorch 张量生成辅助
   
4. **Minimum Test Coverage** — 最低覆盖率要求：
   | 模块类型 | 最低覆盖率 |
   |---------|-----------|
   | 数据加载 | ≥80% |
   | 模型定义 | ≥70% |
   | 工具函数 | ≥90% |
   | 入口脚本 | N/A（集成测试）|

### Phase 3: 进度持久化与验证

**每个子代理完成后必须写入进度文件：**

```json
// memory/organize-progress.json (由主会话创建和维护)
{
  "project": "E:\\LPR",
  "started_at": "2026-04-28T00:00:00+08:00",
  "phases": {
    "create-structure": {"status": "completed", "files_created": [".gitignore"]},
    "move-files-phase1": {"status": "in_progress"},
    ...
  },
  "resumable": true,
  "last_checkpoint": "2026-04-28T00:05:00+08:00"
}
```

**主会话在启动时检查进度：**
1. 如果存在 `memory/organize-progress.json` 且包含未完成阶段 → **跳过已完成阶段，继续执行剩余任务**
2. 如果文件不存在或项目未开始 → 从头开始

### Phase 4: 生成文档（子代理并行）

修改完成后，在**项目根目录**生成以下三个文件：

---

## 文档生成规范

### README.md — 用户面向文档

遵循标准范式，内容应包含：

```markdown
# [项目名称]

[简短的项目描述 — 一句话概括项目目的]

## Features
- [功能点1]
- [功能点2]
- ...

## Project Structure
[新的目录结构树]

## Quick Start
```bash
pip install -r requirements.txt
python main.py --config configs/default.yaml
```

## Configuration
[配置文件说明]

## License
[许可证信息，如已知]
```

**要求**：简洁明了，面向最终用户或使用者。

---

### MODIFICATIONS.md — 修改记录

客观详细记录所有变更（可包含常见问题排查）：

```markdown
# Modifications Log

## Directory Restructuring
- Moved `model.py` → `models/definition.py`
- Created `utils/helpers.py` from scattered functions
- ...

## Code Style Changes
- Renamed variable `x_data` → `input_tensor` (following PyTorch conventions)
- Added type annotations to [N] functions
- Reorganized imports in [N] files
- ...

## Cleanup
- Removed unused import: `os.path.join` (replaced by `pathlib`)
- Consolidated duplicate validation logic into `utils/validators.py`
- ...

## Comment Updates
- Added docstrings to [N] functions
- Standardized comment format across all files

## Troubleshooting Notes（常见问题排查）
### 问题1: [错误描述]
**原因**: [根本原因分析]
**解决**: [解决方案步骤]

---
验证清单：
- [x] 所有 import 路径已更新
- [x] 类型提示已添加
- [x] docstring 完整覆盖公共 API
```

**要求**：具体、可追溯，列出实际变更项。包含常见问题排查记录以便后续维护参考。

---

### NOTE.md — 个人笔记（中文）

面向你自己，简要提示项目核心信息（保持精简）：

```markdown
# [项目名称] 笔记

## 项目用途
[用一两句中文概括这个项目是做什么的、解决什么问题]

## 快速启动
```bash
# 安装依赖
pip install -r requirements.txt

# 基本使用示例
python main.py [options]
```

## 常用配置（按需调整）
| 配置项 | 说明 |
|--------|------|
| [配置A] | [默认值/建议范围] — [简要用途] |
| [配置B] | [默认值/建议范围] — [简要用途] |

## 技术栈
- [技术栈描述，如 Python + Flask / Node.js / etc.]
```

**要求**：保持精简（不超过一页），中文撰写，只包含核心使用信息。**不要包含**修改记录、常见问题排查、代码改进说明等内容。

---

### ⚠️ 三文件不重叠原则

| 文件 | 侧重点 |
|------|--------|
| README.md | **是什么 + 怎么用** — 面向外部用户 |
| MODIFICATIONS.md | **改了什么** — 变更历史记录 |
| NOTE.md | **项目概况** — 个人快速参考 |

避免内容重复：README 不记录修改细节，MODIFICATIONS 不解释功能用途，NOTE 不做详细技术文档。

---

## 安全注意事项

1. **始终先分析再行动** — 不要擅自修改任何文件
2. **保留原始备份意识** — 如果用户要求，可建议创建 git 快照
3. **不做破坏性操作** — 不删除未确认的文件或代码
4. **尊重项目现有结构** — 除非有明显改进空间

---

## PyTorch 项目特殊处理

针对深度学习项目的额外考虑：

- **模型文件**：`models/` 目录下按架构分类（如 `models/resnet.py`, `models/custom_net.py`）
- **数据集**：`data/` 或 `datasets/`，区分预处理和原始数据路径
- **实验管理**：建议 `experiments/` 目录存放训练脚本
- **配置优先**：将超参数提取到 `configs/` YAML 文件
- **日志输出**：确保有统一的 logging 机制
