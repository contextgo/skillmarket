---
name: code-organizer
description: 代码整理与项目重构技能。当用户要求"帮我整理一下这个项目"、"让代码结构更清晰"、"统一命名规范"或类似请求时，请主动使用此技能对 Python 项目进行系统性整理和重构（默认通用 Python 风格，根据具体项目类型如深度学习/Web/API/CLI 自动调整）。包括：目录结构重组、OOP SOLID 原则检查、函数设计规范、错误处理规范、Google-style docstring、导入组织规则、分层架构 / DDD 结构设计、__init__.py 公共 API、代码风格统一、冗余代码清理、配置参数化、单元测试补充，以及生成项目文档。
---

# Code Organizer — 代码整理与项目重构技能

## 概述

本技能用于对 Python 项目进行系统性整理和重构（默认通用风格，根据具体项目类型自动适配）。**重要原则：始终先生成整理建议，等待用户批准后再执行任何文件修改。**

### ⚠️ 避免过度工程化 — 核心约束

**在提出优化建议前，必须先评估项目规模。小型项目应以最小改动为目标。**

| 规模 | 判断标准 | 适用策略 |
|------|---------|---------|
| **微型（1-3 文件）** | 单脚本、Jupyter Notebook、实验性代码 | 仅清理无用代码和空目录，不做结构性调整。不强制 src layout、测试覆盖、配置参数化、文档生成 |
| **小型（4-9 文件）** | 小型工具、数据处理管道、原型项目 | 可整理命名规范和导入顺序；可选创建 README.md。**禁止**自动分层架构、DDD、完整单元测试、pyproject.toml 全套配置。不强制 configs/ 目录和 YAML 配置提取 — 仅当参数数量 >3 时才建议配置化 |
| **中型（10-49 文件）** | 可发布的小库、API 服务、完整 pipeline | 可选 src layout；可选创建 __init__.py + __all__；测试覆盖率 ≥70%；可选分层架构 |
| **大型（50+ 文件）** | 团队项目、商业产品级应用 | 全面重构：src layout + __all__ + 分层/DDD + 完整测试覆盖 + pyproject.toml + 三文档生成 |

**判断原则：**
- "整理" ≠ "重构到最佳实践" — 用户说"帮我整理一下"时，默认只需要轻度修复（无用代码、明显命名问题、空目录）
- 对于深度学习实验/数据处理原型项目：如果项目核心是跑通流程而非工程化，优先保持结构简洁，仅在明确需求时引入配置化和模块化
- **任何超出当前需求的优化，都应在建议阶段列出供用户选择，而不是默认执行**

---

## 工作流程

### ⚠️ 重要：防中断架构设计

**核心原则：使用并行子代理拆分任务，避免单会话超时导致的中断。**

对于复杂项目重构（超过5个文件需要修改），必须采用以下模式：

```python
# 错误做法：串行执行所有操作
for file in files_to_modify:
    read(file)       # 阻塞等待
    edit(file)       # 阻塞等待
    
# 正确做法：并行子代理 + 进度持久化
phases = [
    {"id": "phase-a", "task": "创建目录结构"},
    {"id": "phase-b", "task": "移动文件到对应目录"},
    {"id": "phase-c", "task": "更新所有import路径"},
    {"id": "phase-d", "task": "统一变量命名和类型提示"},
    {"id": "phase-e", "task": "生成三个文档文件"}
]

for phase in phases:
    spawn_sub_agent(phase["id"], phase["task"])  # 并行启动
```

### Phase 1: 分析与建议（主会话）

**由主会话执行，轻量级操作：**

0. **项目规模评估（关键！避免过度工程化）** — 统计文件数量并判断适用策略：
   - 微型（1-3 文件）→ 仅清理无用代码和空目录
   - 小型（4-9 文件）→ 轻度整理，不强制 src layout、测试覆盖、文档生成
   - 中型（10-49 文件）→ 可选完整重构
   - 大型（50+ 文件）→ 全面重构

1. **扫描项目** — 了解当前目录结构、代码规模、模块依赖关系
   - 使用 `exec` 的 `background=true` 模式进行耗时操作（如 robocopy, tree）
   ```bash
   # 推荐：后台执行长时间任务
   cmd /c "robocopy E:\\LPR E:\\LPR_backup /MIR" > backup.log 2>&1 &
   ```

2. **识别问题** — 找出以下类别的问题：（仅针对当前规模下适用的优化）
   - 目录结构混乱（文件散落各处）
   - 命名不一致（变量/函数/类命名风格混杂）
   - 代码重复或未使用
   - 注释缺失或格式不统一

3. **制定建议** — 生成一份结构化的整理计划，包含：
   - 新的目录结构建议
   - 需要修改的文件列表及修改类型
   - 预计可移除的无用代码/依赖
   - **子代理任务拆分方案**（关键！）

### Phase 2: 执行修改（需用户批准 + 并行子代理）

在收到明确批准后，**按以下顺序通过 sub-agents 并行执行**：

```python
# 主会话根据项目规模选择任务集
tasks = {
    # === 所有规模都适用 ===
    "code-cleanup": "统一命名规范和添加类型提示",

    # === 仅中型/大型项目 ===
    "create-structure": "创建目录结构和.gitignore" if scale >= medium else None,
    "move-files-phase1": "移动核心脚本到src/" if scale >= medium else None,
    # ...
}

tasks = {k: v for k, v in tasks.items() if v is not None}  # 过滤掉不适用的任务

# 分批启动子代理（避免token溢出）
batch_size = 3  # 每批最多3个子代理
for i in range(0, len(tasks), batch_size):
    batch = tasks[i:i+batch_size]
    for task_id, task_desc in batch.items():
        sessions_spawn(
            agentId="main", 
            label=task_id,
            task=f"""执行代码整理任务：{task_desc}
            
            注意事项：
            1. 使用相对路径操作文件
            2. 每个子代理只负责自己的任务
            3. 完成后将结果写入进度文件 memory/organize-progress.json
            4. 如果任何步骤失败，记录错误并继续其他步骤
            
            输出格式：
            {{"status": "success|failed", "task": "{task_id}", 
              "files_modified": [...], "errors": [...]}}"""
        )
```

#### A. 目录结构调整（子代理任务，视规模选择）

**微型/小型项目：保持扁平结构即可。** 不做 src layout、不拆分多层级。

**中型及以上：**

```
project-root/
├── src/               # 源代码
│   └── package_name/  # 主包
├── tests/             # 测试代码（可选）
├── configs/           # 配置文件（可选，参数 >3 时建议）
├── scripts/           # 辅助脚本、CLI工具
├── docs/              # 项目文档（仅中型以上）
└── ...
```

根据项目类型可调整：
- **Web/API 应用** — `src/app/routes.py`, `src/app/services/`
- **数据处理项目** — `src/pipeline/`, `data/`, `notebooks/`
- **深度学习项目** — `models/`, `trainers/`, `experiments/`

#### B. 代码风格统一（子代理任务）
- **命名规范**：类名使用 PascalCase，变量/函数使用 snake_case，常量使用 UPPER_CASE
- **格式**：确保 import 排序（标准库 → 第三方 → 本地），按字母顺序排列
- **注释规范**：统一使用 docstring 格式，添加类型标注

#### C. 代码清理
- 移除未使用的 import 和变量
- 合并重复功能
- 标记过时的依赖

#### D. 冗余代码清理（新增）
深入分析并优化：

1. **Dead Code Detection** — 检测死代码：
   - 从未调用的函数/类
   - 条件分支中永远不会执行的代码路径
   - 被注释掉的遗留代码块

2. **残余目录清理** — 删除重构后留下的空目录和旧文件：
   - **识别并删除空目录**：原算法目录（重构迁移后遗留的空子目录应在清理阶段移除
   - **移动或移除原始输入数据**：如测试样本、演示文件等，根据项目原则放入 data/ 目录或删除
   - **清理 \.idea/\ 和 \__pycache__/\**：确保所有 IDE 缓存和 Python 字节码被排除在版本控制外
   - **确认无重复文件**：避免新旧代码在同一目录下共存

3. **Duplicate Logic Removal** — 消除重复逻辑：
   - 识别相似功能模块（如多个文件中的日志初始化）
   - 提取为公共工具函数放入 `utils/`
   
3. **Legacy Code Marking** — 标记过时依赖：
   - Python 2 兼容代码
   - 已废弃的 API 调用
   - 过时的第三方库版本

#### E. 配置参数化（视规模选择）

- **微型/小型项目**：如果硬编码值不超过 3 个，**不要创建 YAML 配置文件和 argparse CLI**。保持 inline 即可。
- **中型及以上或参数 >3 时**才执行以下操作：

1. **Magic Number Extraction** — 魔法数字提取：
   ```python
   # ❌ 改进前（参数超过2-3个）
   api_client = create_client(host="api.example.com", port=8080, timeout=30)

   # ✅ 改进后 - 通过配置文件
   config = load_config("configs/default.yaml")
   api_client = create_client(config.api.host, config.api.port, config.api.timeout_seconds)
   ```

2. **YAML Configuration Structure** — 标准配置格式：（仅适用于中型以上项目）
   （示例同上...）

3. **Command Line Override** — 命令行参数优先（仅适用于 CLI/工具脚本）：

#### F. 单元测试补充（视规模选择）

- **微型/小型项目**：**不建议强制编写单元测试**。原型代码、一次性实验脚本不需要测试覆盖。如果确实有核心逻辑需要验证，只写最简单的 assert 检查即可。
- **中型及以上**：为核心逻辑添加测试用例：

1. **Critical Path Coverage** — 关键路径测试（仅对中型以上项目）：
   - I/O 操作（文件读写、网络请求）
   - 核心业务逻辑/算法处理
   - 数据验证与转换流程

2. **Test Structure** — 推荐测试结构：（同上...）

3. **Test Framework Selection** — 推荐框架（同上...）

4. **Minimum Test Coverage** — 最低覆盖率要求（仅对中型以上项目）：

### Phase 3: 进度持久化与验证

**每个子代理完成后必须写入进度文件：**

```json
// memory/organize-progress.json (由主会话创建和维护)
{
  "project": "E:\\LPR",
  "started_at": "2026-04-28T00:00:00+08:00",
  "phases": {
    "create-structure": {"status": "completed", "files_created": [".gitignore"]},
    "move-files-phase1": {"status": "in_progress"},
    ...
  },
  "resumable": true,
  "last_checkpoint": "2026-04-28T00:05:00+08:00"
}
```

**主会话在启动时检查进度：**
1. 如果存在 `memory/organize-progress.json` 且包含未完成阶段 → **跳过已完成阶段，继续执行剩余任务**
2. 如果文件不存在或项目未开始 → 从头开始

### Phase 3.5: 代码质量与设计规范检查（视规模选择）

**核心原则：对小型项目只做"明显问题修复"，不做深度重构。** 仅当代码确实难以维护时才执行下列优化。

- **微型/小型项目** — 只修复最明显的命名问题和死代码。不拆分函数、不做 OOP 改造、不加类型注解。
- **中型及以上** — 可逐项应用以下规范：

#### A. 函数设计规范（来自 Clean Code）
- **长度** — 理想 4-10 行，不超过两三层缩进；超过则拆分子函数
- **参数数量** — ≤3 个最佳，>5 应使用配置对象/数据类封装
- **布尔参数是代码气味** — 一个布尔参数暗示函数做了两件不同的事，应拆分为两个独立函数（DoS 原则）
- **命令-查询分离 (CQS)** — 函数要么执行动作（Command），要么返回信息（Query），不能两者兼有

#### B. OOP SOLID 六大原则
对每个类用以下自检问题检验：
1. **SRP (Single Responsibility)** — 能否在 25 字以内描述其职责而不含 "if/and/or/but"？
2. **OCP (Open-Closed)** — 能否扩展行为而无需修改源码（开闭原则）？
3. **LSP (Liskov Substitution)** — 子类对象能否替换父类对象而不改变程序正确性？
4. **ISP (Interface Segregation)** — 接口是否足够小，消费者不依赖他们不使用的方法？
5. **DIP (Dependency Inversion)** — 高层模块是否依赖抽象而非具体实现？

#### C. 错误处理规范（来自 Clean Code）
- **异常优先于返回码** — 用 try/except 替代检查特殊返回值
- **禁止返回或传递 None 表示"无"** — Python 中应返回空列表 `[]`、空字典 `{}` 等；仅在语义上确实可能缺失时用 Optional[Type]
- **封装第三方 API** — 将外部库调用包装在内部接口后，使代码可测试和可 mock

#### D. 注释哲学（来自 Clean Code）
注释是"必要的恶"。优先选择重命名而非写注释。仅以下情况应添加注释：
1. 解释意图（why），而非描述做了什么（what）— "用 Adam 优化器因为收敛快" ✅；"遍历列表" ❌
2. 法律条款 / 许可声明
3. 警告可能的后果（如副作用、并发注意事项）
4. 对第三方/外部库行为的不透明之处做解释

#### E. Google-style Docstring 模板（视规模选择）

- **微型/小型项目** — 不强制。仅对公开 API 或核心函数编写简单 docstring。
- **中型及以上** — 公共函数/方法必须添加，遵循以下格式：
```python
def fetch_user(user_id: int, include_deleted: bool = False) -> User | None:
    """Fetch a user by ID with optional deleted flag."""
    ...

class DataProcessor:
    """Efficiently processes and batches input records.

    This class handles filtering, transformation, and batching of data.
    It is designed to be subclassed for custom processing pipelines.

    Attributes:
        batch_size: Number of records per batch (default: 32).
        shuffle: Whether to shuffle the dataset every epoch.
        num_workers: Number of parallel workers for data loading.

    Example:
        >>> processor = DataProcessor(batch_size=64, shuffle=True)
        >>> for batch in processor:
        ...     print(len(batch))
    """
```

#### F. 导入组织规则（Import Organization）
1. **优先使用绝对导入** — 避免相对导入，因为模块移动时不会自动更新
2. **标准库 → 第三方 → 本地代码**（三段式 + 空行分隔）
3. **每组内部按字母顺序排列**
4. **从每个 import 组内做具体导出**（如 `from .models.resnet import ResNet50`），而非 `import models.resnet`

---

## 文档生成规范（视规模选择）

### README.md — 用户面向文档（中型及以上项目建议，小型可选）

- **微型/小型项目** — 如果代码自解释性强，**可以不写 README**。简单说明即可。
- **中型及以上** — 遵循标准范式，内容应包含：

```markdown
# [项目名称]

[简短的项目描述 — 一句话概括项目目的]

## Features
- [功能点1]
- [功能点2]
- ...

## Project Structure
[新的目录结构树]

## Quick Start
```bash
pip install -r requirements.txt
python main.py --config configs/default.yaml
```

## Configuration
[配置文件说明]

## License
[许可证信息，如已知]
```

**要求**：简洁明了，面向最终用户或使用者。

---

### MODIFICATIONS.md — 修改记录（中型及以上项目建议，小型可选）

- **微型/小型项目** — 通常不需要。如果改动不多，用 git commit message 说明即可。
- **中型及以上** — 客观详细记录所有变更：

```markdown
# Modifications Log

## Directory Restructuring
- Moved `model.py` → `models/definition.py`
- Created `utils/helpers.py` from scattered functions
- ...

## Code Style Changes
- Renamed variable `raw_data` → `parsed_records` (semantic naming)
- Added type annotations to [N] functions
- Reorganized imports in [N] files
- ...

## Cleanup
- Removed unused import: `os.path.join` (replaced by `pathlib`)
- Consolidated duplicate validation logic into `utils/validators.py`
- ...

## Comment Updates
- Added docstrings to [N] functions
- Standardized comment format across all files

## Troubleshooting Notes（常见问题排查）
### 问题1: [错误描述]
**原因**: [根本原因分析]
**解决**: [解决方案步骤]

---
验证清单：
- [x] 所有 import 路径已更新
- [x] 类型提示已添加
```

**要求**：具体、可追溯，列出实际变更项。包含常见问题排查记录以便后续维护参考。

---

### NOTE.md — 个人笔记（中文）

面向你自己，简要提示项目核心信息（保持精简）：

```markdown
# [项目名称] 笔记

## 项目用途
[用一两句中文概括这个项目是做什么的、解决什么问题]

## 快速启动
```bash
# 安装依赖
pip install -r requirements.txt

# 基本使用示例
python main.py [options]
```

## 常用配置（按需调整）
| 配置项 | 说明 |
|--------|------|
| [配置A] | [默认值/建议范围] — [简要用途] |
| [配置B] | [默认值/建议范围] — [简要用途] |

## 技术栈
- [技术栈描述，如 Python + Flask / Node.js / etc.]
```

**要求**：保持精简（不超过一页），中文撰写，只包含核心使用信息。**不要包含**修改记录、常见问题排查、代码改进说明等内容。

---

### ⚠️ 三文件不重叠原则

| 文件 | 侧重点 |
|------|--------|
| README.md | **是什么 + 怎么用** — 面向外部用户 |
| MODIFICATIONS.md | **改了什么** — 变更历史记录 |
| NOTE.md | **项目概况** — 个人快速参考 |

避免内容重复：README 不记录修改细节，MODIFICATIONS 不解释功能用途，NOTE 不做详细技术文档。

---

## 安全注意事项

1. **始终先分析再行动** — 不要擅自修改任何文件
2. **保留原始备份意识** — 如果用户要求，可建议创建 git 快照
3. **不做破坏性操作** — 不删除未确认的文件或代码
4. **尊重项目现有结构** — 除非有明显改进空间

---

## PyTorch / 深度学习项目特殊处理

针对深度学习项目的额外考虑（如适用）：

- **模型文件**：`models/` 目录下按架构分类（如 `models/resnet.py`, `models/custom_net.py`）
- **数据集**：`data/` 或 `datasets/`，区分预处理和原始数据路径
- **实验管理**：建议 `experiments/` 目录存放训练脚本、checkpoint、日志
- **配置优先**：将超参数（batch_size, lr, epochs 等）提取到 `configs/` YAML 文件
- **日志输出**：确保有统一的 logging 机制（建议用 Python stdlib `logging` 或 `loguru`）

## Web / API 应用特殊处理

针对 Web/API 项目的额外考虑：

- **路由组织** — FastAPI/Flask 按资源划分路由（`routes/users.py`, `routes/orders.py`）
- **中间件与鉴权** — 认证逻辑独立为 middleware 或 service
- **数据库迁移** — Alembic 或类似工具管理 schema 变更

## CLI / 数据处理项目特殊处理

针对命令行工具和 ETL 管道的额外考虑：

- **配置集中** — 配置文件 + argparse / Typer，确保参数可追溯
- **日志与进度** — rich / click 的进度条支持，便于长时运行的管道监控

---

## Python 项目结构规范（补充）

### A. __init__.py 作为公共 API 边界（中型及以上项目）

- **微型/小型项目 / Flat Layout** — 通常不需要 `__init__.py`，也不需要 `__all__`。
- **中型及以上且使用 src layout 时**：
  - `__init__.py` 不应包含业务逻辑，仅用于重新导出子模块的公开接口
  - 使用 `__all__` **显式声明**公共 API — 不在列表中的 symbol 视为私有：
  ```python
  # __init__.py
  from .user_service import UserService
  from .auth import AuthProvider

  __all__ = ["UserService", "AuthProvider"]
  ```
- 消费者应 `import package` 然后使用公开符号，而非直接 `import package.inner_module`

### B. src/ vs Flat Layout — 决策框架

| 特征 | src/ layout（推荐） | Flat layout |
|------|---------------------|-------------|
| **适用场景** | 库、可发布项目、测试需要模拟包导入 | 简单脚本、一次性分析 Notebook |
| **优点** | 防止误用未安装包运行；`pip install -e .` 行为一致 | 结构简单，路径短 |
| **缺点** | 多一层目录嵌套 | 开发时可能无意中导入本地模块而非安装的包 |

- **中型及以上项目** — 建议选 `src/` layout：`src/package_name/` + `tests/`
- **微型/小型项目 / Flat Layout** — 保持扁平结构即可（如 `main.py`, `utils.py`, `config.yaml`）
- 现有 flat 项目无需强制迁移，除非有明确的包隔离需求

### C. Layered Architecture — 分层架构（仅中型及以上项目）

- **微型/小型项目** — **不要强行拆分多层**。一个 `main.py` + `utils.py` 就够了。
- **中型及以上且涉及多模块交互时**，按技术栈分层（从高层到低层），**依赖只能单向向下**：

```
api/          # FastAPI/Flask 路由、请求/响应模型
│
services/     # 业务逻辑入口点，调用 repositories
│
repositories/ # 数据访问层，与数据库/外部 API 交互
│
models/       # Pydantic 模型 / SQLAlchemy ORM
│
schemas/      # DTOs, input validation schemas
│
config/       # 配置加载、环境管理
```

- 每层只能 `import` 下层模块，禁止跨层或反向导入
- 通过依赖注入（构造函数参数）而非全局实例来耦合层间关系

### D. Domain-Driven Organization（DDD 风格）

当项目复杂度较高时，按业务域划分而非技术层：

```
users/              # 用户域
├── models.py       # 领域模型
├── services.py     # 领域服务
└── api.py          # API 端点
orders/             # 订单域
...
shared/             # 跨域的公共基础设施（日志、缓存等）
```

- DDD 结构适用于团队多人协作的大型项目
- 小型项目仍推荐传统的 layered architecture，避免过度工程化

### E. 模块粒度 — "一个概念一个文件"

- **拆分阈值**：单个文件超过 300-500 行或处理多个不相关职责时应拆分为独立文件
- **文件命名**：`snake_case`、描述性强（如 `user_repository.py`，而非 `repo.py`）
- **类名与文件名匹配**：`UserService` 应放在 `user_service.py` 中

### F. 测试组织 — Co-located vs Parallel（仅中型及以上项目）

- **微型/小型项目** — **不建议写单元测试**。如果必须验证核心逻辑，在脚本中用简单的 `assert` 即可。
- **中型及以上** — 两种策略任选其一并在整个项目中保持一致：

| 策略 | 结构 | 适用场景 |
|------|------|----------|
| **Co-located**（推荐） | `tests/test_<module>.py` 与源码同级 | 小型项目、测试逻辑与实现紧密相关 |
| **Parallel directory** | `tests/` 镜像 `src/` 目录结构 | 大型项目、CI 需要独立运行所有测试 |

### G. pyproject.toml — 工具链配置（中型及以上项目，或发布为库时）

- **微型/小型项目** — 不需要。脚本直接运行即可。
- **中型及以上 / 需要发布到 PyPI 的项目**：在根目录创建 `pyproject.toml`：

```toml
[tool.ruff]
line-length = 120
target-version = "py311"

[tool.ruff.lint]
select = ["E", "W", "F", "I", "B", "UP", "SIM"]
# E/W: pycodestyle, F: Pyflask, I: isort, B: bugbear, UP: pyupgrade, SIM: simplify

[tool.ruff.lint.per-file-ignores]
"tests/**/*" = ["S101"]  # allow assert in tests
"__init__.py" = ["F401"] # unused imports are re-exports by convention

[tool.mypy]
python_version = "3.11"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = false  # production code: true; tests: override to false
```

---

## ⚠️ 避免过度工程化 — 具体禁令

以下行为在**任何规模的项目中都不应默认执行**，除非用户明确提出需求或项目规模确实需要：

1. **不要为只有几个变量的脚本创建 YAML/TOML 配置文件 + argparse CLI** — inline 参数更简单
2. **不要将简单的函数拆分成多个子函数以符合"4-10 行"规则** — 保持逻辑完整性优先于行数限制
3. **不要在扁平布局的项目中强制创建 `__init__.py` + `__all__`**
4. **不要对只有一个类的文件做 SRP/OCP/LSP/ISP/DIP 分析** — OOP 原则只在存在继承和多态关系时才适用
5. **不要为只有几个文件的深度学习/数据处理项目创建完整的分层架构或 DDD 结构**
6. **不要在原型代码中强制要求单元测试和覆盖率阈值**
7. **不要对只有一两个使用者的内部工具生成 README + MODIFICATIONS + NOTE 三份文档** — git commit message 通常就够了
8. **不要把 `main.py` 强行塞进 `src/package_name/` 的目录结构中** — src layout 只对库或大型应用有意义

> **核心原则：优化是为了让人更容易理解和维护代码，不是为了"达到最佳实践"。如果改动让项目变得更复杂而不是更简单，那就做过头了。**
