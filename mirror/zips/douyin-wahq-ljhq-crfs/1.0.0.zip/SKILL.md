---
name: 抖音文案获取_飞书链接内获取_存入飞书
description: >
  从飞书多维表中读取视频附件，自动提取语音文案、语义分段、爆款逻辑分析，并写入飞书文案收录表。
  触发词：飞书视频提取、多维表视频、飞书链接提取、从飞书提取文案、飞书附件视频、
  处理飞书视频、批量提取文案、飞书视频附件、从多维表获取、表格里的视频
metadata:
  openclaw:
    emoji: "📹"
    requires:
      env: [SILI_FLOW_API_KEY, LARK_APP_ID, LARK_APP_SECRET, LARK_APP_TOKEN, LARK_TABLE_ID]
allowed-tools:
disable: false
---

# 抖音文案获取_飞书链接内获取_存入飞书 Skill

从飞书多维表的视频附件字段中读取视频文件，自动提取语音文案、语义分段、品类识别、爆款逻辑分析，并写入飞书文案收录多维表。

## 功能

- 📂 从飞书多维表自动读取视频附件字段（attachment 类型）
- 📥 自动下载视频到本地临时目录
- 🎙️ 语音转写（硅基流动 SenseVoiceSmall）
- ✂️ 语义分段（硅基流动 Qwen/Qwen2.5-7B-Instruct）
- 🏷️ **品类自动识别**（AI 根据标题匹配抖音官方三级类目）
- 🏆 **爆款逻辑分析（9维度深度拆解）**（硅基流动 Qwen）
- 📊 自动写入飞书文案收录多维表
- 🔄 支持**批量处理**（自动遍历源表所有记录）
- ⚡ 已处理视频**自动跳过下载**

## 与「抖音文案获取_存入飞书」的区别

| | 抖音文案获取_存入飞书 | 抖音文案获取_飞书链接内获取_存入飞书 |
|---|---|---|
| **输入源** | 抖音视频链接（URL） | 飞书多维表中的视频附件 |
| **下载方式** | 解析抖音链接 → 下载视频 | 飞书 API → 获取临时链接 → 下载 |
| **使用场景** | 用户提供抖音链接时 | 用户提供飞书多维表链接时 |
| **批量能力** | 单条处理 | 支持批量遍历源表所有记录 |

## 环境变量

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `SILI_FLOW_API_KEY` | 硅基流动 API（语音转写 + AI分析） | 必填 |
| `LARK_APP_ID` | 飞书应用 App ID | 必填 |
| `LARK_APP_SECRET` | 飞书应用 App Secret | 必填 |
| `LARK_SOURCE_APP_TOKEN` | 源多维表 App Token（存放视频附件的表） | 默认 = `LARK_APP_TOKEN` |
| `LARK_SOURCE_TABLE_ID` | 源多维表 Table ID（存放视频附件的表） | 必填 |
| `LARK_APP_TOKEN` | 目标文案收录表 App Token | 必填 |
| `LARK_TABLE_ID` | 目标文案收录表 Table ID | 必填 |

> ✅ 基础变量（`SILI_FLOW_API_KEY`, `LARK_APP_ID`, `LARK_APP_SECRET`, `LARK_APP_TOKEN`, `LARK_TABLE_ID`）已持久化到 `~/.zshrc`。
> ⚠️ 如果源表和目标表不是同一个多维表，需要额外设置 `LARK_SOURCE_APP_TOKEN` 和 `LARK_SOURCE_TABLE_ID`。

## 使用方法

### 方式一：从飞书链接批量处理（推荐）

用户提供飞书多维表链接时，AI 需要执行以下步骤：

1. 从链接中解析 `base-token` 和 `table-id`
2. 读取源表记录，找到视频附件字段
3. 执行脚本处理

```bash
source ~/.zshrc && node /Users/Zhuanz/.workbuddy/skills/抖音文案获取_飞书链接内获取_存入飞书/lark_video_extract.js --source-token <源表token> --source-table <源表table-id>
```

### 方式二：处理指定记录

```bash
source ~/.zshrc && node /Users/Zhuanz/.workbuddy/skills/抖音文案获取_飞书链接内获取_存入飞书/lark_video_extract.js --record-id <record-id> --source-token <token> --source-table <table-id>
```

### 方式三：指定视频名称

```bash
source ~/.zshrc && node /Users/Zhuanz/.workbuddy/skills/抖音文案获取_飞书链接内获取_存入飞书/lark_video_extract.js --record-id <record-id> --name "自定义视频名称" --source-token <token> --source-table <table-id>
```

## AI 调用指引

### 当用户提供飞书多维表链接时

1. **解析链接**：从 URL 中提取 `base-token`（`/base/` 后面的部分）和 `table-id`（`?table=` 后面的部分，`tbl` 开头）
2. **读取源表结构**：用 `lark-cli base +field-list --base-token <token> --table-id <id> --as user` 查看字段结构
3. **读取源表记录**：用 `lark-cli base +record-list --base-token <token> --table-id <id> --as user --limit 200` 获取记录
4. **确认视频附件字段**：找到类型为 `attachment` 的字段，确认其中有视频文件
5. **执行处理脚本**：

```bash
source ~/.zshrc && node /Users/Zhuanz/.workbuddy/skills/抖音文案获取_飞书链接内获取_存入飞书/lark_video_extract.js --source-token <源表token> --source-table <源表table-id>
```

### 处理流程

```
读取飞书源表记录
  ↓
遍历每条记录，查找视频附件字段
  ↓
下载视频（已存在则跳过）
  ↓
FFmpeg 提取音频
  ↓
硅基流动 SenseVoiceSmall 语音转写
  ↓
Qwen2.5-7B 语义分段
  ↓
Qwen2.5-7B 爆款逻辑9维度分析
  ↓
Qwen2.5-7B 品类识别
  ↓
写入飞书目标文案收录表
  ↓
保存本地文案文件
```

## 飞书多维表结构说明

### 源表（存放视频附件的表）

至少需要包含一个 **附件类型** 字段，用于存放视频文件。

推荐字段结构：
| 字段名 | 类型 | 说明 |
|--------|------|------|
| 视频文件 | 附件 | 视频文件附件 |
| 视频名称 | 文本 | 视频标题（可选） |

### 目标表（文案收录表，同「抖音文案获取_存入飞书」）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| 视频名称 | 文本（主字段） | 视频标题 |
| 视频链接 | 超链接 | 视频来源链接（如有） |
| 品类 | 文本 | AI 自动识别，格式为 `一级 > 二级 > 三级` |
| 原始文案 | 长文本 | 语音转写原文 |
| 语义分段 | 长文本 | 分段后的结构化文案 |
| 爆款逻辑解析 | 长文本 | 9维度深度拆解 |

## 技术细节

- **FFmpeg 路径**：`/Users/Zhuanz/WorkBuddy/20260421110229/venv/lib/python3.12/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1`（已硬编码）
- **视频下载目录**：`/tmp/douyin-download-lark/`（macOS 重启后自动清理）
- **飞书附件下载**：通过 `batch_get_tmp_download_url` API 获取临时链接，再用 `curl -L` 下载
- **批量限流**：每条记录处理后间隔 1 秒，避免 API 限流
- **跳过已处理**：视频文件已存在于本地时自动跳过下载步骤
- **智能字段匹配**：自动查找「视频文件」附件字段和「视频名称」字段
