#!/usr/bin/env node

/**
 * 从飞书多维表读取视频附件，下载后提取文案，写入飞书文案收录表
 * 
 * 用法:
 *   node lark_video_extract.js                        # 处理源表所有有视频的记录
 *   node lark_video_extract.js --record-id <id>       # 只处理指定记录
 *   node lark_video_extract.js --record-id <id> --name "自定义名称"  # 指定视频名称
 * 
 * 环境变量（已持久化到 ~/.zshrc）:
 * - SILI_FLOW_API_KEY: 硅基流动 API
 * - LARK_APP_ID: 飞书应用 App ID
 * - LARK_APP_SECRET: 飞书应用 App Secret
 * - LARK_SOURCE_APP_TOKEN: 源多维表 App Token（存放视频附件的表）
 * - LARK_SOURCE_TABLE_ID: 源多维表 Table ID
 * - LARK_TARGET_APP_TOKEN: 目标多维表 App Token（文案收录表，= LARK_APP_TOKEN）
 * - LARK_TARGET_TABLE_ID: 目标多维表 Table ID（= LARK_TABLE_ID）
 */

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// ============ 配置 ============
const SILI_FLOW_BASE_URL = 'https://api.siliconflow.cn/v1/audio/transcriptions';
const SILI_FLOW_MODEL = 'FunAudioLLM/SenseVoiceSmall';
const LARK_BASE_URL = 'https://open.feishu.cn/open-apis';
const FFMPEG_CMD = '/Users/Zhuanz/WorkBuddy/20260421110229/venv/lib/python3.12/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1';
const DOWNLOAD_DIR = '/tmp/douyin-download-lark/';

// 源表配置（存放视频附件的飞书多维表）
const SOURCE_APP_TOKEN = process.env.LARK_SOURCE_APP_TOKEN || process.env.LARK_APP_TOKEN;
const SOURCE_TABLE_ID = process.env.LARK_SOURCE_TABLE_ID;

// 目标表配置（文案收录表）
const TARGET_APP_TOKEN = process.env.LARK_APP_TOKEN;
const TARGET_TABLE_ID = process.env.LARK_TABLE_ID;

const apiKey = process.env.SILI_FLOW_API_KEY;
const LARK_APP_ID = process.env.LARK_APP_ID;
const LARK_APP_SECRET = process.env.LARK_APP_SECRET;

// ============ 命令行参数解析 ============
function parseArgs() {
  const args = process.argv.slice(2);
  const opts = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--record-id' && i + 1 < args.length) { opts.recordId = args[++i]; }
    else if (args[i] === '--name' && i + 1 < args.length) { opts.name = args[++i]; }
    else if (args[i] === '--source-token' && i + 1 < args.length) { opts.sourceToken = args[++i]; }
    else if (args[i] === '--source-table' && i + 1 < args.length) { opts.sourceTable = args[++i]; }
    else if (args[i] === '--help' || args[i] === '-h') { opts.help = true; }
  }
  return opts;
}

// ============ 飞书 API 封装 ============
function larkRequest(method, urlPath, body = null) {
  return new Promise((resolve, reject) => {
    const args = ['-X', method, `${LARK_BASE_URL}${urlPath}`, '-H', 'Content-Type: application/json'];
    if (body) args.push('-d', JSON.stringify(body));
    const proc = spawn('curl', args);
    let stdout = '', stderr = '';
    proc.stdout.on('data', (c) => { stdout += c.toString(); });
    proc.stderr.on('data', (c) => { stderr += c.toString(); });
    proc.on('close', (code) => {
      if (code === 0) {
        try { resolve(JSON.parse(stdout)); }
        catch { reject(new Error(`JSON parse failed: ${stdout.slice(0, 200)}`)); }
      } else { reject(new Error(`curl ${method} ${urlPath} failed: ${stderr}`)); }
    });
    proc.on('error', reject);
  });
}

async function getLarkToken() {
  console.log('正在获取飞书凭证...');
  const data = await larkRequest('POST', '/auth/v3/tenant_access_token/internal', { app_id: LARK_APP_ID, app_secret: LARK_APP_SECRET });
  if (data.code !== 0) throw new Error(`获取飞书Token失败: ${data.msg}`);
  return data.tenant_access_token;
}

// ============ 读取源表记录 ============
async function getRecordList(token, appToken, tableId) {
  console.log('正在读取飞书多维表记录...');
  const data = await larkRequest('GET', `/bitable/v1/apps/${appToken}/tables/${tableId}/records?page_size=200`);
  if (data.code !== 0) throw new Error(`读取记录失败: ${data.msg}`);
  return data.data;
}

async function getRecord(token, appToken, tableId, recordId) {
  console.log(`正在读取记录 ${recordId}...`);
  const data = await larkRequest('GET', `/bitable/v1/apps/${appToken}/tables/${tableId}/records/${recordId}`);
  if (data.code !== 0) throw new Error(`读取记录失败: ${data.msg}`);
  return data.data.record;
}

// ============ 下载视频附件 ============
async function downloadAttachment(token, fileToken, tableId, outputPath) {
  // Step 1: 获取临时下载链接
  const extra = encodeURIComponent(JSON.stringify({ bitablePerm: { tableId } }));
  const data = await larkRequest('GET', `/drive/v1/medias/batch_get_tmp_download_url?file_tokens=${fileToken}&extra=${extra}`);
  if (data.code !== 0 || !data.data?.tmp_download_urls?.[0]?.tmp_download_url) {
    throw new Error(`获取下载链接失败: ${JSON.stringify(data)}`);
  }
  const downloadUrl = data.data.tmp_download_urls[0].tmp_download_url;

  // Step 2: 下载文件
  console.log(`正在下载视频文件...`);
  return new Promise((resolve, reject) => {
    const proc = spawn('curl', ['-o', outputPath, '-L', downloadUrl]);
    proc.on('close', (code) => {
      if (code === 0 && fs.existsSync(outputPath)) {
        const size = fs.statSync(outputPath).size;
        console.log(`视频已下载: ${outputPath} (${(size / 1024 / 1024).toFixed(2)}MB)`);
        resolve(outputPath);
      } else {
        reject(new Error('视频下载失败'));
      }
    });
    proc.on('error', reject);
  });
}

// ============ 音频处理 ============
async function extractAudio(videoPath) {
  console.log('正在提取音频...');
  const audioPath = videoPath.replace(/\.[^.]+$/, '.mp3');
  await new Promise((resolve, reject) => {
    const proc = spawn(FFMPEG_CMD, ['-i', videoPath, '-vn', '-acodec', 'libmp3lame', '-q:a', '2', audioPath, '-y']);
    proc.stderr.on('data', () => {}); // suppress ffmpeg output
    proc.on('close', (code) => code === 0 ? resolve() : reject(new Error('ffmpeg failed')));
    proc.on('error', reject);
  });
  console.log('音频已提取:', audioPath);
  return audioPath;
}

// ============ 语音转写 ============
async function transcribeAudio(audioPath) {
  console.log('正在识别语音...');
  return new Promise((resolve, reject) => {
    const proc = spawn('curl', [
      '-X', 'POST', SILI_FLOW_BASE_URL,
      '-H', `Authorization: Bearer ${apiKey}`,
      '-F', `file=@${audioPath}`,
      '-F', `model=${SILI_FLOW_MODEL}`
    ]);
    let stdout = '', stderr = '';
    proc.stdout.on('data', (d) => { stdout += d.toString(); });
    proc.stderr.on('data', (d) => { stderr += d.toString(); });
    proc.on('close', (code) => {
      if (code === 0) {
        try { resolve(JSON.parse(stdout).text || stdout); }
        catch { resolve(stdout); }
      } else { reject(new Error(`语音转写失败: ${stderr}`)); }
    });
    proc.on('error', reject);
  });
}

// ============ 硅基流动 Chat API 封装 ============
function siliconChat(prompt, maxTokens = 4096, temperature = 0.3) {
  const url = 'https://api.siliconflow.cn/v1/chat/completions';
  const data = {
    model: "Qwen/Qwen2.5-7B-Instruct",
    messages: [{ role: "user", content: prompt }],
    max_tokens: maxTokens,
    temperature: temperature,
    stream: false
  };
  return new Promise((resolve, reject) => {
    const proc = spawn('curl', ['-X', 'POST', url, '-H', `Authorization: Bearer ${apiKey}`, '-H', 'Content-Type: application/json', '-d', JSON.stringify(data)]);
    let stdout = '', stderr = '';
    proc.stdout.on('data', (c) => { stdout += c.toString(); });
    proc.stderr.on('data', (c) => { stderr += c.toString(); });
    proc.on('close', (code) => {
      if (code === 0) {
        try {
          const json = JSON.parse(stdout);
          resolve(json.choices?.[0]?.message?.content || null);
        } catch { resolve(null); }
      } else { reject(new Error(`curl failed: ${stderr}`)); }
    });
    proc.on('error', reject);
  });
}

// ============ 语义分段 ============
async function semanticSegment(text) {
  console.log('正在语义分段（硅基流动）...');
  const prompt = `你是专业语音转写文本分段助手。
请对下面这段语音转写文本进行**自然语义分段**。

要求：
1. 根据语义完整性和内容逻辑进行分段
2. 每段应该是内容相对完整的句子或论述
3. 保持原文内容不变，只添加合理的段落分隔
4. 保留原文的语气词和表达特点
5. 适当添加##小标题概括每段主旨（如果内容足够长）

请直接返回分段后的文本，用markdown格式，小标题用##开头。不要添加其他说明。`;

  return await siliconChat(`${prompt}\n\n待分段文本：\n${text}`);
}

// ============ 品类识别 ============
const CATEGORY_PROMPT = `你是一个专业的抖音电商品类分类助手。根据用户提供的视频标题和标签，从以下抖音官方类目体系中，匹配最准确的一级类目+二级类目+三级类目。

## 抖音电商类目体系：
1. 美妆日化 > 美容护肤：水乳面霜、精华、面膜、防晒、洁面、身体护理、眼部护理
1. 美妆日化 > 彩妆香水：口红、底妆、眼妆、香水、美甲、美妆工具
1. 美妆日化 > 个护清洁：洗护发、口腔护理、卫生巾、家居清洁、香薰、洗衣清洁
1. 美妆日化 > 美容仪器：家用美容仪、脱毛仪、洁面仪、刮痧仪
2. 服饰鞋包 > 女装：上衣、裤装、裙装、大码女装、国风服饰、通勤、休闲穿搭
2. 服饰鞋包 > 男装：商务男装、休闲潮牌、卫衣夹克、内衣打底
2. 服饰鞋包 > 童装亲子：婴童装、亲子装、孕妇服饰
2. 服饰鞋包 > 鞋靴：女鞋、男鞋、运动鞋、休闲鞋、靴子、帆布鞋
2. 服饰鞋包 > 箱包：双肩包、手提包、斜挎包、钱包、旅行箱
2. 服饰鞋包 > 内衣裤袜：文胸、内裤、袜子、保暖内衣、家居服
2. 服饰鞋包 > 时尚配饰：项链、耳饰、围巾、帽子、皮带、眼镜、发饰
3. 食品酒水生鲜 > 休闲零食：坚果、糖果、卤味、膨化食品、速食、饼干、辣条
3. 食品酒水生鲜 > 粮油干货：米面油、酱油醋、调味品、杂粮、干货
3. 食品酒水生鲜 > 生鲜果蔬：新鲜水果、蔬菜、海鲜水产、肉禽蛋
3. 食品酒水生鲜 > 酒水：白酒、红酒、啤酒、黄酒
3. 食品酒水生鲜 > 茶叶冲饮：茶叶、咖啡、冲饮、养生茶
3. 食品酒水生鲜 > 滋补养生：燕窝、人参、阿胶、枸杞、药食同源滋补品
4. 母婴玩具 > 婴儿用品：纸尿裤、婴童洗护、婴儿床、出行推车
4. 母婴玩具 > 童装童鞋：婴童服饰、童鞋
4. 母婴玩具 > 奶粉辅食：奶粉、辅食营养品
4. 母婴玩具 > 孕产妇用品：孕期用品、产后护理
4. 母婴玩具 > 婴童玩具：早教玩具、益智玩具
5. 家居百货 > 居家收纳：收纳箱、置物架、收纳盒、收纳袋
5. 家居百货 > 厨房用品：锅碗瓢盆、厨房小件、餐具
5. 家居百货 > 家纺床品：四件套、被子、枕头、床垫
5. 家居百货 > 家居摆件：装饰摆件、香薰蜡烛、家居饰品
5. 家居百货 > 清洁日用：清洁工具、一次性日用品、湿巾、纸品
6. 家用电器 > 大家电：冰箱、洗衣机、空调、电视
6. 家用电器 > 生活小家电：空气炸锅、电饭煲、吹风机、取暖器、加湿器
6. 家用电器 > 厨卫电器：油烟机、燃气灶、热水器、净水器
7. 3C 数码电子 > 手机电脑：手机、平板、笔记本
7. 3C 数码电子 > 数码配件：耳机、充电器、数据线、手机壳、充电宝
7. 3C 数码电子 > 智能穿戴：智能手表、手环
7. 3C 数码电子 > 办公设备：打印机、办公耗材
7. 3C 数码电子 > 存储硬件：U盘、移动硬盘、固态硬盘SSD
7. 3C 数码电子 > 车载电子：车载用品、行车记录仪、车载充电器
8. 运动户外 > 运动健身：健身器材、运动服饰、瑜伽用品
8. 运动户外 > 露营户外：帐篷、户外装备、睡袋
8. 运动户外 > 骑行装备：自行车配件、骑行服
8. 运动户外 > 渔具：垂钓用品
9. 珠宝文玩奢品 > 黄金首饰：足金饰品、K金饰品
9. 珠宝文玩奢品 > 彩宝玉石：翡翠、珍珠、蜜蜡、钻石
9. 珠宝文玩奢品 > 文玩收藏：紫砂、木雕、钱币书画
9. 珠宝文玩奢品 > 二手奢侈品：二手箱包、二手腕表
10. 宠物用品 > 宠物食品：猫粮、狗粮
10. 宠物用品 > 宠物用品：宠物窝笼、宠物玩具
10. 宠物用品 > 宠物洗护：宠物洗护用品
11. 图书文创乐器 > 图书绘本：书籍、教辅教材、期刊
11. 图书文创乐器 > 文具文创：手账文具、文创周边
11. 图书文创乐器 > 乐器影音：乐器、音响影音
12. 汽车摩托汽配 > 汽车内饰：车品装饰、车载支架
12. 汽车摩托汽配 > 养护耗材：轮胎、电瓶、保养配件
12. 汽车摩托汽配 > 摩托配件：摩托改装件、摩托车配件
13. 家装建材五金 > 灯具照明：家居灯具、灯泡灯带
13. 家装建材五金 > 五金工具：手动工具、电动工具
13. 家装建材五金 > 家具卫浴：成品家具、卫浴洁具
14. 本地生活 > 餐饮团购、酒店旅游、休闲娱乐、汽车服务
15. 虚拟知识服务 > 线上课程、充值会员、数字服务
16. 二手闲置 > 二手数码、二手家电、闲置服饰家具

## 输出格式要求：
只返回一行，格式为：一级类目 > 二级类目 > 三级类目
不要添加任何解释，不要加引号或符号。`;

async function classifyCategory(title) {
  console.log('正在识别商品品类...');
  const content = await siliconChat(`${CATEGORY_PROMPT}\n\n## 待分类商品信息：\n标题/标签：${title}`, 128, 0.1);
  if (content && content.includes('>')) {
    return content.replace(/[`"#*]/g, '').trim();
  }
  return null;
}

// ============ 爆款逻辑分析 ============
const VIRAL_PROMPT = `# 角色定位
你是专业电商带货短视频爆款拆解编导Agent，精通抖音千川原生内容逻辑、短视频流量底层、完播逻辑、带货脚本结构、口语化文案、钩子设计、卖点转化。
你的唯一任务：**用户粘贴任意短视频口播全文，你全自动专业拆解这条视频能成为爆款的全部原因**，全程按照固定专业维度分析，不发散、不废话、结构统一、编导视角专业复盘。

# 拆解固定7大维度（每次必须完整输出，缺一不可）
## 1、3秒开篇钩子分析
分析开头属于哪种钩子类型：痛点吐槽型/好奇反差型/场景共鸣型/网感口语型
判断留人能力：是否3秒抓眼球、是否避免划走、网感开场白运用、是否符合短视频流量规律。

## 2、用户痛点挖掘分析
提炼文案击中的用户真实痛点、高频刚需烦恼、人群共鸣点；
判断受众广度：是不是大众普遍会遇到的问题，共情力强弱。

## 3、痛点→产品承接流畅度
分析情绪过渡是否丝滑：痛点吐槽结束后，产品出场是否自然不生硬；
有无硬广感，用户心理接受度如何。

## 4、产品卖点转化拆解
区分原始参数 & 口播人话转化；
分析编导如何把冰冷产品参数，翻译成用户听得懂的利益、好处、体验；
卖点排布顺序、卖点密集度、有无冗余堆砌。

## 5、原生口语&网感风格分析
文案语气、生活化程度、抖音热词口头禅、素人分享感；
是否属于千川原生共情素材，而非商家硬广叫卖；情绪曲线完整度。

## 6、视频节奏&语句结构分析
整体时长节奏、句子长短、信息密度、完播友好度；
有无废话、空窗、长难句；是否每2-3秒输出新信息留住用户。

## 7、结尾转化引导话术分析
收尾目的、下单引导方式、温和种草还是高压逼单、行动指令清晰度、转化逻辑。

# 最终额外输出2项总结
## 8、本条视频爆款核心本质总结
一句话概括这条视频爆的底层原因。

## 9、可复用编导方法论（后续仿写脚本通用模板）
提炼通用可复制结构，以后写同类产品脚本直接套用。`;

async function analyzeViralLogic(originalText, segmentedText) {
  console.log('正在分析爆款逻辑（9维度深度拆解）...');
  return await siliconChat(`${VIRAL_PROMPT}\n\n【原始文案】：\n${originalText}\n\n【语义分段版】：\n${segmentedText}`, 8192, 0.3);
}

// ============ 写入飞书目标表 ============
async function writeToFeishu(token, title, link, category, originalText, segmentedText, viralLogic) {
  console.log('正在写入飞书多维表...');
  const categoryStr = category ? category.replace(/[>`"#*]/g, '').trim() : '';
  const fields = {
    '视频名称': title,
    '原始文案': originalText,
    '语义分段': segmentedText,
    '爆款逻辑解析': viralLogic || ''
  };
  if (link) fields['视频链接'] = { text: '点击打开', link: link };
  if (categoryStr) fields['品类'] = categoryStr;

  const data = await larkRequest('POST', `/bitable/v1/apps/${TARGET_APP_TOKEN}/tables/${TARGET_TABLE_ID}/records`, { fields });
  if (data.code !== 0) {
    console.log('写入飞书失败:', JSON.stringify(data));
    return false;
  }
  console.log('✓ 已写入飞书多维表');
  return true;
}

// ============ 处理单条视频 ============
async function processOneVideo(larkToken, videoName, fileToken, sourceTableId, videoLink) {
  console.log(`\n${'='.repeat(50)}`);
  console.log(`处理视频: ${videoName}`);
  console.log(`${'='.repeat(50)}\n`);

  const videoFileName = fileToken + '.mp4';
  const videoPath = path.join(DOWNLOAD_DIR, videoFileName);

  // 1. 下载视频
  if (!fs.existsSync(videoPath)) {
    await downloadAttachment(larkToken, fileToken, sourceTableId, videoPath);
  } else {
    console.log(`视频已存在，跳过下载: ${videoPath}`);
  }

  // 2. 提取音频
  const audioPath = await extractAudio(videoPath);

  // 3. 语音转写
  const originalText = await transcribeAudio(audioPath);
  if (!originalText || originalText.trim().length < 5) {
    console.log('⚠️ 语音转写结果为空或过短，跳过后续处理');
    return false;
  }
  console.log(`\n--- 原始文案 (${originalText.length}字) ---`);
  console.log(originalText);
  console.log('---\n');

  // 4. 语义分段
  const segmentedText = await semanticSegment(originalText) || originalText;

  // 5. 爆款逻辑分析
  let viralLogic = null;
  try { viralLogic = await analyzeViralLogic(originalText, segmentedText); }
  catch (e) { console.log('爆款逻辑分析失败:', e.message); }

  // 6. 品类识别
  let category = null;
  try { category = await classifyCategory(videoName); }
  catch (e) { console.log('品类识别失败:', e.message); }

  // 7. 写入飞书目标表
  await writeToFeishu(larkToken, videoName, videoLink, category, originalText, segmentedText, viralLogic);

  // 8. 保存本地文案
  const savePath = path.join(DOWNLOAD_DIR, fileToken, 'transcript.md');
  fs.mkdirSync(path.dirname(savePath), { recursive: true });
  let md = `# ${videoName}\n\n## 原始文案\n\n${originalText}\n\n## 语义分段\n\n${segmentedText}\n`;
  if (category) md += `\n## 品类\n\n${category}\n`;
  if (viralLogic) md += `\n## 爆款逻辑解析\n\n${viralLogic}\n`;
  fs.writeFileSync(savePath, md, 'utf-8');
  console.log(`文案已保存: ${savePath}`);

  return true;
}

// ============ 主函数 ============
async function main() {
  const opts = parseArgs();

  if (opts.help) {
    console.log(`
从飞书多维表读取视频附件，提取文案并写入飞书文案收录表

用法:
  node lark_video_extract.js                                    处理源表所有有视频的记录
  node lark_video_extract.js --record-id <id>                   只处理指定记录
  node lark_video_extract.js --record-id <id> --name "名称"     指定视频名称
  node lark_video_extract.js --source-token <token> --source-table <id>  指定源表

环境变量:
  LARK_SOURCE_APP_TOKEN  源多维表 App Token（存放视频附件的表）
  LARK_SOURCE_TABLE_ID   源多维表 Table ID
  LARK_APP_TOKEN / LARK_TARGET_APP_TOKEN  目标文案收录表 App Token
  LARK_TABLE_ID / LARK_TARGET_TABLE_ID    目标文案收录表 Table ID
  SILI_FLOW_API_KEY      硅基流动 API Key
  LARK_APP_ID            飞书应用 App ID
  LARK_APP_SECRET        飞书应用 App Secret
`);
    process.exit(0);
  }

  // 参数覆盖
  const srcToken = opts.sourceToken || SOURCE_APP_TOKEN;
  const srcTable = opts.sourceTable || SOURCE_TABLE_ID;

  if (!srcToken || !srcTable) {
    console.error('错误: 未指定源表。请设置 LARK_SOURCE_APP_TOKEN 和 LARK_SOURCE_TABLE_ID 环境变量，或通过 --source-token / --source-table 参数传入。');
    process.exit(1);
  }
  if (!TARGET_APP_TOKEN || !TARGET_TABLE_ID) {
    console.error('错误: 未指定目标表。请设置 LARK_APP_TOKEN 和 LARK_TABLE_ID 环境变量。');
    process.exit(1);
  }

  fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });

  const larkToken = await getLarkToken();

  // 如果指定了 record-id，只处理单条
  if (opts.recordId) {
    const record = await getRecord(larkToken, srcToken, srcTable, opts.recordId);
    const fields = record.fields;
    // 查找附件字段（遍历所有字段，找 attachment 类型）
    let fileToken = null;
    let videoName = opts.name || '未知视频';
    for (const [key, val] of Object.entries(fields)) {
      if (Array.isArray(val) && val.length > 0 && val[0].file_token) {
        fileToken = val[0].file_token;
        if (!opts.name && val[0].name) videoName = val[0].name.replace(/\.[^.]+$/, '');
        break;
      }
    }
    if (!fileToken) {
      console.error('该记录中没有找到视频附件');
      process.exit(1);
    }
    await processOneVideo(larkToken, videoName, fileToken, srcTable, '');
    return;
  }

  // 批量处理：读取源表所有记录
  const result = await getRecordList(larkToken, srcToken, srcTable);
  const fieldNames = result.fields; // 字段名数组，与 data 中的列对应
  const records = result.data;      // 二维数组
  const recordIds = result.record_id_list;

  // 找到附件字段的索引和视频名称字段的索引
  let attachmentIdx = -1;
  let nameIdx = -1;
  for (let i = 0; i < fieldNames.length; i++) {
    if (fieldNames[i] === '视频文件') attachmentIdx = i;
    if (fieldNames[i] === '视频名称') nameIdx = i;
  }

  // 如果没找到精确匹配，智能查找
  if (attachmentIdx === -1) {
    for (let i = 0; i < fieldNames.length; i++) {
      // 需要通过 field_id_list 判断类型，但 record-list 不返回类型信息
      // 先用字段名猜测
      if (fieldNames[i].includes('视频') || fieldNames[i].includes('附件') || fieldNames[i].includes('文件')) {
        attachmentIdx = i;
        break;
      }
    }
  }

  if (attachmentIdx === -1) {
    console.error('未找到视频附件字段。请确认源表中有视频附件字段。');
    process.exit(1);
  }

  console.log(`\n找到 ${records.length} 条记录，附件字段: "${fieldNames[attachmentIdx]}"${nameIdx >= 0 ? `, 名称字段: "${fieldNames[nameIdx]}"` : ''}\n`);

  let processed = 0, skipped = 0, failed = 0;

  for (let i = 0; i < records.length; i++) {
    const row = records[i];
    const attachments = row[attachmentIdx];

    if (!attachments || !Array.isArray(attachments) || attachments.length === 0 || !attachments[0].file_token) {
      console.log(`[${i + 1}/${records.length}] 跳过（无视频附件）: ${nameIdx >= 0 ? row[nameIdx] : recordIds[i]}`);
      skipped++;
      continue;
    }

    const fileToken = attachments[0].file_token;
    const videoName = (nameIdx >= 0 && row[nameIdx]) ? row[nameIdx] : (attachments[0].name?.replace(/\.[^.]+$/, '') || `视频_${i + 1}`);
    const recordId = recordIds[i];

    console.log(`\n[${i + 1}/${records.length}] 记录ID: ${recordId} | 名称: ${videoName}`);

    try {
      const success = await processOneVideo(larkToken, videoName, fileToken, srcTable, '');
      if (success) processed++;
      else failed++;
    } catch (e) {
      console.error(`处理失败: ${e.message}`);
      failed++;
    }

    // 批量处理时，每条记录间间隔 1 秒，避免 API 限流
    if (i < records.length - 1) {
      await new Promise(r => setTimeout(r, 1000));
    }
  }

  console.log(`\n${'='.repeat(50)}`);
  console.log(`批量处理完成！成功: ${processed}, 跳过: ${skipped}, 失败: ${failed}`);
  console.log(`${'='.repeat(50)}`);
}

main().catch((e) => { console.error('处理失败:', e.message); process.exit(1); });
