# 数据脱敏规则参考手册 (v3)

## 一、内置默认隐私规则

以下规则在**文本脱敏模式**和**文本值正则扫描**下自动生效，无需用户手动指定。

| 规则名称 | 识别方式 | 默认策略 | 示例（脱敏前 → 后） |
|---------|---------|---------|-----------------|
| 手机号 | 正则：1[3-9]\d{9} | mask(前3后4) | 13812345678 → 138****5678 |
| 身份证号 | 正则：18位标准格式 | mask(前4后4) | 110101199001011234 → 1101**********1234 |
| 邮箱 | 正则：xxx@xxx.com | email_mask | user@example.com → u***@e***.com |
| 银行卡号 | 正则：3-6开头16-19位 | mask(前4后4) | 6222021234567890 → 6222********7890 |
| IPv4地址 | 正则：标准IPv4 | mask(全掩) | 192.168.1.100 → ************* |
| 中文姓名 | 正则：姓名：XX | name_mask | 姓名：张三 → 姓名：张* |
| 家庭住址 | 正则：地址：XXXX | mask(前3) | 地址：上海市浦东新区XX路 → 地址：上海市*** |
| Token/Key | 正则：token=XXXX | mask(前4) | token=abcdefgh → token=abcd*** |

---

## 二、脱敏策略说明

| 策略名 | 说明 | 适用场景 |
|-------|------|---------|
| `mask` | 中间替换为 `*`，可保留前N和后N位 | 手机号、身份证、银行卡 |
| `email_mask` | 邮箱专用：本地名首字保留 + *** | 邮箱地址 |
| `name_mask` | 姓名专用：姓保留 + *（中文宽度感知） | 中文姓名 |
| `hash` | SHA256 截取前16位 | 需要可验证唯一性（如用户ID对比） |
| `remove` | 替换为 `[REDACTED]` | 密码、密钥等敏感凭证 |
| `keep_prefix` | 仅保留前N位，其余掩码 | 地址、组织名称 |

> **v3 新增**：策略注册表（StrategyRegistry）支持运行时注册自定义策略。调用 `STRATEGY_REGISTRY.register(name, fn)` 即可扩展，无需修改核心代码。

---

## 三、字段名自动识别关键词

在结构化数据（JSON/CSV/YAML/XML/INI/Properties）模式下，以下关键词会触发对应字段的自动脱敏（大小写不敏感，支持部分匹配）：

### 隐私类
```
phone / mobile / tel / 手机 / 电话          → mask
email / mail / 邮箱 / 邮件                  → email_mask  
id_card / idcard / 身份证 / identity        → mask
name / username / 姓名 / 用户名              → name_mask
address / addr / 地址 / 住址                → mask
```

### 金融类
```
bank / card / 银行卡 / account / 账号        → mask
salary / 薪资 / 收入                        → mask
```

### 凭证类（高危）
```
password / passwd / pwd / 密码              → remove
secret / token / api_key / apikey           → remove
```

### 其他
```
ip                                          → mask
birthday / birth / 生日 / 出生              → mask
```

---

## 四、多格式处理说明

### 纯文本（.txt / 字符串）
- 使用正则扫描全文
- 所有内置规则自动启用
- 可追加自定义字段关键词正则

### JSON（.json）
- 递归遍历所有层级的 key-value
- **双重脱敏**：字段名匹配 + 文本值正则扫描
- **格式保持**：单行 JSON 输出仍为单行，多行缩进 JSON 保持缩进
- **空值保护**：`""` 和 `null` 不触发脱敏
- 支持嵌套对象和数组
- 用 `--no-regex` 关闭文本值正则扫描

### CSV（.csv）
- 读取表头，根据列名匹配规则
- 逐行处理，保持原始结构
- 支持文本值正则扫描

### TSV（.tsv）
- 与 CSV 相同逻辑，分隔符为制表符

### YAML（.yaml / .yml）
- 纯 Python 行级解析，无需 PyYAML 依赖
- **v3 新增**：引号包裹保留（`"secret"` → `"[REDACTED]"`）
- **v3 新增**：列表项值脱敏（`- 手机13812345678`）
- **v3 新增**：中文 key 支持（`用户:`）
- 保留原始空格缩进
- 支持行尾注释保留
- **限制**：不支持多行字符串折叠、锚点引用等高级特性

### XML（.xml）
- **v3 增强**：标签名匹配（`<password>secret</password>` → `<password>[REDACTED]</password>`）
- 同时处理**标签属性**和**标签文本内容**
- **v3 修复**：属性引号类型保留（双引号/单引号）
- 属性匹配：`<user phone="13812345678"/>` → `phone` 字段命中
- **限制**：使用正则解析，超复杂嵌套结构（如 SOAP/CDATA）建议文本模式

### Markdown（.md / .markdown）
- **智能分区**：代码块（围栏 ```和行内 `）保留原样
- 正文区域正常正则扫描
- 标题、列表、链接等 Markdown 语法不受影响

### INI（.ini / .cfg）
- section/key=value 格式识别
- **v3 修复**：保留原始分隔符（`=` 或 `:`）
- 保留注释和空行
- 支持行尾注释

### Properties（.properties）
- Java 属性文件格式
- 支持 # 和 ! 开头的注释行
- key=value 和 key:value 两种分隔符
- **v3 优化**：与 INI 共享基类，逻辑统一

### 日志（.log / .out）
- 逐行正则扫描，保留完整日志格式
- **v3 修复**：custom_fields 逻辑修复，不再遗漏自定义字段扫描
- 时间戳、日志级别、线程名等结构信息不受影响
- 仅脱敏值中的隐私信息

---

## 五、自定义字段配置格式

### CLI 参数格式（--fields）
```bash
# 单字段默认策略（mask）
--fields "phone"

# 多字段，混合策略
--fields "phone:mask,email:email_mask,password:remove"

# 中文字段名
--fields "手机号,姓名:name_mask"

# 配置文件场景
--fields "db_password:remove,api_key:remove,secret_token:hash"
```

### 在对话中指定（自然语言）
用户可以用自然语言告知需要脱敏的字段：

- "帮我脱敏 phone 和 email 字段"
- "把 JSON 里的 `user_name`、`id_card`、`password` 字段脱敏"
- "对 CSV 中的姓名列用 name_mask，手机列用 mask"
- "还需要把 `company_secret` 字段移除"
- "YAML 里的 database.password 要脱敏"

---

## 六、脱敏效果示例

### 示例1：自由文本脱敏
**输入：**
```
客户张三，手机：13812345678，身份证：110101199001011234，
邮箱：zhangsan@company.com，地址：上海市浦东新区张江路123号
```

**输出：**
```
客户张*，手机：138****5678，身份证：1101**********1234，
邮箱：z***@c***.com，地址：上海市***
```

---

### 示例2：JSON 字段 + 文本值双重脱敏 + 格式保持
**输入（单行）：**
```json
{"name":"李四","phone":"13999998888","note":"手机13812345678"}
```

**输出（保持单行）：**
```json
{"name":"李*","phone":"139****8888","note":"手机138****5678"}
```

---

### 示例3：YAML 配置脱敏（引号保留）
**输入：**
```yaml
database:
  password: "MyS3cretP@ss"
  api_key: 'ak-abcdef1234567890'
用户:
  - 手机13812345678
```

**输出：**
```yaml
database:
  password: "[REDACTED]"
  api_key: '[REDACTED]'
用户:
  - 手机138****5678
```

---

### 示例4：XML 脱敏（标签名匹配）
**输入：**
```xml
<user name="张三" phone="13812345678">
  <password>db_secret_123</password>
</user>
```

**输出：**
```xml
<user name="张*" phone="138****5678">
  <password>[REDACTED]</password>
</user>
```

---

### 示例5：INI 配置脱敏（分隔符保留）
**输入：**
```ini
[database]
host = 192.168.1.100
port: 3306
password = MyS3cretP@ss
```

**输出：**
```ini
[database]
host = *************
port: 3306
password = [REDACTED]
```

---

### 示例6：Markdown 脱敏（代码块保护）
**输入：**
```markdown
请联系张三，手机：13812345678

```python
phone = "13812345678"  # 代码不脱敏
```
```

**输出：**
```markdown
请联系张三，手机：138****5678

```python
phone = "13812345678"  # 代码不脱敏
```
```

---

### 示例7：日志文件脱敏
**输入：**
```
2026-04-24 10:30:00 INFO User login: phone=13812345678, ip=192.168.1.100
2026-04-24 10:32:00 DEBUG api_key=sk-abc123xyz456
```

**输出：**
```
2026-04-24 10:30:00 INFO User login: phone=138****5678, ip=*************
2026-04-24 10:32:00 DEBUG api_key=sk-a***********
```

---

### 示例8：CSV 字段脱敏
**输入：**
```csv
姓名,手机号,邮箱,密码
王五,13711112222,wangwu@test.com,secret123
```

**输出：**
```csv
姓名,手机号,邮箱,密码
王*,137****2222,w***@t***.com,[REDACTED]
```

---

## 七、v3 架构变更

### 策略注册表（StrategyRegistry）
```python
# 注册自定义策略
STRATEGY_REGISTRY.register("custom_mask", lambda value, **kw: "CUSTOM")

# 应用策略
STRATEGY_REGISTRY.apply("custom_mask", "any_value")
```

### FormatEngine 抽象层
每种格式只需实现 `parse / apply / serialize` 三步，脱敏逻辑统一调度。

### _KvLineEngine 基类
INI 和 Properties 共享基类，消除 80% 代码重复。子类只需定义 `comment_chars` 和 `kv_pattern`。

---

## 八、注意事项

1. **脱敏不可逆**：默认 mask/remove 策略不可还原，如需可逆请使用 hash + 密钥加密（需额外实现）
2. **正则覆盖局限**：文本脱敏依赖正则，非标准格式（如变体写法）可能漏识别，建议结合字段名脱敏
3. **中文姓名识别**：仅识别"姓名：XX"格式，散文中的姓名需通过自定义字段或 NER 扩展
4. **大文件处理**：超过 100MB 的文件建议分批处理，避免内存溢出
5. **编码问题**：脚本默认 UTF-8，处理 GBK 文件需先转码
6. **XML 复杂度**：正则解析的 XML 引擎对超复杂嵌套（如 SOAP/CDATA）可能不准，建议文本模式兜底
7. **YAML 限制**：纯 Python 实现不支持多行字符串折叠、锚点引用、类型标签等高级特性
8. **JSON 双重脱敏**：默认开启文本值正则扫描，用 `--no-regex` 可关闭以仅做字段名匹配
9. **JSON 格式保持**：v3 会根据原始 JSON 是否为单行来决定输出格式
