#!/usr/bin/env python3
"""
data-desensitization: 多格式数据脱敏工具 (v3)
================================================
架构：FormatEngine 抽象层 + StrategyRegistry 策略注册表
每种格式只实现 parse / apply / serialize，脱敏策略统一调度。

支持格式：
  文本(.txt) / JSON(.json) / CSV(.csv) / TSV(.tsv) /
  YAML(.yaml/.yml) / XML(.xml) / Markdown(.md) /
  INI(.ini/.cfg) / Properties(.properties) / Log(.log)

v3 改进：
  - 策略注册表（可插件化扩展新策略）
  - XML 引擎支持标签名匹配
  - YAML 引擎保留引号包裹 + 支持列表项值 + 中文 key
  - INI/Properties 合并为基类 + 保留原始分隔符
  - LogEngine custom_fields 逻辑修复
  - JSON 格式偏好保持（单行/缩进）
  - name_mask 中文宽度感知
"""

import re
import json
import csv
import hashlib
import argparse
import sys
import io
import os
from typing import Any, Dict, List, Optional, Tuple
from abc import ABC, abstractmethod


# ─────────────────────────────────────────────
# 策略注册表（Strategy Registry）
# ─────────────────────────────────────────────

class StrategyRegistry:
    """统一管理所有脱敏策略，支持运行时注册新策略"""

    def __init__(self):
        self._strategies: Dict[str, callable] = {}
        # 注册内置策略
        self.register("mask", self._builtin_mask)
        self.register("email_mask", self._builtin_email_mask)
        self.register("name_mask", self._builtin_name_mask)
        self.register("hash", self._builtin_hash)
        self.register("remove", self._builtin_remove)
        self.register("keep_prefix", self._builtin_keep_prefix)

    def register(self, name: str, fn: callable):
        """注册一个新策略。fn 签名: fn(value, **kwargs) -> str"""
        self._strategies[name] = fn

    def apply(self, strategy: str, value: str, **kwargs) -> str:
        """执行指定策略"""
        fn = self._strategies.get(strategy)
        if fn is None:
            # 未知策略回退到 mask
            fn = self._strategies["mask"]
        return fn(str(value), **kwargs)

    def list_strategies(self) -> List[str]:
        return sorted(self._strategies.keys())

    # ── 内置策略实现 ──

    @staticmethod
    def _builtin_mask(value: str, keep_prefix: int = 3, keep_suffix: int = 4,
                      mask_char: str = "*", **_kwargs) -> str:
        length = len(value)
        if length <= keep_prefix + keep_suffix:
            return mask_char * length
        mid_len = length - keep_prefix - keep_suffix
        return value[:keep_prefix] + mask_char * mid_len + (value[-keep_suffix:] if keep_suffix > 0 else "")

    @staticmethod
    def _builtin_email_mask(value: str, **_kwargs) -> str:
        if "@" not in value:
            return StrategyRegistry._builtin_mask(value)
        local, domain = value.rsplit("@", 1)
        local_masked = local[0] + "***" if len(local) > 1 else "***"
        parts = domain.rsplit(".", 1)
        if len(parts) == 2:
            domain_masked = parts[0][0] + "***." + parts[1] if len(parts[0]) > 1 else "***." + parts[1]
        else:
            domain_masked = "***"
        return f"{local_masked}@{domain_masked}"

    @staticmethod
    def _builtin_name_mask(value: str, **_kwargs) -> str:
        """中文宽度感知的姓名脱敏：保留首字，其余用 * 替换。
        2字名：张*（1个*，视觉宽度=2+1*1=3 不对，用全角*）
        3字名：张**（2个*）
        """
        if not value:
            return "*"
        # 计算显示宽度：CJK 字符宽 2，ASCII 宽 1
        def display_width(ch):
            cp = ord(ch)
            if (0x4E00 <= cp <= 0x9FFF or 0x3400 <= cp <= 0x4DBF or
                0x3000 <= cp <= 0x303F or 0xFF00 <= cp <= 0xFFEF or
                0xF900 <= cp <= 0xFAFF or 0x2E80 <= cp <= 0x2EFF or
                0x3040 <= cp <= 0x309F or 0x30A0 <= cp <= 0x30FF):
                return 2
            return 1

        first = value[0]
        rest = value[1:]
        if not rest:
            return "*"
        # 根据剩余字符的显示宽度决定 * 个数
        # 使用半角 * ，数量 = 剩余字符数（保持字符数一致，视觉上基本对齐）
        return first + "*" * len(rest)

    @staticmethod
    def _builtin_hash(value: str, **_kwargs) -> str:
        return hashlib.sha256(value.encode()).hexdigest()[:16]

    @staticmethod
    def _builtin_remove(_value: str, **_kwargs) -> str:
        return "[REDACTED]"

    @staticmethod
    def _builtin_keep_prefix(value: str, keep_prefix: int = 3, **_kwargs) -> str:
        if len(value) <= keep_prefix:
            return "*" * len(value)
        return value[:keep_prefix] + "*" * (len(value) - keep_prefix)


# 全局策略注册表实例
STRATEGY_REGISTRY = StrategyRegistry()

# 便捷函数
def desensitize_value(value: str, strategy: str, keep_prefix: int = 3, keep_suffix: int = 4) -> str:
    return STRATEGY_REGISTRY.apply(strategy, value, keep_prefix=keep_prefix, keep_suffix=keep_suffix)


# ─────────────────────────────────────────────
# 内置默认脱敏规则（正则 + 策略）
# ─────────────────────────────────────────────

DEFAULT_PATTERNS = {
    "手机号": {
        "regex": r"(?<!\d)(1[3-9]\d{9})(?!\d)",
        "strategy": "mask",
        "keep_prefix": 3,
        "keep_suffix": 4,
    },
    "身份证号": {
        "regex": r"(?<!\d)([1-9]\d{5}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx])(?!\d)",
        "strategy": "mask",
        "keep_prefix": 4,
        "keep_suffix": 4,
    },
    "邮箱": {
        "regex": r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",
        "strategy": "email_mask",
    },
    "银行卡号": {
        "regex": r"(?<!\d)([3-6]\d{15,18})(?!\d)",
        "strategy": "mask",
        "keep_prefix": 4,
        "keep_suffix": 4,
    },
    "IPv4地址": {
        "regex": r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b",
        "strategy": "mask",
        "keep_prefix": 0,
        "keep_suffix": 0,
    },
    "中文姓名": {
        "regex": r"(?:姓名[：:]\s*)([^\s，。、,\n]{2,4})",
        "strategy": "name_mask",
        "group": 1,
    },
    "家庭住址": {
        "regex": r"(?:地址|住址|家庭住址)[：:]\s*([^\n，。]{5,30})",
        "strategy": "mask",
        "keep_prefix": 3,
        "keep_suffix": 0,
        "group": 1,
    },
    "URL中的Token": {
        "regex": r"(?:token|access_token|api_key|secret)[=:]\s*([A-Za-z0-9\-_.~+/]{8,})",
        "strategy": "mask",
        "keep_prefix": 4,
        "keep_suffix": 0,
        "group": 1,
    },
}

# 字段名关键词 → 默认脱敏方式
FIELD_KEYWORD_MAP = {
    "phone": "mask", "mobile": "mask", "tel": "mask",
    "手机": "mask", "电话": "mask",
    "email": "email_mask", "mail": "email_mask",
    "邮箱": "email_mask", "邮件": "email_mask",
    "id_card": "mask", "idcard": "mask", "身份证": "mask", "identity": "mask",
    "name": "name_mask", "姓名": "name_mask", "username": "name_mask", "用户名": "name_mask",
    "address": "mask", "addr": "mask", "地址": "mask", "住址": "mask",
    "bank": "mask", "card": "mask", "银行卡": "mask", "account": "mask", "账号": "mask",
    "password": "remove", "passwd": "remove", "pwd": "remove", "密码": "remove",
    "secret": "remove", "token": "remove", "api_key": "remove", "apikey": "remove",
    "ip": "mask",
    "salary": "mask", "薪资": "mask", "收入": "mask",
    "birthday": "mask", "birth": "mask", "生日": "mask", "出生": "mask",
}


# ─────────────────────────────────────────────
# 通用：字段名匹配策略
# ─────────────────────────────────────────────

def _match_field_strategy(key: str, custom_fields: Optional[Dict[str, str]] = None) -> Optional[str]:
    key_lower = key.lower().strip()
    if custom_fields:
        for field, strat in custom_fields.items():
            f_lower = field.lower().strip()
            if f_lower in key_lower or key_lower in f_lower:
                return strat
    for keyword, strat in FIELD_KEYWORD_MAP.items():
        if keyword in key_lower:
            return strat
    return None


# ─────────────────────────────────────────────
# 通用：文本值正则扫描
# ─────────────────────────────────────────────

def _regex_scan_text(text: str, extra_patterns: Optional[Dict] = None) -> Tuple[str, List[str]]:
    """对一段文本做正则脱敏，返回 (脱敏后文本, 命中列表)"""
    patterns = {**DEFAULT_PATTERNS}
    if extra_patterns:
        patterns.update(extra_patterns)

    result = text
    hits = []

    for rule_name, rule in patterns.items():
        regex = rule["regex"]
        strategy = rule.get("strategy", "mask")
        keep_prefix = rule.get("keep_prefix", 3)
        keep_suffix = rule.get("keep_suffix", 4)
        group = rule.get("group", 0)

        def replacer(m, _rule_name=rule_name, _strategy=strategy, _kp=keep_prefix, _ks=keep_suffix, _g=group):
            matched = m.group(_g) if _g < len(m.groups()) + 1 and _g > 0 else m.group(0)
            desensitized = desensitize_value(matched, _strategy, _kp, _ks)
            if _g and _g > 0:
                full = m.group(0)
                return full.replace(matched, desensitized, 1)
            return desensitized

        new_result, count = re.subn(regex, replacer, result)
        if count > 0:
            hits.append(f"{rule_name}({count}处)")
            result = new_result

    return result, hits


# ─────────────────────────────────────────────
# FormatEngine 抽象层
# ─────────────────────────────────────────────

class FormatEngine(ABC):
    """每种格式的脱敏引擎，只需实现三个方法"""

    @abstractmethod
    def parse(self, content: str) -> Any:
        """将原始文本解析为内部数据结构"""

    @abstractmethod
    def apply(self, data: Any, custom_fields: Optional[Dict[str, str]],
              auto_detect: bool, regex_on_values: bool) -> Tuple[Any, List[str]]:
        """对解析后的数据执行脱敏，返回 (脱敏后数据, 命中列表)"""

    @abstractmethod
    def serialize(self, data: Any) -> str:
        """将脱敏后的数据序列化为文本"""

    def run(self, content: str, custom_fields: Optional[Dict[str, str]] = None,
            auto_detect: bool = True, regex_on_values: bool = True) -> Tuple[str, List[str]]:
        data = self.parse(content)
        masked_data, hits = self.apply(data, custom_fields, auto_detect, regex_on_values)
        return self.serialize(masked_data), hits


# ─────────────────────────────────────────────
# TextEngine
# ─────────────────────────────────────────────

class TextEngine(FormatEngine):
    def parse(self, content: str) -> str:
        return content

    def apply(self, data: str, custom_fields, auto_detect, regex_on_values) -> Tuple[str, List[str]]:
        extra = None
        if custom_fields:
            extra = {}
            for field, strat in custom_fields.items():
                extra[field] = {
                    "regex": rf"(?:{re.escape(field)})[：:=\s]*([^\s，。,\n]{{1,50}})",
                    "strategy": strat,
                    "group": 1,
                }
        return _regex_scan_text(data, extra)

    def serialize(self, data: str) -> str:
        return data


# ─────────────────────────────────────────────
# JSONEngine
# ─────────────────────────────────────────────

class JSONEngine(FormatEngine):
    def __init__(self):
        self._original_compact = None  # 记录原始是否为单行

    def parse(self, content: str) -> Any:
        # 检测原始格式偏好
        self._original_compact = "\n" not in content.strip()
        return json.loads(content)

    def apply(self, data: Any, custom_fields, auto_detect, regex_on_values) -> Tuple[Any, List[str]]:
        return self._walk(data, custom_fields, auto_detect, regex_on_values, "")

    def _walk(self, data, cf, auto, regex, path) -> Tuple[Any, List[str]]:
        hits = []
        if isinstance(data, dict):
            new = {}
            for k, v in data.items():
                if v is None or v == "":
                    new[k] = v
                    continue
                strategy = _match_field_strategy(k, cf) if auto else None
                if not strategy and cf:
                    strategy = _match_field_strategy(k, cf)
                if strategy and isinstance(v, (str, int, float)):
                    new[k] = desensitize_value(str(v), strategy)
                    hits.append(path + k)
                elif isinstance(v, str) and regex and not strategy:
                    masked, rh = _regex_scan_text(v)
                    if rh:
                        new[k] = masked
                        hits.extend([path + k + "|" + h for h in rh])
                    else:
                        new[k] = v
                elif isinstance(v, (str, int, float)):
                    new[k] = v
                else:
                    sub, sh = self._walk(v, cf, auto, regex, path + k + ".")
                    new[k] = sub
                    hits.extend(sh)
            return new, hits
        elif isinstance(data, list):
            new_list = []
            for i, item in enumerate(data):
                sub, sh = self._walk(item, cf, auto, regex, path + f"[{i}].")
                new_list.append(sub)
                hits.extend(sh)
            return new_list, hits
        else:
            return data, hits

    def serialize(self, data: Any) -> str:
        if self._original_compact:
            return json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        return json.dumps(data, ensure_ascii=False, indent=2)


# ─────────────────────────────────────────────
# CSVEngine / TSVEngine
# ─────────────────────────────────────────────

class _DelimitedEngine(FormatEngine):
    """CSV / TSV 共用引擎，通过 delimiter 参数区分"""

    delimiter: str = ","
    lineterminator: str = "\r\n"

    def parse(self, content: str) -> List[Dict[str, str]]:
        reader = csv.DictReader(io.StringIO(content), delimiter=self.delimiter)
        rows = list(reader)
        fieldnames = reader.fieldnames or []
        return {"fieldnames": fieldnames, "rows": rows}

    def apply(self, data, custom_fields, auto_detect, regex_on_values) -> Tuple[Any, List[str]]:
        fieldnames = data["fieldnames"]
        rows = data["rows"]
        hits_set = set()
        new_rows = []
        for row in rows:
            new_row = {}
            for k, v in row.items():
                if not k or not v:
                    new_row[k] = v
                    continue
                strategy = _match_field_strategy(k, custom_fields) if auto_detect else None
                if strategy:
                    new_row[k] = desensitize_value(str(v), strategy)
                    hits_set.add(k)
                elif isinstance(v, str) and regex_on_values:
                    masked, rh = _regex_scan_text(v)
                    if rh:
                        new_row[k] = masked
                        hits_set.add(k + "(正则)")
                    else:
                        new_row[k] = v
                else:
                    new_row[k] = v
            new_rows.append(new_row)
        return {"fieldnames": fieldnames, "rows": new_rows}, list(hits_set)

    def serialize(self, data: Any) -> str:
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=data["fieldnames"],
                                delimiter=self.delimiter,
                                lineterminator=self.lineterminator)
        writer.writeheader()
        writer.writerows(data["rows"])
        return output.getvalue()


class CSVEngine(_DelimitedEngine):
    delimiter = ","
    lineterminator = "\r\n"


class TSVEngine(_DelimitedEngine):
    delimiter = "\t"
    lineterminator = "\n"


# ─────────────────────────────────────────────
# YAMLEngine（v3 增强版）
# ─────────────────────────────────────────────

class YAMLEngine(FormatEngine):
    """
    纯 Python 实现的 YAML 脱敏引擎（v3 增强版）。
    新增：引号包裹保留、列表项值脱敏、中文 key 支持。
    不依赖 PyYAML，使用行级解析 + 正则扫描。
    """

    def parse(self, content: str) -> List[Dict]:
        """将 YAML 解析为行列表，每行附带元数据"""
        lines = []
        for raw_line in content.split("\n"):
            line_info = {"raw": raw_line}
            stripped = raw_line.lstrip()
            indent = len(raw_line) - len(stripped)

            # 跳过注释和空行
            if not stripped or stripped.startswith("#"):
                line_info["type"] = "skip"
                lines.append(line_info)
                continue

            # key: value 格式（支持中文 key）
            m = re.match(r'^([^\s:#]+(?::?[^\s:#]*)*)\s*:\s*(.*)$', stripped)
            if m:
                key = m.group(1).strip()
                value = m.group(2).strip()
                # 去除行尾注释（但保留 # 在引号内的情况）
                if " #" in value and not value.startswith('"') and not value.startswith("'"):
                    value = value[:value.index(" #")].strip()
                line_info["type"] = "kv"
                line_info["indent"] = indent
                line_info["key"] = key
                line_info["value"] = value
                line_info["prefix"] = raw_line[:raw_line.index(stripped)]
                # 记录引号信息
                line_info["quote"] = ""
                if value and len(value) >= 2:
                    if (value.startswith('"') and value.endswith('"')) or \
                       (value.startswith("'") and value.endswith("'")):
                        line_info["quote"] = value[0]
                        line_info["value"] = value[1:-1]
                # 记录分隔符（key: 后面可能有多个空格）
                colon_idx = raw_line.index(":")
                line_info["sep"] = raw_line[colon_idx + 1:colon_idx + 1 + len(raw_line[colon_idx + 1:]) - len(raw_line[colon_idx + 1:].lstrip())]
                lines.append(line_info)
                continue

            # 列表项：- value 格式
            list_m = re.match(r'^-\s+(.+)$', stripped)
            if list_m:
                item_val = list_m.group(1).strip()
                line_info["type"] = "list_item"
                line_info["indent"] = indent
                line_info["value"] = item_val
                line_info["prefix"] = raw_line[:raw_line.index(stripped)]
                line_info["quote"] = ""
                if item_val and len(item_val) >= 2:
                    if (item_val.startswith('"') and item_val.endswith('"')) or \
                       (item_val.startswith("'") and item_val.endswith("'")):
                        line_info["quote"] = item_val[0]
                        line_info["value"] = item_val[1:-1]
                lines.append(line_info)
                continue

            line_info["type"] = "skip"
            lines.append(line_info)

        return lines

    def apply(self, data, custom_fields, auto_detect, regex_on_values) -> Tuple[Any, List[str]]:
        hits = []
        for line_info in data:
            # 处理 key: value 行
            if line_info.get("type") == "kv":
                key = line_info["key"]
                value = line_info["value"]
                if not value or value in ("|", ">", "|+", ">+", "|-", ">-"):
                    continue
                strategy = _match_field_strategy(key, custom_fields) if auto_detect else None
                if not strategy and custom_fields:
                    strategy = _match_field_strategy(key, custom_fields)
                if strategy:
                    line_info["value"] = desensitize_value(value, strategy)
                    hits.append(key)
                elif regex_on_values:
                    masked, rh = _regex_scan_text(value)
                    if rh:
                        line_info["value"] = masked
                        hits.append(key + "(正则)")

            # 处理列表项值
            elif line_info.get("type") == "list_item":
                value = line_info["value"]
                if not value:
                    continue
                if regex_on_values:
                    masked, rh = _regex_scan_text(value)
                    if rh:
                        line_info["value"] = masked
                        hits.append("list_item(正则)")

        return data, hits

    def serialize(self, data: Any) -> str:
        lines = []
        for line_info in data:
            if line_info.get("type") == "kv" and "prefix" in line_info:
                val = line_info["value"]
                # 恢复引号包裹
                if line_info.get("quote"):
                    val = f"{line_info['quote']}{val}{line_info['quote']}"
                sep = line_info.get("sep", " ")
                lines.append(f"{line_info['prefix']}{line_info['key']}:{sep}{val}")
            elif line_info.get("type") == "list_item" and "prefix" in line_info:
                val = line_info["value"]
                if line_info.get("quote"):
                    val = f"{line_info['quote']}{val}{line_info['quote']}"
                lines.append(f"{line_info['prefix']}- {val}")
            else:
                lines.append(line_info["raw"])
        return "\n".join(lines)


# ─────────────────────────────────────────────
# XMLEngine（v3 增强版）
# ─────────────────────────────────────────────

class XMLEngine(FormatEngine):
    """
    XML 脱敏引擎（v3 增强版）。
    新增：标签名匹配（<password>secret</password> 会命中）。
    """

    _TAG_RE = re.compile(r'<([a-zA-Z_][\w\-.]*)((?:\s+[^>]*?)?)(/?)>')
    _ATTR_RE = re.compile(r'([a-zA-Z_][\w\-.]*)\s*=\s*(["\'])([^"\']*)\2')

    def parse(self, content: str) -> str:
        return content

    def apply(self, content, custom_fields, auto_detect, regex_on_values) -> Tuple[str, List[str]]:
        hits = []
        result = content

        # Step 1: 处理标签文本内容（<password>secret</password>）
        # 匹配 <tagname>text</tagname> 并根据标签名做字段匹配
        _TAG_TEXT_RE = re.compile(r'<([a-zA-Z_][\w\-.]*)(?:\s[^>]*)?>([^<]+)</\1>')

        def tag_text_replacer(m):
            tag_name = m.group(1)
            text = m.group(2)
            if not text.strip():
                return m.group(0)
            strategy = _match_field_strategy(tag_name, custom_fields) if auto_detect else None
            if strategy:
                hits.append(f"<{tag_name}>")
                val = desensitize_value(text.strip(), strategy)
                # 重建标签，保留属性
                return m.group(0).replace(text, val, 1)
            elif regex_on_values:
                masked, rh = _regex_scan_text(text)
                if rh:
                    hits.extend(rh)
                    return m.group(0).replace(text, masked, 1)
            return m.group(0)

        result = _TAG_TEXT_RE.sub(tag_text_replacer, result)

        # Step 2: 处理属性值
        def attr_replacer(m):
            attr_name = m.group(1)
            quote = m.group(2)  # 保留原始引号类型
            attr_val = m.group(3)
            strategy = _match_field_strategy(attr_name, custom_fields) if auto_detect else None
            if strategy:
                hits.append(f"@{attr_name}")
                val = desensitize_value(attr_val, strategy)
                return f'{attr_name}={quote}{val}{quote}'
            elif regex_on_values:
                masked, rh = _regex_scan_text(attr_val)
                if rh:
                    hits.append(f"@{attr_name}(正则)")
                    return f'{attr_name}={quote}{masked}{quote}'
            return m.group(0)

        result = self._ATTR_RE.sub(attr_replacer, result)

        # Step 3: 对剩余裸露文本做正则兜底（不在标签内的文本）
        # 已经被前两步处理过的，正则不会重复匹配

        return result, hits

    def serialize(self, data: str) -> str:
        return data


# ─────────────────────────────────────────────
# MarkdownEngine
# ─────────────────────────────────────────────

class MarkdownEngine(FormatEngine):
    """Markdown 脱敏：对非代码块区域做正则扫描，代码块保留原样"""

    _CODE_BLOCK_RE = re.compile(r'(```[\s\S]*?```|`[^`]+`)', re.MULTILINE)

    def parse(self, content: str) -> str:
        return content

    def apply(self, content, custom_fields, auto_detect, regex_on_values) -> Tuple[str, List[str]]:
        if not regex_on_values and not auto_detect:
            return content, []

        parts = self._CODE_BLOCK_RE.split(content)
        hits = []
        result_parts = []

        for i, part in enumerate(parts):
            if self._CODE_BLOCK_RE.match(part):
                result_parts.append(part)
            else:
                masked, rh = _regex_scan_text(part)
                if rh:
                    hits.extend(rh)
                result_parts.append(masked)

        return "".join(result_parts), hits

    def serialize(self, data: str) -> str:
        return data


# ─────────────────────────────────────────────
# KvLineEngine 基类（INI/Properties 共用）
# ─────────────────────────────────────────────

class _KvLineEngine(FormatEngine):
    """INI / Properties 共用基类，消除代码重复"""

    comment_chars: Tuple[str, ...] = ("#", ";")
    kv_pattern: str = r'^(\s*[^\s#=;]+\s*)[=:](\s*)(.*)$'

    def parse(self, content: str) -> str:
        return content

    def apply(self, content, custom_fields, auto_detect, regex_on_values) -> Tuple[str, List[str]]:
        hits = []
        lines = content.split("\n")
        new_lines = []

        for line in lines:
            stripped = line.lstrip()

            # 跳过空行和注释
            if not stripped or stripped[0] in self.comment_chars:
                new_lines.append(line)
                continue

            m = re.match(self.kv_pattern, line)
            if not m:
                new_lines.append(line)
                continue

            key_part = m.group(1).strip()
            # 保留原始分隔符（= 或 :）
            full_key_with_sep = m.group(1)  # 包含空格的原始 key
            sep_char = m.group(2)           # 分隔符后的空格
            value = m.group(3)

            # 去行尾注释
            comment = ""
            for marker in [" #", " ;", "\t#", "\t;"]:
                if marker in value:
                    idx = value.index(marker)
                    comment = value[idx:]
                    value = value[:idx]
                    break

            # 检测原始分隔符（= 还是 :）
            raw_line_after_key = line[len(m.group(1)):]
            actual_sep = raw_line_after_key[0] if raw_line_after_key else "="

            strategy = _match_field_strategy(key_part, custom_fields) if auto_detect else None
            if strategy:
                new_val = desensitize_value(value.strip(), strategy)
                new_lines.append(f"{full_key_with_sep}{actual_sep}{sep_char}{new_val}{comment}")
                hits.append(key_part)
            elif regex_on_values:
                masked, rh = _regex_scan_text(value.strip())
                if rh:
                    new_lines.append(f"{full_key_with_sep}{actual_sep}{sep_char}{masked}{comment}")
                    hits.append(key_part + "(正则)")
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)

        return "\n".join(new_lines), hits

    def serialize(self, data: str) -> str:
        return data


class INIEngine(_KvLineEngine):
    """INI / CFG 配置文件脱敏引擎"""
    comment_chars = ("#", ";")
    kv_pattern = r'^(\s*[^\s#=;]+\s*)[=:](\s*)(.*)$'


class PropertiesEngine(_KvLineEngine):
    """Java Properties 文件脱敏引擎"""
    comment_chars = ("#", "!")
    kv_pattern = r'^(\s*[^\s#=!]+\s*)[=:](\s*)(.*)$'


# ─────────────────────────────────────────────
# LogEngine（v3 修复版）
# ─────────────────────────────────────────────

class LogEngine(FormatEngine):
    """日志文件脱敏引擎：逐行正则扫描，保留日志格式（v3 修复 custom_fields 逻辑）"""

    def parse(self, content: str) -> str:
        return content

    def apply(self, content, custom_fields, auto_detect, regex_on_values) -> Tuple[str, List[str]]:
        if not regex_on_values and not custom_fields:
            return content, []

        # Step 1: 对整段做内置正则扫描
        result, hits = _regex_scan_text(content)

        # Step 2: 如果有自定义字段，在已脱敏的结果上追加扫描
        if custom_fields:
            extra = {}
            for field, strat in custom_fields.items():
                extra[field] = {
                    "regex": rf"(?:{re.escape(field)})[=:\s]*([^\s,;\|\]]{{1,80}})",
                    "strategy": strat,
                    "group": 1,
                }
            # 注意：在 result（已脱敏）上追加扫描，而非原始 content
            result, extra_hits = _regex_scan_text(result, extra)
            hits = hits + extra_hits

        return result, hits

    def serialize(self, data: str) -> str:
        return data


# ─────────────────────────────────────────────
# Engine 注册表
# ─────────────────────────────────────────────

FORMAT_ENGINES: Dict[str, FormatEngine] = {
    "text": TextEngine(),
    "json": JSONEngine(),
    "csv": CSVEngine(),
    "tsv": TSVEngine(),
    "yaml": YAMLEngine(),
    "yml": YAMLEngine(),
    "xml": XMLEngine(),
    "markdown": MarkdownEngine(),
    "md": MarkdownEngine(),
    "ini": INIEngine(),
    "cfg": INIEngine(),
    "properties": PropertiesEngine(),
    "log": LogEngine(),
}

# 扩展名 → 格式名 映射
EXT_FORMAT_MAP = {
    ".txt": "text",
    ".json": "json",
    ".csv": "csv",
    ".tsv": "tsv",
    ".yaml": "yaml",
    ".yml": "yml",
    ".xml": "xml",
    ".md": "markdown",
    ".markdown": "markdown",
    ".ini": "ini",
    ".cfg": "cfg",
    ".properties": "properties",
    ".log": "log",
    ".out": "log",
}


def detect_format(filepath: str) -> str:
    """根据文件扩展名自动检测格式"""
    _, ext = os.path.splitext(filepath.lower())
    if ext in (".1", ".2", ".gz", ".bz2"):
        base, real_ext = os.path.splitext(filepath[:filepath.rfind(ext)])
        fmt = EXT_FORMAT_MAP.get(real_ext.lower(), None)
        if fmt:
            return fmt
    return EXT_FORMAT_MAP.get(ext, "text")


# ─────────────────────────────────────────────
# CLI 入口
# ─────────────────────────────────────────────

def parse_custom_fields(fields_str: str, strategy: str = "mask") -> Dict[str, str]:
    result = {}
    for item in fields_str.split(","):
        item = item.strip()
        if ":" in item:
            name, strat = item.split(":", 1)
            result[name.strip()] = strat.strip()
        else:
            result[item] = strategy
    return result


SUPPORTED_FORMATS = sorted(set(FORMAT_ENGINES.keys()))


def main():
    parser = argparse.ArgumentParser(
        description="多格式数据脱敏工具 v3 - 支持 JSON/CSV/YAML/XML/Markdown/INI/Log 等格式",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
支持格式: {', '.join(SUPPORTED_FORMATS)}

示例:
  python3 desensitize.py --text "手机：13812345678"
  python3 desensitize.py --file data.json --auto --show-hits
  python3 desensitize.py --file config.yaml --fields "password:remove,api_key:remove"
  python3 desensitize.py --file data.xml --auto --output data_masked.xml
  python3 desensitize.py --file readme.md --auto --show-hits
  python3 desensitize.py --file app.log --auto --output app_masked.log
  python3 desensitize.py --file settings.ini --fields "db_password:remove"
  python3 desensitize.py --text "token=abc123" --strategy hash
  python3 desensitize.py --list-formats
  python3 desensitize.py --list-strategies
        """,
    )
    parser.add_argument("--text", "-t", help="直接输入要脱敏的文本")
    parser.add_argument("--file", "-f", help="输入文件路径")
    parser.add_argument("--output", "-o", help="输出文件路径（默认打印到终端）")
    parser.add_argument("--fields", help="自定义字段列表，逗号分隔，支持 field:strategy 格式")
    parser.add_argument("--strategy", "-s", default="mask",
                        help="默认脱敏策略（未指定字段策略时使用）")
    parser.add_argument("--auto", "-a", action="store_true", default=True,
                        help="自动检测隐私字段（默认开启）")
    parser.add_argument("--no-auto", dest="auto", action="store_false",
                        help="关闭自动检测，仅处理 --fields 指定字段")
    parser.add_argument("--format", choices=SUPPORTED_FORMATS,
                        help="强制指定输入格式（自动检测可省略）")
    parser.add_argument("--no-regex", dest="regex_on_values", action="store_false", default=True,
                        help="关闭对文本值的正则扫描（仅字段名匹配）")
    parser.add_argument("--show-hits", action="store_true", help="打印命中的字段/规则列表")
    parser.add_argument("--dry-run", action="store_true", help="仅显示会命中的规则，不输出脱敏结果")
    parser.add_argument("--list-formats", action="store_true", help="列出所有支持的格式")
    parser.add_argument("--list-strategies", action="store_true", help="列出所有脱敏策略")

    args = parser.parse_args()

    if args.list_formats:
        print("支持的格式：")
        for fmt_name in SUPPORTED_FORMATS:
            engine = FORMAT_ENGINES[fmt_name]
            exts = [ext for ext, f in EXT_FORMAT_MAP.items() if f == fmt_name]
            print(f"  {fmt_name:12s}  扩展名: {', '.join(exts) if exts else 'N/A'}  引擎: {engine.__class__.__name__}")
        return

    if args.list_strategies:
        print("支持的脱敏策略：")
        for name in STRATEGY_REGISTRY.list_strategies():
            print(f"  {name}")
        return

    if not args.text and not args.file:
        parser.print_help()
        sys.exit(1)

    custom_fields = parse_custom_fields(args.fields, args.strategy) if args.fields else None

    # ── 处理文本输入 ──
    if args.text:
        engine = FORMAT_ENGINES["text"]
        output, hits = engine.run(args.text, custom_fields, args.auto, args.regex_on_values)
        if args.dry_run:
            print("【Dry Run】将命中规则：" + (", ".join(hits) if hits else "无"))
            return
        if args.show_hits:
            print("【命中规则】" + (", ".join(hits) if hits else "无"))
        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(output)
            print(f"✅ 已写入: {args.output}")
        else:
            print(output)
        return

    # ── 处理文件输入 ──
    with open(args.file, "r", encoding="utf-8") as f:
        content = f.read()

    fmt = args.format or detect_format(args.file)
    engine = FORMAT_ENGINES.get(fmt)
    if not engine:
        print(f"⚠️ 不支持的格式: {fmt}，回退到文本模式", file=sys.stderr)
        engine = FORMAT_ENGINES["text"]

    try:
        output, hits = engine.run(content, custom_fields, args.auto, args.regex_on_values)
    except Exception as e:
        print(f"❌ 处理失败 ({fmt}): {e}", file=sys.stderr)
        print("⚠️ 回退到文本正则扫描模式", file=sys.stderr)
        engine = FORMAT_ENGINES["text"]
        output, hits = engine.run(content, custom_fields, args.auto, args.regex_on_values)

    if args.dry_run:
        print(f"【Dry Run】格式: {fmt}，将命中：" + (", ".join(hits) if hits else "无"))
        return

    if args.show_hits:
        print(f"【格式: {fmt}】命中字段/规则：" + (", ".join(hits) if hits else "无"))

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output)
        print(f"✅ 已写入: {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
