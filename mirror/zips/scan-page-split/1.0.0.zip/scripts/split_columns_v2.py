"""
沿实际竖向分割线切割三列。
分割线因扫描倾斜，逐行追踪其x位置，沿线切割后白色填充为矩形。

用法：
  python split_columns_v2.py <输入目录> <前缀> <起始页码> <结束页码>
示例：
  python split_columns_v2.py "D:/扫描图/output/切图" "数学_页面_" 1 100
"""
import os
import argparse
import numpy as np
from PIL import Image
from scipy.signal import find_peaks


def parse_args():
    parser = argparse.ArgumentParser(description="沿印刷竖线将单页切割为三列")
    parser.add_argument("input_dir", help="单页图片所在目录（通常是双页拆分的输出目录）")
    parser.add_argument("prefix", help="文件名前缀，如 'xxx_页面_'")
    parser.add_argument("page_start", type=int, help="起始页码")
    parser.add_argument("page_end", type=int, help="结束页码")
    parser.add_argument("-o", "--output", default=None,
                        help="输出目录（默认: 输入目录/分列）")
    return parser.parse_args()


def detect_divider_lines(filepath, n_strips=30):
    """
    检测图片中的两条竖向分割线路径。
    将图片分为 n_strips 个水平条带，在每个条带中找梯度最高的两个峰值，
    然后拟合从上到下的线路径。
    """
    img = Image.open(filepath).convert('L')
    arr = np.array(img, dtype=float)
    h, w = arr.shape

    strip_h = h // n_strips
    strip_data = []
    edge_margin = int(w * 0.08)

    for s in range(n_strips):
        y1 = s * strip_h
        y2 = min((s + 1) * strip_h, h)
        if y2 - y1 < 20:
            continue
        strip = arr[y1:y2, :]
        grad = np.abs(np.diff(strip, axis=1))
        col_grad = np.mean(grad, axis=0)
        col_grad_search = col_grad.copy()
        col_grad_search[:edge_margin] = 0
        col_grad_search[-edge_margin:] = 0

        peaks, _ = find_peaks(col_grad_search, height=10, distance=80)
        if len(peaks) >= 2:
            peak_grads = [(p, col_grad[p]) for p in peaks]
            peak_grads.sort(key=lambda x: x[1], reverse=True)
            y_center = (y1 + y2) / 2
            strip_data.append((y_center, peak_grads))

    if not strip_data:
        return None, None, w, h

    all_top_peaks = []
    for _, peak_grads in strip_data:
        strong = [p for p, g in peak_grads if g > 80]
        all_top_peaks.extend(strong)

    if len(all_top_peaks) < 4:
        for _, peak_grads in strip_data:
            strong = [p for p, g in peak_grads if g > 50]
            all_top_peaks.extend(strong)

    hist, bin_edges = np.histogram(all_top_peaks, bins=np.arange(0, w + 10, 10))
    hist_peaks, _ = find_peaks(hist, height=2, distance=20)
    if len(hist_peaks) < 2:
        hist_peaks, _ = find_peaks(hist, height=1, distance=15)
    if len(hist_peaks) < 2:
        return None, None, w, h

    hist_peaks_sorted = sorted(hist_peaks, key=lambda i: hist[i], reverse=True)[:2]
    hist_peaks_sorted.sort()
    seed1 = int(bin_edges[hist_peaks_sorted[0]] + 5)
    seed2 = int(bin_edges[hist_peaks_sorted[1]] + 5)

    if abs(seed2 - seed1) < 200:
        return None, None, w, h

    line1_points = []
    line2_points = []

    for y_center, peak_grads in strip_data:
        best1 = None
        best2 = None
        for p, g in peak_grads:
            if g < 50:
                continue
            if best1 is None and abs(p - seed1) < 80:
                best1 = p
            elif best2 is None and abs(p - seed2) < 80:
                best2 = p
        if best1 is None:
            for p, g in peak_grads:
                if g < 30:
                    continue
                if abs(p - seed1) < 120:
                    best1 = p
                    break
        if best2 is None:
            for p, g in peak_grads:
                if g < 30:
                    continue
                if abs(p - seed2) < 120 and (best1 is None or abs(p - best1) > 50):
                    best2 = p
                    break

        if best1 is not None:
            line1_points.append((y_center, best1))
            seed1 = best1
        if best2 is not None:
            line2_points.append((y_center, best2))
            seed2 = best2

    if len(line1_points) < 3 or len(line2_points) < 3:
        return None, None, w, h

    y1_arr = np.array([p[0] for p in line1_points])
    x1_arr = np.array([p[1] for p in line1_points])
    y2_arr = np.array([p[0] for p in line2_points])
    x2_arr = np.array([p[1] for p in line2_points])

    coeff1 = np.polyfit(y1_arr, x1_arr, 1)
    coeff2 = np.polyfit(y2_arr, x2_arr, 1)

    all_y = np.arange(h)
    line1_x = np.clip(np.round(np.polyval(coeff1, all_y)).astype(int), 0, w - 1)
    line2_x = np.clip(np.round(np.polyval(coeff2, all_y)).astype(int), 0, w - 1)

    return line1_x, line2_x, w, h


def split_along_lines(filepath, line1_x, line2_x):
    img = Image.open(filepath)
    arr = np.array(img)
    h = arr.shape[0]
    w = arr.shape[1]
    n_channels = arr.shape[2] if len(arr.shape) == 3 else 1

    col1_widths = line1_x
    col2_widths = line2_x - line1_x
    col3_widths = w - line2_x

    col1_max_w = int(np.max(col1_widths))
    col2_max_w = int(np.max(col2_widths))
    col3_max_w = int(np.max(col3_widths))

    if n_channels > 1:
        mode = img.mode
        white_val = 0 if mode == 'CMYK' else 255
        col1_arr = np.full((h, col1_max_w, n_channels), white_val, dtype=arr.dtype)
        col2_arr = np.full((h, col2_max_w, n_channels), white_val, dtype=arr.dtype)
        col3_arr = np.full((h, col3_max_w, n_channels), white_val, dtype=arr.dtype)
    else:
        col1_arr = np.full((h, col1_max_w), 255, dtype=arr.dtype)
        col2_arr = np.full((h, col2_max_w), 255, dtype=arr.dtype)
        col3_arr = np.full((h, col3_max_w), 255, dtype=arr.dtype)

    for row in range(h):
        x1 = line1_x[row]
        x2 = line2_x[row]

        if x1 > 0:
            col1_arr[row, :x1] = arr[row, :x1]

        seg_w = x2 - x1
        if seg_w > 0:
            col2_arr[row, :seg_w] = arr[row, x1:x2]

        seg_w3 = w - x2
        if seg_w3 > 0:
            col3_arr[row, :seg_w3] = arr[row, x2:w]

    mode = img.mode
    col1_img = Image.fromarray(col1_arr, mode=mode)
    col2_img = Image.fromarray(col2_arr, mode=mode)
    col3_img = Image.fromarray(col3_arr, mode=mode)

    return col1_img, col2_img, col3_img


def main():
    args = parse_args()
    input_dir = os.path.abspath(args.input_dir)
    output_dir = args.output if args.output else os.path.join(input_dir, "分列")
    os.makedirs(output_dir, exist_ok=True)

    for page_num in range(args.page_start, args.page_end + 1):
        filename = f"{args.prefix}{page_num}.jpg"
        filepath = os.path.join(input_dir, filename)
        if not os.path.exists(filepath):
            print(f"跳过: {filename}")
            continue

        line1_x, line2_x, w, h = detect_divider_lines(filepath)
        if line1_x is None:
            print(f"{filename}: 未检测到分割线，跳过")
            continue

        print(f"{filename}: w={w}, 分割线1: {line1_x[0]}-{line1_x[-1]}, 分割线2: {line2_x[0]}-{line2_x[-1]}")

        col1, col2, col3 = split_along_lines(filepath, line1_x, line2_x)
        base = os.path.splitext(filename)[0]
        for idx, col_img in enumerate([col1, col2, col3], 1):
            out_path = os.path.join(output_dir, f"{base}_{idx}.jpg")
            if col_img.mode == 'CMYK':
                col_img = col_img.convert('RGB')
            col_img.save(out_path, quality=95)

        print(f"  -> {col1.size[0]}px, {col2.size[0]}px, {col3.size[0]}px")

    print(f"\n完成！输出: {output_dir}")


if __name__ == "__main__":
    main()
