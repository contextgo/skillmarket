"""
按竖向分割线将双页扫描图切割为左右两页。
自动检测中间区域的分割线位置（最小亮度列）。

用法：
  python split_pages.py <输入目录> <前缀> <起始页码> <结束页码>
示例：
  python split_pages.py "D:\扫描图" "数学_页面_" 1 50
"""
import os
import argparse
import numpy as np
from PIL import Image


def parse_args():
    parser = argparse.ArgumentParser(description="双页扫描图拆分为左右单页")
    parser.add_argument("input_dir", help="图片所在文件夹路径")
    parser.add_argument("prefix", help="文件名前缀，如 'xxx_页面_'")
    parser.add_argument("page_start", type=int, help="起始页码（文件名中的数字）")
    parser.add_argument("page_end", type=int, help="结束页码（文件名中的数字）")
    parser.add_argument("-o", "--output", default=None,
                        help="输出目录（默认: 输入目录/output/切图）")
    parser.add_argument("-d", "--digits", type=int, default=3,
                        help="文件名页码位数，如3表示补零到3位（默认: 3）")
    return parser.parse_args()


def detect_split_x(img_array, search_ratio=0.1):
    """
    在图片中间区域检测竖向分割线。
    对中间 search_ratio 比例的列，计算每列平均亮度，
    取最暗的那列作为分割位置。
    """
    h, w = img_array.shape[:2]
    if len(img_array.shape) == 3:
        gray = np.mean(img_array, axis=2)
    else:
        gray = img_array.astype(float)

    center = w // 2
    half_search = int(w * search_ratio / 2)
    left_bound = center - half_search
    right_bound = center + half_search

    col_means = np.mean(gray[:, left_bound:right_bound], axis=0)
    split_offset = np.argmin(col_means)
    split_x = left_bound + split_offset
    return split_x


def main():
    args = parse_args()
    input_dir = os.path.abspath(args.input_dir)
    output_dir = args.output if args.output else os.path.join(input_dir, "output", "切图")
    os.makedirs(output_dir, exist_ok=True)

    fmt = f"{{:0{args.digits}d}}"

    for page_num in range(args.page_start, args.page_end + 1):
        filename = f"{args.prefix}{fmt.format(page_num)}.jpg"
        filepath = os.path.join(input_dir, filename)
        if not os.path.exists(filepath):
            print(f"跳过（文件不存在）: {filename}")
            continue

        img = Image.open(filepath)
        img_array = np.array(img)
        w, h = img.size

        split_x = detect_split_x(img_array)
        print(f"{filename}: 尺寸={w}x{h}, 分割线 x={split_x}")

        left_img = img.crop((0, 0, split_x, h))
        right_img = img.crop((split_x, 0, w, h))

        base = os.path.splitext(filename)[0]
        left_path = os.path.join(output_dir, f"{base}_左.jpg")
        right_path = os.path.join(output_dir, f"{base}_右.jpg")

        left_img.save(left_path, quality=95)
        right_img.save(right_path, quality=95)
        print(f"  -> {os.path.basename(left_path)}, {os.path.basename(right_path)}")

    print(f"\n完成！输出目录: {output_dir}")


if __name__ == "__main__":
    main()
