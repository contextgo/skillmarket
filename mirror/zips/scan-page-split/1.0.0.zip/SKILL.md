---
name: scan-page-split
description: "将扫描的双页图片沿书脊拆分为单页，再沿印刷竖线切割为三列。Use when: 切图、拆分扫描页、双页切割、分列、扫描图处理、split scanned pages、column split"
argument-hint: "指定图片目录、文件名前缀、页码范围，以及是否需要重命名"
---

# 扫描图切割工具

将双页扫描图（横向）拆分为单页，再沿印刷竖线切割为三列。  
脚本通过命令行参数传入目录和页码，不含硬编码路径，可直接用于任意项目。

## 适用场景

- 扫描的教材或书籍双页图片需要拆分为单页
- 单页图片中有印刷竖线分隔的多列内容需要逐列切割
- 扫描图有轻微倾斜，需要沿实际印刷线精确裁切

## 环境要求

- Python 3.x
- 依赖库：`pip install pillow numpy scipy`
- Python 路径：`C:\Users\xiong\AppData\Local\Python\bin\python.exe`

## 操作流程

向用户收集以下信息后执行：
1. 图片目录：扫描图所在的绝对路径
2. 文件名前缀：页码数字之前的部分，如 `xxx_页面_`
3. 页码范围：文件名中的起止页码数字
4. 实际页码：如果需要重命名，提供实际起始页码
5. 页码位数：文件名中页码补零到几位，默认 3 位

### 第1步：双页拆分

使用 [split_pages.py](./scripts/split_pages.py) 沿书脊将横向双页扫描图切为左右两页。

```powershell
python split_pages.py <输入目录> <前缀> <起始页码> <结束页码> [-d 位数] [-o 输出目录]
```

参数说明：
- `输入目录`：图片所在文件夹
- `前缀`：文件名前缀
- `起始页码`：文件名中的起始数字
- `结束页码`：文件名中的结束数字
- `-d`：页码位数，默认 3
- `-o`：输出目录，默认 `输入目录/output/切图`

示例：

```powershell
python split_pages.py "D:\扫描图" "数学课本_页面_" 97 104
```

### 第1.5步：可选重命名

如果文件名页码与书本实际页码不一致，用 PowerShell 批量重命名：

```powershell
cd "<第1步的输出目录>"
$prefix = "<文件名前缀>"
$startFile = <文件名起始页码>
$startPage = <实际起始页码>
$count = <双页扫描张数>

for ($i = 0; $i -lt $count; $i++) {
    $old = $startFile + $i
    $newL = $startPage + $i * 2
    $newR = $newL + 1
    Rename-Item "${prefix}$("{0:D3}" -f $old)_左.jpg" "${prefix}${newL}.jpg"
    Rename-Item "${prefix}$("{0:D3}" -f $old)_右.jpg" "${prefix}${newR}.jpg"
}
```

### 第2步：三列分割

使用 [split_columns_v2.py](./scripts/split_columns_v2.py) 沿印刷竖线将单页切为三列。

```powershell
python split_columns_v2.py <输入目录> <前缀> <起始页码> <结束页码> [-o 输出目录]
```

参数说明：
- `输入目录`：单页图片目录，通常是第1步的输出
- `前缀`：文件名前缀
- `起始页码`：起始实际页码
- `结束页码`：结束实际页码
- `-o`：输出目录，默认 `输入目录/分列`

示例：

```powershell
python split_columns_v2.py "D:\扫描图\output\切图" "数学课本_页面_" 109 124
```

## 完整执行模板

```powershell
$py = "C:\Users\xiong\AppData\Local\Python\bin\python.exe"
$skill = "C:\Users\xiong\.copilot\skills\scan-page-split\scripts"

& $py "$skill\split_pages.py" "<图片目录>" "<前缀>" <起始页码> <结束页码>
& $py "$skill\split_columns_v2.py" "<图片目录>\output\切图" "<前缀>" <实际起始页码> <实际结束页码>
```

## 触发提示词

- 帮我切图
- 拆分扫描页
- 双页切割
- 分列
- split scanned pages
- column split

## 注意事项

- 输入必须是 JPG 格式
- 双页图应为横向，单页图应为纵向
- 三列分割依赖实际印刷的竖向分隔线
- CMYK 图片输出时会自动转为 RGB
