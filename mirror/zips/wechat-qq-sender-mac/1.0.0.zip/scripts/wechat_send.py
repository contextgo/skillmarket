#!/usr/bin/env python3
"""
微信发送消息 - macOS版本
使用 AppleScript 控制 macOS 微信客户端发送消息到群/联系人
"""
import sys
import subprocess
import os

def send_wechat(contact: str, message: str) -> bool:
    """发送微信消息"""
    script = f'''
    tell application "WeChat" to activate
    delay 0.3
    tell application "System Events" to tell process "WeChat" to keystroke "f" using command down
    delay 0.3
    tell application "System Events" to tell process "WeChat" to keystroke "{contact}"
    delay 0.5
    tell application "System Events" to tell process "WeChat" to key code 36
    delay 0.3
    tell application "System Events" to tell process "WeChat" to key code 36
    delay 0.5
    set the clipboard to "{message}"
    delay 0.2
    tell application "System Events" to tell process "WeChat" to keystroke "v" using command down
    delay 0.2
    tell application "System Events" to tell process "WeChat" to key code 36
    '''
    try:
        subprocess.run(['osascript', '-e', script], capture_output=True)
        return True
    except Exception as e:
        print(f"Error: {e}")
        return False

def main():
    if len(sys.argv) < 3:
        print("Usage: python wechat_send.py <联系人/群名> <消息>")
        print("Example: python wechat_send.py \"hermes\" \"你好\"")
        sys.exit(1)
    
    contact = sys.argv[1]
    message = " ".join(sys.argv[2:])
    
    print(f"发送消息到: {contact}")
    if send_wechat(contact, message):
        print("✅ 发送成功!")
    else:
        print("❌ 发送失败")
        sys.exit(1)

if __name__ == "__main__":
    main()