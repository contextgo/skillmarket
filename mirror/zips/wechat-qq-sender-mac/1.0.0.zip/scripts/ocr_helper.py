#!/usr/bin/env python3
"""
OCR辅助模块
"""
import os
import pytesseract
from PIL import Image

def ocr_image(image_path, lang='chi_sim+eng'):
    """识别图片中的文字"""
    try:
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image, lang=lang)
        return text.strip()
    except Exception as e:
        print(f"OCR识别失败: {e}")
        return ""

def ocr_with_boxes(image_path, lang='chi_sim+eng'):
    """识别文字并返回位置信息"""
    try:
        image = Image.open(image_path)
        data = pytesseract.image_to_data(image, lang=lang, output_type=pytesseract.Output.DICT)
        return data
    except Exception as e:
        print(f"OCR识别失败: {e}")
        return {}

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python ocr_helper.py <image_path>")
        sys.exit(1)
    
    image_path = sys.argv[1]
    text = ocr_image(image_path)
    print(text)
