#!/usr/bin/env python3
"""
截图 + OCR + 智能回复 - macOS版本
截取聊天区域，OCR识别，生成回复建议，用户确认后发送
"""
import sys
import subprocess
import os
import time
import json
import requests
from PIL import Image
import pytesseract

# 截图保存路径
SCREENSHOT_DIR = os.path.expanduser("~/.openclaw/workspace/screenshots")
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

def capture_screen():
    """截取屏幕"""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    screenshot_path = os.path.join(SCREENSHOT_DIR, f"chat_{timestamp}.png")
    
    # 使用 screencapture 截取屏幕
    subprocess.run(['screencapture', '-x', screenshot_path])
    print(f"截图已保存: {screenshot_path}")
    return screenshot_path

def ocr_image(image_path):
    """OCR识别图片文字"""
    try:
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image, lang='chi_sim+eng')
        return text.strip()
    except Exception as e:
        print(f"OCR识别失败: {e}")
        return ""

def get_ai_reply(chat_content):
    """获取AI回复建议"""
    # 使用简单的规则生成回复建议
    # 可以替换为实际的 AI API 调用
    replies = [
        "收到！",
        "好的，了解~",
        "明白了！",
        "OK，没问题！",
        "收到，谢谢！",
    ]
    
    # 简单判断回复
    if "谢谢" in chat_content:
        return "不客气！😊"
    elif "好的" in chat_content or "收到" in chat_content:
        return "嗯嗯，知道了~"
    elif "？" in chat_content or "吗" in chat_content:
        return "我在的，怎么了？"
    else:
        import random
        return random.choice(replies)

def wechat_send_message(message):
    """发送微信消息"""
    # 激活微信
    subprocess.run(['osascript', '-e', 'tell application "WeChat" to activate'])
    time.sleep(0.5)
    
    # 粘贴消息
    import pyperclip
    pyperclip.copy(message)
    time.sleep(0.3)
    
    # Cmd+V 粘贴
    subprocess.run(['osascript', '-e', '''
        tell application "System Events"
            tell process "WeChat"
                keystroke "v" using command down
            end tell
        end tell
    '''])
    time.sleep(0.3)
    
    # Cmd+Enter 发送
    subprocess.run(['osascript', '-e', '''
        tell application "System Events"
            tell process "WeChat"
                keystroke return using command down
            end tell
        end tell
    '''])

def main():
    if len(sys.argv) < 2:
        print("Usage: python capture_and_reply.py <群聊名称>")
        print("Example: python capture_and_reply.py \"工作群\"")
        sys.exit(1)
    
    group_name = sys.argv[1]
    
    print(f"开始处理群聊: {group_name}")
    
    # 1. 截图
    print("1. 截取屏幕...")
    screenshot_path = capture_screen()
    
    # 2. OCR识别
    print("2. OCR识别文字...")
    chat_content = ocr_image(screenshot_path)
    if chat_content:
        print(f"识别内容: {chat_content[:100]}...")
    else:
        print("未识别到文字")
        chat_content = ""
    
    # 3. 生成回复建议
    print("3. 生成回复建议...")
    reply = get_ai_reply(chat_content)
    print(f"\n建议回复: {reply}")
    
    # 4. 等待用户确认
    print("\n是否发送？")
    print("  输入 y 发送")
    print("  输入 n 取消")
    print("  输入自定义回复发送")
    
    user_input = input("请输入: ").strip().lower()
    
    if user_input == 'y':
        final_reply = reply
    elif user_input == 'n':
        print("已取消")
        sys.exit(0)
    else:
        final_reply = user_input
    
    # 5. 发送消息
    print(f"发送消息: {final_reply}")
    wechat_send_message(final_reply)
    print("消息已发送！")

if __name__ == "__main__":
    main()
