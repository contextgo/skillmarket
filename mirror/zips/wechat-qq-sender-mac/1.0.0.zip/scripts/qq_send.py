#!/usr/bin/env python3
"""
QQ发送消息 - macOS版本
使用 AppleScript 控制 macOS QQ客户端
"""
import sys
import subprocess
import pyperclip
import time

def activate_app(app_name):
    """激活应用"""
    script = f'tell application "{app_name}" to activate'
    subprocess.run(['osascript', '-e', script])

def search_contact(name):
    """搜索联系人"""
    # Cmd+F 打开搜索
    subprocess.run(['osascript', '-e', '''
        tell application "System Events"
            tell process "QQ"
                keystroke "f" using command down
            end tell
        end tell
    '''])
    time.sleep(0.5)
    
    # 输入联系人名字
    subprocess.run(['osascript', '-e', f'''
        tell application "System Events"
            tell process "QQ"
                keystroke "{name}"
            end tell
        end tell
    '''])
    time.sleep(1)
    
    # 回车选择第一个结果
    subprocess.run(['osascript', '-e', '''
        tell application "System Events"
            tell process "QQ"
                key code 36
            end tell
        end tell
    '''])
    time.sleep(0.5)

def send_message(message):
    """发送消息"""
    # 复制消息到剪贴板
    pyperclip.copy(message)
    time.sleep(0.3)
    
    # Cmd+V 粘贴
    subprocess.run(['osascript', '-e', '''
        tell application "System Events"
            tell process "QQ"
                keystroke "v" using command down
            end tell
        end tell
    '''])
    time.sleep(0.3)
    
    # Cmd+Enter 发送
    subprocess.run(['osascript', '-e', '''
        tell application "System Events"
            tell process "QQ"
                keystroke return using command down
            end tell
        end tell
    '''])

def main():
    if len(sys.argv) < 3:
        print("Usage: python qq_send.py <联系人> <消息>")
        print("Example: python qq_send.py \"张三\" \"你好！\"")
        sys.exit(1)
    
    contact = sys.argv[1]
    message = sys.argv[2]
    
    print(f"正在发送消息给: {contact}")
    
    # 激活QQ
    activate_app("QQ")
    time.sleep(1)
    
    # 搜索联系人
    search_contact(contact)
    time.sleep(1)
    
    # 发送消息
    send_message(message)
    
    print("消息已发送！")

if __name__ == "__main__":
    main()
