---
name: wechat-qq-sender-mac
version: 1.0.0
description: macOS平台微信和QQ自动发消息工具。支持搜索联系人、发送消息、截图OCR分析，智能回复建议（需用户确认后发送）。
author: HeartFlow
tags: [wechat, qq, messaging, automation, macos, ocr]
metadata:
  openclaw:
    emoji: "💬"
    requires:
      bins: ["osascript", "screencapture", "tesseract"]
      python: ["pillow", "requests"]
---

# WeChat & QQ Sender (macOS)

⚠️ **隐私与安全警告**

本工具涉及以下敏感操作，请仔细阅读：

| 操作 | 风险 | 防护措施 |
|------|------|---------|
| **屏幕截图** | 会捕获屏幕可见内容，可能包含敏感信息 | 截图仅保存到本地，不自动上传 |
| **剪贴板操作** | 会临时覆盖剪贴板内容 | 发送完成后恢复 |
| **键盘模拟** | 模拟键盘输入发送消息 | 发送前需用户确认，不会自动发送 |
| **鼠标控制** | 移动鼠标点击窗口 | 发送期间请勿操作鼠标 |

**建议：**
- ✅ 仅在测试环境使用
- ✅ 避免在包含敏感信息的聊天中使用
- ✅ 发送期间不要操作鼠标键盘
- ❌ 不要将截图上传到外部 AI 服务

---

## 功能特性

- ✅ 微信自动发消息（macOS微信客户端）
- ✅ QQ 自动发消息（macOS QQ客户端）
- ✅ 支持中文、英文、颜文字
- ✅ 使用剪贴板粘贴（支持特殊字符）
- ✅ 截图保存到本地
- ✅ OCR 文字识别（使用 tesseract）
- ✅ 智能回复建议（**需用户确认后发送**）

## 系统要求

- macOS 10.15+
- Python 3.8+
- 微信/QQ 桌面版已安装并登录
- 已安装 Command Line Tools（OCR需要）

## 依赖安装

### OCR 依赖
```bash
# 使用 Homebrew 安装 tesseract
brew install tesseract

# Python 依赖
pip install pillow requests pytesseract
```

## 使用方法

### 微信发消息
```bash
python scripts/wechat_send.py <联系人> <消息>
```

示例：
```bash
python scripts/wechat_send.py "联系人A" "你好呀！(๑•̀ㅂ•́)و✧"
```

### QQ 发消息
```bash
python scripts/qq_send.py <联系人> <消息>
```

示例：
```bash
python scripts/qq_send.py "联系人B" "Hello~"
```

### 截图 + OCR + 智能回复
```bash
python scripts/capture_and_reply.py <群聊名称>
```

**流程说明：**
1. 截取聊天区域
2. OCR 识别聊天内容
3. 分析内容并生成回复建议
4. **显示回复建议，等待用户确认**
5. 用户输入 `y` 发送，或输入自定义内容，或输入 `n` 取消
6. 发送消息

## 工作原理

1. **查找窗口**：使用 osascript AppleScript 查找微信/QQ 窗口
2. **激活窗口**：将窗口置于前台
3. **搜索联系人**：
   - 微信：Cmd+F 打开搜索，输入名字，回车选择
   - QQ：Cmd+F 打开搜索，点击联系人
4. **发送消息**：使用剪贴板粘贴文字（支持中文和颜文字），按 Cmd+Enter 发送

## 重要风险提示

| 风险 | 说明 | 建议 |
|------|------|------|
| 剪贴板操作 | 脚本会临时修改剪贴板内容 | 发送期间不要复制其他内容 |
| 鼠标键盘控制 | 脚本会模拟鼠标点击和键盘输入 | 发送期间不要操作鼠标键盘 |
| 自动发送 | 消息会直接发送到聊天窗口 | 仔细确认回复内容后再发送 |
| OCR 识别 | 会识别聊天内容 | 不要在敏感聊天中使用 |

## 数据存储

本技能会在以下位置读写文件：

| 路径 | 用途 | 是否可删除 |
|------|------|-----------|
| `~/.openclaw/workspace/screenshots/` | 保存聊天截图 | ✅ 可随时删除 |
| `~/.openclaw/workspace/temp/` | 临时文件 | ✅ 可随时删除 |

**注意**：截图文件仅保存在本地，不会自动上传或发送到任何外部服务。

## 文件说明

| 文件 | 功能 |
|------|------|
| `scripts/wechat_send.py` | 微信发消息 |
| `scripts/qq_send.py` | QQ 发消息 |
| `scripts/capture_and_reply.py` | 截图 + OCR + 智能回复 |
| `scripts/ocr_helper.py` | OCR 辅助模块 |

## 故障排除

| 问题 | 解决方案 |
|------|----------|
| 找不到窗口 | 确保微信/QQ 已打开 |
| 发送失败 | 检查窗口是否被其他应用遮挡 |
| 中文乱码 | 使用剪贴板粘贴功能 |
| 点击位置不对 | 调整脚本中的坐标 |
| OCR 失败 | 安装 tesseract: `brew install tesseract` |

---

**Version: 1.0.0**
**Author: HeartFlow**
