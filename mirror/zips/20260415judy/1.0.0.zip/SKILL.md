---
name: industry-entry-exit-decision
description: Build evidence-backed executive decision reports for industry entry, expansion, divestiture, or exit topics discussed in senior management meetings. Use when meeting notes, transcripts, agendas, or user prompts mention entering a new industry, exiting an existing industry, restructuring business lines, portfolio strategy, market attractiveness, competitive position, industry lifecycle, barriers to entry/exit, or whether a company should enter/withdraw from an industry.
---

# Industry Entry Exit Decision

## Purpose

Turn executive meeting discussion into a structured strategic decision report about industry entry or exit. Start by assuming the meeting contains a relevant strategic topic, then identify the corresponding academic/management question, gather current external evidence, model the decision across multiple dimensions, and produce a sourced recommendation.

## Workflow

1. **Extract the strategic issue**
   - Identify the company, current industry, target entry industry or candidate exit industry, geography, time horizon, and decision owner.
   - If the meeting material is vague, infer a plausible decision frame and label it as an assumption.
   - Map the discussion to an academic question, such as market entry under uncertainty, resource-based diversification, real options, transaction cost economics, industry lifecycle timing, or exit barrier management.

2. **Define the decision question**
   - Phrase one primary question: "Should the company enter/exit [industry] in [market] over [time horizon]?"
   - State alternatives: enter now, stage/pilot, partner/acquire, wait, maintain, harvest, divest, spin off, or exit.
   - Define decision criteria before researching to avoid cherry-picking evidence.

3. **Gather live evidence**
   - Use web research for current facts. Prefer primary and authoritative sources: company filings, investor presentations, annual reports, regulator data, industry associations, official statistics, central banks, customs data, listed-company disclosures, and reputable analyst or news sources.
   - Capture source dates. For fast-changing indicators, state the retrieval date.
   - Gather evidence for the company's current industry, the target entry or exit industry, and comparable competitors.
   - Do not rely on unsourced claims. If data is unavailable, explicitly mark the evidence gap and use scenarios.

4. **Model the industry decision**
   - Read `references/frameworks.md` when choosing the analytical model.
   - Use at least three dimensions: market attractiveness, competitive intensity, company fit/capability, financial feasibility, regulatory/geopolitical risk, execution complexity, synergy, optionality, and exit barriers.
   - Build a transparent scoring table. Explain weights and sensitivity; avoid false precision.
   - For entry decisions, include entry mode options. For exit decisions, include exit path, stranded cost, stakeholder impact, and timing risk.

5. **Produce the report**
   - Use `references/report-template.md` for structure.
   - Lead with the recommendation and confidence level.
   - Separate facts, assumptions, analysis, and management judgment.
   - Include citations/links for sourced claims and a final list of unresolved diligence questions.

## Research Rules

- Browse when the answer depends on current market facts, company status, regulation, prices, demand, capacity, financing, or competitor moves.
- Use exact dates for meetings, filings, industry data, and news where possible.
- Cross-check important numbers across at least two sources when practical.
- Prefer the company's reported segment definitions over generic industry labels.
- When meeting content conflicts with current public data, state the conflict and continue with scenario analysis.

## Output Standard

Deliver a decision-support report, not a generic industry overview. The report must include:

- Executive recommendation
- Meeting topic to academic question mapping
- Company and industry baseline
- Evidence-backed industry attractiveness assessment
- Entry/exit feasibility model with weighted dimensions
- Strategic options and scenario comparison
- Key risks, trigger points, and next diligence steps
- Source list with links and publication or retrieval dates

## References

- `references/frameworks.md`: model selection, dimensions, scoring guidance, and entry/exit-specific considerations.
- `references/report-template.md`: recommended report outline and tables.
