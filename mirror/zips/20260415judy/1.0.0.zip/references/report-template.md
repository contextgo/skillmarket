# Decision Report Template

Use this structure for the final output. Adapt section names to the user's language and meeting context.

## 1. Executive Recommendation

- Recommendation: enter, staged entry, wait, partner/acquire, maintain, harvest, divest, or exit.
- Confidence: high / medium / low.
- Decision rationale: 3-5 bullets.
- Immediate next action: one concrete management step.

## 2. Meeting Topic and Academic Framing

| Meeting discussion | Strategic interpretation | Academic question |
| --- | --- | --- |
| Summarize the relevant meeting theme | Entry/exit/portfolio decision | Name the research question and lens |

State assumptions if the meeting record is incomplete.

## 3. Company and Industry Baseline

- Company current business and segment exposure.
- Current industry economics.
- Target entry industry or candidate exit industry.
- Geography and time horizon.
- Public evidence summary with dates.

## 4. External Evidence

| Evidence area | Finding | Source and date | Decision implication |
| --- | --- | --- | --- |
| Market growth |  |  |  |
| Profit pool/margins |  |  |  |
| Competitors |  |  |  |
| Regulation |  |  |  |
| Capital intensity |  |  |  |
| Technology or supply chain |  |  |  |

## 5. Weighted Decision Model

| Dimension | Weight | Score 1-5 | Weighted score | Evidence | Interpretation |
| --- | ---: | ---: | ---: | --- | --- |
| Market attractiveness |  |  |  |  |  |
| Competitive intensity |  |  |  |  |  |
| Capability fit |  |  |  |  |  |
| Financial feasibility |  |  |  |  |  |
| Regulatory risk |  |  |  |  |  |
| Execution complexity |  |  |  |  |  |
| Strategic synergy |  |  |  |  |  |
| Optionality or exit barriers |  |  |  |  |  |

Explain scoring logic and do one sensitivity check.

## 6. Strategic Options

| Option | Upside | Downside | Requirements | Trigger to proceed/stop |
| --- | --- | --- | --- | --- |
| Option 1 |  |  |  |  |
| Option 2 |  |  |  |  |
| Option 3 |  |  |  |  |

## 7. Scenarios

| Scenario | Assumptions | Expected outcome | Management response |
| --- | --- | --- | --- |
| Base |  |  |  |
| Upside |  |  |  |
| Downside |  |  |  |

## 8. Risks and Mitigations

Separate external risks, internal execution risks, financial risks, and governance risks.

## 9. Diligence Questions

List unresolved questions that require internal data, expert interviews, customer checks, legal review, or board approval.

## 10. Sources

List all web sources with links and publication/retrieval dates. Keep source descriptions concise.
