# Analytical Frameworks

Use this reference to choose models for industry entry and exit decisions. Combine frameworks; do not force every case into one model.

## Meeting Topic to Academic Question

| Meeting signal | Academic/management question | Useful lenses |
| --- | --- | --- |
| "Should we enter this industry?" | Market entry under uncertainty | Industrial organization, real options, resource-based view |
| "Should we diversify into adjacent business?" | Related diversification and capability transfer | RBV, economies of scope, transaction cost economics |
| "Should we buy or build?" | Entry mode and boundary of the firm | Transaction cost economics, M&A integration, capability gap |
| "Should we exit this segment?" | Exit barriers and portfolio reallocation | Exit barrier theory, opportunity cost, capital allocation |
| "Should we wait?" | Timing under uncertainty | Real options, industry lifecycle, first-mover/fast-follower tradeoff |
| "Can we defend our current business?" | Competitive response and strategic positioning | Five Forces, game theory, dynamic capabilities |

## Core Dimensions

Score each dimension from 1 to 5. Use weights that sum to 100%. Keep weights visible and explain them.

| Dimension | Entry interpretation | Exit interpretation | Evidence examples |
| --- | --- | --- | --- |
| Market attractiveness | Growth, profit pool, demand durability | Remaining value and decline speed | TAM/SAM, CAGR, margins, utilization, customer demand |
| Competitive intensity | Rivalry, concentration, switching costs | Ability to defend or harvest | HHI proxies, pricing pressure, share trends, new entrants |
| Company capability fit | Transferable assets, channels, technology, brand | Whether capabilities remain advantaged | segment disclosures, patents, talent, distribution |
| Financial feasibility | Required capex, payback, ROIC, funding | Divestiture value, impairment, cash release | filings, comparable multiples, capex intensity |
| Regulatory and policy risk | licenses, subsidies, antitrust, trade controls | closure approvals, labor, environmental liabilities | regulator notices, laws, policy plans |
| Execution complexity | time to scale, hiring, supply chain, integration | separation complexity, stranded cost, customer migration | operational metrics, integration cases |
| Strategic synergy | cross-sell, data, procurement, ecosystem leverage | loss of synergy if exited | segment overlap, shared customers, procurement data |
| Optionality | ability to stage, learn, pivot, abandon | ability to preserve upside or re-enter later | pilots, partnerships, minority stakes, carve-outs |

## Entry Model

Evaluate at least three routes:

1. Organic build: best when the company has core capabilities and time to scale.
2. Partnership or JV: best when market access, licenses, or local relationships are key.
3. Acquisition: best when speed, scarce assets, or consolidation matter.
4. Minority investment or pilot: best under high uncertainty and when learning value is high.

Entry scoring formula:

`Entry Score = Market Attractiveness + Capability Fit + Financial Feasibility + Strategic Synergy + Optionality - Competitive Intensity Risk - Regulatory Risk - Execution Risk`

Use the formula as a disciplined narrative device, not as a mechanical answer.

## Exit Model

Evaluate at least three routes:

1. Maintain and improve: best when the business is strategically necessary or recoverable.
2. Harvest: best when cash flows are positive but long-term growth is weak.
3. Divest or spin off: best when another owner can create more value.
4. Wind down: best when liabilities are contained and sale value is low.

Exit scoring formula:

`Exit Attractiveness = Opportunity Cost of Staying + Decline/Risk Exposure + Capital Release + Strategic Focus Benefit - Exit Barriers - Lost Synergy - Stakeholder/Regulatory Cost`

## Industry Analysis Models

Use the following selectively:

- Five Forces: competitive intensity, supplier/customer power, substitutes, entry barriers.
- PESTEL: policy, macro, social, technology, environment, legal shocks.
- Industry lifecycle: emergence, growth, maturity, decline; match timing and capability needs.
- Value chain profit pool: where margins accrue and whether the company can access them.
- RBV/VRIO: whether the company has valuable, rare, hard-to-imitate, organized capabilities.
- Real options: stage entry or exit when uncertainty is high and learning is valuable.
- Scenario planning: create base/upside/downside cases when data is incomplete or volatile.

## Minimum Evidence Checklist

- Company current industry and segment performance.
- Target or exit industry's size, growth, margin, capacity, and demand drivers.
- Competitor positions and recent strategic moves.
- Entry/exit barriers and regulatory constraints.
- Capital requirements, valuation benchmarks, or exit proceeds where available.
- Macro, supply chain, technology, and policy risks.
- Management assumptions that require internal validation.
