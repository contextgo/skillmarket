---
name: sqlite-memory
description: "Lightweight local SQLite memory system for OpenClaw agents. Store and retrieve user preferences, decisions, project updates, and corrections without API costs. Use when (1) the user wants to persist memory across sessions without external APIs, (2) recording user preferences or corrections, (3) tracking project state and decisions, (4) searching past conversations for context. Alternative to graph-memory or vector-based systems — zero fees, zero configuration, pure local SQLite."
---

# SQLite Memory

Zero-cost local memory system using SQLite. No API keys, no cloud calls, no vector embeddings. Just fast, reliable local storage.

## Quick Start

```python
from sqlite_memory import store_preference, store_decision, search_memory, get_memory_stats

# Store a preference
store_preference("User dislikes overly apologetic language", importance=1.0)

# Store a project decision
store_decision("Using pygame.mouse for head motion simulation", importance=0.9)

# Search memories
results = search_memory("sensitivity")
# Returns: [{id, category, content, importance, created_at}, ...]

# Get stats
stats = get_memory_stats()
# Returns: {total_memories, categories, db_path}
```

## When to Use

| Scenario | Function |
|----------|----------|
| User corrects you | `store_correction()` |
| User expresses preference | `store_preference()` |
| Important decision made | `store_decision()` |
| Project milestone reached | `store_project_update()` |
| Need to recall past context | `search_memory()` |

## Memory Categories

- **preference** — User likes/dislikes, style preferences (importance: 0.7-1.0)
- **decision** — Technical choices, design decisions (importance: 0.8-0.9)
- **fact** — General facts about user or project (importance: 0.5-0.7)
- **project** — Project-specific updates, milestones (importance: 0.7-0.9)
- **correction** — Explicit corrections from user (importance: 1.0)

## API Reference

### Storage Functions

```python
store_preference(content: str, importance: float = 0.8) -> int
store_decision(content: str, context: dict = None, importance: float = 0.9) -> int
store_fact(content: str, importance: float = 0.6) -> int
store_project_update(project: str, content: str, importance: float = 0.7) -> int
store_correction(content: str, importance: float = 1.0) -> int
```

### Retrieval Functions

```python
search_memory(query: str, category: str = None, limit: int = 10) -> List[dict]
get_memory_stats() -> dict
```

## Architecture

```
workspace/
└── memory.db              # SQLite database
    ├── memories           # Main memory table
    │   ├── id             # Auto-increment
    │   ├── category       # preference/decision/fact/project/correction
    │   ├── content        # The actual memory text
    │   ├── context        # Optional JSON metadata
    │   ├── importance     # 0.0-1.0, affects sort order
    │   ├── created_at     # Timestamp
    │   └── access_count   # Usage tracking
    └── sessions           # Session tracking (optional)
```

## Comparison with Other Systems

| Feature | sqlite-memory | graph-memory | elite-longterm-memory |
|---------|--------------|--------------|----------------------|
| Cost | Free | API fees | API fees (OpenAI) |
| Setup | Zero config | Needs API keys | Needs LanceDB + OpenAI |
| Speed | Instant (local) | Network calls | Vector search |
| Complexity | Simple | Complex (graph + LLM) | Complex (6 layers) |
| Best for | Quick recall, preferences | Deep knowledge graphs | Enterprise agents |

## Limitations

- **Text search only** — No semantic/vector search (use graph-memory if needed)
- **Single user** — No multi-user isolation
- **No auto-extraction** — Must manually call store functions (unlike Mem0)

## Migration Path

If you outgrow sqlite-memory:

1. **Need vector search?** → graph-memory with Ollama (local embedding)
2. **Need auto-extraction?** → Mem0 + OpenAI API
3. **Need cross-device sync?** → elite-longterm-memory + SuperMemory cloud

## Resources

- **scripts/sqlite_memory.py** — Core memory module, import and use directly
- **references/usage.md** — Detailed usage examples and patterns
