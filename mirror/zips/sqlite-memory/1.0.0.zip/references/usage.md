# SQLite Memory — Detailed Usage Guide

## Installation

No installation needed. The skill includes `scripts/sqlite_memory.py` which is self-contained (only requires Python standard library + sqlite3).

```python
import sys
sys.path.insert(0, r'C:\Users\70424\.openclaw\skills\sqlite-memory\scripts')
from sqlite_memory import *
```

## Common Patterns

### Pattern 1: Recording User Corrections

When user corrects you, always log it:

```python
from sqlite_memory import store_correction

# User says: "No, that's wrong. It should be X not Y"
store_correction("User corrected: should use X instead of Y for Z scenario", importance=1.0)
```

### Pattern 2: Preference Tracking

Log explicit preferences immediately:

```python
from sqlite_memory import store_preference

# User says: "I prefer when you do X"
store_preference("Prefers X approach over Y", importance=0.9)

# User says: "Never do Z again"
store_preference("Dislikes Z, never do it", importance=1.0)
```

### Pattern 3: Project State Tracking

Track project milestones and decisions:

```python
from sqlite_memory import store_project_update, store_decision

# Milestone reached
store_project_update("milk-tea-game", "Completed v5.3.4: spacing fixes + icon redesign")

# Technical decision
store_decision("Using mouse X-axis for head yaw (-30° to +30°)", 
               context={"project": "milk-tea", "category": "input"})
```

### Pattern 4: Session Start Recall

At session start, search for relevant context:

```python
from sqlite_memory import search_memory

# Find recent project updates
recent = search_memory("milk-tea", category="project", limit=5)

# Find user's preferences
prefs = search_memory("", category="preference", limit=10)

# Find corrections to avoid repeating mistakes
corrections = search_memory("", category="correction", limit=5)
```

### Pattern 5: Memory Maintenance

Check what you've stored:

```python
from sqlite_memory import get_memory_stats, search_memory

# Overview
stats = get_memory_stats()
print(f"Total memories: {stats['total_memories']}")
print(f"Categories: {stats['categories']}")

# Find duplicates or outdated info
all_prefs = search_memory("", category="preference", limit=50)
# Review and delete outdated ones if needed
```

## Importance Guidelines

| Importance | When to Use |
|-----------|-------------|
| 1.0 | Critical corrections, hard rules ("never do X") |
| 0.9 | Major preferences, key decisions |
| 0.8 | Standard preferences, important updates |
| 0.7 | Project milestones, context updates |
| 0.5-0.6 | General facts, minor observations |

## Database Location

Default: `E:\.openclaw\workspace\memory.db`

To change location, instantiate directly:

```python
from sqlite_memory import SQLiteMemory

mem = SQLiteMemory(r'D:\my-project\memory.db')
mem.store('preference', 'Custom location', importance=0.8)
```

## Backup

The `.db` file is a standard SQLite database. Copy it to backup:

```powershell
copy E:\.openclaw\workspace\memory.db E:\backups\memory-backup-2026-04-23.db
```

Or export to JSON:

```python
import sqlite3, json

conn = sqlite3.connect(r'E:\.openclaw\workspace\memory.db')
conn.row_factory = sqlite3.Row
rows = conn.execute('SELECT * FROM memories').fetchall()
data = [dict(r) for r in rows]
with open('memory-export.json', 'w') as f:
    json.dump(data, f, indent=2, default=str)
```
