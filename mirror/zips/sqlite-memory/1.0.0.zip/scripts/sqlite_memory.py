# -*- coding: utf-8 -*-
"""
SQLite Memory - 轻量级本地记忆系统
零费用、零API、纯本地SQLite
"""

import sqlite3
import json
import os
from datetime import datetime
from typing import List, Dict, Optional

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'memory.db')

class SQLiteMemory:
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self):
        """初始化数据库表"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT NOT NULL,  -- preference, decision, fact, project, correction
                    content TEXT NOT NULL,
                    context TEXT,  -- 额外上下文（JSON）
                    importance REAL DEFAULT 0.5,  -- 0.0~1.0
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_accessed TIMESTAMP,
                    access_count INTEGER DEFAULT 0
                )
            ''')
            
            conn.execute('''
                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_key TEXT NOT NULL,
                    summary TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_memories_category ON memories(category)
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_memories_importance ON memories(importance DESC)
            ''')
            conn.commit()
    
    def store(self, category: str, content: str, context: dict = None, importance: float = 0.5) -> int:
        """存储记忆
        
        Args:
            category: preference, decision, fact, project, correction
            content: 记忆内容
            context: 额外上下文字典
            importance: 重要程度 0.0~1.0
        
        Returns:
            记忆ID
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                '''INSERT INTO memories (category, content, context, importance)
                   VALUES (?, ?, ?, ?)''',
                (category, content, json.dumps(context) if context else None, importance)
            )
            conn.commit()
            return cursor.lastrowid
    
    def search(self, query: str, category: str = None, limit: int = 10) -> List[Dict]:
        """搜索记忆（简单文本匹配）
        
        Args:
            query: 搜索关键词
            category: 可选，限定类别
            limit: 返回数量
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            
            if category:
                cursor = conn.execute(
                    '''SELECT * FROM memories 
                       WHERE category = ? AND content LIKE ?
                       ORDER BY importance DESC, created_at DESC
                       LIMIT ?''',
                    (category, f'%{query}%', limit)
                )
            else:
                cursor = conn.execute(
                    '''SELECT * FROM memories 
                       WHERE content LIKE ?
                       ORDER BY importance DESC, created_at DESC
                       LIMIT ?''',
                    (f'%{query}%', limit)
                )
            
            results = []
            for row in cursor.fetchall():
                results.append({
                    'id': row['id'],
                    'category': row['category'],
                    'content': row['content'],
                    'context': json.loads(row['context']) if row['context'] else None,
                    'importance': row['importance'],
                    'created_at': row['created_at']
                })
            
            return results
    
    def get_recent(self, category: str = None, limit: int = 10) -> List[Dict]:
        """获取最近的记忆"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            
            if category:
                cursor = conn.execute(
                    '''SELECT * FROM memories WHERE category = ?
                       ORDER BY created_at DESC LIMIT ?''',
                    (category, limit)
                )
            else:
                cursor = conn.execute(
                    '''SELECT * FROM memories 
                       ORDER BY created_at DESC LIMIT ?''',
                    (limit,)
                )
            
            return [dict(row) for row in cursor.fetchall()]
    
    def get_stats(self) -> Dict:
        """获取记忆统计"""
        with sqlite3.connect(self.db_path) as conn:
            total = conn.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
            
            categories = conn.execute(
                '''SELECT category, COUNT(*) as count FROM memories
                   GROUP BY category'''
            ).fetchall()
            
            return {
                'total_memories': total,
                'categories': {row[0]: row[1] for row in categories},
                'db_path': self.db_path
            }
    
    def delete(self, memory_id: int) -> bool:
        """删除记忆"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute('DELETE FROM memories WHERE id = ?', (memory_id,))
            conn.commit()
            return cursor.rowcount > 0


# 便捷函数（全局实例）
_memory = None

def get_memory() -> SQLiteMemory:
    """获取全局记忆实例"""
    global _memory
    if _memory is None:
        _memory = SQLiteMemory()
    return _memory


def store_preference(content: str, importance: float = 0.8):
    """存储用户偏好"""
    return get_memory().store('preference', content, importance=importance)

def store_decision(content: str, context: dict = None, importance: float = 0.9):
    """存储决策"""
    return get_memory().store('decision', content, context, importance)

def store_fact(content: str, importance: float = 0.6):
    """存储事实"""
    return get_memory().store('fact', content, importance=importance)

def store_project_update(project: str, content: str, importance: float = 0.7):
    """存储项目更新"""
    return get_memory().store('project', content, {'project': project}, importance)

def store_correction(content: str, importance: float = 1.0):
    """存储修正（最高优先级）"""
    return get_memory().store('correction', content, importance=importance)

def search_memory(query: str, category: str = None, limit: int = 10):
    """搜索记忆"""
    return get_memory().search(query, category, limit)

def get_memory_stats():
    """获取统计"""
    return get_memory().get_stats()


if __name__ == '__main__':
    # 测试
    mem = SQLiteMemory()
    
    # 存储一些测试数据
    store_preference("方正扬不喜欢过度道歉")
    store_decision("疯狂奶茶杯使用鼠标模拟头动信号")
    store_project_update("milk-tea", "当前版本 v5.3.4")
    
    # 搜索
    results = search_memory("道歉")
    print(f"搜索'道歉': {len(results)} 条")
    for r in results:
        print(f"  [{r['category']}] {r['content']}")
    
    # 统计
    stats = get_memory_stats()
    print(f"\n记忆统计: {stats}")
