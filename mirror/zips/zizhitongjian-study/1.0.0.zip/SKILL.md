---
name: zizhi-tongjian
version: 1.0.0
description: 资治通鉴每日学习
license: PROPRIETARY

slash_commands:
  /zizhi-today: 今日学习内容
  /zizhi-day: 指定某天学习
  /zizhi-search: 搜索历史事件
  /zizhi-progress: 学习进度

capabilities:
  - daily_lesson
  - search_events
  - track_progress

dependencies: []

---

# 资治通鉴每日学习

按照《资治通鉴》原书顺序，每天推送一篇学习内容，包含原文、译文、解读。

## 功能
1. **每日学习**：按顺序推送原文 + 翻译 + 解读
2. **跳转学习**：指定卷数/年份学习
3. **搜索查询**：搜索历史事件、人物
4. **学习进度**：跟踪学习记录

## 使用
```
/zizhi-today          # 今日学习
/zizhi-day 1          # 学习第 1 卷
/zizhi-search 曹操     # 搜索相关事件
/zizhi-progress       # 查看学习进度
```

## 内容结构
每篇文档包含：
- **原文**：文言文原文
- **翻译**：白话文翻译
- **解读**：历史背景、人物分析、启示

## 学习周期
- 全书 294 卷，约 300 天学完
- 每天一篇，循序渐进
