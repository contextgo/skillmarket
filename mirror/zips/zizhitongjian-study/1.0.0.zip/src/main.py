#!/usr/bin/env python3
"""
资治通鉴每日学习 - 每天一篇历史经典
按原书顺序整理原文、翻译、解读
"""

import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any, List


# 资治通鉴部分原文数据（示例，实际应包含全书）
ZIZHI_TONGJIAN_DATA = [
    {
        "day": 1,
        "volume": "卷一·周纪一",
        "year": "公元前 403 年",
        "title": "三家分晋",
        "original": """初，智宣子将以瑶为后。智果曰：「不如宵也。瑶之贤于人者五，其不逮者一也。美鬓长大则贤，射御足力则贤，伎艺毕给则贤，巧文辩慧则贤，强毅果敢则贤，如是而甚不仁。夫以其五贤陵人，而以不仁行之，其谁能待之？若果立瑶，智宗必灭。」弗听，智果别族于太史为辅氏。

赵简子之子，长曰伯鲁，幼曰无恤。将置后，不知所立。乃书训诫之词于二简，以授二子曰：「谨识之。」三年而问之，伯鲁不能举其词，问其简，已失之矣。问无恤，诵其词甚习固。问其简，出诸袖中而奏之。于是简子以无恤为贤，立以为后。

简子使尹铎为晋阳。请曰：「以为茧丝乎？抑为保障乎？」简子曰：「保障哉！」尹铎损其户数。简子谓无恤曰：「晋国有难，而无以尹铎为少，无以晋阳为远，必以为归。」

及智宣子卒，智襄子为政，与韩康子、魏桓子宴于蓝台。智伯戏康子而侮段规，智国闻之，谏曰：「主不备难，难必至矣！」智伯曰：「难将由我。我不为难，孰敢兴之！」对曰：「不然。夏书有之：『一人三失，怨岂在明，不见是图。』夫君子能勤小物，故无大患。今主一宴而耻人之君相，又弗备，曰不敢兴难，无乃不可乎！蜹、蚁、蜂、虿，皆能害人，况君相乎！」弗听。""",
        "translation": """当初，智宣子准备立智瑶为继承人。智果说：「不如立智宵。智瑶比别人优秀的地方有五点，不如别人的地方有一点。鬓发美观、身材高大是一贤，善于射箭驾车、力气充足是一贤，技艺完备是一贤，巧文善辩、聪明机智是一贤，坚强果敢是一贤，如此五点而非常不仁。如果凭他的五点才能去欺凌别人，而以不仁的行为行事，谁能和他相处？如果真立智瑶为继承人，智氏宗族必定灭亡。」智宣子不听，智果向太史请求另立一族为辅氏。

赵简子的儿子，长子叫伯鲁，幼子叫无恤。赵简子准备立继承人，不知立谁好。于是他把训诫的话写在两块竹简上，分别交给两个儿子说：「好好记住。」过了三年，赵简子问他们，伯鲁背不出竹简上的话，问他的竹简，说已经丢了。问无恤，他熟练地背诵出来，问他的竹简，他从袖子中拿出来呈上。于是赵简子认为无恤贤能，立他为继承人。

赵简子派尹铎去治理晋阳。尹铎请示说：「是把晋阳当作榨取钱财的地方呢？还是当作安全的保障？」赵简子说：「当作保障！」尹铎就减少了纳税户数。赵简子对无恤说：「晋国如果有难，你不要嫌尹铎地位低，不要嫌晋阳路远，一定要把它作为归宿。」

等到智宣子去世，智襄子智瑶当政，与韩康子、魏桓子在蓝台饮宴。智伯戏弄韩康子，又侮辱他的家相段规。智国听说后，劝谏说：「主公您不防备祸难，祸难就一定会到来！」智伯说：「祸难将由我发起。我不发起祸难，谁敢发起！」智国回答说：「不是这样。《夏书》说：『一个人多次犯错，怨恨岂在明处，要在看不见时谋划。』君子能够注意小事，所以不会有大患。现在主公一次饮宴就羞辱人家的君主和宰相，又不防备，说『不敢有祸难』，恐怕不行吧！蚊虫、蚂蚁、蜂蝎，都能害人，何况是君主、宰相呢！」智伯不听。""",
        "interpretation": """### 历史背景

这是《资治通鉴》开篇第一个故事，记载了「三家分晋」的历史事件，标志着春秋时代的结束和战国时代的开始。

### 核心人物

1. **智瑶（智伯）**：智氏家族继承人，才华出众但为人不仁，最终导致家族灭亡。
2. **智果**：有远见的人，看出智瑶的致命弱点，提前脱离家族。
3. **赵无恤（赵襄子）**：赵氏继承人，善于记住父亲的教导，最终在晋阳之战中获胜。

### 核心启示

1. **才能与品德**：智瑶有五项过人才能，但因「不仁」这一致命缺陷导致身死族灭。才能再高，品德有亏，终究难成大事。

2. **细节决定成败**：智国劝谏「君子能勤小物，故无大患」，提醒智伯注意小节，但智伯不听，最终因轻视韩、魏而灭亡。

3. **居安思危**：智伯说「我不为难，孰敢兴之」，狂妄自大，不防备祸难，最终被三家联合消灭。

4. **用人之道**：赵简子通过竹简测试选择继承人，看重的是「记住教导」和「用心程度」，而非表面聪明。

### 原文金句

- 「夫以其五贤陵人，而以不仁行之，其谁能待之？」
- 「君子能勤小物，故无大患。」
- 「一人三失，怨岂在明，不见是图。」

### 现代启示

在职场和生活中，我们应当：
1. 注重品德修养，才能与品德并重
2. 注意细节，不要因小事得罪人
3. 谦虚谨慎，不要恃才傲物
4. 用心记住长辈和领导的教导""",
    },
    {
        "day": 2,
        "volume": "卷一·周纪一",
        "year": "公元前 403 年",
        "title": "智伯索地",
        "original": """智伯请地于韩康子，康子欲弗与。段规曰：「智伯好利而愎，不与，将伐我；不如与之。彼狃于得地，必请于他人；他人不与，必向之以兵。然则我得免于患而待事之变矣。」康子曰：「善。」使使者致万家之邑一于智伯。智伯悦。

又求地于魏桓子，桓子欲弗与。任章曰：「何故弗与？」桓子曰：「无故索地，故弗与。」任章曰：「无故索地，诸大夫必惧；吾与之地，智伯必骄。彼骄而轻敌，此惧而相亲。以相亲之兵待轻敌之人，智氏之命必不长矣。《周书》曰：『将欲败之，必姑辅之；将欲取之，必姑与之。』主不如与之以骄智伯，然后可以择交而图智氏矣。奈何独以吾为智氏质乎！」桓子曰：「善。」亦与之万家之邑一。

智伯又求蔡、皋狼之地于赵襄子，襄子弗与。智伯怒，帅韩、魏之甲以攻赵氏。""",
        "translation": """智伯向韩康子索要土地，韩康子不想给。段规说：「智伯贪图利益又刚愎自用，如果不给，他就要讨伐我们；不如给他。他得到土地后习以为常，必定会向别人索要；别人不给，他必定会动武。这样我们就可以免于祸患而等待事态变化了。」韩康子说：「好。」派使者把一个万户的城邑献给智伯。智伯很高兴。

智伯又向魏桓子索要土地，魏桓子不想给。任章说：「为什么不给？」魏桓子说：「他无缘无故索要土地，所以不给。」任章说：「无缘无故索要土地，各位大夫必定恐惧；我们给他土地，智伯必定骄傲。他骄傲就会轻敌，我们恐惧就会互相亲近。用互相亲近的军队对付轻敌的人，智氏的性命一定不会长了。《周书》说：『想要打败他，必须先暂时辅助他；想要夺取他，必须先暂时给他。』主公不如给他让智伯骄傲，然后可以选择盟友来对付智氏了。为什么偏偏让我们成为智伯攻击的目标呢！」魏桓子说：「好。」也献给他一个万户的城邑。

智伯又向赵襄子索要蔡、皋狼的土地，赵襄子不给。智伯大怒，率领韩、魏的军队进攻赵氏。""",
        "interpretation": """### 历史背景

智伯在得到韩、魏两家的土地后，更加骄横，又向赵襄子索地，遭到拒绝后发动战争，最终导致自己的灭亡。

### 核心策略

1. **韩康子的策略**：段规建议「与之」，避免成为第一个被攻击的目标，等待事态变化。

2. **魏桓子的策略**：任章提出「骄兵之计」，用土地让智伯骄傲轻敌，同时让其他家族恐惧而联合。

3. **赵襄子的选择**：坚决不给，选择正面抵抗。

### 核心启示

1. **欲擒故纵**：任章引用《周书》「将欲败之，必姑辅之；将欲取之，必姑与之」，是典型的欲擒故纵策略。

2. **骄兵必败**：智伯得到土地后更加骄傲，轻敌冒进，最终被三家联合消灭。

3. **团结对抗强权**：弱者联合可以对抗强者，韩、魏、赵三家最终联合消灭了强大的智氏。

4. **取舍之道**：暂时的退让不是懦弱，而是为了最终的胜利。

### 原文金句

- 「将欲败之，必姑辅之；将欲取之，必姑与之。」
- 「彼骄而轻敌，此惧而相亲。」

### 现代启示

在职场竞争中：
1. 面对贪婪的竞争对手，可以适当退让，让其骄傲
2. 团结同事，共同对抗不公平对待
3. 不要因小利而迷失方向""",
    },
    {
        "day": 3,
        "volume": "卷一·周纪一",
        "year": "公元前 403 年",
        "title": "晋阳之战",
        "original": """襄子惧，出奔晋阳而守之。智伯从之以韩、魏之甲。赵氏固守晋阳，智伯攻之，岁余不下。智伯引汾水以灌晋阳，城不没者三版。沈灶产蛙，民无叛意。

智伯行水，魏桓子御，韩康子骖乘。智伯曰：「吾乃今知水可以亡人国也。」桓子肘康子，康子履桓子之跗，以汾水可以灌安邑，绛水可以灌平阳也。

絺疵谓智伯曰：「韩、魏必反矣。」智伯曰：「子何以知之？」对曰：「以人事知之。夫从韩、魏之兵以攻赵，赵亡，难必及韩、魏矣。今约胜赵而三分其地，城不没者三版，人马相食，城降有日，而二子无喜志，有忧色，是非反而何？」

明日，智伯以絺疵之言告二子，二子曰：「此夫谗臣欲为赵氏游说，使主疑于二家而懈于攻赵氏也。不然，夫二家岂不利朝夕分赵氏之田，而欲为危难不可成之事乎？」二子出，絺疵入曰：「主何以臣之言告二子也？」智伯曰：「子何以知之？」对曰：「臣见其视臣端而趋疾，知臣得其情故也。」智伯不悛。絺疵请使于齐。""",
        "translation": """赵襄子恐惧，逃到晋阳坚守。智伯率领韩、魏的军队追击。赵氏固守晋阳，智伯攻打了年多也攻不下。智伯引汾水灌晋阳，城墙只差三版就被淹没。灶台被淹，里面生了青蛙，但百姓没有反叛之心。

智伯巡视水势，魏桓子驾车，韩康子陪乘。智伯说：「我现在知道水可以灭亡别人的国家了。」魏桓子用手肘碰韩康子，韩康子用脚踩魏桓子的脚背，因为汾水可以灌魏氏的安邑，绛水可以灌韩氏的平阳。

絺疵对智伯说：「韩、魏两家必定会反叛。」智伯说：「你怎么知道？」絺疵回答说：「从人情世故知道的。我们联合韩、魏的军队进攻赵氏，赵氏灭亡后，灾难必定会轮到韩、魏。现在约定战胜赵氏后三家平分土地，晋阳城只差三版就被淹没，城里人马相食，投降指日可待，但两位家主没有高兴的样子，反而有忧愁的神色，这不是要反叛是什么？」

第二天，智伯把絺疵的话告诉两位家主，两位家主说：「这是谗臣想替赵氏游说，让主公怀疑我们两家而放松对赵氏的进攻。不然的话，我们两家难道不想早点分到赵氏的土地，而要做危险不可能成功的事吗？」两位家主出去后，絺疵进来问：「主公为什么把臣的话告诉他们？」智伯说：「你怎么知道？」絺疵说：「臣见他们看臣的眼神严肃，脚步加快，知道臣已经了解他们的情况了。」智伯不悔改。絺疵请求出使齐国。""",
        "interpretation": """### 历史背景

这是晋阳之战的关键时刻，智伯水攻晋阳，但韩、魏两家已有反心，最终三家联合反攻，消灭了智氏。

### 关键细节

1. **城不没者三版**：城墙只差三版（约六尺）就被淹没，情况危急。

2. **沈灶产蛙，民无叛意**：灶台被淹生了青蛙，但百姓仍然坚守，说明赵氏得民心。

3. **肘足之谋**：魏桓子用手肘碰韩康子，韩康子用脚踩魏桓子，这是两人之间的暗号，表示互相警告。

4. **絺疵的洞察**：絺疵从韩、魏二人的表情看出他们有反心，但智伯不听。

### 核心启示

1. **得民心者得天下**：赵氏在极端困难的情况下，百姓仍然坚守，说明得民心。

2. **察言观色**：絺疵能从细节看出韩、魏的反心，但智伯不听劝告，最终失败。

3. **唇亡齿寒**：韩、魏明白赵氏灭亡后，自己也会遭殃，所以选择联合赵氏。

4. **骄兵必败**：智伯的狂妄和不听劝告，导致了自己的灭亡。

### 原文金句

- 「沈灶产蛙，民无叛意。」
- 「彼骄而轻敌，此惧而相亲。」

### 现代启示

在团队合作中：
1. 得民心才能成大事
2. 要善于听取不同的意见
3. 不要忽视细节和警告信号""",
    },
]


class ZhiTongJianSkill:
    """资治通鉴学习助手"""

    def __init__(self, data_dir: str = None):
        self.data_dir = data_dir or os.path.join(os.path.dirname(__file__), 'data')
        self.progress_file = os.path.join(self.data_dir, 'progress.json')
        self._load_progress()

    def _load_progress(self):
        """加载学习进度"""
        if os.path.exists(self.progress_file):
            with open(self.progress_file, 'r', encoding='utf-8') as f:
                self.progress = json.load(f)
        else:
            self.progress = {
                'current_day': 1,
                'completed_days': [],
                'start_date': datetime.now().strftime('%Y-%m-%d'),
                'last_study_date': None,
            }

    def _save_progress(self):
        """保存学习进度"""
        os.makedirs(self.data_dir, exist_ok=True)
        with open(self.progress_file, 'w', encoding='utf-8') as f:
            json.dump(self.progress, f, ensure_ascii=False, indent=2)

    def get_today_lesson(self) -> Optional[Dict]:
        """获取今日学习内容"""
        day = self.progress['current_day']
        return self.get_lesson_by_day(day)

    def get_lesson_by_day(self, day: int) -> Optional[Dict]:
        """获取指定天的学习内容"""
        for lesson in ZIZHI_TONGJIAN_DATA:
            if lesson['day'] == day:
                return lesson
        return None

    def get_random_lesson(self) -> Dict:
        """获取随机一篇学习内容"""
        import random
        return random.choice(ZIZHI_TONGJIAN_DATA)

    def search_lessons(self, keyword: str) -> List[Dict]:
        """搜索相关学习内容"""
        results = []
        for lesson in ZIZHI_TONGJIAN_DATA:
            if (keyword in lesson.get('title', '') or
                keyword in lesson.get('original', '') or
                keyword in lesson.get('translation', '') or
                keyword in lesson.get('interpretation', '')):
                results.append(lesson)
        return results

    def mark_completed(self, day: int):
        """标记某天学习完成"""
        if day not in self.progress['completed_days']:
            self.progress['completed_days'].append(day)
        self.progress['current_day'] = day + 1
        self.progress['last_study_date'] = datetime.now().strftime('%Y-%m-%d')
        self._save_progress()

    def get_progress_summary(self) -> Dict:
        """获取学习进度汇总"""
        total_lessons = len(ZIZHI_TONGJIAN_DATA)
        completed = len(self.progress['completed_days'])
        current = self.progress['current_day']

        return {
            'current_day': current,
            'completed_days': completed,
            'total_lessons': total_lessons,
            'progress_percent': f"{completed / total_lessons * 100:.1f}%" if total_lessons > 0 else "0%",
            'start_date': self.progress['start_date'],
            'last_study_date': self.progress['last_study_date'],
        }


def main():
    import argparse

    parser = argparse.ArgumentParser(description='资治通鉴每日学习')
    subparsers = parser.add_subparsers(dest='action')

    # today 命令 - 今日学习
    today_parser = subparsers.add_parser('today', help='今日学习内容')
    today_parser.add_argument('--complete', '-c', action='store_true', help='标记为已完成')

    # day 命令 - 指定某天学习
    day_parser = subparsers.add_parser('day', help='指定某天学习')
    day_parser.add_argument('day', type=int, help='第几天')
    day_parser.add_argument('--complete', '-c', action='store_true', help='标记为已完成')

    # search 命令 - 搜索
    search_parser = subparsers.add_parser('search', help='搜索历史事件')
    search_parser.add_argument('keyword', help='搜索关键词')

    # progress 命令 - 学习进度
    progress_parser = subparsers.add_parser('progress', help='学习进度')

    # random 命令 - 随机学习
    random_parser = subparsers.add_parser('random', help='随机学习一篇')

    args = parser.parse_args()

    skill = ZhiTongJianSkill()

    if args.action == 'today':
        lesson = skill.get_today_lesson()
        if lesson:
            print_lesson(lesson)
            if args.complete:
                skill.mark_completed(lesson['day'])
                print("\n✅ 已标记为已完成")
        else:
            print("🎉 恭喜！你已经学完了所有内容！")

    elif args.action == 'day':
        lesson = skill.get_lesson_by_day(args.day)
        if lesson:
            print_lesson(lesson)
            if args.complete:
                skill.mark_completed(args.day)
                print("\n✅ 已标记为已完成")
        else:
            print(f"❌ 未找到第{args.day}天的学习内容")

    elif args.action == 'search':
        results = skill.search_lessons(args.keyword)
        if results:
            print(f"\n📚 搜索到 {len(results)} 篇相关内容：\n")
            for i, lesson in enumerate(results, 1):
                print(f"{i}. 【{lesson['volume']}】{lesson['title']}")
                print(f"   年份：{lesson['year']}")
        else:
            print(f"❌ 未找到与「{args.keyword}」相关的内容")

    elif args.action == 'progress':
        summary = skill.get_progress_summary()
        print("\n📊 学习进度")
        print("=" * 50)
        print(f"当前天数：第{summary['current_day']}天")
        print(f"已完成：{summary['completed_days']}篇")
        print(f"总篇数：{summary['total_lessons']}篇")
        print(f"进度：{summary['progress_percent']}")
        print(f"开始日期：{summary['start_date']}")
        print(f"上次学习：{summary['last_study_date'] or '尚未学习'}")
        print("=" * 50)

    elif args.action == 'random':
        lesson = skill.get_random_lesson()
        print_lesson(lesson)

    else:
        parser.print_help()


def print_lesson(lesson: Dict):
    """打印学习内容"""
    print(f"\n{'='*60}")
    print(f"📖 资治通鉴 - 第{lesson['day']}天")
    print(f"{'='*60}")
    print(f"【{lesson['volume']}】")
    print(f"年份：{lesson['year']}")
    print(f"标题：{lesson['title']}")
    print(f"{'='*60}")

    print("\n📜 原文")
    print("-" * 60)
    print(lesson['original'])

    print("\n📝 翻译")
    print("-" * 60)
    print(lesson['translation'])

    print("\n💡 解读")
    print("-" * 60)
    print(lesson['interpretation'])

    print(f"\n{'='*60}")
    print("使用 --complete 或 -c 标记为已完成")
    print(f"{'='*60}\n")


if __name__ == '__main__':
    main()
