#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
餐饮品牌加盟分析报告 PDF 生成器

使用方法：
    python generate_report.py --brand "蜜雪冰城" --output report.pdf

依赖：
    pip install reportlab
"""

import argparse
import sys
from datetime import datetime
from pathlib import Path

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer,
        Table,
        TableStyle,
        PageBreak,
    )
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
except ImportError:
    print("错误：缺少 reportlab 库")
    print("请运行：pip install reportlab")
    sys.exit(1)


def setup_chinese_font():
    """设置中文字体支持"""
    # 尝试注册常见的中文字体
    font_paths = [
        # Windows
        "C:/Windows/Fonts/simhei.ttf",  # 黑体
        "C:/Windows/Fonts/msyh.ttc",    # 微软雅黑
        "C:/Windows/Fonts/simsun.ttc",  # 宋体
        # macOS
        "/System/Library/Fonts/PingFang.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
        # Linux
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",
    ]

    for font_path in font_paths:
        if Path(font_path).exists():
            try:
                pdfmetrics.registerFont(TTFont('ChineseFont', font_path))
                return 'ChineseFont'
            except Exception:
                continue

    # 如果找不到中文字体，返回默认字体（可能会有乱码）
    return 'Helvetica'


def create_styles(font_name):
    """创建文档样式"""
    styles = getSampleStyleSheet()

    # 标题样式
    styles.add(ParagraphStyle(
        name='ChineseTitle',
        fontName=font_name,
        fontSize=24,
        leading=30,
        alignment=1,  # 居中
        spaceAfter=20,
    ))

    # 副标题样式
    styles.add(ParagraphStyle(
        name='ChineseSubtitle',
        fontName=font_name,
        fontSize=14,
        leading=18,
        alignment=1,
        spaceAfter=30,
    ))

    # 章节标题样式
    styles.add(ParagraphStyle(
        name='ChineseHeading1',
        fontName=font_name,
        fontSize=16,
        leading=20,
        spaceBefore=20,
        spaceAfter=10,
        textColor=colors.HexColor('#1a1a1a'),
    ))

    # 小节标题样式
    styles.add(ParagraphStyle(
        name='ChineseHeading2',
        fontName=font_name,
        fontSize=13,
        leading=16,
        spaceBefore=15,
        spaceAfter=8,
        textColor=colors.HexColor('#333333'),
    ))

    # 正文样式
    styles.add(ParagraphStyle(
        name='ChineseBody',
        fontName=font_name,
        fontSize=10,
        leading=14,
        spaceAfter=6,
        firstLineIndent=20,
    ))

    # 列表样式
    styles.add(ParagraphStyle(
        name='ChineseList',
        fontName=font_name,
        fontSize=10,
        leading=14,
        spaceAfter=4,
        leftIndent=20,
    ))

    # 风险提示样式
    styles.add(ParagraphStyle(
        name='RiskRed',
        fontName=font_name,
        fontSize=10,
        leading=14,
        spaceAfter=4,
        leftIndent=20,
        textColor=colors.HexColor('#d32f2f'),
    ))

    styles.add(ParagraphStyle(
        name='RiskYellow',
        fontName=font_name,
        fontSize=10,
        leading=14,
        spaceAfter=4,
        leftIndent=20,
        textColor=colors.HexColor('#f57c00'),
    ))

    styles.add(ParagraphStyle(
        name='RiskGreen',
        fontName=font_name,
        fontSize=10,
        leading=14,
        spaceAfter=4,
        leftIndent=20,
        textColor=colors.HexColor('#388e3c'),
    ))

    return styles


def create_table(data, col_widths=None):
    """创建表格"""
    if col_widths is None:
        col_widths = [3*cm, 5*cm, 8*cm]

    table = Table(data, colWidths=col_widths)
    table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'ChineseFont'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e0e0e0')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor('#1a1a1a')),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cccccc')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f5f5f5')]),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    return table


def generate_pdf(brand_name, output_path, analysis_data=None):
    """生成 PDF 报告"""

    # 设置中文字体
    font_name = setup_chinese_font()
    styles = create_styles(font_name)

    # 创建文档
    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        rightMargin=2*cm,
        leftMargin=2*cm,
        topMargin=2*cm,
        bottomMargin=2*cm,
    )

    story = []

    # ========== 封面 ==========
    story.append(Spacer(1, 3*cm))
    story.append(Paragraph(brand_name, styles['ChineseTitle']))
    story.append(Paragraph("加盟分析报告", styles['ChineseTitle']))
    story.append(Spacer(1, 1*cm))
    story.append(Paragraph(
        f"生成日期：{datetime.now().strftime('%Y年%m月%d日')}",
        styles['ChineseSubtitle']
    ))
    story.append(PageBreak())

    # ========== 正文 ==========
    if analysis_data:
        # 使用提供的分析数据
        for section in analysis_data.get('sections', []):
            story.append(Paragraph(section['title'], styles['ChineseHeading1']))
            for content in section.get('content', []):
                if content['type'] == 'text':
                    story.append(Paragraph(content['text'], styles['ChineseBody']))
                elif content['type'] == 'table':
                    story.append(create_table(content['data']))
                    story.append(Spacer(1, 10))
    else:
        # 使用模板结构
        story.append(Paragraph("一、品牌发展史", styles['ChineseHeading1']))
        story.append(Paragraph(
            "【此处填充品牌发展史内容，包括品牌起源、品类定位、加盟历程等】",
            styles['ChineseBody']
        ))
        story.append(Spacer(1, 10))

        story.append(Paragraph("二、加盟模型分析", styles['ChineseHeading1']))
        story.append(Paragraph("2.1 费用结构总览", styles['ChineseHeading2']))
        story.append(Paragraph(
            "【此处填充费用结构表格】",
            styles['ChineseBody']
        ))
        story.append(Spacer(1, 10))

        story.append(Paragraph("2.2 品牌支持与约束体系", styles['ChineseHeading2']))
        story.append(Paragraph(
            "【此处填充支持体系表格】",
            styles['ChineseBody']
        ))
        story.append(Spacer(1, 10))

        story.append(Paragraph("2.3 合同关键点提示", styles['ChineseHeading2']))
        story.append(Paragraph(
            "【此处填充合同关键点】",
            styles['ChineseBody']
        ))
        story.append(Spacer(1, 10))

        story.append(Paragraph("三、加盟投资策略", styles['ChineseHeading1']))
        story.append(Paragraph(
            "【此处填充分城市/分预算/分经验的策略建议】",
            styles['ChineseBody']
        ))
        story.append(Spacer(1, 10))

        story.append(Paragraph("四、风险预警与补充建议", styles['ChineseHeading1']))
        story.append(Paragraph("红灯（强烈需谨慎）", styles['ChineseHeading2']))
        story.append(Paragraph(
            "【此处填充红灯风险】",
            styles['RiskRed']
        ))
        story.append(Spacer(1, 5))

        story.append(Paragraph("黄灯（可控风险）", styles['ChineseHeading2']))
        story.append(Paragraph(
            "【此处填充黄灯风险】",
            styles['RiskYellow']
        ))
        story.append(Spacer(1, 5))

        story.append(Paragraph("绿灯（可积极推进）", styles['ChineseHeading2']))
        story.append(Paragraph(
            "【此处填充绿灯条件】",
            styles['RiskGreen']
        ))
        story.append(Spacer(1, 10))

        story.append(Paragraph("补充建议", styles['ChineseHeading2']))
        story.append(Paragraph(
            "1. 至少实地走访 2–3 家在营门店",
            styles['ChineseList']
        ))
        story.append(Paragraph(
            "2. 尝试与 1–2 位加盟者简单聊天",
            styles['ChineseList']
        ))
        story.append(Paragraph(
            "3. 请专业人士或律师审核合同",
            styles['ChineseList']
        ))

    # 生成 PDF
    doc.build(story)
    print(f"PDF 报告已生成：{output_path}")
    return output_path


def main():
    parser = argparse.ArgumentParser(description="生成餐饮品牌加盟分析报告 PDF")
    parser.add_argument("--brand", required=True, help="品牌名称")
    parser.add_argument("--output", default=None, help="输出文件路径（默认：品牌名_加盟分析报告.pdf）")
    parser.add_argument("--data", default=None, help="分析数据 JSON 文件路径（可选）")

    args = parser.parse_args()

    # 设置输出路径
    if args.output is None:
        output_path = f"{args.brand}_加盟分析报告.pdf"
    else:
        output_path = args.output

    # 加载分析数据（如果提供）
    analysis_data = None
    if args.data:
        import json
        with open(args.data, 'r', encoding='utf-8') as f:
            analysis_data = json.load(f)

    # 生成 PDF
    generate_pdf(args.brand, output_path, analysis_data)


if __name__ == "__main__":
    main()