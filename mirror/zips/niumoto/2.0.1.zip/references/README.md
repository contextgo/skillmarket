# NIU Scooter API - 小牛电动车 API 工具

[English](#english) | [中文](#chinese)

<a name="chinese"></a>
## 中文介绍

通过小牛官方 APP API 读取电动车实时数据，包括电量、位置、里程、骑行记录等。

### 功能特性

- 获取电池状态（电量、温度、健康度、循环次数）
- 获取车辆实时状态（速度、充电状态、锁车状态、GPS位置）
- 查询骑行历史记录
- 计算日期范围内的里程统计
- 生成统计图表
- 导出 CSV 数据
- 电池健康度监控

### 快速开始

```bash
# 安装依赖
pip install requests==2.32.3 matplotlib==3.9.0

# 运行主脚本
python3 scripts/niu_reader.py <手机号> <密码>
```

### 脚本说明

| 脚本 | 功能 | 命令示例 |
|------|------|----------|
| `niu_reader.py` | 完整数据读取 | `python3 niu_reader.py 13800138000 password` |
| `generate_chart.py` | 生成统计图表 | `python3 generate_chart.py 13800138000 password output.png` |
| `export_csv.py` | 导出 CSV 数据 | `python3 export_csv.py 13800138000 password tracks.csv` |
| `battery_health.py` | 电池健康分析 | `python3 battery_health.py 13800138000 password` |

### API 说明

本工具使用小牛官方 APP 的开放 API：
- 认证地址：`https://account.niu.com`
- API 地址：`https://app-api.niu.com`
- 支持国内版和海外版账号

### 安全说明

- 本工具仅在本地执行，不会上传用户数据到第三方服务器
- 密码在传输前进行 MD5 加密
- 建议使用专用密码或二次验证码

### 免责声明

本工具为开源项目，仅供学习和研究使用。使用本工具可能违反小牛官方服务条款，请自行承担使用风险。

---

<a name="english"></a>
## English

Read NIU electric scooter data through the official APP API, including battery, location, mileage, riding records, etc.

### Features

- Get battery status (charge, temperature, health, cycles)
- Get vehicle real-time status (speed, charging, lock, GPS)
- Query riding history
- Calculate mileage within date range
- Generate statistical charts
- Export CSV data
- Battery health monitoring

### Quick Start

```bash
pip install requests==2.32.3 matplotlib==3.9.0
python3 scripts/niu_reader.py <phone> <password>
```

### Scripts

| Script | Function | Example |
|--------|----------|---------|
| `niu_reader.py` | Full data reader | `python3 niu_reader.py 13800138000 password` |
| `generate_chart.py` | Generate charts | `python3 generate_chart.py 13800138000 password output.png` |
| `export_csv.py` | Export CSV | `python3 export_csv.py 13800138000 password tracks.csv` |
| `battery_health.py` | Battery health | `python3 battery_health.py 13800138000 password` |

### Disclaimer

This is an open-source project for educational purposes only. Using this tool may violate NIU's Terms of Service. Use at your own risk.
