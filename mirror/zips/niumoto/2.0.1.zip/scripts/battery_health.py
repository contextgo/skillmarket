#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
电池健康度监控脚本
用法: python3 battery_health.py <手机号> <密码> [scooter_id]
"""

import hashlib
import json
import sys
from datetime import datetime

import requests


def login(username, password):
    url = "https://account.niu.com/v3/api/oauth2/token"
    md5_pw = hashlib.md5(password.encode("utf-8")).hexdigest()
    data = {
        "account": username,
        "password": md5_pw,
        "grant_type": "password",
        "scope": "base",
        "app_id": "niu_ktdrr960",
    }
    resp = requests.post(url, data=data, timeout=30)
    result = resp.json()
    if result.get("status") != 0:
        print(f"Login failed: {result}")
        return None
    return result["data"]["token"]["access_token"]


def get_vehicles(token):
    url = "https://app-api.niu.com/v5/scooter/list"
    headers = {"token": token}
    resp = requests.get(url, headers=headers, timeout=30)
    result = resp.json()
    if result.get("status") != 0:
        return None
    items = result["data"]["items"]
    return items


def get_battery_info(token, sn):
    url = "https://app-api.niu.com/v3/motor_data/battery_info"
    headers = {
        "token": token,
        "Accept-Language": "zh-CN",
        "user-agent": "manager/4.10.4 (android; IN2020 11);lang=zh-CN;clientIdentifier=Domestic;timezone=Asia/Shanghai;model=IN2020;deviceName=IN2020;ostype=android",
    }
    resp = requests.get(url, headers=headers, params={"sn": sn}, timeout=30)
    result = resp.json()
    if result.get("status") != 0:
        return None
    return result.get("data", {})


def analyze_battery(data):
    """分析电池状态"""
    batteries = data.get("batteries", {})
    comp_a = batteries.get("compartmentA", {})
    comp_b = batteries.get("compartmentB", {})

    print("\n" + "=" * 50)
    print("  BATTERY HEALTH REPORT")
    print("=" * 50)

    # 电池A
    print("\n[BATTERY A]")
    charge = comp_a.get('batteryCharging', 'N/A')
    health = comp_a.get('gradeBattery', 'N/A')
    temp = comp_a.get('temperature', 'N/A')
    cycles = comp_a.get('chargedTimes', 'N/A')
    bms_id = comp_a.get('bmsId', 'N/A')

    print(f"  Charge:     {charge}%")
    print(f"  Health:     {health}%")
    print(f"  Temperature: {temp}°C")
    print(f"  Cycles:     {cycles}")
    print(f"  BMS ID:     {bms_id}")

    # 健康度评估
    if isinstance(health, (int, float)):
        if health >= 90:
            status = "EXCELLENT ✨"
        elif health >= 80:
            status = "GOOD ✅"
        elif health >= 70:
            status = "FAIR ⚠️"
        else:
            status = "POOR ❌"
        print(f"  Status:     {status}")

    # 电池B（如果存在）
    if comp_b:
        print("\n[BATTERY B]")
        charge_b = comp_b.get('batteryCharging', 'N/A')
        health_b = comp_b.get('gradeBattery', 'N/A')
        temp_b = comp_b.get('temperature', 'N/A')
        cycles_b = comp_b.get('chargedTimes', 'N/A')

        print(f"  Charge:     {charge_b}%")
        print(f"  Health:     {health_b}%")
        print(f"  Temperature: {temp_b}°C")
        print(f"  Cycles:     {cycles_b}")

        if isinstance(health_b, (int, float)):
            if health_b >= 90:
                status_b = "EXCELLENT ✨"
            elif health_b >= 80:
                status_b = "GOOD ✅"
            elif health_b >= 70:
                status_b = "FAIR ⚠️"
            else:
                status_b = "POOR ❌"
            print(f"  Status:     {status_b}")

    # 温度预警
    print("\n[TEMPERATURE CHECK]")
    if isinstance(temp, (int, float)):
        if temp > 45:
            print(f"  ⚠️  WARNING: Battery temp {temp}°C is too HIGH!")
        elif temp < 0:
            print(f"  ⚠️  WARNING: Battery temp {temp}°C is too LOW!")
        else:
            print(f"  ✅  Temperature normal: {temp}°C")

    # 循环次数预估
    if isinstance(cycles, int):
        # 小牛电池通常寿命约 800-1000 次充放电循环
        remaining = max(0, 800 - cycles)
        print(f"\n[LIFETIME ESTIMATE]")
        print(f"  Current cycles: {cycles}")
        print(f"  Estimated remaining: ~{remaining} cycles")

    print("\n" + "=" * 50)

    # 返回关键数据用于追踪
    return {
        "timestamp": datetime.now().isoformat(),
        "battery_a": {
            "charge": charge,
            "health": health,
            "temperature": temp,
            "cycles": cycles,
        },
        "battery_b": {
            "charge": comp_b.get('batteryCharging'),
            "health": comp_b.get('gradeBattery'),
            "temperature": comp_b.get('temperature'),
            "cycles": comp_b.get('chargedTimes'),
        } if comp_b else None
    }


def save_history(data, filename="battery_history.jsonl"):
    """保存历史记录"""
    with open(filename, "a", encoding="utf-8") as f:
        f.write(json.dumps(data, ensure_ascii=False) + "\n")
    print(f"[OK] History saved to {filename}")


def main():
    if len(sys.argv) < 3:
        print("Usage: python3 battery_health.py <phone> <password> [scooter_id]")
        sys.exit(1)

    username = sys.argv[1]
    password = sys.argv[2]
    scooter_id = int(sys.argv[3]) if len(sys.argv) >= 4 else 0

    print("[*] Logging in...")
    token = login(username, password)
    if not token:
        sys.exit(1)

    print("[*] Getting vehicles...")
    vehicles = get_vehicles(token)
    if not vehicles or scooter_id >= len(vehicles):
        print("[FAIL] Vehicle not found")
        sys.exit(1)

    sn = vehicles[scooter_id]["sn_id"]
    name = vehicles[scooter_id].get("scooter_name", "NIU")
    print(f"[*] Vehicle: {name}")

    print("[*] Fetching battery info...")
    bat_data = get_battery_info(token, sn)
    if not bat_data:
        print("[FAIL] Failed to get battery data")
        sys.exit(1)

    result = analyze_battery(bat_data)
    save_history(result)


if __name__ == "__main__":
    main()
