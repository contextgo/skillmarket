#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
导出小牛电动车骑行记录到 CSV
用法: python3 export_csv.py <手机号> <密码> [output.csv]
"""

import csv
import hashlib
import sys
from datetime import datetime

import requests


def login(username, password):
    url = "https://account.niu.com/v3/api/oauth2/token"
    md5_pw = hashlib.md5(password.encode("utf-8")).hexdigest()
    data = {
        "account": username,
        "password": md5_pw,
        "grant_type": "password",
        "scope": "base",
        "app_id": "niu_ktdrr960",
    }
    resp = requests.post(url, data=data, timeout=30)
    result = resp.json()
    if result.get("status") != 0:
        print(f"Login failed: {result}")
        return None
    return result["data"]["token"]["access_token"]


def get_vehicles(token):
    url = "https://app-api.niu.com/v5/scooter/list"
    headers = {"token": token}
    resp = requests.get(url, headers=headers, timeout=30)
    result = resp.json()
    if result.get("status") != 0:
        return None
    items = result["data"]["items"]
    return items[0]["sn_id"]


def get_tracks(token, sn, pagesize=100):
    url = "https://app-api.niu.com/v5/track/list/v2"
    headers = {
        "token": token,
        "Accept-Language": "zh-CN",
        "User-Agent": "manager/1.0.0 (identifier);clientIdentifier=Domestic",
    }
    resp = requests.post(url, headers=headers, json={"index": "0", "pagesize": pagesize, "sn": sn}, timeout=30)
    result = resp.json()
    if result.get("status") != 0:
        return []
    return result.get("data", [])


def export_csv(tracks, output_path):
    """导出骑行记录到 CSV"""
    with open(output_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(['Date', 'Start Time', 'End Time', 'Distance(m)', 'Distance(km)',
                        'Avg Speed(km/h)', 'Duration(s)', 'Duration(min)'])

        for track in tracks:
            start_ts = track.get('startTime', 0) / 1000
            end_ts = track.get('endTime', 0) / 1000
            start_dt = datetime.fromtimestamp(start_ts)
            end_dt = datetime.fromtimestamp(end_ts)

            distance_m = track.get('distance', 0)
            distance_km = distance_m / 1000
            duration_s = track.get('ridingtime', 0)
            duration_min = duration_s / 60

            writer.writerow([
                start_dt.strftime('%Y-%m-%d'),
                start_dt.strftime('%H:%M:%S'),
                end_dt.strftime('%H:%M:%S'),
                distance_m,
                f'{distance_km:.2f}',
                track.get('avespeed', 0),
                duration_s,
                f'{duration_min:.1f}'
            ])

    print(f"Exported {len(tracks)} records to: {output_path}")


def main():
    if len(sys.argv) < 3:
        print("Usage: python3 export_csv.py <phone> <password> [output.csv]")
        sys.exit(1)

    username = sys.argv[1]
    password = sys.argv[2]
    output = sys.argv[3] if len(sys.argv) >= 4 else "niu_tracks.csv"

    print("[*] Logging in...")
    token = login(username, password)
    if not token:
        sys.exit(1)

    print("[*] Getting vehicle info...")
    sn = get_vehicles(token)

    print("[*] Fetching tracks...")
    tracks = get_tracks(token, sn, pagesize=100)
    print(f"[*] Got {len(tracks)} tracks")

    print("[*] Exporting to CSV...")
    export_csv(tracks, output)


if __name__ == "__main__":
    main()
