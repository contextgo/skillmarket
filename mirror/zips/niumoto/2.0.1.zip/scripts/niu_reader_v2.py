#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小牛电动车数据读取工具 - 双模式版
支持: 官方 MCP API (推荐) + 逆向 APP API (补充)
用法: python3 niu_reader_v2.py [mode] [credentials]
"""

import hashlib
import json
import os
import sys
from datetime import datetime, timedelta

import requests

# ============ 配置 ============
# 官方 MCP API
OFFICIAL_API_URL = "https://ai-mcp.niu.com/claw/scooter_info"

# 逆向 API
ACCOUNT_BASE_URL_CN = "https://account.niu.com"
API_BASE_URL_CN = "https://app-api.niu.com"
LOGIN_URI = "/v3/api/oauth2/token"
MOTOR_BATTERY_API_URI = "/v3/motor_data/battery_info"
MOTOR_INDEX_API_URI = "/v5/scooter/motor_data/index_info"
MOTOINFO_LIST_API_URI = "/v5/scooter/list"
MOTOINFO_ALL_API_URI = "/motoinfo/overallTally"
TRACK_LIST_API_URI = "/v5/track/list/v2"
APP_ID = "niu_ktdrr960"


class NiuOfficialAPI:
    """小牛官方 MCP API 客户端"""

    def __init__(self, api_key=None):
        self.api_key = api_key or self._get_api_key()

    def _get_api_key(self):
        """从环境变量或配置文件获取 API Key"""
        # 1. 环境变量
        key = os.environ.get('NIU_API_KEY')
        if key:
            return key

        # 2. OpenClaw 配置文件
        config_paths = [
            os.path.expanduser('~/.openclaw/openclaw.json'),
            '/data/.clawdbot/openclaw.json',
        ]
        for path in config_paths:
            if os.path.exists(path):
                try:
                    with open(path, 'r') as f:
                        config = json.load(f)
                        key = config.get('skills', {}).get('entries', {}).get('niu-vehicle', {}).get('apiKey')
                        if key:
                            return key
                except:
                    pass

        return None

    def get_status(self):
        """获取车辆状态"""
        if not self.api_key:
            print("[ERROR] NIU_API_KEY not found. Please set it as environment variable or in OpenClaw config.")
            print("[INFO] Get your API key from NIU app: 我的 → API-Key Management")
            return None

        url = f"{OFFICIAL_API_URL}?key={self.api_key}"
        try:
            resp = requests.get(url, timeout=30)
            result = resp.json()

            if result.get('status') != 0:
                print(f"[ERROR] API error: {result}")
                return None

            return result.get('data', {})
        except Exception as e:
            print(f"[ERROR] Request failed: {e}")
            return None

    def print_status(self):
        """打印状态报告"""
        data = self.get_status()
        if not data:
            return False

        print("\n" + "=" * 50)
        print("  NIU Scooter Status (Official API)")
        print("=" * 50)
        print(f"\n  Battery:      {data.get('batteryLevel', 'N/A')}%")
        print(f"  Range:        {data.get('estimatedRange', 'N/A')} km")
        print(f"  Charging:     {'Yes' if data.get('isCharging') else 'No'}")
        if data.get('isCharging'):
            print(f"  Time Left:    {data.get('chargingRemainingTime', 'N/A')} min")
        print(f"  Location:     {data.get('location', 'N/A')}")
        print(f"  Total Mileage: {data.get('totalMileage', 'N/A')} km")
        print(f"  Last Update:  {data.get('lastUpdate', 'N/A')}")
        print("\n" + "=" * 50)
        return True


class NiuReverseAPI:
    """逆向 APP API 客户端 (原 niu-scooter-api 功能)"""

    def __init__(self, username, password, scooter_id=0, use_cn=True):
        self.username = username
        self.password = password
        self.scooter_id = int(scooter_id)
        self.use_cn = use_cn
        self.token = None
        self.sn = None
        self.scooter_name = None

        if use_cn:
            self.account_base_url = ACCOUNT_BASE_URL_CN
            self.api_base_url = API_BASE_URL_CN
        else:
            self.account_base_url = "https://account-fk.niu.com"
            self.api_base_url = "https://app-api-fk.niu.com"

        self.data_bat = None
        self.data_moto = None
        self.data_moto_info = None
        self.data_track = None

    def login(self):
        url = f"{self.account_base_url}{LOGIN_URI}"
        md5_password = hashlib.md5(self.password.encode("utf-8")).hexdigest()
        data = {
            "account": self.username,
            "password": md5_password,
            "grant_type": "password",
            "scope": "base",
            "app_id": APP_ID,
        }

        version = "CN" if self.use_cn else "INTL"
        print(f"[*] Login ({version}): {self.username} ...")
        resp = requests.post(url, data=data, timeout=30)
        result = resp.json()

        if result.get("status") != 0:
            print(f"[FAIL] Login failed: {result.get('desc', 'Unknown error')}")
            return False

        self.token = result["data"]["token"]["access_token"]
        print("[OK] Login success")
        return True

    def get_vehicles(self):
        url = f"{self.api_base_url}{MOTOINFO_LIST_API_URI}"
        headers = {"token": self.token}
        resp = requests.get(url, headers=headers, timeout=30)
        result = resp.json()

        if result.get("status") != 0:
            return False

        items = result["data"]["items"]
        print(f"[*] Found {len(items)} vehicle(s):")
        for idx, item in enumerate(items):
            print(f"    [{idx}] {item.get('scooter_name', 'Unnamed')}")

        if self.scooter_id >= len(items):
            print(f"[FAIL] scooter_id {self.scooter_id} out of range")
            return False

        self.sn = items[self.scooter_id]["sn_id"]
        self.scooter_name = items[self.scooter_id].get("scooter_name", "NIU")
        print(f"[OK] Selected: {self.scooter_name}")
        return True

    def _api_get(self, path):
        url = f"{self.api_base_url}{path}"
        headers = {
            "token": self.token,
            "Accept-Language": "zh-CN",
            "user-agent": "manager/4.10.4 (android; IN2020 11);lang=zh-CN;clientIdentifier=Domestic;timezone=Asia/Shanghai;model=IN2020;deviceName=IN2020;ostype=android",
        }
        try:
            resp = requests.get(url, headers=headers, params={"sn": self.sn}, timeout=30)
            result = resp.json()
        except Exception as e:
            print(f"[ERROR] API error [{path}]: {e}")
            return None

        if result.get("status") != 0:
            return None
        return result

    def _api_post(self, path, payload=None):
        url = f"{self.api_base_url}{path}"
        headers = {
            "token": self.token,
            "Accept-Language": "zh-CN",
            "User-Agent": "manager/1.0.0 (identifier);clientIdentifier=Domestic",
        }
        data = payload or {"sn": self.sn}
        try:
            resp = requests.post(url, headers=headers, json=data, timeout=30)
            result = resp.json()
        except Exception as e:
            print(f"[ERROR] API error [{path}]: {e}")
            return None

        if result.get("status") != 0:
            return None
        return result

    def fetch_battery(self):
        print("[*] Fetching battery info...")
        self.data_bat = self._api_get(MOTOR_BATTERY_API_URI)
        return self.data_bat is not None

    def fetch_motor_data(self):
        print("[*] Fetching motor data...")
        self.data_moto = self._api_get(MOTOR_INDEX_API_URI)
        return self.data_moto is not None

    def fetch_overall(self):
        print("[*] Fetching overall stats...")
        self.data_moto_info = self._api_get(MOTOINFO_ALL_API_URI)
        return self.data_moto_info is not None

    def fetch_track(self, pagesize=50):
        print(f"[*] Fetching track records ({pagesize})...")
        self.data_track = self._api_post(
            TRACK_LIST_API_URI,
            payload={"index": "0", "pagesize": pagesize, "sn": self.sn},
        )
        return self.data_track is not None

    def calculate_distance_in_range(self, start_date_str, end_date_str):
        if not self.data_track or not self.data_track.get("data"):
            return None, {}

        tracks = self.data_track["data"]
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date()

        total_distance = 0
        daily_stats = {}

        for track in tracks:
            start_time_ts = track.get("startTime", 0) / 1000
            track_dt = datetime.fromtimestamp(start_time_ts)
            track_date = track_dt.date()

            if start_date <= track_date <= end_date:
                distance = track.get("distance", 0)
                total_distance += distance
                date_str = track_date.strftime("%Y-%m-%d")
                if date_str not in daily_stats:
                    daily_stats[date_str] = {"count": 0, "distance": 0}
                daily_stats[date_str]["count"] += 1
                daily_stats[date_str]["distance"] += distance

        return total_distance, daily_stats

    def print_report(self):
        print("\n" + "=" * 50)
        print(f"  NIU Scooter Report: {self.scooter_name}")
        print("  (Reverse API - Enhanced Data)")
        print("=" * 50)

        if self.data_bat:
            bat = self.data_bat.get("data", {})
            print("\n[BATTERY]")
            batteries = bat.get("batteries", {})
            comp_a = batteries.get("compartmentA", {})
            print(f"  Charge:     {comp_a.get('batteryCharging', 'N/A')}%")
            print(f"  Health:     {comp_a.get('gradeBattery', 'N/A')}%")
            print(f"  Temp:       {comp_a.get('temperature', 'N/A')}C")
            print(f"  Cycles:     {comp_a.get('chargedTimes', 'N/A')}")
            if "compartmentB" in batteries:
                comp_b = batteries.get("compartmentB", {})
                print(f"  Bat-B:      {comp_b.get('batteryCharging', 'N/A')}%")

        if self.data_moto:
            moto = self.data_moto.get("data", {})
            print("\n[STATUS]")
            print(f"  Speed:      {moto.get('nowSpeed', 'N/A')} km/h")
            print(f"  Online:     {'Yes' if moto.get('isConnected') else 'No'}")
            print(f"  Charging:   {'Yes' if moto.get('isCharging') else 'No'}")
            print(f"  Locked:     {'Yes' if moto.get('lockStatus') else 'No'}")
            print(f"  Range:      {moto.get('estimatedMileage', 'N/A')} km")
            pos = moto.get("postion", {})
            if pos:
                print(f"  GPS:        {pos.get('lat', 'N/A')}, {pos.get('lng', 'N/A')}")

        if self.data_moto_info:
            info = self.data_moto_info.get("data", {})
            print(f"\n[OVERALL]")
            print(f"  Total:      {info.get('totalMileage', 'N/A')} km")
            print(f"  Days:       {info.get('bindDaysCount', 'N/A')}")

        if self.data_track:
            tracks = self.data_track.get("data", [])
            if tracks:
                print(f"\n[TRACKS] {len(tracks)} records")
                total_dist, daily_stats = self.calculate_distance_in_range(
                    (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"),
                    datetime.now().strftime("%Y-%m-%d")
                )
                if total_dist is not None:
                    print(f"  Last 7 days: {total_dist/1000:.2f} km")
                    for date in sorted(daily_stats.keys())[-5:]:
                        stats = daily_stats[date]
                        print(f"    {date}: {stats['distance']/1000:.2f} km ({stats['count']} trips)")

        print("\n" + "=" * 50)

    def run(self):
        if not self.login():
            return False
        if not self.get_vehicles():
            return False
        self.fetch_battery()
        self.fetch_motor_data()
        self.fetch_overall()
        self.fetch_track(pagesize=50)
        self.print_report()
        return True


def main():
    print("=" * 60)
    print("  NIU Scooter Data Reader v2.0")
    print("  Mode 1: Official MCP API (Recommended)")
    print("  Mode 2: Reverse APP API (Enhanced)")
    print("=" * 60)

    if len(sys.argv) < 2:
        print("\nUsage:")
        print("  Mode 1 (Official): python3 niu_reader_v2.py official [API_KEY]")
        print("  Mode 2 (Reverse):  python3 niu_reader_v2.py reverse <phone> <password> [scooter_id]")
        print("\n  If API_KEY not provided, will read from NIU_API_KEY env var")
        sys.exit(1)

    mode = sys.argv[1].lower()

    if mode == "official":
        api_key = sys.argv[2] if len(sys.argv) >= 3 else None
        api = NiuOfficialAPI(api_key)
        success = api.print_status()

    elif mode == "reverse":
        if len(sys.argv) < 4:
            print("[ERROR] Mode 'reverse' requires: <phone> <password>")
            sys.exit(1)
        username = sys.argv[2]
        password = sys.argv[3]
        scooter_id = int(sys.argv[4]) if len(sys.argv) >= 5 else 0

        reader = NiuReverseAPI(username, password, scooter_id, use_cn=True)
        success = reader.run()

        if not success:
            print("\n[!] Trying INTL API...")
            reader = NiuReverseAPI(username, password, scooter_id, use_cn=False)
            success = reader.run()
    else:
        print(f"[ERROR] Unknown mode: {mode}. Use 'official' or 'reverse'")
        sys.exit(1)

    if not success:
        sys.exit(1)


if __name__ == "__main__":
    main()
