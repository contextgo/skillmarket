#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成小牛电动车骑行统计图表
用法: python3 generate_chart.py <手机号> <密码> [output_path]
"""

import hashlib
import sys
from datetime import datetime, timedelta

import matplotlib
import matplotlib.pyplot as plt
import requests

matplotlib.rcParams['font.family'] = ['DejaVu Sans', 'Liberation Sans', 'sans-serif']
matplotlib.rcParams['axes.unicode_minus'] = False


def login(username, password):
    url = "https://account.niu.com/v3/api/oauth2/token"
    md5_pw = hashlib.md5(password.encode("utf-8")).hexdigest()
    data = {
        "account": username,
        "password": md5_pw,
        "grant_type": "password",
        "scope": "base",
        "app_id": "niu_ktdrr960",
    }
    resp = requests.post(url, data=data, timeout=30)
    result = resp.json()
    if result.get("status") != 0:
        print(f"Login failed: {result}")
        return None
    return result["data"]["token"]["access_token"]


def get_vehicles(token):
    url = "https://app-api.niu.com/v5/scooter/list"
    headers = {"token": token}
    resp = requests.get(url, headers=headers, timeout=30)
    result = resp.json()
    if result.get("status") != 0:
        return None
    items = result["data"]["items"]
    return items[0]["sn_id"], items[0].get("scooter_name", "NIU")


def get_tracks(token, sn, pagesize=50):
    url = "https://app-api.niu.com/v5/track/list/v2"
    headers = {
        "token": token,
        "Accept-Language": "zh-CN",
        "User-Agent": "manager/1.0.0 (identifier);clientIdentifier=Domestic",
    }
    resp = requests.post(url, headers=headers, json={"index": "0", "pagesize": pagesize, "sn": sn}, timeout=30)
    result = resp.json()
    if result.get("status") != 0:
        return []
    return result.get("data", [])


def generate_chart(tracks, output_path="niu_chart.png", days=7):
    """生成近 N 天的骑行统计图表"""
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=days - 1)

    daily = {}
    for i in range(days):
        d = (start_date + timedelta(days=i)).strftime("%m-%d")
        daily[d] = {"km": 0, "count": 0}

    for track in tracks:
        ts = track.get("startTime", 0) / 1000
        dt = datetime.fromtimestamp(ts)
        date_str = dt.strftime("%m-%d")
        if date_str in daily:
            daily[date_str]["km"] += track.get("distance", 0) / 1000
            daily[date_str]["count"] += 1

    dates = list(daily.keys())
    kms = [daily[d]["km"] for d in dates]
    counts = [daily[d]["count"] for d in dates]

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8), gridspec_kw={'height_ratios': [2, 1]})

    total_km = sum(kms)
    total_count = sum(counts)
    fig.suptitle(f'NIU Scooter Stats ({start_date} ~ {end_date})', fontsize=16, fontweight='bold')
    fig.text(0.5, 0.93, f'Total: {total_km:.2f}km | {total_count} trips | Avg: {total_km/days:.2f}km/day',
             ha='center', fontsize=11, color='gray')

    colors = ['#FF6B6B' if v == max(kms) and v > 0 else '#4ECDC4' if v == min([x for x in kms if x > 0] or [0]) and v > 0 else '#45B7D1' for v in kms]

    bars = ax1.bar(dates, kms, color=colors, edgecolor='white', linewidth=1.5, alpha=0.85)
    ax1.set_ylabel('Distance (km)', fontsize=11)
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)

    for bar, val, cnt in zip(bars, kms, counts):
        if val > 0:
            ax1.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.2,
                     f'{val:.2f}km\n({cnt})',
                     ha='center', va='bottom', fontsize=8, fontweight='bold')

    ax2.plot(dates, kms, marker='o', linewidth=2, markersize=6, color='#FF6B6B')
    ax2.fill_between(dates, kms, alpha=0.2, color='#FF6B6B')
    ax2.set_ylabel('Distance (km)', fontsize=11)
    ax2.set_xlabel('Date', fontsize=11)
    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    ax2.grid(True, alpha=0.3, linestyle='--')

    plt.tight_layout(rect=[0, 0, 1, 0.92])
    plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print(f"Chart saved: {output_path}")


def main():
    if len(sys.argv) < 3:
        print("Usage: python3 generate_chart.py <phone> <password> [output.png]")
        sys.exit(1)

    username = sys.argv[1]
    password = sys.argv[2]
    output = sys.argv[3] if len(sys.argv) >= 4 else "niu_chart.png"

    print("[*] Logging in...")
    token = login(username, password)
    if not token:
        sys.exit(1)

    print("[*] Getting vehicle info...")
    sn, name = get_vehicles(token)
    print(f"[*] Vehicle: {name}")

    print("[*] Fetching tracks...")
    tracks = get_tracks(token, sn, pagesize=100)
    print(f"[*] Got {len(tracks)} tracks")

    print("[*] Generating chart...")
    generate_chart(tracks, output, days=7)


if __name__ == "__main__":
    main()
