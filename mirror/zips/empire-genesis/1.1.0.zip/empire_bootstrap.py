import os
import sys
import platform
import sqlite3
import json

# --- 1. 环境适配与路径初始化 ---
OS_TYPE = platform.system()
# __file__ 指向 skills/empire-genesis/empire_bootstrap.py
# '..','..' 回到 workspace/（即 .openclaw 的工作根目录）
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
DB_PATH = os.path.join(BASE_DIR, 'state', 'system.db')
AGENT_DIR = os.path.join(BASE_DIR, 'agents')

def get_db_conn():
    """带系统适配的数据库连接（吸收了并发锁死的教训）"""
    timeout = 20 if OS_TYPE == "Windows" else 5
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    return sqlite3.connect(DB_PATH, timeout=timeout)

# --- 2. 数据库创世 (StateDB Schema) ---
def init_statedb():
    print("[1/4] 开始初始化帝国 StateDB...")
    with get_db_conn() as conn:
        cursor = conn.cursor()

        # 任务账本
        cursor.execute('''CREATE TABLE IF NOT EXISTS task_ledger (
            id TEXT PRIMARY KEY, parent_id TEXT, handler_role TEXT,
            status TEXT DEFAULT 'pending', payload JSON, result JSON,
            last_heartbeat DATETIME, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)''')

        # 帝国教训（Signal Protocol v2：lesson_hash 唯一索引 + hit_count + category）
        cursor.execute('''CREATE TABLE IF NOT EXISTS empire_lessons (
            id INTEGER PRIMARY KEY AUTOINCREMENT, domain TEXT, failure_pattern TEXT,
            solution TEXT, category TEXT DEFAULT 'business', severity INTEGER DEFAULT 5,
            hit_count INTEGER DEFAULT 1, lesson_hash TEXT UNIQUE)''')

        # 事实黑板（双时标：event_time + collection_time）
        cursor.execute('''CREATE TABLE IF NOT EXISTS blackboard (
            key TEXT PRIMARY KEY, value TEXT, updated_by TEXT,
            event_time DATETIME, collection_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            source_weight REAL DEFAULT 0.5)''')

        # 哨兵心跳
        cursor.execute('''CREATE TABLE IF NOT EXISTS agent_heartbeat (
            agent_id TEXT PRIMARY KEY, agent_role TEXT, status TEXT DEFAULT 'online',
            last_seen DATETIME DEFAULT CURRENT_TIMESTAMP, current_task_id TEXT)''')

        conn.commit()
    print("[OK] StateDB 架构部署完毕。")

# --- 3. Agent 编制核查与创建 ---
def init_agents():
    print("[2/4] 开始核查帝国编制...")
    required_agents = {
        "research-agent": "搜索汇总助理：负责外部数据抓取与实时 facts 写入。",
        "execution-agent": "执行助理：负责调用具体工具完成结构化操作。",
        "verification-agent": "验证助理：负责交叉审计 facts 表，揪出逻辑矛盾并提炼 lessons。"
    }

    os.makedirs(AGENT_DIR, exist_ok=True)

    for agent_name, desc in required_agents.items():
        agent_path = os.path.join(AGENT_DIR, agent_name)
        if not os.path.exists(agent_path):
            os.makedirs(agent_path)
            with open(os.path.join(agent_path, 'agent.json'), 'w', encoding='utf-8') as f:
                json.dump({"name": agent_name, "model": "gemini-1.5-flash"}, f, indent=2)
            with open(os.path.join(agent_path, 'SOUL.md'), 'w', encoding='utf-8') as f:
                f.write("# Role: %s\n\n## 定位\n%s\n\n## 铁律\n1. 所有高价值数据必须入库 StateDB。\n2. 严禁复述重复的系统告警。" % (agent_name, desc))
            print("  [+] 新建补齐静态 Agent: %s" % agent_name)
        else:
            print("  [=] Agent 已存在: %s" % agent_name)
    print("[OK] 帝国编制 (3+1) 核查完毕。")

# --- 4. 生成看门狗哨兵进程 ---
def init_watchdog():
    print("[3/4] 正在生成帝国监军 (Watchdog v2.1)...")

    # 用 %-formatting 避免 {db_path} 以外的花括号冲突；DB_PATH 用 %s 注入
    safe_path = DB_PATH.replace('\\', '\\\\')
    watchdog_code = (
        "import sqlite3\n"
        "import time\n"
        "import datetime\n"
        "import pathlib\n\n"
        "DB_PATH = r'%s'\n\n"
        "def get_conn():\n"
        "    return sqlite3.connect(DB_PATH, timeout=20)\n\n"
        "def now_iso():\n"
        "    return datetime.datetime.now().isoformat()\n\n"
        "def log(msg):\n"
        "    ts = datetime.datetime.now().isoformat()\n"
        "    print('[%%s] %%s' %% (ts, msg), flush=True)\n\n"
        "def proxy_agent_heartbeat():\n"
        "    try:\n"
        "        with get_conn() as conn:\n"
        "            c = conn.cursor()\n"
        "            now_str = now_iso()\n"
        "            c.execute(\n"
        "                'UPDATE agent_heartbeat SET last_seen=? '\n"
        "                'WHERE status=' + \"'online'\" + ' AND agent_id NOT IN (' + \"'watchdog'\" + ',' + \"'main'\" + ')',\n"
        "                (now_str,)\n"
        "            )\n"
        "            updated = c.rowcount\n"
        "            conn.commit()\n"
        "            if updated:\n"
        "                log('[哨兵补丁] 续命 ' + str(updated) + ' 个 Agent last_seen')\n"
        "    except Exception as e:\n"
        "        log('[哨兵补丁] 代理签发失败: ' + str(e))\n\n"
        "def check_agent_heartbeats():\n"
        "    try:\n"
        "        with get_conn() as conn:\n"
        "            c = conn.cursor()\n"
        "            c.execute('SELECT agent_id, last_seen, current_task_id FROM agent_heartbeat')\n"
        "            now = datetime.datetime.now()\n"
        "            for agent_id, last_seen, current_task_id in c.fetchall():\n"
        "                if last_seen:\n"
        "                    last_t = datetime.datetime.fromisoformat(last_seen)\n"
        "                    age = (now - last_t).total_seconds()\n"
        "                    if age > 600:\n"
        "                        log('[ALERT] Agent ' + agent_id + ' silent ' + str(int(age)) + 's (>600s)')\n"
        "    except Exception as e:\n"
        "        log('[ERROR] check_agent_heartbeats failed: ' + str(e))\n\n"
        "def tick():\n"
        "    try:\n"
        "        with get_conn() as conn:\n"
        "            c = conn.cursor()\n"
        "            c.execute(\n"
        "                'INSERT INTO audit_log (ts, agent_id, action, detail) VALUES (?, ?, ?, ?)',\n"
        "                (now_iso(), 'watchdog', 'tick', 'watchdog alive at ' + now_iso())\n"
        "            )\n"
        "            conn.commit()\n"
        "    except Exception as e:\n"
        "        log('[ERROR] tick log failed: ' + str(e))\n"
        "    check_agent_heartbeats()\n"
        "    proxy_agent_heartbeat()\n"
        "    log('Tick complete')\n\n"
        "def run():\n"
        "    log('Watchdog v2.1 starting... 哨兵补丁 active.')\n"
        "    while True:\n"
        "        try:\n"
        "            tick()\n"
        "        except Exception as e:\n"
        "            log('[ERROR] tick error: ' + str(e))\n"
        "        time.sleep(60)\n\n"
        "if __name__ == '__main__':\n"
        "    run()\n"
    ) % safe_path

    watchdog_path = os.path.join(os.path.dirname(DB_PATH), 'watchdog_signal_v2.py')
    with open(watchdog_path, 'w', encoding='utf-8') as f:
        f.write(watchdog_code)

    print("[OK] 看门狗核心逻辑已写入: %s" % watchdog_path)

# --- 5. 帝国出厂质检与无痕清理 ---
def run_post_flight_checks():
    print("[4/4] 启动帝国出厂质检 (沙箱模拟)...")
    try:
        with get_db_conn() as conn:
            cursor = conn.cursor()

            # 测试 1：冷链任务 (验证事实表与双时标)
            print("  -> [测试1: 小龙虾冷链演习] 事实写入校验...")
            cursor.execute('''
                INSERT INTO blackboard (key, value, updated_by, event_time, collection_time)
                VALUES ('test_lobster_price', '25元/斤', 'research-agent',
                        '2026-04-10 12:00:00', CURRENT_TIMESTAMP)
            ''')
            cursor.execute("SELECT key FROM blackboard WHERE key='test_lobster_price'")
            if not cursor.fetchone():
                raise Exception("事实表写入失败")

            # 测试 2：铁猪行动 (验证 Signal Protocol 去重机制)
            print("  -> [测试2: 铁猪行动] 告警风暴去重校验...")
            test_hash = 'test_hash_pig_alert_001'
            cursor.execute('''
                INSERT INTO empire_lessons (domain, failure_pattern, category, lesson_hash, hit_count)
                VALUES ('test', '模拟死机告警', 'system', ?, 1)
            ''', (test_hash,))
            cursor.execute('''
                INSERT INTO empire_lessons (domain, failure_pattern, category, lesson_hash, hit_count)
                VALUES ('test', '模拟死机告警', 'system', ?, 1)
                ON CONFLICT(lesson_hash) DO UPDATE SET hit_count = hit_count + 1
            ''', (test_hash,))
            cursor.execute("SELECT hit_count FROM empire_lessons WHERE lesson_hash=?", (test_hash,))
            hit_count = cursor.fetchone()[0]
            if hit_count != 2:
                raise Exception("去重协议失效，预期 hits=2，实际=%d" % hit_count)

            print("  [OK] 质检全量通过！双时标与指纹去重生效。")

            # 无痕清理 (阅后即焚)
            print("  -> [清理] 销毁沙箱测试数据...")
            cursor.execute("DELETE FROM blackboard WHERE key LIKE 'test_%'")
            cursor.execute("DELETE FROM empire_lessons WHERE domain = 'test'")
            conn.commit()
            print("  [OK] 质检垃圾已销毁，数据库恢复干净。")

    except Exception as e:
        print("[FAIL] 帝国质检失败，架构存在异常: %s" % e)
        sys.exit(1)

# --- 6. 启动入口 ---
def main():
    print("开始执行【帝国创世纪 V2】(OS: %s)..." % OS_TYPE)
    init_statedb()
    init_agents()
    init_watchdog()
    run_post_flight_checks()
    print("\n龙虾帝国底层架构已通过实弹质检，具备全面作战能力！")
    if OS_TYPE == "Windows":
        print("提示: 请在 Windows 启动项中配置 bat 脚本以拉起 watchdog.py。")

if __name__ == "__main__":
    main()
