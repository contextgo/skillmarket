# Skill: Empire Genesis V2 (帝国创世纪-自检版)

## 技能描述
此技能为系统级架构装配工具。不仅能自动将 OpenClaw 升级为"龙虾帝国"标准架构，还自带"冷链"与"铁猪"双重沙箱质检机制。

## 核心动作
1. 抹平 OS 差异，创建抗并发的 SQLite 状态库 (StateDB)。
2. 注入 Signal Protocol v2 (防告警风暴) 与双时标机制。
3. 补齐核心编制 (Research, Execution, Verification)。
4. 部署独立的 Watchdog 哨兵进程。
5. **注入沙箱模拟测试，验证 StateDB 的吞吐与约束逻辑。**
6. **测试通过后执行无痕销毁（阅后即焚）。**

## 触发条件
当接收到"初始化帝国"、"部署龙虾架构"、"调用帝国创世纪"、"搭建底层架构"等指令时执行。

## 执行命令
`python empire_bootstrap.py`

## 已知教训（龙虾帝国核心经验）
- **并发锁死**：Windows 上 SQLite 需要 timeout=20，避免 Database is locked。
- **Signal Protocol**：empire_lessons 表用 lesson_hash 做唯一索引，ON CONFLICT 时 hit_count+1，防止告警风暴。
- **双时标**：blackboard 表同时记录 event_time 和 collection_time，避免跨 Agent 时间戳冲突。
- **哨兵补丁**：Watchdog 每 60s 替所有 status='online' 的 static agent 代刷 last_seen，消除心跳假死误报。
- **main 不干预**：Watchdog 的哨兵补丁不触碰 main 和 watchdog 自身的心跳记录。
