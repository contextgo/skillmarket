# Skill: Empire Genesis V2（帝国创世纪）

> 一键搭建「龙虾帝国」底层架构，含自检 + 无痕清理。

---

## 适用场景

在新机器 / 新目录 / 新 OpenClaw 实例上，快速部署龙虾帝国标准架构（StateDB + 3 个静态 Agent + Watchdog 哨兵进程）。

---

## 触发方式

在主 Agent 对话框输入：

```
调用帝国创世纪技能，初始化当前环境。
```

---

## 执行流程（全自动，无需人工介入）

| 步骤 | 内容 | 状态 |
|------|------|------|
| 1/4 | 初始化 StateDB（4 张核心表，含 Signal Protocol v2 + 双时标） | 自动 |
| 2/4 | 核查 3 个静态 Agent 目录，缺失则自动创建 | 自动 |
| 3/4 | 生成 Watchdog v2.1（含哨兵代理心跳补丁） | 自动 |
| 4/4 | 执行「冷链演习」+「铁猪行动」双重质检 → 通过后自动销毁测试痕迹 | 自动 |

---

## 出厂质检两项测试

**① 小龙虾冷链演习**
向 `blackboard` 表写入带 `event_time` 的事实数据，验证双时标机制正常。

**② 铁猪行动**
故意用相同 `lesson_hash` 写入两次，验证 `ON CONFLICT(lesson_hash)` 去重生效，`hit_count` 累加为 2。

两项测试通过后，自动执行 `DELETE` 销毁所有 `test_*` 痕迹，数据库不留垃圾。

---

## 生成的产物

```
.openclaw/workspace/
├── state/
│   ├── system.db              # StateDB（4 张表）
│   ├── watchdog_signal_v2.py   # Watchdog 哨兵进程（含哨兵补丁 v2.1）
│   └── lessons_inbox/          # 共享教训入站队列
│
└── agents/
    ├── research-agent/        # 搜索助理
    ├── execution-agent/       # 执行助理
    └── verification-agent/    # 验证助理
```

---

## Watchdog 启动命令

```cmd
cd /d C:\Users\cloud_user\.openclaw\workspace\state
py watchdog_signal_v2.py
```

---

## 已内置的核心教训

- **并发锁死** → Windows 上 `timeout=20`
- **告警风暴** → `empire_lessons` 表用 `lesson_hash` 去重，`hit_count` 累加
- **双时标** → `blackboard` 表同时记录 `event_time`（事件发生时间）和 `collection_time`（入库时间）
- **心跳假死** → Watchdog 每 60s 代刷所有 `status='online'` Agent 的 `last_seen`，main 不干预
