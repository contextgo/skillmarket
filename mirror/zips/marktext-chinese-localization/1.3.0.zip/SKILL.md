---
name: marktext-chinese-localization
version: 1.3.0
description: >
  MarkText 中文汉化技能。当用户要求汉化 MarkText、把 MarkText 改为中文、
  对 MarkText 进行汉化操作，或恢复 MarkText 英文版时触发本技能。
  本技能通过修改 app.asar 内部文件，替换 397 处 UI 文本，实现完整的中文界面。
---

# MarkText 中文汉化技能

## 下载脚本

本技能需要配套脚本文件才能运行：

1. 从 Gitee 下载完整脚本包：
   https://gitee.com/wangxiamtb/marktext-hanhua/releases

2. 解压后将 `scripts` 文件夹放在与 SKILL.md 同级目录

## 使用方法

安装完成后，只需在对话中告诉 AI：

- **汉化 MarkText**：说「帮我汉化 MarkText」，AI 自动完成全部流程
- **恢复英文版**：说「恢复 MarkText 英文版」，AI 一键还原
- **补充遗漏词汇**：说「MarkText 有个地方没翻译」并发截图，AI 自动追加翻译后重新汉化

## 前提条件

1. **Node.js** 已安装（v16+）
2. **@electron/asar** 工具已全局安装：
   ```
   npm install -g @electron/asar
   ```
3. MarkText 已安装（支持 Windows / macOS）

## 技能脚本说明

| 脚本 | 功能 |
|------|------|
| `hanhua-apply.js` | 一键汉化（备份 → 解包 → 汉化 → 打包 → 替换） |
| `hanhua-core.js` | 核心翻译字典，包含 397 处文本映射（v1.3） |
| `hanhua-restore.js` | 恢复英文版 |

## 汉化覆盖范围（v1.3，397 处）

1. **菜单栏**：顶层菜单 + 所有子菜单（文件/编辑/段落/格式/视图/窗口/帮助/主题）
2. **右键菜单**：剪切/复制/粘贴/格式/图片等
3. **设置面板**（全覆盖）：
   - 通用（启动/侧边栏/排序/语言/缩放/自动保存）
   - 编辑器（宽度/代码块/写作行为/文件格式/文本方向/行尾格式/尾空行）
   - Markdown（列表/扩展/兼容性/图表/标题样式/前言格式）
   - 主题（自动调整）
   - 图片（路径/默认操作）
   - 快捷键（所有描述条目）
   - 拼写检查（所有选项）
4. **界面 UI**：
   - 表格操作（对齐/行列插入/删除/单元格合并）
   - 标签页右键（关闭/重命名/复制路径）
   - 搜索框（搜索/替换/全部替换/替换单个）
   - 段落菜单（标题1~6/提升降低/代码块/引用/公式/列表/水平线/前言）
   - 字数统计（字数/字符数/段落数）
   - 图表类型（Vega/流程图/时序图/PlantUML/Mermaid）
   - 图片工具栏（编辑/行内/链接/删除）
   - 通知消息（保存失败/粘贴错误/更新提示等）
   - 新文档段落选择器（全部选项）
   - 导出选项（样式/纸张/边距）
   - 更新对话框
   - 隐私声明/服务条款/反馈

## 常见问题

| 问题 | 解决方案 |
|------|----------|
| `asar: command not found` | `npm install -g @electron/asar` |
| 替换失败（权限拒绝）| 以管理员/sudo 身份运行脚本 |
| 汉化后 MarkText 无法启动 | 运行 `hanhua-restore.js` 恢复英文版 |
| 找不到安装目录 | 传入路径参数：`node hanhua-apply.js "安装目录"` |
| 有新遗漏词汇 | 向 `hanhua-core.js` 的 `TRANSLATIONS` 追加映射条目 |

---

*汉化版本：v1.3.0 | 适用 MarkText：v0.17.1*
