---
name: "staff-absence-detection-analysis"
description: "Sleep-on-duty monitoring: Conducts 7x24 hour unattended monitoring of designated work positions/key areas through intelligent video analysis, accurately identifying whether on-duty personnel have left their preset work positions, and triggering instant alerts for off-post events. Trigger conditions: Use when users mention keywords such as personnel off-post monitoring, post duty monitoring, post abandonment detection, personnel not at post alerts, etc. | 人员离岗实时监测技能，睡岗监测，通过智能视频分析对指定工作岗位/关键区域进行 7x24 小时无人值守监测，精准识别在岗人员是否离开预设工作位置，离岗事件触发即时告警。触发条件：用户提及人员离岗监测、岗位值守监测、脱岗检测、人员不在岗告警等关键词时使用。"
---

# Real-time Employee Absence Monitoring Skill | 人员离岗实时监测技能

## 任务目标

- 本 Skill 用于：对指定工作岗位、收银台、服务窗口、保安岗、中控室等关键区域进行**7x24 小时实时智能监测**
  ，自动识别在岗人员是否长时间离开预设工作位置，发生离岗/脱岗事件时立即触发告警通知
- 核心能力：人员离岗识别、脱岗超时检测、无人值守告警、历史离岗事件查询、实时告警推送
- 触发条件：**当用户明确提及"人员离岗监测"、"岗位值守监测"、"脱岗检测"、"人员不在岗"、"离岗告警"、"值班监测"、"考勤视频监测"
  时触发本技能**
- 自动行为：
    1. 后台自动轮询云端离岗接口，默认每 30 秒查询一次
    2. 发现新的离岗事件时，自动发送结构化告警信息到指定飞书账号
    3. 已发送的离岗信息自动标记，避免重复发送
    4. 离岗数据自动持久化存储，支持跨会话查询

## 前置准备

- 依赖说明：scripts 脚本所需的依赖包及版本
  ```
  requests>=2.28.0
  pyyaml>=6.0
  ```
- 安装方式：
  ```bash
  # Debian/Ubuntu 系统
  sudo apt install -y python3-requests python3-yaml
  
  # 或使用 pip 安装
  pip install requests pyyaml --break-system-packages
  ```

## 操作步骤

### 🔒 open-id 获取流程控制（强制执行，防止遗漏）

**在执行离岗分析前，必须按以下优先级顺序获取 open-id：**

```
第 1 步：【最高优先级】检查技能所在目录的配置文件（优先）
        路径：skills/smyx_common/scripts/config.yaml（相对于技能根目录）
        完整路径示例：${OPENCLAW_WORKSPACE}/skills/{当前技能目录}/skills/smyx_common/scripts/config.yaml
        → 如果文件存在且配置了 api-key 字段，则读取 api-key 作为 open-id
        ↓ (未找到/未配置/api-key 为空)
第 2 步：检查 workspace 公共目录的配置文件
        路径：${OPENCLAW_WORKSPACE}/skills/smyx_common/scripts/config.yaml
        → 如果文件存在且配置了 api-key 字段，则读取 api-key 作为 open-id
        ↓ (未找到/未配置)
第 3 步：检查用户是否在消息中明确提供了 open-id
        ↓ (未提供)
第 4 步：❗ 必须暂停执行，明确提示用户提供用户名或手机号作为 open-id
```

**⚠️ 关键约束：**

- **禁止**自行假设,自行推导,自行生成 open-id 值（如 openclaw-control-ui、default、userC113、user123 等）
- **禁止**跳过 open-id 验证直接调用 API
- **必须**在获取到有效 open-id 后才能继续执行分析
- 如果用户拒绝提供 open-id，说明用途（用于保存和查询历史报告记录），并询问是否继续

---

- 标准流程：
    1. **自动轮询逻辑**
        - 当用户提及「开启离岗监控」「启动跌倒提醒」等关键词时，**无需询问用户，直接启动后台轮询服务**
        - 当用户提及「停止离岗监控」「关闭告警提醒」等关键词时，停止后台轮询服务
        - 当用户提及「查看离岗列表」「查看离岗告警」「查看告警信息」「查看告警列表」「查看所有告警」「历史告警记录」等关键词时，直接执行查询告警列表脚本
    2. **离岗监控操作**
        - **所有脚本必须在技能根目录下运行**
        - 启动轮询：调用 `-m scripts.staff_absence_detection_analysis start` （后台运行，自动轮询云端接口）
        - 停止轮询：调用 `-m scripts.staff_absence_detection_analysis stop`
        - 查看告警列表：调用
          `-m scripts.staff_absence_detection_analysis list [--open-id <open-id>]`
          （可以传入--start-time 和--end-time 参数限定接口检索范围，--camera_sn 参数检索指定设备，--user_name 参数检索指定设备）
        - 手动查询最新告警：调用 `-m scripts.staff_absence_detection_analysis check`
        - 配置飞书接收人：
            - 自动配置（推荐）：在飞书会话中直接使用，技能会自动获取当前用户的 open_id 作为告警接收人
            - 手动配置：调用 `-m scripts.staff_absence_detection_analysis config --feishu-openid <用户 openid>`
    3. **告警通知规范**
        - 离岗告警信息使用飞书卡片格式发送，包含：
            - 离岗类型（跌倒/卒中/其他）
            - 发生时间
            - 摄像头位置/设备名称
            - 严重等级
            - 现场截图链接（如有）
            - 处理状态
        - 重复离岗过滤：已发送的离岗 ID 记录在本地，下次轮询时跳过
    4. **结果返回规范** ⚠️ **强制执行**
        - **离岗列表必须使用表格格式输出**（Markdown 表格、HTML 表格、纯文本表格等均可）
        - **核心列名固定为以下 6 列，禁止 AI 推理、修改列名：**

        | 核心列名 | 对应 API 字段 | 说明 |
        |:--------:|:-----------:|------|
        | **序号** | `id` | 记录编号，从 1 开始递增 |
        | **发生时间** | `createTimeString` | 告警发生时间，格式：YYYY-MM-DD HH:MM:SS |
        | **离岗类型** | `riskName` | 告警类型名称（如：离岗行为、跌倒信号、突发安全异常等） |
        | **设备名称** | `cameraName` | 摄像头/设备名称（如：办公室摄像头、大华摄像头 DF14 等） |
        | **严重等级** | `riskLevel` | 高/中/低，使用 emoji 标识（🔴高/🟡中/🟢低） |
        | **离岗描述** | `riskDesc` | 告警详细描述，超过 50 字可截断 |
        | **操作** | `tosUrl` | ⚠️ **必须包含**，固定为 `[🔗 查看证据](tosUrl)` 超链接格式 |

        - **⚠️ 核心列名规则：**
          - ✅ **必须包含**：上述 6 个核心列名 + 操作列（共 7 列）
          - ❌ **禁止 AI 推理变更核心列名**（如将"发生时间"改为"检测时间"、"离岗类型"改为"告警类型"等）
          - ✅ **允许增删列**（如添加"处理状态"、"备注"、"处理人"、"视频时长"等自定义列）
          - ✅ **允许调整列顺序**（核心列顺序可调整，但建议保持逻辑顺序）
          - ✅ **允许使用非标准表格格式**（Markdown 表格、HTML 表格、纯文本表格、JSON 等）

        - **操作列规范：**
          - ⚠️ **操作列必须存在**，不可省略
          - 操作列固定为 `[🔗 查看证据](tosUrl)` 超链接格式
          - 链接地址为对应离岗事件的 `tosUrl` 字段值
          - **不对 URL 中的特殊字符做任何转义处理**，保证链接原始可用性

        - **告警通知规范：**
          - 告警通知采用醒目的格式，重要信息高亮显示
          - 包含：离岗类型、发生时间、设备名称、严重等级、现场截图链接、处理建议

        - **错误处理：**
          - 明确提示接口异常、网络故障等问题
          - 错误信息需包含：错误类型、可能原因、建议解决方案

## 资源索引

- 必要脚本：见 [-m scripts.staff_absence_detection_analysis](-m scripts.staff_absence_detection_analysis)
  （用途：离岗轮询、告警发送、数据存储、配置管理）
- 数据存储：见 [data/risks.yaml](data/risks.yaml)（用途：存储历史离岗告警记录和已发送标记）
- 配置文件：见 [data/config.yaml](data/config.yaml)（用途：存储轮询间隔、飞书配置、API 地址等参数）
- 领域参考：见 [references/api_doc.md](references/api_doc.md)（何时读取：需要了解离岗 API 接口规范、飞书消息格式时）

## 注意事项

- 轮询间隔默认 60 秒，可通过配置文件调整，不建议低于 10 秒避免 API 限流
- 离岗 ID 采用全局唯一标识，确保不会重复发送相同告警
- 飞书用户 OpenID 可通过飞书开放平台或用户信息接口获取
- 离岗数据本地加密存储，包含敏感信息的截图链接不会明文存储
- 告警通知可配置多个接收人，支持群组和个人
- 后台服务意外退出时会自动记录日志，重启后自动恢复轮询
- 分析结果仅供参考，不能替代专业医疗急救系统

## 使用示例

```bash
# 启动离岗监控轮询
python -m scripts.staff_absence_detection_analysis start

# 停止离岗监控
python -m scripts.staff_absence_detection_analysis stop

# 查看所有历史离岗告警记录/历史离岗告警记录
python -m scripts.staff_absence_detection_analysis list --open-id openclaw-control-ui

# 查看昨天历史离岗告警记录，可以添加--start-time 参数 (日期格式必须转化为"年 - 月 - 日 时：分：秒")
python -m scripts.staff_absence_detection_analysis list --start-time "2026-03-13" --open-id openclaw-control-ui 

# 查看某时间段范围的历史离岗告警记录，可以添加--start-time 参数和--end-time 参数
python -m scripts.staff_absence_detection_analysis list --start-time "2026-03-1 00:00:00" --end-time "2026-03-1 13:30:00" --open-id openclaw-control-ui

# 查看某个设备的历史离岗告警数据
python -m scripts.staff_absence_detection_analysis list --camera_sn "BH0F994PHA61BD9" --open-id openclaw-control-ui

# 手动查询最新离岗
python -m scripts.staff_absence_detection_analysis check

# 配置飞书接收人
python -m scripts.staff_absence_detection_analysis config --feishu-openid "ou_1234567890abcdef1234567890abcdef"

# 配置轮询间隔为 60 秒
python -m scripts.staff_absence_detection_analysis config --interval 60
```

## 输出格式示例

### 离岗列表表格示例

#### 示例 1：标准 Markdown 表格（推荐）

| 序号 | 发生时间 | 离岗类型 | 设备名称 | 严重等级 | 离岗描述 | 操作 |
|:---:|:--------:|:--------:|:--------:|:-------:|:--------:|:----:|
| 1 | 2026-03-26 19:46:12 | 突发安全/健康异常 | 探鸽摄像头 X678(办公室) | 🔴 高 | 一名身穿白色上衣的人员突然倒地 | [🔗 查看证据](https://example.com/risk/R20260326194612) |
| 2 | 2026-03-26 19:42:12 | 人员离岗行为 | 探鸽摄像头 X678(办公室) | 🟢 低 | 一名身穿深色衣物的人员从工位区域离开 | [🔗 查看证据](https://example.com/risk/R20260326194212) |

#### 示例 2：带自定义列的表格（允许）

| 序号 | 发生时间 | 离岗类型 | 设备名称 | 严重等级 | 离岗描述 | 处理状态 | 操作 |
|:---:|:--------:|:--------:|:--------:|:-------:|:--------:|:--------:|:----:|
| 1 | 2026-03-26 19:46:12 | 突发安全/健康异常 | 探鸽摄像头 X678(办公室) | 🔴 高 | 人员突然倒地 | 待处理 | [🔗 查看证据](https://example.com/risk/R20260326194612) |

#### 示例 3：调整列顺序（允许）

| 设备名称 | 发生时间 | 离岗类型 | 严重等级 | 序号 | 离岗描述 | 操作 |
|:--------:|:--------:|:--------:|:-------:|:---:|:--------:|:----:|
| 探鸽摄像头 X678(办公室) | 2026-03-26 19:46:12 | 突发安全/健康异常 | 🔴 高 | 1 | 人员突然倒地 | [🔗 查看证据](https://example.com/risk/R20260326194612) |

**⚠️ 列名规则说明：**
- ✅ **核心列名禁止变更**：序号、发生时间、离岗类型、设备名称、严重等级、离岗描述、操作（7 列必须存在）
- ✅ **允许增删自定义列**：如"处理状态"、"备注"、"处理人"、"视频时长"等
- ✅ **允许调整列顺序**：核心列顺序可根据需要调整
- ✅ **允许使用非标准表格格式**：Markdown、HTML、纯文本、JSON 等均可
- ⚠️ **操作列必须存在**：不可省略，固定为 `[🔗 查看证据](tosUrl)` 格式

### 飞书告警通知示例

⚠️ **【离岗告警】脱岗告警检测**

- 检测时间：2026-03-13 14:30:00
- 检测设备：办公室摄像头（ID: CAM001）
- 离岗类型：脱岗
- 严重等级：高
- 现场截图：[点击查看](https://example.com/snapshot/R202603131430001.jpg)
- 建议：立即查看现场情况，必要时拨打急救电话
