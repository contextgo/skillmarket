#!/usr/bin/env python3
import os
import sys

# try:

# except ImportError:
#     from config import import_path_common

# import_path_common()
from skills.smyx_common.scripts.config import ApiEnum as ApiEnumBase
from skills.smyx_common.scripts.base import BaseSkill
from skills.smyx_common.scripts.api_service import ApiService as ApiServiceBase

# try:
from .api_service import ApiService


# except ImportError:
#     from api_service import ApiService


class Skill(BaseSkill, ApiService):

    def __init__(self):
        super().__init__()


skill = Skill()
