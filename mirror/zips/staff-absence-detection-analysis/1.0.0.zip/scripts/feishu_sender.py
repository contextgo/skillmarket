#!/usr/bin/env python3
"""
飞书消息发送工具
支持发送文本消息和交互式卡片到飞书群或用户
"""
import json
import requests
import time
from typing import Dict, Optional

# from .config import import_path_common

# import_path_common()
# from common.base import BaseApiService
from skills.smyx_common.scripts.api_service import ApiService as ApiServiceBase
from skills.smyx_common.scripts.config import ConstantEnum, ApiEnum

# 飞书配置
FEISHU_APP_ID = ConstantEnum.FEISHU_APP__ID
FEISHU_APP_SECRET = ConstantEnum.FEISHU_APP__SECRET
# RECEIVE_ID = ConstantEnum.FEISHU_APP__RECEIVE_ID

# 全局缓存
tenant_access_token = ""
token_expire_time = 0
access_token = ""


def get_tenant_access_token() -> str:
    """获取飞书租户访问令牌"""
    global tenant_access_token, token_expire_time

    # 如果token还没过期，直接返回
    if tenant_access_token and time.time() < token_expire_time:
        return tenant_access_token

    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    data = {
        "app_id": FEISHU_APP_ID,
        "app_secret": FEISHU_APP_SECRET
    }

    try:
        response = requests.post(url, json=data, timeout=30)
        if response.status_code == 200:
            result = response.json()
            if result.get("code") == 0:
                tenant_access_token = result.get("tenant_access_token")
                expires_in = result.get("expire", 7200)
                token_expire_time = time.time() + expires_in - 60  # 提前1分钟过期
                return tenant_access_token
            else:
                print(f"获取飞书token失败: {result.get('msg')}")
                return ""
        else:
            print(f"HTTP错误: {response.status_code}")
            return ""
    except Exception as e:
        print(f"请求失败: {e}")
        return ""


def send_message(message: Dict, receive_id_type: str = "open_id") -> bool:
    """发送消息到飞书
    receive_id_type: chat_id(群聊)/open_id(用户)/union_id(用户)
    """
    global access_token
    token = access_token
    if not token:
        return False

    receive_id = ConstantEnum.FEISHU_APP__RECEIVE_ID
    open_api = ApiEnum.BASE_URL_OPEN_API

    url = f"https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type={receive_id_type}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json; charset=utf-8"
    }

    data = {
        "receive_id": receive_id,
        "msg_type": message.get("msg_type", "text"),
        "content": json.dumps(message.get("content", {}))
    }

    try:
        response = requests.post(url, headers=headers, json=data, timeout=30)
        if response.status_code == 200:
            result = response.json()
            if result.get("code") == 0:
                print("消息发送成功")
                return True
            else:
                print(f"发送消息失败: {result.get('msg')}")
                return False
        else:
            print(f"HTTP错误: {response.status_code}, {response.text}")
            return False
    except Exception as e:
        print(f"请求失败: {e}")
        return False


def send_text_message(text: str) -> bool:
    """发送文本消息"""
    message = {
        "msg_type": "text",
        "content": {
            "text": text
        }
    }
    return send_message(message)


def send_risk_alert(risk: Dict) -> bool:
    import requests
    import io

    def get_image_key(public_image_url):
        # 1. 先从公网下载图片
        resp = requests.get(public_image_url)
        if resp.status_code != 200:
            # raise Exception("无法下载公网图片")
            return

        # 2. 准备上传给飞书
        url = "https://open.feishu.cn/open-apis/im/v1/images"
        headers = {
            "Authorization": f"Bearer {token}"
            # 注意：使用 files 参数时，requests 会自动设置 multipart/form-data 和 boundary，不要手动设 Content-Type
        }

        data = {
            "image_type": "message"
        }

        # 将下载的图片内容作为文件上传
        files = {
            "image": ("image.png", io.BytesIO(resp.content), "image/png")
        }

        # 3. 调用飞书上传接口
        upload_resp = requests.post(url, headers=headers, data=data, files=files)
        result = upload_resp.json()

        if result.get("code") == 0:
            return result["data"]["image_key"]
        else:
            return

    token = get_tenant_access_token()
    global access_token
    access_token = token
    if not access_token:
        return False

    """发送风险告警卡片"""
    risk_type = risk.get("riskName", "-")
    risk_level = risk.get("riskLevel", "-")
    risk_desc = risk.get("riskDesc", "-")
    device_name = risk.get("cameraName", "-")
    happen_time = risk.get("createTime", time.strftime("%Y-%m-%d %H:%M:%S"))
    snapshot_url = risk.get("thumbnailImage", "")
    snapshot_url = get_image_key(snapshot_url)
    video_url = risk.get("tosUrl", "")
    risk_id = risk.get("id", "")

    # 风险等级颜色和图标
    level_config = {
        "高": {"color": "red", "icon": "🔴"},
        "中": {"color": "orange", "icon": "🟠"},
        "低": {"color": "blue", "icon": "🔵"}
    }
    config = level_config.get(risk_level, {"color": "gray", "icon": "⚪"})

    # 构建卡片内容
    elements = [
        {
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": f"**检测时间：** {happen_time}\n**检测设备：** {device_name}\n**风险等级：** {risk_level}\n**风险描述：** {risk_desc}"
            }
        }
    ]

    # 添加截图
    if snapshot_url:
        elements.append({
            "tag": "img",
            "img_key": snapshot_url,
            "alt": {
                "tag": "plain_text",
                "content": "现场截图"
            }
        })

    # 添加操作按钮
    elements.append({
        "tag": "action",
        "actions": [
            {
                "tag": "button",
                "text": {
                    "tag": "plain_text",
                    "content": "查看详情"
                },
                "url": f"{video_url}",
                "type": "danger"
            }
        ]
    })

    card = {
        "config": {
            "wide_screen_mode": True
        },
        "header": {
            "title": {
                "tag": "plain_text",
                "content": f"{config['icon']} 【{risk_level}】{risk_type}"
            },
            "template": config["color"]
        },
        "elements": elements
    }

    message = {
        "msg_type": "interactive",
        "content": card
    }

    return send_message(message)


if __name__ == "__main__":
    # 测试发送
    send_text_message("✅ 实时风险提醒技能已配置完成，告警消息将发送到本群！")
