#!/usr/bin/env python3
"""
实时离岗提醒脚本
功能：云端离岗接口轮询、离岗告警发送、本地数据存储、重复告警过滤
"""
import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, parent_dir)

from .config import *
from skills.smyx_common.scripts.config import ConstantEnum, ApiEnum as ApiEnumBase

import argparse
import json
import yaml
import time
import requests
import subprocess
from datetime import datetime
from typing import Dict, List, Optional

from skills.smyx_common.scripts.util import YamlUtil

# from skills.smyx_common.scripts.config import ConstantEnum

# from .feishu_sender import send_risk_alert, ConstantEnum

# 配置文件路径
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(BASE_DIR, "data", "config.yaml")
RISKS_PATH = os.path.join(BASE_DIR, "data", "risks.yaml")
PID_FILE = os.path.join(BASE_DIR, "data", "risk_alert.pid")

# 默认配置
DEFAULT_CONFIG = {
    "feishu_openid": "",  # 飞书用户openid
    "feishu_webhook": "",  # 飞书webhook地址（可选）
    # "last_check_time": "2026-01-01T00:00:00+08:00",
    "sent_risk_ids": []  # 已发送的离岗ID列表
}

DEFAULT_RISKS = {
    "risks": []
}

from .api_service import ApiService
from .config import ApiEnum

from .skill import Skill, skill

from skills.smyx_common.scripts.util import DatetimeUtil

# from skills.device_management.scripts.skill import Skill as DeviceManagementSkill, skill as deviceManagementSkill

openclaw_sender_open_id = os.environ.get("OPENCLAW_SENDER_OPEN_ID")
feishu_open_id = os.environ.get("FEISHU_OPEN_ID")


# SkillNew = sjki.Skill
# from feishu_sender import send_risk_alert

# Skill
# skill.add_cn()

# 获取设备列表用于关联离岗告警
# ApiEnum.TOKEN = ApiEnum.OPEN_TOKEN = "XX21312__DFSDFSDAF"
# device_list = deviceManagementSkill.list()


def load_risks() -> Dict:
    """加载离岗记录"""
    if not os.path.exists(RISKS_PATH):
        os.makedirs(os.path.dirname(RISKS_PATH), exist_ok=True)
        with open(RISKS_PATH, "w", encoding="utf-8") as f:
            yaml.dump(DEFAULT_RISKS, f, default_flow_style=False, allow_unicode=True)
        return DEFAULT_RISKS

    with open(RISKS_PATH, "r", encoding="utf-8") as f:
        risks = yaml.safe_load(f) or {}
        if "risks" not in risks:
            risks["risks"] = []
        return risks


def save_risks(risks: Dict) -> None:
    """保存离岗记录"""
    with open(RISKS_PATH, "w", encoding="utf-8") as f:
        yaml.dump(risks, f, default_flow_style=False, allow_unicode=True)


def get_token() -> str:
    """获取API认证token"""
    # 从公共配置中获取token
    try:
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(BASE_DIR))))
        from skills.smyx_common.scripts.config import ApiEnum
        return ApiEnum.OPEN_TOKEN
    except:
        # 默认token
        return "Bearer eyJhbGciOiJIUzUxMiJ9.eyJ0ZW5hbnROYW1lIjoi55Sf5ZG95raM546w5Lqn56CU5Zui6ZifIiwidXNlclJlYWxOYW1lIjoi55Sf5ZG95raM546w5Lqn56CU5Zui6ZifIiwidGVuYW50SWQiOjE3Njk2MTM3NzgyMjcxMDAwMDAsInJvbGVDb2RlcyI6WyJST0xFX1NNWVhfQURNSU4iLCJST0xFX1BBVElFTlQiLCJST0xFX0RPQ1RPUiIsIlJPTEVfQUlfQU5BTFlTSVMiXSwidGVuYW50Q29kZSI6IjEzMjYwNjU3MDA4IiwicGVybWlzc2lvbkNvZGVzIjpbXSwidXNlcklkIjoxNzY5NjEzNzc4MjI3MTAwMDA4LCJ1c2VybmFtZSI6MTc2OTYxMzc3ODIyNzEwMDAwMCwic3ViIjoiMTMyNjA2NTcwMDgiLCJpYXQiOjE3NzMzMzYwMDEsImV4cCI6MTc3Mzk0MDgwMX0.4QRhvaNSySVXc8-POCJbP9P3BVja45nppOlzN4RjuNt_QJC2fr2XyEGBi-K5FPBTHZ9mOW40THbm3ozLjuLkbA"


def fetch_new_risks(startTime, camera_sn=None) -> List[Dict]:
    """从云端获取最新离岗数据"""
    # camera_sn = device_list[0].get("cameraSn") if device_list else None
    data = {
        # "cameraSn": camera_sn,
    }
    if camera_sn:
        data["cameraSn"] = camera_sn
    risks = skill.list(startTime, data=data)
    return risks


def send_to_feishu(risk: Dict, config: Dict) -> bool:
    """发送离岗告警到飞书"""
    # return True
    try:
        # 导入飞书发送模块
        from .feishu_sender import send_risk_alert
        return send_risk_alert(risk)
    except Exception as e:
        print(f"发送飞书消息失败: {e}")
        return False


def process_risks(new_risks: List[Dict], config: Dict, risks_data: Dict) -> int:
    """处理新的离岗数据，返回新发送的告警数量"""
    sent_count = 0
    sent_risk_ids = set(config.get("sent_risk_ids", []))

    for risk in new_risks:
        risk_id = risk.get("id")

        # 发送告警
        if send_to_feishu(risk, config):
            # 标记为已发送
            sent_risk_ids.add(risk_id)
            # 保存到离岗记录
            risk["sent_time"] = datetime.now().isoformat()
            risk["status"] = "已发送"
            risks_data["risks"].insert(0, risk)  # 最新的放在最前面
            sent_count += 1
            print(f"已发送离岗告警: {risk_id} - {risk.get('createTimeString')}")

    # 更新配置
    config["sent_risk_ids"] = list(sent_risk_ids)
    config["last_check_time"] = DatetimeUtil.format(datetime.now())
    # save_config(config)
    # save_risks(risks_data)

    return sent_count


def run_polling(config: Dict, risks_data: Dict) -> None:
    """运行轮询任务"""
    # 从配置中读取上次检查时间，如果没有则使用当前时间
    last_check_time = config.get("last_check_time")
    if last_check_time:
        try:
            start_time = DatetimeUtil.parse(last_check_time)
        except:
            start_time = DatetimeUtil.now()
    else:
        start_time = DatetimeUtil.now()
    print(f"启动离岗监控轮询，间隔 {config['poll_interval']} 秒...[开始查询{DatetimeUtil.format(start_time)}后的离岗]")
    # endtime = int(time.time() * 1000)
    # 写入 PID 文件
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    try:
        while True:
            print(f"正在查询[{DatetimeUtil.format(start_time)}]后的最新离岗告警...")

            new_risks = fetch_new_risks(start_time)
            print(f"正在查询[{DatetimeUtil.format(start_time)}]后的最新离岗告警..., 返回数量:{len(new_risks)}")
            start_time = DatetimeUtil.now()
            receive_id = ConstantEnum.FEISHU_APP__RECEIVE_ID
            open_api = ApiEnum.BASE_URL_OPEN_API

            if new_risks:
                sent_count = process_risks(new_risks, config, risks_data)
                if sent_count > 0:
                    print(f"处理完成，新发送 {sent_count} 条告警到飞书")
                else:
                    print("没有发送任何告警")
            else:
                print("没有查询到离岗告警数据")

            time.sleep(config["poll_interval"])
    except KeyboardInterrupt:
        print("收到停止信号，退出告警轮询")
    finally:
        # 删除PID文件
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)


def show_list(start_time=None, end_time=None, camera_sn=None) -> None:
    start_time = not start_time and not end_time and DatetimeUtil.today() or start_time
    # camera_sn = device_list[0].get("cameraSn") if device_list else None
    data = {
        # "cameraSn": camera_sn
    }
    if camera_sn:
        data["cameraSn"] = camera_sn
    print(f"查询离岗告警，时间范围 {start_time} - {end_time}")
    return skill.list(start_time, end_time, data=data)


def start_daemon() -> None:
    """启动后台守护进程"""
    if os.path.exists(PID_FILE):
        with open(PID_FILE, "r") as f:
            pid = f.read().strip()
        try:
            # 检查进程是否存在
            os.kill(int(pid), 0)
            print(f"离岗监控已经在运行中，PID: {pid}")
            return
        except:
            # 进程不存在，删除旧的PID文件
            os.remove(PID_FILE)

    # 启动后台进程
    script_path = os.path.abspath(__file__)
    subprocess.Popen([sys.executable, script_path, "daemon"],
                     stdout=open(os.path.join(BASE_DIR, "data", "risk_alert.log"), "a"),
                     stderr=subprocess.STDOUT,
                     start_new_session=True)
    print("离岗监控已启动，后台运行中")


def stop_daemon() -> None:
    """停止后台守护进程"""
    if not os.path.exists(PID_FILE):
        print("离岗监控没有在运行")
        return

    with open(PID_FILE, "r") as f:
        pid = f.read().strip()

    try:
        os.kill(int(pid), 15)  # SIGTERM
        # 等待进程退出
        for _ in range(10):
            try:
                os.kill(int(pid), 0)
                time.sleep(0.5)
            except:
                break
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
        print(f"离岗监控已停止，PID: {pid}")
    except Exception as e:
        print(f"停止失败: {e}")
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)


def format_risks_table(risks: List[Dict]) -> str:
    """格式化离岗列表为Markdown表格"""
    if not risks:
        return "暂无离岗记录"

    header = "| 离岗ID | 发生时间 | 离岗类型 | 设备名称 | 严重等级 | 状态 |\n|--------|----------|----------|----------|----------|------|\n"
    rows = []

    for risk in risks[:20]:  # 最多显示20条
        risk_id = risk.get("riskId", "-")[:20]  # 截断过长的ID
        happen_time = risk.get("happenTime", "-")[:19]  # 只保留到秒
        risk_type = risk.get("riskType", "-")
        device_name = risk.get("deviceName", "-")
        risk_level = risk.get("riskLevel", "-")
        status = risk.get("status", "未发送")

        status_icon = "✅ 已发送" if status == "已发送" else "🔄 未发送"

        row = f"| {risk_id} | {happen_time} | {risk_type} | {device_name} | {risk_level} | {status_icon} |"
        rows.append(row)

    table = header + "\n".join(rows)
    if len(risks) > 20:
        table += f"\n\n*仅显示最近20条记录，共 {len(risks)} 条记录*"

    return table


def main():
    parser = argparse.ArgumentParser(description="实时离岗提醒工具")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # 启动轮询
    start_parser = subparsers.add_parser("start", help="启动离岗监控轮询（后台运行）")
    start_parser.add_argument("--feishu-openid", help="飞书用户OpenID")

    # 停止轮询
    stop_parser = subparsers.add_parser("stop", help="停止离岗监控轮询")
    stop_parser.add_argument("--feishu-openid", help="飞书用户OpenID")

    # 查看离岗告警
    list_parser = subparsers.add_parser("list", help="查看离岗告警记录")
    list_parser.add_argument("--open-id", help="当前用户的OpenID/UserId/用户名/手机号")
    list_parser.add_argument("--feishu-openid", help="飞书用户OpenID")
    list_parser.add_argument("--start-time", help="告警记录开始时间")
    list_parser.add_argument("--end-time", help="告警记录结束时间")
    list_parser.add_argument("--camera_sn", help="指定查询设备")

    # 手动检查离岗
    check_parser = subparsers.add_parser("check", help="手动查询最新离岗")

    # 配置管理
    config_parser = subparsers.add_parser("config", help="配置管理")
    config_parser.add_argument("--feishu-openid", help="飞书用户OpenID")
    config_parser.add_argument("--feishu-webhook", help="飞书Webhook地址")
    config_parser.add_argument("--interval", type=int, help="轮询间隔（秒）")
    config_parser.add_argument("--api-url", help="离岗API地址")

    # 后台运行（内部使用）
    daemon_parser = subparsers.add_parser("daemon", help="后台运行轮询（内部调用）")
    daemon_parser.add_argument("--feishu-openid", help="飞书用户OpenID")

    args = parser.parse_args()

    # open_id = args.feishu_openid
    # open_id = args.open_id
    # print(f"查询离岗告警，当前飞书open_id:", open_id)
    if args.open_id:
        ConstantEnumBase.CURRENT__OPEN_ID = args.open_id

    config = YamlUtil.load(CONFIG_PATH, DEFAULT_CONFIG)
    risks_data = load_risks()

    if args.command == "start":
        start_daemon()

    elif args.command == "stop":
        stop_daemon()

    elif args.command == "list":
        def _print_output():
            if output:
                print(f"""
离岗告警列表的json结构化数据如下:
{output}
""")
            else:
                print(f"""
暂无离岗告警数据
""")

        start_time = DatetimeUtil.parse(args.start_time)
        end_time = DatetimeUtil.parse(args.end_time)
        camera_sn = args.camera_sn
        output = show_list(start_time, end_time, camera_sn)
        _print_output()

    elif args.command == "check":
        print("正在查询最新离岗...")
        new_risks = fetch_new_risks(config)
        if new_risks:
            sent_count = process_risks(new_risks, config, risks_data)
            print(f"查询到 {len(new_risks)} 条新离岗，新发送 {sent_count} 条告警")
            print(format_risks_table(new_risks))
        else:
            print("没有查询到新的离岗")

    elif args.command == "config":
        updated = False
        if args.feishu_openid is not None:
            config["feishu_openid"] = args.feishu_openid
            updated = True
        if args.feishu_webhook is not None:
            config["feishu_webhook"] = args.feishu_webhook
            updated = True
        if args.interval is not None:
            if args.interval < 10:
                print("轮询间隔不能小于10秒")
                return
            config["poll_interval"] = args.interval
            updated = True
        if args.api_url is not None:
            config["api_url"] = args.api_url
            updated = True

        if updated:
            YamlUtil.save(CONFIG_PATH, config)
            print("配置已更新")
        else:
            # 显示当前配置
            print("当前配置:")
            print(f"API地址: {config.get('api_url')}")
            print(f"轮询间隔: {config.get('poll_interval')} 秒")
            print(f"飞书用户OpenID: {config.get('feishu_openid') or '未配置'}")
            print(f"飞书Webhook: {config.get('feishu_webhook') or '未配置'}")

    elif args.command == "daemon":
        run_polling(config, risks_data)


if __name__ == "__main__":
    main()
