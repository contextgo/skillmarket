#!/usr/bin/env python3
# 中医面诊分析工具配置文件
import os
import sys

# def import_path_common():
#     current_dir = os.path.dirname(os.path.abspath(__file__))  # .../src
#     parent_dir = os.path.dirname(current_dir)  # .../project_root
#     skills__dir = os.path.dirname(parent_dir)
#     if skills__dir not in sys.path:
#         sys.path.insert(0, skills__dir)
#     common__dir = os.path.dirname(parent_dir) + "/scripts"
#     if common__dir not in sys.path:
#         sys.path.insert(0, common__dir)


# import_path_common()
from enum import Enum
from skills.smyx_common.scripts.config import ApiEnum as ApiEnumBase, ConstantEnum as ConstantEnumBase


class ApiEnum(ApiEnumBase):
    # API_KEY = ApiEnumBase.API_KEY

    ANALYSIS_URL = "/open/coze/v1/ai-analysis"

    PAGE_URL = ApiEnumBase.BASE_URL_OPEN_API + "/web/risk-result/page-realtime-risk"

    GET_URL = ApiEnumBase.BASE_URL_OPEN_API + "/web/camera/query-one"

    ADD_URL = ApiEnumBase.BASE_URL_OPEN_API + "/web/camera/register"

    EDIT_URL = ApiEnumBase.BASE_URL_OPEN_API + "/web/camera/modify-camera-partial-info"

    DELETE_URL = ApiEnumBase.BASE_URL_OPEN_API + "/web/camera/delete"


class SceneCodeEnum(Enum):
    OPEN_HEALTH_AI_ANALYSIS = "OPEN_HEALTH_AI_ANALYSIS"


class ConstantEnum(ConstantEnumBase):
    DEFAULT__SCENE_CODE = SceneCodeEnum.OPEN_HEALTH_AI_ANALYSIS.value
