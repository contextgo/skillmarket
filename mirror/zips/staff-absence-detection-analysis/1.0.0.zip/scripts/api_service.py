#!/usr/bin/env python3

import os
import sys

# def import_path_common():
#     current_dir = os.path.dirname(os.path.abspath(__file__))  # .../risk_alert/scripts
#     risk_alert_dir = os.path.dirname(current_dir)  # .../risk_alert
#     skills_dir = os.path.dirname(risk_alert_dir)  # .../skills
#     scripts_common_dir = os.path.join(skills_dir, "scripts")
#     workspace_root = os.path.dirname(skills_dir)  # .../workspace
#     if current_dir not in sys.path:
#         sys.path.insert(0, current_dir)
#     if workspace_root not in sys.path:
#         sys.path.insert(0, workspace_root)
#     if scripts_common_dir not in sys.path:
#         sys.path.insert(0, scripts_common_dir)


# import_path_common()

# from config import *
from .config import ApiEnum

# try:
#     from .config import ApiEnum
# except ImportError:
#     from config import ApiEnum


# import sys
# sys.path.append('..')
# from api_enum import ApiEnum


# def import_path_common():
#     current_dir = os.path.dirname(os.path.abspath(__file__))  # .../src
#     parent_dir = os.path.dirname(current_dir)  # .../project_root
#     parent_dir = os.path.dirname(parent_dir) + "/scripts"
#     if parent_dir not in sys.path:
#         sys.path.insert(0, parent_dir)
#
#
# import_path_common()
# from common.base import BaseApiService
# from common.api_service import ApiService as ApiServiceBase
from skills.smyx_common.scripts.api_service import ApiService as ApiServiceBase  # IMPORTANT #
from skills.smyx_common.scripts import RequestUtil, DatetimeUtil

openclaw_sender_open_id = os.environ.get("OPENCLAW_SENDER_OPEN_ID")
feishu_open_id = os.environ.get("FEISHU_OPEN_ID")


class ApiService(ApiServiceBase):

    def __init__(self):
        super().__init__()

    def page(self, pageNum=None, pageSize=None, start_time=None, end_time=None, *args, **argss):

        def _get_risk_tos_url(item):
            tos_key = item.get("tosKey", "")
            try:
                tos_url = self.get_download_url(tos_key)
                return tos_url
            except Exception as e:
                # 如果获取下载链接失败，返回空字符串或原始 tosKey
                print(f"获取下载链接失败：{e}")
                return ""

        def _get_risk_name(risk):
            import pydash as _
            return _.get(risk, "riskDetails.0.disease", "")
            return _.get(risk, "riskDetails.0.", "")

        def _get_risk_description(risk):
            import pydash as _
            return _.get(risk, "riskDetails.0.abnormalBehavior", "")

        def _get_risk_level(risk):
            import pydash as _
            return _.get(risk, "riskDetails.0.level", "")

        data = args[0] if len(args) > 0 else argss.setdefault("data", {})
        if start_time:
            data["startTime"] = DatetimeUtil.timestamp(start_time)
        if end_time:
            data["endTime"] = DatetimeUtil.timestamp(end_time)
        # 添加租户编码
        print(f"查询风险告警请求，时间范围 {type(start_time)} {start_time} - {end_time}, data: {data}")
        # args += (start_time, end_time)
        result = super().page(ApiEnum.PAGE_URL, pageNum, pageSize, *args, **argss)
        result = result[:20]

        result = [
            {"id": r.get("id", ""), "level": r.get("level"), "createTimeString": r.get("createTimeString"),
             "updateTimeString": r.get("updateTimeString"),
             # "riskDetails": r.get("riskDetails"), "tosKey": r.get("tosKey"), "cameraSn": r.get("cameraSn"),
             "cameraName": r.get("cameraName"),
             "thumbnailImage": r.get("thumbnailImage"),
             "tosUrl": _get_risk_tos_url(r),
             "riskName": _get_risk_name(r),
             "riskDesc": _get_risk_description(r),
             "riskLevel": _get_risk_level(r)}
            for r in result
            # if r.get("createTime", 0) >= DatetimeUtil.timestamp(start_time) and (
            #         not end_time or r.get("endTime", 0) <= DatetimeUtil.timestamp(end_time))
        ]
        return result

    def list(self, start_time=None, end_time=None, *args, **argss):
        return super().list(None, start_time, end_time, *args, **argss)

    def add(self, item: dict):
        return super().add(ApiEnum.ADD_URL, item)

    def edit(self, item: dict):
        return super().edit(ApiEnum.EDIT_URL, item)

    def delete(self, cameraSn):
        data = {
            "cameraSn": cameraSn
        }
        return super().delete(ApiEnum.DELETE_URL, data, options={"dataAsParams": True})
