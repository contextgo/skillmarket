﻿# AdminNumberRange Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminNumberRange
- Directory: admin-number-range
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-number-range/index.vue
- Types source: admin-ui/src/components/admin-number-range/types.ts
- README source: admin-ui/src/components/admin-number-range/README.md

## 3. API (Extracted From Source)
- Props type: AdminNumberRangeProps
- Props const: no props const found
- Props keys: not extracted from types.ts, check index.vue
- Emits type: AdminNumberRangeEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminNumberRangeInstance
- Other types: NumberRangeValue

## 4. Real Usage Example

~~~vue
<template>
  <AdminNumberRange v-model="rangeValue" />
</template>

<script setup>
import { ref } from 'vue';
import AdminNumberRange from '@/components/admin-number-range';

// 数组格式
const rangeValue = ref([10, 100]);

// 对象格式
// const rangeValue = ref({ min: 10, max: 100 });
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
