﻿# AdminQrcode Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminQrcode
- Directory: admin-qrcode
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-qrcode/index.vue
- Types source: admin-ui/src/components/admin-qrcode/types.ts
- README source: admin-ui/src/components/admin-qrcode/README.md

## 3. API (Extracted From Source)
- Props type: AdminQRCodeProps
- Props const: adminQRCodeProps
- Props keys: value, options, width, logo, tag, description
- Emits type: AdminQRCodeEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose not used
- Instance type: AdminQRCodeInstance
- Other types: QRCodeOptions, LogoOptions, RenderOptions, QRCodeDoneData, QRCodeTag, QRCodeValue, RenderQRCodeFunction, DrawLogoFunction

## 4. Real Usage Example

~~~vue
<template>
  <admin-qrcode 
    value="https://example.com" 
    @done="handleDone"
  />
</template>

<script setup>
function handleDone(data) {
  console.log('二维码生成完成:', data.url)
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
