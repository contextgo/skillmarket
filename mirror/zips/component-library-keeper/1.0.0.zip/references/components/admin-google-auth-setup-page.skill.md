﻿# AdminGoogleAuthSetupPage Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminGoogleAuthSetupPage
- Directory: admin-google-auth-setup-page
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-google-auth-setup-page/index.vue
- Types source: admin-ui/src/components/admin-google-auth-setup-page/types.ts
- README source: none, example below is from source code behavior

## 3. API (Extracted From Source)
- Props type: not explicitly typed in defineProps
- Props const: adminPageGoogleAuthSetupProps
- Props keys: list, qrSize, qrcodeApi, bindGoogleApi
- Emits type: AdminPageGoogleAuthSetupEmits
- Emits events: ok
- Expose methods: defineExpose not used
- Instance type: no instance interface found
- Other types: DownloadItem, GoogleVerifyCode, ApiFunction

## 4. Real Usage Example

~~~vue
<template>
  <admin-google-auth-setup-page
    :qrcode-api="getSetupQrcode"
    :bind-google-api="bindGoogle"
    @ok="handleBindSuccess"
  />
</template>

<script setup lang="ts">
import { AdminGoogleAuthSetupPage } from "admin-ui";

async function getSetupQrcode() {
  return Promise.resolve({ data: { qrCode: "otpauth://...", googleAuthCode: "ABC123", employeeId: "emp-1001" } });
}

async function bindGoogle(params: { employeeId: string; verifyCode: string }) {
  return Promise.resolve({ success: true, params });
}

function handleBindSuccess() {}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
