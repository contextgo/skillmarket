﻿# AdminModal Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminModal
- Directory: admin-modal
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-modal/index.vue
- Types source: admin-ui/src/components/admin-modal/types.ts
- README source: admin-ui/src/components/admin-modal/README.md

## 3. API (Extracted From Source)
- Props type: not explicitly typed in defineProps
- Props const: no props const found
- Props keys: not extracted from types.ts, check index.vue
- Emits type: not explicitly typed in defineEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose not used
- Instance type: no instance interface found
- Other types: none

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 触发按钮 -->
    <Button type="primary" @click="showModal">
      打开对话框
    </Button>
    
    <!-- 模态对话框 -->
    <admin-modal 
      v-model="modalVisible"
      title="对话框标题"
      @cancel="handleCancel"
      @ok="handleOk"
    >
      <p>这里是对话框内容</p>
    </admin-modal>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Button } from 'ant-design-vue'

const modalVisible = ref(false)

// 显示对话框
function showModal() {
  modalVisible.value = true
}

// 取消事件
function handleCancel() {
  modalVisible.value = false
}

// 确认事件
function handleOk() {
  // 处理确认逻辑
  modalVisible.value = false
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
