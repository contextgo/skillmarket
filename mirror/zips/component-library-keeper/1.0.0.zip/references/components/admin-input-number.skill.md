﻿# AdminInputNumber Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminInputNumber
- Directory: admin-input-number
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-input-number/index.vue
- Types source: admin-ui/src/components/admin-input-number/types.ts
- README source: admin-ui/src/components/admin-input-number/README.md

## 3. API (Extracted From Source)
- Props type: AdminInputNumberProps
- Props const: adminInputNumberProps
- Props keys: modelValue, disabled, placeholder, controls, step, strict, precision
- Emits type: AdminInputNumberEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose not used
- Instance type: AdminInputNumberInstance
- Other types: none

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 基础用法 -->
    <admin-input-number 
      v-model="basicValue"
      placeholder="请输入数字"
      @change="handleChange"
    />
    
    <!-- 步长控制 -->
    <admin-input-number 
      v-model="stepValue"
      :step="5"
      placeholder="步长为5"
    />
    
    <!-- 严格模式 -->
    <admin-input-number 
      v-model="strictValue"
      :step="10"
      :strict="true"
      placeholder="严格模式，值必须是10的倍数"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'

const basicValue = ref()
const stepValue = ref()
const strictValue = ref()

// 值变化处理
function handleChange(value) {
  console.log('数值变化:', value)
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
