﻿# AdminAddWhiteIp Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminAddWhiteIp
- Directory: admin-add-white-ip
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-add-white-ip/index.vue
- Types source: admin-ui/src/components/admin-add-white-ip/types.ts
- README source: admin-ui/src/components/admin-add-white-ip/README.md

## 3. API (Extracted From Source)
- Props type: AdminAddWhiteIpProps
- Props const: adminAddWhiteIpProps
- Props keys: api
- Emits type: AdminAddWhiteIpEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminAddWhiteIpInstance
- Other types: AdminAddWhiteIpFormModel

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 触发按钮 -->
    <a-button type="primary" @click="showAddWhiteIpDialog">
      添加白名单IP
    </a-button>
    
    <!-- 白名单IP添加组件 -->
    <admin-add-white-ip 
      ref="dialogAddIpWhiteRef" 
      :api="loginApi.addWhiteIpApi"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { loginApi } from '@/api/login'

const dialogAddIpWhiteRef = ref()

// 显示添加白名单IP对话框
function showAddWhiteIpDialog() {
  dialogAddIpWhiteRef.value.showDialog()
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
