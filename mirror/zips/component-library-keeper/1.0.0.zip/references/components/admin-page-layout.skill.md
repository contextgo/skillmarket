﻿# AdminPageLayout Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminPageLayout
- Directory: admin-page-layout
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-page-layout/index.vue
- Types source: admin-ui/src/components/admin-page-layout/types.ts
- README source: admin-ui/src/components/admin-page-layout/README.md

## 3. API (Extracted From Source)
- Props type: AdminPageLayoutProps
- Props const: adminPageLayoutProps
- Props keys: showLeft, leftWidth, labelWidth, showFilter, showReset, showOperate, showAdd, addText, showImport, importText, showExport, showDelete, confirmContent, deleteDisabled, collapseCount, colon
- Emits type: AdminPageLayoutEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminPageLayoutInstance
- Other types: LayoutCol, LoadingFunction

## 4. Real Usage Example

~~~vue
<template>
  <admin-page-layout
    @search="handleSearch"
    @reset="handleReset"
    @add="handleAdd"
    @delete="handleDelete"
  >
    <!-- 筛选区域 -->
    <template #filter>
      <FormItem label="用户名">
        <Input v-model:value="searchForm.username" placeholder="请输入用户名" />
      </FormItem>
      <FormItem label="状态">
        <Select v-model:value="searchForm.status" placeholder="请选择状态">
          <SelectOption value="1">启用</SelectOption>
          <SelectOption value="0">禁用</SelectOption>
        </Select>
      </FormItem>
    </template>
    
    <!-- 操作区域 -->
    <template #operate>
      <Button type="primary" @click="handleCustomAction">
        自定义操作
      </Button>
    </template>
    
    <!-- 表格区域 -->
    <template #table>
      <Table
        :columns="columns"
        :dataSource="dataSource"
        :pagination="pagination"
        :loading="loading"
        row-key="id"
      />
    </template>
  </admin-page-layout>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { FormItem, Input, Select, SelectOption, Button, Table } from 'ant-design-vue'

const searchForm = reactive({
  username: '',
  status: undefined
})

const dataSource = ref([])
const loading = ref(false)
const pagination = reactive({
  current: 1,
  pageSize: 10,
  total: 0
})

const columns = [
  { title: '用户名', dataIndex: 'username', key: 'username' },
  { title: '状态', dataIndex: 'status', key: 'status' },
  { title: '操作', key: 'action', width: 200 }
]

function handleSearch() {
  console.log('搜索', searchForm)
  // 执行搜索逻辑
}

function handleReset() {
  Object.assign(searchForm, { username: '', status: undefined })
  // 重置后重新搜索
  handleSearch()
}

function handleAdd() {
  console.log('新增')
  // 打开新增对话框
}

function handleDelete(setLoading) {
  setLoading(true)
  // 执行删除逻辑
  setTimeout(() => {
    setLoading(false)
  }, 2000)
}

function handleCustomAction() {
  console.log('自定义操作')
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
