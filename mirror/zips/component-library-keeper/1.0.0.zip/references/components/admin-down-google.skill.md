﻿# AdminDownGoogle Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminDownGoogle
- Directory: admin-down-google
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-down-google/index.vue
- Types source: admin-ui/src/components/admin-down-google/types.ts
- README source: admin-ui/src/components/admin-down-google/README.md

## 3. API (Extracted From Source)
- Props type: AdminDownGoogleProps
- Props const: adminDownGoogleProps
- Props keys: list
- Emits type: AdminDownGoogleEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminDownGoogleInstance
- Other types: DownloadItem

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 触发按钮 -->
    <Button type="primary" @click="handleAddWhiteIp">
      添加白名单IP
    </Button>
    
    <!-- 添加白名单IP组件 -->
    <admin-add-white-ip 
      ref="addWhiteIpRef"
      :api="addWhiteIpApi"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Button, message } from 'ant-design-vue'

const addWhiteIpRef = ref()

// 显示添加对话框
function handleAddWhiteIp() {
  addWhiteIpRef.value?.showDialog()
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
