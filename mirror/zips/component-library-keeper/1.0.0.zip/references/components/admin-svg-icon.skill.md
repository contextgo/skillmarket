﻿# AdminSvgIcon Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminSvgIcon
- Directory: admin-svg-icon
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-svg-icon/index.vue
- Types source: admin-ui/src/components/admin-svg-icon/types.ts
- README source: admin-ui/src/components/admin-svg-icon/README.md

## 3. API (Extracted From Source)
- Props type: AdminSvgIconProps
- Props const: adminSvgIconProps
- Props keys: size, color, icon
- Emits type: not explicitly typed in defineEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose not used
- Instance type: no instance interface found
- Other types: none

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 基础 SVG 图标 -->
    <admin-svg-icon icon="home" />
    
    <!-- 自定义大小和颜色 -->
    <admin-svg-icon 
      icon="user" 
      size="24px" 
      color="#1890ff" 
    />
    
    <!-- 大尺寸图标 -->
    <admin-svg-icon 
      icon="setting" 
      size="32px" 
      color="#52c41a" 
    />
  </div>
</template>

<script setup>
import { AdminSvgIcon } from 'admin-ui'
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
