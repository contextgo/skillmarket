﻿# AdminGoogleAuthQrcode Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminGoogleAuthQrcode
- Directory: admin-google-auth-qrcode
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-google-auth-qrcode/index.vue
- Types source: admin-ui/src/components/admin-google-auth-qrcode/types.ts
- README source: none, example below is from source code behavior

## 3. API (Extracted From Source)
- Props type: not explicitly typed in defineProps
- Props const: adminGoogleAuthQrcodeProps
- Props keys: qrSize, qrcodeApi, primary
- Emits type: not explicitly typed in defineEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminGoogleAuthQrcodeInstance
- Other types: ApiFunction

## 4. Real Usage Example

~~~vue
<template>
  <a-button type="primary" @click="open">Open Qrcode</a-button>
  <admin-google-auth-qrcode
    ref="qrcodeRef"
    :qrcode-api="getGoogleQrcode"
    primary="employeeId"
    :qr-size="180"
  />
</template>

<script setup lang="ts">
import { ref } from "vue";
import { AdminGoogleAuthQrcode } from "admin-ui";

const qrcodeRef = ref<InstanceType<typeof AdminGoogleAuthQrcode> | null>(null);

function open() {
  qrcodeRef.value?.showDialog("emp-1001");
}

async function getGoogleQrcode(params: { employeeId: string }) {
  return Promise.resolve({ data: { qrCode: "otpauth://...", googleAuthCode: "ABC123" } });
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
