﻿# AdminRemoveBlackIp Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminRemoveBlackIp
- Directory: admin-remove-black-ip
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-remove-black-ip/index.vue
- Types source: admin-ui/src/components/admin-remove-black-ip/types.ts
- README source: admin-ui/src/components/admin-remove-black-ip/README.md

## 3. API (Extracted From Source)
- Props type: AdminRemoveBlackIpProps
- Props const: adminRemoveBlackIpProps
- Props keys: api
- Emits type: AdminRemoveBlackIpEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminRemoveBlackIpInstance
- Other types: AdminRemoveBlackIpFormModel

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <a-button @click="showRemoveDialog">解除黑名单IP</
    a-button>
    <admin-remove-black-ip 
      ref="removeBlackIpRef"
      :api="removeBlackIpApi"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { AdminRemoveBlackIp } from 'admin-ui'

const removeBlackIpRef = ref()

// API函数
async function removeBlackIpApi(params) {
  const response = await fetch('/api/
  remove-black-ip', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(params)
  })
  return response.json()
}

// 显示解除黑名单对话框
function showRemoveDialog() {
  removeBlackIpRef.value?.showDialog()
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
