﻿# AdminCaptcha Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminCaptcha
- Directory: admin-captcha
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-captcha/index.vue
- Types source: admin-ui/src/components/admin-captcha/types.ts
- README source: admin-ui/src/components/admin-captcha/README.md

## 3. API (Extracted From Source)
- Props type: AdminCaptchaProps
- Props const: no props const found
- Props keys: not extracted from types.ts, check index.vue
- Emits type: AdminCaptchaEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminCaptchaInstance
- Other types: CaptchaApiResponse, AdminCaptchaComponent, CaptchaApiFunction, CaptchaSize

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 基础验证码组件 -->
    <admin-captcha 
      v-model:captcha-code="formModel.captchaCode"
      v-model:captcha-uuid="formModel.captchaUuid"
      :api="loginApi.getCaptchaApi"
      placeholder="请输入验证码"
      @captcha-loaded="handleCaptchaLoaded"
      @captcha-error="handleCaptchaError"
    />
    
    <!-- 大尺寸验证码组件 -->
    <admin-captcha 
      v-model:captcha-code="formModel.captchaCode"
      v-model:captcha-uuid="formModel.captchaUuid"
      :api="loginApi.getCaptchaApi"
      size="large"
      :auto-refresh="false"
      refresh-title="点击图片刷新"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { loginApi } from '@/api/login'

const formModel = ref({
  captchaCode: '',
  captchaUuid: ''
})

// 验证码加载完成回调
function handleCaptchaLoaded(data) {
  console.log('验证码加载完成:', data)
}

// 验证码加载错误回调
function handleCaptchaError(error) {
  console.error('验证码加载失败:', error)
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
