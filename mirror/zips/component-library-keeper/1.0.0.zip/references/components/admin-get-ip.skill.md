﻿# AdminGetIp Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminGetIp
- Directory: admin-get-ip
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-get-ip/index.vue
- Types source: admin-ui/src/components/admin-get-ip/types.ts
- README source: admin-ui/src/components/admin-get-ip/README.md

## 3. API (Extracted From Source)
- Props type: AdminGetIpProps
- Props const: adminGetIpProps
- Props keys: api
- Emits type: AdminGetIpEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminGetIpInstance
- Other types: AdminGetIpFormModel

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 触发按钮 -->
    <Button type="primary" @click="handleGetIp">
      获取IP地址
    </Button>
    
    <!-- 获取IP组件 -->
    <admin-get-ip 
      ref="getIpRef"
      :api="getIpApi"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Button } from 'ant-design-vue'

const getIpRef = ref()

// 显示获取IP对话框
function handleGetIp() {
  getIpRef.value?.showDialog()
}

// API函数
async function getIpApi() {
  const response = await fetch('/api/get-ip')
  const data = await response.json()
  return { data: data.ip }
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
