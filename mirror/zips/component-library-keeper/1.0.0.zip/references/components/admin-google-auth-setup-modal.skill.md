﻿# AdminGoogleAuthSetupModal Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminGoogleAuthSetupModal
- Directory: admin-google-auth-setup-modal
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-google-auth-setup-modal/index.vue
- Types source: admin-ui/src/components/admin-google-auth-setup-modal/types.ts
- README source: none, example below is from source code behavior

## 3. API (Extracted From Source)
- Props type: not explicitly typed in defineProps
- Props const: adminGoogleAuthSetupModalProps
- Props keys: list, qrSize, qrcodeApi, bindGoogleApi
- Emits type: AdminGoogleAuthSetupModalEmits
- Emits events: ok, cancel
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminGoogleAuthSetupModalInstance
- Other types: DownloadItem, GoogleVerifyCode, ApiFunction

## 4. Real Usage Example

~~~vue
<template>
  <a-button type="primary" @click="open">Bind Google Auth</a-button>
  <admin-google-auth-setup-modal
    ref="setupRef"
    :qrcode-api="getSetupQrcode"
    :bind-google-api="bindGoogle"
    @ok="handleOk"
    @cancel="handleCancel"
  />
</template>

<script setup lang="ts">
import { ref } from "vue";
import { AdminGoogleAuthSetupModal } from "admin-ui";

const setupRef = ref<InstanceType<typeof AdminGoogleAuthSetupModal> | null>(null);

function open() {
  setupRef.value?.showDialog();
}

async function getSetupQrcode() {
  return Promise.resolve({ data: { qrCode: "otpauth://...", googleAuthCode: "ABC123", employeeId: "emp-1001" } });
}

async function bindGoogle(params: { employeeId: string; verifyCode: string }) {
  return Promise.resolve({ success: true, params });
}

function handleOk() {}
function handleCancel() {}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
