﻿# AdminBindGoogle Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminBindGoogle
- Directory: admin-bind-google
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-bind-google/index.vue
- Types source: admin-ui/src/components/admin-bind-google/types.ts
- README source: admin-ui/src/components/admin-bind-google/README.md

## 3. API (Extracted From Source)
- Props type: AdminBindGoogleProps
- Props const: adminBindGoogleProps
- Props keys: captchaApi, qrcodeApi, bindGoogleApi, encrypt, encryptData
- Emits type: AdminBindGoogleEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminBindGoogleInstance
- Other types: AdminBindGoogleFormModel, CaptchaInstance, ErrorResponse, EncryptFunction, ApiFunction

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 触发按钮 -->
    <a-button type="primary" @click="showBindGoogleDialog">
      绑定Google验证器
    </a-button>
    
    <!-- Google绑定组件 -->
    <admin-bind-google 
      ref="bindGoogleRef" 
      :captcha-api="loginApi.getCaptchaApi"
      :login-api="loginApi.loginApi"
      :qrcode-api="loginApi.getQrcodeApi"
      :bind-google-api="loginApi.bindGoogleApi"
      :encrypt-data="encryptData"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { loginApi } from '@/api/login'

const bindGoogleRef = ref()

// 显示Google绑定对话框
function showBindGoogleDialog() {
  bindGoogleRef.value.showDialog()
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
