﻿# AdminDrawer Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminDrawer
- Directory: admin-drawer
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-drawer/index.vue
- Types source: admin-ui/src/components/admin-drawer/types.ts
- README source: admin-ui/src/components/admin-drawer/README.md

## 3. API (Extracted From Source)
- Props type: AdminDrawerProps
- Props const: adminDrawerProps
- Props keys: modelValue, title, titleAlign, width, height, placement, maskClosable
- Emits type: AdminDrawerEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminDrawerInstance
- Other types: DrawerPlacement, TitleAlign

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 触发按钮 -->
    <Button type="primary" @click="showDrawer">
      打开抽屉
    </Button>
    
    <!-- 抽屉组件 -->
    <admin-drawer 
      v-model="drawerVisible"
      title="抽屉标题"
      @close="handleClose"
    >
      <p>这里是抽屉内容</p>
    </admin-drawer>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Button } from 'ant-design-vue'

const drawerVisible = ref(false)

// 显示抽屉
function showDrawer() {
  drawerVisible.value = true
}

// 关闭事件
function handleClose() {
  drawerVisible.value = false
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
