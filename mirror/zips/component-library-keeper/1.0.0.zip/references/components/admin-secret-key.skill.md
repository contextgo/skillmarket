﻿# AdminSecretKey Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminSecretKey
- Directory: admin-secret-key
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-secret-key/index.vue
- Types source: admin-ui/src/components/admin-secret-key/types.ts
- README source: admin-ui/src/components/admin-secret-key/README.md

## 3. API (Extracted From Source)
- Props type: AdminSecretKeyProps
- Props const: adminSecretKeyProps
- Props keys: updateApi
- Emits type: AdminSecretKeyEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminSecretKeyInstance
- Other types: AdminSecretKeyFormModel, UpdateSecretKeyParams, UpdateSecretKeyApiFunction

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 基础密钥修改组件 -->
    <admin-secret-key 
      :update-api="updateSecretKeyApi"
      @on-success="handleSuccess"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { systemApi } from '@/api/system'

// 更新密钥API
function updateSecretKeyApi(params) {
  return systemApi.updateSecretKey(params)
}

// 成功回调
function handleSuccess() {
  console.log('密钥修改成功')
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
