﻿# AdminDatePicker Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminDatePicker
- Directory: admin-date-picker
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-date-picker/index.vue
- Types source: admin-ui/src/components/admin-date-picker/types.ts
- README source: admin-ui/src/components/admin-date-picker/README.md

## 3. API (Extracted From Source)
- Props type: AdminDatePickerProps
- Props const: adminDatePickerProps
- Props keys: modelValue, type, valueFormat, disabledDate, disabledTime, showTime, placeholder, disabled, allowClear
- Emits type: AdminDatePickerEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose not used
- Instance type: AdminDatePickerInstance
- Other types: DateRangeResult, AdminDatePickerType, DateValue, DateRangeValue, AdminDatePickerValue, DisabledDateFunction, DisabledTimeFunction, DateChangeHandler

## 4. Real Usage Example

~~~vue
<template>
  <div>
    <!-- 日期范围选择器（默认） -->
    <admin-date-picker 
      v-model="dateRange"
      @change="handleDateRangeChange"
    />
    
    <!-- 单日期选择器 -->
    <admin-date-picker 
      v-model="singleDate"
      type="single"
      value-format="YYYY-MM-DD"
      @change="handleSingleDateChange"
    />
    
    <!-- 禁用特定日期 -->
    <admin-date-picker 
      v-model="disabledDate"
      type="single"
      :disabled-date="disabledDateFunc"
      @change="handleDisabledDateChange"
    />
    
    <!-- 禁用周末 -->
    <admin-date-picker 
      v-model="weekdayOnly"
      type="range"
      :disabled-date="disabledWeekends"
    />
    
    <!-- 带时间选择的日期选择器 -->
    <admin-date-picker 
      v-model="dateTimeRange"
      type="range"
      :show-time="true"
      :disabled-time="disabledTimeFunc"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import dayjs from 'dayjs'

const dateRange = ref([])
const singleDate = ref('')
const disabledDate = ref('')
const weekdayOnly = ref([])
const dateTimeRange = ref([])

// 禁用今天之前的日期
function disabledDateFunc(current) {
  return current && current < dayjs().startOf('day')
}

// 禁用周末
function disabledWeekends(current) {
  return current && (current.day() === 0 || current.day() === 6)
}

// 禁用特定时间（例如：禁用工作时间外的时间）
function disabledTimeFunc(current) {
  return {
    disabledHours: () => {
      const hours = []
      for (let i = 0; i < 9; i++) {
        hours.push(i) // 禁用0-8点
      }
      for (let i = 18; i < 24; i++) {
        hours.push(i) // 禁用18-23点
      }
      return hours
    },
    disabledMinutes: (selectedHour) => {
      // 可以根据选中的小时禁用特定分钟
      return []
    },
    disabledSeconds: (selectedHour, selectedMinute) => {
      // 可以根据选中的小时和分钟禁用特定秒数
      return []
    }
  }
}

// 日期范围变化回调
function handleDateRangeChange(value) {
  console.log('日期范围变化:', value)
}

// 单日期变化回调
function handleSingleDateChange(value) {
  console.log('单日期变化:', value)
}

// 禁用日期变化回调
function handleDisabledDateChange(value) {
  console.log('禁用日期变化:', value)
}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
