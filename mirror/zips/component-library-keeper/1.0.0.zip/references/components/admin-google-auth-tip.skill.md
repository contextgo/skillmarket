﻿# AdminGoogleAuthTip Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminGoogleAuthTip
- Directory: admin-google-auth-tip
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-google-auth-tip/index.vue
- Types source: admin-ui/src/components/admin-google-auth-tip/types.ts
- README source: none, example below is from source code behavior

## 3. API (Extracted From Source)
- Props type: not explicitly typed in defineProps
- Props const: adminGoogleAuthTipProps
- Props keys: list, desc, qrSize, qrcodeApi, bindGoogleApi
- Emits type: AdminGoogleAuthTipEmits
- Emits events: cancel, ok
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminGoogleAuthTipInstance
- Other types: DownloadItem, ApiFunction

## 4. Real Usage Example

~~~vue
<template>
  <a-button type="primary" @click="open">Show Bind Tip</a-button>
  <admin-google-auth-tip
    ref="tipRef"
    desc="Please complete Google Auth binding first."
    :qrcode-api="getSetupQrcode"
    :bind-google-api="bindGoogle"
    @ok="handleOk"
    @cancel="handleCancel"
  />
</template>

<script setup lang="ts">
import { ref } from "vue";
import { AdminGoogleAuthTip } from "admin-ui";

const tipRef = ref<InstanceType<typeof AdminGoogleAuthTip> | null>(null);

function open() {
  tipRef.value?.showDialog();
}

async function getSetupQrcode() {
  return Promise.resolve({ data: { qrCode: "otpauth://...", googleAuthCode: "ABC123", employeeId: "emp-1001" } });
}

async function bindGoogle(params: { employeeId: string; verifyCode: string }) {
  return Promise.resolve({ success: true, params });
}

function handleOk() {}
function handleCancel() {}
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
