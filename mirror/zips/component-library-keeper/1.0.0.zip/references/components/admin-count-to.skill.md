﻿# AdminCountTo Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminCountTo
- Directory: admin-count-to
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-count-to/index.vue
- Types source: admin-ui/src/components/admin-count-to/types.ts
- README source: admin-ui/src/components/admin-count-to/README.md

## 3. API (Extracted From Source)
- Props type: AdminCountToProps
- Props const: no props const found
- Props keys: not extracted from types.ts, check index.vue
- Emits type: not explicitly typed in defineEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminCountToInstance
- Other types: none

## 4. Real Usage Example

~~~vue
<template>
  <AdminCountTo :endVal="2023" />
</template>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
