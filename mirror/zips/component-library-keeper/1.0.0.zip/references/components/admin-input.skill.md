﻿# AdminInput Skill Doc (Real Usage)

## 1. Basic
- Component Name: AdminInput
- Directory: admin-input
- Status: active

## 2. Source Of Truth
- Component source: admin-ui/src/components/admin-input/index.vue
- Types source: admin-ui/src/components/admin-input/types.ts
- README source: admin-ui/src/components/admin-input/README.md

## 3. API (Extracted From Source)
- Props type: AdminInputProps
- Props const: no props const found
- Props keys: not extracted from types.ts, check index.vue
- Emits type: AdminInputEmits
- Emits events: no event signatures found in types.ts
- Expose methods: defineExpose exists, check instance type and source code
- Instance type: AdminInputInstance
- Other types: none

## 4. Real Usage Example

~~~vue
<template>
  <AdminInput v-model="inputValue" placeholder="请输入内容" />
</template>

<script setup>
import { ref } from 'vue';
import AdminInput from '@/components/admin-input';

const inputValue = ref('');
</script>
~~~

## 5. Guardrails
- Update this doc only from this component folder source.
- Do not copy props/events from other components.
- If API changes, update both API section and real usage example.
