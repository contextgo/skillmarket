# Component Spec Template

## 1. Basic
- Component Name:
- Layer: `base | business | composed`
- Owner:
- Status: `draft | active | deprecated`

## 2. Responsibility
- What problem it solves:
- What it must not do:

## 3. API
- Props:
- Events:
- Slots:
- Exposed methods (if any):

## 4. States
- Default:
- Disabled:
- Loading:
- Error:

## 5. Accessibility
- Keyboard behavior:
- Focus behavior:
- ARIA notes:

## 6. Examples
- Basic usage:
- Edge usage:
- Anti-pattern:

## 7. Change Log
- Breaking changes:
- Migration steps:

