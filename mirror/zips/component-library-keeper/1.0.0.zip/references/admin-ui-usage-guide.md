# admin-ui 私有组件库使用说明

本文档用于在项目内统一使用 `admin-ui` 组件库，适配 `component-library-keeper` 技能的组件沉淀与治理流程。

## 1. 适用范围

- 技术栈：`Vue 3` + `TypeScript`
- 组件风格：基于 `ant-design-vue` 生态
- 包名：`admin-ui`
- 当前组件数量：21（以 `src/components/index.ts` 导出为准）

## 2. 安装与依赖

`admin-ui` 需要以下同级依赖（peerDependencies）：

- `vue`
- `ant-design-vue`
- `@ant-design/icons-vue`
- `@vueuse/core`

示例：

```bash
pnpm add admin-ui
pnpm add vue ant-design-vue @ant-design/icons-vue @vueuse/core
```

## 3. 引入方式

### 3.1 样式引入（必须）

```ts
import "admin-ui/styles/index.css";
```

### 3.2 按需引入（推荐）

```vue
<script setup lang="ts">
import { AdminModal, AdminDatePicker } from "admin-ui";
</script>
```

### 3.3 全局注册

`admin-ui` 从根入口导出 `install` 方法，可手动进行全局注册：

```ts
import { createApp } from "vue";
import { install as installAdminUI } from "admin-ui";
import "admin-ui/styles/index.css";
import App from "./App.vue";

const app = createApp(App);
installAdminUI(app);
app.mount("#app");
```

### 3.4 自动按需解析（unplugin-vue-components）

`admin-ui` 提供了 `resolver` 子路径导出：

```ts
import Components from "unplugin-vue-components/vite";
import { AdminUIResolver } from "admin-ui/resolver";

export default {
  plugins: [
    Components({
      resolvers: [AdminUIResolver()],
    }),
  ],
};
```

## 4. 组件清单

以下为 `admin-ui` 当前导出的组件：

- `AdminCaptcha`
- `AdminDatePicker`
- `AdminModal`
- `AdminQrcode`
- `AdminSvgIcon`
- `AdminDownGoogle`
- `AdminBindGoogle`
- `AdminGetIp`
- `AdminAddWhiteIp`
- `AdminRemoveBlackIp`
- `AdminPageLayout`
- `AdminDrawer`
- `AdminInputNumber`
- `AdminSecretKey`
- `AdminInput`
- `AdminNumberRange`
- `AdminGoogleAuthSetupPage`
- `AdminGoogleAuthSetupModal`
- `AdminGoogleAuthTip`
- `AdminGoogleAuthQrcode`
- `AdminCountTo`

## 5. 业务页面组合示例

```vue
<template>
  <admin-page-layout>
    <admin-modal v-model:open="open" title="示例弹窗">
      <admin-input v-model:value="form.name" placeholder="请输入名称" />
      <admin-date-picker v-model:value="form.date" />
    </admin-modal>
  </admin-page-layout>
</template>

<script setup lang="ts">
import { reactive, ref } from "vue";
import { AdminPageLayout, AdminModal, AdminInput, AdminDatePicker } from "admin-ui";

const open = ref(false);
const form = reactive({
  name: "",
  date: "",
});
</script>
```

## 6. 组件沉淀约定（给技能执行）

- 新增组件必须在 `src/components/index.ts` 注册并导出。
- 每个组件目录保持 `index.vue` + `types.ts` + `README.md` 基线结构。
- 可复用样式统一放到组件自身 `index.less`，并通过入口样式汇总。
- 组件命名统一使用 `AdminXxx` 导出名，目录名保持 `admin-xxx`。

## 7. 常见问题

- 样式不生效：确认已引入 `admin-ui/styles/index.css`。
- 自动导入失败：确认 `AdminUIResolver` 来自 `admin-ui/resolver`，并检查构建工具插件顺序。
- 组件未找到：确认组件已在 `src/components/index.ts` 统一导出。
