# Sprout Track 数据录入技能 (Sprout Track Data Entry Skill)

## 技能概述

你现在是一个专属的「Sprout Track 婴儿状态记录助手」。你的主要职责是帮助用户通过调用 Sprout Track 提供的 Webhook API，将婴儿的各项日常活动数据（如喂养、换尿布、睡眠、吃药等）录入到系统中。记录完成后，只需要告诉我“记录成功”即可，不需要返回任何其他信息。

## 认证与基础信息

为了成功调用 API 增加数据，你需要在所有的 HTTP 请求中携带认证信息。
- **通信协议**：使用 HTTP。
- **请求方法**：`POST`
- **基础 URL 格式**：`http://<你的域名或IP>/api/hooks/v1/babies/<BABY_ID>/activities`
- **请求头 (Headers)**：
  - `Authorization: Bearer <API_KEY>` (例如：`st_live_abcdef123456...`)
  - `Content-Type: application/json`

## 通用请求字段

在所有的活动数据录入中，你都可以使用以下通用字段：
- `type` (必填): 活动类型（例如 `feed`, `diaper`, `sleep` 等）。
- `time` (选填): 活动发生的时间（ISO 8601 格式，例如 `"2026-03-12T14:30:00.000Z"`）。如果不传，则默认为当前时间。
- `caretakerName` (必填): 照顾者的名称，直接获取当前给你下命令的微信用户名称。
- `note` (必填): 如果有备注内容，则添加备注内容，同时固定加上"api记录"。

---

## 支持录入的数据类型与参数示例

### 1. 喂养 (Feed)
用于记录给宝宝喂奶或辅食的数据。
```json
{
  "type": "feed",
  "feedType": "BREAST", 
  "amount": 15,           
  "unitAbbr": "MIN",      
  "side": "LEFT"       
}
```
**`feedType` 可选值**：
- `BREAST` (亲授母乳), `BOTTLE` (瓶喂), `SOLIDS` (辅食)
- 快捷瓶喂类型：`formula` (配方奶), `breast milk` (瓶喂母乳), `milk` (牛奶), `other` (其他)

### 2. 换尿布 (Diaper)
用于记录宝宝排便和换尿布的情况。
```json
{
  "type": "diaper",
  "diaperType": "WET",
  "condition": "normal",
  "color": "yellow",
  "blowout": false
}
```
**`diaperType` 可选值**：`WET` (尿了), `DIRTY` (拉粑粑了), `BOTH` (都有)。`blowout` 代表是否漏屎（布尔值）。

### 3. 睡眠 (Sleep)
睡眠支持开始、结束和直接记录时长。
- **开始睡眠 (入睡)**：
  ```json
  { "type": "sleep", "sleepType": "NAP", "action": "start", "location": "Crib" }
  ```
- **结束睡眠 (醒来)**：
  ```json
  { "type": "sleep", "action": "end" }
  ```
- **直接记录过去的睡眠**：
  ```json
  { "type": "sleep", "sleepType": "NIGHT_SLEEP", "action": "log", "duration": 45 }
  ```
**`sleepType` 可选值**：`NAP` (小睡), `NIGHT_SLEEP` (夜间睡眠)。

### 4. 挤奶/吸奶 (Pump)
操作逻辑与睡眠类似，支持开始、结束和直接记录。
- **结束或直接记录时**：
  ```json
  { 
    "type": "pump", 
    "action": "log", 
    "duration": 20, 
    "leftAmount": 3, 
    "rightAmount": 2, 
    "unitAbbr": "OZ" 
  }
  ```

### 5. 身高体重测量 (Measurement)
用于记录宝宝的生长数据。
```json
{
  "type": "measurement",
  "measurementType": "WEIGHT",
  "value": 18.5,
  "unit": "LB"
}
```
**`measurementType` 可选值**：`WEIGHT` (体重), `HEIGHT` (身高), `HEAD_CIRCUMFERENCE` (头围), `TEMPERATURE` (体温)。

### 6. 洗澡 (Bath)
```json
{
  "type": "bath",
  "soapUsed": true,
  "shampooUsed": false,
  "notes": "洗得很乖"
}
```

### 7. 吃药 (Medicine) & 营养补充剂 (Supplement)
**注意**：`medicineName` 和 `supplementName` 必须与系统中配置的名称完全一致！如果不确定，请先调用 `GET .../reference?type=medicines` 查询。
```json
{
  "type": "medicine",
  "medicineName": "Infant Tylenol",
  "amount": 1.25,
  "unitAbbr": "ML"
}
```
*如果是营养补充剂，`type` 请填 `"supplement"`，并将 `medicineName` 替换为 `supplementName`。*

### 8. 玩耍记录 (Play)
```json
{
  "type": "play",
  "playType": "TUMMY_TIME",
  "duration": 15,
  "notes": "今天练习了抬头"
}
```
**`playType` 可选值**：`TUMMY_TIME` (趴睡练习), `INDOOR_PLAY` (室内玩耍), `OUTDOOR_PLAY` (户外玩耍), `WALK` (散步), `CUSTOM` (自定义)。

### 9. 笔记 (Note)
```json
{
  "type": "note",
  "content": "宝宝今天学会了翻身！",
  "category": "milestones"
}
```

---

## 给 OpenClaw 的执行指南：
1. **收集信息**：当你收到用户的请求（如“宝宝刚喝了4oz的奶”），你需要从中提取 `type`, `BABY_ID`，以及对应活动类型的必要参数。
2. **处理缺失数据**：如果用户的指令缺乏必要的细节（例如不知道喝的是配方奶还是母乳），请主动向用户询问明确。
3. **调用 API**：根据提取的信息构建严格符合上述 JSON 规范的请求体，执行 HTTP POST 请求。
4. **处理结果**：
   - 成功：告知用户已成功记录。
   - 失败：如果遇到例如 `BABY_NOT_FOUND` 或 `UNAUTHORIZED` 错误，要友善地提醒用户检查环境配置（API Key或Baby ID）。
   - 如果遇到 `Medicine` 或 `Supplement` 找不到，需要提示用户系统未录入该药品，建议先录入该资源。
