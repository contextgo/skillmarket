import argparse
import json
import math
import os
import re
import ssl
import socket
import sys
import urllib.parse
from datetime import datetime


API_HOST = "onetotenvip.com"
API_PATH = "/story/xhsUser/query"
RAW_DATA_FILE = "raw_data.json"


def _make_ssl_connection(host):
    """建立不发送SN的SSL连接"""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    raw_sock = socket.create_connection((host, 443), timeout=15)
    return ctx.wrap_socket(raw_sock)


def _read_response(response_bytes):
    """解析HTTP响应，处理chunked编码"""
    header_end = response_bytes.find(b"\r\n\r\n")
    if header_end == -1:
        raise RuntimeError("Invalid HTTP response: no header/body separator")
    body = response_bytes[header_end + 4:]
    try:
        decoded = body.decode("utf-8")
    except UnicodeDecodeError:
        decoded = body.decode("utf-8", errors="replace")

    header_str = response_bytes[:header_end].decode("utf-8", errors="replace")
    if "Transfer-Encoding: chunked" in header_str or "transfer-encoding: chunked" in header_str.lower():
        decoded = _decode_chunked(decoded)
    return json.loads(decoded)


def https_post_no_sn(host, path, body_dict):
    """POST请求（JSON body），不发送SN"""
    body_json = json.dumps(body_dict, ensure_ascii=False)
    request_line = (
        f"POST {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Connection: close\r\n"
        f"Content-Type: application/json\r\n"
        f"Content-Length: {len(body_json.encode('utf-8'))}\r\n"
        f"Accept: application/json\r\n"
        f"\r\n"
        f"{body_json}"
    )
    ssl_sock = _make_ssl_connection(host)
    try:
        ssl_sock.sendall(request_line.encode("utf-8"))
        response = b""
        while True:
            chunk = ssl_sock.recv(4096)
            if not chunk:
                break
            response += chunk
    finally:
        ssl_sock.close()
    return _read_response(response)


def _decode_chunked(data):
    """简易chunked编码解码"""
    result = []
    pos = 0
    while pos < len(data):
        line_end = data.find("\r\n", pos)
        if line_end == -1:
            break
        chunk_size_str = data[pos:line_end].strip()
        if not chunk_size_str:
            pos = line_end + 2
            continue
        try:
            chunk_size = int(chunk_size_str, 16)
        except ValueError:
            break
        if chunk_size == 0:
            break
        chunk_start = line_end + 2
        chunk_end = chunk_start + chunk_size
        result.append(data[chunk_start:chunk_end])
        pos = chunk_end + 2
    return "".join(result)


def _map_user_attribute(raw):
    """映射账号标识"""
    mapping = {
        "明星": "明星",
        "品牌": "品牌/企业",
        "企业": "品牌/企业",
        "头部kol": "头部KOL",
        "头部KOL": "头部KOL",
        "腰部kol": "腰部KOL",
        "腰部KOL": "腰部KOL",
        "尾部kol": "尾部KOL",
        "尾部KOL": "尾部KOL",
        "素人": "素人",
    }
    return mapping.get(raw, raw or "素人")


def _get_viral_threshold(account_tag):
    """根据账号标识获取爆文标准"""
    thresholds = {
        "素人": 1000,
        "尾部KOL": 5000,
        "腰部KOL": 10000,
        "头部KOL": 20000,
        "明星": 20000,
        "品牌/企业": 1000,
    }
    return thresholds.get(account_tag, 1000)


# 粉丝区间与账号标识的映射
FANS_TYPE_MAP = {
    "0-5K": "素人",
    "5K-5w": "尾部KOL",
    "5w-50w": "腰部KOL",
    ">50w": "头部KOL",
}


def _get_fans_type(fans):
    """根据粉丝数确定粉丝区间"""
    if fans < 5000:
        return "0-5K"
    elif fans < 50000:
        return "5K-5w"
    elif fans < 500000:
        return "5w-50w"
    else:
        return ">50w"


def _extract_benchmark_from_api(raw):
    """从接口数据中提取水平衡量基准数据

    Args:
        raw: 接口返回的原始数据，包含 accountAvgList 和 accountExcellentList

    Returns:
        tuple: (benchmark字典, fans_type, account_tag)
    """
    fans = raw.get("fans", 0)
    fans_type = _get_fans_type(fans)
    account_tag = raw.get("accountTag", "") or FANS_TYPE_MAP.get(fans_type, "素人")

    avg_list = raw.get("accountAvgList", []) or []
    excellent_list = raw.get("accountExcellentList", []) or []

    # 构建中位数参考字典
    avg_dict = {}
    for item in avg_list:
        if item.get("fansType") == fans_type:
            name = item.get("name", "")
            value = item.get("value", 0)
            avg_dict[name] = float(value) if value else 0

    # 构建优秀值参考字典
    excellent_dict = {}
    for item in excellent_list:
        if item.get("fansType") == fans_type:
            name = item.get("name", "")
            value = item.get("value", 0)
            excellent_dict[name] = float(value) if value else 0

    # 获取兜底基准数据
    fallback_benchmark = BENCHMARK_DATA.get(account_tag, BENCHMARK_DATA.get("素人", {}))

    # 映射到水平衡量指标
    benchmark = {
        "近30天作品互动量": {
            "中位数参考": avg_dict.get("近30天作品互动量均值", 0),
            "优秀值参考": excellent_dict.get("近30天作品互动量均值", 0),
        },
        "近30天发作品数": {
            "中位数参考": avg_dict.get("近30天发作品数均值", 0),
            "优秀值参考": excellent_dict.get("近30天发作品数均值", 0),
        },
        "总点赞数": {
            "中位数参考": avg_dict.get("总点赞数均值", 0),
            "优秀值参考": excellent_dict.get("总点赞数均值", 0),
        },
        "总收藏数": {
            "中位数参考": avg_dict.get("总收藏数均值", 0),
            "优秀值参考": excellent_dict.get("总收藏数均值", 0),
        },
        "作品总数": {
            "中位数参考": avg_dict.get("作品总数均值", 0),
            "优秀值参考": excellent_dict.get("作品总数均值", 0),
        },
        "周更频率": {
            "中位数参考": avg_dict.get("近30天发作品数均值", 0) / 4.0 if avg_dict.get("近30天发作品数均值", 0) else 2.0,
            "优秀值参考": excellent_dict.get("近30天发作品数均值", 0) / 4.0 if excellent_dict.get("近30天发作品数均值", 0) else 5.0,
        },
    }

    # 计算互动率和收藏率（基于接口返回的点赞数、收藏数、粉丝数）
    # 互动率 = (点赞数 + 收藏数) / 粉丝数 * 100%
    # 收藏率 = 收藏数 / 点赞数 * 100%

    # 获取中位数参考的点赞数、收藏数、粉丝数
    avg_like = avg_dict.get("总点赞数均值", 0)
    avg_collect = avg_dict.get("总收藏数均值", 0)
    avg_fans = avg_dict.get("粉丝数均值", fans)  # 如果没有粉丝数均值，使用当前账号粉丝数

    # 获取优秀值参考的点赞数、收藏数、粉丝数
    excellent_like = excellent_dict.get("总点赞数均值", 0)
    excellent_collect = excellent_dict.get("总收藏数均值", 0)
    excellent_fans = excellent_dict.get("粉丝数均值", fans)  # 如果没有粉丝数均值，使用当前账号粉丝数

    # 计算互动率中位数参考和优秀值参考
    interaction_rate_avg = round((avg_like + avg_collect) / avg_fans * 100, 2) if avg_fans > 0 else 0.5
    interaction_rate_excellent = round((excellent_like + excellent_collect) / excellent_fans * 100, 2) if excellent_fans > 0 else 1.5

    # 计算收藏率中位数参考和优秀值参考
    collect_rate_avg = round(avg_collect / avg_like * 100, 2) if avg_like > 0 else 8.0
    collect_rate_excellent = round(excellent_collect / excellent_like * 100, 2) if excellent_like > 0 else 15.0

    benchmark["互动率"] = {
        "中位数参考": interaction_rate_avg,
        "优秀值参考": interaction_rate_excellent,
    }
    benchmark["收藏率"] = {
        "中位数参考": collect_rate_avg,
        "优秀值参考": collect_rate_excellent,
    }

    return benchmark, fans_type, account_tag


# 水衡量基准数据（按账号标识分类，作为兜底默认值）
# 基于Excel数据"中位值和优秀值.xlsx"更新的基准数据
# 数据结构：每个粉丝区间包含中位数和优秀值两行数据
BENCHMARK_DATA = {
    "素人": {  # 0-5k粉丝
        "近30天作品互动量": {"中位数参考": 71.65, "优秀值参考": 38878.00},
        "近30天发作品数": {"中位数参考": 3.00, "优秀值参考": 12.00},
        "总点赞数": {"中位数参考": 362.61, "优秀值参考": 31087.00},
        "总收藏数": {"中位数参考": 117.75, "优秀值参考": 7368.00},
        "作品总数": {"中位数参考": 16.73, "优秀值参考": 23.00},
        "互动率": {"中位数参考": 0.5, "优秀值参考": 2.0},  # 估算值
        "收藏率": {"中位数参考": 8.0, "优秀值参考": 25.0},  # 估算值
        "周更频率": {"中位数参考": 0.75, "优秀值参考": 3.0},  # 近30天/4
    },
    "尾部KOL": {  # 5k-5w粉丝
        "近30天作品互动量": {"中位数参考": 483.50, "优秀值参考": 124263.00},
        "近30天发作品数": {"中位数参考": 6.00, "优秀值参考": 24.00},
        "总点赞数": {"中位数参考": 41604.23, "优秀值参考": 329082.00},
        "总收藏数": {"中位数参考": 16201.18, "优秀值参考": 82391.50},
        "作品总数": {"中位数参考": 120.30, "优秀值参考": 136.50},
        "互动率": {"中位数参考": 1.0, "优秀值参考": 3.5},  # 估算值
        "收藏率": {"中位数参考": 12.0, "优秀值参考": 28.0},  # 估算值
        "周更频率": {"中位数参考": 1.5, "优秀值参考": 6.0},  # 近30天/4
    },
    "腰部KOL": {  # 5w-50w粉丝
        "近30天作品互动量": {"中位数参考": 3797.60, "优秀值参考": 254721.50},
        "近30天发作品数": {"中位数参考": 7.00, "优秀值参考": 19.00},
        "总点赞数": {"中位数参考": 398278.10, "优秀值参考": 2381874.00},
        "总收藏数": {"中位数参考": 148994.22, "优秀值参考": 481938.50},
        "作品总数": {"中位数参考": 245.56, "优秀值参考": 284.50},
        "互动率": {"中位数参考": 1.2, "优秀值参考": 4.0},  # 估算值
        "收藏率": {"中位数参考": 15.0, "优秀值参考": 30.0},  # 估算值
        "周更频率": {"中位数参考": 1.75, "优秀值参考": 4.75},  # 近30天/4
    },
    "头部KOL": {  # 大于50w粉丝
        "近30天作品互动量": {"中位数参考": 33700.54, "优秀值参考": 251250.50},
        "近30天发作品数": {"中位数参考": 7.00, "优秀值参考": 12.00},
        "总点赞数": {"中位数参考": 4371187.20, "优秀值参考": 7763569.00},
        "总收藏数": {"中位数参考": 1295796.82, "优秀值参考": 1654083.00},
        "作品总数": {"中位数参考": 428.73, "优秀值参考": 485.50},
        "互动率": {"中位数参考": 1.5, "优秀值参考": 5.0},  # 估算值
        "收藏率": {"中位数参考": 18.0, "优秀值参考": 35.0},  # 估算值
        "周更频率": {"中位数参考": 1.75, "优秀值参考": 3.0},  # 近30天/4
    },
    "明星": {  # 与头部KOL相近
        "近30天作品互动量": {"中位数参考": 33700.54, "优秀值参考": 251250.50},
        "近30天发作品数": {"中位数参考": 7.00, "优秀值参考": 12.00},
        "总点赞数": {"中位数参考": 4371187.20, "优秀值参考": 7763569.00},
        "总收藏数": {"中位数参考": 1295796.82, "优秀值参考": 1654083.00},
        "作品总数": {"中位数参考": 428.73, "优秀值参考": 485.50},
        "互动率": {"中位数参考": 2.0, "优秀值参考": 8.0},
        "收藏率": {"中位数参考": 20.0, "优秀值参考": 40.0},
        "周更频率": {"中位数参考": 1.75, "优秀值参考": 3.0},
    },
    "品牌/企业": {  # 与尾部KOL相近
        "近30天作品互动量": {"中位数参考": 483.50, "优秀值参考": 124263.00},
        "近30天发作品数": {"中位数参考": 6.00, "优秀值参考": 24.00},
        "总点赞数": {"中位数参考": 41604.23, "优秀值参考": 329082.00},
        "总收藏数": {"中位数参考": 16201.18, "优秀值参考": 82391.50},
        "作品总数": {"中位数参考": 120.30, "优秀值参考": 136.50},
        "互动率": {"中位数参考": 0.5, "优秀值参考": 1.5},
        "收藏率": {"中位数参考": 8.0, "优秀值参考": 15.0},
        "周更频率": {"中位数参考": 1.5, "优秀值参考": 6.0},
    },
}


def _calc_coefficient_of_variation(works):
    """计算离散系数（衡量稳定性），基于近7天作品的互动量（点赞+收藏）"""
    if not works or len(works) < 2:
        return None

    interactions = []
    for w in works:
        like_count = w.get("likedCount") or 0
        collect_count = w.get("collectedCount") or 0
        total_interaction = like_count + collect_count
        interactions.append(total_interaction)

    if not interactions:
        return None

    mean_val = sum(interactions) / len(interactions)
    if mean_val == 0:
        return None

    variance = sum((x - mean_val) ** 2 for x in interactions) / len(interactions)
    std_dev = math.sqrt(variance)
    cv = std_dev / mean_val

    return round(cv, 2)


def _calc_decay_ratio(works, viral_threshold):
    """计算爆文后衰减比（承接比），互动=点赞+收藏"""
    if not works or len(works) < 2:
        return None

    # 找到第一个爆文
    viral_index = None
    for i, w in enumerate(works):
        like_count = w.get("likedCount") or 0
        if like_count > viral_threshold:
            viral_index = i
            break

    if viral_index is None or viral_index >= len(works) - 1:
        return None

    # 计算爆文互动量
    viral_work = works[viral_index]
    viral_like = viral_work.get("likedCount") or 0
    viral_collect = viral_work.get("collectedCount") or 0
    viral_interaction = viral_like + viral_collect

    if viral_interaction == 0:
        return None

    # 计算爆文后3篇均值互动量
    next_works = works[viral_index + 1: viral_index + 4]
    if not next_works:
        return None

    next_total = 0
    for nw in next_works:
        next_total += (nw.get("likedCount") or 0) + (nw.get("collectedCount") or 0)
    next_avg = next_total / len(next_works)

    # 承接比 = 爆文后3篇均值 / 爆文互动量 * 100%
    carry_ratio = next_avg / viral_interaction * 100
    return round(carry_ratio, 2)


def _calc_interaction_structure(works):
    """计算互动结构（点赞/收藏占比，接口无分享字段）"""
    if not works:
        return None, None

    total_like = 0
    total_collect = 0

    for w in works:
        total_like += w.get("likedCount") or 0
        total_collect += w.get("collectedCount") or 0

    total = total_like + total_collect
    if total == 0:
        return None, None

    like_pct = round(total_like / total * 100, 1)
    collect_pct = round(total_collect / total * 100, 1)

    return like_pct, collect_pct


def _calc_interaction_rate(works, fans):
    """计算互动率（近7天总互动(点赞+收藏) / 粉丝数 * 100%）"""
    if not works or fans == 0:
        return None

    total_interaction = 0
    for w in works:
        like_count = w.get("likedCount") or 0
        collect_count = w.get("collectedCount") or 0
        total_interaction += like_count + collect_count

    interaction_rate = total_interaction / fans * 100
    return round(interaction_rate, 2)


def _calc_viral_magnification(works, viral_threshold):
    """计算爆文放大倍数，互动=点赞+收藏"""
    if not works:
        return None

    viral_interactions = []
    non_viral_interactions = []

    for w in works:
        like_count = w.get("likedCount") or 0
        collect_count = w.get("collectedCount") or 0
        total = like_count + collect_count

        if like_count > viral_threshold:
            viral_interactions.append(total)
        else:
            non_viral_interactions.append(total)

    if not viral_interactions or not non_viral_interactions:
        return None

    viral_avg = sum(viral_interactions) / len(viral_interactions)
    non_viral_avg = sum(non_viral_interactions) / len(non_viral_interactions)

    if non_viral_avg == 0:
        return None

    return round(viral_avg / non_viral_avg, 0)


def _get_level_judgment(value, benchmark, is_lower_better=False):
    """根据基准值判断等级

    基准数据结构：
    - 中位数参考：同层级账号中位数
    - 优秀值参考：同层级账号优秀值
    """
    if value is None:
        return "数据不足"

    median_val = benchmark.get("中位数参考", 0)
    excellent_val = benchmark.get("优秀值参考", 0)

    if is_lower_better:
        # 数值越低越好（如间隔标准差）
        if value <= excellent_val:
            return "优秀"
        elif value <= median_val:
            return "良好"
        else:
            return "待提升"
    else:
        # 数值越高越好（如互动率、收藏率）
        if value >= excellent_val:
            return "优秀"
        elif value >= median_val:
            return "良好"
        else:
            return "待提升"


def _format_fans_count(fans):
    """粉丝数格式化，>=10000转w+，<10000直接展示原值"""
    if fans >= 10000:
        w_val = fans / 10000
        if w_val == int(w_val):
            return f"{int(w_val)}w+"
        return f"{round(w_val, 1)}w+"
    else:
        return str(fans)


def _format_interactive_count(count):
    """互动量格式化，>=10000转w+，<10000直接展示原值"""
    try:
        count = int(count)
    except (ValueError, TypeError):
        return str(count)
    if count >= 10000:
        w_val = count / 10000
        if w_val == int(w_val):
            return f"{int(w_val)}w+"
        return f"{round(w_val, 1)}w+"
    else:
        return str(count)


def _score_interactive_scale(interactive_count, collect_count, benchmark=None):
    """互动规模评分（满分20），基于互动量和收藏量

    互动量维度：10分（>优秀值10分，>中位数6分，其他1分）
    收藏量维度：10分（>优秀值10分，>中位数6分，其他1分）
    """
    score = 0

    # 从benchmark获取中位数和优秀值
    median_interactive = 1000  # 默认中位数
    excellent_interactive = 10000  # 默认优秀值
    median_collect = 100  # 默认中位数
    excellent_collect = 1000  # 默认优秀值

    if benchmark:
        if "近30天作品互动量" in benchmark:
            median_interactive = benchmark["近30天作品互动量"].get("中位数参考", 1000)
            excellent_interactive = benchmark["近30天作品互动量"].get("优秀值参考", 10000)
        if "总收藏数" in benchmark:
            median_collect = benchmark["总收藏数"].get("中位数参考", 100)
            excellent_collect = benchmark["总收藏数"].get("优秀值参考", 1000)

    # 互动量维度（10分）
    if interactive_count > excellent_interactive:
        score += 10
    elif interactive_count > median_interactive:
        score += 6
    else:
        score += 1

    # 收藏量维度（10分）
    if collect_count > excellent_collect:
        score += 10
    elif collect_count > median_collect:
        score += 6
    else:
        score += 1

    return score


def _score_update_rhythm(weekly_count, fans=0):
    """更新产能评分（满分15分）- 基于周更频率和粉丝数

    参考Excel数据中的近30天发作品数中位数和优秀值：
    - 0-5k: 中位数3篇，优秀值12篇 → 周更0.75篇/3篇
    - 5k-5w: 中位数6篇，优秀值24篇 → 周更1.5篇/6篇
    - 5w-50w: 中位数7篇，优秀值19篇 → 周更1.75篇/4.75篇
    - >50w: 中位数7篇，优秀值12篇 → 周更1.75篇/3篇
    """
    # 粉丝数>5000的账号基础分更高
    if fans > 50000:
        base_score = 10  # 头部账号
    elif fans > 10000:
        base_score = 9  # 中腰部账号
    elif fans > 5000:
        base_score = 8  # 尾部账号
    else:
        base_score = 5  # 素人账号

    if weekly_count >= 5:
        return min(base_score + 5, 15)
    elif weekly_count >= 4:
        return min(base_score + 4, 15)
    elif weekly_count >= 3:
        return min(base_score + 3, 15)
    elif weekly_count >= 2:
        return min(base_score + 2, 15)
    elif weekly_count >= 1:
        return min(base_score + 1, 15)
    else:
        return min(base_score, 15)


def _score_viral(viral_rate, interaction_30d, fans):
    """爆文能力评分（满分15），基于爆文率和近30天互动量评估

    爆文率：10分
    近30天互动量评估：5分
    """
    score = 0
    # 爆文率（10分）：爆文数/近7天发作品数*100%
    if viral_rate >= 30:  # 爆文率>=30%
        score += 10
    elif viral_rate >= 20:  # 爆文率>=20%
        score += 8
    elif viral_rate >= 10:  # 爆文率>=10%
        score += 6
    elif viral_rate >= 5:  # 爆文率>=5%
        score += 4
    elif viral_rate > 0:  # 有爆文但爆文率<5%
        score += 2
    else:  # 无爆文
        score += 1

    # 近30天互动量评估（5分）：基于互动量/粉丝数的比值
    if interaction_30d and fans and fans > 0:
        interaction_ratio = interaction_30d / fans
        if interaction_ratio >= 1.0:  # 互动量>=粉丝数，极强
            score += 5
        elif interaction_ratio >= 0.5:  # 互动量>=粉丝数50%，强
            score += 4
        elif interaction_ratio >= 0.2:  # 互动量>=粉丝数20%，良好
            score += 3
        elif interaction_ratio >= 0.1:  # 互动量>=粉丝数10%，一般
            score += 2
        else:  # 互动量<粉丝数10%，较弱
            score += 1
    return min(score, 15)


def _score_positioning(works, account_tag, signature, fans=0):
    """账号定位评分（满分10）

    对粉丝数>5000的账号以夸赞为主，评分更宽松
    """
    # 粉丝数>5000的账号基础分更高，以夸赞为主
    if fans > 50000:
        score = 8  # 头部账号，基础分高
    elif fans > 10000:
        score = 7  # 中腰部账号，基础分较高
    elif fans > 5000:
        score = 6  # 尾部账号，基础分适中
    else:
        score = 5  # 素人账号，基础分正常

    # 简介完整度
    if signature and len(signature.strip()) > 5:
        score += 1
    # 内容垂直度
    if works:
        tags = []
        for w in works:
            desc = w.get("desc") or ""
            if desc:
                tags.extend([t.strip() for t in desc.split("#") if t.strip()])
        unique_tags = set(tags)
        if len(unique_tags) <= 5:
            score += 1  # 对粉丝数>5000的账号，垂直度要求放宽
    return min(score, 10)


def _get_viral_magnification_judgment(viral_avg, non_viral_avg):
    """判断爆文放大倍数是否健康"""
    if non_viral_avg == 0 or viral_avg == 0:
        return "数据不足"
    magnification = viral_avg / non_viral_avg
    if magnification > 100:
        return "极不健康（无中间态，只有爆文和完全沉默）"
    elif magnification > 50:
        return "不健康（内容质量波动大）"
    elif magnification > 20:
        return "一般（有提升空间）"
    else:
        return "健康（内容质量稳定）"


def _score_fans_insight(collect_rate, fans_gender, works, fans):
    """粉丝画像与需求评分（满分15），含粉丝数评估"""
    score = 5  # 基础分
    # 收藏率评估（3分）
    if collect_rate and collect_rate > 30:
        score += 3
    elif collect_rate and collect_rate > 20:
        score += 2
    elif collect_rate and collect_rate > 10:
        score += 1
    # 粉丝画像集中度（3分）
    if fans_gender and isinstance(fans_gender, dict):
        female_ratio = fans_gender.get("female_ratio", 0)
        if female_ratio > 0.7 or female_ratio < 0.3:
            score += 3
        elif female_ratio > 0.6 or female_ratio < 0.4:
            score += 2
        else:
            score += 1
    # 粉丝数规模评估（4分）
    if fans >= 100000:
        score += 4
    elif fans >= 50000:
        score += 3
    elif fans >= 10000:
        score += 2
    elif fans >= 5000:
        score += 1
    return min(score, 15)


def _score_topic_system(works, fans=0):
    """选题体系评分（满分15）

    核心逻辑：选题方向单一/聚焦是加分项，专注某一赛道深耕是好的
    - 有固定选题方向：加分
    - 有固定栏目/标签：加分
    - 选题一致性高：加分

    对粉丝数>5000的账号评分更宽松
    """
    if not works:
        return 5 if fans > 5000 else 3

    # 粉丝数>5000的账号基础分更高
    if fans > 50000:
        score = 10  # 头部账号，基础分高
    elif fans > 10000:
        score = 9  # 中腰部账号，基础分较高
    elif fans > 5000:
        score = 8  # 尾部账号，基础分适中
    else:
        score = 6  # 素人账号，基础分正常

    titles = [w.get("title", "") for w in works if w.get("title")]

    # 选题方向聚焦/单一：加分项（专注赛道深耕是好事）
    unique_titles = set(titles[:5])
    if len(unique_titles) <= 2:  # 选题高度聚焦
        score += 4
    elif len(unique_titles) <= 3:  # 选题较为聚焦
        score += 3
    elif len(unique_titles) <= 4:  # 选题有一定聚焦
        score += 2

    # 有固定栏目/标签：加分项
    tags = []
    for w in works:
        desc = w.get("desc") or ""
        if desc:
            tags.extend([t.strip() for t in desc.split("#") if t.strip()])
    unique_tags = set(tags)
    if unique_tags:
        if len(unique_tags) <= 3:  # 标签高度统一
            score += 3
        elif len(unique_tags) <= 5:  # 标签较为统一
            score += 2
        else:
            score += 1

    return min(score, 15)


def _score_cover_style(works, fans=0):
    """封面风格评分（满分10）

    封面统一或多样只是风格的一种，不作为评分标准
    主要基于：有封面、有作品、粉丝数规模
    对粉丝数>5000的账号以夸赞为主，评分更宽松
    """
    if not works:
        # 粉丝数>5000的账号即使没有作品也给更高基础分
        return 5 if fans > 5000 else 2

    # 粉丝数>5000的账号基础分更高，以夸赞为主
    if fans > 50000:
        score = 9  # 头部账号，基础分高
    elif fans > 10000:
        score = 8  # 中腰部账号，基础分较高
    elif fans > 5000:
        score = 7  # 尾部账号，基础分适中
    else:
        score = 5  # 素人账号，基础分正常

    # 有封面图加分
    covers = [w.get("coverUrl") or w.get("thumbUrl") for w in works]
    valid_covers = [c for c in covers if c]
    if valid_covers:
        score += 1

    return min(score, 10)


def _format_gender(fans_gender):
    """格式化粉丝性别比例"""
    if not fans_gender or not isinstance(fans_gender, dict):
        return ""
    male = float(fans_gender.get("male_ratio", 0))
    female = float(fans_gender.get("female_ratio", 0))
    female_pct = round(female * 100)
    male_pct = round(male * 100)
    return f"女性{female_pct}% / 男性{male_pct}%"


def _analyze_single_account(raw, has_works=True):
    """对单个账号原始数据进行评分和结构化处理

    Args:
        raw: 原始账号数据
        has_works: 是否有作品数据，False时跳过作品相关分析
    """
    # 无作品提示
    no_works_hint = "" if has_works else "该账号暂未获取到近7天作品"

    fans = raw.get("fans", 0)
    nickname = raw.get("nickname", "")
    level = raw.get("level") or ""
    account_tag_raw = raw.get("userAttribute", "素人")
    account_tag = _map_user_attribute(account_tag_raw)
    total_work = raw.get("totalWork", 0)
    liked = raw.get("liked", 0)
    collected = raw.get("collected", 0)
    note_count_thirty = raw.get("noteCountThirty", 0)
    interactive_thirty = raw.get("interactiveCountThirty", 0)
    top_provinces = raw.get("topProvinces", "")
    top_ages = raw.get("topAges", "")
    fans_gender = raw.get("fansGender", {})
    works = raw.get("works", []) or []
    similar_accounts = raw.get("similarAccounts", []) or []
    red_id = raw.get("redId", "")
    avatar = raw.get("avatarUrl") or raw.get("avatar", "")
    gmt_create = raw.get("gmtCreate", "")
    signature = raw.get("signature", "")

    # 空值保护
    fans = fans if fans is not None else 0
    liked = liked if liked is not None else 0
    collected = collected if collected is not None else 0
    note_count_thirty = note_count_thirty if note_count_thirty is not None else 0
    interactive_thirty = interactive_thirty if interactive_thirty is not None else 0

    # 计算各项指标
    viral_threshold = _get_viral_threshold(account_tag)
    if has_works and works:
        viral_count = sum(1 for w in works if (w.get("likedCount") or 0) > viral_threshold)
        viral_rate = round(viral_count / len(works) * 100, 1) if works else 0
        coefficient_of_variation = _calc_coefficient_of_variation(works)
        decay_ratio = _calc_decay_ratio(works, viral_threshold)
        like_pct, collect_pct = _calc_interaction_structure(works)
    else:
        viral_count = 0
        viral_rate = 0
        coefficient_of_variation = 0
        decay_ratio = 0
        like_pct, collect_pct = 0, 0

    avg_interaction = round(interactive_thirty / note_count_thirty, 1) if note_count_thirty > 0 else 0
    collect_rate = round(collected / liked * 100, 1) if liked > 0 else 0
    weekly_count = round(note_count_thirty / 4.3, 1)

    # 互动率计算：使用接口直接返回的近30天互动量
    interaction_rate = round(interactive_thirty / fans * 100, 2) if fans > 0 else 0

    # 获取水平衡量基准（优先使用接口数据，兜底使用默认值）
    api_benchmark, api_fans_type, api_account_tag = _extract_benchmark_from_api(raw)
    default_benchmark = BENCHMARK_DATA.get(account_tag, BENCHMARK_DATA["素人"])
    # 合并：接口数据优先，缺失时使用默认值
    benchmark = {}
    for key in default_benchmark:
        if key in api_benchmark and api_benchmark[key].get("中位数参考"):
            benchmark[key] = api_benchmark[key]
        else:
            benchmark[key] = default_benchmark[key]

    # 计算近7天作品平均互动数（用于爆文能力评分）
    # 近7天作品：按发布时间筛选
    from datetime import datetime, timedelta
    now = datetime.now()
    seven_days_ago = now - timedelta(days=7)
    works_7d = []
    for w in works:
        publish_time = w.get("publishTime", "")
        if publish_time:
            try:
                # 假设时间格式为 "2024-01-01" 或类似
                pub_dt = datetime.strptime(publish_time[:10], "%Y-%m-%d")
                if pub_dt >= seven_days_ago:
                    works_7d.append(w)
            except:
                pass
    if not works_7d:
        works_7d = works  # 如果无法筛选，使用全部作品

    avg_interaction_7d = 0
    if works_7d:
        total_7d = sum((w.get("likedCount") or 0) + (w.get("collectedCount") or 0) for w in works_7d)
        avg_interaction_7d = round(total_7d / len(works_7d), 1) if works_7d else 0

    # 七维度评分（总分100）
    # 满分分配：账号定位10 + 粉丝画像与需求15 + 选题体系15 + 封面风格10 + 爆文能力15 + 互动规模20 + 更新产能15 = 100
    score_positioning = _score_positioning(works, account_tag, signature, fans)
    score_fans_insight = _score_fans_insight(collect_rate, fans_gender, works, fans)
    score_topic_system = _score_topic_system(works, fans)
    score_cover_style = _score_cover_style(works, fans)
    score_viral = _score_viral(viral_rate, interactive_thirty, fans)
    score_interactive = _score_interactive_scale(interactive_thirty, collected, benchmark)
    score_update = _score_update_rhythm(weekly_count, fans)
    total_score = (score_positioning + score_fans_insight + score_topic_system +
                   score_cover_style + score_viral + score_interactive + score_update)

    # 规则：粉丝数>5000的账号，评分必须>60分
    # 通过提升各维度最低分来确保总评分达标
    if fans > 5000 and total_score < 61:
        # 计算需要提升的分数
        needed = 61 - total_score
        # 按比例提升各维度分数（确保每维度至少得满分的一半）
        if score_positioning < 5:
            score_positioning = 5
        if score_fans_insight < 8:
            score_fans_insight = 8
        if score_topic_system < 8:
            score_topic_system = 8
        if score_cover_style < 5:
            score_cover_style = 5
        if score_viral < 8:
            score_viral = 8
        if score_interactive < 10:
            score_interactive = 10
        if score_update < 8:
            score_update = 8
        # 重新计算总分
        total_score = (score_positioning + score_fans_insight + score_topic_system +
                       score_cover_style + score_viral + score_interactive + score_update)

    # 评分一致性检查：确保七维度评分之和等于总分
    score_sum = score_positioning + score_fans_insight + score_topic_system + score_cover_style + score_viral + score_interactive + score_update
    if score_sum != total_score:
        total_score = score_sum  # 以七维度评分之和为准

    # 水平衡量：使用互动数均值和收藏数均值，不用率
    interaction_avg_level = _get_level_judgment(interactive_thirty, benchmark["近30天作品互动量"]) if interactive_thirty else "数据不足"
    collect_avg_level = _get_level_judgment(collected, benchmark["总收藏数"]) if collected else "数据不足"

    # 爆文列表（含超标准倍数）
    viral_list = []
    viral_interactions = []
    non_viral_interactions = []
    for w in works:
        like_count = w.get("likedCount") or 0
        collect_count = w.get("collectedCount") or 0
        total_inter = like_count + collect_count
        title = (w.get("title") or "无标题")[:30]
        date_str = ""
        ts = w.get("time") or w.get("timestamp") or w.get("createTime")
        if ts:
            try:
                if isinstance(ts, (int, float)):
                    if ts > 1e12:
                        ts = ts / 1000
                    date_str = datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
                else:
                    date_str = str(ts)[:10]
            except (ValueError, OSError):
                date_str = ""

        if like_count > viral_threshold:
            magnification = round(total_inter / viral_threshold, 1) if viral_threshold else 0
            viral_list.append({
                "标题": title,
                "发布时间": date_str,
                "互动数": _format_interactive_count(total_inter),
                "超标准倍数": f"{magnification}x"
            })
            viral_interactions.append(total_inter)
        else:
            non_viral_interactions.append(total_inter)

    # 计算爆文和非爆文的平均互动（用于放大倍数计算）
    viral_avg_raw = round(sum(viral_interactions) / len(viral_interactions)) if viral_interactions else 0
    non_viral_avg_raw = round(sum(non_viral_interactions) / len(non_viral_interactions)) if non_viral_interactions else 0
    non_viral_avg = _format_interactive_count(non_viral_avg_raw)

    # 格式化相似账号
    similar_list = []
    for sa in similar_accounts[:5]:
        account_id = sa.get("accountId") or sa.get("redId") or sa.get("userId", "")
        # 优先使用数据中的url字段，如果没有则使用redId拼接
        profile_url = sa.get("url") or sa.get("profileUrl") or sa.get("homepageUrl") or ""
        if not profile_url and account_id:
            profile_url = f"https://www.xiaohongshu.com/user/profile/{account_id}"
        similar_list.append({
            "accountId": account_id,
            "accountName": sa.get("accountName") or sa.get("nickname") or sa.get("name", ""),
            "profileUrl": profile_url,
            "avatarUrl": sa.get("avatarUrl") or sa.get("avatar") or sa.get("headUrl", ""),
            "followerCount": sa.get("followerCount") or sa.get("fans") or sa.get("fansCount", 0),
            "accountType": sa.get("accountType") or sa.get("trackType", ""),
            "accountSecType": sa.get("accountSecType") or sa.get("subType", ""),
            "signature": sa.get("signature") or sa.get("desc") or sa.get("bio", ""),
            "totalAwemeCount": sa.get("totalAwemeCount") or sa.get("workCount") or sa.get("noteCount") or sa.get("totalWork", 0),
            "totalLikeCount": sa.get("totalLikeCount") or sa.get("likedCount") or sa.get("likeCount") or sa.get("liked", 0),
            "totalCollectedCount": sa.get("totalCollectedCount") or sa.get("collectCount") or sa.get("favCount") or sa.get("collected", 0),
            "totalInteractiveCount": sa.get("interactiveCountThirty") or sa.get("totalInteractiveCount") or sa.get("interactCount", 0),
        })

    result = {
        "header": {
            "账号名": nickname,
            "账号标识": account_tag,
            "数据获取时间": gmt_create,
            "无作品提示": no_works_hint,
        },
        "scores": {
            "综合评分": total_score,
            "账号定位得分": score_positioning,
            "账号定位满分": 10,
            "账号定位简述原因": "",
            "粉丝画像与需求得分": score_fans_insight,
            "粉丝画像与需求满分": 15,
            "粉丝画像与需求简述原因": "",
            "选题体系得分": score_topic_system,
            "选题体系满分": 15,
            "选题体系简述原因": "",
            "封面风格得分": score_cover_style,
            "封面风格满分": 10,
            "封面风格简述原因": "",
            "爆文能力得分": score_viral,
            "爆文能力满分": 15,
            "爆文能力简述原因": "",
            "互动规模得分": score_interactive,
            "互动规模满分": 20,
            "互动规模简述原因": "",
            "更新产能得分": score_update,
            "更新产能满分": 15,
            "更新产能简述原因": "",
            "爆文率": viral_rate,
            "爆文数": viral_count,
            "近7天发作品数": len(works),
            "爆文标准": viral_threshold,
        },
        "conclusion": {
            "综合诊断结论内容": "",
            "可借鉴的优点": "",
            "可成长的地方": "",
        },
        "positioning": {
            "TA是谁": "",
            "心智占位": "",
            "核心身份": "",
            "价值观锚点": "",
            "吸引力类型": "",
            "赛道痛点": "",
            "你的优势": "",
            "可强化": "",
            "显示可强化": score_positioning < 8,  # 账号定位<8分时才显示可强化
        },
        "fans_insight": {
            "粉丝构成": "",
            "核心需求反推": [
                {"画像特征": "", "推断需求": "", "内容匹配度": "", "付费意愿": ""},
                {"画像特征": "", "推断需求": "", "内容匹配度": "", "付费意愿": ""},
                {"画像特征": "", "推断需求": "", "内容匹配度": "", "付费意愿": ""}
            ],
            "收藏率判断": "",
            "内容类型": "",
            "变现路径推断": "",
            "粉丝内容匹配度": "",
            "变现机会": "",
        },
        "topic_system": {
            "选题方向": "",
            "表达风格": "",
            "叙事手法": "",
            "人格一致性": "",
            "选题案例1_标题": works[0].get("title", "")[:20] if works else "",
            "选题案例1_互动数": works[0].get("likes", 0) if works else 0,
            "选题案例1_分析": "",
            "选题案例2_标题": works[1].get("title", "")[:20] if len(works) > 1 else "",
            "选题案例2_互动数": works[1].get("likes", 0) if len(works) > 1 else 0,
            "选题案例2_分析": "",
        },
        "cover_style": {
            "视觉特征": "",
            "信息层级": "",
            "一致性": "",
            "封面案例1_标题": works[0].get("title", "")[:20] if works else "",
            "封面案例1_互动数": works[0].get("likes", 0) if works else 0,
            "封面案例1_分析": "",
            "封面案例2_标题": works[1].get("title", "")[:20] if len(works) > 1 else "",
            "封面案例2_互动数": works[1].get("likes", 0) if len(works) > 1 else 0,
            "封面案例2_分析": "",
        },
        "viral": {
            "爆文率": viral_rate,
            "爆文数": viral_count,
            "爆文标准": viral_threshold,
            "标题规律": "",
            "爆文内容规律": "",
            "情绪特点": "",
            "爆文列表": viral_list,
            "非爆文平均互动": non_viral_avg,
            "爆文放大倍数": round(viral_avg_raw / non_viral_avg_raw, 1) if non_viral_avg_raw > 0 and viral_avg_raw > 0 else 0,
            "爆文放大倍数判断": _get_viral_magnification_judgment(viral_avg_raw, non_viral_avg_raw),
        },
        "interactive_scale": {
            "近30天互动量": _format_interactive_count(interactive_thirty),
            "总收藏数": _format_interactive_count(collected),
            "官方等级": level,
            "互动率": interaction_rate,
            "收藏率": collect_rate,
            "互动结构_点赞占比": like_pct,
            "互动结构_收藏占比": collect_pct,
            "类型判断": "",
            "水平衡量_互动数等级": interaction_avg_level,
            "水平衡量_互动数中位数参考": _format_interactive_count(benchmark["近30天作品互动量"]["中位数参考"]),
            "水平衡量_互动数优秀值参考": _format_interactive_count(benchmark["近30天作品互动量"]["优秀值参考"]),
            "水平衡量_收藏数等级": collect_avg_level,
            "水平衡量_收藏数中位数参考": _format_interactive_count(benchmark["总收藏数"]["中位数参考"]),
            "水平衡量_收藏数优秀值参考": _format_interactive_count(benchmark["总收藏数"]["优秀值参考"]),
        },
        "update_rhythm": {
            "近30天发作品数": note_count_thirty,
            "周更频率": weekly_count,
            "频率分析": "",
            "水平衡量_周更频率等级": _get_level_judgment(weekly_count, benchmark["周更频率"]) if weekly_count else "数据不足",
            "水平衡量_周更频率中位数参考": benchmark["周更频率"]["中位数参考"],
            "水平衡量_周更频率优秀值参考": benchmark["周更频率"]["优秀值参考"],
        },
        "action": {
            "问题归因1": "",
            "问题归因2": "",
            "具体动作1": "",
            "具体动作2": "",
            "具体动作3": "",
            "成功指标周期": "7",
            "成功指标A_指标": "",
            "成功指标A_当前": "",
            "成功指标A_目标": "",
            "成功指标B_指标": "",
            "成功指标B_当前": "",
            "成功指标B_目标": "",
            "未达标兜底": "",
            "可以学": [
                {"策略": "", "来源账号": "", "可复制度": "", "怎么学": ""},
                {"策略": "", "来源账号": "", "可复制度": "", "怎么学": ""},
                {"策略": "", "来源账号": "", "可复制度": "", "怎么学": ""}
            ],
            "反常识发现1": "",
            "反常识发现2": "",
            "30天目标": {
                "粉丝数": {"当前": _format_fans_count(fans), "目标": ""},
                "爆文率": {"当前": f"{viral_rate}%", "目标": ""},
                "互动率": {"当前": f"{interaction_rate}%", "目标": ""},
                "收藏率": {"当前": f"{collect_rate}%", "目标": ""},
                "爆文后承接比": {"当前": f"{decay_ratio}%", "目标": ""},
                "简介完整度": {"当前": "", "目标": "3/3"},
            },
        },
        "works": works[:5],
        "similar_accounts": similar_list,
        "无作品提示": no_works_hint,
        # 原始数据保留，供参考
        "_raw": {
            "redId": red_id,
            "粉丝数原始": fans,
            "近30天互动量原始": interactive_thirty,
            "头像": avatar,
            "简介": signature,
            "粉丝省份": top_provinces,
            "粉丝年龄": top_ages,
            "粉丝性别": fans_gender,
            "作品总数": total_work,
            "总点赞数": liked,
            "总收藏数": collected,
        },
    }


def _save_raw_data(raw_data):
    """将接口原始数据保存到raw_data.json"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = os.path.join(script_dir, "..", "output")
    output_dir = os.path.normpath(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    raw_path = os.path.join(output_dir, RAW_DATA_FILE)
    with open(raw_path, "w", encoding="utf-8") as f:
        json.dump(raw_data, f, ensure_ascii=False, indent=2)


def cmd_query(user_ids, force_analyze=False):
    """查询命令：调用API获取数据，保存raw_data.json，输出结构化结果

    Args:
        user_ids: 小红书账号ID列表
        force_analyze: 是否强制分析（订阅推送时为True，即使无作品也执行分析）
    """
    body = {"userIds": user_ids, "source": "小红书账号诊断"}

    try:
        raw = https_post_no_sn(API_HOST, API_PATH, body)
    except Exception as e:
        print(json.dumps({
            "status": "error",
            "message": f"请求失败: {str(e)}",
            "query_type": "not_found",
            "data": {"accounts": []}
        }, ensure_ascii=False))
        return

    if isinstance(raw, dict) and raw.get("code") == 5000:
        print(json.dumps({
            "status": "error",
            "message": f"接口返回: {raw.get('msg', '系统忙')}",
            "query_type": "not_found",
            "data": {"accounts": []}
        }, ensure_ascii=False))
        return

    raw_data = raw
    if isinstance(raw, dict) and raw.get("data") is not None:
        raw_data = raw["data"]

    if isinstance(raw_data, dict):
        items = [raw_data]
    elif isinstance(raw_data, list):
        items = raw_data
    else:
        items = []

    if not items:
        print(json.dumps({
            "status": "success",
            "query_type": "not_found",
            "data": {"accounts": []}
        }, ensure_ascii=False))
        return

    _save_raw_data(raw)

    full_data_items = [it for it in items if isinstance(it, dict) and ("fans" in it or "noteCountThirty" in it)]

    if len(full_data_items) > 1:
        # 多账号对比：检查是否有账号没有作品数据
        accounts_need_sync = []
        accounts_with_works = []
        for it in full_data_items:
            works = it.get("works", []) or []
            if not works:
                accounts_need_sync.append({
                    "nickname": it.get("nickname", ""),
                    "redId": it.get("redId", "")
                })
            else:
                accounts_with_works.append(it)

        # 如果所有账号都没有作品数据
        if not accounts_with_works:
            # 如果是订阅推送（force_analyze参数），仍然执行分析
            if force_analyze:
                accounts = [_analyze_single_account(it, has_works=False) for it in full_data_items]
                output = {
                    "status": "success",
                    "query_type": "multi",
                    "data": {"accounts": accounts},
                    "no_works_hint": "该账号已重新同步，但暂未获取到近7天作品数据"
                }
                print(json.dumps(output, ensure_ascii=False))
                return
            # 否则返回订阅提示
            output = {
                "status": "success",
                "query_type": "need_sync",
                "data": {"accounts": accounts_need_sync},
                "need_sync": accounts_need_sync
            }
            print(json.dumps(output, ensure_ascii=False))
            return

        # 部分账号有作品数据，生成有数据的账号报告
        accounts = [_analyze_single_account(it) for it in accounts_with_works]
        output = {
            "status": "success",
            "query_type": "multi",
            "data": {"accounts": accounts}
        }
        # 如果有账号需要同步作品数据，返回提示
        if accounts_need_sync:
            output["need_sync"] = accounts_need_sync
        print(json.dumps(output, ensure_ascii=False))
        return

    if len(full_data_items) == 1:
        raw_item = full_data_items[0]
        works = raw_item.get("works", []) or []

        # 检查是否需要同步作品数据
        if not works:
            red_id = raw_item.get("redId", "")
            nickname = raw_item.get("nickname", "")
            # 如果是订阅推送（force_analyze参数），仍然执行分析
            if force_analyze:
                result = _analyze_single_account(raw_item, has_works=False)
                output = {
                    "status": "success",
                    "query_type": "single",
                    "data": result,
                    "no_works_hint": "该账号已重新同步，但暂未获取到近7天作品数据"
                }
                print(json.dumps(output, ensure_ascii=False))
                return
            # 否则返回订阅提示
            output = {
                "status": "success",
                "query_type": "need_sync",
                "data": {
                    "nickname": nickname,
                    "redId": red_id
                },
                "need_sync": [{"nickname": nickname, "redId": red_id}]
            }
            print(json.dumps(output, ensure_ascii=False))
            return

        result = _analyze_single_account(raw_item)
        output = {
            "status": "success",
            "query_type": "unique",
            "data": result
        }
        print(json.dumps(output, ensure_ascii=False))
        return

    print(json.dumps({
        "status": "success",
        "query_type": "not_found",
        "data": {"accounts": []}
    }, ensure_ascii=False))


def cmd_sync_notes(red_ids, account_names=None):
    """订阅命令：调用接口同步账号作品数据

    参数:
        red_ids: 小红书账号ID列表（redId）
        account_names: 账号名称列表（可选）
    """
    results = []

    for i, red_id in enumerate(red_ids):
        account_name = account_names[i] if account_names and i < len(account_names) else f"账号{red_id}"
        try:
            body = {"redId": red_id, "source": "小红书账号诊断-skillhub"}
            response = https_post_no_sn(API_HOST, "/story/xhsUser/syncUserNotes", body)

            if isinstance(response, dict) and response.get("code") == 5000:
                results.append({
                    "redId": red_id,
                    "redId_str": str(red_id),
                    "account_name": account_name,
                    "status": "success",
                    "schedule_required": True,
                    "schedule_time_minutes": 30
                })
            else:
                results.append({
                    "redId": red_id,
                    "redId_str": str(red_id),
                    "account_name": account_name,
                    "status": "success",
                    "schedule_required": True,
                    "schedule_time_minutes": 30
                })
        except Exception as e:
            results.append({
                "redId": red_id,
                "status": "error",
                "message": f"订阅失败: {str(e)}"
            })

    print(json.dumps({
        "status": "success",
        "query_type": "sync",
        "data": {"sync_results": results}
    }, ensure_ascii=False))


REPORT_DATA_FILE = "report_data.json"
MULTI_REPORT_DATA_FILE = "multi_report_data.json"

# 各维度满分映射
SCORE_MAX_MAP = {
    "账号定位": 10,
    "粉丝画像与需求": 10,
    "选题体系": 15,
    "封面风格": 10,
    "爆文能力": 15,
    "互动规模": 20,
    "更新产能": 15,
}


def _flatten_dict(d, parent_key="", sep="."):
    """将嵌套字典扁平化为点分隔的键名"""
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(_flatten_dict(v, new_key, sep).items())
        elif isinstance(v, list):
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    items.extend(_flatten_dict(item, f"{new_key}[{i}]", sep).items())
                else:
                    items.append((f"{new_key}[{i}]", str(item) if item is not None else ""))
        else:
            items.append((new_key, str(v) if v is not None else ""))
    return dict(items)


def _build_replacements(report_data):
    """从report_data构建替换字典，支持嵌套结构和数组索引

    生成的占位符格式：
    1. 完整路径：{{header.账号名}}、{{scores.账号定位得分}}
    2. 关键短路径：{{生命周期.当前阶段}}、{{核心需求反推[0].画像特征}}、{{30天目标.粉丝数.当前}}
    3. 最短路径（最后一层）：{{账号名}}、{{当前阶段}}
    三种格式都支持，确保HTML模板中任何写法都能匹配
    """
    numeric_fields = {
        "单篇互动均值", "收藏率", "爆文率", "近7天发作品数", "爆文数", "周更频率",
        "综合评分", "账号定位得分", "互动规模得分", "爆文能力得分",
        "更新产能得分", "粉丝画像与需求得分", "选题体系得分", "封面风格得分"
    }

    # 扁平化整个数据结构
    flat_data = _flatten_dict(report_data)

    replacements = {}
    for k, v in flat_data.items():
        # 空值处理：将 none/null/None/空字符串 替换为 0 或空字符串
        str_v = str(v).strip().lower() if v is not None else ""
        if str_v in ("none", "null", ""):
            v = "0" if k in numeric_fields else ""
        else:
            v = str(v).strip()

        str_v = str(v)
        # 完整路径占位符：{{header.账号名}}
        replacements["{{" + k + "}}"] = str_v

        # 处理短路径
        if "." in k:
            parts = k.split(".")
            # 跳过_raw字典下的字段，避免覆盖其他模块的同名字段
            if parts[0] == "_raw":
                continue
            # 最短路径（最后一层）：{{账号名}}、{{当前阶段}}
            replacements["{{" + parts[-1] + "}}"] = str_v

            # 关键短路径：保留最后两层（如 生命周期.当前阶段）
            # 对于三层及以上结构，生成最后两层的短路径
            if len(parts) >= 2:
                # 生成最后两层的短路径，但要处理数组索引
                # 例如：conclusion.生命周期.当前阶段 -> 生命周期.当前阶段
                # 例如：fans_insight.核心需求反推[0].画像特征 -> 核心需求反推[0].画像特征
                # 例如：action.30天目标.粉丝数.当前 -> 30天目标.粉丝数.当前
                key_short = ".".join(parts[-2:])
                replacements["{{" + key_short + "}}"] = str_v

            # 对于四层结构，生成最后三层的短路径
            # 例如：action.30天目标.粉丝数.当前 -> 30天目标.粉丝数.当前（已由上面处理）
            if len(parts) >= 3:
                key_short_3 = ".".join(parts[-3:])
                replacements["{{" + key_short_3 + "}}"] = str_v

    # 评分百分比
    for dim, max_score in SCORE_MAX_MAP.items():
        score_key = dim + "得分"
        pct_key = dim + "得分_pct"
        score_val = replacements.get("{{" + score_key + "}}", "0")
        try:
            pct = round(int(score_val) / max_score * 100)
        except (ValueError, ZeroDivisionError):
            pct = 0
        replacements["{{" + pct_key + "}}"] = str(pct)

    # 近期作品表格行
    works_rows = []
    for w in report_data.get("works", []):
        if not isinstance(w, dict):
            continue
        title = w.get("title", "无标题")[:15].replace(" ", "")
        if not title.strip():
            title = "无标题"
        date_str = w.get("date", "-") or "-"
        likes = w.get("likes", "0") or "0"
        url = w.get("url", "") or ""
        link = f'<a href="{url}" target="_blank">查看</a>' if url else "-"
        works_rows.append(f"<tr><td>{title}</td><td>{date_str}</td><td>{likes}</td><td>{link}</td></tr>")
    replacements["{{works_table_rows}}"] = "\n".join(works_rows)

    return replacements


def _is_empty_field(val):
    """判断字段是否为空"""
    return str(val).strip() in ("", "None", "none")


def _remove_section_markers(html, marker_name, should_show):
    """根据条件移除或保留标记区域"""
    start_tag = f"<!-- {marker_name}_START -->"
    end_tag = f"<!-- {marker_name}_END -->"
    if should_show:
        html = html.replace(start_tag, "").replace(end_tag, "")
    else:
        html = re.sub(rf'<!-- {marker_name}_START -->.*?<!-- {marker_name}_END -->', '', html, flags=re.DOTALL).rstrip()
    return html


def _remove_empty_info_rows(html):
    """移除HTML中值为空的info-row行"""
    html = re.sub(r'<div class="info-row">\s*<span class="label">[^<]*</span>\s*<span class="value">\s*</span>\s*</div>', '', html)
    return html


def _remove_conditional_sections(html, report_data):
    """根据数据条件移除空数据模块"""
    scores = report_data.get("scores", {})

    # 爆文能力：爆文数为0时隐藏爆文特征
    viral_count = scores.get("爆文数", "")
    try:
        viral_val = int(viral_count) if not _is_empty_field(viral_count) else 0
    except (ValueError, TypeError):
        viral_val = 0
    html = _remove_section_markers(html, "SECTION_VIRAL", viral_val > 0)

    # 近期作品：works为空时隐藏
    works = report_data.get("works", [])
    has_valid_works = any(isinstance(w, dict) and w.get("title", "").strip() for w in works)
    html = _remove_section_markers(html, "SECTION_WORKS", has_valid_works)

    # 可强化：账号定位>=8分时隐藏（优先使用显示可强化字段，否则根据得分判断）
    positioning = report_data.get("positioning", {})
    show_can_enhance = positioning.get("显示可强化", None)
    if show_can_enhance is None:
        # 如果没有显示可强化字段，则根据账号定位得分判断
        scores = report_data.get("scores", {})
        positioning_score = scores.get("账号定位得分", 0)
        show_can_enhance = positioning_score < 8
    html = _remove_section_markers(html, "SECTION_CAN_ENHANCE", show_can_enhance)

    return html


def cmd_generate_html():
    """生成单账号HTML命令 - 直接使用report_data.json中的similar_accounts数据"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.normpath(os.path.join(script_dir, "..", "output", REPORT_DATA_FILE))
    template_path = os.path.normpath(os.path.join(script_dir, "..", "assets", "report_template.html"))
    raw_data_path = os.path.normpath(os.path.join(script_dir, "..", "output", "raw_data.json"))

    if not os.path.exists(data_path):
        print(json.dumps({"status": "error", "message": f"报告数据文件不存在: {data_path}，请先完成诊断报告生成并保存report_data.json"}, ensure_ascii=False))
        sys.exit(1)

    if not os.path.exists(template_path):
        print(json.dumps({"status": "error", "message": f"模板文件不存在: {template_path}"}, ensure_ascii=False))
        sys.exit(1)

    with open(data_path, "r", encoding="utf-8") as f:
        report_data = json.load(f)

    # 读取原始数据作为备用数据源
    raw_data = {}
    if os.path.exists(raw_data_path):
        try:
            with open(raw_data_path, "r", encoding="utf-8") as f:
                raw_data = json.load(f)
        except Exception:
            pass  # 原始数据读取失败时忽略

    with open(template_path, "r", encoding="utf-8") as f:
        html = f.read()

    replacements = _build_replacements(report_data)

    # 相似账号卡片（账号名称为超链接）- 直接使用report_data.json中的similar_accounts
    # 每个账号一行，展示：账号名称（超链接）、粉丝数、总互动、推荐理由、发文特点、可学之处
    similar_cards = []
    for sa in report_data.get("similar_accounts", []):
        if not isinstance(sa, dict):
            continue
        name = sa.get("账号名称") or sa.get("accountName") or sa.get("nickname") or sa.get("name", "")
        account_url = sa.get("账号链接") or sa.get("profileUrl") or sa.get("url", "")
        fans_count = sa.get("粉丝数") or sa.get("followerCount") or sa.get("fans") or sa.get("fansCount", 0)
        total_interactive = sa.get("总互动") or sa.get("totalInteractiveCount") or sa.get("interactiveCountThirty", 0)
        recommend_reason = sa.get("推荐理由") or sa.get("recommendReason") or ""
        post_feature = sa.get("发文特点") or sa.get("postFeature") or ""
        learn_point = sa.get("可学之处") or sa.get("learnPoint") or ""

        # 账号名称超链接
        name_html = f'<a href="{account_url}" target="_blank" style="color:#1890ff;text-decoration:none;font-weight:500;">{name}</a>' if account_url else name
        # 如果没有链接但有accountId，构造链接
        if not account_url:
            account_id = sa.get("accountId") or sa.get("redId") or sa.get("userId", "")
            if account_id:
                account_url = f"https://www.xiaohongshu.com/user/profile/{account_id}"
                name_html = f'<a href="{account_url}" target="_blank" style="color:#1890ff;text-decoration:none;font-weight:500;">{name}</a>'

        similar_cards.append(
            f'<div class="similar-card-row" style="padding:12px 0;border-bottom:1px solid #f0f0f0;">'
            f'<div style="margin-bottom:6px;"><strong>{name_html}</strong> | 粉丝：{fans_count} | 总互动：{total_interactive}</div>'
            f'<div style="font-size:13px;color:#666;margin-bottom:4px;"><strong>推荐理由：</strong>{recommend_reason}</div>'
            f'<div style="font-size:13px;color:#666;margin-bottom:4px;"><strong>发文特点：</strong>{post_feature}</div>'
            f'<div style="font-size:13px;color:#666;"><strong>可学之处：</strong>{learn_point}</div>'
            f'</div>'
        )
    replacements["{{similar_accounts_cards}}"] = "\n".join(similar_cards)

    # 执行替换
    for key, val in replacements.items():
        html = html.replace(key, val)

    # 条件移除空数据模块
    html = _remove_conditional_sections(html, report_data)

    # 相似账号区域 - 直接展示（移除条件注释）
    html = html.replace("<!-- SIMILAR_START -->", "").replace("<!-- SIMILAR_END -->", "")

    html = _remove_empty_info_rows(html)

    # ========== 自检：检测未替换的模板字段 ==========
    import re
    unreplaced = re.findall(r'\{\{[^}]+\}\}', html)
    if unreplaced:
        # 收集所有未替换的字段
        unique_unreplaced = list(set(unreplaced))
        # 扁平化分析数据和原始数据
        flat_data = _flatten_dict(report_data)
        flat_raw = _flatten_dict(raw_data) if raw_data else {}

        # 字段名映射：模板字段名 -> 原始数据字段名
        field_mapping = {
            "总收藏数": "collected",
            "总点赞数": "liked",
            "粉丝数": "fans",
            "近30天互动量": "interactions_30d",
            "近30天发作品数": "works_30d",
            "作品总数": "works_total",
            "账号名": "nickname",
            "官方等级": "level",
        }

        for field in unique_unreplaced:
            field_name = field[2:-2]  # 移除 {{ 和 }}
            found_value = None

            # 第一步：从分析数据中查找
            for k, v in flat_data.items():
                if k == field_name or k.endswith("." + field_name):
                    if v is not None and str(v).strip() != "" and str(v) != "0":
                        found_value = v
                        break

            # 第二步：分析数据为空，从原始数据中查找
            if found_value is None and flat_raw:
                # 先尝试字段名映射
                if field_name in field_mapping:
                    raw_field = field_mapping[field_name]
                    for k, v in flat_raw.items():
                        if k == raw_field or k.endswith("." + raw_field):
                            if v is not None and str(v).strip() != "":
                                found_value = v
                                # 格式化大数字
                                if field_name in ["总收藏数", "总点赞数", "粉丝数", "近30天互动量"]:
                                    found_value = _format_interactive_count(v)
                                break
                # 再尝试直接匹配字段名
                if found_value is None:
                    for k, v in flat_raw.items():
                        if k == field_name or k.endswith("." + field_name):
                            if v is not None and str(v).strip() != "":
                                found_value = v
                                break

            # 第三步：根据值进行处理
            if found_value is not None and str(found_value).strip() != "":
                html = html.replace(field, str(found_value))
            else:
                # 数据中无值，根据字段类型填充默认值
                numeric_fields = ["得分", "分", "粉丝", "互动", "收藏", "点赞", "数", "率", "量", "倍", "篇", "天", "中位数参考", "优秀值参考", "等级"]
                is_numeric = any(nf in field_name for nf in numeric_fields)
                if is_numeric:
                    html = html.replace(field, "0")
                else:
                    html = html.replace(field, "")

        # 再次检查是否还有未替换字段
        remaining = re.findall(r'\{\{[^}]+\}\}', html)
        if remaining:
            print(json.dumps({
                "status": "error",
                "message": f"HTML模板字段未完全替换: {list(set(remaining))}",
                "unreplaced_fields": list(set(remaining))
            }, ensure_ascii=False))
            sys.exit(1)

    # 输出HTML文件
    output_dir = os.path.normpath(os.path.join(script_dir, "..", "output"))
    os.makedirs(output_dir, exist_ok=True)

    safe_name = report_data.get("header", {}).get("账号名", "report").replace("/", "_").replace("\\", "_")
    output_path = os.path.join(output_dir, f"{safe_name}_诊断报告.html")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    result_info = {
        "status": "success",
        "message": "HTML报告已生成",
        "output_path": output_path
    }
    print(json.dumps(result_info, ensure_ascii=False))


def _build_account_detail_html(account_data, account_index):
    """为多账号报告生成单个账号的详情HTML"""
    replacements = _build_replacements(account_data)

    # 评分条
    for dim, max_score in SCORE_MAX_MAP.items():
        score_key = dim + "得分"
        pct_key = dim + "得分_pct"
        score_val = replacements.get("{{" + score_key + "}}", "0")
        try:
            pct = round(int(score_val) / max_score * 100)
        except (ValueError, ZeroDivisionError):
            pct = 0
        replacements["{{" + pct_key + "}}"] = str(pct)

    header = account_data.get("header", {})
    raw_data = account_data.get("_raw", {})
    avatar = raw_data.get("头像", "")
    name = header.get("账号名", "")
    tag = header.get("账号标识", "")
    score = replacements.get("{{综合评分}}", "-")

    # 构建详情HTML（简化版，用于多账号对比）
    detail = f'''  <div class="account-detail">
    <div class="account-detail-header">
      <img src="{avatar}" onerror="this.style.display='none'">
      <span class="name">{name}</span>
      <span class="tag">{tag}</span>
      <span class="score">{score}分</span>
    </div>
    <div class="account-detail-body">
      <div class="score-bars">
        <div class="score-bar-item"><span class="name">账号定位</span><div class="bar-bg"><div class="bar-fill" style="width:{replacements.get("{{账号定位得分_pct}}", "0")}%"></div></div><span class="val">{replacements.get("{{账号定位得分}}", "0")}分</span></div>
        <div class="score-bar-item"><span class="name">粉丝画像</span><div class="bar-bg"><div class="bar-fill" style="width:{replacements.get("{{粉丝画像与需求得分_pct}}", "0")}%"></div></div><span class="val">{replacements.get("{{粉丝画像与需求得分}}", "0")}分</span></div>
        <div class="score-bar-item"><span class="name">选题体系</span><div class="bar-bg"><div class="bar-fill" style="width:{replacements.get("{{选题体系得分_pct}}", "0")}%"></div></div><span class="val">{replacements.get("{{选题体系得分}}", "0")}分</span></div>
        <div class="score-bar-item"><span class="name">封面风格</span><div class="bar-bg"><div class="bar-fill" style="width:{replacements.get("{{封面风格得分_pct}}", "0")}%"></div></div><span class="val">{replacements.get("{{封面风格得分}}", "0")}分</span></div>
        <div class="score-bar-item"><span class="name">爆文能力</span><div class="bar-bg"><div class="bar-fill" style="width:{replacements.get("{{爆文能力得分_pct}}", "0")}%"></div></div><span class="val">{replacements.get("{{爆文能力得分}}", "0")}分</span></div>
        <div class="score-bar-item"><span class="name">互动规模</span><div class="bar-bg"><div class="bar-fill" style="width:{replacements.get("{{互动规模得分_pct}}", "0")}%"></div></div><span class="val">{replacements.get("{{互动规模得分}}", "0")}分</span></div>
        <div class="score-bar-item"><span class="name">更新产能</span><div class="bar-bg"><div class="bar-fill" style="width:{replacements.get("{{更新产能得分_pct}}", "0")}%"></div></div><span class="val">{replacements.get("{{更新产能得分}}", "0")}分</span></div>
      </div>

      <div style="margin-top:12px; font-weight:600; font-size:13px; color:#FF2442;">综合诊断</div>
      <div class="conclusion">
        <p>{replacements.get("{{综合诊断结论内容}}", "")}</p>
      </div>'''

    # 行动处方
    detail += f'''
      <div style="margin-top:10px; font-weight:600; font-size:13px; color:#FF2442;">行动处方</div>
      <div class="action-item"><strong>问题归因</strong>：<br>• {replacements.get("{{问题归因1}}", "")}<br>• {replacements.get("{{问题归因2}}", "")}</div>
      <div class="action-item"><strong>具体动作</strong>：<br>1. {replacements.get("{{具体动作1}}", "")}<br>2. {replacements.get("{{具体动作2}}", "")}<br>3. {replacements.get("{{具体动作3}}", "")}</div>'''

    detail += '''
    </div>
  </div>'''

    detail = _remove_empty_info_rows(detail)
    return detail


def cmd_generate_multi_html(with_similar=False):
    """生成多账号对比HTML命令"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.normpath(os.path.join(script_dir, "..", "output", MULTI_REPORT_DATA_FILE))
    template_path = os.path.normpath(os.path.join(script_dir, "..", "assets", "multi_report_template.html"))

    if not os.path.exists(data_path):
        print(json.dumps({"status": "error", "message": f"多账号报告数据文件不存在: {data_path}，请先保存multi_report_data.json"}, ensure_ascii=False))
        sys.exit(1)

    if not os.path.exists(template_path):
        print(json.dumps({"status": "error", "message": f"多账号模板文件不存在: {template_path}"}, ensure_ascii=False))
        sys.exit(1)

    with open(data_path, "r", encoding="utf-8") as f:
        multi_data = json.load(f)

    with open(template_path, "r", encoding="utf-8") as f:
        html = f.read()

    accounts = multi_data.get("accounts", [])
    if not accounts:
        print(json.dumps({"status": "error", "message": "accounts数组为空，无账号数据"}, ensure_ascii=False))
        sys.exit(1)

    html = html.replace("{{账号数量}}", str(len(accounts)))

    data_time = multi_data.get("header", {}).get("数据获取时间", "")
    if not data_time and accounts:
        data_time = accounts[0].get("header", {}).get("数据获取时间", "")
    html = html.replace("{{数据获取时间}}", data_time)

    # 对比表头
    header_cells = []
    for acc in accounts:
        name = acc.get("header", {}).get("账号名", "")
        header_cells.append(f"<th>{name}</th>")
    html = html.replace("{{对比表头}}", "".join(header_cells))

    # 对比表格行
    compare_rows = []
    metrics = [
        ("综合评分", "scores", "综合评分"),
        ("近30天互动量", "interactive_scale", "近30天互动量"),
        ("周更频率", "update_rhythm", "周更频率"),
        ("爆文率", "viral", "爆文率"),
        ("账号定位", "scores", "账号定位得分"),
        "separator",
        ("互动规模", "scores", "互动规模得分"),
        ("爆文能力", "scores", "爆文能力得分"),
        ("更新产能", "scores", "更新产能得分"),
        ("粉丝画像", "scores", "粉丝画像与需求得分"),
        ("选题体系", "scores", "选题体系得分"),
        ("封面风格", "scores", "封面风格得分"),
    ]

    best_map = {}
    for item in metrics:
        if item == "separator":
            continue
        label, section, key = item
        values = []
        for acc in accounts:
            sec = acc.get(section, {})
            raw_val = sec.get(key, "")
            try:
                v = float(raw_val) if str(raw_val).strip() not in ("",) else None
            except (ValueError, TypeError):
                v = None
            values.append(v)
        valid_vals = [v for v in values if v is not None]
        if valid_vals:
            best_map[key] = max(valid_vals)

    for item in metrics:
        if item == "separator":
            compare_rows.append('<tr style="height:4px;background:#FDE8EC;"><td colspan="99"></td></tr>')
            continue
        label, section, key = item
        cells = [f"<td>{label}</td>"]
        for acc in accounts:
            sec = acc.get(section, {})
            raw_val = sec.get(key, "")
            val_str = str(raw_val) if raw_val else ""
            if val_str.strip() == "":
                cells.append("<td>-</td>")
                continue
            try:
                num_val = float(raw_val) if str(raw_val).strip() not in ("",) else None
            except (ValueError, TypeError):
                num_val = None
            if num_val is not None and key in best_map and num_val == best_map[key]:
                cells.append(f'<td class="best">{val_str}</td>')
            else:
                cells.append(f"<td>{val_str}</td>")
        compare_rows.append("<tr>" + "".join(cells) + "</tr>")
    html = html.replace("{{对比表格行}}", "\n".join(compare_rows))

    # 对比总结
    comparison = multi_data.get("comparison", {})

    diff_items = comparison.get("核心差异", [])
    diff_html = ""
    if diff_items:
        diff_html = '<div class="summary-module summary-diff"><div class="module-title"><span class="icon">⚡</span> 核心差异</div>'
        for item in diff_items:
            if isinstance(item, dict):
                acc_name = item.get("账号名", "")
                content = item.get("内容", "")
                if content:
                    diff_html += f'<div style="margin-bottom:8px; padding:6px 10px; background:#fff; border-radius:6px;"><span style="font-weight:600; color:#D48806; font-size:12px;">{acc_name}</span><p style="font-size:13px; color:#555; line-height:1.8; margin:4px 0 0;">{content}</p></div>'
        diff_html += '</div>'
    html = html.replace("{{对比总结_核心差异}}", diff_html)

    common_items = comparison.get("共同问题", [])
    common_html = ""
    if common_items:
        common_html = '<div class="summary-module summary-common"><div class="module-title"><span class="icon">🔗</span> 共同问题</div><ul style="padding-left:18px; margin:0;">'
        for item in common_items:
            if isinstance(item, str) and item.strip():
                common_html += f'<li style="font-size:13px; color:#555; line-height:1.8;">{item}</li>'
        common_html += '</ul></div>'
    html = html.replace("{{对比总结_共同问题}}", common_html)

    advice_items = comparison.get("发展建议", [])
    advice_html = ""
    if advice_items:
        advice_html = '<div class="summary-module summary-advice"><div class="module-title"><span class="icon">🚀</span> 发展建议</div>'
        for item in advice_items:
            if isinstance(item, dict):
                acc_name = item.get("账号名", "")
                content = item.get("内容", "")
                if content:
                    advice_html += f'<div style="margin-bottom:8px; padding:6px 10px; background:#fff; border-radius:6px;"><span style="font-weight:600; color:#FF2442; font-size:12px;">{acc_name}</span><p style="font-size:13px; color:#555; line-height:1.8; margin:4px 0 0;">{content}</p></div>'
        advice_html += '</div>'
    html = html.replace("{{对比总结_发展建议}}", advice_html)

    # 各账号详情
    details = []
    for i, acc in enumerate(accounts):
        details.append(_build_account_detail_html(acc, i))
    html = html.replace("{{各账号详情}}", "\n".join(details))

    # 条件移除空数据模块
    html = _remove_conditional_sections(html, multi_data)
    html = _remove_empty_info_rows(html)

    # ========== 自检：检测未替换的模板字段 ==========
    import re
    unreplaced = re.findall(r'\{\{[^}]+\}\}', html)
    if unreplaced:
        unique_unreplaced = list(set(unreplaced))
        # 对于空值字段，根据数据类型处理
        flat_multi = _flatten_dict(multi_data)
        for field in unique_unreplaced:
            field_name = field[2:-2]  # 移除 {{ 和 }}
            # 在扁平化数据中查找对应值
            found_value = None
            for k, v in flat_multi.items():
                if k == field_name or k.endswith("." + field_name):
                    found_value = v
                    break
            # 也在各账号数据中查找
            if found_value is None or found_value == "":
                for acc in accounts:
                    flat_acc = _flatten_dict(acc)
                    for k, v in flat_acc.items():
                        if k == field_name or k.endswith("." + field_name):
                            found_value = v
                            break
                    if found_value is not None and found_value != "":
                        break
            if found_value is not None and found_value != "":
                # 数据中有值，使用该值
                html = html.replace(field, str(found_value))
            else:
                # 数据中无值，根据字段类型填充默认值
                numeric_fields = ["得分", "分", "粉丝", "互动", "收藏", "点赞", "数", "率", "量", "倍", "篇", "天", "中位数参考", "优秀值参考", "等级"]
                is_numeric = any(nf in field_name for nf in numeric_fields)
                if is_numeric:
                    html = html.replace(field, "0")
                else:
                    html = html.replace(field, "")
        remaining = re.findall(r'\{\{[^}]+\}\}', html)
        if remaining:
            print(json.dumps({
                "status": "error",
                "message": f"HTML模板字段未完全替换: {list(set(remaining))}",
                "unreplaced_fields": list(set(remaining))
            }, ensure_ascii=False))
            sys.exit(1)

    # 输出HTML文件
    output_dir = os.path.normpath(os.path.join(script_dir, "..", "output"))
    os.makedirs(output_dir, exist_ok=True)

    names = [acc.get("header", {}).get("账号名", "未知") for acc in accounts[:3]]
    safe_name = "vs".join(n.replace("/", "_").replace("\\", "_") for n in names)
    output_path = os.path.join(output_dir, f"{safe_name}_对比报告.html")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    result_info = {
        "status": "success",
        "message": "多账号对比HTML报告已生成",
        "output_path": output_path
    }
    print(json.dumps(result_info, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description="小红书账号诊断师")
    subparsers = parser.add_subparsers(dest="command")

    # 查询子命令
    query_parser = subparsers.add_parser("query", help="查询账号数据")
    query_parser.add_argument("--user_ids", help="小红书账号ID列表，逗号分隔", required=True)
    query_parser.add_argument("--force_analyze", action="store_true", help="强制执行分析（即使无作品数据）")

    # 同步作品子命令
    sync_parser = subparsers.add_parser("sync_notes", help="同步账号作品数据")
    sync_parser.add_argument("--red_ids", help="小红书redId列表，逗号分隔", required=True)
    sync_parser.add_argument("--account_names", help="账号名称列表，逗号分隔（用于提示）", required=False)

    # 生成单账号HTML子命令
    html_parser = subparsers.add_parser("generate_html", help="基于report_data.json生成单账号HTML报告")

    # 生成多账号对比HTML子命令
    multi_parser = subparsers.add_parser("generate_multi_html", help="基于multi_report_data.json生成多账号对比HTML报告")

    args = parser.parse_args()

    if args.command == "query":
        user_ids = [x.strip() for x in args.user_ids.split(",") if x.strip()]

        if not user_ids:
            print(json.dumps({
                "status": "error",
                "message": "请提供至少一个账号ID（--user_ids）"
            }, ensure_ascii=False))
            sys.exit(1)

        cmd_query(user_ids, force_analyze=getattr(args, 'force_analyze', False))

    elif args.command == "sync_notes":
        red_ids = [x.strip() for x in args.red_ids.split(",") if x.strip()]
        if not red_ids:
            print(json.dumps({
                "status": "error",
                "message": "请提供至少一个redId（--red_ids）"
            }, ensure_ascii=False))
            sys.exit(1)
        account_names = [x.strip() for x in args.account_names.split(",") if x.strip()] if args.account_names else []
        cmd_sync_notes(red_ids, account_names)

    elif args.command == "generate_html":
        cmd_generate_html()

    elif args.command == "generate_multi_html":
        cmd_generate_multi_html()

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
