# 星情报分析（xinqingbao-analysis）— 分发安装指南

> **版本**：v4.7 | **最后更新**：2026-04-27 | **作者**：小贝 (AI Assistant)

---

## 📦 这是什么？

这是一个 **WorkBuddy Skill**（技能插件），用于对卫星通信/航天/卫星互联网行业的新闻事件进行**深度专业分析**，自动生成 6000~7000 字的中文公文格式研究报告（Word 文档）。

### 核心能力

- 🔍 **多源信息检索**：IMA 知识库 + 270+ 权威行业网站逐类排查 + PDF 文档深挖
- 📝 **四型文章结构**：自动匹配战略规划(A)/产品(B)/技术(C)/事件(D) 四种分析框架
- 📄 **Word 自动生成**：中文公文格式（黑体/楷体/仿宋、A4、28磅行距、脚注上标）
- ⚖️ **信源冲突校验(v4.7)**：多来源矛盾按优先级自动裁定，不确定信息括号标注
- 💬 **交互式需求确认**：任务类型/侧重点/字数/风格均可自定义

---

## 📁 目录结构

```
xinqingbao-analysis/
├── SKILL.md                          # ★ 核心文件：完整工作流定义（~78KB）
├── README.md                         # 本文件：安装与使用说明
│
├── references/                       # 参考资料目录
│   ├── article_template_v2.md        # 文章模板 v2
│   ├── article_template_v4.md        # 文章模板 v4（四型结构）
│   ├── websites.md                   # 权威网站速查表
│   └── workflow_config.json          # ★ 270+ 网站清单 + 检索策略配置
│
├── scripts/                          # 脚本目录
│   └── gen_py_v4.py                  # Word 排版引擎（基于 python-docx）
│
└── assets/                           # 资源目录（预留）
```

---

## 🚀 安装步骤（3 步）

### 第1步：解压到 skill 目录

将本 zip 包解压到以下路径：

```
~/.workbuddy/skills/xinqingbao-analysis/
```

**Windows 操作示例**：

```powershell
# 创建目标目录（如果不存在）
New-Item -Path "$env:USERPROFILE\.workbuddy\skills\xinqingbao-analysis" -ItemType Directory -Force

# 解压到此目录
Expand-Archive -Path "下载路径\xinqingbao-analysis-v4.7.zip" -DestinationPath "$env:USERPROFILE\.workbuddy\skills\xinqingbao-analysis"
```

**macOS / Linux 操作示例**：

```bash
mkdir -p ~/.workbuddy/skills/xinqingbao-analysis
unzip xinqingbao-analysis-v4.7.zip -d ~/.workbuddy/skills/
```

### 第2步：安装 Python 依赖（可选，仅需要 Word 输出时）

如需自动生成 Word 文档（.docx），需安装 python-docx：

```bash
pip install python-docx
```

> ⚠️ **不需要 Word 输出？** 可以跳过此步。分析结果会以 Markdown 文本形式返回。

### 第3步：配置 IMA 凭证（可选，仅需要知识库检索时）

如需使用"星情报"知识库检索功能，需准备 IMA API 凭证：

1. 在腾讯 IMA 平台申请 API 密钥
2. 将凭证保存到本地：
   - `~/.config/ima/client_id` （内容为 client_id 字符串）
   - `~/.config/ima/api_key` （内容为 api_key 字符串）

> ⚠️ **没有凭证？** 不影响使用。Step 2（IMA 检索）会跳过，流程自动依赖 Step 3（行业网站搜索）。

---

## ✅ 验证安装成功

在 WorkBuddy 对话中输入：

> 用 xinqingbao-analysis 分析一下 XXX 新闻

如果 AI 能识别并加载此 skill，说明安装成功！

---

## 🔧 可选自定义配置

| 配置项 | 文件位置 | 说明 |
|--------|---------|------|
| 自定义网站清单 | `references/workflow_config.json` | 编辑 `websites_v4` 节增删站点 |
| 调整检索策略 | `references/workflow_config.json` | 修改搜索参数/关键词模板 |
| 修改输出格式 | `scripts/gen_py_v4.py` | 调整字体/字号/行距等排版参数 |
| 调整文章模板 | `references/article_template_v4.md` | 修改四种类型的章节框架 |

---

## 📋 功能矩阵（按依赖条件）

| 功能模块 | 最小依赖 | 完整依赖 |
|---------|---------|---------|
| 输入解析（URL/文本/问题） | ✅ 仅需 SKILL.md | — |
| 任务类型判定 + 需求确认 | ✅ 仅需 SKILL.md | — |
| 补充资料收集（v4.6） | ✅ 仅需 SKILL.md | — |
| 行业网站搜索（R1-R4） | ✅ 仅需 SKILL.md | `references/workflow_config.json` |
| IMA 知识库检索 | 需要 IMA 凭证 | IMA 凭证 |
| 信源冲突校验（v4.7） | ✅ 内置逻辑 | — |
| Word 文档输出 | 需要 Python + python-docx | Python + python-docx + `scripts/gen_py_v4.py` |
| Markdown 输出 | ✅ 内置逻辑 | — |

> **最简可用状态**：仅需 `SKILL.md` 即可运行核心流程（输入→搜索→分析→Markdown 返回）

---

## 🔄 版本历史

| 版本 | 日期 | 核心变更 |
|------|------|---------|
| v4.0 | 2026-04-25 | 基础版：多模式输入 + 需求确认 + 网站搜索 + Word 输出 |
| v4.1 | 2026-04-25 | 事实准确性铁律 + 全面性检查机制(17类) + PDF文档深挖 |
| v4.2 | 2026-04-25 | 四型文章结构系统（A/B/C/D）+ 任务类型判定 |
| v4.3 | 2026-04-25 | 排版引擎 v4.1 中文公文格式体系 |
| v4.4 | 2026-04-25 | 排版引擎 v4.2 代码块转表格修复 |
| v4.5 | 2026-04-26 | 排版引擎 v4.3 代码块转换质量重写（三模式拆分）|
| v4.6 | 2026-04-26 | Step 1.6 用户补充资料收集环节 |
| **v4.7** | **2026-04-27** | **信源冲突校验 + 不确定信息标注 + 分发通用化** |

---

## 📌 注意事项

1. **CJK 字体要求**：Word 输出依赖系统中文字体（SimHei 黑体、KaiTi 楷体、FangSong 仿宋）。Windows 系统默认自带；macOS/Linux 可能需要手动安装中文字体。
2. **Python 版本**：推荐 Python 3.8+。
3. **网络访问**：工作流需要联网进行 web_search 和 web_fetch 操作。
4. **知识库覆盖范围**：IMA "星情报"知识库以**中文卫星通信行业内容**为主（5284条）。纯英文产品/公司可能返回 0 条结果，此时自动降级到行业网站搜索。
5. **输出路径**：生成的文件默认保存在当前工作空间的 `output/` 目录下。AI 会动态确定实际路径。

---

## 📮 问题反馈

如有问题或建议，请联系技能作者或在 WorkBuddy 社区反馈。
