# Canvas & Layout

## Aspect Ratios

| Name | Ratio | Pixels | Platform |
|------|-------|--------|----------|
| xhs-standard | 3:4 | 1080×1440 | 小红书首选 |
| xhs-square | 1:1 | 1080×1080 | 小红书备选 |
| pinterest | 2:3 | 1000×1500 | Pinterest 标准 |
| pinterest-long | 1:3 | 1000×3000 | Pinterest 长图 |
| instagram-square | 1:1 | 1080×1080 | IG Feed |
| instagram-portrait | 4:5 | 1080×1350 | IG Feed 竖版 |
| instagram-story | 9:16 | 1080×1920 | Story/Reels |
| youtube-thumbnail | 16:9 | 1280×720 | YouTube 封面 |
| twitter-card | 1.91:1 | 1200×628 | Twitter 卡片 |

## Safe Zones

```
┌─────────────────────────────┐
│                 [like/share]│  ← 右上角：避开
│                             │
│      ✓ 安全内容区域          │
│                             │
│  [标题栏覆盖区]              │  ← 底部10%：避开关键信息
└─────────────────────────────┘
```

## Layout Definitions

### sparse（稀疏）
- 信息密度：低（1-2个要点）
- 留白：60-70%
- 用途：封面、金句、单牌解读
- 结构：一个大标题 + 一个核心视觉元素

### balanced（均衡）
- 信息密度：中（3-4个要点）
- 留白：40-50%
- 用途：性格解读、标准内容
- 结构：标题 + 2-3个分段 + 配图元素

### dense（密集）
- 信息密度：高（5-8个要点）
- 留白：20-30%
- 用途：知识卡片、对照表
- 结构：标题 + 多个小节 + 紧凑排列

### list（列表）
- 项目数：4-7个
- 用途：排行榜、清单
- 结构：编号/图标 + 文字，垂直排列

### comparison（对比）
- 双栏结构
- 用途：合盘（你 vs ta）、正位 vs 逆位
- 结构：左右分栏，中间分割线

### flow（流程）
- 节点数：3-6步
- 用途：教程、时间线
- 结构：节点 + 箭头/连线

### card（卡片）
- 单焦点
- 用途：单张塔罗牌、星宿卡
- 结构：主图居中 + 名称 + 简短描述

### spread（牌阵）
- 多位置
- 用途：塔罗牌阵展示
- 结构：多张小卡按牌阵位置排列

## Position Guidelines

| Position | Layout | Purpose |
|----------|--------|---------|
| 封面(第1张) | sparse | 吸引停留，3秒法则 |
| 内容(中间) | balanced/dense/list | 核心价值输出 |
| 结尾(最后) | sparse/balanced | CTA + 互动引导 |
