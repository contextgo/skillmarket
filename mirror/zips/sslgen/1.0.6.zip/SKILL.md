---
name: SSLGen
description: "Generate self-signed SSL certs and CAs for dev environments. Use when creating certs, validating CSRs, generating chains, formatting PEM."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["ssl","certificate","tls","openssl","security","developer"]
categories: ["Developer Tools", "Utility"]
---

# SSLGen — Developer Tools Toolkit

SSLGen v2.0.0 is a developer-focused toolkit for checking, validating, generating, and managing SSL/TLS certificates and related configurations. It provides a comprehensive set of commands for the full certificate lifecycle — from creation and validation through format conversion and reporting.

All operations are logged with timestamps and stored locally for full traceability. Each command can record input for later review, or display recent entries when called without arguments.

## Commands

| Command | Description |
|---------|-------------|
| `sslgen check <input>` | Check SSL certificates for validity, expiry, or issues |
| `sslgen validate <input>` | Validate certificate chains, CSRs, or configurations |
| `sslgen generate <input>` | Generate self-signed certs, CAs, or CSRs |
| `sslgen format <input>` | Format certificates between PEM, DER, PKCS formats |
| `sslgen lint <input>` | Lint certificate configurations for best practices |
| `sslgen explain <input>` | Explain certificate fields, extensions, or errors |
| `sslgen convert <input>` | Convert between certificate formats or encodings |
| `sslgen template <input>` | Create or apply certificate configuration templates |
| `sslgen diff <input>` | Compare certificates, keys, or configurations |
| `sslgen preview <input>` | Preview certificate details before generation |
| `sslgen fix <input>` | Fix certificate issues (permissions, chains, formats) |
| `sslgen report <input>` | Generate reports on certificate inventory or status |
| `sslgen stats` | Show summary statistics across all command categories |
| `sslgen export <fmt>` | Export all data (formats: `json`, `csv`, `txt`) |
| `sslgen search <term>` | Search across all log entries for a keyword |
| `sslgen recent` | Show the 20 most recent activity log entries |
| `sslgen status` | Health check — version, data dir, entry count, disk usage |
| `sslgen help` | Show help with all available commands |
| `sslgen version` | Print current version (v2.0.0) |

Each certificate command (check, validate, generate, etc.) works in two modes:
- **With arguments** — saves the input with a timestamp to its dedicated log file
- **Without arguments** — displays the 20 most recent entries from that log

## Data Storage

All data is stored locally in `~/.local/share/sslgen/`:

- **Per-command logs**: `check.log`, `validate.log`, `generate.log`, `format.log`, `lint.log`, `explain.log`, `convert.log`, `template.log`, `diff.log`, `preview.log`, `fix.log`, `report.log`
- **Activity history**: `history.log` — chronological log of all operations
- **Exports**: `export.json`, `export.csv`, or `export.txt` when using the export command

Log format: `YYYY-MM-DD HH:MM|<input>` (pipe-delimited timestamp and value).

## Requirements

- **Bash** 4.0+ (uses `set -euo pipefail`)
- **Standard Unix tools**: `date`, `wc`, `du`, `head`, `tail`, `grep`, `basename`, `cat`
- No external dependencies, API keys, or network access required
- Works on Linux and macOS

## When to Use

1. **Local development SSL setup** — Use `sslgen generate` to create self-signed certificates for development, `sslgen template` to maintain reusable configs, and `sslgen preview` to verify before generating
2. **Certificate auditing** — Use `sslgen check` to verify certificate validity, `sslgen lint` to catch misconfigurations, and `sslgen report` for inventory summaries across environments
3. **Format conversion tasks** — Use `sslgen convert` to switch between PEM, DER, and PKCS formats, `sslgen format` for standardization, and `sslgen diff` to compare before and after
4. **Troubleshooting SSL errors** — Use `sslgen explain` to decode certificate errors, `sslgen validate` to verify chain integrity, and `sslgen fix` to track remediation steps
5. **Certificate lifecycle management** — Use `sslgen check` to monitor expiry dates, `sslgen report` for compliance audits, and `sslgen export json` to feed data into monitoring systems

## Examples

### Generate and validate certificates

```bash
# Generate a self-signed cert
sslgen generate "localhost self-signed, CN=localhost, SAN=127.0.0.1, 365 days"

# Validate a certificate chain
sslgen validate "Chain: root-ca.pem -> intermediate.pem -> server.pem — OK"

# Check certificate expiry
sslgen check "api.example.com cert expires in 45 days, SHA-256, 2048-bit RSA"

# Preview before generating
sslgen preview "Wildcard cert *.dev.local, ed25519, 90 days"
```

### Format and convert

```bash
# Convert PEM to DER
sslgen convert "server.pem -> server.der (DER format for Java keystore)"

# Format certificate output
sslgen format "Extracted CN, SAN, issuer, expiry from PEM bundle"

# Create a configuration template
sslgen template "OpenSSL config: RSA 4096, SHA-256, SAN with DNS and IP entries"

# Diff two certificates
sslgen diff "Production cert vs staging cert: different SANs, same CA"
```

### Troubleshoot and fix

```bash
# Explain a certificate error
sslgen explain "ERR_CERT_AUTHORITY_INVALID: browser doesn't trust the CA"

# Lint certificate config
sslgen lint "Missing subjectAltName extension, CN-only deprecated since 2017"

# Fix an issue
sslgen fix "Added intermediate CA to chain, reordered PEM bundle"

# Generate a report
sslgen report "Q1 cert audit: 23 certs, 4 expiring within 30 days, 0 SHA-1"
```

### Review and export

```bash
# View recent activity
sslgen recent

# Search for specific entries
sslgen search "wildcard"

# Check overall stats
sslgen stats

# Export everything as JSON
sslgen export json

# Health check
sslgen status
```

## How It Works

SSLGen uses a simple file-based storage system. Each command writes timestamped entries to its own `.log` file in the data directory. The `history.log` file maintains a chronological record of all operations across all commands. The `stats` command aggregates line counts from all log files, while `export` serializes everything into your chosen format (JSON, CSV, or plain text). The `search` command performs case-insensitive grep across all log files.

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
