# Scripts — 接口文档

小作家写作教练 v3.0 的脚本层，遵循"脚本做计量，LLM做判断"原则。

## 通用约定

- 使用 Python 3 标准库，无外部依赖
- 输出格式为 JSON，包含 `success` 字段
- 从 `config.yaml` 读取配置参数（路径相对于 skill 根目录）
- 有模块 docstring 和 `main()` 函数
- 有错误处理（try/except），错误时输出 `{"success": false, "error": ..., "message": ...}`

---

## analyze.py — 作文统计分析

替代旧版 `evaluate.py`，**只做统计不做评分**。

### 用法

```bash
# 通过命令行参数
python3 scripts/analyze.py "作文文本" [年级]

# 通过管道
echo "作文文本" | python3 scripts/analyze.py [年级]
```

### 参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| 作文文本 | string | （必填）| 要分析的作文内容 |
| 年级 | int | 4 | 1-6年级，影响字数目标 |

### 输出

```json
{
  "success": true,
  "data": {
    "statistics": {
      "word_count": 245,
      "word_target": 400,
      "word_completion": "61%",
      "paragraph_count": 3,
      "sentence_count": 12
    },
    "sense_analysis": {
      "视觉": 3, "听觉": 1, "嗅觉": 0, "触觉": 0, "味觉": 0
    },
    "dialogue_count": 2
  }
}
```

### 功能说明

| 功能 | 说明 |
|------|------|
| 字数统计 | 中文字符数（含中文标点） |
| 段落统计 | 按换行或句号分段 |
| 句子统计 | 按句号/叹号/问号/省略号分句 |
| 字数完成度 | 实际字数/目标字数（目标从 config.yaml 读取） |
| 五官词频 | 按5种感官分类统计词数（词库从 config.yaml 的 sense_words_file 读取，不可用时用内置默认词库） |
| 对话句数 | 统计中文引号对数 |

### 不做的事（交给 LLM）

修辞检测、四维评分、水平定位、家长小贴士、综合分计算

---

## main.py — 大纲生成 + 自由表达

### 用法

```bash
# 大纲生成模式
python3 scripts/main.py [题材] [年级]

# 自由表达模式
python3 scripts/main.py --mode express [年级]
```

### 参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| 题材 | string | "想象作文" | 写作题材，支持模糊匹配 |
| 年级 | int | 4 | 1-6年级 |
| --mode express | flag | — | 自由表达模式，不生成大纲 |

### 大纲模式输出

```json
{
  "success": true,
  "data": {
    "topic": "写人",
    "matched_topic": "写人作文",
    "grade": 4,
    "outline": {
      "title": "写人作文大纲",
      "structure": [...],
      "tips": [...],
      "recommended_methods": [...],
      "word_target": 400,
      "grade": 4
    }
  }
}
```

### 自由表达模式输出

```json
{
  "success": true,
  "data": {
    "mode": "express",
    "grade": 4,
    "opening": "嗨！欢迎来到自由写作时间...",
    "guidance": "自由表达模式不生成大纲，不评分，不纠正..."
  }
}
```

### 功能说明

| 功能 | 说明 |
|------|------|
| 大纲生成 | 根据题材和年级生成写作大纲，支持12种题材的模糊匹配 |
| 自由表达 | --mode express 时输出温暖开场白，不生成大纲、不评分 |
| 模板内置 | 大纲模板使用内置模板（outline_templates_dir 已弃用），外置模板不可用时自动回退 |
| 年级适配 | 支持1-6年级，影响字数目标和开场白内容 |

---

## exercise.py — 练习生成

### 用法

```bash
python3 scripts/exercise.py [练习类型] [年级]
```

### 参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| 练习类型 | string | "comprehensive" | 见下表 |
| 年级 | int | 4 | 1-6年级 |

### 练习类型

| 类型ID | 名称 | 说明 |
|--------|------|------|
| sentence_upgrade | 好句升级练习 | 把平淡句子升级成生动好句 |
| senses | 五官描写练习 | 练习用看听闻摸尝五种感官描写 |
| structure | 结构搭建练习 | 练习搭好凤头-猪肚-豹尾结构 |
| emotion | 情感注入练习 | 用动作和细节代替直接说感受 |
| comprehensive | 综合练习 | 综合运用多种方法的写作挑战 |
| reflective | 反思性写作练习 | 心情日记/写给自己的信/成长信模板 |
| mirror | 照镜子练习 | 用四面镜子看自己的作文 |

别名匹配：支持中文别名（如"好句"→sentence_upgrade，"反思"→reflective，"镜子"→mirror）

### 输出

```json
{
  "success": true,
  "data": {
    "name": "反思性写作练习",
    "method": "反思性写作",
    "description": "用写作整理内心世界——不是写作文，是和自己对话",
    "prompt_template": "试试用文字整理一下你的内心世界：",
    "exercises": [
      {
        "type": "心情日记",
        "prompt": "...",
        "hint": "...",
        "template": "..."
      }
    ],
    "grade": 4,
    "tips": ["..."]
  }
}
```

### 新增练习说明

**反思性写作（reflective）**：
- 心情日记：用颜色/天气/味道/音乐形容心情
- 写给自己的信：写给昨天/半年后/毕业时的自己
- 成长信模板：这件事让我学到了______，下次我会______

**照镜子练习（mirror）**：
- 四面镜子：你写了什么 / 你怎么搭的 / 你怎么说的 / 你的感受
- 不打分，只帮孩子"看见"自己的写作
- 按年级调整深度（低年级2面镜子，高年级4面镜子）
