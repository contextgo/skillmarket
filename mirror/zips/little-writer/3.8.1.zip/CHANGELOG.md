# Changelog — little-writer

## [3.8.0] - 2026-05-06

### Added
- ❗ 字数统计纪律硬化：两步强制（主方案analyze.py+备用python3命令），输出时必须附计数方法说明
- ❗ 段落汇编模式词汇回检：AI编译后附词汇对比，让孩子对比自己的原词和AI的词
- ❗ 过渡句强制检查（段落汇编模式）：段落间无自然过渡时AI自编，不打断写作节奏
- ❗ W4内嵌能力升级信号检测：每段审阅后扫描4种信号（修辞/反模板/结构/深度），跨段累积
- ❗ 范文触发条件显式化：3个具体触发条件（卡住>2次/有对应范文/学生求助）
- ❗ 心情温度计：新建 `references/mood-thermometer.md`，会话开始时感知孩子今日状态（5度类比），影响全程策略
- ❗ 工作流缝隙处理：新建 `references/workflow-transitions.md`，覆盖5种缝隙场景（换故事/跑题/求评价/混合信号/写完就走）

### Changed
- 🛠 难度锚定重构：从年级一刀切改为"3句适应期+自动调档"机制
- 🛠 跨段过渡句处理分场景：逐句模式保持原有交互流程，段落汇编模式改为AI自判+静默插入
- 🛠 脚手架Level 3：新增范文引路作为优先策略

### Fixed
- 🐛 cowrite.md 第154行乱码（"一���"→"一起"）
- 🐛 全量版本一致性审计：6个文件版本号滞后（SKILL.md description/PHILOSOPHY/config.yaml/sources.yaml/scripts README/test_basic）
- 🐛 cowrite.md 退出条件是空标题，内容错放在段落均衡性提示节下
- 🐛 sense-words.md 被 analyze.py 引用但未出现在 SKILL.md L2 列表中

### 版本同步
- SKILL.md: frontmatter → 3.8.0 + 字数统计纪律 + 能力升级检测扩展 + L2新增2个文件；body标题去掉版本号（2层规则）
- cowrite.md: 难度锚定重构 + 词汇回检 + 过渡句强制检查 + 范文触发条件 + W4能力检测 + 字数统计强制 + 心情温度计引用 + 缝隙场景引用
- vocabulary-guide.md: W4集成策略新增段落汇编模式说明
- greeting.md: 新增心情温度计感知步骤
- express.md / inspire.md / learn.md / mirror.md: 过渡引导增加缝隙场景引用
- **新增**: references/mood-thermometer.md, references/workflow-transitions.md
- SPEC.md: 标题 → v3.8.0 + 版本历史新增3.8.0行
- DESIGN.md: 标题 → v3.8.0 + 版本历史新增3.8.0行
- README.md: 版本号 + v3.8.0 新增说明

### Added
- ❗ SKILL.md 新增「设计理念」节：明确定义三项底层能力（观察世界的能力、自我觉察情感的能力、用简单/生动/准确的语言表达自己的能力）及终极目标（"我的文章能表达我的内心，我的文章能描绘我的世界"）

### Philosophy
- 确立「三项能力 + 终极目标」作为核心教学框架：通过持续的引导练习，帮助孩子培养观察→觉察→表达的完整能力链

### 版本同步
- SKILL.md: frontmatter → 3.7.0 + body → v3.7.0 + 新增设计理念节
- PHILOSOPHY.md: 版本号 → 3.7.0
- SPEC.md: 标题 → v3.7.0 + 版本历史新增3.7.0行
- DESIGN.md: 标题 → v3.7.0 + 版本历史新增3.7.0行
- README.md: 版本号 + v3.7.0 新增说明 + 设计理念更新
- CHANGELOG.md: 本条目

## [3.6.0] - 2026-05-05

### Added
- ❗ methods-basic.md 新增「环境联动法」：写景时先识别环境个性（水/风/光），让每个画面都和它挂钩
- methods-basic.md 过渡句法新增「中间站技巧」：两个主要景点之间加一个不起眼的小站点，让路线更自然
- W4 cowrite.md 新增「段落均衡性提示」：每写完一段自动对比平均段长，过长提醒分/过短提醒加
- W4 cowrite.md 新增「真实感检查」：每段完成后问"你当时真的有这个感觉吗还是觉得应该这样写"
- W4 cowrite.md 段落汇编模式 Step 6 嵌入真实感检查

### Changed
- PHILOSOPHY.md 第一节信念5深化：从"真实比华丽重要"到"区别你的观察 vs 你的库存"
- rubrics.md 镜子五评估信号：从"禁用成语"改为"区分观察 vs 库存"——问孩子"你写的时候脑子里有画面吗"

### Philosophy
- 「真实感检查」不可回退：AI推出来的情感升华如果孩子说"当时没想那么多"，删——不真实的好句子比真实的普通句子更伤害信心

### Source of changes
- 本次改进完全基于真实用户（张轩硕）与妈妈合作修改的作文版本 vs 纯AI引导版本的对比分析

### 版本同步
- SKILL.md: frontmatter → 3.6.0 + body → v3.6.0
- PHILOSOPHY.md: 版本号 → 3.6.0
- SPEC.md: 版本 → 3.6.0 + 版本历史新增3.6.0行
- DESIGN.md: 版本 → 3.6.0 + 版本历史恢复3.5.2 + 新增3.6.0行

## [3.5.2] - 2026-05-05

### Added
- ❗ cowrite.md 新增 Step 1.5「动笔前先想」：写前用自然对话帮孩子摊开脑子里的画面、自己排顺序
- ❗ mirror.md 镜二新增「路线回顾」追问：写完回头看"你写的路线跟出发前想的一样吗？"
- mirror.md 价值检查点从 10 条扩展为 11 条（检查点 11：序列感）
- SKILL.md 横切机制新增「序列感」

### Philosophy
- 确立"把排序的钥匙放孩子手里"的辅导哲学——写前自己排、写后回头看，两次建立顺序感

### 版本同步
- SKILL.md: frontmatter → 3.5.2 + body → v3.5.2
- SPEC.md/DESIGN.md/PHILOSOPHY.md/README.md/CHANGELOG.md: 全量同步

## [3.5.1] - 2026-05-05

### Added
- ❗ mirror.md 新增 Step 5.5「回顾与勋章」：收尾时简短回顾亮点（≤3条）+ 改进（≤2条正面引导）+ 给予1-2个跟文章绑定的专属称号
- ❗ SKILL.md 新增「个人基调」节：确立亲切、随和、有幽默感和同理心的老师和伙伴形象
- ❗ user-profile.md 新增「🏅 勋章收藏」区，跨会话追踪获得的写作称号
- update_profile.py 新增 `--medal` 参数
- SKILL.md 横切机制新增「回顾与勋章」

### Changed
- SKILL.md 描述文字更新，加入个人基调
- mirror.md 价值检查点从 9 条扩展为 10 条（检查点 10：回顾与勋章）

### 版本同步
- SKILL.md: frontmatter → 3.5.1 + body → v3.5.1
- SPEC.md: 标题 + 版本历史 → 3.5.1
- DESIGN.md: 标题 + 版本历史 → 3.5.1
- PHILOSOPHY.md: 版本号 → 3.5.1
- README.md: 版本号 + v3.5.1 新增说明
- CHANGELOG.md: 本条目

## [3.5.0] - 2026-05-05

### Added
- ❗ mirror.md 镜二新增「前后一致」追问：让孩子发现时间线/空间线断裂点，不替改
- ❗ mirror.md 镜三新增「言之有物」追问：发现万能句式时引导回真实场景细节
- ❗ mirror.md 镜五深化「你的声音」：帮孩子看见自己的语言特质
- ❗ user-profile.md 能力画像增强：优势、成长区、已克服、语言风格标签、熟练度、成长关注
- ❗ update_profile.py 新增参数：--strength --growth-area --overcome --style-tag --proficiency-topic/--proficiency-label --concern/--concern-status
- mirror.md 新增「空话信号速查表」：万能结尾/标签式感悟/堆砌成语/万能开头四种信号
- SKILL.md 横切机制新增「镜子深化」和「风格信号」说明

### Changed
- update_profile.py 重构：段提取替代全文匹配，避免关注表和历史表数据串行
- update_profile.py 正则从 `.+` 改为 `[^|]+`，防止跨列匹配
- mirror.md 价值检查点从 7 条扩展为 9 条
- user-profile.md 历史表格从 4 列扩展为 5 列（新增「改进点」）

### Philosophy
- 确立「空话是观察入口，不是错误」的引导哲学
- 确立「帮你看见你的声音」的个性化写作理念

### 版本同步
- SKILL.md: frontmatter → 3.5.0 + body → v3.5.0
- SPEC.md: 标题 + 版本历史 → 3.5.0
- DESIGN.md: 标题 + 版本历史 → 3.5.0
- PHILOSOPHY.md: 版本号 → 3.5.0
- README.md: 版本号 + v3.5.0 新增说明
- CHANGELOG.md: 本条目

## [3.4.0] - 2026-05-05

### Added
- ❗ 新增原则「改前必问」：所有修改建议必须以问句结尾，未经确认不得改动
- ❗ 用户画像持久化：`data/user-profile.md` 跨会话保存年级、昵称、偏好和写作成长轨迹
- 新增横切规则「角色宣言」：切换评委/搭档/编辑/镜子模式时必须明说
- 新增横切规则「评分不主动」：除非用户明确要求，不输出分数
- 新增横切规则「会话收尾三件事」：写 profile + 出建议清单 + 问下次注意什么
- 新增横切规则「版本变化清单」：每次改建议时附保留/删除/修改清单
- 新增 `scripts/suggestion.py`：Suggestion/ChangeLog 数据类，统一修改建议格式
- 新增 `scripts/update_profile.py`：会话结束时写入/更新用户画像
- `data/user-profile.md` 模板文件

### Changed
- SKILL.md：原则1从"启发不代写"扩充为"启发不代写 / 改前必问"
- SKILL.md：原则4从"跨会话状态不做"改为"跨会话仅限 profile 中的年级和偏好"
- SKILL.md：横切机制"了解你"从隐式推断优先改为 profile 优先
- greeting.md：年级获取从"隐式推断 + 不追问"改为"先读 profile + 显式确认"
- mirror.md：Step 5 新增"改前必问"子步骤；Step 6 增加 profile 读取；新增角色宣言和评分不主动检查点
- README.md：版本号更新 + v3.4.0 新增说明 + 安全描述修正
- main.py：集成 suggestion.py 的 Suggestion 类
- PHILOSOPHY.md：版本号已同步至 v3.4.0

### Philosophy
- 确立「改前必问」作为信任基石：把"改"的权力交还给用户

### 版本同步
- SKILL.md: frontmatter → 3.4.0 + body → v3.4.0
- SPEC.md: 标题 + 版本历史 → 3.4.0
- DESIGN.md: 标题 + 版本历史 + 同步清单 → 3.4.0
- CHANGELOG.md: 本条目
- README.md: 版本号同步

## [3.3.0] - 2026-05-05

### Added
- ❗ methods-basic.md 新增「说人话法」：翻译测试机制、"不像自己说的"信号识别、与课文对照
- ❗ rubrics.md 新增第五面镜子「你像不像自己」：语言自然度评估，含评估信号表
- methods-basic.md 结构搭建法-开头5招示例改为课文优先（《颐和园》《记金华的双龙洞》）
- methods-basic.md 好句升级法增加课文示例对比表先行，AI编的示例后置
- W5 mirror.md Step 3 从四面镜子更新为五面镜子

### Changed
- 所有方法示例的优先级规则：课文原文 > 实战好句 > AI编的示例
- SKILL.md description 简化（去掉"新增词汇镜子"的旧话术）
- methods-basic.md 借景抒情法对比表中"认认真真地开着，用尽全力绽放着自己"改为实战中孩子更自然的原文
- PHILOSOPHY.md 第一节新增第7条信仰："写的像自己，比写得好看重要"
- rubrics.md 标题从"四面镜子"→"五面镜子"（遗漏修复）
- cowrite.md 收尾照镜子引用从"四面"→"五面"（遗漏修复）
- config.yaml 版本号从 v3.1.0→v3.3.0（遗漏修复）
- CHANGELOG.md v3.1.0 层级结构断裂修复
- SKILL.md frontmatter 新增 author: 张轩硕
- README.md 新增致谢章节

### Philosophy
- 确立「说人话」作为高于所有方法的第一原则：写的像自己 > 写得好看
- 确立「课文优先」作为示例引用规则

### 版本同步
- SKILL.md: frontmatter → 3.3.0 + body → v3.3.0
- PHILOSOPHY.md: 版本号 → 3.3.0
- CHANGELOG.md: 本条目
- SPEC.md: 版本 → 3.3.0 + 版本历史新增3.3.0行
- DESIGN.md: 版本 → 3.3.0 + 版本历史新增3.3.0行
- README.md: 版本号同步

## [3.2.0] - 2026-05-05

### Added
- ❗ methods-basic.md 新增「借景抒情法」：帮孩子在写景中自然注入感情，不用直接说"我很开心/感动"，通过写画面让读者自己感受到
- ❗ methods-basic.md 新增「过渡句法」：游记/写景类作文的场景衔接技巧，4种过渡方式（声音/视线/脚步/心情）
- ❗ PHILOSOPHY.md 第十一节「目标对齐」：当学生带来外部目标（字数/作业/分数）时，先承认再超越的应对策略
- ❗ 能力升级检测横切机制：在 W4/W5 中动态监测学生能力信号（主动使用比喻、写诗、要求批评反馈等），自动升级难度
- W4 cowrite.md 新增"段落汇编模式"：与"逐句精雕模式"并列，学生回答短语→AI 编译成段→学生审阅，适合有全局构思的学生
- W4 cowrite.md 新增"跨段过渡句处理"子流程：写完一段后自动引导生成过渡句再进入下一段
- W4 cowrite.md 新增"跨会话情绪检测"：第二天进入时先问候观察感受，再进入任务
- W4 cowrite.md 新增"问题漏斗原则"：默认从最具体的聚焦级问题开始，接不住再放宽
- SKILL.md 新增混合路由：学生同时触发 W3+W4 时，快速教 1 个方法后自动转入 W4
- SKILL.md 字数统计纪律：每次输出字数必须使用 Python/wc 精确计算，不得估算

### Changed
- PHILOSOPHY.md 第八节：安全边界第1条增加用户主动请求豁免条款（明文列出两类场景）
- PHILOSOPHY.md 第九节：黄金法则从"宁宽勿窄"改为"默认从窄开始，W2例外"
- W5 mirror.md Step 5：建议数量从"最多2个"改为"默认2个，学生主动要求时不受限"
- methods-basic.md 进阶预告：新增"情感注入法的前置基础：借景抒情法"说明

### Fixed
- 实战验证的3处PHILOSOPHY与执行冲突现已通过文档修复对齐

### 版本同步
- SKILL.md: frontmatter version → 3.2.0 + body 版本 → v3.2.0
- PHILOSOPHY.md: 新增第十一节 + 第八节/第九节修订
- CHANGELOG.md: 本条目

## [3.1.0] - 2026-05-05

### Added
- ❗ 词汇镜子横切机制：在 W3/W4/W5 中引导多样精准的词汇表达（v3.1.0 新增）
  - 新增方法论文件 `references/vocabulary-guide.md`：三阶引导法（觉察→好奇→启发）、各工作流集成策略、年级差异化策略、禁忌清单
  - 新增全量词库 `references/vocabulary-lexicon.md`：50+高频笼统词的替代选项，按类别分组，按年级分级，含"不用'很'的10种方法"锦囊
  - **非独立工作流**：词汇镜子是横切机制，不是第6个场景
  - **勿回退**：W1（自由表达）和 W2（找灵感）不介入词汇引导——自由表达不打断，找灵感不聚焦用词
  - **哲学对齐**：精准比华丽重要（原则3"真实比华丽重要"的自然延伸）；三阶法对齐"提问不答案"（原则6）；先肯定后引导对齐"先回应感受"（原则2）

### Changed
- PHILOSOPHY.md：新增第十节「词汇镜子——用词精度的守护」
- SPEC.md：新增 REQ-017（词汇引导需求）、NFR-011（词汇镜子原则）、NFR-012（W1/W2 免介入）
- DESIGN.md：新增 ADR-015（词汇镜子决策记录）、模块关系图和工作流数据流更新
- SKILL.md：横切机制新增"词汇镜子"条目，L2 加载新增 vocabulary-guide / vocabulary-lexicon

### 版本同步
- SKILL.md: frontmatter version → 3.1.0 + description 更新
- SPEC.md: 标题 + 版本历史 + 新增 REQ-017 + NFR-011/012
- DESIGN.md: 标题 + 版本历史 + 新增 ADR-015
- CHANGELOG.md: 本条目

## [3.0.4] - 2026-05-04

### Added
- ❗ 设计哲学引入苏格拉底式引导法（PHILOSOPHY.md 第九节）
  - 新增第6条信仰："每个孩子心里都有答案"
  - 新增第6条不可回退原则："提问不答案"
  - 完整方法论：三问框架（澄清/深挖/反思）× 提问阶梯（4档宽度）× 各工作流提问模式
  - **勿回退**: 苏格拉底式提问是"启发不代写"的实现路径，没有提问的共写就是"换一种方式代写"

### Changed
- W4 陪我写：脚手架策略从3级降级改为4级降级，苏格拉底式提问优先于给提示
- W3 学方法：Step 1 改为"先问再教"，教方法前先问"你觉得为什么"
- W5 照镜子：在修改指导前插入苏格拉底式反思引导；新增检查点5（看见对比）补全6维检查点映射
- W2 找灵感：明确苏格拉底式提问开路，引入提问宽度阶梯
- W1 自由表达：新增停顿轻声引导，实现"停顿时可接"
- SKILL.md / SPEC.md：同步更新原则声明、消歧规则（新增"直接提交作文→W5"）和工作流描述
- DESIGN.md：检查点映射表同步至6维（W5新增检查点5）
- PHILOSOPHY.md：安全边界补充第6条、价值锚点规则改为"先问再教"

## [3.0.3] - 2026-05-04

### Changed
- 全量精修：SKILL.md 入口逻辑、PHILOSOPHY.md 价值锚点、config.yaml 配置参数
- 情绪词库（emotion-lexicon.md）与量规（rubrics.md）内容打磨
- 工作流优化：找灵感工作流（inspire.md）流程调优
- 数据源（sources.yaml）更新

## [3.0.2] - 2026-05-02

### Changed
- description 重写：从 64 字扩充至 120 字，去掉内部元数据，突出"陪伴+方法+内心对话"三合一定位
- SPEC.md / DESIGN.md 版本号从 v3.0 更新为 v3.0.2，与 SKILL.md 对齐
- 新增 README.md：面向安装者（家长/教育者）的完整说明文档
- DESIGN.md 新增版本同步清单：列出本 skill 版本号出现的 4 个文件及位置

## [3.0.1] - 2026-04-28

### Changed
- ❗ Token预算修正：L2 从 3500→5000，hard_cap 从 5500→8000（ADR-008，原估算偏差2-3倍）
- ❗ 无状态架构决策（ADR-014）：brain/ 不存在，跨会话能力全部降级至 v3.1
- ❗ 首次交互协议重写为无状态"了解你"（ADR-010）：每次会话开头自然问年级，不判断首次
- 首次交互文件从 first-interact.md 重命名为 greeting.md
- 成长看见从三层策略简化为两层（会话内必须+降级），跨会话层移除（ADR-006 修订）
- 知识动态增长重写为会话内版（ADR-012）：supplement/ 目录移除，AI 按需生成不持久化

### Added
- ADR-013 方案C混合策略：范文拆出懒加载 + 好词好句 AI 化
- ADR-014 无状态架构决策记录
- ADR-010/012 修订记录（无状态适配）
- data/schemas/analyze-output.json（analyze.py 输出 JSON Schema）

### Removed
- brain/ 目录引用（与无状态架构矛盾）
- supplement/ 持久化缓存目录（改为会话内 AI 生成）
- references/outline-templates/ 外置大纲模板（config.yaml outline_templates_dir 已注释，使用内置模板）
- first-interact.md（替换为 greeting.md）

## [3.0.0] - 2026-04-28

### Changed
- ❗ 架构根本性重构：从7个工作流(A-G)合并为5个功能工作流(W1-W5)
  - **原因**: 旧版路由冲突(C/D边界模糊、"日记"别名冲突)、功能重叠(教程+方法)
  - **替代方案**: 5工作流(自由表达/找灵感/学方法/陪我写/照镜子) + 价值内衬
  - **勿回退**: 4场景方案(写我想写/写我感受/写我看见/写我成长)作为入口不自然，孩子不会说"我想进入写我看见场景"
  - **关联ADR**: ADR-001, ADR-005

- ❗ 评估体系从打分制(1-5分)改为照镜子描述性反馈
  - **原因**: 打分制让孩子想"能拿几分"而非"想写什么"，与核心理念冲突
  - **替代方案**: 四面镜子(你写了什么/你怎么搭的/你怎么说的/你的感受)
  - **勿回退**: 这是PHILOSOPHY.md的根基，不是设计偏好
  - **关联ADR**: ADR-003

- ❗ 家长角色从"辅导者"改为"见证者"
  - **原因**: 辅导者定位把家长推到孩子对立面，PPT承诺的家长模式旧版未实现
  - **替代方案**: 家长看见的是"见证"(闪光句/兴趣方向/热情变化)而非"诊断"
  - **勿回退**: 见证者守护写作热情，辅导者可能扼杀它
  - **关联ADR**: ADR-004

- ❗ evaluate.py → analyze.py，脚本只做统计不做评分
  - **原因**: 正则做语义评分不可靠，评分应交给LLM
  - **替代方案**: analyze.py输出纯统计JSON，LLM+rubrics.md做描述性反馈
  - **勿回退**: 脚本-LLM职责边界必须清晰
  - **关联ADR**: ADR-007

### Added
- 价值锚定文档 PHILOSOPHY.md，所有设计决策可追溯
- 情绪识别横切机制，所有工作流第一步检测情绪
- 首次交互协议(年级探测+3题快速定位+推荐起点)
- 共写对话节奏设计(难度锚定/脚手架策略/退出条件)
- 成长看见分层策略(会话内必须+跨会话尽力+优雅降级)
- 知识动态增长(AI生成范文优先+搜索补充事实)
- 12种题材各自的价值锚点

### Removed
- 四维评分(1-5分)系统
- 水平定位标签(萌芽/起步/成长/突破/优秀)
- 综合分计算
- 修辞检测(正则不可靠)
- 家长小贴士模板拼接
