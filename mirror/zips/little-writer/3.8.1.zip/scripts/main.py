#!/usr/bin/env python3
"""大纲生成 + 自由表达脚本

功能：
- 大纲生成：根据题材和年级生成写作大纲（保留旧版功能）
- 自由表达模式：传入 --mode express 时，不生成大纲，只输出温暖开场白
- 大纲模板使用内置模板（config.yaml 的 outline_templates_dir 已弃用）
- 支持年级参数（1-6年级）

用法：
  大纲模式：python3 scripts/main.py [题材] [年级]
  自由表达：python3 scripts/main.py --mode express [年级]
"""

import json
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPT_DIR))
from suggestion import format_suggestion, ChangeLog, Suggestion
SKILL_DIR = SCRIPT_DIR.parent
CONFIG_PATH = SKILL_DIR / "config.yaml"


def load_config() -> dict:
    """加载配置文件"""
    try:
        import yaml
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except ImportError:
        return _fallback_config()
    except FileNotFoundError:
        return _fallback_config()


def _fallback_config() -> dict:
    """config.yaml 不可用时的后备配置"""
    return {
        "grade_word_targets": {
            1: [50, 100], 2: [100, 200], 3: [200, 300],
            4: [300, 400], 5: [400, 500], 6: [500, 600],
        },
        "topic_aliases": {
            "想象作文": ["想象", "想象类", "编故事", "幻想", "假如"],
            "写人": ["写人", "人物", "写一个人", "我的"],
            "写景": ["写景", "景色", "风景", "美丽的"],
            "写事": ["写事", "记事", "一件难忘的事", "第一次", "我学会了"],
            "读后感": ["读后感", "读书笔记", "读书感想", "观后感"],
            "状物": ["状物", "心爱之物", "小动物"],
            "观察日记": ["观察", "日记", "观察日记"],
            "演讲稿": ["演讲", "发言稿", "竞选"],
            "说明文": ["说明文", "介绍", "科普"],
            "诗歌": ["诗歌", "童诗", "写诗"],
            "童话寓言": ["童话", "寓言", "故事", "编童话"],
            "日记书信": ["日记", "书信", "写信"],
        },
    }


def get_word_target(grade: int, config: dict) -> int:
    """根据年级获取字数目标上限"""
    targets = config.get("grade_word_targets", {})
    grade = max(1, min(6, grade))
    target = targets.get(grade, [300, 400])
    if isinstance(target, list):
        return target[1]
    return target


# 内置大纲模板（当外置模板文件不可用时使用）
BUILTIN_OUTLINES = {
    "想象作文": {
        "title": "想象作文大纲",
        "structure": [
            {"part": "开头（凤头）", "hint": "用一个奇妙发现/声音/疑问进入想象世界", "sentences": "2-3句"},
            {"part": "中间第一段", "hint": "想象开始，写出第一个有趣的场景", "sentences": "5-6句"},
            {"part": "中间第二段", "hint": "事情发展，用五官描写加细节", "sentences": "5-6句"},
            {"part": "中间第三段", "hint": "高潮/转折，写出情感变化", "sentences": "4-5句"},
            {"part": "结尾（豹尾）", "hint": "感悟式/愿望式/呼应式收束", "sentences": "2-3句"},
        ],
        "tips": ["用五官描写法（至少3种感官）", "写出心情变化", "每段5-8句话"],
        "recommended_methods": ["五官描写法", "写作四步法"],
    },
    "写人": {
        "title": "写人作文大纲",
        "structure": [
            {"part": "开头（凤头）", "hint": "外貌+总体印象，用一个特点引入", "sentences": "2-3句"},
            {"part": "中间第一件事", "hint": "写一件事展现第一个性格特点", "sentences": "6-7句"},
            {"part": "中间第二件事", "hint": "写另一件事展现另一个特点", "sentences": "6-7句"},
            {"part": "结尾（豹尾）", "hint": "表达对这个人的感情或评价", "sentences": "2-3句"},
        ],
        "tips": ["用四维写人法：外貌→动作→语言→心理", "每件事要有具体细节", "用对话让人物活起来"],
        "recommended_methods": ["好句升级法", "结构搭建法"],
    },
    "写景": {
        "title": "写景作文大纲",
        "structure": [
            {"part": "开头（凤头）", "hint": "总写印象，用一个比喻或感受引入", "sentences": "2-3句"},
            {"part": "中间第一站", "hint": "移步换景，描写第一个场景", "sentences": "5-6句"},
            {"part": "中间第二站", "hint": "移步换景，描写第二个场景", "sentences": "5-6句"},
            {"part": "中间第三站", "hint": "写人的活动，让景色活起来", "sentences": "4-5句"},
            {"part": "结尾（豹尾）", "hint": "抒情或总结，表达喜爱之情", "sentences": "2-3句"},
        ],
        "tips": ["移步换景：走一步看一步", "五官描写（至少3种感官）", "动静结合：写景+写人活动"],
        "recommended_methods": ["五官描写法", "结构搭建法"],
    },
    "写事": {
        "title": "写事作文大纲",
        "structure": [
            {"part": "开头（凤头）", "hint": "交代起因，设下悬念", "sentences": "2-3句"},
            {"part": "中间：开始", "hint": "事情是怎么开始的？你的心情？", "sentences": "4-5句"},
            {"part": "中间：困难", "hint": "遇到了什么困难？你怎么想的？", "sentences": "5-6句"},
            {"part": "中间：解决", "hint": "怎么解决的？写出波折", "sentences": "5-6句"},
            {"part": "结尾（豹尾）", "hint": "结果+感悟，写出收获", "sentences": "2-3句"},
        ],
        "tips": ["六要素：时间/地点/人物/起因/经过/结果", "要有波折才好看", "写出心情变化"],
        "recommended_methods": ["波折法", "结构搭建法"],
    },
    "读后感": {
        "title": "读后感大纲",
        "structure": [
            {"part": "引（开头）", "hint": "简要介绍读的内容（用自己的话概括）", "sentences": "3-4句"},
            {"part": "议（中间）", "hint": "最打动你的地方，为什么打动你", "sentences": "5-6句"},
            {"part": "联（中间）", "hint": "联系自己的生活经历，举自己的例子", "sentences": "6-7句"},
            {"part": "结（结尾）", "hint": "总结收获，表达愿望", "sentences": "2-3句"},
        ],
        "tips": ["引→议→联→结四步走", "联的部分最重要，要写自己的真实经历", "引用原文金句增加说服力"],
        "recommended_methods": ["引议联结法", "好句升级法"],
    },
    "状物": {
        "title": "状物作文大纲",
        "structure": [
            {"part": "开头", "hint": "总体介绍这个物品（怎么来的？为什么喜欢？）", "sentences": "2-3句"},
            {"part": "中间：静态描写", "hint": "按顺序描写外形（颜色、形状、大小、质感）", "sentences": "5-6句"},
            {"part": "中间：动态描写", "hint": "它怎么动？怎么用？和你的互动", "sentences": "4-5句"},
            {"part": "结尾", "hint": "表达喜爱之情或特殊意义", "sentences": "2-3句"},
        ],
        "tips": ["五官描写（看、摸、听）", "动静结合", "写出你和物品的故事"],
        "recommended_methods": ["五官描写法", "写作四步法"],
    },
    "观察日记": {
        "title": "观察日记大纲",
        "structure": [
            {"part": "格式", "hint": "日期 + 天气（例：4月15日 晴）", "sentences": "1行"},
            {"part": "第1天观察", "hint": "整体印象：长什么样？什么颜色？多大？", "sentences": "3-4句"},
            {"part": "第2-3天观察", "hint": "关注变化：有什么不同？长大了吗？", "sentences": "3-4句"},
            {"part": "第4-5天观察", "hint": "发现惊喜：意想不到的变化和细节", "sentences": "3-4句"},
            {"part": "观察感悟", "hint": "从观察中学到了什么？有什么感受？", "sentences": "2-3句"},
        ],
        "tips": ["天天看天天记", "今天和昨天比一比", "用五官记录（看、摸、闻）"],
        "recommended_methods": ["五官描写法", "写作四步法"],
    },
    "演讲稿": {
        "title": "演讲稿大纲",
        "structure": [
            {"part": "开场（15%）", "hint": "用故事/问题/数据抓住听众注意力", "sentences": "3-4句"},
            {"part": "观点1", "hint": "说观点→讲故事→讲道理", "sentences": "5-6句"},
            {"part": "观点2", "hint": "说观点→讲故事→讲道理", "sentences": "5-6句"},
            {"part": "观点3（可选）", "hint": "说观点→讲故事→讲道理", "sentences": "4-5句"},
            {"part": "结尾（15%）", "hint": "呼吁行动或表达愿景", "sentences": "3-4句"},
        ],
        "tips": ["多用短句，少用长句", "适当用问句互动", "重要的地方重复强调"],
        "recommended_methods": ["结构搭建法", "情感注入法"],
    },
    "说明文": {
        "title": "说明文大纲",
        "structure": [
            {"part": "开头", "hint": "介绍说明对象（是什么？）", "sentences": "2-3句"},
            {"part": "中间：方面1", "hint": "分方面说明（外形/功能/特点）", "sentences": "5-6句"},
            {"part": "中间：方面2", "hint": "分方面说明（习性/原理/数据）", "sentences": "5-6句"},
            {"part": "中间：方面3", "hint": "分方面说明（趣闻/比较/意义）", "sentences": "4-5句"},
            {"part": "结尾", "hint": "总结或展望", "sentences": "2-3句"},
        ],
        "tips": ["用举例子、列数字、打比方让说明更清楚", "按逻辑顺序组织", "语言准确简洁"],
        "recommended_methods": ["结构搭建法", "写作四步法"],
    },
    "诗歌": {
        "title": "童诗大纲",
        "structure": [
            {"part": "观察", "hint": "仔细看一样东西，找到它的特点", "sentences": "1-2行"},
            {"part": "想象", "hint": "它像什么？它会说什么？它有什么秘密？", "sentences": "2-3行"},
            {"part": "展开", "hint": "用短句一行行写出来，像唱歌一样", "sentences": "4-8行"},
            {"part": "结尾", "hint": "一个惊喜或一个画面结束", "sentences": "1-2行"},
        ],
        "tips": ["把东西当人写（拟人）", "用'像'连接两个东西（比喻）", "大胆想象", "一行一行写，要有节奏"],
        "recommended_methods": ["五官描写法", "写作四步法"],
    },
    "童话寓言": {
        "title": "童话/寓言大纲",
        "structure": [
            {"part": "开头", "hint": "介绍角色和背景（谁？住哪？什么特点？）", "sentences": "3-4句"},
            {"part": "中间：遇到问题", "hint": "角色遇到困难或挑战", "sentences": "4-5句"},
            {"part": "中间：第一次尝试", "hint": "想办法解决但失败了", "sentences": "4-5句"},
            {"part": "中间：第二次尝试", "hint": "新办法成功了（或得到帮助）", "sentences": "5-6句"},
            {"part": "结尾", "hint": "揭示道理（自然融入，不要硬说教）", "sentences": "2-3句"},
        ],
        "tips": ["角色要有不同性格", "用对话推进故事", "道理藏在故事里"],
        "recommended_methods": ["结构搭建法", "五官描写法"],
    },
    "日记书信": {
        "title": "日记/书信大纲",
        "structure": [
            {"part": "格式", "hint": "日记：日期+天气；书信：称呼+问候", "sentences": "1-2行"},
            {"part": "主体1", "hint": "选最有趣/最难忘的一件事来写", "sentences": "5-6句"},
            {"part": "主体2", "hint": "写出自己的感受和想法", "sentences": "4-5句"},
            {"part": "结尾", "hint": "日记：感悟；书信：祝福+署名", "sentences": "2-3句"},
        ],
        "tips": ["日记不是流水账，选一件事写详细", "书信根据对象调整语气", "写真实感受"],
        "recommended_methods": ["写作四步法", "五官描写法"],
    },
}


def load_outline_templates(config: dict) -> dict:
    """从外置目录加载大纲模板，如果不可用则使用内置模板"""
    templates_dir_rel = config.get("outline_templates_dir", "")
    if not templates_dir_rel:
        return BUILTIN_OUTLINES

    templates_dir = SKILL_DIR / templates_dir_rel
    if not templates_dir.exists():
        return BUILTIN_OUTLINES

    templates = {}
    try:
        import yaml
        for f in templates_dir.glob("*.yaml"):
            with open(f, "r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh)
                if data and "title" in data:
                    templates[f.stem] = data
        for f in templates_dir.glob("*.json"):
            with open(f, "r", encoding="utf-8") as fh:
                data = json.load(fh)
                if data and "title" in data:
                    templates[f.stem] = data
    except Exception:
        return BUILTIN_OUTLINES

    return templates if templates else BUILTIN_OUTLINES


def match_topic(user_input: str, config: dict) -> str:
    """增强版模糊匹配：支持别名、子串、口语化表达"""
    aliases = config.get("topic_aliases", {})
    outlines = BUILTIN_OUTLINES  # 用内置模板的 key 做匹配

    # 1. 精确匹配
    if user_input in outlines:
        return user_input

    # 2. 别名匹配
    for canonical, alias_list in aliases.items():
        if canonical not in outlines:
            continue
        for alias in alias_list:
            if alias in user_input or user_input in alias:
                return canonical

    # 3. 子串匹配
    for key in outlines:
        if key in user_input or user_input in key:
            return key

    # 4. 去掉"作文"后缀再匹配
    cleaned = user_input.replace("作文", "").replace("的", "").strip()
    if cleaned:
        for key in outlines:
            key_cleaned = key.replace("作文", "").strip()
            if cleaned in key_cleaned or key_cleaned in cleaned:
                return key

    return "想象作文"  # 默认


def generate_express_opening(grade: int = 4) -> dict:
    """生成自由表达模式的温暖开场白"""
    grade = max(1, min(6, grade))

    openings = {
        1: "嗨，小朋友！这里就是你的小天地啦，想写什么就写什么，画画也可以哦！没有人会给你打分，写出来的每一个字都是你的小星星。",
        2: "嘿，欢迎来到你的写作小角落！这里没有题目，没有对错，你想写什么就写什么。开心的事、不开心的事、好玩的想法，都可以写下来。",
        3: "嗨！这里是一个只属于你的写作空间。想说什么就说什么——开心的事、难过的事、心里的悄悄话、或者天马行空的想象，都可以。没有人会评判你，我只想听你说。",
        4: "嗨！欢迎来到自由写作时间。这里没有题目限制，没有对错之分。你可以写今天发生的事，可以写心里的感受，也可以随便写写脑子里蹦出来的想法。重要的是，这是你自己的文字。",
        5: "嘿！这是你的自由表达空间。不用想题目，不用管结构，就是写。写你看到的、写你感受到的、写你想说却没说出口的。你的每一个想法都值得被写下来。",
        6: "嗨！欢迎来到你的私人写作空间。这里不需要题目，不需要技巧，只需要你真实的想法。你想说什么都可以——对生活的观察、对世界的思考、或者就是今天的心情。开始吧，我在听。",
    }

    return {
        "mode": "express",
        "grade": grade,
        "opening": openings.get(grade, openings[4]),
        "guidance": "自由表达模式不生成大纲，不评分，不纠正。让孩子自由书写，写完后可以说'谢谢你写下来'。",
    }


def generate_outline(topic: str, grade: int = 4) -> dict:
    """根据题材和年级生成写作大纲"""
    config = load_config()
    grade = max(1, min(6, grade))

    # 匹配题材
    matched = match_topic(topic, config)

    # 尝试从外置模板加载
    templates = load_outline_templates(config)
    outline = templates.get(matched, BUILTIN_OUTLINES.get(matched, BUILTIN_OUTLINES["想象作文"])).copy()

    # 从配置读取目标字数
    outline["word_target"] = get_word_target(grade, config)

    # 添加年级信息
    outline["grade"] = grade

    return outline


def main():
    """主函数"""
    try:
        # 解析参数
        args = sys.argv[1:]

        # 检查是否为自由表达模式
        if "--mode" in args:
            mode_idx = args.index("--mode")
            if mode_idx + 1 < len(args) and args[mode_idx + 1] == "express":
                try:
                    grade = int(args[mode_idx + 2]) if len(args) > mode_idx + 2 else 4
                except (ValueError, IndexError):
                    grade = 4
                result = generate_express_opening(grade)
                output = {"success": True, "data": result}
                print(json.dumps(output, ensure_ascii=False, indent=2))
                return

        # 大纲生成模式
        topic = args[0].strip() if args else ""
        if not topic:
            error_result = {
                "success": False,
                "error": "empty_topic",
                "message": "题材不能为空，请提供写作题材（如：写景、写人、想象作文）",
            }
            print(json.dumps(error_result, ensure_ascii=False, indent=2))
            sys.exit(1)
        try:
            grade = int(args[1]) if len(args) > 1 else 4
        except ValueError:
            grade = 4

        grade = max(1, min(6, grade))

        outline = generate_outline(topic, grade)
        result = {
            "success": True,
            "data": {
                "topic": topic,
                "matched_topic": outline.get("title", topic).replace("大纲", ""),
                "grade": grade,
                "outline": outline,
            },
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))

    except Exception as e:
        error_result = {
            "success": False,
            "error": str(e),
            "message": f"大纲生成失败：{e}",
        }
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
