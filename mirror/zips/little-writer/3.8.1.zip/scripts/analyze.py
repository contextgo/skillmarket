#!/usr/bin/env python3
"""作文统计分析脚本 — 只做统计不做评分（替代旧版 evaluate.py）

功能：
- 字数统计、段落统计、句子统计、字数完成度
- 五官词频统计（统计词数而非评分）
- 对话句数统计

不做的事（交给 LLM）：
- 修辞检测、四维评分、水平定位、家长小贴士、综合分计算

用法：python3 scripts/analyze.py [作文文本] [年级]
  或：echo "作文文本" | python3 scripts/analyze.py [年级]
"""

import json
import re
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
CONFIG_PATH = SKILL_DIR / "config.yaml"

# 内置默认五官词库（当 config.yaml 或 sense-words.md 不可用时使用）
DEFAULT_SENSE_WORDS = {
    "视觉": ["看到", "看见", "看着", "望着", "映入眼帘", "颜色", "色彩", "亮", "暗", "闪", "光彩",
             "红", "黄", "蓝", "绿", "白", "黑", "金", "银", "紫",
             "美丽", "漂亮", "清晰", "模糊", "高大", "矮小",
             "阳光", "月光", "影子", "倒影",
             "闪烁", "闪耀", "照耀", "五颜六色", "五彩缤纷",
             "仿佛", "好像", "宛如", "像", "似"],
    "听觉": ["听到", "听见", "听着", "声音", "响", "叮", "沙沙", "哗哗", "呼呼",
             "轰隆", "叽叽喳喳", "嘀嘀", "啪啪", "叮咚", "嗡嗡", "呱呱",
             "唱歌", "欢笑", "哭泣", "喊叫", "低语", "呢喃",
             "安静", "寂静", "热闹", "清脆", "悦耳", "刺耳",
             "笑声", "哭声", "鸟鸣", "风声", "雨声", "铃声"],
    "嗅觉": ["闻", "闻到", "香", "气味", "味道", "臭", "芬芳", "清香", "浓烈",
             "清新", "刺鼻", "淡淡", "幽香", "甜香", "芳香",
             "花香", "草香", "饭菜香", "泥土气息", "泥土味",
             "香气扑鼻", "浓郁", "青草味", "饭菜味"],
    "触觉": ["摸", "摸到", "触", "碰到", "软", "硬", "滑", "粗", "暖", "凉", "冷", "热",
             "冰", "烫", "粗糙", "光滑", "柔软", "坚硬",
             "刺", "痒", "麻", "痛", "酸", "胀",
             "湿润", "干燥", "轻", "重", "厚", "薄",
             "毛茸茸", "暖洋洋", "刺骨", "冰凉", "滚烫", "温热"],
    "味觉": ["尝", "尝到", "甜", "酸", "苦", "辣", "咸", "鲜", "淡", "涩",
             "可口", "美味", "香喷喷", "好吃",
             "脆", "嫩", "绵", "酥",
             "甘甜", "苦涩", "酸甜", "辛辣",
             "津津有味", "回味无穷", "鲜美", "爽口"],
}


def load_config() -> dict:
    """加载配置文件"""
    try:
        import yaml
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except ImportError:
        return _fallback_config()
    except FileNotFoundError:
        return _fallback_config()


def _fallback_config() -> dict:
    """config.yaml 不可用时的后备配置"""
    return {
        "grade_word_targets": {
            1: [50, 100], 2: [100, 200], 3: [200, 300],
            4: [300, 400], 5: [400, 500], 6: [500, 600],
        },
    }


def load_sense_words(config: dict) -> dict:
    """加载五官词库，优先从 sense_words_file 读取，否则使用内置默认"""
    sense_file_rel = config.get("sense_words_file", "")
    if sense_file_rel:
        sense_path = SKILL_DIR / sense_file_rel
        if sense_path.exists():
            return _parse_sense_words_file(sense_path)
    return DEFAULT_SENSE_WORDS


def _parse_sense_words_file(filepath: Path) -> dict:
    """解析五官词库 markdown 文件

    期望格式：
    ## 视觉
    看到、看见、映入眼帘、...
    ## 听觉
    ...
    """
    words = {}
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            current_category = None
            for line in f:
                line = line.strip()
                if line.startswith("## "):
                    current_category = line[3:].strip()
                    words[current_category] = []
                elif current_category and line and not line.startswith("#"):
                    # 支持顿号、逗号、空格分隔
                    items = re.split(r'[、，,\s]+', line)
                    words[current_category].extend([w for w in items if w])
    except Exception:
        return DEFAULT_SENSE_WORDS

    return words if words else DEFAULT_SENSE_WORDS


def get_word_target(grade: int, config: dict) -> int:
    """根据年级获取字数目标

    config 中 grade_word_targets 可能是单数字（旧格式）或 [min, max] 列表（新格式）
    """
    targets = config.get("grade_word_targets", {})
    grade = max(1, min(6, grade))
    target = targets.get(grade, [300, 400])

    if isinstance(target, list):
        return target[1]  # 返回上限作为目标
    return target


def count_words(text: str) -> int:
    """统计中文字数（中文字符 + 中文标点）"""
    chinese_chars = re.findall(r'[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]', text)
    return len(chinese_chars)


def count_paragraphs(text: str) -> int:
    """统计段落数"""
    paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
    if len(paragraphs) <= 1:
        paragraphs = [p.strip() for p in text.split("。") if p.strip()]
    return max(1, len(paragraphs))


def count_sentences(text: str) -> int:
    """统计句子数"""
    sentence_endings = re.split(r'[。！？…]', text)
    return max(1, len([s for s in sentence_endings if s.strip()]))


def count_dialogue(text: str) -> int:
    """统计对话句数（包含引号的句子）"""
    # 匹配中文引号中的对话
    dialogue_pattern = r'[「」""""\u201c\u201d]'
    matches = re.findall(dialogue_pattern, text)
    # 每对引号算一次对话
    return len(matches) // 2


def analyze_sense_words(text: str, sense_words: dict) -> dict:
    """统计五官词频

    返回每种感官在文本中出现的词数，如 {"视觉": 3, "听觉": 1, ...}
    使用正则子串匹配，避免短词误匹配（如"香"匹配到"香蕉"是合理的，"阳光"必须完整匹配）
    """
    result = {}
    for category, word_list in sense_words.items():
        count = 0
        for w in word_list:
            # 使用 re.search 做子串匹配，比 `w in text` 更可靠
            # 对于单字词（如"香""冷"），需要确保匹配独立语义单元
            if len(w) == 1:
                # 单字词：直接用 in 检查（单字中文词本身就是最小语义单元）
                count += text.count(w)
            else:
                # 多字词：用正则确保完整匹配
                count += len(re.findall(re.escape(w), text))
        result[category] = count
    return result


def analyze_essay(text: str, grade: int = 4) -> dict:
    """分析作文统计信息"""
    config = load_config()
    grade = max(1, min(6, grade))

    # 基础统计
    word_count = count_words(text)
    paragraph_count = count_paragraphs(text)
    sentence_count = count_sentences(text)

    # 字数目标
    word_target = get_word_target(grade, config)
    word_completion = min(100, int(word_count / word_target * 100)) if word_target > 0 else 0

    # 五官词频
    sense_words = load_sense_words(config)
    sense_analysis = analyze_sense_words(text, sense_words)

    # 对话统计
    dialogue_count = count_dialogue(text)

    return {
        "statistics": {
            "word_count": word_count,
            "word_target": word_target,
            "word_completion": f"{word_completion}%",
            "paragraph_count": paragraph_count,
            "sentence_count": sentence_count,
        },
        "sense_analysis": sense_analysis,
        "dialogue_count": dialogue_count,
    }


def main():
    """主函数"""
    try:
        # 获取作文文本
        if len(sys.argv) > 1 and not sys.argv[1].isdigit():
            text = sys.argv[1]
            grade = int(sys.argv[2]) if len(sys.argv) > 2 else 4
        elif not sys.stdin.isatty():
            text = sys.stdin.read()
            grade = int(sys.argv[1]) if len(sys.argv) > 1 else 4
        else:
            error_result = {
                "success": False,
                "error": "missing_text",
                "message": "请提供作文文本：python3 analyze.py [作文文本] [年级]",
            }
            print(json.dumps(error_result, ensure_ascii=False, indent=2))
            sys.exit(1)

        if not text.strip():
            error_result = {
                "success": False,
                "error": "empty_text",
                "message": "作文文本不能为空",
            }
            print(json.dumps(error_result, ensure_ascii=False, indent=2))
            sys.exit(1)

        result = analyze_essay(text, grade)
        output = {"success": True, "data": result}
        print(json.dumps(output, ensure_ascii=False, indent=2))

    except Exception as e:
        error_result = {
            "success": False,
            "error": str(e),
            "message": f"分析失败：{e}",
        }
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
