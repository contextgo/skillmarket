#!/usr/bin/env python3
"""更新用户画像 — 会话结束时调用 (v3.5.0)

用法：
    # 基础信息
    python3 scripts/update_profile.py --nickname 龙虾 --grade 4 --topic 写景 --word-count 600 --highlight "樱花躺在水面上" --improvement "结尾有点急"

    # 能力画像
    python3 scripts/update_profile.py --strength "比喻生动" --growth-area "结尾有时万能句式" --overcome "不敢写感受"

    # 风格标签
    python3 scripts/update_profile.py --style-tag "会跟自己说话"

    # 熟练度
    python3 scripts/update_profile.py --proficiency 写景 "很自信，常有画面"

    # 成长关注
    python3 scripts/update_profile.py --concern "时间线矛盾" --concern-status improved

从 data/user-profile.md 读取现有记录，追加或更新。
"""

import argparse
import json
import re
from datetime import date
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
PROFILE_PATH = SKILL_DIR / "data" / "user-profile.md"


def read_profile() -> dict:
    """读取现有 user-profile.md"""
    if not PROFILE_PATH.exists():
        return _empty_profile()

    content = PROFILE_PATH.read_text(encoding="utf-8")
    profile = _empty_profile()

    # 用户信息
    profile["nickname"] = _extract_field(content, r"- 昵称：(.+)")
    profile["grade"] = _extract_field(content, r"- 年级：(.+)")
    profile["first_session"] = _extract_field(content, r"- 首次会话日期：(.+)")
    profile["last_session"] = _extract_field(content, r"- 最近会话日期：(.+)")
    total = _extract_field(content, r"- 总写作次数：(\d+)")
    profile["total_sessions"] = int(total) if total else 0

    # 偏好记录
    profile["style_pref"] = _extract_field(content, r"- 风格偏好：(.+)")
    profile["role_pref"] = _extract_field(content, r"- 角色偏好：(.+)")
    topics_str = _extract_field(content, r"- 常用题材：(.+)")
    if topics_str:
        profile["topics"] = [t.strip() for t in topics_str.split("、") if t.strip()]

    # 能力画像 - 优势
    section = _extract_section(content, "\n### 优势\n", "\n### 成长区（")
    for line in section.split("\n"):
        stripped = line.strip()
        if stripped and not stripped.startswith("<!--") and not stripped.startswith("###"):
            profile["strengths"].append(stripped)

    # 能力画像 - 成长区
    section = _extract_section(content, "\n### 成长区（正在提升中）\n", "\n### 已克服\n")
    for line in section.split("\n"):
        stripped = line.strip()
        if stripped and not stripped.startswith("<!--") and not stripped.startswith("###"):
            profile["growth_areas"].append(stripped)

    # 能力画像 - 已克服
    section = _extract_section(content, "\n### 已克服\n", "\n### 语言风格标签\n")
    for line in section.split("\n"):
        stripped = line.strip()
        if stripped and not stripped.startswith("<!--") and not stripped.startswith("###"):
            cleaned = re.sub(r"^~~|~~$", "", stripped)
            profile["overcome"].append(cleaned)

    # 语言风格标签
    section = _extract_section(content, "\n### 语言风格标签\n", "\n### 熟练度\n")
    for line in section.split("\n"):
        stripped = line.strip()
        if stripped and not stripped.startswith("<!--") and not stripped.startswith("###"):
            profile["style_tags"].append(stripped)

    # 熟练度
    section = _extract_section(content, "\n### 熟练度\n", "\n### 🏅 勋章收藏\n")
    for line in section.split("\n"):
        stripped = line.strip()
        if stripped and not stripped.startswith("<!--") and not stripped.startswith("###"):
            profile["proficiency"].append(stripped)

    # 🏅 勋章收藏
    section = _extract_section(content, "\n### 🏅 勋章收藏\n", "\n## 成长关注\n")
    for line in section.split("\n"):
        stripped = line.strip()
        if stripped and not stripped.startswith("<!--") and not stripped.startswith("###"):
            profile["medals"].append(stripped)

    # 成长关注（先提取段，再解析表）
    concern_section = _extract_section(content, "\n## 成长关注\n", "\n## 写作成长轨迹\n")
    concern_lines = re.findall(r"^\|([^|]+)\|([^|]+)\|([^|]+)\|", concern_section, re.MULTILINE)
    for line in concern_lines:
        col1 = line[0].strip()
        col2 = line[1].strip()
        col3 = line[2].strip()
        if col1 == "日期":
            continue
        if re.match(r"^\s*-{2,}", col1):
            continue
        if col1:
            profile["concerns"].append({
                "date": col1,
                "concern": col2,
                "status": col3,
            })

    # 写作成长轨迹（最后一段，直接截取到文件末尾）
    start = content.find("\n## 写作成长轨迹\n")
    if start != -1:
        history_section = content[start:]
    else:
        history_section = ""
    history_lines = re.findall(r"^\|([^|]+)\|([^|]+)\|([^|]+)\|([^|]+)\|([^|]+)\|", history_section, re.MULTILINE)
    for line in history_lines:
        col1 = line[0].strip()
        if col1 == "日期":
            continue
        if re.match(r"^\s*-{2,}", col1):
            continue
        if col1:
            profile["history"].append({
                "date": col1,
                "topic": line[1].strip(),
                "word_count": line[2].strip(),
                "highlight": line[3].strip(),
                "improvement": line[4].strip(),
            })

    return profile


def _extract_field(content: str, pattern: str) -> str:
    m = re.search(pattern, content)
    return m.group(1).strip() if m else ""


def _extract_section(content: str, start_marker: str, end_marker: str) -> str:
    """提取两个标记之间的内容"""
    start = content.find(start_marker)
    end = content.find(end_marker)
    if start == -1:
        return ""
    if end == -1:
        return content[start:]
    return content[start:end]


def write_profile(profile: dict):
    """将画像写回 user-profile.md"""
    today = date.today().isoformat()

    if not profile["first_session"]:
        profile["first_session"] = today
    profile["last_session"] = today

    topics_str = "、".join(profile["topics"]) if profile["topics"] else ""

    # 优势
    strengths_lines = ["\n".join(profile["strengths"])] if profile["strengths"] else [""]
    # 成长区
    growth_lines = ["\n".join(profile["growth_areas"])] if profile["growth_areas"] else [""]
    # 已克服
    overcome_lines = ["\n".join(f"~~{o}~~" for o in profile["overcome"])] if profile["overcome"] else [""]
    # 风格标签
    style_lines = ["\n".join(profile["style_tags"])] if profile["style_tags"] else [""]
    # 熟练度
    prof_lines = ["\n".join(profile["proficiency"])] if profile["proficiency"] else [""]
    # 🏅 勋章收藏
    medal_lines = ["\n".join(profile["medals"])] if profile["medals"] else [""]
    # 成长关注
    concern_rows = ["| 日期 | 关注点 | 状态 |", "|------|--------|------|"]
    for c in profile["concerns"][-10:]:
        concern_rows.append(f"| {c['date']} | {c['concern']} | {c['status']} |")

    # 历史表格（5列）
    history_rows = ["| 日期 | 题材 | 字数 | 亮点 | 改进点 |", "|------|------|------|------|--------|"]
    for entry in profile["history"][-20:]:
        history_rows.append(f"| {entry['date']} | {entry['topic']} | {entry['word_count']} | {entry['highlight']} | {entry['improvement']} |")

    content = f"""# 用户画像

> 由 little-writer 在每次会话结束时自动更新。
> 此文件属于用户隐私数据，不随 skill 打包分发。

## 用户信息
- 昵称：{profile['nickname']}
- 年级：{profile['grade']}
- 首次会话日期：{profile['first_session']}
- 最近会话日期：{profile['last_session']}
- 总写作次数：{profile['total_sessions'] or 0}

## 偏好记录
- 风格偏好：{profile['style_pref']}
- 角色偏好：{profile['role_pref']}
- 常用题材：{topics_str}

## 能力画像

### 优势
{strengths_lines[0] if strengths_lines else ''}

### 成长区（正在提升中）
{growth_lines[0] if growth_lines else ''}

### 已克服
{overcome_lines[0] if overcome_lines else ''}

### 语言风格标签
{style_lines[0] if style_lines else ''}

### 熟练度
{prof_lines[0] if prof_lines else ''}

### 🏅 勋章收藏
{medal_lines[0] if medal_lines else ''}

## 成长关注

{chr(10).join(concern_rows)}

## 写作成长轨迹

{chr(10).join(history_rows)}
"""
    PROFILE_PATH.write_text(content.strip() + "\n", encoding="utf-8")


def _empty_profile() -> dict:
    return {
        "nickname": "",
        "grade": "",
        "first_session": "",
        "last_session": "",
        "total_sessions": 0,
        "style_pref": "普通",
        "role_pref": "",
        "topics": [],
        "strengths": [],
        "growth_areas": [],
        "overcome": [],
        "style_tags": [],
        "proficiency": [],
        "medals": [],
        "concerns": [],
        "history": [],
    }


def _append_unique(lst: list, item: str) -> bool:
    """追加并去重，返回是否新增"""
    if item and item not in lst:
        lst.append(item)
        return True
    return False


def main():
    parser = argparse.ArgumentParser(description="更新用户画像 (v3.5.0)")
    # 基础信息
    parser.add_argument("--nickname", default="", help="用户昵称")
    parser.add_argument("--grade", default="", help="年级")
    parser.add_argument("--topic", default="", help="本次作文题材")
    parser.add_argument("--word-count", default="", help="本次作文字数")
    parser.add_argument("--highlight", default="", help="本次亮点")
    parser.add_argument("--improvement", default="", help="本次改进点")
    parser.add_argument("--style-pref", default="", help="风格偏好")
    parser.add_argument("--role-pref", default="", help="角色偏好")

    # 能力画像
    parser.add_argument("--strength", default="", help="追加优势")
    parser.add_argument("--growth-area", default="", help="追加成长区")
    parser.add_argument("--overcome", default="", help="标记已克服的成长区")

    # 🏅 勋章
    parser.add_argument("--medal", default="", help="追加勋章，多个用逗号分隔")

    # 风格
    parser.add_argument("--style-tag", default="", help="追加语言风格标签")

    # 熟练度（两个参数联动）
    parser.add_argument("--proficiency-topic", default="", help="熟练度题材（如 写景）")
    parser.add_argument("--proficiency-label", default="", help="熟练度描述（如 很自信常有画面）")

    # 成长关注
    parser.add_argument("--concern", default="", help="成长关注事项")
    parser.add_argument("--concern-status", default="🟡留意中", help="关注状态（🟡留意中 / 🟢已改善）")

    args = parser.parse_args()

    profile = read_profile()

    # 基础字段
    if args.nickname:
        profile["nickname"] = args.nickname
    if args.grade:
        profile["grade"] = args.grade
    if args.topic and args.topic not in profile["topics"]:
        profile["topics"].append(args.topic)
    if args.style_pref:
        profile["style_pref"] = args.style_pref
    if args.role_pref:
        profile["role_pref"] = args.role_pref

    # 能力画像
    _append_unique(profile["strengths"], args.strength)
    _append_unique(profile["growth_areas"], args.growth_area)
    if args.overcome:
        _append_unique(profile["overcome"], args.overcome)
        # 同时从成长区移除
        if args.overcome in profile["growth_areas"]:
            profile["growth_areas"].remove(args.overcome)

    # 风格标签
    _append_unique(profile["style_tags"], args.style_tag)

    # 🏅 勋章
    if args.medal:
        for m in args.medal.split(","):
            m = m.strip()
            if m:
                _append_unique(profile["medals"], m)

    # 熟练度
    if args.proficiency_topic and args.proficiency_label:
        prof_entry = f"{args.proficiency_topic}：{args.proficiency_label}"
        _append_unique(profile["proficiency"], prof_entry)

    # 成长关注
    if args.concern:
        profile["concerns"].append({
            "date": date.today().isoformat(),
            "concern": args.concern,
            "status": args.concern_status,
        })

    # 追加本次记录
    if args.topic or args.highlight:
        entry = {
            "date": date.today().isoformat(),
            "topic": args.topic or "",
            "word_count": args.word_count or "",
            "highlight": args.highlight or "",
            "improvement": args.improvement or "",
        }
        profile["history"].append(entry)
        profile["total_sessions"] = len(profile["history"])

    write_profile(profile)

    result = {
        "success": True,
        "profile": {
            "nickname": profile["nickname"],
            "grade": profile["grade"],
            "session_count": profile["total_sessions"],
            "strengths": profile["strengths"],
            "style_tags": profile["style_tags"],
        },
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
