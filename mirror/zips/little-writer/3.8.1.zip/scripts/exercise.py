#!/usr/bin/env python3
"""练习生成脚本 — 根据练习类型和年级生成针对性练习

功能：
- 5种基础练习类型：句子升级、五官描写、结构搭建、情感注入、综合练习
- 2种新增练习类型：反思性写作、照镜子练习
- 根据年级调整难度
- 输出练习题目和参考答案

用法：python3 scripts/exercise.py [练习类型] [年级]
  练习类型：sentence_upgrade / senses / structure / emotion / comprehensive / reflective / mirror
"""

import json
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
CONFIG_PATH = SKILL_DIR / "config.yaml"


def load_config() -> dict:
    """加载配置文件"""
    try:
        import yaml
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except ImportError:
        return _fallback_config()
    except FileNotFoundError:
        return _fallback_config()


def _fallback_config() -> dict:
    return {
        "grade_word_targets": {
            1: [50, 100], 2: [100, 200], 3: [200, 300],
            4: [300, 400], 5: [400, 500], 6: [500, 600],
        },
    }


# 练习模板库
EXERCISES = {
    "sentence_upgrade": {
        "name": "好句升级练习",
        "method": "好句升级法",
        "description": "把平淡的句子升级成生动的好句子",
        "prompt_template": "用「加形容、加感受、加比喻」的方法，把下面的句子升级一下：",
        "exercises": {
            1: [
                {"original": "花开了", "hint": "加上颜色，花像什么？", "reference": "红色的花开了，像小灯笼一样挂满了枝头"},
                {"original": "下雨了", "hint": "雨点像什么？", "reference": "雨点嘀嗒嘀嗒地落下来，像在弹琴"},
            ],
            2: [
                {"original": "我看到了花", "hint": "试试加上颜色和样子", "reference": "我看到了一片金黄色的向日葵，在阳光下灿烂地微笑"},
                {"original": "风吹过来", "hint": "风是什么感觉？像什么？", "reference": "风轻轻地吹过来，像妈妈的手摸着我的脸"},
            ],
            3: [
                {"original": "我看到了花", "hint": "试试加上颜色和样子", "reference": "我看到了一片金黄色的向日葵，在阳光下灿烂地微笑"},
                {"original": "风吹过来", "hint": "风是什么感觉？像什么？", "reference": "风轻轻地吹过来，像妈妈的手摸着我的脸"},
                {"original": "下雨了", "hint": "雨点像什么？", "reference": "雨点像断了线的珠子，噼里啪啦地往下掉"},
            ],
            4: [
                {"original": "我很开心", "hint": "不用'开心'这个词，写出你开心的样子", "reference": "我的脸上止不住地笑，走起路来都想蹦两步"},
                {"original": "天很热", "hint": "用比喻写出热的感受", "reference": "太阳像个大火炉，把大地烤得直冒烟"},
                {"original": "他跑得很快", "hint": "用比喻形容速度快", "reference": "他像一阵风一样冲了出去，眨眼间就跑到了终点"},
            ],
            5: [
                {"original": "我很紧张", "hint": "用身体反应表达紧张", "reference": "我的心像揣着一只小兔子，砰砰直跳，手心全是汗"},
                {"original": "树叶掉了", "hint": "用拟人让树叶'动'起来", "reference": "秋风吹来，金黄的树叶恋恋不舍地松开了大树妈妈的手，在空中旋转着飘落"},
                {"original": "天黑了", "hint": "营造氛围感", "reference": "天边的最后一抹晚霞慢慢褪去，夜幕像一张大网，悄悄地笼罩了整个城市"},
            ],
            6: [
                {"original": "我很感动", "hint": "用微表情和动作表达感动", "reference": "鼻子一酸，说不出话来，只能使劲点了点头，把那股暖意紧紧地按在心底"},
                {"original": "时间过得很快", "hint": "用比喻和对比表达时间的流逝", "reference": "时间像沙漏里的细沙，不知不觉间就从指缝间溜走了，回过神来，一个学期已经翻到了最后一页"},
                {"original": "她很善良", "hint": "不要说'善良'，用一件事让人感受到", "reference": "她看见角落里那只瑟瑟发抖的小猫，二话没说脱下自己的外套轻轻裹住它，自己的手臂却冻得起了鸡皮疙瘩"},
            ],
        },
    },
    "senses": {
        "name": "五官描写练习",
        "method": "五官描写法",
        "description": "练习用看听闻摸尝五种感官来描写",
        "prompt_template": "用至少3种感官描写下面的场景：",
        "exercises": {
            1: [
                {"scene": "你看到的花园", "hint": "你看到了什么颜色？闻到了什么？", "senses": ["看", "闻"]},
                {"scene": "下雨天", "hint": "雨是什么声音？窗户上是什么样子？", "senses": ["看", "听"]},
            ],
            2: [
                {"scene": "你此刻的教室", "hint": "你看到了什么？听到了什么？闻到了什么？", "senses": ["看", "听"]},
                {"scene": "下雨天", "hint": "雨是什么声音？窗户上是什么样子？", "senses": ["看", "听", "闻"]},
            ],
            3: [
                {"scene": "你此刻的教室", "hint": "你看到了什么？听到了什么？闻到了什么？", "senses": ["看", "听"]},
                {"scene": "下雨天", "hint": "雨是什么声音？窗户上是什么样子？", "senses": ["看", "听", "闻"]},
            ],
            4: [
                {"scene": "春天的花园", "hint": "花朵是什么颜色？蜜蜂是什么声音？", "senses": ["看", "听", "闻"]},
                {"scene": "厨房里妈妈做饭", "hint": "闻到了什么？听到了什么声音？", "senses": ["看", "听", "闻", "尝"]},
            ],
            5: [
                {"scene": "夜晚的街道", "hint": "路灯下是什么画面？远处有什么声音？", "senses": ["看", "听", "摸"]},
                {"scene": "下雪的校园", "hint": "雪花摸起来什么感觉？踩上去什么声音？", "senses": ["看", "听", "摸"]},
            ],
            6: [
                {"scene": "集市的早晨", "hint": "用所有感官描写热闹的集市", "senses": ["看", "听", "闻", "尝", "摸"]},
                {"scene": "老家的夏天", "hint": "回忆一种有画面感的场景", "senses": ["看", "听", "闻"]},
            ],
        },
    },
    "structure": {
        "name": "结构搭建练习",
        "method": "结构搭建法",
        "description": "练习搭好文章的开头-中间-结尾",
        "prompt_template": "给下面的题目搭一个'凤头-猪肚-豹尾'的大纲：",
        "exercises": {
            1: [
                {"topic": "我最喜欢的动物", "hint": "开头：一句话介绍它\n中间：它长什么样？\n结尾：你喜欢它什么？"},
                {"topic": "开心的一天", "hint": "开头：哪一天？\n中间：做了什么？\n结尾：你的感受？"},
            ],
            2: [
                {"topic": "我最喜欢的动物", "hint": "开头：一句话介绍它\n中间：它长什么样？会做什么？\n结尾：你喜欢它什么？"},
                {"topic": "开心的一天", "hint": "开头：哪一天？为什么开心？\n中间：发生了什么？\n结尾：你的感受？"},
            ],
            3: [
                {"topic": "我最喜欢的动物", "hint": "开头：一句话介绍它\n中间：它长什么样？会做什么？\n结尾：你喜欢它什么？"},
                {"topic": "开心的一天", "hint": "开头：哪一天？为什么开心？\n中间：发生了什么？\n结尾：你的感受？"},
            ],
            4: [
                {"topic": "我的好朋友", "hint": "开头：用一个特点引入\n中间：2件事展现特点\n结尾：表达感情"},
                {"topic": "第一次XX", "hint": "开头：设悬念\n中间：困难→解决（有波折）\n结尾：感悟"},
            ],
            5: [
                {"topic": "难忘的一件事", "hint": "开头：用声音/对话/疑问\n中间：经过详细+有波折\n结尾：感悟/呼应"},
                {"topic": "美丽的XX", "hint": "开头：总写印象\n中间：移步换景3站\n结尾：抒情收束"},
            ],
            6: [
                {"topic": "XX读后感", "hint": "引→议→联→结\n重点在'联'：联系自己"},
                {"topic": "竞选演讲稿", "hint": "开场：问题/故事吸引\n中间：3个观点+例子\n结尾：呼吁行动"},
            ],
        },
    },
    "emotion": {
        "name": "情感注入练习",
        "method": "情感注入法",
        "description": "练习不用'我很XX'直接说，而是用动作、细节表达情感",
        "prompt_template": "不用'开心/难过/紧张'这些词，写出下面的感受：",
        "exercises": {
            1: [
                {"situation": "你收到了最喜欢的礼物", "hint": "写出你的动作和表情", "forbidden": ["开心", "高兴", "快乐"]},
                {"situation": "你的好朋友转学了", "hint": "写出你的动作和表情", "forbidden": ["难过", "伤心"]},
            ],
            2: [
                {"situation": "你收到了最喜欢的礼物", "hint": "写出你的动作和表情", "forbidden": ["开心", "高兴", "快乐"]},
                {"situation": "你的好朋友转学了", "hint": "写出你的动作和表情", "forbidden": ["难过", "伤心"]},
            ],
            3: [
                {"situation": "你收到了最喜欢的礼物", "hint": "写出你的动作和表情", "forbidden": ["开心", "高兴", "快乐"]},
                {"situation": "你的好朋友转学了", "hint": "写出你的动作和表情", "forbidden": ["难过", "伤心"]},
            ],
            4: [
                {"situation": "考试考了100分", "hint": "用动作和身体反应写出兴奋", "forbidden": ["开心", "兴奋", "高兴"]},
                {"situation": "上台前很紧张", "hint": "用身体反应写出紧张", "forbidden": ["紧张", "害怕"]},
            ],
            5: [
                {"situation": "被老师表扬了", "hint": "写出从意外到自豪的心理变化", "forbidden": ["开心", "自豪", "骄傲"]},
                {"situation": "和朋友吵架后和好了", "hint": "写出心情的转变过程", "forbidden": ["难过", "开心"]},
            ],
            6: [
                {"situation": "看到父母辛苦工作的样子", "hint": "写出心里的触动和感悟", "forbidden": ["感动", "心疼"]},
                {"situation": "毕业时和同学告别", "hint": "写出复杂的心情和不舍", "forbidden": ["难过", "不舍"]},
            ],
        },
    },
    "comprehensive": {
        "name": "综合练习",
        "method": "综合",
        "description": "综合运用多种方法的写作挑战",
        "prompt_template": "写作挑战！用上今天学的方法：",
        "exercises": {
            1: [
                {"challenge": "写一段'我的课间十分钟'（用2种感官描写）", "methods": ["五官描写法"], "word_target": 50},
                {"challenge": "写一段'雨后的校园'（写出你看到了什么、听到了什么）", "methods": ["五官描写法"], "word_target": 50},
            ],
            2: [
                {"challenge": "写一段'我的课间十分钟'（至少用2种感官描写）", "methods": ["五官描写法"], "word_target": 80},
                {"challenge": "写一段'雨后的校园'（写出你看到了什么、听到了什么）", "methods": ["五官描写法"], "word_target": 80},
            ],
            3: [
                {"challenge": "写一段'我的课间十分钟'（至少用2种感官描写）", "methods": ["五官描写法"], "word_target": 100},
                {"challenge": "写一段'雨后的校园'（写出你看到了什么、听到了什么）", "methods": ["五官描写法"], "word_target": 100},
            ],
            4: [
                {"challenge": "把'今天的体育课很有趣'升级成一段3种感官的描写", "methods": ["好句升级法", "五官描写法"], "word_target": 150},
                {"challenge": "给'我的妈妈'搭一个凤头-猪肚-豹尾的大纲，并写开头", "methods": ["结构搭建法"], "word_target": 80},
            ],
            5: [
                {"challenge": "写一件你学会XX的事情，要有波折，写出心情变化", "methods": ["波折法", "情感注入法"], "word_target": 200},
                {"challenge": "用一个声音开头写一段想象作文", "methods": ["凤头豹尾法", "五官描写法"], "word_target": 150},
            ],
            6: [
                {"challenge": "不用任何情感词，写一段让人感动的文字", "methods": ["情感注入法", "好句升级法"], "word_target": 200},
                {"challenge": "写一篇短读后感（引→议→联→结）", "methods": ["引议联结法"], "word_target": 250},
            ],
        },
    },
    # ====== 新增练习类型 ======
    "reflective": {
        "name": "反思性写作练习",
        "method": "反思性写作",
        "description": "用写作整理内心世界——不是写作文，是和自己对话",
        "prompt_template": "试试用文字整理一下你的内心世界：",
        "exercises": {
            1: [
                {
                    "type": "心情日记",
                    "prompt": "今天的心情是什么颜色？（红色=激动、蓝色=平静、灰色=难过……）",
                    "hint": "闭上眼睛感受一下，然后写下你的颜色和为什么",
                    "template": "今天我的心情是____色的，因为____。",
                },
                {
                    "type": "心情日记",
                    "prompt": "今天的心情是什么天气？（晴天=开心、雨天=难过、多云=说不清……）",
                    "hint": "用天气来形容你今天的心情吧",
                    "template": "今天我心里的天气是____，因为____。",
                },
            ],
            2: [
                {
                    "type": "心情日记",
                    "prompt": "今天的心情是什么颜色？为什么？",
                    "hint": "写出颜色，再写一两句原因",
                    "template": "今天我的心情是____色的，因为____。我觉得____。",
                },
                {
                    "type": "心情日记",
                    "prompt": "今天的心情是什么味道？为什么？",
                    "hint": "甜的=开心，苦的=难过，辣的=激动……",
                    "template": "今天的心情是____味的，因为____。",
                },
            ],
            3: [
                {
                    "type": "心情日记",
                    "prompt": "今天的心情是什么颜色/天气/味道？为什么？",
                    "hint": "选一种感觉来形容，再写写发生了什么",
                    "template": "今天我的心情是____的，因为____。这件事让我觉得____。",
                },
                {
                    "type": "写给自己的信",
                    "prompt": "写几句话给昨天的自己",
                    "hint": "想对昨天的自己说什么？表扬？安慰？提醒？",
                    "template": "亲爱的昨天的我：____。",
                },
            ],
            4: [
                {
                    "type": "心情日记",
                    "prompt": "今天的心情是什么颜色/天气/味道？写写发生了什么",
                    "hint": "用比喻形容心情，再写写具体的事",
                    "template": "今天我的心情像____，因为____。",
                },
                {
                    "type": "写给自己的信",
                    "prompt": "写一封短信给半年后的自己",
                    "hint": "你现在最想对未来的自己说什么？有什么期待？",
                    "template": "亲爱的半年后的我：____。",
                },
                {
                    "type": "成长信模板",
                    "prompt": "回想一件让你学到东西的事",
                    "hint": "这件事让你明白了什么？下次你会怎么做？",
                    "template": "这件事让我学到了______，下次我会______。",
                },
            ],
            5: [
                {
                    "type": "写给自己的信",
                    "prompt": "写一封信给'另一个自己'——那个你不敢让别人看到的自己",
                    "hint": "你有没有一些想法，平时不敢说出来？写在这里，只有你自己能看到",
                    "template": "亲爱的另一个我：其实我____。",
                },
                {
                    "type": "成长信模板",
                    "prompt": "回想一个你从失败中学到东西的时刻",
                    "hint": "失败不可怕，重要的是你学到了什么",
                    "template": "那次失败让我学到了______，如果再来一次我会______。",
                },
                {
                    "type": "心情日记",
                    "prompt": "今天的心情像一首什么歌？为什么？",
                    "hint": "欢快的？安静的？激昂的？用音乐的感觉来形容你的心情",
                    "template": "今天我的心情像一首____的歌，因为____。",
                },
            ],
            6: [
                {
                    "type": "写给自己的信",
                    "prompt": "写一封信给小学毕业时的自己",
                    "hint": "你希望那时候的自己变成什么样？有什么话想提前告诉ta？",
                    "template": "亲爱的毕业时的我：____。",
                },
                {
                    "type": "成长信模板",
                    "prompt": "写一封'和解信'——和自己或和某个人的和解",
                    "hint": "有没有什么心结，试着用文字解开它",
                    "template": "关于____，我一直在想____。现在我明白了______。",
                },
                {
                    "type": "心情日记",
                    "prompt": "用'如果今天可以重来'开头，写下你会怎么度过",
                    "hint": "不是后悔，是思考——如果再来一次，你会做出什么不同的选择？",
                    "template": "如果今天可以重来，我会______，因为______。",
                },
            ],
        },
    },
    "mirror": {
        "name": "照镜子练习",
        "method": "照镜子评估",
        "description": "用四面镜子看自己的作文——不是打分，是照见",
        "prompt_template": "用四面镜子照一照你的作文：",
        "exercises": {
            1: [
                {
                    "mirror": "你写了什么",
                    "prompt": "读读你写的作文，你写了什么内容？用一句话说说",
                    "hint": "就像告诉没看过这篇作文的人：你的作文写了什么？",
                    "guidance": "这面镜子帮你看清：我选了什么来写",
                },
                {
                    "mirror": "你的感受",
                    "prompt": "写这篇作文的时候，你心里是什么感觉？",
                    "hint": "开心？紧张？还是随便写写？",
                    "guidance": "这面镜子帮你看清：写作文时我真实的感受是什么",
                },
            ],
            2: [
                {
                    "mirror": "你写了什么",
                    "prompt": "读读你写的作文，你写了什么内容？用一句话说说",
                    "hint": "就像告诉没看过这篇作文的人：你的作文写了什么？",
                    "guidance": "这面镜子帮你看清：我选了什么来写",
                },
                {
                    "mirror": "你的感受",
                    "prompt": "写这篇作文的时候，你心里是什么感觉？",
                    "hint": "开心？紧张？还是随便写写？",
                    "guidance": "这面镜子帮你看清：写作文时我真实的感受是什么",
                },
            ],
            3: [
                {
                    "mirror": "你写了什么",
                    "prompt": "读读你的作文，你选了什么来写？有没有特别想告诉读者的细节？",
                    "hint": "找出你写得最具体的那句话",
                    "guidance": "这面镜子帮你看清：我选了什么素材，写了什么细节",
                },
                {
                    "mirror": "你怎么搭的",
                    "prompt": "你的作文是怎么开头的？怎么结尾的？",
                    "hint": "开头写了什么？结尾写了什么？它们有关系吗？",
                    "guidance": "这面镜子帮你看清：我的文章是怎么组织的",
                },
                {
                    "mirror": "你的感受",
                    "prompt": "你写这篇作文的时候，心里是什么感觉？写出来的是真感受吗？",
                    "hint": "如果有重新写一次的机会，你最想改哪里？",
                    "guidance": "这面镜子帮你看清：我的感受是真实的还是'写出来'的",
                },
            ],
            4: [
                {
                    "mirror": "你写了什么",
                    "prompt": "读读你的作文，你选了什么来写？有没有特别生动的细节？",
                    "hint": "找出你写得最具体的那句话，说说它好在哪里",
                    "guidance": "这面镜子帮你看清：我选了什么素材，写了什么细节",
                },
                {
                    "mirror": "你怎么搭的",
                    "prompt": "你的作文是怎么开头的？怎么收尾的？中间有分段吗？",
                    "hint": "开头能吸引人吗？结尾有没有力度？",
                    "guidance": "这面镜子帮你看清：我的文章是怎么组织的",
                },
                {
                    "mirror": "你怎么说的",
                    "prompt": "你用了什么特别的词或句子？有没有让你自己觉得'写得好'的地方？",
                    "hint": "找出你觉得最得意的一句话",
                    "guidance": "这面镜子帮你看清：我用了什么词，造了什么句",
                },
                {
                    "mirror": "你的感受",
                    "prompt": "你写出来的感受是真实的吗？如果有重新写一次的机会，你想改什么？",
                    "hint": "真实的感受比华丽的词更重要",
                    "guidance": "这面镜子帮你看清：我的感受是真实的还是表演的",
                },
            ],
            5: [
                {
                    "mirror": "你写了什么",
                    "prompt": "你的作文选了什么素材？哪些细节让读者能看到画面？",
                    "hint": "好的细节就像照片，让读者'看到'了你写的东西",
                    "guidance": "这面镜子帮你看清：我选了什么素材，细节够不够具体",
                },
                {
                    "mirror": "你怎么搭的",
                    "prompt": "你的文章结构是怎样的？开头用了什么方法？中间有没有波折？结尾有没有力度？",
                    "hint": "好的结构就像好房子的骨架",
                    "guidance": "这面镜子帮你看清：我的文章是怎么组织的",
                },
                {
                    "mirror": "你怎么说的",
                    "prompt": "你用了什么修辞手法？有没有比喻、拟人、对话？哪个词用得最妙？",
                    "hint": "好的语言就像给文章穿上了好看的衣服",
                    "guidance": "这面镜子帮你看清：我用了什么修辞，语言有没有亮点",
                },
                {
                    "mirror": "你的感受",
                    "prompt": "你写出来的情感是真实流露还是为了凑字数？有没有'不说但读者能感受到'的地方？",
                    "hint": "最好的情感是'你不说，我也读到了'",
                    "guidance": "这面镜子帮你看清：我的情感表达是否真实、是否有变化",
                },
            ],
            6: [
                {
                    "mirror": "你写了什么",
                    "prompt": "你选了什么角度来写？这个角度有什么独特之处？有没有别人想不到的细节？",
                    "hint": "独特的视角是你最珍贵的写作财富",
                    "guidance": "这面镜子帮你看清：我的选材角度和细节深度",
                },
                {
                    "mirror": "你怎么搭的",
                    "prompt": "你的文章结构是否有设计感？有没有起承转合？首尾是否呼应？",
                    "hint": "好的结构让读者跟着你的节奏走，不迷路",
                    "guidance": "这面镜子帮你看清：我的结构是否有意识地设计",
                },
                {
                    "mirror": "你怎么说的",
                    "prompt": "你用了哪些修辞和写作技巧？语言有没有个人风格？有没有'只有你会这么写'的句子？",
                    "hint": "风格是写作的最高境界——让人一看就知道这是你写的",
                    "guidance": "这面镜子帮你看清：我的语言风格和技巧运用",
                },
                {
                    "mirror": "你的感受",
                    "prompt": "你的情感表达是否有层次？是平铺直叙还是有波澜？读者能和你共情吗？",
                    "hint": "最高级的情感表达是让读者和你一起笑、一起哭",
                    "guidance": "这面镜子帮你看清：我的情感是否有深度、有变化、有感染力",
                },
            ],
        },
    },
}


def generate_exercise(exercise_type: str, grade: int = 4) -> dict:
    """生成练习"""
    grade = max(1, min(6, grade))

    # 匹配练习类型
    type_aliases = {
        "句子升级": "sentence_upgrade", "好句": "sentence_upgrade", "升级": "sentence_upgrade",
        "五官": "senses", "感官": "senses", "描写": "senses",
        "结构": "structure", "大纲": "structure", "开头": "structure",
        "情感": "emotion", "感受": "emotion", "心情": "emotion",
        "综合": "comprehensive", "挑战": "comprehensive",
        "反思": "reflective", "反思性": "reflective", "心情日记": "reflective",
        "写给自己的信": "reflective", "成长信": "reflective",
        "照镜子": "mirror", "镜子": "mirror", "自评": "mirror",
    }

    matched_type = exercise_type
    if exercise_type not in EXERCISES:
        for alias, canonical in type_aliases.items():
            if alias in exercise_type or exercise_type in alias:
                matched_type = canonical
                break
        else:
            matched_type = "comprehensive"  # 默认综合练习

    exercise_data = EXERCISES[matched_type]

    # 选择年级对应的练习
    grade_exercises = exercise_data["exercises"].get(grade, exercise_data["exercises"].get(4, []))
    if not grade_exercises:
        grade_exercises = exercise_data["exercises"][4]

    return {
        "name": exercise_data["name"],
        "method": exercise_data["method"],
        "description": exercise_data["description"],
        "prompt_template": exercise_data["prompt_template"],
        "exercises": grade_exercises,
        "grade": grade,
        "tips": _get_tips(matched_type, grade),
    }


def _get_tips(exercise_type: str, grade: int) -> list:
    """获取练习提示"""
    tips_map = {
        "sentence_upgrade": [
            "口诀：加形容、加感受、加比喻",
            "不要只加一个形容词就停，试试同时用两种方法",
            "改完后大声读一遍，听听是不是更生动了",
        ],
        "senses": [
            "口诀：看听闻摸尝，文章就不空",
            "不需要5种全用，每次至少3种",
            "最容易被忽略的是'闻'和'摸'，试试加上它们",
        ],
        "structure": [
            "口诀：凤头漂亮引人来，猪肚丰富撑起来，豹尾有力收得住",
            "先想好中间要写什么，再写开头和结尾",
            "大纲不需要很长，每段写一句话概括就行",
        ],
        "emotion": [
            "口诀：不说'我很开心'，写出怎么个开心法",
            "用动作、表情、身体反应代替直接说感受",
            "写出心情的变化比只写一种心情更有力量",
        ],
        "comprehensive": [
            "把今天学的方法都用上",
            "先搭大纲再写，不要急着动笔",
            "写完后用检查修改法读一遍",
        ],
        "reflective": [
            "反思性写作没有对错，你的感受就是最好的答案",
            "不用想'写得好不好'，只管把心里的话写出来",
            "写完后读一遍，你可能会发现自己之前没注意到的想法",
        ],
        "mirror": [
            "镜子不是尺子，照镜子是为了看清自己，不是为了打分",
            "每面镜子都要认真照，你可能会发现惊喜",
            "如果你发现自己有些地方想改，那是成长的声音",
        ],
    }
    return tips_map.get(exercise_type, tips_map["comprehensive"])


def main():
    """主函数"""
    try:
        exercise_type = sys.argv[1].strip() if len(sys.argv) > 1 else ""
        if not exercise_type:
            exercise_type = "comprehensive"
        try:
            grade = int(sys.argv[2]) if len(sys.argv) > 2 else 4
        except ValueError:
            grade = 4

        result = generate_exercise(exercise_type, grade)
        output = {
            "success": True,
            "data": result,
        }
        print(json.dumps(output, ensure_ascii=False, indent=2))

    except Exception as e:
        error_result = {
            "success": False,
            "error": str(e),
            "message": f"练习生成失败：{e}",
        }
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
