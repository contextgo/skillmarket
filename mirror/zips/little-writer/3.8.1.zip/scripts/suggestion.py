#!/usr/bin/env python3
"""Suggestion 数据类 — 统一修改建议格式

所有修改建议必须通过此类输出，结构强制以问句结尾。

用法：
    from suggestion import Suggestion
    s = Suggestion(original="优雅极了", suggestion="真够优雅的", reason="更口语化")
    print(s.format())  # 自动加"你觉得呢？"
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Suggestion:
    """一条修改建议"""
    original: str           # 原文
    suggestion: str         # 建议稿
    reason: str             # 修改理由
    location: str = ""      # 可选：位置描述（如"第二段第三句"）
    ends_with_question: bool = True  # 是否以问句结尾

    def format(self) -> str:
        """格式化输出，自动添加'你觉得呢？'"""
        parts = []
        if self.location:
            parts.append(f"[{self.location}]")
        parts.append(f"「{self.original}」→ 「{self.suggestion}」")
        parts.append(f"（{self.reason}）")
        result = " ".join(parts)
        if self.ends_with_question and not result.endswith("?"):
            result += " 你觉得呢？"
        return result

    def to_dict(self) -> dict:
        return {
            "type": "suggestion",
            "original": self.original,
            "suggestion": self.suggestion,
            "reason": self.reason,
            "location": self.location,
            "ends_with_question": self.ends_with_question,
        }


@dataclass
class ChangeLog:
    """一组修改建议的变化清单"""
    kept: list[str] = field(default_factory=list)        # 保留的内容
    removed: list[str] = field(default_factory=list)      # 删除的内容
    modified: list[Suggestion] = field(default_factory=list)  # 修改的内容

    def format(self) -> str:
        parts = ["【变化清单】"]
        if self.kept:
            parts.append(f"\n✅ 保留：{'，'.join(self.kept)}")
        if self.removed:
            parts.append(f"\n✂️ 删除：{'，'.join(self.removed)}")
        if self.modified:
            parts.append("\n🔄 修改：")
            for s in self.modified:
                parts.append(f"  • {s.format()}")
        return "\n".join(parts)


def format_suggestion(original: str, suggestion: str, reason: str, location: str = "") -> str:
    """快捷函数：创建并格式化一条修改建议"""
    s = Suggestion(
        original=original,
        suggestion=suggestion,
        reason=reason,
        location=location,
    )
    return s.format()


if __name__ == "__main__":
    # 简单测试
    s = Suggestion("优雅极了", "真够优雅的", "去结论化，让读者自己感受")
    print(s.format())
    print()

    cl = ChangeLog(
        kept=["野花段全文"],
        removed=["心里想","忍不住（第二个）"],
        modified=[s],
    )
    print(cl.format())
