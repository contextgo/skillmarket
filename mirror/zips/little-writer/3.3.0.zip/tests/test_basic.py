#!/usr/bin/env python3
"""little-writer v3.0.1 基础测试

覆盖范围：
1. analyze.py 五官词频识别
2. main.py 空输入处理
3. main.py 正常大纲生成
4. greeting.md 存在性（替代 first-interact.md）
5. topic 文件结构（范文已拆出 excerpts/）

运行：python3 tests/test_basic.py
"""

import json
import subprocess
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).parent.parent
SCRIPTS_DIR = SKILL_DIR / "scripts"
TOPICS_DIR = SKILL_DIR / "references" / "topics"
EXCERPTS_DIR = TOPICS_DIR / "excerpts"

PASSED = 0
FAILED = 0


def run_script(script_name: str, args: list) -> dict:
    """运行脚本并返回 JSON 输出"""
    result = subprocess.run(
        [sys.executable, str(SCRIPTS_DIR / script_name)] + args,
        capture_output=True, text=True, timeout=10
    )
    return json.loads(result.stdout) if result.stdout.strip() else {}


def test(name: str, condition: bool, detail: str = ""):
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  ✅ {name}")
    else:
        FAILED += 1
        print(f"  ❌ {name}" + (f" — {detail}" if detail else ""))


# ====== Test 1: analyze.py 五官词频识别 ======
print("\n🔍 Test 1: analyze.py 五官词频识别")

test_text = "今天天气真好，阳光明媚，我听到了鸟儿在唱歌，闻到了花香。妈妈做了一顿好吃的饭，甜甜的蛋糕让我很开心。"
result = run_script("analyze.py", [test_text, "4"])

if result.get("success"):
    sense = result["data"]["sense_analysis"]
    test("视觉识别'阳光'", sense.get("视觉", 0) >= 1, f"实际: {sense.get('视觉', 0)}")
    test("听觉识别'听到+唱歌'", sense.get("听觉", 0) >= 2, f"实际: {sense.get('听觉', 0)}")
    test("嗅觉识别'闻到+花香+香'", sense.get("嗅觉", 0) >= 3, f"实际: {sense.get('嗅觉', 0)}")
    test("味觉识别'好吃+甜甜'", sense.get("味觉", 0) >= 2, f"实际: {sense.get('味觉', 0)}")
else:
    test("analyze.py 基本运行", False, f"运行失败: {result.get('error', 'unknown')}")

# 空输入
result_empty = run_script("analyze.py", ["", "4"])
test("analyze.py 空输入返回失败", result_empty.get("success") == False)


# ====== Test 2: main.py 空输入处理 ======
print("\n🔍 Test 2: main.py 空输入处理")

result_empty_topic = run_script("main.py", ["", "4"])
test("main.py 空题材返回失败", result_empty_topic.get("success") == False)

result_normal = run_script("main.py", ["写景", "4"])
test("main.py 正常大纲生成", result_normal.get("success") == True)


# ====== Test 3: 文件结构完整性 ======
print("\n🔍 Test 3: 文件结构完整性")

# greeting.md 替代 first-interact.md
test("greeting.md 存在", (SKILL_DIR / "references" / "greeting.md").exists())
test("first-interact.md 已移除", not (SKILL_DIR / "references" / "first-interact.md").exists())

# topic 文件都有对应的 excerpts
topic_files = [f for f in TOPICS_DIR.glob("*.md") if f.name != "README.md"]
for tf in sorted(topic_files):
    excerpt_file = EXCERPTS_DIR / tf.name
    test(f"excerpts/{tf.name} 存在", excerpt_file.exists())

# 空壳目录已清理
test("outline-templates/ 已移除", not (SKILL_DIR / "references" / "outline-templates").exists())
test("supplement/ 已移除", not (SKILL_DIR / "references" / "supplement").exists())
# cache/ 保留 .gitkeep 占位（消除 verify.py 误报），不应有其他文件
cache_dir = SKILL_DIR / "data" / "cache"
cache_only_gitkeep = cache_dir.exists() and all(f.name == ".gitkeep" for f in cache_dir.iterdir())
test("cache/ 仅保留 .gitkeep", not cache_dir.exists() or cache_only_gitkeep)

# schemas 存在
test("schemas/analyze-output.json 存在", (SKILL_DIR / "data" / "schemas" / "analyze-output.json").exists())


# ====== Test 4: Token 预算已更新 ======
print("\n🔍 Test 4: Token 预算已更新")

skill_md = (SKILL_DIR / "SKILL.md").read_text()
test("L2_deep 已更新为 5000", "L2_deep: 5000" in skill_md)
test("hard_cap 已更新为 8000", "hard_cap: 8000" in skill_md)


# ====== Summary ======
print(f"\n{'='*40}")
print(f"测试结果：✅ {PASSED} 通过 / ❌ {FAILED} 失败 / 总计 {PASSED + FAILED}")
if FAILED > 0:
    sys.exit(1)
else:
    print("🎉 全部通过！")
