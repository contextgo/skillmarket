# Scripts — 接口文档

小学生作文拯救者 v3.5 的脚本层，遵循"脚本做计量，LLM做判断"原则。

## 通用约定

- 使用 Python 3 标准库，无外部依赖
- 输出格式为 JSON，包含 `success` 字段
- 从 `config.yaml` 读取配置参数（路径相对于 skill 根目录）
- 有模块 docstring 和 `main()` 函数
- 有错误处理（try/except），错误时输出 `{"success": false, "error": ..., "message": ...}`

---

## analyze.py — 作文统计分析

替代旧版 `evaluate.py`，**只做统计不做评分**。

### 用法

```bash
# 通过命令行参数
python3 scripts/analyze.py "作文文本" [年级]

# 通过管道
echo "作文文本" | python3 scripts/analyze.py [年级]
```

### 参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| 作文文本 | string | （必填）| 要分析的作文内容 |
| 年级 | int | 4 | 1-6年级，影响字数目标 |

### 输出

```json
{
  "success": true,
  "data": {
    "statistics": {
      "word_count": 245,
      "word_target": 400,
      "word_completion": "61%",
      "paragraph_count": 3,
      "sentence_count": 12
    },
    "sense_analysis": {
      "视觉": 3, "听觉": 1, "嗅觉": 0, "触觉": 0, "味觉": 0
    },
    "dialogue_count": 2
  }
}
```

### 功能说明

| 功能 | 说明 |
|------|------|
| 字数统计 | 中文字符数（含中文标点） |
| 段落统计 | 按换行或句号分段 |
| 句子统计 | 按句号/叹号/问号/省略号分句 |
| 字数完成度 | 实际字数/目标字数（目标从 config.yaml 读取） |
| 五官词频 | 按5种感官分类统计词数（词库从 config.yaml 的 sense_words_file 读取，不可用时用内置默认词库） |
| 对话句数 | 统计中文引号对数 |

### 不做的事（交给 LLM）

修辞检测、四维评分、水平定位、家长小贴士、综合分计算

---

## main.py — 大纲生成 + 自由表达

### 用法

```bash
# 大纲生成模式
python3 scripts/main.py [题材] [年级]

# 自由表达模式
python3 scripts/main.py --mode express [年级]
```

### 参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| 题材 | string | "想象作文" | 写作题材，支持模糊匹配 |
| 年级 | int | 4 | 1-6年级 |
| --mode express | flag | — | 自由表达模式，不生成大纲 |

### 大纲模式输出

```json
{
  "success": true,
  "data": {
    "topic": "写人",
    "matched_topic": "写人作文",
    "grade": 4,
    "outline": {
      "title": "写人作文大纲",
      "structure": [...],
      "tips": [...],
      "recommended_methods": [...],
      "word_target": 400,
      "grade": 4
    }
  }
}
```

### 自由表达模式输出

```json
{
  "success": true,
  "data": {
    "mode": "express",
    "grade": 4,
    "opening": "嗨！欢迎来到自由写作时间...",
    "guidance": "自由表达模式不生成大纲，不评分，不纠正..."
  }
}
```

### 功能说明

| 功能 | 说明 |
|------|------|
| 大纲生成 | 根据题材和年级生成写作大纲，支持12种题材的模糊匹配 |
| 自由表达 | --mode express 时输出温暖开场白，不生成大纲、不评分 |
| 模板内置 | 大纲模板使用内置模板（outline_templates_dir 已弃用），外置模板不可用时自动回退 |
| 年级适配 | 支持1-6年级，影响字数目标和开场白内容 |

---

## exercise.py — 练习生成

### 用法

```bash
python3 scripts/exercise.py [练习类型] [年级]
```

### 参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| 练习类型 | string | "comprehensive" | 见下表 |
| 年级 | int | 4 | 1-6年级 |

### 练习类型

| 类型ID | 名称 | 说明 |
|--------|------|------|
| sentence_upgrade | 好句升级练习 | 把平淡句子升级成生动好句 |
| senses | 五官描写练习 | 练习用看听闻摸尝五种感官描写 |
| structure | 结构搭建练习 | 练习搭好凤头-猪肚-豹尾结构 |
| emotion | 情感注入练习 | 用动作和细节代替直接说感受 |
| comprehensive | 综合练习 | 综合运用多种方法的写作挑战 |
| reflective | 反思性写作练习 | 心情日记/写给自己的信/成长信模板 |
| mirror | 照镜子练习 | 用五面镜子看自己的作文 |

别名匹配：支持中文别名（如"好句"→sentence_upgrade，"反思"→reflective，"镜子"→mirror）

### 输出

```json
{
  "success": true,
  "data": {
    "name": "反思性写作练习",
    "method": "反思性写作",
    "description": "用写作整理内心世界——不是写作文，是和自己对话",
    "prompt_template": "试试用文字整理一下你的内心世界：",
    "exercises": [
      {
        "type": "心情日记",
        "prompt": "...",
        "hint": "...",
        "template": "..."
      }
    ],
    "grade": 4,
    "tips": ["..."]
  }
}
```

### 新增练习说明

**反思性写作（reflective）**：
- 心情日记：用颜色/天气/味道/音乐形容心情
- 写给自己的信：写给昨天/半年后/毕业时的自己
- 成长信模板：这件事让我学到了______，下次我会______

**照镜子练习（mirror）**：
- 五面镜子：你写了什么 / 你怎么搭的 / 你怎么说的 / 你的感受 / 你像不像自己
- 不打分，只帮孩子"看见"自己的写作
- 按年级调整深度

---

## suggestion.py — 修改建议数据类 (v3.4.0+)

统一修改建议的输出格式，强制所有修改建议以"你觉得呢？"结尾。

### 用法

```python
from suggestion import Suggestion, ChangeLog, format_suggestion

# 单条建议
s = Suggestion("优雅极了", "真够优雅的", "去结论化，让读者自己感受")
print(s.format())  # → "「优雅极了」→「真够优雅的」（去结论化，让读者自己感受）你觉得呢？"

# 变化清单
cl = ChangeLog(
    kept=["野花段全文"],
    removed=["心里想"],
    modified=[s],
)
print(cl.format())  # → 保留/删除/修改清单
```

### 数据类

| 类 | 字段 | 说明 |
|----|------|------|
| Suggestion | original, suggestion, reason, location, ends_with_question | 单条修改建议 |
| ChangeLog | kept, removed, modified | 变化清单，可格式化输出 |

---

## update_profile.py — 用户画像管理 (v3.4.0+)

会话结束时写入/更新 `data/user-profile.md`，支持跨会话持久化。

### 用法

```bash
# 基础信息
python3 scripts/update_profile.py --nickname 龙虾 --grade 4 --topic 写景 --word-count 600 --highlight "樱花躺水上" --improvement "结尾过渡略急"

# 能力画像
python3 scripts/update_profile.py --strength "比喻生动" --growth-area "结尾有时万能句式" --overcome "不敢写感受"

# 风格标签 + 勋章
python3 scripts/update_profile.py --style-tag "会跟自己说话" --medal "比喻大师,细节观察家"

# 熟练度
python3 scripts/update_profile.py --proficiency-topic 写景 --proficiency-label "很自信，常有画面"

# 成长关注
python3 scripts/update_profile.py --concern "时间线矛盾" --concern-status "🟡留意中"
```

### Profile 字段

| 字段 | 说明 |
|------|------|
| 用户信息 | 昵称、年级、首次/最近会话、总写作次数 |
| 偏好记录 | 风格偏好、角色偏好、常用题材 |
| 能力画像 | 优势、成长区、已克服、风格标签、熟练度 |
| 勋章收藏 | 获得的写作称号 |
| 成长关注 | 可留意的习惯（🟡留意中 / 🟢已改善） |
| 写作成长轨迹 | 日期、题材、字数、亮点、改进点 |
