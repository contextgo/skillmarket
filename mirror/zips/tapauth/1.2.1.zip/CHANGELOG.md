# Changelog

## [0.1.0] - 2026-02-24

- Initial release
