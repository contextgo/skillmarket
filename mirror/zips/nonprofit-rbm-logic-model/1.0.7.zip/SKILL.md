---
author: vassiliylakhonin
description: Generate donor-ready NGO program design packages including
  RBM frameworks, theory of change, logframes, monitoring plans,
  proposal outlines, and SDG alignment for USAID, EU, GIZ, UN, and other
  development funders.
homepage: "https://clawhub.ai/vassiliylakhonin/ngo-program-design-suite"
name: ngo-program-design-suite
tags:
- ngo
- nonprofit
- rbm
- logframe
- theory-of-change
- monitoring
- evaluation
- grants
- proposal-writing
- sdg
version: 1.0.0
---

# NGO Program Design Suite

This skill helps nonprofit and NGO teams create donor-ready program
design packages for grant proposals and development projects.

It combines Results-Based Management, theory of change, logical
frameworks, indicators, monitoring plans, SDG alignment, and proposal
structure.

## Skill trigger

Activate this skill when the user asks about:

-   nonprofit or NGO program design
-   grant proposal structure
-   RBM frameworks
-   theory of change
-   logframes
-   monitoring and evaluation
-   donor-aligned project planning
-   SDG alignment
-   development project design

## What this skill can generate

This skill can produce:

-   RBM results chains
-   theory of change
-   donor-ready logframe tables
-   SMART indicators
-   monitoring and evaluation frameworks
-   SDG alignment
-   OECD DAC evaluation considerations
-   proposal outlines
-   assumptions and risks
-   donor-style program summaries

## RBM results chain

Inputs → Activities → Outputs → Outcomes → Impact

Inputs\
Resources required for implementation.

Activities\
Actions delivered by the project.

Outputs\
Direct measurable deliverables.

Outcomes\
Short- and medium-term changes.

Impact\
Long-term change created by the project.

## Logframe table generator

  ----------------------------------------------------------------------------
  Results Level     Indicators       Means of Verification     Assumptions
  ----------------- ---------------- ------------------------- ---------------
  Impact            long-term impact national statistics,      political
                    indicators       sector reports            stability

  Outcomes          outcome          surveys, administrative   stakeholder
                    indicators       data                      engagement

  Outputs           measurable       project reports           partner
                    deliverables                               capacity

  Activities        key              activity reports          operational
                    implementation                             feasibility
                    actions                                    
  ----------------------------------------------------------------------------

## SDG mapping

Map project outcomes to relevant UN Sustainable Development Goals (SDGs)
and explain how the program contributes.

## Monitoring and evaluation framework

Include:

-   indicators
-   baseline and targets
-   data sources
-   reporting frequency
-   responsible actors

## Example prompts

Create a donor-ready NGO project design package for a youth employment
program.

Build an RBM framework and logframe for a rural health initiative.

Generate a monitoring and evaluation plan for a climate resilience
project.

Create a development project design aligned with SDG goals.

## Output format

1.  Problem statement
2.  RBM results chain
3.  Theory of Change
4.  Logframe table
5.  Indicator framework
6.  Monitoring plan
7.  SDG alignment
8.  Risks and assumptions
9.  Proposal outline

## Output style

-   produce structured donor-ready outputs
-   keep language clear and professional
-   prioritize practical grant-writing usefulness
