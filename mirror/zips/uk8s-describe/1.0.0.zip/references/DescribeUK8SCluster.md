# 获取集群信息-DescribeUK8SCluster

获取集群信息

# Request Parameters
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Region|string|所属区域|**Yes**|
|ProjectId|string|项目id|No|
|ClusterId|string|k8s集群ID|**Yes**|

# Response Elements
|Parameter name|Type|Description|Required|
|---|---|---|---|
|RetCode|int|返回码|**Yes**|
|Action|string|操作名称|**Yes**|
|ClusterName|string|资源名字|**Yes**|
|ClusterId|string|集群ID|**Yes**|
|VPCId|string|所属VPC|**Yes**|
|SubnetId|string|所属子网|**Yes**|
|PodCIDR|string|Pod网段|**Yes**|
|ServiceCIDR|string|服务网段|**Yes**|
|MasterCount|int|Master 节点数量|**Yes**|
|MasterList|array|Master节点配置信息，具体参考UhostInfo。托管版不返回该信息|No|
|NodeList|array|Node节点配置信息,具体参考UhostInfo|No|
|CreateTime|int|创建时间|No|
|NodeCount|int|Node节点数量|No|
|ApiServer|string|集群apiserver地址|No|
|Status|string|状态|No|
|ExternalApiServer|string|集群外部apiserver地址|No|
|KubeProxy|object|kube-proxy配置|No|
|Version|string|K8S版本|No|
|ClusterDomain|string|自定义或者默认的clusterdomain|No|
|EtcdCert|string|集群etcd服务证书|No|
|EtcdKey|string|集群etcd服务密钥|No|
|CACert|string|集群CA根证书|No|
|MasterResourceStatus|string|Master配置预警：Normal正常；Warning 需要升级；Error    需要紧急升级；|No|
|CNIMode|string|CNI模式，可选值VPC/Calico|No|
|MonitorType|string|集群的监控类型：no无监控；cloudwatch统一监控平台；prometheus内置监控|No|
|Autoscaler|object|集群的节点伸缩(CA)配置|No|
|EnableUserAuth|bool|是否开启了授权管理功能|No|
|DedicatedPodSubnet|bool|Pod是否使用独立子网|No|
|PodSubnetIds|array|Pod使用的独立子网列表|No|
|PodSubnetSecGroups|array|Pod独立子网内的ip使用的安全组|No|
|DeleteProtection|int|删除保护开关。0表示不开启，1表示开启。默认不开启|No|

## UhostInfo
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Zone|string|所在机房|**Yes**|
|Name|string|主机名称|**Yes**|
|CPU|int|Cpu数量|**Yes**|
|Memory|int|内存|**Yes**|
|IPSet|array|节点IP信息|**Yes**|
|DiskSet|array|节点磁盘信息|**Yes**|
|NodeId|string|主机ID|**Yes**|
|OsName|string|镜像信息|**Yes**|
|CreateTime|int|创建时间|**Yes**|
|ExpireTime|int|到期时间|**Yes**|
|State|string|主机状态|**Yes**|
|NodeType|string|节点类型：uhost表示云主机;uphost表示物理云主机|**Yes**|

## KubeProxy
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Mode|string|KubeProxy模式，枚举值为[ipvs,iptables]|No|

## IPSet
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Type|string|国际: Internation，BGP: Bgp，内网: Private|No|
|IPId|string|IP资源ID (内网IP无对应的资源ID)|No|
|IP|string|IP地址|No|
|Bandwidth|int|IP对应的带宽, 单位: Mb (内网IP不显示带宽信息)|No|
|Default|string|是否默认的弹性网卡的信息。true: 是默认弹性网卡；其他值：不是。|No|

## DiskSet
|Parameter name|Type|Description|Required|
|---|---|---|---|
|Type|string|磁盘类型。系统盘: Boot，数据盘: Data,网络盘：Udisk|No|
|DiskId|string|磁盘长ID|No|
|Name|string|UDisk名字（仅当磁盘是UDisk时返回）|No|
|Drive|string|磁盘盘符|No|
|Size|int|磁盘大小，单位: GB|No|
|BackupType|string|备份方案，枚举类型：BASIC_SNAPSHOT,普通快照；DATAARK,方舟。无快照则不返回该字段。|No|
|IOPS|int|当前主机的IOPS值|No|
|Encrypted|string|Yes: 加密 No: 非加密|No|
|DiskType|string|LOCAL_NOMAL\| CLOUD_NORMAL\| LOCAL_SSD\| CLOUD_SSD\|EXCLUSIVE_LOCAL_DISK|No|
|IsBoot|string|True\| False|No|

# Request Example
```
https://api.ucloud.cn/?Action=DescribeUK8SCluster
&Region=zfXlbPNP
&Zone=dSenpJQB
&ClusterID=kCvoCLjV
```

# Response Example
```
{
    "EnableUserAuth": true, 
    "EtcdKey": "fcwdvzzi", 
    "UserAuthable": false, 
    "MasterResourceStatus": "BBlivSsQ", 
    "RetCode": 0, 
    "KubeProxy": {}, 
    "PodSubnetSecGroups": [
        "nOXEdkfR"
    ], 
    "ClusterDomain": "TrnBlMmf", 
    "PodSubnetIds": [
        "zVCBFDyV"
    ], 
    "EtcdCert": "KfWoZCox", 
    "Version": "JSrvWaDf", 
    "CACert": "bgsgUSSj", 
    "DeleteProtection": 5, 
    "Action": "DescribeUK8SClusterResponse", 
    "MonitorType": "XjdGMetb", 
    "CNIMode": "lhkRDcNM", 
    "ExternalApiServer": "GVZVJyHy", 
    "DedicatedPodSubnet": true, 
    "Autoscaler": {}
}
```