---
name: uk8s-describe
description: 查询单个 UK8S 集群详细信息，含 Master/Node 节点列表。Use when user asks to "查看集群详情", "describe UK8S cluster", "看看集群节点", "集群信息".
argument-hint: "<cluster-id>"
disable-model-invocation: true
allowed-tools: Bash(ucloud *), Bash(which *), Read, AskUserQuestion
---

# 查询 UK8S 集群详情

通过 `ucloud-cli` 调用 `DescribeUK8SCluster`，查询单个集群的完整配置和节点信息。

- `$ARGUMENTS` 为 ClusterId，**必填**；若未提供，用 `AskUserQuestion` 询问

---

## Step 1：检查 ucloud-cli 环境

按 [`references/check-ucloud-cli.md`](references/check-ucloud-cli.md) 执行环境检查。

---

## Step 2：确认 ClusterId

若 `$ARGUMENTS` 为空，用 `AskUserQuestion` 询问：

```
请输入要查询的集群 ID（如 uk8s-xxxxxxxx）：
```

记录 `ClusterId`。

---

## Step 3：查询集群详情

读取 [`references/DescribeUK8SCluster.md`](references/DescribeUK8SCluster.md) 了解响应结构。

```bash
ucloud api --Action DescribeUK8SCluster --Region <Region> --ProjectId <ProjectId> --ClusterId <ClusterId>
```

| RetCode | 处理 |
|---------|------|
| 0 | 进入 Step 4 |
| 非 0 | 输出完整 RetCode + Message，终止流程 |

---

## Step 4：展示结果

### 基本信息

```
集群 ID:        uk8s-xxxxxxxxxx
名称:           my-cluster
K8s 版本:       1.32.8
状态:           RUNNING
CNI 模式:       VPC
KubeProxy:      iptables
监控类型:       prometheus
删除保护:       关闭

网络:
  VPC/Subnet:   uvnet-xxx / subnet-xxx
  Pod CIDR:     172.16.0.0/16
  Service CIDR: 192.168.0.0/16

ApiServer:      10.23.x.x
外网 API:       106.x.x.x

创建时间:       2025-01-01 12:00:00
```

### Master 节点（MasterList）

若 `MasterList` 有数据（托管版集群不返回）：

```
Master 节点（共 N 个）：

名称                    Zone        CPU   内存    内网 IP      状态     OS
uk8s-xxx-m-a           cn-sh2-01   2C    4096M   10.23.x.x   Running  Ubuntu 24.04
uk8s-xxx-m-b           cn-sh2-01   2C    4096M   10.23.x.x   Running  Ubuntu 24.04
uk8s-xxx-m-c           cn-sh2-01   2C    4096M   10.23.x.x   Running  Ubuntu 24.04
```

若 `MasterList` 为空，提示：`托管版集群不返回 Master 节点信息。`

### Node 节点（NodeList）

```
Node 节点（共 N 个）：

名称                    Zone        CPU   内存    内网 IP      状态     OS
uk8s-xxx-n-yyyyy       cn-sh2-01   4C    8192M   10.23.x.x   Running  Ubuntu 24.04
uk8s-xxx-n-zzzzz       cn-sh2-01   4C    8192M   10.23.x.x   Running  Ubuntu 24.04
```

若 `NodeList` 为空，提示：`当前集群没有 Node 节点。`

**节点字段说明：**
- 内存单位 MB，展示时保留原始值
- `IPSet` 中取 `Type=Private` 的 IP 作为内网 IP，`Type=Bgp` 或 `Internation` 作为外网 IP（若有）
- `State` 直接展示原始值

---

## 错误处理原则

- 不允许吞错误，必须输出 RetCode + Message
- ClusterId 不存在时提示用户确认 ID 是否正确、Region 是否匹配
