---
name: wechat-sender
description: 通过 Windows 微信 PC 客户端向好友/文件传输助手发送文本消息和文件的自动化工具。使用键盘模拟 + 剪贴板操作实现，无需微信 API。当用户需要向微信发送消息、发送文件、通知到文件传输助手时使用此 skill。触发词：微信、微信发送、文件传输助手、发消息、发文件、微信通知。
---

# WeChat Sender

## Overview

通过键盘模拟和剪贴板操作，自动化操作 Windows 微信 PC 客户端，实现向指定联系人或文件传输助手发送文本消息和文件。

**前置条件：**
- Windows 系统，微信 PC 客户端已登录
- Python 3.7+，安装了 `pywin32`（`pip install pywin32`）
- 微信窗口句柄已配置（当前为 `68440`，如失效需重新获取）

## 两种使用方式

### 方式一：MCP Server（推荐，WorkBuddy 可直接调用）

`scripts/wechat_mcp_server.py` 是一个 MCP 服务器，通过 stdio 协议暴露两个工具：

**配置方法：** 在 `~/.workbuddy/mcp.json` 中添加：

```json
{
  "mcpServers": {
    "wxauto": {
      "command": "D:\\Miniconda\\envs\\browser_auto\\python.exe",
      "args": [
        "path/to/scripts/wechat_mcp_server.py"
      ]
    }
  }
}
```

**可用工具：**

| 工具 | 参数 | 说明 |
|------|------|------|
| `send_message` | `contact` (str), `message` (str) | 向微信好友发送文本消息 |
| `send_file` | `contact` (str), `file_paths` (list[str]) | 向微信好友发送文件（支持多文件） |

### 方式二：直接调用 Python 脚本

`scripts/wechat_sender.py` 是一个独立的命令行脚本：

```bash
# 发送文本消息
python scripts/wechat_sender.py --contact "文件传输助手" --message "你好"

# 发送文件
python scripts/wechat_sender.py --contact "文件传输助手" --file "C:/path/to/doc.docx"
python scripts/wechat_sender.py --contact "张三" --file "a.pdf" "b.jpg"
```

## 工作原理

1. **激活微信窗口** — 通过 Windows API 将微信窗口切换到前台
2. **搜索联系人** — Ctrl+F 打开搜索框，粘贴联系人名，验证搜索框内容
3. **打开对话框** — 回车选择第一个搜索结果
4. **发送内容**：
   - 文本：粘贴到输入框 → 验证 → Enter 发送
   - 文件：用 `PowerShell Set-Clipboard -Path` 将文件路径写入 CF_HDROP 剪贴板 → Ctrl+V 粘贴 → Enter 发送

## 已知问题

- 微信窗口句柄（`WECHAT_HANDLE = 68440`）在微信重启后可能变化，需要重新获取
- 发送过程中请勿操作鼠标键盘，避免焦点丢失
- 大文件发送需要更长的等待时间（自动按文件大小计算）
