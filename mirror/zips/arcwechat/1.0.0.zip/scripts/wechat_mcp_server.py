# -*- coding: utf-8 -*-
"""
WeChat MCP Server (键盘模拟版 v4)
功能：
- send_message: 发送文本消息（v3 核心逻辑）
- send_file:  发送文件（v4 新增）
  原理: PowerShell Set-Clipboard -Path → 导航到联系人 → Ctrl+V → Enter

改进历史：
v3: 搜索框剪贴板验证、重试机制、焦点管理
v4: 新增 send_file，用 CF_HDROP 剪贴板实现文件发送
"""
import sys
import os
import asyncio
import logging
import time
import ctypes
import ctypes.wintypes
import traceback
import json
import subprocess
from pathlib import Path

import win32gui
import win32con
import win32api
import win32clipboard

from mcp.server import Server
from mcp.server.stdio import stdio_server

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("wechat-mcp")

user32 = ctypes.windll.user32
WECHAT_HANDLE = 68440

# ─────────────── 底层键盘操作 ───────────────

def activate_wechat() -> bool:
    """激活微信窗口到前台"""
    if not win32gui.IsWindow(WECHAT_HANDLE):
        return False
    user32.SwitchToThisWindow(WECHAT_HANDLE, True)
    time.sleep(0.3)
    if win32gui.IsIconic(WECHAT_HANDLE):
        win32gui.ShowWindow(WECHAT_HANDLE, win32con.SW_RESTORE)
        time.sleep(0.3)
    return True


def _send_key(vk: int):
    win32api.keybd_event(vk, 0, 0, 0)
    time.sleep(0.03)
    win32api.keybd_event(vk, 0, win32con.KEYEVENTF_KEYUP, 0)
    time.sleep(0.03)


def _ctrl_key(vk: int):
    win32api.keybd_event(win32con.VK_CONTROL, 0, 0, 0)
    time.sleep(0.03)
    win32api.keybd_event(vk, 0, 0, 0)
    time.sleep(0.04)
    win32api.keybd_event(vk, 0, win32con.KEYEVENTF_KEYUP, 0)
    time.sleep(0.03)
    win32api.keybd_event(win32con.VK_CONTROL, 0, win32con.KEYEVENTF_KEYUP, 0)
    time.sleep(0.05)


def paste_text(text: str):
    """通过剪贴板粘贴 Unicode 文本（不恢复旧内容，减少焦点丢失风险）"""
    try:
        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardText(text, win32con.CF_UNICODETEXT)
        win32clipboard.CloseClipboard()
    except Exception as e:
        win32clipboard.CloseClipboard()
        raise e
    _ctrl_key(0x56)  # Ctrl+V
    time.sleep(0.15)


def get_clipboard_text() -> str:
    """读取当前剪贴板内容"""
    try:
        win32clipboard.OpenClipboard()
        try:
            data = win32clipboard.GetClipboardData(win32con.CF_UNICODETEXT)
            return data
        except:
            return ""
        finally:
            win32clipboard.CloseClipboard()
    except:
        return ""


def get_foreground_window_title() -> str:
    try:
        hwnd = win32gui.GetForegroundWindow()
        return win32gui.GetWindowText(hwnd)
    except:
        return ""


def close_current_chat():
    """按 Esc 关闭当前打开的聊天对话框，回到主界面"""
    _send_key(win32con.VK_ESCAPE)
    time.sleep(0.2)
    _send_key(win32con.VK_ESCAPE)
    time.sleep(0.3)


def clear_search_box():
    """清空搜索框内容：Ctrl+A → Backspace"""
    activate_wechat()
    time.sleep(0.1)
    _ctrl_key(0x41)  # Ctrl+A
    time.sleep(0.15)
    _send_key(win32con.VK_BACK)  # Backspace
    time.sleep(0.15)


def verify_search_box(contact: str) -> bool:
    """
    通过 Ctrl+A → Ctrl+C 读取搜索框内容来验证当前搜索的联系人
    返回 True 表示验证通过
    """
    activate_wechat()
    time.sleep(0.2)
    _ctrl_key(0x41)  # Ctrl+A
    time.sleep(0.2)
    _ctrl_key(0x43)  # Ctrl+C
    time.sleep(0.3)

    content = get_clipboard_text()
    logger.info(f"搜索框内容: '{content[:100]}'")
    # 精确匹配：搜索框内容应该就是联系人名（或包含联系人名且长度接近）
    return contact == content.strip() or content.strip() == contact


# ─────────────── 核心发送逻辑 ───────────────

def send_message(contact: str, msg: str) -> str:
    """
    向微信指定联系人发送文本消息（带搜索框验证）
    返回: "ok" 或错误描述
    """
    try:
        if not activate_wechat():
            return "错误: 无法激活微信窗口"
        time.sleep(0.3)

        # 步骤 1: 关闭当前对话框，确保从主界面开始
        logger.info("关闭当前对话框...")
        close_current_chat()
        time.sleep(0.3)
        activate_wechat()

        # 步骤 2: Ctrl+F 打开搜索
        logger.info(f"搜索联系人: {contact}...")
        activate_wechat()
        _ctrl_key(0x46)  # Ctrl+F
        time.sleep(0.5)
        activate_wechat()

        # 步骤 3: 清空搜索框，确保从空白开始
        logger.info("清空搜索框...")
        clear_search_box()
        time.sleep(0.3)
        activate_wechat()

        # 步骤 4: 粘贴联系人名
        paste_text(contact)
        time.sleep(0.8)
        activate_wechat()
        time.sleep(0.3)

        # 步骤 5: 验证搜索框内容
        verified = False
        for attempt in range(3):
            logger.info(f"验证搜索框 [{attempt+1}/3]...")
            if verify_search_box(contact):
                verified = True
                break
            # 未通过：重新粘贴再试
            activate_wechat()
            time.sleep(0.3)
            clear_search_box()
            time.sleep(0.2)
            paste_text(contact)
            time.sleep(0.5)
            activate_wechat()

        if not verified:
            # 再试一次完整流程：关闭对话框重新搜索
            logger.warning("搜索框验证失败，重试完整搜索流程...")
            close_current_chat()
            time.sleep(0.3)
            activate_wechat()
            _ctrl_key(0x46)
            time.sleep(0.5)
            activate_wechat()
            clear_search_box()
            time.sleep(0.3)
            paste_text(contact)
            time.sleep(0.8)
            activate_wechat()
            time.sleep(0.3)

            for attempt in range(3):
                logger.info(f"重试验证 [{attempt+1}/3]...")
                if verify_search_box(contact):
                    verified = True
                    break
                activate_wechat()
                time.sleep(0.3)
                clear_search_box()
                time.sleep(0.2)
                paste_text(contact)
                time.sleep(0.5)
                activate_wechat()

        if not verified:
            return f"错误: 搜索框验证失败。搜索 '{contact}' 后搜索框内容不包含目标，可能未找到联系人"

        # 步骤 6: 验证通过，回车选择第一个结果
        logger.info(f"验证通过，选择 [{contact}]...")
        activate_wechat()
        _send_key(win32con.VK_RETURN)
        time.sleep(1.0)  # 等待对话框打开
        activate_wechat()
        time.sleep(0.3)

        # 步骤 7: 发送消息
        logger.info(f"发送消息到 [{contact}]...")
        activate_wechat()
        time.sleep(0.2)

        # 先清空聊天输入框（防止残留文本）
        _ctrl_key(0x41)  # Ctrl+A
        time.sleep(0.15)
        _send_key(win32con.VK_BACK)  # Backspace
        time.sleep(0.2)
        activate_wechat()
        time.sleep(0.2)

        # 粘贴消息
        paste_text(msg)
        time.sleep(0.5)
        activate_wechat()
        time.sleep(0.3)

        # 验证：读聊天输入框，确认消息内容正确
        _ctrl_key(0x41)  # Ctrl+A
        time.sleep(0.2)
        _ctrl_key(0x43)  # Ctrl+C
        time.sleep(0.3)
        input_content = get_clipboard_text()
        logger.info(f"聊天输入框内容: '{input_content[:100]}'")

        if msg not in input_content:
            logger.warning("消息未正确粘贴到输入框，重试...")
            activate_wechat()
            time.sleep(0.2)
            paste_text(msg)
            time.sleep(0.5)
            activate_wechat()
            time.sleep(0.3)
            _ctrl_key(0x41)
            time.sleep(0.2)
            _ctrl_key(0x43)
            time.sleep(0.3)
            input_content = get_clipboard_text()
            logger.info(f"重试后输入框内容: '{input_content[:100]}'")

        # 步骤 8: 回车发送
        _send_key(win32con.VK_RETURN)
        time.sleep(0.5)

        logger.info(f"消息已发送到 [{contact}]")
        return "ok"

    except Exception as e:
        logger.error(f"发送失败: {e}")
        traceback.print_exc()
        return f"发送失败: {e}"


# ─────────────── 文件发送逻辑 ───────────────

def _copy_files_to_clipboard(file_paths: list) -> bool:
    """
    用 PowerShell Set-Clipboard 将文件引用放入剪贴板（CF_HDROP 格式）
    微信 Ctrl+V 时会自动识别为文件发送
    """
    try:
        paths_arg = ','.join(f'"{p}"' for p in file_paths)
        ps_cmd = f'Set-Clipboard -Path {paths_arg}'
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_cmd],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            logger.error(f"Set-Clipboard 失败: {result.stderr}")
            return False
        logger.info(f"已将 {len(file_paths)} 个文件放入剪贴板")
        return True
    except Exception as e:
        logger.error(f"复制文件到剪贴板异常: {e}")
        return False


def send_file(contact: str, file_paths: list) -> str:
    """
    向微信指定联系人发送文件
    原理: Set-Clipboard -Path → 导航到联系人 → Ctrl+V → Enter
    
    参数:
        contact: 接收人名称，如 '文件传输助手'
        file_paths: 文件路径列表（绝对路径）
    """
    try:
        if not file_paths:
            return "错误: 未指定文件路径"

        # 检查文件是否存在
        for fp in file_paths:
            if not os.path.isfile(fp):
                return f"错误: 文件不存在: {fp}"
        
        logger.info(f"准备发送 {len(file_paths)} 个文件到 [{contact}]: {file_paths}")

        # ========== 导航到联系人（复用 send_message 的搜索逻辑） ==========
        if not activate_wechat():
            return "错误: 无法激活微信窗口"
        time.sleep(0.3)

        logger.info("关闭当前对话框...")
        close_current_chat()
        time.sleep(0.3)
        activate_wechat()

        logger.info(f"搜索联系人: {contact}...")
        activate_wechat()
        _ctrl_key(0x46)  # Ctrl+F
        time.sleep(0.5)
        activate_wechat()

        clear_search_box()
        time.sleep(0.3)
        activate_wechat()

        paste_text(contact)
        time.sleep(0.8)
        activate_wechat()
        time.sleep(0.3)

        # 验证搜索框
        verified = False
        for attempt in range(3):
            logger.info(f"验证搜索框 [{attempt+1}/3]...")
            if verify_search_box(contact):
                verified = True
                break
            activate_wechat()
            time.sleep(0.3)
            clear_search_box()
            time.sleep(0.2)
            paste_text(contact)
            time.sleep(0.5)
            activate_wechat()

        if not verified:
            return f"错误: 搜索 '{contact}' 验证失败，可能未找到联系人"

        # 回车打开聊天
        logger.info(f"验证通过，打开 [{contact}] 对话框...")
        activate_wechat()
        _send_key(win32con.VK_RETURN)
        time.sleep(1.0)
        activate_wechat()
        time.sleep(0.3)

        # ========== 粘贴文件并发送 ==========
        # 注意：之前 paste_text(contact) 覆盖了剪贴板，现在重新放入文件
        logger.info("将文件重新放入剪贴板...")
        if not _copy_files_to_clipboard(file_paths):
            return "错误: 无法将文件复制到剪贴板"

        time.sleep(0.3)

        # Ctrl+V 粘贴文件到聊天输入框
        logger.info("Ctrl+V 粘贴文件...")
        activate_wechat()
        time.sleep(0.2)
        _ctrl_key(0x56)  # Ctrl+V
        time.sleep(1.5)  # 等待文件渲染到输入框
        
        activate_wechat()
        time.sleep(0.3)

        # Enter 发送
        logger.info("Enter 发送文件...")
        _send_key(win32con.VK_RETURN)
        # 文件上传需要时间，大文件等更久
        wait_time = 2.0
        for fp in file_paths:
            size_mb = os.path.getsize(fp) / (1024 * 1024)
            if size_mb > 10:
                wait_time = max(wait_time, size_mb * 0.3)  # 每MB约0.3秒
        logger.info(f"等待文件上传 ({wait_time:.1f}s)...")
        time.sleep(wait_time)

        logger.info(f"文件已发送到 [{contact}]: {[os.path.basename(p) for p in file_paths]}")
        return "ok"

    except Exception as e:
        logger.error(f"发送文件失败: {e}")
        traceback.print_exc()
        return f"发送文件失败: {e}"


# ─────────────── MCP Server ───────────────

MCP_SERVER = Server("wechat-mcp")


@MCP_SERVER.list_tools()
async def list_tools():
    from mcp.types import Tool
    return [
        Tool(
            name="send_message",
            description="向微信好友/文件传输助手发送文本消息（自动验证聊天对象后再发送）",
            inputSchema={
                "type": "object",
                "properties": {
                    "contact": {
                        "type": "string",
                        "description": "接收人名称，如 '文件传输助手'、'张三'",
                    },
                    "message": {
                        "type": "string",
                        "description": "要发送的消息内容",
                    },
                },
                "required": ["contact", "message"],
            },
        ),
        Tool(
            name="send_file",
            description="向微信好友/文件传输助手发送文件。原理：将文件路径写入剪贴板(CF_HDROP)，然后 Ctrl+V 粘贴发送。支持单文件或多文件。",
            inputSchema={
                "type": "object",
                "properties": {
                    "contact": {
                        "type": "string",
                        "description": "接收人名称，如 '文件传输助手'、'张三'",
                    },
                    "file_paths": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "要发送的文件路径列表（绝对路径），如 ['C:/Users/xxx/report.pdf']",
                    },
                },
                "required": ["contact", "file_paths"],
            },
        ),
    ]


@MCP_SERVER.call_tool()
async def call_tool(name: str, arguments: dict):
    from mcp.types import CallToolResult, TextContent

    if name == "send_message":
        contact = arguments.get("contact", "")
        message = arguments.get("message", "")
        if not contact or not message:
            return CallToolResult(
                content=[TextContent(type="text", text='{"status": "error", "message": "参数错误: 需要 contact 和 message"}')],
                isError=True,
            )
        result = send_message(contact, message)
        status = "success" if result == "ok" else "error"
        return CallToolResult(
            content=[TextContent(type="text", text=json.dumps({"status": status, "message": result}, ensure_ascii=False))],
            isError=(result != "ok"),
        )

    if name == "send_file":
        contact = arguments.get("contact", "")
        file_paths = arguments.get("file_paths", [])
        if not contact or not file_paths:
            return CallToolResult(
                content=[TextContent(type="text", text='{"status": "error", "message": "参数错误: 需要 contact 和 file_paths"}')],
                isError=True,
            )
        result = send_file(contact, file_paths)
        status = "success" if result == "ok" else "error"
        return CallToolResult(
            content=[TextContent(type="text", text=json.dumps({"status": status, "message": result}, ensure_ascii=False))],
            isError=(result != "ok"),
        )

    return CallToolResult(
        content=[TextContent(type="text", text=f'未知工具: {name}')],
        isError=True,
    )


@MCP_SERVER.list_prompts()
async def list_prompts():
    return []


async def main():
    async with stdio_server() as (read_stream, write_stream):
        logger.info("WeChat MCP Server (v4 - 文本+文件发送) 启动 - stdio 模式")
        await MCP_SERVER.run(
            read_stream,
            write_stream,
            MCP_SERVER.create_initialization_options(),
        )


def main_sync():
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("服务器已停止")
    except Exception as e:
        logger.error(f"服务器错误: {e}")
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main_sync()
