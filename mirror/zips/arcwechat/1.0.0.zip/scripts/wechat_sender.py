# -*- coding: utf-8 -*-
"""
WeChat 4.0 键盘模拟发送消息工具
绕过 wxauto4 的 UIA 兼容性问题，使用 Win32 API + 键盘模拟直接操作微信
"""

import time
import sys
import ctypes
import ctypes.wintypes
import win32gui
import win32con
import win32api
import win32clipboard

# WeChat 主窗口信息
WECHAT_HANDLE = 68440
WECHAT_TITLE = '微信'

user32 = ctypes.windll.user32

# 设置 stdout 编码避免 UnicodeEncodeError
if sys.stdout.encoding is None or sys.stdout.encoding.upper() not in ('UTF-8', 'UTF8'):
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')


def activate_wechat() -> bool:
    """激活微信窗口到前台"""
    if not win32gui.IsWindow(WECHAT_HANDLE):
        return False
    
    # 使用 SwitchToThisWindow 更可靠
    user32.SwitchToThisWindow(WECHAT_HANDLE, True)
    time.sleep(0.2)
    
    # 如果窗口最小化，恢复
    if win32gui.IsIconic(WECHAT_HANDLE):
        win32gui.ShowWindow(WECHAT_HANDLE, win32con.SW_RESTORE)
        time.sleep(0.2)
    
    return True


def send_key(vk_code: int):
    """发送一个按键（按下+释放）"""
    win32api.keybd_event(vk_code, 0, 0, 0)
    time.sleep(0.03)
    win32api.keybd_event(vk_code, 0, win32con.KEYEVENTF_KEYUP, 0)
    time.sleep(0.03)


def send_ctrl_key(vk_code: int):
    """发送 Ctrl+Key 组合键"""
    win32api.keybd_event(win32con.VK_CONTROL, 0, 0, 0)
    time.sleep(0.03)
    win32api.keybd_event(vk_code, 0, 0, 0)
    time.sleep(0.04)
    win32api.keybd_event(vk_code, 0, win32con.KEYEVENTF_KEYUP, 0)
    time.sleep(0.03)
    win32api.keybd_event(win32con.VK_CONTROL, 0, win32con.KEYEVENTF_KEYUP, 0)
    time.sleep(0.05)


def paste_text(text: str):
    """通过剪贴板粘贴 Unicode 文本"""
    # 保存原内容
    old = None
    has_old = False
    try:
        win32clipboard.OpenClipboard()
        try:
            old = win32clipboard.GetClipboardData(win32con.CF_UNICODETEXT)
            has_old = True
        except:
            pass
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardText(text, win32con.CF_UNICODETEXT)
        win32clipboard.CloseClipboard()
    except Exception as e:
        win32clipboard.CloseClipboard()
        raise e

    # Ctrl+V
    send_ctrl_key(0x56)
    time.sleep(0.15)

    # 恢复
    try:
        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        if has_old and old:
            win32clipboard.SetClipboardText(old, win32con.CF_UNICODETEXT)
        win32clipboard.CloseClipboard()
    except:
        pass


def send_to_wechat(contact: str, message: str) -> bool:
    """
    向微信指定联系人发送消息
    使用键盘快捷键模拟操作流程
    """
    print(f"[1/6] 定位微信窗口...", flush=True)
    if not win32gui.IsWindow(WECHAT_HANDLE):
        print("ERROR: 微信窗口句柄失效", flush=True)
        return False

    print("[2/6] 激活微信窗口到前台...", flush=True)
    if not activate_wechat():
        print("WARN: 窗口激活可能失败，继续尝试...", flush=True)
    time.sleep(0.3)

    print(f"[3/6] Ctrl+F 搜索: {contact}...", flush=True)
    send_ctrl_key(0x46)  # Ctrl+F
    time.sleep(0.3)

    paste_text(contact)
    time.sleep(0.5)

    print("[4/6] Enter 选择联系人...", flush=True)
    send_key(win32con.VK_RETURN)
    time.sleep(0.5)

    print(f"[5/6] 粘贴消息...", flush=True)
    paste_text(message)
    time.sleep(0.2)

    print("[6/6] Enter 发送...", flush=True)
    send_key(win32con.VK_RETURN)
    time.sleep(0.3)

    print("DONE! 消息已发送。", flush=True)
    return True


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("用法: python wechat_sender.py <联系人> <消息>", flush=True)
        print("示例: python wechat_sender.py '文件传输助手' '你好，这是一条测试'", flush=True)
        sys.exit(1)

    contact = sys.argv[1]
    message = sys.argv[2]
    print(f"发送到 [{contact}]: {message}", flush=True)
    success = send_to_wechat(contact, message)
    sys.exit(0 if success else 1)
