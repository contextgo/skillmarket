---
name: tencentads-advertiser
description: "腾讯广告广告主信息查询技能。用于查询当前有权限管理的广告主账号信息列表，支持按公司主体名称模糊匹配和分页查询。当用户需要查找广告主账号、查询广告主列表、按公司名搜索账号时使用本技能。"
version: "0.5.0"
license: MIT. See LICENSE for full terms.
compatibility: any
metadata:
  author: Tencent Ads Delivery Team
  version: "0.5.0"
  icon: users
  category: tencent-ads
---

# 腾讯广告 - 客户账号查询技能

> **前置依赖**：运行脚本前需安装 CLI — `npm install tencentads-cli`（需要 Node.js ≥ 20）

本技能用于查询当前登录用户（user_id）关联的广告主账号信息列表。通过调用 `user_account_list/get` 接口，可以获取用户下所有广告主账户的基本信息，支持按公司名称模糊匹配和分页查询。

> **脚本调用格式统一**：`node scripts/<脚本名>.mjs '<JSON 参数>'`
> 执行脚本时先进入本 skill 根目录，再按相对 `scripts/` 路径调用。

### ⚠️ 跨平台 JSON 参数传递规则（经实测验证）

脚本调用格式为 `node scripts/<脚本名>.mjs '<JSON参数>'`，但 **JSON 参数的引号包裹方式因操作系统/终端而异**，传递不当会导致 `JSON.parse` 报错（如 `Expected property name or '}' in JSON at position 1`）。

| 终端环境 | 正确写法 | 说明 |
|---------|---------|------|
| **Linux / macOS (Bash/Zsh)** | `node scripts/xxx.mjs '{"key":"value"}'` | ✅ 单引号包裹，内部双引号原样保留 |
| **Windows Git Bash** | `node scripts/xxx.mjs '{"key":"value"}'` | ✅ 同 Bash |
| **Windows CMD** | `node scripts/xxx.mjs "{\"key\":\"value\"}"` | ✅ 双引号包裹 + 反斜杠转义 |
| **Windows CMD (备选)** | `node scripts/xxx.mjs "{""key"":""value""}"` | ✅ 双引号包裹 + 双双引号转义 |
| **Windows PowerShell 5.x** | `node --% scripts/xxx.mjs "{\"key\":\"value\"}"` | ✅ 必须加 `--%` 停止解析符 |
| **Windows PowerShell 5.x (备选)** | `` node scripts/xxx.mjs "{\`"key\`":\`"value\`"}" `` | ✅ 反斜杠 + 反引号组合转义 |

> **⛔ PowerShell 5.x 是重灾区**：单引号 `'...'`、反引号 `` `" `` 、反斜杠 `\"` 三种常见写法**全部失败**（双引号会被吞掉）。必须使用 `--% ` 停止解析符或 `` \`" `` 组合转义。
> **⛔ Windows CMD 不支持单引号包裹字符串**，单引号会被当作普通字符传入脚本，导致 JSON 解析失败。

---

## 适用场景

- 查询当前用户下所有关联的广告主账号
- 按公司名称模糊搜索广告主账号
- 获取广告主账号的基本信息（账号ID、公司简称、公司全称）
- 分页浏览大量关联账号

---

## 脚本：get-account-list.mjs

### 功能说明

调用 `user_account_list/get` 接口，获取当前 user_id 下关联的广告主账户信息列表。

### 调用方式

```bash
node scripts/get-account-list.mjs '<JSON 参数>'
```

**所有参数均为可选**，不传参数时返回第一页（默认 page=1, page_size=10）的全部关联账号。

### 参数说明

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `corporation_name_fuzzy_list` | string[] | 否 | - | 公司名称模糊匹配列表，最多 2 个字符串，每个字符串长度 2~50。示例：`["北京腾讯科技有限公司"]` |
| `page` | integer | 否 | 1 | 页码，从 1 开始 |
| `page_size` | integer | 否 | 10 | 每页数量，范围 1~500 |

### 调用示例

#### 示例 1：查询全部关联账号（默认分页）

```bash
node scripts/get-account-list.mjs
```

#### 示例 2：按公司名称模糊搜索

```bash
node scripts/get-account-list.mjs '{"corporation_name_fuzzy_list":["广州","西安"]}'
```

#### 示例 3：指定分页参数

```bash
node scripts/get-account-list.mjs '{"page":2,"page_size":20}'
```

#### 示例 4：模糊搜索 + 分页

```bash
node scripts/get-account-list.mjs '{"corporation_name_fuzzy_list":["腾讯"],"page":1,"page_size":50}'
```

### 返回格式

```json
{
  "list": [
    {
      "account_id": 770592,
      "account_type": 1,
      "nick_name": "广州高露洁棕榄有限公司",
      "corporation_name": "广州高露洁棕榄有限公司"
    },
    {
      "account_id": 915225,
      "nick_name": "腾讯",
      "account_type": 1,
      "corporation_name": "广州蛋壳网络科技有限公司"
    }
  ],
  "page_info": {
    "total_number": 38,
    "total_page": 4,
    "page": 1,
    "page_size": 10
  }
}
```

### 返回字段说明

#### list 数组中每个元素

| 字段 | 类型 | 说明 |
|------|------|------|
| `account_id` | integer | 广告主账户 ID |
| `account_type` | integer | 账户类型（固定返回 1，表示广告主） |
| `nick_name` | string | 公司简称 |
| `corporation_name` | string | 公司全称 |

#### page_info 分页信息

| 字段 | 类型 | 说明 |
|------|------|------|
| `total_number` | integer | 总记录数 |
| `total_page` | integer | 总页数 |
| `page` | integer | 当前页码 |
| `page_size` | integer | 每页数量 |

---

## 使用流程

### 场景 A：用户需要查找某个公司的广告主账号

1. 从用户描述中提取公司名称关键词
2. 调用 `get-account-list.mjs`，传入 `corporation_name_fuzzy_list`
3. 将匹配到的账号列表展示给用户

### 场景 B：用户需要浏览所有关联账号

1. 调用 `get-account-list.mjs`（不传参数或仅传分页参数）
2. 展示第一页结果和分页信息
3. 如果有多页，告知用户总数并询问是否需要查看更多

### 场景 C：配合其他技能使用

当其他 `tencentads-*` 技能需要 `account_id` 但用户未提供时，可先调用本技能获取账号列表，让用户选择目标账号后再继续执行。

---

## 注意事项

1. **无需传入 account_id**：本接口基于当前登录用户的 user_id 查询，不需要指定广告主账号
2. **模糊匹配限制**：`corporation_name_fuzzy_list` 最多传 2 个字符串，每个字符串长度限制 2~50 个字符
3. **分页默认值**：不传 `page` 默认为 1，不传 `page_size` 默认为 10
4. **认证依赖**：本技能依赖 `tencentads-auth` 技能配置的 API Key 凭据，如遇认证错误请先完成鉴权

## 错误处理

- 如果返回认证错误，引导用户使用 `tencentads-auth` 技能重新配置 API Key
- 如果 `corporation_name_fuzzy_list` 参数不合法（超过 2 个、字符串长度不在 2~50 范围），脚本会返回明确的错误提示
- 如果查询结果为空，告知用户未找到匹配的账号，建议调整搜索关键词或检查是否有关联账号
