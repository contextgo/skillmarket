---
name: huaweicloud-global-search
description: Query Huawei Cloud (华为云) product information, documentation, parameters, features, and pricing from official sources without login. Use when the user asks about Huawei Cloud products (ECS, OBS, RDS, CCE, etc.), needs product documentation, wants to compare product specifications, or needs help finding specific product parameters and features.
---

# 华为云产品查询 (Huawei Cloud Product Query)

This skill helps users find detailed information about Huawei Cloud products by searching official documentation and product pages without requiring login.

本技能帮助用户通过搜索官方文档和产品页面，无需登录即可获取华为云产品的详细信息。

## When to Use / 使用场景

- User asks about specific Huawei Cloud products (ECS, OBS, RDS, CCE, etc.) / 用户询问特定的华为云产品（ECS、OBS、RDS、CCE等）
- User needs product documentation or API references / 用户需要产品文档或API参考
- User wants to compare product specifications or pricing / 用户想要比较产品规格或价格
- User needs help finding specific product parameters or features / 用户需要帮助查找特定的产品参数或功能
- User mentions "Huawei Cloud", "华为云", or "HWC" and needs product information / 用户提到"华为云"并需要产品信息

---

## Step 1: Identify the Product (识别产品)

从全面的产品目录中确定用户询问的是哪个华为云产品：

### 1.1 识别用户查询中的产品关键词 / Identify Product Keywords from User Query

分析用户问题，提取以下信息 / Analyze user questions and extract the following information:
- **产品名称 (Product Name)**: 用户提到的具体产品名（如 ECS、OBS、RDS）/ Specific product names mentioned by the user (e.g., ECS, OBS, RDS)
- **产品类别 (Product Category)**: 用户可能提到的产品类别（如计算、数据库、存储）/ Product categories mentioned (e.g., Compute, Database, Storage)
- **功能需求 (Functional Requirements)**: 用户想要实现的功能（如搭建网站、数据备份、负载均衡）/ Functions the user wants to implement (e.g., build websites, data backup, load balancing)
- **使用场景 (Use Cases)**: 用户的业务场景（如电商、游戏、金融）/ User's business scenarios (e.g., e-commerce, gaming, finance)

### 1.2 使用产品别名对照表 / Product Alias Reference Table

如果用户使用非标准名称，参考以下别名映射 / If users use non-standard names, refer to the following alias mapping:

| 用户可能说的 (User May Say) | 对应产品 (Product) | 英文名 (English Name) |
|---------------------------|-------------------|----------------------|
| 云服务器、虚拟机、VM、云主机 (Cloud Server, VM, Cloud Host) | 弹性云服务器 ECS | Elastic Cloud Server |
| 对象存储、云盘、云存储 (Object Storage, Cloud Disk) | 对象存储服务 OBS | Object Storage Service |
| 云硬盘、块存储 (Cloud Disk, Block Storage) | 云硬盘 EVS | Elastic Volume Service |
| 文件存储、NAS (File Storage, NAS) | 弹性文件服务 SFS | Scalable File Service |
| 负载均衡、ELB (Load Balancer) | 弹性负载均衡 ELB | Elastic Load Balance |
| 数据库、MySQL、PostgreSQL (Database) | 云数据库 RDS / GaussDB | Relational Database Service |
| Redis、缓存 (Redis, Cache) | 云数据库 GeminiDB | GeminiDB (Redis Compatible) |
| 大模型、盘古、Pangu (Large Model) | 盘古大模型 | Pangu LLM |
| AI平台、机器学习 (AI Platform) | 魔坊 ModelArts | ModelArts |
| 容器、K8s、Kubernetes (Container, K8s) | 云容器引擎 CCE | Cloud Container Engine |
| 函数计算、Serverless (Function Compute) | 函数工作流 FunctionGraph | FunctionGraph |
| 安全中心 (Security Center) | 企业主机安全 HSS | Host Security Service |
| WAF、防火墙 (Firewall) | Web应用防火墙 WAF | Web Application Firewall |
| CDN、加速 (CDN, Acceleration) | 内容分发网络 CDN | Content Delivery Network |
| VPC、私有网络 (VPC, Private Network) | 虚拟私有云 VPC | Virtual Private Cloud |
| 大数据、数仓 (Big Data, Data Warehouse) | MapReduce服务 MRS | MapReduce Service |
| 消息队列、Kafka (Message Queue) | 分布式消息服务 DMS | Distributed Message Service |

### 1.3 确定目标产品 / Identify Target Product

从产品目录中找到最匹配的产品，记录 / Find the best matching product from the catalog and record:
- **产品中文名 (Chinese Name)**: 产品的中文名称
- **产品英文名 (English Name)**: 产品的英文名称
- **产品类别 (Category)**: 产品所属类别
- **产品代码 (Product Code)**: 用于构造URL的产品代码

---

## 📦 华为云全产品目录 (Huawei Cloud Full Product Catalog)

### 🤖 一、人工智能 (Artificial Intelligence)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 魔坊 ModelArts | ModelArts | 面向AI开发者的一站式开发平台 / One-stop AI development platform |
| MaaS模型即服务 | Model as a Service | 极致性能，易用好用的Tokens服务 / High-performance token service |
| 盘古大模型 NLP | Pangu LLM | 多专家+大稀疏比的MOE新架构 / MOE architecture large language model |
| 盘古多模态大模型 | Pangu Multimodal | 图像理解、图像生成、视频生成 / Image understanding and generation |
| 盘古视觉大模型 | Pangu CV | 支持多行业图像数据合成 / Visual model for image synthesis |
| 盘古预测大模型 | Pangu Predict | 虚拟测量、预测性维护、工艺优化 / Prediction model for industry |
| 盘古气象大模型 | Pangu Meteorology | 降水量预测、风电预测、光伏预测 / Weather prediction model |
| 智能体平台 AgentArts | AgentArts | 高效敏捷安全的一站式企业级智能体平台 / Enterprise agent platform |

---

### 🖥️ 二、计算 (Compute)

#### 弹性计算 (Elastic Compute)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 弹性云服务器 ECS | Elastic Cloud Server | 可随时自动获取、弹性伸缩的云服务器 / Elastic cloud server with auto-scaling |
| GPU加速云服务器 GACS | GPU Accelerated Cloud Server | 提供GPU计算资源的弹性云服务器 / GPU-powered cloud server |
| FPGA加速云服务器 FACS | FPGA Accelerated Cloud Server | 提供FPGA计算资源的弹性云服务器 / FPGA-powered cloud server |
| 裸金属服务器 BMS | Bare Metal Server | 高性能、高安全的云上物理服务器 / High-performance bare metal server |
| 弹性伸缩 AS | Auto Scaling | 根据预设策略自动调整计算资源 / Auto-scaling service |
| 云手机服务 KooPhone | KooPhone | 优体验、高安全的政企云手机服务 / Cloud phone service |

#### 边缘计算 (Edge Computing)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| CloudPond | CloudPond | 将云基础设施部署到机房用于边缘计算 / Edge computing infrastructure |
| 边缘安全 EdgeSec | EdgeSec | 保护边缘应用安全，提升安全加速体验 / Edge security service |

---

### 💾 三、存储 (Storage)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 对象存储服务 OBS | Object Storage Service | 稳定、安全、高效、易用的云存储服务 / Stable and secure object storage |
| Flexus对象存储 | Flexus Object Storage | 成本最优，极致安全可靠的数据底座 / Cost-effective object storage |
| 云硬盘 EVS | Elastic Volume Service | 为计算服务提供持久性块存储 / Block storage for compute |
| 键值存储服务 KVS | Key-Value Service | Serverless KV存储服务 / Serverless key-value storage |
| 弹性文件服务 SFS | Scalable File Service | 为计算实例提供完全托管的NAS文件存储 / Managed NAS file storage |
| 专属分布式存储服务 DSS | Dedicated Distributed Storage | 提供独享的物理存储资源 / Dedicated physical storage |
| 云存储网关 CSG | Cloud Storage Gateway | 为企业应用提供标准的文件存储访问入口 / Storage gateway |
| 弹性内存存储 EMS | Elastic Memory Storage | 高带宽、低时延的内存存储服务 / In-memory storage service |
| 对象存储迁移服务 OMS | Object Storage Migration | 公有云对象存储数据迁移服务 / Object storage migration |

---

### 🗄️ 四、数据库 (Database)

#### 关系型数据库 (Relational Database)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 云数据库 GaussDB | GaussDB | 新一代企业级分布式关系型数据库 / Enterprise distributed database |
| 云数据库 TaurusDB | TaurusDB | 新一代完全兼容MySQL的企业级数据库 / MySQL-compatible enterprise database |
| 云数据库 RDS for MySQL | RDS for MySQL | 稳定可靠、安全运行、弹性伸缩 / Reliable and scalable MySQL |
| 云数据库 RDS for PostgreSQL | RDS for PostgreSQL | 开源数据库，保证数据的可靠性和完整性 / PostgreSQL database |
| 云数据库 RDS for SQLServer | RDS for SQLServer | 广受欢迎的商用关系型数据库 / SQL Server database |
| 云数据库 RDS for MariaDB | RDS for MariaDB | 开源数据库、即开即用、稳定可靠 / MariaDB database |
| Flexus云数据库RDS | Flexus RDS | 基于开源MySQL内核的轻量级数据库 / Lightweight MySQL database |

#### 非关系型数据库 (NoSQL Database)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 云数据库 GeminiDB | GeminiDB | 云原生多模数据库，兼容主流NoSQL协议 / Cloud-native multi-model database |
| 文档数据库服务 DDS | Document Database Service | 支持集群和副本集部署，弹性伸缩 / MongoDB-compatible document database |
| 表格存储服务 CloudTable | CloudTable | 企业级托管型云数仓产品 / Managed data warehouse |

#### 数据库生态工具 (Database Tools)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 数据复制服务 DRS | Data Replication Service | 业务不停机中完成数据库迁移上云 / Database migration service |
| 数据管理服务 DAS | Data Admin Service | 数据库管理专家 / Database management expert |
| 数据库和应用迁移 UGO | Database and Application Migration | 异构数据库结构和应用迁移的专业工具 / Database migration tool |
| 分布式数据库中间件 DDM | Distributed Database Middleware | 突破容量和性能瓶颈，支持高并发访问 / Database middleware |
| 数据库安全服务 DBSS | Database Security Service | 数据库审计，SQL注入攻击检测 / Database security audit |

---

### 🐳 五、容器与中间件 (Container & Middleware)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 云容器引擎 CCE | Cloud Container Engine | 提供高可靠的企业级容器应用管理服务 / Enterprise Kubernetes service |
| 云容器实例 CCI | Cloud Container Instance | 提供敏捷安全的Serverless容器服务 / Serverless container service |
| Flexus云容器实例 | Flexus Container Instance | 开箱即用的轻量级容器产品 / Lightweight container product |
| 容器镜像服务 SWR | SoftWare Repository | 支持容器镜像全生命周期管理 / Container registry service |
| 分布式消息服务 DMS | Distributed Message Service | 分布式消息队列服务 / Message queue service |
| 函数工作流 FunctionGraph | FunctionGraph | 事件驱动的无服务器函数托管计算平台 / Serverless function platform |
| 微服务引擎 CSE | Cloud Service Engine | 微服务治理和托管平台 / Microservices governance platform |
| 应用编排服务 AOS | Application Orchestration Service | 应用自动化编排和部署 / Application orchestration |

---

### 🌐 六、网络 (Networking)

#### 云上网络 (Cloud Networking)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 虚拟私有云 VPC | Virtual Private Cloud | 隔离的、私密的虚拟网络环境 / Isolated virtual network |
| 弹性负载均衡 ELB | Elastic Load Balance | 自动分配访问流量的负载均衡服务 / Load balancing service |
| NAT网关 NAT | NAT Gateway | 提供网络地址转换服务 / Network address translation |
| 虚拟专用网络 VPN | Virtual Private Network | 数据中心与华为云的IPsec加密连接通道 / VPN connection |
| 云连接 CC | Cloud Connect | 跨区域互联服务 / Cross-region interconnection |
| 企业路由器 ER | Enterprise Router | 企业级路由服务 / Enterprise routing service |

#### CDN与加速 (CDN & Acceleration)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 内容分发网络 CDN | Content Delivery Network | 就近获得所需内容，改善网络拥挤状况 / Content delivery acceleration |
| 全站加速 WSA | Whole Site Acceleration | 提升网络传输的性能、稳定性和访问体验 / Whole site acceleration |
| 全球加速 GA | Global Accelerator | 全球网络加速服务 / Global network acceleration |

---

### 🔒 七、安全 (Security)

#### 网络安全 (Network Security)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| Web应用防火墙 WAF | Web Application Firewall | 保护Web应用免受常见Web攻击 / Web application firewall |
| 云防火墙 CFW | Cloud Firewall | 网络流量管控与入侵安全防护 / Cloud firewall |
| DDoS防护 AAD | Anti-DDoS | 快速缓解对业务造成瘫痪的网络攻击 / DDoS protection |
| 边缘安全 EdgeSec | Edge Security | 保护边缘应用安全，提升安全加速体验 / Edge security |

#### 主机与数据安全 (Host & Data Security)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 企业主机安全 HSS | Host Security Service | 服务器贴身安全管家 / Host security protection |
| 数据安全中心 DSC | Data Security Center | 云原生数据安全治理平台 / Data security governance |
| 密码安全中心 DEW | Data Encryption Workshop | 云上数据加密和密钥托管服务 / Encryption and key management |
| 数据库安全服务 DBSS | Database Security Service | 数据库审计，SQL注入攻击检测 / Database security |
| 交换数据空间 EDS | Exchange Data Space | 主权可控的数据安全交换服务 / Secure data exchange |

#### 安全运营 (Security Operations)
| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 安全云脑 SecMaster | SecMaster | 云原生的新一代智能安全运营中心 / Security operations center |
| 威胁检测服务 MTD | Managed Threat Detection | 托管威胁检测服务 / Threat detection |
| 漏洞管理服务 CodeArts Inspector | CodeArts Inspector | 满足合规要求，让安全弱点无所遁形 / Vulnerability management |

---

### 📊 八、大数据 (Big Data)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| MapReduce服务 MRS | MapReduce Service | 企业级大数据集群云服务 / Enterprise big data cluster |
| 实时流计算服务 CS | CloudStream | 实时大数据分析平台 / Real-time stream processing |
| 数智融合计算服务 DataArts Fabric | DataArts Fabric | 提供一站式数据+AI开发平台 / Data and AI development platform |
| 数据治理中心 DataArts Studio | DataArts Studio | 一站式数据治理与开发平台 / Data governance platform |
| 云搜索服务 CSS | Cloud Search Service | 基于Elasticsearch的全文搜索服务 / Search service |
| 表格存储服务 CloudTable | CloudTable | 企业级托管型云数仓产品 / Data warehouse |

---

### 🎬 九、视频与通信 (Video & Communication)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 视频直播 Live | Live | 提供高清流畅、超低延时的直播服务 / Live streaming service |
| 视频点播 VOD | Video on Demand | 提供视频上传、存储、转码、播放等服务 / Video on demand |
| 实时音视频 RTC | Real-Time Communication | 提供实时音视频通信能力 / Real-time communication |
| 云会议 Meeting | Meeting | 高清、稳定、安全的云会议服务 / Cloud meeting service |
| Flexus云会议 | Flexus Meeting | 高性价比的云会议，高清、稳定、安全 / Cost-effective cloud meeting |

---

### 🔧 十、开发与运维 (Development & Operations)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 软件开发生产线 CodeArts | CodeArts | 一站式DevOps平台 / One-stop DevOps platform |
| 制品仓库 CodeArts Artifact | CodeArts Artifact | 提供多类型、安全可靠的软件制品仓库 / Artifact repository |
| 漏洞管理服务 CodeArts Inspector | CodeArts Inspector | 满足合规要求，让安全弱点无所遁形 / Vulnerability management |
| 开源治理服务 CodeArts Governance | CodeArts Governance | 识别开源软件风险，高效安全的使用开源 / Open source governance |
| 云运维中心 COC | Cloud Operations Center | 提供安全、高效的一站式智能运维平台 / Cloud operations center |
| 云日志服务 LTS | Log Tank Service | 提供日志收集、实时查询、存储等功能 / Log management service |
| 云监控服务 CES | Cloud Eye Service | 提供云资源监控和告警服务 / Cloud monitoring service |

---

### 🔐 十一、管理与治理 (Management & Governance)

| 产品名称 (Product Name) | 英文名 (English Name) | 描述 (Description) |
|------------------------|----------------------|-------------------|
| 统一身份认证服务 IAM | Identity and Access Management | 提供身份认证和权限管理 / Identity and access management |
| 资源访问管理 RAM | Resource Access Management | 提供安全的跨账号共享资源的能力 / Cross-account resource sharing |
| 资源治理中心 RGC | Resource Governance Center | 搭建并治理安全可扩展的多账号环境 / Resource governance |
| 云审计服务 CTS | Cloud Trace Service | 提供云资源操作记录和审计 / Cloud audit service |
| 标签管理服务 TMS | Tag Management Service | 云资源标签管理 / Tag management |

---

## Step 2: Search for Product Information (搜索产品信息)

### 2.1 构建搜索查询 / Construct Search Queries

根据目标产品，使用以下搜索模板查找官方信息：

**产品首页搜索 / Product Homepage Search**:
```
site:huaweicloud.com [product-name] 产品首页
site:huaweicloud.com/product [product-code]
```

**文档搜索 / Documentation Search**:
```
site:huaweicloud.com/document [product-name] 产品简介
site:huaweicloud.com/document [product-name] 快速入门
site:huaweicloud.com/api [product-name] API参考
```

**定价搜索 / Pricing Search**:
```
site:huaweicloud.com [product-name] 定价
site:huaweicloud.com/pricing [product-code]
```

**最佳实践搜索 / Best Practices Search**:
```
site:huaweicloud.com/document [product-name] 最佳实践
site:huaweicloud.com [product-name] 使用场景
```

### 2.2 执行搜索 / Execute Search

使用 `WebSearch` 工具执行上述查询，获取官方文档和产品页面的URL。

---

## Step 3: Retrieve and Extract Information (获取并提取信息)

### 3.1 获取产品首页信息 / Retrieve Product Homepage Info

访问产品首页获取核心信息：
- **官方URL格式**: `https://www.huaweicloud.com/product/[product-code].html`
- 使用 `Browser Navigate` 或 `WebFetch` 访问页面

**提取信息 / Information to Extract**:
1. **产品标语 (Tagline)**: 一句话价值主张
2. **核心功能 (Core Features)**: 主要能力列表
3. **应用场景 (Use Cases)**: 典型应用案例
4. **产品优势 (Advantages)**: 差异化优势
5. **架构图 (Architecture)**: 技术架构概述

### 3.2 获取技术文档 / Retrieve Technical Documentation

**文档URL格式 / Documentation URL Format**:
- 产品简介: `https://support.huaweicloud.com/productdesc-[product-code]/`
- 用户指南: `https://support.huaweicloud.com/usermanual-[product-code]/`
- API参考: `https://support.huaweicloud.com/api-[product-code]/`
- 定价说明: `https://support.huaweicloud.com/price-[product-code]/`

**常见产品代码 / Common Product Codes**:
| 产品 | 代码 |
|------|------|
| 弹性云服务器 ECS | ecs |
| 对象存储服务 OBS | obs |
| 云数据库 RDS | rds |
| 云容器引擎 CCE | cce |
| 虚拟私有云 VPC | vpc |
| 内容分发网络 CDN | cdn |
| 弹性负载均衡 ELB | elb |

### 3.3 提取关键参数 / Extract Key Parameters

从产品文档中提取：
- **规格参数 (Specifications)**: 实例类型、性能指标、资源限制
- **定价信息 (Pricing)**: 计费模式、单价、免费额度
- **技术参数 (Technical Parameters)**: 配置选项、支持协议
- **限制说明 (Limits)**: 配额限制、使用限制

---

## Step 4: Integrate and Present Results (整合并呈现结果)

### 4.1 信息整合规则 / Information Integration Rules

1. **优先级 / Priority**:
   - 官方文档 > 产品首页 > 第三方来源
   - 最新版本 > 旧版本

2. **冲突处理 / Conflict Resolution**:
   - 以官方文档为准
   - 标注信息来源和时间

3. **完整性检查 / Completeness Check**:
   - 确保所有关键信息已填充
   - 缺失信息标注为"[未在公开资料中找到]"

### 4.2 输出模板 / Output Template

```markdown
# [产品中文名] | [Product English Name]

## 产品概述 (Product Overview)

**产品标语 (Tagline)**: [一句话描述]

**产品描述 (Description)**:
[中文描述]

[English Description]

**核心功能 (Core Features)**:
- [功能1] | [Feature 1]
- [功能2] | [Feature 2]
- ...

**应用场景 (Use Cases)**:
1. [场景1] | [Use Case 1]
2. [场景2] | [Use Case 2]
- ...

---

## 产品规格 (Specifications)

### 实例类型 / Instance Types
| 类型 (Type) | 规格 (Spec) | 适用场景 (Use Case) |
|------------|------------|-------------------|
| [类型1] | [规格1] | [场景1] |

### 支持地域 / Supported Regions
- [地域1] | [Region 1]
- [地域2] | [Region 2]

---

## 定价信息 (Pricing)

### 计费模式 / Billing Models
- **按需计费 (Pay-per-use)**: [描述]
- **包年/包月 (Subscription)**: [描述]

### 价格详情 / Price Details
| 资源类型 | 规格 | 价格 |
|---------|------|------|
| [资源] | [规格] | [价格] |

### 免费额度 / Free Tier
[免费额度说明]

---

## 快速入门 (Quick Start)

### 前提条件 (Prerequisites)
- [条件1] | [Requirement 1]
- [条件2] | [Requirement 2]

### 入门步骤 (Getting Started)
1. [步骤1] | [Step 1]
2. [步骤2] | [Step 2]

---

## 开发参考 (Development Reference)

### API 概览 / API Overview
**服务端点 / Service Endpoint**: `https://[service].[region].myhuaweicloud.com`

### SDK 支持 / SDK Support
- **Java**: [Maven依赖]
- **Python**: [pip安装]
- **Go**: [go get]

### 代码示例 / Code Example
```python
# 示例代码
from huaweicloudsdkcore.auth.credentials import BasicCredentials

credentials = BasicCredentials(
    ak='<your-access-key-id>',
    sk='<your-secret-key-secret>'
)
```

---

## 相关资源 (Related Resources)

### 文档链接 / Documentation Links
- [产品文档](https://support.huaweicloud.com/[product-code]/)
- [API参考](https://support.huaweicloud.com/api-[product-code]/)

### 相关产品 / Related Products
- [产品1] - [描述]
- [产品2] - [描述]
```

---

## Important Notes (重要说明)

### 信息准确性 / Information Accuracy
- 所有信息来源于华为云官方公开文档
- 定价和规格可能变动，请以官网为准
- 部分详细参数可能需要登录后查看

### 工具限制 / Tool Limitations
- `WebFetch` 可能对部分动态页面返回错误
- 建议使用 `WebSearch` + `Browser Navigate` 组合
- 搜索摘要通常足以回答基础查询

### 凭证安全 / Credential Security
所有代码示例使用占位符：
- `<your-access-key-id>` - Access Key ID
- `<your-secret-key-secret>` - Secret Access Key
- `<your-region>` - 地域ID (如 cn-north-4)

---

## Official Resources (官方资源)

- **官方网站**: https://www.huaweicloud.com/
- **产品目录**: https://www.huaweicloud.com/product/
- **帮助中心**: https://support.huaweicloud.com/
- **开发者社区**: https://developer.huaweicloud.com/
