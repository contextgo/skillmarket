# Huawei Cloud Product Query Examples | 华为云产品查询示例

This document provides practical examples demonstrating how to use the Huawei Cloud Product Query Skill to retrieve comprehensive product information from official sources.

本文档提供实用示例，演示如何使用华为云产品查询技能从官方渠道获取全面的产品信息。

---

## Example 1: Single Product Query - ECS | 示例1：单个产品查询 - 弹性云服务器

### User Query | 用户查询
"请帮我查询华为云弹性云服务器(ECS)的详细信息，包括规格、定价和快速入门指南。"

### Skill Execution Steps | 技能执行步骤

#### Step 1: Identify Product | 识别产品
- **产品名称 (Product Name)**: 弹性云服务器 ECS | Elastic Cloud Server
- **产品类别 (Category)**: 计算 (Compute) > 弹性计算 (Elastic Compute)
- **产品代码 (Product Code)**: ecs
- **官方URL**: https://www.huaweicloud.com/product/ecs.html

#### Step 2: Construct Search Queries | 构建搜索查询
```
site:huaweicloud.com 弹性云服务器 产品首页
site:huaweicloud.com/document ecs 产品简介
site:huaweicloud.com/document ecs 快速入门
site:huaweicloud.com/pricing ecs
site:huaweicloud.com/api ecs
```

#### Step 3: Retrieve Product Information | 获取产品信息

**Product Homepage | 产品首页**:
- URL: https://www.huaweicloud.com/product/ecs.html
- Use `Browser Navigate` to visit and extract core information

**Key Information Extracted | 提取的关键信息**:
- **产品标语 (Tagline)**: 可随时自动获取、弹性伸缩的云服务器
- **核心功能 (Core Features)**: 弹性伸缩、稳定可靠、安全可信、简单易用
- **实例规格 (Instance Types)**: 通用型、计算型、内存型、高IO型、GPU型、FPGA型
- **计费方式 (Billing)**: 按需计费、包年/包月、竞价计费

#### Step 4: Retrieve Documentation | 获取技术文档

**Documentation URLs | 文档链接**:
- 产品简介: https://support.huaweicloud.com/productdesc-ecs/
- 用户指南: https://support.huaweicloud.com/usermanual-ecs/
- API参考: https://support.huaweicloud.com/api-ecs/

#### Step 5-7: Present Results | 呈现结果

```markdown
# 弹性云服务器 ECS | Elastic Cloud Server

## 产品概述 (Product Overview)

**产品标语 (Tagline)**: 
可随时自动获取、弹性伸缩的云服务器
/ Elastic cloud server with on-demand provisioning and auto-scaling

**产品描述 (Description)**:
弹性云服务器（Elastic Cloud Server，ECS）是由CPU、内存、镜像、云硬盘组成的一种可随时获取、弹性可扩展的计算服务器。它可以帮助您打造可靠、安全、灵活、高效的应用环境，确保服务持久稳定运行。

Elastic Cloud Server (ECS) is a computing server composed of CPU, memory, image, and cloud disk that can be obtained on-demand and scaled elastically. It helps you build reliable, secure, flexible, and efficient application environments to ensure persistent and stable service operation.

**核心功能 (Core Features)**:
- **弹性伸缩 (Elastic Scaling)**: 支持自动调整和手动调整，分钟级快速发放
  / Support automatic and manual adjustment with minute-level rapid provisioning
- **稳定可靠 (Stable and Reliable)**: 单SLA可用性达99.975%，多SLA可用性达99.995%
  / Single SLA availability up to 99.975%, multi-SLA up to 99.995%
- **安全可信 (Secure and Trusted)**: 提供多种安全服务，保障数据安全
  / Provide multiple security services to ensure data security
- **简单易用 (Easy to Use)**: 提供控制台、API、CLI等多种管理方式
  / Provide console, API, CLI and other management methods

**应用场景 (Use Cases)**:
1. **网站应用 (Web Applications)**: 部署门户网站、电商网站、博客等
   / Deploy portal websites, e-commerce sites, blogs
2. **企业办公 (Enterprise Office)**: 部署OA系统、ERP系统、CRM系统等
   / Deploy OA, ERP, CRM systems
3. **开发测试 (Development and Testing)**: 快速创建和释放资源，降低成本
   / Rapidly create and release resources to reduce costs
4. **大数据分析 (Big Data Analysis)**: 配合MRS进行大数据处理和分析
   / Big data processing and analysis with MRS
5. **AI推理训练 (AI Inference and Training)**: GPU实例支持深度学习
   / GPU instances support deep learning

---

## 产品规格 (Specifications)

### 实例规格族 (Instance Families)
| 规格族 (Family) | 类型 (Type) | 描述 (Description) | 适用场景 (Use Case) |
|----------------|------------|-------------------|-------------------|
| 通用型 (General Purpose) | s6/s7 | 计算、内存、网络性能均衡 | Web服务器、中小型数据库 |
| 计算型 (Compute Optimized) | c6/c7 | 高CPU性能 | 批处理、游戏服务器 |
| 内存型 (Memory Optimized) | m6/m7 | 大内存容量 | 内存数据库、缓存 |
| 高IO型 (High IO) | d6/d7 | 高磁盘IO性能 | 大数据、NoSQL数据库 |
| GPU型 (GPU) | g6/g7 | NVIDIA GPU支持 | AI训练、图形渲染 |
| FPGA型 (FPGA) | f6/f7 | FPGA加速 | 基因计算、视频编解码 |

### 支持地域 (Supported Regions)
- 华北-北京四 | cn-north-4
- 华北-北京一 | cn-north-1
- 华东-上海一 | cn-east-3
- 华东-上海二 | cn-east-2
- 华南-广州 | cn-south-1
- 西南-贵阳一 | cn-southwest-2
- 中国香港 | ap-southeast-1
- 新加坡 | ap-southeast-3

---

## 定价信息 (Pricing)

### 计费模式 (Billing Models)
- **按需计费 (Pay-per-use)**: 按小时计费，精确到秒，无需预付款
  / Billed by hour, accurate to seconds, no upfront payment
- **包年/包月 (Subscription)**: 预付费模式，享受折扣，适合长期稳定业务
  / Prepaid model with discounts for long-term stable business
- **竞价计费 (Spot Pricing)**: 利用闲置资源，价格随市场供需变化
  / Use idle resources with prices varying by market supply and demand

### 价格示例 (Price Examples) - 参考价格
| 实例类型 | vCPU | 内存 | 按需计费 | 包年/包月 |
|---------|------|------|---------|----------|
| 通用型 s6.large.2 | 2 | 4 GiB | ¥0.34/小时 | ¥164/月 |
| 计算型 c6.large.2 | 2 | 4 GiB | ¥0.39/小时 | ¥188/月 |
| 内存型 m6.large.8 | 2 | 16 GiB | ¥0.68/小时 | ¥328/月 |

### 成本优化建议 (Cost Optimization Tips)
1. 长期稳定业务选择包年/包月，享受折扣
2. 可中断应用使用竞价计费，大幅降低成本
3. 启用弹性伸缩，按需调整资源
4. 定期监控资源使用率，及时释放闲置资源

---

## 快速入门 (Quick Start)

### 前提条件 (Prerequisites)
- 华为云账号已完成实名认证
- 账号余额充足或已配置支付方式
- 已创建虚拟私有云(VPC)和子网

### 创建ECS实例 (Create ECS Instance)

**通过控制台 (Via Console)**:
1. 登录华为云控制台
2. 导航至 计算 > 弹性云服务器 ECS
3. 点击"购买弹性云服务器"
4. 选择区域、可用区、实例规格、镜像、磁盘
5. 配置网络、安全组、登录方式
6. 确认配置并创建

**通过API (Via API)**:
```python
from huaweicloudsdkcore.auth.credentials import BasicCredentials
from huaweicloudsdkecs.v2 import EcsClient, CreateServersRequest

# 初始化客户端
credentials = BasicCredentials(
    ak='<your-access-key-id>',
    sk='<your-secret-key-secret>'
)
client = EcsClient.new_builder() \
    .with_credentials(credentials) \
    .with_region(EcsRegion.value_of("cn-north-4")) \
    .build()

# 创建实例请求
request = CreateServersRequest()
request.body = {
    "server": {
        "availability_zone": "cn-north-4a",
        "name": "my-ecs",
        "flavorRef": "s6.large.2",
        "imageRef": "image-xxx",
        "vpcid": "vpc-xxx",
        "root_volume": {
            "volumetype": "SSD"
        }
    }
}

response = client.create_servers(request)
print(f"实例创建成功: {response.server_ids}")
```

### 连接实例 (Connect to Instance)
- **Linux**: 使用SSH密钥或密码登录
  ```bash
  ssh -i <私钥文件> root@<实例IP>
  ```
- **Windows**: 使用远程桌面连接

---

## 开发参考 (Development Reference)

### API 概览 (API Overview)
**服务端点 (Service Endpoint)**: `https://ecs.cn-north-4.myhuaweicloud.com`

**常用操作 (Common Operations)**:
| 操作 (Operation) | API Action | 描述 (Description) |
|-----------------|------------|-------------------|
| 创建实例 | POST /v2/{project_id}/cloudservers | 创建新的ECS实例 |
| 查询实例 | GET /v2/{project_id}/cloudservers | 查询实例列表 |
| 启动实例 | POST /v2/{project_id}/cloudservers/action | 启动已停止的实例 |
| 停止实例 | POST /v2/{project_id}/cloudservers/action | 停止运行中的实例 |
| 删除实例 | DELETE /v2/{project_id}/cloudservers/{server_id} | 删除实例 |

### SDK 支持 (SDK Support)
- **Java**: `huaweicloud-sdk-java`
- **Python**: `huaweicloudsdk`
- **Go**: `github.com/huaweicloud/huaweicloud-sdk-go-v3`

---

## 相关资源 (Related Resources)

### 文档链接 (Documentation Links)
- [ECS产品文档](https://support.huaweicloud.com/ecs/)
- [ECS API文档](https://support.huaweicloud.com/api-ecs/)
- [定价详情](https://www.huaweicloud.com/pricing/ecs.html)

### 相关产品 (Related Products)
- **虚拟私有云 VPC**: 为ECS实例提供网络隔离
- **云硬盘 EVS**: 持久化块存储
- **弹性负载均衡 ELB**: 流量分发
- **云监控 CES**: 实例监控告警
- **弹性伸缩 AS**: 自动容量调整
```

---

## Example 2: Product Comparison - GaussDB vs RDS MySQL | 示例2：产品对比 - GaussDB vs RDS MySQL

### User Query | 用户查询
"华为云的GaussDB和RDS MySQL有什么区别？我应该选择哪个？"

### Skill Execution Steps | 技能执行步骤

#### Step 1: Identify Products | 识别产品
- **产品A**: 云数据库 GaussDB | GaussDB
- **产品B**: 云数据库 RDS for MySQL | RDS for MySQL
- **类别**: 数据库 (Database)

#### Step 2: Construct Comparison Queries | 构建对比查询
```
site:huaweicloud.com GaussDB 产品简介
site:huaweicloud.com RDS MySQL 产品简介
site:huaweicloud.com/document GaussDB 什么是GaussDB
site:huaweicloud.com/document RDS 产品描述
```

#### Step 7: Present Comparison Results | 呈现对比结果

```markdown
# GaussDB vs 云数据库 RDS for MySQL | Product Comparison

## 概览对比 (Overview Comparison)

| 对比项 (Aspect) | GaussDB | RDS for MySQL |
|----------------|---------|---------------|
| **架构 (Architecture)** | 分布式、云原生 | 传统主从架构 |
| **目标负载 (Target Workload)** | 企业级、大规模 | 中小型、通用场景 |
| **MySQL兼容性 (Compatibility)** | 完全兼容 | 100%原生兼容 |
| **最大存储 (Max Storage)** | PB级 | 数十TB |
| **扩展方式 (Scaling)** | 水平扩展 | 垂直扩展 |

## 详细对比 (Detailed Comparison)

### 1. 架构差异 (Architecture Differences)

**GaussDB**:
- 分布式架构，支持分布式事务
- 计算存储分离
- 金融级高可用，RPO=0
- 支持Oracle/MySQL双模式
- AI-Native数据库，智能调优

**RDS for MySQL**:
- 传统主从架构
- 本地存储或云盘存储
- 垂直扩展（升级实例规格）
- 原生MySQL体验

### 2. 性能与扩展性 (Performance & Scalability)

| 特性 (Feature) | GaussDB | RDS MySQL |
|---------------|---------|-----------|
| 计算扩展 | 水平扩展（添加节点） | 垂直扩展（升级规格） |
| 存储扩展 | 自动在线扩展 | 手动扩展 |
| 读扩展 | 自动只读副本 | 手动创建只读副本 |
| 写扩展 | 分布式写入 | 单点写入 |
| 最大连接数 | 100,000+ | 取决于实例规格 |
| 性能 | 企业级高性能 | 标准性能 |

### 3. 适用场景 (Use Cases)

**选择 GaussDB 的场景 (Choose GaussDB when)**:
- 金融核心系统、政企关键业务
- 数据量达到PB级的大规模应用
- 高并发场景（数万并发连接）
- 需要金融级高可用（RPO=0）
- 需要Oracle/MySQL双模式兼容

**选择 RDS MySQL 的场景 (Choose RDS MySQL when)**:
- 中小型Web应用
- 传统MySQL工作负载
- 预算敏感的场景
- 需要原生MySQL兼容性
- 简单的架构需求

### 4. 定价对比 (Pricing Comparison)

| 组件 (Component) | GaussDB | RDS MySQL |
|-----------------|---------|-----------|
| 计算 | 按节点规格计费 | 按实例规格计费 |
| 存储 | 独立存储计费 | 包含或独立计费 |
| 最低成本 | 较高 | 较低 |
| 大规模成本 | 更具成本效益 | 成本较高 |

## 选择建议 (Recommendation)

### 金融/政企/大型企业
**推荐**: GaussDB
- 金融级高可用
- 分布式架构支持海量数据
- AI智能调优
- Oracle/MySQL双模式

### 互联网/中小企业
**推荐**: 云数据库 RDS for MySQL
- 成本更低
- 管理更简单
- 原生MySQL体验
- 满足大多数业务需求
```

---

## Example 3: Pricing Analysis - Object Storage OBS | 示例3：定价分析 - 对象存储OBS

### User Query | 用户查询
"我想了解华为云对象存储(OBS)的定价详情，包括存储费用、流量费用和请求费用。"

### Skill Execution Steps | 技能执行步骤

#### Step 1: Identify Product | 识别产品
- **产品名称**: 对象存储服务 OBS | Object Storage Service
- **产品代码**: obs
- **类别**: 存储 (Storage)

#### Step 2: Construct Pricing Queries | 构建定价查询
```
site:huaweicloud.com 对象存储 OBS 定价
site:huaweicloud.com/document obs 计费说明
site:huaweicloud.com/pricing obs
```

#### Step 3-7: Present Pricing Analysis | 呈现定价分析

```markdown
# 对象存储 OBS 定价分析 | Object Storage Service (OBS) Pricing Analysis

## 计费组成 (Pricing Components)

对象存储OBS定价由四个主要部分组成：
Object Storage Service (OBS) pricing consists of four main components:

### 1. 存储费用 (Storage Fees)
根据存储类型和实际使用量计费
Billed based on storage class and actual storage usage

| 存储类型 (Storage Class) | 中文名称 | 价格 (元/GB/月) | 适用场景 (Use Case) |
|------------------------|---------|----------------|-------------------|
| 标准存储 (Standard) | Standard | ¥0.099 | 频繁访问的数据 |
| 低频访问存储 (Infrequent Access) | Infrequent Access | ¥0.07 | 月均访问1-2次的数据 |
| 归档存储 (Archive) | Archive | ¥0.033 | 很少访问的备份数据 |
| 深度归档存储 (Deep Archive) | Deep Archive | ¥0.015 | 长期归档数据 |

### 2. 流量费用 (Traffic Fees)
外网流出流量计费
Billed for outbound data transfer

| 流量类型 (Traffic Type) | 中文名称 | 价格 (元/GB) |
|------------------------|---------|-------------|
| 外网流出流量-中国大陆 | Internet Outbound - CN | ¥0.50 |
| 外网流出流量-国际 | Internet Outbound - Global | ¥0.50 |
| CDN回源流量 | CDN Back-to-Origin | ¥0.15 |
| 跨区域复制流量 | Cross-Region Replication | ¥0.50 |

**注意**: 内网流量和入站流量免费 / Internal and inbound traffic is free

### 3. 请求费用 (Request Fees)
按万次请求计费
Billed per 10,000 requests

| 请求类型 (Request Type) | 中文名称 | 价格 (元/万次) |
|------------------------|---------|---------------|
| PUT/POST/DELETE | 写请求 | ¥0.01 |
| GET/HEAD | 读请求 | ¥0.01 |
| LIST | 列表请求 | ¥0.01 |

### 4. 数据处理费用 (Data Processing Fees)

| 操作 (Operation) | 中文名称 | 价格 |
|-----------------|---------|------|
| 图片处理 | Image Processing | ¥1.00/万次 |
| 数据取回-低频 | IA Data Retrieval | ¥0.03/GB |
| 数据取回-归档 | Archive Data Retrieval | ¥0.06/GB |
| 数据取回-深度归档 | Deep Archive Data Retrieval | ¥0.15/GB |

---

## 成本计算示例 (Cost Calculation Example)

### 场景 (Scenario)
- 存储容量: 10 TB 标准存储
- 每月外网流出流量: 5 TB
- 每月请求次数: 1000万次 (800万GET, 200万PUT)
- 图片处理: 100万张

### 计算 (Calculation)

| 计费项 | 计算公式 | 费用 |
|-------|---------|------|
| 存储费用 | 10,000 GB × ¥0.099 | ¥990 |
| 流量费用 | 5,000 GB × ¥0.50 | ¥2,500 |
| GET请求 | 800万 ÷ 1万 × ¥0.01 | ¥8 |
| PUT请求 | 200万 ÷ 1万 × ¥0.01 | ¥2 |
| 图片处理 | 100万 ÷ 1万 × ¥1.00 | ¥100 |
| **月度总计** | | **¥3,600** |

---

## 成本优化策略 (Cost Optimization Strategies)

### 1. 存储类型优化 (Storage Class Optimization)
- 使用生命周期策略自动转换对象
- 标准存储 → 低频存储（30天后）
- 低频存储 → 归档存储（90天后）
- 潜在节省: 40-70%

### 2. 流量优化 (Traffic Optimization)
- 使用CDN分发内容（减少源站流量）
- 内网传输使用VPC对等连接
- 跨区域复制选择合适的时间窗口

### 3. 请求优化 (Request Optimization)
- 批量操作减少请求次数
- 大文件使用分段上传
- 实现客户端缓存

### 4. 免费额度利用 (Free Tier Utilization)
华为云为新用户提供免费额度：
- 标准存储: 50 GB/月免费
- 外网流出流量: 10 GB/月免费
- 请求次数: 10万次/月免费
```

---

## Example 4: API Integration - Creating CCE Cluster | 示例4：API集成 - 创建CCE集群

### User Query | 用户查询
"我需要使用API创建华为云容器引擎(CCE)集群，请提供完整的代码示例。"

### Skill Execution Steps | 技能执行步骤

#### Step 1: Identify Product | 识别产品
- **产品名称**: 云容器引擎 CCE | Cloud Container Engine
- **产品代码**: cce
- **类别**: 容器与中间件 (Container & Middleware)

#### Step 2: Construct API Documentation Queries | 构建API文档查询
```
site:huaweicloud.com/document cce API
site:huaweicloud.com/api cce CreateCluster
site:huaweicloud.com cce SDK
```

#### Step 3-7: Present API Integration Guide | 呈现API集成指南

```markdown
# CCE API 集成指南 | CCE API Integration Guide

## 前提条件 (Prerequisites)

1. 华为云账号并开通CCE访问权限
2. 已配置Access Key ID和Secret Key
3. 已创建VPC和子网
4. 具备CCE操作的IAM权限

## API 概览 (API Overview)

**服务端点 (Service Endpoint)**: `https://cce.cn-north-4.myhuaweicloud.com`

**认证方式 (Authentication)**:
- AK/SK签名认证
- Token认证

## 代码示例 (Code Examples)

### Python SDK 示例 (Python SDK Example)

```python
from huaweicloudsdkcore.auth.credentials import BasicCredentials
from huaweicloudsdkcce.v3 import CceClient, CreateClusterRequest
from huaweicloudsdkcce.v3.region.cce_region import CceRegion

# 初始化配置
credentials = BasicCredentials(
    ak='<your-access-key-id>',
    sk='<your-secret-key-secret>'
)

client = CceClient.new_builder() \
    .with_credentials(credentials) \
    .with_region(CceRegion.value_of("cn-north-4")) \
    .build()

# 构建创建集群请求
request = CreateClusterRequest()
request.body = {
    "kind": "Cluster",
    "apiVersion": "v3",
    "metadata": {
        "name": "my-cce-cluster",
        "annotations": {
            "cluster.install.addons.external/install": "[\"autoscaler\", \"gpu-device-plugin\"]"
        }
    },
    "spec": {
        "type": "VirtualMachine",
        "flavor": "cce.s1.small",
        "version": "v1.28",
        "hostNetwork": {
            "vpc": "vpc-xxx",
            "subnet": "subnet-xxx"
        },
        "containerNetwork": {
            "mode": "vpc-router",
            "cidr": "172.16.0.0/16"
        },
        "authentication": {
            "mode": "rbac",
            "authenticatingProxy": {}
        }
    }
}

try:
    response = client.create_cluster(request)
    print(f"集群创建成功!")
    print(f"集群ID: {response.metadata.uid}")
    print(f"集群名称: {response.metadata.name}")
except Exception as e:
    print(f"创建集群错误: {e}")
```

### Java SDK 示例 (Java SDK Example)

```java
import com.huaweicloud.sdk.cce.v3.CceClient;
import com.huaweicloud.sdk.cce.v3.model.*;
import com.huaweicloud.sdk.core.auth.BasicCredentials;

public class CCEClusterCreator {
    public static void main(String[] args) {
        // 初始化客户端
        BasicCredentials credentials = new BasicCredentials()
            .withAk("<your-access-key-id>")
            .withSk("<your-secret-key-secret>");

        CceClient client = CceClient.newBuilder()
            .withCredential(credentials)
            .withRegion(CceRegion.CN_NORTH_4)
            .build();

        // 创建集群请求
        CreateClusterRequest request = new CreateClusterRequest();
        Cluster cluster = new Cluster()
            .withKind("Cluster")
            .withApiVersion("v3")
            .withMetadata(new ClusterMetadata()
                .withName("my-cce-cluster"))
            .withSpec(new ClusterSpec()
                .withType("VirtualMachine")
                .withFlavor("cce.s1.small")
                .withVersion("v1.28")
                .withHostNetwork(new HostNetwork()
                    .withVpc("vpc-xxx")
                    .withSubnet("subnet-xxx"))
                .withContainerNetwork(new ContainerNetwork()
                    .withMode("vpc-router")
                    .withCidr("172.16.0.0/16")));

        request.withBody(cluster);

        try {
            CreateClusterResponse response = client.createCluster(request);
            System.out.println("集群创建成功: " + response.getMetadata().getUid());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

### Go SDK 示例 (Go SDK Example)

```go
package main

import (
    "fmt"
    "github.com/huaweicloud/huaweicloud-sdk-go-v3/core/auth/basic"
    cce "github.com/huaweicloud/huaweicloud-sdk-go-v3/services/cce/v3"
    "github.com/huaweicloud/huaweicloud-sdk-go-v3/services/cce/v3/model"
    region "github.com/huaweicloud/huaweicloud-sdk-go-v3/services/cce/v3/region"
)

func main() {
    // 创建认证
    auth := basic.NewCredentialsBuilder().
        WithAk("<your-access-key-id>").
        WithSk("<your-secret-key-secret>").
        Build()

    // 创建客户端
    client := cce.NewCceClient(
        cce.CceClientBuilder().
            WithRegion(region.ValueOf("cn-north-4")).
            WithCredential(auth).
            Build())

    // 创建集群请求
    name := "my-cce-cluster"
    vpc := "vpc-xxx"
    subnet := "subnet-xxx"
    cidr := "172.16.0.0/16"
    
    request := &model.CreateClusterRequest{
        Body: &model.Cluster{
            Kind:       "Cluster",
            ApiVersion: "v3",
            Metadata: &model.ClusterMetadata{
                Name: &name,
            },
            Spec: &model.ClusterSpec{
                Type:    "VirtualMachine",
                Flavor:  "cce.s1.small",
                Version: "v1.28",
                HostNetwork: &model.HostNetwork{
                    Vpc:    &vpc,
                    Subnet: &subnet,
                },
                ContainerNetwork: &model.ContainerNetwork{
                    Mode: "vpc-router",
                    Cidr: &cidr,
                },
            },
        },
    }

    // 发送请求
    response, err := client.CreateCluster(request)
    if err != nil {
        fmt.Printf("错误: %v\n", err)
        return
    }

    fmt.Printf("集群创建成功: %s\n", *response.Metadata.Uid)
}
```

## 常用操作 (Common Operations)

| 操作 (Operation) | API Action | 描述 (Description) |
|-----------------|------------|-------------------|
| 创建集群 | POST /api/v3/projects/{project_id}/clusters | 创建新的CCE集群 |
| 查询集群 | GET /api/v3/projects/{project_id}/clusters | 列出所有集群 |
| 更新集群 | PUT /api/v3/projects/{project_id}/clusters/{cluster_id} | 修改集群配置 |
| 删除集群 | DELETE /api/v3/projects/{project_id}/clusters/{cluster_id} | 删除集群 |
| 创建节点池 | POST /api/v3/projects/{project_id}/clusters/{cluster_id}/nodepools | 添加节点池 |

## 错误处理 (Error Handling)

常见错误代码及解决方案：

| 错误代码 | 描述 | 解决方案 |
|---------|------|---------|
| CCE.01400001 | 参数错误 | 检查参数格式和范围 |
| CCE.01400002 | 资源不足 | 检查配额或选择其他区域 |
| CCE.01400003 | 权限不足 | 检查IAM权限 |
| CCE.01400004 | VPC不存在 | 验证VPC ID |

## 相关资源 (Related Resources)

- [CCE产品文档](https://support.huaweicloud.com/cce/)
- [CCE API文档](https://support.huaweicloud.com/api-cce/)
- [Kubernetes最佳实践](https://support.huaweicloud.com/bestpractice-cce/)
```

---

## Example 5: Architecture Recommendation - E-commerce Platform | 示例5：架构推荐 - 电商平台

### User Query | 用户查询
"我需要为电商平台设计一个基于华为云的架构，包括前端、后端、数据库和缓存。"

### Skill Execution Steps | 技能执行步骤

#### Step 1: Identify Required Products | 识别所需产品
分析电商需求并映射到华为云产品：
- **前端**: CDN + WSA
- **后端**: ECS/CCE
- **数据库**: GaussDB + GeminiDB
- **存储**: OBS
- **网络**: VPC, ELB
- **安全**: WAF, HSS

#### Step 2: Research Each Product | 调研每个产品
对每个识别出的产品执行查询，收集规格和集成模式。

#### Step 3-7: Present Architecture Recommendation | 呈现架构推荐

```markdown
# 华为云电商平台架构 | E-commerce Platform Architecture on Huawei Cloud

## 架构概览 (Architecture Overview)

本架构使用华为云服务构建可扩展、高可用的电商平台。
This architecture provides a scalable, high-availability e-commerce platform using Huawei Cloud services.

```
                    [用户 Users]
                        |
                        v
                [CDN / 全站加速 WSA]
                        |
                        v
                [WAF 安全防护]
                        |
                        v
        [弹性负载均衡 ELB]
                        |
        +----------------+----------------+
        |                                 |
        v                                 v
[Web服务器 ECS]              [API服务器 CCE]
        |                                 |
        v                                 v
   [GeminiDB缓存]                  [GaussDB]
        |                          (主库+副本)
        v                                 |
   [会话存储]                           v
                             [OBS对象存储]
                             (图片、视频)
```

## 组件详情 (Component Details)

### 1. 内容分发 (Content Delivery)

**产品**: 内容分发网络 (CDN) + 全站加速 (WSA)

**配置**:
- CDN用于静态资源（图片、CSS、JS）
- WSA用于动态内容加速
- 全球加速节点覆盖
- HTTPS自定义SSL证书

**定价估算**:
- CDN: ¥0.24/GB (流出流量)
- WSA: ¥0.30/GB (动态加速)

### 2. 安全层 (Security Layer)

**产品**: Web应用防火墙 (WAF) + 企业主机安全 (HSS)

**配置**:
- WAF防护DDoS攻击和SQL注入
- Bot管理防爬虫
- SSL/TLS传输加密
- HSS主机安全防护

**定价估算**:
- WAF: 起价 ¥2,000/月
- HSS: ¥60/服务器/月

### 3. 负载均衡 (Load Balancing)

**产品**: 弹性负载均衡 (ELB)

**配置**:
- 七层负载均衡
- 健康检查
- 会话保持
- 弹性伸缩集成

**定价估算**:
- ELB实例: ¥0.10/小时
- LCU: ¥0.05/LCU-小时

### 4. 计算层 (Compute Layer)

#### Web服务器 (Web Servers)
**产品**: 弹性云服务器 (ECS) + 弹性伸缩 (AS)

**配置**:
- 实例规格: s6.large.2 (2 vCPU, 4GB内存)
- 最小: 2实例（多可用区）
- 最大: 20实例（弹性伸缩）

**定价估算**:
- ECS: ¥164/月/实例
- AS: 免费（按资源付费）

#### API服务器 (API Servers)
**产品**: 云容器引擎 (CCE)

**配置**:
- Kubernetes v1.28
- 3个Worker节点 (s6.xlarge.2)
- HPA水平Pod自动伸缩

**定价估算**:
- 控制平面: 免费
- Worker节点: ¥328/月/节点

### 5. 数据库层 (Database Layer)

#### 主数据库 (Primary Database)
**产品**: 云数据库 GaussDB

**配置**:
- 分布式架构高可用
- 4核16GB
- 500GB存储
- 自动读写分离

**定价估算**:
- 计算: ¥1,200/月
- 存储: ¥0.50/GB/月

#### 缓存层 (Cache Layer)
**产品**: 云数据库 GeminiDB (Redis)

**配置**:
- 主从架构
- 8GB内存
- 会话存储和热点数据缓存

**定价估算**:
- GeminiDB: ¥480/月

### 6. 存储层 (Storage Layer)

**产品**: 对象存储服务 (OBS)

**配置**:
- 标准存储用于商品图片
- 低频存储用于历史订单附件
- CDN集成图片分发
- 生命周期策略成本优化

**定价估算**:
- 存储: ¥0.099/GB/月
- 请求: ¥0.01/万次

## 成本汇总 (Cost Summary)

### 月度成本估算 (Monthly Cost Estimate)

| 组件 | 配置 | 月度费用 |
|-----|------|---------|
| CDN | 1 TB流量 | ¥240 |
| WAF | 标准版 | ¥2,000 |
| ELB | 1实例 | ¥72 |
| ECS | 4实例(平均) | ¥656 |
| CCE | 3节点 | ¥984 |
| GaussDB | 4核16GB + 500GB | ¥1,450 |
| GeminiDB | 8GB | ¥480 |
| OBS | 500GB + 请求 | ¥50 |
| HSS | 7服务器 | ¥420 |
| **总计** | | **¥6,352/月** |

## 扩展考虑 (Scaling Considerations)

### 水平扩展 (Horizontal Scaling)
- 基于CPU/内存指标的弹性伸缩策略
- 数据库只读副本分担读压力
- CDN全球内容分发

### 垂直扩展 (Vertical Scaling)
- 大促期间升级ECS实例规格
- 增加GaussDB节点提升性能
- 扩展GeminiDB内存支持更大缓存

### 大促准备 (Peak Season Preparation)
- 预热CDN缓存
- 提前扩容ECS/CCE集群
- 启用数据库连接池
- 设置实时监控大屏

## 相关产品 (Related Products)

- **分布式消息服务 DMS**: 订单处理和异步任务
- **云监控 CES**: 监控告警
- **云日志服务 LTS**: 集中日志管理
- **MapReduce服务 MRS**: 业务分析
```

---

## Summary | 总结

These examples demonstrate the complete workflow of the Huawei Cloud Product Query Skill:

这些示例演示了华为云产品查询技能的完整工作流程：

1. **Single Product Query (单个产品查询)**: Deep dive into one product with full specifications, pricing, and usage guides
2. **Product Comparison (产品对比)**: Side-by-side analysis of similar products for informed decision-making
3. **Pricing Analysis (定价分析)**: Detailed cost breakdown with optimization strategies
4. **API Integration (API集成)**: Complete code examples for programmatic access
5. **Architecture Design (架构设计)**: Multi-product solution architecture with cost estimates

When using this skill, always:
- Use `WebSearch` to find official documentation URLs
- Use `WebFetch` or `Browser Navigate` to retrieve detailed content
- Cross-reference multiple sources for accuracy
- Provide bilingual (Chinese/English) output
- Include credential placeholders in all code examples
