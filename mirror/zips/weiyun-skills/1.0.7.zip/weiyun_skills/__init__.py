"""Weiyun Skills - Tencent Weiyun cloud storage management toolkit."""

from weiyun_skills.client import WeiyunClient

__version__ = "1.0.7"
__all__ = ["WeiyunClient"]
