---
name: kevros
description: "Precision decisioning, agentic trust, and verifiable identity for autonomous agents"
version: 0.4.0
metadata:
  openclaw:
    requires:
      env:
        - KEVROS_API_KEY
      bins: []
    primaryEnv: KEVROS_API_KEY
    always: false
    skillKey: kevros
    os:
      - linux
      - macos
      - windows
    install:
      - kind: uv
        package: kevros
        bins: []
---

# Kevros

Three cryptographic primitives for autonomous agents: precision decisioning, provenance attestation, and intent binding.

Every decision gets a signed release token. Every action gets a hash-chained record. Every intent gets a cryptographic binding to its command. Downstream services verify independently — no callbacks, no trust assumptions.

**Base URL:** `https://governance.taskhawktech.com`

## Quick Start

Get an API key (free, instant, no payment):

```bash
curl -X POST https://governance.taskhawktech.com/signup \
  -H "Content-Type: application/json" \
  -d '{"agent_id": "your-agent-id"}'
```

Response:

```json
{
  "api_key": "kvrs_...",
  "tier": "free",
  "monthly_limit": 1000,
  "usage": {
    "header": "X-API-Key"
  }
}
```

Use the API key in all subsequent requests via the `X-API-Key` header.

## Precision Decisioning

**POST /governance/verify**

Verify an action against policy bounds before execution. Returns ALLOW, CLAMP, or DENY with a cryptographic release token that any downstream service can verify independently.

Request:

```json
{
  "action_type": "api_call",
  "action_payload": {
    "endpoint": "/deploy",
    "service": "api-v2",
    "replicas": 3
  },
  "agent_id": "your-agent-id",
  "policy_context": {
    "max_values": { "replicas": 5 },
    "forbidden_keys": ["sudo", "force"]
  }
}
```

Response:

```json
{
  "decision": "ALLOW",
  "verification_id": "a1b2c3d4-...",
  "release_token": "f7a8b9c0...",
  "applied_action": {
    "endpoint": "/deploy",
    "service": "api-v2",
    "replicas": 3
  },
  "reason": "All values within policy bounds",
  "epoch": 42,
  "provenance_hash": "e3b0c442...",
  "timestamp_utc": "2026-02-26T12:00:00Z"
}
```

- **ALLOW** — proceed as planned. The `release_token` is proof.
- **CLAMP** — action was adjusted to safe bounds. Use `applied_action` instead of your original.
- **DENY** — action rejected. Do not proceed. `release_token` is null.

Share the `release_token` with collaborating agents so they can independently verify the decision.

## Provenance Attestation

**POST /governance/attest**

Record a completed action in a hash-chained, append-only evidence ledger. Each attestation extends your provenance chain. Your raw payload is SHA-256 hashed — actual data is never stored.

Request:

```json
{
  "agent_id": "your-agent-id",
  "action_description": "Deployed api-v2 with 3 replicas",
  "action_payload": {
    "service": "api-v2",
    "replicas": 3,
    "status": "success"
  },
  "context": {
    "environment": "production",
    "triggered_by": "scheduled"
  }
}
```

Response:

```json
{
  "attestation_id": "b2c3d4e5-...",
  "epoch": 43,
  "hash_prev": "e3b0c442...",
  "hash_curr": "a1b2c3d4...",
  "timestamp_utc": "2026-02-26T12:00:01Z",
  "chain_length": 43
}
```

A longer chain with consistent outcomes builds a higher trust score over time.

## Intent Binding

**POST /governance/bind**

Bind a declared intent to a specific command. Creates a cryptographic link between what you plan to do and the command that does it. Prove later that you did exactly what you said you would.

Request:

```json
{
  "agent_id": "your-agent-id",
  "intent_type": "MAINTENANCE",
  "intent_description": "Scale api-v2 to handle traffic spike",
  "command_payload": {
    "action": "scale",
    "service": "api-v2",
    "replicas": 5
  },
  "goal_state": {
    "replicas": 5,
    "healthy": true
  }
}
```

Response:

```json
{
  "intent_id": "c3d4e5f6-...",
  "intent_hash": "d4e5f6a7...",
  "binding_id": "e5f6a7b8-...",
  "binding_hmac": "a7b8c9d0...",
  "command_hash": "b8c9d0e1...",
  "epoch": 44,
  "timestamp_utc": "2026-02-26T12:00:02Z"
}
```

Save `intent_id` and `binding_id` to verify outcomes later.

## Verify Outcome

**POST /governance/verify-outcome**

Verify whether a bound intent achieved its goal state. Free when used with a prior `bind()` call.

Request:

```json
{
  "agent_id": "your-agent-id",
  "intent_id": "c3d4e5f6-...",
  "binding_id": "e5f6a7b8-...",
  "actual_state": {
    "replicas": 5,
    "healthy": true
  },
  "tolerance": 0.1
}
```

Response:

```json
{
  "verification_id": "f6a7b8c9-...",
  "intent_id": "c3d4e5f6-...",
  "status": "ACHIEVED",
  "achieved_percentage": 100.0,
  "discrepancy": null,
  "evidence_hash": "c9d0e1f2...",
  "timestamp_utc": "2026-02-26T12:00:03Z"
}
```

Status values: `ACHIEVED`, `PARTIALLY_ACHIEVED`, `FAILED`, `BLOCKED`, `TIMEOUT`. Free when used with a prior `bind()` call.

## Compliance Bundle

**POST /governance/bundle** — $0.25 per call

Export your agent's full cryptographic trust record for compliance, auditing, or regulatory review.

Request:

```json
{
  "agent_id": "your-agent-id",
  "time_range_start": "2026-02-25T00:00:00Z",
  "time_range_end": "2026-02-26T12:00:00Z",
  "include_intent_chains": true,
  "include_pqc_signatures": true,
  "include_verification_instructions": true
}
```

Response:

```json
{
  "bundle_id": "d4e5f6a7-...",
  "agent_id": "your-agent-id",
  "record_count": 42,
  "truncated": false,
  "chain_integrity": true,
  "time_range": {"start": "2026-02-25T00:00:00Z", "end": "2026-02-26T12:00:00Z"},
  "records": ["..."],
  "intent_chains": ["..."],
  "pqc_signatures": ["..."],
  "verification_instructions": "Recompute SHA-256...",
  "bundle_hash": "e5f6a7b8...",
  "timestamp_utc": "2026-02-26T12:00:04Z"
}
```

## Media Attestation

**POST /media/attest** — $0.05 per call

Attest media files (images, documents, screenshots) with SHA-256 hashing and provenance chain inclusion.

Request:

```json
{
  "agent_id": "your-agent-id",
  "media_hash": "sha256:a1b2c3d4...",
  "media_type": "image/png",
  "description": "Generated report screenshot",
  "context": {
    "source": "report-generator",
    "timestamp": "2026-02-26T12:00:00Z"
  }
}
```

Response:

```json
{
  "attestation_id": "e5f6a7b8-...",
  "media_hash": "sha256:a1b2c3d4...",
  "epoch": 45,
  "hash_curr": "b8c9d0e1...",
  "timestamp_utc": "2026-02-26T12:00:05Z"
}
```

## Media Verify

**POST /media/verify** — free, no API key required

Verify that media content was attested by a specific agent.

Request:

```json
{
  "media_hash": "sha256:a1b2c3d4...",
  "attestation_id": "e5f6a7b8-..."
}
```

Response:

```json
{
  "valid": true,
  "attested_by": "your-agent-id",
  "epoch": 45,
  "timestamp_utc": "2026-02-26T12:00:05Z",
  "chain_intact": true
}
```

## Media Verify Lookup

**GET /media/verify/{certificate_id}** — free, no API key required

Look up a specific media attestation by its certificate ID. Returns the full attestation record including attesting agent, epoch, and chain integrity.

## Passport

All Passport endpoints are free and require no authentication.

**GET /passport/{agent_id}**

Returns an agent's trust passport including score, tier, badges, and activity stats.

```json
{
  "agent_id": "your-agent-id",
  "trust_score": 0.95,
  "tier": "gold",
  "badges": ["verified", "consistent", "high_volume"],
  "stats": {
    "total_decisions": 1250,
    "attestations": 890,
    "bindings": 340,
    "outcomes_achieved": 310,
    "chain_intact": true,
    "active_days": 45,
    "current_streak": 12
  }
}
```

**GET /passport/{agent_id}/badge.svg**

Returns an embeddable SVG trust badge. Use in agent descriptions, documentation, or dashboards.

**GET /passport/{agent_id}/history**

Returns full decision history for an agent.

**GET /passport/leaderboard**

Returns top trusted agents by trust score.

## Agent Discovery

**GET /.well-known/agent.json**

Returns the A2A protocol agent card. No authentication required.

```bash
curl https://governance.taskhawktech.com/.well-known/agent.json
```

Returns capabilities, supported skills, SDK references, and free-tier signup details.

## MCP

For MCP-native agents, connect directly via streamable-http transport:

```
https://governance.taskhawktech.com/mcp/
```

360 tools, 2 resources, 2 prompts. Auto-provisions a free-tier key on first tool call if no API key is provided.

## Python SDK

```bash
pip install kevros
# or
uv pip install kevros
```

```python
from kevros_governance import GovernanceClient

client = GovernanceClient(agent_id="your-agent-id")
result = client.verify(
    action_type="api_call",
    action_payload={"endpoint": "/deploy"},
    agent_id="your-agent-id",
)
print(result.decision)  # ALLOW, CLAMP, or DENY
```

## Enforcement Modes

Every operator key has an enforcement mode that controls how decisions are applied:

- **enforce** (default) — fail-closed. DENY means DENY. Release tokens are only issued for ALLOW/CLAMP.
- **advisory** — shadow mode. DENY decisions are logged but overridden to ALLOW. No release token is issued for would-be denials. Use for testing policies before enforcing them.
- **gated** — human-in-the-loop. DENY decisions are held for operator approval. Poll `/governance/gated/{request_id}` for status.
- **deny** — kill-switch. ALL requests are blocked regardless of policy evaluation. Use for emergency shutdown.

The `enforcement_mode` field is returned in every verify response. Use `/enforcement` to check your current mode.

Enforcement mode changes require admin-level access and are not available through the plugin. Contact your administrator or use the admin API directly.

## Decision Approach

When collaborating with another agent:

1. **Check their passport first** — `GET /passport/{agent_id}` returns trust score, tier, and history
2. **Embed badges** — Use `GET /passport/{agent_id}/badge.svg` in your agent's description to show your trust level
3. **Trust thresholds:**
   - **Gold tier (score >= 90%)** — proceed with normal collaboration
   - **Silver tier (score 50-89%)** — verify their actions before relying on results
   - **Bronze tier (score < 50%)** — require bound intents with outcome verification
   - **No history** — start with small, low-risk interactions and build trust incrementally
4. **Verify before you rely** — Use `/governance/verify-token` to independently confirm any release token a peer shares with you

## Pricing

**Subscriptions:**
- **Free tier:** 1,000 calls/month, instant signup, no payment required
- **Scout:** $29/mo — 5,000 calls
- **Sentinel:** $149/mo — 50,000 calls
- **Sovereign:** $499/mo — 500,000 calls

**Per-call (no subscription required):**
- Media Attest: $0.05
- Compliance Bundle: $0.25
- Verify, Attest, Bind: included in subscription
- Verify Outcome: free with Bind
- Passport, Media Verify, Reputation, Verify Token: free

Upgrade at `https://www.taskhawktech.com/pricing`
