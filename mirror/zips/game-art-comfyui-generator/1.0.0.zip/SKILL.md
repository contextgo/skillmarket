---
# Skill 元数据（OpenClaw自动识别，请勿修改结构）
name: game-art-comfyui-generator
version: 1.0.0
description: 对接本地ComfyUI服务，为游戏项目批量生成全套美术素材，包括角色原画、场景原画、道具素材、技能特效序列帧，支持自定义工作流、动态参数替换和批量队列生成，适配RTX3090显卡本地部署环境
author: OpenClaw用户
license: MIT

# 核心能力（OpenClaw自动识别触发场景，请勿删减）
capabilities:
  - id: generate-game-character
    description: 生成游戏角色原画，支持立绘、三视图、NPC、怪物等角色类美术素材，自动调用角色专属工作流
  - id: generate-game-scene
    description: 生成游戏场景原画，支持主城、副本、关卡、UI背景等场景类美术素材，自动调用场景专属工作流
  - id: generate-game-prop
    description: 生成游戏道具素材，支持武器、装备、饰品、图标等道具类美术素材，自动调用道具专属工作流
  - id: generate-game-vfx
    description: 生成游戏技能特效，支持光效、粒子、序列帧、特效贴图等特效类美术素材，自动调用特效专属工作流
  - id: batch-generate-assets
    description: 批量生成多组游戏美术素材，支持一次性生成同风格多类型素材，自动排队列，适配3090显存优化
  - id: query-generate-status
    description: 查询ComfyUI生成任务进度与队列状态，返回生成结果的本地保存路径

# 权限声明（最小权限原则，请勿修改）
permissions:
  network: true
  filesystem: true
  shell: false
env:
  - COMFYUI_API_KEY

# 入参定义（OpenClaw自动从对话中提取参数，请勿修改结构）
inputs:
  - name: prompt
    type: string
    required: true
    description: 美术素材的正向描述词，支持中文，会自动优化为专业绘图提示词
  - name: asset_type
    type: string
    required: true
    default: character
    enum: [character, scene, prop, vfx]
    description: 生成的素材类型，可选角色/场景/道具/特效
  - name: batch_count
    type: number
    required: false
    default: 1
    description: 生成的素材数量，批量生成时使用，最大不超过20（适配3090显存）
  - name: width
    type: number
    required: false
    default: 1024
    description: 生成图片的宽度，单位像素，SDXL推荐1024，特效推荐512
  - name: height
    type: number
    required: false
    default: 1024
    description: 生成图片的高度，单位像素，立绘推荐1536，场景推荐2048
  - name: negative_prompt
    type: string
    required: false
    default: "lowres, blurry, text, watermark, signature, ugly, deformed, noisy, out of frame, extra limbs, bad anatomy"
    description: 反向提示词，用于规避低质量、错误内容
  - name: seed
    type: number
    required: false
    default: -1
    description: 随机种子，-1为随机生成，固定数值可复现效果

# 出参定义（OpenClaw自动处理数据流转，请勿修改）
outputs:
  - name: task_id
    type: string
    description: ComfyUI生成任务的唯一ID，可用于查询进度
  - name: status
    type: string
    description: 任务最终状态，success/failed
  - name: output_paths
    type: array
    description: 生成素材的本地保存绝对路径列表
  - name: error_msg
    type: string
    description: 任务失败时的错误信息
---

# ====================== 用户必填配置区（仅需修改这里，其他内容请勿动） ======================
## 1. ComfyUI 基础API配置
COMFYUI_BASE_URL: "http://127.0.0.1:8188"  # 你的ComfyUI本地服务地址，默认端口8188
COMFYUI_API_KEY: ""  # 选填，若你的ComfyUI开启了API认证，填写你的API密钥
COMFYUI_OUTPUT_DIR: "D:/ComfyUI/output"  # 你的ComfyUI输出文件夹绝对路径，用于OpenClaw定位生成的素材

## 2. 工作流配置（核心！请替换为你自己导出的API格式工作流JSON）
### 导出方法：ComfyUI调试好工作流 → 右上角菜单 → Save (API Format) → 复制JSON内容粘贴到对应位置
WORKFLOW_TEMPLATES:
  # 角色原画工作流（适配立绘、三视图、NPC、怪物，推荐带ControlNet线稿控型）
  character: |
    {
      "3": {
        "class_type": "KSampler",
        "inputs": {
          "cfg": 8,
          "denoise": 1,
          "latent_image": ["5", 0],
          "model": ["4", 0],
          "negative": ["7", 0],
          "positive": ["6", 0],
          "sampler_name": "euler",
          "scheduler": "normal",
          "seed": -1,
          "steps": 20
        }
      },
      "4": {
        "class_type": "CheckpointLoaderSimple",
        "inputs": {
          "ckpt_name": "sdxl_xl_base_1.0.safetensors"
        }
      },
      "5": {
        "class_type": "EmptyLatentImage",
        "inputs": {
          "batch_size": 1,
          "height": 1024,
          "width": 1024
        }
      },
      "6": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "clip": ["4", 1],
          "text": "{{prompt}}"
        }
      },
      "7": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "clip": ["4", 1],
          "text": "{{negative_prompt}}"
        }
      },
      "8": {
        "class_type": "VAEDecode",
        "inputs": {
          "samples": ["3", 0],
          "vae": ["4", 2]
        }
      },
      "9": {
        "class_type": "SaveImage",
        "inputs": {
          "filename_prefix": "game_character",
          "images": ["8", 0]
        }
      }
    }
  # 场景原画工作流（适配大场景、关卡、主城，推荐带景深、高清修复）
  scene: |
    {
      "3": {
        "class_type": "KSampler",
        "inputs": {
          "cfg": 7,
          "denoise": 1,
          "latent_image": ["5", 0],
          "model": ["4", 0],
          "negative": ["7", 0],
          "positive": ["6", 0],
          "sampler_name": "dpmpp_2m",
          "scheduler": "karras",
          "seed": -1,
          "steps": 24
        }
      },
      "4": {
        "class_type": "CheckpointLoaderSimple",
        "inputs": {
          "ckpt_name": "sdxl_xl_base_1.0.safetensors"
        }
      },
      "5": {
        "class_type": "EmptyLatentImage",
        "inputs": {
          "batch_size": 1,
          "height": 1024,
          "width": 2048
        }
      },
      "6": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "clip": ["4", 1],
          "text": "{{prompt}}"
        }
      },
      "7": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "clip": ["4", 1],
          "text": "{{negative_prompt}}"
        }
      },
      "8": {
        "class_type": "VAEDecode",
        "inputs": {
          "samples": ["3", 0],
          "vae": ["4", 2]
        }
      },
      "9": {
        "class_type": "SaveImage",
        "inputs": {
          "filename_prefix": "game_scene",
          "images": ["8", 0]
        }
      }
    }
  # 道具素材工作流（适配武器、装备、图标，推荐带透明背景、对称优化）
  prop: |
    {
      "3": {
        "class_type": "KSampler",
        "inputs": {
          "cfg": 8,
          "denoise": 1,
          "latent_image": ["5", 0],
          "model": ["4", 0],
          "negative": ["7", 0],
          "positive": ["6", 0],
          "sampler_name": "euler",
          "scheduler": "normal",
          "seed": -1,
          "steps": 20
        }
      },
      "4": {
        "class_type": "CheckpointLoaderSimple",
        "inputs": {
          "ckpt_name": "sdxl_xl_base_1.0.safetensors"
        }
      },
      "5": {
        "class_type": "EmptyLatentImage",
        "inputs": {
          "batch_size": 1,
          "height": 1024,
          "width": 1024
        }
      },
      "6": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "clip": ["4", 1],
          "text": "{{prompt}}, transparent background"
        }
      },
      "7": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "clip": ["4", 1],
          "text": "{{negative_prompt}}, white background, solid background"
        }
      },
      "8": {
        "class_type": "VAEDecode",
        "inputs": {
          "samples": ["3", 0],
          "vae": ["4", 2]
        }
      },
      "9": {
        "class_type": "SaveImage",
        "inputs": {
          "filename_prefix": "game_prop",
          "images": ["8", 0]
        }
      }
    }
  # 技能特效工作流（适配光效、粒子、序列帧，推荐带透明通道、动态参数）
  vfx: |
    {
      "3": {
        "class_type": "KSampler",
        "inputs": {
          "cfg": 7.5,
          "denoise": 1,
          "latent_image": ["5", 0],
          "model": ["4", 0],
          "negative": ["7", 0],
          "positive": ["6", 0],
          "sampler_name": "dpmpp_2m",
          "scheduler": "karras",
          "seed": -1,
          "steps": 20
        }
      },
      "4": {
        "class_type": "CheckpointLoaderSimple",
        "inputs": {
          "ckpt_name": "sdxl_xl_base_1.0.safetensors"
        }
      },
      "5": {
        "class_type": "EmptyLatentImage",
        "inputs": {
          "batch_size": 1,
          "height": 512,
          "width": 512
        }
      },
      "6": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "clip": ["4", 1],
          "text": "{{prompt}}, glowing effect, transparent background, black background, vfx, particle effect"
        }
      },
      "7": {
        "class_type": "CLIPTextEncode",
        "inputs": {
          "clip": ["4", 1],
          "text": "{{negative_prompt}}, text, watermark, ugly, deformed"
        }
      },
      "8": {
        "class_type": "VAEDecode",
        "inputs": {
          "samples": ["3", 0],
          "vae": ["4", 2]
        }
      },
      "9": {
        "class_type": "SaveImage",
        "inputs": {
          "filename_prefix": "game_vfx",
          "images": ["8", 0]
        }
      }
    }

## 3. RTX3090 显存优化配置（默认已优化，可按需调整）
RTX3090_OPTIMIZATION:
  max_batch_size: 4  # 单批次最大生成数量，3090 24G显存推荐不超过4
  max_resolution: 2048  # 单张图片最大分辨率，超过会自动分批次
  default_steps: 20  # 默认采样步数，平衡速度与质量
  enable_xformers: true  # 已默认在ComfyUI启动时开启，此处为参数校验

# ====================== 核心执行逻辑（OpenClaw自动执行，请勿修改） ======================
## 一、触发规则（OpenClaw自动识别，以下场景会自动调用本Skill）
1. 用户提及游戏美术、原画、素材、道具、角色、场景、特效、立绘、图标、技能光效等生成需求
2. 用户要求批量生成游戏相关的图片素材
3. 用户要求调用本地ComfyUI生成图片
4. 用户查询ComfyUI生成任务进度

## 二、执行步骤（严格按以下顺序执行）
### 步骤1：前置校验
1. 校验COMFYUI_BASE_URL是否可访问，若无法访问，直接提示用户：「请先启动本地ComfyUI服务，并确认配置的地址正确，当前无法访问 {{COMFYUI_BASE_URL}}」
2. 校验用户选择的asset_type是否有对应的工作流模板，若无，使用character默认模板
3. 校验batch_count是否超过max_batch_size，若超过，自动拆分多批次提交，避免爆显存
4. 校验分辨率是否超过max_resolution，若超过，提示用户并自动调整到推荐分辨率

### 步骤2：工作流动态参数替换
1. 提取用户输入的prompt、negative_prompt、width、height、batch_count、seed参数
2. 将参数填充到对应工作流模板的{{变量名}}占位符中
3. 替换工作流中的seed参数，-1为随机生成，固定数值直接使用
4. 替换工作流中的batch_size参数，适配用户输入的生成数量
5. 替换工作流中的width、height参数，适配用户输入的分辨率

### 步骤3：调用ComfyUI API提交生成任务
1. 请求地址：{{COMFYUI_BASE_URL}}/prompt
2. 请求方法：POST
3. 请求头：
   - Content-Type: application/json
   - 若COMFYUI_API_KEY不为空，添加 Authorization: Bearer {{COMFYUI_API_KEY}}
4. 请求体：
   ```json
   {
     "prompt": {{替换参数后的完整工作流JSON}},
     "client_id": "openclaw-game-art-generator"
   }