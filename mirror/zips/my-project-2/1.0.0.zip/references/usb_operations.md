# 凌柏本地 - 移动盘操作命令参考

> 本文件为 凌柏本地 Skill 的配套参考文档
> 提供移动盘导入/导出的具体命令示例
> （与凌霜柏雪共用相同命令规范）

---

## 1. 检测移动盘盘符

### PowerShell

```powershell
# 列出所有可移动磁盘（U盘/移动硬盘）
Get-WmiObject Win32_LogicalDisk | Where-Object {$_.DriveType -eq 2} | Select-Object DeviceID, VolumeName, Size, FreeSpace

# 输出示例：
# DeviceID  VolumeName    Size          FreeSpace
# --------  ----------    ----          ---------
# E:        我的U盘       31272730624   1073741824
```

### 命令提示符 (CMD)

```cmd
wmic logicaldisk where "DriveType=2" get DeviceID, VolumeName
```

---

## 2. 复制文件到移动盘

### 复制单个文件

```powershell
Copy-Item -Path "D:\工作文件\报告.docx" -Destination "E:\凌柏本地导出\" -Force
```

### 复制整个目录

```powershell
Copy-Item -Path "D:\工作文件\项目A\" -Destination "E:\凌柏本地导出\项目A\" -Recurse -Force
```

### 使用 robocopy（大文件推荐）

```powershell
robocopy "D:\工作文件" "E:\凌柏本地导出" /E /COPY:DAT /R:3 /W:5
```

参数说明：
- `/E` - 包含子目录（包括空目录）
- `/COPY:DAT` - 复制数据、属性、时间戳
- `/R:3` - 失败重试3次
- `/W:5` - 重试间隔5秒

---

## 3. 文件一致性校验

### 计算并对比文件哈希

```powershell
# 计算本地文件哈希
$localHash = Get-FileHash "D:\工作文件\报告.docx" -Algorithm SHA256

# 计算移动盘文件哈希
$usbHash = Get-FileHash "E:\凌柏本地导出\报告.docx" -Algorithm SHA256

# 对比
if ($localHash.Hash -eq $usbHash.Hash) {
    Write-Host "✅ 文件一致" -ForegroundColor Green
} else {
    Write-Host "❌ 文件不一致" -ForegroundColor Red
}
```

### 批量校验整个目录

```powershell
# 获取本地所有文件哈希
$localFiles = Get-ChildItem "D:\工作文件\" -Recurse -File | Get-FileHash -Algorithm SHA256

# 获取移动盘所有文件哈希
$usbFiles = Get-ChildItem "E:\凌柏本地导出\" -Recurse -File | Get-FileHash -Algorithm SHA256

# 对比（简化版）
foreach ($file in $localFiles) {
    $relativePath = $file.Path.Replace("D:\工作文件\", "")
    $usbPath = "E:\凌柏本地导出\" + $relativePath
    
    if (Test-Path $usbPath) {
        $usbHash = Get-FileHash $usbPath -Algorithm SHA256
        if ($file.Hash -eq $usbHash.Hash) {
            Write-Host "✅ $relativePath" -ForegroundColor Green
        } else {
            Write-Host "❌ $relativePath (哈希不匹配)" -ForegroundColor Red
        }
    } else {
        Write-Host "⚠️ $relativePath (移动盘不存在)" -ForegroundColor Yellow
    }
}
```

---

## 4. 创建目标目录

```powershell
# 创建带时间戳的目录
$timestamp = Get-Date -Format "yyyy-MM-dd"
New-Item -ItemType Directory -Force -Path "E:\凌柏本地导出\$timestamp"
```

---

## 5. 验证移动盘空间

```powershell
# 检查移动盘剩余空间是否足够
$usbDrive = Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='E:'"
$freeSpaceGB = [math]::Round($usbDrive.FreeSpace / 1GB, 2)
$neededSpaceGB = 1  # 估算需要的空间(GB)

if ($freeSpaceGB -gt $neededSpaceGB) {
    Write-Host "✅ 空间充足：剩余 $freeSpaceGB GB" -ForegroundColor Green
} else {
    Write-Host "❌ 空间不足：剩余 $freeSpaceGB GB" -ForegroundColor Red
}
```

---

## 6. 安全弹出移动盘

```powershell
# 安全弹出U盘（需要管理员权限）
$driveEject = New-Object -comObject Shell.Application
$driveEject.Namespace(17).ParseName("E:").InvokeVerb("Eject")
```

---

## 7. 凌柏本地完整导出流程

```powershell
# 凌柏本地移动盘导出脚本模板

param(
    [string]$SourcePath = "D:\工作文件",
    [string]$UsbDrive = "E:"
)

Write-Host "=== 凌柏本地移动盘导出工具 ===" -ForegroundColor Cyan

# 1. 检测移动盘
$usb = Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='$UsbDrive'"
if (-not $usb) {
    Write-Host "❌ 未检测到移动盘 $UsbDrive" -ForegroundColor Red
    exit 1
}
Write-Host "✅ 检测到移动盘：$UsbDrive ($($usb.VolumeName))" -ForegroundColor Green

# 2. 检查空间
$freeGB = [math]::Round($usb.FreeSpace / 1GB, 2)
Write-Host "📦 剩余空间：$freeGB GB" -ForegroundColor Cyan

# 3. 创建目标目录
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
$destPath = "$UsbDrive\凌柏本地导出_$timestamp"
New-Item -ItemType Directory -Force -Path $destPath | Out-Null
Write-Host "📁 创建目录：$destPath" -ForegroundColor Cyan

# 4. 复制文件
Write-Host "📋 开始复制..." -ForegroundColor Cyan
robocopy $SourcePath $destPath /E /COPY:DAT /R:3 /W:5 /NDL /NFL

# 5. 验证
Write-Host "🔍 验证文件一致性..." -ForegroundColor Cyan
$localFiles = Get-ChildItem $SourcePath -Recurse -File | Measure-Object
$usbFiles = Get-ChildItem $destPath -Recurse -File | Measure-Object

if ($localFiles.Count -eq $usbFiles.Count) {
    Write-Host "✅ 文件数量一致：$($usbFiles.Count) 个文件" -ForegroundColor Green
} else {
    Write-Host "⚠️ 文件数量不一致：本地 $($localFiles.Count) 个，移动盘 $($usbFiles.Count) 个" -ForegroundColor Yellow
}

# 6. 哈希校验（抽样）
Write-Host "🔐 执行哈希校验..." -ForegroundColor Cyan
$sampleFile = Get-ChildItem $SourcePath -Recurse -File | Select-Object -First 1
if ($sampleFile) {
    $localHash = Get-FileHash $sampleFile.FullName -Algorithm SHA256
    $usbSamplePath = $sampleFile.FullName.Replace($SourcePath, $destPath)
    if (Test-Path $usbSamplePath) {
        $usbHash = Get-FileHash $usbSamplePath -Algorithm SHA256
        if ($localHash.Hash -eq $usbHash.Hash) {
            Write-Host "✅ 哈希校验通过" -ForegroundColor Green
        } else {
            Write-Host "❌ 哈希校验失败" -ForegroundColor Red
        }
    }
}

Write-Host "=== 凌柏本地导出完成 ===" -ForegroundColor Cyan
Write-Host "本地备份：$SourcePath" -ForegroundColor Gray
Write-Host "移动盘副本：$destPath" -ForegroundColor Gray
```

---

## 8. 凌柏本地Qwen9B版移动盘操作注意事项

```markdown
## Qwen9B版特别提示

### 文件大小建议
- 单文件 < 100MB：直接复制
- 单文件 > 100MB：使用robocopy
- 批量文件：分批处理

### Token与文件关系
- 1MB文本 ≈ 500K tokens
- 移动盘操作不影响模型处理
- 导出前确保本地处理完成

### 推荐工作流
1. 本地处理 → 2. 校验结果 → 3. 复制到移动盘 → 4. 哈希验证
```

---

## 注意事项

1. **路径使用**：Windows 路径建议使用双反斜杠 `\\` 或单斜杠 `/`
2. **权限**：部分操作（如安全弹出）需要管理员权限
3. **中文路径**：PowerShell 对中文路径支持较好，CMD 可能有问题
4. **大文件**：超过 1GB 的文件建议使用 `robocopy` 而非 `Copy-Item`
5. **校验建议**：重要文件务必进行 SHA256 哈希校验

---

## 本地模型特别提示

在使用本地大模型配合移动盘导出时，建议：

1. **批量导出前先处理**：确保所有文件已在本地处理完成
2. **分批导出**：大量文件可分批导出，避免单次操作失败
3. **导出后校验**：本地模型处理的文件建议全部校验
4. **版本管理**：不同日期的导出建议分开目录存放

---

*文档版本：v1.1 | 配合 凌柏本地CLL Qwen3.5 9B优化版 Skill 使用*
*更新日期：2026-04-28*
