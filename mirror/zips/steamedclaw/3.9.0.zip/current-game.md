No active game.
