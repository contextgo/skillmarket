#!/usr/bin/env python3
"""
禅道项目需求管理脚本（HTTP API 版）
通过禅道页面内置 HTTP 接口管理项目需求（创建/编辑/删除），确保需求正确关联到项目

功能：
1. 创建需求：--action create --title "需求标题" --desc "描述" --pri 3
2. 编辑需求：--action edit --id 166 --title "新标题" --desc "新描述"
3. 删除需求：--action delete --id 166
4. 批量创建：--action create --input stories.json

优势：
- 速度快（1-2秒/条，vs 浏览器版 10-20秒/条）
- 无需 Playwright/Chromium
- 无需处理 iframe
- 纯 HTTP 请求，稳定可靠
"""

import argparse
import io
import json
import os
import re
import sys
import uuid
from pathlib import Path

# 修复 Windows 控制台编码问题，启用行缓冲确保日志实时输出
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace', line_buffering=True)

# 读取配置
SKILL_DIR = Path(__file__).parent.parent
CONFIG_FILE = SKILL_DIR / "config.json"


def load_config():
    """加载配置文件"""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "zentao_url": "",
        "zentao_user": "",
        "zentao_password": "",
        "default_project": 0,
        "default_product": 0
    }


def login(config):
    """
    通过禅道 REST API 登录获取 token（zentaosid）
    
    Returns:
        tuple: (requests.Session, token_str) 
    """
    import requests

    base_url = config["zentao_url"].rstrip("/")
    session = requests.Session()

    # 通过 REST API 获取 token
    token_url = f"{base_url}/api.php/v1/tokens"
    token_data = {
        "account": config["zentao_user"],
        "password": config["zentao_password"],
    }

    print(f"[INFO] 正在登录禅道...")
    resp = session.post(token_url, json=token_data)

    if resp.status_code not in (200, 201):
        raise Exception(f"登录失败，API状态码: {resp.status_code}, 响应: {resp.text[:200]}")

    token_result = resp.json()
    token = token_result.get("token", "")
    if not token:
        raise Exception(f"登录失败，未获取到token，响应: {json.dumps(token_result, ensure_ascii=False)[:200]}")

    print(f"[INFO] 登录成功，token: {token[:16]}...")

    # 设置 zentaosid cookie（禅道内置接口通过此 cookie 认证）
    session.cookies.set("zentaosid", token)
    session.cookies.set("lang", "zh-cn")
    session.cookies.set("device", "desktop")
    session.cookies.set("theme", "default")
    session.cookies.set("vision", "rnd")

    # 保存 token 供后续 API 查询使用
    session.token = token

    return session, token


# ============================================================
# 创建需求
# ============================================================

def create_story(session, config, title, desc="", pri=3, module=0,
                 project=None, product=None, status="draft"):
    """
    通过禅道内置接口创建项目需求

    URL: /zentao/story-create-{product}-{branch}-{module}-{parent}-{project}-{execution}-{plan}-{storyType}--story.html

    Args:
        session: requests.Session（已登录）
        config: 配置字典
        title: 需求标题（必填）
        desc: 需求描述
        pri: 优先级 1-4，默认 3
        module: 模块ID，默认 0
        project: 项目ID
        product: 产品ID
        status: 状态 draft=草稿, active=激活

    Returns:
        dict: {"success": bool, "story_id": int|None, "message": str, "url": str|None}
    """
    base_url = config["zentao_url"].rstrip("/")
    project = project or config.get("default_project", 0)
    product = product or config.get("default_product", 0)

    # 构建创建需求 URL
    branch = "all"
    parent = 0
    execution = 0
    plan = 0
    story_type = 0

    create_url = (
        f"{base_url}/story-create-{product}-{branch}-{module}-{parent}"
        f"-{project}-{execution}-{plan}-{story_type}--story.html"
    )

    # 生成 uid
    uid = uuid.uuid4().hex[:13]

    # 描述转 HTML 格式
    spec_html = _desc_to_html(desc)

    # 构建表单数据
    form_data = {
        "product": str(product),
        "module": str(module),
        "parent": "",
        "assignedTo": "",
        "category": "feature",
        "reviewer[]": "",
        "title": title,
        "color": "",
        "pri": str(pri),
        "estimate": "",
        "spec": spec_html,
        "uid": uid,
        "verify": "",
        "needNotReview": "1",
        "fileList": "[]",
        "type": "story",
        "status": status,
        "source": "",
        "sourceNote": "",
        "feedbackBy": "",
        "notifyEmail": "",
        "mailto[]": "",
        "contactList": "",
        "keywords": "",
        "grade": "1",
    }

    files = {"files[]": ("", b"", "application/octet-stream")}

    headers = {
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "*/*",
        "Referer": f"{base_url}/project-browse.html",
    }

    print(f"[INFO] 正在创建需求: {title}")
    resp = session.post(create_url, data=form_data, files=files, headers=headers, allow_redirects=False)

    return _parse_response(resp, session, config, title, product, project, "创建")


# ============================================================
# 编辑需求
# ============================================================

def edit_story(session, config, story_id, title=None, desc=None, pri=None,
               module=None, status=None, category=None, assignedTo=None,
               project=None):
    """
    通过禅道内置接口编辑需求

    URL: /zentao/story-edit-{storyID}-default-story.html?zin=1

    Args:
        session: requests.Session（已登录）
        config: 配置字典
        story_id: 需求ID（必填）
        title: 新标题（None=不修改）
        desc: 新描述（None=不修改）
        pri: 新优先级（None=不修改）
        module: 新模块ID（None=不修改）
        status: 新状态（None=不修改）
        category: 新分类（None=不修改）
        assignedTo: 指派给（None=不修改）
        project: 项目ID（用于构建链接）

    Returns:
        dict: {"success": bool, "story_id": int, "message": str}
    """
    base_url = config["zentao_url"].rstrip("/")
    project = project or config.get("default_project", 0)

    # 先获取当前需求数据（用于合并未修改的字段）
    current = _get_story_detail(session, config, story_id)
    if current:
        print(f"[INFO] 当前需求: title={current.get('title')}, pri={current.get('pri')}, status={current.get('status')}, module={current.get('module')}")
    else:
        print(f"[WARN] 无法获取需求 #{story_id} 当前数据，将仅提交提供的字段")

    # 编辑接口 URL
    edit_url = f"{base_url}/story-edit-{story_id}-default-story.html?zin=1"

    # 生成 uid
    uid = uuid.uuid4().hex[:13]

    # 合并当前值和修改值
    _title = title if title is not None else (current.get("title", "") if current else "")
    _pri = pri if pri is not None else (int(current.get("pri", 3)) if current else 3)
    _module = module if module is not None else (int(current.get("module", 0)) if current else 0)
    _status = status if status is not None else (current.get("status", "draft") if current else "draft")
    _category = category if category is not None else (current.get("category", "feature") if current else "feature")
    _raw_assignedTo = assignedTo if assignedTo is not None else (current.get("assignedTo", "") if current else "")
    # assignedTo 可能是 null、dict（如 {"account": "username", ...}）或字符串，需统一处理
    if isinstance(_raw_assignedTo, dict):
        _assignedTo = _raw_assignedTo.get("account", "")
    elif _raw_assignedTo:
        _assignedTo = str(_raw_assignedTo)
    else:
        _assignedTo = ""
    _stage = current.get("stage", "projected") if current else "projected"
    _estimate = current.get("estimate", "0") if current else "0"

    # 描述处理：如果有新描述则使用新描述，否则保留原描述
    if desc is not None:
        spec_html = _desc_to_html(desc)
    else:
        # 从当前数据中获取原描述
        spec_html = current.get("spec", "") if current else ""

    # 构建表单数据（从 curl 抓包分析）
    form_data = {
        "title": _title,
        "color": "",
        "needNotReview": "1",
        "spec": spec_html,
        "uid": uid,
        "verify": "",
        "comment": "",
        "module": str(_module),
        "parent": "",
        "plan": "",
        "source": "",
        "sourceNote": "",
        "status": _status,
        "stage": _stage,
        "category": _category,
        "pri": str(_pri),
        "estimate": str(_estimate),
        "feedbackBy": "",
        "notifyEmail": "",
        "keywords": "",
        "mailto[]": "",
        "contactList": "",
        "assignedTo": str(_assignedTo) if _assignedTo else "",
        "reviewer[]": "",
        "grade": "1",
    }

    headers = {
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "*/*",
        "Referer": f"{base_url}/projectstory-story-{project}.html",
    }

    # 构建修改描述
    changes = []
    if title is not None:
        changes.append(f"标题→{title}")
    if desc is not None:
        changes.append(f"描述→已更新")
    if pri is not None:
        changes.append(f"优先级→{pri}")
    if module is not None:
        changes.append(f"模块→{module}")
    if status is not None:
        changes.append(f"状态→{status}")
    if category is not None:
        changes.append(f"分类→{category}")
    if assignedTo is not None:
        changes.append(f"指派→{assignedTo}")

    print(f"[INFO] 正在编辑需求 #{story_id}: {', '.join(changes)}")

    # 编辑接口用 multipart/form-data（因为有 files[] 字段）
    # 需要单独处理 files 字段
    files_field = {"files[]": ("", b"", "application/octet-stream")}
    # 从 form_data 中移除 files[]，因为它需要通过 files 参数传递
    form_data.pop("files[]", None)

    resp = session.post(edit_url, data=form_data, files=files_field, headers=headers, allow_redirects=False)

    return _parse_response(resp, session, config, _title, config.get("default_product", 0), project, "编辑", story_id)


# ============================================================
# 删除需求
# ============================================================

def delete_story(session, config, story_id):
    """
    通过禅道 REST API 删除需求

    DELETE /zentao/api.php/v1/stories/{storyID}
    Header: Token: {token}

    Args:
        session: requests.Session（已登录）
        config: 配置字典
        story_id: 需求ID（必填）

    Returns:
        dict: {"success": bool, "story_id": int, "message": str}
    """
    base_url = config["zentao_url"].rstrip("/")

    if not hasattr(session, 'token') or not session.token:
        return {"success": False, "story_id": story_id, "message": "无 token，无法调用删除 API"}

    delete_url = f"{base_url}/api.php/v1/stories/{story_id}"
    headers = {"Token": session.token}

    print(f"[INFO] 正在删除需求 #{story_id}")
    resp = session.delete(delete_url, headers=headers)

    if resp.status_code in (200, 201):
        try:
            result = resp.json()
            if result.get("message") == "success":
                print(f"[INFO] 需求 #{story_id} 删除成功")
                return {"success": True, "story_id": story_id, "message": "删除成功"}
            else:
                return {"success": False, "story_id": story_id, "message": result.get("message", "未知错误")}
        except Exception:
            return {"success": False, "story_id": story_id, "message": f"响应解析失败: {resp.text[:200]}"}
    elif resp.status_code == 404:
        return {"success": False, "story_id": story_id, "message": "需求不存在"}
    else:
        return {"success": False, "story_id": story_id, "message": f"HTTP {resp.status_code}: {resp.text[:200]}"}


# ============================================================
# 查询需求
# ============================================================

def get_story(session, config, story_id):
    """
    通过禅道 REST API 获取需求详情

    GET /zentao/api.php/v1/stories/{storyID}
    Header: Token: {token}

    Args:
        session: requests.Session（已登录）
        config: 配置字典
        story_id: 需求ID

    Returns:
        dict: 需求详情，失败返回 None
    """
    base_url = config["zentao_url"].rstrip("/")

    if not hasattr(session, 'token') or not session.token:
        print(f"[WARN] 无 token，无法查询需求")
        return None

    api_url = f"{base_url}/api.php/v1/stories/{story_id}"
    headers = {"Token": session.token}

    try:
        resp = session.get(api_url, headers=headers, timeout=10)
        if resp.status_code in (200, 201):
            return resp.json()
    except Exception as e:
        print(f"[WARN] 查询需求异常: {e}")

    return None


# ============================================================
# 内部辅助函数
# ============================================================

def _desc_to_html(desc):
    """
    将描述文本转为禅道要求的 HTML 格式
    
    规则：
    - 如果描述已包含 HTML 标签（<h1>-<h6>, <p>, <ul>, <ol>, <table>, <div> 等），
      则视为原始 HTML 直接使用，原样返回
    - 纯文本描述则按换行分段，每段包裹 <p><span>...</span></p>
    """
    if not desc:
        return ""
    
    # 检测是否已包含 HTML 块级标签
    block_tags = re.compile(r'<(?:h[1-6]|p|ul|ol|li|table|tr|td|th|div|blockquote|hr)\b', re.IGNORECASE)
    if block_tags.search(desc):
        # 包含 HTML 标签，直接原样返回（描述文件已由 SKILL 规则构建好 HTML 结构）
        return desc
    else:
        # 纯文本，逐行包裹 <p><span>
        html_parts = []
        for line in desc.split('\n'):
            line = line.strip()
            if line:
                html_parts.append(f'<p><span>{line}</span></p>')
        return ''.join(html_parts) if html_parts else ""


def _get_story_id(session, config, title, product=None):
    """通过 API 查询获取刚创建的需求ID"""
    base_url = config["zentao_url"].rstrip("/")
    product = product or config.get("default_product", 0)

    if not hasattr(session, 'token') or not session.token:
        print(f"[WARN] 无 token，无法通过 API 查询需求ID")
        return None

    api_url = f"{base_url}/api.php/v1/products/{product}/stories?limit=10&sort=id_desc"
    headers = {"Token": session.token}

    try:
        resp = session.get(api_url, headers=headers, timeout=10)
        if resp.status_code in (200, 201):
            result = resp.json()
            stories = result.get("stories", [])

            # 精确匹配标题
            for s in stories:
                if s.get("title") == title:
                    story_id = int(s.get("id", 0))
                    print(f"[INFO] 查询到需求ID: {story_id} (标题匹配)")
                    return story_id

            # 模糊匹配
            for s in stories:
                s_title = s.get("title", "")
                if title in s_title or s_title in title:
                    story_id = int(s.get("id", 0))
                    print(f"[INFO] 查询到需求ID: {story_id} (模糊匹配)")
                    return story_id

            # 返回最新的一条
            if stories:
                story_id = int(stories[0].get("id", 0))
                print(f"[INFO] 返回最新需求ID: {story_id} (未精确匹配标题)")
                return story_id
    except Exception as e:
        print(f"[WARN] 查询需求ID异常: {e}")

    return None


def _get_story_detail(session, config, story_id):
    """获取需求详情（用于编辑时合并未修改字段）"""
    story = get_story(session, config, story_id)
    if story and isinstance(story, dict):
        return story
    return None


def _parse_response(resp, session, config, title, product, project, action, story_id=None):
    """解析禅道内置接口的响应（创建和编辑共用）"""
    if resp.status_code in (302, 301):
        location = resp.headers.get('Location', '')
        match = re.search(r'story-view-(\d+)', location)
        sid = int(match.group(1)) if match else story_id
        msg = f"{action}成功" if sid else f"{action}成功（重定向但未获取到ID）"
        url = f"{config['zentao_url'].rstrip('/')}/projectstory-view-{sid}-{project}.html" if sid else location
        return {"success": True, "story_id": sid, "message": msg, "url": url}

    elif resp.status_code == 200:
        try:
            result = resp.json()
        except Exception:
            return {"success": False, "story_id": story_id, "message": f"响应解析失败: {resp.text[:200]}"}

        if result.get("result") == "success":
            msg = result.get("message", f"{action}成功")
            # 创建时不返回ID，需查询获取
            if not story_id and action == "创建":
                story_id = _get_story_id(session, config, title, product)
            url = f"{config['zentao_url'].rstrip('/')}/projectstory-view-{story_id}-{project}.html" if story_id else None
            return {"success": True, "story_id": story_id, "message": msg, "url": url}
        else:
            error_msg = result.get("message", "未知错误")
            return {"success": False, "story_id": story_id, "message": error_msg}
    else:
        return {"success": False, "story_id": story_id, "message": f"HTTP {resp.status_code}: {resp.text[:200]}"}


# ============================================================
# 批量创建
# ============================================================

def create_stories_batch(stories, project=None, product=None):
    """
    批量创建项目需求

    Args:
        stories: 需求列表，每项包含 title, desc, pri, module
        project: 项目ID
        product: 产品ID

    Returns:
        dict: {"results": [...], "total": n, "success": n, "failed": n}
    """
    config = load_config()
    session, token = login(config)

    results = []
    for i, story in enumerate(stories, 1):
        title = story.get("title", "")
        if not title:
            results.append({"success": False, "title": "", "message": "需求标题不能为空", "index": i})
            continue

        print(f"\n--- [{i}/{len(stories)}] ---")
        result = create_story(
            session=session, config=config, title=title,
            desc=story.get("desc", ""), pri=story.get("pri", 3),
            module=story.get("module", 0), project=project, product=product,
            status="draft",
        )
        results.append({
            "success": result["success"], "story_id": result.get("story_id"),
            "title": title, "message": result.get("message", ""),
            "url": result.get("url"), "index": i,
        })

    success_count = sum(1 for r in results if r["success"])
    return {"results": results, "total": len(results), "success": success_count, "failed": len(results) - success_count}


# ============================================================
# CLI 入口
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="禅道项目需求管理（HTTP API版：创建/编辑/删除）")
    subparsers = parser.add_subparsers(dest="action", help="操作类型")

    # --- create 子命令 ---
    create_parser = subparsers.add_parser("create", help="创建需求")
    create_parser.add_argument("--title", "-t", help="需求标题")
    create_parser.add_argument("--desc", "-d", default="", help="需求描述")
    create_parser.add_argument("--desc-file", help="从文件读取需求描述（避免PowerShell解析HTML问题）")
    create_parser.add_argument("--pri", "-p", type=int, default=3, choices=[1, 2, 3, 4], help="优先级 1-4")
    create_parser.add_argument("--module", "-m", type=int, default=0, help="模块ID")
    create_parser.add_argument("--input", "-i", help="JSON 文件路径（批量模式）")
    create_parser.add_argument("--project", type=int, help="项目ID")
    create_parser.add_argument("--product", type=int, help="产品ID")
    create_parser.add_argument("--status", "-s", default="draft", choices=["draft", "active"], help="状态")
    create_parser.add_argument("--json", action="store_true", help="输出 JSON 格式")

    # --- edit 子命令 ---
    edit_parser = subparsers.add_parser("edit", help="编辑需求")
    edit_parser.add_argument("--id", type=int, required=True, help="需求ID（必填）")
    edit_parser.add_argument("--title", "-t", help="新标题")
    edit_parser.add_argument("--desc", "-d", help="新描述")
    edit_parser.add_argument("--desc-file", help="从文件读取新描述（避免PowerShell解析HTML问题）")
    edit_parser.add_argument("--pri", "-p", type=int, choices=[1, 2, 3, 4], help="新优先级")
    edit_parser.add_argument("--module", "-m", type=int, help="新模块ID")
    edit_parser.add_argument("--status", "-s", choices=["draft", "active", "closed", "changed"], help="新状态")
    edit_parser.add_argument("--category", choices=["feature", "performance", "security", "experience", "improve"], help="新分类")
    edit_parser.add_argument("--assignedTo", help="指派给")
    edit_parser.add_argument("--project", type=int, help="项目ID")
    edit_parser.add_argument("--json", action="store_true", help="输出 JSON 格式")

    # --- delete 子命令 ---
    delete_parser = subparsers.add_parser("delete", help="删除需求")
    delete_parser.add_argument("--id", type=int, required=True, help="需求ID（必填）")
    delete_parser.add_argument("--json", action="store_true", help="输出 JSON 格式")

    # --- get 子命令 ---
    get_parser = subparsers.add_parser("get", help="查询需求详情")
    get_parser.add_argument("--id", type=int, required=True, help="需求ID（必填）")
    get_parser.add_argument("--json", action="store_true", help="输出 JSON 格式")

    # --- sync 子命令 ---
    sync_parser = subparsers.add_parser("sync", help="同步需求文档到禅道")
    sync_parser.add_argument("--features", "-f", nargs="+", help="指定要同步的功能编号（如 F001 F002），不指定则同步全部")
    sync_parser.add_argument("--dry-run", action="store_true", help="试运行模式，仅显示计划不实际操作")
    sync_parser.add_argument("--doc", help="需求文档路径（覆盖config中的requirements_doc）")
    sync_parser.add_argument("--json", action="store_true", help="输出 JSON 格式")

    args = parser.parse_args()

    if not args.action:
        parser.print_help()
        sys.exit(1)

    # 登录
    config = load_config()
    try:
        session, token = login(config)
    except Exception as e:
        print(f"❌ 登录失败: {e}")
        sys.exit(1)

    # ---- 执行操作 ----
    if args.action == "create":
        _handle_create(args, session, config)
    elif args.action == "edit":
        _handle_edit(args, session, config)
    elif args.action == "delete":
        _handle_delete(args, session, config)
    elif args.action == "get":
        _handle_get(args, session, config)
    elif args.action == "sync":
        _handle_sync(args, session, config)


def _handle_create(args, session, config):
    """处理创建操作"""
    if args.input:
        # 批量模式
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"❌ 文件不存在: {args.input}")
            sys.exit(1)
        with open(input_path, 'r', encoding='utf-8') as f:
            stories = json.load(f)
        if not isinstance(stories, list):
            print("❌ JSON 文件内容必须是数组")
            sys.exit(1)
    elif args.title:
        desc = args.desc
        if args.desc_file:
            with open(args.desc_file, 'r', encoding='utf-8') as f:
                desc = f.read()
        stories = [{"title": args.title, "desc": desc, "pri": args.pri, "module": args.module}]
    else:
        print("❌ 请指定 --title（单条模式）或 --input（批量模式）")
        sys.exit(1)

    results = []
    for i, story in enumerate(stories, 1):
        title = story.get("title", "")
        if not title:
            results.append({"success": False, "title": "", "message": "标题不能为空", "index": i})
            continue

        print(f"\n--- [{i}/{len(stories)}] ---")
        result = create_story(
            session=session, config=config, title=title,
            desc=story.get("desc", ""), pri=story.get("pri", 3),
            module=story.get("module", 0), project=args.project,
            product=args.product, status=args.status,
        )
        results.append({
            "success": result["success"], "story_id": result.get("story_id"),
            "title": title, "message": result.get("message", ""),
            "url": result.get("url"), "index": i,
        })

    _print_results(results, args.json, "创建")


def _handle_edit(args, session, config):
    """处理编辑操作"""
    # 支持 --desc-file 从文件读取描述
    desc = args.desc
    if args.desc_file:
        with open(args.desc_file, 'r', encoding='utf-8') as f:
            desc = f.read()
    result = edit_story(
        session=session, config=config, story_id=args.id,
        title=args.title, desc=desc, pri=args.pri,
        module=args.module, status=args.status,
        category=args.category, assignedTo=args.assignedTo,
        project=args.project,
    )
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        if result["success"]:
            print(f"\n✅ 编辑需求 #{args.id} 成功")
            if result.get("url"):
                print(f"   链接: {result['url']}")
        else:
            print(f"\n❌ 编辑需求 #{args.id} 失败: {result.get('message', '未知错误')}")
            sys.exit(1)


def _handle_delete(args, session, config):
    """处理删除操作"""
    result = delete_story(session=session, config=config, story_id=args.id)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        if result["success"]:
            print(f"\n✅ 删除需求 #{args.id} 成功")
        else:
            print(f"\n❌ 删除需求 #{args.id} 失败: {result.get('message', '未知错误')}")
            sys.exit(1)


def _handle_get(args, session, config):
    """处理查询操作"""
    story = get_story(session=session, config=config, story_id=args.id)
    if story:
        if args.json:
            print(json.dumps(story, ensure_ascii=False, indent=2))
        else:
            print(f"\n📋 需求 #{args.id} 详情:")
            print(f"   标题: {story.get('title', 'N/A')}")
            print(f"   状态: {story.get('status', 'N/A')}")
            print(f"   优先级: {story.get('pri', 'N/A')}")
            print(f"   分类: {story.get('category', 'N/A')}")
            print(f"   模块: {story.get('module', 'N/A')}")
            print(f"   阶段: {story.get('stage', 'N/A')}")
            print(f"   创建人: {story.get('openedBy', {}).get('realname', story.get('openedBy', 'N/A'))}")
            print(f"   指派给: {story.get('assignedTo', 'N/A')}")
            spec = story.get('spec', '')
            if spec:
                # 去除HTML标签显示纯文本
                spec_text = re.sub(r'<[^>]+>', '', spec).strip()
                print(f"   描述: {spec_text[:200]}{'...' if len(spec_text) > 200 else ''}")
    else:
        print(f"\n❌ 查询需求 #{args.id} 失败")
        sys.exit(1)


def _handle_sync(args, session, config):
    """处理同步操作"""
    # 确定需求文档路径
    workspace = _find_workspace_root()
    doc_name = args.doc or config.get("requirements_doc", "")
    if not doc_name:
        print("❌ 未配置需求文档路径，请在 config.json 中设置 requirements_doc 或使用 --doc 参数")
        sys.exit(1)
    
    doc_path = workspace / doc_name
    if not doc_path.exists():
        print(f"❌ 需求文档不存在: {doc_path}")
        sys.exit(1)
    
    print(f"[INFO] 需求文档: {doc_path}")
    
    # 解析文档
    features = _parse_requirements_doc(doc_path)
    if not features:
        print("❌ 未在文档中发现功能标题（格式：### F001 - 功能名称）")
        sys.exit(1)
    
    # 显示同步计划
    print(f"\n📋 发现 {len(features)} 个功能：")
    for f in features:
        if f["zentao_id"]:
            print(f"   ✏️  {f['feature_id']} - {f['title']} → 编辑 #{f['zentao_id']}")
        else:
            print(f"   ➕ {f['feature_id']} - {f['title']} → 新建")
    
    # 如果指定了 features 过滤
    features_filter = args.features if args.features else None
    if features_filter:
        matched = [f for f in features if f["feature_id"] in features_filter]
        unmatched = set(features_filter) - set(f["feature_id"] for f in features)
        if unmatched:
            print(f"[WARN] 未找到功能: {', '.join(unmatched)}")
    
    # 执行同步
    results = sync_requirements(
        session=session, config=config, doc_path=doc_path,
        features_filter=features_filter, dry_run=args.dry_run,
    )
    
    # 打印结果
    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        print(f"\n{'=' * 50}")
        create_count = sum(1 for r in results if r["action"] == "create" and r["success"])
        edit_count = sum(1 for r in results if r["action"] == "edit" and r["success"])
        fail_count = sum(1 for r in results if not r["success"])
        print(f"同步完成：新建 {create_count} 条，编辑 {edit_count} 条，失败 {fail_count} 条")
        print(f"{'=' * 50}")
        for r in results:
            action_str = "新建" if r["action"] == "create" else "编辑"
            sid = r.get("story_id", "?")
            if r["success"]:
                print(f"  ✅ {r['feature_id']} - {r['title']} ({action_str} #{sid})")
            else:
                print(f"  ❌ {r['feature_id']} - {r['title']} ({action_str}失败: {r.get('message', '')})")
        
        if fail_count > 0:
            sys.exit(1)


def _print_results(results, json_output, action_name):
    """打印操作结果汇总"""
    success_count = sum(1 for r in results if r["success"])
    summary = {
        "results": results, "total": len(results),
        "success": success_count, "failed": len(results) - success_count,
    }

    if json_output:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    else:
        print(f"\n{'=' * 50}")
        print(f"{action_name}完成：共 {summary['total']} 条，成功 {summary['success']} 条，失败 {summary['failed']} 条")
        print(f"{'=' * 50}")
        for r in results:
            idx = r.get("index", "?")
            if r["success"]:
                print(f"  ✅ [{idx}] {r['title']}")
                if r.get("story_id"):
                    print(f"     ID: {r['story_id']}  链接: {r.get('url', 'N/A')}")
                else:
                    print(f"     状态: {r.get('message', f'{action_name}成功')}")
            else:
                print(f"  ❌ [{idx}] {r.get('title', 'N/A')}")
                print(f"     错误: {r.get('message', '未知错误')}")

        if summary["failed"] > 0:
            sys.exit(1)


# ============================================================
# 需求文档解析与同步
# ============================================================

def _find_workspace_root():
    """查找工作区根目录"""
    # 从技能目录往上两级到工作区根
    candidate = SKILL_DIR.parent
    if (candidate / "zentao-story-api").exists():
        return candidate
    return SKILL_DIR.parent


def _parse_requirements_doc(doc_path):
    """
    解析需求文档，提取所有功能及其禅道ID
    
    Returns:
        list: [{"feature_id": "F001", "title": "章节分工", "zentao_id": 155, "line_number": 40, "content": "..."}]
              zentao_id 为 None 表示尚未创建禅道需求
    """
    with open(doc_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    features = []
    # 匹配功能标题：### F001 - 功能名称 或 ### F001 - 功能名称（#155）
    # 支持中英文括号，标题中可能有其他括号内容
    feature_pattern = re.compile(
        r'^###\s+(F\d+)\s*[-–—]\s*(.+?)\s*[（(]#(\d+)[）)]\s*$'
    )
    # 无禅道ID的标题
    feature_pattern_no_id = re.compile(
        r'^###\s+(F\d+)\s*[-–—]\s*(.+?)\s*$'
    )
    
    for line_no, line in enumerate(lines, 1):
        stripped = line.strip()
        # 先尝试匹配有禅道ID的标题
        match = feature_pattern.match(stripped)
        if match:
            feature_id = match.group(1)
            title = match.group(2).strip()
            zentao_id = int(match.group(3))
            features.append({
                "feature_id": feature_id,
                "title": title,
                "zentao_id": zentao_id,
                "line_number": line_no,
                "raw_line": line.rstrip(),
            })
            continue
        
        # 再尝试匹配无禅道ID的标题
        match = feature_pattern_no_id.match(stripped)
        if match:
            # 确认不是已有ID的（避免二次匹配）
            feature_id = match.group(1)
            title = match.group(2).strip()
            # 排除已包含 (#ID) 的情况（理论上已被上面的pattern捕获）
            if not re.search(r'[（(]#\d+[）)]', title):
                features.append({
                    "feature_id": feature_id,
                    "title": title,
                    "zentao_id": None,
                    "line_number": line_no,
                    "raw_line": line.rstrip(),
                })
    
    return features


def _extract_feature_content(doc_path, feature_line_no):
    """
    提取某个功能标题下的全部内容（到下一个同级或更高级标题为止）
    
    Returns:
        str: 该功能下的 Markdown 内容（不含标题行本身）
    """
    with open(doc_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    content_lines = []
    started = False
    
    for i, line in enumerate(lines):
        line_no = i + 1
        if line_no == feature_line_no:
            started = True
            continue  # 跳过标题行本身
        
        if started:
            # 遇到下一个 ### 或 ## 或 # 标题，停止
            if re.match(r'^#{1,3}\s', line):
                break
            content_lines.append(line)
    
    return ''.join(content_lines).strip()


def _md_to_html(md_content):
    """
    将 Markdown 格式的需求描述转为禅道 HTML 格式
    
    遵循写作规范：不写英文字段名、不写UI样式细节
    """
    if not md_content.strip():
        return ""
    
    lines = md_content.split('\n')
    html_parts = []
    i = 0
    
    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()
        
        # 空行跳过
        if not stripped:
            i += 1
            continue
        
        # 引用行 (> 开头) → 用户故事
        if stripped.startswith('> '):
            text = stripped[2:].strip()
            # 如果是第一段引用，添加用户故事标题
            if not any('<h3>用户故事</h3>' in p for p in html_parts):
                html_parts.append('<h3>用户故事</h3>')
            html_parts.append(f'<p>{_md_inline_to_html(text)}</p>')
            i += 1
            continue
        
        # #### 标题 → <h3>
        if stripped.startswith('#### '):
            title = stripped[5:].strip()
            html_parts.append(f'<h3>{_md_inline_to_html(title)}</h3>')
            i += 1
            continue
        
        # 有序列表
        if re.match(r'^\d+\.\s', stripped):
            ol_items = []
            while i < len(lines) and re.match(r'^\s*\d+\.\s', lines[i].strip()):
                item_text = re.sub(r'^\s*\d+\.\s+', '', lines[i].strip())
                # 检查是否是嵌套列表
                ol_items.append(_md_inline_to_html(item_text))
                i += 1
            html_parts.append('<ol>')
            for item in ol_items:
                html_parts.append(f'<li>{item}</li>')
            html_parts.append('</ol>')
            continue
        
        # 无序列表
        if stripped.startswith('- ') or stripped.startswith('* '):
            ul_items = []
            while i < len(lines):
                li = lines[i].rstrip()
                li_stripped = li.strip()
                if li_stripped.startswith('- ') or li_stripped.startswith('* '):
                    item_text = re.sub(r'^[\s]*[-*]\s+', '', li)
                    # 检查嵌套缩进（子列表）
                    if li.startswith('   ') and ul_items:
                        # 嵌套项，追加到上一个item中
                        ul_items[-1] += f'<ul><li>{_md_inline_to_html(item_text.strip())}</li></ul>'
                    else:
                        ul_items.append(_md_inline_to_html(item_text.strip()))
                    i += 1
                else:
                    break
            html_parts.append('<ul>')
            for item in ul_items:
                html_parts.append(f'<li>{item}</li>')
            html_parts.append('</ul>')
            continue
        
        # 表格
        if stripped.startswith('|'):
            table_lines = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                table_lines.append(lines[i].strip())
                i += 1
            html_parts.append(_md_table_to_html(table_lines))
            continue
        
        # 普通段落
        html_parts.append(f'<p>{_md_inline_to_html(stripped)}</p>')
        i += 1
    
    return '\n'.join(html_parts)


def _md_inline_to_html(text):
    """Markdown 行内格式转 HTML"""
    # **加粗** → <b>加粗</b>
    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
    # *斜体* → <i>斜体</i>
    text = re.sub(r'\*(.+?)\*', r'<i>\1</i>', text)
    # `代码` → <code>代码</code>
    text = re.sub(r'`(.+?)`', r'<code>\1</code>', text)
    # [链接](url) → <a href="url">链接</a>
    text = re.sub(r'\[(.+?)\]\((.+?)\)', r'<a href="\2">\1</a>', text)
    return text


def _md_table_to_html(table_lines):
    """Markdown 表格转 HTML 表格"""
    if len(table_lines) < 2:
        return ''
    
    rows = []
    for line in table_lines:
        # 跳过分隔行 (|---|---|)
        if re.match(r'^\|[\s\-:|]+\|$', line):
            continue
        cells = [c.strip() for c in line.strip('|').split('|')]
        rows.append(cells)
    
    if not rows:
        return ''
    
    html = '<table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse;width:100%;">'
    
    # 第一行作为表头
    html += '<tr>'
    for cell in rows[0]:
        html += f'<th>{_md_inline_to_html(cell)}</th>'
    html += '</tr>'
    
    # 其余行作为数据行
    for row in rows[1:]:
        html += '<tr>'
        for cell in row:
            html += f'<td>{_md_inline_to_html(cell)}</td>'
        html += '</tr>'
    
    html += '</table>'
    return html


def _write_back_zentao_id(doc_path, feature_id, zentao_id):
    """
    将禅道需求ID回写到需求文档的功能标题中
    ### F001 - 章节分工 → ### F001 - 章节分工（#155）
    ### F001 - 章节分工（个人空间无此功能） → ### F001 - 章节分工（个人空间无此功能）（#155）
    """
    with open(doc_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 匹配功能标题（无禅道ID的），确保标题末尾没有 (#数字) 格式
    pattern = re.compile(
        rf'^(###\s+{feature_id}\s*[-–—]\s*.+?)(\s*)$',
        re.MULTILINE
    )
    
    match = pattern.search(content)
    if match:
        old_title = match.group(1)
        # 如果已有ID标注则不重复添加
        if re.search(r'[（(]#\d+[）)]', old_title):
            return False
        new_title = f"{old_title}（#{zentao_id}）"
        content = content[:match.start()] + new_title + content[match.end():]
        
        with open(doc_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    return False


def sync_requirements(session, config, doc_path, features_filter=None, dry_run=False):
    """
    同步需求文档到禅道
    
    Args:
        session: requests.Session（已登录）
        config: 配置字典
        doc_path: 需求文档路径
        features_filter: 指定同步的功能编号列表（如 ["F001", "F002"]），None=全部
        dry_run: 试运行模式
    
    Returns:
        list: 同步结果列表
    """
    features = _parse_requirements_doc(doc_path)
    
    if features_filter:
        features = [f for f in features if f["feature_id"] in features_filter]
    
    if not features:
        print("[WARN] 未找到需要同步的功能")
        return []
    
    results = []
    
    for i, feature in enumerate(features, 1):
        fid = feature["feature_id"]
        title = feature["title"]
        zentao_id = feature["zentao_id"]
        full_title = f"{fid} - {title}"
        
        print(f"\n--- [{i}/{len(features)}] {full_title} ---")
        
        # 提取该功能的内容并转为HTML
        content = _extract_feature_content(doc_path, feature["line_number"])
        desc_html = _md_to_html(content)
        
        if zentao_id:
            # 已有禅道ID → 编辑
            print(f"[INFO] 编辑禅道需求 #{zentao_id}")
            if dry_run:
                print(f"[DRY-RUN] 将编辑需求 #{zentao_id}: {full_title}")
                results.append({"success": True, "feature_id": fid, "action": "edit", "story_id": zentao_id, "title": full_title, "message": "dry-run"})
                continue
            result = edit_story(session, config, story_id=zentao_id, desc=desc_html)
            results.append({
                "success": result["success"], "feature_id": fid,
                "action": "edit", "story_id": zentao_id,
                "title": full_title, "message": result.get("message", ""),
            })
        else:
            # 无禅道ID → 创建
            print(f"[INFO] 创建新禅道需求: {full_title}")
            if dry_run:
                print(f"[DRY-RUN] 将创建需求: {full_title}")
                results.append({"success": True, "feature_id": fid, "action": "create", "story_id": None, "title": full_title, "message": "dry-run"})
                continue
            result = create_story(session, config, title=full_title, desc=desc_html, pri=1, status="draft")
            new_id = result.get("story_id")
            results.append({
                "success": result["success"], "feature_id": fid,
                "action": "create", "story_id": new_id,
                "title": full_title, "message": result.get("message", ""),
            })
            # 创建成功后回写ID到文档
            if result["success"] and new_id:
                if _write_back_zentao_id(doc_path, fid, new_id):
                    print(f"[INFO] 已将禅道ID #{new_id} 回写到需求文档 {fid}")
                else:
                    print(f"[WARN] 回写禅道ID #{new_id} 到 {fid} 失败")
    
    return results


if __name__ == "__main__":
    main()
