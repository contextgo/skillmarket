---
name: html-to-mhtml
description: 网页转MHTML存档工具。当用户说"html转mhtml"、"网页保存为mhtml"、"网页转mhtml"、"保存网页"、"网页存档"、"离线保存网页"、"把网址转成mhtml"、"下载网页为单文件"时使用此skill。英文关键词：mhtml, mht, webpage archive, save webpage offline.
---

# HTML to MHTML Converter

Convert any webpage into a single .mhtml file, embedding all resources (images, CSS, JS) for offline viewing. Output format is compatible with Chrome/Edge browsers.

## Usage

```bash
python ~/.qclaw/skills/html-to-mhtml/scripts/html_to_mhtml.py "<URL>" [output.mhtml]
```

**Examples:**

```bash
# Save to auto-generated filename
python html_to_mhtml.py "https://example.com"

# Specify output filename
python html_to_mhtml.py "https://news.ycombinator.com" "hn_archive.mhtml"

# Save Chinese webpage
python html_to_mhtml.py "https://www.baidu.com" "baidu_home.mhtml"
```

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| URL | Yes | Webpage URL to convert |
| output | No | Output .mhtml filename (auto-generated if omitted) |

## Features

- Downloads complete webpage with all linked resources
- Embeds images, CSS, JavaScript into single file
- **Chrome-compatible MHTML format** (Blink format)
- Quoted-printable encoding for text, base64 for binary
- Proper Content-ID and cid: reference handling
- Opens in Chrome, Edge, and other MHTML-compatible browsers

## Dependencies

```bash
pip install -r requirements.txt
```

## Technical Notes

The script generates MHTML in Chrome's native format:
- `From: <Saved by Blink>` header
- `Snapshot-Content-Location` for original URL
- `quoted-printable` encoding for HTML/CSS/JS
- `base64` encoding for images and binary files
- Proper `Content-ID: <xxx@mhtml.blink>` format

## Workflow

1. User provides URL
2. Run script: `python html_to_mhtml.py "<URL>"`
3. Return path to created .mhtml file
