# scientific-critical-thinking 科学批判性思维

## 三个文件分别干什么

- `SKILL.md`：AI 运行时使用，定义技能做什么、何时触发、如何工作（7 个核心能力）
- `meta.yaml`：治理和静态检查使用，不直接参与 Cursor 触发
- `references/`：AI 按需读取的背景知识，每个文件对应一个评估维度

## references 文件说明

| 文件 | 内容 |
|------|------|
| `scientific_method.md` | 科学方法核心原则：经验主义、可证伪性、可重复性、因果推断标准、开放科学 |
| `common_biases.md` | 科学研究中的偏倚大全（23类），含认知偏倚、实验偏倚、统计偏倚，每类附检测与缓解策略 |
| `statistical_pitfalls.md` | 统计常见误区（42个），含 P 值误解、多重比较、样本量问题、效应大小、回归陷阱 |
| `evidence_hierarchy.md` | 证据层级（7级）、GRADE 系统（4级）、批判性评价工具、实用决策框架 |
| `logical_fallacies.md` | 逻辑谬误大全（38个），含因果谬误、泛化谬误、权威谬误、结构谬误、科学特定谬误 |
| `experimental_design.md` | 实验设计全流程检查清单，从研究问题到伦理批准，覆盖设计、测量、分析、报告全阶段 |

## 来源

原版来自 K-Dense Inc.（MIT License），已完整翻译为中文并适配 tuke_v1 skill 规范。
