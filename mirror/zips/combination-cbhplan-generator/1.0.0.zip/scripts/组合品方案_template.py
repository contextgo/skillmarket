"""
组合品方案生成脚本 - 模板
用法：复制此脚本，改名，按以下步骤填写 SECTION 1-3，然后执行
生成：组合品配置表.xlsx
"""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

wb = Workbook()
ws = wb.active
ws.title = "组合品配置表"

# ============================================================
# SECTION 1: 核心品信息（必填）
# ============================================================
CORE = {
    'name':  '',   # 商品全称
    'upc':   '',   # 饿了么UPC
    'cost':  0.0,  # 配送价（成本）
    'price': 0.0,   # 线上原价
    'code':  '',   # 国信编码（如有）
}
CORE_NAME = ''    # 简称（用于文件名，如"布洛芬芬必得"）
START_ID  = ''    # 起始编号（如C53）
COLOR     = '8B0000'  # 主色调（深红/深蓝/深绿等）

# ============================================================
# SECTION 2: 搭配品（选10个，从价格表搜索）
# ============================================================
PRODUCTS = {
    'p1':  ('搭配品1商品名',  'UPC',  配送价, 线上原价),
    'p2':  ('搭配品2商品名',  'UPC',  配送价, 线上原价),
    'p3':  ('搭配品3商品名',  'UPC',  配送价, 线上原价),
    'p4':  ('搭配品4商品名',  'UPC',  配送价, 线上原价),
    'p5':  ('搭配品5商品名',  'UPC',  配送价, 线上原价),
    'p6':  ('搭配品6商品名',  'UPC',  配送价, 线上原价),
    'p7':  ('搭配品7商品名',  'UPC',  配送价, 线上原价),
    'p8':  ('搭配品8商品名',  'UPC',  配送价, 线上原价),
    'p9':  ('搭配品9商品名',  'UPC',  配送价, 线上原价),
    'p10': ('搭配品10商品名', 'UPC',  配送价, 线上原价),
}

# 搭配品国信编码（未知则填空''）
CODE_MAP = {
    'core': CORE['code'],
    'p1': '', 'p2': '', 'p3': '', 'p4': '', 'p5': '',
    'p6': '', 'p7': '', 'p8': '', 'p9': '', 'p10': '',
}

# ============================================================
# SECTION 3: 10个组合（元组列表）
# (编号, 组合名称, 组合主题, 适用场景, 售价)
# ============================================================
_COMBOS_RAW = [
    ('C53','【组合名】','核心品卖点+搭配品卖点','适用症状1、症状2','售价'),
    # ... 共10条
]

# ============================================================
# 以下代码自动计算，无需修改
# ============================================================
import os

def gm_rate(cost, sell):
    return round((sell - cost) / sell * 100, 1)

COMBO_PRODUCTS = {
    f'C{53+i}': [f'core', f'p{i+1}'] for i in range(10)
}

COMBOS = []
for pid, name, theme, scene, sell_str in _COMBOS_RAW:
    pkeys = COMBO_PRODUCTS[pid]
    items_cost = CORE['cost'] + PRODUCTS[f'p{pid[-2:].lstrip("0") or "10"}'][2] if pid in COMBO_PRODUCTS else 0
    # 简化：直接按顺序取
    idx = int(pid[1:]) - 53  # 0-9
    pkey = f'p{idx+1}'
    items_cost = CORE['cost'] + PRODUCTS[pkey][2]
    sell = float(sell_str)
    combo_total_orig = CORE['price'] + PRODUCTS[pkey][3]
    saving = round(combo_total_orig - sell, 2)
    rate = gm_rate(items_cost, sell)
    COMBOS.append({
        'id': pid, 'name': name, 'theme': theme, 'scene': scene,
        'sell': sell, 'cost': round(items_cost, 2),
        'orig': round(combo_total_orig, 2), 'saving': saving,
        'rate': f'{rate}%', 'pkey': pkey,
    })

# 样式
COLOR_DARK  = COLOR
COLOR_LIGHT = 'C0392B'
TITLE_FILL  = PatternFill('solid', fgColor=COLOR_DARK)
HEADER_FILL = PatternFill('solid', fgColor=COLOR_LIGHT)
ALT_FILL    = PatternFill('solid', fgColor='FFF5F5')
WHITE_FILL  = PatternFill('solid', fgColor='FFFFFF')
SELL_FILL   = PatternFill('solid', fgColor='FFF9E6')
RATE_FILL   = PatternFill('solid', fgColor='E8F5E9')
TITLE_FONT  = Font(bold=True, size=13, color='FFFFFF', name='微软雅黑')
HEADER_FONT = Font(bold=True, size=10, color='FFFFFF', name='微软雅黑')
BODY_FONT   = Font(size=9, name='微软雅黑')
SELL_FONT   = Font(bold=True, size=10, color=COLOR_DARK, name='微软雅黑')
thin = Side(style='thin', color='E0C0C0')
THIN_BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
CENTER = Alignment(horizontal='center', vertical='center', wrap_text=True)
LEFT   = Alignment(horizontal='left',   vertical='center', wrap_text=True)

def cell(ws, r, c, value, font=None, fill=None, align=None, border=None, num_fmt=None):
    cl = ws.cell(r, c, value)
    if font:   cl.font = font
    if fill:   cl.fill = fill
    if align:  cl.alignment = align
    if border: cl.border = border
    if num_fmt: cl.number_format = num_fmt
    return cl

# 标题行
ws.row_dimensions[1].height = 32
ws.merge_cells('A1:M1')
c = ws['A1']
c.value = f'{CORE_NAME} × 搭配单品 | 组合编号{START_ID}-C{int(START_ID[1:])+9} | 2026'
c.font = TITLE_FONT; c.fill = TITLE_FILL; c.alignment = CENTER

# 表头
headers = [
    '编号','组合名称','组合主题','适用场景',
    '单品成本\n合计','组合售价','顾客\n节省','毛利率\n预估',
    f'{CORE_NAME}','编码',
    '搭配商品','编码','状态'
]
ws.row_dimensions[2].height = 36
for ci, h in enumerate(headers, 1):
    cell(ws, 2, ci, h, font=HEADER_FONT, fill=HEADER_FILL,
         align=CENTER, border=THIN_BORDER)

# 数据行
for ri, combo in enumerate(COMBOS, 3):
    ws.row_dimensions[ri].height = 52
    pid   = combo['id']
    pkey  = combo['pkey']
    p2    = PRODUCTS[pkey]

    fill = ALT_FILL if ri % 2 == 1 else WHITE_FILL
    row_data = [
        pid, combo['name'], combo['theme'], combo['scene'],
        combo['cost'], combo['sell'], combo['saving'], combo['rate'],
        CORE['name'], CODE_MAP['core'],
        p2[0], CODE_MAP[pkey],
        '待生效',
    ]
    for ci, val in enumerate(row_data, 1):
        align = CENTER if ci in (1,5,6,7,8,10,12,13) else LEFT
        c2 = cell(ws, ri, ci, val, font=BODY_FONT, fill=fill,
                  align=align, border=THIN_BORDER)
        if ci == 6:
            c2.font = SELL_FONT; c2.fill = SELL_FILL; c2.number_format = '#,##0.00'
        if ci in (5,7):
            c2.number_format = '#,##0.00'
        if ci == 8:
            c2.fill = RATE_FILL
            c2.font = Font(bold=True, size=9, color='2E7D32', name='微软雅黑')

# 列宽 + 冻结
col_widths = [7, 26, 28, 32, 10, 10, 9, 9, 28, 10, 28, 10, 10]
for i, w in enumerate(col_widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = 'A3'

# 保存
out = rf'C:\Users\33613\WorkBuddy\阿品-Claw\组合品方案\{CORE_NAME}组合品配置表_{START_ID}-C{int(START_ID[1:])+9}.xlsx'
wb.save(out)
print('保存成功:', out)
print()
print('=== 组合摘要 ===')
for combo in COMBOS:
    status = 'OK' if combo['saving'] > 0 else '!!顾客亏损!!'
    print(f"{combo['id']} {combo['name']} | 售价{combo['sell']} | 成本{combo['cost']} | 毛利{combo['rate']} | 顾客省{combo['saving']} | {status}")
