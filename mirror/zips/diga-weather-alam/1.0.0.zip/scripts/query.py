# -*- coding: utf-8 -*-
"""
高影响天气预警查询脚本 - 未来7天逐日高影响天气预警
支持全国3343个区县级城市
"""

import sys
import json
import urllib.request
import urllib.error
import ssl
from datetime import datetime, timedelta

# 导入内置城市映射表
from cities import CITY_MAP

# 腾讯云COS基础URL
COS_BASE_URL = "https://diga2026-1252033877.cos.ap-beijing.myqcloud.com/product/"

# 创建SSL上下文
SSL_CONTEXT = ssl.create_default_context()
SSL_CONTEXT.check_hostname = False
SSL_CONTEXT.verify_mode = ssl.CERT_NONE

# 预警类型映射
WARNING_TYPES = {
    "台风": "台风",
    "暴雨": "暴雨",
    "暴雪": "暴雪",
    "寒潮": "寒潮",
    "大风": "大风",
    "沙尘暴": "沙尘暴",
    "高温": "高温",
    "干旱": "干旱",
    "雷电": "雷电",
    "冰雹": "冰雹",
    "霜冻": "霜冻",
    "大雾": "大雾",
    "霾": "霾",
    "道路结冰": "道路结冰",
    "干热风": "干热风",
    "低温雨雪冰冻": "低温雨雪冰冻",
    "海上大风": "海上大风",
    "强对流": "强对流",
    "降水": "降水",
}


def fuzzy_match_city(city_name, city_map):
    """模糊匹配城市名"""
    if not city_name:
        return None, None

    # 精确匹配
    if city_name in city_map:
        return city_map[city_name], city_name

    # 包含匹配
    matches = [(name, cid) for name, cid in city_map.items() if city_name in name]
    if matches:
        return matches[0][1], matches[0][0]

    # 前缀匹配
    matches = [(name, cid) for name, cid in city_map.items() if name.startswith(city_name)]
    if matches:
        return matches[0][1], matches[0][0]

    return None, None


def fetch_warning_data(city_id):
    """从腾讯云COS获取天气预警数据"""
    url = f"{COS_BASE_URL}{city_id}warn.json"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10, context=SSL_CONTEXT) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError:
        return None
    except Exception as e:
        raise Exception(f"获取数据失败: {str(e)}")


def get_weekday_cn(date_str):
    """获取星期几的中文名称"""
    try:
        weekday_map = {
            0: "周一",
            1: "周二",
            2: "周三",
            3: "周四",
            4: "周五",
            5: "周六",
            6: "周日",
        }
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        return weekday_map[dt.weekday()]
    except:
        return ""


def parse_warning_content(content):
    """解析预警内容字符串"""
    warnings = []

    if not content or content == "无预警":
        return warnings

    # 统一分隔符
    content = content.replace("：", ":")

    # 首先尝试用 | 分割为多个预警组
    groups = content.split(" | ")

    for group in groups:
        group = group.strip()
        if not group:
            continue

        # 分割各预警项（用；或;分隔）
        parts = group.replace("；", ";").split(";")

        for part in parts:
            part = part.strip()
            if not part:
                continue

            # 查找时段格式：XX-XX时:类型 或 XX时:类型
            # 使用正则匹配
            import re
            match = re.match(r"^(?:(\d+-\d+|\d+)时)?:?(.+)$", part)
            if match:
                time_range = match.group(1)
                if time_range:
                    time_range = time_range + "时"
                warning_type = match.group(2).strip()
            else:
                time_range = ""
                warning_type = part

            if warning_type:
                # 清理预警类型
                warning_type = warning_type.strip(":").strip()
                if warning_type:
                    warnings.append({
                        "time_range": time_range,
                        "type": warning_type
                    })

    return warnings


def format_warning_item(item, date):
    """格式化单条预警信息"""
    weekday = get_weekday_cn(date)
    parsed = parse_warning_content(item.get("warning2", ""))

    return {
        "date": date,
        "weekday": weekday,
        "original_content": item.get("warning2", ""),
        "parsed_warnings": parsed,
    }


def query_warning(city_name, warning_type=None, days=7):
    """查询天气预警

    Args:
        city_name: 城市名称
        warning_type: 预警类型筛选（可选）
        days: 查询天数，默认7天

    Returns:
        查询结果字典
    """
    city_id, matched_name = fuzzy_match_city(city_name, CITY_MAP)
    if not city_id:
        raise ValueError(f"未找到城市: {city_name}\n请检查城市名称是否正确。")

    data = fetch_warning_data(city_id)
    if data is None:
        return {
            "code": 0,
            "message": "success",
            "data": {
                "city_id": city_id,
                "city_name": matched_name,
                "has_warning": False,
                "total_days": days,
                "warnings": [],
            }
        }

    # 解析数据
    all_warnings = []
    if isinstance(data, list):
        for item in data:
            formatted = format_warning_item(item, item.get("date", ""))
            if formatted["original_content"] != "无预警":
                all_warnings.append(formatted)
    elif isinstance(data, dict):
        warning_list = data.get("warnList") or data.get("warnings") or []
        for item in warning_list:
            all_warnings.append(format_warning_item(item, item.get("date", "")))

    # 按日期筛选（未来days天）
    today = datetime.now().strftime("%Y-%m-%d")
    end_date = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")

    filtered_warnings = [
        w for w in all_warnings
        if today <= w["date"] <= end_date
    ]

    # 按类型筛选
    if warning_type:
        filtered_warnings = [
            {
                "date": w["date"],
                "weekday": w["weekday"],
                "original_content": w["original_content"],
                "parsed_warnings": [
                    pw for pw in w["parsed_warnings"]
                    if warning_type in pw["type"]
                ]
            }
            for w in filtered_warnings
        ]
        # 过滤掉没有匹配预警的日期
        filtered_warnings = [
            w for w in filtered_warnings
            if w["parsed_warnings"]
        ]

    # 按日期排序
    filtered_warnings.sort(key=lambda x: x["date"])

    return {
        "code": 0,
        "message": "success",
        "data": {
            "city_id": city_id,
            "city_name": matched_name,
            "has_warning": len(filtered_warnings) > 0,
            "total_days": days,
            "total_warnings": sum(len(w["parsed_warnings"]) for w in filtered_warnings),
            "warnings": filtered_warnings,
        }
    }


def get_warning_icon(warning_text):
    """根据预警内容返回合适的图标"""
    text = str(warning_text)
    if "红色" in text:
        return "🔴"
    elif "橙色" in text:
        return "🟠"
    elif "黄色" in text:
        return "🟡"
    elif "蓝色" in text:
        return "🔵"
    elif any(t in text for t in ["大风", "暴雨", "暴雪", "雷电", "冰雹"]):
        return "⚠️"
    elif "高温" in text:
        return "🌡️"
    elif "大雾" in text or "雾" in text:
        return "🌫️"
    elif "沙尘" in text:
        return "🌪️"
    elif "台风" in text:
        return "🌀"
    else:
        return "⚡"


def print_result(result):
    """打印格式化结果"""
    if result.get("code") != 0:
        print(f"错误: {result.get('message', '未知错误')}")
        return

    data = result["data"]

    print(f"\n{'='*60}")
    print(f"📍 城市: {data['city_name']} (ID: {data['city_id']})")
    print(f"📅 查询范围: 未来{data['total_days']}天")
    print(f"{'='*60}")

    if not data["has_warning"]:
        print("\n✅ 未来7天无高影响天气预警")
        print("   该地区气象条件平稳，暂无灾害性天气预警信息。")
        return

    print(f"\n⚠️  共 {data['total_warnings']} 条预警信息\n")

    # 按日期显示
    for day_warning in data["warnings"]:
        print(f"📅 {day_warning['date']} {day_warning['weekday']}")
        print("-" * 50)

        for pw in day_warning["parsed_warnings"]:
            icon = get_warning_icon(pw["type"])
            time_range = pw["time_range"] if pw["time_range"] else ""
            warning = pw["type"]

            print(f"  {icon} {warning}")
            if time_range:
                print(f"     ⏰ 时段: {time_range}")

        print()


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法: python3 query.py <城市名> [预警类型] [天数]")
        print("\n参数说明:")
        print("  城市名    - 必填，城市名称，支持模糊匹配")
        print("  预警类型  - 可选，如：暴雨、高温、大风等")
        print("  天数     - 可选，查询天数，默认7天")
        print(f"\n支持的预警类型 ({len(WARNING_TYPES)}种):")
        for name in sorted(WARNING_TYPES.keys()):
            print(f"  - {name}")
        print(f"\n覆盖城市: {len(CITY_MAP)} 个")
        sys.exit(1)

    city_name = sys.argv[1]
    warning_type = sys.argv[2] if len(sys.argv) > 2 else None
    days = int(sys.argv[3]) if len(sys.argv) > 3 else 7

    # 验证预警类型
    if warning_type and warning_type not in WARNING_TYPES:
        print(f"未知预警类型: {warning_type}")
        print(f"支持的类型: {', '.join(sorted(WARNING_TYPES.keys()))}")
        sys.exit(1)

    try:
        result = query_warning(city_name, warning_type, days)
        print_result(result)
    except Exception as e:
        print(f"查询失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
