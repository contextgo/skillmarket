---
name: ecommerce-livestream-overlay-generator
description: >
  电商直播贴片生成器 / 电商直播视觉包装工具。
  适用于淘宝直播、抖音直播带货、拼多多直播、快手直播等电商直播场景。
  输入品牌、产品、促销信息或产品照片，自动生成完整电商直播视觉包装：
  背景、标题栏、主播形象、价格卡、产品货架、福利条、促销贴片。
  支持绿幕抠图、自动合成预览、打包交付。
  E-commerce livestream overlay generator for Taobao, Douyin, PDD, Kuaishou streaming.
  Generate background, title banner, host persona, pricing card, product shelf, benefits bar.
  Supports green screen removal, auto-composite preview, and packaged delivery.
homepage: https://github.com/gaoyuji12138/e-commerce-livestream-overlay-skill
user-invocable: true
metadata: '{"openclaw":{"emoji":"🎨","primaryEnv":"VOLCENGINE_ARK_API_KEY","requires":{"env":["VOLCENGINE_ARK_API_KEY"],"bins":["python3","pip3"]}}}'
---

# E-Commerce Livestream Overlay Generator Skill

## I. Prerequisites

### Dependencies
- Python 3 + Pillow + opencv-python-headless + numpy

### Environment Variables

- `VOLCENGINE_ARK_API_KEY` - Volcano Engine (Doubao) Ark API Key（必填）

**获取方式**：
1. 登录 [火山引擎控制台](https://console.volcengine.com/ark/region:ark+cn-beijing/model)
2. 进入 Ark 模型平台，启用以下模型：
   - `doubao-seedream-4-5-251128`（通用组件）
   - `doubao-seedream-5-0-260128`（主播人像组件）
3. 在控制台凭证页面创建 API Key

> **每个用户需要自己的 API Key**：使用时从环境变量 `VOLCENGINE_ARK_API_KEY` 读取。

### Install dependencies
```bash
pip3 install Pillow==12.2.0 opencv-python-headless==4.13.0 numpy==2.3.2
```

## II. Data Privacy & Transparency

This skill sends **text prompts** and **optionally user-supplied product photos** to the Volcano Engine (Doubao) image generation API. All subsequent processing (green screen removal, compositing, packaging) runs **entirely locally**.

| What is sent | Where | Purpose |
|-------------|-------|---------|
| Text prompts (brand/product/style descriptions) | `https://ark.cn-beijing.volces.com/api/v3/images/generations` | Generate overlay component images (background, title, host persona, pricing card, product shelf, benefits bar) |
| User-supplied product photos (optional) | `https://ark.cn-beijing.volces.com/api/v3/images/generations` | Used as reference image input for product shelf generation |

**Data handling details:**
- **Text prompts** and **user product photos** (when provided) are sent to the Volcano Engine API endpoint listed above. No data is forwarded to any other third party.
- **Generated images** are returned from the API and saved locally. They are not re-uploaded anywhere.
- **All post-processing** (green screen removal, compositing, brightness adjustment, packaging) runs **entirely locally** on the user's machine using Python (OpenCV + Pillow).

**What this skill does NOT do:**
- ❌ Store, log, or cache user input data (text prompts, product photos) locally or remotely
- ❌ Forward data to any third party beyond the Volcano Engine API
- ❌ Make purchases, handle payments, or interact with any financial services
- ❌ Perform any cryptocurrency or blockchain operations

> Generated images returned from the API are saved to the local output directory for your use.

> ⚠️ User product photos and text prompts are sent to Volcano Engine's API. Please review [Volcano Engine's privacy policy](https://www.volcengine.com/docs/6369/71845) before uploading sensitive or proprietary product images.

## III. Requirement Confirmation (Must Complete Before Generation)

> ⚠️ Upon receiving a generation request, do NOT start generating images immediately. Confirm the following info first to ensure one-pass success.

### 3.1 Required Information

| Info | Description | Required |
|------|-------------|----------|
| Brand | e.g. Dyson, Moutai, Three Squirrels | ✅ |
| Featured Product | Specific product name and model | ✅ |
| Promotion | Discounts, gifts, loyalty points, etc. | ✅ |
| Style Preference | Special requirements (color, mood, tone) | ❌ |

### 3.2 Confirmation Flow

1. **User provides complete info** → Summarize understanding, ask user to confirm, then start
2. **User info is incomplete** → Only ask for missing required fields, auto-infer the rest
3. **User sends a product photo with no text** → AI agent identifies the product using its built-in vision capability, infers brand & category, summarizes and asks user to confirm
4. **User says "use the example"** → Generate directly using the Dyson example below

### 3.3 Confirmation Example Reply

```
Let me confirm the requirements:

📋 **Brand**: Dyson
📋 **Featured Product**: Dyson Supersonic HD16 Hair Dryer + Airwrap Multi-Styler
📋 **Promotion**: ¥300 off every ¥3,000 spent
📋 **Gift**: Free 2 styling nozzle attachments with hair dryer purchase
📋 **Packaging**: Livestream-exclusive gift box
📋 **Style**: Tech-luxury (inferred from Dyson brand)

Here's my copy design:
- Main title: "Dyson · Salon-Grade Styling"
- Subtitle: "Limited Edition · Luxe Experience"
- Pricing card: "¥300 off ¥3,000+ / Free styling nozzles with hair dryer / Exclusive gift box"
- Benefits: "2-year warranty / Free shipping / Premium gift packaging"

If this looks good I'll start generating. Let me know if you want any changes 👇
```

### 3.4 Example Requirement (Show Proactively on First Trigger)

> When receiving a generation request, proactively show the example below so the user can follow it or ask to use it directly.

**Example requirement:**
> Generate a full Dyson livestream overlay set. Featured products: Dyson Supersonic HD16 Hair Dryer and Airwrap Multi-Styler. Free 2 styling nozzle attachments with hair dryer purchase. ¥300 off every ¥3,000 spent. Livestream-exclusive gift box.

**First reply template:**
```
You can just tell me your brand and promo info, like:

> Generate a full Dyson livestream overlay set. Featured products: Dyson Supersonic HD16 Hair Dryer and Airwrap Multi-Styler. Free 2 styling nozzle attachments with hair dryer purchase. ¥300 off every ¥3,000 spent. Livestream-exclusive gift box.

Or just say "use the Dyson example" and I'll generate with that spec.

What's your requirement?
```

**Minimum needed**: Brand + Featured Product + Promotion (3 core fields)
**Copy, style, host design, benefits** are all auto-generated by AI. User can optionally modify.

## IV. Auto Copywriting Rules

### 4.1 Main Title
- Must include brand name with atmospheric feel
- **NEVER use** "official" or "flagship" or similar words
- Don't just write the product name — it needs marketing appeal and purchase desire

### 4.2 Subtitle
- Core benefit (perks / efficacy / scenario) or current campaign
- Concise and impactful

### 4.3 Pricing Card
- Split promotion into 2-3 tiers
- Each tier: amount/benefit + conditions

### 4.4 Benefits Copy
- Usually 3 items: gift-related + authenticity guarantee + logistics/after-sales
- ⚠️ Avoid audit-triggering words like "authentic" or "guarantee" — use "quality" and "assured" instead

## V. Component List & Dimensions

> ⚠️ Dimensions calibrated for `doubao-seedream-4-5-251128` minimum pixel limits

| # | Component | Size | Green Screen | Notes |
|---|-----------|------|-------------|-------|
| 1 | Background | **1440×2560** | ❌ | C4D scene |
| 2 | Title Banner | **3328×1109** | ✅ | Die-cut sticker |
| 3 | Host Persona | **1440×2560** | ✅ | Bare-faced + youthful face + styled look (no product in hand) |
| 4 | Pricing Card | **1920×1920** | ✅ | Square die-cut sticker |
| 5 | Product Shelf | **3328×1109** | ✅ | 40+ items dense arrangement |
| 6 | Benefits Bar | **3328×1109** | ❌ | Full-width bottom |

## VI. Prompt Writing Standards

### Core Principles
- All components use a unified style prefix for color consistency
- Must include negative constraints
- Background uses "pure solid green" (not #00FF00)

### 6.1 Background Prompt
**Constraint**: No text, no people, no products.

**Template**:
```
A C4D commercial space scene blending [style description]. The space uses [primary color] as the dominant tone, complemented by [secondary color], with [accent color] details, all balanced by [neutral color]. The spatial structure presents [structure description], creating a [atmosphere]. Lighting design [lighting description] highlights texture and depth. Materials include [materials], showcasing the charm of [style]. Modular abstract display elements are scattered throughout, such as [element 1], [element 2], and [element 3], together creating a [overall feeling] spatial experience.
```

### 6.2 Title Banner Prompt
**Template**:
```
Solid uniform green background #00FF00. Center of frame is a [color] gradient die-cut horizontal card with [border texture], irregular artistic edges on all four sides. Inside the card, left side has [text area background color], large text "[MAIN TITLE]" in [font description], below it "[SUBTITLE]" in [font description]. Right side of card shows [product illustration description]. The entire card has rich deep colors with absolutely no white background areas, no green/cyan/teal. The card is a complete solid sticker with crisp sharp edges.
```

### 6.3 Host Persona Prompt

> ⚠️ Core rules (v2 update):
> 1. **Use `doubao-seedream-5-0-260128` for host persona** (other components still use `doubao-seedream-4-5-251128`)
> 2. **Completely bare-faced, no makeup** (not "natural nude makeup")
> 3. **Do NOT hold products** — hands hang naturally, slightly bent (v2 removed hand-held product)
> 4. **Internet-celebrity youthful face with short midface**, deep watery eyes, jelly-glossy lips
> 5. **Outfit must be pre-designed** — fully describe top + bottom (no shoes) + accessories in prompt
> 6. **Hair color preferably black**, silky smooth, styled with possible accessories matching brand tone
> 7. Background uses "pure solid green" (not #00FF00)

**Template**:
```
Pure solid green uniform background, absolutely uniform pure color with no gradients, no texture, no shadows, no light spots, no impurities. Vertical portrait, person standing facing camera, framed from top of head to mid-thigh, person centered and occupying most of the frame, top of head very close to frame top. 25-year-old beautiful young female host, completely bare-faced with no makeup, cool-toned fair skin that is clear and translucent, internet-celebrity youthful face with short midface, {eye type description}, deep watery eyes, {eye area description}, lips {lip shape description} with jelly-glossy {lip color description}, {temperament description}. Completely bare-faced, no makeup on face whatsoever, no eyeshadow, eyeliner, mascara, blush, lipstick, or foundation. Wearing {top description}, {bottom description}, {accessories description}. {hair style and color description}, {hair accessories description}. Soft even front lighting. Person standing naturally, both arms hanging naturally with slight bend, relaxed elegant posture.
```

**Face Differentiation (Must specify these dimensions each time)**:

| Dimension | Description | Examples |
|-----------|-------------|----------|
| Face shape | Internet-celebrity youthful face, short midface (fixed) | Heart/oval/melon/square-round |
| Eye type | Round/almond/peach-blossom/phoenix | Describe "slightly downturned for innocent look" or "slightly upturned for elegance" |
| Eye hydration | Fixed requirement | "Deep watery eyes, delicate translucent skin around eyes" |
| Lip jelly feel | Fixed requirement | "Full pouty lips with jelly-glossy translucent shine" / "Thin lips natural pale pink with jelly feel" |
| Temperament | Sweet & approachable / cool & premium / elegant & intellectual / energetic / confident | Varies by brand |
| Outfit | Must be pre-designed, top + bottom + accessories | No shoes |
| Hairstyle | Must be pre-designed, primarily black + accessories | Silky smooth, refined with design sense |

**Host Design Examples (v2)**:

Lancôme Absolue:
```
Internet-celebrity youthful face with short midface, round eyes slightly downturned for innocent look, deep watery eyes, delicate translucent skin around eyes, full pouty lips with jelly-glossy translucent shine, refined sweet and approachable features. Wearing white fine-knit cropped cardigan, layered over cream-white lace camisole, high-waisted light pink pleated satin midi skirt, rose-gold delicate collarbone chain on chest, rose-gold thin bracelet on left wrist, simple pearl ring on right hand. Long straight black hair silky smooth falling to below collarbone, a small pearl hair clip clipped on the right side of crown, a few wispy strands naturally framing the face.
```

Helena Rubinstein Re-Plasty:
```
Internet-celebrity youthful face with short midface, phoenix eyes slightly upturned, deep watery eyes with natural cool-premium feel at outer corners, thin lips natural pale pink with jelly-glossy hydration, refined cool-premium features. Wearing black high-neck slim-fit silk shirt, sleeves rolled up to elbows revealing slender wrists, black high-waisted wide-leg suit pants, a 2-carat diamond stud on left earlobe, ultra-fine silver chain bracelet on right wrist. Long straight black hair silky smooth with center part falling naturally to center of back, a minimalist black ultra-thin hairpin placed near right temple for clean structured look.
```

La Mer:
```
Internet-celebrity youthful face with short midface, bright large almond eyes, deep watery eyes with warm soulful gaze, standard lips with jelly-glossy natural pink full hydration, refined soft and clear features. Wearing pearl-white silk satin loose shirt with top button undone revealing delicate collarbone, puffy bubble sleeve design, champagne high-waisted satin wide-leg trousers, ultra-fine champagne-gold necklace with small pearl pendant on neck, white jade thin bracelet on left wrist. Long curly black hair silky smooth with natural large waves falling to shoulder blades, a loose refined French braid woven from left side of crown, tiny pearl hairpins scattered through the braid.
```

### 6.4 Pricing Card Prompt
> ⚠️ Size changed from 896×1344 to **1920×1920** (square)

**Template**:
```
Solid uniform green background #00FF00. Center of frame is a compact vertical die-cut label sticker, entirely [dark color scheme] solid background, absolutely no white areas, no light-colored areas, no gradients to white, no green/cyan/teal. Sticker shape is rounded rectangle with arched top decoration. Top has [decorative elements]. Large text "[HEADLINE]" in [font description]; below divided into three tiers: "[TIER 1]" "[TIER 2]" "[TIER 3]". The entire sticker has rich deep solid colors with crisp sharp edges, a solid die-cut sticker. Sticker occupies about 40% of frame area, compact not sparse.
```

### 6.5 Product Shelf Prompt (⚠️ Different from original skill)

> ⚠️ Key differences:
> 1. **White matte marble display tabletop** (not pure green + white plane)
> 2. **Layered cluster + left-right mirror + front-back progression** layout logic
> 3. **At least 40+ individual product units** (not "make it rich")
> 4. Middle core zone split into left-center-right sections, center as visual focal point

**Template**:
```
Background is pure solid green uniform. At the bottom of frame is a front-facing flat white premium display tabletop (white matte marble texture), completely horizontal with no tilt, occupying bottom 40% of frame height. Products arranged by layered cluster plus left-right mirror plus front-back progression logic, at least 40+ individual product units densely covering most tabletop area: [Middle core display zone split into left-center-right] Center visual focal point: {product layout description} [Overall layout requirements] All products standing upright facing the viewer. Height differences create stepped layering. Appropriate blank spacing between left/right zones and center zone for breathing room. Dense and full product arrangement, at least 40+ individual units. Nothing else besides products and white matte metal display stands, absolutely no hands, fingers, arms, or any human body parts. Even lighting. Pure still-life product display photo with no human presence whatsoever.
```

> ⚠️ Do NOT include "leave hand-holding space at front" in the layout — hand-held products are for the host persona image; the product shelf is pure product display.

### 6.6 User Product Photo (Optional)

When the user provides a real product photo:

**a) Background removal**: Select strategy based on product photo background

| Product Background | Removal Method |
|-------------------|----------------|
| White/light solid background | HSV threshold to remove white areas |
| Dark solid background | HSV threshold to remove corresponding dark color |
| Complex scene background | GrabCut or Rembg |

```python
import cv2
import numpy as np

def remove_white_bg(img_path, output_path):
    """Remove white/light background — runs entirely locally"""
    img = cv2.imread(img_path)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask_w = cv2.inRange(hsv, np.array([0, 0, 200]), np.array([180, 30, 255]))
    mask_g = cv2.inRange(hsv, np.array([0, 0, 160]), np.array([180, 50, 240]))
    mask = cv2.bitwise_or(mask_w, mask_g)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=5)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k, iterations=3)
    mask = cv2.GaussianBlur(mask, (5, 5), 0)
    mask = (mask > 200).astype(np.uint8) * 255
    b, g, r = cv2.split(img)
    cv2.imwrite(output_path, cv2.merge([b, g, r, 255 - mask]))
```

**b) Product Shelf Prompt adjustment**: Leave center area blank for user's product

```
In the product shelf prompt, change the center zone description to:
"Leave sufficient blank space in the center area for the main featured product
(about 30% of center area kept clean), surrounding products arranged by
layered cluster plus left-right mirror plus front-back progression logic"
```

**c) Composite overlay**: User product photo scaled and placed at center of product area

```python
# User product: scale to 25% of canvas width, center of product area
up_target_w = int(cw * 0.25)
ups = up_target_w / user_product.width
up_resized = user_product.resize((int(user_product.width * ups), int(user_product.height * ups)), Image.LANCZOS)
upx = (cw - up_resized.width) // 2
upy = pdy + int(pdr.height * 0.05)

# Paste order: user product after product shelf, before title banner
canvas.paste(pdr, (0, pdy), pdr)
canvas.paste(up_resized, (upx, upy), up_resized)  # ← user product
canvas.paste(tr, (tx, ty), tr)
```

### 6.7 Benefits Bar Prompt
**Template**:
```
Symmetrical left-right composition, eye-level view. Core elements in upper half: three simple benefit icons, with corresponding text below: "[BENEFIT 1] / [BENEFIT 2] / [BENEFIT 3]". Background [background description]. Style: flat design, minimalist lighting. Color: [primary color], clean and elegant.
```

## VII. Image Generation API

| Item | Content |
|------|---------|
| Endpoint | `https://ark.cn-beijing.volces.com/api/v3/images/generations` |
| Method | POST |
| Content-Type | application/json |
| **General model** | **`doubao-seedream-4-5-251128`** |
| **Persona model** | **`doubao-seedream-5-0-260128`** (host persona component only) |

> 📋 The API key is obtained from the [Volcano Engine Ark Console](https://console.volcengine.com/ark/region:ark+cn-beijing/model). Text prompts are sent to this endpoint; no images or personal data are transmitted.

### Request parameters
```json
{
  "model": "doubao-seedream-4-5-251128",
  "stream": false,
  "watermark": false,
  "sequential_image_generation": "disabled",
  "prompt": "<prompt in Chinese>",
  "size": "<width>x<height>"
}
```

### Request example
```bash
curl -s "https://ark.cn-beijing.volces.com/api/v3/images/generations" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $VOLCENGINE_ARK_API_KEY" \
  -d '{
    "model": "doubao-seedream-4-5-251128",
    "stream": false,
    "watermark": false,
    "sequential_image_generation": "disabled",
    "prompt": "prompt content",
    "size": "1440x2560"
  }'
```

> 📋 The API key is read from the environment variable `VOLCENGINE_ARK_API_KEY`. Text prompts are sent to this endpoint; no images or personal data are transmitted.

## VIII. Green Screen Removal

Execute green screen removal on components 2 (Title Banner), 3 (Host Persona), 4 (Pricing Card), and 5 (Product Shelf).

> 🔒 This processing runs **entirely locally** — no data leaves the machine.

```python
import cv2
import numpy as np

def remove_green(img_path, output_path):
    img = cv2.imread(img_path)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask1 = cv2.inRange(hsv, np.array([35, 80, 80]), np.array([85, 255, 255]))
    mask2 = cv2.inRange(hsv, np.array([30, 40, 120]), np.array([90, 255, 255]))
    mask = cv2.bitwise_or(mask1, mask2)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=3)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k, iterations=2)
    mask = cv2.GaussianBlur(mask, (3, 3), 0)
    mask = (mask > 127).astype(np.uint8) * 255
    b, g, r = cv2.split(img)
    rgba = cv2.merge([b, g, r, 255 - mask])
    cv2.imwrite(output_path, rgba)
```

## IX. Composite Preview

> ⚠️ Layout parameters differ from original skill
> 🔒 All compositing runs **entirely locally** — no data leaves the machine.

### Layout Parameters

```python
layout = {
    "title":   {"scale": 0.95, "pos": "center-top", "y_pct": 0.07},
    "person":  {"scale": 0.70, "pos": "left", "x_pct": 0.15, "y_pct": 0.14},
    "promo":   {"scale": 0.40, "pos": "right", "x_pct": 0.55, "y_pct": 0.22},
    "product": {"zoom": 1.2,  "pos": "bottom-full", "above": "benefit"},
    "benefit": {"scale": 1.0,  "pos": "bottom-full"},
}
```

### Composite Code

```python
from PIL import Image

def compose_preview(bg_path, person_nobg, title_nobg, promo_nobg, product_nobg, benefit_path, output_path):
    bg = Image.open(bg_path).convert("RGBA")
    cw, ch = bg.size

    def fit(img, w_ratio, center=True):
        w = int(cw * w_ratio)
        s = w / img.width
        r = img.resize((w, int(img.height * s)), Image.LANCZOS)
        x = (cw - w) // 2 if center else cw - w
        return r, x

    def fit_full(img):
        s = cw / img.width
        return img.resize((cw, int(img.height * s)), Image.LANCZOS)

    def zoom_crop(img, zoom):
        w = int(cw * zoom)
        s = w / img.width
        h = int(img.height * s)
        r = img.resize((w, h), Image.LANCZOS)
        cx = (w - cw) // 2
        return r.crop((cx, 0, cx + cw, h))

    title = Image.open(title_nobg).convert("RGBA")
    person = Image.open(person_nobg).convert("RGBA")
    promo = Image.open(promo_nobg).convert("RGBA")
    product = Image.open(product_nobg).convert("RGBA")
    benefit = Image.open(benefit_path).convert("RGBA")

    tr, tx = fit(title, 0.95); ty = int(ch * 0.07)
    prr, prx = fit(promo, 0.40, center=False); prx = int(cw * 0.55); pry = int(ch * 0.22)
    per, perx = fit(person, 0.70); perx = int(cw * 0.15); pery = int(ch * 0.14)
    pdr = zoom_crop(product, 1.2); pdy = ch - fit_full(benefit).height - pdr.height
    bfr = fit_full(benefit); bfy = ch - bfr.height

    # Layer order: background → pricing card → host → product shelf → title banner → benefits bar
    # To place title behind host, move tr paste before per paste
    canvas = bg.copy()
    canvas.paste(prr, (prx, pry), prr)
    canvas.paste(per, (perx, pery), per)
    canvas.paste(pdr, (0, pdy), pdr)
    canvas.paste(tr, (tx, ty), tr)
    canvas.paste(bfr, (0, bfy), bfr)

    canvas.convert("RGB").save(output_path, "JPEG", quality=95)
```

### Post-processing: Host Brightness Boost

Boost the host layer brightness before compositing to prevent dark appearance:

```python
from PIL import ImageEnhance

# Boost host layer by 17% before compositing
person_bright = ImageEnhance.Brightness(person).enhance(1.17)
# Use person_bright instead of person in compositing
```

> ⚠️ Only boost the host layer (17%). Do NOT touch other layers. The delivered 人物.png should also use the boosted version.

## X. Delivery & Packaging

### Deliverables (Fixed 7 files)

| Filename | Format | Notes |
|----------|--------|-------|
| 背景.png | PNG 1440×2560 | Full-bleed |
| 标题横卡.png | PNG 1440×2560 transparent | Content at preview position |
| 人物.png | PNG 1440×2560 transparent | Brightness boosted (don't label "boosted") |
| 促销竖卡.png | PNG 1440×2560 transparent | Content at preview position |
| 桌面商品贴.png | PNG 1440×2560 transparent | Content at preview position |
| 权益下贴.png | PNG 1440×2560 transparent | Content at preview position |
| 预览.jpg | JPG 1440×2560 | Composite preview |

If a user product photo is provided, it will be composited into the center of the product shelf — not delivered separately.

### Delivery Methods (Auto-select based on channel)

**Method 1: Send in chat (when channel supports file sending)**
1. Send preview image (`预览.jpg`) to chat first
2. Send zip archive (named `{Brand}_livestream_overlays.zip`, containing all 7 files)

```bash
cd output/
zip -j "../{Brand}_livestream_overlays.zip" 背景.png 标题横卡.png 人物.png 促销竖卡.png 桌面商品贴.png 权益下贴.png 预览.jpg
```

**Method 2: Desktop folder (when channel doesn't support file sending)**
1. Create folder on user's desktop named `{Brand}_overlays`
2. Put only the 7 files inside — no intermediate files, no zip
3. Use `open` command to show the preview image
4. Use `open` command to open the folder

> ⚠️ Note: webchat (Control UI) does not support file sending — use Method 2. Feishu, WeChat etc. use Method 1.

## XI. Complete Workflow

```
1. Collect requirements (brand, promotion, optional: user product photo)
2. Analyze brand style → determine color palette
3. Design host appearance (youthful face + watery eyes + jelly lips + outfit + hairstyle + accessories)
4. Auto-generate missing copy
5. Write prompts for all 6 components (host uses v2 template, no hand-held products)
   - If user product photo: leave center blank in product shelf prompt
6. General components → doubao-seedream-4-5-251128, host → doubao-seedream-5-0-260128
7. Green screen removal on components 2/3/4/5
8. Boost host layer brightness by 17% (ImageEnhance.Brightness 1.17)
9. [Optional] Remove background from user product photo (white/light bg → HSV threshold)
10. Composite preview (use boosted host, user product overlaid at center of product area)
11. Package and deliver
```
