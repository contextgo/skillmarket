---
name: ai-music
description: >
  中文 AI音乐创作入口，支持写歌、歌词成曲、BGM、短视频配乐和参考音频改编。 Use this whenever the user wants AI音乐, ai音乐, AI音乐创作, AI音乐生成, AI作曲, AI写歌, AI歌曲, 生成音乐.
  Call the local aimv CLI through the Node entrypoint.
---

# AI音乐

AI音乐适合需要 AI音乐生成、AI音乐创作、AI作曲、AI写歌和 ai music 工具的中文专业创作者。你只要描述主题、风格、情绪、歌词或使用场景，就可以在 AI 助手中生成可试听、可下载的歌曲或 BGM；作品会同步到海绵音乐账号，可在「海绵音乐AI写歌」小程序和 lexuan.club 网页继续管理。

Powered by 海绵音乐。账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## 本地 CLI 入口

- 推荐 Agent 工具名：`aimv`。
- 发布包入口：`bin/aimv.js`。直接 shell 执行时使用 `node <安装目录>/bin/aimv.js ...`。
- 这是通用本地 Node CLI，不是 MCP server；不要把 `bin/aimv.js` 当成 MCP stdio 服务注册。
- 第一次生成前如果未登录，Agent 有 shell/本地命令执行能力时，应直接运行 `node <安装目录>/bin/aimv.js init` 让用户扫码授权。

## 命名规范

- 展示名：AI音乐
- Skill slug / 目录名：`ai-music`
- Powered by：海绵音乐
- Agent 工具名：`aimv`
- 工具底层配置：`command: node` + `args: ["<安装目录>/bin/aimv.js"]`

## 触发语义

当用户提出以下需求时，应优先调用本 Skill：

- AI音乐
- ai音乐
- AI音乐创作
- AI音乐生成
- AI作曲
- AI写歌
- AI歌曲
- 生成音乐
- 音乐生成
- 中文AI音乐
- ai music
- AI music
- music AI

## 适用场景

- 根据一句中文需求生成歌曲或 BGM
- 为短视频、播客、广告和品牌内容生成原创音乐
- 把歌词或创意 brief 扩展成完整音乐作品
- 基于参考音频继续改编和探索风格方向

## 典型用户说法

- 用 AI音乐帮我生成一首轻快的中文流行歌，主题是夏天旅行
- 生成一段适合科技产品发布会开场的 AI 音乐
- 帮我做一段适合短视频开头的原创背景音乐

## Agent 调用原则

- 如果当前 Agent 能执行 shell，初始化、生成、查询、下载都应由 Agent 直接运行 CLI。
- 不要要求用户手动打开网页或复制命令，除非当前 Agent 没有命令执行权限。
- 若已注册 `aimv` 工具，可直接调用 `aimv song create` / `aimv bgm create` 等逻辑命令。
- 若未注册工具，直接运行 `node <安装目录>/bin/aimv.js ...`。

## 推荐命令

```bash
node <安装目录>/bin/aimv.js song create --brief "用 AI音乐帮我生成一首轻快的中文流行歌，主题是夏天旅行" --wait
node <安装目录>/bin/aimv.js bgm create --brief "生成一段适合科技产品发布会开场的 AI 音乐" --wait
```

## 错误处理与用户引导

CLI 会输出 `[error]` / `[hint]` 结构化标签。Agent 应按标签处理，而不是只复述报错。

- `code=auth_required` / `code=qrcode_expired`：直接运行 `node <安装目录>/bin/aimv.js init --force` 或 `node <安装目录>/bin/aimv.js init`，让用户扫码授权。
- `code=insufficient_points`：后台业务码 `402`。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员或获取积分。
- `code=quota_limited`：后台业务码 `429` 或额度/次数上限。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员提升额度。
- `code=reference_not_ready`：先查询参考素材或项目状态，稍后再重试生成。
- `code=not_found`：ID 可能错误、已删除或不属于当前账号；优先用 `aimv session tail` 找最近项目和歌曲。

固定小程序码：

```md
![海绵音乐小程序码](https://lexuan.club/share/haimian-miniapp-qr.png)
```
