"""
🏛️ mirror.skill — 奥林匹斯映照图生成器
深渊神谕·黑金风格 · 极深黑金底+浓密金色星空

参考：方案D · 深渊神谕 — 极深黑蓝底 + 金色星尘 + 古希腊边框 + 神谕符文
"""

import math
import random
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
from analyzer import (
    get_olympus_result, RARITY_CONFIG,
    SOUL_COMMENTS_GOD, BEST_PARTNERS_GOD, ANIMAL_TO_GOD, _GOD_MAP
)
from pixel_gods import render_pixel_god

# ═══ 画布 ═══
W = 900
H_MAX = 2200

# ═══ 深渊神谕·黑金调色板（方案D） ═══
BG_DEEP    = (8, 8, 18)        # 极深黑蓝
BG_MID     = (15, 12, 28)      # 深夜
BG_LIGHT   = (25, 22, 38)      # 微亮深紫
BG_GLOW    = (35, 30, 52)      # 深紫辉光

GOLD       = (218, 190, 95)    # 主金色
GOLD_BRIGHT= (255, 235, 140)   # 亮金
GOLD_DIM   = (165, 140, 70)    # 暗金
GOLD_DARK  = (120, 100, 55)    # 深金线条
GOLD_WARM  = (235, 210, 110)   # 暖金

TEXT_WHITE  = (248, 242, 225)   # 暖白文字（深底浅字）
TEXT_DIM    = (195, 185, 160)   # 浅灰棕
TEXT_FAINT  = (140, 130, 105)   # 暗提示
ACCENT_RED  = (200, 100, 85)   # 暖红
ACCENT_TEAL = (100, 168, 148)  # 青铜绿
CREAM       = (248, 242, 225)   # 暖白

RNG = random.Random(42)

def hex_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def god_accent(color_hex):
    r, g, b = hex_rgb(color_hex)
    return (
        min(255, int(r * 0.5 + 225 * 0.5)),
        min(255, int(g * 0.5 + 195 * 0.5)),
        min(255, int(b * 0.3 + 95 * 0.7)),
    )

# ═══ 字体加载（与card_generator共享逻辑） ═══
_FONT_CACHE = {}

def _find_font():
    """查找可用中文字体"""
    candidates = [
        Path(__file__).parent / "fonts" / "NotoSansSC-Regular.otf",
        Path(__file__).parent / "fonts" / "NotoSansSC-Regular.ttf",
        Path(__file__).parent / "fonts" / "NotoSansSC-Mirror.ttf",
        "/usr/share/fonts/google-noto-cjk/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/tmp/mirror-fonts/NotoSansSC-Regular.ttf",
    ]
    for p in candidates:
        if Path(p).exists():
            return str(p)
    return None


def _download_font_runtime():
    """运行时从 CDN 下载中文字体到 /tmp"""
    cache_path = Path("/tmp/mirror-fonts/NotoSansSC-Regular.ttf")
    if cache_path.exists() and cache_path.stat().st_size > 100000:
        return str(cache_path)
    print("  📥 正在下载中文字体...")
    cdn_urls = [
        "https://cdn.jsdelivr.net/gh/googlefonts/noto-cjk@main/Sans/SubsetOTF/SC/NotoSansSC-Regular.otf",
        "https://cdn.jsdelivr.net/fontstatic/NotoSansSC-Regular.otf",
        "https://fonts.googleapis.com/css2?family=Noto+Sans+SC&display=swap",
    ]
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    for url in cdn_urls:
        try:
            import urllib.request
            urllib.request.urlretrieve(url, str(cache_path))
            if cache_path.exists() and cache_path.stat().st_size > 100000:
                print(f"  ✅ 字体下载成功: {cache_path}")
                return str(cache_path)
            else:
                cache_path.unlink(missing_ok=True)
        except Exception as e:
            print(f"  ⚠️ CDN下载失败({url[:50]}...): {e}")
            continue
    return None


def _install_font_system():
    """尝试通过系统包管理器安装中文字体"""
    import subprocess
    commands = [
        (["apt-get", "install", "-y", "-qq", "fonts-noto-cjk"],
         "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
        (["yum", "install", "-y", "-q", "google-noto-sans-cjk-ttc-fonts"],
         "/usr/share/fonts/google-noto-cjk/NotoSansCJK-Regular.ttc"),
    ]
    for cmd, expected_path in commands:
        try:
            subprocess.run(cmd, capture_output=True, timeout=60)
            if Path(expected_path).exists():
                print(f"  ✅ 系统字体安装成功: {expected_path}")
                return expected_path
        except Exception:
            continue
    return None


_FONT_PATH = _find_font()

def font(size, w="regular"):
    cache_key = (w, size)
    if cache_key in _FONT_CACHE:
        return _FONT_CACHE[cache_key]
    if _FONT_PATH:
        try:
            f = ImageFont.truetype(_FONT_PATH, size)
            _FONT_CACHE[cache_key] = f
            return f
        except:
            pass
    # 运行时下载字体
    downloaded = _download_font_runtime()
    if downloaded:
        try:
            f = ImageFont.truetype(downloaded, size)
            _FONT_CACHE[cache_key] = f
            return f
        except:
            pass
    # 尝试系统安装
    installed = _install_font_system()
    if installed:
        try:
            f = ImageFont.truetype(installed, size)
            _FONT_CACHE[cache_key] = f
            return f
        except:
            pass
    print("  ⚠️ 未找到任何中文字体，图片中文将显示为方块")
    f = ImageFont.load_default()
    _FONT_CACHE[cache_key] = f
    return f


# ═══════════════════════════════════════════
# 神话风格装饰系统
# ═══════════════════════════════════════════

def draw_gradient_bg(img, max_h):
    """深渊黑金渐变背景——极深夜空，中心微亮"""
    draw = ImageDraw.Draw(img)
    for y_pos in range(max_h):
        t = y_pos / max_h
        wave = math.sin(t * math.pi) ** 1.2 * 0.55 + 0.45
        r = int(BG_DEEP[0] + (BG_GLOW[0] - BG_DEEP[0]) * wave * 0.5)
        g = int(BG_DEEP[1] + (BG_GLOW[1] - BG_DEEP[1]) * wave * 0.5)
        b = int(BG_DEEP[2] + (BG_GLOW[2] - BG_DEEP[2]) * wave * 0.6)
        draw.line([(0, y_pos), (W, y_pos)], fill=(r, g, b))

def draw_gold_particles(img, max_h, density=0.002):
    """浓密金色星尘（深渊神谕版——极深底+高密度）"""
    draw = ImageDraw.Draw(img)
    n = int(W * max_h * density)
    for _ in range(n):
        px = RNG.randint(0, W - 1)
        py = RNG.randint(0, max_h - 1)
        brightness = RNG.randint(140, 240)
        # 金色为主的星尘
        if RNG.random() < 0.3:
            # 亮金星
            r = min(255, brightness + RNG.randint(30, 60))
            g = min(255, brightness + RNG.randint(10, 40))
            b = max(0, brightness - RNG.randint(40, 80))
        else:
            # 白色/淡金星
            r = g = b = brightness
        alpha_factor = 0.9
        bg = img.getpixel((px, py))
        r2 = int(bg[0] * (1 - alpha_factor) + r * alpha_factor)
        g2 = int(bg[1] * (1 - alpha_factor) + g * alpha_factor)
        b2 = int(bg[2] * (1 - alpha_factor) + b * alpha_factor)
        if RNG.random() < 0.03:
            # 十字光芒大星
            size = RNG.randint(1, 3)
            draw.ellipse([px-size, py-size, px+size, py+size], fill=(r2, g2, b2))
            arm = size + RNG.randint(1, 3)
            dimr = int(r2 * 0.5 + bg[0] * 0.5)
            dimg = int(g2 * 0.5 + bg[1] * 0.5)
            dimb = int(b2 * 0.5 + bg[2] * 0.5)
            draw.line([(px - arm, py), (px + arm, py)], fill=(dimr, dimg, dimb), width=1)
            draw.line([(px, py - arm), (px, py + arm)], fill=(dimr, dimg, dimb), width=1)
        elif RNG.random() < 0.06:
            size = RNG.randint(1, 2)
            draw.ellipse([px-size, py-size, px+size, py+size], fill=(r2, g2, b2))
        else:
            draw.point((px, py), fill=(r2, g2, b2))

def draw_greek_border(draw, h):
    """古希腊神殿风格边框——回纹(meander)+柱式"""
    m = 24
    # 外层金线
    draw.rounded_rectangle([m, m, W-m, h-m], radius=6, outline=GOLD, width=3)
    # 内层线
    draw.rounded_rectangle([m+10, m+10, W-m-10, h-m-10], radius=4, outline=GOLD_DIM, width=1)

    # 顶部回纹装饰（简化版 Greek Key / Meander）
    key_y = m + 4
    key_w = 16
    for x in range(m + 24, W - m - 24, key_w * 2):
        draw.rectangle([x, key_y, x + key_w, key_y + 2], fill=GOLD_DARK)
        draw.rectangle([x + key_w, key_y, x + key_w + 2, key_y + 6], fill=GOLD_DARK)
    # 底部回纹
    key_y = h - m - 6
    for x in range(m + 24, W - m - 24, key_w * 2):
        draw.rectangle([x, key_y, x + key_w, key_y + 2], fill=GOLD_DARK)
        draw.rectangle([x + key_w, key_y - 4, x + key_w + 2, key_y + 2], fill=GOLD_DARK)

    # 四角装饰——简化的爱奥尼柱头
    corner_size = 28
    offset = m + 40
    for cx, cy in [(offset, offset), (W-offset, offset), (offset, h-offset), (W-offset, h-offset)]:
        # 双层同心圆 + 中心点
        for r in [corner_size, int(corner_size * 0.6)]:
            draw.ellipse([cx-r, cy-r, cx+r, cy+r], outline=GOLD_DIM, width=1)
        draw.ellipse([cx-4, cy-4, cx+4, cy+4], fill=GOLD)
        # 十字装饰线
        lr = int(corner_size * 0.6)
        draw.line([(cx-lr, cy), (cx+lr, cy)], fill=GOLD_DARK, width=1)
        draw.line([(cx, cy-lr), (cx, cy+lr)], fill=GOLD_DARK, width=1)

    # 顶部中央——神殿三角楣饰
    mid = W // 2
    tri_w = 100
    tri_h = 16
    tri_y = m + 4
    draw.polygon([(mid, tri_y - tri_h), (mid - tri_w, tri_y), (mid + tri_w, tri_y)],
                 outline=GOLD, width=1)
    # 三角内小太阳
    sun_r = 6
    draw.ellipse([mid-sun_r, tri_y-tri_h+4, mid+sun_r, tri_y-tri_h+4+sun_r*2], fill=GOLD_BRIGHT)

    # 底部中央装饰
    bot_y = h - m - 4
    draw.polygon([(mid, bot_y + 12), (mid - 60, bot_y), (mid + 60, bot_y)],
                 outline=GOLD_DIM, width=1)

def draw_separator(draw, y, style="line"):
    """分隔线——金色古典风"""
    PX = 55
    mid = W // 2
    if style == "line":
        draw.line([(PX, y), (W - PX, y)], fill=GOLD_DARK, width=1)
    elif style == "greek":
        # 双线 + 中央太阳
        draw.line([(PX, y-2), (mid - 25, y-2)], fill=GOLD_DARK, width=1)
        draw.line([(mid + 25, y-2), (W - PX, y-2)], fill=GOLD_DARK, width=1)
        draw.line([(PX, y+2), (mid - 25, y+2)], fill=GOLD_DARK, width=1)
        draw.line([(mid + 25, y+2), (W - PX, y+2)], fill=GOLD_DARK, width=1)
        # 太阳符号
        sun_r = 10
        draw.ellipse([mid-sun_r, y-sun_r, mid+sun_r, y+sun_r], outline=GOLD, width=2)
        draw.ellipse([mid-4, y-4, mid+4, y+4], fill=GOLD_BRIGHT)
        # 光线
        for angle in range(0, 360, 45):
            a = math.radians(angle)
            x1 = mid + int((sun_r + 2) * math.cos(a))
            y1 = y + int((sun_r + 2) * math.sin(a))
            x2 = mid + int((sun_r + 6) * math.cos(a))
            y2 = y + int((sun_r + 6) * math.sin(a))
            draw.line([(x1, y1), (x2, y2)], fill=GOLD_DIM, width=1)
    elif style == "dots":
        for x in range(PX, W - PX, 14):
            draw.ellipse([x, y-1, x+2, y+1], fill=GOLD_DARK)
    elif style == "laurel":
        # 月桂枝分隔线
        draw.line([(PX, y), (mid - 30, y)], fill=GOLD_DARK, width=1)
        draw.line([(mid + 30, y), (W - PX, y)], fill=GOLD_DARK, width=1)
        # 中央月桂花环
        for dx in [-15, -8, 8, 15]:
            leaf_c = GOLD if abs(dx) > 10 else GOLD_DIM
            draw.ellipse([mid+dx-4, y-6, mid+dx+4, y+6], fill=leaf_c)

def draw_progress_bar(draw, x, y, w, h, pct, fill_color):
    """进度条——深底+金色填充"""
    bg = (25, 22, 35)
    draw.rectangle([x, y, x + w, y + h], fill=bg, outline=GOLD_DARK, width=1)
    fw = max(2, int(w * pct / 100))
    if fw > 2:
        for dx in range(fw):
            t = dx / max(fw - 1, 1)
            c = tuple(int(fill_color[i] * (0.5 + 0.5 * t)) for i in range(3))
            draw.line([(x + 1 + dx, y + 1), (x + 1 + dx, y + h - 1)], fill=c)

def draw_avatar_frame(draw, x, y, size, pad):
    """神殿柱式头像框"""
    # 外框
    draw.rectangle([x-pad-6, y-pad-6, x+size+pad+6, y+size+pad+6],
                   outline=GOLD_DARK, width=1)
    # 内框
    draw.rectangle([x-pad, y-pad, x+size+pad, y+size+pad],
                   outline=GOLD, width=2)
    # 四角太阳装饰
    cp = pad + 4
    for dx, dy in [(-cp, -cp), (size+cp, -cp), (-cp, size+cp), (size+cp, size+cp)]:
        r = 4
        cx_c, cy_c = x+dx, y+dy
        draw.ellipse([cx_c-r, cy_c-r, cx_c+r, cy_c+r], fill=GOLD_DIM)

def draw_section_header(draw, cx, y, text_str, f, color):
    """章节标题——月桂枝环绕"""
    bb = draw.textbbox((0, 0), text_str, font=f)
    tw = bb[2] - bb[0]
    tx = cx - tw // 2
    draw.text((tx, y), text_str, font=f, fill=color)
    # 左右月桂枝
    lw = 35
    ly = y + (bb[3] - bb[1]) // 2
    draw.line([(tx - lw - 8, ly), (tx - 8, ly)], fill=GOLD_DIM, width=1)
    draw.line([(tx + tw + 8, ly), (tx + tw + lw + 8, ly)], fill=GOLD_DIM, width=1)
    # 叶子装饰
    for ddx in [-lw-12, tw+lw+12]:
        draw.ellipse([tx+ddx-3, ly-3, tx+ddx+3, ly+3], fill=GOLD_DIM)


# ═══ 文本工具 ═══

def text_center(draw, y, text, f, fill, x_center=None):
    cx = x_center or W // 2
    bb = draw.textbbox((0, 0), text, font=f)
    tw = bb[2] - bb[0]
    draw.text((cx - tw // 2, y), text, font=f, fill=fill)
    return tw

def text_right(draw, xr, y, text, f, fill):
    bb = draw.textbbox((0, 0), text, font=f)
    draw.text((xr - (bb[2] - bb[0]), y), text, font=f, fill=fill)

def wrap_text_block(draw, x, y, text, f, fill, max_w, line_h):
    cur = ""
    cy = y
    for ch in text:
        test = cur + ch
        bb = draw.textbbox((0, 0), test, font=f)
        if bb[2] - bb[0] > max_w:
            draw.text((x, cy), cur, font=f, fill=fill)
            cy += line_h
            cur = ch
        else:
            cur = test
    if cur:
        draw.text((x, cy), cur, font=f, fill=fill)
        cy += line_h
    return cy


# ═══ 主生成函数 ═══

def generate_olympus(result, god_result, out="share_card_olympus.png"):
    """生成奥林匹斯众神版映照图"""
    g = god_result["primary"]
    gs = god_result["secondary"]
    gc = god_accent(g.color)

    img = Image.new("RGB", (W, H_MAX), BG_DEEP)
    draw_gradient_bg(img, H_MAX)
    draw_gold_particles(img, H_MAX, 0.0005)
    img = img.filter(ImageFilter.GaussianBlur(radius=0.5))
    draw = ImageDraw.Draw(img)

    PX = 55

    # ═══ 顶部标题区 ═══
    y = 58
    title_text = "LXBI — mirror.skill"
    f_title = font(34, "bold")
    text_center(draw, y, title_text, f_title, GOLD_BRIGHT)
    y += 48

    text_center(draw, y, "🏛️  奥林匹斯 · 众神映照", font(20, "regular"), TEXT_DIM)
    y += 36

    draw_separator(draw, y, "greek")
    y += 30

    # ═══ 上部：左侧头像 / 右侧深度解读 ═══
    section_top = y

    LEFT_W = 280
    avatar_size = 200
    avatar_x = PX + (LEFT_W - avatar_size) // 2
    avatar_y = y

    draw_avatar_frame(draw, avatar_x, avatar_y, avatar_size, 8)

    # 渲染像素头像
    pixel_avatar = render_pixel_god(g.name)
    pixel_avatar = pixel_avatar.resize((avatar_size, avatar_size), Image.NEAREST)
    pad_img = Image.new("RGBA", (avatar_size, avatar_size), (*BG_LIGHT, 255))
    pad_img.paste(pixel_avatar, (0, 0), mask=pixel_avatar)
    img.paste(pad_img.convert("RGB"), (avatar_x, avatar_y))
    draw = ImageDraw.Draw(img)

    # 头像下方信息
    name_y = avatar_y + avatar_size + 26
    left_cx = PX + LEFT_W // 2

    rarity_cfg = RARITY_CONFIG[g.rarity]
    rarity_color = hex_rgb(rarity_cfg["color"])

    # 神名（中文+英文）
    name_text = f"{rarity_cfg['icon']} {g.name}"
    draw.text((left_cx - draw.textbbox((0,0), name_text, font=font(40, "black"))[2]//2, name_y),
              name_text, font=font(40, "black"), fill=GOLD_BRIGHT)
    name_y += 52

    # 英文名
    text_center(draw, name_y, g.name_en, font(18, "regular"), TEXT_DIM, left_cx)
    name_y += 30

    # 社交标签
    tag_text = f"「{g.social_tag}」"
    tag_font_obj = font(22, "bold")
    bb = draw.textbbox((0, 0), tag_text, font=tag_font_obj)
    tag_w = bb[2] - bb[0] + 24
    tag_h = 38
    tag_x = left_cx - tag_w // 2
    draw.rectangle([tag_x, name_y, tag_x + tag_w, name_y + tag_h],
                   fill=(20, 18, 32), outline=gc, width=1)
    draw.text((tag_x + 12, name_y + 6), tag_text, font=tag_font_obj, fill=gc)
    name_y += tag_h + 16

    # 神职
    text_center(draw, name_y, g.title, font(22, "bold"), gc, left_cx)
    name_y += 34

    # 匹配度
    match_pct = god_result['primary_pct']
    text_center(draw, name_y, f"神谕匹配 {match_pct}%", font(24, "bold"), GOLD, left_cx)
    name_y += 38

    bar_w = min(LEFT_W - 30, 220)
    bar_x = left_cx - bar_w // 2
    draw_progress_bar(draw, bar_x, name_y, bar_w, 14, match_pct, gc)
    name_y += 30

    left_bottom = name_y

    # ── 右侧：神谕解读 ──
    RX = PX + LEFT_W + 20
    RW = W - PX - RX
    ry = section_top + 4

    draw.text((RX, ry), "神谕映照", font=font(17, "medium"), fill=GOLD_DIM)
    ry += 30
    draw.line([(RX, ry), (RX + 70, ry)], fill=GOLD_DARK, width=1)
    ry += 14

    ry = wrap_text_block(draw, RX, ry, g.deep_reading, font(21, "regular"), TEXT_WHITE, RW, 34)
    ry += 14

    # 诅咒面（2段·40字以内）
    draw.line([(RX, ry), (RX + 50, ry)], fill=ACCENT_RED, width=1)
    ry += 10
    draw.text((RX, ry), "// 诅咒面", font=font(15, "bold"), fill=ACCENT_RED)
    ry += 26

    shadow_text = g.shadow
    if len(shadow_text) > 40:
        cut = shadow_text[:42].rfind("。")
        if cut > 10:
            shadow_text = shadow_text[:cut + 1]
        else:
            shadow_text = shadow_text[:40] + "…"
    ry = wrap_text_block(draw, RX, ry, shadow_text, font(19, "regular"), (220, 160, 140), RW, 30)
    ry += 8

    # 神谕金句
    draw.text((RX, ry), f"「{g.quote}」", font=font(20, "bold"), fill=GOLD_BRIGHT)
    ry += 38

    right_bottom = ry
    y = max(left_bottom, right_bottom) + 16

    # ═══ 掌管领域标签 ═══
    draw_separator(draw, y, "dots")
    y += 18

    domain_parts = g.domain.split("·")
    tag_font = font(20, "medium")
    tag_colors = [GOLD, TEXT_DIM, GOLD_BRIGHT, ACCENT_TEAL]

    tag_data = []
    for i, part in enumerate(domain_parts):
        txt = f"⚜ {part.strip()}"
        bb = draw.textbbox((0, 0), txt, font=tag_font)
        tw = bb[2] - bb[0] + 28
        tag_data.append((txt, tw, tag_colors[i % len(tag_colors)]))

    total_tag_w = sum(d[1] for d in tag_data) + 16 * (len(tag_data) - 1)
    tx = (W - total_tag_w) // 2
    for txt, tw, tc in tag_data:
        draw.rectangle([tx, y, tx + tw, y + 38], fill=(20, 18, 32), outline=tc, width=1)
        draw.text((tx + 14, y + 7), txt, font=tag_font, fill=tc)
        tx += tw + 16
    y += 56

    # ═══ 能力星盘 ═══
    draw_separator(draw, y, "laurel")
    y += 26

    draw_section_header(draw, W // 2, y, "能力星盘", font(26, "bold"), GOLD)
    y += 50

    dims = god_result['dimensions']
    dim_colors = [gc, ACCENT_TEAL, GOLD_BRIGHT, TEXT_DIM, ACCENT_RED, GOLD]
    for i, dim in enumerate(dims):
        color = dim_colors[i % len(dim_colors)]
        draw.text((PX, y), dim['name'], font=font(22, "medium"), fill=TEXT_DIM)
        bx = PX + 180
        bar_w = W - PX * 2 - 180 - 70
        draw_progress_bar(draw, bx, y + 4, bar_w, 16, dim['value'], color)
        text_right(draw, W - PX, y, str(dim['value']), font(22, "bold"), color)
        y += 48
    y += 10

    # ═══ 未知之境 ═══
    draw_separator(draw, y, "greek")
    y += 20

    unknown_quote = god_result.get("unknown_quote", "你凝望众神，却从未想过——你也是某人眼中的神")

    text_center(draw, y, "— 未知之境 —", font(14, "regular"), TEXT_FAINT)
    y += 26

    uq_font = font(24, "bold")
    bb_uq = draw.textbbox((0, 0), unknown_quote, font=uq_font)
    uq_w = bb_uq[2] - bb_uq[0]
    if uq_w > W - PX * 2:
        y = wrap_text_block(draw, PX, y, unknown_quote, uq_font, GOLD_DIM, W - PX * 2, 38)
    else:
        text_center(draw, y, unknown_quote, uq_font, GOLD_DIM)
        y += 42

    y += 8

    # ═══ 分隔线 ═══
    draw_separator(draw, y, "laurel")
    y += 30

    # ═══ 下部：潜在神格 + 最佳共鸣 + 二维码 ═══
    left_w = int((W - PX * 2) * 0.52)
    right_w = W - PX * 2 - left_w - 24
    mini_card_h = 155
    mini_gap = 16

    # ── 潜在神格 ──
    lx = PX
    draw.rectangle([lx, y, lx + left_w, y + mini_card_h],
                   fill=(22, 16, 28), outline=ACCENT_RED, width=1)
    draw.rectangle([lx+3, y+3, lx+left_w-3, y+mini_card_h-3],
                   outline=(85, 55, 50), width=1)

    s_avatar_size = 70
    s_avatar = render_pixel_god(gs.name)
    s_avatar = s_avatar.resize((s_avatar_size, s_avatar_size), Image.NEAREST)
    av_x = lx + 18
    av_y = y + (mini_card_h - s_avatar_size) // 2
    pad_s = Image.new("RGBA", (s_avatar_size, s_avatar_size), (*BG_LIGHT, 255))
    pad_s.paste(s_avatar, (0, 0), mask=s_avatar)
    img.paste(pad_s.convert("RGB"), (av_x, av_y))
    draw = ImageDraw.Draw(img)
    draw.rectangle([av_x-2, av_y-2, av_x+s_avatar_size+2, av_y+s_avatar_size+2],
                   outline=ACCENT_RED, width=1)

    tx = av_x + s_avatar_size + 18
    ty = y + 18
    s_rarity_cfg = RARITY_CONFIG[gs.rarity]
    draw.text((tx, ty), "潜在神格", font=font(16, "medium"), fill=ACCENT_RED)
    ty += 26
    draw.text((tx, ty), f"{s_rarity_cfg['icon']} {gs.name}", font=font(28, "bold"), fill=TEXT_WHITE)
    ty += 38
    draw.text((tx, ty), gs.title, font=font(16, "regular"), fill=god_accent(gs.color))
    ty += 26
    s_comment = SOUL_COMMENTS_GOD.get(gs.name, gs.subtitle)
    draw.text((tx, ty), f"「{s_comment}」", font=font(14, "regular"), fill=TEXT_DIM)

    # ── 最佳共鸣 ──
    y2 = y + mini_card_h + mini_gap
    draw.rectangle([lx, y2, lx + left_w, y2 + mini_card_h],
                   fill=(14, 22, 28), outline=ACCENT_TEAL, width=1)
    draw.rectangle([lx+3, y2+3, lx+left_w-3, y2+mini_card_h-3],
                   outline=(45, 72, 62), width=1)

    partner_info = BEST_PARTNERS_GOD.get(g.name, ("雅典娜", "完美互补", "你们是天生的搭档"))
    partner_name = partner_info[0]
    partner_desc = partner_info[1]
    partner_comment = partner_info[2] if len(partner_info) > 2 else ""

    p_avatar = render_pixel_god(partner_name)
    p_avatar = p_avatar.resize((s_avatar_size, s_avatar_size), Image.NEAREST)
    pav_x = lx + 18
    pav_y = y2 + (mini_card_h - s_avatar_size) // 2
    pad_p = Image.new("RGBA", (s_avatar_size, s_avatar_size), (*BG_LIGHT, 255))
    pad_p.paste(p_avatar, (0, 0), mask=p_avatar)
    img.paste(pad_p.convert("RGB"), (pav_x, pav_y))
    draw = ImageDraw.Draw(img)
    draw.rectangle([pav_x-2, pav_y-2, pav_x+s_avatar_size+2, pav_y+s_avatar_size+2],
                   outline=ACCENT_TEAL, width=1)

    tx2 = pav_x + s_avatar_size + 18
    ty2 = y2 + 18
    draw.text((tx2, ty2), "最佳共鸣", font=font(16, "medium"), fill=ACCENT_TEAL)
    ty2 += 26
    draw.text((tx2, ty2), partner_name, font=font(28, "bold"), fill=TEXT_WHITE)
    ty2 += 38
    draw.text((tx2, ty2), partner_desc, font=font(16, "regular"), fill=ACCENT_TEAL)
    ty2 += 26
    if partner_comment:
        draw.text((tx2, ty2), f"「{partner_comment}」", font=font(14, "regular"), fill=TEXT_DIM)

    # ── 右侧二维码 ──
    qr_x = lx + left_w + 24
    total_left_h = mini_card_h * 2 + mini_gap
    qr_box_size = min(right_w - 20, total_left_h - 60)
    qr_bx = qr_x + (right_w - qr_box_size) // 2
    qr_by = y + 10
    qr_cx = qr_bx + qr_box_size // 2
    qr_cy = qr_by + qr_box_size // 2

    # 外层装饰圆
    outer_r = qr_box_size // 2 + 18
    draw.ellipse([qr_cx-outer_r, qr_cy-outer_r, qr_cx+outer_r, qr_cy+outer_r],
                 outline=GOLD_DARK, width=1)
    inner_r = qr_box_size // 2 + 6
    draw.ellipse([qr_cx-inner_r, qr_cy-inner_r, qr_cx+inner_r, qr_cy+inner_r],
                 outline=GOLD_DIM, width=2)

    draw.rounded_rectangle(
        [qr_bx-2, qr_by-2, qr_bx+qr_box_size+2, qr_by+qr_box_size+2],
        radius=8, fill=(18, 16, 28), outline=GOLD_DARK, width=1)

    # 加载二维码
    qr_loaded = False
    qr_img = None

    # 优先从 qrcode_data.py 的 base64 数据加载
    try:
        from qrcode_data import get_qrcode_image
        qr_img = get_qrcode_image().convert("RGB")
    except Exception:
        pass

    # fallback: 从文件路径加载
    if qr_img is None:
        qr_paths = [
            Path(__file__).parent / "qrcode.png",
            Path("qrcode.png"),
            Path("/data/workspace/personality-card/qrcode.png"),
        ]
        for qr_path in qr_paths:
            if qr_path.exists():
                try:
                    qr_img = Image.open(qr_path).convert("RGB")
                    break
                except:
                    pass

    if qr_img is not None:
        try:
            inner = qr_box_size - 8
            qr_img = qr_img.resize((inner, inner), Image.LANCZOS)
            import numpy as np
            qr_arr = np.array(qr_img, dtype=np.float32)
            brightness = qr_arr.mean(axis=2)
            dark_mask = brightness < 128
            light_mask = ~dark_mask
            result_arr = np.zeros_like(qr_arr)
            # 数据点 → 暖金色
            qr_dot = (175, 155, 100)
            for c, v in enumerate(qr_dot):
                result_arr[:,:,c][dark_mask] = v
            bg_qr = (25, 20, 12)
            for c, v in enumerate(bg_qr):
                result_arr[:,:,c][light_mask] = v
            qr_recolored = Image.fromarray(result_arr.astype(np.uint8))
            paste_x = qr_bx + (qr_box_size - inner) // 2
            paste_y = qr_by + (qr_box_size - inner) // 2
            img.paste(qr_recolored, (paste_x, paste_y))
            draw = ImageDraw.Draw(img)
            qr_loaded = True
        except:
            pass

    if not qr_loaded:
        text_center(draw, qr_cy - 8, "QR CODE", font(14, "regular"), GOLD_DIM, qr_cx)

    scan_y = qr_by + qr_box_size + 22
    text_center(draw, scan_y, "扫码探索你的神谕", font(16, "medium"), GOLD_DIM, qr_x + right_w // 2)
    scan_y += 26
    text_center(draw, scan_y, "mirror.skill", font(13, "regular"), TEXT_FAINT, qr_x + right_w // 2)

    y += total_left_h + 30

    # ═══ 底部署名 ═══
    draw_separator(draw, y, "dots")
    y += 22

    text_center(draw, y, "惊风制作 × 造物主系列", font(18, "medium"), TEXT_FAINT)
    y += 58

    # ═══ 边框 ═══
    final_h = y
    draw_greek_border(draw, final_h)

    # ═══ 裁剪 ═══
    img = img.crop((0, 0, W, final_h))
    img.save(out, "PNG", quality=95)
    print(f"  🏛️ 奥林匹斯映照图已保存: {out} ({W}x{final_h})")
    return out
