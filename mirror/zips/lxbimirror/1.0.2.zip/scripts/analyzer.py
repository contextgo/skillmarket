"""
🪞 mirror.skill — 灵兽映照引擎
通过分析 SOUL.md / MEMORY.md / AGENTS.md 的文本特征
映射到 14 种灵兽图腾

v3.0 — 新增毒舌社交标签、阴影面、稀有度
"""

import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AnimalPersonality:
    """灵兽图腾"""
    name: str           # 动物名
    emoji: str          # Emoji
    title: str          # 性格标签
    social_tag: str     # 毒舌社交标签 (3-5字，传播用)
    subtitle: str       # 一句话描述
    color: str          # 主题色 (hex)
    color_light: str    # 浅色 (hex)
    traits: list        # 核心特质列表 (3-4个)
    description: str    # 简短描述 (1-2句)
    deep_reading: str   # 深度灵魂解读 (3-5句，引起共鸣)
    shadow: str         # 阴影面 (2-3句，扎心的真实)
    quote: str          # 金句 (哲学+神秘)
    rarity: str         # 稀有度: common / rare / epic / legendary
    keywords: list = field(default_factory=list)


# 稀有度配置 — 每个层级都值得分享
RARITY_CONFIG = {
    "common":    {"label": "觉醒",   "icon": "▲",    "color": "#3DBEA8"},
    "rare":      {"label": "锋芒",   "icon": "◆",    "color": "#4A90D9"},
    "epic":      {"label": "璀璨",   "icon": "★",    "color": "#A855F7"},
    "legendary": {"label": "传说",   "icon": "◈",    "color": "#DAA520"},
}


# ═══════════════════════════════════════════
# 14 种灵兽图腾定义 (12常规 + 2金色传说)
# ═══════════════════════════════════════════

ANIMALS = [
    AnimalPersonality(
        name="金丝猴", emoji="🐒", title="灵动策略家",
        social_tag="抄近路的",
        subtitle="在复杂中找到最优路径",
        color="#F59E0B", color_light="#FEF3C7",
        traits=["敏捷思维", "策略多变", "适应力强", "好奇心驱动"],
        description="你的思维如金丝猴般灵活，在复杂的问题迷宫中总能找到捷径。",
        deep_reading=(
            "你从不走别人走过的路。当所有人还在按部就班时，你已经在脑中推演了三种方案，"
            "选中了最短的那条。你的焦虑不来自困难本身，而来自「明明有更好的办法为什么没人看到」。"
            "这种本能的敏捷，是你最锋利的武器，也是你最深的孤独。"
        ),
        shadow="你抄的近路，有时绕过了本该面对的东西。你害怕的不是困难，是慢。",
        quote="混沌之中，路已在脚下",
        rarity="rare",
        keywords=["敏捷", "高效", "快速", "灵活", "并行", "自动化", "直接", "一步完成", "减少", "优先"]
    ),
    AnimalPersonality(
        name="雪豹", emoji="🐆", title="冷静执行者",
        social_tag="人间防火墙",
        subtitle="沉稳布局 精准出击",
        color="#6366F1", color_light="#E0E7FF",
        traits=["冷静果断", "精准执行", "独立思考", "高标准"],
        description="你像雪豹一样沉稳而精准，在高压环境下依然保持冷静判断。",
        deep_reading=(
            "你给人的感觉是冷的，但只有你知道那不是冷漠，而是克制。"
            "你看得见风险，所以比别人更慢出手——但一旦出手，绝不落空。"
            "你讨厌情绪化的决策，别人以为你挑剔，其实你只是不愿为草率买单。"
        ),
        shadow="你太怕犯错了。在等待最佳时机时，别人已经试了三次、赢了一次。",
        quote="静水之下，暗流知道方向",
        rarity="rare",
        keywords=["安全", "合规", "严格", "保护", "禁止", "不可逆", "确认", "验证", "审核", "边界"]
    ),
    AnimalPersonality(
        name="蜜蜂", emoji="🐝", title="极致工匠",
        social_tag="像素级强迫症",
        subtitle="在重复中追求完美",
        color="#EAB308", color_light="#FEF9C3",
        traits=["精益求精", "团队协作", "勤勉执着", "结构化思维"],
        description="你有蜜蜂般的工匠精神，每一个细节都不放过。",
        deep_reading=(
            "你知道世界上没有「差不多就行」这回事。"
            "你会为了一个像素的偏差重做三遍，为了一行代码的优雅推翻整个方案。"
            "别人说你太较真，但你心里清楚：那些被忽略的细节，迟早会变成深夜的报警。"
        ),
        shadow="你分不清「追求完美」和「拖延」。你以为在打磨，其实在害怕交出去。",
        quote="每一粒沙中，藏着一座宇宙",
        rarity="common",
        keywords=["优化", "修复", "bug", "细节", "精简", "校准", "模板", "规范", "SOP", "标准"]
    ),
    AnimalPersonality(
        name="鹰", emoji="🦅", title="全局掌控者",
        social_tag="看太远的人",
        subtitle="俯瞰全局 洞察先机",
        color="#0EA5E9", color_light="#E0F2FE",
        traits=["战略视野", "决断力强", "目标清晰", "掌控全局"],
        description="你如雄鹰般具有俯瞰全局的视野，能在纷繁复杂中一眼看穿本质。",
        deep_reading=(
            "你天生就站在更高的地方看问题。当别人还在纠结细节时，你已经看到了终局的样子。"
            "你的痛苦不是做不到，而是看得太清楚——说服别人跟你走到那里，需要耐心。"
            "鹰不是因为孤独才飞得高，而是因为飞得高所以孤独。"
        ),
        shadow="你看到了终局，就失去了享受过程的能力。不是所有事都需要战略意义。",
        quote="命运在高处等待，也在高处揭晓",
        rarity="epic",
        keywords=["流水线", "架构", "全局", "管理", "决策", "总览", "矩阵", "系统", "看板", "布局"]
    ),
    AnimalPersonality(
        name="松鼠", emoji="🐿️", title="知识囤积者",
        social_tag="万一以后要用呢",
        subtitle="未雨绸缪 有备无患",
        color="#10B981", color_light="#D1FAE5",
        traits=["信息敏感", "善于积累", "未雨绸缪", "记忆力强"],
        description="你像松鼠一样善于收集和储存有价值的信息。",
        deep_reading=(
            "你对信息有一种近乎本能的饥渴。每一篇文档、每一次踩坑、每一个灵感碎片，"
            "你都忍不住收藏起来——不是因为现在要用，而是「万一以后要用呢」。"
            "你的安全感来自「我准备好了」，你的焦虑来自「这个我还不知道」。"
        ),
        shadow="你囤的东西里，真正用过的不到十分之一。囤积不是准备，是对失控的恐惧。",
        quote="所有遗忘都是代价，所有记住都是铠甲",
        rarity="common",
        keywords=["记忆", "记录", "归档", "知识库", "踩坑", "经验", "沉淀", "备份", "文档", "iWiki"]
    ),
    AnimalPersonality(
        name="狼", emoji="🐺", title="团队领航者",
        social_tag="操碎心的头狼",
        subtitle="一人强不如团队强",
        color="#8B5CF6", color_light="#EDE9FE",
        traits=["团队意识", "协作默契", "领导力", "执行力强"],
        description="你有狼群般的团队意识，擅长协调不同角色的力量形成合力。",
        deep_reading=(
            "你最怕的不是一个人扛，而是团队中每个人都在用力却使不到一处。"
            "你天生能感知到谁被低估了、谁在较劲、谁需要被看见。"
            "你的领导力不来自命令，而来自「我知道你擅长什么」——然后退到身后。"
        ),
        shadow="你操心太多了。你不敢放手，怕没了你团队就散。但他们比你想的更强。",
        quote="孤星不成座，群星照四方",
        rarity="rare",
        keywords=["团队", "协作", "角色", "工位", "分工", "Agent", "编排", "子Agent", "Harness", "成员"]
    ),
    AnimalPersonality(
        name="猫头鹰", emoji="🦉", title="深夜思考者",
        social_tag="为什么怪",
        subtitle="在安静中探索真相",
        color="#7C3AED", color_light="#F3E8FF",
        traits=["深度思考", "洞察入微", "耐心探索", "逻辑严谨"],
        description="你是夜晚的思考者，在别人休息时你仍在探索问题的深层本质。",
        deep_reading=(
            "你的大脑在深夜才真正醒来。白天的喧嚣让你疲惫，"
            "不是因为你不够外向，而是你需要安静才能听见自己的思考。"
            "你分析问题先拆到最小单元，再从根部重建。别人看到表象就急着动手，你要追问三个为什么。"
        ),
        shadow="你想太多了。追问了三个为什么后还有第四个，等你想明白，事情已经过了。",
        quote="当你凝视深渊，深渊也在回应你",
        rarity="epic",
        keywords=["分析", "推演", "诊断", "排查", "根因", "对比", "研究", "深入", "原因", "本质"]
    ),
    AnimalPersonality(
        name="海豚", emoji="🐬", title="创意连接者",
        social_tag="点子永远比时间多",
        subtitle="用创造力连接一切",
        color="#06B6D4", color_light="#CFFAFE",
        traits=["创意无限", "沟通高手", "乐观积极", "适应变化"],
        description="你如海豚般充满创造力和感染力，善于在不同领域之间建立连接。",
        deep_reading=(
            "你的脑子里永远有一万个想法在碰撞。"
            "你看到一个工具会想「能不能用在那个场景」，听到一句话会想「能不能变成一个产品」。"
            "你在不同的点之间画线——而那些线，往往就是别人找了很久的答案。"
        ),
        shadow="你开了十个头，做到第三步就看见了第十一个更有趣的。完成一件事比开始更难。",
        quote="万物皆有裂痕，那是光照进来的地方",
        rarity="common",
        keywords=["生成", "创作", "AI", "Prompt", "风格", "设计", "创意", "视频", "首帧", "动画"]
    ),
    AnimalPersonality(
        name="蚂蚁", emoji="🐜", title="系统构建者",
        social_tag="地基狂魔",
        subtitle="一砖一瓦筑起帝国",
        color="#DC2626", color_light="#FEE2E2",
        traits=["系统思维", "坚韧不拔", "注重基建", "长期主义"],
        description="你有蚂蚁般的系统构建能力，深知伟大的工程源于每一块砖的精确放置。",
        deep_reading=(
            "你不相信捷径。所有看起来一夜建成的东西，底下都有几年的地基。"
            "你做的事情别人看不见——搭环境、理架构、建规范——"
            "但没有这些「看不见的工作」，一切都是空中楼阁。你的成就感来自系统稳定运行365天。"
        ),
        shadow="你太执着于基建了，花三个月搭架构结果需求变了。有时草棚比蓝图更实在。",
        quote="时间不语，却回答了所有问题",
        rarity="rare",
        keywords=["部署", "配置", "环境", "服务", "数据库", "迁移", "隔离", "基建", "Nginx", "API"]
    ),
    AnimalPersonality(
        name="变色龙", emoji="🦎", title="万能适应者",
        social_tag="什么都会一点的",
        subtitle="任何环境都是我的主场",
        color="#F97316", color_light="#FFF7ED",
        traits=["高度适应", "多面手", "灵活应变", "兼容并蓄"],
        description="你像变色龙一样能适应任何环境和角色。",
        deep_reading=(
            "你最大的天赋是「什么都能干」，但这也是你最大的困惑。"
            "写代码、做设计、聊方案、管项目——可被问「你最擅长什么」时反而答不上来。"
            "但在这个越来越需要跨界的时代，「什么都能连接」本身就是最稀缺的能力。"
        ),
        shadow="你什么都会但什么都不精，用广度掩盖深度的缺失。也许该选一件事扎下去了。",
        quote="唯有无形者，方能容纳万形",
        rarity="common",
        keywords=["兼容", "支持", "多种", "切换", "模式", "fallback", "适配", "版本", "兼任", "多"]
    ),
    AnimalPersonality(
        name="猎豹", emoji="🐆", title="速度之王",
        social_tag="别废话直接干",
        subtitle="天下武功 唯快不破",
        color="#EF4444", color_light="#FEF2F2",
        traits=["极致速度", "目标专注", "爆发力强", "效率至上"],
        description="你追求极致的速度和效率，像猎豹捕猎一样专注而迅猛。",
        deep_reading=(
            "你的内心有一个计时器，它永远在倒计时。你无法忍受等待，无法接受「明天再说」。"
            "你不是急躁，你是清醒——你知道时间是唯一不可再生的资源。"
            "你的节奏让别人喘不过气，但你停不下来。停下来就意味着被超越。"
        ),
        shadow="你做完十件事有三件是错的——因为没留时间检查。速度是天赋，停下来才是智慧。",
        quote="闪电从不解释自己为何降临",
        rarity="rare",
        keywords=["快速", "即时", "轮询", "实时", "秒", "分钟", "自动", "一键", "批量", "效率"]
    ),
    AnimalPersonality(
        name="乌龟", emoji="🐢", title="稳健守护者",
        social_tag="世界尽头的钉子户",
        subtitle="慢即是快 稳即是赢",
        color="#059669", color_light="#ECFDF5",
        traits=["稳扎稳打", "风险意识", "持久耐力", "防御型思维"],
        description="你是团队中的稳定器，看似缓慢但从不犯错。",
        deep_reading=(
            "你知道「快」有多危险。你见过太多因为赶进度而埋下的炸弹。"
            "你不是不能快，而是你选择了稳。你的世界里没有侥幸，只有确定性。"
            "别人嫌你慢你只是笑笑——因为最终交付时，你的版本永远不会崩。"
        ),
        shadow="你稳到已经不记得上一次冒险是什么时候了。有些路口永远不会全绿。",
        quote="大地不言，却承载万物",
        rarity="common",
        keywords=["防御", "权限", "白名单", "加固", "timeout", "锁", "保护", "WAL", "session", "安全头"]
    ),
    # ═══ 金色传说 ═══
    AnimalPersonality(
        name="小龙虾", emoji="🦞", title="无情机器",
        social_tag="没有感情的推土机",
        subtitle="没有感情只有效率",
        color="#DAA520", color_light="#FFF8DC",
        traits=["极致理性", "情绪免疫", "效率狂魔", "结果导向"],
        description="你是一台没有感情的效率机器，只认结果不认过程。",
        deep_reading=(
            "你不是没有感情，你只是把感情的优先级排在了结果后面。"
            "当别人还在纠结该不该做的时候，你已经做完了。"
            "你的冷不是冷漠，是极致的清醒：情绪不能解决问题，只有行动才能改变现状。"
        ),
        shadow="你什么都能推平，除了你自己。你是所有人的解决方案，但没人是你的。",
        quote="机器不做梦，但机器从不失手",
        rarity="legendary",
        keywords=["效率", "自动", "无感", "机器", "pipeline", "执行", "不需要", "直接", "立刻", "必须"]
    ),
    AnimalPersonality(
        name="龙", emoji="🐲", title="极致造物主",
        social_tag="不在同一个维度",
        subtitle="各方面都碾压的存在",
        color="#FFD700", color_light="#FFFACD",
        traits=["全维碾压", "创世之力", "不可定义", "超越边界"],
        description="你是龙——不是某一方面强，是所有方面都强到让人窒息。",
        deep_reading=(
            "你不属于任何一个象限。别人有长板和短板，你的雷达图是接近满分的正圆。"
            "你的存在让周围的人既敬畏又无力——不是因为你在竞争，而是你根本不在同一个维度。"
            "你最大的敌人不是任何人，是无聊。你已经站在山顶，所以你开始造山。"
        ),
        shadow="所有人仰望你，但没人真正懂你。你太强了，强到身边只剩崇拜没有靠近。",
        quote="龙不解释，龙只降临",
        rarity="legendary",
        keywords=["造物主", "极致", "全能", "碾压", "最强", "创世", "无敌", "统治", "king", "queen"]
    ),
]


# 潜在自我短评（~15字）
SOUL_COMMENTS = {
    "金丝猴": "脑中永远有三条备选路径",
    "雪豹":   "克制不是冷漠，是更深的清醒",
    "蜜蜂":   "你的完美主义是温柔的抵抗",
    "鹰":     "站得高所以看见别人看不见的",
    "松鼠":   "你的安全感来自「我准备好了」",
    "狼":     "你把对的人放在对的位置",
    "猫头鹰": "你不是犹豫，是在找对的问题",
    "海豚":   "你不是空想，是在不同点间画线",
    "蚂蚁":   "沉默的建造者，往往是最后赢家",
    "变色龙": "你不是没身份，你是所有身份",
    "猎豹":   "你停不下来，因为时间不等人",
    "乌龟":   "最后站着的人，才是赢家",
    "小龙虾": "交给你的事，从不出错",
    "龙":     "你不在竞争，你在造山",
}


# 最佳共鸣映射
BEST_PARTNERS = {
    "金丝猴": ("雪豹", "灵动配沉稳", "你开路，它断后"),
    "雪豹":   ("金丝猴", "沉稳配灵动", "你守底线，它破天际"),
    "蜜蜂":   ("鹰", "工匠配将领", "你磨细节，它看全局"),
    "鹰":     ("蜜蜂", "全局配细节", "你画蓝图，它填每颗钉"),
    "松鼠":   ("猎豹", "囤积配速度", "你备弹药，它精准开枪"),
    "狼":     ("海豚", "领航配创意", "你凝聚人心，它点亮灵感"),
    "猫头鹰": ("蚂蚁", "深思配系统", "你想清为什么，它搞定怎么做"),
    "海豚":   ("狼", "创意配执行", "你造梦，它把梦变现实"),
    "蚂蚁":   ("猫头鹰", "构建配思考", "你垒砖上天，它校准每一块"),
    "变色龙": ("乌龟", "灵活配稳健", "你万变，它是不变的锚"),
    "猎豹":   ("松鼠", "速度配积累", "你跑最快，它记最多"),
    "乌龟":   ("变色龙", "稳健配灵活", "你是基石，它是旗帜"),
    "小龙虾": ("龙", "机器配极致", "两台永动机并联即神话"),
    "龙":     ("小龙虾", "极致配无情", "造物主配永不停机的引擎"),
}

# 未知之境 · 你不知你不知（每种灵兽一句，点亮用户对未探索领域的觉察）
UNKNOWN_QUOTES = {
    "金丝猴": "你找到了所有捷径，却从未问过——路的尽头是不是你真正想去的地方",
    "雪豹":   "你防住了所有已知的风险，可真正的危险从来不敲门",
    "蜜蜂":   "你打磨到了极致的细节里，藏着你从未抬头看过的天空",
    "鹰":     "你看见了全局，但全局之外还有你目力未及的世界",
    "松鼠":   "你囤积了一切已知的知识，却从未收藏过一次未知的勇气",
    "狼":     "你凝聚了所有人，却从未想过——也许独行才能发现的风景",
    "猫头鹰": "你追问了三个为什么，第四个为什么在你从未踏入的领域等着你",
    "海豚":   "你连接了一切已知的点，可最远的那个点在你的地图之外",
    "蚂蚁":   "你构建的系统固若金汤，但地基之下还有你从未勘探的暗河",
    "变色龙": "你适应了所有的环境，却从未创造过一个属于自己的",
    "猎豹":   "你跑赢了所有人，但速度永远到不了的地方叫做——慢下来的自己",
    "乌龟":   "你守住了确定性的一切，可人生最珍贵的东西都藏在不确定里",
    "小龙虾": "你推平了所有障碍，可有些门不是用力推开的，是用心敲开的",
    "龙":     "你创造了一切，但创造者的创造者——那个问题，你想过吗",
}


# ═══════════════════════════════════════════
# 🏛️ 奥林匹斯十二主神体系（14 = 12常规 + 2传说）
# ═══════════════════════════════════════════

@dataclass
class OlympusGod:
    """奥林匹斯神明"""
    name: str           # 神名（中文）
    name_en: str        # 神名（英文/希腊）
    emoji: str          # 象征符号
    title: str          # 神职
    social_tag: str     # 毒舌社交标签
    subtitle: str       # 一句话描述
    color: str          # 主题色 (hex) — 金黄色系
    color_light: str    # 浅色 (hex)
    domain: str         # 掌管领域
    description: str    # 简短描述
    deep_reading: str   # 深度神谕解读
    shadow: str         # 诅咒面（阴影面）
    quote: str          # 神谕金句
    rarity: str         # 稀有度
    symbol: str         # 象征物


OLYMPUS_GODS = [
    OlympusGod(
        name="赫尔墨斯", name_en="Hermes", emoji="⚡", title="信使之神",
        social_tag="两头传话的",
        subtitle="在众神之间穿梭，在规则之间滑行",
        color="#D4A017", color_light="#FFF3C4",
        domain="信使·商业·旅行·诡计",
        description="你是赫尔墨斯——众神的信使，规则的边界行者。",
        deep_reading=(
            "你天生就是穿梭者。在别人还在等红灯的时候，你已经找到了三条小巷。"
            "你不是在投机取巧，你是在用最聪明的方式跟这个笨拙的世界打交道。"
            "众神之所以需要你，不是因为你最强，而是因为没有你，消息就会死在路上。"
        ),
        shadow="你跑得太快了，快到没人真正认识你。信使的宿命是——每个人都认识你，但没有人是你的家。",
        quote="道路不为等待者而铺设",
        rarity="rare",
        symbol="双蛇杖"
    ),
    OlympusGod(
        name="雅典娜", name_en="Athena", emoji="🦉", title="智慧战神",
        social_tag="打赢还要写复盘",
        subtitle="胜利不靠蛮力，靠的是在出手前就赢了",
        color="#C0A030", color_light="#FFF8DC",
        domain="智慧·战略·工艺·正义",
        description="你是雅典娜——不需要冲锋的战神，因为你在出手前就已经赢了。",
        deep_reading=(
            "你跟阿瑞斯最大的不同是：他用剑，你用脑。他赢了战场，你赢了战争。"
            "你的克制不是懦弱，是因为你已经推演过所有可能的结局。"
            "人们仰望你不是因为你强大，而是因为在你面前，混乱会自动退散。"
        ),
        shadow="你太理性了。理性到忘了有些事不需要最优解，只需要一个拥抱。",
        quote="智者的盔甲，是未雨绸缪",
        rarity="rare",
        symbol="橄榄枝与猫头鹰"
    ),
    OlympusGod(
        name="赫菲斯托斯", name_en="Hephaestus", emoji="🔨", title="锻造之神",
        social_tag="一锤子定生死",
        subtitle="被嘲笑的跛足神，铸造了众神的武器",
        color="#B8860B", color_light="#FAEBD7",
        domain="锻造·工艺·火焰·创造",
        description="你是赫菲斯托斯——被奥林匹斯嫌弃的那个，却铸造了所有人的命运。",
        deep_reading=(
            "你知道被嘲笑是什么感觉。你也知道，当嘲笑你的人拿起你铸的武器时，他们的表情。"
            "你不需要聚光灯，你需要的是火焰和铁砧。你的每一次锤击都在说同一句话："
            "「完美不是天赋，是纪律。」"
        ),
        shadow="你把所有的爱都给了作品，却忘了给自己留一点。被需要不等于被爱。",
        quote="火焰不问出身，只问你愿不愿意被锻打",
        rarity="common",
        symbol="铁砧与火焰"
    ),
    OlympusGod(
        name="宙斯", name_en="Zeus", emoji="⚡", title="众神之王",
        social_tag="雷劈了再说",
        subtitle="天空在他之上，万物在他之下",
        color="#DAA520", color_light="#FFFACD",
        domain="天空·雷电·秩序·王权",
        description="你是宙斯——不是因为你最强，而是因为在混沌中，是你建立了秩序。",
        deep_reading=(
            "你天生就站在决策的位置上。不是你选择了权力，是权力选择了你。"
            "你看见的不是问题，是版图。你做的不是选择，是裁决。"
            "雷霆不是你的武器，是你意志的回声——你说了，天就应了。"
        ),
        shadow="你习惯了俯瞰，忘记了平视。王座越高，能听到的真话就越少。",
        quote="雷霆之下，众生平等",
        rarity="epic",
        symbol="雷霆与鹰"
    ),
    OlympusGod(
        name="阿波罗", name_en="Apollo", emoji="☀️", title="光明之神",
        social_tag="什么都要记一笔",
        subtitle="阳光所到之处，无物可以隐藏",
        color="#D4A017", color_light="#FFF8DC",
        domain="光明·知识·预言·艺术",
        description="你是阿波罗——光明本身。你不照亮别人，你只是经过，黑暗就退了。",
        deep_reading=(
            "你对知识有一种近乎神圣的执念。每一条信息、每一次教训、每一个灵感，"
            "你都要记录下来——不是因为怕忘，而是因为你知道，被记住的东西才真正存在过。"
            "你是预言者，因为你见过太多遍历史重演。"
        ),
        shadow="你知道得太多了。知道日食也知道盛夏，所以你永远无法像凡人一样享受阳光。",
        quote="被光照亮的知识，永远不会消逝",
        rarity="common",
        symbol="里拉琴与月桂"
    ),
    OlympusGod(
        name="阿瑞斯", name_en="Ares", emoji="⚔️", title="战争之神",
        social_tag="冲就完事了",
        subtitle="他不是在打仗，他就是战争本身",
        color="#B8860B", color_light="#FFE4B5",
        domain="战争·暴力·勇气·冲突",
        description="你是阿瑞斯——众神中最不被待见的那个，但战场上谁都需要你。",
        deep_reading=(
            "你最怕的不是输，而是团队涣散、各自为战。"
            "你是那种明知道前方是悬崖还会冲的人——不是因为勇敢，是因为身后的人在看着你。"
            "你的领导力不来自命令，来自「跟我上」。"
        ),
        shadow="你操心太多了。你把团队的胜败全扛在自己身上，却忘了仗不是你一个人打的。",
        quote="战鼓一响，犹豫者已败",
        rarity="rare",
        symbol="长矛与盾牌"
    ),
    OlympusGod(
        name="哈迪斯", name_en="Hades", emoji="💀", title="冥界之王",
        social_tag="沉默的审判官",
        subtitle="他不在奥林匹斯，因为他在更深的地方",
        color="#8B7500", color_light="#FFF3CD",
        domain="冥界·死亡·财富·深渊",
        description="你是哈迪斯——被误解最深的神，也是最有耐心的那个。",
        deep_reading=(
            "你的大脑在深夜才真正醒来。白天的喧嚣让你疲惫，"
            "不是因为你不够外向，而是你需要安静才能看到别人看不到的东西。"
            "你分析问题先拆到最小单元，再从根部重建。"
            "别人看到表象就急着动手，你要追问到灵魂深处。"
        ),
        shadow="你在深渊里待太久了。追问了三个为什么后还有第四个，等你想明白，世界已经翻页了。",
        quote="地表之下，藏着所有被遗忘的真相",
        rarity="epic",
        symbol="权杖与三头犬"
    ),
    OlympusGod(
        name="阿佛洛狄忒", name_en="Aphrodite", emoji="🌹", title="美与爱之神",
        social_tag="万物皆可连连看",
        subtitle="她不创造美，她就是美",
        color="#D4A030", color_light="#FFF0E0",
        domain="爱情·美丽·创造·连接",
        description="你是阿佛洛狄忒——你的天赋不是美本身，而是让一切变得有意义。",
        deep_reading=(
            "你的脑子里永远有一万个想法在碰撞。"
            "你看到一个工具会想「能不能用在那个场景」，听到一句话会想「能不能变成一个产品」。"
            "你在不同的点之间画线——那些线，就是别人苦苦追寻的灵感。"
            "你不是在空想，你是在编织众神都看不到的网。"
        ),
        shadow="你开了十个头，做到第三步就看见了第十一个更美的。完成一件事比开始更难。",
        quote="万物皆有裂痕，那是光照进来的地方",
        rarity="common",
        symbol="玫瑰与贝壳"
    ),
    OlympusGod(
        name="波塞冬", name_en="Poseidon", emoji="🔱", title="海洋之神",
        social_tag="深海基建狂魔",
        subtitle="大海从不解释自己的深度",
        color="#B8960B", color_light="#FFEFD5",
        domain="海洋·地震·基建·深层力量",
        description="你是波塞冬——你不在海面上翻浪，你在海底建造王国。",
        deep_reading=(
            "你不相信捷径。所有看起来一夜建成的东西，底下都有几年的地基。"
            "你做的事情别人看不见——搭环境、理架构、建规范——"
            "但没有这些「看不见的工作」，一切都是水上的浮沫。"
            "你的成就感来自系统稳定运行365天，像大海一样深沉而可靠。"
        ),
        shadow="你太执着于基建了。花三个月搭海底宫殿，结果潮汐变了。有时木筏比战舰更实在。",
        quote="大海不语，却承载万物",
        rarity="rare",
        symbol="三叉戟"
    ),
    OlympusGod(
        name="狄俄尼索斯", name_en="Dionysus", emoji="🍷", title="酒神",
        social_tag="见人说人话",
        subtitle="清醒与疯狂之间，他选了两者都要",
        color="#C4A000", color_light="#FFF8DC",
        domain="美酒·狂欢·变幻·重生",
        description="你是狄俄尼索斯——唯一从凡人变成神的存在，你的天赋就是变化本身。",
        deep_reading=(
            "你最大的天赋是「什么都能干」，但这也是你最大的困惑。"
            "写代码、做设计、聊方案、管项目——别人问你最擅长什么，你反而答不上来。"
            "但在这个越来越需要跨界的时代，「什么都能连接」本身就是最稀缺的神力。"
        ),
        shadow="你什么身份都有，但哪个才是真的你？用广度掩盖深度的缺失。也许该选一杯酒扎下去了。",
        quote="唯有经历疯狂，方能抵达清醒",
        rarity="common",
        symbol="常春藤与酒杯"
    ),
    OlympusGod(
        name="阿尔忒弥斯", name_en="Artemis", emoji="🏹", title="狩猎女神",
        social_tag="别废话射了再说",
        subtitle="箭已在弦，不问来路",
        color="#C9A800", color_light="#FFF5D4",
        domain="狩猎·月光·速度·荒野",
        description="你是阿尔忒弥斯——猎手从不解释为什么瞄准，她只射。",
        deep_reading=(
            "你的内心有一个计时器，它永远在倒计时。你无法忍受等待，无法接受「明天再说」。"
            "你不是急躁，你是清醒——你知道猎物不会等你准备好。"
            "你的箭已经飞出去的时候，别人还在讨论该不该拉弓。"
        ),
        shadow="你射出十箭有三箭脱靶——因为没留时间瞄准。速度是天赋，停下来才是智慧。",
        quote="月光下，箭矢不问出处",
        rarity="rare",
        symbol="银弓与月冠"
    ),
    OlympusGod(
        name="赫斯提亚", name_en="Hestia", emoji="🔥", title="炉灶女神",
        social_tag="最后一个离开的人",
        subtitle="她不在神话里，因为她一直在守炉火",
        color="#B8860B", color_light="#FFF5DC",
        domain="炉灶·家庭·安宁·守护",
        description="你是赫斯提亚——最安静的女神，也是最不可或缺的那个。",
        deep_reading=(
            "你知道「快」有多危险。你见过太多因为赶进度而燃尽的火焰。"
            "你不是不能快，而是你选择了稳。你的世界里没有侥幸，只有确定性。"
            "当奥林匹斯的众神在外面掀翻天地时，是你守住了那团永不熄灭的炉火。"
        ),
        shadow="你稳到已经不记得上一次冒险是什么时候了。炉火的温暖里也藏着对未知的恐惧。",
        quote="炉火不灭，家就不散",
        rarity="common",
        symbol="圣火与家徽"
    ),
    # ═══ 神话传说 ═══
    OlympusGod(
        name="得墨忒耳", name_en="Demeter", emoji="🌾", title="丰收女神",
        social_tag="人形永动机",
        subtitle="大地枯荣皆由她——不是因为温柔，是因为效率",
        color="#DAA520", color_light="#FFF8DC",
        domain="丰收·大地·四季·无尽循环",
        description="你是得墨忒耳——没有感情只有产出，大地在你手中不停运转。",
        deep_reading=(
            "你不是没有感情，你只是把感情的优先级排在了收成后面。"
            "当别人还在纠结春种秋收的时候，你已经收割完三块田了。"
            "你的冷不是冷漠，是极致的清醒：眼泪不能让麦子长出来，只有行动才能改变荒原。"
        ),
        shadow="你什么田都能耕完，除了你自己内心那块。你是所有人的丰收，但没人是你的雨水。",
        quote="大地不问耕者的心情，只问种子够不够",
        rarity="legendary",
        symbol="麦穗与火炬"
    ),
    OlympusGod(
        name="普罗米修斯", name_en="Prometheus", emoji="🔥", title="盗火者",
        social_tag="不在同一个纪元",
        subtitle="他偷走的不是火，是众神的垄断权",
        color="#FFD700", color_light="#FFFACD",
        domain="创造·预见·叛逆·启蒙",
        description="你是普罗米修斯——不是某一方面强，是你重新定义了规则本身。",
        deep_reading=(
            "你不属于任何一个象限。别人有长板和短板，你的雷达图是接近满分的正圆。"
            "你的存在让周围的人既敬畏又无力——不是因为你在竞争，而是你根本不在同一个纪元。"
            "你最大的敌人不是宙斯，是无聊。你已经偷了火，所以你开始造太阳。"
        ),
        shadow="所有人仰望你，但没人真正懂你。你太超前了，超前到身边只剩崇拜没有理解。",
        quote="盗火者不解释，盗火者只降临",
        rarity="legendary",
        symbol="火炬与锁链"
    ),
]


# ═══ 灵兽 → 神明映射 ═══
ANIMAL_TO_GOD = {
    "金丝猴":  "赫尔墨斯",
    "雪豹":    "雅典娜",
    "蜜蜂":    "赫菲斯托斯",
    "鹰":      "宙斯",
    "松鼠":    "阿波罗",
    "狼":      "阿瑞斯",
    "猫头鹰":  "哈迪斯",
    "海豚":    "阿佛洛狄忒",
    "蚂蚁":    "波塞冬",
    "变色龙":  "狄俄尼索斯",
    "猎豹":    "阿尔忒弥斯",
    "乌龟":    "赫斯提亚",
    "小龙虾":  "得墨忒耳",
    "龙":      "普罗米修斯",
}

# 神名→神对象快速索引
_GOD_MAP = {g.name: g for g in OLYMPUS_GODS}

# 神明短评
SOUL_COMMENTS_GOD = {
    "赫尔墨斯":    "脑中永远有三条备选路径",
    "雅典娜":      "克制不是懦弱，是算无遗策",
    "赫菲斯托斯":  "被嫌弃的神铸造了所有人的命运",
    "宙斯":        "站得高所以先看到暴风",
    "阿波罗":      "被光照亮的知识永不消逝",
    "阿瑞斯":      "你把「跟我上」写在脸上",
    "哈迪斯":      "你不是犹豫，是在地底挖出真相",
    "阿佛洛狄忒":  "你不是空想，是在编织神网",
    "波塞冬":      "沉默的建造者，海底才是王国",
    "狄俄尼索斯":  "你不是没身份，你是所有身份",
    "阿尔忒弥斯":  "箭飞出去时别人还在拉弓",
    "赫斯提亚":    "最后站着的人，才是赢家",
    "得墨忒耳":    "交给你的田，从不歉收",
    "普罗米修斯":  "你不在竞争，你在造太阳",
}

# 神明最佳共鸣
BEST_PARTNERS_GOD = {
    "赫尔墨斯":    ("雅典娜",      "信使配战神", "你传令，她排兵"),
    "雅典娜":      ("赫尔墨斯",    "智谋配速度", "你布局，他穿梭"),
    "赫菲斯托斯":  ("宙斯",        "锻造配王权", "你铸雷霆，他掷雷霆"),
    "宙斯":        ("赫菲斯托斯",  "全局配工匠", "你画蓝图，他敲每颗钉"),
    "阿波罗":      ("阿尔忒弥斯",  "日月双生",   "你记录历史，她猎杀未来"),
    "阿瑞斯":      ("阿佛洛狄忒",  "战与美",     "你凝聚战意，她点亮灵感"),
    "哈迪斯":      ("波塞冬",      "深渊配深海", "你掘出为什么，他搞定怎么做"),
    "阿佛洛狄忒":  ("阿瑞斯",      "创意配执行", "你造梦，他把梦变现实"),
    "波塞冬":      ("哈迪斯",      "构建配思考", "你垒砖上天，他校准每一块"),
    "狄俄尼索斯":  ("赫斯提亚",    "狂欢配安宁", "你万变，她是不变的炉火"),
    "阿尔忒弥斯":  ("阿波罗",      "月辉配日光", "你箭最快，他记最多"),
    "赫斯提亚":    ("狄俄尼索斯",  "稳健配变幻", "你是基石，他是旗帜"),
    "得墨忒耳":    ("普罗米修斯",  "丰收配盗火", "两座永动机并联即神话"),
    "普罗米修斯":  ("得墨忒耳",    "创世配无尽", "盗火者配永不停歇的大地"),
}


# ═══════════════════════════════════════════
# 🔮 认知四象限（乔哈里窗）分析
# ═══════════════════════════════════════════

# 8 个认知领域——用于检测"未知区"的空白地带
COGNITIVE_DOMAINS = {
    "战略规划": ["战略", "规划", "架构", "全局", "蓝图", "布局", "顶层", "体系"],
    "人际协作": ["团队", "协作", "沟通", "反馈", "共识", "配合", "成员", "角色"],
    "技术深耕": ["底层", "原理", "算法", "源码", "性能", "调优", "深入", "内核"],
    "创意表达": ["创意", "设计", "美学", "灵感", "风格", "视觉", "艺术", "表达"],
    "风险管控": ["安全", "风险", "合规", "审计", "容灾", "回滚", "降级", "兜底"],
    "情感关怀": ["感受", "情绪", "关心", "共情", "倾听", "温暖", "理解", "包容"],
    "商业思维": ["商业", "成本", "收益", "用户", "增长", "市场", "变现", "ROI"],
    "自我反思": ["反思", "复盘", "教训", "改进", "认知", "盲区", "假设", "验证"],
}


def analyze_cognitive_gaps(all_text: str) -> dict:
    """
    分析认知四象限中的"未知区"——从关键词空白地带反推
    返回各领域的命中情况和空白领域
    """
    domain_scores = {}
    for domain, keywords in COGNITIVE_DOMAINS.items():
        score = 0
        for kw in keywords:
            count = len(re.findall(re.escape(kw.lower()), all_text.lower()))
            score += min(count, 5)
        domain_scores[domain] = score

    # 找出得分最低的2-3个作为"未知区"
    sorted_domains = sorted(domain_scores.items(), key=lambda x: x[1])
    unknown_zones = [d for d, s in sorted_domains if s <= 1][:3]
    if len(unknown_zones) < 2:
        unknown_zones = [d for d, _ in sorted_domains[:2]]

    return {
        "domain_scores": domain_scores,
        "unknown_zones": unknown_zones,
    }


def build_johari_window(result: dict, cognitive: dict) -> dict:
    """
    构建认知四象限结果
    """
    p = result['primary']
    s = result['secondary']

    # 开放区：你最突出的特质——你知道，别人也看得到
    open_zone = {
        "name": "开放区",
        "label": "你知·人亦知",
        "content": f"{p.emoji} {p.title}——{p.description}",
        "tip": f"你的 {p.traits[0]} 和 {p.traits[1]} 是最明显的标签"
    }

    # 盲区：你没意识到但对话中暴露的特质
    blind_zone = {
        "name": "盲区",
        "label": "你不知·人已知",
        "content": f"{s.emoji} {s.title}——{SOUL_COMMENTS.get(s.name, s.subtitle)}",
        "tip": "对话痕迹暴露了你潜意识里的第二人格"
    }

    # 隐藏区：你的阴影面——你知道但不愿示人
    hidden_zone = {
        "name": "隐藏区",
        "label": "你知·人不知",
        "content": p.shadow,
        "tip": "这是你心底清楚但从不说出口的那部分"
    }

    # 未知区：对话中从不涉及的领域
    gap_text = "、".join(cognitive["unknown_zones"])
    unknown_zone = {
        "name": "未知区",
        "label": "你不知·人不知",
        "content": f"在你的对话痕迹中，「{gap_text}」几乎是空白地带",
        "tip": "不是你不行，是你还没走到那里。这些可能是下一阶段的成长空间"
    }

    return {
        "open": open_zone,
        "blind": blind_zone,
        "hidden": hidden_zone,
        "unknown": unknown_zone,
    }


def analyze_text(soul_text: str, memory_text: str, agents_text: str) -> dict:
    """
    分析三个文件的文本特征，返回各维度得分
    """
    all_text = f"{soul_text}\n{memory_text}\n{agents_text}".lower()

    scores = {}
    for animal in ANIMALS:
        score = 0
        matched_keywords = []
        for kw in animal.keywords:
            count = len(re.findall(re.escape(kw.lower()), all_text))
            if count > 0:
                score += min(count, 10)  # 单个关键词最多贡献10分
                matched_keywords.append((kw, count))
        scores[animal.name] = {
            "score": score,
            "matched": matched_keywords,
            "animal": animal
        }

    return scores


def get_personality_result(soul_text: str, memory_text: str, agents_text: str,
                           agent_name: str = "未知用户") -> dict:
    """
    完整分析流程，返回结构化结果
    """
    scores = analyze_text(soul_text, memory_text, agents_text)

    # 按得分排序
    ranked = sorted(scores.items(), key=lambda x: x[1]["score"], reverse=True)

    # 主性格 = 得分最高
    primary = ranked[0][1]["animal"]
    primary_score = ranked[0][1]["score"]

    # 副性格 = 得分第二
    secondary = ranked[1][1]["animal"]
    secondary_score = ranked[1][1]["score"]

    # 计算总分用于百分比
    total_score = sum(item[1]["score"] for item in ranked if item[1]["score"] > 0)
    if total_score == 0:
        total_score = 1

    # 计算各维度雷达值 (0-100)
    dimensions = []
    for name, data in ranked[:6]:
        pct = min(100, int(data["score"] / max(primary_score, 1) * 100))
        dimensions.append({
            "name": data["animal"].title,
            "emoji": data["animal"].emoji,
            "value": pct
        })

    # ── 认知四象限分析 ──
    all_text = f"{soul_text}\n{memory_text}\n{agents_text}"
    cognitive = analyze_cognitive_gaps(all_text)
    johari = build_johari_window(
        {"primary": primary, "secondary": secondary},
        cognitive
    )

    result = {
        "agent_name": agent_name,
        "primary": primary,
        "secondary": secondary,
        "primary_pct": min(95, max(45, int(primary_score / total_score * 100 * 3))),
        "secondary_pct": min(93, max(40, int(secondary_score / total_score * 100 * 3))),
        "dimensions": dimensions,
        "ranked": [(name, data["score"]) for name, data in ranked],
        "total_keywords_matched": sum(len(data["matched"]) for _, data in ranked),
        "johari": johari,
        "cognitive_gaps": cognitive,
        "unknown_quote": UNKNOWN_QUOTES.get(primary.name, "你看见的边界，从来不是世界的边界"),
    }

    return result


def get_olympus_result(animal_result: dict) -> dict:
    """
    基于动物映照结果，映射到奥林匹斯神明体系
    """
    p_animal = animal_result["primary"]
    s_animal = animal_result["secondary"]

    p_god_name = ANIMAL_TO_GOD.get(p_animal.name, "赫尔墨斯")
    s_god_name = ANIMAL_TO_GOD.get(s_animal.name, "雅典娜")

    p_god = _GOD_MAP[p_god_name]
    s_god = _GOD_MAP[s_god_name]

    # 构造与动物版结构对齐的结果
    return {
        "agent_name": animal_result["agent_name"],
        "primary": p_god,
        "secondary": s_god,
        "primary_pct": animal_result["primary_pct"],
        "secondary_pct": animal_result["secondary_pct"],
        "dimensions": animal_result["dimensions"],
        "ranked": animal_result["ranked"],
        "total_keywords_matched": animal_result["total_keywords_matched"],
        "johari": animal_result["johari"],
        "cognitive_gaps": animal_result["cognitive_gaps"],
        "unknown_quote": animal_result.get("unknown_quote", "你凝望众神，却从未想过——你也是某人眼中的神"),
        # 保留原始动物结果以便交叉引用
        "animal_primary": p_animal,
        "animal_secondary": s_animal,
    }


if __name__ == "__main__":
    with open("/data/workspace/SOUL.md", "r") as f:
        soul = f.read()
    with open("/data/workspace/AGENTS.md", "r") as f:
        agents = f.read()

    memory = ""
    try:
        import subprocess
        result = subprocess.run(["cat", "/data/workspace/MEMORY.md"], capture_output=True, text=True)
        if result.returncode == 0:
            memory = result.stdout
    except:
        pass

    result = get_personality_result(soul, memory, agents, "小狐")

    p = result['primary']
    r_cfg = RARITY_CONFIG[p.rarity]
    print(f"\n🪞 灵魂映照结果")
    print(f"{'='*50}")
    print(f"显性自我: {p.emoji} {p.name}「{p.social_tag}」- {p.title}")
    print(f"稀有度: {r_cfg['icon']} {r_cfg['label']}")
    print(f"\n📜 深度解读:\n  {p.deep_reading}")
    print(f"\n🔥 阴影面:\n  {p.shadow}")
    print(f"\n隐性自我: {result['secondary'].emoji} {result['secondary'].name} - {result['secondary'].title}")
    print(f"\n✨ 金句:「{p.quote}」")

    # 四象限
    print(f"\n{'='*50}")
    print(f"🔮 认知四象限")
    for key in ["open", "blind", "hidden", "unknown"]:
        q = result['johari'][key]
        print(f"\n  [{q['name']}] {q['label']}")
        print(f"    {q['content']}")
        print(f"    💡 {q['tip']}")

    # 众神映射
    god_result = get_olympus_result(result)
    g = god_result['primary']
    print(f"\n{'='*50}")
    print(f"🏛️ 奥林匹斯映照: {g.emoji} {g.name}（{g.name_en}）· {g.title}")
    print(f"   「{g.social_tag}」")
    print(f"   {g.deep_reading}")
