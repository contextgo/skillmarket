"""
🏛️ 像素风奥林匹斯神明头像生成器
128×128 画布，像素块清晰可见
金黄色调为主，古希腊神话风格

14位神明：12常规 + 2传说
"""

from PIL import Image, ImageDraw

_ = None  # 透明


def _draw_god(size, draw_fn):
    """通用绘制入口"""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_fn(draw, size)
    return img


# ═══════════════════════════════════════════
#  12 常规神明
# ═══════════════════════════════════════════

def draw_hermes(draw, s):
    """赫尔墨斯 - 信使之神：飞翼帽+双蛇杖"""
    skin = (225, 195, 155)
    skin_l = (240, 215, 180)
    hair = (160, 120, 60)
    gold = (230, 195, 70)
    gold_l = (250, 225, 120)
    gold_d = (180, 150, 40)
    robe = (240, 230, 210)
    robe_d = (200, 190, 170)
    eye = (40, 35, 25)
    # 飞翼帽
    draw.rectangle([36, 4, 92, 20], fill=gold)
    draw.rectangle([44, 0, 84, 12], fill=gold_l)
    # 帽翼（左右）
    draw.rectangle([16, 8, 40, 16], fill=gold_l)
    draw.rectangle([8, 4, 24, 12], fill=gold)
    draw.rectangle([88, 8, 112, 16], fill=gold_l)
    draw.rectangle([104, 4, 120, 12], fill=gold)
    # 头
    draw.rectangle([36, 16, 92, 64], fill=skin)
    draw.rectangle([40, 20, 88, 60], fill=skin_l)
    # 头发
    draw.rectangle([36, 16, 92, 28], fill=hair)
    # 眼睛
    draw.rectangle([44, 36, 56, 46], fill=(255, 255, 240))
    draw.rectangle([48, 38, 56, 46], fill=eye)
    draw.rectangle([72, 36, 84, 46], fill=(255, 255, 240))
    draw.rectangle([76, 38, 84, 46], fill=eye)
    # 微笑
    draw.rectangle([52, 52, 76, 56], fill=(200, 160, 120))
    # 身体（白色长袍）
    draw.rectangle([32, 60, 96, 108], fill=robe)
    draw.rectangle([40, 64, 88, 104], fill=robe_d)
    # 金色腰带
    draw.rectangle([36, 76, 92, 82], fill=gold)
    # 双蛇杖（右手）
    draw.rectangle([96, 48, 104, 108], fill=gold_d)
    draw.rectangle([100, 40, 112, 52], fill=gold)
    draw.rectangle([92, 40, 100, 48], fill=gold)
    # 飞翼靴
    draw.rectangle([36, 104, 56, 120], fill=gold)
    draw.rectangle([28, 108, 40, 116], fill=gold_l)
    draw.rectangle([72, 104, 92, 120], fill=gold)
    draw.rectangle([88, 108, 100, 116], fill=gold_l)


def draw_athena(draw, s):
    """雅典娜 - 智慧战神：头盔+橄榄枝"""
    skin = (230, 200, 165)
    skin_l = (242, 220, 188)
    gold = (230, 195, 70)
    gold_l = (250, 225, 120)
    gold_d = (180, 150, 40)
    helmet = (190, 170, 130)
    helmet_l = (215, 200, 165)
    crest = (200, 60, 50)
    eye = (80, 130, 110)
    robe = (240, 235, 225)
    # 头盔冠羽
    draw.rectangle([56, 0, 72, 12], fill=crest)
    draw.rectangle([52, 4, 76, 16], fill=crest)
    # 头盔
    draw.rectangle([28, 12, 100, 36], fill=helmet)
    draw.rectangle([32, 16, 96, 32], fill=helmet_l)
    # 面甲鼻梁
    draw.rectangle([56, 32, 72, 48], fill=helmet)
    # 头/脸
    draw.rectangle([32, 32, 96, 68], fill=skin)
    draw.rectangle([36, 36, 92, 64], fill=skin_l)
    # 眼睛（灰绿智慧之眼）
    draw.rectangle([40, 40, 54, 50], fill=(230, 240, 235))
    draw.rectangle([44, 42, 54, 50], fill=eye)
    draw.rectangle([74, 40, 88, 50], fill=(230, 240, 235))
    draw.rectangle([78, 42, 88, 50], fill=eye)
    # 嘴
    draw.rectangle([52, 56, 76, 60], fill=(210, 175, 145))
    # 身体（白袍+金甲）
    draw.rectangle([28, 64, 100, 112], fill=robe)
    draw.rectangle([36, 68, 92, 80], fill=gold)
    draw.rectangle([40, 72, 88, 80], fill=gold_l)
    # 盾牌（左侧）
    draw.rectangle([8, 64, 32, 100], fill=gold_d)
    draw.rectangle([12, 68, 28, 96], fill=gold)
    draw.rectangle([16, 76, 24, 88], fill=gold_l)
    # 脚
    draw.rectangle([36, 108, 56, 122], fill=gold_d)
    draw.rectangle([72, 108, 92, 122], fill=gold_d)


def draw_hephaestus(draw, s):
    """赫菲斯托斯 - 锻造之神：铁锤+围裙+火焰"""
    skin = (200, 165, 125)
    skin_l = (220, 185, 145)
    beard = (120, 85, 50)
    apron = (140, 110, 80)
    apron_l = (170, 140, 100)
    fire = (255, 160, 40)
    fire_d = (230, 100, 30)
    hammer = (160, 160, 170)
    hammer_d = (120, 120, 130)
    eye = (35, 30, 20)
    # 头
    draw.rectangle([32, 12, 96, 60], fill=skin)
    draw.rectangle([36, 16, 92, 56], fill=skin_l)
    # 蓬乱头发
    draw.rectangle([28, 4, 100, 20], fill=beard)
    draw.rectangle([24, 8, 36, 24], fill=beard)
    draw.rectangle([92, 8, 104, 24], fill=beard)
    # 眼睛
    draw.rectangle([40, 28, 52, 38], fill=(240, 230, 210))
    draw.rectangle([44, 30, 52, 38], fill=eye)
    draw.rectangle([76, 28, 88, 38], fill=(240, 230, 210))
    draw.rectangle([80, 30, 88, 38], fill=eye)
    # 大胡子
    draw.rectangle([36, 44, 92, 64], fill=beard)
    draw.rectangle([44, 48, 84, 60], fill=(140, 100, 60))
    # 身体（围裙）
    draw.rectangle([28, 60, 100, 108], fill=apron)
    draw.rectangle([36, 64, 92, 104], fill=apron_l)
    # 铁锤（右手高举）
    draw.rectangle([96, 8, 104, 64], fill=(100, 80, 50))
    draw.rectangle([88, 4, 116, 16], fill=hammer)
    draw.rectangle([92, 0, 112, 12], fill=hammer_d)
    # 火焰（左下角）
    draw.rectangle([4, 88, 28, 112], fill=fire_d)
    draw.rectangle([8, 80, 24, 96], fill=fire)
    draw.rectangle([12, 72, 20, 84], fill=(255, 220, 80))
    # 粗壮的脚
    draw.rectangle([32, 104, 56, 120], fill=(100, 80, 50))
    draw.rectangle([72, 104, 96, 120], fill=(100, 80, 50))


def draw_zeus(draw, s):
    """宙斯 - 众神之王：雷霆+王冠+白袍"""
    skin = (225, 195, 160)
    skin_l = (240, 215, 182)
    beard = (200, 200, 210)
    beard_l = (225, 225, 235)
    gold = (240, 205, 70)
    gold_l = (255, 230, 120)
    gold_d = (190, 160, 40)
    robe = (245, 240, 232)
    robe_d = (210, 205, 195)
    lightning = (255, 240, 100)
    eye = (60, 80, 140)
    # 王冠
    draw.rectangle([32, 0, 96, 12], fill=gold)
    draw.rectangle([40, 0, 48, 8], fill=gold_l)
    draw.rectangle([60, 0, 68, 8], fill=gold_l)
    draw.rectangle([80, 0, 88, 8], fill=gold_l)
    draw.rectangle([36, 0, 44, 4], fill=gold_l)
    draw.rectangle([56, 0, 64, 4], fill=gold_l)
    draw.rectangle([76, 0, 84, 4], fill=gold_l)
    # 头
    draw.rectangle([32, 12, 96, 56], fill=skin)
    draw.rectangle([36, 16, 92, 52], fill=skin_l)
    # 头发
    draw.rectangle([28, 12, 100, 24], fill=beard)
    draw.rectangle([24, 16, 36, 36], fill=beard)
    draw.rectangle([92, 16, 104, 36], fill=beard)
    # 眼睛（威严的蓝）
    draw.rectangle([40, 28, 54, 40], fill=(210, 220, 240))
    draw.rectangle([46, 30, 54, 40], fill=eye)
    draw.rectangle([74, 28, 88, 40], fill=(210, 220, 240))
    draw.rectangle([80, 30, 88, 40], fill=eye)
    # 胡子
    draw.rectangle([36, 44, 92, 68], fill=beard)
    draw.rectangle([40, 48, 88, 64], fill=beard_l)
    # 白色长袍
    draw.rectangle([24, 64, 104, 112], fill=robe)
    draw.rectangle([32, 68, 96, 108], fill=robe_d)
    # 金色腰带
    draw.rectangle([28, 76, 100, 82], fill=gold)
    draw.rectangle([32, 78, 96, 82], fill=gold_d)
    # 雷霆（右手）
    draw.rectangle([100, 36, 108, 76], fill=lightning)
    draw.rectangle([104, 28, 116, 44], fill=(255, 255, 180))
    draw.rectangle([108, 44, 120, 60], fill=lightning)
    draw.rectangle([96, 60, 112, 72], fill=lightning)
    # 脚
    draw.rectangle([36, 108, 56, 122], fill=gold_d)
    draw.rectangle([72, 108, 92, 122], fill=gold_d)


def draw_apollo(draw, s):
    """阿波罗 - 光明之神：月桂冠+里拉琴+光环"""
    skin = (235, 205, 170)
    skin_l = (245, 220, 190)
    hair = (210, 175, 80)
    hair_l = (230, 200, 110)
    laurel = (100, 170, 80)
    laurel_l = (140, 200, 110)
    gold = (240, 210, 80)
    robe = (250, 245, 235)
    robe_d = (220, 215, 200)
    eye = (80, 130, 180)
    # 光环
    draw.rectangle([40, 0, 88, 6], fill=(255, 245, 180))
    draw.rectangle([32, 2, 96, 8], fill=(255, 240, 150))
    # 月桂冠
    draw.rectangle([28, 8, 40, 20], fill=laurel)
    draw.rectangle([88, 8, 100, 20], fill=laurel)
    draw.rectangle([36, 4, 92, 12], fill=laurel_l)
    # 头
    draw.rectangle([32, 12, 96, 60], fill=skin)
    draw.rectangle([36, 16, 92, 56], fill=skin_l)
    # 金发
    draw.rectangle([32, 12, 96, 24], fill=hair)
    draw.rectangle([28, 16, 36, 32], fill=hair_l)
    draw.rectangle([92, 16, 100, 32], fill=hair_l)
    # 眼睛（明亮蓝）
    draw.rectangle([40, 32, 54, 42], fill=(220, 235, 250))
    draw.rectangle([46, 34, 54, 42], fill=eye)
    draw.rectangle([74, 32, 88, 42], fill=(220, 235, 250))
    draw.rectangle([80, 34, 88, 42], fill=eye)
    # 微笑
    draw.rectangle([52, 48, 76, 52], fill=(210, 175, 145))
    # 白色长袍
    draw.rectangle([28, 56, 100, 108], fill=robe)
    draw.rectangle([36, 60, 92, 104], fill=robe_d)
    # 金色腰带
    draw.rectangle([32, 72, 96, 78], fill=gold)
    # 里拉琴（左手）
    draw.rectangle([4, 56, 28, 64], fill=gold)
    draw.rectangle([8, 52, 12, 80], fill=(180, 140, 50))
    draw.rectangle([20, 52, 24, 80], fill=(180, 140, 50))
    draw.rectangle([8, 64, 24, 68], fill=gold)
    draw.rectangle([8, 72, 24, 76], fill=gold)
    # 脚
    draw.rectangle([36, 104, 56, 118], fill=(200, 185, 160))
    draw.rectangle([72, 104, 92, 118], fill=(200, 185, 160))


def draw_ares(draw, s):
    """阿瑞斯 - 战争之神：红色盔甲+长矛"""
    skin = (210, 175, 135)
    skin_l = (225, 195, 160)
    armor = (180, 50, 40)
    armor_l = (210, 70, 55)
    armor_d = (140, 35, 25)
    gold = (230, 195, 70)
    gold_d = (180, 150, 40)
    eye = (180, 50, 30)
    helmet = (140, 40, 30)
    crest = (200, 60, 40)
    # 头盔（斯巴达式）
    draw.rectangle([28, 4, 100, 20], fill=helmet)
    draw.rectangle([52, 0, 76, 8], fill=crest)
    draw.rectangle([56, 0, 72, 4], fill=(220, 80, 50))
    # 面部
    draw.rectangle([32, 16, 96, 60], fill=skin)
    draw.rectangle([36, 20, 92, 56], fill=skin_l)
    # 头盔护面
    draw.rectangle([28, 16, 36, 48], fill=helmet)
    draw.rectangle([92, 16, 100, 48], fill=helmet)
    # 怒目
    draw.rectangle([40, 32, 54, 42], fill=(255, 220, 200))
    draw.rectangle([46, 34, 54, 42], fill=eye)
    draw.rectangle([74, 32, 88, 42], fill=(255, 220, 200))
    draw.rectangle([80, 34, 88, 42], fill=eye)
    # 嘴（紧绷）
    draw.rectangle([52, 50, 76, 54], fill=(180, 140, 110))
    # 盔甲身体
    draw.rectangle([24, 56, 104, 108], fill=armor)
    draw.rectangle([32, 60, 96, 104], fill=armor_l)
    # 金色装饰
    draw.rectangle([28, 68, 100, 72], fill=gold)
    draw.rectangle([56, 60, 72, 100], fill=gold_d)
    # 长矛（右手）
    draw.rectangle([104, 0, 110, 120], fill=(160, 150, 140))
    draw.rectangle([102, 0, 112, 12], fill=(200, 200, 210))
    # 盾牌（左手）
    draw.rectangle([4, 60, 28, 100], fill=armor_d)
    draw.rectangle([8, 64, 24, 96], fill=armor)
    # 脚
    draw.rectangle([32, 104, 56, 120], fill=armor_d)
    draw.rectangle([72, 104, 96, 120], fill=armor_d)


def draw_hades(draw, s):
    """哈迪斯 - 冥界之王：暗金冠+权杖+暗色调"""
    skin = (195, 175, 155)
    skin_l = (210, 195, 175)
    hair = (50, 45, 40)
    crown = (160, 140, 60)
    crown_l = (190, 170, 80)
    robe = (45, 40, 55)
    robe_l = (65, 55, 75)
    gold = (200, 175, 70)
    gold_d = (150, 130, 50)
    eye = (160, 140, 60)
    # 暗金王冠
    draw.rectangle([32, 0, 96, 12], fill=crown)
    draw.rectangle([36, 0, 44, 8], fill=crown_l)
    draw.rectangle([60, 0, 68, 8], fill=crown_l)
    draw.rectangle([84, 0, 92, 8], fill=crown_l)
    # 头
    draw.rectangle([32, 12, 96, 60], fill=skin)
    draw.rectangle([36, 16, 92, 56], fill=skin_l)
    # 黑发
    draw.rectangle([28, 8, 100, 24], fill=hair)
    draw.rectangle([24, 16, 36, 40], fill=hair)
    draw.rectangle([92, 16, 104, 40], fill=hair)
    # 眼睛（琥珀色，深邃）
    draw.rectangle([40, 30, 54, 40], fill=(200, 190, 160))
    draw.rectangle([46, 32, 54, 40], fill=eye)
    draw.rectangle([74, 30, 88, 40], fill=(200, 190, 160))
    draw.rectangle([80, 32, 88, 40], fill=eye)
    # 黑胡子
    draw.rectangle([40, 48, 88, 64], fill=hair)
    draw.rectangle([44, 52, 84, 60], fill=(60, 55, 50))
    # 暗色长袍
    draw.rectangle([24, 60, 104, 112], fill=robe)
    draw.rectangle([32, 64, 96, 108], fill=robe_l)
    # 金色腰带
    draw.rectangle([28, 76, 100, 82], fill=gold_d)
    # 权杖（双叉）
    draw.rectangle([100, 16, 108, 112], fill=gold_d)
    draw.rectangle([96, 8, 112, 20], fill=gold)
    draw.rectangle([92, 4, 100, 16], fill=gold_d)
    draw.rectangle([108, 4, 116, 16], fill=gold_d)
    # 脚
    draw.rectangle([36, 108, 56, 122], fill=(40, 35, 30))
    draw.rectangle([72, 108, 92, 122], fill=(40, 35, 30))


def draw_aphrodite(draw, s):
    """阿佛洛狄忒 - 美与爱之神：玫瑰金+贝壳+花冠"""
    skin = (240, 215, 185)
    skin_l = (250, 228, 200)
    hair = (200, 160, 80)
    hair_l = (225, 190, 110)
    rose = (220, 120, 130)
    rose_l = (240, 160, 165)
    gold = (235, 205, 100)
    robe = (255, 235, 220)
    robe_d = (240, 215, 195)
    eye = (100, 150, 130)
    # 花冠
    draw.rectangle([32, 4, 96, 12], fill=gold)
    draw.rectangle([36, 0, 44, 8], fill=rose)
    draw.rectangle([56, 0, 64, 8], fill=rose_l)
    draw.rectangle([76, 0, 84, 8], fill=rose)
    # 长发
    draw.rectangle([24, 8, 104, 28], fill=hair)
    draw.rectangle([20, 20, 32, 56], fill=hair_l)
    draw.rectangle([96, 20, 108, 56], fill=hair_l)
    # 头/脸
    draw.rectangle([32, 16, 96, 60], fill=skin)
    draw.rectangle([36, 20, 92, 56], fill=skin_l)
    # 眼睛（温柔翠绿）
    draw.rectangle([40, 32, 54, 42], fill=(220, 240, 230))
    draw.rectangle([46, 34, 54, 42], fill=eye)
    draw.rectangle([74, 32, 88, 42], fill=(220, 240, 230))
    draw.rectangle([80, 34, 88, 42], fill=eye)
    # 唇
    draw.rectangle([52, 48, 76, 54], fill=rose)
    # 飘逸长袍
    draw.rectangle([24, 56, 104, 112], fill=robe)
    draw.rectangle([32, 60, 96, 108], fill=robe_d)
    # 金色腰带
    draw.rectangle([28, 72, 100, 78], fill=gold)
    # 玫瑰装饰
    draw.rectangle([40, 80, 48, 88], fill=rose)
    draw.rectangle([80, 84, 88, 92], fill=rose_l)
    # 贝壳（左手）
    draw.rectangle([4, 68, 24, 88], fill=(240, 230, 210))
    draw.rectangle([8, 72, 20, 84], fill=(250, 240, 220))
    # 脚
    draw.rectangle([36, 108, 56, 120], fill=(220, 200, 175))
    draw.rectangle([72, 108, 92, 120], fill=(220, 200, 175))


def draw_poseidon(draw, s):
    """波塞冬 - 海洋之神：三叉戟+蓝绿调"""
    skin = (210, 185, 155)
    skin_l = (225, 205, 175)
    hair = (60, 100, 120)
    hair_l = (80, 130, 150)
    beard = (70, 110, 130)
    gold = (230, 195, 70)
    gold_d = (180, 150, 40)
    robe = (70, 140, 160)
    robe_l = (90, 165, 185)
    trident_c = (200, 200, 210)
    eye = (60, 140, 160)
    # 头
    draw.rectangle([32, 12, 96, 60], fill=skin)
    draw.rectangle([36, 16, 92, 56], fill=skin_l)
    # 头发（海蓝色）
    draw.rectangle([28, 4, 100, 24], fill=hair)
    draw.rectangle([24, 12, 36, 36], fill=hair_l)
    draw.rectangle([92, 12, 104, 36], fill=hair_l)
    # 金冠
    draw.rectangle([36, 4, 92, 12], fill=gold)
    draw.rectangle([44, 0, 52, 8], fill=gold)
    draw.rectangle([60, 0, 68, 8], fill=gold)
    draw.rectangle([76, 0, 84, 8], fill=gold)
    # 眼睛（海蓝）
    draw.rectangle([40, 30, 54, 40], fill=(200, 230, 240))
    draw.rectangle([46, 32, 54, 40], fill=eye)
    draw.rectangle([74, 30, 88, 40], fill=(200, 230, 240))
    draw.rectangle([80, 32, 88, 40], fill=eye)
    # 胡子
    draw.rectangle([36, 46, 92, 68], fill=beard)
    draw.rectangle([40, 50, 88, 64], fill=hair_l)
    # 蓝绿长袍
    draw.rectangle([24, 64, 104, 112], fill=robe)
    draw.rectangle([32, 68, 96, 108], fill=robe_l)
    # 金色腰带
    draw.rectangle([28, 80, 100, 86], fill=gold)
    # 三叉戟
    draw.rectangle([104, 20, 110, 116], fill=gold_d)
    draw.rectangle([96, 8, 104, 24], fill=trident_c)
    draw.rectangle([104, 8, 112, 24], fill=trident_c)
    draw.rectangle([112, 8, 120, 24], fill=trident_c)
    draw.rectangle([96, 4, 102, 12], fill=trident_c)
    draw.rectangle([106, 4, 112, 12], fill=trident_c)
    draw.rectangle([114, 4, 120, 12], fill=trident_c)
    # 脚
    draw.rectangle([36, 108, 56, 122], fill=(60, 100, 110))
    draw.rectangle([72, 108, 92, 122], fill=(60, 100, 110))


def draw_dionysus(draw, s):
    """狄俄尼索斯 - 酒神：常春藤冠+酒杯+紫袍"""
    skin = (230, 200, 165)
    skin_l = (242, 218, 185)
    hair = (80, 55, 35)
    ivy = (80, 150, 60)
    ivy_l = (120, 180, 90)
    grape = (130, 60, 100)
    gold = (230, 200, 80)
    robe = (140, 80, 130)
    robe_l = (165, 100, 150)
    eye = (120, 80, 50)
    # 常春藤花冠
    draw.rectangle([28, 4, 100, 16], fill=ivy)
    draw.rectangle([32, 0, 40, 8], fill=ivy_l)
    draw.rectangle([52, 0, 60, 8], fill=grape)
    draw.rectangle([72, 0, 80, 8], fill=ivy_l)
    draw.rectangle([88, 0, 96, 8], fill=grape)
    # 头
    draw.rectangle([32, 12, 96, 60], fill=skin)
    draw.rectangle([36, 16, 92, 56], fill=skin_l)
    # 卷发
    draw.rectangle([28, 8, 104, 24], fill=hair)
    draw.rectangle([24, 16, 36, 36], fill=hair)
    draw.rectangle([92, 16, 104, 36], fill=hair)
    # 眼睛（慵懒迷醉）
    draw.rectangle([40, 32, 54, 42], fill=(240, 230, 210))
    draw.rectangle([46, 34, 54, 42], fill=eye)
    draw.rectangle([74, 32, 88, 42], fill=(240, 230, 210))
    draw.rectangle([80, 34, 88, 42], fill=eye)
    # 微笑
    draw.rectangle([50, 48, 78, 54], fill=(200, 160, 130))
    # 紫袍
    draw.rectangle([24, 56, 104, 112], fill=robe)
    draw.rectangle([32, 60, 96, 108], fill=robe_l)
    # 金色腰带
    draw.rectangle([28, 76, 100, 82], fill=gold)
    # 酒杯（右手高举）
    draw.rectangle([96, 32, 116, 44], fill=gold)
    draw.rectangle([100, 28, 112, 36], fill=gold)
    draw.rectangle([104, 44, 108, 56], fill=gold)
    # 酒（红色液体）
    draw.rectangle([100, 30, 112, 38], fill=grape)
    # 脚
    draw.rectangle([36, 108, 56, 122], fill=(100, 60, 85))
    draw.rectangle([72, 108, 92, 122], fill=(100, 60, 85))


def draw_artemis(draw, s):
    """阿尔忒弥斯 - 狩猎女神：银弓+月冠+猎装"""
    skin = (225, 200, 170)
    skin_l = (240, 218, 190)
    hair = (100, 75, 45)
    hair_l = (130, 100, 65)
    silver = (200, 205, 215)
    silver_l = (225, 230, 240)
    moon = (235, 235, 245)
    hunter = (90, 120, 80)
    hunter_l = (115, 145, 100)
    gold = (220, 190, 70)
    eye = (100, 140, 100)
    # 月冠
    draw.rectangle([40, 0, 88, 8], fill=moon)
    draw.rectangle([48, 0, 56, 4], fill=silver_l)
    draw.rectangle([72, 0, 80, 4], fill=silver_l)
    draw.rectangle([56, 0, 72, 6], fill=(245, 245, 255))
    # 头
    draw.rectangle([32, 8, 96, 56], fill=skin)
    draw.rectangle([36, 12, 92, 52], fill=skin_l)
    # 扎起的头发
    draw.rectangle([28, 4, 100, 18], fill=hair)
    draw.rectangle([24, 12, 36, 28], fill=hair_l)
    draw.rectangle([92, 12, 104, 28], fill=hair_l)
    # 马尾
    draw.rectangle([92, 20, 108, 40], fill=hair)
    draw.rectangle([100, 32, 112, 48], fill=hair_l)
    # 眼睛（森林绿）
    draw.rectangle([40, 24, 54, 34], fill=(220, 240, 220))
    draw.rectangle([46, 26, 54, 34], fill=eye)
    draw.rectangle([74, 24, 88, 34], fill=(220, 240, 220))
    draw.rectangle([80, 26, 88, 34], fill=eye)
    # 嘴
    draw.rectangle([52, 42, 76, 46], fill=(210, 175, 150))
    # 猎装（短裙）
    draw.rectangle([28, 52, 100, 92], fill=hunter)
    draw.rectangle([36, 56, 92, 88], fill=hunter_l)
    # 金色腰带
    draw.rectangle([32, 68, 96, 74], fill=gold)
    # 裙摆
    draw.rectangle([28, 88, 100, 100], fill=hunter)
    # 银弓（左手）
    draw.rectangle([4, 36, 28, 44], fill=silver)
    draw.rectangle([4, 28, 10, 56], fill=silver)
    draw.rectangle([20, 28, 26, 56], fill=silver)
    draw.rectangle([12, 32, 14, 52], fill=(180, 170, 150))
    # 猎靴
    draw.rectangle([32, 96, 56, 116], fill=(100, 80, 55))
    draw.rectangle([72, 96, 96, 116], fill=(100, 80, 55))
    draw.rectangle([28, 108, 56, 116], fill=(80, 60, 40))
    draw.rectangle([68, 108, 96, 116], fill=(80, 60, 40))


def draw_hestia(draw, s):
    """赫斯提亚 - 炉灶女神：温暖火焰+面纱+朴素长袍"""
    skin = (235, 210, 180)
    skin_l = (245, 225, 198)
    veil = (210, 195, 175)
    veil_l = (225, 215, 195)
    robe = (200, 140, 90)
    robe_l = (220, 165, 115)
    fire = (255, 180, 60)
    fire_l = (255, 220, 100)
    fire_d = (230, 120, 40)
    gold = (225, 195, 80)
    eye = (140, 100, 60)
    # 面纱
    draw.rectangle([24, 4, 104, 24], fill=veil)
    draw.rectangle([20, 16, 32, 52], fill=veil_l)
    draw.rectangle([96, 16, 108, 52], fill=veil_l)
    # 头/脸
    draw.rectangle([32, 12, 96, 56], fill=skin)
    draw.rectangle([36, 16, 92, 52], fill=skin_l)
    # 眼睛（温暖棕色）
    draw.rectangle([40, 28, 54, 38], fill=(245, 235, 215))
    draw.rectangle([46, 30, 54, 38], fill=eye)
    draw.rectangle([74, 28, 88, 38], fill=(245, 235, 215))
    draw.rectangle([80, 30, 88, 38], fill=eye)
    # 温和微笑
    draw.rectangle([52, 44, 76, 48], fill=(210, 175, 145))
    # 朴素长袍
    draw.rectangle([24, 52, 104, 112], fill=robe)
    draw.rectangle([32, 56, 96, 108], fill=robe_l)
    # 简朴腰带
    draw.rectangle([28, 72, 100, 78], fill=gold)
    # 双手捧火
    draw.rectangle([44, 88, 84, 100], fill=skin)
    # 圣火
    draw.rectangle([52, 76, 76, 92], fill=fire_d)
    draw.rectangle([56, 72, 72, 84], fill=fire)
    draw.rectangle([60, 68, 68, 76], fill=fire_l)
    # 脚
    draw.rectangle([36, 108, 56, 120], fill=(160, 115, 75))
    draw.rectangle([72, 108, 92, 120], fill=(160, 115, 75))


# ═══════════════════════════════════════════
#  🌟 神话传说
# ═══════════════════════════════════════════

def draw_demeter(draw, s):
    """得墨忒耳 - 丰收女神：麦穗冠+金色长袍"""
    skin = (230, 200, 165)
    skin_l = (242, 218, 185)
    hair = (170, 130, 60)
    hair_l = (200, 165, 85)
    gold = (240, 210, 70)
    gold_l = (255, 235, 120)
    gold_d = (200, 170, 50)
    wheat = (220, 190, 80)
    wheat_l = (240, 215, 110)
    robe = (200, 170, 80)
    robe_l = (220, 195, 110)
    eye = (100, 130, 60)
    # 麦穗冠
    draw.rectangle([32, 4, 96, 12], fill=gold)
    draw.rectangle([28, 0, 36, 12], fill=wheat)
    draw.rectangle([44, 0, 52, 8], fill=wheat_l)
    draw.rectangle([60, 0, 68, 4], fill=wheat)
    draw.rectangle([76, 0, 84, 8], fill=wheat_l)
    draw.rectangle([92, 0, 100, 12], fill=wheat)
    # 长发
    draw.rectangle([24, 8, 104, 24], fill=hair)
    draw.rectangle([20, 16, 32, 48], fill=hair_l)
    draw.rectangle([96, 16, 108, 48], fill=hair_l)
    # 头/脸
    draw.rectangle([32, 12, 96, 60], fill=skin)
    draw.rectangle([36, 16, 92, 56], fill=skin_l)
    # 眼睛（大地绿）
    draw.rectangle([40, 30, 54, 40], fill=(220, 240, 210))
    draw.rectangle([46, 32, 54, 40], fill=eye)
    draw.rectangle([74, 30, 88, 40], fill=(220, 240, 210))
    draw.rectangle([80, 32, 88, 40], fill=eye)
    # 温和表情
    draw.rectangle([52, 48, 76, 52], fill=(210, 175, 140))
    # 金色长袍
    draw.rectangle([24, 56, 104, 112], fill=robe)
    draw.rectangle([32, 60, 96, 108], fill=robe_l)
    # 金色腰带+宝石
    draw.rectangle([28, 74, 100, 80], fill=gold)
    draw.rectangle([60, 74, 68, 80], fill=(200, 80, 60))
    # 右手持麦穗
    draw.rectangle([100, 36, 108, 100], fill=wheat)
    draw.rectangle([96, 28, 112, 40], fill=wheat_l)
    draw.rectangle([104, 24, 116, 32], fill=wheat)
    draw.rectangle([92, 32, 100, 40], fill=wheat_l)
    # 脚
    draw.rectangle([36, 108, 56, 122], fill=gold_d)
    draw.rectangle([72, 108, 92, 122], fill=gold_d)


def draw_prometheus(draw, s):
    """普罗米修斯 - 盗火者：火炬+锁链残片+光芒"""
    skin = (215, 185, 150)
    skin_l = (230, 205, 172)
    hair = (60, 50, 40)
    gold = (255, 220, 80)
    gold_l = (255, 240, 140)
    gold_d = (200, 170, 50)
    fire = (255, 160, 40)
    fire_l = (255, 220, 80)
    fire_d = (230, 100, 30)
    chain = (150, 150, 160)
    chain_d = (110, 110, 120)
    robe = (80, 60, 45)
    robe_l = (110, 85, 65)
    eye = (200, 160, 50)
    # 光芒（头顶）
    draw.rectangle([52, 0, 76, 4], fill=gold_l)
    draw.rectangle([44, 2, 84, 6], fill=(255, 245, 180))
    # 头
    draw.rectangle([32, 8, 96, 56], fill=skin)
    draw.rectangle([36, 12, 92, 52], fill=skin_l)
    # 狂野头发
    draw.rectangle([28, 0, 100, 20], fill=hair)
    draw.rectangle([20, 8, 36, 28], fill=hair)
    draw.rectangle([92, 8, 108, 28], fill=hair)
    draw.rectangle([24, 24, 32, 36], fill=hair)
    draw.rectangle([96, 24, 104, 36], fill=hair)
    # 眼睛（燃烧的金色）
    draw.rectangle([40, 24, 54, 36], fill=(255, 240, 180))
    draw.rectangle([46, 26, 54, 36], fill=eye)
    draw.rectangle([74, 24, 88, 36], fill=(255, 240, 180))
    draw.rectangle([80, 26, 88, 36], fill=eye)
    # 嘴（坚毅紧闭）
    draw.rectangle([52, 44, 76, 48], fill=(180, 145, 110))
    # 身体（破旧长袍+赤裸右肩）
    draw.rectangle([24, 52, 100, 108], fill=robe)
    draw.rectangle([32, 56, 96, 104], fill=robe_l)
    # 右肩赤裸（肌肉）
    draw.rectangle([76, 52, 100, 72], fill=skin)
    draw.rectangle([80, 56, 96, 68], fill=skin_l)
    # 锁链残片（左臂）
    draw.rectangle([8, 52, 24, 60], fill=chain)
    draw.rectangle([16, 56, 24, 68], fill=chain_d)
    draw.rectangle([8, 64, 20, 72], fill=chain)
    draw.rectangle([12, 68, 28, 76], fill=chain_d)
    # 火炬（右手高举！）
    draw.rectangle([100, 32, 108, 76], fill=(100, 75, 50))
    # 火焰
    draw.rectangle([92, 16, 116, 36], fill=fire_d)
    draw.rectangle([96, 8, 112, 28], fill=fire)
    draw.rectangle([100, 4, 108, 16], fill=fire_l)
    draw.rectangle([104, 0, 112, 8], fill=gold_l)
    # 金光效果
    draw.rectangle([88, 12, 94, 16], fill=gold_l)
    draw.rectangle([116, 16, 122, 20], fill=gold_l)
    # 脚（赤脚+锁链）
    draw.rectangle([36, 104, 56, 120], fill=skin)
    draw.rectangle([72, 104, 92, 120], fill=skin)
    draw.rectangle([28, 112, 44, 118], fill=chain)
    draw.rectangle([80, 112, 96, 118], fill=chain_d)


# ═══════════════════════════════════════════
#  渲染器
# ═══════════════════════════════════════════

GOD_DRAW_FNS = {
    "赫尔墨斯":    draw_hermes,
    "雅典娜":      draw_athena,
    "赫菲斯托斯":  draw_hephaestus,
    "宙斯":        draw_zeus,
    "阿波罗":      draw_apollo,
    "阿瑞斯":      draw_ares,
    "哈迪斯":      draw_hades,
    "阿佛洛狄忒":  draw_aphrodite,
    "波塞冬":      draw_poseidon,
    "狄俄尼索斯":  draw_dionysus,
    "阿尔忒弥斯":  draw_artemis,
    "赫斯提亚":    draw_hestia,
    "得墨忒耳":    draw_demeter,
    "普罗米修斯":  draw_prometheus,
}


def render_pixel_god(name: str, pixel_size: int = 16) -> Image.Image:
    """渲染指定神明的像素头像，返回128×128 RGBA图片"""
    draw_fn = GOD_DRAW_FNS.get(name)
    if not draw_fn:
        img = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
        return img
    return _draw_god(128, draw_fn)


if __name__ == "__main__":
    # 生成预览
    from PIL import ImageFont
    cols = 4
    avatar_display = 192
    padding = 24
    label_h = 52
    cell_w = avatar_display + padding * 2
    cell_h = avatar_display + padding + label_h
    total_w = cols * cell_w + padding * 2

    gods_list = [
        ("赫尔墨斯", "信使之神"), ("雅典娜", "智慧战神"),
        ("赫菲斯托斯", "锻造之神"), ("宙斯", "众神之王"),
        ("阿波罗", "光明之神"), ("阿瑞斯", "战争之神"),
        ("哈迪斯", "冥界之王"), ("阿佛洛狄忒", "美与爱之神"),
        ("波塞冬", "海洋之神"), ("狄俄尼索斯", "酒神"),
        ("阿尔忒弥斯", "狩猎女神"), ("赫斯提亚", "炉灶女神"),
    ]
    legend_list = [("得墨忒耳", "丰收女神"), ("普罗米修斯", "盗火者")]

    regular_rows = 3
    total_h = (regular_rows + 1) * cell_h + padding * 2 + 140
    bg = (45, 35, 25)
    img = Image.new("RGB", (total_w, total_h), bg)
    draw = ImageDraw.Draw(img)

    try:
        title_font = ImageFont.truetype("/usr/share/fonts/google-noto-cjk/NotoSansCJK-Bold.ttc", 28)
        label_font = ImageFont.truetype("/usr/share/fonts/google-noto-cjk/NotoSansCJK-Bold.ttc", 18)
        sub_font = ImageFont.truetype("/usr/share/fonts/google-noto-cjk/NotoSansCJK-Regular.ttc", 14)
    except:
        title_font = ImageFont.load_default()
        label_font = title_font
        sub_font = title_font

    title = "🏛️ 奥林匹斯众神图鉴 · 14 Olympians"
    bb = draw.textbbox((0, 0), title, font=title_font)
    tw = bb[2] - bb[0]
    draw.text(((total_w - tw) // 2, 20), title, font=title_font, fill=(230, 200, 80))

    y_start = 60
    for i, (name, label) in enumerate(gods_list):
        col = i % cols
        row = i // cols
        cx = padding + col * cell_w + cell_w // 2
        cy = y_start + row * cell_h

        avatar = render_pixel_god(name)
        avatar = avatar.resize((avatar_display, avatar_display), Image.NEAREST)
        ax = cx - avatar_display // 2
        ay = cy + 10
        img.paste(avatar, (ax, ay), mask=avatar)

        ly = cy + 10 + avatar_display + 4
        bb = draw.textbbox((0, 0), name, font=label_font)
        nw = bb[2] - bb[0]
        draw.text((cx - nw // 2, ly), name, font=label_font, fill=(230, 200, 80))
        bb2 = draw.textbbox((0, 0), label, font=sub_font)
        sw = bb2[2] - bb2[0]
        draw.text((cx - sw // 2, ly + 22), label, font=sub_font, fill=(180, 160, 100))

    out = "/data/workspace/personality-card/pixel_gods_preview.png"
    img.save(out, "PNG")
    print(f"✅ 神明头像预览已保存: {out}")
