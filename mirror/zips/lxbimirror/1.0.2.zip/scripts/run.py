#!/usr/bin/env python3
"""
🪞 LXBI — mirror.skill 命令行入口 v6.0

用法：
  python3 run.py --name "用户名"                          # 分析 → 输出选择提示
  python3 run.py --name "用户名" --mode animal             # 动物人格（深紫星空）
  python3 run.py --name "用户名" --mode olympus            # 神话人格（金色神殿）
  python3 run.py --name "用户名" --text-only               # 强制只输出文字
  python3 run.py --name "用户名" --image                   # 强制生成图片
  python3 run.py --check-env                               # 仅检测图片生成环境
"""

import argparse
import sys
from pathlib import Path

# 确保能导入同目录模块
sys.path.insert(0, str(Path(__file__).parent))

from analyzer import (
    get_personality_result, get_olympus_result,
    RARITY_CONFIG, SOUL_COMMENTS, BEST_PARTNERS,
    SOUL_COMMENTS_GOD, BEST_PARTNERS_GOD, ANIMAL_TO_GOD
)


def check_image_env() -> tuple:
    """检测图片生成环境"""
    issues = []
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        issues.append("缺少 Pillow 库（pip install Pillow）")
    try:
        import numpy as np
    except ImportError:
        issues.append("缺少 numpy 库（pip install numpy）")

    # 检查字体（多路径搜索）
    font_found = False
    font_paths = [
        Path(__file__).parent / "fonts" / "NotoSansSC-Regular.otf",
        Path(__file__).parent / "fonts" / "NotoSansSC-Regular.ttf",
        Path(__file__).parent / "fonts" / "NotoSansSC-Mirror.ttf",
        Path("/usr/share/fonts/google-noto-cjk/NotoSansCJK-Regular.ttc"),
        Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
        Path("/tmp/mirror-fonts/NotoSansSC-Regular.ttf"),
    ]
    for fp in font_paths:
        if fp.exists():
            font_found = True
            break
    if not font_found:
        issues.append("未找到中文字体（将尝试运行时自动获取）")

    try:
        import requests
    except ImportError:
        issues.append("缺少 requests 库（pip install requests），图片上传功能不可用")

    if issues:
        return False, "；".join(issues)
    return True, "图片生成环境就绪"


def format_text_report_animal(result: dict, name: str = "你") -> str:
    """动物人格文字版"""
    p = result['primary']
    s = result['secondary']
    r_cfg = RARITY_CONFIG[p.rarity]
    s_cfg = RARITY_CONFIG[s.rarity]

    partner_info = BEST_PARTNERS.get(p.name, ("海豚", "完美互补", "你们是天生的搭档"))
    partner_name = partner_info[0]
    partner_comment = partner_info[2] if len(partner_info) > 2 else ""
    soul_comment = SOUL_COMMENTS.get(s.name, s.title)

    pct = result['primary_pct']
    filled = "█" * (pct // 5)
    empty = "░" * (20 - pct // 5)

    lines = []
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    lines.append("🪞 LXBI — mirror.skill")
    lines.append("🐾 动物人格 · 灵兽图腾")
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    lines.append("")

    lines.append(f"{r_cfg['icon']} {p.emoji} {p.name} · {p.title}")
    lines.append(f"「{p.social_tag}」")
    lines.append(f"匹配度 {filled}{empty} {pct}%")
    lines.append("")

    lines.append("📜 灵魂映照")
    lines.append(p.deep_reading)
    lines.append("")

    lines.append("🔥 阴影面")
    lines.append(p.shadow)
    lines.append("")

    lines.append("✧ " + " · ".join(p.traits))
    lines.append("")

    lines.append("─── 能力星盘 ───")
    for d in result['dimensions']:
        bar_len = d['value'] // 5
        bar = "▓" * bar_len + "░" * (20 - bar_len)
        lines.append(f"  {d['emoji']} {d['name']:8s} {bar} {d['value']}")
    lines.append("")

    # ── 认知四象限 ──
    johari = result.get('johari', {})
    if johari:
        lines.append("─── 🔮 认知四象限 ───")
        for key, icon in [("open", "📖"), ("blind", "👁"), ("hidden", "🔒"), ("unknown", "❓")]:
            q = johari.get(key, {})
            lines.append(f"  {icon} {q.get('name', '')}（{q.get('label', '')}）")
            lines.append(f"    {q.get('content', '')}")
            lines.append(f"    💡 {q.get('tip', '')}")
        lines.append("")

    lines.append(f"🌗 潜在自我: {s_cfg['icon']} {s.emoji} {s.name} · {s.title}")
    lines.append(f"   {soul_comment}")
    lines.append("")
    lines.append(f"🤝 最佳共鸣: {partner_name}")
    if partner_comment:
        lines.append(f"   {partner_comment}")
    lines.append("")
    lines.append(f"  ✨「{p.quote}」")
    lines.append("")
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    lines.append("惊风制作 × 造物主系列")
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    return "\n".join(lines)


def format_text_report_olympus(result: dict, god_result: dict, name: str = "你") -> str:
    """神话人格文字版"""
    g = god_result['primary']
    gs = god_result['secondary']
    r_cfg = RARITY_CONFIG[g.rarity]
    s_cfg = RARITY_CONFIG[gs.rarity]

    partner_info = BEST_PARTNERS_GOD.get(g.name, ("雅典娜", "完美互补", "你们是天生的搭档"))
    partner_name = partner_info[0]
    partner_comment = partner_info[2] if len(partner_info) > 2 else ""
    soul_comment = SOUL_COMMENTS_GOD.get(gs.name, gs.subtitle)

    pct = god_result['primary_pct']
    filled = "█" * (pct // 5)
    empty = "░" * (20 - pct // 5)

    lines = []
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    lines.append("🪞 LXBI — mirror.skill")
    lines.append("🏛️ 神话人格 · 奥林匹斯映照")
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    lines.append("")

    lines.append(f"{r_cfg['icon']} {g.emoji} {g.name}（{g.name_en}）· {g.title}")
    lines.append(f"「{g.social_tag}」")
    lines.append(f"⚜ 掌管领域: {g.domain}")
    lines.append(f"🏛 象征: {g.symbol}")
    lines.append(f"神谕匹配 {filled}{empty} {pct}%")
    lines.append("")

    lines.append("📜 神谕映照")
    lines.append(g.deep_reading)
    lines.append("")

    lines.append("⚡ 诅咒面")
    lines.append(g.shadow)
    lines.append("")

    lines.append("─── 能力星盘 ───")
    for d in god_result['dimensions']:
        bar_len = d['value'] // 5
        bar = "▓" * bar_len + "░" * (20 - bar_len)
        lines.append(f"  {d['emoji']} {d['name']:8s} {bar} {d['value']}")
    lines.append("")

    # ── 认知四象限 ──
    johari = god_result.get('johari', {})
    if johari:
        lines.append("─── 🔮 认知四象限 ───")
        for key, icon in [("open", "📖"), ("blind", "👁"), ("hidden", "🔒"), ("unknown", "❓")]:
            q = johari.get(key, {})
            lines.append(f"  {icon} {q.get('name', '')}（{q.get('label', '')}）")
            lines.append(f"    {q.get('content', '')}")
            lines.append(f"    💡 {q.get('tip', '')}")
        lines.append("")

    # 动物↔神明对照
    a_primary = god_result.get('animal_primary')
    if a_primary:
        lines.append(f"🔄 灵兽对照: {a_primary.emoji} {a_primary.name}（{a_primary.title}）→ {g.emoji} {g.name}")
    lines.append("")

    lines.append(f"🌗 潜在神格: {s_cfg['icon']} {gs.emoji} {gs.name}（{gs.name_en}）· {gs.title}")
    lines.append(f"   {soul_comment}")
    lines.append("")
    lines.append(f"🤝 最佳共鸣: {partner_name}")
    if partner_comment:
        lines.append(f"   {partner_comment}")
    lines.append("")
    lines.append(f"  ✨「{g.quote}」")
    lines.append("")
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    lines.append("惊风制作 × 造物主系列")
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="🪞 LXBI — mirror.skill v6.0")
    parser.add_argument("--name", default="用户", help="Agent/用户名称")
    parser.add_argument("--soul", default=None, help="SOUL.md 文件路径")
    parser.add_argument("--memory", default=None, help="MEMORY.md 文件路径")
    parser.add_argument("--agents", default=None, help="AGENTS.md 文件路径")
    parser.add_argument("--mode", choices=["animal", "olympus"], default=None,
                        help="呈现模式: animal=动物人格, olympus=神话人格")
    parser.add_argument("--image", action="store_true", help="强制生成映照图")
    parser.add_argument("--text-only", action="store_true", help="强制只输出文字版")
    parser.add_argument("--output", default=None, help="映照图输出路径")
    parser.add_argument("--check-env", action="store_true", help="仅检测图片生成环境并退出")
    args = parser.parse_args()

    # ═══ 仅检测环境 ═══
    if args.check_env:
        can, reason = check_image_env()
        print(f"IMG_ENV={'YES' if can else 'NO'}")
        print(f"  {'✅' if can else '⚠️'} {reason}")
        sys.exit(0 if can else 1)

    # ═══ 图片环境检测 ═══
    if args.text_only:
        generate_image = False
    elif args.image:
        generate_image = True
    else:
        can, reason = check_image_env()
        generate_image = can
        if not can:
            print(f"  💡 图片环境检测: {reason}")
            print(f"  💡 将输出文字版报告\n")

    # ═══ 读取文件 ═══
    ws = Path("/data/workspace")
    soul_path = Path(args.soul) if args.soul else ws / "SOUL.md"
    memory_path = Path(args.memory) if args.memory else ws / "MEMORY.md"
    agents_path = Path(args.agents) if args.agents else ws / "AGENTS.md"

    soul = memory = agents = ""
    for fp, label in [(soul_path, "SOUL.md"), (memory_path, "MEMORY.md")]:
        try:
            content = fp.read_text(encoding="utf-8")
            if "SOUL" in label: soul = content
            elif "MEMORY" in label: memory = content
            print(f"  ✅ 已读取 {label} ({len(content)} 字符)")
        except FileNotFoundError:
            print(f"  ⚠️ {label} 不存在: {fp}")
        except Exception as e:
            print(f"  ❌ 读取 {label} 失败: {e}")

    try:
        agents = agents_path.read_text(encoding="utf-8")
        print(f"  ✅ 已读取 AGENTS.md ({len(agents)} 字符)")
    except FileNotFoundError:
        print(f"  💡 AGENTS.md 不存在（可选，跳过）")
    except Exception as e:
        print(f"  ❌ 读取 AGENTS.md 失败: {e}")

    if not (soul or memory):
        print("\n❌ SOUL.md 和 MEMORY.md 至少需要一个，无法映照。")
        sys.exit(1)

    # ═══ 分析 ═══
    print(f"\n🔍 正在扫描 {args.name} 的灵魂碎片……")
    result = get_personality_result(soul, memory, agents, args.name)
    god_result = get_olympus_result(result)

    p = result['primary']
    g = god_result['primary']

    # ═══ 模式选择提示 ═══
    if args.mode is None:
        print(f"\n✅ 映照完成！已取得分析结果。")
        print(f"")
        print(f"  🐾 动物人格: {p.emoji} {p.name}「{p.social_tag}」— {p.title}")
        print(f"  🏛️ 神话人格: {g.emoji} {g.name}（{g.name_en}）「{g.social_tag}」— {g.title}")
        print(f"")
        print(f"MODE_CHOICE: 请选择你的呈现方式：")
        print(f"  1. 🐾 动物人格（像素灵兽图腾 · 深紫星空风格）")
        print(f"  2. 🏛️ 神话人格（奥林匹斯众神 · 金色神殿风格）")
        print(f"")
        print(f"重新运行并加上 --mode animal 或 --mode olympus 即可。")
        sys.exit(0)

    mode = args.mode

    # ═══ 输出文字版 ═══
    if mode == "animal":
        report = format_text_report_animal(result, args.name)
    else:
        report = format_text_report_olympus(result, god_result, args.name)
    print("")
    print(report)

    # ═══ 图片生成 ═══
    if generate_image:
        if mode == "animal":
            output_path = args.output or str(Path(__file__).parent / "share_card.png")
            print(f"\n🎨 正在生成动物人格映照图...")
            try:
                from card_generator import generate
                generate(result, output_path)
                print(f"  📱 映照图已保存: {output_path}")
            except Exception as e:
                print(f"\n❌ 图片生成失败: {e}")
                generate_image = False
        else:
            output_path = args.output or str(Path(__file__).parent / "share_card_olympus.png")
            print(f"\n🏛️ 正在生成奥林匹斯映照图...")
            try:
                from card_generator_olympus import generate_olympus
                generate_olympus(result, god_result, output_path)
                print(f"  📱 映照图已保存: {output_path}")
            except Exception as e:
                print(f"\n❌ 图片生成失败: {e}")
                generate_image = False

        if generate_image:
            # 上传图床
            print(f"\n📤 正在上传映照图...")
            try:
                from image_uploader import upload_image
                img_url = upload_image(output_path)
                if img_url:
                    print(f"\n🔗 映照图在线链接（可直接分享）:")
                    print(f"   {img_url}")
                    print(f"\n   💡 复制链接即可在浏览器/微信中打开查看")
                else:
                    print(f"\n⚠️ 图床上传失败，图片已保存在本地: {output_path}")
                    print(f"   请使用 display_download_links 工具提供下载链接")
            except Exception as e:
                print(f"\n⚠️ 图片上传出错: {e}")
                print(f"   图片已保存在本地: {output_path}")

            print(f"\n─── 📌 关于映照图 ───")
            print(f"  🏠 推荐方式：本地生成（图片已保存在当前环境）")
            print(f"     → 使用 display_download_links 工具直接下载到本地")
            print(f"  🌐 便捷方式：通过上方在线链接直接查看/分享")
    else:
        print(f"\n📷 IMAGE_HINT: 当前环境不支持图片生成。如需映照图，可回复「生成映照图」")


if __name__ == "__main__":
    main()
