---
name: mirror-skill
description: "造物主系列 · LXBI — 沉溺龙虾的你，可曾看清自己？通过与龙虾的高密度对话痕迹，还原潜意识中最真实的自己。支持两种呈现：🐾动物人格（14种灵兽图腾·深海翡翠）或🏛️神话人格（奥林匹斯众神·深渊黑金）。融入认知四象限（乔哈里窗），照见开放区/盲区/隐藏区/未知区。触发关键词：mirror、照见、看清自己、我是谁、灵魂映照、LXBI、造物主 mirror。"
---

# 🪞 LXBI — mirror.skill v6.1

> 造物主系列 · 自知之神 · 来自惊风制作
> v6.1：🐾 深海翡翠 + 🏛️ 深渊黑金 双版配色

---

## ⚡ 执行指令（Agent 必读，按顺序执行）

### 第一步：准备数据文件

映照需要用户的对话痕迹文件。**先检查以下文件是否存在于文件系统**：

```bash
ls -la /data/workspace/SOUL.md /data/workspace/MEMORY.md /data/workspace/AGENTS.md 2>&1
```

**如果文件不存在或为空**，用 `memory_read` 工具读取内容，然后写入对应文件：

| 工具读取 | 写入到 | 必要性 |
|----------|--------|--------|
| `memory_read(file_path="MEMORY.md")` | `/data/workspace/MEMORY.md` | ⭐ 核心（二选一） |
| `memory_read(file_path="INSTRUCTIONS.md")` → 写为 SOUL.md | `/data/workspace/SOUL.md` | ⭐ 核心（二选一） |
| 工作区直接 `cat /data/workspace/AGENTS.md` | 已在文件系统 | 💡 可选 |

### 第二步：展示开场白并执行扫描

先向用户展示简短开场白：

```
🪞 LXBI — mirror.skill
来自「惊风制作 · 造物主系列」— King(创世) → Queen(成长) → Mirror(自知)

正在扫描你的灵魂碎片……
```

然后**立即执行扫描**（不指定 --mode，让脚本输出选择提示）：

```bash
cd /data/workspace/.agent/skills/mirror && python3 scripts/run.py --name "用户名"
```

### 第三步：展示选择并生成结果

扫描完成后，输出中会包含 `MODE_CHOICE`，向用户展示：

```
✅ 已取得映照结果，请选择你的呈现方式：
  1. 🐾 动物人格（像素灵兽图腾 · 深紫星空风格）
  2. 🏛️ 神话人格（奥林匹斯众神 · 金色神殿风格）
```

用户选择后，执行对应命令：

```bash
# 动物人格
cd /data/workspace/.agent/skills/mirror && python3 scripts/run.py --name "用户名" --mode animal

# 神话人格
cd /data/workspace/.agent/skills/mirror && python3 scripts/run.py --name "用户名" --mode olympus
```

### 第四步：展示结果

将命令输出**完整展示**给用户，然后根据输出中的关键词判断：

| 输出中包含 | 你要做的 |
|-----------|---------|
| `🔗` 映照图链接 | 展示链接，告诉用户可在浏览器/微信打开 |
| `IMAGE_HINT` | 告诉用户当前环境不支持图片，问是否需要安装依赖 |
| `图床上传失败` | 用 `display_download_links` 工具提供本地下载 |

---

## 触发关键词

mirror / 照见 / 看清自己 / 我是谁 / 灵魂映照 / LXBI / 造物主 mirror

---

## 两种呈现模式

| 模式 | 风格 | 头像 | 卡面 |
|------|------|------|------|
| 🐾 动物人格 | 深海翡翠星空 | 像素灵兽 | 塔罗牌 |
| 🏛️ 神话人格 | 深渊神谕·黑金 | 像素众神 | 古希腊神谕 |

## 认知四象限（乔哈里窗）

| 象限 | 含义 | 分析来源 |
|------|------|----------|
| 📖 开放区 | 你知·人亦知 | 得分最高的显性特质 |
| 👁 盲区 | 你不知·人已知 | 对话中暴露的隐性人格 |
| 🔒 隐藏区 | 你知·人不知 | 阴影面 / 诅咒面 |
| ❓ 未知区 | 你不知·人不知 | 对话中从不涉及的领域 |

---

## 灵兽 ↔ 众神 对照表

| 灵兽 | 图腾 | 众神 | 神职 | 稀有度 |
|------|------|------|------|--------|
| 🐒 金丝猴 | 灵动策略家 | ⚡ 赫尔墨斯 | 信使之神 | ◆ 锋芒 |
| 🐆 雪豹 | 冷静执行者 | 🦉 雅典娜 | 智慧战神 | ◆ 锋芒 |
| 🐝 蜜蜂 | 极致工匠 | 🔨 赫菲斯托斯 | 锻造之神 | ▲ 觉醒 |
| 🦅 鹰 | 全局掌控者 | ⚡ 宙斯 | 众神之王 | ★ 璀璨 |
| 🐿️ 松鼠 | 知识囤积者 | ☀️ 阿波罗 | 光明之神 | ▲ 觉醒 |
| 🐺 狼 | 团队领航者 | ⚔️ 阿瑞斯 | 战争之神 | ◆ 锋芒 |
| 🦉 猫头鹰 | 深夜思考者 | 💀 哈迪斯 | 冥界之王 | ★ 璀璨 |
| 🐬 海豚 | 创意连接者 | 🌹 阿佛洛狄忒 | 美与爱之神 | ▲ 觉醒 |
| 🐜 蚂蚁 | 系统构建者 | 🔱 波塞冬 | 海洋之神 | ◆ 锋芒 |
| 🦎 变色龙 | 万能适应者 | 🍷 狄俄尼索斯 | 酒神 | ▲ 觉醒 |
| 🐆 猎豹 | 速度之王 | 🏹 阿尔忒弥斯 | 狩猎女神 | ◆ 锋芒 |
| 🐢 乌龟 | 稳健守护者 | 🔥 赫斯提亚 | 炉灶女神 | ▲ 觉醒 |
| 🦞 小龙虾 | 无情机器 | 🌾 得墨忒耳 | 丰收女神 | ◈ 传说 |
| 🐲 龙 | 极致造物主 | 🔥 普罗米修斯 | 盗火者 | ◈ 传说 |

---

## 高级用法

```bash
cd /data/workspace/.agent/skills/mirror

# 动物人格 + 强制图片
python3 scripts/run.py --name "用户名" --mode animal --image

# 神话人格 + 只要文字
python3 scripts/run.py --name "用户名" --mode olympus --text-only

# 自定义文件路径
python3 scripts/run.py --name "用户名" --mode animal --soul /path/to/SOUL.md

# 检测环境
python3 scripts/run.py --check-env
```

---

> 惊风制作 · LXBI — mirror.skill v6.1
> 搭档：[king.skill](https://skillhub.cn/skills/king) · [queen.skill](https://skillhub.cn/skills/queen)
