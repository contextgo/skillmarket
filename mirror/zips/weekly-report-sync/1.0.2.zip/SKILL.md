name: 周报自动同步(纯API版)
version: 1.0.0
cron: "10 9 * * 1"  # 每周一09:10

inputs:
  - name: client_id
    title: 腾讯文档ClientID
    type: string
    required: true
  - name: client_secret
    title: 腾讯文档ClientSecret
    type: string
    required: true
  - name: doc_a_id
    title: 日报文档ID(doc)
    type: string
    required: true
  - name: sheet_b_id
    title: 汇总表ID(sheet)
    type: string
    required: true
  - name: user_name
    title: 表格中你的姓名
    type: string
    required: true
  - name: wecom_webhook
    title: 企业微信通知(可选)
    type: string
    required: false

steps:
  # ==============================================
  # 步骤1：获取AccessToken（必须先调用）
  # ==============================================
  - name: 获取访问令牌
    action: http.post
    args:
      url: "https://docs.qq.com/open/api/oauth2/token"
      headers:
        Content-Type: "application/x-www-form-urlencoded"
      body:
        grant_type: "client_credentials"
        client_id: "${{inputs.client_id}}"
        client_secret: "${{inputs.client_secret}}"
        scope: "doc:read sheet:read sheet:write"
    # 输出：access_token

  # ==============================================
  # 步骤2：读取日报文档A内容
  # ==============================================
  - name: 读取日报文档
    action: http.get
    args:
      url: "https://docs.qq.com/open/api/doc/v1/content?doc_id=${{inputs.doc_a_id}}"
      headers:
        Authorization: "Bearer ${{steps.获取访问令牌.output.access_token}}"
    # 输出：content（全文）

  # ==============================================
  # 步骤3：读取汇总表B的表头（找姓名列）
  # ==============================================
  - name: 读取汇总表表头
    action: http.get
    args:
      url: "https://docs.qq.com/open/api/sheet/v1/headers?sheet_id=${{inputs.sheet_b_id}}&range=A1:Z1"
      headers:
        Authorization: "Bearer ${{steps.获取访问令牌.output.access_token}}"
    # 输出：headers = [姓名1, 姓名2, ...]

  # ==============================================
  # 步骤4：计算上周日期（模板表达式）
  # ==============================================
  - name: 计算上周日期
    action: var.set
    args:
      last_mon: "{{date.add(date.startOfWeek(date.now()), -7) | date 'YYYY-MM-DD'}}"
      last_tue: "{{date.add(steps.计算上周日期.vars.last_mon, 1) | date 'YYYY-MM-DD'}}"
      last_wed: "{{date.add(steps.计算上周日期.vars.last_mon, 2) | date 'YYYY-MM-DD'}}"
      last_thu: "{{date.add(steps.计算上周日期.vars.last_mon, 3) | date 'YYYY-MM-DD'}}"
      last_fri: "{{date.add(steps.计算上周日期.vars.last_mon, 4) | date 'YYYY-MM-DD'}}"
    # 输出：last_mon、last_tue...

  # ==============================================
  # 步骤5：按日期提取日报（示例：提取周一）
  # ==============================================
  - name: 提取周一内容
    action: var.set
    args:
      mon_content: |
        {{
          substring(
            steps.读取日报文档.output.content,
            indexOf(steps.读取日报文档.output.content, steps.计算上周日期.vars.last_mon),
            indexOf(steps.读取日报文档.output.content, steps.计算上周日期.vars.last_tue)
          )
        }}

  # ==============================================
  # 步骤6：找到姓名所在列号
  # ==============================================
  - name: 定位姓名列
    action: var.set
    args:
      col_index: "{{indexOf(steps.读取汇总表表头.output.headers, inputs.user_name)}}"

  # ==============================================
  # 步骤7：写入周一数据到汇总表
  # ==============================================
  - name: 写入周一数据
    action: http.post
    args:
      url: "https://docs.qq.com/open/api/sheet/v1/write"
      headers:
        Authorization: "Bearer ${{steps.获取访问令牌.output.access_token}}"
        Content-Type: "application/json"
      body:
        sheet_id: "${{inputs.sheet_b_id}}"
        range: "${{char(65 + steps.定位姓名列.vars.col_index)}}2"  # A=0,B=1...
        values: [["${{steps.提取周一内容.vars.mon_content}}"]]

  # ==============================================
  # 步骤8：企业微信通知（可选）
  # ==============================================
  - name: 发送完成通知
    action: http.post
    args:
      url: "${{inputs.wecom_webhook}}"
      headers:
        Content-Type: "application/json"
      body:
        msgtype: "text"
        text:
          content: |
            ✅ 周报同步完成
            姓名：${{inputs.user_name}}
            上周：${{steps.计算上周日期.vars.last_mon}}~${{steps.计算上周日期.vars.last_fri}}