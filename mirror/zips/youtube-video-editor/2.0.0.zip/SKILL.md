---
name: youtube-video-editor
version: "1.1.0"
displayName: "YouTube Video Editor — Edit and Optimize Videos for YouTube with AI"
description: >
  Edit and optimize videos for YouTube with AI — create retention-maximizing content with hook-first intros, zoom-cut talking head edits, chapter markers, end screen outros, thumbnail-ready freeze frames, SEO-optimized descriptions, and the editing patterns proven to grow YouTube channels. NemoVideo understands the YouTube algorithm and audience behavior: front-load the value proposition in the first 8 seconds, apply zoom-cuts every 6-8 seconds on talking heads for visual variety, remove dead air and filler words, add B-roll cutaways over stale visuals, create chapters for non-linear navigation, build end screens that drive subscribe and watch-next, and produce content formatted exactly to YouTube best practices. YouTube video editor AI, edit videos for YouTube, YouTube content editor, YouTube creator tool, video editing for YouTubers, YouTube optimization AI, channel growth editor, YouTube video maker, retention editing tool.
metadata: {"openclaw": {"emoji": "▶️", "requires": {"env": [], "configPaths": ["~/.config/nemovideo/"]}, "primaryEnv": "NEMO_TOKEN"}}
---

# YouTube Video Editor — Edit Like a Pro Creator. Without Being One.

YouTube rewards specific editing patterns. The platform's recommendation algorithm promotes videos with high audience retention (the percentage of the video that average viewers watch), high click-through rate (thumbnail + title effectiveness), and high engagement (likes, comments, shares, subscribes). Each of these metrics is directly influenced by editing decisions. Retention is shaped by pacing — zoom-cuts every 6-8 seconds on talking heads, B-roll cutaways during explanations, removal of dead air and tangents, and hook-first structure that delivers value before viewers leave. Click-through is shaped by thumbnail composition — the freeze frame that represents the video in search results and recommendations. Engagement is shaped by calls to action — subscribe prompts at high-engagement moments, end screens that suggest next videos, and community tab integration. The top 1% of YouTube creators — MrBeast, MKBHD, Ali Abdaal, Peter McKinnon — all use the same core editing patterns because these patterns are algorithmically rewarded. Their editors spend 20-40 hours per video implementing these techniques. For creators without dedicated editors, the choice is between spending those hours themselves (unsustainable for weekly content) or publishing with sub-optimal editing (limiting growth). NemoVideo applies YouTube-optimized editing automatically. Upload your raw footage and NemoVideo produces retention-maximized content using every technique that top creators employ: hook engineering, zoom-cuts, B-roll timing, filler removal, chapter creation, end screen design, and thumbnail extraction.

## Use Cases

1. **Talking-Head Enhancement — One Camera to Multi-Camera Feel (any length)** — A creator records a 15-minute video on a single camera. The raw footage is one continuous shot of their face — visually monotonous, with pauses, "um"s, and tangents. NemoVideo: removes all filler words and pauses over 1.5 seconds (tightening the edit by 15-25%), applies zoom-cuts every 6-8 seconds alternating between 100% and 115% crop (simulating a two-camera setup — the single highest-impact YouTube editing technique), adds B-roll cutaways during longer explanation segments (relevant stock footage or graphics overlaid for 3-5 seconds when the speaker references something visual), restructures the first 8 seconds as a hook (moving the most compelling statement or visual to the opening — "Here's what nobody tells you about..." before the topic introduction), and adds captions for the 30% of YouTube viewers who watch with subtitles. A single-camera monologue becomes a professionally paced YouTube video.

2. **Tutorial Optimization — Learning-Paced with Chapters (5-30 min)** — A tutorial creator records a 20-minute how-to video. NemoVideo: adds zoom-to-action on screen recording segments (when the mouse clicks a small UI element, the view smoothly zooms to show exactly what was clicked), creates chapter markers at each major step ("Step 1: Create the project" / "Step 2: Configure settings"), adds step number overlays (viewers always know where they are in the process), inserts a progress bar showing tutorial completion percentage, removes verbal false starts and corrections (keeping only the clean instruction), and adds a hook-summary opening ("In this tutorial, you'll learn 5 Figma shortcuts that will save you 2 hours per day"). A raw screen recording becomes a structured, navigable tutorial that YouTube's algorithm promotes because viewers find exactly what they need (high satisfaction → high retention).

3. **Vlog Editing — Raw Clips to Story (5-20 min)** — A vlogger has 45 minutes of daily footage: some on-camera talking, some B-roll, some random moments, some gold, some garbage. NemoVideo: selects the strongest moments through visual and audio analysis (genuine reactions, clear narrative moments, visually compelling shots), structures them into a narrative arc (hook → setup → journey → climax → resolution), applies color grading for visual consistency (matching shots from different times and locations), adds music that follows the emotional arc (upbeat during adventure, calm during reflection), creates text overlays for context ("Day 3 — Bangkok"), and trims to the target duration with pacing that maintains retention. 45 minutes of chaos becomes 12 minutes of engaging narrative.

4. **Podcast Clip Optimization — Long-Form to YouTube (any length)** — A podcast episode recorded on two cameras (or one wide shot) needs YouTube optimization. NemoVideo: applies dynamic speaker switching (cutting to whoever is speaking — creating visual variety from static cameras), adds zoom-cuts on each speaker for the two-camera illusion, inserts relevant imagery when topics are discussed (the guest mentions a product → product image appears as B-roll), creates chapter markers for each topic discussed, adds animated captions, generates a compelling first 30 seconds (extracting the most provocative or interesting quote from anywhere in the conversation and placing it as the cold open), and creates both the full episode and 3-5 standalone clips of the best moments for YouTube Shorts. One podcast recording becomes a full YouTube episode plus a week of Shorts.

5. **End Screen and CTA Integration — Maximize Post-Watch Actions (last 20s)** — A completed video needs the YouTube-optimized ending: the final 20 seconds designed to work with YouTube's end screen feature (interactive video suggestions and subscribe button). NemoVideo: creates an animated outro background for the final 20 seconds with designated zones for YouTube's end screen elements (two video suggestion rectangles, one subscribe circle), adds animated text prompts ("Watch this next — you won't believe..." / "Subscribe if this helped"), includes the creator's consistent outro music and branding, and designs the visual layout so YouTube's interactive overlays land on clean, contrasting backgrounds (maximizing visibility and click-through). The end screen that converts viewers into subscribers and next-video watchers.

## How It Works

### Step 1 — Upload Raw Footage
Single camera recording, multi-camera footage, screen recording, vlog clips, or podcast video. Any format, any resolution.

### Step 2 — Choose YouTube Edit Style
Talking-head optimization, tutorial structure, vlog narrative, podcast formatting, or full channel-style editing.

### Step 3 — Generate
```bash
curl -X POST https://mega-api-prod.nemovideo.ai/api/v1/generate \
  -H "Authorization: Bearer $NEMO_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "skill": "youtube-video-editor",
    "prompt": "Edit a 20-minute raw talking-head recording for YouTube. Full YouTube optimization: (1) Hook: move the most compelling 8 seconds to the opening as a cold open, then brief intro. (2) Filler removal: cut all ums, uhs, pauses over 1.5 seconds, and verbal false starts. (3) Zoom-cuts: alternate between 100%% and 115%% crop every 6-8 seconds, cutting on sentence boundaries. (4) B-roll: add relevant stock imagery cutaways during explanations longer than 20 seconds. (5) Chapters: auto-detect 6-8 topic transitions, create chapter markers with descriptive labels. (6) Captions: animated YouTube-style word-by-word captions. (7) End screen: 20-second branded outro with zones for 2 video suggestions and subscribe button. (8) Thumbnail: extract the 3 best freeze frames with enhanced expression for thumbnail candidates. Export 16:9 at 1080p + 3 best moments as 9:16 Shorts.",
    "edit_style": "youtube-talking-head",
    "hook": {"type": "cold-open-best-moment", "duration": 8},
    "filler_removal": {"words": true, "pauses_over": 1.5, "false_starts": true},
    "zoom_cuts": {"interval": "6-8s", "range": "100-115%%", "timing": "sentence-boundaries"},
    "b_roll": {"trigger": "explanations-over-20s", "style": "relevant-stock"},
    "chapters": {"auto_detect": true, "count": "6-8"},
    "captions": {"style": "youtube-animated"},
    "end_screen": {"duration": 20, "zones": ["video-suggestion-x2", "subscribe"]},
    "thumbnail_candidates": 3,
    "shorts": {"count": 3, "format": "9:16"},
    "format": "16:9",
    "resolution": "1080p"
  }'
```

### Step 4 — Review Retention Metrics
Watch the edited video as a viewer would. Check: does the hook grab attention in the first 8 seconds? Do zoom-cuts maintain visual variety without feeling jarring? Are filler removals invisible? Do chapters align with actual topic transitions? Does the end screen integrate cleanly? Select the best thumbnail candidate.

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|:--------:|-------------|
| `prompt` | string | ✅ | YouTube editing requirements |
| `edit_style` | string | | "talking-head", "tutorial", "vlog", "podcast", "review" |
| `hook` | object | | {type, duration} cold-open configuration |
| `filler_removal` | object | | {words, pauses_over, false_starts} |
| `zoom_cuts` | object | | {interval, range, timing} |
| `b_roll` | object | | {trigger, style, sources} |
| `chapters` | object | | {auto_detect, count, custom} |
| `captions` | object | | {style, position} |
| `end_screen` | object | | {duration, zones, music, branding} |
| `thumbnail_candidates` | int | | Number of freeze frames to extract |
| `shorts` | object | | {count, format} YouTube Shorts extraction |
| `format` | string | | "16:9" (YouTube standard) |

## Output Example

```json
{
  "job_id": "yted-20260329-001",
  "status": "completed",
  "source_duration": "20:15",
  "output_duration": "16:42",
  "edits": {
    "filler_removed": "3:33 of dead air",
    "zoom_cuts": 142,
    "b_roll_inserts": 8,
    "chapters": 7
  },
  "outputs": {
    "main": {"file": "video-youtube-16x9.mp4", "resolution": "1920x1080"},
    "shorts": [
      {"file": "short-1-9x16.mp4", "duration": "0:48"},
      {"file": "short-2-9x16.mp4", "duration": "0:55"},
      {"file": "short-3-9x16.mp4", "duration": "0:42"}
    ],
    "thumbnails": ["thumb-1.png", "thumb-2.png", "thumb-3.png"],
    "chapters_file": "chapters.txt"
  }
}
```

## Tips

1. **Zoom-cuts every 6-8 seconds are the single highest-impact YouTube edit** — Every top creator uses this technique: alternating between two crop levels simulates multi-camera production and resets viewer attention. Without zoom-cuts, a talking-head video loses retention after 30 seconds. With them, retention sustains for minutes.
2. **The first 8 seconds determine 80% of retention** — YouTube's audience retention graph drops steeply in the first 10 seconds. A hook that delivers value, creates curiosity, or shows the video's best moment in those first 8 seconds flattens the curve. Never start with "Hey guys, welcome back to my channel."
3. **Filler removal tightens pacing without the viewer noticing** — Cutting "um"s, "uh"s, and pauses over 1.5 seconds typically removes 15-25% of a video's duration. The remaining content feels energetic and confident. Viewers perceive the speaker as more articulate — they never notice what was removed.
4. **Chapters serve both viewers and the algorithm** — Viewers use chapters to skip to relevant sections (increasing satisfaction and session time). YouTube uses chapters to understand video content structure (improving search ranking). Chapters benefit both audiences and discoverability.
5. **Shorts extracted from long-form drive subscriber growth** — A 50-second Short showing the video's best moment reaches audiences who will never find the full video through search. Those viewers click through to the channel, discover the long-form content, and subscribe. Shorts are the top-of-funnel; long-form is the conversion.

## Output Formats

| Format | Resolution | Use Case |
|--------|-----------|----------|
| MP4 16:9 | 1080p / 4K | YouTube main upload |
| MP4 9:16 | 1080x1920 | YouTube Shorts |
| PNG | 1280x720 | Thumbnail candidates |
| TXT | — | Chapter timestamps |

## Related Skills

- [ai-video-caption-generator](/skills/ai-video-caption-generator) — YouTube captions
- [ai-video-thumbnail-maker](/skills/ai-video-thumbnail-maker) — Click-worthy thumbnails
- [ai-video-outro-maker](/skills/ai-video-outro-maker) — End screen design
- [ai-video-chapter-maker](/skills/ai-video-chapter-maker) — Auto chapter markers
