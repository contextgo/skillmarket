# 工作空间和文件管理技能包

## 概述
专门用于优化OpenClaw工作空间结构、文件组织和存储管理的完整解决方案。解决工作空间混乱、文件查找困难、存储效率低下等问题。

## 核心功能

### 1. 标准化目录结构
- 预定义的标准化目录结构
- 自动目录创建和组织
- 项目模板和规范
- 文件分类和标签系统

### 2. 文件管理优化
- 大型文件拆分和优化
- 智能文件分类和整理
- 存储效率分析和优化
- 自动化清理和维护

### 3. 性能优化
- 上下文使用率优化
- 存储空间管理
- 文件访问性能优化
- 自动化备份和恢复

## 快速开始

### 1. 分析当前工作空间
```bash
# 分析工作空间使用情况
python workspace_analyzer.py --mode analyze

# 识别问题区域
python workspace_analyzer.py --mode problems
```

### 2. 优化目录结构
```bash
# 创建标准化结构
python workspace_organizer.py --mode create

# 重新组织现有文件
python workspace_organizer.py --mode reorganize
```

### 3. 优化文件管理
```bash
# 拆分大型文件
python file_optimizer.py --mode split --threshold 50KB

# 创建文件摘要
python file_optimizer.py --mode summarize --format markdown
```

## 标准化目录结构

### 推荐结构
```
~/.openclaw/workspace/
├── projects/          # 项目目录
│   ├── [project-name]/ # 具体项目
│   └── templates/     # 项目模板
├── templates/         # 模板文件
│   ├── project/       # 项目模板
│   ├── skill/         # 技能模板
│   └── document/      # 文档模板
├── references/        # 参考文档
│   ├── guides/        # 使用指南
│   ├── api-docs/      # API文档
│   └── best-practices/# 最佳实践
├── scripts/           # 自动化脚本
│   ├── maintenance/   # 维护脚本
│   ├── automation/    # 自动化脚本
│   └── tools/         # 工具脚本
├── skills/            # 安装的技能
├── memory/            # 日常记忆日志
└── .learnings/        # 自我改进系统
```

## 使用场景

### 场景1：工作空间混乱
```bash
# 分析混乱程度
python workspace_analyzer.py --mode chaos

# 自动整理
python workspace_organizer.py --mode auto-clean
```

### 场景2：大型文件问题
```bash
# 识别大型文件
python file_analyzer.py --mode large-files --threshold 100KB

# 优化文件存储
python file_optimizer.py --mode optimize --strategy external
```

### 场景3：存储空间不足
```bash
# 分析存储使用
python storage_analyzer.py --mode usage

# 清理无用文件
python cleanup_manager.py --mode aggressive --days 30
```

### 场景4：文件查找困难
```bash
# 建立文件索引
python file_indexer.py --mode create

# 智能搜索
python file_searcher.py --query "搜索内容"
```

## 配置管理

### 工作空间配置
```json
{
  "workspace": {
    "structure": "standard",
    "projects": {
      "location": "projects",
      "template": "templates/project"
    },
    "templates": {
      "location": "templates",
      "types": ["project", "skill", "document"]
    },
    "references": {
      "location": "references",
      "categories": ["guides", "api-docs", "best-practices"]
    }
  }
}
```

### 文件管理策略
```json
{
  "fileManagement": {
    "maxFileSize": 50000,
    "splitStrategy": "auto",
    "summaryLength": 1000,
    "compression": {
      "enabled": true,
      "algorithm": "gzip",
      "threshold": 10000
    },
    "cleanup": {
      "tempFiles": 7,
      "cacheFiles": 30,
      "logFiles": 90
    }
  }
}
```

## 最佳实践

### 日常维护
1. **每日检查**: 快速空间使用检查
2. **每周整理**: 文件分类和整理
3. **每月优化**: 存储优化和清理
4. **季度审计**: 完整空间审计

### 项目管理
1. **使用模板**: 标准化项目结构
2. **文档规范**: 统一的文档格式
3. **版本控制**: 重要项目使用Git
4. **知识管理**: 系统化知识积累

### 性能优化
1. **监控趋势**: 定期监控空间使用趋势
2. **预防优化**: 在问题出现前优化
3. **自动化**: 设置自动化维护任务
4. **备份策略**: 定期备份重要数据

## 故障排除

### 常见问题

#### Q1: 工作空间混乱，难以管理
**解决方案**: 使用 `workspace_organizer.py` 重新组织，建立标准化结构

#### Q2: 大型文件导致性能问题
**解决方案**: 使用 `file_optimizer.py` 拆分文件，或使用外部存储

#### Q3: 找不到特定文件
**解决方案**: 建立分类和标签系统，使用搜索工具

#### Q4: 存储空间不足
**解决方案**: 运行清理工具，优化存储策略，考虑扩展存储

### 调试步骤
1. 运行空间分析识别问题
2. 检查文件分类和组织
3. 优化大型文件管理
4. 设置自动化维护
5. 监控优化效果

## 工具说明

### 核心工具
1. **workspace_analyzer.py** - 工作空间分析工具
2. **workspace_organizer.py** - 工作空间组织工具
3. **file_optimizer.py** - 文件优化工具
4. **storage_manager.py** - 存储管理工具

### 辅助工具
1. **template_generator.py** - 模板生成工具
2. **backup_system.py** - 备份系统
3. **cleanup_scheduler.py** - 清理调度器
4. **file_classifier.py** - 文件分类器

## 更新日志

### v1.0 (2026-04-15)
- 初始版本发布
- 基于实际工作空间优化经验
- 包含完整的文件管理工具链

### 未来计划
- 添加图形化界面
- 集成到OpenClaw控制面板
- 支持更多文件类型
- 添加机器学习优化

## 许可证
MIT License

## 支持
- 问题反馈：查看SKILL.md中的解决方案
- 功能请求：提交Issue或Pull Request
- 紧急问题：使用快速诊断工具

---

**提示**: 将此技能作为工作空间管理和文件优化的首选解决方案。定期维护可以显著提高工作效率和系统性能。