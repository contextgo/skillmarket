---
name: web-video-auto-learner
version: 2.0.0
description: 通用网络视频自动学习技能，支持自动登录、视频播放、弹窗处理、音频录制、语音转写、AI 智能总结
author: 龙虾
tags: [browser-automation, playwright, education, video-player, popup-handler, audio-recording, speech-to-text, ai-summary, reasoning-model]
homepage: ""
minVersion: "2026.1.0"
user-invocable: true
disable-model-invocation: false
permissions: [browser-control, file-read, file-write, network-access]
metadata: {"openclaw": {"requires": {"bins": ["playwright"], "env": ["PLAYWRIGHT_BROWSERS_PATH"]}}}
---

# 网络视频自动学习技能 (web-video-auto-learner)

> 通用网络视频自动学习技能 — 自动播放、弹窗处理、答题、录音、AI 转录与智能总结

## 功能说明

基于 **Playwright + Tkinter + AI** 的网站自动化技能，专为网络视频课程自动学习场景设计。支持自动登录、视频播放、弹窗答题、音频录制、语音转写、AI 智能总结的完整学习闭环。

### 核心功能

1. **自动登录** — 支持账号密码登录和 Storage State 免登录（加密存储，仅本机可解密）
2. **视频自动播放** — 按播放列表顺序自动播放视频，支持 xgplayer 等主流播放器懒加载
3. **弹窗自动处理** — 智能检测 MyLayer 弹窗、答题弹窗，自动关闭或 AI 辅助答题
4. **进度守护** — 每60秒自动保存播放进度，浏览器崩溃后自动恢复
5. **音频录制** — 基于 Web Audio API 的页面内录，自动录制课程音频并保存
6. **语音转写** — 支持讯飞 LFASR（云端高精度）和 Whisper（本地离线）双引擎
7. **AI 智能总结** — 多提供商（SiliconFlow / DeepSeek / OpenAI / Ollama）AI 模型生成课程纪要
8. **推理增强** — 支持 DeepSeek-R1 / deepseek-v4-pro 等推理模型的思维链输出
9. **三种模式** — 完整控制台（all）、简约模式（simple）、播放列表模式（list）

## 触发词

| 触发词 | 说明 |
|--------|------|
| 网络视频学习 / 自动学习 | 视频播放核心功能 |
| 自动播放 / 播放列表 | 视频播放相关 |
| 弹窗答题 / 自动答题 | 弹窗处理与答题 |
| 视频进度 / 进度守护 | 播放进度保存/恢复 |
| 音频录制 / 录音 | 音频录制功能 |
| 语音转写 / 转录 | 音频转文字 |
| AI 总结 / 课程纪要 | AI 智能总结 |
| 在线学习 / 继续教育 | 泛化触发 |

## 使用方法

### 基础用法

#### 1. 安装依赖

```bash
pip install -r requirements.txt
playwright install chromium
```

> **版本安全说明**：requirements.txt 使用波浪号约束（`~=X.Y.Z`），允许补丁版本更新但不接受不兼容的次版本升级。如需固定精确版本可改为 `==X.Y.Z`。

> 使用本地 Chrome/Edge 可跳过 Playwright 安装，在配置中指定 `browser_type`。

#### 2. 配置

```bash
# 复制配置模板并修改
cp config/config.yaml.example config/config.yaml
cp config/AImodel.yaml.example config/AImodel.yaml
```

编辑 `config/config.yaml`：
- 设置 `website.login_url` 为目标网站登录页
- 在 `navigation.play_list` 中添加视频 URL

编辑 `config/AImodel.yaml`：
- 填写 AI 提供商的 API 密钥（至少启用一个）

#### 3. 运行

```bash
# 简约模式（推荐新手）
python index.py simple

# 完整控制台模式
python index.py all

# 播放列表模式
python index.py list

# 无头模式（编程调用）
python index.py headless
```

### 高级用法

#### 编程式调用（无 GUI）

```python
from index import WebVideoAutoLearner

learner = WebVideoAutoLearner(mode="headless")

# 配置
learner.configure(
    browser_type="chrome",
    login_url="https://www.example.com/",
    navigation_steps=[
        {
            "name": "播放视频",
            "action": "play_list",
            "loop_infinite": True,
            "play_list": [
                {"url": "https://www.example.com/videoDisplay?coursewareId=xxx", "click_play": True}
            ]
        }
    ]
)

# 执行
result = learner.run()
print(f"状态: {result['status']}")
```

#### 快捷启动

```python
from index import quick_start

learner = quick_start(mode="simple", login_url="https://www.example.com/")
```

#### 完整学习闭环（播放 + 录音 + 转写 + 总结）

```python
from index import WebVideoAutoLearner

learner = WebVideoAutoLearner(mode="headless")

# 启用功能
learner.set_audio_recording_for_playlist(enable=True)
learner.enable_ai_summary(provider="siliconflow")

# 添加课程
learner.add_play_urls(["https://www.example.com/video?id=xxx"])

# 执行
result = learner.run()
```

#### 播放列表管理

```python
from index import WebVideoAutoLearner

learner = WebVideoAutoLearner(mode="headless")

# 批量添加
learner.add_play_urls([
    "https://www.example.com/videoDisplay?coursewareId=xxx",
    ("https://www.example.com/videoDisplay?coursewareId=aaa", "课程A"),
])

# 查看当前列表
urls = learner.get_play_urls()

# 替换全部 / 清空 / 重置进度
learner.set_play_urls(["https://..."])
learner.clear_play_urls()
learner.reset_play_progress()
```

#### AI 模型调用

```python
from index import WebVideoAutoLearner

learner = WebVideoAutoLearner()

# 查看 AI 配置状态
status = learner.get_ai_config_status()

# 直接调用 AI
result = learner.call_ai("请总结以下内容...")

# 使用推理增强模型（思维链）
result = learner.call_ai("请分析这个问题...", use_reasoning=True)
```

#### 音频录制与语音转写

```python
from index import WebVideoAutoLearner

learner = WebVideoAutoLearner()

# 启用音频录制
learner.set_audio_recording_for_playlist(enable=True)

# 转录已有音频文件（本地 Whisper）
result = learner.transcribe_video('recordings/audio.webm', use_api=False)

# 转录已有音频文件（云端讯飞 LFASR，更高精度）
result = learner.transcribe_video('recordings/audio.webm', use_api=True)
```

#### AI 智能总结

```python
from index import WebVideoAutoLearner

learner = WebVideoAutoLearner()
learner.enable_ai_summary(provider="deepseek")

# 一站式处理：转录 → 总结
summary = learner.summarize_video('recordings/audio.webm', video_title="课程标题")

# 一站式处理：录制 → 转录 → 总结
result = learner.process_and_summarize('video.mp4', video_title="课程标题")
```

#### 登录状态管理

```python
from index import WebVideoAutoLearner

learner = WebVideoAutoLearner()

# 保存当前浏览器登录状态（加密存储，仅本机可解密）
result = learner.save_login_state()

# 检查是否有已保存的登录状态
info = learner.check_login_state()

# 加载已保存的登录状态到浏览器
result = learner.load_login_state_into_browser()

# 删除登录状态
result = learner.delete_login_state()
```

## API 文档

查看 [docs/API.md](docs/API.md) 了解完整的公共 API 参考，包括 WebVideoAutoLearner 主控类、AIModelConfig/AIModelCaller、Encryption、PopupHandler、MediaProgressSaver、WebAudioRecorder 等所有模块的接口说明。

## 配置说明

### config/config.yaml

| 配置项 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| `settings.browser_type` | string | chrome | 浏览器类型 (chrome/msedge/360ee/360se) |
| `settings.window_max` | bool | true | 是否最大化窗口 |
| `settings.global_timeout` | int | 60000 | 全局超时（毫秒） |
| `settings.popup_scan_interval` | float | 0.5 | 弹窗扫描间隔（秒） |
| `settings.auto_answer` | bool | false | 自动答题开关 |
| `website.login_url` | string | - | 登录页面URL |
| `website.storage_state` | bool | true | 是否启用免登录 |
| `navigation` | list | [] | 导航步骤列表 |
| `popup_rules` | list | [] | 弹窗处理规则 |

### config/AImodel.yaml

| 配置项 | 说明 |
|--------|------|
| `global.default_provider` | 默认 AI 提供商 (siliconflow/openai/ollama/deepseek) |
| `models.<provider>.api_key` | API 密钥 |
| `models.<provider>.chat_model` | 聊天模型 |
| `models.<provider>.reasoning_model` | 推理增强模型（思维链） |
| `models.xunfei_lfasr` | 讯飞录音转写凭证 |

## AI 提供商

| 提供商 | 聊天模型 | 推理模型 | 说明 |
|--------|----------|----------|------|
| **SiliconFlow** | Qwen2.5-72B-Instruct | DeepSeek-R1 | 推荐国内使用，需 API Key |
| **DeepSeek** | deepseek-chat | deepseek-v4-pro | 国产模型，支持思维链 |
| **OpenAI** | gpt-4o-mini | - | 国际用户，需 API Key |
| **Ollama** | qwen2.5:7b | - | 本地运行，无需 API Key |

## 语音转写引擎

| 引擎 | 类型 | 精度 | 说明 |
|------|------|------|------|
| **讯飞 LFASR** | 云端 | 高 | 支持中英+方言，角色分离，需 API 凭证 |
| **Whisper** | 本地 | 中 | 离线运行，需 PyTorch + transformers |

## 注意事项

1. **首次使用**需先安装 Playwright：`playwright install chromium`
2. **配置初始化**：复制 `.example` 文件为实际配置并填写
3. **Storage State 加密**基于设备特征，仅限本机解密
4. **音频录制**时视频必须正在播放
5. **AI 功能**需配置有效的 API 密钥
6. Windows 平台可自动检测浏览器路径；其他平台需在配置中指定 `browser_path`
7. **讯飞转写**需在 `config/AImodel.yaml` 的 `xunfei_lfasr` 中配置 API 凭证
8. 播放完成后录音文件路径会自动回写到配置文件（`audio_file` / `audio_name` 字段）

## 浏览器扩展

`assets/media-progress-saver/` 是 Chrome 扩展：

- 每10秒自动保存媒体播放进度
- 页面加载时自动恢复进度
- 支持崩溃恢复（localStorage + chrome.storage 双重写入）

### 安装扩展

1. 打开 Chrome → `chrome://extensions/`
2. 开启「开发者模式」
3. 点击「加载已解压的扩展程序」
4. 选择 `assets/media-progress-saver/` 目录

## 技术架构

```
四层架构：
┌──────────────────────────────────────────────┐
│            GUI 层 (Tkinter)                   │  ← control_panel.py
├──────────────────────────────────────────────┤
│            核心逻辑层                         │
│  ┌──────────┬──────────┬──────────┐          │
│  │ 任务执行  │ 弹窗处理  │ 进度守护 │          │  ← task_runner / popup_handler / media_progress_saver
│  └──────────┴──────────┴──────────┘          │
│  ┌──────────┬──────────┬──────────┐          │
│  │ 音频录制  │ 语音转写  │ AI 总结  │          │  ← web_audio_recorder / audio_transcriber + xunfei_transcriber / ai_summarizer
│  └──────────┴──────────┴──────────┘          │
│  ┌──────────┬─────────────────────┐          │
│  │ 配置加载  │   加密存储 + AI配置 │          │  ← config_loader / encryption / ai_model
│  └──────────┴─────────────────────┘          │
├──────────────────────────────────────────────┤
│        Playwright 封装层                      │  ← browser.py
└──────────────────────────────────────────────┘
```

## 项目结构

```
skill/
├── SKILL.md                       # 技能文档（必需）
├── manifest.yaml                   # OpenClaw 技能清单
├── README.md                      # 项目说明
├── CLAUDE.md                      # AI 编码助手指南
├── CHANGELOG.md                   # 变更日志
├── LICENSE                        # 开源协议
├── index.py                       # 技能入口（API 封装）
├── requirements.txt               # Python 依赖
├── start_playlist.py              # 快捷启动脚本（simple模式）
├── run_playlist.py                # 快捷启动脚本（headless模式）
├── src/                           # 核心模块
│   ├── __init__.py
│   ├── browser.py                 # 浏览器管理（Playwright 封装）
│   ├── config_loader.py           # 配置文件加载器
│   ├── control_panel.py           # GUI 控制面板（Tkinter）
│   ├── encryption.py              # 登录信息加密/解密
│   ├── logger.py                  # 日志工具
│   ├── media_progress_saver.py    # 媒体进度守护
│   ├── popup_handler.py           # 弹窗检测与处理
│   ├── task_runner.py             # 任务执行器（含录音控制）
│   ├── ai_model.py                # AI 模型配置和调用（多提供商 + 推理增强）
│   ├── ai_summarizer.py           # AI 总结生成器
│   ├── audio_transcriber.py       # 音频转文字（Whisper 本地）
│   ├── xunfei_transcriber.py     # 讯飞 LFASR 转写（云端）
│   ├── video_processor.py         # 视频处理集成（录制→转写→总结）
│   ├── video_recorder.py          # 视频录制（ffmpeg）
│   ├── web_audio_recorder.py      # 网页音频录制（Web Audio API）
│   └── audio_inject.js            # 音频录制注入脚本
├── config/                        # 配置文件
│   ├── config.yaml.example        # 主配置示例
│   └── AImodel.yaml.example      # AI 模型配置示例
├── assets/                        # 资源文件
│   ├── media-progress-saver/      # Chrome 扩展（媒体进度守护）
│   ├── icon.png                  # 技能图标
│   └── screenshot.png            # 截图展示
├── examples/                      # 使用示例
│   ├── ai_model_example.py
│   ├── audio_recording_example.py
│   └── video_processing_example.py
└── tests/                         # 测试文件
    ├── __init__.py
    ├── test_browser.py
    ├── test_config_loader.py
    ├── test_task_runner.py
    ├── test_encryption.py
    ├── test_ai_model.py
    ├── test_popup_handler.py
    ├── test_media_progress_saver.py
    ├── test_web_audio_recorder.py
    └── test_integration.py
```

## 依赖

### 必需

- Python >= 3.9
- playwright >= 1.40.0
- pyyaml >= 6.0
- cryptography >= 41.0
- openai >= 1.0.0

### 可选（按功能）

- **音频录制**: 无额外依赖（使用 Web Audio API）
- **本地转写 (Whisper)**: torch, transformers, ffmpeg
- **云端转写 (讯飞)**: requests
- **视频录制**: ffmpeg（需添加到 PATH）

## 许可证

MIT License
