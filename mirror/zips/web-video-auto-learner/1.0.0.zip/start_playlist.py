# -*- coding: utf-8 -*-
import sys, os

SKILL = os.path.dirname(os.path.abspath(__file__))

# 按正确顺序加入 sys.path（workspace root 在前，skill/src 在后）
for p in [os.path.dirname(SKILL), os.path.join(SKILL, 'src'), SKILL]:
    if p not in sys.path:
        sys.path.insert(0, p)

os.chdir(SKILL)

from index import WebVideoAutoLearner

learner = WebVideoAutoLearner(mode='simple')
learner.start()
