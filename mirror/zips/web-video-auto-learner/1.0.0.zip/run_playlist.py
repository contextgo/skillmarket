# -*- coding: utf-8 -*-
import sys, os

SKILL = os.path.dirname(os.path.abspath(__file__))

for p in [os.path.dirname(SKILL), os.path.join(SKILL, 'src'), SKILL]:
    if p not in sys.path:
        sys.path.insert(0, p)

os.chdir(SKILL)

from index import WebVideoAutoLearner

print('初始化播放器...')
learner = WebVideoAutoLearner(mode='headless')

# 检查播放列表
urls = learner.get_play_urls()
print(f'播放列表共 {len(urls)} 个视频:')
for i, item in enumerate(urls):
    status = '已完成' if item.get('completed') else '待播放'
    print(f'  {i+1}. [{status}] {item["url"][:80]}')

print('\n启动自动播放...')
result = learner.run()

print(f'\n执行完成: status={result["status"]}')
if result.get("error"):
    print(f'错误: {result["error"]}')
