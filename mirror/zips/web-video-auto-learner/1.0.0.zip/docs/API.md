# WebVideoAutoLearner 公共 API 参考

> 版本：1.0.0 | 更新日期：2026-05-05

本文档列出 `web-video-auto-learner` 技能包的所有公共 API，供开发者和 OpenClaw 系统集成使用。

---

## 目录

- [WebVideoAutoLearner — 主控类](#webvideoautolearner--主控类)
  - [生命周期](#生命周期)
  - [配置](#配置)
  - [播放列表管理](#播放列表管理)
  - [AI 功能](#ai-功能)
  - [录制功能](#录制功能)
  - [登录状态管理](#登录状态管理)
  - [命令接口](#命令接口)
  - [事件系统](#事件系统)
  - [状态查询](#状态查询)
- [AIModelConfig — AI 配置管理](#aimodelconfig--ai-配置管理)
- [AIModelCaller — AI 调用器](#aimodelcaller--ai-调用器)
- [Encryption — 加密模块](#encryption--加密模块)
- [PopupHandler — 弹窗处理器](#popuphandler--弹窗处理器)
- [MediaProgressSaver — 进度守护](#mediaprogresssaver--进度守护)
- [WebAudioRecorder — 音频录制](#webaudiorecorder--音频录制)
- [便捷函数](#便捷函数)

---

## WebVideoAutoLearner — 主控类

> 模块：`index.py`

封装所有核心模块，提供简洁的编程式 API。

### 构造函数

```python
WebVideoAutoLearner(
    mode: str = "headless",       # 运行模式: "all" | "simple" | "list" | "headless"
    config_path: str = None,      # 自定义配置文件路径
    log_level: str = "INFO",      # 日志级别: DEBUG/INFO/WARNING/ERROR
)
```

### 生命周期

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `start()` | 启动自动化（GUI 模式，阻塞） | `None` |
| `run()` | 执行自动化（headless 模式，阻塞） | `Dict[str, Any]` |
| `pause()` | 暂停当前自动化 | `None` |
| `resume()` | 恢复已暂停的自动化 | `None` |
| `stop()` | 停止当前自动化 | `None` |
| `wait_for_completion(timeout=0, poll_interval=1.0)` | 阻塞等待完成 | `Dict` |

### 配置

```python
learner.configure(
    browser_type="chrome",         # 浏览器类型: chrome/msedge/360ee/360se
    login_url="https://...",       # 登录页面 URL
    navigation_steps=None,         # 导航步骤列表
    popup_rules=None,              # 弹窗处理规则
    headless=False,                # 是否无头浏览器
    window_max=True,               # 是否最大化窗口
    browser_path=None,             # 浏览器可执行文件路径
    storage_state=False,           # 是否启用 Storage State
    storage_state_file="storage_state.enc",  # 加密文件名
    **kwargs                       # 其他配置项
) -> WebVideoAutoLearner           # 返回 self，支持链式调用
```

### 播放列表管理

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `add_play_url(url, click_play=True, selector='', course_name='')` | 添加单个视频 URL | `self` |
| `add_play_urls(urls, click_play=True, selector='')` | 批量添加 URL | `self` |
| `set_play_urls(urls, click_play=True, selector='')` | 替换全部 URL | `self` |
| `remove_play_url(url)` | 移除指定 URL | `self` |
| `clear_play_urls()` | 清空播放列表 | `self` |
| `get_play_urls()` | 获取所有 URL | `list` |
| `reset_play_progress()` | 重置完成状态 | `self` |

### AI 功能

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `call_ai(prompt, system_prompt=None, provider=None, **kwargs)` | 调用 AI 模型 | `str \| None` |
| `call_ai_with_prompt_template(template_name, prompt, provider=None, **variables)` | 使用模板调用 AI | `str \| None` |
| `enable_ai_summary(api_key=None, provider="siliconflow")` | 启用 AI 总结 | `self` |
| `disable_ai_summary()` | 禁用 AI 总结 | `self` |
| `add_custom_system_prompt(name, content, description=None, variables=None)` | 添加自定义提示词 | `bool` |
| `list_system_prompts()` | 列出所有提示词 | `dict` |
| `get_ai_config_status()` | 获取 AI 配置状态 | `dict` |
| `set_ai_api_key(provider, api_key)` | 设置 API 密钥 | `bool` |
| `set_auto_answer(enabled)` | 设置自动答题开关 | `bool` |
| `is_auto_answer_enabled()` | 获取自动答题状态 | `bool` |
| `transcribe_video(video_path, use_api=False)` | 转录视频 | `dict \| None` |
| `summarize_video(video_path, video_title="", use_local=False)` | 生成 AI 总结 | `str \| None` |
| `process_and_summarize(video_path, video_title="", use_local=False)` | 一站式处理 | `dict \| None` |

### 录制功能

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `enable_recording(recording_type="video")` | 启用录制 | `self` |
| `disable_recording(recording_type="video")` | 禁用录制 | `self` |
| `set_audio_recording_for_playlist(enable=True)` | 设置播放列表录音 | `self` |
| `get_audio_recording_status()` | 获取录音状态 | `dict` |
| `get_recorded_videos()` | 获取已录制视频 | `list` |
| `get_summaries()` | 获取已生成总结 | `list` |

### 登录状态管理

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `save_login_state(filepath=None)` | 保存登录状态到加密文件 | `Dict` |
| `check_login_state(filepath=None)` | 检查登录状态文件 | `Dict` |
| `delete_login_state(filepath=None)` | 删除登录状态文件 | `Dict` |
| `load_login_state_into_browser(filepath=None)` | 加载到当前浏览器 | `Dict` |
| `get_login_state_info()` | 获取登录状态汇总 | `Dict` |

### 命令接口

```python
learner.execute_command(command, **params) -> Dict[str, Any]
```

**支持命令：**

| 类别 | 命令 | 参数 |
|------|------|------|
| 生命周期 | `init` / `launch` / `start` / `run` / `pause` / `resume` / `stop` / `shutdown` | — |
| 状态查询 | `get_status` / `get_progress` / `get_play_status` / `get_browser_status` | — |
| 播放列表 | `add_urls` / `set_urls` / `clear_urls` / `reset_progress` | `urls=[], click_play=True` |
| 音频录制 | `set_audio_recording` / `get_audio_recording_status` | `enable=True` |
| 登录 | `save_login` / `check_login` / `delete_login` | — |

**返回值格式：**
```python
{
    'success': bool,      # 是否成功
    'command': str,       # 命令名
    'data': dict,         # 结果数据
    'error': str | None   # 错误信息
}
```

**安全预检：**
```python
learner.is_safe_to(action) -> Dict[str, Any]
# 返回: {'safe': bool, 'warnings': list, 'checks': dict}
```

### 事件系统

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `register_event_handler(event, handler)` | 注册事件处理器 | `self` |
| `on_status_changed(handler)` | 状态变更事件 | `self` |
| `on_completed(handler)` | 自动化完成事件 | `self` |
| `on_error(handler)` | 错误事件 | `self` |
| `on_progress(handler)` | 进度更新事件 | `self` |

**事件类型：** `status_changed` / `progress_updated` / `error_occurred` / `completed` / `popup_detected` / `popup_handled`

### 状态查询

| 属性/方法 | 说明 | 返回值 |
|-----------|------|--------|
| `status` | 当前运行状态 | `str` |
| `result` | 执行结果 | `Dict` |
| `get_full_status()` | 完整系统状态快照 | `Dict` |
| `get_progress()` | 当前播放进度 | `Dict` |
| `get_play_status()` | 播放列表详情 | `Dict` |
| `get_browser_status()` | 浏览器状态 | `Dict` |

---

## AIModelConfig — AI 配置管理

> 模块：`src/ai_model.py`

```python
AIModelConfig(config_path: str = None)
```

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `get_global(key, default=None)` | 获取全局配置 | `Any` |
| `get_provider_config(provider=None)` | 获取提供商配置 | `Dict` |
| `get_enabled_providers()` | 获取已启用提供商 | `List[str]` |
| `get_system_prompt(prompt_name='default')` | 获取系统提示词 | `str` |
| `get_all_prompts()` | 获取所有提示词 | `Dict` |
| `add_system_prompt(name, content, description=None, variables=None)` | 添加提示词 | `bool` |
| `update_model_params(provider, params)` | 更新模型参数 | `bool` |
| `set_api_key(provider, api_key)` | 设置 API 密钥 | `bool` |
| `is_provider_ready(provider=None)` | 检查提供商就绪 | `bool` |
| `save()` | 保存配置到文件 | `bool` |

---

## AIModelCaller — AI 调用器

> 模块：`src/ai_model.py`

```python
AIModelCaller(config_path: str = None)
```

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `call(prompt, system_prompt=None, provider=None, use_reasoning=False, **kwargs)` | 调用 AI 模型 | `str` |
| `call_with_retry(prompt, system_prompt=None, provider=None, use_reasoning=False, **kwargs)` | 带重试调用 | `str` |
| `chat(messages, provider=None, **kwargs)` | 聊天接口 | `str` |
| `format_prompt(template, **variables)` | 格式化提示词模板 | `str` |
| `set_system_prompt(name='default')` | 设置系统提示词 | `self` |
| `get_system_prompt(name='default')` | 获取系统提示词 | `str \| None` |

---

## Encryption — 加密模块

> 模块：`src/encryption.py`

使用 Fernet（AES-128-CBC + HMAC-SHA256）对 Storage State 加密存储。密钥通过 PBKDF2HMAC 从设备特征派生。

| 函数 | 说明 | 返回值 |
|------|------|--------|
| `encrypt_storage_state(storage_state: dict)` | 加密字典 | `bytes` |
| `decrypt_storage_state(encrypted_data: bytes)` | 解密密文 | `dict` |
| `save_encrypted_storage_state(storage_state, filepath)` | 加密并保存 | `None` |
| `load_encrypted_storage_state(filepath)` | 加载并解密 | `dict` |

---

## PopupHandler — 弹窗处理器

> 模块：`src/popup_handler.py`

```python
PopupHandler(page, popup_rules, logger, browser=None, auto_answer_enabled=False)
```

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `on_popup_event(event_type, callback_fn)` | 注册弹窗事件回调 | `None` |
| `set_step_popup_rules(step_rules)` | 设置步骤级规则 | `None` |
| `clear_step_popup_rules()` | 清除步骤级规则 | `None` |
| `detect_popup_type(text_or_element)` | 自动判断弹窗类型 | `str` |
| `start_listening(check_interval=2.0)` | 启动弹窗监听 | `None` |
| `stop_listening()` | 停止弹窗监听 | `None` |
| `register_dialog_handler()` | 注册原生 dialog 处理 | `None` |
| `set_pw_caller(caller_fn)` | 设置线程安全调用器 | `None` |

**事件类型：** `detected` / `handled` / `error` / `cleared`

---

## MediaProgressSaver — 进度守护

> 模块：`src/media_progress_saver.py`

```python
MediaProgressSaver(browser, logger, pw_caller=None)
```

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `start()` | 启动定时保存（60秒周期） | `None` |
| `stop()` | 停止定时保存 | `None` |
| `save_now()` | 立即保存一次 | `None` |
| `restore_progress()` | 恢复播放进度 | `None` |
| `clear_progress()` | 清除进度数据 | `None` |
| `update_cache_from_monitor(el_info, selector='', pw_sel='')` | 更新缓存 | `None` |
| `set_pw_caller(caller_fn)` | 设置线程安全调用器 | `None` |

---

## WebAudioRecorder — 音频录制

> 模块：`src/web_audio_recorder.py`

```python
WebAudioRecorder(config: Dict = None)
```

| 方法 | 说明 | 返回值 |
|------|------|--------|
| `inject(page)` | 注入录制代码到页面 | `bool` |
| `start(elements=None, timeslice=1000, output_name=None)` | 开始录制 | `Dict` |
| `pause()` | 暂停录制 | `bool` |
| `resume()` | 恢复录制 | `bool` |
| `stop(save=True, output_path=None)` | 停止录制 | `Dict` |
| `get_status()` | 获取录制状态 | `Dict` |
| `is_recording()` | 是否录制中 | `bool` |
| `is_paused()` | 是否暂停 | `bool` |
| `cleanup(save=False, output_path=None)` | 清理资源 | `None` |
| `set_on_status_change(callback)` | 设置状态回调 | `None` |

**格式常量：** `FORMAT_WEBM_OPUS` / `FORMAT_WEBM_VORBIS` / `FORMAT_WAV` / `FORMAT_MP3` / `FORMAT_M4A` / `FORMAT_WEBM`

---

## 便捷函数

| 函数 | 说明 | 返回值 |
|------|------|--------|
| `quick_start(mode="simple", login_url="...")` | 快速启动 | `WebVideoAutoLearner` |
| `create_config(config_path=None)` | 创建 AI 配置 | `AIModelConfig` |
| `call_ai(prompt, system_prompt=None, provider=None, **kwargs)` | 便捷 AI 调用 | `str` |
