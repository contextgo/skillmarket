"""测试用例：媒体进度守护模块测试

测试进度保存/恢复逻辑、文件读写（原子写入+备份）、
URL 匹配、数据过期检查、定时触发等。
使用 mock 替代真实浏览器，避免依赖 Playwright。
"""
import unittest
import sys
import os
import json
import time
import tempfile
import shutil
from unittest.mock import MagicMock, patch

# 添加项目路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from src.media_progress_saver import MediaProgressSaver, isFinite_check


class TestIsFiniteCheck(unittest.TestCase):
    """isFinite_check 辅助函数测试"""

    def test_01_finite_number(self):
        """测试有限数字"""
        self.assertTrue(isFinite_check(42))
        self.assertTrue(isFinite_check(0))
        self.assertTrue(isFinite_check(-1.5))
        self.assertTrue(isFinite_check(3.14))

    def test_02_infinite(self):
        """测试无穷大"""
        self.assertFalse(isFinite_check(float('inf')))
        self.assertFalse(isFinite_check(float('-inf')))

    def test_03_nan(self):
        """测试 NaN"""
        self.assertFalse(isFinite_check(float('nan')))

    def test_04_none(self):
        """测试 None"""
        self.assertFalse(isFinite_check(None))

    def test_05_string(self):
        """测试字符串"""
        self.assertFalse(isFinite_check("100"))


class TestMediaProgressSaver(unittest.TestCase):
    """媒体进度守护器测试类"""

    @classmethod
    def setUpClass(cls):
        """测试类初始化"""
        cls.temp_dir = tempfile.mkdtemp(prefix="test_progress_")

    @classmethod
    def tearDownClass(cls):
        """测试类清理"""
        if os.path.isdir(cls.temp_dir):
            shutil.rmtree(cls.temp_dir)

    def setUp(self):
        """每个测试用例前创建独立的 MediaProgressSaver"""
        self.logger = MagicMock()
        self.browser = MagicMock()
        self.browser.page = None
        self.browser.is_alive.return_value = False

        # 将进度目录指向临时目录
        self.saver = MediaProgressSaver(self.browser, self.logger)
        self.saver._progress_dir = self.temp_dir
        self.saver._progress_file = os.path.join(self.temp_dir, 'media_progress.json')
        self.saver._backup_file = os.path.join(self.temp_dir, 'media_progress.json.bak')

    def tearDown(self):
        """每个测试用例后清理"""
        self.saver.stop()
        for f in [self.saver._progress_file, self.saver._backup_file]:
            if os.path.isfile(f):
                try:
                    os.remove(f)
                except Exception:
                    pass

    # ================================================================
    #  初始化测试
    # ================================================================

    def test_01_init(self):
        """测试初始化"""
        self.assertIsNotNone(self.saver)
        self.assertFalse(self.saver._running)
        self.assertIsNone(self.saver._last_collected_data)

    # ================================================================
    #  保存到文件测试
    # ================================================================

    def test_02_save_to_file(self):
        """测试保存进度到文件"""
        data = {
            'id': 'media_abc123',
            'tag': 'video',
            'currentTime': 120.5,
            'duration': 3600.0,
            'percent': 3.3,
            'paused': False,
            'ended': False,
            'pageUrl': 'https://example.com/video',
        }
        self.saver._save_to_file(data)

        self.assertTrue(os.path.isfile(self.saver._progress_file))
        # 备份也应存在
        self.assertTrue(os.path.isfile(self.saver._backup_file))

    def test_03_load_from_file(self):
        """测试从文件加载进度"""
        data = {
            'id': 'media_test',
            'tag': 'video',
            'currentTime': 60.0,
            'duration': 300.0,
            'percent': 20.0,
            'paused': True,
            'ended': False,
            'pageUrl': 'https://example.com/video1',
        }
        self.saver._save_to_file(data)
        loaded = self.saver._load_from_file()

        self.assertIsNotNone(loaded)
        self.assertEqual(loaded['currentTime'], 60.0)
        self.assertEqual(loaded['pageUrl'], 'https://example.com/video1')

    def test_04_load_nonexistent_file(self):
        """测试加载不存在的文件返回 None"""
        loaded = self.saver._load_from_file()
        self.assertIsNone(loaded)

    def test_05_load_corrupt_file_fallback_to_backup(self):
        """测试主文件损坏时回退到备份文件"""
        data = {
            'id': 'media_backup',
            'tag': 'video',
            'currentTime': 30.0,
            'duration': 200.0,
            'pageUrl': 'https://example.com/backup',
        }
        # 先保存正常数据（会同时创建备份）
        self.saver._save_to_file(data)

        # 损坏主文件
        with open(self.saver._progress_file, 'w', encoding='utf-8') as f:
            f.write("{invalid json::")

        # 应回退到备份
        loaded = self.saver._load_from_file()
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded['currentTime'], 30.0)

    # ================================================================
    #  URL 匹配测试
    # ================================================================

    def test_06_url_match_same(self):
        """测试相同 URL 匹配"""
        result = self.saver._url_match(
            'https://example.com/video/1',
            'https://example.com/video/1'
        )
        self.assertTrue(result)

    def test_07_url_match_ignore_query(self):
        """测试忽略查询参数的 URL 匹配"""
        result = self.saver._url_match(
            'https://example.com/video/1?token=abc',
            'https://example.com/video/1?session=xyz'
        )
        self.assertTrue(result)

    def test_08_url_match_ignore_hash(self):
        """测试忽略 hash 的 URL 匹配"""
        result = self.saver._url_match(
            'https://example.com/video#section1',
            'https://example.com/video#section2'
        )
        self.assertTrue(result)

    def test_09_url_match_different_path(self):
        """测试不同路径的 URL 不匹配"""
        result = self.saver._url_match(
            'https://example.com/video/1',
            'https://example.com/video/2'
        )
        self.assertFalse(result)

    def test_10_url_match_empty(self):
        """测试空 URL 不匹配"""
        result = self.saver._url_match('', 'https://example.com')
        self.assertFalse(result)

    def test_11_url_match_none_values(self):
        """测试 None URL 不匹配"""
        result = self.saver._url_match(None, 'https://example.com')
        self.assertFalse(result)

    # ================================================================
    #  启停控制测试
    # ================================================================

    def test_12_start_stop(self):
        """测试启动和停止"""
        self.saver.start()
        self.assertTrue(self.saver._running)

        self.saver.stop()
        self.assertFalse(self.saver._running)

    def test_13_start_idempotent(self):
        """测试重复启动是幂等的"""
        self.saver.start()
        self.saver.start()  # 不应抛出异常
        self.assertTrue(self.saver._running)
        self.saver.stop()

    # ================================================================
    #  缓存更新测试
    # ================================================================

    def test_14_update_cache_from_monitor(self):
        """测试从监听循环更新缓存"""
        el_info = {
            'currentTime': 100.0,
            'duration': 600.0,
            'paused': False,
            'ended': False,
            'volume': 0.8,
            'muted': False,
            'playbackRate': 1.0,
        }
        self.saver.update_cache_from_monitor(el_info, selector='video', pw_sel='video')

        # 缓存应被更新
        # 注意: 由于 _pw 调用可能失败，pageUrl 等可能为空
        self.assertIsNotNone(self.saver._last_collected_data)

    def test_15_update_cache_ignores_small_progress(self):
        """测试小进度不更新缓存"""
        el_info = {
            'currentTime': 0.5,  # 小于 MIN_PROGRESS_THRESHOLD
            'duration': 600.0,
            'paused': False,
            'ended': False,
        }
        self.saver.update_cache_from_monitor(el_info)
        self.assertIsNone(self.saver._last_collected_data)

    def test_16_update_cache_ignores_ended(self):
        """测试已结束的媒体不更新缓存"""
        el_info = {
            'currentTime': 100.0,
            'duration': 600.0,
            'paused': False,
            'ended': True,
        }
        self.saver.update_cache_from_monitor(el_info)
        self.assertIsNone(self.saver._last_collected_data)

    def test_17_update_cache_ignores_none(self):
        """测试空输入不更新缓存"""
        self.saver.update_cache_from_monitor(None)
        self.assertIsNone(self.saver._last_collected_data)

    # ================================================================
    #  清除进度测试
    # ================================================================

    def test_18_clear_progress(self):
        """测试清除进度数据"""
        data = {
            'id': 'media_test',
            'tag': 'video',
            'currentTime': 60.0,
            'duration': 300.0,
            'pageUrl': 'https://example.com',
        }
        self.saver._save_to_file(data)
        self.assertTrue(os.path.isfile(self.saver._progress_file))

        self.saver.clear_progress()
        self.assertFalse(os.path.isfile(self.saver._progress_file))
        self.assertIsNone(self.saver._last_collected_data)

    # ================================================================
    #  紧急保存测试
    # ================================================================

    def test_19_save_now_with_cache(self):
        """测试使用缓存紧急保存"""
        # 设置缓存数据
        self.saver._last_collected_data = {
            'id': 'media_emergency',
            'tag': 'video',
            'currentTime': 150.0,
            'duration': 500.0,
            'percent': 30.0,
            'paused': False,
            'ended': False,
            'pageUrl': 'https://example.com/video',
        }
        self.saver._last_collected_time = time.time() * 1000

        # 浏览器已关闭
        self.browser.is_alive.return_value = False

        self.saver.save_now()

        # 底使用缓存数据保存
        if os.path.isfile(self.saver._progress_file):
            loaded = self.saver._load_from_file()
            self.assertIsNotNone(loaded)
            self.assertEqual(loaded['currentTime'], 150.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
