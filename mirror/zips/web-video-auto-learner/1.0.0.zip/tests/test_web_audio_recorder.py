"""测试用例：网页音频录制器测试

测试 WebAudioRecorder 的状态转换、配置解析、格式扩展名映射等。
使用 mock 替代真实浏览器页面，不依赖 Playwright 环境。
"""
import unittest
import sys
import os
from unittest.mock import MagicMock, patch

# 添加项目路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from src.web_audio_recorder import WebAudioRecorder, PageAudioCapture


class TestWebAudioRecorder(unittest.TestCase):
    """网页音频录制器测试类"""

    def setUp(self):
        """每个测试用例前的设置"""
        self.temp_dir = os.path.join(
            os.path.dirname(__file__), "temp_recordings"
        )
        self.recorder = WebAudioRecorder(config={
            'output_dir': self.temp_dir,
            'format': 'webm_opus',
        })

    def tearDown(self):
        """每个测试用例后的清理"""
        self.recorder.cleanup()

    # ================================================================
    #  初始化测试
    # ================================================================

    def test_01_init(self):
        """测试初始化"""
        self.assertIsNotNone(self.recorder)
        self.assertFalse(self.recorder._is_recording)
        self.assertFalse(self.recorder._is_paused)

    def test_02_default_config(self):
        """测试默认配置"""
        recorder = WebAudioRecorder()
        self.assertEqual(recorder.config['format'], 'webm_opus')
        self.assertEqual(recorder.config['sample_rate'], 48000)
        self.assertEqual(recorder.config['channels'], 1)

    def test_03_custom_config(self):
        """测试自定义配置"""
        recorder = WebAudioRecorder(config={
            'format': 'mp3',
            'sample_rate': 44100,
            'channels': 2,
        })
        self.assertEqual(recorder.config['format'], 'mp3')
        self.assertEqual(recorder.config['sample_rate'], 44100)
        self.assertEqual(recorder.config['channels'], 2)

    # ================================================================
    #  格式扩展名映射测试
    # ================================================================

    def test_04_format_extension_webm_opus(self):
        """测试 WebM/Opus 格式扩展名"""
        ext = self.recorder._get_format_extension('webm_opus')
        self.assertEqual(ext, 'webm')

    def test_05_format_extension_wav(self):
        """测试 WAV 格式扩展名"""
        ext = self.recorder._get_format_extension('wav')
        self.assertEqual(ext, 'wav')

    def test_06_format_extension_mp3(self):
        """测试 MP3 格式扩展名"""
        ext = self.recorder._get_format_extension('mp3')
        self.assertEqual(ext, 'mp3')

    def test_07_format_extension_m4a(self):
        """测试 M4A 格式扩展名"""
        ext = self.recorder._get_format_extension('m4a')
        self.assertEqual(ext, 'm4a')

    def test_08_format_extension_unknown(self):
        """测试未知格式默认扩展名为 webm"""
        ext = self.recorder._get_format_extension('unknown_format')
        self.assertEqual(ext, 'webm')

    # ================================================================
    #  状态查询测试
    # ================================================================

    def test_09_is_recording_false(self):
        """测试未录制时 is_recording 返回 False"""
        self.assertFalse(self.recorder.is_recording())

    def test_10_is_paused_false(self):
        """测试未暂停时 is_paused 返回 False"""
        self.assertFalse(self.recorder.is_paused())

    def test_11_get_status_not_injected(self):
        """测试未注入页面时的状态"""
        status = self.recorder.get_status()
        self.assertFalse(status.get('isRecording', True))
        self.assertFalse(status.get('injected', True))

    # ================================================================
    #  录制控制测试（无页面环境）
    # ================================================================

    def test_12_start_without_page(self):
        """测试未注入页面时启动录制失败"""
        result = self.recorder.start()
        self.assertFalse(result.get('success', True))
        self.assertIn('error', result)

    def test_13_stop_without_recording(self):
        """测试未录制时停止返回错误"""
        result = self.recorder.stop()
        self.assertFalse(result.get('success', True))

    def test_14_pause_without_recording(self):
        """测试未录制时暂停返回 False"""
        result = self.recorder.pause()
        self.assertFalse(result)

    def test_15_resume_without_recording(self):
        """测试未录制时恢复返回 False"""
        result = self.recorder.resume()
        self.assertFalse(result)

    # ================================================================
    #  状态回调测试
    # ================================================================

    def test_16_set_on_status_change(self):
        """测试设置状态变化回调"""
        callback = MagicMock()
        self.recorder.set_on_status_change(callback)
        self.assertIs(self.recorder._on_status_change, callback)

    def test_17_notify_status_change(self):
        """测试触发状态变化回调"""
        callback = MagicMock()
        self.recorder.set_on_status_change(callback)
        self.recorder._notify_status_change('recording')
        callback.assert_called_once_with('recording')

    def test_18_notify_status_change_error_handling(self):
        """测试回调异常时不影响主流程"""
        bad_callback = MagicMock(side_effect=Exception("回调异常"))
        self.recorder.set_on_status_change(bad_callback)
        # 不应抛出异常
        self.recorder._notify_status_change('stopped')

    # ================================================================
    #  格式常量测试
    # ================================================================

    def test_19_format_constants(self):
        """测试格式常量定义"""
        self.assertEqual(WebAudioRecorder.FORMAT_WEBM_OPUS, 'webm_opus')
        self.assertEqual(WebAudioRecorder.FORMAT_WEBM_VORBIS, 'webm_vorbis')
        self.assertEqual(WebAudioRecorder.FORMAT_WAV, 'wav')
        self.assertEqual(WebAudioRecorder.FORMAT_MP3, 'mp3')
        self.assertEqual(WebAudioRecorder.FORMAT_M4A, 'm4a')
        self.assertEqual(WebAudioRecorder.FORMAT_WEBM, 'webm')

    # ================================================================
    #  清理测试
    # ================================================================

    def test_20_cleanup(self):
        """测试资源清理"""
        self.recorder._is_recording = False
        self.recorder._page = MagicMock()
        self.recorder.cleanup()
        self.assertIsNone(self.recorder._page)
        self.assertFalse(self.recorder._is_recording)
        self.assertFalse(self.recorder._is_paused)

    # ================================================================
    #  注入测试（mock 页面）
    # ================================================================

    def test_21_inject_success(self):
        """测试成功注入音频录制代码"""
        mock_page = MagicMock()
        mock_page.evaluate.return_value = True

        result = self.recorder.inject(mock_page)
        self.assertTrue(result)
        self.assertIs(self.recorder._page, mock_page)

    def test_22_inject_failure(self):
        """测试注入失败"""
        mock_page = MagicMock()
        mock_page.evaluate.side_effect = Exception("注入异常")

        result = self.recorder.inject(mock_page)
        self.assertFalse(result)

    # ================================================================
    #  ffmpeg 检查测试
    # ================================================================

    def test_23_check_ffmpeg(self):
        """测试 ffmpeg 可用性检查（通常 CI 环境不可用）"""
        # 不假设 ffmpeg 存在，只检查返回值类型
        result = self.recorder._check_ffmpeg()
        self.assertIsInstance(result, bool)


class TestPageAudioCapture(unittest.TestCase):
    """页面音频捕获器测试类"""

    def test_01_init(self):
        """测试初始化"""
        mock_page = MagicMock()
        capture = PageAudioCapture(mock_page)
        self.assertIsNotNone(capture)
        self.assertIsNotNone(capture.recorder)

    def test_02_custom_config(self):
        """测试自定义配置"""
        mock_page = MagicMock()
        capture = PageAudioCapture(mock_page, config={'format': 'wav'})
        self.assertEqual(capture.recorder.config['format'], 'wav')

    def test_03_cleanup(self):
        """测试清理资源"""
        mock_page = MagicMock()
        capture = PageAudioCapture(mock_page)
        capture.cleanup()  # 不应抛出异常


if __name__ == "__main__":
    unittest.main(verbosity=2)
