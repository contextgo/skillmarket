"""测试用例：AI 模型模块测试

测试 AIModelConfig 配置管理、提供商切换、提示词管理，
以及 AIModelCaller 的 mock API 调用。
不触发真实 API 请求，不依赖 API Key。
"""
import unittest
import sys
import os
import tempfile
import shutil
from unittest.mock import patch, MagicMock

# 添加项目路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from src.ai_model import AIModelConfig, AIModelCaller, create_config


class TestAIModelConfig(unittest.TestCase):
    """AI 模型配置管理测试类"""

    @classmethod
    def setUpClass(cls):
        """测试类初始化"""
        cls.temp_dir = tempfile.mkdtemp(prefix="test_ai_config_")

    @classmethod
    def tearDownClass(cls):
        """测试类清理"""
        if os.path.isdir(cls.temp_dir):
            shutil.rmtree(cls.temp_dir)

    def setUp(self):
        """每个测试用例前创建独立配置"""
        self.config_path = os.path.join(
            self.temp_dir, f"test_AImodel_{id(self)}.yaml"
        )
        self.config = AIModelConfig(config_path=self.config_path)

    # ================================================================
    #  初始化和配置加载测试
    # ================================================================

    def test_01_init_creates_default_config(self):
        """测试初始化时创建默认配置"""
        self.assertIsInstance(self.config, AIModelConfig)
        self.assertIn('global', self.config.config)
        self.assertIn('models', self.config.config)
        self.assertIn('system_prompts', self.config.config)

    def test_02_default_provider(self):
        """测试默认提供商配置"""
        default = self.config.get_global('default_provider')
        self.assertEqual(default, 'siliconflow')

    def test_03_default_timeout(self):
        """测试默认超时配置"""
        timeout = self.config.get_global('timeout')
        self.assertEqual(timeout, 120)

    def test_04_config_file_created(self):
        """测试配置文件被创建"""
        self.assertTrue(os.path.isfile(self.config_path))

    # ================================================================
    #  提供商配置测试
    # ================================================================

    def test_05_get_provider_config(self):
        """测试获取指定提供商配置"""
        config = self.config.get_provider_config('siliconflow')
        self.assertIsInstance(config, dict)
        self.assertIn('api_base', config)
        self.assertIn('chat_model', config)

    def test_06_get_default_provider_config(self):
        """测试不指定提供商时获取默认提供商配置"""
        config = self.config.get_provider_config()
        self.assertIn('api_base', config)

    def test_07_get_nonexistent_provider(self):
        """测试获取不存在的提供商返回空字典"""
        config = self.config.get_provider_config('nonexistent_provider')
        self.assertEqual(config, {})

    def test_08_get_enabled_providers(self):
        """测试获取已启用的提供商列表"""
        providers = self.config.get_enabled_providers()
        self.assertIsInstance(providers, list)
        # 默认配置中 siliconflow 和 deepseek 是启用的
        self.assertIn('siliconflow', providers)
        self.assertIn('deepseek', providers)

    def test_09_is_provider_ready_without_key(self):
        """测试未配置 API Key 时提供商未就绪"""
        # 默认配置中 API Key 为空
        ready = self.config.is_provider_ready('siliconflow')
        self.assertFalse(ready)

    def test_10_is_provider_ready_with_key(self):
        """测试配置 API Key 后提供商就绪"""
        self.config.set_api_key('siliconflow', 'sk-test-key-12345')
        ready = self.config.is_provider_ready('siliconflow')
        self.assertTrue(ready)

    def test_11_set_api_key(self):
        """测试设置 API 密钥"""
        result = self.config.set_api_key('siliconflow', 'sk-test-key')
        self.assertTrue(result)
        config = self.config.get_provider_config('siliconflow')
        self.assertEqual(config['api_key'], 'sk-test-key')

    # ================================================================
    #  提示词管理测试
    # ================================================================

    def test_12_get_system_prompt_default(self):
        """测试获取默认系统提示词"""
        prompt = self.config.get_system_prompt('default')
        self.assertIsInstance(prompt, str)
        self.assertGreater(len(prompt), 0)

    def test_13_get_system_prompt_nonexistent(self):
        """测试获取不存在的提示词时回退到默认"""
        prompt = self.config.get_system_prompt('nonexistent_prompt')
        # 应回退到 default
        self.assertIsInstance(prompt, str)

    def test_14_get_all_prompts(self):
        """测试获取所有提示词"""
        prompts = self.config.get_all_prompts()
        self.assertIsInstance(prompts, dict)
        self.assertIn('default', prompts)
        self.assertIn('meeting_notes', prompts)

    def test_15_add_system_prompt(self):
        """测试添加自定义系统提示词"""
        result = self.config.add_system_prompt(
            'test_prompt', '这是一个测试提示词', description='测试', variables=['var1']
        )
        self.assertTrue(result)
        prompt = self.config.get_system_prompt('test_prompt')
        self.assertEqual(prompt, '这是一个测试提示词')

    def test_16_update_model_params(self):
        """测试更新模型参数"""
        result = self.config.update_model_params('siliconflow', {
            'temperature': 0.7,
            'max_tokens': 2000
        })
        self.assertTrue(result)
        config = self.config.get_provider_config('siliconflow')
        self.assertEqual(config['default_params']['temperature'], 0.7)
        self.assertEqual(config['default_params']['max_tokens'], 2000)

    # ================================================================
    #  配置保存和加载测试
    # ================================================================

    def test_17_save_and_reload(self):
        """测试保存配置后重新加载"""
        self.config.set_api_key('siliconflow', 'sk-persist-test')
        self.config.save()

        # 重新加载
        config2 = AIModelConfig(config_path=self.config_path)
        key = config2.get_provider_config('siliconflow').get('api_key', '')
        self.assertEqual(key, 'sk-persist-test')

    def test_18_load_corrupt_yaml(self):
        """测试加载损坏的 YAML 文件时回退到默认配置"""
        # 写入无效 YAML
        with open(self.config_path, 'w', encoding='utf-8') as f:
            f.write("{{invalid yaml::")

        config = AIModelConfig(config_path=self.config_path)
        # 应回退到默认配置
        self.assertIn('global', config.config)


class TestAIModelCaller(unittest.TestCase):
    """AI 模型调用器测试类"""

    @classmethod
    def setUpClass(cls):
        """测试类初始化"""
        cls.temp_dir = tempfile.mkdtemp(prefix="test_ai_caller_")

    @classmethod
    def tearDownClass(cls):
        """测试类清理"""
        if os.path.isdir(cls.temp_dir):
            shutil.rmtree(cls.temp_dir)

    def setUp(self):
        """每个测试用例前创建独立配置"""
        self.config_path = os.path.join(
            self.temp_dir, f"test_AImodel_caller_{id(self)}.yaml"
        )
        self.caller = AIModelCaller(config_path=self.config_path)

    # ================================================================
    #  提示词模板测试
    # ================================================================

    def test_01_format_prompt_braces(self):
        """测试花括号变量格式化"""
        template = "你好{name}，欢迎来到{place}"
        result = self.caller.format_prompt(template, name="张三", place="北京")
        self.assertEqual(result, "你好张三，欢迎来到北京")

    def test_02_format_prompt_dollar(self):
        """测试美元符号变量格式化"""
        template = "标题: $title, 时长: $duration"
        result = self.caller.format_prompt(template, title="测试", duration="5分钟")
        self.assertEqual(result, "标题: 测试, 时长: 5分钟")

    def test_03_format_prompt_missing_variable(self):
        """测试缺失变量时保留原占位符"""
        template = "你好{name}，{missing_var}"
        result = self.caller.format_prompt(template, name="测试")
        # 未匹配的变量保留原样
        self.assertIn("{missing_var}", result)

    def test_04_set_system_prompt(self):
        """测试设置系统提示词"""
        result = self.caller.set_system_prompt('default')
        self.assertIs(result, self.caller)  # 返回 self，支持链式调用
        self.assertIsNotNone(self.caller._current_system_prompt)

    def test_05_get_system_prompt(self):
        """测试获取系统提示词"""
        prompt = self.caller.get_system_prompt('default')
        self.assertIsInstance(prompt, str)
        self.assertGreater(len(prompt), 0)

    # ================================================================
    #  Mock API 调用测试
    # ================================================================

    def test_06_call_without_api_key_raises(self):
        """测试未配置 API Key 时调用抛出异常"""
        with self.assertRaises(ValueError):
            self.caller._get_client('siliconflow')

    def test_07_call_nonexistent_provider_raises(self):
        """测试调用不存在的提供商抛出异常"""
        with self.assertRaises(ValueError):
            self.caller._get_client('nonexistent_provider')

    @patch('src.ai_model.AIModelCaller._get_client')
    def test_08_call_with_mock_client(self, mock_get_client):
        """测试使用 mock 客户端调用 AI"""
        # 创建 mock 响应
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "这是 AI 的回复"

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_get_client.return_value = mock_client

        # 设置 API Key
        self.caller.config.set_api_key('siliconflow', 'sk-test')

        result = self.caller.call("你好", system_prompt="你是助手", provider='siliconflow')
        self.assertEqual(result, "这是 AI 的回复")

    @patch('src.ai_model.AIModelCaller._get_client')
    def test_09_call_with_reasoning_model(self, mock_get_client):
        """测试使用推理模型调用"""
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "推理结果"

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_get_client.return_value = mock_client

        self.caller.config.set_api_key('deepseek', 'sk-test')
        result = self.caller.call("分析这个问题", provider='deepseek', use_reasoning=True)
        self.assertEqual(result, "推理结果")

    @patch('src.ai_model.AIModelCaller._get_client')
    def test_10_chat_with_mock_client(self, mock_get_client):
        """测试聊天接口"""
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "聊天回复"

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_get_client.return_value = mock_client

        messages = [{'role': 'user', 'content': '你好'}]
        result = self.caller.chat(messages, provider='siliconflow')
        self.assertEqual(result, "聊天回复")


class TestCreateConfig(unittest.TestCase):
    """便捷函数测试"""

    def test_01_create_config(self):
        """测试创建配置便捷函数"""
        config = create_config()
        self.assertIsInstance(config, AIModelConfig)


if __name__ == "__main__":
    unittest.main(verbosity=2)
