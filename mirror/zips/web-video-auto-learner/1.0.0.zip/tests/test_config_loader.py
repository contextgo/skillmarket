"""
测试用例：配置加载器测试
"""
import unittest
import sys
import os
import tempfile
import shutil

# 添加项目路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from src.config_loader import ConfigLoader
from src.logger import setup_logger


class TestConfigLoader(unittest.TestCase):
    """配置加载器测试类"""

    @classmethod
    def setUpClass(cls):
        """测试类初始化"""
        cls.logger = setup_logger(name="test_config_loader")
        cls.temp_dir = tempfile.mkdtemp(prefix="test_config_")

    @classmethod
    def tearDownClass(cls):
        """测试类清理"""
        # 清理临时目录
        if os.path.isdir(cls.temp_dir):
            shutil.rmtree(cls.temp_dir)

    def setUp(self):
        """每个测试用例前的设置"""
        # 创建临时配置文件
        self.config_file = os.path.join(self.temp_dir, "test_config.yaml")
        self.loader = ConfigLoader(config_path=self.config_file, logger=self.logger)

    def tearDown(self):
        """每个测试用例后的清理"""
        # 删除临时配置文件
        if os.path.isfile(self.config_file):
            os.remove(self.config_file)

    def test_01_init(self):
        """测试初始化"""
        self.assertIsNotNone(self.loader)
        self.assertEqual(self.loader.config_path, self.config_file)

    def test_02_load_not_exists(self):
        """测试加载不存在的配置文件"""
        # 不应该抛出异常
        result = self.loader.load()
        self.assertIsNone(result)  # 返回 None 表示使用了默认配置

    def test_03_set_and_get_settings(self):
        """测试设置和获取设置"""
        # 设置配置
        settings = {
            "browser_type": "chrome",
            "window_max": True,
            "global_timeout": 60000
        }
        self.loader.set_settings(settings)

        # 获取配置
        result = self.loader.get_settings()
        self.assertEqual(result["browser_type"], "chrome")
        self.assertTrue(result["window_max"])
        self.assertEqual(result["global_timeout"], 60000)

    def test_04_save_and_load(self):
        """测试保存和加载配置"""
        # 设置配置
        settings = {"browser_type": "msedge", "window_max": False}
        self.loader.set_settings(settings)

        # 保存配置
        result = self.loader.save()
        self.assertTrue(result)
        self.assertTrue(os.path.isfile(self.config_file))

        # 创建新的加载器并加载配置
        new_loader = ConfigLoader(config_path=self.config_file, logger=self.logger)
        new_loader.load()
        result = new_loader.get_settings()
        self.assertEqual(result["browser_type"], "msedge")
        self.assertFalse(result["window_max"])

    def test_05_get_website(self):
        """测试获取网站配置"""
        # 先设置配置
        website = {"login_url": "https://www.example.com/", "storage_state": True}
        self.loader.set_website(website)

        # 获取网站配置
        result = self.loader.get_website()
        self.assertEqual(result["login_url"], "https://www.example.com/")
        self.assertTrue(result["storage_state"])

    def test_06_get_navigation(self):
        """测试获取导航步骤"""
        # 先设置配置
        navigation = [
            {"name": "登录页", "action": "navigate", "url": "https://www.example.com/"},
            {"name": "播放视频", "action": "play_list", "play_list": []}
        ]
        self.loader.set_navigation(navigation)

        # 获取导航步骤
        result = self.loader.get_navigation()
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]["name"], "登录页")
        self.assertEqual(result[1]["action"], "play_list")

    def test_07_get_popup_rules(self):
        """测试获取弹窗规则"""
        # 先设置配置
        popup_rules = [
            {"type": "quiz", "keyword": "答题", "action": "auto_answer"}
        ]
        self.loader.set_popup_rules(popup_rules)

        # 获取弹窗规则
        result = self.loader.get_popup_rules()
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["type"], "quiz")

    def test_08_is_auto_answer_enabled(self):
        """测试获取自动答题开关状态"""
        # 先设置配置
        settings = {"auto_answer": True}
        self.loader.set_settings(settings)

        # 获取自动答题开关状态
        result = self.loader.is_auto_answer_enabled()
        self.assertTrue(result)

    def test_09_set_auto_answer(self):
        """测试设置自动答题开关"""
        # 设置自动答题开关
        result = self.loader.set_auto_answer(True)
        self.assertTrue(result)

        # 验证设置
        result = self.loader.is_auto_answer_enabled()
        self.assertTrue(result)

        # 关闭自动答题开关
        result = self.loader.set_auto_answer(False)
        self.assertTrue(result)

        # 验证设置
        result = self.loader.is_auto_answer_enabled()
        self.assertFalse(result)


if __name__ == "__main__":
    unittest.main(verbosity=2)
