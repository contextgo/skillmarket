"""测试用例：弹窗处理器测试

测试弹窗规则匹配、事件回调机制、步骤级规则管理等。
使用 mock 替代真实浏览器，不需要 Playwright 环境。
"""
import unittest
import sys
import os
from unittest.mock import MagicMock, patch

# 添加项目路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from src.popup_handler import PopupHandler


class TestPopupHandler(unittest.TestCase):
    """弹窗处理器测试类"""

    @classmethod
    def setUpClass(cls):
        """测试类初始化"""
        cls.logger = MagicMock()

    def setUp(self):
        """每个测试用例前创建独立的 PopupHandler"""
        self.popup_rules = [
            {"type": "quiz", "keyword": "答题", "action": "auto_answer"},
            {"type": "layer", "keyword": "确认", "action": "click_button",
             "selector": "//button[contains(text(),'确定')]"},
        ]
        self.handler = PopupHandler(
            page=None,
            popup_rules=self.popup_rules,
            logger=self.logger,
            browser=None,
            auto_answer_enabled=False,
        )

    # ================================================================
    #  初始化测试
    # ================================================================

    def test_01_init(self):
        """测试初始化"""
        self.assertIsNotNone(self.handler)
        self.assertEqual(len(self.handler.popup_rules), 2)
        self.assertFalse(self.handler.auto_answer_enabled)
        self.assertFalse(self.handler.running)

    def test_02_init_with_auto_answer(self):
        """测试启用自动答题的初始化"""
        handler = PopupHandler(
            page=None, popup_rules=[], logger=self.logger,
            auto_answer_enabled=True
        )
        self.assertTrue(handler.auto_answer_enabled)

    # ================================================================
    #  弹窗类型检测测试
    # ================================================================

    def test_03_detect_popup_type_by_keyword(self):
        """测试通过关键词自动判断弹窗类型"""
        # 匹配 quiz 规则关键词
        result = self.handler.detect_popup_type("请完成答题测试")
        self.assertEqual(result, "quiz")

    def test_04_detect_popup_type_layer_keyword(self):
        """测试 layer 类型关键词匹配"""
        result = self.handler.detect_popup_type("请确认操作")
        self.assertEqual(result, "layer")

    def test_05_detect_popup_type_no_match(self):
        """测试无匹配规则时的默认检测（无浏览器页面时回退）"""
        # 没有匹配规则且无页面时，返回 'custom' 或回退
        result = self.handler.detect_popup_type("普通文本")
        # 无页面环境时可能返回 'custom' 或触发异常被捕获
        self.assertIn(result, ('custom', None, 'radio'))

    # ================================================================
    #  事件回调测试
    # ================================================================

    def test_06_register_popup_callback(self):
        """测试注册弹窗事件回调"""
        callback = MagicMock()
        self.handler.on_popup_event('detected', callback)
        self.assertEqual(len(self.handler._popup_callbacks), 1)
        self.assertEqual(self.handler._popup_callbacks[0][0], 'detected')
        self.assertIs(self.handler._popup_callbacks[0][1], callback)

    def test_07_fire_callback(self):
        """测试触发弹窗事件回调"""
        callback = MagicMock()
        self.handler.on_popup_event('handled', callback)

        info = {'popup_type': 'quiz', 'details': '测试答题'}
        self.handler._fireCallback('handled', info)

        callback.assert_called_once_with('handled', info)

    def test_08_fire_callback_error_handling(self):
        """测试回调异常时不影响其他回调"""
        bad_callback = MagicMock(side_effect=Exception("回调异常"))
        good_callback = MagicMock()

        self.handler.on_popup_event('detected', bad_callback)
        self.handler.on_popup_event('detected', good_callback)

        info = {'popup_type': 'test'}
        self.handler._fireCallback('detected', info)

        # 两个回调都应被调用
        bad_callback.assert_called_once()
        good_callback.assert_called_once()

    def test_09_fire_callback_type_filter(self):
        """测试只触发指定类型的回调"""
        detected_cb = MagicMock()
        handled_cb = MagicMock()

        self.handler.on_popup_event('detected', detected_cb)
        self.handler.on_popup_event('handled', handled_cb)

        self.handler._fireCallback('detected', {})
        detected_cb.assert_called_once()
        handled_cb.assert_not_called()

    # ================================================================
    #  步骤级弹窗规则测试
    # ================================================================

    def test_10_set_step_popup_rules(self):
        """测试设置步骤级弹窗规则"""
        step_rules = [
            {"type": "quiz", "keyword": "随堂测试", "action": "auto_answer"}
        ]
        self.handler.set_step_popup_rules(step_rules)

        # 步骤规则优先
        self.assertEqual(len(self.handler.popup_rules), 3)  # 1 step + 2 global
        self.assertEqual(self.handler.popup_rules[0]['keyword'], '随堂测试')

    def test_11_set_step_rules_none(self):
        """测试步骤规则为空时仅使用全局规则"""
        self.handler.set_step_popup_rules(None)
        self.assertEqual(len(self.handler.popup_rules), 2)

    def test_12_set_step_rules_empty(self):
        """测试步骤规则为空列表时仅使用全局规则"""
        self.handler.set_step_popup_rules([])
        self.assertEqual(len(self.handler.popup_rules), 2)

    def test_13_clear_step_popup_rules(self):
        """测试清除步骤级弹窗规则"""
        step_rules = [{"type": "quiz", "keyword": "测试", "action": "auto_answer"}]
        self.handler.set_step_popup_rules(step_rules)
        self.assertEqual(len(self.handler.popup_rules), 3)

        self.handler.clear_step_popup_rules()
        self.assertEqual(len(self.handler.popup_rules), 2)

    # ================================================================
    #  自动答题开关测试
    # ================================================================

    def test_14_auto_answer_toggle(self):
        """测试自动答题开关切换"""
        self.handler.auto_answer_enabled = True
        self.assertTrue(self.handler.auto_answer_enabled)

        self.handler.auto_answer_enabled = False
        self.assertFalse(self.handler.auto_answer_enabled)

    # ================================================================
    #  线程安全调用测试
    # ================================================================

    def test_15_pw_caller_on_main_thread(self):
        """测试主线程直接执行函数"""
        result = self.handler._pw(lambda: 42)
        self.assertEqual(result, 42)

    def test_16_set_pw_caller(self):
        """测试设置 Playwright 线程安全调用器"""
        mock_caller = MagicMock(return_value="mock_result")
        self.handler.set_pw_caller(mock_caller)
        self.assertIs(self.handler._pw_call, mock_caller)

    # ================================================================
    #  quiz 规则检测测试
    # ================================================================

    def test_17_has_quiz_rules_true(self):
        """测试检测到 quiz 类型规则"""
        self.assertTrue(self.handler._has_quiz_rules())

    def test_18_has_quiz_rules_false(self):
        """测试无 quiz 类型规则"""
        handler = PopupHandler(
            page=None,
            popup_rules=[{"type": "layer", "keyword": "确认", "action": "click_button"}],
            logger=self.logger,
        )
        self.assertFalse(handler._has_quiz_rules())

    # ================================================================
    #  监听控制测试
    # ================================================================

    def test_19_start_listening_no_rules(self):
        """测试无弹窗规则时不启动监听"""
        handler = PopupHandler(page=None, popup_rules=[], logger=self.logger)
        # 不应抛出异常
        handler.start_listening(check_interval=1.0)

    def test_20_stop_listening(self):
        """测试停止监听"""
        self.handler.stop_listening()
        self.assertFalse(self.handler.running)


if __name__ == "__main__":
    unittest.main(verbosity=2)
