"""
测试用例：任务执行器测试
"""
import unittest
import sys
import os
import time

# 添加项目路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from src.task_runner import TaskRunner
from src.config_loader import ConfigLoader
from src.browser import BrowserManager
from src.logger import setup_logger


class TestTaskRunner(unittest.TestCase):
    """任务执行器测试类"""

    @classmethod
    def setUpClass(cls):
        """测试类初始化"""
        cls.logger = setup_logger(name="test_task_runner")
        cls.config_file = os.path.join(cls._get_temp_dir(), "test_config.yaml")
        cls.config_loader = ConfigLoader(config_path=cls.config_file, logger=cls.logger)
        
        # 初始化配置
        settings = {
            "browser_type": "chrome",
            "window_max": True,
            "global_timeout": 60000,
            "popup_scan_interval": 0.5,
            "auto_answer": False
        }
        cls.config_loader.set_settings(settings)
        
        website = {
            "login_url": "https://www.example.com/",
            "storage_state": False
        }
        cls.config_loader.set_website(website)
        
        navigation = [
            {
                "name": "测试步骤",
                "action": "navigate",
                "url": "https://www.example.com/",
                "selector": "",
                "tab_index": -1,
                "stay_time": 1,
                "loop_infinite": False,
                "loop_count": 1,
                "media_timeout": "3600",
                "play_list": [],
                "popup_rules": []
            }
        ]
        cls.config_loader.set_navigation(navigation)
        
        # 保存配置
        cls.config_loader.save()
        
        # 初始化浏览器
        cls.browser = BrowserManager(cls.logger)
        cls.browser.ensure_open(
            browser_type="chrome",
            window_max=False,
            headless=True  # 使用无头模式，避免弹出浏览器窗口
        )
        
        # 初始化任务执行器
        cls.task_runner = TaskRunner(
            cls.browser,
            None,  # popup_handler
            navigation,
            cls.logger,
            settings,
            config_loader=cls.config_loader
        )

    @classmethod
    def tearDownClass(cls):
        """测试类清理"""
        if cls.browser:
            cls.browser.close(force=True)
        
        # 清理临时配置文件
        if os.path.isfile(cls.config_file):
            os.remove(cls.config_file)

    @classmethod
    def _get_temp_dir(cls):
        """获取临时目录路径"""
        temp_dir = os.path.join(os.path.dirname(__file__), "temp")
        if not os.path.isdir(temp_dir):
            os.makedirs(temp_dir)
        return temp_dir

    def test_01_init(self):
        """测试初始化"""
        self.assertIsNotNone(self.task_runner)
        self.assertEqual(self.task_runner.status, "initialized")

    def test_02_pause_resume(self):
        """测试暂停和恢复"""
        # 暂停
        self.task_runner.pause()
        self.assertEqual(self.task_runner.status, "paused")
        
        # 恢复
        self.task_runner.resume()
        self.assertEqual(self.task_runner.status, "running")

    def test_03_stop(self):
        """测试停止"""
        self.task_runner.stop()
        self.assertEqual(self.task_runner.status, "stopped")

    def test_04_get_progress(self):
        """测试获取进度"""
        progress = self.task_runner.get_progress()
        self.assertIsInstance(progress, dict)

    def test_05_is_paused(self):
        """测试是否暂停"""
        # 先恢复
        self.task_runner.resume()
        result = self.task_runner.is_paused()
        self.assertFalse(result)
        
        # 再暂停
        self.task_runner.pause()
        result = self.task_runner.is_paused()
        self.assertTrue(result)
        
        # 恢复状态
        self.task_runner.resume()


if __name__ == "__main__":
    unittest.main(verbosity=2)
