"""
运行所有测试用例
"""
import unittest
import sys
import os

# 添加项目路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# 发现并运行所有测试
loader = unittest.TestLoader()
suite = loader.discover(os.path.dirname(__file__), pattern="test_*.py")

# 运行测试
runner = unittest.TextTestRunner(verbosity=2)
result = runner.run(suite)

# 退出码
sys.exit(0 if result.wasSuccessful() else 1)
