"""测试用例：加密模块测试

测试加密/解密往返一致性、文件存储/加载、边界情况和错误处理。
所有测试使用 mock 设备特征，避免影响真实加密文件。
"""
import unittest
import sys
import os
import tempfile
import shutil
import json
from unittest.mock import patch, MagicMock

# 添加项目路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from src.encryption import (
    encrypt_storage_state,
    decrypt_storage_state,
    save_encrypted_storage_state,
    load_encrypted_storage_state,
    _derive_key,
)


class TestEncryption(unittest.TestCase):
    """加密模块测试类"""

    @classmethod
    def setUpClass(cls):
        """测试类初始化"""
        cls.temp_dir = tempfile.mkdtemp(prefix="test_encryption_")

    @classmethod
    def tearDownClass(cls):
        """测试类清理"""
        if os.path.isdir(cls.temp_dir):
            shutil.rmtree(cls.temp_dir)

    # ================================================================
    #  核心功能测试：加密/解密往返
    # ================================================================

    def test_01_encrypt_decrypt_roundtrip(self):
        """测试加密后解密能还原原始数据"""
        original = {
            "cookies": [
                {"name": "session", "value": "abc123", "domain": "example.com"}
            ],
            "origins": []
        }
        encrypted = encrypt_storage_state(original)
        self.assertIsInstance(encrypted, bytes)
        self.assertGreater(len(encrypted), 0)

        decrypted = decrypt_storage_state(encrypted)
        self.assertEqual(decrypted, original)

    def test_02_encrypt_decrypt_complex_data(self):
        """测试复杂数据结构的加密解密"""
        original = {
            "cookies": [
                {"name": "token", "value": "x" * 500, "domain": "api.example.com",
                 "path": "/v1", "expires": 1700000000.0, "httpOnly": True, "secure": True, "sameSite": "Lax"},
                {"name": "lang", "value": "zh-CN", "domain": ".example.com"},
            ],
            "origins": [
                {"origin": "https://example.com", "localStorage": [
                    {"name": "key1", "value": "val1"}
                ]}
            ]
        }
        encrypted = encrypt_storage_state(original)
        decrypted = decrypt_storage_state(encrypted)
        self.assertEqual(decrypted, original)

    def test_03_encrypt_produces_different_ciphertext(self):
        """测试相同数据两次加密产生不同密文（Fernet 包含时间戳）"""
        data = {"cookies": [], "origins": []}
        enc1 = encrypt_storage_state(data)
        enc2 = encrypt_storage_state(data)
        # Fernet 加密含时间戳，相同数据两次加密结果不同
        self.assertNotEqual(enc1, enc2)
        # 但都能正确解密
        self.assertEqual(decrypt_storage_state(enc1), data)
        self.assertEqual(decrypt_storage_state(enc2), data)

    # ================================================================
    #  文件存储测试
    # ================================================================

    def test_04_save_and_load_file(self):
        """测试加密存储到文件并从文件加载"""
        original = {
            "cookies": [{"name": "test", "value": "123", "domain": "test.com"}],
            "origins": []
        }
        filepath = os.path.join(self.temp_dir, "test_state.enc")

        save_encrypted_storage_state(original, filepath)
        self.assertTrue(os.path.isfile(filepath))
        self.assertGreater(os.path.getsize(filepath), 0)

        loaded = load_encrypted_storage_state(filepath)
        self.assertEqual(loaded, original)

    def test_05_save_creates_parent_dirs(self):
        """测试保存时自动创建父目录"""
        data = {"cookies": [], "origins": []}
        filepath = os.path.join(self.temp_dir, "sub", "dir", "state.enc")

        save_encrypted_storage_state(data, filepath)
        self.assertTrue(os.path.isfile(filepath))

        loaded = load_encrypted_storage_state(filepath)
        self.assertEqual(loaded, data)

    def test_06_overwrite_existing_file(self):
        """测试覆盖已存在的文件"""
        data1 = {"cookies": [{"name": "v1", "value": "1", "domain": "a.com"}], "origins": []}
        data2 = {"cookies": [{"name": "v2", "value": "2", "domain": "b.com"}], "origins": []}
        filepath = os.path.join(self.temp_dir, "overwrite.enc")

        save_encrypted_storage_state(data1, filepath)
        save_encrypted_storage_state(data2, filepath)

        loaded = load_encrypted_storage_state(filepath)
        self.assertEqual(loaded, data2)

    # ================================================================
    #  边界情况测试
    # ================================================================

    def test_07_empty_dict(self):
        """测试空字典的加密解密"""
        data = {}
        encrypted = encrypt_storage_state(data)
        decrypted = decrypt_storage_state(encrypted)
        self.assertEqual(decrypted, data)

    def test_08_unicode_content(self):
        """测试包含 Unicode 字符的数据"""
        data = {
            "cookies": [{"name": "用户", "value": "中文值🎉", "domain": "例子.中国"}],
            "origins": []
        }
        encrypted = encrypt_storage_state(data)
        decrypted = decrypt_storage_state(encrypted)
        self.assertEqual(decrypted, data)

    def test_09_large_data(self):
        """测试大量数据的加密解密"""
        data = {
            "cookies": [
                {"name": f"cookie_{i}", "value": f"val_{i}" * 50, "domain": "example.com"}
                for i in range(100)
            ],
            "origins": []
        }
        encrypted = encrypt_storage_state(data)
        decrypted = decrypt_storage_state(encrypted)
        self.assertEqual(decrypted, data)

    # ================================================================
    #  错误处理测试
    # ================================================================

    def test_10_decrypt_invalid_data(self):
        """测试解密无效数据抛出异常"""
        with self.assertRaises(Exception):
            decrypt_storage_state(b"not_valid_encrypted_data")

    def test_11_decrypt_empty_bytes(self):
        """测试解密空字节抛出异常"""
        with self.assertRaises(Exception):
            decrypt_storage_state(b"")

    def test_12_load_nonexistent_file(self):
        """测试加载不存在的文件抛出异常"""
        filepath = os.path.join(self.temp_dir, "nonexistent.enc")
        with self.assertRaises(FileNotFoundError):
            load_encrypted_storage_state(filepath)

    # ================================================================
    #  密钥派生测试
    # ================================================================

    def test_13_derive_key_deterministic(self):
        """测试相同密码和盐值派生相同密钥"""
        password = b"test_password"
        salt = os.urandom(16)
        key1 = _derive_key(password, salt)
        key2 = _derive_key(password, salt)
        self.assertEqual(key1, key2)

    def test_14_derive_key_different_salt(self):
        """测试不同盐值派生不同密钥"""
        password = b"test_password"
        salt1 = os.urandom(16)
        salt2 = os.urandom(16)
        key1 = _derive_key(password, salt1)
        key2 = _derive_key(password, salt2)
        self.assertNotEqual(key1, key2)

    def test_15_derive_key_different_password(self):
        """测试不同密码派生不同密钥"""
        salt = os.urandom(16)
        key1 = _derive_key(b"password1", salt)
        key2 = _derive_key(b"password2", salt)
        self.assertNotEqual(key1, key2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
