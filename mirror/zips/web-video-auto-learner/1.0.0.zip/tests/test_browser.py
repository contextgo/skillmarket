"""
测试用例：浏览器管理模块测试
"""
import unittest
import sys
import os

# 添加项目路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from src.browser import BrowserManager
from src.logger import setup_logger


class TestBrowserManager(unittest.TestCase):
    """浏览器管理器测试类"""

    @classmethod
    def setUpClass(cls):
        """测试类初始化"""
        cls.logger = setup_logger(name="test_browser")
        cls.browser = BrowserManager(cls.logger)

    @classmethod
    def tearDownClass(cls):
        """测试类清理"""
        if cls.browser:
            cls.browser.close(force=True)

    def test_01_init(self):
        """测试初始化"""
        self.assertIsNotNone(self.browser)
        self.assertIsNotNone(self.browser.logger)

    def test_02_is_alive_false(self):
        """测试浏览器未启动时 is_alive 返回 False"""
        result = self.browser.is_alive()
        self.assertFalse(result)

    def test_03_ensure_open_chrome(self):
        """测试启动 Chrome 浏览器"""
        result = self.browser.ensure_open(
            browser_type="chrome",
            window_max=True,
            headless=True  # 使用无头模式，避免弹出浏览器窗口
        )
        self.assertTrue(result)
        self.assertTrue(self.browser.is_alive())

    def test_04_is_alive_true(self):
        """测试浏览器启动后 is_alive 返回 True"""
        result = self.browser.is_alive()
        self.assertTrue(result)

    def test_05_navigate(self):
        """测试页面导航"""
        if not self.browser.is_alive():
            self.skipTest("浏览器未启动")

        result = self.browser.navigate("https://www.example.com/")
        self.assertTrue(result)

    def test_06_get_page_url(self):
        """测试获取页面 URL"""
        if not self.browser.is_alive():
            self.skipTest("浏览器未启动")

        url = self.browser.page.url
        self.assertIn("example.com", url)

    def test_07_save_storage_state(self):
        """测试保存浏览器状态"""
        if not self.browser.is_alive():
            self.skipTest("浏览器未启动")

        # 创建临时文件路径
        temp_file = os.path.join(os.path.dirname(__file__), "test_storage_state.json")

        try:
            result = self.browser.save_storage_state(temp_file, encrypt=False)
            self.assertTrue(result)
            self.assertTrue(os.path.isfile(temp_file))
        finally:
            # 清理临时文件
            if os.path.isfile(temp_file):
                os.remove(temp_file)

    def test_08_close_browser(self):
        """测试关闭浏览器"""
        if self.browser.is_alive():
            self.browser.close(force=True)
        self.assertFalse(self.browser.is_alive())


if __name__ == "__main__":
    unittest.main(verbosity=2)
