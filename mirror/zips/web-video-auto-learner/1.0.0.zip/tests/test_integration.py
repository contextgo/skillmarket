"""测试用例：集成测试

测试 WebVideoAutoLearner 端到端流程和命令接口。
使用 mock 替代真实浏览器，不依赖 Playwright 环境和真实 API。
"""
import unittest
import sys
import os
import tempfile
import shutil
from unittest.mock import MagicMock, patch

# 添加项目路径
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# 确保能导入 index.py 中的 WebVideoAutoLearner
_src_dir = os.path.join(_project_root, 'src')
if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)


class TestWebVideoAutoLearnerInit(unittest.TestCase):
    """WebVideoAutoLearner 初始化和配置测试"""

    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.mkdtemp(prefix="test_learner_")

    @classmethod
    def tearDownClass(cls):
        if os.path.isdir(cls.temp_dir):
            shutil.rmtree(cls.temp_dir)

    def setUp(self):
        """每个测试用例前创建独立实例"""
        from index import WebVideoAutoLearner
        self.config_path = os.path.join(
            self.temp_dir, f"test_config_{id(self)}.yaml"
        )
        self.learner = WebVideoAutoLearner(
            mode="headless",
            config_path=self.config_path,
            log_level="WARNING",
        )

    # ================================================================
    #  初始化测试
    # ================================================================

    def test_01_init_headless(self):
        """测试 headless 模式初始化"""
        self.assertEqual(self.learner.mode, "headless")
        self.assertEqual(self.learner.status, "initialized")

    def test_02_init_invalid_mode(self):
        """测试无效模式抛出 ValueError"""
        from index import WebVideoAutoLearner
        with self.assertRaises(ValueError):
            WebVideoAutoLearner(mode="invalid_mode")

    def test_03_valid_modes(self):
        """测试所有有效模式"""
        from index import WebVideoAutoLearner
        valid_modes = {"all", "simple", "list", "headless"}
        self.assertEqual(WebVideoAutoLearner.VALID_MODES, valid_modes)

    # ================================================================
    #  配置测试
    # ================================================================

    def test_04_configure(self):
        """测试配置方法（链式调用）"""
        result = self.learner.configure(
            browser_type="chrome",
            login_url="https://www.example.com/",
            headless=True,
        )
        self.assertIs(result, self.learner)  # 链式调用返回 self

    def test_05_configure_with_storage_state(self):
        """测试配置 Storage State"""
        self.learner.configure(
            storage_state=True,
            storage_state_file="test_state.enc",
        )
        website = self.learner.config_loader.get_website()
        self.assertTrue(website.get('storage_state'))
        self.assertEqual(website.get('storage_state_file'), 'test_state.enc')

    # ================================================================
    #  播放列表管理测试
    # ================================================================

    def test_06_add_play_url(self):
        """测试添加单个播放 URL"""
        result = self.learner.add_play_url(
            "https://example.com/video1", click_play=True
        )
        self.assertIs(result, self.learner)
        urls = self.learner.get_play_urls()
        self.assertEqual(len(urls), 1)
        self.assertEqual(urls[0]['url'], "https://example.com/video1")

    def test_07_add_play_urls(self):
        """测试批量添加播放 URL"""
        urls = [
            "https://example.com/video1",
            "https://example.com/video2",
            ("https://example.com/video3", "课程A"),
        ]
        self.learner.add_play_urls(urls)
        result = self.learner.get_play_urls()
        self.assertEqual(len(result), 3)

    def test_08_add_duplicate_url(self):
        """测试添加重复 URL 被跳过"""
        self.learner.add_play_url("https://example.com/video1")
        self.learner.add_play_url("https://example.com/video1")
        urls = self.learner.get_play_urls()
        self.assertEqual(len(urls), 1)

    def test_09_remove_play_url(self):
        """测试移除播放 URL"""
        self.learner.add_play_url("https://example.com/video1")
        self.learner.add_play_url("https://example.com/video2")
        self.learner.remove_play_url("https://example.com/video1")
        urls = self.learner.get_play_urls()
        self.assertEqual(len(urls), 1)
        self.assertEqual(urls[0]['url'], "https://example.com/video2")

    def test_10_clear_play_urls(self):
        """测试清空播放列表"""
        self.learner.add_play_url("https://example.com/video1")
        self.learner.add_play_url("https://example.com/video2")
        self.learner.clear_play_urls()
        urls = self.learner.get_play_urls()
        self.assertEqual(len(urls), 0)

    def test_11_set_play_urls(self):
        """测试替换播放列表"""
        self.learner.add_play_url("https://example.com/old")
        self.learner.set_play_urls(["https://example.com/new1", "https://example.com/new2"])
        urls = self.learner.get_play_urls()
        self.assertEqual(len(urls), 2)
        self.assertTrue(all('new' in u['url'] for u in urls))

    def test_12_reset_play_progress(self):
        """测试重置播放进度"""
        self.learner.add_play_url("https://example.com/video1")
        urls = self.learner.get_play_urls()
        for item in urls:
            item['completed'] = True

        self.learner.reset_play_progress()
        urls = self.learner.get_play_urls()
        self.assertTrue(all(not u.get('completed', False) for u in urls))

    # ================================================================
    #  命令接口测试
    # ================================================================

    def test_13_execute_command_unknown(self):
        """测试未知命令返回错误"""
        result = self.learner.execute_command('unknown_command')
        self.assertFalse(result['success'])
        self.assertIn('未知命令', result['error'])

    def test_14_execute_command_init(self):
        """测试 init 命令"""
        result = self.learner.execute_command('init')
        self.assertTrue(result['success'])
        self.assertIn('status', result['data'])

    def test_15_execute_command_add_urls(self):
        """测试 add_urls 命令"""
        result = self.learner.execute_command(
            'add_urls', urls=["https://example.com/v1", "https://example.com/v2"]
        )
        self.assertTrue(result['success'])
        self.assertEqual(result['data']['total'], 2)

    def test_16_execute_command_clear_urls(self):
        """测试 clear_urls 命令"""
        self.learner.add_play_url("https://example.com/v1")
        result = self.learner.execute_command('clear_urls')
        self.assertTrue(result['success'])
        self.assertEqual(result['data']['total'], 0)

    def test_17_execute_command_get_status(self):
        """测试 get_status 命令"""
        result = self.learner.execute_command('get_status')
        self.assertTrue(result['success'])
        self.assertIn('status', result['data'])

    def test_18_execute_command_check_login(self):
        """测试 check_login 命令"""
        result = self.learner.execute_command('check_login')
        self.assertTrue(result['success'])
        self.assertIn('exists', result['data'])

    def test_19_execute_command_delete_login(self):
        """测试 delete_login 命令"""
        result = self.learner.execute_command('delete_login')
        self.assertTrue(result['success'])

    # ================================================================
    #  安全预检测试
    # ================================================================

    def test_20_is_safe_to_launch(self):
        """测试 launch 操作安全预检"""
        result = self.learner.is_safe_to('launch')
        self.assertIn('safe', result)
        self.assertIn('warnings', result)
        self.assertIn('checks', result)

    def test_21_is_safe_to_save_login_no_browser(self):
        """测试无浏览器时 save_login 安全预检"""
        result = self.learner.is_safe_to('save_login')
        self.assertFalse(result['checks'].get('browser_ready', True))

    # ================================================================
    #  事件系统测试
    # ================================================================

    def test_22_register_event_handler(self):
        """测试注册事件处理器"""
        handler = MagicMock()
        self.learner.register_event_handler('status_changed', handler)
        self.assertIn('status_changed', self.learner._event_handlers)

    def test_23_fire_event(self):
        """测试触发事件"""
        handler = MagicMock()
        self.learner.register_event_handler('completed', handler)
        self.learner._fire_event('completed', {'result': 'success'})
        handler.assert_called_once_with({'result': 'success'})

    def test_24_on_status_changed(self):
        """测试便捷注册状态变更事件"""
        handler = MagicMock()
        result = self.learner.on_status_changed(handler)
        self.assertIs(result, self.learner)

    def test_25_on_completed(self):
        """测试便捷注册完成事件"""
        handler = MagicMock()
        result = self.learner.on_completed(handler)
        self.assertIs(result, self.learner)

    def test_26_on_error(self):
        """测试便捷注册错误事件"""
        handler = MagicMock()
        result = self.learner.on_error(handler)
        self.assertIs(result, self.learner)

    def test_27_on_progress(self):
        """测试便捷注册进度事件"""
        handler = MagicMock()
        result = self.learner.on_progress(handler)
        self.assertIs(result, self.learner)

    # ================================================================
    #  状态查询测试
    # ================================================================

    def test_28_get_full_status(self):
        """测试获取完整系统状态"""
        status = self.learner.get_full_status()
        self.assertIn('status', status)
        self.assertIn('mode', status)
        self.assertIn('browser', status)
        self.assertIn('play', status)
        self.assertIn('login', status)

    def test_29_get_play_status(self):
        """测试获取播放列表状态"""
        self.learner.add_play_url("https://example.com/v1")
        status = self.learner.get_play_status()
        self.assertEqual(status['total'], 1)
        self.assertEqual(status['pending'], 1)

    def test_30_get_browser_status(self):
        """测试获取浏览器状态"""
        status = self.learner.get_browser_status()
        self.assertIn('alive', status)
        self.assertFalse(status['alive'])

    # ================================================================
    #  AI 功能配置测试
    # ================================================================

    def test_31_enable_ai_summary(self):
        """测试启用 AI 总结"""
        result = self.learner.enable_ai_summary(provider="siliconflow")
        self.assertIs(result, self.learner)

    def test_32_disable_ai_summary(self):
        """测试禁用 AI 总结"""
        result = self.learner.disable_ai_summary()
        self.assertIs(result, self.learner)

    def test_33_set_auto_answer(self):
        """测试设置自动答题"""
        result = self.learner.set_auto_answer(True)
        self.assertTrue(result)
        self.assertTrue(self.learner.is_auto_answer_enabled())

    def test_34_set_audio_recording(self):
        """测试设置音频录制"""
        result = self.learner.set_audio_recording_for_playlist(enable=True)
        self.assertIs(result, self.learner)

    # ================================================================
    #  登录状态管理测试
    # ================================================================

    def test_35_check_login_state_no_file(self):
        """测试检查不存在的登录状态文件"""
        result = self.learner.check_login_state()
        self.assertFalse(result['exists'])
        self.assertFalse(result['valid'])

    def test_36_delete_login_state_no_file(self):
        """测试删除不存在的登录状态文件"""
        result = self.learner.delete_login_state()
        self.assertTrue(result['success'])

    def test_37_save_login_state_no_browser(self):
        """测试无浏览器时保存登录状态失败"""
        result = self.learner.save_login_state()
        self.assertFalse(result['success'])

    # ================================================================
    #  属性测试
    # ================================================================

    def test_38_status_property(self):
        """测试 status 属性"""
        self.assertEqual(self.learner.status, "initialized")

    def test_39_result_property(self):
        """测试 result 属性"""
        result = self.learner.result
        self.assertIsInstance(result, dict)
        self.assertIn('status', result)


class TestWebVideoAutoLearnerWait(unittest.TestCase):
    """等待完成测试"""

    def test_01_wait_for_completion_already_stopped(self):
        """测试已停止状态时立即返回"""
        from index import WebVideoAutoLearner
        learner = WebVideoAutoLearner(mode="headless", log_level="WARNING")
        learner._status = "completed"

        result = learner.wait_for_completion(timeout=1.0)
        self.assertTrue(result['completed'])
        self.assertFalse(result['timed_out'])
        self.assertEqual(result['final_status'], 'completed')

    def test_02_wait_for_completion_timeout(self):
        """测试超时等待"""
        from index import WebVideoAutoLearner
        learner = WebVideoAutoLearner(mode="headless", log_level="WARNING")
        learner._status = "running"

        result = learner.wait_for_completion(timeout=0.5, poll_interval=0.1)
        self.assertFalse(result['completed'])
        self.assertTrue(result['timed_out'])


if __name__ == "__main__":
    unittest.main(verbosity=2)
