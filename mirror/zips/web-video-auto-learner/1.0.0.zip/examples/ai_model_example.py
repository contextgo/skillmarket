# -*- coding: utf-8 -*-
"""
AI 模型使用示例
演示如何通过配置文件管理 AI 模型和系统提示词
"""
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.ai_model import AIModelCaller, AIModelConfig, call_ai


def example_basic_usage():
    """基础使用示例"""
    print("=" * 60)
    print("示例 1: 基础使用")
    print("=" * 60)

    # 初始化 AI 调用器（会自动加载或创建配置文件）
    caller = AIModelCaller()

    # 检查配置状态
    status = caller.config.config.get_provider_config()
    print(f"当前提供商: {status.get('name', 'Unknown')}")
    print(f"API Key 已配置: {bool(status.get('api_key'))}")

    # 设置系统提示词
    caller.set_system_prompt('meeting_notes')

    # 调用 AI
    user_prompt = "请总结以下学习内容：\n1. 课程介绍了Python的基础知识\n2. 讲解了变量和数据类型\n3. 演示了条件判断和循环语句"
    result = caller.call(user_prompt)
    print(f"\nAI 回复:\n{result}")


def example_system_prompts():
    """系统提示词管理示例"""
    print("\n" + "=" * 60)
    print("示例 2: 系统提示词管理")
    print("=" * 60)

    config = AIModelConfig()

    # 列出所有提示词
    prompts = config.get_all_prompts()
    print("可用提示词模板:")
    for name, info in prompts.items():
        print(f"  - {name}: {info.get('name', '')}")

    # 添加自定义提示词
    custom_content = """你是一个代码审查助手。请审查以下代码并指出潜在问题。
    输出格式：
    ## 问题列表
    [行号] 问题描述

    ## 建议
    改进建议...
    """
    config.add_system_prompt('code_review', custom_content, '代码审查助手', ['code'])
    print("\n已添加自定义提示词: code_review")

    # 获取特定提示词
    prompt = config.get_system_prompt('meeting_notes')
    print(f"\n会议纪要提示词预览:\n{prompt[:200]}...")


def example_provider_management():
    """提供商管理示例"""
    print("\n" + "=" * 60)
    print("示例 3: 提供商管理")
    print("=" * 60)

    config = AIModelConfig()

    # 设置 API 密钥
    print("设置 API 密钥...")
    config.set_api_key('siliconflow', 'sk-your-key-here')

    # 检查提供商状态
    providers = config.get_enabled_providers()
    print(f"已启用的提供商: {providers}")

    # 更新模型参数
    config.update_model_params('siliconflow', {
        'temperature': 0.5,
        'max_tokens': 2000
    })
    print("已更新 siliconflow 参数")

    # 保存配置
    config.save()
    print("配置已保存")


def example_with_learner():
    """与 WebVideoAutoLearner 集成示例"""
    print("\n" + "=" * 60)
    print("示例 4: 与自动学习器集成")
    print("=" * 60)

    try:
        from index import WebVideoAutoLearner

        learner = WebVideoAutoLearner(mode='headless')

        # 检查 AI 配置状态
        status = learner.get_ai_config_status()
        print(f"AI 配置状态: {status}")

        # 设置 API 密钥
        # learner.set_ai_api_key('siliconflow', 'your-key')

        # 使用预定义模板调用
        result = learner.call_ai_with_prompt_template(
            'summary',
            '这是一段关于机器学习入门的视频转录内容...'
        )
        print(f"\nAI 摘要结果:\n{result}")

    except ImportError as e:
        print(f"导入失败: {e}")


def example_transcribe_and_summarize():
    """转录并总结示例"""
    print("\n" + "=" * 60)
    print("示例 5: 视频转录和 AI 总结")
    print("=" * 60)

    try:
        from index import WebVideoAutoLearner

        learner = WebVideoAutoLearner(mode='headless')

        # 检查 AI 配置
        if not learner.get_ai_config_status().get('ready'):
            print("请先配置 AI API 密钥")
            return

        # 视频路径
        video_path = "recordings/example.mp4"

        if os.path.exists(video_path):
            # 一站式处理
            result = learner.process_and_summarize(
                video_path,
                video_title="Python 基础教程",
                use_local=False
            )
            print(f"处理完成: {result}")
        else:
            print(f"视频文件不存在: {video_path}")

    except ImportError as e:
        print(f"导入失败: {e}")


def main():
    """主函数"""
    print("网络视频 AI 模型使用示例")
    print("=" * 60)
    print("提示: 请先编辑 config/AImodel.yaml 填写 API 密钥")
    print("=" * 60)

    # 基础使用
    example_basic_usage()

    # 提示词管理
    example_system_prompts()

    # 提供商管理
    example_provider_management()

    # 与主程序集成
    example_with_learner()

    # 转录和总结
    example_transcribe_and_summarize()

    print("\n" + "=" * 60)
    print("示例完成！")
    print("=" * 60)


if __name__ == '__main__':
    main()
