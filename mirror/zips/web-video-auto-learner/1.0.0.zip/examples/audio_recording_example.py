# -*- coding: utf-8 -*-
"""
网页音频录制示例

演示如何使用 WebAudioRecorder 捕获网页视频的音频。

用法:
    python audio_recording_example.py
    
    或在 Python 中:
    from examples.audio_recording_example import main
    main()
"""

import time
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.web_audio_recorder import WebAudioRecorder, PageAudioCapture
from src.browser import BrowserManager
from src.logger import setup_logger


def main():
    """主函数"""
    # 初始化日志
    logger = setup_logger("audio_recording_example")
    logger.info("=" * 50)
    logger.info("网页音频录制示例")
    logger.info("=" * 50)

    recorder = None
    browser = None

    try:
        # 初始化浏览器
        browser = BrowserManager(logger)
        # 启动浏览器
        logger.info("启动浏览器...")
        browser.start_browser(
            browser_type="chrome",
            headless=False,
            window_max=True
        )
        
        # 创建页面
        page = browser.get_page()
        logger.info("浏览器已启动")
        
        # 初始化音频录制器
        recorder = WebAudioRecorder(config={
            'output_dir': 'recordings',
            'format': 'webm_opus'
        })
        
        # 注入 JavaScript 代码到页面
        logger.info("注入音频录制脚本...")
        if not recorder.inject(page):
            logger.error("注入失败!")
            return
        
        # 访问视频页面（示例）
        video_url = "https://www.example.com/videoDisplay?coursewareId=test&courseId=test"
        logger.info(f"访问: {video_url}")
        
        # 打开学习网站登录页面（需要先登录）
        browser.navigate_to("https://www.example.com/")
        time.sleep(2)
        
        logger.info("\n" + "=" * 50)
        logger.info("音频录制控制说明:")
        logger.info("  - 自动录制已启动")
        logger.info("  - 录制期间请确保视频正在播放")
        logger.info("  - 5秒后自动停止录制并保存")
        logger.info("=" * 50 + "\n")
        
        # 设置状态变化回调
        def on_status_change(status):
            logger.info(f"[回调] 录制状态: {status}")
        
        recorder.set_on_status_change(on_status_change)
        
        # 开始录制
        result = recorder.start()
        if not result.get('success'):
            logger.error(f"启动录制失败: {result.get('error')}")
            return
        
        logger.info("开始录制音频...")
        
        # 等待一段时间（这里模拟录制5秒）
        for i in range(5):
            time.sleep(1)
            status = recorder.get_status()
            logger.info(f"录制中... ({i+1}/5秒) - 时长: {status.get('duration', 0):.1f}秒")
        
        # 暂停录制测试
        logger.info("暂停录制...")
        recorder.pause()
        time.sleep(1)
        
        logger.info("恢复录制...")
        recorder.resume()
        
        # 继续录制
        time.sleep(2)
        
        # 停止录制
        logger.info("停止录制...")
        result = recorder.stop(save=True)
        
        if result.get('success'):
            logger.info("=" * 50)
            logger.info("录制完成!")
            logger.info(f"  保存路径: {result.get('path', 'N/A')}")
            logger.info(f"  时长: {result.get('duration', 0):.1f}秒")
            logger.info(f"  大小: {result.get('size', 0) / 1024:.1f}KB")
            logger.info(f"  格式: {result.get('mimeType', 'unknown')}")
            logger.info("=" * 50)
        else:
            logger.error(f"录制失败: {result.get('error')}")
        
        # 清理
        recorder.cleanup()
        
    except KeyboardInterrupt:
        logger.info("\n用户中断")
    except Exception as e:
        logger.error(f"发生错误: {e}")
        import traceback
        traceback.print_exc()
        
    finally:
        # 关闭浏览器
        logger.info("关闭浏览器...")
        browser.close()
        logger.info("完成!")


def demo_with_capture():
    """使用 PageAudioCapture 高级封装"""
    logger = setup_logger("audio_capture_demo")
    logger.info("使用 PageAudioCapture 高级封装演示")
    
    browser = BrowserManager(logger)
    
    try:
        browser.start_browser(browser_type="chrome", headless=False)
        page = browser.get_page()
        
        # 创建音频捕获器
        capture = PageAudioCapture(page, config={
            'output_dir': 'recordings',
            'max_duration': 60
        })
        
        # 定义进度回调
        def on_progress(current, total):
            logger.info(f"进度: {current:.1f}/{total:.1f}秒 ({current/total*100:.0f}%)")
        
        # 开始捕获（指定时长）
        logger.info("开始捕获 (30秒)...")
        result = capture.capture(
            duration=30,
            output_path='recordings/demo_capture.webm',
            on_progress=on_progress
        )
        
        if result.get('success'):
            logger.info(f"保存到: {result.get('path')}")
        else:
            logger.error(f"捕获失败: {result.get('error')}")
        
        capture.cleanup()
        
    finally:
        browser.close()


def demo_manual_control():
    """手动控制录制"""
    logger = setup_logger("manual_control")
    logger.info("手动控制录制演示")
    
    browser = BrowserManager(logger)
    
    try:
        browser.start_browser(browser_type="chrome", headless=False)
        page = browser.get_page()
        
        recorder = WebAudioRecorder(config={'output_dir': 'recordings'})
        
        # 注入
        recorder.inject(page)
        
        # 开始录制
        logger.info("按回车开始录制...")
        input()
        
        recorder.start()
        logger.info("录制中... 按回车暂停...")
        input()
        
        recorder.pause()
        logger.info("已暂停，按回车恢复...")
        input()
        
        recorder.resume()
        logger.info("继续录制，按回车停止...")
        input()
        
        result = recorder.stop()
        logger.info(f"结果: {result}")
        
        recorder.cleanup()
        
    finally:
        browser.close()


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='网页音频录制示例')
    parser.add_argument('--mode', choices=['auto', 'capture', 'manual'], 
                       default='auto', help='运行模式')
    args = parser.parse_args()
    
    if args.mode == 'auto':
        main()
    elif args.mode == 'capture':
        demo_with_capture()
    elif args.mode == 'manual':
        demo_manual_control()
