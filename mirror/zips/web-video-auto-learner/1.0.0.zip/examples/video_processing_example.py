# -*- coding: utf-8 -*-
"""
视频录制和 AI 总结示例

功能说明：
1. 录制学习视频
2. 自动转录为文字
3. AI 智能总结，生成会议纪要格式
4. 精准标注每个要点的时间戳

使用前提：
1. 安装 ffmpeg: https://ffmpeg.org/download.html
2. 安装 whisper: pip install openai-whisper
3. 安装 openai: pip install openai
4. 配置 AI API 密钥（见 config/config.yaml）
"""

import sys
import os

# 添加 skill 目录到路径
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = os.path.dirname(SKILL)
for p in [BASE, os.path.join(SKILL, 'src'), SKILL]:
    if p not in sys.path:
        sys.path.insert(0, p)

from index import WebVideoAutoLearner


def example_basic():
    """基础使用：录制视频并生成总结"""
    print("=" * 60)
    print("示例1：基础使用 - 录制视频并生成 AI 总结")
    print("=" * 60)

    # 初始化学习器
    learner = WebVideoAutoLearner(mode='headless')

    # 启用录制功能
    learner.enable_recording()

    # 启用 AI 总结（使用 SiliconFlow API）
    learner.enable_ai_summary(
        api_key='your-api-key-here',  # 替换为你的 API 密钥
        provider='siliconflow'
    )

    print("\n配置完成！")
    print("- 录制功能: 已启用")
    print("- AI 总结: 已启用")
    print("\n运行自动播放，录制将在播放过程中自动进行...")

    # 启动自动播放
    result = learner.run()
    print(f"\n播放完成: {result}")


def example_local_ai():
    """使用本地 AI（Ollama）进行总结"""
    print("=" * 60)
    print("示例2：使用本地 AI（Ollama）生成总结")
    print("=" * 60)

    learner = WebVideoAutoLearner(mode='headless')

    # 配置使用 Ollama 本地模型
    learner.enable_ai_summary(
        provider='ollama'  # 将使用 http://localhost:11434/v1
    )

    print("\n已配置本地 AI 总结（需要 Ollama 运行中）")
    print("提示：确保已启动 Ollama: ollama serve")


def example_batch_process():
    """批量处理已录制的视频"""
    print("=" * 60)
    print("示例3：批量处理已录制的视频")
    print("=" * 60)

    learner = WebVideoAutoLearner(mode='headless')

    # 获取已录制的视频
    recordings = learner.get_recorded_videos()
    print(f"\n找到 {len(recordings)} 个录制视频:")

    for i, rec in enumerate(recordings[:5], 1):  # 只显示前5个
        print(f"  {i}. {rec['name']} ({rec['size'] / 1024 / 1024:.1f} MB)")

    # 获取已生成的总结
    summaries = learner.get_summaries()
    print(f"\n已生成 {len(summaries)} 个总结文件")

    if recordings:
        # 选择第一个视频进行处理
        video_path = recordings[0]['path']
        print(f"\n正在处理: {recordings[0]['name']}")

        result = learner.process_and_summarize(
            video_path,
            video_title="学习视频",
            use_local=False  # 使用云端 API
        )

        if result:
            print("\n处理完成！")
            print(f"转录字数: {len(result.get('transcription', {}).get('text', ''))}")


def example_transcribe_only():
    """仅转录，不生成总结"""
    print("=" * 60)
    print("示例4：仅转录视频为文字")
    print("=" * 60)

    learner = WebVideoAutoLearner(mode='headless')

    # 视频文件路径
    video_path = r"recordings\your_video.mp4"

    if os.path.exists(video_path):
        print(f"\n正在转录: {video_path}")

        # 转录（使用本地 Whisper）
        result = learner.transcribe_video(video_path)

        if result:
            print(f"\n转录完成！")
            print(f"文本长度: {len(result.get('text', ''))} 字符")
            print(f"段落数量: {len(result.get('segments', []))}")

            # 保存转录结果
            import json
            transcript_file = video_path.replace('.mp4', '_transcript.json')
            with open(transcript_file, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print(f"已保存到: {transcript_file}")
    else:
        print(f"\n视频文件不存在: {video_path}")


def example_custom_summary():
    """使用自定义 API 配置"""
    print("=" * 60)
    print("示例5：使用自定义 API 配置")
    print("=" * 60)

    # 手动创建配置
    learner = WebVideoAutoLearner(mode='headless')

    # 配置 AI 总结参数
    learner.enable_ai_summary(
        api_key='sk-your-custom-key',
        provider='openai'  # 或 'siliconflow'
    )

    # 或使用 Ollama
    # learner.enable_ai_summary(provider='ollama')

    print("\n已配置自定义 API")
    print("支持的提供商:")
    print("  - openai: OpenAI GPT 系列")
    print("  - siliconflow: SiliconFlow (支持多种开源模型)")
    print("  - ollama: 本地 Ollama 模型")


if __name__ == '__main__':
    print("""
╔═══════════════════════════════════════════════════════════╗
║        网络视频 - 视频录制和 AI 总结功能示例              ║
╠═══════════════════════════════════════════════════════════╣
║  功能：                                                    ║
║    1. 自动录制学习视频                                     ║
║    2. 音频转文字（Whisper）                                ║
║    3. AI 智能总结，生成会议纪要                             ║
║    4. 精准标注每个要点的时间戳                              ║
║                                                           ║
║  前置要求：                                                ║
║    - ffmpeg (用于录制)                                     ║
║    - whisper (用于转录): pip install openai-whisper        ║
║    - openai (用于API调用): pip install openai             ║
║    - AI API 密钥 (见 config/config.yaml)                   ║
╚═══════════════════════════════════════════════════════════╝
    """)

    # 选择要运行的示例
    examples = {
        '1': ('基础使用', example_basic),
        '2': ('本地 AI', example_local_ai),
        '3': ('批量处理', example_batch_process),
        '4': ('仅转录', example_transcribe_only),
        '5': ('自定义 API', example_custom_summary),
    }

    print("\n请选择要运行的示例 (1-5):")
    for key, (name, _) in examples.items():
        print(f"  {key}. {name}")

    choice = input("\n选择: ").strip() or '1'

    if choice in examples:
        name, func = examples[choice]
        try:
            func()
        except Exception as e:
            print(f"\n错误: {e}")
            import traceback
            traceback.print_exc()
    else:
        print("无效选择")
