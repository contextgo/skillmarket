# 媒体进度守护 - Chrome 扩展

自动记录视频/音频播放进度，浏览器崩溃后无缝恢复。

## 功能特性

- **自动保存**：每 10 秒自动记录所有 video/audio 元素的播放进度和元数据
- **崩溃恢复**：浏览器意外关闭或崩溃后，重新打开页面自动恢复到上次播放位置
- **双重存储**：chrome.storage.local + localStorage 双重写入，防止数据丢失
- **文本备份**：额外的 JSON 文本备份，主数据损坏时可一键恢复
- **智能恢复**：自动检测媒体元素就绪状态，恢复进度、音量、播放速率、播放状态
- **自动播放**：恢复后尝试自动继续播放；若被浏览器阻止则显示点击恢复覆盖层
- **动态媒体**：监听 DOM 变化，支持 SPA 等动态加载的媒体元素
- **定期清理**：自动清理 7 天以上的过期数据
- **管理面板**：Popup 界面查看所有保存的播放进度，支持手动清除和备份恢复

## 安装方法

1. 打开 Chrome，访问 `chrome://extensions/`
2. 开启右上角「开发者模式」
3. 点击「加载已解压的扩展程序」
4. 选择 `media-progress-saver` 文件夹

## 文件结构

```
media-progress-saver/
├── manifest.json      # 扩展配置
├── content.js         # 内容脚本：媒体监控与恢复
├── background.js      # 后台服务：持久化存储管理
├── popup.html         # 管理面板界面
├── popup.js           # 管理面板逻辑
├── icons/             # 扩展图标
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

## 技术架构

### 数据流

```
页面媒体元素
    │
    ├── 每10秒扫描 ──────▶ content.js ──────▶ background.js
    │                      collectMediaInfo()   saveProgress()
    │                                           ├── chrome.storage.local
    │                                           └── 文本备份
    │
    └── 页面加载 ────────▶ content.js ──────▶ background.js
                           restoreProgress()    getProgress()
                                │
                                ▼
                           设置 currentTime
                           恢复 volume/muted/playbackRate
                           尝试 el.play()
                           (被阻止则显示点击覆盖层)
```

### 媒体元素唯一标识

使用 `页面URL + 标签名 + 元素ID + src + className` 的组合哈希作为唯一标识，
确保同一页面同一媒体元素在不同会话中能被正确匹配。

### 错误处理

- **存储写入失败**：自动清理过期数据后重试
- **存储读取失败**：从文本备份或 localStorage 备份恢复
- **自动播放被阻止**：显示点击恢复覆盖层，10秒后自动消失
- **媒体未就绪**：等待 loadedmetadata 事件，最多5秒超时
- **单个元素失败**：不影响其他元素的保存/恢复

### 保存触发时机

| 时机 | 方式 | 说明 |
|------|------|------|
| 每10秒 | setInterval | 定期自动保存 |
| timeupdate | 防抖5秒 | 播放中实时保存 |
| beforeunload | 同步写入localStorage | 页面关闭前紧急保存 |
| visibilitychange | chrome.storage | 切换标签页时保存 |
