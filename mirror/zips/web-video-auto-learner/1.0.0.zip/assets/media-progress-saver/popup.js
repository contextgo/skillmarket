/**
 * 媒体进度守护 - Popup Script
 */

'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const listContainer = document.getElementById('listContainer');
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const countText = document.getElementById('countText');
  const btnRefresh = document.getElementById('btnRefresh');
  const btnRestore = document.getElementById('btnRestore');
  const btnClearAll = document.getElementById('btnClearAll');
  const toastEl = document.getElementById('toast');

  // ================================================================
  //  工具
  // ================================================================

  function showToast(msg, duration = 2000) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    setTimeout(() => toastEl.classList.remove('show'), duration);
  }

  function formatTime(seconds) {
    if (!seconds || !isFinite(seconds)) return '--:--';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    return `${m}:${String(s).padStart(2, '0')}`;
  }

  function formatTimestamp(ts) {
    if (!ts) return '';
    const d = new Date(ts);
    const now = new Date();
    const isToday = d.toDateString() === now.toDateString();
    const time = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    if (isToday) return `今天 ${time}`;
    return `${d.getMonth() + 1}/${d.getDate()} ${time}`;
  }

  function truncateUrl(url, maxLen = 50) {
    if (!url) return '';
    try {
      const u = new URL(url);
      const display = u.hostname + u.pathname;
      return display.length > maxLen ? display.slice(0, maxLen) + '...' : display;
    } catch (e) {
      return url.length > maxLen ? url.slice(0, maxLen) + '...' : url;
    }
  }

  // ================================================================
  //  加载数据
  // ================================================================

  async function loadSummary() {
    try {
      // 检查 background 是否存活
      try {
        await chrome.runtime.sendMessage({ type: 'PING' });
        statusDot.classList.remove('inactive');
        statusText.textContent = '运行中';
      } catch (e) {
        statusDot.classList.add('inactive');
        statusText.textContent = '未连接';
      }

      const response = await chrome.runtime.sendMessage({ type: 'GET_ALL_SUMMARY' });
      const data = response?.data || [];
      countText.textContent = `${data.length} 条记录`;
      renderList(data);
    } catch (e) {
      console.warn('加载失败:', e);
      statusDot.classList.add('inactive');
      statusText.textContent = '加载失败';
    }
  }

  function renderList(items) {
    if (!items || items.length === 0) {
      listContainer.innerHTML = `
        <div class="empty">
          <div class="emoji">🎵</div>
          <div>暂无播放记录</div>
          <div style="margin-top:4px;font-size:11px;">播放视频或音频后自动保存进度</div>
        </div>
      `;
      return;
    }

    listContainer.innerHTML = items.map(item => {
      const tagClass = item.tag === 'audio' ? 'audio' : '';
      const tagText = item.tag === 'audio' ? 'AUDIO' : 'VIDEO';
      const percent = item.percent || 0;
      const isComplete = percent >= 99;
      const fillClass = isComplete ? 'complete' : '';

      let badge = '';
      if (item.restored) {
        badge = '<span class="card-badge restored">已恢复</span>';
      } else if (!item.paused) {
        badge = '<span class="card-badge playing">播放中</span>';
      } else {
        badge = '<span class="card-badge paused">已暂停</span>';
      }

      const title = item.title || truncateUrl(item.src, 40) || '未知媒体';

      return `
        <div class="card" data-id="${item.id}">
          <div class="card-header">
            <span class="tag ${tagClass}">${tagText}</span>
            <span class="card-title" title="${escapeHtml(title)}">${escapeHtml(title)}</span>
            ${badge}
          </div>
          <div class="progress-wrap">
            <div class="progress-bar">
              <div class="progress-fill ${fillClass}" style="width: ${Math.min(percent, 100)}%"></div>
            </div>
            <div class="progress-text">
              <span>${formatTime(item.currentTime)} / ${formatTime(item.duration)}</span>
              <span>${percent.toFixed(1)}%</span>
            </div>
          </div>
          <div class="card-url" title="${escapeHtml(item.pageUrl)}">${truncateUrl(item.pageUrl)}</div>
          <div class="card-time">保存于 ${formatTimestamp(item.savedAt)}</div>
        </div>
      `;
    }).join('');
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ================================================================
  //  按钮事件
  // ================================================================

  btnRefresh.addEventListener('click', () => {
    loadSummary();
    showToast('已刷新');
  });

  btnRestore.addEventListener('click', async () => {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'RESTORE_BACKUP' });
      if (response?.success) {
        showToast('备份恢复成功');
        loadSummary();
      } else {
        showToast('备份恢复失败或无备份数据');
      }
    } catch (e) {
      showToast('操作失败');
    }
  });

  btnClearAll.addEventListener('click', async () => {
    if (!confirm('确定清除所有播放进度数据？此操作不可撤销。')) return;
    try {
      await chrome.runtime.sendMessage({ type: 'CLEAR_ALL' });
      showToast('已清除所有数据');
      loadSummary();
    } catch (e) {
      showToast('清除失败');
    }
  });

  // 初始加载
  loadSummary();
});
