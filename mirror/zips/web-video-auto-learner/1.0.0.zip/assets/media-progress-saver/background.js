/**
 * 媒体进度守护 - Background Service Worker
 * 
 * 功能：
 * 1. 管理媒体进度的持久化存储（chrome.storage.local）
 * 2. 处理来自 content script 的保存/读取/清理请求
 * 3. 定期清理过期数据
 * 4. 双重写入策略：chrome.storage + 文本备份，防止数据丢失
 * 5. 浏览器启动时通知所有标签页检查恢复
 */

'use strict';

const STORAGE_KEY = 'media_progress_data';
const MAX_AGE_MS = 7 * 24 * 3600000; // 数据最多保留7天
const CLEANUP_INTERVAL_MS = 30 * 60 * 1000; // 30分钟清理一次过期数据
const MAX_ENTRIES_PER_PAGE = 10; // 每个页面最多保存10条记录

// ================================================================
//  存储操作
// ================================================================

/** 读取所有存储的进度数据 */
async function getAllData() {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    return result[STORAGE_KEY] || {};
  } catch (e) {
    console.warn('[媒体进度守护-Background] 读取存储失败:', e);
    return {};
  }
}

/** 写入所有进度数据 */
async function setAllData(data) {
  try {
    await chrome.storage.local.set({ [STORAGE_KEY]: data });
  } catch (e) {
    console.warn('[媒体进度守护-Background] 写入存储失败:', e);
    // 尝试清理后重试（可能是配额超限）
    try {
      await cleanupExpired();
      await chrome.storage.local.set({ [STORAGE_KEY]: data });
    } catch (retryErr) {
      console.error('[媒体进度守护-Background] 重试写入仍然失败:', retryErr);
    }
  }
}

/** 保存来自 content script 的进度数据 */
async function saveProgress(mediaList, pageUrl) {
  if (!mediaList || !Array.isArray(mediaList) || mediaList.length === 0) return;

  try {
    const allData = await getAllData();
    const pageKey = normalizeUrl(pageUrl);

    // 合并数据：更新已有记录，添加新记录
    const existing = allData[pageKey] || [];
    const updatedMap = new Map();

    // 先放入已有数据
    for (const item of existing) {
      if (item && item.id) {
        updatedMap.set(item.id, item);
      }
    }

    // 用新数据覆盖
    for (const item of mediaList) {
      if (item && item.id) {
        updatedMap.set(item.id, item);
      }
    }

    // 限制每个页面的记录数（保留最新的）
    let pageEntries = Array.from(updatedMap.values());
    pageEntries.sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0));
    if (pageEntries.length > MAX_ENTRIES_PER_PAGE) {
      pageEntries = pageEntries.slice(0, MAX_ENTRIES_PER_PAGE);
    }

    allData[pageKey] = pageEntries;
    await setAllData(allData);

    // 双重写入：同时保存一份纯文本备份
    await saveTextBackup(allData);
  } catch (e) {
    console.warn('[媒体进度守护-Background] 保存进度失败:', e);
  }
}

/** 获取指定页面的进度数据 */
async function getProgress(pageUrl) {
  try {
    const allData = await getAllData();
    const pageKey = normalizeUrl(pageUrl);
    const data = allData[pageKey] || [];

    // 过滤掉过期数据
    const now = Date.now();
    const valid = data.filter(d => (now - (d.savedAt || 0)) < MAX_AGE_MS);

    return { data: valid };
  } catch (e) {
    console.warn('[媒体进度守护-Background] 获取进度失败:', e);
    return { data: [] };
  }
}

/** 标记页面数据已恢复 */
async function markRestored(pageUrl) {
  try {
    const allData = await getAllData();
    const pageKey = normalizeUrl(pageUrl);
    if (allData[pageKey]) {
      // 保留数据但标记为已恢复（不立即删除，作为备份）
      for (const item of allData[pageKey]) {
        item.restored = true;
      }
      await setAllData(allData);
    }
  } catch (e) {
    console.warn('[媒体进度守护-Background] 标记恢复失败:', e);
  }
}

/** 清理过期数据 */
async function cleanupExpired() {
  try {
    const allData = await getAllData();
    const now = Date.now();
    let changed = false;

    for (const pageKey of Object.keys(allData)) {
      const items = allData[pageKey];
      if (!Array.isArray(items)) {
        delete allData[pageKey];
        changed = true;
        continue;
      }

      // 过滤掉过期项
      const valid = items.filter(d => (now - (d.savedAt || 0)) < MAX_AGE_MS);
      if (valid.length === 0) {
        delete allData[pageKey];
        changed = true;
      } else if (valid.length !== items.length) {
        allData[pageKey] = valid;
        changed = true;
      }
    }

    if (changed) {
      await setAllData(allData);
      console.info('[媒体进度守护-Background] 过期数据清理完成');
    }
  } catch (e) {
    console.warn('[媒体进度守护-Background] 清理过期数据失败:', e);
  }
}

/** 清除所有数据 */
async function clearAllData() {
  try {
    await chrome.storage.local.remove(STORAGE_KEY);
    await chrome.storage.local.remove(`${STORAGE_KEY}_backup`);
    console.info('[媒体进度守护-Background] 所有数据已清除');
  } catch (e) {
    console.warn('[媒体进度守护-Background] 清除数据失败:', e);
  }
}

/** 清除指定页面的数据 */
async function clearPageData(pageUrl) {
  try {
    const allData = await getAllData();
    const pageKey = normalizeUrl(pageUrl);
    delete allData[pageKey];
    await setAllData(allData);
  } catch (e) {
    console.warn('[媒体进度守护-Background] 清除页面数据失败:', e);
  }
}

// ================================================================
//  双重写入：文本备份
// ================================================================

/** 保存纯文本备份（防止 chrome.storage 损坏） */
async function saveTextBackup(data) {
  try {
    const backupKey = `${STORAGE_KEY}_backup`;
    const jsonStr = JSON.stringify(data);
    await chrome.storage.local.set({ [backupKey]: jsonStr });
  } catch (e) {
    // 备份失败不阻塞主流程
    console.debug('[媒体进度守护-Background] 文本备份保存失败:', e);
  }
}

/** 从文本备份恢复数据（当主数据损坏时） */
async function restoreFromTextBackup() {
  try {
    const backupKey = `${STORAGE_KEY}_backup`;
    const result = await chrome.storage.local.get(backupKey);
    const jsonStr = result[backupKey];
    if (jsonStr && typeof jsonStr === 'string') {
      const data = JSON.parse(jsonStr);
      await setAllData(data);
      console.info('[媒体进度守护-Background] 从文本备份恢复成功');
      return true;
    }
  } catch (e) {
    console.warn('[媒体进度守护-Background] 从文本备份恢复失败:', e);
  }
  return false;
}

// ================================================================
//  URL 规范化
// ================================================================

/** 规范化 URL，去除 hash 和查询参数中的跟踪参数 */
function normalizeUrl(url) {
  try {
    const u = new URL(url);
    // 保留 origin + pathname，去除 hash
    return `${u.origin}${u.pathname}`;
  } catch (e) {
    return url;
  }
}

// ================================================================
//  消息处理
// ================================================================

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handle = async () => {
    try {
      switch (msg.type) {
        case 'SAVE_PROGRESS':
          await saveProgress(msg.data, msg.pageUrl);
          return { success: true };

        case 'GET_PROGRESS':
          return await getProgress(msg.pageUrl);

        case 'MARK_RESTORED':
          await markRestored(msg.pageUrl);
          return { success: true };

        case 'CLEAR_ALL':
          await clearAllData();
          return { success: true };

        case 'CLEAR_PAGE':
          await clearPageData(msg.pageUrl);
          return { success: true };

        case 'GET_ALL_SUMMARY':
          return await getAllSummary();

        case 'RESTORE_BACKUP':
          const restored = await restoreFromTextBackup();
          return { success: restored };

        case 'PING':
          return { alive: true };

        default:
          return { error: 'Unknown message type' };
      }
    } catch (e) {
      console.error('[媒体进度守护-Background] 消息处理异常:', e);
      return { error: e.message };
    }
  };

  // 异步处理
  handle().then(sendResponse);
  return true; // 保持消息通道开放，等待异步响应
});

/** 获取所有数据的摘要（用于 popup 展示） */
async function getAllSummary() {
  try {
    const allData = await getAllData();
    const now = Date.now();
    const summary = [];

    for (const [pageKey, items] of Object.entries(allData)) {
      if (!Array.isArray(items)) continue;
      for (const item of items) {
        // 过滤过期数据
        if ((now - (item.savedAt || 0)) > MAX_AGE_MS) continue;
        summary.push({
          id: item.id,
          tag: item.tag,
          title: item.title || item.pageTitle || '',
          src: item.src || '',
          currentTime: item.currentTime || 0,
          duration: item.duration || 0,
          percent: item.percent || 0,
          paused: item.paused,
          restored: item.restored || false,
          savedAt: item.savedAt || 0,
          pageUrl: item.pageUrl || pageKey,
        });
      }
    }

    // 按保存时间排序（最新在前）
    summary.sort((a, b) => b.savedAt - a.savedAt);
    return { data: summary };
  } catch (e) {
    return { data: [], error: e.message };
  }
}

// ================================================================
//  浏览器启动时通知标签页
// ================================================================

chrome.runtime.onInstalled.addListener((details) => {
  console.info('[媒体进度守护-Background] 扩展已安装/更新:', details.reason);
});

// 浏览器启动时触发恢复检查
chrome.runtime.onStartup.addListener(async () => {
  console.info('[媒体进度守护-Background] 浏览器启动，检查恢复数据...');
  try {
    // 检查主数据是否可用，不可用则从备份恢复
    const allData = await getAllData();
    if (!allData || Object.keys(allData).length === 0) {
      await restoreFromTextBackup();
    }

    // 通知所有已打开的标签页检查恢复
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (tab.url && tab.url.startsWith('http')) {
        try {
          await chrome.tabs.sendMessage(tab.id, { type: 'FORCE_RESTORE' });
        } catch (e) {
          // 标签页可能没有 content script，忽略
        }
      }
    }
  } catch (e) {
    console.warn('[媒体进度守护-Background] 启动恢复检查失败:', e);
  }
});

// ================================================================
//  定期清理
// ================================================================

// 使用 chrome.alarms 实现定期清理（Service Worker 可能被杀，alarm 更可靠）
chrome.alarms.create('cleanup', { periodInMinutes: 30 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'cleanup') {
    cleanupExpired();
  }
});
