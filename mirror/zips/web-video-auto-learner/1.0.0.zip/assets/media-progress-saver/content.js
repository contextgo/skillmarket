/**
 * 媒体进度守护 - Content Script
 * 
 * 功能：
 * 1. 每10秒自动扫描页面中所有 video/audio 元素
 * 2. 记录播放进度和元数据，发送给 background 持久化存储
 * 3. 页面加载时检查是否有可恢复的播放进度，自动恢复
 * 4. 健壮的错误处理，防止数据丢失
 */

(function () {
  'use strict';

  const SAVE_INTERVAL_MS = 10000; // 10秒保存一次
  const RECOVERY_DELAY_MS = 1500; // 页面加载后等待1.5秒再恢复（确保媒体元素已就绪）
  const MIN_PROGRESS_THRESHOLD = 1; // 最小进度阈值（秒），低于此值不保存
  const STORAGE_KEY = 'media_progress_data';

  let saveTimer = null;
  let isRestoring = false; // 恢复过程中暂停自动保存，避免覆盖

  // ================================================================
  //  工具函数
  // ================================================================

  /** 生成媒体元素的唯一标识符（基于页面URL + 元素属性） */
  function getMediaId(el) {
    try {
      const src = el.currentSrc || el.src || '';
      const id = el.id || '';
      const className = (typeof el.className === 'string') ? el.className : '';
      const tag = el.tagName.toLowerCase();
      // 使用 URL + 标签 + id + src 组合作为唯一标识
      const raw = `${location.href}|${tag}|${id}|${src}|${className}`;
      // 简单哈希，避免 key 过长
      let hash = 0;
      for (let i = 0; i < raw.length; i++) {
        const chr = raw.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0; // 转为32位整数
      }
      return `media_${Math.abs(hash).toString(36)}`;
    } catch (e) {
      return `media_fallback_${Date.now()}`;
    }
  }

  /** 收集单个媒体元素的播放状态和元数据 */
  function collectMediaInfo(el) {
    try {
      const info = {
        id: getMediaId(el),
        tag: el.tagName.toLowerCase(),
        // 播放进度
        currentTime: el.currentTime || 0,
        duration: el.duration || 0,
        paused: el.paused,
        ended: el.ended,
        volume: el.volume,
        muted: el.muted,
        playbackRate: el.playbackRate || 1,
        // 元数据
        src: el.currentSrc || el.src || '',
        title: extractTitle(el),
        // 上下文
        pageUrl: location.href,
        pageTitle: document.title || '',
        // 时间戳
        savedAt: Date.now(),
        // 恢复标记
        restored: false,
      };

      // 计算播放百分比
      if (info.duration > 0 && isFinite(info.duration)) {
        info.percent = Math.round((info.currentTime / info.duration) * 1000) / 10;
      } else {
        info.percent = 0;
      }

      return info;
    } catch (e) {
      console.warn('[媒体进度守护] 收集媒体信息失败:', e);
      return null;
    }
  }

  /** 尝试从元素或页面提取媒体标题 */
  function extractTitle(el) {
    try {
      // 1. title 属性
      if (el.title) return el.title;
      // 2. aria-label
      if (el.getAttribute('aria-label')) return el.getAttribute('aria-label');
      // 3. 紧邻的 <figcaption> 或 label
      const parent = el.closest('figure');
      if (parent) {
        const caption = parent.querySelector('figcaption');
        if (caption) return caption.textContent.trim().slice(0, 100);
      }
      // 4. 页面 title
      return document.title || '';
    } catch (e) {
      return '';
    }
  }

  /** 判断媒体元素是否值得保存（有有效进度） */
  function isWorthSaving(info) {
    if (!info) return false;
    // 未播放过的不保存
    if (info.currentTime < MIN_PROGRESS_THRESHOLD) return false;
    // 已结束的不保存（无需恢复）
    if (info.ended) return false;
    // duration 无效的不保存
    if (!isFinite(info.duration) || info.duration <= 0) return false;
    return true;
  }

  /** 安全地向 background 发送消息 */
  function sendMessage(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (response) => {
          if (chrome.runtime.lastError) {
            console.warn('[媒体进度守护] 消息发送失败:', chrome.runtime.lastError.message);
            resolve(null);
          } else {
            resolve(response);
          }
        });
      } catch (e) {
        console.warn('[媒体进度守护] 消息发送异常:', e);
        resolve(null);
      }
    });
  }

  // ================================================================
  //  扫描与保存
  // ================================================================

  /** 扫描页面中所有媒体元素并保存进度 */
  async function scanAndSave() {
    if (isRestoring) return; // 恢复过程中不保存

    try {
      const elements = document.querySelectorAll('video, audio');
      if (!elements || elements.length === 0) return;

      const mediaList = [];
      for (const el of elements) {
        try {
          const info = collectMediaInfo(el);
          if (info && isWorthSaving(info)) {
            mediaList.push(info);
          }
        } catch (e) {
          // 单个元素收集失败不影响其他元素
          console.warn('[媒体进度守护] 单个媒体元素收集失败:', e);
        }
      }

      if (mediaList.length > 0) {
        await sendMessage({
          type: 'SAVE_PROGRESS',
          data: mediaList,
          pageUrl: location.href,
        });
      }
    } catch (e) {
      console.warn('[媒体进度守护] 扫描保存失败:', e);
    }
  }

  // ================================================================
  //  恢复播放进度
  // ================================================================

  /** 页面加载时恢复播放进度 */
  async function restoreProgress() {
    isRestoring = true;
    try {
      const response = await sendMessage({
        type: 'GET_PROGRESS',
        pageUrl: location.href,
      });

      if (!response || !response.data || response.data.length === 0) {
        isRestoring = false;
        return;
      }

      const savedData = response.data;
      const elements = document.querySelectorAll('video, audio');

      for (const el of elements) {
        try {
          const mediaId = getMediaId(el);
          const match = savedData.find(d => d.id === mediaId);
          if (!match) continue;

          // 检查是否值得恢复
          if (match.currentTime < MIN_PROGRESS_THRESHOLD) continue;
          if (match.ended) continue;

          // 等待媒体元素准备就绪
          await waitForMediaReady(el);

          // 设置播放进度
          el.currentTime = match.currentTime;

          // 恢复其他属性
          if (match.volume !== undefined) el.volume = match.volume;
          if (match.muted !== undefined) el.muted = match.muted;
          if (match.playbackRate !== undefined) el.playbackRate = match.playbackRate;

          // 如果之前是播放状态，尝试继续播放
          if (!match.paused) {
            try {
              await el.play();
            } catch (playErr) {
              // 浏览器可能阻止自动播放，需要用户交互
              console.info('[媒体进度守护] 自动播放被阻止，需要用户交互:', playErr.message);
              addPlayOverlay(el, match.currentTime, match.percent);
            }
          }

          console.info(
            `[媒体进度守护] 已恢复: ${match.tag} → ${match.currentTime.toFixed(1)}s / ${match.duration.toFixed(1)}s (${match.percent}%)`
          );

          // 标记已恢复，避免重复恢复
          match.restored = true;
        } catch (e) {
          console.warn('[媒体进度守护] 恢复单个媒体失败:', e);
        }
      }

      // 通知 background 清理已恢复的过期数据
      await sendMessage({ type: 'MARK_RESTORED', pageUrl: location.href });
    } catch (e) {
      console.warn('[媒体进度守护] 恢复进度失败:', e);
    } finally {
      isRestoring = false;
    }
  }

  /** 等待媒体元素准备就绪（loadedmetadata） */
  function waitForMediaReady(el) {
    return new Promise((resolve) => {
      try {
        if (el.readyState >= 1) { // HAVE_METADATA
          resolve();
          return;
        }
        const onReady = () => {
          el.removeEventListener('loadedmetadata', onReady);
          clearTimeout(timeout);
          resolve();
        };
        el.addEventListener('loadedmetadata', onReady);
        // 最多等待5秒
        const timeout = setTimeout(() => {
          el.removeEventListener('loadedmetadata', onReady);
          resolve(); // 超时也继续，不阻塞
        }, 5000);
      } catch (e) {
        resolve();
      }
    });
  }

  /** 当自动播放被阻止时，添加一个点击恢复的覆盖层 */
  function addPlayOverlay(el, currentTime, percent) {
    try {
      // 避免重复添加
      if (el.parentElement.querySelector('.media-progress-overlay')) return;

      const overlay = document.createElement('div');
      overlay.className = 'media-progress-overlay';
      overlay.innerHTML = `
        <div style="
          position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
          background: rgba(0,0,0,0.8); color: #fff; padding: 12px 24px;
          border-radius: 8px; cursor: pointer; z-index: 999999;
          font-size: 14px; font-family: system-ui, sans-serif;
          backdrop-filter: blur(4px); border: 1px solid rgba(255,255,255,0.2);
        ">
          ▶ 点击恢复播放 (${currentTime.toFixed(0)}s / ${percent}%)
        </div>
      `;
      overlay.style.cssText = 'position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 999998;';

      // 确保父元素有定位
      const parent = el.parentElement;
      if (getComputedStyle(parent).position === 'static') {
        parent.style.position = 'relative';
      }

      overlay.addEventListener('click', async () => {
        try {
          await el.play();
          overlay.remove();
        } catch (e) {
          console.warn('[媒体进度守护] 点击恢复播放失败:', e);
        }
      });

      parent.appendChild(overlay);

      // 10秒后自动移除覆盖层
      setTimeout(() => {
        if (overlay.parentElement) overlay.remove();
      }, 10000);
    } catch (e) {
      // 覆盖层创建失败不影响功能
    }
  }

  // ================================================================
  //  事件监听
  // ================================================================

  /** 监听媒体元素事件，关键节点立即保存 */
  function setupMediaEventListeners() {
    try {
      // 使用事件委托，监听所有媒体元素
      document.addEventListener('timeupdate', debounce(() => {
        // timeupdate 触发频率很高，使用防抖
        scanAndSave();
      }, 5000), true); // 5秒防抖，不超过10秒保存间隔

      // 页面卸载前立即保存
      window.addEventListener('beforeunload', () => {
        // 同步保存（使用 localStorage 作为备份）
        saveToLocalBackup();
      });

      // 页面可见性变化时保存（切换标签页、最小化等）
      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          scanAndSave();
        }
      });
    } catch (e) {
      console.warn('[媒体进度守护] 事件监听设置失败:', e);
    }
  }

  /** 防抖函数 */
  function debounce(fn, delay) {
    let timer = null;
    return function (...args) {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => {
        fn.apply(this, args);
        timer = null;
      }, delay);
    };
  }

  /** 保存到 localStorage 作为备份（beforeunload 时同步写入） */
  function saveToLocalBackup() {
    try {
      const elements = document.querySelectorAll('video, audio');
      const backup = [];
      for (const el of elements) {
        const info = collectMediaInfo(el);
        if (info && isWorthSaving(info)) {
          backup.push(info);
        }
      }
      if (backup.length > 0) {
        localStorage.setItem(`${STORAGE_KEY}_backup`, JSON.stringify(backup));
      }
    } catch (e) {
      // localStorage 可能不可用（隐私模式等）
    }
  }

  /** 从 localStorage 备份恢复（仅在 chrome.storage 恢复失败时使用） */
  function restoreFromLocalBackup() {
    try {
      const raw = localStorage.getItem(`${STORAGE_KEY}_backup`);
      if (!raw) return null;
      const data = JSON.parse(raw);
      // 检查备份数据时效性（超过1小时的备份不使用）
      const now = Date.now();
      const valid = data.filter(d => (now - d.savedAt) < 3600000);
      return valid.length > 0 ? valid : null;
    } catch (e) {
      return null;
    }
  }

  // ================================================================
  //  监听来自 background 的消息
  // ================================================================

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    try {
      if (msg.type === 'QUERY_CURRENT_PROGRESS') {
        // background 询问当前页面的播放进度
        const elements = document.querySelectorAll('video, audio');
        const mediaList = [];
        for (const el of elements) {
          const info = collectMediaInfo(el);
          if (info) mediaList.push(info);
        }
        sendResponse({ data: mediaList });
      } else if (msg.type === 'FORCE_RESTORE') {
        // 强制恢复
        restoreProgress().then(() => sendResponse({ success: true }));
        return true; // 异步响应
      }
    } catch (e) {
      sendResponse({ error: e.message });
    }
  });

  // ================================================================
  //  启动
  // ================================================================

  function init() {
    console.info('[媒体进度守护] 扩展已加载');

    // 1. 启动定时保存
    saveTimer = setInterval(scanAndSave, SAVE_INTERVAL_MS);

    // 2. 设置事件监听
    setupMediaEventListeners();

    // 3. 延迟恢复播放进度（等待页面媒体元素加载）
    setTimeout(async () => {
      await restoreProgress();

      // 如果 chrome.storage 恢复失败，尝试 localStorage 备份
      const elements = document.querySelectorAll('video, audio');
      const hasActiveMedia = Array.from(elements).some(
        el => el.currentTime > MIN_PROGRESS_THRESHOLD
      );
      if (!hasActiveMedia) {
        const backupData = restoreFromLocalBackup();
        if (backupData && backupData.length > 0) {
          console.info('[媒体进度守护] 从 localStorage 备份恢复');
          for (const el of elements) {
            const mediaId = getMediaId(el);
            const match = backupData.find(d => d.id === mediaId);
            if (match && match.currentTime >= MIN_PROGRESS_THRESHOLD) {
              try {
                el.currentTime = match.currentTime;
                if (!match.paused) {
                  el.play().catch(() => {});
                }
              } catch (e) {
                // 忽略恢复失败
              }
            }
          }
        }
      }
    }, RECOVERY_DELAY_MS);

    // 4. 监听 DOM 变化，处理动态加载的媒体元素
    observeDynamicMedia();
  }

  /** 监听动态添加的媒体元素 */
  function observeDynamicMedia() {
    try {
      const observer = new MutationObserver((mutations) => {
        let hasNewMedia = false;
        for (const mutation of mutations) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType !== Node.ELEMENT_NODE) continue;
            if (node.tagName === 'VIDEO' || node.tagName === 'AUDIO') {
              hasNewMedia = true;
              break;
            }
            // 检查子元素
            if (node.querySelector && (node.querySelector('video') || node.querySelector('audio'))) {
              hasNewMedia = true;
              break;
            }
          }
          if (hasNewMedia) break;
        }
        if (hasNewMedia) {
          // 新媒体元素出现，尝试恢复
          setTimeout(restoreProgress, 500);
        }
      });

      observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true,
      });
    } catch (e) {
      console.warn('[媒体进度守护] DOM 监听设置失败:', e);
    }
  }

  // 页面就绪后启动
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
