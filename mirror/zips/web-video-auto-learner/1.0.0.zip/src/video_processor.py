# -*- coding: utf-8 -*-
"""
视频处理集成模块 - 整合录制、转录、AI总结
"""
import os
import json
import logging
import time
from pathlib import Path
from datetime import datetime
from urllib.parse import urlparse, parse_qs


class VideoProcessor:
    """视频处理器，集成录制、转录、AI总结功能"""

    def __init__(self, config=None):
        self.logger = logging.getLogger(__name__)
        self.config = config or {}

        # 创建输出目录
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.recordings_dir = os.path.join(base_dir, self.config.get('recording', {}).get('output_dir', 'recordings'))
        self.summaries_dir = os.path.join(base_dir, 'summaries')
        self.transcripts_dir = os.path.join(base_dir, 'transcripts')

        Path(self.recordings_dir).mkdir(parents=True, exist_ok=True)
        Path(self.summaries_dir).mkdir(parents=True, exist_ok=True)
        Path(self.transcripts_dir).mkdir(parents=True, exist_ok=True)

        # 初始化各模块
        self._init_modules()

    def _init_modules(self):
        """初始化各个处理模块"""
        # 视频录制器
        recording_config = self.config.get('recording', {})
        if recording_config.get('enabled', False):
            try:
                from .video_recorder import VideoRecorder
                self.recorder = VideoRecorder(self.config)
                self.logger.info("[处理] 视频录制模块已就绪")
            except ImportError as e:
                self.logger.warning(f"[处理] 无法导入视频录制模块: {e}")
                self.recorder = None
        else:
            self.recorder = None

        # 音频转录器
        try:
            from .audio_transcriber import AudioTranscriber
            self.transcriber = AudioTranscriber(self.config)
            self.logger.info("[处理] 音频转录模块已就绪")
        except ImportError as e:
            self.logger.warning(f"[处理] 无法导入音频转录模块: {e}")
            self.transcriber = None

        # AI 总结器
        ai_config = self.config.get('ai_summary', {})
        if ai_config.get('enabled', False):
            try:
                from .ai_summarizer import AISummarizer
                self.summarizer = AISummarizer(self.config)
                self.logger.info("[处理] AI总结模块已就绪")
            except ImportError as e:
                self.logger.warning(f"[处理] 无法导入AI总结模块: {e}")
                self.summarizer = None
        else:
            self.summarizer = None

    def _extract_video_name(self, url):
        """从 URL 提取视频名称"""
        try:
            parsed = urlparse(url)
            params = parse_qs(parsed.query)
            courseware_id = params.get('coursewareId', ['unknown'])[0]
            course_id = params.get('courseId', ['unknown'])[0]
            return f"video_{courseware_id[:8]}"
        except Exception:
            return f"video_{int(time.time())}"

    def _extract_video_title(self, page_url, page_title=""):
        """提取视频标题"""
        if page_title and page_title.strip():
            return page_title.strip()

        try:
            parsed = urlparse(page_url)
            params = parse_qs(parsed.query)
            courseware_id = params.get('coursewareId', ['unknown'])[0]
            return f"课程视频_{courseware_id[:12]}"
        except Exception:
            return f"课程视频_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    def process_video(self, video_path, video_url="", video_title="", auto_transcribe=True,
                     auto_summarize=True, use_local_ai=False):
        """处理单个视频：转录 + 总结

        Args:
            video_path: 视频文件路径
            video_url: 视频 URL
            video_title: 视频标题
            auto_transcribe: 是否自动转录
            auto_summarize: 是否自动总结
            use_local_ai: 是否使用本地 AI

        Returns:
            dict: 处理结果
        """
        result = {
            'video_path': video_path,
            'video_url': video_url,
            'video_title': video_title,
            'transcription': None,
            'summary': None,
            'success': False
        }

        if not os.path.exists(video_path):
            self.logger.error(f"[处理] 视频文件不存在: {video_path}")
            return result

        # 转录
        if auto_transcribe and self.transcriber:
            self.logger.info(f"[处理] 开始转录: {video_path}")

            # 使用 Whisper 本地转录
            transcription = self.transcriber.transcribe_video(
                video_path,
                model_size='base',
                language='zh'
            )

            if transcription:
                result['transcription'] = transcription

                # 保存转录结果
                transcript_name = self._extract_video_name(video_url) if video_url else os.path.basename(video_path)
                transcript_path = os.path.join(self.transcripts_dir, transcript_name)
                self.transcriber.save_transcription(transcription, transcript_path)
                self.logger.info(f"[处理] 转录完成: {transcript_path}.json")
            else:
                self.logger.warning("[处理] 转录失败")

        # 总结
        if auto_summarize and self.summarizer and result['transcription']:
            self.logger.info("[处理] 开始生成 AI 总结...")

            summary = self.summarizer.generate_meeting_notes(
                result['transcription'],
                video_title or result['video_title'],
                use_local=use_local_ai
            )

            if summary:
                result['summary'] = summary

                # 保存总结
                summary_name = self._extract_video_name(video_url) if video_url else os.path.basename(video_path)
                summary_path = os.path.join(self.summaries_dir, summary_name)

                # 保存 Markdown 格式
                md_path = summary_path + '.md'
                with open(md_path, 'w', encoding='utf-8') as f:
                    f.write(summary)

                # 保存 JSON 格式
                json_path = summary_path + '.json'
                summary_data = {
                    'video_title': result['video_title'],
                    'video_url': video_url,
                    'summary': summary,
                    'transcription': result['transcription'],
                    'generated_at': datetime.now().isoformat()
                }
                with open(json_path, 'w', encoding='utf-8') as f:
                    json.dump(summary_data, f, ensure_ascii=False, indent=2)

                self.logger.info(f"[处理] 总结已保存: {md_path}")

        result['success'] = True
        return result

    def process_batch(self, video_paths, video_infos=None, auto_transcribe=True,
                     auto_summarize=True, use_local_ai=False):
        """批量处理视频

        Args:
            video_paths: 视频文件路径列表
            video_infos: 视频信息列表（包含 url、title 等）
            auto_transcribe: 是否自动转录
            auto_summarize: 是否自动总结
            use_local_ai: 是否使用本地 AI

        Returns:
            list: 处理结果列表
        """
        results = []
        video_infos = video_infos or [{}] * len(video_paths)

        self.logger.info(f"[处理] 开始批量处理 {len(video_paths)} 个视频...")

        for i, (video_path, video_info) in enumerate(zip(video_paths, video_infos)):
            self.logger.info(f"[处理] 处理进度: {i+1}/{len(video_paths)}")

            result = self.process_video(
                video_path,
                video_url=video_info.get('url', ''),
                video_title=video_info.get('title', ''),
                auto_transcribe=auto_transcribe,
                auto_summarize=auto_summarize,
                use_local_ai=use_local_ai
            )

            results.append(result)

            # 处理间隔，避免资源占用过高
            if i < len(video_paths) - 1:
                time.sleep(2)

        self.logger.info(f"[处理] 批量处理完成: {len(results)} 个视频")
        return results

    def get_recordings(self):
        """获取已录制的视频列表"""
        if not self.recorder:
            return []
        return self.recorder.get_recordings()

    def get_summaries(self):
        """获取已生成的总结列表"""
        summaries = []
        if os.path.exists(self.summaries_dir):
            for f in os.listdir(self.summaries_dir):
                if f.endswith('.md'):
                    path = os.path.join(self.summaries_dir, f)
                    summaries.append({
                        'name': f,
                        'path': path,
                        'size': os.path.getsize(path),
                        'created': datetime.fromtimestamp(os.path.getctime(path))
                    })
        return sorted(summaries, key=lambda x: x['created'], reverse=True)

    def cleanup(self):
        """清理资源"""
        if self.transcriber:
            self.transcriber.cleanup()
