# -*- coding: utf-8 -*-
"""
科大讯飞录音文件转写大模型 (LFASR) v2 API 封装模块

实现录音文件转写流程：
1. /v2/upload   - 上传音频文件，获取 orderId
2. /v2/getResult - 轮询转写结果

认证方式：HMAC-SHA1 签名机制
所有配置从 config/AImodel.yaml 读取，不在代码中硬编码。
"""

import os
import re
import time
import json
import hmac
import hashlib
import base64
import logging
import threading
import random
import string
import subprocess
import tempfile
import requests
from datetime import datetime, timezone, timedelta
from urllib.parse import quote
from typing import Optional, Callable, Dict, Any


class XunfeiLfasrTranscriber:
    """科大讯飞录音文件转写大模型 v2 API 封装

    使用示例:
        config = {
            'app_id': 'xxx',
            'secret_key': 'xxx',
            'api_key': 'xxx',
            'api_base': 'https://office-api-ist-dx.iflyaisol.com',
            'params': {'language': 'autodialect', 'role_type': 1},
        }
        transcriber = XunfeiLfasrTranscriber(config)
        result = transcriber.transcribe('path/to/audio.mp3')
        print(result['text'])
    """

    # API 端点
    ENDPOINT_UPLOAD = '/v2/upload'
    ENDPOINT_GET_RESULT = '/v2/getResult'

    # 讯飞 v2 API 支持的音频格式
    SUPPORTED_FORMATS = {'mp3', 'wav', 'pcm', 'mp4', 'm4a', 'aac', 'opus',
                         'flac', 'ogg', 'amr', 'speex', 'lyb', 'ac3',
                         'ape', 'm4r', 'acc', 'wma'}

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化讯飞转写器

        Args:
            config: 配置字典，必须包含 app_id, secret_key, api_key
                    所有参数从配置文件读取
        """
        self.logger = logging.getLogger(__name__)
        self.config = config or {}

        # 从配置中读取凭证（不在代码中硬编码）
        self.app_id = self.config.get('app_id', '')
        self.secret_key = self.config.get('secret_key', '')  # access_key_secret
        self.api_key = self.config.get('api_key', '')  # accessKeyId
        self.api_base = self.config.get('api_base', 'https://office-api-ist-dx.iflyaisol.com')
        self.params = self.config.get('params', {})

        # 转写参数
        self.language = self.params.get('language', 'autodialect')
        self.role_type = self.params.get('role_type', 1)
        self.max_poll_secs = self.params.get('max_poll_secs', 3600)
        self.poll_interval = self.params.get('poll_interval', 5)

        # 内部状态
        self._order_id: Optional[str] = None
        self._is_running = False
        self._cancel_event = threading.Event()

        # HTTP 会话（复用连接）
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'Accept': 'application/json',
        })

    def _generate_datetime(self) -> str:
        """生成当前时间的 dateTime 参数（带时区偏移）

        格式: yyyy-MM-dd'T'HH:mm:ss±HHmm
        例如: 2025-09-08T22:58:29+0800
        """
        now = datetime.now(timezone(timedelta(hours=8)))  # 东八区
        return now.strftime("%Y-%m-%dT%H:%M:%S+0800")

    def _generate_signature_random(self, length: int = 16) -> str:
        """生成随机字符串用于签名

        Args:
            length: 随机字符串长度，默认16位

        Returns:
            由大小写字母和数字组成的随机字符串
        """
        chars = string.ascii_letters + string.digits
        return ''.join(random.choice(chars) for _ in range(length))

    def _generate_signature(self, params: Dict[str, str]) -> str:
        """生成 HMAC-SHA1 签名

        签名流程:
        1. 排除 signature 字段
        2. 按参数名自然排序
        3. 对键值分别 URL 编码（与 Java URLEncoder.encode 一致）
        4. 拼接为 key=value&key=value 格式
        5. 使用 HMAC-SHA1 签名，密钥为 secret_key
        6. Base64 编码

        Args:
            params: 请求参数字典

        Returns:
            Base64 编码的签名字符串
        """
        # 排除 signature 字段
        filtered = {k: v for k, v in params.items() if k != 'signature'}

        # 按参数名自然排序
        sorted_keys = sorted(filtered.keys())

        # 构建 baseString
        # URL 编码方式需与 Java URLEncoder.encode 一致：
        # 不编码: 字母、数字、.、-、_、*
        # 空格编码为 +（虽然我们的参数一般不含空格）
        parts = []
        for key in sorted_keys:
            value = filtered[key]
            if value is not None and str(value).strip():
                encoded_key = quote(str(key), safe='.-_*')
                encoded_value = quote(str(value), safe='.-_*')
                parts.append(f"{encoded_key}={encoded_value}")

        base_string = '&'.join(parts)

        self.logger.debug(f"[讯飞转写] 签名 baseString: {base_string[:500]}")

        # HMAC-SHA1 签名
        try:
            signature = hmac.new(
                self.secret_key.encode('utf-8'),
                base_string.encode('utf-8'),
                hashlib.sha1
            ).digest()
            return base64.b64encode(signature).decode('utf-8')
        except Exception as e:
            self.logger.error(f"[讯飞转写] 生成签名失败: {e}")
            raise

    def _find_ffprobe(self) -> Optional[str]:
        """查找 ffprobe 可执行文件路径

        Returns:
            ffprobe 路径字符串，未找到返回 None
        """
        ffmpeg_path = self._find_ffmpeg()
        if not ffmpeg_path:
            return None

        # ffprobe 和 ffmpeg 在同一目录，使用 os.path 正确拼接
        ffmpeg_dir = os.path.dirname(ffmpeg_path)
        ffmpeg_name = os.path.basename(ffmpeg_path)
        ffprobe_name = ffmpeg_name.replace('ffmpeg', 'ffprobe')

        if ffmpeg_dir:
            ffprobe_path = os.path.join(ffmpeg_dir, ffprobe_name)
        else:
            ffprobe_path = ffprobe_name

        # 验证 ffprobe 是否存在
        if ffprobe_path != 'ffprobe':
            if os.path.isfile(ffprobe_path):
                return ffprobe_path
            # 回退到系统 PATH
            try:
                result = subprocess.run(['ffprobe', '-version'],
                                        capture_output=True, timeout=5)
                if result.returncode == 0:
                    return 'ffprobe'
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
            return None

        return ffprobe_path

    def _get_audio_duration_ms(self, audio_path: str) -> int:
        """使用 ffprobe 获取音频时长（毫秒）

        Args:
            audio_path: 音频文件路径

        Returns:
            时长（毫秒），获取失败返回 0
        """
        ffprobe_path = self._find_ffprobe()
        if not ffprobe_path:
            return 0

        try:
            cmd = [
                ffprobe_path,
                '-v', 'quiet',
                '-show_entries', 'format=duration',
                '-of', 'default=noprint_wrappers=1:nokey=1',
                audio_path
            ]
            result = subprocess.run(cmd, capture_output=True, timeout=10)
            if result.returncode == 0:
                duration_str = result.stdout.decode('utf-8', errors='replace').strip()
                duration_sec = float(duration_str)
                return int(duration_sec * 1000)
        except Exception as e:
            self.logger.debug(f"[讯飞转写] ffprobe 获取时长失败: {e}")

        return 0

    def _validate_audio_file(self, audio_path: str) -> Dict[str, Any]:
        """使用 ffprobe 验证音频文件属性

        Args:
            audio_path: 音频文件路径

        Returns:
            验证结果字典: {valid, sample_rate, channels, duration_ms, codec, format, error}
        """
        result_info = {
            'valid': False,
            'sample_rate': 0,
            'channels': 0,
            'duration_ms': 0,
            'codec': '',
            'format': '',
            'error': '',
        }

        ffprobe_path = self._find_ffprobe()
        if not ffprobe_path:
            result_info['error'] = 'ffprobe 不可用'
            return result_info

        try:
            cmd = [
                ffprobe_path,
                '-v', 'quiet',
                '-print_format', 'json',
                '-show_format',
                '-show_streams',
                audio_path
            ]
            result = subprocess.run(cmd, capture_output=True, timeout=10)
            if result.returncode != 0:
                result_info['error'] = f'ffprobe 返回错误码 {result.returncode}'
                return result_info

            probe_data = json.loads(result.stdout.decode('utf-8', errors='replace'))

            # 获取格式信息
            format_info = probe_data.get('format', {})
            result_info['format'] = format_info.get('format_name', '')
            duration_str = format_info.get('duration', '0')
            try:
                result_info['duration_ms'] = int(float(duration_str) * 1000)
            except (ValueError, TypeError):
                pass

            # 获取音频流信息
            streams = probe_data.get('streams', [])
            audio_stream = None
            for stream in streams:
                if stream.get('codec_type') == 'audio':
                    audio_stream = stream
                    break

            if not audio_stream:
                result_info['error'] = '未找到音频流'
                return result_info

            result_info['codec'] = audio_stream.get('codec_name', '')
            result_info['sample_rate'] = int(audio_stream.get('sample_rate', 0))
            result_info['channels'] = int(audio_stream.get('channels', 0))
            result_info['valid'] = True

        except json.JSONDecodeError as e:
            result_info['error'] = f'ffprobe 输出解析失败: {e}'
        except Exception as e:
            result_info['error'] = f'ffprobe 验证异常: {e}'

        return result_info

    def _check_audio_volume(self, audio_path: str) -> Dict[str, Any]:
        """使用 ffmpeg volumedetect 检查音频音量

        Args:
            audio_path: 音频文件路径

        Returns:
            音量信息字典: {max_volume, mean_volume, is_silent, error}
        """
        volume_info = {
            'max_volume': None,
            'mean_volume': None,
            'is_silent': True,
            'error': '',
        }

        ffmpeg_path = self._find_ffmpeg()
        if not ffmpeg_path:
            volume_info['error'] = 'ffmpeg 不可用'
            return volume_info

        try:
            cmd = [
                ffmpeg_path, '-i', audio_path,
                '-af', 'volumedetect',
                '-f', 'null', '-',
                '-y'
            ]
            result = subprocess.run(cmd, capture_output=True, timeout=30)
            stderr_text = result.stderr.decode('utf-8', errors='replace')

            # 解析 volumedetect 输出
            mean_match = re.search(r'mean_volume:\s*([-\d.]+)\s*dB', stderr_text)
            max_match = re.search(r'max_volume:\s*([-\d.]+)\s*dB', stderr_text)

            if mean_match:
                volume_info['mean_volume'] = float(mean_match.group(1))
            if max_match:
                volume_info['max_volume'] = float(max_match.group(1))

            # 如果最大音量大于 -60dB，认为不是静音
            if volume_info['max_volume'] is not None and volume_info['max_volume'] > -60:
                volume_info['is_silent'] = False

        except Exception as e:
            volume_info['error'] = f'音量检测异常: {e}'

        return volume_info

    def _build_upload_params(self, audio_path: str) -> tuple:
        """构建上传接口的 URL 查询参数和签名

        Args:
            audio_path: 音频文件路径

        Returns:
            (url, signature, params) 元组: 完整URL, 签名, 原始参数字典
        """
        file_size = str(os.path.getsize(audio_path))
        # fileName 使用简化的英文名，避免中文/特殊字符导致 URL 编码问题
        # 服务器只关心扩展名来确定音频格式
        ext = os.path.splitext(audio_path)[1].lower()
        if not ext:
            ext = '.wav'
        file_name = 'audio' + ext
        date_time = self._generate_datetime()
        signature_random = self._generate_signature_random()

        # 构建参与签名的参数（原始值，未编码）
        params = {
            'appId': self.app_id,
            'accessKeyId': self.api_key,
            'dateTime': date_time,
            'signatureRandom': signature_random,
            'fileSize': file_size,
            'fileName': file_name,
            'language': self.language,
        }

        # 获取并传入音频时长（毫秒），API 示例中 duration 是关键参数
        duration_ms = self._get_audio_duration_ms(audio_path)
        if duration_ms > 0:
            params['duration'] = str(duration_ms)
            self.logger.info(f"[讯飞转写] 音频时长: {duration_ms / 1000:.1f}s")
        else:
            # 获取不到时长时跳过时长校验
            params['durationCheckDisable'] = 'true'
            self.logger.warning("[讯飞转写] 无法获取音频时长，将跳过时长校验")

        # 添加可选参数
        if self.role_type and self.role_type != 0:
            params['roleType'] = str(self.role_type)

        # 生成签名（signature 不参与签名计算）
        signature = self._generate_signature(params)

        # 构建 URL（只包含业务参数，不含 signature）
        # URL 编码方式与 Java URLEncoder.encode 一致
        query_parts = []
        for key, value in params.items():
            encoded_key = quote(str(key), safe='.-_*')
            encoded_value = quote(str(value), safe='.-_*')
            query_parts.append(f"{encoded_key}={encoded_value}")

        url = self.api_base + self.ENDPOINT_UPLOAD + '?' + '&'.join(query_parts)
        self.logger.info(f"[讯飞转写] 上传参数: {list(params.keys())}")
        return url, signature, params

    def _build_get_result_params(self, order_id: str) -> tuple:
        """构建结果查询接口的 URL 查询参数和签名

        Args:
            order_id: 订单 ID

        Returns:
            (url, signature, params) 元组: 完整URL, 签名, 原始参数字典
        """
        date_time = self._generate_datetime()
        signature_random = self._generate_signature_random()

        params = {
            'accessKeyId': self.api_key,
            'dateTime': date_time,
            'signatureRandom': signature_random,
            'orderId': order_id,
            'resultType': 'transfer',
        }

        # 生成签名
        signature = self._generate_signature(params)

        # 构建 URL（只包含业务参数，不含 signature）
        query_parts = []
        for key, value in params.items():
            encoded_key = quote(str(key), safe='.-_*')
            encoded_value = quote(str(value), safe='.-_*')
            query_parts.append(f"{encoded_key}={encoded_value}")

        url = self.api_base + self.ENDPOINT_GET_RESULT + '?' + '&'.join(query_parts)
        return url, signature, params

    def _validate_credentials(self) -> bool:
        """验证凭证配置是否有效

        Returns:
            凭证是否有效
        """
        missing = []
        if not self.app_id or not self.app_id.strip():
            missing.append('app_id')
        if not self.secret_key or not self.secret_key.strip():
            missing.append('secret_key')
        if not self.api_key or not self.api_key.strip():
            missing.append('api_key')

        if missing:
            self.logger.warning(f"[讯飞转写] 缺少凭证配置: {', '.join(missing)}")
            self.logger.warning("[讯飞转写] 请在 config/AImodel.yaml 的 xunfei_lfasr 段填写完整凭证")
            return False

        self.logger.info(f"[讯飞转写] 凭证验证通过 (app_id: {self.app_id[:8]}...)")
        return True

    def _find_ffmpeg(self) -> Optional[str]:
        """查找 ffmpeg 可执行文件路径

        Returns:
            ffmpeg 路径字符串，未找到返回 None
        """
        # 尝试系统 PATH
        try:
            result = subprocess.run(['ffmpeg', '-version'],
                                    capture_output=True, timeout=5)
            if result.returncode == 0:
                self.logger.info("[讯飞转写] 找到 ffmpeg (系统 PATH)")
                return 'ffmpeg'
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # 常见安装路径
        common_paths = [
            r'C:\ffmpeg\bin\ffmpeg.exe',
            r'C:\Program Files\ffmpeg\bin\ffmpeg.exe',
            os.path.expanduser(r'~\AppData\Local\Programs\ffmpeg\bin\ffmpeg.exe'),
        ]
        for path in common_paths:
            if os.path.isfile(path):
                self.logger.info(f"[讯飞转写] 找到 ffmpeg: {path}")
                return path

        self.logger.warning("[讯飞转写] 未找到 ffmpeg")
        return None

    def _convert_audio(self, audio_path: str) -> Optional[str]:
        """将音频文件转换为讯飞 API 要求的标准 WAV 格式

        无论原始格式是否被支持，都使用 ffmpeg 转换为 16kHz 16bit 单声道 WAV，
        确保音频属性完全符合讯飞 API 要求（浏览器录制的 WAV 可能是 48kHz/32bit/立体声，
        不转换会导致服务器无法正确解码，返回 failType=6 静音文件错误）。

        Args:
            audio_path: 原始音频文件路径

        Returns:
            转换后的 WAV 文件路径，失败返回 None
        """
        ext = os.path.splitext(audio_path)[1].lower().lstrip('.')

        # 先验证原始文件的音频属性
        self.logger.info(f"[讯飞转写] 原始音频: {os.path.basename(audio_path)}")
        original_info = self._validate_audio_file(audio_path)
        if original_info['valid']:
            self.logger.info(
                f"[讯飞转写] 原始音频属性: 格式={original_info['format']}, "
                f"编码={original_info['codec']}, 采样率={original_info['sample_rate']}Hz, "
                f"声道={original_info['channels']}, 时长={original_info['duration_ms']/1000:.1f}s"
            )
        else:
            self.logger.warning(f"[讯飞转写] 无法读取原始音频属性: {original_info['error']}")

        ffmpeg_path = self._find_ffmpeg()
        if not ffmpeg_path:
            # ffmpeg 不可用时，对于支持的格式直接返回原文件
            if ext in self.SUPPORTED_FORMATS:
                self.logger.warning(
                    "[讯飞转写] ffmpeg 不可用，将直接上传原文件（可能因音频属性不符导致失败）"
                )
                return audio_path
            self.logger.error(
                f"[讯飞转写] 音频格式 .{ext} 不被讯飞 API 支持，且未找到 ffmpeg，无法转换。\n"
                "请安装 ffmpeg: https://ffmpeg.org/download.html"
            )
            return None

        # 生成临时 WAV 文件
        temp_dir = tempfile.gettempdir()
        base_name = os.path.splitext(os.path.basename(audio_path))[0]
        wav_path = os.path.join(temp_dir, f"xunfei_{base_name}.wav")

        try:
            cmd = [
                ffmpeg_path, '-y', '-i', audio_path,
                '-acodec', 'pcm_s16le',  # 明确指定 PCM 16-bit little-endian 编码
                '-ar', '16000',          # 采样率 16kHz
                '-ac', '1',              # 单声道
                '-f', 'wav',             # 明确指定 WAV 容器格式
                wav_path
            ]

            self.logger.info(f"[讯飞转写] 正在转换音频为标准格式: PCM WAV 16kHz/16bit/单声道")
            result = subprocess.run(
                cmd, capture_output=True, timeout=120
            )

            if result.returncode != 0:
                stderr_text = result.stderr.decode('utf-8', errors='replace')[:500]
                self.logger.error(f"[讯飞转写] ffmpeg 转换失败: {stderr_text}")
                return None

            if not os.path.exists(wav_path) or os.path.getsize(wav_path) == 0:
                self.logger.error("[讯飞转写] 转换后文件不存在或为空")
                return None

            # 验证转换后的音频文件
            conv_info = self._validate_audio_file(wav_path)
            if conv_info['valid']:
                self.logger.info(
                    f"[讯飞转写] 转换后属性: 编码={conv_info['codec']}, "
                    f"采样率={conv_info['sample_rate']}Hz, 声道={conv_info['channels']}, "
                    f"时长={conv_info['duration_ms']/1000:.1f}s"
                )
                # 验证关键参数
                if conv_info['sample_rate'] != 16000:
                    self.logger.error(
                        f"[讯飞转写] 转换后采样率不正确: {conv_info['sample_rate']}Hz (应为 16000Hz)"
                    )
                    return None
                if conv_info['channels'] != 1:
                    self.logger.error(
                        f"[讯飞转写] 转换后声道数不正确: {conv_info['channels']} (应为 1)"
                    )
                    return None
            else:
                self.logger.warning(f"[讯飞转写] 无法验证转换后文件: {conv_info['error']}")

            # 检查音量（检测静音）
            volume_info = self._check_audio_volume(wav_path)
            if volume_info.get('error'):
                self.logger.debug(f"[讯飞转写] 音量检测跳过: {volume_info['error']}")
            elif volume_info.get('is_silent'):
                self.logger.warning(
                    f"[讯飞转写] ⚠ 音频可能为静音! "
                    f"最大音量={volume_info.get('max_volume', 'N/A')}dB, "
                    f"平均音量={volume_info.get('mean_volume', 'N/A')}dB。"
                    f"这通常意味着录音没有捕获到声音，讯飞 API 将返回 failType=6 错误。"
                )
            else:
                self.logger.info(
                    f"[讯飞转写] 音量检查: 最大={volume_info.get('max_volume', 'N/A')}dB, "
                    f"平均={volume_info.get('mean_volume', 'N/A')}dB"
                )

            wav_size_mb = os.path.getsize(wav_path) / (1024 * 1024)
            self.logger.info(
                f"[讯飞转写] 格式转换完成: {wav_path} ({wav_size_mb:.1f}MB)"
            )
            return wav_path

        except subprocess.TimeoutExpired:
            self.logger.error("[讯飞转写] ffmpeg 转换超时")
            return None
        except Exception as e:
            self.logger.error(f"[讯飞转写] ffmpeg 转换异常: {e}")
            return None

    def _upload(self, audio_path: str) -> Optional[str]:
        """上传音频文件，获取 orderId

        Args:
            audio_path: 音频文件路径

        Returns:
            orderId 字符串，失败返回 None
        """
        if not os.path.exists(audio_path):
            self.logger.error(f"[讯飞转写] 音频文件不存在: {audio_path}")
            return None

        file_size = os.path.getsize(audio_path)
        file_name = os.path.basename(audio_path)

        self.logger.info(
            f"[讯飞转写] 上传音频: file={file_name}, "
            f"size={file_size / (1024 * 1024):.1f}MB"
        )

        try:
            url, signature, params = self._build_upload_params(audio_path)
            self.logger.info(f"[讯飞转写] POST {self.api_base}{self.ENDPOINT_UPLOAD}")
            self.logger.info(
                f"[讯飞转写] 上传参数: fileName={params.get('fileName')}, "
                f"fileSize={params.get('fileSize')}, "
                f"duration={params.get('duration', params.get('durationCheckDisable', 'N/A'))}, "
                f"language={params.get('language')}"
            )

            # 上传音频文件（二进制流）
            with open(audio_path, 'rb') as f:
                audio_data = f.read()

            # 确认读取的数据大小与文件大小一致
            if len(audio_data) != file_size:
                self.logger.warning(
                    f"[讯飞转写] 数据大小不一致: 文件={file_size}, 读取={len(audio_data)}"
                )

            headers = {
                'Content-Type': 'application/octet-stream',
                'signature': signature,
            }

            response = self._session.post(
                url, headers=headers, data=audio_data, timeout=300
            )

            self.logger.info(f"[讯飞转写] upload 响应: status={response.status_code}")
            self.logger.debug(f"[讯飞转写] upload 响应体: {response.text[:500]}")

            if response.status_code != 200:
                self.logger.error(
                    f"[讯飞转写] upload 失败，HTTP {response.status_code}: {response.text[:500]}"
                )
                return None

            result = response.json()

            # 检查业务错误码
            code = str(result.get('code', ''))
            if code != '000000':
                desc_info = result.get('descInfo', 'unknown error')
                self.logger.error(
                    f"[讯飞转写] upload 业务失败: code={code}, descInfo={desc_info}"
                )
                return None

            # 提取 orderId
            content = result.get('content', {})
            order_id = content.get('orderId', '')

            if not order_id:
                self.logger.error(f"[讯飞转写] upload 响应中未找到 orderId: {result}")
                return None

            task_estimate = content.get('taskEstimateTime', 0)
            self.logger.info(
                f"[讯飞转写] upload 成功, orderId={order_id}, "
                f"预估耗时={task_estimate / 1000:.0f}s"
            )
            return order_id

        except requests.Timeout:
            self.logger.error("[讯飞转写] upload 请求超时")
            return None
        except requests.RequestException as e:
            self.logger.error(f"[讯飞转写] upload 请求异常: {e}")
            return None
        except Exception as e:
            self.logger.error(f"[讯飞转写] upload 未知异常: {e}")
            return None

    def _get_result(self, order_id: str) -> Optional[Dict[str, Any]]:
        """查询转写结果

        Args:
            order_id: 订单 ID

        Returns:
            结果字典，包含 orderInfo 和可能的 orderResult
            status: 0=已创建, 3=处理中, 4=已完成, -1=失败
            处理中/已创建时返回状态信息，失败返回 None
        """
        try:
            url, signature, _ = self._build_get_result_params(order_id)

            headers = {
                'Content-Type': 'application/json',
                'signature': signature,
            }

            response = self._session.post(
                url, headers=headers, data='{}', timeout=60
            )

            if response.status_code != 200:
                self.logger.error(
                    f"[讯飞转写] getResult 失败，HTTP {response.status_code}: "
                    f"{response.text[:500]}"
                )
                return None

            result = response.json()

            code = str(result.get('code', ''))
            if code != '000000':
                desc_info = result.get('descInfo', 'unknown error')
                self.logger.error(
                    f"[讯飞转写] getResult 业务失败: code={code}, descInfo={desc_info}"
                )
                return None

            return result

        except requests.Timeout:
            self.logger.error("[讯飞转写] getResult 请求超时")
            return None
        except requests.RequestException as e:
            self.logger.error(f"[讯飞转写] getResult 请求异常: {e}")
            return None
        except Exception as e:
            self.logger.error(f"[讯飞转写] getResult 未知异常: {e}")
            return None

    def _poll_result(self, order_id: str,
                     on_progress: Optional[Callable[[Dict], None]] = None) -> Optional[Dict[str, Any]]:
        """轮询转写结果直到完成或超时

        Args:
            order_id: 订单 ID
            on_progress: 进度回调函数

        Returns:
            完成时的结果字典，失败或超时返回 None
        """
        start_time = time.time()
        self.logger.info(
            f"[讯飞转写] 开始轮询结果，超时: {self.max_poll_secs}s，"
            f"间隔: {self.poll_interval}s"
        )

        while time.time() - start_time < self.max_poll_secs:
            if self._cancel_event.is_set():
                self.logger.info("[讯飞转写] 轮询已取消")
                return None

            result = self._get_result(order_id)
            if result is None:
                # 查询请求本身失败，等待后重试
                time.sleep(self.poll_interval)
                continue

            content = result.get('content', {})
            order_info = content.get('orderInfo', {})
            status = order_info.get('status', -1)
            fail_type = order_info.get('failType', 0)

            # 状态: 0=已创建, 3=处理中, 4=已完成, -1=失败
            if status == 4:
                # 转写完成
                self.logger.info("[讯飞转写] 转写完成")
                return result

            elif status == -1:
                # 转写失败
                # failType 含义: 0=未知, 1=音量过小, 2=格式不支持,
                # 3=时长过短, 6=静音文件/解码失败, 7=文件损坏
                fail_desc = {
                    0: '未知错误',
                    1: '音量过小',
                    2: '音频格式不支持',
                    3: '音频时长过短',
                    6: '静音文件或解码失败（音频可能无声或格式不兼容）',
                    7: '文件损坏',
                }.get(fail_type, f'未知类型({fail_type})')

                self.logger.error(
                    f"[讯飞转写] 转写失败: failType={fail_type} ({fail_desc}), "
                    f"orderId={order_id}"
                )

                # failType=6 时输出详细诊断建议
                if fail_type == 6:
                    self.logger.error(
                        "[讯飞转写] failType=6 诊断建议:\n"
                        "  1. 检查浏览器录音是否捕获到声音（音频可能确实是静音的）\n"
                        "  2. 检查 ffmpeg 是否正确转换了音频格式\n"
                        "  3. 确认上传的 WAV 文件为 16kHz/16bit/单声道 PCM 格式\n"
                        "  4. 如果音频确实有声音但仍报此错误，请检查上传文件是否完整\n"
                        "  5. 可以尝试用其他音频播放器打开转换后的临时文件验证"
                    )

                # 保存 fail_type 供外部读取
                self._last_fail_type = fail_type
                return None

            elif status in (0, 3):
                # 处理中
                elapsed = time.time() - start_time
                task_estimate = content.get('taskEstimateTime', 0) / 1000
                original_duration = order_info.get('originalDuration', 0) / 1000

                desc = f"处理中 (已等待 {elapsed:.0f}s"
                if task_estimate > 0:
                    desc += f", 预估 {task_estimate:.0f}s"
                desc += ")"

                self.logger.info(
                    f"[讯飞转写] 转写中... status={status}, {desc}"
                )

                if on_progress:
                    try:
                        on_progress({
                            'status': 3,
                            'desc': desc,
                            'step': 'polling',
                            'elapsed': elapsed,
                            'original_duration': original_duration,
                        })
                    except Exception:
                        pass

                time.sleep(self.poll_interval)

            else:
                self.logger.error(f"[讯飞转写] 未知状态: status={status}")
                return None

        self.logger.error(f"[讯飞转写] 轮询超时 ({self.max_poll_secs}s)")
        return None

    def _parse_result(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """解析转写结果，提取文本和分段信息

        讯飞 v2 结果格式:
        orderResult 是一个 JSON 字符串，结构为:
        {
            "lattice": [
                {
                    "json_1best": "{\"st\":{\"rt\":[{\"ws\":[{\"cw\":[{\"w\":\"词\",\"wp\":\"n\"}]}]}],\"bg\":\"0\",\"ed\":\"100\"}}"
                }
            ]
        }

        Args:
            result: API 返回的完整结果字典

        Returns:
            解析后的转写结果: {'text': str, 'sentences': list, 'duration': float, ...}
        """
        content = result.get('content', {})
        order_info = content.get('orderInfo', {})
        order_result_str = content.get('orderResult', '')
        original_duration = order_info.get('originalDuration', 0)

        text = ''
        sentences = []

        if order_result_str and isinstance(order_result_str, str):
            try:
                parsed = json.loads(order_result_str)
                lattice_list = parsed.get('lattice', [])

                for lattice_item in lattice_list:
                    json_1best = lattice_item.get('json_1best', '')
                    if not json_1best:
                        continue

                    try:
                        st_obj = json.loads(json_1best)
                        st = st_obj.get('st', {})
                        bg = st.get('bg', '0')
                        ed = st.get('ed', '0')

                        # 提取词语
                        sentence_text = ''
                        for rt in st.get('rt', []):
                            for ws in rt.get('ws', []):
                                for cw in ws.get('cw', []):
                                    w = cw.get('w', '')
                                    wp = cw.get('wp', '')
                                    if wp == 'g':
                                        # 分段标记，添加换行
                                        sentence_text += '\n'
                                    else:
                                        sentence_text += w

                        if sentence_text.strip():
                            sentences.append({
                                'text': sentence_text.strip(),
                                'bg': int(bg) if bg.isdigit() else 0,
                                'ed': int(ed) if ed.isdigit() else 0,
                            })
                            text += sentence_text.strip()

                    except (json.JSONDecodeError, TypeError) as e:
                        self.logger.debug(f"[讯飞转写] 解析 json_1best 失败: {e}")
                        continue

            except (json.JSONDecodeError, TypeError) as e:
                self.logger.warning(f"[讯飞转写] 解析 orderResult 失败: {e}")
                text = order_result_str
                sentences = [{'text': order_result_str, 'bg': 0, 'ed': 0}]

        if not text:
            self.logger.warning("[讯飞转写] 转写结果为空文本")
            self.logger.debug(
                f"[讯飞转写] 原始响应: {json.dumps(result, ensure_ascii=False)[:1000]}"
            )

        transcription = {
            'text': text,
            'sentences': sentences,
            'task_id': self._order_id or '',
            'raw': content,
            'duration': original_duration / 1000.0 if original_duration else 0,
        }

        self.logger.info(
            f"[讯飞转写] 解析结果成功: 文本长度={len(text)}, 句子数={len(sentences)}"
        )
        return transcription

    def transcribe(self, audio_path: str,
                   on_progress: Optional[Callable[[Dict], None]] = None) -> Optional[Dict[str, Any]]:
        """完整转写流程：upload → poll getResult

        Args:
            audio_path: 音频文件路径
            on_progress: 进度回调函数，接收进度信息字典

        Returns:
            转写结果字典: {'text': str, 'sentences': list, 'duration': float, ...}
            失败返回 None
        """
        # 验证凭证
        if not self._validate_credentials():
            return None

        # 验证文件
        if not os.path.exists(audio_path):
            self.logger.error(f"[讯飞转写] 文件不存在: {audio_path}")
            return None

        file_size = os.path.getsize(audio_path)
        if file_size == 0:
            self.logger.error(f"[讯飞转写] 文件为空: {audio_path}")
            return None

        file_size_mb = file_size / (1024 * 1024)
        self.logger.info(
            f"[讯飞转写] 开始转写: {os.path.basename(audio_path)} "
            f"({file_size_mb:.1f}MB)"
        )

        # 限制文件大小（最大 500MB）
        if file_size_mb > 500:
            self.logger.error(f"[讯飞转写] 文件过大 ({file_size_mb:.1f}MB)，最大支持 500MB")
            return None

        self._is_running = True
        self._cancel_event.clear()
        self._last_fail_type = None

        converted_path = None
        transcription_failed = False  # 标记是否转写失败（用于决定是否保留临时文件）
        try:
            # 0. 格式转换（始终用 ffmpeg 转为标准 16kHz/16bit/单声道 WAV）
            self.logger.info(f"[讯飞转写] 步骤0: 音频格式转换")
            upload_path = self._convert_audio(audio_path)
            if upload_path is None:
                return None
            if upload_path != audio_path:
                converted_path = upload_path
                self.logger.info(
                    f"[讯飞转写] 将使用转换后文件: {upload_path} "
                    f"({os.path.getsize(upload_path) / 1024:.1f}KB)"
                )
            else:
                self.logger.info(f"[讯飞转写] 使用原始文件（未经 ffmpeg 转换）")

            # 1. 上传音频
            if on_progress:
                try:
                    on_progress({'status': 0, 'desc': '正在上传音频...', 'step': 'upload'})
                except Exception:
                    pass

            order_id = self._upload(upload_path)
            if not order_id:
                self.logger.error("[讯飞转写] 上传音频失败")
                return None
            self._order_id = order_id

            # 2. 轮询结果
            if on_progress:
                try:
                    on_progress({'status': 0, 'desc': '正在转写中...', 'step': 'polling'})
                except Exception:
                    pass

            result = self._poll_result(order_id, on_progress)
            if result is None:
                transcription_failed = True
                self.logger.error("[讯飞转写] 转写处理失败或超时")
                # failType=6 时保留临时文件用于诊断
                if self._last_fail_type == 6 and converted_path:
                    self.logger.warning(
                        f"[讯飞转写] ⚠ 已保留转换后的音频文件用于诊断: {converted_path}\n"
                        f"请用音频播放器打开此文件，检查是否有声音。如果文件无声，说明浏览器录音未捕获到音频。"
                    )
                return None

            # 3. 解析结果
            if on_progress:
                try:
                    on_progress({'status': 2, 'desc': '正在解析转写结果...', 'step': 'result'})
                except Exception:
                    pass

            transcription = self._parse_result(result)

            if transcription:
                self.logger.info(
                    f"[讯飞转写] 转写成功完成: "
                    f"文本长度={len(transcription.get('text', ''))}"
                )
            else:
                self.logger.error("[讯飞转写] 解析转写结果失败")

            return transcription

        except Exception as e:
            self.logger.error(f"[讯飞转写] 转写流程异常: {e}")
            return None
        finally:
            self._is_running = False
            # 清理临时转换文件（仅在转写成功或非 failType=6 时清理）
            should_cleanup = not (transcription_failed and self._last_fail_type == 6)
            if should_cleanup and converted_path and os.path.exists(converted_path):
                try:
                    os.remove(converted_path)
                    self.logger.debug(f"[讯飞转写] 已清理临时文件: {converted_path}")
                except Exception:
                    pass

    def cancel(self):
        """取消当前转写任务"""
        self._cancel_event.set()
        self._is_running = False
        self.logger.info("[讯飞转写] 已请求取消")

    def cleanup(self):
        """清理资源"""
        self.cancel()
        try:
            self._session.close()
        except Exception:
            pass
        self.logger.info("[讯飞转写] 资源已清理")


def create_transcriber_from_config(config_path: Optional[str] = None) -> Optional[XunfeiLfasrTranscriber]:
    """从配置文件创建讯飞转写器（工厂函数）

    读取 config/AImodel.yaml 中的 xunfei_lfasr 配置段，
    验证凭证后创建 XunfeiLfasrTranscriber 实例。

    Args:
        config_path: 配置文件路径，默认 config/AImodel.yaml

    Returns:
        XunfeiLfasrTranscriber 实例，配置无效时返回 None
    """
    try:
        from .ai_model import AIModelConfig
        ai_config = AIModelConfig(config_path)
        provider_config = ai_config.get_provider_config('xunfei_lfasr')

        if not provider_config:
            import logging
            logger = logging.getLogger(__name__)
            logger.error("[讯飞转写] 未找到 xunfei_lfasr 配置")
            return None

        transcriber = XunfeiLfasrTranscriber(provider_config)
        if not transcriber._validate_credentials():
            return None

        return transcriber

    except Exception as e:
        import logging
        logger = logging.getLogger(__name__)
        logger.error(f"[讯飞转写] 创建转写器失败: {e}")
        return None
