// -*- coding: utf-8 -*-
/**
 * 前端音频录制注入脚本
 * 
 * 这段 JavaScript 代码会被注入到 Playwright 页面中，
 * 用于捕获网页中的音频流。
 * 
 * 使用方法：
 * 通过 Playwright evaluate() 注入此脚本，
 * 然后调用 window.__web_audio_recorder__.start() 等方法。
 */

// 音频录制器核心代码
const WEB_AUDIO_RECORDER_JS = `
// ================================================================
// WebAudioRecorder - 网页音频录制器
// 支持捕获网页视频/音频的音频流
// ================================================================

(function() {
    'use strict';
    
    // 防止重复注入
    if (window.__web_audio_recorder__) {
        console.log('[AudioRecorder] 已存在实例');
        return window.__web_audio_recorder__;
    }
    
    class WebAudioRecorder {
        constructor() {
            // 核心组件
            this.audioContext = null;
            this.mediaRecorder = null;
            this.audioDestination = null;
            
            // 状态
            this.isRecording = false;
            this.isPaused = false;
            this.startTime = null;
            this.pausedTime = 0;
            this.lastPauseTime = null;
            
            // 数据
            this.recordedChunks = [];
            this.connectedElements = [];
            this.audioNodes = [];
            
            // 配置
            this.config = {
                mimeType: null,
                audioBitsPerSecond: 128000,
                sampleRate: 48000,
                channels: 1,
                timeslice: 1000
            };
            
            // 回调
            this.onDataAvailable = null;
            this.onError = null;
            this.onStatusChange = null;
            
            // 初始化
            this._init();
        }
        
        // 初始化
        _init() {
            // 检测支持的 MIME 类型
            this._detectSupportedMimeType();
            console.log('[AudioRecorder] 初始化完成，支持格式:', this.config.mimeType);
        }
        
        // 检测支持的 MIME 类型
        _detectSupportedMimeType() {
            const types = [
                'audio/webm;codecs=opus',
                'audio/webm;codecs=vorbis', 
                'audio/webm',
                'audio/ogg;codecs=opus',
                'audio/ogg',
                'audio/mp4',
                'audio/aac'
            ];
            
            for (const type of types) {
                try {
                    if (MediaRecorder.isTypeSupported(type)) {
                        this.config.mimeType = type;
                        console.log('[AudioRecorder] 选择格式:', type);
                        return;
                    }
                } catch (e) {
                    console.warn('[AudioRecorder] 不支持:', type);
                }
            }
            
            this.config.mimeType = 'audio/webm';
        }
        
        // 获取音频上下文
        _getAudioContext() {
            if (!this.audioContext || this.audioContext.state === 'closed') {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)({
                    sampleRate: this.config.sampleRate
                });
            }
            return this.audioContext;
        }
        
        // 获取页面的媒体元素
        _getMediaElements() {
            const elements = [];
            
            // 查询所有 video 和 audio 元素
            const selectors = ['video', 'audio'];
            
            selectors.forEach(selector => {
                // 主文档
                document.querySelectorAll(selector).forEach(el => {
                    if (el.src || el.currentSrc) {
                        elements.push(el);
                    }
                });
                
                // Shadow DOM
                document.querySelectorAll('*').forEach(root => {
                    if (root.shadowRoot) {
                        root.shadowRoot.querySelectorAll(selector).forEach(el => {
                            if (el.src || el.currentSrc) {
                                elements.push(el);
                            }
                        });
                    }
                });
                
                // iframe
                document.querySelectorAll('iframe').forEach(iframe => {
                    try {
                        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
                        if (iframeDoc) {
                            iframeDoc.querySelectorAll(selector).forEach(el => {
                                if (el.src || el.currentSrc) {
                                    elements.push(el);
                                }
                            });
                        }
                    } catch (e) {
                        // 跨域 iframe 无法访问
                    }
                });
            });
            
            return [...new Set(elements)];
        }
        
        // 连接到媒体元素
        async _connectToMedia(mediaElement) {
            const audioContext = this._getAudioContext();
            
            try {
                // 方法1: captureStream
                if (mediaElement.captureStream) {
                    const stream = mediaElement.captureStream();
                    const source = audioContext.createMediaStreamSource(stream);
                    source.connect(audioContext.destination);
                    
                    this.audioNodes.push({ type: 'captureStream', source, stream });
                    console.log('[AudioRecorder] 使用 captureStream 方式');
                    return true;
                }
            } catch (e) {
                console.warn('[AudioRecorder] captureStream 失败:', e);
            }
            
            try {
                // 方法2: createMediaElementSource
                if (mediaElement instanceof HTMLMediaElement) {
                    const source = audioContext.createMediaElementSource(mediaElement);
                    source.connect(audioContext.destination);
                    
                    this.audioNodes.push({ type: 'mediaElement', source, element: mediaElement });
                    console.log('[AudioRecorder] 使用 createMediaElementSource 方式');
                    return true;
                }
            } catch (e) {
                console.warn('[AudioRecorder] createMediaElementSource 失败:', e);
            }
            
            return false;
        }
        
        // 创建音频处理节点（用于捕获未连接的音频）
        _createProcessingNode() {
            const audioContext = this._getAudioContext();
            
            // 使用 AudioWorklet (现代浏览器)
            if (audioContext.audioWorklet) {
                try {
                    const workletCode = `
                        class AudioCaptureProcessor extends AudioWorkletProcessor {
                            constructor() {
                                super();
                                this.buffer = [];
                                this.port.onmessage = (e) => {
                                    if (e.data === 'flush') {
                                        this.port.postMessage({ buffer: this.buffer });
                                        this.buffer = [];
                                    }
                                };
                            }
                            
                            process(inputs, outputs, parameters) {
                                const input = inputs[0];
                                if (input && input.length > 0) {
                                    this.buffer.push(...input[0]);
                                }
                                return true;
                            }
                        }
                    `;
                    
                    const blob = new Blob([workletCode], { type: 'application/javascript' });
                    const url = URL.createObjectURL(blob);
                    
                    return audioContext.audioWorklet.addModule(url).then(() => {
                        const node = new AudioWorkletNode(audioContext, 'audio-capture-processor');
                        URL.revokeObjectURL(url);
                        return node;
                    });
                } catch (e) {
                    console.warn('[AudioRecorder] AudioWorklet 失败:', e);
                }
            }
            
            // 回退: ScriptProcessor
            return new Promise((resolve) => {
                const bufferSize = 4096;
                const scriptNode = audioContext.createScriptProcessor(bufferSize, 1, 1);
                
                scriptNode.onaudioprocess = (event) => {
                    // 音频处理逻辑
                    const inputData = event.inputBuffer.getChannelData(0);
                    // 可以在这里进行音频数据回调
                    if (this.onDataAvailable) {
                        this.onDataAvailable(new Float32Array(inputData));
                    }
                };
                
                resolve(scriptNode);
            });
        }
        
        // 开始录制
        async start(options = {}) {
            if (this.isRecording) {
                throw new Error('已经在录制中');
            }
            
            console.log('[AudioRecorder] 开始录制...');
            
            try {
                // 获取音频上下文
                const audioContext = this._getAudioContext();
                
                // 确保音频上下文在运行状态
                if (audioContext.state === 'suspended') {
                    await audioContext.resume();
                }
                
                // 获取媒体元素
                const mediaElements = options.elements || this._getMediaElements();
                console.log('[AudioRecorder] 找到媒体元素:', mediaElements.length);
                
                // 创建目标流
                const destStream = new MediaStream();
                
                // 连接到媒体元素
                let connected = false;
                
                for (const el of mediaElements) {
                    if (await this._connectToMedia(el)) {
                        connected = true;
                    }
                }
                
                // 如果无法通过 Web Audio API 捕获，尝试直接获取音频轨道
                if (!connected) {
                    console.log('[AudioRecorder] 尝试直接获取音频轨道...');
                    
                    // 尝试从 captureStream 获取
                    for (const el of mediaElements) {
                        if (el.captureStream) {
                            const stream = el.captureStream();
                            const audioTracks = stream.getAudioTracks();
                            
                            if (audioTracks.length > 0) {
                                audioTracks.forEach(track => destStream.addTrack(track.clone()));
                                connected = true;
                                console.log('[AudioRecorder] 从 captureStream 获取音频轨道成功');
                                break;
                            }
                        }
                    }
                }
                
                // 尝试使用 getUserMedia 获取系统音频（需要用户授权）
                if (!connected && mediaElements.length === 0) {
                    console.log('[AudioRecorder] 尝试获取系统音频...');
                    try {
                        // 创建虚拟的音频元素来获取系统音频
                        const audio = new Audio();
                        audio.src = ''; // 空的 src
                        
                        // 这需要用户通过 getDisplayMedia 授权
                        // 但我们不能强制要求
                    } catch (e) {
                        console.warn('[AudioRecorder] 无法获取系统音频:', e);
                    }
                }
                
                if (destStream.getAudioTracks().length === 0) {
                    throw new Error('无法获取音频轨道。请确保页面上的视频正在播放音频。');
                }
                
                // 重置状态
                this.recordedChunks = [];
                this.isRecording = true;
                this.isPaused = false;
                this.startTime = Date.now();
                this.pausedTime = 0;
                this.lastPauseTime = null;
                
                // 创建 MediaRecorder
                this.mediaRecorder = new MediaRecorder(destStream, {
                    mimeType: this.config.mimeType,
                    audioBitsPerSecond: this.config.audioBitsPerSecond
                });
                
                // 设置数据处理器
                this.mediaRecorder.ondataavailable = (event) => {
                    if (event.data && event.data.size > 0) {
                        this.recordedChunks.push(event.data);
                        
                        // 触发回调
                        if (this.onDataAvailable) {
                            // 转换为 base64
                            event.data.arrayBuffer().then(buffer => {
                                const base64 = btoa(String.fromCharCode(...new Uint8Array(buffer)));
                                this.onDataAvailable({ 
                                    type: 'chunk',
                                    base64: base64,
                                    size: event.data.size,
                                    timestamp: Date.now()
                                });
                            });
                        }
                    }
                };
                
                this.mediaRecorder.onerror = (event) => {
                    console.error('[AudioRecorder] MediaRecorder 错误:', event.error);
                    if (this.onError) {
                        this.onError(event.error);
                    }
                };
                
                this.mediaRecorder.onpause = () => {
                    console.log('[AudioRecorder] 已暂停');
                    this.isPaused = true;
                    this.lastPauseTime = Date.now();
                    if (this.onStatusChange) {
                        this.onStatusChange('paused');
                    }
                };
                
                this.mediaRecorder.onresume = () => {
                    console.log('[AudioRecorder] 已恢复');
                    this.isPaused = false;
                    if (this.lastPauseTime) {
                        this.pausedTime += Date.now() - this.lastPauseTime;
                        this.lastPauseTime = null;
                    }
                    if (this.onStatusChange) {
                        this.onStatusChange('recording');
                    }
                };
                
                this.mediaRecorder.onstart = () => {
                    console.log('[AudioRecorder] MediaRecorder 已启动');
                    if (this.onStatusChange) {
                        this.onStatusChange('recording');
                    }
                };
                
                this.mediaRecorder.onstop = () => {
                    console.log('[AudioRecorder] MediaRecorder 已停止');
                    if (this.onStatusChange) {
                        this.onStatusChange('stopped');
                    }
                };
                
                // 开始录制
                this.mediaRecorder.start(this.config.timeslice);
                
                return {
                    success: true,
                    mediaElements: mediaElements.length,
                    mimeType: this.config.mimeType,
                    audioTracks: destStream.getAudioTracks().length
                };
                
            } catch (error) {
                console.error('[AudioRecorder] 启动失败:', error);
                this.isRecording = false;
                throw error;
            }
        }
        
        // 暂停录制
        pause() {
            if (!this.isRecording || this.isPaused) {
                return false;
            }
            
            if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
                this.mediaRecorder.pause();
                return true;
            }
            
            return false;
        }
        
        // 恢复录制
        resume() {
            if (!this.isRecording || !this.isPaused) {
                return false;
            }
            
            if (this.mediaRecorder && this.mediaRecorder.state === 'paused') {
                this.mediaRecorder.resume();
                return true;
            }
            
            return false;
        }
        
        // 停止录制
        async stop() {
            if (!this.isRecording) {
                throw new Error('未在录制中');
            }
            
            return new Promise((resolve, reject) => {
                try {
                    const duration = this._getDuration();
                    
                    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
                        this.mediaRecorder.onstop = () => {
                            // 创建最终的 Blob
                            const blob = new Blob(this.recordedChunks, {
                                type: this.config.mimeType || 'audio/webm'
                            });
                            
                            // 清理
                            this._cleanup();
                            
                            resolve({
                                success: true,
                                blob: blob,
                                duration: duration,
                                mimeType: this.config.mimeType,
                                size: blob.size,
                                chunks: this.recordedChunks.length
                            });
                        };
                        
                        this.mediaRecorder.stop();
                    } else {
                        this._cleanup();
                        reject(new Error('MediaRecorder 未启动'));
                    }
                    
                } catch (error) {
                    this._cleanup();
                    reject(error);
                }
            });
        }
        
        // 获取当前时长
        _getDuration() {
            if (!this.startTime) return 0;
            
            let duration = Date.now() - this.startTime - this.pausedTime;
            if (this.lastPauseTime) {
                duration -= (Date.now() - this.lastPauseTime);
            }
            
            return duration / 1000;
        }
        
        // 获取录制时长
        getDuration() {
            return this._getDuration();
        }
        
        // 获取录制状态
        getStatus() {
            return {
                isRecording: this.isRecording,
                isPaused: this.isPaused,
                duration: this._getDuration(),
                state: this.mediaRecorder?.state || 'inactive',
                mimeType: this.config.mimeType,
                chunks: this.recordedChunks.length,
                supportedFormats: this._getSupportedFormats()
            };
        }
        
        // 获取支持的格式列表
        _getSupportedFormats() {
            const types = [
                'audio/webm;codecs=opus',
                'audio/webm;codecs=vorbis',
                'audio/webm',
                'audio/ogg;codecs=opus',
                'audio/ogg',
                'audio/mp4',
                'audio/aac'
            ];
            
            return types.filter(type => {
                try {
                    return MediaRecorder.isTypeSupported(type);
                } catch (e) {
                    return false;
                }
            });
        }
        
        // 获取已录制数据
        getRecordedData() {
            if (this.recordedChunks.length === 0) {
                return null;
            }
            
            const blob = new Blob(this.recordedChunks, {
                type: this.config.mimeType || 'audio/webm'
            });
            
            return {
                blob: blob,
                size: blob.size,
                chunks: this.recordedChunks.length,
                duration: this._getDuration()
            };
        }
        
        // 将 Blob 转换为 Base64
        async blobToBase64(blob) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.onerror = reject;
                reader.readAsDataURL(blob);
            });
        }
        
        // 导出为 WAV 格式
        async exportAsWav() {
            const data = this.getRecordedData();
            if (!data) {
                throw new Error('没有录制数据');
            }
            
            // WebM -> WAV 需要解码再编码
            const audioContext = this._getAudioContext();
            
            try {
                const arrayBuffer = await data.blob.arrayBuffer();
                const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
                
                // 转换为 WAV
                const wavBuffer = this._audioBufferToWav(audioBuffer);
                
                return new Blob([wavBuffer], { type: 'audio/wav' });
            } catch (e) {
                console.error('[AudioRecorder] WAV 转换失败:', e);
                throw e;
            }
        }
        
        // AudioBuffer 转 WAV
        _audioBufferToWav(buffer) {
            const numChannels = buffer.numberOfChannels;
            const sampleRate = buffer.sampleRate;
            const format = 1; // PCM
            const bitDepth = 16;
            
            const bytesPerSample = bitDepth / 8;
            const blockAlign = numChannels * bytesPerSample;
            
            const samples = buffer.length;
            const dataSize = samples * blockAlign;
            const bufferSize = 44 + dataSize;
            
            const arrayBuffer = new ArrayBuffer(bufferSize);
            const view = new DataView(arrayBuffer);
            
            // WAV 头
            this._writeString(view, 0, 'RIFF');
            view.setUint32(4, bufferSize - 8, true);
            this._writeString(view, 8, 'WAVE');
            this._writeString(view, 12, 'fmt ');
            view.setUint32(16, 16, true);
            view.setUint16(20, format, true);
            view.setUint16(22, numChannels, true);
            view.setUint32(24, sampleRate, true);
            view.setUint32(28, sampleRate * blockAlign, true);
            view.setUint16(32, blockAlign, true);
            view.setUint16(34, bitDepth, true);
            this._writeString(view, 36, 'data');
            view.setUint32(40, dataSize, true);
            
            // 写入音频数据
            const channels = [];
            for (let i = 0; i < numChannels; i++) {
                channels.push(buffer.getChannelData(i));
            }
            
            let offset = 44;
            for (let i = 0; i < samples; i++) {
                for (let ch = 0; ch < numChannels; ch++) {
                    let sample = channels[ch][i];
                    sample = Math.max(-1, Math.min(1, sample));
                    sample = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
                    view.setInt16(offset, sample, true);
                    offset += 2;
                }
            }
            
            return arrayBuffer;
        }
        
        _writeString(view, offset, string) {
            for (let i = 0; i < string.length; i++) {
                view.setUint8(offset + i, string.charCodeAt(i));
            }
        }
        
        // 清理资源
        _cleanup() {
            this.isRecording = false;
            this.isPaused = false;
            this.recordedChunks = [];
            
            // 断开所有音频节点
            this.audioNodes.forEach(node => {
                try {
                    if (node.source) {
                        node.source.disconnect();
                    }
                } catch (e) {}
            });
            this.audioNodes = [];
            
            // 关闭音频上下文
            if (this.audioContext && this.audioContext.state !== 'closed') {
                // 延迟关闭
                setTimeout(() => {
                    try {
                        this.audioContext.close();
                    } catch (e) {}
                    this.audioContext = null;
                }, 100);
            }
        }
        
        // 完全清理
        cleanup() {
            this._cleanup();
            if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
                try {
                    this.mediaRecorder.stop();
                } catch (e) {}
            }
            this.mediaRecorder = null;
            console.log('[AudioRecorder] 已清理');
        }
    }
    
    // 导出到全局
    window.__web_audio_recorder__ = new WebAudioRecorder();
    
    return window.__web_audio_recorder__;
})();
`;

// 导出给 Playwright 使用
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { WEB_AUDIO_RECORDER_JS };
}

// 如果在浏览器环境，直接执行
if (typeof window !== 'undefined') {
    // 等待 DOM 加载完成
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            eval(WEB_AUDIO_RECORDER_JS);
        });
    } else {
        eval(WEB_AUDIO_RECORDER_JS);
    }
}
