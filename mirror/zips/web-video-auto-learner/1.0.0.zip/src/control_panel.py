import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
import copy
import queue
import time
import os

from .browser import BrowserManager


class ControlPanel:
    def __init__(self, config_loader, browser, task_runner, popup_handler, logger, mode='all'):
        self.config_loader = config_loader
        self.browser = browser
        self.task_runner = task_runner
        self.popup_handler = popup_handler
        self.logger = logger
        self.mode = mode  # 'all', 'simple', 'list'

        self.root = tk.Tk()
        self.root.resizable(True, True)

        # 根据模式设置窗口
        if mode == 'all':
            self.root.title("网站自动化控制系统")
            self.root.geometry("960x780")
            self.root.minsize(900, 680)
        else:
            self.root.title("网站自动化控制 - 简约模式")
            self.root.geometry("680x520")
            self.root.minsize(600, 400)

        # 预初始化所有跨方法引用的变量（确保 simple/list 模式下不会 AttributeError）
        self._init_shared_vars()

        # 回调
        self.on_start = None
        self.on_pause = None
        self.on_resume = None
        self.on_stop = None

        self._build_ui()
        self._redirect_log()
        self._load_config_to_ui()

        # Playwright 线程安全桥接：所有 Playwright 调用必须回到主线程执行
        self._pw_queue = queue.Queue()  # (fn, result_event, result_box)

        # 启动主线程 Playwright 调度器
        self._schedule_pw_calls()

        # 设置 TaskRunner 的 Playwright 线程安全调用器
        self.task_runner.set_pw_caller(self.call_on_main_thread)

        # 设置播放列表项完成回调（在主线程中同步完成状态到 GUI 和配置文件）
        self.task_runner.set_on_play_list_completed_cb(self._sync_play_list_completed_from_runner)

    def _init_shared_vars(self):
        """预初始化所有跨方法引用的变量，确保 simple/list 模式下不会 AttributeError。
        这些变量在 all 模式下会被 _build_xxx 方法中的实际控件覆盖。"""
        # 浏览器 & 网站设置变量
        self.browser_type_var = tk.StringVar(value="chrome")
        self.window_max_var = tk.BooleanVar(value=True)
        self.timeout_var = tk.StringVar(value="60000")
        self.loop_run_var = tk.BooleanVar(value=False)
        self.retry_var = tk.StringVar(value="2")
        self.login_url_var = tk.StringVar()
        self.wait_after_login_var = tk.StringVar(value="5")
        self.popup_scan_interval_var = tk.StringVar(value="0.5")

        # 登录信息保存
        self.storage_status_var = tk.StringVar(value="未保存")
        self._storage_state = False
        self._storage_state_file = "storage_state.json"

        # 步骤编辑区变量
        self._current_step_idx = -1
        self._candidate_data = None
        self.step_vars = {}
        self._param_widgets = {}
        self._loop_infinite_var = tk.BooleanVar(value=False)
        self._on_end_action_var = tk.StringVar()
        self._on_end_target_var = tk.StringVar()
        self._on_end_wait_var = tk.StringVar(value="0")
        self._on_end_tab_var = tk.StringVar(value="-1")
        self._current_step_popup_rules = []
        self._current_step_popup_idx = -1

        # 导航/弹窗数据
        self._nav_data = []
        self._popup_data = []

        # 播放列表编辑变量
        self._play_list_url_var = tk.StringVar()
        self._play_list_selector_var = tk.StringVar()
        self._play_list_click_play_var = tk.BooleanVar(value=False)
        self._play_list_completed_var = tk.BooleanVar(value=False)
        self._play_list_enable_recording_var = tk.BooleanVar(value=False)  # 录音开关
        self._play_list_audio_name_var = tk.StringVar()  # 录音名称
        self._play_list_recording_format_var = tk.StringVar(value='WEBM')  # 录音格式

        # 停留统计
        self._stay_summary_labels = []

        # 弹窗编辑变量
        self._current_popup_idx = -1

        # 标签页数据
        self._tab_data = []

        # 拾取模式
        self._inspect_poll_count = 0
        self._page_before_pick = None

        # 窗口状态
        self._window_was_maximized = False

        # 浏览器关闭监控状态
        self._browser_close_monitor_active = False
        self._browser_recovery_attempt = 0       # 浏览器恢复重试计数

        # 简约模式播放列表变量
        self._simple_play_list_vars = {}

        # 播放列表点选模式（list 模式专用）
        self._play_list_pick_mode = False
        self._play_list_pick_target = None
        self._play_list_pick_cancel_btn = None
        self._play_list_pick_start_btn = None

    # ================================================================
    #  UI 构建
    # ================================================================
    def _build_ui(self):
        if self.mode == 'all':
            self._build_full_ui()
        elif self.mode == 'simple':
            self._build_simple_ui()
        elif self.mode == 'list':
            self._build_list_ui()

    def _build_full_ui(self):
        """完整版 UI（默认）"""
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # --- Tab 1: 控制台 ---
        ctrl_frame = ttk.Frame(notebook)
        notebook.add(ctrl_frame, text=" 控制台 ")
        self._build_control_tab(ctrl_frame)

        # --- Tab 2: 浏览器 & 网站 ---
        site_frame = ttk.Frame(notebook)
        notebook.add(site_frame, text=" 浏览器 & 网站 ")
        self._build_site_tab(site_frame)

        # --- Tab 3: 步骤配置 ---
        step_frame = ttk.Frame(notebook)
        notebook.add(step_frame, text=" 步骤配置 ")
        self._build_step_tab(step_frame)

        # --- Tab 4: 全局弹窗规则 ---
        popup_frame = ttk.Frame(notebook)
        notebook.add(popup_frame, text=" 全局弹窗规则 ")
        self._build_popup_tab(popup_frame)

        # --- Tab 5: 停留统计 ---
        stay_frame = ttk.Frame(notebook)
        notebook.add(stay_frame, text=" 停留统计 ")
        self._build_stay_tab(stay_frame)

        self._notebook = notebook

    def _build_simple_ui(self):
        """简约版 UI：仅控制台（隐藏运行日志和调试信息）"""
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self._build_simple_control_tab(main_frame)

    def _build_list_ui(self):
        """简约版 + 按列表播放设置 UI"""
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # 上半部分：简约控制台
        self._build_simple_control_tab(main_frame)

        # 下半部分：动态生成的播放列表设置
        self._build_list_settings(main_frame)

    def _build_simple_control_tab(self, parent):
        """简约版控制台：状态栏 + 按钮，无日志和调试"""
        # 状态栏
        status_f = ttk.LabelFrame(parent, text="运行状态", padding=5)
        status_f.pack(fill=tk.X, padx=5, pady=3)

        self.status_label = ttk.Label(status_f, text="状态: 等待启动", foreground="blue",
                                      font=("", 11, "bold"))
        self.status_label.pack(side=tk.LEFT, padx=10)

        self.page_info_label = ttk.Label(status_f, text="", foreground="gray")
        self.page_info_label.pack(side=tk.RIGHT, padx=10)

        # 按钮行
        btn_f = ttk.Frame(parent, padding=5)
        btn_f.pack(fill=tk.X, padx=5)

        self.start_btn = ttk.Button(btn_f, text="▶ 开始自动化", command=self._on_start_click)
        self.start_btn.pack(side=tk.LEFT, padx=3)

        self.pause_btn = ttk.Button(btn_f, text="⏸ 暂停", command=self._on_pause_click, state=tk.DISABLED)
        self.pause_btn.pack(side=tk.LEFT, padx=3)

        self.stop_btn = ttk.Button(btn_f, text="⏹ 停止", command=self._on_stop_click, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=3)

        ttk.Separator(btn_f, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)

        self.step_mode_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(btn_f, text="单步调试", variable=self.step_mode_var,
                        command=self._toggle_step_mode).pack(side=tk.LEFT, padx=3)

        self.step_next_btn = ttk.Button(btn_f, text="⏭ 下一步", command=self._on_step_next,
                                        state=tk.DISABLED)
        self.step_next_btn.pack(side=tk.LEFT, padx=3)

        self.finish_last_btn = ttk.Button(btn_f, text="✅ 完成最后步骤", command=self._on_finish_last_step,
                                          state=tk.DISABLED)
        self.finish_last_btn.pack(side=tk.LEFT, padx=3)

        ttk.Separator(btn_f, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)

        self.keep_listen_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(btn_f, text="结束后保持监听", variable=self.keep_listen_var,
                        command=self._toggle_keep_listen).pack(side=tk.LEFT, padx=3)

        # 简约模式下仍创建隐藏的 log_text 和 debug_text（避免其他方法引用报错）
        self.log_text = scrolledtext.ScrolledText(parent, wrap=tk.WORD, font=("Consolas", 9), height=0)
        self.debug_text = scrolledtext.ScrolledText(parent, height=0, wrap=tk.WORD,
                                                     font=("Consolas", 9), foreground="#006600")

    def _build_list_settings(self, parent):
        """list 模式下生成播放列表设置，保留 all 模式 play_list 的完整功能
        （不包含"选择器候选"和"步骤专属弹窗规则"）"""
        # 从配置中提取所有 play_list 步骤
        navigation = self.config_loader.get_navigation()
        play_list_steps = [nav for nav in navigation if nav.get('action') == 'play_list']

        if not play_list_steps:
            ttk.Label(parent, text="（未发现播放列表步骤）", foreground="gray").pack(pady=5)
            return

        # 为每个 play_list 步骤创建设置区域
        list_notebook = ttk.Notebook(parent)
        list_notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self._simple_play_list_vars = {}  # 存储各列表项的变量

        for step_idx, step in enumerate(play_list_steps):
            step_name = step.get('name', f'播放列表{step_idx + 1}')
            play_list_data = step.get('play_list', [])

            tab_frame = ttk.Frame(list_notebook)
            list_notebook.add(tab_frame, text=f" {step_name} ")

            # --- 播放列表表格 ---
            table_frame = ttk.Frame(tab_frame)
            table_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
            table_frame.columnconfigure(0, weight=1)
            table_frame.rowconfigure(0, weight=1)

            columns = ('#', '播放网页URL', '选择器', '点击播放', '已完成', '录音文件')
            tree = ttk.Treeview(table_frame, columns=columns, show='headings', height=6)
            tree.heading('#', text='#')
            tree.heading('播放网页URL', text='播放网页URL')
            tree.heading('选择器', text='选择器(可选)')
            tree.heading('点击播放', text='点击播放')
            tree.heading('已完成', text='已完成')
            tree.heading('录音文件', text='录音文件')
            tree.column('#', width=30, anchor=tk.CENTER)
            tree.column('播放网页URL', width=200, anchor=tk.W)
            tree.column('选择器', width=100, anchor=tk.W)
            tree.column('点击播放', width=60, anchor=tk.CENTER)
            tree.column('已完成', width=50, anchor=tk.CENTER)
            tree.column('录音文件', width=120, anchor=tk.W)

            scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
            tree.configure(yscrollcommand=scrollbar.set)
            tree.grid(row=0, column=0, sticky=tk.NSEW)
            scrollbar.grid(row=0, column=1, sticky=tk.NS)

            # 加载数据
            for i, entry in enumerate(play_list_data, 1):
                url = entry.get('url', '') or entry.get('播放网页url', '')
                selector = entry.get('选择器', '')
                click_play = '✓' if entry.get('click_play', False) else '□'
                completed = '✓' if (entry.get('completed', False) or entry.get('是否已完成播放', False)) else '□'
                audio_file = entry.get('audio_file', '') or ''
                tree.insert('', tk.END, values=(i, url, selector, click_play, completed, audio_file))

            # --- 按钮区域 ---
            btn_frame = ttk.Frame(tab_frame)
            btn_frame.pack(fill=tk.X, padx=5, pady=(5, 0))

            step_key = (step_idx, id(step))

            def _make_add_handler(t=tree, sk=step_key, pl_data=play_list_data):
                def _add():
                    idx = len(t.get_children()) + 1
                    t.insert('', tk.END, values=(idx, '', '', '□', '□', ''))
                    pl_data.append({'url': '', '选择器': '', 'click_play': False, 'completed': False, 'audio_file': '', 'audio_name': ''})
                    self._sync_list_step_data(sk, pl_data)
                return _add

            def _make_delete_handler(t=tree, sk=step_key, pl_data=play_list_data):
                def _delete():
                    sel = t.selection()
                    if not sel:
                        return
                    idx = t.index(sel[0])
                    t.delete(sel[0])
                    if 0 <= idx < len(pl_data):
                        del pl_data[idx]
                    # 重新编号
                    for i, item in enumerate(t.get_children()):
                        vals = list(t.item(item)['values'])
                        vals[0] = i + 1
                        t.item(item, values=vals)
                    self._sync_list_step_data(sk, pl_data)
                return _delete

            def _make_up_handler(t=tree, sk=step_key, pl_data=play_list_data):
                def _up():
                    sel = t.selection()
                    if not sel:
                        return
                    idx = t.index(sel[0])
                    if idx == 0:
                        return
                    # 交换树数据
                    prev_item = t.get_children()[idx - 1]
                    cur_vals = list(t.item(sel[0])['values'])
                    prev_vals = list(t.item(prev_item)['values'])
                    cur_vals[0], prev_vals[0] = idx, idx + 1
                    t.item(sel[0], values=cur_vals)
                    t.item(prev_item, values=prev_vals)
                    t.move(sel[0], '', idx - 1)
                    # 交换内存数据
                    if 0 <= idx < len(pl_data):
                        pl_data[idx], pl_data[idx - 1] = pl_data[idx - 1], pl_data[idx]
                    self._sync_list_step_data(sk, pl_data)
                return _up

            def _make_down_handler(t=tree, sk=step_key, pl_data=play_list_data):
                def _down():
                    sel = t.selection()
                    if not sel:
                        return
                    idx = t.index(sel[0])
                    children = t.get_children()
                    if idx >= len(children) - 1:
                        return
                    next_item = children[idx + 1]
                    cur_vals = list(t.item(sel[0])['values'])
                    next_vals = list(t.item(next_item)['values'])
                    cur_vals[0], next_vals[0] = idx + 2, idx + 1
                    t.item(sel[0], values=cur_vals)
                    t.item(next_item, values=next_vals)
                    t.move(sel[0], '', idx + 1)
                    if 0 <= idx < len(pl_data) - 1:
                        pl_data[idx], pl_data[idx + 1] = pl_data[idx + 1], pl_data[idx]
                    self._sync_list_step_data(sk, pl_data)
                return _down

            ttk.Button(btn_frame, text="+ 添加行", width=10, command=_make_add_handler()).pack(side=tk.LEFT, padx=2)
            ttk.Button(btn_frame, text="- 删除选中", width=10, command=_make_delete_handler()).pack(side=tk.LEFT, padx=2)
            ttk.Button(btn_frame, text="↑ 上移", width=8, command=_make_up_handler()).pack(side=tk.LEFT, padx=2)
            ttk.Button(btn_frame, text="↓ 下移", width=8, command=_make_down_handler()).pack(side=tk.LEFT, padx=2)

            # --- 编辑区域 ---
            edit_frame = ttk.LabelFrame(tab_frame, text="编辑选中行", padding=5)
            edit_frame.pack(fill=tk.X, padx=5, pady=(5, 0))
            edit_frame.columnconfigure(1, weight=1)

            url_var = tk.StringVar()
            selector_var = tk.StringVar()
            click_play_var = tk.BooleanVar(value=False)
            completed_var = tk.BooleanVar(value=False)
            audio_name_var = tk.StringVar()

            # 第一行：URL + 已完成 + 保存
            ttk.Label(edit_frame, text="URL:").grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
            ttk.Entry(edit_frame, textvariable=url_var, width=40).grid(row=0, column=1, sticky=tk.EW, padx=(0, 10))

            ttk.Label(edit_frame, text="已完成:").grid(row=0, column=2, sticky=tk.W, padx=(0, 5))
            ttk.Checkbutton(edit_frame, text="✓", variable=completed_var).grid(row=0, column=3, sticky=tk.W)

            # 保存按钮
            def _make_save_handler(t=tree, uv=url_var, sv=selector_var, cpv=click_play_var, cv=completed_var,
                                   anv=audio_name_var, sk=step_key, sn=step_name, pl_data=play_list_data):
                def _save():
                    sel = t.selection()
                    if not sel:
                        return
                    url = uv.get().strip()
                    
                    # URL重复检测
                    if url:
                        # 获取所有播放列表项
                        all_items = t.get_children()
                        current_item_idx = t.index(sel[0])
                        
                        # 检查是否有其他行包含相同的URL
                        duplicate_indices = []
                        for i, item in enumerate(all_items):
                            if i == current_item_idx:  # 跳过当前正在编辑的行
                                continue
                            values = t.item(item)['values']
                            if len(values) >= 5 and values[1] == url:  # values[1] 是URL
                                duplicate_indices.append(i + 1)  # 显示行号从1开始
                        
                        if duplicate_indices:
                            messagebox.showerror(
                                "URL重复检测", 
                                f"检测到URL重复！\n\n"
                                f"当前URL: {url}\n"
                                f"重复行号: {', '.join(map(str, duplicate_indices))}\n\n"
                                f"请修改URL或删除重复项，避免重复添加相同的学习网页。"
                            )
                            return
                    
                    selector = sv.get().strip()
                    click_play = '✓' if cpv.get() else '□'
                    completed = '✓' if cv.get() else '□'
                    audio_name = anv.get().strip()
                    # 保留已有的录音文件信息
                    existing_vals = list(t.item(sel[0])['values'])
                    audio_file = existing_vals[5] if len(existing_vals) >= 6 else ''
                    idx = t.index(sel[0])
                    t.item(sel[0], values=(idx + 1, url, selector, click_play, completed, audio_file))
                    # 同步到内存数据
                    if 0 <= idx < len(pl_data):
                        pl_data[idx]['url'] = url
                        pl_data[idx]['选择器'] = selector
                        pl_data[idx]['click_play'] = cpv.get()
                        pl_data[idx]['completed'] = cv.get()
                        pl_data[idx]['audio_name'] = audio_name
                        # 保留已有的录音文件信息
                        if not pl_data[idx].get('audio_file') and audio_file:
                            pl_data[idx]['audio_file'] = audio_file
                    self._sync_list_step_data(sk, pl_data)
                return _save

            ttk.Button(edit_frame, text="💾 保存修改", width=12, command=_make_save_handler()).grid(
                row=0, column=4, padx=(10, 0))

            # 第二行：选择器 + 按钮（点选/取消/扫描媒体/点击播放）
            ttk.Label(edit_frame, text="选择器:").grid(row=1, column=0, sticky=tk.W, padx=(0, 5), pady=(5, 0))
            ttk.Entry(edit_frame, textvariable=selector_var, width=30).grid(
                row=1, column=1, sticky=tk.EW, padx=(0, 5), pady=(5, 0))

            sel_btn_frame = ttk.Frame(edit_frame)
            sel_btn_frame.grid(row=1, column=2, columnspan=3, sticky=tk.W, pady=(5, 0))

            # 点选按钮
            pick_btn = ttk.Button(sel_btn_frame, text="🎯 点选", width=6)
            pick_btn.pack(side=tk.LEFT, padx=(0, 2))

            # 取消按钮
            cancel_pick_btn = ttk.Button(sel_btn_frame, text="✕ 取消", width=6, state=tk.DISABLED)
            cancel_pick_btn.pack(side=tk.LEFT, padx=(0, 2))

            # 扫描媒体按钮
            def _make_scan_handler(t=tree, sv=selector_var, sk=step_key, sn=step_name):
                def _scan():
                    self._play_list_scan_selector_list_mode(sv, sn)
                return _scan

            ttk.Button(sel_btn_frame, text="🔍 扫描媒体", width=10,
                       command=_make_scan_handler()).pack(side=tk.LEFT, padx=(0, 2))

            # 点击播放按钮
            def _make_click_play_handler(t=tree, sv=selector_var, sn=step_name):
                def _click():
                    self._play_list_click_play_list_mode(sv, sn)
                return _click

            ttk.Button(sel_btn_frame, text="▶ 点击播放", width=10,
                       command=_make_click_play_handler()).pack(side=tk.LEFT, padx=(0, 2))

            # 选择器提示
            ttk.Label(edit_frame, text="(留空则自动查找)", foreground="gray",
                      font=("", 8)).grid(row=1, column=5, sticky=tk.W, pady=(5, 0))

            # 第三行：自动点击播放复选框
            ttk.Checkbutton(edit_frame, text="▶ 自动点击播放（打开网页后模拟鼠标点击播放器）",
                            variable=click_play_var).grid(row=2, column=0, columnspan=4, sticky=tk.W, pady=(5, 0))

            # 第四行：音频录制开关 + 格式选择
            recording_var = tk.BooleanVar(value=step.get('enable_recording', False))
            ttk.Checkbutton(edit_frame, text="🎙️ 启用音频录制（播放时录制视频声音）",
                            variable=recording_var).grid(row=3, column=0, columnspan=2, sticky=tk.W, pady=(5, 0))
            ttk.Label(edit_frame, text="录制格式:").grid(row=3, column=2, sticky=tk.E, padx=(10, 2), pady=(5, 0))
            recording_format_var = tk.StringVar(value=step.get('recording_format', 'WEBM'))
            format_combo = ttk.Combobox(edit_frame, textvariable=recording_format_var,
                                         values=['WEBM', 'WAV', 'MP3', 'M4A'], state='readonly', width=8)
            format_combo.grid(row=3, column=3, sticky=tk.W, padx=(0, 5), pady=(5, 0))

            # 第五行：录音名称 + 播放录音按钮 + 总结按钮
            ttk.Label(edit_frame, text="录音名称:").grid(row=4, column=0, sticky=tk.W, padx=(0, 5), pady=(5, 0))
            ttk.Entry(edit_frame, textvariable=audio_name_var, width=30).grid(
                row=4, column=1, sticky=tk.EW, padx=(0, 10), pady=(5, 0))

            def _make_play_recording_handler(t=tree, sn=step_name):
                def _play():
                    sel = t.selection()
                    if not sel:
                        messagebox.showwarning("播放录音", "请先在表格中选中一个包含录音文件的播放列表行。")
                        return
                    values = t.item(sel[0])['values']
                    audio_file = values[5] if len(values) >= 6 else ''
                    if not audio_file:
                        messagebox.showinfo("播放录音", "当前选中行没有录音文件。\n\n请先启用音频录制并完成播放后，录音文件会自动保存。")
                        return
                    skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                    abs_path = os.path.join(skill_dir, audio_file)
                    if not os.path.exists(abs_path):
                        messagebox.showerror("播放录音", f"录音文件不存在:\n{abs_path}")
                        return
                    self.logger.info(f"[播放录音] 打开: {abs_path}")
                    self._open_file(abs_path)
                return _play

            ttk.Button(edit_frame, text="▶ 播放录音", width=12,
                       command=_make_play_recording_handler()).grid(row=4, column=2, sticky=tk.W, padx=(0, 5), pady=(5, 0))

            # 总结按钮
            def _make_summarize_handler(t=tree, pl_data=play_list_data):
                def _summarize():
                    sel = t.selection()
                    if not sel:
                        messagebox.showwarning("AI总结", "请先在表格中选中一个包含录音文件的播放列表行。")
                        return
                    values = t.item(sel[0])['values']
                    audio_file = values[5] if len(values) >= 6 else ''
                    if not audio_file:
                        messagebox.showinfo("AI总结", "当前选中行没有录音文件。\n\n请先启用音频录制并完成播放后，再使用总结功能。")
                        return
                    skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                    abs_path = os.path.join(skill_dir, audio_file)
                    if not os.path.exists(abs_path):
                        messagebox.showerror("AI总结", f"录音文件不存在:\n{abs_path}")
                        return
                    # 获取音频名称
                    idx = t.index(sel[0])
                    audio_name = ''
                    if idx < len(pl_data):
                        audio_name = pl_data[idx].get('audio_name', '')
                    # 在新线程中执行总结
                    threading.Thread(target=self._do_summarize_audio,
                                     args=(abs_path, audio_name), daemon=True).start()
                return _summarize

            ttk.Button(edit_frame, text="📝 总结", width=10,
                       command=_make_summarize_handler()).grid(row=4, column=3, sticky=tk.W, padx=(0, 5), pady=(5, 0))
            ttk.Label(edit_frame, text="(选中行后可播放录音、修改名称、AI总结)",
                      foreground="gray", font=("", 8)).grid(row=4, column=4, columnspan=2, sticky=tk.W, pady=(5, 0))

            # 选中行时加载到编辑区
            def _make_select_handler(t=tree, uv=url_var, sv=selector_var, cpv=click_play_var, cv=completed_var, anv=audio_name_var, pl_data=play_list_data):
                def _on_select(event=None):
                    sel = t.selection()
                    if not sel:
                        return
                    values = t.item(sel[0])['values']
                    if len(values) >= 5:
                        uv.set(values[1] if len(values) > 1 else '')
                        sv.set(values[2] if len(values) > 2 else '')
                        cpv.set(values[3] == '✓')
                        cv.set(values[4] == '✓')
                        # 加载录音名称
                        idx = t.index(sel[0])
                        if idx < len(pl_data):
                            anv.set(pl_data[idx].get('audio_name', ''))
                        else:
                            anv.set('')
                return _on_select

            tree.bind('<<TreeviewSelect>>', _make_select_handler())

            # 点选功能
            def _make_pick_handlers(t=tree, sv=selector_var, pb=pick_btn, cb=cancel_pick_btn, sn=step_name):
                def _start_pick():
                    if not self.browser.page:
                        messagebox.showwarning("提示", "请先启动浏览器")
                        return
                    pb.config(state=tk.DISABLED)
                    cb.config(state=tk.NORMAL)
                    self._play_list_pick_mode = True
                    self._play_list_pick_target = sv
                    self._play_list_pick_cancel_btn = cb
                    self._play_list_pick_start_btn = pb
                    self._start_play_list_pick()

                def _cancel_pick():
                    pb.config(state=tk.NORMAL)
                    cb.config(state=tk.DISABLED)
                    self._play_list_pick_mode = False
                    self.browser.cancel_inspect()
                    self._finish_inspect({'cancelled': True}, 'play_list')

                pb.config(command=_start_pick)
                cb.config(command=_cancel_pick)
                return _start_pick, _cancel_pick

            _make_pick_handlers()

            # --- 说明文字 ---
            ttk.Label(tab_frame,
                      text="💡 说明：URL填播放页面地址，选择器指定媒体元素(留空自动查找)，'点击播放'勾选后打开网页自动点击播放器(适用于懒加载播放器)，'已完成'表示是否已播放完毕。",
                      foreground="#0066cc", font=("", 8), wraplength=600).pack(fill=tk.X, padx=5, pady=(3, 0))

            self._simple_play_list_vars[step_key] = {
                'tree': tree,
                'url_var': url_var,
                'selector_var': selector_var,
                'click_play_var': click_play_var,
                'completed_var': completed_var,
                'recording_var': recording_var,  # 音频录制开关
                'recording_format_var': recording_format_var,  # 音频录制格式
                'play_list_data': play_list_data,
                'step': step,
            }

    def _sync_list_step_data(self, step_key, play_list_data, save_recording=True):
        """将 list 模式下修改的播放列表数据同步到 _nav_data 并保存配置

        Args:
            step_key: 播放列表步骤标识
            play_list_data: 播放列表数据
            save_recording: 是否保存录音设置到 step（默认 True）
        """
        step = self._simple_play_list_vars.get(step_key, {}).get('step')
        if step:
            step['play_list'] = play_list_data
            # 保存录音设置到 step
            if save_recording:
                recording_var = self._simple_play_list_vars.get(step_key, {}).get('recording_var')
                if recording_var:
                    step['enable_recording'] = recording_var.get()
                format_var = self._simple_play_list_vars.get(step_key, {}).get('recording_format_var')
                if format_var:
                    step['recording_format'] = format_var.get()
        # all 模式下也同步 _sync_step_edit_to_data（保存当前步骤编辑区数据）
        # simple/list 模式下 _current_step_idx 为 -1，_sync_step_edit_to_data 会跳过
        if self.mode == 'all' and 0 <= self._current_step_idx < len(self._nav_data):
            self._sync_step_edit_to_data()
        self.config_loader.set_navigation(self._nav_data)
        try:
            self.config_loader.save()
        except Exception as e:
            self.logger.error(f"[播放列表] 保存配置失败: {e}")

    def _play_list_scan_selector_list_mode(self, selector_var, step_name):
        """list 模式下的扫描媒体功能"""
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return

        def _do_scan():
            try:
                self.logger.info(f"[扫描媒体-list模式] 正在扫描 {step_name} ...")
                result = self.call_on_main_thread(lambda: self.browser.scan_media_elements())
                if result:
                    best = result[0]
                    # scan_media_elements 返回 [(selector, type, desc), ...] 格式的元组列表
                    selector_str = best[0] if isinstance(best, (list, tuple)) else best.get('css_selector', '') or best.get('xpath', '')
                    if selector_str:
                        self.call_on_main_thread(lambda: selector_var.set(selector_str))
                        self.logger.info(f"[扫描媒体-list模式] 找到媒体元素: {selector_str}")
                    else:
                        self.logger.warning("[扫描媒体-list模式] 找到媒体元素但无法生成选择器")
                else:
                    self.logger.warning("[扫描媒体-list模式] 未找到媒体元素")
            except Exception as e:
                self.logger.error(f"[扫描媒体-list模式] 扫描失败: {e}")

        threading.Thread(target=_do_scan, daemon=True).start()

    def _play_list_click_play_list_mode(self, selector_var, step_name):
        """list 模式下的点击播放功能"""
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return

        selector = selector_var.get().strip()
        self.logger.info(f"[点击播放-list模式] 尝试点击播放器，选择器: {selector or '(自动)'}")

        def _do_click():
            try:
                if selector:
                    el = self.call_on_main_thread(
                        lambda: self.browser.page.query_selector(self.browser.parse_selector(selector)[0])
                    )
                    if el:
                        self.call_on_main_thread(lambda: el.click())
                        self.logger.info(f"[点击播放-list模式] 已点击选择器元素: {selector}")
                    else:
                        self.logger.warning(f"[点击播放-list模式] 选择器未找到元素: {selector}")
                        self.call_on_main_thread(lambda: self.browser.trigger_xgplayer())
                else:
                    triggered = self.call_on_main_thread(lambda: self.browser.trigger_xgplayer())
                    if triggered:
                        self.logger.info("[点击播放-list模式] xgplayer 触发成功")
                    else:
                        viewport = self.call_on_main_thread(lambda: self.browser.page.viewport_size)
                        if viewport:
                            cx = viewport['width'] // 2
                            cy = viewport['height'] // 3
                            self.call_on_main_thread(lambda: self.browser.page.mouse.click(cx, cy))
                            self.logger.info(f"[点击播放-list模式] 已点击页面坐标 ({cx}, {cy})")
                        else:
                            self.logger.warning("[点击播放-list模式] 未找到可点击的播放器元素")
            except Exception as e:
                self.logger.error(f"[点击播放-list模式] 点击播放失败: {e}")

        threading.Thread(target=_do_click, daemon=True).start()

    # ---------------------- 控制台 Tab ----------------------
    def _build_control_tab(self, parent):
        # 状态栏
        status_f = ttk.LabelFrame(parent, text="运行状态", padding=5)
        status_f.pack(fill=tk.X, padx=5, pady=3)

        self.status_label = ttk.Label(status_f, text="状态: 等待启动", foreground="blue",
                                      font=("", 11, "bold"))
        self.status_label.pack(side=tk.LEFT, padx=10)

        self.page_info_label = ttk.Label(status_f, text="", foreground="gray")
        self.page_info_label.pack(side=tk.RIGHT, padx=10)

        # 按钮行
        btn_f = ttk.Frame(parent, padding=5)
        btn_f.pack(fill=tk.X, padx=5)

        self.start_btn = ttk.Button(btn_f, text="▶ 开始自动化", command=self._on_start_click)
        self.start_btn.pack(side=tk.LEFT, padx=3)

        self.pause_btn = ttk.Button(btn_f, text="⏸ 暂停", command=self._on_pause_click, state=tk.DISABLED)
        self.pause_btn.pack(side=tk.LEFT, padx=3)

        self.stop_btn = ttk.Button(btn_f, text="⏹ 停止", command=self._on_stop_click, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=3)

        ttk.Separator(btn_f, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)

        self.step_mode_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(btn_f, text="单步调试", variable=self.step_mode_var,
                        command=self._toggle_step_mode).pack(side=tk.LEFT, padx=3)

        self.step_next_btn = ttk.Button(btn_f, text="⏭ 下一步", command=self._on_step_next,
                                        state=tk.DISABLED)
        self.step_next_btn.pack(side=tk.LEFT, padx=3)

        self.finish_last_btn = ttk.Button(btn_f, text="✅ 完成最后步骤", command=self._on_finish_last_step,
                                          state=tk.DISABLED)
        self.finish_last_btn.pack(side=tk.LEFT, padx=3)

        ttk.Separator(btn_f, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)

        self.keep_listen_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(btn_f, text="结束后保持监听", variable=self.keep_listen_var,
                        command=self._toggle_keep_listen).pack(side=tk.LEFT, padx=3)

        # 日志
        log_f = ttk.LabelFrame(parent, text="运行日志", padding=3)
        log_f.pack(fill=tk.BOTH, expand=True, padx=5, pady=3)

        self.log_text = scrolledtext.ScrolledText(log_f, wrap=tk.WORD, font=("Consolas", 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_text.config(state=tk.DISABLED)

        # 调试信息
        dbg_f = ttk.LabelFrame(parent, text="调试信息", padding=3)
        dbg_f.pack(fill=tk.X, padx=5, pady=3)

        self.debug_text = scrolledtext.ScrolledText(dbg_f, height=6, wrap=tk.WORD,
                                                     font=("Consolas", 9), foreground="#006600")
        self.debug_text.pack(fill=tk.BOTH, expand=True)
        self.debug_text.config(state=tk.DISABLED)

    # ---------------------- 浏览器 & 网站 Tab ----------------------
    def _build_site_tab(self, parent):
        # 浏览器设置
        br_f = ttk.LabelFrame(parent, text="浏览器设置", padding=10)
        br_f.pack(fill=tk.X, padx=10, pady=5)

        ttk.Label(br_f, text="浏览器类型:").grid(row=0, column=0, sticky=tk.W, pady=3)
        self.browser_type_var = tk.StringVar(value="chrome")
        cb = ttk.Combobox(br_f, textvariable=self.browser_type_var, width=18,
                          values=["chrome", "msedge", "360ee", "360se", "firefox", "webkit"], state="readonly")
        cb.grid(row=0, column=1, sticky=tk.W, padx=5, pady=3)

        self.window_max_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(br_f, text="最大化窗口", variable=self.window_max_var).grid(
            row=0, column=2, padx=15, pady=3)

        ttk.Label(br_f, text="全局超时(ms):").grid(row=1, column=0, sticky=tk.W, pady=3)
        self.timeout_var = tk.StringVar(value="60000")
        ttk.Entry(br_f, textvariable=self.timeout_var, width=15).grid(row=1, column=1, sticky=tk.W, padx=5)

        self.loop_run_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(br_f, text="循环执行", variable=self.loop_run_var).grid(
            row=1, column=2, padx=15, pady=3)

        ttk.Label(br_f, text="失败重试次数:").grid(row=2, column=0, sticky=tk.W, pady=3)
        self.retry_var = tk.StringVar(value="2")
        ttk.Entry(br_f, textvariable=self.retry_var, width=15).grid(row=2, column=1, sticky=tk.W, padx=5)

        # 网站设置
        ws_f = ttk.LabelFrame(parent, text="目标网站", padding=10)
        ws_f.pack(fill=tk.X, padx=10, pady=5)

        ttk.Label(ws_f, text="登录页面 URL:").grid(row=0, column=0, sticky=tk.W, pady=3)
        self.login_url_var = tk.StringVar()
        ttk.Entry(ws_f, textvariable=self.login_url_var, width=60).grid(
            row=0, column=1, sticky=tk.EW, padx=5, pady=3)

        ttk.Label(ws_f, text="登录后等待(秒):").grid(row=1, column=0, sticky=tk.W, pady=3)
        self.wait_after_login_var = tk.StringVar(value="5")
        ttk.Entry(ws_f, textvariable=self.wait_after_login_var, width=10).grid(
            row=1, column=1, sticky=tk.W, padx=5, pady=3)

        # 登录信息保存
        login_f = ttk.Frame(ws_f)
        login_f.grid(row=2, column=0, columnspan=2, sticky=tk.EW, pady=5)

        self.storage_status_var = tk.StringVar(value="未保存")
        ttk.Label(login_f, text="登录状态:").pack(side=tk.LEFT, padx=(0, 5))
        ttk.Label(login_f, textvariable=self.storage_status_var, foreground="blue").pack(side=tk.LEFT, padx=(0, 15))

        ttk.Button(login_f, text="💾 保存登录信息", command=self._save_storage_state).pack(side=tk.LEFT, padx=5)
        ttk.Button(login_f, text="🗑 清除登录信息", command=self._clear_storage_state).pack(side=tk.LEFT, padx=5)

        ws_f.columnconfigure(1, weight=1)

        # 保存按钮
        ttk.Button(parent, text="💾 保存浏览器 & 网站配置", command=self._save_site_config).pack(
            pady=10)

    # ---------------------- 步骤配置 Tab ----------------------
    def _build_step_tab(self, parent):
        # 列表
        list_f = ttk.Frame(parent)
        list_f.pack(fill=tk.BOTH, expand=True, padx=5, pady=3)

        # 左侧步骤列表
        left_f = ttk.LabelFrame(list_f, text="步骤列表", padding=3)
        left_f.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(0, 5))

        self.step_listbox = tk.Listbox(left_f, width=22, height=18, font=("", 10))
        self.step_listbox.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        self.step_listbox.bind("<<ListboxSelect>>", self._on_step_select)

        sb = ttk.Scrollbar(left_f, orient=tk.VERTICAL, command=self.step_listbox.yview)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.step_listbox.config(yscrollcommand=sb.set)

        # 右侧编辑区（可滚动，适应不同屏幕分辨率）
        right_outer = ttk.Frame(list_f)
        right_outer.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # 创建 Canvas + Scrollbar 实现滚动
        self._step_canvas = tk.Canvas(right_outer, highlightthickness=0)
        step_vsb = ttk.Scrollbar(right_outer, orient=tk.VERTICAL, command=self._step_canvas.yview)
        self._step_canvas.config(yscrollcommand=step_vsb.set)

        step_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self._step_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # 内部可滚动容器
        self._step_scroll_frame = ttk.Frame(self._step_canvas)
        self._step_canvas_window = self._step_canvas.create_window((0, 0), window=self._step_scroll_frame, anchor=tk.NW)

        # 绑定滚动区域更新
        self._step_scroll_frame.bind("<Configure>", self._on_step_scroll_frame_configure)
        self._step_canvas.bind("<Configure>", self._on_step_canvas_configure)

        # 鼠标滚轮支持
        self._step_canvas.bind("<Enter>", lambda e: self._step_canvas.bind_all("<MouseWheel>", self._on_step_mousewheel))
        self._step_canvas.bind("<Leave>", lambda e: self._step_canvas.unbind_all("<MouseWheel>"))

        right_f = ttk.LabelFrame(self._step_scroll_frame, text="步骤编辑", padding=8)
        right_f.pack(fill=tk.BOTH, expand=True)

        # --- 操作定义 ---
        # (action_key, 显示名, 需要选择器, 需要URL, 参数列表)
        # 参数列表: [(key, 显示名, 默认值), ...]
        self.ACTION_DEFS = {
            'navigate': {'label': '导航(URL)', 'need_selector': False, 'need_url': True,
                         'params': []},
            'click':    {'label': '单击',       'need_selector': True,  'need_url': False,
                         'params': []},
            'dblclick': {'label': '双击',       'need_selector': True,  'need_url': False,
                         'params': []},
            'input':    {'label': '输入文本',   'need_selector': True,  'need_url': False,
                         'params': [('input_text', '输入内容', '')]},
            'hover':    {'label': '悬停',       'need_selector': True,  'need_url': False,
                         'params': []},
            'select':   {'label': '选择选项',   'need_selector': True,  'need_url': False,
                         'params': [('select_value', '选项值', '')]},
            'check':    {'label': '勾选',       'need_selector': True,  'need_url': False,
                         'params': []},
            'uncheck':  {'label': '取消勾选',   'need_selector': True,  'need_url': False,
                         'params': []},
            'scroll':   {'label': '滚动到元素', 'need_selector': True,  'need_url': False,
                         'params': []},
            'wait':     {'label': '等待元素',   'need_selector': True,  'need_url': False,
                         'params': []},
            'play':     {'label': '播放媒体',   'need_selector': True,  'need_url': False,
                         'params': []},
            'pause':    {'label': '暂停媒体',   'need_selector': True,  'need_url': False,
                         'params': []},
            'play_wait': {'label': '播放并等待', 'need_selector': True,  'need_url': False,
                          'params': [('media_timeout', '等待超时(秒)', '3600')]},
            'play_next': {'label': '播放并下一曲', 'need_selector': True,  'need_url': False,
                          'params': [('media_timeout', '等待超时(秒)', '3600')]},
            'play_list': {'label': '按列表播放', 'need_selector': False,  'need_url': False,
                          'params': [('media_timeout', '等待超时(秒)', '3600')]},
        }

        # 行0: 名称
        row = 0
        ttk.Label(right_f, text="名称:").grid(row=row, column=0, sticky=tk.W, pady=3)
        self.step_vars = {}
        self.step_vars['step_name'] = tk.StringVar()
        ttk.Entry(right_f, textvariable=self.step_vars['step_name'], width=50).grid(
            row=row, column=1, columnspan=2, sticky=tk.EW, padx=5, pady=3)

        # 行1: 操作类型
        row = 1
        ttk.Label(right_f, text="操作类型:").grid(row=row, column=0, sticky=tk.W, pady=3)
        self.step_vars['step_action'] = tk.StringVar(value='navigate')
        action_labels = [f"{k} - {v['label']}" for k, v in self.ACTION_DEFS.items()]
        self._action_combo = ttk.Combobox(right_f, textvariable=self.step_vars['step_action'],
                                          width=22, values=action_labels, state="readonly")
        self._action_combo.grid(row=row, column=1, sticky=tk.W, padx=5, pady=3)
        self._action_combo.bind("<<ComboboxSelected>>", self._on_action_changed)

        # 行2: 目标标签页
        row = 2
        self._tab_label = ttk.Label(right_f, text="目标标签页:")
        self._tab_label.grid(row=row, column=0, sticky=tk.W, pady=3)
        self._tab_frame = ttk.Frame(right_f)
        self._tab_frame.grid(row=row, column=1, columnspan=2, sticky=tk.EW, padx=5, pady=3)
        self.step_vars['step_tab_index'] = tk.StringVar(value='-1')
        self._tab_combo = ttk.Combobox(self._tab_frame,
                                       width=30, state="readonly")
        self._tab_combo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._tab_refresh_btn = ttk.Button(self._tab_frame, text="🔄", width=3,
                                           command=self._refresh_tab_list)
        self._tab_refresh_btn.pack(side=tk.LEFT, padx=(4, 0))
        self._tab_combo.bind("<<ComboboxSelected>>", self._on_tab_selected)

        # 行3: URL
        row = 3
        self._url_label = ttk.Label(right_f, text="URL:")
        self._url_label.grid(row=row, column=0, sticky=tk.W, pady=3)
        self.step_vars['step_url'] = tk.StringVar()
        self._url_entry = ttk.Entry(right_f, textvariable=self.step_vars['step_url'], width=50)
        self._url_entry.grid(row=row, column=1, columnspan=2, sticky=tk.EW, padx=5, pady=3)

        # 行4: 选择器
        row = 4
        self._sel_label = ttk.Label(right_f, text="选择器:")
        self._sel_label.grid(row=row, column=0, sticky=tk.W, pady=3)
        self._sel_frame = ttk.Frame(right_f)
        self._sel_frame.grid(row=row, column=1, columnspan=2, sticky=tk.EW, padx=5, pady=3)
        self.step_vars['step_selector'] = tk.StringVar()
        ttk.Entry(self._sel_frame, textvariable=self.step_vars['step_selector'], width=38).pack(
            side=tk.LEFT, fill=tk.X, expand=True)
        self._pick_btn = ttk.Button(self._sel_frame, text="🎯 点选", width=6,
                                    command=self._start_pick_element)
        self._pick_btn.pack(side=tk.LEFT, padx=(4, 0))
        self._scan_media_btn = ttk.Button(self._sel_frame, text="🎬 扫描媒体", width=10,
                                          command=self._scan_media_elements, state=tk.DISABLED)
        self._scan_media_btn.pack(side=tk.LEFT, padx=(4, 0))
        self._cancel_pick_btn = ttk.Button(self._sel_frame, text="✕ 取消", width=6,
                                           command=self._cancel_current_pick, state=tk.DISABLED)
        self._cancel_pick_btn.pack(side=tk.LEFT, padx=(2, 0))

        # 行5: 操作参数区（动态生成）
        row = 5
        self._param_frame = ttk.LabelFrame(right_f, text="操作参数", padding=5)
        self._param_frame.grid(row=row, column=0, columnspan=3, sticky=tk.EW, pady=3)
        self._param_widgets = {}  # key -> (label, var, entry)

        # 行5.5: 媒体播放完成设置区（仅 play_wait / play_next 时显示）
        self._media_end_frame = ttk.LabelFrame(right_f, text="🎬 媒体播放完成设置", padding=8)
        self._media_end_frame.grid(row=5, column=0, columnspan=3, sticky=tk.EW, pady=3)
        # 初始隐藏
        self._media_end_frame.grid_remove()

        # --- 播放结束后操作 ---
        self._media_end_row = 0
        self._media_end_action_label = ttk.Label(self._media_end_frame, text="结束后操作:")
        self._media_end_action_label.grid(row=0, column=0, sticky=tk.W, pady=3)
        self._on_end_action_var = tk.StringVar(value='none - 无操作')
        self._on_end_action_combo = ttk.Combobox(
            self._media_end_frame, textvariable=self._on_end_action_var, width=22,
            values=['none - 无操作', 'click - 点击元素', 'navigate - 跳转URL',
                    'play_next - 播放下一媒体', 'wait - 等待(秒)', 'refresh - 刷新页面'],
            state="readonly")
        self._on_end_action_combo.grid(row=0, column=1, sticky=tk.W, padx=5, pady=3)
        self._on_end_action_combo.bind("<<ComboboxSelected>>", self._on_media_end_action_changed)

        # --- 结束后目标（选择器/URL/秒数，根据操作类型动态提示） ---
        self._media_end_target_label = ttk.Label(self._media_end_frame, text="目标选择器:")
        self._media_end_target_label.grid(row=1, column=0, sticky=tk.W, pady=3)
        target_inner = ttk.Frame(self._media_end_frame)
        target_inner.grid(row=1, column=1, sticky=tk.EW, padx=5, pady=3)
        self._on_end_target_var = tk.StringVar()
        self._on_end_target_entry = ttk.Entry(target_inner, textvariable=self._on_end_target_var, width=34)
        self._on_end_target_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._media_end_pick_btn = ttk.Button(target_inner, text="🎯 点选", width=6,
                                               command=self._start_media_end_pick, state=tk.DISABLED)
        self._media_end_pick_btn.pack(side=tk.LEFT, padx=(4, 0))
        self._on_end_target_hint = ttk.Label(target_inner, text="", foreground="gray", font=("", 8))
        self._on_end_target_hint.pack(side=tk.LEFT, padx=(5, 0))

        # --- 目标标签页（仅 click / play_next 时显示） ---
        self._media_end_tab_label = ttk.Label(self._media_end_frame, text="目标标签页:")
        self._media_end_tab_label.grid(row=2, column=0, sticky=tk.W, pady=3)
        self._media_end_tab_frame = ttk.Frame(self._media_end_frame)
        self._media_end_tab_frame.grid(row=2, column=1, sticky=tk.EW, padx=5, pady=3)
        self._on_end_tab_var = tk.StringVar(value='-1')
        self._media_end_tab_combo = ttk.Combobox(self._media_end_tab_frame, width=28, state="readonly")
        self._media_end_tab_combo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._media_end_tab_refresh_btn = ttk.Button(self._media_end_tab_frame, text="🔄", width=3,
                                                      command=self._refresh_media_end_tab_list)
        self._media_end_tab_refresh_btn.pack(side=tk.LEFT, padx=(4, 0))
        self._media_end_tab_combo.bind("<<ComboboxSelected>>", self._on_media_end_tab_selected)
        self._media_end_tab_data = []
        # 初始隐藏
        self._media_end_tab_label.grid_remove()
        self._media_end_tab_frame.grid_remove()

        # --- 结束后再等待（秒） ---
        self._media_end_wait_label = ttk.Label(self._media_end_frame, text="结束后等待(秒):")
        self._media_end_wait_label.grid(row=3, column=0, sticky=tk.W, pady=3)
        wait_inner = ttk.Frame(self._media_end_frame)
        wait_inner.grid(row=3, column=1, sticky=tk.W, padx=5, pady=3)
        self._on_end_wait_var = tk.StringVar(value="0")
        ttk.Entry(wait_inner, textvariable=self._on_end_wait_var, width=8).pack(side=tk.LEFT)
        ttk.Label(wait_inner, text="(0=不等待，执行后续操作前暂停秒数)",
                  foreground="gray", font=("", 8)).pack(side=tk.LEFT, padx=(5, 0))

        # --- 策略说明 ---
        self._media_end_desc = ttk.Label(
            self._media_end_frame,
            text="💡 设置媒体播放完成后的自动行为：可点击按钮、跳转页面、播放下一个或刷新页面。",
            foreground="#0066cc", font=("", 8), wraplength=450)
        self._media_end_desc.grid(row=4, column=0, columnspan=2, sticky=tk.W, pady=(6, 0))

        self._media_end_frame.columnconfigure(1, weight=1)

        # 行5.7: 按列表播放配置区（仅 play_list 时显示）
        self._play_list_frame = ttk.LabelFrame(right_f, text="📋 按列表播放 - 播放列表配置", padding=8)
        self._play_list_frame.grid(row=5, column=0, columnspan=3, sticky=tk.EW, pady=3)
        self._play_list_frame.columnconfigure(1, weight=1)
        # 初始隐藏
        self._play_list_frame.grid_remove()

        # --- 播放列表表格 ---
        table_frame = ttk.Frame(self._play_list_frame)
        table_frame.grid(row=0, column=0, columnspan=2, sticky=tk.NSEW, pady=(0, 5))
        table_frame.columnconfigure(0, weight=1)
        table_frame.rowconfigure(0, weight=1)
        self._play_list_frame.rowconfigure(0, weight=1)
        self._play_list_frame.columnconfigure(0, weight=1)

        # 创建 Treeview 表格
        columns = ('#', '播放网页URL', '选择器', '点击播放', '播放状态(已完成)', '录音文件')
        self._play_list_tree = ttk.Treeview(table_frame, columns=columns, show='headings', height=6)
        self._play_list_tree.heading('#', text='#')
        self._play_list_tree.heading('播放网页URL', text='播放网页URL')
        self._play_list_tree.heading('选择器', text='选择器(可选)')
        self._play_list_tree.heading('点击播放', text='点击播放')
        self._play_list_tree.heading('播放状态(已完成)', text='已完成')
        self._play_list_tree.heading('录音文件', text='录音文件')
        self._play_list_tree.column('#', width=30, anchor=tk.CENTER)
        self._play_list_tree.column('播放网页URL', width=200, anchor=tk.W)
        self._play_list_tree.column('选择器', width=100, anchor=tk.W)
        self._play_list_tree.column('点击播放', width=60, anchor=tk.CENTER)
        self._play_list_tree.column('播放状态(已完成)', width=50, anchor=tk.CENTER)
        self._play_list_tree.column('录音文件', width=120, anchor=tk.W)

        # 添加滚动条
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self._play_list_tree.yview)
        self._play_list_tree.configure(yscrollcommand=scrollbar.set)

        self._play_list_tree.grid(row=0, column=0, sticky=tk.NSEW)
        scrollbar.grid(row=0, column=1, sticky=tk.NS)

        # --- 按钮区域 ---
        btn_frame = ttk.Frame(self._play_list_frame)
        btn_frame.grid(row=1, column=0, columnspan=2, sticky=tk.EW, pady=(5, 0))

        ttk.Button(btn_frame, text="+ 添加行", width=10, command=self._play_list_add_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="- 删除选中", width=10, command=self._play_list_delete_row).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="↑ 上移", width=8, command=self._play_list_move_up).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_frame, text="↓ 下移", width=8, command=self._play_list_move_down).pack(side=tk.LEFT, padx=2)

        # --- 编辑区域 ---
        edit_frame = ttk.LabelFrame(self._play_list_frame, text="编辑选中行", padding=5)
        edit_frame.grid(row=2, column=0, columnspan=2, sticky=tk.EW, pady=(5, 0))
        edit_frame.columnconfigure(1, weight=1)
        edit_frame.columnconfigure(3, weight=1)

        # 第一行：URL 和 已完成状态
        ttk.Label(edit_frame, text="URL:").grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
        self._play_list_url_var = tk.StringVar()
        self._play_list_url_entry = ttk.Entry(edit_frame, textvariable=self._play_list_url_var, width=40)
        self._play_list_url_entry.grid(row=0, column=1, sticky=tk.EW, padx=(0, 10))

        ttk.Label(edit_frame, text="已完成:").grid(row=0, column=2, sticky=tk.W, padx=(0, 5))
        self._play_list_completed_var = tk.BooleanVar(value=False)
        self._play_list_completed_check = ttk.Checkbutton(edit_frame, variable=self._play_list_completed_var,
                                                          text="✓")
        self._play_list_completed_check.grid(row=0, column=3, sticky=tk.W)

        ttk.Button(edit_frame, text="💾 保存修改", width=12, command=self._play_list_save_row).grid(row=0, column=4, padx=(10, 0))
        ttk.Button(edit_frame, text="▶ 测试播放", width=12, command=self._play_list_test_play).grid(row=0, column=5, padx=(5, 0))

        # 第二行：选择器输入
        ttk.Label(edit_frame, text="选择器:").grid(row=1, column=0, sticky=tk.W, padx=(0, 5), pady=(5, 0))
        self._play_list_selector_var = tk.StringVar()
        sel_entry = ttk.Entry(edit_frame, textvariable=self._play_list_selector_var, width=30)
        sel_entry.grid(row=1, column=1, sticky=tk.EW, padx=(0, 5), pady=(5, 0))
        # 按钮组：点选 + 取消 + 扫描媒体 + 点击播放
        sel_btn_frame = ttk.Frame(edit_frame)
        sel_btn_frame.grid(row=1, column=2, columnspan=3, sticky=tk.W, pady=(5, 0))
        self._play_list_pick_btn = ttk.Button(sel_btn_frame, text="🎯 点选", width=6,
                                               command=self._start_play_list_pick)
        self._play_list_pick_btn.pack(side=tk.LEFT, padx=(0, 2))
        self._play_list_cancel_pick_btn = ttk.Button(sel_btn_frame, text="✕ 取消", width=6,
                                                      command=self._cancel_play_list_pick, state=tk.DISABLED)
        self._play_list_cancel_pick_btn.pack(side=tk.LEFT, padx=(0, 2))
        ttk.Button(sel_btn_frame, text="🔍 扫描媒体", width=10,
                   command=self._play_list_scan_selector).pack(side=tk.LEFT, padx=(0, 2))
        ttk.Button(sel_btn_frame, text="▶ 点击播放", width=10,
                   command=self._play_list_click_play).pack(side=tk.LEFT, padx=(0, 2))
        # 选择器提示
        ttk.Label(edit_frame, text="(留空则自动查找)", foreground="gray",
                  font=("", 8)).grid(row=1, column=5, sticky=tk.W, pady=(5, 0))

        # 第三行：点击播放选项
        self._play_list_click_play_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(edit_frame, variable=self._play_list_click_play_var,
                        text="▶ 自动点击播放（打开网页后模拟鼠标点击播放器）"
                        ).grid(row=2, column=0, columnspan=4, sticky=tk.W, pady=(5, 0))

        # 第四行：音频录制开关 + 格式选择
        self._play_list_enable_recording_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(edit_frame, variable=self._play_list_enable_recording_var,
                        text="🎙️ 启用音频录制（播放时录制视频声音）"
                        ).grid(row=3, column=0, columnspan=3, sticky=tk.W, pady=(5, 0))
        ttk.Label(edit_frame, text="录制格式:").grid(row=3, column=3, sticky=tk.E, padx=(10, 2), pady=(5, 0))
        self._play_list_recording_format_var = tk.StringVar(value='WEBM')
        format_combo = ttk.Combobox(edit_frame, textvariable=self._play_list_recording_format_var,
                                     values=['WEBM', 'WAV', 'MP3', 'M4A'], state='readonly', width=8)
        format_combo.grid(row=3, column=4, sticky=tk.W, pady=(5, 0))

        # 第五行：录音名称 + 播放录音按钮 + 总结按钮
        ttk.Label(edit_frame, text="录音名称:").grid(row=4, column=0, sticky=tk.W, padx=(0, 5), pady=(5, 0))
        self._play_list_audio_name_entry = ttk.Entry(edit_frame, textvariable=self._play_list_audio_name_var, width=30)
        self._play_list_audio_name_entry.grid(row=4, column=1, sticky=tk.EW, padx=(0, 10), pady=(5, 0))
        self._play_list_play_recording_btn = ttk.Button(edit_frame, text="▶ 播放录音", width=12,
                                                         command=self._play_list_play_recording)
        self._play_list_play_recording_btn.grid(row=4, column=2, sticky=tk.W, padx=(0, 5), pady=(5, 0))
        self._play_list_summarize_btn = ttk.Button(edit_frame, text="📝 总结", width=10,
                                                    command=self._play_list_summarize)
        self._play_list_summarize_btn.grid(row=4, column=3, sticky=tk.W, padx=(0, 5), pady=(5, 0))
        # 录音名称提示
        ttk.Label(edit_frame, text="(选中行后可播放录音、修改名称、AI总结)",
                  foreground="gray", font=("", 8)).grid(row=4, column=4, columnspan=2, sticky=tk.W, pady=(5, 0))

        # 绑定选中事件
        self._play_list_tree.bind('<<TreeviewSelect>>', self._play_list_on_select)

        # --- 说明文字 ---
        hint_label = ttk.Label(
            self._play_list_frame,
            text="💡 说明：URL填播放页面地址，选择器指定媒体元素(留空自动查找)，'点击播放'勾选后打开网页自动点击播放器(适用于懒加载播放器)，'已完成'表示是否已播放完毕。",
            foreground="#0066cc", font=("", 8), wraplength=500)
        hint_label.grid(row=3, column=0, columnspan=2, sticky=tk.W, pady=(5, 0))

        # 行6: 停留时间（滑块 + 输入框组合）
        row = 6
        ttk.Label(right_f, text="停留时间(秒):").grid(row=row, column=0, sticky=tk.W, pady=3)
        stay_inner = ttk.Frame(right_f)
        stay_inner.grid(row=row, column=1, sticky=tk.EW, padx=5, pady=3)

        self._stay_time_var = tk.IntVar(value=3)
        self.step_vars['step_stay'] = tk.StringVar(value="3")

        # 滑块控件：范围 0~120 秒，默认 3 秒
        self._stay_scale = ttk.Scale(stay_inner, from_=0, to=120,
                                      variable=self._stay_time_var, orient=tk.HORIZONTAL,
                                      length=200, command=self._on_stay_scale_changed)
        self._stay_scale.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # 数值输入框（与滑块双向同步）
        self._stay_entry = ttk.Entry(stay_inner, textvariable=self.step_vars['step_stay'], width=6)
        self._stay_entry.pack(side=tk.LEFT, padx=(6, 0))
        self._stay_entry.bind("<Return>", self._on_stay_entry_changed)
        self._stay_entry.bind("<FocusOut>", self._on_stay_entry_changed)

        # 当前值实时显示标签
        self._stay_value_label = ttk.Label(stay_inner, text="3秒", width=6,
                                            font=("", 9, "bold"), foreground="#0066cc")
        self._stay_value_label.pack(side=tk.LEFT, padx=(4, 0))

        # 智能等待提示
        stay_hint_f = ttk.Frame(right_f)
        stay_hint_f.grid(row=row, column=2, sticky=tk.W, padx=2, pady=3)
        ttk.Label(stay_hint_f, text="0=智能等待", foreground="gray",
                  font=("", 8)).pack(side=tk.LEFT)

        # 行6.5: 循环次数（输入框 + 无限循环勾选）
        row = 7
        ttk.Label(right_f, text="循环次数:").grid(row=row, column=0, sticky=tk.W, pady=3)
        loop_inner = ttk.Frame(right_f)
        loop_inner.grid(row=row, column=1, sticky=tk.EW, padx=5, pady=3)

        self.step_vars['step_loop_count'] = tk.StringVar(value="1")
        self._loop_count_entry = ttk.Entry(loop_inner, textvariable=self.step_vars['step_loop_count'], width=6)
        self._loop_count_entry.pack(side=tk.LEFT)

        self._loop_infinite_var = tk.BooleanVar(value=False)
        self._loop_infinite_check = ttk.Checkbutton(loop_inner, text="无限循环",
                                                     variable=self._loop_infinite_var,
                                                     command=self._on_loop_infinite_changed)
        self._loop_infinite_check.pack(side=tk.LEFT, padx=(8, 0))

        ttk.Label(loop_inner, text="(1=仅执行1次)", foreground="gray",
                  font=("", 8)).pack(side=tk.LEFT, padx=(5, 0))

        right_f.columnconfigure(1, weight=1)

        # 选择器候选列表
        sel_cand_f = ttk.LabelFrame(right_f, text="选择器候选（双击选用）", padding=3)
        sel_cand_f.grid(row=8, column=0, columnspan=3, sticky=tk.EW, pady=(3, 0))
        self._selector_candidates = tk.Listbox(sel_cand_f, height=4, font=("Consolas", 9))
        self._selector_candidates.pack(fill=tk.BOTH, expand=True)
        self._selector_candidates.bind("<Double-1>", self._on_candidate_double_click)

        # 步骤操作按钮
        btn_f = ttk.Frame(right_f)
        btn_f.grid(row=9, column=0, columnspan=3, pady=8)

        ttk.Button(btn_f, text="新增", command=self._add_step).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_f, text="更新", command=self._update_step).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_f, text="删除", command=self._delete_step).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_f, text="↑ 上移", command=lambda: self._move_step(-1)).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_f, text="↓ 下移", command=lambda: self._move_step(1)).pack(side=tk.LEFT, padx=3)

        ttk.Separator(btn_f, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)
        ttk.Button(btn_f, text="🔍 测试此步", command=self._test_current_step).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_f, text="▶ 执行此步", command=self._run_current_step).pack(side=tk.LEFT, padx=3)

        # ================================================================
        # 行10: 步骤专属弹窗规则（可折叠，结构与全局弹窗规则一致）
        # ================================================================
        self._step_popup_frame = ttk.LabelFrame(right_f, text="📌 步骤专属弹窗规则", padding=5)
        self._step_popup_frame.grid(row=10, column=0, columnspan=3, sticky=tk.EW, pady=(3, 0))

        # 折叠控制 + 继承说明
        toggle_row = ttk.Frame(self._step_popup_frame)
        toggle_row.grid(row=0, column=0, columnspan=2, sticky=tk.EW)

        self._step_popup_collapsed = True
        self._step_popup_toggle_btn = ttk.Button(
            toggle_row, text="▼ 展开", width=8,
            command=self._toggle_step_popup_panel)
        self._step_popup_toggle_btn.pack(side=tk.LEFT)

        self._step_popup_desc = ttk.Label(
            toggle_row,
            text="步骤专属规则优先于全局规则（参数覆盖），仅在此步骤执行期间生效",
            foreground="gray", font=("", 8))
        self._step_popup_desc.pack(side=tk.LEFT, padx=5)

        # ---- 规则列表 ----
        self._step_popup_content = ttk.Frame(self._step_popup_frame)
        self._step_popup_content.grid(row=1, column=0, columnspan=2, sticky=tk.EW, pady=(3, 0))

        self._step_popup_listbox = tk.Listbox(self._step_popup_content, height=3, font=("", 9))
        self._step_popup_listbox.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        self._step_popup_listbox.bind("<<ListboxSelect>>", self._on_step_popup_select)

        popup_sb = ttk.Scrollbar(self._step_popup_content, orient=tk.VERTICAL,
                                  command=self._step_popup_listbox.yview)
        popup_sb.pack(side=tk.RIGHT, fill=tk.Y)
        self._step_popup_listbox.config(yscrollcommand=popup_sb.set)

        # ---- 规则编辑区（完整配置，与全局弹窗规则结构一致） ----
        self._step_popup_vars = {}
        popup_edit_f = ttk.Frame(self._step_popup_frame)
        popup_edit_f.grid(row=2, column=0, columnspan=2, sticky=tk.EW, pady=3)

        # -- 通用设置 --
        self._sp_common_frame = ttk.LabelFrame(popup_edit_f, text="通用设置", padding=3)
        self._sp_common_frame.pack(fill=tk.X, pady=(0, 3))

        # 关键词
        ttk.Label(self._sp_common_frame, text="关键词:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self._step_popup_vars['keyword'] = tk.StringVar()
        ttk.Entry(self._sp_common_frame, textvariable=self._step_popup_vars['keyword'],
                  width=35).grid(row=0, column=1, sticky=tk.EW, padx=3, pady=2)

        # 弹窗类型 + 操作（同一行）
        ttk.Label(self._sp_common_frame, text="类型:").grid(row=1, column=0, sticky=tk.W, pady=2)
        type_action_f = ttk.Frame(self._sp_common_frame)
        type_action_f.grid(row=1, column=1, sticky=tk.EW, padx=3, pady=2)

        self._step_popup_vars['type'] = tk.StringVar(value='custom')
        self._sp_type_combo = ttk.Combobox(type_action_f, textvariable=self._step_popup_vars['type'],
                                            width=10,
                                            values=["custom", "radio", "quiz", "layer", "alert", "confirm", "prompt"],
                                            state="readonly")
        self._sp_type_combo.pack(side=tk.LEFT)
        self._sp_type_combo.bind("<<ComboboxSelected>>", self._on_step_popup_type_changed)

        ttk.Label(type_action_f, text="操作:").pack(side=tk.LEFT, padx=(8, 0))
        self._step_popup_vars['action'] = tk.StringVar(value='click')
        self._sp_action_combo = ttk.Combobox(type_action_f, textvariable=self._step_popup_vars['action'],
                                              width=10,
                                              values=["close", "click", "accept", "dismiss", "input",
                                                       "select_option", "auto_answer"],
                                              state="readonly")
        self._sp_action_combo.pack(side=tk.LEFT)
        self._sp_action_combo.bind("<<ComboboxSelected>>", self._on_step_popup_action_changed)

        # 目标标签页
        ttk.Label(self._sp_common_frame, text="目标标签页:").grid(row=2, column=0, sticky=tk.W, pady=2)
        sp_tab_f = ttk.Frame(self._sp_common_frame)
        sp_tab_f.grid(row=2, column=1, sticky=tk.EW, padx=3, pady=2)
        self._step_popup_vars['tab_index'] = tk.StringVar(value='-1')
        self._sp_tab_combo = ttk.Combobox(sp_tab_f, width=18, state="readonly")
        self._sp_tab_combo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._sp_tab_data = []
        ttk.Button(sp_tab_f, text="🔄", width=3,
                   command=self._refresh_step_popup_tab_list).pack(side=tk.LEFT, padx=(4, 0))
        self._sp_tab_combo.bind("<<ComboboxSelected>>", self._on_step_popup_tab_selected)

        self._sp_common_frame.columnconfigure(1, weight=1)

        # -- 选择器设置（custom/radio/quiz/layer 可见） --
        self._sp_selector_frame = ttk.LabelFrame(popup_edit_f, text="选择器设置", padding=3)
        self._sp_selector_frame.pack(fill=tk.X, pady=(0, 3))

        ttk.Label(self._sp_selector_frame, text="选择器:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self._step_popup_vars['selector'] = tk.StringVar()
        ttk.Entry(self._sp_selector_frame, textvariable=self._step_popup_vars['selector'],
                  width=35).grid(row=0, column=1, sticky=tk.EW, padx=3, pady=2)
        self._sp_selector_frame.columnconfigure(1, weight=1)

        # -- Quiz 答题专属设置 --
        self._sp_quiz_frame = ttk.LabelFrame(popup_edit_f, text="📝 Quiz 答题专属设置", padding=3)
        self._sp_quiz_frame.pack(fill=tk.X, pady=(0, 3))

        ttk.Label(self._sp_quiz_frame, text="正确答案:").grid(row=0, column=0, sticky=tk.W, pady=2)
        quiz_ans_f = ttk.Frame(self._sp_quiz_frame)
        quiz_ans_f.grid(row=0, column=1, sticky=tk.EW, padx=3, pady=2)
        self._step_popup_vars['correct_answer'] = tk.StringVar()
        ttk.Entry(quiz_ans_f, textvariable=self._step_popup_vars['correct_answer'],
                  width=25).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Label(quiz_ans_f, text="(A/B/C/D 或文本)", foreground="gray",
                  font=("", 7)).pack(side=tk.LEFT, padx=(3, 0))

        ttk.Label(self._sp_quiz_frame, text="最大重试:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self._step_popup_vars['max_retries'] = tk.StringVar(value="5")
        retry_f = ttk.Frame(self._sp_quiz_frame)
        retry_f.grid(row=1, column=1, sticky=tk.W, padx=3, pady=2)
        ttk.Entry(retry_f, textvariable=self._step_popup_vars['max_retries'],
                  width=6).pack(side=tk.LEFT)
        ttk.Label(retry_f, text="(默认5)", foreground="gray",
                  font=("", 7)).pack(side=tk.LEFT, padx=(3, 0))
        self._sp_quiz_frame.columnconfigure(1, weight=1)

        # -- Radio 单选专属设置 --
        self._sp_radio_frame = ttk.LabelFrame(popup_edit_f, text="🔘 Radio 单选专属设置", padding=3)
        self._sp_radio_frame.pack(fill=tk.X, pady=(0, 3))

        ttk.Label(self._sp_radio_frame, text="选项值:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self._step_popup_vars['option_value'] = tk.StringVar()
        ttk.Entry(self._sp_radio_frame, textvariable=self._step_popup_vars['option_value'],
                  width=35).grid(row=0, column=1, sticky=tk.EW, padx=3, pady=2)
        self._sp_radio_frame.columnconfigure(1, weight=1)

        # -- 输入文本设置 --
        self._sp_input_frame = ttk.LabelFrame(popup_edit_f, text="✏️ 输入文本设置", padding=3)
        self._sp_input_frame.pack(fill=tk.X, pady=(0, 3))

        ttk.Label(self._sp_input_frame, text="输入文本:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self._step_popup_vars['input_text'] = tk.StringVar()
        ttk.Entry(self._sp_input_frame, textvariable=self._step_popup_vars['input_text'],
                  width=35).grid(row=0, column=1, sticky=tk.EW, padx=3, pady=2)
        self._sp_input_frame.columnconfigure(1, weight=1)

        # -- 继承覆盖说明 --
        self._sp_inherit_label = ttk.Label(popup_edit_f,
            text="💡 步骤规则优先级: 步骤专属 > 全局规则。同名关键词时步骤规则覆盖全局规则。",
            foreground="#0066cc", font=("", 8), wraplength=500)
        self._sp_inherit_label.pack(fill=tk.X, pady=(3, 0))

        # 规则操作按钮
        popup_btn_f = ttk.Frame(self._step_popup_frame)
        popup_btn_f.grid(row=3, column=0, columnspan=2, pady=3)

        ttk.Button(popup_btn_f, text="添加规则",
                   command=self._add_step_popup_rule).pack(side=tk.LEFT, padx=3)
        ttk.Button(popup_btn_f, text="更新规则",
                   command=self._update_step_popup_rule).pack(side=tk.LEFT, padx=3)
        ttk.Button(popup_btn_f, text="删除规则",
                   command=self._delete_step_popup_rule).pack(side=tk.LEFT, padx=3)
        ttk.Separator(popup_btn_f, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)
        ttk.Button(popup_btn_f, text="🧪 测试规则",
                   command=self._test_step_popup_rule).pack(side=tk.LEFT, padx=3)
        ttk.Separator(popup_btn_f, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)
        ttk.Button(popup_btn_f, text="从全局复制",
                   command=self._copy_global_to_step_popup).pack(side=tk.LEFT, padx=8)
        ttk.Button(popup_btn_f, text="复制到全局",
                   command=self._copy_step_popup_to_global).pack(side=tk.LEFT, padx=3)

        # 默认折叠
        self._step_popup_content.grid_remove()
        popup_edit_f.grid_remove()
        popup_btn_f.grid_remove()

        self._step_popup_edit_frame = popup_edit_f
        self._step_popup_btn_frame = popup_btn_f

        # 步骤弹窗规则内部数据
        self._current_step_popup_rules = []
        self._current_step_popup_idx = -1

        # 初始化条件区域可见性
        self._update_step_popup_sections_visibility()

        # 底部保存
        ttk.Button(parent, text="💾 保存步骤配置", command=self._save_step_config).pack(pady=8)

        # 内部数据
        self._nav_data = []
        self._current_step_idx = -1  # 当前编辑的步骤索引
        self._candidate_data = []    # 点选候选选择器数据

    # ---------------------- 步骤配置滚动辅助 ----------------------
    def _on_step_scroll_frame_configure(self, event=None):
        """内部容器尺寸变化时更新滚动区域"""
        self._step_canvas.config(scrollregion=self._step_canvas.bbox("all"))

    def _on_step_canvas_configure(self, event=None):
        """Canvas 尺寸变化时调整内部容器宽度"""
        self._step_canvas.itemconfig(self._step_canvas_window, width=event.width)

    def _on_step_mousewheel(self, event):
        """鼠标滚轮滚动"""
        if event.delta:
            self._step_canvas.yview_scroll(-1 * (event.delta // 120), "units")
        elif event.num == 4:
            self._step_canvas.yview_scroll(-1, "units")
        elif event.num == 5:
            self._step_canvas.yview_scroll(1, "units")

    # ---------------------- 停留统计 Tab ----------------------
    def _build_stay_tab(self, parent):
        # 摘要区域
        summary_f = ttk.LabelFrame(parent, text="停留统计摘要", padding=8)
        summary_f.pack(fill=tk.X, padx=8, pady=(8, 4))

        self._stay_summary_labels = {}
        summary_items = [
            ('total_pages', '访问页面数:'),
            ('total_duration', '总停留时长:'),
            ('avg_duration', '平均停留时长:'),
            ('max_duration', '最长停留:'),
            ('min_duration', '最短停留:'),
        ]
        for i, (key, label_text) in enumerate(summary_items):
            row, col = divmod(i, 3)
            ttk.Label(summary_f, text=label_text, font=("", 9, "bold")).grid(
                row=row, column=col * 2, sticky=tk.W, padx=(10, 2), pady=2)
            val_label = ttk.Label(summary_f, text="--", foreground="#0066cc", font=("", 10))
            val_label.grid(row=row, column=col * 2 + 1, sticky=tk.W, padx=(0, 15), pady=2)
            self._stay_summary_labels[key] = val_label

        # 记录列表
        list_f = ttk.LabelFrame(parent, text="停留记录明细", padding=5)
        list_f.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)

        columns = ('step', 'action', 'title', 'url', 'start', 'end', 'duration', 'reason')
        self._stay_tree = ttk.Treeview(list_f, columns=columns, show='headings', height=14)
        col_widths = {
            'step': 90, 'action': 75, 'title': 160, 'url': 200,
            'start': 70, 'end': 70, 'duration': 75, 'reason': 80,
        }
        col_headers = {
            'step': '步骤', 'action': '操作', 'title': '页面标题', 'url': 'URL',
            'start': '开始', 'end': '结束', 'duration': '停留(秒)', 'reason': '结束原因',
        }
        for col in columns:
            self._stay_tree.heading(col, text=col_headers[col])
            self._stay_tree.column(col, width=col_widths[col], minwidth=50)

        vsb = ttk.Scrollbar(list_f, orient=tk.VERTICAL, command=self._stay_tree.yview)
        self._stay_tree.config(yscrollcommand=vsb.set)
        self._stay_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        # 操作按钮
        btn_f = ttk.Frame(parent)
        btn_f.pack(fill=tk.X, padx=8, pady=6)

        ttk.Button(btn_f, text="🔄 刷新", command=self._refresh_stay_data).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_f, text="🗑 清空记录", command=self._clear_stay_data).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_f, text="📋 导出CSV", command=self._export_stay_csv).pack(side=tk.LEFT, padx=3)

        # 自动刷新定时器
        self._stay_auto_refresh = False

    def _refresh_stay_data(self):
        """刷新停留统计数据"""
        records = self.browser.get_stay_records()
        summary = self.browser.get_stay_summary()

        # 更新摘要
        self._stay_summary_labels['total_pages'].config(text=str(summary.get('total_pages', 0)))
        self._stay_summary_labels['total_duration'].config(
            text=f"{summary.get('total_duration', 0):.1f}s")
        self._stay_summary_labels['avg_duration'].config(
            text=f"{summary.get('avg_duration', 0):.1f}s")
        self._stay_summary_labels['max_duration'].config(
            text=f"{summary.get('max_duration', 0):.1f}s")
        self._stay_summary_labels['min_duration'].config(
            text=f"{summary.get('min_duration', 0):.1f}s")

        # 更新明细列表
        for item in self._stay_tree.get_children():
            self._stay_tree.delete(item)

        reason_map = {
            'step_end': '步骤完成', 'new_step': '新步骤', 'navigate': '页面跳转',
            'manual': '手动停止', 'error': '异常', 'pause': '暂停',
            'stop': '停止', 'in_progress': '进行中', 'clear': '清空',
        }
        for rec in records:
            reason_text = reason_map.get(rec.get('reason', ''), rec.get('reason', ''))
            duration_text = f"{rec.get('duration', 0):.1f}"
            if rec.get('reason') == 'in_progress':
                duration_text += ' ...'
            self._stay_tree.insert('', tk.END, values=(
                rec.get('step_name', '')[:15],
                rec.get('action', '')[:10],
                rec.get('title', '')[:30],
                rec.get('url', '')[:50],
                rec.get('start_time_str', ''),
                rec.get('end_time_str', ''),
                duration_text,
                reason_text,
            ))

    def _clear_stay_data(self):
        """清空停留统计记录"""
        self.browser.clear_stay_records()
        self._refresh_stay_data()
        self.logger.info("[停留统计] 已清空所有记录")

    def _export_stay_csv(self):
        """导出停留统计为 CSV"""
        records = self.browser.get_stay_records()
        if not records:
            messagebox.showinfo("提示", "暂无停留记录可导出")
            return

        from tkinter import filedialog
        filepath = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV 文件", "*.csv"), ("所有文件", "*.*")],
            title="导出停留统计",
            initialfile=f"停留统计_{time.strftime('%Y%m%d_%H%M%S')}" if hasattr(time, 'strftime') else "停留统计"
        )
        if not filepath:
            return

        try:
            import csv
            with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f)
                writer.writerow(['步骤', '操作', '页面标题', 'URL', '开始时间',
                                 '结束时间', '停留(秒)', '结束原因'])
                for rec in records:
                    writer.writerow([
                        rec.get('step_name', ''),
                        rec.get('action', ''),
                        rec.get('title', ''),
                        rec.get('url', ''),
                        rec.get('start_time_str', ''),
                        rec.get('end_time_str', ''),
                        rec.get('duration', 0),
                        rec.get('reason', ''),
                    ])
            self.logger.info(f"[停留统计] 已导出: {filepath}")
            messagebox.showinfo("导出成功", f"停留统计已导出到:\n{filepath}")
        except Exception as e:
            messagebox.showerror("导出失败", str(e))

    # ---------------------- 步骤弹窗规则管理 ----------------------
    def _toggle_step_popup_panel(self):
        """折叠/展开步骤弹窗规则面板"""
        self._step_popup_collapsed = not self._step_popup_collapsed
        if self._step_popup_collapsed:
            self._step_popup_toggle_btn.config(text="▼ 展开")
            self._step_popup_content.grid_remove()
            self._step_popup_edit_frame.grid_remove()
            self._step_popup_btn_frame.grid_remove()
        else:
            self._step_popup_toggle_btn.config(text="▲ 收起")
            self._step_popup_content.grid()
            self._step_popup_edit_frame.grid()
            self._step_popup_btn_frame.grid()

    def _on_step_popup_type_changed(self, event=None):
        """步骤弹窗类型变更：调整操作下拉 + 更新条件区域可见性"""
        popup_type = self._step_popup_vars['type'].get()

        action_map = {
            'alert':   ['close', 'accept'],
            'confirm': ['close', 'accept', 'dismiss'],
            'prompt':  ['close', 'accept', 'dismiss', 'input'],
            'custom':  ['close', 'click', 'input', 'select_option'],
            'radio':   ['click', 'select_option'],
            'quiz':    ['auto_answer'],
            'layer':   ['click', 'close'],
        }
        default_action = {
            'alert': 'accept', 'confirm': 'accept', 'prompt': 'accept',
            'custom': 'close', 'radio': 'click', 'quiz': 'auto_answer',
            'layer': 'click',
        }
        available = action_map.get(popup_type, ['close'])
        self._sp_action_combo['values'] = available
        current_action = self._step_popup_vars['action'].get()
        if current_action not in available:
            self._step_popup_vars['action'].set(default_action.get(popup_type, 'close'))

        self._update_step_popup_sections_visibility()

    def _on_step_popup_action_changed(self, event=None):
        """步骤弹窗操作变更：更新条件区域可见性"""
        self._update_step_popup_sections_visibility()

    def _update_step_popup_sections_visibility(self):
        """根据当前步骤弹窗类型和操作，动态显示/隐藏专属设置区域"""
        popup_type = self._step_popup_vars['type'].get()
        action = self._step_popup_vars['action'].get()

        # 先隐藏所有条件区域
        self._sp_selector_frame.pack_forget()
        self._sp_quiz_frame.pack_forget()
        self._sp_radio_frame.pack_forget()
        self._sp_input_frame.pack_forget()

        # 确定插入位置（在继承说明标签之前）
        # 按顺序 pack 可见区域
        last_frame = self._sp_common_frame

        # 选择器：custom / radio / quiz / layer 需要
        if popup_type in ('custom', 'radio', 'quiz', 'layer'):
            self._sp_selector_frame.pack(fill=tk.X, pady=(0, 3), after=last_frame)
            last_frame = self._sp_selector_frame

        # Quiz 专属
        if popup_type == 'quiz':
            self._sp_quiz_frame.pack(fill=tk.X, pady=(0, 3), after=last_frame)
            last_frame = self._sp_quiz_frame

        # Radio 专属
        if popup_type == 'radio':
            self._sp_radio_frame.pack(fill=tk.X, pady=(0, 3), after=last_frame)
            last_frame = self._sp_radio_frame

        # 输入文本：prompt 或 custom + input
        need_input = (popup_type == 'prompt') or (popup_type == 'custom' and action == 'input')
        if need_input:
            self._sp_input_frame.pack(fill=tk.X, pady=(0, 3), after=last_frame)

    def _refresh_step_popup_list(self):
        """刷新步骤弹窗规则列表"""
        self._step_popup_listbox.delete(0, tk.END)
        for i, rule in enumerate(self._current_step_popup_rules):
            kw = rule.get('keyword', '')
            tp = rule.get('type', 'custom')
            act = rule.get('action', 'click')
            tab_idx = rule.get('tab_index', -1)
            tab_suffix = f" [Tab{tab_idx}]" if tab_idx >= 0 else ""
            self._step_popup_listbox.insert(tk.END, f"{i + 1}. [{tp}/{act}]{tab_suffix} {kw}")

    def _on_step_popup_select(self, event=None):
        """步骤弹窗规则列表选中"""
        sel = self._step_popup_listbox.curselection()
        if not sel:
            return
        self._current_step_popup_idx = sel[0]
        rule = self._current_step_popup_rules[self._current_step_popup_idx]
        self._step_popup_vars['keyword'].set(rule.get('keyword', ''))
        self._step_popup_vars['type'].set(rule.get('type', 'custom'))
        self._step_popup_vars['action'].set(rule.get('action', 'click'))
        self._step_popup_vars['selector'].set(rule.get('selector', ''))
        self._step_popup_vars['tab_index'].set(str(rule.get('tab_index', -1)))
        self._step_popup_vars['input_text'].set(rule.get('input_text', ''))
        self._step_popup_vars['correct_answer'].set(rule.get('correct_answer', ''))
        self._step_popup_vars['option_value'].set(rule.get('option_value', ''))
        self._step_popup_vars['max_retries'].set(str(rule.get('max_retries', 5)))
        # 刷新条件区域可见性
        self._on_step_popup_type_changed()
        # 刷新标签页下拉并恢复选中
        self._refresh_step_popup_tab_list()

    def _collect_step_popup_rule(self):
        """从编辑区收集一条完整的弹窗规则"""
        try:
            tab_index = int(self._step_popup_vars['tab_index'].get() or '-1')
        except (ValueError, TypeError):
            tab_index = -1
        try:
            max_retries = int(self._step_popup_vars['max_retries'].get() or '5')
        except (ValueError, TypeError):
            max_retries = 5
        return {
            'keyword': self._step_popup_vars['keyword'].get().strip(),
            'type': self._step_popup_vars['type'].get(),
            'action': self._step_popup_vars['action'].get(),
            'tab_index': tab_index,
            'selector': self._step_popup_vars['selector'].get().strip(),
            'correct_answer': self._step_popup_vars['correct_answer'].get().strip(),
            'option_value': self._step_popup_vars['option_value'].get().strip(),
            'max_retries': max_retries,
            'input_text': self._step_popup_vars['input_text'].get().strip(),
        }

    def _add_step_popup_rule(self):
        """添加一条步骤弹窗规则"""
        rule = self._collect_step_popup_rule()
        self._current_step_popup_rules.append(rule)
        self._refresh_step_popup_list()
        idx = len(self._current_step_popup_rules) - 1
        self._step_popup_listbox.selection_set(idx)
        self._current_step_popup_idx = idx

    def _update_step_popup_rule(self):
        """更新当前选中的步骤弹窗规则"""
        if self._current_step_popup_idx < 0 or \
           self._current_step_popup_idx >= len(self._current_step_popup_rules):
            return
        self._current_step_popup_rules[self._current_step_popup_idx] = self._collect_step_popup_rule()
        self._refresh_step_popup_list()
        if 0 <= self._current_step_popup_idx < len(self._current_step_popup_rules):
            self._step_popup_listbox.selection_set(self._current_step_popup_idx)

    def _delete_step_popup_rule(self):
        """删除当前选中的步骤弹窗规则"""
        if self._current_step_popup_idx < 0 or \
           self._current_step_popup_idx >= len(self._current_step_popup_rules):
            return
        del self._current_step_popup_rules[self._current_step_popup_idx]
        self._current_step_popup_idx = -1
        self._refresh_step_popup_list()

    def _copy_step_popup_to_global(self):
        """将当前步骤弹窗规则复制到全局规则"""
        if self._current_step_popup_idx < 0 or \
           self._current_step_popup_idx >= len(self._current_step_popup_rules):
            messagebox.showinfo("提示", "请先选中一条规则")
            return
        rule = self._current_step_popup_rules[self._current_step_popup_idx]
        self._popup_data.append(dict(rule))
        self._refresh_popup_list()
        self.logger.info(f"[弹窗规则] 已复制步骤规则到全局: {rule.get('keyword', '')[:30]}")

    def _copy_global_to_step_popup(self):
        """从全局弹窗规则复制到当前步骤"""
        if not self._popup_data:
            messagebox.showinfo("提示", "全局规则列表为空，无法复制")
            return
        # 弹出选择对话框
        sel_win = tk.Toplevel(self.root)
        sel_win.title("从全局规则复制")
        sel_win.geometry("400x300")
        sel_win.transient(self.root)
        sel_win.grab_set()

        ttk.Label(sel_win, text="选择要复制到当前步骤的全局规则：",
                  font=("", 9)).pack(padx=10, pady=5, anchor=tk.W)

        lb = tk.Listbox(sel_win, height=12, font=("", 9))
        lb.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        for i, rule in enumerate(self._popup_data):
            kw = rule.get('keyword', '')
            tp = rule.get('type', 'custom')
            lb.insert(tk.END, f"{i + 1}. [{tp}] {kw}")

        def do_copy():
            sel = lb.curselection()
            if not sel:
                return
            rule = dict(self._popup_data[sel[0]])
            self._current_step_popup_rules.append(rule)
            self._refresh_step_popup_list()
            sel_win.destroy()
            self.logger.info(f"[弹窗规则] 已从全局复制: {rule.get('keyword', '')[:30]}")

        btn_f = ttk.Frame(sel_win)
        btn_f.pack(pady=5)
        ttk.Button(btn_f, text="复制选中", command=do_copy).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_f, text="取消", command=sel_win.destroy).pack(side=tk.LEFT, padx=5)

    def _refresh_step_popup_tab_list(self):
        """刷新步骤弹窗规则的目标标签页下拉列表"""
        if not self.browser.context:
            self._sp_tab_combo['values'] = []
            self._sp_tab_combo.set('')
            return
        pages = self.browser.list_pages()
        if not pages:
            self._sp_tab_combo['values'] = ['(无标签页)']
            self._sp_tab_combo.set('')
            return
        self._sp_tab_data = pages
        tab_labels = []
        for p in pages:
            marker = " ★" if p['is_current'] else ""
            title = p['title'][:30] if p['title'] else '(无标题)'
            tab_labels.append(f"{p['index']}: {title}{marker}")
        self._sp_tab_combo['values'] = tab_labels
        # 恢复选中项
        try:
            target_idx = int(self._step_popup_vars['tab_index'].get())
        except (ValueError, TypeError):
            target_idx = -1
        if target_idx < 0:
            for i, p in enumerate(pages):
                if p['is_current']:
                    self._sp_tab_combo.current(i)
                    return
            if pages:
                self._sp_tab_combo.current(0)
        else:
            for i, p in enumerate(pages):
                if p['index'] == target_idx:
                    self._sp_tab_combo.current(i)
                    return

    def _on_step_popup_tab_selected(self, event=None):
        """步骤弹窗规则标签页选择变更"""
        sel = self._sp_tab_combo.current()
        if sel < 0 or not hasattr(self, '_sp_tab_data') or sel >= len(self._sp_tab_data):
            self._step_popup_vars['tab_index'].set('-1')
            return
        tab_info = self._sp_tab_data[sel]
        self._step_popup_vars['tab_index'].set(str(tab_info['index']))

    def _load_step_popup_rules(self, nav_item):
        """从步骤数据加载弹窗规则到编辑区"""
        self._current_step_popup_rules = list(nav_item.get('popup_rules', []))
        self._current_step_popup_idx = -1
        self._refresh_step_popup_list()
        # 重置编辑区为默认值
        self._step_popup_vars['keyword'].set('')
        self._step_popup_vars['type'].set('custom')
        self._step_popup_vars['action'].set('click')
        self._step_popup_vars['selector'].set('')
        self._step_popup_vars['tab_index'].set('-1')
        self._step_popup_vars['input_text'].set('')
        self._step_popup_vars['correct_answer'].set('')
        self._step_popup_vars['option_value'].set('')
        self._step_popup_vars['max_retries'].set('5')
        self._update_step_popup_sections_visibility()

    def _save_step_popup_rules(self):
        """将编辑区的弹窗规则保存回当前步骤数据"""
        if self._current_step_idx < 0 or self._current_step_idx >= len(self._nav_data):
            return
        self._nav_data[self._current_step_idx]['popup_rules'] = list(self._current_step_popup_rules)

    # ---------------------- 弹窗规则 Tab ----------------------
    def _build_popup_tab(self, parent):
        # 全局规则说明
        desc_label = ttk.Label(parent,
            text="💡 全局弹窗规则对所有步骤生效。步骤专属规则（在步骤编辑区配置）优先于全局规则。",
            foreground="#0066cc", font=("", 9), wraplength=800)
        desc_label.pack(fill=tk.X, padx=8, pady=(5, 0))

        # 规则列表
        list_f = ttk.Frame(parent)
        list_f.pack(fill=tk.BOTH, expand=True, padx=5, pady=3)

        left_f = ttk.LabelFrame(list_f, text="规则列表", padding=3)
        left_f.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(0, 5))

        self.popup_listbox = tk.Listbox(left_f, width=22, height=14, font=("", 10))
        self.popup_listbox.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        self.popup_listbox.bind("<<ListboxSelect>>", self._on_popup_select)

        sb = ttk.Scrollbar(left_f, orient=tk.VERTICAL, command=self.popup_listbox.yview)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.popup_listbox.config(yscrollcommand=sb.set)

        right_f = ttk.LabelFrame(list_f, text="规则编辑", padding=8)
        right_f.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.popup_vars = {}

        # ---- 通用设置（所有弹窗类型共享） ----
        self._popup_common_frame = ttk.LabelFrame(right_f, text="通用设置", padding=5)
        self._popup_common_frame.pack(fill=tk.X, padx=3, pady=(0, 5))

        # 关键词
        ttk.Label(self._popup_common_frame, text="关键词:").grid(row=0, column=0, sticky=tk.W, pady=3)
        self.popup_vars['popup_keyword'] = tk.StringVar()
        ttk.Entry(self._popup_common_frame, textvariable=self.popup_vars['popup_keyword'],
                  width=50).grid(row=0, column=1, sticky=tk.EW, padx=5, pady=3)

        # 弹窗类型
        ttk.Label(self._popup_common_frame, text="弹窗类型:").grid(row=1, column=0, sticky=tk.W, pady=3)
        self.popup_vars['popup_type'] = tk.StringVar(value="alert")
        type_combo = ttk.Combobox(self._popup_common_frame,
                                  textvariable=self.popup_vars['popup_type'], width=20,
                                  values=["alert", "confirm", "prompt", "custom", "radio", "quiz", "layer"],
                                  state="readonly")
        type_combo.grid(row=1, column=1, sticky=tk.W, padx=5, pady=3)
        type_combo.bind("<<ComboboxSelected>>", self._on_popup_type_changed)

        # 操作
        ttk.Label(self._popup_common_frame, text="操作:").grid(row=2, column=0, sticky=tk.W, pady=3)
        self.popup_vars['popup_action'] = tk.StringVar(value="close")
        self._popup_action_combo = ttk.Combobox(self._popup_common_frame,
                                                 textvariable=self.popup_vars['popup_action'], width=20,
                                                 values=["close", "accept", "dismiss", "input", "click",
                                                          "select_option", "auto_answer"],
                                                 state="readonly")
        self._popup_action_combo.grid(row=2, column=1, sticky=tk.W, padx=5, pady=3)
        self._popup_action_combo.bind("<<ComboboxSelected>>", self._on_popup_action_changed)

        # 目标标签页
        ttk.Label(self._popup_common_frame, text="目标标签页:").grid(row=3, column=0, sticky=tk.W, pady=3)
        tab_frame = ttk.Frame(self._popup_common_frame)
        tab_frame.grid(row=3, column=1, sticky=tk.EW, padx=5, pady=3)
        self.popup_vars['popup_tab_index'] = tk.StringVar(value='-1')
        self._popup_tab_combo = ttk.Combobox(tab_frame, width=22, state="readonly")
        self._popup_tab_combo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._popup_tab_data = []
        refresh_btn = ttk.Button(tab_frame, text="🔄", width=3,
                                 command=self._refresh_popup_tab_list)
        refresh_btn.pack(side=tk.LEFT, padx=(4, 0))
        self._popup_tab_combo.bind("<<ComboboxSelected>>", self._on_popup_tab_selected)

        self._popup_common_frame.columnconfigure(1, weight=1)

        # ---- 选择器设置（custom / radio / quiz 需要） ----
        self._popup_selector_frame = ttk.LabelFrame(right_f, text="选择器设置", padding=5)
        self._popup_selector_frame.pack(fill=tk.X, padx=3, pady=(0, 5))

        ttk.Label(self._popup_selector_frame, text="选择器:").grid(row=0, column=0, sticky=tk.W, pady=3)
        self.popup_vars['popup_selector'] = tk.StringVar()
        sel_inner = ttk.Frame(self._popup_selector_frame)
        sel_inner.grid(row=0, column=1, sticky=tk.EW, padx=5, pady=3)
        ttk.Entry(sel_inner, textvariable=self.popup_vars['popup_selector'],
                  width=40).pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._popup_pick_btn = ttk.Button(sel_inner, text="🎯 点选", width=6,
                                           command=self._start_popup_pick)
        self._popup_pick_btn.pack(side=tk.LEFT, padx=(4, 0))

        self._popup_selector_frame.columnconfigure(1, weight=1)

        # ---- Quiz 答题专属设置 ----
        self._quiz_settings_frame = ttk.LabelFrame(right_f, text="📝 Quiz 答题专属设置", padding=8)
        self._quiz_settings_frame.pack(fill=tk.X, padx=3, pady=(0, 5))

        # 正确答案
        ttk.Label(self._quiz_settings_frame, text="正确答案:").grid(row=0, column=0, sticky=tk.W, pady=3)
        self.popup_vars['popup_correct_answer'] = tk.StringVar()
        ans_frame = ttk.Frame(self._quiz_settings_frame)
        ans_frame.grid(row=0, column=1, sticky=tk.EW, padx=5, pady=3)
        ttk.Entry(ans_frame, textvariable=self.popup_vars['popup_correct_answer'],
                  width=40).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Label(ans_frame, text="(A/B/C/D 或选项文本)", foreground="gray",
                  font=("", 8)).pack(side=tk.LEFT, padx=(5, 0))

        # 最大重试次数
        ttk.Label(self._quiz_settings_frame, text="最大重试:").grid(row=1, column=0, sticky=tk.W, pady=3)
        self.popup_vars['popup_max_retries'] = tk.StringVar(value="5")
        retry_frame = ttk.Frame(self._quiz_settings_frame)
        retry_frame.grid(row=1, column=1, sticky=tk.EW, padx=5, pady=3)
        ttk.Entry(retry_frame, textvariable=self.popup_vars['popup_max_retries'],
                  width=8).pack(side=tk.LEFT, fill=tk.NONE)
        ttk.Label(retry_frame, text="(默认5，0=不限制)", foreground="gray",
                  font=("", 8)).pack(side=tk.LEFT, padx=(5, 0))

        # Quiz 答题策略说明
        ttk.Label(self._quiz_settings_frame,
                  text="💡 策略: 如已知正确答案则直接选中；否则逐一尝试每个选项，"
                       "通过错误反馈自动重试直到选中正确答案。",
                  foreground="#0066cc", font=("", 8), wraplength=400
                  ).grid(row=2, column=0, columnspan=2, sticky=tk.W, pady=(5, 0))

        self._quiz_settings_frame.columnconfigure(1, weight=1)

        # ---- Radio 单选专属设置 ----
        self._radio_settings_frame = ttk.LabelFrame(right_f, text="🔘 Radio 单选专属设置", padding=8)
        self._radio_settings_frame.pack(fill=tk.X, padx=3, pady=(0, 5))

        ttk.Label(self._radio_settings_frame, text="选项值:").grid(row=0, column=0, sticky=tk.W, pady=3)
        self.popup_vars['popup_option_value'] = tk.StringVar()
        opt_frame = ttk.Frame(self._radio_settings_frame)
        opt_frame.grid(row=0, column=1, sticky=tk.EW, padx=5, pady=3)
        ttk.Entry(opt_frame, textvariable=self.popup_vars['popup_option_value'],
                  width=40).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Label(opt_frame, text="(radio 的 value 属性)", foreground="gray",
                  font=("", 8)).pack(side=tk.LEFT, padx=(5, 0))

        self._radio_settings_frame.columnconfigure(1, weight=1)

        # ---- 输入文本设置（prompt / custom+input 需要） ----
        self._custom_input_frame = ttk.LabelFrame(right_f, text="✏️ 输入文本设置", padding=8)
        self._custom_input_frame.pack(fill=tk.X, padx=3, pady=(0, 5))

        ttk.Label(self._custom_input_frame, text="输入文本:").grid(row=0, column=0, sticky=tk.W, pady=3)
        self.popup_vars['popup_input_text'] = tk.StringVar()
        ttk.Entry(self._custom_input_frame, textvariable=self.popup_vars['popup_input_text'],
                  width=50).grid(row=0, column=1, sticky=tk.EW, padx=5, pady=3)

        self._custom_input_frame.columnconfigure(1, weight=1)

        # 操作按钮
        btn_f = ttk.Frame(right_f)
        btn_f.pack(pady=8)

        ttk.Button(btn_f, text="新增", command=self._add_popup).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_f, text="更新", command=self._update_popup).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_f, text="删除", command=self._delete_popup).pack(side=tk.LEFT, padx=3)
        ttk.Separator(btn_f, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)
        ttk.Button(btn_f, text="🧪 测试规则", command=self._test_popup_rule).pack(side=tk.LEFT, padx=3)

        # 底部: 扫描间隔 + 保存
        bottom_f = ttk.Frame(parent)
        bottom_f.pack(fill=tk.X, padx=5, pady=8)

        ttk.Label(bottom_f, text="扫描间隔(秒):").pack(side=tk.LEFT, padx=(5, 2))
        self.popup_scan_interval_var = tk.StringVar(value="0.5")
        ttk.Entry(bottom_f, textvariable=self.popup_scan_interval_var, width=6).pack(
            side=tk.LEFT, padx=(0, 15))
        ttk.Label(bottom_f, text="(自定义弹窗/单选题检测频率)",
                  foreground="gray").pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(bottom_f, text="💾 保存弹窗规则",
                   command=self._save_popup_config).pack(side=tk.RIGHT, padx=5)

        self._popup_data = []
        self._current_popup_idx = -1

        # 初始化：根据默认类型隐藏无关区域
        self._update_popup_sections_visibility()

    # ================================================================
    #  配置 <-> UI 同步
    # ================================================================
    def _load_config_to_ui(self):
        cfg = self.config_loader.config

        # 步骤数据（所有模式都需要加载）
        self._nav_data = copy.deepcopy(cfg.get('navigation', []))
        # 弹窗数据（所有模式都需要加载）
        self._popup_data = copy.deepcopy(cfg.get('popup_rules', []))

        # 浏览器 & 网站设置变量（所有模式都设置值，用于配置保存）
        s = cfg.get('settings', {})
        self.browser_type_var.set(s.get('browser_type', 'chrome'))
        self.window_max_var.set(s.get('window_max', True))
        self.timeout_var.set(str(s.get('global_timeout', 60000)))
        self.loop_run_var.set(s.get('loop_run', False))
        self.retry_var.set(str(s.get('retry_count', 2)))

        w = cfg.get('website', {})
        self.login_url_var.set(w.get('login_url', ''))
        self.wait_after_login_var.set(str(w.get('wait_after_login', 5)))
        self._storage_state = w.get('storage_state', False)
        self._storage_state_file = w.get('storage_state_file', 'storage_state.json')
        self.storage_status_var.set("已保存" if self._storage_state else "未保存")

        # 弹窗扫描间隔
        scan_interval = s.get('popup_scan_interval', 0.5)
        self.popup_scan_interval_var.set(str(scan_interval))

        if self.mode != 'all':
            # simple / list 模式：不刷新 UI 列表控件
            return

        # 步骤列表（all 模式专属 UI）
        self._refresh_step_list()

        # 弹窗列表（all 模式专属 UI）
        self._refresh_popup_list()

    def _collect_site_config(self):
        try:
            scan_interval = float(self.popup_scan_interval_var.get() or '0.5')
        except (ValueError, TypeError):
            scan_interval = 0.5
        try:
            return {
                'settings': {
                    'browser_type': self.browser_type_var.get(),
                    'window_max': self.window_max_var.get(),
                    'global_timeout': int(self.timeout_var.get()),
                    'loop_run': self.loop_run_var.get(),
                    'retry_count': int(self.retry_var.get()),
                    'popup_scan_interval': scan_interval,
                },
                'website': {
                    'login_url': self.login_url_var.get().strip(),
                    'wait_after_login': int(self.wait_after_login_var.get()),
                    'storage_state': self._storage_state,
                    'storage_state_file': self._storage_state_file,
                }
            }
        except ValueError as e:
            messagebox.showerror("配置错误", f"请检查数值字段: {e}")
            return None

    def _save_site_config(self):
        data = self._collect_site_config()
        if not data:
            return
        self.config_loader.set_settings(data['settings'])
        self.config_loader.set_website(data['website'])
        try:
            self.config_loader.save()
            # 同步运行时对象
            self.task_runner.settings = data['settings']
            self.logger.info("浏览器 & 网站配置已保存")
            messagebox.showinfo("成功", "配置已保存")
        except Exception as e:
            messagebox.showerror("保存失败", str(e))

    def _save_storage_state(self):
        """保存当前浏览器的登录信息（storage state），加密保存为 .enc 文件。"""
        import os
        if not self.browser or not self.browser.is_alive():
            messagebox.showwarning("警告", "浏览器未启动，请先启动浏览器并登录")
            return
        try:
            # 统一使用 .enc 后缀表示加密文件
            if not self._storage_state_file.endswith('.enc'):
                self._storage_state_file = self._storage_state_file.rsplit('.', 1)[0] + '.enc'
            # 计算 state 文件的绝对路径（与 config.yaml 同级）
            app_dir = os.path.dirname(self.config_loader.config_path)
            filepath = os.path.join(app_dir, self._storage_state_file)
            filepath = os.path.abspath(filepath)
            # encrypt=True 且后缀为 .enc，save_storage_state 会自动加密
            if self.browser.save_storage_state(filepath, encrypt=True):
                self._storage_state = True
                self.storage_status_var.set("已保存(.enc)")
                # 更新 config
                w = self.config_loader.get_website()
                w['storage_state'] = True
                w['storage_state_file'] = self._storage_state_file
                self.config_loader.set_website(w)
                self.config_loader.save()
                self.logger.info(f"[登录信息] 已加密保存: {filepath}")
                messagebox.showinfo("成功", "登录信息已加密保存，下次启动将自动登录")
            else:
                messagebox.showerror("失败", "保存登录信息失败")
        except Exception as e:
            messagebox.showerror("错误", f"保存登录信息异常: {e}")

    def _clear_storage_state(self):
        """清除已保存的登录信息（删除 .enc 加密文件）。"""
        import os
        try:
            app_dir = os.path.dirname(self.config_loader.config_path)
            filepath = os.path.join(app_dir, self._storage_state_file)
            filepath = os.path.abspath(filepath)
            # 同时尝试删除 .enc 和 .json 两种格式
            for ext in ['.enc', '.json']:
                f = filepath
                if not f.endswith(ext):
                    f = f.rsplit('.', 1)[0] + ext
                if os.path.isfile(f):
                    os.remove(f)
                    self.logger.info(f"[登录信息] 已删除: {f}")
            self._storage_state = False
            self.storage_status_var.set("未保存")
            # 更新 config
            w = self.config_loader.get_website()
            w['storage_state'] = False
            self.config_loader.set_website(w)
            self.config_loader.save()
            messagebox.showinfo("成功", "登录信息已清除")
        except Exception as e:
            messagebox.showerror("错误", f"清除登录信息异常: {e}")

    def _save_step_config(self):
        self._sync_step_edit_to_data()
        self.config_loader.set_navigation(self._nav_data)
        try:
            self.config_loader.save()
            # 同步运行时对象（深拷贝，避免运行中任务修改影响 GUI 数据）
            self.task_runner.navigation_list = copy.deepcopy(self._nav_data)
            self.logger.info("步骤配置已保存")
            messagebox.showinfo("成功", "步骤配置已保存")
        except Exception as e:
            messagebox.showerror("保存失败", str(e))

    def _save_popup_config(self):
        self._sync_popup_edit_to_data()
        self.config_loader.set_popup_rules(self._popup_data)
        # 保存扫描间隔到 settings
        try:
            interval = float(self.popup_scan_interval_var.get() or '0.5')
        except (ValueError, TypeError):
            interval = 0.5
        settings = self.config_loader.get_settings()
        settings['popup_scan_interval'] = interval
        self.config_loader.set_settings(settings)
        try:
            self.config_loader.save()
            # 同步运行时对象
            self.popup_handler.popup_rules = self._popup_data
            self.popup_handler._global_popup_rules = self._popup_data
            self.popup_handler.custom_popup_check_interval = interval
            self.task_runner.settings = settings
            self.logger.info("弹窗规则已保存")
            messagebox.showinfo("成功", "弹窗规则已保存")
        except Exception as e:
            messagebox.showerror("保存失败", str(e))

    # ================================================================
    #  步骤列表管理
    # ================================================================
    def _refresh_step_list(self):
        self.step_listbox.delete(0, tk.END)
        for i, nav in enumerate(self._nav_data):
            name = nav.get('name', f'步骤{i + 1}')
            action = nav.get('action', 'navigate')
            tab_idx = nav.get('tab_index', -1)
            # 如果指定了标签页，在名称后标注
            tab_suffix = f" [Tab{tab_idx}]" if tab_idx >= 0 else ""
            # 循环次数标注
            if nav.get('loop_infinite', False):
                loop_suffix = " ∞"
            else:
                loop_count = nav.get('loop_count', 1)
                loop_suffix = f" x{loop_count}" if loop_count > 1 else ""
            self.step_listbox.insert(tk.END, f"{i + 1}. [{action}]{tab_suffix}{loop_suffix} {name}")

    def _parse_action_key(self, action_str):
        """从 'click - 单击' 格式或纯 key 中提取操作 key"""
        if not action_str:
            return 'navigate'
        if ' - ' in action_str:
            return action_str.split(' - ')[0].strip()
        return action_str.strip()

    # ================================================================
    #  标签页管理
    # ================================================================
    def _refresh_tab_list(self):
        """刷新标签页下拉列表，并恢复选中项以与 step_tab_index 变量同步"""
        if not self.browser.context:
            self._tab_combo['values'] = []
            self._tab_combo.set('')
            return

        pages = self.browser.list_pages()
        if not pages:
            self._tab_combo['values'] = ['(无标签页)']
            self._tab_combo.set('')
            return

        self._tab_data = pages  # 保存页面信息列表
        tab_labels = []
        for p in pages:
            marker = " ★" if p['is_current'] else ""
            title = p['title'][:30] if p['title'] else '(无标题)'
            url_short = p['url'][:50] if p['url'] else ''
            tab_labels.append(f"{p['index']}: {title}{marker}  {url_short}")

        self._tab_combo['values'] = tab_labels

        # 根据当前 step_tab_index 变量值恢复下拉框选中项
        try:
            target_idx = int(self.step_vars['step_tab_index'].get())
        except (ValueError, TypeError):
            target_idx = -1

        if target_idx < 0:
            # -1 表示"当前标签页"，选中当前活动标签页
            for i, p in enumerate(pages):
                if p['is_current']:
                    self._tab_combo.current(i)
                    return
            # 没有活动标签页则选第一个
            if pages:
                self._tab_combo.current(0)
        else:
            # 选中指定索引的标签页
            for i, p in enumerate(pages):
                if p['index'] == target_idx:
                    self._tab_combo.current(i)
                    return
            # 找不到指定索引则回退到当前标签页
            for i, p in enumerate(pages):
                if p['is_current']:
                    self._tab_combo.current(i)
                    return

    def _on_tab_selected(self, event=None):
        """标签页下拉选择变更时，更新 step_tab_index 变量"""
        sel = self._tab_combo.current()
        if sel < 0 or not hasattr(self, '_tab_data') or sel >= len(self._tab_data):
            self.step_vars['step_tab_index'].set('-1')
            return
        tab_info = self._tab_data[sel]
        self.step_vars['step_tab_index'].set(str(tab_info['index']))

    def _scan_media_elements(self):
        """扫描当前标签页中的所有媒体元素（video/audio），填充候选选择器列表"""
        if not self.browser.page:
            self.logger.warning("[扫描媒体] 浏览器未启动")
            return

        # 如果指定了目标标签页，先切换
        tab_index = self._get_target_tab_index()
        target_page = self._switch_to_target_tab(tab_index)
        if target_page is None:
            self.logger.warning("[扫描媒体] 目标标签页不可用")
            return

        original_page = None
        if tab_index >= 0:
            original_page = self.browser.page
            self.browser.page = target_page

        try:
            candidates = self.browser.scan_media_elements()
        finally:
            # 恢复原始标签页
            if original_page is not None:
                self.browser.page = original_page

        # 填充候选列表
        self._selector_candidates.delete(0, tk.END)
        self._candidate_data = candidates

        if candidates:
            # 默认选用第一个
            best = candidates[0]
            self.step_vars['step_selector'].set(best[0])
            self.logger.info(f"[扫描媒体] 已选用: {best[0]} ({best[2]})")

            for sel, sel_type, desc in candidates:
                self._selector_candidates.insert(tk.END, f"{sel}  [{desc}]")

            self.logger.info(f"[扫描媒体] 共发现 {len(candidates)} 个媒体元素选择器")
        else:
            self.logger.warning("[扫描媒体] 当前页面未发现 video/audio 元素")

    def _get_target_tab_index(self):
        """获取步骤配置中指定的标签页索引，-1 表示当前标签页"""
        try:
            val = self.step_vars['step_tab_index'].get()
            idx = int(val) if val else -1
            return idx
        except (ValueError, TypeError):
            return -1

    def _switch_to_target_tab(self, tab_index):
        """切换到目标标签页（用于点选和执行操作）。返回目标 page 或 None。"""
        if tab_index < 0:
            # -1 表示当前标签页，不切换
            return self.browser.page

        page = self.browser.get_page_by_index(tab_index)
        if page is None:
            self.logger.warning(f"标签页 {tab_index} 不存在或已关闭")
            return None
        return page

    def _on_action_changed(self, event=None):
        """操作类型切换时：更新参数区 + 切换 URL/选择器/标签页/媒体设置行可见性"""
        action_key = self._parse_action_key(self.step_vars['step_action'].get())
        action_def = self.ACTION_DEFS.get(action_key, {})

        need_selector = action_def.get('need_selector', False)
        need_url = action_def.get('need_url', False)
        is_media_action = action_key in ('play', 'pause', 'play_wait', 'play_next')
        is_media_with_end = action_key in ('play_wait', 'play_next')
        is_play_list = action_key == 'play_list'

        # 切换 URL 行可见性
        if need_url:
            self._url_label.grid()
            self._url_entry.grid()
        else:
            self._url_label.grid_remove()
            self._url_entry.grid_remove()

        # 切换选择器行可见性
        if need_selector:
            self._sel_label.grid()
            self._sel_frame.grid()
        else:
            self._sel_label.grid_remove()
            self._sel_frame.grid_remove()

        # 媒体操作时：禁用点选按钮，启用扫描媒体按钮；反之恢复
        if is_media_action:
            self._pick_btn.config(state=tk.DISABLED)
            self._scan_media_btn.config(state=tk.NORMAL)
        else:
            self._pick_btn.config(state=tk.NORMAL)
            self._scan_media_btn.config(state=tk.DISABLED)

        # 切换标签页行可见性：需要选择器的操作才显示
        if need_selector:
            self._tab_label.grid()
            self._tab_frame.grid()
            self._refresh_tab_list()
        else:
            self._tab_label.grid_remove()
            self._tab_frame.grid_remove()

        # 媒体播放完成设置区域：仅 play_wait / play_next 时显示
        if is_media_with_end:
            self._media_end_frame.grid()
        else:
            self._media_end_frame.grid_remove()

        # 按列表播放配置区域：仅 play_list 时显示
        if is_play_list:
            self._play_list_frame.grid()
            # 隐藏 URL 和选择器（由播放列表控制）
            self._url_label.grid_remove()
            self._url_entry.grid_remove()
            self._sel_label.grid_remove()
            self._sel_frame.grid_remove()
        else:
            self._play_list_frame.grid_remove()

        # 重建通用参数区
        self._rebuild_param_frame(action_key)

        # 媒体操作时自动扫描页面媒体元素
        if is_media_action and self.browser.page:
            self._scan_media_elements()

    def _rebuild_param_frame(self, action_key):
        """根据操作类型动态生成参数输入框"""
        # 保存当前参数值
        old_params = self._collect_action_params()

        # 清空
        for widget in self._param_frame.winfo_children():
            widget.destroy()
        self._param_widgets = {}

        action_def = self.ACTION_DEFS.get(action_key, {})
        params = action_def.get('params', [])

        if not params:
            ttk.Label(self._param_frame, text="（此操作无额外参数）",
                      foreground="gray").grid(row=0, column=0, columnspan=2, pady=2)
            return

        for i, (key, label, default) in enumerate(params):
            ttk.Label(self._param_frame, text=f"{label}:").grid(
                row=i, column=0, sticky=tk.W, pady=2, padx=(0, 5))
            var = tk.StringVar(value=old_params.get(key, default))
            entry = ttk.Entry(self._param_frame, textvariable=var, width=40)
            entry.grid(row=i, column=1, sticky=tk.EW, pady=2)
            self._param_widgets[key] = (label, var, entry)

        self._param_frame.columnconfigure(1, weight=1)

    def _collect_action_params(self):
        """收集当前参数区的值"""
        params = {}
        for key, (label, var, entry) in self._param_widgets.items():
            params[key] = var.get()
        return params

    def _on_stay_scale_changed(self, value):
        """滑块值变更回调：同步到输入框和显示标签"""
        try:
            int_val = int(float(value))
        except (ValueError, TypeError):
            int_val = 3
        self.step_vars['step_stay'].set(str(int_val))
        self._stay_time_var.set(int_val)
        # 更新实时显示标签
        if int_val == 0:
            self._stay_value_label.config(text="智能", foreground="#cc6600")
        else:
            self._stay_value_label.config(text=f"{int_val}秒", foreground="#0066cc")

    def _on_stay_entry_changed(self, event=None):
        """输入框值变更回调：同步到滑块和显示标签"""
        try:
            val = int(self.step_vars['step_stay'].get() or '3')
        except (ValueError, TypeError):
            val = 3
        # 限制范围
        val = max(0, min(120, val))
        self._stay_time_var.set(val)
        self.step_vars['step_stay'].set(str(val))
        if val == 0:
            self._stay_value_label.config(text="智能", foreground="#cc6600")
        else:
            self._stay_value_label.config(text=f"{val}秒", foreground="#0066cc")

    def _on_loop_infinite_changed(self):
        """无限循环勾选变更：勾选时禁用次数输入框，取消勾选时恢复"""
        if self._loop_infinite_var.get():
            self._loop_count_entry.config(state=tk.DISABLED)
            self.step_vars['step_loop_count'].set("∞")
        else:
            self._loop_count_entry.config(state=tk.NORMAL)
            self.step_vars['step_loop_count'].set("1")

    def _on_media_end_action_changed(self, event=None):
        """媒体播放结束后操作变更：动态更新标签、提示和标签页行可见性"""
        action_str = self._on_end_action_var.get()
        action_key = action_str.split(' - ')[0].strip() if ' - ' in action_str else action_str.strip()

        # 根据操作类型更新标签和提示
        label_map = {
            'none':      ('目标选择器:', '', tk.DISABLED, tk.DISABLED, False),
            'click':     ('目标选择器:', '(要点击的按钮/链接选择器)', tk.NORMAL, tk.NORMAL, True),
            'navigate':  ('跳转URL:', '(播放结束后跳转的页面地址)', tk.NORMAL, tk.DISABLED, False),
            'play_next': ('媒体选择器:', '(下一个媒体元素选择器，留空则自动查找)', tk.NORMAL, tk.NORMAL, True),
            'wait':      ('等待秒数:', '(播放结束后额外等待的秒数)', tk.NORMAL, tk.DISABLED, False),
            'refresh':   ('目标选择器:', '', tk.DISABLED, tk.DISABLED, False),
        }
        default = ('目标选择器:', '', tk.NORMAL, tk.DISABLED, False)
        label_text, hint_text, entry_state, pick_state, show_tab = \
            label_map.get(action_key, default)

        self._media_end_target_label.config(text=label_text)
        self._on_end_target_hint.config(text=hint_text)
        self._on_end_target_entry.config(state=entry_state)
        self._media_end_pick_btn.config(state=pick_state)

        # 目标标签页行：仅 click / play_next 时显示
        if show_tab:
            self._media_end_tab_label.grid()
            self._media_end_tab_frame.grid()
            self._refresh_media_end_tab_list()
        else:
            self._media_end_tab_label.grid_remove()
            self._media_end_tab_frame.grid_remove()

        # 无操作/刷新时清空目标值
        if action_key in ('none', 'refresh'):
            self._on_end_target_var.set('')

        # 更新策略说明
        desc_map = {
            'none':      '💡 播放结束后不执行任何操作，继续下一步骤。',
            'click':     '💡 播放结束后自动点击指定按钮/链接，适用于"下一课"等场景。可指定目标标签页。',
            'navigate':  '💡 播放结束后跳转到指定URL，适用于切换课程页面。',
            'play_next': '💡 播放结束后自动查找并播放下一个媒体元素，适用于连续播放。可指定目标标签页。',
            'wait':      '💡 播放结束后等待指定秒数再继续，适用于页面加载缓冲。',
            'refresh':   '💡 播放结束后刷新当前页面，适用于重置播放状态。',
        }
        self._media_end_desc.config(text=desc_map.get(action_key, ''))

    def _on_step_select(self, event=None):
        # 切换步骤前，先保存当前步骤的编辑区数据（包括 play_list），防止数据丢失
        if 0 <= self._current_step_idx < len(self._nav_data):
            self._sync_step_edit_to_data()

        sel = self.step_listbox.curselection()
        if not sel:
            return
        self._current_step_idx = sel[0]

        # 切换步骤时清空选择器候选列表，保持数据状态一致
        self._selector_candidates.delete(0, tk.END)
        self._candidate_data = []

        nav = self._nav_data[self._current_step_idx]
        self.step_vars['step_name'].set(nav.get('name', ''))
        action_key = nav.get('action', 'navigate')
        # 设置操作类型（用 "key - label" 格式）
        action_def = self.ACTION_DEFS.get(action_key, {})
        action_label = action_def.get('label', action_key)
        self.step_vars['step_action'].set(f"{action_key} - {action_label}")
        self.step_vars['step_url'].set(nav.get('url', ''))
        self.step_vars['step_selector'].set(nav.get('selector', ''))
        self.step_vars['step_stay'].set(str(nav.get('stay_time', 3)))
        # 同步滑块和标签
        try:
            stay_val = int(nav.get('stay_time', 3))
        except (ValueError, TypeError):
            stay_val = 3
        stay_val = max(0, min(120, stay_val))
        self._stay_time_var.set(stay_val)
        if stay_val == 0:
            self._stay_value_label.config(text="智能", foreground="#cc6600")
        else:
            self._stay_value_label.config(text=f"{stay_val}秒", foreground="#0066cc")
        self.step_vars['step_tab_index'].set(str(nav.get('tab_index', -1)))

        # 加载循环次数
        loop_infinite = nav.get('loop_infinite', False)
        self._loop_infinite_var.set(loop_infinite)
        if loop_infinite:
            self.step_vars['step_loop_count'].set("∞")
            self._loop_count_entry.config(state=tk.DISABLED)
        else:
            loop_count = nav.get('loop_count', 1)
            self.step_vars['step_loop_count'].set(str(loop_count))
            self._loop_count_entry.config(state=tk.NORMAL)

        # 重建参数区并填充值
        self._rebuild_param_frame(action_key)
        for key, val in nav.items():
            if key in self._param_widgets:
                self._param_widgets[key][1].set(str(val))

        # 更新 UI 可见性
        self._on_action_changed()

        # 加载媒体播放完成设置（仅 play_wait / play_next）
        if action_key in ('play_wait', 'play_next'):
            end_action = nav.get('on_end_action', 'none')
            # 构建 "key - label" 格式的下拉值
            end_action_labels = {
                'none': '无操作', 'click': '点击元素', 'navigate': '跳转URL',
                'play_next': '播放下一媒体', 'wait': '等待(秒)', 'refresh': '刷新页面',
            }
            end_label = end_action_labels.get(end_action, '')
            self._on_end_action_var.set(f"{end_action} - {end_label}")
            self._on_end_target_var.set(nav.get('on_end_target', ''))
            self._on_end_wait_var.set(str(nav.get('on_end_wait', 0)))
            self._on_end_tab_var.set(str(nav.get('on_end_tab_index', -1)))
            # 触发标签更新
            self._on_media_end_action_changed()

        # 加载按列表播放数据（仅 play_list）
        if action_key == 'play_list':
            play_list_data = nav.get('play_list', [])
            self._play_list_load_data(play_list_data)
            # 加载录音设置
            self._play_list_enable_recording_var.set(nav.get('enable_recording', False))
            self._play_list_recording_format_var.set(nav.get('recording_format', 'WEBM'))

        # 加载步骤弹窗规则
        self._load_step_popup_rules(nav)

    def _sync_step_edit_to_data(self):
        """将编辑区内容同步到 _nav_data"""
        if self._current_step_idx < 0 or self._current_step_idx >= len(self._nav_data):
            return False
        try:
            action_key = self._parse_action_key(self.step_vars['step_action'].get())
            tab_index = self._get_target_tab_index()
            data = {
                'name': self.step_vars['step_name'].get().strip(),
                'action': action_key,
                'url': self.step_vars['step_url'].get().strip(),
                'selector': self.step_vars['step_selector'].get().strip(),
                'tab_index': tab_index,
                'stay_time': int(self.step_vars['step_stay'].get() or 3),
                'loop_infinite': self._loop_infinite_var.get(),
            }
            # 循环次数：无限循环时存0，否则存具体数值
            if self._loop_infinite_var.get():
                data['loop_count'] = 0
            else:
                try:
                    data['loop_count'] = max(1, int(self.step_vars['step_loop_count'].get() or 1))
                except (ValueError, TypeError):
                    data['loop_count'] = 1
            # 合并通用操作参数
            for key, (label, var, entry) in self._param_widgets.items():
                data[key] = var.get()

            # 合并媒体播放完成设置（仅 play_wait / play_next）
            if action_key in ('play_wait', 'play_next'):
                end_action_str = self._on_end_action_var.get()
                end_action_key = end_action_str.split(' - ')[0].strip() if ' - ' in end_action_str else end_action_str.strip()
                data['on_end_action'] = end_action_key
                data['on_end_target'] = self._on_end_target_var.get().strip()
                try:
                    data['on_end_wait'] = float(self._on_end_wait_var.get() or 0)
                except (ValueError, TypeError):
                    data['on_end_wait'] = 0
                # 保存目标标签页索引
                try:
                    data['on_end_tab_index'] = int(self._on_end_tab_var.get() or '-1')
                except (ValueError, TypeError):
                    data['on_end_tab_index'] = -1

            # 合并按列表播放数据（仅 play_list）
            if action_key == 'play_list':
                data['play_list'] = self._play_list_get_data()
                # 保存录音设置到步骤级别
                data['enable_recording'] = self._play_list_enable_recording_var.get()
                data['recording_format'] = self._play_list_recording_format_var.get()

            # 保存步骤弹窗规则
            data['popup_rules'] = list(self._current_step_popup_rules)

            self._nav_data[self._current_step_idx] = data
            return True
        except (ValueError, KeyError) as e:
            self.logger.error(f"步骤数据同步失败: {e}")
            return False

    def _add_step(self):
        self._nav_data.append({
            'name': f'步骤{len(self._nav_data) + 1}',
            'action': 'navigate', 'url': '', 'selector': '', 'tab_index': -1,
            'stay_time': 3, 'loop_count': 1, 'loop_infinite': False,
            'play_list': []
        })
        self._refresh_step_list()
        self.step_listbox.selection_set(len(self._nav_data) - 1)
        self._on_step_select()

    def _update_step(self):
        if not self._sync_step_edit_to_data():
            self.logger.warning("更新失败：未选中步骤或数据格式错误")
            return
        idx = self._current_step_idx
        self._refresh_step_list()
        # 恢复选中状态
        if 0 <= idx < len(self._nav_data):
            self.step_listbox.selection_set(idx)
            self.step_listbox.see(idx)
        # 自动保存到配置文件
        self.config_loader.set_navigation(self._nav_data)
        try:
            self.config_loader.save()
            # 同步运行时对象
            self.task_runner.navigation_list = copy.deepcopy(self._nav_data)
            self.logger.info(f"步骤已更新并保存: {self._nav_data[idx].get('name', '')}")
        except Exception as e:
            self.logger.error(f"步骤更新后保存失败: {e}")

    def _delete_step(self):
        if self._current_step_idx < 0 or self._current_step_idx >= len(self._nav_data):
            return
        del self._nav_data[self._current_step_idx]
        self._current_step_idx = -1
        self._refresh_step_list()

    def _move_step(self, delta):
        idx = self._current_step_idx
        if idx < 0 or idx >= len(self._nav_data):
            return
        new_idx = idx + delta
        if 0 <= new_idx < len(self._nav_data):
            self._nav_data[idx], self._nav_data[new_idx] = self._nav_data[new_idx], self._nav_data[idx]
            self._current_step_idx = new_idx
            self._refresh_step_list()
            self.step_listbox.selection_set(new_idx)
            self.step_listbox.see(new_idx)

    # ================================================================
    #  弹窗规则管理
    # ================================================================
    def _refresh_popup_list(self):
        self.popup_listbox.delete(0, tk.END)
        for i, rule in enumerate(self._popup_data):
            kw = rule.get('keyword', '')
            tp = rule.get('type', 'alert')
            tab_idx = rule.get('tab_index', -1)
            tab_suffix = f" [Tab{tab_idx}]" if tab_idx >= 0 else ""
            self.popup_listbox.insert(tk.END, f"{i + 1}. [{tp}]{tab_suffix} {kw}")

    def _refresh_popup_tab_list(self):
        """刷新弹窗规则的标签页下拉列表"""
        if not self.browser.context:
            self._popup_tab_combo['values'] = []
            self._popup_tab_combo.set('')
            return

        pages = self.browser.list_pages()
        if not pages:
            self._popup_tab_combo['values'] = ['(无标签页)']
            self._popup_tab_combo.set('')
            return

        self._popup_tab_data = pages
        tab_labels = []
        for p in pages:
            marker = " ★" if p['is_current'] else ""
            title = p['title'][:30] if p['title'] else '(无标题)'
            url_short = p['url'][:50] if p['url'] else ''
            tab_labels.append(f"{p['index']}: {title}{marker}  {url_short}")

        self._popup_tab_combo['values'] = tab_labels

        # 恢复选中项
        try:
            target_idx = int(self.popup_vars['popup_tab_index'].get())
        except (ValueError, TypeError):
            target_idx = -1

        if target_idx < 0:
            for i, p in enumerate(pages):
                if p['is_current']:
                    self._popup_tab_combo.current(i)
                    return
            if pages:
                self._popup_tab_combo.current(0)
        else:
            for i, p in enumerate(pages):
                if p['index'] == target_idx:
                    self._popup_tab_combo.current(i)
                    return
            for i, p in enumerate(pages):
                if p['is_current']:
                    self._popup_tab_combo.current(i)
                    return

    def _on_popup_tab_selected(self, event=None):
        """弹窗规则标签页下拉选择变更"""
        sel = self._popup_tab_combo.current()
        if sel < 0 or not hasattr(self, '_popup_tab_data') or sel >= len(self._popup_tab_data):
            self.popup_vars['popup_tab_index'].set('-1')
            return
        tab_info = self._popup_tab_data[sel]
        self.popup_vars['popup_tab_index'].set(str(tab_info['index']))

    def _refresh_media_end_tab_list(self):
        """刷新媒体完成后目标标签页的下拉列表，并恢复选中项"""
        if not self.browser.context:
            self._media_end_tab_combo['values'] = []
            self._media_end_tab_combo.set('')
            return

        pages = self.browser.list_pages()
        if not pages:
            self._media_end_tab_combo['values'] = ['(无标签页)']
            self._media_end_tab_combo.set('')
            return

        self._media_end_tab_data = pages
        tab_labels = []
        for p in pages:
            marker = " ★" if p['is_current'] else ""
            title = p['title'][:30] if p['title'] else '(无标题)'
            url_short = p['url'][:50] if p['url'] else ''
            tab_labels.append(f"{p['index']}: {title}{marker}  {url_short}")

        self._media_end_tab_combo['values'] = tab_labels

        # 恢复选中项
        try:
            target_idx = int(self._on_end_tab_var.get())
        except (ValueError, TypeError):
            target_idx = -1

        if target_idx < 0:
            # -1 表示当前标签页
            for i, p in enumerate(pages):
                if p['is_current']:
                    self._media_end_tab_combo.current(i)
                    return
            if pages:
                self._media_end_tab_combo.current(0)
        else:
            for i, p in enumerate(pages):
                if p['index'] == target_idx:
                    self._media_end_tab_combo.current(i)
                    return
            for i, p in enumerate(pages):
                if p['is_current']:
                    self._media_end_tab_combo.current(i)
                    return

    # ================================================================
    #  按列表播放 - 播放列表表格操作
    # ================================================================
    def _play_list_add_row(self):
        """添加一行空的播放列表项"""
        self._play_list_tree.insert('', tk.END, values=(len(self._play_list_tree.get_children()) + 1, '', '', '□', '□', ''))

    def _play_list_delete_row(self):
        """删除选中的播放列表行"""
        sel = self._play_list_tree.selection()
        if not sel:
            return
        self._play_list_tree.delete(sel[0])
        # 重新编号
        self._play_list_renumber()

    def _play_list_move_up(self):
        """上移选中的行"""
        sel = self._play_list_tree.selection()
        if not sel:
            return
        idx = self._play_list_tree.index(sel[0])
        if idx == 0:
            return
        values = self._play_list_tree.item(sel[0])['values']
        prev = self._play_list_tree.get_children()[idx - 1]
        prev_values = self._play_list_tree.item(prev)['values']
        self._play_list_tree.item(sel[0], values=prev_values)
        self._play_list_tree.item(prev, values=values)
        self._play_list_renumber()

    def _play_list_move_down(self):
        """下移选中的行"""
        sel = self._play_list_tree.selection()
        if not sel:
            return
        idx = self._play_list_tree.index(sel[0])
        children = self._play_list_tree.get_children()
        if idx >= len(children) - 1:
            return
        values = self._play_list_tree.item(sel[0])['values']
        next_item = children[idx + 1]
        next_values = self._play_list_tree.item(next_item)['values']
        self._play_list_tree.item(sel[0], values=next_values)
        self._play_list_tree.item(next_item, values=values)
        self._play_list_renumber()

    def _play_list_renumber(self):
        """重新编号表格行"""
        for i, item in enumerate(self._play_list_tree.get_children(), 1):
            values = list(self._play_list_tree.item(item)['values'])
            values[0] = i
            self._play_list_tree.item(item, values=values)

    def _play_list_on_select(self, event=None):
        """选中表格行时，加载到编辑区域"""
        sel = self._play_list_tree.selection()
        if not sel:
            return
        values = self._play_list_tree.item(sel[0])['values']
        # 表格格式：# (0), URL (1), 选择器 (2), 点击播放 (3), 已完成 (4), 录音文件 (5)
        if len(values) >= 5:
            self._play_list_url_var.set(values[1] if len(values) > 1 else '')
            self._play_list_selector_var.set(values[2] if len(values) > 2 else '')
            self._play_list_click_play_var.set(values[3] == '✓')
            self._play_list_completed_var.set(values[4] == '✓')
            # 加载录音名称（从 _nav_data 中查找）
            idx = self._play_list_tree.index(sel[0])
            if (self._current_step_idx >= 0 and self._current_step_idx < len(self._nav_data)
                    and self._nav_data[self._current_step_idx].get('action') == 'play_list'):
                play_list_data = self._nav_data[self._current_step_idx].get('play_list', [])
                if idx < len(play_list_data):
                    self._play_list_audio_name_var.set(play_list_data[idx].get('audio_name', ''))
                else:
                    self._play_list_audio_name_var.set('')
            else:
                self._play_list_audio_name_var.set('')

    def _play_list_save_row(self):
        """保存编辑区域的修改到选中的表格行，并同步到配置数据"""
        sel = self._play_list_tree.selection()
        if not sel:
            return
        url = self._play_list_url_var.get().strip()
        
        # URL重复检测
        if url:
            # 获取所有播放列表项
            all_items = self._play_list_tree.get_children()
            current_item_idx = self._play_list_tree.index(sel[0])
            
            # 检查是否有其他行包含相同的URL
            duplicate_indices = []
            for i, item in enumerate(all_items):
                if i == current_item_idx:  # 跳过当前正在编辑的行
                    continue
                values = self._play_list_tree.item(item)['values']
                if len(values) >= 5 and values[1] == url:  # values[1] 是URL
                    duplicate_indices.append(i + 1)  # 显示行号从1开始
            
            if duplicate_indices:
                messagebox.showerror(
                    "URL重复检测", 
                    f"检测到URL重复！\n\n"
                    f"当前URL: {url}\n"
                    f"重复行号: {', '.join(map(str, duplicate_indices))}\n\n"
                    f"请修改URL或删除重复项，避免重复添加相同的学习网页。"
                )
                return
        
        selector = self._play_list_selector_var.get().strip()
        click_play = '✓' if self._play_list_click_play_var.get() else '□'
        completed = '✓' if self._play_list_completed_var.get() else '□'
        audio_name = self._play_list_audio_name_var.get().strip()
        # 保留已有的录音文件信息
        existing_vals = list(self._play_list_tree.item(sel[0])['values'])
        audio_file = existing_vals[5] if len(existing_vals) >= 6 else ''
        idx = self._play_list_tree.index(sel[0])
        self._play_list_tree.item(sel[0], values=(idx + 1, url, selector, click_play, completed, audio_file))
        # 同步到 _nav_data 并保存配置文件（audio_name 通过 _sync_step_edit_to_data 保存）
        if (self._current_step_idx >= 0 and self._current_step_idx < len(self._nav_data)
                and self._nav_data[self._current_step_idx].get('action') == 'play_list'):
            play_list_data = self._nav_data[self._current_step_idx].get('play_list', [])
            if idx < len(play_list_data):
                play_list_data[idx]['audio_name'] = audio_name
                # 同时保存 audio_file 到 nav_data（如果表格中有值但 nav_data 没有）
                if audio_file and not play_list_data[idx].get('audio_file'):
                    play_list_data[idx]['audio_file'] = audio_file
        self._sync_step_edit_to_data()
        self.config_loader.set_navigation(self._nav_data)
        try:
            self.config_loader.save()
            self.logger.info(f"[播放列表] 已保存第{idx + 1}行数据（选择器: {selector or '(空)'}, 点击播放: {click_play}）")
        except Exception as e:
            self.logger.error(f"[播放列表] 保存配置失败: {e}")

    def _play_list_test_play(self):
        """测试播放：获取当前选中行的URL，在浏览器中打开以测试视频播放效果"""
        url = self._play_list_url_var.get().strip()
        if not url:
            messagebox.showwarning("测试播放", "当前选中行没有URL地址，请先填写URL。")
            return
        self.logger.info(f"[播放列表] 测试播放: {url}")
        import webbrowser
        webbrowser.open(url)

    def _play_list_play_recording(self):
        """播放录音：使用系统默认播放器打开选中的录音文件"""
        sel = self._play_list_tree.selection()
        if not sel:
            messagebox.showwarning("播放录音", "请先在表格中选中一个包含录音文件的播放列表行。")
            return
        values = self._play_list_tree.item(sel[0])['values']
        audio_file = values[5] if len(values) >= 6 else ''
        if not audio_file:
            messagebox.showinfo("播放录音", "当前选中行没有录音文件。\n\n请先启用音频录制并完成播放后，录音文件会自动保存。")
            return
        # 将相对路径转为绝对路径（相对于 skill 根目录）
        skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        abs_path = os.path.join(skill_dir, audio_file)
        if not os.path.exists(abs_path):
            messagebox.showerror("播放录音", f"录音文件不存在:\n{abs_path}")
            return
        self.logger.info(f"[播放录音] 打开: {abs_path}")
        self._open_file(abs_path)

    @staticmethod
    def _open_file(filepath: str):
        """跨平台打开文件（使用系统默认程序）

        Args:
            filepath: 文件绝对路径
        """
        import platform
        import subprocess
        try:
            if platform.system() == 'Windows':
                os.startfile(filepath)
            elif platform.system() == 'Darwin':  # macOS
                subprocess.call(['open', filepath])
            else:  # Linux
                subprocess.call(['xdg-open', filepath])
        except Exception as e:
            logging.getLogger(__name__).warning(f"[打开文件] 无法打开 {filepath}: {e}")

    def _play_list_summarize(self):
        """总结按钮回调（all 模式）：对选中的录音文件进行转写+总结"""
        sel = self._play_list_tree.selection()
        if not sel:
            messagebox.showwarning("AI总结", "请先在表格中选中一个包含录音文件的播放列表行。")
            return
        values = self._play_list_tree.item(sel[0])['values']
        audio_file = values[5] if len(values) >= 6 else ''
        if not audio_file:
            messagebox.showinfo("AI总结", "当前选中行没有录音文件。\n\n请先启用音频录制并完成播放后，再使用总结功能。")
            return
        skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        abs_path = os.path.join(skill_dir, audio_file)
        if not os.path.exists(abs_path):
            messagebox.showerror("AI总结", f"录音文件不存在:\n{abs_path}")
            return
        # 获取音频名称
        audio_name = self._play_list_audio_name_var.get() or os.path.basename(abs_path)
        # 在新线程中执行转写+总结
        threading.Thread(target=self._do_summarize_audio,
                         args=(abs_path, audio_name), daemon=True).start()

    def _do_summarize_audio(self, audio_path: str, audio_name: str = ''):
        """核心总结流程：讯飞转写 → AI 总结 → 展示结果

        此方法在后台线程中执行，通过主线程调度弹窗展示结果。

        Args:
            audio_path: 录音文件绝对路径
            audio_name: 录音显示名称
        """
        import tkinter as tk

        # 通过主线程创建进度弹窗（tkinter 线程安全要求）
        progress_window = None
        status_label = None
        progress_bar = None
        detail_label = None
        window_ready = threading.Event()

        def _create_progress_window():
            nonlocal progress_window, status_label, progress_bar, detail_label
            try:
                progress_window = tk.Toplevel(self.root)
                progress_window.title("AI 总结进度")
                progress_window.geometry("450x250")
                progress_window.transient(self.root)
                progress_window.grab_set()
                progress_window.resizable(False, False)

                # 居中
                progress_window.update_idletasks()
                x = self.root.winfo_x() + (self.root.winfo_width() - 450) // 2
                y = self.root.winfo_y() + (self.root.winfo_height() - 250) // 2
                progress_window.geometry(f"+{x}+{y}")

                status_label = tk.Label(progress_window, text="正在初始化...",
                                        font=("Microsoft YaHei", 10),
                                        wraplength=400, justify=tk.LEFT)
                status_label.pack(pady=(20, 10))

                progress_bar = ttk.Progressbar(progress_window, mode='indeterminate', length=400)
                progress_bar.pack(pady=(5, 10))
                progress_bar.start()

                detail_label = tk.Label(progress_window, text="",
                                        font=("Microsoft YaHei", 8),
                                        foreground="gray", wraplength=400)
                detail_label.pack(pady=(0, 10))
            finally:
                window_ready.set()

        self.root.after(0, _create_progress_window)
        window_ready.wait(timeout=10)

        def update_status(status_text, detail_text=''):
            """线程安全地更新进度窗口"""
            try:
                if progress_window and progress_window.winfo_exists():
                    if status_label:
                        progress_window.after(0, lambda: status_label.config(text=status_text))
                    if detail_text and detail_label:
                        progress_window.after(0, lambda: detail_label.config(text=detail_text))
            except Exception:
                pass

        def close_progress():
            """关闭进度窗口"""
            try:
                if progress_window and progress_window.winfo_exists():
                    progress_window.after(0, progress_window.destroy)
            except Exception:
                pass

        def show_result(summary_text):
            """在主线程中展示总结结果"""
            try:
                if not self.root.winfo_exists():
                    return
                self.root.after(0, lambda: self._show_summary_result(audio_name, summary_text))
            except Exception as e:
                self.logger.error(f"[AI总结] 展示结果失败: {e}")

        try:
            # ==================== 步骤 1：加载讯飞配置 ====================
            update_status("正在加载讯飞配置...", "读取 config/AImodel.yaml")

            try:
                from .ai_model import AIModelConfig
                ai_config = AIModelConfig()
                xunfei_cfg = ai_config.get_provider_config('xunfei_lfasr')

                if not xunfei_cfg:
                    update_status("错误", "未找到科大讯飞转写配置 (xunfei_lfasr)")
                    time.sleep(2)
                    close_progress()
                    self.root.after(0, lambda: messagebox.showerror(
                        "AI总结", "未找到科大讯飞转写配置。\n请检查 config/AImodel.yaml 中的 xunfei_lfasr 段。"))
                    return

                if not xunfei_cfg.get('enabled', False):
                    update_status("提示", "科大讯飞转写未启用，请编辑配置文件启用")
                    time.sleep(2)
                    close_progress()
                    self.root.after(0, lambda: messagebox.showinfo(
                        "AI总结", "科大讯飞转写未启用。\n请在 config/AImodel.yaml 中将 xunfei_lfasr.enabled 设为 true。"))
                    return

                self.logger.info(f"[AI总结] 讯飞配置已加载: app_id={xunfei_cfg.get('app_id', 'N/A')[:8]}...")

            except Exception as e:
                self.logger.error(f"[AI总结] 加载讯飞配置失败: {e}")
                update_status("错误", f"加载配置失败: {e}")
                time.sleep(2)
                close_progress()
                self.root.after(0, lambda: messagebox.showerror(
                    "AI总结", f"加载讯飞配置失败:\n{e}"))
                return

            # ==================== 步骤 2：科大讯飞转写 ====================
            update_status("正在转写录音文件...", f"文件: {os.path.basename(audio_path)}")

            try:
                from .xunfei_transcriber import XunfeiLfasrTranscriber

                transcriber = XunfeiLfasrTranscriber(xunfei_cfg)

                # 验证凭证
                if not transcriber._validate_credentials():
                    update_status("凭证验证失败", "请检查 app_id、secret_key、api_key")
                    time.sleep(2)
                    close_progress()
                    self.root.after(0, lambda: messagebox.showerror(
                        "AI总结",
                        "科大讯飞凭证验证失败。\n请在 config/AImodel.yaml 的 xunfei_lfasr 段中填写:\n"
                        "  - app_id\n  - secret_key\n  - api_key"))
                    return

                self.logger.info(f"[AI总结] 凭证验证通过，开始调用讯飞 API...")

                # 进度回调
                last_desc = []

                def on_progress(progress):
                    desc = progress.get('desc', '')
                    status = progress.get('status', 0)
                    if desc and (not last_desc or desc != last_desc[0]):
                        last_desc.clear()
                        last_desc.append(desc)
                        update_status(f"转写中... (status={status})", desc)

                update_status("正在上传音频文件到讯飞服务器...",
                             f"文件: {os.path.basename(audio_path)}")

                result = transcriber.transcribe(audio_path, on_progress=on_progress)

                if not result or not result.get('text'):
                    update_status("转写失败", "返回空文本，请检查音频文件格式")
                    time.sleep(2)
                    close_progress()
                    self.root.after(0, lambda: messagebox.showerror(
                        "AI总结",
                        "科大讯飞转写返回空文本。\n"
                        "可能原因:\n"
                        "1. 音频文件格式不支持\n"
                        "2. 音频文件损坏\n"
                        "3. 网络连接异常\n"
                        "4. API 余额不足"))
                    return

                transcribed_text = result.get('text', '')
                self.logger.info(f"[AI总结] 转写完成: 文本长度={len(transcribed_text)}")
                update_status("转写完成!", f"共识别 {len(transcribed_text)} 个字符")

            except Exception as e:
                self.logger.error(f"[AI总结] 转写失败: {e}")
                update_status("转写失败", str(e))
                time.sleep(2)
                close_progress()
                self.root.after(0, lambda: messagebox.showerror(
                    "AI总结", f"科大讯飞转写失败:\n{e}"))
                return

            # ==================== 步骤 3：AI 总结 ====================
            update_status("正在检查 AI 配置...", "验证 API 密钥")

            try:
                from .ai_model import AIModelCaller

                caller = AIModelCaller()
                default_provider = ai_config.get_global('default_provider', 'siliconflow')

                # 检查 API Key 是否有效（非空且非占位符）
                provider_config = ai_config.get_provider_config(default_provider)
                api_key = provider_config.get('api_key', '').strip()
                placeholder_keys = {'your-api-key-here', '', 'xxx', 'placeholder'}

                if api_key.lower() in placeholder_keys or not api_key:
                    self.logger.warning(
                        f"[AI总结] AI 提供商 {default_provider} 的 API Key 未配置或为占位符"
                    )
                    # 尝试寻找其他可用的 AI 提供商
                    available_providers = []
                    for pname in ['siliconflow', 'deepseek', 'openai']:
                        pconf = ai_config.get_provider_config(pname)
                        pkey = pconf.get('api_key', '').strip()
                        if pkey and pkey.lower() not in placeholder_keys and pconf.get('enabled', False):
                            available_providers.append((pname, pconf.get('name', pname)))

                    if available_providers:
                        # 使用第一个可用的提供商
                        use_provider = available_providers[0][0]
                        self.logger.info(
                            f"[AI总结] 自动切换到可用提供商: {available_providers[0][1]}"
                        )
                        update_status(
                            f"使用 {available_providers[0][1]} 生成总结...",
                            f"默认提供商 {default_provider} 未配置，已自动切换"
                        )
                    else:
                        # 所有提供商都不可用，仅展示转写结果
                        self.logger.warning("[AI总结] 没有可用的 AI 提供商，跳过 AI 总结")
                        close_progress()
                        show_result(
                            f"# {audio_name or '录音文件'} - 转写结果\n\n"
                            f"## 原始转写文本\n\n{transcribed_text}\n\n"
                            f"---\n\n"
                            f"## AI 总结\n\n"
                            f"AI 总结未生成。原因：未配置有效的 API 密钥。\n\n"
                            f"**配置方法：**\n"
                            f"1. 打开 `config/AImodel.yaml`\n"
                            f"2. 在 `models.{default_provider}.api_key` 中填写你的 API 密钥\n"
                            f"3. 支持的提供商：\n"
                            f"   - SiliconFlow（推荐国内使用）: https://cloud.siliconflow.cn\n"
                            f"   - DeepSeek: https://platform.deepseek.com\n"
                            f"   - OpenAI: https://platform.openai.com\n"
                            f"   - Ollama（本地免费）: https://ollama.com\n"
                        )
                        return
                else:
                    use_provider = default_provider
                    update_status("正在生成 AI 总结...", f"使用 {provider_config.get('name', default_provider)}")

                caller_provider_config = ai_config.get_provider_config(use_provider)

                system_prompt = ai_config.get_system_prompt('meeting_notes')
                if not system_prompt:
                    system_prompt = ai_config.get_system_prompt('default')

                user_prompt = f"""请对以下学习视频的转录文本进行总结：

标题：{audio_name or '未命名录音'}

转录文本：
{transcribed_text[:8000]}"""

                summary_text = caller.call_with_retry(
                    prompt=user_prompt,
                    system_prompt=system_prompt,
                    provider=use_provider
                )

                self.logger.info(f"[AI总结] AI 总结完成: 长度={len(summary_text) if summary_text else 0}")
                update_status("总结完成!", "正在展示结果...")
                time.sleep(0.5)
                close_progress()

                # 展示结果
                full_result = f"""# {audio_name or '录音文件'} - AI 总结

## 原始转写文本

{transcribed_text}

---

## AI 智能总结

{summary_text if summary_text else '(AI 总结生成失败，仅显示转写文本)'}
"""
                show_result(full_result)

            except Exception as e:
                self.logger.error(f"[AI总结] AI 总结失败: {e}")
                close_progress()
                # 即使总结失败，也展示转写结果
                error_hint = str(e)
                if '401' in error_hint or 'Invalid' in error_hint.lower() or 'token' in error_hint.lower():
                    error_hint += (
                        "\n\n这可能是因为 API Key 无效或已过期。\n"
                        "请在 config/AImodel.yaml 中检查并更新 API 密钥。"
                    )
                show_result(f"# {audio_name or '录音文件'} - 转写结果\n\n"
                           f"(AI 总结生成失败: {error_hint})\n\n"
                           f"## 原始转写文本\n\n{transcribed_text}")

        except Exception as e:
            self.logger.error(f"[AI总结] 整体流程异常: {e}")
            close_progress()
            self.root.after(0, lambda: messagebox.showerror(
                "AI总结", f"总结流程异常:\n{e}"))

    def _show_summary_result(self, title: str, content: str):
        """在主线程中展示总结结果窗口

        Args:
            title: 窗口标题
            content: Markdown 格式的总结内容
        """
        import tkinter as tk
        from tkinter import scrolledtext

        result_window = tk.Toplevel(self.root)
        result_window.title(f"AI总结 - {title[:30]}")
        result_window.geometry("700x550")
        result_window.transient(self.root)
        result_window.resizable(True, True)
        result_window.minsize(500, 400)

        # 居中
        result_window.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() - 700) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - 550) // 2
        result_window.geometry(f"+{x}+{y}")

        # 文本区域
        text_frame = ttk.Frame(result_window)
        text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        text_widget = scrolledtext.ScrolledText(
            text_frame, wrap=tk.WORD, font=("Microsoft YaHei", 10),
            padx=10, pady=10
        )
        text_widget.pack(fill=tk.BOTH, expand=True)
        text_widget.insert(tk.END, content)
        text_widget.config(state=tk.DISABLED)

        # 底部按钮
        btn_frame = ttk.Frame(result_window)
        btn_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

        def copy_to_clipboard():
            """复制到剪贴板"""
            result_window.clipboard_clear()
            result_window.clipboard_append(content.strip())
            messagebox.showinfo("已复制", "总结内容已复制到剪贴板")

        def save_to_file():
            """保存到文件"""
            from tkinter import filedialog
            file_path = filedialog.asksaveasfilename(
                parent=result_window,
                title="保存总结",
                defaultextension=".md",
                filetypes=[("Markdown 文件", "*.md"), ("文本文件", "*.txt"), ("所有文件", "*.*")],
                initialfile=f"{title[:30]}_总结.md"
            )
            if file_path:
                try:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(content)
                    messagebox.showinfo("保存成功", f"已保存到:\n{file_path}")
                except Exception as e:
                    messagebox.showerror("保存失败", str(e))

        ttk.Button(btn_frame, text="复制到剪贴板", command=copy_to_clipboard).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_frame, text="保存到文件", command=save_to_file).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_frame, text="关闭", command=result_window.destroy).pack(side=tk.RIGHT)

    def _play_list_get_data(self):
        """从表格中获取播放列表数据，返回 list[dict]（使用 task_runner 期望的 key 格式）"""
        result = []
        for item in self._play_list_tree.get_children():
            values = self._play_list_tree.item(item)['values']
            # 表格格式：# (0), URL (1), 选择器 (2), 点击播放 (3), 已完成 (4), 录音文件 (5)
            # 返回格式需与 task_runner.py 的 _execute_play_list 期望一致
            if len(values) >= 5:
                entry = {
                    'url': values[1],                       # task_runner 期望 'url'
                    '选择器': values[2] if values[2] else '',
                    'click_play': values[3] == '✓',         # 是否自动点击播放
                    'completed': values[4] == '✓'           # task_runner 期望 'completed'
                }
                # 保留已有的录音文件信息
                if len(values) >= 6 and values[5]:
                    entry['audio_file'] = values[5]
                result.append(entry)
        return result

    def _play_list_load_data(self, play_list_data):
        """将播放列表数据加载到表格中"""
        # 清空表格
        for item in self._play_list_tree.get_children():
            self._play_list_tree.delete(item)
        # 加载数据（支持中文 key 和英文 key 两种格式以保持兼容性）
        if not play_list_data:
            return
        for i, entry in enumerate(play_list_data, 1):
            url = entry.get('url', '') or entry.get('播放网页url', '')
            selector = entry.get('选择器', '')
            click_play = '✓' if entry.get('click_play', False) else '□'
            completed = '✓' if (entry.get('completed', False) or entry.get('是否已完成播放', False)) else '□'
            audio_file = entry.get('audio_file', '') or ''
            self._play_list_tree.insert('', tk.END, values=(i, url, selector, click_play, completed, audio_file))

    def _start_play_list_pick(self):
        """播放列表选择器点选：在当前页面点选元素，将选择器填入编辑区"""
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return

        self.logger.info("[点选] 启动播放列表选择器点选，请在浏览器中点击目标元素...")
        self._play_list_pick_btn.config(state=tk.DISABLED, text="点选中...")
        self._play_list_cancel_pick_btn.config(state=tk.NORMAL)

        try:
            # 在主线程注入 JS（Playwright 要求同线程）
            self.browser.page.evaluate(BrowserManager._INJECT_JS)
            # 保存窗口状态并最小化主窗口
            self._save_and_iconify()
            # 将浏览器窗口提到前台并获得焦点
            self.browser.bring_to_front()
            self._inspect_poll_count = 0
            self.root.after(300, self._poll_inspect_result, 'play_list')
        except Exception as e:
            self.logger.error(f"[点选] 启动失败: {e}")
            self._play_list_pick_btn.config(state=tk.NORMAL, text="🎯 点选")
            self._play_list_cancel_pick_btn.config(state=tk.DISABLED)
            self._restore_window()

    def _cancel_play_list_pick(self):
        """取消播放列表选择器点选"""
        self.logger.info("[点选] 用户取消播放列表点选")
        self.browser.cancel_inspect()
        self._finish_inspect({'cancelled': True}, 'play_list')

    def _play_list_click_play(self):
        """点击播放：模拟鼠标点击播放器窗口，触发 xgplayer 等懒加载播放器"""
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return

        selector = self._play_list_selector_var.get().strip()
        self.logger.info(f"[点击播放] 尝试点击播放器，选择器: {selector or '(自动)'}")

        # 在后台线程执行 Playwright 操作，避免阻塞 GUI 主线程
        def _do_click():
            try:
                if selector:
                    el = self.call_on_main_thread(
                        lambda: self.browser.page.query_selector(self.browser.parse_selector(selector)[0])
                    )
                    if el:
                        self.call_on_main_thread(lambda: el.click())
                        self.logger.info(f"[点击播放] 已点击选择器元素: {selector}")
                    else:
                        self.logger.warning(f"[点击播放] 选择器未找到元素: {selector}，尝试 xgplayer 自动点击")
                        self.call_on_main_thread(lambda: self.browser.trigger_xgplayer())
                else:
                    triggered = self.call_on_main_thread(lambda: self.browser.trigger_xgplayer())
                    if triggered:
                        self.logger.info("[点击播放] xgplayer 触发成功")
                    else:
                        self.logger.info("[点击播放] 尝试点击页面中央播放器区域...")
                        viewport = self.call_on_main_thread(lambda: self.browser.page.viewport_size)
                        if viewport:
                            cx = viewport['width'] // 2
                            cy = viewport['height'] // 3
                            self.call_on_main_thread(lambda: self.browser.page.mouse.click(cx, cy))
                            self.logger.info(f"[点击播放] 已点击页面坐标 ({cx}, {cy})")
                        else:
                            xg_el = self.call_on_main_thread(
                                lambda: self.browser.page.query_selector('.xgplayer, video, #player, .player')
                            )
                            if xg_el:
                                self.call_on_main_thread(lambda: xg_el.click())
                                self.logger.info("[点击播放] 已点击播放器容器")
                            else:
                                self.logger.warning("[点击播放] 未找到可点击的播放器元素")

            except Exception as e:
                self.logger.error(f"[点击播放] 点击播放失败: {e}")
                import traceback
                self.logger.error(traceback.format_exc())

        threading.Thread(target=_do_click, daemon=True).start()

    def _on_play_list_pick_done(self, result):
        """播放列表选择器点选完成回调"""
        # list 模式下使用独立的按钮引用
        if self._play_list_pick_start_btn:
            self._play_list_pick_start_btn.config(state=tk.NORMAL, text="🎯 点选")
        else:
            self._play_list_pick_btn.config(state=tk.NORMAL, text="🎯 点选")
        if self._play_list_pick_cancel_btn:
            self._play_list_pick_cancel_btn.config(state=tk.DISABLED)
        else:
            self._play_list_cancel_pick_btn.config(state=tk.DISABLED)

        self._play_list_pick_mode = False

        if not result or result.get('cancelled'):
            self.logger.info("[点选] 已取消")
            return

        # 生成候选选择器列表
        candidates = BrowserManager.generate_selectors_from_info(result)

        if candidates:
            selector_str = candidates[0][0]
            # list 模式下设置到目标 var
            if self._play_list_pick_target:
                self._play_list_pick_target.set(selector_str)
            else:
                self._play_list_selector_var.set(selector_str)
            self.logger.info(f"[点选] 播放列表选择器: {selector_str} ({candidates[0][2]})")
        else:
            self.logger.warning("[点选] 未能生成有效选择器")

    def _play_list_scan_selector(self):
        """扫描当前页面的媒体元素，填充到选择器输入框
        
        特别注意 xgplayer 西瓜播放器是懒加载的，需要先触发播放按钮才会创建 video 元素。
        """
        if not self.browser.page:
            self.logger.warning("[扫描选择器] 浏览器未启动")
            return

        try:
            # 首先尝试触发 xgplayer（如果存在）
            triggered = self.browser.trigger_xgplayer()
            
            # 获取当前标签页的媒体元素
            candidates = self.browser.scan_media_elements()

            if candidates:
                # 默认选用第一个最佳选择器
                best = candidates[0]
                self._play_list_selector_var.set(best[0])
                self.logger.info(f"[扫描选择器] 已扫描到: {best[0]} ({best[2]})")
                
                # 如果只有一个 xgplayer 选择器但没有 video 元素，提示用户
                if len(candidates) == 1 and '.xgplayer' in candidates[0][0] and 'xgplayer' in candidates[0][1]:
                    self.logger.warning("[扫描选择器] 仅返回 xgplayer 容器选择器，video 元素可能未创建")
            else:
                self._play_list_selector_var.set('')
                self.logger.warning("[扫描选择器] 未发现媒体元素")
                
                # 最后尝试直接返回 xgplayer 选择器
                xgplayer_check = self.browser.page.evaluate("""
                    () => {
                        const xg = document.querySelector('.xgplayer');
                        if (xg) {
                            return {found: true, id: xg.id || '', class: 'xgplayer'};
                        }
                        return {found: false};
                    }
                """)
                if xgplayer_check.get('found'):
                    selector = '#' + xgplayer_check['id'] if xgplayer_check['id'] else '.xgplayer'
                    self._play_list_selector_var.set(selector)
                    self.logger.info(f"[扫描选择器] 返回 xgplayer 选择器: {selector}")
                    
        except Exception as e:
            self.logger.error(f"[扫描选择器] 扫描失败: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            self._play_list_selector_var.set('')

    def _on_media_end_tab_selected(self, event=None):
        """媒体完成后目标标签页下拉选择变更"""
        sel = self._media_end_tab_combo.current()
        if sel < 0 or not hasattr(self, '_media_end_tab_data') or sel >= len(self._media_end_tab_data):
            self._on_end_tab_var.set('-1')
            return
        tab_info = self._media_end_tab_data[sel]
        self._on_end_tab_var.set(str(tab_info['index']))

    def _on_popup_type_changed(self, event=None):
        """弹窗类型变更：更新操作下拉选项 + 切换专属设置区可见性"""
        popup_type = self.popup_vars['popup_type'].get()

        # 根据类型调整可用操作
        action_map = {
            'alert':   ['close', 'accept'],
            'confirm': ['close', 'accept', 'dismiss'],
            'prompt':  ['close', 'accept', 'dismiss', 'input'],
            'custom':  ['close', 'click', 'input', 'select_option'],
            'radio':   ['click', 'select_option'],
            'quiz':    ['auto_answer'],
            'layer':   ['click', 'close'],
        }
        default_action = {
            'alert': 'accept', 'confirm': 'accept', 'prompt': 'accept',
            'custom': 'close', 'radio': 'click', 'quiz': 'auto_answer',
            'layer': 'click',
        }
        available = action_map.get(popup_type, ['close'])
        self._popup_action_combo['values'] = available

        current_action = self.popup_vars['popup_action'].get()
        if current_action not in available:
            self.popup_vars['popup_action'].set(default_action.get(popup_type, 'close'))

        self._update_popup_sections_visibility()

    def _on_popup_action_changed(self, event=None):
        """操作变更时更新可见性（影响输入文本区域）"""
        self._update_popup_sections_visibility()

    def _update_popup_sections_visibility(self):
        """根据当前弹窗类型和操作，显示/隐藏对应的专属设置区域"""
        popup_type = self.popup_vars['popup_type'].get()
        action = self.popup_vars['popup_action'].get()

        # 先隐藏所有条件区域
        self._popup_selector_frame.pack_forget()
        self._quiz_settings_frame.pack_forget()
        self._radio_settings_frame.pack_forget()
        self._custom_input_frame.pack_forget()

        # 按顺序 pack 可见区域，用 after 参数保证顺序
        last_frame = self._popup_common_frame

        # 选择器：custom / radio / quiz / layer 需要
        if popup_type in ('custom', 'radio', 'quiz', 'layer'):
            self._popup_selector_frame.pack(fill=tk.X, padx=3, pady=(0, 5), after=last_frame)
            last_frame = self._popup_selector_frame

        # Quiz 专属
        if popup_type == 'quiz':
            self._quiz_settings_frame.pack(fill=tk.X, padx=3, pady=(0, 5), after=last_frame)
            last_frame = self._quiz_settings_frame

        # Radio 专属
        if popup_type == 'radio':
            self._radio_settings_frame.pack(fill=tk.X, padx=3, pady=(0, 5), after=last_frame)
            last_frame = self._radio_settings_frame

        # 输入文本：prompt 或 custom + input
        need_input = (popup_type == 'prompt') or (popup_type == 'custom' and action == 'input')
        if need_input:
            self._custom_input_frame.pack(fill=tk.X, padx=3, pady=(0, 5), after=last_frame)

    def _on_popup_select(self, event=None):
        sel = self.popup_listbox.curselection()
        if not sel:
            return
        self._current_popup_idx = sel[0]
        rule = self._popup_data[self._current_popup_idx]
        self.popup_vars['popup_keyword'].set(rule.get('keyword', ''))
        self.popup_vars['popup_type'].set(rule.get('type', 'alert'))
        self.popup_vars['popup_action'].set(rule.get('action', 'close'))
        self.popup_vars['popup_tab_index'].set(str(rule.get('tab_index', -1)))
        self.popup_vars['popup_selector'].set(rule.get('selector', ''))
        self.popup_vars['popup_correct_answer'].set(rule.get('correct_answer', ''))
        self.popup_vars['popup_option_value'].set(rule.get('option_value', ''))
        self.popup_vars['popup_max_retries'].set(str(rule.get('max_retries', 5)))
        self.popup_vars['popup_input_text'].set(rule.get('input_text', ''))
        # 刷新标签页下拉列表并恢复选中项
        self._refresh_popup_tab_list()
        # 根据类型切换专属设置区域可见性 + 操作下拉选项
        self._on_popup_type_changed()

    def _sync_popup_edit_to_data(self):
        """将编辑区内容同步到 _popup_data，使用 _current_popup_idx"""
        if self._current_popup_idx < 0 or self._current_popup_idx >= len(self._popup_data):
            return False
        try:
            tab_index = int(self.popup_vars['popup_tab_index'].get() or '-1')
        except (ValueError, TypeError):
            tab_index = -1
        try:
            max_retries = int(self.popup_vars['popup_max_retries'].get() or '5')
        except (ValueError, TypeError):
            max_retries = 5
        self._popup_data[self._current_popup_idx] = {
            'keyword': self.popup_vars['popup_keyword'].get().strip(),
            'type': self.popup_vars['popup_type'].get(),
            'action': self.popup_vars['popup_action'].get(),
            'tab_index': tab_index,
            'selector': self.popup_vars['popup_selector'].get().strip(),
            'correct_answer': self.popup_vars['popup_correct_answer'].get().strip(),
            'option_value': self.popup_vars['popup_option_value'].get().strip(),
            'max_retries': max_retries,
            'input_text': self.popup_vars['popup_input_text'].get().strip(),
        }
        return True

    def _on_popup_pick_done(self, result):
        """弹窗规则点选完成"""
        self._popup_pick_btn.config(state=tk.NORMAL, text="🎯 点选")
        self._cancel_pick_btn.config(state=tk.DISABLED)
        if not result or result.get('cancelled'):
            self.logger.info("[点选] 已取消")
            return
        candidates = BrowserManager.generate_selectors_from_info(result)
        if candidates:
            self.popup_vars['popup_selector'].set(candidates[0][0])
            text = result.get('text', '').strip()
            if text and not self.popup_vars['popup_keyword'].get().strip():
                self.popup_vars['popup_keyword'].set(text[:30])
            self.logger.info(f"[点选] 弹窗选择器: {candidates[0][0]}")

    def _on_media_end_pick_done(self, result):
        """媒体播放完成后目标元素点选完成"""
        self._media_end_pick_btn.config(state=tk.NORMAL, text="🎯 点选")
        if not result or result.get('cancelled'):
            self.logger.info("[点选] 已取消")
            return
        candidates = BrowserManager.generate_selectors_from_info(result)
        if candidates:
            self._on_end_target_var.set(candidates[0][0])
            self.logger.info(f"[点选] 媒体结束后目标选择器: {candidates[0][0]} ({candidates[0][2]})")

    def _add_popup(self):
        self._popup_data.append({
            'keyword': '', 'type': 'alert', 'action': 'close', 'tab_index': -1,
            'selector': '', 'correct_answer': '',
            'option_value': '', 'max_retries': 5, 'input_text': ''
        })
        self._refresh_popup_list()
        idx = len(self._popup_data) - 1
        self._current_popup_idx = idx
        self.popup_listbox.selection_set(idx)
        self._on_popup_select()

    def _update_popup(self):
        if not self._sync_popup_edit_to_data():
            self.logger.warning("更新失败：未选中弹窗规则")
            return
        idx = self._current_popup_idx
        self._refresh_popup_list()
        if 0 <= idx < len(self._popup_data):
            self.popup_listbox.selection_set(idx)
            self.popup_listbox.see(idx)
        # 自动保存
        self.config_loader.set_popup_rules(self._popup_data)
        try:
            self.config_loader.save()
            self.logger.info("弹窗规则已更新并保存")
        except Exception as e:
            self.logger.error(f"弹窗规则更新后保存失败: {e}")

    def _delete_popup(self):
        if self._current_popup_idx < 0 or self._current_popup_idx >= len(self._popup_data):
            return
        del self._popup_data[self._current_popup_idx]
        self._current_popup_idx = -1
        self._refresh_popup_list()

    # ================================================================
    #  弹窗规则测试
    # ================================================================
    def _test_popup_rule(self):
        """测试当前选中的全局弹窗规则"""
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return
        if self._current_popup_idx < 0 or self._current_popup_idx >= len(self._popup_data):
            messagebox.showinfo("提示", "请先选中一条弹窗规则")
            return

        rule = self._popup_data[self._current_popup_idx]
        self.logger.info(f"[弹窗测试] 测试全局规则 #{self._current_popup_idx + 1}: [{rule.get('type', '')}] {rule.get('keyword', '')[:30]}")

        # 设置 pw_caller 以确保线程安全
        self.popup_handler.set_pw_caller(self.call_on_main_thread)

        result = self.popup_handler.test_rule(rule)
        self._show_popup_test_result(result, "全局弹窗规则")

    def _test_step_popup_rule(self):
        """测试当前选中的步骤弹窗规则"""
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return
        if self._current_step_popup_idx < 0 or \
           self._current_step_popup_idx >= len(self._current_step_popup_rules):
            messagebox.showinfo("提示", "请先选中一条步骤弹窗规则")
            return

        rule = self._current_step_popup_rules[self._current_step_popup_idx]
        self.logger.info(f"[弹窗测试] 测试步骤规则 #{self._current_step_popup_idx + 1}: [{rule.get('type', '')}] {rule.get('keyword', '')[:30]}")

        # 设置 pw_caller 以确保线程安全
        self.popup_handler.set_pw_caller(self.call_on_main_thread)

        result = self.popup_handler.test_rule(rule)
        self._show_popup_test_result(result, "步骤弹窗规则")

    def _show_popup_test_result(self, result, source="弹窗规则"):
        """显示弹窗规则测试结果"""
        lines = [f"===== {source}测试结果 ====="]

        matched = result.get('matched', False)
        success = result.get('success', False)
        action_taken = result.get('action_taken', '')
        details = result.get('details', '')
        error = result.get('error', '')

        # 匹配状态
        if matched:
            lines.append(f"✅ 匹配成功: {details}")
        else:
            lines.append(f"❌ 未匹配: {details}")

        # 操作结果
        if action_taken:
            if success:
                lines.append(f"✅ 操作结果: {action_taken}")
            else:
                lines.append(f"⚠️ 操作结果: {action_taken}")

        # 错误信息
        if error:
            lines.append(f"❌ 错误: {error}")

        # 汇总
        if matched and success:
            lines.append("🎉 测试通过！规则有效且操作成功执行")
        elif matched and not action_taken:
            lines.append("ℹ️ 规则匹配但未执行操作（仅检测模式）")
        elif not matched:
            lines.append("💡 提示: 当前页面未出现目标弹窗，请确认弹窗触发条件")
        elif error:
            lines.append("⚠️ 测试发现错误，请检查选择器和配置")

        self.logger.info("\n".join(lines))

        # 弹窗显示测试结果
        msg = "\n".join(lines[1:])  # 跳过标题行
        if success:
            messagebox.showinfo("弹窗规则测试", msg)
        else:
            messagebox.showwarning("弹窗规则测试", msg)

    # ================================================================
    #  运行控制
    # ================================================================
    def _set_state(self, state):
        """state: idle | running | paused | stopped | waiting_manual_end"""
        if state == "idle":
            self.start_btn.config(state=tk.NORMAL)
            self.pause_btn.config(state=tk.DISABLED, text="⏸ 暂停")
            self.stop_btn.config(state=tk.DISABLED)
            self.step_next_btn.config(state=tk.DISABLED)
            self.finish_last_btn.config(state=tk.DISABLED)
            self.status_label.config(text="状态: 等待启动", foreground="blue")
        elif state == "running":
            self.start_btn.config(state=tk.DISABLED)
            self.pause_btn.config(state=tk.NORMAL, text="⏸ 暂停")
            self.stop_btn.config(state=tk.NORMAL)
            self.finish_last_btn.config(state=tk.DISABLED)
            self.status_label.config(text="状态: 运行中", foreground="green")
        elif state == "paused":
            self.pause_btn.config(text="▶ 恢复")
            self.status_label.config(text="状态: 已暂停", foreground="orange")
        elif state == "waiting_manual_end":
            self.start_btn.config(state=tk.DISABLED)
            self.pause_btn.config(state=tk.DISABLED, text="⏸ 暂停")
            self.stop_btn.config(state=tk.NORMAL)
            self.finish_last_btn.config(state=tk.NORMAL)
            self.status_label.config(text="状态: 等待手动结束最后步骤", foreground="purple")
        elif state == "stopped":
            self.start_btn.config(state=tk.NORMAL)
            self.pause_btn.config(state=tk.DISABLED, text="⏸ 暂停")
            self.stop_btn.config(state=tk.DISABLED)
            self.step_next_btn.config(state=tk.DISABLED)
            self.finish_last_btn.config(state=tk.DISABLED)
            # 最终同步：确保播放列表完成状态已保存到配置文件并刷新 GUI
            self._sync_play_list_completed_from_runner()
            if self.keep_listen_var.get():
                self.status_label.config(text="状态: 已停止 (弹窗监听中)", foreground="purple")
            else:
                self.status_label.config(text="状态: 已停止", foreground="red")

    def _toggle_step_mode(self):
        if self.step_mode_var.get():
            self.step_next_btn.config(state=tk.NORMAL)
            self.logger.info("[单步调试] 已启用，每步需手动点击「下一步」")
        else:
            self.step_next_btn.config(state=tk.DISABLED)
            self.logger.info("[单步调试] 已关闭")

    def _toggle_keep_listen(self):
        if self.keep_listen_var.get():
            self.logger.info("[弹窗监听] 流程结束后将保持弹窗监听（方便测试弹窗）")
        else:
            self.logger.info("[弹窗监听] 流程结束后将停止弹窗监听")

    def _on_start_click(self):
        # 重新从文件加载配置（确保获取最新状态，如已完成的播放列表项）
        self._reload_config()
        # 先同步最新配置
        self._apply_all_config()

        # 检查运行自动化所需的必要配置项
        missing = self.config_loader.validate_for_run()
        if missing:
            self._show_setup_guide(missing)
            return

        self._set_state("running")
        if self.step_mode_var.get():
            self.task_runner.step_mode = True
            self.step_next_btn.config(state=tk.NORMAL)
        else:
            self.task_runner.step_mode = False
        # 启动最后步骤手动结束检测
        self._poll_manual_end()
        if self.on_start:
            # on_start 在主线程中执行（Playwright sync API 要求线程绑定）
            # on_start 内部会将 run_navigation 放到后台线程
            self.on_start()

    def _show_setup_guide(self, missing_items):
        """显示设置指引弹窗，指导用户完成必要配置。

        Args:
            missing_items: list[str], 未配置的必要项名称列表
        """
        # 配置项名称与中文描述的映射
        ITEM_LABELS = {
            'navigation': '自动化步骤',
            'login_url': '登录网址',
        }

        # 每个配置项的操作指引
        ITEM_GUIDES = {
            'navigation': (
                '1. 切换到「步骤配置」选项卡\n'
                '2. 点击「+ 添加步骤」创建至少一个步骤\n'
                '3. 常用步骤类型：\n'
                '   - click: 点击页面元素（如登录按钮）\n'
                '   - play_list: 按列表播放视频\n'
                '   - play_wait: 播放并等待结束'
            ),
            'login_url': (
                '1. 切换到「浏览器 & 网站」选项卡\n'
                '2. 在「登录网址」栏填入网站首页地址\n'
                '   例如: https://www.example.com/\n'
                '3. 勾选「使用登录状态免登录」可自动恢复登录\n'
                '4. 点击「保存浏览器 & 网站配置」'
            ),
        }

        # 构建提示消息
        missing_labels = [ITEM_LABELS.get(m, m) for m in missing_items]
        header = f"开始自动化前，需要完成以下配置：\n\n"
        items_text = ""
        for i, m in enumerate(missing_items, 1):
            label = ITEM_LABELS.get(m, m)
            items_text += f"  {i}. {label}\n"
        items_text += "\n"

        guides_text = ""
        for m in missing_items:
            guide = ITEM_GUIDES.get(m, f'请在配置面板中设置「{ITEM_LABELS.get(m, m)}」')
            guides_text += f"【{ITEM_LABELS.get(m, m)}】\n{guide}\n\n"

        full_msg = header + items_text + "操作指引：\n\n" + guides_text

        self.logger.warning(f"缺少必要配置: {', '.join(missing_labels)}，请先完成配置")
        messagebox.showwarning("配置不完整", full_msg)

    def _poll_manual_end(self):
        """定时检测 task_runner 是否进入等待手动结束状态，更新 GUI"""
        if self.task_runner.waiting_manual_end:
            self._set_state("waiting_manual_end")
            return  # 进入等待状态后停止轮询，用户点击按钮后由 _on_finish_last_step 处理
        if self.task_runner.running:
            # 任务还在运行，继续轮询
            self.root.after(500, self._poll_manual_end)

    # ================================================================
    #  浏览器关闭监控
    # ================================================================
    def start_browser_close_monitor(self):
        """启动浏览器关闭监控：定时检测浏览器是否被用户手动关闭。
        如果检测到浏览器已关闭，自动停止自动化流程。
        """
        self._browser_close_monitor_active = True
        self._poll_browser_alive()

    def stop_browser_close_monitor(self):
        """停止浏览器关闭监控"""
        self._browser_close_monitor_active = False

    def _poll_browser_alive(self):
        """轮询检测浏览器是否存活，如果被关闭则启动多次确认流程。
        同时检查后台线程发来的浏览器死亡信号。
        """
        if not self._browser_close_monitor_active:
            return

        # 检查后台线程是否发来了浏览器死亡信号
        with self.task_runner._browser_died_lock:
            browser_died = self.task_runner._browser_died
            if browser_died:
                self.task_runner._browser_died = False  # 重置，恢复后重新检测

        if browser_died:
            self.logger.warning("[浏览器监控] 收到后台线程的浏览器死亡信号，启动确认流程...")
            self._start_browser_death_confirm()
            return

        # 主动检测逻辑：无论任务是否运行，都要检测浏览器状态
        try:
            alive = self.browser.is_alive()
        except Exception:
            alive = False

        if not alive and self.browser._ever_started:
            self._browser_recovery_attempt = 0
            self._start_browser_death_confirm()
            return

        self.root.after(2000, self._poll_browser_alive)

    def _start_browser_death_confirm(self):
        """启动浏览器死亡多次确认流程。

        多次确认策略：
        1. 第一次检测到死亡，等待 3 秒后再次检查（避免误判）
        2. 第二次检查仍然死亡，执行停止清理
        3. 停止清理完成后，弹出确认框询问是否重新启动
        4. 用户确认后，重新启动自动化任务
        """
        self._confirm_count = 0
        self._max_confirm_count = 3  # 最多确认 3 次
        self.logger.warning("[浏览器监控] 检测到浏览器可能已关闭，启动多次确认流程...")
        self._do_browser_death_confirm()

    def _do_browser_death_confirm(self):
        """执行一次浏览器死亡确认检查。"""
        self._confirm_count += 1

        # 多次确认：连续多次检测到浏览器关闭才认定是真的关闭
        try:
            alive = self.browser.is_alive()
        except Exception:
            alive = False

        if alive:
            # 浏览器又活了（可能只是短暂卡死），取消恢复
            self.logger.info("[浏览器监控] 浏览器已恢复（多次确认未通过），取消恢复流程")
            self.root.after(2000, self._poll_browser_alive)
            return

        if self._confirm_count < self._max_confirm_count:
            self.logger.warning(
                f"[浏览器监控] 第 {self._confirm_count}/{self._max_confirm_count} 次确认：浏览器已关闭，"
                f"{3}秒后再次检查...")
            # 延迟后再次检查
            self.root.after(3000, self._do_browser_death_confirm)
            return

        # 多次确认通过：浏览器确实已关闭
        self.logger.warning(
            f"[浏览器监控] {self._max_confirm_count}次确认通过：浏览器确实已关闭，开始停止清理...")
        self._browser_stop_and_restart()

    def _browser_stop_and_restart(self):
        """确认浏览器已关闭后，执行停止清理，然后直接重新启动（不需要用户确认）。"""
        self.logger.info("[浏览器恢复] 正在停止当前任务并清理状态...")

        # 0. 紧急保存进度（浏览器已死，会使用缓存数据回退）
        if hasattr(self, 'browser') and hasattr(self.browser, 'progress_saver') and self.browser.progress_saver:
            self.browser.progress_saver.save_now()
            self.browser.progress_saver.stop()

        # 1. 执行停止命令清理状态
        self.task_runner.stop()
        self.popup_handler.stop_listening()
        self.stop_browser_close_monitor()

        # 标记浏览器已关闭
        self.browser._closed = True
        self.browser._auto_close = False

        # 2. 直接重新启动（不需要用户确认）
        self.logger.info("[浏览器恢复] 正在重新启动自动化...")
        self._restart_automation()

    def _restart_automation(self):
        """重新启动自动化任务（模拟点击「开始」按钮的逻辑）。"""
        try:
            # 重新加载配置
            self._reload_config()
            self._apply_all_config()
            self._set_state("running")

            # 启动浏览器关闭监控
            self.start_browser_close_monitor()

            # 调用 on_start 回调（会处理浏览器启动）
            if self.on_start:
                self.on_start()
            else:
                self.logger.error("[浏览器恢复] on_start 回调未设置，无法重新启动")
                self._set_state("stopped")
        except Exception as e:
            self.logger.error(f"[浏览器恢复] 重新启动失败: {e}")
            self._set_state("stopped")

    def _on_pause_click(self):
        if self.pause_btn.cget("text") == "⏸ 暂停":
            if self.on_pause:
                self.on_pause()
            self._set_state("paused")
        else:
            if self.on_resume:
                self.on_resume()
            self._set_state("running")

    def _on_stop_click(self):
        if self.on_stop:
            self.on_stop()
        self._set_state("stopped")
        # 停止时刷新停留统计
        self._refresh_stay_data()

    def _on_step_next(self):
        self.task_runner.step_next()

    def _on_finish_last_step(self):
        """手动结束最后一步"""
        self.task_runner.finish_last_step()
        self.finish_last_btn.config(state=tk.DISABLED)
        self.logger.info("[手动结束] 用户确认完成最后步骤")

    def _reload_config(self):
        """从配置文件重新加载最新数据到 _nav_data 和 _popup_data。

        每次点击「开始自动化」时调用，确保：
        1. 首次启动：加载配置文件中的初始状态
        2. 重启场景：获取上一次运行保存的完成状态（completed 字段）
        3. 外部修改：如果用户在编辑器中修改了配置文件，此处获取最新内容

        注意：仅重载导航和弹窗数据，不覆盖 UI 中用户正在编辑但未保存的浏览器设置。
        """
        try:
            self.config_loader.load()
        except Exception as e:
            self.logger.error(f"重新加载配置文件失败: {e}")
            return

        cfg = self.config_loader.config
        new_nav = copy.deepcopy(cfg.get('navigation', []))
        new_popup = copy.deepcopy(cfg.get('popup_rules', []))

        # 统计播放列表完成状态变化
        completed_count = 0
        total_play_list_items = 0
        for nav_item in new_nav:
            if nav_item.get('action') == 'play_list':
                for item in nav_item.get('play_list', []):
                    total_play_list_items += 1
                    if item.get('completed', False):
                        completed_count += 1

        self._nav_data = new_nav
        self._popup_data = new_popup

        # 更新设置变量（浏览器类型、超时等可能也被修改）
        s = cfg.get('settings', {})
        self.browser_type_var.set(s.get('browser_type', 'chrome'))
        self.window_max_var.set(s.get('window_max', True))
        self.timeout_var.set(str(s.get('global_timeout', 60000)))
        self.loop_run_var.set(s.get('loop_run', False))
        self.retry_var.set(str(s.get('retry_count', 2)))
        w = cfg.get('website', {})
        self.login_url_var.set(w.get('login_url', ''))
        self.wait_after_login_var.set(str(w.get('wait_after_login', 5)))
        scan_interval = s.get('popup_scan_interval', 0.5)
        self.popup_scan_interval_var.set(str(scan_interval))

        # 刷新播放列表 UI（同步完成状态到 treeview）
        self._refresh_play_list_completed_status()

        if total_play_list_items > 0:
            self.logger.info(
                f"[配置重载] 播放列表状态: {completed_count}/{total_play_list_items} 项已完成")
        self.logger.info("[配置重载] 已从文件重新加载最新配置")

    def _apply_all_config(self):
        """将 UI 当前值同步到 config_loader / task_runner / popup_handler"""
        site = self._collect_site_config()
        if site:
            self.config_loader.set_settings(site['settings'])
            self.config_loader.set_website(site['website'])
        self.config_loader.set_navigation(self._nav_data)
        self.config_loader.set_popup_rules(self._popup_data)

        # 更新运行时对象（深拷贝，避免 GUI 修改影响运行中的任务）
        self.task_runner.navigation_list = copy.deepcopy(self._nav_data)
        self.task_runner.settings = self.config_loader.get_settings()
        # 更新全局弹窗规则（同时更新 _global_popup_rules 以确保步骤级切换时引用正确）
        self.popup_handler.popup_rules = self._popup_data
        self.popup_handler._global_popup_rules = self._popup_data

        # 同步弹窗扫描间隔
        try:
            interval = float(self.popup_scan_interval_var.get() or '0.5')
        except (ValueError, TypeError):
            interval = 0.5
        self.popup_handler.custom_popup_check_interval = interval

    # ================================================================
    #  测试 & 单步执行
    # ================================================================
    def _get_selected_step_index(self):
        if self._current_step_idx < 0 or self._current_step_idx >= len(self._nav_data):
            messagebox.showinfo("提示", "请先在步骤列表中选择一个步骤")
            return None
        return self._current_step_idx

    # ================================================================
    #  页面元素点选
    # ================================================================
    def _start_pick_element(self):
        """启动页面元素点选模式（主线程执行 Playwright 调用，避免 greenlet 线程冲突）
        如果步骤指定了目标标签页，先切换到该标签页再进行点选。
        """
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return

        # 获取目标标签页
        tab_index = self._get_target_tab_index()
        target_page = self._switch_to_target_tab(tab_index)
        if target_page is None:
            messagebox.showwarning("提示", f"标签页 {tab_index} 不存在或已关闭，请刷新标签页列表")
            return

        # 保存点选前的活动页面，以便点选完成后恢复
        self._page_before_pick = self.browser.page
        # 切换到目标页面
        if tab_index >= 0:
            self.browser.page = target_page
            self.browser.page.bring_to_front()
            self.logger.info(f"[点选] 已切换到标签页 {tab_index}")

        self.logger.info("[点选] 启动页面元素点选模式，请在浏览器中点击目标元素...")
        self._pick_btn.config(state=tk.DISABLED, text="点选中...")
        self._cancel_pick_btn.config(state=tk.NORMAL)

        try:
            # 在主线程注入 JS（Playwright 要求同线程）
            self.browser.page.evaluate(BrowserManager._INJECT_JS)
            # 保存窗口状态并最小化主窗口
            self._save_and_iconify()
            # 将浏览器窗口提到前台并获得焦点
            self.browser.bring_to_front()
            self._inspect_poll_count = 0
            self.root.after(300, self._poll_inspect_result, 'step')
        except Exception as e:
            self.logger.error(f"[点选] 启动失败: {e}")
            self._pick_btn.config(state=tk.NORMAL, text="🎯 点选")
            self._restore_window()

    def _start_media_end_pick(self):
        """媒体播放完成后目标元素点选（主线程执行），支持目标标签页切换"""
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return

        # 获取媒体完成后目标标签页
        try:
            tab_index = int(self._on_end_tab_var.get() or '-1')
        except (ValueError, TypeError):
            tab_index = -1

        target_page = self._switch_to_target_tab(tab_index)
        if target_page is None:
            messagebox.showwarning("提示", f"标签页 {tab_index} 不存在或已关闭，请刷新标签页列表")
            return

        self.logger.info("[点选] 启动媒体结束后目标元素点选...")

        # 保存点选前的活动页面
        self._page_before_pick = self.browser.page

        # 切换到目标标签页
        if tab_index >= 0:
            self.browser.page = target_page
            self.browser.page.bring_to_front()
            self.logger.info(f"[媒体结束点选] 已切换到标签页 {tab_index}")

        self._media_end_pick_btn.config(state=tk.DISABLED, text="点选中...")

        try:
            self.browser.page.evaluate(BrowserManager._INJECT_JS)
            self._save_and_iconify()
            self.browser.bring_to_front()
            self._inspect_poll_count = 0
            self.root.after(300, self._poll_inspect_result, 'media_end')
        except Exception as e:
            self.logger.error(f"[点选] 启动失败: {e}")
            self._media_end_pick_btn.config(state=tk.NORMAL, text="🎯 点选")
            self._restore_window()

    def _start_popup_pick(self):
        """弹窗规则选择器点选（主线程执行），支持目标标签页切换"""
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return

        # 获取弹窗规则的目标标签页
        try:
            tab_index = int(self.popup_vars['popup_tab_index'].get() or '-1')
        except (ValueError, TypeError):
            tab_index = -1

        target_page = self._switch_to_target_tab(tab_index)
        if target_page is None:
            messagebox.showwarning("提示", f"标签页 {tab_index} 不存在或已关闭，请刷新标签页列表")
            return

        # 保存点选前的活动页面
        self._page_before_pick = self.browser.page
        if tab_index >= 0:
            self.browser.page = target_page
            self.browser.page.bring_to_front()
            self.logger.info(f"[弹窗点选] 已切换到标签页 {tab_index}")

        self.logger.info("[点选] 启动弹窗元素点选...")
        self._popup_pick_btn.config(state=tk.DISABLED, text="点选中...")

        try:
            self.browser.page.evaluate(BrowserManager._INJECT_JS)
            self._save_and_iconify()
            self.browser.bring_to_front()
            self._inspect_poll_count = 0
            self.root.after(300, self._poll_inspect_result, 'popup')
        except Exception as e:
            self.logger.error(f"[点选] 启动失败: {e}")
            self._popup_pick_btn.config(state=tk.NORMAL, text="🎯 点选")
            self._restore_window()

    def _poll_inspect_result(self, mode='step'):
        """轮询点选结果（在主线程通过 root.after 调用，避免线程冲突）"""
        max_polls = 200  # 200 * 300ms = 60s 超时
        self._inspect_poll_count += 1

        if self._inspect_poll_count > max_polls:
            self.logger.info("[点选] 超时，自动取消")
            self.browser.cancel_inspect()
            self._finish_inspect(None, mode)
            return

        try:
            result = self.browser.page.evaluate("window.__pw_inspector_result")
            if result is not None:
                # 清理
                self.browser.page.evaluate(
                    "window.__pw_inspector_result = null; "
                    "window.__pw_inspector_active = false;"
                )
                self._finish_inspect(result, mode)
                return
        except Exception as e:
            self.logger.debug(f"[点选] 轮询异常: {e}")

        # 继续轮询
        self.root.after(300, self._poll_inspect_result, mode)

    # ================================================================
    #  播放列表完成状态同步
    # ================================================================
    def _sync_play_list_completed_from_runner(self):
        """将 task_runner.navigation_list 中的播放列表 completed/audio_file/audio_name 状态同步回 _nav_data，
        保存配置文件，并刷新 GUI 显示。
        此方法由 task_runner 通过 _pw_call 在主线程中调度执行。
        """
        changed = False
        runner_nav_list = self.task_runner.navigation_list
        for i, runner_nav in enumerate(runner_nav_list):
            if i < len(self._nav_data) and runner_nav.get('action') == 'play_list':
                src_list = runner_nav.get('play_list', [])
                dst_list = self._nav_data[i].get('play_list', [])
                for j, src_item in enumerate(src_list):
                    if j < len(dst_list):
                        # 同步 completed
                        if src_item.get('completed') and not dst_list[j].get('completed'):
                            dst_list[j]['completed'] = True
                            changed = True
                        # 同步 audio_file
                        if src_item.get('audio_file') and dst_list[j].get('audio_file') != src_item['audio_file']:
                            dst_list[j]['audio_file'] = src_item['audio_file']
                            changed = True
                        # 同步 audio_name
                        if src_item.get('audio_name') and dst_list[j].get('audio_name') != src_item['audio_name']:
                            dst_list[j]['audio_name'] = src_item['audio_name']
                            changed = True

        if changed:
            # 保存到配置文件
            self.config_loader.set_navigation(self._nav_data)
            try:
                self.config_loader.save()
                self.logger.info("[播放完成] 已同步完成状态并保存配置")
            except Exception as e:
                self.logger.error(f"[播放完成] 保存配置失败: {e}")
            # 刷新 GUI 显示
            self._refresh_play_list_completed_status()

    def _refresh_play_list_completed_status(self):
        """刷新 GUI 中播放列表的完成状态（支持 all 模式和 list 模式的 treeview）"""
        # all 模式：刷新步骤编辑器中的播放列表表格
        if self.mode == 'all' and hasattr(self, '_play_list_tree') and self._play_list_tree:
            self._refresh_all_mode_play_list_tree()

        # list 模式：刷新简约模式下的播放列表表格
        if hasattr(self, '_simple_play_list_vars') and self._simple_play_list_vars:
            self._refresh_list_mode_play_list_trees()

    def _refresh_all_mode_play_list_tree(self):
        """刷新 all 模式下播放列表编辑器的完成状态列"""
        if not hasattr(self, '_play_list_tree') or not self._play_list_tree:
            return
        # 仅当当前编辑的步骤是 play_list 时才刷新
        if self._current_step_idx < 0 or self._current_step_idx >= len(self._nav_data):
            return
        current_nav = self._nav_data[self._current_step_idx]
        if current_nav.get('action') != 'play_list':
            return
        # 从 _nav_data 重新加载播放列表数据到表格
        play_list_data = current_nav.get('play_list', [])
        self._play_list_load_data(play_list_data)

    def _refresh_list_mode_play_list_trees(self):
        """刷新 list 模式下各播放列表标签页的完成状态和录音文件列"""
        for step_key, vars_data in self._simple_play_list_vars.items():
            tree = vars_data.get('tree')
            play_list_data = vars_data.get('play_list_data')
            if not tree or not play_list_data:
                continue
            children = tree.get_children()
            for i, item_data in enumerate(play_list_data):
                if i < len(children):
                    vals = list(tree.item(children[i])['values'])
                    vals[4] = '✓' if item_data.get('completed', False) else '□'
                    vals[5] = item_data.get('audio_file', '') or ''
                    tree.item(children[i], values=vals)

    # ================================================================
    #  Playwright 线程安全桥接
    # ================================================================
    def _schedule_pw_calls(self):
        """主线程调度器：处理来自后台线程的 Playwright 调用请求"""
        try:
            while True:
                try:
                    fn, done_event, result_box = self._pw_queue.get_nowait()
                    try:
                        result_box['value'] = fn()
                        result_box['error'] = None
                    except Exception as e:
                        result_box['value'] = None
                        result_box['error'] = e
                    finally:
                        done_event.set()
                except queue.Empty:
                    break
        except Exception:
            pass
        # 每 50ms 检查一次
        self.root.after(50, self._schedule_pw_calls)

    def call_on_main_thread(self, fn, timeout=60):
        """从任意线程调用 fn（在主线程执行），返回结果。
        Playwright sync API 要求所有 page 操作在同一线程执行，
        后台线程通过此方法将 Playwright 调用调度到主线程。
        """
        if threading.current_thread() is threading.main_thread():
            return fn()

        done_event = threading.Event()
        result_box = {'value': None, 'error': None}
        self._pw_queue.put((fn, done_event, result_box))

        if not done_event.wait(timeout=timeout):
            raise TimeoutError(f"Playwright 调用超时 ({timeout}s)")

        if result_box['error'] is not None:
            raise result_box['error']
        return result_box['value']

    def _infer_action_from_element(self, tag, result):
        """根据元素标签和属性推断最佳操作类型"""
        tag = tag.upper()
        elem_type = (result.get('type', '') or '').lower()
        href = result.get('href', '')
        onclick = result.get('onclick', '')

        # VIDEO / AUDIO 媒体元素
        if tag in ('VIDEO', 'AUDIO'):
            return 'play_wait'

        # INPUT 根据子类型区分
        if tag == 'INPUT':
            if elem_type in ('checkbox', 'radio'):
                return 'check'
            elif elem_type in ('text', 'search', 'email', 'password', 'tel', 'url', 'number'):
                return 'input'
            elif elem_type == 'submit':
                return 'click'

        # SELECT
        if tag == 'SELECT':
            return 'select'

        # A 标签（链接）
        if tag == 'A':
            return 'click'

        # BUTTON
        if tag == 'BUTTON':
            return 'click'

        # TEXTAREA
        if tag == 'TEXTAREA':
            return 'input'

        # 有 onclick 的元素
        if onclick:
            return 'click'

        # 默认
        return 'click'

    def _cancel_current_pick(self):
        """从 GUI 取消点选模式"""
        self.logger.info("[点选] 用户取消点选")
        self.browser.cancel_inspect()
        self._finish_inspect({'cancelled': True}, 'step')

    def _save_and_iconify(self):
        """保存窗口状态并最小化"""
        try:
            self._window_was_maximized = (self.root.state() == 'zoomed')
            self.root.iconify()
        except Exception:
            self._window_was_maximized = False

    def _restore_window(self):
        """恢复窗口到最小化前的状态"""
        try:
            self.root.deiconify()
            if getattr(self, '_window_was_maximized', False):
                self.root.state('zoomed')
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass

    def _finish_inspect(self, result, mode='step'):
        """点选完成统一处理：恢复窗口 + 恢复标签页 + 调用对应回调"""
        # 恢复主窗口（保持原始大小）
        self._restore_window()

        # 如果点选前切换了标签页，恢复到原来的标签页
        if hasattr(self, '_page_before_pick') and self._page_before_pick is not None:
            try:
                self.browser.page = self._page_before_pick
                self._page_before_pick = None
            except Exception:
                pass

        if mode == 'step':
            self._on_pick_done(result)
        elif mode == 'media_end':
            self._on_media_end_pick_done(result)
        elif mode == 'play_list':
            self._on_play_list_pick_done(result)
        else:
            self._on_popup_pick_done(result)

    def _on_pick_done(self, result):
        """步骤点选完成回调"""
        self._pick_btn.config(state=tk.NORMAL, text="🎯 点选")
        self._cancel_pick_btn.config(state=tk.DISABLED)

        if not result or result.get('cancelled'):
            self.logger.info("[点选] 已取消")
            return

        # 自动填充步骤信息
        tag = result.get('tag', '')
        text = result.get('text', '').strip()
        interactive = result.get('interactive', False)

        # 自动推断操作类型
        action_key = self._infer_action_from_element(tag, result)
        action_def = self.ACTION_DEFS.get(action_key, {})
        action_label = action_def.get('label', action_key)
        self.step_vars['step_action'].set(f"{action_key} - {action_label}")
        self._on_action_changed()

        # 自动设置名称
        if text and not self.step_vars['step_name'].get().strip():
            name = text[:20] if len(text) > 20 else text
            self.step_vars['step_name'].set(name)

        # 生成候选选择器列表
        candidates = BrowserManager.generate_selectors_from_info(result)

        self._selector_candidates.delete(0, tk.END)
        self._candidate_data = candidates  # 存储 [(selector, type, desc), ...]

        if candidates:
            # 默认选用第一个（最优）
            best = candidates[0]
            self.step_vars['step_selector'].set(best[0])
            self.logger.info(f"[点选] 已选用: {best[0]} ({best[2]})")

            for sel, sel_type, desc in candidates:
                self._selector_candidates.insert(tk.END, f"{sel}  [{desc}]")

            # 测试第一个选择器
            test_result = self.browser.test_selector(candidates[0][0])
            count = test_result.get('count', 0)
            best_tag = test_result.get('best_tag', '?')
            self.logger.info(
                f"[点选] 选择器验证: 匹配{count}个元素, 推荐 <{best_tag}>")
        else:
            self.logger.warning("[点选] 未能生成有效选择器")

    def _on_candidate_double_click(self, event=None):
        """双击候选选择器选用"""
        sel = self._selector_candidates.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx < len(self._candidate_data):
            chosen = self._candidate_data[idx][0]
            self.step_vars['step_selector'].set(chosen)
            self.logger.info(f"[点选] 已切换选择器: {chosen}")

            # 即时验证
            test_result = self.browser.test_selector(chosen)
            count = test_result.get('count', 0)
            best_tag = test_result.get('best_tag', '?')
            used = test_result.get('used_selector', chosen)
            fallback = test_result.get('fallback_tried', [])
            msg = f"验证: 匹配{count}个, 推荐<{best_tag}>"
            if used != chosen:
                msg += f" (回退至: {used})"
            self.logger.info(f"[点选] {msg}")

    def _test_current_step(self):
        idx = self._get_selected_step_index()
        if idx is None:
            return
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return

        # 同步编辑内容到 _nav_data
        self._sync_step_edit_to_data()
        self._refresh_step_list()
        self.step_listbox.selection_set(idx)

        # 确保 task_runner 使用最新数据
        self.task_runner.navigation_list = self._nav_data

        self.logger.info(f"===== 测试步骤 {idx + 1} =====")
        debug_info = self.task_runner.test_step(idx)
        self._show_debug_info(debug_info)

    def _run_current_step(self):
        idx = self._get_selected_step_index()
        if idx is None:
            return
        if not self.browser.page:
            messagebox.showwarning("提示", "请先启动浏览器")
            return

        self._sync_step_edit_to_data()
        self._refresh_step_list()
        self.step_listbox.selection_set(idx)

        # 确保 task_runner 使用最新数据（深拷贝防并发修改）
        self.task_runner.navigation_list = copy.deepcopy(self._nav_data)

        self.logger.info(f"===== 执行步骤 {idx + 1} =====")

        def do_run():
            success, debug_info = self.task_runner.run_step(idx)
            self.root.after(0, self._show_debug_info, debug_info)

        threading.Thread(target=do_run, daemon=True).start()

    def _show_debug_info(self, info):
        """在调试区域显示调试信息"""
        self.debug_text.config(state=tk.NORMAL)
        self.debug_text.delete("1.0", tk.END)

        lines = []
        if 'error' in info and info.get('result') is None:
            lines.append(f"❌ 错误: {info['error']}")
        else:
            lines.append(f"步骤: {info.get('name', '?')}")
            lines.append(f"操作: {info.get('action', '?')}")
            if info.get('url'):
                lines.append(f"URL: {info['url']}")
            if info.get('selector'):
                lines.append(f"选择器: {info['selector']}")

            # 页面信息
            pb = info.get('page_before') or info.get('page_info')
            if pb:
                lines.append(f"页面: {pb.get('title', '?')} — {pb.get('url', '?')}")

            # 选择器测试
            st = info.get('selector_test')
            if st:
                best_idx = st.get('best_index', -1)
                best_tag = st.get('best_tag', '')
                lines.append(f"选择器匹配: {st.get('count', 0)} 个元素")
                if best_idx >= 0:
                    lines.append(f"推荐点击: [{best_idx}] <{best_tag}>")
                used_sel = st.get('used_selector', '')
                if used_sel and used_sel != info.get('selector', ''):
                    lines.append(f"实际使用选择器: {used_sel} (回退)")
                fallback_tried = st.get('fallback_tried', [])
                if fallback_tried:
                    lines.append(f"已尝试回退: {', '.join(fallback_tried)}")
                for el in st.get('elements', []):
                    vis = "可见" if el.get('visible') else "不可见"
                    interactive = "可交互" if el.get('interactive') else "普通"
                    skip = " [跳过]" if el.get('skip') else ""
                    best = " <<推荐>>" if el['index'] == best_idx else ""
                    lines.append(
                        f"  [{el['index']}] <{el['tag']}> {vis} {interactive}{skip}{best}"
                        f" text={el.get('text', '')[:60]}"
                    )
                if not st.get('success'):
                    lines.append(f"  选择器错误: {st.get('error', '')}")

            # 结果
            result = info.get('result', '')
            if result == 'success':
                lines.append("✅ 执行成功")
            elif result == 'fail':
                lines.append(f"❌ 执行失败: {info.get('error', '')}")
            elif result == 'skip':
                lines.append(f"⏭ 跳过: {info.get('error', '')}")
            elif result == 'error':
                lines.append(f"💥 异常: {info.get('error', '')}")

            pa = info.get('page_after')
            if pa:
                lines.append(f"执行后页面: {pa.get('title', '?')} — {pa.get('url', '?')}")

            for w in info.get('warnings', []):
                lines.append(f"⚠ {w}")

        self.debug_text.insert(tk.END, "\n".join(lines))
        self.debug_text.config(state=tk.DISABLED)

    # ================================================================
    #  日志 & 页面信息
    # ================================================================
    def _redirect_log(self):
        original_info = self.logger.info
        original_error = self.logger.error
        original_warning = self.logger.warning

        def log_gui(level, message):
            try:
                self.root.after(0, self._append_log, f"[{level}] {message}")
            except Exception:
                pass

        def info_gui(message):
            original_info(message)
            log_gui("INFO", message)

        def error_gui(message):
            original_error(message)
            log_gui("ERROR", message)

        def warning_gui(message):
            original_warning(message)
            log_gui("WARN", message)

        self.logger.info = info_gui
        self.logger.error = error_gui
        self.logger.warning = warning_gui

    def _append_log(self, message):
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)

    def _update_page_info(self):
        if self.browser.page:
            info = self.browser.get_page_info()
            self.page_info_label.config(text=f"📄 {info.get('title', '')} — {info.get('url', '')}")

    # ================================================================
    #  外部接口
    # ================================================================
    def set_on_start(self, fn):
        self.on_start = fn

    def set_on_pause(self, fn):
        self.on_pause = fn

    def set_on_resume(self, fn):
        self.on_resume = fn

    def set_on_stop(self, fn):
        self.on_stop = fn

    def notify_step_done(self, debug_info):
        """供 task_runner 在单步模式下通知 GUI"""
        self.root.after(0, self._show_debug_info, debug_info)
        self.root.after(0, self._update_page_info)
        # 自动刷新停留统计
        self.root.after(0, self._refresh_stay_data)

    def show(self):
        self._update_page_info()
        self.root.mainloop()

    def close(self):
        self.root.destroy()
