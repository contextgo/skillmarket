# -*- coding: utf-8 -*-
"""
音频转文字模块 - 基于 Whisper 实现音频转录
"""
import os
import subprocess
import logging
import json
import uuid
import tempfile
from pathlib import Path
from datetime import datetime, timedelta


class AudioTranscriber:
    """音频转文字转换器，使用 Whisper"""

    def __init__(self, config=None):
        self.logger = logging.getLogger(__name__)
        self.config = config or {}

        # 创建临时目录
        self._temp_dir = tempfile.mkdtemp(prefix='webvideo_transcribe_')

        # Whisper 模型配置
        self._whisper_model = 'base'  # tiny/base/small/medium/large
        self._whisper_language = 'zh'  # 中文

        # 检查 ffmpeg
        self._has_ffmpeg = self._check_ffmpeg()

    def _check_ffmpeg(self):
        """检查 ffmpeg 是否可用"""
        try:
            subprocess.run(['ffmpeg', '-version'],
                         capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            # 尝试常见路径
            common_paths = [
                r'C:\ffmpeg\bin\ffmpeg.exe',
                r'C:\Program Files\ffmpeg\bin\ffmpeg.exe',
            ]
            for path in common_paths:
                if os.path.exists(path):
                    return True
            return False

    def _extract_audio(self, video_path, output_format='mp3', bitrate='128k'):
        """从视频提取音频

        Args:
            video_path: 视频文件路径
            output_format: 输出音频格式
            bitrate: 音频比特率

        Returns:
            str: 提取的音频文件路径
        """
        if not os.path.exists(video_path):
            self.logger.error(f"[转录] 视频文件不存在: {video_path}")
            return None

        # 生成输出路径
        audio_path = os.path.join(
            self._temp_dir,
            f'audio_{uuid.uuid4().hex[:8]}.{output_format}'
        )

        cmd = [
            'ffmpeg', '-y',
            '-i', video_path,
            '-vn',           # 不处理视频
            '-acodec', 'libmp3lame' if output_format == 'mp3' else 'pcm_s16le',
            '-ab', bitrate,
            '-ar', '16000',   # Whisper 建议 16kHz
            '-ac', '1',       # 单声道
            audio_path
        ]

        try:
            self.logger.info(f"[转录] 正在提取音频...")
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300
            )

            if result.returncode != 0:
                self.logger.error(f"[转录] 音频提取失败: {result.stderr[:500]}")
                return None

            if os.path.exists(audio_path):
                self.logger.info(f"[转录] 音频提取成功: {audio_path}")
                return audio_path

        except subprocess.TimeoutExpired:
            self.logger.error("[转录] 音频提取超时")
        except Exception as e:
            self.logger.error(f"[转录] 音频提取异常: {e}")

        return None

    def _format_timestamp(self, seconds):
        """格式化时间戳为 HH:MM:SS 格式"""
        td = timedelta(seconds=float(seconds))
        hours, remainder = divmod(td.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"

    def transcribe_video(self, video_path, model_size='base', language='zh',
                        word_timestamps=True, include_segment_times=True):
        """转录音视频文件

        Args:
            video_path: 视频文件路径
            model_size: Whisper 模型大小 (tiny/base/small/medium/large)
            language: 目标语言代码 (zh/en/ja/ko 等)
            word_timestamps: 是否包含单词级时间戳
            include_segment_times: 是否包含段落级时间戳

        Returns:
            dict: 转录结果，包含文本、时间戳等信息
        """
        if not os.path.exists(video_path):
            self.logger.error(f"[转录] 视频文件不存在: {video_path}")
            return None

        if not self._has_ffmpeg:
            self.logger.error("[转录] 未安装 ffmpeg，无法进行转录")
            self.logger.info("[转录] 安装方法: https://ffmpeg.org/download.html")
            return None

        # 提取音频
        audio_path = self._extract_audio(video_path)
        if not audio_path:
            return None

        # 检查 Whisper 是否可用
        try:
            import whisper
        except ImportError:
            self.logger.error("[转录] 未安装 whisper，请运行: pip install openai-whisper")
            return None

        try:
            self.logger.info(f"[转录] 加载 Whisper {model_size} 模型...")
            model = whisper.load_model(model_size)

            self.logger.info(f"[转录] 开始转录 (语言: {language})...")
            result = model.transcribe(
                audio_path,
                language=language,
                word_timestamps=word_timestamps,
                verbose=False
            )

            # 整理转录结果
            transcription = {
                'text': result['text'].strip(),
                'language': result.get('language', language),
                'duration': result.get('duration', 0),
                'segments': [],
                'words': []
            }

            # 提取段落信息
            if 'segments' in result:
                for seg in result['segments']:
                    segment_info = {
                        'id': seg.get('id'),
                        'start': seg.get('start', 0),
                        'end': seg.get('end', 0),
                        'start_time': self._format_timestamp(seg.get('start', 0)),
                        'end_time': self._format_timestamp(seg.get('end', 0)),
                        'text': seg.get('text', '').strip()
                    }
                    transcription['segments'].append(segment_info)

                    # 提取单词信息
                    if 'words' in seg and word_timestamps:
                        for word in seg['words']:
                            transcription['words'].append({
                                'word': word.get('word', ''),
                                'start': word.get('start', 0),
                                'end': word.get('end', 0),
                                'start_time': self._format_timestamp(word.get('start', 0)),
                                'end_time': self._format_timestamp(word.get('end', 0)),
                                'probability': word.get('probability', 0)
                            })

            # 清理临时文件
            try:
                os.remove(audio_path)
            except Exception:
                pass

            self.logger.info(
                f"[转录] 转录完成! 时长: {transcription['duration']:.1f}秒, "
                f"字数: {len(transcription['text'])}"
            )

            return transcription

        except Exception as e:
            self.logger.error(f"[转录] 转录失败: {e}")
            return None

    def transcribe_with_api(self, audio_path, api_config):
        """使用 API 进行转录（支持 Whisper API/SiliconFlow 等）

        Args:
            audio_path: 音频文件路径
            api_config: API 配置

        Returns:
            dict: 转录结果
        """
        try:
            import openai
        except ImportError:
            self.logger.error("[转录] 请安装 openai: pip install openai")
            return None

        client = openai.OpenAI(
            api_key=api_config.get('api_key'),
            base_url=api_config.get('api_base', 'https://api.openai.com/v1')
        )

        try:
            with open(audio_path, 'rb') as audio_file:
                transcript = client.audio.transcriptions.create(
                    model=api_config.get('model', 'whisper-1'),
                    file=audio_file,
                    response_format='verbose_json',
                    timestamp_granularities=['word']
                )

            # 整理结果
            result = {
                'text': transcript.text,
                'language': 'zh',
                'words': []
            }

            if hasattr(transcript, 'words') and transcript.words:
                for word in transcript.words:
                    result['words'].append({
                        'word': word.word,
                        'start': word.start,
                        'end': word.end,
                        'start_time': self._format_timestamp(word.start),
                        'end_time': self._format_timestamp(word.end)
                    })

            return result

        except Exception as e:
            self.logger.error(f"[转录] API 转录失败: {e}")
            return None

    def transcribe(self, video_path, use_api=False, api_config=None):
        """通用转录接口

        Args:
            video_path: 视频文件路径
            use_api: 是否使用 API
            api_config: API 配置

        Returns:
            dict: 转录结果
        """
        if use_api and api_config:
            # 提取音频
            audio_path = self._extract_audio(video_path)
            if audio_path:
                result = self.transcribe_with_api(audio_path, api_config)
                try:
                    os.remove(audio_path)
                except Exception:
                    pass
                return result

        # 使用本地 Whisper
        return self.transcribe_video(video_path)

    def save_transcription(self, transcription, output_path):
        """保存转录结果到文件"""
        if not transcription:
            return False

        try:
            # 保存为 JSON
            json_path = output_path.replace('.json', '') + '.json'
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(transcription, f, ensure_ascii=False, indent=2)

            # 保存为纯文本
            txt_path = output_path.replace('.txt', '') + '.txt'
            with open(txt_path, 'w', encoding='utf-8') as f:
                f.write(transcription.get('text', ''))

            self.logger.info(f"[转录] 已保存到 {json_path}")
            return True

        except Exception as e:
            self.logger.error(f"[转录] 保存失败: {e}")
            return False

    def cleanup(self):
        """清理临时文件"""
        try:
            import shutil
            if os.path.exists(self._temp_dir):
                shutil.rmtree(self._temp_dir)
                self.logger.debug(f"[转录] 已清理临时目录: {self._temp_dir}")
        except Exception as e:
            self.logger.warning(f"[转录] 清理临时文件失败: {e}")
