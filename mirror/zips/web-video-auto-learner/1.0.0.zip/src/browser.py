from playwright.sync_api import sync_playwright
import os
import re
import json
import time
import sys
import subprocess
import tempfile
import threading

# Windows 注册表操作（仅 Windows 可用）
try:
    import winreg
except ImportError:
    winreg = None


class BrowserManager:
    def __init__(self, logger):
        self.logger = logger
        self.playwright = None
        self.browser = None
        self.context = None
        self.page = None
        self._inspect_active = False
        self._inspect_result = None
        self._closed = False
        # 浏览器实例状态标记
        self._ever_started = False    # 是否曾经成功启动过浏览器
        self._auto_close = False      # 本次启动是否由自动化流程管理（用于区分手动/自动关闭）

        # 页面停留时间统计
        self._stay_records = []          # 已完成的停留记录列表
        self._current_stay = None        # 当前正在进行的停留记录
        self._stay_lock = False          # 防止重复 start/end

        # 媒体进度守护器（由 main.py 注入）
        self.progress_saver = None

    @staticmethod
    def get_exe_dir():
        """获取可执行文件所在目录（支持打包后的 exe 和开发环境）"""
        if getattr(sys, 'frozen', False):
            # 打包后的 exe
            return os.path.dirname(sys.executable)
        else:
            # 开发环境
            return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # 可交互标签
    INTERACTIVE_TAGS = {'A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'SUMMARY', 'OPTION'}
    # 不可交互标签
    SKIP_TAGS = {'SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'META', 'LINK', 'HEAD'}

    # Chromium 内核浏览器类型集合（均通过 chromium launcher 启动）
    CHROMIUM_BASED = {'chrome', 'msedge', '360ee', '360se'}

    # 360浏览器不兼容的 Playwright 默认启动参数
    # 360浏览器基于Chromium但做了深度定制，部分参数会导致进程崩溃或闪退：
    #   --no-startup-window    : 360不支持无窗口启动，进程会立即退出
    #   --edge-skip-compat-layer-relaunch : Edge专用参数，360不识别可能触发异常退出
    #   --enable-automation    : 360检测到此标记会弹出安全提示或直接拒绝启动
    #   --disable-extensions   : 360核心扩展被禁用后浏览器无法正常运行
    #   --disable-component-extensions-with-background-pages : 同上，影响360内置组件
    #   --disable-component-update : 360安全组件更新机制被禁用可能导致异常
    #   --disable-search-engine-choice-screen : 某些360版本不支持此参数
    #   --unsafely-disable-devtools-self-xss-warnings : 某些360版本不支持
    #   --password-store=basic : 360有自带的密码管理器，此参数可能导致冲突
    #   --use-mock-keychain    : 360不支持macOS keychain概念，此参数无意义
    #   --allow-pre-commit-input : 360不支持此管道输入模式
    #   --export-tagged-pdf    : 某些360版本不支持
    #   --no-service-autorun   : 360安全服务与此参数冲突
    #   --enable-unsafe-swiftshader : 360的GPU策略与标准Chromium不同
    _360_INCOMPATIBLE_ARGS = {
        '--no-startup-window',
        '--edge-skip-compat-layer-relaunch',
        '--enable-automation',
        '--disable-extensions',
        '--disable-component-extensions-with-background-pages',
        '--disable-component-update',
        '--enable-unsafe-swiftshader',
        '--allow-pre-commit-input',
        '--export-tagged-pdf',
        '--no-service-autorun',
        '--use-mock-keychain',
        '--password-store=basic',
        '--unsafely-disable-devtools-self-xss-warnings',
        '--disable-search-engine-choice-screen',
    }

    # ================================================================
    #  浏览器路径自动检测
    # ================================================================
    @staticmethod
    def _find_in_registry(reg_paths):
        """从 Windows 注册表中查找浏览器路径。
        reg_paths: [(hive, subkey, value_name), ...] 列表，按优先级尝试。
        value_name="" 表示读取默认值。
        返回找到的值（字符串）或 None。
        """
        if winreg is None:
            return None
        for hive, subkey, value_name in reg_paths:
            try:
                key = winreg.OpenKey(hive, subkey, 0, winreg.KEY_READ)
                val, _ = winreg.QueryValueEx(key, value_name)
                winreg.CloseKey(key)
                if val:
                    return val
            except (OSError, FileNotFoundError):
                continue
        return None

    @staticmethod
    def _find_exe_in_uninstall(hive, display_name_pattern, exe_name):
        """从注册表卸载信息中查找浏览器安装目录，然后在其中查找可执行文件。
        遍历 Uninstall 下的所有子键，匹配 DisplayName 包含指定关键词的条目，
        读取 InstallLocation / DisplayIcon 来定位可执行文件。
        返回可执行文件完整路径或 None。
        """
        if winreg is None:
            return None
        base_keys = [
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
            r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
        ]
        for base in base_keys:
            try:
                key = winreg.OpenKey(hive, base, 0, winreg.KEY_READ)
            except OSError:
                continue
            try:
                idx = 0
                while True:
                    try:
                        subkey_name = winreg.EnumKey(key, idx)
                        idx += 1
                        try:
                            subkey = winreg.OpenKey(key, subkey_name, 0, winreg.KEY_READ)
                        except OSError:
                            continue
                        try:
                            display_name, _ = winreg.QueryValueEx(subkey, "DisplayName")
                        except OSError:
                            winreg.CloseKey(subkey)
                            continue
                        if not display_name or display_name_pattern.lower() not in display_name.lower():
                            winreg.CloseKey(subkey)
                            continue
                        # 匹配到了，尝试获取路径
                        # 优先从 DisplayIcon 提取（通常包含完整 exe 路径）
                        try:
                            icon_path, _ = winreg.QueryValueEx(subkey, "DisplayIcon")
                            if icon_path and os.path.isfile(icon_path) and icon_path.lower().endswith('.exe'):
                                winreg.CloseKey(subkey)
                                return icon_path
                        except OSError:
                            pass
                        # 其次从 InstallLocation 拼接
                        try:
                            install_loc, _ = winreg.QueryValueEx(subkey, "InstallLocation")
                            if install_loc:
                                exe_path = os.path.join(install_loc, exe_name)
                                if os.path.isfile(exe_path):
                                    winreg.CloseKey(subkey)
                                    return exe_path
                                # 尝试 Application 子目录
                                exe_path2 = os.path.join(install_loc, 'Application', exe_name)
                                if os.path.isfile(exe_path2):
                                    winreg.CloseKey(subkey)
                                    return exe_path2
                        except OSError:
                            pass
                        winreg.CloseKey(subkey)
                    except OSError:
                        break
            finally:
                winreg.CloseKey(key)
        return None

    @staticmethod
    def _find_in_common_paths(paths):
        """从常见安装路径列表中查找浏览器可执行文件。
        paths: [path, ...] 列表，按优先级尝试，支持 %USERPROFILE% 等环境变量。
        返回找到的路径或 None。
        """
        for p in paths:
            expanded = os.path.expandvars(os.path.expanduser(p))
            if os.path.isfile(expanded):
                return expanded
        return None

    @classmethod
    def find_browser_path(cls, browser_type):
        """自动检测浏览器可执行文件路径。
        返回 (path, source) 或 (None, None)。
        source: 'registry' | 'common_path' | 'playwright_channel'
        """
        # ---- 1. 本地打包的浏览器（最高优先级） ----
        exe_dir = cls.get_exe_dir()
        local_chrome = os.path.join(exe_dir, "chrome-win64", "chrome-win64", "chrome.exe")
        if os.path.exists(local_chrome) and browser_type in ('chrome',):
            return local_chrome, 'local'

        # ---- 2. 按浏览器类型查找 ----
        if browser_type == 'chrome':
            # 注册表
            path = cls._find_in_registry([
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe", ""),
                (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe", ""),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Google Chrome", "InstallLocation"),
            ])
            if path:
                full = path if path.endswith('chrome.exe') else os.path.join(path, 'chrome.exe')
                if os.path.isfile(full):
                    return full, 'registry'
            # 常见路径
            path = cls._find_in_common_paths([
                r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe",
                r"%PROGRAMFILES(X86)%\Google\Chrome\Application\chrome.exe",
                r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe",
            ])
            if path:
                return path, 'common_path'
            # 回退：使用 Playwright channel 方式
            return None, 'playwright_channel'

        elif browser_type == 'msedge':
            # 注册表
            path = cls._find_in_registry([
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe", ""),
                (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe", ""),
            ])
            if path:
                full = path if path.endswith('msedge.exe') else os.path.join(path, 'msedge.exe')
                if os.path.isfile(full):
                    return full, 'registry'
            # 常见路径
            path = cls._find_in_common_paths([
                r"%PROGRAMFILES(X86)%\Microsoft\Edge\Application\msedge.exe",
                r"%PROGRAMFILES%\Microsoft\Edge\Application\msedge.exe",
            ])
            if path:
                return path, 'common_path'
            # 回退：使用 Playwright channel 方式
            return None, 'playwright_channel'

        elif browser_type == '360ee':
            # 360极速浏览器（支持新版 X 和旧版）
            # 新版: 360ChromeX.exe，安装目录 360ChromeX
            # 旧版: 360chrome.exe，安装目录 360Chrome
            # 1) 注册表 App Paths
            path = cls._find_in_registry([
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\360ChromeX.exe", ""),
                (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\360ChromeX.exe", ""),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\360chrome.exe", ""),
                (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\360chrome.exe", ""),
            ])
            if path and os.path.isfile(path):
                return path, 'registry'
            # 2) 注册表 Uninstall 遍历（最可靠，匹配 DisplayName）
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                for keyword, exe in [('极速', '360ChromeX.exe'), ('极速', '360chrome.exe')]:
                    path = cls._find_exe_in_uninstall(hive, keyword, exe)
                    if path:
                        return path, 'registry'
            # 3) 常见路径
            path = cls._find_in_common_paths([
                # 新版 X
                r"%LOCALAPPDATA%\360ChromeX\Chrome\Application\360ChromeX.exe",
                r"%USERPROFILE%\AppData\Local\360ChromeX\Chrome\Application\360ChromeX.exe",
                # 旧版
                r"%USERPROFILE%\AppData\Roaming\360Chrome\Chrome\Application\360chrome.exe",
                r"%LOCALAPPDATA%\360Chrome\Chrome\Application\360chrome.exe",
                r"%PROGRAMFILES(X86)%\360Chrome\Chrome\Application\360chrome.exe",
                r"%PROGRAMFILES%\360Chrome\Chrome\Application\360chrome.exe",
            ])
            if path:
                return path, 'common_path'
            return None, None

        elif browser_type == '360se':
            # 360安全浏览器
            # 1) 注册表 App Paths
            path = cls._find_in_registry([
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\360se.exe", ""),
                (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\360se.exe", ""),
            ])
            if path and os.path.isfile(path):
                return path, 'registry'
            # 2) 注册表 Uninstall 遍历
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                path = cls._find_exe_in_uninstall(hive, '360安全浏览器', '360se.exe')
                if path:
                    return path, 'registry'
            # 3) 常见路径
            path = cls._find_in_common_paths([
                r"%USERPROFILE%\AppData\Roaming\360se6\Application\360se.exe",
                r"%LOCALAPPDATA%\360se6\Application\360se.exe",
                r"%PROGRAMFILES(X86)%\360\360se6\Application\360se.exe",
                r"%PROGRAMFILES%\360\360se6\Application\360se.exe",
            ])
            if path:
                return path, 'common_path'
            return None, None

        return None, None

    @classmethod
    def get_supported_browsers(cls):
        """返回支持的浏览器类型列表及其显示名称。"""
        return [
            ('chrome',  'Google Chrome'),
            ('msedge',  'Microsoft Edge'),
            ('360ee',   '360极速浏览器'),
            ('360se',   '360安全浏览器'),
            ('firefox', 'Firefox'),
            ('webkit',  'WebKit'),
        ]

    # ================================================================
    #  浏览器启动
    # ================================================================
    @staticmethod
    def _reset_asyncio():
        """重置 asyncio 事件循环状态，避免与 Playwright Sync API 冲突。

        Playwright Sync API 在启动时会检查 asyncio._get_running_loop()。
        需要清除所有可能导致该检查失败的状态。
        """
        import asyncio
        import sys

        # --- 诊断：记录当前 asyncio 状态 ---
        import logging
        _logger = logging.getLogger(__name__)
        _thread = threading.current_thread().name
        try:
            _loop = asyncio.get_event_loop()
            _is_closed = _loop.is_closed()
            _is_running = False
            try:
                _is_running = _loop.is_running()
            except Exception:
                pass
            _logger.debug(f"[_reset_asyncio] thread={_thread}, loop={_loop}, "
                  f"closed={_is_closed}, running={_is_running}")
        except Exception as _e:
            _logger.debug(f"[_reset_asyncio] thread={_thread}, get_event_loop error: {_e}")

        # 1. 关闭当前 loop（如果已存在且未关闭）
        try:
            old_loop = asyncio.get_event_loop()
            if not old_loop.is_closed():
                try:
                    # 取消所有待处理任务
                    for task in asyncio.all_tasks(old_loop):
                        task.cancel()
                except Exception:
                    pass
                try:
                    old_loop.close()
                except Exception:
                    pass
        except Exception:
            pass

        # 2. 创建并设置一个全新的 event loop（处于"未运行"状态）
        new_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(new_loop)

        # 3. 清除 asyncio 内部记录的"当前运行循环"状态（Python 3.7+）
        try:
            asyncio._set_running_loop(None)
        except AttributeError:
            pass

        # 4. 清除当前任务（Python 3.7+）
        try:
            asyncio._set_current_task(None)
        except AttributeError:
            pass

        # --- 诊断：记录清理后的 asyncio 状态 ---
        import logging
        _logger = logging.getLogger(__name__)
        try:
            _loop2 = asyncio.get_event_loop()
            _logger.debug(f"[_reset_asyncio] after reset: loop={_loop2}, "
                  f"closed={_loop2.is_closed()}, "
                  f"running={_loop2.is_running() if not _loop2.is_closed() else 'N/A'}")
        except Exception as _e:
            _logger.debug(f"[_reset_asyncio] after reset error: {_e}")

    def start_browser(self, browser_type="chrome", window_max=True, browser_path=None, storage_state_file=None, headless=False):
        """启动浏览器，内置 asyncio 冲突处理和重试逻辑。

        Args:
            storage_state_file: 已保存的 storage state 文件路径。
                                     如果文件存在，则使用它创建 context（实现免登录）。
        """
        import asyncio as _asyncio
        # 解决 greenlet 线程冲突问题
        self._reset_asyncio()
        _thread_name = threading.current_thread().name
        self.logger.info(f"[start_browser] 进入方法，线程={_thread_name}, attempt循环即将开始")

        for attempt in range(3):
            self.logger.info(f"[start_browser] 第 {attempt+1}/3 次尝试...")
            try:
                self._reset_asyncio()

                # 诊断：打印 reset 后的 asyncio 状态
                _loop = _asyncio.get_event_loop()
                self.logger.info(
                    f"[start_browser] reset后: loop={_loop}, "
                    f"closed={_loop.is_closed()}, "
                    f"running={_loop.is_running() if not _loop.is_closed() else 'N/A'}")
                try:
                    _rl = _asyncio._get_running_loop()
                    self.logger.info(f"[start_browser] _get_running_loop={_rl}")
                except Exception as _e:
                    self.logger.info(f"[start_browser] _get_running_loop error: {_e}")

                self.logger.info("[start_browser] 即将调用 sync_playwright().start()...")
                self.playwright = sync_playwright().start()
                self.logger.info("[start_browser] sync_playwright().start() 成功！")

                # 以下为浏览器启动后的配置
                if browser_path and os.path.isfile(browser_path):
                    self.logger.info(f"使用手动指定的浏览器路径: {browser_path}")
                else:
                    browser_path, source = self.find_browser_path(browser_type)

                if browser_type in self.CHROMIUM_BASED:
                    launcher = self.playwright.chromium
                elif browser_type == "firefox":
                    launcher = self.playwright.firefox
                elif browser_type == "webkit":
                    launcher = self.playwright.webkit
                else:
                    launcher = self.playwright.chromium

                launch_args = {
                    "headless": headless,
                    "args": ["--start-maximized"] if window_max else []
                }

                if browser_type == "msedge":
                    if browser_path:
                        launch_args["executable_path"] = browser_path
                        self.logger.info(f"使用系统 Edge: {browser_path} (来源: {source})")
                    else:
                        launch_args["channel"] = "msedge"
                        self.logger.info("使用 Playwright channel 启动 Edge")

                elif browser_type in ('360ee', '360se'):
                    if not browser_path:
                        raise FileNotFoundError(
                            f"未找到{'360极速浏览器' if browser_type == '360ee' else '360安全浏览器'}，"
                            f"请确认已安装。可尝试将浏览器安装路径下的可执行文件"
                            f"所在目录添加到系统 PATH，或在 config.yaml 中指定 browser_path。")
                    launch_args["executable_path"] = browser_path
                    name = '360极速浏览器' if browser_type == '360ee' else '360安全浏览器'
                    self.logger.info(f"使用系统 {name}: {browser_path} (来源: {source})")
                    launch_args["chromium_sandbox"] = False
                    launch_args["ignore_default_args"] = list(self._360_INCOMPATIBLE_ARGS)

                elif browser_type == "chrome":
                    if browser_path:
                        if source == 'local':
                            launch_args["executable_path"] = browser_path
                            self.logger.info(f"使用本地打包浏览器: {browser_path}")
                        elif source in ('registry', 'common_path'):
                            launch_args["executable_path"] = browser_path
                            self.logger.info(f"使用系统 Chrome: {browser_path} (来源: {source})")
                        else:
                            self.logger.info("使用 Playwright 内置 Chromium")
                    else:
                        self.logger.info("使用 Playwright 内置 Chromium")

                else:
                    self.logger.info(f"使用 Playwright 内置 {browser_type}")

                self.browser = launcher.launch(**launch_args)

                if browser_type in ('360ee', '360se'):
                    self._close_360_default_pages()

                # 创建 context：支持 storage_state（免登录）
                context_options = {}
                if window_max:
                    context_options["no_viewport"] = True
                else:
                    context_options["viewport"] = {"width": 1920, "height": 1080}

                # storage_state 支持两种方式：
                # 1. .enc 文件 → 解密得到字典，传给 storage_state=
                # 2. .json 文件 → Playwright 原生支持直接传文件路径字符串
                if storage_state_file and os.path.isfile(storage_state_file):
                    if storage_state_file.endswith('.enc'):
                        # 加密文件：先解密得到字典
                        decrypted_state = self.load_storage_state(storage_state_file)
                        if decrypted_state:
                            context_options["storage_state"] = decrypted_state
                            self.logger.info(f"[start_browser] 使用已保存的登录信息(解密): {storage_state_file}")
                        else:
                            self.logger.warning(f"[start_browser] 解密登录信息失败，将使用空 context")
                    else:
                        # 明文 json 文件：Playwright 原生支持直接传路径
                        context_options["storage_state"] = storage_state_file
                        self.logger.info(f"[start_browser] 使用已保存的登录信息(明文): {storage_state_file}")

                self.context = self.browser.new_context(**context_options)
                self.page = self.context.new_page()

                if window_max:
                    self._maximize_window(browser_type)

                self.logger.info(f"浏览器启动成功: {browser_type}")
                self._ever_started = True
                return True

            except Exception as e:
                msg = str(e).lower()
                if 'asyncio' in msg and attempt < 2:
                    self.logger.warning(
                        f"Playwright 启动遇到 asyncio 冲突，重试中 ({attempt + 1}/3)...")
                    try:
                        _loop2 = _asyncio.get_event_loop()
                        self.logger.warning(
                            f"[asyncio诊断] thread={_thread_name}, "
                            f"loop={_loop2}, closed={_loop2.is_closed()}, "
                            f"running={_loop2.is_running() if not _loop2.is_closed() else 'N/A'}")
                    except Exception as _e2:
                        self.logger.warning(f"[asyncio诊断] get_event_loop error: {_e2}")
                    try:
                        _rl2 = _asyncio._get_running_loop()
                        self.logger.warning(f"[asyncio诊断] _get_running_loop={_rl2}")
                    except Exception as _e3:
                        self.logger.warning(f"[asyncio诊断] _get_running_loop error: {_e3}")
                    import time
                    time.sleep(1)
                    continue
                self.logger.error(f"浏览器启动失败: {e}")
                if browser_type in ('360ee', '360se') and attempt == 0:
                    self.logger.info("360浏览器启动失败，尝试使用精简参数重试...")
                    try:
                        if self._start_360_fallback(browser_type, browser_path, window_max):
                            return True
                    except Exception as e2:
                        self.logger.error(f"360浏览器精简参数重试也失败: {e2}")
                if attempt >= 2:
                    return False
        return False

    def save_storage_state(self, filepath, encrypt=True):
        """保存当前会话的 storage state 到文件（用于免登录）。

        Args:
            filepath: 保存路径（.enc 加密文件或 .json 明文文件）
            encrypt: 是否加密保存（默认 True，保存为 .enc 文件）

        Returns:
            bool: 是否保存成功
        """
        if not self.context:
            self.logger.error("[save_storage_state] 浏览器未启动，无法保存登录信息")
            return False
        try:
            if encrypt and filepath.endswith('.enc'):
                # 加密保存
                from src.encryption import save_encrypted_storage_state
                state = self.context.storage_state()
                save_encrypted_storage_state(state, filepath)
                self.logger.info(f"[save_storage_state] 登录信息已加密保存: {filepath}")
            else:
                # 明文保存（兼容旧方式）
                self.context.storage_state(path=filepath)
                self.logger.info(f"[save_storage_state] 登录信息已保存: {filepath}")
            return True
        except Exception as e:
            self.logger.error(f"[save_storage_state] 保存登录信息失败: {e}")
            return False

    def load_storage_state(self, filepath):
        """加载 storage state（支持加密和明文）。

        Args:
            filepath: storage state 文件路径（.enc 或 .json）

        Returns:
            dict: storage state 字典，加载失败返回 None
        """
        try:
            if filepath.endswith('.enc'):
                from src.encryption import load_encrypted_storage_state
                state = load_encrypted_storage_state(filepath)
                self.logger.info(f"[load_storage_state] 登录信息已解密加载: {filepath}")
                return state
            else:
                with open(filepath, 'r', encoding='utf-8') as f:
                    state = json.load(f)
                self.logger.info(f"[load_storage_state] 登录信息已加载: {filepath}")
                return state
        except Exception as e:
            self.logger.error(f"[load_storage_state] 加载登录信息失败: {e}")
            return None

    def _start_360_fallback(self, browser_type, browser_path, window_max):
        """360浏览器启动失败后的精简参数回退方案。
        仅使用最基本的参数启动，最大程度兼容360浏览器内核。
        """
        # 清理可能残留的浏览器对象
        if self.browser:
            try:
                self.browser.close()
            except Exception:
                pass
            self.browser = None
        if self.context:
            try:
                self.context.close()
            except Exception:
                pass
            self.context = None
        self.page = None

        if not self.playwright:
            self.playwright = sync_playwright().start()

        launch_args = {
            "executable_path": browser_path,
            "headless": headless,
            "chromium_sandbox": False,
            # 完全忽略所有默认参数，只保留Playwright自动注入的
            # --remote-debugging-pipe 和 --user-data-dir
            "ignore_default_args": True,
            "args": [
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-infobars",
                "--no-sandbox",
            ] + (["--start-maximized"] if window_max else []),
        }

        self.logger.info(f"360浏览器精简模式启动: {browser_path}")
        launcher = self.playwright.chromium
        self.browser = launcher.launch(**launch_args)

        # 关闭360浏览器自动打开的默认页面
        self._close_360_default_pages()

        context_options = {}
        if window_max:
            context_options["no_viewport"] = True
        else:
            context_options["viewport"] = {"width": 1920, "height": 1080}

        self.context = self.browser.new_context(**context_options)
        self.page = self.context.new_page()

        if window_max:
            self._maximize_window(browser_type)

        self.logger.info(f"360浏览器精简模式启动成功: {browser_type}")
        return True

    def _close_360_default_pages(self):
        """通过 CDP 协议关闭360浏览器启动时自动打开的默认页面。

        360浏览器因不兼容 --no-startup-window 参数，启动时会自动打开一个默认标签页。
        Playwright 的 browser.contexts 无法访问该默认窗口（它属于浏览器的默认 context），
        必须通过 CDP 协议的 Target API 枚举并关闭这些页面。
        """
        try:
            cdp = self.browser.new_browser_cdp_session()
            targets = cdp.send('Target.getTargets')
            closed = 0
            for info in targets.get('targetInfos', []):
                if info.get('type') == 'page':
                    target_id = info.get('targetId', '')
                    url = info.get('url', '')
                    try:
                        cdp.send('Target.closeTarget', {'targetId': target_id})
                        closed += 1
                        self.logger.info(
                            f"[360浏览器] 已关闭默认页面: {url[:60]}")
                    except Exception:
                        pass
            cdp.detach()
            if closed:
                self.logger.info(f"[360浏览器] 共关闭 {closed} 个默认页面")
        except Exception as e:
            self.logger.warning(f"[360浏览器] 关闭默认页面失败: {e}")

    def _maximize_window(self, browser_type="chrome"):
        """尝试多种方式最大化浏览器窗口"""
        # 方式1: CDP 命令（Chromium 系：Chrome / Edge / 360浏览器）
        if browser_type in ("chrome", "msedge", "360ee", "360se"):
            try:
                cdp = self.context.new_cdp_session(self.page)
                # 获取屏幕尺寸
                result = cdp.send("Browser.getWindowForTarget")
                window_id = result.get("windowId")
                bounds = result.get("bounds", {})
                # 使用 screen.width/height 通过 JS 获取
                screen_info = self.page.evaluate(
                    "() => ({ w: screen.availWidth, h: screen.availHeight, x: screen.availLeft || 0, y: screen.availTop || 0 })"
                )
                cdp.send("Browser.setWindowBounds", {
                    "windowId": window_id,
                    "bounds": {
                        "windowState": "maximized"
                    }
                })
                cdp.detach()
                self.logger.info("已通过 CDP 最大化窗口")
                return
            except Exception as e:
                self.logger.debug(f"CDP 最大化失败，尝试其他方式: {e}")

        # 方式2: Firefox 通过 JS
        if browser_type == "firefox":
            try:
                self.page.evaluate(
                    "() => { if (window.wrappedJSObject) window.wrappedJSObject.resizeTo(screen.availWidth, screen.availHeight); }"
                )
                self.logger.info("已通过 JS 最大化 Firefox 窗口")
                return
            except Exception:
                pass

        # 方式3: 通用 — 通过 JS 调整 viewport + window (对部分浏览器有效)
        try:
            self.page.evaluate(
                "() => { try { window.moveTo(0, 0); window.resizeTo(screen.availWidth, screen.availHeight); } catch(e) {} }"
            )
            self.logger.info("已尝试通过 JS 最大化窗口")
        except Exception:
            pass

    def bring_to_front(self):
        """将浏览器窗口提到前台并获得焦点"""
        try:
            # 方式1: Playwright page.bring_to_front()
            self.page.bring_to_front()
        except Exception:
            pass
        try:
            # 方式2: CDP 激活窗口（Chromium 系更可靠）
            cdp = self.context.new_cdp_session(self.page)
            result = cdp.send("Browser.getWindowForTarget")
            window_id = result.get("windowId")
            cdp.send("Browser.setWindowBounds", {
                "windowId": window_id,
                "bounds": {"windowState": "normal"}
            })
            cdp.detach()
        except Exception:
            pass

    def open_login_page(self, login_url):
        try:
            self.page.goto(login_url)
            self.logger.info(f"已打开登录页面: {login_url}")
            return True
        except Exception as e:
            self.logger.error(f"打开登录页面失败: {e}")
            return False

    def goto_page(self, url, timeout=30000):
        try:
            self.page.goto(url, timeout=timeout)
            self.logger.info(f"页面访问成功: {url}")
            return True
        except Exception as e:
            self.logger.error(f"页面访问失败: {url}, 错误: {e}")
            return False

    # ================================================================
    #  选择器解析 — 统一入口
    # ================================================================
    @staticmethod
    def parse_selector(selector):
        """解析选择器，返回 (playwright_selector, selector_type)
        支持格式:
          - text=公需课           -> Playwright text 选择器
          - role=link[name="公需课"]  -> Playwright role 选择器
          - //xpath 或 (//xpath   -> XPath
          - css=.class            -> CSS
          - xpath=//...           -> 显式 XPath
          - 其他                   -> 按 CSS 处理
        """
        s = selector.strip()
        if s.startswith('text='):
            return s, 'text'
        if s.startswith('role='):
            return s, 'role'
        if s.startswith('xpath='):
            return s, 'xpath'
        if s.startswith('//') or s.startswith('(//'):
            return f'xpath={s}', 'xpath'
        return s, 'css'

    @staticmethod
    def _extract_xpath_text(selector):
        """从 XPath contains(text(),...) 中提取关键词，用于生成回退选择器。"""
        patterns = [
            r"contains\(\s*(?:text\(\)|\.)\s*,\s*['\"]([^'\"]+)['\"]\s*\)",
        ]
        keywords = []
        for p in patterns:
            keywords.extend(re.findall(p, selector))
        return keywords

    def resolve_selector(self, selector):
        """解析选择器并生成回退策略列表。
        返回 [(playwright_selector, selector_type, is_fallback), ...]
        """
        pw_sel, sel_type = self.parse_selector(selector)
        strategies = [(pw_sel, sel_type, False)]

        # 对 XPath contains(text(),...) 生成 text= 回退
        if sel_type == 'xpath':
            keywords = self._extract_xpath_text(selector)
            for kw in keywords:
                strategies.append((f'text={kw}', 'text', True))
                strategies.append((f'a:has-text("{kw}")', 'css', True))

        # 对 CSS 属性选择器生成 text= 回退
        if sel_type == 'css':
            # 从 [attr="value"] 中提取文本
            attr_texts = re.findall(r'\[[\w-]+="([^"]+)"\]', selector)
            for val in attr_texts:
                # 只对 onclick/href 等不太可靠的选择器添加回退
                if any(kw in selector for kw in ['onclick', 'href=', 'class=']):
                    # 尝试从标签文本回退
                    tag_match = re.match(r'^(\w+)', selector)
                    tag = tag_match.group(1) if tag_match else ''
                    # text= 回退
                    if len(val) <= 60 and not val.startswith(('http', '/', '#', '.')):
                        strategies.append((f'text={val}', 'text', True))
                    # a:has-text 回退
                    if tag == 'a':
                        strategies.append((f'a:has-text("{val}")', 'css', True))

        return strategies

    def query_all_with_fallback(self, selector):
        """用主选择器查询，失败则自动尝试回退选择器。
        返回 (elements, used_selector, used_type, fallback_tried)
        """
        strategies = self.resolve_selector(selector)
        fallback_tried = []

        for pw_sel, sel_type, is_fallback in strategies:
            try:
                elements = self.page.query_selector_all(pw_sel)
                if elements:
                    if is_fallback:
                        self.logger.info(
                            f"[回退] 主选择器无匹配，使用回退选择器: {pw_sel} "
                            f"(匹配 {len(elements)} 个)")
                    return elements, pw_sel, sel_type, fallback_tried
                if is_fallback:
                    fallback_tried.append(pw_sel)
            except Exception as e:
                if is_fallback:
                    fallback_tried.append(f"{pw_sel} (错误: {e})")
                continue

        return [], selector, sel_type, fallback_tried

    def query_one_with_fallback(self, selector):
        """同 query_all_with_fallback 但只返回第一个匹配元素"""
        elements, used_sel, sel_type, tried = self.query_all_with_fallback(selector)
        return elements[0] if elements else None, used_sel, sel_type, tried

    # ================================================================
    #  页面元素点选（Inspector）
    # ================================================================
    _INJECT_JS = r"""
    (window.__pw_inspector = function() {
        if (window.__pw_inspector_active) return;
        window.__pw_inspector_active = true;
        window.__pw_inspector_result = null;

        var overlay = document.createElement('div');
        overlay.id = '__pw_inspector_overlay';
        overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483646;'
            + 'padding:8px 16px;background:#1a73e8;color:#fff;font:14px/1.5 sans-serif;'
            + 'text-align:center;cursor:default;box-shadow:0 2px 8px rgba(0,0,0,.3);'
            + 'display:flex;align-items:center;justify-content:center;gap:16px;';
        var tipSpan = document.createElement('span');
        tipSpan.textContent = '>>> 请点击目标元素 <<<';
        overlay.appendChild(tipSpan);
        var cancelBtn = document.createElement('button');
        cancelBtn.textContent = '\u00D7 取消';
        cancelBtn.style.cssText = 'background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.5);'
            + 'color:#fff;padding:2px 12px;border-radius:4px;cursor:pointer;font:13px/1.4 sans-serif;';
        cancelBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            cleanup();
            window.__pw_inspector_result = {cancelled: true};
        });
        overlay.appendChild(cancelBtn);
        document.body.appendChild(overlay);

        var highlight = document.createElement('div');
        highlight.id = '__pw_inspector_highlight';
        highlight.style.cssText = 'position:fixed;z-index:2147483645;pointer-events:none;'
            + 'border:2px solid #1a73e8;background:rgba(26,115,232,0.12);'
            + 'border-radius:3px;transition:all 0.1s ease;display:none;';
        document.body.appendChild(highlight);

        function buildSelector(el) {
            var selectors = [];

            // 属性值转义：只转义双引号和反斜杠（CSS属性值规则）
            function escapeAttrVal(s) {
                return s.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
            }

            // 1) text=  (最直观)
            var text = (el.textContent || '').trim();
            if (text && text.length <= 80) {
                selectors.push({selector: 'text=' + text, type: 'text', priority: 1});
            }

            // 2) 有限文字的 text=
            if (text && text.length > 80) {
                var short = text.substring(0, 30);
                selectors.push({selector: 'text=' + short, type: 'text-partial', priority: 2});
            }

            // 3) id (CSS.escape 适用于标识符)
            if (el.id) {
                selectors.push({selector: '#' + CSS.escape(el.id), type: 'id', priority: 1});
            }

            // 4) A[href]
            var tag = el.tagName.toUpperCase();
            if (tag === 'A' && el.hasAttribute('href')) {
                var href = el.getAttribute('href');
                if (href && href.length < 200 && href !== 'javascript:;') {
                    selectors.push({selector: 'a[href="' + escapeAttrVal(href) + '"]', type: 'href', priority: 1});
                }
                // a:has-text for JS links
                if (text && text.length <= 80) {
                    selectors.push({selector: 'a:has-text("' + text + '")', type: 'css-has-text', priority: 2});
                }
            }

            // 5) onclick (不用 CSS.escape, 用 escapeAttrVal)
            if (el.hasAttribute('onclick')) {
                var fn = el.getAttribute('onclick');
                if (fn && fn.length < 200) {
                    if (tag === 'A') {
                        selectors.push({selector: 'a[onclick="' + escapeAttrVal(fn) + '"]', type: 'onclick', priority: 1});
                    } else {
                        selectors.push({selector: tag.toLowerCase() + '[onclick="' + escapeAttrVal(fn) + '"]', type: 'onclick', priority: 2});
                    }
                }
            }

            // 6) name
            if (el.hasAttribute('name')) {
                selectors.push({selector: tag.toLowerCase() + '[name="' + escapeAttrVal(el.getAttribute('name')) + '"]', type: 'name', priority: 1});
            }

            // 7) class 组合
            if (el.className && typeof el.className === 'string') {
                var cls = el.className.trim().split(/\s+/).filter(function(c) {
                    return c.length > 0 && !/^(ng-|_|css-|[0-9])/.test(c) && c.length < 40;
                });
                if (cls.length > 0) {
                    var classSel = tag.toLowerCase() + '.' + cls.join('.');
                    selectors.push({selector: classSel, type: 'class', priority: 2});
                }
            }

            // 8) XPath contains(text())
            if (text && text.length <= 80) {
                selectors.push({selector: "//" + tag.toLowerCase() + "[contains(text(),'" + text + "')]", type: 'xpath-text', priority: 3});
            }

            // 9) 唯一路径（兜底）
            var path = [];
            var cur = el;
            while (cur && cur.nodeType === 1) {
                var seg = cur.tagName.toLowerCase();
                if (cur.id) { seg += '#' + cur.id; path.unshift(seg); break; }
                var sib = cur;
                var nth = 1;
                while (sib = sib.previousElementSibling) {
                    if (sib.tagName === cur.tagName) nth++;
                }
                if (nth > 1 || cur.nextElementSibling && cur.nextElementSibling.tagName === cur.tagName) {
                    seg += '[' + nth + ']';
                }
                path.unshift(seg);
                cur = cur.parentElement;
            }
            if (path.length > 0) {
                selectors.push({selector: path.join(' > '), type: 'path', priority: 4});
            }

            // 去重 & 排序
            var seen = {};
            var unique = [];
            for (var i = 0; i < selectors.length; i++) {
                if (!seen[selectors[i].selector]) {
                    seen[selectors[i].selector] = true;
                    unique.push(selectors[i]);
                }
            }
            unique.sort(function(a, b) { return a.priority - b.priority; });

            return {
                tag: tag,
                text: text.substring(0, 200),
                id: el.id || '',
                className: (typeof el.className === 'string') ? el.className : '',
                href: el.getAttribute('href') || '',
                onclick: el.getAttribute('onclick') || '',
                name: el.getAttribute('name') || '',
                type: el.getAttribute('type') || '',
                visible: el.offsetWidth > 0 && el.offsetHeight > 0,
                interactive: tag === 'A' || tag === 'BUTTON' || tag === 'INPUT' || tag === 'SELECT'
                    || el.onclick !== null || el.getAttribute('role') === 'button'
                    || el.getAttribute('role') === 'link',
                selectors: unique
            };
        }

        function onMove(e) {
            var rect = e.target.getBoundingClientRect();
            highlight.style.display = 'block';
            highlight.style.left = rect.left + 'px';
            highlight.style.top = rect.top + 'px';
            highlight.style.width = rect.width + 'px';
            highlight.style.height = rect.height + 'px';
        }

        function onClick(e) {
            e.preventDefault();
            e.stopPropagation();
            cleanup();
            window.__pw_inspector_result = buildSelector(e.target);
        }

        function onKey(e) {
            if (e.key === 'Escape' || e.key === 'Esc' || e.keyCode === 27) {
                e.preventDefault();
                e.stopPropagation();
                cleanup();
                window.__pw_inspector_result = {cancelled: true};
            }
        }

        function cleanup() {
            window.__pw_inspector_active = false;
            document.removeEventListener('mousemove', onMove, true);
            document.removeEventListener('click', onClick, true);
            document.removeEventListener('keydown', onKey, true);
            overlay.remove();
            highlight.remove();
        }

        document.addEventListener('mousemove', onMove, true);
        document.addEventListener('click', onClick, true);
        document.addEventListener('keydown', onKey, true);
    })()
    """

    def start_inspect(self):
        """启动页面元素点选模式。注入 JS 后等待用户点击，结果存入 _inspect_result。
        返回 True 表示注入成功。
        """
        if not self.page:
            self.logger.warning("浏览器未启动，无法点选")
            return False

        self._inspect_active = True
        self._inspect_result = None

        try:
            # 注入 inspector 脚本
            self.page.evaluate(self._INJECT_JS)
            self.logger.info("[点选模式] 已激活 — 请在浏览器中点击目标元素")

            # 轮询等待结果（最多 60 秒）
            import time
            start = time.time()
            while self._inspect_active and (time.time() - start < 60):
                time.sleep(0.3)
                try:
                    result = self.page.evaluate("window.__pw_inspector_result")
                    if result is not None:
                        self._inspect_result = result
                        self._inspect_active = False
                        # 清理
                        self.page.evaluate(
                            "window.__pw_inspector_result = null; "
                            "window.__pw_inspector_active = false;"
                        )
                        break
                except Exception:
                    pass

            return True
        except Exception as e:
            self.logger.error(f"点选模式启动失败: {e}")
            self._inspect_active = False
            return False

    def get_inspect_result(self):
        """获取点选结果，返回 dict 或 None"""
        return self._inspect_result

    def cancel_inspect(self):
        """取消点选模式"""
        self._inspect_active = False
        try:
            self.page.evaluate(
                "if(window.__pw_inspector_active){"
                "  document.getElementById('__pw_inspector_overlay')?.remove();"
                "  document.getElementById('__pw_inspector_highlight')?.remove();"
                "  window.__pw_inspector_active = false;"
                "  window.__pw_inspector_result = {cancelled: true};"
                "}"
            )
        except Exception:
            pass

    # ================================================================
    #  选择器生成（从元素信息自动生成最佳选择器）
    # ================================================================
    @staticmethod
    def _escape_css_attr(value):
        """CSS 属性值转义：只转义双引号和反斜杠"""
        return value.replace('\\', '\\\\').replace('"', '\\"')

    @staticmethod
    def generate_selectors_from_info(info):
        """从 inspect 结果中提取推荐选择器列表
        返回 [(selector, type, description), ...]
        """
        selectors = []
        if not info or info.get('cancelled'):
            return selectors

        tag = info.get('tag', '').upper()
        text = info.get('text', '').strip()
        elem_id = info.get('id', '')
        href = info.get('href', '')
        onclick = info.get('onclick', '')
        name = info.get('name', '')
        interactive = info.get('interactive', False)
        esc = BrowserManager._escape_css_attr

        # 1. id 选择器（最精准）
        if elem_id:
            selectors.append((f'#{elem_id}', 'css', f'ID选择器: #{elem_id}'))

        # 2. A[href] 对 JS 链接用 onclick
        if tag == 'A':
            if onclick:
                short_fn = onclick[:60] + ('...' if len(onclick) > 60 else '')
                selectors.append((f'a[onclick="{esc(onclick)}"]', 'css', f'链接onclick: {short_fn}'))
            if href and href not in ('javascript:;', '#', ''):
                selectors.append((f'a[href="{esc(href)}"]', 'css', f'链接href: {href[:60]}'))
            if text and len(text) <= 60:
                selectors.append((f'text={text}', 'text', f'文本匹配: {text}'))
                selectors.append((f'a:has-text("{text}")', 'css', f'链接文本: {text}'))

        # 3. name 属性
        if name:
            selectors.append((f'{tag.lower()}[name="{esc(name)}"]', 'css', f'name属性: {name}'))

        # 4. 文本选择器（通用）
        if text and tag != 'A' and len(text) <= 60:
            selectors.append((f'text={text}', 'text', f'文本匹配: {text}'))

        # 5. onclick 属性（非 A 标签）
        if onclick and tag != 'A':
            selectors.append((f'{tag.lower()}[onclick="{esc(onclick[:60])}"]', 'css',
                              f'onclick: {onclick[:50]}'))

        # 6. XPath contains(text)
        if text and len(text) <= 60:
            selectors.append((f"//{tag.lower()}[contains(text(),'{text}')]",
                              'xpath', f'XPath文本: {text}'))

        # 7. 从 JS 返回的 selectors 中取
        for sel_info in info.get('selectors', []):
            sel = sel_info.get('selector', '')
            sel_type = sel_info.get('type', '')
            # 避免重复
            if sel and not any(s[0] == sel for s in selectors):
                desc_map = {
                    'text': 'Playwright文本', 'id': 'ID', 'href': '链接href',
                    'onclick': 'onclick属性', 'name': 'name属性', 'class': 'Class组合',
                    'xpath-text': 'XPath文本', 'path': 'DOM路径', 'css-has-text': 'CSS文本匹配',
                    'text-partial': '部分文本',
                }
                desc = desc_map.get(sel_type, sel_type)
                selectors.append((sel, sel_type, desc))

        return selectors

    # ================================================================
    #  选择器测试
    # ================================================================
    def test_selector(self, selector):
        """测试选择器，返回匹配元素的详细信息（含交互性分析和回退信息）"""
        try:
            elements, used_sel, sel_type, fallback_tried = self.query_all_with_fallback(selector)

            results = []
            best_index = -1
            best_score = -1

            for i, el in enumerate(elements[:10]):
                try:
                    text = (el.text_content() or '')[:200]
                    tag = el.evaluate('el => el.tagName').upper()
                    visible = el.is_visible()
                    attrs = el.evaluate(
                        'el => { const a = {}; '
                        'for(const k of el.getAttributeNames()){a[k]=el.getAttribute(k)} '
                        'return a; }'
                    )
                    interactive = tag in self.INTERACTIVE_TAGS or el.evaluate(
                        'el => { const t = el.tagName; '
                        'return t === "A" && el.hasAttribute("href") || '
                        't === "INPUT" || t === "BUTTON" || '
                        'el.onclick !== null || '
                        'el.getAttribute("role") === "button" || '
                        'el.getAttribute("role") === "link"; }'
                    )
                    skip = tag in self.SKIP_TAGS

                    score = -1 if skip else (3 if (visible and interactive) else (2 if visible else 0))
                    if score > best_score:
                        best_score = score
                        best_index = i

                    results.append({
                        'index': i,
                        'tag': tag,
                        'text': text,
                        'visible': visible,
                        'interactive': interactive,
                        'skip': skip,
                        'score': score,
                        'attributes': attrs
                    })
                except Exception:
                    results.append({
                        'index': i, 'tag': '?', 'text': '',
                        'visible': False, 'interactive': False,
                        'skip': True, 'score': -1, 'attributes': {}
                    })

            return {
                'success': True,
                'count': len(elements),
                'elements': results,
                'best_index': best_index,
                'best_tag': results[best_index]['tag'] if best_index >= 0 else None,
                'used_selector': used_sel,
                'used_type': sel_type,
                'fallback_tried': fallback_tried,
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'count': 0,
                'elements': [],
                'best_index': -1,
                'best_tag': None,
                'used_selector': selector,
                'used_type': 'unknown',
                'fallback_tried': [],
            }

    def get_page_info(self):
        """获取当前页面信息"""
        try:
            return {
                'url': self.page.url,
                'title': self.page.title()
            }
        except Exception as e:
            return {
                'url': 'unknown',
                'title': f'获取失败: {e}'
            }

    # ================================================================
    #  多标签页管理
    # ================================================================
    def list_pages(self):
        """列举浏览器中所有标签页，返回 [{index, url, title, is_current}, ...]"""
        if not self.context:
            return []
        try:
            pages = self.context.pages
            result = []
            for i, p in enumerate(pages):
                try:
                    info = {
                        'index': i,
                        'url': p.url or '',
                        'title': p.title() or '',
                        'is_current': (p is self.page),
                    }
                except Exception:
                    info = {
                        'index': i,
                        'url': '(页面已关闭)',
                        'title': '(无标题)',
                        'is_current': False,
                    }
                result.append(info)
            return result
        except Exception as e:
            self.logger.error(f"列举标签页失败: {e}")
            return []

    def switch_to_page(self, page_index, fallback_url=None, fallback_title=None):
        """切换到指定索引的标签页。返回 True/False
        当绝对索引越界时，尝试通过 URL/标题 关键词匹配回退到正确标签页。
        fallback_url: URL 匹配关键词（子串匹配）
        fallback_title: 标题匹配关键词（子串匹配）
        """
        if not self.context:
            self.logger.warning("浏览器未启动，无法切换标签页")
            return False
        try:
            pages = self.context.pages
            # 1. 精确索引匹配
            if 0 <= page_index < len(pages):
                self.page = pages[page_index]
                self.page.bring_to_front()
                self.logger.info(f"已切换到标签页 {page_index}: {self.page.url}")
                return True

            # 2. 索引越界，尝试智能回退
            total = len(pages)
            self.logger.warning(
                f"标签页索引越界: {page_index} (当前共{total}个标签页)，尝试智能匹配...")

            # 2a. 回退：检查当前活跃页面是否可用（tab_index=-1 场景）
            if page_index < 0:
                if self.page and self.page in pages:
                    self.logger.info(f"保持当前标签页 (索引 {pages.index(self.page)})")
                    return True

            # 2b. 回退：通过 URL 关键词匹配
            if fallback_url:
                for i, p in enumerate(pages):
                    try:
                        if fallback_url in (p.url or ''):
                            self.page = p
                            self.page.bring_to_front()
                            self.logger.info(
                                f"智能匹配: 通过URL关键词 '{fallback_url}' 切换到标签页 {i}")
                            return True
                    except Exception:
                        continue

            # 2c. 回退：通过标题关键词匹配
            if fallback_title:
                for i, p in enumerate(pages):
                    try:
                        if fallback_title in (p.title() or ''):
                            self.page = p
                            self.page.bring_to_front()
                            self.logger.info(
                                f"智能匹配: 通过标题关键词 '{fallback_title}' 切换到标签页 {i}")
                            return True
                    except Exception:
                        continue

            # 2d. 回退：如果索引超出范围但超过当前标签数，取最后一个标签页
            if page_index >= total and total > 0:
                last_idx = total - 1
                self.page = pages[last_idx]
                self.page.bring_to_front()
                self.logger.warning(
                    f"标签页索引越界回退: {page_index} -> {last_idx} (使用最后一个标签页)")
                return True

            self.logger.warning(f"标签页切换失败: 索引 {page_index} (共{total}个)")
            return False
        except Exception as e:
            self.logger.error(f"切换标签页失败: {e}")
            return False

    def get_page_by_index(self, page_index):
        """获取指定索引的 Page 对象，返回 Page 或 None"""
        if not self.context:
            return None
        try:
            pages = self.context.pages
            if 0 <= page_index < len(pages):
                return pages[page_index]
        except Exception:
            pass
        return None

    def scan_media_elements(self):
        """扫描当前页面中所有媒体播放器元素（video/audio 及第三方播放器），返回候选选择器列表。
        支持检测以下第三方播放器：
        - xgplayer (西瓜播放器) - 懒加载，会自动触发播放获取 video 元素
        - video.js
        - Plyr
        - JW Player
        - DPlayer
        - 原生 video/audio

        返回 [(selector, type, desc), ...]
        """
        if not self.page:
            return []

        JS_SCAN = r"""
        (() => {
            var results = [];

            // ============================================================
            // 辅助函数
            // ============================================================
            function getMediaInfo(el) {
                var tag = el.tagName.toLowerCase();
                var src = el.currentSrc || el.src || el.getAttribute('src') || '';
                var poster = el.poster || '';
                var id = el.id || '';
                var className = (typeof el.className === 'string') ? el.className : '';
                var visible = el.offsetWidth > 0 && el.offsetHeight > 0;
                var paused = el.paused;
                var duration = el.duration || 0;
                var currentTime = el.currentTime || 0;
                var width = el.offsetWidth || 0;
                var height = el.offsetHeight || 0;

                var selectors = [];
                // 1) id
                if (id) {
                    selectors.push({selector: tag + '#' + CSS.escape(id), type: 'id', priority: 1});
                }
                // 2) src
                if (src && src.length < 200 && !src.startsWith('blob:')) {
                    selectors.push({selector: tag + '[src="' + src.replace(/"/g, '\\"') + '"]', type: 'src', priority: 1});
                }
                // 3) class 组合
                if (className) {
                    var cls = className.trim().split(/\s+/).filter(function(c) {
                        return c.length > 0 && c.length < 40;
                    });
                    if (cls.length > 0 && cls.length <= 3) {
                        selectors.push({selector: tag + '.' + cls.join('.'), type: 'class', priority: 2});
                    }
                }
                // 4) 第 N 个同类
                var siblings = el.parentElement ? el.parentElement.querySelectorAll(':scope > ' + tag) : [];
                if (siblings.length > 1) {
                    var nth = Array.prototype.indexOf.call(siblings, el) + 1;
                    selectors.push({selector: tag + ':nth-of-type(' + nth + ')', type: 'nth', priority: 3});
                }
                // 5) 通用
                selectors.push({selector: tag, type: 'tag', priority: 4});

                // 去重 & 排序
                var seen = {};
                var unique = [];
                for (var j = 0; j < selectors.length; j++) {
                    if (!seen[selectors[j].selector]) {
                        seen[selectors[j].selector] = true;
                        unique.push(selectors[j]);
                    }
                }
                unique.sort(function(a, b) { return a.priority - b.priority; });

                return {
                    tag: tag,
                    src: src.substring(0, 200),
                    id: id,
                    visible: visible,
                    paused: paused,
                    duration: duration,
                    currentTime: currentTime,
                    width: width,
                    height: height,
                    selectors: unique
                };
            }

            // ============================================================
            // 1. 扫描标准 video/audio 元素
            // ============================================================
            var stdMedia = document.querySelectorAll('video, audio');
            stdMedia.forEach(function(el, i) {
                var info = getMediaInfo(el);
                info.source = 'standard';
                results.push(info);
            });

            // ============================================================
            // 2. 扫描第三方播放器
            // ============================================================
            var thirdPartyPlayers = [];

            // 2.1 xgplayer (西瓜播放器) - 懒加载，需要自动触发
            var xgplayers = document.querySelectorAll('.xgplayer');
            xgplayers.forEach(function(container, i) {
                var info = {
                    tag: 'xgplayer',
                    source: 'xgplayer',
                    containerId: container.id || '',
                    containerClass: container.className || '',
                    visible: container.offsetWidth > 0 && container.offsetHeight > 0,
                    paused: true,
                    duration: 0,
                    currentTime: 0,
                    width: container.offsetWidth || 0,
                    height: container.offsetHeight || 0,
                    src: '',
                    selectors: [],
                    triggered: false  // 是否已触发播放
                };

                // 尝试从容器中获取实际的 video 元素
                var videoEl = container.querySelector('video');
                if (videoEl) {
                    // video 元素已存在
                    info.src = videoEl.currentSrc || videoEl.src || '';
                    info.paused = videoEl.paused;
                    info.duration = videoEl.duration || 0;
                    info.currentTime = videoEl.currentTime || 0;
                    info.triggered = true;
                } else {
                    // xgplayer 是懒加载，尝试触发播放来创建 video 元素
                    // 查找开始按钮
                    var startBtn = container.querySelector('.xgplayer-start, xg-start, .xgplayer-icon-play');
                    if (startBtn) {
                        try {
                            // 模拟点击触发 xgplayer 初始化
                            startBtn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
                            info.triggered = true;
                        } catch(e) {}
                    }
                }

                // 生成选择器 - xgplayer 需要使用容器选择器
                if (container.id) {
                    info.selectors.push({selector: '#' + CSS.escape(container.id), type: 'xgplayer#id', priority: 1});
                }
                info.selectors.push({selector: '.xgplayer', type: 'xgplayer.class', priority: 2});

                thirdPartyPlayers.push(info);
            });

            // 2.2 video.js
            var vjsPlayers = document.querySelectorAll('.video-js');
            vjsPlayers.forEach(function(container, i) {
                var info = {
                    tag: 'video.js',
                    source: 'video.js',
                    containerId: container.id || '',
                    visible: container.offsetWidth > 0 && container.offsetHeight > 0,
                    paused: true,
                    duration: 0,
                    currentTime: 0,
                    width: container.offsetWidth || 0,
                    height: container.offsetHeight || 0,
                    src: '',
                    selectors: []
                };

                var videoEl = container.querySelector('video');
                if (videoEl) {
                    info.src = videoEl.currentSrc || videoEl.src || '';
                    info.paused = videoEl.paused;
                    info.duration = videoEl.duration || 0;
                    info.currentTime = videoEl.currentTime || 0;
                }

                if (container.id) {
                    info.selectors.push({selector: '#' + CSS.escape(container.id), type: 'video.js#id', priority: 1});
                }
                info.selectors.push({selector: '.video-js', type: 'video.js.class', priority: 2});

                thirdPartyPlayers.push(info);
            });

            // 2.3 Plyr
            var plyrPlayers = document.querySelectorAll('.plyr');
            plyrPlayers.forEach(function(container, i) {
                var info = {
                    tag: 'plyr',
                    source: 'plyr',
                    containerId: container.id || '',
                    visible: container.offsetWidth > 0 && container.offsetHeight > 0,
                    paused: true,
                    duration: 0,
                    currentTime: 0,
                    width: container.offsetWidth || 0,
                    height: container.offsetHeight || 0,
                    src: '',
                    selectors: []
                };

                var videoEl = container.querySelector('video');
                if (videoEl) {
                    info.src = videoEl.currentSrc || videoEl.src || '';
                    info.paused = videoEl.paused;
                    info.duration = videoEl.duration || 0;
                    info.currentTime = videoEl.currentTime || 0;
                }

                if (container.id) {
                    info.selectors.push({selector: '#' + CSS.escape(container.id), type: 'plyr#id', priority: 1});
                }
                info.selectors.push({selector: '.plyr', type: 'plyr.class', priority: 2});

                thirdPartyPlayers.push(info);
            });

            // 2.4 JW Player
            var jwPlayers = document.querySelectorAll('.jwplayer, #jwplayer, [id^="jwplayer"]');
            jwPlayers.forEach(function(container, i) {
                var info = {
                    tag: 'jwplayer',
                    source: 'jwplayer',
                    containerId: container.id || '',
                    visible: container.offsetWidth > 0 && container.offsetHeight > 0,
                    paused: true,
                    duration: 0,
                    currentTime: 0,
                    width: container.offsetWidth || 0,
                    height: container.offsetHeight || 0,
                    src: '',
                    selectors: []
                };

                var videoEl = container.querySelector('video');
                if (videoEl) {
                    info.src = videoEl.currentSrc || videoEl.src || '';
                    info.paused = videoEl.paused;
                    info.duration = videoEl.duration || 0;
                    info.currentTime = videoEl.currentTime || 0;
                }

                if (container.id) {
                    info.selectors.push({selector: '#' + CSS.escape(container.id), type: 'jwplayer#id', priority: 1});
                }
                info.selectors.push({selector: '.jwplayer', type: 'jwplayer.class', priority: 2});

                thirdPartyPlayers.push(info);
            });

            // 2.5 DPlayer
            var dplayers = document.querySelectorAll('.dplayer');
            dplayers.forEach(function(container, i) {
                var info = {
                    tag: 'dplayer',
                    source: 'dplayer',
                    containerId: container.id || '',
                    visible: container.offsetWidth > 0 && container.offsetHeight > 0,
                    paused: true,
                    duration: 0,
                    currentTime: 0,
                    width: container.offsetWidth || 0,
                    height: container.offsetHeight || 0,
                    src: '',
                    selectors: []
                };

                var videoEl = container.querySelector('video');
                if (videoEl) {
                    info.src = videoEl.currentSrc || videoEl.src || '';
                    info.paused = videoEl.paused;
                    info.duration = videoEl.duration || 0;
                    info.currentTime = videoEl.currentTime || 0;
                }

                if (container.id) {
                    info.selectors.push({selector: '#' + CSS.escape(container.id), type: 'dplayer#id', priority: 1});
                }
                info.selectors.push({selector: '.dplayer', type: 'dplayer.class', priority: 2});

                thirdPartyPlayers.push(info);
            });

            // 合并第三方播放器结果
            results = results.concat(thirdPartyPlayers);

            return results;
        })()
        """

        try:
            media_list = self.page.evaluate(JS_SCAN)
            if not media_list:
                self.logger.info("[扫描媒体] 未发现标准视频/音频或第三方播放器")
                return []

            candidates = []
            for i, m in enumerate(media_list):
                tag = m.get('tag', 'video')
                source = m.get('source', 'standard')
                visible = m.get('visible', False)
                paused = m.get('paused', True)
                duration = m.get('duration', 0)
                src = m.get('src', '')
                elem_id = m.get('id', '') or m.get('containerId', '')
                width = m.get('width', 0)
                height = m.get('height', 0)

                # 状态描述
                state = '暂停' if paused else '播放中'
                vis = '可见' if visible else '隐藏'
                dur_str = f'{duration:.0f}s' if duration > 0 else '未知时长'
                size_str = f'{width}x{height}' if width > 0 else ''
                src_short = src[:60] + ('...' if len(src) > 60 else '') if src else '(无src)'
                src_type = '标准' if source == 'standard' else source

                desc = f'<{tag}> [{src_type}] {vis}/{state} {dur_str} {size_str}'

                # 为每个媒体元素生成最佳选择器
                for sel_info in m.get('selectors', []):
                    sel = sel_info.get('selector', '')
                    sel_type = sel_info.get('type', '')
                    sel_desc = f'{desc} [{sel_type}]'
                    if sel:
                        candidates.append((sel, sel_type, sel_desc))
                    break  # 只取每个元素的最佳选择器

            return candidates
        except Exception as e:
            self.logger.error(f"扫描媒体元素失败: {e}")
            return []

    def trigger_xgplayer(self):
        """触发 xgplayer 播放按钮，创建 video 元素。
        xgplayer 是懒加载播放器，必须触发播放按钮才会创建 video 元素。

        返回: True 如果触发成功，False 否则
        """
        if not self.page:
            self.logger.warning("[触发xgplayer] 浏览器未启动")
            return False

        try:
            # 检查 xgplayer 状态（扩大选择器范围）
            xgplayer_info = self.page.evaluate("""
                () => {
                    // 扩大 xgplayer 容器选择器范围
                    const selectors = [
                        '.xgplayer', '#videoContainer',
                        '[class*="xgplayer"]', '[class*="xg-player"]',
                        '[class*="Xgplayer"]', 'div.xgplayer',
                        '#playerContainer', '#video-box',
                        '.video-container', '.player-container'
                    ];
                    let container = null;
                    for (const sel of selectors) {
                        container = document.querySelector(sel);
                        if (container) break;
                    }
                    
                    // 如果还是找不到，查找含有 xgplayer 关键字的元素
                    if (!container) {
                        const allDivs = document.querySelectorAll('div[class]');
                        for (const div of allDivs) {
                            const cls = String(div.className || '');
                            if (cls.toLowerCase().includes('xgplayer') || cls.toLowerCase().includes('xg-player')) {
                                container = div;
                                break;
                            }
                        }
                    }
                    
                    if (!container) {
                        // 打印页面上的主要容器信息用于调试
                        const mainDivs = Array.from(document.querySelectorAll('div[id], div[class]'))
                            .filter(el => {
                                const rect = el.getBoundingClientRect();
                                return rect.width > 200 && rect.height > 200;
                            })
                            .slice(0, 10)
                            .map(el => ({
                                tag: el.tagName,
                                id: el.id || '',
                                class: String(el.className || '').substring(0, 80),
                                w: Math.round(rect.width),
                                h: Math.round(rect.height)
                            }));
                        return {found: false, hasVideo: false, hasButton: false, mainDivs: mainDivs};
                    }

                    const hasVideo = container.querySelector('video') !== null;
                    const startBtn = container.querySelector('.xgplayer-start, xg-start, [class*="xgplayer-start"], [class*="xg-start"]');

                    return {
                        found: true,
                        hasVideo: hasVideo,
                        hasButton: !!startBtn,
                        containerId: container.id || '',
                        containerClass: String(container.className || '').substring(0, 100)
                    };
                }
            """)

            if not xgplayer_info.get('found'):
                # 打印调试信息
                main_divs = xgplayer_info.get('mainDivs', [])
                if main_divs:
                    div_infos = []
                    for d in main_divs:
                        div_id = d.get('id', '') or d.get('class', '')
                        div_w = d.get('w', 0)
                        div_h = d.get('h', 0)
                        div_infos.append(f'{div_id}({div_w}x{div_h})')
                    self.logger.warning(
                        f"[触发xgplayer] 未找到 xgplayer 容器，页面上大型容器: {div_infos}")
                else:
                    self.logger.warning("[触发xgplayer] 未找到 xgplayer 容器，且页面上无大型容器")
                return False

            if xgplayer_info.get('hasVideo'):
                self.logger.info("[触发xgplayer] video 元素已存在，无需触发")
                return True

            if not xgplayer_info.get('hasButton'):
                self.logger.warning("[触发xgplayer] 未找到开始按钮")
                return False

            self.logger.info(f"[触发xgplayer] 检测到 xgplayer (id={xgplayer_info.get('containerId', '')})，准备触发播放...")

            # 使用 Playwright 的 click 方法触发播放
            start_btn = self.page.query_selector('.xgplayer-start')
            if start_btn:
                start_btn.click()
                self.logger.info("[触发xgplayer] 已点击 .xgplayer-start")
            else:
                xg_start = self.page.query_selector('xg-start')
                if xg_start:
                    xg_start.click()
                    self.logger.info("[触发xgplayer] 已点击 xg-start")
                else:
                    # 尝试使用 JS 触发
                    self.page.evaluate("""
                        () => {
                            const btn = document.querySelector('.xgplayer-start, xg-start');
                            if (btn) btn.click();
                        }
                    """)
                    self.logger.info("[触发xgplayer] 使用 JS 触发")

            # 等待 video 元素创建
            import time
            time.sleep(2)

            # 验证 video 元素是否创建成功
            video_result = self.page.evaluate("""
                () => {
                    const container = document.querySelector('.xgplayer, #videoContainer');
                    if (!container) return {success: false, reason: 'no container'};
                    const video = container.querySelector('video');
                    if (video) {
                        return {
                            success: true,
                            src: video.src || video.currentSrc || '',
                            paused: video.paused
                        };
                    }
                    return {success: false, reason: 'no video after click'};
                }
            """)

            if video_result.get('success'):
                src = video_result.get('src', '')
                self.logger.info(f"[触发xgplayer] video 元素创建成功: {src[:80]}")
                return True
            else:
                self.logger.warning(f"[触发xgplayer] video 元素创建失败: {video_result.get('reason', 'unknown')}")
                return False

        except Exception as e:
            self.logger.error(f"[触发xgplayer] 触发失败: {e}")
            return False

    # ================================================================
    #  媒体事件监听系统
    # ================================================================
    _MEDIA_EVENT_JS = r"""
    (() => {
        // 全局媒体事件监听器，确保只注入一次
        if (window.__pw_media_monitor_active) return;
        window.__pw_media_monitor_active = true;
        window.__pw_media_events = [];
        window.__pw_media_state = {};

        function getMediaId(el) {
            if (el.id) return el.tagName.toLowerCase() + '#' + el.id;
            var idx = Array.prototype.indexOf.call(
                document.querySelectorAll(el.tagName.toLowerCase()), el
            );
            return el.tagName.toLowerCase() + ':eq(' + idx + ')';
        }

        function emitEvent(el, eventType, detail) {
            var mid = getMediaId(el);
            var state = {
                mediaId: mid,
                tag: el.tagName.toLowerCase(),
                event: eventType,
                paused: el.paused,
                ended: el.ended,
                currentTime: el.currentTime,
                duration: el.duration || 0,
                timestamp: Date.now()
            };
            if (detail) Object.assign(state, detail);
            window.__pw_media_events.push(state);
            window.__pw_media_state[mid] = state;
        }

        function attachListeners(el) {
            if (el.__pw_monitored) return;
            el.__pw_monitored = true;

            var events = ['play', 'pause', 'ended', 'waiting', 'playing',
                          'timeupdate', 'error', 'loadedmetadata', 'canplay'];
            events.forEach(function(evtName) {
                el.addEventListener(evtName, function() {
                    emitEvent(el, evtName);
                }, true);
            });

            // 初始化状态
            emitEvent(el, 'init');
        }

        // 监听现有的媒体元素
        document.querySelectorAll('video, audio').forEach(attachListeners);

        // MutationObserver 监听动态添加的媒体元素
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(m) {
                m.addedNodes.forEach(function(node) {
                    if (node.nodeType === 1) {
                        if (node.tagName === 'VIDEO' || node.tagName === 'AUDIO') {
                            attachListeners(node);
                        }
                        var children = node.querySelectorAll ? node.querySelectorAll('video, audio') : [];
                        children.forEach(attachListeners);
                    }
                });
            });
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });

        // 轮询 safety net: 每 2 秒检查未监听的媒体元素
        setInterval(function() {
            document.querySelectorAll('video, audio').forEach(attachListeners);
        }, 2000);
    })()
    """

    def inject_media_monitor(self):
        """注入媒体事件监听脚本到当前页面。返回 True/False。"""
        if not self.page:
            return False
        try:
            self.page.evaluate(self._MEDIA_EVENT_JS)
            self.logger.debug("[媒体监听] 已注入媒体事件监听脚本")
            return True
        except Exception as e:
            self.logger.error(f"[媒体监听] 注入失败: {e}")
            return False

    def get_media_events(self):
        """获取自上次调用以来累积的媒体事件列表，并清空队列。
        返回 [{'mediaId', 'tag', 'event', 'paused', 'ended', 'currentTime', 'duration', 'timestamp'}, ...]
        """
        if not self.page:
            return []
        try:
            events = self.page.evaluate("window.__pw_media_events || []")
            # 清空事件队列
            self.page.evaluate("window.__pw_media_events = []")
            return events or []
        except Exception as e:
            self.logger.debug(f"[媒体监听] 获取事件失败: {e}")
            return []

    def get_media_state(self, selector=None):
        """获取媒体元素的当前状态。
        selector: 指定媒体元素的选择器，None 则返回所有媒体状态。
        返回 dict 或 list。
        """
        if not self.page:
            return {} if selector else []
        try:
            if selector:
                # 获取指定元素的状态
                pw_sel, sel_type = self.parse_selector(selector)
                el = self.page.query_selector(pw_sel)
                if not el:
                    return {}
                return el.evaluate("""el => ({
                    tag: el.tagName.toLowerCase(),
                    paused: el.paused,
                    ended: el.ended,
                    currentTime: el.currentTime,
                    duration: el.duration || 0,
                    src: el.currentSrc || el.src || '',
                    readyState: el.readyState,
                    networkState: el.networkState,
                    error: el.error ? el.error.code : null
                })""")
            else:
                # 返回所有监听的媒体状态
                states = self.page.evaluate("""
                    () => {
                        var result = {};
                        for (var key in (window.__pw_media_state || {})) {
                            result[key] = window.__pw_media_state[key];
                        }
                        return Object.values(result);
                    }
                """)
                return states or []
        except Exception as e:
            self.logger.debug(f"[媒体监听] 获取状态失败: {e}")
            return {} if selector else []

    def _start_media_wait(self, selector):
        """初始化媒体等待：注入脚本、查找元素、自动播放。
        仅执行一次性初始化操作，不进入轮询循环。
        返回 {'ready': bool, 'media_id': str, 'pw_sel': str, 'result': dict|None}
        result 在 ready=False 时包含错误信息，ready=True 时为 None。
        """
        if not self.page:
            return {'ready': False, 'result': {'success': False, 'reason': '页面不可用'}}

        # 先注入监听脚本
        self.inject_media_monitor()

        try:
            pw_sel, sel_type = self.parse_selector(selector)
            el = self.page.query_selector(pw_sel)
            if not el:
                return {'ready': False, 'result': {'success': False, 'reason': f'未找到媒体元素: {selector}'}}

            tag = el.evaluate('el => el.tagName.toLowerCase()')
            media_id = el.evaluate("""el => {
                if (el.id) return el.tagName.toLowerCase() + '#' + el.id;
                var idx = Array.prototype.indexOf.call(
                    document.querySelectorAll(el.tagName.toLowerCase()), el
                );
                return el.tagName.toLowerCase() + ':eq(' + idx + ')';
            }""")

            # 检查是否已经结束
            already_ended = el.evaluate('el => el.ended')
            if already_ended:
                duration = el.evaluate('el => el.duration || 0')
                return {'ready': False, 'result': {'success': True, 'reason': 'already_ended',
                        'duration': duration, 'currentTime': duration}}

            # 确保正在播放 — 等待 play() Promise resolve 以处理自动播放策略
            # 添加重试机制，最多尝试3次
            retry_count = 0
            max_retries = 3
            play_success = False
            muted_success = False
            is_playing = False
            
            # 先等待元素完全可见和可交互
            try:
                # 等待元素可见
                self.page.wait_for_selector(pw_sel, state='visible', timeout=5000)
                # 等待元素可交互
                self.page.wait_for_selector(pw_sel, state='attached', timeout=5000)
            except Exception as e:
                self.logger.warning(f"[媒体监听] 等待媒体元素可见/可交互超时: {selector} ({e})")
            
            while retry_count < max_retries and not play_success and not is_playing:
                retry_count += 1
                try:
                    is_paused = el.evaluate('el => el.paused')
                    is_playing = el.evaluate('el => !el.paused')
                    
                    if is_playing:
                        self.logger.info(f"[媒体监听] 媒体已在播放中: {selector}")
                        play_success = True
                        break
                    
                    if is_paused:
                        # 尝试1: 直接调用play()
                        play_ok = el.evaluate("""async el => {
                            try {
                                await el.play();
                                return true;
                            } catch(e) {
                                return e.name || e.message || 'unknown';
                            }
                        }""")
                        
                        if play_ok is True:
                            self.logger.info(f"[媒体监听] 媒体已暂停，自动开始播放: {selector} (第{retry_count}次尝试)")
                            play_success = True
                            break
                        else:
                            self.logger.warning(
                                f"[媒体监听] 媒体自动播放被阻止: {selector} (原因: {play_ok})，"
                                f"尝试静音后播放 (第{retry_count}次尝试)")
                            
                            # 尝试2: 静音播放绕过自动播放策略
                            muted_ok = el.evaluate("""async el => {
                                try {
                                    el.muted = true;
                                    await el.play();
                                    return true;
                                } catch(e) {
                                    return e.name || e.message || 'unknown';
                                }
                            }""")
                            
                            if muted_ok is True:
                                self.logger.info(f"[媒体监听] 静音播放成功: {selector} (第{retry_count}次尝试)")
                                play_success = True
                                muted_success = True
                                break
                            else:
                                self.logger.warning(
                                    f"[媒体监听] 静音播放也被阻止: {selector} (原因: {muted_ok})，"
                                    f"尝试点击播放按钮 (第{retry_count}次尝试)")
                                
                                # 尝试3: 点击媒体元素触发播放
                                try:
                                    # 点击视频中心位置
                                    el.click(position={'x': 10, 'y': 10})
                                    # 检查是否开始播放
                                    time.sleep(1)
                                    is_playing = el.evaluate('el => !el.paused')
                                    if is_playing:
                                        self.logger.info(f"[媒体监听] 点击播放成功: {selector} (第{retry_count}次尝试)")
                                        play_success = True
                                        break
                                except Exception as click_e:
                                    self.logger.warning(f"[媒体监听] 点击播放失败: {selector} ({click_e}) (第{retry_count}次尝试)")
                except Exception as e:
                    self.logger.error(f"[媒体监听] 播放尝试异常: {selector} ({e}) (第{retry_count}次尝试)")
                
                # 如果未成功且还有重试机会，等待1秒后重试
                if retry_count < max_retries and not play_success:
                    time.sleep(1)
            
            # 如果所有尝试都失败，记录错误
            if not play_success and not is_playing:
                self.logger.error(
                    f"[媒体监听] 无法自动播放媒体: {selector} 所有尝试都失败")

            return {'ready': True, 'media_id': media_id, 'pw_sel': pw_sel, 'result': None}

        except Exception as e:
            return {'ready': False, 'result': {'success': False, 'reason': f'查询媒体元素失败: {e}'}}

    def _check_media_ended(self, selector, media_id, pw_sel):
        """单次检查媒体是否已播放结束。
        不阻塞，立即返回结果。用于轮询模式。
        返回 {'done': bool, 'result': dict|None}
        done=True 时 result 包含最终结果，done=False 时继续轮询。
        """
        try:
            # 检查事件队列
            events = self.get_media_events()
            for evt in events:
                if evt.get('mediaId') == media_id and evt.get('event') == 'ended':
                    duration = evt.get('duration', 0)
                    self.logger.info(
                        f"[媒体监听] 检测到播放结束: {selector} "
                        f"(时长: {duration:.1f}s)")
                    return {'done': True, 'result': {'success': True, 'reason': 'ended',
                            'duration': duration, 'currentTime': evt.get('currentTime', 0)}}

            # 双重保险：直接检查元素 ended 属性
            try:
                el = self.page.query_selector(pw_sel)
                if el:
                    ended = el.evaluate('el => el.ended')
                    if ended:
                        duration = el.evaluate('el => el.duration || 0')
                        current = el.evaluate('el => el.currentTime || 0')
                        self.logger.info(f"[媒体监听] 播放已结束(属性检测): {selector}")
                        return {'done': True, 'result': {'success': True, 'reason': 'ended_property',
                                'duration': duration, 'currentTime': current}}
                    # 记录播放进度（每 30 秒输出一次，用于判断是否在播放）
                    current = el.evaluate('el => el.currentTime || 0')
                    duration = el.evaluate('el => el.duration || 0')
                    return {'done': False, 'progress': {'currentTime': current, 'duration': duration}}
            except Exception:
                pass

        except Exception as e:
            self.logger.debug(f"[媒体监听] 检查异常: {e}")

        return {'done': False, 'progress': None}

    def wait_for_media_ended(self, selector, timeout=3600):
        """等待指定媒体元素播放结束（ended 事件触发）。
        采用分段式轮询：初始化和每次检查都是短操作（在主线程快速完成），
        sleep 在后台线程执行，不阻塞 Tkinter 事件循环。

        selector: 媒体元素选择器
        timeout: 最大等待时间（秒），默认 3600s (1小时)
        返回 {'success': bool, 'reason': str, 'duration': float, 'currentTime': float}
        """
        import time as _time

        if not self.page:
            return {'success': False, 'reason': '页面不可用'}

        # 确保 timeout 为数字（配置文件中可能为字符串）
        try:
            timeout = float(timeout)
        except (ValueError, TypeError):
            timeout = 3600

        # 阶段1: 初始化（一次性操作，在主线程快速完成）
        init = self._start_media_wait(selector)
        if not init['ready']:
            return init['result']

        media_id = init['media_id']
        pw_sel = init['pw_sel']

        # 阶段2: 轮询检查（每次 _check_media_ended 是短操作）
        start_time = _time.time()
        poll_interval = 2.0  # 2秒轮询，减少主线程压力
        last_progress_log = 0  # 上次输出进度日志的时间

        self.logger.info(f"[媒体监听] 等待媒体播放结束: {selector} (超时: {timeout}s)")

        # 判断当前线程：如果在主线程则不能 sleep 阻塞
        import threading
        is_main = threading.current_thread() is threading.main_thread()

        while _time.time() - start_time < timeout:
            # 单次检查（快速操作，<50ms）
            check = self._check_media_ended(selector, media_id, pw_sel)
            if check['done']:
                return check['result']

            # 输出播放进度（每 60 秒一次，避免刷屏）
            now = _time.time()
            progress = check.get('progress')
            if progress and now - last_progress_log >= 60:
                ct = progress.get('currentTime', 0)
                dur = progress.get('duration', 0)
                if dur > 0:
                    pct = ct / dur * 100
                    self.logger.info(
                        f"[媒体监听] 播放进度: {selector} "
                        f"({ct:.0f}s/{dur:.0f}s, {pct:.1f}%)")
                last_progress_log = now

            # 等待下一轮轮询
            if is_main:
                # 主线程: 不能 time.sleep 阻塞 Tkinter 事件循环
                # 使用 Playwright 的 page.wait_for_timeout 让出控制权
                try:
                    self.page.wait_for_timeout(int(poll_interval * 1000))
                except Exception:
                    _time.sleep(poll_interval)
            else:
                _time.sleep(poll_interval)

        # 超时
        self.logger.warning(f"[媒体监听] 等待播放结束超时: {selector} ({timeout}s)")
        return {'success': False, 'reason': 'timeout', 'duration': 0, 'currentTime': 0}

    def play_next_media(self, current_selector, timeout=3600):
        """播放当前媒体直到结束，然后自动播放页面中的下一个媒体。
        current_selector: 当前媒体元素选择器
        timeout: 等待当前媒体结束的最大秒数
        返回 {'success': bool, 'reason': str, 'next_played': bool, 'next_selector': str}
        """
        # 确保 timeout 为数字
        try:
            timeout = float(timeout)
        except (ValueError, TypeError):
            timeout = 3600

        # 先等待当前媒体结束
        result = self.wait_for_media_ended(current_selector, timeout)
        if not result['success']:
            return {**result, 'next_played': False, 'next_selector': ''}

        # 查找页面中所有媒体元素
        try:
            all_media = self.page.evaluate("""() => {
                var mediaEls = document.querySelectorAll('video, audio');
                return Array.from(mediaEls).map((el, i) => ({
                    index: i,
                    tag: el.tagName.toLowerCase(),
                    id: el.id || '',
                    src: (el.currentSrc || el.src || '').substring(0, 200),
                    paused: el.paused,
                    ended: el.ended,
                    duration: el.duration || 0,
                    visible: el.offsetWidth > 0 && el.offsetHeight > 0
                }));
            }""")
        except Exception as e:
            self.logger.error(f"[媒体监听] 查找下一媒体失败: {e}")
            return {**result, 'next_played': False, 'next_selector': ''}

        if not all_media or len(all_media) < 2:
            self.logger.info("[媒体监听] 没有更多媒体可播放")
            return {**result, 'next_played': False, 'next_selector': ''}

        # 找到当前媒体在列表中的位置，播放下一个未结束的
        try:
            pw_sel, _ = self.parse_selector(current_selector)
            current_el = self.page.query_selector(pw_sel)
            if not current_el:
                return {**result, 'next_played': False, 'next_selector': ''}

            current_idx = current_el.evaluate("""el => {
                return Array.prototype.indexOf.call(
                    document.querySelectorAll(el.tagName.toLowerCase()), el
                );
            }""")
        except Exception:
            current_idx = -1

        # 从当前位置之后查找下一个
        next_el_info = None
        for m in all_media:
            if m['index'] > current_idx and not m['ended']:
                next_el_info = m
                break

        # 如果后面没有了，从头找
        if not next_el_info:
            for m in all_media:
                if m['index'] != current_idx and not m['ended']:
                    next_el_info = m
                    break

        if not next_el_info:
            self.logger.info("[媒体监听] 所有媒体均已播放完毕")
            return {**result, 'next_played': False, 'next_selector': ''}

        # 播放下一个
        try:
            tag = next_el_info['tag']
            idx = next_el_info['index']
            next_sel = f"{tag}:nth-of-type({idx + 1})" if idx > 0 else tag

            # 尝试用 id 选择器
            if next_el_info.get('id'):
                next_sel = f"{tag}#{next_el_info['id']}"

            pw_next, _ = self.parse_selector(next_sel)
            next_el = self.page.query_selector(pw_next)

            if not next_el:
                # 回退：获取所有同类标签，按索引取
                all_same = self.page.query_selector_all(tag)
                if idx < len(all_same):
                    next_el = all_same[idx]

            if next_el:
                next_el.evaluate('el => el.play()')
                src = next_el_info.get('src', '')[:50]
                self.logger.info(f"[媒体监听] 自动播放下一个媒体: {next_sel} src={src}")
                return {**result, 'next_played': True, 'next_selector': next_sel}
        except Exception as e:
            self.logger.error(f"[媒体监听] 播放下一个媒体失败: {e}")

        return {**result, 'next_played': False, 'next_selector': ''}

    # ================================================================
    #  页面停留时间统计
    # ================================================================
    def start_stay_tracking(self, step_name='', action=''):
        """开始跟踪当前页面的停留时间。
        仅在页面已加载（load 事件完成）后调用，确保计时从页面就绪开始。
        step_name: 触发此停留的步骤名称
        action: 触发此停留的操作类型
        """
        if self._stay_lock:
            # 已有正在进行的记录，先结束旧的
            self.end_stay_tracking('new_step')

        if not self.page:
            return

        try:
            # 等待页面完全加载后再记录开始时间
            self.page.wait_for_load_state('load', timeout=10000)
        except Exception as e:
            self.logger.debug(f"[停留统计] 等待页面加载超时(继续记录): {e}")

        page_info = self.get_page_info()
        self._current_stay = {
            'step_name': step_name,
            'action': action,
            'url': page_info.get('url', ''),
            'title': page_info.get('title', ''),
            'start_time': time.time(),
            'start_time_str': time.strftime('%H:%M:%S'),
            'end_time': None,
            'end_time_str': '',
            'duration': 0.0,
            'reason': '',
        }
        self._stay_lock = True
        self.logger.debug(f"[停留统计] 开始记录: {page_info.get('title', '')[:30]} (步骤: {step_name})")

    def end_stay_tracking(self, reason='step_end'):
        """结束当前页面的停留时间跟踪，记录数据。
        reason: 停留结束原因
          - 'step_end': 步骤执行完毕（正常）
          - 'new_step': 新步骤开始，自动结束上一个
          - 'navigate': 页面导航跳转
          - 'manual': 手动停止
          - 'error': 发生异常
          - 'pause': 任务暂停
          - 'stop': 任务停止
        """
        if not self._stay_lock or self._current_stay is None:
            return

        end_time = time.time()
        self._current_stay['end_time'] = end_time
        self._current_stay['end_time_str'] = time.strftime('%H:%M:%S')
        duration = end_time - self._current_stay['start_time']
        self._current_stay['duration'] = round(duration, 2)
        self._current_stay['reason'] = reason

        # 记录到历史
        self._stay_records.append(self._current_stay)
        self.logger.info(
            f"[停留统计] {self._current_stay['title'][:30]} "
            f"停留 {self._current_stay['duration']:.1f}s (原因: {reason})")

        self._current_stay = None
        self._stay_lock = False

    def get_stay_records(self):
        """获取所有停留记录（包含当前进行中的记录）。返回 list[dict]。"""
        records = list(self._stay_records)
        # 如果当前有进行中的记录，也返回（标记为 in_progress）
        if self._current_stay is not None:
            current = dict(self._current_stay)
            current['duration'] = round(time.time() - current['start_time'], 2)
            current['reason'] = 'in_progress'
            records.append(current)
        return records

    def get_stay_summary(self):
        """获取停留统计摘要。返回 dict。"""
        records = self._stay_records
        if not records:
            return {
                'total_pages': 0, 'total_duration': 0.0,
                'avg_duration': 0.0, 'max_duration': 0.0,
                'min_duration': 0.0, 'records_count': 0,
            }
        durations = [r['duration'] for r in records if r.get('duration', 0) > 0]
        total = sum(durations)
        return {
            'total_pages': len(records),
            'total_duration': round(total, 2),
            'avg_duration': round(total / len(durations), 2) if durations else 0,
            'max_duration': round(max(durations), 2) if durations else 0,
            'min_duration': round(min(durations), 2) if durations else 0,
            'records_count': len(records),
        }

    def clear_stay_records(self):
        """清空所有停留记录"""
        self.end_stay_tracking('clear')
        self._stay_records = []
        self._current_stay = None
        self._stay_lock = False
        self.logger.info("[停留统计] 已清空所有记录")

    # ================================================================
    #  MyLayer 弹窗自动检测与点击
    # ================================================================
    _MYLAYER_AUTO_JS = r"""
    (() => {
        // 防止重复注入
        if (window.__pw_mylayer_active) return;
        window.__pw_mylayer_active = true;
        window.__pw_mylayer_events = [];

        /**
         * 查找并点击 mylayer 弹窗中的按钮
         * 支持的选择器策略（按优先级）：
         * 1. .mylayer-btn.type1 — 确定/确认按钮（主要）
         * 2. .mylayer-closeico — 关闭图标（次要）
         * 3. 其他常见弹窗确认按钮回退
         */
        function findAndClickLayerBtn(container) {
            var clicked = null;

            // 策略1: .mylayer-btn.type1（确定按钮）
            var confirmBtn = container.querySelector('.mylayer-btn.type1');
            if (confirmBtn) {
                confirmBtn.click();
                clicked = { selector: '.mylayer-btn.type1', text: (confirmBtn.textContent || '').trim(), method: 'confirm' };
                return clicked;
            }

            // 策略1b: .mylayer-btn（不含 type1，但有"确定"文字）
            var allLayerBtns = container.querySelectorAll('.mylayer-btn');
            for (var i = 0; i < allLayerBtns.length; i++) {
                var btnText = (allLayerBtns[i].textContent || '').trim();
                if (/确定|确认|OK|Confirm/i.test(btnText)) {
                    allLayerBtns[i].click();
                    clicked = { selector: '.mylayer-btn', text: btnText, method: 'confirm' };
                    return clicked;
                }
            }

            // 策略2: .mylayer-closeico（关闭图标）
            var closeIcon = container.querySelector('.mylayer-closeico');
            if (closeIcon) {
                closeIcon.click();
                clicked = { selector: '.mylayer-closeico', text: '', method: 'close' };
                return clicked;
            }

            // 策略3: 回退 — 通用弹窗确认按钮
            var fallbackSelectors = [
                '.layui-layer-btn0',       // layui 确定
                '.el-button--primary',     // Element UI 主按钮
                '.ant-btn-primary',        // Ant Design 主按钮
                '.modal .btn-primary',     // Bootstrap modal 确认
                'button.btn-confirm',      // 通用确认按钮
            ];
            for (var j = 0; j < fallbackSelectors.length; j++) {
                var fbBtn = container.querySelector(fallbackSelectors[j]);
                if (fbBtn) {
                    fbBtn.click();
                    clicked = { selector: fallbackSelectors[j], text: (fbBtn.textContent || '').trim(), method: 'fallback' };
                    return clicked;
                }
            }

            return null;
        }

        /**
         * 检测弹窗是否可见（通过 display/visibility/opacity/尺寸）
         */
        function isLayerVisible(el) {
            if (!el) return false;
            var style = window.getComputedStyle(el);
            if (style.display === 'none') return false;
            if (style.visibility === 'hidden') return false;
            if (parseFloat(style.opacity) <= 0) return false;
            return el.offsetWidth > 0 && el.offsetHeight > 0;
        }

        /**
         * 扫描页面上所有可见的 mylayer 弹窗并自动点击
         */
        function scanAndHandleLayers() {
            var handled = [];

            // 查找所有 mylayer 容器
            var layers = document.querySelectorAll(
                '.mylayer, [class*="mylayer"], .mylayer-wrap, .mylayer-main'
            );

            layers.forEach(function(layer) {
                if (!isLayerVisible(layer)) return;

                var result = findAndClickLayerBtn(layer);
                if (result) {
                    // 记录事件
                    var eventData = {
                        type: 'mylayer_click',
                        selector: result.selector,
                        text: result.text,
                        method: result.method,
                        timestamp: Date.now(),
                        layerClass: layer.className || ''
                    };
                    window.__pw_mylayer_events.push(eventData);
                    handled.push(eventData);
                }
            });

            // 额外检查：直接查找可见的 .mylayer-btn.type1（不依赖容器）
            if (handled.length === 0) {
                var standaloneBtn = document.querySelector('.mylayer-btn.type1');
                if (standaloneBtn && standaloneBtn.offsetWidth > 0) {
                    standaloneBtn.click();
                    var eventData = {
                        type: 'mylayer_click',
                        selector: '.mylayer-btn.type1',
                        text: (standaloneBtn.textContent || '').trim(),
                        method: 'standalone',
                        timestamp: Date.now(),
                        layerClass: ''
                    };
                    window.__pw_mylayer_events.push(eventData);
                    handled.push(eventData);
                }
            }

            return handled;
        }

        // MutationObserver 监听动态添加的弹窗
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(m) {
                m.addedNodes.forEach(function(node) {
                    if (node.nodeType !== 1) return;
                    // 检查新节点是否为 mylayer 弹窗
                    var isLayer = (node.classList && (
                        node.classList.contains('mylayer') ||
                        node.classList.contains('mylayer-wrap') ||
                        node.classList.contains('mylayer-main')
                    )) || (node.className && typeof node.className === 'string' &&
                        node.className.indexOf('mylayer') >= 0);

                    if (isLayer) {
                        // 延迟执行，等待弹窗内容渲染完成
                        setTimeout(function() {
                            var result = findAndClickLayerBtn(node);
                            if (result) {
                                window.__pw_mylayer_events.push({
                                    type: 'mylayer_click',
                                    selector: result.selector,
                                    text: result.text,
                                    method: result.method,
                                    timestamp: Date.now(),
                                    layerClass: node.className || ''
                                });
                            }
                        }, 300);
                    }

                    // 检查子节点
                    var subLayers = node.querySelectorAll ? node.querySelectorAll(
                        '.mylayer, [class*="mylayer"], .mylayer-wrap, .mylayer-main'
                    ) : [];
                    if (subLayers.length > 0) {
                        setTimeout(function() {
                            subLayers.forEach(function(sub) {
                                var result = findAndClickLayerBtn(sub);
                                if (result) {
                                    window.__pw_mylayer_events.push({
                                        type: 'mylayer_click',
                                        selector: result.selector,
                                        text: result.text,
                                        method: result.method,
                                        timestamp: Date.now(),
                                        layerClass: sub.className || ''
                                    });
                                }
                            });
                        }, 300);
                    }
                });
            });
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });

        // 定时扫描（兜底，每 2 秒）
        setInterval(scanAndHandleLayers, 2000);
    })()
    """

    def inject_mylayer_handler(self):
        """注入 mylayer 弹窗自动检测与点击脚本。返回 True/False。
        脚本会自动监控页面中出现的 mylayer 弹窗，并点击确定/关闭按钮。
        """
        if not self.page:
            return False
        try:
            self.page.evaluate(self._MYLAYER_AUTO_JS)
            self.logger.info("[MyLayer] 已注入弹窗自动处理脚本")
            return True
        except Exception as e:
            self.logger.error(f"[MyLayer] 注入失败: {e}")
            return False

    def get_mylayer_events(self):
        """获取 mylayer 弹窗点击事件列表并清空队列。返回 list[dict]。"""
        if not self.page:
            return []
        try:
            events = self.page.evaluate("window.__pw_mylayer_events || []")
            self.page.evaluate("window.__pw_mylayer_events = []")
            return events or []
        except Exception as e:
            self.logger.debug(f"[MyLayer] 获取事件失败: {e}")
            return []

    def inject_progress_saver(self):
        """注入媒体进度守护的页面端脚本（页面卸载前同步保存到 localStorage 备份）。
        返回 True/False。
        """
        if not self.page:
            return False
        try:
            self.page.evaluate("""() => {
                if (window.__pw_progress_saver_injected) return;
                window.__pw_progress_saver_injected = true;

                // 页面卸载前将当前媒体进度写入 localStorage（作为备份）
                window.addEventListener('beforeunload', () => {
                    try {
                        const elements = document.querySelectorAll('video, audio');
                        let best = null;
                        let bestScore = -1;
                        for (const el of elements) {
                            const ct = el.currentTime || 0;
                            const dur = el.duration || 0;
                            if (ct < 1 || el.ended || !isFinite(dur) || dur <= 0) continue;
                            let score = ct;
                            if (!el.paused) score += dur;
                            if (score > bestScore) {
                                bestScore = score;
                                const src = el.currentSrc || el.src || '';
                                const elId = el.id || '';
                                const tag = el.tagName.toLowerCase();
                                const raw = location.href + '|' + tag + '|' + elId + '|' + src;
                                let hash = 0;
                                for (let i = 0; i < raw.length; i++) {
                                    hash = ((hash << 5) - hash) + raw.charCodeAt(i);
                                    hash |= 0;
                                }
                                best = {
                                    id: 'media_' + Math.abs(hash).toString(36),
                                    tag: tag,
                                    currentTime: ct,
                                    duration: dur,
                                    percent: dur > 0 ? Math.round(ct / dur * 1000) / 10 : 0,
                                    paused: el.paused,
                                    ended: el.ended,
                                    volume: el.volume,
                                    muted: el.muted,
                                    playbackRate: el.playbackRate || 1,
                                    src: src,
                                    elementId: elId,
                                    pageUrl: location.href,
                                    pageTitle: document.title || '',
                                    savedAt: Date.now()
                                };
                            }
                        }
                        if (best) {
                            localStorage.setItem('__pw_media_progress_backup', JSON.stringify(best));
                        }
                    } catch (e) {}
                });

                // 页面可见性变化时也保存
                document.addEventListener('visibilitychange', () => {
                    if (document.hidden) {
                        try {
                            const elements = document.querySelectorAll('video, audio');
                            for (const el of elements) {
                                if (el.currentTime > 1 && !el.ended) {
                                    const evt = new CustomEvent('__pw_save_progress');
                                    el.dispatchEvent(evt);
                                    break;
                                }
                            }
                        } catch (e) {}
                    }
                });
            }""")
            self.logger.debug("[进度守护] 已注入页面端备份脚本")
            return True
        except Exception as e:
            self.logger.debug(f"[进度守护] 注入页面端脚本失败: {e}")
            return False

    def click_mylayer_confirm(self, selector='.mylayer-btn.type1', timeout=5, page=None):
        """主动查找并点击 mylayer 弹窗的确定按钮。
        selector: 要点击的按钮选择器，默认 '.mylayer-btn.type1'
        timeout: 查找超时（秒）
        page: 指定在哪个页面上查找，None 则使用 self.page
        返回 {'success': bool, 'selector': str, 'text': str}
        
        注意：使用 JS evaluate 触发 click 而非 Playwright click()，
        因为 mylayer 弹窗通常有遮罩层，Playwright click() 会被拦截。
        """
        target = page or self.page
        if not target:
            return {'success': False, 'selector': selector, 'text': ''}

        import time as _time
        start = _time.time()
        while _time.time() - start < timeout:
            try:
                # 策略1: 按指定选择器查找
                btn = target.query_selector(selector)
                if btn and btn.is_visible():
                    text = (btn.text_content() or '').strip()
                    # 使用 JS 直接触发 click，绕过 Playwright 可操作性检查（遮罩层拦截问题）
                    btn.evaluate('el => el.click()')
                    self.logger.info(f"[MyLayer] 已点击确定按钮: {selector} (文本: {text[:30]})")
                    # 短暂等待，验证弹窗是否关闭
                    _time.sleep(0.3)
                    try:
                        still_visible = btn.is_visible()
                    except Exception:
                        still_visible = False
                    if not still_visible:
                        return {'success': True, 'selector': selector, 'text': text}
                    # 按钮仍然可见，尝试强制点击
                    self.logger.debug("[MyLayer] 按钮仍可见，尝试 dispatchEvent 强制点击")
                    btn.evaluate("""el => {
                        var evt = new MouseEvent('click', {bubbles: true, cancelable: true, view: window});
                        el.dispatchEvent(evt);
                    }""")
                    _time.sleep(0.3)
                    return {'success': True, 'selector': selector, 'text': text}

                # 策略2: 查找关闭图标
                close_icon = target.query_selector('.mylayer-closeico')
                if close_icon and close_icon.is_visible():
                    close_icon.evaluate('el => el.click()')
                    self.logger.info("[MyLayer] 已点击关闭图标: .mylayer-closeico")
                    return {'success': True, 'selector': '.mylayer-closeico', 'text': ''}

                # 策略3: 通过文本查找"确定"按钮
                confirm_btn = target.query_selector('.mylayer-btn:has-text("确定")')
                if confirm_btn and confirm_btn.is_visible():
                    confirm_btn.evaluate('el => el.click()')
                    self.logger.info("[MyLayer] 已点击确定按钮(文本匹配)")
                    return {'success': True, 'selector': '.mylayer-btn:has-text("确定")', 'text': '确定'}

                # 策略4: 通过 JS 在页面内直接查找并点击 mylayer 按钮（最可靠）
                js_result = target.evaluate("""() => {
                    var btn = document.querySelector('.mylayer-btn.type1');
                    if (btn && btn.offsetWidth > 0) {
                        btn.click();
                        return {clicked: true, text: (btn.textContent || '').trim(), method: 'js_direct'};
                    }
                    // 尝试关闭图标
                    var close = document.querySelector('.mylayer-closeico');
                    if (close && close.offsetWidth > 0) {
                        close.click();
                        return {clicked: true, text: '', method: 'js_close'};
                    }
                    return {clicked: false, text: '', method: ''};
                }""")
                if js_result and js_result.get('clicked'):
                    self.logger.info(
                        f"[MyLayer] JS直接点击成功: method={js_result.get('method')}, "
                        f"text={js_result.get('text', '')[:30]}")
                    return {'success': True, 'selector': 'js_direct', 'text': js_result.get('text', '')}

            except Exception as e:
                self.logger.debug(f"[MyLayer] 查找按钮异常: {e}")

            _time.sleep(0.3)

        self.logger.warning(f"[MyLayer] 未找到可点击的弹窗按钮: {selector}")
        return {'success': False, 'selector': selector, 'text': ''}

    def close(self, force=False):
        """关闭浏览器及 Playwright 资源。

        Args:
            force: 是否强制关闭。
                   - True: 程序退出时强制关闭（finally 块调用）
                   - False: 仅在浏览器由自动化流程管理时关闭（_auto_close=True），
                            手动停止自动化时浏览器保持打开。
        """
        if self._closed:
            return
        if not force and not self._auto_close:
            # 非强制关闭且非自动化管理的浏览器，保持打开
            self.logger.info("浏览器保持打开（手动停止自动化时不关闭浏览器）")
            return
        self._closed = True
        try:
            self.cancel_inspect()
        except Exception:
            pass
        # 使用非阻塞清理：浏览器可能已被外部关闭，close() 可能卡住
        self._cleanup_resources()
        self._auto_close = False
        self.logger.info("浏览器已关闭")

    def is_alive(self):
        """检查浏览器是否存活（可正常使用）。
        
        多层检测：
        1. _closed 标志（由 close() 设置）
        2. browser/context/page 对象是否存在
        3. page.is_closed()（页面可能被单独关闭）
        4. browser.is_connected()（浏览器进程连接状态）
        """
        if self._closed:
            return False
        if not self.browser or not self.context or not self.page:
            return False
        try:
            # 检查页面是否已关闭（用户可能只关闭了标签页）
            try:
                if self.page.is_closed():
                    self.logger.info("[浏览器状态] page.is_closed()=True，页面已关闭")
                    return False
            except Exception:
                # page 对象已失效，浏览器已死
                self.logger.info("[浏览器状态] page.is_closed() 异常，浏览器已失效")
                return False
            # 检查浏览器进程连接状态
            if not self.browser.is_connected():
                self.logger.info("[浏览器状态] browser.is_connected()=False，浏览器已被外部关闭")
                return False
            return True
        except Exception:
            return False

    def ensure_open(self, browser_type="chrome", window_max=True, browser_path=None, login_url="", storage_state_file=None, headless=False):
        """确保浏览器处于可用状态，根据当前状态智能决策：

        1. 浏览器存活 → 直接复用
        2. 浏览器曾启动但已关闭 → 重新打开
        3. 浏览器从未启动 → 首次打开

        打开成功后标记 _auto_close=True，表示浏览器由自动化流程管理。

        Args:
            storage_state_file: 已保存的 storage state 文件路径。
                                     如果文件存在，则使用它创建 context（实现免登录）。

        Returns:
            bool: 浏览器是否可用
        """
        # 解决 greenlet 线程冲突问题
        self._reset_asyncio()

        # 情况1: 浏览器存活，直接复用
        if self.is_alive():
            self.logger.info("[浏览器] 浏览器已在运行中，直接复用")
            self._auto_close = True
            return True

        # 需要重新打开浏览器：重置关闭标志
        self._closed = False

        if self._ever_started:
            # 情况2: 曾启动但已关闭（用户关闭了浏览器），重新打开
            self.logger.info("[浏览器] 浏览器已关闭，正在重新打开...")
            # 清理残留资源（不调用 close()，因为 _closed 已重置）
            # _cleanup_resources 使用非阻塞方式，不会卡住
            self._cleanup_resources()

            # 安全检查：确保清理后所有引用已置空
            # （如果清理失败，start_browser 会覆盖它们）
            if self.playwright is not None or self.browser is not None:
                self.logger.warning("[浏览器] 残留资源未完全清理，强制置空后重试")
                self.playwright = None
                self.browser = None
                self.context = None
                self.page = None

            if not self.start_browser(browser_type, window_max, browser_path=browser_path, storage_state_file=storage_state_file, headless=headless):
                self.logger.error("浏览器重新打开失败")
                return False
        else:
            # 情况3: 从未启动，首次打开
            self.logger.info("[浏览器] 首次启动浏览器...")
            if not self.start_browser(browser_type, window_max, browser_path=browser_path, storage_state_file=storage_state_file, headless=headless):
                self.logger.error("浏览器启动失败")
                return False

        # 打开登录页面
        # storage_state 只提供登录信息（cookies），不自动导航到任何页面
        # 因此即使使用 storage_state 免登录，仍需导航到登录 URL 作为起始页面
        if login_url:
            self.open_login_page(login_url)
            self.inject_mylayer_handler()

        self._auto_close = True
        self.logger.info("[浏览器] 浏览器已就绪")
        return True

    def _cleanup_resources(self):
        """清理 Playwright 资源并关闭浏览器进程。

        按顺序关闭 page → context → browser → playwright。
        必须在主线程（创建 Playwright 的 greenlet）中调用，
        否则 Playwright 的 close/stop 会因 greenlet 线程绑定问题卡住。
        """
        # 1. 关闭 page
        if self.page:
            page = self.page
            self.page = None
            try:
                if not page.is_closed():
                    page.close()
            except Exception:
                pass

        # 2. 关闭 context
        if self.context:
            ctx = self.context
            self.context = None
            try:
                ctx.close()
            except Exception:
                pass

        # 3. 关闭 browser（这会终止浏览器进程）
        if self.browser:
            br = self.browser
            self.browser = None
            try:
                if br.is_connected():
                    br.close()
                self.logger.info("[清理] 浏览器进程已关闭")
            except Exception as e:
                self.logger.warning(f"[清理] browser.close() 异常: {e}，尝试强制终止")
                self._force_kill_browser_process(br)

        # 4. 停止 playwright（关闭 Node.js 子进程）
        if self.playwright:
            pw = self.playwright
            self.playwright = None
            try:
                pw.stop()
                self.logger.info("[清理] Playwright 已停止")
            except Exception as e:
                self.logger.warning(f"[清理] playwright.stop() 异常: {e}")

    def _force_kill_browser_process(self, browser_obj):
        """强制终止浏览器进程（当 browser.close() 卡住或失败时的最后手段）"""
        try:
            # 尝试从 browser 对象获取进程 PID
            if hasattr(browser_obj, '_impl_obj'):
                impl = browser_obj._impl_obj
                if hasattr(impl, '_browser_process'):
                    proc = impl._browser_process
                    if proc and hasattr(proc, 'pid'):
                        import os
                        import signal
                        pid = proc.pid
                        self.logger.info(f"[清理] 尝试终止浏览器进程 PID={pid}")
                        try:
                            os.kill(pid, signal.SIGTERM)
                        except Exception:
                            try:
                                os.kill(pid, signal.SIGKILL)
                            except Exception:
                                pass
                        return
                    elif proc and hasattr(proc, 'kill'):
                        proc.kill()
                        self.logger.info("[清理] 已强制终止浏览器进程")
                        return
        except Exception:
            pass
        self.logger.warning("[清理] 无法获取浏览器进程信息，可能需要手动关闭")

    def reopen(self, browser_type="chrome", window_max=True, browser_path=None, login_url=""):
        """关闭当前浏览器并重新打开。
        用于停止后重新开始自动化时恢复浏览器会话。
        返回 True 表示成功，False 表示失败。
        """
        self.logger.info("正在重新打开浏览器...")

        # 先彻底关闭
        self.close(force=True)

        # 重置关闭标志，允许重新启动
        self._closed = False

        # 启动浏览器
        if not self.start_browser(browser_type, window_max, browser_path=browser_path):
            self.logger.error("重新打开浏览器失败")
            return False

        # 重新打开登录页面
        if login_url:
            self.open_login_page(login_url)
            self.inject_mylayer_handler()

        self._auto_close = True
        self.logger.info("浏览器重新打开成功")
        return True
