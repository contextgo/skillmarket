import threading
import time


class PopupHandler:
    def __init__(self, page, popup_rules, logger, browser=None, auto_answer_enabled=False):
        self.page = page
        self.popup_rules = popup_rules  # 全局弹窗规则
        self.logger = logger
        self.browser = browser  # 用于统一选择器解析
        self.running = False
        self.thread = None
        self.custom_popup_check_interval = 2.0  # 默认 2 秒轮询
        # 自动答题开关，默认关闭
        self.auto_answer_enabled = auto_answer_enabled
        self._last_handled = {}  # 防止重复处理同一弹窗
        # 弹窗状态变化回调列表
        self._popup_callbacks = []  # [(event_type, callback_fn), ...]
        # 上一次检测到的弹窗状态快照（用于判断状态变化）
        self._last_popup_snapshot = None
        # 答题状态跟踪（用于重试逻辑）
        self._quiz_state = {}  # rule_id -> {tried_indices, last_result, attempts}
        # 答题前原始URL记录（用于答题结束后回调跳转）
        self._pre_quiz_urls = {}  # rule_id -> {'url': str, 'page': page}
        # 上一轮监测周期中所有页面的URL快照（用于在quiz弹窗首次出现时
        # 获取弹窗出现前的原始URL，而非弹窗出现后已变化的URL）
        self._prev_cycle_page_urls = {}  # page_index -> url
        # 步骤级弹窗规则：当前步骤的专属规则（优先于全局规则）
        self._step_popup_rules = []
        self._global_popup_rules = popup_rules  # 保存全局规则引用
        # Playwright 线程安全调用器（由 ControlPanel 设置）
        self._pw_call = None

    def set_pw_caller(self, caller_fn):
        """设置 Playwright 线程安全调用器。
        caller_fn(fn) -> result：将 fn 调度到主线程执行并返回结果。
        """
        self._pw_call = caller_fn

    def _pw(self, fn):
        """线程安全执行 Playwright 操作。如在主线程则直接执行，否则通过调用器调度。"""
        import threading
        if self._pw_call and threading.current_thread() is not threading.main_thread():
            return self._pw_call(fn)
        return fn()

    # ================================================================
    #  弹窗状态回调机制
    # ================================================================
    def on_popup_event(self, event_type, callback_fn):
        """注册弹窗状态变化回调。
        event_type: 事件类型
            - 'detected':  检测到新弹窗
            - 'handled':   弹窗已处理
            - 'error':     处理过程中出错
            - 'cleared':   弹窗已消失（之前存在，现在不存在）
        callback_fn: 回调函数，签名为 callback_fn(event_type, info_dict)
            info_dict 包含: popup_type, page_url, details 等
        """
        self._popup_callbacks.append((event_type, callback_fn))

    def _fire_callback(self, event_type, info):
        """触发指定类型的所有回调。"""
        for cb_type, cb_fn in self._popup_callbacks:
            if cb_type == event_type:
                try:
                    cb_fn(event_type, info)
                except Exception as e:
                    self.logger.debug(f"弹窗回调执行异常: {e}")

    def _get_popup_snapshot(self):
        """获取当前所有页面的弹窗状态快照（单次检测，不执行处理）。
        返回 dict: {page_url: [{'type': str, 'details': str}, ...]}
        """
        snapshot = {}
        try:
            all_pages = self._get_all_pages()
            for page in all_pages:
                page_url = ''
                try:
                    page_url = self._pw(lambda: page.url) or ''
                except Exception:
                    page_url = '<unknown>'
                popups = []
                # 检测 mylayer 弹窗
                try:
                    layer_info = self._check_mylayer_on_page(page)
                    if layer_info['found']:
                        ptype = 'quiz' if layer_info.get('is_quiz') else 'mylayer'
                        popups.append({'type': ptype, 'details': layer_info.get('popup_text', '')[:100]})
                except Exception:
                    pass
                # 检测 quiz 弹窗（不在 mylayer 容器内的）
                try:
                    quiz_info = self._scan_quiz_elements(page)
                    quiz_opts = quiz_info.get('radios', []) or quiz_info.get('checkboxes', [])
                    visible_opts = [o for o in quiz_opts if o.get('visible') and not o.get('disabled')]
                    if len(visible_opts) >= 2:
                        any_checked = any(o.get('checked') for o in visible_opts)
                        if not any_checked and not any(p['type'] in ('quiz', 'mylayer') for p in popups):
                            popups.append({'type': 'quiz', 'details': f'{len(visible_opts)} options'})
                except Exception:
                    pass
                if popups:
                    snapshot[page_url] = popups
        except Exception as e:
            self.logger.debug(f"获取弹窗快照异常: {e}")
        return snapshot

    def set_step_popup_rules(self, step_rules):
        """设置当前步骤的专属弹窗规则。
        步骤执行前调用，将步骤绑定规则与全局规则合并（步骤规则优先）。
        step_rules: 当前步骤的 popup_rules 列表，None 或空列表表示仅使用全局规则。
        """
        if step_rules:
            self._step_popup_rules = step_rules
            # 合并规则：步骤规则在前（优先匹配），全局规则在后
            self.popup_rules = list(step_rules) + list(self._global_popup_rules)
            self.logger.debug(f"[弹窗规则] 已加载步骤专属规则({len(step_rules)}条) + 全局规则({len(self._global_popup_rules)}条)")
        else:
            self._step_popup_rules = []
            self.popup_rules = list(self._global_popup_rules)

    def clear_step_popup_rules(self):
        """清除步骤级弹窗规则，恢复为仅全局规则。步骤执行后调用。"""
        self._step_popup_rules = []
        self.popup_rules = list(self._global_popup_rules)
        # 清除步骤级防重复记录和答题状态
        self._last_handled.clear()
        self._quiz_state.clear()
        self._pre_quiz_urls.clear()
        self._prev_cycle_page_urls.clear()

    def _has_quiz_rules(self):
        """检查当前弹窗规则中是否包含 quiz 类型规则。
        步骤级规则和全局规则都会检查。
        """
        return any(r.get('type') == 'quiz' for r in self.popup_rules)

    def _query_selector(self, selector):
        """统一选择器查询，支持 XPath / CSS / text= 等（线程安全）"""
        if self.browser:
            el, used_sel, sel_type, _ = self._pw(
                lambda: self.browser.query_one_with_fallback(selector))
            return el
        # 回退：无 browser 时手动处理
        try:
            if selector.startswith('//') or selector.startswith('(//'):
                return self._pw(lambda: self.page.query_selector(f'xpath={selector}'))
            return self._pw(lambda: self.page.query_selector(selector))
        except Exception:
            return None

    def _query_selector_all(self, selector):
        """查询所有匹配元素（线程安全）"""
        if self.browser:
            try:
                pw_sel, sel_type = self.browser.parse_selector(selector)
                return self._pw(lambda: self.page.query_selector_all(pw_sel))
            except Exception:
                return []
        try:
            if selector.startswith('//') or selector.startswith('(//'):
                return self._pw(lambda: self.page.query_selector_all(f'xpath={selector}'))
            return self._pw(lambda: self.page.query_selector_all(selector))
        except Exception:
            return []

    # ================================================================
    #  弹窗类型自动判断
    # ================================================================
    def detect_popup_type(self, text_or_element):
        """自动判断弹窗类型：
        1. 浏览器原生 dialog（alert/confirm/prompt）由 Playwright 事件处理
        2. 页面 DOM 弹窗：通过关键词匹配或元素特征判断
           - 'radio': 包含 radio/checkbox 选项列表（单选题）
           - 'custom': 通用自定义弹窗
        """
        # 文本匹配规则
        if isinstance(text_or_element, str):
            text = text_or_element
        else:
            try:
                text = self._pw(lambda: text_or_element.text_content()) or ''
            except Exception:
                text = ''

        # 遍历已有规则，如果关键词匹配，直接使用规则的类型
        for rule in self.popup_rules:
            keyword = rule.get('keyword', '')
            if keyword and keyword in text:
                return rule.get('type', 'custom')

        # 无匹配规则时，尝试自动检测
        # MyLayer 弹窗特征：页面中出现 .mylayer 容器
        try:
            mylayer_els = self._pw(lambda: self.page.query_selector_all('.mylayer, [class*="mylayer"]'))
            visible_layers = [el for el in mylayer_els if self._pw(lambda el=el: el.is_visible())]
            if visible_layers:
                self.logger.debug(f"自动检测: 发现 {len(visible_layers)} 个 mylayer 弹窗 → layer 弹窗")
                return 'layer'
        except Exception:
            pass

        # 单选题特征：页面中出现 radio 输入组
        try:
            radio_groups = self._pw(lambda: self.page.query_selector_all('input[type="radio"]'))
            visible_radios = [r for r in radio_groups if self._pw(lambda r=r: r.is_visible())]
            if visible_radios and len(visible_radios) >= 2:
                # 进一步判断是否为答题弹窗（有提交按钮 + 题目文本）
                submit_btns = self._pw(lambda: self.page.query_selector_all(
                    'button[type="submit"], input[type="submit"], '
                    'button:has-text("提交"), button:has-text("确定")'))
                has_submit = any(self._pw(lambda b=b: b.is_visible()) for b in submit_btns)
                if has_submit:
                    self.logger.debug(f"自动检测: 发现 {len(visible_radios)} 个选项 + 提交按钮 → 答题弹窗")
                    return 'quiz'
                else:
                    self.logger.debug(f"自动检测: 发现 {len(visible_radios)} 个 radio 选项 → 单选题弹窗")
                    return 'radio'
        except Exception:
            pass

        # 默认为自定义弹窗
        return 'custom'

    def match_rule(self, text):
        for rule in self.popup_rules:
            keyword = rule.get('keyword', '')
            if keyword and keyword in text:
                return rule
        return None

    # ================================================================
    #  浏览器原生 dialog 处理
    # ================================================================
    def handle_dialog(self, dialog):
        try:
            text = dialog.message
            self.logger.info(f"捕获到弹窗: {text}")

            rule = self.match_rule(text)

            if rule:
                action = rule.get('action', 'close')
                dialog_type = rule.get('type', 'alert')

                if dialog_type == 'alert':
                    dialog.accept()
                    self.logger.info(f"已关闭alert弹窗: {text}")

                elif dialog_type == 'confirm':
                    if action == 'accept':
                        dialog.accept()
                        self.logger.info(f"已确认confirm弹窗: {text}")
                    else:
                        dialog.dismiss()
                        self.logger.info(f"已取消confirm弹窗: {text}")

                elif dialog_type == 'prompt':
                    input_text = rule.get('input_text', '')
                    dialog.accept(input_text)
                    self.logger.info(f"已在prompt弹窗输入: {input_text}, 弹窗内容: {text}")
            else:
                # 自动判断类型后处理
                dialog.accept()
                self.logger.warning(f"弹窗无匹配规则，已默认关闭: {text}")

        except Exception as e:
            self.logger.error(f"处理弹窗异常: {e}")

    # ================================================================
    #  标签页切换
    # ================================================================
    def _get_target_page(self, tab_index):
        """获取目标标签页的 page 对象。tab_index < 0 表示当前页面。"""
        if tab_index < 0 or not self.browser:
            return self.page

        page = self.browser.get_page_by_index(tab_index)
        if page is None:
            self.logger.debug(f"弹窗规则目标标签页 {tab_index} 不存在，使用当前页面")
            return self.page
        return page

    def _get_all_pages(self):
        """获取所有标签页的 page 列表（用于全标签页扫描）。"""
        if not self.browser or not self.browser.context:
            return [self.page] if self.page else []
        try:
            return self.browser.context.pages
        except Exception:
            return [self.page] if self.page else []

    def _check_mylayer_on_page(self, page):
        """检查指定页面上是否存在可见的 mylayer 弹窗。
        返回 {'found': bool, 'confirm_btn': element|None, 'close_icon': element|None,
               'popup_text': str, 'container': element|None, 'is_quiz': bool}
        is_quiz=True 表示该 mylayer 弹窗内含答题元素(radio/checkbox+提交按钮)，
        不应作为 layer 类型处理，应由 quiz/radio 规则处理。
        """
        result = {
            'found': False,
            'confirm_btn': None,
            'close_icon': None,
            'popup_text': '',
            'container': None,
            'is_quiz': False
        }
        try:
            # 检查 mylayer 容器是否存在且可见
            container = self._pw(lambda: page.query_selector(
                '.mylayer-layer.mylayer-openBtns, .mylayer-layer[style*="display"]'))
            if not container:
                # 回退：检查任意 mylayer 容器
                container = self._pw(lambda: page.query_selector('.mylayer-layer'))
            if not container or not self._pw(lambda: container.is_visible()):
                return result

            result['container'] = container
            result['found'] = True

            # 检测是否为答题弹窗：容器内含 radio/checkbox 选项
            try:
                has_radios = self._pw(lambda: container.query_selector(
                    'input[type="radio"], input[type="checkbox"]')) is not None
                has_submit = self._pw(lambda: container.query_selector(
                    'button[type="submit"], input[type="submit"], '
                    'button:has-text("提交"), button:has-text("确定"), '
                    '.btn.u-main-btn, .m-common-btn button')) is not None
                if has_radios:
                    result['is_quiz'] = True
                    self.logger.debug(
                        f"[MyLayer] 检测到答题弹窗 (radios={has_radios}, submit={has_submit})，"
                        f"跳过 layer 处理")
            except Exception:
                pass

            # 获取弹窗文本内容（从容器获取，包含标题+内容+按钮）
            try:
                result['popup_text'] = (self._pw(lambda: container.text_content()) or '').strip()
            except Exception:
                result['popup_text'] = ''

            # 查找确认按钮（仅在非 quiz 弹窗中有意义）
            confirm_btn = self._pw(lambda: page.query_selector('.mylayer-btn.type1'))
            if confirm_btn and self._pw(lambda: confirm_btn.is_visible()):
                result['confirm_btn'] = confirm_btn

            # 查找关闭图标
            close_icon = self._pw(lambda: page.query_selector('.mylayer-closeico'))
            if close_icon and self._pw(lambda: close_icon.is_visible()):
                result['close_icon'] = close_icon

        except Exception:
            pass
        return result

    # ================================================================
    #  单选题（radio）弹窗处理
    # ================================================================
    def _handle_radio_popup(self, rule, target_page):
        """处理单选题弹窗：根据选项值或选择器选中对应的 radio 按钮"""
        selector = rule.get('selector', '')
        option_value = rule.get('option_value', '')  # radio 的 value 属性
        keyword = rule.get('keyword', '')

        try:
            if selector:
                # 方式1：直接用选择器选中目标 radio
                element = self._query_selector(selector)
                if element:
                    # 检查是否已经选中
                    is_checked = self._pw(lambda: element.is_checked())
                    if is_checked:
                        self.logger.debug(f"单选题 radio 已选中，跳过: {selector}")
                        return True

                    self._pw(lambda: element.click())
                    self.logger.info(f"单选题已选中选项: {selector}")
                    return True

            if option_value:
                # 方式2：通过 radio 的 value 属性选择
                # 查找所有 radio，找到 value 匹配的
                radios = self._pw(lambda: target_page.query_selector_all('input[type="radio"]'))
                for radio in radios:
                    try:
                        val = self._pw(lambda: radio.get_attribute('value')) or ''
                        if val == option_value:
                            is_checked = self._pw(lambda: radio.is_checked())
                            if is_checked:
                                self.logger.debug(f"单选题 radio [value={option_value}] 已选中，跳过")
                                return True
                            self._pw(lambda: radio.click())
                            self.logger.info(f"单选题已选中选项: value={option_value}")
                            return True
                    except Exception:
                        continue

                # 方式3：通过 radio 旁边的 label 文本匹配
                for radio in radios:
                    try:
                        # 尝试通过关联的 label 获取文本
                        radio_id = self._pw(lambda: radio.get_attribute('id')) or ''
                        if radio_id:
                            label = self._pw(lambda: target_page.query_selector(f'label[for="{radio_id}"]'))
                            if label:
                                label_text = self._pw(lambda: label.text_content()) or ''
                                if keyword and keyword in label_text:
                                    is_checked = self._pw(lambda: radio.is_checked())
                                    if is_checked:
                                        self.logger.debug(f"单选题 radio (label匹配) 已选中，跳过")
                                        return True
                                    self._pw(lambda: radio.click())
                                    self.logger.info(f"单选题已选中选项(label匹配): {label_text[:30]}")
                                    return True
                    except Exception:
                        continue

            self.logger.debug(f"单选题未找到匹配选项: selector={selector}, value={option_value}")
            return False

        except Exception as e:
            self.logger.error(f"处理单选题弹窗异常: {e}")
            return False

    # ================================================================
    #  答题(quiz)弹窗处理 — 智能答题 + 错误重试
    # ================================================================
    def _scan_quiz_elements(self, target_page):
        """扫描页面中的答题弹窗元素结构，返回题目、选项和提交按钮信息"""
        try:
            result = self._pw(lambda: target_page.evaluate(r"""() => {
                var info = {
                    hasRadio: document.querySelectorAll('input[type="radio"]').length > 0,
                    hasCheckbox: document.querySelectorAll('input[type="checkbox"]').length > 0,
                    radios: [],
                    checkboxes: [],
                    submitBtns: [],
                    errorIndicators: []
                };

                // 收集 radio 选项
                document.querySelectorAll('input[type="radio"]').forEach(function(el, i) {
                    var label = '';
                    if (el.id) {
                        var lbl = document.querySelector('label[for="' + el.id + '"]');
                        label = lbl ? (lbl.textContent || '').trim() : '';
                    }
                    if (!label) {
                        // 向上查找含有文本的父级 label 元素
                        var p = el.closest('label');
                        if (p) {
                            label = (p.textContent || '').trim().substring(0, 80);
                        } else {
                            p = el.parentElement;
                            while (p && !p.textContent.match(/\S/) && p !== document.body)
                                p = p.parentElement;
                            label = p ? (p.textContent || '').trim().substring(0, 80) : '';
                        }
                    }
                    // 可见性判断：radio input 可能被自定义 UI 隐藏(display:none/opacity:0)，
                    // 此时检查父级 label 元素的可见性
                    var visEl = el.closest('label') || el.parentElement || el;
                    var isVisible = visEl.offsetWidth > 0 && visEl.offsetHeight > 0;
                    // 额外检查：如果 input 自身隐藏但 label 可见，也视为可见
                    if (!isVisible && el.offsetWidth === 0 && visEl !== el) {
                        var visStyle = window.getComputedStyle(visEl);
                        isVisible = visStyle.display !== 'none' && visStyle.visibility !== 'hidden'
                                    && parseFloat(visStyle.opacity) > 0;
                    }
                    info.radios.push({
                        index: i,
                        id: el.id || '',
                        name: el.name || '',
                        value: el.value || '',
                        checked: el.checked,
                        visible: isVisible,
                        label: label,
                        disabled: el.disabled
                    });
                });

                // 收集 checkbox 选项
                document.querySelectorAll('input[type="checkbox"]').forEach(function(el, i) {
                    var label = '';
                    if (el.id) {
                        var lbl = document.querySelector('label[for="' + el.id + '"]');
                        label = lbl ? (lbl.textContent || '').trim() : '';
                    }
                    if (!label) {
                        var p = el.closest('label');
                        if (p) {
                            label = (p.textContent || '').trim().substring(0, 80);
                        } else {
                            p = el.parentElement;
                            while (p && !p.textContent.match(/\S/) && p !== document.body)
                                p = p.parentElement;
                            label = p ? (p.textContent || '').trim().substring(0, 80) : '';
                        }
                    }
                    var visEl = el.closest('label') || el.parentElement || el;
                    var isVisible = visEl.offsetWidth > 0 && visEl.offsetHeight > 0;
                    if (!isVisible && el.offsetWidth === 0 && visEl !== el) {
                        var visStyle = window.getComputedStyle(visEl);
                        isVisible = visStyle.display !== 'none' && visStyle.visibility !== 'hidden'
                                    && parseFloat(visStyle.opacity) > 0;
                    }
                    info.checkboxes.push({
                        index: i,
                        id: el.id || '',
                        name: el.name || '',
                        value: el.value || '',
                        checked: el.checked,
                        visible: el.offsetWidth > 0 && el.offsetHeight > 0,
                        label: label,
                        disabled: el.disabled
                    });
                });

                // 查找提交按钮 —— 增强版：容器范围限定 + 可见性优先排序 + 丰富定位信息
                // 阶段1: 确定 quiz 容器范围（选项所在的最近公共祖先），缩小按钮搜索范围
                var quizContainer = document;
                var firstRadio = document.querySelector('input[type="radio"]');
                var firstCheckbox = document.querySelector('input[type="checkbox"]');
                var firstInput = firstRadio || firstCheckbox;
                if (firstInput) {
                    // 向上查找含有所有选项的最近容器（dialog/form/div等）
                    var container = firstInput.closest('dialog, [role="dialog"], .modal, .popup, .quiz, .exam, form');
                    if (container) {
                        quizContainer = container;
                    } else {
                        // 回退：找包含第一个选项的 form 或有意义的父级
                        container = firstInput.closest('form');
                        if (container) quizContainer = container;
                    }
                }

                // 阶段2: 在容器范围内查找提交按钮
                var btnSelectors = [
                    'button[type="submit"]',
                    'input[type="submit"]',
                    '.submit-btn', '.btn-submit', '#submit',
                    '.confirm-btn', '.btn-confirm', '#confirm',
                    'a.submit', 'a.btn-submit'
                ];
                var foundBtns = [];  // [{el, priority, inContainer}]
                var seenEls = new Set();

                function addBtn(el, priority, inContainer) {
                    if (!el || seenEls.has(el)) return;
                    seenEls.add(el);
                    foundBtns.push({el: el, priority: priority, inContainer: inContainer});
                }

                // CSS 选择器匹配
                btnSelectors.forEach(function(sel) {
                    try {
                        quizContainer.querySelectorAll(sel).forEach(function(b) {
                            addBtn(b, 10, true);
                        });
                        // 同时在 document 范围查找（但优先级更低）
                        if (quizContainer !== document) {
                            document.querySelectorAll(sel).forEach(function(b) {
                                addBtn(b, 5, false);
                            });
                        }
                    } catch(e) {}
                });

                // 关键词文本匹配 — 在容器内
                quizContainer.querySelectorAll('button, [role="button"], a.btn').forEach(function(btn) {
                    var txt = (btn.textContent || btn.value || '').trim();
                    if (/提交|确定|确认|提交答案|submit|ok|确认提交|下一题/i.test(txt)) {
                        addBtn(btn, 8, true);
                    }
                });
                // 关键词文本匹配 — 全局范围
                if (quizContainer !== document) {
                    document.querySelectorAll('button, [role="button"], a.btn').forEach(function(btn) {
                        var txt = (btn.textContent || btn.value || '').trim();
                        if (/提交|确定|确认|提交答案|submit|ok|确认提交|下一题/i.test(txt)) {
                            addBtn(btn, 3, false);
                        }
                    });
                }

                // 阶段3: 排序 — 优先级: 在容器内 > 全局，可见 > 不可见
                foundBtns.sort(function(a, b) {
                    var aVis = a.el.offsetWidth > 0 && a.el.offsetHeight > 0 ? 100 : 0;
                    var bVis = b.el.offsetWidth > 0 && b.el.offsetHeight > 0 ? 100 : 0;
                    var aScore = a.priority + aVis + (a.inContainer ? 50 : 0);
                    var bScore = b.priority + bVis + (b.inContainer ? 50 : 0);
                    return bScore - aScore;
                });

                // 阶段4: 生成结构化信息（含丰富定位字段供 _locate_submit_button 使用）
                foundBtns.forEach(function(item) {
                    var b = item.el;
                    var rect = b.getBoundingClientRect();
                    // 计算唯一 CSS 路径（用于后续重新定位）
                    var cssPath = '';
                    try {
                        if (b.id) {
                            cssPath = '#' + b.id;
                        } else {
                            var parts = [];
                            var node = b;
                            while (node && node !== document) {
                                var sel = node.tagName.toLowerCase();
                                if (node.id) { sel += '#' + node.id; parts.unshift(sel); break; }
                                var siblings = node.parentElement ? node.parentElement.children : [];
                                var idx = 0;
                                for (var s = 0; s < siblings.length; s++) {
                                    if (siblings[s].tagName === node.tagName) idx++;
                                    if (siblings[s] === node) { sel += ':nth-of-type(' + idx + ')'; break; }
                                }
                                parts.unshift(sel);
                                node = node.parentElement;
                            }
                            cssPath = parts.join(' > ');
                        }
                    } catch(e) {}

                    info.submitBtns.push({
                        tag: b.tagName.toLowerCase(),
                        text: (b.textContent || b.value || '').trim().substring(0, 50),
                        type: b.type || '',
                        id: b.id || '',
                        className: (typeof b.className === 'string') ? b.className : '',
                        visible: b.offsetWidth > 0 && b.offsetHeight > 0,
                        inContainer: item.inContainer,
                        priority: item.priority,
                        cssPath: cssPath.substring(0, 200),
                        rect: {x: Math.round(rect.x), y: Math.round(rect.y),
                               w: Math.round(rect.width), h: Math.round(rect.height)},
                        disabled: b.disabled || false
                    });
                });

                return info;
            }"""))
            return result
        except Exception as e:
            self.logger.debug(f"[答题] 扫描元素失败: {e}")
            return {}

    def _detect_quiz_error(self, target_page, before_snapshot=None):
        """检测答题后的错误反馈。
        before_snapshot: 答题前的快照，用于对比变化。
        返回 {'has_error': bool, 'error_text': str, 'feedback': str}
        """
        # 常见错误反馈关键词（可配置）
        error_keywords = ['错误', '回答错误', '答错了', '不正确', 'wrong', 'incorrect',
                           'error', 'fail', '再试', '重新选择', '答案不对', '请重试']
        success_keywords = ['正确', '回答正确', '恭喜', '通过', 'completed', 'success', '完成']

        try:
            # 方式1: 页面上出现新的错误提示文字
            page_text = self._pw(lambda: target_page.evaluate("document.body.innerText")) or ''
            for kw in error_keywords:
                if kw in page_text:
                    # 排除题目本身可能包含的关键词
                    if before_snapshot and kw in before_snapshot:
                        continue
                    return {'has_error': True, 'error_text': kw, 'feedback': f'检测到错误提示: {kw}'}

            # 方式2: 检查是否有红色/高亮的错误样式元素
            error_els = self._pw(lambda: target_page.evaluate("""() => {
                var els = [];
                // 常见错误提示 CSS 类名或内联样式
                var selectors = ['.error', '.wrong', '.incorrect', '.fail',
                               '.alert-danger', '.alert-error', '.toast-error'];
                selectors.forEach(function(sel) {
                    try {
                        document.querySelectorAll(sel).forEach(function(el) {
                            if (el.offsetHeight > 0 && el.innerText.trim()) {
                                els.push({text: el.innerText.trim().substring(0, 100), tag: el.tagName});
                            }
                        });
                    } catch(e) {}
                });
                return els;
            }"""))

            if error_els:
                err = error_els[0] if error_els else {}
                return {'has_error': True, 'error_text': err.get('text', ''), 'feedback': f'错误元素: [{err.get("tag", "")}] {err.get("text", "")}'}

            # 方式3: 弹窗仍然存在且选项被重置（常见于在线考试平台）
            # 检查是否出现"再来一次"/"继续"等按钮
            retry_btns = self._pw(lambda: target_page.evaluate("""() => {
                var btns = [];
                document.querySelectorAll('button, [onclick], .btn, a').forEach(function(el) {
                    var t = (el.textContent || el.value || '').trim();
                    if (/再来|继续|下一题|重试|retry|next|again/i.test(t)) {
                        if (el.offsetHeight > 0)
                            btns.push(t.substring(0, 50));
                    }
                });
                return btns;
            }"""))
            if retry_btns:
                return {'has_error': True, 'error_text': retry_btns[0], 'feedback': f'检测到重试按钮: {retry_btns[0]}'}

            return {'has_error': False, 'error_text': '', 'feedback': ''}

        except Exception as e:
            self.logger.debug(f"[答题] 错误检测异常: {e}")
            return {'has_error': False, 'error_text': '', 'feedback': ''}

    # ================================================================
    #  答题URL记录与回调跳转
    # ================================================================
    def _record_pre_quiz_url(self, rule_id, target_page):
        """答题开始前记录答题弹窗所在页面的完整URL。

        核心逻辑：优先使用上一轮监测周期中该页面的URL（即答题弹窗出现前的URL），
        因为答题弹窗出现时页面URL可能已经从原始课程页导航到了答题页。
        如果上一轮没有记录，则使用当前URL作为回退。

        rule_id: 规则唯一标识（用于后续查找对应URL）
        target_page: 答题弹窗所在的页面对象
        返回: 记录的URL字符串，失败时返回空字符串
        """
        try:
            # 如果该 rule_id 已有记录，说明是重试，不覆盖原始URL
            if rule_id in self._pre_quiz_urls:
                existing_url = self._pre_quiz_urls[rule_id]['url']
                self.logger.info(
                    f"[答题URL] rule_id={rule_id} 已有记录(URL={existing_url[:80]})，"
                    f"保留原始URL不覆盖")
                return existing_url

            # 获取当前页面URL
            current_url = ''
            try:
                current_url = self._pw(lambda: target_page.url) or ''
            except Exception as e:
                self.logger.warning(f"[答题URL] 获取当前页面URL异常: {e}")

            if not current_url:
                self.logger.warning(f"[答题URL] 无法获取答题页面URL，rule_id={rule_id}")
                return ''

            # 尝试从上一轮周期快照中获取该页面的URL（答题弹窗出现前的URL）
            prev_url = self._find_prev_cycle_url(target_page)

            # 决策：使用哪个URL作为回调目标
            if prev_url and prev_url != current_url:
                # 上一轮URL与当前URL不同 → 说明答题弹窗出现导致了URL变化
                # 优先使用上一轮的URL（原始课程页面URL）
                record_url = prev_url
                self.logger.info(
                    f"[答题URL] 检测到URL变化，使用上一轮周期URL作为回调目标:\n"
                    f"  上一轮URL(回调目标): {prev_url[:120]}\n"
                    f"  当前URL(答题页): {current_url[:120]}\n"
                    f"  rule_id={rule_id}")
            else:
                # 上一轮URL与当前URL相同，或无上一轮记录 → 使用当前URL
                record_url = current_url
                self.logger.info(
                    f"[答题URL] 记录当前页面URL: {current_url[:120]} (rule_id={rule_id}, "
                    f"prev_url={'相同' if prev_url == current_url else '无记录'})")

            self._pre_quiz_urls[rule_id] = {
                'url': record_url,
                'page': target_page
            }
            return record_url
        except Exception as e:
            self.logger.error(f"[答题URL] 记录URL异常: {e}")
            return ''

    def _find_prev_cycle_url(self, target_page):
        """从上一轮监测周期的URL快照中查找目标页面的URL。

        通过遍历所有页面对比找到目标页面对应的索引，然后查找上一轮的URL。
        返回: 上一轮URL字符串，未找到返回None
        """
        if not self._prev_cycle_page_urls:
            return None

        try:
            all_pages = self._get_all_pages()
            for i, page in enumerate(all_pages):
                if page is target_page:
                    prev_url = self._prev_cycle_page_urls.get(i)
                    if prev_url:
                        self.logger.debug(
                            f"[答题URL] 找到上一轮URL: page_index={i}, url={prev_url[:80]}")
                        return prev_url
                    break
        except Exception as e:
            self.logger.debug(f"[答题URL] 查找上一轮URL异常: {e}")

        return None

    def _snapshot_all_page_urls(self):
        """记录当前所有页面的URL快照（在每轮监测周期开始前调用）。
        用于在quiz弹窗首次出现时获取弹窗出现前的原始URL。
        """
        try:
            all_pages = self._get_all_pages()
            new_snapshot = {}
            for i, page in enumerate(all_pages):
                try:
                    url = self._pw(lambda p=page: p.url) or ''
                    new_snapshot[i] = url
                except Exception:
                    new_snapshot[i] = ''
            self._prev_cycle_page_urls = new_snapshot
            self.logger.debug(
                f"[答题URL] 已快照所有页面URL: {len(new_snapshot)}个页面, "
                f"urls={list(new_snapshot.values())}")
        except Exception as e:
            self.logger.debug(f"[答题URL] 快照页面URL异常: {e}")

    def _navigate_back_after_quiz(self, rule_id, target_page):
        """答题结束后根据记录的URL进行回调跳转，确保用户准确返回原页面。

        核心逻辑：
        1. 从 _pre_quiz_urls 获取答题前记录的原始URL
        2. 获取答题弹窗所在页面的当前URL
        3. 仅当URL发生变化时才执行跳转（避免不必要的页面刷新）
        4. 跳转使用 _pw(page.goto())，确保线程安全
        5. 跳转失败时回退到 _pw(page.go_back())
        6. 无论成功或失败，均清理 _pre_quiz_urls 记录防止内存泄漏

        rule_id: 规则唯一标识
        target_page: 答题弹窗所在的页面对象
        返回: True=成功返回原页面 / False=跳转失败 / None=无需跳转
        """
        recorded_info = self._pre_quiz_urls.pop(rule_id, None)

        if not recorded_info:
            self.logger.debug(f"[答题URL] 无URL记录(rule_id={rule_id})，跳过回调跳转")
            return None

        recorded_url = recorded_info['url']
        recorded_page = recorded_info.get('page')

        try:
            # 确定要检查的页面对象：优先使用记录时的page，若已关闭则用target_page
            check_page = None
            page_source = 'unknown'
            if recorded_page:
                try:
                    if not recorded_page.is_closed():
                        check_page = recorded_page
                        page_source = 'recorded_page'
                except Exception as e:
                    self.logger.debug(f"[答题URL] recorded_page状态检查异常: {e}")
            if check_page is None:
                check_page = target_page
                page_source = 'target_page'

            if check_page is None:
                self.logger.warning("[答题URL] 无可用页面对象，无法执行回调跳转")
                return False

            # 获取当前页面URL
            current_url = ''
            try:
                current_url = self._pw(lambda: check_page.url) or ''
            except Exception as e:
                self.logger.warning(f"[答题URL] 获取当前URL异常: {e}")

            # 详细日志：记录跳转决策的完整上下文
            self.logger.info(
                f"[答题URL] 回调跳转评估:\n"
                f"  rule_id: {rule_id}\n"
                f"  记录URL(目标): {recorded_url[:150]}\n"
                f"  当前URL: {current_url[:150]}\n"
                f"  页面对象来源: {page_source}\n"
                f"  URL是否一致: {current_url == recorded_url}")

            # URL未变化则无需跳转
            if current_url == recorded_url:
                self.logger.info(
                    f"[答题URL] 当前URL与记录一致，无需跳转: {current_url[:100]}")
                return True

            # 检查是否只是hash变化（如从 /page#section 变为 /page），不算真正跳转
            try:
                from urllib.parse import urlparse
                parsed_current = urlparse(current_url)
                parsed_recorded = urlparse(recorded_url)
                if (parsed_current.scheme == parsed_recorded.scheme and
                    parsed_current.netloc == parsed_recorded.netloc and
                    parsed_current.path == parsed_recorded.path and
                    parsed_current.query == parsed_recorded.query):
                    # 仅 fragment 不同，不算页面跳转
                    self.logger.info(
                        f"[答题URL] URL仅fragment变化，无需跳转 "
                        f"(记录: #{parsed_recorded.fragment} → 当前: #{parsed_current.fragment})")
                    return True
            except Exception:
                pass

            self.logger.info(
                f"[答题URL] 检测到URL变化，准备回调跳转:\n"
                f"  记录URL(目标): {recorded_url[:150]}\n"
                f"  当前URL: {current_url[:150]}")

            # 执行跳转策略：优先 go_back()（不重新加载页面，视频不会暂停），
            # go_back 失败时才用 goto()（会重新加载页面）
            navigate_page = check_page

            # 策略1：优先使用 go_back() 回退浏览器历史（最多回退3次）
            max_go_back_attempts = 3
            go_back_success = False

            for attempt in range(1, max_go_back_attempts + 1):
                try:
                    self.logger.info(
                        f"[答题URL] 执行 go_back() (第{attempt}次)...")
                    self._pw(lambda: navigate_page.go_back(
                        wait_until='domcontentloaded', timeout=10000))
                    back_url = ''
                    try:
                        back_url = self._pw(lambda: navigate_page.url) or ''
                    except Exception:
                        pass

                    # 检查是否回到了目标URL
                    if back_url == recorded_url:
                        self.logger.info(
                            f"[答题URL] go_back回退成功(第{attempt}次): {back_url[:100]}")
                        go_back_success = True
                        break

                    # 检查是否回到了课程页（即使URL不完全匹配，只要路径包含课程ID也算成功）
                    from urllib.parse import urlparse, parse_qs
                    try:
                        parsed_back = urlparse(back_url)
                        parsed_recorded = urlparse(recorded_url)
                        # 如果回退到的URL路径包含课程ID，视为成功
                        course_id_match = False
                        recorded_path = parsed_recorded.path
                        back_path = parsed_back.path
                        # 从记录URL中提取课程ID (格式: /study/course/c_XXXX 或 /a_XXXX/study/course/c_XXXX)
                        import re
                        course_ids = re.findall(r'c_[a-f0-9]{20,}', recorded_path)
                        if course_ids:
                            for cid in course_ids:
                                if cid in back_path:
                                    course_id_match = True
                                    break

                        if course_id_match:
                            self.logger.info(
                                f"[答题URL] go_back回退到课程页(第{attempt}次): {back_url[:100]} "
                                f"(课程ID匹配)")
                            go_back_success = True
                            break
                    except Exception:
                        pass

                    self.logger.debug(
                        f"[答题URL] go_back第{attempt}次后URL不匹配: "
                        f"期望≈{recorded_url[:60]}, 实际={back_url[:60]}")

                except Exception as back_err:
                    self.logger.warning(f"[答题URL] go_back第{attempt}次失败: {back_err}")
                    break

            if go_back_success:
                return True

            # 策略2：go_back 未能回到目标页面，使用 goto() 直接导航
            try:
                self.logger.info(
                    f"[答题URL] go_back未能回到目标页面，执行 goto({recorded_url[:100]})...")
                self._pw(lambda: navigate_page.goto(
                    recorded_url, wait_until='domcontentloaded', timeout=15000))
                # 验证跳转后的URL
                after_url = ''
                try:
                    after_url = self._pw(lambda: navigate_page.url) or ''
                except Exception:
                    pass
                self.logger.info(
                    f"[答题URL] goto跳转成功: → 当前={after_url[:80]}")
                return True
            except Exception as goto_err:
                self.logger.error(f"[答题URL] goto跳转也失败: {goto_err}")
                return False

        except Exception as e:
            self.logger.error(f"[答题URL] 回调跳转异常: {e}")
            # 确保清理记录
            if rule_id in self._pre_quiz_urls:
                del self._pre_quiz_urls[rule_id]
            return False

    def _simulate_mouse_click(self, target_page, element, description=''):
        """模拟真实鼠标点击元素，多策略递进确保点击成功。

        策略优先级：
        1. Playwright mouse.click() — 最真实的模拟（含鼠标移动、坐标、事件序列）
        2. element.click() — Playwright 原生点击（自动等待可操作性）
        3. dispatchEvent — 分派 mousedown/mouseup/click 事件序列
        4. evaluate('el.click()') — JS 层面直接调用，兜底方案

        每种策略执行前都会：
        - 等待元素可见（waitFor 可操作性检查）
        - 滚动到元素可视区域
        - 检测并处理元素遮挡

        返回: True=点击成功 / False=所有策略均失败
        """
        if not element:
            return False

        # ---- 预处理：等待可见 + 滚动到可视区 + 检测遮挡 ----
        try:
            # 等待元素变为可操作状态（最多5秒）
            try:
                self._pw(lambda: element.wait_for_element_state('visible', timeout=5000))
            except Exception as e:
                self.logger.debug(f"[模拟点击] 等待元素可见超时: {e}")

            # 滚动到元素可视区域（居中显示）
            self._pw(lambda: element.scroll_into_view_if_needed(timeout=3000))
            time.sleep(0.2)  # 等待滚动动画完成
        except Exception as e:
            self.logger.debug(f"[模拟点击] 滚动到元素失败: {e}")
            # 滚动失败不阻止后续尝试

        # ---- 检测元素是否被遮挡 ----
        is_obscured = False
        try:
            is_obscured = self._pw(lambda: element.evaluate("""el => {
                var rect = el.getBoundingClientRect();
                var cx = rect.left + rect.width / 2;
                var cy = rect.top + rect.height / 2;
                var topEl = document.elementFromPoint(cx, cy);
                return topEl !== el && !el.contains(topEl);
            }"""))
            if is_obscured:
                self.logger.info(f"[模拟点击] 元素被遮挡{f' ({description})' if description else ''}，尝试移除遮挡层")
                # 尝试移除常见遮挡层（弹窗遮罩、loading遮罩等）
                self._pw(lambda: target_page.evaluate("""() => {
                    var overlays = document.querySelectorAll(
                        '.modal-backdrop, .overlay, .mask, .loading-mask, ' +
                        '[class*="modal-backdrop"], [class*="overlay"], [class*="mask"]'
                    );
                    overlays.forEach(function(el) {
                        if (el.style) el.style.display = 'none';
                    });
                    // 同时移除可能的 pointer-events 限制
                    var body = document.body;
                    if (body.style.pointerEvents === 'none') {
                        body.style.pointerEvents = '';
                    }
                }"""))
                time.sleep(0.3)
                # 重新检查遮挡
                is_obscured = self._pw(lambda: element.evaluate("""el => {
                    var rect = el.getBoundingClientRect();
                    var cx = rect.left + rect.width / 2;
                    var cy = rect.top + rect.height / 2;
                    var topEl = document.elementFromPoint(cx, cy);
                    return topEl !== el && !el.contains(topEl);
                }"""))
        except Exception as e:
            self.logger.debug(f"[模拟点击] 遮挡检测异常: {e}")

        # ---- 策略1: Playwright mouse.click() — 最真实的鼠标模拟 ----
        if not is_obscured:
            try:
                box = self._pw(lambda: element.bounding_box())
                if box and box['width'] > 0 and box['height'] > 0:
                    cx = box['x'] + box['width'] / 2
                    cy = box['y'] + box['height'] / 2
                    self._pw(lambda: target_page.mouse.click(cx, cy))
                    self.logger.info(f"[模拟点击] 策略1(mouse.click)成功{f': {description}' if description else ''}")
                    return True
            except Exception as e:
                self.logger.debug(f"[模拟点击] 策略1(mouse.click)失败: {e}")

        # ---- 策略2: Playwright 原生 element.click() ----
        try:
            self._pw(lambda: element.click(timeout=5000))
            self.logger.info(f"[模拟点击] 策略2(element.click)成功{f': {description}' if description else ''}")
            return True
        except Exception as e:
            self.logger.debug(f"[模拟点击] 策略2(element.click)失败: {e}")

        # ---- 策略3: dispatchEvent — 分派完整鼠标事件序列 ----
        try:
            self._pw(lambda: element.evaluate("""el => {
                var events = ['mousedown', 'mouseup', 'click'];
                events.forEach(function(type) {
                    var rect = el.getBoundingClientRect();
                    var evt = new MouseEvent(type, {
                        bubbles: true,
                        cancelable: true,
                        view: window,
                        clientX: rect.left + rect.width / 2,
                        clientY: rect.top + rect.height / 2,
                        button: 0
                    });
                    el.dispatchEvent(evt);
                });
            }"""))
            self.logger.info(f"[模拟点击] 策略3(dispatchEvent)成功{f': {description}' if description else ''}")
            return True
        except Exception as e:
            self.logger.debug(f"[模拟点击] 策略3(dispatchEvent)失败: {e}")

        # ---- 策略4: evaluate('el.click()') — JS 层面兜底 ----
        try:
            self._pw(lambda: element.evaluate('el => el.click()'))
            self.logger.info(f"[模拟点击] 策略4(evaluate.click)成功{f': {description}' if description else ''}")
            return True
        except Exception as e:
            self.logger.debug(f"[模拟点击] 策略4(evaluate.click)失败: {e}")

        self.logger.warning(f"[模拟点击] 所有策略均失败{f' ({description})' if description else ''}")
        return False

    def _locate_submit_button(self, target_page, submit_info):
        """定位提交按钮元素，支持多种查找策略。

        查找策略（按优先级）：
        1. 通过 cssPath 精确路径定位（扫描时生成的唯一CSS路径）
        2. 通过 CSS ID 精确匹配
        3. 通过 CSS class 匹配
        4. 通过按钮文本内容精确匹配
        5. 通过 XPath 语义匹配（提交/确定/确认等关键词）
        6. 通过 type="submit" 属性匹配

        每种策略找到后，会验证元素可见性，跳过 disabled 按钮。

        返回: (element, strategy_name) 或 (None, '')
        """
        # 辅助：检查按钮是否禁用
        def _is_disabled(el):
            try:
                return self._pw(lambda: el.evaluate(
                    'el => el.disabled || el.getAttribute("aria-disabled") === "true" || el.classList.contains("disabled")'
                ))
            except Exception:
                return False

        # 策略1: cssPath 精确路径（扫描时生成，最可靠）
        css_path = submit_info.get('cssPath', '')
        if css_path:
            try:
                btn = self._pw(lambda: target_page.query_selector(css_path))
                if btn and not _is_disabled(btn):
                    return btn, f'cssPath'
                elif btn:
                    self.logger.debug(f"[答题提交] cssPath找到按钮但已禁用，跳过")
            except Exception:
                pass

        # 策略2: CSS ID 匹配
        sel_id = submit_info.get('id', '')
        if sel_id:
            try:
                btn = self._pw(lambda: target_page.query_selector(f'#{sel_id}'))
                if btn and not _is_disabled(btn):
                    return btn, f'id=#{sel_id}'
            except Exception:
                pass

        # 策略3: CSS class 匹配
        sel_class = submit_info.get('className', '')
        if sel_class:
            try:
                first_class = sel_class.split()[0]
                btn = self._pw(lambda: target_page.query_selector(f'.{first_class}'))
                if btn and not _is_disabled(btn):
                    return btn, f'class={first_class}'
            except Exception:
                pass

        # 策略4: 按钮文本精确匹配
        btn_text = submit_info.get('text', '')
        if btn_text:
            try:
                btn = self._pw(lambda: target_page.query_selector(
                    f'button:has-text("{btn_text}"), '
                    f'input[type="submit"][value*="{btn_text}"], '
                    f'[role="button"]:has-text("{btn_text}")'
                ))
                if btn and not _is_disabled(btn):
                    return btn, f'text="{btn_text[:20]}"'
            except Exception:
                pass

        # 策略5: XPath 语义匹配（提交/确定/确认等关键词）
        try:
            btn = self._pw(lambda: target_page.locator(
                'xpath=//button[contains(text(),"提交") or contains(text(),"确定") '
                'or contains(text(),"确认") or contains(text(),"Submit") '
                'or contains(text(),"OK") or contains(text(),"下一题")]'
                '| //input[@type="submit"]'
            ).first.element_handle(timeout=3000))
            if btn and not _is_disabled(btn):
                return btn, 'xpath-semantic'
        except Exception:
            pass

        # 策略6: type="submit" 属性
        try:
            btn = self._pw(lambda: target_page.query_selector('button[type="submit"], input[type="submit"]'))
            if btn and not _is_disabled(btn):
                return btn, 'type=submit'
        except Exception:
            pass

        return None, ''

    def _click_submit(self, target_page, submit_info):
        """点击提交按钮。返回 True/False

        改进点：
        - 使用 _locate_submit_button 多策略定位按钮
        - 使用 _simulate_mouse_click 模拟真实鼠标点击
        - 支持异步加载等待（等待按钮出现）
        - 处理元素遮挡问题
        - 保留回退到 evaluate('el.click()') 的兜底能力
        """
        if not submit_info:
            return False
        try:
            # 阶段1: 直接定位按钮
            btn, strategy = self._locate_submit_button(target_page, submit_info)

            # 阶段2: 如果直接定位失败，等待异步加载后重试
            if not btn:
                self.logger.info(f"[答题提交] 首次未定位到按钮，等待异步加载...")
                time.sleep(1.0)
                # 重新扫描页面元素（可能异步加载了新按钮）
                quiz_info = self._scan_quiz_elements(target_page)
                new_submit_btns = quiz_info.get('submitBtns', []) if quiz_info else []
                if new_submit_btns:
                    submit_info = new_submit_btns[0]
                    btn, strategy = self._locate_submit_button(target_page, submit_info)

            if not btn:
                # 阶段3: 终极兜底 — 用 JS 全局搜索所有可点击的提交元素
                self.logger.info(f"[答题提交] 定位按钮失败，使用JS全局搜索...")
                btn = self._pw(lambda: target_page.evaluate("""() => {
                    var selectors = [
                        'button[type="submit"]',
                        'input[type="submit"]',
                        '.submit-btn', '.btn-submit', '#submit',
                        'button'
                    ];
                    for (var i = 0; i < selectors.length; i++) {
                        var els = document.querySelectorAll(selectors[i]);
                        for (var j = 0; j < els.length; j++) {
                            var el = els[j];
                            var txt = (el.textContent || el.value || '').trim();
                            // 优先找包含提交关键词的可见按钮
                            if (/提交|确定|确认|submit|ok|下一题/i.test(txt) && el.offsetWidth > 0) {
                                return el;
                            }
                        }
                    }
                    // 回退：找任何可见的 submit 类型按钮
                    var submits = document.querySelectorAll('button[type="submit"], input[type="submit"]');
                    for (var k = 0; k < submits.length; k++) {
                        if (submits[k].offsetWidth > 0) return submits[k];
                    }
                    return null;
                }"""))
                if btn:
                    strategy = 'js-global-search'
                else:
                    self.logger.warning(f"[答题提交] 所有策略均未找到提交按钮")
                    return False

            self.logger.info(f"[答题提交] 定位到按钮(策略={strategy}): "
                        f"text={submit_info.get('text', '')[:30]}")

            # 使用模拟鼠标点击
            description = f"提交按钮({strategy}): {submit_info.get('text', '')[:20]}"
            success = self._simulate_mouse_click(target_page, btn, description)

            if success:
                self.logger.info(f"[答题提交] ✅ 点击成功(策略={strategy})")
            else:
                self.logger.warning(f"[答题提交] ❌ 点击失败(策略={strategy})")

            return success

        except Exception as e:
            self.logger.error(f"[答题提交] 点击提交按钮异常: {e}")
            return False

    def _handle_quiz_popup(self, rule, target_page, exclude_indices=None):
        """处理答题弹窗：逐一尝试每个选项直到找到正确答案

        核心策略：
        1. 扫描弹窗获取选项和提交按钮
        2. 根据选项数量生成尝试顺序：
           - 有已知正确答案且不在排除列表中 → 优先尝试该选项
           - 否则按顺序逐一尝试，跳过 exclude_indices 中的选项
        3. 每次尝试前重置答题状态（清除所有已选中选项），避免上一题记忆干扰
        4. 每次尝试后通过「弹窗是否消失」判断成功（最可靠指标）
        5. 答题错误时提前返回，由弹窗监听循环下轮重试（传入 exclude_indices）

        Args:
            rule: 弹窗规则字典
            target_page: 目标页面
            exclude_indices: 已尝试失败的选项索引列表，这些选项将被跳过

        返回 {'success': bool, 'attempts': int, 'correct_index': int,
               'error_msg': str, 'submit_verified': bool, 'tried_indices': list}
        """
        # 检查自动答题开关
        if not self.auto_answer_enabled:
            # 彻底关闭日志输出
            return {
                'success': False, 'attempts': 0, 'correct_index': -1,
                'error_msg': 'auto_answer_disabled', 'submit_verified': False, 'tried_indices': []
            }

        keyword = rule.get('keyword', '')
        correct_answer = rule.get('correct_answer', '')   # 已知正确答案（可选）
        max_retries = int(rule.get('max_retries', 5))      # 最大尝试次数
        selector = rule.get('selector', '')
        action = rule.get('action', 'auto_answer')

        # 答题前记录当前页面URL（用于答题结束后回调跳转）
        rule_id = f"quiz:{keyword}:{selector}"
        self._record_pre_quiz_url(rule_id, target_page)

        result = {
            'success': False, 'attempts': 0, 'correct_index': -1,
            'error_msg': '', 'submit_verified': False, 'tried_indices': []
        }
        try:
            # 1. 扫描答题元素
            quiz_info = self._scan_quiz_elements(target_page)

            options = quiz_info.get('radios', []) or quiz_info.get('checkboxes', [])
            submit_btns = quiz_info.get('submitBtns', [])

            if len(options) < 2:
                self.logger.info("[答题] 未发现足够选项(<2)，回退为单选题处理")
                radio_result = self._handle_radio_popup(rule, target_page)
                result = {'success': bool(radio_result), 'attempts': 1,
                          'correct_index': 0, 'error_msg': '', 'submit_verified': False,
                          'tried_indices': []}
                return result

            visible_options = [o for o in options if o['visible'] and not o['disabled']]
            if not visible_options:
                self.logger.info("[答题] 无可见选项，跳过")
                result['error_msg'] = '无可见选项'
                return result

            self.logger.info(
                f"[答题] 发现 {len(visible_options)} 个选项，"
                f"{len(submit_btns)} 个提交按钮，开始智能答题: "
                f"{keyword[:30] if keyword else '(无关键词)'}")

            # 2. 构建尝试顺序
            #    优先尝试 correct_answer 匹配的选项（除非在 exclude_indices 中）
            #    其余选项按顺序排列，跳过 exclude_indices
            tried_set = set(exclude_indices or [])
            attempt_order = []  # [(opt_idx, opt), ...]

            if correct_answer:
                # 先找 correct_answer 匹配的选项
                correct_idx = None
                for i, opt in enumerate(visible_options):
                    opt_val = opt.get('value', '')
                    opt_label = opt.get('label', '')
                    if correct_answer in opt_val or correct_answer in opt_label:
                        if i not in tried_set:
                            correct_idx = i
                        else:
                            self.logger.info(
                                f"[答题] 已知正确答案匹配选项[{i}]但已被排除(之前尝试失败)，"
                                f"将尝试其他选项")
                        break

                # correct_answer 匹配的选项优先
                if correct_idx is not None:
                    attempt_order.append((correct_idx, visible_options[correct_idx]))

                # 其余选项按顺序
                for i, opt in enumerate(visible_options):
                    if i not in tried_set and i != correct_idx:
                        attempt_order.append((i, opt))
            else:
                # 无 correct_answer，按顺序尝试
                for i, opt in enumerate(visible_options):
                    if i not in tried_set:
                        attempt_order.append((i, opt))

            if not attempt_order:
                self.logger.warning("[答题] 所有选项均已被排除，无法继续")
                result['error_msg'] = '所有选项均已被排除'
                result['tried_indices'] = list(tried_set)
                return result

            self.logger.info(
                f"[答题] 尝试顺序: {[f'选项[{i}]' for i, _ in attempt_order]}"
                + (f"（跳过已尝试: {list(tried_set)}）" if tried_set else ""))

            # 3. 逐一尝试每个选项
            attempts = 0
            tried_indices = list(tried_set)

            for opt_idx, opt in attempt_order:
                if attempts >= max_retries:
                    self.logger.warning(f"[答题] 达到最大尝试次数({max_retries})，停止")
                    break

                attempts += 1
                label_text = opt.get('label', '')[:40]

                # ★ 关键步骤：每次尝试前重置答题状态，清除所有已选中的选项
                self._reset_quiz_selection(target_page, visible_options)
                time.sleep(0.3)

                # 点击目标选项
                option_ok = self._click_option_with_verify(
                    target_page, opt, opt_idx, max_retries=2)
                tried_indices.append(opt_idx)

                if option_ok:
                    self.logger.info(
                        f"[答题] 尝试第{attempts}次: 选项[{opt_idx}] "
                        f"{label_text} (已验证选中)")
                else:
                    self.logger.warning(
                        f"[答题] 尝试第{attempts}次: 选项[{opt_idx}] "
                        f"{label_text} (⚠️选中验证失败，仍继续提交)")

                # 提交答案
                submit_ok = False
                if submit_btns:
                    submit_ok = self._click_submit(target_page, submit_btns[0])
                    if not submit_ok:
                        # 重新扫描提交按钮
                        quiz_info_retry = self._scan_quiz_elements(target_page)
                        new_btns = quiz_info_retry.get('submitBtns', [])
                        if new_btns:
                            submit_btns = new_btns
                            submit_ok = self._click_submit(target_page, submit_btns[0])
                else:
                    submit_ok = self._try_implicit_submit(target_page)

                if not submit_ok:
                    self.logger.warning(f"[答题] 第{attempts}次提交失败，跳过此选项")
                    continue

                # 等待页面响应
                time.sleep(2.0)

                # ★ 核心验证：检查弹窗是否消失（最可靠的成功指标）
                quiz_disappeared = self._check_quiz_disappeared(target_page)

                if quiz_disappeared:
                    self.logger.info(
                        f"[答题] ✅ 第{attempts}次尝试成功! "
                        f"选项[{opt_idx}] {label_text} (弹窗已消失)")
                    result = {
                        'success': True, 'attempts': attempts,
                        'correct_index': opt_idx,
                        'error_msg': '', 'submit_verified': True,
                        'tried_indices': tried_indices
                    }
                    return result

                # 弹窗仍在 → 答案错误，提前返回让弹窗监听循环下轮重试
                self.logger.info(
                    f"[答题] ❌ 第{attempts}次尝试后弹窗仍在，"
                    f"选项[{opt_idx}] {label_text} 错误，提前返回等待重试")
                result = {
                    'success': False, 'attempts': attempts,
                    'correct_index': -1,
                    'error_msg': f'选项[{opt_idx}]错误(弹窗仍在)',
                    'submit_verified': False,
                    'tried_indices': tried_indices
                }
                return result

            # 所有选项都试过了仍未成功
            error_summary = f"所有 {len(attempt_order)} 个可尝试选项均已尝试(共{attempts}次)"
            self.logger.warning(f"[答题] {error_summary}，未找到正确答案")
            result = {
                'success': False, 'attempts': attempts,
                'correct_index': -1,
                'error_msg': error_summary, 'submit_verified': False,
                'tried_indices': tried_indices
            }
            return result

        except Exception as e:
            self.logger.error(f"[答题] 处理异常: {e}")
            result = {
                'success': False, 'attempts': 0, 'correct_index': -1,
                'error_msg': f'异常: {e}', 'submit_verified': False,
                'tried_indices': list(exclude_indices) if exclude_indices else []
            }
            return result
        finally:
            # 无论答题成功/失败/异常，始终尝试回调跳转到原页面
            self._navigate_back_after_quiz(rule_id, target_page)

    def _reset_quiz_selection(self, target_page, visible_options):
        """重置答题状态：清除所有已选中的选项，确保每次尝试从干净状态开始。

        对于 radio 按钮，通过 JS 将 checked 设为 false 并触发 change 事件；
        对于 checkbox，点击已选中的选项取消选中；
        同时清除页面上的选中态 CSS class。

        Args:
            target_page: 目标页面
            visible_options: 可见选项列表（来自 _scan_quiz_elements）
        """
        try:
            # 方法1：通过 JS 清除所有 radio/checkbox 的选中状态
            cleared = self._pw(lambda: target_page.evaluate("""() => {
                var cleared = 0;
                // 清除 radio
                var radios = document.querySelectorAll('input[type="radio"]');
                for (var i = 0; i < radios.length; i++) {
                    if (radios[i].checked) {
                        radios[i].checked = false;
                        radios[i].dispatchEvent(new Event('change', {bubbles: true}));
                        cleared++;
                    }
                }
                // 清除 checkbox
                var checkboxes = document.querySelectorAll('input[type="checkbox"]');
                for (var j = 0; j < checkboxes.length; j++) {
                    if (checkboxes[j].checked) {
                        checkboxes[j].checked = false;
                        checkboxes[j].dispatchEvent(new Event('change', {bubbles: true}));
                        cleared++;
                    }
                }
                // 清除选中态 CSS class（常见 UI 框架）
                var selectedEls = document.querySelectorAll(
                    '.checked, .selected, .active, .on, .current');
                for (var k = 0; k < selectedEls.length; k++) {
                    var el = selectedEls[k];
                    // 仅清除与 quiz 容器相关的选中态
                    var parent = el.closest('label, .option, .quiz, .exam, form, dialog, [role="dialog"]');
                    if (parent) {
                        el.classList.remove('checked', 'selected', 'active', 'on', 'current');
                    }
                }
                return cleared;
            }"""))
            if cleared and cleared > 0:
                self.logger.debug(f"[答题重置] 已清除 {cleared} 个选中状态")
        except Exception as e:
            self.logger.debug(f"[答题重置] 清除选中状态异常(可忽略): {e}")

    def _check_quiz_disappeared(self, target_page):
        """检查答题弹窗是否已消失（最可靠的答题成功指标）。

        检测方式：
        1. 页面中不再有可见的 radio/checkbox 选项组（>=2个）
        2. 不再有可见的提交按钮
        3. 弹窗容器(dialog/modal)已不可见

        返回: True=弹窗已消失(答题成功) / False=弹窗仍在(答案错误或未生效)
        """
        try:
            disappeared = self._pw(lambda: target_page.evaluate("""() => {
                // 检查1: 是否还有可见的 radio/checkbox 选项
                var radios = document.querySelectorAll('input[type="radio"]');
                var visibleRadios = 0;
                for (var i = 0; i < radios.length; i++) {
                    if (radios[i].offsetParent !== null || radios[i].closest('label[offsetWidth > 0]')) {
                        visibleRadios++;
                    }
                }
                // 也检查 label 关联的 radio
                var labels = document.querySelectorAll('label');
                for (var j = 0; j < labels.length; j++) {
                    var input = labels[j].querySelector('input[type="radio"], input[type="checkbox"]');
                    if (input && labels[j].offsetWidth > 0) {
                        // label 可见
                    }
                }

                if (visibleRadios >= 2) {
                    return false;  // 还有选项可见，弹窗未消失
                }

                // 检查2: 是否还有提交按钮可见
                var submitBtns = document.querySelectorAll(
                    'button[type="submit"], input[type="submit"], ' +
                    'button:has(> :only-child), .submit, .btn-submit, ' +
                    'a[onclick*="submit"], a[onclick*="Submit"]'
                );
                for (var k = 0; k < submitBtns.length; k++) {
                    var btn = submitBtns[k];
                    if (btn.offsetWidth > 0 && btn.offsetHeight > 0) {
                        var btnText = (btn.innerText || btn.value || '').trim();
                        if (btnText.indexOf('提交') >= 0 || btnText.indexOf('确定') >= 0 ||
                            btnText.toLowerCase().indexOf('submit') >= 0) {
                            return false;  // 提交按钮仍可见
                        }
                    }
                }

                // 检查3: dialog/modal 弹窗是否已关闭
                var dialogs = document.querySelectorAll(
                    'dialog[open], .modal.in, .modal.show, .popup.show, ' +
                    '[role="dialog"][aria-hidden="false"], [role="dialog"]:not([aria-hidden="true"])'
                );
                for (var m = 0; m < dialogs.length; m++) {
                    if (dialogs[m].offsetWidth > 0) {
                        return false;  // 弹窗容器仍可见
                    }
                }

                return true;  // 弹窗已消失
            }"""))

            return bool(disappeared)

        except Exception as e:
            self.logger.debug(f"[答题验证] 弹窗消失检测异常: {e}")
            return False

    def _click_option_with_verify(self, target_page, option_info, option_index, max_retries=3):
        """点击选项并验证是否选中，失败时重试。

        max_retries: 最大重试次数
        返回: True=选项已选中 / False=选中失败
        """
        for attempt in range(1, max_retries + 1):
            # 点击选项
            self._click_option(target_page, option_info, option_index)

            # 短暂等待（某些UI需要动画完成）
            time.sleep(0.3)

            # 验证选中状态
            if self._verify_option_selected(target_page, option_info, max_wait=1.5):
                if attempt > 1:
                    self.logger.info(
                        f"[答题] 选项选中成功(第{attempt}次重试): "
                        f"index={option_index}")
                return True

            self.logger.debug(
                f"[答题] 选项选中验证失败(第{attempt}次): "
                f"index={option_index}, "
                f"name={option_info.get('name', '')}, "
                f"value={option_info.get('value', '')}")

        self.logger.warning(
            f"[答题] 选项选中失败(重试{max_retries}次): "
            f"index={option_index}, label={option_info.get('label', '')[:30]}")
        return False

    def _try_implicit_submit(self, target_page):
        """当没有显式提交按钮时，尝试隐式提交方式。

        方式：
        1. 按 Enter 键提交表单
        2. 触发 form 的 submit 事件
        3. 查找隐藏的提交按钮

        返回: True=尝试了某种提交 / False=无法提交
        """
        try:
            # 方式1: 按 Enter 键
            self._pw(lambda: target_page.keyboard.press('Enter'))
            self.logger.info("[答题] 尝试按Enter键提交")
            time.sleep(0.5)
            return True
        except Exception:
            pass

        try:
            # 方式2: 触发 form submit 事件
            submitted = self._pw(lambda: target_page.evaluate("""() => {
                var form = document.querySelector('form');
                if (form) {
                    // 使用 submit() 而非 requestSubmit() 以绕过验证
                    form.submit();
                    return true;
                }
                // 查找隐藏的提交按钮
                var hiddenSubmit = document.querySelector(
                    'input[type="submit"][style*="display: none"], ' +
                    'input[type="submit"][style*="display:none"], ' +
                    'button[type="submit"][style*="display: none"]'
                );
                if (hiddenSubmit) {
                    hiddenSubmit.click();
                    return true;
                }
                return false;
            }"""))
            if submitted:
                self.logger.info("[答题] 通过隐式方式提交成功")
                return True
        except Exception as e:
            self.logger.debug(f"[答题] 隐式提交失败: {e}")

        self.logger.warning("[答题] 无法执行隐式提交")
        return False

    def _click_option(self, target_page, option_info, option_index):
        """点击一个选项（radio 或 checkbox）。
        优先点击父级 label（兼容 bindCheckboxRadioSimulate 等自定义 UI），
        如果 input 被隐藏则用 evaluate 触发 click 事件。
        """
        try:
            opt_id = option_info.get('id', '')
            opt_value = option_info.get('value', '')
            opt_name = option_info.get('name', '')

            # 策略1：通过 value + name 定位，点击对应的 label（最可靠）
            if opt_name and opt_value:
                try:
                    # 找到对应的 input，然后点击其父级 label
                    clicked = self._pw(lambda: target_page.evaluate("""(params) => {
                        var input = document.querySelector(
                            'input[type="radio"][name="' + params.name + '"][value="' + params.value + '"]');
                        if (!input) input = document.querySelector(
                            'input[type="checkbox"][name="' + params.name + '"][value="' + params.value + '"]');
                        if (!input) return false;
                        // 优先点击包含此 input 的 label
                        var label = input.closest('label');
                        if (label && label.offsetWidth > 0) {
                            label.click();
                            return true;
                        }
                        // 回退：直接点击 input（触发 change 事件）
                        input.click();
                        return true;
                    }""", {'name': opt_name, 'value': opt_value}))
                    if clicked:
                        self.logger.debug(f"[答题] 点击选项(name={opt_name}, value={opt_value})")
                        return True
                except Exception:
                    pass

            # 策略2：通过 id 定位
            if opt_id:
                el = self._pw(lambda: target_page.query_selector(f'#{opt_id}'))
                if el:
                    # 点击父级 label 而非隐藏的 input
                    label_el = self._pw(lambda: target_page.query_selector(f'label[for="{opt_id}"]'))
                    if label_el:
                        self._pw(lambda: label_el.evaluate('el => el.click()'))
                        self.logger.debug(f"[答题] 点击选项label(id={opt_id})")
                    else:
                        self._pw(lambda: el.evaluate('el => el.click()'))
                        self.logger.debug(f"[答题] 点击选项input(id={opt_id})")
                    return True

            # 策略3：按 index 定位，点击 label
            tag_name = 'input[type="radio"]' if option_info.get('name') else 'input[type="checkbox"]'
            try:
                # 用 JS 直接按 index 点击 label
                clicked = self._pw(lambda: target_page.evaluate("""(params) => {
                        var inputs = document.querySelectorAll(params.tag);
                        if (params.index >= inputs.length) return false;
                        var input = inputs[params.index];
                        var label = input.closest('label');
                        if (label && label.offsetWidth > 0) {
                            label.click();
                            return true;
                        }
                        input.click();
                        return true;
                    }""", {'tag': tag_name, 'index': option_index}))
                if clicked:
                    self.logger.debug(f"[答题] 点击选项(index={option_index})")
                    return True
            except Exception:
                pass

            # 策略4：用 label 文本匹配
            label_text = option_info.get('label', '')
            if label_text:
                all_labels = self._pw(lambda: target_page.query_selector_all('label'))
                for lbl in all_labels:
                    lbl_txt = (self._pw(lambda: lbl.text_content()) or '').strip()
                    if label_text in lbl_txt or lbl_txt in label_text:
                        self._pw(lambda: lbl.evaluate('el => el.click()'))
                        self.logger.debug(f"[答题] 点击label: {lbl_txt[:30]}")
                        return True

            self.logger.warning(f"[答题] 无法点击选项: {option_info}")
            return False
        except Exception as e:
            self.logger.error(f"[答题] 点击选项失败: {e}")
            return False

    def _verify_option_selected(self, target_page, option_info, max_wait=3.0):
        """验证选项是否已被成功选中。

        通过多种方式检查选中状态：
        1. 检查 input.checked 属性
        2. 检查父级 label 是否有选中态 CSS class
        3. 检查 aria-checked 属性

        max_wait: 最长等待时间（秒），会在此期间重试检查
        返回: True=已选中 / False=未选中
        """
        opt_id = option_info.get('id', '')
        opt_name = option_info.get('name', '')
        opt_value = option_info.get('value', '')

        deadline = time.time() + max_wait
        while time.time() < deadline:
            try:
                checked = self._pw(lambda: target_page.evaluate("""(params) => {
                    var input = null;
                    if (params.id) {
                        input = document.getElementById(params.id);
                    }
                    if (!input && params.name && params.value) {
                        input = document.querySelector(
                            'input[type="radio"][name="' + params.name + '"][value="' + params.value + '"]'
                        );
                        if (!input) input = document.querySelector(
                            'input[type="checkbox"][name="' + params.name + '"][value="' + params.value + '"]'
                        );
                    }
                    if (!input) return false;

                    // 检查1: input.checked
                    if (input.checked) return true;

                    // 检查2: 父级/关联 label 的选中态 class
                    var label = input.closest('label') ||
                                document.querySelector('label[for="' + input.id + '"]');
                    if (label) {
                        var cls = label.className || '';
                        if (/active|selected|checked|current|on/i.test(cls)) return true;
                        // 检查 aria-checked
                        if (label.getAttribute('aria-checked') === 'true') return true;
                    }

                    // 检查3: input 自身的 aria-checked
                    if (input.getAttribute('aria-checked') === 'true') return true;

                    return false;
                }""", {'id': opt_id, 'name': opt_name, 'value': opt_value}))

                if checked:
                    self.logger.debug(f"[答题验证] 选项已选中: id={opt_id}, value={opt_value}")
                    return True

                # 短暂等待后重试
                time.sleep(0.3)

            except Exception as e:
                self.logger.debug(f"[答题验证] 验证选项选中状态异常: {e}")
                time.sleep(0.3)

        self.logger.warning(
            f"[答题验证] 选项未选中(超时{max_wait}s): "
            f"id={opt_id}, name={opt_name}, value={opt_value}")
        return False

    def _verify_submit_result(self, target_page, before_url='', max_wait=5.0):
        """验证提交后的结果。

        检查维度：
        1. URL 变化（表单提交可能导航到新页面）
        2. 页面文字变化（成功/失败提示）
        3. DOM 变化（弹窗消失、新内容出现）
        4. 网络请求拦截（后端 API 响应）

        返回: {
            'submitted': bool,   — 是否确认提交已发出
            'success': bool,     — 提交是否成功
            'error_msg': str,    — 错误消息（如有）
            'page_changed': bool — 页面是否发生了变化
        }
        """
        result = {
            'submitted': False,
            'success': False,
            'error_msg': '',
            'page_changed': False
        }

        try:
            # 获取提交后的页面状态
            current_url = ''
            try:
                current_url = self._pw(lambda: target_page.url) or ''
            except Exception:
                pass

            page_changed = (current_url != before_url)
            result['page_changed'] = page_changed

            # 检查页面文字中的成功/失败提示
            page_feedback = self._pw(lambda: target_page.evaluate("""() => {
                var text = (document.body.innerText || '').substring(0, 2000);

                // 成功关键词
                var successKw = ['回答正确', '恭喜', '答对了', '正确', '通过',
                                 'completed', 'success', 'correct', '完成'];
                for (var i = 0; i < successKw.length; i++) {
                    if (text.indexOf(successKw[i]) >= 0) {
                        return {type: 'success', keyword: successKw[i]};
                    }
                }

                // 失败关键词
                var failKw = ['错误', '回答错误', '答错了', '不正确', 'wrong',
                              'incorrect', 'fail', '请选择', '请作答', '未选择',
                              '请先选择', '不能为空'];
                for (var j = 0; j < failKw.length; j++) {
                    if (text.indexOf(failKw[j]) >= 0) {
                        return {type: 'error', keyword: failKw[j]};
                    }
                }

                // 检查是否有红色错误提示元素
                var errorEls = document.querySelectorAll(
                    '.error, .wrong, .incorrect, .alert-danger, .toast-error, ' +
                    '[style*="color: red"], [style*="color:red"]'
                );
                for (var k = 0; k < errorEls.length; k++) {
                    if (errorEls[k].offsetHeight > 0 && errorEls[k].innerText.trim()) {
                        return {type: 'error', keyword: errorEls[k].innerText.trim().substring(0, 50)};
                    }
                }

                return {type: 'unknown', keyword: ''};
            }"""))

            fb_type = page_feedback.get('type', 'unknown') if page_feedback else 'unknown'
            fb_keyword = page_feedback.get('keyword', '') if page_feedback else ''

            if fb_type == 'success':
                result['submitted'] = True
                result['success'] = True
                self.logger.info(f"[答题验证] 提交成功(检测到: {fb_keyword})")
            elif fb_type == 'error':
                result['submitted'] = True
                result['success'] = False
                result['error_msg'] = fb_keyword
                self.logger.info(f"[答题验证] 提交失败(检测到: {fb_keyword})")
            else:
                # 没有明确的成功/失败提示，但页面发生了变化，可能是提交成功
                if page_changed:
                    result['submitted'] = True
                    result['success'] = True
                    self.logger.info("[答题验证] 提交可能成功(URL已变化)")
                else:
                    # 页面没变化也没提示，可能是提交根本没发出
                    result['submitted'] = False
                    result['success'] = False
                    result['error_msg'] = '无提交响应'
                    self.logger.warning("[答题验证] 未检测到提交响应(页面无变化且无提示)")

        except Exception as e:
            self.logger.error(f"[答题验证] 验证提交结果异常: {e}")
            result['error_msg'] = str(e)

        return result

    # ================================================================
    #  自定义弹窗检测与处理
    # ================================================================
    def check_custom_popup(self):
        try:
            for rule in self.popup_rules:
                rule_type = rule.get('type', 'custom')

                # 处理所有 DOM 弹窗类型
                if rule_type not in ('custom', 'radio', 'quiz', 'layer'):
                    continue

                keyword = rule.get('keyword', '')
                selector = rule.get('selector', '')
                action = rule.get('action', 'click')
                tab_index = rule.get('tab_index', -1)

                if not selector and rule_type not in ('radio', 'quiz'):
                    continue

                # 切换到目标标签页
                target_page = self._get_target_page(tab_index)

                try:
                    # 临时切换 page 以便在目标标签页中查询
                    original_page = None
                    if tab_index >= 0 and self.browser and target_page is not self.page:
                        original_page = self.page
                        self.page = target_page

                    # 单选题弹窗处理
                    if rule_type == 'radio':
                        # 对于 radio 类型，先检测是否存在可见的 radio 选项
                        radios = self._pw(lambda: target_page.query_selector_all('input[type="radio"]'))
                        visible_radios = [r for r in radios if self._pw(lambda r=r: r.is_visible())]
                        if not visible_radios:
                            # 恢复原始 page
                            if original_page is not None:
                                self.page = original_page
                            continue

                        # 检测防重复：用规则关键词+选择器作为标识
                        rule_id = f"{keyword}:{selector}:{rule.get('option_value', '')}"
                        # 如果有已选中的 radio，说明已处理，跳过
                        any_checked = any(self._pw(lambda r=r: r.is_checked()) for r in visible_radios)
                        if any_checked:
                            # 已有选项被选中，标记为已处理
                            self._last_handled[rule_id] = True
                            if original_page is not None:
                                self.page = original_page
                            continue

                        if self._last_handled.get(rule_id):
                            # 恢复原始 page
                            if original_page is not None:
                                self.page = original_page
                            continue

                        self._handle_radio_popup(rule, target_page)
                        self._last_handled[rule_id] = True

                    # 答题弹窗处理（智能答题 + 错误重试）
                    elif rule_type == 'quiz':
                        quiz_info = self._scan_quiz_elements(target_page)
                        options = quiz_info.get('radios', []) or quiz_info.get('checkboxes', [])
                        visible_options = [o for o in options if o['visible'] and not o['disabled']]

                        if len(visible_options) < 2:
                            # 选项太少，可能不是答题弹窗，跳过
                            if original_page is not None:
                                self.page = original_page
                            continue

                        # 检测防重复
                        rule_id = f"quiz:{keyword}:{selector}"
                        any_checked = any(o.get('checked') for o in visible_options)

                        # 如果所有选项都已被选中且提交成功过，且弹窗未再次出现，跳过
                        # 注意：如果弹窗再次出现，说明之前"成功"是假阳性，不应跳过
                        if any_checked and self._last_handled.get(rule_id):
                            # 再次检查：弹窗是否真的存在（quiz元素仍然可见）
                            # 如果 _quiz_state 存在且成功，但弹窗又出现了，说明是假阳性
                            state = self._quiz_state.get(rule_id)
                            if state and state.get('success'):
                                # 之前标记成功但弹窗仍在 → 假阳性，继续处理
                                self.logger.info(
                                    f"[答题] 选项已选中且已处理，但弹窗仍存在(之前答案错误)，重试: {rule_id}")
                                # 不要 continue，继续处理
                            else:
                                self.logger.debug(
                                    f"[答题] 选项已选中且已处理过，跳过: {rule_id}")
                                if original_page is not None:
                                    self.page = original_page
                                continue

                        # 检查答题状态，决定是否需要处理
                        state = self._quiz_state.get(rule_id)
                        exclude_indices = []  # 之前已尝试失败的选项索引
                        if state:
                            # 已有历史状态
                            if state.get('success'):
                                # 之前标记为成功，但弹窗再次出现 → 说明之前答案是错误的（假阳性）
                                self.logger.info(
                                    f"[答题] 弹窗再次出现，之前标记为成功但实际答案错误，"
                                    f"标记为失败并重试: {rule_id}")
                                state['success'] = False
                                # 将之前"成功"的选项也加入排除列表
                                tried = set(state.get('tried_indices', []))
                                exclude_indices = list(tried)
                            else:
                                # 之前失败过，收集已尝试的选项索引传给 _handle_quiz_popup
                                tried = set(state.get('tried_indices', []))
                                exclude_indices = list(tried)
                            remaining = [i for i, o in enumerate(visible_options) if i not in exclude_indices]
                            if not remaining:
                                # 所有选项均已尝试，跳过
                                if original_page is not None:
                                    self.page = original_page
                                    continue
                            else:
                                self.logger.info(
                                    f"[答题] 检测到答题重试场景，跳过已尝试选项: "
                                    f"{exclude_indices}，剩余可尝试: {remaining}")
                        # state 为 None（首次检测）或有剩余选项 → 继续处理

                        # 如果已有选项选中，_handle_quiz_popup 内部会通过 _reset_quiz_selection 处理
                        # 不在此处判断 any_checked 的提交逻辑，统一交给 _handle_quiz_popup

                        result = self._handle_quiz_popup(rule, target_page,
                                                         exclude_indices=exclude_indices)
                        # 记录状态用于后续重试
                        self._quiz_state[rule_id] = {
                            'tried_indices': list(exclude_indices) + result.get('tried_indices', []),
                            'last_result': result,
                            'attempts': result.get('attempts', 0),
                            'success': result.get('success', False),
                            'error_msg': result.get('error_msg', ''),
                            'submit_verified': result.get('submit_verified', False)
                        }
                        # 如果提交验证失败，不标记为最终成功，允许下轮重试
                        if result.get('success') and not result.get('submit_verified'):
                            self.logger.warning(
                                f"[答题] 提交未经验证，下轮将重试: {rule_id}")
                            self._quiz_state[rule_id]['success'] = False
                            # 不标记 _last_handled，允许下轮重新处理

                        # 仅答题成功且验证通过时标记防重复，失败时允许下轮重试
                        elif result.get('success'):
                            self._last_handled[rule_id] = True

                    # mylayer 弹窗处理：扫描所有标签页，自动点击确定/关闭按钮
                    elif rule_type == 'layer':
                        rule_id = f"layer:{keyword}"
                        if self._last_handled.get(rule_id):
                            if original_page is not None:
                                self.page = original_page
                            continue

                        layer_selector = selector or '.mylayer-btn.type1'
                        layer_handled = False

                        # 扫描所有标签页查找 mylayer 弹窗
                        all_pages = self._get_all_pages()
                        # 优先检查 target_page
                        check_pages = [target_page] + [p for p in all_pages if p is not target_page]

                        for scan_page in check_pages:
                            layer_info = self._check_mylayer_on_page(scan_page)
                            if not layer_info['found']:
                                continue
                            # 答题弹窗：跳过 layer 处理，交给 quiz 规则处理
                            if layer_info.get('is_quiz'):
                                self.logger.debug(f"[MyLayer] layer 规则跳过答题弹窗 (关键词: {keyword})")
                                continue

                            # 尝试通过 browser 方法点击（直接传 page 参数）
                            click_result = self._pw(lambda: self.browser.click_mylayer_confirm(
                                selector=layer_selector, timeout=3, page=scan_page)) if self.browser else None

                            if click_result and click_result.get('success'):
                                self.logger.info(
                                    f"[MyLayer] 已处理弹窗: {click_result['selector']} "
                                    f"(文本: {click_result.get('text', '')[:30]})")
                                layer_handled = True
                            else:
                                # 回退：直接用 JS evaluate 点击找到的按钮
                                btn = layer_info.get('confirm_btn')
                                close = layer_info.get('close_icon')
                                if btn:
                                    self._pw(lambda: btn.evaluate('el => el.click()'))
                                    self.logger.info(f"[MyLayer] 已直接点击确认按钮(evaluate)")
                                    layer_handled = True
                                elif close:
                                    self._pw(lambda: close.evaluate('el => el.click()'))
                                    self.logger.info(f"[MyLayer] 已直接点击关闭图标(evaluate)")
                                    layer_handled = True

                            if layer_handled:
                                break

                        if layer_handled:
                            self._last_handled[rule_id] = True
                        else:
                            # 尝试获取 JS 端的事件记录
                            events = self._pw(lambda: self.browser.get_mylayer_events()) if self.browser else []
                            if events:
                                self.logger.info(
                                    f"[MyLayer] JS端已自动处理弹窗: "
                                    f"{events[-1].get('selector', '')}")
                                self._last_handled[rule_id] = True

                    else:
                        # 通用自定义弹窗处理
                        element = self._query_selector(selector)
                        if element:
                            text_content = self._pw(lambda: element.text_content()) or ''
                            if keyword and keyword in text_content:
                                if action == 'click':
                                    self._pw(lambda: element.click())
                                    self.logger.info(f"已点击自定义弹窗按钮: {selector}, 内容: {text_content[:50]}")
                                elif action == 'close':
                                    self._pw(lambda: element.click())
                                    self.logger.info(f"已关闭自定义弹窗: {selector}")
                                elif action == 'input':
                                    input_text = rule.get('input_text', '')
                                    self._pw(lambda: element.fill(input_text))
                                    self.logger.info(f"已在自定义弹窗输入: {input_text[:30]}")

                    # 恢复原始 page
                    if original_page is not None:
                        self.page = original_page

                except Exception:
                    # 确保恢复原始 page
                    if 'original_page' in dir() and original_page is not None:
                        self.page = original_page
        except Exception as e:
            self.logger.error(f"检测自定义弹窗异常: {e}")

    # ================================================================
    #  自动弹窗检测（无规则匹配时自动判断类型并处理）
    # ================================================================
    def auto_detect_and_handle(self):
        """自动检测页面中的弹窗元素，判断类型后执行预定义逻辑。
        注意：所有跨标签页操作后必须恢复 self.page，避免影响后续逻辑。
        """
        try:
            # 检测 mylayer 弹窗（优先级最高，因为这类弹窗会阻塞操作）
            try:
                if self.browser:
                    # 先检查 JS 自动处理的事件
                    events = self._pw(lambda: self.browser.get_mylayer_events())
                    if events:
                        for evt in events:
                            self.logger.info(
                                f"[MyLayer] 自动处理弹窗: {evt.get('selector', '')} "
                                f"(文本: {evt.get('text', '')[:30]}, 方式: {evt.get('method', '')})")
                        return

                    # 遍历所有标签页检测可见的 mylayer 弹窗
                    all_pages = self._get_all_pages()
                    for page in all_pages:
                        layer_info = self._check_mylayer_on_page(page)
                        if layer_info['found']:
                            # 答题弹窗：跳过 layer 处理，交给 quiz 逻辑
                            if layer_info.get('is_quiz'):
                                self.logger.debug("[MyLayer] 检测到答题弹窗，跳过 layer 自动处理")
                                continue

                            # 在找到弹窗的页面上点击确认（直接传 page 参数）
                            result = self._pw(lambda: self.browser.click_mylayer_confirm(timeout=3, page=page))
                            page_url = ''
                            try:
                                page_url = self._pw(lambda: page.url) or ''
                            except Exception:
                                pass
                            if result and result.get('success'):
                                self.logger.info(
                                    f"[MyLayer] 自动检测并处理弹窗: {result['selector']}")
                                self._fire_callback('handled', {
                                    'popup_type': 'mylayer',
                                    'page_url': page_url,
                                    'details': result.get('selector', '')
                                })
                            else:
                                # 尝试直接用 JS evaluate 点击按钮
                                btn = layer_info.get('confirm_btn')
                                close = layer_info.get('close_icon')
                                if btn:
                                    self._pw(lambda: btn.evaluate('el => el.click()'))
                                    self.logger.info("[MyLayer] 已直接点击确认按钮(evaluate)")
                                    self._fire_callback('handled', {
                                        'popup_type': 'mylayer',
                                        'page_url': page_url,
                                        'details': 'evaluate click confirm_btn'
                                    })
                                elif close:
                                    self._pw(lambda: close.evaluate('el => el.click()'))
                                    self.logger.info("[MyLayer] 已直接点击关闭图标(evaluate)")
                                    self._fire_callback('handled', {
                                        'popup_type': 'mylayer',
                                        'page_url': page_url,
                                        'details': 'evaluate click close_icon'
                                    })

                            return
            except Exception:
                pass

            # 检测答题/单选题弹窗（扫描所有标签页）
            try:
                quiz_pages = self._get_all_pages()
                for quiz_page in quiz_pages:
                    quiz_info = self._scan_quiz_elements(quiz_page)
                    quiz_options = quiz_info.get('radios', []) or quiz_info.get('checkboxes', [])
                    visible_quiz_opts = [o for o in quiz_options if o.get('visible') and not o.get('disabled')]
                    if len(visible_quiz_opts) < 2:
                        continue

                    any_checked = any(o.get('checked') for o in visible_quiz_opts)
                    exclude_indices = []

                    # 检查自动答题开关：关闭时跳过所有答题处理
                    if not self.auto_answer_enabled:
                        continue

                    # 检查答题状态：如果弹窗再次出现且之前已"成功"，说明之前答案是错的
                    for rule in self.popup_rules:
                        if rule.get('type') != 'quiz':
                            continue
                        rule_id = f"quiz:{rule.get('keyword', '')}:{rule.get('selector', '')}"
                        state = self._quiz_state.get(rule_id)
                        if state and state.get('success'):
                            # 之前标记为成功但弹窗再次出现 → 之前答案是错误的
                            self.logger.info(
                                f"[自动答题] 弹窗再次出现，之前答案标记为成功但实际错误，"
                                f"标记为失败并重试: {rule_id}")
                            state['success'] = False
                            tried = set(state.get('tried_indices', []))
                            exclude_indices = list(tried)

                    # 有选项已选中时也继续处理，_handle_quiz_popup 内部会 _reset_quiz_selection 重置

                    # 发现答题弹窗
                    self.logger.info(
                        f"[自动答题] 在标签页发现 {len(visible_quiz_opts)} 个选项的答题弹窗"
                        + (f"（重试，跳过已尝试选项: {exclude_indices}）" if exclude_indices else ""))
                    # 匹配 quiz 规则
                    for rule in self.popup_rules:
                        if rule.get('type') == 'quiz':
                            result = self._handle_quiz_popup(rule, quiz_page,
                                                             exclude_indices=exclude_indices)
                            # 统一跟踪答题状态
                            rule_id = f"quiz:{rule.get('keyword', '')}:{rule.get('selector', '')}"
                            self._quiz_state[rule_id] = {
                                'tried_indices': list(exclude_indices) + result.get('tried_indices', []),
                                'last_result': result,
                                'attempts': result.get('attempts', 0),
                                'success': result.get('success', False),
                                'error_msg': result.get('error_msg', ''),
                                'submit_verified': result.get('submit_verified', False)
                            }
                            # 仅成功且验证通过时标记防重复
                            if result.get('success') and result.get('submit_verified'):
                                self._last_handled[rule_id] = True
                            self.logger.info(
                                f"自动答题完成: success={result.get('success')}, "
                                f"attempts={result.get('attempts', 0)}")
                            quiz_page_url = ''
                            try:
                                quiz_page_url = self._pw(lambda: quiz_page.url) or ''
                            except Exception:
                                pass
                            self._fire_callback('handled', {
                                'popup_type': 'quiz',
                                'page_url': quiz_page_url,
                                'details': f"success={result.get('success')}, attempts={result.get('attempts', 0)}"
                            })
                            return
                    # 无规则匹配时使用通用答题（逐一尝试）
                    result = self._handle_quiz_popup({
                        'keyword': '', 'type': 'quiz',
                        'action': 'auto_answer',
                        'selector': '', 'correct_answer': '',
                        'max_retries': 5
                    }, quiz_page, exclude_indices=exclude_indices)
                    # 通用答题也跟踪状态
                    generic_rule_id = "quiz:auto_detect:generic"
                    self._quiz_state[generic_rule_id] = {
                        'tried_indices': list(exclude_indices) + result.get('tried_indices', []),
                        'last_result': result,
                        'attempts': result.get('attempts', 0),
                        'success': result.get('success', False),
                        'error_msg': result.get('error_msg', ''),
                        'submit_verified': result.get('submit_verified', False)
                    }
                    self.logger.info(
                        f"自动答题(无规则): success={result.get('success')}, "
                        f"attempts={result.get('attempts', 0)}")
                    quiz_page_url = ''
                    try:
                        quiz_page_url = self._pw(lambda: quiz_page.url) or ''
                    except Exception:
                        pass
                    self._fire_callback('handled', {
                        'popup_type': 'quiz',
                        'page_url': quiz_page_url,
                        'details': f"auto_answer, success={result.get('success')}, attempts={result.get('attempts', 0)}"
                    })
                    return

                # 旧逻辑保留：通过 is_visible 检测（兼容非隐藏 radio 场景）
                if not self.auto_answer_enabled:
                    # 自动答题关闭时跳过答题相关处理
                    pass
                else:
                    radio_groups = self._pw(lambda: self.page.query_selector_all('input[type="radio"]'))
                    visible_radios = [r for r in radio_groups if self._pw(lambda r=r: r.is_visible())]
                    if len(visible_radios) >= 2:
                        # 检查是否有已选中的
                        any_checked = any(self._pw(lambda r=r: r.is_checked()) for r in visible_radios)
                        if not any_checked:
                            # 自动尝试匹配规则
                            popup_type = self.detect_popup_type(self.page)
                            if popup_type == 'quiz':
                                # 答题弹窗：智能答题
                                for rule in self.popup_rules:
                                    if rule.get('type') == 'quiz':
                                        result = self._handle_quiz_popup(rule, self.page)
                                        # 统一跟踪答题状态
                                        rule_id = f"quiz:{rule.get('keyword', '')}:{rule.get('selector', '')}"
                                        self._quiz_state[rule_id] = {
                                            'tried_indices': result.get('tried_indices', []),
                                            'last_result': result,
                                            'attempts': result.get('attempts', 0),
                                            'success': result.get('success', False),
                                            'error_msg': result.get('error_msg', ''),
                                            'submit_verified': result.get('submit_verified', False)
                                        }
                                        if result.get('success') and result.get('submit_verified'):
                                            self._last_handled[rule_id] = True
                                        self.logger.info(
                                            f"自动答题完成: success={result.get('success')}, "
                                            f"attempts={result.get('attempts', 0)}")
                                        return
                                # 无规则匹配时使用通用答题（逐一尝试）
                                result = self._handle_quiz_popup({
                                    'keyword': '', 'type': 'quiz',
                                    'action': 'auto_answer',
                                    'selector': '', 'correct_answer': '',
                                    'max_retries': 5
                                }, self.page)
                                self.logger.info(
                                    f"自动答题(无规则): success={result.get('success')}, "
                                    f"attempts={result.get('attempts', 0)}")
                                return

                        elif popup_type == 'radio':
                            # 单选题弹窗：选中第一个
                            for rule in self.popup_rules:
                                if rule.get('type') == 'radio':
                                    self._handle_radio_popup(rule, self.page)
                                    return
                            self._pw(lambda: visible_radios[0].click())
                            self.logger.info("自动检测单选题弹窗，已选中第一个选项")
            except Exception:
                pass

        except Exception as e:
            self.logger.debug(f"自动弹窗检测异常: {e}")

    # ================================================================
    #  监听管理
    # ================================================================
    def register_dialog_handler(self):
        """在主线程中注册浏览器原生弹窗(dialog)事件监听。
        必须在启动后台监听线程之前调用，因为 page.on() 需要 Playwright 事件循环。
        """
        try:
            self.page.on("dialog", self.handle_dialog)
            self.logger.debug("已注册浏览器原生dialog事件监听")
        except Exception as e:
            self.logger.error(f"注册dialog监听失败: {e}")

    def start_listening(self, check_interval=None):
        """启动弹窗监听。
        check_interval: 自定义扫描间隔（秒），None 则使用默认值 2.0s
        注意：调用此方法前，须先在主线程调用 register_dialog_handler() 注册 dialog 监听
        """
        if check_interval is not None and check_interval > 0:
            self.custom_popup_check_interval = float(check_interval)

        # 确保旧监听线程已完全退出（防止残留线程导致 Playwright 线程冲突）
        if self.thread and self.thread.is_alive():
            self.logger.info("[弹窗监听] 旧监听线程仍在运行，等待退出...")
            self.running = False
            self.thread.join(timeout=5)
            if self.thread.is_alive():
                self.logger.warning("[弹窗监听] 旧监听线程未能在5秒内退出，强制继续")

        self.running = True
        self._last_handled.clear()
        self._pre_quiz_urls.clear()
        self._last_popup_snapshot = None

        def monitor_custom_popup():
            """后台轮询线程：每 2 秒检测一次弹窗，根据状态变化触发回调。"""
            consecutive_errors = 0
            max_consecutive_errors = 10  # 连续错误上限，超过后延长间隔

            while self.running:
                try:
                    # ---- 阶段1: 获取弹窗状态快照 ----
                    current_snapshot = self._get_popup_snapshot()

                    # ---- 阶段2: 判断状态变化，触发回调 ----
                    if self._last_popup_snapshot is not None:
                        # 检测新弹窗（当前有，之前没有）
                        for url, popups in current_snapshot.items():
                            if url not in self._last_popup_snapshot:
                                for p in popups:
                                    self._fire_callback('detected', {
                                        'popup_type': p['type'],
                                        'page_url': url,
                                        'details': p.get('details', '')
                                    })
                                    self.logger.info(
                                        f"[弹窗监听] 新弹窗: type={p['type']}, "
                                        f"page={url[:60]}, details={p.get('details', '')[:50]}")
                            else:
                                # 同一页面，对比弹窗列表变化
                                old_types = {pp['type'] for pp in self._last_popup_snapshot[url]}
                                for p in popups:
                                    if p['type'] not in old_types:
                                        self._fire_callback('detected', {
                                            'popup_type': p['type'],
                                            'page_url': url,
                                            'details': p.get('details', '')
                                        })
                                        self.logger.info(
                                            f"[弹窗监听] 新弹窗: type={p['type']}, page={url[:60]}")

                        # 检测弹窗消失（之前有，现在没有）
                        for url, popups in self._last_popup_snapshot.items():
                            if url not in current_snapshot:
                                for p in popups:
                                    self._fire_callback('cleared', {
                                        'popup_type': p['type'],
                                        'page_url': url,
                                        'details': p.get('details', '')
                                    })
                                    self.logger.debug(
                                        f"[弹窗监听] 弹窗消失: type={p['type']}, page={url[:60]}")
                            else:
                                old_types = {pp['type'] for pp in popups}
                                new_types = {pp['type'] for pp in current_snapshot[url]}
                                for gone_type in old_types - new_types:
                                    self._fire_callback('cleared', {
                                        'popup_type': gone_type,
                                        'page_url': url,
                                        'details': ''
                                    })
                                    self.logger.debug(
                                        f"[弹窗监听] 弹窗消失: type={gone_type}, page={url[:60]}")

                    self._last_popup_snapshot = current_snapshot

                    # ---- 阶段3: 执行弹窗处理逻辑 ----
                    try:
                        self.check_custom_popup()
                    except Exception as e:
                        self.logger.warning(f"[弹窗监听] 自定义规则检测异常: {e}")
                        self._fire_callback('error', {
                            'popup_type': 'custom',
                            'page_url': '',
                            'details': str(e)
                        })

                    try:
                        self.auto_detect_and_handle()
                    except Exception as e:
                        self.logger.warning(f"[弹窗监听] 自动检测处理异常: {e}")
                        self._fire_callback('error', {
                            'popup_type': 'auto',
                            'page_url': '',
                            'details': str(e)
                        })

                    # 成功执行一轮，重置错误计数
                    consecutive_errors = 0

                    # ---- 阶段4: 快照所有页面URL（仅在启用 quiz 规则时执行） ----
                    # 关键：放在周期末尾而非开头，确保 _prev_cycle_page_urls 保存的是
                    # 上一轮（quiz出现前）的URL，而非当前轮（quiz已出现后）的URL
                    # 优化：无 quiz 规则时跳过，避免不必要的页面URL遍历开销
                    if self._has_quiz_rules():
                        self._snapshot_all_page_urls()

                except Exception as e:
                    consecutive_errors += 1
                    err_str = str(e).lower()
                    # 检测 Playwright 线程切换错误（不可恢复，应停止监听循环）
                    if 'cannot switch to a different thread' in err_str:
                        self.logger.error(
                            f"[弹窗监听] Playwright 线程切换失败（不可恢复），停止监听: {e}")
                        self.running = False
                        break
                    self.logger.error(
                        f"[弹窗监听] 第 {consecutive_errors} 次轮询异常: {e}")
                    self._fire_callback('error', {
                        'popup_type': 'unknown',
                        'page_url': '',
                        'details': str(e)
                    })
                    # 连续错误过多时延长间隔，避免刷屏和占用资源
                    if consecutive_errors >= max_consecutive_errors:
                        self.logger.warning(
                            f"[弹窗监听] 连续 {consecutive_errors} 次异常，"
                            f"间隔延长至 {self.custom_popup_check_interval * 3}s")
                        time.sleep(self.custom_popup_check_interval * 3)
                        continue

                # ---- 阶段4: 等待下一轮轮询 ----
                # 使用分段 sleep，便于快速响应 stop 信号
                wait_secs = self.custom_popup_check_interval
                if consecutive_errors > 3:
                    wait_secs = min(wait_secs * 2, 10.0)  # 异常时加倍，最多 10 秒
                end_time = time.time() + wait_secs
                while self.running and time.time() < end_time:
                    time.sleep(0.2)  # 每 200ms 检查一次 running 标志

        self.thread = threading.Thread(target=monitor_custom_popup, daemon=True)
        self.thread.start()
        self.logger.info(
            f"弹窗监听已启动 (扫描间隔: {self.custom_popup_check_interval}s, "
            f"回调数: {len(self._popup_callbacks)})")

    def stop_listening(self):
        """停止弹窗监听。"""
        self.running = False
        self._last_handled.clear()
        self._pre_quiz_urls.clear()
        self._prev_cycle_page_urls.clear()
        self._last_popup_snapshot = None
        if self.thread:
            self.thread.join(timeout=3)
        self.logger.info("弹窗监听已停止")

    # ================================================================
    #  弹窗规则测试（手动触发单次检测）
    # ================================================================
    def test_rule(self, rule, timeout=10):
        """测试单条弹窗规则，返回测试结果详情。
        rule: 弹窗规则字典
        timeout: 最大等待时间（秒）
        返回: {'success': bool, 'matched': bool, 'action_taken': str, 'details': str, 'error': str}
        """
        result = {
            'success': False,
            'matched': False,
            'action_taken': '',
            'details': '',
            'error': ''
        }

        try:
            rule_type = rule.get('type', 'custom')
            keyword = rule.get('keyword', '')
            selector = rule.get('selector', '')
            action = rule.get('action', 'click')
            tab_index = rule.get('tab_index', -1)

            target_page = self._get_target_page(tab_index)

            # 1. 检测是否匹配
            if rule_type == 'layer':
                # Layer 类型：扫描所有标签页检查 mylayer 弹窗是否存在
                try:
                    layer_sel = selector or '.mylayer-btn.type1'
                    found_page = None
                    layer_info = None

                    # 先检查目标标签页，再扫描全部标签页
                    all_pages = self._get_all_pages()
                    # 优先检查 target_page
                    check_pages = [target_page] + [p for p in all_pages if p is not target_page]

                    for page in check_pages:
                        info = self._check_mylayer_on_page(page)
                        if info['found']:
                            found_page = page
                            layer_info = info
                            break

                    if layer_info and layer_info['found']:
                        result['matched'] = True
                        popup_text = layer_info.get('popup_text', '')[:50]
                        has_confirm = layer_info.get('confirm_btn') is not None
                        has_close = layer_info.get('close_icon') is not None
                        result['details'] = (
                            f"发现 mylayer 弹窗 (确认按钮={'可见' if has_confirm else '不可见'}, "
                            f"关闭图标={'可见' if has_close else '不可见'}, "
                            f"文本: {popup_text})")

                        # 尝试处理：在弹窗所在页面上操作
                        if action in ('click', 'close'):
                            click_result = self._pw(lambda: self.browser.click_mylayer_confirm(
                                selector=layer_sel, timeout=3, page=found_page)) if self.browser else None

                            if click_result and click_result.get('success'):
                                result['success'] = True
                                result['action_taken'] = f"已点击: {click_result['selector']}"
                            else:
                                # 回退：直接用 JS evaluate 点击找到的按钮
                                btn = layer_info.get('confirm_btn')
                                close = layer_info.get('close_icon')
                                if btn:
                                    self._pw(lambda: btn.evaluate('el => el.click()'))
                                    result['success'] = True
                                    result['action_taken'] = '已直接点击确认按钮(evaluate)'
                                elif close:
                                    self._pw(lambda: close.evaluate('el => el.click()'))
                                    result['success'] = True
                                    result['action_taken'] = '已直接点击关闭图标(evaluate)'
                                else:
                                    result['action_taken'] = '点击失败'
                                    result['error'] = '未找到可点击元素'
                    else:
                        result['details'] = '未发现 mylayer 弹窗（已扫描所有标签页）'
                except Exception as e:
                    result['error'] = f'检测异常: {e}'

            elif rule_type in ('custom',):
                # Custom 类型：检测选择器元素是否存在
                if not selector:
                    result['error'] = '选择器为空'
                    return result

                element = self._query_selector(selector)
                if element:
                    result['matched'] = True
                    try:
                        text_content = self._pw(lambda: element.text_content()) or ''
                    except Exception:
                        text_content = ''

                    # 检查关键词匹配
                    if keyword and keyword not in text_content:
                        result['details'] = f"元素存在但关键词不匹配 (文本: {text_content[:50]})"
                        return result

                    result['details'] = f"元素存在 (文本: {text_content[:50]})"

                    # 尝试执行操作
                    if action == 'click':
                        try:
                            self._pw(lambda: element.click())
                            result['success'] = True
                            result['action_taken'] = '已点击元素'
                        except Exception as e:
                            result['action_taken'] = '点击失败'
                            result['error'] = str(e)
                    elif action == 'close':
                        try:
                            self._pw(lambda: element.click())
                            result['success'] = True
                            result['action_taken'] = '已关闭弹窗'
                        except Exception as e:
                            result['action_taken'] = '关闭失败'
                            result['error'] = str(e)
                    elif action == 'input':
                        input_text = rule.get('input_text', '')
                        try:
                            self._pw(lambda: element.fill(input_text))
                            result['success'] = True
                            result['action_taken'] = f'已输入文本: {input_text[:30]}'
                        except Exception as e:
                            result['action_taken'] = '输入失败'
                            result['error'] = str(e)
                    else:
                        result['action_taken'] = f'操作 {action} 未执行（仅检测匹配）'
                        result['success'] = True
                else:
                    result['details'] = '选择器未匹配到元素'

            elif rule_type == 'radio':
                # Radio 类型：检测 radio 选项
                try:
                    radios = self._pw(lambda: target_page.query_selector_all('input[type="radio"]')) if target_page else []
                    visible_radios = [r for r in radios if self._pw(lambda r=r: r.is_visible())] if radios else []
                    if visible_radios:
                        result['matched'] = True
                        checked_count = sum(1 for r in visible_radios if self._pw(lambda r=r: r.is_checked()))
                        result['details'] = f"发现 {len(visible_radios)} 个 radio 选项，{checked_count} 个已选中"

                        option_value = rule.get('option_value', '')
                        if option_value:
                            for radio in visible_radios:
                                val = self._pw(lambda r=radio: r.get_attribute('value')) or ''
                                if val == option_value:
                                    if not self._pw(lambda r=radio: r.is_checked()):
                                        self._pw(lambda r=radio: r.click())
                                        result['success'] = True
                                        result['action_taken'] = f'已选中 value={option_value}'
                                    else:
                                        result['success'] = True
                                        result['action_taken'] = f'已处于选中状态 value={option_value}'
                                    break
                        else:
                            result['action_taken'] = '仅检测，未执行选择'
                            result['success'] = True
                    else:
                        result['details'] = '未发现 radio 选项'
                except Exception as e:
                    result['error'] = f'检测异常: {e}'

            elif rule_type == 'quiz':
                # Quiz 类型：检测答题弹窗
                try:
                    quiz_info = self._scan_quiz_elements(target_page)
                    options = quiz_info.get('radios', []) or quiz_info.get('checkboxes', [])
                    visible_options = [o for o in options if o.get('visible') and not o.get('disabled')]

                    if len(visible_options) >= 2:
                        result['matched'] = True
                        result['details'] = (
                            f"发现 {len(visible_options)} 个选项，"
                            f"{len(quiz_info.get('submitBtns', []))} 个提交按钮"
                        )
                        result['action_taken'] = '仅检测匹配（答题需完整执行流程）'
                        result['success'] = True
                    else:
                        result['details'] = f'选项不足 (<2)，可能不是答题弹窗'
                except Exception as e:
                    result['error'] = f'检测异常: {e}'

            elif rule_type in ('alert', 'confirm', 'prompt'):
                # 浏览器原生弹窗：无法主动测试，仅记录
                result['details'] = '浏览器原生弹窗需要页面触发才能测试'
                result['matched'] = True  # 规则本身有效
                result['success'] = True
                result['action_taken'] = '等待浏览器弹窗触发时自动处理'

        except Exception as e:
            result['error'] = f'测试异常: {e}'

        return result
