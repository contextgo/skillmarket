# -*- coding: utf-8 -*-
"""
网页音频录制模块 - 使用 Playwright 捕获网页视频音频

通过注入 JavaScript 代码，使用 Web Audio API 和 MediaRecorder 
实现对网页视频音频的实时捕获与录制。

主要功能：
- 捕获网页中的媒体音频流
- 支持开始、暂停、恢复、停止录音
- 音频流实时处理，不影响视频播放
- 支持多种音频格式输出
"""

import os
import io
import time
import base64
import logging
import subprocess
import threading
import uuid
import json
from typing import Optional, List, Callable, Dict, Any
from pathlib import Path
from datetime import datetime


class WebAudioRecorder:
    """
    网页音频录制器
    
    使用 Playwright 注入 JavaScript 代码，通过 Web Audio API 捕获网页音频。
    支持对网页中的 <video> 和 <audio> 元素进行音频录制。
    
    特性：
    - 实时音频流捕获
    - 开始/暂停/恢复/停止控制
    - WebM/Opus 或 WAV 格式输出
    - 音频数据回调（实时处理）
    - 兼容主流浏览器（Chrome、Edge、360系列）
    """
    
    # 音频格式枚举
    FORMAT_WEBM_OPUS = 'webm_opus'  # WebM 容器 + Opus 编码（体积小，质量好）
    FORMAT_WEBM_VORBIS = 'webm_vorbis'  # WebM 容器 + Vorbis 编码
    FORMAT_WAV = 'wav'  # WAV 格式（无损，体积大）
    FORMAT_MP3 = 'mp3'  # MP3 格式（需要后处理转换）
    FORMAT_M4A = 'm4a'  # M4A 格式（AAC 编码，需要后处理转换）
    FORMAT_WEBM = 'webm'  # WebM 格式（通用别名）
    
    # 默认配置
    DEFAULT_CONFIG = {
        'format': FORMAT_WEBM_OPUS,
        'sample_rate': 48000,
        'channels': 1,  # 单声道
        'bitrate': '128k',
        'output_dir': 'recordings',
        'auto_create_dir': True,
        'max_duration': 7200,  # 最大录制时长（秒），2小时
        'buffer_size': 8192,
    }
    
    # JavaScript 注入代码 - 精简版
    JS_CODE = """
    (function() {
        if (window.__web_audio_recorder__) return window.__web_audio_recorder__;
        
        const R = {
            ctx: null, rec: null, chunks: [], recording: false, paused: false,
            startTime: null, pausedDur: 0, lastPause: null, nodes: [],
            cfg: { mimeType: null, bps: 128000, sr: 48000, ch: 1, ts: 1000 },
            
            init() {
                const T = ['audio/webm;codecs=opus','audio/webm;codecs=vorbis','audio/webm','audio/ogg;codecs=opus','audio/ogg'];
                for (let t of T) { try { if (MediaRecorder.isTypeSupported(t)) { this.cfg.mimeType = t; break; } } catch(e){} }
                this.cfg.mimeType = this.cfg.mimeType || 'audio/webm';
            },
            
            getCtx() {
                if (!this.ctx || this.ctx.state === 'closed') {
                    this.ctx = new (window.AudioContext || window.webkitAudioContext)({sampleRate: this.cfg.sr});
                }
                return this.ctx;
            },
            
            getMediaEls() {
                const els = [];
                ['video','audio'].forEach(s => {
                    document.querySelectorAll(s).forEach(el => {
                        // 只要元素存在就收集，不要求 src/currentSrc（MSE 视频可能没有 src 属性）
                        if (el.src || el.currentSrc || el.srcObject || el.readyState >= 2) els.push(el);
                    });
                    document.querySelectorAll('*').forEach(r => {
                        if (r.shadowRoot) r.shadowRoot.querySelectorAll(s).forEach(el => {
                            if (el.src || el.currentSrc || el.srcObject || el.readyState >= 2) els.push(el);
                        });
                    });
                    document.querySelectorAll('iframe').forEach(iframe => {
                        try {
                            const doc = iframe.contentDocument || iframe.contentWindow?.document;
                            if (doc) doc.querySelectorAll(s).forEach(el => {
                                if (el.src || el.currentSrc || el.srcObject || el.readyState >= 2) els.push(el);
                            });
                        } catch(e){}
                    });
                });
                return [...new Set(els)];
            },
            
            async start(opts = {}) {
                if (this.recording) throw new Error('already recording');
                this.getCtx();
                if (this.ctx.state === 'suspended') await this.ctx.resume();
                
                const els = opts.elements || this.getMediaEls();
                const stream = new MediaStream();
                let gotTracks = false;
                
                // 方法1: 通过 captureStream 直接获取音频轨道（最可靠）
                for (const el of els) {
                    if (el.captureStream) {
                        try {
                            const s = el.captureStream();
                            s.getAudioTracks().forEach(t => stream.addTrack(t.clone()));
                            if (stream.getAudioTracks().length > 0) {
                                gotTracks = true;
                                console.log('[AR] captureStream 获取音频轨道成功:', stream.getAudioTracks().length);
                                break;
                            }
                        } catch(e) { console.warn('[AR] captureStream 失败:', e); }
                    }
                }
                
                // 方法2: 通过 AudioContext + MediaStreamDestination 捕获
                if (!gotTracks) {
                    const ctx = this.getCtx();
                    const dest = ctx.createMediaStreamDestination();
                    for (const el of els) {
                        try {
                            if (el.captureStream) {
                                const s = el.captureStream();
                                const src = ctx.createMediaStreamSource(s);
                                src.connect(dest);
                                src.connect(ctx.destination);
                                this.nodes.push({s, src});
                            } else if (el instanceof HTMLMediaElement) {
                                const src = ctx.createMediaElementSource(el);
                                src.connect(dest);
                                src.connect(ctx.destination);
                                this.nodes.push({src});
                            }
                        } catch(e) { console.warn('[AR] AudioContext 连接失败:', e); continue; }
                    }
                    // 从 destination 获取音频轨道
                    if (dest.stream.getAudioTracks().length > 0) {
                        dest.stream.getAudioTracks().forEach(t => stream.addTrack(t));
                        gotTracks = true;
                        console.log('[AR] MediaStreamDestination 获取音频轨道成功');
                    }
                }
                
                if (!gotTracks || stream.getAudioTracks().length === 0) {
                    throw new Error('Cannot capture audio. Ensure video is playing.');
                }
                
                this.chunks = [];
                this.recording = true;
                this.paused = false;
                this.startTime = Date.now();
                this.pausedDur = 0;
                this.lastPause = null;
                
                this.rec = new MediaRecorder(stream, { mimeType: this.cfg.mimeType, audioBitsPerSecond: this.cfg.bps });
                this.rec.ondataavailable = e => { if (e.data?.size > 0) this.chunks.push(e.data); };
                this.rec.onerror = e => { console.error('[AR]', e.error); };
                this.rec.onpause = () => { this.paused = true; this.lastPause = Date.now(); };
                this.rec.onresume = () => { this.paused = false; if (this.lastPause) { this.pausedDur += Date.now() - this.lastPause; this.lastPause = null; } };
                this.rec.onstart = () => {};
                this.rec.onstop = () => {};
                this.rec.start(this.cfg.ts);
                
                return { success: true, mimeType: this.cfg.mimeType };
            },
            
            pause() {
                if (this.recording && !this.paused && this.rec?.state === 'recording') { this.rec.pause(); return true; }
                return false;
            },
            
            resume() {
                if (this.recording && this.paused && this.rec?.state === 'paused') { this.rec.resume(); return true; }
                return false;
            },
            
            async stop() {
                if (!this.recording) throw new Error('not recording');
                return new Promise((res, rej) => {
                    const dur = this.getDur();
                    if (this.rec && this.rec.state !== 'inactive') {
                        this.rec.onstop = async () => {
                            try {
                                const blob = new Blob(this.chunks, { type: this.cfg.mimeType || 'audio/webm' });
                                // 将 Blob 转为 Base64 字符串，以便 Playwright evaluate 可以序列化传回 Python
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                    const base64 = reader.result.split(',')[1] || '';
                                    this.cleanup();
                                    res({ success: true, base64, duration: dur, mimeType: this.cfg.mimeType, size: blob.size });
                                };
                                reader.onerror = () => {
                                    this.cleanup();
                                    rej(new Error('Blob to Base64 conversion failed'));
                                };
                                reader.readAsDataURL(blob);
                            } catch(e) { this.cleanup(); rej(e); }
                        };
                        this.rec.stop();
                    } else { this.cleanup(); rej(new Error('recorder not started')); }
                });
            },
            
            getDur() {
                if (!this.startTime) return 0;
                let d = Date.now() - this.startTime - this.pausedDur;
                if (this.lastPause) d -= Date.now() - this.lastPause;
                return d / 1000;
            },
            
            getStatus() {
                return { recording: this.recording, paused: this.paused, duration: this.getDur(), state: this.rec?.state || 'inactive', mimeType: this.cfg.mimeType };
            },
            
            getData() {
                if (!this.chunks.length) return null;
                return { blob: new Blob(this.chunks, { type: this.cfg.mimeType || 'audio/webm' }), size: this.chunks.reduce((a,c) => a + c.size, 0) };
            },
            
            cleanup() {
                this.recording = false; this.paused = false; this.chunks = [];
                this.nodes.forEach(n => { try { n.src?.disconnect(); } catch(e){} });
                this.nodes = [];
                if (this.ctx && this.ctx.state !== 'closed') setTimeout(() => { try { this.ctx.close(); } catch(e){} this.ctx = null; }, 100);
            },
            
            destroy() {
                this.cleanup();
                if (this.rec && this.rec.state !== 'inactive') try { this.rec.stop(); } catch(e){}
                this.rec = null;
            }
        };
        
        R.init();
        window.__web_audio_recorder__ = R;
        return R;
    })();
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """初始化音频录制器"""
        self.logger = logging.getLogger(__name__)
        self.config = {**self.DEFAULT_CONFIG, **(config or {})}
        
        # 状态
        self._page = None
        self._recorder_id = str(uuid.uuid4())[:8]
        self._is_recording = False
        self._is_paused = False
        self._start_time = None
        self._output_dir = self.config.get('output_dir', 'recordings')
        self._current_output_path = None
        
        # 回调
        self._on_data_available = None
        self._on_error = None
        self._on_status_change = None
        
        # 锁（使用可重入锁，因为 cleanup 会调用 stop，两者都需要持锁）
        self._lock = threading.RLock()
        
        # 创建输出目录
        if self.config.get('auto_create_dir', True):
            Path(self._output_dir).mkdir(parents=True, exist_ok=True)
    
    def inject(self, page) -> bool:
        """向 Playwright page 注入音频录制代码"""
        try:
            self._page = page
            page.evaluate(self.JS_CODE)
            result = page.evaluate("() => !!window.__web_audio_recorder__")
            
            if result:
                self.logger.info(f"[音频录制] 注入成功 (ID: {self._recorder_id})")
                formats = page.evaluate("() => window.__web_audio_recorder__.cfg?.mimeType")
                self.logger.info(f"[音频录制] 支持格式: {formats}")
                return True
            
            self.logger.error("[音频录制] 注入失败")
            return False
            
        except Exception as e:
            self.logger.error(f"[音频录制] 注入异常: {e}")
            return False
    
    def start(self, elements: Optional[List[Any]] = None, 
              timeslice: int = 1000,
              output_name: Optional[str] = None) -> Dict[str, Any]:
        """开始录制音频"""
        with self._lock:
            if self._is_recording:
                return {'success': False, 'error': 'already recording'}
            
            if not self._page:
                return {'success': False, 'error': 'page not injected'}
            
            try:
                options = {'timeslice': timeslice}
                if elements:
                    options['elements'] = elements
                
                result = self._page.evaluate(
                    "(opts) => window.__web_audio_recorder__.start(opts)",
                    options
                )
                
                if result.get('success'):
                    self._is_recording = True
                    self._is_paused = False
                    self._start_time = time.time()
                    
                    if not output_name:
                        output_name = f'audio_{datetime.now().strftime("%Y%m%d_%H%M%S")}_{self._recorder_id}'
                    ext = self._get_format_extension(self.config.get('format', self.FORMAT_WEBM_OPUS))
                    self._current_output_path = os.path.join(self._output_dir, f'{output_name}.{ext}')
                    
                    self.logger.info(f"[音频录制] 开始: {result.get('mimeType', 'unknown')}")
                    self._notify_status_change('recording')
                
                return result
                
            except Exception as e:
                self.logger.error(f"[音频录制] 启动异常: {e}")
                return {'success': False, 'error': str(e)}
    
    def pause(self) -> bool:
        """暂停录制"""
        with self._lock:
            if not self._is_recording or self._is_paused:
                return False
            
            try:
                result = self._page.evaluate("() => window.__web_audio_recorder__.pause()")
                if result:
                    self._is_paused = True
                    self.logger.info("[音频录制] 已暂停")
                    self._notify_status_change('paused')
                    return True
            except Exception as e:
                self.logger.error(f"[音频录制] 暂停失败: {e}")
            return False
    
    def resume(self) -> bool:
        """恢复录制"""
        with self._lock:
            if not self._is_recording or not self._is_paused:
                return False
            
            try:
                result = self._page.evaluate("() => window.__web_audio_recorder__.resume()")
                if result:
                    self._is_paused = False
                    self.logger.info("[音频录制] 已恢复")
                    self._notify_status_change('recording')
                    return True
            except Exception as e:
                self.logger.error(f"[音频录制] 恢复失败: {e}")
            return False
    
    def stop(self, save: bool = True, output_path: Optional[str] = None) -> Dict[str, Any]:
        """停止录制"""
        with self._lock:
            if not self._is_recording:
                return {'success': False, 'error': 'not recording'}
            
            try:
                result = self._page.evaluate("() => window.__web_audio_recorder__.stop()")
                
                self._is_recording = False
                self._is_paused = False
                duration = time.time() - self._start_time if self._start_time else 0
                
                if result.get('success'):
                    response = {
                        'success': True,
                        'duration': result.get('duration', duration),
                        'mimeType': result.get('mimeType'),
                        'size': result.get('size', 0),
                    }
                    
                    if save:
                        path = output_path or self._current_output_path
                        if path and result.get('base64'):
                            audio_data = base64.b64decode(result['base64'])
                            saved = self._save_raw(audio_data, path)
                            if saved:
                                # 检查是否需要格式转换（MP3/M4A 需要后处理）
                                target_fmt = self.config.get('format', 'webm_opus')
                                need_convert = target_fmt in (self.FORMAT_MP3, self.FORMAT_M4A)
                                if need_convert:
                                    converted = self._convert_audio_format(saved, target_fmt)
                                    if converted:
                                        response['path'] = converted
                                        self.logger.info(f"[音频录制] 已保存并转换: {converted} (时长: {response['duration']:.1f}s, 大小: {response['size']/1024:.1f}KB)")
                                    else:
                                        # 转换失败，保留原始文件
                                        response['path'] = saved
                                        self.logger.warning(f"[音频录制] 转换失败，保留原始文件: {saved}")
                                else:
                                    response['path'] = saved
                                    self.logger.info(f"[音频录制] 已保存: {saved} (时长: {response['duration']:.1f}s, 大小: {response['size']/1024:.1f}KB)")
                            else:
                                self.logger.error("[音频录制] 文件保存失败")
                        elif path:
                            self.logger.warning("[音频录制] 无音频数据，跳过保存")
                    
                    self._notify_status_change('stopped')
                    return response
                
                error = result.get('error', 'unknown') if result else 'no result'
                return {'success': False, 'error': error}
                
            except Exception as e:
                self.logger.error(f"[音频录制] 停止异常: {e}")
                self._is_recording = False
                self._is_paused = False
                return {'success': False, 'error': str(e)}
    
    def _save_raw(self, audio_data: bytes, output_path: str) -> Optional[str]:
        """保存原始音频数据到文件"""
        try:
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            with open(output_path, 'wb') as f:
                f.write(audio_data)
            return output_path
        except Exception as e:
            self.logger.error(f"[音频录制] 保存失败: {e}")
            return None

    def _check_ffmpeg(self) -> bool:
        """检查 ffmpeg 是否可用"""
        try:
            subprocess.run(['ffmpeg', '-version'],
                         capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            common_paths = [
                r'C:\ffmpeg\bin\ffmpeg.exe',
                r'C:\Program Files\ffmpeg\bin\ffmpeg.exe',
            ]
            for path in common_paths:
                if os.path.exists(path):
                    return True
            return False

    def _get_format_extension(self, fmt: str) -> str:
        """根据格式枚举获取文件扩展名"""
        fmt_lower = fmt.lower()
        fmt_map = {
            self.FORMAT_WEBM_OPUS: 'webm',
            self.FORMAT_WEBM_VORBIS: 'webm',
            self.FORMAT_WEBM: 'webm',
            self.FORMAT_WAV: 'wav',
            self.FORMAT_MP3: 'mp3',
            self.FORMAT_M4A: 'm4a',
        }
        return fmt_map.get(fmt_lower, 'webm')

    def _convert_audio_format(self, input_path: str, target_format: str) -> Optional[str]:
        """使用 ffmpeg 将录音文件转换为目标格式

        Args:
            input_path: 原始录音文件路径
            target_format: 目标格式 ('mp3', 'm4a', 'wav')

        Returns:
            转换后的文件路径，失败返回 None
        """
        if not self._check_ffmpeg():
            self.logger.warning(f"[音频录制] ffmpeg 不可用，无法转换为 {target_format}")
            return None

        target_fmt = target_format.lower()
        ext = self._get_format_extension(target_fmt)
        output_path = os.path.splitext(input_path)[0] + '.' + ext

        try:
            if target_fmt == self.FORMAT_MP3:
                cmd = [
                    'ffmpeg', '-y', '-i', input_path,
                    '-acodec', 'libmp3lame',
                    '-ab', self.config.get('bitrate', '128k'),
                    '-ar', str(self.config.get('sample_rate', 48000)),
                    '-ac', str(self.config.get('channels', 1)),
                    output_path
                ]
            elif target_fmt == self.FORMAT_M4A:
                cmd = [
                    'ffmpeg', '-y', '-i', input_path,
                    '-acodec', 'aac',
                    '-ab', self.config.get('bitrate', '128k'),
                    '-ar', str(self.config.get('sample_rate', 48000)),
                    '-ac', str(self.config.get('channels', 1)),
                    '-movflags', '+faststart',
                    output_path
                ]
            elif target_fmt == self.FORMAT_WAV:
                cmd = [
                    'ffmpeg', '-y', '-i', input_path,
                    '-acodec', 'pcm_s16le',
                    '-ar', str(self.config.get('sample_rate', 48000)),
                    '-ac', str(self.config.get('channels', 1)),
                    output_path
                ]
            else:
                self.logger.warning(f"[音频录制] 不支持的格式转换: {target_fmt}")
                return None

            self.logger.info(f"[音频录制] 正在转换格式: {os.path.basename(input_path)} → {target_fmt}")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)

            if result.returncode != 0:
                self.logger.error(f"[音频录制] 格式转换失败: {result.stderr[:500]}")
                return None

            if os.path.exists(output_path):
                self.logger.info(f"[音频录制] 格式转换成功: {output_path}")
                # 删除原始临时文件
                try:
                    os.remove(input_path)
                except Exception:
                    pass
                return output_path

            return None

        except subprocess.TimeoutExpired:
            self.logger.error("[音频录制] 格式转换超时")
            return None
        except Exception as e:
            self.logger.error(f"[音频录制] 格式转换异常: {e}")
            return None
    
    def get_status(self) -> Dict[str, Any]:
        """获取录制状态"""
        if not self._page:
            return {'isRecording': False, 'injected': False}
        
        try:
            status = self._page.evaluate("() => window.__web_audio_recorder__.getStatus()")
            return {**status, 'localRecording': self._is_recording, 'localPaused': self._is_paused, 'injected': True}
        except:
            return {'isRecording': False, 'injected': False, 'error': 'eval failed'}
    
    def is_recording(self) -> bool:
        """检查是否正在录制"""
        return self._is_recording
    
    def is_paused(self) -> bool:
        """检查是否暂停"""
        return self._is_paused
    
    def cleanup(self, save: bool = False, output_path: Optional[str] = None):
        """清理资源
        
        Args:
            save: 是否保存正在录制的音频（默认 False，用于异常清理）
            output_path: 保存路径（仅在 save=True 时使用）
        """
        with self._lock:
            try:
                if self._is_recording:
                    self.stop(save=save, output_path=output_path)
                if self._page:
                    try:
                        self._page.evaluate("() => { if(window.__web_audio_recorder__) window.__web_audio_recorder__.destroy(); }")
                    except Exception:
                        pass
                self.logger.info("[音频录制] 已清理")
            except Exception as e:
                self.logger.error(f"[音频录制] 清理失败: {e}")
            finally:
                self._page = None
                self._is_recording = False
                self._is_paused = False
    
    def _notify_status_change(self, status: str):
        """触发状态变化回调"""
        if self._on_status_change:
            try:
                self._on_status_change(status)
            except Exception as e:
                self.logger.error(f"[音频录制] 状态回调异常: {e}")
    
    def set_on_status_change(self, callback: Callable[[str], None]):
        """设置状态变化回调"""
        self._on_status_change = callback


class PageAudioCapture:
    """
    页面音频捕获器 - 高级封装
    
    提供更高级的音频捕获功能，包括：
    - 自动查找页面上的媒体元素
    - 音频流实时处理
    - 多种输出格式支持
    """
    
    def __init__(self, page, config: Optional[Dict[str, Any]] = None):
        """初始化页面音频捕获器"""
        self.logger = logging.getLogger(__name__)
        self.page = page
        self.recorder = WebAudioRecorder(config)
        self._capture_thread = None
        self._stop_event = threading.Event()
    
    def capture(self, duration: Optional[float] = None,
                output_path: Optional[str] = None,
                on_progress: Optional[Callable[[float, float], None]] = None) -> Dict[str, Any]:
        """捕获页面音频（同步方法）"""
        if not self.recorder.inject(self.page):
            return {'success': False, 'error': 'injection failed'}
        
        result = self.recorder.start()
        if not result.get('success'):
            return result
        
        try:
            if duration:
                start_time = time.time()
                while time.time() - start_time < duration:
                    if self._stop_event.is_set():
                        break
                    time.sleep(0.1)
                    if on_progress:
                        elapsed = time.time() - start_time
                        on_progress(elapsed, duration)
                
                return self.recorder.stop(output_path=output_path)
            else:
                return {
                    'success': True,
                    'message': 'started, call stop() to finish',
                    'status': self.recorder.get_status()
                }
                
        except Exception as e:
            self.logger.error(f"[音频捕获] 异常: {e}")
            self.recorder.cleanup()
            return {'success': False, 'error': str(e)}
    
    def stop(self, output_path: Optional[str] = None) -> Dict[str, Any]:
        """停止捕获"""
        self._stop_event.set()
        return self.recorder.stop(output_path=output_path)
    
    def cleanup(self):
        """清理资源"""
        self._stop_event.set()
        self.recorder.cleanup()
