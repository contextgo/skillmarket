"""
媒体进度守护模块 - 集成在程序中的播放进度自动保存与恢复

功能：
1. 每1分钟自动记录当前视频/音频的播放进度和元数据（只保存1条记录）
2. 持久化存储到本地JSON文件，确保浏览器意外关闭或崩溃后数据不丢失
3. 重新启动时自动读取上次保存的播放状态，无缝恢复到该进度继续播放
4. 健壮的错误处理机制，防止数据丢失（原子写入、双重备份、校验）

设计要点：
- 不依赖浏览器扩展，通过 Playwright page.evaluate() 注入JS实现
- 后台线程定时收集媒体状态，通过 _pw() 确保线程安全
- 存储文件使用原子写入（先写临时文件再重命名），防止写入中断导致数据损坏
- 保留一份 .bak 备份文件，主文件损坏时自动回退
"""

import os
import sys
import json
import time
import threading
import tempfile
import shutil


class MediaProgressSaver:
    """媒体播放进度守护器：自动保存、持久化、崩溃恢复"""

    # 保存间隔（秒）
    SAVE_INTERVAL = 60
    # 最小进度阈值（秒），低于此值不保存
    MIN_PROGRESS_THRESHOLD = 1.0
    # 恢复等待延迟（秒），确保媒体元素就绪
    RESTORE_DELAY = 2.0
    # 数据最大有效期（7天）
    MAX_AGE_SECONDS = 7 * 24 * 3600
    # 恢复后等待媒体就绪的超时（秒）
    MEDIA_READY_TIMEOUT = 8.0

    def __init__(self, browser, logger, pw_caller=None):
        """
        Args:
            browser: BrowserManager 实例
            logger: 日志记录器
            pw_caller: call_on_main_thread 函数，确保 Playwright 调用在主线程执行
        """
        self.browser = browser
        self.logger = logger
        self._pw_caller = pw_caller

        self._running = False
        self._timer = None
        self._lock = threading.Lock()  # 保护文件读写
        self._is_restoring = False     # 恢复过程中暂停保存

        # 最近一次成功收集的媒体数据缓存（用于浏览器崩溃时紧急保存）
        self._last_collected_data = None
        self._last_collected_time = 0  # 上次收集的时间戳

        # 进度文件路径（与 config 目录同级）
        self._progress_dir = self._get_progress_dir()
        self._progress_file = os.path.join(self._progress_dir, 'media_progress.json')
        self._backup_file = os.path.join(self._progress_dir, 'media_progress.json.bak')

    # ================================================================
    #  公共接口
    # ================================================================

    def start(self):
        """启动定时保存周期"""
        if self._running:
            return
        self._running = True
        self.logger.info("[进度守护] 已启动（每60秒保存一次）")
        self._schedule_next()

    def stop(self):
        """停止定时保存（不清除缓存数据，保留用于后续恢复）"""
        self._running = False
        if self._timer:
            self._timer.cancel()
            self._timer = None
        self.logger.info("[进度守护] 已停止")

    def save_now(self):
        """立即保存一次当前进度（用于页面卸载、浏览器崩溃等关键时刻）。
        
        优先从浏览器实时收集数据；若浏览器已死则使用最近缓存的媒体数据紧急写入。
        """
        saved = False
        # 1. 先尝试从浏览器实时收集（浏览器还活着时）
        try:
            if self.browser.page and self.browser.is_alive():
                self._collect_and_save()
                saved = True
        except Exception:
            pass

        # 2. 浏览器已死，使用缓存数据紧急保存
        if not saved and self._last_collected_data:
            try:
                cache_data = dict(self._last_collected_data)
                # 更新保存时间戳为当前时间（而非缓存时间）
                cache_data['savedAt'] = int(time.time() * 1000)
                cache_data['_fromCache'] = True  # 标记来源，便于调试
                self._save_to_file(cache_data)
                ct = cache_data.get('currentTime', 0)
                dur = cache_data.get('duration', 0)
                self.logger.info(
                    f"[进度守护] 浏览器已关闭，使用缓存紧急保存: "
                    f"{cache_data.get('tag', 'media')} {ct:.1f}s/{dur:.1f}s "
                    f"(缓存时间: {time.strftime('%H:%M:%S', time.localtime(self._last_collected_time / 1000))})")
                saved = True
            except Exception as e:
                self.logger.warning(f"[进度守护] 缓存紧急保存失败: {e}")

        if not saved:
            self.logger.debug("[进度守护] 立即保存失败：浏览器已关闭且无缓存数据")

    def restore_progress(self):
        """恢复播放进度。在页面导航完成后调用。

        流程：
        1. 从本地文件读取上次保存的进度
        2. 检查URL是否匹配当前页面
        3. 注入JS设置媒体元素的currentTime等属性
        4. 尝试自动播放
        """
        if self._is_restoring:
            return

        self._is_restoring = True
        try:
            data = self._load_from_file()
            if not data:
                self.logger.debug("[进度守护] 无可恢复的进度数据")
                return

            # 检查数据时效性
            saved_at = data.get('savedAt', 0)
            age_ms = time.time() * 1000 - saved_at
            if age_ms > self.MAX_AGE_SECONDS * 1000:
                self.logger.info("[进度守护] 进度数据已过期，跳过恢复")
                return

            age_sec = age_ms / 1000
            from_cache = data.get('_fromCache', False)
            ct = data.get('currentTime', 0)
            dur = data.get('duration', 0)
            saved_url = data.get('pageUrl', '')
            self.logger.info(
                f"[进度守护] 发现进度数据: {data.get('tag', 'media')} "
                f"{ct:.1f}s/{dur:.1f}s, 保存于 {age_sec:.0f}秒前"
                f"{' (缓存)' if from_cache else ''}")

            # 检查URL匹配（规范化比较）
            current_url = ''
            try:
                current_url = self._pw(lambda: self.browser.page.url)
            except Exception:
                pass

            if not self._url_match(saved_url, current_url):
                self.logger.info(
                    f"[进度守护] URL不匹配，跳过恢复 "
                    f"(保存: {saved_url[:60]}, 当前: {current_url[:60]})")
                return

            # 等待页面媒体元素就绪
            time.sleep(self.RESTORE_DELAY)

            # 注入恢复脚本
            self._do_restore(data)

        except Exception as e:
            self.logger.warning(f"[进度守护] 恢复进度失败: {e}")
        finally:
            self._is_restoring = False

    def set_pw_caller(self, caller_fn):
        """设置 Playwright 线程安全调用器"""
        self._pw_caller = caller_fn

    def update_cache_from_monitor(self, el_info, selector='', pw_sel=''):
        """由媒体监听循环调用，用最新检测到的媒体状态更新内部缓存。
        
        这确保浏览器崩溃时缓存中的数据尽可能接近崩溃瞬间，
        而不是依赖60秒一次的定时保存。
        
        Args:
            el_info: dict, 包含 currentTime/duration/paused/ended 等字段
            selector: 原始选择器字符串
            pw_sel: Playwright 兼容选择器
        """
        if not el_info or not isinstance(el_info, dict):
            return
        
        ct = el_info.get('currentTime', 0)
        dur = el_info.get('duration', 0)
        
        # 只缓存有效的播放数据
        if ct < self.MIN_PROGRESS_THRESHOLD:
            return
        if not isFinite_check(dur) or dur <= 0:
            return
        if el_info.get('ended', False):
            return

        try:
            # 从上一次缓存继承元数据（pageUrl, src 等），避免频繁 _pw 调用
            prev = self._last_collected_data or {}
            page_url = prev.get('pageUrl', '')
            element_id = prev.get('elementId', '')
            tag = prev.get('tag', 'video')
            src = prev.get('src', '')
            volume = el_info.get('volume', prev.get('volume', 1.0))
            muted = el_info.get('muted', prev.get('muted', False))
            playback_rate = el_info.get('playbackRate', prev.get('playbackRate', 1.0))

            # 每10秒尝试一次完整收集（含 _pw 调用），避免过于频繁
            now_ms = time.time() * 1000
            full_collect_interval = 10 * 1000  # 10秒
            if (now_ms - self._last_collected_time > full_collect_interval
                    and self.browser.page):
                try:
                    if self.browser.is_alive():
                        extra = self._pw(lambda: self.browser.page.evaluate("""(sel) => {
                            const el = document.querySelector(sel);
                            if (!el) return null;
                            return {
                                tag: el.tagName.toLowerCase(),
                                id: el.id || '',
                                src: el.currentSrc || el.src || '',
                                url: location.href,
                                title: document.title || '',
                                volume: el.volume,
                                muted: el.muted,
                                playbackRate: el.playbackRate || 1
                            };
                        }""", pw_sel))
                        if extra:
                            tag = extra.get('tag', tag)
                            element_id = extra.get('id', '')
                            src = extra.get('src', '')
                            page_url = extra.get('url', '')
                            volume = extra.get('volume', volume)
                            muted = extra.get('muted', muted)
                            playback_rate = extra.get('playbackRate', playback_rate)
                except Exception:
                    pass  # _pw 调用失败，使用继承的元数据

            # 生成元素标识哈希
            raw = page_url + '|' + tag + '|' + element_id + '|' + src
            hash_val = 0
            for ch in raw:
                hash_val = ((hash_val << 5) - hash_val) + ord(ch)
                hash_val |= 0
            media_id = 'media_' + format(abs(hash_val), 'x')[:8]

            percent = round(ct / dur * 1000) / 10 if dur > 0 else 0

            self._last_collected_data = {
                'id': media_id,
                'tag': tag,
                'currentTime': ct,
                'duration': dur,
                'percent': percent,
                'paused': el_info.get('paused', False),
                'ended': el_info.get('ended', False),
                'volume': volume,
                'muted': muted,
                'playbackRate': playback_rate,
                'src': src,
                'elementId': element_id,
                'pageUrl': page_url,
                'pageTitle': prev.get('pageTitle', ''),
                'savedAt': int(now_ms)
            }
            self._last_collected_time = now_ms
        except Exception:
            pass  # 缓存更新失败不影响主流程

    def clear_progress(self):
        """清除保存的进度数据"""
        try:
            with self._lock:
                for f in [self._progress_file, self._backup_file]:
                    if os.path.isfile(f):
                        try:
                            os.remove(f)
                        except Exception:
                            pass
            # 同时清除缓存和恢复标志
            self._last_collected_data = None
            self._last_collected_time = 0
            self._is_restoring = False
            self.logger.info("[进度守护] 进度数据已清除")
        except Exception as e:
            self.logger.warning(f"[进度守护] 清除进度数据失败: {e}")

    # ================================================================
    #  内部：线程安全的 Playwright 调用
    # ================================================================

    def _pw(self, fn):
        """线程安全执行 Playwright 操作"""
        if self._pw_caller and threading.current_thread() is not threading.main_thread():
            return self._pw_caller(fn)
        return fn()

    # ================================================================
    #  内部：定时保存
    # ================================================================

    def _schedule_next(self):
        """调度下一次保存"""
        if not self._running:
            return
        self._timer = threading.Timer(self.SAVE_INTERVAL, self._save_cycle)
        self._timer.daemon = True
        self._timer.start()

    def _save_cycle(self):
        """保存周期回调"""
        if not self._running:
            return
        try:
            self._collect_and_save()
        except Exception as e:
            self.logger.debug(f"[进度守护] 定时保存失败: {e}")
        finally:
            self._schedule_next()

    # ================================================================
    #  内部：收集与保存
    # ================================================================

    # 注入JS：收集页面中所有活跃媒体元素的信息
    _JS_COLLECT = """() => {
        const elements = document.querySelectorAll('video, audio');
        if (!elements || elements.length === 0) return null;

        let best = null;
        let bestScore = -1;

        for (const el of elements) {
            try {
                const ct = el.currentTime || 0;
                const dur = el.duration || 0;
                const paused = el.paused;
                const ended = el.ended;

                // 跳过未播放或已结束的
                if (ct < 1 || ended) continue;
                if (!isFinite(dur) || dur <= 0) continue;

                // 评分：播放中 > 暂停且进度大 > 其他
                let score = ct;
                if (!paused) score += dur;  // 正在播放的优先级最高

                if (score > bestScore) {
                    bestScore = score;
                    const src = el.currentSrc || el.src || '';
                    const elId = el.id || '';
                    const tag = el.tagName.toLowerCase();
                    // 生成元素标识
                    const raw = location.href + '|' + tag + '|' + elId + '|' + src;
                    let hash = 0;
                    for (let i = 0; i < raw.length; i++) {
                        hash = ((hash << 5) - hash) + raw.charCodeAt(i);
                        hash |= 0;
                    }
                    const mediaId = 'media_' + Math.abs(hash).toString(36);

                    let percent = 0;
                    if (dur > 0 && isFinite(dur)) {
                        percent = Math.round(ct / dur * 1000) / 10;
                    }

                    best = {
                        id: mediaId,
                        tag: tag,
                        currentTime: ct,
                        duration: dur,
                        percent: percent,
                        paused: paused,
                        ended: ended,
                        volume: el.volume,
                        muted: el.muted,
                        playbackRate: el.playbackRate || 1,
                        src: src,
                        elementId: elId,
                        pageUrl: location.href,
                        pageTitle: document.title || '',
                        savedAt: Date.now()
                    };
                }
            } catch (e) {
                // 单个元素收集失败不影响其他
            }
        }
        return best;
    }"""

    def _collect_and_save(self):
        """从浏览器收集媒体状态并保存到文件"""
        if self._is_restoring:
            return

        # 检查浏览器是否可用
        if not self.browser.page:
            return
        try:
            if not self.browser.is_alive():
                return
        except Exception:
            return

        try:
            media_info = self._pw(lambda: self.browser.page.evaluate(self._JS_COLLECT))
            if not media_info:
                return

            # 验证数据有效性
            ct = media_info.get('currentTime', 0)
            dur = media_info.get('duration', 0)
            if ct < self.MIN_PROGRESS_THRESHOLD:
                return
            if not isFinite_check(dur) or dur <= 0:
                return
            if media_info.get('ended', False):
                return

            self._save_to_file(media_info)
            # 缓存最近一次成功收集的数据（用于浏览器崩溃时紧急保存）
            self._last_collected_data = media_info
            self._last_collected_time = time.time() * 1000
            self.logger.debug(
                f"[进度守护] 已保存: {media_info['tag']} "
                f"{ct:.1f}s/{dur:.1f}s ({media_info.get('percent', 0):.1f}%)")

        except Exception as e:
            self.logger.debug(f"[进度守护] 收集媒体状态失败: {e}")

    # ================================================================
    #  内部：文件读写（原子操作 + 备份）
    # ================================================================

    def _save_to_file(self, data):
        """原子写入进度数据到JSON文件，并更新备份"""
        with self._lock:
            try:
                # 确保目录存在
                os.makedirs(self._progress_dir, exist_ok=True)

                json_str = json.dumps(data, ensure_ascii=False, indent=2)

                # 原子写入：先写临时文件，再重命名
                tmp_fd = None
                tmp_path = None
                try:
                    tmp_fd, tmp_path = tempfile.mkstemp(
                        suffix='.tmp', dir=self._progress_dir, text=True)
                    with os.fdopen(tmp_fd, 'w', encoding='utf-8') as f:
                        f.write(json_str)
                        f.flush()
                        os.fsync(f.fileno())

                    # Windows 上需要先删除目标文件
                    if os.path.exists(self._progress_file):
                        os.replace(tmp_path, self._progress_file)
                    else:
                        os.rename(tmp_path, self._progress_file)
                    tmp_path = None  # 已成功重命名
                except Exception:
                    # 清理临时文件
                    if tmp_path and os.path.exists(tmp_path):
                        try:
                            os.remove(tmp_path)
                        except Exception:
                            pass
                    raise

                # 更新备份文件（非阻塞，失败不影响主流程）
                try:
                    shutil.copy2(self._progress_file, self._backup_file)
                except Exception:
                    pass

            except Exception as e:
                self.logger.warning(f"[进度守护] 写入进度文件失败: {e}")

    def _load_from_file(self):
        """从JSON文件读取进度数据，主文件损坏时回退到备份"""
        with self._lock:
            # 尝试读取主文件
            data = self._try_load_file(self._progress_file)
            if data:
                return data

            # 区分"文件不存在"和"文件损坏"
            main_exists = os.path.isfile(self._progress_file)
            if main_exists:
                # 文件存在但读取失败 → 文件损坏
                self.logger.warning("[进度守护] 主进度文件已损坏，尝试备份文件...")
            else:
                # 文件不存在（可能刚被清除或首次运行），无需警告
                self.logger.debug("[进度守护] 主进度文件不存在")

            data = self._try_load_file(self._backup_file)
            if data:
                # 恢复主文件
                try:
                    shutil.copy2(self._backup_file, self._progress_file)
                    self.logger.info("[进度守护] 已从备份恢复进度文件")
                except Exception:
                    pass
                return data

            return None

    def _try_load_file(self, filepath):
        """尝试从指定文件读取并解析JSON数据"""
        if not os.path.isfile(filepath):
            return None
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            # 基本校验
            if not isinstance(data, dict):
                return None
            if 'currentTime' not in data or 'pageUrl' not in data:
                return None
            return data
        except (json.JSONDecodeError, IOError, OSError) as e:
            self.logger.debug(f"[进度守护] 读取文件失败 {filepath}: {e}")
            return None

    # ================================================================
    #  内部：恢复逻辑
    # ================================================================

    # 注入JS：等待媒体元素就绪
    _JS_WAIT_READY = """(mediaId) => {
        return new Promise((resolve) => {
            const findEl = () => {
                const elements = document.querySelectorAll('video, audio');
                for (const el of elements) {
                    try {
                        const src = el.currentSrc || el.src || '';
                        const elId = el.id || '';
                        const tag = el.tagName.toLowerCase();
                        const raw = location.href + '|' + tag + '|' + elId + '|' + src;
                        let hash = 0;
                        for (let i = 0; i < raw.length; i++) {
                            hash = ((hash << 5) - hash) + raw.charCodeAt(i);
                            hash |= 0;
                        }
                        const mid = 'media_' + Math.abs(hash).toString(36);
                        if (mid === mediaId) return el;
                    } catch (e) {}
                }
                return null;
            };

            const el = findEl();
            if (el && el.readyState >= 1) {
                resolve(el);
                return;
            }

            // 等待元素出现和metadata加载
            let waitCount = 0;
            const interval = setInterval(() => {
                waitCount++;
                const el = findEl();
                if (el && el.readyState >= 1) {
                    clearInterval(interval);
                    resolve(el);
                } else if (waitCount > 40) {  // 最多等8秒
                    clearInterval(interval);
                    resolve(el);  // 超时也返回，可能为null
                }
            }, 200);
        });
    }"""

    # 注入JS：恢复媒体播放状态
    _JS_RESTORE = """(data) => {
        const elements = document.querySelectorAll('video, audio');
        let restored = false;

        for (const el of elements) {
            try {
                const src = el.currentSrc || el.src || '';
                const elId = el.id || '';
                const tag = el.tagName.toLowerCase();
                const raw = location.href + '|' + tag + '|' + elId + '|' + src;
                let hash = 0;
                for (let i = 0; i < raw.length; i++) {
                    hash = ((hash << 5) - hash) + raw.charCodeAt(i);
                    hash |= 0;
                }
                const mid = 'media_' + Math.abs(hash).toString(36);

                if (mid === data.id || (data.elementId && elId === data.elementId)) {
                    // 设置播放进度
                    if (data.currentTime && isFinite(data.currentTime) && data.currentTime > 0) {
                        el.currentTime = data.currentTime;
                    }
                    // 恢复其他属性
                    if (data.volume !== undefined) el.volume = data.volume;
                    if (data.muted !== undefined) el.muted = data.muted;
                    if (data.playbackRate !== undefined) el.playbackRate = data.playbackRate;

                    restored = true;

                    // 如果之前是播放状态，尝试继续播放
                    if (!data.paused) {
                        el.play().catch(() => {
                            // 浏览器可能阻止自动播放
                            console.info('[进度守护] 自动播放被阻止，需要用户交互');
                        });
                    }

                    break;  // 只恢复第一个匹配的元素
                }
            } catch (e) {
                // 单个元素恢复失败不影响其他
            }
        }

        // 如果通过ID匹配失败，尝试按标签+src模糊匹配
        if (!restored && data.src) {
            for (const el of elements) {
                try {
                    const src = el.currentSrc || el.src || '';
                    if (src && data.src && (src.includes(data.src) || data.src.includes(src))) {
                        if (data.currentTime && isFinite(data.currentTime) && data.currentTime > 0) {
                            el.currentTime = data.currentTime;
                        }
                        if (data.volume !== undefined) el.volume = data.volume;
                        if (data.muted !== undefined) el.muted = data.muted;
                        if (data.playbackRate !== undefined) el.playbackRate = data.playbackRate;

                        if (!data.paused) {
                            el.play().catch(() => {});
                        }

                        restored = true;
                        break;
                    }
                } catch (e) {}
            }
        }

        // 最后兜底：如果仍然未恢复，对第一个有效媒体元素设置进度
        if (!restored) {
            for (const el of elements) {
                try {
                    const dur = el.duration;
                    if (dur && isFinite(dur) && dur > 0 && data.currentTime < dur) {
                        el.currentTime = data.currentTime;
                        if (data.volume !== undefined) el.volume = data.volume;
                        if (data.muted !== undefined) el.muted = data.muted;
                        if (!data.paused) {
                            el.play().catch(() => {});
                        }
                        restored = true;
                        break;
                    }
                } catch (e) {}
            }
        }

        return restored;
    }"""

    def _do_restore(self, data):
        """执行恢复操作"""
        try:
            if not self.browser.page:
                return

            result = self._pw(lambda: self.browser.page.evaluate(self._JS_RESTORE, data))

            if result:
                ct = data.get('currentTime', 0)
                dur = data.get('duration', 0)
                pct = data.get('percent', 0)
                self.logger.info(
                    f"[进度守护] 已恢复播放进度: {data.get('tag', 'media')} "
                    f"→ {ct:.1f}s / {dur:.1f}s ({pct:.1f}%)")
            else:
                self.logger.info("[进度守护] 未找到匹配的媒体元素，跳过恢复")

        except Exception as e:
            self.logger.warning(f"[进度守护] 恢复脚本执行失败: {e}")

    # ================================================================
    #  内部：工具函数
    # ================================================================

    def _url_match(self, saved_url, current_url):
        """检查两个URL是否匹配（规范化比较，忽略hash和查询参数）"""
        if not saved_url or not current_url:
            return False
        try:
            from urllib.parse import urlparse
            s = urlparse(saved_url)
            c = urlparse(current_url)
            # 比较 origin + pathname
            return s.scheme == c.scheme and s.netloc == c.netloc and s.path == c.path
        except Exception:
            # 解析失败时做简单字符串比较
            return saved_url.split('?')[0].split('#')[0] == current_url.split('?')[0].split('#')[0]

    @staticmethod
    def _get_progress_dir():
        """获取进度文件存储目录"""
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return os.path.join(base_dir, 'config')


def isFinite_check(val):
    """检查值是否为有限数字（Python端，对应JS的isFinite）"""
    try:
        return val is not None and val != float('inf') and val != float('-inf') and not (val != val)
    except Exception:
        return False
