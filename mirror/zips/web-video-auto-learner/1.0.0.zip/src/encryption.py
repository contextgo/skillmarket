"""
登录信息加密模块

使用 Fernet（基于 AES-128-CBC）对 Playwright 的 storage_state 进行加密存储。
密钥通过 PBKDF2HMAC 从设备特征派生，确保同一设备上自动解密，
同时防止简单复制文件到其他设备后直接读取。

设计要点：
1. 密钥派生：PBKDF2HMAC-SHA256，迭代次数 100000，盐值随机生成并存储在加密文件中
2. 加密算法：Fernet（AES-128-CBC + HMAC-SHA256）
3. 密钥存储：基于设备特征（机器名+用户名）的派生密钥，无需用户记忆密码
4. 文件格式：salt + encrypted_data（二进制格式）
"""

import os
import base64
import json
import hashlib
from pathlib import Path

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend


# ============================================================
#  密钥管理
# ============================================================

def _get_device_salt():
    """获取/创建设备唯一的盐值。

    盐值保存在用户目录下的隐藏文件中（~/.webvideo_salt）。
    同一设备上所有实例共享同一个盐值，确保密钥一致性。
    """
    salt_file = Path.home() / ".webvideo_salt"
    if salt_file.exists():
        return salt_file.read_bytes()
    else:
        # 首次运行，生成随机盐值并保存
        salt = os.urandom(16)
        salt_file.write_bytes(salt)
        # 尝试设置文件权限（Windows 下无效，但 Linux/Mac 下可限制读取）
        try:
            salt_file.chmod(0o600)
        except Exception:
            pass
        return salt


def _derive_key(password: bytes, salt: bytes) -> bytes:
    """从密码和盐值派生 Fernet 密钥。

    Args:
        password: 用于派生密钥的密码（字节串）
        salt: 盐值（16字节随机数据）

    Returns:
        base64 编码的 Fernet 密钥（字节串）
    """
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,           # Fernet 需要 32 字节密钥
        salt=salt,
        iterations=100000,   # 迭代次数，平衡安全性和性能
        backend=default_backend()
    )
    key = base64.urlsafe_b64encode(kdf.derive(password))
    return key


def _get_encryption_key():
    """获取加密密钥。

    密钥派生策略：
    1. 使用设备特征（机器名 + 用户名）作为密码基础
    2. 使用设备盐值（保存在 ~/.webvideo_salt）作为盐值
    3. 派生得到 Fernet 密钥

    这样即使复制 storage_state.enc 文件到另一台设备，
    由于盐值不同，也无法解密。
    """
    import socket
    import getpass

    # 设备特征：机器名 + 用户名（确保同一用户同一设备上密钥一致）
    device_id = f"{socket.gethostname()}_{getpass.getuser()}".encode("utf-8")
    salt = _get_device_salt()
    return _derive_key(device_id, salt)


# ============================================================
#  加密 / 解密接口
# ============================================================

def encrypt_storage_state(storage_state: dict) -> bytes:
    """加密 storage_state 字典，返回二进制密文。

    Args:
        storage_state: Playwright 的 storage_state 字典
                         （通常由 context.storage_state() 获取）

    Returns:
        加密后的二进制数据（包含盐值和密文）
    """
    key = _get_encryption_key()
    fernet = Fernet(key)

    # 将字典序列化为 JSON 字节串
    plaintext = json.dumps(storage_state, ensure_ascii=False).encode("utf-8")

    # 加密
    ciphertext = fernet.encrypt(plaintext)

    return ciphertext


def decrypt_storage_state(encrypted_data: bytes) -> dict:
    """解密 storage_state 密文，返回原始字典。

    Args:
        encrypted_data: 加密后的二进制数据

    Returns:
        解密后的 storage_state 字典
    """
    key = _get_encryption_key()
    fernet = Fernet(key)

    # 解密
    plaintext = fernet.decrypt(encrypted_data)

    # 反序列化为字典
    storage_state = json.loads(plaintext.decode("utf-8"))
    return storage_state


def save_encrypted_storage_state(storage_state: dict, filepath: str):
    """加密并保存 storage_state 到文件。

    文件格式：直接保存 Fernet 加密后的二进制数据。

    Args:
        storage_state: Playwright 的 storage_state 字典
        filepath: 保存路径（通常为 storage_state.enc）
    """
    ciphertext = encrypt_storage_state(storage_state)
    with open(filepath, "wb") as f:
        f.write(ciphertext)


def load_encrypted_storage_state(filepath: str) -> dict:
    """从加密文件加载并解密 storage_state。

    Args:
        filepath: 加密文件路径（通常为 storage_state.enc）

    Returns:
        解密后的 storage_state 字典
    """
    with open(filepath, "rb") as f:
        encrypted_data = f.read()
    return decrypt_storage_state(encrypted_data)


# ============================================================
#  密钥更新工具（可选功能）
# ============================================================

def re_encrypt_file(old_password: bytes, new_password: bytes, filepath: str):
    """重新加密文件（如果密码需要更新）。

    Args:
        old_password: 旧密码
        new_password: 新密码
        filepath: 加密文件路径
    """
    # 用旧密钥解密
    old_salt = _get_device_salt()
    old_key = _derive_key(old_password, old_salt)
    fernet_old = Fernet(old_key)
    with open(filepath, "rb") as f:
        plaintext = fernet_old.decrypt(f.read())

    # 用新密钥加密
    new_salt = os.urandom(16)
    new_key = _derive_key(new_password, new_salt)
    fernet_new = Fernet(new_key)
    ciphertext = fernet_new.encrypt(plaintext)

    # 保存新盐值和新密文
    with open(filepath, "wb") as f:
        f.write(new_salt + ciphertext)


if __name__ == "__main__":
    # 测试代码
    test_data = {
        "cookies": [{"name": "session", "value": "abc123", "domain": "example.com"}],
        "origins": []
    }

    print("测试加密/解密...")
    enc = encrypt_storage_state(test_data)
    print(f"加密后长度: {len(enc)} 字节")

    dec = decrypt_storage_state(enc)
    print(f"解密后数据: {json.dumps(dec, ensure_ascii=False, indent=2)}")

    # 测试文件保存/加载
    test_file = "test_enc.enc"
    save_encrypted_storage_state(test_data, test_file)
    loaded = load_encrypted_storage_state(test_file)
    print(f"文件加载解密后: {json.dumps(loaded, ensure_ascii=False, indent=2)}")

    # 清理测试文件
    os.remove(test_file)
    print("测试完成！")
