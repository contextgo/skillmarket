import yaml
import os
import sys
import copy
import logging


def _get_app_dir():
    """获取应用程序根目录（支持打包后的 exe 和开发环境）"""
    if getattr(sys, 'frozen', False):
        # 打包后的 exe：使用 exe 所在目录
        return os.path.dirname(sys.executable)
    else:
        # 开发环境：使用 skill 目录（config_loader.py 的父级/src/的祖父级）
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# 默认配置（首次启动时使用）
DEFAULT_CONFIG = {
    'settings': {
        'browser_type': 'chrome',
        'window_max': True,
        'global_timeout': 60000,
        'loop_run': False,
        'retry_count': 2,
        'popup_scan_interval': 0.5,
        'auto_answer': False,  # 自动答题开关，默认关闭
    },
    'website': {
        'login_url': '',
        'wait_after_login': 30,
        'storage_state': False,
        'storage_state_file': 'storage_state.enc',
    },
    'navigation': [],
    'popup_rules': [],
}


class ConfigLoader:
    def __init__(self, config_path=None):
        if config_path is None:
            config_path = os.path.join(_get_app_dir(), 'config', 'config.yaml')
        self.config_path = config_path
        self.config = {}
        self._is_first_run = False  # 标记是否为首次运行（配置文件不存在时自动创建）

    @property
    def is_first_run(self):
        """是否是首次运行（配置文件由程序自动创建）"""
        return self._is_first_run

    def load(self):
        """加载配置文件。若文件不存在，自动创建包含默认值的配置文件。"""
        config_dir = os.path.dirname(self.config_path)

        if not os.path.isfile(self.config_path):
            # 配置文件不存在，创建默认配置
            self._is_first_run = True
            try:
                os.makedirs(config_dir, exist_ok=True)
                self.config = copy.deepcopy(DEFAULT_CONFIG)
                self.save()
                logging.getLogger(__name__).info(f"配置文件不存在，已创建默认配置: {self.config_path}")
            except Exception as e:
                logging.getLogger(__name__).warning(f"创建默认配置失败: {e}")
                self.config = copy.deepcopy(DEFAULT_CONFIG)
            return self.config

        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self.config = yaml.safe_load(f) or {}
            # 合并缺失的默认配置项（保证向后兼容）
            self._merge_defaults()
            return self.config
        except Exception as e:
            raise RuntimeError(f"配置文件加载失败: {e}")

    def _merge_defaults(self):
        """将默认配置中缺失的键合并到当前配置（不覆盖已有值）。"""
        for section, defaults in DEFAULT_CONFIG.items():
            if isinstance(defaults, dict):
                current = self.config.get(section, {})
                if not isinstance(current, dict):
                    current = {}
                for key, default_val in defaults.items():
                    if key not in current:
                        current[key] = default_val
                self.config[section] = current
            elif section not in self.config:
                self.config[section] = copy.deepcopy(defaults)

    def save(self):
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, 'w', encoding='utf-8') as f:
                yaml.dump(self.config, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
            return True
        except Exception as e:
            raise RuntimeError(f"配置文件保存失败: {e}")

    def get_settings(self):
        return self.config.get('settings', {})

    def get_website(self):
        return self.config.get('website', {})

    def get_navigation(self):
        return self.config.get('navigation', [])

    def get_popup_rules(self):
        return self.config.get('popup_rules', [])

    def is_auto_answer_enabled(self):
        """获取自动答题开关状态，默认关闭"""
        return self.config.get('auto_answer', False)

    def set_auto_answer(self, enabled):
        """设置自动答题开关"""
        self.config['auto_answer'] = enabled

    def set_settings(self, settings):
        self.config['settings'] = settings

    def set_website(self, website):
        self.config['website'] = website

    def set_navigation(self, navigation):
        self.config['navigation'] = navigation

    def set_popup_rules(self, popup_rules):
        self.config['popup_rules'] = popup_rules

    def validate_for_run(self):
        """检查运行自动化所需的必要配置项是否已设置。

        Returns:
            list[str]: 未配置的必要项列表（空列表表示全部就绪）
        """
        missing = []

        # 1. 检查 navigation 步骤列表
        nav = self.get_navigation()
        if not nav:
            missing.append('navigation')

        # 2. 检查 website.login_url
        website = self.get_website()
        login_url = website.get('login_url', '').strip()
        if not login_url:
            missing.append('login_url')

        return missing
