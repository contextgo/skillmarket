import time
import threading
import json
import random
import os

# 音频录制模块
try:
    from .web_audio_recorder import WebAudioRecorder
    _AUDIO_RECORDER_AVAILABLE = True
except ImportError:
    _AUDIO_RECORDER_AVAILABLE = False
    WebAudioRecorder = None


class TaskRunner:
    def __init__(self, browser, popup_handler, navigation_list, logger, settings, config_loader=None):
        self.browser = browser
        self.popup_handler = popup_handler
        self.navigation_list = navigation_list
        self.logger = logger
        self.settings = settings
        self.config_loader = config_loader
        self.running = False
        self.paused = False
        # 音频录制器实例
        self._audio_recorder = None
        self._current_recording_path = None
        # 单步调试
        self.step_mode = False          # 是否为单步模式
        self.step_ready = threading.Event()  # 单步等待信号
        self.current_step_index = -1    # 当前执行步骤索引
        self.current_step_info = {}     # 当前步骤调试信息
        # 最后步骤手动结束
        self.manual_end_event = threading.Event()  # 最后步骤手动结束信号
        self.waiting_manual_end = False              # 是否正在等待手动结束
        # 浏览器恢复机制
        self._browser_recovering = False          # 浏览器是否正在恢复中
        self._browser_recovery_event = threading.Event()  # 浏览器恢复完成信号
        self._browser_died = False             # 浏览器是否已死亡（由后台线程设置，主线程消费）
        self._browser_died_lock = threading.Lock()  # 防止竞争
        # 浏览器进程意外退出关键词（用于识别浏览器死亡异常）
        self._BROWSER_DEATH_KEYWORDS = (
            'browser has been closed',
            'context has been closed',
            'page has been closed',
            'target closed',
            'connection closed',
            'cdp connection',
            'browser or context is closing',
        )
        # Playwright 线程安全调用器（由 ControlPanel 设置）
        self._pw_call = None  # fn -> result，确保 Playwright 调用在主线程执行
        # 播放列表项完成回调（由 ControlPanel 设置，在主线程调度执行）
        self._on_play_list_completed_cb = None
        # 浏览器恢复：ControlPanel 引用（由 ControlPanel 设置，用于后台线程唤醒主线程）
        self.control_panel = None
        # 媒体进度守护器（由 main.py 设置）
        self.progress_saver = None

    def set_pw_caller(self, caller_fn):
        """设置 Playwright 线程安全调用器。
        caller_fn(fn) -> result：将 fn 调度到主线程执行并返回结果。
        """
        self._pw_call = caller_fn

    def set_on_play_list_completed_cb(self, cb):
        """设置播放列表项完成回调。
        cb()：在主线程中执行，用于同步完成状态到 GUI 和配置文件。
        """
        self._on_play_list_completed_cb = cb

    def set_browser_recovering(self, recovering):
        """设置浏览器恢复中状态。
        当浏览器被意外关闭时，由 GUI 主线程调用此方法通知任务运行器。
        recovering=True: 浏览器正在恢复，后台线程应暂停 Playwright 调用
        recovering=False: 浏览器恢复完成，后台线程可以继续执行
        """
        self._browser_recovering = recovering
        if not recovering:
            self._browser_recovery_event.set()

    def _check_browser_death(self, e):
        """检查异常是否由浏览器死亡/断开连接引起。

        Args:
            e: Exception 对象

        Returns:
            bool: 是否是浏览器死亡异常
        """
        msg = str(e).lower()
        # 1. 通过异常消息中的关键词判断
        if any(k in msg for k in self._BROWSER_DEATH_KEYWORDS):
            return True
        # 2. JavaScript 执行错误（如 TypeError: Cannot read properties of undefined）
        #    可能是浏览器已关闭但 Playwright 未正确抛出连接断开异常
        #    通过检查浏览器内部状态标志判断（不调用 Playwright API，线程安全）
        if 'evaluate' in msg and ('typeerror' in msg or 'error' in msg):
            b = self.browser
            if b._closed or not b.browser or not b.context or not b.page:
                self.logger.warning("[浏览器死亡检测] JavaScript 执行异常 + 浏览器对象已失效，判定为浏览器已关闭")
                return True
        return False

    def _check_page_navigated_away(self, e, pw_sel=''):
        """检查异常是否由页面意外跳转导致媒体元素消失。

        与浏览器死亡的区别：浏览器仍活着，但页面URL已变，媒体元素不再存在。

        Args:
            e: Exception 对象
            pw_sel: Playwright 兼容选择器

        Returns:
            bool: 是否是页面跳转导致元素消失
        """
        msg = str(e).lower()
        # 只处理 JavaScript 执行中的 null 引用错误
        if 'evaluate' not in msg:
            return False
        if 'null' not in msg and 'undefined' not in msg:
            return False

        # 浏览器必须仍然活着
        try:
            alive = self.browser.is_alive()
            if not alive:
                return False  # 浏览器已死，这不是页面跳转
        except Exception:
            return False

        # 确认页面URL已改变（与缓存中的pageUrl不同）
        try:
            current_url = self._pw(lambda: self.browser.page.url) if self.browser.page else ''
            if self.progress_saver and self.progress_saver._last_collected_data:
                saved_url = self.progress_saver._last_collected_data.get('pageUrl', '')
                if saved_url and current_url and not self._url_match_for_nav(saved_url, current_url):
                    self.logger.warning(
                        f"[页面跳转检测] 页面已意外跳转!\n"
                        f"  原页面: {saved_url[:80]}\n"
                        f"  当前页面: {current_url[:80]}")
                    return True
        except Exception:
            pass

        # 即使URL比较失败，如果元素确实不存在了，也可能是跳转
        try:
            el_exists = self._pw(lambda: self.browser.page.evaluate(
                f"(sel) => document.querySelector(sel) !== null", pw_sel))
            if not el_exists:
                self.logger.warning("[页面跳转检测] 媒体元素已消失，可能是页面跳转")
                return True
        except Exception:
            pass

        return False

    def _url_match_for_nav(self, url1, url2):
        """判断两个URL是否属于同一页面（用于导航检测，比进度恢复更宽松）。

        只比较 origin + pathname，忽略查询参数和哈希。
        """
        try:
            from urllib.parse import urlparse
            p1 = urlparse(url1)
            p2 = urlparse(url2)
            return p1.scheme == p2.scheme and p1.netloc == p2.netloc and p1.path == p2.path
        except Exception:
            return url1 == url2

    def _handle_page_navigated_away(self, pw_sel=''):
        """处理页面意外跳转：保存进度缓存，尝试导航回原页面并恢复播放。

        Returns:
            dict: 播放结果。restored=True 表示恢复成功，调用方应继续等待播放。
        """
        # 1. 紧急保存缓存进度
        if self.progress_saver:
            self.progress_saver.save_now()
            self.logger.info("[页面跳转恢复] 已用缓存紧急保存进度")

        # 2. 获取原页面URL
        saved_url = ''
        if self.progress_saver and self.progress_saver._last_collected_data:
            saved_url = self.progress_saver._last_collected_data.get('pageUrl', '')

        if not saved_url:
            self.logger.warning("[页面跳转恢复] 无缓存URL，无法导航回原页面")
            return {
                'success': False,
                'reason': 'page_navigated_away_no_cache',
                'duration': 0,
                'currentTime': 0
            }

        # 3. 尝试导航回原页面
        self.logger.info(f"[页面跳转恢复] 尝试导航回原页面: {saved_url[:80]}")
        try:
            self._pw(lambda: self.browser.page.goto(saved_url, wait_until='domcontentloaded', timeout=15000))
            # 等待页面充分加载（xgplayer 等播放器需要时间初始化）
            time.sleep(5)

            # 4. 检查媒体元素是否已存在
            el_exists = self._pw(lambda: self.browser.page.evaluate(
                f"(sel) => document.querySelector(sel) !== null", pw_sel))

            # 5. 如果媒体元素不存在，尝试触发 xgplayer（和正常播放流程一致）
            if not el_exists:
                self.logger.info("[页面跳转恢复] 媒体元素未找到，尝试触发 xgplayer...")
                trigger_ok = self._pw(lambda: self.browser.trigger_xgplayer())
                if trigger_ok:
                    self.logger.info("[页面跳转恢复] xgplayer 触发成功")
                    # 等待 video 元素出现
                    try:
                        self._pw(lambda: self.browser.page.wait_for_selector(
                            'video', state='attached', timeout=8000))
                    except Exception:
                        pass
                    # 重新检查
                    el_exists = self._pw(lambda: self.browser.page.query_selector('video') is not None)

            # 6. 二次回退：尝试点击页面中央触发播放
            if not el_exists:
                self.logger.info("[页面跳转恢复] 仍无媒体元素，尝试点击页面中央...")
                try:
                    viewport = self._pw(lambda: self.browser.page.viewport_size)
                    if viewport:
                        cx, cy = viewport['width'] // 2, viewport['height'] // 2
                        self._pw(lambda: self.browser.page.mouse.click(cx, cy))
                        time.sleep(3)
                        el_exists = self._pw(lambda: self.browser.page.query_selector('video') is not None)
                except Exception:
                    pass

            if el_exists:
                self.logger.info("[页面跳转恢复] 已成功导航回原页面，媒体元素已恢复")
                # 重新注入页面端脚本（导航后页面是全新的，旧脚本已丢失）
                try:
                    self._pw(lambda: self.browser.inject_media_monitor())
                    self._pw(lambda: self.browser.inject_progress_saver())
                except Exception:
                    pass
                # 恢复进度守护，触发进度恢复（设置 currentTime 并自动播放）
                if self.progress_saver:
                    self.progress_saver.restore_progress()
                return {
                    'success': False,
                    'reason': 'page_navigated_and_restored',
                    'duration': 0,
                    'currentTime': 0,
                    'restored': True
                }
            else:
                self.logger.warning("[页面跳转恢复] 导航回原页面后媒体元素仍未找到（已尝试 xgplayer 触发和点击回退）")
                return {
                    'success': False,
                    'reason': 'page_navigated_away_element_missing',
                    'duration': 0,
                    'currentTime': 0
                }
        except Exception as nav_e:
            self.logger.warning(f"[页面跳转恢复] 导航回原页面失败: {nav_e}")
            return {
                'success': False,
                'reason': 'page_navigated_away_nav_failed',
                'duration': 0,
                'currentTime': 0
            }

    def _signal_browser_died(self):
        """由后台线程调用，通知主线程浏览器已死亡。
        
        设置 _browser_died 标志，并立即唤醒主线程处理恢复。
        """
        with self._browser_died_lock:
            if not self._browser_died:  # 避免重复通知
                self._browser_died = True
                self.logger.warning("[TaskRunner] 已通知主线程：浏览器已关闭，等待恢复...")
        
        # 立即唤醒主线程（通过 after(0, ...) 触发立即检测，无需等待下次轮询）
        if self.control_panel:
            try:
                self.control_panel.root.after(0, self.control_panel._poll_browser_alive)
                self.logger.info("[TaskRunner] 已唤醒主线程的浏览器监控")
            except Exception as e:
                self.logger.warning(f"[TaskRunner] 唤醒主线程失败: {e}")

    def _notify_play_list_completed(self):
        """通知 GUI 播放列表项已完成，触发状态同步和界面刷新。
        通过 _pw_call 调度到主线程执行，避免跨线程 GUI 操作。
        """
        if self._on_play_list_completed_cb and self._pw_call:
            try:
                self._pw_call(self._on_play_list_completed_cb)
            except Exception:
                pass

    def _pw(self, fn):
        """线程安全执行 Playwright 操作。如在主线程则直接执行，否则通过调用器调度。
        当浏览器正在恢复中时，后台线程会等待恢复完成后再执行。
        """
        if self._browser_recovering and threading.current_thread() is not threading.main_thread():
            self.logger.info("[线程安全调用] 浏览器恢复中，等待恢复完成...")
            self._browser_recovery_event.wait(timeout=60)
            self._browser_recovery_event.clear()
            self.logger.info("[线程安全调用] 浏览器恢复完成，继续执行")
        if self._pw_call and threading.current_thread() is not threading.main_thread():
            return self._pw_call(fn)
        return fn()

    # ================================================================
    #  音频录制功能
    # ================================================================

    def _get_recordings_dir(self) -> str:
        """获取录音文件保存目录"""
        recordings_dir = self.settings.get('recordings_dir', 'recordings')
        if not os.path.isabs(recordings_dir):
            # 相对于 skill 目录
            skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            recordings_dir = os.path.join(skill_dir, recordings_dir)
        os.makedirs(recordings_dir, exist_ok=True)
        return recordings_dir

    def _start_audio_recording(self, url: str) -> bool:
        """启动音频录制（线程安全版本）- 同时注入并启动

        Args:
            url: 当前播放的 URL（用于生成文件名）

        Returns:
            bool: 是否成功启动
        """
        # 先注入
        if not self._inject_audio_recorder(url):
            return False
        # 再启动
        return self._start_audio_recording_only()

    # 用户界面格式名 → 内部格式枚举映射
    _FORMAT_MAP = {
        'WEBM': 'webm_opus',
        'WAV': 'wav',
        'MP3': 'mp3',
        'M4A': 'm4a',
        'webm': 'webm_opus',
        'wav': 'wav',
        'mp3': 'mp3',
        'm4a': 'm4a',
    }

    # 内部格式 → 文件扩展名映射
    _FORMAT_EXT_MAP = {
        'webm_opus': 'webm',
        'webm_vorbis': 'webm',
        'webm': 'webm',
        'wav': 'wav',
        'mp3': 'mp3',
        'm4a': 'm4a',
    }

    def _inject_audio_recorder(self, url: str, recording_format: str = 'webm') -> bool:
        """注入音频录制器 JavaScript（仅注入，不启动）

        Args:
            url: 当前播放的 URL（用于生成文件名）
            recording_format: 录音格式 (WEBM/WAV/MP3/M4A)

        Returns:
            bool: 是否成功注入
        """
        if not _AUDIO_RECORDER_AVAILABLE:
            return False

        try:
            # 清理之前的录音器
            if self._audio_recorder:
                self._audio_recorder.cleanup()
                self._audio_recorder = None

            # 将格式映射到内部枚举值
            internal_format = self._FORMAT_MAP.get(recording_format.upper() if recording_format else 'webm', 'webm_opus')
            file_ext = self._FORMAT_EXT_MAP.get(internal_format, 'webm')

            # 生成输出文件名
            recordings_dir = self._get_recordings_dir()
            import hashlib
            url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
            timestamp = time.strftime('%Y%m%d_%H%M%S')
            self._current_recording_path = os.path.join(
                recordings_dir, f'audio_{timestamp}_{url_hash}.{file_ext}'
            )

            # 定义要在主线程执行的注入操作
            def do_inject_and_set_recorder():
                """在主线程中创建录音器并注入 JS"""
                # 在主线程中创建录音器实例
                self._audio_recorder = WebAudioRecorder(config={
                    'output_dir': recordings_dir,
                    'format': internal_format
                })

                page = self.browser.page
                if not page:
                    self.logger.error("[音频录制] 无法获取页面对象")
                    return False

                if not self._audio_recorder.inject(page):
                    self.logger.error("[音频录制] JavaScript 注入失败")
                    return False

                self.logger.info("[音频录制] JavaScript 注入成功")
                return True

            # 使用线程安全的方式执行
            if self._pw_call:
                # 调度到主线程执行并获取结果
                result = self._pw_call(do_inject_and_set_recorder)
                return result if result else False
            else:
                # 如果在主线程中，直接执行
                return do_inject_and_set_recorder()

        except Exception as e:
            self.logger.error(f"[音频录制] 注入异常: {e}")
            return False

    def _start_audio_recording_only(self) -> bool:
        """启动已注入的音频录制器（假设 JS 已注入，只调用 start）

        Returns:
            bool: 是否成功启动
        """
        if not _AUDIO_RECORDER_AVAILABLE:
            return False

        if not self._audio_recorder:
            self.logger.error("[音频录制] 录制器未初始化")
            return False

        try:
            def do_start():
                """在主线程中启动录制器"""
                try:
                    result = self._audio_recorder.start()
                    if result and result.get('success'):
                        self.logger.info(f"[音频录制] 已启动: {self._current_recording_path}")
                    return result
                except Exception as e:
                    self.logger.error(f"[音频录制] 启动异常: {e}")
                    return {'success': False, 'error': str(e)}

            # 使用线程安全的方式执行
            if self._pw_call:
                result = self._pw_call(do_start)
            else:
                result = do_start()

            if result and result.get('success'):
                return True
            else:
                error = result.get('error', 'unknown') if result else 'unknown'
                self.logger.error(f"[音频录制] 启动失败: {error}")
                return False

        except Exception as e:
            self.logger.error(f"[音频录制] 启动异常: {e}")
            return False

    def _stop_audio_recording(self, url: str) -> dict:
        """停止音频录制

        Args:
            url: 当前播放的 URL

        Returns:
            dict: 录制结果，包含 success, path, duration 等
        """
        if not self._audio_recorder:
            # 录制器不存在（可能未启动或已被清理），静默返回
            return {'success': False, 'error': 'recorder not initialized'}

        saved_path = None
        try:
            def do_stop():
                """在主线程中停止录制器并保存"""
                return self._audio_recorder.stop(save=True, output_path=self._current_recording_path)

            # 使用线程安全的方式执行（page.evaluate 必须在创建页面的主线程 greenlet 上运行）
            if self._pw_call:
                result = self._pw_call(do_stop, timeout=20)
            else:
                result = do_stop()

            if result and result.get('success'):
                saved_path = result.get('path')
                self.logger.info(
                    f"[音频录制] 已保存: {saved_path or 'unknown'} "
                    f"(时长: {result.get('duration', 0):.1f}s, "
                    f"大小: {result.get('size', 0) / 1024:.1f}KB)"
                )
                return result
            else:
                self.logger.error(f"[音频录制] 保存失败: {result.get('error', 'unknown') if result else 'no result'}")
                # 保存失败但仍返回路径信息供后续使用
                return {'success': False, 'error': result.get('error', 'unknown') if result else 'no result',
                        'path': self._current_recording_path}

        except Exception as e:
            self.logger.error(f"[音频录制] 停止异常: {e}")
            # 超时或异常时，尝试通过 getData 获取已有数据
            fallback_result = self._try_save_recording_fallback()
            if fallback_result and fallback_result.get('success'):
                return fallback_result
            # 返回失败结果，但保留路径信息
            return {'success': False, 'error': str(e), 'path': self._current_recording_path}

        finally:
            # 清理录音器
            try:
                def do_cleanup():
                    self._audio_recorder.cleanup()
                if self._pw_call:
                    self._pw_call(do_cleanup, timeout=5)
                else:
                    do_cleanup()
            except Exception:
                pass
            self._audio_recorder = None
            # 保留 _current_recording_path 直到调用方处理完毕（不在此处清空）

    def _try_save_recording_fallback(self) -> dict | None:
        """超时后的降级保存：尝试通过 getData 获取浏览器中已录制的音频数据

        Returns:
            dict | None: 保存成功返回结果，失败返回 None
        """
        if not self._audio_recorder:
            return None

        try:
            self.logger.info("[音频录制] 尝试降级保存（getData 方式）...")

            def do_get_data():
                """在主线程中获取已录制的音频数据（不停止录制器）"""
                try:
                    page = getattr(self._audio_recorder, '_page', None)
                    if not page:
                        return None
                    # 调用 JS 端的 getData 方法（不触发 stop/cleanup）
                    data = page.evaluate(
                        "() => {"
                        "  const rec = window.__web_audio_recorder__;"
                        "  if (!rec || !rec.chunks || rec.chunks.length === 0) return null;"
                        "  const blob = new Blob(rec.chunks, {type: rec.options?.mimeType || 'audio/webm'});"
                        "  return new Promise((resolve) => {"
                        "    const reader = new FileReader();"
                        "    reader.onloadend = () => {"
                        "      const base64 = reader.result.split(',')[1] || '';"
                        "      resolve({success: true, base64: base64, "
                        "              duration: rec.chunks.length, size: blob.size});"
                        "    };"
                        "    reader.readAsDataURL(blob);"
                        "  });"
                        "}"
                    )
                    return data
                except Exception as e:
                    self.logger.warning(f"[音频录制] getData 调用失败: {e}")
                    return None

            if self._pw_call:
                result = self._pw_call(do_get_data, timeout=15)
            else:
                result = do_get_data()

            if not result or not result.get('success') or not result.get('base64'):
                self.logger.warning("[音频录制] 降级保存未获取到数据")
                return None

            # 将 base64 数据写入文件
            import base64
            output_path = self._current_recording_path
            if output_path:
                audio_data = base64.b64decode(result['base64'])
                with open(output_path, 'wb') as f:
                    f.write(audio_data)
                file_size = len(audio_data)
                self.logger.info(
                    f"[音频录制] 降级保存成功: {output_path} (大小: {file_size / 1024:.1f}KB)"
                )
                return {
                    'success': True,
                    'path': output_path,
                    'size': file_size,
                    'duration': result.get('duration', 0),
                    'fallback': True
                }

        except Exception as e:
            self.logger.warning(f"[音频录制] 降级保存失败: {e}")

        return None

    def cleanup_audio_recorder(self):
        """清理音频录制器资源（保存录音后再清理）"""
        if self._audio_recorder:
            try:
                # 保存正在录制的音频（而非丢弃）
                def do_cleanup():
                    self._audio_recorder.cleanup(save=True, output_path=self._current_recording_path)
                # cleanup 内部会调用 stop() -> page.evaluate()，必须在主线程执行
                if self._pw_call:
                    self._pw_call(do_cleanup, timeout=15)
                else:
                    do_cleanup()
            except Exception:
                pass
            self._audio_recorder = None
            # 保留路径信息直到配置保存完成

    # ================================================================
    #  媒体播放等待
    # ================================================================

    def _wait_media_ended_safe(self, selector, timeout=3600.0, on_media_started=None):
        """线程安全的媒体播放等待，不会阻塞主线程。

        解决问题：
        - 不能将整个 wait_for_media_ended 通过 _pw 调度到主线程（会因 60s 超时而崩溃）
        - 不能在主线程中 while 循环（会阻塞 Tkinter 事件循环，导致弹窗监听失效）

        方案：分段调度
        - _start_media_wait（初始化，<5s）通过 _pw 单次调度
        - _check_media_ended（单次检查，<3s）每次通过 _pw 调度
        - time.sleep 在后台线程执行，不阻塞主线程
        - 弹窗监听的 _pw 调用有执行机会

        Args:
            selector: 媒体选择器
            timeout: 超时时间（秒）
            on_media_started: 媒体初始化成功后的回调（用于启动音频录制等），
                              签名: fn() -> None，在后台线程中调用

        返回 {'success': bool, 'reason': str, 'duration': float, 'currentTime': float}
        """
        # 确保 timeout 为数字
        try:
            timeout = float(timeout)
        except (ValueError, TypeError):
            timeout = 3600

        # 阶段1: 初始化（短操作，通过 _pw 调度，<5s 内完成）
        init = self._pw(lambda: self.browser._start_media_wait(selector))
        if not init.get('ready'):
            return init.get('result', {'success': False, 'reason': '初始化失败'})

        media_id = init['media_id']
        pw_sel = init['pw_sel']

        # 媒体初始化成功后，触发回调（用于启动音频录制等）
        if on_media_started:
            try:
                on_media_started()
            except Exception as e:
                self.logger.error(f"[媒体监听] on_media_started 回调异常: {e}")

        # 阶段2: 轮询检查（在后台线程控制节奏，每次检查通过 _pw 调度）
        start_time = time.time()
        poll_interval = 1.0  # 缩短轮询间隔到1秒，提高响应速度
        last_progress_log = 0
        last_check_time = time.time()
        consecutive_errors = 0
        max_consecutive_errors = 5
        
        # 播放完成确认机制：用于避免误判
        # 阈值1：严格达到100%（允许0.1%误差，考虑浮点精度和缓冲）
        END_THRESHOLD_STRICT = 99.9  # 严格阈值
        # 阈值2：缓冲延迟容差（允许连续多次接近结束才判定）
        END_THRESHOLD_TOLERANT = 99.5  # 宽松阈值
        # 连续确认次数：使用宽松阈值时需要连续多次检测到才判定完成
        CONFIRM_COUNT_REQUIRED = 3  # 需要连续3次检测到接近结束
        near_end_counter = 0  # 连续接近结束的计数
        near_end_timestamps = []  # 记录每次接近结束的时间点，用于计算间隔
        last_near_end_time = 0  # 上次检测到接近结束的时间
        el_info = None  # 最近一次额外检测的媒体状态（用于进度守护缓存）

        self.logger.info(f"[媒体监听] 等待媒体播放结束: {selector} (超时: {timeout}s)")

        while time.time() - start_time < timeout:
            if not self.running:
                self.logger.info("[媒体监听] 任务已停止，退出等待")
                return {'success': False, 'reason': 'stopped', 'duration': 0, 'currentTime': 0}

            # 单次检查（短操作，<3s）
            try:
                check = self._pw(lambda: self.browser._check_media_ended(selector, media_id, pw_sel))
                consecutive_errors = 0
                
                if check.get('done'):
                    self.logger.info(f"[媒体监听] 播放结束检测成功: {selector}")
                    return check['result']
                
                # 额外检测：直接检查媒体元素的播放状态和进度
                # 用于处理某些特殊播放器的兼容性问题
                try:
                    el_info = self._pw(lambda: {
                        'ended': self.browser.page.evaluate(f"(sel) => document.querySelector(sel).ended", pw_sel),
                        'currentTime': self.browser.page.evaluate(f"(sel) => document.querySelector(sel).currentTime", pw_sel),
                        'duration': self.browser.page.evaluate(f"(sel) => document.querySelector(sel).duration", pw_sel),
                        'paused': self.browser.page.evaluate(f"(sel) => document.querySelector(sel).paused", pw_sel),
                        'buffered': self.browser.page.evaluate(f"(sel) => {{ const el = document.querySelector(sel); if (!el || !el.buffered.length) return null; return {{ start: el.buffered.start(0), end: el.buffered.end(el.buffered.length - 1), length: el.buffered.length }}; }}", pw_sel)
                    })
                    
                    duration = el_info.get('duration', 0)
                    current_time = el_info.get('currentTime', 0)
                    is_ended = el_info.get('ended', False)
                    is_paused = el_info.get('paused', False)
                    
                    # 优先检查 ended 属性：这是最可靠的播放完成标志
                    if is_ended and duration > 0:
                        self.logger.info(f"[媒体监听] 检测到 ended=true，媒体播放已完成: {selector}")
                        return {
                            'success': True,
                            'reason': 'ended',
                            'duration': duration,
                            'currentTime': current_time
                        }
                    
                    # 检查是否处于暂停状态超过10秒且进度接近100%
                    # 这可能是播放完成但未触发ended事件的特殊情况
                    if is_paused and duration > 0 and current_time > 0:
                        percent_complete = (current_time / duration) * 100
                        # 只有进度达到严格阈值才判定为播放完成
                        if percent_complete >= END_THRESHOLD_STRICT:
                            time_since_last_check = time.time() - last_check_time
                            if time_since_last_check > 10:
                                self.logger.info(f"[媒体监听] 媒体已暂停超过10秒且进度达标 ({percent_complete:.1f}%)，判定为播放完成: {selector}")
                                return {
                                    'success': True,
                                    'reason': 'near_end_paused',
                                    'duration': duration,
                                    'currentTime': current_time
                                }
                    
                    # 容错处理：检查进度条和缓冲状态
                    if duration > 0 and current_time > 0:
                        percent_complete = (current_time / duration) * 100
                        buffered = el_info.get('buffered')
                        
                        # 严格条件：进度必须非常接近100%且播放器已停止
                        if percent_complete >= END_THRESHOLD_STRICT:
                            if is_paused:
                                self.logger.info(f"[媒体监听] 进度达标({percent_complete:.1f}%)且已暂停，判定为播放完成: {selector}")
                                return {
                                    'success': True,
                                    'reason': 'near_end_strict',
                                    'duration': duration,
                                    'currentTime': current_time
                                }
                        
                        # 缓冲延迟容错：检查是否真的播放到末尾还是缓冲导致卡住
                        if percent_complete >= END_THRESHOLD_TOLERANT:
                            current_time_ms = int(current_time * 1000)
                            if buffered:
                                buffered_end = buffered.get('end', 0)
                                buffered_end_ms = int(buffered_end * 1000)
                                
                                # 如果缓冲已到末尾且进度接近末尾，认为是真正播放完成
                                if buffered_end_ms - current_time_ms < 2000:  # 缓冲剩余少于2秒
                                    if time.time() - last_near_end_time > 0:
                                        near_end_counter += 1
                                    else:
                                        near_end_counter = 1
                                    near_end_timestamps.append(time.time())
                                    last_near_end_time = time.time()
                                    
                                    # 保持数组长度合理（只保留最近10次）
                                    if len(near_end_timestamps) > 10:
                                        near_end_timestamps = near_end_timestamps[-10:]
                                    
                                    self.logger.debug(f"[媒体监听] 进度接近末尾 ({percent_complete:.1f}%)，缓冲良好，确认计数: {near_end_counter}/{CONFIRM_COUNT_REQUIRED}")
                                    
                                    # 需要连续多次检测到接近结束才判定完成
                                    if near_end_counter >= CONFIRM_COUNT_REQUIRED:
                                        # 检查确认间隔是否合理（避免长时间卡在99.x%）
                                        if len(near_end_timestamps) >= CONFIRM_COUNT_REQUIRED:
                                            intervals = [near_end_timestamps[i+1] - near_end_timestamps[i] 
                                                       for i in range(len(near_end_timestamps)-1)]
                                            avg_interval = sum(intervals) / len(intervals) if intervals else 0
                                            # 如果平均间隔合理（小于10秒），认为是正常播放
                                            if avg_interval < 10 or all(i < 5 for i in intervals):
                                                self.logger.info(f"[媒体监听] 缓冲延迟容错：连续{CONFIRM_COUNT_REQUIRED}次检测到进度接近末尾 ({percent_complete:.1f}%)，判定为播放完成: {selector}")
                                                return {
                                                    'success': True,
                                                    'reason': 'near_end_tolerant',
                                                    'duration': duration,
                                                    'currentTime': current_time
                                                }
                                            else:
                                                self.logger.debug(f"[媒体监听] 确认间隔过长 ({avg_interval:.1f}s)，重置计数")
                                                near_end_counter = 0
                                                near_end_timestamps = []
                                else:
                                    # 缓冲未到末尾，可能是缓冲延迟，继续等待
                                    if near_end_counter > 0:
                                        near_end_counter -= 1
                                        self.logger.debug(f"[媒体监听] 缓冲未到末尾 ({buffered_end_ms - current_time_ms}ms)，减少确认计数: {near_end_counter}")
                            else:
                                # 正在播放但进度接近末尾，继续等待
                                if percent_complete >= 99.0:
                                    near_end_counter = min(near_end_counter + 1, CONFIRM_COUNT_REQUIRED)
                                    self.logger.debug(f"[媒体监听] 正在播放且进度接近末尾 ({percent_complete:.1f}%)，确认计数: {near_end_counter}")
                        else:
                            # 进度回退或不在接近末尾区域，重置计数器
                            if near_end_counter > 0:
                                self.logger.debug(f"[媒体监听] 进度回退 ({percent_complete:.1f}%)，重置确认计数")
                                near_end_counter = 0
                                near_end_timestamps = []
                    
                except Exception as e:
                    self.logger.debug(f"[媒体监听] 额外状态检查失败: {e}")
                    # 检测浏览器死亡：如果浏览器已关闭，立即触发恢复流程
                    if self._check_browser_death(e):
                        self._signal_browser_died()
                        return {
                            'success': False,
                            'reason': 'browser_closed',
                            'duration': 0,
                            'currentTime': 0
                        }
                    # 检测页面意外跳转：元素为null但浏览器仍活着
                    if self._check_page_navigated_away(e, pw_sel):
                        nav_result = self._handle_page_navigated_away(pw_sel)
                        if nav_result.get('restored'):
                            # 页面已导航回原URL且进度已恢复，重置状态继续等待播放
                            self.logger.info("[媒体监听] 页面跳转恢复成功，重置状态继续等待播放")
                            consecutive_errors = 0
                            near_end_counter = 0
                            near_end_timestamps = []
                            el_info = None
                            # 重启进度守护（restore_progress 已恢复播放进度）
                            if self.progress_saver and not self.progress_saver._running:
                                self.progress_saver.start()
                            continue
                        else:
                            return nav_result

            except Exception as e:
                consecutive_errors += 1
                self.logger.warning(f"[媒体监听] 检查媒体状态异常 ({consecutive_errors}/{max_consecutive_errors}): {e}")
                # 检测浏览器死亡：如果浏览器已关闭，立即触发恢复流程
                if self._check_browser_death(e):
                    self._signal_browser_died()
                    return {
                        'success': False,
                        'reason': 'browser_closed',
                        'duration': 0,
                        'currentTime': 0
                    }
                # 检测页面意外跳转（浏览器活着但元素消失了）
                if self._check_page_navigated_away(e, pw_sel):
                    nav_result = self._handle_page_navigated_away(pw_sel)
                    if nav_result.get('restored'):
                        self.logger.info("[媒体监听] 页面跳转恢复成功，重置状态继续等待播放")
                        consecutive_errors = 0
                        near_end_counter = 0
                        near_end_timestamps = []
                        el_info = None
                        # 重启进度守护
                        if self.progress_saver and not self.progress_saver._running:
                            self.progress_saver.start()
                        continue
                    else:
                        return nav_result
                # 连续错误时主动检查浏览器存活状态（通过 _pw 在主线程安全检查）
                if consecutive_errors >= 2:
                    try:
                        alive = self._pw(lambda: self.browser.is_alive())
                        if not alive:
                            self.logger.warning("[媒体监听] 连续错误 + 浏览器不存活，判定为浏览器已关闭")
                            self._signal_browser_died()
                            return {
                                'success': False,
                                'reason': 'browser_closed',
                                'duration': 0,
                                'currentTime': 0
                            }
                    except Exception:
                        self.logger.warning("[媒体监听] 浏览器存活检查失败，判定为浏览器已关闭")
                        self._signal_browser_died()
                        return {
                            'success': False,
                            'reason': 'browser_closed',
                            'duration': 0,
                            'currentTime': 0
                        }
                if consecutive_errors >= max_consecutive_errors:
                    self.logger.error(f"[媒体监听] 连续检查失败，判定为播放失败（不标记完成）: {selector}")
                    return {
                        'success': False,
                        'reason': 'check_failed',
                        'duration': 0,
                        'currentTime': 0
                    }

            # 输出播放进度（每 30 秒一次，更频繁的进度更新）
            now = time.time()
            progress = check.get('progress') if 'check' in locals() and check else None
            if progress and now - last_progress_log >= 30:
                ct = progress.get('currentTime', 0)
                dur = progress.get('duration', 0)
                if dur > 0:
                    pct = ct / dur * 100
                    self.logger.info(
                        f"[媒体监听] 播放进度: {selector} "
                        f"({ct:.0f}s/{dur:.0f}s, {pct:.1f}%)")
                last_progress_log = now

            # 输出音频录制进度（每 30 秒一次）
            if self._audio_recorder and self._audio_recorder.is_recording() and now - last_progress_log < 1:
                # 与播放进度日志同频输出，避免过于频繁
                try:
                    status = self._audio_recorder.get_status()
                    if status and status.get('recording'):
                        rec_duration = status.get('duration', 0)
                        self.logger.info(
                            f"[音频录制] 录制进度: {rec_duration:.0f}s")
                except Exception:
                    pass

            # 更新进度守护缓存（每轮检查都更新，确保崩溃时缓存是最新的）
            if self.progress_saver and el_info is not None:
                try:
                    self.progress_saver.update_cache_from_monitor(
                        el_info, selector, pw_sel)
                except Exception:
                    pass

            # 等待下一轮（在后台线程 sleep，不阻塞主线程）
            # 分段 sleep，便于快速响应停止信号
            end_time = time.time() + poll_interval
            while self.running and time.time() < end_time:
                time.sleep(0.2)

            last_check_time = time.time()

        # 超时
        self.logger.warning(f"[媒体监听] 等待播放结束超时: {selector} ({timeout}s)")
        return {'success': False, 'reason': 'timeout', 'duration': 0, 'currentTime': 0}

    def _play_next_media_safe(self, selector, timeout=3600.0):
        """线程安全的 play_next_media，等待播放结束后自动播放下一个。

        支持两种目标选择器：
        1. 媒体选择器（video#aabbcc）：等待当前媒体结束，查找页面中下一个媒体并播放
        2. 可点击元素（a[onclick="goNext()"]）：点击该元素，等待新页面/新媒体加载，然后等待播放结束

        不通过 _pw 调度整个 play_next_media（会超时），
        而是分段调用：先等待结束，再执行"播放下一个"的 Playwright 操作。
        """
        # 判断选择器类型：是媒体元素还是可点击元素
        is_media_selector = self._is_media_selector(selector)

        if is_media_selector:
            # 场景1: 目标是媒体元素，等待当前媒体结束，找下一个媒体
            return self._play_next_media_on_page(selector, timeout)
        else:
            # 场景2: 目标是可点击元素（如"下一个"按钮），点击后等待新媒体
            return self._click_and_wait_next_media(selector, timeout)

    def _is_media_selector(self, selector):
        """判断选择器是否指向媒体元素。"""
        if not selector:
            return False
        sel_lower = selector.lower()
        # CSS 选择器以 video 或 audio 开头
        if sel_lower.startswith('video') or sel_lower.startswith('audio'):
            return True
        # XPath 包含 video 或 audio
        if 'video' in sel_lower or 'audio' in sel_lower:
            # 排除明显不是媒体的情况（如 a[onclick] 中的文本）
            if sel_lower.startswith('a[') or sel_lower.startswith('button[') or sel_lower.startswith('a.'):
                return False
            return True
        return False

    def _play_next_media_on_page(self, current_media_selector, timeout=3600.0):
        """场景1: 当前媒体结束后，在同一页面查找下一个媒体并播放。"""
        # 查找并播放下一个媒体
        try:
            next_info = self._pw(lambda: self.browser.page.evaluate("""(currentSel) => {
                var mediaEls = document.querySelectorAll('video, audio');
                var currentEl = document.querySelector(currentSel);
                var currentIdx = currentEl ? Array.prototype.indexOf.call(mediaEls, currentEl) : -1;
                for (var i = currentIdx + 1; i < mediaEls.length; i++) {
                    var el = mediaEls[i];
                    if (!el.ended && el.offsetWidth > 0) {
                        return {
                            found: true,
                            tag: el.tagName.toLowerCase(),
                            id: el.id || '',
                            index: i,
                            src: (el.currentSrc || el.src || '').substring(0, 200)
                        };
                    }
                }
                return {found: false};
            }""", current_media_selector))
        except Exception as e:
            self.logger.error(f"[播放下一曲] 查找下一媒体失败: {e}")
            return {'success': False, 'reason': f'查找失败: {e}', 'next_played': False, 'next_selector': ''}

        if not next_info or not next_info.get('found'):
            self.logger.info("[播放下一曲] 同一页面没有更多媒体可播放")
            return {'success': True, 'reason': 'no_more_media', 'next_played': False, 'next_selector': ''}

        # 构建下一个媒体的选择器并播放
        next_id = next_info.get('id', '')
        next_tag = next_info.get('tag', 'video')
        next_selector = f"{next_tag}#{next_id}" if next_id else f"{next_tag}:eq({next_info.get('index', 0)})"

        try:
            self._pw(lambda: self.browser.page.evaluate("""(sel) => {
                var el = document.querySelector(sel);
                if (el) el.play();
            }""", next_selector))
            self.logger.info(f"[播放下一曲] 已自动播放下一个: {next_selector}")
            return {'success': True, 'reason': 'next_media', 'next_played': True, 'next_selector': next_selector}
        except Exception as e:
            self.logger.error(f"[播放下一曲] 播放下一个失败: {e}")
            return {'success': False, 'reason': f'播放失败: {e}', 'next_played': False, 'next_selector': ''}

    def _click_and_wait_next_media(self, click_selector, timeout=3600.0):
        """场景2: 点击可点击元素（如"下一个"按钮），等待新页面加载，然后等待新媒体播放结束。

        流程: 点击 → 等待页面稳定 → 查找新媒体 → 等待播放结束
        """
        # 步骤1: 点击目标元素
        self.logger.info(f"[播放下一曲] 点击元素: {click_selector}")
        try:
            click_result = self._pw(lambda: self.browser.click_element(click_selector))
            if not click_result:
                self.logger.warning(f"[播放下一曲] 点击失败: {click_selector}")
                return {'success': False, 'reason': '点击失败', 'next_played': False, 'next_selector': ''}
        except Exception as e:
            self.logger.error(f"[播放下一曲] 点击异常: {e}")
            return {'success': False, 'reason': f'点击异常: {e}', 'next_played': False, 'next_selector': ''}

        # 步骤2: 等待页面稳定（点击后页面可能跳转或刷新）
        self.logger.info("[播放下一曲] 等待页面稳定...")
        try:
            self._pw(lambda: self.browser.page.wait_for_load_state('domcontentloaded', timeout=15000))
        except Exception:
            pass  # 页面可能已经在加载中，超时不影响

        # 额外等待，给新媒体元素时间出现
        time.sleep(3)

        # 检测新标签页
        try:
            page_count = len(self._pw(lambda: self.browser.context.pages))
            self._detect_and_switch_new_page(page_count)
        except Exception:
            pass

        # 步骤3: 查找页面上的新媒体元素
        self.logger.info("[播放下一曲] 查找新媒体元素...")
        new_media_selector = self._resolve_media_selector('')  # 自动查找可见媒体
        if not new_media_selector:
            self.logger.warning("[播放下一曲] 未找到新媒体元素")
            return {'success': False, 'reason': '未找到新媒体', 'next_played': False, 'next_selector': ''}

        self.logger.info(f"[播放下一曲] 找到新媒体: {new_media_selector}")

        # 步骤4: 等待新媒体播放结束
        result = self._wait_media_ended_safe(new_media_selector, timeout)
        result['next_played'] = result.get('success', False)
        result['next_selector'] = new_media_selector if result.get('success') else ''
        return result

    # 可交互标签（优先点击）
    INTERACTIVE_TAGS = {'A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'SUMMARY', 'OPTION'}
    # 不可交互标签（跳过）
    SKIP_TAGS = {'SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'META', 'LINK', 'HEAD'}

    def _execute_play_list(self, nav_item):
        """按列表播放：读取配置中的播放列表JSON数据，逐个检查并播放未完成的网页。

        播放列表格式:
          play_list: [
            {"url": "https://xxx/page1", "completed": false},
            {"url": "https://xxx/page2", "completed": true},
            ...
          ]

        运行逻辑:
          1. 遍历播放列表，检查每个网页的播放状态(completed)
          2. 若未完成(completed=false)，导航到该URL并启动播放
          3. 等待播放结束（使用 _wait_media_ended_safe）
          4. 播放完成后标记 completed=true
          5. 继续下一个未完成的网页
          6. 循环计数仅计算实际播放耗时（不包含状态检查耗时）
          7. 达到 loop_count 或所有网页均已播放完毕则停止

        Returns:
            bool: 是否至少成功播放了一个网页
        """
        name = nav_item.get('name', '未知')
        tab_index = nav_item.get('tab_index', -1)

        # 直接引用 nav_item 中的 play_list，支持动态更新
        play_list = nav_item.get('play_list', [])

        if not play_list:
            self.logger.warning(f"[按列表播放] 播放列表为空: {name}")
            return False

        # 初始统计
        def get_play_list_stats(pl):
            """获取播放列表统计信息"""
            valid = [i for i, item in enumerate(pl) if item.get('url')]
            completed = [i for i in valid if pl[i].get('completed', False)]
            pending = [i for i in valid if not pl[i].get('completed', False)]
            return {
                'total': len(pl),
                'valid': len(valid),
                'completed': len(completed),
                'pending': len(pending),
                'valid_indices': valid,
                'pending_indices': pending,
            }

        initial_stats = get_play_list_stats(play_list)
        self.logger.info(
            f"[按列表播放] 列表统计: 共 {initial_stats['total']} 项, "
            f"有效 {initial_stats['valid']} 项, 已完成 {initial_stats['completed']} 项, "
            f"待播放 {initial_stats['pending']} 项")

        # 无任何有效项
        if initial_stats['valid'] == 0:
            self.logger.warning(f"[按列表播放] 无有效播放项: {name}")
            return False

        # 所有项已完成，直接结束
        if initial_stats['pending'] == 0:
            self.logger.info(
                f"[按列表播放] 所有播放项均已完成, 无需播放: {name}")
            return True

        # 循环控制
        loop_infinite = nav_item.get('loop_infinite', False)
        loop_count = nav_item.get('loop_count', 1)
        if loop_infinite:
            max_loops = 0  # 0=无限
        else:
            max_loops = max(1, loop_count)

        # 连续失败保护：防止所有项都无法播放时无限重试
        MAX_CONSECUTIVE_FAIL_ROUNDS = 3
        consecutive_fail_rounds = 0

        # 媒体超时
        try:
            media_timeout = float(nav_item.get('media_timeout', 3600))
        except (ValueError, TypeError):
            media_timeout = 3600

        actual_play_count = 0  # 实际播放次数（仅计算播放耗时）
        overall_success = False
        round_idx = 0
        known_urls = set()  # 记录已知的 URL，用于检测新增项

        self.logger.info(
            f"[按列表播放] 开始: {name} (有效{initial_stats['valid']}项, "
            f"待播放{initial_stats['pending']}项, "
            f"循环={'无限' if max_loops == 0 else max_loops}次)")

        # 记录初始已知 URL
        for item in play_list:
            if item.get('url'):
                known_urls.add(item.get('url'))

        while self.running:
            round_idx += 1
            if max_loops > 0 and actual_play_count >= max_loops:
                self.logger.info(
                    f"[按列表播放] 已达到设定循环次数({max_loops}次), 停止播放")
                break

            # 动态重新扫描播放列表（支持动态添加新项）
            current_stats = get_play_list_stats(play_list)

            # 检测是否有新增项
            new_urls = []
            for item in play_list:
                url = item.get('url', '')
                if url and url not in known_urls:
                    known_urls.add(url)
                    new_urls.append(url)
                    self.logger.info(f"[按列表播放] 检测到新增项: {url[:60]}")

            if new_urls:
                self.logger.info(f"[按列表播放] 本轮新增 {len(new_urls)} 个待播放项")

            # 重新获取待播放项（仅未完成的项）
            current_pending = current_stats['pending_indices'].copy()
            random.shuffle(current_pending)  # 随机顺序播放新增项

            if not current_pending:
                self.logger.info(
                    f"[按列表播放] 所有播放项均已完成, 结束: {name}")
                break

            self.logger.info(
                f"[按列表播放] 第{round_idx}轮: 待播放 {len(current_pending)} 项")

            for valid_idx, i in enumerate(current_pending):
                item = play_list[i]
                if not self.running:
                    break

                # 检查暂停
                while self.paused and self.running:
                    time.sleep(0.5)

                if not self.running:
                    break

                url = item.get('url', '')

                # 再次检查完成状态（防止本轮前面已处理的情况）
                if item.get('completed', False):
                    self.logger.debug(
                        f"[按列表播放] [{valid_idx+1}/{len(current_pending)}] "
                        f"已完成, 跳过: {url[:60]}")
                    continue

                # 标签页切换
                original_page = None
                if tab_index >= 0:
                    original_page = self.browser.page
                    switched = self._pw(lambda: self.browser.switch_to_page(tab_index))
                    if not switched:
                        self.logger.warning(
                            f"[按列表播放] 标签页 {tab_index} 切换失败, "
                            f"尝试在当前页面执行: {url[:60]}")
                        original_page = None

                # 导航到目标URL
                # 先检查浏览器是否存活（可能被意外关闭）
                try:
                    if not self.browser.is_alive():
                        self.logger.warning(f"[按列表播放] 浏览器已断开，等待恢复...")
                        # 等待浏览器恢复（最多60秒）
                        if self._browser_recovering:
                            self._browser_recovery_event.wait(timeout=60)
                            self._browser_recovery_event.clear()
                        # 恢复后再次检查
                        if not self.browser.is_alive():
                            self.logger.error(f"[按列表播放] 浏览器恢复后仍不可用，跳过: {url[:60]}")
                            continue
                except Exception:
                    self.logger.error(f"[按列表播放] 浏览器状态检查异常，跳过: {url[:60]}")
                    continue

                self.logger.info(
                    f"[按列表播放] [{valid_idx+1}/{len(current_pending)}] "
                    f"导航到: {url[:80]} (第{round_idx}轮)")
                nav_ok = self._pw(
                    lambda u=url: self.browser.goto_page(
                        u, self.settings.get('global_timeout', 30000)))

                if not nav_ok:
                    self.logger.warning(
                        f"[按列表播放] 导航失败: {url[:60]}")
                    # 恢复标签页
                    if original_page is not None:
                        try:
                            current_pages = self._pw(lambda: self.browser.context.pages)
                            if original_page in current_pages:
                                self.browser.page = original_page
                        except Exception:
                            pass
                    continue

                # 等待页面加载（优先等待 networkidle，确保 JS 动态内容加载完成）
                try:
                    self._pw(lambda: self.browser.page.wait_for_load_state(
                        'networkidle', timeout=15000))
                except Exception:
                    # networkidle 超时则回退到 domcontentloaded
                    try:
                        self._pw(lambda: self.browser.page.wait_for_load_state(
                            'domcontentloaded', timeout=5000))
                    except Exception:
                        pass

                # 额外等待2秒，确保 xgplayer 等动态播放器完成初始化
                time.sleep(2)

                # 如果列表项启用了"点击播放"，模拟点击播放器（适用于 xgplayer 等懒加载播放器）
                click_play = item.get('click_play', False)
                if click_play:
                    self.logger.info("[按列表播放] 已启用'点击播放'，模拟点击播放器...")
                    # 优先点击指定选择器元素，否则尝试触发 xgplayer，最后点击页面中央
                    item_selector = item.get('选择器', '')
                    if item_selector:
                        el = self._pw(lambda: self.browser.page.query_selector(
                            self.browser.parse_selector(item_selector)[0]))
                        if el:
                            self._pw(lambda: el.click())
                            self.logger.info(f"[按列表播放] 已点击选择器元素: {item_selector}")
                        else:
                            triggered = self._pw(lambda: self.browser.trigger_xgplayer())
                            if triggered:
                                self.logger.info("[按列表播放] xgplayer 触发成功")
                            else:
                                viewport = self._pw(lambda: self.browser.page.viewport_size)
                                if viewport:
                                    cx = viewport['width'] // 2
                                    cy = viewport['height'] // 3
                                    self._pw(lambda: self.browser.page.mouse.click(cx, cy))
                                    self.logger.info(f"[按列表播放] 已点击页面坐标 ({cx}, {cy})")
                    else:
                        triggered = self._pw(lambda: self.browser.trigger_xgplayer())
                        if triggered:
                            self.logger.info("[按列表播放] xgplayer 触发成功")
                        else:
                            viewport = self._pw(lambda: self.browser.page.viewport_size)
                            if viewport:
                                cx = viewport['width'] // 2
                                cy = viewport['height'] // 3
                                self._pw(lambda: self.browser.page.mouse.click(cx, cy))
                                self.logger.info(f"[按列表播放] 已点击页面坐标 ({cx}, {cy})")
                    # 点击后等待播放器初始化
                    time.sleep(2)

                # 注入媒体监听脚本
                self._pw(lambda: self.browser.inject_media_monitor())

                # 注入进度守护页面端脚本（beforeunload 时 localStorage 备份）
                self._pw(lambda: self.browser.inject_progress_saver())

                # 启动进度守护定时保存（每60秒自动保存一次）
                if self.progress_saver:
                    self.progress_saver.start()
                    # 尝试恢复上次播放进度（浏览器崩溃后重启场景）
                    self.progress_saver.restore_progress()

                # 获取列表项中的选择器（如果有指定则使用，否则自动查找）
                item_selector = item.get('选择器', '')
                if item_selector:
                    self.logger.info(f"[按列表播放] 使用指定选择器: {item_selector}")
                else:
                    self.logger.info(f"[按列表播放] 未指定选择器，自动查找页面媒体")

                # 查找并解析媒体选择器（优先使用列表项选择器，否则自动查找）
                actual_selector = self._resolve_media_selector(item_selector if item_selector else '')

                if not actual_selector:
                    self.logger.warning(
                        f"[按列表播放] 页面未找到媒体元素: {url[:60]}")
                    # 最后尝试触发 xgplayer
                    self.logger.info("[按列表播放] 尝试触发 xgplayer...")
                    trigger_ok = self._pw(lambda: self.browser.trigger_xgplayer())
                    if trigger_ok:
                        actual_selector = 'video'
                        self.logger.info("[按列表播放] xgplayer 触发成功，使用 video 选择器")
                    else:
                        # 未找到媒体元素，不标记为已完成（下次可重试）
                        self.logger.warning(
                            f"[按列表播放] 跳过（无媒体）: {url[:60]}")
                        if original_page is not None:
                            try:
                                current_pages = self._pw(lambda: self.browser.context.pages)
                                if original_page in current_pages:
                                    self.browser.page = original_page
                            except Exception:
                                pass
                        continue

                # 验证选择器对应的元素是否存在
                el_exists = self._pw(lambda: self.browser.page.query_selector(
                    self.browser.parse_selector(actual_selector)[0]) is not None)
                if not el_exists and actual_selector == 'video':
                    # video 元素不存在，可能是 xgplayer 未触发，尝试触发
                    self.logger.info("[按列表播放] video 元素不存在，尝试触发 xgplayer...")
                    trigger_ok = self._pw(lambda: self.browser.trigger_xgplayer())
                    if trigger_ok:
                        self.logger.info("[按列表播放] xgplayer 触发成功")
                        # 等待 video 元素出现
                        try:
                            self._pw(lambda: self.browser.page.wait_for_selector(
                                'video', state='attached', timeout=5000))
                        except Exception:
                            pass
                        el_exists = self._pw(lambda: self.browser.page.query_selector('video') is not None)
                    
                if not el_exists:
                    self.logger.warning(
                        f"[按列表播放] 选择器 {actual_selector} 对应元素不存在，跳过（不标记完成）: {url[:60]}")
                    if original_page is not None:
                        try:
                            current_pages = self._pw(lambda: self.browser.context.pages)
                            if original_page in current_pages:
                                self.browser.page = original_page
                        except Exception:
                            pass
                    continue

                # 检查是否启用音频录制 - 先注入（不启动），等视频播放后再启动
                enable_recording = nav_item.get('enable_recording', False)
                recording_format = nav_item.get('recording_format', 'WEBM')
                recording_injected = False
                recording_started = False
                recording_start_time = None
                if enable_recording and _AUDIO_RECORDER_AVAILABLE:
                    # 先注入 JS，等视频播放后再启动录制
                    recording_injected = self._inject_audio_recorder(url, recording_format)
                else:
                    if enable_recording and not _AUDIO_RECORDER_AVAILABLE:
                        self.logger.warning("[按列表播放] 音频录制模块不可用，无法录制")

                # 定义媒体开始播放后的回调：启动音频录制
                def _on_media_started():
                    nonlocal recording_started, recording_start_time
                    if enable_recording and recording_injected and _AUDIO_RECORDER_AVAILABLE and self._audio_recorder:
                        # 等待一小段时间确保音频轨道可用
                        time.sleep(0.5)
                        if not self.running:
                            return
                        recording_started = self._start_audio_recording_only()
                        if recording_started:
                            recording_start_time = time.time()
                            self.logger.info(f"[音频录制] 正在录制: {self._current_recording_path}")
                        else:
                            self.logger.warning("[按列表播放] 音频录制启动失败，将继续播放但不录制")

                # 开始播放并等待（计入播放耗时）
                play_start = time.time()
                self.logger.info(
                    f"[按列表播放] 开始播放: {actual_selector} (超时: {media_timeout}s)")

                # 播放视频并获取播放状态（通过 on_media_started 在播放开始后立即启动录制）
                result = self._wait_media_ended_safe(actual_selector, timeout=media_timeout, on_media_started=_on_media_started)

                play_duration = time.time() - play_start

                # 停止音频录制
                recording_result = None
                if enable_recording and _AUDIO_RECORDER_AVAILABLE:
                    recording_result = self._stop_audio_recording(url)

                if result.get('success'):
                    duration = result.get('duration', 0)
                    reason = result.get('reason', '')
                    actual_play_count += 1  # 仅成功播放才计入循环次数
                    self.logger.info(
                        f"[按列表播放] 播放完成: {url[:60]} "
                        f"(时长: {duration:.1f}s, 实际耗时: {play_duration:.1f}s, 原因: {reason})")
                    item['completed'] = True
                    overall_success = True

                    # 录音成功则保存录音文件信息到配置
                    if recording_result and recording_result.get('path'):
                        # 转为相对路径（相对于 skill 根目录）
                        skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                        abs_path = recording_result.get('path')
                        rel_path = os.path.relpath(abs_path, skill_dir)

                        if recording_result.get('success'):
                            item['audio_file'] = rel_path
                        else:
                            # 保存失败也记录路径，标记为未完成，方便后续手动恢复
                            item['audio_file'] = rel_path
                            item['audio_incomplete'] = True
                            self.logger.warning(
                                f"[音频录制] 录音保存未成功，但已记录路径: {rel_path} "
                                f"(错误: {recording_result.get('error', 'unknown')})"
                            )

                        # 获取页面标题作为录音名称
                        try:
                            page_title = self._pw(lambda: self.browser.page.title()) if self._pw_call else self.browser.page.title()
                            item['audio_name'] = page_title
                        except Exception:
                            item['audio_name'] = recording_result.get('path', '').split(os.sep)[-1]
                        self.logger.info(f"[音频录制] 已保存录音信息到播放列表项: audio_file={item['audio_file']}, audio_name={item['audio_name']}")
                        # 持久化配置
                        if self.config_loader:
                            try:
                                self.config_loader.save()
                                self.logger.info("[音频录制] 配置已保存")
                            except Exception as e:
                                self.logger.error(f"[音频录制] 保存配置失败: {e}")
                    elif recording_result and not recording_result.get('success'):
                        # 录音停止失败且没有路径信息
                        self.logger.warning(
                            f"[音频录制] 录音保存失败: {recording_result.get('error', 'unknown')}，"
                            f"未记录 audio_file"
                        )

                    # 播放完成，停止进度守护并清除进度数据
                    if self.progress_saver:
                        self.progress_saver.stop()
                        self.progress_saver.clear_progress()

                    # 通知 GUI 同步播放列表完成状态（通过主线程调度）
                    self._notify_play_list_completed()

                    # 播放结束后执行后续操作
                    self._execute_on_end_action(nav_item)
                else:
                    reason = result.get('reason', 'unknown')
                    self.logger.warning(
                        f"[按列表播放] 播放失败: {url[:60]} (原因: {reason})")

                    # 播放失败时紧急保存进度（浏览器崩溃时使用缓存数据回退），然后停止守护
                    if self.progress_saver:
                        self.progress_saver.save_now()  # 内部会自动使用缓存回退
                        self.progress_saver.stop()

                    # 浏览器已关闭，立即退出播放列表，避免无意义的重试
                    if reason == 'browser_closed':
                        self.logger.warning("[按列表播放] 浏览器已关闭，停止播放列表")
                        return overall_success

                # 恢复标签页
                if original_page is not None:
                    try:
                        current_pages = self._pw(lambda: self.browser.context.pages)
                        if original_page in current_pages:
                            self.browser.page = original_page
                    except Exception:
                        pass
                
                # 等待2秒后进入下一个视频，确保有足够时间完成页面清理
                if self.running and valid_idx < len(current_pending) - 1:  # 如果不是最后一个待播放视频
                    self.logger.info(f"[按列表播放] 等待2秒后进入下一个视频")
                    wait_end = time.time() + 2
                    while self.running and time.time() < wait_end:
                        time.sleep(0.2)

                # 检查是否达到循环次数
                if max_loops > 0 and actual_play_count >= max_loops:
                    self.logger.info(
                        f"[按列表播放] 已达到设定播放次数({max_loops}次), 停止")
                    break

            # 本轮结束：如果非无限循环，检查是否需要继续
            if max_loops > 0 and actual_play_count >= max_loops:
                break

            # 连续失败保护：检测本轮是否有任何项成功完成
            round_newly_completed = sum(
                1 for idx in current_pending
                if play_list[idx].get('completed', False))
            if round_newly_completed > 0:
                consecutive_fail_rounds = 0
            else:
                consecutive_fail_rounds += 1
                if consecutive_fail_rounds >= MAX_CONSECUTIVE_FAIL_ROUNDS:
                    self.logger.warning(
                        f"[按列表播放] 连续{MAX_CONSECUTIVE_FAIL_ROUNDS}轮无任何项成功播放，停止重试")
                    break

        self.logger.info(
            f"[按列表播放] 结束: {name} (实际播放{actual_play_count}次, "
            f"共{len(play_list)}项)")
        return overall_success

    def _parse_on_end_action(self, action_str):
        """解析 on_end_action 字段，返回操作 key。
        支持 'click - 点击元素' 格式或纯 key。
        """
        if not action_str or action_str == 'none':
            return None
        if ' - ' in action_str:
            return action_str.split(' - ')[0].strip()
        return action_str.strip()

    def _execute_on_end_action(self, nav_item):
        """媒体播放结束后执行预设的后续操作。
        nav_item 中需要包含:
          - on_end_action: 后续操作类型 (none/click/navigate/play_next/wait/refresh)
          - on_end_target: 后续操作目标（选择器/URL/秒数）
          - on_end_wait: 后续操作前等待秒数
          - on_end_tab_index: 后续操作目标标签页索引（-1=当前标签页，仅click/play_next有效）
        """
        on_end_action_str = nav_item.get('on_end_action', 'none')
        on_end_action = self._parse_on_end_action(on_end_action_str)
        if not on_end_action:
            return

        on_end_target = nav_item.get('on_end_target', '')
        on_end_wait = nav_item.get('on_end_wait', 0)
        on_end_tab_index = nav_item.get('on_end_tab_index', -1)
        self.logger.info(f"[播放结束] 执行后续操作: {on_end_action}")

        # 先执行等待
        try:
            wait_secs = float(on_end_wait) if on_end_wait else 0
        except (ValueError, TypeError):
            wait_secs = 0

        # 确保 media_timeout 为数字（配置文件中可能为字符串）
        try:
            media_timeout_val = float(nav_item.get('media_timeout', 3600))
        except (ValueError, TypeError):
            media_timeout_val = 3600
        if wait_secs > 0:
            self.logger.info(f"[播放结束] 等待 {wait_secs} 秒后执行后续操作")
            elapsed = 0
            while elapsed < wait_secs and self.running:
                time.sleep(0.5)
                elapsed += 0.5

        # 标签页切换：如果后续操作指定了目标标签页（仅 click / play_next），临时切换
        original_page = None
        need_tab_switch = on_end_action in ('click', 'play_next') and on_end_tab_index is not None and on_end_tab_index >= 0
        if need_tab_switch:
            original_page = self.browser.page
            switched = self._pw(lambda: self.browser.switch_to_page(on_end_tab_index))
            if not switched:
                self.logger.warning(f"[播放结束] 目标标签页 {on_end_tab_index} 不存在或已关闭，跳过后续操作")
                return
            self.logger.info(f"[播放结束] 已切换到目标标签页 {on_end_tab_index}")

        try:
            if on_end_action == 'click':
                if on_end_target:
                    self.logger.info(f"[播放结束] 点击: {on_end_target}")
                    self.click_element(on_end_target)
                else:
                    self.logger.warning("[播放结束] 点击操作缺少选择器")

            elif on_end_action == 'navigate':
                if on_end_target:
                    self.logger.info(f"[播放结束] 跳转: {on_end_target}")
                    self._pw(lambda: self.browser.goto_page(on_end_target,
                              self.settings.get('global_timeout', 30000)))
                else:
                    self.logger.warning("[播放结束] 跳转操作缺少URL")

            elif on_end_action == 'play_next':
                if on_end_target:
                    self.logger.info(f"[播放结束] 播放下一个媒体: {on_end_target}")
                    self._play_next_media_safe(on_end_target, timeout=media_timeout_val)
                else:
                    self.logger.info("[播放结束] 播放下一个媒体(使用当前选择器)")
                    selector = nav_item.get('selector', '')
                    if selector:
                        self._play_next_media_safe(selector, timeout=media_timeout_val)

            elif on_end_action == 'wait':
                try:
                    wait_secs = float(on_end_target) if on_end_target else 3
                except (ValueError, TypeError):
                    wait_secs = 3
                self.logger.info(f"[播放结束] 额外等待 {wait_secs} 秒")
                elapsed = 0
                while elapsed < wait_secs and self.running:
                    time.sleep(0.5)
                    elapsed += 0.5

            elif on_end_action == 'refresh':
                self.logger.info("[播放结束] 刷新页面")
                self._pw(lambda: self.browser.page.reload())

            else:
                self.logger.warning(f"[播放结束] 未知后续操作: {on_end_action}")

        except Exception as e:
            self.logger.error(f"[播放结束] 后续操作执行异常: {e}")

        # 恢复原始标签页
        if original_page is not None:
            try:
                current_pages = self._pw(lambda: self.browser.context.pages)
                if original_page in current_pages:
                    self.browser.page = original_page
                    self.logger.info("[播放结束] 已恢复到原始标签页")
            except Exception:
                pass

    def _execute_play_loop(self, nav_item, selector, media_timeout, initial_success):
        """播放步骤的循环逻辑：在首次播放+on_end_action完成后，
        如果步骤配置了循环(loop_count > 1 或 loop_infinite)，
        则重新播放媒体→等待结束→触发on_end_action，如此循环。

        与外部步骤循环不同，此处不会重新导航页面或重新解析选择器，
        仅重复"播放+等待+后续操作"的核心循环。

        Args:
            nav_item: 步骤配置字典
            selector: 已解析的媒体选择器
            media_timeout: 媒体超时时间
            initial_success: 首次播放是否成功

        Returns:
            bool: 最终是否成功（任何一轮失败则返回 False）
        """
        loop_infinite = nav_item.get('loop_infinite', False)
        loop_count = nav_item.get('loop_count', 1)

        # 没有循环需求，直接返回
        if not loop_infinite and loop_count <= 1:
            return initial_success

        if loop_infinite:
            step_max_loops = 0  # 0 = 无限
        else:
            step_max_loops = max(2, loop_count)  # 至少2次才有循环意义

        overall_success = initial_success
        loop_idx = 1  # 首次播放已经完成，从第2轮开始

        while self.running:
            loop_idx += 1
            if step_max_loops > 0 and loop_idx > step_max_loops:
                break

            loop_hint = f" (循环 {loop_idx}/{step_max_loops})" if step_max_loops > 0 else f" (循环 {loop_idx}/∞)"
            self.logger.info(f"[播放循环] {nav_item.get('name', '未知')}{loop_hint} 重新播放媒体")

            # 暂停检查
            while self.paused and self.running:
                time.sleep(0.5)

            if not self.running:
                break

            # 重新解析媒体选择器（页面可能因 on_end_action 发生了变化）
            actual_selector = self._resolve_media_selector(nav_item.get('selector', ''))

            # 重新播放媒体
            play_ok = False
            try:
                element, used_sel = self._resolve_element(actual_selector)
                if element:
                    self._pw(lambda: element.evaluate('el => el.play()'))
                    self.logger.info(f"[播放循环] 媒体已开始播放: {used_sel}")
                    play_ok = True
                else:
                    # 尝试直接用原始选择器
                    self.logger.warning(f"[播放循环] 媒体选择器未匹配: {actual_selector}，尝试原始选择器: {selector}")
                    element2, used_sel2 = self._resolve_element(selector)
                    if element2:
                        self._pw(lambda: element2.evaluate('el => el.play()'))
                        self.logger.info(f"[播放循环] 媒体已开始播放(原始选择器): {used_sel2}")
                        actual_selector = selector
                        play_ok = True
                    else:
                        self.logger.error(f"[播放循环] 无法找到媒体元素，循环终止")
                        overall_success = False
                        break
            except Exception as e:
                self.logger.error(f"[播放循环] 播放媒体异常: {e}")
                overall_success = False
                break

            if not self.running:
                break

            # 等待媒体播放结束
            # 循环中统一使用 wait_media_ended（仅等待播放结束），
            # on_end_action 会在播放结束后自动处理后续操作（如播放下一个），
            # 无需再次调用 play_next_media_safe。
            result = self._wait_media_ended_safe(actual_selector, timeout=media_timeout)

            if result.get('success'):
                duration = result.get('duration', 0)
                reason = result.get('reason', '')
                self.logger.info(f"[播放循环] 媒体播放结束 (时长: {duration:.1f}s, 原因: {reason})")
                # 播放结束后执行后续操作
                self._execute_on_end_action(nav_item)
            else:
                reason = result.get('reason', 'unknown')
                self.logger.warning(f"[播放循环] 媒体播放等待失败 (原因: {reason})")
                overall_success = False
                # 浏览器已关闭，紧急保存进度后退出循环
                if reason == 'browser_closed':
                    self.logger.warning("[播放循环] 浏览器已关闭，循环终止")
                    if self.progress_saver:
                        self.progress_saver.save_now()
                        self.progress_saver.stop()
                    break
                # 失败后不立即终止，尝试继续循环（可能是临时问题）
                # 但如果原因是不存在媒体元素或页面跳转，则终止
                if 'no media' in reason.lower() or 'not found' in reason.lower():
                    self.logger.error("[播放循环] 媒体元素不存在，循环终止")
                    break
                if 'page_navigated_away' in reason:
                    self.logger.error("[播放循环] 页面意外跳转且无法恢复，循环终止")
                    break

        loop_total = loop_idx if step_max_loops == 0 else min(loop_idx, step_max_loops)
        self.logger.info(f"[播放循环] 循环结束，共执行 {loop_total} 轮")
        return overall_success

    def _pick_best_element(self, elements):
        """从匹配元素中选择最佳点击目标：
        1. 可见 + 可交互标签 > 2. 可见 + 普通标签 > 3. 不可见
        同优先级取第一个
        """
        if not elements:
            return None

        visible_interactive = []
        visible_normal = []
        invisible = []

        for el in elements:
            try:
                tag = el.evaluate('el => el.tagName').upper()
                visible = el.is_visible()

                if not visible or tag in self.SKIP_TAGS:
                    invisible.append(el)
                    continue

                if tag in self.INTERACTIVE_TAGS or el.evaluate(
                    'el => { const t = el.tagName; '
                    'return t === "A" && el.hasAttribute("href") || '
                    't === "INPUT" || t === "BUTTON" || '
                    'el.onclick !== null || '
                    'el.getAttribute("role") === "button" || '
                    'el.getAttribute("role") === "link"; }'
                ):
                    visible_interactive.append((el, tag))
                else:
                    visible_normal.append((el, tag))
            except Exception:
                continue

        if visible_interactive:
            el, tag = visible_interactive[0]
            self.logger.info(f"选择可交互元素: <{tag}> (共{len(visible_interactive)}个可选)")
            return el
        if visible_normal:
            el, tag = visible_normal[0]
            self.logger.info(f"选择可见元素: <{tag}> (无可交互元素，共{len(visible_normal)}个可选)")
            return el

        return None

    def click_element(self, selector, timeout=10):
        try:
            start_time = time.time()
            while time.time() - start_time < timeout:
                try:
                    # 记录点击前的页面数量
                    page_count_before = self._pw(lambda: len(self.browser.context.pages))

                    # 使用 browser 统一选择器解析（含自动回退），线程安全
                    elements, used_sel, sel_type, fallback_tried = \
                        self._pw(lambda: self.browser.query_all_with_fallback(selector))

                    if elements:
                        element = self._pw(lambda: self._pick_best_element(elements))
                        if element:
                            self._pw(lambda: element.click())
                            if used_sel != selector:
                                self.logger.info(f"点击成功(回退): {selector} -> {used_sel}")
                            else:
                                self.logger.info(f"点击成功: {selector}")

                            # 检测是否打开了新标签页，自动切换
                            self._detect_and_switch_new_page(page_count_before)
                            return True
                        else:
                            self.logger.warning(f"匹配到{len(elements)}个元素但无可点击目标")
                except Exception:
                    pass
                time.sleep(0.5)

            self.logger.warning(f"未找到可点击元素: {selector}")
            return False
        except Exception as e:
            self.logger.error(f"点击元素异常: {selector}, 错误: {e}")
            return False

    def _detect_and_switch_new_page(self, page_count_before):
        """点击后检测是否有新标签页打开，如有则自动切换到新标签页。
        增加短暂等待和重试机制，确保新标签页有足够时间被创建。
        """
        try:
            # 短暂等待让浏览器有时间打开新标签页（部分网站有延迟）
            time.sleep(0.3)
            pages = self._pw(lambda: self.browser.context.pages)

            if len(pages) > page_count_before:
                new_page = pages[-1]  # 最新打开的标签页
                self.browser.page = new_page
                try:
                    self._pw(lambda: new_page.wait_for_load_state('domcontentloaded', timeout=10000))
                except Exception:
                    pass  # 新页面加载超时不影响切换
                self.logger.info(f"检测到新标签页已打开，自动切换 (共{len(pages)}个标签页)")
            elif len(pages) == page_count_before:
                # 没有新标签页，二次确认：短暂等待后再检查
                time.sleep(0.5)
                pages = self._pw(lambda: self.browser.context.pages)
                if len(pages) > page_count_before:
                    new_page = pages[-1]
                    self.browser.page = new_page
                    try:
                        self._pw(lambda: new_page.wait_for_load_state('domcontentloaded', timeout=10000))
                    except Exception:
                        pass
                    self.logger.info(f"延迟检测到新标签页，自动切换 (共{len(pages)}个标签页)")
                else:
                    # 确认没有新标签页，等待当前页面导航完成
                    try:
                        self._pw(lambda: self.browser.page.wait_for_load_state('domcontentloaded', timeout=5000))
                    except Exception:
                        pass
        except Exception as e:
            self.logger.debug(f"新标签页检测/等待加载: {e}")

    # 媒体操作类型集合
    MEDIA_ACTIONS = {'play', 'pause', 'play_wait', 'play_next'}

    # 需要选择器的操作集合
    SELECTOR_ACTIONS = {'click', 'dblclick', 'input', 'hover', 'select',
                        'check', 'uncheck', 'scroll', 'wait', 'play', 'pause',
                        'play_wait', 'play_next'}

    def _resolve_element(self, selector, timeout=10):
        """使用回退策略查找并返回最佳元素，返回 (element, used_selector) 或 (None, None)"""
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                elements, used_sel, sel_type, fallback_tried = \
                    self._pw(lambda: self.browser.query_all_with_fallback(selector))
                if elements:
                    element = self._pw(lambda: self._pick_best_element(elements))
                    if element:
                        return element, used_sel
                    else:
                        self.logger.warning(f"匹配到{len(elements)}个元素但无可操作目标")
            except Exception:
                pass
            time.sleep(0.5)
        return None, None

    def _resolve_media_selector(self, selector):
        """解析媒体选择器：如果指定选择器能匹配到元素则直接使用，
        否则自动回退查找页面上第一个可见的媒体元素。
        
        解决场景：视频元素 ID 是动态生成的（如 video#chbwdqelsydqdkurrq），
        每次页面加载后 ID 变化，导致保存的选择器失效。
        """
        # 首先检查是否有指定选择器
        if selector:
            try:
                elements, used_sel, _, _ = self._pw(
                    lambda: self.browser.query_all_with_fallback(selector))
                if elements:
                    # 检查是否有可见的媒体元素
                    for el in elements:
                        try:
                            if self._pw(lambda: el.is_visible()):
                                return selector
                        except Exception:
                            continue
            except Exception:
                pass

            # 指定选择器匹配失败，尝试回退
            self.logger.info(f"[媒体回退] 选择器 {selector} 未匹配到可见元素，自动查找页面上的媒体元素")
        
        # 自动查找可见媒体元素，支持多种播放器类型
        fallback = self._find_visible_media_selector()
        if fallback:
            self.logger.info(f"[媒体回退] 使用回退选择器: {fallback}")
        return fallback
    
    def _find_visible_media_selector(self):
        """查找页面上第一个可见的媒体元素，返回其选择器。
        支持多种媒体播放器类型：HTML5 video/audio、Flash、第三方嵌入播放器等。
        
        特别注意 xgplayer 西瓜播放器：它是懒加载的，需要触发播放按钮才会创建 video 元素。
        """
        try:
            # 1. 优先查找HTML5媒体元素（video/audio）
            media_selector = self._pw(lambda: self.browser.page.evaluate("""
                () => {
                    // 查找所有可见的视频和音频元素
                    const mediaElements = Array.from(document.querySelectorAll('video, audio'));
                    const visibleMedia = mediaElements.filter(el => {
                        const rect = el.getBoundingClientRect();
                        return rect.width > 100 && rect.height > 100 && el.offsetWidth > 0;
                    });
                    
                    if (visibleMedia.length > 0) {
                        const el = visibleMedia[0];
                        if (el.id) {
                            return el.tagName.toLowerCase() + '#' + el.id;
                        } else {
                            // 使用CSS选择器定位
                            const idx = Array.prototype.indexOf.call(document.querySelectorAll(el.tagName), el);
                            return el.tagName.toLowerCase() + ':nth-child(' + (idx + 1) + ')';
                        }
                    }
                    
                    // 2. 查找第三方播放器容器
                    // 优先级：xgplayer > video.js > plyr > jwplayer > 其他
                    const playerContainers = [
                        '.xgplayer',           // xgplayer 西瓜播放器 (最优先)
                        '.xgplayer-skin-default',  // xgplayer 默认皮肤
                        '[class*="xgplayer"]',     // xgplayer 任意子类
                        '[class*="xg-player"]',    // xg-player 变体
                        '#videoContainer',         // 通用视频容器 ID
                        '#playerContainer',        // 通用播放器容器 ID
                        '.video-js',           // Video.js
                        '.plyr',              // Plyr
                        '.jwplayer-container', // JW Player
                        '.jwplayer',          // JW Player (其他版本)
                        '.dplayer',           // DPlayer
                        '.vjs-tech',          // Video.js tech element
                        '#player',             // Common player ID
                        '.player',             // Common player class
                        '#video',              // Common video ID
                        '.video',              // Common video class
                        'iframe[src*="youtube.com"]',  // YouTube
                        'iframe[src*="vimeo.com"]',    // Vimeo
                        'iframe[src*="youku.com"]',    // 优酷
                        'iframe[src*="tudou.com"]'    // 土豆
                    ];
                    
                    for (const selector of playerContainers) {
                        const elements = document.querySelectorAll(selector);
                        const visibleElements = Array.from(elements).filter(el => {
                            const rect = el.getBoundingClientRect();
                            return rect.width > 100 && rect.height > 100;
                        });
                        
                        if (visibleElements.length > 0) {
                            const el = visibleElements[0];
                            if (el.id) {
                                return '#' + el.id;
                            } else if (el.classList && el.classList.length > 0) {
                                // 优先使用 xgplayer 类的完整选择器
                                const classes = Array.from(el.classList);
                                const xgClass = classes.find(c => c.startsWith('xgplayer'));
                                if (xgClass) {
                                    return '.xgplayer';
                                }
                                const classStr = classes.filter(c => c.length < 30).slice(0, 2).join('.');
                                return classStr ? '.' + classStr : selector;
                            } else {
                                return selector;
                            }
                        }
                    }
                    
                    // 3. 查找Flash播放器
                    const flashPlayers = Array.from(document.querySelectorAll('object, embed'));
                    const visibleFlash = flashPlayers.filter(el => {
                        const rect = el.getBoundingClientRect();
                        return rect.width > 100 && rect.height > 100;
                    });
                    
                    if (visibleFlash.length > 0) {
                        const el = visibleFlash[0];
                        if (el.id) {
                            return el.tagName.toLowerCase() + '#' + el.id;
                        } else if (el.classList && el.classList.length > 0) {
                            return el.tagName.toLowerCase() + '.' + Array.from(el.classList).join('.');
                        } else {
                            return el.tagName.toLowerCase();
                        }
                    }
                    
                    return null;
                }
            """))
            
            # 如果找到了具体选择器，返回它
            if media_selector:
                # 对于 xgplayer，需要额外处理 - 使用 browser.trigger_xgplayer() 触发播放按钮
                if '.xgplayer' in media_selector:
                    self.logger.info("[媒体选择器] 检测到 xgplayer 播放器，尝试触发播放...")
                    # 使用 browser 的 trigger_xgplayer 方法（使用 Playwright 原生 click）
                    trigger_ok = self._pw(lambda: self.browser.trigger_xgplayer())
                    if trigger_ok:
                        self.logger.info("[媒体选择器] xgplayer 触发成功，返回 'video' 选择器")
                        return 'video'  # 触发后 video 元素被创建，返回 video 选择器
                    else:
                        self.logger.warning("[媒体选择器] xgplayer 触发失败，尝试使用 xgplayer 选择器")

                return media_selector
            
            # 未找到任何播放器，可能是页面还在加载中，等待并重试
            self.logger.info("[媒体选择器] 首次未找到播放器，等待3秒后重试...")
            time.sleep(3)
            
            # 重试查找
            media_selector = self._pw(lambda: self.browser.page.evaluate("""
                () => {
                    const mediaElements = Array.from(document.querySelectorAll('video, audio'));
                    const visibleMedia = mediaElements.filter(el => {
                        const rect = el.getBoundingClientRect();
                        return rect.width > 100 && rect.height > 100 && el.offsetWidth > 0;
                    });
                    if (visibleMedia.length > 0) {
                        const el = visibleMedia[0];
                        return el.id ? (el.tagName.toLowerCase() + '#' + el.id) : 'video';
                    }
                    const playerContainers = [
                        '.xgplayer', '.xgplayer-skin-default',
                        '[class*="xgplayer"]', '[class*="xg-player"]',
                        '#videoContainer', '#playerContainer',
                        '.video-js', '.plyr', '.jwplayer-container',
                        '.jwplayer', '.dplayer', '.vjs-tech',
                        '#player', '.player', '#video', '.video'
                    ];
                    for (const selector of playerContainers) {
                        const elements = document.querySelectorAll(selector);
                        const visibleElements = Array.from(elements).filter(el => {
                            const rect = el.getBoundingClientRect();
                            return rect.width > 100 && rect.height > 100;
                        });
                        if (visibleElements.length > 0) {
                            const el = visibleElements[0];
                            if (el.id) return '#' + el.id;
                            if (el.classList && el.classList.length > 0) {
                                const classes = Array.from(el.classList);
                                const xgClass = classes.find(c => c.startsWith('xgplayer'));
                                if (xgClass) return '.xgplayer';
                                const classStr = classes.filter(c => c.length < 30).slice(0, 2).join('.');
                                return classStr ? '.' + classStr : selector;
                            }
                            return selector;
                        }
                    }
                    return null;
                }
            """))
            
            if media_selector:
                self.logger.info(f"[媒体选择器] 重试找到播放器: {media_selector}")
                if '.xgplayer' in media_selector:
                    self.logger.info("[媒体选择器] 重试检测到 xgplayer，尝试触发播放...")
                    trigger_ok = self._pw(lambda: self.browser.trigger_xgplayer())
                    if trigger_ok:
                        self.logger.info("[媒体选择器] xgplayer 触发成功，返回 'video' 选择器")
                        return 'video'
                return media_selector
            
            # 最后回退到通用选择器
            self.logger.warning("[媒体选择器] 重试仍未找到播放器，使用通用video选择器")
            return 'video'
            
        except Exception as e:
            self.logger.error(f"[媒体选择器] 查找媒体元素失败: {e}")
            return 'video'



    def _handle_stay_time(self, nav_item):
        """处理步骤的停留时间逻辑：
        - stay_time > 0: 固定等待指定秒数（原有逻辑）
        - stay_time == 0 或未设置: 进入智能等待模式，直到步骤操作完全执行完毕
          - 媒体类操作: 等待媒体播放结束
          - 导航类操作: 等待页面加载完成 + 网络空闲
          - 点击类操作: 等待页面稳定（无网络请求）
          - 其他操作: 短暂等待 1 秒
        """
        stay_time = nav_item.get('stay_time', 3)
        action = nav_item.get('action', 'navigate')
        selector = nav_item.get('selector', '')

        # stay_time > 0: 固定等待
        try:
            stay_time = float(stay_time) if stay_time else 3
        except (ValueError, TypeError):
            stay_time = 3

        if stay_time > 0:
            self.logger.info(f"页面停留 {stay_time} 秒")
            elapsed = 0
            while elapsed < stay_time and self.running:
                if not self.paused:
                    elapsed += 0.5
                time.sleep(0.5)
            return

        # stay_time == 0: 智能等待，直到步骤操作完全执行完毕
        self.logger.info(f"停留时间=0，进入智能等待模式 (操作: {action})")
        self._wait_for_step_completion(nav_item)

    def _wait_for_step_completion(self, nav_item):
        """当 stay_time=0 时，智能等待步骤完全执行完毕。
        根据操作类型采用不同的等待策略：

        1. 媒体播放类 (play/play_wait/play_next):
           等待媒体播放结束（ended 事件），或直到页面中所有媒体均不在播放状态
        2. 导航类 (navigate):
           等待页面 load 完成 + 网络空闲
        3. 点击/输入类 (click/dblclick/input/select 等):
           等待页面网络空闲 + DOM 稳定
        4. 其他操作:
           短暂等待 1 秒
        """
        action = nav_item.get('action', 'navigate')
        selector = nav_item.get('selector', '')

        # ===== 策略1: 媒体播放类 — 等待所有媒体播放结束 =====
        if action in self.MEDIA_ACTIONS:
            self._wait_for_media_completion(nav_item)
            return

        # ===== 策略2: 导航类 — 等待页面加载完成 =====
        if action == 'navigate':
            self.logger.info("[智能等待] 等待页面加载完成...")
            try:
                self._pw(lambda: self.browser.page.wait_for_load_state('load', timeout=30000))
                self.logger.info("[智能等待] 页面加载完成，等待网络空闲...")
                self._pw(lambda: self.browser.page.wait_for_load_state('networkidle', timeout=15000))
                self.logger.info("[智能等待] 页面已稳定")
            except Exception as e:
                self.logger.debug(f"[智能等待] 页面等待超时(可忽略): {e}")
            return

        # ===== 策略3: 点击/输入等交互类 — 等待页面稳定 =====
        interactive_actions = {'click', 'dblclick', 'input', 'select', 'check', 'uncheck',
                               'hover', 'scroll'}
        if action in interactive_actions:
            self.logger.info("[智能等待] 等待操作后页面稳定...")
            # 短暂等待让浏览器处理点击事件
            time.sleep(0.5)
            try:
                # 等待网络空闲（说明点击触发的请求已完成）
                self._pw(lambda: self.browser.page.wait_for_load_state('networkidle', timeout=10000))
                self.logger.info("[智能等待] 页面已稳定（网络空闲）")
            except Exception:
                # 网络空闲超时，使用 DOM 稳定检测
                self.logger.debug("[智能等待] 网络空闲超时，检测DOM稳定...")
                self._wait_for_dom_stable()
            return

        # ===== 策略4: 其他操作 — 短暂等待 =====
        self.logger.info("[智能等待] 等待 1 秒...")
        elapsed = 0
        while elapsed < 1 and self.running:
            time.sleep(0.5)
            elapsed += 0.5

    def _wait_for_media_completion(self, nav_item):
        """等待媒体播放完全结束。用于 stay_time=0 时的媒体类操作。
        检测策略：
        1. 如果步骤是 play_wait/play_next，_execute_step 内部已等待完成，只需额外确认
        2. 如果步骤是 play/pause，需要轮询检测媒体状态
        3. 检测页面中所有媒体元素是否均已结束或暂停
        """
        action = nav_item.get('action', 'navigate')
        selector = nav_item.get('selector', '')
        try:
            media_timeout = float(nav_item.get('media_timeout', 3600))
        except (ValueError, TypeError):
            media_timeout = 3600

        # play_wait / play_next 在 _execute_step 中已经等待完毕
        if action in ('play_wait', 'play_next'):
            self.logger.info("[智能等待] 媒体播放步骤已在执行中等待完成")
            return

        # play / pause: 需要主动检测媒体播放状态
        if action == 'play' and selector:
            self.logger.info(f"[智能等待] 等待媒体播放结束: {selector}")
            result = self._pw(lambda: self.browser.wait_for_media_ended(selector, timeout=media_timeout))
            if result.get('success'):
                self.logger.info(f"[智能等待] 媒体播放结束 (时长: {result.get('duration', 0):.1f}s)")
            else:
                self.logger.warning(f"[智能等待] 媒体等待超时或失败: {result.get('reason', 'unknown')}")
            return

        # 通用检测：等待页面中所有媒体播放完毕
        self.logger.info("[智能等待] 检测页面中所有媒体播放状态...")
        start_time = time.time()
        check_timeout = 3600  # 最大等待 1 小时

        while time.time() - start_time < check_timeout and self.running:
            try:
                # 检查页面中是否有正在播放的媒体
                has_playing = self._pw(lambda: self.browser.page.evaluate("""() => {
                    var mediaEls = document.querySelectorAll('video, audio');
                    for (var i = 0; i < mediaEls.length; i++) {
                        var el = mediaEls[i];
                        if (el.offsetWidth > 0 && !el.paused && !el.ended) {
                            return true;  // 仍有正在播放的媒体
                        }
                    }
                    return false;  // 所有媒体均已暂停或结束
                }"""))
                if not has_playing:
                    self.logger.info("[智能等待] 页面中所有媒体已停止播放")
                    return
            except Exception as e:
                self.logger.debug(f"[智能等待] 媒体状态检测异常: {e}")

            # 检查暂停状态
            while self.paused and self.running:
                time.sleep(0.5)

            time.sleep(1)

        if not self.running:
            return
        self.logger.warning("[智能等待] 媒体等待超时")

    def _wait_for_dom_stable(self):
        """等待 DOM 稳定（连续两次检查子节点数量不变则认为稳定）。
        适用于点击后不确定是否会触发导航的场景。
        """
        try:
            self.logger.debug("[智能等待] 检测DOM稳定...")
            stable_count = 0
            last_node_count = -1

            for _ in range(20):  # 最多检查 20 次（约 10 秒）
                if not self.running:
                    break
                current_count = self._pw(lambda: self.browser.page.evaluate(
                    "document.querySelectorAll('*').length"))
                if current_count == last_node_count:
                    stable_count += 1
                    if stable_count >= 3:  # 连续 3 次（1.5秒）节点数不变则认为稳定
                        self.logger.info("[智能等待] DOM已稳定")
                        return
                else:
                    stable_count = 0
                last_node_count = current_count
                time.sleep(0.5)

            self.logger.debug("[智能等待] DOM稳定检测超时，继续执行")
        except Exception as e:
            self.logger.debug(f"[智能等待] DOM稳定检测异常: {e}")

    def _execute_step(self, nav_item):
        """执行单个步骤，返回 (success, debug_info)"""
        name = nav_item.get('name', '未知')
        url = nav_item.get('url', '')
        stay_time = nav_item.get('stay_time', 3)
        action = nav_item.get('action', 'navigate')
        selector = nav_item.get('selector', '')
        tab_index = nav_item.get('tab_index', -1)

        # 步骤级弹窗规则：将步骤绑定的弹窗规则与全局规则合并
        step_popup_rules = nav_item.get('popup_rules', [])
        self.popup_handler.set_step_popup_rules(step_popup_rules)

        # 标签页切换：如果步骤指定了目标标签页，临时切换
        # 使用 URL/标题作为回退匹配线索，避免标签页动态变化导致索引越界
        original_page = None
        if tab_index >= 0:
            original_page = self.browser.page
            # 提取回退匹配信息：步骤的 URL 或选择器中的文本作为回退线索
            fallback_url = url if url else None
            fallback_title = None
            # 从 text= 选择器中提取回退标题
            if selector and selector.startswith('text='):
                fallback_title = selector[5:].strip()[:30]
            switched = self._pw(lambda: self.browser.switch_to_page(
                tab_index, fallback_url=fallback_url, fallback_title=fallback_title))
            if not switched:
                # 标签页切换失败：不直接跳过，而是尝试在当前页面执行
                self.logger.warning(
                    f"标签页 {tab_index} 切换失败，尝试在当前页面执行步骤: {name}")
                # 重置 original_page，避免后续恢复逻辑干扰
                original_page = None

        debug_info = {
            'name': name,
            'action': action,
            'url': url,
            'selector': selector,
            'stay_time': stay_time,
            'tab_index': tab_index,
            'page_before': self._pw(lambda: self.browser.get_page_info()),
            'selector_test': None,
            'result': None,
            'error': None,
            'page_after': None,
        }

        # 需要选择器的操作：先测试选择器
        # 媒体操作例外：选择器可能因动态ID失效，后续有 _resolve_media_selector 回退
        if action in self.SELECTOR_ACTIONS and selector and action not in self.MEDIA_ACTIONS:
            test_result = self._pw(lambda: self.browser.test_selector(selector))
            debug_info['selector_test'] = test_result
            if not test_result['success'] or test_result['count'] == 0:
                debug_info['result'] = 'fail'
                debug_info['error'] = f"选择器未匹配到元素: {selector}"
                self.logger.warning(f"[调试] 选择器未匹配: {selector}")
                return False, debug_info

        success = False
        try:
            if action == 'navigate':
                # 导航操作
                if url:
                    retry_count = self.settings.get('retry_count', 2)
                    for attempt in range(retry_count + 1):
                        if not self.running:
                            break
                        self.logger.info(f"访问栏目: {name} ({attempt + 1}/{retry_count + 1})")
                        if self._pw(lambda: self.browser.goto_page(url, self.settings.get('global_timeout', 30000))):
                            success = True
                            break
                        if attempt < retry_count:
                            self.logger.info("重试等待中...")
                            time.sleep(2)
                else:
                    debug_info['result'] = 'skip'
                    debug_info['error'] = f"步骤 {name} 缺少 URL"
                    self.logger.warning(f"步骤 {name} 缺少 URL，跳过")
                    return False, debug_info

            elif action == 'click':
                self.logger.info(f"执行点击操作: {name}")
                success = self.click_element(selector)

            elif action == 'dblclick':
                self.logger.info(f"执行双击操作: {name}")
                page_count_before = self._pw(lambda: len(self.browser.context.pages))
                element, used_sel = self._resolve_element(selector)
                if element:
                    self._pw(lambda: element.dblclick())
                    if used_sel != selector:
                        self.logger.info(f"双击成功(回退): {selector} -> {used_sel}")
                    else:
                        self.logger.info(f"双击成功: {selector}")
                    self._detect_and_switch_new_page(page_count_before)
                    success = True
                else:
                    self.logger.warning(f"双击未找到元素: {selector}")

            elif action == 'input':
                input_text = nav_item.get('input_text', '')
                self.logger.info(f"执行输入操作: {name} (内容: {input_text[:30]})")
                element, used_sel = self._resolve_element(selector)
                if element:
                    self._pw(lambda: element.fill(input_text))
                    if used_sel != selector:
                        self.logger.info(f"输入成功(回退): {selector} -> {used_sel}")
                    else:
                        self.logger.info(f"输入成功: {selector}")
                    success = True
                else:
                    self.logger.warning(f"输入未找到元素: {selector}")

            elif action == 'hover':
                self.logger.info(f"执行悬停操作: {name}")
                element, used_sel = self._resolve_element(selector)
                if element:
                    self._pw(lambda: element.hover())
                    if used_sel != selector:
                        self.logger.info(f"悬停成功(回退): {selector} -> {used_sel}")
                    else:
                        self.logger.info(f"悬停成功: {selector}")
                    success = True
                else:
                    self.logger.warning(f"悬停未找到元素: {selector}")

            elif action == 'select':
                select_value = nav_item.get('select_value', '')
                self.logger.info(f"执行选择操作: {name} (值: {select_value})")
                element, used_sel = self._resolve_element(selector)
                if element:
                    self._pw(lambda: element.select_option(select_value))
                    if used_sel != selector:
                        self.logger.info(f"选择成功(回退): {selector} -> {used_sel}")
                    else:
                        self.logger.info(f"选择成功: {selector}")
                    success = True
                else:
                    self.logger.warning(f"选择未找到元素: {selector}")

            elif action == 'check':
                self.logger.info(f"执行勾选操作: {name}")
                element, used_sel = self._resolve_element(selector)
                if element:
                    self._pw(lambda: element.check())
                    if used_sel != selector:
                        self.logger.info(f"勾选成功(回退): {selector} -> {used_sel}")
                    else:
                        self.logger.info(f"勾选成功: {selector}")
                    success = True
                else:
                    self.logger.warning(f"勾选未找到元素: {selector}")

            elif action == 'uncheck':
                self.logger.info(f"执行取消勾选操作: {name}")
                element, used_sel = self._resolve_element(selector)
                if element:
                    self._pw(lambda: element.uncheck())
                    if used_sel != selector:
                        self.logger.info(f"取消勾选成功(回退): {selector} -> {used_sel}")
                    else:
                        self.logger.info(f"取消勾选成功: {selector}")
                    success = True
                else:
                    self.logger.warning(f"取消勾选未找到元素: {selector}")

            elif action == 'scroll':
                self.logger.info(f"执行滚动到元素: {name}")
                element, used_sel = self._resolve_element(selector)
                if element:
                    self._pw(lambda: element.scroll_into_view_if_needed())
                    if used_sel != selector:
                        self.logger.info(f"滚动成功(回退): {selector} -> {used_sel}")
                    else:
                        self.logger.info(f"滚动成功: {selector}")
                    success = True
                else:
                    self.logger.warning(f"滚动未找到元素: {selector}")

            elif action == 'wait':
                wait_timeout = nav_item.get('wait_timeout', 30000)
                self.logger.info(f"等待元素出现: {name} (超时: {wait_timeout}ms)")
                try:
                    pw_sel, sel_type = self._pw(lambda: self.browser.parse_selector(selector))
                    self._pw(lambda: self.browser.page.wait_for_selector(
                        pw_sel, timeout=wait_timeout, state='visible'))
                    self.logger.info(f"等待元素成功: {selector}")
                    success = True
                except Exception as e:
                    self.logger.warning(f"等待元素超时或失败: {selector}, 错误: {e}")

            elif action == 'play':
                self.logger.info(f"执行播放媒体: {name}")
                actual_selector = self._resolve_media_selector(selector)
                element, used_sel = self._resolve_element(actual_selector)
                if element:
                    self._pw(lambda: element.evaluate('el => el.play()'))
                    if used_sel != actual_selector:
                        self.logger.info(f"播放成功(回退): {selector} -> {used_sel}")
                    else:
                        self.logger.info(f"播放成功: {selector}")
                    success = True
                else:
                    self.logger.warning(f"播放未找到媒体元素: {selector}")

            elif action == 'pause':
                self.logger.info(f"执行暂停媒体: {name}")
                actual_selector = self._resolve_media_selector(selector)
                element, used_sel = self._resolve_element(actual_selector)
                if element:
                    self._pw(lambda: element.evaluate('el => el.pause()'))
                    if used_sel != actual_selector:
                        self.logger.info(f"暂停成功(回退): {selector} -> {used_sel}")
                    else:
                        self.logger.info(f"暂停成功: {selector}")
                    success = True
                else:
                    self.logger.warning(f"暂停未找到媒体元素: {selector}")

            elif action == 'play_wait':
                self.logger.info(f"执行播放并等待结束: {name}")
                try:
                    media_timeout = float(nav_item.get('media_timeout', 3600))
                except (ValueError, TypeError):
                    media_timeout = 3600
                # 尝试用指定选择器，如果失败则自动回退到页面上可见的媒体元素
                actual_selector = self._resolve_media_selector(selector)
                # 使用分段式等待：轮询在后台线程，Playwright 操作通过 _pw 分段调度
                # 不再通过 _pw 调度整个 wait_for_media_ended（会因 60s 超时而崩溃）
                result = self._wait_media_ended_safe(actual_selector, timeout=media_timeout)
                if result.get('success'):
                    duration = result.get('duration', 0)
                    reason = result.get('reason', '')
                    self.logger.info(f"媒体播放结束: {actual_selector} (时长: {duration:.1f}s, 原因: {reason})")
                    success = True
                    # 播放结束后执行后续操作
                    self._execute_on_end_action(nav_item)
                    # 播放循环：如果配置了步骤循环，重新播放媒体（不重新导航页面）
                    success = self._execute_play_loop(nav_item, actual_selector, media_timeout, success)
                else:
                    reason = result.get('reason', 'unknown')
                    self.logger.warning(f"媒体播放等待失败: {actual_selector} (原因: {reason})")

            elif action == 'play_next':
                self.logger.info(f"执行播放并自动下一曲: {name}")
                try:
                    media_timeout = float(nav_item.get('media_timeout', 3600))
                except (ValueError, TypeError):
                    media_timeout = 3600
                # 尝试用指定选择器，如果失败则自动回退到页面上可见的媒体元素
                actual_selector = self._resolve_media_selector(selector)
                # 使用分段式等待，不通过 _pw 调度整个 play_next_media
                result = self._play_next_media_safe(actual_selector, timeout=media_timeout)
                if result.get('success'):
                    next_played = result.get('next_played', False)
                    next_sel = result.get('next_selector', '')
                    if next_played:
                        self.logger.info(f"当前媒体播放结束，已自动播放下一个: {next_sel}")
                    else:
                        self.logger.info(f"当前媒体播放结束，没有更多媒体可播放")
                    success = True
                    # 播放结束后执行后续操作
                    self._execute_on_end_action(nav_item)
                    # 播放循环：如果配置了步骤循环，重新播放媒体（不重新导航页面）
                    success = self._execute_play_loop(nav_item, actual_selector, media_timeout, success)
                else:
                    reason = result.get('reason', 'unknown')
                    self.logger.warning(f"播放下一曲失败: {selector} (原因: {reason})")

            elif action == 'play_list':
                self.logger.info(f"执行按列表播放: {name}")
                success = self._execute_play_list(nav_item)

            else:
                debug_info['result'] = 'skip'
                debug_info['error'] = f"未知操作类型: {action}"
                self.logger.warning(f"未知操作类型: {action}，跳过")
                return False, debug_info

            debug_info['result'] = 'success' if success else 'fail'
            if not success:
                debug_info['error'] = f"步骤执行失败: {name}"
            debug_info['page_after'] = self._pw(lambda: self.browser.get_page_info())

            # 步骤执行成功后，记录当前标签页状态（帮助诊断后续步骤的标签页索引问题）
            if success:
                try:
                    all_pages = self._pw(lambda: self.browser.context.pages)
                    current_idx = all_pages.index(self.browser.page) if self.browser.page in all_pages else -1
                    self.logger.info(
                        f"[标签页状态] 当前共{len(all_pages)}个标签页, "
                        f"活跃页索引={current_idx}, 页面={debug_info['page_after'].get('title', '')[:30]}")
                except Exception:
                    pass

            # 步骤执行成功后，开始记录此页面的停留时间
            # 计时从页面完全加载完毕后开始
            if success:
                self._pw(lambda: self.browser.start_stay_tracking(
                    step_name=name, action=action))

        except Exception as e:
            debug_info['result'] = 'error'
            debug_info['error'] = str(e)
            try:
                debug_info['page_after'] = self._pw(lambda: self.browser.get_page_info())
            except Exception:
                debug_info['page_after'] = None
            # 检测浏览器死亡异常，触发恢复流程
            if self._check_browser_death(e):
                self.logger.warning(f"[步骤执行] 检测到浏览器死亡异常: {e}")
                self._signal_browser_died()
            # 异常时结束停留记录
            try:
                self._pw(lambda: self.browser.end_stay_tracking('error'))
            except Exception:
                pass

        # 恢复原始标签页（仅当操作没有产生新标签页时恢复）
        if original_page is not None:
            try:
                # 如果点击后自动切换到了新标签页，不恢复
                current_pages = self._pw(lambda: self.browser.context.pages)
                if self.browser.page not in current_pages:
                    # browser.page 已不在页面列表中（被关闭等），恢复
                    self.browser.page = original_page
                    self.logger.info("当前页面已失效，已恢复到原始标签页")
                elif self.browser.page is original_page:
                    # 没有发生标签页切换，无需恢复
                    pass
                elif self.browser.page is not original_page and \
                        original_page in current_pages:
                    # 点击操作打开了新标签页，保留新标签页不恢复
                    self.logger.info("点击操作打开了新标签页，保留当前标签页")
            except Exception:
                pass

        # 步骤执行完毕，清除步骤级弹窗规则，恢复为全局规则
        self.popup_handler.clear_step_popup_rules()

        return success, debug_info

    def run_step(self, step_index):
        """执行单步（供 GUI 调用），返回 (success, debug_info)"""
        if step_index < 0 or step_index >= len(self.navigation_list):
            self.logger.error(f"步骤索引越界: {step_index}")
            return False, {'error': f'步骤索引越界: {step_index}'}

        nav_item = self.navigation_list[step_index]
        self.current_step_index = step_index
        self.running = True
        self.manual_end_event.clear()
        self.waiting_manual_end = False
        is_last_step = (step_index == len(self.navigation_list) - 1)

        # 读取步骤级循环配置
        loop_infinite = nav_item.get('loop_infinite', False)
        loop_count = nav_item.get('loop_count', 1)
        if loop_infinite:
            step_max_loops = 0  # 0 表示无限
        else:
            step_max_loops = max(1, loop_count)

        # 播放类动作的循环逻辑已内嵌在 _execute_step 中
        is_play_action = nav_item.get('action', '') in ('play_wait', 'play_next', 'play_list')
        if is_play_action and (loop_infinite or loop_count > 1):
            effective_max_loops = 1  # 播放循环由内部处理
        else:
            effective_max_loops = step_max_loops

        step_loop_idx = 0
        last_success = False
        last_debug_info = {'result': '未执行'}

        while self.running:
            step_loop_idx += 1
            if effective_max_loops > 0 and step_loop_idx > effective_max_loops:
                break

            loop_hint = f" (循环 {step_loop_idx}/{effective_max_loops})" if effective_max_loops > 0 else f" (循环 {step_loop_idx}/∞)"
            if is_play_action and (loop_infinite or loop_count > 1):
                inner_hint = "∞" if loop_infinite else str(loop_count)
                loop_hint += f" [播放循环x{inner_hint}]"
            self.logger.info(f"===== 单步执行: 步骤 {step_index + 1}/{len(self.navigation_list)}{loop_hint} =====")

            success, debug_info = self._execute_step(nav_item)
            self.current_step_info = debug_info
            last_success = success
            last_debug_info = debug_info

            if success:
                self._handle_stay_time(nav_item)
                # 停留结束后记录数据
                self._pw(lambda: self.browser.end_stay_tracking('step_end'))

                # 最后一步：仅在配置了 wait_manual_end 时等待用户手动确认结束
                if is_last_step and self.running:
                    if effective_max_loops == 0 or step_loop_idx >= effective_max_loops:
                        if nav_item.get('wait_manual_end', False):
                            self.waiting_manual_end = True
                            self.manual_end_event.clear()
                            self.logger.info(
                                f"===== 最后一步 [{nav_item.get('name', '未知')}] 执行完毕 =====\n"
                                f"请确认操作完成后，点击「完成最后步骤」按钮结束")
                            self.manual_end_event.wait()
                            self.waiting_manual_end = False
                            if self.running:
                                self._pw(lambda: self.browser.end_stay_tracking('manual_end'))
                                self.logger.info(f"最后步骤 [{nav_item.get('name', '未知')}] 已手动结束")
                        else:
                            self.logger.info(
                                f"最后步骤 [{nav_item.get('name', '未知')}] 执行完毕，自动结束")

        self.logger.info(f"===== 单步执行结束: {last_debug_info['result']} =====")
        return last_success, last_debug_info

    def test_step(self, step_index):
        """测试步骤（仅检测选择器/URL，不执行点击），返回 debug_info"""
        if step_index < 0 or step_index >= len(self.navigation_list):
            return {'error': f'步骤索引越界: {step_index}'}

        nav_item = self.navigation_list[step_index]
        name = nav_item.get('name', '未知')
        url = nav_item.get('url', '')
        action = nav_item.get('action', 'navigate')
        selector = nav_item.get('selector', '')
        tab_index = nav_item.get('tab_index', -1)

        # 标签页切换：测试时也切换到目标标签页
        original_page = None
        if tab_index >= 0:
            original_page = self.browser.page
            switched = self._pw(lambda: self.browser.switch_to_page(tab_index))
            if not switched:
                return {
                    'name': name, 'action': action, 'url': url,
                    'selector': selector,
                    'page_info': None, 'selector_test': None,
                    'url_reachable': None,
                    'warnings': [f"标签页 {tab_index} 不存在或已关闭"],
                }

        debug_info = {
            'name': name,
            'action': action,
            'url': url,
            'selector': selector,
            'tab_index': tab_index,
            'page_info': self._pw(lambda: self.browser.get_page_info()),
            'selector_test': None,
            'url_reachable': None,
            'warnings': [],
        }

        self.logger.info(f"===== 测试步骤: {name} =====")

        # 测试选择器（所有需要选择器的操作类型）
        if action in self.SELECTOR_ACTIONS and selector:
            test_result = self._pw(lambda: self.browser.test_selector(selector))
            debug_info['selector_test'] = test_result
            if not test_result['success']:
                debug_info['warnings'].append(f"选择器语法错误: {test_result.get('error', '')}")
            elif test_result['count'] == 0:
                debug_info['warnings'].append(f"选择器未匹配到任何元素")
            else:
                for el in test_result['elements']:
                    if not el['visible']:
                        debug_info['warnings'].append(
                            f"元素 {el['index']}: <{el['tag']}> 不可见")
                self.logger.info(
                    f"[测试] 选择器匹配 {test_result['count']} 个元素")

            # 针对特定操作类型的额外检查
            if action == 'check' or action == 'uncheck':
                if test_result.get('count', 0) > 0:
                    for el in test_result.get('elements', []):
                        tag = el.get('tag', '').upper()
                        elem_type = (el.get('type', '') or '').lower()
                        if tag != 'INPUT' or elem_type not in ('checkbox', 'radio'):
                            debug_info['warnings'].append(
                                f"元素 {el['index']}: <{tag} type={elem_type}> 可能不支持勾选操作")
            elif action == 'select':
                if test_result.get('count', 0) > 0:
                    for el in test_result.get('elements', []):
                        tag = el.get('tag', '').upper()
                        if tag != 'SELECT':
                            debug_info['warnings'].append(
                                f"元素 {el['index']}: <{tag}> 不是 SELECT 元素，选择操作可能失败")
            elif action in ('play', 'pause', 'play_wait', 'play_next'):
                if test_result.get('count', 0) > 0:
                    for el in test_result.get('elements', []):
                        tag = el.get('tag', '').upper()
                        if tag not in ('VIDEO', 'AUDIO'):
                            debug_info['warnings'].append(
                                f"元素 {el['index']}: <{tag}> 不是媒体元素(VIDEO/AUDIO)，播放控制可能失败")

        # 测试 URL 可达性（仅检查格式）
        if url:
            if url.startswith('http'):
                debug_info['url_reachable'] = True
            else:
                debug_info['url_reachable'] = False
                debug_info['warnings'].append("URL 格式不正确")

        self.logger.info(f"===== 测试完成: {len(debug_info['warnings'])} 个警告 =====")

        # 恢复原始标签页（测试时不改变浏览器状态）
        if original_page is not None:
            try:
                current_pages = self._pw(lambda: self.browser.context.pages)
                if original_page in current_pages:
                    self.browser.page = original_page
            except Exception:
                pass

        return debug_info

    def run_navigation(self):
        self.running = True
        self.paused = False
        self.manual_end_event.clear()
        self.waiting_manual_end = False

        retry_count = self.settings.get('retry_count', 2)
        loop_run = self.settings.get('loop_run', False)
        total_steps = len(self.navigation_list)

        while self.running:
            for idx, nav_item in enumerate(self.navigation_list):
                if not self.running:
                    break

                # 读取步骤级循环配置
                loop_infinite = nav_item.get('loop_infinite', False)
                loop_count = nav_item.get('loop_count', 1)
                # loop_count=0 且 loop_infinite=True 视为无限；否则至少执行1次
                if loop_infinite:
                    step_max_loops = 0  # 0 表示无限
                else:
                    step_max_loops = max(1, loop_count)

                # 播放类动作（play_wait/play_next）的循环逻辑已内嵌在 _execute_step 中
                # (_execute_play_loop)，不需要外部步骤循环重复执行整个步骤
                is_play_action = nav_item.get('action', '') in ('play_wait', 'play_next', 'play_list')
                if is_play_action and (loop_infinite or loop_count > 1):
                    # 播放循环由内部 _execute_play_loop / _execute_play_list 处理，外部只执行1次完整步骤
                    effective_max_loops = 1
                else:
                    effective_max_loops = step_max_loops

                step_loop_idx = 0
                while self.running:
                    # 步骤循环计数
                    step_loop_idx += 1
                    if effective_max_loops > 0 and step_loop_idx > effective_max_loops:
                        break  # 达到指定循环次数，退出步骤循环

                    while self.paused and self.running:
                        time.sleep(0.5)

                    self.current_step_index = idx
                    is_last_step = (idx == total_steps - 1)

                    # 步骤循环日志
                    loop_hint = f" (循环 {step_loop_idx}/{effective_max_loops})" if effective_max_loops > 0 else f" (循环 {step_loop_idx}/∞)"
                    # 播放类动作提示内部循环
                    if is_play_action and (loop_infinite or loop_count > 1):
                        inner_hint = "∞" if loop_infinite else str(loop_count)
                        loop_hint += f" [播放循环x{inner_hint}]"
                    self.logger.info(f"[步骤循环] 步骤 {idx + 1}/{total_steps}: {nav_item.get('name', '未知')}{loop_hint}")

                    # 单步模式：等待用户点击"下一步"
                    if self.step_mode:
                        self.current_step_info = {
                            'name': nav_item.get('name', '未知'),
                            'index': idx,
                            'total': total_steps,
                        }
                        self.step_ready.clear()
                        self.logger.info(f"[单步] 步骤 {idx + 1}/{total_steps}: {nav_item.get('name', '未知')} — 等待用户确认执行...")
                        self.step_ready.wait()  # 阻塞直到 GUI 放行
                        if not self.running:
                            break

                    success, debug_info = self._execute_step(nav_item)
                    self.current_step_info = debug_info

                    if success:
                        self._handle_stay_time(nav_item)
                        # 停留时间结束后，记录此页面的停留数据
                        self._pw(lambda: self.browser.end_stay_tracking('step_end'))
                    else:
                        self.logger.error(f"栏目 {nav_item.get('name', '未知')} 执行失败，已跳过")

                    # 最后一步：仅在配置了 wait_manual_end 时等待用户手动确认结束
                    if is_last_step and self.running:
                        if effective_max_loops == 0 or step_loop_idx >= effective_max_loops:
                            if nav_item.get('wait_manual_end', False):
                                self.waiting_manual_end = True
                                self.manual_end_event.clear()
                                self.logger.info(
                                    f"===== 最后一步 [{nav_item.get('name', '未知')}] 执行完毕 =====\n"
                                    f"请确认操作完成后，点击「完成最后步骤」按钮结束自动化")
                                # 通知 GUI 进入等待手动结束状态
                                if hasattr(self, '_pw_call') and self._pw_call:
                                    try:
                                        self._pw_call(lambda: None)  # 占位，确保 GUI 线程有机会更新
                                    except Exception:
                                        pass
                                # 阻塞等待用户点击或任务停止
                                self.manual_end_event.wait()
                                self.waiting_manual_end = False
                                if self.running:
                                    self._pw(lambda: self.browser.end_stay_tracking('manual_end'))
                                    self.logger.info(f"最后步骤 [{nav_item.get('name', '未知')}] 已手动结束")
                            else:
                                self.logger.info(
                                    f"[按列表播放] 最后步骤 [{nav_item.get('name', '未知')}] 执行完毕，自动结束")

                    # 非无限循环时，已在 while 条件中判断退出；无限循环则继续

            if not loop_run or not self.running:
                break

        self.logger.info("栏目执行完成")

    def step_next(self):
        """单步模式放行当前步骤"""
        self.step_ready.set()

    def finish_last_step(self):
        """手动结束最后一步"""
        self.manual_end_event.set()

    def pause(self):
        self.paused = True
        self.logger.info("任务已暂停")

    def resume(self):
        self.paused = False
        self.logger.info("任务已恢复")

    def stop(self):
        self.running = False
        self.step_ready.set()  # 解除单步等待
        self.manual_end_event.set()  # 解除手动结束等待
        self.waiting_manual_end = False
        # 任务停止时结束当前停留记录（短超时，避免卡住清理流程）
        try:
            if self._pw_call:
                self._pw_call(lambda: self.browser.end_stay_tracking('stop'), timeout=3)
            else:
                self.browser.end_stay_tracking('stop')
        except Exception:
            pass
        # 清理音频录制器
        self.cleanup_audio_recorder()
        self.logger.info("任务已停止")
