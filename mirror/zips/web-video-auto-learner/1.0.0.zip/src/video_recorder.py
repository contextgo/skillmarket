# -*- coding: utf-8 -*-
"""
视频录制模块 - 基于 ffmpeg 录制浏览器视频
"""
import os
import subprocess
import time
import logging
import json
from datetime import datetime
from pathlib import Path


class VideoRecorder:
    """视频录制器，使用 ffmpeg 捕获浏览器视频"""

    def __init__(self, config=None):
        self.logger = logging.getLogger(__name__)
        self.config = config or {}
        self.recording_enabled = self.config.get('recording', {}).get('enabled', True)
        self.output_dir = self.config.get('recording', {}).get('output_dir', 'recordings')
        self.format = self.config.get('recording', {}).get('format', 'mp4')
        self.quality = self.config.get('recording', {}).get('quality', 'high')

        # 创建输出目录
        if self.recording_enabled:
            Path(self.output_dir).mkdir(parents=True, exist_ok=True)

        # 录制状态
        self._is_recording = False
        self._current_process = None
        self._current_output = None
        self._start_time = None

    def _get_quality_args(self):
        """根据质量设置获取 ffmpeg 参数"""
        quality_presets = {
            'high': [
                '-c:v', 'libx264',
                '-preset', 'medium',
                '-crf', '23',
                '-c:a', 'aac',
                '-b:a', '128k'
            ],
            'medium': [
                '-c:v', 'libx264',
                '-preset', 'fast',
                '-crf', '28',
                '-c:a', 'aac',
                '-b:a', '96k'
            ],
            'low': [
                '-c:v', 'libx264',
                '-preset', 'fast',
                '-crf', '32',
                '-c:a', 'aac',
                '-b:a', '64k'
            ]
        }
        return quality_presets.get(self.quality, quality_presets['high'])

    def _find_ffmpeg(self):
        """查找 ffmpeg 可执行文件路径"""
        # 首先检查系统 PATH
        try:
            result = subprocess.run(['ffmpeg', '-version'],
                                  capture_output=True, text=True)
            if result.returncode == 0:
                return 'ffmpeg'
        except FileNotFoundError:
            pass

        # 检查常见安装路径
        common_paths = [
            r'C:\ffmpeg\bin\ffmpeg.exe',
            r'C:\Program Files\ffmpeg\bin\ffmpeg.exe',
            os.path.expanduser(r'~\AppData\Local\Programs\ffmpeg\bin\ffmpeg.exe'),
        ]

        for path in common_paths:
            if os.path.exists(path):
                return path

        return None

    def start_recording(self, page, output_name=None, width=None, height=None):
        """开始录制视频

        Args:
            page: Playwright page 对象
            output_name: 输出文件名（不含扩展名）
            width: 录制宽度
            height: 录制高度

        Returns:
            str: 输出文件路径，失败返回 None
        """
        if not self.recording_enabled:
            self.logger.info("[录制] 录制功能已禁用")
            return None

        if self._is_recording:
            self.logger.warning("[录制] 已在录制中，请先停止当前录制")
            return None

        # 查找 ffmpeg
        ffmpeg_path = self._find_ffmpeg()
        if not ffmpeg_path:
            self.logger.error("[录制] 未找到 ffmpeg，请先安装 ffmpeg")
            self.logger.info("[录制] 安装方法: https://ffmpeg.org/download.html")
            return None

        # 生成输出文件名
        if not output_name:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_name = f'recording_{timestamp}'

        output_path = os.path.join(self.output_dir, f'{output_name}.{self.format}')
        self._current_output = output_path

        # 获取页面尺寸
        if not width or not height:
            try:
                viewport = page.viewport_size
                width = viewport.get('width', 1920)
                height = viewport.get('height', 1080)
            except Exception:
                width, height = 1920, 1080

        # 创建临时 pipe 名称（Windows 命名管道）
        pipe_name = r'\\.\pipe\video_capture_' + str(os.getpid())

        # 构建 ffmpeg 命令
        quality_args = self._get_quality_args()
        cmd = [
            ffmpeg_path,
            '-f', 'gdigrab',           # Windows 屏幕捕获
            '-i', 'title=.*',          # 捕获所有窗口（可根据标题过滤）
            '-framerate', '30',
            '-offset_x', '0',
            '-offset_y', '0',
            '-video_size', f'{width}x{height}',
            '-probesize', '32M',
            '-max_muxing_queue_size', '1024',
        ] + quality_args + [
            '-y',                       # 覆盖输出文件
            output_path
        ]

        try:
            # 启动 ffmpeg 进程
            self._current_process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.DEVNULL
            )

            self._is_recording = True
            self._start_time = time.time()

            # 等待 ffmpeg 初始化
            time.sleep(0.5)

            # 检查进程是否正常启动
            if self._current_process.poll() is not None:
                stderr = self._current_process.stderr.read().decode('utf-8', errors='ignore')
                self.logger.error(f"[录制] ffmpeg 启动失败: {stderr[:500]}")
                self._is_recording = False
                return None

            self.logger.info(f"[录制] 开始录制: {output_path}")
            return output_path

        except Exception as e:
            self.logger.error(f"[录制] 启动录制失败: {e}")
            self._is_recording = False
            return None

    def stop_recording(self):
        """停止录制

        Returns:
            dict: 录制结果信息，包含路径、时长等
        """
        if not self._is_recording:
            self.logger.warning("[录制] 未在录制中")
            return None

        try:
            # 发送停止信号给 ffmpeg
            if self._current_process:
                self._current_process.terminate()
                try:
                    self._current_process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    self._current_process.kill()
                    self._current_process.wait()

            duration = time.time() - self._start_time if self._start_time else 0

            result = {
                'path': self._current_output,
                'duration': duration,
                'success': os.path.exists(self._current_output) if self._current_output else False
            }

            if result['success']:
                file_size = os.path.getsize(self._current_output)
                result['size_bytes'] = file_size
                result['size_mb'] = round(file_size / (1024 * 1024), 2)
                self.logger.info(
                    f"[录制] 录制完成: {result['path']}, "
                    f"时长: {duration:.1f}秒, 大小: {result['size_mb']}MB"
                )
            else:
                self.logger.error("[录制] 录制文件未生成")

            self._is_recording = False
            self._current_process = None
            self._start_time = None

            return result

        except Exception as e:
            self.logger.error(f"[录制] 停止录制失败: {e}")
            self._is_recording = False
            return None

    def is_recording(self):
        """检查是否正在录制"""
        return self._is_recording

    def get_recordings(self):
        """获取已录制的视频列表"""
        if not os.path.exists(self.output_dir):
            return []

        recordings = []
        for f in os.listdir(self.output_dir):
            if f.endswith(('.mp4', '.mkv', '.avi', '.webm')):
                path = os.path.join(self.output_dir, f)
                recordings.append({
                    'name': f,
                    'path': path,
                    'size': os.path.getsize(path),
                    'created': datetime.fromtimestamp(os.path.getctime(path))
                })

        return sorted(recordings, key=lambda x: x['created'], reverse=True)
