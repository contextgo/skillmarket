# -*- coding: utf-8 -*-
"""
AI 智能总结模块 - 生成带时间戳的会议纪要
"""
import os
import json
import logging
import time
import re
from datetime import datetime


class AISummarizer:
    """AI 总结器，生成带时间戳的会议纪要"""

    def __init__(self, config=None):
        self.logger = logging.getLogger(__name__)
        self.config = config or {}
        self.ai_config = self.config.get('ai_summary', {})

        # API 配置
        self.provider = self.ai_config.get('provider', 'openai')
        self.api_base = self.ai_config.get('api_base', 'https://api.openai.com/v1')
        self.api_key = self.ai_config.get('api_key', '')
        self.model = self.ai_config.get('model', 'gpt-3.5-turbo')
        self.max_tokens = self.ai_config.get('max_tokens', 4000)
        self.temperature = self.ai_config.get('temperature', 0.3)
        self.include_timestamps = self.ai_config.get('include_timestamps', True)
        self.max_key_points = self.ai_config.get('max_key_points', 10)

    def _format_timestamp(self, seconds):
        """格式化时间戳"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"

    def _create_summary_prompt(self, transcription, video_title=""):
        """创建总结提示词"""
        segments = transcription.get('segments', [])
        full_text = transcription.get('text', '')

        # 构建带时间戳的文本
        timestamped_text = ""
        for seg in segments:
            start = self._format_timestamp(seg.get('start', 0))
            text = seg.get('text', '').strip()
            if text:
                timestamped_text += f"[{start}] {text}\n"

        # 系统提示词
        system_prompt = """你是一个专业的会议记录分析助手。你的任务是：

1. 分析视频/音频转录内容
2. 识别并提取关键信息点
3. 生成结构化的会议纪要
4. 为每个要点标注开始和结束时间戳

**输出格式要求**：
- 使用 Markdown 格式
- 包含以下部分：
  1. 概述（视频主题、时长、核心内容简介）
  2. 关键要点列表（每个要点包含：序号、时间范围、内容、重要性等级）
  3. 详细内容分段（按主题/话题划分，每段有时间范围）
  4. 总结与结论

**时间戳格式**：HH:MM:SS - HH:MM:SS
**重要性等级**：高/中/低

请严格按照格式输出，不要遗漏任何重要信息。"""

        # 用户提示词
        if video_title:
            title_hint = f"视频标题：{video_title}\n\n"
        else:
            title_hint = ""

        duration = transcription.get('duration', 0)
        duration_str = self._format_timestamp(duration)

        user_prompt = f"""{title_hint}视频时长：{duration_str}
总字数：{len(full_text)}字

转录内容：
{timestamped_text if timestamped_text else full_text}

请按照上述格式要求，生成详细的会议纪要。"""

        return {
            'system': system_prompt,
            'user': user_prompt
        }

    def _call_openai_api(self, messages):
        """调用 OpenAI 兼容 API"""
        try:
            import openai
        except ImportError:
            self.logger.error("[AI总结] 请安装 openai: pip install openai")
            return None

        try:
            client = openai.OpenAI(
                api_key=self.api_key,
                base_url=self.api_base
            )

            response = client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )

            return response.choices[0].message.content

        except Exception as e:
            self.logger.error(f"[AI总结] API 调用失败: {e}")
            return None

    def _call_siliconflow_api(self, messages):
        """调用 SiliconFlow API"""
        return self._call_openai_api(messages)

    def _call_ollama_api(self, prompt, model=None):
        """调用 Ollama 本地模型 API"""
        model = model or self.ai_config.get('local_model', 'qwen2.5:7b')
        base_url = self.ai_config.get('local_base', 'http://localhost:11434/v1')

        try:
            import openai
            client = openai.OpenAI(
                api_key='ollama',
                base_url=base_url
            )

            response = client.chat.completions.create(
                model=model,
                messages=[{'role': 'user', 'content': prompt}],
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )

            return response.choices[0].message.content

        except Exception as e:
            self.logger.error(f"[AI总结] Ollama API 调用失败: {e}")
            return None

    def summarize(self, transcription, video_title="", use_local=False):
        """生成总结"""
        if not transcription:
            self.logger.error("[AI总结] 转录内容为空")
            return None

        if not self.api_key and not use_local:
            self.logger.error("[AI总结] 未配置 API 密钥")
            return None

        self.logger.info("[AI总结] 正在生成智能总结...")

        prompts = self._create_summary_prompt(transcription, video_title)

        if use_local or self.provider == 'ollama':
            summary_text = self._call_ollama_api(prompts['system'] + "\n\n" + prompts['user'])
        elif self.provider == 'siliconflow':
            summary_text = self._call_siliconflow_api([
                {'role': 'system', 'content': prompts['system']},
                {'role': 'user', 'content': prompts['user']}
            ])
        else:
            summary_text = self._call_openai_api([
                {'role': 'system', 'content': prompts['system']},
                {'role': 'user', 'content': prompts['user']}
            ])

        if not summary_text:
            self.logger.error("[AI总结] 生成总结失败")
            return None

        key_points = self._extract_key_points(summary_text, transcription)

        result = {
            'summary': summary_text,
            'key_points': key_points,
            'video_title': video_title,
            'duration': transcription.get('duration', 0),
            'generated_at': datetime.now().isoformat(),
            'model': self.model if not use_local else self.ai_config.get('local_model', 'local')
        }

        self.logger.info("[AI总结] 总结生成完成")
        return result

    def _extract_key_points(self, summary_text, transcription):
        """从总结中提取关键要点及其时间戳"""
        key_points = []
        time_pattern = r'(\d{2}:\d{2}:\d{2})'

        try:
            lines = summary_text.split('\n')
            current_point = None

            for line in lines:
                if re.match(r'^\d+[.、]\s', line) or line.startswith('###'):
                    if current_point:
                        key_points.append(current_point)

                    timestamps = re.findall(time_pattern, line)
                    title = re.sub(time_pattern, '', line).strip()
                    current_point = {
                        'title': title,
                        'start_time': timestamps[0] if timestamps else None,
                        'end_time': None,
                        'content': ''
                    }
                elif current_point and line.strip() and not line.startswith('#'):
                    current_point['content'] += line.strip() + '\n'

            if current_point:
                key_points.append(current_point)

        except Exception as e:
            self.logger.warning(f"[AI总结] 提取关键要点失败: {e}")

        return key_points

    def generate_meeting_notes(self, transcription, video_title="", use_local=False):
        """生成完整的会议纪要"""
        result = self.summarize(transcription, video_title, use_local)

        if not result:
            return None

        notes = f"""# {video_title or '视频内容'} 会议纪要

## 基本信息

- **生成时间**: {result['generated_at']}
- **视频时长**: {self._format_timestamp(result['duration'])}
- **AI 模型**: {result['model']}
- **字数统计**: {len(transcription.get('text', ''))} 字

---

{result['summary']}

---

## 快速导航

| 序号 | 时间范围 | 主题 | 重要性 |
|:---:|:-------:|:-----|:------:|
"""

        for i, point in enumerate(result.get('key_points', []), 1):
            title = point.get('title', f'要点 {i}')
            start = point.get('start_time', '--:--:--')
            end = point.get('end_time', '--:--:--')
            time_range = f"{start} - {end}" if end else start
            notes += f"| {i} | {time_range} | {title[:30]} | 高 |\n"

        notes += "\n---\n\n## 完整转录文本\n\n"
        for seg in transcription.get('segments', []):
            start = self._format_timestamp(seg.get('start', 0))
            text = seg.get('text', '').strip()
            if text:
                notes += f"[{start}] {text}\n"

        return notes

    def save_summary(self, summary_result, output_path):
        """保存总结结果"""
        if not summary_result:
            return False

        try:
            json_path = output_path.replace('.md', '') + '.json'
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(summary_result, f, ensure_ascii=False, indent=2)

            md_path = output_path.replace('.json', '') + '.md'
            with open(md_path, 'w', encoding='utf-8') as f:
                f.write(summary_result.get('summary', ''))

            self.logger.info(f"[AI总结] 已保存总结: {json_path}")
            return True

        except Exception as e:
            self.logger.error(f"[AI总结] 保存失败: {e}")
            return False
