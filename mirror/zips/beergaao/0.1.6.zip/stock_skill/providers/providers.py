"""数据提供层 - Tushare + 东方财富 + 缓存 + 重试"""
from __future__ import annotations
import logging, time
from typing import Any, Dict, List, Optional
from datetime import date, timedelta
import requests, pandas as pd
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type, before_sleep_log
from ..config import get_config
from ..models import StockInfo, MoneyFlow, SectorFlow, DragonTiger, DataSource

logger = logging.getLogger(__name__)

_retry = retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1,min=1,max=10),
    retry=retry_if_exception_type((requests.RequestException,ConnectionError,TimeoutError)),
    before_sleep=before_sleep_log(logger,logging.WARNING), reraise=True)

class _Cache:
    def __init__(self, ttl=300): self._s={}; self._ttl=ttl
    def get(self, k):
        if k in self._s:
            v,t = self._s[k]
            if time.time()-t < self._ttl: return v
            del self._s[k]
        return None
    def set(self, k, v, ttl=None): self._s[k] = (v, time.time())

_cache = _Cache()

class TushareProvider:
    def __init__(self):
        import tushare as ts
        cfg = get_config()
        if cfg.tushare_token: ts.set_token(cfg.tushare_token)
        self._pro = ts.pro_api()

    @_retry
    def get_daily(self, code, start, end):
        k = f"daily:{code}:{start}:{end}"
        c = _cache.get(k)
        if c is not None: return c
        df = self._pro.daily(ts_code=code, start_date=start, end_date=end)
        if df is not None and not df.empty:
            df = df.sort_values("trade_date").reset_index(drop=True)
            _cache.set(k, df)
        return df if df is not None else pd.DataFrame()

    @_retry
    def get_market_daily(self, td):
        k = f"market:{td}"
        c = _cache.get(k)
        if c is not None: return c
        df = self._pro.daily(trade_date=td)
        if df is not None: _cache.set(k, df)
        return df if df is not None else pd.DataFrame()

    @_retry
    def get_stock_info(self, code):
        k = f"info:{code}"
        c = _cache.get(k)
        if c is not None: return c
        df = self._pro.stock_basic(ts_code=code, fields="ts_code,name,industry,market")
        if df is not None and not df.empty:
            r = df.iloc[0]
            info = StockInfo(code=code, name=r.get("name",code), industry=r.get("industry",""), market=r.get("market",""))
            _cache.set(k, info, 86400)
            return info
        return StockInfo(code=code, name=code)

    @_retry
    def get_trade_dates(self, end, n):
        df = self._pro.trade_cal(exchange="SSE", end_date=end, is_open="1")
        if df is not None and len(df)>=n: return df.head(n)["cal_date"].tolist()
        return []

    @_retry
    def get_dragon_tiger(self, td):
        df = self._pro.top_list(trade_date=td)
        if df is None or df.empty: return []
        return [DragonTiger(code=r.get("ts_code",""),name=r.get("name",""),close=float(r.get("close",0)),
            pct_change=float(r.get("pct_change",0)),net_amount=float(r.get("amount",0)),
            buy_amount=float(r.get("l_buy",0)),sell_amount=float(r.get("l_sell",0)),reason=r.get("reason","")) for _,r in df.head(10).iterrows()]

class EastMoneyProvider:
    HEADERS = {"User-Agent":"Mozilla/5.0","Referer":"https://quote.eastmoney.com/"}
    def __init__(self): self._t = get_config().http_timeout
    @staticmethod
    def _secid(code):
        c = code.split(".")[0]; return f"1.{c}" if code.endswith(".SH") else f"0.{c}"

    @_retry
    def get_realtime_quote(self, code):
        k = f"quote:{code}"; c = _cache.get(k)
        if c is not None: return c
        r = requests.get("https://push2.eastmoney.com/api/qt/stock/get",
            params={"secid":self._secid(code),"fields":"f57,f58,f43,f169,f170,f46,f47,f44,f51","ut":"fa5fd1943c7b386f172d6893dbbd1131"},
            headers=self.HEADERS, timeout=self._t)
        r.raise_for_status(); d = r.json()
        if d.get("data"):
            dd = d["data"]
            res = {"code":code,"name":dd.get("f58",""),"price":dd.get("f43",0)/100,"change_pct":dd.get("f170",0)/100,
                   "volume":dd.get("f47",0),"amount":dd.get("f46",0)/10000,"high":dd.get("f44",0)/100,"low":dd.get("f51",0)/100}
            _cache.set(k, res, 60); return res
        return {}

    @_retry
    def get_money_flow(self, code):
        k = f"flow:{code}"; c = _cache.get(k)
        if c is not None: return c
        r = requests.get("https://push2.eastmoney.com/api/qt/stock/fflow/kline/get",
            params={"secid":self._secid(code),"fields1":"f1,f2,f3,f7","fields2":"f51,f52,f53,f54,f55,f56,f57","klt":"1","lmt":"1"},
            headers=self.HEADERS, timeout=self._t)
        r.raise_for_status(); d = r.json()
        if d.get("data") and d["data"].get("klines"):
            p = d["data"]["klines"][0].split(",")
            if len(p)>=6:
                res = MoneyFlow(code=code,name="",main_net_inflow=round(float(p[1])/10000,2),
                    super_large_net=round(float(p[2])/10000,2),large_net=round(float(p[3])/10000,2),
                    medium_net=round(float(p[4])/10000,2),small_net=round(float(p[5])/10000,2))
                _cache.set(k, res, 120); return res
        return None

    @_retry
    def get_sector_flow(self, limit=10):
        k = f"sector:{limit}"; c = _cache.get(k)
        if c is not None: return c
        r = requests.get("https://push2.eastmoney.com/api/qt/clist/get",
            params={"fid":"f62","po":"1","pz":str(limit),"pn":"1","np":"1","fltt":"2","invt":"2",
                    "fs":"b:BK04801+f:!50","fields":"f12,f14,f2,f3,f62"},
            headers=self.HEADERS, timeout=self._t)
        r.raise_for_status(); d = r.json()
        sectors = []
        if d.get("data") and d["data"].get("diff"):
            for item in d["data"]["diff"]:
                sectors.append(SectorFlow(sector_name=item.get("f14",""),change_pct=round(item.get("f3",0),2),
                    main_net_inflow=round(item.get("f62",0)/10000,2)))
        _cache.set(k, sectors, 120); return sectors

class DataGateway:
    def __init__(self): self.tushare = TushareProvider(); self.eastmoney = EastMoneyProvider()
    def get_kline(self, code, days=250):
        end = date.today().strftime("%Y%m%d"); start = (date.today()-timedelta(days=days)).strftime("%Y%m%d")
        df = self.tushare.get_daily(code, start, end)
        if df.empty: return df
        df = df.rename(columns={"vol":"volume","trade_date":"date"})
        for c in ["open","high","low","close","volume","amount"]:
            if c in df.columns: df[c] = pd.to_numeric(df[c], errors="coerce")
        return df
    def get_market_snapshot(self, td=None):
        if not td: td = date.today().strftime("%Y%m%d")
        return self.tushare.get_market_daily(td)
    def get_stock_info(self, code): return self.tushare.get_stock_info(code)
    def get_money_flow(self, code):
        f = self.eastmoney.get_money_flow(code)
        if f: f.name = self.get_stock_info(code).name
        return f
    def get_sector_flow(self, limit=10): return self.eastmoney.get_sector_flow(limit)
    def get_dragon_tiger(self): return self.tushare.get_dragon_tiger(date.today().strftime("%Y%m%d"))
    def get_realtime_quote(self, code): return self.eastmoney.get_realtime_quote(code)
    def get_recent_trade_dates(self, n=5): return self.tushare.get_trade_dates(date.today().strftime("%Y%m%d"), n)
