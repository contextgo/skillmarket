"""数据模型 - 标准化 I/O"""
from __future__ import annotations
import json
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Any
from enum import Enum
from datetime import date

class SignalType(str, Enum):
    BUY = "买入"
    SELL = "卖出"
    HOLD = "持有"
    WATCH = "观察"

class MarketTrend(str, Enum):
    STRONG_UP = "强势上涨"
    WEAK_UP = "弱势上涨"
    SIDEWAYS = "横盘震荡"
    WEAK_DOWN = "弱势下跌"
    STRONG_DOWN = "强势下跌"

class DataSource(str, Enum):
    TUSHARE = "tushare"
    EASTMONEY = "eastmoney"
    CACHE = "cache"

@dataclass
class StockInfo:
    code: str
    name: str
    industry: str = ""
    market: str = ""

@dataclass
class TradeSignal:
    code: str
    name: str
    signal_type: SignalType
    price: float
    support: float
    resistance: float
    stop_loss: float
    target_price: float
    position_pct: float
    confidence: float
    reason: str
    strategy_name: str = ""
    backtest_win_rate: float = 0.0
    atr: float = 0.0
    timestamp: str = field(default_factory=lambda: date.today().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["signal_type"] = self.signal_type.value
        return d
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)
    def summary(self) -> str:
        return (f"[{self.name}] ({self.code})\n"
                f"  信号: {self.signal_type.value} | 置信度: {self.confidence:.0%}\n"
                f"  价格: {self.price} | 支撑: {self.support} | 压力: {self.resistance}\n"
                f"  止损: {self.stop_loss} | 目标: {self.target_price}\n"
                f"  仓位: {self.position_pct:.0%} | 策略: {self.strategy_name}")

@dataclass
class MarketAnalysis:
    trend: MarketTrend
    score: float
    up_count: int
    down_count: int
    total_count: int
    limit_up: int = 0
    limit_down: int = 0
    volume_ratio: float = 1.0
    advice: str = ""
    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self); d["trend"] = self.trend.value; return d
    def summary(self) -> str:
        return (f"趋势: {self.trend.value} | 情绪: {self.score}/10\n"
                f"涨跌: {self.up_count}↑ / {self.down_count}↓ | 涨停: {self.limit_up} | 跌停: {self.limit_down}\n"
                f"量比: {self.volume_ratio} | {self.advice}")

@dataclass
class MoneyFlow:
    code: str
    name: str
    main_net_inflow: float = 0.0
    super_large_net: float = 0.0
    large_net: float = 0.0
    medium_net: float = 0.0
    small_net: float = 0.0
    data_source: DataSource = DataSource.EASTMONEY
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    def summary(self) -> str:
        d = "流入" if self.main_net_inflow > 0 else "流出"
        return f"[{self.name}] 主力净{d}: {abs(self.main_net_inflow):.0f}万"

@dataclass
class SectorFlow:
    sector_name: str
    change_pct: float
    main_net_inflow: float
    top_stocks: List[str] = field(default_factory=list)

@dataclass
class DragonTiger:
    code: str
    name: str
    close: float
    pct_change: float
    net_amount: float
    buy_amount: float
    sell_amount: float
    reason: str = ""

@dataclass
class BacktestResult:
    total_signals: int
    wins: int
    losses: int
    neutral: int
    win_rate: float
    loss_rate: float
    avg_return: float
    max_drawdown: float
    sharpe_ratio: float
    profit_factor: float
    def summary(self) -> str:
        return (f"信号数: {self.total_signals} | 胜率: {self.win_rate:.0%} | "
                f"均收益: {self.avg_return:+.2%} | 最大回撤: {self.max_drawdown:.2%} | "
                f"夏普: {self.sharpe_ratio:.2f} | 盈亏比: {self.profit_factor:.2f}")

@dataclass
class StockAnalysis:
    info: StockInfo
    signal: Optional[TradeSignal]
    money_flow: Optional[MoneyFlow]
    backtest: Optional[BacktestResult]
    indicators: Dict[str, float] = field(default_factory=dict)
    def to_dict(self) -> Dict[str, Any]:
        return {
            "info": asdict(self.info),
            "signal": self.signal.to_dict() if self.signal else None,
            "money_flow": self.money_flow.to_dict() if self.money_flow else None,
            "backtest": asdict(self.backtest) if self.backtest else None,
            "indicators": self.indicators,
        }

@dataclass
class ReviewReport:
    date: str
    market: MarketAnalysis
    stocks: List[StockAnalysis]
    sectors: List[SectorFlow]
    dragon_tiger: List[DragonTiger]
    def to_dict(self) -> Dict[str, Any]:
        return {"date": self.date, "market": self.market.to_dict(),
                "stocks": [s.to_dict() for s in self.stocks],
                "sectors": [asdict(s) for s in self.sectors],
                "dragon_tiger": [asdict(d) for d in self.dragon_tiger]}
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)
    def summary(self) -> str:
        lines = ["="*50, f"  A 股复盘报告 - {self.date}", "="*50, "", "【大盘环境】", self.market.summary(), ""]
        buy = [s for s in self.stocks if s.signal and s.signal.signal_type == SignalType.BUY]
        watch = [s for s in self.stocks if s.signal and s.signal.signal_type == SignalType.WATCH]
        if buy:
            lines.append("【买入信号】")
            for s in buy:
                lines.append(s.signal.summary())
                if s.money_flow: lines.append(f"  资金: {s.money_flow.summary()}")
                lines.append("")
        else:
            lines.append("【买入信号】暂无\n")
        if watch:
            lines.append("【观察信号】")
            for s in watch: lines.append(s.signal.summary()); lines.append("")
        if self.sectors:
            lines.append("【板块资金 TOP5】")
            for i, sec in enumerate(self.sectors[:5], 1):
                d = "流入" if sec.main_net_inflow > 0 else "流出"
                lines.append(f"  {i}. {sec.sector_name} | {sec.change_pct:+.2f}% | 主力{d}: {abs(sec.main_net_inflow):.0f}万")
        lines.append("\n⚠ 以上分析仅供参考，投资有风险，入市需谨慎")
        lines.append("="*50)
        return "\n".join(lines)
