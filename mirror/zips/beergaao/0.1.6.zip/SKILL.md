---
name: BeerGaao
description: A股量化分析工具。当用户询问股票分析、行情、资金流向、技术指标、回测、复盘、持仓管理、策略归因时使用此技能。支持自然语言输入如"招商银行能不能买"、"今天大盘怎么样"、"复盘一下"。
---

# BeerGaao — A股量化分析

为 AI Agent 提供标准化的 A 股分析能力：行情、技术分析、多因子、策略集成、回测、风控、绩效归因。

## 快速使用

```python
from stock_skill.tools.tools import StockTools
tools = StockTools()

# 技术分析（自动集成：传统策略 + 集成引擎 + ML + 因子IC + 参数校准）
result = tools.analyze_stock("600036.SH")

# 完整复盘
report = tools.full_review()

# 大盘环境
market = tools.analyze_market()
```

## 工具列表（16个）

| 工具 | 功能 | 参数 |
|------|------|------|
| `get_quote` | 实时行情 | `code` |
| `analyze_stock` | 完整分析（策略+集成+ML+IC+校准） | `code` |
| `analyze_market` | 大盘环境分析 | — |
| `get_money_flow` | 资金流向 | `code` |
| `get_sector_flow` | 板块资金排名 | `limit` |
| `get_dragon_tiger` | 龙虎榜 | — |
| `get_positions` | 持仓查询 | — |
| `add_position` | 添加持仓 | `code,price,shares,stop_loss,target` |
| `close_position` | 平仓 | `code` |
| `get_signal_history` | 历史信号 | `code,days` |
| `full_review` | 完整复盘 | `watchlist` |
| `get_market_breadth` | 市场广度 | — |
| `check_correlation` | 相关性检查 | `codes` |
| `circuit_breaker_check` | 熔断检查 | — |
| `evaluate_signal_performance` | 回填信号绩效+刷新策略权重 | — |
| `strategy_attribution` | 策略归因分析 | `days` |

## analyze_stock 返回数据

```json
{
  "info": {"code": "600036.SH", "name": "招商银行", "industry": "银行"},
  "indicators": {"ma5": 35.2, "rsi": 55.3, "macd": 0.12, "...": "..."},
  "support": 34.5, "resistance": 36.8,
  "backtest": {"win_rate": 0.6, "sharpe_ratio": 1.2, "...": "..."},
  "raw_signals": [{"strategy": "macd_cross", "direction": "BUY", "confidence": 0.65, "reason": "..."}],
  "ensemble": {"direction": "BUY", "confidence": 0.72, "consensus": 0.65, "regime": "trend_up"},
  "ml_signal": {"direction": "BUY", "confidence": 0.68, "model": "ensemble_ml"},
  "factor_ic": {"rsi": {"ic": 0.035, "ic_ir": 0.42, "significant": true}},
  "calibration": {"rsi_oversold": {"rsi_threshold": 28}},
  "signal": {"signal_type": "买入", "confidence": 0.72, "stop_loss": 33.5, "target_price": 37.2}
}
```

## 自然语言路由

| 用户输入 | 路由到 |
|---------|--------|
| "招商银行能不能买" | `analyze_stock("600036.SH")` |
| "今天大盘怎么样" | `analyze_market()` |
| "宁德时代资金流向" | `get_money_flow("300750.SZ")` |
| "复盘一下" | `full_review()` |
| "600036和601318相关性" | `check_correlation(["600036.SH","601318.SH"])` |
| "各策略表现如何" | `strategy_attribution()` |

## 信号类型

- **买入** — 多源共识（传统+集成+ML）置信度 ≥ 0.6
- **卖出** — 卖出信号共识 > 买入信号
- **观察** — 有买入信号但置信度 0.4-0.6
- **持有** — 无明确方向信号

## 策略引擎

详见 [strategy-reference.md](strategy-reference.md)

包含：10种传统策略（均含买卖信号）+ 4种ML策略（增量训练+持久化）+ 集成引擎（市场状态检测+动态权重+信号去冗余+IC过滤）

## 因子体系

详见 [factor-reference.md](factor-reference.md)

包含：19个因子（基本面7+资金面6+情绪面6）+ 3种合成方式 + 增强IC分析 + 因子衰减检测

## 风控与回测

详见 [risk-reference.md](risk-reference.md)

包含：动态止损/移动止损/仓位管理/相关性风控/熔断机制 + 专业回测引擎（T+1/涨跌停/成交量约束/成本模型/基准对比）

## 绩效闭环

```
信号发出 → 自动记录 → 5天后回填实际收益 → 各策略胜率统计 → 权重自动反馈
```

- `evaluate_signal_performance` — 回填历史信号收益，刷新策略权重
- `strategy_attribution` — 追踪收益来源到具体策略

## 项目结构

```
stock_skill/
├── tools/tools.py          # 16个Agent工具（主入口）
├── strategies/
│   ├── strategies.py       # 10种传统策略 + 参数校准器
│   ├── ml_strategies.py    # 4种ML策略（增量训练+持久化）
│   ├── ensemble.py         # 集成引擎（市场状态+动态权重）
│   └── optimizer.py        # 参数优化（网格/随机/贝叶斯/遗传）
├── factors/
│   ├── base.py             # 因子基类 + 合成引擎
│   ├── fundamental.py      # 基本面因子
│   ├── capital.py          # 资金面因子
│   ├── sentiment.py        # 情绪面因子
│   └── enhanced_ic.py      # 增强IC分析
├── backtest/engine.py      # 专业回测引擎
├── execution/order.py      # 执行层（T+1/模拟券商）
├── attribution/brinson.py  # Brinson归因
├── providers/providers.py  # 数据源（Tushare+EastMoney）
├── risk.py                 # 风控模块
├── state.py                # SQLite持久化（信号+绩效）
├── config.py               # 配置管理
├── indicators.py           # 技术指标（18个）
├── models.py               # 数据模型
├── semantic.py             # 自然语言接口
└── monitor.py              # 轮询监控
```

## 安装

本技能是一个完整的 Python 包，需要安装依赖后才能使用：

```bash
# 克隆仓库
git clone https://github.com/GanJiaKouN16/BeerGaao.git
cd BeerGaao

# 安装依赖（推荐使用虚拟环境）
pip install -e .

# 或仅安装核心依赖
pip install -r requirements.txt
```

## 配置

通过环境变量或 `config.env` 文件配置：

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `TUSHARE_TOKEN` | — | Tushare API token（必需） |
| `STOP_LOSS_RATE` | -0.04 | 止损率 |
| `TARGET_RATE` | 0.06 | 止盈率 |
| `HOLD_DAYS` | 5 | 持仓天数 |
| `MAX_SINGLE_POSITION` | 0.30 | 单票最大仓位 |
| `COMMISSION_RATE` | 0.0003 | 佣金费率 |

配置文件示例（复制 `config.example.env` 为 `config.env` 并填写）：

```bash
cp config.example.env config.env
# 编辑 config.env，填入你的 TUSHARE_TOKEN
```

## 外部服务

本技能会访问以下外部服务：

| 服务 | 用途 | 端点 |
|------|------|------|
| Tushare API | 获取A股历史行情、实时数据、龙虎榜 | https://api.tushare.pro |
| 东方财富 EastMoney API | 获取实时行情、资金流向、板块数据 | https://push2.eastmoney.com |

## 数据持久化

| 类型 | 位置 | 说明 |
|------|------|------|
| SQLite 数据库 | `DB_PATH` (默认 `stock_skill.db`) | 存储信号历史、持仓、绩效数据 |
| 机器学习模型 | `models/` 目录 | 使用 joblib 安全序列化（pickle 已移除） |

## 安全说明

- **凭证存储**：Tushare Token 通过环境变量或 `config.env` 文件配置，支持可选加密
- **模型序列化**：使用 joblib 替代 pickle，避免反序列化 RCE 风险
- **沙箱运行**：建议在隔离环境（虚拟环境/容器）中运行
- **数据访问**：仅访问公开的A股市场数据，不会读取系统敏感文件

## 输出格式

所有工具返回统一格式：

```json
{"tool": "工具名", "status": "success | error", "data": {...}}
```
