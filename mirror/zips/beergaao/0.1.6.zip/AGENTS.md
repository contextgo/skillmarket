# AGENTS.md — BeerGaao 项目规范

## 项目概述

A 股量化分析 Agent 工具集，为 AI Agent 提供标准化的股票分析能力。

## 技术栈

- Python 3.10+
- pandas / numpy — 数据处理
- requests — HTTP 数据获取
- sqlite3 — 状态持久化
- scikit-learn / xgboost / lightgbm — 机器学习（可选）
- scipy — 因子优化（可选）

## 代码规范

- 使用 `from __future__ import annotations` 启用延迟注解
- 类型注解使用 `Dict[str, float]` 而非 `dict[str, float]`（兼容性）
- 日志使用 `logging.getLogger(__name__)`
- 所有工具方法返回 `{"tool": "name", "status": "success|error", "data": {...}}`
- 异常处理：捕获 Exception，返回 error 状态，不抛出到调用方

## 命名约定

- 策略类：`PascalCase` + `Strategy` 后缀（如 `MABreakoutStrategy`）
- 因子类：`PascalCase` + `Factor` 后缀（如 `PEFactor`）
- 工具方法：`snake_case`（如 `analyze_stock`）
- 配置项：`UPPER_SNAKE_CASE`（如 `STOP_LOSS_RATE`）
- 内部方法：`_` 前缀（如 `_run_backtest`）

## 文件职责

| 文件 | 职责 | 不应包含 |
|------|------|---------|
| `tools/tools.py` | Agent 工具层，串联所有模块 | 业务逻辑实现 |
| `strategies/strategies.py` | 策略定义 + 参数校准 | 回测逻辑 |
| `strategies/ensemble.py` | 集成引擎 + 市场状态 | 具体策略实现 |
| `factors/base.py` | 因子基类 + 合成引擎 | 具体因子实现 |
| `backtest/engine.py` | 回测引擎 | 策略信号生成 |
| `risk.py` | 风控计算 | 持久化 |
| `state.py` | SQLite 持久化 | 业务逻辑 |
| `models.py` | 数据模型定义 | 业务逻辑 |
| `providers/providers.py` | 数据源 + 缓存 | 数据处理 |

## 添加新策略

1. 在 `strategies/strategies.py` 中定义类，继承 `Strategy`
2. 使用 `@register` 装饰器注册
3. 实现 `evaluate(df)` 方法，返回 `RawSignal`（含 BUY 和 SELL 信号）
4. 在 `StrategyCalibrator.PARAM_SPACES` 中添加可校准参数（可选）

## 添加新因子

1. 在 `factors/` 对应文件中定义类，继承 `Factor`
2. 使用 `@register_factor` 装饰器注册
3. 实现 `compute(df, **kwargs)` 方法
4. 在 `tools.py:_STRATEGY_FACTOR_MAP` 中添加策略→因子映射（可选）

## 测试

```bash
python -m pytest tests/ -v
```

## 配置

通过环境变量或 `config.env` 文件，详见 `config.py`
