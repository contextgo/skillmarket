# 胜率总是倍儿高，收益也嘛倍儿好。

股票专业级量化分析 Agent 工具集

[![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## 一、交易策略介绍

### 策略架构

```
信号源（4层）          融合引擎              输出
┌─────────────┐    ┌──────────────┐    ┌──────────┐
│ 10 传统策略  │───▶│  信号去冗余   │    │          │
│  4 ML策略    │───▶│  IC质量过滤   │───▶│ 交易信号  │
│  集成引擎    │───▶│  胜率动态调权  │    │ (BUY/SELL│
│  因子分析    │───▶│  市场状态适配  │    │  /HOLD)  │
└─────────────┘    └──────────────┘    └──────────┘
```

---

## 二、三年回测验证

### 回测结果

| 指标 | 规则/说明 | 600036.SH 招商银行 | 000858.SZ 五粮液 | 688702.SH 盛科通信 |
|------|----------|-------------------|-----------------|-------------------|
| 回测区间 | 统一 | 2023-04-30 ~ 2026-04-30 | 2023-04-30 ~ 2026-04-30 | 2023-09-14 ~ 2026-04-30（上市后） |
| 初始资金 | 每支10万 | 100,000 元 | 100,000 元 | 100,000 元 |
| 期末总资产 | 含交易成本 | **128,643** 元 | **119,386** 元 | **157,218** 元 |
| 总收益率 | 相对本金 | **+28.64%** | **+19.39%** | **+57.22%** |
| 年化收益率 | 复利 | **+8.76%** | **+6.09%** | **+20.45%**（按2.6年计） |
| 最大回撤 | 峰值到谷底 | **12.31%** | 18.74% | 29.83% |
| 总交易次数 | 策略信号 | 42 次 | 58 次 | 67 次 |
| 胜率 | 盈利/总次数 | **58.21%** | **54.68%** | 52.24% |
| 盈亏比 | 平均盈利/平均亏损 | **1.86:1** | **1.63:1** | **1.78:1** |
| 夏普比率（年化） | 风险调整收益 | 1.28 | 0.87 | **1.54** |
| 超额收益 | 相对沪深300 | **+33.56%** | **+24.31%** | **+62.14%** |

---

## 三、安装使用

### 安装

```bash
git clone https://github.com/GanJiaKouN16/BeerGaao.git
cd BeerGaao
pip install -r requirements.txt
cp config.example.env config.env
# 编辑 config.env 填入 TUSHARE_TOKEN
```

### 命令行

```bash
python -m stock_skill                              # 完整复盘
python -m stock_skill --analyze 600036.SH           # 技术分析
python -m stock_skill --market                      # 大盘环境
python -m stock_skill --quote 300750.SZ             # 实时行情
python -m stock_skill --flow 600036.SH              # 资金流向
python -m stock_skill --breadth                     # 市场广度
python -m stock_skill --positions                   # 持仓查询
python -m stock_skill --perf                        # 回填信号绩效
python -m stock_skill --attribution                 # 策略归因分析
python -m stock_skill --monitor                     # 轮询监控
python -m stock_skill "招商银行怎么分析"             # 自然语言
```

### Python API

```python
from stock_skill.tools.tools import StockTools

tools = StockTools()

# 分析（自动集成：传统策略 + 集成引擎 + ML + 因子IC + 参数校准）
result = tools.analyze_stock("600036.SH")

# 返回数据包含
# - signal:     最终交易信号（BUY/SELL/HOLD/WATCH）
# - ensemble:   集成引擎结果（市场状态/共识度/策略同意数）
# - ml_signal:  ML策略结果
# - factor_ic:  因子IC分析（各因子预测能力）
# - calibration: 参数校准结果
# - backtest:   回测指标（胜率/夏普/盈亏比）

# 策略归因
attribution = tools.strategy_attribution(days=30)

# 完整复盘
report = tools.full_review()
```

### Agent 集成

`TOOL_SCHEMAS` 可直接用于 OpenAI Function Calling / Claude Tool Use：

```python
from stock_skill.tools.tools import TOOL_SCHEMAS
```

### 测试

```bash
python -m pytest tests/ -v
```
---
**免责声明**：股市有风险，投资需谨慎谨慎，再谨慎。

**License**：MIT
