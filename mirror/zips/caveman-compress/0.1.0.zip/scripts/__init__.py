"""Caveman compress skill package."""
