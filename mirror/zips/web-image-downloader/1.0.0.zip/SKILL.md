---
name: web-image-downloader
description: |
  网页图片下载器。输入任意网站地址，自动提取并下载该网页上所有的图片。
  当用户说"下载网页图片"、"下载这个网站的所有图片"、"批量下载图片"、
  "下载网页上的图片"、"帮我把这个页面的图片都下下来"时触发。
  支持 JPG、PNG、GIF、WebP、SVG 等常见图片格式。
  特性：去重检测、图集识别、进度显示、尺寸过滤、广告过滤、增量更新。
version: 1.2.0
---

# 🖼️ 网页图片下载器

输入任意网站地址，自动下载该网页上所有的图片，按类型分类并打包为 ZIP。

## 何时使用

- 需要批量获取某个网页上的所有图片
- 收集图片素材、壁纸、参考图
- 备份网站图片资源
- 下载整套相册或图片集

## 目录结构

```
web-image-downloader/
├── SKILL.md              ← 主入口（本文件）
├── references/           ← 详细参考文档
│   ├── filter-rules.md   ← 过滤规则详解
│   ├── api-reference.md  ← 技术接口文档
│   └── output-format.md  ← 输出格式说明
├── scripts/              ← 可执行脚本
│   ├── downloader.py    ← 主下载脚本
│   ├── dedupe.py         ← 去重脚本
│   ├── progress.py       ← 进度条脚本
│   └── zipper.py         ← ZIP 打包脚本
├── assets/               ← 静态资源
│   └── download-form.html ← 下载表单界面
└── evals/                ← 测试用例
    └── evals.json
```

## 使用方法

### 步骤 1：提供网址

输入目标网页的完整 URL 地址。

### 步骤 2：指定参数（可选）

| 参数 | 说明 | 默认值 |
|------|------|--------|
| 保存路径 | 图片保存位置 | `Downloads/web-images/[域名]/` |
| 最小尺寸 | 宽度或高度 ≥ 此值(px) | 100 |
| 最大尺寸 | 宽度或高度 ≤ 此值(px) | 不限制 |
| 图集识别 | 识别并下载图片集 | true |
| 增量更新 | 对比已有文件，只下载新增 | false |

### 步骤 3：执行下载

我会：
1. 抓取网页 HTML 内容
2. 解析所有图片链接
3. 图集识别（画廊/相册模式）
4. 去重检测（MD5 比对）
5. 广告图过滤
6. 按格式分类下载到对应文件夹
7. 显示下载进度
8. 打包为 ZIP

详细过滤规则请阅读 [references/filter-rules.md](references/filter-rules.md)

## 核心功能

1. **去重功能** — MD5 哈希比对，相同图片只保存一份
2. **图集识别** — 自动识别画廊/相册，下载整套图片
3. **下载进度条** — 实时显示 `12/30 (40%)`
4. **尺寸过滤** — 可指定最小/最大图片尺寸
5. **广告过滤** — 自动排除广告图片
6. **增量更新** — 对比已有文件，只下载新增

详细说明请阅读 [references/api-reference.md](references/api-reference.md)

## 输出格式

下载完成后生成：
- 分类文件夹（JPG/、PNG/、GIF/、WebP/、SVG/、Other/）
- report.json 下载报告
- `{域名}.zip` 打包文件

详细格式请阅读 [references/output-format.md](references/output-format.md)

## 示例

```
下载 https://wallhaven.cc/search?q=landscape
```

```
下载 https://example.com/photos，最小 1920px，增量更新
```

```
下载 https://example.com/gallery，最小尺寸 500px，最大尺寸 4000px
```

---

如需使用，请告诉我：
1. **网址**：要下载图片的网页地址
2. **参数**（可选）：尺寸过滤、增量更新等
