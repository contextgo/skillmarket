# 🖼️ Web Image Downloader - 网页图片下载器

输入任意网站地址，自动提取并下载该网页上所有的图片，按类型分类并打包为 ZIP。

## 功能特性

- ✅ 去重功能（MD5 哈希比对）
- ✅ 图集识别（画廊/相册模式）
- ✅ 下载进度条
- ✅ 自定义尺寸过滤
- ✅ 广告图过滤
- ✅ 增量更新
- ✅ 按类型分类（JPG/PNG/GIF/WebP/SVG/Other）
- ✅ 自动打包为 ZIP

## 安装

将整个 `web-image-downloader/` 文件夹复制到技能目录：

```
C:/Users/Administrator/AppData/Roaming/LobsterAI/SKILLs/
```

## 目录结构

```
web-image-downloader/
├── SKILL.md                      # 主入口文件
├── README.md                     # 说明文档
├── references/                   # 参考文档
│   ├── filter-rules.md          # 过滤规则详解
│   ├── api-reference.md         # 技术接口文档
│   └── output-format.md         # 输出格式说明
├── scripts/                      # 可执行脚本
│   ├── __init__.py             # 包初始化
│   ├── main.py                 # 主程序
│   ├── dedupe.py               # 去重模块
│   ├── progress.py              # 进度条
│   └── zipper.py                # ZIP 打包
├── assets/                       # 静态资源
│   └── download-form.html       # 下载表单界面
└── evals/                       # 测试用例
    └── evals.json
```

## 使用方法

### 在 LobsterAI 中使用

直接告诉我要下载图片的网址：

```
下载 https://example.com/gallery
```

### 可选参数

| 参数 | 说明 | 示例 |
|------|------|------|
| 最小尺寸 | 宽度或高度 ≥ 此值(px) | `最小 1920px` |
| 最大尺寸 | 宽度或高度 ≤ 此值(px) | `最大 4000px` |
| 增量更新 | 只下载新增图片 | `增量更新` |
| 图集检测 | 是否识别图片集 | `图集检测关闭` |

### 使用示例

```
# 基础下载
下载 https://wallhaven.cc/search?q=landscape

# 指定尺寸
下载 https://example.com/photos，最小 1920px

# 增量更新
下载 https://example.com/gallery，增量更新

# 完整参数
下载 https://example.com/gallery，最小 500px，最大 4000px，增量更新
```

## 输出

下载完成后会生成：

```
web-images/example.com/
├── JPG/
│   ├── image_001.jpg
│   └── image_002.jpg
├── PNG/
├── GIF/
├── WebP/
├── SVG/
├── Other/
├── report.json
└── example.com.zip
```

## 版本历史

- **v1.2.0** - 支持去重、图集识别、进度条、尺寸过滤、广告过滤、增量更新
- **v1.1.0** - 支持按类型分类打包 ZIP
- **v1.0.0** - 基础下载功能
