"""
ZIP 打包脚本

Usage:
    from zipper import create_zip, extract_zip

    zip_path = create_zip(
        source_dir="C:/path/to/folder/",
        output_path="C:/path/to/output.zip"
    )
"""

import os
import zipfile
from pathlib import Path


def create_zip(source_dir, output_path=None, include_report=True, compression=zipfile.ZIP_DEFLATED):
    """
    将文件夹打包为 ZIP 文件

    Args:
        source_dir: 源文件夹路径
        output_path: 输出 ZIP 路径，默认在源文件夹同目录
        include_report: 是否包含 report.json
        compression: 压缩方式

    Returns:
        ZIP 文件路径
    """
    source_path = Path(source_dir)
    if not source_path.exists():
        raise FileNotFoundError(f"源文件夹不存在: {source_dir}")

    # 生成输出路径
    if output_path is None:
        output_path = source_path.parent / f"{source_path.name}.zip"
    else:
        output_path = Path(output_path)

    # 创建 ZIP 文件
    with zipfile.ZipFile(output_path, 'w', compression=compression) as zf:
        for root, dirs, files in os.walk(source_path):
            # 跳过 ZIP 文件本身
            if root == str(source_path):
                files = [f for f in files if not f.endswith('.zip')]

            for file in files:
                # 跳过 report.json 如果不需要
                if not include_report and file == 'report.json':
                    continue

                file_path = Path(root) / file
                # 相对于源文件夹的路径
                arcname = str(file_path.relative_to(source_path))
                zf.write(file_path, arcname)

    return str(output_path)


def create_zip_with_structure(source_dir, output_path, folder_structure=None):
    """
    按指定结构打包

    Args:
        source_dir: 源文件夹
        output_path: 输出路径
        folder_structure: 文件夹结构定义
    """
    source_path = Path(source_dir)

    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for folder in folder_structure or ['JPG', 'PNG', 'GIF', 'WebP', 'SVG', 'Other']:
            folder_path = source_path / folder
            if folder_path.exists():
                for file in folder_path.glob('*'):
                    if file.is_file():
                        arcname = str(file.relative_to(source_path))
                        zf.write(file, arcname)

        # 总是包含 report
        report_path = source_path / 'report.json'
        if report_path.exists():
            zf.write(report_path, 'report.json')


def extract_zip(zip_path, output_dir=None):
    """
    解压 ZIP 文件

    Args:
        zip_path: ZIP 文件路径
        output_dir: 输出目录，默认解压到同目录

    Returns:
        解压后的文件夹路径
    """
    zip_path = Path(zip_path)
    if output_dir is None:
        output_dir = zip_path.parent / zip_path.stem
    else:
        output_dir = Path(output_dir)

    output_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(output_dir)

    return str(output_dir)


def list_zip_contents(zip_path):
    """
    列出 ZIP 文件内容

    Returns:
        文件列表
    """
    with zipfile.ZipFile(zip_path, 'r') as zf:
        return zf.namelist()


def get_zip_info(zip_path):
    """
    获取 ZIP 文件信息

    Returns:
        信息字典
    """
    with zipfile.ZipFile(zip_path, 'r') as zf:
        info = zf.infolist()
        return {
            'file_count': len(info),
            'total_size': sum(f.file_size for f in info),
            'compressed_size': sum(f.compress_size for f in info),
            'files': [f.filename for f in info]
        }


if __name__ == '__main__':
    print("ZIP 打包模块")
    print("Usage: from zipper import create_zip, extract_zip")
