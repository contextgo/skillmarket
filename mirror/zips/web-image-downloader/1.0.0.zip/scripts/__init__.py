"""
图片下载器脚本

Usage:
    python downloader.py <url> [options]
"""

import os
import sys
import json
import hashlib
import zipfile
import shutil
from pathlib import Path
from urllib.parse import urlparse, urljoin
from datetime import datetime

# 默认参数
DEFAULT_MIN_SIZE = 100
DEFAULT_CONCURRENCY = 3
DEFAULT_TIMEOUT = 30
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB


def parse_args():
    """解析命令行参数"""
    args = sys.argv[1:]
    if not args:
        print("Usage: python downloader.py <url> [options]")
        sys.exit(1)

    url = args[0]
    params = {
        'output': None,
        'min_size': DEFAULT_MIN_SIZE,
        'max_size': None,
        'gallery': True,
        'incremental': False,
        'concurrency': DEFAULT_CONCURRENCY,
        'timeout': DEFAULT_TIMEOUT
    }

    for arg in args[1:]:
        if arg.startswith('--output=') or arg.startswith('-o='):
            params['output'] = arg.split('=')[1]
        elif arg == '--no-gallery':
            params['gallery'] = False
        elif arg == '--incremental':
            params['incremental'] = True
        elif arg.startswith('--min-size='):
            params['min_size'] = int(arg.split('=')[1])
        elif arg.startswith('--max-size='):
            params['max_size'] = int(arg.split('='')[1])

    return url, params


def get_domain(url):
    """从 URL 提取域名"""
    parsed = urlparse(url)
    return parsed.netloc.replace(':', '_')


def create_output_dir(url, output_path=None):
    """创建输出目录"""
    domain = get_domain(url)
    if output_path:
        base_dir = Path(output_path)
    else:
        base_dir = Path.home() / 'Downloads' / 'web-images' / domain

    base_dir.mkdir(parents=True, exist_ok=True)

    # 创建分类子目录
    for folder in ['JPG', 'PNG', 'GIF', 'WebP', 'SVG', 'Other']:
        (base_dir / folder).mkdir(exist_ok=True)

    return str(base_dir)


def compute_md5(data):
    """计算 MD5 哈希"""
    return hashlib.md5(data).hexdigest()


def filter_ad_images(url, filename):
    """广告图片过滤"""
    ad_keywords = ['ad', 'ads', 'banner', 'promo', 'sponsor', 'advertisement', 'pop', 'sticky']
    url_lower = url.lower()
    filename_lower = filename.lower()

    for keyword in ad_keywords:
        if keyword in url_lower or keyword in filename_lower:
            return True
    return False


def resolve_image_url(base_url, image_url):
    """解析图片 URL，处理相对路径"""
    if not image_url:
        return None
    if image_url.startswith('data:'):
        return None  # 跳过 data URI
    if image_url.startswith('//'):
        return 'https:' + image_url
    if image_url.startswith('http'):
        return image_url
    return urljoin(base_url, image_url)


def get_file_extension(url):
    """从 URL 获取文件扩展名"""
    parsed = urlparse(url)
    path = parsed.path
    ext = Path(path).suffix.lower()
    return ext if ext else '.jpg'


def get_format_folder(ext):
    """根据扩展名返回分类文件夹"""
    ext_map = {
        '.jpg': 'JPG', '.jpeg': 'JPG',
        '.png': 'PNG',
        '.gif': 'GIF',
        '.webp': 'WebP',
        '.svg': 'SVG'
    }
    return ext_map.get(ext, 'Other')


def generate_filename(output_dir, folder, url, index):
    """生成文件名"""
    ext = get_file_extension(url)
    filename = f"{index:03d}{ext}"
    filepath = Path(output_dir) / folder / filename

    counter = 1
    while filepath.exists():
        filename = f"{index:03d}_{counter}{ext}"
        filepath = Path(output_dir) / folder / filename
        counter += 1

    return filename


def save_report(output_dir, report):
    """保存报告 JSON"""
    report_path = Path(output_dir) / 'report.json'
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    return str(report_path)


def create_zip_archive(output_dir, domain):
    """打包为 ZIP"""
    zip_path = Path(output_dir) / f'{domain}.zip'

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(output_dir):
            for file in files:
                if file.endswith('.zip'):
                    continue
                file_path = Path(root) / file
                arcname = str(file_path.relative_to(output_dir))
                zf.write(file_path, arcname)

    return str(zip_path)


def print_progress(current, total, message=''):
    """打印进度条"""
    percent = int(current / total * 100) if total > 0 else 0
    bar_len = 30
    filled = int(bar_len * current / total) if total > 0 else 0
    bar = '█' * filled + '░' * (bar_len - filled)

    print(f'\r📥 [{bar}] {current}/{total} ({percent}%) {message}', end='', flush=True)
    if current >= total:
        print()


def print_summary(report):
    """打印摘要"""
    stats = report['statistics']
    print(f"\n✅ 下载完成")
    print(f"   发现图片：{stats['total_found']} 个")
    print(f"   广告过滤：{stats.get('ad_filtered', 0)} 个")
    print(f"   去重过滤：{stats.get('deduplicated', 0)} 个")
    print(f"   下载成功：{stats['success']} 个")
    print(f"   下载失败：{stats['failed']} 个")
    print(f"\n📁 保存位置：{report['output_dir']}")
    print(f"📦 ZIP 包：{report['output_zip']}")


if __name__ == '__main__':
    print("此脚本需要配合 requests、beautifulsoup4 等库使用")
    print("请在 LobsterAI 环境中通过 skill 调用")
