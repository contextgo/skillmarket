"""
web-image-downloader 主脚本
整合所有模块，完成图片下载任务
"""

import os
import sys
import json
import requests
from pathlib import Path
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# 导入本地模块
from dedupe import Deduplicator
from progress import ProgressBar
from zipper import create_zip


class ImageDownloader:
    """网页图片下载器"""

    def __init__(self, url, **kwargs):
        self.url = url
        self.params = {
            'output': kwargs.get('output'),
            'min_size': kwargs.get('min_size', 100),
            'max_size': kwargs.get('max_size'),
            'gallery': kwargs.get('gallery', True),
            'incremental': kwargs.get('incremental', False),
            'concurrency': kwargs.get('concurrency', 3),
            'timeout': kwargs.get('timeout', 30)
        }

        self.domain = urlparse(url).netloc.replace(':', '_')
        self.output_dir = self._get_output_dir()
        self.deduplicator = Deduplicator()
        self.images = []
        self.report = {
            'version': '1.2.0',
            'source_url': url,
            'download_time': time.strftime('%Y-%m-%dT%H:%M:%S+08:00'),
            'output_dir': self.output_dir,
            'output_zip': '',
            'parameters': self.params,
            'statistics': {
                'total_found': 0,
                'ad_filtered': 0,
                'size_filtered': 0,
                'deduplicated': 0,
                'success': 0,
                'failed': 0
            },
            'by_type': {},
            'files': []
        }

    def _get_output_dir(self):
        """获取输出目录"""
        if self.params['output']:
            base = Path(self.params['output'])
        else:
            base = Path.home() / 'Downloads' / 'web-images' / self.domain

        base.mkdir(parents=True, exist_ok=True)

        # 创建分类文件夹
        for folder in ['JPG', 'PNG', 'GIF', 'WebP', 'SVG', 'Other']:
            (base / folder).mkdir(exist_ok=True)

        return str(base)

    def fetch_page(self):
        """获取网页内容"""
        try:
            resp = requests.get(self.url, timeout=self.params['timeout'])
            resp.raise_for_status()
            return resp.text
        except Exception as e:
            print(f"获取页面失败: {e}")
            return None

    def parse_images(self, html):
        """解析网页中的图片"""
        soup = BeautifulSoup(html, 'html.parser')
        image_urls = set()

        # 1. 标准 img 标签
        for img in soup.find_all('img'):
            src = img.get('src') or img.get('data-src') or img.get('data-lazy-src')
            if src:
                image_urls.add(self.resolve_url(src))

            # srcset
            srcset = img.get('srcset')
            if srcset:
                for item in srcset.split(','):
                    url = item.strip().split()[0]
                    image_urls.add(self.resolve_url(url))

        # 2. picture 元素
        for pic in soup.find_all('picture'):
            for source in pic.find_all('source'):
                srcset = source.get('srcset')
                if srcset:
                    for item in srcset.split(','):
                        url = item.strip().split()[0]
                        image_urls.add(self.resolve_url(url))

        # 3. CSS 背景图
        import re
        style_pattern = re.compile(r'background-image:\s*url\(["\']?([^"\')]+)["\']?\)')
        for elem in soup.find_all(style=True):
            matches = style_pattern.findall(elem['style'])
            for url in matches:
                image_urls.add(self.resolve_url(url))

        # 4. a 标签（画廊链接）
        if self.params['gallery']:
            for a in soup.find_all('a', href=True):
                href = a['href']
                if any(ext in href.lower() for ext in ['.jpg', '.png', '.gif', '.webp']):
                    image_urls.add(self.resolve_url(href))

        self.images = list(image_urls)
        self.report['statistics']['total_found'] = len(self.images)
        return self.images

    def resolve_url(self, url):
        """解析为完整 URL"""
        if not url or url.startswith('data:'):
            return None
        if url.startswith('//'):
            return 'https:' + url
        if url.startswith('http'):
            return url
        return urljoin(self.url, url)

    def filter_ad_images(self):
        """过滤广告图片"""
        ad_keywords = ['ad', 'ads', 'banner', 'promo', 'sponsor', 'advertisement', 'pop', 'sticky']
        filtered = []

        for img_url in self.images:
            parsed = urlparse(img_url)
            path = parsed.path.lower()
            filename = Path(parsed.path).name.lower()

            is_ad = any(kw in path or kw in filename for kw in ad_keywords)

            if is_ad:
                self.report['statistics']['ad_filtered'] += 1
            else:
                filtered.append(img_url)

        self.images = filtered

    def download_image(self, img_url, index):
        """下载单个图片"""
        try:
            resp = requests.get(img_url, timeout=self.params['timeout'], stream=True)
            resp.raise_for_status()

            content = resp.content
            content_length = len(content)

            # 检查文件大小
            if content_length > 50 * 1024 * 1024:  # 50MB
                return {'status': 'skipped', 'reason': 'file_too_large', 'url': img_url}

            # 计算 MD5
            md5_hash = self.deduplicator.compute_md5_from_bytes(content)

            # 去重检查
            if self.deduplicator.is_duplicate(md5_hash):
                self.report['statistics']['deduplicated'] += 1
                return {'status': 'duplicated', 'url': img_url, 'md5': md5_hash}

            self.deduplicator.add_to_seen(md5_hash)

            # 确定格式和保存路径
            ext = self._get_ext(img_url, content)
            folder = self._get_folder(ext)
            filename = self._get_filename(folder, index, ext)
            filepath = Path(self.output_dir) / folder / filename

            # 保存文件
            with open(filepath, 'wb') as f:
                f.write(content)

            # 获取尺寸
            dimensions = self._get_dimensions(content, ext)

            # 检查尺寸过滤
            min_size = self.params['min_size']
            max_size = self.params['max_size']
            if dimensions:
                w, h = dimensions
                if w < min_size and h < min_size:
                    filepath.unlink()
                    self.report['statistics']['size_filtered'] += 1
                    return {'status': 'filtered', 'reason': 'too_small', 'url': img_url}
                if max_size and w > max_size and h > max_size:
                    filepath.unlink()
                    self.report['statistics']['size_filtered'] += 1
                    return {'status': 'filtered', 'reason': 'too_large', 'url': img_url}

            # 更新统计
            folder_stats = self.report['by_type'].get(folder, {'found': 0, 'success': 0, 'failed': 0})
            folder_stats['found'] += 1
            folder_stats['success'] += 1
            self.report['by_type'][folder] = folder_stats

            self.report['statistics']['success'] += 1

            return {
                'status': 'success',
                'url': img_url,
                'filename': filename,
                'folder': folder,
                'dimensions': dimensions,
                'size': content_length
            }

        except Exception as e:
            self.report['statistics']['failed'] += 1
            return {'status': 'failed', 'url': img_url, 'error': str(e)}

    def _get_ext(self, url, content=None):
        """获取文件扩展名"""
        parsed = urlparse(url)
        ext = Path(parsed.path).suffix.lower()
        if ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp']:
            return ext
        # 尝试从内容检测
        if content:
            if content[:3] == b'\xff\xd8\xff':
                return '.jpg'
            if content[:4] == b'\x89PNG':
                return '.png'
            if content[:4] == b'GIF8':
                return '.gif'
        return '.jpg'

    def _get_folder(self, ext):
        """获取分类文件夹"""
        mapping = {
            '.jpg': 'JPG', '.jpeg': 'JPG',
            '.png': 'PNG',
            '.gif': 'GIF',
            '.webp': 'WebP',
            '.svg': 'SVG'
        }
        return mapping.get(ext, 'Other')

    def _get_filename(self, folder, index, ext):
        """生成文件名"""
        filename = f"{index:03d}{ext}"
        filepath = Path(self.output_dir) / folder / filename
        counter = 1
        while filepath.exists():
            filename = f"{index:03d}_{counter}{ext}"
            filepath = Path(self.output_dir) / folder / filename
            counter += 1
        return filename

    def _get_dimensions(self, content, ext):
        """获取图片尺寸"""
        try:
            if ext in ['.jpg', '.jpeg', '.png', '.gif']:
                from PIL import Image
                from io import BytesIO
                img = Image.open(BytesIO(content))
                return img.size
        except Exception:
            pass
        return None

    def run(self):
        """执行下载"""
        print(f"\n📥 开始下载: {self.url}")

        # 1. 获取页面
        print("📌 步骤 1/5: 获取网页内容...")
        html = self.fetch_page()
        if not html:
            print("❌ 获取页面失败")
            return None

        # 2. 解析图片
        print("📌 步骤 2/5: 解析图片链接...")
        self.parse_images(html)
        print(f"   发现 {len(self.images)} 个图片")

        # 3. 过滤广告
        print("📌 步骤 3/5: 过滤广告图片...")
        self.filter_ad_images()
        print(f"   过滤 {self.report['statistics']['ad_filtered']} 个广告图")

        # 4. 下载图片
        print("📌 步骤 4/5: 下载图片...")
        pb = ProgressBar(total=len(self.images), description="下载")

        for i, img_url in enumerate(self.images, 1):
            result = self.download_image(img_url, i)
            pb.update(current=i, message=img_url.split('/')[-1][:30])

        pb.close()

        # 5. 打包
        print("📌 步骤 5/5: 打包 ZIP...")
        zip_path = create_zip(self.output_dir)
        self.report['output_zip'] = zip_path

        # 保存报告
        report_path = Path(self.output_dir) / 'report.json'
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(self.report, f, indent=2, ensure_ascii=False)

        self.print_summary()
        return self.report

    def print_summary(self):
        """打印摘要"""
        stats = self.report['statistics']
        print(f"\n✅ 下载完成")
        print(f"   发现图片：{stats['total_found']} 个")
        print(f"   广告过滤：{stats['ad_filtered']} 个")
        print(f"   去重过滤：{stats['deduplicated']} 个")
        print(f"   尺寸过滤：{stats['size_filtered']} 个")
        print(f"   下载成功：{stats['success']} 个")
        print(f"   下载失败：{stats['failed']} 个")
        print(f"\n📁 保存位置：{self.output_dir}")
        print(f"📦 ZIP 包：{self.report['output_zip']}")


def main():
    """命令行入口"""
    if len(sys.argv) < 2:
        print("Usage: python main.py <url> [options]")
        print("Options:")
        print("  --output=<path>     输出目录")
        print("  --min-size=<px>     最小尺寸")
        print("  --max-size=<px>     最大尺寸")
        print("  --no-gallery        关闭图集识别")
        print("  --incremental       增量更新")
        sys.exit(1)

    url = sys.argv[1]
    kwargs = {}

    for arg in sys.argv[2:]:
        if arg.startswith('--output='):
            kwargs['output'] = arg.split('=')[1]
        elif arg.startswith('--min-size='):
            kwargs['min_size'] = int(arg.split('=')[1])
        elif arg.startswith('--max-size='):
            kwargs['max_size'] = int(arg.split('=')[1])
        elif arg == '--no-gallery':
            kwargs['gallery'] = False
        elif arg == '--incremental':
            kwargs['incremental'] = True

    downloader = ImageDownloader(url, **kwargs)
    downloader.run()


if __name__ == '__main__':
    main()
