"""
去重脚本 - MD5 和感知哈希

Usage:
    from dedupe import Deduplicator

    d = Deduplicator()
    md5 = d.compute_md5(file_path)
    if d.is_duplicate(md5):
        print("重复文件")
    d.add_to_seen(md5)
"""

import os
import hashlib
from pathlib import Path


class Deduplicator:
    """MD5 去重器"""

    def __init__(self, known_hashes=None):
        self.seen_hashes = known_hashes or set()

    def compute_md5(self, file_path):
        """计算文件的 MD5 哈希"""
        hash_md5 = hashlib.md5()
        try:
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_md5.update(chunk)
            return hash_md5.hexdigest()
        except Exception:
            return None

    def compute_md5_from_bytes(self, data):
        """从字节数据计算 MD5"""
        return hashlib.md5(data).hexdigest()

    def is_duplicate(self, md5_hash):
        """检查是否是重复文件"""
        if md5_hash is None:
            return True
        return md5_hash in self.seen_hashes

    def add_to_seen(self, md5_hash):
        """添加到已见集合"""
        if md5_hash:
            self.seen_hashes.add(md5_hash)

    def get_seen_count(self):
        """获取已见文件数量"""
        return len(self.seen_hashes)

    def export_hashes(self):
        """导出哈希集合"""
        return list(self.seen_hashes)

    def import_hashes(self, hashes):
        """导入哈希集合"""
        self.seen_hashes = set(hashes)


def perceptual_hash_simple(image_path):
    """
    简化版感知哈希
    基于图片内容生成感知指纹
    """
    try:
        from PIL import Image
        import numpy as np

        # 缩小到 8x8
        img = Image.open(image_path).convert('L')
        img = img.resize((8, 8), Image.Resampling.LANCZOS)

        # 转换为数组
        pixels = np.array(img)

        # 计算平均灰度
        avg = pixels.mean()

        # 生成 64 位哈希
        bits = ''.join(['1' if pixel > avg else '0' for pixel in pixels.flatten()])

        # 转换为十六进制
        return hex(int(bits, 2))[2:]

    except ImportError:
        print("Pillow 未安装，使用简单 MD5 替代")
        return hashlib.md5(open(image_path, 'rb').read()).hexdigest()
    except Exception:
        return None


def hamming_distance(hash1, hash2):
    """计算两个哈希的海明距离"""
    if hash1 is None or hash2 is None:
        return float('inf')

    h1 = int(hash1, 16) if isinstance(hash1, str) else hash1
    h2 = int(hash2, 16) if isinstance(hash2, str) else hash2

    return bin(h1 ^ h2).count('1')


def is_similar(hash1, hash2, threshold=10):
    """判断两个哈希是否相似（海明距离 < threshold）"""
    return hamming_distance(hash1, hash2) < threshold


if __name__ == '__main__':
    print("去重模块")
    print("Usage: from dedupe import Deduplicator")
