"""
进度条脚本

Usage:
    from progress import ProgressBar

    pb = ProgressBar(total=30, description="下载图片")
    pb.update(current=12, message="image_007.jpg (1.2MB)")
    pb.close()
"""

import sys
import time


class ProgressBar:
    """简单的进度条显示"""

    def __init__(self, total, description="进度"):
        self.total = total
        self.current = 0
        self.description = description
        self.start_time = time.time()
        self.last_update = 0

    def update(self, current=None, message=''):
        """更新进度"""
        if current is not None:
            self.current = current

        # 限制更新频率（每秒最多一次）
        now = time.time()
        if now - self.last_update < 0.1 and self.current < self.total:
            return
        self.last_update = now

        # 计算百分比
        percent = int(self.current / self.total * 100) if self.total > 0 else 0

        # 进度条
        bar_len = 30
        filled = int(bar_len * self.current / self.total) if self.total > 0 else 0
        bar = '█' * filled + '░' * (bar_len - filled)

        # 预计剩余时间
        elapsed = time.time() - self.start_time
        if self.current > 0:
            eta = elapsed / self.current * (self.total - self.current)
            eta_str = f"预计剩余: {int(eta)}秒"
        else:
            eta_str = ""

        # 打印
        line = f'\r📥 {self.description} [{bar}] {self.current}/{self.total} ({percent}%) {message} {eta_str}'
        print(line[:self._terminal_width()], end='', flush=True)

        if self.current >= self.total:
            print()

    def close(self):
        """关闭进度条"""
        self.current = self.total
        elapsed = time.time() - self.start_time
        print(f'\n✅ 完成！耗时: {elapsed:.1f}秒')

    def _terminal_width(self):
        """获取终端宽度"""
        try:
            return shutil.get_terminal_size().columns
        except Exception:
            return 80


class MultiProgressBar:
    """多任务进度条"""

    def __init__(self, tasks):
        """
        tasks: dict, {task_name: total}
        """
        self.tasks = {name: {'total': total, 'current': 0} for name, total in tasks.items()}
        self.start_time = time.time()

    def update(self, task_name, current=None, message=''):
        """更新指定任务进度"""
        if task_name not in self.tasks:
            return

        if current is not None:
            self.tasks[task_name]['current'] = current

        # 构建显示行
        lines = []
        lines.append(f"📥 下载中...")
        lines.append("━" * 40)

        for name, task in self.tasks.items():
            total = task['total']
            current = task['current']
            percent = int(current / total * 100) if total > 0 else 0
            bar_len = 15
            filled = int(bar_len * current / total) if total > 0 else 0
            bar = '█' * filled + '░' * (bar_len - filled)
            lines.append(f"[{bar}] {name}: {current}/{total} ({percent}%)")

        lines.append("━" * 40)

        # 打印
        print('\n'.join(lines), end='', flush=True)
        # 光标上移
        print(f'\033[{len(lines)}A', end='')


def print_step(step, total, message):
    """打印步骤进度（简易版）"""
    print(f"\n📌 步骤 {step}/{total}: {message}")


def print_spinner(message):
    """打印旋转动画"""
    chars = '⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    for char in chars:
        print(f'\r{char} {message}', end='', flush=True)
        time.sleep(0.1)


if __name__ == '__main__':
    # 测试进度条
    pb = ProgressBar(total=30, description="测试下载")

    for i in range(1, 31):
        pb.update(current=i, message=f"image_{i:03d}.jpg")
        time.sleep(0.1)

    pb.close()
