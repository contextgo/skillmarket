# 输出格式说明

## 目录结构

```
web-images/
└── [域名]/
    ├── JPG/
    │   ├── image_001.jpg
    │   └── image_002.jpg
    ├── PNG/
    │   └── image_003.png
    ├── GIF/
    │   └── animation.gif
    ├── WebP/
    │   └── modern.webp
    ├── SVG/
    │   └── vector.svg
    ├── Other/
    │   └── icon.bmp
    ├── report.json
    └── [域名].zip
```

## 文件夹分类规则

| 格式 | 文件夹 | 扩展名 |
|------|--------|--------|
| JPEG | JPG/ | .jpg, .jpeg |
| PNG | PNG/ | .png |
| GIF | GIF/ | .gif |
| WebP | WebP/ | .webp |
| SVG | SVG/ | .svg |
| 其他 | Other/ | .bmp, .ico, .tiff, .tif |

## 文件命名规则

### 自动命名

```
{序号}_{原文件名或URL哈希}.{扩展名}
```

示例：
- `001_a1b2c3d4.jpg`
- `002_wallhaven_xyz789.png`

### 重名处理

如果文件名已存在，自动添加序号：

```
image_001.jpg
image_002.jpg
image_003.jpg
```

## report.json 格式

```json
{
  "version": "1.2.0",
  "source_url": "https://example.com",
  "download_time": "2026-04-24T15:13:00+08:00",
  "output_dir": "C:/Users/Administrator/Downloads/web-images/example.com/",
  "output_zip": "C:/Users/Administrator/Downloads/web-images/example.com.zip",

  "parameters": {
    "min_size": 100,
    "max_size": null,
    "gallery_detection": true,
    "incremental_update": false
  },

  "statistics": {
    "total_found": 35,
    "ad_filtered": 6,
    "size_filtered": 2,
    "deduplicated": 5,
    "success": 22,
    "skipped": 0,
    "failed": 0
  },

  "by_type": {
    "JPG": { "found": 15, "success": 14, "failed": 1 },
    "PNG": { "found": 10, "success": 8, "failed": 0 },
    "GIF": { "found": 5, "success": 5, "failed": 0 },
    "WebP": { "found": 3, "success": 3, "failed": 0 },
    "SVG": { "found": 2, "success": 2, "failed": 0 }
  },

  "deduplication": {
    "total_found": 35,
    "unique": 30,
    "duplicates": 5
  },

  "ad_filtering": {
    "blocked_by_name": 3,
    "blocked_by_path": 2,
    "blocked_by_ratio": 1,
    "total_blocked": 6
  },

  "galleries": [
    {
      "name": "album-1",
      "url": "https://example.com/gallery/album-1/",
      "images_count": 12
    }
  ],

  "files": [
    {
      "index": 1,
      "name": "image_001.jpg",
      "url": "https://cdn.example.com/image.jpg",
      "type": "JPG",
      "size_bytes": 1234567,
      "dimensions": {"width": 1920, "height": 1080},
      "status": "success",
      "local_path": "C:/Users/.../JPG/image_001.jpg"
    }
  ],

  "errors": [
    {
      "index": 15,
      "url": "https://example.com/broken.jpg",
      "error": "404 Not Found",
      "status": "failed"
    }
  ]
}
```

## 进度条输出格式

```
📥 正在下载: example.com
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[████████████░░░░░░░░░░░░░] 12/30 (40%)
正在下载: image_007.jpg (1.2MB)
预计剩余: 15秒
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### 进度更新频率

- 每秒更新不超过 1 次
- 显示当前文件和已下载大小
- 显示预计剩余时间

## ZIP 文件结构

```
example.com.zip
├── JPG/
│   ├── image_001.jpg
│   └── image_002.jpg
├── PNG/
├── GIF/
├── WebP/
├── SVG/
├── Other/
└── report.json
```

## 最终报告（用户可见）

```markdown
# 📥 下载完成

## 来源
URL: https://example.com

## 统计
- 发现图片：35 个
- 广告过滤：6 个
- 去重过滤：5 个
- 尺寸过滤：2 个
- 下载成功：22 个
- 下载失败：0 个

## 分类统计
| 格式 | 数量 | 成功 |
|------|------|------|
| JPG | 14 | ✅ |
| PNG | 8 | ✅ |
| GIF | 5 | ✅ |
| WebP | 3 | ✅ |
| SVG | 2 | ✅ |

## 输出位置
- 文件夹：`C:/Users/Administrator/Downloads/web-images/example.com/`
- ZIP 包：`C:/Users/Administrator/Downloads/web-images/example.com.zip`
```

## 错误报告格式

```json
{
  "errors": [
    {
      "url": "https://example.com/image.jpg",
      "error": "Connection timeout",
      "status": "failed",
      "retries": 3
    }
  ]
}
```
