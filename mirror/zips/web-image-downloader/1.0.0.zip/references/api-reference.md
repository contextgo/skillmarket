# 技术接口文档

## 脚本概览

| 脚本 | 功能 | 依赖 |
|------|------|------|
| `downloader.py` | 主下载脚本，协调其他模块 | requests, beautifulsoup4, Pillow |
| `dedupe.py` | MD5 去重和感知哈希 | hashlib, imagehash |
| `progress.py` | 进度条显示 | tqdm |
| `zipper.py` | ZIP 打包 | zipfile, shutil |

## 主下载脚本

### 命令行接口

```bash
python downloader.py <url> [options]
```

### 参数

| 参数 | 类型 | 说明 | 默认值 |
|------|------|------|--------|
| `url` | str | 目标网页 URL（必填） | - |
| `--output`, `-o` | str | 输出目录 | `~/Downloads/web-images/[域名]/` |
| `--min-size` | int | 最小图片尺寸(px) | 100 |
| `--max-size` | int | 最大图片尺寸(px) | 无限制 |
| `--no-gallery` | flag | 关闭图集识别 | 开启 |
| `--incremental` | flag | 启用增量更新 | 关闭 |
| `--concurrency` | int | 并发下载数 | 3 |
| `--timeout` | int | 单个下载超时(秒) | 30 |

### 返回值

```python
{
    "success": True,
    "output_zip": "C:/Users/.../example.com.zip",
    "statistics": { ... },
    "files": [ ... ]
}
```

## 去重脚本

### 函数接口

```python
from dedupe import Deduplicator

d = Deduplicator()
md5_hash = d.compute_md5(file_path)
is_duplicate = d.is_duplicate(md5_hash)
d.add_to_seen(md5_hash)
```

### 感知哈希

```python
from dedupe import perceptual_hash

hash1 = perceptual_hash(image_path)
hash2 = perceptual_hash(image_path2)
similarity = hash1.similarities(hash2)
is_same = similarity > 0.9
```

## 进度条脚本

### 基本用法

```python
from progress import ProgressBar

pb = ProgressBar(total=30, description="下载图片")
pb.update(current=12, message="image_007.jpg (1.2MB)")
pb.close()
```

### 输出格式

```
📥 正在下载: example.com
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[████████████░░░░░░░░░░░░░] 12/30 (40%)
正在下载: image_007.jpg (1.2MB)
预计剩余: 15秒
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## ZIP 打包脚本

### 函数接口

```python
from zipper import create_zip

zip_path = create_zip(
    source_dir="C:/Users/.../example.com/",
    output_path="C:/Users/.../example.com.zip",
    include_report=True
)
```

### ZIP 结构

```
example.com.zip
├── JPG/
│   ├── image_001.jpg
│   └── image_002.jpg
├── PNG/
├── GIF/
├── WebP/
├── SVG/
├── Other/
└── report.json
```

## 图片解析

### 支持的 HTML 模式

```html
<!-- 标准 img -->
<img src="https://example.com/image.jpg">

<!-- srcset -->
<img srcset="small.jpg 480w, large.jpg 1080w">

<!-- 懒加载 -->
<img data-src="https://example.com/lazy.jpg">
<img data-lazy-src="https://example.com/lazy.jpg">
<img loading="lazy" src="...">

<!-- picture 元素 -->
<picture>
    <source srcset="image.webp" type="image/webp">
    <source srcset="image.jpg" type="image/jpeg">
    <img src="image.jpg">
</picture>

<!-- CSS 背景图 -->
<div style="background-image: url('image.jpg')">

<!-- figure 元素 -->
<figure>
    <img src="image.jpg">
    <figcaption>Caption</figcaption>
</figure>
```

### URL 解析规则

```python
def resolve_url(base_url, image_url):
    """将相对 URL 转换为绝对 URL"""
    if image_url.startswith('http'):
        return image_url
    elif image_url.startswith('//'):
        return 'https:' + image_url
    elif image_url.startswith('/'):
        # 相对根路径
        parsed = urlparse(base_url)
        return f"{parsed.scheme}://{parsed.netloc}{image_url}"
    else:
        # 相对路径
        return urljoin(base_url, image_url)
```

## 下载参数

| 参数 | 值 | 说明 |
|------|-----|------|
| 最大并发 | 3 | 避免对服务器压力过大 |
| 连接超时 | 10 秒 | 建立连接超时 |
| 读取超时 | 30 秒 | 读取数据超时 |
| 最大重试 | 3 次 | 失败后自动重试 |
| 最大文件大小 | 50 MB | 超过则跳过 |
| User-Agent | 随机桌面浏览器 | 模拟浏览器请求 |

## 错误处理

| 错误类型 | 处理方式 | 报告字段 |
|----------|----------|----------|
| 连接超时 | 重试 3 次 | `"failed"` |
| 404 错误 | 跳过 | `"failed"` |
| 文件过大 | 跳过 | `"skipped"` |
| 解析失败 | 跳过该 URL | `"failed"` |
| 磁盘空间不足 | 停止下载 | `"error"` |
| 网络中断 | 暂停后重试 | `"retry"` |
