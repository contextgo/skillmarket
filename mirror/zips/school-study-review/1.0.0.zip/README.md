# 📚 School Study — 学习辅助错题管理 Skill

> 一个面向初中和高中学生的 AI 智能错题管理系统，兼容 Claude Code skill 格式。

## ✨ 功能特性

| 功能 | 说明 |
|------|------|
| 🖼️ 图片识别解题 | 拍照上传不会做的题目，AI 自动识别并详细解答；自动筛选非学科图片 |
| 📐 图形智能重绘 | 自动识别题目中的几何图形、函数图像等，用 SVG 精确重绘，打印清晰 |
| 🧠 知识点提取 | 自动提取关键知识点，配有简明说明 |
| 📂 智能归档 | 按学科自动分类，Markdown + JSON 双格式存储 |
| 🔍 相似错题检测 | 归档前自动检索同知识点错题，提醒复习薄弱环节 |
| 📄 PDF 导出 | 按学科/时间/知识点导出格式化 PDF，方便打印 |
| 📖 复习模式 | 按条件筛选错题，支持先看题后看答案的复习方式 |

## 📦 安装方式

### 方式一：作为 Claude Code 个人 Skill

```bash
# 将 skill 目录复制到 Claude Code skills 目录
cp -r school-study-skill ~/.claude/skills/school-study
```

### 方式二：作为项目级 Skill

```bash
# 将 skill 目录复制到项目的 .claude 目录下
cp -r school-study-skill .claude/skills/school-study
```

### 方式三：作为 CodeBuddy Skill

```bash
# 将 skill 目录复制到 CodeBuddy skills 目录
cp -r school-study-skill ~/.codebuddy/skills/school-study
```

## 🚀 快速开始

### 1. 初始化错题库

首次使用时，需要初始化错题库：

```
/school-study 初始化错题库
```

或指定自定义路径：

```
/school-study 初始化错题库到 ~/Documents/我的错题库
```

### 2. 上传错题

将不会做的题目拍照上传：

```
/school-study <图片路径>
```

AI 会自动：
1. 预筛选图片内容（仅处理学科题目，非学科图片会友好拒绝）
2. 识别题目内容（含文字、图形、标注等）
3. 若题目包含图形，自动用 SVG 重绘为清晰的矢量图形
4. 详细解答并标注知识点
5. 检测是否有相似历史错题
6. 归档到对应学科文件夹（原图 + 重绘图形 + Markdown + 索引）

### 3. 复习错题

```
/school-study 复习数学错题
/school-study 复习"二次函数"相关错题
/school-study 查看最近一周的错题
```

### 4. 导出 PDF

```
/school-study 导出数学错题PDF
/school-study 导出所有错题PDF
/school-study 导出本月物理错题PDF
```

## 📁 Skill 文件结构

```
school-study-skill/
├── SKILL.md                              # 核心指令文件（必需）
├── README.md                             # 本说明文件
├── assets/
│   └── templates/
│       └── question_template.md          # 错题 Markdown 格式模板
├── references/
│   └── index_schema.json                 # 索引文件数据结构定义
├── scripts/
│   ├── init_archive.py                   # 错题库初始化脚本
│   ├── search_similar.py                 # 相似错题检索脚本
│   └── export_pdf.py                     # PDF 导出脚本
└── examples/
    └── sample_question.md                # 错题示例文件
```

## 📁 错题库结构

初始化后的错题库目录结构：

```
~/错题库/
├── 数学/
│   ├── images/                # 原始题目图片
│   ├── figures/               # AI 重绘的清晰图形（SVG/PNG）
│   ├── 数学_错题001.md        # 错题详细记录
│   └── ...
├── 物理/
│   ├── images/
│   ├── figures/
│   └── ...
├── <其他学科>/
│   └── ...
├── index.json                 # 全局索引（自动维护，请勿手动修改）
├── config.json                # 用户配置
├── exports/                   # PDF 导出目录
└── README.md                  # 使用说明
```

## 🔧 PDF 导出依赖

PDF 导出功能需要安装 Python 库：

```bash
# 推荐方案（效果最佳）
pip install markdown weasyprint

# 备选方案
pip install markdown pdfkit
# pdfkit 还需要安装 wkhtmltopdf: brew install wkhtmltopdf
```

如果未安装以上依赖，导出脚本会自动降级为生成 HTML 文件，可通过浏览器打开并打印为 PDF。

## 📝 自定义配置

错题库中的 `config.json` 支持以下配置项：

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `similarity_threshold` | 相似题匹配阈值（0-100） | 25.0 |
| `max_similar_results` | 最多展示相似题数量 | 5 |
| `pdf_export.page_size` | PDF 页面大小 | A4 |
| `pdf_export.include_images` | PDF 中是否包含图片和重绘图形 | true |
| `pdf_export.include_personal_notes` | 是否导出个人笔记区域 | false |

## 🤝 兼容性

- ✅ Claude Code Skills
- ✅ CodeBuddy Skills
- ✅ OpenClaw / AI Agent（通过加载 SKILL.md）
- ✅ 任何支持 Markdown-based skill 格式的 AI 工具

## 📜 许可证

MIT License — 自由使用、修改和分发。
