#!/usr/bin/env python3
"""
错题库初始化脚本

创建标准的错题库目录结构和初始配置文件。

用法:
  python3 init_archive.py --path <目标路径>

默认路径: ~/错题库/
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path


DEFAULT_PATH = os.path.expanduser("~/错题库")

INITIAL_INDEX = {
    "version": "1.0.0",
    "last_updated": None,  # 会被填充
    "total_count": 0,
    "subjects": {},
    "questions": []
}

INITIAL_CONFIG = {
    "version": "1.0.0",
    "created_at": None,  # 会被填充
    "settings": {
        "default_difficulty": "中等",
        "auto_detect_subject": True,
        "similarity_threshold": 25.0,
        "max_similar_results": 5,
        "pdf_export": {
            "page_size": "A4",
            "font_family": "PingFang SC, Microsoft YaHei, sans-serif",
            "include_images": True,
            "include_personal_notes": False
        }
    },
    "subjects_alias": {
        "数学": ["math", "数学"],
        "语文": ["chinese", "语文"],
        "英语": ["english", "英语"],
        "物理": ["physics", "物理"],
        "化学": ["chemistry", "化学"],
        "生物": ["biology", "生物"],
        "历史": ["history", "历史"],
        "地理": ["geography", "地理"],
        "政治": ["politics", "政治", "道德与法治", "思想品德"],
        "信息技术": ["it", "信息技术", "计算机"]
    },
    "statistics": {
        "total_questions": 0,
        "total_reviews": 0,
        "subjects_count": {}
    }
}

# 欢迎 README 文件
WELCOME_README = """# 📚 我的错题库

欢迎使用**学习辅助错题管理系统**！

## 目录结构

```
错题库/
├── <学科>/              # 按学科自动分类
│   ├── images/          # 原始题目图片
│   ├── figures/         # AI 重绘的清晰图形（SVG/PNG）
│   └── <学科>_错题XXX.md # 错题 Markdown 文件
├── exports/             # PDF 导出目录
├── index.json           # 全局索引文件（请勿手动修改）
├── config.json          # 配置文件
└── README.md            # 本文件
```

## 使用方式

### 1. 上传错题
拍照上传不会做的题目图片，AI 会自动：
- 识别并解答题目
- 提取关键知识点
- 按学科归档存储
- 检测相似错题并提醒复习

### 2. 复习错题
告诉 AI 你想复习哪个学科或知识点的错题。

### 3. 导出 PDF
请求 AI 将错题导出为 PDF 文件，方便打印。

## 注意事项
- `index.json` 是自动维护的索引文件，请勿手动修改
- 每道错题都有独立的 Markdown 文件，可以手动添加笔记
- 图片存储在各学科的 `images/` 目录下
- 重绘的清晰图形存储在各学科的 `figures/` 目录下（SVG格式，打印友好）

---
*由学习辅助错题管理系统自动生成*
"""


def init_archive(target_path: str) -> bool:
    """
    初始化错题库目录结构

    参数:
        target_path: 目标路径

    返回:
        True 表示成功
    """
    target = Path(target_path)
    now = datetime.now().isoformat()

    # 检查是否已存在
    if target.exists():
        index_file = target / "index.json"
        if index_file.exists():
            print(f"⚠️ 错题库已存在于: {target_path}")
            print(f"   如需重新初始化，请先手动删除或备份该目录。")
            return False
        else:
            print(f"📂 目录已存在，将在其中创建错题库结构...")

    # 创建主目录
    target.mkdir(parents=True, exist_ok=True)

    # 创建导出目录
    (target / "exports").mkdir(exist_ok=True)

    # 创建 index.json
    index_data = INITIAL_INDEX.copy()
    index_data["last_updated"] = now
    with open(target / "index.json", 'w', encoding='utf-8') as f:
        json.dump(index_data, f, ensure_ascii=False, indent=2)

    # 创建 config.json
    config_data = INITIAL_CONFIG.copy()
    config_data["created_at"] = now
    with open(target / "config.json", 'w', encoding='utf-8') as f:
        json.dump(config_data, f, ensure_ascii=False, indent=2)

    # 创建 README.md
    with open(target / "README.md", 'w', encoding='utf-8') as f:
        f.write(WELCOME_README)

    # 创建 .gitkeep 文件保持空目录结构
    (target / "exports" / ".gitkeep").touch()

    print(f"✅ 错题库初始化成功！")
    print(f"📁 位置: {target_path}")
    print(f"")
    print(f"已创建的文件:")
    print(f"  📄 index.json   — 错题索引文件")
    print(f"  📄 config.json  — 配置文件")
    print(f"  📄 README.md    — 使用说明")
    print(f"  📂 exports/     — PDF 导出目录")
    print(f"")
    print(f"📝 开始使用：上传一张题目图片，AI 会自动解答并归档。")
    print(f"   学科文件夹将在首次添加错题时自动创建，")
    print(f"   每个学科文件夹下会自动创建 images/（原始图片）和 figures/（重绘图形）目录。")

    return True


def main():
    parser = argparse.ArgumentParser(
        description="初始化错题库目录结构",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 在默认路径初始化
  python3 init_archive.py

  # 指定自定义路径
  python3 init_archive.py --path ~/Documents/我的错题库

  # 指定学生名称
  python3 init_archive.py --path ~/错题库 --student "张三"
        """
    )
    parser.add_argument('--path', default=DEFAULT_PATH,
                        help=f'错题库目标路径 (默认: {DEFAULT_PATH})')
    parser.add_argument('--student', default=None,
                        help='学生名称（可选，用于个性化显示）')

    args = parser.parse_args()

    # 展开 ~ 路径
    target_path = os.path.expanduser(args.path)

    print(f"📚 学习辅助错题管理系统 — 初始化")
    print(f"{'=' * 45}")
    print(f"目标路径: {target_path}")
    if args.student:
        print(f"学生: {args.student}")
    print()

    success = init_archive(target_path)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
