#!/usr/bin/env python3
"""
相似错题检索脚本

在已有的错题索引中搜索与当前题目知识点相似的历史错题。
匹配策略：
  1. 知识点名称精确匹配（权重最高）
  2. 知识点名称子串匹配（部分匹配）
  3. 同学科 + 题目文字关键词匹配（辅助匹配）

用法：
  python3 search_similar.py \
    --index <index.json路径> \
    --subject <学科> \
    --knowledge-points <知识点1>,<知识点2>,... \
    --question-text <题目文字摘要>

输出：
  JSON 格式的匹配结果列表，按相似度降序排列。
  如果没有找到相似错题，输出空列表 []。
"""

import argparse
import json
import sys
import os
import re
from typing import List, Dict, Any


def normalize_text(text: str) -> str:
    """标准化文本，去除多余空白和标点"""
    text = re.sub(r'\s+', '', text)
    text = text.lower()
    return text


def extract_keywords(text: str, min_length: int = 2) -> set:
    """从文本中提取关键词"""
    # 移除标点和特殊字符
    cleaned = re.sub(r'[^\w\u4e00-\u9fff]', ' ', text)
    # 按空白分割
    words = cleaned.split()
    # 过滤太短的词
    keywords = set()
    for w in words:
        if len(w) >= min_length:
            keywords.add(w.lower())
    # 对中文文本，也提取连续的中文短语
    chinese_phrases = re.findall(r'[\u4e00-\u9fff]{2,}', text)
    for phrase in chinese_phrases:
        keywords.add(phrase)
        # 提取长短语的子串
        if len(phrase) >= 4:
            for i in range(len(phrase) - 1):
                for j in range(i + 2, min(i + 5, len(phrase) + 1)):
                    keywords.add(phrase[i:j])
    return keywords


def calculate_similarity(
    current_kps: List[str],
    current_subject: str,
    current_text: str,
    existing_question: Dict[str, Any]
) -> Dict[str, Any]:
    """
    计算当前题目与已有错题的相似度

    返回:
        {
            "score": float,          # 总相似度得分 (0-100)
            "matched_kps": list,     # 匹配到的知识点
            "match_type": str,       # 匹配类型描述
        }
    """
    score = 0.0
    matched_kps = []
    match_details = []

    # 获取已有题目的知识点名称
    existing_kps = [kp.get("name", "") for kp in existing_question.get("knowledge_points", [])]
    existing_kps_normalized = [normalize_text(kp) for kp in existing_kps]

    # 1. 知识点精确匹配 (每个匹配 +30 分)
    for kp in current_kps:
        kp_normalized = normalize_text(kp)
        if kp_normalized in existing_kps_normalized:
            score += 30
            matched_kps.append(kp)
            match_details.append(f"知识点精确匹配: {kp}")

    # 2. 知识点子串匹配 (每个匹配 +15 分)
    for kp in current_kps:
        kp_normalized = normalize_text(kp)
        if kp_normalized not in existing_kps_normalized:  # 避免重复计分
            for existing_kp, existing_kp_normalized in zip(existing_kps, existing_kps_normalized):
                if (kp_normalized in existing_kp_normalized or
                        existing_kp_normalized in kp_normalized):
                    score += 15
                    if kp not in matched_kps:
                        matched_kps.append(kp)
                    match_details.append(f"知识点部分匹配: {kp} ↔ {existing_kp}")
                    break

    # 3. 同学科加分 (+10 分)
    if existing_question.get("subject", "") == current_subject:
        score += 10
        match_details.append(f"同学科: {current_subject}")

    # 4. 题目文字关键词匹配 (最多 +20 分)
    if current_text and existing_question.get("question_text", ""):
        current_keywords = extract_keywords(current_text)
        existing_keywords = extract_keywords(existing_question.get("question_text", ""))
        if current_keywords and existing_keywords:
            common = current_keywords & existing_keywords
            if common:
                keyword_score = min(20, len(common) * 2)
                score += keyword_score
                match_details.append(f"关键词匹配 {len(common)} 个")

    # 上限 100
    score = min(100, score)

    return {
        "score": round(score, 1),
        "matched_kps": matched_kps,
        "match_type": "; ".join(match_details) if match_details else "无匹配"
    }


def search_similar(
    index_path: str,
    subject: str,
    knowledge_points: List[str],
    question_text: str = "",
    threshold: float = 25.0,
    max_results: int = 5
) -> List[Dict[str, Any]]:
    """
    在错题索引中搜索相似错题

    参数:
        index_path: index.json 文件路径
        subject: 当前题目学科
        knowledge_points: 当前题目的知识点列表
        question_text: 当前题目文字（可选，用于辅助匹配）
        threshold: 相似度阈值，低于此值的不返回
        max_results: 最大返回结果数

    返回:
        相似错题列表，按相似度降序排列
    """
    # 读取索引文件
    if not os.path.exists(index_path):
        return []

    try:
        with open(index_path, 'r', encoding='utf-8') as f:
            index_data = json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        print(f"⚠️ 读取索引文件失败: {e}", file=sys.stderr)
        return []

    questions = index_data.get("questions", [])
    if not questions:
        return []

    results = []

    for q in questions:
        similarity = calculate_similarity(
            current_kps=knowledge_points,
            current_subject=subject,
            current_text=question_text,
            existing_question=q
        )

        if similarity["score"] >= threshold:
            results.append({
                "id": q.get("id", ""),
                "subject": q.get("subject", ""),
                "date": q.get("date", ""),
                "difficulty": q.get("difficulty", ""),
                "question_summary": q.get("question_summary", ""),
                "answer_summary": q.get("answer_summary", ""),
                "knowledge_points": [kp.get("name", "") for kp in q.get("knowledge_points", [])],
                "markdown_path": q.get("markdown_path", ""),
                "review_count": q.get("review_count", 0),
                "similarity_score": similarity["score"],
                "matched_knowledge_points": similarity["matched_kps"],
                "match_type": similarity["match_type"]
            })

    # 按相似度降序排列
    results.sort(key=lambda x: x["similarity_score"], reverse=True)

    return results[:max_results]


def main():
    parser = argparse.ArgumentParser(
        description="在错题索引中搜索相似错题",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python3 search_similar.py \\
    --index ~/错题库/index.json \\
    --subject 数学 \\
    --knowledge-points "二次函数,配方法,顶点坐标" \\
    --question-text "已知二次函数过三点求解析式"
        """
    )
    parser.add_argument('--index', required=True, help='index.json 文件路径')
    parser.add_argument('--subject', required=True, help='当前题目的学科')
    parser.add_argument('--knowledge-points', required=True,
                        help='当前题目的知识点，用逗号分隔')
    parser.add_argument('--question-text', default='',
                        help='当前题目的文字摘要（可选，用于辅助匹配）')
    parser.add_argument('--threshold', type=float, default=25.0,
                        help='相似度阈值 (默认: 25.0)')
    parser.add_argument('--max-results', type=int, default=5,
                        help='最大返回结果数 (默认: 5)')

    args = parser.parse_args()

    # 解析知识点列表
    kps = [kp.strip() for kp in args.knowledge_points.split(',') if kp.strip()]

    if not kps:
        print("❌ 错误：至少需要提供一个知识点", file=sys.stderr)
        sys.exit(1)

    results = search_similar(
        index_path=args.index,
        subject=args.subject,
        knowledge_points=kps,
        question_text=args.question_text,
        threshold=args.threshold,
        max_results=args.max_results
    )

    # 输出 JSON 结果
    output = {
        "query": {
            "subject": args.subject,
            "knowledge_points": kps,
            "question_text": args.question_text[:100] if args.question_text else ""
        },
        "total_matches": len(results),
        "results": results
    }

    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
