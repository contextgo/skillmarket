#!/usr/bin/env python3
"""
错题 PDF 导出脚本

将错题库中的 Markdown 错题文件导出为格式化的 PDF 文件，方便打印复习。
支持按学科、日期范围、知识点等条件筛选导出。

依赖:
  - markdown: Markdown 转 HTML
  - weasyprint: HTML 转 PDF (推荐，效果最佳)
  - 备选方案: 如果 weasyprint 不可用，使用 markdown + pdfkit 或纯文本方案

安装依赖:
  pip install markdown weasyprint

用法:
  python3 export_pdf.py \
    --source <错题库根目录> \
    --subject <学科/all> \
    --output <输出目录> \
    [--date-range <起始日期>:<结束日期>] \
    [--knowledge-point <知识点名称>]
"""

import argparse
import json
import os
import sys
import re
from datetime import datetime, date
from pathlib import Path
from typing import List, Dict, Optional, Tuple


# ─── HTML 模板 ───────────────────────────────────────────────

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<style>
@page {{
    size: A4;
    margin: 2cm 1.5cm;
    @top-center {{
        content: "错题本 — {title}";
        font-size: 9pt;
        color: #888;
    }}
    @bottom-center {{
        content: "第 " counter(page) " 页 / 共 " counter(pages) " 页";
        font-size: 9pt;
        color: #888;
    }}
}}

body {{
    font-family: "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei",
                 "WenQuanYi Micro Hei", "Noto Sans CJK SC", sans-serif;
    font-size: 11pt;
    line-height: 1.8;
    color: #333;
}}

/* 封面 */
.cover {{
    page-break-after: always;
    text-align: center;
    padding-top: 30%;
}}
.cover h1 {{
    font-size: 28pt;
    color: #2c3e50;
    margin-bottom: 10px;
}}
.cover .subtitle {{
    font-size: 14pt;
    color: #7f8c8d;
    margin-bottom: 30px;
}}
.cover .info {{
    font-size: 12pt;
    color: #95a5a6;
    line-height: 2;
}}

/* 目录 */
.toc {{
    page-break-after: always;
}}
.toc h2 {{
    font-size: 18pt;
    color: #2c3e50;
    border-bottom: 2px solid #3498db;
    padding-bottom: 5px;
}}
.toc ul {{
    list-style: none;
    padding: 0;
}}
.toc li {{
    padding: 5px 0;
    border-bottom: 1px dotted #ddd;
    font-size: 11pt;
}}
.toc li .page-ref {{
    float: right;
    color: #888;
}}

/* 错题条目 */
.question-entry {{
    page-break-before: always;
}}
.question-entry:first-of-type {{
    page-break-before: avoid;
}}

h1 {{
    font-size: 16pt;
    color: #2c3e50;
    border-bottom: 2px solid #3498db;
    padding-bottom: 5px;
    margin-top: 0;
}}
h2 {{
    font-size: 14pt;
    color: #2c3e50;
    margin-top: 20px;
}}
h3 {{
    font-size: 12pt;
    color: #34495e;
    margin-top: 15px;
}}

/* 元信息 */
.meta {{
    background: #f8f9fa;
    border-left: 4px solid #3498db;
    padding: 10px 15px;
    margin: 10px 0;
    font-size: 10pt;
    color: #555;
}}

/* 题目区域 */
.question-text {{
    background: #fff3cd;
    border: 1px solid #ffc107;
    border-radius: 5px;
    padding: 15px;
    margin: 15px 0;
}}

/* 答案区域 */
.answer-box {{
    background: #d4edda;
    border: 1px solid #28a745;
    border-radius: 5px;
    padding: 10px 15px;
    margin: 15px 0;
    font-weight: bold;
}}

/* 知识点表格 */
table {{
    width: 100%;
    border-collapse: collapse;
    margin: 15px 0;
    font-size: 10pt;
}}
th {{
    background: #3498db;
    color: white;
    padding: 8px 12px;
    text-align: left;
}}
td {{
    border: 1px solid #ddd;
    padding: 8px 12px;
}}
tr:nth-child(even) {{
    background: #f8f9fa;
}}

/* 警告/提醒区域 */
.warning {{
    background: #f8d7da;
    border: 1px solid #f5c6cb;
    border-radius: 5px;
    padding: 10px 15px;
    margin: 15px 0;
    color: #721c24;
}}

/* 引用块 */
blockquote {{
    border-left: 4px solid #3498db;
    margin: 10px 0;
    padding: 5px 15px;
    background: #f8f9fa;
    color: #555;
}}

/* 图片 */
img {{
    max-width: 100%;
    height: auto;
    display: block;
    margin: 10px auto;
    border: 1px solid #ddd;
    border-radius: 3px;
}}

/* 重绘图形（SVG）— 打印优化 */
img[src*="figures/"] {{
    border: none;
    background: white;
    padding: 10px;
    max-width: 80%;
}}

/* 图形说明文字 */
.figure-description {{
    font-size: 10pt;
    color: #555;
    text-align: center;
    font-style: italic;
    margin: 5px auto 15px;
    max-width: 80%;
}}

/* SVG 内联图形 */
svg {{
    display: block;
    margin: 10px auto;
    max-width: 80%;
    height: auto;
}}

/* 代码/公式 */
code {{
    background: #f4f4f4;
    padding: 2px 5px;
    border-radius: 3px;
    font-size: 10pt;
}}

/* 分隔线 */
hr {{
    border: none;
    border-top: 1px solid #ddd;
    margin: 20px 0;
}}
</style>
</head>
<body>
{content}
</body>
</html>
"""

COVER_TEMPLATE = """
<div class="cover">
    <h1>📚 错题本</h1>
    <div class="subtitle">{subject}</div>
    <div class="info">
        <p>错题数量：{count} 道</p>
        <p>{date_range}</p>
        <p>导出时间：{export_time}</p>
    </div>
</div>
"""


# ─── 核心函数 ─────────────────────────────────────────────────

def load_index(source_dir: str) -> Dict:
    """加载错题索引"""
    index_path = os.path.join(source_dir, "index.json")
    if not os.path.exists(index_path):
        print(f"❌ 错误：索引文件不存在: {index_path}", file=sys.stderr)
        sys.exit(1)

    with open(index_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def filter_questions(
    questions: List[Dict],
    subject: str = "all",
    date_range: Optional[Tuple[str, str]] = None,
    knowledge_point: Optional[str] = None
) -> List[Dict]:
    """按条件筛选错题"""
    filtered = questions

    # 按学科筛选
    if subject != "all":
        filtered = [q for q in filtered if q.get("subject", "") == subject]

    # 按日期范围筛选
    if date_range:
        start_date, end_date = date_range
        filtered = [
            q for q in filtered
            if start_date <= q.get("date", "") <= end_date
        ]

    # 按知识点筛选
    if knowledge_point:
        kp_lower = knowledge_point.lower()
        filtered = [
            q for q in filtered
            if any(
                kp_lower in kp.get("name", "").lower()
                for kp in q.get("knowledge_points", [])
            )
        ]

    # 按日期倒序排列
    filtered.sort(key=lambda x: x.get("date", ""), reverse=True)

    return filtered


def read_markdown_file(source_dir: str, md_path: str) -> str:
    """读取 Markdown 文件内容"""
    full_path = os.path.join(source_dir, md_path)
    if not os.path.exists(full_path):
        return f"⚠️ 文件未找到: {md_path}"

    with open(full_path, 'r', encoding='utf-8') as f:
        return f.read()


def markdown_to_html(md_content: str, source_dir: str, subject: str) -> str:
    """将 Markdown 内容转换为 HTML"""
    try:
        import markdown
        from markdown.extensions.tables import TableExtension

        # 处理图片路径：将相对路径转为绝对路径（包括 images/ 和 figures/ 目录）
        img_base = os.path.join(source_dir, subject)

        def fix_img_path(match):
            alt = match.group(1)
            src = match.group(2)
            if not os.path.isabs(src) and not src.startswith('http'):
                abs_path = os.path.abspath(os.path.join(img_base, src))
                # 对于 SVG 文件，使用 <img> 标签确保正确渲染
                if src.lower().endswith('.svg'):
                    return f'![{alt}](file://{abs_path})'
                return f'![{alt}](file://{abs_path})'
            return match.group(0)

        md_content = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', fix_img_path, md_content)

        # 处理 HTML 注释中的图形描述，转换为可见的说明文字
        def convert_figure_desc(match):
            desc = match.group(1).strip()
            if desc.startswith('图形描述：'):
                desc_text = desc[len('图形描述：'):]
                return f'<div class="figure-description">📐 {desc_text}</div>'
            return ''

        md_content = re.sub(r'<!--\s*(图形描述：[^>]+?)\s*-->', convert_figure_desc, md_content)

        html = markdown.markdown(
            md_content,
            extensions=['tables', 'fenced_code', 'nl2br']
        )
        return html

    except ImportError:
        # 如果 markdown 库不可用，使用简单的文本转换
        return simple_md_to_html(md_content)


def simple_md_to_html(md_content: str) -> str:
    """简单的 Markdown 到 HTML 转换（备选方案）"""
    html = md_content

    # 标题
    html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
    html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
    html = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)

    # 粗体和斜体
    html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
    html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)

    # 引用
    html = re.sub(r'^> (.+)$', r'<blockquote>\1</blockquote>', html, flags=re.MULTILINE)

    # 分隔线
    html = re.sub(r'^---+$', '<hr>', html, flags=re.MULTILINE)

    # 段落
    paragraphs = html.split('\n\n')
    html = ''.join(
        f'<p>{p}</p>' if not p.startswith('<') else p
        for p in paragraphs
    )

    return html


def generate_toc(questions: List[Dict]) -> str:
    """生成目录 HTML"""
    toc_items = []
    for i, q in enumerate(questions, 1):
        toc_items.append(
            f'<li>{i}. [{q.get("date", "")}] {q.get("id", "")} — '
            f'{q.get("question_summary", "无摘要")}'
            f'</li>'
        )

    return f"""
<div class="toc">
    <h2>📑 目录</h2>
    <ul>
        {"".join(toc_items)}
    </ul>
</div>
"""


def generate_html(
    source_dir: str,
    questions: List[Dict],
    subject: str,
    date_range_str: str
) -> str:
    """生成完整的 HTML 内容"""

    # 封面
    subject_display = subject if subject != "all" else "全部学科"
    cover = COVER_TEMPLATE.format(
        subject=subject_display,
        count=len(questions),
        date_range=date_range_str if date_range_str else "全部时间",
        export_time=datetime.now().strftime("%Y-%m-%d %H:%M")
    )

    # 目录
    toc = generate_toc(questions)

    # 各错题内容
    entries = []
    for q in questions:
        md_path = q.get("markdown_path", "")
        if md_path:
            md_content = read_markdown_file(source_dir, md_path)
            q_subject = q.get("subject", subject)
            html_content = markdown_to_html(md_content, source_dir, q_subject)
            entries.append(f'<div class="question-entry">{html_content}</div>')

    all_content = cover + toc + "\n".join(entries)

    return HTML_TEMPLATE.format(
        title=subject_display,
        content=all_content
    )


def export_to_pdf(html_content: str, output_path: str) -> bool:
    """将 HTML 导出为 PDF"""
    try:
        from weasyprint import HTML as WeasyprintHTML
        WeasyprintHTML(string=html_content).write_pdf(output_path)
        return True
    except ImportError:
        pass

    # 备选方案 1: pdfkit
    try:
        import pdfkit
        pdfkit.from_string(html_content, output_path, options={
            'encoding': 'UTF-8',
            'page-size': 'A4',
            'margin-top': '2cm',
            'margin-bottom': '2cm',
            'margin-left': '1.5cm',
            'margin-right': '1.5cm',
        })
        return True
    except ImportError:
        pass

    # 备选方案 2: 保存为 HTML（用户可通过浏览器打印为 PDF）
    html_output = output_path.replace('.pdf', '.html')
    with open(html_output, 'w', encoding='utf-8') as f:
        f.write(html_content)

    print(f"⚠️ 未安装 PDF 生成库 (weasyprint 或 pdfkit)。", file=sys.stderr)
    print(f"   已生成 HTML 文件: {html_output}", file=sys.stderr)
    print(f"   可通过浏览器打开并打印为 PDF。", file=sys.stderr)
    print(f"   安装推荐: pip install weasyprint", file=sys.stderr)
    return False


def main():
    parser = argparse.ArgumentParser(
        description="将错题库导出为格式化 PDF",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 导出数学科目的所有错题
  python3 export_pdf.py --source ~/错题库 --subject 数学 --output ~/错题库/exports/

  # 导出所有科目的错题
  python3 export_pdf.py --source ~/错题库 --subject all --output ~/错题库/exports/

  # 按日期范围导出
  python3 export_pdf.py --source ~/错题库 --subject 物理 --output ~/错题库/exports/ \\
    --date-range "2026-01-01:2026-03-31"

  # 按知识点导出
  python3 export_pdf.py --source ~/错题库 --subject 数学 --output ~/错题库/exports/ \\
    --knowledge-point "二次函数"
        """
    )

    parser.add_argument('--source', required=True, help='错题库根目录路径')
    parser.add_argument('--subject', required=True,
                        help='学科名称，或 "all" 导出全部学科')
    parser.add_argument('--output', required=True, help='PDF 输出目录')
    parser.add_argument('--date-range', default=None,
                        help='日期范围，格式 "YYYY-MM-DD:YYYY-MM-DD"')
    parser.add_argument('--knowledge-point', default=None,
                        help='按知识点筛选')

    args = parser.parse_args()

    # 验证源目录
    if not os.path.isdir(args.source):
        print(f"❌ 错误：错题库目录不存在: {args.source}", file=sys.stderr)
        sys.exit(1)

    # 加载索引
    index_data = load_index(args.source)
    questions = index_data.get("questions", [])

    if not questions:
        print("📭 错题库为空，没有可导出的错题。")
        sys.exit(0)

    # 解析日期范围
    date_range = None
    date_range_str = ""
    if args.date_range:
        try:
            parts = args.date_range.split(':')
            date_range = (parts[0].strip(), parts[1].strip())
            date_range_str = f"{date_range[0]} 至 {date_range[1]}"
        except (IndexError, ValueError):
            print(f"❌ 错误：日期范围格式不正确，应为 'YYYY-MM-DD:YYYY-MM-DD'",
                  file=sys.stderr)
            sys.exit(1)

    # 确定导出科目列表
    if args.subject == "all":
        subjects = list(set(q.get("subject", "未分类") for q in questions))
        subjects.sort()
    else:
        subjects = [args.subject]

    # 创建输出目录
    os.makedirs(args.output, exist_ok=True)

    # 逐学科导出
    total_exported = 0
    for subject in subjects:
        filtered = filter_questions(
            questions,
            subject=subject,
            date_range=date_range,
            knowledge_point=args.knowledge_point
        )

        if not filtered:
            print(f"📭 [{subject}] 没有符合条件的错题，跳过。")
            continue

        # 生成 HTML
        html_content = generate_html(
            source_dir=args.source,
            questions=filtered,
            subject=subject,
            date_range_str=date_range_str
        )

        # 导出 PDF
        timestamp = datetime.now().strftime("%Y%m%d")
        filename = f"错题本_{subject}_{timestamp}.pdf"
        output_path = os.path.join(args.output, filename)

        success = export_to_pdf(html_content, output_path)

        if success:
            print(f"✅ [{subject}] 导出成功: {output_path} ({len(filtered)} 道错题)")
        else:
            html_path = output_path.replace('.pdf', '.html')
            print(f"📄 [{subject}] HTML 已生成: {html_path} ({len(filtered)} 道错题)")

        total_exported += len(filtered)

    print(f"\n📊 导出完成！共导出 {total_exported} 道错题，涵盖 {len(subjects)} 个学科。")
    print(f"📁 输出目录: {args.output}")


if __name__ == "__main__":
    main()
