---
name: tomoviee-video-continuation
description: Continue/extend existing 5-second video by generating next segment. Use when users request video_continuation operations or related tasks.
---

# Tomoviee AI - 视频续写 (Video Continuation)

## Overview

Continue/extend existing 5-second video by generating next segment.

**API**: `tm_video_continuation_b`

## Quick Start

### Authentication

```bash
python scripts/generate_auth_token.py YOUR_APP_KEY YOUR_APP_SECRET
```

### Python Client

```python
from scripts.tomoviee_video_continuation_client import TomovieeClient

client = TomovieeClient("app_key", "app_secret")
```

## API Usage

### Basic Example

```python
task_id = client._make_request({
    prompt='Bird continues soaring higher into blue sky'
    video='https://result.com/previous-video.mp4'
})

result = client.poll_until_complete(task_id)
import json
output = json.loads(result['result'])
```

### Parameters

- `prompt` (required): Description for continuation
- `video` (required): Video URL (MP4, <200M, 5s, 720p)
- `resolution`: `720p` or `1080p`
- `aspect_ratio`: `16:9`, `9:16`, `4:3`, `3:4`, `1:1`

## Async Workflow

1. **Create task**: Get `task_id` from API call
2. **Poll for completion**: Use `poll_until_complete(task_id)`
3. **Extract result**: Parse returned JSON for output URLs

**Status codes**:
- 1 = Queued
- 2 = Processing
- 3 = Success (ready)
- 4 = Failed
- 5 = Cancelled
- 6 = Timeout

## Resources

### scripts/
- `tomoviee_video_continuation_client.py` - API client
- `generate_auth_token.py` - Auth token generator

### references/
See bundled reference documents for detailed API documentation and examples.

## External Resources

- **Developer Portal**: https://www.tomoviee.ai/developers.html
- **API Documentation**: https://www.tomoviee.ai/doc/
- **Get API Credentials**: Register at developer portal
