# MT4 Bridge API 完整文档

## 通信原理

**协议**：JSON over 文件（零 DLL 依赖）

```
┌──────────┐  request_{symbol}.json  ┌──────────────┐
│  Python   │ ──────────────────────→│  MT4 EA      │
│  Client   │ ←──────────────────────│  (on chart)   │
└──────────┘  response_{symbol}.json └──────────────┘
```

**目录**：`%APPDATA%\MetaQuotes\Terminal\Common\Files\mt4_bridge\`
- 示例：`C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\Common\Files\mt4_bridge\`
- 品种专属文件名：`request_XAUUSD.s.json`、`response_XAUUSD.s.json`
- 多品种共用时，每个 EA 实例自动读写自己的品种文件

**文件锁机制**：Python 客户端创建 `.lock` 文件防止读写冲突，EA 检测到锁文件时等待后重试。

**超时**：5 秒（Python 客户端默认），超时返回 `"MT4 超时未响应"`。

---

## 方法一览（共 57+ 方法）

### 行情查询（11 个）

| 方法 | 描述 | 必传参数 |
|------|------|---------|
| `get_price()` | 获取实时报价（bid/ask） | `symbol` |
| `get_positions()` | 获取持仓列表 | — |
| `get_account_info()` | 获取账户信息（余额/净值/保证金等） | — |
| `get_history()` | 获取历史订单 | `days` |
| `calc_lots()` | 按风险%计算手数 | `symbol`, `risk_percent`, `sl_distance` |
| `get_klines()` | 获取 K 线（OHLCV）数据 | `symbol`, `timeframe`, `count` |
| `get_sr_levels()` | 获取支撑压力位 | `symbol` |
| `get_pending_orders()` | 查询当前挂单 | — |
| `get_alert_count()` | 获取当前预警数量 | — |
| `check_prices()` | 手动触发价格预警检查 | — |
| `get_orders_history_by_date()` | 按日期范围查询历史订单 | `from_date`, `to_date` |

### 市价交易（7 个）

| 方法 | 描述 | 必传参数 |
|------|------|---------|
| `buy()` | 市价买入开仓 | `symbol`, `lots` |
| `sell()` | 市价卖出开仓 | `symbol`, `lots` |
| `close()` | 平指定订单 | `ticket` |
| `close_all()` | 一键全部平仓 | — |
| `close_all_buy()` | 平所有多单 | — |
| `close_all_sell()` | 平所有空单 | — |
| `partial_close()` | 部分平仓 | `ticket`, `lots` |

### 挂单交易（6 个）

| 方法 | 描述 | 必传参数 |
|------|------|---------|
| `buy_limit()` | 限价买入（低于现价挂买单） | `symbol`, `lots`, `price` |
| `sell_limit()` | 限价卖出（高于现价挂卖单） | `symbol`, `lots`, `price` |
| `buy_stop()` | 买入止损（高于现价追涨） | `symbol`, `lots`, `price` |
| `sell_stop()` | 卖出止损（低于现价追空） | `symbol`, `lots`, `price` |
| `cancel_pending()` | 取消挂单 | `ticket` |
| `oco_order()` | OCO 二选一订单 | `symbol`, `lots`, `order1`, `order2` |

### 止损止盈（9 个）

| 方法 | 描述 | 必传参数 |
|------|------|---------|
| `set_sl()` | 设置止损价 | `ticket`, `sl` |
| `set_tp()` | 设置止盈价 | `ticket`, `tp` |
| `modify_order()` | 同时修改止损止盈 | `ticket`, `sl`, `tp` |
| `set_tp_by_profit()` | 按盈利金额设置止盈 | `ticket`, `profit` |
| `close_by_magic()` | 按 Magic Number 平仓 | `magic` |
| `auto_sl()` | 按账户风险%自动止损 | `ticket`, `risk_percent` |
| `atr_sl()` | ATR 动态止损 | `ticket`, `period`, `multiplier` |
| `trailing_stop()` | 移动止损 | `ticket`, `distance` |
| `close_profit()` | 平所有盈利单 | — |
| `close_loss()` | 平所有亏损单 | — |

### 芝麻网格策略（8 个）

| 方法 | 描述 | 必传参数 |
|------|------|---------|
| `grid_start()` | 启动网格 | `symbol` |
| `grid_stop()` | 停止网格（停止开新单） | `symbol` |
| `grid_close_all()` | 平所有网格持仓 | `symbol` |
| `grid_status()` | 查询网格运行状态 | `symbol` |
| `grid_set_sl_tp()` | 批量设置网格单止损止盈 | `symbol` |
| `grid_start_buy()` | 网格买入一笔 | `symbol` |
| `grid_start_sell()` | 网格卖出一笔 | `symbol` |
| `grid_reverse()` | 网格反向 | `symbol`, `lots` |

### 支撑压力位/画线（5 个）

| 方法 | 描述 | 必传参数 |
|------|------|---------|
| `draw_sr_levels()` | 在图表上画出支撑压力位 | `symbol` |
| `draw_trendline()` | 画趋势线 | `symbol`, `price1`, `price2`, `label` |
| `draw_hline()` | 画水平线 | `symbol`, `price`, `label` |
| `draw_vline()` | 画垂直线 | `symbol`, `time`, `label` |
| `delete_object()` | 删除画线对象 | `symbol`, `name` |

### 价格预警（6 个）

| 方法 | 描述 | 必传参数 |
|------|------|---------|
| `add_alert()` | 添加价格预警 | `type`, `value` |
| `list_alerts()` | 查看所有预警 | — |
| `cancel_alert()` | 取消指定预警 | `index` |
| `clear_alerts()` | 清除所有预警 | — |
| `check_alerts()` | 手动触发预警检查 | — |
| `get_alert_count()` | 获取预警数量 | — |

### 辅助（8 个）

| 方法 | 描述 | 必传参数 |
|------|------|---------|
| `set_magic_override()` | 设置自定义 Magic Number | `magic` |
| `set_timeout()` | 设置超时时间（秒） | `seconds` |
| `set_retry()` | 设置重试次数 | `count` |
| `get_bridge_dir()` | 获取桥接目录路径 | — |
| `_transact()` | 底层交易方法（内部使用） | — |
| `safe_close_all()` | 安全全平（含错误处理） | `symbol` |
| `set_default_symbol()` | 设置默认品种 | `symbol` |

---

## 详细文档

### get_price(symbol) —— 获取实时报价

获取指定品种的当前买价（bid）和卖价（ask）。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `symbol` | str | ✅ | 品种代码，如 "XAUUSD.s"、"BTCUSD" |

**请求 JSON：**
```json
{"action": "get_price", "symbol": "XAUUSD.s"}
```

**成功响应：**
```json
{
  "status": "success",
  "symbol": "XAUUSD.s",
  "bid": 4565.20,
  "ask": 4565.70,
  "time": "2026-05-04 12:30:00"
}
```

**失败响应：**
```json
{"status": "error", "error": "无法获取价格: XAUUSD.s"}
```

**Python 示例：**
```python
price = client.get_price(symbol="XAUUSD.s")
print(price)
# {'status': 'success', 'symbol': 'XAUUSD.s', 'bid': 4565.20, 'ask': 4565.70, 'time': '...'}
```

---

### get_positions() —— 查询持仓

查询当前所有未平仓订单。

**请求 JSON：**
```json
{"action": "get_positions"}
```

**成功响应：**
```json
{
  "status": "success",
  "count": 2,
  "positions": [
    {
      "ticket": 95308752,
      "symbol": "XAUUSD.s",
      "type": "buy",
      "lots": 0.05,
      "open_price": 4580.35,
      "current_price": 4595.00,
      "sl": 4573.00,
      "tp": 4588.00,
      "profit": 7.25,
      "swap": 0.00,
      "commission": -0.25,
      "magic": 888888,
      "open_time": "2026-05-01 07:56:00"
    }
  ]
}
```

> 注意：当持仓为 0 时，返回 `{"status": "success", "count": 0, "positions": []}`

**Python 代码：**
```python
positions = client.get_positions()
if positions["count"] > 0:
    for pos in positions["positions"]:
        print(f"{pos['type']} {pos['symbol']} {pos['lots']} lot @ {pos['open_price']}")
else:
    print("0 持仓")
```

---

### get_account_info() —— 获取账户信息

**请求 JSON：**
```json
{"action": "get_account_info"}
```

**成功响应：**
```json
{
  "status": "success",
  "balance": 10000.00,
  "equity": 10007.25,
  "margin": 500.00,
  "free_margin": 9507.25,
  "margin_level": 2001.45,
  "leverage": "1:100",
  "currency": "USD",
  "server": "EBCFinancial-Demo01",
  "company": "EBC Financial Group",
  "name": "Demo Account",
  "number": 12345678
}
```

**Python 代码：**
```python
info = client.get_account_info()
print(f"余额: ${info['balance']:.2f}")
print(f"净值: ${info['equity']:.2f}")
print(f"保证金比例: {info['margin_level']:.1f}%")
```

---

### get_history(days) —— 查询历史订单

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `days` | int | ✅ | 查询最近多少天的历史（1~365） |

**请求 JSON：**
```json
{"action": "get_history", "days": 7}
```

**成功响应：**
```json
{
  "status": "success",
  "count": 15,
  "orders": [
    {
      "ticket": 94854144,
      "symbol": "XAUUSD.s",
      "type": "sell",
      "lots": 0.05,
      "open_price": 4565.20,
      "close_price": 4555.30,
      "profit": 9.10,
      "open_time": "2026-04-29 10:00:00",
      "close_time": "2026-04-29 14:30:00"
    }
  ]
}
```

---

### buy(symbol, lots) / sell(symbol, lots) —— 市价开仓

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `symbol` | str | ✅ | 品种代码 |
| `lots` | float | ✅ | 手数（如 0.01、0.05、0.10） |

**请求 JSON：**
```json
{"action": "buy", "symbol": "XAUUSD.s", "lots": "0.05", "price": "0"}
```

> `price: "0"` 表示市价单。如果传具体价格则为限价单（不推荐，用 buy_limit/sell_limit 更明确）。

**成功响应：**
```json
{
  "status": "success",
  "action": "buy",
  "ticket": 95308752,
  "symbol": "XAUUSD.s",
  "lots": 0.05,
  "price": 4580.35
}
```

**失败响应（4106）：**
```json
{"status": "error", "error": "买入失败: Trade is disabled [4106]"}
```

> 常见 4106 原因：EA 属性中未勾选"允许实时交易"，或 MT4 自动交易按钮为关闭状态。

**Python 代码：**
```python
# ✅ 正确用法
result = client.buy(symbol="XAUUSD.s", lots=0.05)

# ❌ 错误用法（参数顺序问题！）
result = client.buy(0.05, "XAUUSD.s")  # 可能会报 4106 错误

if result["status"] == "success":
    print(f"开仓成功，ticket: {result['ticket']}")
else:
    print(f"开仓失败: {result['error']}")
```

---

### close(ticket) —— 平仓

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `ticket` | int | ✅ | 订单编号 |

**请求 JSON：**
```json
{"action": "close", "ticket": "95308752"}
```

**成功响应：**
```json
{
  "status": "success",
  "action": "close",
  "ticket": 95308752
}
```

**Python 代码：**
```python
result = client.close(ticket=95308752)
```

---

### close_all() —— 一键全平

平掉所有持仓单。

> ⚠️ 注意：网格策略的持仓单（magic=777777）不受此命令影响，需使用 `grid_stop` + `grid_close_all` 平网格单。

**请求 JSON：**
```json
{"action": "close_all"}
```

**成功响应：**
```json
{"status": "success", "action": "close_all", "message": "closed 5 orders"}
```

---

### close_all_buy() / close_all_sell() —— 按方向平仓

**close_all_buy** —— 平所有多单
**close_all_sell** —— 平所有空单

**请求 JSON：**
```json
{"action": "close_all_buy"}
```

**成功响应：**
```json
{"status": "success", "message": "closed 3 buy"}
```

---

### close_profit() / close_loss() —— 按盈亏平仓

**close_profit** —— 平所有盈利持仓（`profit + swap + commission > 0`）
**close_loss** —— 平所有亏损持仓（`profit + swap + commission < 0`）

**请求 JSON：**
```json
{"action": "close_profit"}
```

**成功响应：**
```json
{"status": "success", "message": "closed 2 profit"}
```

---

### partial_close(ticket, lots) —— 部分平仓

部分平掉指定订单的部分手数。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `ticket` | int | ✅ | 订单编号 |
| `lots` | float | ✅ | 平掉的手数（必须小于持仓量） |

**请求 JSON：**
```json
{"action": "partial_close", "ticket": "95308752", "lots": "0.02"}
```

**成功响应：**
```json
{"status": "success", "action": "partial_close", "ticket": 95308752}
```

---

### buy_limit / sell_limit / buy_stop / sell_stop —— 挂单

**buy_limit(symbol, lots, price)** —— 限价买单（低于当前市价挂多单，期待价格回踩买入）

**sell_limit(symbol, lots, price)** —— 限价卖单（高于当前市价挂空单，期待价格反弹卖出）

**buy_stop(symbol, lots, price)** —— 买入止损单（高于当前市价挂多单，期待价格突破追涨）

**sell_stop(symbol, lots, price)** —— 卖出止损单（低于当前市价挂空单，期待价格破位追空）

**请求 JSON（以 buy_limit 为例）：**
```json
{"action": "buy_limit", "symbol": "XAUUSD.s", "lots": "0.03", "price": "4500.00"}
```

**成功响应：**
```json
{"status": "success", "action": "buy_limit", "ticket": 95412345}
```

**Python 代码：**
```python
# 黄金回调到 4500 买入
client.buy_limit(symbol="XAUUSD.s", lots=0.03, price=4500.00)

# BTC 突破 80000 追涨
client.buy_stop(symbol="BTCUSD", lots=0.01, price=80000.00)
```

---

### get_pending_orders() —— 查询挂单

**请求 JSON：**
```json
{"action": "get_pending_orders"}
```

**成功响应：**
```json
{
  "status": "success",
  "count": 2,
  "orders": [
    {
      "ticket": 95412345,
      "symbol": "XAUUSD.s",
      "type": "buy_limit",
      "lots": 0.03,
      "price": 4500.00,
      "sl": 0,
      "tp": 0,
      "open_time": "2026-05-04 10:00:00"
    }
  ]
}
```

---

### cancel_pending(ticket) —— 取消挂单

**请求 JSON：**
```json
{"action": "cancel_pending", "ticket": "95412345"}
```

**成功响应：**
```json
{"status": "success", "action": "cancel_pending", "ticket": 95412345}
```

---

### oco_order(symbol, lots, order1, order2) —— OCO 二选一订单

同时挂两个方向相反的挂单，其中一个成交后自动取消另一个。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `symbol` | str | ✅ | 品种代码 |
| `lots` | float | ✅ | 手数 |
| `order1` | dict | ✅ | 第一个挂单定义 |
| `order2` | dict | ✅ | 第二个挂单定义 |

order1/order2 格式：
```python
{
    "type": "buy_stop|sell_stop|buy_limit|sell_limit",
    "price": 77000,
    "sl": 76500,      # 可选
    "tp": 78000       # 可选
}
```

**请求 JSON：**
```json
{
  "action": "oco_order",
  "symbol": "XAUUSD.s",
  "lots": "0.03",
  "order1": {"type": "buy_stop", "price": "77000", "sl": "76500"},
  "order2": {"type": "sell_stop", "price": "76000", "sl": "76500"}
}
```

**成功响应：**
```json
{
  "status": "success",
  "action": "oco_order",
  "order1_ticket": 95420001,
  "order2_ticket": 95420002
}
```

---

### set_sl(ticket, sl) / set_tp(ticket, tp) —— 设置止损止盈

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `ticket` | int | ✅ | 订单编号 |
| `sl` | float | ✅ (set_sl) | 止损价格 |
| `tp` | float | ✅ (set_tp) | 止盈价格 |

**请求 JSON：**
```json
{"action": "set_sl", "ticket": "95308752", "sl": "4573.00"}
```

**成功响应：**
```json
{"status": "success", "action": "set_sl", "ticket": 95308752}
```

---

### modify_order(ticket, sl, tp) —— 同时修改止损止盈

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `ticket` | int | ✅ | 订单编号 |
| `sl` | float | ✅ | 新止损价 |
| `tp` | float | ✅ | 新止盈价 |

**请求 JSON：**
```json
{"action": "modify_order", "ticket": "95308752", "sl": "4570.00", "tp": "4600.00"}
```

**成功响应：**
```json
{"status": "success", "action": "modify_order", "ticket": 95308752}
```

---

### close_by_magic(magic) —— 按 Magic Number 平仓

平掉所有指定 Magic Number 的持仓。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `magic` | int | ✅ | Magic Number |

**请求 JSON：**
```json
{"action": "close_by_magic", "magic": "888888"}
```

**成功响应：**
```json
{"status": "success", "action": "close_by_magic", "closed": 5}
```

---

### set_tp_by_profit(ticket, profit) —— 按盈利金额设止盈

设置止盈价为当前价格 + 目标盈利金额对应的点数。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `ticket` | int | ✅ | 订单编号 |
| `profit` | float | ✅ | 目标盈利金额（美元） |

**请求 JSON：**
```json
{"action": "set_tp_by_profit", "ticket": "95308752", "profit": "20.00"}
```

---

### auto_sl(ticket, risk_percent) —— 按账户风险%止损

根据账户余额计算止损价，防止单笔亏损超过指定比例。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `ticket` | int | ✅ | 订单编号 |
| `risk_percent` | float | ✅ | 风险比例（如 2.0 = 2%） |

**Python 示例：**
```python
# 限制该笔最大亏损为账户余额的 2%
client.auto_sl(ticket=95308752, risk_percent=2.0)
```

---

### atr_sl(ticket, period, multiplier) —— ATR 动态止损

基于 ATR（Average True Range，平均真实波幅）指标设置止损。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `ticket` | int | ✅ | 订单编号 |
| `period` | int | ✅ | ATR 计算周期（推荐 14） |
| `multiplier` | float | ✅ | ATR 倍数（推荐 2.0） |

**ATR 倍数参考：**
| 交易风格 | 倍数 | 说明 |
|---------|------|------|
| 激进日内 | 1.5x | 止损窄，易被扫 |
| 标准日内 | **2.0x** | ✅ 推荐 |
| 宽松/波段 | 3.0x | 容错空间大 |

**Python 示例：**
```python
# 黄金多单，14周期 ATR，2 倍止损
client.atr_sl(ticket=95308752, period=14, multiplier=2.0)
```

---

### trailing_stop(ticket, distance) —— 移动止损

当价格朝有利方向移动时，自动上移止损线，锁住利润。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `ticket` | int | ✅ | 订单编号 |
| `distance` | int | ✅ | 止损距离（点数，如 300 = 300 点） |

**Python 示例：**
```python
# 持仓价向有利方向移动超过 300 点时，止损自动上移 300 点跟随
client.trailing_stop(ticket=95308752, distance=300)
```

---

### calc_lots(symbol, risk_percent, sl_distance) —— 手数计算

根据账户余额、风险百分比和止损距离计算建议交易手数。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `symbol` | str | ✅ | 品种代码 |
| `risk_percent` | float | ✅ | 该笔所愿承受的风险（账户余额的百分比） |
| `sl_distance` | float | ✅ | 止损距离（美元） |

**Python 示例：**
```python
# 黄金，1% 风险，止损 5 美元 → 返回建议手数
lots = client.calc_lots(symbol="XAUUSD.s", risk_percent=1.0, sl_distance=5.0)
print(f"建议手数: {lots}")
```

---

### get_klines(symbol, timeframe, count) —— K 线数据

获取历史 K 线数据（开盘价/最高价/最低价/收盘价/成交量），用于量化分析。

**参数：**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `symbol` | str | ✅ | 品种代码 |
| `timeframe` | str | ✅ | 周期：M1, M5, M15, M30, H1, H4, D1, W1, MN |
| `count` | int | ✅ | 获取的 K 线数量（最大 1000） |

**请求 JSON：**
```json
{"action": "get_klines", "symbol": "XAUUSD.s", "timeframe": "H1", "count": "20"}
```

**成功响应：**
```json
{
  "status": "success",
  "symbol": "XAUUSD.s",
  "timeframe": "H1",
  "count": 20,
  "data": [
    {"time": "2026-05-04 08:00:00", "open": 4560.0, "high": 4570.0, "low": 4558.0, "close": 4568.0, "volume": 1200},
    {"time": "2026-05-04 09:00:00", "open": 4568.0, "high": 4575.0, "low": 4565.0, "close": 4572.0, "volume": 1500}
  ]
}
```

**支持的周期：**
| 参数 | 含义 |
|------|------|
| M1, M5, M15, M30 | 分钟 |
| H1, H4 | 小时 |
| D1 | 日线 |
| W1 | 周线 |
| MN | 月线 |

**Python 示例：**
```python
# 获取最近 20 根 H1 K 线
klines = client.get_klines(symbol="XAUUSD.s", timeframe="H1", count=20)
for k in klines["data"]:
    print(f"{k['time']} O:{k['open']} H:{k['high']} L:{k['low']} C:{k['close']}")
```

---

## 网格策略 API（芝麻网格 EA）

网格策略通过独立的芝麻网格 EA（magic=777777）运行，使用 `grid_bridge` 目录通信。

> ⚠️ 重要约束：
> - 平网格仓必须：`grid_stop()` → `grid_close_all()` 两步
> - `close_all()` 命令会拒绝 magic=777777 的订单
> - 网格单的精确持仓查询通过 `grid_status()` 完成

### grid_start(symbol) —— 启动网格

在指定品种上启动网格策略。EA 会根据预设参数在价格区间内自动分批挂单。

```python
client.grid_start(symbol="XAUUSD.s")
```

**成功响应：**
```json
{"status": "success", "action": "grid_start", "message": "grid started"}
```

### grid_stop(symbol) —— 停止网格

停止网格 EA 继续开新单。已开的持仓单不受影响。

```python
client.grid_stop(symbol="XAUUSD.s")
```

### grid_close_all(symbol) —— 平所有网格单

平掉所有网格策略的持仓单。

```python
client.grid_close_all(symbol="XAUUSD.s")
```

> 强烈建议先 `grid_stop()` 再 `grid_close_all()`，防止平仓过程中网格 EA 又开新单。

### grid_status(symbol) —— 网格状态查询

```python
status = client.grid_status(symbol="XAUUSD.s")
print(status)
# {'status': 'success', 'running': True, 'orders': [...], 'profit': 12.50, ...}
```

---

## 价格预警 API

预警系统支持以下类型：

| 预警类型 | 说明 | value 含义 |
|---------|------|-----------|
| `profit` | 总盈利达到目标时触发 | 目标盈利金额（美元） |
| `above` | 价格突破时触发 | 突破价格 |
| `below` | 价格跌破时触发 | 跌破价格 |

### add_alert(type, value) —— 添加预警

```python
# 盈利达到 $20 提醒
client.add_alert(type="profit", value=20)
# BTC 突破 77000 提醒
client.add_alert(type="above", value=77000)
# BTC 跌破 75000 提醒
client.add_alert(type="below", value=75000)
```

### list_alerts() —— 查看预警

```python
alerts = client.list_alerts()
```

### cancel_alert(index) —— 取消预警

```python
client.cancel_alert(index=3)
```

### clear_alerts() —— 清除所有预警

```python
client.clear_alerts()
```

---

## 品种代码速查

| 品种 | 标准代码 | 注意 |
|------|---------|------|
| 黄金 | `XAUUSD.s` | 部分经纪商为 XAUUSD（无 .s） |
| 白银 | `XAGUSD.s` | 或 XAGUSD |
| 原油 WTI | `XTIUSD.s` | 或 USOIL、CL |
| 布伦特原油 | `XBRUSD` | 或 UKOIL |
| 比特币 | `BTCUSD` | 部分平台为 BTCUSD.pro |
| 以太坊 | `ETHUSD` | 部分平台不支持 |
| 欧元/美元 | `EURUSD` | 标准外汇货币对 |
| 英镑/美元 | `GBPUSD` | 标准外汇货币对 |
| 美元/日元 | `USDJPY` | 标准外汇货币对 |

> 品种代码因经纪商而异。如果报错"无法获取价格"，请在 MT4 市场报价中右键 → "全部显示"确认精确名称。

---

## 错误码参考

| 错误码 | 含义 | 常见原因 |
|--------|------|---------|
| 4106 | 交易被禁用 | 未勾选"允许实时交易"或自动交易按钮关闭 |
| 4107 | 市场关闭 | 经纪商休市（周末常见） |
| 4108 | 无效单量 | 手数超出允许范围 |
| 4111 | 交易超时 | 服务器繁忙 |
| 4113 | 无效价格 | 挂单价格超出当前市价范围 |
| 4200 | 保证金不足 | 可用保证金不够开仓 |
| 4202 | 已停止交易 | 账户已被冻结或限制 |
| 4001 | 品种被禁用 | 该品种不允许交易 |
| 4002 | 无效品种 | 品种名称不正确 |
| 1000 | 超时 | 请求发出后 5 秒内无响应 |

---

## 常见使用模式

### 模式 1：日内黄金交易

```python
# 开多
result = client.buy(symbol="XAUUSD.s", lots=0.05)
ticket = result["ticket"]

# 设置 ATR 止损
client.atr_sl(ticket=ticket, period=14, multiplier=2.0)

# 设置止盈
client.set_tp(ticket=ticket, tp=4605.00)
```

### 模式 2：网格策略完整流程

```python
# 启动网格
client.grid_start(symbol="XAUUSD.s")

# 查看状态
status = client.grid_status(symbol="XAUUSD.s")

# 停止网格 + 平仓
client.grid_stop(symbol="XAUUSD.s")
client.grid_close_all(symbol="XAUUSD.s")
```

### 模式 3：OCO 双向挂单

```python
# 黄金突破追涨 / 破位追空
client.oco_order(
    symbol="XAUUSD.s",
    lots=0.03,
    order1={"type": "buy_stop", "price": 4620.00, "sl": 4580.00},
    order2={"type": "sell_stop", "price": 4560.00, "sl": 4600.00}
)
```

### 模式 4：移动止损锁利

```python
ticket = client.buy(symbol="XAUUSD.s", lots=0.03)["ticket"]
# 价格朝有利方向移动时，止损自动跟随
client.trailing_stop(ticket=ticket, distance=300)
```
