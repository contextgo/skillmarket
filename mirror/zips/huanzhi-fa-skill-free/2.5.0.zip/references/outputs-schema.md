# Outputs 输出格式参考

## 融资诊断输出
```json
{
  "version": "2.3.1",
  "spec": "openclaw",
  "score": { "total": 0-100, "pct": 0-100 },
  "grade": "S|A|B|C|D",
  "summary": "一句话诊断结论",
  "dimensions": {
    "traction":  { "score": 0-15, "pct": 0-100, "reasons": ["..."] },
    "market":    { "score": 0-15, "pct": 0-100, "reasons": ["..."] },
    "team":      { "score": 0-15, "pct": 0-100, "reasons": ["..."] },
    "product":   { "score": 0-15, "pct": 0-100, "reasons": ["..."] },
    "story":     { "score": 0-10, "pct": 0-100, "reasons": ["..."] },
    "unit_econ": { "score": 0-10, "pct": 0-100, "reasons": ["..."] },
    "use_funds": { "score": 0-10, "pct": 0-100, "reasons": ["..."] },
    "timing":    { "score": 0-10, "pct": 0-100, "reasons": ["..."] }
  },
  "weakness": ["短板维度ID列表"],
  "suggestions": ["Top 3 改进建议"]
}
```

## 条款分析输出
```json
{
  "clause": "条款名称",
  "verdict": "green|yellow|red",
  "risk": "风险等级说明",
  "reason": "判断依据",
  "industry_standard": "行业标准做法",
  "suggestion": "谈判建议",
  "fallback": "替代方案"
}
```

## 输出校验规则
1. 脚本输出必须通过 `validate_output()` 自检函数校验
2. 校验失败时重试最多 1 次，仍失败则走 Failure 路径
3. LLM 生成内容需有明确的输出模板约束
