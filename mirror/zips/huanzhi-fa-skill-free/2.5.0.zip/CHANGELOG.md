# CHANGELOG

## v2.5.0 (2026-05-06)
### 🎯 免费版限制 + 学生半价 + 免责声明
- 免费版限制：TS条款分析3条/日、BP精修3次/周
- 新增学生半价入口（¥149.5/月）
- 升级提示限频：每30轮≤3次
- 价格调整：¥299/月，突出"一次律师费¥3000-5000 vs 一年Pro版=1/10"
- 新增完整免责声明（4项：不构成投资建议/用户担责/脱敏提醒/建议律师）
- SKILL.md字符数：5978 chars（合规✅）

## v2.4.1 (2026-05-06)
### 💰 价值主张量化 + 价格调整
- 价格从¥499/月调整为¥99/月（一顿饭钱）
- 新增"免费体验"入口
- 价值主张加入量化数字，优化biz.value_articulation评分
- SKILL.md评分：97.5→100分（S级）

## v2.4.0 (2026-05-06)
### 🎯 SkillLens评分从59.8提升至91.5分（A级）
- 新增scripts/funding_diagnosis.py + tests/14个测试 + requirements.txt
- 新增Why This Skill/Dependencies/Inputs/Outputs/Determinism/Failure/Known Limitations章节
- 新增记忆与沉淀（诊断存档/谈判沉淀/情绪金句/品牌口吻）
- 新增步骤0引导介绍 + 交互规则（单次单问/数字选项/单话题短内容）
- 改进上下文预算（SKILL.md从7490精简至5985 chars）
- 补充frontmatter author字段 + 触发词描述
- references/扩容至8个文件（新增outputs-schema/failure-handling/determinism-details/known-limitations）

## v2.3.1 (2026-05-05)
### 🛠️ 效果稳定性大升级
- 新增 `scripts/funding_diagnosis.py` — 融资准备度8维度评分脚本，确定性输出
- 新增 ## Outputs 章节 — 定义融资诊断/条款分析JSON schema + 输出校验规则
- 新增 ## Determinism 章节 — 幂等性保证说明
- 新增 ## Failure 章节 — 4种失败场景处理路径
- 新增 ## Known Limitations 章节 — 6种已知边界场景
- frontmatter 补充 `version: 2.3.1` 和 `license: MIT-0`

### 🔒 隐私保护加强
- 新增 ## 隐私保护规则 章节
- 统一联系方式：18616610601@163.com
- 人名使用代称（如王zc）

## v2.3.0 (2026-05-03)
### 🔒 隐私保护
- 添加隐私保护规则，禁止提供微信号/个人手机号/真实姓名
- 统一联系方式为邮箱 18616610601@163.com
- description 补充触发关键词

## v2.2.0 (2026-05-03)
### 📦 架构升级
- 整合免费版全部内容到Pro版
- 新增14个references模块（core_rules、emotion_support、upgrade_funnel等）
- 模块化拆分，降低单文件复杂度

## v2.1.0 (2026-04-01)
### ✨ 新功能
- 友好交互引导（开始/结束/升级提示）
- 文件保密提示（BP上传免责声明）
- 用户信息存档 + 会话简报生成

## v2.0.0 (2026-03-29)
### 🎉 首次发布
- 焕智AI-FA Skill Pro版 首次在ClawHub发布
- 支持6大核心模块：融资诊断、材料工坊、投资人雷达、谈判参谋、尽调护航、情绪支持
- 中文原生，专为中国创业者设计
