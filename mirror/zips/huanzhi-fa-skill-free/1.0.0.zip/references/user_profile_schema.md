# 用户画像模板

> **适用范围**：Fa.Pro V1免费版 + V4纯Token版 共享
>
> 首次对话时收集用户基础信息，后续对话基于画像调整语气和主动触达频率。

---

## 目录

1. [用户画像字段表](#一用户画像字段表)
2. [融资红线配置](#二融资红线配置)
3. [枚举值说明](#三枚举值说明)

---

## 一、用户画像字段表

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| founder_name | string | "" | 创始人姓名/花名 |
| company_name | string | "" | 公司名 |
| sector | string | "" | 赛道 |
| current_stage | enum | "" | 融资阶段：[天使/Pre-A/A/B/C+] |
| funding_experience | enum | "" | 融资经验：[首次/有经验/老司机] |
| support_style | enum | "" | 支持风格：[教练式/朋友式/导师式] |
| reminder_frequency | enum | "standard" | 提醒频率：[激进/标准/保守/被动] |
| do_not_disturb | string | "22:00-08:00" | 勿扰时段 |
| pipeline_count | int | 0 | Pipeline机构数量 |
| active_investors | int | 0 | 活跃投资人数量 |
| ts_received | int | 0 | 收到TS数量 |
| burnout_risk_score | int | 0 | Burnout风险评分 |

---

## 二、融资红线配置

| 红线项 | 默认值 | 说明 |
|--------|--------|------|
| no_veto_on_operations | true | 不接受日常经营否决权 |
| no_personal_guarantee | true | 不接受个人回购担保 |
| min_founder_control | "50%" | 最低创始人控制比例 |
| max_dilution | "30%" | 本轮最大稀释比例 |

---

## 三、枚举值说明

### current_stage（融资阶段）
- `天使` — 天使轮/种子轮
- `Pre-A` — Pre-A轮
- `A` — A轮
- `B` — B轮
- `C+` — C轮及以后

### funding_experience（融资经验）
- `首次` — 第一次融资，需要更多引导
- `有经验` — 有过融资经历
- `老司机` — 多次融资，熟悉流程

### support_style（支持风格）
- `教练式` — 引导式提问，帮助用户自己找到答案
- `朋友式` — 轻松平等，像朋友聊天
- `导师式` — 直接给建议，权威专业

### reminder_frequency（提醒频率）
- `激进` — 频繁主动触达，适合紧迫项目
- `标准` — 平衡频率，默认设置
- `保守` — 较少打扰，适合不喜欢被推送的用户
- `被动` — 完全不主动，等用户来找
