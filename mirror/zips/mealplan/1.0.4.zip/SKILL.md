---
name: MealPlan
description: "Plan weekly meals and auto-generate shopping lists for easier meal prep. Use when organizing dinners, building grocery lists, simplifying meal routines."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["meal","food","planning","diet","nutrition","cooking","health","weekly"]
categories: ["Health & Wellness", "Personal Management", "Productivity"]
---

# MealPlan

Productivity toolkit for planning, tracking, reviewing, and managing tasks and habits. MealPlan provides a complete productivity workflow — from adding items and planning ahead, through tracking progress, reviewing results, maintaining streaks, and generating reports. Each command logs timestamped entries for persistent history.

## Commands

| Command | Description |
|---------|-------------|
| `mealplan add <input>` | Add a new item or entry to your plan |
| `mealplan plan <input>` | Create or update a plan entry |
| `mealplan track <input>` | Track progress on a goal or task |
| `mealplan review <input>` | Review and reflect on completed work |
| `mealplan streak <input>` | Log streak or habit consistency data |
| `mealplan remind <input>` | Set or log a reminder |
| `mealplan prioritize <input>` | Prioritize tasks or items by importance |
| `mealplan archive <input>` | Archive completed or old entries |
| `mealplan tag <input>` | Tag entries with labels for organization |
| `mealplan timeline <input>` | Create timeline entries for project milestones |
| `mealplan report <input>` | Generate or log report data |
| `mealplan weekly-review <input>` | Conduct a weekly review — summarize progress |
| `mealplan stats` | Show summary statistics across all entry types |
| `mealplan export <fmt>` | Export all data (formats: json, csv, txt) |
| `mealplan search <term>` | Search across all logged entries |
| `mealplan recent` | Show the 20 most recent activity entries |
| `mealplan status` | Health check — version, data size, last activity |
| `mealplan help` | Show all available commands |
| `mealplan version` | Show version number |

Each command can be called without arguments to view recent entries for that type, or with arguments to save a new timestamped entry.

## Data Storage

All data is stored locally in `~/.local/share/mealplan/`:

- **Per-command logs**: `add.log`, `plan.log`, `track.log`, `review.log`, `streak.log`, `remind.log`, `prioritize.log`, `archive.log`, `tag.log`, `timeline.log`, `report.log`, `weekly-review.log`
- **Activity history**: `history.log` — unified log of all actions with timestamps
- **Exports**: `export.json`, `export.csv`, or `export.txt` — generated on demand

Each entry is stored as `YYYY-MM-DD HH:MM|<content>` for easy parsing and review.

## Requirements

- Bash 4.0+ (uses `set -euo pipefail`)
- Standard Unix utilities (`date`, `wc`, `du`, `grep`, `tail`, `head`, `cat`)
- No external API keys or network access needed
- Runs entirely offline with local file storage

## When to Use

1. **Meal planning and prep** — You're organizing your weekly meals, tracking what you've planned for each day, and want a log of your meal decisions.
2. **Habit tracking** — You want to track daily streaks, log reminders, and maintain consistency on goals like exercise, reading, or healthy eating.
3. **Weekly reviews** — You conduct weekly retrospectives and want to log your reflections, priorities, and action items in a searchable format.
4. **Project timeline management** — You're tracking milestones, tagging entries by project, and generating timeline views of your progress.
5. **Productivity auditing** — You want to review your activity history, search past entries, export data for analysis, and see summary statistics on how you've been spending your effort.

## Examples

```bash
# Add a meal to your plan
mealplan add "Monday breakfast: overnight oats with chia seeds and blueberries"

# Plan the week ahead
mealplan plan "Week 12: focus on high-protein meals, prep Sunday evening"

# Track a habit
mealplan track "Day 15 of no-sugar challenge — feeling more energy"

# Log a streak
mealplan streak "21-day meditation streak maintained"

# Set a reminder
mealplan remind "Buy groceries before 6pm Thursday"

# Prioritize tasks
mealplan prioritize "1. Meal prep Sunday 2. Gym Monday 3. Doctor appointment Tuesday"

# Tag an entry
mealplan tag "recipe:chicken-stir-fry category:dinner prep-time:30min"

# Archive old entries
mealplan archive "January meal plans — completed and reviewed"

# Create a timeline entry
mealplan timeline "March 15: Started keto plan | March 22: First weigh-in"

# Weekly review
mealplan weekly-review "Stuck to plan 5/7 days. Missed Thursday dinner prep. Improve: prep 2 meals Sunday."

# View recent plan entries
mealplan plan

# Search for a specific food or topic
mealplan search "chicken"

# Export everything as CSV
mealplan export csv

# Check overall stats
mealplan stats

# See recent activity
mealplan recent
```

## Output

All commands output to stdout. Results can be redirected:

```bash
mealplan stats > weekly-report.txt
mealplan export json
```

## Configuration

Set `MEALPLAN_DIR` environment variable to change the data directory. Default: `~/.local/share/mealplan/`

---
*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
