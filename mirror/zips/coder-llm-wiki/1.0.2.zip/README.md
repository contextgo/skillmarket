# coder-llm-wiki

面向代码项目的开发者 Wiki 维护 skill。

它用于把开发过程中的代码变更、模块规范、外部资料、技术概念和 ADR 沉淀为可持续维护的 wiki 资产，而不是去修改业务代码。

## 适用场景

适合这些请求：

- 记录一次重构、修复或功能改动
- 初始化或更新某个模块文档
- 归档技术文章、设计稿、会议纪要，并映射到当前代码
- 记录已经确认的架构决策
- 基于现有 wiki 回答开发问题，并检查 wiki 是否过期

不适合这些请求：

- 只是改业务代码，不需要知识沉淀
- 产出产品文档、运营文档、市场文案等非开发内容

## 文件结构

```text
SKILL.md
README.md
templates.md
```

## 默认约定

- 默认 wiki 根目录：`./docs/wiki`
- 默认代码目录：`./src`
- 默认原始资料目录：`./docs/raw`
- 这 3 个目录是动态配置，不是强制固定值
- 第一次在某个项目使用时，先询问用户：
  - 使用 skill 默认配置
  - 或使用当前项目作用域内 `AGENTS.md` / `CLAUDE.md` 等文档中的配置
- 如果用户选择项目文档配置，但文档里缺少某些目录定义，需要先确认是否回退到默认值
- 覆盖优先级：用户明确指令 > 当前作用域内的 `AGENTS.md` / `CLAUDE.md` > 默认约定

## 怎么使用

这个 skill 不依赖真实的斜杠命令。以下自然语言都应该触发它：

- `帮我记录这次订单状态机重构`
- `初始化 payment 模块文档`
- `把这篇 Redis 持久化文章归档进 wiki`
- `补一条缓存相关 ADR`
- `现在 payment 模块怎么接入`

如果宿主环境支持斜杠命令，也可以把这些意图理解为：

- `/change`
- `/module`
- `/ingest`
- `/query`
- `/lint`
- `/sync`

## 核心行为

### 1. `/change`

- 先收集背景、文件列表和可选 git 证据
- 生成 `changes/*.md`
- 同步相关 `modules/*.md`、`index.md`、`log.md`
- 强调代码路径、兼容性影响、测试跟进和待办

### 2. `/module`

- 基于真实代码刷新模块职责、入口接口、依赖、测试规范、性能约束
- 生成或更新 `modules/*.md`
- 模块边界不清时必须先问，不得猜测

### 3. `/ingest`

- 把外部资料映射回项目代码，而不是只写摘要
- 生成 `sources/*.md`
- 必要时更新 `concepts/*.md` 和相关 `modules/*.md`
- 只把已经确认的技术决策写成 ADR

## 开发者导向约束

这个 skill 会优先保留：

- 接口契约
- 模块依赖
- 测试要求
- 性能考量
- 兼容性与迁移信息
- 技术债和后续动作

它不会：

- 禁止修改 `code_root` 下业务代码（默认 `./src`）
- 删除历史变更记录
- 删除、覆盖或截断用户代码和非 wiki 项目文件
- 使用 `git reset --hard`、`git checkout --`、强推、`rm -rf` 等危险操作
- 把 diff 推断直接写成事实
- 在证据不足时自动创建 ADR

## 模板说明

页面模板在 `templates.md`。

包含五类页面：

- `change`
- `module`
- `source`
- `concept`
- `decision`

模板不仅有正文结构，也带了 canonical 链接示例，提醒后续要同步回链到：

- `modules/*.md`
- `concepts/*.md`
- `index.md`
- `log.md`

## 安装

### 方式一：本地安装（推荐）

1. 在本地 skill 目录创建 `coder-llm-wiki` 文件夹。
2. 复制以下 3 个文件到该目录：

- `SKILL.md`
- `README.md`
- `templates.md`

3. 重启或刷新你的 CLI skill 环境。
4. 用 skill 列表命令确认 `coder-llm-wiki` 已可用。

> 提示：本仓库里 `skills/llm-wiki/` 目录已经是完整可安装内容，安装时名称使用 `coder-llm-wiki`。

## 使用方式

安装后，当请求是“维护开发者 wiki”而不是“改业务代码”时触发此 skill。

常见触发语句：

- `帮我记录这次订单状态机重构`
- `初始化 payment 模块文档`
- `把这篇 Redis 持久化文章归档进 wiki`
- `补一条缓存相关 ADR`
- `现在 payment 模块怎么接入`

## 最小使用流程

1. 给出目标（change / module / ingest / query / lint / sync 任一意图）。
2. 第一次使用先确认目录配置来源（默认配置或项目文档配置）。
3. 提供必要上下文（改动文件、模块名、资料链接、已有 wiki 页面等）。
4. 让 skill 按 `SKILL.md` 和 `templates.md` 输出或更新对应页面。
5. 对超过 3 个代码文件或超过 3 个 wiki 页面的改动，先确认再批量写入。

## 验证清单

每次使用后建议快速检查：

- 页面类型是否正确（`changes/`、`modules/`、`sources/`、`concepts/`、`decisions/`）
- 是否补齐了 `index.md`、`log.md` 和相关回链
- `/query` 结果是否做了新旧代码/页面的新鲜度校验
- 是否严格遵守“只维护 wiki，不改业务代码”
