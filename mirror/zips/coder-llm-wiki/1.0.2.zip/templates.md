# coder-llm-wiki Templates

Use these templates as the default page skeletons. Keep the structure unless the user or project conventions explicitly require a change.

These templates define the page body. They do not replace the linking work required by `SKILL.md`: when you create one of these pages, also update the related module pages, concept pages, `index.md`, and `log.md` when the workflow calls for it.

## Change Template

```md
---
type: change
date: YYYY-MM-DD
scope: [module-a, module-b]
tags: [feature|bugfix|refactor]
related_commits: []
---

# 变更：简短标题

## 背景

## 改动摘要

## 证据来源

- 代码或提交证据：
- 背景来源（用户说明 / 文档 / issue）：

## 未确认项 / 假设

## 影响模块

## 技术决策

## 测试与验证

## 关联页面

- `[[modules/module-a]]`
- `[[modules/module-b]]`
- `index.md`
- `log.md`

## 待跟进
```

## Module Template

```md
---
type: module
status: active|deprecated|planned
owner: [owner]
created: YYYY-MM-DD
---

# 模块：模块名

## 一句话职责

## 核心入口

## 接口契约

## 依赖

## 相关概念

- `[[concepts/example-concept]]`

## 测试规范

## 性能考量

## 近期变更

## 关联页面

- `[[changes/example-change]]`
- `[[modules/dependency-module]]`
- `index.md`
- `log.md`

## 待决策 / 技术债
```

## Source Template

```md
---
type: source
date: YYYY-MM-DD
source_type: article|doc|meeting|design
urls: []
tags: []
---

# 来源：资料名

## 核心要点

## 与项目的关联

## 建议行动

## 关联页面

- `[[concepts/example-concept]]`
- `[[modules/example-module]]`
- `index.md`
- `log.md`
```

## Concept Template

```md
---
type: concept
aliases: []
---

# 概念：概念名

## 定义

## 在项目中的应用

## 相关模块

- `[[modules/example-module]]`

## 来源

- `[[sources/example-source]]`

## 关联页面

- `index.md`
- `log.md`
```

## Decision Template

```md
---
type: decision
status: accepted|superseded
date: YYYY-MM-DD
---

# ADR：决策标题

## 背景

## 备选方案

## 最终选择

## 后果

## 关联模块与变更

- `[[modules/example-module]]`
- `[[changes/example-change]]`

## 关联页面

- `index.md`
- `log.md`
```
