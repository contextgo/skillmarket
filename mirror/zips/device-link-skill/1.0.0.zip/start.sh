#!/bin/bash
# QClaw 设备互联 Skill 启动脚本
# SkillHub 标准启动脚本

# 进入脚本所在目录
cd "$(dirname "$0")"

# 设置编码
export PYTHONIOENCODING=utf-8
export LANG=C.UTF-8

# 安装依赖
echo "正在安装依赖库..."
pip3 install -r requirements.txt -q

# 启动Skill
echo "正在启动 QClaw 设备互联..."
python3 device_link_skill.py