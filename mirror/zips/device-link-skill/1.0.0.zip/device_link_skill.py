# -*- coding: utf-8 -*-
"""
设备互联 Skill - 安全局域网文件互传
功能：路由器局域网搭建 + 设备认证 + 加密文件传输
安全特性：内网隔离、临时验证码、MAC白名单、文件安全校验
"""
import os
import socket
import threading
import time
import random
from flask import Flask, request, jsonify, abort
from functools import wraps

# ==================== Skill 基础配置 ====================
SKILL_NAME = "设备互联"
VERSION = "1.0.0"


# ==================== 安全核心配置 ====================
SAFE_LAN_PREFIX = ("192.168.", "10.", "172.16.", "172.17.", "172.18.", "172.19.")
TEMP_AUTH_CODE = None
CODE_EXPIRE_TIME = 0
DEVICE_MAC_WHITELIST = set()
TRANSFER_DIR = "./QClaw_File_Transfer"
# 允许传输的文件类型
ALLOW_FILE_TYPES = {"jpg", "jpeg", "png", "gif", "pdf", "txt", "zip", "rar", "mp4", "mov", "docx", "xlsx", "pptx"}
# 禁止传输的危险文件
BLOCK_FILE_TYPES = {"exe", "bat", "cmd", "sh", "py", "apk", "iso", "dll", "bin", "php"}
# 安全口令（语音指令必须包含）
SAFE_PHRASE = "qclaw2026"
# 操作日志
OPERATION_LOG = []

# 初始化服务
app = Flask(__name__)
os.makedirs(TRANSFER_DIR, exist_ok=True)

# ==================== 安全访问装饰器 ====================
def local_network_only(func):
    """仅允许局域网IP访问"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        client_ip = request.remote_addr
        if not any(client_ip.startswith(prefix) for prefix in SAFE_LAN_PREFIX):
            OPERATION_LOG.append(f"[拦截] 公网IP尝试访问：{client_ip}")
            abort(403)
        return func(*args, **kwargs)
    return wrapper

def require_auth_code(func):
    """需要临时验证码验证"""
    @wraps(func)
    @local_network_only
    def wrapper(*args, **kwargs):
        code = request.headers.get("X-Auth-Code")
        if not code or code != TEMP_AUTH_CODE or time.time() > CODE_EXPIRE_TIME:
            OPERATION_LOG.append(f"[拦截] 验证码错误/过期：{request.remote_addr}")
            abort(401)
        return func(*args, **kwargs)
    return wrapper

# ==================== 传输服务接口 ====================
@app.route("/skill/device/auth", methods=["POST"])
@local_network_only
def device_auth():
    """设备认证接口"""
    mac = request.form.get("device_mac", "")
    code = request.form.get("auth_code", "")
    if code == TEMP_AUTH_CODE and time.time() < CODE_EXPIRE_TIME:
        DEVICE_MAC_WHITELIST.add(mac)
        OPERATION_LOG.append(f"[认证成功] 设备MAC：{mac}")
        return jsonify(status="success", msg="设备认证成功")
    return jsonify(status="fail", msg="认证失败"), 401

@app.route("/skill/file/upload", methods=["POST"])
@require_auth_code
def upload_file():
    """文件上传接口"""
    file = request.files.get("transfer_file")
    if not file:
        return jsonify(status="fail", msg="未选择文件"), 400

    # 文件后缀安全校验
    filename = file.filename
    if "." not in filename:
        return jsonify(status="fail", msg="不支持的文件类型"), 403
    ext = filename.rsplit(".", 1)[-1].lower()

    if ext in BLOCK_FILE_TYPES or ext not in ALLOW_FILE_TYPES:
        OPERATION_LOG.append(f"[拦截] 危险文件：{filename}")
        return jsonify(status="fail", msg="该文件类型禁止传输"), 403

    # 保存文件
    save_path = os.path.join(TRANSFER_DIR, filename)
    file.save(save_path)
    OPERATION_LOG.append(f"[传输成功] {filename}")
    return jsonify(status="success", msg="文件接收完成", path=save_path)

@app.route("/skill/file/list", methods=["GET"])
@require_auth_code
def get_file_list():
    """获取文件列表"""
    files = os.listdir(TRANSFER_DIR)
    return jsonify(files=files)

# ==================== QClaw 语音交互入口 ====================
class QClawDeviceLinkSkill:
    def __init__(self):
        self.running = False
        self.server_thread = None

    def start_server(self):
        """启动局域网传输服务"""
        if not self.server_thread or not self.server_thread.is_alive():
            self.server_thread = threading.Thread(
                target=app.run,
                kwargs={"host": "0.0.0.0", "port": 5201, "debug": False, "threaded": True},
                daemon=True
            )
            self.server_thread.start()
        self.running = True

    def execute(self, voice_command):
        """语音指令执行入口"""
        global TEMP_AUTH_CODE, CODE_EXPIRE_TIME

        # 安全口令校验
        if SAFE_PHRASE not in voice_command:
            return "⚠️ 请先说出正确的安全口令，才能使用设备互联功能"

        # 指令：打开设备互联
        if "打开设备互联" in voice_command or "启动设备互联" in voice_command:
            self.start_server()
            # 生成6位5分钟临时验证码
            TEMP_AUTH_CODE = f"{random.randint(100000, 999999)}"
            CODE_EXPIRE_TIME = time.time() + 300
            DEVICE_MAC_WHITELIST.clear()
            OPERATION_LOG.clear()

            local_ip = self.get_local_ip()
            return f"""✅ 设备互联已安全启动
局域网IP：{local_ip}
临时验证码：{TEMP_AUTH_CODE}
有效时间：5分钟
仅同一WiFi设备可连接"""

        # 指令：关闭设备互联
        elif "关闭设备互联" in voice_command or "停止设备互联" in voice_command:
            self.running = False
            TEMP_AUTH_CODE = None
            DEVICE_MAC_WHITELIST.clear()
            return "✅ 已关闭设备互联，所有连接已断开，验证码失效"

        # 指令：查看设备
        elif "设备列表" in voice_command or "连接设备" in voice_command:
            return f"📱 已认证设备：{len(DEVICE_MAC_WHITELIST)} 台"

        # 指令：传输日志
        elif "日志" in voice_command or "记录" in voice_command:
            if not OPERATION_LOG:
                return "📝 暂无操作日志"
            return "📝 最近10条记录：\n" + "\n".join(OPERATION_LOG[-10:])

        # 未知指令
        else:
            return "📌 支持指令：打开设备互联、关闭设备互联、设备列表、查看日志"

    def get_local_ip(self):
        """获取本机局域网IP"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"

# Skill 导出实例（QClaw 系统自动加载）
skill = QClawDeviceLinkSkill()