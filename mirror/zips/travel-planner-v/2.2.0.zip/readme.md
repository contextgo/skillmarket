# Travel Planner v2.2 - 智能旅行规划工具

## 版本说明

这是Travel Planner v2.2版本，修复了原始版本中的目的地解析错误，并增强了多项功能。

## 主要改进

### 修复的问题
1. **目的地解析错误**：原始版本在处理"沈阳到大连"时错误地识别为"兰州"
2. **API配置问题**：修复了高德地图API和GLM API的配置问题
3. **错误处理增强**：添加了更完善的错误处理机制
4. **文件生成优化**：改进了Excel和Word文件的生成逻辑

### 新增功能
1. **手动生成功能**：支持手动创建正确的旅行规划
2. **多格式输出**：支持Excel、Word、Markdown三种格式
3. **智能推荐**：基于用户兴趣提供个性化推荐
4. **输入验证**：增强的输入验证和错误提示

## 安装依赖

```bash
pip install -r requirements.txt
```

## 配置API密钥

编辑 `config.json` 文件，添加您的API密钥：

```json
{
  "amap_api_key": "您的高德地图API密钥",
  "glm_api_key": "您的GLM API密钥"
}
```

## 使用方法

### 基本用法

```bash
python main.py "从沈阳到大连3天3000元"
```

### 参数说明

- `input`: 旅行规划输入，格式为"从[出发地]到[目的地][天数][预算]"
- `--config`: 配置文件路径（默认：config.json）
- `--formats`: 输出格式（默认：excel, word, markdown）

### 输入格式示例

```bash
# 基本格式
python main.py "从沈阳到大连3天3000元"

# 其他格式
python main.py "沈阳到大连3天3000元"
python main.py "从沈阳去大连3天3000元"
python main.py "沈阳-大连3天3000元"
python main.py "沈阳 大连 3天 3000元"
```

### 指定输出格式

```bash
# 只生成Excel文件
python main.py "从沈阳到大连3天3000元" --formats excel

# 生成Word和Markdown文件
python main.py "从沈阳到大连3天3000元" --formats word markdown
```

## 输出文件

工具会生成以下格式的旅行规划文件：

- **Excel格式**: `沈阳到大连三天旅行规划_YYYYMMDD_HHMMSS.xlsx`
- **Word格式**: `沈阳到大连三天旅行规划_YYYYMMDD_HHMMSS.docx`
- **Markdown格式**: `沈阳到大连三天旅行规划_YYYYMMDD_HHMMSS.md`

## 文件内容

生成的旅行规划包含以下内容：

### 基本信息
- 出发地
- 目的地
- 旅行时间
- 预算
- 人数
- 最佳季节

### 行程安排
- 每日主题
- 详细行程
- 推荐景点
- 推荐美食
- 住宿建议

### 预算明细
- 交通费用
- 住宿费用
- 餐饮费用
- 门票费用
- 购物费用
- 总计

### 实用信息
- 最佳旅行时间
- 天气建议
- 交通方式
- 必备物品
- 注意事项

## 故障排除

### 常见问题

1. **导入错误**
   ```
   ImportError: No module named 'openpyxl'
   ```
   解决：安装依赖 `pip install -r requirements.txt`

2. **API密钥错误**
   ```
   错误：未配置高德地图API密钥
   ```
   解决：在config.json中添加正确的API密钥

3. **输入格式错误**
   ```
   输入格式错误，请使用类似：从沈阳到大连3天3000元
   ```
   解决：检查输入格式是否符合要求

### 获取帮助

```bash
python main.py --help
```

## 版本历史

### v2.1 (原始版本)
- 基础功能实现
- 支持多格式输出
- 存在目的地解析错误

### v2.2 (当前版本)
- ✅ 修复了目的地解析错误
- ✅ 改进了API配置
- ✅ 增强了错误处理
- ✅ 新增手动生成功能
- ✅ 优化了文件生成逻辑

## 技术支持

如有问题或建议，请联系开发者。