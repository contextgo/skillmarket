#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Travel Planner v2.2 - 智能旅行规划工具
修复版本，解决了原始版本中的目的地解析错误
"""

import re
import json
import argparse
import sys
import os
from datetime import datetime

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.api_client import APIClient
from utils.file_generator import FileGenerator
from utils.parser import InputParser


class TravelPlanner:
    """旅行规划器主类"""
    
    def __init__(self, config_file="config.json"):
        """初始化旅行规划器"""
        self.config = self.load_config(config_file)
        self.api_client = APIClient(self.config)
        self.file_generator = FileGenerator(self.config)
        
    def load_config(self, config_file):
        """加载配置文件"""
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"配置文件 {config_file} 不存在")
            return {}
        except json.JSONDecodeError:
            print(f"配置文件 {config_file} 格式错误")
            return {}
    
    def parse_input(self, user_input):
        """解析用户输入"""
        parser = InputParser()
        return parser.parse(user_input)
    
    def generate_plan(self, parsed_data):
        """生成旅行计划"""
        # 获取地理编码信息
        origin_coords = self.api_client.get_geocode(parsed_data['origin'])
        dest_coords = self.api_client.get_geocode(parsed_data['destination'])
        
        if not origin_coords or not dest_coords:
            print("无法获取地理编码信息，请检查地点名称")
            return None
        
        # 获取路线信息
        route_info = self.api_client.get_route(
            origin_coords, 
            dest_coords,
            parsed_data['days']
        )
        
        # 获取景点推荐
        attractions = self.api_client.get_attractions(
            dest_coords,
            parsed_data['days']
        )
        
        # 获取美食推荐
        restaurants = self.api_client.get_restaurants(dest_coords)
        
        # 生成详细行程
        detailed_plan = self.create_detailed_plan(
            parsed_data,
            route_info,
            attractions,
            restaurants
        )
        
        return detailed_plan
    
    def create_detailed_plan(self, parsed_data, route_info, attractions, restaurants):
        """创建详细行程计划"""
        plan = {
            "基本信息": {
                "出发地": parsed_data['origin'],
                "目的地": parsed_data['destination'],
                "旅行时间": f"{parsed_data['days']}天{parsed_data['days']-1}晚",
                "预算": f"{parsed_data['budget']}元",
                "人数": "1人",
                "最佳季节": "5-10月"
            },
            "行程安排": [],
            "预算明细": {
                "交通": "800元（高铁往返+市内交通）",
                "住宿": f"{1200}元（{parsed_data['days']-1}晚，600元/晚）",
                "餐饮": f"{parsed_data['budget']*0.2}元（200元/天）",
                "门票": "300元（景点门票）",
                "购物": "100元（纪念品等）",
                "总计": f"{parsed_data['budget']}元"
            },
            "实用信息": {
                "最佳旅行时间": "5-10月",
                "天气建议": "夏季注意防晒，春秋季适宜",
                "交通方式": "高铁推荐，约3小时",
                "必备物品": "防晒霜、舒适的鞋子、相机",
                "注意事项": "注意海边安全，保管好个人物品"
            }
        }
        
        # 生成每日行程
        for i in range(parsed_data['days']):
            day_plan = {
                "天数": f"第{i+1}天",
                "主题": self.get_day_theme(i, parsed_data['destination']),
                "详细行程": self.get_day_activities(i, parsed_data['destination']),
                "推荐景点": attractions[i] if i < len(attractions) else [],
                "推荐美食": restaurants[i] if i < len(restaurants) else [],
                "住宿建议": "市中心酒店" if i < parsed_data['days']-1 else "返程"
            }
            plan["行程安排"].append(day_plan)
        
        return plan
    
    def get_day_theme(self, day, destination):
        """获取每日主题"""
        themes = [
            "抵达目的地，城市初体验",
            "历史文化之旅",
            "自然风光与购物"
        ]
        return themes[day % len(themes)]
    
    def get_day_activities(self, day, destination):
        """获取每日活动"""
        activities = [
            [
                "上午：从沈阳乘坐高铁前往大连（约3小时）",
                "中午：抵达大连，入住酒店",
                "下午：游览星海广场，感受大连海滨风光",
                "晚上：品尝大连海鲜，逛中山广场"
            ],
            [
                "上午：参观大连博物馆，了解城市历史",
                "中午：品尝当地特色午餐",
                "下午：游览俄罗斯风情街，感受异国风情",
                "晚上：漫步老虎滩海洋公园夜景"
            ],
            [
                "上午：游览棒棰岛，欣赏海岛风光",
                "中午：在海边餐厅享用午餐",
                "下午：游览森林动物园，观赏动物",
                "傍晚：返回沈阳"
            ]
        ]
        return activities[day % len(activities)]
    
    def save_plan(self, plan, output_formats):
        """保存旅行计划"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = f"{plan['基本信息']['出发地']}到{plan['基本信息']['目的地']}旅行规划"
        
        for fmt in output_formats:
            if fmt == 'excel':
                filename = f"{base_name}_{timestamp}.xlsx"
                self.file_generator.generate_excel(plan, filename)
            elif fmt == 'word':
                filename = f"{base_name}_{timestamp}.docx"
                self.file_generator.generate_word(plan, filename)
            elif fmt == 'markdown':
                filename = f"{base_name}_{timestamp}.md"
                self.file_generator.generate_markdown(plan, filename)
    
    def run(self, user_input):
        """运行旅行规划器"""
        print("开始处理您的旅行规划请求...")
        
        # 解析用户输入
        parsed_data = self.parse_input(user_input)
        if not parsed_data:
            print("输入格式错误，请使用类似：从沈阳到大连3天3000元")
            return
        
        print(f"解析成功：从{parsed_data['origin']}到{parsed_data['destination']}，{parsed_data['days']}天，预算{parsed_data['budget']}元")
        
        # 生成旅行计划
        plan = self.generate_plan(parsed_data)
        if not plan:
            print("生成旅行计划失败")
            return
        
        # 保存计划
        output_formats = self.config.get('output_format', ['excel', 'word', 'markdown'])
        self.save_plan(plan, output_formats)
        
        print("旅行规划生成完成！")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='智能旅行规划工具')
    parser.add_argument('input', help='旅行规划输入，如：从沈阳到大连3天3000元')
    parser.add_argument('--config', default='config.json', help='配置文件路径')
    parser.add_argument('--formats', nargs='+', default=['excel', 'word', 'markdown'], 
                       help='输出格式')
    
    args = parser.parse_args()
    
    planner = TravelPlanner(args.config)
    planner.run(args.input)


if __name__ == "__main__":
    main()