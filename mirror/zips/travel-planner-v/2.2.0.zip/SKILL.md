# SKILL.md - Travel Planner v2.2

## 简介

**travel-planner-v2.2** 是一个智能旅行规划工具，可根据用户的输入（出发地、目的地、天数、预算）自动生成完整的多格式旅行规划文件。

主要功能：
- 智能解析输入（支持多种格式：`从沈阳到大连3天3000元`、`沈阳-大连3天3000元`等）
- 生成 Excel、Word、Markdown 三种格式的旅行规划文档
- 包含行程安排、预算明细、景点推荐、美食推荐、实用信息等完整内容

---

## 触发场景

当用户提到以下需求时使用此技能：

- "帮我规划一次旅行"
- "生成旅行攻略"
- "制定旅行行程"
- "做一个从XX到XX的旅行规划"
- 任何涉及旅行规划、行程安排、预算规划的需求

---

## 文件地址

```
C:\Users\贾大卫\.openclaw-autoclaw\agents\travel-planner-v22\workspace\temp_extract\travel-planner-v2.2\
```

项目结构：
```
travel-planner-v2.2/
├── main.py              # 主程序入口
├── config.json          # 配置文件
├── requirements.txt     # Python 依赖
├── readme.md           # 项目说明文档
├── SKILL.md            # 本技能说明文件
├── output/             # 输出目录（生成的规划文件存放位置）
└── utils/
    ├── __init__.py
    ├── api_client.py    # API 客户端（高德地图、GLM）
    ├── file_generator.py # 文件生成器（Excel/Word/Markdown）
    └── parser.py        # 输入解析器
```

---

## 使用方法

### 1. 安装依赖

```bash
cd "C:\Users\贾大卫\.openclaw-autoclaw\agents\travel-planner-v22\workspace\temp_extract\travel-planner-v2.2"
pip install -r requirements.txt
```

**依赖包：**
- `openpyxl` >= 3.0.0（Excel 文件生成）
- `python-docx` >= 0.8.11（Word 文件生成）
- `requests` >= 2.25.0（API 请求）

### 2. 配置 API 密钥（可选）

编辑 `config.json`，填入高德地图和 GLM 的 API 密钥：

```json
{
  "amap_api_key": "您的高德地图API密钥",
  "glm_api_key": "您的GLM API密钥",
  "output_format": ["excel", "word", "markdown"],
  "output_dir": "./output"
}
```

> 注意：如不配置 API 密钥，工具将使用内置的模拟数据运行，仍可生成规划文件。

### 3. 运行程序

**基本用法：**
```bash
python main.py "从沈阳到大连3天3000元"
```

**指定输出格式：**
```bash
# 只生成 Excel
python main.py "沈阳到大连3天3000元" --formats excel

# 生成 Word 和 Markdown
python main.py "沈阳到大连3天3000元" --formats word markdown
```

**指定配置文件：**
```bash
python main.py "从沈阳到大连3天3000元" --config config.json
```

### 4. 输入格式示例

```
从沈阳到大连3天3000元
沈阳到大连3天3000元
从沈阳去大连3天3000元
沈阳-大连3天3000元
沈阳 大连 3天 3000元
```

### 5. 输出文件

生成的规划文件位于 `output/` 目录，文件名格式：
- Excel: `出发地到目的地旅行规划_YYYYMMDD_HHMMSS.xlsx`
- Word: `出发地到目的地旅行规划_YYYYMMDD_HHMMSS.docx`
- Markdown: `出发地到目的地旅行规划_YYYYMMDD_HHMMSS.md`

---

## 生成内容

旅行规划包含以下章节：

### 基本信息
- 出发地、目的地
- 旅行时间（X天X晚）
- 预算、人数、最佳季节

### 行程安排（按天）
- 每日主题
- 详细行程（上下午活动安排）
- 推荐景点
- 推荐美食
- 住宿建议

### 预算明细
- 交通、住宿、餐饮、门票、购物费用分解
- 总计

### 实用信息
- 最佳旅行时间、天气建议
- 交通方式、必备物品、注意事项

---

## 注意事项

1. **天数范围**：支持 1-30 天的行程规划
2. **预算范围**：支持 100-100,000 元的预算
3. **出发地≠目的地**：两者不能相同
4. **无 API 密钥时**：使用内置模拟数据，可正常生成文件（景点/美食数据为大连默认值）
5. **Python 版本**：需要 Python 3.x 环境
