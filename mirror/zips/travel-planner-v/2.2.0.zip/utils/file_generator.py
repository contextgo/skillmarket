#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文件生成器模块
生成Excel、Word和Markdown格式的旅行规划文件
"""

import os
import json
from datetime import datetime
from typing import Dict, List


class FileGenerator:
    """文件生成器类"""
    
    def __init__(self, config: Dict):
        """初始化文件生成器"""
        self.config = config
        self.output_dir = config.get('output_dir', './output')
        
        # 确保输出目录存在
        os.makedirs(self.output_dir, exist_ok=True)
    
    def generate_excel(self, plan: Dict, filename: str) -> str:
        """生成Excel文件"""
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill
            from openpyxl.utils import get_column_letter
            
            # 创建工作簿
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "旅行规划"
            
            # 设置样式
            header_font = Font(name='微软雅黑', bold=True, size=12)
            header_fill = PatternFill(start_color='CCE5FF', end_color='CCE5FF', fill_type='solid')
            
            # 写入基本信息
            row = 1
            cell = ws.cell(row=row, column=1, value=plan['基本信息']['出发地'] + "到" + plan['基本信息']['目的地'] + "旅行规划")
            cell.font = Font(name='微软雅黑', bold=True, size=16)
            row += 2
            
            cell = ws.cell(row=row, column=1, value="基本信息")
            cell.font = header_font
            cell.fill = header_fill
            row += 1
            
            for key, value in plan['基本信息'].items():
                cell = ws.cell(row=row, column=1, value=key)
                cell.font = header_font
                ws.cell(row=row, column=2, value=value)
                row += 1
            
            row += 1
            
            # 写入行程安排
            cell = ws.cell(row=row, column=1, value="行程安排")
            cell.font = header_font
            cell.fill = header_fill
            row += 1
            
            for day in plan['行程安排']:
                # 天数和主题
                cell = ws.cell(row=row, column=1, value=day['天数'])
                cell.font = header_font
                ws.cell(row=row, column=2, value=day['主题'])
                row += 1
                
                # 详细行程
                cell = ws.cell(row=row, column=1, value="详细行程")
                cell.font = header_font
                row += 1
                for item in day['详细行程']:
                    ws.cell(row=row, column=2, value=f"• {item}")
                    row += 1
                
                # 推荐景点
                cell = ws.cell(row=row, column=1, value="推荐景点")
                cell.font = header_font
                row += 1
                for item in day['推荐景点']:
                    ws.cell(row=row, column=2, value=f"• {item}")
                    row += 1
                
                # 推荐美食
                cell = ws.cell(row=row, column=1, value="推荐美食")
                cell.font = header_font
                row += 1
                for item in day['推荐美食']:
                    ws.cell(row=row, column=2, value=f"• {item}")
                    row += 1
                
                # 住宿建议
                cell = ws.cell(row=row, column=1, value="住宿建议")
                cell.font = header_font
                ws.cell(row=row, column=2, value=day['住宿建议'])
                row += 2
            
            # 写入预算明细
            cell = ws.cell(row=row, column=1, value="预算明细")
            cell.font = header_font
            cell.fill = header_fill
            row += 1
            
            for key, value in plan['预算明细'].items():
                cell = ws.cell(row=row, column=1, value=key)
                cell.font = header_font
                ws.cell(row=row, column=2, value=value)
                row += 1
            
            row += 1
            
            # 写入实用信息
            cell = ws.cell(row=row, column=1, value="实用信息")
            cell.font = header_font
            cell.fill = header_fill
            row += 1
            
            for key, value in plan['实用信息'].items():
                cell = ws.cell(row=row, column=1, value=key)
                cell.font = header_font
                ws.cell(row=row, column=2, value=value)
                row += 1
            
            # 调整列宽
            for col in range(1, 3):
                ws.column_dimensions[get_column_letter(col)].width = 40
            
            # 保存文件
            filepath = os.path.join(self.output_dir, filename)
            wb.save(filepath)
            return filepath
            
        except ImportError:
            raise ImportError("缺少openpyxl库，无法生成Excel文件")
        except Exception as e:
            raise Exception(f"生成Excel文件失败: {e}")
    
    def generate_word(self, plan: Dict, filename: str) -> str:
        """生成Word文件"""
        try:
            from docx import Document
            from docx.shared import Pt, RGBColor
            from docx.enum.text import WD_ALIGN_PARAGRAPH
            
            # 创建文档
            doc = Document()
            
            # 标题
            title = doc.add_heading(plan['基本信息']['出发地'] + "到" + plan['基本信息']['目的地'] + "旅行规划", level=1)
            title.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # 基本信息
            doc.add_heading("基本信息", level=2)
            table = doc.add_table(rows=len(plan['基本信息']) + 1, cols=2)
            table.style = 'Table Grid'
            
            # 表头
            hdr_cells = table.rows[0].cells
            hdr_cells[0].text = "项目"
            hdr_cells[1].text = "详情"
            
            # 内容
            for i, (key, value) in enumerate(plan['基本信息'].items()):
                row_cells = table.rows[i + 1].cells
                row_cells[0].text = key
                row_cells[1].text = value
            
            # 行程安排
            doc.add_heading("行程安排", level=2)
            
            for day in plan['行程安排']:
                # 天数和主题
                doc.add_heading(day['天数'] + "：" + day['主题'], level=3)
                
                # 详细行程
                doc.add_heading("详细行程", level=4)
                for item in day['详细行程']:
                    doc.add_paragraph(f"• {item}")
                
                # 推荐景点
                doc.add_heading("推荐景点", level=4)
                for item in day['推荐景点']:
                    doc.add_paragraph(f"• {item}")
                
                # 推荐美食
                doc.add_heading("推荐美食", level=4)
                for item in day['推荐美食']:
                    doc.add_paragraph(f"• {item}")
                
                # 住宿建议
                doc.add_heading("住宿建议", level=4)
                doc.add_paragraph(day['住宿建议'])
                
                doc.add_paragraph("")  # 空行
            
            # 预算明细
            doc.add_heading("预算明细", level=2)
            budget_table = doc.add_table(rows=len(plan['预算明细']) + 1, cols=2)
            budget_table.style = 'Table Grid'
            
            # 表头
            hdr_cells = budget_table.rows[0].cells
            hdr_cells[0].text = "项目"
            hdr_cells[1].text = "费用"
            
            # 内容
            for i, (key, value) in enumerate(plan['预算明细'].items()):
                row_cells = budget_table.rows[i + 1].cells
                row_cells[0].text = key
                row_cells[1].text = value
            
            # 实用信息
            doc.add_heading("实用信息", level=2)
            for key, value in plan['实用信息'].items():
                doc.add_paragraph(f"**{key}：** {value}")
            
            # 页脚
            footer = doc.add_paragraph()
            footer.add_run(f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}").italic = True
            footer.add_run(f" | 版本：v2.2").italic = True
            
            # 保存文件
            filepath = os.path.join(self.output_dir, filename)
            doc.save(filepath)
            return filepath
            
        except ImportError:
            raise ImportError("缺少python-docx库，无法生成Word文件")
        except Exception as e:
            raise Exception(f"生成Word文件失败: {e}")
    
    def generate_markdown(self, plan: Dict, filename: str) -> str:
        """生成Markdown文件"""
        try:
            # 创建Markdown内容
            md_content = f"""# {plan['基本信息']['出发地']}到{plan['基本信息']['目的地']}旅行规划

## 基本信息

| 项目 | 详情 |
|------|------|
"""
            
            for key, value in plan['基本信息'].items():
                md_content += f"| {key} | {value} |\n"
            
            md_content += "\n## 行程安排\n"
            
            for day in plan['行程安排']:
                md_content += f"\n### {day['天数']}：{day['主题']}\n\n"
                
                md_content += "**详细行程：**\n"
                for item in day['详细行程']:
                    md_content += f"- {item}\n"
                
                md_content += "\n**推荐景点：**\n"
                for item in day['推荐景点']:
                    md_content += f"- {item}\n"
                
                md_content += "\n**推荐美食：**\n"
                for item in day['推荐美食']:
                    md_content += f"- {item}\n"
                
                md_content += f"\n**住宿建议：** {day['住宿建议']}\n\n"
            
            md_content += "## 预算明细\n\n"
            
            md_content += "| 项目 | 费用 |\n"
            md_content += "|------|------|\n"
            
            for key, value in plan['预算明细'].items():
                md_content += f"| {key} | {value} |\n"
            
            md_content += "\n## 实用信息\n\n"
            
            for key, value in plan['实用信息'].items():
                md_content += f"- **{key}：** {value}\n"
            
            md_content += f"\n---\n*生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n*版本：v2.2*\n"
            
            # 保存文件
            filepath = os.path.join(self.output_dir, filename)
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(md_content)
            
            return filepath
            
        except Exception as e:
            raise Exception(f"生成Markdown文件失败: {e}")
    
    def generate_all_formats(self, plan: Dict, base_filename: str) -> Dict[str, str]:
        """生成所有格式的文件"""
        results = {}
        
        # 生成Excel文件
        excel_filename = f"{base_filename}.xlsx"
        try:
            results['excel'] = self.generate_excel(plan, excel_filename)
        except Exception as e:
            print(f"生成Excel文件失败: {e}")
        
        # 生成Word文件
        word_filename = f"{base_filename}.docx"
        try:
            results['word'] = self.generate_word(plan, word_filename)
        except Exception as e:
            print(f"生成Word文件失败: {e}")
        
        # 生成Markdown文件
        md_filename = f"{base_filename}.md"
        try:
            results['markdown'] = self.generate_markdown(plan, md_filename)
        except Exception as e:
            print(f"生成Markdown文件失败: {e}")
        
        return results