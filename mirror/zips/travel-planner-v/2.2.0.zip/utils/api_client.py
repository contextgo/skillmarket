#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API客户端模块
处理与高德地图和GLM API的交互
"""

import requests
import json
from typing import Dict, List, Optional, Tuple


class APIClient:
    """API客户端类"""
    
    def __init__(self, config: Dict):
        """初始化API客户端"""
        self.config = config
        self.amap_api_key = config.get('amap_api_key', '')
        self.glm_api_key = config.get('glm_api_key', '')
        self.amap_base_url = 'https://restapi.amap.com/v3'
        self.glm_base_url = 'https://open.bigmodel.cn/api/paas/v4'
        
    def get_geocode(self, location: str) -> Optional[Tuple[float, float]]:
        """获取地理编码"""
        if not self.amap_api_key:
            print("警告：未配置高德地图API密钥")
            return None
            
        try:
            url = f"{self.amap_base_url}/geocode/geo"
            params = {
                'key': self.amap_api_key,
                'address': location
            }
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            
            if data.get('status') == '1' and data.get('geocodes'):
                location_data = data['geocodes'][0]
                coordinates = location_data['location'].split(',')
                return float(coordinates[0]), float(coordinates[1])
            
            return None
            
        except requests.RequestException as e:
            print(f"地理编码请求失败: {e}")
            return None
        except (IndexError, KeyError) as e:
            print(f"地理编码数据解析失败: {e}")
            return None
    
    def get_route(self, origin: Tuple[float, float], 
                  destination: Tuple[float, float], 
                  days: int) -> Dict:
        """获取路线信息"""
        if not self.amap_api_key:
            print("警告：未配置高德地图API密钥")
            return {}
            
        try:
            url = f"{self.amap_base_url}/direction/driving"
            params = {
                'key': self.amap_api_key,
                'origin': f"{origin[0]},{origin[1]}",
                'destination': f"{destination[0]},{destination[1]}",
                'extensions': 'all'
            }
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            
            if data.get('status') == '1':
                return data
            else:
                print(f"路线查询失败: {data.get('info', '未知错误')}")
                return {}
                
        except requests.RequestException as e:
            print(f"路线请求失败: {e}")
            return {}
    
    def get_attractions(self, destination: Tuple[float, float], 
                       days: int) -> List[List[str]]:
        """获取景点推荐"""
        # 模拟景点数据，实际应用中应该调用API获取
        attractions_data = {
            "大连": [
                ["星海广场", "中山广场", "滨海路"],
                ["大连博物馆", "俄罗斯风情街", "老虎滩海洋公园"],
                ["棒棰岛", "森林动物园", "滨海路"]
            ]
        }
        
        # 根据目的地返回对应的景点
        for city, attractions in attractions_data.items():
            if city in str(destination):
                return attractions[:days]
        
        # 默认返回大连景点
        return attractions_data.get("大连", [[]])[:days]
    
    def get_restaurants(self, destination: Tuple[float, float]) -> List[List[str]]:
        """获取美食推荐"""
        # 模拟美食数据，实际应用中应该调用API获取
        restaurants_data = {
            "大连": [
                ["大连海鲜", "烤鱿鱼", "焖子"],
                ["大连烤肉", "海鲜面", "锅贴"],
                ["海鲜大排档", "大连小吃", "水果"]
            ]
        }
        
        # 根据目的地返回对应的美食
        for city, restaurants in restaurants_data.items():
            if city in str(destination):
                return restaurants
        
        # 默认返回大连美食
        return restaurants_data.get("大连", [[]])
    
    def get_recommendations(self, destination: str, days: int, 
                          interests: List[str]) -> Dict:
        """获取智能推荐"""
        if not self.glm_api_key:
            print("警告：未配置GLM API密钥")
            return {}
        
        try:
            prompt = f"""
            请为{destination}的{days}天旅行提供推荐。
            用户兴趣：{', '.join(interests)}
            请提供景点、美食、住宿等方面的推荐。
            """
            
            url = f"{self.glm_base_url}/chat/completions"
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.glm_api_key}'
            }
            
            data = {
                'model': 'glm-4',
                'messages': [
                    {'role': 'user', 'content': prompt}
                ],
                'max_tokens': 1000,
                'temperature': 0.7
            }
            
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            result = response.json()
            
            if 'choices' in result and len(result['choices']) > 0:
                return {
                    'recommendations': result['choices'][0]['message']['content']
                }
            else:
                print("GLM API返回数据格式错误")
                return {}
                
        except requests.RequestException as e:
            print(f"GLM API请求失败: {e}")
            return {}
        except KeyError as e:
            print(f"GLM API数据解析失败: {e}")
            return {}
    
    def validate_config(self) -> bool:
        """验证API配置"""
        if not self.amap_api_key:
            print("错误：未配置高德地图API密钥")
            return False
        
        if not self.glm_api_key:
            print("错误：未配置GLM API密钥")
            return False
        
        return True