#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
输入解析器模块
解析用户输入的旅行规划请求
"""

import re
from typing import Dict, Optional, List


class InputParser:
    """输入解析器类"""
    
    def __init__(self):
        """初始化输入解析器"""
        # 正则表达式模式
        self.patterns = [
            # 从沈阳到大连3天3000元
            r'从(.+?)到(.+?)(\d+)天(\d+)元',
            # 沈阳到大连3天3000元
            r'(.+?)到(.+?)(\d+)天(\d+)元',
            # 从沈阳去大连3天3000元
            r'从(.+?)去(.+?)(\d+)天(\d+)元',
            # 沈阳去大连3天3000元
            r'(.+?)去(.+?)(\d+)天(\d+)元',
            # 沈阳-大连3天3000元
            r'(.+?)-(.+?)(\d+)天(\d+)元',
            # 沈阳 大连 3天 3000元
            r'(.+?)\s+(.+?)\s+(\d+)天\s+(\d+)元',
        ]
        
        # 城市别名映射
        self.city_aliases = {
            '沈阳': ['沈阳', '沈', 'shenyang'],
            '大连': ['大连', '连', 'dalian'],
            '北京': ['北京', '京', 'beijing'],
            '上海': ['上海', '沪', 'shanghai'],
            '广州': ['广州', '穗', 'guangzhou'],
            '深圳': ['深圳', '深', 'shenzhen'],
            '杭州': ['杭州', '杭', 'hangzhou'],
            '南京': ['南京', '宁', 'nanjing'],
            '成都': ['成都', '蓉', 'chengdu'],
            '西安': ['西安', '长安', 'xian'],
        }
    
    def parse(self, user_input: str) -> Optional[Dict]:
        """
        解析用户输入
        
        Args:
            user_input: 用户输入字符串
            
        Returns:
            解析后的数据字典，包含origin, destination, days, budget
            如果解析失败返回None
        """
        # 清理输入
        user_input = user_input.strip()
        
        # 尝试各种模式
        for pattern in self.patterns:
            match = re.search(pattern, user_input, re.IGNORECASE)
            if match:
                groups = match.groups()
                
                # 根据模式确定组的位置
                if len(groups) == 4:
                    origin, destination, days, budget = groups
                elif len(groups) == 3:
                    # 如果只有3个组，可能是天数和预算合并了
                    origin, destination, days_budget = groups
                    # 尝试分离天数和预算
                    days_budget_match = re.search(r'(\d+)[天日](\d+)[元块]', days_budget)
                    if days_budget_match:
                        days, budget = days_budget_match.groups()
                    else:
                        continue
                else:
                    continue
                
                # 清理和验证数据
                origin = self.clean_city_name(origin)
                destination = self.clean_city_name(destination)
                days = self.validate_days(days)
                budget = self.validate_budget(budget)
                
                if origin and destination and days and budget:
                    return {
                        'origin': origin,
                        'destination': destination,
                        'days': int(days),
                        'budget': int(budget)
                    }
        
        # 如果所有模式都失败，尝试更简单的解析
        return self.simple_parse(user_input)
    
    def clean_city_name(self, city_name: str) -> str:
        """
        清理城市名称
        
        Args:
            city_name: 原始城市名称
            
        Returns:
            清理后的标准城市名称
        """
        city_name = city_name.strip()
        
        # 检查城市别名
        for standard_name, aliases in self.city_aliases.items():
            if city_name in aliases:
                return standard_name
        
        # 如果不是已知城市，返回原始名称
        return city_name
    
    def validate_days(self, days_str: str) -> Optional[int]:
        """
        验证天数
        
        Args:
            days_str: 天数字符串
            
        Returns:
            验证后的天数，如果无效返回None
        """
        try:
            days = int(days_str)
            if 1 <= days <= 30:  # 合理的天数范围
                return days
            else:
                return None
        except ValueError:
            return None
    
    def validate_budget(self, budget_str: str) -> Optional[int]:
        """
        验证预算
        
        Args:
            budget_str: 预算字符串
            
        Returns:
            验证后的预算，如果无效返回None
        """
        try:
            # 移除可能的货币符号和逗号
            budget_str = re.sub(r'[^\d]', '', budget_str)
            budget = int(budget_str)
            
            # 合理的预算范围
            if 100 <= budget <= 100000:
                return budget
            else:
                return None
        except ValueError:
            return None
    
    def simple_parse(self, user_input: str) -> Optional[Dict]:
        """
        简单解析方法，用于处理复杂的输入格式
        
        Args:
            user_input: 用户输入字符串
            
        Returns:
            解析后的数据字典，如果解析失败返回None
        """
        # 尝试提取关键信息
        import re
        
        # 提取出发地
        origin_patterns = [
            r'从(.+?)到',
            r'(.+?)到',
            r'从(.+?)去',
            r'(.+?)去',
        ]
        
        origin = None
        for pattern in origin_patterns:
            match = re.search(pattern, user_input)
            if match:
                origin = self.clean_city_name(match.group(1))
                break
        
        # 提取目的地
        dest_patterns = [
            r'到(.+?)(?:\d+天|\d+元|$)',
            r'去(.+?)(?:\d+天|\d+元|$)',
            r'(.+?)(?:\d+天|\d+元|$)',
        ]
        
        destination = None
        for pattern in dest_patterns:
            match = re.search(pattern, user_input)
            if match:
                dest = match.group(1)
                # 确保这不是天数或预算
                if not re.match(r'\d+', dest):
                    destination = self.clean_city_name(dest)
                    break
        
        # 提取天数
        days = None
        days_match = re.search(r'(\d+)[天日]', user_input)
        if days_match:
            days = self.validate_days(days_match.group(1))
        
        # 提取预算
        budget = None
        budget_match = re.search(r'(\d+)[元块]', user_input)
        if budget_match:
            budget = self.validate_budget(budget_match.group(1))
        
        # 如果有足够的信息，返回结果
        if origin and destination and days and budget:
            return {
                'origin': origin,
                'destination': destination,
                'days': int(days),
                'budget': int(budget)
            }
        
        return None
    
    def validate_input(self, parsed_data: Dict) -> bool:
        """
        验证解析后的数据
        
        Args:
            parsed_data: 解析后的数据字典
            
        Returns:
            如果数据有效返回True，否则返回False
        """
        required_fields = ['origin', 'destination', 'days', 'budget']
        
        # 检查必需字段
        for field in required_fields:
            if field not in parsed_data:
                return False
        
        # 检查字段值
        if not isinstance(parsed_data['origin'], str) or not parsed_data['origin']:
            return False
        
        if not isinstance(parsed_data['destination'], str) or not parsed_data['destination']:
            return False
        
        if not isinstance(parsed_data['days'], int) or not (1 <= parsed_data['days'] <= 30):
            return False
        
        if not isinstance(parsed_data['budget'], int) or not (100 <= parsed_data['budget'] <= 100000):
            return False
        
        # 检查出发地和目的地是否相同
        if parsed_data['origin'] == parsed_data['destination']:
            return False
        
        return True
    
    def get_examples(self) -> List[str]:
        """
        获取输入示例
        
        Returns:
            输入示例列表
        """
        return [
            "从沈阳到大连3天3000元",
            "沈阳到大连3天3000元",
            "从沈阳去大连3天3000元",
            "沈阳去大连3天3000元",
            "沈阳-大连3天3000元",
            "沈阳 大连 3天 3000元",
        ]
    
    def get_help(self) -> str:
        """
        获取帮助信息
        
        Returns:
            帮助信息字符串
        """
        examples = "\n".join(f"  - {example}" for example in self.get_examples())
        return f"""
旅行规划输入格式说明：

支持的格式：
{examples}

参数说明：
- 出发地：城市名称，如"沈阳"、"北京"等
- 目的地：城市名称，如"大连"、"上海"等
- 天数：旅行天数，1-30天
- 预算：旅行预算，100-100000元

注意：
- 出发地和目的地不能相同
- 天数必须在1-30天之间
- 预算必须在100-100000元之间
"""