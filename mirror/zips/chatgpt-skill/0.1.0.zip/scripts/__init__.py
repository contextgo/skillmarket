"""ChatGPT skill scripts package."""
