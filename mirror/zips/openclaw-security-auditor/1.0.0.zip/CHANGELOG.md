# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0] - 2025-02-XX

### Added

- Initial release
- 15+ security checks
- AI-powered analysis
- Risk scoring
- Detailed fix instructions
- Privacy-focused design
