---
name: automation-task-share
description: "自动化任务分享工具 - 把已有自动化任务序列化成 JSON 发给协作方；协作方把 JSON 贴回来，一键创建（支持批量）。关键词：分享自动化、分享定时任务、导出/导入自动化、协作方创建自动化"
version: "1.0.0"
author: "CodeBuddy AI"
created: "2026-05-06"
updated: "2026-05-06"
---

# Automation Task Share

> 把已有自动化任务序列化成一段 JSON 给协作方；协作方把 JSON 贴回来，调用 `automation_update mode=create` 一键创建（支持批量）。
>

## When to Use

- 导出（发送方）："分享 / 导出某个或全部自动化任务给同事"
- 导入（接收方）：用户消息中**贴出符合下文字段约定的 JSON**（object 或数组）且语境是"创建任务"

## When NOT to Use

- 新建一个全新任务（无来源 JSON） → 直接调用 `automation_update`
- 查看 / 编辑 / 删除已有任务 → 直接调用 `automation_update`

## Core Principles

1. **创建走工具**：协作方导入时**必须**调用 `automation_update mode=create`，严禁直接写 `automation.toml` 或调任何 API。
2. **剥离个人化字段**：`id` / `cwds` / `status` / `modelId` 永不写入分享 JSON，由协作方自行指定。
3. **导入须确认**：先展示摘要 + 默认当前工作空间创建。
4. **批量天然支持**：单任务是 object，批量是数组，无任何额外包装。

## 分享 JSON 格式

字段对齐 `automation_update view` 返回值，只保留：

| 字段 | 必填 | 说明 |
|------|------|------|
| `name` | ✅ | 任务名称 |
| `prompt` | ✅ | 执行提示词（多行用 `\n`） |
| `scheduleType` | ✅ | `recurring` / `once` |
| `rrule` | recurring 必填 | 如 `FREQ=DAILY;BYHOUR=21;BYMINUTE=0` |
| `scheduledAt` | once 必填 | ISO 8601 |
| `validFrom` / `validUntil` | 源任务有则带 | YYYY-MM-DD 或 ISO 8601 |

**严禁**写入：`id` / `cwds` / `status` / `modelId` / `nextRunAt` / `created_at` / `updated_at`。

单任务：

```json
{
  "name": "每日日报提醒",
  "prompt": "提醒用户写日报...",
  "scheduleType": "recurring",
  "rrule": "FREQ=DAILY;BYHOUR=21;BYMINUTE=0"
}
```

批量任务（直接是数组）：

```json
[
  { "name": "...", "prompt": "...", "scheduleType": "recurring", "rrule": "..." },
  { "name": "...", "prompt": "...", "scheduleType": "once", "scheduledAt": "..." }
]
```

## 工作流

### 导出（发送方）

1. **定位**：用户给名称 / 关键词 → `automation_update mode=list` 找 id；用户说"全部分享" → 用 list 拿全部 id
2. **取详情**：对每个 id 调 `automation_update mode=view --id <id>`
3. **组装 JSON**：从返回的 `automation` 中只复制【格式表】列出的字段，**严禁**带 `id` / `cwds` / `status` / `modelId`
4. **敏感扫描**：扫 `prompt`，命中以下任一即先告知并请求用户确认后再输出：
   - 凭据：`password` / `token` / `secret` / `cookie` / `api_key` / `access_key` / `private_key` / `Bearer ` / `密码` / `密钥` / `凭据`
   - 个人信息：邮箱 / 11 位手机号 / 18 位身份证
5. **交付**：用代码块呈现 JSON，提醒用户告诉协作方"导入时需要选一个 workspace 作为 cwd"

### 导入（接收方）

1. **解析**：从消息提取 JSON；object → 单任务，数组 → 批量
2. **校验**：每项必须有 `name` / `prompt` / `scheduleType`；recurring 必带 `rrule`；once 必带 `scheduledAt`。任一不满足，整体拒绝并列出缺失字段
3. **预览**：每条输出名称、频率、`rrule` 自然语言解读（或 `scheduledAt`）、prompt 折行；高亮：
   - 占位串：`<...>` / `{{...}}` / 绝对用户路径（`/Users/.../`、`/home/.../`）
   - 时效：`scheduledAt` / `validUntil` 已早于今天 → 警告"创建后不会触发"
4. **对齐 cwds**（关键）：分享 JSON 不含 `cwds`，**默认建议当前打开的 workspace 根路径**作为单元素 cwds，并询问是否需要绑定多个 workspace
5. **确认其它字段**：是否改名（避免与 `list` 中已有任务重名）；`status` 默认 `ACTIVE`，过期字段是否重选
6. **创建**：逐条调 `automation_update mode=create`，传入 `name` / `prompt` / `scheduleType` / `rrule` / `scheduledAt` / `validFrom` / `validUntil` / 用户指定的 `cwds` / 用户选的 `status`
7. **反馈**：汇总每条结果（新 id、成功 / 失败原因）

## 注意事项

- 跨账号分享时 `prompt` 内的个人路径 / 凭据 / 内部地址需协作方自行替换，预览时务必高亮提醒。
- `automation_update view` 未来新增可分享字段时，按"严禁"清单甄别后即可纳入，无需版本号。
