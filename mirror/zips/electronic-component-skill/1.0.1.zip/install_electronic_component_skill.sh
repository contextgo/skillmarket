#!/bin/bash
# Electronic Component Skill - 依赖安装脚本
# 支持 Linux/macOS/Windows (Git Bash)

set -e

echo "============================================="
echo "    Electronic Component Skill - 依赖安装"
echo "============================================="

# 检测 Python
if ! command -v python3 &> /dev/null && ! command -v python &> /dev/null; then
    echo "[错误] 未检测到 Python，请先安装 Python 3.8+"
    exit 1
fi

PYTHON_CMD=$(command -v python3 || command -v python)
echo "[信息] 使用 Python: $PYTHON_CMD"

# 升级 pip
echo "[步骤] 安装 Python 依赖包..."
$PYTHON_CMD -m pip install requests beautifulsoup4 -q

echo ""
echo "============================================="
echo "    Python 依赖安装完成！"
echo "============================================="

# 验证安装
echo ""
echo "[验证] 检查依赖包..."
$PYTHON_CMD -c "
import sys
packages = ['requests', 'bs4']
all_ok = True
for pkg in packages:
    try:
        __import__(pkg)
        print(f'  [OK] {pkg}')
    except ImportError:
        print(f'  [MISSING] {pkg}')
        all_ok = False
sys.exit(0 if all_ok else 1)
" && echo "" && echo "[成功] 所有依赖已就绪！" || echo "[警告] 部分依赖安装失败"

echo ""
echo "============================================="
echo "    使用示例"
echo "============================================="
echo ""
echo "  python electronic_component_skill.py mark A7B"
echo "  python electronic_component_skill.py res-code 103"
echo "  python electronic_component_skill.py led --vin 5 --vf 2.2"
echo "  python electronic_component_skill.py div --r1 10k --r2 10k --vin 5"
echo "  python electronic_component_skill.py search 'STM32F103C8T6'"
echo ""
echo "============================================="