#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
电子元件终极处理 Skill for QClaw
功能：丝印反查、型号搜索、电阻/电容/电感计算、LED限流电阻、分压电路、RC滤波、PCB载流、封装尺寸查询

用法：
    python electronic_component_skill.py <命令> [参数]

示例：
    python electronic_component_skill.py mark A7B
    python electronic_component_skill.py res-code 103
    python electronic_component_skill.py led --vin 5 --vf 2.2
    python electronic_component_skill.py div --r1 10k --r2 10k --vin 5
    python electronic_component_skill.py search "STM32F103C8T6"
"""
import os
import sys
import io
import re
import math
import argparse

# Windows 终端编码兼容
if sys.platform == "win32":
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    except Exception:
        pass

# 延迟导入第三方依赖
def check_dependencies():
    """检查并提示安装依赖"""
    missing = []
    try:
        import requests
    except ImportError:
        missing.append("requests")
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        missing.append("beautifulsoup4")
    
    if missing:
        print(f"[错误] 缺少依赖包: {', '.join(missing)}")
        print("[提示] 请运行以下命令安装依赖:")
        print("       pip install requests beautifulsoup4")
        sys.exit(1)

check_dependencies()

import requests
from bs4 import BeautifulSoup

# ==================== 基础数据库 ====================
COLOR_BAND = {
    "黑": 0, "棕": 1, "红": 2, "橙": 3, "黄": 4,
    "绿": 5, "蓝": 6, "紫": 7, "灰": 8, "白": 9, "金": -1, "银": -2
}
COLOR_TOL = {"金": 5, "银": 10, "棕": 1, "红": 2, "绿": 0.5, "蓝": 0.25, "紫": 0.1}
COLOR_TEMP = {"棕": 100, "红": 50, "橙": 15, "黄": 25, "蓝": 10, "紫": 5}

E96_CODE = {
    "01A": "100Ω", "01B": "102Ω", "01C": "105Ω", "01D": "107Ω", "01E": "110Ω",
    "02A": "100Ω", "02B": "124Ω", "02C": "127Ω", "02D": "130Ω", "02E": "133Ω",
    "03A": "162Ω", "03B": "165Ω", "03C": "169Ω", "03D": "174Ω", "03E": "178Ω",
    "10C": "10kΩ", "10D": "12.4kΩ", "10E": "15.8kΩ", "10F": "20kΩ", "10G": "25.5kΩ"
}

PACKAGE = {
    "0402": "1.0×0.5mm", "0603": "1.6×0.8mm", "0805": "2.0×1.25mm",
    "1206": "3.2×1.6mm", "1210": "3.2×2.5mm", "1812": "4.5×3.2mm",
    "SOT-23": "2.9×1.6mm", "SOT-89": "4.6×2.6mm", "SOP-8": "5.0×4.0mm",
    "SOP-16": "10.3×5.3mm", "TSSOP-20": "6.5×4.4mm", "QFN-32": "5.0×5.0mm"
}

MARK_DATABASE = {
    "A1": "MMBTA06 NPN", "A2": "MMBTA07 PNP", "A3": "MMBTA92 PNP",
    "A6": "BC846", "A7": "BC847", "B1": "BC856", "B2": "BC857",
    "J3": "MMBT3904 NPN", "J6": "MMBT3906 PNP", "1AM": "MMBT2222",
    "A7B": "SI2307 MOS", "AO34": "AO3400 N沟道MOS", "AO3401": "AO3401 P沟道MOS",
    "662K": "RT9193-3.3V LDO", "662J": "RT9193-5.0V LDO", "661K": "RT9081-3.3V",
    "M1": "BAT54S", "M2": "BAT54", "M7": "1N4007", "S4": "SS34",
    "SS56": "SS56 5A肖特基", "SR340": "SR340 3A肖特基",
    "AMS1117": "AMS1117 LDO", "BL8505": "BL8505 DC-DC",
    "6206": "6206 USB限流", "DW01": "DW01 锂电池保护",
    "FS8205": "FS8205 双N沟道MOS", "FS210": "FS210 DC-DC升压"
}

# ==================== 单位换算 ====================
def parse_resistor_value(s):
    """解析电阻值字符串"""
    s = str(s).strip().upper()
    multipliers = {'K': 1e3, 'M': 1e6, 'R': 1}
    for unit, mult in multipliers.items():
        if unit in s:
            try:
                return float(s.replace(unit, '')) * mult
            except:
                return None
    try:
        return float(s)
    except:
        return None

def parse_capacitor_value(s):
    """解析电容值字符串"""
    s = str(s).strip().upper()
    multipliers = {'P': 1e-12, 'N': 1e-9, 'U': 1e-6, 'M': 1e-3}
    for unit, mult in multipliers.items():
        if unit in s:
            try:
                return float(s.replace(unit, '')) * mult
            except:
                return None
    try:
        return float(s)
    except:
        return None

# ==================== 联网通用爬取 ====================
def search_web(keyword):
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    url = f"https://www.baidu.com/s?wd={keyword}"
    try:
        r = requests.get(url, headers=headers, timeout=10)
        r.encoding = 'utf-8'
        soup = BeautifulSoup(r.text, "html.parser")
        res = []
        for g in soup.find_all(class_="result-op c-container")[:5]:
            t = g.get_text().strip()
            if len(t) > 20:
                res.append(t[:180] + "...")
        return "\n\n".join(res) if res else "无搜索结果"
    except Exception as e:
        return f"网络请求失败: {e}"

# ==================== 丝印反查 ====================
def search_mark(mark):
    mark = mark.strip().upper()
    if mark in MARK_DATABASE:
        return f"【本地匹配】{mark} → {MARK_DATABASE[mark]}"
    return f"【联网搜索】{search_web(f'丝印 {mark} 电子元件')}"

# ==================== 电阻计算 ====================
def res_code(code):
    m = re.fullmatch(r'(\d+)(\d)', str(code))
    if not m: return "格式例：103、472、224"
    v = int(m.group(1)) * (10 ** int(m.group(2)))
    if v >= 1e6: return f"{code} = {v/1e6:.2f} MΩ"
    if v >= 1e3: return f"{code} = {v/1e3:.2f} kΩ"
    return f"{code} = {v} Ω"

def res_color4(c1, c2, c3, c4="金"):
    try:
        v = COLOR_BAND[c1]*10 + COLOR_BAND[c2]
        r = v * (10 ** COLOR_BAND[c3])
        t = COLOR_TOL.get(c4, 5)
        if r >= 1e6: s = f"{r/1e6:.2f}MΩ ±{t}%"
        elif r >= 1e3: s = f"{r/1e3:.2f}kΩ ±{t}%"
        else: s = f"{r}Ω ±{t}%"
        return f"4环：{s}"
    except:
        return "颜色输入错误"

def res_parallel(r_list):
    try:
        rec = sum(1/r for r in r_list)
        return f"并联 = {1/rec:.2f} Ω"
    except:
        return "输入错误"

def res_series(r_list):
    return f"串联 = {sum(r_list):.2f} Ω"

# ==================== 电容计算 ====================
def cap_code(code):
    m = re.fullmatch(r'(\d+)(\d)', str(code))
    if not m: return "格式例：104、223、471"
    pf = int(m.group(1)) * (10 ** int(m.group(2)))
    if pf >= 1e6: return f"{code} = {pf/1e6:.2f} μF = {pf} pF"
    if pf >= 1e3: return f"{code} = {pf/1e3:.2f} nF = {pf} pF"
    return f"{code} = {pf} pF"

def cap_series(c_list):
    rec = sum(1/c for c in c_list)
    return f"串联 = {1/rec:.2e} F"

def cap_parallel(c_list):
    return f"并联 = {sum(c_list):.2e} F"

# ==================== 电感计算 ====================
def ind_code(code):
    m = re.fullmatch(r'(\d+)(\d)', str(code))
    if not m: return "格式例：101、222、333"
    nh = int(m.group(1)) * (10 ** int(m.group(2)))
    if nh >= 1e3: return f"{code} = {nh/1e3:.2f} μH = {nh} nH"
    return f"{code} = {nh} nH"

# ==================== 电路常用计算 ====================
def led_res(vin, vf, current_ma=20):
    i = current_ma / 1000  # 转换为A
    r = (vin - vf) / i
    return f"R = {r:.0f} Ω  (Vin={vin}V, Vf={vf}V, I={current_ma}mA)"

def voltage_div(r1, r2, vin):
    r1 = parse_resistor_value(r1)
    r2 = parse_resistor_value(r2)
    if r1 is None or r2 is None:
        return "电阻值格式错误"
    vout = vin * r2 / (r1 + r2)
    return f"Vout = {vout:.2f} V  (R1={r1}Ω, R2={r2}Ω, Vin={vin}V)"

def rc_freq(r, c):
    r = parse_resistor_value(r)
    c = parse_capacitor_value(c)
    if r is None or c is None:
        return "参数格式错误"
    f = 1 / (2 * math.pi * r * c)
    if f >= 1e6: return f"截止频率 = {f/1e6:.2f} MHz"
    if f >= 1e3: return f"截止频率 = {f/1e3:.2f} kHz"
    return f"截止频率 = {f:.2f} Hz"

def pcb_current(width_mm, thickness_oz=1, temp_rise=10):
    # IPC-D-275 经验公式
    current = 0.024 * (width_mm ** 0.466) * (temp_rise ** 0.449) * (thickness_oz ** 0.5)
    return f"载流 ≈ {current:.2f} A  (宽={width_mm}mm, 铜厚={thickness_oz}oz, 温升={temp_rise}℃)"

# ==================== Qclaw 标准入口 ====================
def run_skill(params):
    act = params.get("action", "").lower()

    if act == "mark":
        return search_mark(params.get("code", ""))
    elif act == "res_code":
        return res_code(params.get("code", ""))
    elif act == "res_color4":
        return res_color4(params.get("c1"), params.get("c2"), params.get("c3"), params.get("c4", "金"))
    elif act == "res_series":
        return res_series(params.get("list", []))
    elif act == "res_parallel":
        return res_parallel(params.get("list", []))
    elif act == "cap_code":
        return cap_code(params.get("code", ""))
    elif act == "cap_series":
        return cap_series(params.get("list", []))
    elif act == "cap_parallel":
        return cap_parallel(params.get("list", []))
    elif act == "ind_code":
        return ind_code(params.get("code", ""))
    elif act == "led":
        return led_res(float(params.get("vin", 0)), float(params.get("vf", 0)), float(params.get("current", 20)))
    elif act == "div":
        return voltage_div(float(params.get("r1", 0)), float(params.get("r2", 0)), float(params.get("vin", 0)))
    elif act == "rc":
        return rc_freq(float(params.get("r", 0)), float(params.get("c", 0)))
    elif act == "pcb":
        return pcb_current(float(params.get("width", 0)))
    elif act == "package":
        return PACKAGE.get(params.get("pkg", "").upper(), "未收录")
    elif act == "search":
        return search_web(params.get("word", ""))
    else:
        return "未知动作，支持：mark/res_code/cap_code/led/div/rc/pcb/package/search"


# ===================== CLI 入口 =====================
def main():
    parser = argparse.ArgumentParser(
        description="电子元件终极处理工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python electronic_component_skill.py mark A7B
  python electronic_component_skill.py res-code 103
  python electronic_component_skill.py res-color4 棕 黑 橙 金
  python electronic_component_skill.py led --vin 5 --vf 2.2
  python electronic_component_skill.py div --r1 10k --r2 10k --vin 5
  python electronic_component_skill.py search STM32F103C8T6
        """
    )
    
    parser.add_argument("command", choices=[
        "mark", "res-code", "res-color4", "res-series", "res-parallel",
        "cap-code", "cap-series", "cap-parallel", "ind-code",
        "led", "div", "rc", "pcb", "package", "search"
    ], help="执行的操作命令")
    
    parser.add_argument("args", nargs="*", help="位置参数")
    parser.add_argument("--code", help="丝印/代码")
    parser.add_argument("--c1", "--c2", "--c3", "--c4", help="色环颜色")
    parser.add_argument("--vin", type=float, help="输入电压 (V)")
    parser.add_argument("--vf", type=float, help="LED正向压降 (V)")
    parser.add_argument("--current", type=float, default=20, help="工作电流 (mA)")
    parser.add_argument("--r1", help="上拉电阻")
    parser.add_argument("--r2", help="下拉电阻")
    parser.add_argument("--r", help="电阻值")
    parser.add_argument("--c", help="电容值")
    parser.add_argument("--width", type=float, help="走线宽度 (mm)")
    parser.add_argument("--thickness", type=float, default=1, help="铜厚 (oz)")
    parser.add_argument("--temp", type=float, default=10, help="温升 (℃)")
    parser.add_argument("--pkg", help="封装名称")
    parser.add_argument("--word", help="搜索关键词")
    
    args = parser.parse_args()
    
    # 构建参数字典
    params = {"action": args.command}
    
    # 处理位置参数
    if args.args:
        if args.command == "mark":
            params["code"] = args.args[0] if not args.code else args.code
        elif args.command == "res-code" or args.command == "cap-code" or args.command == "ind-code":
            params["code"] = args.args[0] if not args.code else args.code
        elif args.command == "res-color4" and len(args.args) >= 3:
            params["c1"] = args.args[0]
            params["c2"] = args.args[1]
            params["c3"] = args.args[2]
            if len(args.args) >= 4:
                params["c4"] = args.args[3]
        elif args.command in ["res-series", "res-parallel", "cap-series", "cap-parallel"]:
            params["list"] = [parse_resistor_value(x) for x in args.args]
        elif args.command == "search":
            params["word"] = " ".join(args.args) if not args.word else args.word
    
    # 处理命名参数
    if args.code: params["code"] = args.code
    if args.c1: params["c1"] = args.c1
    if args.c2: params["c2"] = args.c2
    if args.c3: params["c3"] = args.c3
    if args.c4: params["c4"] = args.c4
    if args.vin is not None: params["vin"] = args.vin
    if args.vf is not None: params["vf"] = args.vf
    if args.current is not None: params["current"] = args.current
    if args.r1 is not None: params["r1"] = args.r1
    if args.r2 is not None: params["r2"] = args.r2
    if args.r is not None: params["r"] = args.r
    if args.c is not None: params["c"] = args.c
    if args.width is not None: params["width"] = args.width
    if args.thickness is not None: params["thickness"] = args.thickness
    if args.temp is not None: params["temp"] = args.temp
    if args.pkg: params["pkg"] = args.pkg
    if args.word: params["word"] = args.word
    
    # 执行
    result = run_skill(params)
    print(result)


if __name__ == "__main__":
    main()