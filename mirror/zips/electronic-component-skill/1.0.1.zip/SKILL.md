---
name: electronic-component-skill
description: 电子元件终极处理工具 - 丝印反查、型号搜索、电阻/电容/电感计算、LED限流电阻、分压电路、RC滤波、PCB载流、封装尺寸查询
homepage: https://github.com/QClaw/skills
metadata:
  {
    "clawdbot":
      {
        "emoji": "🔌",
        "requires":
          {
            "bins": ["python3"],
            "packages": ["requests", "beautifulsoup4"]
          },
        "primaryEnv": "python3",
        "systemDeps": {},
        "autoInstall": true
      }
  }
---

# 🔌 电子元件终极处理 Skill

> 硬件工程师必备工具箱：丝印反查、型号搜索、电阻/电容/电感计算、电路计算、封装查询

---

## 🤖 Agent 执行指令

**执行本技能后，代理必须：**

### 1. 理解用户需求
- 识别电子元件查询意图（丝印反查/参数计算/型号搜索等）
- 解析关键参数（元件代码、阻值、容值、电路参数）

### 2. 执行命令示例

```bash
# 丝印反查
python electronic_component_skill.py mark A7B
python electronic_component_skill.py mark --code AO34

# 电阻计算
python electronic_component_skill.py res-code 103
python electronic_component_skill.py res-color4 棕 黑 橙 金
python electronic_component_skill.py res-series 100 220 330
python electronic_component_skill.py res-parallel 1k 1k 1k

# 电容计算
python electronic_component_skill.py cap-code 104
python electronic_component_skill.py cap-series 10uF 10uF
python electronic_component_skill.py cap-parallel 10uF 10uF

# 电感计算
python electronic_component_skill.py ind-code 101

# 电路计算
python electronic_component_skill.py led --vin 5 --vf 2.2 --current 20
python electronic_component_skill.py div --r1 10k --r2 10k --vin 5
python electronic_component_skill.py rc --r 10k --c 0.1uF
python electronic_component_skill.py pcb --width 0.5

# 封装查询
python electronic_component_skill.py package 0805
python electronic_component_skill.py package SOT-23

# 联网搜索
python electronic_component_skill.py search "STM32F103C8T6 参数"
```

### 3. 依赖安装
```bash
pip install requests beautifulsoup4
```

---

## 📋 支持的命令

### 🔍 丝印反查
| 命令 | 说明 | 示例 |
|------|------|------|
| `mark` | 丝印反查型号 | `mark A7B` |

### 🔢 电阻计算
| 命令 | 说明 | 示例 |
|------|------|------|
| `res-code` | 数字代码转阻值 | `res-code 103` → 10kΩ |
| `res-color4` | 4环色环计算 | `res-color4 棕 黑 橙 金` |
| `res-series` | 串联计算 | `res-series 100 220 330` |
| `res-parallel` | 并联计算 | `res-parallel 1k 1k 1k` |

### 🔋 电容计算
| 命令 | 说明 | 示例 |
|------|------|------|
| `cap-code` | 数字代码转容值 | `cap-code 104` → 0.1μF |
| `cap-series` | 串联计算 | `cap-series 10uF 10uF` |
| `cap-parallel` | 并联计算 | `cap-parallel 10uF 10uF` |

### 🧲 电感计算
| 命令 | 说明 | 示例 |
|------|------|------|
| `ind-code` | 数字代码转电感值 | `ind-code 101` → 100nH |

### 💡 电路计算
| 命令 | 说明 | 示例 |
|------|------|------|
| `led` | LED限流电阻 | `led --vin 5 --vf 2.2` |
| `div` | 分压电路 | `div --r1 10k --r2 10k --vin 5` |
| `rc` | RC滤波截止频率 | `rc --r 10k --c 0.1uF` |
| `pcb` | PCB走线载流 | `pcb --width 0.5` |

### 📦 封装查询
| 命令 | 说明 | 示例 |
|------|------|------|
| `package` | 贴片封装尺寸 | `package 0805` → 2.0×1.25mm |

### 🌐 联网搜索
| 命令 | 说明 | 示例 |
|------|------|------|
| `search` | 任意关键词搜索 | `search STM32F103C8T6` |

---

## 🔧 参数说明

### LED 限流电阻
- `--vin` 输入电压 (V)
- `--vf` LED正向压降 (V)
- `--current` 工作电流 (mA)，默认 20mA

### 分压电路
- `--r1` 上拉电阻 (Ω/kΩ/MΩ)
- `--r2` 下拉电阻 (Ω/kΩ/MΩ)
- `--vin` 输入电压 (V)

### RC 滤波
- `--r` 电阻值 (Ω/kΩ/MΩ)
- `--c` 电容值 (pF/nF/μF)

### PCB 载流
- `--width` 走线宽度 (mm)
- `--thickness` 铜厚 (oz)，默认 1oz
- `--temp` 温升 (℃)，默认 10℃

---

## 📝 更新日志

- **v1.0.0**：初始版本，支持完整电子元件处理功能