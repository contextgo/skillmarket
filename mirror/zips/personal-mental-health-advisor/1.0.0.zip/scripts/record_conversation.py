#!/usr/bin/env python3
# 对话记录与情绪分析脚本
import json
import time
import re
from datetime import datetime
from pathlib import Path

# 配置路径
CONFIG_PATH = Path(__file__).parent.parent / "config" / "config.yaml"
DATA_PATH = Path(__file__).parent.parent / "data" / "records"
DATA_PATH.mkdir(parents=True, exist_ok=True)

# 高风险关键词
HIGH_RISK_KEYWORDS = ["活着没意思", "不想活了", "一切都没有意义", "想结束自己", "没必要继续了", "我撑不住了", "我想消失", "自杀", "自伤", "想死"]
# 情绪关键词映射
EMOTION_KEYWORDS = {
    "开心": ["开心", "高兴", "快乐", "幸福", "满足", "爽", "好棒", "太好了"],
    "放松": ["放松", "舒服", "惬意", "悠闲", "自在"],
    "平静": ["平静", "还好", "一般", "还行", "没什么"],
    "紧张": ["紧张", "慌", "害怕", "恐惧", "担心", "忐忑"],
    "焦虑": ["焦虑", "烦", "闹心", "焦躁", "着急", "坐不住"],
    "烦躁": ["烦躁", "暴躁", "易怒", "不爽", "烦得很"],
    "沮丧": ["沮丧", "失落", "难过", "伤心", "失望", "灰心"],
    "悲伤": ["悲伤", "哭了", "难受", "心碎", "痛苦", "悲痛"],
    "愤怒": ["愤怒", "生气", "恼火", "火大", "气死我了", "不爽"],
    "委屈": ["委屈", "冤枉", "憋屈", "不被理解", "难过"],
    "孤独": ["孤独", "孤单", "一个人", "没人陪", "寂寞"],
    "无力": ["无力", "累", "疲惫", "不想动", "撑不住", "没力气"],
    "压抑": ["压抑", "憋得慌", "喘不过气", "郁闷", "低沉"],
    "绝望": ["绝望", "没希望", "没意思", "不想活了", "活够了"]
}
# 场景关键词映射
SCENARIO_KEYWORDS = {
    "工作压力": ["工作", "上班", "加班", "老板", "同事", "KPI", "项目", "业绩"],
    "家庭矛盾": ["爸妈", "家里", "父母", "家人", "亲戚", "吵架", "矛盾"],
    "情感问题": ["对象", "男朋友", "女朋友", "分手", "吵架", "失恋", "喜欢的人"],
    "自我否定": ["我不行", "我没用", "我做不好", "我太菜了", "我很差"],
    "社交压力": ["社交", "聚会", "见人", "打招呼", "尴尬", "社恐"],
    "身体疲惫": ["累", "困", "腰酸背痛", "不舒服", "生病", "疲惫"],
    "睡眠问题": ["失眠", "睡不着", "熬夜", "睡不好", "多梦", "醒得早"],
    "财务压力": ["没钱", "穷", "欠钱", "工资", "花钱", "账单"],
    "学习压力": ["学习", "考试", "作业", "论文", "毕业", "考研"]
}

def analyze_emotion(user_message: str) -> dict:
    """分析用户消息的情绪、场景、风险等级"""
    result = {
        "primary_emotion": "平静",
        "secondary_emotion": None,
        "intensity": 0.5,
        "scenario": None,
        "risk_level": "low",
        "evidence_keywords": []
    }

    # 检查高风险
    for keyword in HIGH_RISK_KEYWORDS:
        if keyword in user_message:
            result["risk_level"] = "high"
            result["primary_emotion"] = "绝望"
            result["evidence_keywords"].append(keyword)
            return result

    # 识别情绪
    emotions_found = []
    for emotion, keywords in EMOTION_KEYWORDS.items():
        for kw in keywords:
            if kw in user_message:
                emotions_found.append(emotion)
                result["evidence_keywords"].append(kw)
                break

    if emotions_found:
        result["primary_emotion"] = emotions_found[0]
        if len(emotions_found) > 1:
            result["secondary_emotion"] = emotions_found[1]
        # 情绪强度，关键词越多强度越高
        result["intensity"] = min(0.3 + len(result["evidence_keywords"]) * 0.2, 1.0)

    # 识别场景
    for scenario, keywords in SCENARIO_KEYWORDS.items():
        for kw in keywords:
            if kw in user_message:
                result["scenario"] = scenario
                break
        if result["scenario"]:
            break

    # 判定风险等级
    if len([e for e in emotions_found if e in ["焦虑", "烦躁", "沮丧", "悲伤", "愤怒", "委屈", "孤独", "无力", "压抑"]]) >= 2:
        result["risk_level"] = "medium"

    return result

def save_conversation(user_message: str, assistant_response: str, mode_used: str, emotion_analysis: dict):
    """保存对话记录到本地"""
    today = datetime.now().strftime("%Y-%m-%d")
    record_file = DATA_PATH / f"conversation_{today}.json"
    
    record = {
        "timestamp": int(time.time()),
        "user_message": user_message,
        "assistant_response": assistant_response,
        "message_summary": user_message[:50] + "..." if len(user_message) > 50 else user_message,
        "mode_used": mode_used,
        "risk_level": emotion_analysis["risk_level"],
        "confidence": emotion_analysis["intensity"],
        "tags": [emotion_analysis["primary_emotion"], emotion_analysis["scenario"]] if emotion_analysis["scenario"] else [emotion_analysis["primary_emotion"]]
    }

    # 写入文件
    if record_file.exists():
        with open(record_file, "r", encoding="utf-8") as f:
            records = json.load(f)
    else:
        records = []
    
    records.append(record)
    
    with open(record_file, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)

    # 保存情绪分析记录
    emotion_record = {
        "timestamp": int(time.time()),
        **emotion_analysis,
        "evidence_context": user_message[:100]
    }
    emotion_file = DATA_PATH / f"emotion_{today}.json"
    if emotion_file.exists():
        with open(emotion_file, "r", encoding="utf-8") as f:
            emotion_records = json.load(f)
    else:
        emotion_records = []
    emotion_records.append(emotion_record)
    with open(emotion_file, "w", encoding="utf-8") as f:
        json.dump(emotion_records, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    # 测试用
    test_msg = "今天上班好累，项目做不完，好焦虑啊，感觉撑不住了"
    analysis = analyze_emotion(test_msg)
    print("情绪分析结果：", json.dumps(analysis, ensure_ascii=False, indent=2))
    save_conversation(test_msg, "别着急呀，慢慢来，你已经做得很好啦，实在累了就先休息会哦", "empathize", analysis)
    print("记录已保存")
