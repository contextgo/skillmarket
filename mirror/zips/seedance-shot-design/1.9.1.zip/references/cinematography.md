# 运镜与焦段专业词典

> Seedance 2.0 对中英文混合描述效果最佳。运镜是决定视频质量的关键——同样的场景，精准运镜是"电影感"和"监控探头"的区别。
>
> ⚠️ **Seedance 审核安全提醒：** 裸写的英文运镜术语（如 `Dolly`、`Aerial`、`Crane`）可能被审核系统误判为人名/品牌名而触发违规拦截。**中文提示词使用中文运镜词，英文提示词使用完整短语**（见下表「Seedance 安全写法」列）。

## 一、景别体系 (Shot Sizes)

| 英文术语 | 中文 | 画面范围 | 叙事功能 |
|----------|------|----------|----------|
| Extreme Close-Up (ECU) | 极致特写 | 瞳孔/指尖/水滴 | 放大情绪、展现微观质感 |
| Close-Up (CU) | 特写 | 面部/单个物体 | 捕捉微表情、聚焦关键道具 |
| Medium Close-Up (MCU) | 中近景 | 头肩以上 | 对话、情绪传达 |
| Medium Shot (MS) | 中景 | 腰部以上 | 叙事推进、日常对话 |
| Medium Full Shot | 中全景 | 膝部以上 | 展示肢体语言 |
| Full Shot (FS) | 全景 | 头到脚完整人物 | 展示角色全貌与动作 |
| Wide Shot (WS) | 远景 | 主体+大量环境 | 交代环境关系 |
| Extreme Wide Shot (EWS) | 大远景 | 壮阔风光，人物极小 | 建立宏大世界观 |
| Establishing Shot | 建置镜头 | 场景全貌 | 开场定位时空 |
| Over-the-Shoulder (OTS) | 过肩镜头 | 一人肩后看另一人 | 对话场景视角切换 |
| Two-Shot | 双人镜头 | 两人同框 | 展现人物关系 |
| POV Shot | 主观视角 | 角色第一人称 | 最高级沉浸体验 |

## 二、三级运镜体系

### Level 1：基础运镜动作（覆盖80%基础需求）

| 英文术语 | 中文 | 运动轨迹 | 心理效果 | Seedance 安全写法 |
|----------|------|----------|----------|-------------------|
| Pan Left/Right | 水平摇摄 | 镜头固定，水平转动 | 追踪横向移动、展现广阔环境 | ⚠️ CN: `水平摇摄` / EN: `pan shot` |
| Tilt Up/Down | 垂直俯仰 | 镜头固定，垂直转动 | 仰拍强化力量感，俯拍表现脆弱 | ✅ 安全 |
| Dolly In/Out | 推轨推进/后拉 | 机位前后物理移动 | 推进=建立亲密感；后拉=揭示孤立 | ⚠️ CN: `推轨推进` / EN: `dolly tracking shot` |
| Zoom In/Out | 变焦推进/拉远 | 焦距变化，机位不动 | 快速聚焦或拉开距离 | ✅ 安全 |
| Truck Left/Right | 横向平移 | 机位左右横向移动 | 展示并列元素 | ✅ 安全 |
| Crane Up/Down | 摇臂升/降 | 机位垂直升降 | 升=宏大揭示；降=逐渐逼近 | ⚠️ CN: `摇臂升降` / EN: `crane shot` / `jib shot` |
| Orbit / Arc | 环绕/弧形 | 围绕主体旋转 | 展示主体全貌、制造仪式感 | ⚠️ CN: `环绕`/`弧形环绕` / EN: `orbital camera movement` / `arc shot` |
| Tracking Shot | 跟踪镜头 | 跟随主体平行移动 | 保持主体焦点+传递速度感 | ✅ 安全 |
| Static Shot | 固定镜头 | 机位不动 | 客观记录、冷静叙事 | ✅ 安全 |
| Push In | 缓慢推进 | 缓慢靠近主体 | 累积紧张感、聚焦细节 | ✅ 安全 |
| Pull Out | 缓慢拉出 | 缓慢远离主体 | 揭示更大环境 | ✅ 安全 |
| Pedestal Up/Down | 升降平移 | 机身垂直升降不改俯仰角 | 跟随角色起立/坐下 | ✅ 安全 |
| Epic Drone Reveal | 史诗级无人机揭示 | 无人机从背后/低位缓慢升起，揭示宏观场景 | 从人物亲密视角到史诗全貌的戏剧性反转，制造震撼揭示感 | ✅ CN: `无人机缓慢上升揭示` / EN: `epic drone reveal shot` |
| Reveal from Behind / Through Shot | 遮挡揭示/穿梭镜头 | 镜头穿越遮挡物（树丛/门框/人群/窗帘）后揭示场景 | 制造悬念感与层次纵深，营造"发现"的仪式感 | ✅ CN: `穿越[遮挡物]揭示` / EN: `reveal through obstacle shot` |
| Leading Shot | 引导镜头 | 镜头在主体前方后退，主体主动"追"镜头方向前进 | 叙述旅程感与主动性，观众视角=前方未知 | ✅ CN: `引导后退跟拍` / EN: `leading shot pulling back` |

### Level 2：修饰词（赋予运镜灵魂）

**速度修饰：**

| 修饰词 | 效果 | 示例 |
|--------|------|------|
| Smooth / 流畅的 | 平和优雅 | `Smooth dolly in on the couple` |
| Slow / 缓慢的 | 悬念、回忆 | `Slow zoom out from the photo` |
| Fast / Rapid | 紧张激烈 | `Fast tracking through the market` |
| Subtle / 微妙的 | 增强沉浸 | `Subtle tilt up during monologue` |
| Gradual / 渐进的 | 自然过渡 | `Gradual 10-second crane up` |
| Sudden / 突然的 | 惊吓转折 | `Sudden whip pan to reveal` |

**情绪修饰：**

| 修饰词 | 氛围 | 示例 |
|--------|------|------|
| Cinematic | 电影感 | `Cinematic arc shot around hero` |
| Aggressive | 侵略性 | `Aggressive handheld in chase` |
| Dreamy | 梦幻 | `Dreamy slow-motion dolly` |
| Intimate | 亲密 | `Intimate push-in on hands` |
| Epic | 史诗 | `Epic crane up revealing army` |
| Dynamic | 动态活力 | `Dynamic tracking on dance floor` |

**风格修饰：**

| 修饰词 | 效果 | 示例 |
|--------|------|------|
| Handheld / 手持 | 纪实感、混乱感 | `Handheld follow in war zone` |
| Aerial / 航拍 | 俯瞰视角 | `Aerial rising over city` |
| Dutch Angle / 荷兰角 | 倾斜不安 | `Dutch angle tracking thriller` |
| Gimbal / 云台 | 稳定流畅 | `Gimbal tracking through corridor` |
| Steadicam / 斯坦尼康 | 专业级稳定 | `Steadicam follow in hallway` |
| POV | 第一人称沉浸 | `POV walking through haunted house` |
| FPV Drone / 穿越机 | 极速俯冲翻滚 | `FPV drone dive through canyon` |

### Level 3：组合运镜（复合技巧）

用 `+` 或 `while` 连接，一次最多 2-3 个动作：

| 组合 | 效果 | 场景 |
|------|------|------|
| Orbit + Zoom In | 视觉冲击力极强 | 揭示主体、产品展示 |
| Crane Up + Pan | 大气磅礴 | 开场/结尾 |
| Dolly Zoom (Vertigo) | 眩晕空间扭曲 | 心理冲击、恐慌 |
| Tracking + Handheld Shake | 紧张追逐 | 追逐/逃亡 |
| Dolly Back + Crane Up | 逐渐揭示宏大场景 | 震撼场景揭示 |
| Arc 180° + Subtle Zoom In | 情绪聚焦 | 情绪转折点 |
| Whip Pan | 极速横摇转场 | 空间转场、紧张节奏 |
| Snap Zoom / Crash Zoom | 急推变焦——焦距骤变至极端特写或极端远景，产生爆裂冲击感 | 喜剧冲击、惊吓强调、MV节拍卡点 |
| Orbit Follow（移动环绕） | 主体运动中同步环绕（orbit + tracking），环绕中心点随主体移动 | 跟随奔跑/格斗同时环绕，制造动感包围感；区别于静止主体环绕 |

## 三、焦段与物理镜头参数

| 焦段 | 视觉特征 | 适用场景 |
|------|----------|----------|
| **14mm Ultra-wide** | 强烈透视畸变、边缘拉伸 | 巨物恐惧、末世压迫、建筑全貌 |
| **24mm Wide** | 适度广角、自然空间感 | 环境建置、街景 |
| **35mm Standard Wide** | 接近人眼略广 | 纪录片、日常叙事 |
| **50mm Standard** | 最接近人眼 | 平实叙事、对话场景 |
| **85mm Portrait** | 背景压缩、柔美虚化 | 人像特写、情感场景 |
| **135mm Telephoto** | 极度空间压缩、奶油散景 | 面部微表情、汗滴特写 |
| **200mm+ Super Telephoto** | 极致背景压缩 | 远距离偷拍感、监视感 |
| **Fisheye** | 极度球面畸变 | 偷窥感、心理扭曲、滑板视角 |

### 焦段叙事心理学（为什么 mm 数比形容词更有效）

> 视频大模型底层是三维物理模拟器，对具体的毫米数（mm）极度敏感。写 `14mm ultra-wide lens` 远比写"广角镜头"更能激发正确的空间透视。

**核心规律：焦距越短 → 空间越夸张 → 主体越膨胀；焦距越长 → 空间越压缩 → 背景越贴近。**

| 焦段 | 物理效果 | 心理暗示 | 典型创作场景 |
|------|----------|----------|-------------|
| **14mm** | 强烈桶形畸变，边缘物体被拉伸 | 压迫、窒息、巨物恐惧 | 末日废土仰拍巨型机甲；幽闭室内被困角色；建筑内部仰拍穹顶 |
| **24-35mm** | 适度广角，自然空间延伸 | 开放、叙事、客观 | 环境建置镜头；街头纪实；多人对话全景 |
| **50mm** | 零畸变，最接近人眼 | 平实、真实、亲切 | 日常对话；平实叙事；纪录片采访 |
| **85mm** | 轻度压缩，柔美散景 | 温柔、亲密、浪漫 | 人像特写；情感戏；产品美拍 |
| **135-200mm** | 极致空间压缩，奶油般背景虚化 (Creamy Bokeh) | 孤立、窥视、聚焦微观 | 面部汗滴微表情；远距离跟拍的"偷窥感"；人群中锁定单一面孔 |

**提示词范例：**

```
# 14mm 巨物压迫
14mm ultra-wide lens, extreme low angle, towering mecha looming above, barrel distortion stretching the edges

# 135mm 微表情特写
135mm telephoto lens, shallow depth of field with creamy bokeh, extreme close-up on trembling lips, sweat rolling down temple

# 50mm 平实叙事
50mm standard lens, eye-level medium shot, natural perspective, couple walking through autumn park
```

## 四、焦点控制与景深

| 术语 | 英文 | 效果 |
|------|------|------|
| 浅景深 | Shallow Depth of Field | 背景模糊，主体突出 |
| 深焦 | Deep Focus | 前中后景全部锐利 |
| 焦点转换 | Rack Focus | 焦点在前后景间平滑转移 |
| 散景 | Bokeh | 柔和的圆形背景虚化光斑 |
| 分屈光镜 | Split Diopter | 两个平面同时对焦 |

### 高阶动态对焦范式

> Rack Focus 是最被低估的叙事武器——它不移动摄像机，却能在一秒内改变观众的注意力焦点。

**速度修饰：**

| 修饰 | 英文 | 效果 | 场景 |
|------|------|------|------|
| 缓焦转移 | Slow rack focus | 从容的视觉引导 | 回忆、发现、渐悟 |
| 急焦切换 | Snap focus / Whip focus | 瞬间跳焦，视觉冲击 | 惊吓、突然发现威胁 |
| 呼吸焦点 | Breathing focus | 焦点微微前后游移 | 紧张等待、不安情绪 |

**创作范式（可直接用于提示词）：**

```
# 经典前→后焦转
Rack focus from the dripping gun barrel in foreground to the villain's face emerging from shadows in background

# 后→前焦转（揭示型）
Focus shifts from blurred foreground, slowly resolving to reveal a bloody handprint on the glass

# 急焦切换（惊吓型）
Snap focus from peaceful landscape to a figure standing inches from camera
```

**焦段联动提示：** 长焦段（85mm+）下的 Rack Focus 效果最戏剧化，因为浅景深让焦内/焦外的反差更强烈。在提示词中组合使用效果最佳：

```
135mm telephoto, shallow DOF, slow rack focus from wilting flower in foreground to woman's tear-streaked face in background, creamy bokeh transition
```

## 五、转场技巧

| 术语 | 英文 | 效果 |
|------|------|------|
| 硬切 | Cut | 瞬间切换 |
| 溶解 | Dissolve / Crossfade | 渐变混合 |
| 匹配剪辑 | Match Cut | 形状/动作匹配切换 |
| 甩镜转场 | Whip Transition | 快速横摇衔接两场景 |
| 渐隐 | Fade to Black/White | 渐变至纯色 |
| 速度渐变 | Speed Ramp | 慢到快或快到慢 |

## 六、镜头角度

| 术语 | 英文 | 心理效果 |
|------|------|----------|
| 平视 | Eye-Level | 中立自然 |
| 仰拍 | Low Angle | 力量感、英雄感 |
| 俯拍 | High Angle | 脆弱、渺小 |
| 鸟瞰 | Bird's Eye / Top-Down | 上帝视角、几何美 |
| 虫瞰 | Worm's Eye | 极致仰视，建筑压迫 |
| 荷兰角 | Dutch Angle | 不安、悬疑张力 |

## 七、物理挂载与特种设备 (Camera Rigs)

> 运镜动作决定"摄像机做什么"，物理挂载决定"摄像机骑在什么上面"。后者赋予画面独特的**呼吸感和物理质感**，是打破 AI 默认"死板平滑"的关键。
>
> *与 Level 2 风格修饰（Steadicam / FPV Drone / Handheld 等）互为补充，此处提供深度物理参数与创作指南。*

| 设备 | 英文 | 物理特征 | 视觉签名 | 适用场景 |
|------|------|----------|----------|----------|
| 斯诺里机位 | SnorriCam / Body-mounted | 摄像机刚性绑定在演员躯干 | 人物面部静止，背景疯狂晃动后退 | 眩晕、精神崩溃、亡命狂奔、醉酒 |
| 穿越机 | FPV Drone | 微型无人机极速飞行，6自由度 | 狭窄空间极速穿梭、俯冲翻滚 | 废墟穿越、走廊追逐、车窗穿入、Seedance 极擅长 |
| 斯坦尼康跟拍 | Steadicam Follow | 弹簧臂+背心稳定系统 | 流畅移动中带微弱真实呼吸感 | 长镜头跟拍、《闪灵》走廊、打破 AI 死板平滑 |
| 钢索飞猫 | Cable Cam / Wirecam | 钢索悬挂系统精准直线运动 | 高速直线飞越，无抖动 | 体育场飞越、音乐节俯冲、峡谷穿越 |
| 低机位碾压 | Crash Cam | 摄像机贴地/底盘安装 | 极致仰视碾压感 | 车轮特写、奔跑踩踏、动物视角 |
| 摇臂/伸缩炮 | Jib / Crane | 长臂大幅度升降摆动 | 从地面到高空的连续弧线 | 开场大揭示、告别俯瞰、舞台表演 |

**提示词范例：**

```
# SnorriCam 精神崩溃
SnorriCam body-mounted, actor's terrified face locked in center frame, background spinning and rushing backward, 24mm wide lens

# FPV 穿越机穿梭
FPV drone shot, racing through narrow abandoned warehouse corridors, sharp banking turns, debris flying past camera, motion blur

# Steadicam 跟拍长镜头
Steadicam follow behind character walking through dimly lit hotel corridor, subtle organic breathing motion, 35mm lens

# Crash Cam 碾压视角
Crash cam ground level, motorcycle tire spinning inches from lens, gravel spraying, extreme low angle
```

## 八、创意特效运镜速查（v1.8 新增）

> 以下为 Seedance 2.0 可通过关键词触发的特殊视觉效果，可与常规运镜自由组合使用。

| 效果 | 中文触发词 | English Trigger | 适用场景 |
|------|-----------|----------------|---------|
| 希区柯克变焦 | `希区柯克变焦` / `滑动变焦` | `Hitchcock zoom` / `dolly zoom` | 惊恐/顿悟/空间扭曲 |
| 鱼眼镜头 | `鱼眼镜头透过[形状]窥视` | `Fisheye lens peering through [shape]` | 偷窥/夸张/喜剧 |
| 粒子特效 | `金色沙砾飘散` / `粒子吹散效果` | `Golden sand particles scattering` / `Particle dispersion effect` | 魔法/转场/片头 |
| 速度渐变 | `过山车般速度逐渐加快` | `Speed accelerates like roller coaster` | 追逐/紧迫/高潮 |
| 定格转场 | `画面定格后碎裂转场` | `Frame freezes then shatters into transition` | 闪回/转场/MV |
| 水墨化 | `黑白水墨风格` | `Black-and-white ink wash style` | 东方美学/功夫/禅意 |
| 变身/变装 | `裂纹蔓延后粒子消散变形` | `Cracks spreading then particles dissolve and morph` | 变身/超能力/Before-After |
| 遮罩文字 | `主体背后通过遮罩出现文字` | `Text appears behind subject through masking` | 广告/片头/品牌 |

**组合范例：**

```
# 希区柯克变焦 + 情绪
主角在惊恐时希区柯克变焦，背景急速远离，面部保持在画面中央

# 粒子特效 + 片头
以黑幕开场，金色鎏金材质的沙砾从画面左边飘出并向右覆盖，粒子吹散效果，@图片1的字体逐渐出现在画面中心

# 水墨风格 + 动作
黑白水墨风格，人物参考@视频1的特效和动作，上演一段水墨太极功夫
```

## 九、叙事引导运镜速查（v1.9 新增）

> 「引导与跟随」是最常被 AI 视频创作者忽视的运镜维度——它决定了观众的情绪视角是「被带领」还是「旁观」，是区分"有叙事灵魂的镜头"与"监控探头"的关键。

| 运镜类型 | 中文触发词 | English Trigger | 叙事效果 |
|----------|-----------|----------------|----------|
| 引导后退镜头 (Leading Shot) | `镜头在主体前方缓慢后退引导` | `leading shot, camera retreating ahead of subject` | 观众站在"未知前方"视角，强化旅程感与主动性 |
| 背影跟随镜头 (Following Shot) | `背影稳定跟随，呈现旅程感` | `following shot from behind, steady pursuit` | 传达前进与探索感，营造神秘与宿命感 |
| 侧向平行跟随 (Side Tracking) | `侧面平行跟拍，同步展示动作` | `side tracking shot, parallel to subject movement` | 展示肢体语言与动作全貌，适合跑步/舞蹈/格斗 |
| 低角度贴地跟随 (Low Angle Follow) | `低机位贴地跟随` | `low angle follow shot, camera near ground level` | 夸大运动动感，制造奔跑/车辆的速度压迫感 |
| 长焦压迫跟随 (Long Lens Follow) | `200mm长焦跟拍，背景与主体压缩叠加` | `long lens follow, 200mm telephoto compression` | 背景快速填满画面，强化幽闭与追击紧迫感 |
| 史诗无人机揭示 (Epic Drone Reveal) | `无人机从低位缓慢升起，从背后揭示宏大场景` | `epic drone reveal, slow rise from low angle behind subject` | 从人物视角→史诗全貌的戏剧性反转，常用于高潮揭示 |
| 遮挡揭示 (Reveal Through) | `镜头穿越[遮挡物]后揭示场景` | `reveal through [obstacle], camera pushing through [obstruction]` | 制造"发现"的仪式感与层次纵深，增加叙事悬念 |
| 移动环绕 (Orbit Follow) | `移动中环绕拍摄，中心点随主体运动` | `orbit follow shot, circling subject while both move` | 跟随运动主体同步环绕，制造动感包围感 |

**提示词范例：**

```
# 引导后退镜头（旅程感）
徒步者背负行囊缓步攀爬山路。镜头在其正前方缓慢后退引导，始终保持中景。
Hiker trudging up mountain trail, camera retreating ahead of subject in steady leading shot, keeping medium framing throughout.

# 史诗无人机揭示（震撼高潮）
无人机从武者背后低位缓慢上升揭示，起始特写武者颈后，随上升逐渐揭示身后万顷沙漠与落日余晖。
epic drone reveal shot rising slowly from behind warrior, starting tight on neck, ascending to unveil vast desert and blazing sunset panorama.

# 遮挡揭示（叙事悬念）
镜头缓慢穿越密集竹林缝隙，穿出竹林后瞬间揭示远处隐约可见的孤独山城。
camera slowly pushing through dense bamboo forest gaps, emerging to reveal a solitary mountain fortress in the mist beyond.
```

## 十、运动强度修饰词速查（v1.8.2 新增）

> 动作描写中使用明确的强度修饰词，可以显著改善 Seedance 的运动生成质量，避免"糊动"（motion mush）——即动作幅度不够或方向不明确。

### 强度等级对照表

| 等级 | 中文修饰词 | English Modifiers | 适用场景 |
|------|-----------|------------------|---------|
| ⚡ 极强 | 猛烈、暴烈、爆裂、猛冲 | violent, explosive, slamming, bursting | 爆炸/撞击/格斗 |
| 🔥 强烈 | 剧烈、迅猛、急速、用力 | dramatic, vigorous, rapid, forceful | 追逐/运动/情绪高潮 |
| ⚡ 突然 | 突然、骤然、猛然、戛然 | sudden, abrupt, snapping, jolting | 惊吓/转变/闪回 |
| 🌊 中等 | 稳步、从容、自然、轻快 | steady, confident, natural, brisk | 叙事推进/日常动作 |
| 🍃 轻柔 | 缓缓、温柔、轻柔、丝滑 | gentle, soft, smooth, delicate | 浪漫/舒缓/ASMR |
| 🪨 渐进 | 渐渐、逐步、缓慢、不知不觉 | gradual, slowly, imperceptibly, easing | 日出/情绪渐变/暗场 |

### 用法要点

- **每个动作都应携带强度修饰词**——`人物猛然转身` 而非 `人物转身`；`Camera gently drifts upward` 而非 `Camera moves up`
- **强度修饰词应与运镜节奏一致**——剧烈动作配快速运镜，轻柔动作配缓慢运镜
- **避免矛盾组合**——`缓慢爆裂` / `gentle slamming` 这类自相矛盾的描述会让模型困惑

### 对比示例

```
# ❌ 模糊（容易糊动）
人物走过去。镜头跟随。

# ✅ 明确（运动清晰）
人物猛然起身大步流星冲向出口。手持跟拍急速追踪。

# ❌ Vague (mushy motion)
The person moves forward. Camera follows.

# ✅ Clear (crisp motion)
The person surges forward in explosive strides toward the exit. Handheld tracking shot rushes to keep pace.
```
