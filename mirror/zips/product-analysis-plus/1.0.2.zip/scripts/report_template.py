# -*- coding: utf-8 -*-
"""
五维产品调研分析报告 - 通用版 Python docx 生成模板 v2.0
基于 python-docx 库，用于生成专业格式的Word调研报告。

通用设计：
- 企业信息通过配置区输入，不硬编码任何公司数据
- 包含全部五维分析 + 新增模块（技术趋势/准入壁垒/政策法规/SWOT/敏感性等）
- 所有具体数据为 TODO 占位符，每次调研按需填充

使用方法：
1. pip install python-docx
2. 修改下方配置区（PRODUCT_NAME / COMPANY_INFO / REPORT_DATE 等）
3. 填充各 Part 的数据区域（搜索 # TODO: 标记）
4. 运行：python report_template.py

输出：桌面 [产品名称]产品调研分析报告.docx
"""
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from datetime import datetime

# ==================== 配置区（每次调研必改）====================
# --- 产品信息 ---
PRODUCT_NAME = "【产品名称】"            # 例：高周波焊接机
PRODUCT_NAME_EN = "【Product Name】"     # 例：High Frequency Welding Machine

# --- 用户企业信息（如未提供，填 None 或留空）---
COMPANY_NAME = None                      # 例："Auplex" / None
COMPANY_SCALE = None                     # 例："7000平工厂，30人团队" / None
COMPANY_MAIN_BUSINESS = None             # 例："热转印设备出口" / None
COMPANY_CHANNELS = None                  # 例："阿里国际站+独立站" / None
COMPANY_TARGET_MARKETS = None            # 例："欧美、南美、南非、澳洲" / None
COMPANY_BUDGET = None                    # 例："5万人民币" / None

# --- 报告元数据 ---
REPORT_DATE = datetime.now().strftime("%Y年%m月%d日")  # 自动使用当前日期
OUTPUT_FILENAME = PRODUCT_NAME + "产品调研分析报告.docx"
# =================================================================


def get_company_label():
    """根据是否提供企业信息返回合适的标签文本"""
    if COMPANY_NAME:
        return f"{COMPANY_NAME}企业背景"
    else:
        return "入局所需能力基准（通用行业标准）"


doc = Document()

# Set default font for Chinese
style = doc.styles['Normal']
style.font.name = 'Microsoft YaHei'
style.font.size = Pt(11)
style._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')

# Page setup - A4
for section in doc.sections:
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.left_margin = Cm(2)
    section.right_margin = Cm(2)
    section.top_margin = Cm(2.5)
    section.bottom_margin = Cm(2.5)


def set_cell_shading(cell, fill_color):
    """Set cell background color"""
    shading_elm = OxmlElement('w:shd')
    shading_elm.set(qn('w:fill'), fill_color)
    cell._tc.get_or_add_tcPr().append(shading_elm)


def add_heading(text, level=1):
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        if level == 1:
            run.font.size = Pt(18)
            run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)
        elif level == 2:
            run.font.size = Pt(14)
            run.font.color.rgb = RGBColor(0x2E, 0x75, 0xB6)
        else:
            run.font.size = Pt(12)
            run.font.color.rgb = RGBColor(0x40, 0x40, 0x40)
    return h


def add_para(text, bold=False, italic=False, color=None, size=11):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.name = 'Microsoft YaHei'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    run.font.size = Pt(size)
    if color:
        run.font.color.rgb = RGBColor(*color)
    return p


def add_bullet(text, bold_prefix=None):
    p = doc.add_paragraph(style='List Bullet')
    if bold_prefix:
        run = p.add_run(bold_prefix)
        run.bold = True
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(11)
        run = p.add_run(text)
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(11)
    else:
        run = p.add_run(text)
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(11)
    return p


def create_table(headers, rows, col_widths=None):
    """创建带样式的表格：蓝底白字表头，斑马纹数据行"""
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = 'Table Grid'

    # Header row - 蓝底白字
    header_row = table.rows[0]
    for i, header in enumerate(headers):
        cell = header_row.cells[i]
        cell.text = ''
        p = cell.paragraphs[0]
        run = p.add_run(header)
        run.bold = True
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(10)
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_cell_shading(cell, '2E75B6')

    # Data rows - 斑马纹
    for r_idx, row_data in enumerate(rows):
        row = table.rows[r_idx + 1]
        for c_idx, cell_text in enumerate(row_data):
            cell = row.cells[c_idx]
            cell.text = ''
            p = cell.paragraphs[0]
            run = p.add_run(str(cell_text))
            run.font.name = 'Microsoft YaHei'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
            run.font.size = Pt(10)
            if r_idx % 2 == 1:
                set_cell_shading(cell, 'F2F2F2')

    if col_widths:
        for i, width in enumerate(col_widths):
            for row in table.rows:
                row.cells[i].width = Cm(width)

    return table


def add_warning_box(text):
    """添加醒目的警告框"""
    p = doc.add_paragraph()
    run = p.add_run('⚠️ ' + text)
    run.bold = True
    run.font.name = 'Microsoft YaHei'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    run.font.size = Pt(11)
    run.font.color.rgb = RGBColor(0xCC, 0x00, 0x00)  # 红色警告
    set_cell_shading = OxmlElement('w:shd')
    return p


def add_info_note(text):
    """添加信息提示框"""
    p = doc.add_paragraph()
    run = p.add_run('📌 ' + text)
    run.font.name = 'Microsoft YaHei'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    run.font.size = Pt(10)
    run.font.color.rgb = RGBColor(0x66, 0x66, 0x66)
    run.italic = True
    return p


# ==================== 封面页 ====================
doc.add_paragraph()
doc.add_paragraph()
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run(PRODUCT_NAME)
run.bold = True
run.font.size = Pt(26)
run.font.name = 'Microsoft YaHei'
run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run('产品深度调研与可行性分析报告')
run.bold = True
run.font.size = Pt(18)
run.font.name = 'Microsoft YaHei'
run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
run.font.color.rgb = RGBColor(0x2E, 0x75, 0xB6)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run('—— 五维分析法 v2.0 ——')
run.italic = True
run.font.size = Pt(12)
run.font.name = 'Microsoft YaHei'
run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
run.font.color.rgb = RGBColor(0x88, 0x88, 0x88)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run('产品画像 · 市场需求 · 竞争格局 · 利润测算 · 自身匹配度')
run.font.size = Pt(10)
run.font.name = 'Microsoft YaHei'
run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
run.font.color.rgb = RGBColor(0xAA, 0xAA, 0xAA)

doc.add_paragraph()
doc.add_paragraph()

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run(f'报告生成日期：{REPORT_DATE}')
run.font.size = Pt(11)
run.font.name = 'Microsoft YaHei'
run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')

if COMPANY_NAME:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f'委托方：{COMPANY_NAME}')
    run.font.size = Pt(11)
    run.font.name = 'Microsoft YaHei'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run('调研方法：联网实时搜索 + 多平台数据交叉验证 + 行业数据库')
run.font.size = Pt(10)
run.font.name = 'Microsoft YaHei'
run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
run.font.color.rgb = RGBColor(0x88, 0x88, 0x88)

doc.add_page_break()


# ==================== 执行摘要（新增）====================
add_heading('执行摘要', 1)
add_para('[本节为半页纸核心发现速览，在完成全部分析后回填]', italic=True,
         color=(0x88, 0x88, 0x88))

create_table(
    ['项目', '核心发现'],
    [
        ['产品定位', '# TODO: 一句话定义该产品和其在产业链中的位置'],
        ['市场规模', '# TODO: 全球/中国市场规模及增速'],
        ['竞争态势', '# TODO: 红海/蓝海/细分赛道判断'],
        ['利润空间', '# TODO: 预估毛利率区间'],
        ['关键风险', '# TODO: 最大的1-2个风险点'],
        ['决策结论', '# TODO: ✅/⚠️/❌ + 一句话'],
    ],
    [4, 12]
)

add_para('[以下为完整分析内容 ↓]', color=(0x2E, 0x75, 0xB6), bold=True)

doc.add_page_break()


# ==================== PART 1：产品深度画像 ====================
add_heading('板块一：产品深度画像', 1)

# ---- 1.1 产品定义与技术原理 ----
add_heading('1.1 产品定义与技术原理', 2)
# TODO: 产品定义（大白话解释）
add_para('[TODO: 用2-3句话通俗解释这是什么设备/产品，非专业人士也能看懂]')
add_para('[TODO: 核心工作原理描述，避免过多术语]')

add_heading('核心功能清单', 3)
# TODO: 至少5项核心功能
create_table(
    ['序号', '功能名称', '功能描述', '重要性'],
    [
        ['1', '', '', '核心/重要/辅助'],
        ['2', '', '', ''],
        ['3', '', '', ''],
        ['4', '', '', ''],
        ['5', '', '', ''],
    ],
    [1.5, 3.5, 8, 3]
)

add_heading('关键性能参数', 3)
# TODO: 行业通用的3-5个关键参数
create_table(
    ['参数名称', '典型值范围', '单位', '说明'],
    [
        ['', '', '', ''],
        ['', '', '', ''],
        ['', '', '', ''],
        ['', '', '', ''],
    ],
    [4, 4, 2.5, 5.5]
)

# ---- 1.2 适用基材范围 ----
add_heading('1.2 适用基材/加工范围', 2)
create_table(
    ['材料类别', '适用材质示例', '不适用材质', '加工限制条件'],
    [
        # TODO: 填写适用材料表
        ['# TODO: 材料类别1', '# TODO: 具体材质A/B/C', '# TODO: 材质X/Y/Z', '# TODO: 温度/厚度限制等'],
        ['# TODO: 材料类别2', '', '', ''],
        ['# TODO: 材料类别3', '', '', ''],
    ],
    [3.5, 5, 4, 4.5]
)

# ---- 1.3 应用场景全景图 ----
add_heading('1.3 应用场景全景图', 2)
add_para('目标覆盖至少8个应用行业领域：', italic=True)
create_table(
    ['序号', '应用领域', '终端产品示例', '加工方式', '行业规模(推测)', '增长趋势'],
    [
        # TODO: 至少8个行业
        ['1', '', '', '', '', ''],
        ['2', '', '', '', '', ''],
        ['3', '', '', '', '', ''],
        ['4', '', '', '', '', ''],
        ['5', '', '', '', '', ''],
        ['6', '', '', '', '', ''],
        ['7', '', '', '', '', ''],
        ['8', '', '', '', '', ''],
    ],
    [1, 3.5, 4.5, 3.5, 3.5, 2.5]
)

# ---- 1.4 目标用户画像 ----
add_heading('1.4 目标用户画像', 2)
create_table(
    ['用户类型', '占比(推测)', '典型采购场景', '决策特点', '采购频次', '客单价区间'],
    [
        # TODO: 至少5类用户
        ['# TODO: 类型1', '~XX%', '', '', '', ''],
        ['# TODO: 类型2', '~XX%', '', '', '', ''],
        ['# TODO: 类型3', '~XX%', '', '', '', ''],
        ['# TODO: 类型4', '~XX%', '', '', '', ''],
        ['# TODO: 类型5', '~XX%', '', '', '', ''],
    ],
    [3, 2.2, 4, 3.5, 2, 3.3]
)

# ---- 1.5 产品生命周期判断 ----
add_heading('1.5 产品生命周期判断', 2)
add_para('生命周期定位：□导入期  □成长期  □成熟期  □衰退期', bold=True)

add_heading('判断依据', 3)
create_table(
    ['判断维度', '数据/事实', '来源', '日期'],
    [
        ['全球市场规模与CAGR', '# TODO: 规模 + 年增长率', '', ''],
        ['中国市场规模与增速', '# TODO: 规模 + 同比增速', '', ''],
        ['技术迭代频率', '# TODO: 技术更新周期', '', ''],
        ['新进入者数量趋势', '# TODO: 近年新增玩家情况', '', ''],
        ['替代品威胁程度', '# TODO: 替代方案成熟度', '', ''],
        ['未来驱动因素', '# TODO: 增长驱动力', '', ''],
        ['未来制约因素', '# TODO: 制约增长的因素', '', ''],
    ],
    [4, 6, 3, 3]
)

# ---- 1.6 技术发展趋势（新增） ----
add_heading('1.6 技术发展趋势', 2)
create_table(
    ['趋势方向', '具体表现', '对从业者的影响', '时间窗口', '应对建议'],
    [
        ['自动化/智能化', '# TODO: AI/IoT集成等', '', '近1-3年', ''],
        ['绿色环保要求', '# TODO: 节能减排法规等', '', '', ''],
        ['新材料适配', '# TODO: 新型材料的加工能力', '', '', ''],
        ['数字化集成', '# TODO: 工业4.0/云端管理', '', '', ''],
        ['其他前沿趋势', '# TODO: 其他值得关注的趋势', '', '', ''],
    ],
    [3.5, 5, 4, 2.5, 4]
)

# ---- 1.7 准入壁垒分析（新增） ----
add_heading('1.7 准入壁垒分析', 2)
create_table(
    ['壁垒类型', '严重程度', '具体说明', '突破成本估算', '耗时估算'],
    [
        ['技术专利壁垒', '高/中/低', '# TODO:', '# TODO:', '# TODO:'],
        ['认证资质壁垒', '高/中/低', '# TODO: CE/UL/FDA等', '# TODO:', '# TODO:'],
        ['资金门槛', '高/中/低', '# TODO: 初始投入需求', '# TODO:', '# TODO:'],
        ['人才/技术积累', '高/中/低', '# TODO: 所需专业人才', '# TODO:', '# TODO:'],
        ['品牌认知度', '高/中/低', '# TODO: 品牌建设难度', '# TODO:', '# TODO:'],
        ['渠道资源', '高/中/低', '# TODO: 渠道获取难度', '# TODO:', '# TODO:'],
    ],
    [3.5, 2.5, 5.5, 3, 3]
)

# ---- 1.8 政策法规环境（新增） ----
add_heading('1.8 政策法规环境', 2)
add_heading('产品安全认证要求', 3)
create_table(
    ['认证类型', '适用地区', '具体要求', '费用范围', '周期', '必要性'],
    [
        ['CE认证', '欧盟', '# TODO: 适用指令', '# TODO:', '# TODO:', '必须/推荐'],
        ['UL认证', '北美', '# TODO:', '# TODO:', '# TODO:', ''],
        ['CCC认证', '中国国内', '# TODO:', '# TODO:', '# TODO:', ''],
        ['其他认证', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
    ],
    [3, 3, 5, 2.5, 2, 3.5]
)

add_heading('环保与贸易法规', 3)
create_table(
    ['法规类别', '适用地区', '具体要求', '合规成本', '对你的影响'],
    [
        ['环保法规(RoHS/REACH)', '欧盟', '# TODO:', '# TODO:', ''],
        ['出口关税', '目标市场国', '# TODO: 关税税率', '# TODO:', ''],
        ['行业特定法规', '# TODO:', '# TODO:', '# TODO:', ''],
    ],
    [4.5, 3.5, 5.5, 2.5, 3]
)


# ==================== PART 2：市场需求验证 ====================
add_heading('板块二：市场需求验证', 1)

# ---- 2.1 推荐关键词体系 ----
add_heading('2.1 推荐关键词体系（跨境营销用）', 2)
create_table(
    ['类别', '关键词', '热度星级', '月搜索量估算', '适用平台', 'CPC参考(USD)'],
    [
        ['# TODO: 核心主词', '', '★★★★★', '', 'Alibaba/Google', ''],
        ['# TODO: 功能长尾词1', '', '★★★★☆', '', 'Google/YouTube', ''],
        ['# TODO: 功能长尾词2', '', '★★★☆☆', '', '', ''],
        ['# TODO: 品牌/型号词', '', '★★☆☆☆', '', 'Amazon/eBay', ''],
        ['# TODO: 问题解决型词', '', '★★★★☆', '', 'Quora/论坛', ''],
        ['# TODO: 替代品对比词', '', '★★☆☆☆', '', '全平台', ''],
    ],
    [3.5, 4.5, 2.5, 3, 4, 2.5]
)

# ---- 2.2 各平台热度概览 ----
add_heading('2.2 各平台热度概览', 2)
create_table(
    ['平台类型', '平台名称', '卖家数量级', 'Listing质量', '价格透明度', '入驻门槛', '综合评分'],
    [
        ['B2B', 'Alibaba.com', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '★☆~★★★★'],
        ['B2B', 'Made-in-China', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
        ['B2B', 'Global Sources', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
        ['国内批发', '1688.com', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
        ['贸易数据', 'Volza/Panjiva', '# TODO:', 'N/A', 'N/A', 'N/A', ''],
        ['B2C', 'Amazon Business', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
        ['社交电商', 'TikTok Shop', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
    ],
    [2.2, 3.5, 2.8, 2.3, 2.3, 2.2, 2.7]
)

# ---- 2.3 社交媒体热度 ----
add_heading('2.3 社交媒体与内容热度分析', 2)
create_table(
    ['平台', '内容类型', '发布频率(推测)', '平均互动量', '头部账号数', '商业化程度'],
    [
        ['YouTube', '产品演示/教程/测评', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['LinkedIn', '行业讨论/B2B推广', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['TikTok', '操作展示/创意应用', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['Reddit', '专业讨论/问答', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['行业论坛', '技术交流/采购需求', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['Facebook Groups', '社群互动', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
    ],
    [2.5, 4, 2.8, 2.5, 2.5, 3.7]
)

# ---- 2.4 典型Listing参考 ----
add_heading('2.4 典型Listing深度参考', 2)
create_table(
    ['序号', '平台', '卖家', '型号/规格', '价格(USD)', 'MOQ', '发货地', '销量信号', '备注'],
    [
        ['1', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
        ['2', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
        ['3', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
        ['4', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
        ['5', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
    ],
    [1, 2, 2.5, 3, 2.2, 1.5, 2, 2, 2.3]
)

# ---- 2.5 季节性与周期性 ----
add_heading('2.5 季节性与周期性分析', 2)
create_table(
    ['分析维度', '发现', '影响程度', '应对建议'],
    [
        ['季节性特征', '# TODO: 淡旺季分布', '高/中/低', '# TODO:'],
        ['行业关联周期', '# TODO: 与上下游关系', '高/中/低', '# TODO:'],
        ['经济周期敏感度', '# TODO: 对经济波动反应', '高/中/低', '# TODO:'],
        ['地缘政治影响', '# TODO: 贸易战/制裁等', '高/中/低', '# TODO:'],
    ],
    [3.5, 5.5, 2.5, 5.5]
)

# ---- 2.6 地域分布 ----
add_heading('2.6 全球地域分布（按出口目的地）', 2)
create_table(
    ['区域/代表国家', '市场规模占比', '需求特征', '偏好价位段', '准入门槛', '年增速', '竞争激烈度'],
    [
        ['北美（美国/加拿大/墨西哥）', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['欧洲（德/英/法/意/荷等）', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['东南亚', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['中东', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['南美（巴西/阿根廷/智利等）', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['非洲', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['大洋洲（澳/新）', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['其他新兴市场', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
    ],
    [4.5, 2.5, 3, 2.5, 2.5, 1.8, 2.2]
)

# ---- 2.7 替代品与互补品（新增） ----
add_heading('2.7 替代品与互补品分析', 2)
add_para('替代品威胁评估：', bold=True)
create_table(
    ['替代品/方案', '替代程度', '优劣势对比', '价格对比(相对本产品)', '市场份额侵蚀风险'],
    [
        ['# TODO: 直接替代品1', '高/中/低', '# TODO:', '# 更贵/持平/更便宜', '高/中/低'],
        ['# TODO: 直接替代品2', '高/中/低', '# TODO:', '#', '高/中/低'],
        ['# TODO: 间接替代品', '高/中/低', '# TODO:', '#', '高/中/低'],
        ['# TODO: 手工/传统方式', '高/中/低', '# TODO:', '#', '高/中/低'],
    ],
    [3.5, 2.2, 4.5, 3.5, 3.3]
)

add_para('互补品连带销售机会：', bold=True)
create_table(
    ['互补品', '关联强度', '连带销售潜力', '市场规模', '进入难度', '优先级'],
    [
        ['# TODO: 互补品1', '强/中/弱', '# TODO:', '# TODO:', '易/中/难', 'P0-P3'],
        ['# TODO: 互补品2', '强/中/弱', '# TODO:', '# TODO:', '易/中/难', ''],
        ['# TODO: 互补品3', '强/中/弱', '# TODO:', '# TODO:', '易/中/难', ''],
    ],
    [3.5, 2, 3.5, 3, 2, 2]
)


# ==================== PART 3：竞争格局深度分析 ====================
add_heading('板块三：竞争格局深度分析', 1)

# ---- 3.1 卖家密度 ----
add_heading('3.1 卖家密度与市场拥挤度', 2)
create_table(
    ['平台', '卖家数量级', '近12月变化', '新进入者速度', '活跃卖家比例', '拥挤评级'],
    [
        ['# TODO: Alibaba', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '🟢宽松/🟡中等/🔴拥挤'],
        ['# TODO: MIC', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
        ['# TODO: Amazon', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
    ],
    [3.5, 2.8, 2.5, 2.8, 2.7, 3.7]
)

# 拥挤度评级说明
add_info_note('评级标准：🟢 宽松(卖家<200) | 🟡 中等(200-1000) | 🔴 拥挤(>1000)')

# ---- 3.2 头部厂商 ----
add_heading('3.2 国内头部厂商全景图谱', 2)
create_table(
    ['排名', '厂商名称', '所在城市', '成立年限', '主营产品线', '年营收(推测)', '出口比例', '核心优势', '薄弱点'],
    [
        ['1', '# TODO:(真实公司名)', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO%', '# TODO:', '# TODO:'],
        ['2', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO%', '# TODO:', '# TODO:'],
        ['3', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO%', '# TODO:', '# TODO:'],
        ['4', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO%', '# TODO:', '# TODO:'],
        ['5', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO%', '# TODO:', '# TODO:'],
        ['6-10', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO%', '# TODO:', '# TODO:'],
    ],
    [1, 3.5, 2.3, 1.8, 3, 2.3, 1.8, 2.5, 2.8]
)

add_warning_box('⚠️ 以上所有厂商名称必须通过搜索确认真实存在，禁止编造！')

add_heading('国际TOP品牌/厂商', 3)
create_table(
    ['品牌', '国家', '定位', '价格区间(USD)', '中国市场份额', '全球策略', '对中国制造威胁度'],
    [
        ['# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '高/中/低'],
        ['# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
        ['# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
    ],
    [2.5, 2, 2, 2.8, 2.5, 3, 3.2]
)

# ---- 3.3 集中度 ----
add_heading('3.3 市场集中度分析', 2)
create_table(
    ['指标', '数值', '含义解读', '国际对标'],
    [
        ['CR5（前5名市占率）', '# TODO: XX%', '# TODO:', '# TODO: 对比发达国家同行业'],
        ['CR10（前10名市占率）', '# TODO: XX%', '# TODO:', '# TODO:'],
        ['HHI指数', '# TODO:', '# TODO:', '# TODO: <1500碎片化/1500-2500中等/>2500集中'],
        ['集中度判断', '□高集中 □中等分散 □高度碎片化', '', ''],
    ],
    [4, 3, 5, 5]
)

add_para('产业聚集区域：# TODO: 主要产地省份/城市集群', bold=True)
add_bullet('# TODO: 集群1 — 城市/省份 — 特色说明')
add_bullet('# TODO: 集群2 — 城市/省份 — 特色说明')
add_bullet('# TODO: 出口格局 — 主要口岸 + 目的国别TOP5')

# ---- 3.4 SWOT分析（新增） ----
add_heading('3.4 SWOT分析矩阵（行业整体视角）', 2)
create_table(
    ['', '有利因素 (内部S/外部O)', '', '不利因素 (内部W/外部T)', ''],
    [
        ['**内部**', '**S 优势 Strengths**', '', '**W 劣势 Weaknesses**', ''],
        ['', '# TODO: S1 行业整体优势', '', '# TODO: W1 行业整体短板', ''],
        ['', '# TODO: S2', '', '# TODO: W2', ''],
        ['', '# TODO: S3', '', '# TODO: W3', ''],
        ['**外部**', '**O 机会 Opportunities**', '', '**T 威胁 Threats**', ''],
        ['', '# TODO: O1 市场层面机会', '', '# TODO: T1 市场层面威胁', ''],
        ['', '# TODO: O2', '', '# TODO: T2', ''],
        ['', '# TODO: O3', '', '# TODO: T3', ''],
    ],
    [2.5, 5.5, 0.5, 5.5, 0.5]
)

# ---- 3.5 差异化空间 ----
add_heading('3.5 差异化空间分析（机会地图）', 2)
create_table(
    ['编号', '现有竞品的普遍不足', '改进方向（你的机会）', '难度评估', '预期收益', '优先级'],
    [
        ['D1', '# TODO:', '# TODO:', '易/中/难', '# TODO:', 'P0/P1/P2/P3'],
        ['D2', '# TODO:', '# TODO:', '易/中/难', '# TODO:', ''],
        ['D3', '# TODO:', '# TODO:', '易/中/难', '# TODO:', ''],
        ['D4', '# TODO:', '# TODO:', '易/中/难', '# TODO:', ''],
        ['D5', '# TODO:', '# TODO:', '易/中/难', '# TODO:', ''],
        ['D6', '# TODO:', '# TODO:', '易/中/难', '# TODO:', ''],
        ['D7', '# TODO:', '# TODO:', '易/中/难', '# TODO:', ''],
        ['D8', '# TODO:', '# TODO:', '易/中/难', '# TODO:', ''],
    ],
    [1.3, 5, 5, 2, 2.5, 2.2]
)

# ---- 3.6 价格带 ----
add_heading('3.6 价格带全谱分析', 2)
create_table(
    ['价位段', '价格区间(USD)', '典型配置/规格', '代表品牌/厂商', '目标客户群体', '毛利率(推测)', '市场份额'],
    [
        ['经济型/入门', '$# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:%', '# TODO:'],
        ['性价比/中端主力', '$# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:%', '# TODO:'],
        ['高端专业型', '$# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:%', '# TODO:'],
        ['顶级/旗舰/进口', '$# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:%', '# TODO:'],
    ],
    [3, 2.8, 3.5, 3.5, 3.5, 2.2, 2]
)

# ---- 3.7 竞品营销拆解（新增） ----
add_heading('3.7 竞品营销策略拆解', 2)
create_table(
    ['竞品', '定价策略', '渠道布局', '推广方式', '内容策略', '服务模式', '弱点可利用'],
    [
        ['# TODO: 竞品A（真实品牌名）', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['# TODO: 竞品B（真实品牌名）', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['# TODO: 竞品C（真实品牌名）', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
    ],
    [3, 2.5, 2.5, 2.5, 2.5, 2.5, 3.5]
)


# ==================== PART 4：利润与供应链深度测算 ====================
add_heading('板块四：利润与供应链深度测算', 1)

# ---- 4.1 成本结构 ----
add_heading('4.1 成本结构表（以主力机型为例）', 2)
add_para('假设前提：# TODO: 说明售价目标、渠道、目标市场、起订量等假设条件', italic=True)

create_table(
    ['序号', '成本项目', '金额(本币)', '占售价比', '说明', '优化空间'],
    [
        ['1', '产品采购/生产成本（FOB出厂价）', '# TODO:', '# TODO:%', '# TODO:', '# TODO:'],
        ['2', '定制包装材料（木箱/纸箱）', '# TODO:', '# TODO:%', '# TODO:', ''],
        ['3', '国内物流（厂→港口）', '# TODO:', '%', '# TODO:', ''],
        ['4', '国际运费（海运）', '# TODO:', '%', '# TODO: 按CBM计算', ''],
        ['5', '清关报关费用', '# TODO:', '%', '# TODO:', ''],
        ['6', '目的港关税+VAT', '# TODO:', '%', '# TODO: 依目的国而定', ''],
        ['7', '平台佣金+交易手续费', '# TODO:', '%', '# TODO: Alibaba~5%,Amazon~15%', ''],
        ['8', '广告/推广费(P4P/SEM)', '# TODO:', '%', '# TODO: 按营收比反推', ''],
        ['9', '认证检测费（年度摊销）', '# TODO:', '%', '# TODO:', ''],
        ['10', '仓储管理费', '# TODO:', '%', '# TODO:', ''],
        ['11', '售后服务预留金', '# TODO:', '%', '# TODO: 备件库+远程支持', ''],
        ['12', '坏账/退款预留', '# TODO:', '%', '# TODO:', ''],
        ['13', '汇率波动缓冲', '# TODO:', '%', '# TODO:', ''],
        ['', '**总成本合计**', '**# TODO:**', **-**, '', ''],
    ],
    [1, 5.5, 2.5, 2.2, 4, 3.8]
)

# ---- 4.2 利润情景分析 ----
add_heading('4.2 利润情景分析', 2)
create_table(
    ['指标', '悲观估计(-20%)', '保守估计(基准)', '乐观估计(+20%)', '最佳情况', '备注'],
    [
        ['建议零售价(USD)', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '对标竞品定价'],
        ['总成本(RMB)', '# TODO:', '# TODO:', '# TODO:', '# TODO:', '含上述全部成本项'],
        ['单台毛利(RMB)', '# TODO:', '# TODO:', '# TODO:# TODO:', '# TODO:', ''],
        ['毛利率(%)', '# TODO:%', '# TODO:%', '# TODO:%', '# TODO:%', ''],
        ['净利率(%)', '# TODO:%', '# TODO:%', '# TODO:%', '# TODO:%', '扣除运营费用后'],
        ['盈亏平衡销量(台/年)', '# TODO:', '# TODO:', '# TODO:', '# TODO:', ''],
    ],
    [3.5, 2.8, 2.8, 2.8, 2.8, 3.3]
)

# ⚠️ 低毛利警告框（按需取消注释）
# add_warning_box('该产品保守毛利率 < 15%，纯贸易模式毛利极薄，必须走 OEM贴牌/高端路线/增值服务才能盈利。详见4.6警告规则。')

# ---- 4.3 敏感性分析（新增） ----
add_heading('4.3 敏感性分析', 2)
create_table(
    ['变动因素', '变动幅度', '对毛利率的影响', '风险等级', '应对措施建议'],
    [
        ['采购成本上升', '+10%', '# TODO: 影响XX个百分点', '🟢低/🟡中/🔴高', '# TODO:'],
        ['国际海运费波动', '+20%', '# TODO:', '🟢/🟡/🔴', '# TODO:'],
        ['汇率变动(人民币升值)', '+5%', '# TODO:', '🟢/🟡/🔴', '# TODO:'],
        ['平台佣金上调', '+3%', '# TODO:', '🟢/🟡/🔴', '# TODO:'],
        ['竞品降价压力', '-10%', '# TODO:', '🟢/🟡/🔴', '# TODO:'],
        ['关税上调', '+5%', '# TODO:', '🟢/🟡/🔴', '# TODO:'],
    ],
    [3.5, 2.5, 3.5, 2.8, 4.7]
)

# ---- 4.4 关键财务指标 ----
add_heading('4.4 关键财务指标', 2)
create_table(
    ['维度', '详细分析', '影响程度', '改善建议'],
    [
        ['复购/回购可能性', '# TODO: 设备本身低复购但备件/耗材可持续产生收入', '★★☆~★★★★', '# TODO:'],
        ['连带销售(LTV提升)', '# TODO: 配件/耗材/培训/增值服务的追加销售潜力', '', '# TODO:'],
        ['资金周转周期', '# TODO: 下单→生产→发货→收款的完整周期(天)', '', '# TODO:'],
        ['库存占用风险', '# TODO: 单台价值×库存周转天数', '', '# TODO:'],
        ['现金流健康度', '# TODO: 预付款比例+账期+回款可靠性', '', '# TODO:'],
    ],
    [3.5, 6.5, 2.5, 4.5]
)

# ---- 4.5 经营模式对比（新增） ----
add_heading('4.5 不同经营模式的盈利对比', 2)
create_table(
    ['经营模式', '毛利区间', '所需能力', '启动资金', '风险等级', '适合阶段'],
    [
        ['纯贸易(倒手)', '15-25%', '低', '低', '中', '试水期'],
        ['OEM贴牌', '25-40%', '中', '中', '中低', '成长期'],
        ['ODM设计制造', '35-50%', '中高', '中高', '低', '稳定期'],
        ['自有品牌', '40-60%+', '高', '高', '中', '成熟期'],
    ],
    [3.5, 2.5, 3, 2.2, 2.3, 3.5]
)

# ---- 4.6 警告规则 ----
add_heading('4.6 关键警告规则检查', 2)
create_table(
    ['触发条件', '是否触发', '警告文案'],
    [
        ['保守毛利率 < 15%', '□是 □否', '⚠️ 纯贸易模式毛利极薄，须走OEM贴牌/高端路线/增值服务'],
        ['竞争密度为🔴拥挤', '□是 □否', '⚠️ 红海赛道，必须有明确差异化优势才能进入'],
        ['准入壁垒"高"超过3项', '□是 □否', '⚠️ 准入壁垒较高，前期投入和时间成本需重新评估'],
        ['替代品威胁"高"', '□是 □否', '⚠️ 存在高威胁替代品，需密切跟踪技术替代趋势'],
        ['盈亏平衡销量>50%年销量', '□是 □否', '⚠️ 盈亏平衡点偏高，销量不及预期时亏损风险较大'],
    ],
    [5, 2, 9]
)


# ==================== PART 5：自身匹配度评估 ====================
add_heading('板块五：自身匹配度评估（核心维度）', 1)

company_label = get_company_label()
add_para(f'评估基准：{company_label}', italic=True)

# 如果有企业信息，列出摘要
if COMPANY_NAME:
    add_para(f'企业名称：{COMPANY_NAME}', bold=True)
    if COMPANY_SCALE:
        add_para(f'企业规模：{COMPANY_SCALE}')
    if COMPANY_MAIN_BUSINESS:
        add_para(f'主营业务：{COMPANY_MAIN_BUSINESS}')
    if COMPANY_CHANNELS:
        add_para(f'核心渠道：{COMPANY_CHANNELS}')
    if COMPANY_TARGET_MARKETS:
        add_para(f'目标市场：{COMPANY_TARGET_MARKETS}')
    if COMPANY_BUDGET:
        add_para(f'测试预算：{COMPANY_BUDGET}')
else:
    add_info_note('未提供企业信息，本部分以"入局所需能力基准"呈现，供自我评估。')

# ---- 5.1 能力匹配雷达图（六大维度） ----
add_heading('5.1 能力匹配雷达图（六大维度）', 2)
create_table(
    ['评估维度', '权重', '所需能力描述', '自评(1-5)', '加权得分', '差距分析与补强路径'],
    [
        ['技术/产品理解力', '20%', '# TODO: 是否懂技术原理和应用？', '# TODO: /5', '# TODO: /20', '# TODO:'],
        ['生产/供应能力', '20%', '# TODO: 是否有稳定货源/生产能力？', '# TODO: /5', '# TODO: /20', '# TODO:'],
        ['资金实力', '15%', '# TODO: 能否支撑前期投入和库存？', '# TODO: /5', '# TODO: /15', '# TODO:'],
        ['渠道运营能力', '15%', '# TODO: 是否有成熟获客转化渠道？', '# TODO: /5', '# TODO: /15', '# TODO:'],
        ['售后/服务能力', '15%', '# TODO: 有无能力处理售后问题？', '# TODO: /5', '# TODO: /15', '# TODO:'],
        ['行业人脉/资源', '15%', '# TODO: 是否有现成行业资源和客户？', '# TODO: /5', '# TODO: /15', '# TODO:'],
        ['**总分**', '**100%**', '', '**# TODO: /5**', '**# TODO: /100**', ''],
    ],
    [3.5, 1.3, 5, 2.2, 2.2, 5.8]
)

add_para('评分解读：80-100分高度匹配 | 60-79分基本匹配 | 40-59分部分匹配 | 0-39分匹配度低', italic=True, size=10)

# ---- 5.2 供应链匹配 ----
add_heading('5.2 供应链匹配度评估', 2)
create_table(
    ['评估项', '情况分析', '匹配度', '风险提示'],
    [
        ['现有供应商可复用性', '# TODO:', '✅✅/✅/⚠️/❌', '# TODO:'],
        ['新供应商寻找难度', '# TODO:', '易/中等/难', '# TODO:'],
        ['供应商稳定性风险', '# TODO:', '高/中/低', '# TODO:'],
        ['起订量(MOQ)要求', '# TODO:', '# TODO:', ''],
        ['供货周期(Lead Time)', '# TODO:', '# TODO: 天', ''],
        ['OEM/ODM可能性', '# TODO:', '# TODO:', ''],
        ['最小起订金额', '# TODO:', '# TODO:', ''],
        ['付款条件', '# TODO:', '# TODO:', ''],
    ],
    [4, 5, 2.5, 5.5]
)

# ---- 5.3 渠道匹配 ----
add_heading('5.3 渠道与营销匹配度', 2)
create_table(
    ['渠道', '适用性', '匹配度(1-5)', '理由分析', '优先级建议'],
    [
        ['阿里巴巴国际站', '✅/❌', '# TODO: ★☆', '# TODO:', 'P0/P1/P2/P3'],
        ['Made-in-China', '✅/❌', '# TODO:', '# TODO:', ''],
        ['独立站(SEO+SEM)', '✅/❌', '# TODO:', '# TODO:', ''],
        ['Amazon Business', '✅/❌', '# TODO:', '# TODO:', ''],
        ['TikTok Shop', '✅/❌', '# TODO:', '# TODO:', ''],
        ['线下展会/地推', '✅/❌', '# TODO:', '# TODO:', ''],
        ['本地经销商代理', '✅/❌', '# TODO:', '# TODO:', ''],
        ['行业垂直平台', '✅/❌', '# TODO:', '# TODO:', ''],
    ],
    [3.5, 2, 2.3, 5.5, 2.7]
)

# ---- 5.4 风险矩阵 ----
add_heading('5.4 全面风险矩阵（10大风险）', 2)
create_table(
    ['编号', '风险类型', '详细描述', '概率', '影响', '等级', '可承受?', '缓解措施'],
    [
        ['R01', '质量稳定性风险', '# TODO:', '高/中/低', '高/中/低', '🟢🟡🔴', '是/否', '# TODO:'],
        ['R02', '售后复杂度风险', '# TODO:', '高/中/低', '高/中/低', '🟢🟡🔴', '是/否', '# TODO:'],
        ['R03', '认证合规风险', '# TODO:', '高/中/低', '高/中/低', '🟢🟡🔴', '是/否', '# TODO:'],
        ['R04', '资金占用风险', '# TODO:', '高/中/低', '高/中/低', '🟢🟡🔴', '是/否', '# TODO:'],
        ['R05', '知识产权风险', '# TODO:', '高/中/低', '高/中/低', '🟢🟡🔴', '是/否', '# TODO:'],
        ['R06', '季节性过时风险', '# TODO:', '高/中/低', '高/中/低', '🟢🟡🔴', '是/否', '# TODO:'],
        ['R07', '汇率波动风险', '# TODO:', '高/中/低', '高/中/低', '🟢🟡🔴', '是/否', '# TODO:'],
        ['R08', '供应链断裂风险', '# TODO:', '高/中/低', '高/中/低', '🟢🟡🔴', '是/否', '# TODO:'],
        ['R09', '政策关税变动风险', '# TODO:', '高/中/低', '高/中/低', '🟢🟡🔴', '是/否', '# TODO:'],
        ['R10', '客户集中度风险', '# TODO:', '高/中/低', '高/中/低', '🟢🟡🔴', '是/否', '# TODO:'],
    ],
    [1.3, 2.8, 4, 1.5, 1.5, 1.5, 1.8, 4.6]
)

# ---- 5.5 波特五力模型（新增） ----
add_heading('5.5 波特五力竞争位势分析', 2)
create_table(
    ['力量维度', '强度', '详细分析', '对你（入局者）的含义'],
    [
        ['现有竞争者对抗强度', '强/中/弱', '# TODO: 价格战/营销战/创新竞争程度', '# TODO:'],
        ['潜在进入者威胁', '强/中/弱', '# TODO: 新玩家进入的门槛和意愿', '# TODO:'],
        ['替代品威胁', '强/中/弱', '# TODO: 替代方案对市场的冲击', '# TODO:'],
        ['供应商议价能力', '强/中/弱', '# TODO: 上游供应链的议价权', '# TODO:'],
        ['买方（客户）议价能力', '强/中/弱', '# TODO: 下游客户的议价权', '# TODO:'],
    ],
    [3.5, 2, 5, 6.5]
)

# ---- 5.6 协同效应 ----
add_heading('5.6 行业协同效应（跨品类机会）', 2)
if COMPANY_NAME and COMPANY_MAIN_BUSINESS:
    create_table(
        ['现有业务线', '与新品的协同点', '客户复用率', '资源共享度', '协同评分'],
        [
            ['# TODO: 用户现有产品A', '# TODO:', '# TODO: 高/中/低', '# TODO: 高/中/低', '# TODO:/10'],
            ['# TODO: 用户现有产品B', '# TODO:', '# TODO:', '# TODO:', '# TODO:/10'],
            ['# TODO: 用户现有产品C', '# TODO:', '# TODO:', '# TODO:', '# TODO:/10'],
        ],
        [3.5, 5, 2.5, 2.5, 2.5]
    )
else:
    add_info_note('建议梳理现有客户群和产品线，评估跨品类销售的协同效应。协同效应越高，新品推广成本越低、成功率越高。')


# ==================== 最终结论 ====================
add_heading('最终结论', 1)

# 决策结论标题
# p = doc.add_paragraph()
# run = p.add_run('✅ 强烈推荐（Strongly Recommend）')  # 三选一
# run.bold = True
# run.font.size = Pt(16)
# run.font.color.rgb = RGBColor(0x00, 0x80, 0x00)  # 绿色
add_para('# TODO: ✅强烈推荐 / ✅有条件推荐 / ❌不建议做 （三选一，必须明确）',
         bold=True, size=14, color=(0x1F, 0x4E, 0x79))

add_heading('一、决策结论（一句话）', 2)
add_para('# TODO: 明确判断 + 核心理由一句话概括')

add_heading('二、核心理由（3条）', 2)
add_bullet('# TODO: 理由1（每条一句话，有数据支撑）')
add_bullet('# TODO: 理由2')
add_bullet('# TODO: 理由3')

add_heading('三、核心挑战/风险（3条）', 2)
add_bullet('# TODO: 挑战1（最大风险之一）')
add_bullet('# TODO: 挑战2')
add_bullet('# TODO: 挑战3')

add_heading('四、关键假设条件', 2)
add_bullet('# TODO: 假设1（如：汇率稳定在XX范围内）')
add_bullet('# TODO: 假设2（如：无重大政策变化）')
add_bullet('# TODO: 假设3（其他关键假设）')

add_heading('五、MVP快速验证方案（7天零预算）', 2)
create_table(
    ['步骤', '时间', '动作', '具体执行方法', '预期产出', '花费'],
    [
        ['Day 1', '1天', '信息收集', '# TODO: 各平台搜索产品信息和竞品', 'Excel竞品汇总表', '￥0'],
        ['Day 2', '1天', '深度调研', '# TODO: 联系3-5家供应商询价', '供应商报价对比表', '￥0'],
        ['Day 3', '1天', '客户验证', '# TODO: 向潜在客户询问需求意向', '5-10条客户反馈', '￥0'],
        ['Day 4', '1天', '利润测算', '# TODO: 基于报价做详细成本核算', '利润测算初稿', '￥0'],
        ['Day 5', '1天', '竞品体验', '# TODO: 申请样品或观看竞品演示视频', '竞品体验笔记', '￥0(或有少量样品费)'],
        ['Day 6', '1天', '合规排查', '# TODO: 查询目标市场认证要求', '合规检查清单', '￥0'],
        ['Day 7', '1天', '决策复盘', '# TODO: 汇总全部信息做GO/NO-GO决策', 'MVP验证结论报告', '￥0'],
        ['', '**合计**', '', '', '', '**≈￥0**'],
    ],
    [1.5, 1.3, 2, 5.5, 3.5, 2.2]
)

add_heading('六、分阶段投入计划', 2)

add_para('第一阶段（试水期）：预算 ' + (COMPANY_BUDGET or '# TODO: 建议1-3万'), bold=True)
create_table(
    ['投入项', '预算', '目的', '预期产出', '成功指标'],
    [
        ['样品采购', '# TODO:', '获取实物了解产品', '1-2台样机', '完成产品熟悉'],
        ['基础物料制作', '# TODO:', '图片/视频/文案素材', '完整产品资料包', '可上架使用'],
        ['小额测款', '# TODO:', '平台少量广告测试', '点击/询盘数据', 'ROI > 1:3'],
        ['第一阶段小计', '# TODO:', '', '', ''],
    ],
    [3, 2.5, 4, 3.5, 3]
)

add_para('第二阶段（成长期）：预算 ' + (COMPANY_BUDGET or '# TODO: 建议5-10万') + '（视第一阶段结果决定是否推进）', bold=True)
create_table(
    ['投入项', '预算', '目的', '预期产出', '成功指标'],
    [
        ['# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['第二阶段小计', '# TODO:', '', '', ''],
    ],
    [3, 2.5, 4, 3.5, 3]
)

add_para('第三阶段（扩张期）：预算视第一二阶段结果调整', bold=True)
create_table(
    ['投入项', '预算', '目的', '预期产出', '成功指标'],
    [
        ['# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['# TODO:', '# TODO:', '# TODO:', '# TODO:', '# TODO:'],
        ['第三阶段小计', '# TODO:', '', '', ''],
    ],
    [3, 2.5, 4, 3.5, 3]
)


# ==================== 附录 ====================
add_heading('附录', 1)

add_heading('附录A：数据来源列表', 2)
add_bullet('# TODO: 来源1（注明URL和访问日期）')
add_bullet('# TODO: 来源2（注明URL和访问日期）')
add_bullet('# TODO: 来源3')
add_bullet('# TODO: 来源4')
add_bullet('# TODO: 来源5')
add_bullet('# TODO: 来源6+...')

add_heading('附录B：术语表', 2)
create_table(
    ['术语', '英文/缩写', '解释'],
    [
        ['# TODO:', '# TODO:', '# TODO:'],
        ['# TODO:', '# TODO:', '# TODO:'],
        ['# TODO:', '# TODO:', '# TODO:'],
    ],
    [3, 3.5, 10.5]
)

add_heading('附录C：参考资料与延伸阅读', 2)
add_bullet('# TODO: 参考资料链接/文献')
add_bullet('# TODO: 相关行业报告')

# 声明
doc.add_paragraph()
p = doc.add_paragraph()
run = p.add_run('声明：')
run.bold = True
run.font.size = Pt(10)
run.font.color.rgb = RGBColor(0x88, 0x88, 0x88)
run.font.name = 'Microsoft YaHei'
run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
run = p.add_run('\n本报告中标注"推测"的数据为基于行业经验的合理估算，未经第三方审计验证。所有市场数据均来自公开渠道的联网搜索，标注了获取日期。价格、销量、市场规模等数据受市场波动影响可能发生变化，建议在实际决策前进行二次核实。本报告仅供参考，不构成投资或商业决策建议。')
run.italic = True
run.font.size = Pt(10)
run.font.color.rgb = RGBColor(0x88, 0x88, 0x88)
run.font.name = 'Microsoft YaHei'
run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')

# Save
output_path = fr'C:\Users\alex\Desktop\{OUTPUT_FILENAME}'
doc.save(output_path)
print(f'Report saved to: {output_path}')
print(f'Total tables generated: ~30+')  # 实际表格数量统计
