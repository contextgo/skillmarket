---
name: customer-service
description: >
  客服服务 Skill。当用户需要：
  - 回答客户关于产品的咨询问题
  - 根据知识库解决产品使用问题
  - 处理售后服务和技术支持请求
  - 记录无法解答的问题到工单
  - 涉及客户反馈、投诉处理、退换货等场景
  触发词：客服、客户问题、售后服务、技术支持、产品咨询、使用帮助、问题反馈、退换货、投诉建议、知识库问答、工单
---

# 客服服务 Skill

本 Skill 提供基于知识库的智能客服能力，支持多产品线知识库检索、自动分类、亲切回复和工单记录。

## 快速配置

首次使用前，请编辑 `references/config.toml` 配置文件：

```toml
[knowledge_base]
root_dir = "./knowledge"      # 知识库目录

[tickets]
dir = "./tickets"             # 工单目录

[reply]
style = "warm"               # warm(温暖) / professional(专业) / concise(简洁)
```

## 核心能力

| 功能 | 说明 |
|------|------|
| **知识库检索** | 支持 Markdown、JSON、YAML、TXT 格式 |
| **智能分类** | 自动识别：功能咨询/使用问题/售后/技术支持/投诉 |
| **工单记录** | 无法解答的问题自动记录，含优先级判断 |
| **亲切回复** | 朋友式的温暖沟通风格 |

## 工作流程

### Step 1: 初始化配置（如未配置）

```bash
# 查看当前配置
python3 scripts/config_manager.py view

# 初始化默认配置
python3 scripts/config_manager.py init
```

### Step 2: 检索知识库

```bash
python3 scripts/knowledge_search.py \
  --query "会员权益" \
  --product "product-a"        # 可选
  --dir "./knowledge"          # 可选，默认从配置读取
```

### Step 3: 生成回复

根据检索结果，结合 `references/reply_templates.json` 模板生成回复。

### Step 4: 创建工单（如需）

```bash
# 创建工单（优先级自动判断）
python3 scripts/create_ticket.py create \
  --product "产品名称" \
  --category "技术支持" \
  --question "问题描述"

# 查看工单列表
python3 scripts/create_ticket.py list --status pending

# 查看工单详情
python3 scripts/create_ticket.py view TKT-XXXX-XXXXXXXX
```

## 配置文件详解

### knowledge_base 配置

```toml
[knowledge_base]
root_dir = "./knowledge"      # 知识库根目录
top_k = 3                      # 搜索返回结果数量

[knowledge_base.structure]
enable_product_isolation = true  # 是否按产品线隔离
default_product = "common"       # 默认产品线
```

### tickets 配置

```toml
[tickets]
dir = "./tickets"              # 工单存放目录

[tickets.auto_create]
enable = true                  # 是否自动创建工单

[tickets.auto_create.priority_keywords]
urgent = ["急", "崩溃", "无法使用"]   # 紧急关键词
high = ["很久", "一直"]              # 高优先级关键词
```

## 知识库目录结构

建议按产品线组织知识库：

```
knowledge/                      # 根目录（可在配置中修改）
├── product-a/
│   ├── faq.md                 # 常见问题
│   ├── user-guide.md          # 用户指南
│   └── policies.json          # 政策文档
├── product-b/
│   ├── faq.md
│   └── troubleshooting.yaml   # 故障排查
└── shared/
    └── common-questions.txt   # 通用问题
```

## 回复风格

亲切温暖的朋友式沟通：
- 使用表情符号增加亲切感 😊👍💪
- 使用"呀""哦""呢"等语气词
- 主动表达理解和关心
- 不使用生硬的官方腔调

### 回复模板示例

**功能咨询**：
> 关于这个问题，让我帮你查一下：
> [知识库内容]
> 希望这个回答对你有帮助！如果想了解更多，随时告诉我～

**使用问题**：
> 看起来你在使用过程中遇到了点小麻烦，别着急，我来帮你看看：
> [解决步骤]
> 按照这些步骤操作应该可以解决问题。如果还有疑问，随时来找我～

**转工单**：
> 抱歉，关于这个问题我的知识库暂时没有收录 📭
> 我已经帮你记录了（工单号：XXX），专业团队会尽快跟进处理～
> 感谢你的理解和支持 💪

## 工单字段说明

| 字段 | 说明 |
|------|------|
| ticket_id | 工单编号，格式：TKT-产品-时间戳 |
| product | 产品名称 |
| category | 问题类别 |
| priority | 优先级：urgent/high/normal/low |
| status | 状态：pending/processing/resolved/closed |
| question | 问题描述 |
| customer_info | 客户信息 |
| resolution | 解决方案（解决后填写） |

## 文件清单

| 文件 | 用途 |
|------|------|
| `SKILL.md` | 本技能说明文档 |
| `references/config.toml` | 配置文件 |
| `references/reply_templates.json` | 回复模板 |
| `scripts/config_manager.py` | 配置管理脚本 |
| `scripts/knowledge_search.py` | 知识库检索脚本 |
| `scripts/create_ticket.py` | 工单管理脚本 |
