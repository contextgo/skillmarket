#!/usr/bin/env python3
"""
客服工单创建脚本 v2
支持从配置文件读取设置
"""

import os
import sys
import json
import argparse
from datetime import datetime
from pathlib import Path
from typing import Optional, List

# 添加父目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))
from scripts.config_manager import load_config, resolve_path, get_config_value


def determine_priority(question: str, config: dict = None) -> str:
    """
    根据问题内容自动判断优先级

    Args:
        question: 问题内容
        config: 配置字典（可选）

    Returns:
        priority: low / normal / high / urgent
    """
    if config is None:
        config = load_config()

    priority_config = config.get("tickets", {}).get("auto_create", {})
    priority_keywords = priority_config.get("priority_keywords", {})

    urgent_keywords = priority_keywords.get("urgent", [])
    high_keywords = priority_keywords.get("high", [])

    question_lower = question.lower()

    for keyword in urgent_keywords:
        if keyword in question:
            return "urgent"

    for keyword in high_keywords:
        if keyword in question:
            return "high"

    return "normal"


def create_ticket(
    ticket_dir: str,
    product: str,
    category: str,
    question: str,
    customer_info: Optional[dict] = None,
    priority: str = None
) -> str:
    """
    创建客服工单

    Args:
        ticket_dir: 工单目录路径
        product: 产品名称
        category: 问题类别
        question: 客户问题
        customer_info: 客户信息（可选）
        priority: 优先级（可选，自动判断）

    Returns:
        工单编号
    """
    ticket_dir = Path(ticket_dir)
    ticket_dir.mkdir(parents=True, exist_ok=True)

    # 自动判断优先级
    if priority is None:
        config = load_config()
        priority = determine_priority(question, config)

    # 生成工单编号
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    product_code = product.upper()[:4] if product else "MISC"
    ticket_id = f"TKT-{product_code}-{timestamp}"

    # 工单数据
    ticket_data = {
        "ticket_id": ticket_id,
        "created_at": datetime.now().isoformat(),
        "product": product,
        "category": category,
        "priority": priority,
        "status": "pending",
        "question": question,
        "customer_info": customer_info or {},
        "conversation_history": [],
        "resolution": None,
        "resolved_at": None,
        "assigned_to": None
    }

    # 保存工单文件
    ticket_file = ticket_dir / f"{ticket_id}.json"
    with open(ticket_file, 'w', encoding='utf-8') as f:
        json.dump(ticket_data, f, ensure_ascii=False, indent=2)

    return ticket_id


def update_ticket(
    ticket_dir: str,
    ticket_id: str,
    update_data: dict
) -> bool:
    """
    更新工单信息

    Args:
        ticket_dir: 工单目录路径
        ticket_id: 工单编号
        update_data: 更新数据

    Returns:
        是否成功
    """
    ticket_file = Path(ticket_dir) / f"{ticket_id}.json"

    if not ticket_file.exists():
        print(f"Ticket not found: {ticket_id}", file=sys.stderr)
        return False

    with open(ticket_file, 'r', encoding='utf-8') as f:
        ticket_data = json.load(f)

    ticket_data.update(update_data)

    with open(ticket_file, 'w', encoding='utf-8') as f:
        json.dump(ticket_data, f, ensure_ascii=False, indent=2)

    return True


def list_tickets(
    ticket_dir: str,
    status: Optional[str] = None,
    product: Optional[str] = None,
    priority: Optional[str] = None
) -> List[dict]:
    """
    列出工单

    Args:
        ticket_dir: 工单目录路径
        status: 按状态筛选
        product: 按产品筛选
        priority: 按优先级筛选

    Returns:
        工单列表
    """
    ticket_dir = Path(ticket_dir)

    if not ticket_dir.exists():
        return []

    tickets = []
    for ticket_file in ticket_dir.glob("*.json"):
        try:
            with open(ticket_file, 'r', encoding='utf-8') as f:
                ticket_data = json.load(f)

            if status and ticket_data.get('status') != status:
                continue
            if product and ticket_data.get('product') != product:
                continue
            if priority and ticket_data.get('priority') != priority:
                continue

            tickets.append(ticket_data)
        except Exception as e:
            print(f"Error reading {ticket_file}: {e}", file=sys.stderr)

    # 按创建时间倒序
    tickets.sort(key=lambda x: x.get('created_at', ''), reverse=True)
    return tickets


def get_ticket(ticket_dir: str, ticket_id: str) -> Optional[dict]:
    """获取单个工单详情"""
    ticket_file = Path(ticket_dir) / f"{ticket_id}.json"
    if not ticket_file.exists():
        return None

    with open(ticket_file, 'r', encoding='utf-8') as f:
        return json.load(f)


def format_ticket_list(tickets: list) -> str:
    """格式化工单列表"""
    if not tickets:
        return "暂无工单"

    status_emoji = {
        "pending": "⏳",
        "processing": "🔄",
        "resolved": "✅",
        "closed": "🔒"
    }

    priority_emoji = {
        "urgent": "🔴",
        "high": "🟠",
        "normal": "🟡",
        "low": "⚪"
    }

    output = []
    for ticket in tickets:
        status_icon = status_emoji.get(ticket.get('status', ''), "❓")
        priority_icon = priority_emoji.get(ticket.get('priority', ''), "")

        output.append(
            f"{status_icon} {priority_icon} [{ticket['ticket_id']}] {ticket['product']} - {ticket['category']}\n"
            f"   问题: {ticket['question'][:60]}...\n"
            f"   创建: {ticket['created_at'][:10]} | 优先级: {ticket['priority'].upper()}"
        )

    return '\n\n'.join(output)


def format_ticket_detail(ticket: dict) -> str:
    """格式化工单详情"""
    if not ticket:
        return "工单不存在"

    output = [
        f"📋 工单详情: {ticket['ticket_id']}",
        f"",
        f"产品: {ticket['product']}",
        f"类别: {ticket['category']}",
        f"优先级: {ticket['priority'].upper()}",
        f"状态: {ticket['status']}",
        f"创建时间: {ticket['created_at']}",
        f"",
        f"问题描述:",
        f"{ticket['question']}",
    ]

    if ticket.get('customer_info'):
        output.append(f"")
        output.append(f"客户信息: {json.dumps(ticket['customer_info'], ensure_ascii=False)}")

    if ticket.get('resolution'):
        output.append(f"")
        output.append(f"解决方案: {ticket['resolution']}")

    return '\n'.join(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='客服工单管理工具')
    subparsers = parser.add_subparsers(dest='command', help='子命令')

    # create 子命令
    create_parser = subparsers.add_parser('create', help='创建新工单')
    create_parser.add_argument('--dir', '-d', help='工单目录（默认从配置读取）')
    create_parser.add_argument('--product', '-p', required=True, help='产品名称')
    create_parser.add_argument('--category', '-c', required=True,
                              choices=['功能咨询', '使用问题', '售后', '技术支持', '投诉'],
                              help='问题类别')
    create_parser.add_argument('--question', '-q', required=True, help='问题描述')
    create_parser.add_argument('--priority', choices=['low', 'normal', 'high', 'urgent'],
                              help='优先级（默认自动判断）')
    create_parser.add_argument('--customer-name', help='客户姓名')
    create_parser.add_argument('--customer-contact', help='联系方式')

    # list 子命令
    list_parser = subparsers.add_parser('list', help='列出工单')
    list_parser.add_argument('--dir', '-d', help='工单目录（默认从配置读取）')
    list_parser.add_argument('--status', '-s', choices=['pending', 'processing', 'resolved', 'closed'])
    list_parser.add_argument('--product', '-p', help='产品筛选')
    list_parser.add_argument('--priority', help='优先级筛选')

    # view 子命令
    view_parser = subparsers.add_parser('view', help='查看工单详情')
    view_parser.add_argument('--dir', '-d', help='工单目录（默认从配置读取）')
    view_parser.add_argument('ticket_id', help='工单编号')

    # update 子命令
    update_parser = subparsers.add_parser('update', help='更新工单')
    update_parser.add_argument('--dir', '-d', help='工单目录（默认从配置读取）')
    update_parser.add_argument('ticket_id', help='工单编号')
    update_parser.add_argument('--status', '-s', choices=['pending', 'processing', 'resolved', 'closed'])
    update_parser.add_argument('--resolution', '-r', help='解决方案')
    update_parser.add_argument('--assign', '-a', help='指派给')

    args = parser.parse_args()

    # 获取工单目录（从配置或参数）
    def get_ticket_dir():
        if hasattr(args, 'dir') and args.dir:
            return args.dir
        return get_config_value("tickets.dir", "./tickets")

    if args.command == 'create':
        customer_info = {}
        if hasattr(args, 'customer_name') and args.customer_name:
            customer_info['name'] = args.customer_name
        if hasattr(args, 'customer_contact') and args.customer_contact:
            customer_info['contact'] = args.customer_contact

        ticket_id = create_ticket(
            ticket_dir=get_ticket_dir(),
            product=args.product,
            category=args.category,
            question=args.question,
            customer_info=customer_info if customer_info else None,
            priority=args.priority if hasattr(args, 'priority') else None
        )
        print(f"✅ 工单创建成功: {ticket_id}")

    elif args.command == 'list':
        tickets = list_tickets(
            ticket_dir=get_ticket_dir(),
            status=args.status if hasattr(args, 'status') else None,
            product=args.product if hasattr(args, 'product') else None,
            priority=args.priority if hasattr(args, 'priority') else None
        )
        print(format_ticket_list(tickets))

    elif args.command == 'view':
        ticket = get_ticket(
            ticket_dir=get_ticket_dir(),
            ticket_id=args.ticket_id
        )
        print(format_ticket_detail(ticket))

    elif args.command == 'update':
        update_data = {}
        if hasattr(args, 'status') and args.status:
            update_data['status'] = args.status
        if hasattr(args, 'resolution') and args.resolution:
            update_data['resolution'] = args.resolution
            update_data['resolved_at'] = datetime.now().isoformat()
        if hasattr(args, 'assign') and args.assign:
            update_data['assigned_to'] = args.assign

        if update_data:
            success = update_ticket(
                ticket_dir=get_ticket_dir(),
                ticket_id=args.ticket_id,
                update_data=update_data
            )
            if success:
                print(f"✅ 工单已更新: {args.ticket_id}")
            else:
                print(f"❌ 工单更新失败: {args.ticket_id}")
        else:
            print("没有需要更新的字段")

    else:
        parser.print_help()
