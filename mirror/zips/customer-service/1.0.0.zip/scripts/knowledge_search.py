#!/usr/bin/env python3
"""
知识库检索脚本 v2
支持从配置文件读取设置
"""

import os
import sys
import json
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional

# 添加父目录到路径，以便导入 config_manager
sys.path.insert(0, str(Path(__file__).parent.parent))
from scripts.config_manager import load_config, resolve_path, get_config_value


def load_markdown(file_path: Path) -> Dict[str, Any]:
    """加载 Markdown 文件，提取标题和内容"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    sections = {}
    current_title = "通用"
    current_content = []

    for line in content.split('\n'):
        if line.startswith('## '):
            if current_content:
                sections[current_title] = '\n'.join(current_content).strip()
            current_title = line[3:].strip()
            current_content = []
        else:
            current_content.append(line)

    if current_content:
        sections[current_title] = '\n'.join(current_content).strip()

    return {
        'title': file_path.stem,
        'sections': sections,
        'full_content': content
    }


def load_json(file_path: Path) -> Dict[str, Any]:
    """加载 JSON 文件"""
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    if isinstance(data, list):
        return {'items': data, 'title': file_path.stem}
    elif isinstance(data, dict):
        data['title'] = file_path.stem
        return data
    return {'title': file_path.stem, 'data': data}


def load_yaml(file_path: Path) -> Dict[str, Any]:
    """加载 YAML 文件"""
    try:
        import yaml
        with open(file_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
    except ImportError:
        # YAML 库不可用，简单解析
        return {'title': file_path.stem, 'error': 'YAML library not available'}

    if isinstance(data, list):
        return {'items': data, 'title': file_path.stem}
    elif isinstance(data, dict):
        data['title'] = file_path.stem
        return data
    return {'title': file_path.stem, 'data': data}


def load_text(file_path: Path) -> Dict[str, Any]:
    """加载纯文本文件"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    sections = {}
    current_title = "通用"
    current_content = []

    for line in content.split('\n'):
        if line.strip() == '':
            if current_content:
                sections[current_title] = '\n'.join(current_content).strip()
                current_content = []
        elif line.startswith('Q:') or line.startswith('问：'):
            if current_content:
                sections[current_title] = '\n'.join(current_content).strip()
            current_title = line.strip()
            current_content = []
        else:
            current_content.append(line)

    if current_content:
        sections[current_title] = '\n'.join(current_content).strip()

    return {
        'title': file_path.stem,
        'sections': sections,
        'full_content': content
    }


def load_knowledge_file(file_path: Path) -> Optional[Dict[str, Any]]:
    """根据文件扩展名加载知识库文件"""
    suffix = file_path.suffix.lower()

    loaders = {
        '.md': load_markdown,
        '.markdown': load_markdown,
        '.json': load_json,
        '.yaml': load_yaml,
        '.yml': load_yaml,
        '.txt': load_text,
    }

    loader = loaders.get(suffix)
    if loader:
        try:
            return loader(file_path)
        except Exception as e:
            print(f"Error loading {file_path}: {e}", file=sys.stderr)
            return None
    return None


def search_in_text(text: str, keywords: List[str]) -> int:
    """计算关键词在文本中的匹配次数"""
    text_lower = text.lower()
    count = 0
    for keyword in keywords:
        count += text_lower.count(keyword.lower())
    return count


def search_knowledge_base(
    knowledge_dir: str,
    query: str,
    product: Optional[str] = None,
    top_k: int = None,
    file_formats: List[str] = None
) -> List[Dict[str, Any]]:
    """
    搜索知识库

    Args:
        knowledge_dir: 知识库根目录
        query: 查询关键词
        product: 产品线名称（可选）
        top_k: 返回结果数量（默认从配置读取）
        file_formats: 支持的文件格式（默认从配置读取）

    Returns:
        匹配结果列表
    """
    # 加载配置获取默认值
    if top_k is None:
        top_k = get_config_value("knowledge_base.search.top_k", 3)
    if file_formats is None:
        file_formats = get_config_value("knowledge_base.search.file_formats",
                                        [".md", ".markdown", ".json", ".yaml", ".yml", ".txt"])

    # 构建搜索路径
    if product:
        search_path = Path(knowledge_dir) / product
    else:
        search_path = Path(knowledge_dir)

    if not search_path.exists():
        print(f"Knowledge base path not found: {search_path}", file=sys.stderr)
        return []

    # 解析查询关键词
    keywords = [k.strip() for k in query.split() if k.strip()]

    # 收集所有知识库文件
    knowledge_files = []
    for ext in file_formats:
        knowledge_files.extend(search_path.rglob(f'*{ext}'))

    # 搜索并评分
    results = []
    for file_path in knowledge_files:
        kb_data = load_knowledge_file(file_path)
        if not kb_data:
            continue

        # 搜索 sections
        if 'sections' in kb_data:
            for section_title, section_content in kb_data['sections'].items():
                score = search_in_text(section_title, keywords) * 10
                score += search_in_text(section_content, keywords)
                if score > 0:
                    results.append({
                        'file': str(file_path.relative_to(knowledge_dir)),
                        'section': section_title,
                        'content': section_content[:500],
                        'score': score
                    })

        # 搜索 full_content
        if 'full_content' in kb_data:
            score = search_in_text(kb_data['full_content'], keywords)
            if score > 0:
                results.append({
                    'file': str(file_path.relative_to(knowledge_dir)),
                    'section': '全文',
                    'content': kb_data['full_content'][:500],
                    'score': score
                })

    # 按评分排序并返回 top_k
    results.sort(key=lambda x: x['score'], reverse=True)
    return results[:top_k]


def format_results(results: List[Dict[str, Any]]) -> str:
    """格式化搜索结果为可读文本"""
    if not results:
        return ""

    output = []
    for i, result in enumerate(results, 1):
        output.append(f"\n--- 结果 {i} ---\n")
        output.append(f"来源: {result['file']}")
        if result['section'] != '全文':
            output.append(f"章节: {result['section']}")
        output.append(f"\n内容:\n{result['content']}")

    return '\n'.join(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='知识库检索工具')
    parser.add_argument('--dir', '-d', help='知识库目录（默认从配置读取）')
    parser.add_argument('--query', '-q', required=True, help='搜索关键词')
    parser.add_argument('--product', '-p', help='产品线名称')
    parser.add_argument('--top-k', '-k', type=int, help='返回结果数量（默认从配置读取）')

    args = parser.parse_args()

    # 从配置或参数获取知识库目录
    knowledge_dir = args.dir or get_config_value("knowledge_base.root_dir", "./knowledge")
    knowledge_dir = str(resolve_path(knowledge_dir))

    results = search_knowledge_base(
        knowledge_dir=knowledge_dir,
        query=args.query,
        product=args.product,
        top_k=args.top_k
    )

    output = format_results(results)
    if output:
        print(output)
    else:
        print("未找到相关知识库内容")
