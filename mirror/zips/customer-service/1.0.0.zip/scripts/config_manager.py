#!/usr/bin/env python3
"""
客服配置管理器
支持从 TOML 配置文件读取配置
"""

import os
import sys
import json
import argparse
from pathlib import Path
from typing import Any, Dict, Optional


def find_config_file(skill_dir: Optional[str] = None) -> Optional[Path]:
    """查找配置文件"""
    if skill_dir:
        config_path = Path(skill_dir) / "references" / "config.toml"
        if config_path.exists():
            return config_path

    # 在技能目录中查找
    skill_base = Path(__file__).parent.parent
    config_path = skill_base / "references" / "config.toml"
    if config_path.exists():
        return config_path

    return None


def load_config(config_path: Optional[Path] = None) -> Dict[str, Any]:
    """加载配置文件"""
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib
        except ImportError:
            # TOML 库不可用，使用 JSON 配置
            if config_path and config_path.suffix == '.json':
                with open(config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return get_default_config()

    if config_path is None:
        config_path = find_config_file()

    if config_path and config_path.exists():
        with open(config_path, 'rb') as f:
            return tomllib.load(f)

    return get_default_config()


def get_default_config() -> Dict[str, Any]:
    """获取默认配置"""
    return {
        "knowledge_base": {
            "root_dir": "./knowledge",
            "search": {
                "top_k": 3,
                "file_formats": [".md", ".markdown", ".json", ".yaml", ".yml", ".txt"]
            },
            "structure": {
                "enable_product_isolation": True,
                "default_product": "common"
            }
        },
        "tickets": {
            "dir": "./tickets",
            "auto_create": {
                "enable": True,
                "priority_keywords": {
                    "urgent": ["急", "马上", "立刻", "崩溃", "无法使用", "严重"],
                    "high": ["很久", "一直", "频繁", "多次", "很烦"],
                    "normal": []
                }
            }
        },
        "reply": {
            "style": "warm",
            "use_emoji": True
        }
    }


def resolve_path(path: str, base_dir: Optional[str] = None) -> Path:
    """解析路径（支持相对路径和绝对路径）"""
    p = Path(path)
    if p.is_absolute():
        return p

    # 相对路径：以当前工作目录或基础目录为基准
    if base_dir:
        return Path(base_dir) / p
    return Path.cwd() / p


def get_config_value(key_path: str, default: Any = None) -> Any:
    """
    获取配置值，支持点号路径
    例如：get_config_value("knowledge_base.root_dir")
    """
    config = load_config()

    keys = key_path.split('.')
    value = config

    for key in keys:
        if isinstance(value, dict):
            value = value.get(key)
            if value is None:
                return default
        else:
            return default

    return value


def save_config(config: Dict[str, Any], output_path: Optional[str] = None) -> str:
    """
    保存配置到文件
    返回保存的路径
    """
    try:
        import tomllib
        import tomli_w
        use_toml = True
    except ImportError:
        use_toml = False

    if output_path:
        config_path = Path(output_path)
    else:
        config_path = find_config_file() or (Path(__file__).parent.parent / "references" / "config.toml")

    config_path.parent.mkdir(parents=True, exist_ok=True)

    if use_toml and config_path.suffix == '.toml':
        with open(config_path, 'wb') as f:
            tomli_w.dump(config, f)
    else:
        # 保存为 JSON
        json_path = config_path.with_suffix('.json')
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        config_path = json_path

    return str(config_path)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='客服配置管理工具')
    subparsers = parser.add_subparsers(dest='command', help='子命令')

    # view 子命令
    view_parser = subparsers.add_parser('view', help='查看当前配置')
    view_parser.add_argument('--key', '-k', help='查看指定配置项（支持点号路径）')

    # init 子命令
    init_parser = subparsers.add_parser('init', help='初始化配置文件')
    init_parser.add_argument('--output', '-o', help='输出路径')

    args = parser.parse_args()

    if args.command == 'view':
        config = load_config()
        if args.key:
            value = get_config_value(args.key)
            print(f"{args.key} = {value}")
        else:
            print(json.dumps(config, ensure_ascii=False, indent=2))

    elif args.command == 'init':
        default_config = get_default_config()
        output_path = save_config(default_config, args.output)
        print(f"✅ 配置文件已创建: {output_path}")

    else:
        parser.print_help()
