"""
风格库管理
管理 style-library.json 的读写
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class DomainStyle:
    """域风格"""
    name: str
    rules: Dict[str, Any]
    confirmed: bool
    evidence: List[str]
    
    def to_dict(self) -> dict:
        return {
            "rules": self.rules,
            "confirmed": self.confirmed,
            "evidence": self.evidence
        }
    
    @classmethod
    def from_dict(cls, name: str, data: dict) -> 'DomainStyle':
        return cls(
            name=name,
            rules=data.get("rules", {}),
            confirmed=data.get("confirmed", False),
            evidence=data.get("evidence", [])
        )


class StyleLibrary:
    """风格库管理器"""
    
    DEFAULT_DOMAINS = {
        "ppt": {
            "rules": {
                "color_palette": {
                    "background": "#FFFFFF",
                    "primary_text": "#1A1A1A",
                    "accent": "#F15A22"
                },
                "layout": "极简浅色系，左对齐，大留白",
                "font": "系统默认，标题加粗"
            },
            "confirmed": True,
            "evidence": ["2026-04-08 用户认可方案A"]
        },
        "writing": {
            "rules": {
                "tone": "直接、不寒暄、有观点",
                "length": "精简优先，重点突出",
                "format": "多用表格和列表，减少大段文字"
            },
            "confirmed": True,
            "evidence": ["用户多次跳过开场白"]
        },
        "code": {
            "rules": {
                "language_preference": "Python优先，PowerShell次之",
                "comment_style": "关键逻辑加注释，不过度注释",
                "error_handling": "明确的错误提示，不静默失败"
            },
            "confirmed": False,
            "evidence": []
        },
        "document": {
            "rules": {
                "structure": "结论先行，再展开论据",
                "tables": "优先用表格对比，不用长段落"
            },
            "confirmed": True,
            "evidence": ["MEMORY.md:文档策略"]
        }
    }
    
    GLOBAL_DEFAULTS = {
        "response_language": "中文",
        "no_filler": True,
        "no_emoji_unless_asked": True,
        "direct_action": True,
        "precheck_before_complex_task": True
    }
    
    def __init__(self, data_dir: Optional[Path] = None):
        if data_dir is None:
            data_dir = Path.home() / ".workbuddy" / "dreams"
        self.data_dir = data_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.library_file = self.data_dir / "style-library.json"
        self.domains: Dict[str, DomainStyle] = {}
        self.global_preferences: Dict[str, Any] = {}
        self._load_library()
    
    def _load_library(self):
        """加载风格库"""
        if self.library_file.exists():
            try:
                with open(self.library_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    
                    # 加载域
                    for name, domain_data in data.get("domains", {}).items():
                        self.domains[name] = DomainStyle.from_dict(name, domain_data)
                    
                    # 加载全局偏好
                    self.global_preferences = data.get("global_preferences", self.GLOBAL_DEFAULTS.copy())
                    
            except (json.JSONDecodeError, UnicodeDecodeError):
                self._initialize_defaults()
        else:
            self._initialize_defaults()
    
    def _initialize_defaults(self):
        """初始化默认风格"""
        for name, data in self.DEFAULT_DOMAINS.items():
            self.domains[name] = DomainStyle.from_dict(name, data)
        
        self.global_preferences = self.GLOBAL_DEFAULTS.copy()
        self._save_library()
    
    def _save_library(self):
        """保存风格库"""
        data = {
            "updated_at": datetime.now().isoformat(),
            "domains": {
                name: domain.to_dict()
                for name, domain in self.domains.items()
            },
            "global_preferences": self.global_preferences
        }
        
        with open(self.library_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def get_domain_style(self, domain: str) -> Optional[DomainStyle]:
        """获取域风格"""
        return self.domains.get(domain)
    
    def get_style_rule(self, domain: str, rule_name: str) -> Optional[Any]:
        """获取具体风格规则"""
        domain_style = self.domains.get(domain)
        if domain_style:
            return domain_style.rules.get(rule_name)
        return None
    
    def update_style(self, domain: str, rule_name: str, 
                    value: Any, evidence: str = ""):
        """
        更新风格规则
        
        Args:
            domain: 域名称
            rule_name: 规则名称
            value: 规则值
            evidence: 证据说明
        """
        if domain not in self.domains:
            # 创建新域
            self.domains[domain] = DomainStyle(
                name=domain,
                rules={},
                confirmed=False,
                evidence=[]
            )
        
        domain_style = self.domains[domain]
        
        # 检查是否是同一规则的第二次更新
        if rule_name in domain_style.rules:
            # 标记为 confirmed
            domain_style.confirmed = True
        
        # 更新规则
        domain_style.rules[rule_name] = value
        
        # 添加证据
        if evidence:
            timestamp = datetime.now().strftime("%Y-%m-%d")
            domain_style.evidence.append(f"{timestamp} {evidence}")
        
        self._save_library()
    
    def get_global_preference(self, key: str) -> Optional[Any]:
        """获取全局偏好"""
        return self.global_preferences.get(key)
    
    def update_global_preference(self, key: str, value: Any):
        """更新全局偏好"""
        self.global_preferences[key] = value
        self._save_library()
    
    def detect_domain(self, content: str) -> str:
        """
        检测内容所属域
        
        Args:
            content: 内容描述
            
        Returns:
            域名称
        """
        content_lower = content.lower()
        
        # PPT 域
        if any(kw in content_lower for kw in ["ppt", "幻灯片", "演示", "slide"]):
            return "ppt"
        
        # 代码域
        if any(kw in content_lower for kw in ["代码", "script", "python", "javascript", "编程"]):
            return "code"
        
        # 文档域
        if any(kw in content_lower for kw in ["文档", "doc", "报告", "word"]):
            return "document"
        
        # 写作域
        if any(kw in content_lower for kw in ["写作", "文案", "文章", "内容"]):
            return "writing"
        
        # 默认
        return "writing"
    
    def get_all_confirmed_styles(self) -> Dict[str, DomainStyle]:
        """获取所有已确认的风格"""
        return {name: style for name, style in self.domains.items() if style.confirmed}
    
    def get_summary(self) -> Dict:
        """获取风格库摘要"""
        return {
            "total_domains": len(self.domains),
            "confirmed_domains": len([d for d in self.domains.values() if d.confirmed]),
            "domains": list(self.domains.keys()),
            "global_prefs": list(self.global_preferences.keys())
        }


# 单例
_style_library_instance: Optional[StyleLibrary] = None


def get_style_library() -> StyleLibrary:
    global _style_library_instance
    if _style_library_instance is None:
        _style_library_instance = StyleLibrary()
    return _style_library_instance
