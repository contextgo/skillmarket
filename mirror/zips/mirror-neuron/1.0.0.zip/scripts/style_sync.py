"""
风格同步器
实现风格注入和学习
"""

from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass

from style_library import get_style_library, DomainStyle


@dataclass
class StyleInjection:
    """风格注入结果"""
    domain: str
    rules_applied: Dict[str, Any]
    source: str  # confirmed, unconfirmed, global
    conflicts: List[str]


@dataclass
class StyleLearning:
    """风格学习结果"""
    domain: str
    rule_updated: str
    old_value: Any
    new_value: Any
    confirmed: bool
    message: str


class StyleSync:
    """风格同步器"""
    
    def __init__(self):
        self.library = get_style_library()
    
    def inject_style(self, task_description: str) -> StyleInjection:
        """
        注入风格
        
        Args:
            task_description: 任务描述
            
        Returns:
            风格注入结果
        """
        # 检测域
        domain = self.library.detect_domain(task_description)
        domain_style = self.library.get_domain_style(domain)
        
        rules_applied = {}
        source = "none"
        conflicts = []
        
        if domain_style:
            # 应用已确认的规则
            if domain_style.confirmed:
                rules_applied = domain_style.rules.copy()
                source = "confirmed"
            else:
                # 未确认，只应用部分规则
                rules_applied = {k: v for k, v in domain_style.rules.items() 
                               if k in ["tone", "format"]}  # 只应用基础规则
                source = "unconfirmed"
        else:
            # 使用全局默认
            rules_applied = {"global": self.library.global_preferences}
            source = "global"
        
        return StyleInjection(
            domain=domain,
            rules_applied=rules_applied,
            source=source,
            conflicts=conflicts
        )
    
    def learn_from_correction(self, original_output: str, 
                             user_correction: str,
                             task_domain: str = "") -> StyleLearning:
        """
        从用户修正中学习
        
        Args:
            original_output: 原始输出
            user_correction: 用户修正
            task_domain: 任务域
            
        Returns:
            学习结果
        """
        # 检测域
        if not task_domain:
            task_domain = self.library.detect_domain(user_correction)
        
        # 识别修正维度（简化实现）
        rule_name = "general"
        
        if any(kw in user_correction for kw in ["颜色", "背景", "字体", "样式"]):
            rule_name = "visual_style"
        elif any(kw in user_correction for kw in ["语气", "风格", "措辞"]):
            rule_name = "tone"
        elif any(kw in user_correction for kw in ["格式", "结构", "排版"]):
            rule_name = "format"
        elif any(kw in user_correction for kw in ["长度", "精简", "详细"]):
            rule_name = "length"
        
        # 获取旧值
        old_value = self.library.get_style_rule(task_domain, rule_name)
        
        # 更新风格
        self.library.update_style(
            domain=task_domain,
            rule_name=rule_name,
            value=user_correction,
            evidence=f"用户修正: {user_correction[:50]}"
        )
        
        # 检查是否已确认
        domain_style = self.library.get_domain_style(task_domain)
        confirmed = domain_style.confirmed if domain_style else False
        
        return StyleLearning(
            domain=task_domain,
            rule_updated=rule_name,
            old_value=old_value,
            new_value=user_correction,
            confirmed=confirmed,
            message=f"已学习风格规则: {task_domain}.{rule_name}"
        )
    
    def check_conflict(self, task_requirements: Dict, 
                      domain: str) -> List[str]:
        """
        检查风格冲突
        
        Args:
            task_requirements: 任务需求
            domain: 域
            
        Returns:
            冲突列表
        """
        conflicts = []
        domain_style = self.library.get_domain_style(domain)
        
        if not domain_style:
            return conflicts
        
        # 检查每个需求是否与风格冲突
        for req_key, req_value in task_requirements.items():
            if req_key in domain_style.rules:
                style_value = domain_style.rules[req_key]
                if style_value != req_value:
                    conflicts.append(
                        f"{req_key}: 风格库='{style_value}' vs 需求='{req_value}'"
                    )
        
        return conflicts
    
    def get_style_prompt(self, domain: str) -> str:
        """
        获取风格提示词
        
        Args:
            domain: 域
            
        Returns:
            风格提示词
        """
        domain_style = self.library.get_domain_style(domain)
        
        if not domain_style:
            # 使用全局偏好
            prefs = self.library.global_preferences
            return f"使用{prefs.get('response_language', '中文')}回复，直接不寒暄"
        
        # 构建风格提示
        prompts = []
        
        for rule_name, rule_value in domain_style.rules.items():
            if isinstance(rule_value, dict):
                # 嵌套规则（如 color_palette）
                prompts.append(f"{rule_name}: {rule_value}")
            else:
                prompts.append(f"{rule_name}: {rule_value}")
        
        return "\n".join(prompts)
    
    def apply_style(self, content: str, domain: str) -> str:
        """
        应用风格到内容
        
        Args:
            content: 原始内容
            domain: 域
            
        Returns:
            应用风格后的内容
        """
        # 获取全局偏好
        no_filler = self.library.get_global_preference("no_filler")
        no_emoji = self.library.get_global_preference("no_emoji_unless_asked")
        
        styled = content
        
        # 应用无废话规则
        if no_filler:
            # 移除常见的寒暄语
            fillers = ["你好！", "很高兴", "我会", "让我来"]
            for filler in fillers:
                if styled.startswith(filler):
                    styled = styled[len(filler):].strip()
        
        # 应用无emoji规则
        if no_emoji:
            import re
            styled = re.sub(r'[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF]', '', styled)
        
        return styled
    
    def get_sync_summary(self) -> Dict:
        """获取同步摘要"""
        lib_summary = self.library.get_summary()
        
        return {
            "library": lib_summary,
            "ready": True
        }


# 单例
_style_sync_instance: Optional[StyleSync] = None


def get_style_sync() -> StyleSync:
    global _style_sync_instance
    if _style_sync_instance is None:
        _style_sync_instance = StyleSync()
    return _style_sync_instance
