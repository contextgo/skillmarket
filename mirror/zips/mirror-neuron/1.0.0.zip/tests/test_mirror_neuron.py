#!/usr/bin/env python3
"""
镜像神经元系统测试套件
"""
import unittest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

from style_sync import StyleSync, StyleInjection, StyleLearning
from style_library import DomainStyle


class TestStyleSync(unittest.TestCase):
    """测试风格同步"""
    
    def setUp(self):
        self.sync = StyleSync()
    
    def test_inject_style(self):
        """测试风格注入"""
        injection = self.sync.inject_style("编写Python代码")
        
        self.assertIsInstance(injection, StyleInjection)
        self.assertIn(injection.source, ["confirmed", "unconfirmed", "global", "none"])
    
    def test_learn_from_correction(self):
        """测试从纠正中学习"""
        learning = self.sync.learn_from_correction(
            original_output="使用 4 空格缩进",
            user_correction="使用 2 空格缩进",
            task_domain="python"
        )
        
        self.assertIsInstance(learning, StyleLearning)
        self.assertEqual(learning.domain, "python")


class TestStyleInjection(unittest.TestCase):
    """测试风格注入结果"""
    
    def test_injection_creation(self):
        """测试注入结果创建"""
        injection = StyleInjection(
            domain="python",
            rules_applied={"indent": "4 spaces"},
            source="confirmed",
            conflicts=[]
        )
        
        self.assertEqual(injection.domain, "python")
        self.assertEqual(injection.source, "confirmed")


class TestStyleLearning(unittest.TestCase):
    """测试风格学习结果"""
    
    def test_learning_creation(self):
        """测试学习结果创建"""
        learning = StyleLearning(
            domain="python",
            rule_updated="indent",
            old_value="4",
            new_value="2",
            confirmed=False,
            message="规则已更新"
        )
        
        self.assertEqual(learning.domain, "python")
        self.assertEqual(learning.old_value, "4")


if __name__ == "__main__":
    unittest.main()
