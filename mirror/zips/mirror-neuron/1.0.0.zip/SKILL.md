---
name: mirror-neuron
slug: mirror-neuron
version: 1.0.0
description: "镜像神经元风格同步。模拟人类镜像神经元系统：自动学习并复现用户的风格偏好、表达习惯和审美取向，确保每次输出都与用户的「内在标准」高度对齐，无需重复说明。"
---

# 🪞 Mirror Neuron — 镜像神经元风格同步

## 类比

> 人类镜像神经元让我们能理解他人意图、模仿他人行为。
> 本 Skill 让 AI 自动「镜像」用户的风格偏好，做到不说也懂。

---

## 自动触发规则（全自动，无需用户说"同步风格"）

### 触发时机（自动激活）

| 场景 | 自动执行 |
|------|---------|
| 输出任何文档/代码/设计内容前 | 自动加载风格库对应域 |
| 用户修正了输出风格 | 自动学习，更新 style-library.json |
| 用户说"跟之前一样" | 自动恢复上次风格配置 |
| 风格冲突时 | 自动提示（1句话），默认按旧偏好执行 |

### 自动风格注入流程（内置，0额外操作）

```
每次输出前：
  1. 检测输出类型（ppt/文档/代码/文案）
  2. 查 style-library.json 对应域
  3. 找到规则 → 直接应用（无感知）
  4. 找到 confirmed 规则 → 强制应用
  5. 未找到 → 用 global_preferences 兜底

每次用户修正后（自动学习）：
  1. 识别修正维度
  2. 更新 style-library.json
  3. 追加 evidence
  4. 同一维度 ≥2 次 → 标记 confirmed: true
  5. confirmed → 推送给 dream-memory

---

## 风格库结构

存储位置：`.workbuddy/dreams/style-library.json`

```json
{
  "updated_at": "2026-04-08",
  "domains": {
    "ppt": {
      "color_palette": {
        "background": "#FFFFFF",
        "primary_text": "#1A1A1A",
        "accent": "#F15A22",
        "confirmed": true
      },
      "layout": "极简浅色系，左对齐，大留白",
      "font": "系统默认，标题加粗",
      "evidence": ["2026-04-01 用户认可方案A", "MEMORY.md:PPT颜色策略"]
    },
    "writing": {
      "tone": "直接、不寒暄、有观点",
      "length": "精简优先，重点突出",
      "format": "多用表格和列表，减少大段文字",
      "evidence": ["用户多次跳过开场白", "用户偏好不加emoji"]
    },
    "code": {
      "language_preference": "Python优先，PowerShell次之",
      "comment_style": "关键逻辑加注释，不过度注释",
      "error_handling": "明确的错误提示，不静默失败",
      "evidence": []
    },
    "document": {
      "structure": "结论先行，再展开论据",
      "tables": "优先用表格对比，不用长段落",
      "evidence": ["MEMORY.md:简历优化策略"]
    }
  },
  "global_preferences": {
    "response_language": "中文",
    "no_filler": true,
    "no_emoji_unless_asked": true,
    "direct_action": true,
    "precheck_before_complex_task": true
  }
}
```

---

## 核心操作

### 1. 风格注入（任务开始时）

```
检测任务类型 → 查询风格库对应域
  → 找到匹配风格 → 静默应用（不告知用户，直接体现在输出中）
  → 未找到 → 使用 global_preferences 兜底
  → 新域类型 → 标记为「待学习」
```

### 2. 风格学习（用户修正时）

触发信号：
- "不对，应该是..."
- "换成..."
- "跟之前一样..."
- 用户直接修改了 AI 的输出

```
1. 识别修正维度（颜色/语气/结构/格式...）
2. 提取新偏好规则
3. 更新 style-library.json 对应域
4. 追加 evidence 记录（时间 + 触发语句）
5. 如果同一维度被修正 ≥2 次 → 标记为 confirmed: true
6. confirmed 的规则 → 推送给 dream-memory 写入 MEMORY.md
```

### 3. 风格冲突处理

```
当新任务的需求与风格库冲突时：
优先级：用户当次明确指令 > confirmed规则 > 未确认规则 > 全局默认

如果冲突明显 → 简短说明：
"检测到与你常用风格有差异（[旧偏好]→[新要求]），
本次按新要求执行，是否更新你的风格偏好？"
```

### 4. 风格快照（周期性）

```
每周一次（由 dream-memory REM 阶段触发）：
1. 汇总7天内的风格修正记录
2. 提炼规律 → 更新 style-library.json
3. 高频确认项 → 推送到 MEMORY.md
```

---

## 内置已知偏好（从 MEMORY.md 预加载）

| 域 | 规则 | 来源 |
|----|------|------|
| PPT | 背景#FFFFFF，文字#1A1A1A，橙色#F15A22保留 | MEMORY.md 已确认 |
| 文档修改 | 只改目标部分，不整体重写 | MEMORY.md 已确认 |
| 回复风格 | 直接、不废话、中文输出 | MEMORY.md 已确认 |
| 风险操作 | 先警告，再确认，绝不自动执行 | MEMORY.md 已确认 |

---

## 联动

- **prefrontal-check**：预检阶段调用风格库，确认输出方向
- **dream-memory**：REM 阶段触发风格快照 + 推送 confirmed 规则
- **working-memory-buffer**：决策中记录 `from_memory: true` 的风格来源
