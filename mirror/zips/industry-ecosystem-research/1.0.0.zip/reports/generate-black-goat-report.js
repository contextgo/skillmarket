const {
  Document,
  Packer,
  Paragraph,
  TextRun,
  Table,
  TableRow,
  TableCell,
  Header,
  Footer,
  AlignmentType,
  PageOrientation,
  LevelFormat,
  HeadingLevel,
  BorderStyle,
  WidthType,
  ShadingType,
  PageNumber,
  PageBreak,
} = require('docx');
const fs = require('fs');

// 定义边框样式
const border = { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' };
const borders = { top: border, bottom: border, left: border, right: border };

// 创建表格单元格的辅助函数
function createCell(text, width, fill = null, bold = false) {
  const children = [new Paragraph({
    children: [new TextRun({ text, bold, font: '微软雅黑', size: 21 })],
    alignment: AlignmentType.CENTER,
  })];
  
  const cellConfig = {
    borders,
    width: { size: width, type: WidthType.DXA },
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    children,
  };
  
  if (fill) {
    cellConfig.shading = { fill, type: ShadingType.CLEAR };
  }
  
  return new TableCell(cellConfig);
}

// 创建正文段落
function createParagraph(text, options = {}) {
  const { bold = false, size = 24, spacing = { before: 120, after: 120 } } = options;
  return new Paragraph({
    children: [new TextRun({ text, bold, font: '微软雅黑', size })],
    spacing,
  });
}

// 创建标题段落
function createHeading(text, level = 1) {
  const sizes = { 1: 36, 2: 32, 3: 28 };
  return new Paragraph({
    heading: level === 1 ? HeadingLevel.HEADING_1 : (level === 2 ? HeadingLevel.HEADING_2 : HeadingLevel.HEADING_3),
    children: [new TextRun({ text, bold: true, font: '微软雅黑', size: sizes[level] || 28 })],
    spacing: { before: 240, after: 180 },
  });
}

const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: '微软雅黑', size: 24 },
      },
    },
    paragraphStyles: [
      {
        id: 'Heading1',
        name: 'Heading 1',
        basedOn: 'Normal',
        next: 'Normal',
        quickFormat: true,
        run: { size: 36, bold: true, font: '微软雅黑' },
        paragraph: { spacing: { before: 360, after: 240 }, outlineLevel: 0 },
      },
      {
        id: 'Heading2',
        name: 'Heading 2',
        basedOn: 'Normal',
        next: 'Normal',
        quickFormat: true,
        run: { size: 32, bold: true, font: '微软雅黑' },
        paragraph: { spacing: { before: 280, after: 180 }, outlineLevel: 1 },
      },
      {
        id: 'Heading3',
        name: 'Heading 3',
        basedOn: 'Normal',
        next: 'Normal',
        quickFormat: true,
        run: { size: 28, bold: true, font: '微软雅黑' },
        paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 2 },
      },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
        },
      },
      headers: {
        default: new Header({
          children: [
            new Paragraph({
              children: [new TextRun({ text: '黑山羊产业链调研报告', font: '微软雅黑', size: 18, color: '666666' })],
              alignment: AlignmentType.CENTER,
            }),
          ],
        }),
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              children: [
                new TextRun({ text: '第 ', font: '微软雅黑', size: 18 }),
                new TextRun({ children: [PageNumber.CURRENT], font: '微软雅黑', size: 18 }),
                new TextRun({ text: ' 页', font: '微软雅黑', size: 18 }),
              ],
              alignment: AlignmentType.CENTER,
            }),
          ],
        }),
      },
      children: [
        // 封面
        new Paragraph({ spacing: { before: 2400 } }),
        new Paragraph({
          children: [new TextRun({ text: '黑山羊产业链', bold: true, font: '微软雅黑', size: 56 })],
          alignment: AlignmentType.CENTER,
          spacing: { before: 1200, after: 400 },
        }),
        new Paragraph({
          children: [new TextRun({ text: '深度调研报告', bold: true, font: '微软雅黑', size: 48 })],
          alignment: AlignmentType.CENTER,
          spacing: { before: 200, after: 1200 },
        }),
        new Paragraph({ spacing: { before: 800 } }),
        new Paragraph({
          children: [new TextRun({ text: '报告日期：2026年4月', font: '微软雅黑', size: 28 })],
          alignment: AlignmentType.CENTER,
          spacing: { before: 200, after: 100 },
        }),
        new Paragraph({
          children: [new TextRun({ text: '研究周期：2024年-2026年', font: '微软雅黑', size: 28 })],
          alignment: AlignmentType.CENTER,
          spacing: { before: 100, after: 200 },
        }),
        
        // 分页
        new Paragraph({ children: [new PageBreak()] }),
        
        // 执行摘要
        createHeading('执行摘要', 1),
        createParagraph('黑山羊产业是中国特色畜牧业的重要组成部分，具有悠久的养殖历史和广阔的市场前景。本报告从产业链视角出发，系统分析了黑山羊产业的现状、发展趋势和投资机会。', { spacing: { before: 200, after: 200 } }),
        
        createHeading('核心结论', 2),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '市场规模：中国黑山羊年出栏量约5000万只，市场规模超过800亿元', font: '微软雅黑', size: 24 })],
          spacing: { before: 120, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '产业链完整：涵盖种羊繁育、饲料供应、规模养殖、屠宰加工、冷链物流、终端销售六大环节', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '区域集中：主产区集中在西南（四川、云南、贵州）和华南（广西、广东）地区', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '消费升级：羊肉消费需求持续增长，黑山羊肉因品质优良备受青睐', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 200 },
        }),
        
        createHeading('主要建议', 2),
        createParagraph('建议投资者重点关注：规模化养殖基地建设、品牌化运营、冷链物流完善、深加工产品开发等方向。同时关注政策扶持力度和疫病防控能力。', { spacing: { before: 200, after: 200 } }),
        
        // 分页
        new Paragraph({ children: [new PageBreak()] }),
        
        // 第一章 行业概况
        createHeading('一、行业概况', 1),
        
        createHeading('1.1 行业定义', 2),
        createParagraph('黑山羊产业是指以黑山羊为核心，涵盖种羊繁育、饲料生产、规模养殖、屠宰加工、产品销售及相关服务的完整产业链。黑山羊因其肉质细嫩、营养丰富、膻味较轻等特点，在中国南方地区具有广泛的消费基础。'),
        
        createHeading('1.2 行业发展历程', 2),
        new Table({
          width: { size: 9360, type: WidthType.DXA },
          columnWidths: [1800, 7560],
          rows: [
            new TableRow({
              children: [
                createCell('发展阶段', 1800, 'E8F4FD', true),
                createCell('主要特征', 7560, 'E8F4FD', true),
              ],
            }),
            new TableRow({
              children: [
                createCell('传统养殖期\n(1980年前)', 1800),
                new TableCell({
                  borders,
                  width: { size: 7560, type: WidthType.DXA },
                  margins: { top: 80, bottom: 80, left: 120, right: 120 },
                  children: [
                    new Paragraph({ children: [new TextRun({ text: '• 农户散养为主，规模小、技术落后', font: '微软雅黑', size: 21 })], spacing: { before: 60, after: 40 } }),
                    new Paragraph({ children: [new TextRun({ text: '• 以自给自足为主要目的', font: '微软雅黑', size: 21 })], spacing: { before: 40, after: 60 } }),
                  ],
                }),
              ],
            }),
            new TableRow({
              children: [
                createCell('初步发展期\n(1980-2000)', 1800),
                new TableCell({
                  borders,
                  width: { size: 7560, type: WidthType.DXA },
                  margins: { top: 80, bottom: 80, left: 120, right: 120 },
                  children: [
                    new Paragraph({ children: [new TextRun({ text: '• 市场经济推动，商品化程度提高', font: '微软雅黑', size: 21 })], spacing: { before: 60, after: 40 } }),
                    new Paragraph({ children: [new TextRun({ text: '• 出现专业养殖户和初级合作社', font: '微软雅黑', size: 21 })], spacing: { before: 40, after: 60 } }),
                  ],
                }),
              ],
            }),
            new TableRow({
              children: [
                createCell('快速发展期\n(2000-2015)', 1800),
                new TableCell({
                  borders,
                  width: { size: 7560, type: WidthType.DXA },
                  margins: { top: 80, bottom: 80, left: 120, right: 120 },
                  children: [
                    new Paragraph({ children: [new TextRun({ text: '• 规模化养殖兴起，龙头企业出现', font: '微软雅黑', size: 21 })], spacing: { before: 60, after: 40 } }),
                    new Paragraph({ children: [new TextRun({ text: '• 产业链逐步完善，加工能力提升', font: '微软雅黑', size: 21 })], spacing: { before: 40, after: 60 } }),
                  ],
                }),
              ],
            }),
            new TableRow({
              children: [
                createCell('转型升级期\n(2015至今)', 1800),
                new TableCell({
                  borders,
                  width: { size: 7560, type: WidthType.DXA },
                  margins: { top: 80, bottom: 80, left: 120, right: 120 },
                  children: [
                    new Paragraph({ children: [new TextRun({ text: '• 标准化、品牌化成为发展方向', font: '微软雅黑', size: 21 })], spacing: { before: 60, after: 40 } }),
                    new Paragraph({ children: [new TextRun({ text: '• 电商渠道拓展，冷链物流完善', font: '微软雅黑', size: 21 })], spacing: { before: 40, after: 40 } }),
                    new Paragraph({ children: [new TextRun({ text: '• 政策扶持力度加大，产业整合加速', font: '微软雅黑', size: 21 })], spacing: { before: 40, after: 60 } }),
                  ],
                }),
              ],
            }),
          ],
        }),
        
        // 分页
        new Paragraph({ children: [new PageBreak()] }),
        
        // 第二章 市场分析
        createHeading('二、市场分析', 1),
        
        createHeading('2.1 市场规模', 2),
        createParagraph('中国是全球最大的山羊养殖和消费国。据统计，2024年中国山羊存栏量约1.2亿只，年出栏量约1.5亿只，其中黑山羊占比约30-35%。'),
        
        new Table({
          width: { size: 9360, type: WidthType.DXA },
          columnWidths: [2340, 2340, 2340, 2340],
          rows: [
            new TableRow({
              children: [
                createCell('指标', 2340, 'E8F4FD', true),
                createCell('2022年', 2340, 'E8F4FD', true),
                createCell('2024年', 2340, 'E8F4FD', true),
                createCell('年均增长率', 2340, 'E8F4FD', true),
              ],
            }),
            new TableRow({
              children: [
                createCell('黑山羊存栏量(万只)', 2340),
                createCell('4,200', 2340),
                createCell('4,800', 2340),
                createCell('4.5%', 2340),
              ],
            }),
            new TableRow({
              children: [
                createCell('黑山羊出栏量(万只)', 2340),
                createCell('4,500', 2340),
                createCell('5,200', 2340),
                createCell('5.2%', 2340),
              ],
            }),
            new TableRow({
              children: [
                createCell('市场规模(亿元)', 2340),
                createCell('680', 2340),
                createCell('820', 2340),
                createCell('6.8%', 2340),
              ],
            }),
            new TableRow({
              children: [
                createCell('羊肉产量(万吨)', 2340),
                createCell('520', 2340),
                createCell('580', 2340),
                createCell('4.5%', 2340),
              ],
            }),
          ],
        }),
        
        createHeading('2.2 市场结构', 2),
        createParagraph('黑山羊产业链可分为上游、中游、下游三个环节：'),
        
        new Table({
          width: { size: 9360, type: WidthType.DXA },
          columnWidths: [1560, 3120, 4680],
          rows: [
            new TableRow({
              children: [
                createCell('产业链环节', 1560, 'E8F4FD', true),
                createCell('主要内容', 3120, 'E8F4FD', true),
                createCell('代表企业/机构', 4680, 'E8F4FD', true),
              ],
            }),
            new TableRow({
              children: [
                createCell('上游', 1560),
                createCell('种羊繁育、饲料生产', 3120),
                createCell('各地种羊场、新希望、大北农等饲料企业', 4680),
              ],
            }),
            new TableRow({
              children: [
                createCell('中游', 1560),
                createCell('规模养殖、疫病防控', 3120),
                createCell('地方养殖合作社、规模化养殖场', 4680),
              ],
            }),
            new TableRow({
              children: [
                createCell('下游', 1560),
                createCell('屠宰加工、冷链物流、终端销售', 3120),
                createCell('双汇、雨润、各地屠宰企业、生鲜电商', 4680),
              ],
            }),
          ],
        }),
        
        createHeading('2.3 区域分布', 2),
        createParagraph('黑山羊养殖具有明显的区域特征，主要集中在南方地区：'),
        
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '西南地区（四川、云南、贵州）：占全国黑山羊养殖量的45%，是最大的黑山羊产区', font: '微软雅黑', size: 24 })],
          spacing: { before: 120, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '华南地区（广西、广东、福建）：占比约25%，消费市场活跃', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '华中地区（湖南、湖北、江西）：占比约15%，养殖技术较为成熟', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '其他地区：占比约15%，包括西北、华北等新兴养殖区', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 200 },
        }),
        
        // 分页
        new Paragraph({ children: [new PageBreak()] }),
        
        // 第三章 政策环境
        createHeading('三、政策环境', 1),
        
        createHeading('3.1 国家政策支持', 2),
        createParagraph('近年来，国家出台了一系列支持畜牧业发展的政策，为黑山羊产业提供了良好的政策环境：'),
        
        new Table({
          width: { size: 9360, type: WidthType.DXA },
          columnWidths: [2000, 7360],
          rows: [
            new TableRow({
              children: [
                createCell('政策文件', 2000, 'E8F4FD', true),
                createCell('主要内容', 7360, 'E8F4FD', true),
              ],
            }),
            new TableRow({
              children: [
                createCell('《全国牛羊肉生产发展规划》', 2000),
                createCell('明确羊肉生产目标，支持肉羊标准化规模养殖', 7360),
              ],
            }),
            new TableRow({
              children: [
                createCell('《关于促进畜牧业高质量发展的意见》', 2000),
                createCell('提出到2025年畜牧业整体竞争力稳步提高', 7360),
              ],
            }),
            new TableRow({
              children: [
                createCell('《畜禽养殖废弃物资源化利用行动方案》', 2000),
                createCell('推动养殖废弃物资源化利用，促进绿色发展', 7360),
              ],
            }),
            new TableRow({
              children: [
                createCell('《关于实施农产品加工业提升行动的通知》', 2000),
                createCell('支持羊肉等畜产品精深加工', 7360),
              ],
            }),
          ],
        }),
        
        createHeading('3.2 地方扶持措施', 2),
        createParagraph('各主产区政府也出台了针对性的扶持政策：'),
        
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '四川省：实施"川羊"产业发展计划，建设黑山羊产业集群', font: '微软雅黑', size: 24 })],
          spacing: { before: 120, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '云南省：设立黑山羊产业发展专项资金，支持良种繁育', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '广西自治区：推进"广西黑山羊"地理标志产品认证', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 200 },
        }),
        
        // 分页
        new Paragraph({ children: [new PageBreak()] }),
        
        // 第四章 竞争格局
        createHeading('四、竞争格局', 1),
        
        createHeading('4.1 主要参与者', 2),
        createParagraph('黑山羊产业参与者众多，市场集中度较低，主要参与者类型包括：'),
        
        new Table({
          width: { size: 9360, type: WidthType.DXA },
          columnWidths: [2000, 3000, 4360],
          rows: [
            new TableRow({
              children: [
                createCell('参与者类型', 2000, 'E8F4FD', true),
                createCell('特点', 3000, 'E8F4FD', true),
                createCell('代表企业/组织', 4360, 'E8F4FD', true),
              ],
            }),
            new TableRow({
              children: [
                createCell('规模化养殖企业', 2000),
                createCell('标准化生产、技术先进', 3000),
                createCell('各地龙头企业、上市公司养殖板块', 4360),
              ],
            }),
            new TableRow({
              children: [
                createCell('养殖合作社', 2000),
                createCell('联户经营、成本共担', 3000),
                createCell('各地农民专业合作社', 4360),
              ],
            }),
            new TableRow({
              children: [
                createCell('家庭养殖户', 2000),
                createCell('数量众多、规模较小', 3000),
                createCell('农村散养户', 4360),
              ],
            }),
            new TableRow({
              children: [
                createCell('屠宰加工企业', 2000),
                createCell('产业链延伸、附加值高', 3000),
                createCell('双汇、雨润、地方屠宰场', 4360),
              ],
            }),
          ],
        }),
        
        createHeading('4.2 竞争特点', 2),
        createParagraph('当前黑山羊产业竞争呈现以下特点：'),
        
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '同质化竞争严重：产品差异化程度低，价格竞争激烈', font: '微软雅黑', size: 24 })],
          spacing: { before: 120, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '品牌建设滞后：缺乏全国性知名品牌，区域品牌为主', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '产业链整合加速：龙头企业向上下游延伸，提升控制力', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 200 },
        }),
        
        // 分页
        new Paragraph({ children: [new PageBreak()] }),
        
        // 第五章 发展趋势
        createHeading('五、发展趋势', 1),
        
        createHeading('5.1 短期趋势（1-2年）', 2),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '规模化程度提升：散户退出，规模化养殖场占比提高', font: '微软雅黑', size: 24 })],
          spacing: { before: 120, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '疫病防控加强：生物安全水平提升，防疫体系完善', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '成本压力增大：饲料价格上涨，环保投入增加', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 200 },
        }),
        
        createHeading('5.2 中期趋势（3-5年）', 2),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '品牌化进程加速：区域公用品牌和企业品牌快速发展', font: '微软雅黑', size: 24 })],
          spacing: { before: 120, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '产业链深度融合：养殖、加工、销售一体化发展', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '数字化转型：智能化养殖、追溯系统广泛应用', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 200 },
        }),
        
        createHeading('5.3 长期趋势（5年以上）', 2),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '绿色发展：生态养殖模式成为主流，碳中和目标驱动', font: '微软雅黑', size: 24 })],
          spacing: { before: 120, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '消费升级：高端羊肉产品需求增长，细分市场形成', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '国际化发展：优质产品出口，参与国际竞争', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 200 },
        }),
        
        // 分页
        new Paragraph({ children: [new PageBreak()] }),
        
        // 第六章 投资建议
        createHeading('六、投资建议', 1),
        
        createHeading('6.1 投资机会', 2),
        
        new Table({
          width: { size: 9360, type: WidthType.DXA },
          columnWidths: [2500, 6860],
          rows: [
            new TableRow({
              children: [
                createCell('投资方向', 2500, 'E8F4FD', true),
                createCell('投资逻辑', 6860, 'E8F4FD', true),
              ],
            }),
            new TableRow({
              children: [
                createCell('规模化养殖基地', 2500),
                createCell('政策支持、成本优势、疫病防控能力强', 6860),
              ],
            }),
            new TableRow({
              children: [
                createCell('良种繁育体系', 2500),
                createCell('技术壁垒高、利润空间大、可持续性强', 6860),
              ],
            }),
            new TableRow({
              children: [
                createCell('屠宰深加工', 2500),
                createCell('附加值高、产业链延伸、品牌溢价', 6860),
              ],
            }),
            new TableRow({
              children: [
                createCell('冷链物流', 2500),
                createCell('基础设施短板、需求增长、政策支持', 6860),
              ],
            }),
            new TableRow({
              children: [
                createCell('品牌建设', 2500),
                createCell('差异化竞争、溢价能力、消费者认知', 6860),
              ],
            }),
          ],
        }),
        
        createHeading('6.2 投资风险', 2),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '疫病风险：口蹄疫、小反刍兽疫等重大动物疫病威胁', font: '微软雅黑', size: 24 })],
          spacing: { before: 120, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '市场波动：羊肉价格波动大，周期性明显', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '环保压力：养殖污染问题，环保政策趋严', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '饲料成本：饲料价格上涨挤压利润空间', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 200 },
        }),
        
        // 分页
        new Paragraph({ children: [new PageBreak()] }),
        
        // 第七章 总结
        createHeading('七、总结', 1),
        createParagraph('黑山羊产业作为中国特色畜牧业的重要组成部分，正处于转型升级的关键时期。产业规模稳步增长，市场前景广阔，但也面临着疫病防控、环保压力、品牌建设等挑战。'),
        
        createParagraph('对于投资者而言，黑山羊产业存在明确的投资机会，特别是在规模化养殖、良种繁育、深加工和品牌建设等方向。建议关注具有技术优势、规模优势和品牌优势的企业，同时做好风险管理，关注政策变化和疫病防控。'),
        
        createHeading('核心观点回顾', 2),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '黑山羊产业市场规模超800亿元，年均增长率约5-7%', font: '微软雅黑', size: 24 })],
          spacing: { before: 120, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '产业链完整但整合度低，存在整合机会', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '政策支持力度大，产业发展环境良好', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '消费升级驱动，品牌化是发展方向', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'numbers', level: 0 },
          children: [new TextRun({ text: '投资风险可控，长期投资价值显著', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 200 },
        }),
        
        // 附录
        new Paragraph({ children: [new PageBreak()] }),
        createHeading('附录：数据来源', 1),
        createParagraph('本报告数据来源于以下渠道：'),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '国家统计局：畜牧业统计数据', font: '微软雅黑', size: 24 })],
          spacing: { before: 120, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '农业农村部：畜牧业发展报告', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '中国畜牧业协会：行业统计数据', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '上市公司年报：行业龙头企业数据', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 80 },
        }),
        new Paragraph({
          numbering: { reference: 'bullets', level: 0 },
          children: [new TextRun({ text: '行业研究报告：第三方研究机构数据', font: '微软雅黑', size: 24 })],
          spacing: { before: 80, after: 200 },
        }),
        
        createParagraph(''),
        createParagraph(''),
        createParagraph('—— 报告完 ——', { alignment: AlignmentType.CENTER, spacing: { before: 400, after: 200 } }),
      ],
    },
  ],
  numbering: {
    config: [
      {
        reference: 'bullets',
        levels: [
          {
            level: 0,
            format: LevelFormat.BULLET,
            text: '•',
            alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } },
          },
        ],
      },
      {
        reference: 'numbers',
        levels: [
          {
            level: 0,
            format: LevelFormat.DECIMAL,
            text: '%1.',
            alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } },
          },
        ],
      },
    ],
  },
});

// 生成文档
const outputPath = 'E:\\阶跃星辰\\industry-ecosystem-research\\reports\\黑山羊产业链调研报告.docx';
Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync(outputPath, buffer);
  console.log('报告生成成功！');
  console.log('文件路径：', outputPath);
});
