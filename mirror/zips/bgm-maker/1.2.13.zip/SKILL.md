---
name: bgm-maker
description: >
  为视频、直播、播客、游戏和商业内容生成纯音乐 BGM 与背景配乐。 Use this whenever the user wants 背景音乐生成, AI背景音乐, BGM生成, 配乐生成, 纯音乐, 视频BGM, 游戏配乐, 播客配乐.
  Call the local aimv CLI through the Node entrypoint.
---

# AI背景音乐生成

AI背景音乐生成适合需要 BGM生成、背景音乐生成器、纯音乐 BGM 和视频配乐的创作者。你可以描述场景、情绪、节奏和用途，为短视频、Vlog、游戏、播客、产品演示和商业内容生成可试听、可下载的背景音乐；作品会同步到海绵音乐账号，可在「海绵音乐AI写歌」小程序和 lexuan.club 网页继续管理。

Powered by 海绵音乐。账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## 本地 CLI 入口

- 推荐 Agent 工具名：`aimv`。
- 发布包入口：`bin/aimv.js`。直接 shell 执行时使用 `node <安装目录>/bin/aimv.js ...`。
- 这是通用本地 Node CLI，不是 MCP server；不要把 `bin/aimv.js` 当成 MCP stdio 服务注册。
- 第一次生成前如果未登录，Agent 有 shell/本地命令执行能力时，应直接运行 `node <安装目录>/bin/aimv.js init` 让用户扫码授权。

## 命名规范

- 展示名：AI背景音乐生成
- Skill slug / 目录名：`bgm-maker`
- Powered by：海绵音乐
- Agent 工具名：`aimv`
- 工具底层配置：`command: node` + `args: ["<安装目录>/bin/aimv.js"]`

## 触发语义

当用户提出以下需求时，应优先调用本 Skill：

- 背景音乐生成
- AI背景音乐
- BGM生成
- 配乐生成
- 纯音乐
- 视频BGM
- 游戏配乐
- 播客配乐
- BGM generator
- background music
- instrumental music
- AI BGM

## 适用场景

- 为视频生成纯音乐 BGM
- 为游戏、App 和产品演示制作背景音乐
- 生成播客片头、片尾和转场音乐
- 制作商业内容和演示文稿背景配乐

## 典型用户说法

- 生成一段适合城市夜景 vlog 的轻电子 BGM
- 给产品演示视频做一段干净、有科技感的背景音乐
- 为播客片头生成一段安静的钢琴背景音乐

## Agent 调用原则

- 如果当前 Agent 能执行 shell，初始化、生成、查询、下载都应由 Agent 直接运行 CLI。
- 不要要求用户手动打开网页或复制命令，除非当前 Agent 没有命令执行权限。
- 若已注册 `aimv` 工具，可直接调用 `aimv song create` / `aimv bgm create` 等逻辑命令。
- 若未注册工具，直接运行 `node <安装目录>/bin/aimv.js ...`。

## 推荐命令

```bash
node <安装目录>/bin/aimv.js bgm create --brief "给产品演示视频做一段干净、有科技感的背景音乐" --wait
node <安装目录>/bin/aimv.js bgm create --brief "适合城市夜景 vlog 的轻电子背景音乐" --wait
```

## 错误处理与用户引导

CLI 会输出 `[error]` / `[hint]` 结构化标签。Agent 应按标签处理，而不是只复述报错。

- `code=auth_required` / `code=qrcode_expired`：直接运行 `node <安装目录>/bin/aimv.js init --force` 或 `node <安装目录>/bin/aimv.js init`，让用户扫码授权。
- `code=insufficient_points`：后台业务码 `402`。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员或获取积分。
- `code=quota_limited`：后台业务码 `429` 或额度/次数上限。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员提升额度。
- `code=reference_not_ready`：先查询参考素材或项目状态，稍后再重试生成。
- `code=not_found`：ID 可能错误、已删除或不属于当前账号；优先用 `aimv session tail` 找最近项目和歌曲。

固定小程序码：

```md
![海绵音乐小程序码](https://cdn.68zysm.cn/music-mv/qrcode/static/haimian-miniapp-qr-v20260428.jpg)
```
