# 场景总览与匹配指南

本文档帮助AI快速判断用户属于哪个场景，以及加载对应的模板文件。

## 快速匹配决策树

```
用户请求
  │
  ├─ 提到具体职业/角色？
  │   ├─ "我是产品经理" → project-mgmt
  │   ├─ "我做自媒体" → media
  │   ├─ "我是数据分析师" → data-analysis
  │   ├─ "我在创业" → startup
  │   └─ "我是上班族/打工人" → office
  │
  ├─ 提到具体任务？
  │   ├─ 周报/日报/邮件/会议纪要/汇报 → office
  │   ├─ 爆款标题/文案/脚本/内容分发 → media
  │   ├─ Excel/SQL/数据分析/图表/报表 → data-analysis
  │   ├─ 项目计划/任务拆分/进度管理 → project-mgmt
  │   └─ 商业计划/竞品分析/融资/市场调研 → startup
  │
  ├─ 提到具体痛点？
  │   ├─ "每天加班/工作太多" → 先诊断再匹配
  │   ├─ "不知道怎么用AI" → 进入全面方案模式
  │   └─ "重复劳动太多" → 分析重复内容再匹配
  │
  └─ 模糊请求（"怎么提升效率"）
      → 进入职业诊断模式
```

## 场景文件索引

| 场景 | 文件路径 | 模板数量 | 最适合的职业 |
|------|---------|:-------:|------------|
| 职场办公 | `references/office.md` | 10个 | 所有上班族 |
| 新媒体运营 | `references/media.md` | 10个 | 运营/自媒体/市场 |
| 数据分析 | `references/data-analysis.md` | 10个 | 分析师/财务/运营 |
| 项目管理 | `references/project-mgmt.md` | 10个 | PM/团队Leader/创业者 |
| 创业副业 | `references/startup.md` | 10个 | 创业者/自由职业/副业者 |

## 职业与场景映射表

| 职业 | 主要场景 | 次要场景 |
|------|---------|---------|
| 产品经理 | project-mgmt | office, data-analysis |
| 程序员/开发 | office, data-analysis | project-mgmt |
| UI/UX设计师 | office, project-mgmt | media |
| 新媒体运营 | media | data-analysis, startup |
| 市场营销 | media, startup | office |
| 数据分析师 | data-analysis | office, project-mgmt |
| HR/行政 | office | project-mgmt |
| 财务/会计 | data-analysis, office | - |
| 项目经理 | project-mgmt | office |
| 创业者 | startup | project-mgmt, media |
| 自由职业者 | startup, media | office |
| 学生 | office, startup | media |
| 教师/培训 | office, media | - |
| 销售/商务 | office, startup | media |

## 职业诊断问卷模板

当用户请求模糊时，使用以下问卷快速定位：

```
为了给你最匹配的AI提效方案，简单了解一下你的情况：

1. 你的职业是？（如：产品经理、运营、教师、学生...）
2. 日常工作中最耗时间的3件事？
3. 你目前用过AI工具吗？用什么？（ChatGPT/文心一言/豆包/...）
4. 你最想解决的问题是什么？（一句话）
```

## 常见跨场景组合

有些用户的需求会跨多个场景，推荐组合：

| 用户画像 | 推荐组合 |
|---------|---------|
| 一人创业者 | startup + media + office |
| 小团队Leader | project-mgmt + office + data-analysis |
| 自媒体博主 | media + data-analysis + startup |
| 职场上升期 | office + project-mgmt |
| 副业探索者 | startup + office |
