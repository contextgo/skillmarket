---
name: Epoch
description: "Convert Unix timestamps, compare epochs, and do time arithmetic. Use when converting dates, debugging timestamps, or checking timezone offsets."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["epoch","unix","timestamp","time","converter","calculator","developer"]
categories: ["Developer Tools", "Utility"]
---

# Epoch

A sysops toolkit for scanning, monitoring, reporting, alerting, tracking top processes, checking usage, verifying system state, applying fixes, cleaning up, backing up, restoring, logging, benchmarking, and comparing — all from the command line.

## Commands

| Command | Description |
|---------|-------------|
| `epoch scan <input>` | Scan systems or logs — log scan targets and findings |
| `epoch monitor <input>` | Monitor system events or metrics — record monitoring data |
| `epoch report <input>` | Generate system reports — save report specifications |
| `epoch alert <input>` | Set or log alerts — track alert conditions and triggers |
| `epoch top <input>` | Track top processes or resource consumers — log top entries |
| `epoch usage <input>` | Check resource usage — record usage metrics |
| `epoch check <input>` | Check system state — log check results |
| `epoch fix <input>` | Apply system fixes — record fix operations and outcomes |
| `epoch cleanup <input>` | Clean up old files, logs, or temp data — log cleanup actions |
| `epoch backup <input>` | Backup data or configurations — track backup operations |
| `epoch restore <input>` | Restore from backup — log restore operations |
| `epoch log <input>` | Log arbitrary events — record custom log entries |
| `epoch benchmark <input>` | Benchmark system performance — save benchmark results |
| `epoch compare <input>` | Compare configurations or results — track comparisons |
| `epoch stats` | Show summary statistics across all command categories |
| `epoch export json\|csv\|txt` | Export all logged data in JSON, CSV, or plain text format |
| `epoch search <term>` | Search across all log entries for a keyword |
| `epoch recent` | Show the 20 most recent activity entries |
| `epoch status` | Health check — version, data directory, entry count, disk usage, last activity |
| `epoch help` | Show available commands and usage |
| `epoch version` | Show version (v2.0.0) |

Each domain command (scan, monitor, report, etc.) works in two modes:
- **Without arguments**: displays the 20 most recent entries from that category
- **With arguments**: logs a new timestamped entry and shows the running total

## Data Storage

All data is stored locally in `~/.local/share/epoch/`. Each command writes to its own log file (e.g., `scan.log`, `monitor.log`, `backup.log`) and a shared `history.log` tracks all activity with timestamps. No cloud sync, no external API calls — everything stays on your machine.

## Requirements

- Bash 4+ (uses `set -euo pipefail`)
- Standard Unix utilities: `date`, `wc`, `du`, `grep`, `head`, `tail`, `basename`
- No external dependencies or API keys required

## When to Use

1. **System scanning and monitoring** — Use `scan` to log scan results across servers, `monitor` to track ongoing metrics, and `alert` to record events that need attention
2. **Backup and disaster recovery tracking** — Use `backup` and `restore` to maintain a full audit trail of backup/restore operations, and `check` to verify current system state
3. **Performance benchmarking and comparison** — Use `benchmark` to log performance test results, `compare` to track differences across configurations or time periods, and `report` to summarize findings
4. **System maintenance and cleanup** — Use `cleanup` to log removal of old logs or temp files, `fix` to track remediation actions, and `usage` to monitor resource consumption over time
5. **Operational logging and auditing** — Use `log` to record custom events, `search` to quickly find relevant entries, `stats` to get a bird's-eye view, and `export` to generate audit-ready data exports

## Examples

```bash
# Scan systems
epoch scan "Production servers — all 12 nodes responding, avg load 0.4"

# Monitor a metric
epoch monitor "Disk usage on /data: 67% (340GB of 500GB)"

# Set an alert
epoch alert "Server db-03 swap usage exceeded 80% threshold"

# Log a backup operation
epoch backup "Full backup completed: 45GB compressed to /mnt/backup/2025-03-18.tar.gz"

# Benchmark performance
epoch benchmark "PostgreSQL query: avg 12ms, p99 45ms, 10k queries/sec"

# Compare two configurations
epoch compare "nginx gzip on vs off: 40% smaller responses, 2% more CPU"

# Check system state
epoch check "All services healthy, 99.97% uptime this month"

# Clean up old logs
epoch cleanup "Removed 2.3GB of logs older than 90 days from /var/log/archive"

# Export all data to JSON
epoch export json

# View statistics
epoch stats

# Search for specific entries
epoch search backup
```

## How It Works

Epoch uses a simple append-only log architecture. Each command appends a timestamped, pipe-delimited entry (`YYYY-MM-DD HH:MM|value`) to its category-specific log file. The `stats` command aggregates line counts across all logs, `search` runs case-insensitive grep across all files, and `export` serializes everything into your chosen format (JSON, CSV, or plain text). The `status` command gives a quick system health overview including version, total entries, disk usage, and last activity timestamp.

---

*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
