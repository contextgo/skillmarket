# BigA Cron 安装命令模板
# 将 <USER_OPEN_ID> 替换为实际 open_id 后执行

# 1. 开盘前瞻（早8:30）
openclaw cron add \
  --name "biga-morning" \
  --schedule.kind cron \
  --schedule.expr "30 8 * * 1-5" \
  --schedule.tz "Asia/Shanghai" \
  --payload.kind agentTurn \
  --payload.message "【直接输出，严禁开场白。直接以📈 BigA · 大A开头输出】现在北京时间8:30，执行BigA开盘前瞻：1)读取 memory/biga-stock-pool.md 获取股票池 2)exec+curl调腾讯API(http://qt.gtimg.cn/q=sh000001,sz399001,sz399006,sz688000+池中股票代码)获取实时行情 3)web_search搜索隔夜美股/A50/外围影响 4)web_search搜索关注板块最新消息 5)更新股票池评分 6)输出大盘+🔥买入信号标的。只输出方向为🔥买入或⚠️卖出的标的。无买入/卖出信号则不推送。" \
  --payload.timeoutSeconds 180 \
  --delivery.mode none \
  --sessionTarget isolated

# 2. 盘中扫描（9:30/10:30/11:30/13:30/14:30）
openclaw cron add \
  --name "biga-scan" \
  --schedule.kind cron \
  --schedule.expr "30 9,10,11,13,14 * * 1-5" \
  --schedule.tz "Asia/Shanghai" \
  --payload.kind agentTurn \
  --payload.message "【直接输出，严禁开场白。直接以📈 BigA · 大A开头输出】现在执行BigA盘中扫描：1)读取 memory/biga-stock-pool.md 2)exec+curl调腾讯API获取全部池中股票实时行情 3)检查每支股票：涨幅>5%或跌幅>5%或成交量环比前次>50% 4)符合异动条件的股票输出分析 5)更新评分 6)如果>30支则淘汰。只推送有异动的标的+买卖建议。无异动则不推送。" \
  --payload.timeoutSeconds 180 \
  --delivery.mode none \
  --sessionTarget isolated

# 3. 收盘复盘（15:30）
openclaw cron add \
  --name "biga-evening" \
  --schedule.kind cron \
  --schedule.expr "30 15 * * 1-5" \
  --schedule.tz "Asia/Shanghai" \
  --payload.kind agentTurn \
  --payload.message "【直接输出，严禁开场白。直接以📈 BigA · 大A开头输出】现在北京时间15:30，执行BigA收盘复盘：1)读取 memory/biga-stock-pool.md 2)exec+curl调腾讯API获取全部池中股票实时行情 3)web_search搜当日大盘表现+板块轮动+北向资金 4)web_search搜池中股票今日新闻/催化剂 5)按评分模型重新评分更新 6)如果>30支则淘汰最低分 7)web_search搜索新热点（政策/产业突破/板块爆发）评估是否新增 8)输出大盘+🔥买入+⚠️卖出标的。无买入/卖出信号则不推送。" \
  --payload.timeoutSeconds 240 \
  --delivery.mode none \
  --sessionTarget isolated
