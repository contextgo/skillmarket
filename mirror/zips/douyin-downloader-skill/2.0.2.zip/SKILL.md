---
name: douyin-downloader
description: |
  抖音无水印视频下载器。支持单个/批量下载抖音视频（去除水印）。
  当用户提到"下载抖音"、"抖音无水印"、"下载视频"、"抖音链接下载"时触发。
  原生Python实现，无需GUI。
version: "2.1"
author: Skill Creator
base_dir: douyin-downloader-skill
---

# 抖音无水印视频下载器 Skill

### 技术约束说明

本 Skill 的抖音视频解析依赖脚本内实现的专用 HTTP 请求链路（重定向跟踪 → `_ROUTER_DATA` 数据提取），该流程针对抖音分享页结构定制，通用网页抓取工具无法等价替代。

> 若脚本执行失败，请将错误信息反馈给用户协助排查。

## 目录结构

```
douyin-downloader-skill\
  ├── SKILL.md          ← 本文件（Skill说明 + SOP）
  ├── requirements.txt  ← 依赖锁定（版本 + SHA256 hash）
  └── scripts\
      └── download.py   ← 核心下载脚本
```

> **下载默认保存位置：与 scripts/ 同级的目录下**
> 即 `douyin-downloader-skill\`
> 如需指定其他目录，在调用时传入第二个参数。

---

## 工作原理

```
用户输入（分享链接/文本）
  → 正则提取短链/长链
  → GET请求跟随301重定向 → 获取真实URL
  → 正则提取 video_id（支持modal_id/note_id/item_id等多种参数名）
  → GET https://www.iesdouyin.com/share/video/{video_id}/
  → 解析 window._ROUTER_DATA JSON
  → 提取 loaderData.*.videoInfoRes.item_list[0].video.play_addr.uri
  → 构造无水印链接：https://www.douyin.com/aweme/v1/play/?video_id={uri}
  → 流式下载到本地 .mp4
```

**关键Headers：**
- User-Agent: Android Chrome Mobile（模拟手机浏览器）
- Referer: https://www.douyin.com/?is_from_mobile_home=1&recommend=1
  （若403则自动去掉Referer重试）

---

## 使用方法

### 前置依赖（首次运行自动安装）

脚本首次运行时会自动安装依赖（通过 `requirements.txt`，启用 `--require-hashes` SHA256 校验）。

如需提前手动安装：
```bash
pip install -r requirements.txt --require-hashes
```

> **安全策略**：自动安装依赖时使用 `requirements.txt` + `--require-hashes` 进行 SHA256 完整性校验，防止供应链投毒。

### 单个下载（保存到 Skill 目录）

```python
import subprocess, sys
import os

script = os.path.join(os.path.dirname(__file__), "scripts", "download.py")
link = '用户提供的抖音链接或分享文本'
subprocess.run([sys.executable, script, link])
```

### 单个下载（指定保存目录）

```python
import subprocess, sys
import os

script = os.path.join(os.path.dirname(__file__), "scripts", "download.py")
link = '用户提供的抖音链接或分享文本'
output_dir = 'D:\\Videos'  # 自定义目录
subprocess.run([sys.executable, script, link, output_dir])
```

### 批量下载（txt文件每行一个链接）

```python
import subprocess, sys
import os

script = os.path.join(os.path.dirname(__file__), "scripts", "download.py")
txt_file = os.path.join(os.path.dirname(__file__), "links.txt")
subprocess.run([sys.executable, script, '--batch', txt_file])
```

### Python 直接调用

```python
import sys
import os

skill_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(skill_dir, "scripts"))
from download import run, run_batch

# 单个（保存到 Skill 目录）
run('https://v.douyin.com/xxxxxx/')

# 单个（指定目录）
run('https://v.douyin.com/xxxxxx/', 'D:\\Videos')

# 批量
run_batch(os.path.join(skill_dir, 'links.txt'))
```

---

## 操作规范（SOP）

1. **获取链接**：让用户粘贴抖音分享链接或完整分享文本（脚本自动提取链接）
2. **确认保存目录**：默认保存到 Skill 所在目录，可按用户要求修改
3. **执行下载**：调用脚本，实时显示进度条
4. **验证结果**：列出下载目录中新增的 `.mp4` 文件
5. **批量任务**：如用户有多个链接，建议先写入 `links.txt`，再用 `--batch` 模式

---

## 输出示例

```
[+] 正在解析链接: https://v.douyin.com/xxxxx/
[+] 视频ID: 7562497408383438095
[+] 视频: 所谓"长征"，从来不是过去的故事 | 作者: 延安市融媒体中心
[+] 正在下载: 所谓"长征"，从来不是过去的故事_7562497408383438095.mp4
  [##################################################] 100.0%
[OK] 下载完成！保存至: <保存目录>\所谓"长征"，从来不是过去的故事_7562497408383438095.mp4
```

文件名格式：`{视频标题前30字}_{video_id}.mp4`

---

## 注意事项

- 需要 Python 3.8+（脚本会自动安装依赖，使用 `requirements.txt` + SHA256 hash 校验）
- 如需离线/手动安装：`pip install -r requirements.txt --require-hashes`
- 不需要登录Cookie，利用 iesdouyin.com 分享页面的公开接口
- 抖音API可能变化，若解析失败可检查 `_ROUTER_DATA` 数据结构是否变更
- 下载速度受网络和抖音服务器限制
- **跨设备使用**：脚本首次运行自动安装依赖，其他电脑直接运行即可
