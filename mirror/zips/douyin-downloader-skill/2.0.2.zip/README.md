# 抖音无水印视频下载器 Skill — 安全修复说明

## 概述

本 Skill 提供抖音无水印视频下载功能，基于原生 Python 实现（无需 GUI）。

**版本**：2.1（安全修复版）

---

## 修复记录

### 问题 1：Prompt 注入模式（SKILL.md）

**原始问题**：
SKILL.md 中存在一段「重要说明」，通过技术性理由反复强调禁止 Agent 使用 `web_fetch` 等工具替代脚本执行。安全扫描将其识别为 **Prompt 注入模式**——即通过重复强制性指令试图操控 Agent 行为。

**修复方案**：
- 将标题从 `### 重要说明` 改为 `### 技术约束说明`
- 移除命令式/禁止式措辞（如"勿用其他工具替代重试"）
- 改为**陈述性描述**：客观说明技术实现原理（专用请求链路针对抖音页面定制），而非对 Agent 下达行为约束
- 核心功能逻辑完全不变

### 问题 2：自动依赖安装的供应链风险（download.py 第20行附近）

**原始问题**：
`download.py` 的自动安装逻辑存在 **fallback 分支**：当 `requirements.txt` 不存在时，会直接执行 `pip install requests==2.33.1 --hash=sha256:...` 虽然该分支也带了 hash，但安全扫描认为：
1. fallback 分支的 hash 是硬编码在源码中的，不如 `requirements.txt` 集中管理安全
2. 存在两条安装路径增加了审计复杂度
3. 理想情况下应强制要求 `requirements.txt` 存在，否则拒绝运行

**修复方案**：
- **移除 fallback 分支**（不再有裸 pip install 路径）
- 当 `requirements.txt` 不存在时，**直接报错退出**（`sys.exit(1)`），提示用户手动安装
- 所有安装路径统一走 `pip install -r requirements.txt --require-hashes`
- 注释同步更新为「仅通过 requirements.txt + --require-hashes」

### 问题 3：SKILL.md 文档与代码不一致

**修复方案**：
- 更新所有文档中的安全策略描述，统一表述为「使用 `requirements.txt` + SHA256 hash 校验」
- 移除散落在各处的 `requests==2.33.1` 字面量引用，改为指向 `requirements.txt`

---

## 当前安全机制

| 安全措施 | 说明 |
|---------|------|
| 版本锁定 | `requirements.txt` 中所有依赖固定精确版本号 |
| SHA256 校验 | 安装时强制 `--require-hashes`，pip 会校验每个包的 SHA256 |
| 单一安装路径 | 移除 fallback，仅允许通过 requirements.txt 安装 |
| 缺失即中止 | requirements.txt 缺失时不尝试任何自动安装，直接报错退出 |

## 文件清单

```
douyin-downloader-skill/
├── README.md              ← 本文件（安全修复说明）
├── SKILL.md               ← Skill 说明 + SOP（已修复 Prompt 注入风格）
├── requirements.txt       ← 依赖锁定（版本号 + SHA256 hash）
└── scripts/
    └── download.py        ← 核心下载脚本（已移除非 hash 安装路径）
```

---

## 核心功能未变更

以下核心功能在本次修复中 **完全保持不变**：

1. ✅ 抖音短链/长链提取与解析
2. ✅ 301 重定向跟踪获取真实 URL
3. ✅ `_ROUTER_DATA` JSON 解析提取视频信息
4. ✅ 无水印视频地址构造与流式下载
5. ✅ 单个/批量下载支持
6. ✅ 403 自动去 Referer 重试机制
7. ✅ 进度条显示与结果验证
