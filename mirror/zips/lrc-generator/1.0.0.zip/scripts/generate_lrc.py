#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LRC歌词生成脚本
根据音频和歌词文本生成带时间轴的LRC文件

用法:
    python generate_lrc.py <音频文件> <歌词文件> [输出文件]

示例:
    python generate_lrc.py audio.wav lyrics.txt output.lrc
"""

import sys
import os
import json

def check_dependencies():
    """检查必要的依赖是否已安装"""
    try:
        import whisper
        print(f"✓ Whisper 已安装 (版本: {whisper.__version__})")
    except ImportError:
        print("✗ Whisper 未安装")
        print("  请运行: pip install openai-whisper torch numba")
        return False

    try:
        import subprocess
        result = subprocess.run(['ffmpeg', '-version'], capture_output=True, text=True)
        if result.returncode == 0:
            version = result.stdout.split('\n')[0]
            print(f"✓ FFmpeg 已安装 ({version})")
        else:
            raise Exception("FFmpeg not found")
    except Exception:
        print("✗ FFmpeg 未安装")
        print("  请访问 https://ffmpeg.org/download.html 下载安装")
        return False

    return True

def format_time(seconds):
    """将秒数转换为LRC时间格式 [mm:ss.xx]"""
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 100)
    return f"[{minutes:02d}:{secs:02d}.{millis:02d}]"

def transcribe_audio(audio_path, model_size="small"):
    """
    使用Whisper识别音频，返回带时间戳的结果

    参数:
        audio_path: 音频文件路径
        model_size: 模型大小 (tiny/base/small/medium/large)
    """
    import whisper

    print(f"\n正在加载Whisper模型 ({model_size})...")
    model = whisper.load_model(model_size)

    print(f"正在识别音频: {audio_path}")
    print("这可能需要几分钟，请耐心等待...\n")

    result = model.transcribe(
        audio_path,
        language="zh",
        verbose=True,
        word_timestamps=True
    )

    return result

def align_lyrics(lyrics_lines, segments):
    """
    将歌词行与识别的时间戳对齐

    参数:
        lyrics_lines: 歌词文本行列表
        segments: Whisper识别的片段列表

    返回:
        对齐后的 (歌词, 开始时间, 结束时间) 列表
    """
    aligned = []

    # 简单对齐策略：按顺序匹配
    # 实际应用中可能需要更复杂的模糊匹配算法
    for i, line in enumerate(lyrics_lines):
        if i < len(segments):
            seg = segments[i]
            aligned.append((
                line,
                seg["start"],
                seg["end"]
            ))
        else:
            # 如果歌词行多于识别片段，使用估算时间
            if aligned:
                last_end = aligned[-1][2]
                aligned.append((line, last_end, last_end + 3))
            else:
                aligned.append((line, 0, 3))

    return aligned

def generate_lrc(aligned_lyrics, output_path, metadata=None):
    """
    生成LRC文件

    参数:
        aligned_lyrics: 对齐后的歌词列表 [(text, start, end), ...]
        output_path: 输出文件路径
        metadata: 元数据字典 {title, artist, album}
    """
    if metadata is None:
        metadata = {}

    lrc_lines = []
    lrc_lines.append(f"[ti:{metadata.get('title', '未知标题')}]")
    lrc_lines.append(f"[ar:{metadata.get('artist', '未知艺术家')}]")
    lrc_lines.append(f"[al:{metadata.get('album', '未知专辑')}]")
    lrc_lines.append("[by:LRC Generator]")
    lrc_lines.append("")

    for text, start, end in aligned_lyrics:
        if text.strip():
            lrc_lines.append(f"{format_time(start)}{text}")
        else:
            lrc_lines.append("")

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lrc_lines))

    print(f"\n✓ LRC文件已生成: {output_path}")

def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    audio_path = sys.argv[1]
    lyrics_path = sys.argv[2]
    output_path = sys.argv[3] if len(sys.argv) > 3 else "output.lrc"

    # 检查文件是否存在
    if not os.path.exists(audio_path):
        print(f"错误: 音频文件不存在: {audio_path}")
        sys.exit(1)

    if not os.path.exists(lyrics_path):
        print(f"错误: 歌词文件不存在: {lyrics_path}")
        sys.exit(1)

    # 检查依赖
    print("检查依赖环境...")
    if not check_dependencies():
        sys.exit(1)

    # 读取歌词
    print(f"\n读取歌词文件: {lyrics_path}")
    with open(lyrics_path, 'r', encoding='utf-8') as f:
        lyrics_lines = f.read().strip().split('\n')
    print(f"  共 {len(lyrics_lines)} 行")

    # 语音识别
    result = transcribe_audio(audio_path)
    segments = result["segments"]
    print(f"\n识别完成，共 {len(segments)} 个片段")

    # 对齐歌词
    print("\n对齐歌词与时间戳...")
    aligned = align_lyrics(lyrics_lines, segments)

    # 生成LRC
    metadata = {
        "title": os.path.splitext(os.path.basename(audio_path))[0],
        "artist": "未知",
        "album": "未知"
    }
    generate_lrc(aligned, output_path, metadata)

    print(f"\n完成！")
    print(f"  音频: {audio_path}")
    print(f"  歌词: {lyrics_path}")
    print(f"  输出: {output_path}")

if __name__ == "__main__":
    main()
