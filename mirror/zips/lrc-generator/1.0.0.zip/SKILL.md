---
name: lrc-generator
description: Generate LRC lyric files from audio and text lyrics using speech recognition. Use when the user wants to create LRC files, sync lyrics with audio, generate subtitle files for music, or align text with audio timestamps.
---

# LRC歌词生成器

根据音频文件和歌词文本生成带时间轴的LRC文件。

## 工作流程

```
Task Progress:
- [ ] 步骤1: 检查依赖环境 (Whisper, FFmpeg)
- [ ] 步骤2: 读取歌词文本文件
- [ ] 步骤3: 使用Whisper识别音频获取时间戳
- [ ] 步骤4: 将识别结果与歌词文本对齐
- [ ] 步骤5: 生成LRC文件
- [ ] 步骤6: 验证输出
```

## 步骤1: 检查依赖环境

检查是否安装了必要的工具：

```bash
# 检查Whisper
python -c "import whisper; print('Whisper:', whisper.__version__)"

# 检查FFmpeg
ffmpeg -version
```

如未安装，执行安装：

```bash
# 安装Whisper及其依赖
pip install openai-whisper torch numba more-itertools tiktoken

# FFmpeg需单独安装，参见 https://ffmpeg.org/download.html
```

## 步骤2: 读取歌词文本

读取用户提供的歌词文件（通常是.txt格式）：

```python
with open("歌词.txt", "r", encoding="utf-8") as f:
    lyrics = f.read()
```

将歌词按行分割，保留空行用于表示停顿：

```python
lyrics_lines = lyrics.strip().split("\n")
```

## 步骤3: 语音识别获取时间戳

使用Whisper识别音频，获取每句的时间戳：

```python
import whisper
import json

model = whisper.load_model("small")  # 可选: tiny/base/small/medium/large

result = model.transcribe(
    "音频.wav",
    language="zh",
    verbose=True,
    word_timestamps=True
)

# 保存识别结果
with open("whisper_result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
```

**模型选择建议：**
- `tiny`: 最快，精度较低
- `base`: 较快，适合清晰音频
- `small`: 平衡选择（推荐）
- `medium`/`large`: 最准确，但较慢

## 步骤4: 对齐歌词与时间戳

将Whisper识别的时间戳与正确歌词对齐：

```python
def format_time(seconds):
    """转换为LRC时间格式 [mm:ss.xx]"""
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 100)
    return f"[{minutes:02d}:{secs:02d}.{millis:02d}]"

# 读取Whisper结果
with open("whisper_result.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# 创建时间映射 (lyrics_index, start_time, end_time)
time_mapping = []
for i, seg in enumerate(data["segments"]):
    time_mapping.append((
        i,  # 对应歌词行索引
        seg["start"],
        seg["end"]
    ))
```

## 步骤5: 生成LRC文件

根据对齐结果生成LRC格式文件：

```python
lrc_lines = []
lrc_lines.append("[ti:歌曲标题]")
lrc_lines.append("[ar:艺术家]")
lrc_lines.append("[al:专辑]")
lrc_lines.append("[by:QoderWork]")
lrc_lines.append("")

# 根据时间映射生成歌词行
for idx, start_time, end_time in time_mapping:
    if idx < len(lyrics_lines):
        line = lyrics_lines[idx]
        if line.strip():
            lrc_lines.append(f"{format_time(start_time)}{line}")
        else:
            lrc_lines.append("")

# 保存LRC文件
with open("歌词.lrc", "w", encoding="utf-8") as f:
    f.write("\n".join(lrc_lines))
```

## 步骤6: 验证输出

检查生成的LRC文件：

1. 时间戳是否递增
2. 歌词行数是否匹配
3. 文件编码是否为UTF-8

## 完整示例脚本

见 [scripts/generate_lrc.py](scripts/generate_lrc.py)

## 注意事项

1. **音频质量**: 清晰的音频识别效果更好
2. **语言设置**: 根据音频语言设置正确的language参数
3. **诗歌/朗诵**: 对于非歌曲类音频，识别可能有音近字错误，需要人工校对
4. **时间调整**: 生成的LRC可能需要微调，可用歌词编辑软件调整

## 输出格式示例

```
[ti:歌曲标题]
[ar:艺术家]
[al:专辑]
[by:QoderWork]

[00:11.94]绿绸半张 指落刀兵
[00:18.54]四方如城 他坐如渊
[00:26.98]筹码移山 收回江水
...
```
