# LRC生成器使用示例

## 示例1: 基本用法

生成LRC文件：

```bash
python scripts/generate_lrc.py audio.wav lyrics.txt output.lrc
```

## 示例2: Python代码集成

```python
import whisper
import json

def generate_lrc(audio_path, lyrics_path, output_path):
    # 读取歌词
    with open(lyrics_path, 'r', encoding='utf-8') as f:
        lyrics_lines = [line.strip() for line in f]

    # 语音识别
    model = whisper.load_model("small")
    result = model.transcribe(audio_path, language="zh")

    # 生成LRC
    def format_time(s):
        return f"[{int(s//60):02d}:{int(s%60):02d}.{int((s%1)*100):02d}]"

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("[ti:歌曲]\n[ar:未知]\n\n")
        for i, seg in enumerate(result["segments"]):
            if i < len(lyrics_lines):
                f.write(f"{format_time(seg['start'])}{lyrics_lines[i]}\n")

# 使用
generate_lrc("audio.wav", "lyrics.txt", "output.lrc")
```

## 示例3: 处理诗歌/朗诵

对于诗歌朗诵类音频，识别可能有音近字错误，建议：

1. 先运行识别获取时间戳
2. 人工校对歌词匹配
3. 生成最终LRC

```python
# 步骤1: 仅获取时间戳
result = model.transcribe("poem.wav", language="zh")

# 步骤2: 保存时间戳供人工参考
timestamps = [(s["start"], s["end"]) for s in result["segments"]]

# 步骤3: 使用正确歌词和获取的时间戳生成LRC
# ...
```

## 示例4: 批量处理

```python
import os
import glob

for audio_file in glob.glob("*.wav"):
    base_name = os.path.splitext(audio_file)[0]
    lyrics_file = base_name + ".txt"
    output_file = base_name + ".lrc"

    if os.path.exists(lyrics_file):
        print(f"处理: {audio_file}")
        # generate_lrc(audio_file, lyrics_file, output_file)
```
