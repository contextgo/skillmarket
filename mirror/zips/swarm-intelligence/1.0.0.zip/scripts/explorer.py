"""
探索器
单个蜜蜂的探索逻辑
"""

import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Callable
from datetime import datetime


@dataclass
class ExplorationResult:
    """探索结果"""
    explorer_id: str
    strategy: str
    result: any
    quality: float  # 0-1
    steps: int
    timestamp: str


class Explorer:
    """探索蜜蜂"""
    
    def __init__(self, explorer_id: str, strategy: str):
        self.id = explorer_id
        self.strategy = strategy
        self.pheromone = 1.0  # 初始信息素
        self.exploration_count = 0
        self.success_count = 0
    
    def explore(self, task: str, 
                executor: Callable[[str, str], tuple]) -> ExplorationResult:
        """
        执行探索
        
        Args:
            task: 任务描述
            executor: 执行函数 (task, strategy) -> (result, quality)
            
        Returns:
            探索结果
        """
        self.exploration_count += 1
        
        # 执行策略
        result, quality = executor(task, self.strategy)
        
        if quality > 0.5:
            self.success_count += 1
        
        return ExplorationResult(
            explorer_id=self.id,
            strategy=self.strategy,
            result=result,
            quality=quality,
            steps=1,
            timestamp=datetime.now().isoformat()
        )
    
    def deposit_pheromone(self, quality: float):
        """沉积信息素"""
        # 高质量结果增加更多信息素
        deposit = 1.0 + quality
        self.pheromone += deposit
    
    def evaporate_pheromone(self, rate: float = 0.1):
        """信息素挥发"""
        self.pheromone *= (1 - rate)
        # 保持最小值
        self.pheromone = max(0.1, self.pheromone)
    
    def get_confidence(self) -> float:
        """获取置信度"""
        if self.exploration_count == 0:
            return 0.5
        
        # 基于成功率和信息素计算置信度
        success_rate = self.success_count / self.exploration_count
        pheromone_factor = min(1.0, self.pheromone / 10.0)
        
        return (success_rate * 0.6 + pheromone_factor * 0.4)
