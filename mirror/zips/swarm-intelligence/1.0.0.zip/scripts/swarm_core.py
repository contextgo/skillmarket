"""
蜂群核心
管理多个探索蜜蜂，实现集体智能
"""

import json
import random
from pathlib import Path
from typing import Dict, List, Optional, Callable, Any
from datetime import datetime

from explorer import Explorer, ExplorationResult


class SwarmCore:
    """蜂群智能核心"""
    
    DEFAULT_EXPLORER_COUNT = 3
    PHEROMONE_EVAPORATION_RATE = 0.1
    
    def __init__(self, data_dir: Optional[Path] = None):
        if data_dir is None:
            data_dir = Path.home() / ".workbuddy" / "dreams"
        self.data_dir = data_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.pheromone_file = self.data_dir / "pheromone-map.json"
        self.history_file = self.data_dir / "swarm-history.json"
        self.log_file = self.data_dir / "exploration-log.json"
        
        self.explorers: Dict[str, Explorer] = {}
        self.pheromone_map: Dict[str, float] = {}
        self.exploration_history: List[Dict] = []
        
        self._load_state()
    
    def _load_state(self):
        """加载状态"""
        if self.pheromone_file.exists():
            try:
                with open(self.pheromone_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.pheromone_map = data.get("pheromones", {})
            except:
                pass
        
        if self.history_file.exists():
            try:
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.exploration_history = data.get("history", [])
            except:
                pass
    
    def _save_state(self):
        """保存状态"""
        with open(self.pheromone_file, 'w', encoding='utf-8') as f:
            json.dump({
                "pheromones": self.pheromone_map,
                "updated_at": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
        
        with open(self.history_file, 'w', encoding='utf-8') as f:
            json.dump({
                "history": self.exploration_history[-100:],  # 只保留最近100条
                "updated_at": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
    
    def create_explorers(self, strategies: Optional[List[str]] = None) -> List[Explorer]:
        """
        创建探索蜜蜂
        
        Args:
            strategies: 策略列表，默认生成3个通用策略
            
        Returns:
            探索蜜蜂列表
        """
        if strategies is None:
            strategies = [
                "保守策略：安全第一，小步验证",
                "平衡策略：兼顾效率和质量",
                "激进策略：快速推进，大胆尝试"
            ]
        
        explorers = []
        for i, strategy in enumerate(strategies[:self.DEFAULT_EXPLORER_COUNT]):
            explorer_id = f"E{i+1}_{datetime.now().strftime('%H%M%S')}"
            
            # 检查是否有历史信息素
            if strategy in self.pheromone_map:
                initial_pheromone = self.pheromone_map[strategy]
            else:
                initial_pheromone = 1.0
            
            explorer = Explorer(explorer_id, strategy)
            explorer.pheromone = initial_pheromone
            
            self.explorers[explorer_id] = explorer
            explorers.append(explorer)
        
        return explorers
    
    def explore(self, task: str, 
                executor: Callable[[str, str], tuple],
                strategies: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        执行蜂群探索
        
        Args:
            task: 任务描述
            executor: 执行函数
            strategies: 策略列表
            
        Returns:
            探索结果汇总
        """
        # 创建探索者
        explorers = self.create_explorers(strategies)
        
        # 并行探索
        results = []
        for explorer in explorers:
            result = explorer.explore(task, executor)
            results.append(result)
            
            # 更新信息素
            if result.quality > 0.5:
                explorer.deposit_pheromone(result.quality)
            else:
                explorer.evaporate_pheromone(self.PHEROMONE_EVAPORATION_RATE)
            
            # 更新全局信息素地图
            self.pheromone_map[explorer.strategy] = explorer.pheromone
        
        # 选择最优结果
        best_result = max(results, key=lambda r: r.quality)
        
        # 记录历史
        self.exploration_history.append({
            "task": task[:100],
            "timestamp": datetime.now().isoformat(),
            "explorers_count": len(explorers),
            "best_strategy": best_result.strategy,
            "best_quality": best_result.quality
        })
        
        self._save_state()
        
        return {
            "task": task,
            "explorations": [
                {
                    "explorer_id": r.explorer_id,
                    "strategy": r.strategy,
                    "quality": r.quality,
                    "pheromone": self.explorers[r.explorer_id].pheromone
                }
                for r in results
            ],
            "best_result": {
                "strategy": best_result.strategy,
                "quality": best_result.quality,
                "result": best_result.result
            },
            "confidence": best_result.quality
        }
    
    def get_pheromone_ranking(self) -> List[tuple]:
        """获取信息素排名"""
        return sorted(
            self.pheromone_map.items(),
            key=lambda x: x[1],
            reverse=True
        )
    
    def evaporate_all(self, rate: float = 0.1):
        """全局信息素挥发"""
        for strategy in self.pheromone_map:
            self.pheromone_map[strategy] *= (1 - rate)
            self.pheromone_map[strategy] = max(0.1, self.pheromone_map[strategy])
        
        self._save_state()
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        return {
            "active_explorers": len(self.explorers),
            "pheromone_trails": len(self.pheromone_map),
            "total_explorations": len(self.exploration_history),
            "top_strategy": self.get_pheromone_ranking()[0] if self.pheromone_map else None
        }


# 单例
_swarm_core_instance: Optional[SwarmCore] = None


def get_swarm_core() -> SwarmCore:
    global _swarm_core_instance
    if _swarm_core_instance is None:
        _swarm_core_instance = SwarmCore()
    return _swarm_core_instance
