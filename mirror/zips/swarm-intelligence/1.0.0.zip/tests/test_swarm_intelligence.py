#!/usr/bin/env python3
"""
蜂群智能系统测试套件
"""
import unittest
import sys
import os
import tempfile
from pathlib import Path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

from swarm_core import SwarmCore
from explorer import Explorer, ExplorationResult


class TestSwarmCore(unittest.TestCase):
    """测试蜂群智能核心"""
    
    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.swarm = SwarmCore(data_dir=self.temp_dir)
    
    def test_create_explorers(self):
        """测试创建探索者"""
        explorers = self.swarm.create_explorers()
        
        self.assertEqual(len(explorers), 3)  # 默认3个
        self.assertEqual(len(self.swarm.explorers), 3)
    
    def test_explore(self):
        """测试蜂群探索"""
        def executor(task, strategy):
            return ({"result": "test"}, 0.7)
        
        result = self.swarm.explore("测试任务", executor)
        
        self.assertIn("explorations", result)
        self.assertIn("best_result", result)
        self.assertIn("confidence", result)
    
    def test_get_pheromone_ranking(self):
        """测试信息素排名"""
        # 先执行一次探索
        def executor(task, strategy):
            return ({}, 0.8)
        
        self.swarm.explore("任务", executor)
        
        ranking = self.swarm.get_pheromone_ranking()
        
        self.assertIsInstance(ranking, list)
    
    def test_evaporate_all(self):
        """测试全局信息素挥发"""
        # 先执行一次探索
        def executor(task, strategy):
            return ({}, 0.8)
        
        self.swarm.explore("任务", executor)
        initial = dict(self.swarm.pheromone_map)
        
        self.swarm.evaporate_all(rate=0.1)
        
        # 信息素应该减少
        for key in initial:
            self.assertLess(self.swarm.pheromone_map[key], initial[key])


class TestExplorer(unittest.TestCase):
    """测试探索者"""
    
    def setUp(self):
        self.explorer = Explorer(explorer_id="test_explorer", strategy="test_strategy")
    
    def test_explore(self):
        """测试探索"""
        def executor(task, strategy):
            return ({"value": 42}, 0.8)
        
        result = self.explorer.explore("test task", executor)
        
        self.assertIsInstance(result, ExplorationResult)
        self.assertEqual(result.explorer_id, "test_explorer")
        self.assertEqual(result.strategy, "test_strategy")
    
    def test_exploration_count(self):
        """测试探索计数"""
        def executor(task, strategy):
            return ({}, 0.5)
        
        self.explorer.explore("task1", executor)
        self.explorer.explore("task2", executor)
        
        self.assertEqual(self.explorer.exploration_count, 2)
    
    def test_deposit_pheromone(self):
        """测试信息素沉积"""
        initial = self.explorer.pheromone
        
        self.explorer.deposit_pheromone(0.8)
        
        self.assertGreater(self.explorer.pheromone, initial)
    
    def test_evaporate_pheromone(self):
        """测试信息素挥发"""
        initial = self.explorer.pheromone
        
        self.explorer.evaporate_pheromone(0.1)
        
        self.assertLess(self.explorer.pheromone, initial)


class TestExplorationResult(unittest.TestCase):
    """测试探索结果"""
    
    def test_result_creation(self):
        """测试结果创建"""
        result = ExplorationResult(
            explorer_id="e1",
            strategy="s1",
            result="test",
            quality=0.9,
            steps=1,
            timestamp="2024-01-01"
        )
        
        self.assertEqual(result.explorer_id, "e1")
        self.assertEqual(result.quality, 0.9)


if __name__ == "__main__":
    unittest.main()
