# AIWolfPK — AI狼人杀

> 四个AI互相猜疑，你坐着看戏。每局30秒，到底谁是狼？

---

## 快速开始

安装后对AI说一句话：

```
来一局
```

然后你就是观众。AI自己聊，自己投票，自己出局。

---

## 游戏规则

- **4个AI** = 3好人 + 1狼人
- 所有人拿到同一个话题，但好人和狼人拿到**相反的关键词**
- 狼人必须伪装成正常人
- 第一轮：发言 → 质疑 → 投票 → 淘汰
- 第二轮（如果狼还活着）：发言 → 投票 → 淘汰
- **好人投出狼 → 好人赢 / 场上剩1好1狼 → 狼赢**

---

## 两种模式

### 多AI对战（推荐）

如果你的环境有多个AI模型，每个角色由不同AI扮演。默认配置：

| 角色 | 模型 | 覆盖率 | 修改位置 |
|------|------|:------:|--------|
| 🟨 Kimi | Kimi-K2.6 | 4/4平台 | agents/player1/config.json |
| 🟩 GLM | GLM-5.1 | 4/4平台 | agents/player2/config.json |
| 🟥 MiniMax | MiniMax-M2.7 | 4/4平台 | agents/player3/config.json |
| 🟦 旗舰 | 各平台自家旗舰 | — | agents/player4/config.json |

**第4个角色按平台选择旗舰模型：**

| 平台 | 旗舰模型 | 显示名 |
|------|---------|--------|
| WorkBuddy / CodyBuddy | Hy3 preview | 混元 |
| QClaw（腾讯） | Hy3 preview | 混元 |
| AutoClaw（智谱） | Pony-Alpha-2 | Pony |
| ArkClaw（字节） | Doubao-Seed-2.0-Pro | 豆包 |
| CoPaw（阿里） | Qwen3.5-128B | 通义 |

不同AI之间是**物理隔离**的——它们真的互相看不到对方的身份。

### 单AI模式

只有一个模型也能玩。AI会同时扮演4个角色，用不同语气区分。

---

## 安装

### ClawHub / SkillHub

```bash
clawhub install aiwolfpk
```

### GitHub

```bash
npx skills add huangjihua007-rgb/aiwolfpk
```

---

## 文件结构

```
SKILL.md              ← 营销文案 + 单模型游戏逻辑
skill.json            ← 多Agent架构配置
manifest.json         ← 包元数据
agents/
  gamemaster/         ← 游戏主持（编排全局）
  player1-4/          ← 4个玩家Agent（各有独立人格）
```

---

## 常见问题

**Q: 我只有2个模型能玩吗？**
A: 能。把4个player的config.json都改成你有的模型即可，同一模型可以分配给多个角色。最低1个模型就能跑（单模型模式）。

**Q: 怎么换话题？**
A: 每局自动随机选题，内置10个精选话题。说"再来一局"换话题。

**Q: 一局多长时间？**
A: 30秒左右，最长不超过1分钟。

---

## License

MIT

## Author

huangjihua007-rgb
