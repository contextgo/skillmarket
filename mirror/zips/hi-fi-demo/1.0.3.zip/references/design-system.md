# 企业 H5 高保真 Demo 设计系统

> 构建专业级企业 H5 Demo 的最佳实践

## 一、技术架构

### 1.1 推荐技术栈

```
Vue 3 CDN + Vue Router 4 + localStorage + Font Awesome 6
```

**CDN 依赖（带国内镜像）**：

```html
<!-- Vue 3 -->
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<!-- 国内镜像（备选） -->
<!-- <script src="https://cdn.bootcdn.net/ajax/libs/vue/3.4.21/vue.global.prod.min.js"></script> -->

<!-- Vue Router -->
<script src="https://unpkg.com/vue-router@4/dist/vue-router.global.prod.js"></script>

<!-- 图标库 -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<!-- 国内镜像（备选） -->
<!-- <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.5.1/css/all.min.css"> -->
```

**离线环境解决方案**：

将上述文件下载到本地 `vendor/` 目录：

```html
<script src="vendor/vue.global.prod.js"></script>
<script src="vendor/vue-router.global.prod.js"></script>
<link rel="stylesheet" href="vendor/fontawesome.all.min.css">
```

**技术栈优势**：
- 零构建配置，文件直接浏览器打开即可运行
- 完全离线可用，适合客户现场演示
- localStorage 实现数据持久化，无需后端
- CSS Variables 设计令牌，一处修改全局生效

### 1.2 项目结构

```
project/
├── index.html              # 入口：角色选择页（可选）
├── h5.html                  # H5 移动端 SPA（多角色合一）
├── admin.html               # PC 管理端 SPA（可选）
├── exec.html                # 高管驾驶舱 SPA（可选）
├── css/
│   ├── variables.css        # 设计令牌（颜色/字号/间距/阴影/动效）
│   ├── base.css             # 全局重置、按钮、卡片、标签、动画
│   ├── h5.css              # H5 端专用样式
│   ├── admin.css           # PC 管理端专用样式
│   └── exec.css            # 高管端专用样式
└── js/
    ├── store.js             # 数据管理层（Store + DataManager）
    └── utils.js             # 工具函数（日期/格式化/AI模拟）
```

## 二、设计令牌（Design Tokens）

### 2.1 完整颜色体系

```css
:root {
  /* === 品牌色 === */
  --color-primary: #07C160;           /* 企业微信绿 */
  --color-primary-light: #38D97A;     /* 浅绿 */
  --color-primary-dark: #06AD56;      /* 深绿 */
  --color-primary-bg: rgba(7, 193, 96, 0.08);
  --color-primary-bg-hover: rgba(7, 193, 96, 0.15);

  /* === 辅色 === */
  --color-secondary: #576B95;
  --color-secondary-light: #7089B8;
  --color-secondary-bg: rgba(87, 107, 149, 0.08);

  /* === 功能色 === */
  --color-success: #07C160;
  --color-warning: #FAAD14;
  --color-warning-orange: #FA8C16;
  --color-danger: #FF4D4F;
  --color-info: #1890FF;

  /* === 预警三级色 === */
  --color-alert-yellow: #FAAD14;
  --color-alert-yellow-bg: rgba(250, 173, 20, 0.1);
  --color-alert-orange: #FA8C16;
  --color-alert-orange-bg: rgba(250, 140, 22, 0.1);
  --color-alert-red: #FF4D4F;
  --color-alert-red-bg: rgba(255, 77, 79, 0.1);

  /* === 中性色 === */
  --color-text-primary: #1A1A1A;
  --color-text-secondary: #666666;
  --color-text-tertiary: #999999;
  --color-text-placeholder: #CCCCCC;
  --color-text-inverse: #FFFFFF;

  --color-bg-page: #F5F6FA;
  --color-bg-card: #FFFFFF;
  --color-bg-hover: #F7F8FA;
  --color-bg-active: #EEEEF0;
  --color-bg-overlay: rgba(0, 0, 0, 0.5);

  --color-border: #E8E8EC;
  --color-border-light: #F0F0F3;
  --color-divider: #F2F2F5;

  /* === 高管端紫色系 === */
  --color-exec-primary: #6C5CE7;
  --color-exec-primary-light: #A29BFE;
  --color-exec-sidebar-from: #2D1B3D;
  --color-exec-sidebar-to: #1E1E1E;
  --color-exec-accent: #FF6B6B;
}
```

### 2.2 字体规范

```css
:root {
  /* 字体栈 */
  --font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC',
    'Hiragino Sans GB', 'Microsoft YaHei', 'Helvetica Neue', Helvetica,
    Arial, sans-serif;

  /* 字号 */
  --font-size-h1: 24px;
  --font-size-h2: 20px;
  --font-size-h3: 17px;
  --font-size-body: 15px;
  --font-size-caption: 13px;
  --font-size-mini: 11px;

  /* 字重 */
  --font-weight-regular: 400;
  --font-weight-medium: 500;
  --font-weight-semibold: 600;
  --font-weight-bold: 700;
  --font-weight-heavy: 800;

  /* 行高 */
  --line-height-tight: 1.25;
  --line-height-normal: 1.5;
  --line-height-loose: 1.75;
}
```

### 2.3 间距规范

```css
:root {
  --space-xs: 4px;
  --space-sm: 8px;
  --space-md: 12px;
  --space-base: 16px;
  --space-lg: 20px;
  --space-xl: 24px;
  --space-2xl: 32px;
  --space-3xl: 48px;
}
```

### 2.4 圆角规范

```css
:root {
  --radius-xs: 4px;
  --radius-sm: 6px;
  --radius-md: 10px;
  --radius-lg: 14px;
  --radius-xl: 18px;
  --radius-2xl: 24px;
  --radius-full: 9999px;
}
```

### 2.5 阴影规范

```css
:root {
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.07);
  --shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.09);
  --shadow-xl: 0 16px 48px rgba(0, 0, 0, 0.12);
  --shadow-card: 0 1px 3px rgba(0, 0, 0, 0.04), 0 4px 12px rgba(0, 0, 0, 0.03);
  --shadow-card-hover: 0 8px 28px rgba(0, 0, 0, 0.09), 0 2px 8px rgba(0, 0, 0, 0.04);
  --shadow-float: 0 12px 36px rgba(0, 0, 0, 0.15);
  --shadow-green: 0 4px 14px rgba(7, 193, 96, 0.25);
  --shadow-purple: 0 4px 14px rgba(108, 92, 231, 0.25);
  --shadow-red: 0 4px 14px rgba(255, 77, 79, 0.25);
}
```

### 2.6 动效规范

```css
:root {
  --duration-fast: 150ms;
  --duration-normal: 250ms;
  --duration-slow: 350ms;
  --ease-out: cubic-bezier(0.22, 1, 0.36, 1);
  --ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
  --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
}
```

### 2.7 层级规范

```css
:root {
  --z-normal: 1;
  --z-sticky: 10;
  --z-fixed: 100;
  --z-overlay: 500;
  --z-modal: 1000;
  --z-toast: 2000;
}
```

### 2.8 布局尺寸

```css
:root {
  --sidebar-width: 220px;
  --sidebar-collapsed-width: 64px;
  --header-height: 56px;
  --tabbar-height: 50px;
  --content-max-width: 1200px;
}
```

## 三、基础样式（base.css）

### 3.1 全局重置

```css
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  font-size: 16px;
  -webkit-text-size-adjust: 100%;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: optimizeLegibility;
}

body {
  font-family: var(--font-family);
  font-size: var(--font-size-body);
  color: var(--color-text-primary);
  background: var(--color-bg-page);
  line-height: var(--line-height-normal);
  overflow-x: hidden;
}

a { color: inherit; text-decoration: none; }
img { max-width: 100%; display: block; }

button {
  font-family: inherit;
  cursor: pointer;
  border: none;
  background: none;
  font-size: inherit;
  color: inherit;
  outline: none;
  -webkit-tap-highlight-color: transparent;
}

input, textarea, select {
  font-family: inherit;
  font-size: inherit;
  outline: none;
  border: none;
  background: none;
}

ul, ol { list-style: none; }
```

### 3.2 滚动条样式

```css
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.12);
  border-radius: 3px;
}
::-webkit-scrollbar-thumb:hover { background: rgba(0, 0, 0, 0.2); }
```

### 3.3 按钮组件

```css
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-sm);
  padding: 0 var(--space-lg);
  height: 40px;
  border-radius: var(--radius-md);
  font-size: var(--font-size-body);
  font-weight: var(--font-weight-medium);
  transition: all var(--duration-fast) var(--ease-out);
  white-space: nowrap;
  user-select: none;
}

.btn:active { transform: scale(0.96); }

.btn-primary {
  background: var(--color-primary);
  color: white;
  box-shadow: 0 2px 8px rgba(7, 193, 96, 0.3);
}
.btn-primary:hover {
  background: var(--color-primary-light);
  box-shadow: 0 4px 12px rgba(7, 193, 96, 0.35);
}

.btn-secondary { background: var(--color-bg-page); color: var(--color-text-primary); }
.btn-secondary:hover { background: var(--color-bg-active); }

.btn-danger {
  background: var(--color-danger);
  color: white;
  box-shadow: 0 2px 8px rgba(255, 77, 79, 0.3);
}

.btn-outline {
  border: 1px solid var(--color-border);
  color: var(--color-text-secondary);
  background: white;
}
.btn-outline:hover {
  border-color: var(--color-primary);
  color: var(--color-primary);
  background: var(--color-primary-bg);
}

.btn-sm { height: 32px; padding: 0 var(--space-md); font-size: var(--font-size-caption); border-radius: var(--radius-sm); }
.btn-lg { height: 48px; padding: 0 var(--space-2xl); font-size: var(--font-size-h3); border-radius: var(--radius-lg); }
.btn-block { width: 100%; }
```

### 3.4 卡片组件

```css
.card {
  background: var(--color-bg-card);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-card);
  transition: box-shadow var(--duration-normal) var(--ease-out);
  overflow: hidden;
}
.card:hover { box-shadow: var(--shadow-card-hover); }

.card-body { padding: var(--space-lg); }
```

### 3.5 标签组件

```css
.tag {
  display: inline-flex;
  align-items: center;
  height: 22px;
  padding: 0 var(--space-sm);
  border-radius: var(--radius-sm);
  font-size: var(--font-size-mini);
  font-weight: var(--font-weight-medium);
  line-height: 1;
}

.tag-primary { background: var(--color-primary-bg); color: var(--color-primary); }
.tag-warning { background: var(--color-alert-yellow-bg); color: var(--color-alert-orange); }
.tag-danger { background: var(--color-alert-red-bg); color: var(--color-alert-red); }
.tag-success { background: rgba(5, 150, 105, 0.08); color: var(--color-success); }
.tag-default { background: var(--color-bg-page); color: var(--color-text-secondary); }
.tag-info { background: rgba(24, 144, 255, 0.08); color: var(--color-info); }
.tag-secondary { background: var(--color-bg-page); color: var(--color-text-secondary); }
```

### 3.6 进度条

```css
.progress-bar {
  width: 100%;
  height: 6px;
  background: var(--color-border-light);
  border-radius: 3px;
  overflow: hidden;
}

.progress-bar-fill {
  height: 100%;
  border-radius: 3px;
  transition: width var(--duration-slow) var(--ease-out);
  background: linear-gradient(90deg, var(--color-primary), var(--color-primary-light));
}
.progress-bar-fill.warning {
  background: linear-gradient(90deg, var(--color-warning), var(--color-warning-orange));
}
.progress-bar-fill.danger {
  background: linear-gradient(90deg, var(--color-alert-orange), var(--color-danger));
}
```

### 3.7 动画关键帧

```css
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes fadeInUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
@keyframes fadeInDown { from { opacity: 0; transform: translateY(-16px); } to { opacity: 1; transform: translateY(0); } }
@keyframes slideInRight { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: translateX(0); } }
@keyframes slideInLeft { from { opacity: 0; transform: translateX(-20px); } to { opacity: 1; transform: translateX(0); } }
@keyframes scaleIn { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
@keyframes pulseRing { 0% { transform: scale(1); opacity: 0.6; } 100% { transform: scale(1.8); opacity: 0; } }
@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
@keyframes shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
@keyframes bounceIn { 0% { transform: scale(0); opacity: 0; } 50% { transform: scale(1.08); } 100% { transform: scale(1); opacity: 1; } }
@keyframes glowReveal { from { opacity: 0; transform: scale(0.92); filter: blur(6px); } to { opacity: 1; transform: scale(1); filter: blur(0); } }
@keyframes redFlash { 0%, 100% { background-color: rgba(255,77,79,0.12); } 50% { background-color: transparent; } }
@keyframes warningGlow { 0%, 100% { box-shadow: 0 0 0 0 rgba(255,77,79,0); } 50% { box-shadow: 0 0 16px 2px rgba(255,77,79,0.25); } }
@keyframes glowPulse { 0%, 100% { box-shadow: 0 0 24px rgba(7,193,96,0.3); } 50% { box-shadow: 0 0 48px rgba(7,193,96,0.5); } }
@keyframes staggerIn { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
@keyframes slideInUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }
@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
```

### 3.8 Vue 过渡

```css
.fade-enter-active, .fade-leave-active { transition: opacity var(--duration-normal) var(--ease-out); }
.fade-enter-from, .fade-leave-to { opacity: 0; }

.slide-up-enter-active, .slide-up-leave-active { transition: all var(--duration-normal) var(--ease-out); }
.slide-up-enter-from { opacity: 0; transform: translateY(20px); }
.slide-up-leave-to { opacity: 0; transform: translateY(-10px); }

.slide-right-enter-active, .slide-right-leave-active { transition: all var(--duration-normal) var(--ease-out); }
.slide-right-enter-from { opacity: 0; transform: translateX(20px); }
.slide-right-leave-to { opacity: 0; transform: translateX(-20px); }
```

### 3.9 空状态

```css
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--space-3xl) var(--space-lg);
  color: var(--color-text-tertiary);
}
.empty-state-icon { font-size: 48px; margin-bottom: var(--space-md); opacity: 0.4; }
.empty-state-text { font-size: var(--font-size-caption); }
```

## 四、H5 端组件规范

### 4.1 H5 容器

```css
.h5-app {
  width: 100%;
  min-height: 100vh;
  max-width: 500px;
  margin: 0 auto;
  background: var(--color-bg-page);
  position: relative;
  overflow-x: hidden;
}
```

### 4.2 顶部导航栏

```css
.h5-navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: var(--header-height);
  background: white;
  border-bottom: 0.5px solid var(--color-border-light);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: var(--z-fixed);
  padding: 0 var(--space-base);
  padding-top: env(safe-area-inset-top, 0);
}

.h5-navbar-left {
  position: absolute;
  left: var(--space-base);
  display: flex;
  align-items: center;
  gap: 4px;
  color: var(--color-text-primary);
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.h5-navbar-left i { font-size: 16px; }
.h5-navbar-left span { font-size: var(--font-size-body); }

.h5-navbar-title {
  font-size: var(--font-size-h3);
  font-weight: var(--font-weight-semibold);
  color: var(--color-text-primary);
}

.h5-navbar-right {
  position: absolute;
  right: var(--space-base);
  color: var(--color-text-primary);
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.h5-navbar-right i { font-size: 18px; }

.h5-navbar-right .badge {
  position: absolute;
  top: -6px;
  right: -6px;
  min-width: 16px;
  height: 16px;
  line-height: 16px;
  padding: 0 4px;
  background: var(--color-danger);
  color: white;
  font-size: 10px;
  font-weight: var(--font-weight-bold);
  border-radius: 8px;
  text-align: center;
}
```

### 4.3 底部 TabBar

```css
.h5-tabbar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  width: 100%;
  max-width: 500px;
  margin: 0 auto;
  height: var(--tabbar-height);
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-top: 0.5px solid var(--color-border-light);
  display: flex;
  align-items: center;
  justify-content: space-around;
  z-index: var(--z-fixed);
  padding-bottom: env(safe-area-inset-bottom, 0);
}

.h5-tabbar-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  flex: 1;
  height: 100%;
  color: var(--color-text-tertiary);
  transition: color var(--duration-fast);
  position: relative;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.h5-tabbar-item.active { color: var(--color-primary); }
.h5-tabbar-item-icon { font-size: 22px; line-height: 1; }
.h5-tabbar-item-label { font-size: 10px; font-weight: var(--font-weight-medium); }

.h5-tabbar-item .badge {
  position: absolute;
  top: 2px;
  right: 50%;
  margin-right: -18px;
  min-width: 16px;
  height: 16px;
  line-height: 16px;
  padding: 0 4px;
  background: var(--color-danger);
  color: white;
  font-size: 10px;
  font-weight: var(--font-weight-bold);
  border-radius: 8px;
  text-align: center;
}
```

### 4.4 页面容器

```css
.h5-page {
  padding: var(--space-base);
  padding-top: calc(var(--header-height) + var(--space-base));
  padding-bottom: calc(var(--tabbar-height) + var(--space-lg) + env(safe-area-inset-bottom, 0));
  min-height: 100vh;
  box-sizing: border-box;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

.h5-page-no-tab {
  padding-top: calc(var(--header-height) + var(--space-base));
  padding-bottom: var(--space-lg);
  min-height: 100vh;
  box-sizing: border-box;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
```

### 4.5 预警横幅

```css
.h5-alert-bar {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
  padding: var(--space-sm) var(--space-base);
  border-radius: var(--radius-md);
  font-size: var(--font-size-caption);
  margin-bottom: var(--space-base);
}

.h5-alert-yellow {
  background: var(--color-alert-yellow-bg);
  color: var(--color-alert-orange);
}

.h5-alert-orange {
  background: var(--color-alert-orange-bg);
  color: var(--color-alert-orange);
}

.h5-alert-red {
  background: var(--color-alert-red-bg);
  color: var(--color-alert-red);
}
```

### 4.6 桌面端手机模拟器适配

```css
@media (min-width: 501px) {
  body {
    background: #1a1a2e;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    overflow: hidden;  /* 防止双滚动条 */
  }

  .h5-app {
    width: 390px;
    height: 844px;
    border-radius: 40px;
    box-shadow: 0 0 0 8px #333, 0 0 0 10px #555, 0 20px 60px rgba(0,0,0,0.5);
    overflow: hidden;
    position: relative;
    padding-top: 44px;
    padding-bottom: 34px;
  }

  /* 模拟器刘海 */
  .h5-app::before {
    content: '';
    position: absolute;
    top: 8px;
    left: 50%;
    transform: translateX(-50%);
    width: 120px;
    height: 28px;
    background: #333;
    border-radius: 0 0 16px 16px;
    z-index: calc(var(--z-fixed) + 1);
  }

  /* 模拟器下巴指示条 */
  .h5-app::after {
    content: '';
    position: absolute;
    bottom: 8px;
    left: 50%;
    transform: translateX(-50%);
    width: 140px;
    height: 5px;
    background: #555;
    border-radius: 3px;
    z-index: calc(var(--z-fixed) + 1);
  }

  /* TabBar 在桌面端模拟器内定位 */
  .h5-tabbar {
    position: fixed;
    bottom: 34px;
    left: calc(50% - 195px);
    width: 390px;
    border-radius: 0 0 40px 40px;
  }

  /* 无 TabBar 页面在模拟器内定位 */
  .h5-page-no-tab {
    position: absolute;
    top: 100px;
    left: 0;
    right: 0;
    bottom: 34px;
    padding: var(--space-base);
    padding-bottom: calc(var(--space-2xl) + 60px);
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
  }

  /* 页面内容内部滚动 */
  .h5-page {
    height: calc(100% - 44px);
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
  }

  /* 隐藏滚动条但保持滚动功能 */
  .h5-page::-webkit-scrollbar {
    width: 0;
    height: 0;
  }

  /* 弹窗在桌面端模拟器中定位修复 */
  .h5-modal-overlay {
    position: absolute !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 84px !important;
    background: rgba(0,0,0,0.5) !important;
    z-index: 3000 !important;
    display: flex !important;
    align-items: flex-end !important;
    justify-content: center !important;
  }

  .h5-modal-content {
    background: white;
    width: 100%;
    max-width: 390px;
    border-radius: 20px 20px 0 0;
    display: flex;
    flex-direction: column;
    animation: slideUp 0.3s ease-out;
    overflow: hidden;
    box-sizing: border-box;
  }
}
```

## 五、PC 管理端组件规范

### 5.1 侧边栏

```css
.admin-sidebar {
  width: var(--sidebar-width);
  background: #1B2A4A;
  color: white;
  display: flex;
  flex-direction: column;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  z-index: var(--z-fixed);
  transition: width var(--duration-normal) var(--ease-out);
  overflow: hidden;
}

.admin-sidebar-header {
  padding: var(--space-lg) var(--space-base);
  border-bottom: 1px solid rgba(255,255,255,0.06);
}

.admin-sidebar-logo {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
  font-size: var(--font-size-h3);
  font-weight: var(--font-weight-bold);
  white-space: nowrap;
}

.admin-sidebar-logo-icon {
  width: 32px;
  height: 32px;
  border-radius: var(--radius-md);
  background: var(--color-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  flex-shrink: 0;
}

.admin-sidebar-nav {
  flex: 1;
  padding: var(--space-md) 0;
  overflow-y: auto;
}
.admin-sidebar-nav::-webkit-scrollbar { width: 0; }

.admin-nav-group { padding: var(--space-xs) var(--space-md); }
.admin-nav-group-title {
  font-size: var(--font-size-mini);
  color: rgba(255,255,255,0.3);
  text-transform: uppercase;
  letter-spacing: 1px;
  padding: var(--space-md) var(--space-sm) var(--space-xs);
  white-space: nowrap;
}

.admin-nav-item {
  display: flex;
  align-items: center;
  gap: var(--space-md);
  padding: var(--space-sm) var(--space-md);
  border-radius: var(--radius-md);
  color: rgba(255,255,255,0.55);
  cursor: pointer;
  transition: all var(--duration-fast) var(--ease-out);
  white-space: nowrap;
  margin-bottom: 2px;
  position: relative;
}
.admin-nav-item:hover {
  color: rgba(255,255,255,0.85);
  background: rgba(255,255,255,0.06);
}
.admin-nav-item.active {
  color: white;
  background: var(--color-primary);
  font-weight: var(--font-weight-medium);
}
.admin-nav-item-icon { font-size: 18px; width: 20px; text-align: center; flex-shrink: 0; }
.admin-nav-item-label { font-size: var(--font-size-caption); }
.admin-nav-item .badge {
  margin-left: auto;
  min-width: 18px;
  height: 18px;
  line-height: 18px;
  padding: 0 5px;
  background: var(--color-danger);
  color: white;
  font-size: 10px;
  font-weight: var(--font-weight-bold);
  border-radius: 9px;
  text-align: center;
}

.admin-sidebar-footer {
  padding: var(--space-md) var(--space-base);
  border-top: 1px solid rgba(255,255,255,0.06);
}
```

### 5.2 主内容区

```css
.admin-main {
  flex: 1;
  margin-left: var(--sidebar-width);
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.admin-header {
  height: var(--header-height);
  background: rgba(255, 255, 255, 0.85);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--color-border-light);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 var(--space-xl);
  position: sticky;
  top: 0;
  z-index: var(--z-sticky);
}

.admin-header-left { display: flex; align-items: center; gap: var(--space-md); }
.admin-header-title { font-size: var(--font-size-h3); font-weight: var(--font-weight-bold); }
.admin-breadcrumb { font-size: var(--font-size-caption); color: var(--color-text-tertiary); }

.admin-header-right { display: flex; align-items: center; gap: var(--space-lg); }

.admin-header-action {
  width: 36px;
  height: 36px;
  border-radius: var(--radius-md);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--color-text-secondary);
  cursor: pointer;
  transition: all var(--duration-fast);
  position: relative;
}
.admin-header-action:hover { background: var(--color-bg-page); }

.admin-header-action .badge-dot {
  position: absolute;
  top: 6px;
  right: 6px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--color-danger);
  border: 2px solid white;
}

.admin-header-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: var(--color-primary-bg);
  color: var(--color-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: var(--font-weight-bold);
  cursor: pointer;
}
```

## 六、高管驾驶舱组件规范

### 6.1 侧边栏（深色渐变）

```css
.exec-sidebar {
  width: var(--sidebar-width);
  background: linear-gradient(180deg, var(--color-exec-sidebar-from), var(--color-exec-sidebar-to));
  color: white;
  display: flex;
  flex-direction: column;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  z-index: var(--z-fixed);
  overflow: hidden;
}

.exec-sidebar-logo-icon {
  background: linear-gradient(135deg, var(--color-exec-primary), var(--color-exec-primary-light));
}

.exec-nav-item:hover {
  color: rgba(255,255,255,0.8);
  background: rgba(255,255,255,0.06);
}
.exec-nav-item.active {
  color: white;
  background: linear-gradient(135deg, var(--color-exec-primary), var(--color-exec-primary-light));
  box-shadow: 0 4px 12px rgba(108, 92, 231, 0.3);
}
```

### 6.2 KPI 仪表盘卡片

```css
.exec-kpi-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: var(--space-lg);
  margin-bottom: var(--space-xl);
}

.exec-kpi-card {
  background: white;
  border-radius: var(--radius-lg);
  padding: var(--space-xl);
  box-shadow: var(--shadow-card);
  position: relative;
  overflow: hidden;
  transition: all var(--duration-normal) var(--ease-out);
}
.exec-kpi-card:hover {
  transform: translateY(-3px);
  box-shadow: var(--shadow-card-hover);
}
.exec-kpi-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 4px;
  height: 100%;
}
.exec-kpi-card.purple::before {
  background: linear-gradient(180deg, var(--color-exec-primary), var(--color-exec-primary-light));
}
.exec-kpi-card.green::before { background: var(--color-primary); }
.exec-kpi-card.orange::before { background: var(--color-warning-orange); }
.exec-kpi-card.red::before { background: var(--color-danger); }

.exec-kpi-label {
  font-size: var(--font-size-caption);
  color: var(--color-text-tertiary);
  margin-bottom: var(--space-sm);
}
.exec-kpi-value {
  font-size: 32px;
  font-weight: var(--font-weight-heavy);
  line-height: var(--line-height-tight);
}
.exec-kpi-card.purple .exec-kpi-value { color: var(--color-exec-primary); }
.exec-kpi-card.green .exec-kpi-value { color: var(--color-primary); }
.exec-kpi-card.orange .exec-kpi-value { color: var(--color-warning-orange); }
.exec-kpi-card.red .exec-kpi-value { color: var(--color-danger); }
```

## 七、角色选择页规范

### 7.1 渐变背景

```css
.role-select-overlay {
  position: fixed;
  inset: 0;
  background: linear-gradient(135deg, #f0fdf4 0%, #f0f5ff 50%, #faf5ff 100%);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  padding: 32px 24px;
}

.role-select-title {
  font-size: 24px;
  font-weight: 800;
  color: #1a1a1a;
  margin-bottom: 8px;
}
.role-select-subtitle {
  font-size: 14px;
  color: #999;
  margin-bottom: 40px;
}

.role-select-cards {
  display: flex;
  flex-direction: column;
  gap: 20px;
  width: 100%;
  max-width: 340px;
}

.role-select-card {
  background: white;
  border-radius: 20px;
  padding: 28px 24px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.06);
  cursor: pointer;
  transition: all 0.25s cubic-bezier(0.22,1,0.36,1);
  position: relative;
  overflow: hidden;
}
.role-select-card:active { transform: scale(0.97); }

.role-select-card.employee { border: 2px solid rgba(7,193,96,0.2); }
.role-select-card.employee:hover,
.role-select-card.employee:active {
  border-color: #07C160;
  box-shadow: 0 8px 32px rgba(7,193,96,0.15);
}
.role-select-card.employee::before {
  content: '';
  position: absolute;
  top: -30px;
  right: -30px;
  width: 100px;
  height: 100px;
  border-radius: 50%;
  background: rgba(7,193,96,0.06);
}

.role-select-card.manager { border: 2px solid rgba(108,92,231,0.2); }
.role-select-card.manager:hover,
.role-select-card.manager:active {
  border-color: #6C5CE7;
  box-shadow: 0 8px 32px rgba(108,92,231,0.15);
}
.role-select-card.manager::before {
  content: '';
  position: absolute;
  top: -30px;
  right: -30px;
  width: 100px;
  height: 100px;
  border-radius: 50%;
  background: rgba(108,92,231,0.06);
}
```

## 八、工具函数规范

### 8.1 localStorage 封装

```javascript
const STORAGE_PREFIX = 'demo_';  // 每个项目使用唯一前缀

const Store = {
  get(key) {
    try {
      const data = localStorage.getItem(STORAGE_PREFIX + key);
      return data ? JSON.parse(data) : null;
    } catch (e) { return null; }
  },
  set(key, value) {
    try {
      localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
      return true;
    } catch (e) { return false; }
  },
  remove(key) { localStorage.removeItem(STORAGE_PREFIX + key); },
  clear() {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(STORAGE_PREFIX)) keys.push(k);
    }
    keys.forEach(k => localStorage.removeItem(k));
  }
};
```

### 8.2 日期格式化

```javascript
function formatDate(d) {
  let date;
  if (d === undefined || d === null) date = new Date();
  else if (typeof d === 'number') { date = new Date(); date.setDate(date.getDate() + d); }
  else date = new Date(d);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function formatTime(d) {
  const date = d ? new Date(d) : new Date();
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

function formatDateTime(d) { return formatDate(d) + ' ' + formatTime(d); }

function relativeTime(d) {
  const now = Date.now();
  const diff = now - new Date(d).getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return '刚刚';
  if (minutes < 60) return `${minutes}分钟前`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}小时前`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}天前`;
  return formatDate(d);
}
```

### 8.3 AI 模拟 - 打字机

```javascript
const Utils = {
  typeWriter(text, callback, speed = 30) {
    let i = 0;
    const timer = setInterval(() => {
      if (i < text.length) {
        callback(text.slice(0, i + 1), i === text.length - 1);
        i++;
      } else {
        clearInterval(timer);
      }
    }, speed);
    return timer;
  },

  sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); },
};
```

### 8.4 数字动画

```javascript
animateNumber(el, target, duration = 800) {
  const start = parseInt(el.textContent) || 0;
  const startTime = performance.now();
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(start + (target - start) * eased);
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}
```

### 8.5 进度环 SVG

```javascript
progressRingSVG(progress, size = 72, stroke = 6, color = '#07C160') {
  const r = (size - stroke) / 2;
  const c = Math.PI * 2 * r;
  const offset = c * (1 - progress / 100);
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
    <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="#F0F0F3" stroke-width="${stroke}"/>
    <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="${color}" stroke-width="${stroke}"
      stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${offset}"
      transform="rotate(-90 ${size/2} ${size/2})"
      style="transition: stroke-dashoffset 0.8s cubic-bezier(0.22,1,0.36,1)"/>
    <text x="${size/2}" y="${size/2}" text-anchor="middle" dominant-baseline="central"
      font-size="${size/4}" font-weight="700" fill="${color}">${progress}%</text>
  </svg>`;
}
```

## 九、数据层规范

### 9.1 DataManager 模式

```javascript
const DataManager = {
  init() {
    if (!Store.get('initialized')) {
      this.seedAll();
      Store.set('initialized', true);
    }
  },

  reset() {
    Store.clear();
    this.seedAll();
    Store.set('initialized', true);
    // 广播重置事件
    window.dispatchEvent(new CustomEvent('data-reset'));
  },

  seedAll() {
    // 种子数据示例
    Store.set('current_user', {
      id: 'user001',
      name: '用户名称',
      role: 'employee',
      department: '部门名称',
      avatar: '姓'
    });
    // ... 更多种子数据
  },

  // CRUD 操作的 getter/setter
  getTasks() { return Store.get('tasks') || []; },
  saveTask(task) {
    const tasks = this.getTasks();
    const idx = tasks.findIndex(t => t.id === task.id);
    if (idx >= 0) tasks[idx] = task;
    else tasks.push(task);
    Store.set('tasks', tasks);
  },
};
```

### 9.2 演示数据规模

| 数据类型 | 建议数量 | 说明 |
|----------|----------|------|
| 核心对象 | 2-5 个 | 展示主要实体 |
| 任务/条目 | 10-15 条 | 展示筛选和进度 |
| 报告/日志 | 8-12 份 | 展示评分和分析 |
| 财务项目 | 5-8 笔 | 展示审批流程 |
| 预警/告警 | 6-10 条 | 黄/橙/红三级预警 |
| 洞察/行动 | 3-5 条 | 驾驶舱数据 |

## 十、路由与权限规范

### 10.1 路由配置

```javascript
const routes = [
  // 员工端
  { path: '/', component: HomePage, meta: { title: '首页', showTabbar: true, role: 'employee' } },
  { path: '/tasks', component: TasksPage, meta: { title: '任务', showTabbar: true, role: 'employee' } },
  { path: '/reports', component: ReportsPage, meta: { title: '报告', showTabbar: true, role: 'employee' } },
  { path: '/approvals', component: ApprovalsPage, meta: { title: '审批', showTabbar: true, role: 'employee' } },
  { path: '/profile', component: ProfilePage, meta: { title: '我的', showTabbar: true, role: 'employee' } },

  // 经理端
  { path: '/m/', component: ManagerDashboard, meta: { title: '管理驾驶舱', showTabbar: true, role: 'manager' } },
  { path: '/m/tasks', component: ManagerTasks, meta: { title: '团队任务', showTabbar: true, role: 'manager' } },

  // 老板端
  { path: '/b/', component: BossDashboard, meta: { title: '老板驾驶舱', showTabbar: true, role: 'boss' } },
];
```

### 10.2 路由守卫

```javascript
router.beforeEach((to, from, next) => {
  const role = localStorage.getItem('demo_role');

  // 如果没有选择角色，只能访问根路径
  if (!role) {
    if (to.path === '/') {
      next();
    } else {
      next('/');
    }
    return;
  }

  // 检查路由权限
  const routeRole = to.meta.role;
  if (routeRole && routeRole !== role) {
    // 角色不匹配，重定向到首页
    next('/');
    return;
  }

  // 经理访问根路径重定向
  if (role === 'manager' && to.path === '/') { next('/m/'); return; }
  // 老板访问根路径重定向
  if (role === 'boss' && to.path === '/') { next('/b/'); return; }
  // 员工访问管理路由重定向
  if (role === 'employee' && (to.path.startsWith('/m/') || to.path.startsWith('/b/'))) { next('/'); return; }

  next();
});
```

## 十一、质量检查清单

### 功能检查
- [ ] 所有导航链接正常工作
- [ ] TabBar 在桌面模拟器正确显示
- [ ] 数据在页面刷新后持久化
- [ ] 重置按钮清除所有数据
- [ ] 角色切换正确刷新视图
- [ ] 路由守卫正确拦截越权访问

### 视觉检查
- [ ] 移动端响应式布局正常
- [ ] 桌面端模拟器居中显示
- [ ] 动画流畅（60fps）
- [ ] 字体和图标正确加载
- [ ] 无控制台错误
- [ ] 无双滚动条问题

### H5 专项
- [ ] 安全区域（刘海/下巴）正确适配
- [ ] 无 TabBar 页面底部内容不被遮挡
- [ ] 弹窗在模拟器内正确定位
- [ ] 触摸反馈正常

### 数据质量
- [ ] 无 "Lorem Ipsum" 或占位符文本
- [ ] 所有数据看起来真实可信
- [ ] 日期为当前或近期日期
- [ ] 名称和金额看起来真实

---

> 本设计系统是通用的企业级 H5 高保真 Demo 开发规范，可适用于各类企业应用场景。
