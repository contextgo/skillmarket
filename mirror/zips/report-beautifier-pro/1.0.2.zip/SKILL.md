# Report Beautifier · 专业报告美颜器

> 上传丑报表（Word/Excel/PDF）→ AI 自动识别数据结构和内容 → 输出专业级排版（PPT/PDF）

---

## 触发词

`报告美颜` `美化报表` `Word转PPT` `Excel转PPT` `PDF转PPT` `报表美化` `数据可视化` `图表生成` `report beautifier` `beautify report`

---

## 使用方法

### 1. 基础使用

```python
from scripts.beautifier import beautify_report

result = beautify_report(
    file_path="/path/to/report.xlsx",
    api_key="RPT-XXXX-your-api-key",
    template="business_blue",  # 可选模板
    output_format="pptx"         # pptx / pdf / png
)

if result["success"]:
    print(f"生成文件: {result['output_path']}")
    print(f"使用套餐: {result['tier_info']['tier_name']}")
else:
    print(f"错误: {result['error']}")
```

### 2. 高级使用

```python
from scripts.beautifier import ReportBeautifier, BeautifierConfig

config = BeautifierConfig(
    template_id="tech_purple",
    output_format="pptx",
    include_charts=True,
    quality="high"
)

beautifier = ReportBeautifier(api_key="RPT-XXXX", config=config)
result = beautifier.beautify_file("/path/to/report.xlsx")

print(result)
```

### 3. 查询套餐信息

```python
from scripts.beautifier import get_tier_info, list_templates

# 获取API Key对应的套餐信息
info = get_tier_info("RPT-XXXX")
print(info)

# 获取可用模板列表
templates = list_templates("RPT-XXXX")
for t in templates:
    print(f"{t['id']}: {t['name']}")
```

---

## 支持格式

| 格式 | 扩展名 | 说明 |
|------|--------|------|
| Word | `.docx`, `.doc` | 自动提取标题、段落、表格 |
| Excel | `.xlsx`, `.xls` | 支持多Sheet，智能识别表头 |
| PDF | `.pdf` | 文本提取，支持简单表格识别 |

---

## 套餐与定价

| 套餐 | 价格 | 次数/月 | 输入格式 | 模板数 | 下载 | 其他 |
|------|------|---------|----------|--------|------|------|
| **FREE** | 免费 | 3次 | Word | 1种 | 预览不可下载 | - |
| **BSC/Standard** | ¥29/月 | 50次 | Word/Excel/PDF | 5种 | PPT下载 | 图表美化 |
| **Pro** | ¥99/月 | 300次 | 全部格式 | 15种+自定义配色 | PDF/PPT/图片 | 高级图表、演讲稿 |
| **Max/Enterprise** | ¥299/月 | 无限次 | 全部格式 | 企业VI模板 | 全部格式 | 批量10份/批、API接口 |

---

## 可用模板（15种）

### 商务风格
- `business_blue` - 商务蓝
- `finance_gray` - 金融灰
- `government_red` - 政务红

### 教育/专业
- `teaching_green` - 教学绿
- `tech_purple` - 科技紫
- `ocean_blue` - 海洋蓝

### 活力风格
- `vibrant_orange` - 活力橙
- `rose_pink` - 玫瑰粉
- `vibrant_purple` - 活力紫

### 简约风格
- `minimal_white` - 简约白
- `night_dark` - 暗夜黑
- `fresh_cyan` - 清新青

### 高端风格
- `classic_gold` - 经典金
- `forest_green` - 森林绿
- `deep_sea_blue` - 深海蓝

---

## API Key 格式

```
RPT-FREE-xxxxx     # 免费版
RPT-BSC-xxxxx      # 标准版
RPT-STD-xxxxx      # 标准版（别名）
RPT-PRO-xxxxx      # 专业版
RPT-ENT-xxxxx      # 企业版
```

验证接口: `POST https://api.yk-global.com/v1/verify`

---

## 输出格式

- **PPTX**: PowerPoint 演示文稿（默认）
- **PDF**: PDF 文档（通过转换）
- **PNG**: 单张图表图片

---

## 场景识别

自动识别以下报告类型并应用对应样式：

- `financial` - 财务报告
- `sales` - 销售报表
- `report` - 述职/工作汇报
- `bidding` - 投标方案
- `teaching` - 教学课件
- `general` - 通用文档

---

## 错误处理

```python
try:
    result = beautify_report(file_path, api_key)
    if not result["success"]:
        print(f"美化失败: {result['error']}")
except Exception as e:
    print(f"系统错误: {e}")
```

---

## 依赖

```
python-docx>=1.1.0
openpyxl>=3.1.2
PyPDF2>=3.0.0
python-pptx>=1.0.1
matplotlib>=3.7.0
plotly>=5.18.0
requests>=2.31.0
Pillow>=10.0.0
kaleido>=0.2.1
```

---

> 如需购买收费版，请访问 [YK-Global.com](https://yk-global.com)
