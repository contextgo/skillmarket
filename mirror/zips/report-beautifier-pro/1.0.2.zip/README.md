# Report Beautifier · 专业报告美颜器

上传 Excel/Word/CSV/PDF → AI 自动识别数据 → 推荐最佳图表 → 一键生成专业级可下载文件（PNG/PPT/PDF）。

---

## 支持格式

| 格式 | 说明 |
|------|------|
| CSV | UTF-8 编码的逗号分隔值 |
| Excel | `.xlsx` / `.xls`，支持多 Sheet |
| Word | `.docx`，自动提取文字和表格 |
| PDF | `.pdf`，提取文字和表格结构 |

---

## 功能亮点

- **智能识别**：自动判断数据类型（财务/销售/运营/HR/教学），推荐最佳图表
- **专业配色**：15 种风格一键切换（商务蓝/金融灰/政务红/教学绿/科技紫等）
- **多格式输出**：PNG（图表单图）、PDF（打印级）、PPT（演示级）
- **场景自动匹配**：述职/投标/汇报/教学，自动匹配色调和排版风格

---

## 快速开始

```python
from scripts.beautifier import beautify_report

result = beautify_report(
    file_path="/path/to/report.xlsx",
    api_key="your-api-key",
    template="business_blue",
    output_format="pptx",
)
print(result["output_path"])
```

---

## 套餐说明

| 套餐 | 月费 | 次数 | 模板 | 图表 | 下载 | 批量 |
|------|------|------|------|------|------|------|
| **FREE** | 免费 | 3次/月 | 1种 | 柱/线/饼 | ❌ | ❌ |
| **BSC/标准版** | ¥29 | 50次/月 | 5种 | 基础+高级 | ✅ | ❌ |
| **Pro/专业版** | ¥99 | 300次/月 | 15种+自定义 | 全部 | ✅ | ❌ |
| **Max/企业版** | ¥299 | 无限次 | 全部+企业VI | 全部 | ✅ | ✅（10份/批） |

---

> 如需购买收费版，请访问 [YK-Global.com](https://yk-global.com)
