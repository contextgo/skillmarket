"""
Test Suite for Report Beautifier
Comprehensive tests covering all major functionality.
"""

import os
import sys
import io
import tempfile
import unittest
from unittest.mock import patch, MagicMock
from dataclasses import dataclass

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.token_validator import (
    validate_token, ValidationResult, Tier,
    get_tier_display_name, clear_cache,
    _get_cache, _set_cache
)
from scripts.document_parser import (
    parse_document, parse_word, parse_excel, parse_pdf,
    ParsedDocument, TableData, SceneType,
    get_supported_extensions, _detect_scene
)
from scripts.chart_maker import (
    create_bar_chart, create_line_chart, create_pie_chart,
    create_horizontal_bar_chart, create_stacked_bar_chart,
    auto_select_chart_type, chart_to_image, ChartType, ChartConfig
)
from scripts.templates import (
    get_template, get_available_templates, validate_template,
    get_default_template, list_all_templates, TEMPLATES
)
from scripts.beautifier import (
    beautify_report, ReportBeautifier, BeautifierConfig,
    get_tier_info, list_templates
)


class TestTokenValidator(unittest.TestCase):
    """Test token validation functionality."""

    def setUp(self):
        clear_cache()

    def tearDown(self):
        clear_cache()

    def test_tier_from_prefix(self):
        """Test tier detection from API key prefix."""
        from scripts.token_validator import Tier

        self.assertEqual(Tier.from_prefix("RPT-FREE-xxx"), Tier.FREE)
        self.assertEqual(Tier.from_prefix("RPT-BSC-xxx"), Tier.BSC)
        self.assertEqual(Tier.from_prefix("RPT-STD-xxx"), Tier.STD)
        self.assertEqual(Tier.from_prefix("RPT-PRO-xxx"), Tier.PRO)
        self.assertEqual(Tier.from_prefix("RPT-ENT-xxx"), Tier.ENT)
        self.assertEqual(Tier.from_prefix("RPT-UNKNOWN-xxx"), Tier.FREE)

    def test_validation_result_properties(self):
        """Test ValidationResult tier properties."""
        # FREE tier
        result = ValidationResult(valid=True, tier=Tier.FREE, api_key="RPT-FREE-test")
        self.assertTrue(result.is_free)
        self.assertEqual(result.monthly_limit, 3)
        self.assertEqual(result.template_count, 1)
        self.assertFalse(result.can_download)
        self.assertFalse(result.supports_batch)
        self.assertTrue(result.supports_word)
        self.assertFalse(result.supports_excel)
        self.assertFalse(result.supports_pdf)

        # BSC tier
        result = ValidationResult(valid=True, tier=Tier.BSC, api_key="RPT-BSC-test")
        self.assertFalse(result.is_free)
        self.assertEqual(result.monthly_limit, 50)
        self.assertEqual(result.template_count, 5)
        self.assertTrue(result.can_download)
        self.assertFalse(result.supports_batch)

        # PRO tier
        result = ValidationResult(valid=True, tier=Tier.PRO, api_key="RPT-PRO-test")
        self.assertEqual(result.monthly_limit, 300)
        self.assertEqual(result.template_count, 15)

        # ENT tier
        result = ValidationResult(valid=True, tier=Tier.ENT, api_key="RPT-ENT-test")
        self.assertEqual(result.monthly_limit, -1)  # unlimited
        self.assertTrue(result.supports_batch)
        self.assertTrue(result.supports_api)

    def test_cache_functionality(self):
        """Test validation result caching."""
        result = ValidationResult(valid=True, tier=Tier.FREE, api_key="test-key")

        # Cache should be empty initially
        self.assertIsNone(_get_cache("test-key"))

        # Set cache
        _set_cache("test-key", result)

        # Should retrieve from cache
        cached = _get_cache("test-key")
        self.assertIsNotNone(cached)
        self.assertTrue(cached.from_cache)
        self.assertEqual(cached.tier, Tier.FREE)

        # Clear cache
        clear_cache("test-key")
        self.assertIsNone(_get_cache("test-key"))

        # Clear all
        _set_cache("key1", result)
        _set_cache("key2", result)
        clear_cache()
        self.assertIsNone(_get_cache("key1"))
        self.assertIsNone(_get_cache("key2"))

    @patch('scripts.token_validator.requests.post')
    def test_validate_token_success(self, mock_post):
        """Test successful token validation."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"valid": True}
        mock_post.return_value = mock_response

        clear_cache()
        result = validate_token("RPT-PRO-test", skip_cache=False)

        self.assertTrue(result.valid)
        self.assertEqual(result.tier, Tier.PRO)
        self.assertFalse(result.from_cache)

    @patch('scripts.token_validator.requests.post')
    def test_validate_token_network_error(self, mock_post):
        """Test token validation with network error (degraded mode)."""
        mock_post.side_effect = Exception("Connection refused")

        clear_cache()
        result = validate_token("RPT-PRO-test", skip_cache=False)

        # Should not block usage, tier preserved from key prefix
        self.assertTrue(result.valid)
        self.assertEqual(result.tier, Tier.PRO)  # Tier preserved from prefix
        self.assertIsNotNone(result.error)

    def test_get_tier_display_name(self):
        """Test human-readable tier names."""
        self.assertIn("免费", get_tier_display_name(Tier.FREE))
        self.assertIn("标准", get_tier_display_name(Tier.BSC))
        self.assertIn("专业", get_tier_display_name(Tier.PRO))
        self.assertIn("企业", get_tier_display_name(Tier.ENT))


class TestDocumentParser(unittest.TestCase):
    """Test document parsing functionality."""

    def test_get_supported_extensions(self):
        """Test supported file extensions."""
        exts = get_supported_extensions()
        self.assertIn(".docx", exts)
        self.assertIn(".xlsx", exts)
        self.assertIn(".pdf", exts)
        self.assertIn(".doc", exts)
        self.assertIn(".xls", exts)

    def test_scene_detection(self):
        """Test scene type detection."""
        # Financial
        doc = ParsedDocument()
        doc.title = "2024年度财务报告"
        doc.paragraphs = ["收入分析", "成本控制"]
        self.assertEqual(_detect_scene(doc), SceneType.FINANCIAL)

        # Sales
        doc = ParsedDocument()
        doc.title = "销售业绩报表"
        doc.paragraphs = ["客户增长", "渠道拓展"]
        self.assertEqual(_detect_scene(doc), SceneType.SALES)

        # Report
        doc = ParsedDocument()
        doc.title = "年度述职报告"
        doc.paragraphs = ["工作总结", "下年计划"]
        self.assertEqual(_detect_scene(doc), SceneType.REPORT)

        # General (no keywords)
        doc = ParsedDocument()
        doc.title = "Document"
        doc.paragraphs = ["Some content"]
        self.assertEqual(_detect_scene(doc), SceneType.GENERAL)

    def test_table_data_properties(self):
        """Test TableData properties."""
        # Empty table
        table = TableData()
        self.assertFalse(table.has_headers)
        self.assertEqual(table.row_count, 0)
        self.assertEqual(table.col_count, 0)

        # With headers
        table = TableData(
            headers=["Name", "Value"],
            rows=[["Item1", 100], ["Item2", 200]]
        )
        self.assertTrue(table.has_headers)
        self.assertEqual(table.row_count, 2)
        self.assertEqual(table.col_count, 2)

        # Without headers
        table = TableData(
            rows=[["Item1", 100], ["Item2", 200]]
        )
        self.assertFalse(table.has_headers)
        self.assertEqual(table.row_count, 2)
        self.assertEqual(table.col_count, 2)


class TestChartMaker(unittest.TestCase):
    """Test chart generation functionality."""

    def setUp(self):
        """Create test table data."""
        # Table without headers - first column is label, last column is value
        self.test_table = TableData(
            headers=[],
            rows=[
                ["销售部", 1200000, 15],
                ["市场部", 850000, 8],
                ["技术部", 920000, 12],
                ["运营部", 680000, 5],
            ]
        )

    def test_auto_select_chart_type(self):
        """Test automatic chart type selection."""
        # Small table with few rows -> Pie
        small_table = TableData(
            headers=["类别", "数值"],
            rows=[["A", 100], ["B", 200]]
        )
        self.assertEqual(auto_select_chart_type(small_table), ChartType.PIE)

        # Many rows, 2 cols -> Horizontal bar
        long_table = TableData(
            rows=[[f"Item{i}", i*100] for i in range(10)]
        )
        self.assertEqual(auto_select_chart_type(long_table), ChartType.HORIZONTAL_BAR)

        # Multiple columns (3+) -> Stacked bar (only if enough rows)
        multi_table = TableData(
            headers=["季度", "产品A", "产品B", "产品C"],
            rows=[
                ["Q1", 100, 200, 300],
                ["Q2", 150, 250, 350],
                ["Q3", 180, 280, 380],
                ["Q4", 200, 300, 400],
            ]
        )
        self.assertEqual(auto_select_chart_type(multi_table), ChartType.STACKED_BAR)

    def test_create_bar_chart(self):
        """Test bar chart creation."""
        config = ChartConfig(
            title="测试图表",
            color_scheme="business"
        )
        result = create_bar_chart(self.test_table, config)
        self.assertIsInstance(result, io.BytesIO)
        self.assertGreater(result.getbuffer().nbytes, 0)

    def test_create_line_chart(self):
        """Test line chart creation."""
        config = ChartConfig(title="测试图表")
        result = create_line_chart(self.test_table, config)
        self.assertIsInstance(result, io.BytesIO)

    def test_create_pie_chart(self):
        """Test pie chart creation."""
        config = ChartConfig(title="测试图表")
        result = create_pie_chart(self.test_table, config)
        self.assertIsInstance(result, io.BytesIO)

    def test_create_horizontal_bar_chart(self):
        """Test horizontal bar chart creation."""
        config = ChartConfig(title="测试图表")
        result = create_horizontal_bar_chart(self.test_table, config)
        self.assertIsInstance(result, io.BytesIO)

    def test_chart_to_image(self):
        """Test chart_to_image convenience function."""
        img_bytes = chart_to_image(
            self.test_table,
            chart_type="bar",
            title="部门销售",
            color_scheme="business"
        )
        self.assertIsInstance(img_bytes, bytes)
        self.assertGreater(len(img_bytes), 0)


class TestTemplates(unittest.TestCase):
    """Test template functionality."""

    def test_get_template(self):
        """Test getting a template."""
        template = get_template("business_blue")
        self.assertEqual(template["name"], "商务蓝")
        self.assertIn("primary", template)
        self.assertIn("chart_colors", template)

        # Default template
        template = get_template("nonexistent")
        self.assertEqual(template["name"], "商务蓝")

    def test_get_available_templates(self):
        """Test getting available templates for tiers."""
        # FREE tier
        templates = get_available_templates("free")
        self.assertEqual(len(templates), 1)

        # BSC tier
        templates = get_available_templates("bsc")
        self.assertEqual(len(templates), 5)

        # PRO tier
        templates = get_available_templates("pro")
        self.assertEqual(len(templates), 15)

    def test_validate_template(self):
        """Test template validation for tiers."""
        # FREE can only use minimal_white
        self.assertTrue(validate_template("minimal_white", "free"))
        self.assertFalse(validate_template("business_blue", "free"))

        # BSC can use 5 templates
        self.assertTrue(validate_template("business_blue", "bsc"))
        self.assertTrue(validate_template("finance_gray", "bsc"))
        self.assertFalse(validate_template("tech_purple", "bsc"))

        # PRO can use all
        self.assertTrue(validate_template("business_blue", "pro"))
        self.assertTrue(validate_template("tech_purple", "pro"))

    def test_get_default_template(self):
        """Test default template selection."""
        self.assertEqual(get_default_template("free"), "minimal_white")
        self.assertEqual(get_default_template("bsc"), "business_blue")
        self.assertEqual(get_default_template("pro"), "business_blue")

    def test_list_all_templates(self):
        """Test listing all templates."""
        templates = list_all_templates()
        self.assertEqual(len(templates), 15)
        self.assertIn("business_blue", templates)
        self.assertIn("tech_purple", templates)


class TestBeautifier(unittest.TestCase):
    """Test main beautifier functionality."""

    def setUp(self):
        clear_cache()

    def test_beautifier_config_defaults(self):
        """Test BeautifierConfig defaults."""
        config = BeautifierConfig()
        self.assertEqual(config.template_id, "business_blue")
        self.assertEqual(config.output_format, "pptx")
        self.assertTrue(config.include_charts)
        self.assertEqual(config.quality, "high")

    @patch('scripts.beautifier.validate_token')
    def test_beautifier_initialization(self, mock_validate):
        """Test ReportBeautifier initialization."""
        mock_validate.return_value = ValidationResult(
            valid=True, tier=Tier.FREE, api_key="RPT-FREE-test"
        )

        beautifier = ReportBeautifier("RPT-FREE-test")
        self.assertEqual(beautifier.tier, Tier.FREE)
        self.assertEqual(beautifier.tier_name, get_tier_display_name(Tier.FREE))

    @patch('scripts.beautifier.validate_token')
    def test_beautifier_template_adjustment(self, mock_validate):
        """Test template adjustment based on tier."""
        mock_validate.return_value = ValidationResult(
            valid=True, tier=Tier.FREE, api_key="RPT-FREE-test"
        )

        # BSC template should be adjusted to free template
        config = BeautifierConfig(template_id="business_blue")
        beautifier = ReportBeautifier("RPT-FREE-test", config)

        # Should be adjusted to minimal_white for FREE tier
        self.assertEqual(beautifier.config.template_id, "minimal_white")

    @patch('scripts.beautifier.validate_token')
    def test_beautifier_tier_info(self, mock_validate):
        """Test tier info retrieval."""
        mock_validate.return_value = ValidationResult(
            valid=True, tier=Tier.PRO, api_key="RPT-PRO-test"
        )

        beautifier = ReportBeautifier("RPT-PRO-test")
        info = beautifier._get_tier_info()

        self.assertEqual(info["tier"], "pro")
        self.assertEqual(info["monthly_limit"], 300)
        self.assertEqual(info["template_count"], 15)
        self.assertTrue(info["can_download"])

    def test_beautify_report_invalid_file(self):
        """Test beautify_report with invalid file."""
        result = beautify_report(
            file_path="/nonexistent/file.xlsx",
            api_key="RPT-FREE-test"
        )
        self.assertFalse(result["success"])
        self.assertIn("not found", result["error"].lower())

    def test_beautify_report_invalid_format(self):
        """Test beautify_report with invalid format."""
        with tempfile.NamedTemporaryFile(suffix=".xyz", delete=False) as f:
            f.write(b"test")
            temp_path = f.name

        try:
            result = beautify_report(
                file_path=temp_path,
                api_key="RPT-FREE-test"
            )
            self.assertFalse(result["success"])
            self.assertIn("Unsupported", result["error"])
        finally:
            os.unlink(temp_path)


class TestIntegration(unittest.TestCase):
    """Integration tests."""

    def setUp(self):
        clear_cache()

    def test_full_workflow_mock(self):
        """Test full beautification workflow with mocked validation."""
        with patch('scripts.beautifier.validate_token') as mock_validate:
            mock_validate.return_value = ValidationResult(
                valid=True, tier=Tier.BSC, api_key="RPT-BSC-test"
            )

            # This would require actual files for full test
            # Just verify the function exists and has correct signature
            result = beautify_report(
                file_path="/fake/path.xlsx",
                api_key="RPT-BSC-test"
            )
            # Should fail with file not found, not validation error
            self.assertFalse(result["success"])
            self.assertIn("not found", result["error"].lower())


def run_tests():
    """Run all tests."""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestTokenValidator))
    suite.addTests(loader.loadTestsFromTestCase(TestDocumentParser))
    suite.addTests(loader.loadTestsFromTestCase(TestChartMaker))
    suite.addTests(loader.loadTestsFromTestCase(TestTemplates))
    suite.addTests(loader.loadTestsFromTestCase(TestBeautifier))
    suite.addTests(loader.loadTestsFromTestCase(TestIntegration))

    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
