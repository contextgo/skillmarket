#!/usr/bin/env python3
"""
Report Beautifier API Server (Max Tier Only)
Flask-based REST API for enterprise integration.

Usage: python api_server.py --api-key <key> --port 5000
"""

import argparse, json, logging, os, sys, tempfile
from pathlib import Path
from functools import wraps

# Add parent dir to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from flask import Flask, request, jsonify, send_file
from werkzeug.utils import secure_filename

from scripts.beautifier import ReportBeautifier, BeautifierConfig, BeautifierResult
from scripts.token_validator import check_tier_limit

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB max
app.config["ALLOWED_EXTENSIONS"] = {"docx", "doc", "xlsx", "xls", "csv", "pdf"}

beautifier_instances = {}  # api_key -> ReportBeautifier instance


def require_max_tier(f):
    """Decorator: only allow Max tier users."""
    @wraps(f)
    def decorated(*args, **kwargs):
        api_key = request.headers.get("Authorization", "").replace("Bearer ", "")
        if not api_key:
            return jsonify({"error": "Missing API key"}), 401
        allowed, verify_result = check_tier_limit(api_key)
        if not allowed:
            return jsonify({"error": f"Invalid API key: {verify_result.get('error')}"}), 403
        if verify_result.get("tier") != "MAX":
            return jsonify({"error": "This endpoint requires Max tier"}), 403
        return f(*args, **kwargs)
    return decorated


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in app.config["ALLOWED_EXTENSIONS"]


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "report-beautifier-api"})


@app.route("/beautify", methods=["POST"])
@require_max_tier
def beautify():
    """
    Beautify a document.

    Form-data:
      - file: document file
      - template: template ID (optional, default: business_blue)
      - output_format: pptx/pdf/png (optional, default: pptx)
      - logo: optional logo file for VI customization
      - primary_color: hex color for VI (optional)
      - secondary_color: hex color for VI (optional)
      - accent_color: hex color for VI (optional)
    """
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": f"Unsupported file type. Allowed: {', '.join(app.config['ALLOWED_EXTENSIONS'])}"}), 400

    api_key = request.headers.get("Authorization", "").replace("Bearer ", "")
    template = request.form.get("template", "business_blue")
    output_format = request.form.get("output_format", "pptx")
    logo_file = request.files.get("logo")
    logo_path = None

    # Handle logo upload
    if logo_file and logo_file.filename:
        if not allowed_file(logo_file.filename):
            return jsonify({"error": "Logo must be PNG or JPG"}), 400
        logo_path = os.path.join(tempfile.gettempdir(), secure_filename(logo_file.filename))
        logo_file.save(logo_path)

    # Handle VI colors
    vi_colors = {}
    for key in ["primary_color", "secondary_color", "accent_color"]:
        val = request.form.get(key)
        if val:
            vi_colors[key.replace("_color", "")] = val

    # Save uploaded file
    filename = secure_filename(file.filename)
    tmp_path = os.path.join(tempfile.gettempdir(), filename)
    file.save(tmp_path)

    try:
        config = BeautifierConfig(
            template_id=template,
            output_format=output_format,
            include_charts=True,
            include_titles=True,
        )

        beautifier = ReportBeautifier(api_key, config)

        # Apply VI if logo or colors provided
        if logo_path or vi_colors:
            result = beautifier.beautify_with_vi(tmp_path, logo_path, vi_colors)
        else:
            result = beautifier.beautify_file(tmp_path)

        if not result.success:
            return jsonify({"error": result.error}), 400

        return jsonify({
            "success": True,
            "output_path": result.output_path,
            "template_used": result.template_used,
            "charts_created": result.charts_created,
            "tables_processed": result.tables_processed,
            "tier_info": result.tier_info,
        })

    except PermissionError as e:
        return jsonify({"error": str(e)}), 403
    except Exception as e:
        logger.error(f"Beautification error: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        if logo_path and os.path.exists(logo_path):
            os.remove(logo_path)


@app.route("/speech", methods=["POST"])
@require_max_tier
def generate_speech():
    """
    Generate a speaking script from a report.

    Form-data:
      - file: document file
      - model: AI model (optional, default: glm-4)
    """
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Unsupported file type"}), 400

    api_key = request.headers.get("Authorization", "").replace("Bearer ", "")
    model = request.form.get("model", "glm-4")

    filename = secure_filename(file.filename)
    tmp_path = os.path.join(tempfile.gettempdir(), filename)
    file.save(tmp_path)

    try:
        from scripts.document_parser import parse_document

        doc = parse_document(tmp_path)

        config = BeautifierConfig()
        beautifier = ReportBeautifier(api_key, config)
        speech, duration = beautifier.generate_speech(doc, api_key, model)

        return jsonify({
            "success": True,
            "speech": speech,
            "duration_minutes": duration,
            "word_count": len(speech),
        })

    except PermissionError as e:
        return jsonify({"error": str(e)}), 403
    except Exception as e:
        logger.error(f"Speech generation error: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


@app.route("/tier-info", methods=["GET"])
def tier_info():
    """Get tier information for an API key."""
    api_key = request.headers.get("Authorization", "").replace("Bearer ", "")
    if not api_key:
        return jsonify({"error": "Missing API key"}), 401

    allowed, verify_result = check_tier_limit(api_key)
    if not allowed:
        return jsonify({"error": f"Invalid API key: {verify_result.get('error')}"}), 403

    tier = verify_result.get("tier", "FREE")
    tier_info = {
        "FREE": {"tier": "FREE", "templates": 3, "max_file_size_mb": 5, "batch": False, "api": False},
        "STANDARD": {"tier": "STANDARD", "templates": 8, "max_file_size_mb": 50, "batch": False, "api": False},
        "PRO": {"tier": "PRO", "templates": 15, "max_file_size_mb": 200, "batch": True, "api": False},
        "MAX": {"tier": "MAX", "templates": "all", "max_file_size_mb": "unlimited", "batch": True, "api": True, "vi_custom": True, "speech_gen": True},
    }

    return jsonify(tier_info.get(tier, tier_info["FREE"]))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Report Beautifier API Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind")
    parser.add_argument("--port", type=int, default=5000, help="Port to bind")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()

    logger.info(f"Starting Report Beautifier API Server on {args.host}:{args.port}")
    app.run(host=args.host, port=args.port, debug=args.debug)