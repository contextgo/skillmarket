"""
Chart Maker - Creates professional charts from table data.
Supports matplotlib and plotly for chart generation.
"""

import os
import io
import logging
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np

from .document_parser import TableData

logger = logging.getLogger(__name__)

_CHINESE_FONTS = [
    "SimHei", "Microsoft YaHei", "STHeiti", "WenQuanYi Micro Hei",
    "Noto Sans CJK SC", "Source Han Sans CN", "Arial Unicode MS"
]

def _get_chinese_font() -> str:
    """Get a font that supports Chinese characters."""
    available_fonts = [f.name for f in fm.fontManager.ttflist]
    for font_name in _CHINESE_FONTS:
        if font_name in available_fonts:
            return font_name
    for font in available_fonts:
        if "CJK" in font or "Chinese" in font or "Hei" in font:
            return font
    return "DejaVu Sans"


_CHINESE_FONT = _get_chinese_font()


class ChartType(Enum):
    """Supported chart types."""
    BAR = "bar"
    LINE = "line"
    PIE = "pie"
    SCATTER = "scatter"
    AREA = "area"
    HORIZONTAL_BAR = "horizontal_bar"
    STACKED_BAR = "stacked_bar"
    GROUPED_BAR = "grouped_bar"


@dataclass
class ChartConfig:
    """Configuration for chart styling."""
    title: str = ""
    xlabel: str = ""
    ylabel: str = ""
    color_scheme: str = "default"
    show_legend: bool = True
    show_grid: bool = True
    figsize: Tuple[int, int] = (10, 6)
    dpi: int = 150


COLOR_SCHEMES = {
    "default": ["#4A90D9", "#5AC8FA", "#007AFF", "#34C759", "#FF9500", "#FF3B30", "#AF52DE", "#5856D6"],
    "blues": ["#08519C", "#3182BD", "#4292C6", "#6BAED6", "#9ECAE1", "#C6DBEF", "#DEEBF7", "#F7FBFF"],
    "greens": ["#006D2C", "#31A354", "#74C476", "#A1D99B", "#C7E9C0", "#EDF8E9", "#F7F7F7", "#FAFAFA"],
    "oranges": ["#D94801", "#F16913", "#FD8D3C", "#FDAE6B", "#FDD0A2", "#FEE6CE", "#FFF5EB", "#FFFAF0"],
    "reds": ["#A50F15", "#CB181D", "#EF3B2C", "#FB6A4A", "#FC9272", "#FCBBA1", "#FEE0D2", "#FFF5F0"],
    "business": ["#1A365D", "#2B6CB0", "#4299E1", "#63B3ED", "#90CDF4", "#BEE3F8", "#E2E8F0", "#EDF2F7"],
    "finance": ["#1A202C", "#2D3748", "#4A5568", "#718096", "#A0AEC0", "#CBD5E0", "#E2E8F0", "#F7FAFC"],
    "tech": ["#553C9A", "#805AD5", "#B794F4", "#D6BCFA", "#E9D8FD", "#F3D8FD", "#FAF5FF", "#FFFFFF"],
    "vibrant": ["#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7", "#DDA0DD", "#98D8C8", "#F7DC6F"],
}


def _get_colors(config: ChartConfig) -> List[str]:
    """Get color list based on color scheme."""
    colors = COLOR_SCHEMES.get(config.color_scheme, COLOR_SCHEMES["default"])
    return colors


def _setup_chinese_font():
    """Setup matplotlib for Chinese font support."""
    plt.rcParams['font.sans-serif'] = [_CHINESE_FONT, 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False


def create_bar_chart(table: TableData, config: ChartConfig) -> io.BytesIO:
    """Create a bar chart from table data."""
    _setup_chinese_font()

    if not table.rows:
        raise ValueError("No data to chart")

    # Use labels from headers if available, else first column
    if table.has_headers:
        labels = [str(h) for h in table.headers]
        # Use values from first data row
        if table.rows:
            values = [float(v) if v else 0 for v in table.rows[0]]
        else:
            values = []
    else:
        labels = [str(row[0]) if row and len(row) > 0 else "" for row in table.rows[:10]]
        values = [float(row[-1]) if row and len(row) > 0 and row[-1] else 0 for row in table.rows[:10]]

    colors = _get_colors(config)

    fig, ax = plt.subplots(figsize=config.figsize, dpi=config.dpi)

    x_pos = np.arange(len(labels))
    bars = ax.bar(x_pos, values, color=colors[:len(labels)], edgecolor='white', linewidth=0.5)

    ax.set_xticks(x_pos)
    ax.set_xticklabels(labels, rotation=45, ha='right', fontsize=9)
    ax.set_ylabel(config.ylabel, fontsize=10)
    if config.title:
        ax.set_title(config.title, fontsize=14, fontweight='bold', pad=15)
    if config.show_grid:
        ax.grid(axis='y', alpha=0.3, linestyle='--')
    ax.set_axisbelow(True)

    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', facecolor='white')
    buf.seek(0)
    plt.close(fig)
    return buf


def create_line_chart(table: TableData, config: ChartConfig) -> io.BytesIO:
    """Create a line chart from table data."""
    _setup_chinese_font()

    if not table.rows:
        raise ValueError("No data to chart")

    if table.has_headers:
        x_labels = [str(h) for h in table.headers[1:]] if len(table.headers) > 1 else [f"P{i}" for i in range(len(table.rows))]
    else:
        x_labels = [str(row[0]) if row and len(row) > 0 else "" for row in table.rows]

    colors = _get_colors(config)

    fig, ax = plt.subplots(figsize=config.figsize, dpi=config.dpi)

    for idx, row in enumerate(table.rows[:5]):
        values = [float(row[i]) if i < len(row) and row[i] else 0 for i in range(1, len(row))]
        if len(values) == len(x_labels):
            ax.plot(x_labels, values, marker='o', linewidth=2, markersize=6,
                   color=colors[idx % len(colors)], label=f"Series {idx+1}")

    ax.set_xticklabels(x_labels, rotation=45, ha='right', fontsize=9)
    ax.set_ylabel(config.ylabel, fontsize=10)
    if config.title:
        ax.set_title(config.title, fontsize=14, fontweight='bold', pad=15)
    if config.show_grid:
        ax.grid(alpha=0.3, linestyle='--')
    if config.show_legend:
        ax.legend(loc='best', fontsize=9)
    ax.set_axisbelow(True)

    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', facecolor='white')
    buf.seek(0)
    plt.close(fig)
    return buf


def create_pie_chart(table: TableData, config: ChartConfig) -> io.BytesIO:
    """Create a pie chart from table data."""
    _setup_chinese_font()

    if not table.rows:
        raise ValueError("No data to chart")

    if table.has_headers and len(table.rows) > 0:
        # First column is label, rest are values
        if len(table.headers) >= 2:
            labels = [str(h) for h in table.headers[1:]]
            values = [float(table.rows[0][i]) if i < len(table.rows[0]) and table.rows[0][i] else 0 for i in range(1, len(table.headers))]
        else:
            labels = [str(table.rows[0][0])] if table.rows else ["A", "B", "C", "D"]
            values = [float(v) if v else 0 for v in table.rows[0][1:]] if table.rows else [10, 20, 30, 40]
    else:
        labels = [str(row[0]) if row and len(row) > 0 else "" for row in table.rows[:8]]
        values = [float(row[-1]) if row and len(row) > 1 and row[-1] else 0 for row in table.rows[:8]]

    colors = _get_colors(config)

    fig, ax = plt.subplots(figsize=config.figsize, dpi=config.dpi)

    wedges, texts, autotexts = ax.pie(
        values,
        labels=labels,
        autopct='%1.1f%%',
        colors=colors[:len(values)],
        startangle=90,
        pctdistance=0.75,
        textprops={'fontsize': 9}
    )

    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')

    if config.title:
        ax.set_title(config.title, fontsize=14, fontweight='bold', pad=15)

    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', facecolor='white')
    buf.seek(0)
    plt.close(fig)
    return buf


def create_horizontal_bar_chart(table: TableData, config: ChartConfig) -> io.BytesIO:
    """Create a horizontal bar chart from table data."""
    _setup_chinese_font()

    if not table.rows:
        raise ValueError("No data to chart")

    labels = [str(row[0]) if row and len(row) > 0 else "" for row in table.rows[:10]]
    values = [float(row[-1]) if row and len(row) > 0 and row[-1] else 0 for row in table.rows[:10]]

    colors = _get_colors(config)

    fig, ax = plt.subplots(figsize=config.figsize, dpi=config.dpi)

    y_pos = np.arange(len(labels))
    bars = ax.barh(y_pos, values, color=colors[:len(labels)], edgecolor='white', linewidth=0.5)

    ax.set_yticks(y_pos)
    ax.set_yticklabels(labels, fontsize=9)
    ax.set_xlabel(config.xlabel or config.ylabel, fontsize=10)
    if config.title:
        ax.set_title(config.title, fontsize=14, fontweight='bold', pad=15)
    if config.show_grid:
        ax.grid(axis='x', alpha=0.3, linestyle='--')
    ax.invert_yaxis()

    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', facecolor='white')
    buf.seek(0)
    plt.close(fig)
    return buf


def create_stacked_bar_chart(table: TableData, config: ChartConfig) -> io.BytesIO:
    """Create a stacked bar chart from table data."""
    _setup_chinese_font()

    if not table.rows or len(table.rows) < 2:
        raise ValueError("Need at least 2 rows for stacked chart")

    labels = [str(row[0]) if row and len(row) > 0 else "" for row in table.rows]

    num_cols = max(len(row) - 1 for row in table.rows if row)
    if num_cols <= 0:
        num_cols = 1

    colors = _get_colors(config)

    fig, ax = plt.subplots(figsize=config.figsize, dpi=config.dpi)

    x_pos = np.arange(len(labels))
    bottom = np.zeros(len(labels))

    for col_idx in range(num_cols):
        values = [float(row[col_idx + 1]) if col_idx + 1 < len(row) and row[col_idx + 1] else 0 for row in table.rows]
        ax.bar(x_pos, values, bottom=bottom, label=f"Series {col_idx + 1}",
               color=colors[col_idx % len(colors)], edgecolor='white', linewidth=0.5)
        bottom += values

    ax.set_xticks(x_pos)
    ax.set_xticklabels(labels, rotation=45, ha='right', fontsize=9)
    ax.set_ylabel(config.ylabel, fontsize=10)
    if config.title:
        ax.set_title(config.title, fontsize=14, fontweight='bold', pad=15)
    if config.show_grid:
        ax.grid(axis='y', alpha=0.3, linestyle='--')
    if config.show_legend:
        ax.legend(loc='best', fontsize=9)

    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', facecolor='white')
    buf.seek(0)
    plt.close(fig)
    return buf


def auto_select_chart_type(table: TableData) -> ChartType:
    """Automatically select the best chart type based on data characteristics."""
    if not table.rows:
        return ChartType.BAR

    num_rows = table.row_count
    num_cols = table.col_count

    # Small table with few rows -> Pie
    if num_rows <= 3 and num_cols >= 2:
        return ChartType.PIE

    # Many rows, 2 cols -> Horizontal bar
    if num_rows >= 5 and num_cols == 2:
        return ChartType.HORIZONTAL_BAR

    # Multiple data columns (more than just label+1 value) -> Stacked bar
    if num_cols >= 3:
        return ChartType.STACKED_BAR

    # Many rows -> Line
    if num_rows >= 5:
        return ChartType.LINE

    return ChartType.BAR


def create_chart(table: TableData, config: ChartConfig) -> io.BytesIO:
    """Create a chart based on configuration and data."""
    chart_type = config.color_scheme

    if chart_type == "line":
        return create_line_chart(table, config)
    elif chart_type == "pie":
        return create_pie_chart(table, config)
    elif chart_type == "horizontal_bar":
        return create_horizontal_bar_chart(table, config)
    elif chart_type == "stacked_bar":
        return create_stacked_bar_chart(table, config)
    else:
        return create_bar_chart(table, config)


def chart_to_image(table: TableData,
                   chart_type: Optional[str] = None,
                   title: str = "",
                   color_scheme: str = "business") -> bytes:
    """Convert table data to a chart image."""
    if chart_type is None or chart_type == "auto":
        selected_type = auto_select_chart_type(table)
    else:
        type_map = {
            "bar": ChartType.BAR,
            "line": ChartType.LINE,
            "pie": ChartType.PIE,
            "horizontal_bar": ChartType.HORIZONTAL_BAR,
            "stacked_bar": ChartType.STACKED_BAR,
            "grouped_bar": ChartType.BAR,
            "scatter": ChartType.BAR,
        }
        selected_type = type_map.get(chart_type.lower(), ChartType.BAR)

    config = ChartConfig(
        title=title,
        color_scheme=color_scheme,
        show_grid=True
    )

    chart_buffer = create_chart(table, config)
    return chart_buffer.getvalue()


if __name__ == "__main__":
    test_table = TableData(
        headers=["部门", "销售额", "增长"],
        rows=[
            ["销售部", 1200000, 15],
            ["市场部", 850000, 8],
            ["技术部", 920000, 12],
            ["运营部", 680000, 5],
        ]
    )

    print("Testing chart creation...")
    img = chart_to_image(test_table, title="部门销售业绩", color_scheme="business")
    print(f"Chart created: {len(img)} bytes")
