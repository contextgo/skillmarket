"""
Document Parser - Extracts content and structure from Word, Excel, and PDF files.
"""

import os
import logging
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class SceneType(Enum):
    """Document scene types for appropriate styling."""
    FINANCIAL = "financial"      # 财务
    SALES = "sales"             # 销售
    REPORT = "report"           # 述职/汇报
    BIDDING = "bidding"         # 投标
    TEACHING = "teaching"       # 教学
    GENERAL = "general"         # 通用


@dataclass
class TableData:
    """Represents a table extracted from document."""
    headers: List[str] = field(default_factory=list)
    rows: List[List[Any]] = field(default_factory=list)
    title: Optional[str] = None

    @property
    def has_headers(self) -> bool:
        return len(self.headers) > 0

    @property
    def row_count(self) -> int:
        return len(self.rows)

    @property
    def col_count(self) -> int:
        if self.headers:
            return len(self.headers)
        if self.rows:
            return len(self.rows[0])
        return 0


@dataclass
class ParsedDocument:
    """Complete parsed document structure."""
    title: str = ""
    headings: List[Tuple[int, str]] = field(default_factory=list)
    paragraphs: List[str] = field(default_factory=list)
    tables: List[TableData] = field(default_factory=list)
    scene_type: SceneType = SceneType.GENERAL
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def has_tables(self) -> bool:
        return len(self.tables) > 0

    @property
    def has_content(self) -> bool:
        return bool(self.title or self.paragraphs or self.tables)


def parse_word(file_path: str) -> ParsedDocument:
    """Parse Word (.docx/.doc) document."""
    from docx import Document
    from docx.document import Document as DocType

    result = ParsedDocument()

    try:
        doc: DocType = Document(file_path)

        if doc.core_properties.title:
            result.title = doc.core_properties.title

        for para in doc.paragraphs:
            text = para.text.strip()
            if not text:
                continue

            style_name = para.style.name if para.style else ""
            if style_name.startswith("Heading"):
                try:
                    level = int(style_name.replace("Heading ", "").replace("Heading", "1"))
                except (ValueError, AttributeError):
                    level = 1
                result.headings.append((level, text))
                if not result.title and level == 1:
                    result.title = text
            else:
                result.paragraphs.append(text)

        for i, table in enumerate(doc.tables):
            table_data = TableData()
            table_data.title = f"表格 {i + 1}"

            for row_idx, row in enumerate(table.rows):
                cells = [cell.text.strip() for cell in row.cells]
                if row_idx == 0 and cells:
                    if all(c for c in cells):
                        table_data.headers = cells
                    else:
                        table_data.rows.append(cells)
                else:
                    table_data.rows.append(cells)

            if table_data.rows or table_data.headers:
                result.tables.append(table_data)

        result.scene_type = _detect_scene(result)

        result.metadata = {
            "source": "word",
            "file_path": file_path,
            "file_name": os.path.basename(file_path),
            "table_count": len(result.tables),
            "paragraph_count": len(result.paragraphs),
        }

    except Exception as e:
        logger.error(f"Error parsing Word document: {e}")
        raise ValueError(f"Failed to parse Word document: {e}")

    return result


def parse_excel(file_path: str) -> ParsedDocument:
    """Parse Excel (.xlsx/.xls) workbook."""
    from openpyxl import load_workbook

    result = ParsedDocument()

    try:
        wb = load_workbook(file_path, data_only=True)
        result.title = os.path.splitext(os.path.basename(file_path))[0]

        for sheet_idx, sheet_name in enumerate(wb.sheetnames):
            sheet = wb[sheet_name]

            table_data = TableData()
            table_data.title = sheet_name if len(wb.sheetnames) > 1 else f"数据表"

            rows_data = []
            for row in sheet.iter_rows(values_only=True):
                if all(cell is None for cell in row):
                    continue
                rows_data.append([cell for cell in row])

            if not rows_data:
                continue

            first_row = rows_data[0] if rows_data else []
            is_header = False
            for cell in first_row:
                if cell is None:
                    continue
                cell_str = str(cell).strip()
                if cell_str and (len(cell_str) < 30 or any(kw in cell_str for kw in ["名称", "项目", "类型", "分类", "科目", "日期", "指标"])):
                    is_header = True
                    break

            if is_header:
                table_data.headers = [str(c) if c is not None else "" for c in rows_data[0]]
                table_data.rows = [[c for c in row] for row in rows_data[1:]]
            else:
                table_data.headers = []
                table_data.rows = [[c for c in row] for row in rows_data]

            if table_data.rows or table_data.headers:
                result.tables.append(table_data)

        if len(wb.sheetnames) > 1:
            for i, name in enumerate(wb.sheetnames):
                result.headings.append((1, name))

        result.scene_type = _detect_scene(result)

        result.metadata = {
            "source": "excel",
            "file_path": file_path,
            "file_name": os.path.basename(file_path),
            "sheet_count": len(wb.sheetnames),
            "table_count": len(result.tables),
        }

    except Exception as e:
        logger.error(f"Error parsing Excel file: {e}")
        raise ValueError(f"Failed to parse Excel file: {e}")

    return result


def parse_pdf(file_path: str) -> ParsedDocument:
    """Parse PDF document."""
    from PyPDF2 import PdfReader

    result = ParsedDocument()

    try:
        reader = PdfReader(file_path)
        result.title = os.path.splitext(os.path.basename(file_path))[0]

        all_text = []
        for page_num, page in enumerate(reader.pages):
            text = page.extract_text()
            if text:
                lines = [l.strip() for l in text.split("\n") if l.strip()]
                all_text.extend(lines)

        in_table = False
        current_table_rows = []
        current_headers = []

        for line in all_text:
            if "\t" in line or "  " in line:
                parts = [p.strip() for p in line.split("\t") if p.strip()]
                if len(parts) >= 2:
                    if not in_table:
                        in_table = True
                        current_table_rows = []
                    current_table_rows.append(parts)
                    continue

            if in_table and current_table_rows:
                if current_headers:
                    table_data = TableData(headers=current_headers, rows=current_table_rows)
                else:
                    table_data = TableData(rows=current_table_rows)
                if table_data.row_count > 0:
                    result.tables.append(table_data)
                in_table = False
                current_table_rows = []
                current_headers = []

            if line and len(line) < 100 and not line.endswith(("。", ".", ",", "，", ";")):
                result.headings.append((1, line))
            else:
                result.paragraphs.append(line)

        if in_table and current_table_rows:
            if current_headers:
                table_data = TableData(headers=current_headers, rows=current_table_rows)
            else:
                table_data = TableData(rows=current_table_rows)
            if table_data.row_count > 0:
                result.tables.append(table_data)

        result.scene_type = _detect_scene(result)

        result.metadata = {
            "source": "pdf",
            "file_path": file_path,
            "file_name": os.path.basename(file_path),
            "page_count": len(reader.pages),
            "table_count": len(result.tables),
            "paragraph_count": len(result.paragraphs),
        }

    except Exception as e:
        logger.error(f"Error parsing PDF: {e}")
        raise ValueError(f"Failed to parse PDF: {e}")

    return result


def _detect_scene(doc: ParsedDocument) -> SceneType:
    """Detect the scene type based on document content."""
    all_text = " ".join([
        doc.title,
        " ".join([h[1] for h in doc.headings]),
        " ".join(doc.paragraphs[:10])
    ]).lower()

    scene_keywords = {
        SceneType.FINANCIAL: ["财务", "收入", "支出", "利润", "成本", "预算", "资产", "负债", "营收", "利润表", "现金流量"],
        SceneType.SALES: ["销售", "市场", "客户", "订单", "业绩", "增长", "渠道"],
        SceneType.REPORT: ["述职", "汇报", "总结", "工作", "计划", "年度", "报告"],
        SceneType.BIDDING: ["投标", "招标", "方案", "报价", "资质", "技术方案"],
        SceneType.TEACHING: ["教学", "课程", "学生", "教师", "培训", "教材"],
    }

    scores = {}
    for scene, keywords in scene_keywords.items():
        score = sum(1 for kw in keywords if kw in all_text)
        scores[scene] = score

    if max(scores.values()) > 0:
        return max(scores, key=scores.get)
    return SceneType.GENERAL


def parse_csv(file_path: str) -> ParsedDocument:
    """Parse CSV file into a ParsedDocument with a single table."""
    result = ParsedDocument()
    result.title = os.path.splitext(os.path.basename(file_path))[0]

    try:
        import csv
        with open(file_path, newline="", encoding="utf-8-sig") as f:
            reader = csv.reader(f)
            rows_data = [[cell.strip() for cell in row] for row in reader if row]

        if not rows_data:
            result.metadata = {"source": "csv", "file_path": file_path, "file_name": os.path.basename(file_path), "row_count": 0}
            return result

        first_row = rows_data[0]
        is_header = False
        for cell in first_row:
            if cell and (len(cell) < 30 or any(kw in cell for kw in ["名称", "项目", "类型", "分类", "科目", "日期", "指标", "金额", "部门", "姓名", "编号"])):
                is_header = True
                break

        table_data = TableData()
        table_data.title = result.title
        if is_header:
            table_data.headers = rows_data[0]
            table_data.rows = rows_data[1:]
        else:
            table_data.headers = []
            table_data.rows = rows_data

        if table_data.rows or table_data.headers:
            result.tables.append(table_data)

        result.scene_type = _detect_scene(result)
        result.metadata = {
            "source": "csv",
            "file_path": file_path,
            "file_name": os.path.basename(file_path),
            "row_count": len(rows_data),
            "column_count": len(rows_data[0]) if rows_data else 0,
            "table_count": 1,
        }
    except UnicodeDecodeError:
        for enc in ["gbk", "gb2312", "latin1"]:
            try:
                import csv
                with open(file_path, newline="", encoding=enc) as f:
                    reader = csv.reader(f)
                    rows_data = [[cell.strip() for cell in row] for row in reader if row]
                if rows_data:
                    table_data = TableData()
                    table_data.title = result.title
                    table_data.headers = rows_data[0] if len(rows_data[0]) < 30 else []
                    table_data.rows = rows_data[1:] if table_data.headers else rows_data
                    if table_data.rows or table_data.headers:
                        result.tables.append(table_data)
                    result.scene_type = _detect_scene(result)
                    result.metadata = {"source": "csv", "encoding": enc, "file_path": file_path, "file_name": os.path.basename(file_path), "row_count": len(rows_data)}
                    return result
            except Exception:
                continue
        logger.error(f"Error parsing CSV file: could not decode with any encoding")
        raise ValueError(f"Failed to parse CSV file: encoding error")
    except Exception as e:
        logger.error(f"Error parsing CSV file: {e}")
        raise ValueError(f"Failed to parse CSV file: {e}")

    return result


def parse_document(file_path: str) -> ParsedDocument:
    """Auto-detect document type and parse accordingly."""
    ext = os.path.splitext(file_path)[1].lower()

    if ext in [".docx", ".doc"]:
        return parse_word(file_path)
    elif ext in [".xlsx", ".xls"]:
        return parse_excel(file_path)
    elif ext == ".csv":
        return parse_csv(file_path)
    elif ext == ".pdf":
        return parse_pdf(file_path)
    else:
        raise ValueError(f"Unsupported file format: {ext}")


def get_supported_extensions() -> List[str]:
    """Get list of supported file extensions."""
    return [".docx", ".doc", ".xlsx", ".xls", ".csv", ".pdf"]


if __name__ == "__main__":
    print("Document parser loaded successfully")
    print(f"Supported extensions: {get_supported_extensions()}")
