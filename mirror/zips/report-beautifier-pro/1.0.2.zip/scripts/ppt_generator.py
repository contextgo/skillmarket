"""
PPT Generator - Creates professional PowerPoint presentations from parsed documents.
Uses python-pptx library for PPTX generation.
"""

import io
import os
import logging
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn
from pptx.oxml import parse_xml

from .document_parser import ParsedDocument, TableData, SceneType
from .templates import get_template, TEMPLATES

logger = logging.getLogger(__name__)


@dataclass
class SlideConfig:
    """Configuration for a slide."""
    title: str = ""
    layout: str = "title_only"  # title_only, title_content, two_content, blank
    background_color: Optional[str] = None
    show_header_bar: bool = True
    header_color: Optional[str] = None


def hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
    """Convert hex color to RGB tuple."""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))


def rgb_to_hex(r: int, g: int, b: int) -> str:
    """Convert RGB to hex color."""
    return f"{r:02X}{g:02X}{b:02X}"


class PPTGenerator:
    """Generates PowerPoint presentations from parsed documents."""

    def __init__(self, template_id: str = "business_blue"):
        """
        Initialize PPT generator with template.

        Args:
            template_id: Template identifier
        """
        self.template = get_template(template_id)
        self.template_id = template_id
        self.prs = Presentation()
        self.prs.slide_width = Inches(13.333)  # 16:9 aspect ratio
        self.prs.slide_height = Inches(7.5)

    def _get_color(self, color_key: str) -> RGBColor:
        """Get RGBColor from template."""
        hex_color = self.template.get(color_key, "#FFFFFF")
        r, g, b = hex_to_rgb(hex_color)
        return RGBColor(r, g, b)

    def _set_slide_background(self, slide, color: Optional[str] = None) -> None:
        """Set slide background color."""
        if color:
            r, g, b = hex_to_rgb(color)
        else:
            r, g, b = hex_to_rgb(self.template.get("background", "#FFFFFF"))

        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = RGBColor(r, g, b)

    def _add_header_bar(self, slide, title: str = "") -> None:
        """Add a colored header bar to the slide."""
        if not self.template.get("show_header_bar", True):
            return

        header_color = self._get_color("primary")
        width = self.prs.slide_width
        height = Inches(1.2)

        shape = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            0, 0,
            width, height
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = header_color
        shape.line.fill.background()

        # Add title text
        if title:
            left = Inches(0.5)
            top = Inches(0.3)
            width = Inches(12)
            height = Inches(0.7)

            text_frame = slide.shapes.add_textbox(left, top, width, height).text_frame
            text_frame.word_wrap = True
            p = text_frame.paragraphs[0]
            p.text = title
            p.font.size = Pt(32)
            p.font.bold = True
            p.font.color.rgb = RGBColor(255, 255, 255)
            p.font.name = self.template.get("font_title", "Microsoft YaHei")
            p.alignment = PP_ALIGN.LEFT

    def _add_content_box(self, slide, content: str, left: float = 0.5, top: float = 1.5,
                        width: float = 12, height: float = 5.5) -> None:
        """Add a text content box."""
        text_color = self._get_color("text")

        text_frame = slide.shapes.add_textbox(
            Inches(left), Inches(top),
            Inches(width), Inches(height)
        ).text_frame

        text_frame.word_wrap = True
        p = text_frame.paragraphs[0]
        p.text = content
        p.font.size = Pt(18)
        p.font.color.rgb = text_color
        p.font.name = self.template.get("font_body", "Microsoft YaHei")
        p.line_spacing = 1.5

    def _add_table_to_slide(self, slide, table_data: TableData,
                            left: float = 0.5, top: float = 1.5,
                            width: float = 12, height: float = 5) -> None:
        """Add a table to the slide."""
        num_rows = len(table_data.rows) + (1 if table_data.has_headers else 0)
        num_cols = max(table_data.col_count, 1)

        # Limit rows per slide
        max_rows = 15
        if num_rows > max_rows:
            num_rows = max_rows

        table = slide.shapes.add_table(
            num_rows, num_cols,
            Inches(left), Inches(top),
            Inches(width), Inches(height)
        ).table

        # Style the table
        primary_color = self._get_color("primary")
        light_color = self._get_color("light")
        text_color = self._get_color("text")
        accent_color = self._get_color("accent")

        # Set column widths
        col_width = Inches(width / num_cols)
        for i in range(num_cols):
            table.columns[i].width = col_width

        row_idx = 0

        # Add headers
        if table_data.has_headers:
            for col_idx, header in enumerate(table_data.headers[:num_cols]):
                cell = table.cell(row_idx, col_idx)
                cell.text = str(header)
                cell.fill.solid()
                cell.fill.fore_color.rgb = primary_color
                para = cell.text_frame.paragraphs[0]
                para.font.bold = True
                para.font.size = Pt(12)
                para.font.color.rgb = RGBColor(255, 255, 255)
                para.font.name = self.template.get("font_body", "Microsoft YaHei")
                para.alignment = PP_ALIGN.CENTER
            row_idx += 1

        # Add data rows
        for data_row in table_data.rows[:max_rows - (1 if table_data.has_headers else 0)]:
            for col_idx in range(num_cols):
                cell = table.cell(row_idx, col_idx)
                value = data_row[col_idx] if col_idx < len(data_row) else ""
                cell.text = str(value) if value is not None else ""

                # Alternate row colors
                if row_idx % 2 == 0:
                    cell.fill.solid()
                    cell.fill.fore_color.rgb = light_color
                else:
                    cell.fill.solid()
                    cell.fill.fore_color.rgb = RGBColor(255, 255, 255)

                para = cell.text_frame.paragraphs[0]
                para.font.size = Pt(11)
                para.font.color.rgb = text_color
                para.font.name = self.template.get("font_body", "Microsoft YaHei")
                para.alignment = PP_ALIGN.CENTER
            row_idx += 1

    def _add_image_to_slide(self, slide, image_data: bytes,
                           left: float = 0.5, top: float = 1.5,
                           width: float = 6, height: float = 5) -> None:
        """Add an image to the slide."""
        image_stream = io.BytesIO(image_data)
        slide.shapes.add_picture(
            image_stream,
            Inches(left), Inches(top),
            Inches(width), Inches(height)
        )

    def add_title_slide(self, title: str, subtitle: str = "") -> None:
        """Add a title/cover slide."""
        slide_layout = self.prs.slide_layouts[6]  # Blank
        slide = self.prs.slides.add_slide(slide_layout)
        self._set_slide_background(slide)

        # Full slide header bar
        header_height = Inches(3)
        shape = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            0, 0,
            self.prs.slide_width, header_height
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = self._get_color("primary")
        shape.line.fill.background()

        # Title
        title_box = slide.shapes.add_textbox(
            Inches(0.75), Inches(1.0),
            Inches(11.8), Inches(1.5)
        )
        tf = title_box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = title
        p.font.size = Pt(48)
        p.font.bold = True
        p.font.color.rgb = RGBColor(255, 255, 255)
        p.font.name = self.template.get("font_title", "Microsoft YaHei")
        p.alignment = PP_ALIGN.CENTER

        # Subtitle
        if subtitle:
            subtitle_box = slide.shapes.add_textbox(
                Inches(0.75), Inches(3.5),
                Inches(11.8), Inches(1)
            )
            tf = subtitle_box.text_frame
            p = tf.paragraphs[0]
            p.text = subtitle
            p.font.size = Pt(24)
            p.font.color.rgb = self._get_color("text_light")
            p.font.name = self.template.get("font_body", "Microsoft YaHei")
            p.alignment = PP_ALIGN.CENTER

        # Add decorative accent line
        accent_left = Inches(5.5)
        accent_width = Inches(2.333)
        accent = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            accent_left, Inches(2.8),
            accent_width, Inches(0.1)
        )
        accent.fill.solid()
        accent.fill.fore_color.rgb = self._get_color("accent")
        accent.line.fill.background()

    def add_content_slide(self, title: str, content: str) -> None:
        """Add a content slide with title and text."""
        slide_layout = self.prs.slide_layouts[6]  # Blank
        slide = self.prs.slides.add_slide(slide_layout)
        self._set_slide_background(slide)
        self._add_header_bar(slide, title)
        self._add_content_box(slide, content)

    def add_table_slide(self, title: str, table_data: TableData) -> None:
        """Add a slide with a table."""
        slide_layout = self.prs.slide_layouts[6]  # Blank
        slide = self.prs.slides.add_slide(slide_layout)
        self._set_slide_background(slide)
        self._add_header_bar(slide, title)
        self._add_table_to_slide(slide, table_data)

    def add_image_slide(self, title: str, image_data: bytes,
                       caption: str = "") -> None:
        """Add a slide with an image/chart."""
        slide_layout = self.prs.slide_layouts[6]  # Blank
        slide = self.prs.slides.add_slide(slide_layout)
        self._set_slide_background(slide)
        self._add_header_bar(slide, title)

        # Center the image
        img_width = 10
        img_left = (13.333 - img_width) / 2
        self._add_image_to_slide(slide, image_data,
                                 left=img_left, top=1.5,
                                 width=img_width, height=5)

        if caption:
            caption_box = slide.shapes.add_textbox(
                Inches(1), Inches(6.8),
                Inches(11.3), Inches(0.5)
            )
            tf = caption_box.text_frame
            p = tf.paragraphs[0]
            p.text = caption
            p.font.size = Pt(12)
            p.font.color.rgb = self._get_color("text_light")
            p.font.name = self.template.get("font_body", "Microsoft YaHei")
            p.alignment = PP_ALIGN.CENTER

    def add_two_column_slide(self, title: str, left_content: str,
                            right_content: str) -> None:
        """Add a slide with two columns of content."""
        slide_layout = self.prs.slide_layouts[6]  # Blank
        slide = self.prs.slides.add_slide(slide_layout)
        self._set_slide_background(slide)
        self._add_header_bar(slide, title)

        # Left column
        self._add_content_box(slide, left_content,
                             left=0.5, top=1.5,
                             width=5.8, height=5.5)

        # Right column
        self._add_content_box(slide, right_content,
                             left=6.8, top=1.5,
                             width=5.8, height=5.5)

    def add_image_and_text_slide(self, title: str, image_data: bytes,
                                 text_content: str,
                                 image_on_left: bool = True) -> None:
        """Add a slide with image on one side and text on the other."""
        slide_layout = self.prs.slide_layouts[6]  # Blank
        slide = self.prs.slides.add_slide(slide_layout)
        self._set_slide_background(slide)
        self._add_header_bar(slide, title)

        if image_on_left:
            self._add_image_to_slide(slide, image_data,
                                    left=0.3, top=1.5,
                                    width=6, height=5.5)
            self._add_content_box(slide, text_content,
                                 left=6.5, top=1.5,
                                 width=6.3, height=5.5)
        else:
            self._add_content_box(slide, text_content,
                                 left=0.5, top=1.5,
                                 width=6.3, height=5.5)
            self._add_image_to_slide(slide, image_data,
                                    left=6.8, top=1.5,
                                    width=6, height=5.5)

    def add_section_slide(self, section_title: str) -> None:
        """Add a section divider slide."""
        slide_layout = self.prs.slide_layouts[6]  # Blank
        slide = self.prs.slides.add_slide(slide_layout)

        # Set background to primary color
        shape = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            0, 0,
            self.prs.slide_width, self.prs.slide_height
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = self._get_color("primary")
        shape.line.fill.background()

        # Add section title centered
        title_box = slide.shapes.add_textbox(
            Inches(0.75), Inches(3),
            Inches(11.8), Inches(1.5)
        )
        tf = title_box.text_frame
        p = tf.paragraphs[0]
        p.text = section_title
        p.font.size = Pt(44)
        p.font.bold = True
        p.font.color.rgb = RGBColor(255, 255, 255)
        p.font.name = self.template.get("font_title", "Microsoft YaHei")
        p.alignment = PP_ALIGN.CENTER

    def add_closing_slide(self, title: str = "谢谢", subtitle: str = "") -> None:
        """Add a closing/thank you slide."""
        slide_layout = self.prs.slide_layouts[6]  # Blank
        slide = self.prs.slides.add_slide(slide_layout)
        self._set_slide_background(slide)

        # Center content
        title_box = slide.shapes.add_textbox(
            Inches(0.75), Inches(2.8),
            Inches(11.8), Inches(1.5)
        )
        tf = title_box.text_frame
        p = tf.paragraphs[0]
        p.text = title
        p.font.size = Pt(56)
        p.font.bold = True
        p.font.color.rgb = self._get_color("primary")
        p.font.name = self.template.get("font_title", "Microsoft YaHei")
        p.alignment = PP_ALIGN.CENTER

        if subtitle:
            sub_box = slide.shapes.add_textbox(
                Inches(0.75), Inches(4.5),
                Inches(11.8), Inches(1)
            )
            tf = sub_box.text_frame
            p = tf.paragraphs[0]
            p.text = subtitle
            p.font.size = Pt(24)
            p.font.color.rgb = self._get_color("text_light")
            p.font.name = self.template.get("font_body", "Microsoft YaHei")
            p.alignment = PP_ALIGN.CENTER

    def build_from_document(self, doc: ParsedDocument,
                           include_charts: bool = True) -> None:
        """
        Build a complete presentation from a parsed document.

        Args:
            doc: ParsedDocument with content
            include_charts: Whether to create charts from tables
        """
        # Title slide
        self.add_title_slide(
            title=doc.title or "报告",
            subtitle=f"自动生成 | {doc.scene_type.value}"
        )

        # Headings become section slides + content
        for level, heading in doc.headings[:20]:  # Limit to 20 headings
            if level == 1:
                self.add_section_slide(heading)
            else:
                self.add_content_slide(heading, "")

        # Tables
        if doc.has_tables and include_charts:
            from .chart_maker import chart_to_image, auto_select_chart_type

            for i, table in enumerate(doc.tables[:10]):  # Max 10 tables
                # Add table slide
                self.add_table_slide(f"数据表 {i+1}", table)

                # Add chart slide (auto-select chart type)
                try:
                    chart_type = auto_select_chart_type(table)
                    chart_data = chart_to_image(
                        table,
                        title=f"图表 {i+1}",
                        color_scheme=self.template_id
                    )
                    self.add_image_slide(
                        f"图表 {i+1}",
                        chart_data,
                        caption=table.title or f"数据表 {i+1}"
                    )
                except Exception as e:
                    logger.warning(f"Could not create chart for table {i+1}: {e}")

        # Content paragraphs as content slides
        content = "\n\n".join(doc.paragraphs[:10])
        if content:
            self.add_content_slide("内容详情", content)

        # Closing slide
        self.add_closing_slide("谢谢观看", "感谢您的关注")

    def save(self, output_path: str) -> str:
        """Save the presentation to a file."""
        self.prs.save(output_path)
        return output_path

    def get_bytes(self) -> bytes:
        """Get presentation as bytes."""
        buffer = io.BytesIO()
        self.prs.save(buffer)
        buffer.seek(0)
        return buffer.getvalue()


def create_presentation(file_path: str,
                       template_id: str = "business_blue",
                       include_charts: bool = True) -> str:
    """
    Create a presentation from a document file.

    Args:
        file_path: Path to input document
        template_id: Template to use
        include_charts: Whether to include charts

    Returns:
        Path to created presentation
    """
    from .document_parser import parse_document

    # Parse the document
    doc = parse_document(file_path)

    # Create generator
    generator = PPTGenerator(template_id)

    # Build presentation
    generator.build_from_document(doc, include_charts=include_charts)

    # Determine output path
    base_name = os.path.splitext(file_path)[0]
    output_path = f"{base_name}_beautified.pptx"

    # Save
    generator.save(output_path)

    return output_path


if __name__ == "__main__":
    print("PPT Generator loaded successfully")
    print(f"Available templates: {len(TEMPLATES)}")
