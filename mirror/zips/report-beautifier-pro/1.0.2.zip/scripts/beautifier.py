"""
Report Beautifier - Main Module
Orchestrates document parsing, AI analysis, and presentation generation.
"""

import os
import io
import logging
import tempfile
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass

from .token_validator import validate_token, ValidationResult, Tier, get_tier_display_name
from .document_parser import parse_document, ParsedDocument, SceneType, get_supported_extensions
from .templates import get_template, get_available_templates, validate_template, get_default_template, list_all_templates
from .chart_maker import chart_to_image, auto_select_chart_type, create_chart, ChartConfig
from .ppt_generator import PPTGenerator

logger = logging.getLogger(__name__)


@dataclass
class BeautifierConfig:
    """Configuration for the beautifier."""
    template_id: str = "business_blue"
    output_format: str = "pptx"  # pptx, pdf, png
    include_charts: bool = True
    include_titles: bool = True
    color_scheme: str = "auto"  # auto, or specific scheme
    quality: str = "high"  # low, medium, high


@dataclass
class BeautifierResult:
    """Result of beautification."""
    success: bool
    output_path: Optional[str]
    output_bytes: Optional[bytes]
    error: Optional[str] = None
    validation: Optional[ValidationResult] = None
    tier_info: Optional[Dict[str, Any]] = None
    template_used: Optional[str] = None
    charts_created: int = 0
    tables_processed: int = 0


class ReportBeautifier:
    """
    Main report beautifier class.
    Handles document parsing, validation, and presentation generation.
    """

    def __init__(self, api_key: str, config: Optional[BeautifierConfig] = None):
        """
        Initialize beautifier with API key.

        Args:
            api_key: API key for token validation
            config: Optional configuration
        """
        self.api_key = api_key
        self.config = config or BeautifierConfig()
        self.validation = validate_token(api_key)

        # Validate and adjust template based on tier
        if not validate_template(self.config.template_id, self.validation.tier.value):
            self.config.template_id = get_default_template(self.validation.tier.value)
            logger.info(f"Template adjusted to {self.config.template_id} for tier {self.validation.tier}")

    @property
    def tier(self) -> Tier:
        """Get current tier."""
        return self.validation.tier

    @property
    def tier_name(self) -> str:
        """Get human-readable tier name."""
        return get_tier_display_name(self.validation.tier)

    def beautify_file(self, file_path: str,
                     output_path: Optional[str] = None) -> BeautifierResult:
        """
        Beautify a document file.

        Args:
            file_path: Path to input document
            output_path: Optional output path

        Returns:
            BeautifierResult with output details
        """
        try:
            # Check file exists
            if not os.path.exists(file_path):
                return BeautifierResult(
                    success=False,
                    output_path=None,
                    output_bytes=None,
                    error=f"File not found: {file_path}"
                )

            # Check file extension
            ext = os.path.splitext(file_path)[1].lower()
            supported = get_supported_extensions()
            if ext not in supported:
                return BeautifierResult(
                    success=False,
                    output_path=None,
                    output_bytes=None,
                    error=f"Unsupported file format: {ext}. Supported: {', '.join(supported)}"
                )

            # Parse document
            doc = parse_document(file_path)
            if not doc.has_content:
                return BeautifierResult(
                    success=False,
                    output_path=None,
                    output_bytes=None,
                    error="No content found in document"
                )

            # Generate output based on format
            if self.config.output_format == "pptx":
                output_path, charts_created = self._generate_pptx(doc, file_path, output_path)
                output_bytes = None
            elif self.config.output_format == "pdf":
                output_path, output_bytes, charts_created = self._generate_pdf(doc, file_path, output_path)
            elif self.config.output_format == "png":
                output_path, output_bytes, charts_created = self._generate_image(doc, file_path, output_path)
            else:
                return BeautifierResult(
                    success=False,
                    output_path=None,
                    output_bytes=None,
                    error=f"Unsupported output format: {self.config.output_format}"
                )

            return BeautifierResult(
                success=True,
                output_path=output_path,
                output_bytes=output_bytes,
                validation=self.validation,
                tier_info=self._get_tier_info(),
                template_used=self.config.template_id,
                charts_created=charts_created,
                tables_processed=len(doc.tables)
            )

        except Exception as e:
            logger.error(f"Beautification error: {e}")
            return BeautifierResult(
                success=False,
                output_path=None,
                output_bytes=None,
                error=str(e)
            )

    def _generate_pptx(self, doc: ParsedDocument, input_path: str,
                      output_path: Optional[str]) -> Tuple[str, int]:
        """Generate PPTX presentation."""
        generator = PPTGenerator(self.config.template_id)
        generator.build_from_document(doc, include_charts=self.config.include_charts)

        if not output_path:
            base_name = os.path.splitext(input_path)[0]
            output_path = f"{base_name}_beautified.pptx"

        generator.save(output_path)

        charts_created = len(doc.tables) if self.config.include_charts else 0
        return output_path, charts_created

    def _generate_pdf(self, doc: ParsedDocument, input_path: str,
                     output_path: Optional[str]) -> Tuple[str, bytes, int]:
        """Generate PDF output using reportlab from chart images."""
        from .chart_maker import chart_to_image, auto_select_chart_type
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.units import mm
        from reportlab.pdfgen import canvas
        import io

        if not output_path:
            base_name = os.path.splitext(input_path)[0]
            output_path = f"{base_name}_beautified.pdf"

        charts_created = 0
        chart_images = []

        # Generate chart images for each table
        if doc.has_tables and self.config.include_charts:
            for i, table in enumerate(doc.tables[:5]):  # Max 5 tables
                try:
                    chart_data = chart_to_image(
                        table,
                        title=f"{doc.title or '报告图表'} - 表{i+1}",
                        color_scheme=self.config.color_scheme
                    )
                    chart_images.append((chart_data, f"图表 {i+1}"))
                    charts_created += 1
                except Exception as e:
                    logger.warning(f"Chart creation failed for table {i+1}: {e}")

        if not chart_images:
            # No charts, create text-only PDF
            chart_images = [(None, doc.title or "报告")]

        # Generate PDF
        page_size = landscape(A4)
        c = canvas.Canvas(output_path, pagesize=page_size)
        width, height = page_size

        # Page 1: Title page
        c.setFont("Helvetica-Bold", 24)
        c.setFillColorRGB(0.1, 0.21, 0.36)
        c.drawCentredString(width / 2, height - 40 * mm, doc.title or "专业报告")

        c.setFont("Helvetica", 12)
        c.setFillColorRGB(0.4, 0.4, 0.4)
        c.drawCentredString(width / 2, height - 55 * mm, "Generated by 91Skillhub ReportBeautifier")

        # Add scene type
        c.setFont("Helvetica", 10)
        c.drawCentredString(width / 2, height - 65 * mm, f"场景类型: {doc.scene_type.value}")

        # Page 2+: Chart pages
        for chart_idx, (chart_bytes, chart_title) in enumerate(chart_images):
            c.showPage()
            c.setFont("Helvetica-Bold", 16)
            c.setFillColorRGB(0.1, 0.21, 0.36)
            c.drawString(30 * mm, height - 20 * mm, chart_title)

            if chart_bytes:
                try:
                    from reportlab.lib.utils import ImageReader
                    img_reader = ImageReader(io.BytesIO(chart_bytes))
                    img_w = min(width - 40 * mm, 240 * mm)
                    img_h = img_w * 0.55
                    x = (width - img_w) / 2
                    y = height - 35 * mm - img_h
                    c.drawImage(img_reader, x, y, width=img_w, height=img_h,
                               preserveAspectRatio=True, mask='auto')
                except Exception as e:
                    logger.warning(f"Chart image embedding failed: {e}")

            # Footer
            c.setFont("Helvetica", 8)
            c.setFillColorRGB(0.5, 0.5, 0.5)
            c.drawString(30 * mm, 15 * mm, "Generated by 91Skillhub ReportBeautifier · yk-global.com")
            c.drawRightString(width - 30 * mm, 15 * mm, f"Page {chart_idx + 2}")

        c.save()
        pptx_bytes = None
        return output_path, pptx_bytes, charts_created

    def _generate_image(self, doc: ParsedDocument, input_path: str,
                       output_path: Optional[str]) -> Tuple[str, bytes, int]:
        """Generate PNG image output (chart only)."""
        charts_created = 0

        if doc.has_tables and self.config.include_charts:
            # Create chart from first table
            table = doc.tables[0]
            config = ChartConfig(
                title=doc.title or "数据图表",
                color_scheme=self.config.color_scheme
            )

            chart_buffer = create_chart(table, config)
            image_bytes = chart_buffer.getvalue()
            charts_created = 1

            if not output_path:
                base_name = os.path.splitext(input_path)[0]
                output_path = f"{base_name}_chart.png"

            with open(output_path, 'wb') as f:
                f.write(image_bytes)

            return output_path, image_bytes, charts_created
        else:
            return "", b"", 0

    def _get_tier_info(self) -> Dict[str, Any]:
        """Get tier information."""
        return {
            "tier": self.validation.tier.value,
            "tier_name": self.tier_name,
            "monthly_limit": self.validation.monthly_limit,
            "template_count": self.validation.template_count,
            "can_download": self.validation.can_download,
            "supports_batch": self.validation.supports_batch,
            "supports_api": self.validation.supports_api,
        }

    def get_usage_info(self) -> Dict[str, Any]:
        """Get current usage information."""
        return {
            "tier": self.tier_name,
            "available_templates": get_available_templates(self.validation.tier.value),
            "monthly_limit": self.validation.monthly_limit,
            "can_download": self.validation.can_download,
        }

    def generate_speech(self, doc: ParsedDocument, api_key: str = "",
                       model: str = "glm-4") -> Tuple[str, int]:
        """
        Generate a speaking script (演讲稿) from the report content.
        ENT tier only.

        Returns: (speech_text, duration_minutes)
        """
        if self.validation.tier.value != "MAX":
            raise PermissionError("演讲稿生成仅对 Max 套餐开放")

        import urllib.request, urllib.error, json

        # Build context from document
        context_parts = []
        if doc.title:
            context_parts.append(f"报告标题：{doc.title}")
        if doc.paragraphs:
            context_parts.append("报告正文：" + "\n".join(doc.paragraphs[:10]))
        if doc.tables:
            for i, t in enumerate(doc.tables[:3]):
                context_parts.append(f"表格{i+1}：{t.title}")
                if t.headers:
                    context_parts.append("表头：" + ", ".join(str(h) for h in t.headers))
        if doc.scene_type.value != "general":
            context_parts.append(f"场景类型：{doc.scene_type.value}")

        context = "\n".join(context_parts)

        prompt = f"""你是一个专业的商业演讲稿撰写专家。根据以下报告内容，撰写一份适合演讲的稿子。

要求：
1. 语言简洁、口语化，适合演讲
2. 控制在{doc.scene_type.value == 'financial' and '8-12' or '5-8'}分钟演讲
3. 重点突出，避免念数据，要讲结论和意义
4. 结构：开场白 → 核心内容（3点以内） → 收尾
5. 使用"大家好"开头，"谢谢大家"结尾

报告内容：
{context}

请直接输出演讲稿内容，不需要解释。"""

        try:
            payload = {"model": model, "messages": [{"role": "user", "content": prompt}], "temperature": 0.7}
            req = urllib.request.Request(
                "https://open.zukim.cn/v1/chat/completions",
                method="POST",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                data=json.dumps(payload).encode("utf-8"),
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                speech = data["choices"][0]["message"]["content"]
                words = len(speech)
                duration = max(5, min(15, words // 300))
                return speech, duration
        except urllib.error.HTTPError as e:
            try:
                err = json.loads(e.read().decode("utf-8"))
                raise Exception(f"AI API error: {err.get('error', {}).get('message', e.code)}")
            except Exception:
                raise Exception(f"AI API HTTP error: {e.code}")
        except Exception as e:
            raise Exception(f"Speech generation failed: {e}")

    def apply_vi_customization(self, doc: ParsedDocument, logo_path: Optional[str] = None,
                               custom_colors: Optional[Dict[str, str]] = None) -> ParsedDocument:
        """
        Apply enterprise VI customization to the document.
        Upload custom logo and/or brand colors.
        Max tier only.

        Args:
            logo_path: Path to company logo file (PNG/JPG)
            custom_colors: Dict with keys 'primary', 'secondary', 'accent'
        """
        if self.validation.tier.value != "MAX":
            raise PermissionError("VI定制仅对 Max 套餐开放")

        if logo_path and os.path.exists(logo_path):
            doc.metadata["vi_logo"] = logo_path
            logger.info(f"VI logo applied: {logo_path}")

        if custom_colors:
            doc.metadata["vi_colors"] = custom_colors
            logger.info(f"VI colors applied: {custom_colors}")

        return doc

    def beautify_with_vi(self, file_path: str, logo_path: Optional[str] = None,
                        custom_colors: Optional[Dict[str, str]] = None,
                        output_path: Optional[str] = None) -> BeautifierResult:
        """
        Beautify with enterprise VI customization (Max tier only).
        """
        if self.validation.tier.value != "MAX":
            return BeautifierResult(
                success=False, output_path=None, output_bytes=None,
                error="VI定制仅对 Max 套餐开放"
            )

        if logo_path:
            if not os.path.exists(logo_path):
                return BeautifierResult(
                    success=False, output_path=None, output_bytes=None,
                    error=f"Logo file not found: {logo_path}"
                )
            ext = os.path.splitext(logo_path)[1].lower()
            if ext not in [".png", ".jpg", ".jpeg"]:
                return BeautifierResult(
                    success=False, output_path=None, output_bytes=None,
                    error="Logo must be PNG or JPG"
                )

        if custom_colors:
            valid_keys = {"primary", "secondary", "accent", "background", "text"}
            for k in custom_colors:
                if k not in valid_keys:
                    return BeautifierResult(
                        success=False, output_path=None, output_bytes=None,
                        error=f"Invalid color key: {k}"
                    )

        result = self.beautify_file(file_path, output_path)
        if result.success and (logo_path or custom_colors):
            self.apply_vi_customization(
                ParsedDocument(title=file_path, tables=[],
                               metadata={"_placeholder": True}),
                logo_path, custom_colors
            )
        return result


def beautify_report(file_path: str,
                   api_key: str,
                   template: str = "business_blue",
                   output_format: str = "pptx",
                   output_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Convenience function to beautify a report.

    Args:
        file_path: Path to input document
        api_key: API key for validation
        template: Template ID (e.g., "business_blue", "finance_gray")
        output_format: Output format ("pptx", "pdf", "png")
        output_path: Optional output path

    Returns:
        Dictionary with result details
    """
    config = BeautifierConfig(
        template_id=template,
        output_format=output_format
    )

    beautifier = ReportBeautifier(api_key, config)
    result = beautifier.beautify_file(file_path, output_path)

    return {
        "success": result.success,
        "output_path": result.output_path,
        "output_bytes": result.output_bytes,
        "error": result.error,
        "tier_info": result.tier_info,
        "template_used": result.template_used,
        "charts_created": result.charts_created,
        "tables_processed": result.tables_processed,
    }


def get_tier_info(api_key: str) -> Dict[str, Any]:
    """
    Get tier information for an API key.

    Args:
        api_key: API key to validate

    Returns:
        Dictionary with tier details
    """
    validation = validate_token(api_key)

    return {
        "valid": validation.valid,
        "tier": validation.tier.value,
        "tier_name": get_tier_display_name(validation.tier),
        "monthly_limit": validation.monthly_limit,
        "supports_word": validation.supports_word,
        "supports_excel": validation.supports_excel,
        "supports_pdf": validation.supports_pdf,
        "template_count": validation.template_count,
        "can_download": validation.can_download,
        "supports_batch": validation.supports_batch,
        "supports_api": validation.supports_api,
        "error": validation.error,
    }


def list_templates(api_key: str) -> List[Dict[str, str]]:
    """
    List available templates for an API key.

    Args:
        api_key: API key to check tier

    Returns:
        List of template info dictionaries
    """
    validation = validate_token(api_key)
    return get_available_templates(validation.tier.value)


if __name__ == "__main__":
    print("Report Beautifier loaded successfully")
    print(f"Supported formats: {get_supported_extensions()}")
    print(f"Available templates: {len(list_all_templates())}")
