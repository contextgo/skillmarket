"""
Data Parser - Handles CSV/Excel/Word file parsing and data summary generation.
"""

import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def parse_file(file_path: str) -> dict:
    """
    Parse CSV/Excel/Word file and return DataFrame + summary.

    Returns:
        {
            "success": bool,
            "data": DataFrame,
            "summary": {
                "row_count": int,
                "col_count": int,
                "numeric_cols": list,
                "categorical_cols": list,
                "has_date": bool,
                "categories": int,
                "data_type": str,  # financial/sales/ops/hr/other
            },
            "error": str or None
        }
    """
    path = Path(file_path)
    ext = path.suffix.lower()

    try:
        if ext == ".csv":
            return _parse_csv(file_path)
        elif ext in (".xlsx", ".xls"):
            return _parse_excel(file_path)
        elif ext == ".docx":
            return _parse_word(file_path)
        else:
            return {"success": False, "error": f"Unsupported file format: {ext}", "data": None, "summary": {}}
    except Exception as e:
        logger.error(f"Parse error for {file_path}: {e}")
        return {"success": False, "error": str(e), "data": None, "summary": {}}


def _parse_csv(file_path: str) -> dict:
    """Parse CSV file using pandas."""
    import pandas as pd

    # Try encoding detection
    for enc in ["utf-8", "gbk", "gb2312", "utf-8-sig"]:
        try:
            df = pd.read_csv(file_path, encoding=enc)
            break
        except UnicodeDecodeError:
            continue

    return _build_result(df)


def _parse_excel(file_path: str) -> dict:
    """Parse Excel file using pandas."""
    import pandas as pd

    xl = pd.ExcelFile(file_path, engine="openpyxl")
    # Read first sheet by default
    df = xl.parse(xl.sheet_names[0])
    return _build_result(df)


def _parse_word(file_path: str) -> dict:
    """Parse Word file, extract table data."""
    from docx import Document

    doc = Document(file_path)
    tables = doc.tables

    if not tables:
        return {"success": False, "error": "No tables found in Word document", "data": None, "summary": {}}

    # Use first table
    table = tables[0]
    rows = []
    for row in table.rows:
        cells = [cell.text.strip() for cell in row.cells]
        rows.append(cells)

    # Build DataFrame from rows (first row as header)
    import pandas as pd
    header = rows[0] if rows else []
    data = rows[1:] if len(rows) > 1 else []
    df = pd.DataFrame(data, columns=header)

    return _build_result(df)


def _build_result(df) -> dict:
    """Build success result with DataFrame and summary."""
    import pandas as pd

    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
    categorical_cols = df.select_dtypes(include=["object", "string"]).columns.tolist()

    # Detect date columns
    has_date = False
    for col in df.columns:
        try:
            pd.to_datetime(df[col], infer_datetime_format=True)
            has_date = True
            break
        except Exception:
            continue

    # Infer data type
    data_type = _infer_data_type(df, numeric_cols, categorical_cols)

    # Count categories (for categorical columns)
    categories = 0
    if categorical_cols:
        categories = df[categorical_cols[0]].nunique()

    summary = {
        "row_count": len(df),
        "col_count": len(df.columns),
        "numeric_cols": numeric_cols,
        "categorical_cols": categorical_cols,
        "has_date": has_date,
        "categories": categories,
        "data_type": data_type,
        "columns": list(df.columns),
    }

    return {"success": True, "data": df, "summary": summary, "error": None}


def _infer_data_type(df, numeric_cols: list, categorical_cols: list) -> str:
    """Infer data type from column names and values."""
    col_str = " ".join(df.columns).lower()

    # Financial keywords
    if any(k in col_str for k in ["收入", "利润", "成本", "支出", "财务", "金额", "盈利", "销售额", "利润", "资产", "负债"]):
        return "financial"
    # Sales keywords
    if any(k in col_str for k in ["销售", "订单", "客户", "转化", "流量", "渠道", "GMV"]):
        return "sales"
    # HR keywords
    if any(k in col_str for k in ["员工", "人力", "招聘", "绩效", "部门", "编制"]):
        return "hr"
    # Operations keywords
    if any(k in col_str for k in ["库存", "运营", "供应链", "生产", "采购", "仓储"]):
        return "ops"

    return "other"