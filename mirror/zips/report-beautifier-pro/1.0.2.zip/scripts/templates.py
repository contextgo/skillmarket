"""
Templates - 15 Professional Report Templates
Each template defines colors, fonts, layouts, and styling for presentations.
"""

from typing import Dict, Any, Tuple, List
from dataclasses import dataclass
from enum import Enum

# Template color schemes
TEMPLATES = {
    # 1. 商务蓝 (Business Blue)
    "business_blue": {
        "name": "商务蓝",
        "name_en": "Business Blue",
        "primary": "#1A365D",
        "secondary": "#2B6CB0",
        "accent": "#4299E1",
        "light": "#EBF8FF",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#4A5568",
        "highlight": "#3182CE",
        "chart_colors": ["#1A365D", "#2B6CB0", "#4299E1", "#63B3ED", "#90CDF4", "#BEE3F8"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 2. 金融灰 (Finance Gray)
    "finance_gray": {
        "name": "金融灰",
        "name_en": "Finance Gray",
        "primary": "#1A202C",
        "secondary": "#2D3748",
        "accent": "#718096",
        "light": "#EDF2F7",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#718096",
        "highlight": "#4A5568",
        "chart_colors": ["#1A202C", "#2D3748", "#4A5568", "#718096", "#A0AEC0", "#CBD5E0"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 3. 政务红 (Government Red)
    "government_red": {
        "name": "政务红",
        "name_en": "Government Red",
        "primary": "#9B2C2C",
        "secondary": "#C53030",
        "accent": "#FC8181",
        "light": "#FFF5F5",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#4A5568",
        "highlight": "#E53E3E",
        "chart_colors": ["#9B2C2C", "#C53030", "#E53E3E", "#FC8181", "#FEB2B2", "#FED7D7"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 4. 教学绿 (Teaching Green)
    "teaching_green": {
        "name": "教学绿",
        "name_en": "Teaching Green",
        "primary": "#276749",
        "secondary": "#38A169",
        "accent": "#68D391",
        "light": "#F0FFF4",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#4A5568",
        "highlight": "#48BB78",
        "chart_colors": ["#276749", "#38A169", "#48BB78", "#68D391", "#9AE6B4", "#C6F6D5"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 5. 科技紫 (Tech Purple)
    "tech_purple": {
        "name": "科技紫",
        "name_en": "Tech Purple",
        "primary": "#44337A",
        "secondary": "#6B46C1",
        "accent": "#9F7AEA",
        "light": "#FAF5FF",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#4A5568",
        "highlight": "#805AD5",
        "chart_colors": ["#44337A", "#6B46C1", "#805AD5", "#9F7AEA", "#B794F4", "#D6BCFA"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 6. 活力橙 (Vibrant Orange)
    "vibrant_orange": {
        "name": "活力橙",
        "name_en": "Vibrant Orange",
        "primary": "#C05621",
        "secondary": "#DD6B20",
        "accent": "#ED8936",
        "light": "#FFFAF0",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#4A5568",
        "highlight": "#F6AD55",
        "chart_colors": ["#C05621", "#DD6B20", "#ED8936", "#F6AD55", "#FBD38D", "#FEEBC8"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 7. 清新青 (Fresh Cyan)
    "fresh_cyan": {
        "name": "清新青",
        "name_en": "Fresh Cyan",
        "primary": "#0D6E6E",
        "secondary": "#0E7490",
        "accent": "#06B6D4",
        "light": "#ECFEFF",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#4A5568",
        "highlight": "#22D3EE",
        "chart_colors": ["#0D6E6E", "#0E7490", "#06B6D4", "#22D3EE", "#67E8F9", "#A5F3FC"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 8. 玫瑰粉 (Rose Pink)
    "rose_pink": {
        "name": "玫瑰粉",
        "name_en": "Rose Pink",
        "primary": "#97266D",
        "secondary": "#B83280",
        "accent": "#D53F8C",
        "light": "#FFF5F7",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#4A5568",
        "highlight": "#ED64A6",
        "chart_colors": ["#97266D", "#B83280", "#D53F8C", "#ED64A6", "#F687B3", "#FBB6CE"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 9. 经典金 (Classic Gold)
    "classic_gold": {
        "name": "经典金",
        "name_en": "Classic Gold",
        "primary": "#744210",
        "secondary": "#975A16",
        "accent": "#D69E2E",
        "light": "#FFFFF0",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#4A5568",
        "highlight": "#ECC94B",
        "chart_colors": ["#744210", "#975A16", "#B7791F", "#D69E2E", "#ECC94B", "#F6E05E"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 10. 深海蓝 (Deep Sea Blue)
    "deep_sea_blue": {
        "name": "深海蓝",
        "name_en": "Deep Sea Blue",
        "primary": "#0C4A6E",
        "secondary": "#075985",
        "accent": "#0EA5E9",
        "light": "#F0F9FF",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#4A5568",
        "highlight": "#38BDF8",
        "chart_colors": ["#0C4A6E", "#075985", "#0369A1", "#0EA5E9", "#38BDF8", "#7DD3FC"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 11. 森林绿 (Forest Green)
    "forest_green": {
        "name": "森林绿",
        "name_en": "Forest Green",
        "primary": "#14532D",
        "secondary": "#166534",
        "accent": "#22C55E",
        "light": "#F0FDF4",
        "background": "#FFFFFF",
        "text": "#1A202C",
        "text_light": "#4A5568",
        "highlight": "#4ADE80",
        "chart_colors": ["#14532D", "#166534", "#15803D", "#22C55E", "#4ADE80", "#86EFAC"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 12. 暗夜黑 (Night Dark)
    "night_dark": {
        "name": "暗夜黑",
        "name_en": "Night Dark",
        "primary": "#0F0F0F",
        "secondary": "#1A1A1A",
        "accent": "#3B82F6",
        "light": "#18181B",
        "background": "#09090B",
        "text": "#FAFAFA",
        "text_light": "#A1A1AA",
        "highlight": "#60A5FA",
        "chart_colors": ["#3B82F6", "#60A5FA", "#93C5FD", "#BFDBFE", "#DBEAFE", "#EFF6FF"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 13. 简约白 (Minimal White)
    "minimal_white": {
        "name": "简约白",
        "name_en": "Minimal White",
        "primary": "#000000",
        "secondary": "#374151",
        "accent": "#6B7280",
        "light": "#F9FAFB",
        "background": "#FFFFFF",
        "text": "#111827",
        "text_light": "#6B7280",
        "highlight": "#9CA3AF",
        "chart_colors": ["#000000", "#374151", "#6B7280", "#9CA3AF", "#D1D5DB", "#E5E7EB"],
        "font_title": "Arial",
        "font_body": "Arial",
    },

    # 14. 活力紫 (Vibrant Purple)
    "vibrant_purple": {
        "name": "活力紫",
        "name_en": "Vibrant Purple",
        "primary": "#7C3AED",
        "secondary": "#8B5CF6",
        "accent": "#A78BFA",
        "light": "#F5F3FF",
        "background": "#FFFFFF",
        "text": "#1E1B4B",
        "text_light": "#4C1D95",
        "highlight": "#C4B5FD",
        "chart_colors": ["#7C3AED", "#8B5CF6", "#A78BFA", "#C4B5FD", "#DDD6FE", "#EDE9FE"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },

    # 15. 海洋蓝 (Ocean Blue)
    "ocean_blue": {
        "name": "海洋蓝",
        "name_en": "Ocean Blue",
        "primary": "#0D4F8B",
        "secondary": "#1565C0",
        "accent": "#1976D2",
        "light": "#E3F2FD",
        "background": "#FFFFFF",
        "text": "#0D1B2A",
        "text_light": "#415A77",
        "highlight": "#42A5F5",
        "chart_colors": ["#0D4F8B", "#1565C0", "#1976D2", "#42A5F5", "#90CAF9", "#BBDEFB"],
        "font_title": "Microsoft YaHei",
        "font_body": "Microsoft YaHei",
    },
}

# Template for FREE tier (limited templates)
FREE_TEMPLATES = ["minimal_white"]

# Template for BSC/STD tier (5 templates)
BSC_TEMPLATES = ["business_blue", "finance_gray", "government_red", "teaching_green", "minimal_white"]

# Template for PRO/ENT tier (all 15 templates)
PRO_TEMPLATES = list(TEMPLATES.keys())


def get_template(template_id: str) -> Dict[str, Any]:
    """
    Get template by ID.

    Args:
        template_id: Template identifier (e.g., "business_blue")

    Returns:
        Template dictionary with colors, fonts, etc.
    """
    return TEMPLATES.get(template_id, TEMPLATES["business_blue"])


def get_available_templates(tier: str) -> List[Dict[str, str]]:
    """
    Get list of available templates for a tier.

    Args:
        tier: Tier name (free, bsc, std, pro, ent)

    Returns:
        List of template info dicts
    """
    tier = tier.lower()

    if tier in ["free"]:
        template_ids = FREE_TEMPLATES
    elif tier in ["bsc", "std"]:
        template_ids = BSC_TEMPLATES
    else:  # pro, ent
        template_ids = PRO_TEMPLATES

    return [
        {
            "id": tid,
            "name": TEMPLATES[tid]["name"],
            "name_en": TEMPLATES[tid]["name_en"],
        }
        for tid in template_ids
    ]


def validate_template(template_id: str, tier: str) -> bool:
    """
    Check if a template is valid for the given tier.

    Args:
        template_id: Template identifier
        tier: User's subscription tier

    Returns:
        True if template is available
    """
    tier = tier.lower()

    if tier in ["free"]:
        return template_id in FREE_TEMPLATES
    elif tier in ["bsc", "std"]:
        return template_id in BSC_TEMPLATES
    else:  # pro, ent
        return template_id in PRO_TEMPLATES


def get_default_template(tier: str) -> str:
    """Get default template for a tier."""
    tier = tier.lower()

    if tier in ["free"]:
        return "minimal_white"
    elif tier in ["bsc", "std"]:
        return "business_blue"
    else:  # pro, ent
        return "business_blue"


def list_all_templates() -> List[str]:
    """Get list of all template IDs."""
    return list(TEMPLATES.keys())


if __name__ == "__main__":
    print(f"Total templates: {len(TEMPLATES)}")
    print("\nAvailable templates:")
    for tid, t in TEMPLATES.items():
        print(f"  {tid}: {t['name']} ({t['name_en']})")
