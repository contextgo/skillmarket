"""
Token validation for Report Beautifier.
Validates API keys against api.yk-global.com/v1/verify
"""

import time
import logging
from typing import Optional, Dict, Any
from dataclasses import dataclass
from enum import Enum

import requests

logger = logging.getLogger(__name__)

VALIDATION_URL = "https://api.yk-global.com/v1/verify"
CACHE_DURATION = 300  # 5 minutes


class Tier(Enum):
    FREE = "free"
    BSC = "bsc"      # Standard
    STD = "std"      # Standard alias
    PRO = "pro"
    ENT = "ent"      # Enterprise/Max

    @classmethod
    def from_prefix(cls, prefix: str) -> "Tier":
        prefix = prefix.upper()
        if "FREE" in prefix:
            return cls.FREE
        elif "BSC" in prefix:
            return cls.BSC
        elif "STD" in prefix:
            return cls.STD
        elif "PRO" in prefix:
            return cls.PRO
        elif "ENT" in prefix:
            return cls.ENT
        return cls.FREE


@dataclass
class ValidationResult:
    valid: bool
    tier: Tier
    api_key: str
    error: Optional[str] = None
    from_cache: bool = False

    @property
    def is_free(self) -> bool:
        return self.tier == Tier.FREE

    @property
    def monthly_limit(self) -> int:
        limits = {
            Tier.FREE: 3,
            Tier.BSC: 50,
            Tier.STD: 50,
            Tier.PRO: 300,
            Tier.ENT: -1,  # unlimited
        }
        return limits.get(self.tier, 3)

    @property
    def supports_word(self) -> bool:
        return True  # All tiers support Word

    @property
    def supports_excel(self) -> bool:
        return self.tier not in [Tier.FREE]

    @property
    def supports_pdf(self) -> bool:
        return self.tier not in [Tier.FREE]

    @property
    def supports_pptx(self) -> bool:
        return self.tier not in [Tier.FREE]

    @property
    def template_count(self) -> int:
        counts = {
            Tier.FREE: 1,
            Tier.BSC: 5,
            Tier.STD: 5,
            Tier.PRO: 15,
            Tier.ENT: 15,
        }
        return counts.get(self.tier, 1)

    @property
    def can_download(self) -> bool:
        return self.tier != Tier.FREE

    @property
    def supports_batch(self) -> bool:
        return self.tier == Tier.ENT

    @property
    def supports_api(self) -> bool:
        return self.tier == Tier.ENT


# In-memory cache
_cache: Dict[str, tuple[ValidationResult, float]] = {}


def _get_cache(api_key: str) -> Optional[ValidationResult]:
    """Get cached validation result if not expired."""
    if api_key in _cache:
        result, timestamp = _cache[api_key]
        if time.time() - timestamp < CACHE_DURATION:
            result.from_cache = True
            return result
    return None


def _set_cache(api_key: str, result: ValidationResult) -> None:
    """Cache validation result."""
    _cache[api_key] = (result, time.time())


def validate_token(api_key: str, skip_cache: bool = False) -> ValidationResult:
    """
    Validate API token against the validation server.

    Args:
        api_key: The API key to validate (format: RPT-*)
        skip_cache: If True, bypass the cache

    Returns:
        ValidationResult with tier information
    """
    if not api_key:
        return ValidationResult(
            valid=False,
            tier=Tier.FREE,
            api_key="",
            error="No API key provided"
        )

    # Check cache first
    if not skip_cache:
        cached = _get_cache(api_key)
        if cached:
            return cached

    # Determine expected tier from prefix for fallback
    detected_tier = Tier.from_prefix(api_key)

    try:
        response = requests.post(
            VALIDATION_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            },
            json={},
            timeout=10
        )

        if response.status_code == 200:
            data = response.json()
            is_valid = data.get("valid", False)

            if is_valid:
                result = ValidationResult(
                    valid=True,
                    tier=detected_tier,
                    api_key=api_key
                )
            else:
                # Invalid token - downgrade to FREE
                result = ValidationResult(
                    valid=False,
                    tier=Tier.FREE,
                    api_key=api_key,
                    error="Invalid API key"
                )
        else:
            # HTTP error - network issue, use FREE tier (degraded mode)
            logger.warning(f"Token validation HTTP error: {response.status_code}")
            result = ValidationResult(
                valid=True,  # Don't block usage
                tier=Tier.FREE,
                api_key=api_key,
                error=f"Validation server error ({response.status_code}), using FREE tier"
            )

    except requests.exceptions.Timeout:
        logger.warning("Token validation timeout, using key-prefix tier")
        # Preserve tier from prefix on network error - don't downgrade
        result = ValidationResult(
            valid=True,
            tier=detected_tier,
            api_key=api_key,
            error="Validation timeout, assuming valid tier from key prefix"
        )

    except requests.exceptions.ConnectionError:
        logger.warning("Token validation connection error, using key-prefix tier")
        # Preserve tier from prefix on network error - don't downgrade
        result = ValidationResult(
            valid=True,
            tier=detected_tier,
            api_key=api_key,
            error="Validation unavailable, assuming valid tier from key prefix"
        )

    except Exception as e:
        logger.error(f"Token validation unexpected error: {e}")
        result = ValidationResult(
            valid=True,
            tier=detected_tier,
            api_key=api_key,
            error=f"Validation error: {str(e)}, assuming valid tier from key prefix"
        )

    _set_cache(api_key, result)
    return result


def clear_cache(api_key: Optional[str] = None) -> None:
    """Clear validation cache."""
    global _cache
    if api_key:
        _cache.pop(api_key, None)
    else:
        _cache.clear()


def get_tier_display_name(tier: Tier) -> str:
    """Get human-readable tier name."""
    names = {
        Tier.FREE: "免费版 (FREE)",
        Tier.BSC: "标准版 (BSC)",
        Tier.STD: "标准版 (STD)",
        Tier.PRO: "专业版 (Pro)",
        Tier.ENT: "企业版 (Enterprise)",
    }
    return names.get(tier, "未知")


if __name__ == "__main__":
    # Test the validator
    print("Testing token validation...")
    result = validate_token("RPT-FREE-test-key")
    print(f"Result: valid={result.valid}, tier={result.tier}, error={result.error}")
