# AI News Known - AI新闻智能采集与去重

融合多平台实时热榜与 AI 搜索的智能新闻采集工具，内置本地记忆去重机制，确保每次获取的都是全新资讯。

## 核心特性

- **多源融合**：聚合微博、知乎、百度、头条、华尔街见闻、澎湃等8大中文热榜
- **AI 专项搜索**：通过 web_search 补充 AI 领域专属新闻（Newsletter、开源、论文等）
- **本地记忆去重**：自动记录已推送新闻摘要，下次运行自动过滤历史内容
- **AI 关键词过滤**：精准识别 AI 相关新闻，过滤噪音

## 系统依赖

### Python 脚本（采集与去重）
仅使用 Python 标准库，无需额外安装：
- `urllib`：HTTP 请求
- `json`、`re`、`time`、`os`、`hashlib`：数据处理与本地记忆

### 截图工具（可选）
将 HTML 报告截图为高清 PNG 图片，依赖 Node.js + Playwright：
- 首次使用需安装：`cd ~/.workbuddy/skills/ai-news-known && npm install`
- 截图命令：`node scripts/screenshot_news.js <html_path> [output_dir]`

## 技能目录结构

```
ai-news-known/
├── SKILL.md                    # 本文件
├── package.json                # Playwright 依赖
├── scripts/
│   ├── fetch_ai_news.py        # 主脚本：多源采集 + AI过滤 + 本地去重
│   ├── format_ai_news.py       # 格式化输出
│   └── screenshot_news.js      # HTML → PNG 截图工具
├── data/
│   └── history.json            # 本地记忆文件（自动生成，记录已推送新闻）
└── references/
    └── sources.md              # AI新闻源推荐
```

## 工作流程

### 阶段一：本地记忆检查（自动执行）

脚本启动时自动加载 `data/history.json`，获取已推送新闻记录。

### 阶段二：多源并行采集

按以下优先级采集新闻：

#### 2.1 中文热榜平台（通过 API 直接采集）

```bash
# 支持的单源采集
python ai-news-known/scripts/fetch_ai_news.py weibo 20
python ai-news-known/scripts/fetch_ai_news.py zhihu 20
python ai-news-known/scripts/fetch_ai_news.py baidu 20
python ai-news-known/scripts/fetch_ai_news.py douyin 20
python ai-news-known/scripts/fetch_ai_news.py wallstreetcn 20
python ai-news-known/scripts/fetch_ai_news.py toutiao 20
python ai-news-known/scripts/fetch_ai_news.py jin10 20
python ai-news-known/scripts/fetch_ai_news.py thepaper 20
```

#### 2.2 全平台聚合采集（推荐）

```bash
# 从所有中文热榜采集，自动过滤AI相关新闻，自动去重
python ai-news-known/scripts/fetch_ai_news.py all 50
```

### 阶段三：AI 关键词过滤

对采集结果执行多级关键词匹配：

**高置信度词（匹配即收录）**：
`AI`, `人工智能`, `大模型`, `GPT`, `LLM`, `ChatGPT`, `Claude`, `Gemini`, `OpenAI`, `Anthropic`, `DeepSeek`, `机器学习`, `深度学习`, `神经网络`, `自动驾驶`, `机器人`, `Copilot`, `Agent`, `智能体`, `Sora`, `Midjourney`, `Stable Diffusion`, `Hugging Face`, `Transformer`, `LangChain`, `RAG`, `提示词`, `prompt`, `具身智能`, `AIGC`

**中置信度词（需上下文确认）**：
`芯片`, `算力`, `开源模型`, `训练`, `推理`, `微调`, `fine-tune`, `多模态`, `生成式`

### 阶段四：本地记忆去重

对每条新闻标题计算 SHA-256 哈希，与历史记录比对：
- **完全匹配**：跳过（已推送过）
- **相似度 > 70%**：跳过（同一事件的不同标题表述）
- **新内容**：收录并记录

历史数据存储在 `data/history.json`，格式如下：
```json
{
  "version": 1,
  "last_updated": "2026-04-14T23:30:00",
  "total_count": 156,
  "records": [
    {
      "hash": "a1b2c3...",
      "title": "新闻标题...",
      "source": "weibo",
      "timestamp": "2026-04-14T23:30:00"
    }
  ]
}
```

### 阶段五：AI 专项搜索补充（可选）

在使用本技能时，AI Agent 应额外通过 web_search 执行以下搜索，补充热榜未覆盖的 AI 专属新闻：

**推荐搜索词**（至少执行 4 次）：
```
"AI news today" OR "AI news this week"
"大模型" OR "AI agent" 最新发布
site:github.com trending AI
"AI breakthrough" OR "AI paper" [当前月份]
```

搜索结果中提取的新闻需同样经过关键词过滤和本地去重。

### 阶段六：格式化输出

```bash
# 将采集结果格式化输出（默认输出 HTML）
python ai-news-known/scripts/format_ai_news.py news.json
python ai-news-known/scripts/format_ai_news.py news.json html
python ai-news-known/scripts/format_ai_news.py news.json elegant
python ai-news-known/scripts/format_ai_news.py news.json compact
python ai-news-known/scripts/format_ai_news.py news.json markdown
python ai-news-known/scripts/format_ai_news.py news.json summary
```

**输出格式说明**：
- `html`（默认）：生成独立的 HTML 静态页面，深色主题，可直接在浏览器打开
- `elegant`：终端美化输出，带边框和 emoji
- `compact`：紧凑单行格式
- `markdown`：Markdown 格式
- `summary`：简短摘要

### 完整流程示例

```bash
# Step 1: 从所有热榜采集，AI过滤，去重
python ai-news-known/scripts/fetch_ai_news.py all 50

# Step 2: 格式化输出（默认 HTML）
python ai-news-known/scripts/format_ai_news.py /tmp/ai_news.json

# Step 3（仅用户要求时）: 截图
node ai-news-known/scripts/screenshot_news.js ai-news-2026-04-15.html screenshots/

# Step 4（仅用户要求时）: 小红书文案
# 由 AI Agent 根据新闻内容直接生成，无需额外脚本
```

## AI Agent 执行指南

当用户触发本技能时，按以下步骤执行：

### Step 1: 读取历史记忆
```bash
# 检查是否有历史数据
python ai-news-known/scripts/fetch_ai_news.py history
```

### Step 2: 多源采集 + AI 过滤 + 去重
```bash
python ai-news-known/scripts/fetch_ai_news.py all 50
```

### Step 3: AI 专项搜索补充（通过 web_search 工具）
使用 web_search 工具执行至少 4 次 AI 专属搜索，将结果补充到新闻列表中。

### Step 4: 汇总输出
- 将热榜采集结果与搜索补充结果合并
- 按来源分类，按热度排序
- 输出 **10-20 条** 高价值 AI 新闻
- 每条附带简短解读（1-2 句话）

### Step 5: 生成 HTML 文件（默认执行）
- 生成深色主题 HTML 静态页面
- 保存到 `ai-news-YYYY-MM-DD.html`
- 使用 `preview_url` 工具展示给用户

### Step 6: 截图输出（⚠️ 默认不执行）
仅当用户明确说"截图"、"生成图片"、"PNG"、"图片版"等关键词时才执行。

### Step 7: 小红书文案（⚠️ 默认不执行）
仅当用户明确说"小红书"、"文案"、"话题标签"、"xhs"等关键词时才执行。
输出：备选标题（3条）+ 正文文案（结构化摘要）+ 热门话题标签（15-20个）。

### Step 6: 截图输出（仅在用户明确要求时执行）
> ⚠️ **默认不执行**，仅当用户明确说"截图"、"生成图片"、"PNG"等时才执行。

```bash
# 首次使用，安装 Playwright 依赖（只需一次）
cd ~/.workbuddy/skills/ai-news-known && npm install

# 截图（自动生成4种版本）
node scripts/screenshot_news.js ai-news-2026-04-15.html screenshots/
```

### Step 7: 小红书文案（仅在用户明确要求时执行）
> ⚠️ **默认不执行**，仅当用户明确说"小红书"、"文案"、"话题标签"等时才执行。

输出内容包含：
- **备选标题**（3条，风格偏爆款）
- **正文文案**（结构化摘要，带 emoji 分点）
- **热门话题标签**（15-20个 #标签）

## 输出格式

默认输出 **HTML 静态页面**，可直接用浏览器打开：

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <title>AI 新闻速递 2026-04-15</title>
    <style>
        /* 深色主题配色 */
        body { background: linear-gradient(135deg, #1a1a2e, #16213e); }
        .stat-card { background: rgba(255,255,255,0.05); }
        .news-item:hover { background: rgba(255,255,255,0.06); }
    </style>
</head>
<body>
    <div class="header">
        <h1>🤖 AI 新闻速递</h1>
        <div class="date">2026-04-15 17:00</div>
    </div>
    <div class="stats">
        <div class="stat-card">
            <div class="value">255</div>
            <div class="label">总采集</div>
        </div>
        <!-- ... 更多统计卡片 ... -->
    </div>
    <div class="source-section">
        <div class="source-title">📍 微博热搜 (5 条)</div>
        <div class="news-list">
            <div class="news-item">
                <div class="title">1. <a href="...">新闻标题</a></div>
                <div class="meta"><span class="keyword">AI</span></div>
            </div>
        </div>
    </div>
</body>
</html>
```

## 记忆管理

```bash
# 查看历史统计
python ai-news-known/scripts/fetch_ai_news.py stats

# 清理超过30天的历史记录（自动保留最近500条）
python ai-news-known/scripts/fetch_ai_news.py cleanup
```

## 注意事项

- 本技能独立运行，不调用 ai-news-collectors 或 newsnow-reader
- 本地记忆文件存储在技能目录下 `data/history.json`
- 历史记录自动管理，超过 500 条或 30 天的记录会被清理
- 关键词过滤为中文优先，中英文关键词并重
- 如所有平台采集均失败，回退到纯 web_search 模式
