#!/usr/bin/env python3
"""
AI News Known - Format AI news into elegant readable output.

Usage:
    python format_ai_news.py <json_file> [style]
    Styles: elegant (default), compact, markdown, summary
"""
import json
import sys
from datetime import datetime


def load_news(path: str) -> dict:
    """Load news JSON from file or stdin."""
    if path == '-':
        return json.load(sys.stdin)
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def format_elegant(data: dict) -> str:
    """Format news with elegant borders and emojis."""
    meta = data.get("meta", {})
    news = data.get("news", [])

    lines = []
    lines.append("╔" + "═" * 60 + "╗")
    lines.append("║" + " " * 14 + "🤖 AI 新闻速递" + " " * 28 + "║")
    lines.append("╠" + "═" * 60 + "╣")

    now = datetime.now().strftime('%Y-%m-%d %H:%M')
    lines.append(f"║  📅 {now}" + " " * (60 - len(f"║  📅 {now}") - 1) + "║")
    lines.append("╚" + "═" * 60 + "╝")
    lines.append("")

    # Stats section
    total = meta.get("total_fetched", 0)
    ai_out = meta.get("ai_filtered_out", 0)
    dedup_out = meta.get("dedup_filtered_out", 0)
    final = meta.get("final_count", len(news))
    hist = meta.get("history_total", 0)

    lines.append("📊 采集统计")
    lines.append(f"   总采集: {total} 条 | AI过滤: {ai_out} 条 | 去重过滤: {dedup_out} 条")
    lines.append(f"   历史记录: {hist} 条 | 最终输出: {final} 条")
    lines.append("")

    if not news:
        lines.append("   😴 暂无新的 AI 新闻")
        return "\n".join(lines)

    lines.append("─" * 60)
    lines.append("")

    # Group by source
    source_groups = {}
    for item in news:
        src = item.get("source", "其他")
        if src not in source_groups:
            source_groups[src] = []
        source_groups[src].append(item)

    # Sort sources by count (descending)
    sorted_sources = sorted(source_groups.items(), key=lambda x: len(x[1]), reverse=True)

    num = 0
    for source_name, items in sorted_sources:
        lines.append(f"📍 {source_name} ({len(items)} 条)")
        lines.append("")

        for item in items:
            num += 1
            title = item.get("title", "无标题")
            url = item.get("url", "")
            keyword = item.get("ai_keyword", "")

            # Number emoji for top 10
            if num <= 10:
                num_emoji = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣",
                             "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"][num - 1]
            else:
                num_emoji = f"{num}."

            kw_tag = f"  [{keyword}]" if keyword else ""
            lines.append(f"{num_emoji} {title}{kw_tag}")
            if url:
                lines.append(f"   🔗 {url}")
            lines.append("")

    return "\n".join(lines)


def format_compact(data: dict) -> str:
    """Format news in compact one-line-per-item style."""
    news = data.get("news", [])
    meta = data.get("meta", {})

    lines = []
    now = datetime.now().strftime('%Y-%m-%d %H:%M')
    final = meta.get("final_count", len(news))
    dedup_out = meta.get("dedup_filtered_out", 0)

    lines.append(f"🤖 AI News ({now}) | {final} new, {dedup_out} deduped")
    lines.append("")

    for i, item in enumerate(news, 1):
        title = item.get("title", "")
        source = item.get("source", "")
        url = item.get("url", "")
        lines.append(f"{i:2d}. [{source}] {title}")
        if url:
            lines.append(f"    {url}")

    return "\n".join(lines)


def format_markdown(data: dict) -> str:
    """Format news as Markdown."""
    news = data.get("news", [])
    meta = data.get("meta", {})
    now = datetime.now().strftime('%Y-%m-%d %H:%M')

    lines = []
    lines.append(f"## 🤖 AI 新闻速递（{now}）")
    lines.append("")

    total = meta.get("total_fetched", 0)
    ai_out = meta.get("ai_filtered_out", 0)
    dedup_out = meta.get("dedup_filtered_out", 0)
    final = meta.get("final_count", len(news))

    lines.append("### 📊 采集统计")
    lines.append("")
    lines.append(f"| 指标 | 数值 |")
    lines.append(f"|------|------|")
    lines.append(f"| 总采集 | {total} |")
    lines.append(f"| AI 过滤 | {ai_out} |")
    lines.append(f"| 去重过滤 | {dedup_out} |")
    lines.append(f"| 最终输出 | {final} |")
    lines.append("")

    if not news:
        lines.append("> 暂无新的 AI 新闻")
        return "\n".join(lines)

    lines.append("### 📰 新闻列表")
    lines.append("")

    # Group by source
    source_groups = {}
    for item in news:
        src = item.get("source", "其他")
        if src not in source_groups:
            source_groups[src] = []
        source_groups[src].append(item)

    sorted_sources = sorted(source_groups.items(), key=lambda x: len(x[1]), reverse=True)
    num = 0

    for source_name, items in sorted_sources:
        lines.append(f"#### 📍 {source_name}")
        lines.append("")
        for item in items:
            num += 1
            title = item.get("title", "无标题")
            url = item.get("url", "")
            keyword = item.get("ai_keyword", "")
            kw_tag = f" `{keyword}`" if keyword else ""

            if url:
                lines.append(f"**{num}. [{title}]({url})**{kw_tag}")
            else:
                lines.append(f"**{num}. {title}**{kw_tag}")
            lines.append("")

    lines.append("---")
    lines.append(f"*更新时间: {now} | 采集量: {total} → 去重后: {final}*")

    return "\n".join(lines)


def format_html(data: dict) -> str:
    """Format news as a standalone HTML page."""
    news = data.get("news", [])
    meta = data.get("meta", {})
    now = datetime.now().strftime('%Y-%m-%d %H:%M')

    total = meta.get("total_fetched", 0)
    ai_out = meta.get("ai_filtered_out", 0)
    dedup_out = meta.get("dedup_filtered_out", 0)
    final = meta.get("final_count", len(news))

    # Group by source
    source_groups = {}
    for item in news:
        src = item.get("source", "其他")
        if src not in source_groups:
            source_groups[src] = []
        source_groups[src].append(item)
    sorted_sources = sorted(source_groups.items(), key=lambda x: len(x[1]), reverse=True)

    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI 新闻速递 {now}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            padding: 40px 20px;
            color: #e0e0e0;
        }}
        .container {{ max-width: 900px; margin: 0 auto; }}
        .header {{
            text-align: center;
            margin-bottom: 40px;
        }}
        .header h1 {{
            font-size: 2.5em;
            background: linear-gradient(90deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
        }}
        .header .date {{
            color: #888;
            font-size: 1.1em;
        }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 40px;
        }}
        .stat-card {{
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
        }}
        .stat-card .value {{
            font-size: 2em;
            font-weight: bold;
            color: #00d4ff;
        }}
        .stat-card .label {{
            color: #888;
            margin-top: 5px;
        }}
        .source-section {{
            margin-bottom: 30px;
        }}
        .source-title {{
            display: inline-block;
            background: rgba(124, 58, 237, 0.3);
            border: 1px solid #7c3aed;
            border-radius: 20px;
            padding: 8px 20px;
            margin-bottom: 20px;
            font-size: 1.1em;
        }}
        .news-list {{
            display: flex;
            flex-direction: column;
            gap: 15px;
        }}
        .news-item {{
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 12px;
            padding: 20px;
            transition: all 0.3s ease;
        }}
        .news-item:hover {{
            background: rgba(255,255,255,0.06);
            border-color: rgba(0,212,255,0.3);
            transform: translateX(5px);
        }}
        .news-item .title {{
            font-size: 1.1em;
            color: #fff;
            margin-bottom: 10px;
            line-height: 1.5;
        }}
        .news-item .title a {{
            color: #fff;
            text-decoration: none;
        }}
        .news-item .title a:hover {{
            color: #00d4ff;
        }}
        .news-item .meta {{
            display: flex;
            gap: 15px;
            font-size: 0.85em;
            color: #666;
        }}
        .news-item .keyword {{
            background: rgba(0,212,255,0.2);
            color: #00d4ff;
            padding: 2px 10px;
            border-radius: 10px;
        }}
        .empty {{ text-align: center; padding: 60px; color: #666; }}
        .footer {{
            text-align: center;
            margin-top: 50px;
            padding-top: 30px;
            border-top: 1px solid rgba(255,255,255,0.1);
            color: #666;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 AI 新闻速递</h1>
            <div class="date">{now}</div>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <div class="value">{total}</div>
                <div class="label">总采集</div>
            </div>
            <div class="stat-card">
                <div class="value">{ai_out}</div>
                <div class="label">AI 过滤</div>
            </div>
            <div class="stat-card">
                <div class="value">{dedup_out}</div>
                <div class="label">去重过滤</div>
            </div>
            <div class="stat-card">
                <div class="value">{final}</div>
                <div class="label">最终输出</div>
            </div>
        </div>
'''

    if not news:
        html += '<div class="empty">😴 暂无新的 AI 新闻</div>'
    else:
        num = 0
        for source_name, items in sorted_sources:
            html += f'''
        <div class="source-section">
            <div class="source-title">📍 {source_name} ({len(items)} 条)</div>
            <div class="news-list">
'''
            for item in items:
                num += 1
                title = item.get("title", "无标题")
                url = item.get("url", "")
                keyword = item.get("ai_keyword", "")
                
                if url:
                    title_html = f'<a href="{url}" target="_blank">{title}</a>'
                else:
                    title_html = title
                
                keyword_html = f'<span class="keyword">{keyword}</span>' if keyword else ''
                
                html += f'''
                <div class="news-item">
                    <div class="title">{num}. {title_html}</div>
                    <div class="meta">
                        {keyword_html}
                    </div>
                </div>
'''

            html += '            </div>\n        </div>\n'

    html += f'''
        <div class="footer">
            更新时间: {now} | 采集量: {total} → 去重后: {final}
        </div>
    </div>
</body>
</html>'''

    return html


def format_summary(data: dict) -> str:
    """Generate a brief summary of top AI news."""
    news = data.get("news", [])
    meta = data.get("meta", {})
    now = datetime.now().strftime('%Y-%m-%d %H:%M')

    if not news:
        return f"🤖 AI 新闻速递（{now}）\n\n😴 暂无新的 AI 新闻"

    top = news[:10]
    lines = []
    lines.append(f"🤖 AI 新闻速递（{now}）")
    lines.append(f"📰 共 {meta.get('final_count', len(news))} 条新资讯")
    lines.append("")

    for i, item in enumerate(top, 1):
        title = item.get("title", "")
        source = item.get("source", "")
        lines.append(f"{i}. {title}")
        lines.append(f"   来源: {source}")

    if len(news) > 10:
        lines.append(f"\n... 还有 {len(news) - 10} 条新闻")

    return "\n".join(lines)


def main():
    if len(sys.argv) < 2:
        print("Usage: python format_ai_news.py <json_file> [style]", file=sys.stderr)
        print("Styles: html (default), elegant, compact, markdown, summary", file=sys.stderr)
        sys.exit(1)

    json_path = sys.argv[1]
    style = sys.argv[2] if len(sys.argv) > 2 else "html"

    try:
        data = load_news(json_path)
    except FileNotFoundError:
        print(f"Error: File not found: {json_path}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    formatters = {
        "html": format_html,
        "elegant": format_elegant,
        "compact": format_compact,
        "markdown": format_markdown,
        "summary": format_summary,
    }

    formatter = formatters.get(style, format_html)
    print(formatter(data))


if __name__ == "__main__":
    main()
