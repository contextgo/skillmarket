#!/usr/bin/env python3
"""
AI News Known - Multi-source AI news collector with local memory deduplication.

Integrates hot news fetching from 8 Chinese platforms (Weibo, Zhihu, Baidu, etc.)
with AI keyword filtering and local history-based deduplication.

Usage:
    python fetch_ai_news.py <source> [limit]
    python fetch_ai_news.py all [limit]        # Fetch from all sources, filter AI news
    python fetch_ai_news.py history             # Show history stats
    python fetch_ai_news.py stats               # Show memory statistics
    python fetch_ai_news.py cleanup             # Clean old records (>30 days or >500)
"""
import json
import sys
import os
import re
import hashlib
import random
import string
import time
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Set, Tuple
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

# ============================================================================
# Configuration
# ============================================================================

# Directory paths - resolve relative to this script
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
DATA_DIR = os.path.join(SKILL_DIR, "data")
HISTORY_FILE = os.path.join(DATA_DIR, "history.json")

# Maximum history records to keep
MAX_HISTORY_RECORDS = 500
# Maximum days to keep history
MAX_HISTORY_DAYS = 30

# AI keyword dictionaries
HIGH_CONFIDENCE_KEYWORDS = [
    "AI", "人工智能", "大模型", "GPT", "LLM", "ChatGPT", "Claude",
    "Gemini", "OpenAI", "Anthropic", "DeepSeek", "Deep seek",
    "机器学习", "深度学习", "神经网络", "自动驾驶", "机器人",
    "Copilot", "Agent", "智能体", "Sora", "Midjourney",
    "Stable Diffusion", "Hugging Face", "Transformer", "LangChain",
    "RAG", "提示词", "prompt", "具身智能", "AIGC", "AGI",
    "通义", "文心", "讯飞", "智谱", "百川", "月之暗面", "Kimi",
    "Samantha", "GLM", "Qwen", "Llama", "Mistral", "Cohere",
    "AI芯片", "AI芯片", "GPU", "英伟达", "NVIDIA",
    "Turing", "图灵", "Chatbot", "聊天机器人", "AI搜索",
    "AI搜索", "Perplexity", "Cursor", "Devin", "AI编程",
    "代码生成", "AI生成", "AI绘画", "AI音乐", "AI视频",
]

MEDIUM_CONFIDENCE_KEYWORDS = [
    "芯片", "算力", "开源模型", "训练", "推理", "微调",
    "fine-tune", "fine tune", "多模态", "生成式", "生成AI",
    "语义理解", "自然语言", "计算机视觉", "图像识别",
    "语音识别", "文本生成", "知识图谱", "强化学习",
    "迁移学习", "联邦学习", "边缘计算", "量子计算",
    "自动驾驶", "无人驾驶", "脑机接口", "元宇宙",
    "Web3", "区块链", "数字孪生",
]


# ============================================================================
# HTTP Utility
# ============================================================================

def http_request(url, headers=None, follow_redirects=True, timeout=30):
    """Make HTTP request using urllib with proper error handling."""
    try:
        req = Request(url)
        req.add_header(
            'User-Agent',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
            'AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/130.0.0.0 Safari/537.36'
        )
        if headers:
            for key, value in headers.items():
                req.add_header(key, value)
        response = urlopen(req, timeout=timeout)
        content = response.read().decode('utf-8', errors='ignore')
        if follow_redirects and response.status in [301, 302, 303, 307, 308]:
            redirect_url = response.getheader('Location')
            if redirect_url:
                return http_request(redirect_url, headers, False, timeout)
        return content
    except (URLError, HTTPError) as e:
        print(f"HTTP error ({url}): {e}", file=sys.stderr)
        return None


# ============================================================================
# Platform Fetchers (based on newsnow-style API calls)
# ============================================================================

def generate_random_weibo_cookie():
    """Generate a random Weibo-like cookie to avoid anti-scraping."""
    random_part = ''.join(random.choices(string.ascii_letters + string.digits, k=40))
    return f"SUB=_2AkM{random_part}"


def fetch_weibo_hot(limit=20):
    """Fetch Weibo hot search."""
    try:
        url = "https://s.weibo.com/top/summary?cate=realtimehot"
        cookie = generate_random_weibo_cookie()
        headers = {'Cookie': cookie, 'Referer': url}
        html = http_request(url, headers, timeout=30)
        if not html or len(html) < 100:
            return []
        pattern = r'<td[^>]*class="td-02"[^>]*>.*?<a[^>]*href="([^"]+)"[^>]*>([^<]+)</a>'
        matches = re.findall(pattern, html, re.DOTALL)
        items = []
        for href, title in matches[:limit]:
            title = title.strip()
            if title and 'javascript:void(0);' not in href:
                full_url = f"https://s.weibo.com{href}" if not href.startswith('http') else href
                items.append({
                    "title": title,
                    "url": full_url,
                    "source": "微博热搜",
                    "source_key": "weibo"
                })
        return items
    except Exception as e:
        print(f"Weibo fetch error: {e}", file=sys.stderr)
        return []


def fetch_zhihu_hot(limit=20):
    """Fetch Zhihu hot list."""
    try:
        url = "https://www.zhihu.com/api/v3/feed/topstory/hot-list-web?limit=20&desktop=true"
        content = http_request(url, timeout=30)
        if not content:
            return []
        data = json.loads(content)
        items = []
        for item in data.get('data', [])[:limit]:
            try:
                target = item.get('target', {})
                title_area = target.get('title_area', {})
                metrics_area = target.get('metrics_area', {})
                link = target.get('link', {})
                title = title_area.get('text', '')
                item_url = link.get('url', '')
                info = metrics_area.get('text', '')
                if title:
                    items.append({
                        "title": title,
                        "url": item_url,
                        "source": f"知乎热榜 | {info}" if info else "知乎热榜",
                        "source_key": "zhihu"
                    })
            except Exception:
                continue
        return items
    except Exception as e:
        print(f"Zhihu fetch error: {e}", file=sys.stderr)
        return []


def fetch_baidu_hot(limit=20):
    """Fetch Baidu hot search."""
    try:
        url = "https://top.baidu.com/board?tab=realtime"
        html = http_request(url, timeout=30)
        if not html:
            return []
        pattern = r'<!--s-data:(.*?)-->'
        match = re.search(pattern, html, re.DOTALL)
        if not match:
            return []
        data = json.loads(match.group(1))
        cards = data.get('data', {}).get('cards', [])
        if not cards:
            return []
        items = []
        content = cards[0].get('content', [])
        for item in content[:limit]:
            try:
                if item.get('isTop'):
                    continue
                word = item.get('word', '')
                raw_url = item.get('rawUrl', '')
                desc = item.get('desc', '')
                if word and raw_url:
                    items.append({
                        "title": word,
                        "url": raw_url,
                        "source": f"百度热搜 | {desc}" if desc else "百度热搜",
                        "source_key": "baidu"
                    })
            except Exception:
                continue
        return items
    except Exception as e:
        print(f"Baidu fetch error: {e}", file=sys.stderr)
        return []


def fetch_douyin_hot(limit=20):
    """Fetch Douyin hot search."""
    try:
        url = "https://www.douyin.com/aweme/v1/web/hot/search/list/?device_platform=webapp&aid=6383&channel=channel_pc_web&detail_list=1"
        # Get session cookie
        login_url = "https://login.douyin.com/"
        login_req = Request(login_url)
        login_req.add_header(
            'User-Agent',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
            'AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/130.0.0.0 Safari/537.36'
        )
        try:
            login_response = urlopen(login_req, timeout=30)
        except (URLError, HTTPError):
            return []
        cookies = []
        for cookie in login_response.headers.get_all('Set-Cookie') or []:
            cookies.append(cookie.split(';')[0])
        cookie_str = '; '.join(cookies)
        content = http_request(url, {'Cookie': cookie_str}, timeout=30)
        if not content:
            return []
        data = json.loads(content)
        items = []
        for item in data.get('data', {}).get('word_list', [])[:limit]:
            try:
                sentence_id = item.get('sentence_id', '')
                word = item.get('word', '')
                hot_value = item.get('hot_value', '')
                if word and sentence_id:
                    items.append({
                        "title": word,
                        "url": f"https://www.douyin.com/hot/{sentence_id}",
                        "source": f"抖音热榜 | 热度: {hot_value}" if hot_value else "抖音热榜",
                        "source_key": "douyin"
                    })
            except Exception:
                continue
        return items
    except Exception as e:
        print(f"Douyin fetch error: {e}", file=sys.stderr)
        return []


def fetch_wallstreetcn_hot(limit=20):
    """Fetch Wallstreetcn hot news."""
    try:
        url = "https://api-one.wallstcn.com/apiv1/content/articles/hot?period=all"
        content = http_request(url, timeout=30)
        if not content:
            return []
        data = json.loads(content)
        items = []
        for item in data.get('data', {}).get('day_items', [])[:limit]:
            try:
                title = item.get('title', '')
                uri = item.get('uri', '')
                if title and uri:
                    items.append({
                        "title": title,
                        "url": uri,
                        "source": "华尔街见闻",
                        "source_key": "wallstreetcn"
                    })
            except Exception:
                continue
        return items
    except Exception as e:
        print(f"Wallstreetcn fetch error: {e}", file=sys.stderr)
        return []


def fetch_toutiao_hot(limit=20):
    """Fetch Toutiao hot news."""
    try:
        url = "https://www.toutiao.com/hot-event/hot-board/?origin=toutiao_pc"
        content = http_request(url, timeout=30)
        if not content:
            return []
        data = json.loads(content)
        items = []
        for item in data.get('data', [])[:limit]:
            try:
                cluster_id = item.get('ClusterIdStr', '')
                title = item.get('Title', '')
                hot_value = item.get('HotValue', '')
                if title and cluster_id:
                    items.append({
                        "title": title,
                        "url": f"https://www.toutiao.com/trending/{cluster_id}/",
                        "source": f"今日头条 | 热度: {hot_value}" if hot_value else "今日头条",
                        "source_key": "toutiao"
                    })
            except Exception:
                continue
        return items
    except Exception as e:
        print(f"Toutiao fetch error: {e}", file=sys.stderr)
        return []


def fetch_jin10_news(limit=20):
    """Fetch Jin10 flash news."""
    try:
        timestamp = int(time.time() * 1000)
        url = f"https://www.jin10.com/flash_newest.js?t={timestamp}"
        raw_data = http_request(url, timeout=30)
        if not raw_data:
            return []
        json_str = re.sub(r'^var\s+newest\s*=\s*', '', raw_data)
        json_str = re.sub(r';*$', '', json_str).strip()
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            return []
        items = []
        for item in data[:limit]:
            try:
                data_obj = item.get('data', {})
                if not (data_obj.get('title') or data_obj.get('content')):
                    continue
                channels = item.get('channel', [])
                if isinstance(channels, list) and 5 in channels:
                    continue
                item_id = item.get('id', '')
                title = data_obj.get('title', data_obj.get('content', ''))
                important = item.get('important', 0)
                # Remove HTML tags
                title = re.sub(r'<[^>]+>', '', title)
                if title:
                    info_text = "✰ 重要" if important else ""
                    items.append({
                        "title": title,
                        "url": f"https://flash.jin10.com/detail/{item_id}",
                        "source": f"金十数据 | {info_text}" if info_text else "金十数据",
                        "source_key": "jin10"
                    })
            except Exception:
                continue
        return items
    except Exception as e:
        print(f"Jin10 fetch error: {e}", file=sys.stderr)
        return []


def fetch_thepaper_hot(limit=20):
    """Fetch The Paper hot news."""
    try:
        url = "https://cache.thepaper.cn/contentapi/wwwIndex/rightSidebar"
        content = http_request(url, timeout=30)
        if not content:
            return []
        data = json.loads(content)
        items = []
        for item in data.get('data', {}).get('hotNews', [])[:limit]:
            try:
                cont_id = item.get('contId', '')
                name = item.get('name', '')
                if name and cont_id:
                    items.append({
                        "title": name,
                        "url": f"https://www.thepaper.cn/newsDetail_forward_{cont_id}",
                        "source": "澎湃新闻",
                        "source_key": "thepaper"
                    })
            except Exception:
                continue
        return items
    except Exception as e:
        print(f"ThePaper fetch error: {e}", file=sys.stderr)
        return []


# ============================================================================
# Source Registry
# ============================================================================

FETCHERS = {
    "weibo": ("微博热搜", fetch_weibo_hot),
    "zhihu": ("知乎热榜", fetch_zhihu_hot),
    "baidu": ("百度热搜", fetch_baidu_hot),
    "douyin": ("抖音热榜", fetch_douyin_hot),
    "wallstreetcn": ("华尔街见闻", fetch_wallstreetcn_hot),
    "toutiao": ("今日头条", fetch_toutiao_hot),
    "jin10": ("金十数据", fetch_jin10_news),
    "thepaper": ("澎湃新闻", fetch_thepaper_hot),
}


# ============================================================================
# Local Memory (History) Management
# ============================================================================

def _ensure_data_dir():
    """Ensure the data directory exists."""
    os.makedirs(DATA_DIR, exist_ok=True)


def _load_history() -> dict:
    """Load history from local JSON file."""
    _ensure_data_dir()
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    # Return empty history structure
    return {
        "version": 1,
        "last_updated": "",
        "total_count": 0,
        "records": []
    }


def _save_history(history: dict):
    """Save history to local JSON file."""
    _ensure_data_dir()
    history["last_updated"] = datetime.now().isoformat()
    history["total_count"] = len(history["records"])
    with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
        json.dump(history, f, ensure_ascii=False, indent=2)


def compute_title_hash(title: str) -> str:
    """Compute SHA-256 hash of a news title for deduplication."""
    # Normalize: strip whitespace, lowercase for English
    normalized = title.strip().lower()
    return hashlib.sha256(normalized.encode('utf-8')).hexdigest()[:16]


def _compute_similarity_hash(title: str) -> str:
    """
    Compute a simplified similarity signature for fuzzy dedup.
    Removes common stop words and short tokens, keeping core meaning.
    """
    # Remove punctuation and common noise
    cleaned = re.sub(r'[^\w\u4e00-\u9fff]', '', title)
    # Extract Chinese characters and English words >= 2 chars
    chinese_chars = re.findall(r'[\u4e00-\u9fff]', cleaned)
    english_words = [w.lower() for w in re.findall(r'[a-zA-Z]{2,}', cleaned) if len(w) >= 2]
    # Combine and hash
    core = ''.join(chinese_chars) + ''.join(sorted(english_words))
    if not core:
        return compute_title_hash(title)
    return hashlib.sha256(core.encode('utf-8')).hexdigest()[:12]


def is_duplicate(title: str, history: dict) -> Tuple[bool, str]:
    """
    Check if a news title is duplicate based on history.
    Returns (is_duplicate, reason).
    """
    exact_hash = compute_title_hash(title)
    similarity_hash = _compute_similarity_hash(title)

    for record in history.get("records", []):
        # Exact match
        if record.get("hash") == exact_hash:
            return True, "exact_match"
        # Similarity match (same core meaning, different wording)
        if record.get("sim_hash") == similarity_hash:
            return True, "similar_match"

    return False, "new"


def add_to_history(title: str, source_key: str, history: dict):
    """Add a news item to history."""
    history["records"].append({
        "hash": compute_title_hash(title),
        "sim_hash": _compute_similarity_hash(title),
        "title": title,
        "source": source_key,
        "timestamp": datetime.now().isoformat()
    })


def cleanup_history(history: dict) -> dict:
    """
    Clean up old history records.
    Keeps at most MAX_HISTORY_RECORDS, and removes records older than MAX_HISTORY_DAYS.
    """
    now = datetime.now()
    cutoff = now - timedelta(days=MAX_HISTORY_DAYS)

    # Filter by date
    filtered = [
        r for r in history.get("records", [])
        if datetime.fromisoformat(r["timestamp"]) > cutoff
    ]

    # If still too many, keep most recent
    if len(filtered) > MAX_HISTORY_RECORDS:
        filtered.sort(key=lambda r: r["timestamp"], reverse=True)
        filtered = filtered[:MAX_HISTORY_RECORDS]

    removed_count = len(history.get("records", [])) - len(filtered)
    history["records"] = filtered
    return removed_count


# ============================================================================
# AI Keyword Filter
# ============================================================================

def is_ai_related(title: str) -> Tuple[bool, str]:
    """
    Check if a news title is AI-related.
    Returns (is_related, matched_keyword).
    """
    title_lower = title.lower()

    # Check high confidence keywords first
    for kw in HIGH_CONFIDENCE_KEYWORDS:
        if kw.lower() in title_lower:
            return True, kw

    # Check medium confidence keywords (need at least one match)
    for kw in MEDIUM_CONFIDENCE_KEYWORDS:
        if kw.lower() in title_lower:
            return True, kw

    return False, ""


# ============================================================================
# Main Pipeline
# ============================================================================

def fetch_all_sources(limit_per_source=20) -> List[dict]:
    """Fetch news from all available sources."""
    all_items = []
    source_stats = {}

    for source_key, (source_name, fetcher) in FETCHERS.items():
        try:
            items = fetcher(limit_per_source)
            all_items.extend(items)
            source_stats[source_key] = {"name": source_name, "count": len(items), "status": "ok"}
        except Exception as e:
            source_stats[source_key] = {"name": source_name, "count": 0, "status": f"error: {e}"}
            print(f"Failed to fetch {source_name}: {e}", file=sys.stderr)

    # Add stats to output
    print(f"[DEBUG] Source stats: {json.dumps(source_stats, ensure_ascii=False)}", file=sys.stderr)
    return all_items


def filter_and_deduplicate(
    items: List[dict],
    history: dict,
    require_ai_filter: bool = True
) -> Tuple[List[dict], int, int, int]:
    """
    Filter AI-related news and deduplicate against history.
    Returns (filtered_items, ai_filtered_count, dedup_count, new_count).
    """
    results = []
    ai_filtered = 0
    dedup_count = 0

    for item in items:
        title = item.get("title", "")

        # AI keyword filter
        if require_ai_filter:
            is_ai, matched_kw = is_ai_related(title)
            if not is_ai:
                ai_filtered += 1
                continue

        # Deduplication against local history
        dup, reason = is_duplicate(title, history)
        if dup:
            dedup_count += 1
            continue

        # Add enriched metadata
        item["ai_keyword"] = matched_kw if require_ai_filter else ""
        item["fetched_at"] = datetime.now().isoformat()
        results.append(item)

        # Record in history
        add_to_history(title, item.get("source_key", "unknown"), history)

    return results, ai_filtered, dedup_count, len(results)


def main():
    if len(sys.argv) < 2:
        print("Usage: python fetch_ai_news.py <source|all|history|stats|cleanup> [limit]", file=sys.stderr)
        print("Sources: " + ", ".join(FETCHERS.keys()), file=sys.stderr)
        sys.exit(1)

    command = sys.argv[1].lower()

    # --- Special commands ---
    if command == "history":
        history = _load_history()
        records = history.get("records", [])
        print(f"Last updated: {history.get('last_updated', 'N/A')}")
        print(f"Total records: {len(records)}")
        if records:
            print("\nLast 10 records:")
            for r in records[-10:]:
                print(f"  - [{r['source']}] {r['title']}")
        return

    if command == "stats":
        history = _load_history()
        records = history.get("records", [])
        print(json.dumps({
            "total_records": len(records),
            "last_updated": history.get("last_updated", "N/A"),
            "max_capacity": MAX_HISTORY_RECORDS,
            "max_days": MAX_HISTORY_DAYS,
            "usage_pct": round(len(records) / MAX_HISTORY_RECORDS * 100, 1)
        }, ensure_ascii=False, indent=2))
        return

    if command == "cleanup":
        history = _load_history()
        removed = cleanup_history(history)
        _save_history(history)
        print(f"Cleanup complete: removed {removed} old records")
        print(f"Remaining records: {len(history['records'])}")
        return

    # --- Source-specific or all ---
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    history = _load_history()

    if command == "all":
        # Fetch from all sources, apply AI filter, deduplicate
        all_items = fetch_all_sources(limit)
        results, ai_filtered, dedup_count, new_count = filter_and_deduplicate(
            all_items, history, require_ai_filter=True
        )
        _save_history(history)

        output = {
            "meta": {
                "total_fetched": len(all_items),
                "ai_filtered_out": ai_filtered,
                "dedup_filtered_out": dedup_count,
                "final_count": new_count,
                "history_total": len(history["records"]),
                "fetched_at": datetime.now().isoformat()
            },
            "news": results
        }
    elif command in FETCHERS:
        # Single source fetch
        source_name, fetcher = FETCHERS[command]
        items = fetcher(limit)
        # For single source, still apply dedup but skip AI filter
        results, _, dedup_count, new_count = filter_and_deduplicate(
            items, history, require_ai_filter=False
        )
        _save_history(history)

        output = {
            "meta": {
                "source": command,
                "source_name": source_name,
                "total_fetched": len(items),
                "dedup_filtered_out": dedup_count,
                "final_count": new_count,
                "history_total": len(history["records"]),
                "fetched_at": datetime.now().isoformat()
            },
            "news": results
        }
    else:
        print(f"Unknown source: {command}", file=sys.stderr)
        print(f"Available sources: all, " + ", ".join(FETCHERS.keys()), file=sys.stderr)
        sys.exit(1)

    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
