/**
 * AI News Known - HTML 报告截图工具
 * 将 ai-daily-YYYY-MM-DD.html 截图为高清 PNG 图片
 * 
 * 依赖：playwright（npm install playwright）
 * 用法：node screenshot_news.js <html_path> [output_dir]
 */

const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

// ── 配置 ──────────────────────────────────────────
const CONFIG = {
  // 桌面端截图（完整报告）
  desktop: {
    width: 1280,
    height: 960,
    deviceScaleFactor: 2,  // 2x 高清
    fullPage: true,
    suffix: '_full'
  },
  // 社交分享版截图（3:4 竖版卡片风格）
  social: {
    width: 480,
    height: 900,
    deviceScaleFactor: 2,
    fullPage: true,
    suffix: '_social'
  },
  // 封面版（只截 header + stats 区域）
  cover: {
    width: 1080,
    height: 1080,
    deviceScaleFactor: 2,
    fullPage: false,
    selector: '.header, .stats, .breaking-banner',
    suffix: '_cover'
  }
};

async function screenshotHtml(htmlPath, outputDir) {
  // 参数校验
  if (!htmlPath) {
    console.error('❌ 用法: node screenshot_news.js <html_path> [output_dir]');
    console.error('   示例: node screenshot_news.js ai-daily-2026-04-15.html screenshots/');
    process.exit(1);
  }

  // 规范化路径
  const absoluteHtml = path.resolve(htmlPath);
  if (!fs.existsSync(absoluteHtml)) {
    console.error(`❌ 文件不存在: ${absoluteHtml}`);
    process.exit(1);
  }

  // 输出目录
  const outDir = outputDir
    ? path.resolve(outputDir)
    : path.dirname(absoluteHtml);
  fs.mkdirSync(outDir, { recursive: true });

  // 文件 URL
  const fileUrl = 'file:///' + absoluteHtml.replace(/\\/g, '/');

  // 基础文件名（不含扩展名）
  const baseName = path.basename(absoluteHtml, '.html');
  const dateStr = baseName.replace(/ai-daily-|ai-news-/, '') || new Date().toISOString().split('T')[0];

  console.log(`\n📸 开始截图: ${path.basename(absoluteHtml)}`);
  console.log(`📁 输出目录: ${outDir}\n`);

  const browser = await chromium.launch({ headless: true });

  try {
    // ── 1. 完整报告截图（桌面端）──
    console.log('  🖥️  桌面端完整报告...');
    await takeScreenshot(browser, fileUrl, CONFIG.desktop, outDir, `${baseName}_full.png`);

    // ── 2. 社交分享版截图 ──
    console.log('  📱 社交分享版...');
    await takeScreenshot(browser, fileUrl, CONFIG.social, outDir, `${baseName}_social.png`);

    // ── 3. 封面版截图 ──
    console.log('  🖼️  封面版...');
    await takeCoverScreenshot(browser, fileUrl, CONFIG.cover, outDir, `${baseName}_cover.png`);

    // ── 4. 分段截图（每个 section 单独一张）──
    console.log('  ✂️  分段截图（按板块）...');
    await takeSectionScreenshots(browser, fileUrl, outDir, baseName);

    console.log('\n✅ 全部截图完成！');
    console.log(`📁 输出目录: ${outDir}`);
  } finally {
    await browser.close();
  }
}

async function takeScreenshot(browser, fileUrl, config, outDir, filename) {
  const context = await browser.newContext({
    viewport: { width: config.width, height: config.height },
    deviceScaleFactor: config.deviceScaleFactor
  });
  const page = await context.newPage();

  await page.goto(fileUrl, { waitUntil: 'networkidle', timeout: 30000 });
  // 额外等待字体和渲染
  await page.waitForTimeout(500);

  const outputPath = path.join(outDir, filename);
  await page.screenshot({
    path: outputPath,
    type: 'png',
    fullPage: config.fullPage
  });

  await context.close();
  const size = getFileSize(outputPath);
  console.log(`    ✓ ${filename} (${size})`);
}

async function takeCoverScreenshot(browser, fileUrl, config, outDir, filename) {
  const context = await browser.newContext({
    viewport: { width: config.width, height: config.height },
    deviceScaleFactor: config.deviceScaleFactor
  });
  const page = await context.newPage();

  await page.goto(fileUrl, { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(500);

  // 尝试截取 header + stats 区域作为封面
  const header = await page.locator('.header');
  const stats = await page.locator('.stats');
  const banner = await page.locator('.breaking-banner');

  const outputPath = path.join(outDir, filename);

  // 如果有 .header 元素，截取 header + stats
  if (await header.count() > 0) {
    try {
      // 滚动到顶部
      await page.evaluate(() => window.scrollTo(0, 0));
      await page.waitForTimeout(200);

      // 截取 header 区域
      await header.screenshot({ path: outputPath, type: 'png' });

      // 如果还有 stats，追加到截图（通过合成方式简单处理，直接截取整个上半部分）
      if (await stats.count() > 0) {
        // 重新截取更完整的区域
        const fullTop = await page.evaluate(() => {
          const h = document.querySelector('.header');
          const s = document.querySelector('.stats');
          const b = document.querySelector('.breaking-banner');
          let bottom = h ? h.getBoundingClientRect().bottom : 400;
          if (s) bottom = Math.max(bottom, s.getBoundingClientRect().bottom);
          if (b) bottom = Math.max(bottom, b.getBoundingClientRect().bottom);
          return { top: 0, bottom: bottom + 40 };
        });

        await page.screenshot({
          path: outputPath,
          type: 'png',
          clip: {
            x: 0,
            y: 0,
            width: config.width,
            height: Math.min(fullTop.bottom, 1200)
          }
        });
      }
    } catch (e) {
      // 回退到全页截图
      await page.screenshot({ path: outputPath, type: 'png', fullPage: false });
    }
  } else {
    await page.screenshot({ path: outputPath, type: 'png', fullPage: false });
  }

  await context.close();
  const size = getFileSize(outputPath);
  console.log(`    ✓ ${filename} (${size})`);
}

async function takeSectionScreenshots(browser, fileUrl, outDir, baseName) {
  const context = await browser.newContext({
    viewport: { width: 1080, height: 800 },
    deviceScaleFactor: 2
  });
  const page = await context.newPage();

  await page.goto(fileUrl, { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(500);

  // 获取所有 section-title 对应的区域
  const sections = await page.locator('.section-title').all();
  if (sections.length === 0) {
    await context.close();
    console.log('    ⚠️  未找到分段区域，跳过');
    return;
  }

  // 板块名称映射
  const sectionNames = [
    '大模型', 'Agent', '具身智能', '行业', '洞察', '其他'
  ];

  for (let i = 0; i < sections.length; i++) {
    try {
      await sections[i].scrollIntoViewIfNeeded();
      await page.waitForTimeout(200);

      // 获取板块的边界框
      const box = await sections[i].boundingBox();
      if (!box) continue;

      // 向下截取到下一个 section 或页面底部
      const clipHeight = await page.evaluate((idx) => {
        const titles = document.querySelectorAll('.section-title');
        const current = titles[idx];
        if (!current) return 600;
        const currentTop = current.getBoundingClientRect().top;

        // 查找下一个 section-title 或 hr 或 .insight
        let nextTop = window.innerHeight;
        const siblings = document.querySelectorAll('.section-title, hr, .insight, .footer');
        for (const el of siblings) {
          const rect = el.getBoundingClientRect();
          if (rect.top > currentTop + 50) {
            nextTop = rect.top;
            break;
          }
        }
        return Math.min(nextTop - currentTop + 40, 2000);
      }, i);

      const sectionName = sectionNames[i] || `section-${i + 1}`;
      const outputPath = path.join(outDir, `${baseName}_${String(i + 1).padStart(2, '0')}_${sectionName}.png`);

      await page.screenshot({
        path: outputPath,
        type: 'png',
        clip: {
          x: 0,
          y: box.y - 10,
          width: 1080,
          height: Math.max(clipHeight, 400)
        }
      });

      const size = getFileSize(outputPath);
      console.log(`    ✓ ${baseName}_${String(i + 1).padStart(2, '0')}_${sectionName}.png (${size})`);
    } catch (e) {
      console.log(`    ⚠️  板块 ${i + 1} 截图失败: ${e.message}`);
    }
  }

  await context.close();
}

function getFileSize(filePath) {
  try {
    const stats = fs.statSync(filePath);
    const kb = (stats.size / 1024).toFixed(0);
    const mb = (stats.size / 1024 / 1024).toFixed(1);
    return stats.size > 1024 * 1024 ? `${mb} MB` : `${kb} KB`;
  } catch {
    return '?';
  }
}

// ── 入口 ──
screenshotHtml(process.argv[2], process.argv[3]).catch(err => {
  console.error('❌ 截图失败:', err.message);
  process.exit(1);
});
