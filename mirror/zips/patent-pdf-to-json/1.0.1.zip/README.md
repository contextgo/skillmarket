# patent-pdf-to-json（3 CLI 解耦版）

## 命令职责

1. `claims-trim`：专利 PDF 裁剪，仅保留著录项 + 权利要求书。
2. `pdf-extract`：调用 MinerU 解析 PDF -> Markdown，仅此命令处理 `local/cloud` 差异。
3. `md-to-json`：Markdown 结构化为稳定 JSON 契约，不依赖 MinerU/网络。

## 运行决策（摘要）

当前生产默认建议：

- `pdf-extract` 优先使用 `--mode local`
- 本地模式默认走 `pipeline` 路径
- 并发建议 `threads/workers=1~2`（M4 机器不超过 2）

决策依据来自回归结果：本地 pipeline 在批量任务上稳定性和耗时可控性更优，适合作为默认主链路。

## 推荐目录

```text
workspace/
  trimmed_pdf/
  md/
  json/
```

## 命令 A：claims-trim

```bash
python3 skills/patent-pdf-to-json/scripts/claims_trim_cli.py \
  --input <pdf|dir|zip> \
  --output_dir <trim_pdf_dir> \
  --workers 2 \
  --overwrite on \
  --keep_tmp off
```

参数：`--input --output_dir --workers --id_regex --overwrite on|off --keep_tmp on|off`

## 命令 B：pdf-extract

### local 模式

```bash
python3 skills/patent-pdf-to-json/scripts/pdf_extract_cli.py \
  --mode local \
  --input <trim_pdf_dir> \
  --output_dir <md_dir> \
  --threads 2 \
  --page_range "" \
  --timeout_sec 600
```

### cloud 模式

```bash
python3 skills/patent-pdf-to-json/scripts/pdf_extract_cli.py \
  --mode cloud \
  --input <trim_pdf_dir> \
  --output_dir <md_dir> \
  --threads 2 \
  --retry 2 \
  --timeout_sec 600
```

参数边界：

- `local/cloud` 共同支持：`--input --output_dir --workers --page_range --timeout_sec --retry`
- `cloud` 缺 token 会 fail-fast
- `local` 模式固定使用本地 `pipeline`，不再支持模型选择参数
- `--timeout_sec` 在 local 模式仅为参考值（MinerU CLI 内部仍有独立超时）

云端网络注意：

- `cloud` 模式下载默认严格启用 SSL 证书校验，不再提供跳过证书校验的回退逻辑。
- 若出现 TLS 握手类错误，优先检查并关闭系统/终端代理后重试；常见根因是代理链路干扰，而非 token 或命令参数错误。

## 命令 C：md-to-json

```bash
python3 skills/patent-pdf-to-json/scripts/md_to_json_cli.py \
  --input <md_dir> \
  --output_dir <json_dir> \
  --schema_version v1 \
  --workers 4 \
  --strict off
```

参数：`--input --output_dir --schema_version --workers --strict on|off`

## JSON 契约

成功项：

- `schema_version`
- `patent_id`
- `title`
- `publication_number`
- `application_number`
- `application_date`
- `publication_date`
- `assignees` (array)
- `inventors` (array)
- `ipc_classes` (array)
- `abstract`
- `full_claims`
- `status = success`
- `raw_data`（`provider/runtime_mode/task_id/md_path/source_file`）

失败项：

- `schema_version`
- `patent_id`
- `status = failed`
- `error`
- `raw_data`

## 可选薄编排（兼容）

历史入口 `pdf_import_cli.py` 仍可用作串联调用，但不建议继续承载新业务逻辑。
