import logging
import os
import re
import shutil
import tempfile
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from zipfile import ZipFile

from mineru_client import MinerUClient

logger = logging.getLogger(__name__)


@dataclass
class PdfTask:
    patent_id: str
    pdf_path: str


class PDFExtractService:
    def __init__(self, mineru_client: Optional[MinerUClient] = None):
        self.mineru_client = mineru_client or MinerUClient()

    def count_input_tasks(self, input_path: str, id_regex: Optional[str] = None) -> int:
        input_path = os.path.abspath(input_path)
        tasks, tmp_dirs = self.build_tasks(input_path=input_path, id_regex=id_regex)
        try:
            return len(tasks)
        finally:
            for temp_dir in tmp_dirs:
                shutil.rmtree(temp_dir, ignore_errors=True)

    def build_tasks(self, input_path: str, id_regex: Optional[str]) -> Tuple[List[PdfTask], List[str]]:
        task_files: List[str] = []
        tmp_dirs: List[str] = []
        path_lower = input_path.lower()

        if path_lower.endswith(".pdf"):
            if not os.path.exists(input_path):
                raise FileNotFoundError(f"输入文件不存在: {input_path}")
            task_files = [input_path]
        elif path_lower.endswith(".zip"):
            if not os.path.exists(input_path):
                raise FileNotFoundError(f"输入 ZIP 不存在: {input_path}")
            temp_dir = tempfile.mkdtemp(prefix="pdf_import_zip_")
            tmp_dirs.append(temp_dir)
            with ZipFile(input_path, "r") as zf:
                zf.extractall(temp_dir)
            task_files = self._collect_pdfs(temp_dir)
        elif os.path.isdir(input_path):
            task_files = self._collect_pdfs(input_path)
        else:
            raise ValueError("`--input` 仅支持 .pdf / 目录 / .zip")

        regex = re.compile(id_regex) if id_regex else None
        tasks: List[PdfTask] = []
        for pdf_path in task_files:
            patent_id = self._extract_patent_id(pdf_path=pdf_path, id_regex=regex)
            tasks.append(PdfTask(patent_id=patent_id, pdf_path=os.path.abspath(pdf_path)))
        return tasks, tmp_dirs

    def run_extract(
        self,
        tasks: List[PdfTask],
        output_dir: str,
        mode: str = "auto",
        workers: int = 4,
        page_range: Optional[str] = None,
        retry: int = 2,
        timeout_sec: int = 600,
        progress_callback: Optional[Callable[..., None]] = None,
    ) -> Dict[str, Any]:
        total = len(tasks)
        if total == 0:
            return {"total": 0, "success_count": 0, "failed_count": 0, "errors": [], "items": []}

        os.makedirs(output_dir, exist_ok=True)

        result: Dict[str, Any] = {
            "total": total,
            "success_count": 0,
            "failed_count": 0,
            "errors": [],
            "items": [],
        }
        success_items_by_id: Dict[str, Dict[str, Any]] = {}
        final_failed_by_id: Dict[str, Dict[str, Any]] = {}
        with ThreadPoolExecutor(max_workers=max(1, workers)) as executor:
            future_to_task = {
                executor.submit(
                    self._extract_one_task,
                    task=task,
                    output_dir=output_dir,
                    mode=mode,
                    page_range=page_range,
                    retry=retry,
                    timeout_sec=timeout_sec,
                    progress_callback=progress_callback,
                ): task
                for task in tasks
            }
            batch_deadline_sec = max(60, int(max(1, timeout_sec) * max(1, total) * 1.5))
            completed_task_ids = set()
            try:
                for future in as_completed(future_to_task, timeout=batch_deadline_sec):
                    task = future_to_task[future]
                    completed_task_ids.add(task.patent_id)
                    item = future.result()
                    if item["status"] == "success":
                        success_items_by_id[task.patent_id] = item
                        final_failed_by_id.pop(task.patent_id, None)
                    else:
                        final_failed_by_id[task.patent_id] = item

                    done = len(success_items_by_id) + len(final_failed_by_id)
                    if progress_callback:
                        progress_callback(event="done", done=done, success=len(success_items_by_id), failed=len(final_failed_by_id))
            except FuturesTimeoutError:
                logger.error("extract 触发整体超时保护（%ss），未完成任务将标记失败。", batch_deadline_sec)
                for task in tasks:
                    if task.patent_id in completed_task_ids:
                        continue
                    final_failed_by_id[task.patent_id] = {
                        "status": "failed",
                        "patent_id": task.patent_id,
                        "file_path": task.pdf_path,
                        "error": f"提取超时（>{batch_deadline_sec}s）",
                    }

        result["items"] = list(success_items_by_id.values())
        result["errors"] = list(final_failed_by_id.values())
        result["success_count"] = len(success_items_by_id)
        result["failed_count"] = len(final_failed_by_id)
        return result

    def _collect_pdfs(self, dir_path: str) -> List[str]:
        all_files: List[str] = []
        for root, _, files in os.walk(dir_path):
            for name in files:
                if not name.lower().endswith(".pdf"):
                    continue
                if name.startswith("._"):
                    continue
                file_path = os.path.join(root, name)
                rel_parts = Path(os.path.relpath(file_path, dir_path)).parts
                if "__MACOSX" in rel_parts:
                    continue
                if os.path.getsize(file_path) <= 0:
                    continue
                all_files.append(file_path)
        all_files.sort()
        return all_files

    def _extract_patent_id(self, pdf_path: str, id_regex: Optional[re.Pattern]) -> str:
        stem = Path(pdf_path).stem
        if not id_regex:
            return stem
        match = id_regex.search(stem)
        if not match:
            return stem
        if match.groups():
            return match.group(1)
        return match.group(0)

    def _extract_one_task(
        self,
        task: PdfTask,
        output_dir: str,
        mode: str,
        page_range: Optional[str],
        retry: int,
        timeout_sec: int,
        progress_callback: Optional[Callable[..., None]] = None,
    ) -> Dict[str, Any]:
        if progress_callback:
            progress_callback(event="start", item=task.patent_id)
        attempts = max(1, retry + 1)
        last_err: Optional[str] = None
        selected_provider = "pipeline" if mode == "local" else ("vlm" if mode == "cloud" else "auto")

        for current_attempt in range(1, attempts + 1):
            try:
                markdown, meta = self.mineru_client.parse_pdf(
                    file_path=task.pdf_path,
                    page_range=page_range,
                    timeout_sec=timeout_sec,
                    mode=mode,
                )
                if not markdown or not markdown.strip():
                    raise ValueError("MinerU 返回 markdown 为空")
                output_path = os.path.join(output_dir, f"{task.patent_id}.md")
                with open(output_path, "w", encoding="utf-8") as fp:
                    fp.write(markdown)
                final_provider = str(meta.get("provider", selected_provider))
                logger.info("extract 成功 patent_id=%s file=%s provider=%s", task.patent_id, task.pdf_path, final_provider)
                if progress_callback and meta.get("local_trace"):
                    progress_callback(
                        event="trace",
                        patent_id=task.patent_id,
                        provider=final_provider,
                        runtime_mode=meta.get("runtime_mode"),
                        backend=meta.get("backend", ""),
                        trace=meta.get("local_trace"),
                    )
                return {
                    "status": "success",
                    "patent_id": task.patent_id,
                    "file_path": task.pdf_path,
                    "md_path": os.path.abspath(output_path),
                    "provider": final_provider,
                    "task_id": meta.get("task_id"),
                    "runtime_mode": meta.get("runtime_mode"),
                }
            except Exception as exc:
                last_err = str(exc)
                logger.exception(
                    "extract 失败 patent_id=%s provider=%s attempt=%s/%s file=%s",
                    task.patent_id,
                    selected_provider,
                    current_attempt,
                    attempts,
                    task.pdf_path,
                )
                continue
        return {
            "status": "failed",
            "patent_id": task.patent_id,
            "file_path": task.pdf_path,
            "provider": selected_provider,
            "error": last_err or "unknown error",
        }
