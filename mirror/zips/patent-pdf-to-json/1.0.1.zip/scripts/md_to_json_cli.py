import argparse
import logging
import os
import sys
import threading
from typing import Dict

from md_to_json_service import MDToJSONService
from tqdm import tqdm


def _build_log_path(output_dir: str) -> str:
    return os.path.join(os.path.abspath(output_dir), ".log", "md_to_json.log")


def _setup_file_logger(log_path: str) -> None:
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    root_logger.addHandler(file_handler)


def main() -> None:
    parser = argparse.ArgumentParser(description="Markdown 结构化 CLI（Markdown -> JSON）")
    parser.add_argument("--input", type=str, required=True, help="输入路径：md / 目录")
    parser.add_argument("--output_dir", type=str, required=True, help="JSON 输出目录")
    parser.add_argument("--schema_version", type=str, default="v1", help="JSON 契约版本")
    parser.add_argument("--workers", type=int, default=4, help="并发线程数")
    parser.add_argument("--strict", type=str, default="off", help="严格校验字段完整性（on/off）")
    parser.add_argument("--id_regex", type=str, default="", help="从文件名提取 patent_id 的正则")
    args = parser.parse_args()

    strict = args.strict.lower() in ("true", "1", "yes", "on")
    log_path = _build_log_path(output_dir=args.output_dir)
    _setup_file_logger(log_path)
    logger = logging.getLogger(__name__)

    os.makedirs(args.output_dir, exist_ok=True)
    service = MDToJSONService(output_dir=args.output_dir)
    tasks = service.build_md_tasks(input_path=args.input, id_regex=args.id_regex or None)
    total = len(tasks)
    if total == 0:
        logger.error("未发现可处理 Markdown input=%s", args.input)
        sys.exit(1)

    progress: Dict[str, int] = {"done": 0, "success": 0, "failed": 0}
    lock = threading.Lock()

    def on_progress(done: int, success: int, failed: int, patent_id: str) -> None:
        with lock:
            progress["done"] = int(done)
            progress["success"] = int(success)
            progress["failed"] = int(failed)

    with tqdm(total=total, desc="[json-export]", unit="file", dynamic_ncols=True, leave=True) as pbar:
        def wrapped_progress(done: int, success: int, failed: int, patent_id: str) -> None:
            on_progress(done, success, failed, patent_id)
            with lock:
                new_done = progress["done"]
                increment = max(0, new_done - pbar.n)
                pbar.set_postfix({"ok": progress["success"], "err": progress["failed"]}, refresh=False)
                if increment > 0:
                    pbar.update(increment)

        success, failed, errors = service.export_tasks(
            tasks=tasks,
            output_dir=args.output_dir,
            schema_version=args.schema_version,
            strict=strict,
            workers=args.workers,
            progress_callback=wrapped_progress,
        )
        if pbar.n < total:
            pbar.update(total - pbar.n)

    logger.info("结构化完成 total=%s success=%s failed=%s", total, success, failed)
    if errors:
        logger.error("失败样本=%s", errors[:5])
    if failed > 0:
        sys.exit(2)


if __name__ == "__main__":
    main()
