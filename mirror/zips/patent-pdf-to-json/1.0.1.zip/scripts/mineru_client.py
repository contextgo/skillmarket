import json
import os
import re
import signal
import shutil
import subprocess
import tempfile
import threading
import time
import zipfile
from collections import deque
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import requests


class MinerUClient:
    _sign_lock = threading.Lock()
    _sign_timestamps = deque()
    _sign_limit_per_minute = 45
    _valid_modes = {"auto", "local", "cloud"}
    _local_retryable_error_keywords = (
        "started local mineru-api",
        "waiting for application startup",
        "connection",
        "timed out",
        "timeout",
        "temporarily unavailable",
        "broken pipe",
        "address already in use",
    )
    _local_trace_markers = (
        ("api_spawn", "Started local mineru-api"),
        ("task_submit", "run_planned_task:771 - Submitting batch"),
        ("model_init_start", "DocAnalysis init, this may take some times"),
        ("model_init_done", "DocAnalysis init done!"),
        ("batch_done", "run_planned_task:807 - Completed batch"),
    )

    def __init__(
        self,
        token: Optional[str] = None,
        mode: Optional[str] = None,
        local_cli: Optional[str] = None,
    ):
        self.token = token or self._load_token()
        self.mode = self._resolve_mode(mode)
        self.local_cli = local_cli or os.environ.get("MINERU_LOCAL_CLI", "").strip() or "mineru"
        self.base_url_v4 = "https://mineru.net/api/v4"
        self._local_cli_path_cache: Optional[str] = None

    def _load_token(self) -> Optional[str]:
        config_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "assets", "mineru_api", "config.json")
        )
        if os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as fp:
                    config = json.load(fp)
                token = config.get("MINERU_API_TOKEN")
                if isinstance(token, str) and token.strip():
                    return token.strip()
            except Exception:
                pass

        env_token = os.environ.get("MINERU_API_TOKEN")
        if env_token and env_token.strip():
            return env_token.strip()
        return None

    def _resolve_mode(self, mode: Optional[str]) -> str:
        raw = (mode or os.environ.get("MINERU_MODE", "auto")).strip().lower()
        if raw not in self._valid_modes:
            raise ValueError(f"不支持的 MINERU_MODE: {raw}（仅支持 auto/local/cloud）")
        return raw

    def _auth_headers(self) -> Dict[str, str]:
        if not self.token:
            raise ValueError("未找到 MinerU token，请在 assets/mineru_api/config.json 或环境变量 MINERU_API_TOKEN 中配置。")
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.token}",
        }

    def _resolve_local_cli_path(self) -> Optional[str]:
        if self._local_cli_path_cache:
            return self._local_cli_path_cache
        candidates = [self.local_cli, "mineru", "magic-pdf"]
        for candidate in candidates:
            if not candidate:
                continue
            cli_path = shutil.which(candidate)
            if cli_path:
                self._local_cli_path_cache = cli_path
                return cli_path
        return None

    def _check_local_available(self) -> Tuple[bool, str]:
        cli_path = self._resolve_local_cli_path()
        if not cli_path:
            return False, "未找到本地 MinerU CLI（可执行文件 mineru/magic-pdf）"
        try:
            proc = subprocess.run(
                [cli_path, "--version"],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
            if proc.returncode == 0:
                return True, f"{cli_path} 可用"
            err_msg = (proc.stderr or proc.stdout or "").strip()
            return False, f"{cli_path} 不可用: {err_msg[:200]}"
        except Exception as exc:
            return False, f"{cli_path} 健康检查异常: {exc}"

    def resolve_runtime_mode(self, mode: Optional[str] = None) -> str:
        desired_mode = self._resolve_mode(mode) if mode is not None else self.mode
        if desired_mode == "local":
            ok, reason = self._check_local_available()
            if not ok:
                raise RuntimeError(f"MINERU_MODE=local 但本地 MinerU 不可用：{reason}")
            return "local"
        if desired_mode == "cloud":
            if not self.token:
                raise RuntimeError("MINERU_MODE=cloud 但未配置 MINERU_API_TOKEN")
            return "cloud"
        ok, _ = self._check_local_available()
        if ok:
            return "local"
        if self.token:
            return "cloud"
        raise RuntimeError("MINERU_MODE=auto 下本地 MinerU 不可用，且未配置 MINERU_API_TOKEN（无法回退 cloud）")

    def health_check(self, mode: Optional[str] = None) -> Dict[str, Any]:
        desired_mode = self._resolve_mode(mode) if mode is not None else self.mode
        if desired_mode == "local":
            ok, reason = self._check_local_available()
            if not ok:
                raise RuntimeError(f"MinerU 本地模式健康检查失败：{reason}")
            return {"requested_mode": desired_mode, "runtime_mode": "local", "reason": reason}

        if desired_mode == "cloud":
            if not self.token:
                raise RuntimeError("MinerU 云端模式健康检查失败：未配置 MINERU_API_TOKEN")
            return {"requested_mode": desired_mode, "runtime_mode": "cloud", "reason": "已检测到 API Token"}

        ok, reason = self._check_local_available()
        if ok:
            return {"requested_mode": desired_mode, "runtime_mode": "local", "reason": reason}
        if self.token:
            return {
                "requested_mode": desired_mode,
                "runtime_mode": "cloud",
                "reason": f"本地不可用({reason})，已回退 cloud（token 可用）",
            }
        raise RuntimeError(f"MinerU 自动模式健康检查失败：本地不可用({reason})，且 cloud token 未配置")

    def _wait_for_sign_slot(self) -> None:
        while True:
            wait_sec = 0.0
            with self._sign_lock:
                now = time.monotonic()
                while self._sign_timestamps and now - self._sign_timestamps[0] >= 60:
                    self._sign_timestamps.popleft()
                if len(self._sign_timestamps) < self._sign_limit_per_minute:
                    self._sign_timestamps.append(now)
                    return
                wait_sec = max(0.5, 60 - (now - self._sign_timestamps[0]))
            time.sleep(wait_sec)

    # HTTP utility cluster
    def _request_with_retry(
        self,
        method: str,
        url: str,
        *,
        max_attempts: int = 5,
        timeout: int = 30,
        headers: Optional[Dict[str, str]] = None,
        json_payload: Optional[Dict[str, Any]] = None,
        data: Any = None,
    ) -> requests.Response:
        last_error: Optional[Exception] = None
        for attempt in range(1, max_attempts + 1):
            try:
                resp = requests.request(
                    method=method.upper(),
                    url=url,
                    headers=headers,
                    json=json_payload,
                    data=data,
                    timeout=timeout,
                )
                if resp.status_code == 429:
                    retry_after = resp.headers.get("Retry-After")
                    delay = float(retry_after) if retry_after and retry_after.isdigit() else min(60, 2**attempt)
                    time.sleep(delay)
                    continue
                if 500 <= resp.status_code < 600:
                    time.sleep(min(30, 2**attempt))
                    continue
                return resp
            except requests.exceptions.RequestException as exc:
                last_error = exc
                time.sleep(min(30, 2**attempt))
        if last_error:
            raise last_error
        raise RuntimeError(f"HTTP 请求重试失败: {url}")

    def parse_pdf(
        self,
        file_path: str,
        page_range: Optional[str] = None,
        timeout_sec: int = 600,
        mode: Optional[str] = None,
    ) -> Tuple[str, Dict[str, Any]]:
        runtime_mode = self.resolve_runtime_mode(mode=mode)
        if runtime_mode == "local":
            return self._parse_local(file_path=file_path, page_range=page_range, timeout_sec=timeout_sec)
        return self._parse_precision(file_path=file_path, page_range=page_range, timeout_sec=timeout_sec)

    # Local parse cluster
    def _parse_page_range(self, page_range: Optional[str]) -> Tuple[Optional[int], Optional[int]]:
        if not page_range:
            return None, None
        text = page_range.strip()
        if not text:
            return None, None
        if "-" in text:
            left, right = text.split("-", 1)
            if not left.strip().isdigit() or not right.strip().isdigit():
                return None, None
            start_page = max(0, int(left.strip()) - 1)
            end_page = max(start_page, int(right.strip()) - 1)
            return start_page, end_page
        if text.isdigit():
            page = max(0, int(text) - 1)
            return page, page
        return None, None

    def _collect_local_markdown_candidates(self, output_root: str, stem: str) -> List[str]:
        preferred = []
        fallback = []
        for root, _, files in os.walk(output_root):
            for name in files:
                if not name.lower().endswith(".md"):
                    continue
                path = os.path.join(root, name)
                if name == f"{stem}.md":
                    preferred.append(path)
                else:
                    fallback.append(path)
        preferred.sort()
        fallback.sort()
        return preferred + fallback

    def _parse_local(
        self,
        file_path: str,
        page_range: Optional[str],
        timeout_sec: int,
    ) -> Tuple[str, Dict[str, Any]]:
        cli_path = self._resolve_local_cli_path()
        if not cli_path:
            raise RuntimeError("本地 MinerU 不可用：未找到 mineru/magic-pdf 可执行文件")

        backend = "pipeline"
        start_page, end_page = self._parse_page_range(page_range)
        stem = os.path.splitext(os.path.basename(file_path))[0]
        with tempfile.TemporaryDirectory(prefix="mineru_local_") as temp_dir:
            cmd = [
                cli_path,
                "-p",
                file_path,
                "-o",
                temp_dir,
                "-b",
                backend,
                "-m",
                "auto",
                "-l",
                "ch",
                "-f",
                "true",
                "-t",
                "true",
            ]
            if start_page is not None:
                cmd.extend(["-s", str(start_page)])
            if end_page is not None:
                cmd.extend(["-e", str(end_page)])

            max_attempts = 2
            proc: Optional[subprocess.CompletedProcess[str]] = None
            last_error_msg = ""
            attempt_trace: List[Dict[str, Any]] = []
            for attempt in range(1, max_attempts + 1):
                started_at = time.time()
                proc = self._run_local_cli_with_timeout(cmd=cmd, timeout_sec=max(30, timeout_sec))
                finished_at = time.time()
                combined_text = "\n".join([proc.stderr or "", proc.stdout or ""])
                attempt_trace = self._build_local_trace(
                    raw_text=combined_text,
                    started_at=started_at,
                    finished_at=finished_at,
                )
                if proc.returncode == 0:
                    break
                stderr = (proc.stderr or proc.stdout or "").strip()
                last_error_msg = stderr
                if attempt >= max_attempts or not self._is_local_retryable_error(stderr):
                    raise RuntimeError(f"本地 MinerU 解析失败(returncode={proc.returncode}): {stderr[:500]}")
                time.sleep(2)

            if proc is None:
                raise RuntimeError(f"本地 MinerU 解析失败: {last_error_msg[:500]}")

            md_candidates = self._collect_local_markdown_candidates(output_root=temp_dir, stem=stem)
            if not md_candidates:
                raise RuntimeError("本地 MinerU 解析完成但未找到 markdown 产物")

            md_path = md_candidates[0]
            with open(md_path, "r", encoding="utf-8", errors="replace") as fp:
                markdown_text = fp.read()
            if not markdown_text.strip():
                raise RuntimeError("本地 MinerU 产物 markdown 为空")

            return markdown_text, {
                "task_id": f"local_{int(time.time() * 1000)}",
                "provider": "pipeline",
                "runtime_mode": "local",
                "backend": backend,
                "local_md_path": md_path,
                "local_trace": attempt_trace,
                "state": "done",
            }

    def _run_local_cli_with_timeout(self, cmd: List[str], timeout_sec: int) -> subprocess.CompletedProcess[str]:
        timeout = max(30, timeout_sec)
        kwargs: Dict[str, Any] = {
            "stdout": subprocess.PIPE,
            "stderr": subprocess.PIPE,
            "text": True,
        }
        if os.name == "posix":
            kwargs["start_new_session"] = True
        proc = subprocess.Popen(cmd, **kwargs)
        try:
            stdout, stderr = proc.communicate(timeout=timeout)
            return subprocess.CompletedProcess(cmd, proc.returncode, stdout, stderr)
        except subprocess.TimeoutExpired:
            self._terminate_process_tree(proc)
            raise TimeoutError(f"本地 MinerU 超时（{timeout}s），已强制终止子进程")

    def _terminate_process_tree(self, proc: subprocess.Popen[Any]) -> None:
        try:
            if os.name == "posix":
                os.killpg(proc.pid, signal.SIGTERM)
            else:
                proc.terminate()
        except Exception:
            pass
        try:
            proc.wait(timeout=5)
            return
        except Exception:
            pass
        try:
            if os.name == "posix":
                os.killpg(proc.pid, signal.SIGKILL)
            else:
                proc.kill()
        except Exception:
            pass

    def _is_local_retryable_error(self, err_text: str) -> bool:
        text = (err_text or "").lower()
        return any(keyword in text for keyword in self._local_retryable_error_keywords)

    def _build_local_trace(self, raw_text: str, started_at: float, finished_at: float) -> List[Dict[str, Any]]:
        lines = (raw_text or "").splitlines()
        marker_hits: Dict[str, Dict[str, Any]] = {}
        for line in lines:
            for step, needle in self._local_trace_markers:
                if step in marker_hits:
                    continue
                if needle not in line:
                    continue
                ts = self._extract_ts(line)
                marker_hits[step] = {"step": step, "ts": ts, "line": line.strip()}
        steps: List[Dict[str, Any]] = [{"step": "process_start", "ts": started_at}]
        for step, _ in self._local_trace_markers:
            if step in marker_hits:
                steps.append({"step": step, "ts": marker_hits[step]["ts"], "line": marker_hits[step]["line"]})
        steps.append({"step": "process_end", "ts": finished_at})

        # Fill missing timestamps by carrying forward nearest known timestamp.
        last_known = started_at
        for item in steps:
            ts = item.get("ts")
            if ts is None:
                item["ts"] = last_known
            else:
                last_known = float(ts)

        normalized: List[Dict[str, Any]] = []
        prev_ts = started_at
        for item in steps:
            ts = float(item["ts"])
            normalized.append(
                {
                    "step": item["step"],
                    "offset_sec": round(max(0.0, ts - started_at), 3),
                    "delta_sec": round(max(0.0, ts - prev_ts), 3),
                    "line": item.get("line", ""),
                }
            )
            prev_ts = ts
        return normalized

    def _extract_ts(self, line: str) -> Optional[float]:
        match = re.search(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d+)", line)
        if not match:
            return None
        try:
            dt = datetime.strptime(match.group(1), "%Y-%m-%d %H:%M:%S.%f")
            return dt.timestamp()
        except ValueError:
            return None

    # Cloud parse cluster
    def _parse_precision(
        self,
        file_path: str,
        page_range: Optional[str],
        timeout_sec: int,
    ) -> Tuple[str, Dict[str, Any]]:
        file_name = os.path.basename(file_path)
        payload_file: Dict[str, Any] = {"name": file_name, "data_id": f"{file_name}_{int(time.time() * 1000)}"}
        if page_range:
            payload_file["page_ranges"] = page_range

        payload = {
            "files": [payload_file],
            "model_version": "vlm",
            "enable_formula": True,
            "enable_table": True,
            "language": "ch",
        }

        self._wait_for_sign_slot()
        sign_resp = self._request_with_retry(
            method="POST",
            url=f"{self.base_url_v4}/file-urls/batch",
            headers=self._auth_headers(),
            json_payload=payload,
            timeout=30,
            max_attempts=6,
        )
        if sign_resp.status_code != 200:
            raise RuntimeError(f"申请上传签名失败 HTTP {sign_resp.status_code}: {sign_resp.text}")
        sign_data = sign_resp.json()
        if sign_data.get("code") != 0:
            raise RuntimeError(f"申请上传签名失败: {sign_data}")

        batch_id = sign_data["data"]["batch_id"]
        file_urls = sign_data["data"].get("file_urls", [])
        if not file_urls:
            raise RuntimeError("申请上传签名成功但未返回 file_url")

        with open(file_path, "rb") as fp:
            upload_resp = self._request_with_retry(
                method="PUT",
                url=file_urls[0],
                data=fp,
                timeout=120,
                max_attempts=4,
            )
        if upload_resp.status_code not in (200, 201):
            raise RuntimeError(f"上传文件失败 HTTP {upload_resp.status_code}")

        full_zip_url = self._poll_precision_zip_url(batch_id=batch_id, timeout_sec=timeout_sec, file_name=file_name)
        markdown_text = self._download_full_markdown(full_zip_url=full_zip_url)
        return markdown_text, {
            "task_id": batch_id,
            "provider": "vlm",
            "runtime_mode": "cloud",
            "state": "done",
        }

    def _poll_precision_zip_url(self, batch_id: str, timeout_sec: int, file_name: str) -> str:
        status_url = f"{self.base_url_v4}/extract-results/batch/{batch_id}"
        deadline = time.time() + max(10, timeout_sec)

        while time.time() < deadline:
            status_resp = self._request_with_retry(
                method="GET",
                url=status_url,
                headers=self._auth_headers(),
                timeout=20,
                max_attempts=3,
            )
            if status_resp.status_code == 200:
                status_data = status_resp.json()
                for item in status_data.get("data", {}).get("extract_result", []):
                    if item.get("file_name") != file_name:
                        continue
                    state = item.get("state")
                    if state == "done":
                        zip_url = item.get("full_zip_url")
                        if not zip_url:
                            raise RuntimeError("任务完成但缺少 full_zip_url")
                        return zip_url
                    if state == "failed":
                        raise RuntimeError(item.get("err_msg") or "MinerU 精准解析失败")
            time.sleep(5)

        raise TimeoutError(f"MinerU 精准解析超时（{timeout_sec}s）")

    def _download_full_markdown(self, full_zip_url: str) -> str:
        with tempfile.TemporaryDirectory(prefix="mineru_dl_") as temp_dir:
            zip_path = os.path.join(temp_dir, "result.zip")
            download_resp = self._request_with_retry(
                method="GET",
                url=full_zip_url,
                timeout=120,
                max_attempts=4,
            )
            if download_resp.status_code != 200:
                raise RuntimeError(f"下载 MinerU 结果失败 HTTP {download_resp.status_code}")
            with open(zip_path, "wb") as fp:
                fp.write(download_resp.content)

            with zipfile.ZipFile(zip_path, "r") as zf:
                md_file = next((name for name in zf.namelist() if name.endswith("full.md")), None)
                if not md_file:
                    raise RuntimeError("MinerU 结果 ZIP 中未找到 full.md")
                with zf.open(md_file, "r") as md_fp:
                    return md_fp.read().decode("utf-8", errors="replace")
