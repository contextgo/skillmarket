import argparse
import logging
import os
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict
from zipfile import ZipFile
from pdf_extract_service import PDFExtractService
from tqdm import tqdm

from pdf_preprocess_service import PDFPreprocessService


def _build_log_path(output_dir: str) -> str:
    out_abs = os.path.abspath(output_dir)
    return os.path.join(out_abs, ".log", "pdf_claims_only.log")


def _setup_file_logger(log_path: str) -> None:
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    root_logger.addHandler(file_handler)


def _trim_one_pdf(task: Any, output_dir: str, overwrite: bool, preprocess_service: PDFPreprocessService) -> Dict[str, str]:
    logger = logging.getLogger(__name__)
    src = task.pdf_path
    dst = os.path.join(os.path.abspath(output_dir), f"{task.patent_id}.pdf")
    if (not overwrite) and os.path.exists(dst):
        return {"status": "skipped", "patent_id": task.patent_id, "output_path": dst, "reason": "已存在"}
    result = preprocess_service.trim_one_task(task=task, output_dir=os.path.abspath(output_dir))
    keep_count = result["keep_pages"]
    total_pages = result["total_pages"]
    reason = result["reason"]

    logger.info(
        "裁剪完成 patent_id=%s src=%s dst=%s keep_pages=%s total_pages=%s reason=%s",
        task.patent_id,
        src,
        dst,
        keep_count,
        total_pages,
        reason,
    )
    return {
        "status": "success",
        "patent_id": task.patent_id,
        "output_path": dst,
        "keep_pages": str(keep_count),
        "total_pages": str(total_pages),
        "reason": reason,
    }


def _str_to_bool(value: str) -> bool:
    return value.lower() in ("true", "1", "yes", "on")


def main() -> None:
    parser = argparse.ArgumentParser(description="仅保留专利 PDF 著录项+权利要求书，裁掉说明书/附图")
    parser.add_argument("--input", type=str, required=True, help="输入路径：pdf / 目录 / zip")
    parser.add_argument("--output_dir", type=str, required=True, help="输出目录（写入裁剪后 PDF）")
    parser.add_argument("--workers", type=int, default=4, help="并发线程数")
    parser.add_argument("--id_regex", type=str, default="", help="从文件名提取 patent_id 的正则")
    parser.add_argument("--keep_tmp", type=str, default="off", help="保留 ZIP 解压临时目录（on/off）")
    parser.add_argument("--overwrite", type=str, default="on", help="覆盖已存在输出（on/off）")
    args = parser.parse_args()

    keep_tmp = _str_to_bool(args.keep_tmp)
    overwrite = _str_to_bool(args.overwrite)

    log_path = _build_log_path(output_dir=args.output_dir)
    _setup_file_logger(log_path)
    logger = logging.getLogger(__name__)

    task_service = PDFExtractService()
    tasks, tmp_dirs = task_service.build_tasks(input_path=args.input, id_regex=args.id_regex or None)
    total = len(tasks)
    if total == 0:
        logger.error("未发现可处理 PDF input=%s", args.input)
        sys.exit(1)
    os.makedirs(args.output_dir, exist_ok=True)

    progress = {"done": 0, "ok": 0, "err": 0, "skip": 0}
    preprocess_service = PDFPreprocessService()
    exit_code = 0
    try:
        with tqdm(total=total, desc="[claims-trim]", unit="file", dynamic_ncols=True, leave=True) as pbar:
            with ThreadPoolExecutor(max_workers=max(1, args.workers)) as executor:
                future_to_task = {
                    executor.submit(_trim_one_pdf, task, args.output_dir, overwrite, preprocess_service): task
                    for task in tasks
                }
                for future in as_completed(future_to_task):
                    task = future_to_task[future]
                    progress["done"] += 1
                    pbar.update(1)
                    try:
                        result = future.result()
                        status = result.get("status")
                        if status == "success":
                            progress["ok"] += 1
                        elif status == "skipped":
                            progress["skip"] += 1
                        else:
                            progress["err"] += 1
                        if status == "failed":
                            logger.error("裁剪失败 patent_id=%s error=%s", task.patent_id, result.get("error", "unknown"))
                    except Exception as exc:
                        progress["err"] += 1
                        logger.exception("处理异常 patent_id=%s file=%s err=%s", task.patent_id, task.pdf_path, exc)
                    pbar.set_postfix({"ok": progress["ok"], "err": progress["err"], "skip": progress["skip"]}, refresh=False)
    finally:
        if not keep_tmp:
            for temp_dir in tmp_dirs:
                shutil.rmtree(temp_dir, ignore_errors=True)
        if progress["err"] > 0:
            exit_code = 2

    logger.info(
        "处理完成 total=%s ok=%s fail=%s skip=%s output_dir=%s",
        total,
        progress["ok"],
        progress["err"],
        progress["skip"],
        os.path.abspath(args.output_dir),
    )
    if exit_code != 0:
        sys.exit(exit_code)


if __name__ == "__main__":
    main()
