import logging
import os
import re
import tempfile
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

from PyPDF2 import PdfReader, PdfWriter

logger = logging.getLogger(__name__)


@dataclass
class PdfTask:
    patent_id: str
    pdf_path: str


class PDFPreprocessService:
    def __init__(self):
        pass

    def preprocess_tasks(
        self,
        tasks: List[Any],
        workers: int = 4,
        claims_only_pdf: bool = True,
        event_callback: Optional[Callable[[Dict[str, object]], None]] = None,
    ) -> Tuple[List[Any], List[str]]:
        if not claims_only_pdf or not tasks:
            return tasks, []

        temp_dir = tempfile.mkdtemp(prefix="pdf_claims_only_")
        with ThreadPoolExecutor(max_workers=max(1, workers)) as executor:
            futures = [executor.submit(self._trim_one_task, task=task, output_dir=temp_dir) for task in tasks]
            trimmed_tasks: List[Any] = []
            for task, future in zip(tasks, futures):
                result = future.result()
                trimmed_task = type(task)(patent_id=task.patent_id, pdf_path=result["output_path"])
                trimmed_tasks.append(trimmed_task)
                logger.info(
                    "预处理完成 patent_id=%s keep_pages=%s total_pages=%s reason=%s src=%s dst=%s",
                    task.patent_id,
                    result["keep_pages"],
                    result["total_pages"],
                    result["reason"],
                    task.pdf_path,
                    result["output_path"],
                )
                if event_callback:
                    event_callback(
                        {
                            "type": "preprocess_done",
                            "patent_id": task.patent_id,
                            "keep_pages": result["keep_pages"],
                            "total_pages": result["total_pages"],
                            "reason": result["reason"],
                        }
                    )
        return trimmed_tasks, [temp_dir]

    def _trim_one_task(self, task: Any, output_dir: str) -> Dict[str, str]:
        reader = PdfReader(task.pdf_path)
        total_pages = len(reader.pages)
        keep_end_idx, reason = self._detect_keep_end_index(reader=reader)
        keep_count = max(0, keep_end_idx + 1)
        if keep_count <= 0:
            raise ValueError(f"预处理后保留页数为 0: {task.pdf_path}")

        dst = os.path.join(output_dir, f"{task.patent_id}.pdf")
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        writer = PdfWriter()
        for idx in range(keep_count):
            writer.add_page(reader.pages[idx])
        with open(dst, "wb") as fp:
            writer.write(fp)

        return {
            "output_path": os.path.abspath(dst),
            "keep_pages": str(keep_count),
            "total_pages": str(total_pages),
            "reason": reason,
        }

    def trim_one_task(self, task: Any, output_dir: str) -> Dict[str, str]:
        return self._trim_one_task(task=task, output_dir=output_dir)

    def _detect_keep_end_index(self, reader: PdfReader) -> Tuple[int, str]:
        total = len(reader.pages)
        if total == 0:
            return -1, "空PDF"

        seen_claim = False
        last_claim_idx = -1
        first_description_idx = -1

        for idx, page in enumerate(reader.pages):
            page_text = page.extract_text() or ""
            normalized_text = self._norm_text(page_text)
            if self._is_claim_page(page_text=page_text, normalized_text=normalized_text):
                seen_claim = True
                last_claim_idx = idx
            if seen_claim and self._is_description_page(page_text=page_text):
                first_description_idx = idx
                break

        if first_description_idx >= 0:
            return first_description_idx - 1, f"命中说明书起始页 p{first_description_idx + 1}"
        if last_claim_idx >= 0:
            return last_claim_idx, f"仅命中权利要求页，保留到 p{last_claim_idx + 1}"
        return total - 1, "未识别到边界，保留全文"

    def _norm_text(self, text: str) -> str:
        return "".join(text.replace("\u3000", " ").split())

    def _is_claim_page(self, page_text: str, normalized_text: str) -> bool:
        compact_lines = ["".join(line.split()) for line in page_text.splitlines() if line.strip()]
        if any("权利要求书" in line for line in compact_lines):
            return True
        if "其特征在于" in normalized_text or "如权利要求" in normalized_text or "根据权利要求" in normalized_text:
            return True
        if re.search(r"^\s*1\s*[\.、]", page_text[:120]) and "特征在于" in normalized_text:
            return True
        return False

    def _is_description_page(self, page_text: str) -> bool:
        compact_lines = ["".join(line.split()) for line in page_text.splitlines() if line.strip()]
        heading_markers = {"技术领域", "背景技术", "发明内容", "附图说明", "具体实施方式"}
        if any(line in heading_markers for line in compact_lines):
            return True
        if any("说明书附图" in line for line in compact_lines):
            return True
        if re.search(r"(?m)^\s*\[\s*0{0,3}1\s*\]", page_text):
            return True
        return False
