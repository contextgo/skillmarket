import logging
import os
import shutil
from typing import Any, Callable, Dict, Optional

from md_to_json_service import MDToJSONService
from mineru_client import MinerUClient
from pdf_extract_service import PDFExtractService

logger = logging.getLogger(__name__)


class PDFImportService:
    def __init__(self, mineru_client: Optional[MinerUClient] = None):
        self.mineru_client = mineru_client or MinerUClient()
        self.extract_service = PDFExtractService(mineru_client=self.mineru_client)
        self.json_service = MDToJSONService()

    def import_input(
        self,
        input_path: str,
        output_dir: str,
        workers: int = 4,
        mode: str = "auto",
        page_range: Optional[str] = None,
        retry: int = 2,
        timeout_sec: int = 600,
        no_json: bool = False,
        id_regex: Optional[str] = None,
        keep_tmp: bool = False,
        progress_callback: Optional[Callable[..., None]] = None,
    ) -> Dict[str, Any]:
        input_path = os.path.abspath(input_path)
        tasks, tmp_dirs = self.extract_service.build_tasks(input_path=input_path, id_regex=id_regex)
        total = len(tasks)
        if total == 0:
            raise ValueError(f"未发现可处理 PDF：{input_path}")

        os.makedirs(output_dir, exist_ok=True)

        if progress_callback:
            progress_callback(event="phase", name="extract", total=total)

        extract_result = self.extract_service.run_extract(
            tasks=tasks,
            output_dir=output_dir,
            mode=mode,
            workers=workers,
            page_range=page_range,
            retry=retry,
            timeout_sec=timeout_sec,
            progress_callback=progress_callback,
        )

        json_output_dir = os.path.join(output_dir, "json")
        if not no_json:
            if progress_callback:
                progress_callback(event="phase", name="json_export", total=total)

            export_done = 0
            for item in extract_result["items"]:
                if progress_callback:
                    progress_callback(event="start", item=item.get("patent_id", ""))
                self.json_service.export_success_item(
                    item=item,
                    output_dir=json_output_dir,
                )
                export_done += 1
                if progress_callback:
                    progress_callback(event="done", done=export_done, success=export_done, failed=0)

            for item in extract_result["errors"]:
                if progress_callback:
                    progress_callback(event="start", item=item.get("patent_id", ""))
                self.json_service.export_failed_item(
                    item=item,
                    output_dir=json_output_dir,
                    provider=item.get("provider", "pipeline" if mode == "local" else "vlm"),
                )
                export_done += 1
                if progress_callback:
                    progress_callback(event="done", done=export_done, success=len(extract_result["items"]), failed=export_done - len(extract_result["items"]))

        result: Dict[str, Any] = {
            "total": total,
            "success_count": extract_result["success_count"],
            "failed_count": extract_result["failed_count"],
            "errors": extract_result["errors"],
            "output_dir": os.path.abspath(output_dir),
            "json_output_dir": os.path.abspath(json_output_dir) if not no_json else "",
        }

        if not keep_tmp:
            for temp_dir in tmp_dirs:
                shutil.rmtree(temp_dir, ignore_errors=True)

        return result

    def count_input_tasks(self, input_path: str, id_regex: Optional[str] = None) -> int:
        return self.extract_service.count_input_tasks(input_path=input_path, id_regex=id_regex)

    def health_check(self, mineru_mode: Optional[str] = None) -> Dict[str, Any]:
        return self.mineru_client.health_check(mode=mineru_mode)
