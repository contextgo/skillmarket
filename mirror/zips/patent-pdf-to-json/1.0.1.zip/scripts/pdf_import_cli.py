import argparse
import logging
import os
import sys
import threading
from typing import Any, Dict

from pdf_import_service import PDFImportService
from tqdm import tqdm


def _build_log_path(output_dir: str) -> str:
    return os.path.join(os.path.abspath(output_dir), "pdf_import.log")


def _setup_file_logger(log_path: str) -> None:
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    root_logger.addHandler(file_handler)


def _str_to_bool(value: str) -> bool:
    return value.lower() in ("true", "1", "yes", "on")


def _format_local_trace(trace: Any) -> str:
    if not isinstance(trace, list) or not trace:
        return ""
    step_map: Dict[str, Dict[str, Any]] = {
        str(item.get("step", "")): item
        for item in trace
        if isinstance(item, dict) and item.get("step")
    }
    phase_pairs = [
        ("startup", "api_spawn"),
        ("submit", "task_submit"),
        ("model_init", "model_init_done"),
        ("inference", "batch_done"),
        ("total", "process_end"),
    ]
    chunks = []
    for label, step_key in phase_pairs:
        entry = step_map.get(step_key)
        if not entry:
            continue
        val = float(entry.get("offset_sec", 0.0)) if label == "total" else float(entry.get("delta_sec", 0.0))
        chunks.append(f"{label}={val:.1f}s")
    return " | ".join(chunks)


def main() -> None:
    parser = argparse.ArgumentParser(description="PDF 导入 CLI（ MinerU -> Markdown -> JSON）")
    parser.add_argument("--input", type=str, required=True, help="输入路径：pdf / 目录 / zip")
    parser.add_argument("--output_dir", type=str, required=True, help="Markdown 输出目录（JSON 在其 json/ 子目录）")
    parser.add_argument("--workers", type=int, default=None, help="并发线程数（每 PDF 一个线程，建议不超过 2）")
    parser.add_argument("--threads", type=int, default=None, help="并发线程数（--workers 别名）")
    parser.add_argument(
        "--mineru_mode",
        type=str,
        default="auto",
        choices=["auto", "local", "cloud"],
        help="MinerU 路由模式：auto(默认, local优先) / local / cloud",
    )
    parser.add_argument("--mode", type=str, default="", choices=["", "auto", "local", "cloud"], help=argparse.SUPPRESS)
    parser.add_argument("--page_range", type=str, default="", help="页范围透传，如 1-20")
    parser.add_argument("--retry", type=int, default=2, help="失败重试次数")
    parser.add_argument("--timeout_sec", type=int, default=600, help="单任务超时秒数（local 模式仅参考）")
    parser.add_argument("--no_json", type=str, default="off", help="仅输出 md，不输出 json（on/off）")
    parser.add_argument("--id_regex", type=str, default="", help="从文件名提取 patent_id 的正则")
    parser.add_argument("--keep_tmp", type=str, default="off", help="保留 ZIP 临时解压目录（on/off）")
    args = parser.parse_args()

    mineru_mode = args.mode or args.mineru_mode
    workers = args.workers if args.workers is not None else args.threads
    if workers is None:
        workers = 2
    no_json = _str_to_bool(args.no_json)
    keep_tmp = _str_to_bool(args.keep_tmp)

    log_path = _build_log_path(output_dir=args.output_dir)
    _setup_file_logger(log_path)
    logger = logging.getLogger(__name__)
    logger.info(
        "启动 PDF 导入任务 input=%s output_dir=%s mineru_mode=%s",
        args.input,
        args.output_dir,
        mineru_mode,
    )

    service = PDFImportService()
    health = service.health_check(mineru_mode=mineru_mode)
    logger.info("MinerU 健康检查通过 requested_mode=%s runtime_mode=%s", health["requested_mode"], health["runtime_mode"])
    estimated_total = 1
    try:
        estimated_total = max(1, service.count_input_tasks(input_path=args.input, id_regex=args.id_regex or None))
    except Exception:
        estimated_total = 1

    progress_state: Dict[str, Any] = {"phase": "init", "total": estimated_total, "done": 0, "success": 0, "failed": 0}
    progress_lock = threading.Lock()

    try:
        with tqdm(total=estimated_total, desc="[init]", unit="file", dynamic_ncols=True, leave=True) as pbar:
            def on_progress(event: str, **kwargs: Any) -> None:
                with progress_lock:
                    if event == "phase":
                        progress_state["phase"] = kwargs.get("name", progress_state["phase"])
                        phase_total = int(kwargs.get("total", progress_state["total"]))
                        progress_state["total"] = max(0, phase_total)
                        progress_state["done"] = 0
                        progress_state["success"] = 0
                        progress_state["failed"] = 0
                        pbar.set_description(f"[{progress_state['phase']}]")
                        pbar.reset(total=max(1, progress_state["total"]))
                        pbar.set_postfix({"ok": 0, "err": 0}, refresh=False)
                        return
                    if event == "trace":
                        patent_id = str(kwargs.get("patent_id", ""))
                        backend = str(kwargs.get("backend", ""))
                        trace_msg = _format_local_trace(kwargs.get("trace"))
                        if trace_msg:
                            tqdm.write(f"[trace] {patent_id} backend={backend} {trace_msg}")
                        return
                    if event != "done":
                        return
                    new_done = int(kwargs.get("done", progress_state["done"]))
                    if new_done < progress_state["done"]:
                        return
                    increment = new_done - progress_state["done"]
                    progress_state["done"] = new_done
                    progress_state["success"] = int(kwargs.get("success", progress_state["success"]))
                    progress_state["failed"] = int(kwargs.get("failed", progress_state["failed"]))
                    pbar.set_postfix({"ok": progress_state["success"], "err": progress_state["failed"]}, refresh=False)
                    if increment > 0:
                        pbar.update(increment)

            result = service.import_input(
                input_path=args.input,
                output_dir=args.output_dir,
                workers=workers,
                mode=mineru_mode,
                page_range=args.page_range or None,
                retry=args.retry,
                timeout_sec=args.timeout_sec,
                no_json=no_json,
                id_regex=args.id_regex or None,
                keep_tmp=keep_tmp,
                progress_callback=on_progress,
            )
            if pbar.n < pbar.total:
                pbar.update(pbar.total - pbar.n)
    except Exception as exc:
        logger.exception("PDF 导入任务异常")
        sys.exit(1)

    logger.info("PDF 导入完成 result=%s", result)

    if result.get("failed_count", 0) > 0:
        sys.exit(2)


if __name__ == "__main__":
    main()
