import json
import logging
import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class MDTask:
    patent_id: str
    md_path: str


class MDToJSONService:
    def __init__(self, output_dir: Optional[str] = None):
        self.output_dir = output_dir

    def export_success_item(self, item: Dict[str, Any], output_dir: str) -> str:
        md_path = item.get("md_path", "")
        markdown = ""
        if md_path and os.path.exists(md_path):
            with open(md_path, "r", encoding="utf-8", errors="replace") as fp:
                markdown = fp.read()

        metadata = self._build_success_metadata(
            patent_id=item.get("patent_id", ""),
            markdown=markdown,
            schema_version="v1",
            raw_data={
                "task_id": item.get("task_id", ""),
                "provider": item.get("provider", ""),
                "runtime_mode": item.get("runtime_mode") or "",
                "md_path": md_path,
                "source_file": item.get("file_path", ""),
            },
        )
        return self._write_json(patent_id=metadata.get("patent_id", ""), data=metadata, output_dir=output_dir)

    def export_failed_item(self, item: Dict[str, Any], output_dir: str, provider: str) -> str:
        metadata = self._build_failed_metadata(
            patent_id=item.get("patent_id", ""),
            error=item.get("error", "unknown error"),
            schema_version="v1",
            raw_data={
                "provider": provider,
                "runtime_mode": "",
                "md_path": "",
                "source_file": item.get("file_path", ""),
            },
        )
        return self._write_json(patent_id=metadata.get("patent_id", ""), data=metadata, output_dir=output_dir)

    def export_markdown_file(
        self,
        md_path: str,
        output_dir: str,
        schema_version: str = "v1",
        strict: bool = False,
    ) -> str:
        if not os.path.exists(md_path):
            raise FileNotFoundError(f"Markdown 不存在: {md_path}")
        with open(md_path, "r", encoding="utf-8", errors="replace") as fp:
            markdown = fp.read()
        patent_id = os.path.splitext(os.path.basename(md_path))[0]
        metadata = self._build_success_metadata(
            patent_id=patent_id,
            markdown=markdown,
            schema_version=schema_version,
            raw_data={
                "task_id": "",
                "provider": "",
                "runtime_mode": "",
                "md_path": os.path.abspath(md_path),
                "source_file": "",
            },
        )
        if strict:
            self._validate_required_fields(metadata)
        return self._write_json(patent_id=patent_id, data=metadata, output_dir=output_dir)

    def build_md_tasks(self, input_path: str, id_regex: Optional[str] = None) -> List[MDTask]:
        input_path = os.path.abspath(input_path)
        task_files: List[str] = []
        if input_path.lower().endswith(".md"):
            if not os.path.exists(input_path):
                raise FileNotFoundError(f"输入文件不存在: {input_path}")
            task_files = [input_path]
        elif os.path.isdir(input_path):
            task_files = self._collect_mds(input_path)
        else:
            raise ValueError("`--input` 仅支持 .md / 目录")

        regex = re.compile(id_regex) if id_regex else None
        tasks: List[MDTask] = []
        for md_path in task_files:
            stem = os.path.splitext(os.path.basename(md_path))[0]
            patent_id = stem
            if regex:
                match = regex.search(stem)
                if match:
                    patent_id = match.group(1) if match.groups() else match.group(0)
            tasks.append(MDTask(patent_id=patent_id, md_path=os.path.abspath(md_path)))
        return tasks

    def export_tasks(
        self,
        tasks: List[MDTask],
        output_dir: str,
        schema_version: str = "v1",
        strict: bool = False,
        workers: int = 4,
        progress_callback: Optional[Any] = None,
    ) -> Tuple[int, int, List[Dict[str, str]]]:
        success = 0
        failed = 0
        errors: List[Dict[str, str]] = []
        with ThreadPoolExecutor(max_workers=max(1, workers)) as executor:
            future_to_task = {
                executor.submit(
                    self._export_single_task,
                    task=task,
                    output_dir=output_dir,
                    schema_version=schema_version,
                    strict=strict,
                ): task
                for task in tasks
            }
            for future in as_completed(future_to_task):
                task = future_to_task[future]
                try:
                    future.result()
                    success += 1
                    if progress_callback:
                        progress_callback(done=success + failed, success=success, failed=failed, patent_id=task.patent_id)
                except Exception as exc:
                    failed += 1
                    errors.append({"patent_id": task.patent_id, "md_path": task.md_path, "error": str(exc)})
                    failed_payload = self._build_failed_metadata(
                        patent_id=task.patent_id,
                        error=str(exc),
                        schema_version=schema_version,
                        raw_data={
                            "task_id": "",
                            "provider": "",
                            "runtime_mode": "",
                            "md_path": task.md_path,
                            "source_file": "",
                        },
                    )
                    self._write_json(patent_id=task.patent_id, data=failed_payload, output_dir=output_dir)
                    if progress_callback:
                        progress_callback(done=success + failed, success=success, failed=failed, patent_id=task.patent_id)
        return success, failed, errors

    def _export_single_task(
        self,
        task: MDTask,
        output_dir: str,
        schema_version: str,
        strict: bool,
    ) -> None:
        with open(task.md_path, "r", encoding="utf-8", errors="replace") as fp:
            markdown = fp.read()
        metadata = self._build_success_metadata(
            patent_id=task.patent_id,
            markdown=markdown,
            schema_version=schema_version,
            raw_data={
                "task_id": "",
                "provider": "",
                "runtime_mode": "",
                "md_path": task.md_path,
                "source_file": "",
            },
        )
        if strict:
            self._validate_required_fields(metadata)
        self._write_json(patent_id=task.patent_id, data=metadata, output_dir=output_dir)

    def _build_success_metadata(
        self,
        patent_id: str,
        markdown: str,
        schema_version: str,
        raw_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        metadata = self._extract_metadata(markdown)
        metadata["schema_version"] = schema_version
        metadata["patent_id"] = patent_id
        metadata["status"] = "success"
        metadata["raw_data"] = raw_data
        return metadata

    def _build_failed_metadata(
        self,
        patent_id: str,
        error: str,
        schema_version: str,
        raw_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        return {
            "schema_version": schema_version,
            "patent_id": patent_id,
            "status": "failed",
            "error": error or "unknown error",
            "raw_data": raw_data,
        }

    def _write_json(self, patent_id: str, data: Dict[str, Any], output_dir: str) -> str:
        os.makedirs(output_dir, exist_ok=True)
        safe_id = re.sub(r'[<>:"/\\|?*]', "_", patent_id)
        json_path = os.path.join(output_dir, f"{safe_id}.json")
        with open(json_path, "w", encoding="utf-8") as fp:
            json.dump(data, fp, ensure_ascii=False, indent=2)
        return json_path

    def _extract_metadata(self, markdown: str) -> Dict[str, Any]:
        meta: Dict[str, Any] = {}

        pub_match = re.search(r"\(10\)(?:授权公告号|申请公布号)\s+([A-Za-z0-9\s]+)", markdown)
        if pub_match:
            meta["publication_number"] = pub_match.group(1).replace(" ", "")

        app_match = re.search(r"\(21\)申请号\s+([A-Za-z0-9\.\s]+)", markdown)
        if app_match:
            meta["application_number"] = app_match.group(1).replace(" ", "")

        app_date_match = re.search(r"\(22\)申请日\s+([0-9\.\s]+)", markdown)
        if app_date_match:
            meta["application_date"] = app_date_match.group(1).replace(" ", "")

        pub_date_match = re.search(r"\((?:43|45)\)(?:申请公布日|授权公告日)\s+([0-9\.\s]+)", markdown)
        if pub_date_match:
            meta["publication_date"] = pub_date_match.group(1).replace(" ", "")

        assignee_match = re.search(r"\((?:71|73)\)(?:申请人|专利权人)\s+(.*?)(?=\n|$)", markdown)
        if assignee_match:
            raw_assignee = assignee_match.group(1).strip()
            if "地址" in raw_assignee:
                raw_assignee = raw_assignee.split("地址")[0].strip()
            meta["assignees"] = [raw_assignee]

        inventor_match = re.search(r"\(72\)发明人\s+(.*?)(?=\n|$)", markdown)
        if inventor_match:
            inventors_str = inventor_match.group(1).strip()
            inventors = [v for v in inventors_str.split() if v]
            if not inventors:
                meta["inventors"] = self._split_chinese_names(inventors_str)
            else:
                meta["inventors"] = inventors

        ipc_match = re.search(r"\(51\)Int\s*\.Cl\.?\s*(.*?)(?=\n|$)", markdown)
        if ipc_match:
            ipc_str = ipc_match.group(1).strip()
            meta["ipc_classes"] = self._extract_ipc_classes(ipc_str)

        title_text = self._extract_section(markdown, r"##\s*\(54\)发明名称")
        if title_text:
            meta["title"] = title_text
        abstract_text = self._extract_section(markdown, r"##\s*\(57\)摘要")
        if abstract_text:
            meta["abstract"] = abstract_text

        full_claims = self._extract_claims_section(markdown)
        meta["full_claims"] = full_claims or markdown
        return meta

    def _extract_ipc_classes(self, ipc_line: str) -> List[str]:
        if not ipc_line:
            return []
        parts = re.findall(r"[A-HY]\d{2}[A-Z]?\s*\d+/\d+", ipc_line.upper())
        if parts:
            return [re.sub(r"\s+", "", p) for p in parts]
        return [v for v in ipc_line.split() if v]

    def _extract_section(self, markdown: str, heading_pattern: str) -> str:
        pattern = rf"{heading_pattern}\s*\n+([\s\S]*?)(?=\n##\s*\(|\Z)"
        match = re.search(pattern, markdown)
        if not match:
            return ""
        text = match.group(1).strip()
        lines = [line.strip() for line in text.splitlines()]
        lines = [line for line in lines if line]
        return " ".join(lines).strip()

    def _extract_claims_section(self, markdown: str) -> str:
        match = re.search(r"(##\s*权利要求书[\s\S]*?)(?=\n##\s*说明书|\n##\s*说明书附图|\Z)", markdown)
        if not match:
            return ""
        return match.group(1).strip()

    def _collect_mds(self, dir_path: str) -> List[str]:
        all_files: List[str] = []
        for root, _, files in os.walk(dir_path):
            for name in files:
                if not name.lower().endswith(".md"):
                    continue
                if name.startswith("."):
                    continue
                file_path = os.path.join(root, name)
                if os.path.getsize(file_path) <= 0:
                    continue
                all_files.append(file_path)
        all_files.sort()
        return all_files

    def _validate_required_fields(self, metadata: Dict[str, Any]) -> None:
        required_keys = [
            "patent_id",
            "title",
            "publication_number",
            "application_number",
            "application_date",
            "publication_date",
            "assignees",
            "inventors",
            "ipc_classes",
            "abstract",
            "full_claims",
            "status",
            "raw_data",
        ]
        missing = [key for key in required_keys if key not in metadata or metadata.get(key) in (None, "", [])]
        if missing:
            raise ValueError(f"strict 模式字段缺失: {','.join(missing)}")

    def _split_chinese_names(self, text: str) -> List[str]:
        if not text:
            return []
        text = text.strip()
        if re.match(r"^[\u4e00-\u9fa5]{2,4}$", text):
            return [text]
        text = re.sub(r"[、，,]\s*", " ", text)
        parts = text.split()
        result: List[str] = []
        for part in parts:
            part = part.strip()
            if part:
                result.append(part)
        return result
