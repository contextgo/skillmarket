---
name: "patent-pdf-to-json"
description: "将专利 PDF 按 3 阶段处理：裁剪、提取 Markdown、结构化 JSON。Invoke when user asks to import patent PDFs, extract markdown from PDFs, or convert patents to structured JSON via MinerU."
---

# Patent PDF to JSON Skill

将专利 PDF 转为结构化 JSON，采用 3 个职责单一 CLI：

- `claims-trim`：PDF 裁剪
- `pdf-extract`：MinerU 解析 PDF -> MD
- `md-to-json`：Markdown -> JSON

## 调用时机

当用户出现以下场景时必须调用此 skill：

- "导入专利 PDF"
- "把 PDF 转成 JSON"
- "用 MinerU 解析专利"
- "pdf import"
- "专利 PDF 批量提取"
- 直接提供 PDF 文件并要求处理

## CLI 入口

### 1) claims-trim

```bash
python3 skills/patent-pdf-to-json/scripts/claims_trim_cli.py \
  --input <pdf_path|dir|zip> \
  --output_dir <output_dir>
```

参数：`--input --output_dir --workers --id_regex --overwrite on|off --keep_tmp on|off`

### 2) pdf-extract

```bash
python3 skills/patent-pdf-to-json/scripts/pdf_extract_cli.py \
  --mode local \
  --input <trim_pdf_dir> \
  --output_dir <md_dir> \
  --threads 2 \
  --timeout_sec 600
```

```bash
python3 skills/patent-pdf-to-json/scripts/pdf_extract_cli.py \
  --mode cloud \
  --input <trim_pdf_dir> \
  --output_dir <md_dir> \
  --threads 2 \
  --retry 2
```

参数边界：

- `local/cloud` 共同支持：`--input --output_dir --workers --page_range --timeout_sec --retry`
- `cloud` 缺 token fail-fast
- `local` 模式固定使用本地 `pipeline`，不再支持模型选择参数
- `--timeout_sec` 在 local 模式仅为参考值（MinerU CLI 内部仍有独立超时）

云端网络注意：

- `cloud` 模式下载默认严格启用 SSL 证书校验，不再提供跳过证书校验的回退逻辑。
- 若出现 TLS 握手类错误，优先检查并关闭系统/终端代理后重试；常见根因是代理链路干扰，并不一定表示 token 或主流程参数配置错误。

### 3) md-to-json

```bash
python3 skills/patent-pdf-to-json/scripts/md_to_json_cli.py \
  --input <md_dir> \
  --output_dir <json_dir> \
  --schema_version v1 \
  --workers 4 \
  --strict off
```

参数：`--input --output_dir --schema_version --workers --strict on|off`

## 输出产物

```
trimmed_pdf/*.pdf
md/*.md
json/*.json
```

## JSON 契约

```json
{
  "schema_version": "v1",
  "patent_id": "CN109934380A",
  "title": "发明名称",
  "publication_number": "CN109934380A",
  "application_number": "201910123456.7",
  "application_date": "2019.03.15",
  "publication_date": "2019.07.26",
  "assignees": ["申请人1"],
  "inventors": ["张三", "李四"],
  "ipc_classes": ["H01M10/052"],
  "full_claims": "## 权利要求书\n1. ...",
  "abstract": "摘要内容...",
  "status": "success",
  "raw_data": {
    "task_id": "xxx",
    "provider": "pipeline",
    "runtime_mode": "local",
    "md_path": "/path/to/CN109934380A.md",
    "source_file": "/path/to/CN109934380A.pdf"
  }
}
```

失败项至少包含：`schema_version`, `patent_id`, `status=failed`, `error`, `raw_data`
