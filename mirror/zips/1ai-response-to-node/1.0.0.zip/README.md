# ai-note-summary

> AI 对话链接自动摘要 & 笔记管理技能

将国内主流 AI 平台的对话分享链接，一键转换为结构化本地笔记，按**年月自动归档**，并通过**智能标签**（工具名、协议名、语言名等具体实体）实现精准分类检索。

---

## 功能概览

| 功能 | 说明 |
|------|------|
| 🔗 自动抓取 | 识别 AI 平台分享链接，自动抓取对话内容 |
| 📝 结构化笔记 | 提取问题、答案要点、代码，生成 Markdown 笔记 |
| 🏷️ 智能标签 | 自动识别工具名、协议名、语言名等具体实体作为标签 |
| 🔖 自定义标签 | 发链接时附带 `#tag`，追加到自动标签之后 |
| 📅 时间归档 | 按年月自动归档到 `YYYY-MM/` 子目录，文件名带日期前缀 |
| 🗂️ 全局索引 | 维护 `INDEX.md`，按时间+标签双维度聚合所有笔记 |
| 🔍 笔记查询 | 支持按标签、时间、关键词检索已有笔记 |

---

## 支持平台

| 平台 | 域名 | 备注 |
|------|------|------|
| 元宝 | `yb.tencent.com` | 腾讯混元，静态页面 |
| 千问 | `tongyi.aliyun.com` | 阿里通义千问 |
| 豆包 | `doubao.com` | 字节跳动 |
| Kimi | `kimi.moonshot.cn` | 月之暗面，支持长文本 |
| 文心一言 | `yiyan.baidu.com` | 百度 |
| DeepSeek | `chat.deepseek.com` | 国产开源大模型 |

---

## 快速上手

### 生成笔记

直接将 AI 对话分享链接发送给助手，即可自动触发摘要流程：

```
https://kimi.moonshot.cn/share/xxxxxxxx
```

附带自定义标签（可选）：

```
https://www.doubao.com/share/xxxxxxxx  #工作 #重要

https://chat.deepseek.com/share/xxxxxxxx  [分类:学习] [标签:Python,爬虫]
```

### 查询笔记

```
查看编程相关的笔记
最近一周的笔记
带有 #Python 标签的笔记
我有哪些笔记
```

---

## 标签体系

### 核心原则：标签 = 具体实体

不再使用预设的固定主题分类（如"编程开发"、"工具使用"），改为从对话内容中**智能提取具体实体名词**作为标签，粒度更细、检索更精准。

**示例对比：**

| 对话内容 | ❌ 旧方式（固定主题） | ✅ 新方式（智能标签） |
|---------|------------------|------------------|
| 在 Linux 中如何使用 iperf | 工具使用 | `#Linux` `#iperf` `#网络测试` |
| 如何在交换机配置 OSPF | 编程开发 / 其他 | `#网络` `#交换机` `#OSPF` `#路由协议` |
| 如何用 Python 控制谷歌浏览器 | 编程开发 | `#Python` `#Chrome` `#浏览器自动化` |
| Docker 容器网络怎么配置 | 编程开发 | `#Docker` `#容器` `#网络` |

### 自动提取的标签类型

| 类型 | 示例 |
|------|------|
| 操作系统 / 平台 | `#Linux` `#Windows` `#macOS` `#Android` |
| 编程语言 | `#Python` `#JavaScript` `#Go` `#Bash` |
| 工具 / 命令 | `#iperf` `#tcpdump` `#Git` `#Docker` `#ffmpeg` |
| 网络协议 / 技术 | `#OSPF` `#BGP` `#HTTP` `#TCP` `#DNS` `#VLAN` |
| 产品 / 软件 | `#Chrome` `#Nginx` `#MySQL` `#Redis` `#VSCode` |
| 网络设备 | `#交换机` `#路由器` `#防火墙` |
| 框架 / 库 | `#React` `#Selenium` `#FastAPI` |

每条笔记自动提取 **3-6 个**标签，优先具体实体名词，不足时补充概念标签。

### 自定义标签

发链接时附带，追加到自动标签之后（两者共存，不互相覆盖）：

```
https://xxx.com/share/abc  #重要 #工作
```

### 时间归档

笔记按 **年-月** 自动归入子目录：

```
memory/ai-notes/
├── INDEX.md                    # 全局索引（时间 + 标签）
├── 2026-03/
│   ├── 2026-03-20_Linux中iperf网络测试.md
│   ├── 2026-03-19_交换机OSPF配置.md
│   └── 2026-03-18_Python控制谷歌浏览器.md
└── 2026-02/
    └── ...
```

---

## 笔记格式

每条笔记保存为独立 Markdown 文件，格式如下：

```markdown
# AI 对话笔记 - <标题>

> 来源: <平台名>
> 日期: YYYY-MM-DD
> 生成时间: YYYY-MM-DD HH:MM
> 标签: #Linux #iperf #网络测试

## 问题
<用户提问>

## 答案总结
<AI 回答要点>

### 关键点
- point 1
- point 2

### 代码（如有）
```语言
代码块
```
```

---

## 文件结构

### 笔记存储目录

笔记保存在工作区的 `memory/ai-notes/` 下，实际绝对路径因操作系统不同而异：

| 操作系统 | 笔记根目录路径 |
|---------|--------------|
| Windows | `%USERPROFILE%\<工作区路径>\memory\ai-notes\` |
| macOS | `~/<工作区路径>/memory/ai-notes/` |
| Linux | `~/<工作区路径>/memory/ai-notes/` |

> 若未指定工作区，默认存放在 AI 助手的当前会话工作区目录下。

### 目录树

```
memory/ai-notes/
├── INDEX.md                    # 全局索引（时间 + 标签双维度）
├── 2026-03/                    # 按年月归档
│   ├── 2026-03-20_Linux中iperf网络测试.md
│   ├── 2026-03-19_交换机OSPF配置.md
│   └── 2026-03-18_Python控制谷歌浏览器.md
├── 2026-02/
│   └── ...
└── 2026-01/
    └── ...
```

---

## 触发条件

| 场景 | 触发示例 |
|------|---------|
| 粘贴分享链接 | `https://kimi.moonshot.cn/share/xxx` |
| 明确请求摘要 | "总结这个对话"、"帮我记录一下" |
| 查询已有笔记 | "查看我的笔记"、"最近的笔记有哪些" |
| 标签/主题检索 | "#Python 的笔记"、"编程相关笔记" |

---

## 注意事项

- 国内 AI 平台分享链接通常**需要公开可访问**，登录限制的链接无法抓取
- 抓取失败时会提示用户检查链接是否有效
- 标签优先提取**具体实体名词**，避免"编程"、"工具"等过于宽泛的标签
- 索引文件 `INDEX.md` 采用追加方式更新，不做整体重写，避免数据丢失
- 自定义标签与自动标签共存，不互相覆盖

---

## 安装方式

### 方式一：WorkBuddy 内置（推荐）

WorkBuddy 用户直接在「专家中心 → Skills」搜索 `ai-note-summary` 一键安装，无需额外配置。

确保已启用 `browser` 工具权限（用于抓取动态页面）。

---

### 方式二：OpenClaw / ClawHub 安装

**通过 ClawHub 命令行安装：**

```bash
clawhub install ai-note-summary
```

**更新到最新版本：**

```bash
clawhub update ai-note-summary
# 或更新全部 Skills
clawhub update --all
```

**安装后 Skill 的存储路径：**

| 操作系统 | 默认安装路径 |
|---------|------------|
| Windows | `%USERPROFILE%\.openclaw\skills\ai-note-summary\` |
| macOS | `~/.openclaw/skills/ai-note-summary/` |
| Linux | `~/.openclaw/skills/ai-note-summary/` |

> 也可安装到工作区级别（仅当前项目可用）：`<workspace>/skills/ai-note-summary/`

---

### 方式三：手动安装（通用）

适用于 WorkBuddy、OpenClaw 及其他兼容 AgentSkills 标准的客户端。

**步骤：**

1. 下载或克隆本仓库：

   ```bash
   git clone https://github.com/your-repo/ai-note-summary.skill.git
   ```

2. 将文件夹复制到对应客户端的 Skills 目录：

   **WorkBuddy：**

   | 操作系统 | 路径 |
   |---------|------|
   | Windows | `%USERPROFILE%\.workbuddy\skills\` |
   | macOS | `~/.workbuddy/skills/` |
   | Linux | `~/.workbuddy/skills/` |

   **OpenClaw：**

   | 操作系统 | 路径 |
   |---------|------|
   | Windows | `%USERPROFILE%\.openclaw\skills\` |
   | macOS / Linux | `~/.openclaw/skills/` |

3. 重启客户端或开启新会话后生效。

---

### 方式四：配置自定义目录（OpenClaw）

如果你希望将 Skills 存放在其他位置，可以在 `~/.openclaw/openclaw.json` 中指定：

```json
{
  "skills": {
    "load": {
      "extraDirs": ["/your/custom/skills/path"]
    }
  }
}
```

Windows 路径写法：

```json
{
  "skills": {
    "load": {
      "extraDirs": ["C:\\Users\\YourName\\MySkills"]
    }
  }
}
```

---

### 加载优先级（OpenClaw）

当同名 Skill 存在于多个位置时，优先级从高到低为：

```
工作区 Skills  >  用户主目录 Skills  >  内置 Skills
<workspace>/skills  >  ~/.openclaw/skills  >  内置
```

---

## License

MIT
