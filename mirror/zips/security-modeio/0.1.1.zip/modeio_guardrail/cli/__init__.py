"""CLI entrypoints for security."""
