"""
Habit-Loop 测试套件
"""

import unittest
import sys
from pathlib import Path

# 添加 scripts 到路径
sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))

from habit_store import get_habit_store
from habit_detector import get_habit_detector
from habit_executor import get_habit_executor


class TestHabitStore(unittest.TestCase):
    """测试习惯存储"""
    
    def setUp(self):
        self.store = get_habit_store()
    
    def test_create_habit(self):
        """测试创建习惯"""
        habit = self.store.create_habit(
            trigger="用户说'做PPT'",
            action_sequence=["加载PPT skill", "应用模板"],
            confidence=0.5
        )
        
        self.assertIsNotNone(habit.id)
        self.assertEqual(habit.trigger, "用户说'做PPT'")
        self.assertEqual(len(habit.action_sequence), 2)
        self.assertFalse(habit.auto_confirmed)
    
    def test_find_matching_habit(self):
        """测试查找习惯"""
        self.store.create_habit(
            trigger="做PPT 简历",
            action_sequence=["加载PPT"],
            confidence=0.8
        )
        
        match = self.store.find_matching_habit("帮我做PPT简历")
        self.assertIsNotNone(match)
    
    def test_record_trigger(self):
        """测试记录触发"""
        habit = self.store.create_habit(
            trigger="测试",
            action_sequence=["动作"],
            confidence=0.5
        )
        
        self.store.record_trigger(habit.id, success=True)
        updated = self.store.get_habit(habit.id)
        
        self.assertEqual(updated.trigger_count, 1)
        self.assertGreater(updated.confidence, 0.5)


class TestHabitDetector(unittest.TestCase):
    """测试习惯检测"""
    
    def setUp(self):
        self.detector = get_habit_detector()
    
    def test_record_task(self):
        """测试记录任务"""
        # 记录任务
        result = self.detector.record_task("帮我做PPT", ["加载PPT"])
        
        # 返回结果可能是习惯对象或None，取决于实现
        # 重点是测试方法能正常执行不报错
        self.assertTrue(result is None or hasattr(result, 'id'))
    
    def test_analyze_patterns(self):
        """测试模式分析"""
        self.detector.record_task("测试任务", ["动作1"])
        reports = self.detector.analyze_patterns()
        
        self.assertTrue(len(reports) > 0)


class TestHabitExecutor(unittest.TestCase):
    """测试习惯执行"""
    
    def setUp(self):
        self.executor = get_habit_executor()
    
    def test_try_execute_no_match(self):
        """测试无匹配习惯"""
        result = self.executor.try_execute("完全不相关的输入")
        
        self.assertFalse(result.success)
        self.assertIsNone(result.habit_id)
    
    def test_get_execution_summary(self):
        """测试执行摘要"""
        summary = self.executor.get_execution_summary()
        
        self.assertIn("total_habits", summary)
        self.assertIn("confirmed_habits", summary)


if __name__ == "__main__":
    unittest.main()
