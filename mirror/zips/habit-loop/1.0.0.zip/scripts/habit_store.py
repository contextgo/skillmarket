"""
习惯存储管理
管理 habit-store.json 的读写和习惯生命周期
"""

import json
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional
from datetime import datetime, timedelta


@dataclass
class Habit:
    """习惯对象"""
    id: str
    trigger: str
    action_sequence: List[str]
    confidence: float
    trigger_count: int
    last_used: str
    skip_precheck: bool
    created_at: str
    auto_confirmed: bool
    violations: int = 0
    
    def to_dict(self) -> dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Habit':
        return cls(**data)


class HabitStore:
    """习惯存储管理器"""
    
    CONFIDENCE_DECAY_DAYS = 30
    AUTO_PROMOTE_THRESHOLD = 5
    MIN_CONFIDENCE = 0.3
    
    def __init__(self, data_dir: Optional[Path] = None):
        if data_dir is None:
            data_dir = Path.home() / ".workbuddy" / "dreams"
        self.data_dir = data_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.store_file = self.data_dir / "habit-store.json"
        self.archive_file = self.data_dir / "habit-archive.json"
        self.habits: Dict[str, Habit] = {}
        self._load_store()
    
    def _load_store(self):
        """加载习惯库"""
        if self.store_file.exists():
            try:
                with open(self.store_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for h_data in data.get("habits", []):
                        habit = Habit.from_dict(h_data)
                        self.habits[habit.id] = habit
            except (json.JSONDecodeError, UnicodeDecodeError):
                pass
    
    def _save_store(self):
        """保存习惯库"""
        with open(self.store_file, 'w', encoding='utf-8') as f:
            json.dump({
                "habits": [h.to_dict() for h in self.habits.values()],
                "confidence_decay_days": self.CONFIDENCE_DECAY_DAYS,
                "auto_promote_threshold": self.AUTO_PROMOTE_THRESHOLD,
                "updated_at": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
    
    def create_habit(self, trigger: str, action_sequence: List[str],
                    confidence: float = 0.5) -> Habit:
        """
        创建新习惯
        
        Args:
            trigger: 触发条件
            action_sequence: 动作序列
            confidence: 初始置信度
            
        Returns:
            新习惯对象
        """
        habit_id = f"h{len(self.habits)+1:03d}"
        timestamp = datetime.now().strftime("%Y-%m-%d")
        
        habit = Habit(
            id=habit_id,
            trigger=trigger,
            action_sequence=action_sequence,
            confidence=confidence,
            trigger_count=0,
            last_used=timestamp,
            skip_precheck=False,
            created_at=timestamp,
            auto_confirmed=False
        )
        
        self.habits[habit_id] = habit
        self._save_store()
        
        return habit
    
    def get_habit(self, habit_id: str) -> Optional[Habit]:
        """获取习惯"""
        return self.habits.get(habit_id)
    
    def find_matching_habit(self, user_input: str) -> Optional[Habit]:
        """
        查找匹配的习惯
        
        Args:
            user_input: 用户输入
            
        Returns:
            匹配的习惯或 None
        """
        user_lower = user_input.lower()
        
        for habit in self.habits.values():
            # 简单关键词匹配
            trigger_keywords = habit.trigger.lower().split()
            match_count = sum(1 for kw in trigger_keywords if kw in user_lower)
            
            # 如果匹配度足够高
            if match_count >= len(trigger_keywords) * 0.5:
                return habit
        
        return None
    
    def record_trigger(self, habit_id: str, success: bool = True):
        """
        记录习惯触发
        
        Args:
            habit_id: 习惯ID
            success: 是否成功执行
        """
        if habit_id not in self.habits:
            return
        
        habit = self.habits[habit_id]
        habit.trigger_count += 1
        habit.last_used = datetime.now().strftime("%Y-%m-%d")
        
        if success:
            # 成功执行，提升置信度
            habit.confidence = min(0.95, habit.confidence + 0.05)
            
            # 达到阈值，自动确认
            if habit.trigger_count >= self.AUTO_PROMOTE_THRESHOLD:
                habit.auto_confirmed = True
                habit.skip_precheck = True
        
        self._save_store()
    
    def record_violation(self, habit_id: str):
        """
        记录习惯违反
        
        Args:
            habit_id: 习惯ID
        """
        if habit_id not in self.habits:
            return
        
        habit = self.habits[habit_id]
        habit.violations += 1
        habit.confidence -= 0.1
        
        # 置信度太低，暂停习惯
        if habit.confidence < self.MIN_CONFIDENCE:
            self._archive_habit(habit_id)
        else:
            self._save_store()
    
    def _archive_habit(self, habit_id: str):
        """归档习惯"""
        if habit_id not in self.habits:
            return
        
        habit = self.habits.pop(habit_id)
        
        # 加载归档
        archived = []
        if self.archive_file.exists():
            try:
                with open(self.archive_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    archived = data.get("habits", [])
            except:
                pass
        
        # 添加归档
        archived.append(habit.to_dict())
        
        with open(self.archive_file, 'w', encoding='utf-8') as f:
            json.dump({
                "habits": archived,
                "archived_at": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
        
        self._save_store()
    
    def apply_decay(self):
        """应用置信度衰减"""
        today = datetime.now()
        habits_to_archive = []
        
        for habit_id, habit in self.habits.items():
            last_used = datetime.strptime(habit.last_used, "%Y-%m-%d")
            days_since = (today - last_used).days
            
            if days_since > self.CONFIDENCE_DECAY_DAYS:
                # 计算衰减月数
                months = days_since // self.CONFIDENCE_DECAY_DAYS
                decay_factor = 0.9 ** months
                habit.confidence *= decay_factor
                
                if habit.confidence < self.MIN_CONFIDENCE:
                    habits_to_archive.append(habit_id)
        
        # 归档低置信度习惯
        for habit_id in habits_to_archive:
            self._archive_habit(habit_id)
        
        self._save_store()
    
    def get_all_habits(self) -> List[Habit]:
        """获取所有习惯"""
        return list(self.habits.values())
    
    def get_confirmed_habits(self) -> List[Habit]:
        """获取已确认的习惯"""
        return [h for h in self.habits.values() if h.auto_confirmed]


# 单例模式
_habit_store_instance: Optional[HabitStore] = None


def get_habit_store() -> HabitStore:
    """获取习惯存储单例"""
    global _habit_store_instance
    if _habit_store_instance is None:
        _habit_store_instance = HabitStore()
    return _habit_store_instance
