"""
习惯执行器
执行匹配的习惯，处理执行流程
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from habit_store import get_habit_store, Habit


@dataclass
class ExecutionResult:
    """执行结果"""
    success: bool
    habit_id: Optional[str]
    actions_executed: List[str]
    message: str
    skipped_precheck: bool


class HabitExecutor:
    """习惯执行器"""
    
    HIGH_CONFIDENCE_THRESHOLD = 0.8
    
    def __init__(self):
        self.store = get_habit_store()
    
    def try_execute(self, user_input: str) -> ExecutionResult:
        """
        尝试执行习惯
        
        Args:
            user_input: 用户输入
            
        Returns:
            执行结果
        """
        # 查找匹配的习惯
        habit = self.store.find_matching_habit(user_input)
        
        if not habit:
            return ExecutionResult(
                success=False,
                habit_id=None,
                actions_executed=[],
                message="未匹配到习惯",
                skipped_precheck=False
            )
        
        # 检查置信度
        if habit.confidence >= self.HIGH_CONFIDENCE_THRESHOLD and habit.auto_confirmed:
            # 高置信度，直接执行
            return self._execute_habit(habit, skip_precheck=True)
        elif habit.confidence >= 0.5:
            # 中等置信度，需要确认
            return ExecutionResult(
                success=False,
                habit_id=habit.id,
                actions_executed=[],
                message=f"检测到习惯 '{habit.trigger}'，是否按此执行？（置信度: {habit.confidence:.0%}）",
                skipped_precheck=False
            )
        else:
            # 低置信度，不执行
            return ExecutionResult(
                success=False,
                habit_id=habit.id,
                actions_executed=[],
                message=f"习惯置信度太低 ({habit.confidence:.0%})，需要重新学习",
                skipped_precheck=False
            )
    
    def _execute_habit(self, habit: Habit, skip_precheck: bool = False) -> ExecutionResult:
        """
        执行习惯
        
        Args:
            habit: 习惯对象
            skip_precheck: 是否跳过预检查
            
        Returns:
            执行结果
        """
        # 记录触发
        self.store.record_trigger(habit.id, success=True)
        
        # 模拟执行动作序列
        executed = []
        for i, action in enumerate(habit.action_sequence):
            executed.append(f"[{i+1}] {action}")
        
        return ExecutionResult(
            success=True,
            habit_id=habit.id,
            actions_executed=executed,
            message=f"习惯 '{habit.id}' 执行完成（触发次数: {habit.trigger_count + 1}）",
            skipped_precheck=skip_precheck
        )
    
    def confirm_and_execute(self, habit_id: str) -> ExecutionResult:
        """
        确认后执行习惯
        
        Args:
            habit_id: 习惯ID
            
        Returns:
            执行结果
        """
        habit = self.store.get_habit(habit_id)
        if not habit:
            return ExecutionResult(
                success=False,
                habit_id=None,
                actions_executed=[],
                message=f"习惯 {habit_id} 不存在",
                skipped_precheck=False
            )
        
        return self._execute_habit(habit, skip_precheck=False)
    
    def bypass_habit(self, habit_id: str, actual_actions: List[str]):
        """
        绕过习惯，记录差异
        
        Args:
            habit_id: 习惯ID
            actual_actions: 实际执行的动作
        """
        habit = self.store.get_habit(habit_id)
        if not habit:
            return
        
        # 记录违反
        self.store.record_violation(habit_id)
        
        # 分析差异（简化实现）
        original = set(habit.action_sequence)
        actual = set(actual_actions)
        
        if original != actual:
            # 动作序列有差异，可能需要更新习惯
            pass
    
    def get_execution_summary(self) -> Dict:
        """获取执行摘要"""
        habits = self.store.get_all_habits()
        confirmed = self.store.get_confirmed_habits()
        
        return {
            "total_habits": len(habits),
            "confirmed_habits": len(confirmed),
            "high_confidence_habits": len([h for h in habits if h.confidence >= 0.8]),
            "total_triggers": sum(h.trigger_count for h in habits)
        }


# 单例模式
_habit_executor_instance: Optional[HabitExecutor] = None


def get_habit_executor() -> HabitExecutor:
    """获取习惯执行器单例"""
    global _habit_executor_instance
    if _habit_executor_instance is None:
        _habit_executor_instance = HabitExecutor()
    return _habit_executor_instance
