"""
习惯检测器
检测高频任务模式，自动创建习惯候选
"""

import json
from pathlib import Path
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
from collections import defaultdict
from datetime import datetime

from habit_store import get_habit_store, Habit


@dataclass
class TaskPattern:
    """任务模式"""
    pattern_key: str
    trigger_keywords: List[str]
    action_signature: str
    count: int
    last_seen: str


class HabitDetector:
    """习惯检测器"""
    
    DETECTION_THRESHOLD = 3  # 触发3次开始检测
    CONFIRMATION_THRESHOLD = 5  # 触发5次自动确认
    
    def __init__(self, data_dir: Optional[Path] = None):
        if data_dir is None:
            data_dir = Path.home() / ".workbuddy"
        self.data_dir = data_dir
        
        self.tracker_file = self.data_dir / "task-frequency-tracker.json"
        self.patterns: Dict[str, TaskPattern] = {}
        self._load_tracker()
    
    def _load_tracker(self):
        """加载任务频率追踪器"""
        if self.tracker_file.exists():
            try:
                with open(self.tracker_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for key, p_data in data.get("patterns", {}).items():
                        self.patterns[key] = TaskPattern(
                            pattern_key=key,
                            trigger_keywords=p_data.get("trigger_keywords", []),
                            action_signature=p_data.get("action_signature", ""),
                            count=p_data.get("count", 0),
                            last_seen=p_data.get("last_seen", "")
                        )
            except (json.JSONDecodeError, UnicodeDecodeError):
                pass
    
    def _save_tracker(self):
        """保存任务频率追踪器"""
        with open(self.tracker_file, 'w', encoding='utf-8') as f:
            json.dump({
                "patterns": {
                    key: {
                        "trigger_keywords": p.trigger_keywords,
                        "action_signature": p.action_signature,
                        "count": p.count,
                        "last_seen": p.last_seen
                    }
                    for key, p in self.patterns.items()
                },
                "updated_at": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
    
    def _extract_pattern_key(self, user_input: str) -> str:
        """提取模式键"""
        # 简化实现：取前3个关键词
        words = user_input.lower().split()[:3]
        return "_".join(words)
    
    def _extract_keywords(self, user_input: str) -> List[str]:
        """提取关键词"""
        # 简化实现：过滤停用词
        stop_words = {"帮我", "请", "一下", "一个", "这个", "那个"}
        words = user_input.lower().split()
        return [w for w in words if w not in stop_words][:5]
    
    def record_task(self, user_input: str, actions: List[str]) -> Optional[Habit]:
        """
        记录任务，检测模式
        
        Args:
            user_input: 用户输入
            actions: 执行的动作列表
            
        Returns:
            如果形成新习惯则返回习惯对象
        """
        pattern_key = self._extract_pattern_key(user_input)
        keywords = self._extract_keywords(user_input)
        action_signature = "|".join(actions)
        
        today = datetime.now().strftime("%Y-%m-%d")
        
        if pattern_key in self.patterns:
            # 更新现有模式
            pattern = self.patterns[pattern_key]
            pattern.count += 1
            pattern.last_seen = today
            
            # 检查是否达到习惯形成阈值
            if pattern.count == self.DETECTION_THRESHOLD:
                # 创建习惯候选
                return self._create_habit_candidate(pattern)
        else:
            # 创建新模式
            self.patterns[pattern_key] = TaskPattern(
                pattern_key=pattern_key,
                trigger_keywords=keywords,
                action_signature=action_signature,
                count=1,
                last_seen=today
            )
        
        self._save_tracker()
        return None
    
    def _create_habit_candidate(self, pattern: TaskPattern) -> Habit:
        """创建习惯候选"""
        store = get_habit_store()
        
        trigger = f"用户输入包含关键词: {', '.join(pattern.trigger_keywords)}"
        action_sequence = pattern.action_signature.split("|")
        
        habit = store.create_habit(
            trigger=trigger,
            action_sequence=action_sequence,
            confidence=0.5
        )
        
        return habit
    
    def analyze_patterns(self) -> List[Dict]:
        """
        分析所有模式
        
        Returns:
            模式分析报告
        """
        reports = []
        
        for pattern in self.patterns.values():
            report = {
                "pattern_key": pattern.pattern_key,
                "count": pattern.count,
                "trigger_keywords": pattern.trigger_keywords,
                "status": "habit_formed" if pattern.count >= self.DETECTION_THRESHOLD else "learning",
                "progress": f"{pattern.count}/{self.DETECTION_THRESHOLD}"
            }
            reports.append(report)
        
        return sorted(reports, key=lambda x: x["count"], reverse=True)
    
    def get_suggestions(self) -> List[str]:
        """获取习惯化建议"""
        suggestions = []
        store = get_habit_store()
        
        for pattern in self.patterns.values():
            if pattern.count >= self.DETECTION_THRESHOLD:
                # 检查是否已创建习惯
                trigger = f"用户输入包含关键词: {', '.join(pattern.trigger_keywords)}"
                existing = any(h.trigger == trigger for h in store.get_all_habits())
                
                if not existing:
                    suggestions.append(
                        f"检测到高频模式 '{pattern.pattern_key}' ({pattern.count}次)，建议创建习惯"
                    )
        
        return suggestions


# 单例模式
_habit_detector_instance: Optional[HabitDetector] = None


def get_habit_detector() -> HabitDetector:
    """获取习惯检测器单例"""
    global _habit_detector_instance
    if _habit_detector_instance is None:
        _habit_detector_instance = HabitDetector()
    return _habit_detector_instance
