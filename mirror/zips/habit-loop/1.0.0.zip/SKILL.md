---
name: habit-loop
slug: habit-loop
version: 1.0.0
description: "Habit-Loop 自动习惯化系统。模拟人类基底核的自动化能力：当某个行为序列被高频重复时，自动将其固化为"不动脑筋"的习惯，从而释放认知资源处理新任务。"
---

# 🔁 Habit-Loop — 自动习惯化系统

## 类比

> 人类基底核驱动习惯行为：第一次做时需要全神贯注，重复多次后变成"自动驾驶"。
> 本 Skill 让 AI 将高频工作流固化为可秒级执行的"习惯"，省流提效。

---

## 自动触发规则（全自动，零感知）

### 触发时机

| 场景 | 自动执行 |
|------|---------|
| 同一类任务出现 ≥3 次 | 自动创建习惯规则 |
| 读取 task-frequency-tracker.json 时 | 自动检查是否有可习惯化的模式 |
| 习惯规则命中时 | 直接执行，跳过 prefrontal-check（省流） |
| 用户绕过习惯时 | 记录为"习惯例外"，评估是否更新规则 |

---

## 习惯库结构

存储位置：`.workbuddy/dreams/habit-store.json`

```json
{
  "habits": [
    {
      "id": "h001",
      "trigger": "用户说「帮我做PPT」且包含「简历」关键词",
      "action_sequence": [
        "加载 PPT 演示文稿 skill",
        "应用 style-library.json 的 ppt 域配色",
        "使用极简浅色模板",
        "橙底白字保留，F15A22"
      ],
      "confidence": 0.9,
      "trigger_count": 5,
      "last_used": "2026-04-08",
      "skip_precheck": true,
      "created_at": "2026-04-08",
      "auto_confirmed": true
    },
    {
      "id": "h002",
      "trigger": "用户修改现有 PPT 的文字内容",
      "action_sequence": [
        "解压 pptx",
        "找到对应 slide XML",
        "只修改目标文字",
        "重新打包",
        "不改动其他页面"
      ],
      "confidence": 0.95,
      "trigger_count": 8,
      "last_used": "2026-04-08",
      "skip_precheck": true,
      "auto_confirmed": true
    },
    {
      "id": "h003",
      "trigger": "用户提到「简历」",
      "action_sequence": [
        "加载 MEMORY.md 简历优化策略",
        "检查用户是否有已优化的简历模板",
        "使用外部信物 + 数据支撑策略",
        "先确认求职意向方向"
      ],
      "confidence": 0.85,
      "trigger_count": 3,
      "last_used": "2026-04-08",
      "skip_precheck": false,
      "auto_confirmed": false
    }
  ],
  "confidence_decay_days": 30,
  "auto_promote_threshold": 5
}
```

---

## 核心操作

### 1. 习惯形成（自动）

```
每次任务完成 → 检查 task-frequency-tracker.json
  → 如果同一触发词命中 ≥3 次：
    → 生成习惯候选
    → 检查触发条件是否足够精确
    → 写入 habit-store.json（标记 auto_confirmed: false）
    → 下次命中时以"建议"形式呈现给用户确认
```

### 2. 习惯执行（自动，秒级响应）

```
用户输入 → 匹配 habit-store.json 触发条件
  → 命中且 confidence >= 0.8：
    → 直接执行 action_sequence（跳过 precheck）
    → 触发计数器 +1
    → 不输出多余废话
  → 命中但 confidence < 0.8：
    → 快速确认："按上次的方式做？"（1句话）
    → 3秒无异议 → 执行
```

### 3. 习惯更新（自动学习）

```
用户绕过习惯，自定义执行方式：
  → 记录为 habit_violation
  → 分析差异：修改了哪一步？
  → 更新对应 action_sequence
  → confidence -= 0.1（信任度下降）
  → confidence < 0.5 → 暂停该习惯，重新学习
```

### 4. 习惯衰减（自动维护）

```
habit 超过 30 天未触发：
  → confidence 衰减：× 0.9 / 月
  → confidence < 0.3 → 移入归档
  → 移入归档前通知用户："[习惯名]已很久没用，是否删除？"
```

---

## 省流核心逻辑

| 传统流程 | 习惯化后 |
|---------|---------|
| 意图解码（~3秒）→ 预检（~2秒）→ 执行 → 反馈 | 命中习惯 → 直接执行（省3-5秒） |
| 每次问确认 | 习惯置信度高 → 免确认直接执行 |
| 每次加载风格库 | 习惯中已嵌入风格参数 |

---

## 与其他 Skill 的联动

| 来源 | 联动 |
|------|------|
| auto-skill-creator | 习惯置信度达到阈值（≥0.9，≥5次）→ 建议升级为正式 Skill |
| working-memory-buffer | 决策记录作为习惯触发条件的训练数据 |
| dream-memory | REM 洞察中发现的高频模式 → 自动创建习惯候选 |
| mirror-neuron | 风格偏好固化后 → 生成对应的 habit |
