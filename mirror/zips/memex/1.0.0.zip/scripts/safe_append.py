#!/usr/bin/env python3
"""
跨平台文件锁安全追加工具
支持 macOS 和 Linux 的并发写入保护

Usage: safe_append.py <file_path> <content>
"""
import fcntl
import sys
from pathlib import Path


def safe_append(file_path: str, content: str, max_retries: int = 3) -> bool:
    """
    使用 fcntl 文件锁安全追加内容到文件

    Args:
        file_path: 目标文件路径（支持 ~ 展开）
        content: 要追加的内容
        max_retries: 最大重试次数

    Returns:
        bool: 成功返回 True，失败返回 False
    """
    path = Path(file_path).expanduser()

    for attempt in range(max_retries):
        try:
            # 确保父目录存在
            path.parent.mkdir(parents=True, exist_ok=True)

            with open(path, 'a') as f:
                # 获取排他锁
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                try:
                    f.write(content + '\n')
                    f.flush()
                finally:
                    # 释放锁
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            return True
        except (IOError, OSError) as e:
            if attempt == max_retries - 1:
                print(f"Error: {e}", file=sys.stderr)
                return False
    return False


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: safe_append.py <file_path> <content>", file=sys.stderr)
        sys.exit(1)

    success = safe_append(sys.argv[1], sys.argv[2])
    sys.exit(0 if success else 1)
