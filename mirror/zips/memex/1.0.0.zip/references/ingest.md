# Ingest — 内容摄入流程

将用户发送的内容编译进 Wiki。支持 URL、图片、文件、长文字笔记、短备忘。

**在开始前**，确保已完成 SKILL.md 中的「Vault 初始化检查」和「Orientation」步骤。

> ⚠️ **写文件只用 Python，不用 bash heredoc。**  
> bash heredoc 在重试时会重复执行，导致 index.md 出现重复条目。所有写入（raw 文件、pages 文件、index.md、log.md）统一使用 Python `open().write()` 或下方的 `safe_append()`。

---

## 通用写文件函数（整个 ingest 流程复用）

在开始任何写入操作前，先在 Python 会话中定义这两个函数：

```python
import fcntl, os
from pathlib import Path
from datetime import datetime

def write_file(path_str, content):
    """幂等写文件：如文件已存在则跳过（raw 层保护）"""
    path = Path(path_str).expanduser()
    if path.exists():
        print(f"[skip] already exists: {path}")
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')
    return True

def overwrite_file(path_str, content):
    """覆盖写文件（用于 pages 层更新）"""
    path = Path(path_str).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')

def safe_append(file_path, line):
    """并发安全追加一行，追加前检查是否已存在（防止重复）"""
    path = Path(file_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'a+') as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            f.seek(0)
            existing = f.read()
            if line.strip() in existing:
                print(f"[skip] already in file: {line.strip()[:60]}")
                return
            f.seek(0, 2)  # seek to end
            f.write(line + '\n')
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)

vault = open(os.path.expanduser("~/.memex/active-vault.txt")).read().strip()
```

---

## 步骤 1：识别内容类型

按以下优先级判断：

| 类型 | 判断条件 | 处理方式 |
|------|---------|---------|
| URL | 消息含 http:// 或 https:// | browser/fetch 抓取正文 |
| 图片 | 附件为图片格式 | vision 工具提取文字 |
| 文件 | 附件为文档/PDF | 读取文件内容 |
| 长文字 | 纯文字 > 100 字 | 直接处理 |
| 短备忘 | 纯文字 ≤ 100 字，无明确主题 | → 直接跳到「短备忘处理」章节 |

---

## 步骤 2：获取正文内容

- **URL**：抓取正文；超时或 403 → 追加到 inbox，回复「链接无法访问，已存入 Inbox」
- **图片**：vision 提取文字；结果为空 → 回复「图片内容无法识别」，终止
- **文件**：直接读取
- **文字**：直接使用消息内容

---

## 步骤 3：生成 slug

从标题或内容前几词生成 slug：
- 取标题前 4-6 个有意义的词
- 转小写，词间用连字符连接
- 只保留字母、数字、连字符
- 示例：`how-llms-work-internally`

---

## 步骤 4：写 raw 存档

根据内容类型选择子目录：

| 内容类型 | 子目录 |
|---------|--------|
| URL 网页文章 | `raw/articles/` |
| 播客笔记/转录 | `raw/podcasts/` |
| 论文 | `raw/papers/` |
| 长文字/笔记 | `raw/my-notes/` |
| 图片附件 | `raw/assets/` |

```python
date_str = datetime.now().strftime("%Y-%m-%d")
raw_filename = f"{date_str}-{slug}.md"
raw_path = f"{vault}/Wiki/raw/{subdir}/{raw_filename}"

raw_content = f"""# {title}

source-url: {url}
fetched: {date_str}

---

{article_text}
"""

created = write_file(raw_path, raw_content)
# write_file 在文件已存在时自动跳过，不会重复写入
```

---

## 步骤 5：深度语义理解

**不要只提取关键词，要做语义分析：**

### 第一阶段：深度理解

1. **识别核心论点**：主要观点、支持证据、论证结构（前提→结论）
2. **识别隐含信息**：文章暗示但未明说的内容、可能存在的偏见或局限性

### 第二阶段：知识整合

1. **与现有 Wiki 对比**（基于 orientation 阶段读取的内容）
   - 查找相关实体/概念页面，检查新旧信息一致性

2. **发现语义关联**（因果/矛盾/演进/扩展/相似关系）

3. **标记矛盾**：发现矛盾时，两处都加 `⚠️ CONFLICT with [[页面名]]`，不自动择一

---

## 步骤 6：创建 source 摘要页

```python
source_path = f"{vault}/Wiki/pages/sources/{date_str}-{slug}.md"

source_content = f"""---
title: "{title}"
page-type: source
created: {date_str}
updated: {date_str}
source-type: article
source-url: "{url}"
status: processed
tags: []
confidence: medium
---

# {title}

## 摘要

{summary}

## 核心论点

{core_arguments}

## 关键概念

{key_concepts_list}

## 关键实体

{key_entities_list}

## 语义关联

{relations_list}

## Sources

- 原始文件：[[raw/{subdir}/{raw_filename}]]
"""

write_file(source_path, source_content)
```

参考 `references/agents.md` 中的完整模板格式。

---

## 步骤 7：创建/更新 entity 和 concept 页

识别内容中涉及的实体（人物/产品/组织/工具）和概念：

**已存在对应页面**（先检查 index.md，注意别名/拼写变体）：
```python
# 读取现有页面，追加来源记录行
existing = Path(page_path).read_text()
new_row = f"| {date_str} | [[sources/{date_str}-{slug}]] | {contribution} |"
updated = existing.replace("<!-- sources-end -->", f"{new_row}\n<!-- sources-end -->")
# 如果没有 sources-end 标记，手动追加到来源记录表末尾
overwrite_file(page_path, updated)
```

**不存在对应页面**：参考 `references/agents.md` 中的对应模板，用 `write_file()` 新建。

**relations 字段格式**（新建/更新时添加）：
```yaml
relations:
  - type: causes | caused_by | contradicts | extends | replaces | similar_to | example_of | applies_to
    target: [[page/name]]
    confidence: high | medium | low
    source: [[sources/current-source]]
```

---

## 步骤 8：判断是否生成 Synthesis

满足任一条件时，自动生成综合分析页：
1. 同一主题有 5+ 个来源
2. 发现明显的时间演进（同一概念不同时期有不同描述）
3. 发现争议/矛盾观点（检测到 CONFLICT）

路径：`$VAULT/Wiki/pages/syntheses/{topic}-analysis.md`，用 `write_file()` 创建。

---

## 步骤 9：安全更新 index.md 和 log.md

`safe_append()` 内置去重检查，同一行不会被写入两次，即使调用多次也安全：

```python
# 更新 index.md（在 sources 区块追加）
safe_append(f"{vault}/Wiki/index.md", f"- [[sources/{date_str}-{slug}]] — {title}")

# 同样方式追加 concept/entity 页面到 index.md 对应区块
for concept_slug in new_concepts:
    safe_append(f"{vault}/Wiki/index.md", f"- [[concept/{concept_slug}]] — {concept_summary}")

for entity_slug in new_entities:
    safe_append(f"{vault}/Wiki/index.md", f"- [[entity/{entity_slug}]] — {entity_summary}")

# 追加 log.md
dt = datetime.now().strftime("%Y-%m-%d %H:%M")
safe_append(f"{vault}/Wiki/log.md",
    f"{dt} | INGEST | {subdir}/{raw_filename} | new:{new_count} updated:{updated_count} | {title}")
```

---

## 步骤 10：强制检查清单

在回复用户前确认以下全部通过：

- [ ] raw 文件已成功创建（非空、可读）
- [ ] sources 页的 `sources` 字段指向正确的 raw 文件（格式：`raw/subdir/filename.md`，不是 `[[sources/...]]`）
- [ ] 所有 entity/concept 页的 `sources` 字段完整
- [ ] 发现的矛盾已双向标注 ⚠️ CONFLICT
- [ ] index.md 和 log.md 使用 `safe_append()` 写入，无重复条目

任何检查失败：回复「摄入失败，请重试」，不回复成功消息。

---

## 步骤 11：回复用户

```
已摄入：{标题} · 新建 {N} 页 · 更新 {M} 页
{如有 synthesis：已生成综合分析：[[syntheses/xxx]]}
{如有矛盾：⚠️ 发现 {N} 处矛盾信息，已标记}
```

---

## 短备忘处理（inbox 路径）

当内容为短备忘（≤ 100 字，无明确主题）时，跳过上述步骤，直接追加到 inbox：

```python
dt = datetime.now().strftime("%Y-%m-%d %H:%M")
inbox_path = f"{vault}/Wiki/pages/topic/inbox.md"
safe_append(inbox_path, f"\n### {dt}\n\n{user_message}")
```

回复：「已存入 Inbox」

---

## 错误处理

| 场景 | 处理方式 |
|------|---------|
| URL 超时 / 无法访问 | 追加到 inbox，回复「链接无法访问，已存入 Inbox」 |
| 图片 OCR 结果为空 | 回复「图片内容无法识别」，不写入任何文件 |
| 内容与已有页面高度重复（>80%） | 合并入已有页面，回复「已合并入 [[页面名]]」 |
| 任何写入步骤失败 | 回复「摄入失败，请重试」 |
