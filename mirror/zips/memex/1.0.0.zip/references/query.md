# Query — Wiki 查询 + 问答持久化流程

从 Wiki 检索内容回答用户问题，并将有价值的问答保存到 qa/ 目录。

**本流程分两个阶段**：先检索回答，再判断是否持久化。

**在开始前**，确保已完成 SKILL.md 中的「Vault 初始化检查」。

---

## 阶段一：检索与回答

### 步骤 1：Orientation

```
读取 $VAULT/SCHEMA.md       （不存在则跳过）
读取 $VAULT/AGENTS.md       （不存在则跳过）
读取 $VAULT/Wiki/index.md
读取 $VAULT/Wiki/log.md     （最近 20-30 条）
```

### 步骤 2：定位相关页面

从用户问题提取关键词，在 pages/ 下查找相关页面：

匹配优先级（知识密度从高到低）：
1. `pages/entity/` 和 `pages/concept/`
2. `pages/topic/`、`pages/syntheses/`
3. `pages/sources/`、`pages/qa/`

最多读取 5 个最相关页面，避免上下文过长。

### 步骤 3：组织回答

- 综合多个页面内容，给出直接回答
- 引用页面名称：`[[entity/名称]]`、`[[concept/名称]]`
- 回答控制在 300 字以内；超长时摘要主要结论，附「详见 [[页面名]]」
- Wiki 无相关内容时明确回复「Wiki 中暂无此内容」，不编造

---

## 阶段二：判断是否持久化

### 值得保存的条件（满足任一即保存）

1. 综合了 3 个以上 Wiki 页面
2. 包含对比、因果、演进或冲突分析
3. 需要推理，不是直接摘录
4. 明显是未来可能重复查询的重要问题
5. 用户使用 `/q-save` 强制保存

### 不值得保存

- 单个页面即可回答的简单查询
- 纯定义类问题（"什么是 X"，Wiki 里有完整页面）
- 纯导航性问题（"有哪些页面"）
- 与 qa/ 中已有的相似问题高度重合

---

## 阶段三：保存到 qa/（如果值得保存）

### 步骤 4：生成 slug

从问题中提取 2-4 个核心关键词，转小写，用连字符连接。

### 步骤 5：创建 qa 页面

路径：`$VAULT/Wiki/pages/qa/$(date +%Y-%m-%d)-$SLUG.md`

```markdown
---
title: "{问题}"
page-type: qa
created: {今日日期}
updated: {今日日期}
sources:
  - {相关页面列表}
tags: []
confidence: medium
---

# {问题}

## 问题

{用户原始问题}

## 回答

{生成的回答，包含 [[页面链接]] 引用}

## 相关资料

{引用的相关页面列表}
```

### 步骤 6：安全更新 index.md 和 log.md

```python
import fcntl, os
from pathlib import Path
from datetime import datetime

def safe_append(file_path, content):
    path = Path(file_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'a') as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        f.write(content + '\n')
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)

vault = open(os.path.expanduser("~/.memex/active-vault.txt")).read().strip()
dt = datetime.now().strftime("%Y-%m-%d %H:%M")

# 更新 index.md（Q&A 区块）
safe_append(f"{vault}/Wiki/index.md", f"- [[qa/{qa_filename}]] — {question_summary}")

# 追加 log.md
safe_append(f"{vault}/Wiki/log.md",
    f"{dt} | QUERY | qa/{qa_filename} | new:1 updated:0 | {question_summary}")
```

---

## 步骤 7：回复用户

回复答案。如果保存了，末尾追加：

```
已保存问答：[[qa/{文件名}]]
```

---

## 硬性约束

- 查询阶段**严禁写入任何文件**
- 持久化时必须使用并发保护写 index.md 和 log.md
- Wiki 无答案时明确告知，不编造内容
- 所有引用使用 `[[链接]]` 格式
- 保存前检查 qa/ 是否已有相似问题，避免重复
