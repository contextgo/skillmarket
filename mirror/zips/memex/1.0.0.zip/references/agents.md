# Memex Vault 操作规范

> 本文件是所有 Hermes skill 写入 Wiki 页面的权威格式参考。
> skill 在执行前必须读取本文件，严格按照以下模板写入。

---

## 设计原则

- 使用 Obsidian Callout 块展示元信息和重点内容（`> [!info]`、`> [!tip]`、`> [!quote]`、`> [!warning]`）
- frontmatter 使用完整字段集：title, page-type, created, updated, sources, tags, confidence
- 页面间链接使用 `[[页面名]]` 格式
- 来源记录用表格，其余区块用散文或 Callout

---

## 目录结构

```
Wiki/
├── SCHEMA.md                    # 当前 vault 的领域规则与建页偏好
├── raw/                        # L1 · 原始资料层（不可变，追加式）
│   ├── articles/               # 网页文章（URL 抓取）
│   ├── podcasts/               # 播客笔记/转录
│   ├── papers/                 # 论文
│   ├── my-notes/               # 个人原始笔记
│   └── assets/                 # 图片/文件附件
│
├── pages/                      # L2 · 编译产物层（LLM 维护）
│   ├── sources/                # 来源摘要页
│   ├── entity/                 # 实体页（人物/产品/组织/工具）
│   ├── concept/                # 概念页
│   ├── topic/                  # 主题汇总页
│   │   └── inbox.md            # 短备忘暂存区
│   ├── syntheses/              # 综合分析页（跨多个来源的关联发现）
│   ├── qa/                     # 问答记录
│   └── system/                 # 系统页（健康报告、周报等）
│
├── index.md                    # 全局地图（flock 保护写入）
└── log.md                      # 操作日志（flock 保护写入，追加式）
```

**核心原则**：
- **raw/ 层不可变**：一旦写入绝对不能修改或删除
- **编译方向**：知识从 raw/ → pages/ 单向流动
- **可追溯性**：每个 pages/ 页面都能追溯到具体 raw 文件
- **先 orientation 再操作**：执行摄入、查询、健康检查、维护前，先读 `SCHEMA.md`、`index.md` 和最近 `log.md`

---

## 页面类型

| 类型 | 目录 | 说明 |
|------|------|------|
| source | pages/sources/ | 每个 raw 文件的摘要页 |
| entity | pages/entity/ | 具象实体（人/产品/组织/工具）|
| concept | pages/concept/ | 抽象概念（思想/方法/框架）|
| topic | pages/topic/ | 跨概念的综合分析 |
| synthesis | pages/syntheses/ | 综合分析页（跨来源关联发现）|
| qa | pages/qa/ | 问答记录 |
| system | pages/system/ | 系统报告（健康检查/周报）|

---

## 页面模板

### sources 摘要页

路径：`Wiki/pages/sources/YYYY-MM-DD-{slug}.md`

```markdown
---
title: "{标题}"
page-type: source
created: YYYY-MM-DD
updated: YYYY-MM-DD
source-type: {article / note / paper / podcast}
source-url: "{URL}"
status: processed
tags: [{tags}]
confidence: {low | medium | high}
---

# {标题}

## 摘要

{2-3 句内容概述}

## 核心论点

### {论点一}

{阐述}

### {论点二}

{阐述}

## 关键概念

- [[concept/{名称}]] — {为什么相关}

## 关键实体

- [[entity/{名称}]] — {为什么相关}

## Sources

- 原始文件：[[raw/YYYY-MM-DD-{slug}]]
```

---

### entity 页

路径：`Wiki/pages/entity/{名称}.md`

```markdown
---
title: "{实体名称}"
page-type: entity
created: YYYY-MM-DD
updated: YYYY-MM-DD
sources:
  - [[sources/{slug}]]
tags: [{tags}]
confidence: {low | medium | high}
aliases: [{别名}]
entity-type: {person / product / organization / tool}
relations:
  - type: {关系类型}
    target: [[{关联页面}]]
    confidence: {high | medium | low}
    source: [[sources/{slug}]]
---

# {实体名称}

> [!info] 基本信息
> **类型**：{person / product / organization / tool}
> **领域**：{所属领域}
> **首次记录**：[[sources/{slug}]]

{2-3 句概述}

## 关键信息

{具体内容}

## 语义关联

| 关系类型 | 关联对象 | 置信度 | 来源 |
|---------|---------|-------|------|
| {relation_type} | [[{page}]] | {confidence} | [[sources/{slug}]] |

## 来源记录

| 时间 | 来源 | 贡献了什么 |
| ---- | ---- | --------- |
| YYYY-MM-DD | [[sources/{slug}]] | {一句话} |

---

#entity #{entity_type} #{领域标签}
```

---

### concept 页

路径：`Wiki/pages/concept/{名称}.md`

```markdown
---
title: "{概念名称}"
page-type: concept
created: YYYY-MM-DD
updated: YYYY-MM-DD
sources:
  - [[sources/{slug}]]
tags: [{tags}]
confidence: {low | medium | high}
aliases: []
relations:
  - type: {关系类型}
    target: [[{关联页面}]]
    confidence: {high | medium | low}
    source: [[sources/{slug}]]
---

# {概念名称}

> [!info] 概念定位
> **领域**：{所属领域}
> **相关概念**：[[concept/{A}]] · [[concept/{B}]]

{核心定义}

## 理解这个概念

{展开解释}

## 应用场景

{举例}

## 容易混淆的点

> [!tip] 与相关概念的区别
> {澄清近似概念}

## 语义关联

| 关系类型 | 关联对象 | 置信度 | 来源 |
|---------|---------|-------|------|
| {relation_type} | [[{page}]] | {confidence} | [[sources/{slug}]] |

## 来源记录

| 时间 | 来源 | 贡献了什么 |
| ---- | ---- | --------- |
| YYYY-MM-DD | [[sources/{slug}]] | {一句话} |

---

#concept #{领域标签}
```

---

### qa 问答页

路径：`Wiki/pages/qa/YYYY-MM-DD-{slug}.md`

```markdown
---
title: "{问题}"
page-type: qa
created: YYYY-MM-DD
updated: YYYY-MM-DD
sources:
  - [[sources/{slug}]]
tags: [{tags}]
confidence: {low | medium | high}
---

# {问题}

## 问题

{用户原始问题}

## 回答

{LLM 生成的回答，包含 [[页面链接]] 引用}

## 相关资料

- {相关页面列表}
```

---

### synthesis 综合分析页

路径：`Wiki/pages/syntheses/{topic}-analysis.md`

```markdown
---
title: "{主题}"
page-type: synthesis
created: YYYY-MM-DD
updated: YYYY-MM-DD
sources:
  - [[sources/{slug1}]]
  - [[sources/{slug2}]]
tags: [{tags}]
confidence: {low | medium | high}
---

# {主题}

## 摘要

{综合概述}

## 关联发现

{跨来源的发现和关联}

## 涉及来源

- [[sources/{slug1}]] — {简述}
- [[sources/{slug2}]] — {简述}

## 结论

{综合结论}
```

---

### inbox 暂存页

路径：`Wiki/pages/topic/inbox.md`

```markdown
---
title: "Inbox"
page-type: topic
created: YYYY-MM-DD
updated: YYYY-MM-DD
sources: []
tags: [inbox]
---

# Inbox

> [!warning] 待处理暂存区
> 通过微信发送的短备忘自动追加到此处。定期整理后删除对应条目。

## 待处理

### YYYY-MM-DD HH:mm

{备忘内容}
```

---

## 关系类型定义

| 关系类型 | 说明 | 示例 |
|---------|------|------|
| causes | A 导致 B | [[概念/温度]] → [[概念/气候变化]] |
| caused_by | A 由 B 导致 | [[概念/气候变化]] ← [[概念/温室效应]] |
| contradicts | A 与 B 矛盾 | [[sources/A]] 与 [[sources/B]] 观点冲突 |
| extends | A 扩展 B | [[论文/新方法]] extends [[概念/基础理论]] |
| replaces | A 替代 B | [[概念/GPT-4]] replaces [[概念/GPT-3]] |
| similar_to | A 与 B 相似 | [[概念/RAG]] similar_to [[概念/检索增强]] |
| example_of | A 是 B 的例子 | [[产品/ChatGPT]] example_of [[概念/LLM]] |
| applies_to | A 应用于 B | [[概念/注意力]] applies_to [[概念/Transformer]] |

---

## log.md 追加格式

每次操作完成后追加一行（4 列格式）：

```
YYYY-MM-DD HH:mm | {操作类型} | {统计/状态} | {描述}
```

**操作类型**：INGEST, QUERY, HEALTH-CHECK, MAINTAIN, MAINTAIN-ADD, DAILY-BRIEF, SYSTEM

| 类型 | 触发场景 | 是否写 raw/ |
|------|---------|------------|
| `INGEST` | 用户提交内容（URL/笔记/文件）→ raw/ → pages/ | ✅ 是 |
| `QUERY` | 用户查询，结果保存为 qa/ | ❌ 否 |
| `HEALTH-CHECK` | 健康检查完成 | ❌ 否 |
| `MAINTAIN` | 维护任务完成（自动修复链接/标签等） | ❌ 否 |
| `MAINTAIN-ADD` | 维护过程中新建 pages/（不来自 raw 摄入，如补缺失页） | ❌ 否 |
| `DAILY-BRIEF` | 每日摘要推送 | ❌ 否 |
| `SYSTEM` | 系统级操作（测试报告、初始化等） | ❌ 否 |

**各操作格式示例**：
- INGEST: `2026-04-19 10:30 | INGEST | articles/2026-04-19-article.md | new:3 updated:2 | 文章标题`
- QUERY: `2026-04-19 10:35 | QUERY | qa/2026-04-19-question.md | new:1 updated:0 | 问：XXX`
- HEALTH-CHECK: `2026-04-19 10:00 | HEALTH-CHECK | issues:5 | 健康检查完成`
- MAINTAIN: `2026-04-19 11:00 | MAINTAIN | auto:2 suggested:3 | 维护任务完成`
- MAINTAIN-ADD: `2026-04-19 11:05 | MAINTAIN-ADD | entity/hermes + concept/pkm | new:2 updated:0 | 补充维护发现的缺失页面`
- DAILY-BRIEF: `2026-04-19 08:00 | DAILY-BRIEF | sent:3 chars:210 | 每日摘要推送完成`

---

## 并发保护

所有写 `log.md` 和 `index.md` 的操作必须在 `flock /tmp/memex-ingest.lock` 保护下执行。

---

## 硬性约束

1. **raw/ 目录文件只增不改**，禁止修改或删除
2. **handle-query skill 严禁调用任何写工具**（只读）
3. **handle-query-synthesis** 负责将问答保存到 qa/
4. **vault 路径**从 `~/.memex/active-vault.txt` 读取
5. **所有论断必须能追溯到 raw 文件**，无法追溯的标注 `⚠️ 推测`
6. **发现矛盾时双向标注** `⚠️ CONFLICT with [[页面名]]`
7. **执行前必须 orientation**：读取 `SCHEMA.md`（如存在）、`Wiki/index.md` 和最近 20-30 条 `Wiki/log.md`
