# Maintain — 健康检查 + 主动维护流程

两个流程，触发方式不同，但都先做 Orientation：

- **`/health-check`**：扫描 Wiki 发现问题，生成健康报告
- **`/maintain`**：主动发现改进机会，执行安全操作，提供建议

**在开始前**，确保已完成 SKILL.md 中的「Vault 初始化检查」。

---

## 通用前置步骤：Orientation

```
读取 $VAULT/SCHEMA.md       （不存在则跳过）
读取 $VAULT/AGENTS.md       （不存在则跳过）
读取 $VAULT/Wiki/index.md
读取 $VAULT/Wiki/log.md     （最近 20-30 条）
```

---

# 健康检查（/health-check）

扫描所有 Wiki 页面，发现结构性问题，生成报告。**只读，不自动修改任何页面。**

## HC-1：孤立页面检测

**定义**：没有被其他页面链接的页面。

遍历所有页面，统计每个页面被链接次数（搜索 `[[页面名]]` 引用）。

**豁免规则**（以下天然是叶节点）：
- `page-type: qa`：问答页只引用别人
- `page-type: system`：系统页面
- `topic/inbox.md`：全局暂存区

## HC-2：矛盾信息检测

扫描 `> [!warning]` callout 块中的 `⚠️ CONFLICT` 标记（排除代码块内的）。列出所有已标记的矛盾，提示用户处理。

## HC-3：过时知识检测

读取每个页面 frontmatter 的 `updated` 字段，距今超过 180 天的标记为过时。

## HC-4：别名/拼写变体检测

**仅在同 page-type 的页面之间**比较名称相似度（编辑距离 > 80%），避免跨类型误判。

## HC-5：缺失链接检测

扫描页面内容，识别被多次提及（3次+）但无独立页面的专业术语，建议创建。

## 生成健康报告

路径：`$VAULT/Wiki/pages/system/health-report-$(date +%Y-%m-%d).md`

```markdown
---
title: "Wiki 健康报告 - {日期}"
page-type: system
created: {今日日期}
updated: {今日日期}
sources: []
tags: [health-check]
confidence: high
---

# Wiki 健康报告 - {日期}

生成时间：{YYYY-MM-DD HH:mm}

## 统计概览

- 总页面数：{N}
- 孤立页面：{N}
- 已标记矛盾：{N} 处
- 过时知识：{N} 个（>180天未更新）
- 潜在别名：{N} 对
- 建议新建：{N} 个术语页

## 详细发现

{各检查项结果}

## 建议行动

1. 高优先级：{需要立即处理的}
2. 中优先级：{建议近期处理的}
3. 低优先级：{可选改进}
```

## 安全更新 log.md

```python
import fcntl, os
from pathlib import Path
from datetime import datetime

def safe_append(file_path, content):
    path = Path(file_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'a') as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        f.write(content + '\n')
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)

vault = open(os.path.expanduser("~/.memex/active-vault.txt")).read().strip()
dt = datetime.now().strftime("%Y-%m-%d %H:%M")
safe_append(f"{vault}/Wiki/log.md",
    f"{dt} | HEALTH-CHECK | issues:{total_issues} | 健康检查完成")
```

## 回复用户

```
健康检查完成，已生成报告：[[pages/system/health-report-{日期}.md]]
发现 {N} 个问题需要关注
```

---

# 主动维护（/maintain）

主动发现 Wiki 改进机会，执行安全操作，将需要人工判断的操作列为建议。

## MT-1：发现可合并的相似页面

扫描所有页面标题，识别高度重复或相似的内容（编辑距离 > 85%，同 page-type），列入建议。

## MT-2：识别缺失的中间概念

分析现有页面的 relations 字段，发现"断链"（A → C 但缺少中间概念 B）。识别频繁共现但无独立页面的术语。

## MT-3：生成知识周报

读取最近 7 天的 log.md，统计新增内容，识别重要趋势。

路径：`$VAULT/Wiki/pages/system/weekly-summary-$(date +%Y-W%V).md`

```markdown
---
title: "知识周报 - 第{WW}周"
page-type: system
created: {今日日期}
updated: {今日日期}
sources: []
tags: [weekly-summary]
confidence: high
---

# 知识周报 - 第{WW}周（{日期范围}）

## 本周统计
- 新增来源：{N} 篇
- 新建页面：{N} 个
- 更新页面：{N} 个
- 新增问答：{N} 条

## 本周亮点
{重要发现、新知识、有趣关联}

## 建议关注
{需要进一步探索的方向}
```

## MT-4：提出研究问题

基于现有知识发现空白：识别有 CONFLICT 标记但尚未解决的问题、频繁出现但缺乏深入讨论的主题。

## MT-5：自动执行安全操作

以下操作可自动执行（无需用户确认）：
- **添加别名**：两个页面明显是同一事物时，在 frontmatter 的 `aliases` 字段添加别名
- **补充缺失链接**：页面中提及的术语已有独立页面时，将裸文本改为 `[[链接]]`
- **更新 frontmatter**：补充缺失的 `tags` 字段

以下操作**只提供建议**，不自动执行（需要人类判断）：
- 合并页面
- 删除页面
- 修改内容实质

## 生成维护报告

路径：`$VAULT/Wiki/pages/system/maintenance-tasks.md`（更新已有文件或新建）

在报告中分「待处理建议」（高/中/低优先级）和「已完成」两个区块，记录所有自动执行的操作。

## 安全更新 log.md（严格区分类型）

```python
# 如果本次维护新建了页面（如补缺失页、inbox升级等）
if new_pages > 0:
    safe_append(log_path,
        f"{dt} | MAINTAIN-ADD | {page_list} | new:{new_pages} updated:0 | 补充维护发现的缺失页面")

# 维护汇总
safe_append(log_path,
    f"{dt} | MAINTAIN | auto:{auto_count} suggested:{suggest_count} | 维护任务完成")
```

**日志类型说明**（重要）：
- `INGEST`：仅用于用户提交内容 → raw/ → pages/ 的完整流程
- `MAINTAIN-ADD`：维护过程中新建 pages/（不来自 raw）
- `MAINTAIN`：维护汇总（修复链接、补标签、生成报告等）

## 回复用户

```
维护完成：
- 自动执行 {N} 项操作
- 新增 {M} 条建议
- 已生成周报：[[pages/system/weekly-summary-{周}.md]]

详见：[[pages/system/maintenance-tasks.md]]
```

---

## 硬性约束

- 必须使用并发保护写入 log.md
- 只自动执行「安全操作」，需要判断的操作只提供建议
- 所有自动执行的操作必须在报告中记录
- 检测结果是建议性的，健康检查不自动修改任何页面
