# Daily Brief — 每日摘要生成流程

生成昨日摄入内容的摘要，通过你的工具链推送给用户。

本 skill 只负责**生成摘要文本**，不负责推送渠道——推送方式由你的平台/工具决定（微信、邮件、Slack、终端输出等）。

**在开始前**，确保已完成 SKILL.md 中的「Vault 初始化检查」。

---

## 步骤 1：读取昨日 INGEST 记录

```python
import os
from datetime import datetime, timedelta
from pathlib import Path

vault = open(os.path.expanduser("~/.memex/active-vault.txt")).read().strip()
log_path = f"{vault}/Wiki/log.md"

yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")

ingest_records = []
with open(log_path) as f:
    for line in f:
        line = line.strip()
        if line.startswith(yesterday) and "| INGEST |" in line:
            # 格式：YYYY-MM-DD HH:mm | INGEST | {raw文件名} | new:{N} updated:{M} | {标题}
            parts = [p.strip() for p in line.split("|")]
            if len(parts) >= 5:
                raw_file = parts[2]
                title = parts[4]
                ingest_records.append({"raw_file": raw_file, "title": title})
```

---

## 步骤 2：获取摘要（从 sources 页）

对每条 INGEST 记录，尝试读取对应的 sources 页面获取一句话摘要：

```python
for record in ingest_records:
    # raw_file 格式如 articles/2025-01-01-some-slug.md
    slug_part = Path(record["raw_file"]).stem  # -> 2025-01-01-some-slug
    source_path = f"{vault}/Wiki/pages/sources/{slug_part}.md"
    try:
        content = open(source_path).read()
        # 提取「摘要」章节第一句话
        summary = extract_first_sentence_of_section(content, "摘要")
    except FileNotFoundError:
        summary = ""  # 无 sources 页时跳过摘要
    record["summary"] = summary
```

---

## 步骤 3：生成摘要文本

**有摄入内容时**，生成如下格式（严格控制在 300 字以内）：

```
昨日摄入 N 条
· {标题1（≤15字）} — {摘要（≤25字）}
· {标题2（≤15字）} — {摘要（≤25字）}
回复「问：XXX」可查询 Wiki
```

**截断规则**（贪心算法）：
- header = `昨日摄入 N 条\n`
- footer = `回复「问：XXX」可查询 Wiki`
- budget = 300 - len(header) - len(footer) - 1
- 逐条添加，超出 budget 时追加 `…（共 N 条，发问查询更多）\n` 并终止

**无摄入内容时**：

```
昨日无新内容摄入
```

---

## 步骤 4：推送摘要

将生成的文本通过你的平台推送渠道发送。以下是常见集成方式：

**Hermes（微信）**：通过 Hermes 微信网关调用 `send_message(user_id, brief_text)`

**Claude Code / OpenClaw**：直接将文本输出到对话，或通过配置的 webhook 发送

**通用 webhook**：
```python
import urllib.request, json
webhook_url = os.environ.get("MEMEX_NOTIFY_WEBHOOK")
if webhook_url:
    data = json.dumps({"text": brief_text}).encode()
    req = urllib.request.Request(webhook_url, data=data,
                                  headers={"Content-Type": "application/json"})
    urllib.request.urlopen(req)
```

---

## 步骤 5：更新 log.md

```python
import fcntl
from pathlib import Path

def safe_append(file_path, content):
    path = Path(file_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'a') as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        f.write(content + '\n')
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)

dt = datetime.now().strftime("%Y-%m-%d %H:%M")
char_count = len(brief_text)
safe_append(f"{vault}/Wiki/log.md",
    f"{dt} | DAILY-BRIEF | sent:{len(ingest_records)} chars:{char_count} | 每日摘要生成完成")
```

---

## 定时触发配置

本 skill 设计为每日定时触发，配置方式因平台而异：

| 平台 | 配置方式 |
|------|---------|
| Hermes | `hermes cron add "0 8 * * *" memex:daily-brief` |
| Claude Code | 在 `.claude/scheduled-tasks.json` 中配置 cron |
| 系统 cron | `0 8 * * * claude --skill memex --trigger daily-brief` |
| OpenClaw | 在工具的定时任务面板中配置 |

推荐触发时间：每天 08:00

---

## 通知渠道配置

通过环境变量配置推送渠道（可选）：

```bash
export MEMEX_NOTIFY_WEBHOOK="https://your-webhook-url"
export MEMEX_NOTIFY_EMAIL="you@example.com"
```

如果没有配置任何推送渠道，摘要文本会直接作为对话回复输出。

---

## 硬性约束

- 只使用 read_file，不写入任何页面内容（只追加 log.md）
- vault 路径只从 `~/.memex/active-vault.txt` 读取
- 推送文本不超过 300 字
- 推送失败时记录到 log.md，不抛出异常
