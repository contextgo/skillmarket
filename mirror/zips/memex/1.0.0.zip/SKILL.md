---
name: memex
description: >
  Memex 是一个 LLM 驱动的个人知识库系统。每当用户想要将内容（URL、文章、笔记、文件、图片）存入知识库时，请使用本 skill。每当用户以「问：」「/q」「/q-save」开头提问，或提出明确疑问句时，请使用本 skill 从 Wiki 检索回答。每当用户发送 /health-check、/maintain、/status、/inbox 命令时，请使用本 skill。即使用户只是转发一篇文章链接、发来一段长文字、或说「帮我存一下这个」，也应该触发本 skill。Memex 支持 Hermes、Claude Code、OpenClaw 及任何兼容 Claude skill 格式的工具。
---

# Memex · 个人知识库 Skill

Memex 是一个「摄入时一次编译，之后无限复用」的个人知识库系统。  
用户通过对话发来内容，你将其编译成结构化知识页面，存入 Wiki。查询时从 Wiki 检索，给出有来源追溯的回答。

---

## Vault 初始化检查

每次执行任何操作前，先确认 vault 路径：

```bash
cat ~/.memex/active-vault.txt
```

- 如果文件不存在或为空：回复「Memex 未初始化，请先运行安装脚本，或手动创建 `~/.memex/active-vault.txt` 并写入你的 vault 路径。」然后终止。
- 如果路径有效：将其存为 `VAULT` 变量，后续所有操作使用该路径。

---

## Vault 结构

```
$VAULT/
├── SCHEMA.md          ← 当前 vault 的领域规则与建页偏好（可选）
├── AGENTS.md          ← Wiki 页面格式与硬性约束（可选，优先级高于 SKILL.md 默认模板）
├── Wiki/
│   ├── raw/           ← 原始资料层（只追加，永不修改）
│   │   ├── articles/
│   │   ├── podcasts/
│   │   ├── papers/
│   │   ├── my-notes/
│   │   └── assets/
│   ├── pages/         ← 编译产物层（LLM 维护）
│   │   ├── sources/
│   │   ├── entity/
│   │   ├── concept/
│   │   ├── topic/
│   │   │   └── inbox.md
│   │   ├── syntheses/
│   │   ├── qa/
│   │   └── system/
│   ├── index.md       ← 全局知识地图
│   └── log.md         ← 操作日志（只追加）
└── templates/         ← 页面模板（可选，skill 内置了默认模板）
```

---

## 意图路由

收到消息后，按以下规则判断操作类型，然后读取对应的 reference 文件执行：

| 消息特征 | 操作类型 | 读取 reference |
|---------|---------|---------------|
| 含 URL（http/https） | 摄入 | `references/ingest.md` |
| 含图片 / PDF / 文档附件 | 摄入 | `references/ingest.md` |
| 纯文字 > 100 字 | 摄入 | `references/ingest.md` |
| 短备忘 / TODO / 想法（< 100 字） | 摄入到 inbox | `references/ingest.md` |
| 以「问：」开头 | 查询 | `references/query.md` |
| 以 `/q` 或 `/q-save` 开头 | 查询 | `references/query.md` |
| 明确疑问句（什么、为什么、怎么、如何、是否） | 查询 | `references/query.md` |
| `/health-check` | 健康检查 | `references/maintain.md` |
| `/maintain` | 主动维护 | `references/maintain.md` |
| `/status` | 查看统计 | 读 log.md，统计近 7 天 INGEST 条数，直接回复 |
| `/inbox` | 查看暂存区 | 读 inbox.md，直接回复 |
| `/help` | 帮助 | 回复下方帮助文本 |
| 无法识别 | — | 询问用户意图，不猜测，不执行操作 |

读取 reference 文件后，按其中的步骤执行，不要跳步。

---

## Orientation（每次写入操作前必须执行）

在执行任何写入操作前，先读取以下文件建立上下文：

```
$VAULT/SCHEMA.md        （不存在则跳过）
$VAULT/AGENTS.md        （不存在则跳过；存在时，其页面格式规则优先于本 skill 的默认模板）
$VAULT/Wiki/index.md
$VAULT/Wiki/log.md      （只读最近 20-30 条）
```

这步至关重要：index.md 告诉你已有哪些知识页面（避免重复建页），log.md 提供最近的操作上下文（避免重复摄入）。

---

## 并发写入保护

所有写 `index.md` 和 `log.md` 的操作，必须通过以下方式之一保护：

**方式 A（推荐）：使用 skill 内置脚本**

```bash
SCRIPT_DIR="$(find ~/.claude ~/.hermes /usr/local/share -name 'safe_append.py' 2>/dev/null | head -1)"
python3 "$SCRIPT_DIR" "$VAULT/Wiki/log.md" "内容"
```

**方式 B：内联 Python（推荐用这个，最可靠）**

```python
import fcntl
from pathlib import Path

def safe_append(file_path, content):
    path = Path(file_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'a') as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        f.write(content + '\n')
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)

safe_append("$VAULT/Wiki/log.md", "内容")
```

---

## /help 回复内容

```
📚 Memex 指令说明

摄入内容（自动存入知识库）：
  · 直接发 URL、图片、文件、长文字（> 100 字）
  · 短备忘/想法直接发送，存入 Inbox

查询 Wiki：
  · 问：XXX
  · /q XXX
  · /q-save XXX    （查询并强制保存到知识库）

系统指令：
  · /status        — 最近 7 天摄入统计
  · /inbox         — 查看待处理备忘
  · /health-check  — Wiki 健康检查
  · /maintain      — 主动维护（发现改进机会）
  · /help          — 显示本说明
```

---

## 硬性约束（任何操作都必须遵守）

1. `raw/` 目录文件**只增不改**，禁止修改或删除已有文件内容
2. 写 `log.md` 和 `index.md` 前必须使用并发保护
3. vault 路径只从 `~/.memex/active-vault.txt` 读取
4. pages/ 中所有论断必须能追溯到具体 raw 文件；无法追溯的标注 `⚠️ 推测：...`
5. 发现矛盾时两处都加 `⚠️ CONFLICT with [[页面名]]`，不自动择一
6. 查询发现 Wiki 中无相关内容，明确回复「Wiki 中暂无此内容」，不编造

---

## Reference 文件索引

| 文件 | 包含内容 |
|------|---------|
| `references/ingest.md` | 内容摄入完整流程（URL/文件/笔记/短备忘） |
| `references/query.md` | Wiki 查询 + 问答持久化流程 |
| `references/maintain.md` | 健康检查 + 主动维护流程 |
| `references/daily-brief.md` | 每日摘要生成流程（需配置通知渠道） |
| `references/agents.md` | 所有页面模板、目录规范、log 格式 |
