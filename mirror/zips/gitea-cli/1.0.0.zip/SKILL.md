---
name: gitea-cli
description: "轻量级 Gitea CLI 工具，不依赖外部 tea 工具，直接通过 HTTP API 与 Gitea 服务器交互"
---

# Gitea CLI 技能

这是一个轻量级的 Gitea 命令行工具，不依赖外部 `tea` 工具，直接通过 HTTP API 与你的 Gitea 服务器交互。

## 🔧 初始化配置（必需）

### 第 1 步：必须初始化

**在使用任何功能前，必须先运行初始化命令：**
```bash
gitea-cli config save \
  --url "your-url" \
  --user "your-username" \
  --pass "your-password"
```

⚠️ **注意：** 所有命令都需要先完成初始化，否则会提示错误。

### 第 2 步：开始使用

初始化完成后，配置会自动保存到 `.env` 文件，之后可以直接使用其他命令：
```bash
gitea-cli repos list                    # 列出仓库
gitea-cli issues list owner/repo        # 列出问题
gitea-cli releases list owner/repo      # 列出发布
gitea-cli releases delete owner/repo v1.0.0  # 删除发布和标签
```

> 💡 **认证方式优先级：**
> 1. `GITEA_TOKEN` - 个人访问令牌
> 2. `GITEA_USER` + `GITEA_PASS` - 账号密码（默认）

## 📋 仓库管理

**列出仓库：**
```bash
gitea-cli repos list
```

**创建仓库：**
```bash
gitea-cli repo create my-project --description "我的项目"
```

**删除仓库：**
```bash
gitea-cli repo delete my-project
```

## 🐛 问题管理

**列出问题：**
```bash
gitea-cli issues list owner/repo
```

**创建问题：**
```bash
gitea-cli issue create owner/repo --title "Bug 标题" --body "问题描述"
```

**关闭问题：**
```bash
gitea-cli issue close owner/repo 123
```

## 🔄 拉取请求

**列出 PR：**
```bash
gitea-cli pr list owner/repo
```

**创建 PR：**
```bash
gitea-cli pr create owner/repo --title "新功能" --body "描述" --head feature-branch --base main
```

## 📦 发布管理

**列出发布：**
```bash
gitea-cli releases list owner/repo
```

**删除发布（连同标签）：**
```bash
gitea-cli releases delete owner/repo v1.0.0
```

⚠️ **注意：** 删除发布时会自动删除对应的 Git 标签，确保两者同时被清理。执行流程：
1. 先删除 Release（发布记录）
2. 再删除 Git Tag（版本标签）
3. 如果标签不存在会显示警告但不中断

## 🌿 分支管理

**列出分支：**
```bash
gitea-cli branches list owner/repo
```

**创建分支：**
```bash
gitea-cli branch create owner/repo new-branch --from main
```

## ⚡ 快速操作

**查看仓库信息：**
```bash
gitea-cli repo info owner/repo
```

**查看用户信息：**
```bash
gitea-cli user info username
```

**搜索仓库：**
```bash
gitea-cli search repos "关键词"
```

## 🔐 认证方式

**默认使用账号密码认证：**
```bash
export GITEA_USER="your-username"
export GITEA_PASS="your-password"
```

**也可以选择使用 Personal Access Token：**
```bash
export GITEA_TOKEN="your-personal-access-token"
```

> 💡 优先级：如果设置了 GITEA_TOKEN，则优先使用 token 认证，否则使用账号密码

## 🎯 特点

- ✅ 无需安装外部工具
- ✅ 纯 HTTP API 实现
- ✅ 支持自定义 Gitea 实例
- ✅ 轻量级，快速响应
- ✅ 完整的错误处理
- ✅ 删除发布自动清理标签

## 📝 输出格式

支持多种输出格式：
```bash
gitea-cli repos list --format json    # JSON 格式
gitea-cli repos list --format table   # 表格格式
gitea-cli repos list --format simple  # 简单文本
```
