#!/usr/bin/env python3
"""
轻量级 Gitea CLI 工具 - 不依赖外部 tea 工具
直接通过 HTTP API 与 Gitea 服务器交互
"""

import os
import sys
import json
import argparse
import urllib.request
import urllib.parse
import base64
from typing import Optional, Dict, Any, List

def get_workspace_env_path():
    """获取当前工作区的 .env 文件路径"""
    # 优先使用 OPENCLAW_WORKSPACE 环境变量
    workspace = os.environ.get('OPENCLAW_WORKSPACE')
    if workspace:
        return os.path.join(workspace, '.env')
    # 备选：使用当前代理的工作区（通过 PID 查找）
    # 查找 /root/.openclaw/workspace/ 下的工作区
    base_path = '/root/.openclaw/workspace/'
    if os.path.exists(base_path):
        for agent_name in os.listdir(base_path):
            agent_path = os.path.join(base_path, agent_name)
            if os.path.isdir(agent_path):
                env_file = os.path.join(agent_path, '.env')
                if os.path.exists(env_file):
                    return env_file
    # 最后 fallback 到当前目录
    return './.env'

def load_env_file(env_file: str = None):
    """从 .env 文件加载环境变量"""
    if env_file is None:
        env_file = get_workspace_env_path()
    if os.path.exists(env_file):
        with open(env_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key] = value

def save_to_env_file(key: str, value: str, env_file: str = None):
    """保存配置到 .env 文件"""
    if env_file is None:
        env_file = get_workspace_env_path()
    # 确保 .env 文件存在
    if not os.path.exists(env_file):
        os.makedirs(os.path.dirname(env_file), exist_ok=True)
        with open(env_file, 'w') as f:
            f.write("# Gitea CLI Configuration\n")
    
    # 读取现有内容
    env_content = {}
    if os.path.exists(env_file):
        with open(env_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    k, v = line.split('=', 1)
                    env_content[k] = v
    
    # 更新配置
    env_content[key] = value
    
    # 写回文件
    with open(env_file, 'w') as f:
        f.write("# Gitea CLI Configuration\n")
        for k, v in env_content.items():
            f.write(f"{k}={v}\n")
    
    print(f"✅ 已保存 {key} 到 .env 文件")

class GiteaCLI:
    def __init__(self):
        # 先加载 .env 文件
        load_env_file()
        
        self.base_url = os.getenv('GITEA_URL')
        self.token = os.getenv('GITEA_TOKEN')
        self.username = os.getenv('GITEA_USER')
        self.password = os.getenv('GITEA_PASS')
        
        # 必须初始化配置
        if not self.base_url:
            print("错误: 需要设置 GITEA_URL 环境变量")
            print("💡 使用: gitea-cli config save --url <地址> --user <用户名> --pass <密码>")
            sys.exit(1)
            
        # 优先使用账号密码（默认方式）
        if not self.token and not (self.username and self.password):
            print("错误: 需要设置 GITEA_USER/GITEA_PASS 环境变量（默认认证方式）")
            print("或者设置 GITEA_TOKEN 使用环境变量认证")
            print("💡 使用: gitea-cli config save --url <地址> --user <用户名> --pass <密码>")
            sys.exit(1)
    
    def _get_headers(self) -> Dict[str, str]:
        """获取请求头"""
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        if self.token:
            headers['Authorization'] = f'token {self.token}'
        return headers
    
    def _make_request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Dict[Any, Any]:
        """发送 HTTP 请求"""
        url = urllib.parse.urljoin(self.base_url, f'/api/v1{endpoint}')
        headers = self._get_headers()
        
        try:
            # 添加基本认证
            if self.username and self.password:
                auth_str = f"{self.username}:{self.password}"
                auth_bytes = auth_str.encode('ascii')
                base64_auth = base64.b64encode(auth_bytes).decode('ascii')
                headers['Authorization'] = f'Basic {base64_auth}'
            
            if method.upper() == 'GET':
                req = urllib.request.Request(url, headers=headers, method='GET')
            elif method.upper() == 'POST':
                json_data = json.dumps(data).encode('utf-8') if data else b''
                req = urllib.request.Request(url, data=json_data, headers=headers, method='POST')
            elif method.upper() == 'DELETE':
                req = urllib.request.Request(url, headers=headers, method='DELETE')
            else:
                raise ValueError(f"不支持的 HTTP 方法: {method}")
            
            with urllib.request.urlopen(req) as response:
                content = response.read().decode('utf-8')
                return json.loads(content) if content else {}
                
        except Exception as e:
            print(f"请求失败: {e}")
            sys.exit(1)
    
    def list_repos(self, format_type: str = 'table') -> None:
        """列出用户仓库"""
        repos = self._make_request('GET', '/user/repos')
        
        if format_type == 'json':
            print(json.dumps(repos, indent=2, ensure_ascii=False))
        elif format_type == 'simple':
            for repo in repos:
                print(f"{repo['full_name']}")
        else:  # table
            print(f"{'仓库名':<30} {'描述':<40} {'私有':<8} {'星标':<8}")
            print("-" * 90)
            for repo in repos:
                private = "是" if repo['private'] else "否"
                print(f"{repo['full_name']:<30} {repo['description'][:38]:<40} {private:<8} {repo['stars_count']:<8}")
    
    def create_repo(self, name: str, description: str = "", private: bool = False) -> None:
        """创建新仓库"""
        data = {
            'name': name,
            'description': description,
            'private': private,
            'auto_init': True
        }
        
        result = self._make_request('POST', '/user/repos', data)
        print(f"✅ 仓库创建成功: {result['html_url']}")
    
    def delete_repo(self, owner: str, repo: str) -> None:
        """删除仓库"""
        self._make_request('DELETE', f'/repos/{owner}/{repo}')
        print(f"✅ 仓库 {owner}/{repo} 已删除")
    
    def list_issues(self, owner: str, repo: str, format_type: str = 'table') -> None:
        """列出问题"""
        issues = self._make_request('GET', f'/repos/{owner}/{repo}/issues')
        
        if format_type == 'json':
            print(json.dumps(issues, indent=2, ensure_ascii=False))
        elif format_type == 'simple':
            for issue in issues:
                print(f"#{issue['number']}: {issue['title']}")
        else:  # table
            print(f"{'编号':<8} {'标题':<40} {'状态':<10} {'创建时间':<20}")
            print("-" * 80)
            for issue in issues:
                created_at = issue['created_at'][:19].replace('T', ' ')
                print(f"#{issue['number']:<7} {issue['title'][:38]:<40} {issue['state']:<10} {created_at:<20}")
    
    def create_issue(self, owner: str, repo: str, title: str, body: str = "") -> None:
        """创建问题"""
        data = {
            'title': title,
            'body': body
        }
        
        result = self._make_request('POST', f'/repos/{owner}/{repo}/issues', data)
        print(f"✅ 问题创建成功: #{result['number']} - {result['title']}")
    
    def list_releases(self, owner: str, repo: str, format_type: str = 'table') -> None:
        """列出发布"""
        releases = self._make_request('GET', f'/repos/{owner}/{repo}/releases')
        
        if format_type == 'json':
            print(json.dumps(releases, indent=2, ensure_ascii=False))
        elif format_type == 'simple':
            for release in releases:
                print(f"{release['tag_name']}: {release['name']}")
        else:  # table
            print(f"{'标签':<15} {'名称':<30} {'预发布':<10} {'创建时间':<20}")
            print("-" * 75)
            for release in releases:
                created_at = release['created_at'][:19].replace('T', ' ')
                prerelease = "是" if release['prerelease'] else "否"
                print(f"{release['tag_name']:<15} {release['name'][:28]:<30} {prerelease:<10} {created_at:<20}")
    
    def delete_release(self, owner: str, repo: str, tag_name: str) -> None:
        """删除发布及其关联的标签"""
        # 第一步：删除发布（release）
        print(f"正在删除发布：{tag_name}...")
        self._make_request('DELETE', f'/repos/{owner}/{repo}/releases/tags/{tag_name}')
        print(f"✅ 发布 {tag_name} 已删除")
        
        # 第二步：删除对应的标签（tag）
        print(f"正在删除标签：{tag_name}...")
        try:
            self._make_request('DELETE', f'/repos/{owner}/{repo}/tags/{tag_name}')
            print(f"✅ 标签 {tag_name} 已删除")
        except Exception as e:
            # 如果标签不存在或其他错误，打印警告但不中断
            if '404' in str(e):
                print(f"⚠️  标签 {tag_name} 不存在，可能已被删除")
            else:
                print(f"⚠️  删除标签时出现警告：{e}")

def main():
    parser = argparse.ArgumentParser(description='轻量级 Gitea CLI 工具')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # config 命令 - 保存配置到 .env 文件
    config_parser = subparsers.add_parser('config', help='保存配置到 .env 文件')
    config_subparsers = config_parser.add_subparsers(dest='subcommand')
    
    config_save = config_subparsers.add_parser('save', help='保存认证信息')
    config_save.add_argument('--url', required=True, help='Gitea 服务器地址')
    config_save.add_argument('--user', required=True, help='用户名')
    config_save.add_argument('--pass', dest='password', required=True, help='密码')
    
    # repos 命令
    repos_parser = subparsers.add_parser('repos', help='仓库管理')
    repos_subparsers = repos_parser.add_subparsers(dest='subcommand')
    
    repos_list = repos_subparsers.add_parser('list', help='列出仓库')
    repos_list.add_argument('--format', choices=['table', 'json', 'simple'], default='table')
    
    repos_create = repos_subparsers.add_parser('create', help='创建仓库')
    repos_create.add_argument('name', help='仓库名称')
    repos_create.add_argument('--description', default='', help='仓库描述')
    repos_create.add_argument('--private', action='store_true', help='创建私有仓库')
    
    repos_delete = repos_subparsers.add_parser('delete', help='删除仓库')
    repos_delete.add_argument('owner', help='仓库所有者')
    repos_delete.add_argument('repo', help='仓库名称')
    
    # issues 命令
    issues_parser = subparsers.add_parser('issues', help='问题管理')
    issues_subparsers = issues_parser.add_subparsers(dest='subcommand')
    
    issues_list = issues_subparsers.add_parser('list', help='列出问题')
    issues_list.add_argument('owner', help='仓库所有者')
    issues_list.add_argument('repo', help='仓库名称')
    issues_list.add_argument('--format', choices=['table', 'json', 'simple'], default='table')
    
    issues_create = issues_subparsers.add_parser('create', help='创建问题')
    issues_create.add_argument('owner', help='仓库所有者')
    issues_create.add_argument('repo', help='仓库名称')
    issues_create.add_argument('--title', required=True, help='问题标题')
    issues_create.add_argument('--body', default='', help='问题描述')
    
    # releases 命令
    releases_parser = subparsers.add_parser('releases', help='发布管理')
    releases_subparsers = releases_parser.add_subparsers(dest='subcommand')
    
    releases_list = releases_subparsers.add_parser('list', help='列出发布')
    releases_list.add_argument('owner', help='仓库所有者')
    releases_list.add_argument('repo', help='仓库名称')
    releases_list.add_argument('--format', choices=['table', 'json', 'simple'], default='table')
    
    releases_delete = releases_subparsers.add_parser('delete', help='删除发布和标签')
    releases_delete.add_argument('owner', help='仓库所有者')
    releases_delete.add_argument('repo', help='仓库名称')
    releases_delete.add_argument('tag_name', help='要删除的标签名（如 v1.0.0）')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    try:
        if args.command == 'config':
            if args.subcommand == 'save':
                save_to_env_file('GITEA_URL', args.url)
                save_to_env_file('GITEA_USER', args.user)
                save_to_env_file('GITEA_PASS', args.password)
                print("✅ 配置已保存到工作区 .env 文件")
                print("💡 现在可以直接使用其他命令，无需重复设置环境变量")
                sys.exit(0)
        
        cli = GiteaCLI()
        
        if args.command == 'repos':
            if args.subcommand == 'list':
                cli.list_repos(args.format)
            elif args.subcommand == 'create':
                cli.create_repo(args.name, args.description, args.private)
            elif args.subcommand == 'delete':
                cli.delete_repo(args.owner, args.repo)
        
        elif args.command == 'issues':
            if args.subcommand == 'list':
                cli.list_issues(args.owner, args.repo, args.format)
            elif args.subcommand == 'create':
                cli.create_issue(args.owner, args.repo, args.title, args.body)
        
        elif args.command == 'releases':
            if args.subcommand == 'list':
                cli.list_releases(args.owner, args.repo, args.format)
            elif args.subcommand == 'delete':
                cli.delete_release(args.owner, args.repo, args.tag_name)
    
    except KeyboardInterrupt:
        print("\n操作已取消")
        sys.exit(0)

if __name__ == '__main__':
    main()