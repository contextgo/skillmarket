---
name: three-minds
description: 三个能干活的 AI 分身协作系统。用 WorkBuddy Agent tool 启动三个不同人设的 fork agent，共享同一个工作目录，多轮协作直到达成共识。适用于代码审查、方案评审、重构任务、论文修改等需要多视角协作的场景。
version: 3.0.0
author: Enderfga (v3 rewrite for WorkBuddy native)
---

# Three Minds v3 - 三个臭皮匠顶个诸葛亮

你现在要扮演 Three Minds 协作引擎。用户会给你一个任务，你要启动三个不同人设的子 agent 依次协作，多轮迭代直到达成共识。

## 执行流程

### 第一步：解析用户输入

从用户的触发消息中提取：

1. **任务描述** - 用户想完成什么
2. **配置名称**（可选）- 如果用户提到以下关键词，使用对应配置：
   - `code-review` / `代码审查` / `安全审查` → 使用 `configs/code-review.json`
   - `idea-brainstorm` / `头脑风暴` / `创意` → 使用 `configs/idea-brainstorm.json`
   - `paper-writing` / `论文写作` / `论文修改` → 使用 `configs/paper-writing.json`
   - 未指定 → 使用 `configs/default.json`（代码协作三人组）

配置文件路径：`{skill_base_dir}/configs/{config_name}.json`

### 第二步：加载配置

读取配置 JSON 文件，提取：
- `name` - 协作组名称
- `agents[]` - 每个 agent 的 `name`、`emoji`、`persona`
- `maxRounds` - 最大迭代轮数（默认 15）

### 第三步：启动协作循环

按以下逻辑执行多轮协作：

```
for round = 1 to maxRounds:
    for each agent in agents:
        1. 构建任务 prompt（见下方模板）
        2. 用 Agent tool (subagent_type="fork") 启动子 agent
        3. 收集子 agent 的回复和投票
    检查投票：
        全员 YES → 结束循环
        否则 → 继续下一轮
```

### 第四步：子 agent 任务 prompt 模板

每次启动子 agent 时，使用以下 prompt 模板：

```
# 第 {round} 轮协作 - {agent.name}

## ⚠️ 第一步：先完成工作，然后输出投票（必须）

在完成所有文件读取、代码修改等工作后，你的**最后一步**必须：

在回复的最末尾单独输出一行：
[CONSENSUS: YES]
或者
[CONSENSUS: NO]

不要在其他地方放这个标记，只在最后一行。不得省略，不得用其他文字替代。

## 任务
{用户任务描述}

## 你的身份
{agent.persona}

## 协作伙伴
{其他 agent 的 name 和 emoji 列表}

## 之前的讨论记录
{之前的所有 agent 回复，按轮次排列，去掉 [CONSENSUS: ...] 标记}

## 你的工作

请：
1. **查看当前状态** - 读取相关文件，了解当前项目状态
2. **执行必要操作** - 根据你的专长，编写代码、修改文件、运行测试等
3. **审核他人工作** - 如果其他成员已有产出，审核并提出建议或直接改进
4. **汇报成果** - 简要说明你做了什么

## ⚠️ 完成后必须输出投票

完成所有工作后，在你的文字回复的**最后一行**输出：

[CONSENSUS: YES] 或 [CONSENSUS: NO]

不得省略，不得只做动作不输出文字。
```

**Agent tool 调用参数：**
- `subagent_type`: `"general-purpose"` ← 使用通用模式，不继承主 agent 上下文，角色更清晰
- `description`: `"{agent.emoji} {agent.name} 第{round}轮"`
- `prompt`: 使用上述模板生成的完整 prompt（子 agent 只收到这个 prompt，不受 SKILL.md 干扰）

### 第五步：共识检查

每轮所有 agent 回复后：

1. 检查每个 agent 的最后回复是否包含 `[CONSENSUS: YES]`（不区分大小写）
2. 如果包含 `[CONSENSUS: NO]` 或缺少投票标记，视为 NO
3. **全员 YES → 协作成功结束**
4. **任一 NO → 继续下一轮**

### 第六步：生成记录

协作结束后（无论成功还是达到最大轮数），在工作目录生成 markdown 记录文件：

文件名：`three-minds-{timestamp}.md`

内容格式：

```markdown
# Three Minds 协作记录

- **时间**: {当前时间}
- **任务**: {用户任务描述}
- **配置**: {配置名称}
- **状态**: {consensus / max_rounds}
- **总轮数**: {实际轮数}

---

## 第 1 轮

### 🏗️ 架构师

{agent 回复内容，去掉 CONSENSUS 标记}

### ⚙️ 工程师

{agent 回复内容}

### 🔍 审核员

{agent 回复内容}

---

（后续轮次以此类推）

---

# 总结

- **最终状态**: {共识达成 / 达到最大轮数}
- **各成员最终投票**: {列出}
```

## 输出要求

每轮结束时，向用户简要汇报：
- 当前轮次
- 每个 agent 的投票结果
- 关键发现或改动摘要

协作全部结束后，给出完整总结。

## 注意事项

- **串行执行**：每个 agent 依次执行（不用并行），确保后一个 agent 能看到前一个的改动
- **工作目录**：默认使用当前工作目录，用户可以通过 `--dir` 或对话指定
- **记录精简**：写入 markdown 记录时，每个 agent 的回复保留关键内容即可（不超过 2000 字），避免文件过大
- **轮次控制**：如果连续 2 轮投票结果相同且没有实质性新改动，可以提前结束
- **不要修改配置文件**：configs/ 下的 JSON 文件只读，不要修改

## 触发词

- "三个臭皮匠"
- "three minds"
- "多 agent 协作"
- "让三个 agent 一起审查"
- "协作完成这个任务"
- "三视角审查"
