# Three Minds v3 — 三个臭皮匠顶个诸葛亮

WorkBuddy 原生多 Agent 协作技能，让三个不同人设的 AI Agent 依次协作，多轮迭代直达成共识。

## ✨ 特性

- **WorkBuddy 原生**：基于 WorkBuddy Agent 工具，无需外部依赖
- **多角色配置**：内置 4 套预设角色配置，覆盖代码、审查、创意、写作场景
- **共识机制**：内置 `[CONSENSUS: YES/NO]` 投票机制，自动判断协作是否完成
- **完整记录**：自动生成 Markdown 协作记录，可追溯每一轮讨论内容
- **串行协作**：Agent 依次执行，后一个 Agent 能看到前一个的改动

## 🎯 适用场景

| 场景 | 触发词 | 使用配置 |
|------|--------|----------|
| 代码协作开发 | "三个臭皮匠"、"协作完成这个任务" | `default.json` |
| 代码审查 | "代码审查"、"安全审查" | `code-review.json` |
| 创意头脑风暴 | "头脑风暴"、"创意" | `idea-brainstorm.json` |
| 论文写作修改 | "论文写作"、"论文修改" | `paper-writing.json` |

## 📦 安装

```bash
# 通过 SkillHub 安装（推荐）
# 在 WorkBuddy 专家中心搜索 "Three Minds" 并安装

# 或手动安装
# 将本技能文件夹放到 ~/.workbuddy/skills/three-minds/
```

## 🚀 使用方法

在 WorkBuddy 对话中，使用以下任一方式触发：

```
@skill:"Three Minds" 帮我重构这个 Express 项目的路由结构

三个臭皮匠，帮我审查这段代码的安全性

让三个 agent 一起完成这个任务：优化数据库查询性能
```

## ⚙️ 预设配置

### 1. 代码协作三人组（`default.json`）
| 角色 | Emoji | 专长 |
|------|-------|------|
| 架构师 | 🏗️ | 代码结构、设计模式、可扩展性 |
| 工程师 | ⚙️ | 代码质量、错误处理、性能优化 |
| 审核员 | 🔍 | 代码规范、潜在 bug、安全问题 |

### 2. 代码审查三人组（`code-review.json`）
| 角色 | Emoji | 专长 |
|------|-------|------|
| 安全专家 | 🛡️ | SQL注入、XSS、CSRF、认证授权 |
| 性能工程师 | ⚡ | 算法复杂度、内存使用、缓存策略 |
| 质量审查员 | ✅ | 代码可读性、命名规范、测试覆盖 |

### 3. 科研创意头脑风暴（`idea-brainstorm.json`）
| 角色 | Emoji | 专长 |
|------|-------|------|
| 文献专家 | 📚 | 经典/前沿论文、创新点分析 |
| 创意发散者 | 💡 | 跨领域联想、反直觉假设 |
| 可行性审查员 | 🔬 | 技术可行性、MVP 实验设计 |

### 4. 论文写作与修改（`paper-writing.json`）
| 角色 | Emoji | 专长 |
|------|-------|------|
| 内容审稿人 | 📝 | 贡献评估、方法严谨性、实验设计 |
| 语言编辑 | ✏️ | 语法检查、学术写作规范、可读性 |
| 呈现顾问 | 🎯 | 叙事结构、图表呈现、亮点突出 |

## 📝 协作记录

每次协作结束后，会在工作目录自动生成 `three-minds-{timestamp}.md` 记录文件，包含：
- 协作时间、任务描述、使用配置
- 每一轮各 Agent 的回复内容
- 最终共识状态

## 🔧 技术原理

v3 版本完全基于 WorkBuddy 原生 Agent 工具重构：
- 使用 `subagent_type: "general-purpose"` 启动子 Agent
- 每个 Agent 接收独立的 prompt，不受主 Agent 上下文干扰
- 通过 `[CONSENSUS: YES/NO]` 标记实现共识投票
- 最大迭代轮数可配置（默认 15 轮）

## 🆚 v3 更新说明

| 变更 | v2（旧版） | v3（当前版） |
|------|------------|--------------|
| 依赖 | 需要 Claude Code CLI | WorkBuddy 原生，无外部依赖 |
| 实现方式 | TypeScript + spawnSync | Prompt-only + Agent 工具 |
| 上下文隔离 | 无 | 使用 general-purpose 子 Agent |
| 配置文件 | 无 | 4 套 JSON 预设配置 |

## 📋  Requirements

- WorkBuddy 最新版
- Agent 工具可用（内置）

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 License

MIT
