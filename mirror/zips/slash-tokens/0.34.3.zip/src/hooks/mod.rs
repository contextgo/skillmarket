//! Hook installation and lifecycle management for AI coding agents.

pub mod hook_audit_cmd;
pub mod hook_check;
pub mod hook_cmd;
pub mod init;
pub mod integrity;
pub mod permissions;
pub mod rewrite_cmd;
pub mod trust;
pub mod verify_cmd;
