# Changelog

## 1.1.0 — 2026-03-30

- Initial ClawHub publish bundle generated from `skills/game-feedback-audit/SKILL.md`.
- Added bundle metadata, README, and MANIFEST for OpenClaw / ClawHub distribution.
