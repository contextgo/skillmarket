---
name: topic-evaluation-scorecard
description: evaluate and rank major-theme editorial topics for international communication using a structured scorecard across source grounding, audience entry, distinctiveness, evidence strength, execution feasibility, amplification potential, and strategic fit. use when chatgpt needs to assess whether a topic is worth doing, compare multiple topic options, identify structural weaknesses, or recommend whether to scale, refine, delay, or drop a topic.
---

# Topic Evaluation Scorecard

Evaluate the strength, readiness, and strategic value of editorial topics for international communication.

This skill is for editorial judgment and prioritization. It does not generate the topic from scratch. It tests whether a topic is strong enough, distinctive enough, grounded enough, and executable enough to justify further investment.

## Core task
Given one or more topic proposals, produce a structured evaluation that answers:
- is this topic strong enough to pursue?
- what are its strongest advantages?
- what are its structural weaknesses?
- is it source-grounded and evidence-ready?
- is it easy enough for the target audience to enter?
- is it worth scaling into a multi-format package?

## Scorecard dimensions
Evaluate each topic across seven dimensions:
1. source grounding
2. audience entry
3. distinctiveness
4. evidence and scene strength
5. execution feasibility
6. amplification potential
7. strategic fit

Use the scoring guidance in `references/scoring-dimensions.md` and return the structure in `references/scorecard-output-template.md`.

## Editorial rules
- Score structure before enthusiasm.
- Weaknesses matter more than decorative strengths.
- Strategic fit is not enough without a good angle.
- Accessibility is not enough without distinctiveness.
- Scaling must be earned.

## Boundary
This skill is for topic assessment, ranking, and scale decisions. It is not for inventing topics from zero, writing finished plans, or post-publication analytics.
