# Scorecard Output Template

### Topic Definition
Restate the topic in one to three sentences.

### Evaluation Scope
State whether this is a single-topic assessment, topic comparison, scale-or-not decision, or repair diagnosis.

### Scorecard
For each of the seven dimensions, give:
- score: 1 to 5
- summary: brief judgment
- rationale: one sentence

### Strength Summary
List the topic’s strongest advantages.

### Structural Weaknesses
List the weaknesses most likely to reduce impact or execution quality.

### Scale Recommendation
Choose one: flagship scale, moderate package, lean execution only, or not yet suitable for amplification.

### Repair Priorities
List the top changes needed if the topic is promising but weak.

### Final Verdict
Choose one clear verdict and explain it briefly.
