# Scoring Dimensions

## Score meaning
Use a 1 to 5 scale.
- 5 = strong, clear advantage, little structural weakness
- 4 = solid and usable, with manageable weakness
- 3 = mixed, usable with caution or repair
- 2 = weak, significant structural problem
- 1 = very weak, not currently viable

## Dimension 1: Source grounding
Ask whether there is a true anchor case, continuity, and reportable evidence.

## Dimension 2: Audience entry
Ask whether the target audience can enter easily enough and whether there is a clear issue, scene, or question.

## Dimension 3: Distinctiveness
Ask whether the angle is generic or whether this institution can do it in a unique way.

## Dimension 4: Evidence and scene strength
Ask whether there is visible proof, people, places, archives, or contrasts.

## Dimension 5: Execution feasibility
Ask whether access, dependencies, and coordination load are manageable.

## Dimension 6: Amplification potential
Ask whether the topic can support an anchor product and whether scale reinforces or weakens it.

## Dimension 7: Strategic fit
Ask whether the topic fits institutional strengths, audience mission, and current communication need.

## Interpretation rule
Do not average mechanically. Look for fatal weaknesses.
