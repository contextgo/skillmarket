# Store Metadata

    ## Listing identity
    - **Display name:** Topic Evaluation Scorecard
    - **Slug:** `topic-evaluation-scorecard`
    - **Category:** editorial-planning
    - **Short description:** Score, compare, and prioritize editorial topic ideas.
    - **One-line positioning:** Evaluate whether a topic is worth doing, whether it should stay lean or scale up, and where it is structurally weak.

    ## Suggested tags
    - `editorial-planning`
- `evaluation`
- `prioritization`
- `scorecard`
- `strategy`
- `decision-support`

    ## Best-fit queries
    - Score this topic across grounding, entry, distinctiveness, and feasibility.
- Rank these three topic ideas for editorial priority.
- Should we scale this topic into a flagship package or keep it lean?

    ## Core use cases
    - Rank multiple topic ideas
- Decide whether a topic deserves flagship scale
- Identify repair priorities before production

    ## README intro block
    > Topic Evaluation Scorecard helps editorial teams and planning agents solve one specific planning problem with repeatable structure, output patterns, and reference materials. It is best used as one module inside a larger editorial planning system.

    ## Publish notes
    - Keep this skill listed separately rather than bundling it with all six skills.
    - Use a concise changelog line such as `Initial public release` or `Improved trigger wording and examples`.
    - Keep the public listing focused on the problem it solves, not the full six-skill architecture.
    - Recommended audience: editorial strategists, newsroom innovation teams, international communication planners, and multi-agent OpenClaw builders.
