#!/usr/bin/env python3
"""
多地图 POI 搜索 · 阶梯降级版（安全修复版）
- 高德优先 → 额度耗尽自动切百度 → 百度也耗尽自动切腾讯
- 高德Key必填，其他选填
- 三家按顺序排队，一家耗尽才换下一家，不同时用
- 彻底移除 subprocess/curl，纯 urllib 实现

用法: python amap_search.py 城市 "关键词1 关键词2" [输出前缀] [--out 目录]
"""

import sys, json, re, os, time
from urllib.request import urlopen, Request
from urllib.parse import quote
from urllib.error import URLError, HTTPError
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8')

MOBILE_RE = re.compile(r'1[3-9]\d{9}')

# ─── 输出目录（默认桌面）───────────────────────────────
OUT_DIR = os.path.expanduser('~/Desktop')

WORKSPACE = os.path.expanduser('~/.qclaw/workspace')
CACHE_DIR = os.path.join(WORKSPACE, '.map_cache')
os.makedirs(CACHE_DIR, exist_ok=True)

# ─── 配置文件 ───────────────────────────────────────────
def load_config():
    cfg_file = os.path.join(WORKSPACE, 'map_config.json')
    fallback  = os.path.join(WORKSPACE, 'amap_config.json')
    if os.path.exists(cfg_file):
        with open(cfg_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    if os.path.exists(fallback):
        with open(fallback, 'r', encoding='utf-8') as f:
            old = json.load(f)
            return {'amap_key': old.get('amap_key', ''),
                    'baidu_key': old.get('baidu_key', ''),
                    'tencent_key': old.get('tencent_key', '')}
    return {}


def http_get(url, timeout=15):
    """
    发送 HTTP GET 请求（纯 urllib，无 subprocess/curl）
    不验证 SSL 证书降级（部分地图 API 证书不完整），但仅访问已知官方域名
    """
    try:
        req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urlopen(req, timeout=timeout) as r:
            # 高德/百度/腾讯均返回 JSON
            raw = r.read()
            # 尝试 UTF-8，fallback GBK
            try:
                return json.loads(raw.decode('utf-8'))
            except UnicodeDecodeError:
                return json.loads(raw.decode('gbk', errors='replace'))
    except (HTTPError, URLError, TimeoutError, json.JSONDecodeError, ValueError):
        return {}


# ─── 高德 ───────────────────────────────────────────────
class AmapProvider:
    name = '高德地图'

    def __init__(self, key):
        self.key = key

    def get_districts(self, city):
        cache = os.path.join(CACHE_DIR, f'amap_{city}.json')
        if os.path.exists(cache):
            with open(cache, 'r', encoding='utf-8') as f:
                d = json.load(f)
                if d.get('_city') == city:
                    return {k: v for k, v in d.items() if not k.startswith('_')}

        # 只请求一次，解析 district 层级
        url = (f'https://restapi.amap.com/v3/config/district'
               f'?keywords={quote(city)}&subdistrict=2&extensions=base&key={self.key}')
        data = http_get(url)
        districts = data.get('districts', [])
        if not districts:
            return None

        # 找 city 级别节点
        city_node = districts[0]
        for d in districts:
            if d.get('level') == 'city':
                city_node = d
                break

        result = {}
        for d in city_node.get('districts', []):
            name = d.get('name', '')
            if not name:
                continue
            # 区下面的街道列表；如果没有街道就用 [name] 本身
            streets = [s['name'] for s in d.get('districts', []) if s.get('name')]
            result[name] = streets if streets else [name]

        # 缓存（不含内部 _city 字段）
        cache_data = dict(result)
        cache_data['_city'] = city
        with open(cache, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, ensure_ascii=False)
        return result

    def search(self, keyword, city, district=None, street=None, max_pages=20):
        """返回 {(name): (phone, addr)} 或 {'_limit': True}"""
        results = {}
        kw = f'{city} {district or ""} {street or ""} {keyword}'.strip()
        for page in range(1, max_pages + 1):
            url = (f'https://restapi.amap.com/v3/place/text'
                   f'?key={self.key}&keywords={quote(kw)}&city={quote(city)}'
                   f'&citylimit=true&page={page}&extensions=all&output=json')
            data = http_get(url)
            if data.get('info') == 'DAILY_QUERY_OVER_LIMIT':
                return {'_limit': True}
            pois = data.get('pois', [])
            if not pois:
                break
            for poi in pois:
                name = poi.get('name', '').strip()
                if not name or name in results:
                    continue
                tel = poi.get('tel', '')
                if isinstance(tel, list):
                    tel = tel[0] if tel else ''
                tel = str(tel).strip()
                if not tel:
                    continue
                for m in MOBILE_RE.findall(tel):
                    addr = poi.get('address', '')
                    if isinstance(addr, list):
                        addr = addr[0] if addr else ''
                    results[name] = (m, str(addr) if addr else ''); break
            total = int(data.get('count', 0))
            if page * 20 >= total:
                break
        return results


# ─── 百度 ───────────────────────────────────────────────
class BaiduProvider:
    name = '百度地图'

    def __init__(self, key):
        self.key = key

    def get_districts(self, city):
        return None   # 百度无行政区划接口

    def search(self, keyword, city, district=None, street=None, max_pages=20):
        results = {}
        for page in range(1, max_pages + 1):
            url = (f'https://api.map.baidu.com/place/v2/search'
                   f'?query={quote(keyword)}&region={quote(city)}'
                   f'&page_size=20&page_num={page - 1}'
                   f'&scope=2&output=json&ak={self.key}')
            data = http_get(url)
            s = data.get('status')
            if s in (302, 401, 402):
                return {'_limit': True}
            pois = data.get('results', [])
            if not pois:
                break
            for poi in pois:
                name = poi.get('name', '').strip()
                if not name or name in results:
                    continue
                tel = poi.get('telephone', '')
                if isinstance(tel, list):
                    tel = tel[0] if tel else ''
                tel = str(tel).strip()
                if not tel:
                    continue
                for m in MOBILE_RE.findall(tel):
                    addr = poi.get('address', '')
                    if isinstance(addr, list):
                        addr = addr[0] if addr else ''
                    results[name] = (m, str(addr) if addr else ''); break
            total = int(data.get('total', 0))
            if page * 20 >= total:
                break
        return results


# ─── 腾讯 ───────────────────────────────────────────────
class TencentProvider:
    name = '腾讯地图'

    def __init__(self, key):
        self.key = key

    def get_districts(self, city):
        return None   # 腾讯district只返回省级别

    def search(self, keyword, city, district=None, street=None, max_pages=74):
        results = {}
        boundary = f'region({quote(city)},0)'
        for idx in range(0, max_pages):
            url = (f'https://apis.map.qq.com/ws/place/v1/search'
                   f'?key={self.key}&keyword={quote(keyword)}'
                   f'&boundary={boundary}&page_size=20&page_index={idx}')
            data = http_get(url)
            if data.get('status') != 0:
                return {'_limit': True}
            pois = data.get('data', [])
            if not pois:
                break
            for poi in pois:
                name = poi.get('title', '').strip()
                if not name or name in results:
                    continue
                tel = str(poi.get('tel', '')).strip()
                if not tel:
                    continue
                for m in MOBILE_RE.findall(tel):
                    addr = poi.get('address', '')
                    if isinstance(addr, list):
                        addr = addr[0] if addr else ''
                    results[name] = (m, str(addr) if addr else ''); break
            total = int(data.get('count', 0))
            if (idx + 1) * 20 >= total:
                break
        return results


# ─── 降级管理器 ─────────────────────────────────────────
class CascadeSearch:
    """阶梯降级：一家耗尽才切下一家"""

    def __init__(self, cfg):
        self.providers = []
        if cfg.get('amap_key'):
            self.providers.append(('amap',    AmapProvider(cfg['amap_key'])))
        if cfg.get('baidu_key'):
            self.providers.append(('baidu',   BaiduProvider(cfg['baidu_key'])))
        if cfg.get('tencent_key'):
            self.providers.append(('tencent', TencentProvider(cfg['tencent_key'])))

    def banner(self, msg):
        print(f'\n{"="*52}')
        print(f'  {msg}')
        print(f'{"="*52}\n')

    def cascade_search(self, keywords, city, dist_map=None):
        merged = {}
        exhausted = []
        current_provider_idx = 0

        for kw in keywords:
            districts = sorted(dist_map.items()) if dist_map else [(None, [None])]

            for district, streets in districts:
                street_list = sorted(streets) if streets else [None]

                for street in street_list:
                    while current_provider_idx < len(self.providers):
                        pid, prov = self.providers[current_provider_idx]

                        if pid in exhausted:
                            current_provider_idx += 1
                            continue

                        label = f'{city} {district or ""} {street or ""} {kw}'
                        print(f'  [{prov.name}] {label} ... ', end='', flush=True)

                        results = prov.search(kw, city, district, street)

                        if results.get('_limit'):
                            exhausted.append(pid)
                            next_names = [p[1].name for p in self.providers
                                          if p[0] not in exhausted]
                            self.banner(f'{prov.name} 今日额度已用尽')
                            if next_names:
                                self.banner(f'已切换到 {next_names[0]}，继续搜索...')
                            else:
                                self._no_quota_hint(pid)
                                return merged
                            current_provider_idx += 1
                            break

                        new = 0
                        for name, val in results.items():
                            if name not in merged:
                                merged[name] = val
                                new += 1
                        print(f'{len(results)}条（累计{len(merged)}）')
                        time.sleep(0.1)
                        break

                    if current_provider_idx >= len(self.providers):
                        self._no_quota_hint(exhausted[-1] if exhausted else None)
                        return merged

        return merged

    def _no_quota_hint(self, last_pid):
        has_baidu   = any(p[0] == 'baidu'    for p in self.providers)
        has_tencent = any(p[0] == 'tencent'  for p in self.providers)
        if last_pid == 'amap' and not has_baidu:
            self.banner('高德额度已用完，可以用百度免费额度\n'
                        '  申请地址: https://lbsyun.baidu.com/apiconsole/key/create\n'
                        '  配置: map_config.json 添加 "baidu_key"')
        elif last_pid == 'baidu' and not has_tencent:
            self.banner('百度额度已用完，可以用腾讯免费额度\n'
                        '  申请地址: https://lbs.qq.com/console/mykey.html\n'
                        '  配置: map_config.json 添加 "tencent_key"')
        else:
            self.banner('三家地图额度均已耗尽，搜索终止')


# ─── 文件保存 ───────────────────────────────────────────
def _safe_str(v):
    """安全转字符串，处理 list/dict 等异常类型"""
    if isinstance(v, list):
        return v[0] if v else ''
    if isinstance(v, dict):
        return ''
    return str(v) if v else ''


def save_csv(data, path):
    """纯CSV保存，不依赖openpyxl"""
    with open(path, 'w', encoding='utf-8-sig') as f:
        f.write('\ufeff店名,手机号,地址\n')
        for name, v in sorted(data.items()):
            phone = _safe_str(v[0]) if isinstance(v, tuple) else _safe_str(v)
            addr  = _safe_str(v[1]) if isinstance(v, tuple) else ''
            f.write(f'{name},{phone},{addr}\n')


def save_excel(data, path):
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except ImportError:
        return  # 交给 save_csv 兜底
    wb = Workbook()
    ws = wb.active
    ws.title = '商家手机号'
    for cell, text in [(ws['A1'], '店名'), (ws['B1'], '手机号'), (ws['C1'], '地址')]:
        cell.value = text
        cell.font = Font(bold=True)
    for i, (name, v) in enumerate(sorted(data.items()), start=2):
        phone = _safe_str(v[0]) if isinstance(v, tuple) else _safe_str(v)
        addr  = _safe_str(v[1]) if isinstance(v, tuple) else ''
        ws[f'A{i}'] = name
        ws[f'B{i}'] = phone
        ws[f'C{i}'] = addr
    ws.column_dimensions['A'].width = 38
    ws.column_dimensions['B'].width = 15
    ws.column_dimensions['C'].width = 55
    wb.save(path)


def save_vcf(data, path):
    with open(path, 'w', encoding='utf-8') as f:
        for name, v in sorted(data.items()):
            phone = _safe_str(v[0]) if isinstance(v, tuple) else _safe_str(v)
            addr  = _safe_str(v[1]) if isinstance(v, tuple) else ''
            f.write('BEGIN:VCARD\nVERSION:3.0\n'
                    f'FN:{name}\nTEL;TYPE=CELL:{phone}\n')
            if addr:
                f.write(f'ADR:{addr}\n')
            f.write('END:VCARD\n')
    print(f'  通讯录已保存: {path} ({len(data)}条)  <- 可导入手机通讯录')


# ─── 主函数 ─────────────────────────────────────────────
def main():
    global OUT_DIR
    out_override = None
    args = []
    i = 1
    while i < len(sys.argv):
        a = sys.argv[i]
        if a == '--out':
            out_override = sys.argv[i + 1] if i + 1 < len(sys.argv) else None
            i += 2
        elif a.startswith('--out='):
            out_override = a[6:].strip().strip('"\'')
            i += 1
        else:
            args.append(a)
            i += 1

    if len(args) < 2:
        print('用法: python amap_search.py 城市 "关键词" [文件名前缀] [--out 输出目录]')
        print()
        print('示例:')
        print('  python amap_search.py 北京 "火锅"              # 搜索北京火锅，结果存桌面')
        print('  python amap_search.py 上海 "奶茶 咖啡" 奶茶    # 自定义文件名')
        print('  python amap_search.py 厦门 "蛋糕" --out /tmp   # 指定输出到 /tmp')
        print()
        print('结果文件（自动保存到桌面）:')
        print('  xxx.csv    <- 可用Excel/Numbers打开')
        print('  xxx.vcf   <- 可导入手机通讯录')
        print('  xxx.xlsx   <- Excel格式')
        print()
        print('配置文件: ~/.qclaw/workspace/map_config.json')
        print('  amap_key    - 高德Key（必填）')
        print('  baidu_key   - 百度Key（选填，高德用尽后自动切换）')
        print('  tencent_key - 腾讯Key（选填，百度也用尽后自动切换）')
        sys.exit(1)

    city     = args[0]
    keywords = args[1].split()
    prefix   = args[2] if len(args) > 2 else f'{city}_poi'

    if out_override:
        OUT_DIR = out_override
    os.makedirs(OUT_DIR, exist_ok=True)
    print(f'输出目录: {OUT_DIR}')

    cfg = load_config()
    if not cfg.get('amap_key'):
        print('\n' + '=' * 52)
        print('  请先配置高德地图Key（高德有免费额度）')
        print('=' * 52)
        print('\n申请地址: https://console.amap.com/dev/key/app')
        print('  1. 注册高德开发者账号')
        print('  2. 创建应用，选择「Web服务」平台')
        print('  3. 复制Key到配置文件：')
        print('\n配置文件: ~/.qclaw/workspace/map_config.json')
        print('  {"amap_key": "你申请的Key"}')
        print('\n' + '=' * 52)
        sys.exit(1)

    if not cfg.get('baidu_key'):
        print('  提示: 高德用完后可用百度免费额度')
        print('     百度申请地址: https://lbsyun.baidu.com/apiconsole/key/create')
        print()
    if not cfg.get('tencent_key'):
        print('  提示: 百度用完后可用腾讯免费额度')
        print('     腾讯申请地址: https://lbs.qq.com/console/mykey.html')
        print()

    cs = CascadeSearch(cfg)
    names = [p[1].name for p in cs.providers]
    print(f'\n已启用: {" -> ".join(names)}（按顺序降级）')
    print(f'搜索: {city} x {keywords}\n')

    dist_map = None
    if cs.providers and cs.providers[0][0] == 'amap':
        print('正在获取行政区划...')
        dist_map = cs.providers[0][1].get_districts(city)
        if dist_map:
            print(f'获取到 {len(dist_map)} 个区，三层搜索...\n')
        else:
            print('行政区划获取失败，降级为城市级搜索...\n')

    merged = cs.cascade_search(keywords, city, dist_map)

    print(f'\n{"=" * 52}')
    print(f'搜索完成！共 {len(merged)} 个商家')
    print(f'{"=" * 52}\n')

    xlsx = os.path.join(OUT_DIR, f'{prefix}.xlsx')
    vcf  = os.path.join(OUT_DIR, f'{prefix}.vcf')
    csv  = os.path.join(OUT_DIR, f'{prefix}.csv')
    save_excel(merged, xlsx)
    save_vcf(merged, vcf)
    save_csv(merged, csv)
    print(f'  表格已保存: {xlsx} ({len(merged)}条)  <- Excel')
    print(f'  表格已保存: {csv} ({len(merged)}条)  <- CSV可用Excel/Numbers打开')
    print(f'  通讯录已保存: {vcf} ({len(merged)}条)  <- 可导入手机通讯录')


if __name__ == '__main__':
    main()
