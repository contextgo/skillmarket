#!/usr/bin/env node
/**
 * PPT 元素重叠检查脚本
 * 使用 jszip + xml2js 解析 PPTX 文件，检查元素位置重叠问题
 */

import JSZip from 'jszip';
import { parseString } from 'xml2js';
import fs from 'fs';
import path from 'path';

// EMU 转 inch (1 inch = 914400 EMU)
const EMU_PER_INCH = 914400;

function emuToInch(emu) {
  return emu / EMU_PER_INCH;
}

function inchToEmu(inch) {
  return inch * EMU_PER_INCH;
}

function getShapeBounds(shapeElement) {
  // 从 XML 中提取位置和尺寸
  const spPr = shapeElement['p:spPr']?.[0] || shapeElement;
  const xfrm = spPr['a:xfrm']?.[0];

  if (!xfrm) return null;

  const off = xfrm['a:off']?.[0];
  const ext = xfrm['a:ext']?.[0];

  if (!off || !ext) return null;

  const left = parseInt(off.$.x || 0);
  const top = parseInt(off.$.y || 0);
  const width = parseInt(ext.$.cx || 0);
  const height = parseInt(ext.$.cy || 0);

  return {
    left, top, right: left + width, bottom: top + height,
    width, height,
  };
}

function getShapeText(shapeElement) {
  const txBody = shapeElement['p:txBody']?.[0];
  if (!txBody) return null;

  const bodyPr = txBody['a:bodyPr']?.[0];
  const p = txBody['a:p']?.[0];
  if (!p) return null;

  const r = p['a:r']?.[0];
  if (!r) return null;

  const t = r['a:t']?.[0];
  return t ? String(t) : null;
}

function boundsOverlap(bounds1, bounds2, tolerance = 10000) {
  // 扩展边界以考虑容差
  const b1 = {
    left: bounds1.left - tolerance,
    top: bounds1.top - tolerance,
    right: bounds1.right + tolerance,
    bottom: bounds1.bottom + tolerance,
  };

  const b2 = {
    left: bounds2.left - tolerance,
    top: bounds2.top - tolerance,
    right: bounds2.right + tolerance,
    bottom: bounds2.bottom + tolerance,
  };

  // 检查是否重叠
  if (b1.right < b2.left || b2.right < b1.left) return false;
  if (b1.bottom < b2.top || b2.bottom < b1.top) return false;

  return true;
}

function boundsContain(outer, inner, tolerance = 5000) {
  return (
    inner.left >= outer.left - tolerance &&
    inner.top >= outer.top - tolerance &&
    inner.right <= outer.right + tolerance &&
    inner.bottom <= outer.bottom + tolerance
  );
}

function calculateOverlapRatio(bounds1, bounds2) {
  const overlapLeft = Math.max(bounds1.left, bounds2.left);
  const overlapTop = Math.max(bounds1.top, bounds2.top);
  const overlapRight = Math.min(bounds1.right, bounds2.right);
  const overlapBottom = Math.min(bounds1.bottom, bounds2.bottom);

  if (overlapRight <= overlapLeft || overlapBottom <= overlapTop) return 0;

  const overlapArea = (overlapRight - overlapLeft) * (overlapBottom - overlapTop);
  const area1 = bounds1.width * bounds1.height;
  const area2 = bounds2.width * bounds2.height;

  const ratio1 = area1 > 0 ? overlapArea / area1 : 0;
  const ratio2 = area2 > 0 ? overlapArea / area2 : 0;

  return Math.max(ratio1, ratio2);
}

async function parseSlide(slideXml) {
  return new Promise((resolve, reject) => {
    parseString(slideXml, { explicitArray: true }, (err, result) => {
      if (err) reject(err);
      else resolve(result);
    });
  });
}

async function checkPptOverlap(pptFile) {
  try {
    const buffer = fs.readFileSync(pptFile);
    const zip = await JSZip.loadAsync(buffer);

    // 获取幻灯片尺寸
    let slideWidth = inchToEmu(13.333);
    let slideHeight = inchToEmu(7.5);

    // 尝试从 presentation.xml 获取尺寸
    const presentationXml = await zip.file('ppt/presentation.xml')?.async('string');
    if (presentationXml) {
      const presData = await parseSlide(presentationXml);
      const sldSz = presData?.['p:presentation']?.['p:sldSz']?.[0]?.$;
      if (sldSz) {
        slideWidth = parseInt(sldSz.cx || slideWidth);
        slideHeight = parseInt(sldSz.cy || slideHeight);
      }
    }

    console.log(`📄 PPT 文件: ${pptFile}`);
    console.log(`📐 幻灯片尺寸: ${emuToInch(slideWidth).toFixed(2)}" × ${emuToInch(slideHeight).toFixed(2)}"`);

    // 获取所有幻灯片
    const slideFiles = Object.keys(zip.files)
      .filter(name => name.match(/^ppt\/slides\/slide\d+\.xml$/))
      .sort();

    console.log(`📊 幻灯片数量: ${slideFiles.length}`);
    console.log();

    const allOverlapIssues = [];
    const allBoundaryIssues = [];

    for (const slideFile of slideFiles) {
      const slideNum = parseInt(slideFile.match(/slide(\d+)\.xml$/)[1]);
      const slideXml = await zip.file(slideFile).async('string');
      const slideData = await parseSlide(slideXml);

      // 获取所有形状
      const spTree = slideData?.['p:sld']?.['p:cSld']?.[0]?.['p:spTree']?.[0];
      if (!spTree) continue;

      const shapes = spTree['p:sp'] || [];
      const shapeBounds = [];

      shapes.forEach((shape, index) => {
        const bounds = getShapeBounds(shape);
        if (bounds) {
          const text = getShapeText(shape);
          shapeBounds.push({
            index,
            bounds,
            text: text ? text.slice(0, 30) + (text.length > 30 ? '...' : '') : `[Shape ${index}]`,
            isBackground: bounds.width > inchToEmu(12) && bounds.height > inchToEmu(6),
          });
        }
      });

      // 检查重叠
      for (let i = 0; i < shapeBounds.length; i++) {
        for (let j = i + 1; j < shapeBounds.length; j++) {
          const shape1 = shapeBounds[i];
          const shape2 = shapeBounds[j];

          // 跳过背景形状
          if (shape1.isBackground || shape2.isBackground) continue;

          if (boundsOverlap(shape1.bounds, shape2.bounds)) {
            // 检查容器关系
            if (boundsContain(shape1.bounds, shape2.bounds)) continue;
            if (boundsContain(shape2.bounds, shape1.bounds)) continue;

            const overlapRatio = calculateOverlapRatio(shape1.bounds, shape2.bounds);

            // 重叠比例小于 15% 可接受
            if (overlapRatio < 0.15) continue;

            allOverlapIssues.push({
              slide: slideNum,
              shape1: shape1.text,
              shape2: shape2.text,
              pos1: `(${emuToInch(shape1.bounds.left).toFixed(2)}", ${emuToInch(shape1.bounds.top).toFixed(2)}")`,
              pos2: `(${emuToInch(shape2.bounds.left).toFixed(2)}", ${emuToInch(shape2.bounds.top).toFixed(2)}")`,
              overlapRatio,
            });
          }
        }
      }

      // 检查边界
      const tolerance = inchToEmu(0.1);
      shapeBounds.forEach(shape => {
        if (shape.isBackground) return;

        const { bounds, text } = shape;

        if (bounds.right > slideWidth + tolerance) {
          allBoundaryIssues.push({
            slide: slideNum,
            type: '超出右边界',
            shape: text,
            right: `${emuToInch(bounds.right).toFixed(2)}"`,
            limit: `${emuToInch(slideWidth).toFixed(2)}"`,
          });
        }

        if (bounds.bottom > slideHeight + tolerance) {
          allBoundaryIssues.push({
            slide: slideNum,
            type: '超出下边界',
            shape: text,
            bottom: `${emuToInch(bounds.bottom).toFixed(2)}"`,
            limit: `${emuToInch(slideHeight).toFixed(2)}"`,
          });
        }

        if (bounds.left < -tolerance) {
          allBoundaryIssues.push({
            slide: slideNum,
            type: '超出左边界',
            shape: text,
            left: `${emuToInch(bounds.left).toFixed(2)}"`,
          });
        }

        if (bounds.top < -tolerance) {
          allBoundaryIssues.push({
            slide: slideNum,
            type: '超出上边界',
            shape: text,
            top: `${emuToInch(bounds.top).toFixed(2)}"`,
          });
        }
      });
    }

    // 输出重叠问题
    if (allOverlapIssues.length > 0) {
      console.log('⚠️  发现元素重叠问题:');
      console.log('-'.repeat(60));
      allOverlapIssues.forEach(issue => {
        console.log(`  幻灯片 ${issue.slide}:`);
        console.log(`    元素1: "${issue.shape1}" 位置 ${issue.pos1}`);
        console.log(`    元素2: "${issue.shape2}" 位置 ${issue.pos2}`);
        console.log();
      });
    } else {
      console.log('✅ 未发现元素重叠问题');
    }

    console.log();

    // 输出边界问题
    if (allBoundaryIssues.length > 0) {
      console.log('⚠️  发现边界问题:');
      console.log('-'.repeat(60));
      allBoundaryIssues.forEach(issue => {
        console.log(`  幻灯片 ${issue.slide} - ${issue.type}:`);
        console.log(`    元素: "${issue.shape}"`);
        if (issue.limit) {
          console.log(`    当前: ${issue.right || issue.bottom}, 限制: ${issue.limit}`);
        } else {
          console.log(`    当前位置: ${issue.left || issue.top}`);
        }
        console.log();
      });
    } else {
      console.log('✅ 未发现边界问题');
    }

    // 总结
    console.log();
    console.log('='.repeat(60));
    const totalIssues = allOverlapIssues.length + allBoundaryIssues.length;
    if (totalIssues === 0) {
      console.log('✅ PPT 检查通过，未发现问题');
      return true;
    } else {
      console.log(`❌ PPT 检查完成，发现 ${totalIssues} 个问题需要修复`);
      return false;
    }
  } catch (err) {
    console.error(`❌ 无法打开 PPT 文件: ${err.message}`);
    return false;
  }
}

// CLI 入口
const pptFile = process.argv[2];

if (!pptFile) {
  console.error('Usage: node check_ppt_overlap.js <ppt_file>');
  process.exit(1);
}

checkPptOverlap(path.resolve(pptFile)).then(success => {
  process.exit(success ? 0 : 1);
});