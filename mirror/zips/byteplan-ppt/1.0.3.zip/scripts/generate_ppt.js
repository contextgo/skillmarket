#!/usr/bin/env node
/**
 * BytePlan PPT 报告生成脚本
 * 设计风格与 byteplan-html 完全一致
 * 
 * 特点：
 * - 紫色渐变封面和结尾页
 * - 深色渐变内容页
 * - 卡片式设计
 * - 微软雅黑字体
 * - 与 HTML 风格统一
 */

import PptxGenJS from 'pptxgenjs';
import fs from 'fs';
import path from 'path';

// ============ 颜色配置（与 HTML 一致）============
const COLORS = {
  // 主题色
  purple: '667eea',
  darkPurple: '764ba2',
  
  // 背景色
  darkBg: '1a1a2e',
  darkBg2: '16213e',
  darkBg3: '0f3460',
  
  // 文字色
  textWhite: 'FFFFFF',
  textGray: 'CBD5E1',
  textMuted: '94A3B8',
  
  // 数据色
  green: '4ade80',
  blue: '60a5fa',
  pink: 'f472b6',
  orange: 'fbbf24',
  red: 'f87171',
  cyan: '06B6D4',
};

// 字体配置
const FONT = '微软雅黑';

// 图表配色
const CHART_COLORS = [COLORS.green, COLORS.blue, COLORS.pink, COLORS.purple, COLORS.orange];

// ============ 第1页：封面（紫色渐变）============
function createCoverSlide(pptx, data) {
  const slide = pptx.addSlide();
  slide.background = { color: COLORS.purple };

  // 主标题
  slide.addText(data.title || '数据分析报告', {
    x: 0, y: 1.8, w: 10, h: 0.8,
    fontSize: 44, bold: true, color: COLORS.textWhite, align: 'center', fontFace: FONT
  });

  // 副标题
  if (data.subtitle) {
    slide.addText(data.subtitle, {
      x: 0, y: 2.7, w: 10, h: 0.5,
      fontSize: 22, color: COLORS.textGray, align: 'center', fontFace: FONT
    });
  }

  // 数据周期
  if (data.period) {
    slide.addText(data.period, {
      x: 0, y: 3.3, w: 10, h: 0.4,
      fontSize: 16, color: COLORS.textMuted, align: 'center', fontFace: FONT
    });
  }

  // 租户信息（圆角卡片）
  slide.addShape('roundRect', {
    x: 3.5, y: 4.0, w: 3, h: 0.5,
    fill: { color: COLORS.textWhite, transparency: 85 },
    line: { width: 0 }
  });
  slide.addText(data.source || 'BytePlan 数据平台', {
    x: 3.5, y: 4.0, w: 3, h: 0.5,
    fontSize: 11, color: COLORS.textWhite, align: 'center', fontFace: FONT
  });
}

// ============ 第2页：目录 ============
function createTocSlide(pptx, data) {
  const slide = pptx.addSlide();
  slide.background = { color: COLORS.darkBg };

  slide.addText('目录', {
    x: 0.5, y: 0.3, w: 9, h: 0.7,
    fontSize: 36, bold: true, color: COLORS.textWhite, fontFace: FONT
  });

  const sections = data.sections || ['核心发现摘要', '关键指标概览', '数据分析', '洞察建议'];
  
  sections.forEach((section, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    // 两列布局，中间留出间距
    const x = col === 0 ? 0.5 : 5.3;
    const y = 1.2 + row * 0.85;

    // 卡片背景（宽度调整为4.2，两列之间有0.6的间距）
    slide.addShape('roundRect', {
      x, y, w: 4.2, h: 0.6,
      fill: { color: COLORS.textWhite, transparency: 90 },
      line: { width: 0 }
    });

    // 编号和文字合并为一个文本，避免换行问题
    const numStr = (i + 1).toString().padStart(2, '0');
    slide.addText([
      { text: numStr, options: { bold: true, color: COLORS.purple, fontSize: 16 } },
      { text: '  ' + section, options: { color: COLORS.textWhite, fontSize: 13 } }
    ], {
      x: x + 0.2, y: y + 0.12, w: 3.8, h: 0.4,
      fontFace: FONT, align: 'left', valign: 'middle'
    });
  });
}

// ============ 第3页：核心发现摘要（三卡片）============
function createSummarySlide(pptx, data) {
  const slide = pptx.addSlide();
  slide.background = { color: COLORS.darkBg3 };

  slide.addText('🏆 贡献最大的三个要素', {
    x: 0, y: 0.4, w: 10, h: 0.6,
    fontSize: 28, bold: true, color: COLORS.textWhite, align: 'center', fontFace: FONT
  });

  const summary = data.summary || [
    { rank: '🥇 第一名', name: '项目A', type: '类型', value: '¥1,000,000', rate: '贡献率 68%' },
    { rank: '🥈 第二名', name: '项目B', type: '类型', value: '¥500,000', rate: '贡献率 50%' },
    { rank: '🥉 第三名', name: '项目C', type: '类型', value: '¥300,000', rate: '贡献率 40%' }
  ];

  summary.forEach((item, i) => {
    const x = 0.8 + i * 3.1;

    // 卡片背景
    slide.addShape('roundRect', {
      x, y: 1.3, w: 2.8, h: 3.2,
      fill: { color: COLORS.textWhite, transparency: 90 },
      line: { color: COLORS.textWhite, transparency: 80, width: 1 }
    });

    // 排名
    slide.addText(item.rank || '', {
      x, y: 1.5, w: 2.8, h: 0.5,
      fontSize: 16, color: COLORS.orange, align: 'center', fontFace: FONT
    });

    // 名称
    slide.addText(item.name || '', {
      x, y: 2.0, w: 2.8, h: 0.5,
      fontSize: 26, bold: true, color: COLORS.textWhite, align: 'center', fontFace: FONT
    });

    // 类型
    slide.addText(item.type || '', {
      x, y: 2.5, w: 2.8, h: 0.4,
      fontSize: 12, color: COLORS.textMuted, align: 'center', fontFace: FONT
    });

    // 数值（绿色）
    slide.addText(item.value || '', {
      x, y: 3.1, w: 2.8, h: 0.6,
      fontSize: 22, bold: true, color: COLORS.green, align: 'center', fontFace: FONT
    });

    // 贡献率（蓝色）
    slide.addText(item.rate || '', {
      x, y: 3.7, w: 2.8, h: 0.4,
      fontSize: 14, color: COLORS.blue, align: 'center', fontFace: FONT
    });
  });
}

// ============ 第4页：关键指标概览（四卡片）============
function createKpiSlide(pptx, data) {
  const slide = pptx.addSlide();
  slide.background = { color: COLORS.darkBg };

  slide.addText('📊 关键指标概览', {
    x: 0, y: 0.4, w: 10, h: 0.6,
    fontSize: 28, bold: true, color: COLORS.textWhite, align: 'center', fontFace: FONT
  });

  const kpis = data.kpis || [
    { icon: '💰', label: '指标1', value: '1,000', unit: '元' },
    { icon: '📈', label: '指标2', value: '74%', unit: '' },
    { icon: '🌍', label: '指标3', value: '500', unit: '元' },
    { icon: '⚠️', label: '指标4', value: '2', unit: '个' }
  ];

  kpis.forEach((kpi, i) => {
    const x = 0.6 + i * 2.35;

    // 卡片背景
    slide.addShape('roundRect', {
      x, y: 1.3, w: 2.1, h: 3.0,
      fill: { color: COLORS.textWhite, transparency: 90 },
      line: { width: 0 }
    });

    // 图标
    slide.addText(kpi.icon || '📊', {
      x, y: 1.5, w: 2.1, h: 0.6,
      fontSize: 32, align: 'center'
    });

    // 标签
    slide.addText(kpi.label || '', {
      x, y: 2.2, w: 2.1, h: 0.4,
      fontSize: 11, color: COLORS.textMuted, align: 'center', fontFace: FONT
    });

    // 数值（绿色）
    slide.addText(kpi.value || '', {
      x, y: 2.6, w: 2.1, h: 0.6,
      fontSize: 24, bold: true, color: COLORS.green, align: 'center', fontFace: FONT
    });

    // 单位
    slide.addText(kpi.unit || '', {
      x, y: 3.2, w: 2.1, h: 0.3,
      fontSize: 10, color: COLORS.textMuted, align: 'center', fontFace: FONT
    });
  });
}

// ============ 第5-7页：图表幻灯片（使用形状绘制，兼容性最好）============
function createChartSlides(pptx, data) {
  const chartSlides = [];
  
  // 支持两种格式：新的 charts 数组 或 旧的 barChart/ratioData/rankingData
  let processedCharts = [];
  
  if (data.charts && Array.isArray(data.charts)) {
    processedCharts = data.charts.map((chart, index) => ({
      title: chart.title || `图表 ${index + 1}`,
      type: chart.type || 'bar',
      data: chart.data || [],
      canvasId: `chart_${index}`
    }));
  } else {
    if (data.barChart && data.barChart.data) {
      processedCharts.push({
        title: data.barChart.title || '数据对比',
        type: 'bar',
        data: data.barChart.data,
        canvasId: 'barChart'
      });
    }
    if (data.ratioData && data.ratioData.data) {
      processedCharts.push({
        title: data.ratioData.title || '贡献率对比',
        type: 'horizontalBar',
        data: data.ratioData.data,
        canvasId: 'ratioData'
      });
    }
    if (data.rankingData && data.rankingData.data) {
      processedCharts.push({
        title: data.rankingData.title || '排行榜',
        type: 'ranking',
        data: data.rankingData.data,
        canvasId: 'rankingData'
      });
    }
  }
  
  // 为每个图表创建幻灯片
  processedCharts.forEach((chart, index) => {
    const slide = pptx.addSlide();
    const bgColors = [COLORS.darkBg2, COLORS.darkBg3, COLORS.darkBg];
    slide.background = { color: bgColors[index % 3] };
    
    slide.addText('📊 ' + chart.title, {
      x: 0, y: 0.3, w: 10, h: 0.6,
      fontSize: 26, bold: true, color: COLORS.textWhite, align: 'center', fontFace: FONT
    });
    
    // 图表区域背景
    slide.addShape('roundRect', {
      x: 0.8, y: 1.0, w: 8.4, h: 4.0,
      fill: { color: '1E293B' },
      line: { width: 0 }
    });
    
    if (chart.data && chart.data.length > 0) {
      const isHorizontal = chart.type === 'horizontalBar' || chart.type === 'ranking';
      
      // 动态生成颜色
      let chartColors;
      if (chart.type === 'ranking') {
        chartColors = chart.data.map((_, i) => {
          if (i === 0) return COLORS.green;
          if (i < 3) return COLORS.blue;
          return COLORS.purple;
        });
      } else if (isHorizontal && chart.data.some(d => d.value < 0)) {
        chartColors = chart.data.map(d => d.value < 0 ? COLORS.red : COLORS.green);
      } else {
        chartColors = CHART_COLORS.slice(0, chart.data.length);
      }
      
      // 使用形状绘制柱状图（兼容性最好）
      const chartData = chart.data;
      const maxValue = Math.max(...chartData.map(d => Math.abs(d.value || 0)));
      
      // 背景区域边界（与上面 addShape 保持一致）
      const bgX = 0.8;
      const bgY = 1.0;
      const bgWidth = 8.4;
      const bgHeight = 4.0;
      const padding = 0.3; // 内边距
      
      if (isHorizontal) {
        // 横向条形图 - 根据背景高度动态计算
        const availableHeight = bgHeight - padding * 2;
        const dataCount = Math.min(chartData.length, 10); // 最多10条
        const barGap = Math.max(0.08, availableHeight / dataCount * 0.2); // 间距至少0.08
        const barHeight = Math.max(0.2, (availableHeight - barGap * (dataCount - 1)) / dataCount);
        
        // 标签和条形的区域分配
        const labelWidth = 1.3;
        const maxBarWidth = bgWidth - labelWidth - padding * 2 - 0.8; // 留出数值空间
        const startX = bgX + labelWidth + padding;
        const startY = bgY + padding;
        
        chartData.slice(0, 10).forEach((item, i) => {
          const y = startY + i * (barHeight + barGap);
          const barWidth = Math.min(maxBarWidth, Math.max(0.3, Math.abs(item.value || 0) / maxValue * maxBarWidth));
          const barColor = chartColors[i] || COLORS.purple;
          
          // 标签
          slide.addText(item.name || '', {
            x: bgX + padding, y, w: labelWidth - 0.1, h: barHeight,
            fontSize: Math.min(12, Math.max(9, 12 - dataCount * 0.3)), color: COLORS.textWhite, align: 'right', fontFace: FONT, valign: 'middle'
          });
          
          // 条形
          slide.addShape('roundRect', {
            x: startX, y, w: barWidth, h: barHeight,
            fill: { color: barColor },
            line: { width: 0 }
          });
          
          // 数值
          const valueText = maxValue <= 100 ? `${item.value}%` : item.value >= 1000 ? `${(item.value / 1000).toFixed(0)}k` : String(item.value);
          slide.addText(valueText, {
            x: startX + barWidth + 0.08, y, w: 0.8, h: barHeight,
            fontSize: Math.min(11, Math.max(8, 11 - dataCount * 0.2)), color: COLORS.green, align: 'left', fontFace: FONT, valign: 'middle'
          });
        });
      } else {
        // 纵向柱状图 - 根据背景宽度和数据量动态计算
        const availableWidth = bgWidth - padding * 2;
        const availableHeight = bgHeight - padding * 2 - 0.5; // 底部留空间给标签
        const dataCount = Math.min(chartData.length, 8); // 最多8条
        
        // 动态计算柱子宽度和间距
        const totalBarRatio = 0.65; // 柱子占总宽度的比例
        const totalGapRatio = 0.35; // 间距占总宽度的比例
        const barWidth = Math.max(0.4, (availableWidth * totalBarRatio) / dataCount);
        const barGap = Math.max(0.15, (availableWidth * totalGapRatio) / (dataCount + 1));
        
        // 起始位置（居中）
        const totalBarsWidth = dataCount * barWidth + (dataCount - 1) * barGap;
        const startX = bgX + padding + (availableWidth - totalBarsWidth) / 2;
        const chartAreaY = bgY + padding;
        
        chartData.slice(0, 8).forEach((item, i) => {
          const x = startX + i * (barWidth + barGap);
          const barHeight = Math.max(0.1, (Math.abs(item.value || 0) / maxValue) * availableHeight);
          const y = chartAreaY + availableHeight - barHeight;
          const barColor = chartColors[i] || COLORS.purple;
          
          // 柱状条
          slide.addShape('roundRect', {
            x, y, w: barWidth, h: barHeight,
            fill: { color: barColor },
            line: { width: 0 }
          });
          
          // 数值（在柱状条上方）
          const valueText = maxValue <= 100 ? `${item.value}%` : item.value >= 10000 ? `${(item.value / 10000).toFixed(1)}万` : item.value >= 1000 ? `${(item.value / 1000).toFixed(0)}k` : String(item.value);
          slide.addText(valueText, {
            x, y: y - 0.28, w: barWidth, h: 0.25,
            fontSize: Math.min(10, Math.max(8, 10 - dataCount * 0.5)), bold: true, color: COLORS.green, align: 'center', fontFace: FONT
          });
          
          // 标签（在柱状条下方）
          slide.addText(item.name || '', {
            x, y: chartAreaY + availableHeight + 0.05, w: barWidth, h: 0.35,
            fontSize: Math.min(11, Math.max(8, 11 - dataCount * 0.4)), color: COLORS.textWhite, align: 'center', fontFace: FONT
          });
        });
      }
    }
    
    chartSlides.push(slide);
  });
  
  return chartSlides.length;
}

// ============ 第8页：数据明细表 ============
function createTableSlide(pptx, data) {
  const slide = pptx.addSlide();
  slide.background = { color: COLORS.darkBg2 };

  const tableData = data.tableData || { title: '数据明细', rows: [] };

  slide.addText('📋 ' + (tableData.title || '数据明细表'), {
    x: 0, y: 0.3, w: 10, h: 0.5,
    fontSize: 26, bold: true, color: COLORS.textWhite, align: 'center', fontFace: FONT
  });

  // 表格区域背景
  slide.addShape('roundRect', {
    x: 0.6, y: 0.9, w: 8.8, h: 4.2,
    fill: { color: '1E293B' },
    line: { width: 0 }
  });

  const rows = tableData.rows || [];
  const columns = tableData.columns || ['要素名称', '类型', '数值', '贡献', '贡献率'];

  if (rows.length === 0) return;

  // 构建表格数据
  const tableRows = [
    // 表头
    columns.map(col => ({
      text: typeof col === 'string' ? col : col.label,
      options: { bold: true, color: COLORS.textWhite, fontFace: FONT, fill: { color: COLORS.purple, transparency: 40 } }
    })),
    // 数据行
    ...rows.slice(0, 8).map(row => {
      if (Array.isArray(row)) {
        return row.map((cell, i) => {
          const isNegative = typeof cell === 'string' && cell.startsWith('-');
          return {
            text: String(cell),
            options: { 
              color: isNegative ? COLORS.red : (i >= 3 ? COLORS.green : COLORS.textGray), 
              fontFace: FONT 
            }
          };
        });
      }
      return columns.map(col => {
        const key = typeof col === 'string' ? col : col.key;
        const value = row[key] || '';
        const isNegative = typeof value === 'string' && value.startsWith('-');
        return {
          text: String(value),
          options: { 
            color: isNegative ? COLORS.red : COLORS.textGray, 
            fontFace: FONT 
          }
        };
      });
    })
  ];

  slide.addTable(tableRows, {
    x: 0.8, y: 1.1, w: 8.4, h: 3.8,
    fontFace: FONT,
    fontSize: 11,
    color: COLORS.textGray,
    align: 'center',
    valign: 'middle',
    border: { type: 'solid', pt: 0.5, color: '334155' },
    fill: { color: '1E293B' },
    colW: [1.8, 1.0, 1.8, 1.8, 1.0]
  });
}

// ============ 第9页：关键洞察（四卡片）============
function createInsightSlide(pptx, data) {
  const slide = pptx.addSlide();
  slide.background = { color: COLORS.darkBg3 };

  slide.addText('💡 关键洞察', {
    x: 0, y: 0.3, w: 10, h: 0.6,
    fontSize: 28, bold: true, color: COLORS.textWhite, align: 'center', fontFace: FONT
  });

  const insights = data.insights || [
    { title: '发现一', content: '这是关键发现内容。', warning: false },
    { title: '发现二', content: '这是另一个发现。', warning: false },
    { title: '发现三', content: '这是第三个发现。', warning: false },
    { title: '⚠️ 风险提示', content: '这是风险提示内容。', warning: true }
  ];

  insights.forEach((item, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = 0.6 + col * 4.6;
    const y = 1.1 + row * 1.9;
    // 恢复最初的颜色搭配：普通紫色，警告橙色
    const borderColor = item.warning ? COLORS.orange : COLORS.purple;
    const titleColor = item.warning ? COLORS.orange : COLORS.purple;

    // 卡片背景（直角）- 参考行动建议的风格，使用紫色/橙色透明背景
    slide.addShape('rect', {
      x, y, w: 4.2, h: 1.6,
      fill: { color: borderColor, transparency: 80 },
      line: { width: 0 }
    });

    // 左边框（更亮的同色边框）
    slide.addShape('rect', {
      x, y, w: 0.1, h: 1.6,
      fill: { color: borderColor },
      line: { width: 0 }
    });

    // 标题
    slide.addText(item.title || '', {
      x: x + 0.2, y: y + 0.15, w: 3.8, h: 0.4,
      fontSize: 16, bold: true, color: titleColor, fontFace: FONT
    });

    // 内容
    slide.addText(item.content || '', {
      x: x + 0.2, y: y + 0.6, w: 3.8, h: 0.8,
      fontSize: 12, color: COLORS.textGray, fontFace: FONT, valign: 'top'
    });
  });
}

// ============ 第10页：行动建议（四卡片）============
function createRecommendationSlide(pptx, data) {
  const slide = pptx.addSlide();
  slide.background = { color: COLORS.darkBg };

  slide.addText('📝 行动建议', {
    x: 0, y: 0.3, w: 10, h: 0.6,
    fontSize: 28, bold: true, color: COLORS.textWhite, align: 'center', fontFace: FONT
  });

  const recommendations = data.recommendations || [
    { title: '建议一', content: '这是第一条建议。' },
    { title: '建议二', content: '这是第二条建议。' },
    { title: '建议三', content: '这是第三条建议。' },
    { title: '建议四', content: '这是第四条建议。' }
  ];

  recommendations.forEach((item, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = 0.6 + col * 4.6;
    const y = 1.1 + row * 1.9;

    // 卡片背景（直角，绿色调）
    slide.addShape('rect', {
      x, y, w: 4.2, h: 1.6,
      fill: { color: COLORS.green, transparency: 80 },
      line: { width: 0 }
    });

    // 左边框（绿色）
    slide.addShape('rect', {
      x, y, w: 0.08, h: 1.6,
      fill: { color: COLORS.green },
      line: { width: 0 }
    });

    // 标题
    slide.addText(item.title || '', {
      x: x + 0.2, y: y + 0.15, w: 3.8, h: 0.4,
      fontSize: 16, bold: true, color: COLORS.green, fontFace: FONT
    });

    // 内容
    slide.addText(item.content || '', {
      x: x + 0.2, y: y + 0.6, w: 3.8, h: 0.8,
      fontSize: 12, color: COLORS.textGray, fontFace: FONT, valign: 'top'
    });
  });
}

// ============ 第11页：结尾页（紫色渐变）============
function createEndingSlide(pptx, data) {
  const slide = pptx.addSlide();
  slide.background = { color: COLORS.purple };

  slide.addText('谢谢观看', {
    x: 0, y: 1.6, w: 10, h: 0.9,
    fontSize: 56, bold: true, color: COLORS.textWhite, align: 'center', fontFace: FONT
  });

  slide.addText(data.title || '数据分析报告', {
    x: 0, y: 2.5, w: 10, h: 0.5,
    fontSize: 20, color: COLORS.textGray, align: 'center', fontFace: FONT
  });

  slide.addText(data.source || 'BytePlan 数据平台', {
    x: 0, y: 3.0, w: 10, h: 0.4,
    fontSize: 16, color: COLORS.textMuted, align: 'center', fontFace: FONT
  });

  // 来源信息卡片
  slide.addShape('roundRect', {
    x: 3, y: 3.8, w: 4, h: 0.8,
    fill: { color: COLORS.textWhite, transparency: 85 },
    line: { width: 0 }
  });

  slide.addText(`数据来源：${data.source || 'BytePlan 数据平台'}\n分析时间：${data.period || new Date().toLocaleDateString('zh-CN')}`, {
    x: 3, y: 3.9, w: 4, h: 0.6,
    fontSize: 11, color: COLORS.textWhite, align: 'center', fontFace: FONT
  });
}

// ============ 主函数 ============
function generatePpt(outputFile, dataFile = null) {
  // 加载数据
  let data = {};

  if (dataFile) {
    const filePath = path.resolve(dataFile);
    if (fs.existsSync(filePath)) {
      data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    }
  } else {
    const defaultPath = path.resolve('ppt_data.json');
    if (fs.existsSync(defaultPath)) {
      data = JSON.parse(fs.readFileSync(defaultPath, 'utf-8'));
    }
  }

  // 创建演示文稿 (16:9)
  const pptx = new PptxGenJS();
  pptx.defineLayout({ name: 'WIDESCREEN', width: 10, height: 5.625 });
  pptx.layout = 'WIDESCREEN';
  pptx.author = 'BytePlan';
  pptx.company = 'BytePlan 数据平台';

  // 生成幻灯片
  createCoverSlide(pptx, data);           // 1. 封面
  createTocSlide(pptx, data);             // 2. 目录
  createSummarySlide(pptx, data);         // 3. 核心发现
  createKpiSlide(pptx, data);             // 4. KPI
  const chartCount = createChartSlides(pptx, data);  // 5-N. 图表（动态数量）
  createTableSlide(pptx, data);           // N+1. 数据表
  createInsightSlide(pptx, data);         // N+2. 关键洞察
  createRecommendationSlide(pptx, data);  // N+3. 行动建议
  createEndingSlide(pptx, data);          // N+4. 结尾页

  // 保存
  pptx.writeFile({ fileName: outputFile });
  
  const totalSlides = 11 + (chartCount > 3 ? chartCount - 3 : 0);
  return `Successfully generated PPT with ${totalSlides} slides -> ${outputFile}`;
}

// CLI 入口
const args = process.argv.slice(2);
let outputFile = 'analysis-report.pptx';
let dataFile = null;

for (let i = 0; i < args.length; i++) {
  if (args[i] === '-o' || args[i] === '--output-file') {
    outputFile = args[++i];
  } else if (args[i] === '-d' || args[i] === '--data-file') {
    dataFile = args[++i];
  }
}

console.log(generatePpt(outputFile, dataFile));