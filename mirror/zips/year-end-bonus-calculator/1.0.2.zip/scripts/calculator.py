#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
年终奖最优发放计算器 - 核心计算逻辑
"""

# 工资薪金综合所得税率表（应纳税所得额 = 工资 - 60000 - 税前扣除）
SALARY_BRACKETS = [
    (36000, 0.03, 0),
    (144000, 0.10, 2520),
    (300000, 0.20, 16920),
    (420000, 0.25, 31920),
    (660000, 0.30, 52920),
    (960000, 0.35, 85920),
    (float('inf'), 0.45, 181920),
]

# 年终奖单独计税表（月度换算：全额除以12找税率档次）
BONUS_BRACKETS = [
    (3000, 0.03, 0),
    (12000, 0.10, 210),
    (25000, 0.20, 1410),
    (35000, 0.25, 2660),
    (55000, 0.30, 4410),
    (80000, 0.35, 7160),
    (float('inf'), 0.45, 7160),
]


def calc_salary_tax(taxable):
    """
    计算工资薪金个税（综合所得）
    :param taxable: 应纳税所得额（已减60000和税前扣除）
    :return: 个税金额
    """
    if taxable <= 0:
        return 0
    for limit, rate, deduction in SALARY_BRACKETS:
        if taxable <= limit:
            return taxable * rate - deduction
    return taxable * 0.45 - 181920


def calc_bonus_tax(amount):
    """
    计算年终奖个税（单独计税优惠）
    规则：年终奖÷12找税率档，然后用该税率×年终奖-对应速算扣除数
    :param amount: 年终奖总额
    :return: 个税金额
    """
    if amount <= 0:
        return 0
    monthly = amount / 12
    for limit, rate, deduction in BONUS_BRACKETS:
        if monthly <= limit:
            return amount * rate - deduction
    return amount * 0.45 - 7160


def find_optimal_bonus(annual_income, other_deductions, max_bonus=None, step=1000):
    """
    寻找最优年终奖发放方案
    :param annual_income: 年度总收入
    :param other_deductions: 三险一金 + 专项附加扣除 + 其他扣除
    :param max_bonus: 最大年终奖金额（默认等于年收入）
    :param step: 遍历步长
    :return: 最优方案字典
    """
    BASE_DEDUCTION = 60000
    
    if max_bonus is None:
        max_bonus = annual_income
    
    # 总的应纳税所得额
    total_taxable = annual_income - BASE_DEDUCTION - other_deductions
    
    if total_taxable <= 0:
        return {
            'bonus': 0,
            'salary': annual_income,
            'salary_tax': 0,
            'bonus_tax': 0,
            'total_tax': 0,
            'after_tax': annual_income,
            'effective_rate': 0,
            'scenarios': []
        }
    
    best = None
    scenarios = []
    
    # 遍历各种分配方案
    for bonus in range(0, int(min(max_bonus, annual_income)) + 1, step):
        salary = annual_income - bonus
        salary_taxable = salary - BASE_DEDUCTION - other_deductions
        
        salary_tax = calc_salary_tax(salary_taxable)
        bonus_tax = calc_bonus_tax(bonus)
        total_tax = salary_tax + bonus_tax
        after_tax = annual_income - total_tax
        
        scenario = {
            'bonus': bonus,
            'salary': salary,
            'salary_tax': salary_tax,
            'bonus_tax': bonus_tax,
            'total_tax': total_tax,
            'after_tax': after_tax,
            'effective_rate': total_tax / annual_income if annual_income > 0 else 0
        }
        scenarios.append(scenario)
        
        if best is None or after_tax > best['after_tax']:
            best = scenario.copy()
    
    # 精简返回的场景（只保留关键节点）
    key_scenarios = _filter_key_scenarios(scenarios)
    
    return {
        'bonus': best['bonus'],
        'salary': best['salary'],
        'salary_tax': best['salary_tax'],
        'bonus_tax': best['bonus_tax'],
        'total_tax': best['total_tax'],
        'after_tax': best['after_tax'],
        'effective_rate': best['effective_rate'],
        'scenarios': key_scenarios
    }


def _filter_key_scenarios(scenarios):
    """过滤关键场景（最优解附近和税率临界点）"""
    if not scenarios:
        return []
    
    # 年终奖税率临界点（年度金额）
    critical_points = [36000, 144000, 300000, 420000, 660000, 960000]
    
    result = []
    added_bonuses = set()
    
    # 添加最优解
    best = max(scenarios, key=lambda x: x['after_tax'])
    result.append(best)
    added_bonuses.add(best['bonus'])
    
    # 添加临界点附近的方案
    for point in critical_points:
        for s in scenarios:
            if abs(s['bonus'] - point) <= 1000 and s['bonus'] not in added_bonuses:
                result.append(s)
                added_bonuses.add(s['bonus'])
                break
    
    # 按年终奖金额排序
    result.sort(key=lambda x: x['bonus'])
    return result


def format_money(amount):
    """格式化金额显示"""
    return f"¥{amount:,.0f}"


def format_pct(rate):
    """格式化百分比显示"""
    return f"{rate*100:.1f}%"


def generate_report(annual_income, other_deductions, result):
    """生成计算报告"""
    lines = []
    lines.append("=" * 50)
    lines.append("年终奖最优发放方案")
    lines.append("=" * 50)
    lines.append("")
    lines.append(f"📊 输入信息：")
    lines.append(f"   年度总收入：{format_money(annual_income)}")
    lines.append(f"   税前扣除：{format_money(other_deductions)}")
    lines.append("")
    lines.append(f"💰 最优方案：")
    lines.append(f"   年终奖：{format_money(result['bonus'])} ({format_pct(result['bonus']/annual_income)})")
    lines.append(f"   工资薪金：{format_money(result['salary'])}")
    lines.append("")
    lines.append(f"📈 税负情况：")
    lines.append(f"   工资个税：{format_money(result['salary_tax'])}")
    lines.append(f"   年终奖个税：{format_money(result['bonus_tax'])}")
    lines.append(f"   个税合计：{format_money(result['total_tax'])}")
    lines.append(f"   实际税率：{format_pct(result['effective_rate'])}")
    lines.append(f"   税后收入：{format_money(result['after_tax'])}")
    lines.append("")
    
    if result['scenarios']:
        lines.append("📋 关键方案对比：")
        lines.append("-" * 80)
        lines.append(f"{'年终奖':>12} {'工资':>12} {'奖金税':>10} {'工资税':>10} {'总税负':>10} {'税后收入':>12}")
        lines.append("-" * 80)
        for s in result['scenarios'][:5]:
            lines.append(f"{format_money(s['bonus']):>12} {format_money(s['salary']):>12} "
                        f"{format_money(s['bonus_tax']):>10} {format_money(s['salary_tax']):>10} "
                        f"{format_money(s['total_tax']):>10} {format_money(s['after_tax']):>12}")
    
    lines.append("")
    lines.append("💡 关键提示：")
    lines.append("   年终奖落在 3.6万、14.4万、24万 这几个节点之下时税率最优")
    lines.append("   年终奖单独计税优惠延续至2027年12月31日")
    
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    
    # 测试
    result = find_optimal_bonus(500000, 50000)
    print(generate_report(500000, 50000, result))
