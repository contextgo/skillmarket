"""
从 getdesign.md 批量同步 DESIGN.md 文件到 references/ 目录。

用法:
    python sync_designs.py              # 同步所有设计系统
    python sync_designs.py claude figma # 同步指定设计系统
"""

import os
import sys
import urllib.request
import urllib.error

BASE_URL = "https://getdesign.md/{name}/design-md"
REFERENCES_DIR = os.path.join(os.path.dirname(__file__), "..", "references")
DESIGNS = [
    "airbnb", "airtable", "apple", "bmw", "cal", "claude", "clay", "clickhouse",
    "cohere", "coinbase", "composio", "cursor", "elevenlabs", "expo", "ferrari",
    "figma", "framer", "hashicorp", "ibm", "intercom", "kraken", "lamborghini",
    "linear.app", "lovable", "minimax", "mintlify", "miro", "mistral.ai",
    "mongodb", "notion", "nvidia", "ollama", "opencode.ai", "pinterest", "posthog",
    "raycast", "renault", "replicate", "resend", "revolut", "runwayml", "sanity",
    "semrush", "sentry", "spacex", "spotify", "stripe", "supabase", "superhuman",
    "tesla", "together.ai", "uber", "vercel", "voltagent", "warp", "webflow",
    "wise", "x.ai", "zapier", "theverge", "nike", "shopify",
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; QClaw/1.0)",
    "Accept": "text/markdown,text/plain,*/*",
}


def fetch(name: str) -> tuple[bool, str]:
    url = BASE_URL.format(name=name)
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return True, resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code}"
    except Exception as e:
        return False, str(e)


def sync(targets: list[str] | None = None):
    if targets:
        names = [t.lower().strip().replace(" ", ".") for t in targets]
    else:
        names = DESIGNS

    os.makedirs(REFERENCES_DIR, exist_ok=True)
    ok, fail = 0, 0

    for name in names:
        if name.endswith(".md"):
            name = name[:-3]

        out_path = os.path.join(REFERENCES_DIR, f"{name}.md")
        if os.path.exists(out_path):
            print(f"  [skip] {name} (already exists)")
            ok += 1
            continue

        success, content = fetch(name)
        if success:
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(content)
            print(f"  [save] {name}")
            ok += 1
        else:
            print(f"  [fail] {name}: {content}")
            fail += 1

    print(f"\nDone: {ok} saved, {fail} failed")


if __name__ == "__main__":
    sync(sys.argv[1:] if len(sys.argv) > 1 else None)
