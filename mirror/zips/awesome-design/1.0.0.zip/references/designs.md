# 62 Design Systems — VoltAgent/awesome-design-md

Source: https://github.com/VoltAgent/awesome-design-md
Live files: https://getdesign.md/{name}/design-md

## 完整列表

| # | 名称 | getdesign.md URL |
|---|------|-----------------|
| 1 | airbnb | https://getdesign.md/airbnb/design-md |
| 2 | airtable | https://getdesign.md/airtable/design-md |
| 3 | apple | https://getdesign.md/apple/design-md |
| 4 | bmw | https://getdesign.md/bmw/design-md |
| 5 | cal | https://getdesign.md/cal/design-md |
| 6 | claude | https://getdesign.md/claude/design-md |
| 7 | clay | https://getdesign.md/clay/design-md |
| 8 | clickhouse | https://getdesign.md/clickhouse/design-md |
| 9 | cohere | https://getdesign.md/cohere/design-md |
| 10 | coinbase | https://getdesign.md/coinbase/design-md |
| 11 | composio | https://getdesign.md/composio/design-md |
| 12 | cursor | https://getdesign.md/cursor/design-md |
| 13 | elevenlabs | https://getdesign.md/elevenlabs/design-md |
| 14 | expo | https://getdesign.md/expo/design-md |
| 15 | ferrari | https://getdesign.md/ferrari/design-md |
| 16 | figma | https://getdesign.md/figma/design-md |
| 17 | framer | https://getdesign.md/framer/design-md |
| 18 | hashicorp | https://getdesign.md/hashicorp/design-md |
| 19 | ibm | https://getdesign.md/ibm/design-md |
| 20 | intercom | https://getdesign.md/intercom/design-md |
| 21 | kraken | https://getdesign.md/kraken/design-md |
| 22 | lamborghini | https://getdesign.md/lamborghini/design-md |
| 23 | linear.app | https://getdesign.md/linear.app/design-md |
| 24 | lovable | https://getdesign.md/lovable/design-md |
| 25 | minimax | https://getdesign.md/minimax/design-md |
| 26 | mintlify | https://getdesign.md/mintlify/design-md |
| 27 | miro | https://getdesign.md/miro/design-md |
| 28 | mistral.ai | https://getdesign.md/mistral.ai/design-md |
| 29 | mongodb | https://getdesign.md/mongodb/design-md |
| 30 | notion | https://getdesign.md/notion/design-md |
| 31 | nvidia | https://getdesign.md/nvidia/design-md |
| 32 | ollama | https://getdesign.md/ollama/design-md |
| 33 | opencode.ai | https://getdesign.md/opencode.ai/design-md |
| 34 | pinterest | https://getdesign.md/pinterest/design-md |
| 35 | posthog | https://getdesign.md/posthog/design-md |
| 36 | raycast | https://getdesign.md/raycast/design-md |
| 37 | renault | https://getdesign.md/renault/design-md |
| 38 | replicate | https://getdesign.md/replicate/design-md |
| 39 | resend | https://getdesign.md/resend/design-md |
| 40 | revolut | https://getdesign.md/revolut/design-md |
| 41 | runwayml | https://getdesign.md/runwayml/design-md |
| 42 | sanity | https://getdesign.md/sanity/design-md |
| 43 | semrush | https://getdesign.md/semrush/design-md |
| 44 | sentry | https://getdesign.md/sentry/design-md |
| 45 | spacex | https://getdesign.md/spacex/design-md |
| 46 | spotify | https://getdesign.md/spotify/design-md |
| 47 | stripe | https://getdesign.md/stripe/design-md |
| 48 | supabase | https://getdesign.md/supabase/design-md |
| 49 | superhuman | https://getdesign.md/superhuman/design-md |
| 50 | tesla | https://getdesign.md/tesla/design-md |
| 51 | together.ai | https://getdesign.md/together.ai/design-md |
| 52 | uber | https://getdesign.md/uber/design-md |
| 53 | vercel | https://getdesign.md/vercel/design-md |
| 54 | voltagent | https://getdesign.md/voltagent/design-md |
| 55 | warp | https://getdesign.md/warp/design-md |
| 56 | webflow | https://getdesign.md/webflow/design-md |
| 57 | wise | https://getdesign.md/wise/design-md |
| 58 | x.ai | https://getdesign.md/x.ai/design-md |
| 59 | zapier | https://getdesign.md/zapier/design-md |
| 60 | theverge | https://getdesign.md/theverge/design-md |
| 61 | nike | https://getdesign.md/nike/design-md |
| 62 | shopify | https://getdesign.md/shopify/design-md |

## 使用说明

需要某个设计系统时，直接告诉 AI，例如：
> "我要 Figma 的设计系统" / "给我 Claude 风格的设计"

AI 会从 `https://getdesign.md/<name>/design-md` 获取对应的 DESIGN.md 内容。
