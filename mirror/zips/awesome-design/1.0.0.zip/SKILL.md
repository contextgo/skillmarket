---
name: awesome-design-md
description: VoltAgent awesome-design-md — 62个网站设计系统文档（DESIGN.md）合集，支持按名获取任意网站的设计风格参考。当用户提到"设计系统"、"DESIGN.md"、"参考XX的设计风格"、"我要做XX风格的UI"、"给我一个设计系统"、"复制某网站的设计"等意图时触发。
---

# awesome-design-md

VoltAgent 出品的 DESIGN.md 合集，收集了 62 个知名网站的设计系统文档。

## 设计系统列表

完整列表见 [references/designs.md](references/designs.md)，可按需加载。

## 使用方式

### 获取指定网站的设计

直接告诉我想要哪个网站的设计风格，例如：

- "给我 Claude 的设计系统"
- "我要 Figma 风格的设计"
- "把 Spotify 的设计风格应用到项目"

我会在 `~/.qclaw/skills/awesome-design-md/references/` 下查找对应文件，如不存在则从 getdesign.md 抓取。

### 从仓库批量同步

DESIGN.md 文件来自 `https://github.com/VoltAgent/awesome-design-md`，原始文件托管在 `https://getdesign.md/<name>/design-md`。

如需批量同步，运行：

```powershell
python ~/.qclaw/skills/awesome-design-md/scripts/sync_designs.py
```

### 文件格式说明

每个 DESIGN.md 包含：
1. Visual Theme & Atmosphere
2. Color Palette & Roles
3. Typography Rules
4. Component Stylings
5. Layout Principles
6. Depth & Elevation
7. Do's and Don'ts
8. Responsive Behavior
9. Agent Prompt Guide

## 常用设计系统快捷列表

| 分类 | 网站 |
|------|------|
| AI 工具 | Claude, xAI, Cursor, ElevenLabs, Ollama, Minimax, Mistral AI, Cohere, Replicate, RunwayML, Together AI, OpenCode AI, VoltaAgent |
| 前端/部署 | Vercel, Supabase, Cloudflare, Expo, Warp, Raycast |
| 设计工具 | Figma, Framer, Miro, Webflow |
| 金融支付 | Stripe, Coinbase, Binance, Kraken, Revolut, Wise |
| 电商 | Shopify, Airbnb, Nike |
| 消费科技 | Apple, NVIDIA, IBM, Meta, Tesla, SpaceX |
| 效率工具 | Notion, Linear, Superhuman, Raycast, PostHog, Sentry, Intercom, Cal.com, Mintlify |
| 媒体 | The Verge, WIRED, Spotify, Pinterest, Uber |
| 汽车 | BMW, Ferrari, Lamborghini, Renault |
