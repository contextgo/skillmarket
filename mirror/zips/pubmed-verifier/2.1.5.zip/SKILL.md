---
name: pubmed-verifier
description: PubMed文献引用批量验证：不只查PMID是否存在，还能判断它是否指向正确的论文。五态判定系统，自动解析引用上下文并交叉比对，不匹配时推荐正确PMID。零依赖，纯本地运行。
  Keywords: PMID验证, PubMed引用核查, 文献审计, AI幻觉检测, 学术写作, 医学文献,
  批量验证, 引用核对, 论文引用检查, reference validation, citation audit,
  PubMed API, systematic review QA, academic integrity, pharmacovigilance.
  Triggers: "验证PMID", "检查引用", "核查文献", "PMID检查", "引用验证",
  "verify PMIDs", "check citations", "validate references", "audit PMID",
  "文献验证", "引用核对", "batch verify references", "检查引用", "验证文献".
---

# PubMed文献引用批量验证工具 v2.1.5

检测AI编造的虚假文献引用。不只检查PMID是否存在——还能判断PMID是否指向正确的论文。零依赖，纯本地运行。

## 五态判定系统

| 判定 | 含义 |
|------|------|
| ✅ 正确 | PMID存在，且与引用的论文匹配（标题+作者/期刊） |
| ⚠️ 不匹配 | PMID存在，但指向**不同的**论文（AI幻觉最常见的情况！） |
| 🔶 部分匹配 | 部分元数据匹配（如作者+期刊匹配但标题不同） |
| ❌ 无效 | PubMed中不存在此PMID |
| ❓ 待确认 | 缺少足够的引用元数据，无法交叉比对 |

## 快速开始

```bash
# 扫描项目目录中所有PMID（自动解析引用上下文）
python3 scripts/verify_pmids.py --source /path/to/project --output report.html

# 验证指定PMID
python3 verify_pmids.py --pmids 31018962,22213727

# 带引用信息验证（JSON格式）
python3 verify_pmids.py --claims '[{"pmid":"34078778","title":"JIA pathogenesis","authors":["Zaripova"],"journal":"Pediatr Rheumatol Online J","year":"2021"}]' --output report.html

# 带引用信息验证（CSV文件）
python3 verify_pmids.py --claims-file claims.csv --suggest --output report.html

# 启用DOI交叉验证
python3 verify_pmids.py --source /path/to/files --verify-doi --output report.html

# 完整流程
python3 verify_pmids.py --source /path/to/files --verify-doi --suggest --output report.html
```

## v2.1.4 新功能

| 功能 | 说明 |
|------|------|
| **SQLite缓存** | 已验证PMID缓存在 `~/.cache/pubmed-verifier/cache.db`，默认30天有效期。重复验证秒级完成。 |
| **CSV支持** | `--claims-file` 支持CSV格式（自动检测JSON/CSV），支持分号或竖线分隔的作者列表。 |
| **Crossref DOI验证** | `--verify-doi` 通过Crossref API交叉验证DOI，提供额外置信度。 |
| **自动重试** | API临时故障自动重试3次，指数退避（1s→2s→4s）。零外部依赖。 |
| **双重模糊匹配** | 标题匹配使用词级Jaccard重叠（≥50%）+ SequenceMatcher（≥90%）补充。 |

## 工作原理

### 1. 提取PMID + 解析引用上下文

扫描文件中的PMID模式（`PMID: 12345678`、PubMed URL等），**自动解析周围引用文本**提取声称的元数据：
- 作者姓名
- 论文标题
- 期刊名称
- 发表年份

支持格式：`.html`、`.md`、`.txt`、`.json`、`.htm`

### 2. 获取PubMed元数据（带缓存）

通过PubMed `esummary` API查询，结果缓存到SQLite（30天，可通过 `--cache-days` 调整）。批量请求（每次50条，间隔0.4秒，3次重试）。

### 3. 交叉比对：声称 vs 实际

双重模糊匹配策略：
- **主要**：词级Jaccard重叠 ≥ 50%（处理词序变化、缩写展开）
- **补充**：SequenceMatcher ≥ 90%（捕获边界情况）

| 字段 | 匹配逻辑 |
|------|---------|
| **标题** | 词重叠 ≥ 50% 或 SequenceMatcher ≥ 90% |
| **作者** | 单作者声称 ≥1 姓氏命中；多作者 ≥2 |
| **期刊** | 包含匹配（处理缩写） |
| **年份** | 精确匹配 |

### 4. Crossref DOI验证（可选，`--verify-doi`）

对有DOI的文章，通过Crossref API独立交叉验证标题/期刊/年份。

### 5. 自动推荐（可选，`--suggest`）

对不匹配的引用，使用声称元数据搜索PubMed，推荐正确PMID（前3个候选）。

### 6. 报告输出

| 格式 | 参数 | 用途 |
|------|------|------|
| HTML | `--output report.html` | 可视化审查，含声称vs实际对比、判定列 |
| JSON | `--output report.json` | 程序化处理 |
| 文本 | 默认（无 `--output`） | 终端快速查看 |

## 命令行参数

```
python3 scripts/verify_pmids.py [选项]

选项：
  --source PATH        扫描文件或目录
  --pmids P1,P2,...    逗号分隔的PMID列表
  --claims JSON        JSON格式的引用元数据
  --claims-file FILE   JSON或CSV格式的引用元数据文件
  --verify-doi         启用Crossref DOI验证
  --suggest            自动推荐正确PMID
  --match-keywords     检查主题相关性（辅助功能）
  --threshold FLOAT    关键词匹配阈值（默认：0.2）
  --no-cache           禁用缓存，强制重新查询
  --cache-days N       缓存有效天数（默认：30）
  --output FILE        输出文件（.json 或 .html）
  --format FORMAT      输出格式：json|html|text（默认：text）
```

## 性能

| 场景 | 首次运行 | 缓存运行 |
|------|---------|---------|
| 225条PMID（MedWiki-Rheum） | ~7分钟 | ~5秒 |
| 单条PMID | ~2秒 | ~1.4秒 |

## 适用场景

- 系统性综述/荟萃分析文献验证
- AI生成内容的文献真实性审核
- 论文投稿前引用自检
- 医学知识库/教材引用质量控制
- 药物警戒文献核查

## 文件说明

| 文件 | 用途 |
|------|------|
| `scripts/verify_pmids.py` | 主验证脚本（v2.1.4，1058行，零外部依赖） |
| `references/api_examples.md` | PubMed E-utilities API示例 |

## 许可证

MIT-0 — 自由使用、修改和分发，无需署名。
