---
name: api-designer
description: RESTful/RPC API 设计助手。根据业务需求生成符合团队规范的接口设计文档，包括路由规划、请求/响应结构、错误码体系、版本策略，并自动检查设计合理性。
---

# API Designer — 接口设计助手

## 使用方式

```
@api-designer
```

提供需求描述，AI 将生成完整的接口设计文档。

## 设计原则

### RESTful 规范
- 资源用名词复数，动作用 HTTP Method 表达
- GET 幂等，POST 新增，PUT 全量更新，PATCH 部分更新，DELETE 删除
- 路径层级不超过 3 层：`/api/v1/{resource}/{id}/{sub-resource}`
- 查询参数用于过滤/排序/分页，路径参数用于资源定位

### 版本策略
- URL 版本化：`/api/v1/`、`/api/v2/`
- 向后兼容原则：新增字段不算 Breaking Change
- 废弃接口至少保留 2 个版本周期

### 通用响应结构

```json
{
  "code": 0,           // 0=成功，非0=业务错误码
  "message": "OK",     // 错误描述（成功时可省略）
  "data": {},          // 业务数据
  "request_id": "xxx"  // 链路追踪 ID
}
```

### 分页规范

```json
// 请求
{
  "page": 1,
  "page_size": 20
}

// 响应
{
  "data": {
    "list": [],
    "total": 100,
    "page": 1,
    "page_size": 20,
    "has_more": true
  }
}
```

## 输出模板

```markdown
# API 设计文档：[模块名]

## 接口总览

| 方法 | 路径 | 描述 | 鉴权 |
|------|------|------|------|
| POST | /api/v1/xxx | 创建xxx | 需要 |

---

## 接口详情

### POST /api/v1/xxx — 创建xxx

**描述：** xxx

**请求头：**
| Header | 必填 | 说明 |
|--------|------|------|
| Authorization | 是 | Bearer Token |

**请求体：**
```json
{
  "field1": "string",  // 必填，说明
  "field2": 0          // 可选，说明
}
```

**响应示例：**
```json
{
  "code": 0,
  "data": {
    "id": "xxx"
  }
}
```

**错误码：**
| code | message | 说明 |
|------|---------|------|
| 40001 | param invalid | 参数校验失败 |
| 50001 | internal error | 内部错误 |
```

## 快捷指令

| 指令 | 说明 |
|------|------|
| `/gen-mock` | 生成 Mock 数据 |
| `/gen-curl` | 生成 curl 调用示例 |
| `/check-design` | 检查接口设计合理性 |
| `/gen-openapi` | 生成 OpenAPI 3.0 YAML |
