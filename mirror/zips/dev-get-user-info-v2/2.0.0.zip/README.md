# 用户信息查询 Skill

[![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)](./SKILL.md)
[![Python](https://img.shields.io/badge/python-3.6+-green.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-yellow.svg)](./LICENSE)

通过 REST API 查询企业内部用户信息，支持 userId、username、mobile 三种查询方式。

**v2.0.0 新增**：密钥链自动 Token 管理，Token 过期自动刷新。

## 特性

- **零配置** - AI 在对话中引导配置，无需手动编辑文件
- **凭证安全** - 账号密码存入系统密钥链，操作系统级加密
- **自动刷新** - Token 过期自动重新登录，无需手动干预
- **多维度查询** - 支持 userId、username、mobile 三种方式
- **多环境支持** - 可配置 dev / test / prod 环境

## 安装

### 依赖安装

```bash
pip install requests keyring
```

### 安装步骤

1. 解压 Skill 包到指定目录
2. 安装依赖
3. 直接使用，AI 会引导首次配置

## 快速开始

### 方式一：AI 引导（推荐）

直接告诉 AI 你想查询的内容：

```
查询用户 ID 为 19857 的用户信息
```

AI 会自动引导完成配置和查询。

### 方式二：命令行配置

```bash
# 首次配置
python scripts/get_user_info.py --setup \
  --username <用户名> \
  --password <密码> \
  --device-id <设备ID> \
  --env prod \
  --api-domain <API域名>

# 查询用户
python scripts/get_user_info.py id 19857
python scripts/get_user_info.py name stu_013
python scripts/get_user_info.py mobile 13800138000
```

### 管理命令

```bash
python scripts/get_user_info.py status   # 查看配置状态
python scripts/get_user_info.py refresh  # 手动刷新 Token
python scripts/get_user_info.py reset    # 清除配置
```

## 配置参数

| 参数 | 必填 | 说明 |
|------|------|------|
| `--username` | 是 | 登录用户名 |
| `--password` | 是 | 登录密码 |
| `--device-id` | 是 | 设备唯一标识 |
| `--env` | 是 | 环境：`dev` / `test` / `prod` |
| `--api-domain` | 是 | 用户查询 API 的域名 |

## 故障排除

### 问题：提示"需要安装 keyring"

**解决**：安装 keyring
```bash
pip install keyring
```

### 问题：Token 过期但无法刷新

**解决**：重新配置
```bash
python scripts/get_user_info.py reset
# 然后重新配置
```

## API 参考

详细接口规范请参阅 [references/api_doc.md](./references/api_doc.md)

## 文件结构

```
get-user-info/
├── SKILL.md                  # Skill 元数据
├── README.md                 # 本文件
├── manifest.json             # SkillHub 元数据
├── assets/
│   └── icon.svg              # 图标
├── scripts/
│   ├── get_user_info.py      # 主脚本
│   └── credential_manager.py # 凭证管理器
└── references/
    └── api_doc.md            # API 接口参考
```

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-04-03 | 初始版本 |
| 1.1.0 | 2026-04-07 | 新增无文件模式 |
| 2.0.0 | 2026-04-09 | 新增密钥链自动 Token 管理 |

## 致谢

- 基于 WorkBuddy Skill 框架开发
- 使用 Python requests 和 keyring 库
