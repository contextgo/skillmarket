# 数据脱敏规范 (Desensitization Rules)

在生成经验总结文档时，**必须**严格遵守以下脱敏规则，确保任何敏感信息都不会被泄露到最终的文档中。

## 1. 凭证与密钥 (Credentials & Secrets)
- **规则**：替换所有密码、API Keys、Tokens、Secret Keys、证书内容。
- **替换格式**：`[REDACTED_SECRET]` 或 `[API_KEY_HIDDEN]`
- **示例**：
  - 原始：`Authorization: Bearer sk-1234567890abcdef`
  - 脱敏：`Authorization: Bearer [REDACTED_TOKEN]`

## 2. 网络与基础设施信息 (Network & Infrastructure)
- **规则**：替换所有内部 IP 地址、内网域名、数据库连接字符串、服务器真实端口。
- **替换格式**：
  - IP：`10.x.x.x` 或 `192.168.x.x`
  - 域名：`internal-service.local` 或 `api.example.com`
  - 数据库：`mysql://user:pass@db-host:3306/dbname` -> `mysql://[USER]:[PASS]@[DB_HOST]:3306/[DB_NAME]`
- **示例**：
  - 原始：`http://10.2.3.4:8080/api/v1/users`
  - 脱敏：`http://[INTERNAL_IP]:[PORT]/api/v1/users`

## 3. 真实业务数据与个人隐私 (PII & Business Data)
- **规则**：替换所有真实的用户姓名、手机号、邮箱、身份证号、订单号、真实金额等。
- **替换格式**：使用占位符如 `[USER_NAME]`, `[PHONE_NUMBER]`, `[ORDER_ID]`，或使用假数据（如张三、test@example.com）。
- **示例**：
  - 原始：`{"name": "李雷", "phone": "13812345678", "order_id": "ORD20231001999"}`
  - 脱敏：`{"name": "[USER_NAME]", "phone": "[PHONE_NUMBER]", "order_id": "[ORDER_ID]"}`

## 4. 公司与项目特定标识 (Company & Project Identifiers)
- **规则**：如果用户要求完全脱敏，需替换公司名称、内部项目代号、特定的业务线名称。
- **替换格式**：`[COMPANY_NAME]`, `[PROJECT_NAME]`
- **示例**：
  - 原始：`在处理 WarpWeft-Nexus 项目的 AI营销 模块时...`
  - 脱敏：`在处理 [PROJECT_NAME] 项目的 [MODULE_NAME] 模块时...`

## 5. 绝对路径与系统用户名 (Paths & Usernames)
- **规则**：替换本地绝对路径中的真实用户名或敏感目录名。
- **替换格式**：`/path/to/project/` 或 `C:\path\to\project\`
- **示例**：
  - 原始：`C:\Users\lingerlin\AppData\Roaming\...`
  - 脱敏：`C:\Users\[USERNAME]\AppData\Roaming\...`

## 执行要求
在输出最终的 Markdown 文档前，请务必进行一次全局审查，确保上述规则被严格执行。宁可过度脱敏，也不要遗漏任何潜在的敏感信息。
