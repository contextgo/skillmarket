---
name: reviewing-final-state-diff
description: Use when the user asks to review a commit range, feature branch, PR branch, or `<start_commit>..HEAD` as the final code state instead of reviewing individual commits.
---

# Reviewing Final State Diff

## Overview

Review the code as it would land after the full range is applied. Ignore transient problems that existed only in earlier commits and were fixed by later commits in the same range.

## Workflow

If the user asks how to invoke this skill, see `references/examples.md` for prompt examples.

1. Confirm the review range.
   - Use the exact range when the user provides one, such as `<start_commit>..HEAD`.
   - If only a branch is provided, determine a merge base against the likely target branch; ask only when the target branch is ambiguous.
   - Note whether the working tree has uncommitted changes, because they are outside a pure commit-range review unless the user includes them.

2. Build the final-state picture before judging.
   - Run `git diff --stat <range>` and `git diff --name-only <range>`.
   - Inspect relevant final files at `HEAD`, not only the patch hunks.
   - Follow call sites, tests, config, migrations, and public contracts touched by the diff.

3. Review for final behavior.
   - Prioritize bugs, regressions, data loss, security issues, compatibility breaks, concurrency risks, resource leaks, and missing high-value tests.
   - Do not flag commit sequencing, temporary breakages, or intermediate implementation choices unless they still affect the final tree.
   - Do not edit code during review unless the user explicitly asks to fix findings.

4. Verify when practical.
   - Run focused tests, compilation, or static checks that correspond to the changed surface.
   - If verification is blocked or too expensive, state exactly what was not run and why.

## Output Format

Lead with findings, ordered by severity.

For each finding include:
- Severity such as `P0`, `P1`, `P2`, or `P3`.
- Final-file path and line reference.
- The observable risk in the final code state.
- A concrete fix direction.

If no blocking findings are found, say that clearly and include any verification limits or residual risks. Keep summaries secondary to findings.

## Command Hints

```bash
git status --short
git diff --stat <start_commit>..HEAD
git diff --name-only <start_commit>..HEAD
git diff <start_commit>..HEAD -- <path>
git diff --check <start_commit>..HEAD
```

For branch-based reviews:

```bash
git merge-base HEAD origin/main
git diff --stat $(git merge-base HEAD origin/main)..HEAD
```

## Common Mistakes

- Reviewing each commit separately when the user asked for final state.
- Reporting issues that were fixed later inside the same range.
- Citing only diff context when the final file or caller context changes the behavior.
- Saying the range is clean without running or clearly scoping verification.
