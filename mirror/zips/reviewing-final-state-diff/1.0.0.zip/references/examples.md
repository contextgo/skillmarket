# Usage Examples

Use these prompts when you want a final-state review of a feature branch or commit range.

## Review a Known Range

```text
请用 reviewing-final-state-diff 审查 abc1234..HEAD 的整体差异，关注最终代码状态，不按单个 commit 审。
```

```text
$reviewing-final-state-diff
请审查 abc1234..HEAD 的整体差异，只关注最终代码状态。
```

## Review Against a Target Branch

```text
请用 reviewing-final-state-diff 审查当前分支相对 origin/develop 的最终状态差异。
```

```text
请用 reviewing-final-state-diff 审查当前 feature 分支相对 origin/main 的整体差异，不按提交逐个审。
```

## Include or Exclude Working Tree Changes

```text
请用 reviewing-final-state-diff 审查 abc1234..HEAD，并包含当前工作区未提交改动。
```

```text
请用 reviewing-final-state-diff 只审查 abc1234..HEAD 的提交差异，不包含工作区未提交改动。
```

## Expected Review Focus

```text
请用 reviewing-final-state-diff 审查 abc1234..HEAD，重点看最终代码是否有功能回归、数据丢失、兼容性问题和缺失的高价值测试。
```

```text
请用 reviewing-final-state-diff 审查当前分支最终状态。如果没有阻塞问题，请明确说明验证范围和残余风险。
```
