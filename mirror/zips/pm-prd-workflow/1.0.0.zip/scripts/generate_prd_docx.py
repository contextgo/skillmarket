#!/usr/bin/env python3
"""
Generate PRD Word document from structured requirements data.
"""

import sys
import json
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

def set_cell_border(cell, **kwargs):
    """Set cell border properties."""
    tc = cell._element
    tcPr = tc.get_or_add_tcPr()
    
    for edge in ('top', 'left', 'bottom', 'right'):
        edge_elm = tcPr.find(qn(f'w:{edge}'))
        if edge_elm is None:
            edge_elm = docx.oxml.OxmlElement(f'w:{edge}')
            tcPr.append(edge_elm)
        
        for key, val in kwargs.items():
            edge_elm.set(qn(f'w:{key}'), val)

def create_prd_document(data, output_path):
    """Create PRD Word document from requirements data."""
    doc = Document()
    
    # Title
    title = doc.add_heading('产品需求文档 (PRD)', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Product Info
    doc.add_heading('一、产品概述', level=1)
    
    info_table = doc.add_table(rows=4, cols=2)
    info_table.style = 'Table Grid'
    
    info_data = [
        ('产品名称', data.get('product_name', '未命名')),
        ('版本号', data.get('version', 'v1.0')),
        ('创建日期', data.get('created_date', '')),
        ('文档状态', data.get('status', '草稿')),
    ]
    
    for i, (key, val) in enumerate(info_data):
        row = info_table.rows[i]
        row.cells[0].text = key
        row.cells[1].text = val
        row.cells[0].paragraphs[0].runs[0].bold = True
    
    doc.add_paragraph()
    
    # Product Description
    doc.add_heading('二、产品背景与目标', level=1)
    doc.add_paragraph(data.get('description', '暂无描述'))
    
    # Requirements Table
    doc.add_heading('三、功能需求列表', level=1)
    
    req_table = doc.add_table(rows=1, cols=6)
    req_table.style = 'Table Grid'
    
    # Header
    headers = ['展现形式', '功能模块', '功能名称', '功能描述', '优先级', '备注']
    header_cells = req_table.rows[0].cells
    for i, header in enumerate(headers):
        header_cells[i].text = header
        header_cells[i].paragraphs[0].runs[0].bold = True
        header_cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Data rows
    for req in data.get('requirements', []):
        row = req_table.add_row().cells
        row[0].text = req.get('platform', '')
        row[1].text = req.get('module', '')
        row[2].text = req.get('name', '')
        row[3].text = req.get('description', '')
        row[4].text = req.get('priority', '')
        row[5].text = req.get('notes', '')
    
    doc.add_paragraph()
    
    # Business Logic Flow
    if data.get('flowchart_description'):
        doc.add_heading('四、主业务逻辑流程', level=1)
        doc.add_paragraph(data.get('flowchart_description', ''))
        doc.add_paragraph()
    
    # Appendix
    doc.add_heading('五、附录', level=1)
    doc.add_paragraph('本文档由 AI 辅助生成，如有疑问请联系产品经理确认。')
    
    # Save
    doc.save(output_path)
    print(f"PRD document saved to: {output_path}")

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python generate_prd_docx.py <input_json> <output_docx>")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    create_prd_document(data, output_file)
