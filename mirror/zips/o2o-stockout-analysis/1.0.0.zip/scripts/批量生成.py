# -*- coding: utf-8 -*-
"""
缺断周报批量生成脚本
使用方法：python 批量生成.py
自动扫描Downloads目录下的export*.xls文件并批量生成周报
"""
import os
import sys
import re
import shutil
import subprocess
from pathlib import Path

# ========== 配置区 ==========
# 桌面路径（自动获取）
DESKTOP = os.path.join(os.path.expanduser("~"), "Desktop")
# 下载目录
DOWNLOADS = os.path.join(os.path.expanduser("~"), "Downloads")
# 工作目录（模板所在目录）
WORK_DIR = r"c:\Users\33613\WorkBuddy\阿品-Claw"
# 周报输出目录（自动创建）
REPORT_DIR = os.path.join(WORK_DIR, "热销品缺断周报")
# 模板文件
TEMPLATE_FILE = os.path.join(WORK_DIR, "scripts", "缺断周报_通用模板.py")
# 热销品目录
TOP_FILE = os.path.join(DESKTOP, "国信TOP品.xlsx")
# 仓库库存
STOCK_FILE = os.path.join(DESKTOP, "国信商品库存情况.xlsx")
# ========== 配置区结束 ==========

def get_week_number(date_str=None):
    """获取当前周数"""
    from datetime import datetime
    if date_str:
        d = datetime.strptime(date_str, "%Y-%m-%d")
    else:
        d = datetime.now()
    # 格式：2026-04-11第2周
    return d.strftime("%Y-%m-%d第2周").replace("-04-11第", "-04-11第")

def get_week_prefix():
    """获取周报目录前缀（自动检测）"""
    from datetime import datetime
    today = datetime.now()
    # 简单逻辑：4月11日是第2周
    if today.month == 4 and today.day <= 7:
        week = 1
    elif today.month == 4 and today.day <= 14:
        week = 2
    elif today.month == 4 and today.day <= 21:
        week = 3
    else:
        week = 4
    return f"{today.strftime('%Y-%m-%d')}第{week}周"

def find_export_files():
    """扫描Downloads目录下的export文件"""
    export_files = []
    for f in os.listdir(DOWNLOADS):
        if f.startswith("export") and (f.endswith(".xls") or f.endswith(".xlsx")):
            # 提取门店名：从文件名提取
            # 格式：export瑞安信一店.xls 或 export (瑞安信一店).xls
            match = re.search(r'export[\\(]?(.+?)[\\)]?', f)
            if match:
                store_name = match.group(1).strip()
                export_files.append({
                    "file": os.path.join(DOWNLOADS, f),
                    "name": store_name
                })
    return export_files

def convert_xls_to_xlsx(xls_file, xlsx_file):
    """转换xls为xlsx"""
    try:
        import pandas as pd
        df = pd.read_excel(xls_file, engine="xlrd")
        df.to_excel(xlsx_file, index=False, engine="openpyxl")
        print(f"  [转换] {os.path.basename(xls_file)} → {os.path.basename(xlsx_file)}")
        return True
    except Exception as e:
        print(f"  [错误] 转换失败: {e}")
        return False

def run_report(store_name, store_file, output_file):
    """运行周报生成脚本"""
    # 读取模板
    with open(TEMPLATE_FILE, "r", encoding="utf-8") as f:
        template = f.read()
    
    # 替换配置区
    config = f'''# ========== 配置区 ==========
STORE_NAME = "{store_name}"
STORE_FILE = r"{store_file}"
OUTPUT_FILE = r"{output_file}"
# ========== 配置区结束 =========='''
    
    # 提取模板主体（去掉原有配置区）
    main_start = template.find("# ========== 配置区结束 ==========") + len("# ========== 配置区结束 ==========")
    main_code = template[main_start:].strip()
    
    # 组合新脚本
    new_script = config + "\n\n" + main_code
    
    # 写入临时脚本
    temp_script = os.path.join(WORK_DIR, "_temp", f"_run_{store_name}.py")
    with open(temp_script, "w", encoding="utf-8") as f:
        f.write(new_script)
    
    # 执行
    python_exe = r"C:\Users\33613\AppData\Local\Programs\Python\Python312\python.exe"
    result = subprocess.run([python_exe, temp_script], 
                          capture_output=True, text=True)
    if result.returncode == 0:
        print(f"  [成功] {store_name} 周报已生成")
        return True
    else:
        print(f"  [错误] {store_name} 生成失败: {result.stderr}")
        return False

def generate_summary(files):
    """生成横向对比分析"""
    summary_script = os.path.join(WORK_DIR, "_temp", "_generate_summary.py")
    summary_code = f'''# -*- coding: utf-8 -*-
import pandas as pd
import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

REPORT_DIR = r"{REPORT_DIR}"
week_prefix = "{get_week_prefix()}"

# 收集所有周报数据
data = []
for f in os.listdir(REPORT_DIR):
    if week_prefix in f and "清晰版.xlsx" in f:
        store = f.replace("热销品缺断周报_", "").replace("_清晰版.xlsx", "")
        try:
            wb = pd.read_excel(os.path.join(REPORT_DIR, f), sheet_name="汇总看板")
            # 提取关键数据...
            data.append({{"store": store}})
        except:
            pass

print(f"[OK] Found {{len(data)}} store reports")
'''
    with open(summary_script, "w", encoding="utf-8") as f:
        f.write(summary_code)
    
    python_exe = r"C:\Users\33613\AppData\Local\Programs\Python\Python312\python.exe"
    subprocess.run([python_exe, summary_script], capture_output=True)

def main():
    print("=" * 50)
    print("🏪 缺断周报批量生成工具")
    print("=" * 50)
    
    # 确保目录存在
    os.makedirs(os.path.join(WORK_DIR, "_temp"), exist_ok=True)
    
    # 获取周报目录
    week_prefix = get_week_prefix()
    week_dir = os.path.join(REPORT_DIR, week_prefix)
    os.makedirs(week_dir, exist_ok=True)
    print(f"\\n📁 输出目录: {week_dir}\\n")
    
    # 扫描export文件
    export_files = find_export_files()
    if not export_files:
        print("[提示] 未找到export文件")
        print("请将要处理的ERP文件放入Downloads目录，文件名格式：")
        print("  export瑞安信一店.xls")
        print("  export (瑞安信一店).xls")
        return
    
    print(f"📋 找到 {len(export_files)} 个门店文件:\\n")
    for i, f in enumerate(export_files, 1):
        print(f"  {i}. {f['name']} ({os.path.basename(f['file'])})")
    print()
    
    # 处理每个文件
    success = 0
    for f in export_files:
        print(f"处理: {f['name']}...")
        
        # 检查是否需要转换
        xls_file = f["file"]
        xlsx_file = xls_file + "x"
        if xls_file.endswith(".xls") and not os.path.exists(xlsx_file):
            if not convert_xls_to_xlsx(xls_file, xlsx_file):
                continue
            store_file = xlsx_file
        else:
            store_file = xls_file
        
        # 生成周报
        output_file = os.path.join(week_dir, f"热销品缺断周报_{f['name']}_清晰版.xlsx")
        if run_report(f["name"], store_file, output_file):
            success += 1
    
    print(f"\\n✅ 完成！成功生成 {success}/{len(export_files)} 个周报")
    print(f"📁 文件位置: {week_dir}")

if __name__ == "__main__":
    main()
