---
name: "OFDM_Receiver_Setup"
description: "Guides OFDM simulation platform setup and intelligent receiver model training. Invoke when user needs to build OFDM communication link or train neural network receiver."
---
## 工具/库版本要求
- MATLAB | R2021a 或更高 | OFDM 链路仿真、信道建模 |
- Communications Toolbox | 需包含 | 调制、误码率计算 |
- Python | 3.8+ | 深度学习模型训练 |
- PyTorch | 1.10+ | FCN 网络实现 |
- NumPy, Matplotlib | 最新版 | 数据处理与绘图 |
- SciPy | 可选 | 用于加载 .mat 数据交换 |
## 能力定义
1. 系统建模能力: 能够使用Matlab/Simulink搭建符合规范参数的OFDM通信链路。
2. 数据生成能力: 能够生成多信噪比条件下的通信信号数据集。
3. 模型构建能力: 能够设计并训练指定结构的全连接神经网络（FCN）。
## 工作流程
### 任务一：OFDM仿真平台搭建
#### 参数配置（严格遵循）：
- 子载波数 \(N_c\) 128 
- 调制方式  QPSK 
- 循环前缀长度 \(N_{CP}\) 32（符号长度的 1/4） 
- 数据帧结构 每帧 128 个符号（包含导频，本阶段可先采用理想信道估计或已知信道） 
- 信道模型 AWGN、瑞利衰落（Jakes 模型）、WINNER II
- 信噪比范围 0 ~ 20 dB，步进 2 dB 
#### 模块实现: 
- 发射端：随机生成QPSK符号序列，经IFFT 变换为时域信号，添加循环前缀后发送。
- 信道模拟：信号通过瑞利衰落信道，信道冲激响应 
- 接收端预处理：移除 CP，FFT 变换得到频域接收符号
- 数据集构建：每个样本由 256 维实向量（128 个 I/Q 对）组成，标签为对应的 QPSK 符号（四类）。共生成 100,000 组样本，覆盖 0~20dB 信噪比范围（步进 2dB），其中 80% 用于训练，20% 用于测试。
#### 验证测试: 
- 运行仿真，绘制BER曲线并与理论值对比，确保链路无误。
#### 预期输出: 
- 可运行的matlab/Simulink 项目文件，包含OFDM仿真平台代码。
- 系统搭建报告文档。
### 任务二：智能接收机基准模型设计与训练
#### 参数配置（严格遵循）：
- 网络结构（固定）：
- 输入层：256 个神经元（对应 128 个子载波的 I/Q 分量）。
- 隐藏层 1：128 个神经元，激活函数 ReLU。
- 隐藏层 2：64 个神经元，激活函数 ReLU。
- 隐藏层 3：32 个神经元，激活函数 ReLU。
- 输出层：4 个神经元，激活函数 Softmax（输出四个符号的概率分布）。
- 训练超参数（固定）：
- 优化器 Adam 
- 初始学习率 0.001 
- 损失函数  交叉熵损失（CrossEntropyLoss） 
- 批次大小（Batch Size）  128 
- 训练轮次（Epochs）  30 
- 学习率调度  可选用 StepLR 或 ReduceLROnPlateau（若验证集损失停滞） 
#### 模块实现: 
- 网络构建: 利用python和PyTorch库按照上述固定网络结构实现FCN。
#### 预期输出: 
- python代码实现模型训练代码。

