# qianliu-aitest Skill

千流 AI 测试效能平台集成技能。

## 用途

- 执行 TP 平台的测试任务
- 获取测试床和执行主机信息
- 监控测试执行状态
- 获取测试报告

## 配置

### 1. Token 配置

在 `~/.qianliu/config.json` 中配置 TP 平台的访问 Token：

```json
{
  "tp_token": "your_token_here",
  "tp_base_url": "https://tp.atrust.sangfor.com"
}
```

### 2. 任务配置

在 `workspace/.qianliu/.qianliu-aitest/tp-aitest-config.yaml` 中配置任务参数：

```yaml
tp_platform:
  project_id: 8
  version_id: 117
  ai_testcase_task_id: 1488
  agent_version: "v1"
  testbed_name: ""
  exec_host_name: ""
  desc: "批量测试任务（上线验证）- 千流manus"
```

## 使用方法

### 执行测试任务

```bash
# PowerShell
./scripts/execute-tp-test.ps1 -PlanId 1488 -ProductId 8 -ProjectId 117
```

### 获取测试床列表

```bash
# PowerShell
./scripts/get-resources.ps1 -Type testbed
```

## API 端点

- 获取测试床列表：`GET /api/resource/testbeds`
- 获取执行主机列表：`GET /api/resource/exec-hosts`
- 执行测试任务：`POST /api/test/execute`
- 查询任务状态：`GET /api/test/status/{taskId}`
- 获取测试报告：`GET /api/test/report/{taskId}`

## 获取 Token

1. 登录 TP 平台：https://tp.atrust.sangfor.com
2. 进入个人设置 -> API Token
3. 生成或复制 Token
4. 将 Token 配置到 `~/.qianliu/config.json`

## 故障排查

### Token 无效
- 检查 Token 是否过期
- 确认 Token 有正确的权限

### 测试床不可用
- 确认测试床状态为"空闲"
- 检查测试床是否已分配给其他任务

### 执行主机连接失败
- 确认执行主机在线
- 检查网络连接
