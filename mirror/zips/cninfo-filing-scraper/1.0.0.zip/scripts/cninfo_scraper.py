#!/usr/bin/env python3
"""
CNInfo Filing Scraper - 巨潮资讯网A股公告检索与下载工具

基于巨潮资讯网(hisAnnouncement/query)公开JSON API，
支持按股票代码和日期范围搜索公告、批量下载PDF文档、导出Excel。

用法:
    python cninfo_scraper.py search --stock 000001
    python cninfo_scraper.py search --stock 600519 --from 2025-01-01 --to 2025-12-31
    python cninfo_scraper.py search --stock 000858 --category ndbg
    python cninfo_scraper.py download --stock 600519 --from 2025-01-01 --output ./pdfs
    python cninfo_scraper.py search --stock 000858 --format xlsx --output filings.xlsx
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CNINFO_SEARCH_URL = "https://www.cninfo.com.cn/new/hisAnnouncement/query"
CNINFO_STOCK_URL = "https://www.cninfo.com.cn/new/data/szse_stock.json"
CNINFO_DETAIL_URL = "https://www.cninfo.com.cn/new/disclosure/detail?announcementId={id}"
CNINFO_PDF_BASE = "https://static.cninfo.com.cn/"

# Rate limit: 1.5s between requests (cninfo is aggressive on rate limiting)
REQUEST_INTERVAL = 1.5

DEFAULT_HEADERS = {
    "Accept": "*/*",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "X-Requested-With": "XMLHttpRequest",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Origin": "https://www.cninfo.com.cn",
    "Referer": "https://www.cninfo.com.cn/new/commonUrl/pageOfSearch?url=disclosure/list/search",
}

# Category code mapping
CATEGORY_MAP = {
    "ndbg": "category_ndbg_szsh",       # 年报
    "bndbg": "category_bndbg_szsh",     # 半年报
    "yjdbg": "category_yjdbg_szsh",     # 一季报
    "sjdbg": "category_sjdbg_szsh",     # 三季报
    "yjygjxz": "category_yjygjxz_szsh", # 业绩预告
    "qyfpxzcs": "category_qyfpxzcs_szsh", # 权益分派
    "dshgg": "category_dshgg_szsh",     # 董事会
    "jshgg": "category_jshgg_szsh",     # 监事会
    "gddh": "category_gddh_szsh",       # 股东会
    "rcjy": "category_rcjy_szsh",       # 日常经营
    "gszl": "category_gszl_szsh",       # 公司治理
    "zj": "category_zj_szsh",           # 中介报告
    "sf": "category_sf_szsh",           # 首发IPO
    "zf": "category_zf_szsh",           # 增发
    "gqjl": "category_gqjl_szsh",       # 股权激励
    "pg": "category_pg_szsh",           # 配股
    "jj": "category_jj_szsh",           # 解禁
    "gszq": "category_gszq_szsh",       # 公司债
    "kzzq": "category_kzzq_szsh",       # 可转债
    "qtrz": "category_qtrz_szsh",       # 其他融资
    "gqbd": "category_gqbd_szsh",       # 股权变动
    "bcgz": "category_bcgz_szsh",       # 补充更正
    "cqdq": "category_cqdq_szsh",       # 澄清致歉
    "fxts": "category_fxts_szsh",       # 风险提示
    "tbclts": "category_tbclts_szsh",   # 特别处理和退市
}

# Category display names
CATEGORY_NAMES = {
    "ndbg": "年报", "bndbg": "半年报", "yjdbg": "一季报", "sjdbg": "三季报",
    "yjygjxz": "业绩预告", "qyfpxzcs": "权益分派", "dshgg": "董事会",
    "jshgg": "监事会", "gddh": "股东会", "rcjy": "日常经营", "gszl": "公司治理",
    "zj": "中介报告", "sf": "首发IPO", "zf": "增发", "gqjl": "股权激励",
    "pg": "配股", "jj": "解禁", "gszq": "公司债", "kzzq": "可转债",
    "qtrz": "其他融资", "gqbd": "股权变动", "bcgz": "补充更正",
    "cqdq": "澄清致歉", "fxts": "风险提示", "tbclts": "特别处理和退市",
}

# Plate code mapping
PLATE_MAP = {
    "sz": "sz", "szmb": "szmb", "szcy": "szcy",
    "sh": "sh", "shmb": "shmb", "shkcp": "shkcp", "bj": "bj",
}


# ---------------------------------------------------------------------------
# Stock code -> orgId mapping
# ---------------------------------------------------------------------------

_stock_cache: Optional[Dict[str, dict]] = None


def _load_stock_list() -> Dict[str, dict]:
    """Load stock list with orgId from cninfo API.

    Returns dict mapping stock code -> {code, orgId, name, category, pinyin}.
    """
    global _stock_cache
    if _stock_cache is not None:
        return _stock_cache

    import requests as _requests

    print("  加载A股股票列表...", file=sys.stderr)
    _stock_cache = {}

    try:
        resp = _requests.get(
            CNINFO_STOCK_URL,
            headers={
                "User-Agent": DEFAULT_HEADERS["User-Agent"],
                "Referer": "https://www.cninfo.com.cn/",
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()

        stock_list = data.get("stockList", [])
        for s in stock_list:
            code = s.get("code", "").strip()
            if code:
                _stock_cache[code] = {
                    "code": code,
                    "orgId": s.get("orgId", ""),
                    "name": s.get("zwjc", ""),
                    "category": s.get("category", ""),
                    "pinyin": s.get("pinyin", ""),
                }

        print(f"  已加载 {len(_stock_cache)} 只A股", file=sys.stderr)

    except Exception as e:
        print(f"  股票列表加载失败: {e}", file=sys.stderr)

    return _stock_cache


def lookup_stock(code: str) -> Optional[dict]:
    """Look up stock info by code. Returns {code, orgId, name} or None."""
    stocks = _load_stock_list()
    return stocks.get(code.strip())


def _build_stock_param(code: str) -> str:
    """Build the stock parameter value: 'code,orgId' format required by cninfo API."""
    info = lookup_stock(code)
    if info and info.get("orgId"):
        return f"{info['code']},{info['orgId']}"
    # Fallback: try just the code (won't work but let it try)
    return code


# ---------------------------------------------------------------------------
# Filing classification
# ---------------------------------------------------------------------------

def classify_announcement(title: str) -> Tuple[str, str]:
    """Classify an announcement by its title. Returns (category_key, description)."""
    if not title:
        return "other", "其他"

    if "年度报告" in title or "年报" in title:
        return "ndbg", "年报"
    elif "半年度报告" in title or "半年报" in title or "中期报告" in title:
        return "bndbg", "半年报"
    elif "第一季度" in title:
        return "yjdbg", "一季报"
    elif "第三季度" in title:
        return "sjdbg", "三季报"
    elif "业绩预告" in title or "业绩快报" in title:
        return "yjygjxz", "业绩预告"
    elif "权益分派" in title or "分红" in title or "派息" in title:
        return "qyfpxzcs", "权益分派"
    elif "董事会" in title:
        return "dshgg", "董事会"
    elif "监事会" in title:
        return "jshgg", "监事会"
    elif "股东大会" in title:
        return "gddh", "股东会"
    elif "招股说明书" in title or "IPO" in title.upper():
        return "sf", "首发IPO"
    elif "可转债" in title:
        return "kzzq", "可转债"
    elif "股权激励" in title:
        return "gqjl", "股权激励"
    elif "更正" in title or "补充" in title:
        return "bcgz", "补充更正"
    elif "澄清" in title or "致歉" in title:
        return "cqdq", "澄清致歉"
    elif "风险提示" in title:
        return "fxts", "风险提示"
    else:
        return "other", "其他"


# ---------------------------------------------------------------------------
# API: Fetch announcements
# ---------------------------------------------------------------------------

def _build_payload(
    stock: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    category: Optional[str] = None,
    search_key: Optional[str] = None,
    plate: Optional[str] = None,
    page_num: int = 1,
    page_size: int = 30,
) -> dict:
    """Build POST payload for cninfo search API."""
    today = datetime.now().strftime("%Y-%m-%d")
    two_months_ago = (datetime.now() - timedelta(days=60)).strftime("%Y-%m-%d")

    se_date = f"{date_from or two_months_ago}~{date_to or today}"

    payload = {
        "pageNum": str(page_num),
        "pageSize": str(page_size),
        "column": "szse",
        "tabName": "fulltext",
        "plate": "",
        "stock": _build_stock_param(stock) if stock else "",
        "searchkey": search_key or "",
        "secid": "",
        "category": CATEGORY_MAP.get(category, "") if category else "",
        "trade": "",
        "seDate": se_date,
        "sortName": "",
        "sortType": "",
        "isHLtitle": "true",
    }

    if plate and plate in PLATE_MAP:
        payload["plate"] = PLATE_MAP[plate]

    return payload


def fetch_announcements(
    stock: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    category: Optional[str] = None,
    search_key: Optional[str] = None,
    plate: Optional[str] = None,
    max_pages: int = 0,
    page_size: int = 30,
) -> List[dict]:
    """Fetch announcements from cninfo.

    Args:
        stock: Stock code (e.g., '000001', '600519')
        date_from: Start date YYYY-MM-DD
        date_to: End date YYYY-MM-DD
        category: Category key (e.g., 'ndbg', 'bndbg')
        search_key: Keyword search in title
        plate: Plate filter (e.g., 'sz', 'sh', 'bj')
        max_pages: Max pages to fetch (0 = all)
        page_size: Results per page (max 100)

    Returns:
        List of announcement dicts
    """
    import requests as _requests

    if page_size > 100:
        page_size = 100

    all_announcements = []
    page_num = 1

    while True:
        payload = _build_payload(
            stock=stock,
            date_from=date_from,
            date_to=date_to,
            category=category,
            search_key=search_key,
            plate=plate,
            page_num=page_num,
            page_size=page_size,
        )

        print(f"  请求第 {page_num} 页...", file=sys.stderr)

        try:
            resp = _requests.post(
                CNINFO_SEARCH_URL,
                data=payload,
                headers=DEFAULT_HEADERS,
                timeout=30,
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            print(f"  请求失败: {e}", file=sys.stderr)
            break

        announcements = data.get("announcements") or []
        if not announcements:
            if page_num == 1:
                print("  未找到公告", file=sys.stderr)
            break

        total_pages = data.get("totalpages", 1)
        total_records = data.get("totalRecordNum", 0)

        if page_num == 1:
            print(f"  共 {total_records} 条公告，{total_pages} 页", file=sys.stderr)

        for ann in announcements:
            sec_code = ann.get("secCode", "").strip()
            sec_name = re.sub(r"</?em>", "", ann.get("secName", "")).strip()
            title = re.sub(r"</?em>", "", ann.get("announcementTitle", "")).strip()
            ann_id = ann.get("announcementId", "")
            adjunct_url = ann.get("adjunctUrl", "")
            adjunct_size = ann.get("adjunctSize", 0)
            adjunct_type = ann.get("adjunctType", "")
            ann_time_ms = ann.get("announcementTime", 0)

            ann_date = ""
            if ann_time_ms:
                try:
                    ann_date = datetime.fromtimestamp(ann_time_ms / 1000).strftime("%Y-%m-%d")
                except Exception:
                    pass

            cat_key, cat_desc = classify_announcement(title)

            detail_url = CNINFO_DETAIL_URL.format(id=ann_id) if ann_id else ""
            pdf_url = f"{CNINFO_PDF_BASE}{adjunct_url}" if adjunct_url else ""

            all_announcements.append({
                "secCode": sec_code,
                "secName": sec_name,
                "title": title,
                "announcementId": ann_id,
                "announcementDate": ann_date,
                "category": cat_key,
                "categoryDescription": cat_desc,
                "adjunctUrl": adjunct_url,
                "adjunctSize": adjunct_size,
                "adjunctType": adjunct_type,
                "detailUrl": detail_url,
                "pdfUrl": pdf_url,
            })

        if page_num >= total_pages:
            break
        if max_pages > 0 and page_num >= max_pages:
            break

        page_num += 1
        time.sleep(REQUEST_INTERVAL)

    return all_announcements


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

def download_announcements(
    announcements: List[dict],
    output_dir: str,
) -> List[str]:
    """Download announcement PDFs to output_dir."""
    import requests as _requests

    os.makedirs(output_dir, exist_ok=True)
    downloaded = []

    for ann in announcements:
        pdf_url = ann.get("pdfUrl", "")
        if not pdf_url:
            continue

        adjunct_type = ann.get("adjunctType", "").upper()
        if adjunct_type and adjunct_type != "PDF":
            print(f"  SKIP (non-PDF: {adjunct_type}): {ann['title'][:40]}", file=sys.stderr)
            continue

        sec_code = ann.get("secCode", "unknown")
        ann_date = ann.get("announcementDate", "nodate")
        safe_title = re.sub(r'[^\w\u4e00-\u9fff\-_.]', '_', ann.get("title", "doc"))[:60]
        filename = f"{sec_code}_{ann_date}_{safe_title}.pdf"
        filepath = os.path.join(output_dir, filename)

        if os.path.exists(filepath):
            print(f"  SKIP (exists): {filename}", file=sys.stderr)
            downloaded.append(filepath)
            continue

        try:
            resp = _requests.get(
                pdf_url,
                headers={
                    "User-Agent": DEFAULT_HEADERS["User-Agent"],
                    "Referer": "https://www.cninfo.com.cn/",
                },
                timeout=60,
            )
            resp.raise_for_status()

            content_type = resp.headers.get("Content-Type", "")
            if "pdf" not in content_type.lower() and not resp.content[:5].startswith(b"%PDF"):
                print(f"  SKIP (not PDF, ct={content_type[:30]}): {filename}", file=sys.stderr)
                continue

            with open(filepath, "wb") as f:
                f.write(resp.content)

            print(f"  OK: {filename} ({len(resp.content):,} bytes)", file=sys.stderr)
            downloaded.append(filepath)
            time.sleep(REQUEST_INTERVAL)

        except Exception as e:
            print(f"  FAIL: {filename}: {e}", file=sys.stderr)

    return downloaded


# ---------------------------------------------------------------------------
# Export to Excel
# ---------------------------------------------------------------------------

def export_xlsx(announcements: List[dict], output_path: str):
    """Export announcements to Excel with hyperlinks."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    except ImportError:
        print("[ERROR] openpyxl 未安装。请运行: pip install openpyxl", file=sys.stderr)
        sys.exit(1)

    wb = Workbook()
    ws = wb.active
    ws.title = "CNInfo Filings"

    headers = [
        "序号", "股票代码", "公司简称", "公告标题", "分类",
        "分类说明", "公告日期", "文件类型", "文件大小(KB)", "详情", "PDF",
    ]
    header_fill = PatternFill(start_color="C00000", end_color="C00000", fill_type="solid")
    header_font = Font(color="FFFFFF", bold=True, size=11)
    thin_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )

    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = thin_border

    link_font = Font(color="0563C1", underline="single")

    for i, ann in enumerate(announcements, 1):
        row = i + 1
        ws.cell(row=row, column=1, value=i).border = thin_border
        ws.cell(row=row, column=2, value=ann["secCode"]).border = thin_border
        ws.cell(row=row, column=3, value=ann["secName"]).border = thin_border
        ws.cell(row=row, column=4, value=ann["title"]).border = thin_border
        ws.cell(row=row, column=5, value=ann["category"]).border = thin_border
        ws.cell(row=row, column=6, value=ann["categoryDescription"]).border = thin_border
        ws.cell(row=row, column=7, value=ann["announcementDate"]).border = thin_border
        ws.cell(row=row, column=8, value=ann.get("adjunctType", "")).border = thin_border
        ws.cell(row=row, column=9, value=ann.get("adjunctSize", 0)).border = thin_border

        detail_cell = ws.cell(row=row, column=10, value="详情")
        detail_cell.hyperlink = ann.get("detailUrl", "")
        detail_cell.font = link_font
        detail_cell.border = thin_border

        pdf_cell = ws.cell(row=row, column=11, value="PDF")
        pdf_cell.hyperlink = ann.get("pdfUrl", "")
        pdf_cell.font = link_font
        pdf_cell.border = thin_border

    widths = [6, 10, 12, 50, 10, 10, 12, 8, 10, 6, 6]
    for i, w in enumerate(widths, 1):
        col_letter = chr(64 + i) if i <= 26 else f"A{chr(64 + i - 26)}"
        ws.column_dimensions[col_letter].width = w

    ws.auto_filter.ref = ws.dimensions

    wb.save(output_path)
    print(f"  导出Excel: {output_path} ({len(announcements)}条)", file=sys.stderr)


# ---------------------------------------------------------------------------
# CLI Commands
# ---------------------------------------------------------------------------

def cmd_search(args):
    """Search cninfo announcements."""
    announcements = fetch_announcements(
        stock=args.stock,
        date_from=args.from_date,
        date_to=args.to_date,
        category=args.category,
        search_key=args.search_key,
        plate=args.plate,
        max_pages=args.max_pages,
        page_size=args.page_size,
    )

    if not announcements:
        stock_desc = args.stock or "全市场"
        print(f"\n未找到 {stock_desc} 的公告", file=sys.stderr)
        return

    stock_desc = args.stock or "全市场"
    print(f"\n{stock_desc} 公告搜索结果 ({len(announcements)}条)")
    print("=" * 80)
    for a in announcements:
        print(f"  [{a['announcementDate']}] {a['secCode']} {a['secName']} - {a['title'][:50]}")

    if args.format == "xlsx":
        output = args.output or f"{args.stock or 'all'}_cninfo_filings.xlsx"
        export_xlsx(announcements, output)

    json_output = (
        args.output.replace(".xlsx", ".json")
        if args.output and args.format == "xlsx"
        else f"{args.stock or 'all'}_cninfo_filings.json"
    )
    if not args.output or args.format != "xlsx":
        json_output = f"{args.stock or 'all'}_cninfo_filings.json"
    with open(json_output, "w", encoding="utf-8") as jf:
        json.dump(announcements, jf, ensure_ascii=False, indent=2, default=str)
    print(f"  JSON已保存: {json_output}", file=sys.stderr)


def cmd_download(args):
    """Download cninfo announcement PDFs."""
    announcements = fetch_announcements(
        stock=args.stock,
        date_from=args.from_date,
        date_to=args.to_date,
        category=args.category,
        max_pages=args.max_pages or 5,
        page_size=30,
    )

    if not announcements:
        print(f"\n未找到 {args.stock or '全市场'} 的公告", file=sys.stderr)
        return

    output_dir = args.output or f"./{args.stock or 'all'}_cninfo_pdfs"
    print(f"\n下载 {len(announcements)} 份公告到 {output_dir}", file=sys.stderr)
    downloaded = download_announcements(announcements, output_dir)
    print(f"\n下载完成: {len(downloaded)}/{len(announcements)} 份", file=sys.stderr)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="CNInfo Filing Scraper - 巨潮资讯网A股公告检索与下载"
    )
    subparsers = parser.add_subparsers(dest="command", help="命令")

    search_parser = subparsers.add_parser("search", help="搜索公告")
    search_parser.add_argument("--stock", help="股票代码 (e.g., 000001, 600519)")
    search_parser.add_argument("--from", dest="from_date", help="起始日期 YYYY-MM-DD")
    search_parser.add_argument("--to", dest="to_date", help="结束日期 YYYY-MM-DD")
    search_parser.add_argument("--category", help="公告分类 (ndbg年报/bndbg半年报/yjygjxz业绩预告等)")
    search_parser.add_argument("--search-key", help="标题关键字搜索")
    search_parser.add_argument("--plate", help="板块过滤 (sz/sh/bj/szcy/shkcp)")
    search_parser.add_argument("--max-pages", type=int, default=0, help="最大页数 (0=全部)")
    search_parser.add_argument("--page-size", type=int, default=30, help="每页条数 (最大100)")
    search_parser.add_argument("--format", choices=["text", "xlsx"], default="text", help="输出格式")
    search_parser.add_argument("--output", help="输出文件路径")

    dl_parser = subparsers.add_parser("download", help="下载公告PDF")
    dl_parser.add_argument("--stock", help="股票代码")
    dl_parser.add_argument("--from", dest="from_date", help="起始日期 YYYY-MM-DD")
    dl_parser.add_argument("--to", dest="to_date", help="结束日期 YYYY-MM-DD")
    dl_parser.add_argument("--category", help="公告分类")
    dl_parser.add_argument("--max-pages", type=int, default=5, help="最大页数")
    dl_parser.add_argument("--output", help="输出目录")

    args = parser.parse_args()

    if args.command == "search":
        cmd_search(args)
    elif args.command == "download":
        cmd_download(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
