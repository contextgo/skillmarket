---
name: cninfo-filing-scraper
version: 1.0.0
description: |
  巨潮资讯网A股公告检索与下载工具。支持按股票代码、日期范围、公告类型搜索公告，
  批量下载PDF文档，提取公告元数据（股票代码、公司简称、公告标题、分类、日期等）。
  触发词：巨潮网、A股公告、cninfo、深交所公告、上交所公告、年报下载、半年报、
  业绩预告、公告检索、创业板公告、科创板公告、北交所公告、巨潮公告
---

# CNInfo Filing Scraper - 巨潮资讯网A股公告检索工具

基于巨潮资讯网公开JSON API，支持按股票代码、日期范围和公告类型搜索A股公告、批量下载PDF文档、导出Excel。

## 能力

1. **搜索公告**：按股票代码 + 日期范围 + 公告类型搜索A股公告
2. **批量下载**：下载公告PDF文档到本地目录
3. **元数据导出**：输出结构化JSON或Excel（含超链接）
4. **公告分类**：自动识别公告类型（年报、半年报、业绩预告、董事会等）
5. **板块筛选**：支持深市/沪市/北交所/创业板/科创板过滤

## 使用方式

调用 `scripts/cninfo_scraper.py` 脚本：

```bash
# 搜索某只股票的公告（默认最近2个月）
python3 "$SKILL_DIR/scripts/cninfo_scraper.py" search --stock 000001

# 搜索指定日期范围
python3 "$SKILL_DIR/scripts/cninfo_scraper.py" search --stock 600519 --from 2025-01-01 --to 2025-12-31

# 按公告类型过滤（年报）
python3 "$SKILL_DIR/scripts/cninfo_scraper.py" search --stock 000858 --category ndbg

# 关键字搜索
python3 "$SKILL_DIR/scripts/cninfo_scraper.py" search --stock 000001 --search-key "关联交易"

# 板块筛选
python3 "$SKILL_DIR/scripts/cninfo_scraper.py" search --plate szcy --from 2025-01-01

# 下载公告PDF
python3 "$SKILL_DIR/scripts/cninfo_scraper.py" download --stock 600519 --from 2025-01-01 --output ./pdfs

# 导出为Excel
python3 "$SKILL_DIR/scripts/cninfo_scraper.py" search --stock 000858 --format xlsx --output filings.xlsx

# 限制返回数量
python3 "$SKILL_DIR/scripts/cninfo_scraper.py" search --stock 000001 --max-pages 3
```

## 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `search` | 子命令：搜索公告元数据 | - |
| `download` | 子命令：搜索并下载PDF | - |
| `--stock` | 股票代码（6位数字，如000001） | 全市场 |
| `--from` | 起始日期（YYYY-MM-DD） | 2个月前 |
| `--to` | 结束日期（YYYY-MM-DD） | 今天 |
| `--category` | 公告分类代码 | 全部 |
| `--search-key` | 标题关键字 | 无 |
| `--plate` | 板块过滤 | 全部 |
| `--max-pages` | 最大页数 | 0=不限 |
| `--page-size` | 每页条数（最大100） | 30 |
| `--format` | 输出格式：text/xlsx | text |
| `--output` | 输出文件路径 | 自动生成 |

## 公告分类代码

| 代码 | 分类 | 代码 | 分类 |
|------|------|------|------|
| `ndbg` | 年报 | `bndbg` | 半年报 |
| `yjdbg` | 一季报 | `sjdbg` | 三季报 |
| `yjygjxz` | 业绩预告 | `qyfpxzcs` | 权益分派 |
| `dshgg` | 董事会 | `jshgg` | 监事会 |
| `gddh` | 股东会 | `rcjy` | 日常经营 |
| `gszl` | 公司治理 | `zj` | 中介报告 |
| `sf` | 首发IPO | `zf` | 增发 |
| `gqjl` | 股权激励 | `kzzq` | 可转债 |
| `gqbd` | 股权变动 | `bcgz` | 补充更正 |
| `cqdq` | 澄清致歉 | `fxts` | 风险提示 |

## 板块代码

| 代码 | 板块 |
|------|------|
| `sz` | 深市 |
| `szmb` | 深主板 |
| `szcy` | 创业板 |
| `sh` | 沪市 |
| `shmb` | 沪主板 |
| `shkcp` | 科创板 |
| `bj` | 北交所 |

## 数据字段

每条公告包含以下字段：

- `secCode`: 股票代码（如 000001）
- `secName`: 公司简称
- `title`: 公告标题
- `announcementId`: 公告唯一ID
- `announcementDate`: 公告日期
- `category`: 自动分类代码
- `categoryDescription`: 分类说明
- `adjunctUrl`: 附件相对路径
- `adjunctSize`: 附件大小（KB）
- `adjunctType`: 附件类型（PDF/HTML/XLSX）
- `detailUrl`: 巨潮网详情页链接
- `pdfUrl`: PDF直接下载链接

## 技术原理

使用巨潮资讯网公开JSON API：
- 搜索接口：`https://www.cninfo.com.cn/new/hisAnnouncement/query`（POST）
- 详情页面：`https://www.cninfo.com.cn/new/disclosure/detail?announcementId={id}`
- PDF下载：`https://static.cninfo.com.cn/{adjunctUrl}`

该API支持：
- 按股票代码、日期范围、公告类型筛选
- 分页获取全部记录
- 无需API Key，无需浏览器
- 速率限制：1.5秒间隔（已内置）

## 注意事项

- 巨潮网反爬较严格，脚本已设置1.5秒请求间隔，请勿调低
- PDF直链 `static.cninfo.com.cn` 通常可直接下载，少数情况可能需要Cookie
- 如遇频繁403，可在浏览器登录巨潮网后，将Cookie手动添加到脚本headers中
- 部分公告附件为HTML或XLSX格式，下载命令默认只下载PDF

## 审计场景示例

- 获取A股客户特定期间的全部公告列表
- 批量下载年报、半年报用于审计底稿
- 检查某公司公告披露的及时性和完整性
- 按类型筛选业绩预告、权益分派等关键公告
