---
name: lyrics
version: "2.0.0"
author: BytesAgain
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
license: MIT-0
tags: [lyrics, tool, utility]
description: "Write lyrics with rhyme finding, syllable counting, and verse structuring. Use when composing songs, finding rhymes, structuring verses and choruses."
---

# Lyrics

Content creation toolkit for drafting, editing, optimizing, and managing written content. Lyrics provides a complete content workflow — from initial drafts through editing, optimization, tone adjustment, translation, and scheduling. Each command logs timestamped entries to local files, giving you a persistent history of all your content work.

## Commands

| Command | Description |
|---------|-------------|
| `lyrics draft <input>` | Draft new content — saves a timestamped draft entry |
| `lyrics edit <input>` | Edit and refine existing content |
| `lyrics optimize <input>` | Optimize content for performance or clarity |
| `lyrics schedule <input>` | Schedule content for future publishing |
| `lyrics hashtags <input>` | Generate or log hashtag ideas for posts |
| `lyrics hooks <input>` | Create attention-grabbing hooks and openers |
| `lyrics cta <input>` | Craft call-to-action text |
| `lyrics rewrite <input>` | Rewrite content with a fresh angle |
| `lyrics translate <input>` | Translate or localize content |
| `lyrics tone <input>` | Adjust content tone (formal, casual, persuasive, etc.) |
| `lyrics headline <input>` | Generate headlines and titles |
| `lyrics outline <input>` | Create content outlines and structures |
| `lyrics stats` | Show summary statistics across all entry types |
| `lyrics export <fmt>` | Export all data (formats: json, csv, txt) |
| `lyrics search <term>` | Search across all logged entries |
| `lyrics recent` | Show the 20 most recent activity entries |
| `lyrics status` | Health check — version, data size, last activity |
| `lyrics help` | Show all available commands |
| `lyrics version` | Show version number |

Each content command (draft, edit, optimize, etc.) can be called without arguments to view recent entries for that type, or with arguments to save a new entry.

## Data Storage

All data is stored locally in `~/.local/share/lyrics/`:

- **Per-command logs**: `draft.log`, `edit.log`, `optimize.log`, `schedule.log`, `hashtags.log`, `hooks.log`, `cta.log`, `rewrite.log`, `translate.log`, `tone.log`, `headline.log`, `outline.log`
- **Activity history**: `history.log` — unified log of all actions with timestamps
- **Exports**: `export.json`, `export.csv`, or `export.txt` — generated on demand

Each entry is stored as `YYYY-MM-DD HH:MM|<content>` for easy parsing and review.

## Requirements

- Bash 4.0+ (uses `set -euo pipefail`)
- Standard Unix utilities (`date`, `wc`, `du`, `grep`, `tail`, `head`, `cat`)
- No external API keys or network access needed
- Runs entirely offline with local file storage

## When to Use

1. **Content creation workflow** — You're writing blog posts, social media content, or marketing copy and want to track your drafts, edits, and revisions in one place.
2. **Social media management** — You need to generate hashtags, hooks, and CTAs for posts, and want a log of what you've used before.
3. **Content scheduling** — You're planning content ahead and want to log what's scheduled for when.
4. **Multilingual content** — You're translating or adapting content for different audiences and want to track translation notes.
5. **Content auditing** — You want to review your content history, search for past work, and export everything for analysis or backup.

## Examples

```bash
# Draft a new blog post intro
lyrics draft "AI is transforming how small businesses reach customers online"

# Generate hashtag ideas for a tech post
lyrics hashtags "#AI #SmallBusiness #DigitalMarketing #ContentStrategy"

# Create a hook for an Instagram reel
lyrics hooks "Did you know 73% of marketers say AI saves them 5+ hours per week?"

# Write a call-to-action
lyrics cta "Download our free guide to AI-powered content creation"

# Rewrite content with a different angle
lyrics rewrite "Instead of focusing on features, lead with the customer pain point"

# Adjust tone to be more casual
lyrics tone "Hey! Quick tip: AI tools aren't replacing writers — they're making us faster"

# Create a headline
lyrics headline "5 Ways AI Content Tools Changed My Writing Process"

# View recent drafts
lyrics draft

# Search all entries for a keyword
lyrics search "marketing"

# Export everything as JSON
lyrics export json

# Check overall stats
lyrics stats

# See recent activity across all commands
lyrics recent
```

## Output

All commands output to stdout. Results can be redirected:

```bash
lyrics stats > content-report.txt
lyrics export json
```

## Configuration

Set `LYRICS_DIR` environment variable to change the data directory. Default: `~/.local/share/lyrics/`

---
*Powered by BytesAgain | bytesagain.com | hello@bytesagain.com*
