---
name: bp-motion-analysis
description: "Generate comprehensive British Parliamentary (BP) debate motion analysis documents as polished HTML files. Use this skill whenever a user provides a debate motion and wants a structured analysis — including motion type classification, position-specific strategies, burdens mapping, framing options, arguments for all four table positions (OG, OO, CG, CO), tournament room simulations, real-world examples, and balance evaluation. Trigger on any mention of 'motion analysis', 'BP debate', 'WUDC', 'British Parliamentary', 'debate prep', 'analyze this motion', or when a user provides a motion in THW/THBT/THS/THO/THP/THR format and asks for analysis. Also trigger when users ask for debate case-building, argument generation for specific positions, or motion evaluation for CA/adjudication work."
---

# BP Motion Analysis — HTML Generator

## Overview

This skill generates a comprehensive, publication-quality HTML motion analysis document for any British Parliamentary (BP) debate motion. The output is a single self-contained `.html` file styled for readability, with collapsible sections, responsive design, and print-friendly formatting.

## When to Use

- User provides a BP motion (THW/THBT/THS/THO/THP/THR format) and wants analysis
- User asks for "motion analysis", "debate prep", "case building", or "motion evaluation"
- User wants arguments for specific positions in a BP round
- User is doing CA/adjudication work and wants to evaluate a motion's balance
- User mentions WUDC, Worlds, Euros, or any BP tournament preparation

## Workflow

### Step 0: Input Validation (before any analysis)

Before doing anything, confirm the input is analyzable:

| Input issue | Action |
|---|---|
| User gave motion but no BP prefix (e.g. "universities should ban AI") | Ask once: "Should I treat this as **THW ban AI in universities**, or is it a different format?" Default to THW if no reply. |
| Motion is in Chinese / another debate format (WSDC, AP, Public Forum, 中国辩论) | Tell the user: this skill is BP-specific. Offer to (a) convert the motion to BP framing, or (b) decline and recommend they use a format-appropriate skill. |
| Motion is incomplete / ambiguous ("something about immigration") | Do NOT invent a motion. Ask the user to provide the exact wording. |
| User pasted multiple motions | Pick the most complete one and confirm: "Analyzing motion #1: '[text]'. Run the others after, or pick a different one?" |
| Motion uses a rare actor (e.g. "This House, as the Iroquois Confederacy…") | Proceed, but in Step A flag that actor knowledge is thin; lean on principled reasoning over empirical claims. |
| Motion seems to have a **missing infoslide** (references a specific event/policy without context) | Ask once: "Is there an infoslide for this?" before proceeding. |

Only proceed to Step 1 once the motion is unambiguous.

### Step 1: Read References

Before generating anything, read the relevant reference files:

```
references/framework.md     — The full A-through-H analytical structure
references/motion-types.md  — Rules for THW, THBT, THS, THR, THP, actor motions
references/html-template.md — The HTML/CSS template to use for output
```

Always read `framework.md` first, then `motion-types.md` to identify the specific motion type, then `html-template.md` before writing any HTML.

### Step 2: Identify Motion Type

Using the rules in `motion-types.md`, classify the motion:
- **THW** → Policy motion (Gov has fiat, model required)
- **THBT [X] should [Y]** where X is an actor → Policy motion from actor's perspective
- **THBT [statement]** → Analysis motion (no model, no fiat)
- **THS/THO** → Support/Oppose (no fiat, evaluate probable outcomes)
- **THP** → Preference (Opp bound to defend specific comparison)
- **THR** → Regret (backward-looking, counterfactual required)
- **Actor motions** → Evaluate from actor's values/interests/duties

The motion type determines burdens, fiat powers, and what teams must prove.

**Checkpoint 1 — Classification confirmation**:
State your classification to the user in one line before proceeding:
> "Reading this as a **[TYPE]** motion. Gov fiat = [yes/no]. Counterfactual required = [yes/no]. Actor perspective = [yes/the actor named]. Proceeding unless you correct me."

Wait 1 short turn for the user to correct. If the user stays silent or affirms, continue. If they correct, restart Step 2 with their classification. This prevents 30+ minutes of analysis built on the wrong motion type.

### Step 3: Check for Infoslide

If the user provides an infoslide with the motion:
- Include it prominently in the output
- Evaluate it against the five infoslide checks (necessary? true? argument-feeding? clear? sufficient?)
- Note its implications for the debate in the analysis

### Step 4: Research

Use the `WebSearch` tool (or `WebFetch` for specific URLs) to fact-check and find real-world examples. Run **3–6 targeted searches**, each on one of:
- Key factual claims that arguments might rely on
- Historical precedents and case studies
- Statistics and data points (prefer primary sources: OECD, World Bank, Pew, academic papers)
- Counterexamples that challenge intuitive positions

Aim for 6–10 verified examples that support arguments on both sides. If a search returns nothing usable after 2 reformulations, mark the claim as "unverified — use cautiously" in Step G rather than fabricating a source.

### Step 5: Generate the Analysis

Follow the structure in `framework.md` exactly. The analysis must contain ALL of these sections:

**Step A: What the Motion Is About**
- A.1 Motion Type (classify using motion-types.md)
- A.2 Core Controversy (identify 2-3 deep tensions)
- A.3 Key Stakeholders (table format)
- A.4 Counterfactual / Status Quo

**Step B: Exclusive Strategies and Winning Approaches**
- B.1 Opening Government (OG) — model, core strategy, pre-emption
- B.2 Opening Opposition (OO) — core strategy, counter-prop options, rebuttal targets
- B.3 Closing Government (CG) — extension opportunities (list 3-4)
- B.4 Closing Opposition (CO) — extension opportunities (list 3-4)
- Summary box at the end

**Step C: Mapping the Burdens**
- C.1 Motion-Implied Burdens (table: side, burden, what must be proved)
- C.2 Analysis-Created Burdens (likely to emerge during debate)
- C.3 Likely Weighing Frameworks (table: framework, likely advocated by, how it reshapes burdens)

**Step D: Effective Framing**
- D.1 Government Framing Options (3 named frames with explanation)
- D.2 Opposition Framing Options (3 named frames with explanation)

**Step E: Position-Specific Arguments**
- E.1 Government Arguments (2-4 arguments, each assigned to OG or CG)
- E.2 Opposition Arguments (2-4 arguments, each assigned to OO or CO)
- Each argument uses AREIC or CMILC framework (see framework.md)
- Each argument has a position label: "Best for OG", "Best for CG Extension", etc.

**Step F: Tournament Room Simulation**
- F.1 Novice Room (likely approaches, probable ranking, key pitfall)
- F.2 Intermediate Room (likely approaches, probable ranking, key pitfall)
- F.3 Advanced Room (likely approaches, probable ranking, key pitfall)

**Step G: Real-Life Examples**
- Table with columns: Example, Key Facts, Supports Which Argument, How to Deploy
- 6-10 fact-checked examples

**Step H: Balance Evaluation**
- H.1 Rule of Five Assessment (table format)
- H.2 Top Half vs. Bottom Half Bias
- H.3 Bench Bias (double burdens, silver bullets, reality bias, motion breakers)
- H.4 Clarity Assessment (+ infoslide evaluation if applicable)
- H.5 Accessibility Assessment
- H.6 Overall Assessment (balance, depth, clarity, accessibility, extension potential, recommended placement)

**Checkpoint 2 — Pre-HTML spot check**:
Before generating the full HTML (which is long), deliver a **1-screen preview** in chat:
- Motion type + status quo (2 sentences)
- 4 one-line position summaries (OG / OO / CG / CO)
- Top 3 framing ideas (one per bench side) in a single line each
- Top 3 examples you plan to use

Ask: "Ship HTML on this basis, or adjust?" Continue to Step 6 only after explicit go-ahead (or if user already said "just build it" at the start).

### Step 6: Build the HTML

Using the template in `html-template.md`, generate a single self-contained HTML file. Key requirements:

- ALL CSS must be inline in a `<style>` tag (no external dependencies)
- Use the exact color scheme and typography from the template
- Every major section (A through H) must be a collapsible `<details>` element
- Arguments must be in styled boxes with position-color coding (green for Gov, red for Opp)
- Tables must be responsive and styled consistently
- Include a print-friendly `@media print` stylesheet
- The file must render correctly when opened directly in a browser

### Step 7: Save and Present

Save the HTML file using the `Write` tool to one of these locations (in priority order):

1. If the user specified an output path in their request → use that
2. If a project/working directory is obvious from conversation context → save there
3. Otherwise → ask the user for a save location before writing (do NOT write to a guessed path)

Filename convention:
```
Motion_Analysis_[SHORT_MOTION_DESCRIPTION].html
```

After writing, tell the user the absolute path and offer to open the file in a browser (they can use `start filename.html` on Windows or `open filename.html` on macOS).

**Do NOT use**: `/mnt/user-data/outputs/` (claude.ai-only path) or `present_files` (claude.ai-only tool). These do not exist in Claude Code / CLI environments.

## Argument Frameworks

### AREIC (Assertion–Reasoning–Evidence–Importance–Comparison)
Best for principled/normative arguments. Structure:
- **Assertion**: The core claim
- **Reasoning**: Why it's true (logical/moral reasoning)
- **Evidence**: Real-world support
- **Importance**: Why this matters to the debate
- **Comparison**: Why this outweighs opposing arguments

### CMILC (Claim–Mechanism–Impact–Link–Comparison)
Best for consequentialist/empirical arguments. Structure:
- **Claim**: What you're arguing
- **Mechanism**: The causal chain
- **Impact**: Who is affected and how severely
- **Link**: How this connects to the team's burden
- **Comparison**: Why this matters more than the other side's points

## Quality Standards

- Arguments must be genuinely position-specific (not generic "Gov/Opp" but specific to OG/OO/CG/CO)
- CG and CO arguments must be genuine extensions (not repetitions of top-half material)
- Examples must be fact-checked via web search
- The balance evaluation must be honest — if the motion has a tilt, say so
- Tournament simulations must be realistic about how different skill levels debate
- The counterfactual (for THR) or status quo must be clearly described
- Infoslide evaluation must be rigorous if an infoslide is provided

## Edge Cases & Fallbacks

- **Search returns nothing usable**: After 2 query reformulations, label the claim "unverified" in Step G. Never fabricate a statistic, study, or quotation to fill the table.
- **Motion type is genuinely ambiguous** (e.g. a THBT statement that could read as either policy or analysis): In Step A.1, present both readings and ask the user to pick. Do not silently choose.
- **User wants only a subset** (e.g. "just give me OG arguments"): Skip Steps B.2–B.4, C, F, H. Still do A (motion understanding) and the requested subset of E. Deliver as lighter HTML or plain markdown per user preference.
- **Running out of context mid-analysis**: Save what you have to a partial HTML file, warn the user, and list which sections remain. Do not truncate silently.
- **Non-standard motion**: If the motion has unusual structure (sub-clauses, conditional phrasing, multiple actors), dedicate 1 paragraph in Step A.1 to parsing the structure before classifying. Err on the side of explicitness.

## Common Pitfalls to Avoid

- Don't generate generic arguments that could apply to any motion
- Don't assign CG/CO arguments that are just "deeper versions" of OG/OO — they must be genuinely new material
- Don't assume a utilitarian framework — let the framework clash emerge naturally
- Don't evaluate balance based on personal views — use the Madrid AdjCore criteria
- Don't skip the tournament simulation — it's a distinctive feature of this analysis
- Don't forget to fact-check examples via web search before including them
