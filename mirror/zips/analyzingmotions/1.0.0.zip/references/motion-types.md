# Motion Types — WUDC Rules Reference

Derived from the WUDC Sofia 2026 Rules Manual (Sections 2.6–2.7, 2.9–2.12).

---

## Policy Motions

### THW (This House Would [do X])
- Government argues they should enact policy X
- **Government has fiat**: the policy WILL be implemented as described
- Debate is purely normative: should we do X?
- "The government would never do this" is NOT a valid Opposition argument
- Government controls the model (how policy is implemented) but NOT reactions to it
- Opposition may: defend status quo, propose counter-prop, or argue the policy makes things worse

### THBT [X] should [Y] (where X is an actor, Y is an action)
- Policy motion from actor X's perspective
- Government has fiat to model HOW X does Y
- Opposition has fiat for counter-propositions
- Fiat is limited to things within the actor's power
- Arguments evaluated from a neutral observer's perspective (NOT an actor motion unless infoslide says "You are...")

### Counter-Propositions (Opposition only, policy motions only)
- Must be mutually exclusive with Government's policy
- Must use same or fewer resources (of each type) as Government's model
- Must be in the same broad policy area
- Only the LO may set out a counter-proposition
- Alters the comparative: all teams now compare Gov policy vs. counter-prop (not vs. status quo)

---

## Analysis Motions

### THBT [statement] (This House Believes That)
- Government argues the statement is TRUE; Opposition argues it is NOT TRUE
- NO model, NO fiat for either side
- Government should define terms but is not proposing a policy
- Example: "THBT there is no moral obligation to follow the law" — debate whether the statement is true

### THS / THO (This House Supports / Opposes [X])
- Teams must support or oppose X **in totality** as it manifests in the world
- NO fiat for either side — neither can dictate how X manifests
- Government (THS): X does more good than harm
- Opposition (THS): X does more harm than good
- Teams cannot cherry-pick only favourable/unfavourable aspects
- Government can argue X is LIKELY to happen in a certain way, but this is open to challenge

### THP (This House Prefers [X to Y])
- Government: X is preferable to Y
- **Opposition is BOUND to defend Y** (or status quo if no Y is named)
- Opposition cannot argue for a third option
- "THP a world in which X": Government envisions alternative world; arguments about transitions are NOT permissible; retrocausality arguments NOT permissible
- The counterfactual world exists by fiat — teams don't explain how it came about
- Use common sense for the divergence point

### THR (This House Regrets [X])
- Would the ABSENCE of X have been good for the world?
- Backward-looking: consider past harms/benefits with hindsight
- Teams must describe a **counterfactual** — how the world would have developed without X
- Government regrets X (world would be better without it)
- Opposition does not regret X (X has been net positive or at least not regrettable)
- "The rise of" = the development of the trend up until the debate, NOT future growth

### This House Predicts [X]
- Teams prove X WILL or WILL NOT happen
- No burden to prove the outcome is good or morally desirable
- Judges evaluate persuasiveness about likelihood, not desirability

---

## Actor Motions

### TH, as [A], would do [X]
- Evaluate from the ACTOR'S OWN PERSPECTIVE (values, interests, duties)
- What the actor SHOULD do ≠ what the actor is LIKELY to do
- Actors are NOT assumed to be purely self-interested
- Actors hold some values more firmly than others
- Any information teams present = information the actor becomes aware of
- Actor is fully capable of reasoning, free from manipulation
- Groups as actors: OG has definitional fiat over who is included in the group

### Alternative formulation
- "THW [do X]" + infoslide describing "You are a..." = actor motion
- "TH, as [A], supports/believes/prefers [X]" = analysis motion rules for setup, but actor motion rules for argument evaluation

---

## Definitions and Models (Section 2.9)

### OG's Definitional Fiat
- OG defines what the words in the motion mean
- The debate is about the motion AS DEFINED BY OG
- Definitions are not subject to "likelihood analysis"
- Definition should be at the level of generality implied by the motion
- NOT legitimate to include only marginal/extreme cases
- NOT legitimate to restrict to a specific time or place (unless motion specifies)
- Should be set in the present day

### Squirrelling
A definition is invalid if:
- It is literally inconsistent with the words of the motion
- It is not debatable (unfairly limits scope)

### Vague Definitions
- A vague definition is NOT an invalid definition
- It undermines OG's persuasiveness to the degree things are unclear
- Opposition should identify the vagueness and its impact
- Opposition may infer reasonable consequences but may NOT replace the definition

### Challenging the Definition
- Must be done during LO's speech
- Only grounds: squirrelling or unfair time/place restriction
- NOT enough that the definition "wasn't expected" or "isn't in the spirit"
- LO can: (a) complain but debate it anyway, or (b) challenge and redefine

---

## Role Fulfilment (Sections 2.8, 2.11, 2.12)

### All speakers must:
- Be consistent with their partner and their bench's opening team
- Take at least one POI and offer POIs regularly
- Speak within the time frame

### PM must:
- Ensure the debate is adequately defined
- Present the model (if policy motion)

### Member speakers (MG, MO) must:
- EXTEND the debate with genuinely new material
- Extensions can be: new arguments, new rebuttals, new examples, new characterisations, new framing, new analysis of existing arguments, new weighing criteria
- Closing teams are credited ONLY for contributions beyond what opening said
- Closing teams do NOT win merely by "having an extension"

### Whip speakers (GW, OW):
- May make new contributions that are responsive or that add to member's material
- May NOT introduce entirely new non-responsive material that significantly alters the case direction
- May: new defences, new explanations, new examples, new weighing, new framing

### Knifing
- Closing teams MUST be consistent with their opening teams
- Rare exceptions: opening conceded the debate, opening made a strategic concession solely to bind closing, opening squirrelled, opening made a clearly false factual statement
- Proposing a different weighing metric is NOT usually a knife

---

## The Ordinary Intelligent Voter (Section 2.2)

The standard by which judges assess persuasiveness:
- Knowledge of someone who regularly reads major international newspapers
- Does NOT have specialist knowledge or technical jargon
- Comes from NOWHERE — no "domestic examples" requiring less explanation
- Open-minded, no preformed views on the topic
- Not convinced by sophistry, deception, or logical fallacies
- Intelligent enough to understand complex arguments WHEN EXPLAINED
- Constrained to material presented unless it patently contradicts common knowledge

Judges should:
- Be aware of basic global facts
- Be familiar with sustained international headline issues
- Avoid utilising personal specialist knowledge
- Avoid preferencing particular styles or accents
- Assess merits separate from personal perspectives
