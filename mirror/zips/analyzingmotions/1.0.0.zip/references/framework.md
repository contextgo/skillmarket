# BP Motion Analysis Framework — Complete Reference

This document contains the full analytical structure for a BP motion analysis, derived from the WUDC Sofia 2026 Rules Manual and the Madrid EUDC 2021 AdjCore Motion Setting and Evaluating guide.

## Table of Contents
1. Step A: What the Motion Is About
2. Step B: Exclusive Strategies
3. Step C: Burdens
4. Step D: Framing
5. Step E: Position-Specific Arguments
6. Step F: Tournament Simulation
7. Step G: Real-Life Examples
8. Step H: Balance Evaluation

---

## 1. Step A: What the Motion Is About

### A.1 Motion Type
Classify using the rules in `motion-types.md`. The motion type determines:
- Whether Government has fiat (policy motions: yes; analysis/regret: no)
- Whether Opposition can counter-prop (policy motions only)
- What burdens each side faces
- Whether a counterfactual is needed (THR motions)
- Whether teams argue from an actor's perspective (actor motions)

### A.2 Core Controversy
Identify 2-3 deep tensions the motion raises. Frame these as genuine disagreements where reasonable people differ. Common tension types:
- **Normative tension**: Is X right or wrong? (values clash)
- **Empirical tension**: Does X cause Y? (factual dispute)
- **Strategic tension**: Even if X is right, is this the best way to achieve it?
- **Definitional tension**: What does the key term in the motion actually mean?

### A.3 Key Stakeholders
Create a table listing 5-7 stakeholders with columns:
- Stakeholder (who they are)
- Interests / Perspective (what they care about)
- Likely Side (Government, Opposition, or Contested)

### A.4 Counterfactual / Status Quo
Describe:
- The **status quo**: what the world currently looks like with respect to the motion
- The **counterfactual** (for THR) or **proposed change** (for THW): what the alternative world looks like
- What the debate is comparing: status quo vs. proposed policy, or status quo vs. counterfactual world

---

## 2. Step B: Exclusive Strategies

For each position, identify:

### B.1 Opening Government (OG)
- **Model** (if policy motion): What specific policy is being proposed? How is it implemented?
- **Core strategy**: What is the strongest principled or empirical case?
- **Pre-emption**: What is Opposition's strongest argument, and how should OG address it proactively?

### B.2 Opening Opposition (OO)
- **Core strategy**: What is the strongest line of opposition?
- **Counter-proposition** (if applicable): What alternative does OO propose?
- **Key rebuttal target**: Which part of Government's case is most vulnerable?

### B.3 Closing Government (CG)
- **Extension opportunities**: List 3-4 genuinely new arguments or analytical dimensions CG can introduce. These must be:
  - Weighable as debate-winning (not trivial additions)
  - Independent from OG's material (not just "deeper" versions)
  - Non-contradicting with OG's case
  - At a similar level of analytical difficulty to OG's arguments

### B.4 Closing Opposition (CO)
- **Extension opportunities**: Same criteria as CG. List 3-4 options.

End with a **summary box** stating each position's core strategy in one sentence.

---

## 3. Step C: Burdens

### C.1 Motion-Implied Burdens
Create a table with columns: Side | Burden | What Must Be Proved

For Government, list 2-3 specific things they must prove.
For Opposition, list 2-3 alternatives (connected by OR, not AND — Opposition can win by proving any one).

**Critical note**: Government does NOT need to prove their proposal is risk-free. Opposition does NOT need to defend the status quo as perfect. State what each side does and does not need to prove.

### C.2 Analysis-Created Burdens
List 3-4 conditional burdens that emerge from specific argumentative choices:
- "If Government argues X, they take on a burden to show Y"
- "If Opposition proposes Z, they take on a burden to show W"

### C.3 Likely Weighing Frameworks
Create a table: Framework | Likely Advocated By | How It Reshapes Burdens

Per the WUDC Manual: judges should NOT assume a utilitarian framework. The framework clash is often the most important issue in the debate.

---

## 4. Step D: Framing

### D.1 Government Framing Options
Provide 3 named frames, each with a short name and 3-4 sentence explanation of how it reshapes the debate.

### D.2 Opposition Framing Options
Same format. 3 named frames.

Good frames share these properties:
- They make the team's strongest argument the central issue in the debate
- They make the opposing team's strongest argument less relevant
- They are intuitive to the Ordinary Intelligent Voter
- They can be stated in one sentence

---

## 5. Step E: Position-Specific Arguments

### Argument Assignment Rules
- **OG** gets the foundational case: the core principled argument and/or the primary empirical argument
- **OO** gets the core opposition: the strongest principled rebuttal and/or the primary counter-case
- **CG** gets extensions that go BEYOND OG: new analytical dimensions, new mechanisms, new stakeholder impacts, new frameworks
- **CO** gets extensions that go BEYOND OO: systemic/structural arguments, historical precedent, meta-arguments about methodology

### Each argument must include:
1. **Position label**: "Best for OG", "Best for CG Extension", etc.
2. **Framework label**: AREIC or CMILC
3. **Title**: A descriptive name for the argument
4. **All 5 fields** of the chosen framework, each with substantive content (3-6 sentences minimum)

### Quality checks for arguments:
- Could this argument plausibly win the round if it's the team's strongest contribution? If not, it's too weak.
- Is this argument genuinely new relative to the position above it on the same bench? If CG's argument is just OG's argument with more detail, it fails.
- Does the argument engage with the specific motion, or could it apply to any debate? If generic, rewrite.
- Are the evidence and examples fact-checked? If citing specific claims, verify via web search.

---

## 6. Step F: Tournament Room Simulation

For each of three room types (Novice, Intermediate, Advanced), provide:

### Structure per room:
- **Likely OG approach**: What will OG probably run? Where will they be strong/weak?
- **Likely OO approach**: Same.
- **Likely CG approach**: Will they find a genuine extension or be derivative?
- **Likely CO approach**: Same.
- **Probable ranking**: The most likely result (e.g., "OO > CG > OG > CO") with a brief explanation of why.
- **Key pitfall**: The single most common mistake teams at this level will make with this motion.

### Room type profiles:
- **Novice**: Arguments from first principles, limited examples, likely to mishandle motion type mechanics (e.g., treating THR as THW), shallow engagement with framework clashes
- **Intermediate**: Correct motion type handling, reasonable examples, some framework engagement, extensions that are genuine but may lack depth
- **Advanced**: Sophisticated framework arguments, precise mechanism work, strong weighing, creative extensions, deep engagement with the counterfactual/status quo

---

## 7. Step G: Real-Life Examples

Create a table with columns:
- **Example**: Short name
- **Key Facts**: 2-3 sentence factual summary (must be verified via web search)
- **Supports Which Argument**: Reference by argument number (G1, O2, etc.)
- **How to Deploy**: One sentence on how to use it in a speech

Aim for 6-10 examples. Include examples that support both sides. Mark any example that supports both sides as "Both sides" and explain.

---

## 8. Step H: Balance Evaluation

### H.1 Rule of Five Assessment
Table with rows: Five arguments? | Weighable? | Independent? | Non-contradicting? | Similar complexity? | Similar accessibility?
Columns: Criterion | Government | Opposition
End with a verdict: PASS or FAIL with explanation.

The "upgrade" test: Do the 5 arguments span at least 3 different clashes?

### H.2 Top Half vs. Bottom Half Bias
- Do CG and CO have accessible, weighable, independent extensions?
- Are extensions at similar analytical difficulty to top-half arguments?
- Is there definition-proofing risk (can OG's setup shut out CG)?

### H.3 Bench Bias
Check each:
- **Double burdens**: Does one side need to win all clashes while the other needs only one? Watch for "and", "or", "all", "never", "always".
- **Silver bullets**: Is there an argument so strong it overrides everything?
- **Reality bias**: Is this just obviously good/bad once you have fiat?
- **Motion breakers**: Can a sneaky team exploit a loophole to make it unwinnable?
- **Repeated motion risk**: Has this been set too recently?

### H.4 Clarity Assessment
- Is the actor well-defined (if applicable)?
- Are all key terms commonly understood across cultures?
- Is the counterfactual (for THR) analyzable?
- Infoslide evaluation (if provided): Pass the 5 checks (necessary? true? argument-feeding? clear? sufficient?)

### H.5 Accessibility Assessment
- Can a team that knows nothing argue from first principles?
- Is specialist knowledge required?
- Is an infoslide needed?

### H.6 Overall Assessment
Provide verdicts on:
- **Balance**: Good/Fair/Poor + explanation
- **Depth**: Excellent/Good/Fair + Rule of Five result
- **Clarity**: Good/Fair/Poor + specific concerns
- **Accessibility**: Excellent/Good/Moderate/Poor
- **Extension potential**: Strong/Moderate/Weak for each position
- **Recommended placement**: Which round(s) and tournament level this motion is best suited for, with reasoning

End with a closing note: "This document provides a comprehensive analytical foundation for debating, judging, or setting this motion."
