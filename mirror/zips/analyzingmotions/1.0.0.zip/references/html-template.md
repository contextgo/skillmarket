# HTML Template Reference

Use this template structure and styling for all motion analysis HTML output. The entire document must be a single self-contained HTML file with no external dependencies.

## Document Structure

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Motion Analysis: [MOTION_TEXT]</title>
  <style>
    /* === PASTE FULL CSS BELOW === */
  </style>
</head>
<body>
  <header class="doc-header">
    <h1>Motion Analysis</h1>
    <p class="subtitle">British Parliamentary Format — Position-Specific Framework</p>
    <div class="motion-box">
      <span class="motion-label">Motion:</span>
      <span class="motion-text">[FULL MOTION TEXT]</span>
    </div>
    <!-- If infoslide exists: -->
    <div class="infoslide-box">
      <strong>Infoslide:</strong> [INFOSLIDE TEXT]
    </div>
  </header>

  <nav class="toc">
    <h2>Contents</h2>
    <ul>
      <li><a href="#step-a">Step A: What the Motion Is About</a></li>
      <li><a href="#step-b">Step B: Strategies</a></li>
      <li><a href="#step-c">Step C: Burdens</a></li>
      <li><a href="#step-d">Step D: Framing</a></li>
      <li><a href="#step-e">Step E: Arguments</a></li>
      <li><a href="#step-f">Step F: Tournament Simulation</a></li>
      <li><a href="#step-g">Step G: Examples</a></li>
      <li><a href="#step-h">Step H: Balance Evaluation</a></li>
    </ul>
  </nav>

  <!-- Each step is a <details> element for collapsibility -->
  <details open id="step-a">
    <summary><h2>Step A: What the Motion Is About</h2></summary>
    <div class="section-content">
      <!-- Subsections use <h3> tags -->
    </div>
  </details>

  <!-- Repeat for steps B through H -->

  <footer class="doc-footer">
    <p>Prepared using the WUDC Sofia 2026 Rules Manual & Madrid EUDC 2021 AdjCore Motion Evaluation Framework</p>
  </footer>
</body>
</html>
```

## Complete CSS

Use this exact CSS in every output:

```css
/* Reset and Base */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Arial, sans-serif;
  line-height: 1.7; color: #2c3e50; background: #f8f9fa;
  max-width: 900px; margin: 0 auto; padding: 20px;
}

/* Header */
.doc-header {
  text-align: center; padding: 40px 20px 30px;
  border-bottom: 4px solid #1B4F72; margin-bottom: 30px;
}
.doc-header h1 { font-size: 2.4em; color: #1B4F72; margin-bottom: 5px; }
.subtitle { font-size: 1.1em; color: #2E75B6; margin-bottom: 25px; }
.motion-box {
  background: #eaf2f8; border-left: 5px solid #1B4F72;
  padding: 15px 20px; margin: 20px auto; max-width: 750px; text-align: left;
  border-radius: 0 8px 8px 0;
}
.motion-label { font-weight: 700; color: #1B4F72; }
.motion-text { font-style: italic; font-size: 1.1em; color: #1B4F72; }
.infoslide-box {
  background: #fef9e7; border-left: 5px solid #8B6914;
  padding: 15px 20px; margin: 15px auto; max-width: 750px; text-align: left;
  border-radius: 0 8px 8px 0; font-size: 0.95em;
}

/* Table of Contents */
.toc {
  background: white; border: 1px solid #ddd; border-radius: 8px;
  padding: 20px 30px; margin-bottom: 30px;
}
.toc h2 { font-size: 1.2em; color: #1B4F72; margin-bottom: 10px; }
.toc ul { list-style: none; }
.toc li { margin: 6px 0; }
.toc a { color: #2E75B6; text-decoration: none; font-weight: 500; }
.toc a:hover { text-decoration: underline; }

/* Collapsible Sections */
details {
  background: white; border: 1px solid #ddd; border-radius: 8px;
  margin-bottom: 20px; overflow: hidden;
}
details > summary {
  cursor: pointer; padding: 15px 20px; background: #f0f4f8;
  border-bottom: 1px solid #ddd; list-style: none;
}
details > summary::-webkit-details-marker { display: none; }
details > summary::before {
  content: '▶ '; color: #2E75B6; font-size: 0.8em; transition: transform 0.2s;
}
details[open] > summary::before { content: '▼ '; }
details > summary h2 {
  display: inline; font-size: 1.4em; color: #1B4F72; margin: 0;
}
.section-content { padding: 20px 25px; }

/* Headings inside sections */
h3 { font-size: 1.15em; color: #2E75B6; margin: 25px 0 10px; }
h4 { font-size: 1.05em; color: #34495e; margin: 15px 0 8px; }

/* Paragraphs */
p { margin-bottom: 12px; }

/* Summary Box */
.summary-box {
  background: #eaf2f8; border: 2px solid #2E75B6; border-radius: 8px;
  padding: 15px 20px; margin: 20px 0;
}
.summary-box strong { color: #1B4F72; }

/* Argument Boxes */
.arg-box {
  border-radius: 8px; padding: 20px; margin: 20px 0;
  border: 1px solid #ddd; border-left: 6px solid;
}
.arg-box.gov { border-left-color: #27ae60; background: #f0faf3; }
.arg-box.opp { border-left-color: #c0392b; background: #fdf0ef; }
.arg-box .arg-title {
  font-size: 1.1em; font-weight: 700; margin-bottom: 5px;
}
.arg-box.gov .arg-title { color: #1e8449; }
.arg-box.opp .arg-title { color: #a93226; }
.arg-box .arg-position {
  font-style: italic; color: #666; font-size: 0.9em; margin-bottom: 12px;
}
.arg-box .arg-field { margin-bottom: 10px; }
.arg-box .arg-field-label {
  font-weight: 700; color: #34495e; display: inline;
}

/* Tables */
table {
  width: 100%; border-collapse: collapse; margin: 15px 0;
  font-size: 0.95em;
}
th {
  background: #1B4F72; color: white; padding: 10px 12px;
  text-align: left; font-weight: 600;
}
td { padding: 10px 12px; border-bottom: 1px solid #ddd; vertical-align: top; }
tr:nth-child(even) { background: #f8f9fa; }
tr:hover { background: #eaf2f8; }

/* Simulation Boxes */
.sim-room {
  border: 1px solid #ddd; border-radius: 8px; padding: 20px;
  margin: 15px 0; background: white;
}
.sim-room h4 { margin-top: 0; }
.sim-room .sim-label {
  font-weight: 700; color: #1B4F72; display: inline;
}
.sim-ranking {
  background: #eaf2f8; border-radius: 6px; padding: 10px 15px;
  margin: 10px 0; font-weight: 600;
}
.sim-pitfall {
  background: #fef9e7; border-radius: 6px; padding: 10px 15px;
  margin: 10px 0; border-left: 4px solid #f39c12;
}

/* Verdict Boxes */
.verdict {
  background: #eaf2f8; border: 2px solid #1B4F72; border-radius: 8px;
  padding: 20px; margin: 20px 0;
}
.verdict h4 { color: #1B4F72; margin-top: 0; }
.verdict .pass { color: #27ae60; font-weight: 700; }
.verdict .fail { color: #c0392b; font-weight: 700; }
.verdict .mild-concern { color: #e67e22; font-weight: 600; }

/* Frame Boxes */
.frame-box {
  background: white; border: 1px solid #ddd; border-radius: 8px;
  padding: 15px 20px; margin: 12px 0;
}
.frame-box .frame-name { font-weight: 700; color: #1B4F72; font-size: 1.05em; }

/* Footer */
.doc-footer {
  text-align: center; padding: 20px; margin-top: 30px;
  border-top: 2px solid #ddd; color: #999; font-size: 0.85em;
}

/* Print Styles */
@media print {
  body { background: white; max-width: 100%; padding: 0; font-size: 11pt; }
  details { border: none; break-inside: avoid; }
  details > summary { background: none; border-bottom: 2px solid #1B4F72; }
  details[open] > summary + .section-content { page-break-before: auto; }
  .toc { page-break-after: always; }
  .arg-box { break-inside: avoid; }
  table { font-size: 9pt; }
  .doc-footer { border-top: 1px solid #ccc; }
  a { color: inherit; text-decoration: none; }
}

/* Responsive */
@media (max-width: 600px) {
  body { padding: 10px; }
  .doc-header h1 { font-size: 1.8em; }
  .section-content { padding: 15px; }
  table { font-size: 0.85em; }
  th, td { padding: 6px 8px; }
}
```

## Component Patterns

### Argument Box (Government)
```html
<div class="arg-box gov">
  <div class="arg-title">ARGUMENT G1: [Title] (AREIC)</div>
  <div class="arg-position">Best for OG</div>
  <div class="arg-field"><span class="arg-field-label">Assertion:</span> [text]</div>
  <div class="arg-field"><span class="arg-field-label">Reasoning:</span> [text]</div>
  <div class="arg-field"><span class="arg-field-label">Evidence:</span> [text]</div>
  <div class="arg-field"><span class="arg-field-label">Importance:</span> [text]</div>
  <div class="arg-field"><span class="arg-field-label">Comparison:</span> [text]</div>
</div>
```

### Argument Box (Opposition)
```html
<div class="arg-box opp">
  <!-- Same structure but with class="opp" -->
</div>
```

### Simulation Room
```html
<div class="sim-room">
  <h4>F.1 Novice Room</h4>
  <p><span class="sim-label">Likely OG approach:</span> [text]</p>
  <p><span class="sim-label">Likely OO approach:</span> [text]</p>
  <p><span class="sim-label">Likely CG approach:</span> [text]</p>
  <p><span class="sim-label">Likely CO approach:</span> [text]</p>
  <div class="sim-ranking"><span class="sim-label">Probable ranking:</span> [text]</div>
  <div class="sim-pitfall"><span class="sim-label">Key pitfall:</span> [text]</div>
</div>
```

### Frame Box
```html
<div class="frame-box">
  <div class="frame-name">Frame 1: The [Name] Frame</div>
  <p>[3-4 sentence explanation]</p>
</div>
```

### Verdict Box
```html
<div class="verdict">
  <h4>Overall Motion Evaluation</h4>
  <p><strong>Balance:</strong> <span class="pass">Good.</span> [explanation]</p>
  <p><strong>Depth:</strong> <span class="pass">Excellent.</span> [explanation]</p>
  <!-- etc. -->
</div>
```

### Stakeholder Table
```html
<table>
  <thead>
    <tr><th>Stakeholder</th><th>Interests / Perspective</th><th>Likely Side</th></tr>
  </thead>
  <tbody>
    <tr><td>[who]</td><td>[what they care about]</td><td>[Gov/Opp/Contested]</td></tr>
  </tbody>
</table>
```

## File Naming Convention

Save all output files as:
```
Motion_Analysis_[SHORT_DESCRIPTION].html
```
Examples:
- `Motion_Analysis_THW_Ban_Beauty_Pageants.html`
- `Motion_Analysis_THR_Rise_of_Satirical_Journals.html`
- `Motion_Analysis_THBT_Feminist_Movement_Beauty_Pageants.html`

## Rendering Notes

- ALL sections (Steps A-H) should start as `<details open>` so the full document is visible on load
- The Table of Contents uses anchor links to each `<details>` section's `id`
- Arguments are color-coded: green-left-border for Government, red-left-border for Opposition
- Tables alternate row colors for readability
- The document should look professional and publication-ready when printed
- Mobile responsiveness is required (the `@media (max-width: 600px)` queries handle this)
- No JavaScript is required — the document uses only HTML and CSS
