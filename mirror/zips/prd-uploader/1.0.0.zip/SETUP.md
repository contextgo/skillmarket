# 首次配置（约 5 分钟，全程在浏览器里完成）

只需要做一次。做完之后跟 Claude 说话就能直接上传，**不用打开终端，不用启动任何东西**。

---

## 你需要准备

- **Claude Pro 或 Max 计划** ⚠️
  - 个人版（Pro / Max）才能自己控制 skill 的网络权限
  - 如果你用的是 **Team / Enterprise 计划**，网络权限由组织管理员控制，请联系**你们公司的 Claude 管理员**帮你协调开通
  - 不知道自己是哪个计划？打开 Claude.ai → 头像 → Settings → 看 Plan 那一栏
- 一个 GitHub 账号（没有就免费注册：https://github.com/signup）

**GitHub 完全免费**。原型用项目口令加密保护，所以仓库设为 Public 也不会泄露内容。

---

## 第 0 步：开启 Claude 的网络访问权限 ⚠️

**这一步必须先做，不然 skill 没法连 GitHub**。Claude 默认把 skill 限制在沙盒里只能访问少数几个域名（npm、PyPI 这些），需要把 GitHub API 加到白名单。

> 🔒 我们采用**最小权限**做法 —— 只放开 skill 实际需要的一个域名 `api.github.com`，不开放全网，避免 skill 在沙盒里能访问任意网站。

### 如果你是 Pro / Max 计划

1. 打开 Claude.ai，点左下角头像 → **Settings**（设置）
2. 左侧菜单选 **Capabilities**（能力）
3. 找到 **Code execution and file creation** 区域，确认它**已开启**
4. 在它下面找到 **Allow network egress**（允许网络出站），把开关**打开**
5. 在 **Domain allowlist**（域名白名单）下拉里保持默认的 **Package managers only**（只允许包管理器域名）
6. 在下方 **Additional allowed domains**（额外允许的域名）里**加上一行**：
   ```
   api.github.com
   ```
7. **关键：关掉当前所有对话窗口，开一个全新对话** —— 这个设置只对新对话生效，旧对话不会自动应用

### 如果你是 Team / Enterprise 计划

这个选项会被组织管理员锁定，你自己改不了。**请联系你们公司的 Claude 管理员**，让管理员去 **Organization settings → Capabilities** 在 **Additional allowed domains** 里加上一行：

```
api.github.com
```

管理员改完后你也要**开个新对话**才生效。

### 我们为什么只需要这一个域名

skill 的所有操作只通过 `api.github.com` 完成（读写仓库、列目录、上传文件）。`xxx.github.io`（你的 Pages 链接）是访问者用浏览器去看的，skill 自己不访问；解密在访问者浏览器里本地完成，也不联网。所以一个域名就够了。

### 验证

如果跳过或没生效，skill 会在第一次连 GitHub 时报 `403 Forbidden / x-deny-reason: blocked-by-allowlist` 错误。看到这个错误回来检查这一步即可。

---

## 第 1 步：建一个仓库

1. 打开 https://github.com/new
2. 填写：
   - **Repository name**：`team-prototypes`（或你喜欢的名字）
   - **Description**：随意，比如「团队原型预览」
   - 选 **Public** ✅（原型内容已经加密，公开仓库即可，免费 Pages）
   - 勾选 **Add a README file**
3. 点 **Create repository**

---

## 第 2 步：开启 GitHub Pages

1. 进入刚建的仓库
2. 点击顶部 **Settings**
3. 左边菜单点 **Pages**
4. 在 **Source** 区域：
   - Branch 选 **main**
   - 文件夹选 **/ (root)**
   - 点 **Save**
5. 等 30 秒左右刷新页面，会看到：
   > Your site is live at `https://你的用户名.github.io/team-prototypes/`

   **把这个地址记下来**，后面要用。

---

## 第 3 步：生成访问 Token

1. 打开 https://github.com/settings/tokens?type=beta
2. 点击 **Generate new token**
3. 填写：
   - **Token name**：`prototype-uploader`
   - **Expiration**：建议 **1 year** 或 **No expiration**
   - **Repository access**：选 **Only select repositories** → 选刚建的 `team-prototypes`
   - **Permissions** → **Repository permissions**：
     - 找到 **Contents**，下拉选 **Read and write**
     - **Metadata** 会自动变成 **Read-only**（保持即可）
4. 点 **Generate token**
5. **立刻复制 Token**（只显示一次），形如 `github_pat_xxxxx...`

---

## 第 4 步：告诉 Claude

打开 Claude.ai 新对话，把下面这段贴给 Claude（替换成你的实际信息）：

```
帮我配置原型上传 skill。
- GitHub 用户名: 你的用户名
- 仓库名: team-prototypes
- Pages 地址: https://你的用户名.github.io/team-prototypes
- Token: github_pat_xxxxxxxxxxxxx
```

Claude 会自动写入配置 + 跑健康检查。

---

## 第 5 步：测试一下

跟 Claude 说：

> 帮我生成一个测试 HTML 原型，然后上传一下

Claude 会：
1. 生成 HTML
2. 问你「这是什么项目？」（首次让你新建一个）
3. 问你「给这个项目设个口令吧」（你随便起，比如 `test1234`）
4. 上传成功，给你链接和口令

把链接和口令一起发给你自己（或同事），打开 → 输口令 → 看到原型 ✅

---

## 之后日常使用

聊完原型后说：

> 上传一下

Claude 会自动：
- 列出已有项目让你选 / 创建新项目
- 已有项目会问你口令（验证后才上传）
- 新项目让你设口令
- 加密上传 → 给你链接 + 口令

把链接和口令一起发给同事就行。

✅ 不用打开终端
✅ 不用启动任何服务
✅ 不用记 Git 命令
✅ 关机也不影响（GitHub 托管）

---

## 同事的体验

1. 收到你发的链接 + 口令
2. 浏览器打开链接
3. 弹窗输入口令
4. 看到原型
5. **7 天内**再访问该项目其他原型，浏览器自动放行（不用再输）

---

## 常见问题

**Q: Claude 报错说 `403 Forbidden` 或 `blocked-by-allowlist`？**
A: 沙盒网络被禁了。回 SETUP.md 第 0 步，在 **Additional allowed domains** 里加上 `api.github.com`，然后**开个新对话**再试 —— 旧对话不会自动应用新设置。这是新手最常见的卡点。

**Q: 我已经按第 0 步加了 `api.github.com` 但还是 403？**
A: 99% 的可能是没开新对话。Claude 的网络设置只在新对话生效。把当前对话关掉，从左侧菜单点 "New chat" 重新跟 Claude 说一遍上传需求。

**Q: 我是 Team / Enterprise 计划，Settings 里的网络选项是灰的 / 改不了？**
A: 这是组织管理员设的限制，你自己改不了。请联系**你们公司的 Claude 管理员**去 **Organization settings → Capabilities** 在 **Additional allowed domains** 里加上一行 `api.github.com`。

**Q: 仓库是 Public 的，原型内容真的安全吗？**
A: HTML 内容用 AES-256-GCM 加密（配 PBKDF2 密钥派生），就算有人猜到 URL 拿到加密文件，没口令也只能看到一段乱码。安全级别等同主流密码管理器。

**Q: 我忘了某项目口令怎么办？**
A: 口令只存哈希，无法找回。可以重新设个新口令用于以后上传，但**之前**上传的版本仍然需要旧口令才能解开。

**Q: 上传后多久能访问？**
A: GitHub Pages 部署一般 30-60 秒。点链接显示 404 时等 1 分钟再刷新。

**Q: 在新设备上用 Claude 也能上传吗？**
A: 配置存在云端 skill 沙盒里，新设备登录同一 Claude 账号即可。如果失效了，把第 4 步那段话再发一遍即可。**注意：新设备首次也要确认第 0 步的网络开关已开 + 是新对话**。

**Q: 想换公司内网 CDN，不用 GitHub？**
A: 找开发同学改 `scripts/backends.py`，加一个新 Backend 类即可。skill 的对话流程和加密逻辑都不用变。
