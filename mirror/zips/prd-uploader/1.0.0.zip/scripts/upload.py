#!/usr/bin/env python3
"""
原型上传 CLI。Claude 通过这个脚本与存储后端交互。

子命令:
    health                       检查后端是否可用
    list                         列出所有项目
    versions --project=<name>    列出某项目的所有版本
    has-password --project=<n>   检查项目是否已设口令
    set-password --project=<n> --password=<p>   设置项目口令
    verify-password --project=<n> --password=<p>  校验口令是否对
    upload --project=<n> --password=<p> --html-file=<path> [--note=<...>]
                                 加密并上传一份新原型

输出统一为 JSON。
"""
import argparse
import json
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from backends import get_backend
from crypto_util import verify_password


DEFAULT_CONFIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'config.json')


def load_config(path):
    if not os.path.exists(path):
        raise FileNotFoundError(
            f'找不到配置文件: {path}\n'
            f'请按照 SETUP.md 完成首次配置（创建 config.json）。'
        )
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def emit(obj, success=True):
    print(json.dumps(obj, ensure_ascii=False, indent=2))
    sys.exit(0 if success else 1)


def cmd_health(backend, args):
    result = backend.health_check()
    emit(result, success=result.get('ok', False))


def cmd_list(backend, args):
    emit({'projects': backend.list_projects()})


def cmd_versions(backend, args):
    emit({'project': args.project, 'versions': backend.list_versions(args.project)})


def cmd_has_password(backend, args):
    emit({'project': args.project, 'has_password': backend.has_project_password(args.project)})


def cmd_set_password(backend, args):
    backend.set_project_password(args.project, args.password, author=args.author)
    emit({'success': True, 'project': args.project, 'message': '口令已设置'})


def cmd_verify_password(backend, args):
    record = backend.get_project_password_record(args.project)
    if record is None:
        emit({'project': args.project, 'has_password': False, 'valid': False,
              'message': '该项目还没有口令'}, success=False)
    valid = verify_password(args.password, record)
    emit({'project': args.project, 'has_password': True, 'valid': valid},
         success=valid)


def cmd_meta(backend, args):
    """查询项目的元数据（作者、是否有口令、创建时间）"""
    meta = backend.get_project_meta(args.project)
    emit(meta)


def cmd_set_author(backend, args):
    backend.set_project_author(args.project, args.author)
    emit({'success': True, 'project': args.project, 'author': args.author,
          'message': '作者已更新'})


def cmd_upload(backend, args):
    if not os.path.exists(args.html_file):
        emit({'error': f'找不到文件: {args.html_file}'}, success=False)
    with open(args.html_file, 'r', encoding='utf-8') as f:
        html = f.read()
    result = backend.upload(args.project, html, args.password,
                            author=args.author, note=args.note)
    result['success'] = True
    emit(result)


def main():
    parser = argparse.ArgumentParser(description='原型上传 CLI（带项目口令保护）')
    parser.add_argument('--config', default=DEFAULT_CONFIG)

    sub = parser.add_subparsers(dest='cmd', required=True)
    sub.add_parser('health')
    sub.add_parser('list')

    p = sub.add_parser('versions'); p.add_argument('--project', required=True)
    p = sub.add_parser('has-password'); p.add_argument('--project', required=True)
    p = sub.add_parser('meta'); p.add_argument('--project', required=True)

    p = sub.add_parser('set-password')
    p.add_argument('--project', required=True)
    p.add_argument('--password', required=True)
    p.add_argument('--author', help='可选，同时设置作者')

    p = sub.add_parser('set-author')
    p.add_argument('--project', required=True)
    p.add_argument('--author', required=True)

    p = sub.add_parser('verify-password')
    p.add_argument('--project', required=True); p.add_argument('--password', required=True)

    p = sub.add_parser('upload')
    p.add_argument('--project', required=True)
    p.add_argument('--password', required=True)
    p.add_argument('--html-file', required=True)
    p.add_argument('--author', help='新项目必填；已有项目可省略表示不变')
    p.add_argument('--note')

    args = parser.parse_args()

    try:
        config = load_config(args.config)
        backend = get_backend(config)
    except Exception as e:
        emit({'error': str(e)}, success=False)

    handlers = {
        'health': cmd_health,
        'list': cmd_list,
        'versions': cmd_versions,
        'has-password': cmd_has_password,
        'meta': cmd_meta,
        'set-password': cmd_set_password,
        'set-author': cmd_set_author,
        'verify-password': cmd_verify_password,
        'upload': cmd_upload,
    }
    try:
        handlers[args.cmd](backend, args)
    except Exception as e:
        emit({
            'error': str(e),
            'trace': traceback.format_exc() if os.environ.get('DEBUG') else None,
        }, success=False)


if __name__ == '__main__':
    main()
