"""
原型加密模块。

加密方案：
  - 算法：AES-256-GCM（认证加密，防篡改）
  - Key 派生：PBKDF2-HMAC-SHA256，100,000 轮迭代
  - 每次加密用新的随机 salt(16B) 和 IV(12B)

设计目标：与浏览器 SubtleCrypto.subtle.decrypt 完全兼容。
依赖 cryptography 包（云端沙盒预装）。
"""
import base64
import hashlib
import json
import secrets

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


PBKDF2_ITERATIONS = 100_000


def encrypt_html(html: str, password: str) -> dict:
    """用口令加密 HTML，返回 base64 编码的密文+参数。"""
    salt = secrets.token_bytes(16)
    iv = secrets.token_bytes(12)
    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, PBKDF2_ITERATIONS, dklen=32)
    aesgcm = AESGCM(key)
    # AESGCM.encrypt 返回 ciphertext || tag（GCM tag 16 字节）
    ct_with_tag = aesgcm.encrypt(iv, html.encode('utf-8'), associated_data=None)
    return {
        'ciphertext_b64': base64.b64encode(ct_with_tag).decode('ascii'),
        'salt_b64': base64.b64encode(salt).decode('ascii'),
        'iv_b64': base64.b64encode(iv).decode('ascii'),
        'iterations': PBKDF2_ITERATIONS,
    }


def decrypt_html(encrypted: dict, password: str) -> str:
    """自测用的解密函数（实际访问时由浏览器执行同样逻辑）。"""
    salt = base64.b64decode(encrypted['salt_b64'])
    iv = base64.b64decode(encrypted['iv_b64'])
    ct_with_tag = base64.b64decode(encrypted['ciphertext_b64'])
    iterations = encrypted.get('iterations', PBKDF2_ITERATIONS)
    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations, dklen=32)
    aesgcm = AESGCM(key)
    plaintext = aesgcm.decrypt(iv, ct_with_tag, associated_data=None)
    return plaintext.decode('utf-8')


def hash_password(password: str, salt: bytes = None) -> dict:
    """PBKDF2 哈希一个口令，存到 .passwords.json 里。"""
    if salt is None:
        salt = secrets.token_bytes(16)
    h = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, PBKDF2_ITERATIONS, dklen=32)
    return {
        'hash_b64': base64.b64encode(h).decode('ascii'),
        'salt_b64': base64.b64encode(salt).decode('ascii'),
        'iterations': PBKDF2_ITERATIONS,
    }


def verify_password(password: str, stored: dict) -> bool:
    """验证口令是否匹配存档"""
    salt = base64.b64decode(stored['salt_b64'])
    iterations = stored.get('iterations', PBKDF2_ITERATIONS)
    h = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations, dklen=32)
    return secrets.compare_digest(
        base64.b64encode(h).decode('ascii'),
        stored['hash_b64']
    )


# ============================================================
# 浏览器端解密 HTML 模板
# ============================================================

def make_protected_html(encrypted: dict, project_name: str, version_label: str, author: str = '') -> str:
    """生成包含解密 UI 的 HTML 包装页。"""
    payload = json.dumps({
        'ct': encrypted['ciphertext_b64'],
        'salt': encrypted['salt_b64'],
        'iv': encrypted['iv_b64'],
        'iter': encrypted['iterations'],
        'project': project_name,
        'version': version_label,
    }, ensure_ascii=True)

    template = r"""<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__PROJECT__</title>
<style>
  :root {
    --bg: #ffffff;
    --bg-subtle: #f7f7f8;
    --fg: #0a0a0a;
    --muted: #737373;
    --muted-2: #a3a3a3;
    --border: #e5e5e5;
    --border-strong: #0a0a0a;
    --ring: rgba(10,10,10,.08);
    --danger: #b91c1c;
    --mono: ui-monospace,"SF Mono","JetBrains Mono",Menlo,Consolas,monospace;
  }
  html, body { background: var(--bg); }
  * { box-sizing: border-box; }
  body { margin:0; font-family:-apple-system,BlinkMacSystemFont,"Inter","PingFang SC",
    "Segoe UI",sans-serif; color:var(--fg); min-height:100vh;
    display:flex; align-items:center; justify-content:center;
    padding:24px; -webkit-font-smoothing:antialiased; }
  .card { width:100%; max-width:400px; background:var(--bg);
    border:1px solid var(--border); border-radius:18px; padding:36px 32px 28px;
    text-align:left; }
  .meta-row { display:flex; align-items:center; justify-content:space-between;
    margin-bottom:28px; font-size:11px; color:var(--muted);
    text-transform:uppercase; letter-spacing:.08em; font-family:var(--mono); }
  .meta-row .dot { display:inline-block; width:6px; height:6px; border-radius:50%;
    background:var(--fg); margin-right:8px; vertical-align:1px; }
  h1 { font-size:26px; font-weight:600; margin:0 0 4px;
    letter-spacing:-.02em; line-height:1.2; }
  .sub { color:var(--muted); font-size:13px; margin:0 0 32px; line-height:1.5;
    font-family:var(--mono); }
  .field { margin-bottom:14px; }
  label { display:block; font-size:12px; font-weight:500; color:var(--fg);
    margin-bottom:8px; letter-spacing:-.005em; }
  input { width:100%; padding:12px 14px; border:1px solid var(--border);
    border-radius:12px; font-size:14px; background:var(--bg); color:var(--fg);
    outline:none; transition:border-color .15s, box-shadow .15s;
    font-family:inherit; }
  input::placeholder { color:var(--muted-2); }
  input:focus { border-color:var(--border-strong); box-shadow:0 0 0 4px var(--ring); }
  button { width:100%; padding:13px 16px; border:1px solid var(--border-strong);
    border-radius:14px; background:var(--border-strong); color:var(--bg);
    font-size:14px; font-weight:500; cursor:pointer; font-family:inherit;
    transition:transform .08s, opacity .15s; letter-spacing:-.005em; }
  button:hover { opacity:.9; }
  button:active { transform:scale(.985); }
  button:disabled { opacity:.5; cursor:not-allowed; }
  .err { color:var(--danger); font-size:13px; margin-top:14px; min-height:18px;
    font-family:var(--mono); }
  .author-line { font-size: 12px; color: var(--muted); margin: 0 0 8px;
    font-family: var(--mono); display: flex; align-items: center; gap: 6px; }
  .author-line .label { color: var(--muted-2); }
  .author-line .name { color: var(--fg); font-weight: 500; }
  .footer { margin-top:28px; padding-top:20px; border-top:1px solid var(--border);
    font-size:12px; color:var(--muted); line-height:1.7; font-family:var(--mono); }
  .footer .contact-line { display:block; }
  .footer .contact { color:var(--fg); font-weight:500; }
</style></head>
<body>
<div class="card" id="gate">
  <div class="meta-row">
    <span><span class="dot"></span>已加密</span>
    <span>__VERSION__</span>
  </div>
  <h1>__PROJECT__</h1>
  __AUTHOR_LINE__
  <p class="sub">该原型已加密，请输入项目口令查看。</p>
  <div class="field">
    <label for="pw">项目口令</label>
    <input id="pw" type="password" placeholder="输入口令" autofocus autocomplete="off">
  </div>
  <button id="btn">查看原型</button>
  <div class="err" id="err"></div>
  <div class="footer">
    <div class="contact-line">遇到问题，企微请联系 <span class="contact">yunpeng.wang</span></div>
    <div class="contact-line">微信请联系 <span class="contact">xiaohei-o_o</span></div>
  </div>
</div>
<script>
const PAYLOAD = __PAYLOAD__;
const STORAGE_KEY = 'proto_pw_' + PAYLOAD.project;
const TTL_MS = 7 * 24 * 60 * 60 * 1000;

function b64decode(s) {
  const bin = atob(s); const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

async function deriveKey(password, salt, iterations) {
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey(
    'raw', enc.encode(password), 'PBKDF2', false, ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false, ['decrypt']
  );
}

async function tryDecrypt(password) {
  const salt = b64decode(PAYLOAD.salt);
  const iv = b64decode(PAYLOAD.iv);
  const ct = b64decode(PAYLOAD.ct);
  const key = await deriveKey(password, salt, PAYLOAD.iter);
  const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ct);
  return new TextDecoder().decode(plain);
}

function renderHtml(html) {
  // 用 srcdoc iframe 渲染，隔离作用域
  document.documentElement.innerHTML = '';
  document.documentElement.style.cssText = 'margin:0;height:100%';
  const body = document.createElement('body');
  body.style.cssText = 'margin:0;height:100vh;overflow:hidden';
  document.documentElement.appendChild(body);
  const ifr = document.createElement('iframe');
  ifr.style.cssText = 'border:0;width:100vw;height:100vh;display:block';
  ifr.srcdoc = html;
  body.appendChild(ifr);
}

async function attempt(password, savePassword) {
  const err = document.getElementById('err');
  err.textContent = '';
  try {
    const html = await tryDecrypt(password);
    if (savePassword) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        password, expires: Date.now() + TTL_MS
      }));
    }
    renderHtml(html);
  } catch (e) {
    err.textContent = '口令不正确，请重试';
    const pw = document.getElementById('pw');
    if (pw) { pw.value = ''; pw.focus(); }
  }
}

(async function () {
  const cached = localStorage.getItem(STORAGE_KEY);
  if (cached) {
    try {
      const c = JSON.parse(cached);
      if (c.expires > Date.now()) {
        await attempt(c.password, false);
        return;
      } else {
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch (e) {}
  }
  const pw = document.getElementById('pw');
  const btn = document.getElementById('btn');
  btn.onclick = () => attempt(pw.value, true);
  pw.onkeydown = (e) => { if (e.key === 'Enter') attempt(pw.value, true); };
})();
</script>
</body></html>"""

    author_line = (
        f'<p class="author-line"><span class="label">作者</span>'
        f'<span class="name">{_html_escape(author)}</span></p>'
        if author else ''
    )

    return (template
            .replace('__PROJECT__', _html_escape(project_name))
            .replace('__VERSION__', _html_escape(version_label))
            .replace('__AUTHOR_LINE__', author_line)
            .replace('__PAYLOAD__', payload))


def _html_escape(s):
    return (str(s).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;').replace("'", '&#39;'))
