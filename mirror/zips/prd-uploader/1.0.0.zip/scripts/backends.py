"""
存储后端抽象层 + GitHub 实现（带项目口令保护）。

工作流程：
  1. 用户给 skill 一个项目和口令 → set_project_password()
     口令的哈希写到仓库根 .passwords.json，方便 Claude 之后核验
  2. 用户上传 HTML → upload()
     用项目口令 AES-GCM 加密 HTML，包到带解密 UI 的模板里，push 到 GitHub
  3. 同事打开链接 → 浏览器要求输口令 → 本地解密 → 渲染原型
  4. 7 天内同项目其他原型自动放行（localStorage 缓存）

未来换公司 CDN 只需新增一个继承 Backend 的类。
"""
import base64
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from abc import ABC, abstractmethod

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from crypto_util import (
    encrypt_html, hash_password, verify_password, make_protected_html
)


class Backend(ABC):
    """所有存储后端要实现的接口"""

    @abstractmethod
    def list_projects(self): ...

    @abstractmethod
    def list_versions(self, project_name): ...

    @abstractmethod
    def upload(self, project_name, html, password, author=None, note=None): ...

    @abstractmethod
    def health_check(self): ...

    @abstractmethod
    def set_project_password(self, project_name, password, author=None): ...

    @abstractmethod
    def set_project_author(self, project_name, author): ...

    @abstractmethod
    def has_project_password(self, project_name): ...

    @abstractmethod
    def get_project_meta(self, project_name): ...


def make_timestamp():
    return datetime.now().strftime('%Y-%m-%d_%H-%M-%S')


def is_valid_project_name(name):
    if not name or not isinstance(name, str) or len(name) > 50:
        return False
    return bool(re.match(r'^[\w\u4e00-\u9fff\-]+$', name))


# ============================================================
# GitHub 后端
# ============================================================

class GitHubBackend(Backend):
    API = 'https://api.github.com'
    PROJECTS_FILE = '.projects.json'  # 项目元数据：口令哈希、作者、创建时间

    def __init__(self, token, owner, repo, pages_url, branch='main'):
        self.token = token
        self.owner = owner
        self.repo = repo
        self.branch = branch
        self.pages_url = pages_url.rstrip('/')

    def _request(self, method, path, body=None):
        url = f'{self.API}{path}'
        data = json.dumps(body).encode('utf-8') if body is not None else None
        req = urllib.request.Request(
            url, data=data, method=method,
            headers={
                'Authorization': f'Bearer {self.token}',
                'Accept': 'application/vnd.github+json',
                'X-GitHub-Api-Version': '2022-11-28',
                'Content-Type': 'application/json',
                'User-Agent': 'prototype-uploader-skill',
            }
        )
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                raw = resp.read()
                return json.loads(raw) if raw else None
        except urllib.error.HTTPError as e:
            err_body = e.read().decode('utf-8', errors='replace')
            raise RuntimeError(f'GitHub API {e.code}: {err_body}') from e
        except urllib.error.URLError as e:
            raise RuntimeError(f'网络问题：无法连接 GitHub: {e.reason}') from e

    def _get_file_sha(self, path):
        try:
            data = self._request('GET', f'/repos/{self.owner}/{self.repo}/contents/{urllib.parse.quote(path)}?ref={self.branch}')
            return data.get('sha') if isinstance(data, dict) else None
        except RuntimeError as e:
            if '404' in str(e):
                return None
            raise

    def _get_file_content(self, path):
        try:
            data = self._request('GET', f'/repos/{self.owner}/{self.repo}/contents/{urllib.parse.quote(path)}?ref={self.branch}')
            if not isinstance(data, dict) or 'content' not in data:
                return None
            return base64.b64decode(data['content']).decode('utf-8')
        except RuntimeError as e:
            if '404' in str(e):
                return None
            raise

    def _put_file(self, path, content_str, commit_message):
        b64 = base64.b64encode(content_str.encode('utf-8')).decode('ascii')
        body = {
            'message': commit_message,
            'content': b64,
            'branch': self.branch,
        }
        sha = self._get_file_sha(path)
        if sha:
            body['sha'] = sha
        self._request('PUT', f'/repos/{self.owner}/{self.repo}/contents/{urllib.parse.quote(path)}', body)

    # -------- 项目元数据管理 --------

    def _load_projects(self):
        """读取 .projects.json，返回 {project_name: {password, author, created_at}}"""
        content = self._get_file_content(self.PROJECTS_FILE)
        if not content:
            return {}
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            return {}

    def _save_projects(self, projects):
        content = json.dumps(projects, ensure_ascii=False, indent=2)
        self._put_file(self.PROJECTS_FILE, content, 'update .projects.json')

    def set_project_password(self, project_name, password, author=None):
        if not is_valid_project_name(project_name):
            raise ValueError('项目名无效')
        if not password or len(password) < 4:
            raise ValueError('口令至少 4 个字符')
        projects = self._load_projects()
        existing = projects.get(project_name, {})
        projects[project_name] = {
            'password': hash_password(password),
            'author': author or existing.get('author', ''),
            'created_at': existing.get('created_at', make_timestamp()),
        }
        self._save_projects(projects)

    def set_project_author(self, project_name, author):
        """单独更新作者字段，不影响其他元数据"""
        if not is_valid_project_name(project_name):
            raise ValueError('项目名无效')
        projects = self._load_projects()
        if project_name not in projects:
            raise ValueError(f'项目 {project_name} 不存在')
        projects[project_name]['author'] = author or ''
        self._save_projects(projects)
        # 作者变化要刷新浏览页（首页 + 项目页）
        # 注意：原型 HTML 内嵌的作者是上传时的快照，单独改作者不重新加密老文件
        try:
            self._refresh_indexes()
        except Exception:
            pass

    def has_project_password(self, project_name):
        projects = self._load_projects()
        return project_name in projects and 'password' in projects[project_name]

    def get_project_password_record(self, project_name):
        record = self._load_projects().get(project_name, {})
        return record.get('password')

    def get_project_author(self, project_name):
        return self._load_projects().get(project_name, {}).get('author', '')

    def get_project_meta(self, project_name):
        """返回完整的项目元数据（不含口令哈希），供 CLI 查询用"""
        record = self._load_projects().get(project_name, {})
        return {
            'name': project_name,
            'author': record.get('author', ''),
            'created_at': record.get('created_at', ''),
            'has_password': 'password' in record,
        }

    # -------- 后端接口 --------

    def health_check(self):
        try:
            self._request('GET', f'/repos/{self.owner}/{self.repo}')
            return {'ok': True, 'message': 'GitHub 仓库可访问'}
        except RuntimeError as e:
            msg = str(e)
            if '401' in msg:
                return {'ok': False, 'message': 'Token 无效或已过期。请重新生成 GitHub Personal Access Token。'}
            if '404' in msg:
                return {'ok': False, 'message': f'仓库 {self.owner}/{self.repo} 不存在或 token 没有访问权限。'}
            return {'ok': False, 'message': msg}

    def list_projects(self):
        try:
            data = self._request('GET', f'/repos/{self.owner}/{self.repo}/contents/?ref={self.branch}')
            if not isinstance(data, list):
                return []
            return sorted([
                item['name'] for item in data
                if item.get('type') == 'dir' and not item['name'].startswith('.')
            ])
        except RuntimeError as e:
            if '404' in str(e):
                return []
            raise

    def list_versions(self, project_name):
        if not is_valid_project_name(project_name):
            return []
        try:
            data = self._request('GET', f'/repos/{self.owner}/{self.repo}/contents/{urllib.parse.quote(project_name)}?ref={self.branch}')
        except RuntimeError as e:
            if '404' in str(e):
                return []
            raise
        if not isinstance(data, list):
            return []
        versions = []
        for item in data:
            if item.get('type') != 'file' or not item['name'].endswith('.html'):
                continue
            if item['name'] == 'index.html':
                continue
            versions.append({
                'filename': item['name'],
                'url': f'{self.pages_url}/{urllib.parse.quote(project_name)}/{urllib.parse.quote(item["name"])}',
                'is_latest': item['name'] == 'latest.html',
                'size': item.get('size', 0),
            })
        versions.sort(key=lambda v: v['filename'], reverse=True)
        return versions

    def upload(self, project_name, html, password, author=None, note=None):
        if not is_valid_project_name(project_name):
            raise ValueError('项目名无效。只能用中英文、数字、连字符、下划线，长度 ≤ 50。')
        if not html:
            raise ValueError('HTML 内容不能为空')
        if not password:
            raise ValueError('必须提供项目口令（用于加密 HTML）')

        timestamp = make_timestamp()

        # 同步项目元数据（口令 + 作者）
        is_new_project = not self.has_project_password(project_name)
        if is_new_project:
            # 新项目：必须有作者（虽然 CLI 默认设为空字符串以容错，但 SKILL.md 要求 Claude 必问）
            self.set_project_password(project_name, password, author=author)
        elif author is not None:
            # 已有项目：传了 author 就更新（None 表示不改）
            self.set_project_author(project_name, author)

        # 取最新作者用于嵌入 HTML
        current_author = self.get_project_author(project_name)

        # 加密 HTML，包进保护模板
        encrypted = encrypt_html(html, password)
        protected_html = make_protected_html(encrypted, project_name, timestamp, author=current_author)
        latest_protected = make_protected_html(encrypted, project_name, '最新版本', author=current_author)

        # 写带时间戳的版本文件
        commit_msg = f'[{project_name}] {timestamp}'
        if note:
            commit_msg += f' - {note}'
        self._put_file(f'{project_name}/{timestamp}.html', protected_html, commit_msg)

        # 更新 latest.html
        self._put_file(f'{project_name}/latest.html', latest_protected,
                       f'[{project_name}] update latest -> {timestamp}')

        # 重新生成浏览页（失败不影响主流程）
        try:
            self._refresh_indexes()
        except Exception:
            pass

        base = f'{self.pages_url}/{urllib.parse.quote(project_name)}'
        return {
            'url': f'{base}/latest.html',
            'versioned_url': f'{base}/{urllib.parse.quote(timestamp)}.html',
            'project_url': f'{base}/',
            'home_url': f'{self.pages_url}/',
            'filename': f'{timestamp}.html',
            'timestamp': timestamp,
            'author': current_author,
        }

    # -------- 浏览页 --------

    def _refresh_indexes(self):
        projects = self.list_projects()

        if not projects:
            items_html = '''<div class="empty">
              <p class="empty-title">还没有原型</p>
              <p class="empty-sub">上传第一个原型后会显示在这里</p>
            </div>'''
        else:
            cards = []
            for p in projects:
                versions = self.list_versions(p)
                version_count = len([v for v in versions if v['filename'] != 'latest.html'])
                author = self.get_project_author(p)
                # meta 行：版本数 [· 作者]
                meta_parts = [f'{version_count} 个版本']
                if author:
                    meta_parts.append(f'作者 {_html_escape(author)}')
                meta_html = ' · '.join(meta_parts)
                cards.append(f'''
                <a class="card" href="./{urllib.parse.quote(p)}/">
                  <div class="card-main">
                    <div class="card-name">{_html_escape(p)}</div>
                    <div class="card-meta">{meta_html}</div>
                  </div>
                  <div class="card-arrow">{_ICON_ARROW}</div>
                </a>''')
            items_html = '\n'.join(cards)

        index_html = (INDEX_TEMPLATE
                      .replace('{{ITEMS}}', items_html)
                      .replace('{{COUNT}}', str(len(projects))))
        self._put_file('index.html', index_html, 'update index')

        for p in projects:
            self._refresh_project_index(p)

    def _refresh_project_index(self, project_name):
        versions = self.list_versions(project_name)
        # 分离出真实版本（不含 latest.html）
        real_versions = [v for v in versions if v['filename'] != 'latest.html']
        # 找最新一份（list_versions 已按文件名倒序，第一个就是最新）
        latest_filename = real_versions[0]['filename'] if real_versions else None

        if not real_versions:
            items = '''<div class="empty">
              <p class="empty-title">还没有版本</p>
              <p class="empty-sub">上传一份原型到本项目</p>
            </div>'''
        else:
            cards = []
            for v in real_versions:
                is_latest = (v['filename'] == latest_filename)
                label = v['filename'].replace('.html', '')
                if is_latest:
                    # 最新版本：带 LATEST 徽章，链接指向稳定的 latest.html
                    label_html = f'{label} <span class="badge">LATEST</span>'
                    href = './latest.html'
                    meta = f'{(v["size"]/1024):.1f} KB · 稳定链接'
                else:
                    label_html = label
                    href = f'./{urllib.parse.quote(v["filename"])}'
                    meta = f'{(v["size"]/1024):.1f} KB'
                cards.append(f'''
                <a class="card" href="{href}" target="_blank">
                  <div class="card-main">
                    <div class="card-name">{label_html}</div>
                    <div class="card-meta">{meta}</div>
                  </div>
                  <div class="card-arrow">{_ICON_ARROW}</div>
                </a>''')
            items = '\n'.join(cards)
        author = self.get_project_author(project_name)
        author_eyebrow = (
            f'<span class="sep">·</span>作者 <span style="color:var(--fg);font-weight:500">{_html_escape(author)}</span>'
            if author else ''
        )
        page = (PROJECT_INDEX_TEMPLATE
                .replace('{{NAME}}', _html_escape(project_name))
                .replace('{{COUNT}}', str(len(real_versions)))
                .replace('{{AUTHOR_EYEBROW}}', author_eyebrow)
                .replace('{{ITEMS}}', items))
        self._put_file(f'{project_name}/index.html', page, f'[{project_name}] update index')


# ============================================================
# 浏览页模板
# ============================================================

_COMMON_STYLE = '''
:root {
  --bg: #ffffff;
  --bg-subtle: #f7f7f8;
  --fg: #0a0a0a;
  --muted: #737373;
  --muted-2: #a3a3a3;
  --border: #e5e5e5;
  --border-strong: #0a0a0a;
  --hover: #fafafa;
  --mono: ui-monospace,"SF Mono","JetBrains Mono",Menlo,Consolas,monospace;
}
html, body { background: var(--bg); }
* { box-sizing: border-box; }
body { font-family: -apple-system, BlinkMacSystemFont, "Inter", "PingFang SC",
  "Segoe UI", sans-serif; color: var(--fg);
  margin: 0; padding: 0; min-height: 100vh;
  -webkit-font-smoothing: antialiased; }
.container { max-width: 640px; margin: 0 auto; padding: 80px 28px 60px; }

/* Header */
.eyebrow { font-family: var(--mono); font-size: 11px; color: var(--muted);
  text-transform: uppercase; letter-spacing: .1em; margin-bottom: 16px; }
.eyebrow .dot { display: inline-block; width: 6px; height: 6px; border-radius: 50%;
  background: var(--fg); margin-right: 8px; vertical-align: 1px; }
.eyebrow .sep { color: var(--muted-2); margin: 0 10px; }
h1 { font-size: 36px; font-weight: 600; margin: 0 0 12px;
  letter-spacing: -.025em; line-height: 1.1; }
.subtitle { color: var(--muted); font-size: 14px; margin: 0 0 48px;
  line-height: 1.5; max-width: 480px; }

/* List */
.list-header { display: flex; align-items: baseline; justify-content: space-between;
  padding-bottom: 14px; border-bottom: 1px solid var(--border); margin-bottom: 8px;
  font-family: var(--mono); font-size: 11px; color: var(--muted);
  text-transform: uppercase; letter-spacing: .08em; }
.list { display: flex; flex-direction: column; gap: 4px; }
.card { display: flex; align-items: center; justify-content: space-between;
  padding: 18px 20px; border: 1px solid var(--border); border-radius: 16px;
  background: var(--bg); text-decoration: none; color: var(--fg);
  transition: background-color .15s, border-color .15s, transform .08s; }
.card:hover { background: var(--hover); border-color: var(--border-strong); }
.card:active { transform: scale(.997); }
.card-main { min-width: 0; flex: 1; }
.card-name { font-weight: 500; font-size: 15px; margin: 0 0 4px;
  letter-spacing: -.01em; display: flex; align-items: center; gap: 10px; }
.card-meta { font-size: 12px; color: var(--muted);
  font-family: var(--mono); font-variant-numeric: tabular-nums; }
.card-arrow { color: var(--muted-2); flex-shrink: 0; margin-left: 16px;
  transition: transform .15s, color .15s; }
.card:hover .card-arrow { color: var(--fg); transform: translateX(2px); }
.badge { display: inline-flex; align-items: center; padding: 2px 8px;
  font-size: 10px; font-weight: 500; letter-spacing: .06em;
  border-radius: 999px; background: var(--fg); color: var(--bg);
  text-transform: uppercase; font-family: var(--mono); }

/* Empty */
.empty { padding: 80px 24px; text-align: left;
  border: 1px dashed var(--border); border-radius: 16px; }
.empty-title { font-size: 16px; font-weight: 500; margin: 0 0 6px; }
.empty-sub { color: var(--muted); font-size: 13px; margin: 0;
  font-family: var(--mono); }

/* Breadcrumb */
.breadcrumb { font-family: var(--mono); font-size: 11px; color: var(--muted);
  text-transform: uppercase; letter-spacing: .08em; margin-bottom: 24px;
  display: flex; align-items: center; gap: 8px; }
.breadcrumb a { color: var(--muted); text-decoration: none;
  display: inline-flex; align-items: center; gap: 6px;
  transition: color .15s; }
.breadcrumb a:hover { color: var(--fg); }

/* Footer */
.footer { margin-top: 80px; padding-top: 24px; border-top: 1px solid var(--border);
  font-family: var(--mono); font-size: 11px; color: var(--muted);
  text-transform: uppercase; letter-spacing: .08em;
  display: flex; justify-content: space-between; align-items: center;
  gap: 16px; flex-wrap: wrap; }
.footer .contact { color: var(--fg); font-weight: 500; text-transform: none;
  letter-spacing: 0; }
.footer .contacts { display: inline-flex; align-items: center; gap: 8px;
  flex-wrap: wrap; }
.footer .dot-sep { color: var(--muted-2); }
@media (max-width: 480px) {
  .footer { flex-direction: column; align-items: flex-start; }
}
'''

# 简化的功能性图标
_ICON_ARROW = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>'
_ICON_BACK = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>'

_FOOTER_HTML = '''<div class="footer">
  <span>已加密 · 7 天免重输</span>
  <span class="contacts">
    <span>企微 <span class="contact">yunpeng.wang</span></span>
    <span class="dot-sep">·</span>
    <span>微信 <span class="contact">xiaohei-o_o</span></span>
  </span>
</div>'''

INDEX_TEMPLATE = f'''<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>原型索引</title>
<style>{_COMMON_STYLE}</style></head><body><div class="container">
<div class="eyebrow"><span class="dot"></span>原型索引<span class="sep">·</span>{{{{COUNT}}}} 个项目</div>
<h1>原型索引</h1>
<p class="subtitle">所有原型均经过加密。每个项目使用独立口令，输入一次后该项目所有版本在浏览器内 7 天免重输。</p>
<div class="list-header"><span>项目</span><span>版本数</span></div>
<div class="list">
{{{{ITEMS}}}}
</div>
{_FOOTER_HTML}
</div></body></html>
'''

PROJECT_INDEX_TEMPLATE = f'''<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{{{NAME}}}}</title>
<style>{_COMMON_STYLE}</style></head><body><div class="container">
<div class="breadcrumb"><a href="../">{_ICON_BACK} 返回索引</a></div>
<div class="eyebrow"><span class="dot"></span>项目<span class="sep">·</span>{{{{COUNT}}}} 个版本{{{{AUTHOR_EYEBROW}}}}</div>
<h1>{{{{NAME}}}}</h1>
<p class="subtitle">该项目下全部版本，均需口令访问。最新版本在最上方。</p>
<div class="list-header"><span>版本</span><span>大小</span></div>
<div class="list">
{{{{ITEMS}}}}
</div>
{_FOOTER_HTML}
</div></body></html>
'''


def _html_escape(s):
    return (str(s).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;').replace("'", '&#39;'))


def get_backend(config):
    """
    根据配置实例化后端。
    未来加新后端时只需在这里加一个分支。
    """
    backend_type = config.get('backend', 'github')
    if backend_type == 'github':
        gh = config.get('github', {})
        required = ['token', 'owner', 'repo', 'pages_url']
        missing = [k for k in required if not gh.get(k)]
        if missing:
            raise ValueError(f'GitHub 配置缺少字段: {", ".join(missing)}')
        return GitHubBackend(
            token=gh['token'],
            owner=gh['owner'],
            repo=gh['repo'],
            pages_url=gh['pages_url'],
            branch=gh.get('branch', 'main'),
        )
    raise ValueError(f'不支持的后端类型: {backend_type}')
