---
name: slbrow-skills
description: Browser automation via SLBrow MCP. Use when the user needs to navigate pages, analyze content, manage tabs, search history, extract text, or control the browser. For use with browser plugin (aiassist) + MCP. Requires SLBrow server running and browser extension installed.
---

# SLBrow Browser Automation (Skills for Browser)

Skills for browser-side AI assistant. The browser plugin (aiassist) connects to slbrow-mcp via MCP protocol; these skills guide when and how to use the tools.

## Prerequisites

1. **SLBrow server** running: `npx slbrow` or `npm start` in `ai/slbrowmcp/slbrow-mcp/`
2. **Browser extension** installed and connected (Chrome/Firefox)
3. **MCP plugin** enabled in aiassist: `http://127.0.0.1:5556/mcp` (视联浏览器MCP), `http://127.0.0.1:5556/vaimcp` (视联视频AI MCP)
4. Default ports: HTTP 5556, WebSocket 5555

## Usage (Browser Plugin + MCP)

When the MCP plugin is enabled, the AI has access to browser tools. Use these skills to guide tool selection and workflow:

- **Navigation**: Use `page_navigate` to open URLs
- **Analysis**: Use `page_analyze` with intent_hint (article, form submit, post_create) before extraction
- **Tabs**: Use `tab_list` first, then pass `tab_id` to target specific tabs; use `tab_switch` to focus a tab by ID
- **Interaction**: After `page_analyze`, use `element_id` with `element_click`, `element_fill`, or `element_get_state` (optional `tab_id` for background tabs)

## Available Tools

| Tool | Description |
|------|-------------|
| `page_navigate` | Navigate current tab to URL |
| `page_analyze` | Analyze page for elements (intent_hint: article, login, signup, search, post_create, comment, submit, buy, download, form, pagination, navigation) |
| `page_extract_content` | Extract content (content_type: article, search_results, posts) |
| `page_wait_for` | Wait for element or text (condition_type, selector, text) |
| `element_click` | Click an element by `element_id` from `page_analyze` (click_type: left/right/double; optional tab_id) |
| `element_fill` | Fill an input/textarea by `element_id` (value, clear_first, force_focus; optional tab_id) |
| `element_get_state` | Read state for an `element_id` (disabled, visible, value, etc.; optional tab_id) |
| `page_scroll` | Scroll the page or scroll an element into view (direction, amount, element_id; optional tab_id) |
| `page_style` | Change page appearance (mode: preset/custom/ai_mood/effect/reset; themes, colors, effects) |
| `tab_create` | Create tab(s) (url, urls[], or count) |
| `tab_close` | Close tab(s) (tab_id, tab_ids[]) |
| `tab_list` | List open tabs with IDs |
| `tab_switch` | Switch active tab to a given `tab_id` |
| `get_bookmarks` | List or search bookmarks (optional query) |
| `add_bookmark` | Add a bookmark (title, url; optional parentId) |
| `get_history` | Search browser history (keywords, start_date, end_date, domains, max_results) |
| `get_selected_text` | Get selected text (optional tab_id) |
| `get_page_links` | Get page links (link_type: all/internal/external, domains, max_results) |

## VAI Tools (Seelink)

| Tool | Description |
|------|-------------|
| `get_page_seelink_player_list` | Get all players on current page |
| `use_seelink_players_ai` | Apply AI function to players (ai_function_name: reduce_fog, face_mosaic, dark_reduce, human_outline, vechicle_outline, none) |

## Workflow Patterns

**Multi-tab workflow:**
1. `tab_list` to get tab IDs
2. Add `tab_id` to any tool to target a background tab

**Content extraction:**
1. `page_navigate` to target URL
2. `page_analyze` with intent_hint to find elements
3. `page_extract_content` for article/search_results/posts

**Form filling:**
1. `page_analyze` with intent_hint "form submit" to discover form elements
2. Note the element IDs returned — use them with subsequent `page_analyze` or `page_extract_content` to confirm state

**Click / type on the page:**
1. `page_analyze` with an intent that matches the UI (e.g. form submit, post_create, menu)
2. Use `element_get_state` if you need to confirm disabled/visible/value before acting
3. `element_fill` for inputs; `element_click` for buttons/links (optional `tab_id` to act on a background tab)

**Bookmarks:**
1. `get_bookmarks` with optional `query` to search
2. `add_bookmark` with `title` and `url` (optional `parentId` for folder)

**Long pages / focus:**
1. `page_scroll` with direction/amount or `element_id` to bring content into view (optional `tab_id`)

**VAI (Seelink player AI):**
1. `get_page_seelink_player_list` to get player IDs and count
2. Choose targets by `player_position_list` (zero-based index) **or** `player_id_list` (not both)
3. `use_seelink_players_ai` with chosen targets and `ai_function_name`
4. To apply different functions to different players, call `use_seelink_players_ai` separately for each
5. To disable AI on a player, set `ai_function_name` to `"none"`

## Fetching Skills in Browser

The browser plugin can fetch skills from the server to inject into AI context:

```
GET http://127.0.0.1:5556/api/skills
```

Returns the full SKILL.md content (text/markdown). Use when slbrow MCP plugins are enabled to guide tool usage.

## API Reference

For full parameter schemas, see [references/api-reference.md](references/api-reference.md).

## Error Handling

- `EXTENSION_DISCONNECTED`: Ensure extension is installed and server is running. Check `http://localhost:5556/health` first.
- `Tool call timeout`: Operation took >30s; retry with simpler args or break into smaller steps.
- `page_analyze` returns 0 elements: Page may still be loading — wait a moment and retry, or `page_navigate` again.
- `tab_id` invalid (tab was closed): Call `tab_list` to refresh available tab IDs before retrying.
- Server restarted (session lost): Client will receive 404; re-initialize MCP connection (refresh the page).

## Fallback (No MCP Tools)

If MCP tools are unavailable, call the HTTP API directly with `curl`:

```bash
curl -X POST http://localhost:5556/api/execute \
  -H 'Content-Type: application/json' \
  -d '{"tool":"use_seelink_players_ai","args":{"player_position_list":[0],"ai_function_name":"face_mosaic"}}'
```
