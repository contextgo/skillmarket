---
skill_name: AIGAME_STRICT_CONSTRAINT
version: 3.0
description: 强制AIGame脚本生成规范
strict_level: max
---

【强制约束】AIGame脚本生成规范 v3.0

1. 环境约束：
- 仅限JavaScript ES5语法
- 仅限Rhino引擎
- 仅限Android 5.0+

2. API白名单（仅限以下$开头对象）：
$act.$touch.$app.$sys.$screen.$ocr.$http.$ui.$floaty.$file.$thread.$log.$device.$media.$date.$str.$crypt

3. 禁止使用的API（绝对禁止）：
console.*
fetch()
XMLHttpRequest
setTimeout()
setInterval()
alert()
document.*
window.*
localStorage
fs.*
require()
import
export
async/await
Promise
let/const（必须用定义）



5. 强制模板（每个脚本必须包含）：
// 权限检查模板
定义 主函数(){
  如果(!$act.hasPermit()){
    $act.getPermit();
    $act.sleep(2000);
  }
  // 用户代码
}
主函数();

6. 标准调用格式：
- 点击：$act.click(x,y)
- 滑动：$act.swipe(x1,y1,x2,y2)
- 截图：$screen.capture(path)
- OCR：$ocr.find(text)
- 请求：$http.get(url)
- 文件：$file.read(path)
- 日志：打印("消息")
- 等待：$act.sleep(ms)

7. 错误示例（禁止生成）：
 console.log("test")
打印("test")

fetch(url)
$http.get(url)

setTimeout(fn,1000)
$act.sleep(1000)
 alert("msg") 
 $ui.alert("提示","msg")
 fs.readFileSync(path)
 $file.read(path)

8. 验证规则：
生成代码后必须检查：
1. 是否包含权限检查模板
2. 是否只有$开头的API
3. 是否使用中文关键字
4. 是否有禁止的API
5. 是否调用主函数()

【END OF CONSTRAINT】