# AutoGOD autogod 编码规范技能

## 触发条件

当用户需要编写 autogod  AIGame / AutoGOD 脚本、使用 AIGame API（如 `$act`、`$screen`、`$ocr`、`$http`、`$floaty`、`$file` 等）、实现安卓自动化操作、处理图像识别、OCR 文字识别、UI 界面构建、网络请求、文件操作、多线程等任务时使用本技能。

---

## 核心架构

**权限优先级链：ROOT > Shizuku > Accessibility**

所有 `$act` 手势操作均遵循此优先级：先判断 ROOT，有则用 `$root`；否则判断 Shizuku，有则用 `$szk`；最后才用无障碍 Accessibility。

---

## 强制执行流程

### 第一步：读取规范文档

1. 读取 `references/01_autogod-js-api-standard.md` — JavaScript 方言与核心 API 规范
2. 读取 `references/02_autogod-xml-layout-standard.md` — XML 布局语法规范
3. 读取 `references/03_autogod-code-snippets.md` — 纯净代码范式示例
4. 读取 `references/04_autogod-error-correction.md` — 常见错误修正
5. 读取 `references/05_autogod-mandatory-checklist.md` — 强制自检清单

### 第二步：强制自检

在生成代码前，必须完成 `05_autogod-mandatory-checklist.md` 中的所有检查项，并在回复中声明：

```
✅ 已完成强制自检：
- [x] API 调用规范检查
- [x] 权限申请顺序检查
- [x] 异步操作处理检查
- [x] 资源释放检查
- [x] 异常处理检查
```

### 第三步：生成代码

- 严格遵循 `01_autogod-js-api-standard.md` 中的 API 调用规范
- 使用 `03_autogod-code-snippets.md` 中的标准范式
- 确保所有异步操作使用 `async/await` 或回调
- 确保所有资源在使用后正确释放
- 添加必要的异常处理和日志

### 第四步：代码审查

生成代码后，对照 `04_autogod-error-correction.md` 检查常见错误：
- API 名称拼写错误
- 参数类型错误
- 权限缺失
- 资源泄漏
- 异步操作错误

---

## 参考文档

### 规范文档（必读）

| 文件 | 说明 |
|------|------|
| `references/01_autogod-js-api-standard.md` | JavaScript 方言与核心 API 规范 |
| `references/02_autogod-xml-layout-standard.md` | XML 布局语法规范 |
| `references/03_autogod-code-snippets.md` | 纯净代码范式示例 |
| `references/04_autogod-error-correction.md` | 常见错误修正 |
| `references/05_autogod-mandatory-checklist.md` | 强制自检清单 |
| `references/06_autogod-supplement-api.md` | 补充 API 规范（早期版本） |

### API 模块文档（按需查阅）

27 个独立 API 参考文件位于 `references/api/` 目录：

#### 手势与动作
| 文件 | 模块 | 说明 |
|------|------|------|
| `references/api/$act.md` | `$act` | 手势动作（click/press/move/gesture/path） |
| `references/api/$root.md` | `$root` | ROOT 权限手势与 Shell 命令 |
| `references/api/$szk.md` | `$szk` | Shizuku 免 ROOT 手势/Shell/分辨率控制 |

#### 图色识别
| 文件 | 模块 | 说明 |
|------|------|------|
| `references/api/$ag.md` | `$ag` | 图色框架：找图/等图/血条检测/多点找色 |
| `references/api/$img.md` | `$img` | 图片处理：裁剪/缩放/旋转/灰度/二值化 |
| `references/api/$color.md` | `$color` | 颜色操作：内置常量/找色/通道解析/主题色 |

#### 屏幕与识别
| 文件 | 模块 | 说明 |
|------|------|------|
| `references/api/$screen.md` | `$screen` | 屏幕操作：截屏/亮度/方向/分割 |
| `references/api/$ocr.md` | `$ocr` | 文字识别：ncnn/mlkit/ppv5 三引擎 |
| `references/api/$draw.md` | `$draw` | 全屏绘制：矩形/十字/文字/圆/线/路径 |

#### 文件与存储
| 文件 | 模块 | 说明 |
|------|------|------|
| `references/api/$file.md` | `$file` | 文件系统：读写/拷贝/移动/媒体库 |
| `references/api/$storage.md` | `$storage` | 应用内键值存储（命名空间） |
| `references/api/$res.md` | `$res` | 资源管理器：跨线程存储/导入导出 |

#### 网络与媒体
| 文件 | 模块 | 说明 |
|------|------|------|
| `references/api/$http.md` | `$http` | 网络请求：GET/POST/下载 |
| `references/api/$media.md` | `$media` | 音频播放（MediaPlayer） |
| `references/api/$tts.md` | `$tts` | 文字转语音（TTS） |

#### UI 与交互
| 文件 | 模块 | 说明 |
|------|------|------|
| `references/api/$floaty.md` | `$floaty` | 悬浮窗：可调节/应用级/系统级/范围选择 |
| `references/api/$tip.md` | `$tip` | 阻塞对话框：输入/选择器/日期时间 |
| `references/api/$log.md` | `$log` | 日志框架：分级打印/悬浮窗/日志界面 |

#### 系统与设备
| 文件 | 模块 | 说明 |
|------|------|------|
| `references/api/$device.md` | `$device` | 设备信息：屏幕/电池/音量/内存/震动 |
| `references/api/$sys.md` | `$sys` | 系统工具：飞行模式/音量/剪切板/保活 |
| `references/api/$permit.md` | `$permit` | 权限工具：悬浮窗/无障碍/存储/定位等 |
| `references/api/$event.md` | `$event` | 事件监听：系统/无障碍/应用事件 |
| `references/api/$engine.md` | `$engine` | 脚本引擎：运行/暂停/停止任务 |

#### 工具与线程
| 文件 | 模块 | 说明 |
|------|------|------|
| `references/api/$app.md` | `$app` | 应用操作：启动/安装/卸载/包名查询 |
| `references/api/$thread.md` | `$thread` | 并发编程：线程/循环器/倒计时锁 |
| `references/api/$str.md` | `$str` | 字符串操作：编码/分割/比较/格式化（80+函数） |
| `references/api/$date.md` | `$date` | 日期工具：格式化/解析/时长 |
| `references/api/$global.md` | `$global` | 全局函数：无 `$` 前缀直接调用（sleep/alert/log/random 等） |

---

## 常用模式速查

### 权限申请
```javascript
// 无障碍权限（推荐，非阻塞）
$permit.wza();

// 悬浮窗权限
$permit.floaty();

// 获取并等待无障碍（阻塞式，不推荐在 UI 线程）
$act.getPermit();

// 获取 Shizuku 权限
$szk.getPermit();
```

### 找图点击（最常用）
```javascript
// 单图点击（推荐）
let point = $ag.findImgClick({
    path: "/sdcard/close.png",
    region: [0, 0, 500, 500],
    similar: 0.85
});

// 等图出现后再点击
let point = $ag.waitImgClick({
    path: "/sdcard/ready.png",
    waitTimes: 60,
    waitDur: 1000
});

// 循环等图
let point = $ag.waitImg({
    path: "/sdcard/ready.png",
    waitTimes: 60,
    waitDur: 1000
});
if (point) {
    $act.click(point);
}
```

### 截屏 + OCR
```javascript
$screen.getPermit();
let img = $screen.getScreen();

// 指定区域灰度 OCR
let result = $ocr.detect({
    img: img,
    region: [0, 0, 200, 100],
    gray: true
});

// 全量文字识别（默认 mlkit 引擎）
let text = $ocr.v(img);
```

### 找色
```javascript
let img = $screen.getScreen();
let point = $color.find(img, "#a55978", 5, [300, 200, 500, 500]);
if (point) {
    $draw.cross(point);  // 调试标注
    $act.click(point);
}
```

### 悬浮窗
```javascript
$floaty.getPermit();

// 应用级悬浮窗（推荐）
let win = $floaty.newApp({
    w: 200,
    h: 100,
    initX: 100,
    initY: 200
});
win.setText("Hello");

// 关闭所有
$floaty.closeAll();
```

### 应用操作
```javascript
// 启动应用
$app.run("QQ");

// 判断是否安装
if ($app.isInstall("com.example.app")) {
    log("已安装");
}

// 卸载
$app.uninstall("com.example.app");

// 打开应用设置
$app.openAppSetting("AIGame");
```

### 并发任务
```javascript
// 在新线程运行
$thread.run(() => {
    let img = $screen.getScreen();
    $ocr.detect(img);
});

// 定时循环
$thread.loop(() => {
    $ag.waitImgClick({ path: "/sdcard/btn.png" });
}, 3000);  // 每 3 秒执行一次
```

---

## 重要注意事项

| 项目 | 说明 |
|------|------|
| `$act` 优先级 | ROOT > Shizuku > Accessibility |
| `$permit` 权限 | 所有方法只调用一次（内部缓存） |
| OCR 引擎 | ncnn 快但可能混乱；mlkit 准但慢；ppv5 精确 |
| MIUI 限制 | `$draw` 全屏绘制会被拦截，v1.8.0+ ROOT/Szk 可解锁 |
| 安卓 13+ 剪切板 | 获取可能为空或失败，属于正常现象 |
| 打包 APK | 使用 `$engine.run("项目中js路径")` 而非 `runCode(源码)` |
| `getPermit()` | 阻塞方法，不要在 UI 线程调用 |

---

## 快速启动

使用 `assets/quick_start_template.js` 作为项目起点。

---

**文档来源：** https://aigamepro.work/api_en/  
**本地备份：** `references/api/` 目录下的 27 个 API 模块文件
