# AutoGOD 常见"跑编"错误修正

## 更新时间
2026-04-30

## 一、API 调用错误

### 1.1 API 名称拼写错误

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `$act.clickk(500, 800)` | `$act.click(500, 800)` | API 名称拼写错误 |
| `$screen.getscreen()` | `$screen.getScreen()` | 大小写错误 |
| `$ocr.detct()` | `$ocr.detect()` | 拼写错误 |
| `$floaty.newAppp()` | `$floaty.newApp()` | 多余字母 |
| `$act.selecter()` | `$act.selector()` | 拼写错误 |

**修正方法：**
- 严格参考 `01_autogod-js-api-standard.md` 中的 API 名称
- 使用代码编辑器的自动补全功能
- 运行前检查 API 名称拼写

### 1.2 参数类型错误

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `$act.click("500", "800")` | `$act.click(500, 800)` | 坐标必须为数字 |
| `$act.click(500.5, 800.2)` | `$act.click(500, 800)` | 坐标必须为整数 |
| `$act.move(500, 800, 600, 900, "500")` | `$act.move(500, 800, 600, 900, 500)` | 时长必须为数字 |
| `$screen.bright("100")` | `$screen.bright(100)` | 亮度必须为数字 |
| `$ocr.v(123)` | `$ocr.v("mlkit")` | 引擎名称必须为字符串 |

**修正方法：**
```javascript
// ✅ 正确：使用整数坐标
let x = Math.floor(500.5);  // 500
let y = Math.floor(800.2);  // 800
$act.click(x, y);

// ✅ 正确：类型检查
function safeClick(x, y) {
    if (typeof x !== "number" || typeof y !== "number") {
        throw new Error("坐标必须为数字");
    }
    $act.click(Math.floor(x), Math.floor(y));
}
```

### 1.3 参数缺失错误

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `$act.move(500, 800)` | `$act.move(500, 800, 600, 900)` | 缺少终点坐标 |
| `$ocr.getPoint()` | `$ocr.getPoint("文字")` | 缺少目标文字 |
| `$http.post()` | `$http.post({url: "..."})` | 缺少请求配置 |
| `$file.write("content")` | `$file.write("content", path)` | 缺少文件路径 |

### 1.4 参数顺序错误

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `$act.click(y, x)` | `$act.click(x, y)` | X/Y 坐标顺序错误 |
| `$act.move(x2, y2, x1, y1)` | `$act.move(x1, y1, x2, y2)` | 起点/终点顺序错误 |
| `$file.write(path, content)` | `$file.write(content, path)` | 内容/路径顺序错误 |

## 二、权限相关错误

### 2.1 权限未申请

| 错误场景 | 错误代码 | 修正代码 |
|---------|---------|---------|
| 无障碍未申请 | `$act.click(500, 800)` | `if(!$act.hasPermit()) $act.getPermit(); $act.click(500, 800);` |
| 截屏权限未申请 | `$screen.getScreen()` | `if(!$screen.hasPermit()) $screen.getPermit(); $screen.getScreen();` |
| 悬浮窗权限未申请 | `$floaty.newApp(...)` | `if(!$floaty.hasPermit()) $floaty.getPermit(); $floaty.newApp(...);` |

**修正范式：**
```javascript
// ✅ 正确：权限检查范式
async function ensurePermissions() {
    if (!$act.hasPermit()) {
        log("申请无障碍权限...");
        $act.getPermit();
    }
    
    if (!$screen.hasPermit()) {
        log("申请截屏权限...");
        $screen.getPermit();
    }
    
    log("权限检查完成");
}
```

### 2.2 UI 线程调用阻塞函数

| 错误场景 | 错误代码 | 修正代码 |
|---------|---------|---------|
| UI 线程调用 getPermit | `ui.button.onClick = () => { $act.getPermit(); }` | `ui.button.onClick = () => { $permit.wza(); }` |

**修正方法：**
```javascript
// ❌ 错误：UI 线程阻塞
ui.findView("btn").setOnClickListener(() => {
    $act.getPermit();  // 阻塞 UI 线程
});

// ✅ 正确：使用非阻塞方式
ui.findView("btn").setOnClickListener(() => {
    $permit.wza();  // 非阻塞申请
});
```

## 三、异步操作错误

### 3.1 同步调用异步函数

| 错误场景 | 错误代码 | 修正代码 |
|---------|---------|---------|
| 未等待权限申请 | `$act.getPermit(); $act.click(...);` | `await $act.getPermit(); $act.click(...);` |

**修正方法：**
```javascript
// ❌ 错误：未等待异步操作
function main() {
    $act.getPermit();
    $act.click(500, 800);  // 可能权限还未获取
}

// ✅ 正确：使用 async/await
async function main() {
    await $act.getPermit();
    $act.click(500, 800);
}
```

## 四、资源泄漏错误

### 4.1 图像资源未释放

| 错误场景 | 错误代码 | 修正代码 |
|---------|---------|---------|
| 截屏未释放 | `let img = $screen.getScreen();` | `let img = $screen.getScreen(); img.recycle();` |

**修正范式：**
```javascript
// ✅ 正确：使用 try-finally 确保资源释放
function processImage() {
    let img = null;
    try {
        img = $screen.getScreen();
        // 处理图片...
        return result;
    } finally {
        if (img != null) {
            img.recycle();  // 确保释放
        }
    }
}
```

## 五、逻辑错误

### 5.1 空指针错误

| 错误场景 | 错误代码 | 修正代码 |
|---------|---------|---------|
| 节点未找到就操作 | `node.click();` | `if(node != null) node.click();` |

**修正范式：**
```javascript
// ❌ 错误：未检查空值
let node = $act.selector().text("按钮").waitFirst();
node.click();  // node 可能为 null

// ✅ 正确：检查空值
let node = $act.selector().text("按钮").waitFirst();
if (node != null) {
    node.click();
} else {
    log("未找到按钮");
}
```

### 5.2 无限循环

| 错误场景 | 说明 |
|---------|------|
| while(true) 无退出条件 | 可能导致死循环 |

**修正方法：**
```javascript
// ❌ 错误：无限循环
while (true) {
    // 没有退出条件
}

// ✅ 正确：带退出条件
let maxRetry = 10;
let count = 0;
while (count < maxRetry) {
    // 执行操作
    if (success) break;
    count++;
}
```

## 六、性能错误

### 6.1 频繁截屏

| 错误场景 | 说明 |
|---------|------|
| 循环中频繁截屏 | 性能低下，应缓存或降低频率 |

**修正方法：**
```javascript
// ❌ 错误：频繁截屏
for (let i = 0; i < 100; i++) {
    let img = $screen.getScreen();  // 每次都截屏
    // 处理...
    img.recycle();
}

// ✅ 正确：降低截屏频率
for (let i = 0; i < 100; i++) {
    if (i % 10 == 0) {  // 每10次截屏一次
        let img = $screen.getScreen();
        // 处理...
        img.recycle();
    }
}
```

### 6.2 大量 OCR 操作

| 错误场景 | 说明 |
|---------|------|
| 全屏 OCR | 应缩小识别范围 |

**修正方法：**
```javascript
// ❌ 错误：全屏 OCR
let result = $ocr.detect();  // 识别整个屏幕

// ✅ 正确：指定范围
let result = $ocr.detect({
    region: [0, 0, 500, 200]  // 只识别指定区域
});
```

## 七、错误处理最佳实践

### 7.1 统一异常处理

```javascript
/**
 * 安全执行函数
 */
function safeExecute(fn, errorMsg = "操作失败") {
    try {
        return fn();
    } catch (e) {
        log(errorMsg + ": " + e);
        return null;
    }
}

// 使用示例
safeExecute(() => {
    $act.click(500, 800);
}, "点击失败");
```

### 7.2 重试机制

```javascript
/**
 * 带重试的执行
 */
function retry(fn, maxRetry = 3, delay = 1000) {
    for (let i = 0; i < maxRetry; i++) {
        try {
            return fn();
        } catch (e) {
            log(`执行失败 (第 ${i+1} 次): ${e}`);
            if (i < maxRetry - 1) {
                sleep(delay);
            }
        }
    }
    throw new Error("重试次数耗尽");
}
```

## 八、调试技巧

### 8.1 日志分级

```javascript
const LOG_LEVEL = {
    DEBUG: 0,
    INFO: 1,
    WARN: 2,
    ERROR: 3
};

let currentLevel = LOG_LEVEL.INFO;

function logDebug(msg) {
    if (currentLevel <= LOG_LEVEL.DEBUG) {
        log("[DEBUG] " + msg);
    }
}

function logError(msg) {
    if (currentLevel <= LOG_LEVEL.ERROR) {
        log("[ERROR] " + msg);
    }
}
```

### 8.2 节点调试

```javascript
/**
 * 调试节点信息
 */
function debugNode(node) {
    if (node == null) {
        log("节点为 null");
        return;
    }
    
    log("节点信息:");
    log("  包名: " + node.pkg());
    log("  类名: " + node.cls());
    log("  文本: " + node.text());
    log("  描述: " + node.desc());
    log("  位置: " + node.bounds());
    
    node.draw();  // 绘制节点位置
}
```

## 九、常见错误速查表

| 错误类型 | 错误现象 | 解决方法 |
|---------|---------|---------|
| API 拼写错误 | "xxx is not defined" | 检查 API 名称拼写 |
| 参数类型错误 | "xxx is not a function" | 检查参数类型 |
| 权限未申请 | 操作无效果 | 先申请权限 |
| 资源未释放 | 内存持续增长 | 调用 recycle() |
| 空指针错误 | "Cannot read property xxx of null" | 检查空值 |
| 死循环 | 脚本卡死 | 添加退出条件 |
| 异步未等待 | 操作顺序错乱 | 使用 async/await |
