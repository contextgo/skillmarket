---
name: $floaty-api
description: "$floaty API 参考 - 悬浮窗（可调节、应用级、系统级、选择范围）"
tags: [autogod, api, floaty]
---

# $floaty - 悬浮窗

对应官方文档：https://aigamepro.work/api_en/floaty.html

## 模块概述

`$floaty` 提供多种悬浮窗创建能力：可调节、应用级、系统级、范围选择。

**注意事项：**
- `getPermit()` 是阻塞方法，会一直等待权限
- 系统级悬浮窗可覆盖导航栏，但容易被游戏检测并闪退

## 函数清单

### 权限
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getPermit()` | boolean | 获取悬浮窗权限（阻塞） |
| `hasPermit()` | boolean | 是否有悬浮窗权限 |

### 悬浮窗创建
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `newAdj(xmlOrPath)` | AdjustableFloaty | 创建可调节悬浮窗 |
| `newApp(xmlOrPath)` | AppFloaty | 创建应用级悬浮窗 |
| `newApp(xmlOrPath, touchable)` | AppFloaty | 创建应用级悬浮窗（指定是否可触摸） |
| `newSys(xmlOrPath)` | SysFloaty | 创建系统级悬浮窗 |
| `newSys(xmlOrPath, touchable)` | SysFloaty | 创建系统级悬浮窗（指定是否可触摸） |
| `newSelect(callback)` | SelectFloaty | 创建范围选择器 |

### 关闭
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `closeAll()` | void | 关闭所有悬浮窗 |

## 悬浮窗类型说明

| 类型 | 说明 |
|------|------|
| AdjustableFloaty | 可调节大小和位置 |
| AppFloaty | 应用级，限制在应用内 |
| SysFloaty | 系统级，可覆盖全屏，易被检测 |
| SelectFloaty | 范围选择器，返回 rect 数据 |

## 代码示例

```javascript
// 权限检测
let hasPermit = $floaty.hasPermit();
if (hasPermit) {
    log("有悬浮窗权限");
}

// 获取权限（阻塞）
let permit = $floaty.getPermit();
if (permit) {
    log("获取到悬浮窗权限");
}

// 创建可调节悬浮窗
let adjFloaty = $floaty.newAdj("./res/layout/floaty_adj.xml");
// 也可直接写 XML 字符串
let adjFloaty = $floaty.newAdj(`<ui>...</ui>`);

// 创建应用级悬浮窗
let appFloaty = $floaty.newApp("./res/layout/floaty_app.xml");
let appFloaty = $floaty.newApp(`<ui>...</ui>`);

// 创建不可触摸的应用级悬浮窗
let appFloaty = $floaty.newApp("./res/layout/floaty_app.xml", false);

// 创建系统级悬浮窗（可覆盖导航栏）
let sysFloaty = $floaty.newSys("./res/layout/floaty_sys.xml");
let sysFloaty = $floaty.newSys(`<ui>...</ui>`);

// 创建不可触摸的系统级悬浮窗
let sysFloaty = $floaty.newSys("./res/layout/floaty_sys.xml", false);

// 创建范围选择器
$floaty.newSelect((rect) => {
    log("用户选择范围:", rect);
});

// 关闭所有悬浮窗
$floaty.closeAll();
```

## AdjustableFloaty 常用方法

```javascript
let adj = $floaty.newAdj("./floaty_adj.xml");
// 设置位置
adj.setGravity("center");  // left/right/center
adj.setSize(300, 200);
// 显示/关闭
adj.show();
adj.close();
```

## AppFloaty / SysFloaty 常用方法

```javascript
let floaty = $floaty.newApp("./floaty_app.xml");
// 操作元素
let btn = floaty.findViewById("btn1");
btn.on("click", () => {
    log("按钮被点击");
});
// 显示/关闭
floaty.show();
floaty.close();
```

## 注意事项

- `newSys` 在部分游戏中会被检测到并导致闪退
- `getPermit()` 每 30 秒请求一次权限，直到获取为止
- 推荐使用 `$permit.floaty()` 来单次获取权限