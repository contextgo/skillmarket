---
name: $root-api
description: "$root API 参考 - ROOT与Shell命令（手势、屏幕、进程、分辨率）"
tags: [autogod, api, root]
---

# $root - ROOT 与 Shell 命令

对应官方文档：https://aigamepro.work/api_en/root.html

## 模块概述

提供 ROOT 权限下的手势操作、屏幕控制、Shell 命令执行等能力。

## 函数清单

### 权限
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `hasPermit()` | boolean | 是否有 ROOT 权限 |
| `getPermit()` | boolean | 获取 ROOT 权限 |
| `enablePointer(enable)` | void | 启用/禁用指针位置显示 |

### 手势操作
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `click(x, y)` | void | 点击 |
| `click(x, y, dur)` | void | 点击（带时长） |
| `click(x, y, dur, delay)` | void | 点击（带时长+延迟） |
| `click([x, y])` | void | 点击（数组坐标） |
| `click(point)` | void | 点击（Point对象） |
| `click(point, dur)` | void | 点击（Point+时长） |
| `click(point, dur, delay)` | void | 点击（Point+时长+延迟） |
| `press(x, y)` | void | 长按 |
| `press(x, y, dur)` | void | 长按（带延迟） |
| `press(x, y, dur, delay)` | void | 长按（带时长+延迟） |
| `move(x1, y1, x2, y2)` | void | 滑动 |
| `move(x1, y1, x2, y2, dur)` | void | 滑动（带时长） |
| `move(x1, y1, x2, y2, dur, delay)` | void | 滑动（带时长+延迟） |

### 屏幕操作
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `lock()` | void | 锁屏 |
| `unlock()` | void | 解锁屏幕 |
| `power()` | void | 电源按键 |

### 系统控制
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `home()` | void | 返回主页 |
| `back()` | void | 返回按键 |
| `menu()` | void | 菜单按键 |
| `recent()` | void | 最近任务 |
| `input(text)` | void | 输入文本 |
| `key(keyName)` | void | 模拟按键 |

### 进程管理
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `killApp(pkgName)` | void | 杀死应用（需ROOT） |
| `lsRunningApps(callback)` | void | 列出所有运行中的应用 |

### 分辨率控制
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `setWmSize(width, height)` | void | 设置手机分辨率 |
| `setDpi(density)` | void | 设置手机 DPI |
| `resetWm()` | void | 重置分辨率与 DPI |

### ROOT Shell
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `exec(cmd)` | void | 执行 ROOT 命令 |
| `exeRootShell(cmd)` | void | 执行 ROOT 命令 |
| `exeRootShell(cmd, output)` | void | 执行（输出回调） |
| `exeRootShell(cmd, output, terminate)` | void | 执行（输出+终止回调） |
| `exeRootShell(cmd, output, terminate, complete)` | void | 执行（完整回调） |
| `exeRootShellSync(cmd)` | String | 同步执行 ROOT 命令 |
| `closeRootShell()` | void | 关闭 rootShell |

### 普通 Shell
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `exeShell(cmd)` | void | 执行免 ROOT 命令 |
| `exeShell(cmd, output)` | void | 执行（输出回调） |
| `exeShell(cmd, output, terminate)` | void | 执行（输出+终止回调） |
| `exeShell(cmd, output, terminate, complete)` | void | 执行（完整回调） |
| `closeShell()` | void | 关闭 shell |
| `closeAll()` | void | 关闭所有 |

## 代码示例

```javascript
// 权限
if ($root.hasPermit()) {
    $root.getPermit();
}

// 点击手势
$root.click(500, 800);
$root.click(500, 800, 1500);  // 长按1.5秒
$root.click([500, 800], 50, 2000);  // 数组坐标+延迟

// Point对象点击
let point = new org.opencv.core.Point(500, 800);
$root.click(point, 1500);

// 滑动
$root.move(500, 0, 500, 800, 500, 1000);

// 屏幕控制
$root.lock();
$root.unlock();
$root.power();

// 系统按键
$root.home();
$root.back();
$root.menu();
$root.recent();
$root.key("KEYCODE_POWER");

// 输入文本
$root.input("Hello AIGame!");

// ROOT 命令
$root.exeRootShell("ls /", (line) => {
    log(line);
}, (err) => {
    $log.e(err);
}, (exitCode) => {
    $log.i("退出码:", exitCode);
});

// 同步 ROOT 命令
let res = $root.exeRootShellSync("ls /");
let files = res.split("\n");

// 免 ROOT 命令
$root.exeShell("ls /sdcard/Pictures");

// 杀进程
$root.killApp("com.example.app");

// 列出运行中的应用
$root.lsRunningApps((pkg) => {
    log(pkg);
});

// 分辨率
$root.setWmSize(1080, 2200);
$root.setDpi(320);
$root.resetWm();
```

## 注意事项

- 大部分操作需要 ROOT 权限
- `killApp` 需要 ROOT 才能执行
- `exeRootShell` 执行危险命令（如 `rm -rf`）前请三思