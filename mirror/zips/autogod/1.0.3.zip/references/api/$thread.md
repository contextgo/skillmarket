---
name: $thread-api
description: "$thread API 参考 - 并发编程（线程、循环器、倒计时锁）"
tags: [autogod, api, thread]
---

# $thread - 并发编程

对应官方文档：https://aigamepro.work/api_en/thread.html

## 函数清单

### UI 线程
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `ui(runnable)` | void | 在 UI 线程中执行 |

### 线程管理
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `run(runnable)` | Threadx | 创建并运行线程 |
| `create(runnable)` | Threadx | 创建线程 |
| `create(name, runnable)` | Threadx | 创建命名线程 |
| `has(name)` | boolean | 是否存在指定名称的线程 |
| `get(name)` | Threadx | 获取已存在的线程 |
| `stop(threadx)` | void | 停止指定线程 |
| `stop(threadName)` | void | 停止指定名称的线程 |
| `stopAll()` | void | 停止所有线程（不包括循环器） |

### 循环执行器
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `loop(name, runnable)` | Threadx | 创建循环执行器 |
| `hasLoop(name)` | boolean | 是否存在循环执行器 |
| `stopLoop(name)` | void | 停止循环执行器 |
| `stopAllLoop()` | void | 停止所有循环执行器 |

### 倒计时锁
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `newCdLock(num)` | CdLock | 创建倒计时锁 |

## 代码示例

```javascript
// UI 线程
$thread.ui(() => {
    // UI 操作
});

// 创建并运行线程
let t1 = $thread.run(() => {
    // 耗时任务
});
t1.interrupt();

// 创建命名线程
let t1 = $thread.create("线程1", () => {
    for (let i = 0; i < 10; i++) {
        sleep(300);
        log(t1.getName() + "==>" + i);
    }
});
t1.start();

// 检查和获取线程
if ($thread.has("线程1")) {
    let t = $thread.get("线程1");
}

// 循环执行器
let loop = $thread.loop("循环1号", () => {
    sleep(1000);
    log("我还活着！");
});
loop.start();

// 停止循环
$thread.stopLoop("循环1号");
$thread.stopAllLoop();

// 停止所有线程
$thread.stopAll();

// 倒计时锁
let lock = $thread.newCdLock(5);
```

## 注意事项

- `stopAll()` 不会停止循环执行器线程
- `stopAllLoop()` 也会停止 `setInterval` 创建的循环执行器
- 线程名重复时会返回已存在的线程对象