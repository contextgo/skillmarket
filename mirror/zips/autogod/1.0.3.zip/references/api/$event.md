---
name: $event-api
description: "$event API 参考 - 事件监听（系统事件、无障碍事件、应用事件）"
tags: [autogod, api, event]
---

# $event - 事件监听

对应官方文档：https://aigamepro.work/api_en/event.html

## 模块概述

监听系统级和应用级事件，支持唯一监听器和监听器列表两种机制。线程安全。

## 监听器机制

| 类型 | 函数 | 说明 |
|------|------|------|
| 唯一监听器 | `on(name, callback)` | 全局唯一，后调覆盖前调；传null可取消 |
| 监听器列表 | `add(name, callback)` | 可多次添加，触发时全部调用 |

触发顺序：先调用唯一监听器，再调用监听器列表中的所有监听器。

## 事件分类

| 类别 | 说明 |
|------|------|
| 系统事件 | 不需要权限（部分例外，如蓝牙需要位置权限） |
| 无障碍事件 | 需要开启无障碍权限才能监听 |
| 软件内部事件 | 应用自身的事件 |

## 常用事件类型

```javascript
// WIFI 事件
$event.on("wifi", (data) => {
    log(data);
});

// 锁屏事件
$event.on("lock", null);  // 取消监听

// 音量键事件
$event.on("volume", (data) => {
    // 连续减音量可停止脚本
});

// 应用切换事件
$event.on("app", (data) => {
    // 当前应用切换时触发
});

// 屏幕事件
$event.on("screen", (data) => {
    // 屏幕亮/灭时触发
});
```

## 代码示例

```javascript
// 设置唯一监听器
$event.on("wifi", (data) => {
    log(data);
});

// 取消唯一监听器
$event.on("lock", null);

// 添加监听器到列表（可重复添加多个）
$event.add("wifi", (data) => {
    log("监听器1:", data);
});
$event.add("wifi", (data) => {
    log("监听器2:", data);
});

// 应用切换
$event.on("app", (data) => {
    log("切换到:", data.pkg);
});

// 屏幕状态
$event.on("screen", (data) => {
    if (data.on) {
        log("屏幕亮起");
    } else {
        log("屏幕熄灭");
    }
});
```

## 注意事项

- 唯一监听器全局只有一个，重复设置会覆盖
- `on(name, null)` 可取消唯一监听器
- 监听器列表在软件重启后会被清空
- 事件具体有哪些类型请参考官方 EventType 文档