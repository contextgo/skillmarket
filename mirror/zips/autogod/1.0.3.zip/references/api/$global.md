---
name: $global-api
description: "$global API 参考 - 全局函数（无需$前缀直接调用）"
tags: [autogod, api, global]
---

# $global - 全局函数

对应官方文档：https://aigamepro.work/api_en/global.html

## 模块概述

全局函数在调用时无需使用 `$` 前缀，直接写函数名即可。

## 函数清单

### 基础操作
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `sleep(ms)` | void | 睡眠（毫秒） |
| `tip(info)` | void | 提示 |
| `alert(title, msg)` | void | 对话框 |
| `showImg(img)` | void | 显示图片（路径或 Image 对象） |
| `curPkg()` | String | 获取无障碍检测到的包名 |
| `curCls()` | String | 获取无障碍检测到的活动名 |
| `curTime()` | long | 获取当前时间戳（毫秒） |

### 剪切板
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getClip()` | String | 获取剪切板内容（注意安卓13+隐私限制） |
| `setClip(text)` | void | 设置剪切板内容 |
| `hasClip()` | boolean | 是否有剪切板内容 |
| `clearClip()` | boolean | 清空剪切板内容 |

### 绘制（全局封装）
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `closeLog()` | void | 关闭绘制日志 |
| `closeDraw()` | void | 关闭绘制悬浮窗 |
| `clearDraw()` | void | 清空绘制（不关闭悬浮窗） |

### 日志
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `log(msg...)` | void | 控制台日志 |
| `print(msg...)` | void | 控制台日志 |
| `info(msg...)` | void | 悬浮土司提示（需悬浮窗权限） |
| `infoLog(msg...)` | void | 悬浮土司 + 控制台打印 |
| `toast(msg...)` | void | 系统土司（部分手机需通知权限） |
| `toastLog(msg...)` | void | 系统土司 + 控制台打印 |

### 随机数
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `random()` | float | 随机数（0-1） |
| `random(max)` | int | 随机数（0-max） |
| `random(min, max)` | int | 随机数（min-max） |

### 模块导入
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `require(path)` | JsObject | 导入模块 |

## 代码示例

```javascript
// 睡眠
sleep(1000);

// 对话框
alert("提示", "内容");

// 显示图片
showImg("/sdcard/Pictures/demo.png");
let img = $img.read("/sdcard/Pictures/demo.png");
showImg(img);

// 剪切板
let clip = getClip();
setClip("我是剪切板内容");
if (hasClip()) {
    log(getClip());
}
clearClip();

// 绘制
closeLog();
closeDraw();
clearDraw();

// 日志
log("信息");
info("悬浮提示");
infoLog("悬浮提示+控制台");
toast("系统土司");
toastLog("系统土司+控制台");

// 随机数
log(random());           // 0-1
log(random(10));         // 0-10
log(random(10, 30));     // 10-30

// 当前环境
log(curPkg());           // com.example.app
log(curCls());           // .MainActivity
log(curTime());          // 1747985594110

// 模块导入
let MyClass = require("mCls.js");
let obj = new MyClass();
```

## 注意事项

- 从安卓13开始，剪切板内容可能为敏感信息，获取可能为空
- 较高版本安卓系统中，剪切板无法后台获取
- `info()` 需要悬浮窗权限
- `toast()` 部分手机需要通知权限