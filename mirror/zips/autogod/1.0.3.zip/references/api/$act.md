---
name: $act-api
description: "$act API 参考 - 手势动作与触摸操作框架"
tags: [autogod, api, gesture]
---

# $act - 手势动作

对应官方文档：https://aigamepro.work/api_en/act.html

## 模块概述

`$act` 是一个高度封装的框架，集成了无障碍、$root、$szk 触摸方案，优先级为：`$root > $szk > 无障碍`。

所有 click、press、move 函数都会优先判断是否有 ROOT 权限，如果有则使用 $root 执行手势；之后判断是否有 Shizuku 权限；最后判断无障碍权限。

## 常量定义

无

## 函数清单

| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `hasPermit()` | boolean | 判断无障碍服务是否开启 |
| `getPermit()` | boolean | 获得无障碍服务（阻塞式） |
| `click(x, y)` | void | 点击坐标 |
| `click(x, y, dur)` | void | 点击坐标（带长按时长） |
| `click(x, y, dur, delay)` | void | 点击坐标（带长按时长+延迟） |
| `click(index)` | void | 点击坐标（数组形式） |
| `click(point)` | void | 点击坐标（Point对象） |
| `click(node)` | void | 点击节点 |
| `click(node, useAct)` | void | 点击节点（指定是否用act点击） |
| `press(x, y)` | void | 长按坐标 |
| `press(x, y, dur)` | void | 长按坐标（带时长） |
| `press(node)` | void | 长按节点 |
| `slide(startX, startY, endX, endY, duration)` | void | 模拟滑动 |
| `move(x1, y1, x2, y2)` | void | 滑动 |
| `move(node, dir)` | void | 滑动节点（方向） |
| `gesture(gesture)` | void | 单指手势 |
| `gesture(g1, g2)` | void | 双指手势 |
| `gesture(g1, g2, g3)` | void | 三指动作 |
| `gesture(g1, g2, g3, g4)` | void | 四指动作 |
| `createPath(paths, dur)` | AgPath | 构建路径对象 |
| `path(paths)` | void | 执行路径 |
| `home()` | void | 点击Home键 |
| `back()` | void | 返回 |
| `menu()` | void | 菜单键 |
| `recent()` | void | 近期任务 |
| `power()` | void | 长按电源键 |
| `lock()` | void | 锁屏 |
| `unlock()` | void | 唤醒屏幕 |
| `splitScreen()` | void | 分屏 |
| `settings()` | void | 设置 |
| `notifications()` | void | 通知 |
| `screenshot()` | void | 截屏 |
| `input(text)` | void | 输入文本 |
| `activity()` | String | 获得activity类名 |
| `activity(callback)` | void | 设置窗口变化监听 |
| `selector()` | UiSelector | 创建UI选择器 |
| `setDevDensity(density)` | void | 设置开发环境密度 |
| `setAdapt(usable)` | void | 启动分辨率适配 |
| `isOnlyAcc()` | boolean | 判断是否只使用无障碍 |
| `setOnlyAcc(onlyAcc)` | void | 设置只使用无障碍 |
| `setJitter(jitter)` | void | 设置抖动值 |
| `enableRoot(enableRoot)` | void | 启用/禁用$root |
| `isEnableRoot()` | boolean | 判断$root是否启用 |
| `enableSzk(enableSzk)` | void | 启用/禁用$szk |
| `isEnableSzk()` | boolean | 判断$szk是否启用 |

## 代码示例

```javascript
// 判断是否有权限
let hasPermit = $act.hasPermit();
$tip.show("是否获得无障碍", hasPermit);

// 基本点击
$act.click(500, 800);

// 长按（延迟一秒后点击，停留1500ms）
$act.click(500, 800, 1500, 100);

// 滑动
$act.move(500, 0, 500, 800, 500);

// 多指手势
$act.gesture(
    [centerX, centerY, centerX - 400, centerY - 400, 0, 500],
    [centerX, centerY, centerX + 400, centerY + 400, 0, 500]
);

// 点击节点
let node = $act.selector()
    .pkg("org.aigame.pro")
    .cls("android.widget.FrameLayout")
    .waitFirst();
if (node != null) {
    node.draw();
    $act.click(node);
}

// 窗口监听
$act.activity((name) => {
    log("当前界面==>", name);
});

// 创建选择器
let selector = $act.selector();
```

## 注意事项

- `getPermit()` 是阻塞式函数，请勿放在 UI 线程中操作
- 永久无障碍需要等待 1-5 秒自动授权
- 建议使用 `$permit.wza()` 函数在 UI 状态下申请无障碍