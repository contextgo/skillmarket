---
name: $sys-api
description: "$sys API 参考 - 系统工具（飞行模式、音量、剪切板、设备ID、保活）"
tags: [autogod, api, system]
---

# $sys - 系统工具

对应官方文档：https://aigamepro.work/api_en/sys.html

## 函数清单

### 飞行模式
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `airplane(enable)` | void | 设置飞行模式 |

### 音量控制
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `volume(mode, volume)` | void | 设置音量 |
| `volumeCtrl(enable)` | void | 启用/禁用音量控制（默认监听音量键可停止脚本） |

音量模式（前3字母可简写）：system/sys、ring/rin、music/mus、alarm/ala、notification/notif、call/call、dtmf/dtmf、accessibility/acc

### 剪切板
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getClip()` | String | 获取剪切板内容（安卓13+可能为空） |
| `setClip(text)` | void | 设置剪切板内容 |
| `hasClip()` | boolean | 是否有剪切板内容 |
| `clearClip()` | boolean | 清空剪切板内容 |

### 设备
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getDeviceId()` | String | 获取设备唯一标识 |

### 电池优化
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `ignorePower(pkgName)` | boolean | 是否忽略电池优化 |
| `requestIgnorePower(pkgName)` | void | 请求忽略电池优化 |

### 前台保活
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `stayAlive(enable)` | void | 开启/关闭前台保活服务 |
| `hasStayAlive()` | boolean | 是否开启前台保活服务 |

### 开发者指针
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `hasPointer()` | boolean | 是否开启指针位置显示 |
| `pointer(enable)` | void | 授权开启开发者指针（需ROOT/Shizuku） |

## 代码示例

```javascript
// 飞行模式
$sys.airplane(true);

// 音量控制
$sys.volume("system", 100);   // 系统音量
$sys.volume("ring", 50);      // 铃声
$sys.volume("music", 80);     // 媒体音量
$sys.volume("alarm", 100);   // 闹钟
$sys.volume("acc", 100);     // 无障碍音量

// 关闭音量键停止脚本功能
$sys.volumeCtrl(false);

// 剪切板
$sys.setClip("Hello AIGame!");
if ($sys.hasClip()) {
    let content = $sys.getClip();
    $tip.i(content);
}
$sys.clearClip();

// 设备ID
let id = $sys.getDeviceId();
log(id);

// 电池优化
let is = $sys.ignorePower("org.aigame.app");
$sys.requestIgnorePower("org.aigame.app");

// 前台保活
$sys.stayAlive(true);   // 开启
$sys.stayAlive(false);  // 关闭
if ($sys.hasStayAlive()) {
    log("保活服务已开启");
}

// 开发者指针
$sys.pointer(true);
sleep(1000);
if ($sys.hasPointer()) {
    alert("指针已开启");
}
```

## 注意事项

- 安卓13+ 剪切板内容可能为敏感信息，获取可能为空或失败
- 电池优化功能仅在低版本安卓系统上有效
- 开发者指针需要 ROOT 或 Shizuku 权限
- 音量控制配置不影响 `$event.on("volume", ...)` 事件监听