---
name: $screen-api
description: "$screen API 参考 - 屏幕操作（截屏、亮度、方向、分割）"
tags: [autogod, api, screen]
---

# $screen - 屏幕操作

对应官方文档：https://aigamepro.work/api_en/screen.html

## 模块概述

提供屏幕截屏、亮度调节、方向控制等功能。优先使用无障碍截屏（安卓11+），降级使用录屏权限。

## 函数清单

### 权限
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getPermit()` | boolean | 获取截屏权限（阻塞，等待获取成功） |
| `getPermitOnce()` | boolean | 获取截屏权限一次（非阻塞） |
| `hasPermit()` | boolean | 是否有截屏权限 |
| `hasRecord()` | boolean | 是否有录屏权限 |
| `onlyRecord(onlyRecord)` | void | 是否只用录屏权限（默认false优先无障碍） |

### 截屏
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getScreen()` | Image | 获取屏幕截屏 |

### 显示信息
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getWidth()` | int | 屏幕宽度 |
| `getHeight()` | int | 屏幕高度 |
| `getScreenInfo()` | ScreenInfo | 屏幕详细信息 |
| `info()` | ScreenInfo | 屏幕详细信息 |
| `getDensity()` | float | 屏幕密度因子 |

### 屏幕状态
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `isScreenOn()` | boolean | 屏幕是否亮屏 |
| `isScreenOff()` | boolean | 屏幕是否息屏 |

### 显示控制
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `bright(bright)` | void | 设置屏幕亮度（0-255） |
| `dir(degree)` | void | 设置屏幕方向（0/90/180/270/-1自动） |

### 截屏保存
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `save(path)` | void | 截屏并保存到指定路径 |

### 屏幕分割
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `split(tranCut, vertCut, index)` | Rect | 屏幕分割，返回指定索引范围 |

### 横竖屏控制
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `mustV()` | void | 强制竖屏截屏 |
| `mustH()` | void | 强制横屏截屏 |
| `cancelMust()` | void | 取消强制横竖屏 |

## 代码示例

```javascript
// 获取截屏权限
$screen.getPermit();

// 截屏
let img = $screen.getScreen();
$img.show(img);

// 截屏并保存
$screen.save("/sdcard/Pictures/截屏.png");

// 屏幕宽高
let w = $screen.getWidth();
let h = $screen.getHeight();
alert("屏幕尺寸", w + "x" + h);

// 屏幕信息
let info = $screen.info();
log(info);

// 密度
let density = $screen.getDensity();

// 屏幕状态
if ($screen.isScreenOn()) {
    toast("屏幕亮屏");
}

// 设置亮度
$screen.bright(100);

// 屏幕方向
$screen.dir(0);   // 强制竖屏
$screen.dir(90);  // 强制右转横屏
$screen.dir(180); // 强制倒置竖屏
$screen.dir(270); // 强制左转横屏
$screen.dir(-1);  // 自动旋转

// 屏幕分割（九宫格）
let region = $screen.split(3, 3, 8);
$draw.rect(region);

// 只用录屏权限
$screen.onlyRecord(true);

// 强制横竖屏
$screen.mustV();      // 强制竖屏截屏
$screen.mustH();      // 强制横屏截屏
$screen.cancelMust(); // 取消强制
```

## 注意事项

- 安卓15+ 用户获取录屏权限时需选中"整个屏幕"选项
- 屏幕方向旋转在部分模拟器上可能导致闪退
- `getWidth()` 和 `getHeight()` 会先获取屏幕所有信息，性能开销较大