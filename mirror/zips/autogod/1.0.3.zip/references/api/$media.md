---
name: $media-api
description: "$media API 参考 - 音频播放（MediaPlayer）"
tags: [autogod, api, media]
---

# $media - 媒体播放

对应官方文档：https://aigamepro.work/api_en/media.html

## 函数清单

| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `play(path)` | MediaPlayer | 播放音频（播放后自动回收资源） |
| `create()` | MediaPlayer | 创建媒体播放器 |
| `create(path)` | MediaPlayer | 创建并加载音频（失败返回null） |
| `setPath(mediaPlayer, path)` | boolean | 为播放器设置音频路径 |

## 代码示例

```javascript
// 直接播放（推荐，用于提示音）
$media.play("res/mTip.mp3");

// 创建播放器（用于需要控制的场景）
let mp = $media.create();
if (mp) {
    mp.start();                   // 开始播放
    mp.stop();                    // 停止
    mp.pause();                   // 暂停
    mp.isPlaying();               // 是否播放中
    mp.isLooping();               // 是否循环
    mp.getDuration();             // 总时长
    mp.getCurrentPosition();      // 当前进度
    mp.seekTo(30000);             // 跳转30秒
    mp.prepare();                 // 准备资源
    mp.reset();                   // 重置
    mp.release();                 // 释放资源
}

// 创建并加载
let mp2 = $media.create("res/bgm.mp3");
if (mp2) {
    mp2.start();
}

// 设置路径
let mp3 = $media.create();
$media.setPath(mp3, "res/bgm.mp3");
mp3.start();
```

## 注意事项

- `play()` 播放结束自动回收资源，无需手动 release
- 资源加载失败返回 null
- `setPath` 重复调用可能抛异常