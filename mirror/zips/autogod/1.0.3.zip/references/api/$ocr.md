---
name: $ocr-api
description: "$ocr API 参考 - 文字识别（PaddleOcr/PpOcrV5/GoogleMlkit）"
tags: [autogod, api, ocr]
---

# $ocr - 文字识别

对应官方文档：https://aigamepro.work/api_en/ocr.html

## 模块概述

支持三种 OCR 引擎：
- **ncnn（PaddleOcr）**：速度快，但部分手机可能识别混乱
- **mlkit（GoogleMlkit）**：速度较慢，准确率高，兼容性好（默认）
- **ppv5（PpOcrV5）**：2025年流行，支持中英文+特殊字符，精确度高

## 函数清单

### 引擎
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `v(name)` | void | 设置 OCR 引擎（ncnn/mlkit/ppv5） |

### 初始化
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `init()` | DetectResult | 初始化 OCR（mlkit 不需要） |

### 识别文字（完整）
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `detect(options)` | DetectResult | 识别屏幕文字（自动截屏） |
| `detect64(base64)` | DetectResult | 识别 base64 图片 |
| `detectPath(imgPath)` | DetectResult | 识别路径中的图片 |
| `detectImg(img)` | DetectResult | 识别图片对象 |
| `detectBitmap(bitmap)` | DetectResult | 识别位图对象 |

### 单行识别
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `line(options)` | String | 识别单行文字（去除空格换行） |
| `line(img)` | String | 识别单行文字（图片对象） |
| `line(img, x, y, w, h)` | String | 识别单行文字（指定区域） |

### 定位文字
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getPoint(word, options)` | Point | 识别文字并返回位置 |

### 轻量化（仅 ncnn/ppv5）
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `onlyRec(image)` | String | 只识别文字（不做位置检测） |
| `onlyRec(bitmap)` | String | 只识别文字（位图） |
| `onlyRec(path)` | String | 只识别文字（路径） |
| `onlyDet(image)` | String | 只检测位置（不识别文字） |
| `onlyDet(bitmap)` | String | 只检测位置（位图） |
| `onlyDet(path)` | String | 只检测位置（路径） |

## OcrOptions 配置

```javascript
let options = {
    region: [x, y, w, h],       // 识别范围（空则整屏）
    gray: true,                 // 灰度化（速度快，准确率低）
    color: "#EEEEEE",           // 二值化文字颜色
    threshold: 20,              // 二值化阈值（推荐20-50）
    save: true,                 // 是否保存识别图片
    savePath: "/sdcard/ocr.png",// 保存路径
    number: true                // 是否提取数字（用,号分隔）
};
```

## 代码示例

```javascript
// 设置引擎
$ocr.v("mlkit");  // 设置 mlkit 引擎

// 初始化
$ocr.init();

// 灰度化识别
let result = $ocr.detect({
    region: [0, 0, 200, 100],
    gray: true,
    save: true,
    savePath: "/sdcard/ocr.png"
});
if (result.isSuccess()) {
    log(result.result());
}

// 二值化识别
let result = $ocr.detect({
    region: [0, 0, 200, 100],
    color: "#EEEEEE",
    threshold: 20
});

// 识别 base64 图片
let result = $ocr.detect64(base64Str);

// 识别本地图片
let result = $ocr.detectPath("/sdcard/test.png");

// 识别图片对象
let img = $img.read("/sdcard/test.png");
let result = $ocr.detectImg(img);

// 获取位置并点击
let point = $ocr.getPoint("开始", {
    region: [0, 0, 500, 300],
    gray: true
});
if (point) {
    $act.click(point);
}

// 单行识别
let txt = $ocr.line({
    region: [0, 0, 200, 100],
    number: true
});

// 只识别文字（更快）
let word = $ocr.onlyRec("/sdcard/test.png");

// 只检测位置（最快）
let positions = $ocr.onlyDet("/sdcard/test.png");
```

## 注意事项

- mlkit 不需要初始化
- `onlyRec` / `onlyDet` 是 ncnn/ppv5 独有功能
- 灰度化适合简单背景，二值化适合复杂背景
- 传入的 Bitmap/Image 不会自动回收，需手动释放