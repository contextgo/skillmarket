---
name: $color-api
description: "$color API 参考 - 颜色操作（内置常量、找色、相似度、通道解析、主题色）"
tags: [autogod, api, color]
---

# $color - 颜色操作

对应官方文档：https://aigamepro.work/api_en/color.html

## 内置常量

| 常量 | 说明 |
|------|------|
| `BLACK` | 黑色 |
| `DGRAY` | 深灰色 |
| `GRAY` | 灰色 |
| `LGRAY` | 浅灰色 |
| `WHITE` | 白色 |
| `RED` | 红色 |
| `GREEN` | 绿色 |
| `BLUE` | 蓝色 |
| `YELLOW` | 黄色 |
| `CYAN` | 青色 |
| `MAGENTA` | 品红 |
| `TRANSPARENT` | 透明 |

## 函数清单

### 找色
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `find(img, color)` | Point | 查找颜色位置 |
| `find(img, color, threshold)` | Point | 查找颜色（阈值） |
| `find(img, color, threshold, region)` | Point | 范围找色 |
| `findAll(img, color)` | Point[] | 查找所有匹配位置 |
| `findAll(img, color, threshold)` | Point[] | 查找所有（阈值） |
| `findAll(img, color, threshold, region)` | Point[] | 范围找所有 |

### 相似度
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `similar(c1, c2)` | double | 计算颜色相似度 |

### 颜色解析
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `parse(color)` | int | 解析颜色值（支持#RRGGBB和主题色） |
| `parse(r, g, b)` | int | 解析 RGB |
| `rgb(red, green, blue)` | int | 通过 RGB 通道获得颜色值 |
| `argb(alpha, red, green, blue)` | int | 通过 ARGB 通道获得颜色值 |
| `str(color)` | String | 颜色值转6位字符（#RRGGBB） |
| `toString(color)` | String | 颜色值转8位字符（#AARRGGBB） |

### 通道提取
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `a(color)` | int | 提取 A 通道值 |
| `r(color)` | int | 提取 R 通道值 |
| `g(color)` | int | 提取 G 通道值 |
| `b(color)` | int | 提取 B 通道值 |

### 颜色调整
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `setAlpha(color, alpha)` | int | 设置颜色透明度（0-255） |
| `brighter(color)` | int | 获取较亮颜色 |
| `darker(color)` | int | 获取较暗颜色 |

### 比较
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `equals(c1, c2)` | boolean | 比较两个颜色是否相等 |

### 主题
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `isDarkTheme()` | boolean | 是否是深色主题 |
| `isColor(colorStr)` | boolean | 判断颜色格式是否正确 |

## 主题色字符串（动态获取）

`colorPrimary`、`colorSurface`、`colorOnSurface`、`colorOnPrimary`、`colorPrimaryContainer`、`colorOnPrimaryContainer`、`colorSecondary`、`colorOnSecondary`、`colorSecondaryContainer`、`colorOnSecondaryContainer`、`colorTertiary`、`colorOnTertiary`、`colorTertiaryContainer`、`colorOnTertiaryContainer`、`colorError`、`colorErrorContainer`、`colorOnErrorContainer`、`colorOnBackground`、`colorSurfaceVariant`、`colorOnSurfaceVariant`、`colorOutline`、`colorOutlineVariant`、`colorPrimaryInverse`

## 代码示例

```javascript
// 找色
let img = $screen.getScreen();
let point = $color.find(img, "#a55978", 5, [300, 200, 500, 500]);
if (point != null) {
    $draw.cross(point);
    sleep(3000);
}
img.close();

// 找所有颜色位置
let result = $color.findAll(screenImg, "#d28384", 5);
for (let index of result) {
    $draw.dot(index);
}

// 相似度
let sim = $color.similar("#1E1F22", "#2B2D30");

// 解析颜色
let c = $color.parse("#1E1F22");
let c = $color.parse("colorPrimary");  // 主题色
let c = $color.rgb(105, 78, 230);
let c = $color.argb(255, 105, 78, 230);

// 颜色转换
$color.str(-166780);      // "#000000"
$color.toString(-166780); // "#00000000"

// 通道提取
let a = $color.a("#357C94");
let r = $color.r("#357C94");
let g = $color.g("#357C94");
let b = $color.b("#357C94");

// 颜色调整
let c = $color.setAlpha($color.parse("#1E1F22"), 100);
let c = $color.brighter($color.parse("#1E1F22"));
let c = $color.darker($color.parse("#1E1F22"));

// 比较
let same = $color.equals("#1E1F22", -14803166);
if (same) toast("颜色相同");

// 主题检测
if ($color.isDarkTheme()) toast("深色主题");
```