---
name: $ag-api
description: "$ag API 参考 - 图色框架（找图/等图/血条/多点找色）"
tags: [autogod, api, image-color]
---

# $ag - 图色框架

对应官方文档：https://aigamepro.work/api_en/ag.html

## 模块概述

集成找图、找色、血条检测的图色框架。自动截屏后进行图像/颜色匹配，支持调试模式。

## 函数清单

### 调试
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `setDebug(debug)` | void | 开启/关闭调试模式（默认开启，找到图片/颜色会在屏幕绘制位置） |
| `closeDraw()` | void | 关闭绘制的图案 |

### 找图
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `findImg(options)` | Point | 在屏幕上寻找图片（自动截屏） |
| `findImgClick(options)` | Point | 寻找图片并点击 |
| `findImgInRegions(options)` | Point, int | 在多个范围内寻找图片（返回位置和下标） |
| `findImgsOne(options)` | Point, int | 多组图片数据，找任意一个（返回位置和下标） |

### 等图
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `waitImg(options)` | Point | 等待图片出现 |
| `waitImg(options, failCallback)` | Point | 等待图片（失败回调） |
| `waitImgClick(options)` | Point | 等待图片并点击 |
| `waitImgClick(options, failCallback)` | Point | 等待图片并点击（失败回调） |
| `waitImgsOne(options)` | Point, int | 多组等待，返回匹配的一个 |
| `waitImgsOne(options, failCallback)` | Point, int | 多组等待（失败回调） |
| `clickImgWhileNot(options)` | Point | 循环点击图片直到消失 |
| `clickImgWhileNot(options, failCallback)` | Point | 循环点击（失败回调） |

### 找色
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `findColor(options)` | Point | 查找颜色 |
| `findColorClick(options)` | Point | 查找颜色并点击 |
| `findColorInRegions(options)` | Point | 在多个范围内找色 |
| `findColorsOne(options)` | Point | 多组颜色匹配任意一个 |

### 等色
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `waitColor(options)` | Point | 等待颜色出现 |
| `waitColor(options, failCallback)` | Point | 等待颜色（失败回调） |
| `waitColorClick(options)` | Point | 等待颜色并点击 |
| `waitColorClick(options, failCallback)` | Point | 等待颜色并点击（失败回调） |
| `waitColorWhileNot(options, failCallback)` | void | 等待颜色消失 |
| `waitMultiColors(options)` | Point | 等待多点色 |
| `waitMultiColors(options, failCallback)` | Point | 等待多点色（失败回调） |
| `waitMultiColorsClick(options)` | Point | 等待多点色并点击 |

### 血条检测
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `bloodPercent(options)` | int | 血条检测（返回-1到100，为-1表示无血量） |

## options 参数说明

```javascript
// 通用找图选项
let options = {
    path: "/sdcard/Pictures/t01.png",  // 必填：图片路径
    region: [x, y, w, h],                // 可选：范围（4位，后两位不能为0）
    similar: 0.8,                         // 可选：相似度（最小0.3）
    trans: false,                         // 可选：是否找透明背景图片
    px: 0,                               // 可选：点击位置x偏移
    py: 0,                               // 可选：点击位置y偏移
    // 等待专用
    ensure: false,                        // 可选：找到后是否确认
    ensureMode: "once",                   // 可选：once=任一次成功，more=全部成功
    ensureTimes: 3,                       // 可选：确认次数
    ensureDur: 300,                       // 可选：确认间隔（ms）
    waitTimes: 75,                        // 可选：等待次数
    waitDur: 800                          // 可选：等待间隔（ms）
};

// 找色选项
let colorOptions = {
    color: "#ff0000,#00ff00",  // 必填：颜色（多个用,分隔）
    threshold: 5,               // 可选：偏差值（默认5）
    region: [x, y, w, h]       // 可选：范围
};

// 多点找色
let mcOptions = {
    multiColors: [
        [px, py, "#FF0000", 5],  // px/py是相对主颜色的偏移
        [-54, -13, "#db0306", 5],
    ],
    color: "#000000",   // 主颜色
    threshold: 5,
    region: [x, y, w, h]
};

// 血条检测
let bloodOptions = {
    region: [x, y, w, h],        // 必填：血条范围
    color: "#ff0000,#ff0000",    // 必填：颜色
    threshold: 5                  // 可选：偏差值
};
```

## 代码示例

```javascript
// 简单找图
let point = $ag.findImg({
    path: "/sdcard/Pictures/close.png",
    region: [0, 0, 500, 500],
    similar: 0.8
});

// 找图并点击
let point = $ag.findImgClick({
    path: "/sdcard/Pictures/start.png"
});

// 等待图片
let point = $ag.waitImg({
    path: "/sdcard/Pictures/ready.png",
    waitTimes: 60,
    waitDur: 1000
});

// 等待图片（失败回调）
let point = $ag.waitImgClick({
    path: "/sdcard/Pictures/confirm.png",
    px: -10,  // 点击偏左一点
}, (times) => {
    log("第" + times + "次未找到");
});

// 找多组图片之一
let result = $ag.findImgsOne({
    data: [
        { path: "/res/ad1.png", region: [0, 0, 500, 300], similar: 0.8 },
        { path: "/res/ad2.png", region: [200, 400, 300, 300], similar: 0.8 }
    ]
});
log("找到第", result.index, "个图片，位置:", result.point);

// 多范围找图（广告关闭按钮）
let result = $ag.findImgInRegions({
    path: "/res/close.png",
    region: [
        [0, 0, 200, 200],
        [600, 0, 200, 200],
        [300, 500, 300, 300]
    ],
    similar: 0.85
});

// 循环点击直到消失
$ag.clickImgWhileNot({
    path: "/sdcard/Pictures/close.png",
    waitDur: 500
});

// 找色
let point = $ag.findColor({
    color: "#ff0000",
    region: [0, 0, 500, 500],
    threshold: 5
});

// 多点找色
let point = $ag.findMultiColors({
    multiColors: [
        [0, 0, "#FF0000", 5],
        [-54, -13, "#db0306", 5],
    ],
    color: "#e70216",
    threshold: 5,
    region: [0, 0, 400, 400]
});

// 血条检测
let percent = $ag.bloodPercent({
    region: [300, 50, 200, 20],
    color: "#ff0000",
    threshold: 5
});
if (percent > 50) {
    log("血量充足:", percent + "%");
}
```

## 注意事项

- 多点找色无法完美适配全分辨率（相对位置写死）
- `waitImg` 每次找图失败都会执行回调
- `findImgsOne` 找到任意一个就立即返回
- `clickImgWhileNot` 适合卡顿场景的关闭按钮操作