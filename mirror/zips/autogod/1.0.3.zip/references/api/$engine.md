---
name: $engine-api
description: "$engine API 参考 - 脚本引擎（任务调度、运行/暂停/停止脚本）"
tags: [autogod, api, engine]
---

# $engine - 脚本引擎

对应官方文档：https://aigamepro.work/api_en/engine.html

## 模块概述

全局唯一的脚本引擎对象，负责脚本的运行、暂停、继续、停止等任务调度操作。

## 重要提示

- `runCode(源码)` 在开发环境可用，但**打包后的 APK 代码会被混淆**，直接传源码无法执行
- 打包后应使用 `$engine.run(项目中js路径)` 来执行代码
- 打包后想执行源码，需通过 AG 服务器后端接口将源码转换为混淆码

## 函数清单

### 运行
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `run(path)` | String (taskID) | 运行脚本路径 |
| `run(jsFile)` | String (taskID) | 运行脚本文件 |
| `runCode(code)` | String (taskID) | 运行代码字符串 |
| `runCode(path, code)` | String (taskID) | 运行代码（指定上下文路径） |

### 暂停/继续
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `pause(id)` | void | 暂停指定任务 |
| `start(id)` | void | 继续运行暂停的任务 |
| `isPause(id)` | boolean/null | 判断任务是否暂停（null=未找到） |

### 停止
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `stop(id)` | void | 停止指定任务 |
| `stopAll()` | void | 停止所有任务 |
| `stopAll(exit)` | void | 停止所有任务（是否退出应用） |

### 列表
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `ls()` | JsTaskInfo[] | 列出所有任务信息 |
| `lsTask()` | $task[] | 获取任务列表 |
| `has(id)` | boolean | 任务是否存在 |

## 代码示例

```javascript
// 运行脚本
let id = $engine.run("/sdcard/脚本.js");
let id = $engine.run($file.open("/sdcard/脚本.js"));

// 运行代码字符串
let id = $engine.runCode(`
    alert("提示", "我被运行了");
`);

// 运行代码（指定上下文路径）
let id = $engine.runCode("/sdcard/main.js", `
    alert("提示", "我被运行了");
`);

// 暂停和继续
let id = $engine.run("/sdcard/脚本.js");
$engine.pause(id);
sleep(2000);
$engine.start(id);

// 判断暂停状态
let isPause = $engine.isPause(id);
if (isPause != null) {
    if (isPause) {
        info("任务已暂停");
    } else {
        info("任务正在跑");
    }
}

// 列出任务
let tasks = $engine.ls();
for (let task of tasks) {
    log(task);
}

// 停止任务
let id = $engine.run("/sdcard/脚本.js");
$engine.stop(id);

// 停止所有
$engine.stopAll();     // 停止所有任务
$engine.stopAll(true); // 停止所有任务并杀死APP

// 判断任务是否存在
let hasTask = $engine.has(id);
if (hasTask) {
    $engine.stop(id);
}
```

## 注意事项

- `isPause()` 返回：`false`=运行中，`true`=暂停中，`null`=未找到
- 任务结束后会自动销毁
- 打包 APK 后无法直接用 `runCode(源码)` 执行