---
name: $file-api
description: "$file API 参考 - 文件系统操作（读写、拷贝、移动、媒体库文件）"
tags: [autogod, api, file-system]
---

# $file - 文件系统

对应官方文档：https://aigamepro.work/api_en/file.html

## 模块概述

`$file` 用于操作外部存储(sdcard)文件。部分函数也支持读取 assets 目录（打包后的项目目录）下的文件。

**assets 目录限制：**
- 文件夹不能以 `_` 开头（安卓机制）
- 仅支持读取操作（罗列文件、拷贝文件、读取文件）

## 函数清单

### 路径与判断
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `uri(path)` | Uri | 通过 FileProvider 获得 Uri 对象 |
| `open(path)` | File | 获得 File 对象（拼接路径） |
| `isFile(path)` | boolean | 是否是文件 |
| `isDir(path)` | boolean | 是否是文件夹 |
| `isEmptyDir(path)` | boolean | 是否是空文件夹 |
| `isEmpty(path)` | boolean | 是否是空文件或文件夹 |
| `exists(path)` | boolean | 路径是否存在 |
| `join(parent, child)` | String | 路径拼接 |
| `join(path[])` | String | 拼接路径数组 |

### 目录与文件创建
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `create(path)` | boolean | 创建文件（目录不存在自动创建） |
| `mkdir(path)` | boolean | 创建目录 |
| `ensureDir(path)` | String | 确保文件夹存在 |

### 读取（支持 assets）
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `read(path)` | String | 读取文件内容 |
| `read(path, encoding)` | String | 读取文件（指定编码） |
| `reads(path)` | String[] | 读取文件行列表 |
| `readByte(path)` | byte[] | 读取文件字节 |

### 写入（仅外部存储）
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `write(content, path)` | void | 写入文件 |
| `write(content, path, encoding)` | void | 写入文件（指定编码） |
| `writes(lines, path)` | void | 写入行数据 |
| `writeByte(bytes, path)` | void | 写入二进制文件 |

### 追加（仅外部存储）
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `add(content, path)` | void | 追加文件内容（自动换行） |
| `adds(lines, path)` | void | 追加行数据（自动换行） |

### 操作
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `copy(src, dest)` | void | 拷贝文件（支持 assets → sdcard） |
| `move(src, dest)` | boolean | 移动文件或文件夹 |
| `rename(src, dest)` | boolean | 重命名文件 |

### 文件信息
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `size(path)` | long | 获取文件大小（字节） |
| `sizeStr(size)` | String | 获取文件可视化大小 |
| `sizeStr(path)` | String | 获取文件可视化大小（路径） |
| `name(path)` | String | 获取文件名称（含后缀） |
| `mainName(path)` | String | 获取主文件名（不含后缀） |
| `ext(path)` | String | 获取后缀名 |

### 罗列
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `ls(path)` | String[] | 罗列文件 |
| `ls(path, filter)` | String[] | 罗列文件（带过滤） |
| `loopFiles(path, accept)` | File[] | 递归遍历文件 |

### 媒体库文件
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `lsVideo()` | VideoInfo[] | 罗列视频文件（需权限） |
| `lsAudio()` | AudioInfo[] | 罗列音频文件（需权限） |
| `lsImages()` | ImageInfo[] | 罗列图片文件（需权限） |

### 目录路径
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `sd()` | String | 获取 sdcard 路径 |
| `getDir(name)` | String | 获取公共目录路径 |
| `getDir(name, isPublic)` | String | 获取目录路径（指定公共/私有） |

### 刷新与删除
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `del(path)` | boolean | 删除文件或文件夹（三次重试） |
| `flushSd(successCallback, failCallback)` | void | 刷新 sd 卡媒体库 |
| `flush(filePath, sc, fc)` | void | 刷新媒体文件 |

### 热更新
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `hotUpdate(path, data)` | void | 热更新文件 |
| `delHotUpdate(path)` | void | 删除热更新文件 |

## 信息类型定义

```javascript
// VideoInfo
{ id, name, path, size, dur, time }

// AudioInfo
{ id, name, path, size, dur, artist, album, time }

// ImageInfo
{ id, name, path, size, width, height, time }
```

## 目录类型可选项

`pictures/图片`、`downloads/下载`、`dcim`、`music/音乐`、`movies/视频`、`documents/文档`、`alarms/闹钟`、`notifications/通知`、`podcasts/播客`、`ringtones/铃声`

## 代码示例

```javascript
// 路径操作
let file = $file.open("res");
let path = $file.join("sdcard", "Pictures");
let path = $file.join(["sdcard", "Pictures", "项目", "res"]);

// 判断
log($file.isFile("main.js"));  // true
log($file.isDir("res"));       // true
log($file.exists("./a.js"));   // true

// 创建文件/目录
$file.create("./测试/a.js");
$file.mkdir("./测试/b");
$file.ensureDir("./测试/c/a.js");

// 读取（支持 assets）
let content = $file.read("./main.js");
let content = $file.read("./main.js", "gbk");
let list = $file.reads("./main.js");
let data = $file.readByte("./main.js");

// 写入
$file.write("我是内容", "./code/a.js");
$file.writes(["内容1", "内容2"], "./code/a.js");

// 追加
$file.add("追加内容\n", "./code/a.js");
$file.adds(["追加01", "追加02"], "./code/a.js");

// 拷贝（支持 assets → sdcard）
$file.copy("res/a.txt", "/sdcard/Pictures/res/a.txt");

// 移动
let ok = $file.move("modules", "xml");
let ok = $file.move("res/code.js", "/");

// 重命名
let ok = $file.rename("run.js", "res/code.js");

// 文件信息
let size = $file.size("./a.js");
let sizeStr = $file.sizeStr("./a.js");  // "6 B"
let fn = $file.name("./xml/mFile.txt");  // "mFile.txt"
let fn = $file.mainName("./xml/mFile.txt");  // "mFile"
let ext = $file.ext("./xml/mFile.txt");  // "txt"

// 罗列文件
let arr = $file.ls("res");
$file.ls("res", (path) => { return true; });

// 媒体库
let videos = $file.lsVideo();
let audios = $file.lsAudio();
let images = $file.lsImages();

// 删除
$file.del("tools");
$file.del("main.js");

// sdcard路径
let sd = $file.sd();  // /storage/emulated/0

// 获取目录
let pic = $file.getDir("图片");
let vid = $file.getDir("视频", true);

// 刷新媒体库
$file.flushSd(
    () => { log("刷新成功"); },
    () => { log("刷新失败"); }
);
$file.flush("/sdcard/Pictures/新建.png");

// 热更新
$file.hotUpdate("main.js", "新内容");
$file.delHotUpdate("main.js");
```

## 注意事项

- assets 中的文件夹不能以 `_` 开头
- assets 只支持读取操作
- `move` 传入的是目录时会移动目录下所有文件
- `del` 有三次重试机制，强制删除
- 热更新文件优先于项目文件