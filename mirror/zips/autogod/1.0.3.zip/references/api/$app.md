---
name: $app-api
description: "$app API 参考 - 应用管理（安装/卸载/启动/包名检测）"
tags: [autogod, api, app]
---

# $app - 应用管理

对应官方文档：https://aigamepro.work/api_en/app.html

## 函数清单

### 安装与卸载
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `install(path)` | boolean | 安装应用（路径） |
| `install(url)` | boolean | 安装应用（URL下载） |
| `install(path, cbSuc, cbFail)` | void | 安装（成功/失败回调） |
| `uninstall(pkgName)` | boolean | 卸载应用 |

### 启动
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `launch(pkgName)` | boolean | 启动应用 |
| `launch(pkgName, clsName)` | boolean | 启动应用指定类 |

### 包名检测
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getPkgName(appName)` | String | 获取包名（通过应用名称） |
| `isInstall(pkgName)` | boolean | 应用是否安装 |

### 应用信息
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getAppName(pkgName)` | String | 通过包名获取应用名称 |
| `getAppVersionName(pkgName)` | String | 获取应用版本名称 |
| `getAppVersionCode(pkgName)` | int | 获取应用版本号 |
| `getAppPath(pkgName)` | String | 获取应用安装路径 |
| `getAppIcon(pkgName)` | Drawable | 获取应用图标 |
| `getAppInfo(pkgName)` | AppInfo | 获取应用完整信息 |

### 入口检测
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `hasActivity(pkgName)` | boolean | 应用是否有主入口 |
| `hasActivity(pkgName, clsName)` | boolean | 应用是否有指定 Activity |
| `getLauncherActivity(pkgName)` | String | 获取主入口 Activity 名称 |

### 当前应用
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `cur()` | String | 获取当前前台应用包名 |

## AppInfo 返回字段

```javascript
{
    name: "应用名称",
    packageName: "com.example.app",
    versionName: "1.0.0",
    versionCode: 100,
    path: "/data/app/com.example.app/base.apk",
    icons: [...],
    firstInstallTime: 时间戳,
    lastUpdateTime: 时间戳
}
```

## 代码示例

```javascript
// 安装应用
let ok = $app.install("/sdcard/app.apk");
let ok = $app.install("https://example.com/app.apk");

// 安装（带回调）
$app.install("/sdcard/app.apk",
    () => { log("安装成功"); },
    () => { log("安装失败"); }
);

// 卸载
$app.uninstall("com.example.app");

// 启动
$app.launch("com.example.app");
$app.launch("com.example.app", "com.example.MainActivity");

// 包名检测
let pkg = $app.getPkgName("微信");
if ($app.isInstall(pkg)) {
    log("已安装:", pkg);
}

// 应用信息
let name = $app.getAppName("com.example.app");
let ver = $app.getAppVersionName("com.example.app");
let code = $app.getAppVersionCode("com.example.app");
let path = $app.getAppPath("com.example.app");

// 应用图标
let icon = $app.getAppIcon("com.example.app");

// 完整信息
let info = $app.getAppInfo("com.example.app");
log(info.name, info.versionName, info.firstInstallTime);

// 入口检测
if ($app.hasActivity("com.example.app")) {
    log("有主入口");
}
let act = $app.getLauncherActivity("com.example.app");

// 当前前台应用
let pkg = $app.cur();
log("当前应用:", pkg);
```

## 注意事项

- 安装需要存储权限
- `install(url)` 会先下载再安装
- 卸载需要用户确认