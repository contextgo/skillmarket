---
name: $img-api
description: "$img API 参考 - 图片处理（读取、裁剪、缩放、找图、颜色识别）"
tags: [autogod, api, image]
---

# $img - 图片操作

对应官方文档：https://aigamepro.work/api_en/img.html

## 函数清单

### 读取与构建
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `read(path)` | Image | 读取图片（支持相对路径） |
| `read(file)` | Image | 读取图片（File对象） |
| `open(path)` | Image | 构建img对象（v1.2.4+） |
| `open(bitmap)` | Image | 构建img对象（v1.2.4+） |
| `save(image, path)` | void | 保存图片（默认PNG，质量100） |
| `save(image, path, format, quality)` | void | 保存图片（指定格式质量） |
| `toBase64(image)` | String | 图片转Base64 |
| `toBase64(path)` | String | 路径转Base64 |
| `readBase64(base64)` | Image | Base64加载为图片 |
| `show(image)` | void | 显示图片 |
| `show(path)` | void | 显示图片（路径） |

### 图片处理
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `clip(image, x, y, w, h)` | Image | 裁剪图片 |
| `resize(image, w, h)` | Image | 调整尺寸（默认LINEAR插值） |
| `resize(image, w, h, interpolation)` | Image | 调整尺寸（指定插值） |
| `scale(image, scaleX, scaleY)` | Image | 缩放图片 |
| `scale(image, scaleX, scaleY, interpolation)` | Image | 缩放图片（指定插值） |
| `rotate(image)` | Image | 旋转90° |
| `rotate(image, degree)` | Image | 旋转指定角度 |
| `rotate(image, degree, x, y)` | Image | 绕中心点旋转 |
| `concat(img1, img2, dir)` | Image | 拼接图片（left/right/top/bottom） |
| `flip(image)` | Image | 左右翻转 |
| `flip(image, sx, sy)` | Image | 水平翻转 |
| `upside(image)` | Image | 上下翻转 |
| `putTop(bigImg, smallImg, x, y)` | Image | 放置小图到大图上 |

### 图像处理
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `gray(image)` | Image | 灰度化 |
| `threshold(image, thre)` | Image | 二值化 |
| `adaptiveThreshold(image, maxValue, adaptiveMethod, thresholdType, blockSize, C)` | Image | 自适应二值化 |
| `cvtColor(img, code)` | Image | 颜色空间转换 |
| `inRange(img, lowerBound, upperBound)` | Image | 图片二值化 |
| `blur(img, size, point, type)` | Image | 模糊处理 |
| `medianBlur(img, size)` | Image | 中值滤波 |
| `gaussianBlur(img, size, sigmaX, sigmaY, type)` | Image | 高斯模糊 |

插值方式（不区分大小写）：NEAREST, LINEAR, CUBIC, AREA, LANCZOS4, EXACT
模糊类型（不区分大小写）：CONSTANT, REPLICATE, REFLECT, WRAP, REFLECT_101, DEFAULT, ISOLATED

### 找图
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `findImg(bigImg, minImg)` | Point | 找图（返回中心点） |
| `findImg(bigImg, minImg, options)` | Point | 找图（详细参数） |
| `findImgAll(bigImg, minImg)` | Point[] | 找所有匹配位置 |
| `findImgAll(bigImg, minImg, options)` | Point[] | 找所有（详细参数） |

**options 参数：**
```javascript
{
    similar: 0.8,           // 相似度（0-1）
    region: [x, y, w, h],  // 搜索范围
    trans: false,            // 透明找图模式
    drawResult: true,       // 保存结果图
    savePath: "路径"        // 结果图保存路径
}
```

### 找色
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `findColor(image, color)` | Point | 查找颜色 |
| `findColor(image, color, threshold)` | Point | 查找颜色（阈值） |
| `findColor(image, color, threshold, x, y, w, h)` | Point | 范围找色 |
| `findColor(image, color, threshold, region)` | Point | 范围找色（数组） |
| `findMultiColors(image, region, color, threshold, colors)` | Point | 多点找色 |

## 代码示例

```javascript
// 读取与显示
let img = $img.read("/$img/res/p01.png");
$img.show(img);

// 裁剪
let cropped = $img.clip(img, 0, 0, 300, 200);

// 缩放
let scaled = $img.resize(img, 200, 200, "INTER_CUBIC");

// 旋转
let rotated = $img.rotate(img, 45, 100, 200);

// 拼接
let t1 = $img.read("/$img/res/t02.png");
let t2 = $img.read("/$img/res/t03.png");
t1 = $img.resize(t1, 300, 200);
t2 = $img.resize(t2, 300, 200);
let merged = $img.concat(t1, t2, "bottom");

// 灰度化
let gray = $img.gray(img);

// 二值化
let binary = $img.threshold(img, 150);

// 模糊
let blurred = $img.gaussianBlur(img, [15, 15], 0, 0, "WRAP");

// 找图
let point = $img.findImg(img1, img2, {
    similar: 0.8,
    region: [0, 0, 500, 600],
    drawResult: true,
    savePath: "/$img/img/result.png"
});
if (point) {
    log("找到位置:", point);
}

// 找所有
let points = $img.findImgAll(img1, img2, {
    similar: 0.8,
    region: [0, 0, 350, 280]
});
log("找到", points.length, "个匹配");

// 找色
let p = $img.findColor(img, "#d80005", 5);
log("颜色位置:", p);

// 多点找色
let p2 = $img.findMultiColors(img, [0], "#e70216", 5, [
    -54, -13, "#db0306", 5,
    -121, -13, "#dc0407", 5,
    -155, -18, "#d80306", 5,
]);

// 截屏保存
$screen.getPermit();
let screenImg = $screen.getScreen();
$img.save(screenImg, "/$img/img/s05.png");
```