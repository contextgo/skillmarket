---
name: $storage-api
description: "$storage API 参考 - 应用内存储（键值对、命名空间、持久化配置）"
tags: [autogod, api, storage]
---

# $storage - 应用内存储

对应官方文档：https://aigamepro.work/api_en/storage.html

## 模块概述

轻量级键值存储，用于应用内配置数据。应用卸载后数据清空。

## 函数清单

### 创建
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `create(namespace)` | $storage | 创建命名空间 |

### 通用
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `get(key)` | Object | 获取值（不存在返回null） |
| `get(key, defaultValue)` | Object | 获取值（默认值） |
| `put(key, value)` | void | 存放数据（通用） |
| `getAll()` | Object | 获取全部数据 |
| `has(key)` | boolean | 是否包含key |
| `clear()` | void | 删除全部数据 |
| `del(key)` | void | 删除指定key |

### 字符串
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getStr(key)` | String | 获取字符串（不存在返回null） |
| `getStr(key, defaultValue)` | String | 获取（默认值） |
| `getString(key)` | String | 获取字符串（等价于getStr） |
| `getString(key, defaultValue)` | String | 获取（默认值） |
| `putStr(key, value)` | void | 存放字符串 |
| `putString(key, value)` | void | 存放字符串 |

### 整数
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getInt(key)` | int | 获取整数（不存在返回-1） |
| `getInt(key, defaultValue)` | int | 获取（默认值） |
| `putInt(key, value)` | void | 存放整数 |

### 布尔
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getBool(key)` | boolean | 获取布尔（不存在返回false） |
| `getBool(key, defaultValue)` | boolean | 获取（默认值） |
| `getBoolean(key)` | boolean | 获取布尔（等价于getBool） |
| `getBoolean(key, defaultValue)` | boolean | 获取（默认值） |
| `putBool(key, value)` | void | 存放布尔 |
| `putBoolean(key, value)` | void | 存放布尔 |

### 浮点数
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getFloat(key)` | float | 获取浮点数（不存在返回-1.0） |
| `getFloat(key, defaultValue)` | float | 获取（默认值） |
| `putFloat(key, value)` | void | 存放浮点数 |

### 长整数
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getLong(key)` | long | 获取长整数（不存在返回-1） |
| `getLong(key, defaultValue)` | long | 获取（默认值） |
| `putLong(key, value)` | void | 存放长整数 |

### 字符串集合
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getStrSet(key)` | String[] | 获取集合（不存在返回空[]） |
| `getStrSet(key, defaultValue)` | String[] | 获取（默认值） |
| `putStrSet(key, value)` | void | 存放字符串集合 |

## 代码示例

```javascript
let storage = $storage.create("myApp");

// 通用
storage.put("MyStr", "字符串数据");
storage.get("MyStr", "默认值");

// 字符串
storage.putStr("name", "张三");
let name = storage.getStr("name", "匿名");

// 整数
storage.putInt("level", 10);
let level = storage.getInt("level", 0);

// 布尔
storage.putBool("enabled", true);
let enabled = storage.getBool("enabled", false);

// 浮点
storage.putFloat("score", 3.14159);
let score = storage.getFloat("score", 0.0);

// 长整数
storage.putLong("timestamp", 1747985594110);

// 集合
storage.putStrSet("tags", ["标签1", "标签2", "标签3"]);

// 检查和删除
if (storage.has("name")) {
    storage.del("name");
}
storage.clear();
```

## 注意事项

- 应用卸载后数据清空
- 命名空间名称一致即可跨脚本共享数据
- 不存在的key：`get`返回null，`getInt`返回-1，`getBool`返回false