---
name: $szk-api
description: "$szk API 参考 - Shizuku工具（免ROOT手势/Shell/分辨率控制）"
tags: [autogod, api, shizuku]
---

# $szk - Shizuku 工具

对应官方文档：https://aigamepro.work/api_en/szk.html

## 模块概述

Shizuku 是一种不需要 ROOT 就能享受 ROOT 同等级权限的工具。提供手势操作、Shell 命令执行等功能。

## 函数清单

### 权限
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getPermit()` | void | 获取 Shizuku 权限 |
| `hasPermit()` | boolean | 判断 Shizuku 是否可用 |
| `waitPermit()` | boolean | 阻塞等待 Shizuku 权限连接 |
| `waitPermit(callback)` | void | 异步等待 Shizuku 权限 |
| `enablePointer(enable)` | void | 启用/禁用指针位置显示 |

### 手势操作
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `click(x, y)` | void | 点击 |
| `click(x, y, dur)` | void | 点击（持续时长） |
| `click(x, y, dur, delay)` | void | 点击（持续时长+点击前延迟） |
| `click([x, y])` | void | 点击（数组坐标） |
| `click([x, y], dur)` | void | 点击（数组+时长） |
| `click([x, y], dur, delay)` | void | 点击（数组+时长+延迟） |
| `click(point)` | void | 点击（Point对象） |
| `click(point, dur)` | void | 点击（Point+时长） |
| `click(point, dur, delay)` | void | 点击（Point+时长+延迟） |
| `press(x, y)` | void | 长按 |
| `press(x, y, dur)` | void | 长按（持续时长） |
| `press(x, y, dur, delay)` | void | 长按（时长+延迟） |
| `move(x1, y1, x2, y2)` | void | 滑动 |
| `move(x1, y1, x2, y2, dur)` | void | 滑动（时长） |
| `move(x1, y1, x2, y2, dur, delay)` | void | 滑动（时长+延迟） |

### 系统按键
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `home()` | void | 返回主页 |
| `back()` | void | 返回 |
| `menu()` | void | 菜单 |
| `recent()` | void | 最近任务 |
| `power()` | void | 电源按键 |
| `lock()` | void | 锁屏 |
| `unlock()` | void | 唤醒屏幕 |

### 输入
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `input(text)` | void | 输入文本 |

### 进程与分辨率
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `killApp(pkgName)` | void | 杀死应用 |
| `setWmSize(width, height)` | void | 设置分辨率 |
| `setDpi(density)` | void | 设置 DPI |
| `resetWm()` | void | 重置分辨率与 DPI |

### Shell 命令
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `exe(cmd)` | String | 执行命令并返回结果 |
| `exe(cmd, infoCallback, errorCallback)` | void | 执行（输出+错误回调） |
| `exe(cmd, infoCallback, errorCallback, endCallback)` | void | 执行（完整回调） |
| `exe(cmd, startCallback, infoCallback, errorCallback, endCallback)` | void | 执行（开始+完整回调） |

## 代码示例

```javascript
// 获取权限
$szk.getPermit();

// 判断权限
if ($szk.hasPermit()) {
    log("Shizuku 可用");
}

// 等待权限连接
let ok = $szk.waitPermit();

// 异步等待
$szk.waitPermit((success) => {
    log("Shizuku 连接", success ? "成功" : "失败");
});

// 点击手势
$szk.click(500, 800);
$szk.click(500, 800, 1000);  // 长按1秒
$szk.click([500, 800], 50, 2000);  // 数组坐标

// Point 对象
let point = new org.opencv.core.Point(500, 800);
$szk.click(point, 1000);

// 滑动
$szk.move(500, 0, 500, 800, 1000, 2000);

// 系统按键
$szk.home();
$szk.back();
$szk.lock();
$szk.unlock();
$szk.power();

// 输入文本
$szk.input("Hello Shizuku!");

// 杀进程
$szk.killApp("com.example.app");

// 分辨率
$szk.setWmSize(1080, 2200);
$szk.setDpi(320);
$szk.resetWm();

// Shell 命令
$szk.exe("input keyevent KEYCODE_POWER");

// Shell 带回调
$szk.exe("ls",
    (info) => { log(info); },
    (error) => { $log.e(error); },
    (result) => { log("执行结束:", result); }
);

// Shell 完整回调
$szk.exe("ls",
    () => { log("开始执行"); },
    (info) => { log(info); },
    (error) => { $log.e(error); },
    (result) => { log("结束:", result); }
);
```

## 注意事项

- `$szk` 提供免 ROOT 的高权限操作
- `waitPermit()` 需要先调用 `getPermit()` 后再使用
- Shizuku 未安装或不可用时 `waitPermit()` 返回 false