---
name: $tip-api
description: "$tip API 参考 - 阻塞式对话框（信息/输入/选择器/日期时间）"
tags: [autogod, api, dialog]
---

# $tip - 阻塞式对话框

对应官方文档：https://aigamepro.work/api_en/tip.html

## 模块概述

阻塞式对话框：在对话框处理完事件之前，后续代码不会执行。

## 函数清单

### 信息对话框
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `i(msg...)` | void | 信息对话框 |
| `v(msg...)` | void | 说明对话框 |
| `w(msg...)` | void | 警告对话框 |
| `e(msg...)` | void | 异常对话框 |
| `d(msg...)` | void | 调试对话框 |

### 文本提示
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `show(title, msg)` | void | 文本提示对话框 |
| `show(title, msg, click)` | void | 文本提示（确定回调） |
| `show(title, view)` | void | 自定义对话框（右上角关闭） |
| `show(title, view, click)` | void | 自定义对话框（确定关闭） |

### 输入对话框
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `input(title, callback)` | void | 输入对话框 |
| `input(title, def, callback)` | void | 输入对话框（默认值） |
| `input(title, hint, def, callback)` | void | 输入对话框（提示+默认值） |
| `inputInt(title, callback)` | void | 输入整数 |
| `inputInt(title, def, callback)` | void | 输入整数（默认值） |
| `inputInt(title, hint, callback)` | void | 输入整数（引导文字） |
| `inputInt(title, hint, def, callback)` | void | 输入整数（完整参数） |

### 选择对话框
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `one(title, items, callback)` | void | 单选对话框 |
| `more(title, items, callback)` | void | 多选对话框 |

### 日期时间选择
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `calendar(callback)` | void | 日期选择对话框 |
| `date(callback)` | void | 滚轮方式选择日期 |
| `clock(callback)` | void | 时间选择对话框（24小时制） |
| `time(callback)` | void | 滚轮方式选择时间 |

## 代码示例

```javascript
// 信息对话框
$tip.i("我是信息");
$tip.w("警告!");
$tip.e("异常");

// 文本提示
$tip.show("你好", "我是AIGame助手");
$tip.show("你好", "点击确定后执行", () => {
    toast("继续执行!");
});

// 自定义对话框
let ui = $ui.layout("./ui.xml");
let view = ui.getView();
$tip.show("自定义", view);
$tip.show("自定义", view, () => {
    toast("保存成功");
});

// 输入框
$tip.input("请输入名字", (value) => {
    toast("输入: " + value);
});
$tip.input("请输入", "提示文字", "默认值", (value) => {
    toast("输入: " + value);
});

// 整数输入
$tip.inputInt("年龄", (num) => {
    toast("刚满" + num + "岁~");
});
$tip.inputInt("年龄", "请输入年龄", 18, (num) => {
    toast("刚满" + num + "岁~");
});

// 单选
let arr = ["小狗", "小猫", "小猪"];
$tip.one("请选择", arr, (value) => {
    toast("选择了: " + value);
});

// 多选
$tip.more("请选择", arr, (values) => {
    toast("选择了: " + values);
});

// 日期选择
$tip.calendar((info) => {
    // 回调在子线程
    let year = info.year;
    let month = info.month;
    let day = info.day;
    alert("日期", year + "-" + month + "-" + day);
});

// 滚轮日期
$tip.date((info) => {
    log(info.year + "-" + info.month + "-" + info.day);
});

// 时间选择
$tip.clock((info) => {
    alert("时间", info.hour + ":" + info.minute);
});

// 滚轮时间
$tip.time((info) => {
    log(info.hour + ":" + info.minute);
});
```

## 注意事项

- 日期/时间选择回调运行在子线程中
- 输入整数无法解析时返回 0
- 自定义 view 对话框右上角有关闭按钮