---
name: $device-api
description: "$device API 参考 - 设备信息（屏幕/电池/音量/内存/震动）"
tags: [autogod, api, device]
---

# $device - 设备信息

对应官方文档：https://aigamepro.work/api_en/device.html

## 静态常量

### 屏幕
| 常量 | 说明 |
|------|------|
| `width` | 屏幕宽度 |
| `height` | 屏幕高度 |

### 系统信息
| 常量 | 说明 |
|------|------|
| `buildId` | Build ID |
| `buildDisplay` | Build Display |
| `product` | 产品名称 |
| `board` | 主板名称 |
| `brand` | 品牌名称 |
| `device` | 设备名称 |
| `model` | 型号名称 |
| `bootloader` | 引导加载程序 |
| `hardware` | 硬件名称 |
| `fingerprint` | 指纹信息 |
| `sdkInt` | SDK版本号 |
| `incremental` | 内部版本号 |
| `release` | Android版本号 |
| `code` | 开发代号 |
| `serial` | 序列号 |
| `baseOS` | 基础操作系统版本（仅Android 6.0+） |
| `securityPatch` | 安全补丁版本（仅Android 6.0+） |

## 函数清单

### 设备ID
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getIMEI()` | String | 获取IMEI号码 |
| `getAndroidId()` | String | 获取Android ID |

### 屏幕状态
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getBrightness()` | int | 获取屏幕亮度 |
| `getBrightnessMode()` | int | 获取亮度模式 |
| `isScreenOn()` | boolean | 屏幕是否亮起 |
| `isScreenOff()` | boolean | 屏幕是否熄灭 |
| `wakeUp()` | void | 唤醒设备屏幕 |
| `keepScreenOn()` | void | 保持屏幕常亮 |
| `keepScreenOn(timeout)` | void | 保持常亮指定时长（毫秒） |
| `keepScreenDim()` | void | 保持低亮度状态 |
| `keepScreenDim(timeout)` | void | 保持低亮指定时长 |
| `cancelKeepingAwake()` | void | 取消保持唤醒 |

### 电池
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getBattery()` | int | 电池电量百分比 |
| `isCharging()` | boolean | 是否正在充电 |

### 音量
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getMusicVolume()` | int | 获取媒体音量 |
| `getNotificationVolume()` | int | 获取通知音量 |
| `getAlarmVolume()` | int | 获取闹钟音量 |
| `getMusicMaxVolume()` | int | 获取媒体最大音量 |
| `getNotificationMaxVolume()` | int | 获取通知最大音量 |
| `getAlarmMaxVolume()` | int | 获取闹钟最大音量 |

### 内存
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getTotalMem()` | long | 获取总内存（字节） |
| `getAvailMem()` | long | 获取可用内存（字节） |

### 其他
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `vibrate(millis)` | void | 震动指定时长（毫秒） |
| `cancelVibration()` | void | 取消震动 |
| `getMacAddress()` | String | 获取MAC地址（null=无法获取） |
| `hasNavBar()` | boolean | 是否存在NavigationBar |
| `getVirtualBarHeight()` | int | 获取虚拟功能键高度 |
| `isLock()` | boolean | 设备是否锁定 |

## 代码示例

```javascript
// 设备信息
log("设备型号:", $device.model);
log("品牌:", $device.brand);
log("Android版本:", $device.release);
log("SDK:", $device.sdkInt);

// IMEI / Android ID
log("IMEI:", $device.getIMEI());
log("Android ID:", $device.getAndroidId());

// 屏幕状态
log("屏幕亮度:", $device.getBrightness());
if ($device.isScreenOn()) {
    log("屏幕亮着");
}

// 保持屏幕唤醒
$device.keepScreenOn();
$device.keepScreenDim(60000);  // 低亮60秒

// 取消唤醒
$device.cancelKeepingAwake();

// 电池
log("电量:", $device.getBattery() + "%");
log("充电中:", $device.isCharging());

// 音量
log("媒体音量:", $device.getMusicVolume());
log("最大音量:", $device.getMusicMaxVolume());

// 内存
log("总内存:", $device.getTotalMem());
log("可用内存:", $device.getAvailMem());

// 震动
$device.vibrate(1000);
$device.cancelVibration();

// 其他
log("MAC地址:", $device.getMacAddress());
log("导航栏高度:", $device.getVirtualBarHeight());
log("设备锁定:", $device.isLock());
```

## 注意事项

- `getIMEI()` 需要电话权限
- `baseOS` 和 `securityPatch` 仅在 Android 6.0+ 有效
- MAC 地址在 Android 7.0+ 可能返回 null