---
name: $res-api
description: "$res API 参考 - 资源管理器（跨线程存储、导入导出）"
tags: [autogod, api, resource]
---

# $res - 资源管理器

对应官方文档：https://aigamepro.work/api_en/res.html

## 模块概述

针对脚本引擎设计的资源管理器，支持跨线程访问，方便存储和读取 JS 对象数据。

## 函数清单

### 创建
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `create(appName)` | AgRes | 创建资源对象 |

### 数据操作
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `set(resName, resData)` | void | 设置资源 |
| `get(resName)` | Object | 获取资源（不存在返回null） |
| `get(resName, defaultValue)` | Object | 获取资源（默认值） |

### 文件操作
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `load(path)` | boolean | 加载本地资源到内部存储 |
| `ls()` | String[] | 列出所有资源名称 |
| `cat()` | String | 查看资源内容（格式化JSON） |
| `dump(path)` | String | 导出资源到指定路径 |

## 代码示例

```javascript
// 创建资源对象
let res = $res.create("我的资源");

// 设置资源
res.set("名字", "张三");
res.set("年龄", 16);
res.set("用户", {
    name: "张三",
    age: 16
});

// 获取资源
let name = res.get("名字");
let data = res.get("名字", "默认值");

// 列出资源
let list = res.ls();

// 查看内容
let content = res.cat();
alert("资源内容", content);

// 加载本地资源
res.load("/data.res");  // sdcard/当前项目/data.res
log(res.cat());

// 导出资源
res.dump("/data");  // 导出到 sdcard/当前项目/data.res
```

## 注意事项

- 资源存储在应用内部，支持跨线程访问
- `.res` 后缀会自动添加
- `load` 将 sdcard 下的资源拷贝到内部存储