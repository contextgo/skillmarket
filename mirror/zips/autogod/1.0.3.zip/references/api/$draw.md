---
name: $draw-api
description: "$draw API 参考 - 全屏绘制（矩形、十字、点、文字、圆、线、路径、图片）"
tags: [autogod, api, draw]
---

# $draw - 全屏绘制

对应官方文档：https://aigamepro.work/api_en/draw.html

## 模块概述

`$draw` 提供全屏绘制能力，用于调试时标注位置、绘制辅助线等。

## 系统限制

在 MIUI 系列手机中，厂家会拦截悬浮窗手势，无论用何种悬浮窗类型都无效。
在 1.8.0 版本后，支持在 ROOT 或 Shizuku 授权下自动解锁"卡悬浮"限制。

## 函数清单

### 权限
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getPermit()` | boolean | 获取悬浮窗权限 |

### 矩形
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `rect(rect)` | void | 绘制方框（Rect对象） |
| `rect(node)` | void | 绘制方框（Node节点） |
| `rect(x, y, w, h)` | void | 绘制方框 |
| `rect(x, y, w, h, color)` | void | 绘制方框（指定颜色） |
| `rect(x, y, w, h, ext)` | void | 绘制方框（四周拓展） |
| `rect(x, y, w, h, ext, color)` | void | 绘制方框（拓展+颜色） |
| `rect(arr, ext, color)` | void | 绘制方框（数组形式） |

### 十字准心
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `cross(point)` | void | 绘制十字准心（Point对象） |
| `cross(index)` | void | 绘制十字准心（数组） |
| `cross(node)` | void | 绘制十字准心（节点） |
| `cross(x, y)` | void | 绘制十字准心 |
| `cross(x, y, color)` | void | 绘制十字准心（指定颜色） |

### 点
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `dot(x, y)` | void | 绘制点 |
| `dot(x, y, color)` | void | 绘制点（指定颜色） |

### 文字
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `text(text, x, y)` | void | 绘制文字（默认15dp） |
| `text(text, x, y, size)` | void | 绘制文字（指定大小） |
| `text(text, x, y, size, color)` | void | 绘制文字（大小+颜色） |

### 圆
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `circle(x, y)` | void | 绘制圆形（默认半径50） |
| `circle(x, y, r)` | void | 绘制圆形 |
| `circle(x, y, r, ext)` | void | 绘制圆形（拓展） |
| `circle(x, y, r, ext, color)` | void | 绘制圆形（拓展+颜色） |

### 线
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `line(x, y, toX, toY)` | void | 绘制线 |
| `line(x, y, toX, toY, color)` | void | 绘制线（指定颜色） |

### 路径
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `path(data)` | void | 绘制路径（二维坐标数组） |
| `path(data, color)` | void | 绘制路径（指定颜色） |

### 图片
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `img(img, x, y, w, h)` | void | 绘制图片 |

### 日志绘制（小型悬浮窗，不挡手势）
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `i(text)` | void | 绘制日志（信息级别） |
| `i(text, x, y)` | void | 绘制日志（指定位置） |
| `i(text, x, y, size)` | void | 绘制日志（指定位置+大小） |
| `d(text)` | void | 绘制日志（调试级别） |
| `d(text, x, y)` | void | 绘制日志（指定位置） |
| `d(text, x, y, size)` | void | 绘制日志（指定位置+大小） |
| `w(text)` | void | 绘制日志（警告级别） |
| `w(text, x, y)` | void | 绘制日志（指定位置） |
| `w(text, x, y, size)` | void | 绘制日志（指定位置+大小） |
| `e(text)` | void | 绘制日志（错误级别） |
| `e(text, x, y)` | void | 绘制日志（指定位置） |
| `e(text, x, y, size)` | void | 绘制日志（指定位置+大小） |
| `v(text)` | void | 绘制日志（信息级别） |
| `v(text, x, y)` | void | 绘制日志（指定位置） |
| `v(text, x, y, size)` | void | 绘制日志（指定位置+大小） |
| `log(text)` | void | 绘制日志 |
| `log(text, color)` | void | 绘制日志（指定颜色） |
| `log(text, x, y)` | void | 绘制日志（指定位置） |
| `log(text, color, x, y)` | void | 绘制日志（颜色+位置） |
| `log(text, color, x, y, size)` | void | 绘制日志（完整参数） |

### 关闭与清空
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `closeAll()` | void | 关闭所有绘制 |
| `closeAll(delay)` | void | 延迟关闭所有绘制 |
| `closeLog(delay)` | void | 关闭日志绘制 |
| `closeLog()` | void | 关闭日志绘制 |
| `clear()` | void | 清空所有绘制 |

## 代码示例

```javascript
// 小型日志悬浮窗（不挡手势）
$draw.i("信息");
$draw.d("调试");
$draw.w("警告");

// 绘制方框
let rect = new org.opencv.core.Rect(0, 0, 100, 100);
$draw.rect(rect);
$draw.rect(200, 200, 200, 100);
$draw.rect(200, 200, 200, 100, "#FF0000");

// 扩展矩形
$draw.rect(200, 200, 200, 100, 50, "#FF0000");

// 十字准心
$draw.cross([400, 500]);
$draw.cross(400, 500, "#FF0000");

// 绘制节点
let node = $act.selector().textHas("停止").findFirst();
$draw.rect(node);
$draw.cross(node);

// 绘制圆形
$draw.circle(350, 400);
$draw.circle(350, 400, 100, 50, "#FF0000");

// 绘制线
$draw.line(300, 0, 100, 1000);
$draw.line(300, 0, 100, 1000, "#FF0000");

// 绘制路径（手势）
$draw.path([
    [100, 800], [120, 750], [150, 720], [180, 750],
    [200, 800], [220, 700], [250, 680], [280, 700],
    [300, 800], [320, 250], [350, 200], [380, 250],
    [400, 800], [420, 740], [450, 730], [480, 740],
    [500, 800], [520, 770], [550, 760], [580, 770],
    [600, 800]
], "#FF0000");

// 绘制图片
let img = $img.read("/cat.png");
$draw.img(img, 200, 200, 100, 150);

// 日志文字
$draw.log("信息", "#57965C", 400, 300, 20);

// 关闭
$draw.closeAll();
$draw.closeAll(1000);
$draw.clear();
```

## 注意事项

- 小型日志绘制（`i/d/w/e/v/log`）是小型悬浮窗，不会阻拦用户手势
- 全屏绘制类函数（如 `rect`、`text`）在 MIUI 系统会拦截手势
- `clear()` 实际上是通过绘制透明颜色来实现的，仍需要悬浮窗权限