---
name: $tts-api
description: "$tts API 参考 - 语音阅读（TTS文字转语音）"
tags: [autogod, api, tts]
---

# $tts - 语音阅读

对应官方文档：https://aigamepro.work/api_en/tts.html

## 函数清单

| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `read(text)` | void | 播放文本（默认配置） |
| `read(text, options)` | void | 播放文本（自定义配置） |

## TtsOptions 配置

```javascript
let options = {
    rate: 1,           // 语速（默认1）
    pitch: 1,         // 音调（默认1）
    volume: 1,        // 音量（默认1）
    language: "zh",    // 语言（zh中文）
    streamType: "system"  // 播放流（system声音最大）
};
```

## 代码示例

```javascript
// 默认配置
$tts.read("你好呀，早安~");

// 自定义配置
let options = {
    rate: 1.5,           // 语速加快
    pitch: 0.8,         // 音调降低
    volume: 1,           // 最大音量
    language: "zh",      // 中文
    streamType: "system"
};
$tts.read("你好呀，早安~", options);
```

## 注意事项

- 没有 TTS 引擎的设备调用无效
- `streamType: "system"` 播放声音最大