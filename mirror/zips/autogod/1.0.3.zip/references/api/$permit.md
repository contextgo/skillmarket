---
name: $permit-api
description: "$permit API 参考 - 权限工具（悬浮窗/无障碍/存储/相机/定位等）"
tags: [autogod, api, permission]
---

# $permit - 权限工具

对应官方文档：https://aigamepro.work/api_en/permit.html

## 模块概述

统一的权限申请和检测工具。**注意：所有权限方法都只会调用一次。**

## 函数清单

### 权限申请（has + 获取 / has 判断）

| 权限 | 获取 | 判断 | 说明 |
|------|------|------|------|
| 悬浮窗 | `floaty()` | `hasFloaty()` | 悬浮窗绘制 |
| 无障碍 | `wza()` | `hasWza()` | 自动化核心权限 |
| 存储 | `sd()` | `hasSd()` | 文件读写 |
| 电话 | `call()` | `hasCall()` | 拨打电话 |
| 修改设置 | `set()` | `hasSet()` | 系统设置修改 |
| 网络 | `net()` | `hasNet()` | 网络请求 |
| 相机 | `camera()` | `hasCamera()` | 拍照 |
| 录音 | `record()` | `hasRecord()` | 录音 |
| 读取短信 | `readSms()` | `hasReadSms()` | 读取短信 |
| 发送短信 | `sendSms()` | `hasSendSms()` | 发送短信 |
| 读取联系人 | `readContact()` | `hasReadContact()` | 读取联系人 |
| 写入联系人 | `writeContact()` | `hasWriteContact()` | 写入联系人 |
| 定位 | `loc()` | `hasLoc()` | 位置信息 |
| 读取日历 | `readCalendar()` | `hasReadCalendar()` | 读取日历 |
| 写入日历 | `writeCalendar()` | `hasWriteCalendar()` | 写入日历 |
| 通知访问 | `notifyAccess()` | `hasNotifyAccess()` | 读取通知 |
| 读取视频 | `readVideo()` | `hasReadVideo()` | 读取视频文件 |
| 读取图片 | `readImage()` | `hasReadImage()` | 读取图片文件 |
| 读取音频 | `readAudio()` | `hasReadAudio()` | 读取音频文件 |
| 读取媒体 | `readMedia()` | `hasReadMedia()` | 综合读取音频/图片/视频 |

### 通用方法
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `getPermit(permitName)` | void | 按权限名获取单个权限 |
| `getPermit(permitNames[])` | void | 按权限名数组批量获取权限 |
| `hasPermit(permitName)` | boolean | 按权限名判断单个权限 |
| `hasPermit(permitNames[])` | boolean | 按权限名数组判断批量权限 |

## 代码示例

```javascript
// 申请悬浮窗权限
$permit.floaty();

// 申请无障碍权限（核心！）
$permit.wza();

// 申请存储权限
$permit.sd();

// 申请所有需要的权限
$permit.getPermit([
    "android.permission.READ_CALENDAR",
    "android.permission.WRITE_CALENDAR"
]);

// 检查权限
if ($permit.hasFloaty()) {
    log("有悬浮窗权限");
}
if ($permit.hasWza()) {
    log("有无障碍权限");
}

// 按名称判断
$permit.hasPermit("android.Manifest.permission.GET_ACCOUNTS");
$permit.hasPermit([
    "android.permission.READ_CALENDAR",
    "android.permission.WRITE_CALENDAR"
]);
```

## 注意事项

- **所有方法只调用一次**（内部有缓存）
- 无障碍权限 `wza()`：有 ROOT/Shizuku 时授予永久权限，否则需要手动授权
- `readMedia()` 综合了视频、图片、音频三种权限