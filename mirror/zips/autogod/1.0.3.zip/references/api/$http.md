---
name: $http-api
description: "$http API 参考 - 网络请求（GET/POST/下载等）"
tags: [autogod, api, http]
---

# $http - 网络请求

对应官方文档：https://aigamepro.work/api_en/http.html

## 模块概述

`$http` 支持 GET、POST、DELETE、PUT、PATCH 等 HTTP 请求，以及文件下载功能。支持 JSON、XML、表单、文件等多种数据格式。

## 请求选项（HttpOptions）

```javascript
let opt = {
    url: "https://example.com/api",  // 请求地址（必填）
    head: {                          // 请求头
        "key": "value",
        "key2": "value2"
    },
    data: "请求数据",                 // 数据（支持 file/xml/json/string/byte）
    form: {                          // 表单数据（自动拼接为 key=value&...）
        name: "张三",
        sex: "boy"
    },
    connectTimeout: 30,              // 连接超时（默认30秒）
    readTimeout: 30,                 // 读超时（默认30秒）
    writeTimeout: 30,                // 写超时（默认30秒）
    callTimeout: 60                  // 请求超时（默认60秒）
};
```

## 函数清单

### Uri 解析
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `uri(uri)` | Uri | 解析 Uri 字符串 |

### 请求方法
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `get(url)` | HttpResponse | 同步 GET 请求（字符串） |
| `get(opts)` | HttpResponse | 同步 GET 请求（选项） |
| `post(opts)` | HttpResponse | 同步 POST 请求 |
| `del(opts)` | HttpResponse | 同步 DELETE 请求 |
| `delete(opts)` | HttpResponse | 同步 DELETE 请求 |
| `put(opts)` | HttpResponse | 同步 PUT 请求 |
| `patch(opts)` | HttpResponse | 同步 PATCH 请求 |

### 下载
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `download(url, savePath)` | void | 下载文件 |
| `download(url, savePath, completeCallback)` | void | 下载（完成回调） |
| `download(url, savePath, completeCallback, onFailure)` | void | 下载（完成+失败回调） |
| `download(url, savePath, progressListener, completeCallback, onFailure)` | void | 下载（进度+完成+失败回调） |

### 其他
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `wifiIp()` | String | 获取 WiFi 的 IP 地址（非 WiFi 返回 null） |

## 请求示例

### POST JSON
```javascript
let res = $http.post({
    url: "https://example.com/api",
    head: {
        "Content-Type": "application/json"
    },
    data: {
        name: "张三"
    }
});
log(res.body());
```

### POST 表单
```javascript
let res = $http.post({
    url: "https://example.com/api",
    form: {
        name: "张三",
        sex: "boy"
    }
});
log(res.body());
```

### POST 表单（含文件）
```javascript
let res = $http.post({
    url: "https://example.com/api",
    form: {
        name: "张三",
        head: "/sdcard/head.png"  // 文件用路径
    }
});
```

### POST 单文件
```javascript
let res = $http.post({
    url: "https://example.com/upload",
    data: "/sdcard/test.js"
});
```

### POST 二进制
```javascript
let res = $http.post({
    url: "https://example.com/api",
    data: "二进制字符串",
    type: "byte"
});
```

### GET 请求
```javascript
let res = $http.get("https://example.com/api?key=value");
log(res.body());

// 带完整选项
let res = $http.get({
    url: "https://example.com/api",
    head: { "Authorization": "Bearer token" },
    connectTimeout: 30,
    readTimeout: 30
});
```

### PUT 请求
```javascript
let res = $http.put({
    url: "https://example.com/api/1",
    data: { name: "李四" }
});
```

### DELETE 请求
```javascript
let res = $http.del({
    url: "https://example.com/api/1"
});
```

## 下载示例

```javascript
$http.download(
    "https://pics0.baidu.com/feed/f11f3a292df5e0feee2783e88baf3fa75fdf727e.jpeg",
    "/sdcard/美女.png",
    (cur, total, percent) => {
        log("下载进度", percent);
    },
    () => {
        log("下载完毕");
        $tip.show("下载完成");
    },
    (res) => {
        log("下载失败", res);
    }
);
```

## Uri 解析
```javascript
let uri = $http.uri("smsto:" + $str.uriEncode("13693749475"));
```

## HttpResponse 方法

```javascript
let res = $http.get("https://example.com");
// res.body()       → 响应体（字符串）
// res.status()     → 状态码
// res.headers()    → 响应头
```

## 注意事项

- `get`、`post` 等都是同步方法，会阻塞当前线程
- `data` 参数会根据内容自动判断类型（file/xml/json/string）
- 如需发送二进制，需设置 `type: "byte"`
- `wifiIp()` 非 WiFi 连接时返回 null