---
name: $date-api
description: "$date API 参考 - 日期工具（格式化、解析、时长计算）"
tags: [autogod, api, date]
---

# $date - 日期工具

对应官方文档：https://aigamepro.work/api_en/date.html

## 函数清单

### 日期时间字符串
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `dt()` | String | 当前日期时间（yyyy-MM-dd HH:mm:ss） |
| `dt(time)` | String | 指定时间戳→日期时间字符串 |
| `dt(time)` | String | 指定时间字符串→日期时间字符串 |

### 日期字符串
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `d()` | String | 当前日期（yyyy-MM-dd） |
| `d(time)` | String | 指定时间戳→日期字符串 |

### 解析
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `parse(dateStr, pattern)` | Date | 按格式模板解析日期 |
| `parse(dateStr)` | Date | 自动解析（预置27种格式） |

### 日期信息
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `info()` | DateInfo | 获取当前日期详细信息 |
| `info(time)` | DateInfo | 获取指定时间戳的日期信息 |
| `info(time)` | DateInfo | 获取指定字符串时间的日期信息 |

### 格式化
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `format(time, pattern)` | String | 时间戳→格式化日期字符串 |
| `format(date, pattern)` | String | Date对象→格式化字符串 |
| `format(dateStr, pattern)` | String | 乱序日期字符串→格式化 |

### 创建日期
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `date()` | Date | 创建当前日期对象 |
| `date(time)` | Date | 从时间戳创建日期 |
| `date(dateStr)` | Date | 从字符串创建日期 |

### 时长
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `dur(milliseconds)` | String | 毫秒→"x天x时x分x秒"字符串 |

### 时间戳
| 函数签名 | 返回值 | 说明 |
|---------|--------|------|
| `curTime()` | long | 获取当前时间戳（毫秒） |

## 代码示例

```javascript
// 当前日期时间
let dateStr = $date.dt();        // "2025-10-25 18:32:53"
let dateStr = $date.d();         // "2025-05-23"

// 从时间戳
let dateStr = $date.dt(1747985594110);
let dateStr = $date.d(1747985594110);

// 解析日期
let date = $date.parse("2025/12/08 12/35/24", "yyyy/MM/dd HH/mm/ss");
let date = $date.parse("2025/12/08 12-35-24");  // 自动解析

// 获取日期信息
let info = $date.info();
// info: { year, month, day, hour, minute, second, dayOfWeek, ... }

// 格式化
let str = $date.format(1747985594110, "yyyy年MM月dd日 HH时mm分ss秒");
// "2025年05月23日 15时33分14秒"

let str = $date.format("2025/12/08 12-35-24", "yyyy年MM月dd日 HH时mm分ss秒");

// 创建日期
let d = $date.date();
let d = $date.date(1747985594110);

// 时长转换
let dur = $date.dur(1234567890);  // "14天6时56分7秒"

// 当前时间戳
let ts = $date.curTime();
```

## 注意事项

- `parse(dateStr)` 内部预置了27种日期格式模板
- `dur()` 用于将毫秒数转换为易读时长字符串