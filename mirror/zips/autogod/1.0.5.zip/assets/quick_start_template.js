/**
 * AutoGOD 快速启动模板
 * 
 * 这是一个标准的 AutoGOD 脚本模板，包含：
 * - 标准初始化流程
 * - 权限申请
 * - 异常处理
 * - 资源管理
 * - 日志记录
 * 
 * 使用方法：
 * 1. 复制此文件到项目目录
 * 2. 修改 CONFIG 配置
 * 3. 在 main() 函数中编写业务逻辑
 */

// ==================== 配置区 ====================

const CONFIG = {
    // 应用配置
    APP_PACKAGE: "com.example.app",      // 目标应用包名
    APP_ACTIVITY: "MainActivity",         // 目标 Activity
    
    // 超时配置
    TIMEOUT: {
        ELEMENT: 3000,      // 元素查找超时（毫秒）
        ACTIVITY: 5000,     // 界面切换超时
        REQUEST: 10000      // 网络请求超时
    },
    
    // 重试配置
    RETRY: {
        COUNT: 3,           // 重试次数
        DELAY: 1000         // 重试延迟（毫秒）
    },
    
    // OCR 配置
    OCR: {
        ENGINE: "mlkit",    // OCR 引擎：mlkit|ncnn|ppv5
        THRESHOLD: 20       // 二值化阈值
    },
    
    // 日志配置
    LOG: {
        ENABLED: true,      // 是否启用日志
        LEVEL: "INFO"       // 日志级别：DEBUG|INFO|WARN|ERROR
    }
};

// ==================== 工具函数区 ====================

/**
 * 日志函数
 */
function logMsg(level, msg) {
    if (!CONFIG.LOG.ENABLED) return;
    
    const levels = ["DEBUG", "INFO", "WARN", "ERROR"];
    const currentLevel = levels.indexOf(CONFIG.LOG.LEVEL);
    const msgLevel = levels.indexOf(level);
    
    if (msgLevel >= currentLevel) {
        let timestamp = new Date().toLocaleTimeString();
        log(`[${timestamp}] [${level}] ${msg}`);
    }
}

function logDebug(msg) { logMsg("DEBUG", msg); }
function logInfo(msg) { logMsg("INFO", msg); }
function logWarn(msg) { logMsg("WARN", msg); }
function logError(msg) { logMsg("ERROR", msg); }

/**
 * 安全执行函数
 */
function safeExecute(fn, errorMsg = "操作失败") {
    try {
        return fn();
    } catch (e) {
        logError(`${errorMsg}: ${e}`);
        return null;
    }
}

/**
 * 重试执行函数
 */
function retry(fn, maxRetry = CONFIG.RETRY.COUNT, delay = CONFIG.RETRY.DELAY) {
    for (let i = 0; i < maxRetry; i++) {
        try {
            return fn();
        } catch (e) {
            logWarn(`执行失败 (第 ${i+1} 次): ${e}`);
            if (i < maxRetry - 1) {
                sleep(delay);
            }
        }
    }
    throw new Error("重试次数耗尽");
}

/**
 * 等待元素出现
 */
function waitForElement(selector, timeout = CONFIG.TIMEOUT.ELEMENT) {
    let startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
        let node = $act.selector()
            .text(selector.text || null)
            .cls(selector.cls || null)
            .pkg(selector.pkg || CONFIG.APP_PACKAGE)
            .waitFirst(500);
        
        if (node != null) {
            return node;
        }
        
        sleep(200);
    }
    
    return null;
}

/**
 * 安全点击节点
 */
function clickNode(selector, timeout = CONFIG.TIMEOUT.ELEMENT) {
    let node = waitForElement(selector, timeout);
    
    if (node != null) {
        node.draw();  // 调试：绘制节点位置
        node.click();
        logInfo(`点击节点: ${selector.text || selector.cls}`);
        return true;
    } else {
        logWarn(`未找到节点: ${selector.text || selector.cls}`);
        return false;
    }
}

/**
 * 等待界面切换
 */
function waitForActivity(targetActivity, timeout = CONFIG.TIMEOUT.ACTIVITY) {
    let startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
        let current = $act.activity();
        
        if (current.includes(targetActivity)) {
            logInfo(`已切换到界面: ${targetActivity}`);
            return true;
        }
        
        sleep(200);
    }
    
    logWarn(`界面切换超时: ${targetActivity}`);
    return false;
}

/**
 * 安全截屏
 */
function safeScreenshot() {
    let img = null;
    try {
        img = $screen.getScreen();
        return img;
    } catch (e) {
        logError("截屏失败: " + e);
        if (img != null) {
            img.recycle();
        }
        return null;
    }
}

/**
 * 识别文字并点击
 */
function clickText(targetText, options = {}) {
    let img = null;
    try {
        img = safeScreenshot();
        if (img == null) return false;
        
        let point = $ocr.getPoint(targetText, {
            region: options.region || null,
            gray: options.gray || false,
            threshold: options.threshold || CONFIG.OCR.THRESHOLD
        });
        
        if (point != null) {
            $act.click(point);
            logInfo(`点击文字: ${targetText}`);
            return true;
        } else {
            logWarn(`未找到文字: ${targetText}`);
            return false;
        }
    } catch (e) {
        logError("文字识别点击失败: " + e);
        return false;
    } finally {
        if (img != null) {
            img.recycle();
        }
    }
}

// ==================== 初始化区 ====================

/**
 * 初始化权限
 */
async function initPermissions() {
    logInfo("开始申请权限...");
    
    // 申请无障碍权限
    if (!$act.hasPermit()) {
        logInfo("申请无障碍权限...");
        $act.getPermit();
    }
    
    // 申请截屏权限
    if (!$screen.hasPermit()) {
        logInfo("申请截屏权限...");
        $screen.getPermit();
    }
    
    // 申请悬浮窗权限（如需要）
    // if (!$floaty.hasPermit()) {
    //     logInfo("申请悬浮窗权限...");
    //     $floaty.getPermit();
    // }
    
    logInfo("权限申请完成");
}

/**
 * 初始化模块
 */
function initModules() {
    logInfo("开始初始化模块...");
    
    // 初始化 OCR
    $ocr.v(CONFIG.OCR.ENGINE);
    $ocr.init();
    
    logInfo("模块初始化完成");
}

/**
 * 完整初始化
 */
async function init() {
    logInfo("========== 开始初始化 ==========");
    
    await initPermissions();
    initModules();
    
    logInfo("========== 初始化完成 ==========");
}

// ==================== 功能区 ====================

/**
 * 示例功能：启动应用
 */
function launchApp() {
    logInfo("启动应用: " + CONFIG.APP_PACKAGE);
    
    // 使用包名启动应用
    app.launchPackage(CONFIG.APP_PACKAGE);
    
    // 等待应用启动
    if (waitForActivity(CONFIG.APP_ACTIVITY)) {
        logInfo("应用启动成功");
        return true;
    } else {
        logError("应用启动失败");
        return false;
    }
}

/**
 * 示例功能：点击按钮
 */
function exampleClickButton() {
    logInfo("执行点击按钮示例...");
    
    // 方式1：通过文本点击
    clickNode({ text: "确定" });
    
    // 方式2：通过类名点击
    // clickNode({ cls: "android.widget.Button" });
    
    // 方式3：通过 OCR 识别点击
    // clickText("确定");
}

/**
 * 示例功能：滑动操作
 */
function exampleSwipe() {
    logInfo("执行滑动示例...");
    
    let w = $screen.getWidth();
    let h = $screen.getHeight();
    
    // 向上滑动（内容向下滚动）
    $act.slide(
        w / 2, h * 0.7,  // 起点：屏幕中下方
        w / 2, h * 0.3,  // 终点：屏幕中上方
        500              // 持续时间
    );
    
    logInfo("滑动完成");
}

/**
 * 示例功能：数据采集
 */
function exampleCollectData() {
    logInfo("执行数据采集示例...");
    
    let img = null;
    try {
        // 截屏
        img = safeScreenshot();
        if (img == null) return null;
        
        // OCR 识别
        let result = $ocr.detect({
            region: [0, 0, 500, 200],  // 识别范围
            gray: true                  // 灰度化加速
        });
        
        if (result.isSuccess()) {
            let text = result.getText();
            logInfo("识别结果: " + text);
            return text;
        }
        
        return null;
    } catch (e) {
        logError("数据采集失败: " + e);
        return null;
    } finally {
        if (img != null) {
            img.recycle();
        }
    }
}

// ==================== 主流程 ====================

/**
 * 主流程
 */
async function main() {
    try {
        // 初始化
        await init();
        
        // 启动应用
        if (!launchApp()) {
            return;
        }
        
        // 等待主界面加载
        sleep(2000);
        
        // 执行业务逻辑
        exampleClickButton();
        sleep(1000);
        
        exampleSwipe();
        sleep(1000);
        
        let data = exampleCollectData();
        
        logInfo("========== 脚本执行完成 ==========");
        
    } catch (e) {
        logError("脚本执行失败: " + e);
    }
}

// ==================== 启动 ====================

// 启动主流程
main();
