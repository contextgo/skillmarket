# AutoGOD 悬浮窗 API 错误修正

## 修正时间
2026-05-03 13:37

## 错误描述
❌ **错误代码**：
```javascript
var floaty = $floaty.window(RelativeLayout);  // ❌ 错误
var floaty = $floaty.newApp(xml);             // ❌ 也是错误
```

## 正确代码
✅ **正确代码**：
```javascript
// 必须使用 $floaty.newSys()！
var floaty = $floaty.newSys(`
<ui>
<frame w="200dp" h="300dp" bg="#FFFFFF">
<linear dir="v" w="max" h="max" gravity="center">
<text text="悬浮窗内容" textSize="16" />
</linear>
</frame>
</ui>
`);
floaty.setXY(100, 200);  // 设置位置
floaty.setWH(200, 300);  // 设置宽高
```

## 常用 API
- `$floaty.newSys(xml)` - 创建系统级悬浮窗（正确方法）
- `floaty.id(id)` - 获取控件
- `floaty.setXY(x, y)` - 设置位置
- `floaty.setWH(w, h)` - 设置宽高
- `floaty.close()` - 关闭悬浮窗

## 相关文件
- 规范文档：`AutoGOD开发规范.md` 第五节、第八节问题8
- 库文件：`lib/SysFloaty-系统级悬浮窗.js`
