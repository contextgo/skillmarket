# AutoGOD 常见"跑编"错误修正

## 更新时间
2026-05-01

> 🔴 本文档记录所有经实际运行验证的错误，不允许凭记忆推测。所有条目必须有真实错误案例支撑。
> 每次跑编失败后，必须将错误现象和根因追加到本文档。

---

## 一、XML 布局语法错误（v2 UI 框架）⚠️ 2026-05-01 新增

> AutoGOD v2 使用全新 UI 框架，与旧版 Android XML 不兼容。
> **编写 XML 布局前必须读取 `references/ui/` 对应模块文档确认标签和属性名。**

### 1.1 根节点与 XML 声明

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `<?xml version="1.0" encoding="UTF-8"?>` | **删除此行** | XML 声明头导致解析失败 |
| `<界面>` | `<ui>` | v2 根节点必须是 `<ui>` |
| `<layout>` | `<ui>` | 同上 |
| 无根标签（直接写控件） | `<ui>...内容...</ui>` | 必须有 `<ui>` 包裹 |

### 1.2 标签名映射（旧 → v2）

| 旧版写法（❌） | v2 正确写法（✅） |
|--------------|-------------------|
| `<LinearLayout>` | `<linear>` |
| `<ScrollView>` | `<scroll>` |
| `<HorizontalScrollView>` | `<hscroll>` |
| `<FrameLayout>` | `<frame>` |
| `<RelativeLayout>` | `<relative>` |
| `<android.widget.LinearLayout>` | `<linear>` |

### 1.3 属性名映射（旧 → v2）

| 旧版写法（❌） | v2 正确写法（✅） |
|--------------|-------------------|
| `orientation="vertical"` | `dir="v"` |
| `orientation="horizontal"` | `dir="h"` |
| `background="#RRGGBB"` | `bg="#RRGGBB"` |
| `textStyle="bold"` | `typeface="bold"` |
| `textSize="16sp"` | `textSize="16"`（无单位） |
| `textColor` | `color` |
| `padding="10 20 10 15"`（空格） | `padding="10,20,10,15"`（逗号） |
| `margin="15 20"`（空格） | `margin="15,20"`（逗号） |
| `layout_width="match_parent"` | `w="max"` |
| `layout_width="wrap_content"` | `w="wrap"` |
| `layout_height="match_parent"` | `h="max"` |
| `layout_height="wrap_content"` | `h="wrap"` |

### 1.4 完整对照示例

```xml
<!-- ❌ 旧版 Android XML（解析失败） -->
<?xml version="1.0"?>
<界面>
    <LinearLayout orientation="vertical" background="#FFFFFF" padding="15 20">
        <text text="标题" textStyle="bold" textSize="16sp"/>
    </LinearLayout>
</界面>

<!-- ✅ v2 UI 框架（正确） -->
<ui>
    <linear dir="v" bg="#FFFFFF" padding="15,20">
        <text text="标题" typeface="bold" textSize="16"/>
    </linear>
</ui>
```

### 1.5 v2 常用属性速查

**布局属性：** `dir`, `gravity`, `w`, `h`, `weight`, `margin`, `padding`, `layout_gravity`
**控件属性：** `text`, `textSize`, `color`, `bg`, `radius`, `padding`, `typeface`
**gravity 值：** `center`, `left`, `right`, `top`, `bottom`, `start`, `end`, 多值用 `|` 分隔

---

## 二、JS 代码错误

### 2.1 $ui.layout() 路径错误

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `$ui.layout("xml/main.xml")` | `$ui.layout("src/main.xml")` | 路径相对于项目根目录 |
| `$ui.layout("main.xml")`（JS 在 src/） | `$ui.layout("src/main.xml")` | 仍需写完整相对路径 |
| `$ui.layout("/main.xml")` | `$ui.layout("src/main.xml")` | 不能用 / 开头 |

> **说明：** `$ui.layout()` 的路径相对于项目根目录（project.json 同级目录），不是相对于 JS 文件所在目录。
> JS 在 `src/main.js`，XML 在 `src/main.xml`，路径写 `src/main.xml`。

### 2.2 全局变量名称错误

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `$files.read(path)` | `$file.read(path)` | 模块名是 `$file`，不是 `$files` |
| `$files.write(c, p)` | `$file.write(c, p)` | 同上 |

### 2.3 floaty 创建方式错误

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `$floaty.create().setLayout(xml)` | `$floaty.newApp(xml)` 或 `$floaty.newAdj(xml)` | v2 API 不同 |
| `$floaty.find("id")` | 返回的 floaty 对象用 `.id("id")` | v2 无 find 方法 |

### 2.4 API 名称拼写错误

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `$act.clickk(500, 800)` | `$act.click(500, 800)` | 拼写错误 |
| `$screen.getscreen()` | `$screen.getScreen()` | 大小写错误 |
| `$ocr.detct()` | `$ocr.detect()` | 拼写错误 |
| `$floaty.newAppp()` | `$floaty.newApp()` | 多余字母 |

### 2.5 参数类型错误

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `$act.click("500", "800")` | `$act.click(500, 800)` | 坐标必须为数字 |
| `$act.click(500.5, 800.2)` | `$act.click(500, 800)` | 坐标必须为整数 |
| `$screen.bright("100")` | `$screen.bright(100)` | 亮度必须为数字 |

### 2.6 参数顺序错误

| 错误写法 | 正确写法 | 错误原因 |
|---------|---------|---------|
| `$act.click(y, x)` | `$act.click(x, y)` | X/Y 顺序错误 |
| `$file.write(path, content)` | `$file.write(content, path)` | 内容/路径顺序错误 |

---

## 三、权限相关错误

### 3.1 权限未申请

| 错误场景 | 错误代码 | 修正代码 |
|---------|---------|---------|
| 无障碍未申请 | `$act.click(500, 800)` | `if(!$act.hasPermit()) $act.getPermit(); $act.click(500, 800);` |
| 截屏权限未申请 | `$screen.getScreen()` | `if(!$screen.hasPermit()) $screen.getPermit(); $screen.getScreen();` |
| 悬浮窗权限未申请 | `$floaty.newApp(...)` | `if(!$floaty.hasPermit()) $floaty.getPermit(); $floaty.newApp(...);` |

### 3.2 UI 线程调用阻塞函数

| 错误场景 | 错误代码 | 修正代码 |
|---------|---------|---------|
| UI 线程调用 getPermit | `ui.button.onClick = () => { $act.getPermit(); }` | `ui.button.onClick = () => { $permit.wza(); }` |

---

## 四、资源泄漏错误

### 4.1 图像资源未释放

| 错误场景 | 错误代码 | 修正代码 |
|---------|---------|---------|
| 截屏未释放 | `let img = $screen.getScreen();` | `let img = $screen.getScreen(); img.recycle();` |

**修正范式：**
```javascript
let img = null;
try {
    img = $screen.getScreen();
    // 处理图片...
} finally {
    if (img != null) img.recycle();
}
```

---

## 五、逻辑错误

### 5.1 空指针错误

| 错误场景 | 错误代码 | 修正代码 |
|---------|---------|---------|
| 节点未找到就操作 | `node.click();` | `if(node != null) node.click();` |

### 5.2 无限循环

| 错误场景 | 说明 |
|---------|------|
| while(true) 无退出条件 | 可能导致死循环 |

**修正：**
```javascript
let maxRetry = 10;
for (let i = 0; i < maxRetry; i++) {
    if (success) break;
}
```

---

## 六、性能错误

### 6.1 频繁截屏

循环中频繁截屏性能低下，应降低频率或缓存。

```javascript
// ✅ 每10次截屏一次
for (let i = 0; i < 100; i++) {
    if (i % 10 == 0) {
        let img = $screen.getScreen();
        // 处理...
        img.recycle();
    }
}
```

### 6.2 全屏 OCR

应缩小识别范围：
```javascript
let result = $ocr.detect({ region: [0, 0, 500, 200] });
```

---

## 七、常见错误速查表

| 错误类型 | 错误现象 | 解决方法 |
|---------|---------|---------|
| XML 声明头 | 解析失败 | 删除 `<?xml...?>` |
| XML 根标签 | 解析失败 | 改为 `<ui>` |
| XML 标签名 | 未知标签 | 改为小写无驼峰 |
| XML 属性名 | 属性无效 | 对照 v2 映射表 |
| 路径错误 | 文件找不到 | 相对于项目根目录 |
| $files | 未定义 | 改为 $file |
| API 拼写错误 | "xxx is not defined" | 检查 API 名称拼写 |
| 参数类型错误 | "xxx is not a function" | 检查参数类型 |
| 权限未申请 | 操作无效果 | 先申请权限 |
| 资源未释放 | 内存持续增长 | 调用 recycle() |
| 空指针错误 | "Cannot read property xxx of null" | 检查空值 |
| 死循环 | 脚本卡死 | 添加退出条件 |
