# AutoGOD XML 布局语法规范

## 更新时间
2026-04-30

## 一、基础结构

### 1.1 根节点

**规范：所有 XML 布局必须以 `<ui>` 为根节点**

```xml
<!-- ✅ 正确 -->
<ui>
    <text text="Hello World" />
</ui>

<!-- ❌ 错误：缺少根节点 -->
<text text="Hello World" />
```

### 1.2 命名空间

```xml
<ui xmlns:android="http://schemas.android.com/apk/res/android">
    <text android:text="Hello" />
</ui>
```

## 二、常用控件

### 2.1 文本控件

```xml
<text
    text="文本内容"
    textSize="16sp"
    textColor="#FF0000"
    gravity="center"
    padding="10dp"
    layout_width="wrap_content"
    layout_height="wrap_content"
/>
```

**属性说明：**
- `text`: 文本内容
- `textSize`: 字体大小（sp 单位）
- `textColor`: 文字颜色（十六进制）
- `gravity`: 内容对齐方式（left|center|right|top|bottom）
- `padding`: 内边距（dp 单位）
- `layout_width`: 宽度（wrap_content|match_parent|具体数值）
- `layout_height`: 高度

### 2.2 按钮控件

```xml
<button
    text="按钮"
    onClick="handleClick"
    background="#4CAF50"
    textColor="#FFFFFF"
    layout_width="wrap_content"
    layout_height="wrap_content"
/>
```

**事件绑定：**
```javascript
// 在 JavaScript 中定义事件处理函数
function handleClick(view) {
    toast("按钮被点击");
}
```

### 2.3 输入框

```xml
<input
    hint="请输入内容"
    text="默认文本"
    inputType="text"
    lines="3"
    layout_width="match_parent"
    layout_height="wrap_content"
/>
```

**inputType 类型：**
- `text`: 普通文本
- `number`: 数字
- `phone`: 电话号码
- `password`: 密码

### 2.4 图片控件

```xml
<img
    src="res/icon.png"
    scaleType="centerCrop"
    layout_width="100dp"
    layout_height="100dp"
/>
```

**scaleType 类型：**
- `center`: 居中显示
- `centerCrop`: 等比例缩放并裁剪
- `centerInside`: 等比例缩放并包含
- `fitXY`: 拉伸填充

### 2.5 复选框

```xml
<checkbox
    text="选项"
    checked="true"
    onCheckedChangeListener="onCheckChange"
/>
```

```javascript
function onCheckChange(buttonView, isChecked) {
    log("选中状态: " + isChecked);
}
```

### 2.6 单选按钮

```xml
<radio
    text="选项A"
    checked="true"
    id="radio_a"
/>
<radio
    text="选项B"
    id="radio_b"
/>
```

### 2.7 开关

```xml
<switch
    text="开关"
    checked="true"
    onCheckedChangeListener="onSwitchChange"
/>
```

### 2.8 进度条

```xml
<progress
    progress="50"
    max="100"
    indeterminate="false"
    layout_width="match_parent"
    layout_height="wrap_content"
/>
```

## 三、布局容器

### 3.1 线性布局

```xml
<linear
    orientation="vertical"
    gravity="center"
    padding="20dp"
    layout_width="match_parent"
    layout_height="match_parent"
>
    <text text="第一行" />
    <text text="第二行" />
</linear>
```

**orientation:**
- `vertical`: 垂直排列
- `horizontal`: 水平排列

### 3.2 相对布局

```xml
<relative
    layout_width="match_parent"
    layout_height="match_parent"
>
    <text
        text="顶部文本"
        layout_alignParentTop="true"
        layout_centerHorizontal="true"
    />
    <text
        text="底部文本"
        layout_alignParentBottom="true"
        layout_centerHorizontal="true"
    />
</relative>
```

**常用属性：**
- `layout_alignParentTop`: 对齐父容器顶部
- `layout_alignParentBottom`: 对齐父容器底部
- `layout_alignParentLeft`: 对齐父容器左侧
- `layout_alignParentRight`: 对齐父容器右侧
- `layout_centerHorizontal`: 水平居中
- `layout_centerVertical`: 垂直居中
- `layout_centerInParent`: 居中

### 3.3 帧布局

```xml
<frame
    layout_width="match_parent"
    layout_height="match_parent"
>
    <img src="res/background.png" />
    <text text="覆盖文本" />
</frame>
```

### 3.4 滚动视图

```xml
<scroll
    layout_width="match_parent"
    layout_height="match_parent"
>
    <linear orientation="vertical">
        <!-- 内容超出屏幕时可滚动 -->
        <text text="内容1" />
        <text text="内容2" />
        <!-- 更多内容... -->
    </linear>
</scroll>
```

### 3.5 水平滚动

```xml
<hscroll
    layout_width="match_parent"
    layout_height="wrap_content"
>
    <linear orientation="horizontal">
        <!-- 水平滚动内容 -->
    </linear>
</hscroll>
```

## 四、高级控件

### 4.1 列表视图

```xml
<list
    id="myList"
    layout_width="match_parent"
    layout_height="match_parent"
/>
```

```javascript
// 在 JavaScript 中设置适配器
let list = ui.findView("myList");
let adapter = ui.listAdapter([
    { title: "项目1", desc: "描述1" },
    { title: "项目2", desc: "描述2" }
], (item, view) => {
    view.text = item.title;
});
list.setAdapter(adapter);
```

### 4.2 网格视图

```xml
<grid
    id="myGrid"
    numColumns="3"
    layout_width="match_parent"
    layout_height="match_parent"
/>
```

### 4.3 WebView

```xml
<webview
    id="myWebView"
    url="https://example.com"
    layout_width="match_parent"
    layout_height="match_parent"
/>
```

## 五、布局属性详解

### 5.1 尺寸单位

| 单位 | 说明 | 示例 |
|------|------|------|
| `dp` | 密度无关像素 | `100dp` |
| `sp` | 缩放无关像素（文字） | `16sp` |
| `px` | 实际像素 | `100px` |
| `match_parent` | 填充父容器 | `match_parent` |
| `wrap_content` | 包裹内容 | `wrap_content` |

### 5.2 边距与填充

```xml
<text
    text="示例"
    padding="10dp"              <!-- 四边 -->
    paddingLeft="5dp"           <!-- 左边距 -->
    paddingRight="5dp"          <!-- 右边距 -->
    paddingTop="10dp"           <!-- 上边距 -->
    paddingBottom="10dp"        <!-- 下边距 -->
    margin="20dp"               <!-- 外边距 -->
    marginLeft="10dp"
    marginRight="10dp"
    marginTop="20dp"
    marginBottom="20dp"
/>
```

### 5.3 权重（线性布局）

```xml
<linear orientation="horizontal" layout_width="match_parent">
    <text
        text="左侧"
        layout_weight="1"
        layout_width="0dp"
    />
    <text
        text="右侧"
        layout_weight="2"
        layout_width="0dp"
    />
</linear>
<!-- 左侧占 1/3，右侧占 2/3 -->
```

### 5.4 对齐与重力

```xml
<text
    text="文本"
    gravity="center"            <!-- 内容对齐 -->
    layout_gravity="center"     <!-- 控件在父容器中的对齐 -->
/>
```

**gravity 取值：**
- `left`: 左对齐
- `right`: 右对齐
- `top`: 顶部对齐
- `bottom`: 底部对齐
- `center`: 居中
- `center_horizontal`: 水平居中
- `center_vertical`: 垂直居中

## 六、样式与主题

### 6.1 定义样式

```xml
<style name="MyButton">
    <item name="background">#4CAF50</item>
    <item name="textColor">#FFFFFF</item>
    <item name="textSize">16sp</item>
</style>
```

### 6.2 应用样式

```xml
<button
    text="按钮"
    style="@style/MyButton"
/>
```

## 七、动态属性

### 7.1 数据绑定

```xml
<text text="{{userName}}" />
<button onClick="{{handleClick}}" />
```

```javascript
// 在 JavaScript 中定义数据
ui.setData({
    userName: "张三",
    handleClick: function(view) {
        toast("点击");
    }
});
```

### 7.2 条件渲染

```xml
<text text="已登录" if="{{isLoggedIn}}" />
<text text="未登录" if="{{!isLoggedIn}}" />
```

### 7.3 列表渲染

```xml
<linear orientation="vertical">
    <text text="{{item}}" for="{{item in items}}" />
</linear>
```

## 八、事件处理

### 8.1 点击事件

```xml
<button text="点击" onClick="handleClick" />
```

```javascript
function handleClick(view) {
    toast("按钮被点击");
}
```

### 8.2 长按事件

```xml
<button text="长按" onLongClick="handleLongClick" />
```

```javascript
function handleLongClick(view) {
    toast("长按事件");
    return true;  // 返回 true 表示消费事件
}
```

### 8.3 触摸事件

```xml
<text text="触摸" onTouch="handleTouch" />
```

```javascript
function handleTouch(view, event) {
    let action = event.getAction();
    if (action == event.ACTION_DOWN) {
        log("按下");
    } else if (action == event.ACTION_MOVE) {
        log("移动");
    } else if (action == event.ACTION_UP) {
        log("抬起");
    }
    return true;
}
```

### 8.4 文本变化事件

```xml
<input onTextChanged="handleTextChanged" />
```

```javascript
function handleTextChanged(text) {
    log("输入内容: " + text);
}
```

## 九、布局加载

### 9.1 从文件加载

```javascript
// 加载布局文件
ui.layoutFile("./res/layout/main.xml");

// 或在悬浮窗中使用
let floaty = $floaty.newApp("./res/layout/floaty.xml");
```

### 9.2 从字符串加载

```javascript
ui.layout(`<ui>
    <text text="Hello" />
</ui>`);
```

### 9.3 查找控件

```javascript
// 通过 ID 查找
let button = ui.findView("myButton");

// 修改属性
button.setText("新文本");

// 设置事件
button.setOnClickListener((view) => {
    toast("点击");
});
```

## 十、常见错误对照表

| 错误写法 | 正确写法 | 说明 |
|---------|---------|------|
| `<text>Hello</text>` | `<text text="Hello" />` | 文本内容必须用属性 |
| `<linear>` 无根节点 | `<ui><linear>...</linear></ui>` | 必须有 `<ui>` 根节点 |
| `width="100"` | `layout_width="100dp"` | 宽度属性名错误 |
| `onClick="alert()"` | `onClick="handleClick"` | 事件绑定函数名，不要直接调用 |
| `padding="100"` | `padding="100dp"` | 缺少单位 |
| `textSize="16"` | `textSize="16sp"` | 文字大小用 sp 单位 |

## 十一、完整示例

### 11.1 登录界面

```xml
<ui>
    <linear
        orientation="vertical"
        gravity="center"
        padding="30dp"
        layout_width="match_parent"
        layout_height="match_parent"
    >
        <text
            text="用户登录"
            textSize="24sp"
            textColor="#333333"
            marginBottom="30dp"
        />
        
        <input
            id="username"
            hint="请输入用户名"
            inputType="text"
            marginBottom="15dp"
            layout_width="match_parent"
            layout_height="wrap_content"
        />
        
        <input
            id="password"
            hint="请输入密码"
            inputType="password"
            marginBottom="30dp"
            layout_width="match_parent"
            layout_height="wrap_content"
        />
        
        <button
            id="loginBtn"
            text="登录"
            onClick="handleLogin"
            background="#4CAF50"
            textColor="#FFFFFF"
            textSize="18sp"
            layout_width="match_parent"
            layout_height="wrap_content"
        />
    </linear>
</ui>
```

```javascript
function handleLogin(view) {
    let username = ui.findView("username").getText();
    let password = ui.findView("password").getText();
    
    if (username.length == 0 || password.length == 0) {
        toast("请输入用户名和密码");
        return;
    }
    
    // 执行登录逻辑
    log("登录: " + username);
}
```

### 11.2 悬浮窗示例

```xml
<ui>
    <frame
        background="#80000000"
        padding="10dp"
        layout_width="wrap_content"
        layout_height="wrap_content"
    >
        <linear orientation="vertical">
            <text
                text="自动化脚本"
                textColor="#FFFFFF"
                textSize="16sp"
            />
            <button
                id="startBtn"
                text="开始"
                onClick="startScript"
                marginTop="10dp"
            />
            <button
                id="stopBtn"
                text="停止"
                onClick="stopScript"
                marginTop="5dp"
            />
        </linear>
    </frame>
</ui>
```

```javascript
// 创建悬浮窗
let floaty = $floaty.newApp("./res/layout/floaty.xml");

// 脚本控制函数
function startScript(view) {
    toast("脚本开始运行");
    // 启动脚本逻辑
}

function stopScript(view) {
    toast("脚本已停止");
    // 停止脚本逻辑
}
```
