# AutoGOD 补充 API 规范

## 更新时间
2026-04-30

本文档包含从 aigamepro.work 获取的补充 API 文档，作为 `01_autogod-js-api-standard.md` 的补充。

---

## 七、$app - 应用操作 API

### 7.1 应用启动

```javascript
// 运行应用（应用名或包名）
$app.run("QQ");                    // 推荐写法
$app.launchApp("QQ");              // 同上
$app.launch("QQ");                 // 同上
$app.launchPkg("com.tencent.mobileqq"); // 包名方式
$app.runPkg("com.tencent.mobileqq");   // 同上

// 打开应用设置
$app.openAppSetting("AIGame");
$app.appSetting("AIGame");

// 打开自身
$app.openSelf();
```

### 7.2 应用查询

```javascript
// 获取应用列表
let apps = $app.ls();              // 所有应用
let userApps = $app.lsUserApp();  // 用户应用
let sysApps = $app.lsSysApp();    // 系统应用

// 获取最近运行的应用（需要 UsagePermit 权限）
if ($app.hasUsagePermit()) {
    let recent = $app.lsRecent();
}

// 包名操作
$app.pkgExists("com.example");     // 包名是否存在
$app.getPackageName("QQ");         // 应用名转包名
$app.appName("com.android.settings"); // 包名转应用名
```

### 7.3 应用安装/卸载

```javascript
// 安装 APK
$app.installApk("./apk/qq.apk");

// 卸载应用
$app.uninstall("QQ");
$app.uninstallPkg("com.tencent.mobileqq");
```

### 7.4 应用控制

```javascript
// 杀死应用（需要 Root 或 Shizuku）
$app.kill("QQ");

// 获取前台应用
let foreApps = $app.getForeApps();
```

### 7.5 意图操作

```javascript
// 打开网址
$app.openUrl("https://www.baidu.com");

// 发送短信
$app.sendSms("13800000000", "你好");

// 拨打电话
$app.call("13800000000");

// 发送邮件
$app.sendMail("test@example.com", "标题", "内容");

// 分享
$app.shareText("分享内容");
$app.shareImg("/sdcard/pic.png");

// 创建意图
let intent = $app.intent({
    action: "VIEW",
    data: "https://example.com",
    pkg: "com.browser"
});
$app.startActivity(intent);

// 打开 AIGame 内部界面
$app.startActivity("log");     // 日志
$app.startActivity("device"); // 设备信息
$app.startActivity("ocr");    // OCR
$app.startActivity("yolo");  // Yolo
$app.startActivity("shizuku"); // Shizuku
```

### 7.6 权限管理

```javascript
// 检查/获取使用情况权限
$app.hasUsagePermit();
$app.getUsagePermit();

// 获取应用图标
let icon = $app.getIcon("QQ");
$img.show(icon);  // 显示图标
```

---

## 八、$img - 图片操作 API

### 8.1 图片读取与保存

```javascript
// 读取图片
let img = $img.read("/sdcard/pic.png");
let img = $img.open("/sdcard/pic.png");  // 同上

// 保存图片
$img.save(img, "/sdcard/save.png");           // 默认 PNG
$img.save(img, "/sdcard/save.jpg", "jpg", 90);

// Base64 转换
let base64 = $img.toBase64(img);
let base64 = $img.toBase64("/sdcard/pic.png");
let img2 = $img.readBase64(base64);
```

### 8.2 图片裁剪与缩放

```javascript
// 裁剪图片
let clipped = $img.clip(img, x, y, w, h);

// 调整尺寸
let resized = $img.resize(img, 200, 200);  // 默认 LINEAR 插值
let resized = $img.resize(img, 200, 200, "CUBIC");

// 缩放
let scaled = $img.scale(img, 0.5, 0.5);  // 缩放倍数

// 旋转
let rotated = $img.rotate(img, 90);       // 默认绕中心
let rotated = $img.rotate(img, 45, cx, cy); // 绕指定点

// 翻转
let flipped = $img.flip(img);   // 左右翻转
let upside = $img.upside(img); // 上下翻转
```

### 8.3 图片拼接

```javascript
// 拼接图片
let combined = $img.concat(img1, img2, "bottom");  // left|right|top|bottom
```

### 8.4 图像处理

```javascript
// 灰度化
let gray = $img.gray(img);

// 二值化
let binary = $img.threshold(img, 150);

// 自适应二值化
let adaptive = $img.adaptiveThreshold(img, 255, "MEAN_C", "BINARY", 11, 2);

// 模糊处理
let blurred = $img.blur(img, [10, 10]);

// 中值滤波
let median = $img.medianBlur(img, 3);

// 高斯模糊
let gaussian = $img.gaussianBlur(img, [15, 15]);

// 颜色空间转换
let converted = $img.cvtColor(img, "RGBA2BGR");

// 颜色范围二值化
let inRange = $img.inRange(img, "#666666", "#FFFFFF");
```

### 8.5 找图找色

```javascript
// 找图
let point = $img.findImg(bigImg, smallImg, {
    similar: 0.8,           // 相似度
    region: [0, 0, 500, 600], // 范围
    trans: false,           // 是否透明找图
    drawResult: true,       // 是否保存结果
    savePath: "/sdcard/result.png"
});

// 找所有匹配
let points = $img.findImgAll(bigImg, smallImg, {similar: 0.8});

// 找颜色
let point = $img.findColor(img, "#FF0000", 5);           // 全屏
let point = $img.findColor(img, "#FF0000", 5, [0, 0, 100, 100]); // 指定范围

// 多点找色
let point = $img.findMultiColors(img, [0], "#e70216", 5, [
    -54, -13, "#db0306", 5,
    -121, -13, "#dc0407", 5
]);
```

### 8.6 图片叠加

```javascript
// 在大图上放置小图
let result = $img.putTop(bigImg, smallImg, x, y);
```

---

## 九、$device - 设备信息 API

### 9.1 设备常量

```javascript
// 屏幕尺寸
$device.width;   // 屏幕宽度
$device.height;  // 屏幕高度

// 设备信息
$device.buildId;      // Build ID
$device.brand;        // 品牌
$device.model;        // 型号
$device.device;       // 设备名
$device.sdkInt;      // SDK 版本
$device.release;      // Android 版本
$device.serial;       // 序列号
```

### 9.2 设备标识

```javascript
let imei = $device.getIMEI();
let androidId = $device.getAndroidId();
let deviceId = $device.getDeviceId();
let mac = $device.getMacAddress();
```

### 9.3 屏幕控制

```javascript
// 屏幕状态
$device.isScreenOn();   // 屏幕是否亮着
$device.isScreenOff();  // 屏幕是否息屏

// 唤醒/保持
$device.wakeUp();                    // 唤醒屏幕
$device.keepScreenOn();              // 保持常亮
$device.keepScreenOn(10000);         // 保持常亮 10 秒
$device.keepScreenDim();             // 保持低亮度
$device.cancelKeepingAwake();         // 取消保持

// 亮度
let brightness = $device.getBrightness();
let mode = $device.getBrightnessMode();
```

### 9.4 音量控制

```javascript
// 获取音量
let musicVol = $device.getMusicVolume();
let notifVol = $device.getNotificationVolume();
let alarmVol = $device.getAlarmVolume();

// 获取最大音量
let maxMusic = $device.getMusicMaxVolume();
let maxNotif = $device.getNotificationMaxVolume();
let maxAlarm = $device.getAlarmMaxVolume();
```

### 9.5 电池与内存

```javascript
let battery = $device.getBattery();    // 电池百分比
let totalMem = $device.getTotalMem(); // 总内存
let availMem = $device.getAvailMem(); // 可用内存
let isCharging = $device.isCharging(); // 是否充电中
```

### 9.6 震动与导航栏

```javascript
// 震动
$device.vibrate(1000);      // 震动 1 秒
$device.cancelVibration();  // 取消震动

// 导航栏
let hasNav = $device.hasNavBar();        // 是否有导航栏
let barHeight = $device.getVirtualBarHeight(); // 导航栏高度

// 设备锁定
let isLocked = $device.isLock();  // 是否锁定
```

---

## 十、$sys - 系统工具 API

### 10.1 系统设置

```javascript
// 飞行模式
$sys.airplane(true);   // 开启
$sys.airplane(false);  // 关闭

// 音量设置
$sys.volume("system", 100);     // 系统音量
$sys.volume("ring", 100);       // 铃声
$sys.volume("music", 100);      // 媒体
$sys.volume("alarm", 100);       // 闹钟
$sys.volume("notification", 100); // 通知

// 电池优化
$sys.ignorePower("com.example");       // 是否忽略优化
$sys.requestIgnorePower("com.example"); // 请求忽略优化
```

### 10.2 剪贴板

```javascript
// 剪贴板操作
$sys.hasClip();          // 是否有内容
$sys.getClip();         // 获取内容
$sys.setClip("内容");    // 设置内容
$sys.clearClip();        // 清除内容
```

### 10.3 前台服务

```javascript
// 前台保活
$sys.stayAlive(true);   // 开启保活
$sys.stayAlive(false);  // 关闭保活
$sys.hasStayAlive();   // 是否已开启
```

### 10.4 开发者选项

```javascript
// 指针位置
$sys.hasPointer();    // 是否开启指针
$sys.pointer(true);   // 开启指针（需要 Root/Shizuku）

// 音量控制
$sys.volumeCtrl(false); // 禁用音量键停止脚本
```

---

## 十一、$draw - 全屏绘制 API

### 11.1 权限

```javascript
// 获取悬浮窗权限
$draw.getPermit();
```

### 11.2 绘制图形

```javascript
// 矩形
$draw.rect(x, y, w, h);           // 基础矩形
$draw.rect(x, y, w, h, 50);      // 向外扩展 50px
$draw.rect(x, y, w, h, 50, "#FF0000"); // 带颜色

// 圆形
$draw.circle(x, y);                // 半径默认 50
$draw.circle(x, y, 100);          // 半径 100
$draw.circle(x, y, 100, 50);     // 扩展 50px

// 十字准心
$draw.cross(x, y);
$draw.cross([x, y]);
$draw.cross(node);                 // 通过节点

// 点
$draw.dot(x, y);

// 线
$draw.line(x1, y1, x2, y2);
$draw.line(x1, y1, x2, y2, "#FF0000");

// 路径
$draw.path([[x1,y1], [x2,y2], ...]);

// 图片
$draw.img(img, x, y, w, h);
```

### 11.3 绘制文字

```javascript
// 基础文字
$draw.text("Hello", x, y);
$draw.text("Hello", x, y, 16);     // 字体大小
$draw.text("Hello", x, y, 16, "#FF0000");

// 日志样式文字
$draw.i("信息");     // 信息（绿色）
$draw.d("调试");     // 调试（蓝色）
$draw.w("警告");     // 警告（黄色）
$draw.e("错误");     // 错误（红色）
$draw.v("详情");     // 详情（灰色）

// 带位置
$draw.i("信息", 400, 300);
$draw.i("信息", 400, 300, 20);  // 带大小
$draw.log("信息", "#57965C", 400, 300, 20);
```

### 11.4 清除

```javascript
$draw.closeAll();    // 关闭所有绘制
$draw.closeLog();    // 只关闭日志文字
$draw.clear();       // 清空所有绘制
```

---

## 十二、$tip - 阻塞式对话框 API

### 12.1 简单对话框

```javascript
// 信息对话框
$tip.i("消息");
$tip.v("消息");
$tip.w("警告");
$tip.e("错误");
$tip.d("调试");

// 带标题
$tip.show("标题", "内容");
$tip.show("标题", "内容", () => {
    toast("点击确定");
});
```

### 12.2 输入对话框

```javascript
// 文本输入
$tip.input("请输入名字", (value) => {
    toast("输入: " + value);
});

$tip.input("请输入", "默认内容", (value) => {
    // ...
});

// 数字输入
$tip.inputInt("年龄", (num) => {
    toast("年龄: " + num);
});

$tip.inputInt("年龄", 18, (num) => {
    // 有默认值
});
```

### 12.3 选择对话框

```javascript
// 单选
let items = ["选项1", "选项2", "选项3"];
$tip.one("请选择", items, (value) => {
    toast("选择: " + value);
});

// 多选
$tip.more("请选择", items, (values) => {
    toast("选择: " + values);
});
```

### 12.4 日期时间

```javascript
// 日期选择
$tip.calendar((info) => {
    let date = info.year + "-" + info.month + "-" + info.day;
});

// 时间选择
$tip.clock((info) => {
    let time = info.hour + ":" + info.minute;
});

// 滚轮选择
$tip.date((info) => { /* ... */ });
$tip.time((info) => { /* ... */ });
```

---

## 十三、$ag - 图色框架 API

### 13.1 调试模式

```javascript
// 开启/关闭调试（默认开启）
$ag.setDebug(true);  // 找到图片会绘制位置
```

### 13.2 找图

```javascript
// 找图
let point = $ag.findImg({
    path: "/sdcard/template.png",
    region: [200, 200, 800, 1000],  // 范围
    similar: 0.8,                    // 相似度
    trans: false                     // 是否透明找图
});

if (point != null) {
    $act.click(point);
}
```

### 13.3 找色

```javascript
// 找颜色
let point = $ag.findColor({
    color: "#FF0000",
    region: [0, 0, 500, 500],
    threshold: 5
});

// 多点找色
let point = $ag.findMultiColor({
    firstColor: "#FF0000",
    region: [0, 0, 500, 500],
    threshold: 5,
    points: [
        [10, 10, "#00FF00", 5],
        [20, 20, "#0000FF", 5]
    ]
});
```

### 13.4 等待出现

```javascript
// 等待图片出现并点击
$ag.waitImgClick({
    path: "/sdcard/button.png",
    timeout: 5000
});

// 等待颜色出现并点击
$ag.waitColorClick({
    color: "#FF0000",
    region: [0, 0, 500, 500]
});
```

### 13.5 关闭绘制

```javascript
$ag.closeDraw();
```

---

## 十四、$thread - 并发编程 API

### 14.1 线程创建

```javascript
// 创建并运行线程
let t1 = $thread.run(() => {
    // 耗时操作
});

// 创建线程
let t2 = $thread.create(() => {
    for (let i = 0; i < 10; i++) {
        log(i);
        sleep(300);
    }
});
t2.start();

// 带名称的线程
let t3 = $thread.create("myThread", () => {
    // ...
});
t3.start();
```

### 14.2 线程控制

```javascript
// 停止线程
t1.interrupt();
$thread.stop(t1);
$thread.stop("threadName");
$thread.stopAll();  // 停止所有

// 检查线程存在
$thread.has("threadName");
$thread.get("threadName");
```

### 14.3 循环执行器

```javascript
// 创建循环器
let loop = $thread.loop("myLoop", () => {
    log("循环中...");
    sleep(1000);
});
loop.start();

// 停止循环器
$thread.stopLoop("myLoop");
$thread.hasLoop("myLoop");
$thread.stopAllLoop();
```

### 14.4 UI 线程

```javascript
// 在 UI 线程执行
$thread.ui(() => {
    // UI 操作
});

// 或使用
$ui.run(() => {
    // UI 操作
});
```

### 14.5 倒计时锁

```javascript
// 创建倒计时锁
let lock = $thread.newCdLock(10);  // 10 次

// 使用
if (lock.lock()) {
    // 获取锁成功
    // ...
    lock.unlock();  // 释放锁
}
```

---

## 十五、$str - 字符串操作 API

### 15.1 编码转换

```javascript
// Base64
let base64 = $str.encodeBase64("字符串");
let str = $str.decodeBase64(base64);

// Hex
let hex = $str.strToHex("字符串");
let original = $str.hexToStr(hex);

// URI
let encoded = $str.uriEncode("字符串");
let decoded = $str.uriDecode(encoded);

// 字节
let bytes = $str.getBytes("字符串");
```

### 15.2 空值检查

```javascript
$str.isEmpty(str);       // 是否为空
$str.isNotEmpty(str);    // 是否不为空
$str.isBlank(str);       // 是否空白
$str.isNotBlank(str);    // 是否不是空白
$str.hasBlank(["a", " ", "b"]);  // 是否有空白
$str.isAllBlank([" ", "  "]);    // 是否全是空白
```

### 15.3 空值处理

```javascript
$str.emptyIfNull(null);       // null 转空字符串
$str.nullToEmpty(null);       // 同上
$str.nullToDefault(null, "默认");  // null 转默认值
$str.emptyToDefault("", "默认");    // 空转默认值
```

### 15.4 截取

```javascript
$str.subStart("ABCDEF", 3);   // 截取开头 3 个字符 -> "ABC"
$str.subEnd("ABCDEF", 3);     // 截取末尾 3 个字符 -> "DEF"
$str.trim(" ABC ");           // 去除首尾空格
$str.sub(0, 5);              // 截取 [0, 5)
```

### 15.5 大小写与格式

```javascript
$str.upperFirst("abc");       // 首字母大写 -> "Abc"
$str.lowerFirst("ABC");       // 首字母小写 -> "aBC"
$str.toCamelCase("hello_world"); // 驼峰 -> "helloWorld"
$str.toUnderlineCase("helloWorld"); // 下划线 -> "hello_world"
```

### 15.6 判断

```javascript
$str.startsWith("ABC", "AB");      // 是否以...开头
$str.endsWith("ABC", "BC");       // 是否以...结尾
$str.contains("ABC", "B");        // 是否包含
$str.equalsIgnoreCase("ABC", "abc"); // 忽略大小写比较
```

### 15.7 替换

```javascript
$str.replace("Hello World", "World", "AutoGOD");
$str.replaceIgnoreCase("Hello World", "hello", "Hi");
$str.replaceFirst("aaa", "a", "b");  // 替换第一个
$str.replaceLast("aaa", "a", "b");   // 替换最后一个
```

### 15.8 分割与合并

```javascript
$str.split("a,b,c", ",");           // 分割成数组
$str.join(",", ["a", "b", "c"]);   // 合并成字符串
$str.repeat("ab", 3);               // 重复 -> "ababab"
```

### 15.9 填充与截断

```javascript
$str.padPre("abc", 5, "0");         // 前面填充 -> "00abc"
$str.padAfter("abc", 5, "0");      // 后面填充 -> "abc00"
$str.brief("很长很长的字符串", 10);  // 截断 -> "很长很长的..."
```

### 15.10 数字与随机

```javascript
$str.extractNumbers("abc123def456"); // 提取数字 -> "123,456"
$str.isNumeric("123");              // 是否为数字
$str.random("abcdef");               // 随机字符
$str.random(["a", "b", "c"]);       // 随机数组元素
```

---

## 十六、更多 API 模块

根据侧边栏，还有以下模块可用：

- `$arc` - 悬浮球
- `$bus` - 消息总线
- `$color` - 颜色操作
- `$date` - 日期工具
- `$engine` - 脚本引擎
- `$event` - 事件监听
- `$excel` - 表格操作
- `$ext` - 拓展加载
- `$fc` - 文件选择器
- `$global` - 全局函数
- `$hid` - 键鼠触控
- `$html` - 网页操作
- `$log` - 日志框架
- `$media` - 媒体播放
- `$permit` - 权限工具
- `$plugin` - 插件系统
- `$qr` - 二维码工具
- `$res` - 资源管理
- `$root` - ROOT 与 Shell
- `$sqlite` - 轻量数据库
- `$storage` - 应用存储
- `$szk` - Shizuku 工具
- `$tts` - 语音阅读
- `$ws` - WebSocket
- `$yolo` - 目标检测

完整的 API 文档请参考：https://aigamepro.work/api_en/
