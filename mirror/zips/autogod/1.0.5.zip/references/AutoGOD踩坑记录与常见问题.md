# AutoGOD 踩坑记录与常见问题

> 最后更新：2026-05-02
> 来源：实际开发调试经验，所有条目均经真机验证

---

## 一、API 陷阱（模块不存在 / 名称错误）

### 1.1 `$log` 不存在
- ❌ `$log("66600")` → 报错
- ✅ `log("66600")` — `log` 是全局函数，不带 `$` 前缀
- **规则**：`log/sleep/tip/alert/toast/random/require/getClip/setClip` 属于 `$global` 全局函数，直接调用不加 `$`

### 1.2 `$files` 不存在
- ❌ `$files.read(path)` → 报错
- ✅ `$file.read(path)` — 文件系统模块是 `$file`，不是 `$files`

### 1.3 `$dialog` 不在运行环境
- ❌ `$dialog.create(...)` → "找不到函数 create"
- ✅ 用 `$floaty` 或 `$tip.show()` 替代
- `$dialog` 是需要加载的 lib，不在默认运行环境里

### 1.4 `ui.ids()` 不存在
- ❌ `ui.ids("xxx")` → 报错
- ✅ `ui.id("xxx")` — 单数形式，不是复数

### 1.5 `$floaty.create()` 不存在
- ❌ `$floaty.create().setLayout().id().click().show()` → 链式调用全部失败
- ✅ `$floaty.newApp(xml)` / `$floaty.newAdj(xml)` / `$floaty.newSys(xml)`
- `newAdj ≠ create`，必须用 `new*` 系列方法

---

## 二、XML 布局陷阱

### 2.1 `visibility="gone"` XML 属性不生效
- ❌ `<frame id="hiddenLayer" visibility="gone">` → 不隐藏，控件仍然显示
- ✅ 在 JS 中控制：
  ```js
  var ui = $ui.layout("main.xml");
  ui.show();
  ui.id("hiddenLayer").setVisibility($ui.GONE);  // JS 中隐藏
  ```
- **原因**：AutoGOD XML 解析器不支持 `visibility` 属性，这是 Android 原生属性，不能直接套用

### 2.2 `gravity` vs `layout_gravity` 混淆
- `gravity` → 控制**自身内容**在自身范围内的对齐方式
  - 例：`<linear gravity="center">` 让 linear 内部的子控件居中排列
- `layout_gravity` → 控制**自身**在父布局中的位置
  - 例：`<frame layout_gravity="center">` 让 frame 在父布局中居中显示
- **常见错误**：想让弹窗层居中显示，写了 `gravity="center"`，结果内容居中了但弹窗本身靠顶端对齐
- **正确做法**：弹窗居中用 `layout_gravity="center"`，内部内容居中用 `gravity="center"`

### 2.3 XML 根标签必须是 `<ui>`
- ❌ `<?xml version="1.0"?>` 声明头 → 解析错误
- ❌ `<vertical>` 作为根标签 → 不识别
- ✅ `<ui>` 作为根标签
- ✅ 垂直布局用 `<linear dir="v">`

### 2.4 XML 宽高不支持百分号
- ❌ `w="40%"` → 不生效或报错
- ✅ 只能用具体 dp 数值：`w="400dp"`
- 如需按比例，在 JS 中计算具体数值后写入

---

## 三、引擎与运行时陷阱

### 3.1 Rhino 引擎不支持 async/await
- ❌ `async function foo() { await bar(); }` → 语法错误
- ✅ 全部使用同步写法
- AutoGOD 使用 Rhino/Modescript 引擎，仅支持 ES5+ 部分特性

### 3.2 function 声明前必须加分号
- ❌ `} } function foo() {}` → 引擎解析混乱
- ✅ `} }; function foo() {}` — 分号明确块级作用域结束
- **原因**：Rhino 引擎无法区分块级作用域结尾和函数表达式声明起始

### 3.3 真机运行缓存问题
- **现象**：修改代码后在真机运行，仍然执行旧代码（如已删除的延迟代码仍生效）
- **解决方法**：
  1. 从后台彻底杀掉 AutoGOD 进程（划掉）
  2. 重新打开运行
  3. 如仍缓存，在 AutoGOD 设置里找"重启引擎"选项
- **预防**：每次修改后都先停止脚本再重新运行，不要直接覆盖运行

### 3.4 `$ui.id("mAppbar")` 未找到控件提示
- **现象**：运行时提示 `ui:id:未找到控件:mAppbar`
- **原因**：AutoGOD 框架内部尝试查找默认 appbar 组件，不是用户代码的问题
- **处理**：可忽略，不影响功能。如需消除提示，可在 XML 中加 `<appbar id="mAppbar"/>`

---

## 四、$tip 对话框陷阱

### 4.1 `$tip.one()` 存在！（曾误记为不存在）
- ✅ `$tip.one(title, items, callback)` — 单选对话框，官方文档确认存在
- **教训**：不能因为一次调用失败就判定 API 不存在，应先查文档确认

---

## 五、$file 文件系统陷阱

### 5.1 创建目录的间接方式
- AutoGOD 的 `$file` 没有直接的 `mkdir` 方法
- **变通**：向目标目录写入一个临时文件即可创建目录
  ```js
  var dir = $file.join($file.sd(), "dongzuo");
  if (!$file.isDir(dir)) {
      $file.write($file.join(dir, ".nomedia"), "");  // 写文件自动创建目录
  }
  ```
- 之后即可正常写入文件到该目录

### 5.2 $file.write 参数
- `$file.write(path, content)` — 写入文件
- `$file.add(path, content)` — 追加内容
- `$file.read(path)` — 读取文件
- 注意：`write` 会覆盖，`add` 才是追加

---

## 六、隐藏图层（弹窗）的正确实现模式

```xml
<!-- XML: 外层 frame 包裹主界面 + 隐藏图层 -->
<ui>
    <frame w="max" h="max">
        <!-- 主界面 -->
        <linear dir="v" w="max" h="max" bg="#FFFFFF" gravity="center">
            <button id="btn1" text="按钮1" w="400dp" h="80dp"/>
        </linear>

        <!-- 隐藏图层：不写 visibility="gone"，用 JS 控制 -->
        <frame id="hiddenLayer" w="400dp" h="400dp" bg="#FFB6C1" layout_gravity="center">
            <linear dir="v" w="max" h="max" gravity="center" padding="20">
                <text text="创建文件" textSize="20sp"/>
                <input id="fileNameInput" hint="请输入文件名" w="max"/>
                <linear dir="h" w="max" gravity="center">
                    <button id="btnCancel" text="取消" weight="1"/>
                    <button id="btnConfirm" text="确定" weight="1"/>
                </linear>
            </linear>
        </frame>
    </frame>
</ui>
```

```js
// JS: 初始化隐藏 + 事件注册
var ui = $ui.layout("main.xml");
ui.show();

// 初始化：隐藏弹窗层
ui.id("hiddenLayer").setVisibility($ui.GONE);

// 显示弹窗
ui.id("btn1").click(function() {
    ui.id("hiddenLayer").setVisibility($ui.VISIBLE);
});

// 取消：隐藏弹窗
ui.id("btnCancel").click(function() {
    ui.id("hiddenLayer").setVisibility($ui.GONE);
});

// 确定：创建文件并隐藏弹窗
ui.id("btnConfirm").click(function() {
    var fileName = ui.id("fileNameInput").getText();
    if (fileName && fileName.trim() !== "") {
        var dir = $file.join($file.sd(), "dongzuo");
        if (!$file.isDir(dir)) {
            $file.write($file.join(dir, ".nomedia"), "");
        }
        var filePath = $file.join(dir, fileName + ".json");
        $file.write(filePath, "{}");
        ui.id("hiddenLayer").setVisibility($ui.GONE);
        ui.id("fileNameInput").setText("");
        toast("文件已创建: " + filePath);
    } else {
        ui.id("fileNameInput").setError("文件名不能为空");
    }
});
```

**关键要点**：
1. 弹窗用 `layout_gravity="center"` 居中（不是 `gravity`）
2. 初始隐藏用 JS 的 `setVisibility($ui.GONE)`（不是 XML 的 `visibility="gone"`）
3. `ui.show()` 之后再设置隐藏，确保控件已创建

---

## 七、核心原则

1. **必须查文档**：任何 API 用之前必须先读学习库文档验证，不能凭记忆猜测
2. **Android 经验不能直接套用**：AutoGOD 虽然类似 Android，但很多属性/方法不存在或不生效
3. **真机与模拟器行为可能不同**：缓存问题、渲染差异等
4. **报错先查模块是否存在**：`$xxx` 不存在是很常见的错误来源

---

## 学习库路径

- 完整学习库：`F:\小龙虾文件仓\0.AI技能体\4.技能学习库\autogod\学习结果\`
- API 模块文档：`学习结果\API模块\$xxx - 中文名.md`
- UI 框架文档：`学习结果\UI框架\`
- 代码示例：`学习结果\代码示例\`
