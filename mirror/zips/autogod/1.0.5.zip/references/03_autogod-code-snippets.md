# AutoGOD 纯净代码范式示例

## 更新时间
2026-04-30

## 一、初始化范式

### 1.1 标准初始化流程

```javascript
/**
 * 标准初始化流程
 * 1. 申请必要权限
 * 2. 初始化模块
 * 3. 检查环境
 */
async function init() {
    // 申请无障碍权限
    if (!$act.hasPermit()) {
        log("申请无障碍权限...");
        $act.getPermit();
    }
    
    // 申请截屏权限
    if (!$screen.hasPermit()) {
        log("申请截屏权限...");
        $screen.getPermit();
    }
    
    // 初始化 OCR
    $ocr.v("mlkit");
    $ocr.init();
    
    log("初始化完成");
}

// 执行初始化
init();
```

### 1.2 带超时的初始化

```javascript
async function initWithTimeout(timeout = 10000) {
    let startTime = Date.now();
    
    // 申请权限（带超时）
    while (!$act.hasPermit() || !$screen.hasPermit()) {
        if (Date.now() - startTime > timeout) {
            throw new Error("权限申请超时");
        }
        
        if (!$act.hasPermit()) {
            $act.getPermit();
        }
        if (!$screen.hasPermit()) {
            $screen.getPermit();
        }
        
        sleep(1000);
    }
    
    log("初始化完成");
}
```

## 二、点击操作范式

### 2.1 安全点击（带重试）

```javascript
/**
 * 安全点击：点击指定坐标，失败时重试
 * @param {number} x - X 坐标
 * @param {number} y - Y 坐标
 * @param {number} retryCount - 重试次数
 * @param {number} retryDelay - 重试延迟（毫秒）
 */
function safeClick(x, y, retryCount = 3, retryDelay = 1000) {
    for (let i = 0; i < retryCount; i++) {
        try {
            $act.click(x, y);
            sleep(500);  // 等待响应
            
            // 验证点击效果（可选）
            // if (checkClickSuccess()) {
            //     return true;
            // }
            
            return true;
        } catch (e) {
            log(`点击失败 (第 ${i+1} 次): ${e}`);
            if (i < retryCount - 1) {
                sleep(retryDelay);
            }
        }
    }
    return false;
}
```

### 2.2 节点点击（推荐）

```javascript
/**
 * 通过选择器点击节点
 * @param {object} selector - 选择器配置
 * @param {number} timeout - 超时时间（毫秒）
 */
function clickNode(selector, timeout = 3000) {
    try {
        let node = $act.selector()
            .pkg(selector.pkg || null)
            .cls(selector.cls || null)
            .text(selector.text || null)
            .desc(selector.desc || null)
            .id(selector.id || null)
            .waitFirst(timeout);
        
        if (node != null) {
            node.draw();  // 调试：绘制节点位置
            node.click();
            return true;
        } else {
            log("未找到节点");
            return false;
        }
    } catch (e) {
        log("节点点击失败: " + e);
        return false;
    }
}

// 使用示例
clickNode({
    pkg: "com.example.app",
    cls: "android.widget.Button",
    text: "确定"
});
```

### 2.3 文字识别点击

```javascript
/**
 * 识别文字并点击
 * @param {string} targetText - 目标文字
 * @param {object} options - OCR 配置
 */
function clickText(targetText, options = {}) {
    try {
        let point = $ocr.getPoint(targetText, {
            region: options.region || null,
            gray: options.gray || false,
            threshold: options.threshold || 20
        });
        
        if (point != null) {
            $act.click(point);
            return true;
        } else {
            log("未找到文字: " + targetText);
            return false;
        }
    } catch (e) {
        log("文字识别点击失败: " + e);
        return false;
    }
}

// 使用示例
clickText("登录", { region: [0, 0, 500, 200] });
```

### 2.4 图像识别点击

```javascript
/**
 * 找图并点击
 * @param {string} templatePath - 模板图片路径
 * @param {number} threshold - 相似度阈值（0-1）
 */
function clickImage(templatePath, threshold = 0.8) {
    try {
        // 截屏
        let screen = $screen.getScreen();
        
        // 读取模板
        let template = $img.read(templatePath);
        
        // 找图
        let result = $img.find(screen, template, threshold);
        
        if (result != null) {
            let centerX = result.x + template.getWidth() / 2;
            let centerY = result.y + template.getHeight() / 2;
            
            $act.click(centerX, centerY);
            
            // 释放资源
            screen.recycle();
            template.recycle();
            
            return true;
        } else {
            log("未找到图片");
            screen.recycle();
            template.recycle();
            return false;
        }
    } catch (e) {
        log("图像识别点击失败: " + e);
        return false;
    }
}
```

## 三、滑动操作范式

### 3.1 标准滑动

```javascript
/**
 * 标准滑动：从起点滑到终点
 * @param {number} startX - 起点X
 * @param {number} startY - 起点Y
 * @param {number} endX - 终点X
 * @param {number} endY - 终点Y
 * @param {number} duration - 持续时间（毫秒）
 */
function swipe(startX, startY, endX, endY, duration = 500) {
    try {
        $act.slide(startX, startY, endX, endY, duration);
        return true;
    } catch (e) {
        log("滑动失败: " + e);
        return false;
    }
}
```

### 3.2 翻页滑动

```javascript
/**
 * 向上翻页（内容向下滚动）
 * @param {number} distance - 滑动距离
 */
function pageUp(distance = 800) {
    let w = $screen.getWidth();
    let h = $screen.getHeight();
    
    $act.slide(
        w / 2, h * 0.7,  // 起点：屏幕中下方
        w / 2, h * 0.7 - distance,  // 终点
        500  // 持续时间
    );
}

/**
 * 向下翻页（内容向上滚动）
 */
function pageDown(distance = 800) {
    let w = $screen.getWidth();
    let h = $screen.getHeight();
    
    $act.slide(
        w / 2, h * 0.3,  // 起点：屏幕中上方
        w / 2, h * 0.3 + distance,  // 终点
        500
    );
}
```

### 3.3 滑动找元素

```javascript
/**
 * 滑动查找元素
 * @param {object} selector - 选择器
 * @param {string} direction - 滑动方向（up|down）
 * @param {number} maxSwipe - 最大滑动次数
 */
function swipeToFind(selector, direction = "up", maxSwipe = 10) {
    for (let i = 0; i < maxSwipe; i++) {
        // 查找元素
        let node = $act.selector()
            .text(selector.text || null)
            .cls(selector.cls || null)
            .waitFirst(1000);
        
        if (node != null) {
            return node;
        }
        
        // 滑动
        if (direction == "up") {
            pageUp();
        } else {
            pageDown();
        }
        
        sleep(500);
    }
    
    log("滑动查找失败，未找到元素");
    return null;
}
```

## 四、等待与超时范式

### 4.1 等待元素出现

```javascript
/**
 * 等待元素出现
 * @param {object} selector - 选择器
 * @param {number} timeout - 超时时间（毫秒）
 */
function waitForElement(selector, timeout = 10000) {
    let startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
        let node = $act.selector()
            .text(selector.text || null)
            .cls(selector.cls || null)
            .waitFirst(500);
        
        if (node != null) {
            return node;
        }
        
        sleep(200);
    }
    
    return null;
}
```

### 4.2 等待文字出现

```javascript
/**
 * 等待指定文字出现
 * @param {string} targetText - 目标文字
 * @param {number} timeout - 超时时间（毫秒）
 */
function waitForText(targetText, timeout = 10000) {
    let startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
        let point = $ocr.getPoint(targetText);
        
        if (point != null) {
            return point;
        }
        
        sleep(500);
    }
    
    return null;
}
```

### 4.3 等待界面切换

```javascript
/**
 * 等待切换到指定界面
 * @param {string} targetActivity - 目标 Activity
 * @param {number} timeout - 超时时间（毫秒）
 */
function waitForActivity(targetActivity, timeout = 10000) {
    let startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
        let current = $act.activity();
        
        if (current == targetActivity) {
            return true;
        }
        
        sleep(200);
    }
    
    return false;
}
```

## 五、循环与重试范式

### 5.1 重试执行

```javascript
/**
 * 重试执行函数
 * @param {function} fn - 要执行的函数
 * @param {number} retryCount - 重试次数
 * @param {number} retryDelay - 重试延迟（毫秒）
 */
async function retry(fn, retryCount = 3, retryDelay = 1000) {
    for (let i = 0; i < retryCount; i++) {
        try {
            let result = await fn();
            return result;
        } catch (e) {
            log(`执行失败 (第 ${i+1} 次): ${e}`);
            
            if (i < retryCount - 1) {
                sleep(retryDelay);
            }
        }
    }
    
    throw new Error("重试次数耗尽");
}
```

### 5.2 循环执行直到成功

```javascript
/**
 * 循环执行直到成功或超时
 * @param {function} condition - 成功条件函数
 * @param {function} action - 每次执行的动作
 * @param {number} timeout - 超时时间（毫秒）
 * @param {number} interval - 执行间隔（毫秒）
 */
function loopUntilSuccess(condition, action, timeout = 30000, interval = 1000) {
    let startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
        // 执行动作
        action();
        
        // 检查条件
        if (condition()) {
            return true;
        }
        
        sleep(interval);
    }
    
    return false;
}
```

### 5.3 有限次循环

```javascript
/**
 * 有限次循环执行
 * @param {function} action - 执行动作
 * @param {number} maxCount - 最大次数
 * @param {function} breakCondition - 中断条件
 */
function loopWithCount(action, maxCount, breakCondition = null) {
    for (let i = 0; i < maxCount; i++) {
        log(`执行第 ${i+1} 次`);
        
        let result = action(i);
        
        // 检查中断条件
        if (breakCondition && breakCondition(result)) {
            log("满足中断条件，停止循环");
            break;
        }
        
        sleep(500);
    }
}
```

## 六、异常处理范式

### 6.1 标准异常处理

```javascript
/**
 * 安全执行函数
 * @param {function} fn - 要执行的函数
 * @param {any} defaultValue - 失败时的默认返回值
 */
function safeExecute(fn, defaultValue = null) {
    try {
        return fn();
    } catch (e) {
        log("执行失败: " + e);
        return defaultValue;
    }
}
```

### 6.2 带日志的异常处理

```javascript
/**
 * 带详细日志的执行
 * @param {string} operation - 操作名称
 * @param {function} fn - 执行函数
 */
function executeWithLog(operation, fn) {
    log(`开始执行: ${operation}`);
    let startTime = Date.now();
    
    try {
        let result = fn();
        let duration = Date.now() - startTime;
        log(`执行成功: ${operation} (耗时 ${duration}ms)`);
        return result;
    } catch (e) {
        let duration = Date.now() - startTime;
        log(`执行失败: ${operation} (耗时 ${duration}ms)`);
        log(`错误信息: ${e}`);
        throw e;
    }
}
```

## 七、数据采集范式

### 7.1 截屏保存

```javascript
/**
 * 截屏并保存
 * @param {string} savePath - 保存路径
 * @param {string} prefix - 文件名前缀
 */
function saveScreenshot(savePath, prefix = "screenshot") {
    try {
        let timestamp = new Date().getTime();
        let fileName = `${prefix}_${timestamp}.png`;
        let fullPath = $file.join(savePath, fileName);
        
        $screen.save(fullPath);
        log("截屏已保存: " + fullPath);
        
        return fullPath;
    } catch (e) {
        log("截屏保存失败: " + e);
        return null;
    }
}
```

### 7.2 批量采集

```javascript
/**
 * 批量采集数据
 * @param {function} collectFn - 采集函数
 * @param {number} count - 采集数量
 * @param {number} interval - 采集间隔（毫秒）
 */
function batchCollect(collectFn, count, interval = 1000) {
    let results = [];
    
    for (let i = 0; i < count; i++) {
        try {
            let data = collectFn(i);
            results.push(data);
            log(`采集进度: ${i+1}/${count}`);
        } catch (e) {
            log(`采集失败 (第 ${i+1} 次): ${e}`);
        }
        
        if (i < count - 1) {
            sleep(interval);
        }
    }
    
    return results;
}
```

### 7.3 数据保存

```javascript
/**
 * 保存数据到文件
 * @param {array} data - 数据数组
 * @param {string} filePath - 文件路径
 * @param {string} format - 格式（json|csv|txt）
 */
function saveData(data, filePath, format = "json") {
    try {
        let content = "";
        
        if (format == "json") {
            content = JSON.stringify(data, null, 2);
        } else if (format == "csv") {
            content = data.map(row => row.join(",")).join("\n");
        } else {
            content = data.join("\n");
        }
        
        $file.write(content, filePath);
        log("数据已保存: " + filePath);
        
        return true;
    } catch (e) {
        log("数据保存失败: " + e);
        return false;
    }
}
```

## 八、网络请求范式

### 8.1 标准 HTTP 请求

```javascript
/**
 * 发送 HTTP 请求
 * @param {string} method - 请求方法
 * @param {string} url - 请求地址
 * @param {object} data - 请求数据
 * @param {object} headers - 请求头
 */
function httpRequest(method, url, data = null, headers = {}) {
    try {
        let options = {
            url: url,
            head: headers,
            connectTimeout: 30,
            readTimeout: 30
        };
        
        if (method == "GET") {
            return $http.get(options);
        } else if (method == "POST") {
            options.data = data;
            return $http.post(options);
        }
        
    } catch (e) {
        log("HTTP 请求失败: " + e);
        return null;
    }
}
```

### 8.2 带重试的请求

```javascript
/**
 * 带重试的 HTTP 请求
 * @param {string} url - 请求地址
 * @param {number} retryCount - 重试次数
 */
function requestWithRetry(url, retryCount = 3) {
    for (let i = 0; i < retryCount; i++) {
        try {
            let response = $http.get(url);
            
            if (response != null && response.code() == 200) {
                return response;
            }
            
            log(`请求失败 (第 ${i+1} 次): HTTP ${response.code()}`);
            
        } catch (e) {
            log(`请求异常 (第 ${i+1} 次): ${e}`);
        }
        
        if (i < retryCount - 1) {
            sleep(2000);
        }
    }
    
    return null;
}
```

## 九、完整脚本模板

### 9.1 标准脚本结构

```javascript
/**
 * AutoGOD 标准脚本模板
 * 
 * 功能：[脚本功能描述]
 * 作者：[作者]
 * 日期：[日期]
 */

// ==================== 配置区 ====================
const CONFIG = {
    APP_PACKAGE: "com.example.app",
    TIMEOUT: 10000,
    RETRY_COUNT: 3
};

// ==================== 初始化区 ====================
async function init() {
    log("开始初始化...");
    
    // 申请权限
    if (!$act.hasPermit()) {
        $act.getPermit();
    }
    if (!$screen.hasPermit()) {
        $screen.getPermit();
    }
    
    // 初始化模块
    $ocr.v("mlkit");
    $ocr.init();
    
    log("初始化完成");
}

// ==================== 功能区 ====================
function step1() {
    log("执行步骤1...");
    // 功能代码
}

function step2() {
    log("执行步骤2...");
    // 功能代码
}

// ==================== 主流程 ====================
async function main() {
    try {
        // 初始化
        await init();
        
        // 执行步骤
        step1();
        step2();
        
        log("脚本执行完成");
        
    } catch (e) {
        log("脚本执行失败: " + e);
    }
}

// ==================== 启动 ====================
main();
```

### 9.2 带悬浮窗控制

```javascript
/**
 * 带悬浮窗控制的脚本模板
 */

// 状态变量
let isRunning = false;

// 创建悬浮窗
function createFloaty() {
    let floaty = $floaty.newApp(`<ui>
        <frame background="#80000000" padding="10dp">
            <linear orientation="vertical">
                <text id="status" text="就绪" textColor="#FFFFFF" />
                <button id="toggleBtn" text="开始" onClick="toggleScript" marginTop="10dp" />
            </linear>
        </frame>
    </ui>`);
    
    return floaty;
}

// 切换运行状态
function toggleScript(view) {
    isRunning = !isRunning;
    
    let btn = ui.findView("toggleBtn");
    let status = ui.findView("status");
    
    if (isRunning) {
        btn.setText("停止");
        status.setText("运行中...");
        main();
    } else {
        btn.setText("开始");
        status.setText("已停止");
    }
}

// 主流程
async function main() {
    while (isRunning) {
        try {
            // 执行自动化逻辑
            log("执行中...");
            sleep(1000);
            
        } catch (e) {
            log("执行失败: " + e);
            isRunning = false;
            break;
        }
    }
}

// 启动
if (!$floaty.hasPermit()) {
    $floaty.getPermit();
}
createFloaty();
```
