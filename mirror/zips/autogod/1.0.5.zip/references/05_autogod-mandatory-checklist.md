# AutoGOD 代码生成前强制自检清单

## 更新时间
2026-05-01

## 使用说明

**【强制】在生成任何 AutoGOD 代码之前，必须完成以下所有检查项。**

在回复中声明：
```
✅ 已完成强制自检：
- [x] 检查项1
- [x] 检查项2
...
```

---

## 一、XML 布局语法检查（v2 UI 框架）⚠️ 2026-05-01 新增

> AutoGOD v2 使用全新 UI 框架，必须先读取 `references/ui/` 对应模块文档确认标签和属性名。

### 1.1 根节点检查

- [ ] XML 文件**没有** `<?xml version="1.0"...?>` 声明头
- [ ] 根节点是 `<ui>`（不是 `<界面>` `<layout>` 或无根标签）
- [ ] 所有控件都包裹在 `<ui>...</ui>` 内

### 1.2 标签名检查

- [ ] 使用小写标签名：`<linear>` `<scroll>` `<frame>` `<relative>`
- [ ] **没有**驼峰命名：`<LinearLayout>` ❌ → `<linear>` ✅
- [ ] **没有** Android 全限定名：`<android.widget.LinearLayout>` ❌

### 1.3 属性名检查

- [ ] 方向用 `dir`：`dir="v"`（垂直）或 `dir="h"`（水平）
- [ ] 背景色用 `bg`：`bg="#FFFFFF"`
- [ ] 字体样式用 `typeface`：`typeface="bold"`
- [ ] 文字颜色用 `color`：`color="#333333"`
- [ ] 多值间距用逗号：`padding="10,20,10,15"`（不是空格）
- [ ] 宽高用 `w`/`h`：`w="max"` `h="wrap"`（不是 `layout_width`）

### 1.4 路径检查

- [ ] `$ui.layout()` 路径相对于项目根目录
- [ ] JS 在 `src/main.js`，XML 在 `src/main.xml`，路径写 `src/main.xml`

---

## 二、API 调用规范检查

### 1.1 API 名称检查

- [ ] 所有 API 名称拼写正确（参考 `01_autogod-js-api-standard.md`）
- [ ] 大小写正确（如 `$screen.getScreen()` 不是 `getscreen()`）
- [ ] 使用正确的模块前缀（`$act`、`$screen`、`$ocr`、`$http`、`$floaty`、`$file`）

**常见错误：**
```
❌ $act.clickk()        ✅ $act.click()
❌ $screen.getscreen()  ✅ $screen.getScreen()
❌ $ocr.detct()         ✅ $ocr.detect()
```

### 1.2 参数类型检查

- [ ] 坐标参数为整数（不是浮点数或字符串）
- [ ] 时长参数为数字（毫秒）
- [ ] 文本参数为字符串
- [ ] 配置对象格式正确

**检查示例：**
```javascript
// ❌ 错误
$act.click("500", "800");      // 字符串
$act.click(500.5, 800.2);      // 浮点数

// ✅ 正确
$act.click(500, 800);          // 整数
$act.click(Math.floor(500.5), Math.floor(800.2));  // 取整
```

### 1.3 参数完整性检查

- [ ] 必填参数都已提供
- [ ] 参数顺序正确
- [ ] 可选参数使用正确

**参数顺序：**
```javascript
// click: (x, y, dur?, delay?)
// move: (x1, y1, x2, y2, dur?, delay?)
// write: (content, path, encoding?)
```

---

## 二、权限申请顺序检查

### 2.1 权限依赖关系

- [ ] 无障碍权限在截屏权限之前申请（安卓11+ 可用无障碍截屏）
- [ ] 存储权限在文件操作之前申请
- [ ] 悬浮窗权限在创建悬浮窗之前申请

**正确顺序：**
```javascript
async function init() {
    // 1. 无障碍权限（优先）
    if (!$act.hasPermit()) {
        $act.getPermit();
    }
    
    // 2. 截屏权限
    if (!$screen.hasPermit()) {
        $screen.getPermit();
    }
    
    // 3. 悬浮窗权限
    if (!$floaty.hasPermit()) {
        $floaty.getPermit();
    }
    
    // 4. 其他权限
    // ...
}
```

### 2.2 权限检查函数

- [ ] 所有需要权限的操作前都有权限检查
- [ ] 使用正确的检查函数（`hasPermit()` 不是 `getPermit()`）

**权限检查表：**

| 操作 | 权限检查函数 |
|------|-------------|
| 手势操作 | `$act.hasPermit()` |
| 截屏操作 | `$screen.hasPermit()` |
| 悬浮窗 | `$floaty.hasPermit()` |
| 读取图片 | `$permit.readImage()` |
| 读取视频 | `$permit.readVideo()` |
| 读取音频 | `$permit.readAudio()` |

### 2.3 UI 线程权限申请

- [ ] UI 线程中使用非阻塞方式（`$permit.wza()`）
- [ ] 或使用线程执行阻塞函数

**正确做法：**
```javascript
// ✅ UI 线程：使用非阻塞方式
ui.findView("btn").setOnClickListener(() => {
    $permit.wza();  // 非阻塞
});

// ✅ 或使用线程
ui.findView("btn").setOnClickListener(() => {
    threads.start(() => {
        $act.getPermit();  // 在线程中阻塞
    });
});
```

---

## 三、异步操作处理检查

### 3.1 async/await 使用

- [ ] 所有异步函数使用 `async` 声明
- [ ] 所有异步调用使用 `await` 等待
- [ ] 异步函数调用在 async 上下文中

**正确示例：**
```javascript
// ✅ 正确
async function main() {
    await $act.getPermit();
    await $screen.getPermit();
    let img = await $screen.getScreen();
    // ...
}
```

### 3.2 回调函数

- [ ] 回调函数参数正确
- [ ] 回调中异常已处理
- [ ] 避免回调地狱（使用 async/await）

**正确示例：**
```javascript
// ✅ 正确：回调
$http.download(url, path,
    (cur, total, percent) => { /* 进度 */ },
    () => { /* 完成 */ },
    (err) => { /* 错误 */ }
);

// ✅ 正确：async/await（推荐）
async function download() {
    try {
        await $http.download(url, path);
        log("下载完成");
    } catch (e) {
        log("下载失败: " + e);
    }
}
```

### 3.3 并发操作

- [ ] 多线程操作共享资源时使用锁
- [ ] 避免资源竞争
- [ ] 线程安全的数据结构

---

## 四、资源释放检查

### 4.1 图像资源

- [ ] 所有 `Image` 对象使用后调用 `recycle()`
- [ ] 使用 `try-finally` 确保释放
- [ ] 避免重复释放

**正确示例：**
```javascript
// ✅ 正确：try-finally
let img = null;
try {
    img = $screen.getScreen();
    // 使用图片...
} finally {
    if (img != null) {
        img.recycle();
    }
}
```

### 4.2 文件资源

- [ ] 文件操作使用 `$file` API（自动关闭）
- [ ] 或手动关闭 Java IO 流

### 4.3 悬浮窗

- [ ] 脚本退出时关闭悬浮窗
- [ ] 使用 `events.on("exit", ...)` 注册退出回调

**正确示例：**
```javascript
let floaty = $floaty.newApp(xml);

events.on("exit", () => {
    $floaty.closeAll();
});
```

---

## 五、异常处理检查

### 5.1 try-catch 包裹

- [ ] 所有关键操作包裹在 try-catch 中
- [ ] 异常信息记录到日志
- [ ] 异常后资源已释放

**正确示例：**
```javascript
try {
    let node = $act.selector().text("按钮").waitFirst(3000);
    if (node != null) {
        node.click();
    }
} catch (e) {
    log("操作失败: " + e);
}
```

### 5.2 空值检查

- [ ] 节点查找结果检查 null
- [ ] OCR 识别结果检查 null
- [ ] 数组访问检查索引范围

**正确示例：**
```javascript
// ✅ 正确：节点空值检查
let node = $act.selector().text("按钮").waitFirst();
if (node != null) {
    node.click();
} else {
    log("未找到按钮");
}

// ✅ 正确：OCR 空值检查
let point = $ocr.getPoint("文字");
if (point != null) {
    $act.click(point);
} else {
    log("未识别到文字");
}

// ✅ 正确：数组索引检查
if (arr.length > index) {
    let item = arr[index];
}
```

### 5.3 超时处理

- [ ] 所有等待操作有超时时间
- [ ] 超时后有默认行为或错误处理
- [ ] 避免无限等待

**正确示例：**
```javascript
// ✅ 正确：带超时的等待
let node = $act.selector().text("按钮").waitFirst(5000);  // 5秒超时
if (node == null) {
    log("等待超时，未找到按钮");
    // 执行备用方案
}
```

---

## 六、逻辑完整性检查

### 6.1 循环退出条件

- [ ] 所有循环有明确的退出条件
- [ ] 避免死循环
- [ ] 循环次数限制

**正确示例：**
```javascript
// ✅ 正确：有限次循环
for (let i = 0; i < maxCount; i++) {
    // 执行操作
    if (success) break;
}

// ✅ 正确：带超时的循环
let startTime = Date.now();
while (Date.now() - startTime < timeout) {
    // 执行操作
    if (condition) break;
    sleep(500);
}
```

### 6.2 条件分支完整性

- [ ] if-else 分支完整
- [ ] switch-case 有 default 分支
- [ ] 所有可能的情况都已处理

---

## 七、性能优化检查

### 7.1 截屏频率

- [ ] 避免循环中频繁截屏
- [ ] 使用缓存或降低截屏频率
- [ ] 指定截屏范围（减少数据量）

**正确示例：**
```javascript
// ✅ 正确：降低截屏频率
for (let i = 0; i < 100; i++) {
    if (i % 10 == 0) {  // 每10次截屏一次
        let img = $screen.getScreen();
        // 处理...
        img.recycle();
    }
}
```

### 7.2 OCR 优化

- [ ] 指定识别范围（region）
- [ ] 使用灰度化或二值化加速
- [ ] 选择合适的引擎（ncnn 最快，mlkit 最准）

**正确示例：**
```javascript
// ✅ 正确：指定范围 + 灰度化
let result = $ocr.detect({
    region: [0, 0, 500, 200],  // 缩小范围
    gray: true                  // 灰度化加速
});
```

### 7.3 网络请求优化

- [ ] 设置合理的超时时间
- [ ] 使用重试机制
- [ ] 避免频繁请求

---

## 八、代码规范检查

### 8.1 命名规范

- [ ] 函数名使用 camelCase
- [ ] 常量使用 UPPER_SNAKE_CASE
- [ ] 变量名语义清晰

**正确示例：**
```javascript
// ✅ 正确
const MAX_RETRY_COUNT = 3;
const DEFAULT_TIMEOUT = 10000;

function clickButton() { /* ... */ }
function waitForElement() { /* ... */ }
```

### 8.2 注释规范

- [ ] 函数有文档注释（功能、参数、返回值）
- [ ] 关键逻辑有注释说明
- [ ] 复杂算法有注释解释

**正确示例：**
```javascript
/**
 * 安全点击节点
 * @param {object} selector - 选择器配置
 * @param {number} timeout - 超时时间（毫秒）
 * @returns {boolean} 是否点击成功
 */
function clickNode(selector, timeout = 3000) {
    // 查找节点
    let node = $act.selector()
        .text(selector.text || null)
        .waitFirst(timeout);
    
    // 检查并点击
    if (node != null) {
        node.click();
        return true;
    }
    
    return false;
}
```

### 8.3 代码结构

- [ ] 配置区、初始化区、功能区、主流程区分离
- [ ] 函数职责单一
- [ ] 避免深层嵌套

---

## 九、安全检查

### 9.1 敏感信息

- [ ] 不硬编码密码、token 等敏感信息
- [ ] 敏感信息使用环境变量或配置文件
- [ ] 日志不输出敏感信息

### 9.2 文件操作

- [ ] 文件路径检查（避免路径穿越）
- [ ] 文件大小检查（避免读取过大文件）
- [ ] 写入操作确认（避免覆盖重要文件）

---

## 十、完整检查清单

### 快速检查表

```
✅ API 调用规范
  [ ] API 名称拼写正确
  [ ] 参数类型正确
  [ ] 参数完整且顺序正确

✅ 权限申请
  [ ] 权限申请顺序正确
  [ ] 操作前有权限检查
  [ ] UI 线程使用非阻塞方式

✅ 异步处理
  [ ] async/await 使用正确
  [ ] 回调函数正确
  [ ] 并发操作安全

✅ 资源管理
  [ ] 图像资源已释放
  [ ] 文件资源已关闭
  [ ] 悬浮窗已关闭

✅ 异常处理
  [ ] try-catch 包裹关键操作
  [ ] 空值检查
  [ ] 超时处理

✅ 逻辑完整性
  [ ] 循环有退出条件
  [ ] 条件分支完整

✅ 性能优化
  [ ] 截屏频率合理
  [ ] OCR 范围优化
  [ ] 网络请求优化

✅ 代码规范
  [ ] 命名规范
  [ ] 注释完整
  [ ] 结构清晰

✅ 安全检查
  [ ] 无敏感信息泄露
  [ ] 文件操作安全
```

---

## 十一、检查通过标准

**所有检查项必须为 ✅，否则不得生成代码。**

如有不确定项，必须：
1. 查阅 `01_autogod-js-api-standard.md` 确认 API 规范
2. 查阅 `03_autogod-code-snippets.md` 参考标准范式
3. 查阅 `04_autogod-error-correction.md` 检查常见错误

**完成检查后，在回复开头声明：**

```
✅ 已完成强制自检：
- [x] API 调用规范检查
- [x] 权限申请顺序检查
- [x] 异步操作处理检查
- [x] 资源释放检查
- [x] 异常处理检查
- [x] 逻辑完整性检查
- [x] 性能优化检查
- [x] 代码规范检查
- [x] 安全检查
```
