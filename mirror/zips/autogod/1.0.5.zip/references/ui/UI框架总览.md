# UI框架 - 布局与控件

> 来源: https://aigamepro.work/ui_en/index.html  
> 更新时间: 2026-03-17

## 继承体系

```
XView (所有控件的父类)
├── XLayout (所有布局的父类)
│   ├── linear (线性布局)
│   ├── frame (帧布局)
│   ├── scroll (滚动布局)
│   ├── grid (网格布局)
│   └── ...其他布局
├── XButton (按钮)
├── XText (文本)
├── XInput (输入框)
└── ...其他控件
```

## XML根标签
```xml
<ui>
  <!-- 所有内容必须放在 <ui> 标签内 -->
</ui>
```

## 通用属性（所有控件/布局可用）

| 属性 | 说明 | 可选值 |
|------|------|--------|
| id | 控件id | 字符串 |
| w | 宽度 | "auto"(WRAP_CONTENT), "max"(MATCH_PARENT), **整数dp值** - ⚠️ 不支持百分号%写法如`w="40%"`，需JS计算出具体dp值后写入 |
| h | 高度 | "auto", "max", **整数dp值** - ⚠️ 不支持百分号%写法如`h="50%"`，需JS计算出具体dp值后写入 |
| margin | 外边距 | 单值/四值(左上右下,dp) |
| margin_left/top/right/bottom | 单边外边距 | dp |
| padding | 内边距 | 单值/四值(dp) |
| bg | 背景颜色 | 颜色值 |
| bgImg | 背景图片 | 图片路径 |
| gravity | 内容重力 | "center", "start", "end", "center\|top" 等 |

## 线性布局属性 (linear)

| 属性 | 说明 |
|------|------|
| dir | 布局方向: "v"(垂直) / "h"(水平) |
| weight | 权重(浮点值，分配剩余空间) |
| layout_gravity | 布局重力 |

## 示例

```xml
<ui>
  <statusbar />
  <linear w="max" dir="v" gravity="center" h="max" padding="20">
    <text text="标题" textSize="24" gravity="center" />
    <input id="myInput" hint="请输入" w="max" />
    <button id="myBtn" text="确定" w="max" />
  </linear>
</ui>
```

```js
let ui = $ui.layout("ui.xml");
ui.show();
ui.id("myBtn").click(() => {
    let text = ui.id("myInput").getText();
    toast("输入了: " + text);
});
```


## 示例
```xml
<ui>
    <!-- 主界面 -->
    <linear dir="v" w="max" h="max" bg="#FFFFFF" gravity="center">
        
        <!-- 按钮1：绿色 -->
        <button text="按钮1" bg="#00FF00" textSize="16sp" w="400dp" h="80dp"/>
        
        <!-- 按钮2：粉蓝色 -->
        <button text="按钮2" bg="#87CEEB" textSize="16sp" w="400dp" h="80dp"/>
        
        <!-- 按钮3：粉红色 -->
        <button text="按钮3" bg="#FFB6C1" textSize="16sp" w="400dp" h="80dp"/>
        
        <!-- 按钮4：灰色 -->
        <button text="按钮4" bg="#808080" textSize="16sp" w="400dp" h="80dp"/>
        
    </linear>
</ui>
```


```js
var ui = $ui.layout("main.xml");
ui.show();
```



## ⚠️ 之前错误修正
- ❌ XML声明 `<?xml version="1.0"...?>` 会导致解析失败 → 移除
- ❌ 根标签用 `<界面>` → 正确是 `<ui>`
- ❌ `<vertical>` 标签 → 不存在，用 `<linear dir="v">`
- ❌ `<LinearLayout>` → 正确是 `<linear>`（小写）
