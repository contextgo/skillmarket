# $ui - 界面交互
> 来源：https://aigamepro.work/ui_en/ui
> 抓取时间：2026-05-01

$ui - 界面交互

### layout(path)
解析布局文件 → {UI对象}

### show()
显示界面

### finish()
关闭界面

### id(name)
获取控件 → {XView子类}

### runOnUiThread(callback)
在UI线程执行

### toast(msg)
显示Toast

### inflate(xmlString)
解析XML字符串 → {UI对象}