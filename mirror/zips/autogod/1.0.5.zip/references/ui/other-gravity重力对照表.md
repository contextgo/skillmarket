# gravity重力属性对照表
> 来源：https://aigamepro.work/ui_en/other/gravity
> 抓取时间：2026-05-01

gravity重力属性对照表

fill/fill_h/fill_v → FILL/FILL_HORIZONTAL/FILL_VERTICAL
start/end/left/right/top/bottom → START/END/LEFT/RIGHT/TOP/BOTTOM
center/center_h/center_v → CENTER/CENTER_HORIZONTAL/CENTER_VERTICAL
display_h/display_v/clip_h/clip_v → DISPLAY_CLIP/CLIP

可用|组合: center|bottom / start|center_v