# 补充文档
> 来源：https://aigamepro.work/ui_en/other
> 抓取时间：2026-05-01

补充文档

包含color颜色属性对照表和gravity重力属性对照表