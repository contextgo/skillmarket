# UI - 界面对象
> 来源：https://aigamepro.work/ui_en/ui/UI
> 抓取时间：2026-05-01

UI - 界面对象

由$ui.layout()返回的对象

### id(name)
获取控件 → {XView子类}

### show()
显示界面

### finish()
关闭界面

### runOnUiThread(callback)
UI线程执行

### setTitle(title)
设置标题

### setFullScreen(fullScreen)
全屏模式

### setImmersive(immersive)
沉浸模式

### onBack(callback)
返回键监听

### onResult(callback)
结果回调