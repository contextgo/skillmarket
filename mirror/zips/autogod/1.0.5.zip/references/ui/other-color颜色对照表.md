# color颜色属性对照表
> 来源：https://aigamepro.work/ui_en/other/color
> 抓取时间：2026-05-01

颜色属性对照表

支持格式:
- #RRGGBB / #AARRGGBB
- 颜色名称: red/blue/green/black/white/gray/cyan/magenta/yellow/lightgray/darkgray
- 内置颜色: $color.RED / $color.BLUE 等