# 视频 - Video

> 来源: https://aigamepro.work/ui_en/video.html
> 更新时间: 2026-03-17

用于展示视频的控件。

## XML属性

| 属性 | 说明 | 可选值 |
|------|------|--------|
| path | 视频本地路径 | 路径 |
| url | 视频链接 | URL |
| loop | 循环播放 | "true"、"false" |
| autoStart | 自动播放 | "true"、"false" |
| padding | 内边距 | 左,上,右,下 |
| bg | 背景颜色 | 颜色值 |
| bgImg | 背景图片 | 图片路径 |

## JS函数

| 函数 | 说明 |
|------|------|
| onComplete(callback) | 播放完成回调 |
| onPrepare(callback) | 准备完成回调 |
| onError(callback) | 播放错误回调 |
| onInfo(callback) | 信息监听(缓冲开始/结束) |
| path(path) | 设置视频路径 |
| uri(uri) | 设置URI(本地/网络) |
| start() | 开始播放 |
| pause() | 暂停播放 |
| stop() | 停止并释放资源 |
| resume() | 从头开始播放 |
| suspend() | 暂停并释放资源 |
| keepScreen(keep) | 保持屏幕常亮 |
| seekTo(ms) | 跳转到指定时间点 |
| isPlaying() | 是否正在播放 |
| getDur() | 获取总时长(毫秒) |
| getCur() | 获取当前位置(毫秒) |
| canPause() | 是否可暂停 |
| canSeekBackward() | 是否可向后快退 |
| canSeekForward() | 是否可向前快进 |
| getBufferPercentage() | 获取缓冲百分比 |

## 示例

```xml
<video path="res/video.mp4" autoStart="true" loop="true" />
```