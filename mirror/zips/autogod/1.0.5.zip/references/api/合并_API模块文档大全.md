﻿# AutoGOD API 模块文档大全

> 自动合并生成，共 47 个模块

---

## $act-动作执行

# $act - 动作执行

> 来源: https://aigamepro.work/api_en/act.html
> 更新时间: 2026-02-08 19:43:34

手势动作模块，高度封装的框架，集成了无障碍、$root、$szk触摸方案，优先级为：$root>$szk>无障碍。

## API 列表

### hasPermit()
判断无障碍服务是否开启
- 返回: `{boolean}` 是否开启
- 版本: 1.0.0

```js
let hasPermit = $act.hasPermit();
$tip.show("是否获得无障碍", hasPermit);
```

### getPermit()
获得无障碍服务
- 返回: `{boolean}` 是否获得
- 版本: 1.0.0

```js
$act.getPermit();
```

### click(x, y)
点击坐标
- 参数: x `{int}` 点击位置x
- 参数: y `{int}` 点击位置y
- 版本: 1.0.0

```js
$act.click(500, 800);
```

### click(x, y, dur)
点击(长按效果)
- 参数: x `{int}` 点击位置x
- 参数: y `{int}` 点击位置y
- 参数: dur `{int}` 点击后延迟
- 版本: 1.0.0

```js
$act.click(135, 344, 1500);
```

### click(node)
点击节点
- 参数: node `{Node}` 节点对象
- 版本: 1.0.0

```js
let node = $act.selector().pkg("org.aigame.pro").cls("android.widget.FrameLayout").waitFirst();
if(node != null) {
    node.draw();
    $act.click(node);
}
```

### press(x, y)
长按
- 参数: x `{int}` 长按位置x
- 参数: y `{int}` 长按位置y
- 版本: 1.0.0

```js
$act.press(136, 347);
```

### press(x, y, dur)
长按指定时长
- 参数: dur `{int}` 长按后延迟
- 版本: 1.0.0

```js
$act.press(136, 347, 1500);
```

### slide(startX, startY, endX, endY, duration)
模拟人手滑动
- 参数: startX `{int}` 起点x
- 参数: startY `{int}` 起点y
- 参数: endX `{int}` 终点x
- 参数: endY `{int}` 终点y
- 参数: duration `{int}` 持续时间(默认1秒)
- 版本: 1.7.8

```js
$act.slide(189, 244, 733, 1440, 3000);
```

### move(x1, y1, x2, y2)
滑动
- 参数: x1 `{int}` 起点x
- 参数: y1 `{int}` 起点y
- 参数: x2 `{int}` 终点x
- 参数: y2 `{int}` 终点y
- 版本: 1.0.0

```js
$act.move(500, 0, 500, 800);
```

### gesture(gesture)
多指手势
- 参数: gesture `{int[]}` 动作数据数组[起点x,起点y,终点x,终点y,开始时间,时长]
- 版本: 1.0.0

```js
$act.gesture([500, 0, 500, 800, 0, 500]);
```

### gesture(gesture1, gesture2)
双指手势
- 参数: gesture1 `{int[]}` 动作数据数组
- 参数: gesture2 `{int[]}` 动作数据数组
- 版本: 1.0.0

```js
let centerX = 500;
let centerY = 800;
$act.gesture(
    [centerX, centerY, centerX - 400, centerY - 400, 0, 500],
    [centerX, centerY, centerX + 400, centerY + 400, 0, 500]
);
```

### home()
点击Home键
- 版本: 1.0.0

```js
$act.home();
```

### back()
返回
- 版本: 1.0.0

```js
$act.back();
```

### recent()
近期任务
- 版本: 1.0.0

```js
$act.recent();
```

### lock()
锁屏
- 版本: 1.0.0

```js
$act.lock();
```

### unlock()
唤醒屏幕
- 版本: 1.0.0

```js
$act.unlock();
```

### input(text)
粘贴到文本框
- 参数: text `{String}` 需要输入的文字
- 版本: 1.0.0

```js
$act.input("我是要粘贴的内容");
```

### selector()
创建UI选择器
- 返回: `{UiSelector}` UI选择器
- 版本: 1.0.0

### activity()
获得activity类名
- 返回: `{string}` activity类名
- 版本: 1.0.0

```js
let name = $act.activity();
log("当前类名:" + name);
```

### setJitter(jitter)
设置抖动值(随机点击)
- 参数: jitter `{int}` 抖动值
- 版本: 1.4.3

### enableRoot(enableRoot)
启用$root
- 参数: enableRoot `{boolean}` 是否启用$root
- 版本: 1.4.7


---

## $ag-图色框架

# $ag - 图色框架
> 来源：https://aigamepro.work/api_en/ag
> 抓取时间：2026-05-01

图色框架

### setDebug(debug)
开启调试模式
- 参数 : debug {boolean}

### findImg(options)
寻找图片 → {point}
- options: {path,region:[],similar:0.8,trans:false}

### findImgClick(options)
寻找图片并点击 → {point}
- options同上+px,py偏移

### waitImg(options, failCallback)
等待图片 → {point}
- options: {path,region,similar,trans,ensure,ensureMode:"once"/"more",ensureTimes,ensureDur,waitTimes:75,waitDur:800}
- ensure流程: once=有1次成功即返回, more=全部成功才返回

### waitImgClick(options, failCallback)
等待图片并点击 → {point}

### findImgInRegions(options)
在多个范围中寻找图片 → {point,index}
- options: {path,region:[[],[],[]],similar,trans}

### findImgsOne(options)
多组图片找一组 → {point,index}
- options: {data:[{path,region,similar,trans},...]}

### waitImgsOne(options, failCallback)
等待多组图片 → {point,index}

### clickImgWhileNot(options, failCallback)
循环点击直到图片消失 → {point}

### bloodPercent(options)
血条检测 → {int} -1~100
- options: {region,color:"#ff0000,#ff0000",threshold:5}

### findColor(options)
找色 → {Point}

### findMultiColors(options)
多点找色 → {point}
- options: {multiColors:[[px,py,color,threshold],...],color,threshold,region}

### findMultiColorsClick(options) / waitMultiColors(options,failCallback) / waitMultiColorsClick(options,failCallback)
多点找色相关

### findColorClick(options)
找色点击

### waitColor(options,failCallback) / waitColorClick(options,failCallback) / waitColorWhileNot(options,failCallback)
等待颜色相关

### findColorInRegions(options)
多区域找色 → {point}

### findColorsOne(options)
找到一种颜色

### closeDraw()
关闭绘制图案

---

## $app - 应用管理

# $app - 应用管理

> 来源: https://aigamepro.work/api_en/app.html
> 更新时间: 2026-02-08 19:43:35

应用操作模块，提供应用启动、卸载、分享等功能。

## API 列表

### run(name)
打开应用(推荐)
- 参数: name `{string}` 包名或程序名称
- 返回: `{boolean}` 是否打开成功
- 版本: 1.0.0

```js
$app.run("QQ");
$app.run("com.tencent.mobileqq");
```

### launchApp(appName) / runApp(appName) / launch(appName)
运行应用
- 参数: appName `{string}` 应用名称
- 返回: `{boolean}` 是否运行成功
- 版本: 1.0.0

### launchPkg(packageName) / runPkg(packageName)
运行包名
- 参数: packageName `{string}` 程序包名
- 返回: `{boolean}` 是否跳转成功
- 版本: 1.0.0

### getIcon(name)
获取应用图标
- 参数: name `{string}` 应用名称或包名
- 返回: `{Image}` 图标
- 版本: 1.0.0

```js
let icon = $app.getIcon("QQ");
$img.show(icon);
```

### ls()
获得应用列表
- 返回: `{AppInfo[]}` 应用信息列表
- 版本: 1.0.0

```js
let apps = $app.ls();
for (let i = 0; i < apps.size(); i++) {
    let appInfo = apps.get(i);
    let appName = appInfo.appName;
    let pkgName = appInfo.pkgName;
    let icon = appInfo.icon;
}
```

### lsUserApp() / lsSysApp()
获得用户/系统应用列表
- 返回: `{AppInfo[]}` 应用列表
- 版本: 1.3.2

### lsRecent()
获得最近运行的应用
- 返回: `{AppTaskInfo[]}` 应用信息列表
- 版本: 1.0.1

```js
if ($app.hasUsagePermit()) {
    let pkgList = $app.lsRecent();
}
```

### pkgExists(pkgName)
包名是否存在
- 参数: pkgName `{string}` 包名
- 返回: `{boolean}` 是否存在
- 版本: 1.0.0

### getPackageName(appName) / pkgName(appName)
获得包名
- 参数: appName `{string}` 应用名称
- 返回: `{string}` 包名
- 版本: 1.0.0

### appName(packageName)
根据包名拿应用名
- 参数: packageName `{string}` 包名
- 返回: `{string}` 应用名称
- 版本: 1.0.0

### installApk(apkPath)
安装apk文件
- 参数: apkPath `{string}` 路径
- 返回: `{boolean}` 是否成功获取安装意图
- 版本: 1.3.3

### uninstallApp(name) / uninstallPkg(name) / uninstall(name)
卸载应用
- 参数: name `{string}` 应用名称或包名
- 版本: 1.0.0

### openUrl(url)
打开链接
- 参数: url `{string}` 网页链接
- 版本: 1.0.0

```js
$app.openUrl("www.baidu.com");
```

### shareText(text) / shareImg(imgPath)
分享文本/图片
- 参数: text `{string}` 文本内容
- 参数: imgPath `{string}` 图片路径
- 版本: 1.0.0

### sendEmail(to, subject, text)
发送邮件
- 参数: to `{string}` 收件人
- 参数: subject `{string}` 主题
- 参数: text `{string}` 内容
- 版本: 1.0.0

### openAppSetting(name) / appSetting(name)
打开应用设置界面
- 参数: name `{string}` 应用名称或包名
- 版本: 1.0.0

### startActivity(name) / startActivity(options)
启动Activity
- 参数: name `{string}` 界面名称
- 参数: options `{Object}` 意图配置
- 版本: 1.0.1

```js
$app.startActivity("log");
$app.startActivity({
    data: "https://www.baidu.com",
    pkg: "com.baidu.BaiduMap"
});
```

### kill(name)
杀死应用
- 参数: name `{string}` 应用名或包名
- 版本: 1.0.4

```js
$app.kill("QQ");
```

### hasUsagePermit() / getUsagePermit()
是否有/获取使用情况权限
- 版本: 1.0.1


---

## $arc-悬浮球

# $arc - 悬浮球
> 来源：https://aigamepro.work/api_en/arc
> 抓取时间：2026-05-01

悬浮球

### item(iconName)
创建悬浮按钮 → {MenuItem}
- iconName: 图标资源名或本地相对路径

### body(name)
创建容器 → {MenuBody}
- 链式调用: $arc.body("名称").add(menu1).add(menu2).show()

### has(name) → {boolean}
### close(name) / closeAll()

---

## $bus-消息总线

# $bus - 消息总线
> 来源：https://aigamepro.work/api_en/bus
> 抓取时间：2026-05-01

消息总线

### ls() → {String[]} 监听器列表
### post(name, object) 发送消息
### event(name, listener) 添加监听 listener={(data)=>{}}
### close(name) 移除监听器
### clear() / stopAll() 移除所有监听器

---

## $color - 颜色

# $color - 颜色

> 来源: https://aigamepro.work/api_en/color.html
> 更新时间: 2026-02-08 19:43:36

颜色操作模块，提供颜色解析、对比、找色等功能。

## 预定义颜色常量

### const {int} BLACK / WHITE / RED / GREEN / BLUE / YELLOW / CYAN / MAGENTA
常用颜色值

### const {int} DGRAY / GRAY / LGRAY / TRANSPARENT
灰色系列和透明色

## API 列表

### find(img, color, threshold, region)
查找颜色位置
- 参数: img `{Image}` 图片
- 参数: color `{String}` 颜色值
- 参数: threshold `{int}` 阈值
- 参数: region `{double[]}` 范围
- 返回: `{Point}` 找到的位置
- 版本: 1.0.0

```js
let img = $screen.getScreen();
let point = $color.find(img, "#a55978", 5, [300, 200, 500, 500]);
if (point != null) {
    $draw.cross(point);
}
```

### findAll(img, color, threshold, region)
查找所有颜色位置
- 返回: `{Point[]}` 所有的位置集合
- 版本: 1.0.0

### similar(c1, c2)
计算相似度
- 参数: c1 `{string|int}` 颜色1
- 参数: c2 `{string|int}` 颜色2
- 返回: `{double}` 相似度
- 版本: 1.0.0

```js
let result = $color.similar("#1E1F22", "#2B2D30");
```

### parse(color)
解析颜色值
- 参数: color `{string}` 颜色字符串
- 返回: `{int}` 颜色值
- 版本: 1.0.0

```js
let color = $color.parse("#1E1F22");
// 支持主题颜色
let color = $color.parse("colorPrimary");
let color = $color.parse("colorSurface");
```

### parse(r, g, b)
解析RGB颜色
- 返回: `{int}` 颜色值
- 版本: 1.0.0

### rgb(red, green, blue)
通过RGB获得颜色值
- 返回: `{int}` 颜色值
- 版本: 1.0.0

### argb(alpha, red, green, blue)
通过ARGB获得颜色值
- 返回: `{int}` 颜色值
- 版本: 1.0.0

### a(color) / r(color) / g(color) / b(color)
计算ARGB各通道值
- 参数: color `{String}` 颜色
- 返回: `{int}` 通道值
- 版本: 1.0.0

### equals(c1, c2)
比较两个颜色
- 返回: `{boolean}` 是否相等
- 版本: 1.0.0

### setAlpha(color, alpha)
设置颜色透明度
- 参数: color `{int}` 颜色值
- 参数: alpha `{int}` 透明度(0-255)
- 返回: `{int}` 颜色值
- 版本: 1.4.3

### brighter(color) / darker(color)
获取较亮/较暗颜色
- 返回: `{int}` 颜色值
- 版本: 1.4.3

### isDarkTheme()
是否是黑暗主题
- 返回: `{boolean}` 是否是深色主题

### isColor(colorStr)
判断颜色格式是否正确
- 返回: `{boolean}` 是否正确
- 版本: 1.4.3


---

## $date-日期

# $date - 日期

> 来源: https://aigamepro.work/api_en/date.html
> 更新时间: 2026-02-08 19:43:36

日期工具模块。

## API 列表

### dt()
当前日期时间字符串
- 返回: `{string}` 格式为 yyyy-MM-dd HH:mm:ss
- 版本: 1.1.4

```js
let dateStr = $date.dt(); // 2025-10-25 18:32:53
```

### dt(time)
指定时间戳的日期时间
- 参数: time `{number}` 时间戳
- 返回: `{string}` 日期时间字符串
- 版本: 1.1.4

### d()
当前日期字符串
- 返回: `{string}` 格式为 yyyy-MM-dd
- 版本: 1.1.4

```js
let dateStr = $date.d(); // 2025-05-23
```

### parse(dateStr)
解析日期字符串
- 参数: dateStr `{string}` 日期字符串
- 返回: `{Date}` 日期对象
- 版本: 1.1.4

```js
let date = $date.parse("2025/12/08 12/35/24");
```

### parse(dateStr, pattern)
解析日期(指定格式)
- 参数: dateStr `{string}` 日期字符串
- 参数: pattern `{string}` 日期格式
- 返回: `{Date}` 日期对象
- 版本: 1.1.4

```js
let date = $date.parse("2025/12/08 12/35/24", "yyyy/MM/dd HH/mm/ss");
```

### info()
获取当前日期信息
- 返回: `{DateInfo}` 日期信息对象
- 版本: 1.1.4

### info(time)
获取指定时间日期信息
- 参数: time `{number|string}` 时间戳或时间字符串
- 返回: `{DateInfo}` 日期信息对象
- 版本: 1.1.4

### format(time, pattern)
格式化日期
- 参数: time `{long}` 时间戳
- 参数: pattern `{string}` 日期格式
- 返回: `{string}` 日期字符串
- 版本: 1.1.4

```js
let info = $date.format(1747985594110, "yyyy年MM月dd日 HH时mm分ss秒");
```

### date()
创建当前日期对象
- 返回: `{Date}` 当前日期
- 版本: 1.1.4

### date(time)
从时间戳创建日期
- 参数: time `{long}` 时间戳
- 返回: `{Date}` 日期对象
- 版本: 1.1.4

### date(dateStr)
从字符串创建日期
- 参数: dateStr `{string}` 日期字符串
- 返回: `{Date}` 日期对象
- 版本: 1.1.4

### dur(milliseconds)
将毫秒数转换为时间字符串
- 参数: milliseconds `{long}` 毫秒数
- 返回: `{string}` 格式化时间字符串
- 版本: 1.6.1

```js
let info = $date.dur(1234567890); // 14天6时56分7秒
```

### curTime()
获取当前时间戳
- 返回: `{long}` 时间戳
- 版本: 1.7.8


---

## $device-设备信息

# $device - 设备信息

> 来源: https://aigamepro.work/api_en/device.html
> 更新时间: 2026-02-08 19:43:37

设备信息模块，提供设备硬件和系统信息。

## 常量属性

### const {int} width
屏幕宽度

### const {int} height
屏幕高度

### const {String} buildId
Build ID

### const {String} product
产品名称

### const {String} board
主板名称

### const {String} brand
品牌名称

### const {String} device
设备名称

### const {String} model
型号名称

### const {String} bootloader
引导加载程序名称

### const {String} hardware
硬件名称

### const {String} fingerprint
指纹信息

### const {int} sdkInt
SDK版本号

### const {String} incremental
内部版本号

### const {String} release
Android版本号

### const {String} code
开发代号

### const {String} serial
序列号

### const {String} baseOS
基础操作系统版本(仅Android 6.0+)

### const {String} securityPatch
安全补丁版本(仅Android 6.0+)

## API 列表

### getIMEI()
获取IMEI号码
- 返回: `{string}` IMEI号码
- 版本: 1.0.0

### getAndroidId()
获取Android ID
- 返回: `{string}` Android ID
- 版本: 1.0.0

### getBrightness()
获取屏幕亮度
- 返回: `{int}` 屏幕亮度
- 版本: 1.0.0

### getMusicVolume()
获取音乐音量
- 返回: `{int}` 音乐音量值
- 版本: 1.0.0

### getBattery()
电池电量百分比
- 返回: `{int}` 电池电量百分比
- 版本: 1.0.0

### getTotalMem()
获取总内存
- 返回: `{long}` 总内存大小(字节)
- 版本: 1.0.0

### getAvailMem()
获取可用内存
- 返回: `{long}` 可用内存大小(字节)
- 版本: 1.0.0

### isCharging()
是否正在充电
- 返回: `{boolean}` 是否正在充电
- 版本: 1.0.0

### isScreenOn()
判断设备屏幕是否亮起
- 返回: `{boolean}` 是否亮起
- 版本: 1.0.0

### wakeUp()
唤醒设备屏幕
- 版本: 1.0.0

### keepScreenOn()
保持设备屏幕常亮
- 版本: 1.0.0

### vibrate(millis)
震动指定时长
- 参数: millis `{long}` 震动时长(ms)
- 版本: 1.0.0

```js
$device.vibrate(1000);
```

### getMacAddress()
获取MAC地址
- 返回: `{string}` MAC地址
- 版本: 1.0.0

### hasNavBar()
是否存在NavigationBar
- 返回: `{boolean}` 是否存在
- 版本: 1.0.0

### getVirtualBarHeight()
获取虚拟功能键高度
- 返回: `{int}` 虚拟功能键高度
- 版本: 1.0.0

### isLock()
判断设备是否锁定
- 返回: `{boolean}` 是否锁定
- 版本: 1.0.0


---

## $dialog-对话框

# $dialog - 对话框

> 来源: https://aigamepro.work/api_en/dialog.html
> 更新时间: 2026-02-08 19:43:38

对话框模块，提供各种弹窗交互。

## API 列表

### alert(title, content)
提示对话框
- 参数: title `{string}` 标题
- 参数: content `{string}` 内容
- 版本: 1.0.0

```js
$dialog.alert("提示", "这是一个提示对话框");
```

### confirm(title, content)
确认对话框
- 返回: `{boolean}` 用户是否点击确认
- 版本: 1.0.0

```js
if ($dialog.confirm("确认", "确定要执行吗？")) {
    log("用户点击了确认");
}
```

### input(title, content, defaultValue)
输入对话框
- 参数: defaultValue `{string}` 默认值
- 返回: `{string}` 用户输入的内容
- 版本: 1.0.0

```js
let name = $dialog.input("输入", "请输入名称", "默认名称");
```

### select(title, items)
选择对话框
- 参数: items `{string[]}` 选项列表
- 返回: `{int}` 用户选择的索引
- 版本: 1.0.0

```js
let index = $dialog.select("请选择", ["选项1", "选项2", "选项3"]);
```

### multiSelect(title, items)
多选对话框
- 参数: items `{string[]}` 选项列表
- 返回: `{int[]}` 用户选择的索引数组
- 版本: 1.0.0

### singleChoice(title, items, selectedIndex)
单选对话框
- 参数: selectedIndex `{int}` 默认选中项
- 返回: `{int}` 用户选择的索引
- 版本: 1.0.0

### showProgressBar(title, content)
显示进度条对话框
- 返回: `{ProgressDialog}` 进度对话框对象
- 版本: 1.0.0

```js
let progress = $dialog.showProgressBar("加载中", "请稍候...");
sleep(2000);
progress.dismiss();
```


---

## $draw-全屏绘制

# $draw - 全屏绘制
> 来源：https://aigamepro.work/api_en/draw
> 抓取时间：2026-05-01

全屏绘制

系统限制：全屏悬浮窗在MIUI会卡悬浮(拦截手势)，1.8.0后root/shizuku可解锁。
小型日志悬浮窗不阻碍：$draw.i/d/w("信息")

### getPermit() → {boolean}
### rect(x,y,w,h) / rect(x,y,w,h,color) / rect(x,y,w,h,ext) / rect(x,y,w,h,ext,color) / rect(arr,ext,color) / rect(rect) / rect(node)
绘制方框
### cross(x,y) / cross(x,y,color) / cross(point/index/node) 绘制十字准心
### dot(x,y) / dot(x,y,color) / dot(point/index) 绘制点
### text(text,x,y) / text(text,x,y,size) / text(text,x,y,size,color) 绘制文字(默认15dp)
### circle(x,y) / circle(x,y,r) / circle(x,y,r,ext) / circle(x,y,r,ext,color) 绘制圆形(默认半径50px)
### img(img,x,y,w,h) 绘制图片
### line(x,y,toX,toY) / line(x,y,toX,toY,color) 绘制线条
### path(data) / path(data,color) 绘制路径(int[][]坐标数组)
### i/d/w/e/v(text) / i/d/w/e/v(text,x,y) / i/d/w/e/v(text,x,y,size) 绘制日志(小型悬浮窗)
### log(text) / log(text,color) / log(text,color,x,y) / log(text,color,x,y,size) / log(text,x,y) 绘制日志
### closeAll() / closeAll(delay) / closeLog() / closeLog(delay) 关闭
### clear() 清空所有绘制

---

## $engine-脚本引擎

# $engine - 脚本引擎
> 来源：https://aigamepro.work/api_en/engine
> 抓取时间：2026-05-01

脚本引擎

重要：打包apk后只能执行混淆码，runCode(源码)会报错，需用run(项目js路径)或对接AG后端。

### run(path) / run(jsFile) → {string} taskID
### runCode(code) / runCode(path,code) → {string} taskID
### pause(id) 暂停
### isPause(id) → {boolean|null}
### start(id) 继续
### ls() → {JsTaskInfo[]}
### stop(id) 停止
### stopAll(exit) 停止所有(exit=true杀app)
### lsTask() → {$task[]}
### has(id) 任务是否存在

---

## $event-事件

# $event - 事件

> 来源: https://aigamepro.work/api_en/event.html
> 更新时间: 2026-02-08 19:43:39

事件监听模块，用于监听按键和触摸事件。

## API 列表

### setKeyCallback(callback)
设置按键监听回调
- 参数: callback `{(keyCode, event)=>{}}` 回调函数
- 版本: 1.0.0

```js
$event.setKeyCallback((keyCode, event) => {
    log("按键代码:", keyCode);
});
```

### setTouchCallback(callback)
设置触摸监听回调
- 参数: callback `{(action, x, y)=>{}}` 回调函数
- 版本: 1.0.0

```js
$event.setTouchCallback((action, x, y) => {
    log("动作:", action, "坐标:", x, y);
});
```

### removeKeyCallback()
移除按键监听
- 版本: 1.0.0

### removeTouchCallback()
移除触摸监听
- 版本: 1.0.0


---

## $excel-表格操作

# $excel - 表格操作

> 来源: https://aigamepro.work/api_en/excel  
> 更新时间: 2026-05-01

## 概述

表格操作模块，用于读取和写入二维数组到表格中。需要在安卓8+系统上才能完美运行。

## API 列表

### read(path)

读取第一个表格

- **参数**: `path` `{String}` 路径（支持相对路径）
- **返回**: `{String[][]}` 表格数据
- **版本**: 1.7.8

```js
// 读取第一个表格数据
let data = $excel.read("data.xlsx"); // 相对路径
log(data);
// 输出:
// [
//   ["学号","姓名","年龄","性别","入学日期"],
//   ["2023001","张三","20","男","2023-09-01"],
//   ["2023002","李四","19","女","2023-09-01"],
//   ["2023003","王五","21","男","2022-09-01"],
//   ["2023004","赵六","20","女","2023-09-01"]
// ]
```

### read(path, index)

读取指定表格

- **参数**: `path` `{String}` 路径（支持相对路径）
- **参数**: `index` `{int}` 表格索引（从0开始）
- **返回**: `{String[][]}` 表格数据
- **版本**: 1.7.8

```js
// 读取第2个表格数据（索引为1）
let data = $excel.read("data.xlsx", 1);
log(data);
// 输出:
// [
//   ["商品ID","商品名称","商品单价","库存"],
//   ["P001","笔记本电脑","4999","10"],
//   ["P002","智能手机","3999","25"]
// ]
```

### num(path)

获取表格数量

- **参数**: `path` `{String}` 路径（支持相对路径）
- **返回**: `{int}` 表格数量
- **版本**: 1.7.8

```js
let sheetNum = $excel.num("data.xlsx");
log(sheetNum); // 输出: 3
```

### ls(path)

获取表格名称列表

- **参数**: `path` `{String}` 路径（支持相对路径）
- **返回**: `{String[]}` 表格名称列表
- **版本**: 1.7.8

```js
let sheetList = $excel.ls("data.xlsx");
log(sheetList); // 输出: ["班级表","商品表","部门表"]
```

### loop(path, onSheet)

遍历所有表格

- **参数**: `path` `{String}` 路径（支持相对路径）
- **参数**: `onSheet` `{(sheetName, sheetData)=>{}}` 数据回调函数
- **版本**: 1.7.8

```js
$excel.loop("data.xlsx", (name, data) => {
    log(name, data);
});
```

### write(sheetName, sheetData, path)

写入表格

- **参数**: `sheetName` `{String}` 表格名称
- **参数**: `sheetData` `{String[][]}` 表格数据（注意：所有值必须是字符串类型）
- **参数**: `path` `{String}` 保存路径（**不支持相对路径，必须是绝对路径**）
- **版本**: 1.7.8

```js
let sheetData = [
    ["姓名", "年龄"],
    ["小红", "18"],  // 注意必须都是字符串类型
    ["小明", "19"]
];
let sheetName = "我的表格";
let savePath = "/sdcard/demo.xlsx";  // 必须是绝对路径
$excel.write(sheetName, sheetData, savePath);
```

## 注意事项

- 需要安卓8+系统
- `read()`/`num()`/`ls()`/`loop()` 支持相对路径
- `write()` 只支持绝对路径
- 所有表格数据均为字符串类型


---

## $ext-拓展加载

# $ext - 拓展
> 来源：https://aigamepro.work/api_en/ext
> 抓取时间：2026-05-01

拓展：加载Dex,Apk,Jar,So

内置缓存机制，相同文件复用类加载器，clear()清除。

### loadApk(apkPath) / loadApk(options) → {DexClassLoader}
### loadDex(dexPath) / loadDex(options) → {DexClassLoader}
options: {path:["dexOrJarPath"],so:[{path,load:false},...]}
### loadDexs(paths) → {DexClassLoader}
### loadJar(jarPath) / loadJar(options) → {DexClassLoader} (jar须经AndroidStudio编译)
### loadJars(paths) → {DexClassLoader}
### clear() 清除缓存(加载so后慎用)
### delete() 删除缓存文件

---

## $fc-文件选择器

# $fc - 文件选择器
> 来源：https://aigamepro.work/api_en/fc
> 抓取时间：2026-05-01

文件选择器

### show(callback, options)
options: {mode:"m"/"s", type:"a"/"f"/"d", root, path, ext}
mode: m=多选,s=单选; type: a=文件和目录,f=文件,d=目录

---

## $file-文件系统

# $file - 文件系统

> 来源: https://aigamepro.work/api_en/file.html  
> 更新时间: 2026-04-04

**操作外部存储(sdcard)文件，部分函数可操作assets目录**

## 路径操作

| 方法 | 说明 | 返回 |
|------|------|------|
| $file.uri(path) | 获得Uri对象 | `{Uri}` |
| $file.open(path) | 获得File对象（支持相对路径） | `{File}` |
| $file.join(parent, child) | 路径拼接 | `{string}` |
| $file.join([path1,path2,...]) | 路径拼接（数组） | `{string}` |
| $file.sd() | 获得存储目录 | `{string}` 如 /storage/emulated/0 |

## 判断

| 方法 | 说明 | 返回 |
|------|------|------|
| isFile(path) | 是否是文件 | `{boolean}` |
| isDir(path) | 是否是文件夹 | `{boolean}` |
| isEmptyDir(path) | 是否是空文件夹 | `{boolean}` |
| isEmpty(path) | 是否是空文件或文件夹 | `{boolean}` |
| exists(path) | 路径是否存在 | `{boolean}` |

## 创建

| 方法 | 说明 | 返回 |
|------|------|------|
| create(path) | 创建文件（目录不存在自动创建） | `{boolean}` |
| mkdir(path) | 创建目录 | `{boolean}` |
| ensureDir(path) | 确保文件夹存在 | `{string}` |

## 读写

| 方法 | 说明 |
|------|------|
| read(path) | 读取文件文本内容 |
| read(path, encoding) | 指定编码读取（如"gbk"） |
| reads(path) | 读取文件行 → `{string[]}` |
| readByte(path) | 读取文件字节 → `{byte[]}` |
| write(content, path) | 写入文件 |
| write(content, path, encoding) | 指定编码写入 |
| writes(lines, path) | 写入行数据 |
| add(content, path) | 追加内容（需手动加\n换行） |
| adds(lines, path) | 追加行数据（自动换行） |
| writeByte(bytes, path) | 写入字节 |

## 文件操作

| 方法 | 说明 |
|------|------|
| copy(src, dest) | 拷贝文件（支持assets→sdcard） |
| move(src, dest) | 移动文件或文件夹 |
| rename(src, dest) | 重命名文件 |
| del(path) | 递归删除（3次重试） |

## 信息

| 方法 | 说明 | 返回 |
|------|------|------|
| size(path) | 文件大小 | `{number}` 字节 |
| sizeStr(path) | 格式化大小 | `{string}` 如 "6 B" |
| name(path) | 文件名称 | `{string}` |
| mainName(path) | 主文件名（无后缀） | `{string}` |
| ext(path) | 后缀名 | `{string}` |

## 罗列

| 方法 | 说明 |
|------|------|
| ls(path) | 罗列文件 → `{string[]}` |
| ls(path, filter) | 罗列文件（带过滤） |
| loopFiles(path, accept) | 递归遍历文件 → `{File[]}` |
| lsVideo() | 罗列视频（需权限） |
| lsAudio() | 罗列音频（需权限） |
| lsImages() | 罗列图片（需权限） |

## 目录

### $file.getDir(name, isPublic)
获取安卓目录路径
- name: "pictures"/"图片", "downloads"/"下载", "dcim", "music"/"音乐", "movies"/"视频", "documents"/"文档" 等
- isPublic: true=公共目录, false=私有目录

## 热更新

| 方法 | 说明 |
|------|------|
| hotUpdate(path, data) | 热更新文件内容（优先读取热更新文件） |
| delHotUpdate(path) | 删除热更新文件 |

## ⚠️ 关键提醒
- `$file` 是文件系统API，之前代码中 `$files` 是错误的写法！
- 正确: `$file.read()`, `$file.write()`, `$file.ls()` 等


---

## $floaty - 悬浮窗-悬浮窗

# $floaty - 悬浮窗

> 来源: https://aigamepro.work/api_en/floaty.html  
> 更新时间: 2026-02-08

## API 列表

### getPermit()
获取悬浮窗权限（阻塞方法，每30秒重试直到获取）
- 返回: `{boolean}` 是否有权限
- 版本: 1.0.0

```js
let hasPermit = $floaty.getPermit();
if(hasPermit){ log("获取到悬浮窗权限"); }
```

### hasPermit()
是否有悬浮窗权限
- 返回: `{boolean}`
- 版本: 1.0.0

### newAdj(xmlOrPath)
创建可调节悬浮窗
- 参数: xmlOrPath `{xml|path}` xml或路径
- 返回: `{AdjustableFloaty}`
- 版本: 1.4.4

```js
let adjFloaty = $floaty.newAdj("./res/layout/floaty_adj.xml");
let adjFloaty = $floaty.newAdj(`<ui>...</ui>`);
```

### newApp(xmlOrPath)
创建应用级悬浮窗
- 参数: xmlOrPath `{xml|path}`
- 返回: `{AppFloaty}`
- 版本: 1.4.4

### newApp(xmlOrPath, touchable)
创建应用级悬浮窗（可设置是否可触摸）
- 参数: touchable `{boolean}` 默认true
- 版本: 1.8.3

```js
let appFloaty = $floaty.newApp("./res/layout/floaty_app.xml", false);
```

### newSys(xmlOrPath)
创建系统级悬浮窗（可覆盖导航栏和状态栏，但容易被游戏检测闪退）
- 参数: xmlOrPath `{xml|path}`
- 返回: `{SysFloaty}`
- 版本: 1.4.4

### newSys(xmlOrPath, touchable)
- 版本: 1.8.3

### newSelect(callback)
创建选择范围悬浮窗
- 参数: callback `{SimpleFloatArrCallback}` 关闭时回调范围数据
- 返回: `{SelectFloaty}`
- 版本: 1.8.3

```js
$floaty.newSelect((rect)=>{
    log("用户选择范围:",rect);
});
```

### closeAll()
关闭所有悬浮窗
- 版本: 1.0.0

## ⚠️ 之前的错误修正
- ❌ `$floaty.find()` 不存在
- ❌ `$floaty.create().setLayout().id()` 不是正确的悬浮窗用法
- ✅ 正确用法：`$floaty.newApp(xmlOrPath)` 或 `$floaty.newAdj(xmlOrPath)` 或 `$floaty.newSys(xmlOrPath)`


---

## $global-全局函数

# $global - 全局函数

> 来源: https://aigamepro.work/api_en/global.html  
> 更新时间: 2026-02-08

**全局函数无需 $ 前缀，直接调用**

## 基础函数

| 函数 | 说明 |
|------|------|
| sleep(ms) | 睡眠（毫秒） |
| tip(info) | 提示 |
| alert(title, msg) | 对话框 |
| showImg(img) | 显示图片（路径或Image对象） |
| closeLog() | 关闭绘制日志 |
| closeDraw() | 关闭绘制悬浮窗 |
| clearDraw() | 清空绘制（不关闭悬浮窗） |

## 剪切板

| 函数 | 说明 | 返回 |
|------|------|------|
| getClip() | 获取剪切板内容 | `{string}` |
| setClip(text) | 设置剪切板内容 | - |
| hasClip() | 是否有剪切板内容 | `{boolean}` |
| clearClip() | 清空剪切板 | `{boolean}` |

## 当前信息

| 函数 | 说明 | 返回 |
|------|------|------|
| curPkg() | 获取当前包名 | `{string}` |
| curCls() | 获取当前活动名 | `{string}` |
| curTime() | 获取当前时间戳 | `{long}` |

## 日志

| 函数 | 说明 |
|------|------|
| info(msg) | 悬浮土司提示（需悬浮窗权限） |
| infoLog(msg) | 悬浮土司+控制台打印 |
| toast(msg) | 系统土司 |
| toastLog(msg) | 系统土司+控制台打印 |
| log(msg) / print(msg) | 控制台日志 |

## 随机数

```js
random()          // 0-1 之间
random(max)       // 0-max 之间
random(min, max)  // min-max 之间
```

## 模块导入

```js
let MyClass = require("mCls.js");
let obj = new MyClass();
```


---

## $hid-键鼠触控

# $hid - 键鼠触控
> 来源：https://aigamepro.work/api_en/hid
> 抓取时间：2026-05-01

键鼠触控(无需权限，连接键鼠硬件)

### init() → {String} "true"或失败原因
### isOn() → {boolean}
### dexBeat() → {float} 版本号
### getBatteryLevel() / isCharging() 电量/充电
### setPowerOff() / setPowerOn() 供电控制
### click(x,y) / click([x,y]) → {boolean}
### longClick(x,y,dur) / longClick([x,y,dur]) → {boolean}
### swipEx(x1,y1,x2,y2) / swipEx(x1,y1,x2,y2,press,time,delay) → {boolean}
### touchDown(id,x,y) / touchMove(id,x,y) / touchUp(id) 多指触控
### keyPress(keyCode) / keyPress(modify,keyCode) 按键
### home() / back() / recents() / recentsV2() 导航键
### selectAll() / cut() / copy() / paste() / paste(text) 剪贴板
### inputSimple(text) 输入英文+数字(不支持中文标点)
### delete() / delete(len) / backspace() / backspace(len) 删除/回退

---

## $hid-人机接口

# $hid - 人机接口

> 来源: https://aigamepro.work/api_en/hid.html
> 更新时间: 2026-02-08 19:43:40

人机接口模块，通过模拟HID设备进行操作(需要ROOT)。

## API 列表

### hasPermit()
是否可用(判断设备是否有root权限)
- 返回: `{boolean}` 是否可用
- 版本: 1.6.2

### init()
初始化(约需5秒)
- 返回: `{boolean}` 是否初始化成功
- 版本: 1.6.2

```js
if ($hid.hasPermit()) {
    $hid.init();
}
```

### click(x, y)
点击坐标
- 参数: x `{int}` 坐标X
- 参数: y `{int}` 坐标Y
- 版本: 1.6.2

```js
$hid.click(500, 800);
```

### swipe(x1, y1, x2, y2, duration)
滑动
- 参数: x1 `{int}` 起点X
- 参数: y1 `{int}` 起点Y
- 参数: x2 `{int}` 终点X
- 参数: y2 `{int}` 终点Y
- 参数: duration `{int}` 持续时间(ms)
- 版本: 1.6.2

```js
$hid.swipe(100, 100, 500, 800, 1000);
```

### key(keyCode)
模拟按键
- 参数: keyCode `{int}` 键值
- 版本: 1.6.2

```js
$hid.key(4); // 返回键
```

### text(content)
输入文本
- 参数: content `{string}` 要输入的文本
- 版本: 1.6.2

```js
$hid.text("Hello World");
```


---

## $html-网页操作

# $html - 网页操作
> 来源：https://aigamepro.work/api_en/html
> 抓取时间：2026-05-01

网页操作

### escape(html) 转义HTML字符
### unescape(text) 还原转义
### cleanHtmlTag(text) 清除所有HTML标签
### removeHtmlTag(text, tagNames) 删除标签(含内容)
### unwrapHtmlTag(text, tagNames) 清除标签(保留内容)
### removeHtmlTag(text, withTagContent, tagNames) 清除指定标签
### removeHtmlAttr(html, attrs) 去除标签属性
### removeAllHtmlAttr(html, tagNames) 去除指定标签所有属性
### filter(html) 过滤XSS
### getWeiYunNote(shortLink) 处理腾讯微笔记 → {string} 可作免费云数据库

---

## $http-网络请求

# $http - 网络请求

> 来源: https://aigamepro.work/api_en/http.html
> 更新时间: 2026-04-10 17:55:36

网络请求模块，支持GET、POST、PUT、DELETE等HTTP方法。

## API 列表

### get(url)
同步GET请求
- 参数: url `{string}` 链接地址
- 返回: `{HttpResponse}` 返回结果
- 版本: 1.2.0

```js
let res = $http.get("https://api.example.com/data");
```

### get(opts)
GET请求(配置方式)
- 参数: opts `{HttpOptions}` 配置对象
- 返回: `{HttpResponse}` 返回结果
- 版本: 1.2.0

```js
let opt = {
    url: "", // 请求地址
    head: { "key": "value" },
    data: "请求数据",
    connectTimeout: 30,
    readTimeout: 30,
    writeTimeout: 30,
    callTimeout: 60
};
let res = $http.get(opt);
```

### post(opts)
POST请求
- 参数: opts `{HttpOptions}` 配置
- 返回: `{HttpResponse}` 返回结果
- 版本: 1.2.0

```js
// 发送JSON
$http.post({
    url: "",
    head: { "key": "value" },
    data: { name: "张三" }
});

// 发送XML
$http.post({
    url: "",
    head: {},
    data: "<name>zhang_san</name>"
});

// 发送表单
$http.post({
    url: "",
    head: {},
    form: { name: "zhang_san", sex: "boy" }
});

// 发送表单含文件
$http.post({
    url: "",
    head: {},
    form: {
        name: "zhang_san",
        head: "/sdcard/head.png"
    }
});

// 发送文件
$http.post({
    url: "",
    head: {},
    data: "/sdcard/test.js"
});

// 发送二进制
$http.post({
    url: "",
    head: {},
    data: "我会被转换成二进制",
    type: "byte"
});
```

### del(opts) / delete(opts)
DELETE请求
- 参数: opts `{HttpOptions}` 配置
- 返回: `{HttpResponse}` 返回结果
- 版本: 1.2.0

### put(opts)
PUT请求
- 参数: opts `{HttpOptions}` 配置
- 返回: `{HttpResponse}` 返回结果
- 版本: 1.2.0

### patch(opts)
PATCH请求
- 参数: opts `{HttpOptions}` 配置
- 返回: `{HttpResponse}` 返回结果
- 版本: 1.2.0

### download(url, savePath)
下载文件
- 参数: url `{string}` 下载地址
- 参数: savePath `{string}` 保存路径
- 版本: 1.0.0

### download(url, savePath, progressListener, completeCallback, onFailure)
下载文件(带进度)
- 参数: progressListener `{(cur,total,percent)=>{}}` 进度监听
- 参数: completeCallback `{()=>{}}` 完成回调
- 参数: onFailure `{(res)=>{}}` 错误回调

```js
$http.download(
    "https://example.com/image.png",
    "/sdcard/美女.png",
    (cur, total, percent) => {
        log("下载进度", percent);
    },
    () => {
        log("下载完毕");
    },
    (res) => {
        log("下载失败", res);
    }
);
```

### uri(uri)
解析Uri字符串
- 参数: uri `{String}` Uri字符串
- 返回: `{Uri}` Uri对象
- 版本: 1.3.7

```js
let uri = $http.uri("smsto:" + $str.uriEncode("13693749475"));
```

### wifiIp()
获取wifi的IP地址
- 返回: `{string}` IP地址，非wifi返回null


---

## $img-图片操作

# $img - 图片操作

> 来源: https://aigamepro.work/api_en/img.html
> 更新时间: 2026-02-08 19:43:41

图片处理模块，支持读取、裁剪、缩放、旋转、找图找色等操作。

## API 列表

### read(imgPath)
读取图片
- 参数: imgPath `{string}` 图片路径
- 返回: `{Image}` 图片对象
- 版本: 1.0.0

```js
let img = $img.read("/sdcard/Pictures/test.png");
```

### save(image, path)
保存图片(PNG格式，质量100)
- 参数: image `{Image}` 图片对象
- 参数: path `{string}` 保存路径
- 版本: 1.0.0

```js
$img.save(img, "/sdcard/output.png");
```

### toBase64(image)
转换为Base64字符串
- 参数: image `{Image}` 图片对象
- 返回: `{string}` Base64字符串
- 版本: 1.0.0

```js
let base64 = $img.toBase64(img);
```

### readBase64(base64)
从Base64加载图片
- 参数: base64 `{string}` Base64字符串
- 返回: `{Image}` 图片对象
- 版本: 1.0.0

### clip(image, x, y, w, h)
裁剪图片
- 参数: image `{Image}` 原图片
- 参数: x `{int}` 起点X
- 参数: y `{int}` 起点Y
- 参数: w `{int}` 宽度
- 参数: h `{int}` 高度
- 返回: `{Image}` 裁剪后的图片
- 版本: 1.0.0

```js
let clipped = $img.clip(img, 0, 0, 300, 200);
```

### resize(image, w, h)
设置尺寸(默认插值LINEAR)
- 参数: image `{Image}` 图片对象
- 参数: w `{int}` 宽度
- 参数: h `{int}` 高度
- 返回: `{Image}` 处理后的图片
- 版本: 1.0.0

```js
let resized = $img.resize(img, 200, 200);
```

### scale(image, scaleX, scaleY)
缩放图片
- 参数: scaleX `{double}` 宽度缩放倍数
- 参数: scaleY `{double}` 高度缩放倍数
- 返回: `{Image}` 处理后的图片
- 版本: 1.0.0

```js
let scaled = $img.scale(img, 0.5, 0.5);
```

### rotate(image, degree)
旋转图片
- 参数: degree `{float}` 旋转角度
- 返回: `{Image}` 处理后的图片
- 版本: 1.0.0

```js
let rotated = $img.rotate(img, 90);
```

### flip(image)
左右翻转
- 返回: `{Image}` 处理后的图片
- 版本: 1.0.0

### upside(image)
上下翻转
- 返回: `{Image}` 处理后的图片
- 版本: 1.0.0

### concat(img1, img2, dir)
拼接图片
- 参数: img1 `{Image}` 图片1
- 参数: img2 `{Image}` 图片2
- 参数: dir `{string}` 方向(left|right|top|bottom)
- 返回: `{Image}` 拼接后的图片
- 版本: 1.0.0

```js
let result = $img.concat(img1, img2, "bottom");
```

### gray(image)
灰度化
- 返回: `{Image}` 灰度图片
- 版本: 1.0.0

### threshold(image, thre)
二值化图片
- 参数: thre `{double}` 阈值
- 返回: `{Image}` 处理后的图片
- 版本: 1.0.0

### blur(img, size, point, type)
模糊处理
- 参数: size `{double[]}` 滤波器大小
- 参数: point `{double[]}` 锚点位置
- 参数: type `{string}` 边缘类型
- 返回: `{Image}` 处理后的图片
- 版本: 1.0.0

### findImg(bigImg, minImg, options)
找图
- 参数: bigImg `{Image}` 大图片
- 参数: minImg `{Image}` 小图片
- 参数: options `{object}` 参数
- 返回: `{Point}` 找到的位置(中心点)
- 版本: 1.0.0

```js
let point = $img.findImg(img1, img2, {
    similar: 0.8,
    region: [0, 0, 500, 600],
    trans: false,
    drawResult: true,
    savePath: "/sdcard/result.png"
});
```

### findImgAll(bigImg, minImg, options)
找到所有图片位置
- 返回: `{Point[]}` 所有的位置集合
- 版本: 1.0.0

### findColor(image, color, threshold)
查找颜色
- 参数: color `{string}` 颜色值
- 参数: threshold `{int}` 阈值
- 返回: `{Point}` 找到的位置
- 版本: 1.0.0

### show(image)
显示图片
- 参数: image `{Image}` 图片对象
- 版本: 1.0.0


---

## $log-日志

# $log - 日志框架

> 来源: https://aigamepro.work/api_en/log.html
> 更新时间: 2026-02-08 19:43:40

日志打印模块，支持多种日志级别。

## API 列表

### i(args) / info(args)
打印信息日志
- 参数: args `{string...}` 日志内容
- 版本: 1.0.0

```js
$log.i("信息");
$log.info("信息");
```

### d(args) / debug(args)
打印调试日志
- 版本: 1.0.0

```js
$log.d("调试");
$log.debug("调试");
```

### w(args) / warn(args)
打印警告日志
- 版本: 1.0.0

```js
$log.w("警告");
$log.warn("警告");
```

### e(args) / err(args)
打印异常日志
- 版本: 1.0.0

```js
$log.e("异常");
$log.err("异常");
```

### v(args)
打印冗余日志
- 版本: 1.0.0

```js
$log.v("冗余");
```

### log(args) / print(args)
打印日志
- 版本: 1.0.0

```js
$log.log("hello");
$log.print("hello");
```

### floaty()
打开日志悬浮窗
- 版本: 1.0.0

```js
$log.floaty();
```

### closeFloaty()
关闭日志悬浮窗
- 版本: 1.8.6

```js
$log.closeFloaty();
```

### activity()
打开日志界面
- 版本: 1.1.2

```js
$log.activity();
```

### delete()
删除本地缓存
- 版本: 1.0.6

```js
$log.delete();
```


---

## $media-媒体播放

# $media - 媒体播放
> 来源：https://aigamepro.work/api_en/media
> 抓取时间：2026-05-01

媒体播放

### play(path) 播放音频(自动回收) → {MediaPlayer|null}
### create() 创建媒体播放器 → {MediaPlayer}
### create(path) 创建并加载 → {MediaPlayer|null}
### setPath(mediaPlayer, path) 设置音频路径 → {boolean}

MediaPlayer方法参考android.media.MediaPlayer:
isPlaying/isLooping/start/stop/getDuration/getCurrentPosition/seekTo/prepare/reset/release

---

## $ocr-文字识别

# $ocr - 文字识别

> 来源: https://aigamepro.work/api_en/ocr.html
> 更新时间: 2026-04-07 10:13:44

文字识别模块，支持PaddleOcr、PpOcrV5、GoogleMlkit三种识别引擎。

## API 列表

### v(name)
设置OCR引擎
- 参数: name `{string}` 可选: ncnn, mlkit(默认), ppv5
- 版本: 1.2.2

```js
$ocr.v("mlkit");
```

### init()
初始化OCR(加载文字模型)
- 返回: `{DetectResult}` 结果
- 版本: 1.0.0

```js
$ocr.init();
```

### detect(options)
识别文字
- 参数: options `{OcrOptions}` 参数
- 返回: `{DetectResult}` 结果
- 版本: 1.0.0

```js
// 灰度化识别
let result = $ocr.detect({
    region: [0, 0, 200, 100],
    gray: true,
    save: true,
    savePath: "/sdcard/ocr.png"
});

// 二值化识别
let result = $ocr.detect({
    region: [0, 0, 200, 100],
    color: "#EEEEEE",
    threshold: 20,
    save: true,
    savePath: "/sdcard/ocr.png"
});
```

### detect64(base64)
识别Base64图片
- 参数: base64 `{String}` Base64字符串
- 返回: `{DetectResult}` 结果
- 版本: 1.0.0

### detectPath(imgPath)
识别路径中图片
- 参数: imgPath `{String}` 图片路径
- 返回: `{DetectResult}` 结果
- 版本: 1.0.0

### detectImg(img)
识别图片对象
- 参数: img `{Image}` 图片对象
- 返回: `{DetectResult}` 结果
- 版本: 1.0.0

### detectBitmap(bitmap)
识别位图对象
- 参数: bitmap `{Bitmap}` 位图对象
- 返回: `{DetectResult}` 结果
- 版本: 1.7.0

### getPoint(word, options)
识别文字拿位置
- 参数: word `{string}` 文字
- 参数: options `{OcrOptions}` 配置
- 返回: `{Point}` 位置
- 版本: 1.0.0

```js
let point = $ocr.getPoint("文字", {
    region: [0, 0, 200, 100],
    gray: true
});
if (point != null) {
    $act.click(point);
}
```

### line(options)
识别单行文字
- 参数: options `{OcrOptions}` 配置
- 返回: `{String}` 一行字符
- 版本: 1.0.0

```js
let result = $ocr.line({
    region: [0, 0, 200, 100],
    number: true  // 提取数字(用,号分割)
});
```

### onlyRec(image)
只识别文字(不检测方位)
- 参数: image `{Image}` 单一文字图片
- 返回: `{String}` 文字
- 版本: 1.9.6

### onlyDet(image)
只检测位置(不识别文字)
- 参数: image `{Image}` 图片
- 返回: `{String}` 位置信息
- 版本: 1.9.6


---

## $permit-权限

# $permit - 权限

> 来源: https://aigamepro.work/api_en/permit.html
> 更新时间: 2026-02-08 19:43:41

权限工具模块，用于获取和判断各种系统权限。

## API 列表

### floaty()
获取悬浮窗权限
- 版本: 1.1.6

```js
$permit.floaty();
```

### hasFloaty()
判断是否有悬浮窗权限
- 返回: `{boolean}` 是否有权限
- 版本: 1.1.6

### wza()
获取无障碍权限
- 版本: 1.1.6

### hasWza()
判断是否有无障碍权限
- 返回: `{boolean}` 是否有权限
- 版本: 1.1.6

### sd()
获取存储权限
- 版本: 1.1.6

### hasSd()
判断是否有存储权限
- 返回: `{boolean}` 是否有权限
- 版本: 1.1.6

### call()
获取电话权限
- 版本: 1.1.6

### hasCall()
判断是否有电话权限
- 返回: `{boolean}` 是否有权限
- 版本: 1.1.6

### set()
获取修改系统设置权限
- 版本: 1.1.6

### hasSet()
判断是否有修改系统设置权限
- 返回: `{boolean}` 是否有权限
- 版本: 1.1.6

### camera()
获取相机权限
- 版本: 1.1.6

### hasCamera()
判断是否有相机权限
- 返回: `{boolean}` 是否有权限
- 版本: 1.1.6

### record()
获取录音权限
- 版本: 1.1.6

### hasRecord()
判断是否有录音权限
- 返回: `{boolean}` 是否有权限
- 版本: 1.1.6

### loc()
获取定位权限
- 版本: 1.1.6

### hasLoc()
判断是否有定位权限
- 返回: `{boolean}` 是否有权限
- 版本: 1.1.6

### hasPermit(permitName)
判断是否有权限
- 参数: permitName `{string}` 权限名
- 返回: `{boolean}` 是否有权限
- 版本: 1.2.2

```js
$permit.hasPermit("android.permission.GET_ACCOUNTS");
```

### getPermit(permitName)
获取权限
- 参数: permitName `{string}` 权限名
- 版本: 1.2.2

### hasNotifyAccess()
是否已授予通知访问权限
- 返回: `{boolean}` 是否有通知访问权限
- 版本: 1.6.4

### notifyAccess()
获取通知访问权限
- 版本: 1.6.4

### readMedia()
获取读取媒体权限(音频、图片、视频)
- 版本: 1.6.4


---

## $plugin-插件系统

# $plugin - 插件系统
> 来源：https://aigamepro.work/api_en/plugin
> 抓取时间：2026-05-01

插件系统

插件=已安装的apk，与$ext不同：$ext加载文件无需安装，$plugin加载已安装apk更方便访问资源。

### ls() 列出所有插件
返回: [{appName, pkgName, icon}]

---

## $qr-二维码工具

# $qr - 二维码工具
> 来源：https://aigamepro.work/api_en/qr
> 抓取时间：2026-05-01

二维码工具

### make(content) → {Image}
### make(content, options) → {Image}
options: {w:500,h:500,margin:2,foreColor,bgColor}
### parse(path) → {string}
### parse(image) → {string}
### parse(x,y,w,h) 解析屏幕二维码 → {string}
### parse(region) / parse(rect) → {string}

---

## $res-资源管理器

# $res - 资源管理器
> 来源：https://aigamepro.work/api_en/res
> 抓取时间：2026-05-01

资源管理器(跨线程安全)

### create(appName) → {AgRes}
### set(resName, resData) 设置资源(可存js对象)
### get(resName) → {object}
### get(resName, defaultValue) 获取资源(带默认值)
### load(path) 加载本地资源到内部存储 → {boolean}
### ls() → {string[]} 资源名称列表
### cat() → {string} 资源内容(JSON格式化)
### dump(path) → {string} 导出资源

---

## $root-ROOT与Shell

# $root - ROOT与Shell命令
> 来源：https://aigamepro.work/api_en/root
> 抓取时间：2026-05-01

ROOT与Shell工具

### hasPermit() / getPermit() → {boolean}
### enablePointer(enable) 开关调试指针
### click(x,y) / click(x,y,dur) / click(x,y,dur,delay) / click(index) / click(Point) 点击
### press(x,y) / press(x,y,dur) / press(x,y,dur,delay) 长按
### move(x1,y1,x2,y2) / move(x1,y1,x2,y2,dur) / move(x1,y1,x2,y2,dur,delay) 滑动
### lock() / unlock() 锁屏/解锁
### power() 电源键
### exec(cmd) 执行ROOT命令
### exeRootShell(cmd) / exeRootShell(cmd,output) / exeRootShell(cmd,output,terminate) / exeRootShell(cmd,output,terminate,complete)
### exeRootShellSync(cmd) → {string} 同步执行ROOT命令
### exeShell(cmd) / exeShell(cmd,output) / exeShell(cmd,output,terminate) / exeShell(cmd,output,terminate,complete) 免ROOT命令
### closeRootShell() / closeShell() / closeAll() 关闭
### input(text) 输入文本
### killApp(pkgName) 杀死应用
### lsRunningApps(callback) 列出运行应用
### home() / back() / menu() / recent() 导航键
### setWmSize(w,h) / setDpi(density) / resetWm() 分辨率控制
### key(keyName) 模拟按键

---

## $screen-屏幕操作

# $screen - 屏幕操作

> 来源: https://aigamepro.work/api_en/screen.html
> 更新时间: 2026-02-08 19:43:41

屏幕操作模块，支持截屏、亮度设置、屏幕方向控制等。

## API 列表

### getPermit()
获取截屏权限
- 返回: `{boolean}` 是否获取成功
- 版本: 1.0.0

```js
$screen.getPermit();
let img = $screen.getScreen();
$img.show(img);
```

### hasPermit()
是否有截屏权限
- 返回: `{boolean}` 是否有截屏权限
- 版本: 1.1.5

```js
if ($screen.hasPermit()) {
    log("有截屏权限");
}
```

### getScreen()
获取屏幕截屏
- 返回: `{Image}` 截屏图片
- 版本: 1.0.0

### bright(bright)
设置屏幕亮度
- 参数: bright `{int}` 亮度值(0-255)
- 版本: 1.0.0

```js
$screen.bright(100);
```

### dir(degree)
设置屏幕方向
- 参数: degree `{string}` 屏幕旋转度数
- 版本: 1.0.0

```js
$screen.dir(0);    // 强制竖屏
$screen.dir(90);   // 强制右转横屏
$screen.dir(180);  // 强制倒置竖屏
$screen.dir(270);  // 强制左转横屏
$screen.dir(-1);   // 自动旋转
```

### getWidth()
屏幕宽度
- 返回: `{int}` 屏幕宽度
- 版本: 1.0.0

### getHeight()
屏幕高度
- 返回: `{int}` 屏幕高度
- 版本: 1.0.0

### getScreenInfo()
屏幕信息
- 返回: `{ScreenInfo}` 屏幕宽高信息
- 版本: 1.0.0

### getDensity()
获取密度因子
- 返回: `{float}` 密度因子
- 版本: 1.0.0

### isScreenOff()
判断屏幕是否息屏
- 返回: `{boolean}` 是否息屏
- 版本: 1.0.0

### isScreenOn()
判断屏幕是否亮屏
- 返回: `{boolean}` 是否亮屏
- 版本: 1.0.0

### split(tranCut, vertCut, index)
屏幕分割
- 参数: tranCut `{int}` 横向分割数量
- 参数: vertCut `{int}` 纵向分割数量
- 参数: index `{int}` 块的索引
- 返回: `{Rect}` 范围
- 版本: 1.1.2

```js
let region = $screen.split(3, 3, 8);
$draw.rect(region);
```

### save(path)
截屏并保存
- 参数: path `{String}` 保存路径
- 版本: 1.0.0

```js
$screen.save("/sdcard/Pictures/截屏.png");
```

### mustV()
强制竖屏截屏
- 版本: 1.1.8

### mustH()
强制横屏截屏
- 版本: 1.1.8

### cancelMust()
取消强制横竖屏
- 版本: 1.1.8


---

## $sqlite-轻量数据库

# $sqlite - 轻量数据库
> 来源：https://aigamepro.work/api_en/sqlite
> 抓取时间：2026-05-01

轻量数据库(线程安全)

### newSqlite() 创建新对象
### open(dbName) / open(dbName,external) 打开数据库 → {boolean}
external:false=内部存储(卸载清空), true=外部存储(需全路径)
### newTab(tableName,columns) 建表 → {boolean} (全部用字符串存储)
### add(tableName,data) 添加数据 → {boolean}
### update(tableName,map,where) 更新 → {boolean}
### ls(tableName) → {obj[]} 查询数据
### ls() → {string[]} 查询表名
### select(selectSql) → {obj[]} 执行查询
### hasTab(tableName) → {boolean}
### exe(sql) → {boolean} 执行SQL
### delDb(dbName) / delDb(dbName,external) 删库 → {boolean}
### delTab(table) 删表 → {boolean}
### close() 关闭 → {boolean}

---

## $storage-存储

# $storage - 存储

> 来源: https://aigamepro.work/api_en/storage.html
> 更新时间: 2026-02-08 19:43:42

轻量级存储方案，用于存储简单基础数据，一般用作全局配置。

## API 列表

### create(namespace)
创建storage
- 参数: namespace `{string}` 命名空间
- 返回: `{$storage}` 存储对象
- 版本: 1.0.0

```js
let storage = $storage.create("namespace");
```

### get(key, defaultValue)
获取值(带默认值)
- 参数: key `{string}` 关键字
- 参数: defaultValue `{Object}` 默认值
- 返回: `{Object}` 获取到的值
- 版本: 1.0.0

```js
let value = storage.get("MyStr", "我是默认值");
```

### put(key, value)
存放数据
- 参数: key `{string}` 关键字
- 参数: value `{Object}` 数据
- 版本: 1.0.0

```js
storage.put("MyStr", "我是被存放进来的数据");
```

### getStr(key)
获得字符串数据
- 参数: key `{string}` 关键字
- 返回: `{string}` 数据
- 版本: 1.0.0

### putStr(key, value)
存放字符串数据
- 参数: key `{string}` 关键字
- 参数: value `{string}` 数据
- 版本: 1.0.0

### getInt(key, defaultValue)
获得整数数据
- 参数: key `{string}` 关键字
- 参数: defaultValue `{int}` 默认值
- 返回: `{int}` 数据
- 版本: 1.0.0

### putInt(key, value)
存放数字数据
- 参数: key `{string}` 关键字
- 参数: value `{int}` 数据
- 版本: 1.0.0

### getBool(key, defaultValue)
获得布尔数据
- 参数: key `{string}` 关键字
- 参数: defaultValue `{boolean}` 默认值
- 返回: `{boolean}` 数据
- 版本: 1.0.0

### putBool(key, value)
存放布尔数据
- 参数: key `{string}` 关键字
- 参数: value `{boolean}` 数据
- 版本: 1.0.0

### getAll()
获得全部数据
- 返回: `{obj}` 数据对象
- 版本: 1.0.0

### has(key)
是否包含
- 参数: key `{string}` 关键字
- 返回: `{boolean}` 是否包含
- 版本: 1.0.0

### clear()
删除全部数据
- 版本: 1.0.0

### del(key)
移除数据
- 参数: key `{string}` 关键字
- 版本: 1.0.0


---

## $str - 字符串

# $str - 字符串

> 来源: https://aigamepro.work/api_en/str.html
> 更新时间: 2026-04-10 18:08:36

字符串操作工具模块。

## API 列表

### getBytes(str, encoding)
转字节(指定编码)
- 参数: str `{string}` 字符串
- 参数: encoding `{string}` 编码格式
- 返回: `{byte[]}` 字节数组
- 版本: 1.0.0

### encodeBase64(str) / decodeBase64(str)
Base64编码/解码
- 参数: str `{string}` 字符串
- 返回: `{string}` 编码/解码结果
- 版本: 1.0.0

```js
let base64Str = $str.encodeBase64("我是字符串");
let str = $str.decodeBase64(base64Str);
```

### strToHex(str) / hexToStr(dexStr)
字符串与16进制互转
- 版本: 1.9.7

### uriEncode(str) / uriDecode(str)
Uri编码/解码
- 版本: 1.3.7

### random(str) / random(strList)
随机字符/元素
- 返回: `{string}` 随机结果
- 版本: 1.0.0

### isBlank(str) / isNotBlank(str)
是否为空白/非空白
- 返回: `{boolean}` 判断结果
- 版本: 1.0.0

### isEmpty(str) / isNotEmpty(str)
是否为空/非空
- 返回: `{boolean}` 判断结果
- 版本: 1.0.0

### trim(str)
去除首尾空格
- 返回: `{string}` 处理后的字符串
- 版本: 1.0.0

### subStart(input, length) / subEnd(input, length)
截取开头/末尾字符
- 参数: input `{string}` 输入字符串
- 参数: length `{int}` 截取长度
- 返回: `{string}` 结果
- 版本: 1.0.0

### startWith(str, prefix) / endWith(str, suffix)
是否以前缀开头/后缀结尾
- 返回: `{boolean}` 判断结果
- 版本: 1.0.0

### contains(str, searchStr)
是否包含指定子字符串
- 返回: `{boolean}` 判断结果
- 版本: 1.0.0

### replace(str, searchStr, replacement)
替换字符串
- 返回: `{string}` 替换后的字符串
- 版本: 1.0.0

### split(str, separator)
分割字符串
- 返回: `{string[]}` 分割后的数组
- 版本: 1.0.0

### format(template, params)
格式化字符串
- 参数: template `{string}` 模板
- 参数: params `{Object}` 参数
- 返回: `{string}` 格式化后的字符串
- 版本: 1.0.0

### equals(str1, str2)
比较两个字符串是否相等
- 返回: `{boolean}` 是否相等
- 版本: 1.0.0

### toUnderlineCase(str) / toCamelCase(name)
转换为下划线/驼峰格式
- 返回: `{string}` 转换结果
- 版本: 1.0.0

### upperFirst(str) / lowerFirst(str)
首字母大写/小写
- 返回: `{string}` 处理结果
- 版本: 1.0.0

### reverse(str)
反转字符串
- 返回: `{string}` 反转后的字符串
- 版本: 1.0.0

### uuid()
生成UUID
- 返回: `{string}` UUID字符串
- 版本: 1.0.0

### similar(str1, str2)
计算两个字符串的相似度
- 返回: `{double}` 相似度(0.0-1.0)
- 版本: 1.0.0

### extractNumbers(str)
提取数字
- 返回: `{string}` 提取的数字(用,号分割)
- 版本: 1.0.0

```js
let nums = $str.extractNumbers("22字符33串44");
// nums = "22,33,44"
```

### length(cs)
获取字符串长度
- 返回: `{int}` 长度
- 版本: 1.0.0

### isNumeric(str)
判断是否为数字
- 返回: `{boolean}` 判断结果
- 版本: 1.0.0


---

## $sys-系统工具

# $sys - 系统工具
> 来源：https://aigamepro.work/api_en/sys
> 抓取时间：2026-05-01

系统工具

### airplane(enable) 设置飞行模式
### volume(mode, volume) 设置音量
mode: system|ring|music|alarm|notification|call|dtmf|accessibility (可只写前3位)
### getDeviceId() → 设备唯一标识
### hasClip() → {boolean} 剪切板是否有内容
### clearClip() → {boolean} 清除剪切板
### getClip() → {String} 获取剪切板(安卓13+可能无法获取)
### setClip(text) → {String} 设置剪切板
### ignorePower(pkgName) → {boolean} 是否忽略电池优化
### requestIgnorePower(pkgName) 请求忽略电池优化
### stayAlive(enable) 开启/关闭前台保活服务
### hasStayAlive() → {boolean} 是否开启保活
### hasPointer() → {boolean} 是否开启指针
### pointer(enable) 开发者指针授权(需root/shizuku)
### volumeCtrl(enable) 设置音量控制(关闭后连续减音量不会停止脚本)

---

## $szk-Shizuku工具

# $szk - Shizuku工具
> 来源：https://aigamepro.work/api_en/szk
> 抓取时间：2026-05-01

Shizuku工具(无需root享root级权限)

### getPermit() 获取Shizuku权限
### hasPermit() → {boolean} 是否可用
### enablePointer(enable) 启用指针
### waitPermit() → {boolean} 阻塞等待权限(需先getPermit)
### waitPermit(callback) 异步等待权限
### click(x,y) / click(x,y,dur) / click(x,y,dur,delay) / click([x,y]) / click(Point) 点击
### press(x,y) / press(x,y,dur) / press(x,y,dur,delay) 长按
### move(x1,y1,x2,y2) / move(x1,y1,x2,y2,dur) / move(x1,y1,x2,y2,dur,delay) 滑动
### home() / back() / menu() / recent() / power() / lock() / unlock() 导航键
### input(text) 输入文本
### killApp(pkgName) 杀死应用
### setWmSize(w,h) / setDpi(density) / resetWm() 分辨率控制
### exe(cmd) → {string} 执行命令
### exe(cmd,infoCallback,errorCallback) 执行命令(带回调)
### exe(cmd,infoCallback,errorCallback,endCallback) 执行命令(带结束回调)
### exe(cmd,startCallback,infoCallback,errorCallback,endCallback) 执行命令(完整回调)

---

## $thread-多线程

# $thread - 多线程

> 来源: https://aigamepro.work/api_en/thread.html
> 更新时间: 2026-02-08 19:43:42

并发编程模块，支持多线程并发编程。

## API 列表

### ui(runnable)
在UI线程中执行
- 参数: runnable `{()=>{}}` 任务
- 版本: 1.0.0

```js
$thread.ui(() => {
    // 这里是UI线程
});
```

### run(runnable)
创建并运行线程
- 参数: runnable `{()=>{}}` 任务
- 返回: `{Threadx}` 增强线程
- 版本: 1.2.0

```js
let t1 = $thread.run(() => {
    // 耗时任务
});
t1.interrupt();
```

### create(runnable)
创建线程(自动生成线程名称)
- 参数: runnable `{()=>{}}` 线程任务
- 返回: `{Threadx}` 增强线程
- 版本: 1.0.0

```js
let t1 = $thread.create(() => {
    for (let i = 0; i < 10; i++) {
        sleep(300);
        log(t1.getName() + "==>" + i);
    }
});
t1.start();
```

### create(name, runnable)
创建线程(指定名称)
- 参数: name `{string}` 线程名称
- 参数: runnable `{()=>{}}` 线程任务
- 返回: `{Threadx}` 增强线程
- 版本: 1.0.0

### has(name)
是否存在线程名称
- 参数: name `{string}` 线程名称
- 返回: `{boolean}` 是否存在
- 版本: 1.2.0

### get(name)
获得已存在的线程
- 参数: name `{string}` 线程名称
- 返回: `{Threadx}` 增强线程
- 版本: 1.0.0

### loop(name, runnable)
创建循环执行器
- 参数: name `{string}` 循环器名称
- 参数: runnable `{()=>{}}` 循环体
- 返回: `{Threadx}` 增强线程
- 版本: 1.0.0

```js
let t1 = $thread.loop("循环1号", () => {
    sleep(1000);
    log("我还活着！");
});
t1.start();
```

### stopLoop(name)
停止循环执行器
- 参数: name `{string}` 循环器名称
- 版本: 1.0.0

### stop(threadx) / stop(threadName)
停止指定线程
- 参数: threadx `{Threadx}` 或 threadName `{string}`
- 版本: 1.0.0

### stopAll()
停止所有线程(不包括循环器线程)
- 版本: 1.0.0

### stopAllLoop()
停止所有循环执行器(包括setInterval)
- 版本: 1.0.0


---

## $tip - 阻塞式对话框

# $tip - 阻塞式对话框

> 来源: https://aigamepro.work/api_en/tip.html  
> 更新时间: 2026-02-08

**阻塞式 = 调用后暂停当前线程，对话框关闭后才继续执行**

## 基础对话框

| 方法 | 说明 |
|------|------|
| $tip.i(msg) | [信息]对话框 |
| $tip.v(msg) | [说明]对话框 |
| $tip.w(msg) | [警告]对话框 |
| $tip.e(msg) | [异常]对话框 |
| $tip.d(msg) | [调试]对话框 |

## 输入对话框

### $tip.input(title, callback)
```js
$tip.input("请输入你的名字",(value)=> {
    toast("输入的内容:"+value);
});
```

### $tip.input(title, def, callback)
带默认值
```js
$tip.input("请输入你的名字","张三",(value)=> {
    toast("输入的内容:"+value);
});
```

### $tip.input(title, hint, def, callback)
带提示和默认值

## 输入整数

### $tip.inputInt(title, callback)
### $tip.inputInt(title, def, callback)
### $tip.inputInt(title, hint, callback)
### $tip.inputInt(title, hint, def, callback)

```js
$tip.inputInt("年龄",18,(num)=> {
    toast("刚满"+num+"岁~");
});
```
⚠️ 无法解析成数字则回调结果为0

## 文本提示

### $tip.show(title, msg)
### $tip.show(title, msg, click)
### $tip.show(title, view) — 自定义对话框（右上角关闭）
### $tip.show(title, view, click) — 自定义对话框（确定关闭）

```js
let ui = $ui.layout("ui.xml");
let view = ui.getView();
$tip.show("自定义对话框", view);
```

## 选择对话框

### $tip.one(title, items, callback) — 单选
```js
$tip.one("请选择",["小狗","小猫","小猪"],(value)=> {
    toast("你选择了:"+value);
});
```

### $tip.more(title, items, callback) — 多选
```js
$tip.more("请选择",["小狗","小猫","小猪"],(values)=> {
    toast("你选择了:"+values);
});
```

## 日期时间

### $tip.calendar(callback) — 日历选择日期
### $tip.date(callback) — 滚轮选择日期
### $tip.clock(callback) — 时间选择
### $tip.time(callback) — 滚轮选择时间

```js
$tip.calendar((info)=> {
    let year = info.year;
    let month = info.month;
    let day = info.day;
});
```

## ⚠️ 之前错误修正
- ❌ `$tip.one()` 不存在 → **错误！$tip.one() 确实存在**，之前编造说它不存在是错的
- ✅ $tip 完整API: i/v/w/e/d(msg), input, inputInt, show, one, more, calendar, date, clock, time


---

## $touch-触摸操作

# $touch - 触摸操作

> 来源: https://aigamepro.work/api_en/touch.html
> 更新时间: 2026-02-08 19:43:43

触摸驱动模块，需要ROOT权限，部分手机不会与手指触摸冲突。

## API 列表

### hasPermit()
是否可用(判断设备是否有root权限)
- 返回: `{boolean}` 是否可用
- 版本: 1.5.2

```js
if ($touch.hasPermit()) {
    $touch.init();
}
```

### init()
初始化(约需5秒，已初始化则直接返回true)
- 返回: `{boolean}` 是否初始化成功
- 版本: 1.5.2

```js
$touch.init();
```

### touchDown(fingerId, x, y)
按下手指
- 参数: fingerId `{int}` 手指ID
- 参数: x `{int}` 坐标X
- 参数: y `{int}` 坐标Y
- 版本: 1.5.2

```js
$touch.touchDown(1, 100, 100);
```

### touchMove(fingerId, x, y)
移动手指
- 参数: fingerId `{int}` 手指ID
- 参数: x `{int}` 坐标X
- 参数: y `{int}` 坐标Y
- 版本: 1.5.2

```js
$touch.touchMove(1, 300, 500);
```

### touchUp(fingerId)
抬起手指
- 参数: fingerId `{int}` 手指ID
- 版本: 1.5.2

```js
$touch.touchUp(1);
```

### click(x, y)
点击(高效，C/C++层执行系统命令)
- 参数: x `{int}` 坐标X
- 参数: y `{int}` 坐标Y
- 版本: 1.5.4

```js
$touch.click(300, 500);
```

### click(pointerId, x, y, dur)
点击(指定时长)
- 参数: pointerId `{int}` 指针ID
- 参数: dur `{int}` 按压时长
- 版本: 1.5.2

### press(x, y)
长按(默认750毫秒)
- 版本: 1.5.2

```js
$touch.press(300, 500);
```

### press(pointerId, x, y, dur)
长按指定时长
- 版本: 1.5.2

```js
$touch.press(1, 300, 500, 2000);
```

### move(x, y, x2, y2, dur)
滑动
- 参数: x `{int}` 起点X
- 参数: y `{int}` 起点Y
- 参数: x2 `{int}` 终点X
- 参数: y2 `{int}` 终点Y
- 参数: dur `{int}` 移动时间
- 版本: 1.5.2

```js
$touch.move(100, 100, 300, 500, 1000);
```

### swipe(x, y, x2, y2, dur)
模拟滑动(C/C++层系统调用)
- 版本: 1.5.4

```js
$touch.swipe(100, 200, 600, 1200, 2000);
```

### key(keyCode)
模拟按键(C/C++层系统调用)
- 参数: keyCode `{int}` 键值
- 版本: 1.5.4

```js
$touch.key(4); // 返回按钮
```


---

## $tts - 语音

# $tts - 语音

> 来源: https://aigamepro.work/api_en/tts.html
> 更新时间: 2026-02-08 19:43:42

语音合成模块，将文字转换为语音播放。

## API 列表

### speak(text)
朗读文本
- 参数: text `{string}` 要朗读的文字
- 版本: 1.0.0

```js
$tts.speak("你好，欢迎使用自动化助手");
```

### speak(text, callback)
朗读文本(带回调)
- 参数: callback `{()=>{}}` 朗读完成回调
- 版本: 1.0.0

```js
$tts.speak("朗读完成", () => {
    log("朗读完毕");
});
```

### stop()
停止朗读
- 版本: 1.0.0

```js
$tts.stop();
```

### setSpeed(speed)
设置语速
- 参数: speed `{float}` 语速倍数(0.5-2.0)
- 版本: 1.0.0

```js
$tts.setSpeed(1.5);
```

### setPitch(pitch)
设置音调
- 参数: pitch `{float}` 音调倍数(0.5-2.0)
- 版本: 1.0.0

### setVolume(volume)
设置音量
- 参数: volume `{float}` 音量倍数(0.0-1.0)
- 版本: 1.0.0

### isSpeaking()
是否正在朗读
- 返回: `{boolean}` 是否正在朗读
- 版本: 1.0.0


---

## $tts-语音阅读

# $tts - 语音阅读
> 来源：https://aigamepro.work/api_en/tts
> 抓取时间：2026-05-01

语音阅读(需TTS引擎)

### read(text, options)
播放文本(配置)
options: {rate:1, pitch:1, volume:1, language:"zh", streamType:"system"}

### read(text)
播放文本(默认配置)

---

## $ui-界面对象

# $ui - 界面对象

> 来源: https://aigamepro.work/ui_en/ui/UI.html  
> 更新时间: 2026-04-10

## 核心 API

### $ui.layout(path)
解析布局文件，返回 ui 对象
```js
let ui = $ui.layout("main.xml");
ui.show();
```

### ui.getView()
获取解析后的最大布局视图
- 返回: `{View}`

### ui.id(id)
通过id获取控件
- 返回: `{XView}` 控件对象
```js
let mButton = ui.id("mButton");
```

### ui.run(runnable)
UI线程执行
```js
ui.run(()=>{
    // 在ui线程中执行的代码
});
```

### ui.toast(text) / ui.toast(text, gravity)
悬浮土司（基于悬浮窗，显示在界面顶层）

### ui.show()
显示界面

### ui.finish()
结束/关闭界面

### ui.activity()
等待获得activity对象
- 返回: `{AppCompatActivity}`

## 生命周期回调

| 方法 | 说明 |
|------|------|
| ui.onStart((activity)=>{}) | 界面初始时执行 |
| ui.onResume((activity)=>{}) | 重返界面时执行 |
| ui.onPause((activity)=>{}) | 界面暂停时执行 |
| ui.onStop((activity)=>{}) | 界面停止时执行 |
| ui.onDestroy((activity)=>{}) | 界面销毁时执行（释放资源） |
| ui.onRestart((activity)=>{}) | 重新刷新界面时执行 |

## 键盘事件

| 方法 | 参数 |
|------|------|
| ui.onKeyDown((keyCode,event,activity)=>{}) | 按键按下 |
| ui.onKeyUp((keyCode,event,activity)=>{}) | 按键抬起 |
| ui.onKeyLongPress((keyCode,event,activity)=>{}) | 长按 |

## 其他

### ui.setDir(dir)
设置界面显示方向
- 可选值: "h"(横向), "v"(竖向), "auto"(自动), null(默认)

### ui.setTheme(style)
设置主题（需重启生效）
- 可选值: "blue.light", "blue.dark", "green.light", "pink.light", "orange.dark" 等

## 常量
- `$ui.VISIBLE` - 可见
- `$ui.INVISIBLE` - 不可见（占位）
- `$ui.GONE` - 不可见（不占位）
- `$ui.BOLD`, `$ui.NORMAL`, `$ui.ITALIC`, `$ui.BOLD_ITALIC` - 字体常量

## ⚠️ 关键修正
- ✅ 正确: `let ui = $ui.layout("main.xml"); ui.show();`
- ✅ 获取控件: `ui.id("controlId")` — 这才是标准用法
- ❌ 旧错误: `$floaty.create().setLayout().id()` 不是 $floaty 的用法


---

## $ws-双工通信

# $ws - 双工通信WebSocket
> 来源：https://aigamepro.work/api_en/ws
> 抓取时间：2026-05-01

双工通信WebSocket

### create(url) → {Ws} 封装的WebSocket对象

Ws对象方法(链式调用):
- .onOpen((res,ws)=>{}) 连接成功
- .onClosed((code,reason,ws)=>{}) 关闭后
- .onClosing((code,reason,ws)=>{}) 正在关闭
- .onFail((err,res,ws)=>{}) 异常
- .onMsgStr((str,ws)=>{}) 接收字符串
- .onMsgByte((bs)=>{}) 接收二进制(bs:okio.ByteString,有hex/base64/md5/toByteArray方法)
- .send(str) 发送字符串
- .send([10,15,1,1,0,5]) 发送二进制

---

## $yolo-目标检测

# $yolo - 目标检测

> 来源: https://aigamepro.work/api_en/yolo.html
> 更新时间: 2026-02-08 19:43:44

目标检测模块，基于YOLO模型进行图像识别。

## API 列表

### init(modelPath)
初始化模型
- 参数: modelPath `{string}` 模型文件路径
- 返回: `{boolean}` 是否初始化成功
- 版本: 1.0.0

```js
$yolo.init("/sdcard/model/yolov5.tflite");
```

### detect(image, confidence)
检测图片中的目标
- 参数: image `{Image}` 图片对象
- 参数: confidence `{float}` 置信度阈值(0.0-1.0)
- 返回: `{YoloResult[]}` 检测结果数组
- 版本: 1.0.0

```js
let img = $screen.getScreen();
let results = $yolo.detect(img, 0.5);
for (let result of results) {
    log("类别:", result.label, "置信度:", result.confidence);
    log("位置:", result.x, result.y, result.width, result.height);
}
```

### detectPath(imgPath, confidence)
检测路径中图片的目标
- 参数: imgPath `{string}` 图片路径
- 参数: confidence `{float}` 置信度阈值
- 返回: `{YoloResult[]}` 检测结果数组
- 版本: 1.0.0

### setNmsThreshold(threshold)
设置NMS阈值
- 参数: threshold `{float}` NMS阈值
- 版本: 1.0.0

### setNumThreads(threads)
设置推理线程数
- 参数: threads `{int}` 线程数
- 版本: 1.0.0

### close()
释放模型资源
- 版本: 1.0.0

```js
$yolo.close();
```

## YoloResult 对象

### 属性
- label `{string}` 类别名称
- confidence `{float}` 置信度
- x `{int}` 边界框左上角X坐标
- y `{int}` 边界框左上角Y坐标
- width `{int}` 边界框宽度
- height `{int}` 边界框高度


---

## excel-v2

# $excel - 表格操作

> 来源: https://aigamepro.work/api_en/excel  
> 更新时间: 2026-05-01

## 概述

表格操作模块，用于读取和写入二维数组到表格中。需要在安卓8+系统上才能完美运行。

## API 列表

### read(path)

读取第一个表格

- **参数**: `path` `{String}` 路径（支持相对路径）
- **返回**: `{String[][]}` 表格数据
- **版本**: 1.7.8

```js
// 读取第一个表格数据
let data = $excel.read("data.xlsx"); // 相对路径
log(data);
// 输出:
// [
//   ["学号","姓名","年龄","性别","入学日期"],
//   ["2023001","张三","20","男","2023-09-01"],
//   ["2023002","李四","19","女","2023-09-01"],
//   ["2023003","王五","21","男","2022-09-01"],
//   ["2023004","赵六","20","女","2023-09-01"]
// ]
```

### read(path, index)

读取指定表格

- **参数**: `path` `{String}` 路径（支持相对路径）
- **参数**: `index` `{int}` 表格索引（从0开始）
- **返回**: `{String[][]}` 表格数据
- **版本**: 1.7.8

```js
// 读取第2个表格数据（索引为1）
let data = $excel.read("data.xlsx", 1);
log(data);
// 输出:
// [
//   ["商品ID","商品名称","商品单价","库存"],
//   ["P001","笔记本电脑","4999","10"],
//   ["P002","智能手机","3999","25"]
// ]
```

### num(path)

获取表格数量

- **参数**: `path` `{String}` 路径（支持相对路径）
- **返回**: `{int}` 表格数量
- **版本**: 1.7.8

```js
let sheetNum = $excel.num("data.xlsx");
log(sheetNum); // 输出: 3
```

### ls(path)

获取表格名称列表

- **参数**: `path` `{String}` 路径（支持相对路径）
- **返回**: `{String[]}` 表格名称列表
- **版本**: 1.7.8

```js
let sheetList = $excel.ls("data.xlsx");
log(sheetList); // 输出: ["班级表","商品表","部门表"]
```

### loop(path, onSheet)

遍历所有表格

- **参数**: `path` `{String}` 路径（支持相对路径）
- **参数**: `onSheet` `{(sheetName, sheetData)=>{}}` 数据回调函数
- **版本**: 1.7.8

```js
$excel.loop("data.xlsx", (name, data) => {
    log(name, data);
});
```

### write(sheetName, sheetData, path)

写入表格

- **参数**: `sheetName` `{String}` 表格名称
- **参数**: `sheetData` `{String[][]}` 表格数据（注意：所有值必须是字符串类型）
- **参数**: `path` `{String}` 保存路径（**不支持相对路径，必须是绝对路径**）
- **版本**: 1.7.8

```js
let sheetData = [
    ["姓名", "年龄"],
    ["小红", "18"],  // 注意必须都是字符串类型
    ["小明", "19"]
];
let sheetName = "我的表格";
let savePath = "/sdcard/demo.xlsx";  // 必须是绝对路径
$excel.write(sheetName, sheetData, savePath);
```

## 注意事项

- 需要安卓8+系统
- `read()`/`num()`/`ls()`/`loop()` 支持相对路径
- `write()` 只支持绝对路径
- 所有表格数据均为字符串类型


---

## XView-控件父类

# XView - 控件父类（公共方法）

> 来源: https://aigamepro.work/ui_en/XView.html  
> 更新时间: 2026-03-17

**所有控件和布局都继承自 XView，因此以下方法所有组件都能调用。**

## 视图操作

| 方法 | 说明 | 返回 |
|------|------|------|
| getView() | 获得安卓原生视图 | `{View}` |
| getName() | 获取组件节点名称 | `{String}` |
| parseColor(color) | 解析颜色（支持"white","colorPrimary"等） | `{int}` |
| dp(dp) | dp转px | `{float}` |
| bgImg(path) | 设置背景图片 | - |

## 提示与交互

| 方法 | 说明 |
|------|------|
| snack(msg) | 显示 Snackbar |
| snack(msg, title, callback) | Snackbar 带按钮 |
| click(callback) | 设置点击事件 `callback(view)` |
| longClick(callback) | 设置长按事件 |
| popup(titles, callback) | 显示选项菜单 |
| popup(titles, gravity, callback) | 选项菜单（带重力） |

## 控件状态

| 方法 | 说明 |
|------|------|
| setEnabled(bool) | 启用/禁用 |
| isEnabled() | 是否启用 |
| setVisibility(visibility) | 设置可见性（$ui.VISIBLE/$ui.GONE） |
| isVisibility() | 获得可见性 |
| setFocusable(bool) | 设置可聚焦 |
| setClickable(bool) | 设置可点击 |
| setAlpha(float) | 设置透明度 (0.5半透明, 1不透明) |
| getAlpha() | 获得透明度 |
| setElevation(int) | 设置立体值 |

## 位置与尺寸

| 方法 | 说明 | 返回 |
|------|------|------|
| getX() / setX(float) | 获取/设置x值 | `{float}` |
| getY() / setY(float) | 获取/设置y值 | `{float}` |
| getW() | 获得控件宽度 | `{float}` |
| getH() | 获得控件高度 | `{float}` |
| onTouch(callback) | 触摸事件 `callback(event,view)` | - |

## parseColor 支持的颜色

**基础色**: white, black, null, none, green, red, blue, yellow

**主题色**:
- `colorPrimary` - 主题最明显颜色
- `colorSurface` - 背景颜色
- `colorOnSurface` - 文字颜色
- `colorOnPrimary`, `colorPrimaryContainer`, `colorOnPrimaryContainer`
- `colorSecondary`, `colorOnSecondary`, `colorSecondaryContainer`
- `colorTertiary`, `colorOnTertiary`, `colorTertiaryContainer`
- `colorError`, `colorErrorContainer`, `colorOnErrorContainer`
- `colorOnBackground`, `colorSurfaceVariant`, `colorOnSurfaceVariant`
- `colorOutline`, `colorOutlineVariant`, `colorPrimaryInverse`


---

