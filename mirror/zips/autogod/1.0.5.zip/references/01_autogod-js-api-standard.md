# AutoGOD JavaScript 方言与 API 规范

## 更新时间
2026-04-30

## 一、核心模块概览

AutoGOD 提供以下核心模块：

| 模块 | 用途 | 权限要求 |
|------|------|----------|
| `$act` | 手势动作（点击、滑动、长按等） | 无障碍/Root/Shizuku |
| `$screen` | 屏幕操作（截屏、亮度、方向等） | 无障碍/录屏权限 |
| `$ocr` | 文字识别（PaddleOcr、PpOcrV5、GoogleMlkit） | 无 |
| `$http` | 网络请求（GET、POST、下载等） | 网络 |
| `$floaty` | 悬浮窗（应用级、系统级） | 悬浮窗权限 |
| `$file` | 文件系统操作 | 存储权限 |
| `$img` | 图像处理 | 无 |
| `$draw` | 绘图调试 | 无 |

## 二、$act - 手势动作 API

### 2.1 权限管理

**优先级顺序：Root > Shizuku > 无障碍**

```javascript
// 检查无障碍权限
let hasPermit = $act.hasPermit(); // 返回 boolean

// 获取无障碍权限（阻塞式）
$act.getPermit(); // 返回 boolean

// 注意：getPermit() 是阻塞函数，不要在 UI 线程调用
// UI 线程请使用 $permit.wza()
```

### 2.2 点击操作

**规范：所有坐标参数必须为整数，支持多种参数形式**

```javascript
// 基础点击
$act.click(x, y);                    // 基础坐标点击
$act.click(x, y, dur);               // 带时长的点击（长按效果）
$act.click(x, y, dur, delay);        // 带前置延迟的点击

// 数组形式
$act.click([x, y]);                  // 数组坐标
$act.click([x, y], dur);             // 数组 + 时长
$act.click([x, y], dur, delay);      // 数组 + 时长 + 延迟

// OpenCV Point 对象
let point = new org.opencv.core.Point(x, y);
$act.click(point);
$act.click(point, dur);
$act.click(point, dur, delay);

// 节点点击（推荐）
let node = $act.selector()
    .pkg("com.example.app")
    .cls("android.widget.Button")
    .waitFirst();
if (node != null) {
    node.draw();        // 绘制节点位置（调试用）
    node.click();       // 方式1：节点自身点击
    $act.click(node);   // 方式2：通过 $act 点击
    $act.click(node, true); // 方式3：强制使用 $act 坐标点击
}
```

### 2.3 长按操作

```javascript
// 坐标长按
$act.press(x, y);                    // 基础长按（默认时长）
$act.press(x, y, dur);               // 指定时长
$act.press(x, y, dur, delay);        // 带前置延迟

// 节点长按
let node = $act.selector().text("按钮").waitFirst();
if (node != null) {
    $act.press(node);        // 节点长按
    node.press();            // 等价写法
}
```

### 2.4 滑动操作

```javascript
// 基础滑动
$act.move(x1, y1, x2, y2);           // 起点到终点
$act.move(x1, y1, x2, y2, dur);      // 带时长
$act.move(x1, y1, x2, y2, dur, delay); // 带前置延迟

// 模拟真人滑动（推荐）
$act.slide(startX, startY, endX, endY, duration);

// 节点滑动
$act.move(node, "up");               // 方向滑动：up|down|left|right
$act.move(node, x2, y2, dur);        // 节点到目标坐标
```

### 2.5 多指手势

```javascript
// 单指手势：[起点x, 起点y, 终点x, 终点y, 开始时间, 时长]
$act.gesture([500, 0, 500, 800, 0, 500]);

// 双指放大
let centerX = 500, centerY = 800;
$act.gesture(
    [centerX, centerY, centerX-400, centerY-400, 0, 500],  // 手指1
    [centerX, centerY, centerX+400, centerY+400, 0, 500]   // 手指2
);

// 三指滑动
$act.gesture(
    [500, 0, 500, 800, 500, 0],
    [550, 0, 550, 800, 500, 0],
    [600, 0, 600, 800, 500, 0]
);
```

### 2.6 系统按键

```javascript
$act.home();          // Home 键
$act.back();          // 返回键
$act.menu();          // 菜单键
$act.recent();        // 近期任务
$act.power();         // 长按电源
$act.lock();          // 锁屏
$act.unlock();        // 唤醒屏幕
$act.splitScreen();   // 分屏
$act.settings();      // 设置
$act.notifications(); // 通知
$act.screenshot();    // 截屏（系统自带）
```

### 2.7 文本输入

```javascript
// 基础输入（粘贴到当前焦点）
$act.input("要输入的文字");

// 指定节点输入
let node = $act.selector().cls("android.widget.EditText").waitFirst();
if (node != null) {
    $act.input(node, "要输入的文字");
}
```

### 2.8 界面监听

```javascript
// 获取当前 Activity
let activityName = $act.activity();
log("当前界面: " + activityName);

// 监听界面变化
$act.activity((name) => {
    log("界面切换到: " + name);
});
```

### 2.9 UI 选择器

```javascript
let node = $act.selector()
    .pkg("com.example.app")        // 包名
    .cls("android.widget.Button")  // 类名
    .text("确定")                  // 文本
    .desc("描述")                  // 描述
    .id("btn_ok")                  // ID
    .bounds(0, 0, 100, 100)        // 边界范围
    .waitFirst(3000);              // 等待出现（毫秒）

if (node != null) {
    node.click();
}
```

### 2.10 配置选项

```javascript
// 设置抖动值（随机点击范围）
$act.setJitter(10); // 点击坐标会在 ±10 范围内随机

// 禁用 Root（强制使用无障碍）
$act.enableRoot(false);

// 禁用 Shizuku
$act.enableSzk(false);

// 设置只使用无障碍
$act.setOnlyAcc(true);

// 分辨率适配
$act.setAdapt(true);
$act.setDevDensity(2.75); // 开发环境密度因子
```

## 三、$screen - 屏幕操作 API

### 3.1 权限管理

```javascript
// 检查截屏权限
if ($screen.hasPermit()) {
    log("有截屏权限");
}

// 获取截屏权限（阻塞式）
$screen.getPermit();

// 获取截屏权限一次（非阻塞）
$screen.getPermitOnce();

// 只使用录屏权限
$screen.onlyRecord(true);

// 检查录屏权限
if ($screen.hasRecord()) {
    log("有录屏权限");
}
```

### 3.2 截屏操作

```javascript
// 获取截屏
let img = $screen.getScreen();
$img.show(img); // 显示图片

// 截屏并保存
$screen.save("/sdcard/screenshot.png");

// 屏幕信息
let w = $screen.getWidth();
let h = $screen.getHeight();
let info = $screen.info(); // 或 $screen.getScreenInfo()
let density = $screen.getDensity();
```

### 3.3 屏幕控制

```javascript
// 设置亮度（0-255）
$screen.bright(100);

// 设置方向
$screen.dir(0);    // 竖屏
$screen.dir(90);   // 右转横屏
$screen.dir(180);  // 倒置竖屏
$screen.dir(270);  // 左转横屏
$screen.dir(-1);   // 自动旋转

// 屏幕状态
if ($screen.isScreenOn()) {
    log("屏幕亮着");
}
if ($screen.isScreenOff()) {
    log("屏幕息屏");
}
```

### 3.4 屏幕分割（全分辨率适配）

```javascript
// 将屏幕分成 3x3 九宫格，获取第 8 块的范围
let region = $screen.split(3, 3, 8);
$draw.rect(region); // 绘制该区域
```

### 3.5 强制横竖屏（特殊设备适配）

```javascript
$screen.mustV();       // 强制竖屏截屏
$screen.mustH();       // 强制横屏截屏
$screen.cancelMust();  // 取消强制
```

## 四、$ocr - 文字识别 API

### 4.1 引擎选择

```javascript
// 设置 OCR 引擎（必须在识别前调用）
$ocr.v("mlkit");  // Google ML Kit（默认，准确率高）
$ocr.v("ncnn");   // PaddleOcr（速度快，部分设备兼容性问题）
$ocr.v("ppv5");   // PpOcrV5（2025 新方案，高精度）

// 初始化（可选，会自动初始化）
$ocr.init();
```

### 4.2 识别配置

```javascript
// 灰度化识别配置
let options = {
    region: [0, 0, 200, 100],  // 识别范围 [x, y, w, h]
    gray: true,                 // 开启灰度化
    save: true,                 // 保存识别图片
    savePath: "/sdcard/ocr.png" // 保存路径
};

// 二值化识别配置
let options = {
    region: [0, 0, 200, 100],
    color: "#EEEEEE",    // 文字颜色
    threshold: 20,       // 二值化阈值（推荐 20-50）
    save: true,
    savePath: "/sdcard/ocr.png"
};
```

### 4.3 识别方法

```javascript
// 识别文字并获取位置
let point = $ocr.getPoint("目标文字", options);
if (point != null) {
    $act.click(point);
}

// 识别单行文字
let text = $ocr.line(options);
log("识别结果: " + text);

// 提取数字
let options = {
    region: [0, 0, 200, 100],
    number: true  // 提取数字，用逗号分隔
};
let numbers = $ocr.line(options);

// 完整识别
let result = $ocr.detect(options);
if (result.isSuccess()) {
    // 处理识别结果
}
```

### 4.4 图片识别

```javascript
// 识别本地图片
let result = $ocr.detectPath("/sdcard/test.png");

// 识别图片对象
let img = $img.read("/sdcard/test.png");
let result = $ocr.detectImg(img);

// 识别 Bitmap 对象
let bitmap = img.getBitmap();
let result = $ocr.detectBitmap(bitmap);

// 识别 base64
let base64 = $img.toBase64(img);
let result = $ocr.detect64(base64);
```

### 4.5 高级方法（ncnn/ppv5 专属）

```javascript
// 只识别文字（不检测位置，速度快）
let word = $ocr.onlyRec(img);

// 只检测位置（不识别文字，速度极快）
let result = $ocr.onlyDet(img);
```

## 五、$http - 网络请求 API

### 5.1 基础请求

```javascript
// GET 请求
let response = $http.get("https://api.example.com/data");

// POST 请求（JSON）
let response = $http.post({
    url: "https://api.example.com/upload",
    head: {
        "Content-Type": "application/json",
        "Authorization": "Bearer token"
    },
    data: {
        name: "张三",
        age: 25
    }
});

// POST 请求（表单）
let response = $http.post({
    url: "https://api.example.com/form",
    form: {
        username: "user",
        password: "pass"
    }
});

// POST 请求（文件）
let response = $http.post({
    url: "https://api.example.com/upload",
    form: {
        name: "张三",
        avatar: "/sdcard/avatar.png"  // 文件路径
    }
});
```

### 5.2 其他方法

```javascript
// DELETE
$http.delete({ url: "https://api.example.com/item/1" });

// PUT
$http.put({ url: "https://api.example.com/item/1", data: {...} });

// PATCH
$http.patch({ url: "https://api.example.com/item/1", data: {...} });
```

### 5.3 文件下载

```javascript
$http.download(
    "https://example.com/file.zip",
    "/sdcard/download/file.zip",
    (cur, total, percent) => {
        log("下载进度: " + percent + "%");
    },
    () => {
        log("下载完成");
    },
    (res) => {
        log("下载失败: " + res);
    }
);
```

### 5.4 工具方法

```javascript
// 解析 URI
let uri = $http.uri("smsto:" + $str.uriEncode("13693749475"));

// 获取 WiFi IP
let ip = $http.wifiIp();
```

## 六、$floaty - 悬浮窗 API

### 6.1 权限管理

```javascript
// 检查权限
if ($floaty.hasPermit()) {
    log("有悬浮窗权限");
}

// 获取权限（阻塞式）
$floaty.getPermit();
```

### 6.2 创建悬浮窗

```javascript
// 应用级悬浮窗
let appFloaty = $floaty.newApp("./res/layout/floaty_app.xml");
// 或直接传 XML 字符串
let appFloaty = $floaty.newApp(`<ui>
    <text text="悬浮窗内容" />
</ui>`);

// 系统级悬浮窗（可覆盖导航栏）
let sysFloaty = $floaty.newSys("./res/layout/floaty_sys.xml");

// 可调节悬浮窗
let adjFloaty = $floaty.newAdj("./res/layout/floaty_adj.xml");

// 不可触摸悬浮窗
let floaty = $floaty.newApp("./res/layout/floaty.xml", false);
```

### 6.3 范围选择悬浮窗

```javascript
$floaty.newSelect((rect) => {
    log("用户选择范围: " + rect);
});
```

### 6.4 关闭悬浮窗

```javascript
$floaty.closeAll(); // 关闭所有悬浮窗
```

## 七、$file - 文件系统 API

### 7.1 文件检查

```javascript
$file.exists(path);        // 是否存在
$file.isFile(path);        // 是否是文件
$file.isDir(path);         // 是否是目录
$file.isEmptyDir(path);    // 是否是空目录
$file.isEmpty(path);       // 是否是空文件或目录
```

### 7.2 文件操作

```javascript
// 创建
$file.create(path);        // 创建文件
$file.mkdir(path);         // 创建目录
$file.ensureDir(path);     // 确保目录存在

// 读取
let content = $file.read(path);
let content = $file.read(path, "gbk");  // 指定编码
let lines = $file.reads(path);          // 读取所有行
let bytes = $file.readByte(path);       // 读取字节

// 写入
$file.write(content, path);
$file.write(content, path, "gbk");
$file.writes([line1, line2], path);     // 写入多行

// 追加
$file.add(content, path);
$file.adds([line1, line2], path);

// 拷贝、移动、重命名
$file.copy(src, dest);
$file.move(src, dest);
$file.rename(src, dest);

// 删除
$file.del(path);
```

### 7.3 文件信息

```javascript
let size = $file.size(path);           // 文件大小（字节）
let sizeStr = $file.sizeStr(path);     // 可视化大小（如 "1.5 MB"）
let name = $file.name(path);           // 文件名（含后缀）
let mainName = $file.mainName(path);   // 主文件名（不含后缀）
let ext = $file.ext(path);             // 后缀名
```

### 7.4 目录操作

```javascript
// 罗列文件
let files = $file.ls("res");
let files = $file.ls("res", (path) => {
    return path.endsWith(".js");  // 过滤器
});

// 递归遍历
$file.loopFiles("/res", (file) => {
    log(file.getAbsolutePath());
    return true;  // 继续遍历
});

// 获取系统目录
let videoDir = $file.getDir("视频");
let downloadDir = $file.getDir("下载");
let customDir = $file.getDir("mydir", false);  // 私有目录
```

### 7.5 媒体文件

```javascript
// 罗列视频（需要 $permit.readVideo()）
let videos = $file.lsVideo();

// 罗列音频（需要 $permit.readAudio()）
let audios = $file.lsAudio();

// 罗列图片（需要 $permit.readImage()）
let images = $file.lsImages();
```

### 7.6 热更新

```javascript
// 热更新文件（打包后 APP 使用）
$file.hotUpdate("./main.js", "新的文件内容");

// 删除热更新文件
$file.delHotUpdate("./main.js");
```

## 八、编码规范

### 8.1 异步处理

**规范：所有耗时操作必须使用 async/await 或回调**

```javascript
// ✅ 正确：async/await
async function main() {
    await $act.getPermit();
    await $screen.getPermit();
    let img = await $screen.getScreen();
    // ...
}

// ✅ 正确：回调
$http.download(url, path, 
    (cur, total, percent) => { /* 进度 */ },
    () => { /* 完成 */ },
    (err) => { /* 错误 */ }
);

// ❌ 错误：同步调用异步函数
$act.getPermit();  // 阻塞主线程
```

### 8.2 资源释放

**规范：所有图像资源必须手动释放**

```javascript
// ✅ 正确
let img = $img.read("/sdcard/test.png");
let bitmap = img.getBitmap();
// 使用图片...
img.recycle();  // 释放资源

// ❌ 错误：未释放资源
let img = $img.read("/sdcard/test.png");
// 使用后未调用 recycle()
```

### 8.3 权限检查

**规范：所有需要权限的操作必须先检查权限**

```javascript
// ✅ 正确
if (!$act.hasPermit()) {
    $act.getPermit();
}
if (!$screen.hasPermit()) {
    $screen.getPermit();
}
// 执行操作...

// ❌ 错误：直接调用
$act.click(500, 500);  // 可能因权限不足而失败
```

### 8.4 异常处理

**规范：所有关键操作必须包裹在 try-catch 中**

```javascript
try {
    let node = $act.selector().text("按钮").waitFirst(3000);
    if (node != null) {
        node.click();
    } else {
        log("未找到按钮");
    }
} catch (e) {
    log("操作失败: " + e);
}
```

### 8.5 日志规范

```javascript
// 调试日志
log("调试信息", data);

// 提示日志
toast("提示信息");

// 警告日志
$tip.show("警告", "内容");

// 错误日志
log("错误: " + e);
```

## 九、常见错误对照表

| 错误写法 | 正确写法 | 说明 |
|---------|---------|------|
| `$act.click(500.5, 800.2)` | `$act.click(500, 800)` | 坐标必须为整数 |
| `$act.getPermit()` (UI线程) | `$permit.wza()` | UI 线程不能用阻塞函数 |
| `img` 未释放 | `img.recycle()` | 必须释放图像资源 |
| `$ocr.detect()` 未初始化 | `$ocr.init(); $ocr.detect()` | 需先初始化 |
| `$act.click()` 无权限检查 | `if($act.hasPermit()) {...}` | 必须检查权限 |
