# AutoGOD autogod编码规范技能

## 触发条件

当用户需要编写autogod, AIGame / AutoGOD 脚本、使用 AIGame API（如 `$act`、`$screen`、`$ocr`、`$http`、`$floaty`、`$file` 等）、实现安卓自动化操作、处理图像识别、OCR 文字识别、UI 界面构建、网络请求、文件操作、多线程等任务时使用本技能。

---

## 核心架构

**权限优先级链：ROOT > Shizuku > Accessibility**

所有 `$act` 手势操作均遵循此优先级：先判断 ROOT，有则用 `$root`；否则判断 Shizuku，有则用 `$szk`；最后才用无障碍 Accessibility。

---

## 强制执行流程

### 第一步：读取规范文档

1. 读取 `references/01_autogod-js-api-standard.md` — JavaScript 方言与核心 API 规范
2. 读取 `references/02_autogod-xml-layout-standard.md` — XML 布局语法规范
3. 读取 `references/03_autogod-code-snippets.md` — 纯净代码范式示例
4. 读取 `references/04_autogod-error-correction.md` — 常见错误修正
5. 读取 `references/05_autogod-mandatory-checklist.md` — 强制自检清单

### 第二步：强制自检

在生成代码前，必须完成 `05_autogod-mandatory-checklist.md` 中的所有检查项，并在回复中声明：

```
✅ 已完成强制自检：
- [x] API 调用规范检查
- [x] 权限申请顺序检查
- [x] 异步操作处理检查
- [x] 资源释放检查
- [x] 异常处理检查
```

### 第三步：生成代码

- 严格遵循 `01_autogod-js-api-standard.md` 中的 API 调用规范
- 使用 `03_autogod-code-snippets.md` 中的标准范式
- 确保所有异步操作使用 `async/await` 或回调
- 确保所有资源在使用后正确释放
- 添加必要的异常处理和日志

### 第四步：代码审查

生成代码后，对照 `04_autogod-error-correction.md` 检查常见错误：
- API 名称拼写错误
- 参数类型错误
- 权限缺失
- 资源泄漏
- 异步操作错误

---

## 参考文档

### 规范文档（必读）

| 文件 | 说明 |
|------|------|
| `references/01_autogod-js-api-standard.md` | JavaScript 方言与核心 API 规范 |
| `references/02_autogod-xml-layout-standard.md` | XML 布局语法规范 |
| `references/03_autogod-code-snippets.md` | 纯净代码范式示例 |
| `references/04_autogod-error-correction.md` | 常见错误修正 |
| `references/05_autogod-mandatory-checklist.md` | 强制自检清单 |
| `references/06_autogod-supplement-api.md` | 补充 API 规范（早期版本） |

### API 模块文档（按需查阅）

**新版文档（v3，2026-05-01 官方抓取，中文命名）：** `references/api/$xxx - 中文名.md`  
→ 共 45 个 API 模块文档，命名如 `$floaty - 悬浮窗.md`、`$ui - 界面交互.md`

| 文件 | 模块 | 说明 |
|------|------|------|
| `$act-v2.md` | `$act` | 手势动作（Root/Shizuku/无障碍） |
| `$app-v2.md` | `$app` | 应用操作：启动/安装/卸载/包名查询 |
| `$color-v2.md` | `$color` | 颜色操作：常量/找色/通道解析 |
| `$date-v2.md` | `$date` | 日期工具：格式化/解析/时长 |
| `$device-v2.md` | `$device` | 设备信息：屏幕/电池/音量/内存 |
| `$dialog-v2.md` | `$dialog` | 对话框lib（需加载） |
| `$event-v2.md` | `$event` | 事件监听：系统/无障碍/应用事件 |
| `$file-v2.md` | `$file` | 文件系统：读写/拷贝/移动/媒体库 |
| `$floaty-v2.md` | `$floaty` | 悬浮窗：newApp/newAdj/newSys |
| `$global-v2.md` | `$global` | 全局函数：sleep/alert/log/random |
| `$hid-v2.md` | `$hid` | HID模拟（需ROOT） |
| `$http-v2.md` | `$http` | 网络请求：GET/POST/下载 |
| `$img-v2.md` | `$img` | 图片处理：找图/裁剪/灰度 |
| `$log-v2.md` | `$log` | 日志框架 |
| `$ocr-v2.md` | `$ocr` | 文字识别：ncnn/mlkit/ppv5 |
| `$permit-v2.md` | `$permit` | 权限工具：悬浮窗/无障碍/存储 |
| `$screen-v2.md` | `$screen` | 屏幕操作：截屏/亮度/方向 |
| `$storage-v2.md` | `$storage` | 键值存储 |
| `$str-v2.md` | `$str` | 字符串操作 |
| `$thread-v2.md` | `$thread` | 并发编程：线程/循环器 |
| `$tip-v2.md` | `$tip` | 阻塞对话框：input/one/more/calendar |
| `$touch-v2.md` | `$touch` | ROOT触摸操作 |
| `$tts-v2.md` | `$tts` | 文字转语音 |
| `$ui-v2.md` | `$ui` | 界面对象：layout/show/id/生命周期 |
| `$yolo-v2.md` | `$yolo` | YOLO目标检测 |
| `XView-v2.md` | `XView` | 所有控件/布局的公共父类 |

### UI 框架文档（2026-05-01 新增，2026-05-01 扩充）

位于 `references/ui/`：

**布局（17个）：** absolute-绝对布局, card-卡片布局, const-约束布局, coord-锚点布局, drawer-抽屉布局, expand-展开布局, flow-流式布局, flush-刷新布局, frame-帧布局, grid-网格布局, include-包含布局, layout-布局父类, linear-线性布局, nested-滑动布局, pager-多页布局, relative-相对布局, scroll-滚动布局  
**控件（31个）：** Sheet-底部弹窗, appbar-应用条, button-按钮, button-group-按钮组, check-复选框, chip-小片, chip-group-小片组, drop-下拉框, edit-编辑框, fab-浮动按钮, hr-分割线, img-图片, input-输入框, load-加载, log-日志, ls-列表, nav-导航栏, progress-进度条, radio-单选框, radio-group-单选按钮组, rail-轨道, range-范围, seek-拖动条, slider-滑块, statusbar-状态栏, switch-开关, tab-标签页, text-文本, toolbar-工具栏, video-视频, webview-网页视图  
**示例（27个）：** demo-appbar, demo-button, demo-check, demo-chip, demo-drop, demo-edit, demo-expand, demo-fab, demo-hr, demo-img, demo-input, demo-load, demo-log, demo-nav, demo-pager, demo-progress, demo-radio, demo-rail, demo-range, demo-switch, demo-video, demo-webview, webview-bridge 等  
**补充文档（10个）：** UI框架总览, $ui-界面交互, UI-界面对象, 颜色对照表, 重力对照表, 补充文档, Controls/video-视频, other-color, other-gravity

### 旧版 API 模块文档

27 个旧版 API 参考文件位于 `references/api/` 目录（无 -v2 后缀的文件）：

#### 手势与动作
| 文件 | 模块 | 说明 |
|------|------|------|
| `$act.md` | `$act` | 手势动作（click/press/move/gesture/path） |
| `$root.md` | `$root` | ROOT 权限手势与 Shell 命令 |
| `$szk.md` | `$szk` | Shizuku 免 ROOT 手势/Shell/分辨率控制 |

#### 图色识别
| 文件 | 模块 | 说明 |
|------|------|------|
| `$ag.md` | `$ag` | 图色框架：找图/等图/血条检测/多点找色 |
| `$img.md` | `$img` | 图片处理：裁剪/缩放/旋转/灰度/二值化 |
| `$color.md` | `$color` | 颜色操作：内置常量/找色/通道解析/主题色 |

#### 屏幕与识别
| 文件 | 模块 | 说明 |
|------|------|------|
| `$screen.md` | `$screen` | 屏幕操作：截屏/亮度/方向/分割 |
| `$ocr.md` | `$ocr` | 文字识别：ncnn/mlkit/ppv5 三引擎 |
| `$draw.md` | `$draw` | 全屏绘制：矩形/十字/文字/圆/线/路径 |

#### 文件与存储
| 文件 | 模块 | 说明 |
|------|------|------|
| `$file.md` | `$file` | 文件系统：读写/拷贝/移动/媒体库 |
| `$storage.md` | `$storage` | 应用内键值存储（命名空间） |
| `$res.md` | `$res` | 资源管理器：跨线程存储/导入导出 |

#### 网络与媒体
| 文件 | 模块 | 说明 |
|------|------|------|
| `$http.md` | `$http` | 网络请求：GET/POST/下载 |
| `$media.md` | `$media` | 音频播放（MediaPlayer） |
| `$tts.md` | `$tts` | 文字转语音（TTS） |

#### UI 与交互
| 文件 | 模块 | 说明 |
|------|------|------|
| `$floaty.md` | `$floaty` | 悬浮窗：可调节/应用级/系统级/范围选择 |
| `$tip.md` | `$tip` | 阻塞对话框：输入/选择器/日期时间 |
| `$log.md` | `$log` | 日志框架：分级打印/悬浮窗/日志界面 |

#### 系统与设备
| 文件 | 模块 | 说明 |
|------|------|------|
| `$device.md` | `$device` | 设备信息：屏幕/电池/音量/内存/震动 |
| `$sys.md` | `$sys` | 系统工具：飞行模式/音量/剪切板/保活 |
| `$permit.md` | `$permit` | 权限工具：悬浮窗/无障碍/存储/定位等 |
| `$event.md` | `$event` | 事件监听：系统/无障碍/应用事件 |
| `$engine.md` | `$engine` | 脚本引擎：运行/暂停/停止任务 |

#### 工具与线程
| 文件 | 模块 | 说明 |
|------|------|------|
| `$app.md` | `$app` | 应用操作：启动/安装/卸载/包名查询 |
| `$thread.md` | `$thread` | 并发编程：线程/循环器/倒计时锁 |
| `$str.md` | `$str` | 字符串操作：编码/分割/比较/格式化（80+函数） |
| `$date.md` | `$date` | 日期工具：格式化/解析/时长 |
| `$global.md` | `$global` | 全局函数：无 `$` 前缀直接调用（sleep/alert/log/random 等） |

---

## 常用模式速查

### 权限申请
```javascript
// 无障碍权限（推荐，非阻塞）
$permit.wza();

// 悬浮窗权限
$permit.floaty();

// 获取并等待无障碍（阻塞式，不推荐在 UI 线程）
$act.getPermit();

// 获取 Shizuku 权限
$szk.getPermit();
```

### 找图点击（最常用）
```javascript
// 单图点击（推荐）
let point = $ag.findImgClick({
    path: "/sdcard/close.png",
    region: [0, 0, 500, 500],
    similar: 0.85
});

// 等图出现后再点击
let point = $ag.waitImgClick({
    path: "/sdcard/ready.png",
    waitTimes: 60,
    waitDur: 1000
});

// 循环等图
let point = $ag.waitImg({
    path: "/sdcard/ready.png",
    waitTimes: 60,
    waitDur: 1000
});
if (point) {
    $act.click(point);
}
```

### 截屏 + OCR
```javascript
$screen.getPermit();
let img = $screen.getScreen();

// 指定区域灰度 OCR
let result = $ocr.detect({
    img: img,
    region: [0, 0, 200, 100],
    gray: true
});

// 全量文字识别（默认 mlkit 引擎）
let text = $ocr.v(img);
```

### 找色
```javascript
let img = $screen.getScreen();
let point = $color.find(img, "#a55978", 5, [300, 200, 500, 500]);
if (point) {
    $draw.cross(point);  // 调试标注
    $act.click(point);
}
```

### 悬浮窗
```javascript
$floaty.getPermit();

// 应用级悬浮窗（推荐）
let win = $floaty.newApp({
    w: 200,
    h: 100,
    initX: 100,
    initY: 200
});
win.setText("Hello");

// 关闭所有
$floaty.closeAll();
```

### 应用操作
```javascript
// 启动应用
$app.run("QQ");

// 判断是否安装
if ($app.isInstall("com.example.app")) {
    log("已安装");
}

// 卸载
$app.uninstall("com.example.app");

// 打开应用设置
$app.openAppSetting("AIGame");
```

### 并发任务
```javascript
// 在新线程运行
$thread.run(() => {
    let img = $screen.getScreen();
    $ocr.detect(img);
});

// 定时循环
$thread.loop(() => {
    $ag.waitImgClick({ path: "/sdcard/btn.png" });
}, 3000);  // 每 3 秒执行一次
```

---

## 重要注意事项

| 项目 | 说明 |
|------|------|
| `$act` 优先级 | ROOT > Shizuku > Accessibility |
| `$permit` 权限 | 所有方法只调用一次（内部缓存） |
| OCR 引擎 | ncnn 快但可能混乱；mlkit 准但慢；ppv5 精确 |
| MIUI 限制 | `$draw` 全屏绘制会被拦截，v1.8.0+ ROOT/Szk 可解锁 |
| 安卓 13+ 剪切板 | 获取可能为空或失败，属于正常现象 |
| 打包 APK | 使用 `$engine.run("项目中js路径")` 而非 `runCode(源码)` |
| `getPermit()` | 阻塞方法，不要在 UI 线程调用 |

---

## 快速启动

使用 `assets/quick_start_template.js` 作为项目起点。

---

---

## 📚 官方文档学习库（2026-05-01 建立，持续更新）

从 aigamepro.work 官方文档站抓取，533个文件全量同步到 skill 目录：

**学习库主备份：** `F:\小龙虾文件仓\0.AI技能体\4.技能学习库\autogod\学习结果\`
**Skill 同步目录：** `references/` 下 566 个文件

### references/api/ — API 模块（45个文件）
官方 v3 文档，中文命名 `$xxx-中文名.md` 格式，覆盖全部 API 模块

### references/ui/ — UI 框架（109个文件）
- **布局** (17个): absolute, card, const, coord, drawer, expand, flow, flush, frame, grid, include, layout, linear, nested, pager, relative, scroll
- **控件** (31个): Sheet, appbar, button, button-group, check, chip, chip-group, drop, edit, fab, hr, img, input, load, log, ls, nav, progress, radio, radio-group, rail, range, seek, slider, statusbar, switch, tab, text, toolbar, video, webview
- **示例** (27个): demo-appbar ~ demo-webview
- **补充** (10个): UI框架总览, $ui-界面交互, UI-界面对象, 颜色对照表, 重力对照表, 补充文档, Controls/video 等

### references/examples/ — 代码示例（374个文件）
按模块分类的代码片段，命名格式 `$模块-中文名-序号.标题.txt`

主要模块示例数：$ui(30), $app(24), $permit(19), $tip(19), $event(14), $act(11), $screen(11), $sys(12), $draw(11), $engine(11), $file(12), $bus(10), 脚本语法(27), 其他模块各3-9个

### references/projects/ — 示例项目（30个文件）
- **光源音乐源码**: main.js, create.js, ConfigDialog.js, InsertDialog.js, PlayerFloatyBall.js + xml/res
- **悬浮界面源码**: main.js, run.js, 悬浮球.js, 悬浮窗.js + xml/res/tools + 10个工具脚本
- **开发者后台源码**: index.html 单页应用

### references/docs/ — 参考文档（2个文件）
补充参考资料

### 使用方式
写 AutoGOD 代码时，**先从 references/ 读取对应模块文档**，确认 API 签名后再写。不要凭记忆猜测。
代码示例优先查 `references/examples/$模块-*.txt`，项目级参考查 `references/projects/`。
