# AutoGOD (APICloud) 开发规范

> ⚠️ **警告：AutoGOD 不是 Android 开发！不要使用 Android XML 格式！**

---

## 一、项目结构

```
项目名/
├── src/
│   ├── main.js      # 入口脚本
│   └── main.xml     # 主界面布局
├── lib/
│   ├── *.js         # 功能模块库
│   └── ...
└── README.md
```

---

## 二、XML布局规范 (main.xml)

### 2.1 根节点
```xml
<ui>
    <!-- 布局内容 -->
</ui>
```

### 2.2 布局容器

| 标签 | 说明 | 关键属性 |
|------|------|----------|
| `<linear>` | 线性布局 | `dir="v"` 垂直, `dir="h"` 水平 |
| `<frame>` | 绝对布局/帧布局 | 无方向 |
| `<list>` | 列表布局 | `items`, `select` |

### 2.3 尺寸属性

| 属性 | 说明 | 示例 |
|------|------|------|
| `w` | 宽度 | `"wrap"`, `"max"`, `"0dp"`, `"200dp"` |
| `h` | 高度 | `"wrap"`, `"max"`, `"40dp"`, `"200dp"` |
| `weight` | 权重 | `"1"`, `"2"` |

### 2.4 布局属性

| 属性 | 说明 | 示例 |
|------|------|------|
| `margin` | 外边距 | `"8"` 或 `"8,16"` |
| `marginTop` | 上边距 | `"16"` |
| `marginLeft` | 左边距 | `"8"` |
| `marginRight` | 右边距 | `"8"` |
| `marginBottom` | 下边距 | `"8"` |
| `padding` | 内边距 | `"16"` |
| `gravity` | 重心 | `"center"`, `"left"`, `"right"` |

### 2.5 组件属性

| 属性 | 说明 | 示例 |
|------|------|------|
| `id` | 组件ID | `"btn1"`, `"inputName"` |
| `bg` | 背景色 | `"#FFFFFF"`, `"#4CAF50"` |
| `textColor` | 文字颜色 | `"#000000"`, `"#FFFFFF"` |
| `textSize` | 文字大小 | `"16"`, `"18"` |
| `visibility` | 可见性 | `"visible"`, `"gone"`, `"hidden"` |

---

## 三、组件标签

### 3.1 按钮
```xml
<button id="btn1" text="点击" bg="#4CAF50" textColor="#FFFFFF" textSize="16" />
```

### 3.2 文本
```xml
<text text="标签:" textSize="16" textColor="#333333" />
```

### 3.3 输入框
```xml
<input id="input1" hint="请输入" type="text" />
```
- `type`: `text`, `number`, `password`

### 3.4 下拉框
```xml
<drop id="drop1" items="选项1,选项2,选项3" select="0" />
```

### 3.5 图片
```xml
<img id="img1" src="widget://image/logo.png" />
```

### 3.6 复选框
```xml
<checkbox id="check1" text="同意协议" checked="true" />
```

### 3.7 工具栏
```xml
<toolbar id="mainToolbar" title="标题" bg="#1976D2" textColor="#FFFFFF" />
```

### 3.8 AppBar（必须添加，消除全局脚本警告）
```xml
<appbar id="mAppbar" w="max" />
```

---

## 四、JavaScript API (main.js)

### 4.1 入口函数
```javascript
var ui = $ui.layout("main.xml");
ui.show();

// 初始化代码...
```

### 4.2 组件获取
```javascript
var btn = ui.id("btnId");      // 通过ID获取组件
var input = ui.id("inputId");
```

### 4.3 组件操作

| 操作 | 代码 |
|------|------|
| 获取文本 | `input.text()` 或 `input.getText()` |
| 设置文本 | `input.text("内容")` 或 `input.setText("内容")` |
| 获取选中项 | `drop.getSelect()` → 返回索引 `0,1,2...` |
| 设置选中项 | `drop.setSelect(1)` |

### 4.4 视图操作

| 操作 | 代码 |
|------|------|
| 显示组件 | `view.setVisibility($ui.VISIBLE)` |
| 隐藏组件 | `view.setVisibility($ui.GONE)` |
| 添加视图 | `container.addView(view)` |
| 移除视图 | `view.remove()` |
| 清除子视图 | `container.removeAll()` |

### 4.5 动态创建视图（重要！）

```javascript
// ❌ 错误方式 - $ui.create() 不存在！
// var textView = $ui.create("text");

// ✅ 正确方式 - 使用 $ui.layout() 传入XML模板字符串
let itemUi = $ui.layout(`
<ui>
    <text id="label" text="动态文本" w="100" h="50" bg="#4CAF50" />
</ui>
`);
let textView = itemUi.id("label");
container.addView(textView);

// 动态属性示例
var x = 100;
var lineUi = $ui.layout(`<ui><view id="vLine" w="1" h="500" marginLeft="` + x + `" /></ui>`);
var vLine = lineUi.id("vLine");
container.addView(vLine);

// ⚠️ 注意：视图被添加到容器后，不能再添加到其他容器（安卓机制）
// 如果需要重复添加，必须每次重新用 $ui.layout() 创建新的视图
```

### 4.6 屏幕尺寸获取
```javascript
var screenWidth = $screen.getWidth();   // 屏幕宽度
var screenHeight = $screen.getHeight(); // 屏幕高度
```

### 4.7 事件绑定

```javascript
// 按钮点击
ui.id("btn").click(function() {
    // 处理点击
});

// 下拉框选择变化
ui.id("drop").onCheck(function(value, index) {
    // index: 0, 1, 2...
});

// 点击事件（带坐标）
touchLayer.click(function(e) {
    var x = e.x;
    var y = e.y;
});
```

### 4.8 定时器
```javascript
// 延迟执行
setTimeout(function() {
    // 代码
}, 1000);

// 循环执行
var intervalId = setInterval(function() {
    // 代码
}, 1000);

// 停止循环
clearInterval(intervalId);
```

---

## 五、悬浮窗 (floaty)

### 5.1 创建系统级悬浮窗
```javascript
// ⚠️ 注意：必须使用 $floaty.newSys()，不是 $floaty.window() 或 $floaty.newApp()！
var floaty = $floaty.newSys(`
<ui>
<frame w="200dp" h="300dp" bg="#FFFFFF">
<linear dir="v" w="max" h="max" gravity="center">
<text text="悬浮窗内容" textSize="16" />
</linear>
</frame>
</ui>
`);
floaty.setXY(100, 200);  // 设置位置
floaty.setWH(200, 300);  // 设置宽高
```

### 5.2 获取控件
```javascript
var btn = floaty.id("btnId");
btn.click(function() {
    // 处理点击
});
```

### 5.3 关闭悬浮窗
```javascript
floaty.close();
```

### 5.4 隐藏悬浮窗（不销毁）
```javascript
floaty.setXY(-2000, -2000);  // 移出屏幕
```

---

## 六、文件操作

### 6.1 路径操作
```javascript
// 拼接路径
var filePath = $file.join($file.sd(), "folder", "file.txt");

// 判断是否是目录
var isDir = $file.isDir("path/to/folder");

// 创建目录
$file.mkDir("path/to/folder");

// 列出目录文件
var files = $file.listDir("path/to/folder");

// 判断文件存在
var exists = $file.exist("path/to/file.txt");
```

### 6.2 读取文件
```javascript
var content = $file.read("path/to/file.txt");
```

### 6.3 写入文件（参数顺序：内容在前，路径在后！）
```javascript
// ⚠️ 参数顺序：content 在前，path 在后
$file.write("文件内容", "path/to/file.txt");

// JSON数据
$file.write(JSON.stringify(data), filePath);
```

---

## 七、输入操作

### 7.1 触摸操作
```javascript
// 点击
$input.tap(x, y);

// 长按
$input.longPress(x, y, duration);

// 滑动
$input.swipe(startX, startY, endX, endY, duration);
```

---

## 八、Toast提示

```javascript
toast("提示内容");
```

---

## 九、常用颜色

| 颜色 | 值 | 说明 |
|------|-----|------|
| 白色 | `#FFFFFF` | 背景/文字 |
| 黑色 | `#000000` | 文字 |
| 绿色 | `#4CAF50` | 成功/确定 |
| 蓝色 | `#2196F3` | 信息/链接 |
| 红色 | `#F44336` | 错误/取消 |
| 橙色 | `#FF9800` | 警告 |
| 灰色 | `#9E9E9E` | 禁用 |
| 浅灰 | `#F5F5F5` | 背景 |

---

## 十、常见错误

### ❌ 错误示例
```xml
<!-- Android XML 格式 - 错误！ -->
<LinearLayout 
    android:layout_width="match_parent"
    android:orientation="vertical">
</LinearLayout>
```

### ✅ 正确示例
```xml
<!-- AutoGOD XML 格式 - 正确！ -->
<linear dir="v" w="max" h="wrap">
</linear>
```

### ❌ 其他常见错误
```javascript
// ❌ 错误 - $ui.create() 不存在
var view = $ui.create("view");

// ❌ 错误 - 参数顺序错误
$file.write(filePath, content);

// ❌ 错误 - 使用Android API
$device.info.screen.width;

// ❌ 错误 - visibility属性在XML中不生效
<text visibility="gone" />  // 无效！
```

### ✅ 正确写法
```javascript
// ✅ 正确 - 使用$ui.layout()
var view = $ui.layout(`<ui><view id="v" w="100" /></ui>`).id("v");

// ✅ 正确 - $file.write(content, path)
$file.write(content, filePath);

// ✅ 正确 - 屏幕尺寸
$screen.getWidth();

// ✅ 正确 - JS控制可见性
view.setVisibility($ui.GONE);
```

---

## 十一、注意事项

1. **不要混淆**：AutoGOD ≠ Android ≠ Web ≠ HTML ≠ Android XML
2. **属性名不同**：`layout_width` → `w`, `orientation` → `dir`
3. **大小写敏感**：JavaScript区分大小写
4. **ID唯一性**：同一界面中ID不能重复
5. **必须加`<appbar id="mAppbar"/>`**：消除全局脚本警告
6. **动态创建视图**：必须用 `$ui.layout()` 模板字符串

---

## 十二、踩坑记录

### 1. `$ui.create()` 不存在
- **问题**：运行时提示"找不到函数 create"
- **解决**：使用 `$ui.layout()` 传入XML模板字符串

### 2. `$file.write()` 参数顺序
- **问题**：文件写入失败
- **解决**：参数顺序是 `$file.write(content, path)`，内容在前

### 3. `mAppbar` 未找到控件
- **问题**：运行时提示"未找到控件:mAppbar"
- **解决**：在XML中添加 `<appbar id="mAppbar" w="max" />`

### 4. XML中 `visibility="gone"` 无效
- **问题**：组件依然显示
- **解决**：用JS控制 `view.setVisibility($ui.GONE)`

### 5. 屏幕尺寸获取
- **错误**：`$device.info.screen.width`
- **正确**：`$screen.getWidth()`

### 6. 弹窗层无法显示（重要！）
- **问题**：frame 弹窗 setVisibility($ui.VISIBLE) 后不显示
- **原因**：缺少外层 frame 容器
- **解决**：必须将所有内容放在外层 frame 中

```xml
<!-- ❌ 错误结构 -->
<ui>
    <linear id="main">主界面</linear>
    <frame id="dialog">弹窗</frame>
</ui>

<!-- ✅ 正确结构 -->
<ui>
    <frame w="max" h="max">
        <linear id="main">主界面</linear>
        <frame id="dialog" layout_gravity="center">弹窗</frame>
    </frame>
</ui>
```

### 7. drop 下拉框没有 setSelect 方法
- **问题**：运行时提示"找不到函数 setSelect"
- **解决**：使用 `select="0"` 在 XML 中设置默认选中项

### 8. 悬浮窗必须使用 $floaty.newSys()
- **问题**：用 frame 作为弹窗只能在当前页面显示
- **解决**：使用 `$floaty.newSys(xmlString)` 创建真正的系统级悬浮窗
- **注意**：floaty 是全局 API，TS 会提示未定义但运行正常

```javascript
// ✅ 正确：使用 $floaty.newSys()
var floatyWindow = $floaty.newSys(`<ui>
    <frame w="wrap" h="wrap" bg="#80000000">
        <linear dir="v" w="300dp" h="wrap" bg="#FFFFFF" padding="16">
            <text text="标题" />
            <button id="btnClose" text="关闭" />
        </linear>
    </frame>
</ui>`);

// 设置位置 - 使用 setXY 不是 setPosition！
floatyWindow.setXY(100, 200);
// 或单独设置
floatyWindow.setX(100);
floatyWindow.setY(200);

// 获取控件
floatyWindow.id("btnClose").click(function() {
    floatyWindow.close();
});

// 设置触摸 - 使用 touch() 不是 setTouchable()！
floatyWindow.touch(true);   // 可触摸
floatyWindow.touch(false);  // 不可触摸

// ❌ 错误：用 frame 作为弹窗
// <frame id="dialog" ...> 只能在页面内显示
```

---

> 📅 更新时间：2026-05-03
> 📁 备份位置：F:\小龙虾文件仓\0.AI技能体\4.技能学习库\autogod\autogod
