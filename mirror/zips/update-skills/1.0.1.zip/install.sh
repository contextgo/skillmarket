#!/bin/bash

# UpdateSkills 技能安装脚本

echo "🔄 UpdateSkills - 技能更新检查助手"
echo "=================================="
echo ""

# 1. 复制技能到 skills 目录
echo "📦 正在安装技能..."
SKILLS_DIR="$HOME/.openclaw/workspace/skills"

if [ ! -d "$SKILLS_DIR" ]; then
    echo "❌ 错误：未找到 OpenClaw skills 目录"
    echo "请确认 OpenClaw 已正确安装"
    exit 1
fi

# 备份旧版本（如果存在）
if [ -d "$SKILLS_DIR/UpdateSkills" ]; then
    echo "⚠️  发现旧版本，正在备份..."
    mv "$SKILLS_DIR/UpdateSkills" "$SKILLS_DIR/UpdateSkills.old.$(date +%Y%m%d%H%M%S)"
fi

# 复制新技能
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR" "$SKILLS_DIR/"

echo "✅ 技能已复制到 $SKILLS_DIR/UpdateSkills"
echo ""

# 2. 询问是否设置定时检查
echo "⏰ 是否设置定时检查？"
echo "   1) 每天上午 9 点检查（推荐）"
echo "   2) 每周一上午 9 点检查"
echo "   3) 不设置定时检查"
echo ""
read -p "请选择 [1/2/3]: " choice

case $choice in
    1)
        echo ""
        echo "📅 设置每天上午 9 点检查..."
        openclaw cron add '{
          "name": "每日技能更新检查",
          "schedule": {"kind": "cron", "expr": "0 9 * * *", "tz": "Asia/Shanghai"},
          "payload": {"kind": "systemEvent", "text": "检查技能更新"},
          "sessionTarget": "current"
        }'
        if [ $? -eq 0 ]; then
            echo "✅ 已设置每天上午 9 点自动检查"
        else
            echo "⚠️  cron 设置失败，可以稍后手动设置"
        fi
        ;;
    2)
        echo ""
        echo "📅 设置每周一上午 9 点检查..."
        openclaw cron add '{
          "name": "每周技能更新检查",
          "schedule": {"kind": "cron", "expr": "0 9 * * 1", "tz": "Asia/Shanghai"},
          "payload": {"kind": "systemEvent", "text": "检查技能更新"},
          "sessionTarget": "current"
        }'
        if [ $? -eq 0 ]; then
            echo "✅ 已设置每周一上午 9 点自动检查"
        else
            echo "⚠️  cron 设置失败，可以稍后手动设置"
        fi
        ;;
    3)
        echo "⏭️  跳过定时检查设置"
        ;;
    *)
        echo "❌ 无效选择，跳过定时检查设置"
        ;;
esac

echo ""

# 3. 重启 Gateway
echo "🔄 需要重启 Gateway 使技能生效"
read -p "是否现在重启？[Y/n]: " restart_choice

case $restart_choice in
    [Yy]*|"")
        echo "🔄 正在重启 Gateway..."
        openclaw gateway restart
        echo "✅ Gateway 已重启"
        ;;
    [Nn]*)
        echo "⏭️  跳过重启，请稍后手动执行：openclaw gateway restart"
        ;;
esac

echo ""
echo "=================================="
echo "✨ 安装完成！"
echo ""
echo "使用方式："
echo "  - 检查更新：检查技能更新"
echo "  - 批量更新：批量更新所有技能"
echo "  - 查看 cron：openclaw cron list"
echo ""
