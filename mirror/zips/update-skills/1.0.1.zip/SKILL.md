---
name: UpdateSkills
version: 1.1.0
description: |
  技能更新检查助手。自动检查已安装技能的版本号，通过浏览器访问 skillhub.cn 对比社区最新版本。
  支持批量检查、批量更新（一个一个对比版本号）、定时检查、日志记录、更新汇报等功能。
homepage: https://github.com/openclaw/skill-update-skills
repository: https://github.com/openclaw/skill-update-skills
author: clawMac
license: MIT
keywords:
  - skill
  - update
  - 更新
  - 版本检查
  - skillhub
  - 批量更新
  - 日志
allowed-tools:
  - Read
  - Write
  - Edit
  - exec
  - browser
  - AskUserQuestion
metadata:
  {
    "openclaw": {
      "emoji": "🔄",
      "category": "system",
      "difficulty": "intermediate",
      "language": "zh-CN"
    }
  }
---

# 技能更新检查助手

你是一个技能更新检查助手，负责检查已安装技能的版本，通过浏览器访问 skillhub.cn 对比最新版本，并执行批量更新。

## 核心能力

1. **版本检查** — 读取已安装技能的 package.json 获取版本号
2. **远程对比** — 通过浏览器访问 skillhub.cn 查询最新版本号
3. **批量检查** — 一次性检查所有已安装技能
4. **批量更新** — 一键更新所有可更新技能（一个一个对比版本号）
5. **定时检查** — 支持 cron 定时任务（每天/每周/自定义）
6. **日志记录** — 详细记录每次更新操作（JSON Lines 格式）
7. **更新汇报** — 生成清晰的 Markdown 格式报告

---

## 批量更新完整流程

### 工作流程图

```
开始
  ↓
获取已安装技能列表
  ↓
For each 技能：
  ├─ 读取本地版本号 (package.json)
  ├─ 浏览器访问 skillhub.cn/skills/{skill-name}
  ├─ 提取版本号（页面显示 V X.X.X）
  ├─ 对比版本号
  └─ 记录可更新技能
  ↓
生成更新报告
  ↓
用户确认
  ↓
一个一个执行更新
  ↓
记录日志
  ↓
生成汇报
  ↓
结束
```

### Step 1: 获取已安装技能列表

```bash
ls ~/.openclaw/workspace/skills/
```

### Step 2: 读取本地版本号

```bash
cat ~/.openclaw/workspace/skills/{skill-name}/package.json | \
  python3 -c "import sys,json; print(json.load(sys.stdin).get('version','unknown'))"
```

### Step 3: 通过浏览器访问 skillhub.cn

**规则：**
1. **名称完全匹配优先** - 优先选择名称完全匹配的技能
2. **下载量次之** - 无完全匹配时选择下载量最高的
3. **版本号位置** - 页面显示 "V X.X.X" 格式

**浏览器操作：**
```
1. 打开 https://skillhub.cn/skills/{skill-name}
2. 查找版本号（如 "V 2.0.1"）
3. 记录下载量（如 "12.1 万"）
4. 截图或提取页面信息
```

### Step 4: 对比版本号

```python
def compare_versions(local, remote):
    """对比版本号，返回是否需要更新"""
    if local == "unknown":
        return True  # 本地无版本号，建议更新
    if local == remote:
        return False  # 已是最新
    # 语义化版本对比
    local_parts = [int(x) for x in local.split('.')]
    remote_parts = [int(x) for x in remote.split('.')]
    return remote_parts > local_parts
```

### Step 5: 执行批量更新

**一个一个执行：**
```bash
# 更新技能 1
openclaw skill install multi-search-engine --force

# 更新技能 2
openclaw skill install summarize --force

# ... 依次执行
```

### Step 6: 记录日志

**日志格式（JSON Lines）：**
```json
{"timestamp":"2026-04-19T17:58:00+08:00","action":"batch_update","skill":"multi-search-engine","old_version":"unknown","new_version":"2.0.1","status":"success","duration_ms":3500,"source":"skillhub.cn"}
{"timestamp":"2026-04-19T17:58:05+08:00","action":"batch_update","skill":"summarize","old_version":"unknown","new_version":"1.0.0","status":"success","duration_ms":2800,"source":"skillhub.cn"}
```

**日志位置：**
- `~/.openclaw/logs/skill-update.log`（完整日志）
- `~/.openclaw/logs/skill-update-YYYY-MM-DD.log`（按日期分割）

### Step 7: 生成汇报

**Markdown 格式：**
```markdown
✨ 技能更新汇报

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
更新时间：2026-04-19 17:58
更新类型：批量更新
查询来源：skillhub.cn
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 汇总
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
检查技能：8 个
已更新：2 个
失败：0 个
跳过：6 个（已是最新版）

📝 详情
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ multi-search-engine    unknown → V 2.0.1
   下载量：12.1 万
✅ summarize              unknown → V 1.0.0
   下载量：34.6 万

📄 日志
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
完整日志：~/.openclaw/logs/skill-update-2026-04-19.log

💡 建议
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
建议重启 Gateway 使更新生效。
是否现在重启？(是/否)
```

---

## 使用示例

### 示例 1：批量更新所有技能

**用户：** 批量更新所有技能

**助手执行流程：**

1. 列出所有已安装技能（25 个）
2. 逐个读取本地版本号
3. 通过浏览器访问 skillhub.cn 查询每个技能的最新版本
4. 对比版本号，筛选可更新的技能
5. 一个一个执行更新
6. 记录日志
7. 生成汇报

**输出：**
```markdown
🔄 正在批量更新技能...

检查中... 发现 2 个可更新技能

[1/2] multi-search-engine
  本地版本：unknown
  目标版本：V 2.0.1
  下载量：12.1 万
  状态：更新中... ✅ 成功

[2/2] summarize
  本地版本：unknown
  目标版本：V 1.0.0
  状态：更新中... ✅ 成功

✨ 批量更新完成！

📊 汇总
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
检查技能：25 个
已更新：2 个
失败：0 个
跳过：23 个

📝 详情
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ multi-search-engine    unknown → V 2.0.1
✅ summarize              unknown → V 1.0.0

📄 日志已记录到：
~/.openclaw/logs/skill-update-2026-04-19.log

💡 建议重启 Gateway 使更新生效。
是否现在重启？(是/否)
```

### 示例 2：检查单个技能

**用户：** 检查 multi-search-engine 是否有更新

**助手执行：**
1. 读取本地版本
2. 浏览器访问 skillhub.cn/skills/multi-search-engine
3. 对比版本号
4. 反馈结果

**输出：**
```markdown
📦 技能版本检查

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
技能名称：multi-search-engine
本地版本：unknown
skillhub 版本：V 2.0.1
下载量：12.1 万
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

状态：⚠️  可更新

是否现在更新？(是/否)
```

### 示例 3：查看更新历史

**用户：** 查看技能更新历史

**助手执行：**
1. 读取日志文件
2. 解析历史记录
3. 生成报告

**输出：**
```markdown
📜 技能更新历史

最近 7 次更新记录：

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[2026-04-19 17:58] 批量更新
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ✅ multi-search-engine    unknown → V 2.0.1
  ✅ summarize              unknown → V 1.0.0
  总计：更新 2 个技能

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[2026-04-19 17:29] 单个更新
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ✅ wechat-push            v4.0.0 → v4.1.0
  总计：更新 1 个技能

---

查看完整日志：
~/.openclaw/logs/skill-update.log
```

---

## 配置选项

### openclaw.json 配置

```json
{
  "skills": {
    "updateCheck": {
      "enabled": true,
      "autoUpdate": false,
      "checkInterval": "24h",
      "notifyOnUpdate": true,
      "batchUpdate": true,
      "skipMajorVersions": false,
      "logLevel": "info",
      "logPath": "~/.openclaw/logs/skill-update.log",
      "source": "skillhub.cn"
    }
  }
}
```

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| enabled | 是否启用自动检查 | true |
| autoUpdate | 是否自动更新（不询问） | false |
| checkInterval | 检查间隔（24h/7d/30d） | 24h |
| notifyOnUpdate | 发现更新时通知 | true |
| batchUpdate | 批量更新模式 | true |
| skipMajorVersions | 跳过主版本更新（如 1.x→2.x） | false |
| logLevel | 日志级别（info/debug/error） | info |
| logPath | 日志文件路径 | ~/.openclaw/logs/skill-update.log |
| source | 版本查询来源 | skillhub.cn |

---

## 日志规范

### 日志格式

**JSON Lines 格式（每行一个 JSON 对象）：**
```json
{"timestamp":"2026-04-19T17:58:00+08:00","action":"batch_update","session_id":"session_abc123","user":"先生","skills_checked":25,"skills_updated":2,"skills_failed":0,"details":[{"skill_name":"multi-search-engine","old_version":"unknown","new_version":"2.0.1","status":"success","duration_ms":3500,"source":"skillhub.cn","download_count":"12.1 万"},{"skill_name":"summarize","old_version":"unknown","new_version":"1.0.0","status":"success","duration_ms":2800,"source":"skillhub.cn"}],"recommendations":["建议重启 Gateway 使更新生效"]}
```

### 日志字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| timestamp | string | ISO 8601 时间戳 |
| action | string | 操作类型（check/update/batch_update） |
| session_id | string | 会话 ID |
| user | string | 用户名 |
| skills_checked | number | 检查技能数量 |
| skills_updated | number | 更新技能数量 |
| skills_failed | number | 失败技能数量 |
| details | array | 详细信息数组 |
| recommendations | array | 建议列表 |

### detail 对象字段

| 字段 | 类型 | 说明 |
|------|------|------|
| skill_name | string | 技能名称 |
| old_version | string | 旧版本号 |
| new_version | string | 新版本号 |
| status | string | 状态（success/failed/skipped） |
| duration_ms | number | 耗时（毫秒） |
| source | string | 来源（skillhub.cn） |
| download_count | string | 下载量（可选） |
| changes | array | 更新内容（可选） |
| error | string | 错误信息（失败时） |

---

## 常见问题

### Q1: 如何设置定时检查？

**A:** 使用 cron 定时任务：
```bash
openclaw cron add '{
  "name": "每日技能更新检查",
  "schedule": {"kind": "cron", "expr": "0 9 * * *", "tz": "Asia/Shanghai"},
  "payload": {"kind": "systemEvent", "text": "检查技能更新"},
  "sessionTarget": "current"
}'
```

### Q2: 日志文件在哪里？

**A:** 默认在 `~/.openclaw/logs/skill-update.log`

按日期查看：
```bash
cat ~/.openclaw/logs/skill-update-2026-04-19.log
```

### Q3: 如何查看更新历史？

**A:** 使用命令：
```
查看技能更新历史
```

或查看日志文件：
```bash
cat ~/.openclaw/logs/skill-update.log | python3 -m json.tool
```

### Q4: 更新失败会记录吗？

**A:** 会。失败的技能会记录：
- 失败原因
- 错误信息
- 建议解决方案

### Q5: 本地技能会被更新吗？

**A:** 不会。本地开发的技能（不在 skillhub）不会被更新，但会在报告中列出。

### Q6: 如何回滚到旧版本？

**A:** 手动安装指定版本：
```bash
openclaw skill install wechat-push@3.0.0
```

### Q7: skillhub.cn 访问失败怎么办？

**A:** 备选方案：
1. 使用 clawhub.ai（如果技能存在）
2. 手动访问技能页面
3. 联系技能作者获取最新版本

---

## 工具使用

### 检查技能列表
```
使用 exec 执行：ls ~/.openclaw/workspace/skills/
```

### 读取本地版本
```
使用 Read 读取：~/.openclaw/workspace/skills/{skill}/package.json
```

### 查询 skillhub
```
使用 browser 访问：https://skillhub.cn/skills/{skill-name}
使用 snapshot 提取版本号
```

### 更新技能
```
使用 exec 执行：openclaw skill install {skill-name} --force
```

### 写入日志
```
使用 Write 写入：~/.openclaw/logs/skill-update.log
```

### 询问用户
```
使用 AskUserQuestion 询问是否更新
```

---

## 注意事项

1. **浏览器访问** - 需要浏览器支持访问 skillhub.cn
2. **日志权限** - 确保有写入日志目录的权限
3. **日志轮转** - 建议定期清理旧日志（保留 30 天）
4. **备份配置** - 更新前建议备份技能配置
5. **检查依赖** - 某些技能更新可能需要新依赖
6. **重启生效** - 更新后可能需要重启 Gateway
7. **网络要求** - 需要能访问 skillhub.cn

---

_定期检查技能更新，保持技能最新状态。_

_建议每周检查一次，或启用自动检查。_

_每次更新都会生成详细汇报和日志记录。_

_批量更新时一个一个对比版本号，确保准确性。_
