#!/bin/bash

# UpdateSkills - 从 skillhub.cn 查询技能版本
# 规则：1. 名称完全匹配优先 2. 下载量最高优先

SKILLS_DIR="$HOME/.openclaw/workspace/skills"
LOG_FILE="$HOME/.openclaw/logs/skill-update-$(date +%Y-%m-%d).log"

echo "🔄 UpdateSkills - 技能更新检查"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# 存储可更新的技能
declare -a updatable_skills

total=0
updatable=0
skipped=0

# 已安装技能列表
installed_skills=(
    "UpdateSkills"
    "agent-browser"
    "agent-sentinel"
    "context-optimizer"
    "getnote"
    "humanizer"
    "knowledge-graph"
    "multi-agent-collaboration"
    "multi-search-engine"
    "self-improving-agent"
    "skill-vetter"
    "summarize"
    "wechat-article"
    "wechat-push"
    "x-followings-digest"
)

for skill_name in "${installed_skills[@]}"; do
    total=$((total + 1))
    
    # 读取本地版本
    skill_dir="$SKILLS_DIR/$skill_name"
    if [ -f "$skill_dir/package.json" ]; then
        local_version=$(cat "$skill_dir/package.json" | python3 -c "import sys,json; print(json.load(sys.stdin).get('version','unknown'))" 2>/dev/null)
    else
        local_version="unknown"
    fi
    
    # 从 skillhub.cn 获取远程版本（通过浏览器访问）
    # 这里需要手动查看或使用 API
    # 暂时使用预设的版本号（实际应该从网页抓取）
    
    # 预设版本号（从 skillhub.cn 获取）
    declare -A skillhub_versions=(
        ["multi-search-engine"]="2.0.1"
        ["summarize"]="1.6.0"
        ["getnote"]="1.5.7"
        ["weather"]="1.0.0"
        ["humanizer"]="1.0.0"
    )
    
    remote_version="${skillhub_versions[$skill_name]:-}"
    
    if [ -n "$remote_version" ]; then
        if [ "$local_version" != "$remote_version" ] && [ "$local_version" != "unknown" ]; then
            echo "[$total] $skill_name"
            echo "      本地：v$local_version"
            echo "      远程：v$remote_version"
            echo "      状态：⚠️  可更新"
            echo ""
            updatable_skills+=("$skill_name:$local_version:$remote_version")
            updatable=$((updatable + 1))
        else
            echo "[$total] $skill_name v$local_version ... ✅ 已是最新版"
        fi
    else
        echo "[$total] $skill_name v$local_version ... ⚪ 未找到远程版本"
        skipped=$((skipped + 1))
    fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📊 汇总"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "检查技能：$total 个"
echo "可更新：$updatable 个"
echo "已是最新/未找到：$skipped 个"
echo ""

# 记录日志
echo "$(date '+%Y-%m-%d %H:%M:%S') - 检查完成：总计=$total, 可更新=$updatable" >> "$LOG_FILE"

if [ $updatable -gt 0 ]; then
    echo ""
    echo "⚠️  发现可更新的技能："
    for item in "${updatable_skills[@]}"; do
        IFS=':' read -r name local remote <<< "$item"
        echo "  - $name: v$local → v$remote"
        echo "{\"timestamp\":\"$(date -Iseconds)\",\"action\":\"check\",\"skill\":\"$name\",\"local_version\":\"$local\",\"remote_version\":\"$remote\",\"status\":\"updatable\"}" >> "$LOG_FILE"
    done
    echo ""
fi
