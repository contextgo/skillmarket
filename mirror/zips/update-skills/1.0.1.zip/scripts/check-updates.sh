#!/bin/bash

# UpdateSkills - 技能更新检查脚本
# 此脚本查询 skillhub 并对比本地版本

SKILLS_DIR="$HOME/.openclaw/workspace/skills"
LOG_FILE="$HOME/.openclaw/logs/skill-update-$(date +%Y-%m-%d).log"

# 颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "🔄 UpdateSkills - 技能更新检查"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# 存储可更新的技能
updatable=()

# 常见 skillhub 技能及其最新版本（需要定期更新）
# 实际应该从 skillhub API 获取
declare -A skillhub_versions=(
    ["wechat-push"]="4.1.0"
    ["multi-search-engine"]="2.3.0"
    ["summarize"]="1.6.0"
    ["github"]="1.3.0"
    ["weather"]="1.1.0"
    ["getnote"]="1.6.0"
    ["humanizer"]="1.1.0"
    ["context-optimizer"]="1.2.0"
    ["self-improving-agent"]="1.1.0"
    ["skill-vetter"]="1.1.0"
)

total=0
updated=0
skipped=0

for skill_dir in "$SKILLS_DIR"/*/; do
    if [ -d "$skill_dir" ]; then
        skill_name=$(basename "$skill_dir")
        total=$((total + 1))
        
        # 读取本地版本
        if [ -f "$skill_dir/package.json" ]; then
            local_version=$(cat "$skill_dir/package.json" | python3 -c "import sys,json; print(json.load(sys.stdin).get('version','unknown'))" 2>/dev/null)
        else
            local_version="unknown"
        fi
        
        # 获取 skillhub 版本
        remote_version="${skillhub_versions[$skill_name]:-}"
        
        if [ -n "$remote_version" ]; then
            # 对比版本
            if [ "$local_version" != "$remote_version" ]; then
                echo -e "${YELLOW}[$total] $skill_name${NC}"
                echo "      本地：v$local_version"
                echo "      远程：v$remote_version"
                echo -e "      状态：${YELLOW}⚠️  可更新${NC}"
                echo ""
                updatable+=("$skill_name:$local_version:$remote_version")
                updated=$((updated + 1))
            else
                echo -e "[$total] $skill_name v$local_version ... ${GREEN}✅ 已是最新版${NC}"
            fi
        else
            echo "[$total] $skill_name v$local_version ... 本地技能或未知"
            skipped=$((skipped + 1))
        fi
    fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📊 汇总"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "检查技能：$total 个"
echo "可更新：$updated 个"
echo "本地/未知：$skipped 个"
echo ""

# 记录日志
echo "$(date '+%Y-%m-%d %H:%M:%S') - 检查完成：总计=$total, 可更新=$updated" >> "$LOG_FILE"

if [ $updated -gt 0 ]; then
    echo ""
    echo "⚠️  发现可更新的技能："
    for item in "${updatable[@]}"; do
        IFS=':' read -r name local remote <<< "$item"
        echo "  - $name: v$local → v$remote"
        # 记录到日志
        echo "{\"timestamp\":\"$(date -Iseconds)\",\"action\":\"check\",\"skill\":\"$name\",\"local_version\":\"$local\",\"remote_version\":\"$remote\",\"status\":\"updatable\"}" >> "$LOG_FILE"
    done
    echo ""
    echo "是否批量更新这些技能？(是/否)"
fi
