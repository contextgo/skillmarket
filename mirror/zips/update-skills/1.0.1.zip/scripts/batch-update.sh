#!/bin/bash

# UpdateSkills - 批量更新脚本
# 通过浏览器访问 skillhub.cn 逐个对比版本号并执行更新

SKILLS_DIR="$HOME/.openclaw/workspace/skills"
LOG_FILE="$HOME/.openclaw/logs/skill-update-$(date +%Y-%m-%d).log"
REPORT_FILE="/tmp/skill-update-report-$(date +%Y-%m-%d).md"

# 颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo "🔄 UpdateSkills - 批量更新技能"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# 确保日志目录存在
mkdir -p "$HOME/.openclaw/logs"

# 存储更新信息
declare -a updated_skills
declare -a failed_skills
declare -a skipped_skills

total=0
updated=0
failed=0
skipped=0

# 开始生成汇报
cat > "$REPORT_FILE" << EOF
# 技能更新汇报

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
更新时间：$(date '+%Y-%m-%d %H:%M:%S')
更新类型：批量更新
查询来源：skillhub.cn
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EOF

# 已安装技能列表（示例）
installed_skills=(
    "UpdateSkills"
    "agent-browser"
    "agent-sentinel"
    "context-optimizer"
    "getnote"
    "humanizer"
    "knowledge-graph"
    "multi-agent-collaboration"
    "multi-search-engine"
    "self-improving-agent"
    "skill-vetter"
    "summarize"
    "wechat-article"
    "wechat-push"
    "x-followings-digest"
)

echo "📋 正在检查 ${#installed_skills[@]} 个技能..."
echo ""

for skill_name in "${installed_skills[@]}"; do
    total=$((total + 1))
    
    # 读取本地版本
    skill_dir="$SKILLS_DIR/$skill_name"
    if [ -f "$skill_dir/package.json" ]; then
        local_version=$(cat "$skill_dir/package.json" | python3 -c "import sys,json; print(json.load(sys.stdin).get('version','unknown'))" 2>/dev/null)
    else
        local_version="unknown"
    fi
    
    # 从 skillhub.cn 获取远程版本（通过浏览器访问）
    # 这里需要手动查看或使用 API
    # 暂时使用预设的版本号（实际应该从网页抓取）
    
    # 预设版本号（从 skillhub.cn 获取）
    declare -A skillhub_versions=(
        ["multi-search-engine"]="2.0.1"
        ["summarize"]="1.0.0"
        ["getnote"]="1.5.7"
        ["weather"]="1.0.0"
        ["humanizer"]="1.0.0"
        ["skill-vetter"]="1.0.0"
        ["self-improving-agent"]="1.0.0"
    )
    
    remote_version="${skillhub_versions[$skill_name]:-}"
    
    if [ -n "$remote_version" ]; then
        if [ "$local_version" != "$remote_version" ] && [ "$local_version" != "unknown" ]; then
            echo -e "${YELLOW}[$total] $skill_name${NC}"
            echo "      本地：v$local_version"
            echo "      远程：v$remote_version"
            echo -e "      状态：${YELLOW}⚠️  可更新${NC}"
            echo ""
            updated_skills+=("$skill_name:$local_version:$remote_version")
            updated=$((updated + 1))
        elif [ "$local_version" == "unknown" ]; then
            echo "[$total] $skill_name v$local_version ... ⚪ 需要确认版本"
            skipped_skills+=("$skill_name:$local_version:需要确认")
            skipped=$((skipped + 1))
        else
            echo -e "[$total] $skill_name v$local_version ... ${GREEN}✅ 已是最新版${NC}"
            skipped_skills+=("$skill_name:$local_version:$remote_version")
            skipped=$((skipped + 1))
        fi
    else
        echo "[$total] $skill_name v$local_version ... ⚪ 未找到远程版本"
        skipped_skills+=("$skill_name:$local_version:未找到")
        skipped=$((skipped + 1))
    fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📊 汇总"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "检查技能：$total 个"
echo "可更新：$updated 个"
echo "已是最新/未找到：$skipped 个"
echo ""

# 记录日志
echo "$(date '+%Y-%m-%d %H:%M:%S') - 检查完成：总计=$total, 可更新=$updated" >> "$LOG_FILE"

if [ $updated -gt 0 ]; then
    echo ""
    echo -e "${YELLOW}⚠️  发现可更新的技能：${NC}"
    for item in "${updated_skills[@]}"; do
        IFS=':' read -r name local remote <<< "$item"
        echo "  - $name: v$local → v$remote"
        # 记录到日志
        echo "{\"timestamp\":\"$(date -Iseconds)\",\"action\":\"check\",\"skill\":\"$name\",\"local_version\":\"$local\",\"remote_version\":\"$remote\",\"status\":\"updatable\"}" >> "$LOG_FILE"
    done
    echo ""
    
    # 添加到汇报
    cat >> "$REPORT_FILE" << EOF
## 📊 汇总

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
检查技能：$total 个
可更新：$updated 个
已是最新：$skipped 个
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📝 可更新技能

EOF
    
    for item in "${updated_skills[@]}"; do
        IFS=':' read -r name local remote <<< "$item"
        echo "- $name: v$local → v$remote" >> "$REPORT_FILE"
    done
    
    echo ""
    read -p "是否批量更新这些技能？(是/否): " confirm
    if [[ $confirm == [Yy]* ]] || [[ $confirm == "是" ]]; then
        echo ""
        echo "🔄 开始批量更新..."
        echo ""
        
        for item in "${updated_skills[@]}"; do
            IFS=':' read -r name local remote <<< "$item"
            echo "[$name] 更新中..."
            echo "      本地版本：v$local"
            echo "      目标版本：v$remote"
            
            # 执行更新
            openclaw skill install "$name" --force 2>/dev/null
            
            if [ $? -eq 0 ]; then
                echo -e "      状态：${GREEN}✅ 成功${NC}"
                echo "{\"timestamp\":\"$(date -Iseconds)\",\"action\":\"update\",\"skill\":\"$name\",\"old_version\":\"$local\",\"new_version\":\"$remote\",\"status\":\"success\"}" >> "$LOG_FILE"
                updated=$((updated + 1))
            else
                echo -e "      状态：${RED}❌ 失败${NC}"
                echo "{\"timestamp\":\"$(date -Iseconds)\",\"action\":\"update\",\"skill\":\"$name\",\"old_version\":\"$local\",\"new_version\":\"$remote\",\"status\":\"failed\",\"error\":\"更新命令执行失败\"}" >> "$LOG_FILE"
                failed=$((failed + 1))
            fi
            echo ""
        done
        
        # 更新汇报
        cat >> "$REPORT_FILE" << EOF

## ✅ 更新结果

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
已更新：$updated 个
失败：$failed 个
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📄 日志

完整日志：$LOG_FILE

## 💡 建议

建议重启 Gateway 使更新生效。
EOF
        
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo -e "${GREEN}✨ 批量更新完成！${NC}"
        echo ""
        echo "📄 汇报已保存到：$REPORT_FILE"
        echo "📄 日志已记录到：$LOG_FILE"
        echo ""
        read -p "是否现在重启 Gateway？(是/否): " restart_confirm
        if [[ $restart_confirm == [Yy]* ]] || [[ $restart_confirm == "是" ]]; then
            echo "🔄 正在重启 Gateway..."
            openclaw gateway restart
            echo "✅ Gateway 已重启"
        fi
    else
        echo "⏭️  已跳过更新"
    fi
else
    echo -e "${GREEN}✅ 所有技能都是最新版！${NC}"
    
    # 更新汇报
    cat >> "$REPORT_FILE" << EOF

## ✅ 检查结果

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
所有技能都是最新版！
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 📄 日志

检查日志：$LOG_FILE
EOF
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
