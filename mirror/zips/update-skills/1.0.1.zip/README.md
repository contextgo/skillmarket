# UpdateSkills - 技能更新检查助手

自动检查已安装技能的版本号，通过浏览器访问 skillhub.cn 对比社区最新版本。

## 功能特性

- ✅ **版本检查** — 读取已安装技能的 package.json
- ✅ **远程对比** — 通过浏览器访问 skillhub.cn 查询最新版本
- ✅ **批量检查** — 一次性检查所有技能
- ✅ **批量更新** — 一键更新所有可更新技能（一个一个对比版本号）
- ✅ **定时检查** — 支持 cron 定时任务（每天/每周/自定义）
- ✅ **日志记录** — JSON Lines 格式，详细记录每次更新
- ✅ **更新汇报** — Markdown 格式，清晰的报告

## 使用方式

### 检查所有技能

```
检查技能更新
```

### 批量更新所有技能

```
批量更新所有技能
```

### 更新单个技能

```
更新 multi-search-engine
```

### 设置定时检查

```
每天早上 9 点检查技能更新
```

或

```
每周一检查技能更新
```

### 查看更新历史

```
查看技能更新历史
```

## 输出示例

### 批量更新汇报

```markdown
✨ 技能更新汇报

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
更新时间：2026-04-19 17:58
更新类型：批量更新
查询来源：skillhub.cn
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 汇总
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
检查技能：25 个
已更新：2 个
失败：0 个
跳过：23 个（已是最新版）

📝 详情
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ multi-search-engine    unknown → V 2.0.1
   下载量：12.1 万
✅ summarize              unknown → V 1.0.0
   下载量：34.6 万

📄 日志
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
完整日志：~/.openclaw/logs/skill-update-2026-04-19.log

💡 建议
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
建议重启 Gateway 使更新生效。
是否现在重启？(是/否)
```

### 更新历史

```markdown
📜 技能更新历史

最近 7 次更新记录：

[2026-04-19 17:58] 批量更新
  ✅ multi-search-engine    unknown → V 2.0.1
  ✅ summarize              unknown → V 1.0.0

[2026-04-19 17:29] 单个更新
  ✅ wechat-push            v4.0.0 → v4.1.0
```

## 日志文件

**位置：** `~/.openclaw/logs/skill-update.log`

**格式：** JSON Lines（每行一个 JSON 对象）

**示例：**
```json
{"timestamp":"2026-04-19T17:58:00+08:00","action":"batch_update","skill":"multi-search-engine","old_version":"unknown","new_version":"2.0.1","status":"success","source":"skillhub.cn"}
```

## 配置选项

在 `openclaw.json` 中添加：

```json
{
  "skills": {
    "updateCheck": {
      "enabled": true,
      "autoUpdate": false,
      "checkInterval": "24h",
      "notifyOnUpdate": true,
      "batchUpdate": true,
      "logLevel": "info",
      "source": "skillhub.cn"
    }
  }
}
```

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| enabled | 是否启用自动检查 | true |
| autoUpdate | 是否自动更新（不询问） | false |
| checkInterval | 检查间隔（24h/7d/30d） | 24h |
| notifyOnUpdate | 发现更新时通知 | true |
| batchUpdate | 批量更新模式 | true |
| logLevel | 日志级别（info/debug/error） | info |
| source | 版本查询来源 | skillhub.cn |

## 安装

### 方法 1：使用安装脚本（推荐）

```bash
cd /Users/mac/Desktop/UpdateSkills
./install.sh
```

安装脚本会：
1. 复制技能到 skills 目录
2. 询问是否设置定时检查
3. 重启 Gateway

### 方法 2：手动安装

```bash
# 复制技能
cp -r /Users/mac/Desktop/UpdateSkills ~/.openclaw/workspace/skills/

# 设置定时检查（每天早上 9 点）
openclaw cron add '{
  "name": "每日技能更新检查",
  "schedule": {"kind": "cron", "expr": "0 9 * * *", "tz": "Asia/Shanghai"},
  "payload": {"kind": "systemEvent", "text": "检查技能更新"},
  "sessionTarget": "current"
}'

# 重启 Gateway
openclaw gateway restart
```

### 方法 3：从 skillhub 安装

```bash
openclaw skill install UpdateSkills
```

## 文件结构

```
UpdateSkills/
├── SKILL.md              # 技能详细说明（8.6KB）
├── README.md             # 本文件
├── package.json          # 版本信息
├── install.sh            # 安装脚本
├── scripts/
│   ├── check-skillhub.sh     # skillhub 版本检查脚本
│   └── check-updates.sh      # 更新检查脚本
└── examples/
    ├── log-sample.json       # 日志示例
    ├── report-sample.md      # 汇报示例
    └── usage.md              # 使用示例
```

## 批量更新流程

1. 获取已安装技能列表
2. 读取每个技能的本地版本号
3. 通过浏览器访问 skillhub.cn 查询最新版本
4. 对比版本号（名称匹配优先，下载量次之）
5. 生成更新报告
6. 用户确认
7. 一个一个执行更新
8. 记录日志
9. 生成汇报
10. 建议重启 Gateway

## 版本对比规则

1. **名称完全匹配优先** - 优先选择名称完全匹配的技能
2. **下载量次之** - 无完全匹配时选择下载量最高的
3. **版本号位置** - skillhub.cn 页面显示 "V X.X.X" 格式

## License

MIT
