# 位置服务管理API — 接口速查文档

> 原始文档：位置服务管理API文档.docx（同目录）
> 权限要求：第三方平台需新增位置服务管理权限集 **195** 并重新授权

---

## 术语说明

| 术语 | 定义 |
|------|------|
| 服务定义 | 小程序提供的通用服务能力，如"预点单"、"外卖"，与位置无关 |
| 位置服务授权 | 将服务定义中的通用服务授权给位置，可带唯一标识，审核通过后位置管理员可将服务挂载到微信位置外显 |
| 位置类型 | 位置分类，如"美食:中餐厅:粤菜" |
| 服务类型 | 通用服务分类，如"预点单"、"外卖" |

---

## API 总览

| 模块 | 接口 | 说明 |
|------|------|------|
| 位置认领 | [创建位置认领链接](#1-创建位置认领链接) | 提交位置信息+资质，生成认领链接 |
| 位置认领 | [查询位置认领状态](#2-查询位置认领状态) | 按task_id查询认领审核状态 |
| 服务定义 | [查询服务定义列表](#3-查询服务定义列表) | 查询小程序已有服务定义 |
| 服务定义 | [新增服务定义](#4-新增服务定义) | 申请新增服务定义 |
| 服务定义 | [删除服务定义](#5-删除服务定义) | 删除服务定义 |
| 位置服务授权 | [查询已绑定位置列表](#6-查询已绑定位置列表) | 查询小程序已绑定的位置 |
| 位置服务授权 | [新增位置服务授权](#7-新增位置服务授权) | 将服务授权给位置，需审核 |
| 位置服务授权 | [查询位置服务授权记录](#8-查询位置服务授权记录) | 查询指定位置的服务授权 |
| 位置服务授权 | [删除位置服务授权](#9-删除位置服务授权) | 删除授权给位置的服务 |
| 消息推送 | [位置认领审核结果](#10-位置认领审核结果推送) | 审核结果回调 |
| 消息推送 | [位置服务授权审核结果](#11-位置服务授权审核结果推送) | 授权审核结果回调 |

---

## 一、位置认领

### 1. 创建位置认领链接

> 服务商代用户填写入驻信息并生成专属认领链接，降低用户入驻门槛。平台会通过地址与腾讯地图POI匹配；如位置已被认领则不允许重复创建。

**请求参数**

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| access_token | string | ✅ | URL参数，接口调用凭证 |
| name | string | ✅ | 位置名称，最长50字。如"爱马哥咖啡" |
| qqmap_poi_id | string | ❌ | 腾讯地图POI ID，填写则优先匹配 |
| province | string | ❌ | 省份 |
| city | string | ❌ | 城市 |
| district | string | ❌ | 区 |
| address | string | ❌ | 详细地址，最长100字（address和location至少存在一个） |
| location | string | ❌ | 经纬度，纬度在前经度在后，英文逗号分隔（address和location至少存在一个） |
| custom_location_id | string | ❌ | 开发者系统唯一标识，最长50字，用于映射微信位置ID |
| license_img_url | string | ❌ | 营业执照图片URL，jpg/jpeg/png，≤10MB。预填则法人无需手动填写 |
| principal_name | string | ❌ | 机构名称，预填则法人无需手动填写 |
| principal_number | string | ❌ | 营业执照号，预填则法人无需手动填写 |
| legal_person_name | string | ❌ | 法人姓名，预填则法人无需手动填写 |
| legal_person_idcard | string | ❌ | 法人身份证号，预填则法人无需手动填写 |
| legal_person_phone | string | ❌ | 法人手机号，11位中国大陆号码 |

**返回参数**

| 属性 | 类型 | 说明 |
|------|------|------|
| errcode | number | 错误码 |
| errmsg | string | 错误原因 |
| task_id | string | 认领申请任务ID，用于查询状态 |
| url_link | string | 认领申请小程序URL Link，**有效期48小时** |

---

### 2. 查询位置认领状态

> 按task_id查询，不支持任意位置查询

**认领状态码**

| 状态值 | 状态 | 说明 |
|--------|------|------|
| 0 | 未认领 | 用户还未开始认领流程 |
| 1 | 审核中 | 用户已提交认领申请，等待平台审核 |
| 2 | 审核不通过 | 平台审核不通过 |
| 3 | 审核通过 | 认领成功 |
| 4 | 任务超时 | 任务有效期48小时 |

**请求参数**

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| access_token | string | ✅ | URL参数 |
| task_id | string | ✅ | 创建认领时返回的任务ID |

**返回参数**

| 属性 | 类型 | 说明 |
|------|------|------|
| errcode | number | 错误码 |
| errmsg | string | 错误原因 |
| status | number | 0-未认领 / 1-审核中 / 2-不通过 / 3-通过 |
| poi_id | string | 位置ID，审核通过后返回 |
| custom_location_id | string | 开发者系统唯一标识 |

---

## 二、服务定义管理

### 3. 查询服务定义列表

**请求参数**

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| access_token | string | ✅ | URL参数 |
| offset | number | ❌ | 分页偏移，从0开始 |
| limit | number | ❌ | 每页数量，默认10 |
| wxa_service_id | string | ❌ | 服务定义ID，精确查询 |

**返回参数 — WxaServiceInfo**

| 属性 | 类型 | 说明 |
|------|------|------|
| wxa_service_id | string | 服务定义ID |
| industry_id | number | 位置类型 |
| service_type_id | number | 服务类型 |
| base_path | string | 小程序页面，如 pages/index/index |
| extra_path | string | 公共query参数，不同门店特殊参数在授权时传入 |
| create_time | number | 创建时间戳 |
| remark | string | 备注 |

---

### 4. 新增服务定义

**请求参数**

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| access_token | string | ✅ | URL参数 |
| industry_id | number | ✅ | 位置类型 |
| service_type_id | number | ✅ | 服务类型 |
| base_path | string | ✅ | 小程序页面，如 pages/index/index |
| extra_path | string | ❌ | 公共query参数 |
| remark | string | ❌ | 备注，≤20字 |

**返回：** `wxa_service_id`（服务定义ID）

---

### 5. 删除服务定义

**请求参数**

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| access_token | string | ✅ | URL参数 |
| wxa_service_id | string | ✅ | 服务定义ID |

---

## 三、位置服务授权管理

### 6. 查询已绑定位置列表

**请求参数**

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| access_token | string | ✅ | URL参数 |
| offset | number | ❌ | 分页偏移 |
| limit | number | ❌ | 每页数量，默认10 |

**返回参数 — POIInfo**

| 属性 | 类型 | 说明 |
|------|------|------|
| poi_id | string | 位置ID |
| poi_name | string | 位置名称 |
| poi_address | string | 位置地址 |
| poi_principal_name | string | 位置主体名称 |
| industry_id | number | 位置类型 |
| industry_name | string | 位置类型名称 |
| first_industry_id | number | 一级位置类型 |
| first_industry_name | string | 一级位置类型名称 |
| second_industry_id | number | 二级位置类型 |
| second_industry_name | string | 二级位置类型名称 |

---

### 7. 新增位置服务授权

> 将服务功能授权给位置，需审核通过后生效

**请求参数**

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| access_token | string | ✅ | URL参数 |
| poi_id | string | ✅ | 位置ID |
| wxa_service_id | string | ✅ | 服务定义ID |
| poi_extra_path | string | ❌ | 位置扩展路径，与基础路径拼接生成完整服务路径，用于传门店特殊参数 |

**返回：** `poi_service_id`（位置服务授权ID）

---

### 8. 查询位置服务授权记录

**请求参数**

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| access_token | string | ✅ | URL参数 |
| poi_id | string | ✅ | 位置ID |
| offset | number | ❌ | 分页偏移 |
| limit | number | ❌ | 每页数量，默认10 |

**返回参数 — POIServiceInfo**

| 属性 | 类型 | 说明 |
|------|------|------|
| poi_service_id | string | 位置服务授权ID |
| poi_id | string | 位置ID |
| wxa_service_id | string | 服务定义ID |
| service_type_id | number | 服务类型 |
| poi_extra_path | string | 位置扩展路径 |
| service_path | string | 完整服务路径 |
| status | number | 1-审核通过 / 2-审核中 / 3-审核不通过 |
| create_time | number | 创建时间戳 |
| update_time | number | 更新时间戳 |
| audit_reason | string | 审核不通过原因 |

---

### 9. 删除位置服务授权

**请求参数**

| 属性 | 类型 | 必填 | 说明 |
|------|------|------|------|
| access_token | string | ✅ | URL参数 |
| poi_service_id | string | ✅ | 位置服务授权ID |

---

## 四、消息推送

> 接入方式参考公众平台消息推送，第三方平台需权限集195

### 10. 位置认领审核结果推送

**事件类型：** `secpoi_verify_audit_event`

| 属性 | 类型 | 说明 |
|------|------|------|
| task_id | string | 认领申请任务ID |
| poi_id | string | 位置ID |
| custom_location_id | string | 开发者系统唯一标识 |
| status | number | 2-审核不通过 / 3-审核通过（认领成功） |
| create_time | number | 创建时间戳 |
| update_time | number | 更新时间戳 |

### 11. 位置服务授权审核结果推送

**事件类型：** `secpoi_service_audit_event`

| 属性 | 类型 | 说明 |
|------|------|------|
| poi_id | string | 位置ID |
| poi_service_id | string | 位置服务授权ID |
| wxa_service_id | string | 服务定义ID |
| service_type_id | number | 服务类型 |
| service_path | string | 完整服务路径 |
| status | number | 1-审核通过 / 3-审核不通过 |
| create_time | number | 创建时间戳 |
| update_time | number | 更新时间戳 |
| audit_reason | string | 审核不通过原因 |

---

## 五、常见错误码

| 错误码 | 原因 | 处理方式 |
|--------|------|---------|
| 10220001 | 基础路径不可用 | 检查 base_path 是否正确 |
| 10220002 | 公共参数格式不正确 | 检查 extra_path 格式 |
| 10220003 | 备注超出字数限制 | 修改备注≤20字 |
| 10220004 | 位置路径格式不正确 | 检查 poi_extra_path |
| 10220005 | 位置ID不存在或未授权 | 确认位置已认领且已授权 |
| 10220006 | 服务不存在或与位置类型不匹配 | 确认 industry_id 和 service_type_id 匹配 |
| 10220007 | 服务授权记录不存在 | 确认 poi_service_id 正确 |
| 10220008 | 参数错误 | 逐项检查请求参数 |
| **10220009** | **该位置已被认领，暂不支持重复认领** | ⚠️ 高频错误，告知商家位置已被认领 |
| 10220010 | 任务ID不存在 | 确认 task_id 正确 |
| 10220011 | 位置信息错误 | 检查名称与地址/经纬度是否对应 |
| 10220012 | 不支持的位置类型或服务类型 | 查品类速查表确认是否开放 |
| 10221001 | 位置类型下已存在相同服务类型 | 无需重复新增 |
| 10221002 | 当前服务已授权或审核中，不可删除 | 先删除授权再删服务定义 |
| 10221003 | 已存在该服务类型 | 检查是否重复创建 |
| 10221004 | 服务审核中，请等待 | 不可在审核期间操作 |

---

## 六、接入流程概览

```
1. 创建位置认领链接 → 生成url_link分享给用户
2. 用户点击链接补充信息/确认 → 提交认领申请
3. 查询认领状态（或等推送） → 认领通过获得poi_id
4. 新增服务定义 → 绑定industry_id + service_type_id + 小程序路径
5. 新增位置服务授权 → 将服务授权给poi_id
6. 等待授权审核通过 → 服务在微信位置页外显
```
