---
name: easy-to-read-converter
description: >
  易读图文转换器。用户输入"yd"或"y"或"d"即可启动。将复杂文字转化为易读图文符号内容，
  输出为Word文档(.docx)。使用通用符码、图标、图解、流程图、色彩标记、排版符号等视觉辅助手段，
  使文字更易于理解。适用于：用户上传含文字的照片/文档/公告/菜单/指示牌/文章后要求转化为易读内容，
  或用户要求简化文字、制作易读版、将艰涩内容转化为浅显版本、为心智障碍者/儿童/长者/新移民
  设计可读内容、改善文字可读性、制作无障碍图文、将文字转化为图文符号等场景。
---

# 易读图文转换器

将照片中的复杂文字转化为以**图文符号**为核心的易读Word文档。

## 快速启动

- 输入 `yd` 启动
- 输入 `y` 启动
- 输入 `d` 启动

## 输出格式

输出为Word文档(.docx)，使用C# + OpenXML SDK生成。

排版规范：
- 字号：正文14pt以上（Val="28"），标题更大
- 字体：中文微软雅黑，英文Arial
- 无斜体/下划线/阴影，强调用粗体
- 行距1.5倍以上
- 靠左对齐
- 长句分段（每句不超过20字）
- 纯白背景，无水印

## 执行流程

### 第一步：文字提取

用户上传图片时用OCR提取文字，直接提供文字时跳过此步。

### 第二步：内容分析

识别需转化为符号的信息：动作、地点、时间、联络、物品、数量、警示、步骤、选择。

### 第三步：文字转化

- 词汇简化为小学四五年级程度
- 每句不超过20字，一句一段
- 主动语态，正面语气
- 每节最多2个重点
- 加入理解检查

### 第四步：生成Word文档

**核心设计：RunProperties模板复用**

C#模板中预定义了12个RunProperties工厂方法，通过`CloneNode(true)`安全复用：

| 方法 | 用途 |
|------|------|
| `RpBody()` | 正文：14pt + 微软雅黑/Arial + 深灰 |
| `RpBoldBody()` | 粗体正文 |
| `RpColor(c)` | 彩色文字 |
| `RpBoldColor(c)` | 粗体彩色 |
| `RpTitle()` | 主标题：22pt + 标题色 |
| `RpHeading()` | 节标题：18pt |
| `RpSubHeading()` | 小标题：16pt |
| `RpEmoji()` | Emoji符号：Segoe UI Emoji字体 |
| `RpEmojiColor(c)` | 彩色Emoji |
| `RpTable()` | 表格文字：12pt |
| `RpTableBold()` | 表格粗体 |

使用方式：`new Run(RpBody().CloneNode(true), new Text("内容"))`

**关键原则：Emoji和文字必须在不同Run中**
- Emoji Run用`RpEmoji()`或`RpEmojiColor()`
- 文字Run用`RpBody()`、`RpBoldBody()`等

### 第五步：构建与交付

```bash
# 构建命令
./scripts/docx build <输出路径>
```

构建成功后会显示`[SUCCESS]`，失败会显示错误码和排查建议。

## 错误码与排查指南

| 错误码 | 含义 | 排查方法 |
|--------|------|----------|
| E001 | 参数错误 | 检查输出路径是否为空 |
| E002 | OpenXML包错误 | 检查输出路径是否有写入权限，路径不含特殊字符 |
| E003 | IO错误 | 关闭已打开的Word文件；检查磁盘空间 |
| E004 | 权限错误 | 更换输出路径到有写入权限的目录 |
| E999 | 未知错误 | 检查中文标点是否泄露到C#语法位置；检查TableGrid位置 |

常见编译错误排查：
- `CS1003`：中文引号断裂字符串，用`\"`转义
- `CS1056`：中文标点出现在参数列表/分号位置，改用ASCII标点
- `InvalidOperationException`：RunProperties被重复Append到多个Run，改用`CloneNode(true)`
- `missing tblGrid`：TableGrid放在了TableProperties内部，应放在Table下作为并列子元素

## 参考资料

| 文件 | 路径 | 内容 |
|------|------|------|
| 图文符号规则 | `references/easy-to-read-rules.md` | 符码库、简化规则、Word排版规范、案例 |
| C#代码模板 | `assets/easy-to-read-template.cs` | 完整C#模板（含RpXxx工厂方法和错误处理） |
