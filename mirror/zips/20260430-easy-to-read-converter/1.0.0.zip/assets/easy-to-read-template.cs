// Easy-to-Read Document Template
// 核心: Emoji和文字混排在同一个Run中，通过ComplexScript字体通道自动渲染Emoji
//
// Emoji显示原理:
//   - 普通文字(U+0000-U+FFFF) → Ascii/EastAsia通道 → Arial/微软雅黑
//   - Emoji字符(U+1F000+) → ComplexScript通道 → Segoe UI Emoji
//   - 若系统无Segoe UI Emoji，Word自动回退到Apple Color Emoji/Noto Color Emoji
//
// 排版: 14pt正文, 微软雅黑+Arial, 1.5倍行距, 靠左, 白背景, 无特效

using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

namespace Docx;

class Program
{
    private static class C
    {
        public const string Title = "1A6B5E", Heading = "2E8B7B", Sub = "4A9E8F";
        public const string Body = "333333", Light = "666666", Orig = "999999";
        public const string Accent = "D4762C", TH = "E8F4F2", TB = "B8D4CF", Box = "F5FAF9";
        public const string Red = "C00000", Green = "548235";
    }

    private const int W = 11906, H = 16838;

    // ========================================================================
    // RunProperties 工厂 (所有RunProperties统一从这里创建)
    // 关键: ComplexScript="Segoe UI Emoji" 确保Emoji(U+1F000+)正确显示
    // ========================================================================
    static RunProperties Rp(string sz, string clr, bool b = false)
    {
        var r = new RunProperties(
            new FontSize { Val = sz },
            // ComplexScript是Emoji字符的字体通道。Word会自动回退到系统Emoji字体
            new RunFonts { Ascii = "Arial", HighAnsi = "Arial", EastAsia = "Microsoft YaHei", ComplexScript = "Segoe UI Emoji" },
            new Color { Val = clr });
        if (b) r.Append(new Bold());
        return r;
    }

    static RunProperties RpBody()      => Rp("28", C.Body);          // 14pt正文
    static RunProperties RpBold()      => Rp("28", C.Body, true);    // 粗体
    static RunProperties RpColor(string c) => Rp("28", c);           // 彩色
    static RunProperties RpBoldC(string c) => Rp("28", c, true);     // 粗体彩色
    static RunProperties RpH1()        => Rp("44", C.Title, true);   // 22pt主标题
    static RunProperties RpH2()        => Rp("36", C.Heading, true); // 18pt节标题
    static RunProperties RpH3()        => Rp("32", C.Sub, true);     // 16pt小标题
    static RunProperties RpLight()     => Rp("28", C.Light);         // 14pt浅灰
    static RunProperties RpOrig()      => Rp("20", C.Orig);          // 10pt原始
    static RunProperties RpTbl()       => Rp("24", C.Body);          // 12pt表格
    static RunProperties RpTblB()      => Rp("24", C.Title, true);   // 12pt表头
    static RunProperties RpFoot()      => Rp("20", C.Light);         // 10pt页脚

    // ========================================================================
    // Main
    // ========================================================================
    static void Main(string[] args)
    {
        string path = args.Length > 0 ? args[0] : "./易读版文档.docx";
        using var doc = WordprocessingDocument.Create(path, WordprocessingDocumentType.Document);
        try
        {
            var mp = doc.AddMainDocumentPart();
            mp.Document = new Document(new Body());
            var body = mp.Document.Body!;

            AddStyles(mp);
            Build(body);
            AddFooter(mp, body);

            var sp = mp.AddNewPart<DocumentSettingsPart>();
            sp.Settings = new Settings(new UpdateFieldsOnOpen { Val = true });
            doc.Save();
            Console.WriteLine("[OK] 已生成: " + path);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("[ERROR] " + ex.Message);
            throw;
        }
    }

    // ========================================================================
    // 样式
    // ========================================================================
    static void AddStyles(MainDocumentPart mp)
    {
        var sp = mp.AddNewPart<StyleDefinitionsPart>();
        sp.Styles = new Styles();

        sp.Styles.Append(MkSt("Normal", "Normal", "28", C.Body,
            Sp(360, 160), J(JustificationValues.Left)));
        sp.Styles.Append(MkSt("H1", "heading 1", "44", C.Title,
            Sp(400, 240), Ol(0), Kn(), Kl()));
        sp.Styles.Append(MkSt("H2", "heading 2", "36", C.Heading,
            Sp(320, 160), Ol(1), Kn(), Kl()));
        sp.Styles.Append(MkSt("H3", "heading 3", "32", C.Sub,
            Sp(240, 120), Ol(2), Kn(), Kl()));
    }

    // 辅助创建OpenXmlElement (避免C#语法位置出现中文)
    static SpacingBetweenLines Sp(uint line, uint after) =>
        new SpacingBetweenLines { Line = line.ToString(), LineRule = LineSpacingRuleValues.Auto, After = after.ToString() };
    static Justification J(JustificationValues v) => new Justification { Val = v };
    static OutlineLevel Ol(int v) => new OutlineLevel { Val = v };
    static KeepNext Kn() => new KeepNext();
    static KeepLines Kl() => new KeepLines();

    static Style MkSt(string sid, string name, string sz, string clr, params OpenXmlElement[] extras)
    {
        var spp = new StyleParagraphProperties();
        foreach (var e in extras) spp.Append(e.CloneNode(true));
        return new Style(
            new StyleName { Val = name }, new BasedOn { Val = "Normal" }, spp,
            new StyleRunProperties(new Bold(), new FontSize { Val = sz },
                new RunFonts { Ascii = "Arial", HighAnsi = "Arial", EastAsia = "Microsoft YaHei", ComplexScript = "Segoe UI Emoji" },
                new Color { Val = clr }))
        { Type = StyleValues.Paragraph, StyleId = sid };
    }

    // ========================================================================
    // 内容构建 (替换此处为用户实际的易读转化结果)
    // ========================================================================
    static void Build(Body body)
    {
        // 主标题
        body.Append(H1("\uD83C\uDFE2 博物馆参观指南"));
        body.Append(P(RpLight(), "易读版"));
        body.Append(Sep());

        // 原始内容
        body.Append(H2("\uD83D\uDCCB 原始内容"));
        body.Append(OrigBox("本馆即日起实施入馆实名制，参观民众须于事前透过官方网站预约，并携带身分证或健保卡以供查验。未携带证件者，本馆得拒绝入馆。预约时段分为上午九时至十二时、下午一时至五时，每时段限额一百人。洽询电话：(02)2343-1100"));
        body.Append(Sep());

        // 符号说明
        body.Append(H2("\uD83D\uDD23 符号说明"));
        body.Append(SymTbl());

        // 易读内容
        body.Append(H2("\u2728 易读内容"));

        body.Append(H3("\uD83D\uDCCC 来之前要做的事"));
        body.Append(Bl("\uD83D\uDCDE 先打电话或上网预约"));
        body.Append(P(RpBody(), "可以上博物馆的网站预约"));
        body.Append(Bl("\uD83D\uDCDD 准备证件"));
        body.Append(P(RpBody(), "身分证或健保卡都可以"));
        body.Append(Bl("\u274C 没有证件不能进去"));
        body.Append(P(RpBody(), "出门前检查一下包包"));

        body.Append(H3("\uD83D\uDD50 开放时间"));
        body.Append(TimeTbl());

        body.Append(H3("\u274C 不可以做的事"));
        body.Append(No("用别人的证件进去"));
        body.Append(No("超过预约时间来"));
        body.Append(No("在馆内大声吵闹"));

        body.Append(H3("\u2B55 可以做的好事"));
        body.Append(Yes("慢慢看展品"));
        body.Append(Yes("拍照片（不要用闪光灯）"));
        body.Append(Yes("问工作人员问题"));

        body.Append(Tip("小提示", "博物馆每周一休息，来之前先确认有没有开！"));

        // 理解检查
        body.Append(Sep());
        body.Append(H2("\uD83C\uDFAF 理解检查"));
        body.Append(Q("来博物馆要准备什么？"));
        body.Append(Chk("先预约"));
        body.Append(Chk("带证件"));
        body.Append(Chk("在开放时间来"));
        body.Append(Q("如果没有证件怎么办？"));
        body.Append(P(RpBody(), "回家拿证件再来"));
    }

    // ========================================================================
    // 段落工厂 (单Run设计: Emoji+文字混排，ComplexScript自动处理Emoji)
    // ========================================================================

    // 基础: RunProperties + Text 生成 Paragraph
    static Paragraph P(RunProperties rp, string txt, ParagraphProperties? pp = null)
    {
        var p = new Paragraph();
        if (pp != null) p.Append(pp.CloneNode(true));
        p.Append(new Run(rp.CloneNode(true),
            new Text(txt) { Space = SpaceProcessingModeValues.Preserve }));
        return p;
    }

    static Paragraph H1(string t)  => P(RpH1(), t, PP("H1", "200", "120", null));
    static Paragraph H2(string t)  => P(RpH2(), t, PP("H2", "400", "200",
        new ParagraphBorders(new BottomBorder { Val = BorderValues.Single, Size = 8, Color = C.Heading, Space = 4 })));
    static Paragraph H3(string t)  => P(RpH3(), t, PP("H3", null, null, null));

    static Paragraph Bl(string t)  => P(RpBody(), t, PP(null, null, "120", Ind("360")));
    static Paragraph Short(string t) => P(RpBody(), t, PP(null, null, "120", null));
    static Paragraph No(string t)  => P(RpColor(C.Red), "\u274C " + t, PP(null, null, "100", Ind("360")));
    static Paragraph Yes(string t) => P(RpColor(C.Green), "\u2B55 " + t, PP(null, null, "100", Ind("360")));
    static Paragraph Chk(string t) => P(RpBody(), "\u2610 " + t, PP(null, null, "80", Ind("720")));
    static Paragraph Q(string t)   => P(RpBoldC(C.Accent), "\u2753 " + t, PP(null, "200", "100", null));

    static Paragraph OrigBox(string t) => P(RpOrig(), t, PP(null, null, "120",
        new Indentation { Left = "200", Right = "200" },
        new Shading { Val = ShadingPatternValues.Clear, Fill = "F5F5F5" }));

    static Paragraph Tip(string title, string content)
    {
        var pp = new ParagraphProperties(
            new SpacingBetweenLines { Line = "360", LineRule = LineSpacingRuleValues.Auto, Before = "200", After = "200" },
            new Shading { Val = ShadingPatternValues.Clear, Fill = C.Box },
            new ParagraphBorders(new LeftBorder { Val = BorderValues.Single, Size = 24, Color = C.Heading, Space = 8 }),
            new Indentation { Left = "200", Right = "200" });
        return new Paragraph(pp,
            new Run(RpBoldC(C.Heading).CloneNode(true),
                new Text("\uD83D\uDCA1 " + title + "\uff1a") { Space = SpaceProcessingModeValues.Preserve }),
            new Run(RpBody().CloneNode(true),
                new Text(content) { Space = SpaceProcessingModeValues.Preserve }));
    }

    static Paragraph Sep() => new Paragraph(new ParagraphProperties(
        Sp(360, 0),
        new ParagraphBorders(new BottomBorder { Val = BorderValues.Single, Size = 4, Color = C.TB, Space = 1 })));

    // ParagraphProperties 辅助构建
    static ParagraphProperties PP(string? style, string? before, string? after, Indentation? ind, params OpenXmlElement[] extras)
    {
        var pp = new ParagraphProperties();
        if (style != null) pp.Append(new ParagraphStyleId { Val = style });
        if (before != null || after != null)
        {
            var sp = new SpacingBetweenLines { Line = "360", LineRule = LineSpacingRuleValues.Auto };
            if (before != null) sp.Before = before;
            if (after != null) sp.After = after;
            pp.Append(sp);
        }
        if (ind != null) pp.Append(ind);
        foreach (var e in extras) pp.Append(e);
        return pp;
    }
    static Indentation Ind(string left) => new Indentation { Left = left };

    // ========================================================================
    // 表格
    // ========================================================================
    static Table SymTbl()
    {
        var tbl = MkTbl(new[] { "1500", "2500", "1500", "2500" });
        tbl.Append(SymRow("\uD83D\uDCDE", "电话", "\uD83D\uDD50", "时间"));
        tbl.Append(SymRow("\uD83D\uDCCD", "地点", "\uD83D\uDC64", "工作人员"));
        tbl.Append(SymRow("\uD83D\uDCB0", "费用", "\uD83C\uDD93", "免费"));
        tbl.Append(SymRow("\u2B55", "可以", "\u274C", "不可以"));
        tbl.Append(SymRow("\u26A0", "注意", "\u2705", "完成"));
        tbl.Append(SymRow("\u25B6", "步骤", "\u25C6", "重点"));
        return tbl;
    }

    static Table TimeTbl()
    {
        var tbl = MkTbl(new[] { "2500", "3500" });
        tbl.Append(TRow(true, "场次", "时间"));
        tbl.Append(TRow(false, "上午场", "9点 - 12点"));
        tbl.Append(TRow(false, "下午场", "1点 - 5点"));
        tbl.Append(TRow(false, "每场次", "最多100人"));
        return tbl;
    }

    static Table MkTbl(string[] widths)
    {
        var tg = new TableGrid();
        foreach (var w in widths) tg.Append(new GridColumn { Width = w });
        return new Table(
            new TableProperties(
                new TableWidth { Width = "5000", Type = TableWidthUnitValues.Pct },
                new TableBorders(
                    new TopBorder { Val = BorderValues.Single, Size = 8, Color = C.Heading },
                    new BottomBorder { Val = BorderValues.Single, Size = 8, Color = C.Heading },
                    new LeftBorder { Val = BorderValues.Nil }, new RightBorder { Val = BorderValues.Nil },
                    new InsideHorizontalBorder { Val = BorderValues.Single, Size = 4, Color = C.TB })),
            tg);
    }

    static TableRow SymRow(string e1, string t1, string e2, string t2)
        => new TableRow(ECell(e1), TCell(t1), ECell(e2), TCell(t2));

    static TableCell ECell(string emoji) => Cell(emoji, true);
    static TableCell TCell(string text)  => Cell(text, false);

    static TableCell Cell(string text, bool emoji)
    {
        var rp = emoji ? RpTbl() : RpTbl();
        return new TableCell(
            new TableCellProperties(
                new TableCellWidth { Width = "0", Type = TableWidthUnitValues.Auto },
                new TableCellVerticalAlignment { Val = TableVerticalAlignmentValues.Center }),
            new Paragraph(
                new ParagraphProperties(
                    J(emoji ? JustificationValues.Center : JustificationValues.Left),
                    new Indentation { FirstLine = "0" },
                    Sp(300, 60)),
                new Run(rp.CloneNode(true), new Text(text) { Space = SpaceProcessingModeValues.Preserve })));
    }

    static TableRow TRow(bool hdr, string c1, string c2)
    {
        var row = new TableRow();
        if (hdr) row.Append(new TableRowProperties(new TableHeader()));
        foreach (var txt in new[] { c1, c2 })
        {
            var tcp = new TableCellProperties(new TableCellWidth { Width = "0", Type = TableWidthUnitValues.Auto });
            if (hdr) tcp.Append(new Shading { Val = ShadingPatternValues.Clear, Fill = C.TH });
            var rp = hdr ? RpTblB() : RpTbl();
            row.Append(new TableCell(tcp, new Paragraph(
                new ParagraphProperties(J(JustificationValues.Center), new Indentation { FirstLine = "0" }, Sp(300, 80)),
                new Run(rp.CloneNode(true), new Text(txt)))));
        }
        return row;
    }

    // ========================================================================
    // 页脚 + Section
    // ========================================================================
    static void AddFooter(MainDocumentPart mp, Body body)
    {
        var fp = mp.AddNewPart<FooterPart>();
        var fid = mp.GetIdOfPart(fp);
        var para = new Paragraph(new ParagraphProperties(J(JustificationValues.Center)));

        // PAGE field: Begin -> Code -> Separate -> Placeholder -> End
        var rpf = RpFoot();
        para.Append(MkRun(rpf, "- ", false));
        para.Append(MkRun(rpf, "", true, FieldCharValues.Begin));
        para.Append(MkRun(rpf, " PAGE ", false, true));
        para.Append(MkRun(rpf, "", true, FieldCharValues.Separate));
        para.Append(MkRun(rpf, "1", false));
        para.Append(MkRun(rpf, "", true, FieldCharValues.End));
        para.Append(MkRun(rpf, " -", false));

        fp.Footer = new Footer(para);

        body.Append(new SectionProperties(
            new FooterReference { Type = HeaderFooterValues.Default, Id = fid },
            new PageSize { Width = (UInt32Value)(uint)W, Height = (UInt32Value)(uint)H },
            new PageMargin { Top = 1440, Right = 1440, Bottom = 1440, Left = 1440, Header = 720, Footer = 720 }));
    }

    static Run MkRun(RunProperties rp, string text, bool isField, FieldCharValues? fcv = null, bool isCode = false)
    {
        var r = new Run();
        r.Append(rp.CloneNode(true));
        if (isField && fcv.HasValue)
            r.Append(new FieldChar { FieldCharType = fcv.Value });
        else if (isCode)
            r.Append(new FieldCode(text) { Space = SpaceProcessingModeValues.Preserve });
        else
            r.Append(new Text(text) { Space = SpaceProcessingModeValues.Preserve });
        return r;
    }
}
