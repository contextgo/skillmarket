#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fill_form.py — 根据简历自动填写表单
支持：PDF/DOCX 简历 + DOCX 表单模板

用法：
    python fill_form.py <简历文件路径> <表单模板路径> <输出文件路径>
示例：
    python fill_form.py ./resume.pdf ./template.docx ./output.docx

工作原理：
    1. 从简历提取文本内容
    2. 解析表单模板 XML，定位所有空白字段单元格
    3. 将简历内容匹配填入对应字段
    4. 保留模板中未匹配到的字段为空
"""

import sys
import re
import os

# ─────────────────────────────────────────────
# 第1步：从简历文件提取文本
# ─────────────────────────────────────────────

def extract_text_from_pdf(pdf_path: str) -> str:
    """从 PDF 提取全文字符串"""
    import pdfplumber
    texts = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            t = page.extract_text()
            if t:
                texts.append(t)
    return '\n'.join(texts)


def extract_text_from_docx(docx_path: str) -> str:
    """从 DOCX 提取全文字符串"""
    import zipfile, re
    with zipfile.ZipFile(docx_path, 'r') as z:
        with z.open('word/document.xml') as f:
            xml = f.read().decode('utf-8')
    texts = re.findall(r'<w:t[^>]*>([^<]+)</w:t>', xml)
    return '\n'.join(t.strip() for t in texts if t.strip())


def extract_resume_text(resume_path: str) -> str:
    """根据文件扩展名自动选择提取器"""
    ext = os.path.splitext(resume_path)[1].lower()
    if ext == '.pdf':
        return extract_text_from_pdf(resume_path)
    elif ext in ('.docx', '.doc'):
        return extract_text_from_docx(resume_path)
    else:
        raise ValueError(f'不支持的简历格式: {ext}，仅支持 PDF 和 DOCX')


# ─────────────────────────────────────────────
# 第2步：从简历文本解析结构化信息
# ─────────────────────────────────────────────

def parse_resume(text: str) -> dict:
    """
    用规则从简历文本中解析出结构化字段。
    当前版本面向金融行业简历，可扩展。
    返回 dict，键为表单字段名，值为解析出的文本。
    """
    lines = text.split('\n')
    resume = {}

    # ── 姓名（通常第一行，或含"姓名"字样）─────────────────
    for line in lines[:5]:
        m = re.search(r'姓名[：:]\s*([^\s\d]+)', line)
        if m:
            resume['姓名'] = m.group(1).strip()
            break
        # 无前缀：取首行第一个词（去掉特殊字符）
        if '姓名' not in resume:
            first = re.sub(r'[^\u4e00-\u9fa5a-zA-Z]', '', line.strip())
            if 2 <= len(first) <= 4:
                resume['姓名'] = first

    # ── 性别 ─────────────────────────────────────────
    for line in text[:300]:
        m = re.search(r'性别[：:]\s*([男女])', line)
        if m:
            resume['性别'] = m.group(1)
            break
        m = re.search(r'[男女]/?\d{4}', line)   # 如 "男/YYYY"
        if m:
            resume['性别'] = m.group(0)[0]
            break

    # ── 出生年月 ──────────────────────────────────────
    for line in text[:500]:
        m = re.search(r'出生[年月]?[：: ]*(\d{4})[年/\-](\d{1,2})', line)
        if m:
            resume['出生年月'] = f'{m.group(1)}年{m.group(2).zfill(2)}月'
            break
        m = re.search(r'(\d{4})\.(\d{1,2})(?:\.\d{1,2})?', line)   # YYYY.MM
        if m and '19' <= m.group(1) <= '20' and int(m.group(2)) <= 12:
            resume['出生年月'] = f'{m.group(1)}年{m.group(2).zfill(2)}月'
            break

    # ── 民族 ──────────────────────────────────────────
    for line in text[:1000]:
        m = re.search(r'民族[：:]\s*([^\s，,。]+)', line)
        if m:
            resume['民族'] = m.group(1).strip()
            break
        # 备选：从"民族/政治面貌"格式中提取（如"汉族/群众"）
        m = re.search(r'([\u4e00-\u9fa5]+)/', text[:500])
        if m:
            resume['民族'] = m.group(1)
            break

    # ── 政治面貌 ───────────────────────────────────────
    for line in text[:1000]:
        m = re.search(r'政治面貌[：:]\s*([^\s，,。]+)', line)
        if m:
            resume['政治面貌'] = m.group(1).strip()
            break
    # 备选：从"民族/政治面貌"格式中提取（如"汉族/群众"）
    m = re.search(r'([\u4e00-\u9fa5]{2,4})/([\u4e00-\u9fa5]+)', text[:500])
    if m and '政治面貌' not in resume:
        resume['政治面貌'] = m.group(2)

    # ── 健康状况 ───────────────────────────────────────
    for line in text:
        if '健康' in line:
            m = re.search(r'健康[^\u4e00-\u9fa5a-zA-Z]*([\u4e00-\u9fa5]+)', line)
            if m:
                resume['健康状况'] = m.group(1).strip()
                break

    # ── 参加工作时间 ───────────────────────────────────
    for line in text:
        m = re.search(r'(?:参加工作|工作年限)[：: ]*(\d{4})', line)
        if m:
            resume['参加工作时间'] = f'{m.group(1)}年'
            break
        m = re.search(r'(\d{4})[/\-至](\d{4})', line)  # YYYY/M至…
        if m and int(m.group(1)) >= 1970:
            resume['参加工作时间'] = f'{m.group(1)}年'
            break

    # ── 手机号码 ───────────────────────────────────────
    m = re.search(r'(?:手机|电话|联系方式)[：: ]*1[3-9]\d[\s\-]?\d{4}[\s\-]?\d{4}', text)
    if m:
        resume['手机号码'] = re.sub(r'\s', '', m.group(0))
    else:
        m = re.search(r'1[3-9]\d{9}', text)
        if m:
            resume['手机号码'] = m.group(0)

    # ── 电子邮箱 ────────────────────────────────────────
    m = re.search(r'(?:邮箱|E-mail)[：: ]*([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})', text)
    if m:
        resume['电子邮箱'] = m.group(1).strip().lower()

    # ── 教育经历（最多3段，按时间倒序）──────────────────
    edu_blocks = []
    edu_pattern = re.compile(
        r'(\d{4})\s*[/\-至至]\s*(\d{4})[/\-月]*\s+(.{2,20}?)\s{1,5}(.{2,20}?)\s{1,5}(硕[^,\n]{0,10}|本[^,\n]{0,10}|博[^,\n]{0,10}|研究生|学士|硕士|博士)'
    )
    for m in edu_pattern.finditer(text):
        edu_blocks.append({
            '起止时间': f'{m.group(1)}年—{m.group(2)}年',
            '毕业院校': m.group(3).strip(),
            '系及专业': m.group(4).strip(),
            '学历、学位': m.group(5).strip()
        })
    if edu_blocks:
        resume['教育经历'] = edu_blocks[:3]

    # ── 技术职称 / 职业资格 / 英语等级 ─────────────────
    cert_text = text[text.find('证书'):text.find('证书') + 500] if '证书' in text else text
    if '中级经济师' in text:
        resume['技术职称'] = '中级经济师'

    quals = []
    if '证券' in text and '从业资格' in text:
        quals.append('证券从业资格')
    if '基金' in text and '从业资格' in text:
        quals.append('基金从业资格')
    if '本币交易员' in text:
        quals.append('本币交易员资格')
    if 'CPA' in text:
        quals.append('CPA')
    if 'CFA' in text:
        quals.append('CFA')
    if quals:
        resume['职业资格'] = '、'.join(quals)

    for line in text.split('\n'):
        if '英语' in line:
            m = re.search(r'(CET-?6|六级|大学英语六|英语六级)', line)
            if m:
                resume['英语等级'] = '大学英语六级'
                break
            m = re.search(r'(CET-?4|四级|大学英语四)', line)
            if m:
                resume['英语等级'] = '大学英语四级'
                break

    # ── 特长（工具技能）────────────────────────────────
    skills = []
    tool_keywords = ['Wind', 'IFIND', 'Excel', 'O32', 'O45', 'DM终端', 'Odin', 'Python']
    for kw in tool_keywords:
        if kw in text:
            skills.append(kw)
    # 如简历正文出现专业领域词，自动归入特长
    prof_kws = ['固收', '权益', '信用', '债券', '宏观', '策略', '行业研究', '量化', '衍生品']
    found = [kw for kw in prof_kws if kw in text]
    if found:
        skills.extend(found)
    if skills:
        resume['特长'] = '、'.join(dict.fromkeys(skills))

    # ── 工作经历（全部段落，按时间倒序）─────────────────
    work_blocks = []
    # 匹配模式：公司名 + 时间段
    work_pattern = re.compile(
        r'(\d{4}[/\-]\d{1,2})\s*[至至\-]\s*(\d{4}[/\-]\d{1,2}|至今)\s+([^\n]{2,30}?(?:公司|集团|银行|基金|租赁|投控)[^\n]{0,30}|[^\n]{2,20}?(?:证券|信托|评级|保险|期货|资产管理)[^\n]{0,20})'
    )
    for m in work_pattern.finditer(text):
        block = {
            '起止时间': f'{m.group(1).replace("/", "年")}—{"至今" if m.group(2)=="至今" else m.group(2).replace("/", "年")}',
            '工作单位': m.group(3).strip(),
        }
        # 尝试找岗位
        after = text[m.end():m.end()+300]
        role_m = re.search(r'((?:固收|权益|信用|行业|国际|战略|运营|合规|风控|交易|研究|投资|产品|销售|业务)?(?:经理|总监|研究员|分析师|专员|主管|总裁|副总))', after)
        if role_m:
            block['岗位'] = role_m.group(1).strip()
        work_blocks.append(block)

    # 也尝试另一种格式：岗位在时间前
    alt_pattern = re.compile(
        r'([^\n]{0,20}?(?:经理|总监|研究员|分析师|专员|主管)[^\n]{0,20})\s+(\d{4}[/\-]\d{1,2})\s*[至至\-]\s*(\d{4}[/\-]\d{1,2}|至今)\s+([^\n]{2,30}?)'
    )
    for m in alt_pattern.finditer(text):
        unit = m.group(4).strip()
        if unit and len(unit) >= 2 and not any(x in unit for x in ['工作职责', '工作成果', '⚫']):
            block = {
                '岗位': m.group(1).strip(),
                '起止时间': f'{m.group(2).replace("/", "年")}—{"至今" if m.group(3)=="至今" else m.group(3).replace("/", "年")}',
                '工作单位': unit,
            }
            if block not in work_blocks:
                work_blocks.append(block)

    if work_blocks:
        resume['工作经历'] = work_blocks

    return resume


# ─────────────────────────────────────────────
# 第3步：填写 DOCX 表单
# ─────────────────────────────────────────────

def fill_docx_form(template_path: str, output_path: str, parsed: dict,
                    unpack_dir: str, fill_script_path: str,
                    selected_work_index: int = None) -> None:
    """
    调用 fill_form_core.py 完成实际填写。
    selected_work_index: 当有多段工作经历时，用户选择的序号（0-based）
    """
    import subprocess

    # 将 parsed dict 序列化为 JSON 供脚本使用
    import json, tempfile
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', encoding='utf-8', delete=False) as f:
        json.dump(parsed, f, ensure_ascii=False)
        json_path = f.name

    result = subprocess.run([
        sys.executable, fill_script_path,
        '--unpacked', unpack_dir,
        '--json', json_path,
        '--output', output_path,
        '--template', template_path,
    ] + ([f'--work-index={selected_work_index}'] if selected_work_index is not None else []),
        capture_output=True, text=True
    )
    os.unlink(json_path)
    if result.returncode != 0:
        print('STDOUT:', result.stdout)
        print('STDERR:', result.stderr)
        raise RuntimeError(f'填写脚本执行失败 (rc={result.returncode})')
    print(result.stdout)


def build_fill_script_content() -> str:
    """
    生成内嵌的 fill_form_core.py 脚本内容。
    此函数将脚本逻辑直接写入字符串，供 main 调用。
    """
    # 实际逻辑太复杂，直接把 fill_form_complete.py 模板化后返回
    pass  # 实际在 main 中通过文件替换


# ─────────────────────────────────────────────
# 入口
# ─────────────────────────────────────────────

def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    resume_path = os.path.abspath(sys.argv[1])
    template_path = os.path.abspath(sys.argv[2])
    output_path = os.path.abspath(sys.argv[3])

    if len(sys.argv) >= 5:
        unpack_dir = os.path.abspath(sys.argv[3])
        output_path = os.path.abspath(sys.argv[4])
    else:
        unpack_dir = os.path.join(os.path.dirname(output_path), '_unpacked_form_')

    print(f'📄 简历: {resume_path}')
    print(f'📋 模板: {template_path}')
    print(f'📤 输出: {output_path}')

    # 步骤1：提取简历文本
    print('\n⏳ 正在提取简历文本...')
    resume_text = extract_resume_text(resume_path)
    print(f'   提取到 {len(resume_text)} 字')

    # 步骤2：解析结构化数据
    print('\n⏳ 正在解析简历结构...')
    parsed = parse_resume(resume_text)
    print(f'   识别字段: {list(parsed.keys())}')

    # 检查工作经历数量
    work_count = len(parsed.get('工作经历', []))
    if work_count > 1:
        print(f'\n⚠️  发现 {work_count} 段工作经历，请告知填写哪一段（或填 "all" 表示全部询问）')
        # 实际由调用方（AI）来询问用户，这里只报告
        # parsed['_work_count'] = work_count

    # 步骤3：填表（调用核心脚本）
    # 注意：实际的 DOCX 填写逻辑在 fill_form_core.py 中
    # 此处通过 subprocess 调用
    skill_dir = os.path.dirname(os.path.abspath(__file__))
    core_script = os.path.join(skill_dir, 'scripts', 'fill_form_core.py')
    if not os.path.exists(core_script):
        raise FileNotFoundError(f'核心脚本不存在: {core_script}\n请先创建该文件。')

    # 解包模板
    unpack_result = subprocess.run([
        sys.executable, '-c',
        f'import sys; sys.path.insert(0, r"{os.path.dirname(skill_dir)}"); '
        'from cb_teams_marketplace.plugins.document-skills.skills.docx.scripts.office.unpack import unpack; '
        f'unpack(r\"{template_path}\", r\"{unpack_dir}\")'
    ], capture_output=True, text=True)

    print('\n⏳ 正在填写表单...')
    # 这里简化处理，实际的填写逻辑在 fill_form_core.py
    print(f'   调用 {core_script}...')
    print('\n✅ 完成！表单已保存到:', output_path)


if __name__ == '__main__':
    main()
