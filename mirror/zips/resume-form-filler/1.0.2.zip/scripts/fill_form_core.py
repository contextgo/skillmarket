#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fill_form_core.py — 填写表单核心逻辑
由 fill_form.py 调用，或直接被 AI Agent 使用。

参数：
    --unpacked   解包后的表单 XML 目录
    --json       解析后的简历数据（JSON 格式）
    --output     输出 docx 路径
    --template   原始模板路径（用于 pack 打包）
    --work-index 选中的工作经历序号（0-based），默认 0

使用示例：
    python fill_form_core.py --unpacked ./unpacked/ --json ./parsed.json \
        --output ./output.docx --template ./template.docx --work-index 0
"""

import sys
import os
import json
import re
import shutil
import subprocess


def make_run_xml(text: str, indent: str = '            ') -> str:
    """生成带格式的 <w:r> XML 片段"""
    return (
        f'{indent}<w:r>\n'
        f'{indent}  <w:rPr>\n'
        f'{indent}    <w:rFonts w:ascii="仿宋_GB2312" w:hAnsi="仿宋_GB2312"/>\n'
        f'{indent}    <w:color w:val="000000"/>\n'
        f'{indent}    <w:kern w:val="0"/>\n'
        f'{indent}  </w:rPr>\n'
        f'{indent}  <w:t xml:space="preserve">{text}</w:t>\n'
        f'{indent}</w:r>\n'
    )


def insert_text_after_label_in_cell(content: str, label: str,
                                     value: str, occurrence: int = 1) -> str:
    """
    在 document.xml 中找到 label 的第 occurrence 个标签，
    在其后紧跟的空白单元格（无 <w:t> 内容）中插入文字。
    返回修改后的 content。
    """
    if not value:
        return content

    label_tag = f'<w:t>{label}</w:t>'
    pos = -1
    count = 0
    search_start = 0
    while count < occurrence:
        pos = content.find(label_tag, search_start)
        if pos == -1:
            print(f'  [SKIP] 标签 "{label}" 第 {occurrence} 次未找到')
            return content
        count += 1
        search_start = pos + 1

    # 找到该 label 所在单元格末尾
    tc_end = content.find('</w:tc>', pos)
    if tc_end == -1:
        print(f'  [SKIP] 标签 "{label}" 后未找到 </w:tc>')
        return content

    # 找下一个单元格（值单元格）
    next_tc_start = content.find('<w:tc>', tc_end)
    if next_tc_start == -1:
        print(f'  [SKIP] 标签 "{label}" 后未找到值单元格')
        return content
    next_tc_end = content.find('</w:tc>', next_tc_start)
    cell_xml = content[next_tc_start:next_tc_end]

    # 如果该单元格已有文字（可能是另一个标签），跳过
    if '<w:t>' in cell_xml or '<w:t ' in cell_xml:
        print(f'  [SKIP] 标签 "{label}" 的值单元格已有内容，跳过')
        return content

    ppr_end = cell_xml.find('</w:pPr>')
    if ppr_end == -1:
        print(f'  [SKIP] 标签 "{label}" 的值单元格无 </w:pPr>')
        return content

    insert_pos = next_tc_start + ppr_end + len('</w:pPr>')
    run = '\n' + make_run_xml(value)
    content = content[:insert_pos] + run + content[insert_pos:]
    print(f'  [OK] {label} = {value}')
    return content


def fill_work_section_work、单位_label(content: str, unit: str, dates: str,
                                        role: str, duties: str, perf: str) -> str:
    """填写工作经历区块（通过工作单位标签定位）"""
    if unit:
        content = _fill_cell_after_label(content, '工作单位', unit)

    # 起止时间：找第二个"起止时间"（第一个在教育经历）
    qiz_label = '起止时间</w:t>'
    pos1 = content.find(qiz_label)
    pos2 = content.find(qiz_label, pos1 + 1) if pos1 != -1 else -1
    if pos2 != -1 and dates:
        tc_end = content.find('</w:tc>', pos2)
        val_start = content.find('<w:tc>', tc_end)
        val_end = content.find('</w:tc>', val_start)
        cell = content[val_start:val_end]
        if '<w:t>' not in cell and '<w:t ' not in cell:
            ppr = cell.find('</w:pPr>')
            if ppr != -1:
                ip = val_start + ppr + len('</w:pPr>')
                content = content[:ip] + '\n' + make_run_xml(dates) + content[ip:]
                print(f'  [OK] 起止时间(工作) = {dates}')

    if role:
        content = insert_text_after_label_in_cell(content, '岗位', role)

    if duties:
        content = _fill_multiline_field(content, '工作职责', duties)

    if perf:
        content = _fill_multiline_field(content, '相关业绩', perf)

    return content


def _fill_cell_after_label(content: str, label: str, value: str) -> str:
    """通过标签填充紧邻的空白单元格"""
    label_tag = f'<w:t>{label}</w:t>'
    pos = content.find(label_tag)
    if pos == -1:
        print(f'  [SKIP] 未找到标签: {label}')
        return content
    tc_end = content.find('</w:tc>', pos)
    val_tc_start = content.find('<w:tc>', tc_end)
    val_tc_end = content.find('</w:tc>', val_tc_start)
    cell = content[val_tc_start:val_tc_end]
    if '<w:t>' in cell or '<w:t ' in cell:
        return content
    ppr = cell.find('</w:pPr>')
    if ppr == -1:
        return content
    ip = val_tc_start + ppr + len('</w:pPr>')
    content = content[:ip] + '\n' + make_run_xml(value) + content[ip:]
    print(f'  [OK] {label} = {value}')
    return content


def _fill_multiline_field(content: str, label: str, value: str) -> str:
    """填充多行文本字段"""
    label_tag = f'<w:t>{label}</w:t>'
    pos = content.find(label_tag)
    if pos == -1:
        print(f'  [SKIP] 未找到标签: {label}')
        return content
    tc_end = content.find('</w:tc>', pos)
    val_tc_start = content.find('<w:tc>', tc_end)
    val_tc_end = content.find('</w:tc>', val_tc_start)
    cell = content[val_tc_start:val_tc_end]
    if '<w:t>' in cell or '<w:t ' in cell:
        return content
    ppr = cell.find('</w:pPr>')
    jc = cell.find('<w:jc')
    insert_local = ppr + len('</w:pPr>') if ppr != -1 else -1
    if insert_local == -1 and jc != -1:
        jc_end = cell.find('/>', jc)
        if jc_end != -1:
            insert_local = jc_end + 2
    if insert_local == -1:
        return content
    ip = val_tc_start + insert_local
    content = content[:ip] + '\n' + make_run_xml(value) + content[ip:]
    print(f'  [OK] {label} 已填写（多行）')
    return content


def fill_education_rows(content: str, edu_list: list) -> str:
    """填写教育经历表格（最多3行，按时间倒序）"""
    edu_label = '学历、学位</w:t>'
    pos = content.find(edu_label)
    if pos == -1:
        print('  [SKIP] 未找到教育经历表头')
        return content

    tc_end = content.find('</w:tc>', pos)
    tr_end = content.find('</w:tr>', tc_end)
    search_pos = tr_end

    for row_idx, edu in enumerate(edu_list[:3]):
        tr_start = content.find('<w:tr ', search_pos)
        tr_end_idx = content.find('</w:tr>', tr_start)
        if tr_start == -1:
            break
        tr_content = content[tr_start:tr_end_idx]

        tc_positions = []
        tc_search = 0
        while True:
            s = tr_content.find('<w:tc>', tc_search)
            if s == -1:
                break
            e = tr_content.find('</w:tc>', s)
            tc_positions.append((s, e + len('</w:tc>')))
            tc_search = e + 1

        # tc[0]=vMerge(跳过), tc[1]=起止时间, tc[2]=毕业院校, tc[3]=系及专业, tc[4]=学历学位
        edu_vals = [
            edu.get('起止时间', ''),
            edu.get('毕业院校', ''),
            edu.get('系及专业', ''),
            edu.get('学历、学位', ''),
        ]

        for cell_idx in reversed(range(1, min(5, len(tc_positions)))):
            val_idx = cell_idx - 1
            if val_idx >= len(edu_vals) or not edu_vals[val_idx]:
                continue
            val = edu_vals[val_idx]
            s, e = tc_positions[cell_idx]
            cell_xml = tr_content[s:e]
            if '<w:t>' in cell_xml or '<w:t ' in cell_xml:
                continue
            ppr = cell_xml.find('</w:pPr>')
            if ppr == -1:
                continue
            insert_local = ppr + len('</w:pPr>')
            run = '\n' + make_run_xml(val)
            shift = len(run)
            tr_content = tr_content[:s + insert_local] + run + tr_content[s + insert_local:]
            # 修正后续偏移
            for i in range(cell_idx + 1, len(tc_positions)):
                tc_positions[i] = (tc_positions[i][0] + shift, tc_positions[i][1] + shift)
            print(f'    第{row_idx + 1}行 第{cell_idx}格: {val}')

        new_tr_end = content.find('</w:tr>', tr_start + len(tr_content))
        content = content[:tr_start] + tr_content + content[new_tr_end + len('</w:tr>'):]
        search_pos = tr_start + len(tr_content)

    return content


def pack_docx(unpacked_dir: str, output_path: str, template_path: str) -> None:
    """调用 docx pack 脚本打包"""
    skill_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    pack_py = os.path.join(skill_root,
        '..', '..',  # 向上两级到 plugins
        'cb_teams_marketplace', 'plugins', 'document-skills',
        'skills', 'docx', 'scripts', 'office', 'pack.py')
    pack_py = os.path.normpath(pack_py)

    result = subprocess.run(
        [sys.executable, pack_py, unpacked_dir, output_path,
         '--original', template_path],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        print('PACK ERR:', result.stderr.decode('utf-8', errors='replace'))
        raise RuntimeError('打包失败')
    print(result.stdout)


# ─────────────────────────────────────────────
# 入口
# ─────────────────────────────────────────────

def main():
    args = sys.argv[1:]

    # 简单参数解析
    i = 0
    kwargs = {}
    while i < len(args):
        if args[i] == '--unpacked':
            kwargs['unpacked'] = args[i + 1]; i += 2
        elif args[i] == '--json':
            kwargs['json_path'] = args[i + 1]; i += 2
        elif args[i] == '--output':
            kwargs['output'] = args[i + 1]; i += 2
        elif args[i] == '--template':
            kwargs['template'] = args[i + 1]; i += 2
        elif args[i].startswith('--work-index='):
            kwargs['work_index'] = int(args[i].split('=')[1]); i += 1
        else:
            i += 1

    unpacked = kwargs['unpacked']
    json_path = kwargs.get('json_path')
    output = kwargs['output']
    template = kwargs.get('template', '')
    work_index = kwargs.get('work_index', 0)

    # 读取解析数据
    if json_path and os.path.exists(json_path):
        with open(json_path, 'r', encoding='utf-8') as f:
            parsed = json.load(f)
    else:
        # 从环境变量或 stdin 读取
        parsed = json.loads(sys.stdin.read())

    doc_xml_path = os.path.join(unpacked, 'word', 'document.xml')
    with open(doc_xml_path, 'r', encoding='utf-8') as f:
        content = f.read()

    print('\n=== 基本信息 ===')
    basic_fields = [
        ('姓名', parsed.get('姓名')),
        ('性别', parsed.get('性别')),
        ('出生年月', parsed.get('出生年月')),
        ('民族', parsed.get('民族')),
        ('政治面貌', parsed.get('政治面貌')),
        ('健康状况', parsed.get('健康状况')),
        ('参加工作时间', parsed.get('参加工作时间')),
        ('手机号码', parsed.get('手机号码')),
        ('电子邮箱', parsed.get('电子邮箱')),
    ]
    for field, value in basic_fields:
        if value:
            content = insert_text_after_label_in_cell(content, field, value)

    print('\n=== 教育经历 ===')
    if '教育经历' in parsed and parsed['教育经历']:
        content = fill_education_rows(content, parsed['教育经历'])
    else:
        print('  [SKIP] 无教育经历数据')

    print('\n=== 技能资格 ===')
    skill_fields = [
        ('技术职称', parsed.get('技术职称')),
        ('职业资格', parsed.get('职业资格')),
        ('英语等级', parsed.get('英语等级')),
        ('特长', parsed.get('特长')),
    ]
    for field, value in skill_fields:
        if value:
            content = insert_text_after_label_in_cell(content, field, value)

    print('\n=== 工作经历 ===')
    work_list = parsed.get('工作经历', [])
    if not work_list:
        print('  [SKIP] 无工作经历数据')
    else:
        # 默认选最新一段（索引0，因为按时间倒序）
        sel = work_list[work_index] if work_index < len(work_list) else work_list[0]
        content = fill_work_section_work、单位_label(
            content,
            unit=sel.get('工作单位', ''),
            dates=sel.get('起止时间', ''),
            role=sel.get('岗位', ''),
            duties=parsed.get('_work_duties', ''),     # 需外部传入
            perf=parsed.get('_work_perf', ''),          # 需外部传入
        )

    with open(doc_xml_path, 'w', encoding='utf-8') as f:
        f.write(content)

    print('\n=== 打包输出 ===')
    if template and os.path.exists(template):
        pack_docx(unpacked, output, template)
    else:
        # 手动打包
        import zipfile
        os.makedirs(os.path.dirname(output), exist_ok=True)
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as zout:
            for root, dirs, files in os.walk(unpacked):
                for file in files:
                    fp = os.path.join(root, file)
                    arcname = os.path.relpath(fp, unpacked)
                    zout.write(fp, arcname)
        print(f'  [OK] 输出到: {output}')

    print('\n✅ 完成！')


if __name__ == '__main__':
    main()
