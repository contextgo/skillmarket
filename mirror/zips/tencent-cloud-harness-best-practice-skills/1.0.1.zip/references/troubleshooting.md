# 故障排查

## TAPD 侧

### HTTP 403 访问 workspace

**症状**：
```
curl -u user:pass https://api.tapd.cn/workspaces/get_workspace_info?workspace_id=xxx
HTTP 403
```

但 `/quickstart/testauth` 能返回 status=1。

**原因**：该 API 账号创建时没勾选 workspace 的授权。

**修复**：
1. 浏览器打开 `https://www.tapd.cn/<公司ID>/open_platform/config`（需公司管理员权限）
2. 找到该 API 账号 → 「编辑」或「授权项目」
3. 勾选目标 workspace
4. 保存后重跑 `install-harness.sh connect-tapd`

### HTTP 302 / 重定向到登录页

**原因**：通常是调错 base_url（把 `https://www.tapd.cn` 当 `https://api.tapd.cn`，或反过来）。

**修复**：确认：
- API 调用用 `https://api.tapd.cn`
- 浏览器界面跳转用 `https://www.tapd.cn`

### get_commit_msg 返回 "Hello world from TAPD API..."

**原因**：这个端点在公网 `api.tapd.cn` 没实现，是占位响应。

**修复**：三种 fallback：
1. 在 TAPD 工作项详情页右上角「复制源码提交关键字」
2. 如果装了 `mcp-server-tapd` MCP：让 AI agent 调 `get_commit_msg` 工具
3. 直接用最简格式 `--story=<id>`，TAPD 一样会解析

## CNB 侧

### HTTP 404 建仓接口

**症状**：`POST /orgs/<org>/repos` → 404 errcode: 5

**原因**：CNB 不走 GitHub 风格路径。

**修复**：改成 `POST /<org>/-/repos`，body 用 `visibility_level: "Private"`。

### `/user/orgs` 返回 `[]`

**原因**：CNB 叫 groups。

**修复**：改成 `GET /user/groups`，响应字段叫 `access_role`（不是 `role`），仓库计数叫 `all_sub_repo_count`。

### push 拿到 403

**原因**：PAT scope 不够，或该 group 对当前用户不是 Owner/Maintainer。

**修复**：
1. 去 CNB 个人设置重新生成 PAT，勾 `repo`
2. 或换一个自己是 Owner 的 group

### AI Review 没在 PR 里评论

排查顺序：
1. `.cnb.yml` 的 `main: pull_request:` 下**是否有** `cnbcool/ai-review:latest` stage？
2. PR 的 **target 分支是 main 吗**？（只有 `main: pull_request:` 会触发对应 pipeline）
3. 去 CNB Web 仓库首页看流水线：AI review 的 pipeline 是否跑了？失败了看日志
4. AI 评论可能要 1~3 分钟，耐心等

### Mirror push 说 "remote rejected"

**原因**：
- 目标仓库 default branch 保护开启了
- 第一次 push 就包含 force-update（mirror push 会推所有 ref）

**修复**：
- 确认你是仓库 Owner
- 改用分支级 push：`git push cnb main`（推一条分支），不用 `--mirror`

## git hooks 侧

### commit 被拦截"未关联任何 TAPD 故事/缺陷/任务"

**原因**：commit message 里没有 `--story=<id>` / `--bug=<id>` / `--task=<id>`。

**修复**：任选其一：
- 去 TAPD 故事页右上角复制源码提交关键字，贴到 commit message
- 自己写：`--story=<TAPD 故事 ID>`
- 如果确实无单可关联：在 message 里加 `[harness-bypass]: <原因>`
- hotfix 场景：subject 以 "Merge "/"Revert \""/"Initial commit"/"chore: bump " 开头自动豁免

### push 被拦截"直推受保护分支"

**原因**：pre-push dispatcher 的 `protect-main` 特性生效。

**修复**：建 feature 分支走 PR 流程。紧急豁免：
- `HARNESS_ALLOW_MAIN_PUSH=1 git push cnb main`
- 或仓库根 `touch .harness-bypass` 然后 push，事后删文件
- 最后手段：`git push --no-verify`（跳所有 hooks）

### hook 完全没生效

**原因**：
- hook 文件不存在或非可执行
- 手动装的时候没 `chmod 755`
- `core.hooksPath` 配置被改了

**修复**：
```bash
ls -l .git/hooks/commit-msg .git/hooks/pre-push
# 首行应显示 "cnb-tapd-harness-managed ..."
# 权限应是 -rwxr-xr-x
git config --get core.hooksPath
# 如果指向别处，要么清掉 `git config --unset core.hooksPath`，要么把 hook 装到那里
```

### hook 手动测试报错 "not a git repo"

**原因**：`git rev-parse --show-toplevel` 在非 git 上下文下失败。

**修复**：跑 hook 前 `cd` 到仓库根，或从仓库根触发真实 git 操作（`git commit`、`git push`）。

## commit 没出现在 TAPD 故事「代码」Tab

按概率从高到低排查：

1. **commit message 里没关键字** → commit-msg hook 应该已经拦截了。如果是历史 commit，手动 `push-commit-to-tapd.sh <alias> <repo> <sha>` 补推

2. **TAPD 项目没启用 CNB 集成** → 去 `https://www.tapd.cn/<workspace_id>/settings/devops` 启用「云原生构建源码」→ 关联仓库

3. **API 账号没授权 workspace** → 见上面「HTTP 403 访问 workspace」

4. **仓库 push 到的是 github 而非 CNB** → `git remote -v` 确认 cnb remote 存在，push 用 `git push cnb <branch>`

5. **TAPD webhook 有延迟** → 通常 30 秒内。真的没回来，手动 push-commit-to-tapd.sh 兜底

## install-harness.sh setup 报错

### "缺 --tapd-alias （或 connections.yml 里 tapd.alias）"

setup 时要么传 `--tapd-alias=<name>`，要么 `.codebuddy/connections.yml` 已含 `tapd: alias: "<name>"`。先跑 `connect-tapd` 再跑 `setup`。

### "TAPD 凭据不存在，先跑 install-harness.sh connect-tapd"

`$HOME/.codebuddy/secrets/tapd/<alias>.json` 不存在。connect-tapd 一遍就有。

### "CNB 仓库检查/创建失败 (rc=X)"

rc=9 表示仓库已存在（复用）；其他 rc 表示 API 失败。手动验证：
```bash
curl -H "Authorization: Bearer $CNB_TOKEN" https://api.cnb.cool/<org>/<repo>
```

### `python3` 相关报错

setup 内部用 python3 改 connections.yml。确认 `which python3` 能找到。macOS 原生自带；Linux 可能需 `apt install python3`。

## 看不到自己的 CNB group

**原因**：CNB 注册后只有一个默认个人 group（形如 `cnb.<hash>`），需要用户自己建一个命名 group。

**修复**：
1. 浏览器打开 `https://cnb.cool`
2. 左上角切换器 → 新建组织
3. 重跑 `install-harness.sh connect-cnb` 或 `list-cnb-orgs.sh`

## 卸载没干净

`uninstall-harness.sh` 默认保留：
- 本地凭据文件（`~/.codebuddy/secrets/...`）
- CNB 远端仓库
- PR 模板里的 TAPD 段
- `.gitmessage` 模板
- `.gitignore` 里追加的行

如需彻底清理：
```bash
# 凭据
rm -rf ~/.codebuddy/secrets/tapd/<alias>.json ~/.codebuddy/secrets/cnb/<alias>.json

# PR 模板手动删除 "harness-skills managed section" 那段

# CNB 远端仓库去 Web UI 删

# .gitmessage
rm .gitmessage
git config --unset commit.template

# .gitignore 手动删除 "harness-skills: never commit local credentials" 那几行
```
