# Harness 完整工作流

## 人类 + AI 协作的标准剧本

```
                   TAPD（意图层）
                         │
                 ① 建故事 or 拿到 story_id
                         │
                         ▼
                start-feature.sh
                         │
                 ② 一键拉 feature 分支
                         │
                         ▼
              本地改代码 + commit
                         │
                ③ commit-msg hook 校验
                         │
                         ▼
              git push cnb feature/xxx
                         │
                ④ pre-push hook: 放行 feature/*，拒绝 main
                         │
                         ▼
                CNB 创建 PR
                         │
                 ⑤ cnbcool/ai-review 在 PR 评论里评审
                 ⑥ 常规 CI（test/lint）并行
                         │
                         ▼
                人类 reviewer 批准
                         │
                         ▼
                合入 main
                         │
                 ⑦ CNB webhook → TAPD 故事「代码」Tab
                         │
                         ▼
                故事闭环
```

## 每一步具体在干嘛

### ① 建 TAPD 故事

用户在 TAPD Web 界面建，或通过 MCP / Open API 自动建。故事 ID 形如 `<STORY_ID>`（19 位）：
- 前 2 位：prefix
- 接下来 8 位：workspace_id 的 8 位表示
- 最后 9 位：序列号

### ② start-feature.sh

命令：`bash scripts/start-feature.sh <story_id>`

内部逻辑：
1. 读仓库的 `.codebuddy/connections.yml` 获得 `tapd.alias` 和 `workspace_id`
2. 用对应 TAPD 凭据查故事标题（尝试 story / bug / task 三种端点）
3. 把标题 slug 化：`tr '[:upper:]' '[:lower:]'` → `sed -E 's/[^a-z0-9]+/-/g'` → 限 40 字符
4. 分支名：`feature/<story_id 最后 7 位>-<slug>`
5. 先 `git fetch` base（默认 main），然后 `git checkout -b` 新分支
6. 顺便调 tapd-commit-tag.sh 拿 commit 关键字（到剪贴板）

### ③ commit-msg hook 校验

hook 逻辑：
1. 读 `.git/hooks/commit-msg` 收到 commit message 文件路径
2. 检查豁免（`.harness-bypass` / subject 是 Merge/Revert/Initial / message 含 `[harness-bypass]: <原因>`）
3. 主校验：正则 `--(story|bug|task)=[0-9]+(@tapd-[0-9]+)?` 必须匹配
4. 未匹配时打印拒绝信息 + `.tapd.yml` 里的 workspace URL，exit 1

### ④ pre-push hook dispatcher

hook 在 `.git/hooks/pre-push`，按注入的 `HARNESS_FEATURES` 旗标分派：

- `protect-main`（默认开）：read stdin 拿到 `<local_ref> <local_sha> <remote_ref> <remote_sha>`，如果 `remote_ref=refs/heads/<受保护分支>` 则 exit 1
- `auto-tapd-push`（默认关）：对本次 push 的每个新 commit 调 push-commit-to-tapd.sh

### ⑤ CNB AI Review（cnbcool/ai-review）

触发：`.cnb.yml` 里 `main: pull_request:` 下有 `cnbcool/ai-review:latest` stage。

流水线启动时 CNB 注入 `CNB_TOKEN_FOR_AI`，插件内部调 CNB OpenAPI 的 AI 能力生成评审意见，发回 PR 评论。

可手动触发：在 PR 评论区 `@CodeBuddy 代码评审`。

### ⑥ 常规 CI

与 AI review 并行。`.cnb.yml` 把两者写成同级的 pipeline list，都挂在 `main: pull_request:` 下。

### ⑦ CNB → TAPD 自动回写

**前置**：在 TAPD 项目 → 项目设置 → DevOps → 启用「云原生构建源码」应用 → 用 CNB 授权码授权 → 关联目标 CNB 仓库。

启用后，CNB 每次 push 的 commit 都会 webhook 通知 TAPD。TAPD 解析 commit message 中的 `--story=xxx` / `--bug=xxx` 关键字，把 commit 绑到对应故事的「代码」Tab。

**备选路径**（不走 CNB-TAPD webhook）：本地 pre-push hook 带 `auto-tapd-push` 特性，调 `POST /code_commit_infos` 直接推给 TAPD。

## 客户演示的 6 步脚本

适合 15-20 分钟的 demo：

1. **开场**：打开 `https://cnb.cool/<org>/<repo>` 和 `https://www.tapd.cn/<ws>/prong/stories`，两边空仓库/空故事
2. **建故事**：在 TAPD 建个故事（30 秒）
3. **一键拉分支**：`bash scripts/start-feature.sh <story_id>`（10 秒）
4. **编辑 + commit**：改一个小地方，commit message 贴 TAPD 关键字，hook 放行
5. **push**：`git push cnb feature/xxx`，CNB 返回 PR 创建链接
6. **PR + AI review**：在 CNB 建 PR，等 1 分钟，AI 评审评论自动出现
7. **回看 TAPD 故事**：刷新故事「代码」Tab，commit 已经在那里了

观众看到的关键体验：
- **零上下文切换成本**：整个流程一个终端 + 两个浏览器 Tab 就够了
- **硬约束可见**：故意漏写 `--story=`，commit 被立刻拒绝并给出 URL
- **AI 介入可见**：PR 刚创建就有 AI 评论（不是人工）
- **反向追溯可见**：TAPD 故事里能看到这个需求的所有提交，点进去跳 CNB diff

## 装完后的工作习惯建议

- 每个 TAPD 故事都对应一个 feature 分支，禁止多个故事塞一个分支
- 一个 PR 原则上只改一个故事（commit 可多个，但 story id 应一致）
- `[harness-bypass]` 仅用于 infra 引导 commit、hotfix、纯文档修复
- 保护分支列表可在 `.tapd.yml` 里自定义（默认 main + master），release/* 类分支建议也加进去
