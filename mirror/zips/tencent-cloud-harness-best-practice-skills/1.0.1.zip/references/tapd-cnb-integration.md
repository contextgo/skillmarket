# TAPD × CNB 集成：所有已知事实

> 以下都是 2026-05 在公网 `api.tapd.cn` + `api.cnb.cool` 实战验证过的。

## TAPD Open API

### 路径和鉴权

- Base URL：`https://api.tapd.cn`
- 鉴权：HTTP Basic Auth，用 "API 账号" 而非登录账号/密码
- 获取 API 账号：公司管理 → API 账号管理 → `https://www.tapd.cn/<公司ID>/open_platform/config`（需公司管理员权限）
- **创建 API 账号时务必勾选目标 workspace 授权**，否则该账号对该项目的一切请求返回 403
- 公司 ID：登录 TAPD 后任意页 URL 第一段路径即是，如 `www.tapd.cn/<COMPANY_ID>/projects`

### 关键端点

| 功能 | 方法 | URL | 备注 |
|---|---|---|---|
| 验证凭据 | GET | `/quickstart/testauth` | 成功返回 `status=1`，data 是 hello world |
| 查 workspace | GET | `/workspaces/get_workspace_info?workspace_id=<id>` | 403 = 没授权 |
| 查 story | GET | `/stories?workspace_id=<id>&id=<story_id>` | 同 bugs / tasks |
| 建 story | POST | `/stories` | form: workspace_id, name, entity_type, ... |
| **推 commit** | POST | `/code_commit_infos` | JSON body，详见下文 |
| 列 commit | GET | `/code_commit_infos?workspace_id=<id>&type=story&object_id=<id>` | 按故事反查关联 commit |

### POST /code_commit_infos（关键）

Content-Type: `application/json`

Body：
```json
{
  "workspace_id": <WORKSPACE_ID>,
  "commit_id": "<full sha>",
  "commit_time": "YYYY-MM-DD HH:MM:SS",
  "author": "Burton",
  "repo": "<org>/<repo>",
  "repo_id": "<任意字符串，CNB 仓库 id 最佳>",
  "message": "<包含 --story=<id>@tapd-<ws> 的完整 commit message>",
  "files": ["M path/to/file.go", "A newfile.md"],
  "git_env": "cnb",
  "repo_url": "https://cnb.cool/<org>/<repo>",
  "commit_url": "https://cnb.cool/<org>/<repo>/-/commit/<sha>"
}
```

返回：`status=1, data.related=[{type, object_id, code: "SUCCESS"}, ...]`。TAPD 服务端自己解析 message 绑定对象。

**幂等性**：同一 commit_id 重复 POST 会产生不同 record id，但在 TAPD UI 上按 commit_id 去重（用户看到一条）。

### 源码提交关键字（TAPD 官方格式）

格式：
```
--story=<短ID>@tapd-<workspace_id> --user=<api_user> <标题> <故事短链>
```

例：
```
--story=<SHORT_ID>@tapd-<WORKSPACE_ID> --user=<API_USER> [需求标题] https://www.tapd.cn/<WORKSPACE_ID>/s/<SHORT_LINK_ID>
```

获取方式：
- **在 TAPD 故事详情页右上角「复制源码提交关键字」**（最可靠）
- 通过 `mcp-server-tapd` 调 `get_commit_msg(workspace_id, options={object_id, type})`
- Open API 上**公网没有暴露** get_commit_msg（端点返回 hello world 占位），只能走 MCP 或 Web

TAPD 服务端解析非常宽容：
- `--story=<SHORT_ID>`（短 ID）也接受
- `--story=<SHORT_ID>@tapd-<WORKSPACE_ID>`（带 workspace 后缀）
- `--bug=` / `--task=` 同理
- 多个并列也行：`--story=111 --story=222 --bug=333`

## CNB OpenAPI

### 路径和鉴权

- Base URL：`https://api.cnb.cool`
- Web：`https://cnb.cool`
- 鉴权：`Authorization: Bearer <PAT>`
- PAT 生成：个人设置 → 访问令牌（Access Tokens），scope 勾 `repo`

### 关键路径（与 GitHub 风格有区别！）

**心智模型**：CNB 采用 GitLab 风格路径，没有 `/repos/` 前缀，特殊资源用 `/-/` 分隔。

| 功能 | 方法 | URL | 备注 |
|---|---|---|---|
| 查当前用户 | GET | `/user` | 轻量探活 |
| 列用户所属 group | GET | `/user/groups` | **不是** `/user/orgs` |
| 列用户所有 repo | GET | `/user/repos` | - |
| 查 repo | GET | `/<org>/<repo>` | **不是** `/repos/<org>/<repo>` |
| 建 repo | POST | `/<org>/-/repos` | **不是** `/orgs/<org>/repos` |
| 删 repo | DELETE | `/<org>/<repo>` | 危险 |

### POST /<org>/-/repos

Body：
```json
{
  "name": "my-api",
  "visibility_level": "Private",
  "description": "..."
}
```

注意字段：
- `visibility_level`（首字母大写 `"Public"` / `"Private"`），**不是** `visibility`
- 返回 201，body 可能为空（成功后请 `GET /<org>/<repo>` 拿完整元数据）

### 撞名检测

先 `GET /<org>/<repo>`：
- 200 = 仓库已存在
- 404 (`errcode: 5`) = 可创建
- 401/403 = 权限问题

### Pipeline REST

**2026-05 实测：CNB 未公开 pipeline REST API**。以下路径全部返回 404：
- `/<org>/<repo>/pipelines`
- `/<org>/<repo>/-/pipelines`
- `/pipelines/<org>/<repo>`
- `/<org>/<repo>/-/workflows`
- `/<org>/<repo>/-/actions/runs`

查流水线状态唯一可靠路径：浏览器开 `https://cnb.cool/<org>/<repo>`。

## `.cnb.yml` 关键字段

顶层结构：`<branch_pattern>: <event>: [<pipeline>, ...]`

常见事件：
- `push`：main 分支每次 push 触发，用于构建/部署
- `pull_request`：PR 创建/更新触发，用于测试 + AI review

### AI Review 最小配置

```yaml
main:
  pull_request:
    - stages:
        - name: ai-code-review
          image: cnbcool/ai-review:latest
          settings:
            type: code-review
```

- 镜像：`cnbcool/ai-review:latest`
- `settings.type`：目前文档只列了 `code-review` 一个值
- 插件自动用 `CNB_TOKEN_FOR_AI` 调 AI，评论回写到 PR
- **不需要在仓库设置里手动开启**，写进 `.cnb.yml` 即生效

### NPC（被动触发）

PR 评论区输入：
- `@CodeBuddy 代码评审`（系统 NPC）
- `@cnb/feedback(评审专家) 代码评审`（自定义 NPC）

需要 `.cnb.yml` 配 `pull_request.comment@npc` 事件。详见 https://docs.cnb.cool/zh/build/npc.html。

### 其他 stage 常用语法

```yaml
stages:
  - name: go-test
    script:
      - go test -race -cover ./...
  - name: frontend-build       # 切镜像
    image: oven/bun:1
    script:
      - cd web
      - bun install --frozen-lockfile
      - bun run build
```

缓存：
```yaml
docker:
  volumes:
    - /root/.cache/go-build:copy-on-write
    - /go/pkg/mod:copy-on-write
```

## TAPD → CNB 双向集成

### CNB → TAPD（commit 回写）

TAPD 项目 → 项目设置 → DevOps → 「云原生构建源码」应用：
1. 启用应用
2. 用 **CNB 授权码** 授权（或手机号）
3. 关联目标 CNB 仓库

启用后，CNB 每次 push 自动 webhook TAPD，commit 出现在故事「代码」Tab。

**配置页真实 URL**：`https://www.tapd.cn/<workspace_id>/settings/devops`（项目级，**不是**公司级 `/company_admin/integrations`）。

### TAPD → CNB（反向跳转）

绑定后 PR / commit 里能看到关联的 TAPD 工作项；从 TAPD 也能发起 MR。

## 凭据管理

skill 约定三层：

1. **Session**：环境变量，只活当前 shell，推荐 CI 用
2. **User**：`~/.codebuddy/secrets/{tapd,cnb}/<alias>.json`，0600 权限，跨仓库可复用
3. **Project**：`<repo>/.codebuddy/connections.yml`，**仅元数据**（alias、workspace_id、repo_slug 等），**不含 token**，可 commit

`.gitignore` 强制追加 `.codebuddy/secrets/` 防止误 commit。

## 踩坑历史

| 坑 | 症状 | 解 |
|---|---|---|
| TAPD API 账号未勾 workspace 授权 | testauth OK 但 list workspace 全 403 | 回 `/<公司ID>/open_platform/config` 编辑勾选 |
| CNB 路径风格 | 用 GitHub 风格 `POST /orgs/<org>/repos` 全 404 | 改 `POST /<org>/-/repos` |
| CNB `/user/orgs` 返回 `[]` 或 404 | CNB 叫 groups | 用 `/user/groups` |
| CNB `visibility` 字段 | 返回"invalid param" | 改 `visibility_level`，值 `"Public"`/`"Private"` 首字母大写 |
| `awk '/^tapd:/,/^[a-z]/' conns.yml` 截断 | tapd: 自己就匹配 `^[a-z]`，range 只有 1 行 | 改状态机：in_sec 进段 + 下个顶层段退出 |
| pre-push hook 手动测试时 cwd 空 | `git rev-parse --show-toplevel` 失败 | 从 $0 路径反推仓库根 |
| 公网 TAPD API 无 get_commit_msg | 端点返回 "Hello world from TAPD API..." 占位 | 三种 fallback：MCP / Web 手复制 / `--story=<id>` 最简格式 |
