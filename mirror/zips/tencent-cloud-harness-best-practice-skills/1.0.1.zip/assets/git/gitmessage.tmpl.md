# <type>(<scope>): <subject>
#
# type: feat / fix / refactor / docs / test / chore / ci / infra / provider / script
# scope: 可选，模块名
# subject: 祈使句、≤50 字、首字母小写、不加句号
#
# body (可选，每行 ≤72 字，说明动机与影响):
#
#
# TAPD 关联（必须至少一条）：
#
#   推荐格式（TAPD CNB 集成可自动回写到故事"代码"页）：
#     --story=<短ID>@tapd-<workspace_id> --user=<api_user> <故事标题> <故事短链>
#     例: --story=<SHORT_ID>@tapd-<WORKSPACE_ID> --user=<API_USER> 登录接口 https://www.tapd.cn/<WORKSPACE_ID>/s/<SHORT_LINK_ID>
#
#   获取方式：
#     · TAPD 故事/缺陷/任务详情页 → 右上角「复制源码提交关键字」
#     · 或本地命令:
#         bash .codebuddy/skills/cnb-tapd-harness/scripts/tapd-commit-tag.sh <alias> <story_id> --copy
#
#   最简格式（只要校验通过，但不带 workspace 上下文）：
#     --story=<id>  |  --bug=<id>  |  --task=<id>
#
# 提交后，commit-msg hook 会校验 TAPD 关联，未关联将被拒绝。
# 紧急豁免: [harness-bypass]: <原因>
