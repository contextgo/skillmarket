<!-- cnb-tapd-harness managed PR template. 段落可增不可删，TAPD 关联段为必填 -->

## 关联 TAPD

- 需求 / 缺陷：<!-- 填写链接，如 https://www.tapd.cn/<workspace_id>/prong/stories/view/<id> -->
- 若无对应单，说明原因：<!-- 例如：紧急热修 / 仅改文档 -->

## 改动概述

<!-- 一段话说清楚做了什么、为什么 -->

## 影响面

- 影响模块：
- 数据库变更：是 / 否
- 配置变更：是 / 否
- 兼容性：
- 回滚策略：

## 验证方式

- [ ] 单元测试通过
- [ ] 本地集成测试通过
- [ ] （如适用）`terraform plan` 已粘贴到下方
- [ ] （如适用）前端截图已附上

## terraform plan（如适用）

```
<!-- paste plan output -->
```

## 截图 / 录屏

<!-- 前端改动必须有 -->

## Reviewer 重点关注

- 

---
<sub>此 PR 模板由 cnb-tapd-harness 维护。规则见 `.codebuddy/rules/04-pr-style.md`。</sub>
