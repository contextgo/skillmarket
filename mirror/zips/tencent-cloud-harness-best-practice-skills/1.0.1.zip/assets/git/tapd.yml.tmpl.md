# .tapd.yml — 由 cnb-tapd-harness skill 生成
# 本文件可 commit，仅含公开元数据，不含任何凭据。
# 第三方工具（CI / commit-msg hook）可直接读取本文件拼 URL。

workspace_id: "{{TAPD_WORKSPACE_ID}}"
workspace_name: "{{TAPD_WORKSPACE_NAME}}"
base_url: "{{TAPD_BASE_URL}}"

# 严格度：strict | warn | template
# 当前 skill 版本固定为 strict（commit 不带 --story= 会被拒绝）
strictness: "strict"

# 豁免规则
bypass:
  token: "[harness-bypass]"              # message 含此 token + 原因时放行
  emergency_file: ".harness-bypass"      # 仓库根存在此文件时全部放行
  subject_patterns:                      # 以下 subject 开头的 commit 自动放行
    - "Merge "
    - "Revert \""
    - "Initial commit"
    - "chore: bump "
    - "docs: typo"
    - "Squashed commit of "

# 详细规则见:
#   .codebuddy/rules/03-commit-style.md
#   .codebuddy/skills/cnb-tapd-harness/references/tapd-fields-map.md
