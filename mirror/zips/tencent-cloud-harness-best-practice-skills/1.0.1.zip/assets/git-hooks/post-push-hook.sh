#!/usr/bin/env bash
# post-push hook — cnb-tapd-harness 自动把新 commit 推给 TAPD
#
# 触发时机: git 没有真正的 post-push hook，用 alias / pre-push 都不完美
#           这里用 pre-push 的"之后"模式：在 pre-push 最后调 push-commit-to-tapd.sh
#
# stdin 格式（git 规定）: <local_ref> <local_sha> <remote_ref> <remote_sha>
# 我们只对推送到名为 cnb 的 remote 才触发
#
# 安装路径: <repo>/.git/hooks/pre-push
# 维护:     由 cnb-tapd-harness skill 安装与更新（带 marker）

set -eu

REMOTE_NAME="$1"    # git pre-push 的第一个参数：remote 别名
REMOTE_URL="$2"     # 第二个：remote URL

REPO_ROOT=$(git rev-parse --show-toplevel)

# 只在推送到名为 cnb 的 remote 或 URL 含 cnb.cool 时触发
if [[ "$REMOTE_NAME" != "cnb" ]] && [[ "$REMOTE_URL" != *"cnb.cool"* ]]; then
  exit 0
fi

# 读 connections.yml 里的 tapd alias
CONN="$REPO_ROOT/.codebuddy/connections.yml"
if [[ ! -f "$CONN" ]]; then
  exit 0
fi

TAPD_ALIAS=$(awk '
  /^tapd:[[:space:]]*$/ {in_sec=1; next}
  /^[A-Za-z]/ {if(in_sec==1) in_sec=0}
  in_sec && /^[[:space:]]+alias:/ {
    sub(/.*alias:[[:space:]]*"?/, "");
    sub(/".*/, "");
    sub(/[[:space:]].*/, "");
    print; exit
  }' "$CONN")

if [[ -z "${TAPD_ALIAS:-}" ]]; then
  exit 0   # 没 TAPD 绑定，跳过
fi

# 找 skill 根：优先 .codebuddy/skills/cnb-tapd-harness，其次用户级
SKILL_DIR=""
if [[ -d "$REPO_ROOT/.codebuddy/skills/cnb-tapd-harness/scripts" ]]; then
  SKILL_DIR="$REPO_ROOT/.codebuddy/skills/cnb-tapd-harness"
elif [[ -d "$HOME/.codebuddy/skills/cnb-tapd-harness/scripts" ]]; then
  SKILL_DIR="$HOME/.codebuddy/skills/cnb-tapd-harness"
else
  # 也允许通过环境变量指定（WorkBuddy 等工程下 skill 在别处）
  if [[ -n "${HARNESS_SKILL_DIR:-}" ]] && [[ -d "$HARNESS_SKILL_DIR/scripts" ]]; then
    SKILL_DIR="$HARNESS_SKILL_DIR"
  fi
fi

if [[ -z "$SKILL_DIR" ]]; then
  echo "⚠  [harness] skill 目录未找到，跳过 TAPD 推送" >&2
  exit 0
fi

PUSH_SCRIPT="$SKILL_DIR/scripts/push-commit-to-tapd.sh"
if [[ ! -x "$PUSH_SCRIPT" ]]; then
  exit 0
fi

# stdin 形如: refs/heads/main <new_sha> refs/heads/main <old_sha>
# 对每一行（本次 push 涉及的每个 ref）取 new_sha..old_sha 之间的 commits
# 对每个 commit 调 push-commit-to-tapd.sh
echo "" >&2
echo "── [harness] 把 push 的 commits 同步到 TAPD ──" >&2

pushed=0
failed=0
while read -r local_ref local_sha remote_ref remote_sha; do
  [[ -z "$local_ref" ]] && continue
  # 删除分支 push 不处理
  if [[ "$local_sha" =~ ^0+$ ]]; then
    continue
  fi

  # 首次 push（remote_sha 全零）：只推最新一条 commit，避免一次推几百条
  if [[ "$remote_sha" =~ ^0+$ ]]; then
    commits="$local_sha"
  else
    commits=$(git rev-list --reverse "$remote_sha..$local_sha" 2>/dev/null || echo "")
  fi

  for c in $commits; do
    if "$PUSH_SCRIPT" "$TAPD_ALIAS" "$REPO_ROOT" "$c" >/dev/null 2>&1; then
      echo "  ✓ $c → TAPD" >&2
      pushed=$((pushed + 1))
    else
      # 退出码 1 是"message 里没 --story"，正常情况（bypass commit 就是这样）
      # 其他退出码才算真失败
      rc=$?
      if [[ $rc -eq 1 ]]; then
        echo "  - $c (无 TAPD 关键字，跳过)" >&2
      else
        echo "  ✗ $c (TAPD 推送失败 rc=$rc)" >&2
        failed=$((failed + 1))
      fi
    fi
  done
done

echo "── [harness] TAPD 同步完成: 成功 $pushed, 失败 $failed ──" >&2
echo "" >&2

# pre-push 的返回码决定 git push 是否继续：即使 TAPD 推送失败也不阻断 git push
# 用户仍可手动用 scripts/push-commit-to-tapd.sh 补推
exit 0
