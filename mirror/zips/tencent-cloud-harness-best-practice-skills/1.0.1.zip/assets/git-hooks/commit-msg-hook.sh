#!/usr/bin/env bash
# commit-msg hook — cnb-tapd-harness 严格模式 A
# 拒绝未关联 TAPD 故事/缺陷/任务的 commit。
#
# 安装路径: <repo>/.git/hooks/commit-msg
# 权限:     0755
# 维护:     由 cnb-tapd-harness skill 安装与更新。手动编辑会被下次重装覆盖。
#
# 豁免:
#   1. subject 匹配 Merge / Revert / Initial commit / chore: bump / docs: typo
#   2. message 含 [harness-bypass]: <reason>
#   3. 仓库根存在 .harness-bypass 文件（临时总开关）

set -eu

COMMIT_MSG_FILE="$1"
COMMIT_MSG=$(cat "$COMMIT_MSG_FILE")
REPO_ROOT=$(git rev-parse --show-toplevel)

# ---------- 豁免 3: 临时总开关 ----------
if [[ -f "$REPO_ROOT/.harness-bypass" ]]; then
  exit 0
fi

# ---------- 豁免 1: 特殊 subject ----------
SUBJECT=$(printf '%s' "$COMMIT_MSG" | head -n1)
case "$SUBJECT" in
  "Merge "*)               exit 0 ;;
  "Revert \""*)            exit 0 ;;
  "Initial commit")        exit 0 ;;
  "chore: bump "*)         exit 0 ;;
  "docs: typo"*)           exit 0 ;;
  "Squashed commit of "*)  exit 0 ;;
esac

# ---------- 豁免 2: [harness-bypass] ----------
if printf '%s' "$COMMIT_MSG" | grep -q "\[harness-bypass\]"; then
  # 必须带理由
  if printf '%s' "$COMMIT_MSG" | grep -qE "\[harness-bypass\]:.+"; then
    echo "⚠️  harness-bypass activated. commit will proceed." >&2
    exit 0
  else
    echo "❌ [harness-bypass] present but no reason given." >&2
    echo "   请改成 [harness-bypass]: <原因说明>" >&2
    exit 1
  fi
fi

# ---------- 主校验 ----------
# TAPD CNB 集成要求 commit message 含形如以下关键字（两种格式均接受）：
#   短格式（基础）：  --story=<STORY_ID>
#   官方格式（推荐）：--story=<SHORT_ID>@tapd-<WORKSPACE_ID> --user=<API_USER>
# 官方格式可在 TAPD 工作项详情页右上角「复制源码提交关键字」，或用 skill:
#   bash scripts/tapd-commit-tag.sh <alias> <story_id> --copy
# 正则说明：支持 --story / --bug / --task 三种，值为数字 ID，可选 "@tapd-<workspace>" 后缀
if printf '%s' "$COMMIT_MSG" | grep -qE -- '--(story|bug|task)=[0-9]+(@tapd-[0-9]+)?'; then
  exit 0
fi

# ---------- 未通过：打印指引 ----------
# 读 .tapd.yml 拼 TAPD URL
TAPD_URL=""
if [[ -f "$REPO_ROOT/.tapd.yml" ]]; then
  # 简陋解析（只提取 workspace_id 和 base_url）
  ws_id=$(grep -E "^\s*workspace_id:" "$REPO_ROOT/.tapd.yml" 2>/dev/null | sed -E 's/.*workspace_id:[[:space:]]*"?([0-9]+)"?.*/\1/' | head -1)
  base=$(grep -E "^\s*base_url:" "$REPO_ROOT/.tapd.yml" 2>/dev/null | sed -E 's/.*base_url:[[:space:]]*"?([^"]+)"?.*/\1/' | head -1)
  base="${base:-https://www.tapd.cn}"
  if [[ -n "${ws_id:-}" ]]; then
    TAPD_URL="${base%/}/$ws_id/prong/stories"
  fi
fi

cat >&2 <<EOF

❌ commit 被 cnb-tapd-harness 拦截

原因: commit message 未关联任何 TAPD 故事/缺陷/任务。

修复方式（任选其一）:

  1. 推荐：复制 TAPD 官方源码提交关键字（会被 CNB 自动回写到故事页）
     a) 打开 TAPD 故事/缺陷/任务详情页 → 右上角「复制源码提交关键字」
        粘贴到 commit message 即可，形如：
          --story=<SHORT_ID>@tapd-<WORKSPACE_ID> --user=<api_user> <title>
     b) 或用 skill 命令：
          bash .codebuddy/skills/cnb-tapd-harness/scripts/tapd-commit-tag.sh \\
               <alias> <story_id> --copy

  2. 基础格式（也可通过，但不带 workspace 上下文）：
       --story=<id>  |  --bug=<id>  |  --task=<id>

  3. 如果确实无单可关联（紧急热修 / 仅改文档），追加:
       [harness-bypass]: <简短原因>
     在 message 任意一行。

  4. 特殊 subject（Merge / Revert / Initial / docs: typo / chore: bump）会自动豁免。

去找 TAPD 单: ${TAPD_URL:-"（.tapd.yml 缺 workspace_id，无法生成链接）"}

详见: .codebuddy/rules/03-commit-style.md

EOF

exit 1
