#!/usr/bin/env bash
# protect-main hook — cnb-tapd-harness 阻止直推受保护分支
#
# 逻辑: 当本次 push 会更新 main / master / release/* 等保护分支时拒绝，
#      引导走 feature 分支 + PR 流程，让 CNB AI Review 有机会介入。
#
# 豁免:
#   · 仓库根存在 .harness-bypass 文件
#   · push 命令带了 --no-verify（git 会直接跳过所有 hook，本 hook 不需额外处理）
#   · 环境变量 HARNESS_ALLOW_MAIN_PUSH=1
#
# 输入（git pre-push 规范）：
#   stdin 每行: <local_ref> <local_sha> <remote_ref> <remote_sha>

set -eu

REMOTE_NAME="${1:-}"
REMOTE_URL="${2:-}"

REPO_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || echo "")
if [[ -z "$REPO_ROOT" ]]; then
  exit 0
fi

# 豁免 1: 仓库根 .harness-bypass
if [[ -f "$REPO_ROOT/.harness-bypass" ]]; then
  exit 0
fi

# 豁免 2: 环境变量
if [[ "${HARNESS_ALLOW_MAIN_PUSH:-0}" == "1" ]]; then
  exit 0
fi

# 读保护分支列表（.tapd.yml 里可自定义）
PROTECTED_BRANCHES="main master"
if [[ -f "$REPO_ROOT/.tapd.yml" ]]; then
  custom=$(awk '
    /^protected_branches:/ {in_sec=1; next}
    /^[A-Za-z]/ {if(in_sec==1) in_sec=0}
    in_sec && /^[[:space:]]*-[[:space:]]/ {
      sub(/^[[:space:]]*-[[:space:]]*"?/, "");
      sub(/".*/, "");
      sub(/[[:space:]].*/, "");
      print
    }' "$REPO_ROOT/.tapd.yml" 2>/dev/null | tr '\n' ' ')
  if [[ -n "$custom" ]]; then
    PROTECTED_BRANCHES="$custom"
  fi
fi

blocked=0
blocked_refs=""
while read -r local_ref local_sha remote_ref remote_sha; do
  [[ -z "$local_ref" ]] && continue
  # remote_ref 形如 refs/heads/main
  branch_name="${remote_ref#refs/heads/}"
  for protected in $PROTECTED_BRANCHES; do
    if [[ "$branch_name" == "$protected" ]]; then
      blocked=1
      blocked_refs="$blocked_refs $branch_name"
    fi
  done
done

if [[ $blocked -eq 1 ]]; then
  cat >&2 <<EOF

❌ push 被 cnb-tapd-harness 拦截

原因: 直推受保护分支 ($blocked_refs ) 不被允许。
      受保护分支应通过 Pull Request 流程合入，以触发 CNB AI Review 和人类审阅。

建议流程:
  1. 新建 feature 分支（可用 skill 命令一步生成）:
       bash .codebuddy/skills/cnb-tapd-harness/scripts/start-feature.sh <story_id>
     或手动:
       git checkout -b feature/<story_id>-<slug>

  2. 提交改动（hook 会校验 TAPD 关联）:
       git add ... && git commit -m "..."

  3. 推 feature 分支:
       git push cnb feature/<story_id>-<slug>

  4. 去 CNB (https://cnb.cool) 创 Pull Request → main
     · AI Review 会自动在 PR 评论里给出代码评审意见
     · 人类 reviewer 批准后合入 main

紧急豁免（慎用）:
  · 临时：在命令前加环境变量  HARNESS_ALLOW_MAIN_PUSH=1 git push ...
  · 仓库级：创建  .harness-bypass  文件（记得事后删除）
  · 跳过所有 hook（最后手段）： git push --no-verify

EOF
  exit 1
fi

exit 0
