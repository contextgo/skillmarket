#!/usr/bin/env bash
# pre-push dispatcher — cnb-tapd-harness 统一 pre-push 入口
#
# git 每个仓只能有 1 个 pre-push hook，这里做统一调度：
#   · 总是校验 "不能直推保护分支"（除非显式豁免）
#   · 可选：把 commits 自动同步到 TAPD（opt-in，由 install 时控制）
#
# 安装时 install-commit-hook.sh 会在头部注入：
#   HARNESS_FEATURES="protect-main[,auto-tapd-push]"
#   HARNESS_SKILL_DIR="/.../cnb-tapd-harness"
#
# stdin: git pre-push 规范
# args:  $1=remote_name  $2=remote_url

set -eu

REMOTE_NAME="${1:-}"
REMOTE_URL="${2:-}"

# 确保 cwd 是仓库根，hook 被 git 调用时 cwd 应该已是，但手动测试时需兜底
if ! REPO_ROOT=$(git rev-parse --show-toplevel 2>/dev/null); then
  # 从 $0 的路径反推（$0 形如 .../<repo>/.git/hooks/pre-push）
  hook_self="$(cd "$(dirname "$0")" && pwd)"
  candidate="${hook_self%/.git/hooks}"
  if [[ "$candidate" != "$hook_self" ]] && [[ -d "$candidate/.git" ]]; then
    cd "$candidate"
    REPO_ROOT="$candidate"
  else
    exit 0
  fi
fi

FEATURES="${HARNESS_FEATURES:-protect-main}"
SKILL_DIR="${HARNESS_SKILL_DIR:-}"

# 保存 stdin 到临时文件，因为要给多个子 hook 复用
STDIN_TMP=$(mktemp)
trap 'rm -f "$STDIN_TMP"' EXIT
cat > "$STDIN_TMP"

run_sub_hook() {
  local script="$1"
  if [[ ! -f "$script" ]]; then
    return 0
  fi
  bash "$script" "$REMOTE_NAME" "$REMOTE_URL" < "$STDIN_TMP"
  return $?
}

# ---------- protect-main（默认开）----------
if [[ ",$FEATURES," == *",protect-main,"* ]]; then
  if [[ -n "$SKILL_DIR" ]] && [[ -f "$SKILL_DIR/assets/tapd/protect-main-hook.sh" ]]; then
    if ! run_sub_hook "$SKILL_DIR/assets/tapd/protect-main-hook.sh"; then
      exit 1
    fi
  fi
fi

# ---------- auto-tapd-push（可选）----------
if [[ ",$FEATURES," == *",auto-tapd-push,"* ]]; then
  if [[ -n "$SKILL_DIR" ]] && [[ -f "$SKILL_DIR/assets/tapd/post-push-hook.sh" ]]; then
    # 这里调子 hook 的退出码不阻断 git push（只记录）
    run_sub_hook "$SKILL_DIR/assets/tapd/post-push-hook.sh" || true
  fi
fi

exit 0
