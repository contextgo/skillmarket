#!/usr/bin/env bash
# push-commit-to-tapd.sh — 把一个 git commit 推给 TAPD（POST /code_commit_infos）
#
# 背景: TAPD 原生 CNB 集成（公司管理→服务集成→云原生构建）需要 Web 授权 + 关联仓库。
#      在开通之前（或不想走 Web 集成时），本脚本直接调 TAPD Open API
#      `POST /code_commit_infos`，由 TAPD 服务端解析 commit message 中的 `--story=<id>@tapd-<ws>`
#      关键字，自动绑定到对应故事/缺陷/任务，同样会出现在故事详情页「代码」Tab。
#
# 用法:
#   push-commit-to-tapd.sh <tapd-alias> <repo-path> <commit-sha> [--repo-id=xxx]
#
# 参数:
#   tapd-alias   TAPD 凭据 alias（如 new-api）
#   repo-path    本地 git 仓库路径
#   commit-sha   要推的 commit SHA（支持短/长 SHA）
#   --repo-id    可选，CNB 仓库 id，不传会从 connections.yml 里读
#
# 必要条件:
#   · commit message 中已含 `--story=<id>`、`--bug=<id>` 或 `--task=<id>`
#   · TAPD alias 已绑定目标 workspace
#   · 目标 repo 在 connections.yml 的 cnb 段（用于拼 repo/repo_id/commit_url）
#
# 行为:
#   1. 读 TAPD 凭据 + 读 .codebuddy/connections.yml 拿 workspace_id / cnb.repo_slug / cnb.repo_id
#   2. 用 git 提取 commit_id/commit_time/author/message/file changes
#   3. POST /code_commit_infos，Basic Auth
#   4. 打印 TAPD 返回的 related 列表（绑定到哪些故事）
#
# 退出码:
#   0 绑定成功（至少一条 related.code=SUCCESS）
#   1 API 返回 status=1 但 related 为空（commit msg 没关键字）
#   2 参数错误 / 依赖缺失
#   3 凭据 / connections.yml 不存在
#   4 TAPD API 调用失败
#
# 踩坑 (2026-05-06)：
#   · 端点是 /code_commit_infos（单数 commit + 复数 infos）
#   · body 必须 JSON（Content-Type: application/json），不是 form-urlencoded
#   · files 是 "<op> <path>" 字符串数组，op 在 A/M/D/U 中选
#   · commit_time 格式 "YYYY-MM-DD HH:MM:SS"（不含时区）
#   · git_env 设成 "gitlab" 时 TAPD 界面展示 commit 的方式最接近 CNB

set -euo pipefail

# ---------- 参数 ----------
tapd_alias=""
repo_path=""
commit_sha=""
override_repo_id=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --repo-id=*) override_repo_id="${1#--repo-id=}"; shift ;;
    -h|--help)
      sed -n '2,20p' "$0"
      exit 0
      ;;
    *)
      if [[ -z "$tapd_alias" ]]; then tapd_alias="$1"
      elif [[ -z "$repo_path" ]]; then repo_path="$1"
      elif [[ -z "$commit_sha" ]]; then commit_sha="$1"
      fi
      shift
      ;;
  esac
done

if [[ -z "$tapd_alias" || -z "$repo_path" || -z "$commit_sha" ]]; then
  echo "Usage: $0 <tapd-alias> <repo-path> <commit-sha> [--repo-id=xxx]" >&2
  exit 2
fi

if [[ ! -d "$repo_path/.git" ]]; then
  echo "ERROR: not a git repo: $repo_path" >&2
  exit 2
fi

for bin in jq python3 git; do
  command -v "$bin" >/dev/null 2>&1 || { echo "ERROR: need $bin" >&2; exit 2; }
done

# ---------- 凭据 ----------
ROOT="${CODEBUDDY_SECRETS_ROOT:-$HOME/.codebuddy/secrets}"
cred_file="$ROOT/tapd/$tapd_alias.json"
if [[ ! -f "$cred_file" ]]; then
  echo "ERROR: TAPD credential not found: $cred_file" >&2
  exit 3
fi
api_user=$(jq -r '.api_user' "$cred_file")
api_password=$(jq -r '.api_password' "$cred_file")
base_url=$(jq -r '.base_url // "https://api.tapd.cn"' "$cred_file")

# ---------- connections.yml ----------
conn_file="$repo_path/.codebuddy/connections.yml"
if [[ ! -f "$conn_file" ]]; then
  echo "ERROR: $conn_file not found, run P2/P3 first" >&2
  exit 3
fi

workspace_id=$(awk '
  /^tapd:[[:space:]]*$/ {in_sec=1; next}
  /^[A-Za-z]/ {if(in_sec==1) in_sec=0}
  in_sec && /^[[:space:]]+workspace_id:/ {
    sub(/.*workspace_id:[[:space:]]*"?/, "");
    sub(/".*/, "");
    sub(/[[:space:]].*/, "");
    print; exit
  }' "$conn_file")

cnb_repo_slug=$(awk '
  /^cnb:[[:space:]]*$/ {in_sec=1; next}
  /^[A-Za-z]/ {if(in_sec==1) in_sec=0}
  in_sec && /^[[:space:]]+repo_slug:/ {
    sub(/.*repo_slug:[[:space:]]*"?/, "");
    sub(/".*/, "");
    sub(/[[:space:]].*/, "");
    print; exit
  }' "$conn_file")

cnb_web=$(awk '
  /^cnb:[[:space:]]*$/ {in_sec=1; next}
  /^[A-Za-z]/ {if(in_sec==1) in_sec=0}
  in_sec && /^[[:space:]]+web_url:/ {
    sub(/.*web_url:[[:space:]]*"?/, "");
    sub(/".*/, "");
    sub(/[[:space:]].*/, "");
    print; exit
  }' "$conn_file")

if [[ -z "$workspace_id" ]]; then
  echo "ERROR: connections.yml 缺 tapd.workspace_id" >&2
  exit 3
fi

repo_id="$override_repo_id"
if [[ -z "$repo_id" ]]; then
  repo_id=$(awk '
    /^cnb:[[:space:]]*$/ {in_sec=1; next}
    /^[A-Za-z]/ {if(in_sec==1) in_sec=0}
    in_sec && /^[[:space:]]+repo_id:/ {
      sub(/.*repo_id:[[:space:]]*"?/, "");
      sub(/".*/, "");
      sub(/[[:space:]].*/, "");
      print; exit
    }' "$conn_file" 2>/dev/null || true)
fi
# repo_id 不是必须，TAPD 允许为空（但建议传）
repo_id="${repo_id:-unknown}"

cnb_web="${cnb_web:-https://cnb.cool/$cnb_repo_slug}"

# ---------- git 数据 ----------
cd "$repo_path"
full_sha=$(git rev-parse "$commit_sha")
commit_time=$(git show -s --format=%ci "$full_sha" | awk '{print $1" "$2}')
author=$(git show -s --format=%an "$full_sha")
message=$(git show -s --format=%B "$full_sha")

# 预检：message 必须含 --story/--bug/--task 关键字
if ! printf '%s' "$message" | grep -qE -- '--(story|bug|task)=[0-9]+'; then
  echo "ERROR: commit $full_sha 的 message 未含 --story/--bug/--task 关键字" >&2
  echo "       TAPD 无法绑定，拒绝推送" >&2
  exit 1
fi

# 文件变更
files_json=$(git show --name-status --format= "$full_sha" \
  | awk 'NF{
      op = substr($1,1,1);
      for(i=2;i<=NF;i++){path=path" "$i} sub(/^ /,"",path);
      printf "\"%s %s\"\n", op, path; path="";
    }' \
  | jq -Rsc 'split("\n") | map(select(length>0))')

commit_url="$cnb_web/-/commit/$full_sha"

# ---------- 构造 payload ----------
payload=$(jq -n \
  --argjson ws "$workspace_id" \
  --arg cid "$full_sha" \
  --arg ctime "$commit_time" \
  --arg author "$author" \
  --arg repo "$cnb_repo_slug" \
  --arg rid "$repo_id" \
  --arg msg "$message" \
  --argjson files "$files_json" \
  --arg repo_url "$cnb_web" \
  --arg curl "$commit_url" \
  '{
    workspace_id: $ws,
    commit_id: $cid,
    commit_time: $ctime,
    author: $author,
    repo: $repo,
    repo_id: $rid,
    message: $msg,
    files: $files,
    git_env: "gitlab",
    repo_url: $repo_url,
    commit_url: $curl
  }')

# ---------- 发送 ----------
tmp_resp=$(mktemp)
http_code=$(curl -s --max-time 15 \
  -o "$tmp_resp" -w "%{http_code}" \
  -u "$api_user:$api_password" \
  -X POST \
  -H "Content-Type: application/json" \
  -d "$payload" \
  "$base_url/code_commit_infos" 2>/dev/null || echo "000")

resp=$(cat "$tmp_resp")
rm -f "$tmp_resp"

# ---------- 结果解析 ----------
if [[ "$http_code" != "200" ]]; then
  echo "❌ TAPD API HTTP $http_code" >&2
  echo "$resp" | head -c 300 >&2
  exit 4
fi

status=$(echo "$resp" | jq -r '.status // 0')
if [[ "$status" != "1" ]]; then
  info=$(echo "$resp" | jq -r '.info // "unknown"')
  echo "❌ TAPD 返回失败: $info" >&2
  exit 4
fi

# 统计 related 数量
related_count=$(echo "$resp" | jq -r '.data.related | length // 0')
if [[ "$related_count" == "0" ]]; then
  echo "⚠  TAPD 接受了 commit 但未绑定任何对象（message 里的 story/bug/task id 可能不存在）" >&2
  exit 1
fi

echo "✅ 推送成功 · 绑定 $related_count 个对象："
echo "$resp" | jq -r '.data.related[] | "   \(.type)=\(.object_id) → \(.code)"'

echo ""
echo "TAPD commit record id: $(echo "$resp" | jq -r '.data.id')"
echo "验证：在故事详情页「代码」Tab 应能看到此 commit。"
