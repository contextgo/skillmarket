#!/usr/bin/env bash
# install-cnb-ci.sh — 按栈自动选 .cnb.yml 模板并写入仓库
#
# 用法:
#   install-cnb-ci.sh install <repo-path> [<template-override>]
#   install-cnb-ci.sh status  <repo-path>
#   install-cnb-ci.sh remove  <repo-path>
#
# template-override (可选): go | node | python | terraform | mixed-go-node
# 不传则读 .codebuddy/intel/stack.json 自动选
#
# 行为:
#   - 如仓库根已有 .cnb.yml：
#     · 若开头有 "# cnb-tapd-harness managed" 标记 → 覆盖
#     · 否则备份为 .cnb.yml.backup-<ts>
#   - 安装新模板，开头注入 managed 标记
#   - 不自动 commit；由调用方或用户手动 commit（走 commit-msg hook）

set -euo pipefail

cmd="${1:-}"
repo_path="${2:-}"
override="${3:-}"

SKILL_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_ROOT="$(cd "$SKILL_DIR/../.." && pwd)"
ASSETS="$SKILL_ROOT/assets/cnb-templates"

MARKER="# cnb-tapd-harness managed"

if [[ -z "$cmd" || -z "$repo_path" ]]; then
  echo "Usage: $0 {install|status|remove} <repo-path> [<template-override>]" >&2
  exit 2
fi

if [[ ! -d "$repo_path" ]]; then
  echo "ERROR: not a directory: $repo_path" >&2
  exit 2
fi

TARGET="$repo_path/.cnb.yml"

# ---------- pick template ----------
pick_template() {
  local primary=""
  local languages=""
  local frameworks=""

  local stack_json="$repo_path/.codebuddy/intel/stack.json"
  if [[ -f "$stack_json" ]] && command -v jq >/dev/null 2>&1; then
    primary=$(jq -r '.primary // empty' "$stack_json" 2>/dev/null || true)
    languages=$(jq -r '.languages // [] | join(",")' "$stack_json" 2>/dev/null || true)
    frameworks=$(jq -r '.frameworks // [] | join(",")' "$stack_json" 2>/dev/null || true)
  fi

  # mixed: go + (javascript/typescript)
  if [[ "$primary" == "go" ]] && [[ ",$languages," == *",javascript,"* || ",$languages," == *",typescript,"* ]]; then
    echo "mixed-go-node"
    return
  fi

  case "$primary" in
    go) echo "go" ;;
    typescript|javascript) echo "node" ;;
    python) echo "python" ;;
    terraform) echo "terraform" ;;
    *)
      # 退而求其次：按存在的文件推断
      if [[ -f "$repo_path/go.mod" ]]; then echo "go"; return; fi
      if [[ -f "$repo_path/package.json" ]]; then echo "node"; return; fi
      if [[ -f "$repo_path/pyproject.toml" || -f "$repo_path/requirements.txt" ]]; then echo "python"; return; fi
      if ls "$repo_path"/*.tf 2>/dev/null | head -1 | grep -q '.tf$'; then echo "terraform"; return; fi
      echo "go" # 兜底
      ;;
  esac
}

case "$cmd" in
  install)
    tmpl_name="${override:-$(pick_template)}"
    tmpl_file="$ASSETS/${tmpl_name}.cnb.yml"
    if [[ ! -f "$tmpl_file" ]]; then
      echo "ERROR: template not found: $tmpl_file" >&2
      echo "       available: $(ls "$ASSETS" | grep .cnb.yml | sed 's/\.cnb\.yml$//' | tr '\n' ' ')" >&2
      exit 2
    fi

    # 备份已有 .cnb.yml
    if [[ -f "$TARGET" ]]; then
      if head -5 "$TARGET" 2>/dev/null | grep -q "$MARKER"; then
        echo "✓ existing .cnb.yml is harness-managed, will overwrite"
      else
        ts=$(date +%Y%m%d%H%M%S)
        backup="$TARGET.backup-$ts"
        mv "$TARGET" "$backup"
        echo "✓ backed up existing .cnb.yml to: $backup"
      fi
    fi

    # 写入（注入 MARKER 到首行）
    {
      echo "$MARKER  template=$tmpl_name  installed_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
      cat "$tmpl_file"
    } > "$TARGET"

    echo "✅ installed: $TARGET (template=$tmpl_name)"
    echo ""
    echo "下一步:"
    echo "  1. 检查 .cnb.yml 是否需要调整（分支名、镜像版本、测试命令）"
    echo "  2. git add .cnb.yml && git commit（别忘了 --story=<TAPD id>）"
    echo "  3. git push cnb main（mirror 模式）或 git push（migrate 模式）"
    echo "  4. 到 cnb.cool 查流水线运行状态，或跑 verify-cnb-pipeline.sh"
    ;;

  status)
    if [[ ! -f "$TARGET" ]]; then
      echo "cnb.yml:           ❌ not installed"
      exit 0
    fi
    if head -5 "$TARGET" 2>/dev/null | grep -q "$MARKER"; then
      header=$(head -1 "$TARGET")
      echo "cnb.yml:           ✅ installed"
      echo "  $header"
    else
      echo "cnb.yml:           ⚠  present but NOT harness-managed"
    fi
    ;;

  remove)
    if [[ ! -f "$TARGET" ]]; then
      echo "no .cnb.yml at $TARGET"
      exit 0
    fi
    if head -5 "$TARGET" 2>/dev/null | grep -q "$MARKER"; then
      rm -f "$TARGET"
      echo "✓ removed harness-managed .cnb.yml"
      backups=$(ls "$repo_path"/.cnb.yml.backup-* 2>/dev/null | sort -r || true)
      if [[ -n "$backups" ]]; then
        latest=$(echo "$backups" | head -1)
        echo ""
        echo "发现旧 .cnb.yml 备份: $latest"
        echo "如需还原: mv '$latest' '$TARGET'"
      fi
    else
      echo "⚠ .cnb.yml is NOT harness-managed, refusing to remove" >&2
      exit 1
    fi
    ;;

  *)
    echo "Usage: $0 {install|status|remove} <repo-path> [<template-override>]" >&2
    exit 2
    ;;
esac
