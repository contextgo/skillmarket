#!/usr/bin/env bash
# create-cnb-repo.sh — 在 CNB 上创建仓库
#
# 用法:
#   create-cnb-repo.sh <alias> <org> <repo> [<visibility>] [<description>]
#
# visibility: private | public (默认 private)
#
# 踩坑修正（2026-05-06）：
#   - 查仓库：GET /<org>/<repo>                （不是 /repos/<org>/<repo>）
#   - 创建仓库：POST /<org>/-/repos              （不是 /orgs/<org>/repos）
#   - visibility 字段名：visibility_level = "Public" | "Private"
#
# 退出码:
#   0 创建成功
#   1 API 失败
#   2 参数错误
#   3 凭据不存在
#   9 撞名（已存在）

set -euo pipefail

alias_name="${1:?alias required}"
org="${2:?org required}"
repo="${3:?repo required}"
visibility="${4:-private}"
description="${5:-Mirrored by cnb-tapd-harness}"

# 规范化 visibility 到 CNB 约定
case "$visibility" in
  private|Private|PRIVATE) vis_level="Private" ;;
  public|Public|PUBLIC)    vis_level="Public"  ;;
  *) vis_level="Private" ;;
esac

SKILL_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="${CODEBUDDY_SECRETS_ROOT:-$HOME/.codebuddy/secrets}"
file="$ROOT/cnb/$alias_name.json"

if [[ ! -f "$file" ]]; then
  echo "ERROR: no stored credentials at $file" >&2
  exit 3
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "ERROR: jq required" >&2
  exit 2
fi

token=$(jq -r '.token' "$file")
endpoint=$(jq -r '.endpoint // "https://api.cnb.cool"' "$file")

# 1. 查撞名: GET /<org>/<repo>
check_code=$(curl -s -o /dev/null -w "%{http_code}" \
  --max-time 10 \
  -H "Authorization: Bearer $token" \
  "$endpoint/$org/$repo" 2>/dev/null || echo "000")

case "$check_code" in
  200)
    echo "⚠ 仓库已存在: $org/$repo" >&2
    echo "（调用方应决定复用或追加后缀再重试）" >&2
    curl -s --max-time 10 \
      -H "Authorization: Bearer $token" \
      "$endpoint/$org/$repo"
    exit 9
    ;;
  404)
    # 不存在，继续创建
    ;;
  401|403)
    echo "ERROR: 权限不足 (HTTP $check_code)，检查 PAT scope 或 group 访问权限" >&2
    exit 1
    ;;
  *)
    echo "ERROR: 撞名检查失败 (HTTP $check_code)" >&2
    exit 1
    ;;
esac

# 2. 创建: POST /<org>/-/repos
body=$(jq -n \
  --arg n "$repo" \
  --arg v "$vis_level" \
  --arg d "$description" \
  '{name: $n, visibility_level: $v, description: $d}')

create_resp=$(curl -s --max-time 15 \
  -X POST \
  -H "Authorization: Bearer $token" \
  -H "Content-Type: application/json" \
  -d "$body" \
  -w "\n%{http_code}" \
  "$endpoint/$org/-/repos" 2>/dev/null || echo $'\n000')

http_code=$(echo "$create_resp" | tail -n1)
resp_body=$(echo "$create_resp" | sed '$d')

case "$http_code" in
  201|200)
    echo "✅ 仓库已创建: $org/$repo" >&2
    # 201 可能 body 为空 → 回查一次拿元数据
    if [[ -z "$resp_body" ]]; then
      resp_body=$(curl -s --max-time 10 \
        -H "Authorization: Bearer $token" \
        "$endpoint/$org/$repo" 2>/dev/null || echo "{}")
    fi
    echo "$resp_body" | jq --arg org "$org" --arg repo "$repo" '{
      name: (.name // $repo),
      org: $org,
      full_name: "\($org)/\($repo)",
      clone_url: (.clone_url // "https://cnb.cool/\($org)/\($repo).git"),
      ssh_url: (.ssh_url // "git@cnb.cool:\($org)/\($repo).git"),
      web_url: (.web_url // "https://cnb.cool/\($org)/\($repo)"),
      visibility: (.visibility_level // "Private"),
      created_at: (.created_at // "unknown"),
      id: (.id // "unknown")
    }'
    exit 0
    ;;
  409)
    echo "⚠ 创建时返回冲突，可能是撞名 (HTTP 409)" >&2
    exit 9
    ;;
  401|403)
    echo "ERROR: 权限不足 (HTTP $http_code)" >&2
    echo "  · 检查 PAT scope 包含 repo" >&2
    echo "  · 检查当前身份在 $org 的 access_role 是 Owner/Maintainer" >&2
    exit 1
    ;;
  *)
    echo "ERROR: 创建失败 (HTTP $http_code)" >&2
    echo "response: $resp_body" >&2
    exit 1
    ;;
esac
