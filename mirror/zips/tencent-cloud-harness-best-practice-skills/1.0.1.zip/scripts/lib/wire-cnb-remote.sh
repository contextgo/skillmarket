#!/usr/bin/env bash
# wire-cnb-remote.sh — 配置 git remote 指向 CNB
#
# 用法:
#   wire-cnb-remote.sh add <repo-path> <cnb-url>         # mirror 模式：加 remote cnb
#   wire-cnb-remote.sh promote <repo-path> <cnb-url>     # 升级到 migrate：cnb 变 origin，原 origin 改名 github-backup
#   wire-cnb-remote.sh status <repo-path>                # 查当前 remote 状态
#   wire-cnb-remote.sh unwire <repo-path>                # 移除本 skill 配置的 remote
#
# 设计：
#   - remote URL 使用 HTTPS 明文（不含 token），依赖 git credential helper 或 ssh key 做认证
#   - mirror 模式：origin 保留（通常是 GitHub），新增 cnb
#   - migrate 模式：原 origin → github-backup，新 origin = cnb

set -euo pipefail

cmd="${1:-}"
repo_path="${2:-}"
cnb_url="${3:-}"

if [[ -z "$cmd" || -z "$repo_path" ]]; then
  echo "Usage: $0 {add|promote|status|unwire} <repo-path> [<cnb-url>]" >&2
  exit 2
fi

if [[ ! -d "$repo_path" ]]; then
  echo "ERROR: not a directory: $repo_path" >&2
  exit 2
fi

cd "$repo_path"

if ! git rev-parse --git-dir >/dev/null 2>&1; then
  echo "ERROR: not a git repository: $repo_path" >&2
  exit 2
fi

have_remote() {
  git remote | grep -qx "$1"
}

case "$cmd" in
  add)
    if [[ -z "$cnb_url" ]]; then
      echo "ERROR: cnb-url required for 'add'" >&2
      exit 2
    fi
    if have_remote "cnb"; then
      cur=$(git remote get-url cnb 2>/dev/null || true)
      if [[ "$cur" == "$cnb_url" ]]; then
        echo "✓ remote 'cnb' already set to $cnb_url"
      else
        git remote set-url cnb "$cnb_url"
        echo "✓ remote 'cnb' updated: $cur -> $cnb_url"
      fi
    else
      git remote add cnb "$cnb_url"
      echo "✓ remote 'cnb' added: $cnb_url"
    fi
    echo ""
    echo "（mirror 模式：origin 保留，推送到 CNB 用：git push cnb <branch>）"
    ;;

  promote)
    if [[ -z "$cnb_url" ]]; then
      echo "ERROR: cnb-url required for 'promote'" >&2
      exit 2
    fi
    # 幂等处理
    if have_remote "origin"; then
      cur_origin=$(git remote get-url origin 2>/dev/null)
      if [[ "$cur_origin" == "$cnb_url" ]]; then
        echo "✓ origin 已指向 CNB，无需升级"
        exit 0
      fi
      # 保存旧 origin 为 github-backup（如名字已占，追加数字）
      backup_name="github-backup"
      suffix=""
      i=1
      while have_remote "$backup_name$suffix"; do
        suffix="-$i"
        i=$((i+1))
      done
      git remote rename origin "$backup_name$suffix"
      echo "✓ 原 origin ($cur_origin) 改名为 $backup_name$suffix"
    fi

    # 移除 cnb remote（如存在），然后设为 origin
    if have_remote "cnb"; then
      git remote remove cnb
    fi
    git remote add origin "$cnb_url"
    echo "✓ origin 现在指向 CNB: $cnb_url"
    echo ""
    echo "（migrate 完成。后续 git push 默认推 CNB。原 GitHub 仍可访问：git push github-backup <branch>）"
    ;;

  status)
    echo "当前 remotes:"
    git remote -v
    echo ""
    if have_remote "cnb"; then
      echo "mode: mirror"
    elif have_remote "origin" && git remote get-url origin | grep -q "cnb.cool"; then
      if have_remote "github-backup"; then
        echo "mode: migrated"
      else
        echo "mode: cnb-only"
      fi
    else
      echo "mode: not wired"
    fi
    ;;

  unwire)
    removed=0
    if have_remote "cnb"; then
      url=$(git remote get-url cnb)
      git remote remove cnb
      echo "✓ removed remote 'cnb' ($url)"
      removed=1
    fi
    # migrate 模式下如何还原
    if have_remote "origin" && git remote get-url origin | grep -q "cnb.cool"; then
      if have_remote "github-backup"; then
        cnb_url_cur=$(git remote get-url origin)
        git remote remove origin
        git remote rename github-backup origin
        echo "✓ origin 恢复为原值；CNB URL ($cnb_url_cur) 已移除"
        removed=1
      else
        echo "⚠ origin 指向 CNB 但无 github-backup，不自动移除（避免无 remote）"
        echo "  如确定要移除：git remote remove origin"
      fi
    fi
    if [[ $removed -eq 0 ]]; then
      echo "(no harness-managed remote found)"
    fi
    exit 0
    ;;

  *)
    echo "Usage: $0 {add|promote|status|unwire} <repo-path> [<cnb-url>]" >&2
    exit 2
    ;;
esac
