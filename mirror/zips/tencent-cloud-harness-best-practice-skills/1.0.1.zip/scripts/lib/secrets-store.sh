#!/usr/bin/env bash
# secrets-store.sh — ~/.codebuddy/secrets/ 读写封装
#
# 用法:
#   secrets-store.sh put <kind> <alias> <json-payload-from-stdin>
#   secrets-store.sh get <kind> <alias>
#   secrets-store.sh list <kind>
#   secrets-store.sh delete <kind> <alias>
#   secrets-store.sh exists <kind> <alias>
#
# <kind>: tapd | cnb
# 所有 JSON 文件 0600，目录 0700。跨平台（macOS / Linux / Git-Bash on Windows）。

set -euo pipefail

ROOT="${CODEBUDDY_SECRETS_ROOT:-$HOME/.codebuddy/secrets}"

ensure_root() {
  local kind="$1"
  local dir="$ROOT/$kind"
  if [[ ! -d "$dir" ]]; then
    mkdir -p "$dir"
    chmod 700 "$dir" 2>/dev/null || true
    chmod 700 "$ROOT" 2>/dev/null || true
  fi
}

cmd="${1:-}"
case "$cmd" in
  put)
    kind="${2:?kind required}"
    alias_name="${3:?alias required}"
    ensure_root "$kind"
    file="$ROOT/$kind/$alias_name.json"
    # 从 stdin 读 JSON
    cat > "$file"
    chmod 600 "$file" 2>/dev/null || true
    echo "stored: $file"
    ;;
  get)
    kind="${2:?kind required}"
    alias_name="${3:?alias required}"
    file="$ROOT/$kind/$alias_name.json"
    if [[ ! -f "$file" ]]; then
      echo "ERROR: not found: $file" >&2
      exit 4
    fi
    cat "$file"
    ;;
  list)
    kind="${2:?kind required}"
    dir="$ROOT/$kind"
    if [[ ! -d "$dir" ]]; then
      echo ""
      exit 0
    fi
    # 输出纯 alias 名字（去掉 .json 后缀），一行一个
    find "$dir" -maxdepth 1 -type f -name "*.json" \
      -exec basename {} .json \; 2>/dev/null | sort
    ;;
  delete)
    kind="${2:?kind required}"
    alias_name="${3:?alias required}"
    file="$ROOT/$kind/$alias_name.json"
    if [[ -f "$file" ]]; then
      rm -f "$file"
      echo "deleted: $file"
    else
      echo "not present: $file"
    fi
    ;;
  exists)
    kind="${2:?kind required}"
    alias_name="${3:?alias required}"
    file="$ROOT/$kind/$alias_name.json"
    [[ -f "$file" ]] && exit 0 || exit 1
    ;;
  *)
    echo "Usage: $0 {put|get|list|delete|exists} <kind> [<alias>]" >&2
    exit 2
    ;;
esac
