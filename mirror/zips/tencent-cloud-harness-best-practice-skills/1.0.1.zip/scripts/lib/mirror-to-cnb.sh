#!/usr/bin/env bash
# mirror-to-cnb.sh — 把本地仓库完整推送（mirror）到 CNB
#
# 用法:
#   mirror-to-cnb.sh <alias> <repo-path> <cnb-clone-url>
#
# 行为:
#   1. 用 git clone --bare 克隆当前仓库到临时目录
#   2. git push --mirror 到 CNB（用 PAT 临时注入 URL）
#   3. 成功清理临时目录；失败不清理（便于排查）
#
# 设计：
#   - PAT 只用在本次 push 的 URL，不写入任何 git config
#   - 使用临时 ~/.git-credentials 或 askpass helper 确保不泄漏
#
# 退出码:
#   0 成功
#   1 推送失败
#   2 参数错
#   3 凭据不存在

set -euo pipefail

alias_name="${1:?alias required}"
repo_path="${2:?repo path required}"
cnb_url="${3:?cnb url required (https://cnb.cool/<org>/<repo>.git)}"

SKILL_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="${CODEBUDDY_SECRETS_ROOT:-$HOME/.codebuddy/secrets}"
file="$ROOT/cnb/$alias_name.json"

if [[ ! -f "$file" ]]; then
  echo "ERROR: no stored credentials at $file" >&2
  exit 3
fi

if [[ ! -d "$repo_path/.git" ]] && [[ ! -f "$repo_path/HEAD" ]]; then
  # 允许 bare 仓（有 HEAD 文件）或普通仓（有 .git 目录）
  echo "ERROR: not a git repo: $repo_path" >&2
  exit 2
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "ERROR: jq required" >&2
  exit 2
fi

token=$(jq -r '.token' "$file")

# 构造带 PAT 的 URL
# cnb_url: https://cnb.cool/<org>/<repo>.git
# 注入后: https://oauth2:<PAT>@cnb.cool/<org>/<repo>.git
if [[ "$cnb_url" =~ ^https?:// ]]; then
  # 拆 scheme 和 host 部分
  scheme="${cnb_url%%://*}"
  rest="${cnb_url#*://}"
  auth_url="${scheme}://oauth2:${token}@${rest}"
else
  echo "ERROR: cnb_url must be https://..." >&2
  exit 2
fi

# 临时 bare clone 目录
tmpdir=$(mktemp -d)
trap 'rm -rf "$tmpdir"' EXIT

echo "==> git clone --bare $repo_path -> $tmpdir/bare.git"
git clone --bare --quiet "$repo_path" "$tmpdir/bare.git"

cd "$tmpdir/bare.git"

echo "==> git push --mirror to CNB (token masked)"
# 用 subshell 确保 URL 中的 token 不落 shell 历史
set +e
push_output=$(GIT_TERMINAL_PROMPT=0 git push --mirror "$auth_url" 2>&1)
push_rc=$?
set -e

# 过滤输出中的 token（即使 git 输出完整 URL 也把 token 替换掉）
# 注意：使用 sed 可能在某些平台对特殊字符敏感，这里做简单替换
clean_output=$(echo "$push_output" | sed "s|oauth2:${token}@|oauth2:***@|g")

if [[ $push_rc -ne 0 ]]; then
  echo "❌ push 失败:" >&2
  echo "$clean_output" >&2
  exit 1
fi

echo "$clean_output"
echo ""
echo "✅ mirror 推送完成"
exit 0
