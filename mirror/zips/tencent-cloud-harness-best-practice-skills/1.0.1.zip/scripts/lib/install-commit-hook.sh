#!/usr/bin/env bash
# install-commit-hook.sh — 把严格模式 commit-msg hook 装到目标仓库
#
# 用法:
#   install-commit-hook.sh install <repo-root>
#   install-commit-hook.sh uninstall <repo-root>
#   install-commit-hook.sh status <repo-root>
#
# 行为:
#   install:
#     - 如已有 commit-msg hook，备份为 commit-msg.backup-<timestamp>
#     - 从 assets/tapd/commit-msg-hook.sh 复制新 hook 到 .git/hooks/commit-msg
#     - chmod 755
#     - 在 hook 顶部追加 `# cnb-tapd-harness-managed` 便于识别
#     - 同时装 .gitmessage 模板并 git config commit.template
#   uninstall:
#     - 如 .git/hooks/commit-msg 是 harness-managed，删除
#     - 若存在 commit-msg.backup-*，提示用户手动还原
#     - git config --unset commit.template（如指向 .gitmessage）
#   status:
#     - 打印当前 hook 是否已装 / 是否 harness-managed / commit.template 配置

set -euo pipefail

SKILL_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_ROOT="$(cd "$SKILL_DIR/../.." && pwd)"
HOOK_SRC="$SKILL_ROOT/assets/git-hooks/commit-msg-hook.sh"
PREPUSH_SRC="$SKILL_ROOT/assets/git-hooks/pre-push-dispatcher.sh"
GITMSG_SRC="$SKILL_ROOT/assets/git/gitmessage.tmpl.md"

MARKER="# cnb-tapd-harness-managed"

cmd="${1:-}"
repo="${2:-}"

if [[ -z "$repo" ]]; then
  echo "Usage: $0 {install|uninstall|status} <repo-root>" >&2
  exit 2
fi

if [[ ! -d "$repo" ]]; then
  echo "ERROR: not a directory: $repo" >&2
  exit 2
fi

cd "$repo"

# 必须是 git 仓库
git_dir=$(git rev-parse --git-dir 2>/dev/null || true)
if [[ -z "$git_dir" ]]; then
  echo "ERROR: $repo is not a git repository" >&2
  exit 3
fi

# 可能是 worktree，git_dir 可能为相对路径
if [[ "$git_dir" != /* ]]; then
  git_dir="$repo/$git_dir"
fi

HOOK_TARGET="$git_dir/hooks/commit-msg"
PREPUSH_TARGET="$git_dir/hooks/pre-push"
GITMSG_TARGET="$repo/.gitmessage"

case "$cmd" in
  install)
    # 1. 备份已有 hook
    if [[ -f "$HOOK_TARGET" ]]; then
      if head -20 "$HOOK_TARGET" 2>/dev/null | grep -q "$MARKER"; then
        echo "✓ existing hook is already harness-managed, will overwrite"
      else
        ts=$(date +%Y%m%d%H%M%S)
        backup="$HOOK_TARGET.backup-$ts"
        mv "$HOOK_TARGET" "$backup"
        echo "✓ backed up existing hook to: $backup"
      fi
    fi

    # 2. 装新 hook，注入 MARKER
    mkdir -p "$(dirname "$HOOK_TARGET")"
    {
      echo "#!/usr/bin/env bash"
      echo "$MARKER $(date -u +%Y-%m-%dT%H:%M:%SZ)"
      # 跳过原 shebang
      tail -n +2 "$HOOK_SRC"
    } > "$HOOK_TARGET"
    chmod 755 "$HOOK_TARGET"
    echo "✓ installed: $HOOK_TARGET"

    # 3. 装 .gitmessage 模板
    if [[ ! -f "$GITMSG_TARGET" ]]; then
      cp "$GITMSG_SRC" "$GITMSG_TARGET"
      echo "✓ installed: $GITMSG_TARGET"
    else
      echo "! .gitmessage already exists, skipped (please review merge manually)"
    fi

    # 4. 配置 git commit.template
    current=$(git config --get commit.template 2>/dev/null || true)
    if [[ "$current" != ".gitmessage" ]]; then
      git config commit.template .gitmessage
      echo "✓ git config commit.template = .gitmessage"
    fi

    # 5. 装 pre-push dispatcher（默认保护 main 分支，可选自动推 TAPD）
    features="protect-main"
    for arg in "$@"; do
      case "$arg" in
        --with-auto-push)      features="$features,auto-tapd-push" ;;
        --no-protect-main)     features="${features//protect-main/}"; features="${features//,,/,}"; features="${features#,}"; features="${features%,}" ;;
      esac
    done

    if [[ -f "$PREPUSH_TARGET" ]]; then
      if head -20 "$PREPUSH_TARGET" 2>/dev/null | grep -q "$MARKER"; then
        echo "✓ existing pre-push hook is harness-managed, will overwrite"
      else
        ts=$(date +%Y%m%d%H%M%S)
        mv "$PREPUSH_TARGET" "$PREPUSH_TARGET.backup-$ts"
        echo "✓ backed up existing pre-push hook to: $PREPUSH_TARGET.backup-$ts"
      fi
    fi

    {
      echo "#!/usr/bin/env bash"
      echo "$MARKER $(date -u +%Y-%m-%dT%H:%M:%SZ)"
      echo "export HARNESS_SKILL_DIR=\"$SKILL_ROOT\""
      echo "export HARNESS_FEATURES=\"$features\""
      tail -n +2 "$PREPUSH_SRC"
    } > "$PREPUSH_TARGET"
    chmod 755 "$PREPUSH_TARGET"
    echo "✓ installed: $PREPUSH_TARGET"
    echo "  ├─ protect-main: $(if [[ ",$features," == *",protect-main,"* ]]; then echo 开启 ✓; else echo 关闭; fi)"
    echo "  └─ auto-tapd-push: $(if [[ ",$features," == *",auto-tapd-push,"* ]]; then echo 开启 ✓; else echo 关闭; fi)"

    echo ""
    echo "✅ commit-msg + pre-push hook 已安装"
    echo "   · commit：未关联 TAPD 将被拒绝"
    echo "   · push main：拒绝直推，强制走 PR 流程"
    if [[ ",$features," == *",auto-tapd-push,"* ]]; then
      echo "   · push 任意分支：自动把 commits 同步到 TAPD 故事"
    else
      echo ""
      echo "💡 已在 TAPD 项目设置 → DevOps 启用「云原生构建源码」？推荐；无需 --with-auto-push。"
      echo "   如未开通，可加 --with-auto-push 装本地兜底钩子。"
    fi
    echo ""
    echo "   豁免方式见: .codebuddy/rules/03-commit-style.md"
    ;;

  uninstall)
    if [[ ! -f "$HOOK_TARGET" ]]; then
      echo "no commit-msg hook at $HOOK_TARGET"
    else
      if head -20 "$HOOK_TARGET" 2>/dev/null | grep -q "$MARKER"; then
        rm -f "$HOOK_TARGET"
        echo "✓ removed harness-managed commit-msg hook"
      else
        echo "! current commit-msg hook is NOT harness-managed, refusing to remove" >&2
      fi
    fi

    # pre-push
    if [[ -f "$PREPUSH_TARGET" ]]; then
      if head -20 "$PREPUSH_TARGET" 2>/dev/null | grep -q "$MARKER"; then
        rm -f "$PREPUSH_TARGET"
        echo "✓ removed harness-managed pre-push hook"
      else
        echo "! current pre-push hook is NOT harness-managed, refusing to remove" >&2
      fi
    fi

    # 检查是否有 backup 可还原
    backups=$(ls "$git_dir/hooks/" 2>/dev/null | grep "^commit-msg.backup-" | sort -r || true)
    if [[ -n "$backups" ]]; then
      latest=$(echo "$backups" | head -1)
      echo ""
      echo "发现旧 hook 备份:"
      echo "  $git_dir/hooks/$latest"
      echo "如需还原: mv '$git_dir/hooks/$latest' '$HOOK_TARGET'"
    fi

    # 撤销 commit.template
    current=$(git config --get commit.template 2>/dev/null || true)
    if [[ "$current" == ".gitmessage" ]]; then
      git config --unset commit.template
      echo "✓ git config --unset commit.template"
    fi
    ;;

  status)
    if [[ -f "$HOOK_TARGET" ]]; then
      if head -20 "$HOOK_TARGET" 2>/dev/null | grep -q "$MARKER"; then
        ts=$(head -20 "$HOOK_TARGET" | grep "$MARKER" | awk '{print $NF}')
        echo "commit-msg:      ✅ installed (harness-managed since $ts)"
      else
        echo "commit-msg:      ⚠  installed but NOT harness-managed"
      fi
    else
      echo "commit-msg:      ❌ not installed"
    fi

    if [[ -f "$PREPUSH_TARGET" ]]; then
      if head -20 "$PREPUSH_TARGET" 2>/dev/null | grep -q "$MARKER"; then
        ts=$(head -20 "$PREPUSH_TARGET" | grep "$MARKER" | awk '{print $NF}')
        echo "pre-push:        ✅ installed (harness-managed since $ts)"
      else
        echo "pre-push:        ⚠  present but NOT harness-managed"
      fi
    else
      echo "pre-push:        ❌ not installed (auto-push to TAPD disabled)"
    fi

    if [[ -f "$GITMSG_TARGET" ]]; then
      echo "gitmessage:      ✅ present"
    else
      echo "gitmessage:      ❌ missing"
    fi

    current=$(git config --get commit.template 2>/dev/null || true)
    if [[ "$current" == ".gitmessage" ]]; then
      echo "commit.template: ✅ = .gitmessage"
    elif [[ -n "$current" ]]; then
      echo "commit.template: ⚠  = $current (not harness default)"
    else
      echo "commit.template: ❌ not set"
    fi
    ;;

  *)
    echo "Usage: $0 {install|uninstall|status} <repo-root>" >&2
    exit 2
    ;;
esac
