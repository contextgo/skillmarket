#!/usr/bin/env bash
# list-cnb-orgs.sh — 列出当前 CNB 凭据可见的组织（CNB 叫 groups，不是 orgs）
#
# 用法: list-cnb-orgs.sh <alias>
# 输出: JSON 数组
#   [{"name": "xxx", "path": "xxx", "role": "Owner", "remark": "xxx", "repo_count": 8}, ...]
#
# 踩坑（2026-05-06）：CNB 真实 endpoint 是 /user/groups，/user/orgs 返回 404 errcode:5
#
# 退出码: 0 成功 / 1 API 失败 / 2 参数错 / 3 凭据不存在

set -euo pipefail

alias_name="${1:?alias required}"

SKILL_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="${CODEBUDDY_SECRETS_ROOT:-$HOME/.codebuddy/secrets}"
file="$ROOT/cnb/$alias_name.json"

if [[ ! -f "$file" ]]; then
  echo "ERROR: no stored credentials at $file" >&2
  exit 3
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "ERROR: jq required" >&2
  exit 2
fi

token=$(jq -r '.token' "$file")
endpoint=$(jq -r '.endpoint // "https://api.cnb.cool"' "$file")

resp=$(curl -s --max-time 15 \
  -H "Authorization: Bearer $token" \
  "$endpoint/user/groups" 2>/dev/null || true)

if [[ -z "$resp" ]]; then
  echo "ERROR: empty response from $endpoint/user/groups" >&2
  exit 1
fi

# 兼容两种返回结构：数组 或 {data: [...]}
normalized=$(echo "$resp" | jq 'if type == "array" then . elif .data then .data else [] end' 2>/dev/null || echo "[]")

# 规范化字段
echo "$normalized" | jq '[.[] | {
  name: (.name // .path // "unknown"),
  path: (.path // .name // "unknown"),
  role: (.access_role // .role // "Unknown"),
  remark: (.remark // ""),
  repo_count: (.all_sub_repo_count // .sub_repo_count // 0)
}]'
