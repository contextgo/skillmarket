#!/usr/bin/env bash
# verify-connection.sh — 验证已存储的凭据是否仍有效
#
# 用法: verify-connection.sh <kind> <alias>
# 退出码: 0=有效, 1=无效, 2=参数错误, 3=凭据不存在
#
# 当前支持:
#   - tapd: direct 模式下对 TAPD Open API 做一次 /projects/info 探测
#   - cnb:  待 P3 实现

set -euo pipefail

kind="${1:?kind required}"
alias_name="${2:?alias required}"

SKILL_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="${CODEBUDDY_SECRETS_ROOT:-$HOME/.codebuddy/secrets}"
file="$ROOT/$kind/$alias_name.json"

if [[ ! -f "$file" ]]; then
  echo "ERROR: no stored credentials at $file" >&2
  exit 3
fi

case "$kind" in
  tapd)
    # 从 json 读 api_user/api_password/base_url，调 /projects/info
    if ! command -v jq >/dev/null 2>&1; then
      echo "ERROR: jq not installed, cannot parse stored credentials" >&2
      echo "       install jq or verify manually" >&2
      exit 2
    fi
    api_user=$(jq -r '.api_user // empty' "$file")
    api_password=$(jq -r '.api_password // empty' "$file")
    base_url=$(jq -r '.base_url // "https://api.tapd.cn"' "$file")
    if [[ -z "$api_user" || -z "$api_password" ]]; then
      echo "ERROR: stored credentials missing api_user/api_password" >&2
      exit 1
    fi
    # 轻量探测：列出当前账号可见项目（workspace_id 不指定）
    # TAPD open API 需要 workspace_id 才能查 projects/info，这里用 /workspaces/projects?user_nick= 更稳妥
    # 但不同账号可能没 nick，折中：调 /quickstart/testauth 或简单 /me 探测
    http_code=$(curl -s -o /dev/null -w "%{http_code}" \
      -u "$api_user:$api_password" \
      --max-time 10 \
      "$base_url/quickstart/testauth" 2>/dev/null || echo "000")
    if [[ "$http_code" == "200" ]]; then
      echo "✅ TAPD credential is valid (alias=$alias_name)"
      exit 0
    else
      echo "❌ TAPD credential is invalid (HTTP $http_code)" >&2
      exit 1
    fi
    ;;
  cnb)
    if ! command -v jq >/dev/null 2>&1; then
      echo "ERROR: jq not installed, cannot parse stored credentials" >&2
      exit 2
    fi
    token=$(jq -r '.token // empty' "$file")
    endpoint=$(jq -r '.endpoint // "https://api.cnb.cool"' "$file")
    if [[ -z "$token" ]]; then
      echo "ERROR: stored credentials missing token" >&2
      exit 1
    fi
    # 轻量探活：GET /user
    http_code=$(curl -s -o /dev/null -w "%{http_code}" \
      -H "Authorization: Bearer $token" \
      --max-time 15 \
      "$endpoint/user" 2>/dev/null || echo "000")
    if [[ "$http_code" == "200" ]]; then
      echo "✅ CNB credential is valid (alias=$alias_name)"
      exit 0
    elif [[ "$http_code" == "401" || "$http_code" == "403" ]]; then
      echo "❌ CNB credential invalid or insufficient scope (HTTP $http_code)" >&2
      echo "   请重新生成 PAT，确认勾选了 repo/pipeline/org:read scope" >&2
      exit 1
    else
      echo "❌ CNB API returned HTTP $http_code" >&2
      exit 1
    fi
    ;;
  *)
    echo "ERROR: unknown kind: $kind" >&2
    exit 2
    ;;
esac
