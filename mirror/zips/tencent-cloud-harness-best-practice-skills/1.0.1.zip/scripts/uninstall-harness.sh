#!/usr/bin/env bash
# uninstall-harness.sh — 从仓库移除 harness-skills 装配的内容
#
# 用法: uninstall-harness.sh <repo-path> [--keep-secrets] [--keep-cnb-remote]
#
# 行为:
#   - 卸 commit-msg + pre-push hook（仅 harness-managed）
#   - 删 .tapd.yml
#   - 删 .cnb.yml（仅 harness-managed）
#   - 从 .codebuddy/connections.yml 里清 tapd/cnb 段
#   - 不删 secrets（除非 --no-keep-secrets）
#   - 不删 cnb remote（除非 --no-keep-cnb-remote）
#   - 不删 PR 模板的 harness 段（手动处理）

set -euo pipefail
SKILL_DIR="$(cd "$(dirname "$0")" && pwd)"
LIB="$SKILL_DIR/lib"

repo="${1:?repo-path required}"; shift || true
keep_secrets=1
keep_remote=1
while [[ $# -gt 0 ]]; do
  case "$1" in
    --no-keep-secrets) keep_secrets=0 ;;
    --no-keep-cnb-remote) keep_remote=0 ;;
  esac
  shift
done

[[ -d "$repo/.git" ]] || { echo "ERROR: not a git repo: $repo" >&2; exit 2; }
repo=$(cd "$repo" && pwd)

echo "── 移除 git hooks ──"
bash "$LIB/install-commit-hook.sh" uninstall "$repo" || true

echo "── 删配置文件 ──"
[[ -f "$repo/.tapd.yml" ]] && rm -f "$repo/.tapd.yml" && echo "✓ .tapd.yml"

if [[ -f "$repo/.cnb.yml" ]] && head -3 "$repo/.cnb.yml" | grep -q "cnb-tapd-harness managed\|harness-skills managed"; then
  rm -f "$repo/.cnb.yml"
  echo "✓ .cnb.yml (harness-managed)"
fi

if [[ $keep_remote -eq 0 ]]; then
  (cd "$repo" && git remote | grep -qx "cnb" && git remote remove cnb && echo "✓ removed remote cnb") || true
fi

# connections.yml 清段
conn="$repo/.codebuddy/connections.yml"
if [[ -f "$conn" ]]; then
  python3 - "$conn" <<'PY'
import sys, re, pathlib
p = pathlib.Path(sys.argv[1])
text = p.read_text(encoding="utf-8")
for section in ("tapd", "cnb"):
    text = re.sub(rf"^{section}:[\s\S]*?(?=^[A-Za-z]|\Z)", "", text, flags=re.MULTILINE)
p.write_text(text.rstrip() + "\n", encoding="utf-8")
print("✓ connections.yml tapd/cnb 段已清")
PY
fi

if [[ $keep_secrets -eq 0 ]]; then
  echo "⚠ 同时删凭据（传了 --no-keep-secrets）"
  # 谨慎：只删已知命名
  echo "  (跳过自动删，请手动：rm -rf ~/.codebuddy/secrets/tapd/<alias>.json ~/.codebuddy/secrets/cnb/<alias>.json)"
fi

echo ""
echo "✅ 卸载完成。"
echo "   保留：git 仓库 cnb remote（如有）、CNB 远端仓库、TAPD 故事、.gitmessage 模板"
echo "   如需连 cnb.cool 上的远端仓库一起删，去 CNB 控制台手动操作。"
