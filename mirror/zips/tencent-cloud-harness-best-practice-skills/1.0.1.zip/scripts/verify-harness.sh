#!/usr/bin/env bash
# verify-harness.sh — 体检仓库的 harness 完整度（7 层）
#
# 用法: verify-harness.sh [<repo-root>]
# 输出: 人类可读表格 + 末尾一个"通过/部分通过/未装"的结论
# 退出码: 0=全装完, 1=部分装完, 2=未装, 3=参数错误

set -uo pipefail

REPO="${1:-$(pwd)}"

if [[ ! -d "$REPO" ]]; then
  echo "ERROR: not a directory: $REPO" >&2
  exit 3
fi

cd "$REPO"

# ---------- helpers ----------
pass=()
partial=()
miss=()

check() {
  local phase="$1"
  local desc="$2"
  local result="$3"   # pass | partial | miss
  case "$result" in
    pass)    pass+=("$phase|$desc") ;;
    partial) partial+=("$phase|$desc") ;;
    miss)    miss+=("$phase|$desc") ;;
  esac
}

file_exists() { [[ -f "$1" ]]; }
dir_exists()  { [[ -d "$1" ]]; }
file_nonempty() { [[ -f "$1" && -s "$1" ]]; }

# ---------- P0 Discover ----------
p0_ok=0
p0_total=3
file_nonempty ".codebuddy/intel/stack.md"        && ((p0_ok++))
file_nonempty ".codebuddy/intel/architecture.md" && ((p0_ok++))
file_nonempty ".codebuddy/intel/modules.md"      && ((p0_ok++))
if   (( p0_ok == p0_total )); then check "P0" "Discover (intel/ 三份文档)" pass
elif (( p0_ok > 0 ));         then check "P0" "Discover (缺 $((p0_total - p0_ok))/$p0_total)" partial
else                               check "P0" "Discover" miss; fi

# ---------- P1 AGENTS.md ----------
p1_ok=0
p1_total=3
file_nonempty "AGENTS.md" && ((p1_ok++))
dir_exists    ".codebuddy/rules" && \
  (( $(ls .codebuddy/rules/*.md 2>/dev/null | wc -l) >= 5 )) && ((p1_ok++))
# AGENTS.md 行数 ≤ 150
if file_exists "AGENTS.md" && (( $(wc -l < AGENTS.md) <= 150 )); then ((p1_ok++)); fi
if   (( p1_ok == p1_total )); then check "P1" "AGENTS.md + rules/" pass
elif (( p1_ok > 0 ));         then check "P1" "AGENTS.md + rules/ (不完整)" partial
else                               check "P1" "AGENTS.md + rules/" miss; fi

# ---------- P2 TAPD ----------
p2_ok=0
p2_total=5
# connections.yml 有 tapd 段
file_exists ".codebuddy/connections.yml" && grep -q "^tapd:" .codebuddy/connections.yml 2>/dev/null && ((p2_ok++))
# .tapd.yml 公开副本
file_exists ".tapd.yml" && ((p2_ok++))
# commit-msg hook 存在且是 harness-managed
git_dir=$(git rev-parse --git-dir 2>/dev/null || true)
if [[ -n "$git_dir" ]]; then
  [[ "$git_dir" != /* ]] && git_dir="$REPO/$git_dir"
  hook_file="$git_dir/hooks/commit-msg"
  if [[ -f "$hook_file" ]] && head -20 "$hook_file" 2>/dev/null | grep -q "cnb-tapd-harness-managed"; then
    ((p2_ok++))
  fi
fi
# .gitmessage 模板
file_exists ".gitmessage" && ((p2_ok++))
# PR 模板（任一位置有且含 "关联 TAPD"）
if ( [[ -f ".github/PULL_REQUEST_TEMPLATE.md" ]] && grep -q "关联 TAPD\|TAPD" .github/PULL_REQUEST_TEMPLATE.md ) \
   || ( [[ -f ".cnb/pr-template.md" ]] && grep -q "关联 TAPD\|TAPD" .cnb/pr-template.md ); then
  ((p2_ok++))
fi
if   (( p2_ok == p2_total )); then check "P2" "TAPD Bind (connections/tapd.yml/hook/gitmessage/pr-template)" pass
elif (( p2_ok > 0 ));         then check "P2" "TAPD Bind (不完整 $p2_ok/$p2_total)" partial
else                               check "P2" "TAPD Bind" miss; fi

# ---------- P3 CNB Onboarding ----------
p3_ok=0
p3_total=4
# .cnb.yml 存在且是 harness-managed
if [[ -f ".cnb.yml" ]] && head -5 ".cnb.yml" 2>/dev/null | grep -q "cnb-tapd-harness managed"; then
  ((p3_ok++))
fi
# connections.yml 有 cnb 段（alias + repo_slug）
if file_exists ".codebuddy/connections.yml" && grep -q "^cnb:" .codebuddy/connections.yml 2>/dev/null; then
  if grep -A10 "^cnb:" .codebuddy/connections.yml | grep -qE "^\s*alias:" && \
     grep -A10 "^cnb:" .codebuddy/connections.yml | grep -qE "^\s*repo_slug:"; then
    ((p3_ok++))
  fi
fi
# git remote 有 cnb 或 origin 指向 cnb.cool
if command -v git >/dev/null 2>&1 && git rev-parse --git-dir >/dev/null 2>&1; then
  if git remote 2>/dev/null | grep -qx "cnb"; then
    ((p3_ok++))
  elif git remote 2>/dev/null | grep -qx "origin" && git remote get-url origin 2>/dev/null | grep -q "cnb.cool"; then
    ((p3_ok++))
  fi
fi
# ~/.codebuddy/secrets/cnb/ 至少一个 alias（从 connections 读 alias 名）
conn_alias=$(grep -A5 "^cnb:" .codebuddy/connections.yml 2>/dev/null | grep -E "^\s*alias:" | head -1 | sed -E 's/.*alias:[[:space:]]*"?([^"]+)"?.*/\1/')
if [[ -n "$conn_alias" && -f "$HOME/.codebuddy/secrets/cnb/$conn_alias.json" ]]; then
  ((p3_ok++))
fi

if   (( p3_ok == p3_total )); then check "P3" "CNB Onboarding (cnb.yml/connections/remote/secret)" pass
elif (( p3_ok > 0 ));         then check "P3" "CNB Onboarding (不完整 $p3_ok/$p3_total)" partial
else                               check "P3" "CNB Onboarding" miss; fi

# ---------- P4 Change Analysis ----------
p4_ok=0
p4_total=2
# review-checklist.md 存在
file_exists ".codebuddy/rules/07-review-checklist.md" && ((p4_ok++))
# connections.yml 中 cnb.change_analysis_enabled: true（API 成功或用户手动确认后 skill 写入）
if file_exists ".codebuddy/connections.yml" && grep -q "change_analysis_enabled: *true" .codebuddy/connections.yml 2>/dev/null; then
  ((p4_ok++))
fi
if   (( p4_ok == p4_total )); then check "P4" "Change Analysis (review-checklist + enabled flag)" pass
elif (( p4_ok > 0 ));         then check "P4" "Change Analysis (不完整 $p4_ok/$p4_total)" partial
else                               check "P4" "Change Analysis" miss; fi

# ---------- P5 Logs Ready ----------
p5_ok=0
p5_total=3
# 06-logging.md 规约存在
file_exists ".codebuddy/rules/06-logging.md" && ((p5_ok++))
# log-queries.md 生成（P5 核心产物）
file_exists ".codebuddy/intel/log-queries.md" && ((p5_ok++))
# 日志库文件存在（三种栈任一命中）
if [[ -f "logger/harness.go" ]] || \
   [[ -f "src/lib/logger.harness.ts" ]] || \
   [[ -f "src/logger.harness.ts" ]] || \
   [[ -f "logger.harness.ts" ]] || \
   [[ -f "app/logging_harness.py" ]] || \
   [[ -f "logging_harness.py" ]]; then
  ((p5_ok++))
fi
if   (( p5_ok == p5_total )); then check "P5" "Logs Ready (rule + queries + logger)" pass
elif (( p5_ok > 0 ));         then check "P5" "Logs Ready (不完整 $p5_ok/$p5_total)" partial
else                               check "P5" "Logs Ready" miss; fi

# ---------- P6 Gardening ----------
p6_ok=0
p6_total=2
# 子 skill 已安装
dir_exists ".codebuddy/skills/doc-gardener" && file_exists ".codebuddy/skills/doc-gardener/SKILL.md" && ((p6_ok++))
# reports 目录已建（即使为空也算，说明 install 走完了初始化）
dir_exists ".codebuddy/intel/gardener-reports" && ((p6_ok++))
if   (( p6_ok == p6_total )); then check "P6" "Gardening (doc-gardener + reports dir)" pass
elif (( p6_ok > 0 ));         then check "P6" "Gardening (不完整 $p6_ok/$p6_total)" partial
else                               check "P6" "Gardening" miss; fi

# ---------- 通用安全检查 ----------
sec_issues=0
if [[ -f ".gitignore" ]] && grep -q ".codebuddy/secrets/" .gitignore; then
  :
else
  ((sec_issues++))
fi

# 扫 connections.yml 里有无 token 泄漏
if [[ -f ".codebuddy/connections.yml" ]]; then
  if grep -Ei "(token|password|secret):\s*[^\"']?[A-Za-z0-9_-]{16,}" .codebuddy/connections.yml > /dev/null 2>&1; then
    ((sec_issues++))
  fi
fi

# ---------- 输出 ----------
echo ""
echo "======================================================================"
echo " harness-skills 体检报告"
echo " 仓库: $REPO"
echo " 时间: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "======================================================================"
printf "%-4s %-10s %s\n" "层" "状态" "说明"
echo "----------------------------------------------------------------------"

print_phase() {
  local phase="$1"
  local arr_pass="$2"
  local arr_part="$3"
  local arr_miss="$4"

  if printf '%s\n' "$arr_pass" | grep -q "^$phase|"; then
    local desc; desc=$(printf '%s\n' "$arr_pass" | grep "^$phase|" | cut -d'|' -f2)
    printf "%-4s %-10s %s\n" "$phase" "✅ PASS" "$desc"
  elif printf '%s\n' "$arr_part" | grep -q "^$phase|"; then
    local desc; desc=$(printf '%s\n' "$arr_part" | grep "^$phase|" | cut -d'|' -f2)
    printf "%-4s %-10s %s\n" "$phase" "⚠  PART" "$desc"
  else
    local desc; desc=$(printf '%s\n' "$arr_miss" | grep "^$phase|" | cut -d'|' -f2)
    printf "%-4s %-10s %s\n" "$phase" "❌ MISS" "$desc"
  fi
}

pass_str=$(printf '%s\n' "${pass[@]:-}")
part_str=$(printf '%s\n' "${partial[@]:-}")
miss_str=$(printf '%s\n' "${miss[@]:-}")

for p in P0 P1 P2 P3 P4 P5 P6; do
  print_phase "$p" "$pass_str" "$part_str" "$miss_str"
done

echo "----------------------------------------------------------------------"
echo " 安全检查: $([[ $sec_issues -eq 0 ]] && echo "✅ 无明显问题" || echo "⚠  发现 $sec_issues 个问题（见 secrets-policy.md）")"
echo "======================================================================"

# 结论
total_pass=${#pass[@]}
total_phases=7
if (( total_pass == total_phases && sec_issues == 0 )); then
  echo " 结论: ✅ 全部装完"
  exit 0
elif (( total_pass > 0 )); then
  echo " 结论: ⚠  部分装完 ($total_pass/$total_phases)"
  exit 1
else
  echo " 结论: ❌ 未装"
  exit 2
fi
