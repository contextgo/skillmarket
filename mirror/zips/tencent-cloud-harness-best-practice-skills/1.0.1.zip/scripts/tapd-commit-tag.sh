#!/usr/bin/env bash
# tapd-commit-tag.sh — 从 TAPD 取"源码提交关键字"
#
# 背景: TAPD 的 CNB 集成通过 commit message 里的特定关键字回写故事，真实格式：
#   --story=<短ID>@tapd-<workspace_id> --user=<api_user> <标题> <故事短链>
# 这个格式由 TAPD 动态生成（/code_commit_infos/get_commit_msg），不是固定模板。
#
# 用法:
#   tapd-commit-tag.sh <alias> <story_id> [--type=story|task|bug] [--copy]
#
# 参数:
#   alias     TAPD 凭据 alias（如 new-api）
#   story_id  TAPD 对象完整 ID（19 位）
#   --type    对象类型，默认 story
#   --copy    拷贝到系统剪贴板（macOS pbcopy / Linux xclip）
#
# 输出:
#   成功: 标准输出原始关键字字符串（单行），exit 0
#   失败: 错误到 stderr，exit 1/2/3
#
# 退出码:
#   0 成功
#   1 TAPD API 失败
#   2 参数错误 / jq 缺失
#   3 凭据不存在

set -euo pipefail

alias_name=""
object_id=""
object_type="story"
do_copy=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --type=*) object_type="${1#--type=}"; shift ;;
    --copy)   do_copy=1; shift ;;
    -h|--help)
      cat <<EOF
Usage: $0 <alias> <story_id> [--type=story|task|bug] [--copy]

Examples:
  $0 new-api <STORY_ID>
  $0 new-api <STORY_ID> --type=bug --copy
EOF
      exit 0
      ;;
    *)
      if [[ -z "$alias_name" ]]; then
        alias_name="$1"
      elif [[ -z "$object_id" ]]; then
        object_id="$1"
      fi
      shift
      ;;
  esac
done

if [[ -z "$alias_name" || -z "$object_id" ]]; then
  echo "Usage: $0 <alias> <story_id> [--type=story|task|bug] [--copy]" >&2
  exit 2
fi

case "$object_type" in
  story|task|bug) : ;;
  *) echo "ERROR: --type 只支持 story|task|bug" >&2; exit 2 ;;
esac

if ! command -v jq >/dev/null 2>&1; then
  echo "ERROR: 需要 jq" >&2
  exit 2
fi

ROOT="${CODEBUDDY_SECRETS_ROOT:-$HOME/.codebuddy/secrets}"
file="$ROOT/tapd/$alias_name.json"
if [[ ! -f "$file" ]]; then
  echo "ERROR: 凭据不存在: $file" >&2
  exit 3
fi

api_user=$(jq -r '.api_user' "$file")
api_password=$(jq -r '.api_password' "$file")
base_url=$(jq -r '.base_url // "https://api.tapd.cn"' "$file")

# 从 object_id 反推 workspace_id（TAPD 的 19 位 ID 编码规则：前缀 + workspace_id 8 位 + 序号）
# 保险起见，也允许用户通过环境变量 TAPD_WORKSPACE_ID 传
workspace_id="${TAPD_WORKSPACE_ID:-}"
if [[ -z "$workspace_id" ]]; then
  # 约定格式：11 开头的 19 位 ID，第 3-10 位是 workspace_id
  if [[ "$object_id" =~ ^11([0-9]{8})[0-9]+$ ]]; then
    workspace_id="${BASH_REMATCH[1]}"
  else
    echo "ERROR: 无法从 object_id 推断 workspace_id，请设 TAPD_WORKSPACE_ID=<id>" >&2
    exit 2
  fi
fi

# 去 TAPD 取 commit 关键字
# 说明（2026-05-06 实测）：
#   · 公网 api.tapd.cn 没有对外暴露 get_commit_msg 端点
#   · MCP-server-tapd 内部用的是 apiv2.tapd.woa.com 内网接口（外部不可用）
#   · 本脚本尝试多个候选路径，全失败时给出清晰降级指引
# 获取关键字的真正可靠通路是：
#   1) AI agent 调 MCP tool: get_commit_msg
#   2) 用户手动在 TAPD 故事详情页右上角「复制源码提交关键字」
candidates=(
  "code_commit_infos/get_commit_msg"
  "commit_infos/get_commit_msg"
  "commit_msg"
)
msg=""
for ep in "${candidates[@]}"; do
  resp=$(curl -s --max-time 10 \
    -u "$api_user:$api_password" \
    "$base_url/$ep?workspace_id=$workspace_id&object_id=$object_id&type=$object_type" 2>/dev/null || true)
  [[ -z "$resp" ]] && continue
  status=$(echo "$resp" | jq -r '.status // 0' 2>/dev/null || echo "0")
  data=$(echo "$resp" | jq -r '.data // ""' 2>/dev/null)
  # "Hello world from TAPD API..." 是 TAPD 对未实现端点的占位响应
  if [[ "$status" == "1" ]] && [[ -n "$data" ]] && [[ "$data" != Hello* ]]; then
    msg="$data"
    break
  fi
done

if [[ -z "$msg" ]]; then
  cat >&2 <<EOF
⚠  TAPD 公网 API 未暴露 get_commit_msg 端点。

获取 commit 关键字的可靠方法（三选一，效果一致）:

  A) 手动：浏览器打开 TAPD 对象详情页
        https://www.tapd.cn/$workspace_id/prong/stories/view/$object_id
     → 右上角「复制源码提交关键字」

  B) 如果是 AI agent（在 CodeBuddy/CodeX 等集成了 mcp-server-tapd）：
     调工具 mcp-server-tapd.get_commit_msg
         workspace_id=$workspace_id
         options={object_id: "$object_id", type: "$object_type"}

  C) 最简格式（也能通过本 skill 的 hook 校验，但不走 TAPD 官方自动回写）：
        --story=$object_id
EOF
  exit 1
fi

# 输出
echo "$msg"

# 可选：拷到剪贴板
if [[ $do_copy -eq 1 ]]; then
  if command -v pbcopy >/dev/null 2>&1; then
    printf '%s' "$msg" | pbcopy
    echo "✓ 已复制到剪贴板" >&2
  elif command -v xclip >/dev/null 2>&1; then
    printf '%s' "$msg" | xclip -selection clipboard
    echo "✓ 已复制到剪贴板（xclip）" >&2
  elif command -v clip.exe >/dev/null 2>&1; then
    printf '%s' "$msg" | clip.exe
    echo "✓ 已复制到剪贴板（clip.exe）" >&2
  else
    echo "（未找到剪贴板工具，未复制）" >&2
  fi
fi
