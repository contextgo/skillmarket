#!/usr/bin/env bash
# install-harness.sh — harness-skills 主入口（精简版）
#
# 功能组合：把 TAPD 凭据绑定、CNB 仓库建立/mirror、git hooks、.cnb.yml 模板、分支保护
# 一口气装到一个已有 git 仓库，让它马上能走 "feature 分支 → PR → AI review → 合入 → TAPD 回写" 全链路。
#
# 用法:
#   install-harness.sh wizard <repo-path>
#       - 🌟 交互式向导，一步步问参数并装配（零态用户首选）
#
#   install-harness.sh connect-tapd <alias> <workspace_id>
#       - 从环境变量 TAPD_API_USER / TAPD_API_PASSWORD 录入 TAPD 凭据，并验证对该 workspace 的访问
#
#   install-harness.sh connect-cnb <alias>
#       - 从环境变量 CNB_TOKEN 录入 CNB PAT，并验证
#
#   install-harness.sh setup <repo-path>
#       - 一次性装好 git hooks + .cnb.yml + .gitmessage + .tapd.yml + PR 模板 TAPD 段
#       - 需要仓库已有 .codebuddy/connections.yml（用 `--auto-init` 自动创建）
#       - 支持标志:
#           --tapd-alias=<name>        TAPD 凭据 alias（若 connections.yml 已有可省）
#           --workspace-id=<id>        TAPD workspace id
#           --cnb-alias=<name>         CNB 凭据 alias
#           --cnb-org=<org>            CNB 组织 path（例如 <YOUR_ORG>）
#           --cnb-repo=<name>          CNB 仓库名（默认取 git 仓库目录名）
#           --mirror                   同时 mirror 推送一次到新建的 CNB 仓
#           --ci-template=<name>       覆盖自动探测的 .cnb.yml 模板名
#                                       可选: go|node|python|terraform|mixed-go-node
#           --with-auto-push           额外装"自动推 commit 到 TAPD"的 pre-push 钩子
#                                       （仅当贵司 TAPD 未开通原生 CNB 集成时需要）
#           --no-protect-main          关闭"拒绝直推 main"保护（不推荐）
#           --auto-init                connections.yml 不存在时自动创建骨架
#
#   install-harness.sh status <repo-path>
#       - 打印当前装配状态和下一步建议
#
# 环境变量:
#   TAPD_API_USER, TAPD_API_PASSWORD    connect-tapd 用
#   TAPD_BASE_URL                       可选，默认 https://api.tapd.cn
#   CNB_TOKEN                           connect-cnb 用
#   CNB_ENDPOINT                        可选，默认 https://api.cnb.cool
#   TAPD_COMPANY_ID                     可选，有则在错误提示里给授权深链

set -euo pipefail

SKILL_DIR="$(cd "$(dirname "$0")" && pwd)"
LIB="$SKILL_DIR/lib"
SKILL_ROOT="$(cd "$SKILL_DIR/.." && pwd)"

die() { echo "ERROR: $*" >&2; exit 2; }

need() {
  for bin in "$@"; do
    command -v "$bin" >/dev/null 2>&1 || die "缺少依赖: $bin"
  done
}

# ---------- connect-tapd ----------
cmd_connect_tapd() {
  local alias_name="${1:?alias required}"
  local workspace_id="${2:?workspace_id required}"
  : "${TAPD_API_USER:?env TAPD_API_USER required}"
  : "${TAPD_API_PASSWORD:?env TAPD_API_PASSWORD required}"
  local base_url="${TAPD_BASE_URL:-https://api.tapd.cn}"

  need jq curl

  local secrets_dir="${CODEBUDDY_SECRETS_ROOT:-$HOME/.codebuddy/secrets}/tapd"
  mkdir -p "$secrets_dir"
  chmod 700 "$(dirname "$secrets_dir")" "$secrets_dir" 2>/dev/null || true

  local file="$secrets_dir/$alias_name.json"
  # 写入
  jq -n \
    --arg alias "$alias_name" \
    --arg base_url "$base_url" \
    --arg u "$TAPD_API_USER" \
    --arg p "$TAPD_API_PASSWORD" \
    --arg now "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    '{alias: $alias, kind: "tapd", base_url: $base_url, api_user: $u, api_password: $p, created_at: $now}' \
    > "$file"
  chmod 600 "$file"
  echo "✓ TAPD 凭据已存入 $file"

  # 验证
  echo "── 验证 workspace=$workspace_id 可访问 ──"
  local resp http_code
  resp=$(curl -s -w "\n%{http_code}" --max-time 10 \
    -u "$TAPD_API_USER:$TAPD_API_PASSWORD" \
    "$base_url/workspaces/get_workspace_info?workspace_id=$workspace_id" 2>/dev/null || echo $'\n000')
  http_code=$(echo "$resp" | tail -n1)
  local body
  body=$(echo "$resp" | sed '$d')

  if [[ "$http_code" != "200" ]]; then
    echo "❌ HTTP $http_code" >&2
    rm -f "$file"
    die "TAPD 验证失败，已清理凭据。常见原因：API 账号未勾选该 workspace 授权。"
  fi

  local status
  status=$(echo "$body" | jq -r '.status // 0' 2>/dev/null || echo 0)
  if [[ "$status" != "1" ]]; then
    local info
    info=$(echo "$body" | jq -r '.info // "unknown"' 2>/dev/null)
    rm -f "$file"
    die "TAPD 返回失败: $info（常见原因：API 账号未勾选该 workspace 授权）"
  fi

  local name
  name=$(echo "$body" | jq -r '.data.Workspace.name // "unknown"' 2>/dev/null)
  echo "✅ TAPD 连通 · workspace=$workspace_id · name=$name"
  echo ""
  echo "下一步：cd 到目标 git 仓库，跑"
  echo "  install-harness.sh setup . --tapd-alias=$alias_name --workspace-id=$workspace_id ..."
}

# ---------- connect-cnb ----------
cmd_connect_cnb() {
  local alias_name="${1:?alias required}"
  : "${CNB_TOKEN:?env CNB_TOKEN required}"
  local endpoint="${CNB_ENDPOINT:-https://api.cnb.cool}"

  need jq curl

  local secrets_dir="${CODEBUDDY_SECRETS_ROOT:-$HOME/.codebuddy/secrets}/cnb"
  mkdir -p "$secrets_dir"
  chmod 700 "$(dirname "$secrets_dir")" "$secrets_dir" 2>/dev/null || true

  local file="$secrets_dir/$alias_name.json"
  jq -n \
    --arg alias "$alias_name" \
    --arg endpoint "$endpoint" \
    --arg token "$CNB_TOKEN" \
    --arg now "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    '{alias: $alias, kind: "cnb", endpoint: $endpoint, token: $token, created_at: $now}' \
    > "$file"
  chmod 600 "$file"
  echo "✓ CNB 凭据已存入 $file"

  # 探活
  local http_code
  http_code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
    -H "Authorization: Bearer $CNB_TOKEN" "$endpoint/user")
  if [[ "$http_code" != "200" ]]; then
    rm -f "$file"
    die "CNB 验证失败 (HTTP $http_code)，已清理凭据"
  fi
  echo "✅ CNB 连通"
  echo ""
  echo "可用组织（groups）:"
  bash "$LIB/list-cnb-orgs.sh" "$alias_name" | jq -r '.[] | "  · \(.path) (\(.role), \(.repo_count) repos) — \(.remark)"'
}

# ---------- setup ----------
cmd_setup() {
  local repo_path="${1:?repo-path required}"
  shift || true

  local tapd_alias="" workspace_id="" cnb_alias="" cnb_org="" cnb_repo=""
  local do_mirror=0 ci_tpl="" auto_init=0
  local hook_extra_args=()

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --tapd-alias=*)     tapd_alias="${1#--tapd-alias=}" ;;
      --workspace-id=*)   workspace_id="${1#--workspace-id=}" ;;
      --cnb-alias=*)      cnb_alias="${1#--cnb-alias=}" ;;
      --cnb-org=*)        cnb_org="${1#--cnb-org=}" ;;
      --cnb-repo=*)       cnb_repo="${1#--cnb-repo=}" ;;
      --mirror)           do_mirror=1 ;;
      --ci-template=*)    ci_tpl="${1#--ci-template=}" ;;
      --with-auto-push)   hook_extra_args+=(--with-auto-push) ;;
      --no-protect-main)  hook_extra_args+=(--no-protect-main) ;;
      --auto-init)        auto_init=1 ;;
      *) die "未知参数: $1" ;;
    esac
    shift
  done

  [[ -d "$repo_path/.git" ]] || die "$repo_path 不是 git 仓库"
  repo_path=$(cd "$repo_path" && pwd)

  need jq curl git

  # ---------- connections.yml ----------
  local conn="$repo_path/.codebuddy/connections.yml"
  if [[ ! -f "$conn" ]]; then
    if [[ $auto_init -ne 1 ]]; then
      die ".codebuddy/connections.yml 不存在。加 --auto-init 自动创建，或先手动创建后重跑。"
    fi
    mkdir -p "$repo_path/.codebuddy"
    cat > "$conn" <<EOF
# .codebuddy/connections.yml — 由 harness-skills 维护
# 可 commit，不含任何凭据（凭据在 ~/.codebuddy/secrets/）

harness:
  installed_phases: []
  last_setup_at: "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
EOF
    echo "✓ 新建 $conn"
  fi

  # 从 connections.yml 读默认值
  if [[ -z "$tapd_alias" ]]; then
    tapd_alias=$(awk '/^tapd:[[:space:]]*$/{s=1;next}/^[A-Za-z]/{s=0}s&&/^[[:space:]]+alias:/{sub(/.*alias:[[:space:]]*"?/,"");sub(/".*/,"");sub(/[[:space:]].*/,"");print;exit}' "$conn" 2>/dev/null || true)
  fi
  if [[ -z "$workspace_id" ]]; then
    workspace_id=$(awk '/^tapd:[[:space:]]*$/{s=1;next}/^[A-Za-z]/{s=0}s&&/^[[:space:]]+workspace_id:/{sub(/.*workspace_id:[[:space:]]*"?/,"");sub(/".*/,"");sub(/[[:space:]].*/,"");print;exit}' "$conn" 2>/dev/null || true)
  fi
  if [[ -z "$cnb_alias" ]]; then
    cnb_alias=$(awk '/^cnb:[[:space:]]*$/{s=1;next}/^[A-Za-z]/{s=0}s&&/^[[:space:]]+alias:/{sub(/.*alias:[[:space:]]*"?/,"");sub(/".*/,"");sub(/[[:space:]].*/,"");print;exit}' "$conn" 2>/dev/null || true)
  fi
  if [[ -z "$cnb_org" ]]; then
    local slug
    slug=$(awk '/^cnb:[[:space:]]*$/{s=1;next}/^[A-Za-z]/{s=0}s&&/^[[:space:]]+repo_slug:/{sub(/.*repo_slug:[[:space:]]*"?/,"");sub(/".*/,"");sub(/[[:space:]].*/,"");print;exit}' "$conn" 2>/dev/null || true)
    cnb_org="${slug%%/*}"
  fi
  [[ -z "$cnb_repo" ]] && cnb_repo="$(basename "$repo_path")"

  [[ -n "$tapd_alias" ]]   || die "缺 --tapd-alias （或 connections.yml 里 tapd.alias）"
  [[ -n "$workspace_id" ]] || die "缺 --workspace-id （或 connections.yml 里 tapd.workspace_id）"
  [[ -n "$cnb_alias" ]]    || die "缺 --cnb-alias （或 connections.yml 里 cnb.alias）"
  [[ -n "$cnb_org" ]]      || die "缺 --cnb-org"

  [[ -f "$HOME/.codebuddy/secrets/tapd/$tapd_alias.json" ]] || \
    die "TAPD 凭据不存在，先跑 install-harness.sh connect-tapd $tapd_alias $workspace_id"
  [[ -f "$HOME/.codebuddy/secrets/cnb/$cnb_alias.json" ]] || \
    die "CNB 凭据不存在，先跑 install-harness.sh connect-cnb $cnb_alias"

  # ---------- gitignore 追加 secrets 路径 ----------
  local gi="$repo_path/.gitignore"
  local gi_marker="# harness-skills: never commit local credentials"
  if [[ ! -f "$gi" ]] || ! grep -q "$gi_marker" "$gi"; then
    {
      echo ""
      echo "$gi_marker"
      echo ".codebuddy/secrets/"
      echo ".harness-bypass"
    } >> "$gi"
    echo "✓ 更新 .gitignore"
  fi

  # ---------- CNB 仓库：查/建 + mirror + wire ----------
  local cnb_full="$cnb_org/$cnb_repo"
  local cnb_url="https://cnb.cool/$cnb_full.git"
  local cnb_web="https://cnb.cool/$cnb_full"
  echo ""
  echo "── 配置 CNB 仓库 $cnb_full ──"

  set +e
  bash "$LIB/create-cnb-repo.sh" "$cnb_alias" "$cnb_org" "$cnb_repo" private "Managed by harness-skills" >/dev/null 2>&1
  local rc=$?
  set -e
  case $rc in
    0) echo "✓ 已创建 CNB 仓库" ;;
    9) echo "✓ CNB 仓库已存在，复用" ;;
    *) die "CNB 仓库检查/创建失败 (rc=$rc)" ;;
  esac

  if [[ $do_mirror -eq 1 ]]; then
    bash "$LIB/mirror-to-cnb.sh" "$cnb_alias" "$repo_path" "$cnb_url" | tail -5
  fi

  bash "$LIB/wire-cnb-remote.sh" add "$repo_path" "$cnb_url" | head -2

  # ---------- .cnb.yml ----------
  echo ""
  echo "── 安装 .cnb.yml ──"
  if [[ -n "$ci_tpl" ]]; then
    bash "$LIB/install-cnb-ci.sh" install "$repo_path" "$ci_tpl" | tail -3
  else
    bash "$LIB/install-cnb-ci.sh" install "$repo_path" | tail -3
  fi

  # ---------- .tapd.yml / PR 模板 ----------
  echo ""
  echo "── 安装 TAPD 元数据文件 ──"
  if [[ ! -f "$repo_path/.tapd.yml" ]]; then
    # 查 workspace name
    local ws_name
    ws_name=$(curl -s --max-time 10 \
      -u "$(jq -r .api_user < "$HOME/.codebuddy/secrets/tapd/$tapd_alias.json"):$(jq -r .api_password < "$HOME/.codebuddy/secrets/tapd/$tapd_alias.json")" \
      "https://api.tapd.cn/workspaces/get_workspace_info?workspace_id=$workspace_id" 2>/dev/null \
      | jq -r '.data.Workspace.name // "unknown"')
    sed "s|{{TAPD_WORKSPACE_ID}}|$workspace_id|g; s|{{TAPD_WORKSPACE_NAME}}|$ws_name|g; s|{{TAPD_BASE_URL}}|https://www.tapd.cn|g" \
      "$SKILL_ROOT/assets/git/tapd.yml.tmpl.md" > "$repo_path/.tapd.yml"
    echo "✓ 写入 .tapd.yml"
  else
    echo "✓ .tapd.yml 已存在，保留"
  fi

  # PR 模板：仅当不存在时写入，避免覆盖上游模板
  local pr_path="$repo_path/.github/PULL_REQUEST_TEMPLATE.md"
  if [[ ! -f "$pr_path" ]]; then
    mkdir -p "$(dirname "$pr_path")"
    cp "$SKILL_ROOT/assets/git/pr-template.md" "$pr_path"
    echo "✓ 写入 $pr_path"
  else
    if ! grep -q "关联 TAPD\|TAPD" "$pr_path"; then
      # 追加 TAPD 段
      cat >> "$pr_path" <<EOF

---

<!-- harness-skills managed section -->
## 🔖 关联 TAPD

- 需求 / 缺陷 / 任务: <!-- https://www.tapd.cn/$workspace_id/prong/stories/view/<id> -->
- 若无对应单: <!-- 紧急热修 / 仅改文档 -->

EOF
      echo "✓ 追加 TAPD 段到现有 PR 模板"
    fi
  fi

  # ---------- git hooks ----------
  echo ""
  echo "── 安装 git hooks（commit-msg + pre-push）──"
  bash "$LIB/install-commit-hook.sh" install "$repo_path" "${hook_extra_args[@]+"${hook_extra_args[@]}"}" | tail -12

  # ---------- 更新 connections.yml ----------
  echo ""
  echo "── 更新 connections.yml ──"
  # 追加/覆盖 tapd 段 + cnb 段（这里用重写法，保留 harness: 段）
  python3 - "$conn" "$tapd_alias" "$workspace_id" "$cnb_alias" "$cnb_full" "$cnb_web" <<'PY'
import sys, re, os, datetime, pathlib
conn, t_alias, ws, c_alias, c_slug, c_web = sys.argv[1:7]
p = pathlib.Path(conn)
text = p.read_text(encoding="utf-8")

def drop(section):
    return re.sub(rf"^{section}:[\s\S]*?(?=^[A-Za-z]|\Z)", "", text, flags=re.MULTILINE)

text = drop("tapd")
text = drop("cnb")
now = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
tapd_block = f"""
tapd:
  via: direct
  alias: "{t_alias}"
  base_url: "https://api.tapd.cn"
  workspace_id: "{ws}"
  installed_at: "{now}"
"""
cnb_block = f"""
cnb:
  via: direct
  alias: "{c_alias}"
  endpoint: "https://api.cnb.cool"
  repo_slug: "{c_slug}"
  web_url: "{c_web}"
  mode: "mirror"
  installed_at: "{now}"
"""
text = text.rstrip() + "\n" + tapd_block + cnb_block
p.write_text(text, encoding="utf-8")
print("✓ connections.yml tapd/cnb 段已更新")
PY

  echo ""
  echo "✅ 装配完成。"
  echo ""
  echo "试试：  $SKILL_DIR/start-feature.sh <tapd_story_id>"
}

# ---------- status ----------
cmd_status() {
  local repo_path="${1:?repo-path required}"
  bash "$SKILL_DIR/verify-harness.sh" "$repo_path"
  echo ""
  bash "$LIB/install-commit-hook.sh" status "$repo_path" 2>/dev/null || true
}

# ---------- wizard（交互式引导） ----------
# 适合零态用户：一步步问，每步都有获取指引，不要求一次性传对所有参数
cmd_wizard() {
  local repo_path="${1:-}"
  if [[ -z "$repo_path" ]]; then
    echo ""
    echo "用法: install-harness.sh wizard <repo-path>"
    echo "     会交互式问你所有必要参数，并调用底层子命令完成装配。"
    exit 2
  fi
  [[ -d "$repo_path/.git" ]] || die "$repo_path 不是 git 仓库"
  repo_path=$(cd "$repo_path" && pwd)

  if [[ ! -t 0 ]]; then
    die "wizard 需要交互终端运行，非交互场景请改用 connect-tapd/connect-cnb/setup 子命令"
  fi

  need jq curl git python3

  cat <<EOF

┌────────────────────────────────────────────────────┐
│  harness-skills 装配向导                            │
│  目标仓库: $repo_path
└────────────────────────────────────────────────────┘

装配会做以下事：
  · 绑定 TAPD + CNB 凭据到 \$HOME/.codebuddy/secrets/ (0600 权限)
  · 在 CNB 上查/建一个仓库，把本地仓库 mirror 过去（可选）
  · 装 commit-msg + pre-push git hooks
  · 写入 .cnb.yml / .tapd.yml / .gitmessage / PR 模板 TAPD 段
  · 写入 .codebuddy/connections.yml（可 commit，不含凭据）

你需要提前准备（向导会在每步给获取指引）：
  · TAPD 公司ID + workspace_id + API 账号（user + password）
  · CNB 个人访问令牌（PAT）+ CNB 组织 path

---

EOF

  # ===== 步骤 1: TAPD =====
  echo "▶ 步骤 1/3: TAPD 凭据"
  echo ""
  echo "  获取 TAPD 公司ID：登录 https://www.tapd.cn 后，看任意页面 URL 第一段路径数字，如"
  echo "     www.tapd.cn/12345678/projects  →  公司ID = 12345678（仅作格式示例）"
  read -r -p "  你的 TAPD 公司ID: " tapd_company
  [[ -n "$tapd_company" ]] || die "公司ID 不能为空"

  echo ""
  echo "  获取 API 账号（如果已有可跳过）："
  echo "     https://www.tapd.cn/$tapd_company/open_platform/config"
  echo "     点「新建 API 账号」，务必勾选目标 workspace 授权，否则 403"

  # 尝试跨平台打开浏览器
  if command -v open >/dev/null 2>&1; then
    read -r -p "  要自动打开 API 账号管理页吗? [Y/n] " yn
    [[ "${yn:-y}" =~ ^[Yy] ]] && open "https://www.tapd.cn/$tapd_company/open_platform/config" >/dev/null 2>&1 || true
  elif command -v xdg-open >/dev/null 2>&1; then
    read -r -p "  要自动打开 API 账号管理页吗? [Y/n] " yn
    [[ "${yn:-y}" =~ ^[Yy] ]] && xdg-open "https://www.tapd.cn/$tapd_company/open_platform/config" >/dev/null 2>&1 || true
  fi

  echo ""
  read -r -p "  TAPD workspace_id（要接入的 TAPD 项目 id，10 位数字）: " tapd_ws
  [[ -n "$tapd_ws" ]] || die "workspace_id 不能为空"
  [[ "$tapd_ws" =~ ^[0-9]+$ ]] || die "workspace_id 只能是数字"

  read -r -p "  TAPD API User: " tapd_user
  [[ -n "$tapd_user" ]] || die "API User 不能为空"

  read -r -s -p "  TAPD API Password: " tapd_pass
  echo ""
  [[ -n "$tapd_pass" ]] || die "API Password 不能为空"

  read -r -p "  给这组 TAPD 凭据起一个 alias [${USER:-tapd}]: " tapd_alias
  tapd_alias="${tapd_alias:-${USER:-tapd}}"

  echo ""
  echo "  -> 验证 TAPD 凭据..."
  TAPD_COMPANY_ID="$tapd_company" \
  TAPD_API_USER="$tapd_user" \
  TAPD_API_PASSWORD="$tapd_pass" \
    cmd_connect_tapd "$tapd_alias" "$tapd_ws" || die "TAPD 连接失败，向导终止"

  # ===== 步骤 2: CNB =====
  echo ""
  echo "▶ 步骤 2/3: CNB 凭据"
  echo ""
  echo "  获取 CNB 个人访问令牌（PAT）："
  echo "     https://cnb.cool → 右上角头像 → 个人设置 → 访问令牌 (Access Tokens)"
  echo "     scope 勾选 \"repo\"，创建后复制 token（只显示一次）"

  if command -v open >/dev/null 2>&1; then
    read -r -p "  要自动打开 CNB 访问令牌页吗? [Y/n] " yn
    [[ "${yn:-y}" =~ ^[Yy] ]] && open "https://cnb.cool" >/dev/null 2>&1 || true
  elif command -v xdg-open >/dev/null 2>&1; then
    read -r -p "  要自动打开 CNB 访问令牌页吗? [Y/n] " yn
    [[ "${yn:-y}" =~ ^[Yy] ]] && xdg-open "https://cnb.cool" >/dev/null 2>&1 || true
  fi

  echo ""
  read -r -s -p "  CNB PAT: " cnb_tok
  echo ""
  [[ -n "$cnb_tok" ]] || die "CNB PAT 不能为空"

  read -r -p "  给 CNB 凭据起一个 alias [${USER:-cnb}]: " cnb_alias
  cnb_alias="${cnb_alias:-${USER:-cnb}}"

  echo ""
  echo "  -> 验证 CNB PAT..."
  CNB_TOKEN="$cnb_tok" cmd_connect_cnb "$cnb_alias" || die "CNB 连接失败，向导终止"

  # 列出用户的 CNB groups 让用户选
  echo ""
  echo "  你的 CNB 组织/group 列表："
  local groups_json
  groups_json=$(bash "$LIB/list-cnb-orgs.sh" "$cnb_alias" 2>/dev/null || echo "[]")
  local group_count
  group_count=$(echo "$groups_json" | jq '. | length')
  if [[ "$group_count" == "0" ]]; then
    echo "    （一个也没有）你需要先去 https://cnb.cool 左上角新建一个组织，然后重跑"
    die "没有可用的 CNB 组织"
  fi
  echo "$groups_json" | jq -r '.[] | "    · \(.path) (\(.role))  \(.remark // "")"'
  echo ""

  local default_group
  default_group=$(echo "$groups_json" | jq -r '.[0].path')
  read -r -p "  选一个 CNB 组织 path [$default_group]: " cnb_org
  cnb_org="${cnb_org:-$default_group}"

  local default_repo
  default_repo=$(basename "$repo_path")
  read -r -p "  CNB 仓库名 [$default_repo]: " cnb_repo
  cnb_repo="${cnb_repo:-$default_repo}"

  # ===== 步骤 3: setup =====
  echo ""
  echo "▶ 步骤 3/3: 装配仓库"
  echo ""
  read -r -p "  同时把本地仓库 mirror 到新 CNB 仓库? [Y/n] " yn
  local mirror_flag=""
  [[ "${yn:-y}" =~ ^[Yy] ]] && mirror_flag="--mirror"

  echo ""
  read -r -p "  是否启用本地兜底\"自动推 commit 到 TAPD\"钩子? (若 TAPD 项目已开 CNB 集成可关) [y/N] " yn
  local autopush_flag=""
  [[ "${yn:-n}" =~ ^[Yy] ]] && autopush_flag="--with-auto-push"

  echo ""
  echo "  -> 开始装配..."
  echo ""

  cmd_setup "$repo_path" \
    --auto-init \
    --tapd-alias="$tapd_alias" \
    --workspace-id="$tapd_ws" \
    --cnb-alias="$cnb_alias" \
    --cnb-org="$cnb_org" \
    --cnb-repo="$cnb_repo" \
    ${mirror_flag:-} \
    ${autopush_flag:-}

  echo ""
  echo "🎉 装配完成！下一步："
  echo "    从 TAPD 故事建 feature 分支:  $SKILL_DIR/start-feature.sh <story_id>"
  echo "    查看装配状态:                  $SKILL_DIR/install-harness.sh status $repo_path"
}

# ---------- dispatch ----------
cmd="${1:-}"
shift 2>/dev/null || true
case "$cmd" in
  connect-tapd) cmd_connect_tapd "$@" ;;
  connect-cnb)  cmd_connect_cnb "$@" ;;
  setup)        cmd_setup "$@" ;;
  status)       cmd_status "$@" ;;
  wizard)       cmd_wizard "$@" ;;
  ""|-h|--help)
    sed -n '2,45p' "$0"
    ;;
  *)
    die "未知子命令: $cmd。用 -h 查看用法。"
    ;;
esac
