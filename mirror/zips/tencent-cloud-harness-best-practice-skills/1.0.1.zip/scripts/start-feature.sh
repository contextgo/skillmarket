#!/usr/bin/env bash
# start-feature.sh — 从 TAPD 故事一键拉 feature 分支
#
# 用法:
#   start-feature.sh <story_id> [--alias=<tapd-alias>] [--from=<base-branch>]
#
# 参数:
#   story_id   TAPD 故事完整 ID（19 位）
#   --alias    TAPD 凭据 alias，默认从 .codebuddy/connections.yml 读
#   --from     feature 分支的基底分支，默认 main
#
# 行为:
#   1. 通过 TAPD API 查故事标题
#   2. 把标题转成分支友好的 slug（小写、去特殊字符、限 40 字符）
#   3. 分支名格式: feature/<短 story_id>-<slug>
#   4. 从 base-branch 拉取最新，checkout 新分支
#   5. 打印 commit message 建议（复用 tapd-commit-tag.sh 拿关键字）
#
# 退出码:
#   0 成功
#   2 参数错误
#   3 凭据 / connections 不存在
#   4 TAPD API 失败 / 分支创建失败

set -euo pipefail

story_id=""
alias_override=""
base_branch="main"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --alias=*) alias_override="${1#--alias=}"; shift ;;
    --from=*)  base_branch="${1#--from=}"; shift ;;
    -h|--help)
      sed -n '2,20p' "$0"
      exit 0
      ;;
    *) if [[ -z "$story_id" ]]; then story_id="$1"; fi; shift ;;
  esac
done

if [[ -z "$story_id" ]]; then
  echo "Usage: $0 <story_id> [--alias=<tapd-alias>] [--from=<base-branch>]" >&2
  exit 2
fi

for bin in jq git curl; do
  command -v "$bin" >/dev/null 2>&1 || { echo "ERROR: need $bin" >&2; exit 2; }
done

REPO_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || echo "")
if [[ -z "$REPO_ROOT" ]]; then
  echo "ERROR: 不在 git 仓库内" >&2
  exit 2
fi

# ---------- 读 connections ----------
CONN="$REPO_ROOT/.codebuddy/connections.yml"
if [[ ! -f "$CONN" ]]; then
  echo "ERROR: $CONN 不存在（先跑 P2 接入）" >&2
  exit 3
fi

tapd_alias="$alias_override"
if [[ -z "$tapd_alias" ]]; then
  tapd_alias=$(awk '
    /^tapd:[[:space:]]*$/ {in_sec=1; next}
    /^[A-Za-z]/ {if(in_sec==1) in_sec=0}
    in_sec && /^[[:space:]]+alias:/ {
      sub(/.*alias:[[:space:]]*"?/, ""); sub(/".*/, ""); sub(/[[:space:]].*/, "");
      print; exit
    }' "$CONN" 2>/dev/null || true)
fi

if [[ -z "$tapd_alias" ]]; then
  echo "ERROR: 无法确定 TAPD alias（connections.yml 缺 tapd.alias 且未传 --alias）" >&2
  exit 3
fi

workspace_id=$(awk '
  /^tapd:[[:space:]]*$/ {in_sec=1; next}
  /^[A-Za-z]/ {if(in_sec==1) in_sec=0}
  in_sec && /^[[:space:]]+workspace_id:/ {
    sub(/.*workspace_id:[[:space:]]*"?/, ""); sub(/".*/, ""); sub(/[[:space:]].*/, "");
    print; exit
  }' "$CONN" 2>/dev/null || true)

# ---------- 读凭据 ----------
ROOT="${CODEBUDDY_SECRETS_ROOT:-$HOME/.codebuddy/secrets}"
cred="$ROOT/tapd/$tapd_alias.json"
if [[ ! -f "$cred" ]]; then
  echo "ERROR: 凭据不存在: $cred" >&2
  exit 3
fi
api_user=$(jq -r '.api_user' "$cred")
api_password=$(jq -r '.api_password' "$cred")
base_url=$(jq -r '.base_url // "https://api.tapd.cn"' "$cred")

# ---------- 查故事标题 ----------
resp=$(curl -s --max-time 10 \
  -u "$api_user:$api_password" \
  "$base_url/stories?workspace_id=$workspace_id&id=$story_id" 2>/dev/null || echo "")

if [[ -z "$resp" ]]; then
  echo "ERROR: TAPD API 无响应" >&2
  exit 4
fi

status=$(echo "$resp" | jq -r '.status // 0')
if [[ "$status" != "1" ]]; then
  info=$(echo "$resp" | jq -r '.info // "unknown"')
  echo "ERROR: TAPD 返回失败: $info" >&2
  exit 4
fi

name=$(echo "$resp" | jq -r '.data[0].Story.name // ""')
if [[ -z "$name" ]]; then
  # 试 bug 和 task
  for kind in bugs tasks; do
    resp2=$(curl -s --max-time 10 -u "$api_user:$api_password" \
      "$base_url/$kind?workspace_id=$workspace_id&id=$story_id" 2>/dev/null || echo "")
    [[ -z "$resp2" ]] && continue
    case "$kind" in
      bugs) name=$(echo "$resp2" | jq -r '.data[0].Bug.title // ""') ;;
      tasks) name=$(echo "$resp2" | jq -r '.data[0].Task.name // ""') ;;
    esac
    [[ -n "$name" ]] && break
  done
fi

if [[ -z "$name" ]]; then
  echo "WARN: 未找到 story/bug/task id=$story_id 的标题，使用 placeholder" >&2
  name="work"
fi

# ---------- 生成 slug ----------
# 1. 小写；2. 非字母数字→连字符；3. 压缩连续 -；4. 去首尾 -；5. 限 40 字符
slug=$(printf '%s' "$name" \
  | tr '[:upper:]' '[:lower:]' \
  | LC_ALL=C sed -E 's/[^a-z0-9]+/-/g' \
  | sed -E 's/^-+|-+$//g' \
  | cut -c 1-40 \
  | sed -E 's/-+$//')
if [[ -z "$slug" ]]; then
  slug="work"
fi

# 短 ID：story 完整 19 位的后 7 位（和 TAPD 的短 ID 约定对齐）
short_id="${story_id: -7}"
if [[ ${#short_id} -lt 7 ]]; then short_id="$story_id"; fi

branch="feature/${short_id}-${slug}"

echo "== 从 TAPD 故事 ==> feature 分支 =="
echo "  story_id:  $story_id"
echo "  title:     $name"
echo "  branch:    $branch"
echo "  base:      $base_branch"
echo ""

# ---------- 拉分支 ----------
cd "$REPO_ROOT"

# 先确保在干净的 base_branch
current_branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "")
if [[ -n "$(git status --porcelain)" ]]; then
  echo "⚠  工作区有未提交改动。先 stash 或 commit 再来。" >&2
  git status --short
  exit 4
fi

# 尝试更新 base
git fetch origin "$base_branch" 2>/dev/null || true
git fetch cnb "$base_branch" 2>/dev/null || true

# checkout
if git show-ref --verify --quiet "refs/heads/$branch"; then
  echo "⚠  分支 $branch 已存在，直接切过去" >&2
  git checkout "$branch"
else
  # 决定从哪个 base 起
  if git show-ref --verify --quiet "refs/heads/$base_branch"; then
    git checkout "$base_branch"
    git pull --ff-only 2>/dev/null || true
  fi
  git checkout -b "$branch"
fi

echo ""
echo "✅ 已切到分支: $branch"
echo ""

# ---------- 提示 commit message ----------
tag_script="$(cd "$(dirname "$0")" && pwd)/tapd-commit-tag.sh"
if [[ -x "$tag_script" ]]; then
  echo "── 推荐 commit 关键字（已请求 TAPD 官方格式）──"
  "$tag_script" "$tapd_alias" "$story_id" --copy 2>/dev/null || \
    echo "  (获取失败，请手动去 TAPD 故事页右上角复制)"
  echo ""
fi

cat <<EOF
下一步:
  1. 改代码
  2. git add + git commit（注意 commit msg 末尾贴 TAPD 关键字，已复制到剪贴板）
  3. git push cnb $branch
  4. 去 https://cnb.cool 创 PR → main
     · AI Review 会自动在 PR 评论里给代码评审意见
     · CI（test + lint）会自动跑
     · 人类 reviewer 批准后合入 main
EOF
