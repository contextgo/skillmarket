#!/usr/bin/env python3
"""
nanoAR 报价单模板填充器

用法：
  python generate_quote_from_template.py --data payload.json [--template template.xlsx] [--output quote.xlsx]

说明：
- 基于固定 Excel 模板填充项目基础信息
- 优先填充“投影屏幕”和“投影设备”两行
- 其余行可通过 additional_items 传入，未传时保留为 0 金额占位项
"""

from __future__ import annotations

import json
import math
import re
import sys
from copy import deepcopy
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


CURRENT_DIR = Path(__file__).resolve().parent
SKILL_DIR = CURRENT_DIR.parent
DEFAULT_TEMPLATE = SKILL_DIR / "templates" / "光子透明屏项目报价单_Template_V1.1.xlsx"
DEFAULT_OUTPUT_DIR = Path(r"D:\99Downloads\WorkBuddy")


if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from calc_projector import FILM_DB, PROJECTOR_RECS  # noqa: E402


DEFAULT_SCREEN_UNIT_PRICES = {
    "38D": 3200,
    "2KD": 3500,
    "3KD": 4200,
    "HB1": 3500,
    "C1H": 5800,
    "C3T": 6800,
}

DEFAULT_EXTRA_ITEMS = [
    {"category": "互动设备", "detail": "互动设备", "unit": "套", "qty": 1, "unit_price": 0, "tax_rate": 0.0},
    {"category": "其他材料", "detail": "支架、线缆、配件", "unit": "套", "qty": 1, "unit_price": 0, "tax_rate": 0.13},
    {"category": "安装服务", "detail": "专业安装施工", "unit": "项", "qty": 1, "unit_price": 0, "tax_rate": 0.06},
    {"category": "售后服务", "detail": "一年质保服务 (免费)", "unit": "年", "qty": 1, "unit_price": 0, "tax_rate": 0.06},
]

ITEM_ROWS = [13, 14, 15, 16, 17, 18]
SHEET_NAME = "报价单"


def _to_float(value: Any, default: float = 0.0) -> float:
    if value in (None, ""):
        return default
    return float(value)


def _today_str() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def _valid_until_str(days: int = 30) -> str:
    return (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")


def _quote_no() -> str:
    return "Q" + datetime.now().strftime("%Y%m%d%H%M%S")


def _slugify(text: str) -> str:
    text = re.sub(r"[\\/:*?\"<>|]+", "_", text.strip())
    return text or "nanoAR项目"


def _env_level_label(env_lux: float) -> str:
    if env_lux <= 80:
        return "较弱"
    if env_lux <= 200:
        return "一般"
    if env_lux <= 400:
        return "较强"
    return "强光"


def _format_env_lux(env_lux: float) -> str:
    return f"{env_lux:g} lux（{_env_level_label(env_lux)}）"


def _format_glass_size(width_m: float, height_m: float) -> str:
    return f"宽{width_m:g}m × 高{height_m:g}m"


def _effective_lm(projector: dict[str, Any]) -> float:
    if projector.get("lm_real"):
        return float(projector["lm_real"])
    return float(projector["lm_rated"]) * 0.85


def _projector_records() -> list[dict[str, Any]]:
    records = []
    for brand, model, tech, lm_r, lm_real, throw_ratio, resolution, cost, sell in PROJECTOR_RECS:
        records.append({
            "brand": brand,
            "model": model,
            "tech": tech,
            "lm_rated": lm_r,
            "lm_real": lm_real,
            "throw_ratio": throw_ratio,
            "resolution": resolution,
            "cost": cost,
            "sell": sell,
        })
    return records


def _find_projector(brand: str | None = None, model: str | None = None) -> dict[str, Any] | None:
    for item in _projector_records():
        if brand and item["brand"] != brand:
            continue
        if model and item["model"] != model:
            continue
        return item
    return None


def _select_projector(data: dict[str, Any], width_m: float, height_m: float, env_lux: float) -> dict[str, Any]:
    brand = data.get("projector_brand")
    model = data.get("projector_model")
    found = _find_projector(brand=brand, model=model)
    if found:
        return found

    target_lm = env_lux * 10 * width_m * height_m
    candidates = [item for item in _projector_records() if _effective_lm(item) >= target_lm]
    if candidates:
        candidates.sort(key=lambda p: (p.get("sell") is None, p.get("sell") or p.get("cost") or math.inf, _effective_lm(p)))
        return candidates[0]

    records = _projector_records()
    records.sort(key=_effective_lm, reverse=True)
    return records[0]


def _normalize_additional_items(items: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    if not items:
        return deepcopy(DEFAULT_EXTRA_ITEMS)
    normalized = []
    for item in items[:4]:
        normalized.append({
            "category": item.get("category", "其他费用"),
            "detail": item.get("detail", item.get("category", "其他费用")),
            "unit": item.get("unit", "项"),
            "qty": _to_float(item.get("qty"), 1),
            "unit_price": _to_float(item.get("unit_price"), 0),
            "tax_rate": _to_float(item.get("tax_rate"), 0),
        })
    while len(normalized) < 4:
        normalized.append(deepcopy(DEFAULT_EXTRA_ITEMS[len(normalized)]))
    return normalized


def _prepare_payload(data: dict[str, Any]) -> dict[str, Any]:
    width_m = _to_float(data.get("glass_width_m") or data.get("width_m"))
    height_m = _to_float(data.get("glass_height_m") or data.get("height_m"))
    if not width_m or not height_m:
        raise ValueError("glass_width_m 和 glass_height_m 必须提供")

    env_lux = _to_float(data.get("env_lux") or data.get("E_lux"))
    if not env_lux:
        raise ValueError("env_lux 必须提供")

    film_model = (data.get("film_model") or "2KD").upper()
    if film_model not in FILM_DB:
        raise ValueError(f"未知膜型号：{film_model}")

    area_m2 = round(width_m * height_m, 2)
    projector = _select_projector(data, width_m, height_m, env_lux)

    screen_unit_price = _to_float(data.get("screen_unit_price"), DEFAULT_SCREEN_UNIT_PRICES.get(film_model, 3500))
    projector_unit_price = _to_float(data.get("projector_unit_price"), projector.get("sell") or projector.get("cost") or 0)

    return {
        "project_name": data.get("project_name") or "光子透明屏项目",
        "customer_name": data.get("customer_name") or "待补充",
        "customer_contact": data.get("customer_contact") or "待补充",
        "project_address": data.get("project_address") or "",
        "install_location": data.get("install_location") or "现场玻璃",
        "glass_size_text": data.get("glass_size_text") or _format_glass_size(width_m, height_m),
        "env_light_text": data.get("env_light_text") or _format_env_lux(env_lux),
        "quote_no": data.get("quote_no") or _quote_no(),
        "quote_date": data.get("quote_date") or _today_str(),
        "valid_until": data.get("valid_until") or _valid_until_str(),
        "prepared_by": data.get("prepared_by") or "nanoAR 方案顾问",
        "film_model": film_model,
        "screen_area_m2": area_m2,
        "screen_unit_price": screen_unit_price,
        "screen_tax_rate": _to_float(data.get("screen_tax_rate"), 0.13),
        "screen_detail": data.get("screen_detail") or f"光子屏{film_model} 面积{area_m2:.2f}m²",
        "projector_brand": projector["brand"],
        "projector_model": projector["model"],
        "projector_unit_price": projector_unit_price,
        "projector_tax_rate": _to_float(data.get("projector_tax_rate"), 0.13),
        "projector_detail": data.get("projector_detail") or f"{projector['brand']}{projector['model']} {projector['lm_rated']}lm {projector['resolution']} 投射比{projector['throw_ratio']}",
        "additional_items": _normalize_additional_items(data.get("additional_items")),
    }


def _set_item_row(ws, row: int, index: int, item: dict[str, Any]) -> None:
    ws[f"B{row}"] = index
    ws[f"C{row}"] = item["category"]
    ws[f"D{row}"] = item["detail"]
    ws[f"F{row}"] = item["unit"]
    ws[f"G{row}"] = item["qty"]
    ws[f"H{row}"] = item["unit_price"]
    ws[f"I{row}"] = f"=ROUND(G{row}*H{row},2)"
    ws[f"J{row}"] = item["tax_rate"]
    ws[f"K{row}"] = f"=ROUND(I{row}*(1+J{row}),2)"


def fill_workbook(template_path: Path, output_path: Path, payload: dict[str, Any]) -> Path:
    wb = load_workbook(template_path)
    ws = wb[SHEET_NAME]

    ws["D6"] = payload["project_name"]
    ws["G6"] = payload["install_location"]
    ws["J6"] = payload["quote_no"]
    ws["D7"] = payload["customer_name"]
    ws["G7"] = payload["glass_size_text"]
    ws["J7"] = payload["quote_date"]
    ws["D8"] = payload["customer_contact"]
    ws["G8"] = payload["env_light_text"]
    ws["J8"] = payload["valid_until"]
    ws["D9"] = payload["project_address"]
    ws["J9"] = payload["prepared_by"]

    screen_item = {
        "category": "投影屏幕",
        "detail": payload["screen_detail"],
        "unit": "m²",
        "qty": payload["screen_area_m2"],
        "unit_price": payload["screen_unit_price"],
        "tax_rate": payload["screen_tax_rate"],
    }
    projector_item = {
        "category": "投影设备",
        "detail": payload["projector_detail"],
        "unit": "台",
        "qty": 1,
        "unit_price": payload["projector_unit_price"],
        "tax_rate": payload["projector_tax_rate"],
    }
    all_items = [screen_item, projector_item, *payload["additional_items"]]

    for index, (row, item) in enumerate(zip(ITEM_ROWS, all_items), start=1):
        _set_item_row(ws, row, index, item)

    ws["K21"] = "=SUM($I$13:$I$18)"
    ws["K22"] = "=K23-K21"
    ws["K23"] = "=SUM($K$13:$K$18)"

    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)
    return output_path


def _default_output_path(payload: dict[str, Any]) -> Path:
    project_name = _slugify(payload["project_name"])
    date_part = str(payload["quote_date"])
    return DEFAULT_OUTPUT_DIR / f"报价单_{project_name}_{date_part}.xlsx"


def main() -> None:
    args = sys.argv[1:]
    if "--data" not in args:
        print("用法: python generate_quote_from_template.py --data payload.json [--template template.xlsx] [--output quote.xlsx]")
        sys.exit(1)

    data_path = Path(args[args.index("--data") + 1])
    template_path = Path(args[args.index("--template") + 1]) if "--template" in args else DEFAULT_TEMPLATE

    with data_path.open("r", encoding="utf-8") as f:
        raw = json.load(f)

    payload = _prepare_payload(raw)
    output_path = Path(args[args.index("--output") + 1]) if "--output" in args else _default_output_path(payload)

    final_path = fill_workbook(template_path, output_path, payload)
    summary = {
        "output": str(final_path),
        "template": str(template_path),
        "project_name": payload["project_name"],
        "film_model": payload["film_model"],
        "screen_area_m2": payload["screen_area_m2"],
        "screen_unit_price": payload["screen_unit_price"],
        "projector": f"{payload['projector_brand']} {payload['projector_model']}",
        "projector_unit_price": payload["projector_unit_price"],
        "quote_no": payload["quote_no"],
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
