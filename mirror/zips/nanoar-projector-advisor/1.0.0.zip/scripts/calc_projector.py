#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
from typing import Any

FILM_DB = {
    "38D": {"gain": 1.5, "transmittance": 0.78, "view_angle": 50, "scene": "标准橱窗、零售展示"},
    "2KD": {"gain": 2.0, "transmittance": 0.75, "view_angle": 45, "scene": "中等亮度需求、常规室内"},
    "3KD": {"gain": 3.0, "transmittance": 0.72, "view_angle": 42, "scene": "亮度优先型商业展示"},
    "HB1": {"gain": 0.68, "transmittance": 0.694, "view_angle": 45, "scene": "垂直玻璃、落地玻璃、商场橱窗"},
    "C1H": {"gain": 5.0, "transmittance": 0.62, "view_angle": 25, "scene": "定向展示、车载等高亮定向场景"},
    "C3T": {"gain": 9.5, "transmittance": 0.55, "view_angle": 15, "scene": "超高亮、窄视角场景"},
}

PROJECTOR_RECS = [
    ("华录", "HL-DU900C", "Laser", 9000, 8299, "1.21", "WUXGA", 23490, 27000),
    ("光峰", "AL-DU935", "Laser", 9300, 8207, "0.85-1.35", "WUXGA", 33060, 38000),
    ("华录", "HL-DU1050C", "Laser", 10500, 9860, "1.21", "WUXGA", 29800, 34500),
    ("爱普生", "CB-L770U", "Laser", 7000, 6300, "1.35-2.20", "WUXGA", 21000, 24800),
    ("松下", "PT-BMZ71C", "Laser", 7000, 6200, "1.09-1.77", "WUXGA", 22000, 25900),
    ("光峰", "AL-LU710", "Laser", 7000, 5950, "1.20", "WUXGA", 18800, 22900),
]


def ceil_to_500(value: float) -> int:
    return int(math.ceil(value / 500.0) * 500)


def effective_lm(projector: tuple[Any, ...]) -> float:
    lm_real = projector[4]
    lm_rated = projector[3]
    return float(lm_real or (lm_rated * 0.85))


def infer_height(width_m: float, aspect_ratio: str = "16:9") -> float:
    width_ratio, height_ratio = aspect_ratio.split(":")
    return width_m * float(height_ratio) / float(width_ratio)


def choose_film(install_location: str | None, env_lux: float) -> str:
    text = (install_location or "").lower()
    if any(key in text for key in ["玻璃", "落地", "vertical", "window"]):
        return "HB1"
    if env_lux >= 400:
        return "C1H"
    if env_lux >= 250:
        return "3KD"
    return "2KD"


def throw_distance_range(width_m: float, throw_ratio: str) -> str:
    if "-" in throw_ratio:
        low, high = throw_ratio.split("-", 1)
        return f"{width_m * float(low):.2f}-{width_m * float(high):.2f}m"
    return f"约 {width_m * float(throw_ratio):.2f}m"


def recommend_projector(required_lm: float) -> dict[str, Any]:
    records = []
    for brand, model, tech, lm_rated, lm_real, throw_ratio, resolution, cost, sell in PROJECTOR_RECS:
        record = {
            "brand": brand,
            "model": model,
            "tech": tech,
            "lm_rated": lm_rated,
            "lm_real": lm_real,
            "throw_ratio": throw_ratio,
            "resolution": resolution,
            "cost": cost,
            "sell": sell,
        }
        records.append(record)

    qualified = [r for r in records if float(r["lm_real"] or r["lm_rated"] * 0.85) >= required_lm]
    if qualified:
        qualified.sort(key=lambda r: (r["sell"] or r["cost"] or 10**9, r["lm_real"] or r["lm_rated"]))
        return qualified[0]

    records.sort(key=lambda r: (r["lm_real"] or r["lm_rated"] * 0.85), reverse=True)
    return records[0]


def calculate_solution(width_m: float, height_m: float | None, env_lux: float, install_location: str | None = None, film_model: str | None = None) -> dict[str, Any]:
    actual_height = height_m or infer_height(width_m)
    area_m2 = width_m * actual_height
    p_lux = env_lux * 10
    required_lm = p_lux * area_m2
    lm_bucket = ceil_to_500(required_lm)
    selected_film = (film_model or choose_film(install_location, env_lux)).upper()
    film = FILM_DB[selected_film]
    brightness_nit = p_lux * film["gain"] / math.pi
    projector = recommend_projector(required_lm)

    return {
        "width_m": round(width_m, 3),
        "height_m": round(actual_height, 3),
        "area_m2": round(area_m2, 2),
        "env_lux": env_lux,
        "p_lux": round(p_lux, 2),
        "required_lm": round(required_lm, 2),
        "lm_bucket": lm_bucket,
        "film_model": selected_film,
        "film_gain": film["gain"],
        "brightness_nit": round(brightness_nit, 1),
        "projector": projector,
        "throw_distance": throw_distance_range(width_m, str(projector["throw_ratio"])),
        "margin_policy": "不加工程余量",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="nanoAR 投影选型计算器（恢复版）")
    parser.add_argument("--width", type=float, required=True)
    parser.add_argument("--height", type=float)
    parser.add_argument("--env", type=float, required=True)
    parser.add_argument("--install-location", type=str, default="")
    parser.add_argument("--film", type=str)
    args = parser.parse_args()

    result = calculate_solution(
        width_m=args.width,
        height_m=args.height,
        env_lux=args.env,
        install_location=args.install_location,
        film_model=args.film,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
