#!/usr/bin/env python3
"""Quark OCR - 夸克扫描王文档转换服务"""
import sys
from pathlib import Path

# 导入公共模块 - 同级目录（发布版本）
SCRIPTS_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPTS_DIR))

from common import run_ocr, save_document_from_result

if __name__ == "__main__":
    run_ocr(result_handler_with_config=save_document_from_result)
