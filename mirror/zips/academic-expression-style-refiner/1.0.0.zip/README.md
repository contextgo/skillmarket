# Academic Expression Style Refiner

`academic-expression-style-refiner` 是一个面向中文社科写作、教育研究、音乐教育研究、音乐史写作与学术大众化表达的标准化 Skill 包。它的核心定位不是普通润色器，而是“学术表达诊断器 + 论文语言重构器 + 文体风格切换器 + 公众号写作教练 + 写作能力训练系统”。

## 1. Skill 简介

这个 Skill 适合处理以下任务：

- 论文表达不够学术，想知道哪里有问题、为什么有问题、怎样改
- 同一段内容需要在期刊论文、硕博论文、综述、职称论文、公众号文章之间切换
- 想把中西方音乐史、音乐教育、教育研究内容写得既专业又可读
- 想学习优秀公众号文章的结构和节奏，但不复制原文
- 想结合 iMA、Get 笔记、NotebookLM 导出的资料做风格学习或写作训练
- 想把数据描述、访谈材料、课堂观察写得更规范

## 2. 适用场景

- 社科类期刊论文修改
- 硕士论文、博士论文表达优化
- 文献综述与研究现状写作
- 开题报告与研究方案写作
- 教育研究报告与教研论文写作
- 中西方音乐史综述文章写作
- 中西方音乐史公众号推文写作
- 学术型公众号文章写作
- 科普与公共学术写作
- 访谈材料、课堂观察、问卷结果表达规范化
- 用户提供范文后的结构学习与风格迁移

## 3. 不适用场景

- 伪造研究数据、访谈材料、课堂记录或引用
- 代写整篇论文并规避作者责任
- 把营销文包装成学术研究
- 把缺少证据的观点写成确定结论
- 不得逐字模仿公众号范文或近似改写整篇文章

## 4. 安装方式

如果你的 Skill 生态支持本地文件夹加载，可直接使用本目录。若需要打包：

```bash
zip -r academic-expression-style-refiner.zip academic-expression-style-refiner \
  -x "*.DS_Store" \
  -x "__MACOSX/*" \
  -x "*.pyc" \
  -x "__pycache__/*"
```

生成 `.skill`：

```bash
cp academic-expression-style-refiner.zip academic-expression-style-refiner.skill
```

也可以运行本地脚本：

```bash
python3 academic-expression-style-refiner/scripts/package_skill.py academic-expression-style-refiner
```

## 5. 文件结构

```text
academic-expression-style-refiner/
├── SKILL.md
├── README.md
├── references/
├── templates/
├── examples/
├── tests/
└── scripts/
```

## 6. 使用方法

把用户需求或草稿直接交给 Skill 即可。Skill 会先识别任务类型和目标文体，再选择合适的输出模式，并给出问题诊断、示范改写和可迁移规则。

推荐调用语句：

```text
请用 Diagnostic Mode 帮我批改下面这段论文表达，指出哪些地方不够学术，并给出示范修改。
```

```text
我要写一篇中西方音乐史综述文章，请按学术综述的标准指导我搭建结构。
```

```text
我要写一篇中西方音乐史公众号推文，请帮我设计标题、开篇和文章结构。
```

```text
请把下面这段论文表达改成适合公众号发布的表达，但保留专业性。
```

```text
请把下面这段公众号表达改成更适合社科期刊论文的学术表达。
```

```text
我发给你一篇我觉得不错的公众号文章，请你分析它为什么好读，并告诉我如何迁移到我的音乐教育文章写作中。
```

```text
请结合我从 iMA / Get 笔记 / NotebookLM 导出的资料，帮我总结适合我模仿的公众号写作结构。
```

```text
请检查下面这段数据描述是否规范，尤其提醒我样本量、比例、因果推断和数据局限的问题。
```

```text
请检查下面这段访谈材料分析，帮我区分受访者原话、研究者解释和主题归纳。
```

```text
请帮我把下面这段课堂观察记录转化成更规范的研究分析表达。
```

## 7. 输出模式说明

- `Quick Fix Mode`：快速粗改，给出主要问题、3 到 5 条关键建议和优化版
- `Diagnostic Mode`：默认模式，输出文体判断、整体诊断、重点问题表、示范改写、可迁移规则和下一步建议
- `Line-by-Line Mode`：逐句批改
- `Teaching Mode`：写作训练模式，强调规则、练习与自检
- `Genre Switch Mode`：学术文体与公众号文体双向切换
- `WeChat Writing Coach Mode`：公众号写作教练模式
- `Example Learning Mode`：范文学习模式

## 8. 文体切换说明

Skill 会优先使用用户的明确指令进行路由：

- `综述 / 文献综述 / 国内外研究现状` -> Academic Review Mode
- `期刊论文 / 学术论文 / CSSCI / 北大核心` -> Journal Article Mode
- `硕士论文 / 博士论文 / 学位论文` -> Thesis Mode
- `公众号 / 推文 / 微信文章` -> WeChat Public Article Mode
- `科普文章 / 知识普及` -> Public Scholarship Mode
- `视频号口播 / 短视频文案` -> Short-form Speech Mode
- `讲座稿 / 分享稿 / 培训稿` -> Lecture or Presentation Mode
- `课堂观察 / 教学反思 / 教学案例` -> Teaching Case Analysis Mode
- `访谈分析 / 质性材料` -> Qualitative Analysis Mode
- `数据结果 / 问卷结果 / 统计描述` -> Data Reporting Mode

如果用户未明确说明，Skill 会先给出暂时判断，并提示可以切换标准。

## 9. 如何用于期刊论文

期刊论文模式会重点检查：

- 概念是否清晰
- 研究问题是否明确
- 论证链是否完整
- 数据或材料是否可追溯
- 是否存在口语化、宣传化、绝对化表达
- 是否过度拔高研究意义

## 10. 如何用于硕博论文

硕博论文模式会更强调：

- 概念界定
- 文献综述系统性
- 理论框架
- 方法说明
- 章节逻辑
- 研究边界

## 11. 如何用于中西方音乐史综述

Skill 会按学术综述标准检查：

- 研究对象是否过大
- 时间范围是否合理
- 中西方比较维度是否清楚
- 是否避免百科式罗列
- 是否有问题意识与研究脉络
- 是否兼顾风格、制度、人物、作品、审美与文化语境

## 12. 如何用于公众号学术文章

公众号模式会重点优化：

- 标题吸引力
- 开篇抓人能力
- 专业术语的转译
- 段落节奏
- 小标题结构
- 读者代入感
- 结尾传播价值

## 13. 如何学习用户提供的公众号范文

Skill 不会复制范文，而是提炼以下可迁移策略：

- 标题结构
- 开篇方式
- 问题设置
- 段落节奏
- 案例使用
- 观点句位置
- 结尾方式

并明确指出哪些地方不建议直接模仿。

## 14. 如何调用 iMA / Get 笔记 / NotebookLM 导出材料

本 Skill 采用“知识源适配层”而不是伪造 API。

支持三种方式：

1. 用户直接复制粘贴材料
2. 用户把导出后的文件夹放到本地目录，再让 Skill 读取
3. 未来若运行环境能验证存在 API / MCP / CLI，再扩展适配

Skill 不会擅自声称这些平台存在官方 API。

## 15. 如何用于数据描述

涉及问卷、评分、比例、样本量、前后测时，Skill 会提醒：

- 样本量是否明确
- 数据来源是否明确
- 时间范围是否明确
- 统计口径是否明确
- 是否区分描述性结果与推断性结论
- 是否把相关关系写成因果关系
- 是否说明局限

## 16. 如何用于访谈材料

涉及访谈或对话材料时，Skill 会提醒：

- 是否对受访者编号
- 是否保护隐私
- 是否说明访谈时间、对象与主题
- 是否区分原话与研究者解释
- 是否避免以个别访谈代表整体

## 17. 如何用于课堂观察

涉及课堂观察时，Skill 会提醒：

- 观察对象、时间和任务是否清楚
- 写的是可观察行为还是主观推断
- 是否有分析指标
- 是否可转化为研究数据
- 是否需要访谈、学生作品或问卷做互证

## 18. Token 高效使用说明

这个 Skill 默认不会对长文本逐句穷尽批改，而是：

- 优先抓最影响文本质量的问题
- 合并重复问题
- 选代表性句段示范修改
- 用“可迁移规则”替代重复说教
- 学习范文时只提炼写作策略，不复述整篇文章

## 19. 学术诚信说明

Skill 明确禁止：

- 不得伪造数据
- 不得伪造访谈
- 不得伪造文献
- 不得虚构课堂观察
- 不得把缺少证据的判断包装为确定结论

## 20. 版权与范文模仿边界说明

Skill 允许学习：

- 结构
- 节奏
- 标题策略
- 开篇方式
- 问题设置
- 知识转译方法

Skill 不允许：

- 不得逐字复制
- 不得近似改写整篇文章
- 不得把别人的原创观点当成用户自己的观点
- 不得模仿到足以造成来源混淆

## 21. 打包为 zip 的方法

```bash
zip -r academic-expression-style-refiner.zip academic-expression-style-refiner \
  -x "*.DS_Store" \
  -x "__MACOSX/*" \
  -x "*.pyc" \
  -x "__pycache__/*"
```

## 22. 打包为 .skill 的方法

```bash
cp academic-expression-style-refiner.zip academic-expression-style-refiner.skill
```

或者：

```bash
zip -r academic-expression-style-refiner.skill academic-expression-style-refiner \
  -x "*.DS_Store" \
  -x "__MACOSX/*" \
  -x "*.pyc" \
  -x "__pycache__/*"
```

## 23. 发布前检查清单

```text
[ ] SKILL.md 存在
[ ] YAML frontmatter 合法
[ ] name 使用 kebab-case
[ ] description 清楚说明用途
[ ] README.md 存在
[ ] references 文件完整
[ ] templates 文件完整
[ ] examples 文件完整
[ ] tests 文件完整
[ ] 有 genre routing 规则
[ ] 有 Academic Review Mode
[ ] 有 WeChat Public Article Mode
[ ] 有 Example Learning Mode
[ ] 有 Knowledge Base Integration 说明
[ ] 有公众号开篇与标题指导
[ ] 有中西方音乐史写作专项规则
[ ] 没有 API key
[ ] 没有 token
[ ] 没有 cookie
[ ] 没有远程下载脚本
[ ] 没有自动上传逻辑
[ ] 没有伪造文献或数据的内容
[ ] 没有鼓励复制范文的内容
[ ] 有版权与范文模仿边界说明
[ ] 有数据描述规范提醒
[ ] 有访谈材料规范提醒
[ ] 有课堂观察规范提醒
[ ] 有非学术化表达诊断规则
[ ] 有示范改写
[ ] 有可迁移写作规则
[ ] 有 token 高效使用协议
[ ] 可以打包为 zip
[ ] 可以打包为 .skill
```
