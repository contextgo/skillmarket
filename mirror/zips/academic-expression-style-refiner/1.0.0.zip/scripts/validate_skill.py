#!/usr/bin/env python3
"""Validate the academic-expression-style-refiner skill package."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

MAX_NAME_LENGTH = 64
MAX_DESCRIPTION_LENGTH = 1024
MAX_SKILL_BODY_LINES = 500

REQUIRED_DIRS = [
    "references",
    "templates",
    "examples",
    "tests",
    "scripts",
]

REQUIRED_FILES = [
    "SKILL.md",
    "README.md",
    "references/academic_expression_principles.md",
    "references/diagnostic_categories.md",
    "references/genre_router.md",
    "references/academic_review_writing_rules.md",
    "references/journal_article_writing_rules.md",
    "references/thesis_writing_rules.md",
    "references/wechat_public_article_rules.md",
    "references/public_scholarship_rules.md",
    "references/example_learning_rules.md",
    "references/knowledge_base_integration.md",
    "references/academic_expression_replacement_rules.md",
    "references/data_reporting_rules.md",
    "references/interview_material_rules.md",
    "references/classroom_observation_rules.md",
    "references/music_history_writing_rules.md",
    "references/readability_and_style.md",
    "references/genre_modes.md",
    "templates/diagnostic_mode_template.md",
    "templates/quick_fix_template.md",
    "templates/line_by_line_template.md",
    "templates/teaching_mode_template.md",
    "templates/genre_switch_template.md",
    "templates/academic_review_template.md",
    "templates/wechat_article_coach_template.md",
    "templates/example_learning_template.md",
    "templates/data_description_revision_template.md",
    "templates/interview_analysis_revision_template.md",
    "templates/academic_rewrite_template.md",
    "examples/example_non_academic_expression.md",
    "examples/example_academic_review_music_history.md",
    "examples/example_wechat_music_history_article.md",
    "examples/example_genre_switch_academic_to_wechat.md",
    "examples/example_wechat_article_learning.md",
    "examples/example_data_reporting_revision.md",
    "examples/example_interview_material_revision.md",
    "examples/example_music_education_paragraph.md",
    "examples/example_public_academic_writing.md",
    "tests/sample_inputs.md",
    "tests/expected_output_checklist.md",
    "scripts/validate_skill.py",
    "scripts/package_skill.py",
]

TEXT_SUFFIXES = {".md", ".py", ".txt", ".yaml", ".yml", ".json"}

CREDENTIAL_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9]{10,}"),
    re.compile(r"api[_-]?key\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{8,}", re.IGNORECASE),
    re.compile(r"secret\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{8,}", re.IGNORECASE),
    re.compile(r"authorization\s*:\s*bearer\s+[A-Za-z0-9._\-]+", re.IGNORECASE),
    re.compile(r"cookie\s*:\s*[^\\n]{8,}", re.IGNORECASE),
    re.compile(r"token\s*[:=]\s*['\"]?[A-Za-z0-9._\-]{8,}", re.IGNORECASE),
]

REMOTE_DOWNLOAD_PATTERNS = [
    re.compile(r"\bcurl\s+https?://", re.IGNORECASE),
    re.compile(r"\bwget\s+https?://", re.IGNORECASE),
    re.compile(r"urllib\.request\.urlretrieve", re.IGNORECASE),
    re.compile(r"requests\.(get|post)\(\s*['\"]https?://", re.IGNORECASE),
]

UPLOAD_PATTERNS = [
    re.compile(r"\bscp\s+", re.IGNORECASE),
    re.compile(r"\brsync\s+.*@", re.IGNORECASE),
    re.compile(r"upload_file", re.IGNORECASE),
    re.compile(r"gh\s+release\s+upload", re.IGNORECASE),
    re.compile(r"requests\.post\(\s*['\"]https?://", re.IGNORECASE),
]

RISKY_COPY_PATTERNS = [
    "逐字复制",
    "近似改写整篇",
    "伪造数据",
    "伪造文献",
    "伪造访谈",
    "自动上传",
]

NEGATION_HINTS = ("不", "不得", "不能", "不应", "禁止", "避免", "没有", "avoid", "never", "no ", "do not", "does not")


def _strip_quotes(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def parse_frontmatter(content: str) -> Dict[str, str]:
    match = re.match(r"^---\n(.*?)\n---\n", content, re.DOTALL)
    if not match:
        raise ValueError("SKILL.md is missing valid YAML frontmatter.")

    frontmatter_text = match.group(1)
    result: Dict[str, str] = {}

    for raw_line in frontmatter_text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if ":" not in line:
            raise ValueError(f"Invalid frontmatter line: {raw_line}")
        key, value = line.split(":", 1)
        result[key.strip()] = _strip_quotes(value)

    return result


def validate_frontmatter(skill_md: Path, errors: List[str]) -> None:
    content = skill_md.read_text(encoding="utf-8")
    try:
        frontmatter = parse_frontmatter(content)
    except ValueError as exc:
        errors.append(str(exc))
        return

    keys = set(frontmatter)
    if keys != {"name", "description"}:
        errors.append("SKILL.md frontmatter must contain only 'name' and 'description'.")

    name = frontmatter.get("name", "").strip()
    description = frontmatter.get("description", "").strip()

    if not name:
        errors.append("Frontmatter is missing 'name'.")
    elif not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
        errors.append("Frontmatter name must be kebab-case.")
    elif len(name) > MAX_NAME_LENGTH:
        errors.append(f"Frontmatter name exceeds {MAX_NAME_LENGTH} characters.")

    if not description:
        errors.append("Frontmatter is missing 'description'.")
    elif len(description) > MAX_DESCRIPTION_LENGTH:
        errors.append(f"Frontmatter description exceeds {MAX_DESCRIPTION_LENGTH} characters.")

    body = content.split("---\n", 2)[-1]
    if len(body.splitlines()) > MAX_SKILL_BODY_LINES:
        errors.append(f"SKILL.md body exceeds {MAX_SKILL_BODY_LINES} lines.")


def validate_directories(root: Path, errors: List[str]) -> None:
    for relative in REQUIRED_DIRS:
        path = root / relative
        if not path.exists():
            errors.append(f"Missing required directory: {relative}")
        elif not path.is_dir():
            errors.append(f"Required directory is not a directory: {relative}")


def validate_required_files(root: Path, errors: List[str]) -> None:
    for relative in REQUIRED_FILES:
        if not (root / relative).exists():
            errors.append(f"Missing required file: {relative}")


def iter_text_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() in TEXT_SUFFIXES:
            yield path


def validate_no_symlinks(root: Path, errors: List[str]) -> None:
    for path in root.rglob("*"):
        if path.is_symlink():
            errors.append(f"Symlink is not allowed: {path.relative_to(root)}")


def validate_dangerous_patterns(root: Path, errors: List[str]) -> None:
    for path in iter_text_files(root):
        if path.name == "validate_skill.py":
            continue
        content = path.read_text(encoding="utf-8", errors="ignore")
        rel = path.relative_to(root)
        for pattern in CREDENTIAL_PATTERNS:
            if pattern.search(content):
                errors.append(f"Possible credential-like content found in {rel}: {pattern.pattern}")
        for pattern in REMOTE_DOWNLOAD_PATTERNS:
            if pattern.search(content):
                errors.append(f"Remote download logic found in {rel}: {pattern.pattern}")
        for pattern in UPLOAD_PATTERNS:
            if pattern.search(content):
                errors.append(f"Upload logic found in {rel}: {pattern.pattern}")


def validate_risky_copying(root: Path, errors: List[str]) -> None:
    for path in iter_text_files(root):
        if path.name == "validate_skill.py":
            continue
        rel = path.relative_to(root)
        for line_number, raw_line in enumerate(path.read_text(encoding="utf-8", errors="ignore").splitlines(), start=1):
            line = raw_line.strip().lower()
            if not line:
                continue
            for phrase in RISKY_COPY_PATTERNS:
                if phrase in raw_line:
                    if not any(hint in line for hint in NEGATION_HINTS):
                        errors.append(
                            f"Risky phrase without clear prohibition in {rel}:{line_number}: {raw_line.strip()}"
                        )


def validate_core_content(root: Path, errors: List[str]) -> None:
    skill_text = (root / "SKILL.md").read_text(encoding="utf-8", errors="ignore")
    required_headings = [
        "## Purpose",
        "## When to use this skill",
        "## When not to use this skill",
        "## Core workflow",
        "## Genre detection and routing",
        "## Academic review writing mode",
        "## Journal article writing mode",
        "## Thesis writing mode",
        "## WeChat public article mode",
        "## Example learning mode",
        "## Knowledge base integration rules",
        "## Diagnostic categories",
        "## Academic expression principles",
        "## Data reporting rules",
        "## Interview material rules",
        "## Classroom observation rules",
        "## Music history writing notes",
        "## Music education writing notes",
        "## Output modes",
        "## Token efficiency protocol",
        "## Academic integrity and copyright constraints",
        "## Examples",
    ]
    for heading in required_headings:
        if heading not in skill_text:
            errors.append(f"Missing required SKILL.md section: {heading}")

    if "Prioritize high-impact writing issues." not in skill_text:
        errors.append("SKILL.md is missing the required token-efficiency English rule.")

    if "我会提炼这篇文章的写作策略，而不是复制它的语言。" not in skill_text:
        errors.append("SKILL.md is missing the recommended example-learning boundary wording.")

    if "不得逐字复制" not in skill_text and "never reproduce the source article" not in skill_text:
        errors.append("SKILL.md should clearly prohibit copying example texts.")


def validate_readme_content(root: Path, errors: List[str]) -> None:
    readme_text = (root / "README.md").read_text(encoding="utf-8", errors="ignore")
    required_strings = [
        "请用 Diagnostic Mode 帮我批改下面这段论文表达",
        "我要写一篇中西方音乐史综述文章",
        "我要写一篇中西方音乐史公众号推文",
        "请把下面这段论文表达改成适合公众号发布的表达",
        "请把下面这段公众号表达改成更适合社科期刊论文的学术表达",
        "请结合我从 iMA / Get 笔记 / NotebookLM 导出的资料",
    ]
    for item in required_strings:
        if item not in readme_text:
            errors.append(f"README.md is missing required usage example text: {item}")


def validate_skill_root(root: Path) -> Tuple[bool, Sequence[str]]:
    errors: List[str] = []

    if not root.exists():
        return False, [f"Path does not exist: {root}"]
    if not root.is_dir():
        return False, [f"Path is not a directory: {root}"]

    validate_directories(root, errors)
    validate_required_files(root, errors)
    skill_md = root / "SKILL.md"
    if skill_md.exists():
        validate_frontmatter(skill_md, errors)
        validate_core_content(root, errors)
    if (root / "README.md").exists():
        validate_readme_content(root, errors)
    validate_no_symlinks(root, errors)
    validate_dangerous_patterns(root, errors)
    validate_risky_copying(root, errors)

    return not errors, errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate the skill package structure and policy constraints.")
    parser.add_argument("path", nargs="?", default=".", help="Path to the skill root. Defaults to current directory.")
    args = parser.parse_args()

    root = Path(args.path).resolve()
    ok, errors = validate_skill_root(root)

    if ok:
        print("Skill package is valid.")
        return 0

    print("Skill package validation failed:")
    for error in errors:
        print(f"- {error}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
