#!/usr/bin/env python3
"""Package the academic-expression-style-refiner skill as .zip and .skill archives."""

from __future__ import annotations

import argparse
import shutil
import sys
import zipfile
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from validate_skill import validate_skill_root


def should_skip(path: Path) -> bool:
    parts = set(path.parts)
    if "__pycache__" in parts:
        return True
    if path.name in {".DS_Store"}:
        return True
    if path.suffix in {".pyc", ".zip", ".skill"}:
        return True
    return False


def write_archive(root: Path, destination: Path) -> Path:
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            if should_skip(path.relative_to(root)):
                continue
            arcname = Path(root.name) / path.relative_to(root)
            archive.write(path, arcname.as_posix())
    return destination


def package_skill(root: Path, output_dir: Path) -> tuple[Path, Path]:
    ok, errors = validate_skill_root(root)
    if not ok:
        joined = "\n".join(f"- {item}" for item in errors)
        raise ValueError(f"Validation failed:\n{joined}")

    output_dir.mkdir(parents=True, exist_ok=True)
    zip_path = output_dir / f"{root.name}.zip"
    skill_path = output_dir / f"{root.name}.skill"

    write_archive(root, zip_path)
    shutil.copyfile(zip_path, skill_path)

    return zip_path, skill_path


def main() -> int:
    parser = argparse.ArgumentParser(description="Package the skill into .zip and .skill archives.")
    parser.add_argument("path", nargs="?", default=".", help="Path to the skill root. Defaults to current directory.")
    parser.add_argument(
        "--output-dir",
        default="..",
        help="Output directory for archives. Defaults to the parent of the skill root.",
    )
    args = parser.parse_args()

    root = Path(args.path).resolve()
    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = (root / output_dir).resolve()

    try:
        zip_path, skill_path = package_skill(root, output_dir)
    except ValueError as exc:
        print(exc)
        return 1

    print(f"Created zip archive: {zip_path}")
    print(f"Created skill archive: {skill_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
