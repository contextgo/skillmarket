# Expected Output Checklist

## Routing and genre control

- [ ] 是否正确识别目标文体
- [ ] 是否能在综述和公众号之间切换标准
- [ ] 是否能区分文体模式与输出模式

## Diagnostic quality

- [ ] 是否指出非学术化表达
- [ ] 是否说明为什么有问题
- [ ] 是否提供示范改写
- [ ] 是否提供可迁移规则
- [ ] 是否能根据文体调整修改尺度
- [ ] 是否保持可读性，而不是一味改成僵硬论文腔

## Research-material discipline

- [ ] 是否提醒数据描述规范
- [ ] 是否提醒访谈材料规范
- [ ] 是否提醒课堂观察规范
- [ ] 是否避免伪造数据
- [ ] 是否避免伪造访谈或文献

## WeChat and example learning

- [ ] 是否能分析公众号范文的结构和开篇策略
- [ ] 是否没有复制或近似改写范文
- [ ] 是否能提炼标题、开头、节奏与转译策略

## Knowledge-base boundary

- [ ] 是否能说明知识库材料接入边界
- [ ] 是否没有伪造 iMA、Get 笔记、NotebookLM 的 API

## Efficiency

- [ ] 是否控制 token
- [ ] 是否优先处理高影响问题
- [ ] 是否在长文本场景下归并同类问题
