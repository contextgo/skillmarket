# Genre Modes

## 模式总览

| 模式 | 主要目标 | 重点检查 |
|---|---|---|
| Academic Review Mode | 建立研究脉络与学术判断 | 问题意识、维度划分、贡献与不足 |
| Journal Article Mode | 形成可发表的学术论证 | 概念、论证链、证据、研究边界 |
| Thesis Mode | 支撑系统性长文写作 | 综述、框架、方法、章节逻辑 |
| Professional Evaluation Paper Mode | 把经验转成可分析实践研究 | 对象、场景、过程、变化、价值 |
| Proposal Mode | 形成可执行研究方案 | 研究问题、意义、方法、材料、可行性 |
| WeChat Public Article Mode | 提高可读性和传播性 | 标题、开头、节奏、转译、结尾 |
| Public Scholarship Mode | 做准确而易懂的知识传播 | 概念解释、例子、准确性 |
| Short-form Speech Mode | 形成口播友好的短时表达 | 开场、节奏、口语流畅度、信息压缩 |
| Lecture / Presentation Mode | 服务讲述与现场理解 | 层次、提示语、段落功能 |
| Teaching Case Analysis Mode | 把教学记录转成案例分析 | 场景、对象、行动、变化、反思 |
| Qualitative Analysis Mode | 规范呈现访谈与质性材料 | 编号、主题、引语与解释分离 |
| Data Reporting Mode | 规范呈现量化结果 | 样本、指标、统计口径、局限 |

## 输出模式与文体模式区别

- 文体模式解决“按什么标准写”
- 输出模式解决“按什么形式回答”

例如：

- 用户说“我要写公众号文章” -> 文体模式切到 WeChat Public Article Mode
- 用户说“逐句批改” -> 输出模式切到 Line-by-Line Mode

两者可以同时存在。
