# Example: Genre Switch from Academic to WeChat

## Original

`人工智能技术的介入在一定程度上重构了音乐创作课堂中的任务组织方式与评价关系。`

## WeChat-oriented rewrite

`当 AI 进入音乐创作课，变化并不只是“多了一个工具”。它其实悄悄改写了课堂怎么布置任务、学生怎么尝试、老师又怎么评价作品。`

## Switch note

- 保留原本的核心判断
- 降低抽象度
- 增加可感知的课堂场景
- 让句子更适合普通读者进入
