# -*- coding: utf-8 -*-
"""
选品分析报告生成器 - 专业版
支持任意产品品类的选品分析报告生成
Version: 2.0 - 通用版
"""

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime
import os

# ══════════════════════════════════════════════════════════════
# 颜色系统
# ══════════════════════════════════════════════════════════════
C_DARK   = "1A3A5C"   # 深蓝（标题背景）
C_MID    = "2E6DB4"   # 中蓝（副标题）
C_ACCENT = "E8913A"   # 橙色（强调）
C_LIGHT  = "EBF3FB"   # 浅蓝（交替行）
C_GREEN  = "2D7D4F"   # 绿色（蓝海）
C_RED    = "C0392B"   # 红色（爆品）
C_PURPLE = "7B3F9E"   # 紫色（利润品）
C_WHITE  = "FFFFFF"
C_GRAY   = "F5F5F5"
C_YELLOW = "FFF3CD"   # 提示背景
C_TEAL   = "008B8B"   # 青色（竞争分析）


def make_fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)


def make_border(style="thin"):
    s = Side(style=style)
    return Border(left=s, right=s, top=s, bottom=s)


def hdr_font(size=11, bold=True, color=C_WHITE):
    return Font(name="微软雅黑", size=size, bold=bold, color=color)


def body_font(size=10, bold=False, color="000000"):
    return Font(name="微软雅黑", size=size, bold=bold, color=color)


def center(wrap=True):
    return Alignment(horizontal="center", vertical="center", wrap_text=wrap)


def left(wrap=True):
    return Alignment(horizontal="left", vertical="center", wrap_text=wrap)


def add_banner(ws, row, text, col_span, fill_color=C_DARK, font_size=14):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=col_span)
    c = ws.cell(row=row, column=1, value=text)
    c.fill = make_fill(fill_color)
    c.font = Font(name="微软雅黑", size=font_size, bold=True, color=C_WHITE)
    c.alignment = center()
    ws.row_dimensions[row].height = 36


def add_note(ws, row, col_span, text):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=col_span)
    c = ws.cell(row=row, column=1, value=text)
    c.fill = make_fill(C_YELLOW)
    c.font = Font(name="微软雅黑", size=9, italic=True, color="7D6608")
    c.alignment = left(wrap=True)
    ws.row_dimensions[row].height = 28


def set_col_widths(ws, widths):
    for col, w in widths.items():
        ws.column_dimensions[get_column_letter(col)].width = w


def write_data_table(ws, start_row, headers, data_rows, col_fills=None, alt_fill=C_LIGHT):
    """col_fills: dict {col: hex_color} for specific columns"""
    col_fills = col_fills or {}
    col_count = len(headers)

    # 写入表头
    for col in range(1, col_count + 1):
        c = ws.cell(row=start_row, column=col, value=headers[col-1])
        c.fill = make_fill(C_DARK)
        c.font = hdr_font(size=10)
        c.alignment = center()
        c.border = make_border()
    ws.row_dimensions[start_row].height = 30

    # 写入数据行
    for r_idx, row_data in enumerate(data_rows):
        row = start_row + 1 + r_idx
        bg = alt_fill if r_idx % 2 == 0 else C_GRAY
        for c_idx, val in enumerate(row_data):
            col = c_idx + 1
            c = ws.cell(row=row, column=col, value=val if val else "N/A")
            if col in col_fills:
                c.fill = make_fill(col_fills[col])
                c.font = hdr_font(size=9, color=C_WHITE, bold=False)
            else:
                c.fill = make_fill(bg)
                c.font = body_font(size=9)
            # 产品名称列左对齐
            c.alignment = left() if col in [1, 2, 3] else center()
            c.border = make_border()
        ws.row_dimensions[row].height = 45


def generate_report(product_name, output_dir, report_data):
    """
    生成专业选品分析报告

    参数:
        product_name: 产品名称
        output_dir: 输出目录
        report_data: 报告数据字典
    """
    wb = openpyxl.Workbook()
    today = datetime.now().strftime("%Y%m%d")
    report_date = datetime.now().strftime("%Y年%m月%d日")

    # ══════════════════════════════════════════════════════════
    # SHEET 1: 封面与总览
    # ══════════════════════════════════════════════════════════
    ws_cover = wb.active
    ws_cover.title = "封面与总览"
    ws_cover.sheet_view.showGridLines = False

    # 全宽标题
    ws_cover.merge_cells("A1:L1")
    t = ws_cover["A1"]
    t.value = f"🎯  {product_name}选品分析报告  |  外贸选品专用"
    t.fill = make_fill(C_DARK)
    t.font = Font(name="微软雅黑", size=20, bold=True, color=C_WHITE)
    t.alignment = center()
    ws_cover.row_dimensions[1].height = 56

    ws_cover.merge_cells("A2:L2")
    s = ws_cover["A2"]
    s.value = f"生成日期：{report_date}  |  数据来源：Amazon · Alibaba · 市场研究机构  |  数据时效：{today}前"
    s.fill = make_fill(C_MID)
    s.font = Font(name="微软雅黑", size=9, color=C_WHITE)
    s.alignment = center()
    ws_cover.row_dimensions[2].height = 22

    # 四列核心指标
    metrics_data = report_data.get("metrics", {})
    blue_count = len(report_data.get("blue_ocean", []))
    hot_count = len(report_data.get("hot_products", []))
    profit_count = len(report_data.get("profit_products", []))

    metrics = [
        ("🌐", "全球市场规模", metrics_data.get("market_size", "待调研"), metrics_data.get("market_growth", "CAGR待查"), C_DARK),
        ("📈", "行业增长率", metrics_data.get("market_growth", "待调研"), f"预测至{report_data.get('industry_overview', {}).get('forecast_year', '2030')}", C_MID),
        ("💰", "利润空间", metrics_data.get("profit_margin", "待调研"), f"零售=出厂×{metrics_data.get('price_multiplier', '3~8')}", C_ACCENT),
        ("📦", "选品方向", f"蓝海{blue_count}款 | 爆品{hot_count}款 | 利润{profit_count}款", "共计18款精选产品", C_TEAL),
    ]
    for i, (icon, label, val, sub, color) in enumerate(metrics):
        col_s = 1 + i * 3
        col_e = col_s + 2
        ws_cover.merge_cells(start_row=4, start_column=col_s, end_row=4, end_column=col_e)
        c = ws_cover.cell(row=4, column=col_s, value=f"{icon}  {label}")
        c.fill = make_fill(color)
        c.font = Font(name="微软雅黑", size=11, bold=True, color=C_WHITE)
        c.alignment = center()
        ws_cover.row_dimensions[4].height = 30

        ws_cover.merge_cells(start_row=5, start_column=col_s, end_row=5, end_column=col_e)
        c2 = ws_cover.cell(row=5, column=col_s, value=val)
        c2.fill = make_fill(color)
        c2.font = Font(name="微软雅黑", size=14, bold=True, color=C_WHITE)
        c2.alignment = center()
        ws_cover.row_dimensions[5].height = 40

        ws_cover.merge_cells(start_row=6, start_column=col_s, end_row=6, end_column=col_e)
        c3 = ws_cover.cell(row=6, column=col_s, value=sub)
        c3.fill = make_fill(color)
        c3.font = Font(name="微软雅黑", size=9, color=C_WHITE)
        c3.alignment = center()
        ws_cover.row_dimensions[6].height = 22

    # 行业概览摘要
    overview = report_data.get("industry_overview", {})
    add_banner(ws_cover, 8, "📊  行业概览", 12, C_DARK, 12)

    overview_items = [
        ("全球市场规模", overview.get("market_size_global", "待调研")),
        ("中国市场规模", overview.get("market_size_cn", "待调研")),
        ("复合增长率(CAGR)", overview.get("cagr", "待调研")),
        (f"预测规模({overview.get('forecast_year', '2030')}年)", overview.get("forecast_size", "待调研")),
        ("市场集中度", overview.get("market_concentration", "待调研")),
        ("主要驱动因素", " / ".join(overview.get("key_drivers", ["待调研"]))),
    ]
    for i, (k, v) in enumerate(overview_items):
        row = 9 + i
        bg = C_LIGHT if i % 2 == 0 else C_GRAY
        for col in range(1, 13):
            c = ws_cover.cell(row=row, column=col)
            c.fill = make_fill(bg)
            c.border = make_border()
        ws_cover.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
        kc = ws_cover.cell(row=row, column=1, value=k)
        kc.font = Font(name="微软雅黑", size=9, bold=True, color="1A3A5C")
        kc.fill = make_fill(bg)
        kc.alignment = left()

        ws_cover.merge_cells(start_row=row, start_column=5, end_row=row, end_column=12)
        vc = ws_cover.cell(row=row, column=5, value=v)
        vc.font = Font(name="微软雅黑", size=9)
        vc.fill = make_fill(bg)
        vc.alignment = left()
        ws_cover.row_dimensions[row].height = 24

    # 行业基础数据表
    add_banner(ws_cover, 16, "📈  行业基础数据", 12, C_DARK, 12)

    industry_data = report_data.get("industry_data", [])
    for i, (k, v, src) in enumerate(industry_data):
        row = 17 + i
        bg = C_LIGHT if i % 2 == 0 else C_GRAY
        for col in range(1, 13):
            c = ws_cover.cell(row=row, column=col)
            c.fill = make_fill(bg)
            c.border = make_border()
        ws_cover.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
        kc = ws_cover.cell(row=row, column=1, value=k)
        kc.font = Font(name="微软雅黑", size=9, bold=True, color="1A3A5C")
        kc.fill = make_fill(bg)
        kc.alignment = left()

        ws_cover.merge_cells(start_row=row, start_column=5, end_row=row, end_column=8)
        vc = ws_cover.cell(row=row, column=5, value=v)
        vc.font = Font(name="微软雅黑", size=9, bold=True)
        vc.fill = make_fill(bg)
        vc.alignment = center()

        ws_cover.merge_cells(start_row=row, start_column=9, end_row=row, end_column=12)
        sc = ws_cover.cell(row=row, column=9, value=src)
        sc.font = Font(name="微软雅黑", size=8, color="888888", italic=True)
        sc.fill = make_fill(bg)
        sc.alignment = center()
        ws_cover.row_dimensions[row].height = 22

    # 快速测试优先级
    start_row = 17 + len(industry_data) + 2
    add_banner(ws_cover, start_row, "⏱️  快速测试优先级（按验证难易排序）", 12, C_ACCENT, 12)

    priorities = report_data.get("priorities", [])
    for i, item in enumerate(priorities):
        row = start_row + 1 + i
        num, label, action, timing, color = item
        for col in range(1, 13):
            c = ws_cover.cell(row=row, column=col)
            c.fill = make_fill(color if col <= 2 else C_LIGHT)
            c.border = make_border()
        ws_cover.merge_cells(start_row=row, start_column=1, end_row=row, end_column=1)
        nc = ws_cover.cell(row=row, column=1, value=num)
        nc.font = Font(name="微软雅黑", size=14, bold=True, color=C_WHITE)
        nc.alignment = center()

        ws_cover.merge_cells(start_row=row, start_column=2, end_row=row, end_column=2)
        lc = ws_cover.cell(row=row, column=2, value=label)
        lc.font = Font(name="微软雅黑", size=10, bold=True, color=C_WHITE)
        lc.alignment = center()

        ws_cover.merge_cells(start_row=row, start_column=3, end_row=row, end_column=10)
        ac = ws_cover.cell(row=row, column=3, value=action)
        ac.font = Font(name="微软雅黑", size=9, color="000000")
        ac.alignment = left()

        ws_cover.merge_cells(start_row=row, start_column=11, end_row=row, end_column=12)
        tc = ws_cover.cell(row=row, column=11, value=timing)
        tc.font = Font(name="微软雅黑", size=9, bold=True, color=C_WHITE)
        tc.alignment = center()
        ws_cover.row_dimensions[row].height = 32

    set_col_widths(ws_cover, {1: 12, 2: 12, 3: 28, 4: 14, 5: 14, 6: 14, 7: 14, 8: 14, 9: 14, 10: 14, 11: 10, 12: 10})

    # ══════════════════════════════════════════════════════════
    # SHEET 2: 蓝海品
    # ══════════════════════════════════════════════════════════
    ws_blue = wb.create_sheet("蓝海品")
    ws_blue.sheet_view.showGridLines = False

    blue_ocean = report_data.get("blue_ocean", [])
    count = len(blue_ocean)
    add_banner(ws_blue, 1, f"🌊  蓝海品（{count}款）— 技术壁垒 / 认证壁垒 / 功能细分 | 竞争少 增长快", 14, C_GREEN, 13)
    add_note(ws_blue, 2, 14,
        "💡 蓝海品定义：竞争者少、有技术/认证/功能壁垒，市场增速高于行业均值（>8%/年），具有持续增长潜力。"
        "适合：有稳定供应链基础，希望建立长期护城河的销售团队。综合评分≥4分为蓝海候选。")

    headers = ["产品名称", "核心卖点", "目标客群", "零售价(USD)", "出厂价(USD)", "毛利", "认证/壁垒", "竞争度", "社媒热度", "切入建议", "供应商难度", "风险提示"]
    data = [[
        p.get("name", ""),
        p.get("selling_point", ""),
        p.get("target", ""),
        p.get("retail_price", ""),
        p.get("b2b_price", ""),
        p.get("margin", ""),
        p.get("certification", ""),
        p.get("competition", ""),
        p.get("social_trend", ""),
        p.get("entry_strategy", ""),
        p.get("supplier_difficulty", ""),
        p.get("risk", ""),
    ] for p in blue_ocean]

    write_data_table(ws_blue, 4, headers, data,
        col_fills={7: C_GREEN, 9: C_GREEN}, alt_fill=C_LIGHT)
    set_col_widths(ws_blue, {1: 22, 2: 32, 3: 16, 4: 12, 5: 12, 6: 8, 7: 16, 8: 10, 9: 20, 10: 28, 11: 12, 12: 24})

    # ══════════════════════════════════════════════════════════
    # SHEET 3: 爆品潜质
    # ══════════════════════════════════════════════════════════
    ws_hot = wb.create_sheet("爆品潜质")
    ws_hot.sheet_view.showGridLines = False

    hot_products = report_data.get("hot_products", [])
    count = len(hot_products)
    add_banner(ws_hot, 1, f"🔥  爆品潜质（{count}款）— 社交传播力强 / 销量已验证 / Z世代驱动", 14, C_RED, 13)
    add_note(ws_hot, 2, 14,
        "💡 爆品定义：已在Amazon/AliExpress验证高销量，TikTok/Instagram等社媒热度持续攀升，"
        "或具有强烈视觉冲击力的产品。适合：有短视频运营能力，追求快速出单的销售团队。综合评分≥4分为爆品候选。")

    headers = ["产品名称", "核心卖点", "目标客群", "Amazon月销", "AliExpress月销", "Amazon评分", "零售价(USD)", "毛利", "社媒热度", "切入建议", "启动资金", "验证周期"]
    data = [[
        p.get("name", ""),
        p.get("selling_point", ""),
        p.get("target", ""),
        p.get("amazon_monthly_sales", ""),
        p.get("aliexpress_monthly_sales", ""),
        p.get("amazon_rating", ""),
        p.get("retail_price", ""),
        p.get("margin", ""),
        p.get("social_metrics", ""),
        p.get("entry_strategy", ""),
        p.get("investment", ""),
        p.get("time_to_market", ""),
    ] for p in hot_products]

    write_data_table(ws_hot, 4, headers, data,
        col_fills={9: C_RED}, alt_fill=C_LIGHT)
    set_col_widths(ws_hot, {1: 22, 2: 28, 3: 14, 4: 14, 5: 16, 6: 10, 7: 12, 8: 8, 9: 20, 10: 26, 11: 12, 12: 10})

    # ══════════════════════════════════════════════════════════
    # SHEET 4: 利润品
    # ══════════════════════════════════════════════════════════
    ws_profit = wb.create_sheet("利润品")
    ws_profit.sheet_view.showGridLines = False

    profit_products = report_data.get("profit_products", [])
    count = len(profit_products)
    add_banner(ws_profit, 1, f"💰  利润品（{count}款）— 成本低 / 批量稳定 / 复购率高", 14, C_PURPLE, 13)
    add_note(ws_profit, 2, 14,
        "💡 利润品定义：出厂成本低，零售溢价空间大，标准化程度高，适合B2B批量走量或礼品套装捆绑销售。"
        "适合：追求稳定毛利、快速资金周转的销售团队。综合评分≥4分为利润品候选。")

    headers = ["产品名称", "核心卖点", "目标客群", "出厂价(USD)", "零售价(USD)", "毛利", "MOQ", "生产周期", "物流成本", "切入建议", "捆绑机会", "注意事项"]
    data = [[
        p.get("name", ""),
        p.get("selling_point", ""),
        p.get("target", ""),
        p.get("b2b_price", ""),
        p.get("retail_price", ""),
        p.get("margin", ""),
        p.get("moq", ""),
        p.get("production_cycle", ""),
        p.get("shipping_cost", ""),
        p.get("entry_strategy", ""),
        p.get("bundle_opportunity", ""),
        p.get("note", ""),
    ] for p in profit_products]

    write_data_table(ws_profit, 4, headers, data,
        col_fills={6: C_PURPLE}, alt_fill=C_LIGHT)
    set_col_widths(ws_profit, {1: 22, 2: 28, 3: 14, 4: 12, 5: 12, 6: 8, 7: 10, 8: 10, 9: 12, 10: 26, 11: 20, 12: 22})

    # ══════════════════════════════════════════════════════════
    # SHEET 5: 竞争分析
    # ══════════════════════════════════════════════════════════
    ws_comp = wb.create_sheet("竞争分析")
    ws_comp.sheet_view.showGridLines = False

    comp = report_data.get("competition_analysis", {})
    add_banner(ws_comp, 1, "🔍  市场竞争格局分析", 12, C_TEAL, 13)
    add_note(ws_comp, 2, 12,
        "💡 竞争分析帮助您了解市场饱和度、头部玩家策略、价格带分布，找准差异化切入机会。")

    # 市场概况
    add_banner(ws_comp, 4, "📊  市场概况", 12, C_DARK, 11)

    comp_summary = [
        ("估算卖家总数", comp.get("total_sellers", "待调研")),
        ("头部品牌", " / ".join(comp.get("top_brands", ["待调研"]))),
        ("市场集中度", comp.get("market_concentration", "待调研")),
        ("进入壁垒", " / ".join(comp.get("barriers_to_entry", ["待调研"]))),
    ]
    for i, (k, v) in enumerate(comp_summary):
        row = 5 + i
        bg = C_LIGHT if i % 2 == 0 else C_GRAY
        ws_comp.merge_cells(start_row=row, start_column=1, end_row=row, end_column=4)
        kc = ws_comp.cell(row=row, column=1, value=k)
        kc.fill = make_fill(bg)
        kc.font = Font(name="微软雅黑", size=10, bold=True)
        kc.alignment = left()
        ws_comp.merge_cells(start_row=row, start_column=5, end_row=row, end_column=12)
        vc = ws_comp.cell(row=row, column=5, value=v)
        vc.fill = make_fill(bg)
        vc.font = Font(name="微软雅黑", size=10)
        vc.alignment = left()
        ws_comp.row_dimensions[row].height = 26

    # 价格带分析
    add_banner(ws_comp, 10, "💲  价格带竞争分析", 12, C_DARK, 11)

    price_headers = ["价格区间", "竞争激烈程度", "机会点", "建议策略"]
    price_data = comp.get("price_segments", [])
    if price_data:
        for col, hdr in enumerate(price_headers, 1):
            c = ws_comp.cell(row=11, column=col, value=hdr)
            c.fill = make_fill(C_MID)
            c.font = hdr_font(size=10)
            c.alignment = center()
            c.border = make_border()
        ws_comp.row_dimensions[11].height = 28

        for i, seg in enumerate(price_data):
            row = 12 + i
            bg = C_LIGHT if i % 2 == 0 else C_GRAY
            vals = [
                seg.get("range", ""),
                seg.get("competition", ""),
                seg.get("opportunity", ""),
                seg.get("strategy", ""),
            ]
            for col, val in enumerate(vals, 1):
                c = ws_comp.cell(row=row, column=col, value=val)
                c.fill = make_fill(bg)
                c.font = body_font(size=10)
                c.alignment = left()
                c.border = make_border()
            ws_comp.row_dimensions[row].height = 30

    # 主要玩家分析
    add_banner(ws_comp, 18, "🏢  主要玩家分析", 12, C_DARK, 11)

    player_headers = ["品牌/卖家", "市场份额", "核心优势", "主要弱点", "价格区间", "定位"]
    players = comp.get("key_players", [])
    if players:
        for col, hdr in enumerate(player_headers, 1):
            c = ws_comp.cell(row=19, column=col, value=hdr)
            c.fill = make_fill(C_MID)
            c.font = hdr_font(size=10)
            c.alignment = center()
            c.border = make_border()
        ws_comp.row_dimensions[19].height = 28

        for i, player in enumerate(players):
            row = 20 + i
            bg = C_LIGHT if i % 2 == 0 else C_GRAY
            vals = [
                player.get("name", ""),
                player.get("market_share", ""),
                player.get("strength", ""),
                player.get("weakness", ""),
                player.get("price_range", ""),
                player.get("positioning", ""),
            ]
            for col, val in enumerate(vals, 1):
                c = ws_comp.cell(row=row, column=col, value=val)
                c.fill = make_fill(bg)
                c.font = body_font(size=10)
                c.alignment = left()
                c.border = make_border()
            ws_comp.row_dimensions[row].height = 35

    # 差异化机会
    diff_row = 20 + len(players) + 2 if players else 22
    add_banner(ws_comp, diff_row, "🎯  差异化机会", 12, C_ACCENT, 11)

    diff_opps = comp.get("differentiation_opportunities", [])
    for i, opp in enumerate(diff_opps):
        row = diff_row + 1 + i
        bg = C_LIGHT if i % 2 == 0 else C_GRAY
        ws_comp.merge_cells(start_row=row, start_column=1, end_row=row, end_column=12)
        c = ws_comp.cell(row=row, column=1, value=f"✓  {opp}")
        c.fill = make_fill(bg)
        c.font = Font(name="微软雅黑", size=10)
        c.alignment = left()
        ws_comp.row_dimensions[row].height = 26

    set_col_widths(ws_comp, {1: 14, 2: 16, 3: 24, 4: 24, 5: 14, 6: 14, 7: 14, 8: 14, 9: 14, 10: 14, 11: 14, 12: 14})

    # ══════════════════════════════════════════════════════════
    # SHEET 6: 数据来源
    # ══════════════════════════════════════════════════════════
    ws_src = wb.create_sheet("数据来源")
    ws_src.sheet_view.showGridLines = False

    add_banner(ws_src, 1, "📚  数据来源说明", 10, C_DARK, 13)
    add_note(ws_src, 2, 10,
        "⚠️  数据时效说明：市场数据通常有3-6个月滞后；平台销量数据为估算值；预测数据基于当前趋势推算。仅供参考。")

    sources = report_data.get("sources", [])

    headers_src = ["序号", "数据来源", "数据类型", "链接", "数据时效"]
    for col, hdr in enumerate(headers_src, 1):
        c = ws_src.cell(row=4, column=col, value=hdr)
        c.fill = make_fill(C_MID)
        c.font = hdr_font(size=10)
        c.alignment = center()
        c.border = make_border()
    ws_src.row_dimensions[4].height = 28

    for i, source in enumerate(sources):
        row = 5 + i
        bg = C_LIGHT if i % 2 == 0 else C_GRAY
        # 兼容4字段或5字段
        num = source[0] if len(source) > 0 else str(i+1)
        src = source[1] if len(source) > 1 else ""
        desc = source[2] if len(source) > 2 else ""
        url = source[3] if len(source) > 3 else ""
        freshness = source[4] if len(source) > 4 else "待标注"
        vals = [num, src, desc, url, freshness]
        for col, val in enumerate(vals, 1):
            c = ws_src.cell(row=row, column=col, value=val)
            c.fill = make_fill(bg)
            c.font = body_font(size=9)
            c.alignment = left() if col in [2, 3] else center()
            c.border = make_border()
        ws_src.row_dimensions[row].height = 28

    set_col_widths(ws_src, {1: 6, 2: 24, 3: 48, 4: 50, 5: 14})

    # 保存文件
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, f"{product_name}选品分析报告_{today}.xlsx")
    wb.save(output_path)
    print(f"[OK] 报告已保存：{output_path}")
    return output_path
