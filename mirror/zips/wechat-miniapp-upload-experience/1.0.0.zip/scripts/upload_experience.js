#!/usr/bin/env node
'use strict';

const childProcess = require('child_process');
const fs = require('fs');
const path = require('path');

function printUsage() {
  console.log(`Usage:
  node scripts/upload_experience.js --project <repo-path> [options]

Options:
  --project <path>         Target repo path. Defaults to current working directory.
  --private-key <path>     Path to the WeChat upload private key (.key).
  --robot <number>         CI robot slot. Defaults to 1 or WECHAT_CI_ROBOT.
  --version <string>       Upload version. Defaults to a timestamp version.
  --desc <string>          Upload description. Defaults to "Codex upload <version>".
  --appid <string>         Override appid from project.config.json.
  --project-type <type>    Override inferred project type: miniProgram, miniGame, plugin.
  --threads <number>       Upload thread count.
  --ci-module <path>       Explicit path to miniprogram-ci.
  --config <path>          Optional external config JSON file.
  --setup                  Bootstrap config and install miniprogram-ci for this project.
  --doctor                 Only run prerequisite checks and print next actions.
  --dry-run                Validate inputs and print the resolved plan without uploading.
  --help                   Show this help.

Environment variable fallbacks:
  WECHAT_CI_CONFIG
  WECHAT_PRIVATE_KEY_PATH
  WECHAT_CI_MODULE
  WECHAT_CI_ROBOT
  WECHAT_CI_VERSION
  WECHAT_CI_DESC
  WECHAT_CI_PROJECT_TYPE
  WECHAT_CI_THREADS
`);
}

function fail(message, error) {
  console.error(`[ERROR] ${message}`);
  if (error && error.stack) {
    console.error(error.stack);
  } else if (error && error.message) {
    console.error(error.message);
  }
  process.exit(1);
}

function failWithGuidance(message, guidance) {
  console.error(`[ERROR] ${message}`);
  if (guidance && guidance.length > 0) {
    console.error('[NEXT]');
    for (const item of guidance) {
      console.error(`- ${item}`);
    }
  }
  process.exit(1);
}

function parseArgs(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (token === '--help' || token === '-h') {
      args.help = true;
      continue;
    }
    if (token === '--dry-run') {
      args.dryRun = true;
      continue;
    }
    if (token === '--doctor') {
      args.doctor = true;
      continue;
    }
    if (token === '--setup') {
      args.setup = true;
      continue;
    }
    if (!token.startsWith('--')) {
      fail(`Unknown argument: ${token}`);
    }

    const key = token.slice(2);
    const value = argv[i + 1];
    if (value == null || value.startsWith('--')) {
      fail(`Missing value for --${key}`);
    }
    args[key] = value;
    i += 1;
  }
  return args;
}

function readJson(filePath) {
  try {
    const text = fs.readFileSync(filePath, 'utf8').replace(/^\uFEFF/, '');
    return JSON.parse(text);
  } catch (error) {
    fail(`Failed to read JSON from ${filePath}`, error);
  }
}

function ensureFileExists(filePath, label) {
  if (!fs.existsSync(filePath)) {
    fail(`${label} does not exist: ${filePath}`);
  }
}

function toAbsolutePath(inputPath) {
  return path.resolve(process.cwd(), inputPath);
}

function toAbsoluteFromBase(inputPath, baseDir) {
  if (!inputPath) {
    return null;
  }
  if (path.isAbsolute(inputPath)) {
    return inputPath;
  }
  return path.resolve(baseDir, inputPath);
}

function getDefaultConfigPath() {
  const userProfile = process.env.USERPROFILE || process.env.HOME;
  if (!userProfile) {
    return null;
  }
  return path.join(userProfile, '.codex', 'wechat-ci', 'config.json');
}

function getDefaultKeyPath(appid) {
  const userProfile = process.env.USERPROFILE || process.env.HOME;
  if (!userProfile || !appid) {
    return null;
  }
  return path.join(userProfile, '.codex', 'wechat-ci', 'keys', `${appid}.key`);
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function writeJson(filePath, value) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

function normalizePackageName(name) {
  return (
    name
      .toLowerCase()
      .replace(/[^a-z0-9-]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .replace(/-{2,}/g, '-') || 'wechat-miniapp-project'
  );
}

function inferProjectType(projectConfig, explicitType) {
  if (explicitType) {
    return explicitType;
  }

  const compileType = projectConfig.compileType;
  if (compileType === 'game') {
    return 'miniGame';
  }
  if (compileType === 'miniprogram') {
    return 'miniProgram';
  }
  if (compileType === 'plugin') {
    return 'plugin';
  }

  fail(`Unsupported compileType in project.config.json: ${compileType}`);
}

function deriveSetting(projectConfig) {
  const source = projectConfig.setting || {};
  const setting = {};

  if (typeof source.es6 === 'boolean') {
    setting.es6 = source.es6;
  }
  if (typeof source.newFeature === 'boolean') {
    setting.es7 = source.newFeature;
  }
  if (typeof source.minified === 'boolean') {
    setting.minify = source.minified;
  }
  if (typeof source.postcss === 'boolean') {
    setting.autoPrefixWXSS = source.postcss;
  }

  return setting;
}

function pad(number) {
  return String(number).padStart(2, '0');
}

function makeTimestampVersion() {
  const now = new Date();
  return [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate()),
  ].join('.') + '-' + [pad(now.getHours()), pad(now.getMinutes()), pad(now.getSeconds())].join('');
}

function resolveCiModule(projectPath, explicitPath) {
  const candidates = [];
  if (explicitPath) {
    candidates.push(toAbsolutePath(explicitPath));
  }
  candidates.push(path.join(projectPath, 'node_modules', 'miniprogram-ci'));
  candidates.push(path.join(process.cwd(), 'node_modules', 'miniprogram-ci'));
  candidates.push('miniprogram-ci');

  for (const candidate of candidates) {
    try {
      return require(candidate);
    } catch (error) {
      if (error.code !== 'MODULE_NOT_FOUND') {
        throw error;
      }
    }
  }

  fail(
    "Unable to resolve 'miniprogram-ci'. Install it in the target repo or pass --ci-module <path>."
  );
}

function canResolveCiModule(projectPath, explicitPath) {
  const candidates = [];
  if (explicitPath) {
    candidates.push(toAbsolutePath(explicitPath));
  }
  candidates.push(path.join(projectPath, 'node_modules', 'miniprogram-ci'));
  candidates.push(path.join(process.cwd(), 'node_modules', 'miniprogram-ci'));
  candidates.push('miniprogram-ci');

  for (const candidate of candidates) {
    try {
      require.resolve(candidate);
      return candidate;
    } catch (error) {
      if (error.code !== 'MODULE_NOT_FOUND') {
        return `error:${error.message}`;
      }
    }
  }

  return null;
}

function loadExternalConfig(explicitPath) {
  const candidate = explicitPath || process.env.WECHAT_CI_CONFIG || getDefaultConfigPath();
  if (!candidate) {
    return null;
  }

  const resolvedPath = toAbsolutePath(candidate);
  if (!fs.existsSync(resolvedPath)) {
    if (explicitPath || process.env.WECHAT_CI_CONFIG) {
      failWithGuidance(
        `Config file does not exist: ${resolvedPath}`,
        ['Check the value passed to --config or WECHAT_CI_CONFIG.']
      );
    }
    return null;
  }

  const config = readJson(resolvedPath);
  return {
    path: resolvedPath,
    baseDir: path.dirname(resolvedPath),
    data: config,
  };
}

function loadExternalConfigOptional(explicitPath) {
  const candidate = explicitPath || process.env.WECHAT_CI_CONFIG || getDefaultConfigPath();
  if (!candidate) {
    return null;
  }

  const resolvedPath = toAbsolutePath(candidate);
  if (!fs.existsSync(resolvedPath)) {
    return {
      path: resolvedPath,
      baseDir: path.dirname(resolvedPath),
      data: null,
    };
  }

  return loadExternalConfig(explicitPath);
}

function selectProjectConfigEntry(externalConfig, appid, projectPath) {
  if (!externalConfig || !externalConfig.data || !externalConfig.data.projects) {
    return null;
  }

  const projects = externalConfig.data.projects;
  const normalizedProjectPath = path.normalize(projectPath);
  const candidates = [];

  if (appid && projects[appid]) {
    candidates.push({
      source: `config.projects.${appid}`,
      value: projects[appid],
    });
  }

  for (const [key, value] of Object.entries(projects)) {
    if (path.normalize(key) === normalizedProjectPath) {
      candidates.push({
        source: `config.projects.${key}`,
        value,
      });
    }
  }

  if (candidates.length === 0) {
    return null;
  }

  return candidates[0];
}

function pickValue(...candidates) {
  for (const candidate of candidates) {
    if (candidate !== undefined && candidate !== null && candidate !== '') {
      return candidate;
    }
  }
  return null;
}

function resolveInputBundle({ args, externalConfig, projectPath, appid }) {
  const defaults = (externalConfig && externalConfig.data && externalConfig.data.defaults) || {};
  const projectEntry = selectProjectConfigEntry(externalConfig, appid, projectPath);
  const projectValues = projectEntry ? projectEntry.value : {};
  const configBaseDir = externalConfig ? externalConfig.baseDir : process.cwd();

  const privateKeyRaw = pickValue(
    args['private-key'],
    process.env.WECHAT_PRIVATE_KEY_PATH,
    projectValues.privateKeyPath,
    defaults.privateKeyPath
  );

  const ciModuleRaw = pickValue(
    args['ci-module'],
    process.env.WECHAT_CI_MODULE,
    projectValues.ciModule,
    defaults.ciModule
  );

  const robotRaw = pickValue(
    args.robot,
    process.env.WECHAT_CI_ROBOT,
    projectValues.robot,
    defaults.robot,
    '1'
  );

  const version = pickValue(
    args.version,
    process.env.WECHAT_CI_VERSION,
    projectValues.version,
    defaults.version
  );

  const desc = pickValue(
    args.desc,
    process.env.WECHAT_CI_DESC,
    projectValues.desc,
    defaults.desc
  );

  const projectType = pickValue(
    args['project-type'],
    process.env.WECHAT_CI_PROJECT_TYPE,
    projectValues.projectType,
    defaults.projectType
  );

  const threadsRaw = pickValue(
    args.threads,
    process.env.WECHAT_CI_THREADS,
    projectValues.threads,
    defaults.threads
  );

  return {
    configPath: externalConfig ? externalConfig.path : null,
    configSource: projectEntry ? projectEntry.source : null,
    privateKeyPath: privateKeyRaw ? toAbsoluteFromBase(privateKeyRaw, configBaseDir) : null,
    ciModule: ciModuleRaw ? toAbsoluteFromBase(ciModuleRaw, configBaseDir) : null,
    robotRaw,
    version,
    desc,
    projectType,
    threadsRaw,
  };
}

function buildDoctorReport({ projectPath, projectConfigPath, projectConfig, args, resolvedInputs }) {
  const checks = [];
  const nextActions = [];

  const appid = args.appid || projectConfig.appid || null;
  const projectType = inferProjectType(projectConfig, resolvedInputs.projectType);
  const ciCandidate = canResolveCiModule(projectPath, resolvedInputs.ciModule);
  const resolvedPrivateKeyPath = resolvedInputs.privateKeyPath;
  const privateKeyExists = resolvedPrivateKeyPath ? fs.existsSync(resolvedPrivateKeyPath) : false;

  checks.push({
    name: 'project.config.json',
    ok: true,
    detail: projectConfigPath,
  });
  checks.push({
    name: 'appid',
    ok: Boolean(appid),
    detail: appid || 'Missing appid in project.config.json',
  });
  checks.push({
    name: 'project type',
    ok: true,
    detail: projectType,
  });
  checks.push({
    name: 'external config',
    ok: true,
    detail: resolvedInputs.configPath || 'Not provided',
  });
  checks.push({
    name: 'private key',
    ok: privateKeyExists,
    detail: resolvedPrivateKeyPath || 'Not provided',
  });
  checks.push({
    name: 'miniprogram-ci',
    ok: Boolean(ciCandidate && !String(ciCandidate).startsWith('error:')),
    detail: ciCandidate || 'Not installed',
  });

  if (!resolvedPrivateKeyPath) {
    nextActions.push('Run setup to create the default config and key location: node scripts/upload_experience.js --project <repo-path> --setup');
    nextActions.push('Download the WeChat code upload private key and provide it with --private-key, WECHAT_PRIVATE_KEY_PATH, or external config.');
  } else if (!privateKeyExists) {
    nextActions.push(`Fix the private key path. Current value does not exist: ${resolvedPrivateKeyPath}`);
  }

  if (!ciCandidate) {
    nextActions.push('Run setup to install miniprogram-ci automatically: node scripts/upload_experience.js --project <repo-path> --setup');
  } else if (String(ciCandidate).startsWith('error:')) {
    nextActions.push(`Resolve the miniprogram-ci module error: ${ciCandidate.slice(6)}`);
  }

  if (!appid) {
    nextActions.push('Add appid to project.config.json or pass --appid <appid>.');
  }

  if ((projectConfig.cloudfunctionRoot || '').trim()) {
    nextActions.push('If cloud functions changed, deploy them separately. Experience upload does not publish cloud functions.');
  }

  return {
    summary: {
      projectPath,
      appid,
      projectType,
      configPath: resolvedInputs.configPath,
      configSource: resolvedInputs.configSource,
      miniprogramRoot: projectConfig.miniprogramRoot || null,
      cloudfunctionRoot: projectConfig.cloudfunctionRoot || null,
    },
    checks,
    nextActions,
  };
}

function printDoctorReport(report) {
  console.log('[INFO] Doctor summary:');
  console.log(JSON.stringify(report.summary, null, 2));
  console.log('[INFO] Checks:');
  for (const check of report.checks) {
    const status = check.ok ? 'OK' : 'MISSING';
    console.log(`- [${status}] ${check.name}: ${check.detail}`);
  }
  if (report.nextActions.length > 0) {
    console.log('[INFO] Next actions:');
    for (const action of report.nextActions) {
      console.log(`- ${action}`);
    }
  } else {
    console.log('[INFO] All required prerequisites look ready for upload.');
  }
}

function buildSetupConfig({ configPath, existingConfig, appid, keyPath, robot }) {
  const config = existingConfig && existingConfig.data ? existingConfig.data : {};
  const nextConfig = {
    defaults: {
      ...(config.defaults || {}),
    },
    projects: {
      ...(config.projects || {}),
    },
  };

  if (nextConfig.defaults.robot == null) {
    nextConfig.defaults.robot = robot;
  }

  nextConfig.projects[appid] = {
    ...(nextConfig.projects[appid] || {}),
    privateKeyPath: (nextConfig.projects[appid] && nextConfig.projects[appid].privateKeyPath) || keyPath,
    robot: (nextConfig.projects[appid] && nextConfig.projects[appid].robot) || robot,
  };

  return {
    path: configPath,
    data: nextConfig,
  };
}

function ensureRootPackageJson(projectPath, dryRun) {
  const packageJsonPath = path.join(projectPath, 'package.json');
  if (fs.existsSync(packageJsonPath)) {
    return {
      path: packageJsonPath,
      created: false,
      data: readJson(packageJsonPath),
    };
  }

  const packageJson = {
    name: normalizePackageName(path.basename(projectPath)),
    version: '1.0.0',
    private: true,
  };

  if (!dryRun) {
    writeJson(packageJsonPath, packageJson);
  }

  return {
    path: packageJsonPath,
    created: true,
    data: packageJson,
  };
}

function getNpmCommand() {
  return process.platform === 'win32' ? 'npm.cmd' : 'npm';
}

function installMiniprogramCi(projectPath, dryRun) {
  const command = getNpmCommand();
  const args = ['install', '--save-dev', 'miniprogram-ci'];

  if (dryRun) {
    return {
      installed: false,
      skipped: true,
      command: [command, ...args].join(' '),
    };
  }

  const result = childProcess.spawnSync(command, args, {
    cwd: projectPath,
    stdio: 'inherit',
    shell: false,
  });

  if (result.error) {
    failWithGuidance(
      'Failed to launch npm for installing miniprogram-ci.',
      [result.error.message, 'Check that Node.js and npm are installed and available in PATH.']
    );
  }

  if (result.status !== 0) {
    failWithGuidance(
      'npm install for miniprogram-ci failed.',
      ['Check npm registry/network access and rerun setup after fixing the npm error.']
    );
  }

  return {
    installed: true,
    skipped: false,
    command: [command, ...args].join(' '),
  };
}

function runSetup({ projectPath, projectConfig, args, resolvedInputs }) {
  const appid = args.appid || projectConfig.appid;
  if (!appid) {
    failWithGuidance(
      'appid is missing. Cannot generate setup defaults.',
      ['Add appid to project.config.json or rerun with --appid <appid>.']
    );
  }

  const defaultConfigPath = args.config
    ? toAbsolutePath(args.config)
    : (getDefaultConfigPath() || toAbsolutePath('wechat-ci-config.json'));
  const existingConfig = loadExternalConfigOptional(args.config);
  const defaultKeyPath = resolvedInputs.privateKeyPath || getDefaultKeyPath(appid);
  const robot = Number(resolvedInputs.robotRaw || '1');
  if (!Number.isInteger(robot) || robot < 1 || robot > 30) {
    fail(`Robot must be an integer from 1 to 30. Received: ${resolvedInputs.robotRaw}`);
  }

  const nextConfig = buildSetupConfig({
    configPath: existingConfig ? existingConfig.path : defaultConfigPath,
    existingConfig,
    appid,
    keyPath: defaultKeyPath,
    robot,
  });

  const packageJsonState = ensureRootPackageJson(projectPath, args.dryRun);
  const ciCandidate = canResolveCiModule(projectPath, resolvedInputs.ciModule);
  const installState = ciCandidate
    ? { installed: false, skipped: true, command: null }
    : installMiniprogramCi(projectPath, args.dryRun);

  if (!args.dryRun) {
    writeJson(nextConfig.path, nextConfig.data);
    if (defaultKeyPath) {
      ensureDir(path.dirname(defaultKeyPath));
    }
  }

  console.log('[INFO] Setup summary:');
  console.log(
    JSON.stringify(
      {
        projectPath,
        appid,
        configPath: nextConfig.path,
        keyPath: defaultKeyPath,
        packageJsonPath: packageJsonState.path,
        packageJsonCreated: packageJsonState.created,
        ciInstalledNow: Boolean(installState.installed),
        ciAlreadyAvailable: Boolean(ciCandidate),
        dryRun: Boolean(args.dryRun),
      },
      null,
      2
    )
  );

  if (installState.command && (args.dryRun || installState.installed)) {
    console.log(`[INFO] npm command: ${installState.command}`);
  }

  console.log('[INFO] Next actions:');
  console.log(`- Download the WeChat private key and place it at: ${defaultKeyPath}`);
  console.log(`- Review or edit config if needed: ${nextConfig.path}`);
  console.log(`- Run doctor: node scripts/upload_experience.js --project "${projectPath}" --doctor`);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    printUsage();
    return;
  }

  const projectPath = toAbsolutePath(args.project || '.');
  const projectConfigPath = path.join(projectPath, 'project.config.json');
  ensureFileExists(projectConfigPath, 'project.config.json');

  const projectConfig = readJson(projectConfigPath);
  const appid = args.appid || projectConfig.appid;
  const externalConfig = loadExternalConfig(args.config);
  const resolvedInputs = resolveInputBundle({
    args,
    externalConfig,
    projectPath,
    appid,
  });

  if (args.setup) {
    runSetup({
      projectPath,
      projectConfig,
      args,
      resolvedInputs,
    });
    return;
  }

  if (args.doctor) {
    const report = buildDoctorReport({
      projectPath,
      projectConfigPath,
      projectConfig,
      args,
      resolvedInputs,
    });
    printDoctorReport(report);
    return;
  }

  if (!appid) {
    failWithGuidance(
      'appid is missing. Provide --appid or ensure project.config.json contains appid.',
      ['Run with --doctor to inspect the repository before uploading.']
    );
  }

  const privateKeyPath = resolvedInputs.privateKeyPath;
  if (!privateKeyPath) {
    failWithGuidance(
      'Missing private key path.',
      [
        'Download the WeChat code upload private key from the WeChat admin console.',
        'Rerun with --private-key <path>, set WECHAT_PRIVATE_KEY_PATH, or store the path in external config.',
        'If you only want a checklist, run with --doctor.',
      ]
    );
  }
  if (!fs.existsSync(privateKeyPath)) {
    failWithGuidance(
      `Private key file does not exist: ${privateKeyPath}`,
      ['Check the absolute path of the .key file.', 'Run with --doctor to print the current prerequisite status.']
    );
  }

  const robotRaw = resolvedInputs.robotRaw;
  const robot = Number(robotRaw);
  if (!Number.isInteger(robot) || robot < 1 || robot > 30) {
    fail(`Robot must be an integer from 1 to 30. Received: ${robotRaw}`);
  }

  const version = resolvedInputs.version || makeTimestampVersion();
  const desc = resolvedInputs.desc || `Codex upload ${version}`;
  const projectType = inferProjectType(projectConfig, resolvedInputs.projectType);
  const setting = deriveSetting(projectConfig);
  const threads = resolvedInputs.threadsRaw == null ? undefined : Number(resolvedInputs.threadsRaw);
  if (resolvedInputs.threadsRaw != null && (!Number.isInteger(threads) || threads < 1)) {
    fail(`Threads must be a positive integer. Received: ${resolvedInputs.threadsRaw}`);
  }

  const plan = {
    projectPath,
    projectConfigPath,
    appid,
    projectType,
    configPath: resolvedInputs.configPath,
    configSource: resolvedInputs.configSource,
    privateKeyPath: privateKeyPath,
    robot,
    version,
    desc,
    threads: threads || null,
    setting,
    cloudfunctionRoot: projectConfig.cloudfunctionRoot || null,
    miniprogramRoot: projectConfig.miniprogramRoot || null,
  };

  console.log('[INFO] Resolved upload plan:');
  console.log(JSON.stringify(plan, null, 2));

  if (args.dryRun) {
    console.log('[INFO] Dry run only. Skipping miniprogram-ci upload.');
    return;
  }

  const ciCandidate = canResolveCiModule(projectPath, resolvedInputs.ciModule);
  if (!ciCandidate) {
    failWithGuidance(
      "Unable to resolve 'miniprogram-ci'.",
      [
        'Install it in the target repo: npm install --save-dev miniprogram-ci',
        'Or rerun with --ci-module <path>, set WECHAT_CI_MODULE, or store ciModule in external config.',
        'Run with --doctor to confirm what is still missing before uploading.',
      ]
    );
  }
  if (String(ciCandidate).startsWith('error:')) {
    failWithGuidance(
      "miniprogram-ci exists but could not be loaded cleanly.",
      [ciCandidate.slice(6), 'Fix the module installation, then rerun the upload.']
    );
  }

  const ci = resolveCiModule(projectPath, resolvedInputs.ciModule);

  const project = new ci.Project({
    appid,
    type: projectType,
    projectPath,
    privateKeyPath: privateKeyPath,
  });

  const uploadOptions = {
    project,
    version,
    desc,
    robot,
    onProgressUpdate: (status) => {
      console.log('[PROGRESS]', JSON.stringify(status));
    },
  };

  if (Object.keys(setting).length > 0) {
    uploadOptions.setting = setting;
  }
  if (threads) {
    uploadOptions.threads = threads;
  }

  const result = await ci.upload(uploadOptions);
  console.log('[INFO] Upload completed.');
  console.log(JSON.stringify(result, null, 2));
}

main().catch((error) => fail('Upload failed.', error));
