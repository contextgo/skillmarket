# WeChat Experience Upload Prerequisites

Start with:

```powershell
node scripts/upload_experience.js --project <repo-path> --setup
```

Then verify with:

```powershell
node scripts/upload_experience.js --project <repo-path> --doctor
```

Use setup mode to create the default local config, prepare the default key path, create a root `package.json` if needed, and install `miniprogram-ci`.
Use doctor mode to print the current blockers and next actions without attempting an upload.

## Recommended Key Handling Policy

- Store the `.key` file outside the repository.
- Never paste private key contents into chat, scripts, or committed config.
- Pass only a file path through one of these channels:
  - `--private-key <path>`
  - `WECHAT_PRIVATE_KEY_PATH`
  - External config JSON outside the repo

Input precedence:

1. CLI arguments
2. Environment variables
3. External config JSON
4. Script defaults

## End-User Quick Start

For users who install this skill from a shared catalog:

1. Download the code upload private key for their own app from 微信公众平台.
2. Save the file to:

```text
%USERPROFILE%\.codex\wechat-ci\keys\<appid>.key
```

3. Create this config file:

```text
%USERPROFILE%\.codex\wechat-ci\config.json
```

Example:

```json
{
  "defaults": {
    "robot": 1
  },
  "projects": {
    "wxc4b455b5f53c9309": {
      "privateKeyPath": "C:\\Users\\admin\\.codex\\wechat-ci\\keys\\wxc4b455b5f53c9309.key",
      "robot": 1
    }
  }
}
```

4. Install `miniprogram-ci` in the target repository:

```powershell
node scripts/upload_experience.js --project <repo-path> --setup
```

5. Run doctor mode before the first upload:

```powershell
node scripts/upload_experience.js --project <repo-path> --doctor
```

## Operator Actions

1. Log in to 微信公众平台 with an account allowed to upload code for the target app.
2. Open the page for downloading the code upload private key and save the `.key` file locally.
3. If IP whitelisting is enabled for uploads, add the current public IP or relax the restriction according to your policy.
4. Ensure `miniprogram-ci` is installed where the helper can resolve it.

Recommended local install in the target repo:

```powershell
npm install --save-dev miniprogram-ci
```

## External Config File

Optional default path:

```text
%USERPROFILE%\.codex\wechat-ci\config.json
```

You can also override it with:

```powershell
node scripts/upload_experience.js --project <repo-path> --config <config-path> --doctor
```

Recommended schema:

```json
{
  "defaults": {
    "robot": 1
  },
  "projects": {
    "wxc4b455b5f53c9309": {
      "privateKeyPath": "C:\\Users\\admin\\.codex\\wechat-ci\\keys\\wxc4b455b5f53c9309.key",
      "robot": 1
    }
  }
}
```

Allowed values for each project entry:

- `privateKeyPath`
- `robot`
- `version`
- `desc`
- `projectType`
- `threads`
- `ciModule`

Do not store private key contents in this JSON. Store only a file path.

## Required Inputs

- Repository path that contains `project.config.json`
- Private key file path

## Common Optional Inputs

- Robot number: use the correct CI robot slot for the project
- Version string: keep a stable versioning convention, for example `2026.03.11-1`
- Description: short upload reason or environment note

## Notes For Repositories With Cloud Functions

If the repository contains a `cloudfunction/` directory, code upload to the experience version does not automatically guarantee cloud function deployment. If cloud functions changed, deploy them separately or extend the automation.

## Failure Patterns

- `Cannot find module 'miniprogram-ci'`
  - Install `miniprogram-ci` in the target repository or make it available from the current working directory.
- `private key path does not exist`
  - Check the absolute Windows path and file extension.
- `appid mismatch`
  - Confirm the private key belongs to the same miniapp as `project.config.json`.
- Upload rejected by IP whitelist
  - Add the current public IP in 微信公众平台 or disable the whitelist if policy allows.
- Permission error from WeChat platform
  - Verify the operator account has upload permission for the selected robot slot.
