---
name: wechat-miniapp-upload-experience
description: Automate uploads of WeChat Mini Program or Mini Game projects to the WeChat experience version by validating `project.config.json`, collecting required upload inputs, and running bundled `miniprogram-ci` helpers. Use when Codex needs to submit current code to 微信小程序/微信小游戏体验版, prepare a repeatable CI upload command, verify appid/private key/robot/version parameters, or troubleshoot experience-build upload failures on Windows.
---

# Wechat Miniapp Upload Experience

## Overview

Use this skill to inspect a WeChat Mini Program or Mini Game repository, verify upload prerequisites, and submit an experience build with the bundled Node.js helper. Prefer the helper script over handwritten commands so parameter validation and project-type detection stay consistent.

## Workflow

1. Inspect the target repository.
Read `project.config.json` first. Capture `appid`, `compileType`, `miniprogramRoot`, and `cloudfunctionRoot`.

2. Bootstrap the machine and repository first.
If the user has not confirmed the upload private key or `miniprogram-ci`, start with:

```powershell
node scripts/upload_experience.js --project <repo-path> --setup
```

Setup mode creates the default local config, prepares the default key path, creates a root `package.json` if the repo does not have one, and installs `miniprogram-ci`.

3. Check operator prerequisites.
Run:

```powershell
node scripts/upload_experience.js --project <repo-path> --doctor
```

Use the doctor output to tell the user exactly what is missing. Read `references/prerequisites.md` when you need the exact operator steps or troubleshooting notes.

4. Dry-run before a real upload when the prerequisites exist but the upload parameters are still uncertain.
Run:

```powershell
node scripts/upload_experience.js --project <repo-path> --private-key <private-key-path> --dry-run
```

Use `--dry-run` to validate paths, infer `miniProgram` vs `miniGame`, and show the resolved upload plan without calling WeChat CI.

5. Run the real upload only after doctor checks pass.
Use the same helper with explicit metadata:

```powershell
node scripts/upload_experience.js `
  --project <repo-path> `
  --private-key <private-key-path> `
  --robot 1 `
  --version 2026.03.11-1 `
  --desc "Codex experience upload"
```

6. Report the result clearly.
On success, return the resolved project type, appid, version, robot number, and the upload result summary. On failure, separate configuration errors from operator-only actions such as missing upload key, IP whitelist restrictions, or absent `miniprogram-ci`.

## Operator Inputs

- Required:
  - Target repository path
- Required for actual upload:
  - Upload private key file path
- Usually required:
  - Robot number
  - Version string
  - Upload description
- Optional:
  - Explicit appid override
  - Explicit project type override
  - Thread count override

If the user did not specify `version`, generate a timestamp-based version string. If the user did not specify `desc`, generate a short description that includes the version.

## Configuration Precedence

Resolve upload inputs in this order:

1. CLI arguments such as `--private-key` and `--robot`
2. Environment variables such as `WECHAT_PRIVATE_KEY_PATH`
3. External config JSON outside the repository
4. Built-in defaults such as robot `1` or generated version strings

Prefer CLI and environment variables for public examples. Use external config only for local operator convenience.

## End-User Setup

Share this skill with the following onboarding steps:

1. Download a personal upload private key from 微信公众平台.
   Each user must use their own `.key` file for the target app. Do not redistribute a private key with the skill.

2. Store the private key outside the repository.
   Recommended location on Windows:

```text
%USERPROFILE%\.codex\wechat-ci\keys\<appid>.key
```

3. Configure one of these input methods:
   - Recommended for repeat use: create `%USERPROFILE%\.codex\wechat-ci\config.json`
   - Good for one-off use: pass `--private-key <path>`
   - Good for shell-based automation: set `WECHAT_PRIVATE_KEY_PATH`

First command after setup:

```powershell
node scripts/upload_experience.js --project <repo-path> --doctor
```

Use doctor mode to confirm the key path and `miniprogram-ci` installation before any upload attempt.

## Guardrails

- Never ask the user to paste the private key contents into chat. Ask only for a file path.
- When the private key or `miniprogram-ci` is missing, stop at doctor mode and tell the user what to prepare.
- Keep private keys and config files outside the repository. Do not commit `.key` files or machine-local config to source control.
- Prefer a local `miniprogram-ci` installation in the target repository. If it is missing, ask the user to install it or install it yourself only when permitted.
- Treat `compileType: "game"` as a Mini Game upload unless the user explicitly overrides the project type.
- If the repository has a `cloudfunction/` directory, warn that code upload and cloud function deployment are separate operations unless the user already automated both.
- Do not edit project config files just to make upload succeed unless the user explicitly asks for config changes.

## Bundled Resources

- `scripts/upload_experience.js`
  - Run doctor checks
  - Validate inputs
  - Read `project.config.json`
  - Infer `miniProgram` or `miniGame`
  - Load optional external config from `--config`, `WECHAT_CI_CONFIG`, or `%USERPROFILE%\.codex\wechat-ci\config.json`
  - Resolve `miniprogram-ci`
  - Run `ci.upload(...)`
- `references/prerequisites.md`
  - Manual operator steps in 微信公众平台
  - Dependency expectations
  - Windows command examples
  - Common failure modes
  - External config schema

## Example Triggers

- "帮我把这个微信小程序自动上传到体验版"
- "给当前小游戏提一个体验版，机器人 2，版本号 1.3.7"
- "检查一下这个仓库为什么没法用 CI 上传体验版"
- "生成一个可复用的微信小程序体验版上传命令"
