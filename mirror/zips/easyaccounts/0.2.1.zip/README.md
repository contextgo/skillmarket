# EasyAccounts Skill for OpenClaw

让你的 OpenClaw AI 助手成为家庭财务管家 — 通过自然语言记账、查账、统计和导出报表。

> 对接 [EasyAccounts](https://github.com/QingHeYang/EasyAccounts) 个人记账系统。

---

## 它能做什么

- **🦞 记一笔流水** — "记一下午餐 30 块"
- **🦞 批量记账** — "今天的:午餐 30、地铁 12、咖啡 25"
- **🦞 查询流水** — "查上个月的餐饮支出"、"今年最大的 5 笔开销"
- **🦞 修改流水** — "把刚才那笔午餐改成 35"
- **🦞 内部转账** — "从微信转 500 到银行卡"
- **🦞 年度统计** — "今年总收入多少"、"现在总资产多少"
- **🦞 导出 Excel** — "把 3 月的账单导出"
- **🦞 系统信息** — "有什么新公告"、"我用的什么版本"

所有由本 skill 创建的流水会标记 `from=Claw` 和备注末尾追加 `#Claw记账`,方便你区分哪些是 OpenClaw 帮你记的。

---

# 🚀 在 OpenClaw 里 5 步上手

打开你的 OpenClaw 对话窗口,**全程对话即可**,不需要写代码或编辑文件。

## 第一步:让 OpenClaw 安装这个 skill

> **你**:帮我从 ClawHub 上搜索一下 easyaccounts,然后安装这个 skill
>
> **AI**:好的,正在搜索...找到了 `easyaccounts`(by qingheyang),正在安装...安装完成 ✅

OpenClaw 会自动调用 `clawhub install easyaccounts` 把 skill 装到本地。

## 第二步:告诉 OpenClaw 你的 EasyAccounts 服务地址和登录信息

> **你**:配置一下 easyaccounts skill,我的服务地址是 `http://192.168.30.201:10669`,用户名 `admin`,密码 `mypassword`
>
> **AI**:收到。我来把这些信息写入配置文件 `~/.openclaw/.env`...
> - `EASYACCOUNTS_URL` = `http://192.168.30.201:10669`
> - `EASYACCOUNTS_USERNAME` = `admin`
> - `EASYACCOUNTS_PASSWORD` = `********`
> 配置完成 ✅

**地址格式说明**(给 LLM 看的,你不用管):
- ✅ 直接复制浏览器地址栏的 URL,如 `http://192.168.30.201:10669`
- ❌ 不要带末尾斜杠 `/`
- ❌ 不要加任何路径(`/api`、`/web` 等都不要加)
- 这就是浏览器访问 EasyAccounts 时地址栏看到的样子

> 💡 如果你的 EasyAccounts 服务端**没有开启登录**(`ENABLE_LOGIN=false`),则用户名密码可以省略,只设地址即可。

## 第三步:让 OpenClaw 检查能否连通(验证基础信息)

> **你**:看一下 easyaccounts 的系统状态和我有哪些账户
>
> **AI**:
> - 系统版本:**v2.6.1**(已是最新)
> - 数据库备份:已配置(每天 22:00)
> - 你共有 **7 个账户**:微信、理财、基金、公积金、现金、支付宝、万能账户
> - 当前总资产:**¥665,840.95**

如果到这里看到了你的真实账户列表 → ✅ 配置成功,可以开始用了。
如果看到 `认证失败` 或 `URL 格式不正确` → 检查第二步的地址或密码。

## 第四步:开始记账

随便说人话即可:

> **你**:今天午餐花了 35,记一下
>
> **AI**:好的,记一笔现金支出。需要确认一下分类用"餐饮"还是"我的支出/吃吃喝喝"?
>
> **你**:吃吃喝喝
>
> **AI**:已记录,流水 ID **#4828**:`现金 -35.00`,分类:`家庭支出/吃吃喝喝`,日期:2026-04-07,备注:`午餐 #Claw记账` ✅

## 第五步:更高级的玩法

```
"今天的:午餐 30、地铁 12、咖啡 25"            → 批量记 3 笔
"把刚才那笔午餐改成 38"                       → 修改流水
"从微信转 500 到现金"                         → 内部转账
"查上个月的餐饮支出"                          → 查流水 + 统计
"今年总支出多少"                              → 年度统计
"导出 3 月的账单"                             → Excel 报表
"有什么新公告"                                → 项目通知
```

---

## 💡 进阶玩法:与 Excel skill 组合使用(强烈推荐)

如果你**同时安装**任意一个 Excel 处理类 skill(在 ClawHub 搜 `excel`、`xlsx`、`spreadsheet`),就能解锁一个**爆炸性玩法** —— **微信账单/支付宝账单批量导入**。

### 操作流程

1. **微信/支付宝导出账单**
   - 微信:`服务` → `钱包` → `账单` → `常见问题` → `下载账单` → 选月份 → 导出到邮箱
   - 支付宝:`我的` → `账单` → 右上角 `…` → `开具交易流水证明` → 导出 Excel

2. **把 Excel 文件交给 OpenClaw**

   > **你**:这是我 3 月份的微信账单 Excel,帮我导入到 EasyAccounts 里
   >
   > **AI**:好的,我先用 excel skill 读取文件...一共 87 笔交易(支出 62 笔、收入 8 笔、转账 17 笔)。我帮你按你的分类规则分类后批量导入,要先确认一下分类映射吗?
   >
   > **你**:嗯
   >
   > **AI**:[列出每笔交易和建议的分类、账户]
   >
   > **你**:可以
   >
   > **AI**:正在调用 batch_add_flow 批量导入...87/87 全部成功 ✅,本月共记录 ¥4,532.10 支出、¥12,800.00 收入。

### 为什么这个组合这么好用?

- **excel skill** 负责:读取表格、解析交易明细、识别金额/日期/对方名称
- **easyaccounts skill** 负责:查询你的账户和分类列表、智能匹配、批量写入
- **OpenClaw** 在中间负责:分类决策、确认流程、错误恢复

整个过程**全程对话**,你只需要确认 LLM 的分类建议。比手工录入快 50 倍以上,而且不会漏单。

> 💡 类似地,银行流水(招商/建行/工行 Excel 导出)、信用卡账单都能用同样的方法批量导入。

---

## 不支持的操作

出于**安全考虑**,本 skill **不提供以下功能**:

- ❌ **删除流水**(高风险不可逆操作)— 需要到 EasyAccounts 前端手动删除,前端会自动恢复账户余额
- ❌ **创建/删除账户、分类、动作** — 主数据维护请用前端

---

## 配套前端识别(可选)

本 skill 写入的流水带 `from=Claw` 标记。**升级前端**后,流水列表会显示一个**粉色 `Claw` 标签**🦞,一眼就能区分哪些流水是 OpenClaw 帮你记的;不升级则只能在备注末尾看到 `#Claw记账` 文字。

### 升级前端镜像

到你部署 EasyAccounts 的服务器上执行(只升级前端容器,不影响数据库和后端):

```bash
# 1. 拉取最新前端镜像(包含粉色 Claw 标签支持)
docker pull 775495797/easyaccounts-nginx:latest

# 2. 重建前端容器
cd /your/path/to/EasyAccounts   # 你的 docker-compose.yml 所在目录
docker-compose up -d --force-recreate nginx
```

升级完刷新浏览器即可看到效果。

> 💡 这一步是**纯展示增强**,即使不升级,记账/查账等所有功能都能正常工作,只是少了视觉标识。

---

## 常见问题

**Q:为什么需要 `~/.openclaw/.env` 配置?能不能在对话里临时输入?**

A:可以。第一次对话时告诉 OpenClaw 你的地址和密码,它会自动写入 env 文件,之后所有对话都不再需要你输入。如果你换了密码,直接告诉 OpenClaw"重新配置 easyaccounts 的密码为 xxx"即可。

**Q:token 多久过期?会不会经常要重新登录?**

A:服务端默认 30 分钟。如果你在配置里写了用户名密码,token 过期后 skill 会**自动续期**,你完全无感。

**Q:支持哪些操作系统?**

A:macOS、Linux、Windows(通过 WSL2)— 任何能跑 OpenClaw 的环境都支持。需要 `curl` 和 `jq`(macOS/Linux 一般自带 curl,jq 可通过 `brew install jq` 或 `apt install jq` 安装)。

**Q:数据安全吗?**

A:本 skill 是纯本地脚本,所有 HTTP 请求**只发到你自己配置的 EasyAccounts 服务器**,不经过任何第三方。代码全开源可审计。

---

## 项目地址

- **本 Skill**:[GitHub](https://github.com/QingHeYang/EasyAccounts/tree/main/skills/easyaccounts)
- **ClawHub 主页**:[clawhub.ai/skills/qingheyang/easyaccounts](https://clawhub.ai)
- **EasyAccounts 主项目**:[GitHub](https://github.com/QingHeYang/EasyAccounts)
- **问题反馈**:[Issues](https://github.com/QingHeYang/EasyAccounts/issues)

## License

MIT-0(MIT No Attribution),允许任何使用包括商用,无附加条款。
