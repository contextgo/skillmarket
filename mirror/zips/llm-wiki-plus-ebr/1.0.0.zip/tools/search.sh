﻿#!/bin/bash
# wiki+ 统一搜索入口
# 检索优先级：① 本地向量语义检索（vec-search.mjs）→ ② 关键词全文搜索（search.js）
# 用法：bash tools/search.sh "查询词" [topK]

QUERY="$1"
TOP_K="${2:-5}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
WIKI_DIR="$(cd "${SCRIPT_DIR}/../../../.." && pwd)/wiki"
VEC_INDEX="${WIKI_DIR}/.wiki-vec/config.json"
VEC_SEARCH="${SCRIPT_DIR}/vec-search.mjs"

if [ -z "$QUERY" ]; then
    echo "错误：请提供搜索关键词。"
    echo "用法：bash tools/search.sh \"你的查询\" [topK]"
    exit 1
fi

# ── 优先级 1：本地向量语义检索 ────────────────────────────
if command -v node &>/dev/null && [ -f "${VEC_INDEX}" ] && [ -f "${VEC_SEARCH}" ]; then
    node "${VEC_SEARCH}" "$QUERY" "$TOP_K"
    exit 0
fi

# ── 优先级 2：提示建立向量索引 ────────────────────────────
if command -v node &>/dev/null && [ -f "${VEC_SEARCH}" ] && [ ! -f "${VEC_INDEX}" ]; then
    echo "⚠️  [降级] 向量索引尚未建立，使用关键词全文搜索。"
    echo "   建议运行以下命令建立向量索引（首次约需下载 80MB 模型）："
    echo "   cd .cursor/skills/wiki+/tools && npm install && node vec-index.mjs"
fi

# ── 优先级 3：关键词全文搜索（兜底） ──────────────────────
node "${SCRIPT_DIR}/search.js" "$QUERY"