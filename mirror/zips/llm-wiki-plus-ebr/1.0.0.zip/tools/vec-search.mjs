/**
 * wiki+ 向量语义检索
 * 将查询嵌入为向量，与索引中所有文本块计算余弦相似度，返回 Top-K 结果
 *
 * 用法：
 *   node vec-search.mjs "查询词"        # 返回 Top-5（默认）
 *   node vec-search.mjs "查询词" 8      # 返回 Top-8
 *   node vec-search.mjs "查询词" 5 0.3  # 相似度阈值 0.3 以上才返回
 */

import { pipeline } from '@huggingface/transformers';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// ── 路径配置 ──────────────────────────────────────────────
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WIKI_DIR  = path.resolve(__dirname, '../../../../wiki');
const INDEX_DIR = path.join(WIKI_DIR, '.wiki-vec');
const VEC_FILE  = path.join(INDEX_DIR, 'vectors.bin');
const META_FILE = path.join(INDEX_DIR, 'meta.json');
const CFG_FILE  = path.join(INDEX_DIR, 'config.json');

// ── 参数解析 ──────────────────────────────────────────────
const query     = process.argv[2];
const topK      = parseInt(process.argv[3] ?? '5', 10);
const threshold = parseFloat(process.argv[4] ?? '0.0');

if (!query) {
  console.error('用法：node vec-search.mjs "查询词" [topK] [相似度阈值]');
  process.exit(1);
}

// ── 工具函数 ──────────────────────────────────────────────

/** 检查索引是否存在且有效 */
function checkIndex() {
  if (!fs.existsSync(CFG_FILE) || !fs.existsSync(VEC_FILE) || !fs.existsSync(META_FILE)) {
    console.error('⚠️  向量索引不存在，请先运行：');
    console.error('   cd .cursor/skills/wiki+/tools && npm install && node vec-index.mjs');
    process.exit(1);
  }
}

/** 加载索引（meta + 向量矩阵） */
function loadIndex() {
  const cfg  = JSON.parse(fs.readFileSync(CFG_FILE, 'utf-8'));
  const meta = JSON.parse(fs.readFileSync(META_FILE, 'utf-8'));
  const buf  = fs.readFileSync(VEC_FILE);
  const vecs = new Float32Array(buf.buffer, buf.byteOffset, buf.byteLength / 4);
  return { cfg, meta, vecs };
}

/** 计算查询向量与索引中所有向量的余弦相似度 */
function rankChunks(queryVec, vecs, meta, dim) {
  const scores = [];
  for (let i = 0; i < meta.length; i++) {
    let dot = 0;
    const offset = i * dim;
    for (let j = 0; j < dim; j++) dot += queryVec[j] * vecs[offset + j];
    scores.push({ idx: i, score: dot });
  }
  scores.sort((a, b) => b.score - a.score);
  return scores;
}

/** 从排序结果中取 Top-K，按文件去重（每个文件只保留最高分块） */
function deduplicateByFile(scores, meta, topK, threshold) {
  const seen    = new Map(); // file -> best score
  const results = [];

  for (const { idx, score } of scores) {
    if (score < threshold) break;
    const chunk = meta[idx];
    if (!seen.has(chunk.file) || seen.get(chunk.file).score < score) {
      seen.set(chunk.file, { chunk, score });
    }
    if (seen.size >= topK * 2) break; // 采集足够候选后提前终止
  }

  return [...seen.values()]
    .sort((a, b) => b.score - a.score)
    .slice(0, topK);
}

/** 格式化输出，供 LLM / 终端阅读 */
function formatResults(results, query) {
  if (results.length === 0) {
    console.log(`在向量索引中未找到与「${query}」相关的内容。`);
    return;
  }

  console.log(`# 向量检索结果：「${query}」（Top-${results.length}）\n`);
  for (const { chunk, score } of results) {
    console.log(`## ${chunk.file}  _(相似度: ${score.toFixed(4)})_\n`);
    // 输出该文件的完整内容（供 LLM 读取），最多 1200 字
    const fullPath = path.join(WIKI_DIR, chunk.file);
    if (fs.existsSync(fullPath)) {
      const fullContent = fs.readFileSync(fullPath, 'utf-8').slice(0, 1200);
      console.log('```markdown');
      console.log(fullContent);
      if (fullContent.length === 1200) console.log('... [内容已截断]');
      console.log('```\n');
    } else {
      console.log('```');
      console.log(chunk.text);
      console.log('```\n');
    }
  }
}

// ── 主流程 ──────────────────────────────────────────────

async function main() {
  checkIndex();

  const { cfg, meta, vecs } = loadIndex();

  // 静默加载模型（搜索时不打印进度）
  const embedder = await pipeline('feature-extraction', cfg.model, {
    progress_callback: () => {},
  });

  // 嵌入查询
  const output   = await embedder([query], { pooling: 'mean', normalize: true });
  const queryVec = Array.from(output.data);

  // 排序 + 去重
  const ranked  = rankChunks(queryVec, vecs, meta, cfg.dim);
  const results = deduplicateByFile(ranked, meta, topK, threshold);

  formatResults(results, query);
}

main().catch(err => { console.error('❌ 检索失败:', err.message); process.exit(1); });
