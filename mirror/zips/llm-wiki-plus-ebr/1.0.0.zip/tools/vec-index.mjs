/**
 * wiki+ 向量索引构建器
 * 扫描 wiki/ 下所有 .md 文件，生成本地嵌入向量，保存至 wiki/.wiki-vec/
 *
 * 用法：
 *   node vec-index.mjs          # 全量重建
 *   node vec-index.mjs --update # 仅索引新增/修改的文件
 */

import { pipeline } from '@huggingface/transformers';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// ── 路径配置 ──────────────────────────────────────────────
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WIKI_DIR   = path.resolve(__dirname, '../../../../wiki');
const INDEX_DIR  = path.join(WIKI_DIR, '.wiki-vec');
const VEC_FILE   = path.join(INDEX_DIR, 'vectors.bin');
const META_FILE  = path.join(INDEX_DIR, 'meta.json');
const CFG_FILE   = path.join(INDEX_DIR, 'config.json');

const MODEL_ID   = 'Xenova/all-MiniLM-L6-v2';  // 80MB，专为句子相似度训练
const CHUNK_SIZE = 800;   // 每个文本块的最大字符数
const UPDATE_MODE = process.argv.includes('--update');

// ── 工具函数 ──────────────────────────────────────────────

/** 递归收集 wiki/ 下所有 .md 文件（跳过隐藏目录） */
function collectMarkdownFiles(dir, files = []) {
  if (!fs.existsSync(dir)) return files;
  for (const name of fs.readdirSync(dir)) {
    if (name.startsWith('.')) continue;
    const fullPath = path.join(dir, name);
    if (fs.statSync(fullPath).isDirectory()) {
      collectMarkdownFiles(fullPath, files);
    } else if (name.endsWith('.md')) {
      files.push(fullPath);
    }
  }
  return files;
}

/**
 * 将单个 .md 文件按 Markdown 标题切分为语义块
 * 每块保留标题上下文，限制字符数防止超出模型最大 token
 */
function chunkFile(filePath) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const relPath  = path.relative(WIKI_DIR, filePath).replace(/\\/g, '/');
  const mtime    = fs.statSync(filePath).mtimeMs;

  // 按 Markdown 一/二级标题切分
  const rawSections = content.split(/\n(?=#{1,2} )/);

  return rawSections
    .map(s => s.trim())
    .filter(s => s.length > 10)
    .flatMap((section, i) => {
      // 超长 section 再按段落二次切割
      if (section.length <= CHUNK_SIZE) {
        return [{ id: `${relPath}#${i}`, file: relPath, mtime, text: section }];
      }
      const paragraphs = section.split(/\n{2,}/);
      return paragraphs
        .filter(p => p.trim().length > 10)
        .map((p, j) => ({
          id: `${relPath}#${i}_${j}`,
          file: relPath,
          mtime,
          text: p.slice(0, CHUNK_SIZE),
        }));
    });
}

/** 余弦相似度（向量已归一化，等价于点积） */
function cosine(a, b) {
  let dot = 0;
  for (let i = 0; i < a.length; i++) dot += a[i] * b[i];
  return dot;
}

// ── 主流程 ──────────────────────────────────────────────

async function main() {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('  wiki+ 向量索引构建');
  console.log(`  模式: ${UPDATE_MODE ? '增量更新' : '全量重建'}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  // 加载嵌入模型
  console.log(`\n📦 加载模型 ${MODEL_ID}`);
  console.log('   首次运行将从 HuggingFace 下载约 80MB，请保持网络畅通...\n');

  const embedder = await pipeline('feature-extraction', MODEL_ID, {
    progress_callback: ({ status, name, progress }) => {
      if (status === 'downloading' && name && progress != null) {
        const bar = '█'.repeat(Math.floor(progress / 5)).padEnd(20, '░');
        process.stdout.write(`\r   ${bar} ${Math.round(progress)}%  ${name.split('/').pop()}`);
      }
    },
  });
  console.log('\n✅ 模型加载完成\n');

  // 收集文件并切块
  const files  = collectMarkdownFiles(WIKI_DIR);
  console.log(`📚 发现 ${files.length} 个 Markdown 文件`);

  // 增量更新：读取现有元数据，只处理新增/修改的文件
  let existingMeta = [];
  let existingVecs = null;
  let existingDim  = 0;

  if (UPDATE_MODE && fs.existsSync(META_FILE) && fs.existsSync(VEC_FILE)) {
    existingMeta = JSON.parse(fs.readFileSync(META_FILE, 'utf-8'));
    const cfg    = JSON.parse(fs.readFileSync(CFG_FILE, 'utf-8'));
    existingDim  = cfg.dim;
    existingVecs = new Float32Array(fs.readFileSync(VEC_FILE).buffer);

    const existingMtimes = new Map(existingMeta.map(c => [c.file, c.mtime]));
    const newFiles = files.filter(f => {
      const rel   = path.relative(WIKI_DIR, f).replace(/\\/g, '/');
      const mtime = fs.statSync(f).mtimeMs;
      return existingMtimes.get(rel) !== mtime;
    });

    console.log(`🔄 增量更新：${newFiles.length} 个文件有变更`);
    if (newFiles.length === 0) {
      console.log('✅ 索引已是最新，无需更新');
      return;
    }

    // 移除已变更文件的旧块
    const changedFiles = new Set(newFiles.map(f => path.relative(WIKI_DIR, f).replace(/\\/g, '/')));
    const keptIndices  = existingMeta
      .map((c, i) => ({ c, i }))
      .filter(({ c }) => !changedFiles.has(c.file));

    const keptMeta = keptIndices.map(({ c }) => c);
    const keptVecs = new Float32Array(keptIndices.length * existingDim);
    keptIndices.forEach(({ i }, newI) => {
      keptVecs.set(existingVecs.slice(i * existingDim, (i + 1) * existingDim), newI * existingDim);
    });

    existingMeta = keptMeta;
    existingVecs = keptVecs;

    // 只对变更文件重新切块
    const newChunks = newFiles.flatMap(chunkFile);
    await embedAndSave(embedder, newChunks, existingMeta, existingVecs, existingDim);
  } else {
    // 全量重建
    const chunks = files.flatMap(chunkFile);
    console.log(`✂️  切分为 ${chunks.length} 个文本块\n`);
    await embedAndSave(embedder, chunks, [], null, 0);
  }
}

async function embedAndSave(embedder, newChunks, existingMeta, existingVecs, existingDim) {
  if (newChunks.length === 0) {
    console.log('⚠️  没有需要嵌入的文本块');
    return;
  }

  console.log(`⚡ 嵌入 ${newChunks.length} 个文本块...`);

  // 批量嵌入（每批 32 块，防止内存溢出）
  const BATCH = 32;
  const allNewVecs = [];

  for (let i = 0; i < newChunks.length; i += BATCH) {
    const batch  = newChunks.slice(i, i + BATCH);
    const output = await embedder(batch.map(c => c.text), { pooling: 'mean', normalize: true });
    const dim    = output.dims[1];

    for (let j = 0; j < batch.length; j++) {
      allNewVecs.push(Array.from(output.data.slice(j * dim, (j + 1) * dim)));
    }

    const pct = Math.round(((i + batch.length) / newChunks.length) * 100);
    process.stdout.write(`\r   进度: ${'█'.repeat(Math.floor(pct / 5)).padEnd(20, '░')} ${pct}%`);
  }
  console.log();

  const dim       = allNewVecs[0].length;
  const allMeta   = [...existingMeta, ...newChunks];
  const totalCnt  = allMeta.length;

  // 合并向量
  const flat = new Float32Array(totalCnt * dim);
  if (existingVecs && existingDim === dim) {
    flat.set(existingVecs.slice(0, existingMeta.length * dim));
  }
  allNewVecs.forEach((vec, i) => {
    flat.set(vec, (existingMeta.length + i) * dim);
  });

  // 写入磁盘
  fs.mkdirSync(INDEX_DIR, { recursive: true });
  fs.writeFileSync(VEC_FILE,  Buffer.from(flat.buffer));
  fs.writeFileSync(META_FILE, JSON.stringify(allMeta, null, 2));
  fs.writeFileSync(CFG_FILE,  JSON.stringify({ dim, count: totalCnt, model: MODEL_ID, builtAt: new Date().toISOString() }));

  console.log(`\n✅ 向量索引完成`);
  console.log(`   位置: wiki/.wiki-vec/`);
  console.log(`   文本块: ${totalCnt} 个 | 维度: ${dim} | 模型: ${MODEL_ID}`);
}

main().catch(err => { console.error('❌ 错误:', err.message); process.exit(1); });
