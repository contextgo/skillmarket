#!/usr/bin/env node
/**
 * wiki+ 全文搜索工具
 * 在 wiki/ 目录中进行关键词全文匹配（向量索引不可用时的降级方案）
 * 用法：node search.js <查询词> [wiki根目录路径]
 */

const fs = require('fs');
const path = require('path');

const query = process.argv[2];
const wikiRoot = process.argv[3] || path.resolve(__dirname, '../../../wiki');

if (!query) {
  console.error('错误：请提供搜索关键词。');
  console.error('用法：node search.js "你的查询" [wiki目录路径]');
  process.exit(1);
}

// 递归读取目录下所有 .md 文件
function collectMarkdownFiles(dir, files = []) {
  if (!fs.existsSync(dir)) return files;
  for (const name of fs.readdirSync(dir)) {
    const fullPath = path.join(dir, name);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      collectMarkdownFiles(fullPath, files);
    } else if (name.endsWith('.md')) {
      files.push(fullPath);
    }
  }
  return files;
}

// 在文本中查找匹配行（上下文各 2 行）
function searchInFile(filePath, keywords) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n');
  const results = [];

  lines.forEach((line, idx) => {
    const hit = keywords.some(kw => line.toLowerCase().includes(kw.toLowerCase()));
    if (hit) {
      const start = Math.max(0, idx - 2);
      const end = Math.min(lines.length - 1, idx + 2);
      results.push({
        line: idx + 1,
        context: lines.slice(start, end + 1).join('\n'),
      });
    }
  });

  return results;
}

// 将查询拆分为关键词（空格分隔）
const keywords = query.split(/\s+/).filter(Boolean);
const allFiles = collectMarkdownFiles(wikiRoot);

let totalHits = 0;
const output = [];

for (const filePath of allFiles) {
  const hits = searchInFile(filePath, keywords);
  if (hits.length > 0) {
    const relPath = path.relative(wikiRoot, filePath).replace(/\\/g, '/');
    output.push(`\n## ${relPath}\n`);
    for (const { line, context } of hits) {
      output.push(`> 第 ${line} 行：\n\`\`\`\n${context}\n\`\`\`\n`);
      totalHits++;
    }
  }
}

if (totalHits === 0) {
  console.log(`在 wiki 知识库中未找到与 "${query}" 相关的内容。`);
} else {
  console.log(`# 搜索结果：「${query}」（共 ${totalHits} 处命中）\n`);
  console.log(output.join('\n'));
}
