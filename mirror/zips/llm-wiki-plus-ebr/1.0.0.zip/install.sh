#!/bin/bash
# wiki+ 跨平台安装脚本（macOS / Linux）
# 安装本地向量检索依赖并初始化知识库目录结构
# 用法：bash .cursor/skills/wiki+/install.sh
set -e

WIKI_DIR="${PWD}/wiki"
PLATFORM="unknown"

case "$(uname -s)" in
    Linux*)               PLATFORM="linux";;
    Darwin*)              PLATFORM="macos";;
    CYGWIN*|MINGW*|MSYS*) PLATFORM="windows";;
    *)                    PLATFORM="unknown";;
esac

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  wiki+ 环境初始化"
echo "  系统: ${PLATFORM}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── 第一步：创建目录结构 ──────────────────────────────
echo ""
echo "📁 创建知识库目录..."
mkdir -p "${WIKI_DIR}/inbox" "${WIKI_DIR}/cards" "${WIKI_DIR}/pages"
mkdir -p ".cursor/skills/wiki+/tools"
echo "✅ 目录就绪"

# ── 第二步：初始化 index.md（仅首次）────────────────────
if [ ! -f "${WIKI_DIR}/index.md" ]; then
    echo "📄 创建 index.md..."
    cat > "${WIKI_DIR}/index.md" <<'EOF'
# Wiki 全局索引

> 此文件由 `wiki+` Skill 自动维护。
> 手动编辑后执行 `@wiki+ rebuild-index` 刷新索引。

---

## 知识目录

*摄入第一份文档后，此处将自动生成主题分类列表。*
EOF
    echo "✅ index.md 已创建"
fi

# ── 第三步：安装向量检索依赖 ──────────────────────────────
echo ""
echo "🔧 安装向量检索工具（@huggingface/transformers）..."

TOOLS_DIR="${PWD}/.cursor/skills/wiki+/tools"

if ! command -v node &>/dev/null; then
    echo ""
    echo "❌ 未找到 Node.js，请先安装："
    echo "   https://nodejs.org（推荐 LTS 版本）"
    exit 1
fi

echo "   Node.js $(node --version) 已就绪"

if ! command -v npm &>/dev/null; then
    echo "❌ 未找到 npm，通常随 Node.js 一起安装，请检查安装"
    exit 1
fi

cd "${TOOLS_DIR}" && npm install --silent
echo "✅ 向量检索依赖安装完成"

# ── 第四步：建立向量索引 ──────────────────────────────
echo ""
echo "🔍 建立向量索引..."
echo "   首次运行将下载本地嵌入模型（Xenova/all-MiniLM-L6-v2，约 80MB）"
echo "   请保持网络畅通，后续检索全程离线..."
echo ""
node "${TOOLS_DIR}/vec-index.mjs"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🎉 wiki+ 初始化完成！"
echo ""
echo "  下一步："
echo "  1. 将原始文档放入 wiki/inbox/"
echo "  2. 执行 @wiki+ ingest <文件路径>"
echo "  3. 执行 @wiki+ search <你的问题>"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
