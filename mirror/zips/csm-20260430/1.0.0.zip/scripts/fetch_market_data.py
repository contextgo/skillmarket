#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, sys
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

"""
每日盘后数据获取脚本 (v20260428)
================================================
功能：获取市场数据并输出复盘信息（不写入Excel）

数据源：
  - A股四大指数：新浪财经实时接口 hq.sinajs.cn
  - 恒生/纳指/道指：新浪财经 hkHSI/gb_dji/gb_ixic
  - 美元指数：多通道（东方财富历史→新浪→腾讯），全部失败则标记N/A
  - 黄金/白银/原油：akshare期货连续合约 AU0/AG0/SC0
  - 市场情绪：akshare 涨停池/跌停池/乐咕乐股
  - 概念板块Top5/Bottom5：东方财富push2delay直连API
  - 全球事件：腾讯自选股投资日历 westock-data calendar API

变更记录：
  v20260428 - 增加全球事件分析模块（六），调用westock-data calendar接口获取当日重要财经事件
  v20260426 - 日经225改日经指数，移除大宗商品模块
  v20260425 - 外围市场扩展为全球股指+商品期货双表格，日经225、美元、黄金、白银、原油
  v20260424 - 大盘指数表格合并成交量环比，收盘价改今收
  v20260423 - 删除Excel写入功能，增加全球事件分析模块，概念板块增加最强个股列
  v20260422 - 概念板块H列"原因分析"改为"最大涨幅个股"，新增get_top_stock方法
"""

import argparse
import json
import re
from datetime import datetime, timedelta
from pathlib import Path

try:
    import akshare as ak
    import pandas as pd
    import requests
except ImportError as e:
    print(f"缺少依赖: {e}")
    print("请安装: pip install akshare pandas openpyxl")
    sys.exit(1)


# ─────────────────────────────────────────────────────
# 常量定义
# ─────────────────────────────────────────────────────

# A股指数 新浪符号映射
SINA_A_SHARE_SYMBOLS = {
    '上证指数': 'sh000001',
    '深证指数': 'sz399001',
    '创业板':   'sz399006',
    '科创板':   'sh000688',
}

# HTTP headers
EM_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://quote.eastmoney.com/",
}
SINA_HEADERS = {
    "Referer": "https://stock.finance.sina.com.cn/",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
}


# ─────────────────────────────────────────────────────
# 数据获取器
# ─────────────────────────────────────────────────────

class MarketDataFetcher:
    """市场数据统一获取器"""

    def __init__(self):
        self.data = {}
        self.today = datetime.now()
        self.today_str = self.today.strftime('%Y%m%d')
        self.yesterday_str = (self.today - timedelta(days=1)).strftime('%Y%m%d')

    # ── 1. A股四大指数（新浪实时） ──

    def _fetch_sina_realtime(self, symbols_dict):
        """通用新浪实时行情获取"""
        syms = ','.join(symbols_dict.values())
        url = f'https://hq.sinajs.cn/list={syms}'
        r = requests.get(url, headers=SINA_HEADERS, timeout=10)
        r.encoding = 'gbk'
        result = {}
        for line in r.text.strip().split('\n'):
            line = line.strip()
            if not line:
                continue
            sym = line.split('=')[0].replace('var hq_str_', '')
            val = line.split('"')[1]
            fields = val.split(',')
            # 收盘后格式字段解析：名称,当前价,昨日收盘,今日开盘,...
            if len(fields) < 10:
                cur_price = float(fields[1])
                change = float(fields[2])
                pct = float(fields[3]) / 100
                amount = float(fields[5]) / 10000  # 万元→亿
            else:
                cur_price = float(fields[1])  # fields[1] = 当前价
                prev = float(fields[2])        # fields[2] = 昨日收盘
                change = round(cur_price - prev, 2)
                pct = round(change / prev, 4) if prev else 0
                amount = float(fields[9]) / 1e8  # 元→亿
            result[sym] = {
                'value': round(cur_price, 2),
                'change': round(change, 2),
                'change_pct': round(pct, 4),
                'volume': round(amount, 2),
            }
        return result

    def fetch_a_share(self):
        """获取A股四大指数"""
        print("[1/6] A股四大指数...")
        try:
            raw = self._fetch_sina_realtime(SINA_A_SHARE_SYMBOLS)
            for name, sym in SINA_A_SHARE_SYMBOLS.items():
                if sym in raw:
                    d = raw[sym]
                    self.data[name] = {**d, 'name': name}
                    print(f"  ✅ {name}: {d['value']:,.2f} ({d['change']:+.2f}, {d['change_pct']:.2%}), 成交额{d['volume']:.1f}亿")
                else:
                    print(f"  ❌ {name}: 未返回数据")
                    self.data[name] = None
        except Exception as e:
            print(f"  ❌ A股指数获取失败: {e}")
            for name in SINA_A_SHARE_SYMBOLS:
                self.data[name] = None

    # ── 2. 全球股指（新浪财经） ──

    def fetch_global(self):
        """获取恒生/日经/纳斯达克/道琼斯（使用新浪财经）"""
        print("\n[2/6] 全球股指（新浪财经）...")
        url = 'https://hq.sinajs.cn/list=hkHSI,gb_n225,gb_dji,gb_ixic'
        try:
            r = requests.get(url, headers=SINA_HEADERS, timeout=10)
            r.encoding = 'gbk'
            for line in r.text.strip().split('\n'):
                line = line.strip()
                if not line:
                    continue
                sym = line.split('=')[0].replace('var hq_str_', '')
                val = line.split('"')[1]

                # 处理空数据（日经225有时返回空字符串）
                if not val or val.strip() == '':
                    print(f"  ⚠️ {sym}: 无数据")
                    continue

                fields = val.split(',')

                if sym == 'hkHSI':
                    # 恒生格式: HSI,恒生指数,开盘,收盘,最高,最低,当前,涨跌,涨跌%,...
                    cur = float(fields[6])
                    chg = float(fields[7])
                    pct = float(fields[8]) / 100
                    self.data['恒生指数'] = {'name': '恒生指数', 'value': round(cur, 2),
                                              'change': round(chg, 2), 'change_pct': round(pct, 4), 'volume': None}
                    print(f"  ✅ 恒生指数: {cur:,.2f} ({chg:+.2f}, {pct:.2%})")

                elif sym == 'gb_n225':
                    # 日经225: 名称,当前价,涨跌%,时间,涨跌额,...
                    cur = float(fields[1])
                    pct = float(fields[2]) / 100
                    chg = float(fields[4])
                    self.data['日经指数'] = {'name': '日经指数', 'value': round(cur, 2),
                                             'change': round(chg, 2), 'change_pct': round(pct, 4), 'volume': None}
                    print(f"  ✅ 日经指数: {cur:,.2f} ({chg:+.2f}, {pct:.2%})")

                elif sym == 'gb_dji':
                    # 道琼斯: 名称,当前价,涨跌%,时间,涨跌额,...
                    cur = float(fields[1])
                    pct = float(fields[2]) / 100
                    chg = float(fields[4])
                    self.data['道琼斯'] = {'name': '道琼斯', 'value': round(cur, 2),
                                           'change': round(chg, 2), 'change_pct': round(pct, 4), 'volume': None}
                    print(f"  ✅ 道琼斯: {cur:,.2f} ({chg:+.2f}, {pct:.2%})")

                elif sym == 'gb_ixic':
                    # 纳斯达克: 同道琼斯格式
                    cur = float(fields[1])
                    pct = float(fields[2]) / 100
                    chg = float(fields[4])
                    self.data['纳斯达克'] = {'name': '纳斯达克', 'value': round(cur, 2),
                                             'change': round(chg, 2), 'change_pct': round(pct, 4), 'volume': None}
                    print(f"  ✅ 纳斯达克: {cur:,.2f} ({chg:+.2f}, {pct:.2%})")

        except Exception as e:
            print(f"  ❌ 全球股指获取失败: {e}")
            for name in ['恒生指数', '日经指数', '纳斯达克', '道琼斯']:
                if name not in self.data:
                    self.data[name] = None

    # ── 3. 美元指数（多通道） ──

    def fetch_usd(self):
        """美元指数：东方财富→新浪→腾讯，全部失败返回None"""
        print("\n[3/6] 美元指数...")

        # 通道1: 东方财富历史接口
        try:
            df = ak.index_global_hist_em(symbol='美元指数')
            if df is not None and len(df) >= 2:
                cur = float(df.iloc[-1]['最新价'])
                prev = float(df.iloc[-2]['最新价'])
                if cur > 50:
                    chg = round(cur - prev, 3)
                    pct = round(chg / prev, 4)
                    self.data['美元'] = {'name': '美元', 'value': round(cur, 3),
                                         'change': chg, 'change_pct': pct, 'volume': None}
                    print(f"  ✅ 美元(东财): {cur} ({chg:+.3f}, {pct:.2%})")
                    return
        except Exception as e:
            print(f"  ⚠️ 东方财富失败: {e}")

        # 通道2: 新浪美元指数
        try:
            url = 'https://hq.sinajs.cn/list=fx_usdx'
            r = requests.get(url, headers=SINA_HEADERS, timeout=8)
            r.encoding = 'gbk'
            val = r.text.split('"')[1]
            fields = val.split(',')
            if len(fields) >= 2 and fields[0]:
                cur = float(fields[0]) if fields[0] else float(fields[1])
                prev = float(fields[1]) if len(fields) > 1 and fields[1] else cur
                if 50 < cur < 150:  # 合理范围校验
                    chg = round(cur - prev, 3)
                    pct = round(chg / prev, 4) if prev else 0
                    self.data['美元'] = {'name': '美元', 'value': round(cur, 3),
                                         'change': chg, 'change_pct': pct, 'volume': None}
                    print(f"  ✅ 美元(新浪): {cur} ({chg:+.3f})")
                    return
        except Exception as e:
            print(f"  ⚠️ 新浪失败: {e}")

        # 通道3: 腾讯财经
        try:
            url = 'https://qt.gtimg.cn/q=USDDXY'
            r = requests.get(url, timeout=8)
            r.encoding = 'gbk'
            data_str = r.text.split('~')
            if len(data_str) > 3:
                cur = float(data_str[1])
                if 50 < cur < 150:
                    self.data['美元'] = {'name': '美元', 'value': round(cur, 3),
                                         'change': None, 'change_pct': None, 'volume': None}
                    print(f"  ✅ 美元(腾讯): {cur}")
                    return
        except Exception as e:
            print(f"  ⚠️ 腾讯失败: {e}")

        print("  ❌ 所有美元接口均失败，标记为None")
        self.data['美元'] = None

    # ── 4. 商品（黄金/白银/原油） ──

    def fetch_commodities(self):
        """获取黄金(AU0)/白银(AG0)/原油(SC0)期货连续合约"""
        print("\n[4/6] 商品数据（期货连续合约）...")
        mapping = {'黄金': 'AU0', '白银': 'AG0', '原油': 'SC0'}
        for name, sym in mapping.items():
            try:
                df = ak.futures_zh_spot(symbol=sym, market="CF", adjust="0")
                if df is None or df.empty:
                    print(f"  ❌ {name}: 空数据")
                    self.data[name] = None
                    continue
                row = df.iloc[0]
                cur = float(row['current_price'])
                # 使用结算价作为昨收基准（期货当日结算价）
                settle = float(row['last_settle_price'])
                chg = round(cur - settle, 2)
                pct = round(chg / settle, 4) if settle else 0
                self.data[name] = {'name': name, 'value': round(cur, 2),
                                   'change': chg, 'change_pct': pct, 'volume': None}
                print(f"  ✅ {name}: {cur:.2f} ({chg:+.2f}, {pct:.2%})")
            except Exception as e:
                print(f"  ❌ {name} 失败: {e}")
                self.data[name] = None

    # ── 5. 市场情绪 ──

    def fetch_sentiment(self):
        """获取涨停/跌停/二板率/涨跌比"""
        print("\n[5/6] 市场情绪...")
        s = {'zt_count': 0, 'dt_count': 0, 'erban_rate': 0,
             'up_count': 0, 'down_count': 0}

        # 涨停池
        today_codes = set()
        try:
            zt_df = ak.stock_zt_pool_em(date=self.today_str)
            s['zt_count'] = len(zt_df) if zt_df is not None else 0
            today_codes = set(zt_df['代码'].tolist()) if zt_df is not None else set()
        except Exception as e:
            print(f"  ⚠️ 涨停失败: {e}")

        # 跌停池
        try:
            dt_df = ak.stock_zt_pool_dtgc_em(date=self.today_str)
            s['dt_count'] = len(dt_df) if dt_df is not None else 0
        except Exception as e:
            print(f"  ⚠️ 跌停失败: {e}")

        # 二板率
        try:
            zt_yes = ak.stock_zt_pool_em(date=self.yesterday_str)
            yes_codes = set(zt_yes['代码'].tolist()) if zt_yes is not None else set()
            erban = len(today_codes & yes_codes)
            s['erban_rate'] = round(erban / len(yes_codes), 4) if yes_codes else 0
            print(f"  二板率: {erban}/{len(yes_codes)} = {s['erban_rate']:.2%}")
        except Exception as e:
            print(f"  ⚠️ 二板率失败: {e}")

        # 涨跌家数（乐咕乐股优先）
        try:
            legu_df = ak.stock_market_activity_legu()
            legu_dict = dict(zip(legu_df['item'], legu_df['value']))
            s['up_count'] = int(legu_dict.get('上涨', 0))
            s['down_count'] = int(legu_dict.get('下跌', 0))
        except Exception as e:
            print(f"  ⚠️ 乐咕涨跌比失败: {e}，尝试全量行情...")
            try:
                spot_df = ak.stock_zh_a_spot_em()
                if spot_df is not None and not spot_df.empty:
                    s['up_count'] = len(spot_df[spot_df['涨跌幅'] > 0])
                    s['down_count'] = len(spot_df[spot_df['涨跌幅'] < 0])
            except Exception as e2:
                print(f"  ❌ 全量行情也失败: {e2}")

        self.data['sentiment'] = s
        print(f"  ✅ 涨停{s['zt_count']} 跌停{s['dt_count']} "
              f"涨跌比{s['up_count']}:{s['down_count']} 二板率{s['erban_rate']:.2%}")

    # ── 6. 概念板块 Top5 / Bottom5 ──

    def fetch_concepts(self):
        """
        获取概念板块涨幅前五和后五。
        使用东方财富 push2delay API。
        返回 (top5_df, bottom5_df, bk_code_map)
        """
        # 概念板块黑名单关键词
        exclude_keywords = [
            "连板", "打板", "打二板", "一字", "昨日", "今日",
            "做市", "机构重仓", "北证", "融资融券", "转融通",
        ]

        print("\n[6/6] 概念板块（东方财富push2delay）...")
        all_items = []

        # 分页获取（最多取400条，覆盖主要概念板块）
        for page in range(1, 5):
            url = (
                f"https://push2delay.eastmoney.com/api/qt/clist/get"
                f"?pn={page}&pz=100&po=1&np=1&fltt=2&invt=2&dect=1"
                f"&fid=f3&fs=m:90+t:3"
                f"&fields=f14,f3,f6,f62,f12,f104,f105,f106"
                f"&cb=&ut=&_=1"
            )
            try:
                r = requests.get(url, headers=EM_HEADERS, timeout=15)
                items = r.json().get('data', {}).get('diff', [])
                if not items:
                    break
                all_items.extend(items)
            except Exception as e:
                print(f"  ⚠️ 第{page}页获取失败: {e}")
                break

        if not all_items:
            print("  ❌ 概念板块数据为空")
            return None, None, {}

        df = pd.DataFrame(all_items)
        df.rename(columns={
            "f14": "板块名称", "f3": "涨跌幅", "f6": "成交额",
            "f62": "主力净流入", "f12": "代码",
            "f104": "涨家数", "f105": "跌家数", "f106": "涨停数",
        }, inplace=True)
        df["涨跌幅"] = pd.to_numeric(df["涨跌幅"], errors="coerce")
        df.dropna(subset=["涨跌幅"], inplace=True)

        # 过滤黑名单
        mask = df["板块名称"].apply(
            lambda n: not any(kw in str(n) for kw in exclude_keywords)
                  and not re.search(r'R$', str(n))
        )
        df = df[mask].reset_index(drop=True)
        df.sort_values("涨跌幅", ascending=False, inplace=True)
        df.reset_index(drop=True, inplace=True)

        # 单位转换
        df["成交额亿"] = (df["成交额"].astype(float) / 1e8).round(2)
        df["主力净流入亿"] = (df["主力净流入"].astype(float) / 1e8).round(2)
        for col in ["涨停数", "涨家数", "跌家数"]:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)

        top5 = df.head(5).copy()
        bottom5 = df.tail(5).sort_values("涨跌幅", ascending=True).reset_index(drop=True)

        # 构建 BK代码映射表（名称→BK代码）
        bk_code_map = dict(zip(df["板块名称"], df["代码"]))

        # 获取每个板块的最大涨幅个股
        top_stocks = {}
        bottom_stocks = {}
        print("\n  涨幅前5 (含最强个股):")
        for _, row in top5.iterrows():
            board_name = row['板块名称']
            bk_code = bk_code_map.get(board_name, '')
            top_stock = self.get_top_stock(bk_code) if bk_code else '--'
            top_stocks[board_name] = top_stock
            print(f"    {board_name:<12} {row['涨跌幅']:+.2f}%  "
                  f"涨停{row['涨停数']} 涨{row['涨家数']} 跌{row['跌家数']}  → {top_stock}")

        print("\n  跌幅前5 (含最强个股):")
        for _, row in bottom5.iterrows():
            board_name = row['板块名称']
            bk_code = bk_code_map.get(board_name, '')
            top_stock = self.get_top_stock(bk_code) if bk_code else '--'
            bottom_stocks[board_name] = top_stock
            print(f"    {board_name:<12} {row['涨跌幅']:+.2f}%  "
                  f"涨停{row['涨停数']} 涨{row['涨家数']} 跌{row['跌家数']}  → {top_stock}")

        # 将个股信息添加到DataFrame
        top5['最强个股'] = top5['板块名称'].map(top_stocks)
        bottom5['最强个股'] = bottom5['板块名称'].map(bottom_stocks)

        return top5, bottom5, bk_code_map

    # ── 7. 获取板块内最大涨幅个股 ──

    def get_top_stock(self, bk_code):
        """
        查询板块成分股中涨幅最大的个股，返回格式：
        "股票名称 +X.XX%"
        失败时返回 '--'
        """
        url = (
            f"https://push2delay.eastmoney.com/api/qt/clist/get"
            f"?pn=1&pz=500&po=1&np=1&fltt=2&invt=2&fid=f3"
            f"&fs=b:{bk_code}"
            f"&fields=f14,f3,f12"
        )
        try:
            r = requests.get(url, headers=EM_HEADERS, timeout=10)
            stocks = r.json().get('data', {}).get('diff', [])
            if not stocks:
                return '--'

            # 过滤有效涨跌幅数据
            def safe_float(v):
                try:
                    return float(v)
                except (TypeError, ValueError):
                    return None

            valid = [s for s in stocks if safe_float(s.get('f3')) is not None]
            if not valid:
                return '--'

            # 按涨跌幅降序，取涨幅最大的那只
            best = max(valid, key=lambda s: safe_float(s['f3']))
            name = best.get('f14', '')
            pct = safe_float(best['f3'])
            if name and pct is not None:
                return f"{name} {pct:+.2f}%"
            return '--'
        except Exception as e:
            return '--'

    # ── 8. 成交量涨跌幅 ──

    def calc_volume_change(self):
        """
        计算A股四大指数的成交量环比涨跌幅。
        """
        print("\n[附加] 成交量涨跌幅计算...")
        indices = [
            ('sh000001', '上证指数'),
            ('sz399001', '深证指数'),
            ('sz399006', '创业板'),
            ('sh000688', '科创板'),
        ]
        result = {}
        for code, name in indices:
            try:
                df = ak.stock_zh_index_daily(symbol=code)
                today_vol = float(df.iloc[-1]['volume']) / 1e8  # 元→亿
                yest_vol = float(df.iloc[-2]['volume']) / 1e8
                if yest_vol > 0:
                    chg_pct = (today_vol - yest_vol) / yest_vol
                    result[name] = f"{chg_pct:+.2%}"
                    print(f"  ✅ {name}: 昨{yest_vol:.0f}亿 → 今{today_vol:.0f}亿 → {chg_pct:+.2%}")
                else:
                    result[name] = ""
                    print(f"  ⚠️ {name}: 昨日成交量为0")
            except Exception as e:
                print(f"  ❌ {name}: {e}")
                result[name] = ""
        return result

    # ── 7. 全球重要财经事件（腾讯自选股投资日历） ──

    def fetch_events(self):
        """
        通过 subprocess 调用 westock-data calendar 获取当日重要财经事件。
        筛选 Weightiness >= 2 的事件，按时间升序排列，返回事件列表。
        返回格式：[{'time': str, 'content': str, 'country': str, 'weightiness': int}, ...]
        """
        import subprocess
        import shutil
        target = self.today.strftime('%Y-%m-%d')
        print(f"\n[7/7] 全球重要财经事件（投资日历）...")

        # 跨平台查找 npx 命令路径（Windows 需要 .cmd 后缀）
        npx_cmd = shutil.which('npx')
        if npx_cmd is None:
            # Windows 降级：直接用 cmd /c npx
            npx_cmd = 'npx.cmd'

        try:
            result = subprocess.run(
                [npx_cmd, '--yes', 'westock-data-skillhub@latest', 'calendar', target],
                capture_output=True, text=True, timeout=90,
                encoding='utf-8', errors='replace',
                shell=(sys.platform == 'win32'),  # Windows 需 shell=True 解析 .cmd
            )
            if result.returncode != 0:
                print(f"  ⚠️ westock-data 调用失败: {result.stderr[:200]}")
                return []

            output = result.stdout
            events = []
            seen_contents = set()

            # 表格列顺序（westock-data calendar 标准输出）：
            # | date | oid | time | Weightiness | Content | CountryName | CountryCode |
            # | Previous | Predict | CurrentValue | ColumnCode | Area | FinancialEvent | Flag |
            # 对应索引（split('|') 后，第0/最后个元素是空字符串）：
            # parts[1]=date, parts[2]=oid, parts[3]=time, parts[4]=Weight,
            # parts[5]=Content, parts[6]=Country, parts[7]=CountryCode,
            # parts[8]=Previous, parts[9]=Predict, parts[10]=CurrentValue,
            # parts[11]=ColumnCode, parts[12]=Area, parts[13]=FinancialEvent

            for line in output.splitlines():
                line = line.strip()
                if not line or line.startswith('#') or line.startswith('npm ') or line.startswith('http'):
                    continue
                if '|' not in line:
                    continue
                parts = [p.strip() for p in line.split('|')]
                # 至少需要 14 个分隔符（含首尾空元素）才可能有 FinancialEvent
                if len(parts) < 6:
                    continue

                try:
                    time_val     = parts[3]
                    weight_str   = parts[4]
                    content      = parts[5]           # 经济指标名，如"3月失业率"
                    country      = parts[6] if len(parts) > 6 else ''
                    previous     = parts[8]  if len(parts) > 8  else ''
                    predict      = parts[9]  if len(parts) > 9  else ''
                    current_val  = parts[10] if len(parts) > 10 else ''
                    fin_event    = parts[13] if len(parts) > 13 else ''  # 叙事性事件名
                except IndexError:
                    continue

                # 跳过表头行和分隔行
                if weight_str in ('Weightiness', '---', ''):
                    continue

                try:
                    weight = int(weight_str)
                except ValueError:
                    weight = 0
                if weight < 2:
                    continue

                # 确定展示用标题：优先 FinancialEvent（叙事性），次选 Content（指标名）
                display_title = fin_event if fin_event else content
                if not display_title:
                    continue  # 两者均为空则跳过

                # 去重
                key = f"{time_val}|{display_title[:40]}"
                if key in seen_contents:
                    continue
                seen_contents.add(key)

                events.append({
                    'time':          time_val,
                    'title':         display_title,
                    'indicator':     content,       # 经济指标名（可空）
                    'country':       country,
                    'weightiness':   weight,
                    'previous':      previous,
                    'predict':       predict,
                    'current':       current_val,
                    'is_event':      bool(fin_event),  # True=叙事型, False=数据指标型
                })

            if events:
                # 按时间升序排列
                events.sort(key=lambda x: x['time'])
                print(f"  ✅ 筛选到 {len(events)} 条重要事件（重要程度≥2）：")
                for e in events:
                    tag = '📌' if e['is_event'] else '📊'
                    print(f"    [{e['time']}] {tag} {e['title'][:60]}")
            else:
                print("  ⚠️ 未筛选到重要事件，请检查日历接口数据格式")

            return events

        except subprocess.TimeoutExpired:
            print("  ❌ westock-data 调用超时（60s）")
            return []
        except Exception as e:
            print(f"  ❌ 全球事件获取异常: {e}")
            return []

    # ── 全量执行入口 ──

    def run_all(self):
        """按顺序执行所有数据获取步骤"""
        self.fetch_a_share()
        self.fetch_global()
        self.fetch_usd()
        self.fetch_commodities()
        self.fetch_sentiment()
        top5, bottom5, bk_code_map = self.fetch_concepts()
        vol_change = self.calc_volume_change()
        events = self.fetch_events()

        return {
            'market_data': self.data,
            'top5': top5,
            'bottom5': bottom5,
            'bk_code_map': bk_code_map,
            'vol_change': vol_change,
            'events': events,
        }


# ─────────────────────────────────────────────────────
# 格式化输出
# ─────────────────────────────────────────────────────

def format_recovery_report(result, events=None):
    """格式化输出复盘报告"""
    mkt = result['market_data']
    top5 = result['top5']
    bottom5 = result['bottom5']
    vol_change = result['vol_change']
    sentiment = mkt.get('sentiment', {})

    lines = []
    lines.append("=" * 60)
    lines.append(f"  📊 股市复盘 - {datetime.now().strftime('%Y年%m月%d日')}")
    lines.append("=" * 60)

    # 一、大盘指数（含成交量环比）
    lines.append("\n## 一、大盘指数表现")
    lines.append("| 指数 | 今收 | 涨跌幅 | 成交额 | 环比 |")
    lines.append("|------|------|--------|--------|------|")
    for name in ['上证指数', '深证指数', '创业板', '科创板']:
        d = mkt.get(name, {})
        vol_chg = vol_change.get(name, '')
        if d:
            pct = d.get('change_pct', 0)
            arrow = "▲" if pct >= 0 else "▼"
            lines.append(f"| {name} | {d.get('value', 0):,.2f} | {arrow}{abs(pct)*100:.2f}% | {d.get('volume', 0):.0f}亿 | {vol_chg} |")

    # 二、外围市场
    lines.append("\n## 二、外围市场")
    lines.append("| 指数 | 今收 | 涨跌幅 |")
    lines.append("|------|------|--------|")
    for name in ['恒生指数', '日经指数', '道琼斯', '纳斯达克']:
        d = mkt.get(name, {})
        if d:
            pct = d.get('change_pct', 0)
            arrow = "▲" if pct >= 0 else "▼"
            lines.append(f"| {name} | {d.get('value', 0):,.2f} | {arrow}{abs(pct)*100:.2f}% |")
        else:
            lines.append(f"| {name} | -- | -- |")

    # 三、市场情绪
    lines.append("\n## 三、市场情绪")
    zt = sentiment.get('zt_count', 0)
    dt = sentiment.get('dt_count', 0)
    up = sentiment.get('up_count', 0)
    dn = sentiment.get('down_count', 0)
    erban = sentiment.get('erban_rate', 0)
    lines.append(f"- 涨停: **{zt}家** | 跌停: **{dt}家**")
    lines.append(f"- 涨跌比: **{up}:{dn}**")
    lines.append(f"- 二板率: **{erban*100:.2f}%**")

    # 四、概念板块
    lines.append("\n## 四、概念板块")
    if top5 is not None and not top5.empty:
        lines.append("\n**涨幅前五：**")
        lines.append("| 板块 | 涨跌幅 | 涨停 | 涨 | 跌 |")
        lines.append("|------|--------|------|-----|-----|")
        for _, row in top5.iterrows():
            lines.append(f"| {row['板块名称']} | +{row['涨跌幅']:.2f}% | {row['涨停数']} | {row['涨家数']} | {row['跌家数']} |")

    if bottom5 is not None and not bottom5.empty:
        lines.append("\n**跌幅前五：**")
        lines.append("| 板块 | 涨跌幅 | 涨停 | 涨 | 跌 |")
        lines.append("|------|--------|------|-----|-----|")
        for _, row in bottom5.iterrows():
            lines.append(f"| {row['板块名称']} | {row['涨跌幅']:.2f}% | {row['涨停数']} | {row['涨家数']} | {row['跌家数']} |")

    # 五、大宗商品
    lines.append("\n## 五、大宗商品")
    lines.append("| 品种 | 最新价 | 涨跌幅 |")
    lines.append("|------|--------|--------|")
    commodity_map = {
        '黄金':  ('AU0', '元/克'),
        '白银':  ('AG0', '元/千克'),
        '原油':  ('SC0', '元/桶'),
        '美元':  ('DXY', ''),
    }
    for name, (sym, unit) in commodity_map.items():
        d = mkt.get(name, {})
        if d:
            pct = d.get('change_pct', 0)
            arrow = "▲" if pct >= 0 else "▼"
            val = d.get('value', 0)
            lines.append(f"| {name}（{sym}）| {val:,.2f}{unit} | {arrow}{abs(pct)*100:.2f}% |")
        else:
            lines.append(f"| {name}（{sym}）| -- | -- |")

    # 六、全球重要财经事件
    events = result.get('events', [])
    if events:
        lines.append("\n## 六、对金融市场影响的全球事件分析")
        lines.append(f"\n*来源：腾讯自选股投资日历 | {datetime.now().strftime('%Y-%m-%d')}*\n")

        # 先输出叙事型重大事件（is_event=True，如央行决议、发布会）
        narrative_events = [e for e in events if e.get('is_event')]
        data_events      = [e for e in events if not e.get('is_event')]

        idx = 1
        for event in narrative_events:
            weight = event.get('weightiness', 0)
            stars = '⭐' * weight
            country = event.get('country', '')
            time_str = event.get('time', '')
            title = event.get('title', '')
            country_tag = f"[{country}] " if country else ''
            lines.append(f"**📌 {idx}. {country_tag}{title}**  {stars}  _{time_str}_\n")
            idx += 1

        # 再输出重要数据指标（Weightiness=3）
        key_data = [e for e in data_events if e.get('weightiness', 0) >= 3]
        if key_data:
            lines.append("\n**📊 今日重要经济数据：**")
            lines.append("| 时间 | 国家 | 指标 | 前值 | 预测 | 公布 |")
            lines.append("|------|------|------|------|------|------|")
            for event in key_data:
                t = event.get('time', '')
                c = event.get('country', '')
                ind = event.get('indicator', event.get('title', ''))
                prev = event.get('previous', '--') or '--'
                pred = event.get('predict', '--') or '--'
                cur  = event.get('current', '--') or '--'
                lines.append(f"| {t} | {c} | {ind} | {prev} | {pred} | {cur} |")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────
# Main 入口
# ─────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='每日盘后数据获取 (v20260428)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python fetch_market_data.py
  python fetch_market_data.py --date 2026-04-22
        """)
    parser.add_argument('--date', help='指定日期 YYYY-MM-DD（默认今天）')

    args = parser.parse_args()

    if args.date:
        target_date = datetime.strptime(args.date, '%Y-%m-%d')
    else:
        target_date = datetime.now()

    print(f"{'='*55}")
    print(f"  盘后数据获取 v20260428")
    print(f" {target_date.strftime('%Y-%m-%d %H:%M')}")
    print(f"{'='*55}\n")

    # 全量获取数据
    fetcher = MarketDataFetcher()
    if args.date:
        fetcher.today = target_date
        fetcher.today_str = target_date.strftime('%Y%m%d')
        fetcher.yesterday_str = (target_date - timedelta(days=1)).strftime('%Y%m%d')

    result = fetcher.run_all()

    events = result.get('events', [])
    print("\n" + "=" * 55)
    print(" ✅ 数据获取完成！")
    if events:
        print(f" ✅ 全球重要事件 {len(events)} 条（已并入复盘报告第六部分）")
    print("=" * 55)

    # 输出格式化复盘报告
    print("\n\n" + "=" * 60)
    print("  📋 完整复盘报告")
    print("=" * 60)
    report = format_recovery_report(result)
    print(report)


if __name__ == '__main__':
    main()
