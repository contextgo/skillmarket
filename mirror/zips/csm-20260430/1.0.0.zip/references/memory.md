# 股票市场日报技能 - 长期记忆

## 目标 Excel 文件

- 路径：`C:/Users/rlong/Desktop/26年盘复盘.xlsx`（用户本地路径，执行时需替换）
- Sheet 命名规则：`N月`（如 3月、4月等）

## 已知接口问题及修复方案

### 黄金/白银
- **问题**：`ak.spot_hist_sge()` 收盘后经常返回0
- **修复**：使用 `ak.futures_zh_spot(symbol="AU0"/"AG0", market="CF", adjust="0")`
- **字段**：涨跌幅基于 `last_settle_price`（昨结算价）计算

### 原油
- **问题**：`ak.futures_zh_realtime(symbol="SC0")` 已不可用
- **修复**：使用 `ak.futures_zh_spot(symbol="SC0", market="CF", adjust="0")`

### 全球指数/美元
- **问题**：`ak.index_global_spot_em()` 东方财富实时接口经常断连
- **修复(2026-04-09)**：恒生/道琼斯/纳斯达克改用新浪财经接口
- **美元指数**：目前所有接口均无法稳定获取，需手动补充

### A股数据时间
- **问题**：`ak.stock_zh_index_daily()` 在收盘后延迟较大
- **修复**：改用新浪财经实时接口 `hq.sinajs.cn`
- **注意**：盘中6字段 vs 收盘后34字段两套格式自动识别

### 概念板块
- **问题**：akshare的`stock_board_concept_*`接口夜间全部断连
- **修复**：使用东方财富直连API `push2delay.eastmoney.com`
- **限制**：接口硬限制返回300条

## 板块数据格式规范

- 前五：Row19-23，后五：Row26-30
- 标题和表头：绿色加粗（FF008000）
- 前五：绿底白字(00B050)、后五：红底白字(FF0000)

## 黑名单过滤关键词

```
连板、打板、打二板、一字、昨日、今日、做市、机构重仓、北证、融资融券、转融通
```
正则排除：`R$`（指数成分股后缀）

## 脚本版本管理

- **当前版本**: `v20260422`
- **备份版本**: `scripts/fetch_market_data_v20260413.py`

### 回滚方法
```bash
cp scripts/fetch_market_data_v20260413.py scripts/fetch_market_data.py
```
