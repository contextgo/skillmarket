---
name: full-page-screenshot
description: Capture full-page screenshots of any web page, including scrollable content, lazy-loaded images, and mobile-optimized sites. This skill should be used when the user asks to take a screenshot, capture a web page, save a page as an image, or needs a visual snapshot of a URL. Trigger phrases include "screenshot", "截图", "截屏", "capture page", "save page as image", "网页截图", "全页面截图", "完整截图", "长截图", "滚动截图".
---

# Full Page Screenshot

Capture complete, pixel-perfect screenshots of any web page — including all scrollable content, lazy-loaded images, internal scroll containers, and mobile-optimized layouts.

## When to Use

- The user asks to take a screenshot of a web page (full or partial)
- The user wants to capture a URL as an image
- The user needs a visual snapshot for documentation, reporting, or archiving
- The user mentions terms like "截图", "截屏", "capture", "screenshot", "网页截图", "长截图"

## Prerequisites

The screenshot script requires **Playwright** with Chromium. Before running the script, ensure Playwright is available:

```bash
# Check if playwright is installed
node -e "require('playwright')" 2>&1

# If not installed, install it in the current workspace
npm install playwright

# Ensure Chromium browser is downloaded
npx playwright install chromium
```

If `playwright` is not installed in the workspace, install it before running the screenshot script. This is a one-time setup per workspace.

## How to Use

### Script Location

The screenshot tool is at: `scripts/screenshot.js` (relative to this skill's directory).

### Basic Usage

```bash
node <skill-dir>/scripts/screenshot.js <url> [options]
```

### Screenshot Modes

| Mode | Description | Flag |
|------|-------------|------|
| **fullpage** (default) | Captures the entire page including all scrollable content | `--mode fullpage` or omit |
| **viewport** | Captures only the visible viewport area | `--mode viewport` |
| **element** | Captures a specific DOM element | `--mode element --selector ".css-selector"` |

### Common Options

| Option | Short | Description | Default |
|--------|-------|-------------|---------|
| `--output` | `-o` | Output file path | `fullpage-screenshot.png` |
| `--mode` | `-m` | Screenshot mode: fullpage / viewport / element | `fullpage` |
| `--selector` | `-s` | CSS selector (element mode) | — |
| `--device` | `-d` | Device: auto / desktop / iphone / ipad | `auto` |
| `--width` | `-w` | Custom viewport width | auto-detected |
| `--height` | | Custom viewport height | auto-detected |
| `--scale` | | Device pixel ratio | auto (desktop=1, mobile=3) |
| `--format` | `-f` | Image format: png / jpeg | `png` |
| `--quality` | `-q` | JPEG quality (1-100) | `90` |
| `--wait` | | Extra wait after page load (ms) | `3000` |
| `--no-lazy` | | Skip lazy-load scrolling | `false` |
| `--keep-fixed` | | Keep fixed/sticky elements visible | `false` |
| `--dark` | | Use dark color scheme | `false` |
| `--cookie` | | Set cookies (format: `name=value; name2=value2`) | — |
| `--header` | | Custom HTTP header (format: `Key:Value`, repeatable) | — |
| `--auth` | | HTTP Basic Auth (format: `user:pass`) | — |
| `--json` | | Output result as JSON (silent mode for programmatic use) | `false` |
| `--timeout` | | Page load timeout (ms) | `60000` |
| `--skip-font-check` | | Skip Chinese font detection on Linux | `false` |
| `--install-fonts` | | Install Chinese fonts only, then exit (Linux) | `false` |

### Examples

```bash
# Full page screenshot with auto device detection
node <script> https://www.qq.com/ -o qq-full.png

# Force mobile device emulation
node <script> https://m.example.com -d iphone -o mobile.png

# Desktop mode with dark theme
node <script> https://example.com -d desktop --dark -o dark.png

# Viewport-only screenshot (no scrolling)
node <script> https://example.com -m viewport -o viewport.png

# Screenshot a specific element
node <script> https://example.com -m element -s ".article-body" -o article.png

# JPEG format for smaller file size
node <script> https://example.com -f jpeg -q 85 -o result.jpg

# With cookies and custom headers
node <script> https://example.com --cookie "token=abc123" --header "X-Custom:value" -o auth.png

# JSON output for programmatic use
node <script> https://example.com --json -o result.png

# Install Chinese fonts on Linux server (one-time setup)
node <script> --install-fonts

# Skip font check if fonts are known to be installed
node <script> https://example.com --skip-font-check -o result.png
```

## Key Technical Details

### Chinese Font Auto-Detection (Linux Cloud Servers)

On Linux systems, the script runs a font check before launching the browser (Phase 0):
1. Uses `fc-list :lang=zh` to check if Chinese fonts exist
2. If missing, auto-detects the package manager (apt/yum/dnf/apk/pacman/zypper)
3. Checks for root/sudo permission
4. Installs `fonts-noto-cjk` (or equivalent) and refreshes font cache
5. Verifies installation success

This is **automatic** — no manual intervention needed if the agent has root/sudo access. On macOS/Windows, this step is skipped (system fonts are sufficient).

Use `--skip-font-check` to bypass this step for faster execution after initial setup.

### Auto Device Detection

When `--device auto` (default), the script:
1. Opens the URL with a desktop User-Agent first
2. Checks the `<meta name="viewport">` tag and body width
3. If mobile viewport detected (`width=device-width`) or body width ≤ 768px, switches to iPhone emulation
4. Otherwise uses desktop mode

### Internal Scroll Container Handling

Many modern web apps (especially mobile SPAs) use internal scroll containers (`overflow: auto/scroll`) instead of native page scrolling. The script automatically:
1. Detects the largest internal scroll container
2. Scrolls within it to trigger lazy-loaded content
3. Expands the container (`overflow: visible`, `height: auto`)
4. Unblocks all ancestor elements that may restrict height
5. Adjusts viewport height if the page height remains locked

### Fixed/Sticky Element Handling

By default, `position: fixed` and `position: sticky` elements (nav bars, floating buttons, cookie banners) are **hidden** before taking the screenshot. This prevents them from appearing at incorrect positions in full-page mode. To keep them visible, use `--keep-fixed`.

### Lazy Loading

The script automatically scrolls through the page/container in 300px increments to trigger lazy-loaded images and content. To skip this (for static pages), use `--no-lazy`.

## Workflow for Common Tasks

### Standard Full-Page Screenshot

1. Ensure `playwright` is installed in the workspace
2. Run: `node <script> <url> -o <output-path>`
3. Present the result to the user

### Mobile Page Screenshot

1. Ensure `playwright` is installed
2. Run: `node <script> <url> -d iphone -o <output-path>`
3. Or let auto-detection handle it: `node <script> <url> -o <output-path>`

### Batch Screenshots

For multiple URLs, run the script in sequence:
```bash
for url in "https://a.com" "https://b.com" "https://c.com"; do
  name=$(echo "$url" | sed 's|https://||;s|/|-|g;s|[^a-zA-Z0-9-]||g')
  node <script> "$url" -o "${name}.png" --json
done
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `Cannot find module 'playwright'` | Run `npm install playwright` in the workspace |
| `Browser not found` | Run `npx playwright install chromium` |
| Page content missing at bottom | Increase `--wait` time (e.g., `--wait 5000`) |
| Image too large | Use JPEG format: `-f jpeg -q 80` |
| Auth-required page blank | Use `--cookie` or `--auth` options |
| Floating elements misplaced | This is handled by default; use `--keep-fixed` to keep them |
| **Chinese text blank/garbled** | Cloud Linux servers lack CJK fonts — auto-detected and auto-installed, see below |

### Cloud Server: Chinese / CJK Font Auto-Detection

**Symptom**: Screenshots taken on cloud servers (Linux) show Chinese characters as blank, squares (□□□), or garbled text.

**Root Cause**: Headless Chromium requires system-level fonts to render text. Most cloud Linux images (Ubuntu Server, CentOS Minimal, Alpine) do not include CJK (Chinese/Japanese/Korean) fonts by default.

**Automatic Handling (v2)**: The script now automatically handles this on Linux:

1. **Auto-detect**: Before each screenshot, checks for Chinese fonts via `fc-list :lang=zh`
2. **Auto-install**: If no Chinese fonts found and root/sudo is available, automatically installs `fonts-noto-cjk` using the system package manager (apt/yum/dnf/apk/pacman/zypper)
3. **Auto-verify**: Confirms installation success before proceeding

**Supported Linux distributions**: Ubuntu/Debian (apt), CentOS/RHEL/Amazon Linux (yum/dnf), Alpine (apk), Arch (pacman), openSUSE (zypper).

**Manual Commands** (if auto-install fails due to permissions):

```bash
# Ubuntu / Debian
sudo apt-get update && sudo apt-get install -y fonts-noto-cjk fontconfig && fc-cache -fv

# CentOS / RHEL / Amazon Linux
sudo yum install -y google-noto-sans-cjk-sc-fonts wqy-zenhei-fonts fontconfig && fc-cache -fv

# Alpine (Docker)
apk add --no-cache font-noto-cjk fontconfig && fc-cache -fv
```

**Standalone Font Install Mode**:
```bash
# Just install fonts without taking a screenshot
node <script> --install-fonts
```

**Skip Font Check** (for performance, if fonts are known to be installed):
```bash
node <script> https://example.com --skip-font-check -o result.png
```

**Docker Tip**: Add font installation to your Dockerfile:
```dockerfile
# For node-based images (Debian/Ubuntu)
RUN apt-get update && apt-get install -y fonts-noto-cjk fontconfig && \
    fc-cache -fv && apt-get clean

# For Alpine-based images
RUN apk add --no-cache font-noto-cjk fontconfig && fc-cache -fv
```

**Playwright Dockerfile Tip**: Playwright's official Docker images (`mcr.microsoft.com/playwright`) already include common fonts, but may still lack full CJK coverage. Always install `fonts-noto-cjk` explicitly.
