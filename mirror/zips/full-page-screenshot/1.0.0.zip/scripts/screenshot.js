#!/usr/bin/env node
/**
 * full-page-screenshot — 网页完整截图工具
 *
 * 功能：
 *  1. 自动检测移动端/桌面端页面（viewport meta + 宽度检测）
 *  2. 自动检测并展开内部滚动容器（overflow: auto/scroll）
 *  3. 自动处理 fixed/sticky 悬浮元素（隐藏避免截图错位）
 *  4. 自动逐步滚动触发懒加载内容
 *  5. 支持 viewport / fullPage / element 三种截图模式
 *  6. 支持自定义视口尺寸、设备模拟、等待时间等
 *
 * 用法：
 *   node screenshot.js <url> [options]
 *
 * 选项：
 *   --output, -o      输出文件路径（默认: fullpage-screenshot.png）
 *   --mode, -m        截图模式: fullpage（默认）| viewport | element
 *   --selector, -s    CSS 选择器（仅 element 模式）
 *   --width, -w       视口宽度（默认: 自动检测）
 *   --height           视口高度（默认: 自动检测）
 *   --device, -d      设备名称: desktop | iphone | ipad（默认: auto）
 *   --scale            设备像素比（默认: auto, 桌面=1, 移动端=3）
 *   --wait             页面加载后额外等待时间 ms（默认: 3000）
 *   --scroll-wait      每次滚动间隔 ms（默认: 200）
 *   --format, -f      图片格式: png（默认）| jpeg
 *   --quality, -q     JPEG 质量 1-100（默认: 90）
 *   --no-lazy          跳过懒加载滚动
 *   --keep-fixed       保留 fixed/sticky 元素（不隐藏）
 *   --timeout          页面加载超时 ms（默认: 60000）
 *   --cookie           Cookie 字符串（格式: name=value; name2=value2）
 *   --header           自定义请求头（格式: Key:Value，可多次使用）
 *   --auth             HTTP Basic Auth（格式: username:password）
 *   --dark             使用暗色主题
 *   --locale           语言区域（默认: zh-CN）
 *   --help, -h        显示帮助
 *   --json             以 JSON 格式输出结果（静默模式，适合被其他程序调用）
 *   --skip-font-check  跳过中文字体检测（Linux 云服务器）
 *   --install-fonts    仅安装中文字体后退出（Linux 云服务器）
 */

const path = require('path');
const fs = require('fs');

// 智能加载 playwright：先尝试当前 node_modules，再尝试 cwd 下的 node_modules
let chromium;
try {
  ({ chromium } = require('playwright'));
} catch {
  const cwdPlaywright = path.join(process.cwd(), 'node_modules', 'playwright');
  if (fs.existsSync(cwdPlaywright)) {
    ({ chromium } = require(cwdPlaywright));
  } else {
    console.error('错误: 找不到 playwright 模块。请在工作目录中运行: npm install playwright');
    process.exit(1);
  }
}

// ===== 中文字体检测与安装（Linux 云服务器）=====
const { execSync, spawnSync } = require('child_process');
const os = require('os');

function checkChineseFonts(log) {
  // 仅在 Linux 上执行检测
  if (os.platform() !== 'linux') return true;

  try {
    const result = execSync('fc-list :lang=zh 2>/dev/null', { encoding: 'utf-8', timeout: 5000 });
    const fontCount = result.trim().split('\n').filter(l => l.trim()).length;
    if (fontCount > 0) {
      log.info(`  ✅ 检测到 ${fontCount} 个中文字体`);
      return true;
    }
  } catch {
    // fc-list 不存在或执行失败
  }

  log.warn('  ⚠️  未检测到中文字体，截图中的中文可能显示为空白或乱码');
  return false;
}

function detectPackageManager() {
  const managers = [
    { cmd: 'apt-get', type: 'apt' },
    { cmd: 'dnf', type: 'dnf' },
    { cmd: 'yum', type: 'yum' },
    { cmd: 'apk', type: 'apk' },
    { cmd: 'pacman', type: 'pacman' },
    { cmd: 'zypper', type: 'zypper' },
  ];
  for (const m of managers) {
    try {
      execSync(`which ${m.cmd} 2>/dev/null`, { encoding: 'utf-8', timeout: 3000 });
      return m.type;
    } catch { /* continue */ }
  }
  return null;
}

function canSudo() {
  try {
    // 检查是否为 root
    const uid = execSync('id -u', { encoding: 'utf-8', timeout: 3000 }).trim();
    if (uid === '0') return 'root';
    // 检查 sudo 是否可无密码执行
    const result = spawnSync('sudo', ['-n', 'true'], { timeout: 5000, stdio: 'pipe' });
    if (result.status === 0) return 'sudo';
    return null;
  } catch {
    return null;
  }
}

function installChineseFonts(log) {
  if (os.platform() !== 'linux') return false;

  const pkgMgr = detectPackageManager();
  if (!pkgMgr) {
    log.warn('  ❌ 无法识别包管理器，请手动安装中文字体');
    log.warn('     推荐安装: fonts-noto-cjk 或 wqy-zenhei');
    return false;
  }

  const sudoMode = canSudo();
  if (!sudoMode) {
    log.warn('  ❌ 无 root/sudo 权限，无法自动安装字体');
    log.warn('     请手动执行以下命令安装中文字体:');
    printManualInstallCmd(log, pkgMgr);
    return false;
  }

  const sudo = sudoMode === 'root' ? '' : 'sudo ';
  log.info(`  📦 正在自动安装中文字体 (${pkgMgr})...`);

  const installCmds = {
    apt: [
      `${sudo}apt-get update -qq`,
      `${sudo}apt-get install -y -qq fonts-noto-cjk fontconfig`,
    ],
    dnf: [
      `${sudo}dnf install -y -q google-noto-sans-cjk-sc-fonts fontconfig`,
    ],
    yum: [
      `${sudo}yum install -y -q google-noto-sans-cjk-sc-fonts wqy-zenhei-fonts fontconfig`,
    ],
    apk: [
      `${sudo}apk add --no-cache font-noto-cjk fontconfig`,
    ],
    pacman: [
      `${sudo}pacman -S --noconfirm noto-fonts-cjk fontconfig`,
    ],
    zypper: [
      `${sudo}zypper install -y -n google-noto-sans-cjk-fonts fontconfig`,
    ],
  };

  const cmds = installCmds[pkgMgr];
  if (!cmds) {
    log.warn(`  ❌ 不支持的包管理器: ${pkgMgr}`);
    return false;
  }

  try {
    for (const cmd of cmds) {
      log.info(`  > ${cmd}`);
      execSync(cmd, { encoding: 'utf-8', timeout: 120000, stdio: ['pipe', 'pipe', 'pipe'] });
    }
    // 刷新字体缓存
    try {
      execSync(`${sudo}fc-cache -f`, { encoding: 'utf-8', timeout: 30000, stdio: 'pipe' });
    } catch { /* fc-cache 失败不影响使用 */ }

    // 验证安装结果
    try {
      const result = execSync('fc-list :lang=zh 2>/dev/null', { encoding: 'utf-8', timeout: 5000 });
      const fontCount = result.trim().split('\n').filter(l => l.trim()).length;
      if (fontCount > 0) {
        log.info(`  ✅ 中文字体安装成功！检测到 ${fontCount} 个字体`);
        return true;
      }
    } catch { /* ignore */ }

    log.warn('  ⚠️  字体包已安装但未检测到中文字体，可能需要手动验证');
    return true; // 乐观处理，包安装成功通常就可以用了
  } catch (err) {
    log.warn(`  ❌ 字体安装失败: ${err.message}`);
    log.warn('     请手动执行以下命令:');
    printManualInstallCmd(log, pkgMgr);
    return false;
  }
}

function printManualInstallCmd(log, pkgMgr) {
  const cmds = {
    apt: 'sudo apt-get update && sudo apt-get install -y fonts-noto-cjk fontconfig && fc-cache -fv',
    dnf: 'sudo dnf install -y google-noto-sans-cjk-sc-fonts fontconfig && fc-cache -fv',
    yum: 'sudo yum install -y google-noto-sans-cjk-sc-fonts wqy-zenhei-fonts fontconfig && fc-cache -fv',
    apk: 'apk add --no-cache font-noto-cjk fontconfig && fc-cache -fv',
    pacman: 'sudo pacman -S --noconfirm noto-fonts-cjk fontconfig && fc-cache -fv',
    zypper: 'sudo zypper install -y google-noto-sans-cjk-fonts fontconfig && fc-cache -fv',
  };
  log.warn(`     ${cmds[pkgMgr] || '请安装 fonts-noto-cjk 或 wqy-zenhei 字体包'}`);
}

/**
 * 确保中文字体可用。检测 → 安装 → 验证，全自动流程。
 * @param {object} log - 日志工具
 * @param {boolean} skipFontCheck - 是否跳过字体检测
 * @returns {boolean} 字体是否可用
 */
function ensureChineseFonts(log, skipFontCheck) {
  if (os.platform() !== 'linux') return true;
  if (skipFontCheck) {
    log.info('  ⏭️  跳过字体检测 (--skip-font-check)');
    return true;
  }

  log.info('[0/5] 检测中文字体环境...');
  if (checkChineseFonts(log)) return true;

  // 尝试自动安装
  log.info('  🔧 尝试自动安装中文字体...');
  return installChineseFonts(log);
}

// ===== 参数解析 =====
function parseArgs(argv) {
  const args = argv.slice(2);
  const opts = {
    url: null,
    output: 'fullpage-screenshot.png',
    mode: 'fullpage',
    selector: null,
    width: null,
    height: null,
    device: 'auto',
    scale: null,
    wait: 3000,
    scrollWait: 200,
    format: 'png',
    quality: 90,
    noLazy: false,
    keepFixed: false,
    timeout: 60000,
    cookies: null,
    headers: {},
    auth: null,
    dark: false,
    locale: 'zh-CN',
    help: false,
    json: false,
    skipFontCheck: false,
    installFonts: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    const next = () => args[++i];

    if (arg === '--help' || arg === '-h') { opts.help = true; }
    else if (arg === '--output' || arg === '-o') { opts.output = next(); }
    else if (arg === '--mode' || arg === '-m') { opts.mode = next(); }
    else if (arg === '--selector' || arg === '-s') { opts.selector = next(); }
    else if (arg === '--width' || arg === '-w') { opts.width = parseInt(next(), 10); }
    else if (arg === '--height') { opts.height = parseInt(next(), 10); }
    else if (arg === '--device' || arg === '-d') { opts.device = next(); }
    else if (arg === '--scale') { opts.scale = parseFloat(next()); }
    else if (arg === '--wait') { opts.wait = parseInt(next(), 10); }
    else if (arg === '--scroll-wait') { opts.scrollWait = parseInt(next(), 10); }
    else if (arg === '--format' || arg === '-f') { opts.format = next(); }
    else if (arg === '--quality' || arg === '-q') { opts.quality = parseInt(next(), 10); }
    else if (arg === '--no-lazy') { opts.noLazy = true; }
    else if (arg === '--keep-fixed') { opts.keepFixed = true; }
    else if (arg === '--timeout') { opts.timeout = parseInt(next(), 10); }
    else if (arg === '--cookie') { opts.cookies = next(); }
    else if (arg === '--header') {
      const h = next();
      const idx = h.indexOf(':');
      if (idx > 0) opts.headers[h.substring(0, idx).trim()] = h.substring(idx + 1).trim();
    }
    else if (arg === '--auth') { opts.auth = next(); }
    else if (arg === '--dark') { opts.dark = true; }
    else if (arg === '--locale') { opts.locale = next(); }
    else if (arg === '--json') { opts.json = true; }
    else if (arg === '--skip-font-check') { opts.skipFontCheck = true; }
    else if (arg === '--install-fonts') { opts.installFonts = true; }
    else if (!arg.startsWith('-') && !opts.url) { opts.url = arg; }
  }

  return opts;
}

function showHelp() {
  console.log(`
网页完整截图工具 (full-page-screenshot)

用法:
  node screenshot.js <url> [options]

示例:
  node screenshot.js https://www.qq.com/
  node screenshot.js https://example.com -o result.png -m viewport
  node screenshot.js https://m.example.com -d iphone -o mobile.png
  node screenshot.js https://example.com -s ".main-content" -m element

选项:
  --output, -o     输出文件路径 (默认: fullpage-screenshot.png)
  --mode, -m       截图模式: fullpage | viewport | element (默认: fullpage)
  --selector, -s   CSS 选择器 (element 模式必填)
  --width, -w      视口宽度 (默认: 自动检测)
  --height         视口高度 (默认: 自动检测)
  --device, -d     设备: auto | desktop | iphone | ipad (默认: auto)
  --scale          设备像素比 (默认: 桌面=1, 移动端=3)
  --wait           加载后等待时间 ms (默认: 3000)
  --scroll-wait    滚动间隔 ms (默认: 200)
  --format, -f     格式: png | jpeg (默认: png)
  --quality, -q    JPEG 质量 1-100 (默认: 90)
  --no-lazy        跳过懒加载滚动
  --keep-fixed     保留 fixed/sticky 元素
  --timeout        页面加载超时 ms (默认: 60000)
  --cookie         Cookie 字符串
  --header         请求头 (格式: Key:Value, 可多次使用)
  --auth           HTTP Basic Auth (格式: user:pass)
  --dark           暗色主题
  --locale         语言区域 (默认: zh-CN)
  --json           JSON 格式输出
  --skip-font-check  跳过中文字体检测 (Linux)
  --install-fonts    仅安装中文字体后退出 (Linux)
  --help, -h       显示帮助
`);
}

// ===== 设备配置 =====
const DEVICE_PROFILES = {
  desktop: {
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 1,
    isMobile: false,
    hasTouch: false,
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
  },
  iphone: {
    viewport: { width: 390, height: 844 },
    deviceScaleFactor: 3,
    isMobile: true,
    hasTouch: true,
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
  },
  ipad: {
    viewport: { width: 820, height: 1180 },
    deviceScaleFactor: 2,
    isMobile: true,
    hasTouch: true,
    userAgent: 'Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
  },
};

// ===== 日志工具 =====
function createLog(jsonMode) {
  return {
    info: (...args) => { if (!jsonMode) console.log(...args); },
    warn: (...args) => { if (!jsonMode) console.warn(...args); },
    error: (...args) => console.error(...args),
  };
}

// ===== 核心截图流程 =====
async function takeScreenshot(opts) {
  const log = createLog(opts.json);
  const result = { url: opts.url, output: null, device: null, dimensions: null, fileSize: null };

  // === Phase 0: 中文字体环境检测（Linux 云服务器）===
  const fontsOk = ensureChineseFonts(log, opts.skipFontCheck);
  if (!fontsOk) {
    log.warn('  ⚠️  中文字体不可用，截图中的中文可能显示异常');
    log.warn('     继续执行截图，如需修复请使用 --install-fonts 或手动安装字体');
  }

  const browser = await chromium.launch({ headless: true });

  try {
    // === Phase 1: 探测页面类型 ===
    log.info(`[1/5] 正在探测页面类型: ${opts.url}`);

    let deviceProfile;
    if (opts.device !== 'auto') {
      deviceProfile = DEVICE_PROFILES[opts.device] || DEVICE_PROFILES.desktop;
      log.info(`  设备模式: ${opts.device}（手动指定）`);
    } else {
      // URL 模式检测（快速判断）
      const urlStr = opts.url.toLowerCase();
      const urlHints = /\/(m|mobile|wap|touch)\b/.test(urlStr) ||
        /^(m|mobile|wap)\./i.test(new URL(opts.url).hostname);

      // 用桌面 UA 探测页面
      const detectCtx = await browser.newContext({
        ...DEVICE_PROFILES.desktop,
        locale: opts.locale,
        colorScheme: opts.dark ? 'dark' : 'light',
      });
      const detectPage = await detectCtx.newPage();
      try {
        await detectPage.goto(opts.url, { waitUntil: 'domcontentloaded', timeout: opts.timeout });
        await detectPage.waitForTimeout(2000);

        const detection = await detectPage.evaluate(() => {
          const vp = document.querySelector('meta[name="viewport"]');
          const vpContent = vp ? vp.getAttribute('content') || '' : '';
          const hasMobileVP = vpContent.includes('width=device-width');
          // 移动端强信号：禁用用户缩放 + maximum-scale=1
          const hasScaleLock = vpContent.includes('user-scalable=no') ||
            /maximum-scale\s*=\s*1\b/.test(vpContent);
          const bodyWidth = document.body ? document.body.scrollWidth : window.innerWidth;

          // 检查 body 或根内容容器是否有 max-width 限制在移动端范围
          const bodyStyle = document.body ? window.getComputedStyle(document.body) : null;
          const maxWidth = bodyStyle ? parseInt(bodyStyle.maxWidth, 10) : NaN;
          const hasSmallMaxWidth = !isNaN(maxWidth) && maxWidth <= 768;

          // 检查主要内容区是否很窄
          const contentEl = document.querySelector('main, [role="main"], #app, #root, .container, .wrapper');
          let contentWidth = bodyWidth;
          if (contentEl) {
            const rect = contentEl.getBoundingClientRect();
            contentWidth = rect.width;
          }

          // 检查是否使用了 rem/vw 单位（移动端页面的典型特征）
          const htmlFontSize = parseInt(window.getComputedStyle(document.documentElement).fontSize, 10);
          const hasLargeRootFontSize = htmlFontSize > 50; // 移动端 rem 适配通常设置很大的根字号

          return {
            hasMobileViewport: hasMobileVP,
            hasScaleLock,
            bodyWidth,
            contentWidth,
            hasSmallMaxWidth,
            hasLargeRootFontSize,
            title: document.title,
          };
        });

        log.info(`  页面标题: ${detection.title}`);

        // 综合判断
        // 1. 页面渲染宽度 ≤ 480 → 一定是移动端
        // 2. URL 含 /m/ /mobile/ 等 + viewport meta → 移动端
        // 3. body max-width ≤ 768 → 移动端
        // 4. 内容区宽度 ≤ 500（在1440宽桌面下居中的窄页面）→ 移动端
        // 5. viewport 禁用缩放（user-scalable=no + maximum-scale=1）→ 移动端强信号
        // 6. 根字号 > 50px（rem 适配方案）→ 移动端
        const isMobile = detection.bodyWidth <= 480 ||
          detection.hasSmallMaxWidth ||
          (urlHints && detection.hasMobileViewport) ||
          (detection.contentWidth <= 500 && detection.hasMobileViewport) ||
          (detection.hasScaleLock && detection.hasMobileViewport) ||
          detection.hasLargeRootFontSize;

        log.info(`  检测结果: ${isMobile ? '移动端' : '桌面端'}${urlHints ? ' (URL 有移动端标识)' : ''}`);

        deviceProfile = isMobile ? DEVICE_PROFILES.iphone : DEVICE_PROFILES.desktop;
      } finally {
        await detectCtx.close();
      }
    }

    // 覆盖用户自定义参数
    if (opts.width) deviceProfile.viewport.width = opts.width;
    if (opts.height) deviceProfile.viewport.height = opts.height;
    if (opts.scale) deviceProfile.deviceScaleFactor = opts.scale;

    result.device = deviceProfile.isMobile ? 'mobile' : 'desktop';

    // === Phase 2: 配置并加载页面 ===
    log.info('[2/5] 正在配置浏览器并加载页面...');

    const contextOpts = {
      ...deviceProfile,
      locale: opts.locale,
      colorScheme: opts.dark ? 'dark' : 'light',
    };

    if (opts.auth) {
      const [username, password] = opts.auth.split(':');
      contextOpts.httpCredentials = { username, password };
    }

    if (Object.keys(opts.headers).length > 0) {
      contextOpts.extraHTTPHeaders = opts.headers;
    }

    const context = await browser.newContext(contextOpts);

    // 设置 cookies
    if (opts.cookies) {
      const urlObj = new URL(opts.url);
      const cookieList = opts.cookies.split(';').map(c => c.trim()).filter(Boolean).map(c => {
        const [name, ...rest] = c.split('=');
        return { name: name.trim(), value: rest.join('=').trim(), domain: urlObj.hostname, path: '/' };
      });
      await context.addCookies(cookieList);
    }

    const page = await context.newPage();
    await page.goto(opts.url, { waitUntil: 'networkidle', timeout: opts.timeout });
    await page.waitForTimeout(opts.wait);

    // === 截图模式分支 ===
    if (opts.mode === 'viewport') {
      // 仅截取当前视口
      log.info('[3/5] 视口模式 — 跳过滚动');
      log.info('[4/5] 视口模式 — 跳过容器展开');
      log.info(`[5/5] 正在截取视口截图 → ${opts.output}`);

      const screenshotOpts = { path: opts.output, type: opts.format };
      if (opts.format === 'jpeg') screenshotOpts.quality = opts.quality;
      await page.screenshot(screenshotOpts);

    } else if (opts.mode === 'element') {
      // 截取指定元素
      if (!opts.selector) throw new Error('element 模式需要通过 --selector 指定 CSS 选择器');

      log.info(`[3/5] 元素模式 — 等待元素: ${opts.selector}`);
      await page.waitForSelector(opts.selector, { timeout: 10000 });

      log.info('[4/5] 元素模式 — 跳过容器展开');
      log.info(`[5/5] 正在截取元素截图 → ${opts.output}`);

      const el = await page.$(opts.selector);
      const screenshotOpts = { path: opts.output, type: opts.format };
      if (opts.format === 'jpeg') screenshotOpts.quality = opts.quality;
      await el.screenshot(screenshotOpts);

    } else {
      // === fullpage 模式（默认）===

      // Phase 3: 检测页面结构 & 滚动加载
      log.info('[3/5] 正在检测页面结构并加载全部内容...');

      const pageInfo = await page.evaluate(() => {
        const bodyH = document.body ? document.body.scrollHeight : 0;
        const htmlH = document.documentElement.scrollHeight;
        const vpH = window.innerHeight;

        // 查找最大的内部滚动容器
        let maxScrollH = 0;
        let scrollInfo = null;
        for (const el of document.querySelectorAll('*')) {
          if (el.scrollHeight > el.clientHeight * 1.2) {
            const st = window.getComputedStyle(el);
            const ov = st.overflow + st.overflowY;
            if (ov.includes('auto') || ov.includes('scroll')) {
              if (el.scrollHeight > maxScrollH) {
                maxScrollH = el.scrollHeight;
                scrollInfo = {
                  tag: el.tagName,
                  id: el.id,
                  className: typeof el.className === 'string' ? el.className.substring(0, 120) : '',
                  scrollHeight: el.scrollHeight,
                  clientHeight: el.clientHeight,
                };
              }
            }
          }
        }
        return { bodyH, htmlH, vpH, scrollContainer: scrollInfo };
      });

      const hasInternalScroller = pageInfo.scrollContainer &&
        pageInfo.scrollContainer.scrollHeight > pageInfo.vpH * 1.2;

      if (hasInternalScroller) {
        log.info(`  内部滚动容器: <${pageInfo.scrollContainer.tag}> class="${pageInfo.scrollContainer.className}"`);
        log.info(`  容器高度: ${pageInfo.scrollContainer.scrollHeight}px (可视: ${pageInfo.scrollContainer.clientHeight}px)`);
      }

      // 滚动触发懒加载
      let contentHeight = 0;
      if (!opts.noLazy) {
        contentHeight = await page.evaluate(async ({ hasScroller, scrollWait }) => {
          // 找到滚动目标
          let target = null;
          if (hasScroller) {
            for (const el of document.querySelectorAll('*')) {
              if (el.scrollHeight > el.clientHeight * 1.2) {
                const st = window.getComputedStyle(el);
                const ov = st.overflow + st.overflowY;
                if (ov.includes('auto') || ov.includes('scroll')) {
                  target = el;
                  break;
                }
              }
            }
          }
          const t = target || document.documentElement;

          // 逐步滚动
          await new Promise(resolve => {
            let total = 0;
            const step = 300;
            const timer = setInterval(() => {
              const sh = t.scrollHeight;
              t.scrollBy(0, step);
              total += step;
              if (total >= sh + 500) { clearInterval(timer); resolve(); }
            }, scrollWait);
          });
          await new Promise(r => setTimeout(r, 2000));
          t.scrollTo(0, 0);
          return t.scrollHeight;
        }, { hasScroller: hasInternalScroller, scrollWait: opts.scrollWait });

        log.info(`  内容总高度: ${contentHeight}px`);
      }

      // Phase 4: 展开容器 & 处理悬浮元素
      log.info('[4/5] 正在展开容器并处理悬浮元素...');

      await page.evaluate(({ hasScroller, keepFixed }) => {
        if (hasScroller) {
          // 找到并展开滚动容器
          for (const el of document.querySelectorAll('*')) {
            if (el.scrollHeight > el.clientHeight * 1.2) {
              const st = window.getComputedStyle(el);
              const ov = st.overflow + st.overflowY;
              if (ov.includes('auto') || ov.includes('scroll')) {
                el.style.overflow = 'visible';
                el.style.height = 'auto';
                el.style.maxHeight = 'none';
                el.style.position = 'static';
                el.scrollTo(0, 0);

                // 展开所有祖先
                let p = el.parentElement;
                while (p) {
                  const ps = window.getComputedStyle(p);
                  if (ps.overflow !== 'visible' || ps.position === 'fixed' || ps.position === 'sticky') {
                    p.style.overflow = 'visible';
                    p.style.height = 'auto';
                    p.style.maxHeight = 'none';
                    if (ps.position === 'fixed' || ps.position === 'sticky') p.style.position = 'relative';
                  }
                  p = p.parentElement;
                }
                break; // 只处理最大的滚动容器
              }
            }
          }
        }

        // 处理 fixed/sticky 元素
        if (!keepFixed) {
          for (const el of document.querySelectorAll('*')) {
            const st = window.getComputedStyle(el);
            if (st.position === 'fixed' || st.position === 'sticky') {
              el.style.display = 'none';
            }
          }
        }

        // 确保 html/body 不限制滚动
        document.documentElement.style.overflow = 'visible';
        document.documentElement.style.height = 'auto';
        document.body.style.overflow = 'visible';
        document.body.style.height = 'auto';
        window.scrollTo(0, 0);
      }, { hasScroller: hasInternalScroller, keepFixed: opts.keepFixed });

      await page.waitForTimeout(1000);

      // 如果高度仍被锁定，调整视口
      const dims = await page.evaluate(() => ({
        w: document.documentElement.scrollWidth,
        h: document.documentElement.scrollHeight,
      }));

      if (hasInternalScroller && contentHeight > 0 && dims.h <= pageInfo.vpH) {
        log.info(`  高度锁定(${dims.h}px)，调整视口为 ${contentHeight + 100}px`);
        await page.setViewportSize({ width: deviceProfile.viewport.width, height: contentHeight + 100 });
        await page.waitForTimeout(1000);
      }

      // Phase 5: 截图
      log.info(`[5/5] 正在截取完整页面截图 → ${opts.output}`);

      const screenshotOpts = { path: opts.output, fullPage: true, type: opts.format };
      if (opts.format === 'jpeg') screenshotOpts.quality = opts.quality;
      await page.screenshot(screenshotOpts);
    }

    // 收集最终信息
    const finalDims = await page.evaluate(() => ({
      w: document.documentElement.scrollWidth,
      h: document.documentElement.scrollHeight,
    }));

    result.dimensions = { width: finalDims.w, height: finalDims.h };
    result.output = path.resolve(opts.output);

    const stat = fs.statSync(opts.output);
    result.fileSize = stat.size;
    const sizeStr = stat.size > 1024 * 1024
      ? `${(stat.size / 1024 / 1024).toFixed(1)} MB`
      : `${(stat.size / 1024).toFixed(0)} KB`;

    log.info('\n✅ 截图完成！');
    log.info(`  设备模式: ${result.device === 'mobile' ? '移动端' : '桌面端'}`);
    log.info(`  页面尺寸: ${finalDims.w} x ${finalDims.h}`);
    log.info(`  文件大小: ${sizeStr}`);
    log.info(`  保存路径: ${result.output}`);

    if (opts.json) {
      console.log(JSON.stringify(result, null, 2));
    }

    return result;

  } finally {
    await browser.close();
  }
}

// ===== 主入口 =====
const opts = parseArgs(process.argv);

if (opts.help) {
  showHelp();
  process.exit(0);
}

// --install-fonts 模式：仅安装字体后退出
if (opts.installFonts) {
  const log = createLog(opts.json);
  log.info('🔠 中文字体安装模式');
  if (os.platform() !== 'linux') {
    log.info('  当前系统非 Linux，无需安装字体');
    process.exit(0);
  }
  if (checkChineseFonts(log)) {
    log.info('  中文字体已存在，无需安装');
    process.exit(0);
  }
  const ok = installChineseFonts(log);
  process.exit(ok ? 0 : 1);
}

if (!opts.url) {
  console.error('错误: 请提供 URL 参数');
  console.error('用法: node screenshot.js <url> [options]');
  console.error('使用 --help 查看完整帮助');
  process.exit(1);
}

takeScreenshot(opts).catch(err => {
  if (opts.json) {
    console.log(JSON.stringify({ error: err.message }));
  } else {
    console.error(`\n❌ 截图失败: ${err.message}`);
  }
  process.exit(1);
});
