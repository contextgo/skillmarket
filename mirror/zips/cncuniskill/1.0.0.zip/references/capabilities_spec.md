# Capabilities 规范

每个 SKILL 的 `SKILL.md` 可包含 `capabilities` 列表，定义该技能提供的原子能力。

## 字段说明

- `name`: 能力名称（字符串，唯一标识）
- `description`: 自然语言描述，用于匹配
- `parameters`: 参数列表，每个参数含 `name`, `type`, `required`, `description`
- `output`: 输出描述
- `invoke`: 调用方式，支持：
  - `type: python_function` + `module` + `function`
  - `type: cli` + `command`（支持 `{param_name}` 占位符）
- `example`: 示例参数 JSON

## 示例

```yaml
capabilities:
  - name: make_punched_plate
    description: 生成矩形打孔板（法兰）STEP 文件
    parameters:
      - name: w
        type: float
        required: true
      - name: h
        type: float
        required: true
      - name: thickness
        type: float
        required: true
      - name: hole_rs
        type: list[float]
        required: true
      - name: spacing
        type: list[float]
        required: true
    output: STEP 文件路径
    invoke:
      type: python_function
      module: "step_occ"
      function: "make_punched_plate"
    example: '{"w":120,"h":80,"thickness":10,"hole_rs":[8],"spacing":[60,40]}'
```
