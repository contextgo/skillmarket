#!/usr/bin/env python3
"""
Orchestrator - 技能编排器
- 扫描 ~/.openclaw/skills/*/SKILL.md，解析 capabilities 块
- 建立能力注册表（能力名 → 调用方式、参数）
- 提供任务分解 + 确定性匹配 + 执行
- 支持预定义工作流（YAML）
"""

import asyncio
import json
import re
import yaml
import os
import sys
import subprocess
import importlib.util
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from functools import lru_cache

# 异步HTTP（用于调用LLM）
import aiohttp

# 配置
OPENCLAW_SKILLS_DIR = Path(os.environ.get("OPENCLAW_SKILLS_DIR", Path.home() / ".openclaw/skills"))
ORCHESTRATOR_DIR = Path(__file__).parent.parent
WORKFLOWS_DIR = ORCHESTRATOR_DIR / "workflows"
LOG_LEVEL = os.environ.get("ORCHESTRATOR_LOG_LEVEL", "INFO")
MAX_RETRIES = 3

# 日志
import logging
logging.basicConfig(level=getattr(logging, LOG_LEVEL), format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("orchestrator")

# ========== 数据结构 ==========
@dataclass
class Capability:
    skill_name: str
    capability_name: str
    description: str
    parameters: List[Dict]
    output: str
    invoke: Dict
    example: Optional[str] = None

@dataclass
class SubTask:
    id: str
    capability: Capability
    params: Dict
    depends_on: List[str] = field(default_factory=list)

@dataclass
class ExecutionPlan:
    tasks: List[SubTask]
    order: List[str]

# ========== 能力注册表（自动扫描） ==========
class CapabilityRegistry:
    def __init__(self):
        self.registry: Dict[str, Capability] = {}
        self.keyword_index: Dict[str, List[str]] = {}
        self.skill_names: Dict[str, str] = {}  # skill_name → skill_dir
        self.skill_descriptions: Dict[str, str] = {}  # skill_name → description

    def scan(self) -> None:
        """扫描所有 SKILL 目录，解析 capabilities"""
        if not OPENCLAW_SKILLS_DIR.exists():
            logger.warning(f"Skills目录不存在: {OPENCLAW_SKILLS_DIR}")
            return
        for skill_dir in OPENCLAW_SKILLS_DIR.iterdir():
            if not skill_dir.is_dir():
                continue
            skill_md = skill_dir / "SKILL.md"
            if not skill_md.exists():
                continue
            self._parse_skill_md(skill_dir.name, skill_md, skill_dir)
        logger.info(f"注册了 {len(self.registry)} 个能力，{len(self.skill_names)} 个SKILL")
        self._build_keyword_index()

    def _parse_skill_md(self, skill_name: str, path: Path, skill_dir: Path) -> None:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 记录 SKILL 名称和路径
        self.skill_names[skill_name] = str(skill_dir)
        
        # 提取 SKILL description（用于整体匹配）
        desc_match = re.search(r'^description:\s*(.+)$', content, re.MULTILINE)
        if desc_match:
            self.skill_descriptions[skill_name] = desc_match.group(1).strip()
        
        # 方法1: frontmatter (--- 包裹的 YAML)
        frontmatter_match = re.search(r'^---\n(.*?)\n---', content, re.DOTALL)
        if frontmatter_match:
            try:
                meta = yaml.safe_load(frontmatter_match.group(1))
                capabilities = meta.get('capabilities', [])
                self._register_capabilities(skill_name, capabilities)
                return
            except Exception as e:
                logger.debug(f"解析 frontmatter 失败: {e}")
        
        # 方法2: capabilities 代码块 (```yaml ... ```)
        yaml_blocks = re.findall(r'```(?:yaml)?\s*(capabilities:\s*.*?)```', content, re.DOTALL)
        for block in yaml_blocks:
            try:
                data = yaml.safe_load(block)
                if data and 'capabilities' in data:
                    self._register_capabilities(skill_name, data['capabilities'])
                    return
            except Exception as e:
                logger.debug(f"解析 yaml 代码块失败: {e}")

    def _register_capabilities(self, skill_name: str, capabilities: List[Dict]) -> None:
        for cap in capabilities:
            if not isinstance(cap, dict):
                continue
            cap_obj = Capability(
                skill_name=skill_name,
                capability_name=cap.get('name'),
                description=cap.get('description', ''),
                parameters=cap.get('parameters', []),
                output=cap.get('output', ''),
                invoke=cap.get('invoke', {}),
                example=cap.get('example')
            )
            key = f"{skill_name}.{cap_obj.capability_name}"
            self.registry[key] = cap_obj

    def _build_keyword_index(self) -> None:
        """从 description 中提取关键词"""
        for key, cap in self.registry.items():
            # 提取中文词（每个汉字）+ 英文词
            words = set(re.findall(r'[\u4e00-\u9fa5]', cap.description.lower()))
            english_words = re.findall(r'[a-zA-Z]+', cap.description.lower())
            words.update([w for w in english_words if len(w) >= 2])
            for w in words:
                if w:  # 确保非空
                    self.keyword_index.setdefault(w, []).append(key)

    def match(self, query: str, top_k: int = 3) -> List[Tuple[str, float]]:
        """匹配能力：字符级匹配 + 子串包含匹配"""
        query_lower = query.lower()
        
        # 提取中文单字 + 英文词
        keywords = set(re.findall(r'[\u4e00-\u9fa5]', query_lower))
        english_words = re.findall(r'[a-zA-Z]+', query_lower)
        keywords.update([w for w in english_words if len(w) >= 2])
        
        # 提取中文多字词（2-4字）
        chinese_phrases = re.findall(r'[\u4e00-\u9fff]{2,4}', query_lower)
        keywords.update(chinese_phrases)
        
        candidates = set()
        for kw in keywords:
            if kw in self.keyword_index:
                candidates.update(self.keyword_index[kw])
        
        # 子串包含匹配
        for key, cap in self.registry.items():
            cap_desc_lower = cap.description.lower()
            cap_name_lower = cap.capability_name.lower()
            for kw in keywords:
                if len(kw) >= 2 and (kw in cap_desc_lower or kw in cap_name_lower):
                    candidates.add(key)
        
        if not candidates:
            candidates = set(self.registry.keys())
        
        scores = []
        for key in candidates:
            cap = self.registry[key]
            cap_desc_lower = cap.description.lower()
            cap_name_lower = cap.capability_name.lower()
            
            # 计算得分：单字命中 * 0.1 + 多字词命中 * 0.5 + 英文词命中 * 0.3
            score = 0.0
            for kw in keywords:
                if kw in cap_desc_lower or kw in cap_name_lower:
                    if len(kw) == 1:
                        score += 0.1
                    else:
                        score += 0.5
            
            scores.append((key, score))
        
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]

    def match_skill_name(self, query: str) -> Optional[str]:
        """从查询中匹配 SKILL 名称（整体调用）"""
        query_lower = query.lower()
        
        # 提取关键词
        keywords = set(re.findall(r'[\u4e00-\u9fa5]', query_lower))
        english_words = re.findall(r'[a-zA-Z]+', query_lower)
        keywords.update([w for w in english_words if len(w) >= 2])
        chinese_phrases = re.findall(r'[\u4e00-\u9fff]{2,4}', query_lower)
        keywords.update(chinese_phrases)
        
        # 直接包含匹配
        for skill_name in self.skill_names.keys():
            skill_name_lower = skill_name.lower().replace('-', '').replace('_', '')
            query_processed = query_lower.replace('-', '').replace('_', '')
            if skill_name_lower in query_processed or query_processed in skill_name_lower:
                return skill_name
        
        # 描述包含匹配
        for skill_name, desc in self.skill_descriptions.items():
            desc_lower = desc.lower()
            for kw in keywords:
                if kw in desc_lower:
                    return skill_name
        
        return None

# ========== 任务分解（使用本地 LLM） ==========
class TaskDecomposer:
    def __init__(self, ollama_url: str = "http://localhost:11434", model: str = "llama3.2:3b"):
        self.ollama_url = ollama_url
        self.model = model

    async def decompose(self, request: str, registry: CapabilityRegistry, max_retries: int = 3) -> List[Dict]:
        """调用 LLM 将请求分解为子任务列表"""
        for attempt in range(max_retries):
            caps_summary = "\n".join([f"- {key}: {cap.description[:100]}" for key, cap in registry.registry.items()])
            prompt = f"""任务分解专家。给定以下能力和请求，输出JSON数组。

能力：
{caps_summary}

请求：{request}

重要：只输出JSON数组格式，例如：
[{{"id":"1","expected_capability":"step-factory.make_punched_plate","params":{{}}}}]

不要输出任何其他文字，只输出JSON。
"""
            try:
                async with aiohttp.ClientSession() as session:
                    payload = {
                        "model": self.model,
                        "prompt": prompt,
                        "stream": False,
                        "format": "json",
                        "options": {"temperature": 0.2}
                    }
                    async with session.post(f"{self.ollama_url}/api/generate", json=payload, timeout=60) as resp:
                        data = await resp.json()
                        response = data.get("response", "[]")
                        json_match = re.search(r'\[.*\]|\{.*\}', response, re.DOTALL)
                        if json_match:
                            tasks = json.loads(json_match.group())
                            # 确保返回列表
                            if isinstance(tasks, dict):
                                return [tasks]
                            elif isinstance(tasks, list) and len(tasks) > 0:
                                return tasks
                        # 空结果，重试
                        logger.warning(f"空分解结果 (尝试 {attempt+1}/{max_retries})")
                        if attempt < max_retries - 1:
                            await asyncio.sleep(1)
                            continue
                        return []
                return []
            except Exception as e:
                logger.error(f"任务分解失败 (尝试 {attempt+1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(1)
                    continue
                return []

    async def extract_params(self, description: str, capability: Capability) -> Dict:
        """使用 LLM 从自然语言中提取参数"""
        param_spec = ", ".join([f"{p['name']}({p.get('type','any')})" for p in capability.parameters])
        prompt = f"""从以下描述中提取参数。

描述：{description}

参数规格：{param_spec}

输出JSON对象，键为参数名，值为参数值。只输出JSON。
"""
        async with aiohttp.ClientSession() as session:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "format": "json",
                "options": {"temperature": 0.1}
            }
            try:
                async with session.post(f"{self.ollama_url}/api/generate", json=payload, timeout=30) as resp:
                    data = await resp.json()
                    response = data.get("response", "{}")
                    json_match = re.search(r'\{.*\}', response, re.DOTALL)
                    if json_match:
                        return json.loads(json_match.group())
                    return {}
            except Exception as e:
                logger.error(f"参数提取失败: {e}")
                return {}

# ========== 执行计划生成 ==========
class PlanGenerator:
    def __init__(self, registry: CapabilityRegistry, decomposer: TaskDecomposer):
        self.registry = registry
        self.decomposer = decomposer
        self.ollama_url = decomposer.ollama_url
        self.model = decomposer.model

    async def generate_plan(self, decomposed_tasks: List[Dict], user_request: str = "") -> ExecutionPlan:
        """将分解后的任务转换为可执行的 SubTask 列表（异步）"""
        subtasks = []
        for task in decomposed_tasks:
            # 处理 {"task1": {...}} 格式
            if not isinstance(task, dict):
                continue
            if 'expected_capability' not in task and len(task) == 1:
                # 可能是 {"task1": {...}} 格式
                task_id = list(task.keys())[0]
                task_data = task[task_id]
                if isinstance(task_data, dict):
                    task_data['id'] = task_id
                    task = task_data
            
            cap_key = task.get("expected_capability")
            capability = None
            
            if cap_key and cap_key in self.registry.registry:
                capability = self.registry.registry[cap_key]
                # 如果匹配到 orchestrator.orchestrate 但参数没有 'request'，尝试 fallback
                if cap_key == "orchestrator.orchestrate" and 'request' not in task.get('params', {}):
                    # 尝试匹配 skill name（从 description 或 params 中提取）
                    search_text = task.get("description", "")
                    if not search_text:
                        # 尝试从 params 中提取
                        for v in task.get("params", {}).values():
                            if isinstance(v, str) and len(v) > 2:
                                search_text = v
                                break
                    skill_name = self.registry.match_skill_name(search_text) if search_text else None
                    if skill_name:
                        # 使用 skill name fallback
                        cap_key = f"{skill_name}._whole_skill"
                        skill_dir = Path(self.registry.skill_names[skill_name])
                        default_cmd = self._find_default_entry(skill_dir, skill_name)
                        capability = Capability(
                            skill_name=skill_name,
                            capability_name="_whole_skill",
                            description=f"整体调用 {skill_name} SKILL",
                            parameters=[],
                            output="SKILL 执行输出",
                            invoke={"type": "cli", "command": default_cmd}
                        )
                        self.registry.registry[cap_key] = capability
            else:
                # 先尝试匹配能力
                matches = self.registry.match(task.get("description", ""), top_k=1)
                if matches and matches[0][1] > 0:
                    cap_key = matches[0][0]
                    capability = self.registry.registry.get(cap_key)
                
                # fallback: 尝试匹配 SKILL 名称（整体调用）
                if not capability:
                    skill_name = self.registry.match_skill_name(task.get("description", ""))
                    if skill_name:
                        cap_key = f"{skill_name}._whole_skill"
                        # 动态创建整体调用的 Capability
                        skill_dir = Path(self.registry.skill_names[skill_name])
                        
                        # 查找默认入口脚本
                        default_cmd = self._find_default_entry(skill_dir, skill_name)
                        
                        capability = Capability(
                            skill_name=skill_name,
                            capability_name="_whole_skill",
                            description=f"整体调用 {skill_name} SKILL",
                            parameters=[],
                            output="SKILL 执行输出",
                            invoke={
                                "type": "cli",
                                "command": default_cmd
                            }
                        )
                        self.registry.registry[cap_key] = capability
            
            if not capability:
                logger.warning(f"无法为任务 {task.get('id')} 匹配到能力或SKILL")
                continue
            
            params = task.get("params", {})
            # 保存原始请求到参数中供后续使用
            if user_request:
                params['_user_request'] = user_request
            subtask = SubTask(
                id=task.get("id", f"task_{len(subtasks)}"),
                capability=capability,
                params=params,
                depends_on=task.get("depends_on", [])
            )
            subtasks.append(subtask)
        order = self._topological_sort(subtasks)
        return ExecutionPlan(tasks=subtasks, order=order)

    async def _extract_params_with_llm(self, description: str, capability: Capability, existing_params: Dict = None) -> Dict:
        """使用 LLM 从自然语言中提取参数"""
        param_spec = []
        for p in capability.parameters:
            param_spec.append(f"- {p['name']} ({p.get('type','any')}, required={p.get('required', True)}): {p.get('description', '')}")
        param_desc = "\n".join(param_spec)
        
        prompt = f"""从以下用户请求中提取参数，以 JSON 格式返回。

用户请求：{description}

已有参数（可能不完整，需要补充完整）：
{str(existing_params) if existing_params else "{}"}

需要提取的参数（严格按照以下名称和类型）：
{param_desc}

输出示例：{{"material": "6061-T6", "surface": "阳极氧化黑", "quantity": 10}}
只输出 JSON，不要解释。
注意：必须包含所有参数，part_name 如果没有明确给出，请根据用户请求推断（如"法兰"）。
"""
        try:
            async with aiohttp.ClientSession() as session:
                payload = {
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "format": "json",
                    "options": {"temperature": 0.1}
                }
                async with session.post(f"{self.ollama_url}/api/generate", json=payload, timeout=30) as resp:
                    data = await resp.json()
                    response = data.get("response", "{}")
                    json_match = re.search(r'\{.*\}', response, re.DOTALL)
                    if json_match:
                        return json.loads(json_match.group())
        except Exception as e:
            logger.error(f"LLM 参数提取失败: {e}")
        return {{}}

    def _find_default_entry(self, skill_dir: Path, skill_name: str) -> str:
        """查找 SKILL 的默认入口脚本"""
        # 优先查找 scripts 目录下的 Python 文件
        scripts_dir = skill_dir / "scripts"
        if scripts_dir.exists():
            # 优先找 main.py 或 run.py
            for name in ["main.py", "run.py", "start.py"]:
                path = scripts_dir / name
                if path.exists():
                    return f"python3 {path}"
            # 否则找与 skill 名相关的文件
            for path in scripts_dir.glob("*.py"):
                if skill_name.replace('-', '_') in path.stem.lower() or path.stem.lower() in skill_name.replace('-', '_'):
                    return f"python3 {path}"
            # 返回找到的第一个 .py 文件
            py_files = list(scripts_dir.glob("*.py"))
            if py_files:
                return f"python3 {py_files[0]}"
        
        # 查找根目录下的文件
        for name in ["main.py", "run.py", "start.py", f"{skill_name.replace('-', '_')}.py"]:
            path = skill_dir / name
            if path.exists():
                return f"python3 {path}"
        
        # 默认返回 SKILL 目录
        return f"echo 'SKILL {skill_name} 无默认入口' && false"

    async def infer_params(self, description: str, capability: Capability) -> Dict:
        """从自然语言中推断参数（LLM增强版）"""
        # 先尝试 LLM 提取
        params = await self.decomposer.extract_params(description, capability)
        if params:
            return params
        # 降级：简单数字提取
        params = {}
        numbers = re.findall(r'(\d+(?:\.\d+)?)', description)
        for i, param_def in enumerate(capability.parameters):
            if i < len(numbers):
                param_name = param_def.get('name')
                param_type = param_def.get('type', 'float')
                try:
                    if 'int' in param_type:
                        params[param_name] = int(float(numbers[i]))
                    elif 'list' in param_type:
                        # 尝试提取列表如 [8]
                        list_match = re.search(r'\[([^\]]+)\]', description)
                        if list_match:
                            vals = list_match.group(1).split(',')
                            params[param_name] = [float(v.strip()) for v in vals]
                        else:
                            params[param_name] = float(numbers[i])
                    else:
                        params[param_name] = float(numbers[i])
                except:
                    pass
        return params

    def _topological_sort(self, subtasks: List[SubTask]) -> List[str]:
        """简单拓扑排序"""
        graph = {t.id: t.depends_on for t in subtasks}
        in_degree = {t.id: 0 for t in subtasks}
        for t in subtasks:
            for dep in t.depends_on:
                if dep in in_degree:
                    in_degree[t.id] += 1
        queue = [tid for tid, deg in in_degree.items() if deg == 0]
        order = []
        while queue:
            tid = queue.pop(0)
            order.append(tid)
            for t in subtasks:
                if tid in t.depends_on:
                    in_degree[t.id] -= 1
                    if in_degree[t.id] == 0:
                        queue.append(t.id)
        return order

# ========== 执行器（带重试） ==========
class Executor:
    async def execute(self, subtask: SubTask) -> Any:
        """根据 invoke 类型执行能力，带重试"""
        invoke = subtask.capability.invoke
        invoke_type = invoke.get('type')
        
        last_error = None
        for attempt in range(MAX_RETRIES):
            try:
                if invoke_type == 'python_function':
                    return await self._exec_python_function(subtask)
                elif invoke_type == 'cli':
                    return await self._exec_cli(subtask)
                else:
                    raise ValueError(f"不支持的调用类型: {invoke_type}")
            except Exception as e:
                last_error = e
                if attempt < MAX_RETRIES - 1:
                    logger.warning(f"执行失败 (尝试 {attempt+1}/{MAX_RETRIES}): {e}")
                    await asyncio.sleep(1)  # 等待后重试
                continue
        
        raise last_error or RuntimeError(f"执行失败，已重试 {MAX_RETRIES} 次")

    async def _exec_python_function(self, subtask: SubTask) -> Any:
        """动态导入模块并调用函数 - 修复路径问题"""
        invoke = subtask.capability.invoke
        module_path = invoke.get('module', '')
        function_name = invoke.get('function', '')
        
        if not module_path or not function_name:
            raise ValueError("python_function 需要 module 和 function 字段")
        
        skill_dir = OPENCLAW_SKILLS_DIR / subtask.capability.skill_name
        if not skill_dir.exists():
            raise FileNotFoundError(f"技能目录不存在: {skill_dir}")
        
        # module_path 格式: "scripts.step_occ" 或 "step_occ"
        # 相对于 scripts/ 目录
        if '.' in module_path:
            # "scripts.step_occ" -> scripts/step_occ.py
            parts = module_path.split('.')
            if parts[0] == 'scripts':
                module_file = skill_dir / '/'.join(parts) + '.py'
            else:
                module_file = skill_dir / 'scripts' / f"{parts[-1]}.py"
        else:
            # 直接文件名 -> scripts/{module}.py
            module_file = skill_dir / 'scripts' / f"{module_path}.py"
        
        logger.info(f"加载模块: {module_file}")
        
        if not module_file.exists():
            raise FileNotFoundError(f"模块文件不存在: {module_file}")
        
        sys.path.insert(0, str(skill_dir / 'scripts'))
        try:
            spec = importlib.util.spec_from_file_location(module_path, module_file)
            if not spec:
                raise ImportError(f"无法加载模块 {module_path}")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            func = getattr(module, function_name, None)
            if not func:
                raise AttributeError(f"模块 {module_path} 中没有函数 {function_name}")
            result = func(**subtask.params)
            if asyncio.iscoroutine(result):
                result = await result
            return result
        except Exception as e:
            logger.error(f"执行 Python 函数失败: {e}")
            raise
        finally:
            path_to_remove = str(skill_dir / 'scripts')
            if path_to_remove in sys.path:
                sys.path.remove(path_to_remove)

    async def _exec_cli(self, subtask: SubTask) -> Any:
        """执行命令行"""
        invoke = subtask.capability.invoke
        command_template = invoke.get('command', '')
        
        if not command_template:
            raise ValueError("cli 需要 command 字段")
        
        # 标准化参数名（处理 LLM 返回的不完全匹配名称）
        params = dict(subtask.params)  # 复制
        param_aliases = {
            'surface': ['surface Finish', 'surface finish', 'Surface', 'finish'],
            'material': ['material', 'Material', 'MATERIAL'],
            'quantity': ['quantity', 'Quantity', 'num', 'count'],
            'part_name': ['part_name', 'partname', 'name', 'PartName']
        }
        for key, aliases in param_aliases.items():
            if key not in params:
                for alias in aliases:
                    if alias in params:
                        params[key] = params[alias]
                        break
                    # 模糊匹配
                    for param_key in params:
                        if alias.lower() in param_key.lower():
                            params[key] = params[param_key]
                            break
        
        # 如果 part_name 缺失，尝试从描述中提取或使用默认值
        if 'part_name' not in params:
            # 从 description 中查找 "法兰"、"零件" 等关键词
            desc = subtask.capability.description or ""
            import re
            part_match = re.search(r'(法兰|零件|工件|板|轴|齿轮|螺栓|螺母|箱体|支架)', desc)
            if part_match:
                params['part_name'] = part_match.group(1)
            else:
                params['part_name'] = '零件'  # 默认值
        
        # 替换参数占位符
        command = command_template
        for k, v in params.items():
            if isinstance(v, list):
                v = ','.join(str(x) for x in v)
            elif isinstance(v, dict):
                v = json.dumps(v)
            # 处理 YAML 的 {{{param}}} 格式（3个花括号）
            threebrace = "{" * 3 + k + "}" * 3
            command = command.replace(threebrace, str(v))
            # 也处理普通 {param} 格式
            command = command.replace(f"{{{k}}}", str(v))
        
        logger.info(f"执行命令: {command[:100]}...")
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        stdout, stderr = await proc.communicate()
        
        if proc.returncode != 0:
            raise RuntimeError(f"命令执行失败: {stderr.decode()}")
        return stdout.decode().strip()

# ========== 工作流引擎 ==========
class WorkflowEngine:
    def __init__(self, registry: CapabilityRegistry):
        self.registry = registry
        self.workflows = self._load_workflows()

    def _load_workflows(self) -> Dict[str, Dict]:
        workflows = {}
        if not WORKFLOWS_DIR.exists():
            return workflows
        for yaml_file in WORKFLOWS_DIR.glob("*.yaml"):
            with open(yaml_file, 'r', encoding='utf-8') as f:
                try:
                    workflow = yaml.safe_load(f)
                    name = workflow.get('name', yaml_file.stem)
                    workflows[name] = workflow
                except Exception as e:
                    logger.error(f"加载工作流 {yaml_file} 失败: {e}")
        return workflows

    async def run_workflow(self, workflow_name: str, inputs: Dict) -> Dict:
        if workflow_name not in self.workflows:
            raise ValueError(f"工作流 {workflow_name} 未找到")
        workflow = self.workflows[workflow_name]
        steps = workflow.get('steps', [])
        subtasks = []
        step_results = {}
        
        for step in steps:
            step_id = step['id']
            skill_name = step['skill']
            cap_name = step['function']
            cap_key = f"{skill_name}.{cap_name}"
            if cap_key not in self.registry.registry:
                raise ValueError(f"能力 {cap_key} 不存在")
            capability = self.registry.registry[cap_key]
            params = step.get('inputs', {})
            params = self._resolve_variables(params, step_results, inputs)
            depends_on = step.get('depends_on', [])
            subtasks.append(SubTask(
                id=step_id,
                capability=capability,
                params=params,
                depends_on=depends_on
            ))
        
        executor = Executor()
        plan_gen = PlanGenerator(self.registry, TaskDecomposer())
        order = plan_gen._topological_sort(subtasks)
        
        results = {}
        for tid in order:
            subtask = next(t for t in subtasks if t.id == tid)
            for dep in subtask.depends_on:
                if dep not in results:
                    raise RuntimeError(f"依赖 {dep} 未完成")
            result = await executor.execute(subtask)
            results[tid] = result
            step_results[tid] = result
        
        return results

    def _resolve_variables(self, params: Any, step_results: Dict, inputs: Dict) -> Any:
        """递归替换 {{...}} 变量，支持所有类型"""
        if isinstance(params, str):
            matches = re.findall(r'{{(.*?)}}', params)
            for match in matches:
                if match.startswith('inputs.'):
                    key = match.split('.', 1)[1]
                    value = inputs.get(key, '')
                else:
                    parts = match.split('.')
                    if len(parts) == 2:
                        step_id, field = parts
                        value = step_results.get(step_id, '')
                    else:
                        value = ''
                params = params.replace(f"{{{{{match}}}}}", str(value))
            return params
        elif isinstance(params, dict):
            return {k: self._resolve_variables(v, step_results, inputs) for k, v in params.items()}
        elif isinstance(params, list):
            return [self._resolve_variables(item, step_results, inputs) for item in params]
        else:
            return params

# ========== 主入口 ==========
class Orchestrator:
    def __init__(self):
        self.registry = CapabilityRegistry()
        self.registry.scan()
        self.decomposer = TaskDecomposer()
        self.plan_gen = PlanGenerator(self.registry, self.decomposer)
        self.executor = Executor()
        self.workflow_engine = WorkflowEngine(self.registry)

    async def run(self, request: str, workflow_name: Optional[str] = None) -> Any:
        if workflow_name:
            return await self.workflow_engine.run_workflow(workflow_name, {"request": request})
        
        tasks = await self.decomposer.decompose(request, self.registry)
        if not tasks:
            return {"error": "无法分解任务，请提供更明确的请求。"}
        
        plan = await self.plan_gen.generate_plan(tasks, user_request=request)
        
        # 推断缺失或不匹配的参数
        for subtask in plan.tasks:
            cap_params = {p['name']: p for p in subtask.capability.parameters}
            # 如果 params 为空或不包含所有必需参数名，则尝试映射或重新推断
            has_all_params = subtask.params and all(k in cap_params for k in subtask.params.keys())
            if not has_all_params and subtask.params:
                # 尝试映射 LLM 返回的参数名到 capability 参数名
                mapped = {}
                for llm_key, llm_val in subtask.params.items():
                    # 常见的参数名映射
                    if llm_key in ('w', 'width') and 'w' in cap_params:
                        mapped['w'] = llm_val
                    elif llm_key in ('h', 'height', 'length') and 'h' in cap_params:
                        mapped['h'] = llm_val
                    elif llm_key in ('thickness', 't', 'depth') and 'thickness' in cap_params:
                        mapped['thickness'] = llm_val
                    elif llm_key in ('hole_rs', 'hole_radius', 'hole_diameter') and 'hole_rs' in cap_params:
                        # hole_diameter -> hole_rs (半径 = 直径/2)
                        if isinstance(llm_val, (int, float)):
                            mapped['hole_rs'] = [llm_val / 2]
                        elif isinstance(llm_val, list):
                            mapped['hole_rs'] = [v/2 if isinstance(v, (int,float)) else v for v in llm_val]
                    elif llm_key in ('num_holes', 'hole_count', 'holes') and 'hole_rs' in cap_params:
                        # 孔数量 -> 生成等间距的孔
                        if isinstance(llm_val, int) and llm_val > 0:
                            # 默认间距
                            mapped['spacing'] = [40, 40]
                    elif llm_key in ('size', 'dimensions'):
                        # size: [w, h, t] 或 [w, h, thickness]
                        if isinstance(llm_val, list) and len(llm_val) >= 3:
                            mapped['w'] = llm_val[0]
                            mapped['h'] = llm_val[1]
                            mapped['thickness'] = llm_val[2]
                
                # 如果映射成功且覆盖了必需参数，使用映射结果
                if mapped and all(k in mapped for k in ['w', 'h', 'thickness']):
                    subtask.params = mapped
                    has_all_params = True
            
            # 如果仍未匹配，优先用 LLM 提取
            if not has_all_params:
                if subtask.capability.parameters:
                    # 使用 LLM 提取
                    # 使用 LLM 提取参数，传入用户原始请求和已有参数
                    user_request = subtask.params.get('_user_request', '') or subtask.capability.description
                    llm_params = await self.plan_gen._extract_params_with_llm(
                        user_request, 
                        subtask.capability,
                        existing_params=subtask.params
                    )
                    if llm_params:
                        subtask.params = llm_params
                        has_all_params = True
                
                # 如果 LLM 提取失败，使用简单推断
                if not has_all_params:
                    subtask.params = await self.plan_gen.infer_params(
                        user_request,
                        subtask.capability
                    )
        
        results = {}
        for tid in plan.order:
            subtask = next(t for t in plan.tasks if t.id == tid)
            try:
                result = await self.executor.execute(subtask)
                results[tid] = result
            except Exception as e:
                results[tid] = {"error": str(e)}
        
        return results

async def run_orchestrator(request: str, workflow_name: str = None) -> str:
    orch = Orchestrator()
    result = await orch.run(request, workflow_name)
    return json.dumps(result, indent=2, ensure_ascii=False)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Orchestrator - 技能编排器')
    parser.add_argument("--request", type=str, required=True, help="用户请求")
    parser.add_argument("--workflow", type=str, default=None, help="预定义工作流名称")
    args = parser.parse_args()
    result = asyncio.run(run_orchestrator(args.request, args.workflow))
    print(result)
