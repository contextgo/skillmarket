#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
每日总结 - 总结生成器
从 memory/ 目录读取当日对话，生成结构化总结
"""

import os
import re
import json
import glob
from datetime import datetime, timedelta
from typing import List, Dict, Any


class SummaryGenerator:
    """每日总结生成器"""

    def __init__(self, base_path=None):
        if base_path is None:
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.base_path = base_path

        # memory 目录路径
        self.memory_dir = os.path.expanduser('~/.openclaw/agents/assistant/workspace/memory')

    def _get_today_memory_files(self) -> List[str]:
        """获取今天的 memory 文件"""
        today = datetime.now().strftime('%Y-%m-%d')
        pattern = os.path.join(self.memory_dir, f'*{today}*.md')
        files = glob.glob(pattern)
        return sorted(files)

    def _read_memory_content(self, filepath: str) -> str:
        """读取 memory 文件内容"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            return f"[读取失败: {e}]"

    def _extract_conversations(self, content: str) -> List[str]:
        """从 memory 内容中提取对话片段"""
        # 按时间戳或分隔符分割
        # memory 文件通常有 ### 标题分段
        sections = re.split(r'\n###\s+', content)
        # 过滤空段落和太短的内容
        conversations = []
        for sec in sections:
            sec = sec.strip()
            if len(sec) > 50:  # 至少50字符才算有效内容
                conversations.append(sec[:500])  # 截取前500字符
        return conversations

    def _load_config(self) -> Dict:
        """加载用户配置"""
        config_path = os.path.join(self.base_path, 'data', 'config.json')
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def generate_summary(self) -> Dict[str, Any]:
        """
        生成每日总结
        
        Returns:
            {
                'date': str,
                'key_points': List[str],      # 关键信息
                'todos': List[Dict],          # 待办事项
                'potential_issues': List[str], # 潜在议题
                'raw_content': str            # 原始内容摘要
            }
        """
        today = datetime.now().strftime('%Y-%m-%d')
        files = self._get_today_memory_files()

        if not files:
            return {
                'date': today,
                'key_points': ['今日暂无对话记录'],
                'todos': [],
                'potential_issues': [],
                'raw_content': ''
            }

        # 读取所有 memory 文件
        all_content = []
        for f in files:
            content = self._read_memory_content(f)
            all_content.append(content)

        combined = '\n\n---\n\n'.join(all_content)

        # 提取关键信息（基于规则）
        key_points = self._extract_key_points(combined)
        todos = self._extract_todos(combined)
        potential_issues = self._extract_potential_issues(combined)

        return {
            'date': today,
            'key_points': key_points,
            'todos': todos,
            'potential_issues': potential_issues,
            'raw_content': combined[:2000]  # 保留前2000字符作为参考
        }

    def _extract_key_points(self, content: str) -> List[str]:
        """从内容中提取关键信息点"""
        points = []

        # 规则1: 识别完成/配置/创建类语句（排除代码片段）
        done_patterns = [
            r'(?:完成|搞定|搞定|做好)[了\s]*(.+?)[。！\n]',
            r'已[经\s]*(?:完成|配置|创建|设置|添加|启用|改造|初始化|更新|同步)(.+?)[。！\n]',
            r'(?:成功|顺利)(.+?)[。！\n]',
            r'(?:创建|新增|添加)[了\s]*(.+?)[。！\n]',
            r'(?:配置|设置)[好\s]*(.+?)[。！\n]',
            r'(?:改造|重构|优化)[完成\s]*(.+?)[。！\n]',
            r'(?:初始化|重置)[完成\s]*(.+?)[。！\n]',
        ]
        for pattern in done_patterns:
            matches = re.findall(pattern, content)
            for m in matches[:3]:
                m = m.strip()
                # 过滤掉代码片段、目录结构、标点符号开头
                if len(m) > 5 and len(m) < 100:
                    if not m.startswith(('`', '│', '├', '└', '-', '|', '#', '•')):
                        if not re.match(r'^[\s│├└─]+', m):
                            points.append(m)

        # 规则2: 识别 BMI/体重等健康数据变化
        health_patterns = [
            r'BMI[：:\s]*([\d.]+)\s*[(（](.+?)[)）]',
            r'体重[：:\s]*([\d.]+)\s*kg',
            r'身高[：:\s]*([\d.]+)\s*cm',
        ]
        for pattern in health_patterns:
            matches = re.findall(pattern, content)
            for m in matches:
                if isinstance(m, tuple):
                    points.append(f"健康数据: BMI {m[0]} ({m[1]})")
                else:
                    points.append(f"健康数据: {m}")

        # 规则3: 识别决策/结论性语句
        conclusion_patterns = [
            r'(?:决定|确定|选定|选择)[了\s]*(.+?)[。！\n]',
            r'(?:推荐|建议|采用|使用)[了\s]*(.+?)[。！\n]',
            r'(?:确认|核实)[了\s]*(.+?)[。！\n]',
        ]
        for pattern in conclusion_patterns:
            matches = re.findall(pattern, content)
            for m in matches[:2]:
                m = m.strip()
                if len(m) > 5 and len(m) < 100:
                    if not m.startswith(('`', '│', '├', '└', '-', '|')):
                        points.append(m)

        # 去重并限制数量
        seen = set()
        unique_points = []
        for p in points:
            key = p[:30]
            if key not in seen:
                seen.add(key)
                unique_points.append(p)

        return unique_points[:5]

    def _extract_todos(self, content: str) -> List[Dict]:
        """提取待办事项"""
        todos = []

        # 规则: 识别明确的待办/需要执行的事项
        todo_patterns = [
            r'(?:需要|要|记得|别忘了).{0,5}(.+?)[。！\n]',
            r'(?:后续|以后|下次|明天).{0,3}(.+?)[。！\n]',
            r'(?:验证|测试|检查|确认).{0,3}(.+?)[。！\n]',
            r'(?:排查|修复|解决|处理).{0,3}(.+?)[。！\n]',
        ]
        for pattern in todo_patterns:
            matches = re.findall(pattern, content)
            for m in matches:
                m = m.strip()
                # 过滤掉代码片段、疑问句
                if len(m) > 5 and len(m) < 80:
                    if not m.startswith(('`', '│', '├', '└', '-', '|', '是否', '怎么', '什么', '吗')):
                        if '?' not in m and '？' not in m:
                            # 判断优先级
                            priority = '中'
                            if any(w in m for w in ['明天', '今天', '立即', '马上', '今晚']):
                                priority = '高'
                            elif any(w in m for w in ['后续', '以后', '慢慢', '有空', '下周']):
                                priority = '低'

                            todos.append({
                                'content': m,
                                'priority': priority
                            })

        # 去重
        seen = set()
        unique_todos = []
        for t in todos:
            key = t['content'][:25]
            if key not in seen:
                seen.add(key)
                unique_todos.append(t)

        return unique_todos[:5]

    def _extract_potential_issues(self, content: str) -> List[str]:
        """提取潜在议题（未形成结论的讨论）"""
        issues = []

        # 规则: 识别疑问/考虑/讨论/问题等
        issue_patterns = [
            r'(?:是否|是不是|能不能|可以).{0,3}(.+?)[？?\n]',
            r'(?:考虑|思考|讨论).{0,3}(.+?)[。！\n]',
            r'(?:问题|疑问|困惑).{0,3}(.+?)[。！\n]',
            r'(?:暂时|目前).{0,3}(.+?)[。！\n]',
        ]
        for pattern in issue_patterns:
            matches = re.findall(pattern, content)
            for m in matches:
                m = m.strip()
                if len(m) > 8 and len(m) < 100:
                    if not m.startswith(('`', '│', '├', '└', '-', '|')):
                        issues.append(m)

        # 规则2: 识别未解决的事项
        unresolved_patterns = [
            r'(?:尚未|还没|没有|未).{0,3}(.+?)[。！\n]',
            r'(?:缺少|缺乏|不足).{0,3}(.+?)[。！\n]',
        ]
        for pattern in unresolved_patterns:
            matches = re.findall(pattern, content)
            for m in matches[:2]:
                m = m.strip()
                if len(m) > 8 and len(m) < 100:
                    if not m.startswith(('`', '│', '├', '└', '-', '|')):
                        issues.append(f"待完善: {m}")

        # 去重
        seen = set()
        unique_issues = []
        for i in issues:
            key = i[:30]
            if key not in seen:
                seen.add(key)
                unique_issues.append(i)

        return unique_issues[:3]

    def format_report(self, summary: Dict[str, Any]) -> str:
        """将总结格式化为可读的报告"""
        date = summary['date']
        key_points = summary['key_points']
        todos = summary['todos']
        potential_issues = summary['potential_issues']

        lines = []
        lines.append(f"📋 今日总结（{date}）\n")
        lines.append("━━━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"🔍 关键信息（{len(key_points)}项）")
        lines.append("━━━━━━━━━━━━━━━━━━━━━━")

        if key_points:
            for i, point in enumerate(key_points, 1):
                lines.append(f"{i}. {point}")
        else:
            lines.append("（今日暂无明确结论性议题）")

        lines.append("")
        lines.append("━━━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"✅ 待办事项（{len(todos)}项）")
        lines.append("━━━━━━━━━━━━━━━━━━━━━━")

        if todos:
            for i, todo in enumerate(todos, 1):
                prio_icon = {'高': '🔴', '中': '🟡', '低': '🟢'}.get(todo['priority'], '⚪')
                lines.append(f"{prio_icon} {i}. [{todo['priority']}] {todo['content']}")
        else:
            lines.append("（暂无明确待办事项）")

        if potential_issues:
            lines.append("")
            lines.append("━━━━━━━━━━━━━━━━━━━━━━")
            lines.append(f"💡 潜在议题（{len(potential_issues)}项）")
            lines.append("━━━━━━━━━━━━━━━━━━━━━━")
            for i, issue in enumerate(potential_issues, 1):
                lines.append(f"• {issue}")

        lines.append("")
        lines.append("— 小右每日总结 🤍 —")

        return '\n'.join(lines)


if __name__ == '__main__':
    gen = SummaryGenerator()
    summary = gen.generate_summary()
    report = gen.format_report(summary)
    print(report)
