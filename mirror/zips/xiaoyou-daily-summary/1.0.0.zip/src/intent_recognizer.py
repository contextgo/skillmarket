#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
每日总结 - 意图识别器
"""

import re
from typing import Dict, Any

class IntentRecognizer:
    """识别用户是否要触发每日总结"""

    # 直接触发关键词
    TRIGGER_KEYWORDS = [
        '总结一下', '今日总结', '今天总结', '生成日报', '日报',
        '今天聊了', '今天说了', '今天讨论', '今日回顾',
        '总结今天', '回顾今天', '今天做了什么'
    ]

    # 名称唤起
    SUMMON_NAMES = ['总结', '日报', '今日总结', '每日总结']

    def should_trigger(self, message: str) -> Dict[str, Any]:
        """
        判断是否应该触发每日总结
        
        Returns:
            {
                'should_trigger': bool,
                'confidence': float,
                'intent': str  # 'daily_summary' | None
            }
        """
        message = message.strip().lower()

        # 1. 关键词匹配
        for keyword in self.TRIGGER_KEYWORDS:
            if keyword in message:
                return {
                    'should_trigger': True,
                    'confidence': 0.95,
                    'intent': 'daily_summary'
                }

        # 2. 名称唤起
        for name in self.SUMMON_NAMES:
            if name in message and ('来' in message or '吧' in message or '一下' in message):
                return {
                    'should_trigger': True,
                    'confidence': 0.85,
                    'intent': 'daily_summary'
                }

        return {
            'should_trigger': False,
            'confidence': 0.0,
            'intent': None
        }
