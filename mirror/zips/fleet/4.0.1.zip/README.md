<p align="center">
  <img src="assets/banner.svg" alt="Fleet" width="800" />
</p>

<h3 align="center">Multi-agent fleet management for OpenClaw, Claude Code, Codex, Cursor, Windsurf, Gemini CLI, and custom agent stacks</h3>

<p align="center">
  <strong>One CLI to monitor, manage, and orchestrate your entire AI agent fleet.</strong>
</p>

<p align="center">
  📖 <a href="https://blog.oguzhanatalay.com/architecting-multi-agent-ai-fleet-single-vps"><strong>Read the story behind this →</strong></a>
</p>

<p align="center">
  <a href="https://github.com/oguzhnatly/fleet/actions"><img src="https://github.com/oguzhnatly/fleet/actions/workflows/ci.yml/badge.svg" alt="CI" /></a>
  <a href="https://clawhub.com"><img src="https://img.shields.io/badge/ClawHub-fleet-blue" alt="ClawHub" /></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-green" alt="License" /></a>
  <a href="#"><img src="https://img.shields.io/badge/bash-4%2B-orange" alt="Bash 4+" /></a>
</p>

<p align="center">
  <a href="#quick-start">Quick Start</a> •
  <a href="#commands">Commands</a> •
  <a href="#patterns">Patterns</a> •
  <a href="#configuration">Configuration</a> •
  <a href="docs/">Docs</a>
</p>

---

Fleet brings OpenClaw, Claude Code, Codex, Cursor, Windsurf, Gemini CLI, and custom agent stacks into one multi-agent fleet management CLI to orchestrate, monitor, judge reliability, and route intelligently across any runtime with delta tracking.

Dispatch work, steer live sessions, track outcomes, and keep OpenClaw gateways, HTTP workers, Docker workers, and local processes accountable from one CLI. Built for every operator running more than one agent or runtime.

<p align="center">
  <em>Built for AI agents to manage AI agents. Works on any system 🦞</em>
</p>

<p align="center">
  <img src="assets/demo.gif" alt="Fleet Demo" width="700" />
</p>

### Why Fleet?

🔍 **Visibility**: Know which agents are up, which CI is red, what changed overnight. One command, full picture.

📊 **Delta tracking**: SITREP remembers the last run. Only shows what _changed_. No noise.

🔧 **Safe setup**: `fleet init` detects running gateways and creates a locked local config. Symlink and shell PATH writes are explicit opt-in flags.

🧩 **Modular**: Each command is a separate file. Adding a new command means dropping a `.sh` file in `lib/commands/`. No monolith, no framework.

⚡ **Agent native**: Designed to be _used by agents_, not just humans. The [SKILL.md](SKILL.md) teaches OpenClaw and other coding agents how to manage a fleet with explicit approvals for high impact actions. Dependency installation steps are operator-action references for every supported platform.

📦 **Pattern library**: Solo empire, dev team, research lab. Pre built configs for common setups.

## Contents

- [Why Fleet?](#why-fleet)
- [Quick Start](#quick-start)
- [Commands](#commands)
  - [Dispatch](#dispatch)
  - [Monitoring](#monitoring)
  - [Development](#development)
  - [Operations](#operations)
- [Patterns](#patterns)
- [Configuration](#configuration)
- [Environment Variables](#environment-variables)
- [Architecture](#architecture)
- [For AI Agents](#for-ai-agents)
- [Requirements](#requirements)
- [Roadmap](#roadmap)
- [Contributing](#contributing)
- [Support](#support)

## Quick Start

```bash
# Install via ClawHub
clawhub install fleet

# Or via skills.sh for OpenClaw, Claude Code, Codex, Cursor, Windsurf, Gemini CLI, and shell capable agents
npx skills add oguzhnatly/fleet

# Or clone directly
git clone https://github.com/oguzhnatly/fleet.git
fleet/bin/fleet init    # creates locked config and detects gateways
# Optional after review: fleet/bin/fleet init --link

# Check your fleet
fleet agents
fleet health
fleet sitrep
```

## Commands

### Dispatch

| Command | Description |
|---------|-------------|
| `fleet task <agent> "<prompt>" --yes` | Dispatch a task after operator approval, stream response live |
| `fleet steer <agent> "<message>" --yes` | Send a mid-session correction after operator approval, with policy injection when enabled |
| `fleet watch <agent>` | Live session tail: polls every 3s, shows new messages as they arrive |
| `fleet parallel "<task>" --dry-run` | Decompose into subtasks for review before confirmed dispatch |
| `fleet kill <agent> --yes` | Send a graceful stop signal after operator approval |
| `fleet log` | Append-only structured log of all dispatches and outcomes |
| `fleet policy` | Show optional operator constitution rules applied to dispatched tasks |

### Monitoring

| Command | Description |
|---------|-------------|
| `fleet health` | Health check all gateways, endpoints, and configured runtimes |
| `fleet agents` | Show agent fleet with live status and latency, plus configured runtimes |
| `fleet sitrep [hours]` | Full SITREP with delta tracking across agents, CI, runtimes |
| `fleet audit` | Check for misconfigurations and risks |

### Operator Constitution

| Command | Description |
|---------|-------------|
| `fleet policy` | Show configured constitution status, scope, and rules |
| `fleet policy enable` / `fleet policy disable` | Toggle constitution injection |
| `fleet policy require` / `fleet policy optional` | Require valid constitution coverage before dispatch, or relax back to prompt only mode |
| `fleet policy add "<rule>"` | Add a rule and enable the constitution |
| `fleet policy rm <index>` / `fleet policy clear` | Remove one rule or clear all rules |
| `fleet policy title "<title>"` | Customize the rule block title |
| `fleet policy scope task,parallel,steer` | Choose which commands receive the rule block |
| `fleet policy preview <agent> "<prompt>"` | Preview the exact task prompt after constitution injection |

Set `constitution.enabled` in config or use `fleet policy add` to prepend custom rules to `fleet task`, `fleet parallel`, and `fleet steer` dispatches. Use `fleet policy require` to block scoped dispatches when the constitution is disabled or empty. This is useful for team rules such as required tests, repository instructions, or no history rewrite unless the operator declares an emergency.

### Cross-Runtime (v4)

| Command | Description |
|---------|-------------|
| `fleet adapters` | List registered adapters and their bindings to agents and runtimes |
| `fleet runtime add <name> <type>` | Register a new runtime (openclaw, http, docker, process) |
| `fleet runtime test <name>` | One-off probe of a runtime or agent (health + info + version) |
| `fleet runtime list` | Live status of every runtime, probed in parallel |
| `fleet runtime rm <name>` | Remove a runtime from the config |

### Development

| Command | Description |
|---------|-------------|
| `fleet ci [filter]` | GitHub CI status across all repos |
| `fleet skills` | List installed ClawHub skills |

### Operations

| Command | Description |
|---------|-------------|
| `fleet backup` | Backup gateway configs, cron jobs, and sanitized Fleet config |
| `fleet restore --yes` | Restore from latest backup after operator approval |
| `fleet init` | Setup with gateway detection, optional `--link` or `--path` |
| `fleet update` | Check releases, install only with `--install` and approval |

High impact commands support `--yes` for automation, but use it only when the current operator instruction explicitly approves the action. `fleet audit` checks config permissions, inline tokens, placeholder tokens, missing tokenEnv values, and backup state.

<details>
<summary><strong>See command output examples</strong></summary>

#### `fleet task coder "add pagination to /api/spots, cursor-based, include tests"`

```
Fleet Task
──────────
  Agent     coder (port 48520)
  Type      code
  Task ID   a1b2c3d4
  Timeout   30m

  add pagination to /api/spots, cursor-based, include tests

  ────────────────────────────────────────
  I'll add cursor-based pagination to the /api/spots endpoint.

  Starting with the database query layer...
  [streams response in real time until complete]
  ────────────────────────────────────────
  ✅  Task complete  (a1b2c3d4)
```

#### `fleet steer coder "also add a max_limit cap of 100 per page"`

```
Fleet Steer
───────────
  Agent    coder
  Session  fleet-coder

  also add a max_limit cap of 100 per page

  ────────────────────────────────────────
  Good call. Adding MAX_LIMIT = 100 guard at the top of the handler...
  ────────────────────────────────────────
  ✅  Steered.
```

#### `fleet watch coordinator`

```
Watching coordinator
────────────────────
  Session: main: polling every 3s: Ctrl+C to stop

  Connecting to coordinator session...
  Last 3 message(s):

  coordinator (strategic-default)  15:10 UTC
  Running fleet sitrep...

  you  15:23 UTC
  build the pricing page

  coordinator (strategic-default)  15:24 UTC
  On it. Reading the Stripe config first...
```

#### `fleet parallel "research competitor pricing and build a pricing page with tiers" --dry-run`

```
Fleet Parallel
──────────────
  Task: research competitor pricing and build a pricing page with tiers

  Execution plan:

  1. researcher    [research]
     Research phase: research competitor pricing and build a pricing page with tiers

  2. coder         [code]
     Implementation: research competitor pricing and build a pricing page with tiers

  ────────────────────────────────────────
  2 subtask(s) ready to dispatch in parallel.

  ℹ️  Dry run complete. Remove --dry-run to execute.
```

#### `fleet log`

```
Fleet Log  3 entries

  i9j0k1l2  coder        code      pending  ⤷1 steer
  2026-03-01 15:30  refactor auth middleware to use JWT RS256 instead of HS256

  e5f6g7h8  researcher   research  success  8m43s
  2026-03-01 15:10  analyze top 3 competitor pricing models in the surf social space

  a1b2c3d4  coder        code      success  12m17s
  2026-03-01 15:10  add pagination to /api/spots endpoint with cursor-based approach...
```

#### `fleet log --agent coder --outcome success`

```
Fleet Log  2 entries

  a1b2c3d4  coder        code      success  12m17s
  2026-03-01 15:10  add pagination to /api/spots endpoint with cursor-based approach...
```

#### `fleet kill coder`

```
Fleet Kill
──────────
  Agent    coder
  Session  fleet-coder

  ✅  Agent coder acknowledged stop signal.
  ✅  Kill signal sent to coder.
```

#### `fleet agents`

```
Agent Fleet
───────────
  ⬢ coordinator      coordinator      strategic-default               :48391 online 13ms

  ⬢ coder            implementation   coding-default                       :48520 online 8ms
  ⬢ reviewer         code-review      coding-default                       :48540 online 9ms
  ⬡ deployer         deployment       coding-default                       :48560 unreachable
  ⬢ qa               quality-assurance coding-default                      :48580 online 7ms
```

#### `fleet audit`

```
Fleet Audit
───────────

Configuration
  ✅ Config file exists at ~/.fleet/config.json
  ✅ Config permissions: 600
  ✅ All agent tokens configured
  ✅ No placeholder tokens found

Agents
  ✅ All 5 agents online
  ✅ Main gateway healthy (:48391)

CI
  ✅ gh CLI available
  ✅ All CI green

Resources
  ✅ Memory usage: 43%
  ✅ Disk usage: 7%

Backups
  ✅ Last backup: 2 day(s) ago

  All clear: 11 checks passed, 0 warnings
```

#### `fleet ci`

```
CI Status
─────────

  frontend (myorg/frontend)
    ✅ Update homepage (main) passed 2h ago
    ✅ Fix footer (main) passed 4h ago

  backend (myorg/backend)
    ❌ Add endpoint (main) failed 1h ago
    ✅ Fix auth (main) passed 3h ago
```

#### `fleet health`

```
Fleet Health Check
──────────────────
  ✅ coordinator (:48391) 12ms

Endpoints
  ✅ website (200) 234ms
  ✅ api (200) 89ms
  ❌ docs UNREACHABLE

Services
  ✅ openclaw-gateway
```

</details>

## Patterns

Fleet supports any agent organization pattern. Four common ones:

### Solo Empire
> One brain, many hands. The indie hacker setup.

```
         Coordinator (strategic)
        /     |      \
    Coder  Reviewer  Deployer
   (coding)  (coding)   (coding)
```

### Development Team
> Team leads managing specialized developers.

```
              Orchestrator (strategic)
            /        |         \
      FE Lead     BE Lead     QA Lead
     (review)    (review)    (review)
       / \          |           |
    Dev1  Dev2    Dev1       Tester
   (coding)(coding)(coding)    (coding)
```

### Research Lab
> Specialized agents for knowledge work.

```
            Director (strategic)
          /     |      \       \
    Scraper  Analyst  Writer  Fact Check
   (coding)  (review) (review)  (coding)
```

### Operator Constitution

Fleet can optionally prepend a customizable operator constitution to every dispatched task. This is a prompt level guardrail for coding agents that read the task text. It does not replace the operating system, git, or CI protections.

```json
{
  "constitution": {
    "enabled": true,
    "title": "Operator Constitution",
    "mode": "prepend",
    "required": true,
    "applyTo": ["task", "parallel", "steer"],
    "rules": [
      "Read project instructions before editing files",
      "Run verification before reporting completion",
      "Do not rewrite shared git history unless the operator explicitly declares an emergency"
    ]
  }
}
```

Use `fleet policy` to inspect rules, `fleet policy add "Run tests before reporting completion"` to customize them, `fleet policy require` to block dispatch without valid rules, `fleet policy scope task,parallel,steer` to choose coverage, and `fleet policy preview coder "fix login tests"` to see the exact prompt before dispatch.

### Cross-Runtime Operation (v4)
> Mix OpenClaw agents with Docker containers, HTTP services, and OS processes in one config.

```
                Coordinator
           /      |      \
       Coder   Reviewer  Deployer          via OpenClaw adapter
                   |
          billing-api (HTTP)               via HTTP adapter
          postgres    (Docker)             via Docker adapter
          tailscaled  (Process)            via Process adapter
```

See [`docs/patterns.md`](docs/patterns.md) for detailed guides and [`examples/`](examples/) for configs.

## Configuration

Fleet reads `~/.fleet/config.json`. Create one with `fleet init` or manually:

```json
{
  "workspace": "~/workspace",
  "gateway": {
    "port": 48391,
    "name": "coordinator"
  },
  "agents": [
    { "name": "coder", "port": 48520, "role": "implementation", "model": "coding-default" },
    { "name": "reviewer", "port": 48540, "role": "code review", "model": "coding-default" }
  ],
  "endpoints": [
    { "name": "website", "url": "https://myapp.com" },
    { "name": "api", "url": "https://api.myapp.com/health" }
  ],
  "repos": [
    { "name": "frontend", "repo": "myorg/frontend" },
    { "name": "backend", "repo": "myorg/backend" }
  ]
}
```

Everything is configurable. No hardcoded ports, models, or names. Your fleet, your way.

### v4: Cross-Runtime Adapters

Register any target under the `runtimes` key. Each entry needs an `adapter` field:

```json
{
  "runtimes": [
    { "name": "billing-api", "adapter": "http",     "url": "https://billing.example.com/health" },
    { "name": "postgres",    "adapter": "docker",   "container": "postgres" },
    { "name": "tailscaled",  "adapter": "process",  "process": "tailscaled" },
    { "name": "secondary",   "adapter": "openclaw", "port": 48490 }
  ]
}
```

Add a runtime from the CLI without editing JSON:

```bash
fleet runtime add billing-api http --url=https://billing.example.com/health
fleet runtime add postgres docker --container=postgres
fleet runtime add tailscale process --process=tailscaled
fleet runtime test billing-api   # one-off probe
fleet runtime list                # live status of all runtimes
fleet adapters                    # list registered adapters and bindings
```

See [`docs/configuration.md`](docs/configuration.md) for the full schema.

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `FLEET_CONFIG` | Config file path | `~/.fleet/config.json` |
| `FLEET_LOG` | Dispatch log path | `~/.fleet/log.jsonl` |
| `FLEET_WORKSPACE` | Workspace override | Config value |
| `FLEET_STATE_DIR` | State persistence | `~/.fleet/state` |
| `FLEET_ADAPTER_TIMEOUT` | Max seconds per adapter probe | `6` |
| `FLEET_ADAPTERS_DIR` | Drop-in directory for custom adapters | `~/.fleet/adapters` |
| `NO_COLOR` | Disable ANSI color output | _(unset)_ |
| `FLEET_NO_UPDATE_CHECK` | Skip background GitHub release check | _(unset)_ |

## Architecture

```
fleet/
├── bin/fleet               # Entry point
├── lib/
│   ├── core/               # Config, output, state, trust, adapter dispatcher
│   │   ├── adapters.sh     # v4 adapter registry, dispatcher, parallel probe helper
│   │   ├── config.sh       # JSON config loader
│   │   ├── output.sh       # Colors, formatting, HTTP helpers
│   │   ├── state.sh        # Delta state persistence
│   │   └── trust.sh        # v3 trust scoring engine
│   ├── adapters/           # v4 cross-runtime adapters (one file per runtime type)
│   │   ├── openclaw.sh     # OpenClaw gateway probe (verified)
│   │   ├── http.sh         # Generic HTTP probe (verified)
│   │   ├── docker.sh       # Docker container state and health (verified when CLI present)
│   │   └── process.sh      # OS process via pgrep (inferred)
│   └── commands/           # One file per command
│       ├── adapters.sh     # v4: list adapters and bindings
│       ├── agents.sh       # Agent fleet status
│       ├── audit.sh        # Misconfiguration checker
│       ├── backup.sh       # Config backup/restore
│       ├── ci.sh           # GitHub CI integration
│       ├── health.sh       # Endpoint and runtime health checks
│       ├── init.sh         # Interactive setup
│       ├── kill.sh         # Graceful agent stop
│       ├── log.sh          # Append-only dispatch log
│       ├── parallel.sh     # Parallel task decomposition
│       ├── runtime.sh      # v4: runtime add, test, list, rm
│       ├── score.sh        # v3 score command
│       ├── sitrep.sh       # Structured status reports
│       ├── skills.sh       # ClawHub skill listing
│       ├── steer.sh        # Mid-session corrections
│       ├── task.sh         # Task dispatch to agents
│       ├── trust.sh        # v3 trust command
│       ├── update.sh       # Self-upgrade
│       └── watch.sh        # Live session tail
├── templates/configs/      # Config templates
├── examples/               # Architecture pattern examples
│   ├── solo-empire/
│   ├── dev-team/
│   ├── research-lab/
│   └── cross-runtime/      # v4: mixed openclaw, http, docker, process targets
├── docs/                   # Documentation
├── tests/                  # Integration tests
├── SKILL.md                # ClawHub agent instructions
└── .github/workflows/      # CI pipeline
```

Modular by design. Each command is a separate file. Add your own by dropping a `.sh` file in `lib/commands/`.

## For AI Agents

Fleet ships with a [`SKILL.md`](SKILL.md) that AI coding agents can read. It is designed for OpenClaw, Claude Code, Codex, Cursor, Windsurf, Gemini CLI, and custom agent stacks, and any shell capable coding agent or editor. Install it and your coordinator automatically knows how to manage the fleet:

```bash
clawhub install fleet          # OpenClaw agents
npx skills add oguzhnatly/fleet  # OpenClaw, Claude Code, Codex, Cursor, Windsurf, Gemini CLI, and shell capable agents
```

The agent reads the skill file, learns the commands, and can run read-only health checks during heartbeat cycles. High impact commands require explicit approval.

## Requirements

| Dependency | Version | Notes |
|------------|---------|-------|
| bash | 4+ | macOS ships 3.2, run `brew install bash` |
| python3 | 3.10+ | No pip packages needed |
| curl | any | Pre installed on most systems |
| [OpenClaw](https://openclaw.ai) | any | Gateway support required |
| [gh CLI](https://cli.github.com/) | any | Optional, for CI commands |

## Roadmap

Fleet is being built in stages. Each version makes it more active, more intelligent, and more universal.

### v1: Shipped ✅
Visibility layer. Monitoring, delta SITREP, CI status, backup, audit. Fleet can see the entire operation.

### v2: Shipped ✅ (task dispatch and session steering)
Fleet stops being observational and becomes directive.

- [x] `fleet log`: append-only structured log of everything dispatched and received (built first, foundation for everything else)
- [x] `fleet task <agent> "<prompt>"`: dispatch a task to any agent from the CLI, with timeout and result capture
- [x] `fleet watch <agent>`: live log tail from a specific agent session
- [x] `fleet steer <agent> "<message>"`: send a mid-session correction to a running agent
- [x] `fleet kill <agent>`: graceful session end
- [x] `fleet parallel "<task>"`: break a high-level task into subtasks, assign to agents, run in parallel (with `--dry-run` to review decomposition before executing)

### v3: Shipped ✅ (reliability scoring and agent trust)
Fleet learns which agents actually deliver, not just which ones are alive.

- [x] `fleet trust`: trust matrix for all agents with scores, trends, and task counts
- [x] `fleet score [<agent>]`: per-task-type reliability breakdown: code, review, research, deploy, qa; with `--type` filter
- [x] Reliability formula: `quality_score × speed_multiplier`: quality degrades per steer, speed penalizes slow agents
- [x] 72h rolling window: recent tasks count 2×, 7-day tasks count 1×, older tasks count 0.5× (configurable via `trust.windowHours`)
- [x] Reliability-weighted routing for `fleet parallel`: dispatches to highest-trust agent per task type, not just whoever is idle
- [x] Trust summary line appended to every `fleet sitrep` output
- [x] v3.5: cross-validation: `fleet score` checks code/deploy successes against GitHub CI activity within 1h, flags unverified tasks

### v4: Shipped ✅ (cross-runtime adapter layer)
OpenClaw remains the primary stack for Fleet, and v4 extends orchestration, monitoring, reliability judging, routing, and delta tracking across Claude Code, Codex, Cursor, Windsurf, Gemini CLI, and custom agent stacks.

- [x] Pluggable adapter interface: six-function contract (`describe`, `verified`, `required`, `health`, `info`, `version`) every runtime implements
- [x] Built-in adapters: OpenClaw (verified), HTTP (any /health endpoint, verified), Docker (container state and health, verified when CLI present), Process (pgrep-based, inferred and labeled as such)
- [x] `fleet adapters`: lists registered adapters with verified vs inferred status, plus the binding from each agent and runtime entry to its adapter
- [x] `fleet runtime add <name> <type>`: registers a new runtime without editing config manually
- [x] `fleet runtime test <name>`: one-off health, info, and version probe against a named adapter for debugging, with animated spinner
- [x] `fleet runtime list` / `fleet runtime rm`: parallel probe of every runtime, and removal by name
- [x] User adapter directory: drop a custom `<type>.sh` into `~/.fleet/adapters/` (or `FLEET_ADAPTERS_DIR`) and it is auto-loaded
- [x] `fleet agents`, `fleet health`, `fleet sitrep` now surface runtimes alongside agents, with delta tracking on runtime status changes
- [x] Optional operator constitution: prepend customizable rules to task, parallel, and steer dispatches, preview them before execution, and optionally require valid rules before dispatch
- [x] Backward compatible: existing configs default to OpenClaw adapter, zero migration needed

### v5: Planned (server mode and HTTP API)
Fleet becomes an embeddable data source, not just a CLI.

- [ ] `fleet serve`: start fleet as a local HTTP server (localhost only by default)
- [ ] `fleet status`: show if server is running, on what port, and uptime
- [ ] REST API: `GET /agents`, `/sitrep`, `/trust`, `/log`, `/ci` and `POST /task`, `/steer`
- [ ] All responses are structured JSON with stable field names
- [ ] External tools, dashboards, and CI pipelines can consume fleet data without shelling out
- [ ] Foundation for a future cloud sync tier (local free, cloud paid)

---

## Contributing

Issues and PRs welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

Built by a solo operation, for solo operations.

## Support

If Fleet is useful to you, consider supporting its development:

<a href="https://github.com/sponsors/oguzhnatly">
  <img src="https://img.shields.io/badge/Sponsor-❤️-ea4aaa?style=for-the-badge&logo=github" alt="Sponsor on GitHub" />
</a>

## License

[MIT](LICENSE): [Oguzhan Atalay](https://github.com/oguzhnatly)
