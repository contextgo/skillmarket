#!/usr/bin/env node
/**
 * AI教育日报生成脚本 v3.0
 * 精简评分：4维度，总分10分，≥6.5入选
 * 数据源：微信公众号 + coze-web-search（去掉GitHub/36氪媒体）
 */

const { identifyAccount } = require('./wechat_identifier.js');

// ============================================================
// 评分配置（4维度，总分10分）
// ============================================================
const SCORING = {
  // 时效性（3分）—— 重新平衡，3-7天也有1分
  recency: {
    today: 2,
    yesterday: 1.5,
    day_before: 1,
    older: 1,     // 3-7天前，给1分（原来0.5太低）
  },
  // 实用度（3分）
  practicality: {
    immediate: 2,    // 立即可操作（工具/方法/清单/rct实验）
    reference: 1,   // 有参考价值（案例/故事/经验/实践）
    info: 0,        // 一般资讯
  },
  // 来源权威（1分）
  authority: {
    official: 1,   // 官方/知名媒体
    normal: 0.5,   // 普通号
  },
  // 受众匹配（3分）
  audience: {
    both: 2,       // 家长+教育者都相关
    single: 1.5,   // 单一群体
    niche: 0.5,    // 小众/从业者向
  },
  // 入选分数线
  threshold: 4.5,
};

// ============================================================
// 模拟搜索数据（test only）
// ============================================================
const mockData = {
  wechat: [
    { title: "别错过!清华开源的AI教师工具,藏着2026教育创业的大机会", source: "西江悦", datetime: "2026-04-01", summary: "不仅降低了AI教育创业的技术门槛..." },
    { title: "教育部2026年教师人工智能应用案例征集，正式开始！", source: "嘉峪关市教育局", datetime: "2026-04-01", summary: "面向全国基础教育教师，聚焦AI+学科教学创新" },
    { title: "兰州中小学AI课堂百花齐放：编程机器人到数字人导游", source: "兰州日报", datetime: "2026-03-31", summary: "兰州市AI课堂多学科覆盖，各校落地" },
    { title: "2026年学习机怎么选不踩雷？实测7款后家长必看", source: "搜狐科技", datetime: "2026-04-01", summary: "实测七款主流学习机，三条核心避坑标准" },
    { title: "65分到89分：一位妈妈用AI私教法救回孩子期中成绩", source: "莲花溢荷塘", datetime: "2026-04-01", summary: "杭州五年级妈妈用AI做诊断，找到薄弱点反复练习" },
    { title: "斯坦福商学院RCT实验：放任学生用AI，4周后学习效果崩盘", source: "网易教育", datetime: "2026-04-01", summary: "自由使用AI组多步骤问题解决能力显著低于限制使用组" },
    { title: "AI正式进入中小学课程标准！教育部2026年九大重点", source: "EAILab壹贰实验室", datetime: "2026-03-31", summary: "2026年是AI+教育真正落地元年" },
    { title: "重庆启动AI育人新引擎，明确2027年智能终端普及率80%", source: "重庆市人民政府", datetime: "2026-04-01", summary: "重庆AI教育有了施工图" },
  ],
  coze: [
    { title: "人工智能+，如何加好教育", source: "中华人民共和国教育部", published_at: "2026-04-02T08:49:00+08:00" },
    { title: "推动人工智能教育从盆景到风景", source: "中国教育新闻网", published_at: "2026-04-01T00:00:00+08:00" },
    { title: "多地学校AI+课堂大赛火热：真实课堂发生了什么", source: "华衍教育", published_at: "2026-03-31T00:00:00+08:00" },
  ],
};

// ============================================================
// 核心评分函数（4维度）
// ============================================================

/**
 * 计算时效性得分
 */
function getRecencyScore(dateStr, sourceType) {
  const now = new Date();
  const date = new Date(dateStr);
  const daysAgo = Math.floor((now - date) / (1000 * 60 * 60 * 24));
  
  if (daysAgo === 0) return SCORING.recency.today;
  if (daysAgo === 1) return SCORING.recency.yesterday;
  if (daysAgo === 2) return SCORING.recency.day_before;
  if (daysAgo <= 7) return SCORING.recency.older; // 3-7天，给0.5保底
  return 0; // 超过7天直接排除
}

/**
 * 计算实用度得分
 */
function getPracticalityScore(title, summary, sourceType) {
  const text = (title + ' ' + (summary || '')).toLowerCase();
  
  // 营销号直接给0，不参与评分
  if (sourceType === 'marketing') return 0;
  // 立即可操作
  if (/避坑|指南|方法|清单|工具|rct|实验/.test(text)) return SCORING.practicality.immediate;
  // 有参考价值（含"案例"——真实故事型文章）
  if (/真实|体验|反馈|实践|一线|学校|课堂|案例/.test(text)) return SCORING.practicality.reference;
  return SCORING.practicality.info;
}

/**
 * 计算来源权威得分
 */
function getAuthorityScore(sourceType) {
  if (sourceType === 'official' || sourceType === 'media') return SCORING.authority.official;
  return SCORING.authority.normal;
}

/**
 * 计算受众匹配得分
 */
function getAudienceScore(title, summary) {
  const text = (title + ' ' + (summary || '')).toLowerCase();
  
  const parentSignals = /家长|孩子|妈妈|爸爸|亲子|陪娃|作业|成绩/;
  const teacherSignals = /老师|课堂|学校|教学|教师|课程|学校/;
  
  const hasParent = parentSignals.test(text);
  const hasTeacher = teacherSignals.test(text);
  
  if (hasParent && hasTeacher) return SCORING.audience.both;
  if (hasParent || hasTeacher) return SCORING.audience.single;
  return SCORING.audience.niche;
}

/**
 * 综合评分（4维度）
 */
function calculateScore(item, type) {
  const sourceType = identifyAccount(item.source || '').type;
  const dateStr = type === 'wechat' ? item.datetime : item.published_at;
  
  const recency = getRecencyScore(dateStr, type);
  const practicality = getPracticalityScore(item.title, item.summary, sourceType);
  const authority = getAuthorityScore(sourceType);
  const audience = getAudienceScore(item.title, item.summary);
  
  const total = recency + practicality + authority + audience;
  
  return {
    score: Math.round(total * 10) / 10,
    breakdown: {
      recency: { value: recency, label: `时效性(${getDaysAgo(dateStr)}天前)` },
      practicality: { value: practicality, label: '实用度' },
      authority: { value: authority, label: `来源(${sourceType})` },
      audience: { value: audience, label: '受众匹配' },
    },
    sourceType,
  };
}

function getDaysAgo(dateStr) {
  const now = new Date();
  const date = new Date(dateStr);
  return Math.floor((now - date) / (1000 * 60 * 60 * 24));
}

// ============================================================
// 模拟日报生成
// ============================================================

function generateDailyReport() {
  console.log('='.repeat(60));
  console.log('AI教育日报 v3.0 · 测试运行');
  console.log('生成时间: ' + new Date().toLocaleString('zh-CN'));
  console.log(`评分规则: 4维度(时效/实用/权威/受众) · 入选线≥${SCORING.threshold}分`);
  console.log('='.repeat(60));
  
  const allArticles = [];
  
  // 处理微信公众号
  for (const item of mockData.wechat) {
    const { score, breakdown, sourceType } = calculateScore(item, 'wechat');
    allArticles.push({ ...item, score, breakdown, sourceType, type: 'wechat' });
  }
  
  // 处理 coze-web-search
  for (const item of mockData.coze) {
    const { score, breakdown, sourceType } = calculateScore(item, 'coze');
    allArticles.push({ ...item, score, breakdown, sourceType, type: 'coze' });
  }
  
  // 排序
  allArticles.sort((a, b) => b.score - a.score);
  
  // 输出评分详情
  console.log('\n📊 全部文章评分：');
  console.log('-'.repeat(60));
  allArticles.forEach((a, i) => {
    const status = a.score >= SCORING.threshold ? '✅' : '❌';
    console.log(`\n${i + 1}. ${status} [${a.score.toFixed(1)}分] ${a.title.substring(0, 40)}`);
    console.log(`   来源: ${a.source} | 类型: ${a.type}`);
    const bd = a.breakdown;
    console.log(`   时效+${bd.recency.value} | 实用+${bd.practicality.value} | 权威+${bd.authority.value} | 受众+${bd.audience.value}`);
  });
  
  // 筛选
  const qualified = allArticles.filter(a => a.score >= SCORING.threshold);
  console.log('\n' + '='.repeat(60));
  console.log(`📋 入选结果：${qualified.length}/${allArticles.length} 条（≥${SCORING.threshold}分）`);
  console.log('='.repeat(60));
  
  // 按输出板块分类
  const parentCases = qualified.filter(a => /家长|孩子|妈妈|亲子|陪娃/.test(a.title));
  const practice = qualified.filter(a => /课堂|学校|教学|老师|AI课/.test(a.title) && !parentCases.includes(a));
  const policy = qualified.filter(a => /教育部|政策|标准|规划|施工图/.test(a.title));
  const others = qualified.filter(a => !parentCases.includes(a) && !practice.includes(a) && !policy.includes(a));
  
  console.log('\n📁 分类预览：');
  console.log(`   👨‍👩‍👧 家长案例: ${parentCases.length}条`);
  console.log(`   🔬 实践一线: ${practice.length}条`);
  console.log(`   📢 政策信号: ${policy.length}条`);
  console.log(`   ⚡ 快讯备选: ${others.length}条`);
  
  console.log('\n✅ 评分系统 v3.0 测试完成！');
}

generateDailyReport();
