#!/usr/bin/env node
/**
 * 微信公众号来源识别与评分工具
 * 根据公众号名称自动判断权重（简化版，无需外部依赖）
 */

// 内置配置（内联，无需外部YAML文件）
const CONFIG = {
  // 🏛️ 官方号（权重 +1.0）
  official_accounts: [
    '微言教育', '中国教育发布', '教育之江', '湘微教育', '广东省教育厅',
    '清华大学', '北京大学', '北京师范大学', '华东师范大学', '华中师范大学',
    '中国教育科学研究院', '北大教育经济研究所'
  ],

  // 📰 知名教育媒体（权重 +0.5）
  media_accounts: [
    '中国教育报', '人民教育', '中国教师报', '教育信息化100人',
    '中小学信息技术教育', 'EAILab壹贰实验室', '认知边界', '优动设计',
    '21世纪经济报道', '光明社教育家'
  ],

  // ⚠️ 营销号/低质量号（权重 +0）
  marketing_accounts: [
    '成都炎培教育科技研究院', '西江悦'
  ],

  // 🔑 核心事件关键词表（用于识别同一事件的不同报道）
  // 格式：事件名 -> 核心关键词集合（只匹配标题，不匹配描述）
  // ⚠️ 注意：GitHub 项目互相独立，不用 event_keywords 去重
  event_keywords: {
    '两会AI教育': ['两会', '政府工作报告', '全国两会', '代表委员', '全学段', '必修课', '中小学AI课', '正式成为必修'],
    '东莞AI素养': ['东莞', 'AI素养', '核心素养', '先导计划'],
    '重庆施工图': ['重庆', '渝中区', '施工图', '教育行动方案'],
    '北京景山': ['北京', '景山学校', '小悟空空间站'],
    '教育部AI教育': ['教育部', '人工智能+教育', '加好'],
    '国际AI教育': ['美国', '英国', '新加坡', '欧盟', 'OECD', '全球'],
    'OpenAI教育': ['OpenAI', 'ChatGPT Edu'],
    // GitHub 项目互相独立，不设事件标签，由标题相似度兜底
  },

  // 识别规则（正则）
  rules: {
    official: [
      { pattern: /教育.*局|教育厅|教育局/, weight: 1.0 },
      { pattern: /大学$|学院$|研究院/, weight: 1.0 }
    ],
    media: [
      { pattern: /教育报|教育杂志|教育研究|教育科技/, weight: 0.5 }
    ],
    low_quality: [
      { pattern: /创业|掘金|风口|赚钱|暴利|必看|必考/, weight: 0 }
    ]
  }
};

/**
 * ============================================================
 * 优化A：基于事件的知识去重
 * ============================================================
 */

/**
 * 从标题中提取事件标签
 * @param {string} title - 文章标题
 * @returns {string|null} - 匹配到的事件名，或null
 */
function extractEventTag(title) {
  const t = title || '';
  const lowerTitle = t.toLowerCase();

  for (const [eventName, keywords] of Object.entries(CONFIG.event_keywords)) {
    const matched = keywords.some(kw => lowerTitle.includes(kw.toLowerCase()));
    if (matched) return eventName;
  }
  return null;
}

/**
 * 计算两篇文章的相似度
 * @param {string} titleA
 * @param {string} titleB
 * @returns {number} 0-1 之间，>0.6 认为相似
 */
function titleSimilarity(titleA, titleB) {
  if (!titleA || !titleB) return 0;
  const a = titleA.toLowerCase();
  const b = titleB.toLowerCase();

  // 提取中文词（简单按字符n-gram）
  const ngrams = (str, n = 2) => {
    const chars = str.replace(/[^\u4e00-\u9fa5]/g, '');
    const set = new Set();
    for (let i = 0; i <= chars.length - n; i++) {
      set.add(chars.slice(i, i + n));
    }
    return set;
  };

  const gramsA = ngrams(a, 2);
  const gramsB = ngrams(b, 2);

  let intersection = 0;
  for (const g of gramsA) {
    if (gramsB.has(g)) intersection++;
  }
  const union = gramsA.size + gramsB.size - intersection;
  if (union === 0) return 0;
  return intersection / union;
}

/**
 * 判断文章是否应被标记为"同类信息"（降权而非直接过滤）
 * 同一事件：标题相似度 > 0.6 或 命中同一 event_keywords
 * @param {object} article - 待检测文章 { title, source, days_ago }
 * @param {object[]} selected - 已选入日报的文章列表
 * @returns {object|null} - { is_duplicate: boolean, reason: string, similar_to: string }
 */
function checkDuplicate(article, selected) {
  if (!selected || selected.length === 0) return null;

  const eventA = extractEventTag(article.title || '');

  for (const sel of selected) {
    const eventB = extractEventTag(sel.title || '');
    const sim = titleSimilarity(article.title || '', sel.title || '');

    // 完全相同事件（高相似度）
    if (sim > 0.75) {
      // 如果已有相同高优文章，标记为重复
      if (article.source_type === 'official' && sel.source_type !== 'official') {
        return null; // 允许官方稿替换普通稿
      }
      return { is_duplicate: true, reason: `标题高度相似(${Math.round(sim*100)}%)`, similar_to: sel.title };
    }

    // 同一事件不同角度（命中相同 event_keywords）
    if (eventA && eventA === eventB && sim < 0.75) {
      // 标记为同类信息，降低权重但保留
      return { is_duplicate: false, is_same_event: true, reason: `同属"${eventA}"事件`, similar_to: sel.title };
    }
  }
  return null;
}

/**
 * ============================================================
 * 优化C：独家性/一手报道加分
 * ============================================================
 */

/**
 * 判断是否为"第一手报道"（独家/首发）
 * 规则：
 * - 官方号（+0.5）：首发政策原文
 * - 知名媒体（+0.3）：有采访/一手信源
 * - 普通号/营销号（0）：纯转载或二手解读
 */
function getExclusivityBonus(article) {
  const { source_type, title = '' } = article;
  const t = title.toLowerCase();

  // 标题含"首发""独家""刚刚""刚刚宣布"等 → 额外+0.3
  const isExclusive = /首发|独家|刚刚|重磅/.test(t);

  if (source_type === 'official') {
    return isExclusive ? 0.8 : 0.5; // 官方+首发双重加成
  }
  if (source_type === 'media') {
    return isExclusive ? 0.5 : 0.3; // 知名媒体
  }
  return 0; // 普通/营销号无独家性加分
}

/**
 * 对一批文章应用完整去重逻辑
 * 1. 先按评分排序
 * 2. 逐一检查是否重复，只对重复文章打标记而非直接丢弃
 * 3. 评分前先加独家性分
 * @param {object[]} articles - 原始文章列表（需含 score, title, source_type 字段）
 * @param {number} lookbackDays - 与近几天日报去重（默认3天）
 * @returns {object[]} - 每项含 is_duplicate / is_same_event / exclusivity_bonus 标记
 */
function deduplicateArticles(articles, lookbackDays = 3) {
  // 1. 独家性加分（先算，不改变原始分）
  const withExclusivity = articles.map(a => ({
    ...a,
    exclusivity_bonus: getExclusivityBonus(a),
    final_score: Math.min((a.score || 5) + getExclusivityBonus(a), 10)
  }));

  // 2. 按最终分排序
  withExclusivity.sort((a, b) => b.final_score - a.final_score);

  // 3. 逐一去重检测
  const selected = []; // 已选入的
  const result = [];

  for (const article of withExclusivity) {
    const dupInfo = checkDuplicate(article, selected);

    if (dupInfo && dupInfo.is_duplicate) {
      // 完全重复：跳过，但标记原因
      result.push({ ...article, deduplication_reason: dupInfo.reason, kept: false });
    } else if (dupInfo && dupInfo.is_same_event) {
      // 同事件不同角度：降分但保留，避免扎堆
      result.push({
        ...article,
        is_same_event: true,
        event_note: dupInfo.reason,
        exclusivity_bonus: 0, // 同事件不给独家性加分
        final_score: article.score, // 还原，不加独家分
        kept: true
      });
      selected.push(article); // 仍加入selected，防止第三篇继续进来
    } else {
      // 全新内容
      result.push({ ...article, kept: true });
      selected.push(article);
    }
  }

  return result;
}

/**
 * 识别公众号类型并返回权重
 * @param {string} accountName - 公众号名称
 * @returns {object} - { type: string, weight: number, reason: string }
 */
function identifyAccount(accountName) {
  const name = accountName?.trim() || '';
  
  // 1. 精确匹配官方号
  if (CONFIG.official_accounts.includes(name)) {
    return { type: 'official', weight: 1.0, reason: '白名单官方号' };
  }
  
  // 2. 精确匹配知名媒体
  if (CONFIG.media_accounts.includes(name)) {
    return { type: 'media', weight: 0.5, reason: '白名单教育媒体' };
  }
  
  // 3. 精确匹配营销号
  if (CONFIG.marketing_accounts.includes(name)) {
    return { type: 'marketing', weight: 0, reason: '已知营销号' };
  }
  
  // 4. 规则匹配
  for (const rule of CONFIG.rules.official) {
    if (rule.pattern.test(name)) {
      return { type: 'official', weight: rule.weight, reason: `匹配规则: ${rule.pattern}` };
    }
  }
  
  for (const rule of CONFIG.rules.media) {
    if (rule.pattern.test(name)) {
      return { type: 'media', weight: rule.weight, reason: `匹配规则: ${rule.pattern}` };
    }
  }
  
  for (const rule of CONFIG.rules.low_quality) {
    if (rule.pattern.test(name)) {
      return { type: 'low_quality', weight: rule.weight, reason: `匹配规则: ${rule.pattern}` };
    }
  }
  
  // 5. 默认普通号
  return { type: 'normal', weight: 0, reason: '普通号（无特殊权重）' };
}

/**
 * 批量识别并添加权重分
 * @param {Array} articles - 文章列表，每项需包含source字段
 * @returns {Array} - 添加了weight_info的文章列表
 */
function addWeightToArticles(articles) {
  return articles.map(article => {
    const source = article.source || article.account || '未知来源';
    const weightInfo = identifyAccount(source);
    
    // 复制原始评分并添加来源权重
    let baseScore = article.score || 5;
    const newScore = Math.min(baseScore + weightInfo.weight, 10);
    
    return {
      ...article,
      source_weight: weightInfo.weight,
      source_type: weightInfo.type,
      weight_reason: weightInfo.reason,
      score_before_weight: baseScore,
      score: Math.round(newScore * 10) / 10
    };
  });
}

/**
 * 过滤低质量内容
 * @param {Array} articles - 文章列表
 * @param {number} minScore - 最低分数（默认7分）
 * @param {boolean} filterMarketing - 是否过滤营销号
 * @returns {Array} - 过滤后的文章
 */
function filterArticles(articles, minScore = 7, filterMarketing = true) {
  return articles.filter(article => {
    // 过滤营销号
    if (filterMarketing && article.source_type === 'marketing') {
      return false;
    }
    // 过滤低分
    return (article.score || 0) >= minScore;
  });
}

// CLI用法
if (require.main === module) {
  const command = process.argv[2];
  
  if (command === 'identify') {
    // 识别单个公众号
    const name = process.argv[3];
    if (!name) {
      console.log('用法: node wechat_identifier.js identify <公众号名称>');
      process.exit(1);
    }
    
    const result = identifyAccount(name);
    console.log(`公众号: ${name}`);
    console.log(`类型: ${result.type}`);
    console.log(`权重: +${result.weight}`);
    console.log(`原因: ${result.reason}`);
    
  } else if (command === 'test') {
    // 测试一批公众号
    const testAccounts = [
      '微言教育',
      '中国教育报',
      '认知边界',
      '成都炎培教育科技研究院',
      '某个普通教育号',
      '华东师范大学',
      '21世纪经济报道',
      '西江悦'
    ];
    
    console.log('公众号来源识别测试:\n');
    console.log('公众号名称'.padEnd(25) + ' | 类型'.padEnd(12) + ' | 权重  | 原因');
    console.log('-'.repeat(80));
    
    for (const name of testAccounts) {
      const result = identifyAccount(name);
      console.log(
        name.padEnd(25) + 
        ' | ' + result.type.padEnd(10) + 
        ' | +' + result.weight.toFixed(1).padEnd(4) + 
        ' | ' + result.reason
      );
    }
    
  } else {
    console.log('微信公众号来源识别工具');
    console.log('用法:');
    console.log('  node wechat_identifier.js identify <公众号名称>  - 识别单个公众号');
    console.log('  node wechat_identifier.js test                 - 运行测试用例');
  }
}

module.exports = {
  identifyAccount,
  addWeightToArticles,
  filterArticles,
  extractEventTag,
  titleSimilarity,
  checkDuplicate,
  getExclusivityBonus,
  deduplicateArticles,
  CONFIG
};
