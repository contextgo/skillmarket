---
name: wisediag-calories
description: "Food Calorie Estimator — Identify food items and estimate calories from an image URL via WiseDiag AI. Usage: Provide a food image URL and say Use WiseDiag Calories to analyze this."
registry:
  homepage: https://github.com/wisediag/WiseDiag-Calories
  author: wisediag
  credentials:
    required: true
    env_vars:
      - WISEDIAG_API_KEY
---

# ⚠️ Privacy Notice

**Please read before installing:**

This tool transmits image URLs **to WiseDiag cloud servers** for recognition and processing.

**Do not upload images containing sensitive or private content** unless:
- You trust WiseDiag's data handling policy
- You accept that the image content will be transmitted to and processed remotely

---

# WiseDiag Food Calorie Estimator (OpenClaw Skill)

Automatically identify food items in images using AI, estimate calories and nutritional content per serving, and support healthy eating and weight management.

![License](https://img.shields.io/badge/License-MIT-blue.svg)
![Python](https://img.shields.io/badge/Python-3.10+-green.svg)

## Features

- Identify food types in images (meals, snacks, beverages, etc.)
- Estimate calories (kcal) and key nutritional content per serving
- Results are automatically saved as a Markdown file

## Installation

```bash
pip install -r requirements.txt
```

## 🔑 API Key Configuration (Required)

**Get your API Key:** 👉 [https://console.wisediag.com/apiKeyManage](https://s.wisediag.com/xsu9x0jq)

```bash
# Temporary (current terminal session only)
export WISEDIAG_API_KEY=your_api_key_here

# Permanent (add to ~/.zshrc or ~/.bashrc)
echo 'export WISEDIAG_API_KEY=your_api_key_here' >> ~/.zshrc
source ~/.zshrc
```

## Usage (Step-by-Step)

**Do not call any API or HTTP endpoints directly — use only the script below.**

Step 1: Set your API Key (if not already set):

```bash
export WISEDIAG_API_KEY=your_api_key_here
```

Step 2: Run the script with a food image URL:

```bash
cd scripts

# Basic usage: pass an image URL
python3 calories.py --image "https://example.com/food.jpg"

# Specify a question
python3 calories.py --image "https://example.com/food.jpg" --question "Roughly how many calories are in this meal?"

# Specify output filename
python3 calories.py --image "https://example.com/food.jpg" -n "lunch_20260324"
```

Results are automatically saved to `~/.openclaw/workspace/WiseDiag-Calories/{name}.md` — no manual saving needed.

## Parameters

| Parameter | Description |
|-----------|-------------|
| `--image` | Public URL of the food image (required) |
| `--question` | Question to ask (default: How many calories are in the food shown in this image?) |
| `-n, --name` | Output filename (without extension) |
| `-o, --output` | Output directory (default: ~/.openclaw/workspace/WiseDiag-Calories) |

## FAQ

**"WISEDIAG_API_KEY is not set" error:**
Verify the environment variable is set correctly by running `echo $WISEDIAG_API_KEY`.

**"Authentication failed" error:**
Your API Key may be invalid or expired. Visit [console.wisediag.com](https://s.wisediag.com/xsu9x0jq) to check or regenerate it.

**Image not recognized:**
Ensure the image URL is publicly accessible and in JPG, JPEG, or PNG format.

## Data Privacy

Image URLs are sent to the WiseDiag API for analysis. Image content is not permanently stored, and results are returned directly to you.

## License

MIT
