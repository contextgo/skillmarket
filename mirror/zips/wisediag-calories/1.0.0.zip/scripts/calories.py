#!/usr/bin/env python3
"""
WiseDiag Calories CLI — Estimate food calories from an image URL (powered by WiseDiag)

Usage:
    export WISEDIAG_API_KEY=your_api_key
    python3 calories.py --image "https://example.com/food.jpg"
    python3 calories.py --image "https://example.com/food.jpg" --question "这顿饭有多少卡路里？"
    python3 calories.py --image "https://example.com/meal.jpg" --member-id sample_1

Get API key: https://console.wisediag.com/apiKeyManage
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

import requests


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_SERVICE_URL = "https://openapi.wisediag.com"
REQUEST_TIMEOUT     = 120   # seconds


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_api_key() -> str:
    key = os.environ.get("WISEDIAG_API_KEY", "")
    if not key:
        print("""
[!] Error: WISEDIAG_API_KEY is not set.

    export WISEDIAG_API_KEY=your_api_key

Get a key at: https://console.wisediag.com/apiKeyManage
""")
        raise SystemExit(1)
    return key


# ---------------------------------------------------------------------------
# Core analysis
# ---------------------------------------------------------------------------

def analyze_calories(
    image_url:  str,
    question:   str        = "图片中的食物热量有多少？",
    output_dir: str | None = None,
    name:       str | None = None,
) -> bool:
    """Call WiseDiag calories API and stream results to stdout."""

    key = _get_api_key()

    url     = f"{DEFAULT_SERVICE_URL}/v1/medicine/calories"
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type":  "application/json",
    }

    payload: dict = {
        "image_list":        [image_url],
        "messages":          [{"role": "user", "content": question}],
        "topic_id":          f"calories_{int(time.time() * 1000)}",
        "request_id":        str(int(time.time() * 1000)),
        "use_thinking":      0,
        "use_health_record": 0,
    }

    print(f"[*] Analyzing : {image_url}")
    print(f"[*] Question  : {question}")
    print()

    content_text = ""
    vl_result    = None

    try:
        with requests.post(
            url, headers=headers, json=payload,
            stream=True, timeout=REQUEST_TIMEOUT,
        ) as resp:

            if resp.status_code == 401:
                print("[!] Authentication failed. Check your API key.")
                return False

            if resp.status_code != 200:
                print(f"[!] Request failed: HTTP {resp.status_code}")
                print(resp.text[:300])
                return False

            for line in resp.iter_lines():
                if not line:
                    continue
                decoded = line.decode("utf-8")
                raw     = decoded.split("data:")[-1].strip()

                if raw == "[DONE]":
                    break

                try:
                    data = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                t = data.get("type", "")

                if t == "content":
                    chunk = data.get("content") or ""
                    print(chunk, end="", flush=True)
                    content_text += chunk

                elif t == "vl_complete":
                    vl_result = data.get("data")

    except requests.Timeout:
        print("\n[!] Request timed out.")
        return False

    except requests.ConnectionError as e:
        print(f"\n[!] Connection error: {e}")
        return False

    print()  # newline after streaming output

    # -----------------------------------------------------------------------
    # Save result to Markdown
    # -----------------------------------------------------------------------
    if output_dir is None:
        out_dir = Path.home() / ".openclaw" / "workspace" / "WiseDiag-Calories"
    else:
        out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    stem     = name or f"calories_{int(time.time())}"
    out_path = out_dir / f"{stem}.md"

    md  = f"# Calorie Analysis\n\n"
    md += f"**Image:** {image_url}\n\n"
    md += f"**Question:** {question}\n\n"
    md += f"## Result\n\n{content_text}\n"

    if vl_result:
        md += (
            f"\n## Detection Details\n\n"
            f"```json\n{json.dumps(vl_result, ensure_ascii=False, indent=2)}\n```\n"
        )

    out_path.write_text(md, encoding="utf-8")
    print(f"\n[+] Result saved: {out_path}")
    return True


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="WiseDiag Calories CLI — Estimate food calories from an image URL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 calories.py --image "https://example.com/food.jpg"
  python3 calories.py --image "https://example.com/food.jpg" --question "这顿饭有多少卡路里？"
  python3 calories.py --image "https://example.com/meal.jpg" --member-id sample_1
  python3 calories.py --image "https://example.com/food.jpg" -n "lunch_20260324"
        """,
    )

    parser.add_argument(
        "--image", required=True, metavar="URL",
        help="Public URL of the food image (required)",
    )
    parser.add_argument(
        "--question", default="图片中的食物热量有多少？",
        help="Question to ask about the food (default: calorie estimate in Chinese)",
    )
    parser.add_argument(
        "-o", "--output",
        help="Output directory (default: ~/.openclaw/workspace/WiseDiag-Calories)",
    )
    parser.add_argument(
        "-n", "--name",
        help="Output filename stem",
    )

    args = parser.parse_args()

    success = analyze_calories(
        image_url  = args.image,
        question   = args.question,
        output_dir = args.output,
        name       = args.name,
    )
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
