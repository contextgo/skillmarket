---
name: wisediag-calories
description: "Food Calorie Estimator — Identify food items and estimate calories from an image URL via WiseDiag AI. Usage: Provide a food image URL and say Use WiseDiag Calories to analyze this."
registry:
  homepage: https://github.com/wisediag/WiseDiag-Calories
  author: wisediag
  credentials:
    required: true
    env_vars:
      - WISEDIAG_API_KEY
---

# ⚠️ Privacy Warning

**IMPORTANT - READ BEFORE INSTALLING:**

This skill transmits image URLs to **WiseDiag's cloud servers** for AI analysis.

**Do NOT use with sensitive or private images** unless:
- You trust WiseDiag's data handling policies
- You accept that image content will be transmitted and processed remotely

---

# WiseDiag Food Calorie Estimator (OpenClaw Skill)

Automatically identify food items from a photo and estimate calories and nutritional content per serving — powered by WiseDiag AI.

![License](https://img.shields.io/badge/License-MIT-blue.svg)
![Python](https://img.shields.io/badge/Python-3.10+-green.svg)

## Features

- Identifies food types from photos (meals, snacks, beverages, etc.)
- Estimates calories (kcal) and key nutritional components per serving
- Results are automatically saved as a Markdown file

## Installation

```bash
pip install -r requirements.txt
```

## 🔑 API Key Setup (Required)

**Get your API key:** 👉 [https://console.wisediag.com/apiKeyManage](https://s.wisediag.com/xsu9x0jq)

```bash
# Temporary (current terminal session)
export WISEDIAG_API_KEY=your_api_key_here

# Permanent (add to ~/.zshrc or ~/.bashrc)
echo 'export WISEDIAG_API_KEY=your_api_key_here' >> ~/.zshrc
source ~/.zshrc
```

## How to Use (Step-by-Step)

**NEVER call any API or HTTP endpoint directly. ONLY use the script below.**

Step 1: Set the API key (if not already set):

```bash
export WISEDIAG_API_KEY=your_api_key_here
```

Step 2: Run the script with a food image URL:

```bash
cd scripts

# Basic usage: pass a public image URL
python3 calories.py --image "https://example.com/food.jpg"

# Custom question
python3 calories.py --image "https://example.com/food.jpg" --question "How many calories is this meal?"

# Custom output filename
python3 calories.py --image "https://example.com/food.jpg" -n "lunch_20260324"
```

Results are automatically saved to `~/.openclaw/workspace/WiseDiag-Calories/{name}.md`. No additional saving is needed.

## Arguments

| Flag | Description |
|------|-------------|
| `--image` | Public URL of the food image (required) |
| `--question` | Question to ask about the food (default: calorie estimate) |
| `-n, --name` | Output filename stem |
| `-o, --output` | Output directory (default: ~/.openclaw/workspace/WiseDiag-Calories) |

## Troubleshooting

**"WISEDIAG_API_KEY is not set" error:**
Make sure you've set the environment variable correctly. Run `echo $WISEDIAG_API_KEY` to check.

**"Authentication failed" error:**
Your API key may be invalid or expired. Visit [console.wisediag.com](https://s.wisediag.com/xsu9x0jq) to check or regenerate your key.

**Food not recognized:**
Ensure the image URL is publicly accessible and in JPG, JPEG, or PNG format.

## Data Privacy

Image URLs are sent to WiseDiag's API for analysis. Image content is not permanently stored on WiseDiag servers. Results are returned directly to you.

## License

MIT
