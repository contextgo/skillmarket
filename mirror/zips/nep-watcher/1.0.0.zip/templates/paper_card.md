📄 【{{index}}/{{total}}】{{match_level}}

📌 {{title}}

👤 {{authors}}

📅 {{date}} | 匹配度 {{stars}}

📝 {{summary}}

{{#if url}}
🔗 {{url}}
{{/if}}

⬇️ 回复「下载{{index}}」存档
