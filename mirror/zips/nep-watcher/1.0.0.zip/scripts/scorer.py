#!/usr/bin/env python3
"""
scorer.py - 论文评分与排序
支持关键词匹配度 + 时间衰减综合评分
"""

import re
from datetime import datetime, timedelta
from typing import List, Dict, Tuple


class PaperScorer:
    """论文评分器"""

    def __init__(self, config: dict):
        self.config = config
        self.profile = config['user_profile']
        self.keywords = [kw.lower().strip() for kw in self.profile.get('keywords', [])]
        self.weights = self.profile.get('hybrid_weights', {'keyword_match': 0.6, 'recency': 0.4})
        self.match_mode = self.profile.get('match_mode', 'OR')

    def score_and_filter(self, papers: List[Dict], min_score: float = 0.0) -> List[Dict]:
        """
        对论文列表评分并排序
        :param papers: 原始论文列表
        :param min_score: 最低分数阈值（0-1）
        :return: 排序后的论文列表（包含得分）
        """
        if not self.keywords:
            # 无关键词时，按时间排序
            scored = []
            for p in papers:
                p['score'] = self._calc_recency_score(p)
                p['match_level'] = self._get_match_level(0)
                scored.append(p)
            scored.sort(key=lambda x: x['score'], reverse=True)
            return scored

        scored = []
        for paper in papers:
            score = self._calc_score(paper)
            match_count = self._count_keyword_matches(paper)
            paper['score'] = score
            paper['match_count'] = match_count
            paper['match_level'] = self._get_match_level(match_count)
            scored.append(paper)

        # 过滤低于阈值的
        filtered = [p for p in scored if p['score'] >= min_score]

        # 排序
        filtered.sort(key=lambda x: x['score'], reverse=True)

        return filtered

    def _calc_score(self, paper: Dict) -> float:
        """计算综合得分"""
        keyword_score = self._calc_keyword_score(paper)
        recency_score = self._calc_recency_score(paper)

        return (
            keyword_score * self.weights['keyword_match'] +
            recency_score * self.weights['recency']
        )

    def _calc_keyword_score(self, paper: Dict) -> float:
        """计算关键词匹配得分"""
        if not self.keywords:
            return 0.5  # 无关键词给中等分

        text = (paper.get('title', '') + ' ' + paper.get('abstract', '')).lower()
        matches = sum(1 for kw in self.keywords if kw in text)

        if matches == 0:
            return 0.0

        if self.match_mode == 'AND':
            return 1.0 if matches == len(self.keywords) else 0.0
        else:  # OR
            return matches / len(self.keywords)

    def _count_keyword_matches(self, paper: Dict) -> int:
        """统计匹配到的关键词数量"""
        if not self.keywords:
            return 0

        text = (paper.get('title', '') + ' ' + paper.get('abstract', '')).lower()
        return sum(1 for kw in self.keywords if kw in text)

    def _calc_recency_score(self, paper: Dict) -> float:
        """计算时间衰减得分（30天内线性衰减）"""
        date_str = paper.get('date', '')
        if not date_str:
            return 0.5  # 无日期给中等分

        try:
            # 尝试解析日期
            date_str = date_str.replace('–', '-').replace('–', '-')
            parts = date_str.split('-')

            if len(parts) == 3:
                year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
                pub_date = datetime(year, month, day)
            elif len(parts) == 2:
                year, month = int(parts[0]), int(parts[1])
                pub_date = datetime(year, month, 1)
            else:
                year = int(parts[0])
                pub_date = datetime(year, 6, 15)  # 假设年中

            days_old = (datetime.now() - pub_date).days
            # 30天内满分，之后线性衰减
            score = max(0, 1 - days_old / 30)
            return score

        except (ValueError, IndexError):
            return 0.5

    def _get_match_level(self, match_count: int) -> str:
        """根据匹配数量返回等级"""
        if not self.keywords:
            return "未设关键词"
        if match_count == 0:
            return "未匹配"
        total = len(self.keywords)
        ratio = match_count / total
        if ratio >= 0.8:
            return "🔥高匹配"
        elif ratio >= 0.5:
            return "中匹配"
        else:
            return "低匹配"

    def get_match_Stars(self, match_count: int) -> str:
        """返回星级评分"""
        if not self.keywords:
            return "⭐⭐⭐☆☆"
        total = len(self.keywords)
        ratio = match_count / total
        stars = int(ratio * 5)
        return "⭐" * stars + "☆" * (5 - stars)


if __name__ == '__main__':
    import json
    from pathlib import Path

    config_path = Path(__file__).parent.parent / 'config.json'
    with open(config_path) as f:
        config = json.load(f)

    # 测试
    scorer = PaperScorer(config)
    test_papers = [
        {
            'title': 'Tax Compliance and Global Minimum Tax',
            'abstract': 'This paper investigates the effects of global minimum tax on multinational enterprises.',
            'date': '2026-03-15',
            'url': 'https://example.com/1'
        },
        {
            'title': 'Climate Change Policy',
            'abstract': 'Environmental regulation and carbon pricing.',
            'date': '2026-03-20',
            'url': 'https://example.com/2'
        }
    ]

    scored = scorer.score_and_filter(test_papers)
    for p in scored:
        print(f"标题: {p['title'][:40]}")
        print(f"得分: {p['score']:.3f} | {p['match_level']}")
        print()
