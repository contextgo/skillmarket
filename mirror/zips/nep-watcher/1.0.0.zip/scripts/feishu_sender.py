#!/usr/bin/env python3
"""
feishu_sender.py - 飞书消息推送
使用 lark-cli 发送富文本消息
"""

import json
import subprocess
from pathlib import Path
from typing import List, Dict


class FeishuSender:
    """飞书推送器"""

    def __init__(self, config: dict):
        self.config = config
        self.feishu_config = config.get('feishu', {})
        self.chat_id = self.feishu_config.get('chat_id', '')
        self.mention = self.feishu_config.get('mention', True)

    def send_overview(self, field_name: str, total: int, date: str) -> bool:
        """发送概览消息"""
        message = self._build_overview_message(field_name, total, date)
        return self._send_message(message)

    def send_paper_card(self, paper: Dict, index: int, total: int) -> bool:
        """发送单篇论文卡片"""
        message = self._build_paper_card(paper, index, total)
        return self._send_message(message)

    def send_batch_cards(self, papers: List[Dict], field_name: str, date: str) -> bool:
        """批量发送论文卡片"""
        # 先发概览
        self.send_overview(field_name, len(papers), date)

        # 发分隔线
        self._send_message("━━━━━━━━━━━━━━━━━━━━━━")

        # 发每篇论文
        for i, paper in enumerate(papers, 1):
            self.send_paper_card(paper, i, len(papers))
            if i < len(papers):
                self._send_message("━━━━━━━━━━━━━━━━━━━━━━")

        return True

    def send_download_confirm(self, paper: Dict, index: int, filepath: str) -> bool:
        """发送下载确认消息"""
        message = (
            f"✅ 【下载完成】论文{index}\n"
            f"📄 {paper.get('title', '')[:50]}\n"
            f"📁 {filepath}"
        )
        return self._send_message(message)

    def _build_overview_message(self, field_name: str, total: int, date: str) -> str:
        """构建概览消息"""
        keywords = self.config.get('user_profile', {}).get('keywords', [])
        keyword_hint = f"（关键词：{', '.join(keywords[:3])}）" if keywords else ""

        message = (
            f"📚 今日论文速递 | {field_name}\n"
            f"📅 {date} | 共 {total} 篇 {keyword_hint}\n"
            f"回复「下载+序号」即可存档，如：下载1、下载2,3"
        )
        return message

    def _build_paper_card(self, paper: Dict, index: int, total: int) -> str:
        """构建单篇论文卡片"""
        # 优先使用中文标题
        title = paper.get('chinese_title') or paper.get('title', '无标题')
        authors = ', '.join(paper.get('authors', ['未知'])[:3])
        date = paper.get('date', '未知日期')
        # 优先使用中文摘要
        summary = paper.get('chinese_abstract') or paper.get('chinese_summary', paper.get('abstract', '暂无摘要')[:150])
        url = paper.get('url', '')
        match_level = paper.get('match_level', '')
        score = paper.get('score', 0)

        # 匹配度星级
        match_count = paper.get('match_count', 0)
        total_kw = len(self.config.get('user_profile', {}).get('keywords', []))
        if total_kw > 0:
            stars = int(match_count / total_kw * 5)
            star_str = "⭐" * stars + "☆" * (5 - stars)
        else:
            star_str = "⭐⭐⭐⭐⭐"

        # 组装卡片
        card = []
        card.append(f"📄 【{index}/{total}】{match_level}")
        card.append(f"📌 {title}")
        card.append(f"👤 {authors}")
        card.append(f"📅 {date} | 匹配度 {star_str}")
        card.append(f"📝 {summary[:120]}..." if len(summary) > 120 else f"📝 {summary}")
        if url:
            card.append(f"🔗 {url}")
        card.append(f"⬇️ 回复「下载{index}」存档")

        return '\n'.join(card)

    def _send_message(self, content: str) -> bool:
        """通过 lark-cli 发送消息"""
        try:
            # 使用 +messages-send 快捷方式发送到用户的 open_id（私聊）
            cmd = [
                'lark-cli',
                'im', '+messages-send',
                '--user-id', self.chat_id,
                '--text', content
            ]

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )

            if result.returncode == 0:
                return True
            else:
                print(f"发送失败: {result.stderr}")
                return False

        except FileNotFoundError:
            print("错误: lark-cli 未安装，请先安装并配置 lark-cli")
            return False
        except Exception as e:
            print(f"发送异常: {e}")
            return False


class FeishuInteractive:
    """飞书交互解析"""

    @staticmethod
    def parse_download_command(text: str) -> List[int]:
        """
        解析下载命令
        支持格式：
        - 下载1
        - 下载1,2,3
        - download 1
        - download 1,3,5
        - 下载 1 到 5
        """
        text = text.strip().lower()

        # 下载1,2,3 格式
        indices = []

        # 匹配 "下载" 或 "download" 后面跟数字
        pattern = r'(?:下载|download)\s*([\d,\s]+)'
        match = re.search(pattern, text)
        if match:
            nums = match.group(1)
            indices = [int(n.strip()) for n in re.split(r'[,，\s]+', nums) if n.strip().isdigit()]

        # 匹配范围格式 "下载1到5"
        range_pattern = r'(\d+)\s*(?:到|－|-)\s*(\d+)'
        range_match = re.search(range_pattern, text)
        if range_match:
            start, end = int(range_match.group(1)), int(range_match.group(2))
            indices.extend(range(start, end + 1))

        return sorted(list(set(indices)))


if __name__ == '__main__':
    import re
    import sys
    sys.path.insert(0, __file__.rsplit('/', 1)[0])

    # 测试解析
    tests = ['下载1', '下载1,2,3', 'download 3', '下载 2 到 5']
    for t in tests:
        result = FeishuInteractive.parse_download_command(t)
        print(f"'{t}' -> {result}")
