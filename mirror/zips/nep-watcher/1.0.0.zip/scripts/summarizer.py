#!/usr/bin/env python3
"""
summarizer.py - 摘要生成器
翻译后的内容直接使用，不再重复生成
"""

from typing import List, Dict


class ChineseSummarizer:
    """中文摘要处理器"""

    def __init__(self, config: dict = None):
        self.config = config or {}

    def summarize(self, papers: List[Dict], max_length: int = 200) -> List[Dict]:
        """
        处理已翻译的论文
        直接使用 chinese_title 和 chinese_abstract，不再重复生成
        """
        for paper in papers:
            # 如果没有中文标题，从原文翻译
            if not paper.get('chinese_title'):
                paper['chinese_title'] = self._translate_title(paper)

            # 如果没有中文摘要，从原文翻译
            if not paper.get('chinese_abstract'):
                paper['chinese_abstract'] = self._translate_abstract(paper)

            # 生成展示用摘要 = 中文摘要
            paper['chinese_summary'] = paper.get('chinese_abstract', '暂无摘要')

        return papers

    def _translate_title(self, paper: Dict) -> str:
        """从原文翻译标题"""
        from translator import Translator
        t = Translator(self.config)
        return t.translate_title(paper)

    def _translate_abstract(self, paper: Dict) -> str:
        """从原文翻译摘要"""
        from translator import Translator
        t = Translator(self.config)
        return t.translate_abstract(paper)


if __name__ == '__main__':
    # 测试
    config = {'user_profile': {'keywords': ['tax', 'compliance']}}
    summarizer = ChineseSummarizer(config)

    test_paper = {
        'title': 'Tax Avoidance by Small Multinationals',
        'chinese_title': '小型跨国公司避税',
        'abstract': 'This paper examines tax avoidance behavior.',
        'chinese_abstract': '本文研究了避税行为。',
    }

    result = summarizer.summarize([test_paper])
    print("中文标题:", result[0].get('chinese_title'))
    print("中文摘要:", result[0].get('chinese_abstract'))
    print("展示摘要:", result[0].get('chinese_summary'))
