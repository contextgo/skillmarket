#!/usr/bin/env python3
"""
main.py - NEP-Watcher 主入口
定时任务执行时调用此脚本
"""

import json
import sys
import os
from datetime import datetime
from pathlib import Path

# 添加脚本目录到路径
SCRIPT_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPT_DIR))

from fetcher import PaperFetcher
from scorer import PaperScorer
from summarizer import ChineseSummarizer
from translator import Translator
from feishu_sender import FeishuSender
from downloader import PaperDownloader
from interactive import InteractiveParser, ConfigManager


def load_config():
    """加载配置文件"""
    config_path = SCRIPT_DIR.parent / 'config.json'
    if not config_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def run_watch(config: dict, max_results: int = None) -> list:
    """
    执行一次论文监控
    :param config: 配置字典
    :param max_results: 最大推送篇数，默认读配置
    :return: 论文列表（含评分和摘要）
    """
    print(f"[{datetime.now().strftime('%H:%M:%S')}] 开始抓取论文...")

    # 1. 抓取
    fetcher = PaperFetcher(config)
    papers = fetcher.fetch_with_config()
    print(f"  → 抓取到 {len(papers)} 篇原始论文")

    if not papers:
        print("  → 未抓取到任何论文")
        return []

    # 2. 评分排序
    scorer = PaperScorer(config)
    max_n = max_results or config.get('user_profile', {}).get('max_results', 5)
    scored_papers = scorer.score_and_filter(papers)
    top_papers = scored_papers[:max_n]
    print(f"  → 评分排序后取前 {len(top_papers)} 篇")

    # 3. 翻译标题和摘要为中文
    print(f"  → 正在翻译标题和摘要...")
    translator = Translator(config)
    translated = translator.translate_batch(top_papers)
    print(f"  → 翻译完成")

    # 4. 生成中文摘要（使用已翻译的内容）
    summarizer = ChineseSummarizer(config)
    summarized = summarizer.summarize(translated)
    print(f"  → 中文摘要生成完成")

    return summarized


def send_to_feishu(config: dict, papers: list):
    """
    发送论文到飞书
    """
    if not papers:
        print("无论文可发送")
        return

    print(f"正在发送 {len(papers)} 篇论文到飞书...")

    sender = FeishuSender(config)
    field_name = config.get('supported_fields', {}).get(
        config.get('user_profile', {}).get('field', 'nep-pbe'),
        {}
    ).get('name', '论文')

    date = datetime.now().strftime('%Y-%m-%d')
    sender.send_batch_cards(papers, field_name, date)
    print("发送完成!")


def main():
    """主函数"""
    config = load_config()

    # 检查是否是交互模式
    if len(sys.argv) > 1:
        command = sys.argv[1]

        if command == 'run':
            # 执行一次抓取并推送
            papers = run_watch(config)
            if papers:
                send_to_feishu(config, papers)

        elif command == 'init':
            # 初始化配置（首次使用引导）
            print("📋 论文情报员初始化向导")
            print("=" * 40)
            print("请编辑 config.json 配置您的偏好")
            print("或使用交互命令调整：")
            print("  • 修改关键词为 xxx, yyy")
            print("  • 修改篇数为 N")
            print("  • 状态 - 查看当前配置")

        elif command == 'status':
            parser = InteractiveParser(config)
            print(parser.get_status_text())

        elif command == 'help':
            parser = InteractiveParser(config)
            print(parser.get_help_text())

        elif command == 'interactive':
            # 处理用户交互
            if len(sys.argv) < 3:
                print("用法: main.py interactive <用户消息>")
                sys.exit(1)

            user_message = sys.argv[2]
            papers_json = sys.argv[3] if len(sys.argv) > 3 else '[]'

            try:
                papers = json.loads(papers_json)
            except:
                papers = []

            parser = InteractiveParser(config)
            cmd, args = parser.parse(user_message)

            if cmd == 'download':
                indices = args.get('indices', [])
                if not indices:
                    print("未指定要下载的论文序号")
                else:
                    downloader = PaperDownloader(config)
                    results = downloader.batch_download(papers, indices)
                    sender = FeishuSender(config)
                    for idx, filepath in results.items():
                        if filepath:
                            sender.send_download_confirm(papers[idx - 1], idx, filepath)

            elif cmd == 'status':
                parser = InteractiveParser(config)
                print(parser.get_status_text())

            elif cmd == 'modify':
                changes = args
                if changes:
                    manager = ConfigManager()
                    manager.update_profile(changes)
                    print(f"✅ 配置已更新: {changes}")
                else:
                    print("未识别到要修改的内容")

            elif cmd == 'help':
                parser = InteractiveParser(config)
                print(parser.get_help_text())

            elif cmd == 'pause':
                manager = ConfigManager()
                manager.toggle_schedule(False)
                print("⏸️ 已暂停定时推送")

            elif cmd == 'resume':
                manager = ConfigManager()
                manager.toggle_schedule(True)
                print("▶️ 已恢复定时推送")

        else:
            print(f"未知命令: {command}")
            print("可用命令: run, init, status, help, interactive")

    else:
        # 默认：执行一次
        papers = run_watch(config)
        if papers:
            send_to_feishu(config, papers)


if __name__ == '__main__':
    main()
