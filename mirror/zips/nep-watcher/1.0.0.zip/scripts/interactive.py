#!/usr/bin/env python3
"""
interactive.py - 交互命令解析
处理用户在飞书中发送的命令
"""

import re
import json
from typing import List, Dict, Optional, Tuple
from pathlib import Path


class InteractiveParser:
    """交互命令解析器"""

    # 命令关键词
    DOWNLOAD_COMMANDS = ['下载', 'download', '下']
    MODIFY_COMMANDS = ['修改', 'change', '设置', 'update']
    STATUS_COMMANDS = ['状态', 'status', '配置']
    HELP_COMMANDS = ['帮助', 'help', '命令']
    PAUSE_COMMANDS = ['暂停']
    RESUME_COMMANDS = ['恢复', 'resume']
    SKIP_COMMANDS = ['跳过', 'skip', '忽略']

    def __init__(self, config: dict):
        self.config = config
        self.profile = config.get('user_profile', {})

    def parse(self, text: str) -> Tuple[str, dict]:
        """
        解析用户输入
        :param text: 用户输入文本
        :return: (命令类型, 命令参数)
        """
        text = text.strip().lower()

        # 下载命令
        if self._match_any(text, self.DOWNLOAD_COMMANDS):
            return ('download', self._parse_download(text))

        # 修改配置
        if self._match_any(text, self.MODIFY_COMMANDS):
            return ('modify', self._parse_modify(text))

        # 查看状态
        if self._match_any(text, self.STATUS_COMMANDS):
            return ('status', {})

        # 暂停
        if self._match_any(text, self.PAUSE_COMMANDS):
            return ('pause', {})

        # 恢复
        if self._match_any(text, self.RESUME_COMMANDS):
            return ('resume', {})

        # 跳过
        if self._match_any(text, self.SKIP_COMMANDS):
            return ('skip', {})

        # 帮助
        if self._match_any(text, self.HELP_COMMANDS):
            return ('help', {})

        return ('unknown', {})

    def _match_any(self, text: str, commands: List[str]) -> bool:
        """检查是否匹配任意命令"""
        return any(cmd in text for cmd in commands)

    def _parse_download(self, text: str) -> Dict:
        """解析下载命令"""
        indices = []

        # 下载1,2,3 或 下载1 2 3
        nums = re.findall(r'\d+', text)
        indices = [int(n) for n in nums]

        # 下载1到5 范围格式
        range_match = re.search(r'(\d+)\s*(?:到|－|-)\s*(\d+)', text)
        if range_match:
            start, end = int(range_match.group(1)), int(range_match.group(2))
            indices.extend(range(start, end + 1))

        # 去重并排序
        indices = sorted(list(set(indices)))

        return {'indices': indices}

    def _parse_modify(self, text: str) -> Dict:
        """解析修改配置命令"""
        changes = {}

        # 修改关键词
        if any(w in text for w in ['关键词', 'keyword', '过滤']):
            kw_match = re.search(r'关键词[为是]?\s*([^\s,，]+(?:[,\s]+[^\s,，]+)*)', text)
            if not kw_match:
                # 提取引号内的内容
                kw_match = re.search(r'["'"'"']([^"'"'"']+)["'"'"']', text)
            if kw_match:
                keywords_text = kw_match.group(1)
                keywords = [kw.strip() for kw in re.split(r'[,，\s]+', keywords_text) if kw.strip()]
                changes['keywords'] = keywords

        # 修改篇数
        num_match = re.search(r'(\d+)\s*(?:篇|条|个)', text)
        if num_match:
            changes['max_results'] = int(num_match.group(1))

        # 修改字段
        for field_id, field_info in self.config.get('supported_fields', {}).items():
            if field_info['name'] in text or field_id in text:
                changes['field'] = field_id
                break

        # 修改评分方式
        if '最新' in text or 'recency' in text:
            changes['scoring'] = 'recency'
        elif '匹配' in text or 'keyword' in text:
            changes['scoring'] = 'keyword'
        elif '综合' in text or 'hybrid' in text:
            changes['scoring'] = 'hybrid'

        return changes

    def get_help_text(self) -> str:
        """返回帮助文本"""
        return (
            "📖 论文情报员命令列表：\n\n"
            "📥 下载论文：\n"
            "  • 下载1 — 下载第1篇\n"
            "  • 下载1,2,3 — 下载第1、2、3篇\n"
            "  • 下载1到5 — 下载第1到5篇\n\n"
            "⚙️ 修改配置：\n"
            "  • 修改关键词为tax, compliance\n"
            "  • 修改篇数为10\n"
            "  • 修改字段为劳动经济学\n\n"
            "📊 查看状态：\n"
            "  • 状态 — 查看当前配置\n\n"
            "⏸️ 暂停推送：\n"
            "  • 暂停 — 暂停每日推送\n\n"
            "▶️ 恢复推送：\n"
            "  • 恢复 — 恢复每日推送\n\n"
            "⏭️ 跳过：\n"
            "  • 跳过 — 忽略本次推送\n"
        )

    def get_status_text(self) -> str:
        """返回当前状态文本"""
        profile = self.profile
        keywords = profile.get('keywords', [])
        field = profile.get('field', 'nep-pbe')
        field_name = self.config.get('supported_fields', {}).get(field, {}).get('name', field)
        max_results = profile.get('max_results', 5)
        scoring = profile.get('scoring', 'hybrid')
        schedule_enabled = self.config.get('schedule', {}).get('enabled', False)
        cron = self.config.get('schedule', {}).get('cron', '')

        scoring_map = {
            'hybrid': '综合（关键词×0.6 + 时间×0.4）',
            'keyword': '关键词匹配优先',
            'recency': '最新优先'
        }

        return (
            f"📊 当前配置状态：\n\n"
            f"📚 领域：{field_name}\n"
            f"📝 每次推送：{max_results} 篇\n"
            f"🔑 关键词：{', '.join(keywords) if keywords else '未设置'}\n"
            f"⭐ 评分方式：{scoring_map.get(scoring, scoring)}\n"
            f"⏰ 定时推送：{'已开启' if schedule_enabled else '已暂停'}（{cron}）\n"
        )


class ConfigManager:
    """配置文件管理器"""

    def __init__(self, config_path: str = None):
        if config_path is None:
            config_path = Path(__file__).parent.parent / 'config.json'
        self.config_path = Path(config_path)
        self.config = self._load()

    def _load(self) -> dict:
        """加载配置"""
        if self.config_path.exists():
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def save(self):
        """保存配置"""
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)

    def update_profile(self, changes: dict):
        """更新用户配置"""
        if 'user_profile' not in self.config:
            self.config['user_profile'] = {}
        self.config['user_profile'].update(changes)
        self.save()

    def toggle_schedule(self, enabled: bool):
        """开关定时任务"""
        if 'schedule' not in self.config:
            self.config['schedule'] = {}
        self.config['schedule']['enabled'] = enabled
        self.save()


if __name__ == '__main__':
    config = {
        'supported_fields': {
            'nep-pbe': {'name': '公共经济学'},
            'nep-lab': {'name': '劳动经济学'}
        },
        'user_profile': {
            'field': 'nep-pbe',
            'keywords': ['tax', 'compliance'],
            'max_results': 5
        }
    }

    parser = InteractiveParser(config)

    tests = [
        '下载1',
        '下载1,2,3',
        '下载1到5',
        '修改关键词为carbon tax, environmental',
        '修改篇数为10',
        '状态',
        '帮助'
    ]

    for t in tests:
        cmd, args = parser.parse(t)
        print(f"'{t}' -> {cmd}, {args}")
