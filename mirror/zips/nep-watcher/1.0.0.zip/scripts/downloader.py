#!/usr/bin/env python3
"""
downloader.py - 论文下载存档
从 RePEc/EconPapers 下载 PDF 或抓取详情页存档
"""

import os
import re
import json
import requests
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional, List


class PaperDownloader:
    """论文下载器"""

    def __init__(self, config: dict):
        self.config = config
        self.storage = config.get('storage', {})
        self.download_dir = os.path.expanduser(self.storage.get('download_dir', '~/Documents/papers/'))
        self.naming = self.storage.get('naming', '{date}_{author}_{title[:30]}')
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        })

        # 确保下载目录存在
        Path(self.download_dir).mkdir(parents=True, exist_ok=True)

    def download(self, paper: Dict) -> Optional[str]:
        """
        下载单篇论文
        :param paper: 论文信息（包含 url, title, authors, date 等）
        :return: 下载后的文件路径，失败返回 None
        """
        url = paper.get('url', '')
        if not url:
            print(f"无URL信息，跳过: {paper.get('title', '')[:30]}")
            return None

        # RePEc 链接处理
        if 'd.repec.org' in url:
            return self._download_from_repec(paper, url)
        # arXiv 链接处理
        elif 'arxiv.org' in url:
            return self._download_from_arxiv(paper, url)
        else:
            # 通用处理：保存详情页
            return self._save_detail_page(paper, url)

    def _download_from_repec(self, paper: Dict, url: str) -> Optional[str]:
        """从 RePEc 下载"""
        # 先尝试获取PDF
        pdf_url = self._try_repec_pdf(url)

        if pdf_url:
            # 尝试下载PDF，最多重试2次
            for attempt in range(3):
                try:
                    resp = self.session.get(pdf_url, timeout=30)
                    if resp.status_code == 200 and 'pdf' in resp.headers.get('content-type', '').lower():
                        filepath = self._make_filepath(paper, 'pdf')
                        with open(filepath, 'wb') as f:
                            f.write(resp.content)
                        return filepath
                    elif resp.status_code == 429:
                        # 限速，等待后重试
                        import time
                        time.sleep(5 * (attempt + 1))
                        continue
                    else:
                        break
                except requests.exceptions.Timeout:
                    import time
                    time.sleep(2 * (attempt + 1))
                    continue
                except Exception as e:
                    print(f"PDF下载失败(尝试{attempt+1}): {e}")
                    break

        # 回退：保存详情页
        return self._save_detail_page(paper, url)

    def _try_repec_pdf(self, url: str) -> Optional[str]:
        """尝试从 RePEc URL 获取 PDF 链接"""
        try:
            # 尝试直接访问，RePEc 会重定向到 PDF 或 HTML
            resp = self.session.get(url, timeout=30, allow_redirects=True)
            final_url = resp.url

            # 如果是 PDF URL 直接返回
            if 'pdf' in final_url.lower() or 'pdf' in resp.headers.get('content-type', '').lower():
                return final_url

            # 尝试构造 PDF URL
            if '/n?' in url:
                paper_id = url.split('u=')[-1] if 'u=' in url else ''
                # 很多 RePEc 论文可以通过 /n?u=... 找到 PDF
                # 但不是所有都有 PDF，回退到 HTML
                return None

        except:
            return None

    def _download_from_arxiv(self, paper: Dict, url: str) -> Optional[str]:
        """从 arXiv 下载 PDF"""
        try:
            # arXiv PDF URL: https://arxiv.org/pdf/xxxx.xxxx.pdf
            arxiv_id = re.search(r'arxiv\.org/(?:abs|pdf)/(\d+\.\d+)', url)
            if arxiv_id:
                pdf_url = f"https://arxiv.org/pdf/{arxiv_id.group(1)}.pdf"
                resp = self.session.get(pdf_url, timeout=120)
                if resp.status_code == 200:
                    filepath = self._make_filepath(paper, 'pdf')
                    with open(filepath, 'wb') as f:
                        f.write(resp.content)
                    return filepath
        except Exception as e:
            print(f"arXiv下载失败: {e}")

        return self._save_detail_page(paper, url)

    def _save_detail_page(self, paper: Dict, url: str) -> Optional[str]:
        """保存论文详情页（Markdown格式，包含摘要）"""
        try:
            filepath = self._make_filepath(paper, 'md')

            # 构建包含元数据和摘要的Markdown文件
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(f"# {paper.get('chinese_title', paper.get('title', ''))}\n\n")
                f.write(f"**原文标题:** {paper.get('title', '')}\n\n")
                f.write(f"**作者:** {', '.join(paper.get('authors', []))}\n\n")
                f.write(f"**日期:** {paper.get('date', '')}\n\n")
                f.write(f"**关键词:** {', '.join(paper.get('keywords', []))}\n\n")
                f.write(f"**JEL:** {', '.join(paper.get('jel', []))}\n\n")
                f.write(f"**链接:** {url}\n\n")
                f.write(f"**中文摘要:**\n\n{paper.get('chinese_abstract', paper.get('abstract', '暂无'))}\n\n")
                f.write(f"**英文摘要:**\n\n{paper.get('abstract', '暂无')}\n\n")
                f.write(f"---\n\n")
                f.write(f"*存档时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*")

            return filepath

        except Exception as e:
            print(f"详情页保存失败: {e}")
            return None

    def _make_filepath(self, paper: Dict, ext: str) -> str:
        """生成文件路径"""
        # 清理文件名
        title = re.sub(r'[^\w\s\u4e00-\u9fff-]', '', paper.get('title', 'untitled'))[:30]
        title = re.sub(r'\s+', '_', title.strip())

        author = paper.get('authors', ['unknown'])
        if isinstance(author, list):
            author = author[0].split(',')[0] if author else 'unknown'
        author = re.sub(r'[^\w]', '', author)[:15]

        date = paper.get('date', datetime.now().strftime('%Y-%m'))
        date = date[:7] if len(date) > 7 else date

        filename = f"{date}_{author}_{title}.{ext}"
        filepath = os.path.join(self.download_dir, filename)

        # 避免重名
        if os.path.exists(filepath):
            base, ext2 = os.path.splitext(filepath)
            filepath = f"{base}_副本.{ext2}"

        return filepath

    def batch_download(self, papers: list, indices: List[int]) -> Dict[int, str]:
        """
        批量下载指定序号的论文
        :param papers: 完整论文列表
        :param indices: 要下载的序号列表（1-based）
        :return: {序号: 文件路径} 的字典
        """
        results = {}
        for idx in indices:
            if 1 <= idx <= len(papers):
                paper = papers[idx - 1]
                filepath = self.download(paper)
                results[idx] = filepath
            else:
                results[idx] = None
        return results


if __name__ == '__main__':
    # 测试
    config = {
        'storage': {
            'download_dir': '/tmp/test_papers/',
            'naming': '{date}_{author}_{title[:30]}'
        }
    }
    downloader = PaperDownloader(config)

    test_paper = {
        'title': 'Global Minimum Tax and Profit Shifting',
        'authors': ['Chen, Xuyang', 'Sun, Rui'],
        'date': '2026-03-15',
        'url': 'https://d.repec.org/n?u=RePEc:cor:louvco:2025019',
        'abstract': 'Test abstract'
    }

    result = downloader.download(test_paper)
    print(f"下载结果: {result}")
