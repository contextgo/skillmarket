#!/usr/bin/env python3
"""
fetcher.py - 从目标网站抓取论文列表
支持 NEP 系列网站，输出结构化论文数据
"""

import re
import json
import requests
from datetime import datetime
from typing import List, Dict, Optional
from bs4 import BeautifulSoup


class PaperFetcher:
    """论文抓取器"""

    def __init__(self, config: dict):
        self.config = config
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        })

    def fetch(self, url: str = None, field: str = None) -> List[Dict]:
        """
        抓取论文列表
        :param url: 自定义URL，优先于 field
        :param field: 预定义字段名（如 nep-pbe）
        :return: 论文列表
        """
        if url:
            target_url = url
        elif field:
            target_url = self.config['supported_fields'][field]['url']
        else:
            target_url = self.config['user_profile']['custom_url'] or \
                         self.config['supported_fields']['nep-pbe']['url']

        html = self._fetch_html(target_url)
        papers = self._parse_html(html)
        return papers

    def _fetch_html(self, url: str) -> str:
        """获取网页内容"""
        try:
            resp = self.session.get(url, timeout=30)
            resp.raise_for_status()
            return resp.text
        except requests.RequestException as e:
            raise RuntimeError(f"抓取失败: {e}")

    def _parse_html(self, html: str) -> List[Dict]:
        """解析NEP格式的HTML"""
        # 清理HTML实体
        html = html.replace('&#39;', "'").replace('&amp;', '&')
        soup = BeautifulSoup(html, 'html.parser')
        text = soup.get_text()

        # 提取所有URL（每个论文条目以URL结尾）
        url_pattern = r'(https://d\.repec\.org/n\?u=RePEc:[^\s<>"\']+)'

        # 找到所有URL的位置
        url_matches = list(re.finditer(url_pattern, text))

        papers = []
        for idx, match in enumerate(url_matches):
            url = match.group(1).split('&')[0]  # 去掉 &r=pbe 等参数

            # 获取这个URL之前的文本块（到上一个URL之后的位置）
            start_pos = url_matches[idx-1].end() if idx > 0 else 0
            end_pos = match.start()
            block = text[start_pos:end_pos].strip()

            if not block:
                continue

            paper = self._parse_block(block, url)
            if paper and paper.get('title') and not paper.get('title', '').startswith('http'):
                papers.append(paper)

        return papers

    def _parse_block(self, block: str, url: str = '') -> Optional[Dict]:
        """解析单个论文块"""
        paper = {
            'title': '',
            'authors': [],
            'abstract': '',
            'date': '',
            'url': url,
            'keywords': [],
            'jel': []
        }

        lines = block.strip().split('\n')
        lines = [l.strip() for l in lines if l.strip()]

        if not lines:
            return None

        # 第一行是标题
        title = lines[0].strip('"').strip()
        # 过滤掉明显的页眉页脚内容
        if not title or title.startswith('http') or len(title) < 5:
            return None
        paper['title'] = title

        # 找到 By: 之后的内容
        by_idx = -1
        for idx, line in enumerate(lines):
            if re.match(r'^By:?\s*$', line) or line.startswith('By:'):
                by_idx = idx
                break

        if by_idx < 0:
            # 尝试在标题后找作者（常见格式：标题 \n By: Author\n Abstract:）
            for idx, line in enumerate(lines[1:5], 1):
                if re.match(r'^[A-Z][a-z]+,?\s', line) or 'By' in line:
                    by_idx = idx
                    break

        if by_idx >= 0:
            # 提取作者行
            author_lines = []
            for j in range(by_idx, len(lines)):
                line = lines[j]
                # 遇到新标记就停止
                if j > by_idx and any(k in line for k in ['Abstract:', 'Keywords:', 'JEL:', 'Date:']):
                    break
                author_lines.append(line)

            # 清理作者
            author_text = ' '.join(author_lines)
            author_text = re.sub(r'^By:?\s*', '', author_text)
            author_text = author_text.replace(';', ',').replace('，', ',')

            # 按逗号分割
            authors = []
            for part in author_text.split(','):
                part = part.strip()
                # 去掉机构信息（括号内的）
                part = re.sub(r'\s*\([^)]*\)\s*', '', part).strip()
                if part and len(part) > 2 and not part.startswith('http'):
                    authors.append(part)
            paper['authors'] = authors[:5]

        # 提取 Abstract:
        abstract_match = re.search(r'Abstract:\s*(.+?)(?=Keywords:|$)', block, re.DOTALL | re.IGNORECASE)
        if abstract_match:
            paper['abstract'] = ' '.join(abstract_match.group(1).split())

        # 提取 Keywords:
        kw_match = re.search(r'Keywords:\s*(.+?)(?=JEL:|Date:|URL:|$)', block, re.DOTALL | re.IGNORECASE)
        if kw_match:
            kw_text = kw_match.group(1)
            paper['keywords'] = [k.strip() for k in re.split(r'[,;]', kw_text) if k.strip()]

        # 提取 JEL:
        jel_match = re.search(r'JEL:\s*([A-Z]\d{2}(?:\s+[A-Z]\d{2})*)', block)
        if jel_match:
            paper['jel'] = jel_match.group(1).split()

        # 提取 Date:
        date_match = re.search(r'Date:\s*(\d{4}[–\-–]\d{2}[–\-–]\d{2}|\d{4}[–\-–]\d{2}|\d{4})', block)
        if date_match:
            paper['date'] = date_match.group(1).replace('–', '-').replace('–', '-')

        return paper

    def fetch_with_config(self) -> List[Dict]:
        """使用当前配置抓取"""
        profile = self.config['user_profile']
        field = profile.get('field') if not profile.get('custom_url') else None
        return self.fetch(url=profile.get('custom_url'), field=field)


if __name__ == '__main__':
    # 测试
    from pathlib import Path
    config_path = Path(__file__).parent.parent / 'config.json'
    with open(config_path) as f:
        config = json.load(f)

    fetcher = PaperFetcher(config)
    papers = fetcher.fetch_with_config()
    print(f"抓取到 {len(papers)} 篇论文")

    # 去重
    seen_urls = set()
    unique_papers = []
    for p in papers:
        if p['url'] not in seen_urls:
            seen_urls.add(p['url'])
            unique_papers.append(p)

    print(f"去重后: {len(unique_papers)} 篇")
    for i, p in enumerate(unique_papers[:5], 1):
        print(f"\n--- 论文{i} ---")
        print(f"标题: {p['title'][:60]}...")
        print(f"作者: {', '.join(p['authors'][:2])}")
        print(f"日期: {p['date']}")
        print(f"URL: {p['url'][:60]}...")
        print(f"摘要: {p['abstract'][:80]}..." if p['abstract'] else "无摘要")
