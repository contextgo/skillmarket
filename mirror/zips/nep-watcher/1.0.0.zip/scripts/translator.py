#!/usr/bin/env python3
"""
translator.py - 使用 MyMemory API 进行学术论文翻译
免费、可靠、支持学术术语
"""

import urllib.request
import urllib.parse
import json
import re
from typing import Dict, List


class Translator:
    """学术论文翻译器"""

    def __init__(self, config: dict = None):
        self.config = config or {}

    def translate_batch(self, papers: List[Dict]) -> List[Dict]:
        """批量翻译"""
        for paper in papers:
            paper['chinese_title'] = self.translate_title(paper)
            paper['chinese_abstract'] = self.translate_abstract(paper)
        return papers

    def translate_title(self, paper: Dict) -> str:
        """翻译标题"""
        title = paper.get('title', '')
        if not title:
            return ''
        return self._translate(title)

    def translate_abstract(self, paper: Dict) -> str:
        """翻译摘要"""
        abstract = paper.get('abstract', '')
        if not abstract:
            return '暂无摘要'
        return self._translate(abstract)

    def _translate(self, text: str) -> str:
        """调用 MyMemory API 翻译"""
        if not text:
            return text

        # 长文本截断（API限制）
        MAX_LEN = 500
        if len(text) > MAX_LEN:
            # 先翻前半段，再翻后半段拼接
            part1 = text[:MAX_LEN]
            part2 = text[MAX_LEN:MAX_LEN*2] if len(text) > MAX_LEN else ''
            
            try:
                url1 = f'https://api.mymemory.translated.net/get?q={urllib.parse.quote(part1)}&langpair=en|zh-CN'
                req1 = urllib.request.Request(url1, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req1, timeout=15) as resp1:
                    result1 = json.loads(resp1.read().decode('utf-8'))
                    if result1.get('responseStatus') == 200:
                        translated1 = result1['responseData']['translatedText']
                    else:
                        translated1 = part1
            except:
                translated1 = part1
            
            if part2:
                try:
                    url2 = f'https://api.mymemory.translated.net/get?q={urllib.parse.quote(part2)}&langpair=en|zh-CN'
                    req2 = urllib.request.Request(url2, headers={'User-Agent': 'Mozilla/5.0'})
                    with urllib.request.urlopen(req2, timeout=15) as resp2:
                        result2 = json.loads(resp2.read().decode('utf-8'))
                        if result2.get('responseStatus') == 200:
                            translated2 = result2['responseData']['translatedText']
                        else:
                            translated2 = part2
                except:
                    translated2 = part2
                return self._post_process(translated1 + '...' + translated2)
            
            return self._post_process(translated1)

        try:
            url = f'https://api.mymemory.translated.net/get?q={urllib.parse.quote(text)}&langpair=en|zh-CN'
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=15) as resp:
                result = json.loads(resp.read().decode('utf-8'))
                if result.get('responseStatus') == 200:
                    translated = result['responseData']['translatedText']
                    # Post-process: 清理并优化
                    return self._post_process(translated)
        except Exception as e:
            print(f"翻译失败: {e}")

        return text

    def _post_process(self, text: str) -> str:
        """后处理：优化翻译结果"""
        if not text:
            return text

        # 移除多余空格
        text = re.sub(r'\s+', ' ', text).strip()

        # 修复常见术语不统一问题
        replacements = {
            '最小值': '最低',
            '跨国公司[MNEs]': '跨国企业',
            '跨国公司[MNEs]': '跨国企业',
            '跨國企業': '跨国企业',
            '跨國公司': '跨国公司',
            '税': '税收',
            '收入': '收入',
            '最小': '最低',
            '全球最低税收和税收竞争': '全球最低税与税收竞争',
            '全球最低税收': '全球最低税',
        }

        for old, new in replacements.items():
            if old in text:
                text = text.replace(old, new)

        return text


if __name__ == '__main__':
    translator = Translator()

    tests = [
        'Tax Avoidance by Small Multinationals as a Side Effect of Anti Tax Avoidance Policy',
        'Global Minimum Tax, Investment Incentives and Asymmetric Tax Competition',
        'The OECD BEPS initiative introduced country-by-country reporting for multinational groups with consolidated turnover above 750 million euros.',
    ]

    for en in tests:
        cn = translator._translate(en)
        print(f'EN: {en[:60]}')
        print(f'CN: {cn}')
        print()
