---
name: nep-watcher
description: 定时从 NEP 系列网站抓取学术论文，生成中文摘要，推送飞书，支持关键词过滤、评分排序和下载存档。适用于研究人员追踪最新学术动态。
---

# NEP-Watcher：论文情报员

定时从指定学术网站抓取论文，生成中文摘要，推送飞书，支持关键词过滤、评分排序、下载存档。

## 功能一览

| 功能 | 说明 |
|------|------|
| 定时抓取 | 每天自动执行，无需手动 |
| 多网站支持 | NEP系列（公共经济学、会计、劳动经济学等）+ 自定义URL |
| 关键词过滤 | 只推送包含指定关键词的论文 |
| 评分排序 | 按关键词匹配度 + 时间综合评分 |
| 中文摘要 | MyMemory API 翻译，标题摘要均支持 |
| 飞书推送 | 卡片式推送，支持直接下载 |
| 下载存档 | 回复"下载X"即可存档到本地 |

## 首次初始化

```
/nep-watcher init
```

会引导设置：
1. 选择论文领域或自定义URL
2. 设置每次推送篇数（默认5篇）
3. 设置关键词（选填）
4. 选择评分偏好

## 日常使用

```
/nep-watcher run        # 立即执行一次
/nep-watcher status     # 查看当前配置
/nep-watcher modify     # 调整关键词/偏好
/nep-watcher pause     # 暂停推送
/nep-watcher resume    # 恢复推送
```

## 交互命令

收到推送后：
- `下载1` / `download 1` → 下载第1篇
- `下载1,3,5` → 同时下载第1、3、5篇
- `跳过` → 忽略本次推送

## 定时调度

通过 OpenClaw cron job 实现，调度命令：
```bash
openclaw cron create \
  --name "NEP-PBE论文推送" \
  --schedule "0 8 * * *" \
  --command "python3 ~/.openclaw/workspace/skills/nep-watcher/scripts/main.py"
```

## 依赖

- Python 3.9+
- `requests` / `beautifulsoup4`
- `lark-cli`（飞书推送）
- OpenClaw cron 调度

## 目录结构

```
nep-watcher/
├── SKILL.md
├── config.json
├── scripts/
│   ├── main.py          # 主入口
│   ├── fetcher.py       # 网页抓取
│   ├── scorer.py        # 评分排序
│   ├── summarizer.py    # 摘要处理
│   ├── translator.py     # 翻译（MyMemory API）
│   ├── feishu_sender.py # 飞书推送
│   ├── downloader.py     # 下载存档
│   └── interactive.py    # 交互解析
└── templates/
    └── paper_card.md    # 消息卡片模板
```

## 配置说明

编辑 `config.json` 来自定义：

```json
{
  "user_profile": {
    "field": "nep-pbe",
    "max_results": 5,
    "keywords": ["tax compliance", "BEPS"],
    "scoring": "hybrid",
    "hybrid_weights": {
      "keyword_match": 0.6,
      "recency": 0.4
    }
  },
  "schedule": {
    "cron": "0 20 * * *",
    "enabled": true
  },
  "feishu": {
    "chat_id": "用户open_id",
    "mention": true
  }
}
```
