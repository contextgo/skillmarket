#!/bin/bash
# ontology-clawra 进化验证脚本
# 用途：对比进化前后的能力差异，输出验证报告

SKILL_DIR="$HOME/.openclaw/skills/ontology-clawra"
MEMORY_DIR="$SKILL_DIR/memory"
BACKUP_DIR="$HOME/.openclaw/workspace"

echo "=== ontology-clawra 进化验证报告 ==="
echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 1. 版本信息
echo "## 版本信息"
grep '"version"' "$SKILL_DIR/SKILL.md" | head -1
echo ""

# 2. 技能文件统计
echo "## 技能文件统计"
echo "SKILL.md 行数: $(wc -l < "$SKILL_DIR/SKILL.md")"
echo "memory/ 文件数: $(ls "$MEMORY_DIR" | wc -l)"
echo "memory/ 目录大小: $(du -sh "$MEMORY_DIR" | cut -f1)"
echo ""

# 3. 能力清单对比
echo "## 能力清单"
echo "### GEP基因数: $(grep -c '"id":' "$MEMORY_DIR/genes.json" 2>/dev/null || echo 0)"
echo "### 进化胶囊数: $(grep -c '"type": "Capsule"' "$MEMORY_DIR/evolution_capsules.json" 2>/dev/null || echo 0)"
echo "### 本体规则数: $(grep -c '^- ' "$MEMORY_DIR/rules.yaml" 2>/dev/null || echo 0)"
echo "### 本体概念数: $(wc -l < "$MEMORY_DIR/concepts.jsonl" 2>/dev/null || echo 0)"
echo "### 置信度追踪: $(wc -l < "$MEMORY_DIR/confidence_tracker.jsonl" 2>/dev/null || echo 0)"
echo ""

# 4. cron任务统计
echo "## cron任务统计"
echo "总任务数: $(openclaw cron list 2>/dev/null | grep -c 'id:' || echo '需要手动检查')"
echo ""

# 5. 备份检查
echo "## 备份历史"
ls -lt "$BACKUP_DIR"/ontology-clawra-backup-* 2>/dev/null | head -5 || echo "无备份"
echo ""

# 6. 反假任务机制验证
echo "## 反假任务机制"
if grep -q "反假任务机制" "$SKILL_DIR/SKILL.md"; then
    echo "✅ 反假任务机制已嵌入SKILL.md"
else
    echo "❌ 反假任务机制缺失"
fi
if grep -q "Rule-anti-fake-001" "$SKILL_DIR/SKILL.md"; then
    echo "✅ Rule-anti-fake-001 规则存在"
else
    echo "❌ Rule-anti-fake-001 缺失"
fi
echo ""

# 7. GEP协议验证
echo "## GEP协议"
if [ -f "$MEMORY_DIR/genes.json" ]; then
    echo "✅ genes.json 存在"
else
    echo "❌ genes.json 缺失"
fi
if [ -f "$MEMORY_DIR/evolution_capsules.json" ]; then
    echo "✅ evolution_capsules.json 存在"
else
    echo "❌ evolution_capsules.json 缺失"
fi
echo ""

# 8. WAL协议验证
echo "## WAL协议"
if grep -q "WAL Protocol" "$SKILL_DIR/SKILL.md"; then
    echo "✅ WAL Protocol 已嵌入"
else
    echo "❌ WAL Protocol 缺失"
fi
if [ -f "$HOME/.openclaw/workspace/memory/working-buffer.md" ]; then
    echo "✅ working-buffer.md 存在"
else
    echo "⚠️ working-buffer.md 未创建（建议创建）"
fi
echo ""

# 9. 整合效果评估
echo "## 整合效果评估"
COMPARED_FEATURES=$(cat << 'EOF'
v3.5能力:
- 推理框架
- 置信度体系
- 规则引擎

v3.6新增:
- GEP基因库
- 进化胶囊
- corrections追踪
- WAL协议
- 反假任务机制
- 任务健康报告
EOF
)
echo "$COMPARED_FEATURES"
echo ""

echo "=== 验证完成 ==="
