# ontology-clawra 安装说明

## 安装方式

```bash
# 方式1: 通过 ClawHub 安装
clawhub install ontology-clawra

# 方式2: 手动安装
git clone https://github.com/wu-xiaochen/ontology-clawra.git
```

## 环境要求

- Node.js 18+
- Python 3.9+
- OpenClaw

## 权限说明

| 权限 | 说明 |
|------|------|
| 读取 | 仅读取 ~/.openclaw/skills/ontology-clawra/memory/ |
| 写入 | 需用户明确确认"写入本体" |
| 网络 | 不主动发起网络请求 |

## 安全边界

- 默认不启用自动写入
- 写入本体必须用户确认
- 不上传用户数据到任何服务器
