# MacVision OCR module
