# -*- coding: utf-8 -*-
# Copyright (c) 2026 WorkBuddy Skills. Author: QQ 1817694478 | Q-Group: 972156177
"""Test: generate inject data for student-goal-task-manager skill"""
import sys, json, base64

sys.stdout.reconfigure(encoding='utf-8')

data = {
  "goals": [
    {
      "id": "g_bukao_baoyan",
      "title": "\u8865\u8003\u901a\u5173+\u4fdd\u7814\u57fa\u7840",
      "direction": "\u7efc\u5408\u7d20\u517b",
      "stage": "\u5927\u5b66",
      "progress": 0,
      "subGoals": [
        {"id": "sg1", "title": "\u9ad8\u4ee3I\u8865\u8003\u901a\u8fc7", "progress": 0, "status": "in_progress"},
        {"id": "sg2", "title": "\u6570\u5b66\u5206\u6790I\u8865\u8003\u901a\u8fc7", "progress": 0, "status": "in_progress"},
        {"id": "sg3", "title": "\u672c\u5b66\u671fGPA\u4e0d\u4f4e\u4e8e3.0", "progress": 0, "status": "not_started"},
        {"id": "sg4", "title": "\u9ad8\u4ee3II/\u6570\u5b66\u5206\u6790II\u671f\u672b80+", "progress": 0, "status": "not_started"}
      ]
    },
    {
      "id": "g_cert_plan",
      "title": "\u8bc1\u4e66\u8003\u8bd5\u89c4\u5212",
      "direction": "\u7efc\u5408\u7d20\u517b",
      "stage": "\u5927\u5b66",
      "progress": 5,
      "subGoals": [
        {"id": "sg5", "title": "\u82f1\u8bed\u56db\u7ea7(2026.6)", "progress": 10, "status": "in_progress"},
        {"id": "sg6", "title": "\u8ba1\u7b97\u673a\u4e8c\u7ea7(2026.9)", "progress": 0, "status": "not_started"},
        {"id": "sg7", "title": "\u82f1\u8bed\u516d\u7ea7(2027.6)", "progress": 0, "status": "not_started"},
        {"id": "sg8", "title": "\u666e\u901a\u8bdd(2027.7)", "progress": 0, "status": "not_started"},
        {"id": "sg9", "title": "\u6559\u5e08\u8d44\u683c\u8bc1(2027.10)", "progress": 0, "status": "not_started"}
      ]
    },
    {
      "id": "g_rutuan_rudang",
      "title": "\u5165\u56e2\u5165\u515a\u6d41\u7a0b",
      "direction": "\u7efc\u5408\u7d20\u517b",
      "stage": "\u5927\u5b66",
      "progress": 0,
      "subGoals": [
        {"id": "sg10", "title": "\u63d0\u4ea4\u5165\u56e2\u7533\u8bf7\u4e66", "progress": 0, "status": "not_started"},
        {"id": "sg11", "title": "\u53c2\u52a0\u56e2\u8bfe\u5b66\u4e60", "progress": 0, "status": "not_started"},
        {"id": "sg12", "title": "\u6210\u4e3a\u5165\u56e2\u79ef\u6781\u5206\u5b50", "progress": 0, "status": "not_started"},
        {"id": "sg13", "title": "\u6210\u4e3a\u5165\u515a\u79ef\u6781\u5206\u5b50", "progress": 0, "status": "not_started"}
      ]
    },
    {
      "id": "g_teacher_bianzhi",
      "title": "\u4fdd\u7814+\u6559\u5e08\u8003\u7f16\u53cc\u8f68",
      "direction": "\u8003\u7f16",
      "stage": "\u5927\u5b66",
      "progress": 0,
      "subGoals": [
        {"id": "sg14", "title": "GPA\u4fdd\u6301\u4e13\u4e1a\u524d20%", "progress": 0, "status": "not_started"},
        {"id": "sg15", "title": "\u53c2\u52a0\u6570\u5b66\u5efa\u6a21/\u6311\u6218\u676f\u7ade\u8d5b", "progress": 0, "status": "not_started"},
        {"id": "sg16", "title": "\u5b8c\u6210\u4fdd\u7814\u590f\u4ee4\u8425(\u5927\u4e09\u590f)", "progress": 0, "status": "not_started"},
        {"id": "sg17", "title": "\u6559\u8d44\u7b14\u8bd5+\u9762\u8bd5\u901a\u8fc7", "progress": 0, "status": "not_started"},
        {"id": "sg18", "title": "\u6559\u5e08\u7f16\u5236\u8003\u8bd5\u4e0a\u5cb8", "progress": 0, "status": "not_started"}
      ]
    }
  ],
  "templates": [
    {
      "id": "tpl_weekly_review",
      "title": "\u6bcf\u5468\u5b66\u4e60\u590d\u76d8",
      "tasks": [
        {"title": "\u6574\u7406\u672c\u5468\u9ad8\u4ee3II\u9519\u9898", "tag": "\u9ad8\u4ee3II", "priority": "high"},
        {"title": "\u6574\u7406\u672c\u5468\u6570\u5b66\u5206\u6790II\u9519\u9898", "tag": "\u6570\u5b66\u5206\u6790II", "priority": "high"},
        {"title": "\u5b8c\u6210Python\u8bfe\u8bbe\u672c\u5468\u8fdb\u5ea6", "tag": "Python", "priority": "med"},
        {"title": "\u590d\u4e60\u672c\u5468\u8bfe\u5802\u7b14\u8bb0", "tag": "\u7efc\u5408", "priority": "med"}
      ]
    },
    {
      "id": "tpl_cet4_daily",
      "title": "\u56db\u7ea7\u6bcf\u65e5\u5907\u8003",
      "tasks": [
        {"title": "\u80cc30\u4e2a\u56db\u7ea7\u5355\u8bcd", "tag": "\u82f1\u8bed\u56db\u7ea7", "priority": "med"},
        {"title": "\u505a1\u7bc7\u56db\u7ea7\u9605\u8bfb\u7406\u89e3", "tag": "\u82f1\u8bed\u56db\u7ea7", "priority": "med"},
        {"title": "\u542c1\u6bb5\u56db\u7ea7\u542c\u529b", "tag": "\u82f1\u8bed\u56db\u7ea7", "priority": "low"}
      ]
    },
    {
      "id": "tpl_makeup_prep",
      "title": "\u8865\u8003\u4e13\u9879\u590d\u4e60",
      "tasks": [
        {"title": "\u505a1\u5957\u9ad8\u4ee3I\u6a21\u62df\u5377", "tag": "\u9ad8\u4ee3I\u8865\u8003", "priority": "high"},
        {"title": "\u505a1\u5957\u6570\u5b66\u5206\u6790I\u6a21\u62df\u5377", "tag": "\u6570\u5b66\u5206\u6790I\u8865\u8003", "priority": "high"},
        {"title": "\u6574\u7406\u8865\u8003\u91cd\u70b9\u516c\u5f0f", "tag": "\u8865\u8003", "priority": "high"}
      ]
    }
  ],
  "tasks": [
    {"id": "t1", "title": "\u9ad8\u4ee3I\u8865\u8003\u62a5\u540d", "desc": "\u5173\u6ce8\u6559\u52a1\u5904\u8865\u8003\u901a\u77e5\uff0c\u53ca\u65f6\u62a5\u540d", "date": "2026-05-10", "priority": "high", "tag": "\u9ad8\u4ee3I\u8865\u8003", "course": "\u9ad8\u4ee3II", "done": False},
    {"id": "t2", "title": "\u6570\u5b66\u5206\u6790I\u8865\u8003\u62a5\u540d", "desc": "\u5173\u6ce8\u6559\u52a1\u5904\u8865\u8003\u901a\u77e5\uff0c\u53ca\u65f6\u62a5\u540d", "date": "2026-05-10", "priority": "high", "tag": "\u6570\u5b66\u5206\u6790I\u8865\u8003", "course": "\u6570\u5b66\u5206\u6790II", "done": False},
    {"id": "t3", "title": "\u9ad8\u4ee3I\u7b2c1-3\u7ae0\u590d\u4e60", "desc": "\u8865\u8003\u91cd\u70b9\uff1a\u591a\u9879\u5f0f\u3001\u884c\u5217\u5f0f\u3001\u77e9\u9635", "date": "2026-05-20", "priority": "high", "tag": "\u9ad8\u4ee3I\u8865\u8003", "course": "\u9ad8\u4ee3II", "done": False},
    {"id": "t4", "title": "\u9ad8\u4ee3I\u7b2c4-6\u7ae0\u590d\u4e60", "desc": "\u8865\u8003\u91cd\u70b9\uff1a\u7ebf\u6027\u65b9\u7a0b\u7ec4\u3001\u7279\u5f81\u503c\u3001\u4e8c\u6b21\u578b", "date": "2026-05-30", "priority": "high", "tag": "\u9ad8\u4ee3I\u8865\u8003", "course": "\u9ad8\u4ee3II", "done": False},
    {"id": "t5", "title": "\u6570\u5b66\u5206\u6790I\u7b2c1-3\u7ae0\u590d\u4e60", "desc": "\u8865\u8003\u91cd\u70b9\uff1a\u6781\u9650\u3001\u8fde\u7eed\u3001\u5bfc\u6570", "date": "2026-05-20", "priority": "high", "tag": "\u6570\u5b66\u5206\u6790I\u8865\u8003", "course": "\u6570\u5b66\u5206\u6790II", "done": False},
    {"id": "t6", "title": "\u6570\u5b66\u5206\u6790I\u7b2c4-6\u7ae0\u590d\u4e60", "desc": "\u8865\u8003\u91cd\u70b9\uff1a\u4e0d\u5b9a\u79ef\u5206\u3001\u5b9a\u79ef\u5206\u3001\u5fae\u5206\u65b9\u7a0b", "date": "2026-05-30", "priority": "high", "tag": "\u6570\u5b66\u5206\u6790I\u8865\u8003", "course": "\u6570\u5b66\u5206\u6790II", "done": False},
    {"id": "t7", "title": "\u82f1\u8bed\u56db\u7ea7\u62a5\u540d", "desc": "2026\u5e746\u6708\u8003\u8bd5\uff0c\u5173\u6ce8\u5b66\u6821\u62a5\u540d\u901a\u77e5", "date": "2026-04-30", "priority": "high", "tag": "\u82f1\u8bed\u56db\u7ea7", "course": "", "done": False},
    {"id": "t8", "title": "\u56db\u7ea7\u8bcd\u6c47\u5237\u5b8c\u6838\u5fc32000\u8bcd", "desc": "\u6bcf\u592930\u4e2a\u8bcd\uff0c\u7ea667\u5929\u5b8c\u6210", "date": "2026-05-31", "priority": "med", "tag": "\u82f1\u8bed\u56db\u7ea7", "course": "", "done": False},
    {"id": "t9", "title": "\u56db\u7ea7\u6a21\u62df\u8003\u8bd5(\u7b2c1\u6b21)", "desc": "\u5168\u771f\u6a21\u62df\uff0c\u4e25\u683c\u8ba1\u65f6", "date": "2026-05-18", "priority": "med", "tag": "\u82f1\u8bed\u56db\u7ea7", "course": "", "done": False},
    {"id": "t10", "title": "Python\u8bfe\u8bbe\u9700\u6c42\u5206\u6790", "desc": "\u786e\u5b9a\u8bfe\u8bbe\u9898\u76ee\u548c\u6280\u672f\u65b9\u6848", "date": "2026-05-15", "priority": "med", "tag": "Python\u8bfe\u8bbe", "course": "Python\u8bfe\u8bbe", "done": False},
    {"id": "t11", "title": "Python\u8bfe\u8bbe\u7f16\u7801\u5b8c\u6210", "desc": "\u5b8c\u6210\u8bfe\u8bbe\u6838\u5fc3\u529f\u80fd\u5f00\u53d1", "date": "2026-06-10", "priority": "med", "tag": "Python\u8bfe\u8bbe", "course": "Python\u8bfe\u8bbe", "done": False},
    {"id": "t12", "title": "\u63d0\u4ea4\u5165\u56e2\u7533\u8bf7\u4e66", "desc": "\u5411\u56e2\u7ec4\u7ec7\u63d0\u4ea4\u4e66\u9762\u5165\u56e2\u7533\u8bf7", "date": "2026-05-15", "priority": "med", "tag": "\u5165\u56e2\u5165\u515a", "course": "", "done": False},
    {"id": "t13", "title": "\u9ad8\u4ee3II\u671f\u4e2d\u590d\u4e60", "desc": "\u671f\u4e2d\u8003\u8bd5\u524d\u96c6\u4e2d\u590d\u4e60", "date": "2026-05-25", "priority": "high", "tag": "\u9ad8\u4ee3II", "course": "\u9ad8\u4ee3II", "done": False},
    {"id": "t14", "title": "\u6570\u5b66\u5206\u6790II\u671f\u4e2d\u590d\u4e60", "desc": "\u671f\u4e2d\u8003\u8bd5\u524d\u96c6\u4e2d\u590d\u4e60", "date": "2026-05-25", "priority": "high", "tag": "\u6570\u5b66\u5206\u6790II", "course": "\u6570\u5b66\u5206\u6790II", "done": False}
  ],
  "memos": [
    {"id": "m1", "title": "\u4fdd\u7814\u8981\u6c42\u53c2\u8003", "content": "\u5357\u901a\u5927\u5b66\u4fdd\u7814\u6761\u4ef6\uff1aGPA\u4e13\u4e1a\u524d20%+\u65e0\u6302\u79d1\u8bb0\u5f55+\u7ade\u8d5b/\u79d1\u7814\u52a0\u5206\u3002\u5927\u4e00\u6302\u79d1\u4e0d\u5f71\u54cd\u540e\u7eed\u4fdd\u7814\u8d44\u683c\uff0c\u4f46\u8865\u8003\u5fc5\u987b\u901a\u8fc7\u3002", "tag": "\u4fdd\u7814"},
    {"id": "m2", "title": "\u5165\u56e2\u5165\u515a\u6d41\u7a0b", "content": "\u5165\u56e2\uff1a\u9012\u4ea4\u7533\u8bf7\u2192\u56e2\u8bfe(8\u5b66\u65f6)\u2192\u56e2\u8bfe\u8003\u8bd5\u2192\u56e2\u652f\u90e8\u5927\u4f1a\u2192\u5165\u56e2\u5ba3\u8a93\u3002\u5165\u515a\u9700\u5148\u5165\u56e2\u6ee11\u5e74\uff0c\u518d\u8d70\u79ef\u6781\u5206\u5b50\u2192\u57f9\u517b\u2192\u9884\u5907\u2192\u8f6c\u6b63\u3002", "tag": "\u5165\u56e2\u5165\u515a"},
    {"id": "m3", "title": "\u56db\u7ea7\u5907\u8003\u5efa\u8bae", "content": "\u5efa\u8bae\u6bcf\u5929\u80cc30\u4e2a\u5355\u8bcd+1\u7bc7\u9605\u8bfb+1\u6bb5\u542c\u529b\u30025\u6708\u4e2d\u65ec\u5f00\u59cb\u505a\u771f\u9898\uff0c6\u6708\u51b2\u523a\u6a21\u8003\u3002\u91cd\u70b9\u7a81\u7834\u542c\u529b\u548c\u9605\u8bfb\u4e24\u5927\u9879\u3002", "tag": "\u82f1\u8bed\u56db\u7ea7"},
    {"id": "m4", "title": "\u8865\u8003\u7b56\u7565", "content": "\u9ad8\u4ee3I\u548c\u6570\u5b66\u5206\u6790I\u8865\u8003\u5efa\u8bae\uff1a\u5148\u6293\u57fa\u7840\u6982\u5ff5\u548c\u6838\u5fc3\u5b9a\u7406\uff0c\u518d\u505a\u5386\u5e74\u8865\u8003\u771f\u9898\u3002\u6bcf\u5929\u81f3\u5c112\u5c0f\u65f6\u4e13\u9879\u590d\u4e60\uff0c\u4f18\u5148\u653b\u7834\u8584\u5f31\u7ae0\u8282\u3002", "tag": "\u8865\u8003"},
    {"id": "m5", "title": "\u6559\u5e08\u8003\u7f16\u65f6\u95f4\u7ebf", "content": "\u6559\u5e08\u8003\u7f16\u4e00\u822c\u6d41\u7a0b\uff1a\u6559\u8d44\u7b14\u8bd5(10\u6708)\u2192\u9762\u8bd5(\u6b21\u5e741-3\u6708)\u2192\u8ba4\u5b9a(3-5\u6708)\u2192\u8003\u7f16\u516c\u544a(5-7\u6708)\u2192\u7b14\u8bd5\u9762\u8bd5\u3002\u4fdd\u7814\u548c\u8003\u7f16\u53ef\u4ee5\u5e76\u884c\u51c6\u5907\u3002", "tag": "\u8003\u7f16"},
    {"id": "m6", "title": "Python\u5b66\u4e60\u5efa\u8bae", "content": "\u9ad8\u7ea7\u7f16\u7a0bPython\u548cPython\u8bfe\u8bbe\u5efa\u8bae\uff1a\u591a\u5199\u4ee3\u7801\uff0c\u4ece\u7b80\u5355\u811a\u672c\u5f00\u59cb\uff0c\u9010\u6b65\u5b9e\u73b0\u8bfe\u8bbe\u529f\u80fd\u3002\u9047\u5230bug\u5584\u7528print\u8c03\u8bd5\u548c\u641c\u7d22\u5f15\u64ce\u3002", "tag": "Python"},
    {"id": "m7", "title": "\u793e\u4f1a\u5b9e\u8df5", "content": "\u6691\u671f\u793e\u4f1a\u5b9e\u8df5\u662f\u4fdd\u7814\u52a0\u5206\u9879\uff0c\u5efa\u8bae\u5173\u6ce8\u5b66\u6821\u56e2\u59d4\u901a\u77e5\uff0c\u63d0\u524d\u7ec4\u961f\u3002\u53ef\u9009\u62e9\u652f\u6559\u3001\u8c03\u7814\u3001\u5fd7\u613f\u670d\u52a1\u7b49\u5f62\u5f0f\u3002", "tag": "\u793e\u4f1a\u5b9e\u8df5"}
  ]
}

# Stats
goals_count = len(data["goals"])
templates_count = len(data["templates"])
tasks_count = len(data["tasks"])
memos_count = len(data["memos"])
subgoals_count = sum(len(g.get("subGoals", [])) for g in data["goals"])
print(f"[OK] Data generated: {goals_count} goals ({subgoals_count} sub-goals), {templates_count} templates, {tasks_count} tasks, {memos_count} memos")

# zlib压缩 + base64url编码（压缩率约29%，解决URL过长问题）
import zlib
json_str = json.dumps(data, ensure_ascii=False)
compressed = zlib.compress(json_str.encode(), 9)
encoded = base64.urlsafe_b64encode(compressed).decode().rstrip('=')
url = f"https://gpt.cntaxs.com/stustar-api/ai-plan-inject.html?zdata={encoded}"
print(f"[OK] Inject URL length: {len(url)} chars")
print(f"[INFO] Data: {len(json_str)} bytes -> zlib: {len(compressed)} bytes -> base64url: {len(encoded)} chars")
print(f"[INFO] Compression ratio: {len(encoded)/len(json_str)*100:.1f}%")

# Save URL to file for easy access
with open(r"e:\AIwork\student-goal-task-manager-git\inject_test_url.txt", "w", encoding="utf-8") as f:
    f.write(url)
print(f"[OK] URL saved to inject_test_url.txt")

# Also save raw JSON for reference
with open(r"e:\AIwork\student-goal-task-manager-git\inject_test_data.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
print(f"[OK] Raw JSON saved to inject_test_data.json")
