# Frontend Review — Common Definitions

## Severity Levels

- **P0**: 安全漏洞（XSS、eval、硬编码密钥）、系统崩溃、数据丢失
- **P1**: 外部数据使用 `any`、空 catch 块、悬空 Promise、组件内直接调用 fetch/axios、API Key 暴露在 bundle
- **P2**: 缺少显式返回类型、魔法值、嵌套 > 3 层、函数 > 50 行、index 作 key、DRY 违规、状态管理选型错误
- **Nit**: 命名建议、缺少 JSDoc、注释风格、细节改进

## Frontend Review Dimensions

| Dimension | Checklist |
|-----------|-----------|
| **typescript** | 禁止 `any`（含函数参数/返回值/变量）、缺少显式返回类型、`@ts-ignore` 使用、普通 `enum`（应用联合类型替代）、泛型命名不语义化 |
| **async-error** | 缺少 `try/catch` 的异步函数、空 catch 块、悬空 Promise、组件内直接调用 `fetch`/`axios`、可并发的串行 `await` |
| **code-structure** | 函数超 50 行、嵌套超 3 层（未用 Early Return）、多重三元（超 2 层）、魔法值（硬编码数字/字符串未定义常量） |
| **naming** | 变量/函数非 camelCase、组件/Interface/Type 非 PascalCase、布尔变量缺 is/has/can/should 前缀、Hook 缺 use 前缀、事件 Prop 缺 on 前缀、无意义命名 |
| **component-design** | Props 超 7 个未拆分、直接修改 props、index 作 key、render 内创建新对象/数组、组件 JSX 超 100 行、多字段散落调用处（应传整个对象） |
| **dry-reuse** | 相同逻辑 ≥2 次未封装为 Hook/组件/utils、重复 CSS 类定义 |
| **state-management** | 服务端数据存入 Redux/Zustand（应用 React Query/SWR）、Context 用于高频更新、状态选型与作用范围不匹配 |
| **security** | dangerouslySetInnerHTML/innerHTML 使用未净化数据、eval/new Function、硬编码密钥/Token、敏感数据写入 localStorage、用户输入未校验直接拼接 URL/HTML |
| **imports** | 全量引入大型库、新增依赖未评估包体积/维护状态/License/TS 支持 |
| **comments** | 公共函数/组件缺 JSDoc、行内注释说"是什么"而非"为什么"、临时代码未标注 TODO/FIXME |
| **accessibility** | 交互元素缺语义化标签或 `aria-label`（P1）、图片缺 `alt`、表单控件未关联 `<label>`、仅依赖鼠标事件缺键盘支持、颜色对比度不足 4.5:1 |
| **hooks-correctness** | `useEffect` deps 包含非稳定引用（对象/函数字面量）导致无限循环（P0）、unmount 后 setState（缺少 cleanup 或 isMounted 检查）（P1）、闭包陷阱（setTimeout/setInterval 内引用 state 未用 `useRef` 或函数式更新）（P1）、`useCallback`/`useMemo` deps 缺失或多余 |
| **memory-leak** | `addEventListener` 无对应 `removeEventListener`（P1）、`setInterval`/`setTimeout` 无 `clearInterval`/`clearTimeout`（P1）、RxJS/EventEmitter subscription 未 unsubscribe（P1）、`useEffect` 内异步订阅无 cleanup 返回 |
| **null-safety** | 深层属性访问未使用可选链 `?.`（如 `data.user.name` 可能崩溃）（P1）、数组方法调用前未检查非空（`list.map` 在 `list` 可能为 `null` 时）（P1）、`as` 类型断言绕过 null 检查（P2） |
| **css-quality** | `!important` 滥用（P2）、硬编码颜色值未使用 CSS 变量（P2）、`z-index` 无规划（魔法值，应用 CSS 变量管理层级）（P2）、`<img>` 缺少 `width`/`height` 导致 CLS（P2） |
| **async-race** | 并发请求无取消机制（缺 `AbortController` 或 React Query 的 `enabled` 控制）导致竞态条件（P1）、`useEffect` 内异步请求无清理导致过期响应覆盖最新状态（P1）、直接 `.push`/`.splice` 修改 state 数组/对象而非返回新引用（P1） |

## Merge Gate

- **Ready**: 无 P0/P1；P2/Nit sweep 策略在 precommit 前适用
- **Blocked**: 有 P0/P1，需修复后重新评审

## Codex Independent Research (Required)

Codex **必须**自行研究项目，不能仅依赖提供的 diff/上下文：

### Git Exploration (Priority)
1. 检查变更状态：`git status`
2. 读取完整 diff：`git diff HEAD`
3. 逐文件读取 diff：`git diff HEAD -- <file-path>`
4. 读取变更文件完整内容：`cat <changed file> | head -200`

### Frontend Project Research
- 检测框架：`cat package.json | grep -E '"react"|"vue"|"svelte"|"solid"'`
- 检查 bundle 配置：`ls -la | grep -E 'bundlesize|size-limit|webpack|vite|rollup'`
- 搜索组件调用：`grep -r "ComponentName" src/ -l --include="*.tsx" --include="*.vue" | head -10`
- 检查 CSS 变量定义：`grep -r "var(--" src/ -l | head -10`

## Three-Source Aggregation

Sources: Codex + reviewer-framework (`references/reviewer-framework.md`) + diff security findings (Step 1)

### Severity Mapping

**reviewer-framework → standard**:

| reviewer-framework severity | Standard Mapping | Upgrade Condition |
|-----------------------------|------------------|-------------------|
| `critical` | P1 | 含 P0 关键词 → P0 |
| `major` | P1 | — |
| `minor` | P2 | — |
| `suggestion` | Nit | — |

**diff security findings → standard**:

| diff severity | Standard Mapping |
|---------------|-----------------|
| `warning` (security) | P1 |
| `warning` (non-security) | P2 |
| `info` | Nit |

**P0 关键词**: XSS, dangerouslySetInnerHTML unsanitized, eval, new Function, crash, data loss, security vulnerability, auth bypass, infinite render loop, useEffect infinite loop

### Deduplication Algorithm

| Step | Rule |
|------|------|
| Key | `canonical_file_path + canonical_issue_text` |
| 行号容差 | ±5 行（忽略行号差异） |
| 冲突解决 | 同 key → 保留最高严重级别（P0 > P1 > P2 > Nit） |
| Source 合并 | 两个 reviewer 都报告同一 key → `source = "both"` |

### Degradation Matrix

| 场景 | 行为 | Gate Source |
|------|------|-------------|
| Codex ✅ + framework ✅ | 三源联合聚合 | `codex+framework` |
| Codex ✅ + framework ❌ | Codex + diff-analyzer + 降级警告 | `codex-only` |
| Codex ❌ + framework ✅ | framework + diff-analyzer + 降级警告 | `framework-only` |
| Both ❌ | `⛔ Blocked` + `⚠️ Need Human` | `none` |

### Source Attribution

| Source | 含义 |
|--------|------|
| `codex` | 仅 Codex 发现 |
| `framework` | 仅 reviewer-framework 发现 |
| `diff-analyzer` | 仅 diff 安全扫描（Step 1）发现 |
| `both` | Codex + framework 均发现（去重后） |
| `all` | 三源均发现 |

## Output Findings Format

每个 P 级单独一张表，无发现时省略该表。

```markdown
#### ⛔ P0 — Must Fix (Merge Blocked)

| 文件:行 | 问题 | 修复建议 | 来源 |
|---------|------|---------|------|
| `<file:line>` | <issue description> | <fix recommendation> | codex|framework|diff-analyzer|both|all |

#### 🔴 P1 — Should Fix

| 文件:行 | 问题 | 修复建议 | 来源 |
|---------|------|---------|------|
| `<file:line>` | <issue description> | <fix recommendation> | ... |

#### 🟡 P2 — Nice to Fix

| 文件:行 | 问题 | 修复建议 | 来源 |
|---------|------|---------|------|
| `<file:line>` | <issue description> | <fix recommendation> | ... |

#### 💬 Nit

| 文件:行 | 问题 | 修复建议 | 来源 |
|---------|------|---------|------|
| `<file:line>` | <issue description> | <fix recommendation> | ... |
```

## Gate Sentinels

Hook gate 通过 `bash scripts/emit-review-gate.sh READY|BLOCKED` 触发（写入 `.review-gate.json`）。

文本 sentinel 用于行为层（auto-loop）和视觉确认：
- `✅ Ready` — 通过（无 P0/P1）
- `⛔ Blocked` — 阻断（有 P0/P1，需修复）

> 注意：始终同时 emit：(1) `emit-review-gate.sh` 写文件，(2) 文本 sentinel 输出到对话。

## Re-review Prompt Template

Loop 场景下使用 `mcp__codex__codex-reply`：

```typescript
mcp__codex__codex-reply({
  threadId: '<from --continue parameter>',
  prompt: `I have fixed the previously identified issues. Please re-review:

## ${LOCAL_CHECKS ? 'Local Check Results\n' + LOCAL_CHECKS + '\n\n##' : ''} New Git Diff
\`\`\`diff
${GIT_DIFF}
\`\`\`

Please verify:
1. Have previous P0/P1 issues been correctly fixed?
2. Did fixes introduce new issues?
3. Update Merge Gate status
4. For P2/Nit items: are they resolved? List any remaining with status.`,
});
```

## Loop Termination Rules

- 同一问题连续 **3 轮**未修复 → 报告阻塞，请求人工介入
- 全局最大迭代次数：**5 轮**
- 任何代码编辑重置 reviewer-framework（Codex 保持 threadId 续接）
- per-issue 计数在问题解决后重置

## P2/Nit Post-Ready Sweep

返回 Ready 但有 P2/Nit 时：
1. 批量修复所有 P2/Nit（1 次尝试）
2. `--continue <threadId>` 重新评审验证
3. 未解决 P2 → `⚠️ Need Human`；未解决 Nit → `[NIT_DEFERRED]` 日志豁免；全部解决 → `/precommit`

## Review Loop (Dual Mode)

| Reviewer | Loop 行为 |
|----------|-----------|
| Codex MCP（via retry-executor，见 `references/retry-executor.md`） | 有状态 → `mcp__codex__codex-reply(threadId)` 续接上下文 |
| reviewer-framework（见 `references/reviewer-framework.md`） | 每轮重新调用（fresh context），无状态续接 |

Codex gate 为权威时间基准。reviewer-framework 非阻塞后台运行。任何代码编辑重置两个 reviewer。
