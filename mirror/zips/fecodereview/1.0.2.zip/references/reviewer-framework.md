# Reviewer Framework

通用可配置评审框架。根据传入的评审维度和内容执行结构化评审，输出 JSON 格式的评审报告。

## Inputs

| 参数 | 必填 | 说明 |
|------|------|------|
| `target_content` | 是 | 待评审内容（代码 diff） |
| `review_dimensions` | 是 | 评审维度列表 |
| `context` | 否 | 评审上下文（需求描述、技术方案等） |
| `severity_threshold` | 否 | 最低严重级别：`critical`/`major`/`minor`/`suggestion`，默认 `minor` |
| `output_format` | 否 | 输出格式：`json`/`markdown`/`inline`，默认 `markdown` |
| `max_issues` | 否 | 最大 issue 数量限制 |

## 内置评审维度集

| 维度集 | 包含检查点 |
|--------|-----------|
| `typescript` | 禁止 `any`（含函数参数/返回值/变量）、缺少显式返回类型、`@ts-ignore` 使用（应改 `@ts-expect-error`）、普通 `enum`（应用联合类型替代）、泛型命名不语义化 |
| `async-error` | 缺少 `try/catch` 的异步函数、空 catch 块、悬空 Promise（floating promise）、组件内直接调用 `fetch`/`axios`（应通过 API 层） |
| `code-structure` | 函数超 50 行、嵌套超 3 层（未用 Early Return）、多重三元（超 2 层）、魔法值（硬编码数字/字符串未定义常量） |
| `naming` | 变量/函数非 camelCase、组件/Interface/Type 非 PascalCase、布尔变量缺 is/has/can/should 前缀、自定义 Hook 缺 use 前缀、事件回调 Props 缺 on 前缀、无意义命名（a、data2、handle） |
| `component-design` | Props 超 7 个未拆分/使用 Context、直接修改 props、列表渲染用 index 作 key、render 内创建新对象/数组作 props、组件 JSX 超 100 行 |
| `dry-reuse` | 相同逻辑出现 ≥2 次未封装为 Hook/组件/utils、同一对象多字段散落在调用处（应传整个对象）、重复 CSS 类定义 |
| `state-management` | 服务端数据存入 Redux/Zustand（应用 React Query/SWR）、Context 用于高频更新数据、状态作用范围与选型不匹配 |
| `security` | `dangerouslySetInnerHTML` 使用未净化数据、`eval()`/`new Function()`、硬编码密钥/Token/API Key、敏感信息写入 localStorage、用户输入未校验直接拼接 URL/HTML |
| `imports` | 全量引入大型库（lodash、antd icons 等）、新增依赖未评估包体积/维护状态/License/TS 支持 |
| `comments` | 公共函数/组件缺 JSDoc、行内注释说"是什么"而非"为什么"、临时代码未标注 TODO/FIXME |
| `accessibility` | 交互元素（按钮、链接、表单）缺语义化标签或 `aria-label`、图片缺 `alt`、表单控件未关联 `<label>`、仅依赖鼠标事件（缺键盘支持）、颜色对比度不足 4.5:1 |
| `hooks-correctness` | `useEffect` deps 包含非稳定引用（对象/函数字面量）导致无限循环、unmount 后 setState（缺少 cleanup 或 isMounted 检查）、闭包陷阱（setTimeout/setInterval 内引用 state 未用 `useRef` 或函数式更新）、`useCallback`/`useMemo` deps 缺失或多余 |
| `memory-leak` | `addEventListener` 无对应 `removeEventListener`、`setInterval`/`setTimeout` 无 `clearInterval`/`clearTimeout`、RxJS/EventEmitter subscription 未 unsubscribe、`useEffect` 内异步订阅无 cleanup 返回 |
| `null-safety` | 深层属性访问未使用可选链 `?.`（如 `data.user.name` 可能崩溃）、数组方法调用前未检查非空（`list.map` 在 `list` 可能为 `null` 时）、`as` 类型断言绕过 null 检查 |
| `css-quality` | `!important` 滥用、硬编码颜色值未使用 CSS 变量、`z-index` 无规划（魔法值，应用 CSS 变量管理层级）、`<img>` 缺少 `width`/`height` 导致 CLS |
| `async-race` | 并发请求无取消机制（缺 `AbortController` 或 React Query 的 `enabled` 控制）导致竞态条件、`useEffect` 内异步请求无清理导致过期响应覆盖最新状态、直接 `.push`/`.splice` 修改 state 数组/对象而非返回新引用 |

## 执行流程

### Step 1: 解析评审配置

1. 读取 `review_dimensions`，展开为具体检查点列表
2. 按 weight 排序，高权重维度优先评审
3. 应用 `severity_threshold` 过滤

### Step 2: 理解评审上下文

1. 读取 `context`，理解变更背景和技术约束
2. 建立评审基线：哪些变更是预期的，哪些是意外的

### Step 3: 逐维度评审

对每个维度按检查点逐条扫描，识别问题时记录：
- 问题位置（`file:line`）
- 问题描述（简洁明确）
- 严重程度（`critical`/`major`/`minor`/`suggestion`）
- 修复建议（可操作的具体建议）

### Step 4: 交叉验证

1. 检查不同维度间是否有冲突建议
2. 去重（同类问题只报告一次）
3. 检查是否遗漏明显问题

### Step 5: 生成报告

按 `output_format` 生成报告。

## Output Format（JSON）

```json
{
  "summary": {
    "total_issues": 8,
    "critical": 1,
    "major": 3,
    "minor": 2,
    "suggestion": 2,
    "overall_score": 72,
    "verdict": "needs_revision"
  },
  "dimensions": [
    {
      "name": "typescript",
      "score": 60,
      "issues": [
        {
          "severity": "major",
          "location": "src/api/user.ts:12",
          "description": "函数参数和返回值使用了 any，违反 TypeScript 严格规范",
          "suggestion": "将参数类型改为具体类型或 unknown，并添加显式返回类型",
          "evidence": "function getUser(id: any): any {}"
        }
      ]
    }
  ],
  "highlights": {
    "good_practices": ["错误处理完整", "组件 Props 类型定义清晰"],
    "concerns": ["多处 any 类型", "缺少 try/catch"]
  },
  "verdict": {
    "decision": "needs_revision",
    "blocking_issues": ["dangerouslySetInnerHTML XSS 风险"],
    "message": "发现 1 个 critical 级别问题需要修复后重新评审"
  }
}
```

## Verdict 决策逻辑

| 条件 | Verdict |
|------|---------|
| 有 critical issue | `reject` |
| 有 major issue 且 > 3 个 | `needs_revision` |
| 仅 minor + suggestion | `approve_with_comments` |
| 无任何 issue | `approve` |

## Severity → P 级映射（用于三源聚合）

见 `references/review-common.md § Three-Source Aggregation`。

## Guidelines

- **客观严谨**：基于代码证据，不做主观臆断
- **具体可操作**：每条建议必须包含具体修改方案
- **区分严重级别**：合理区分优先级，不要把所有问题都标为 critical
- **给出正面反馈**：好的实践也要指出
- **避免重复**：同类问题只报告一次，附带"此类问题在 N 处出现"
