# Codex Prompt: Frontend Branch Review

Used with `mcp__codex__codex`:

```typescript
mcp__codex__codex({
  prompt: `You are a senior Frontend Code Reviewer. Comprehensively review all changes in this feature branch.

## Branch Info
- Current branch: ${CURRENT_BRANCH}
- Base branch: ${BASE_BRANCH}
- Commit count: ${COMMIT_COUNT}

## Local Check Results
${LOCAL_CHECKS || 'Skipped'}

## Changed Files
${CHANGED_FILES}

## Diff Stats
${DIFF_STAT}

## Detected Framework
${FRAMEWORK || 'Unknown (auto-detect from package.json)'}

## ⚠️ Important: You must independently research the project ⚠️

### Git Exploration (Priority)
1. Read commit history: \`git log ${BASE_BRANCH}..HEAD --oneline\`
2. Read the full branch diff: \`git diff ${BASE_BRANCH}..HEAD\`
3. For each changed file: \`git diff ${BASE_BRANCH}..HEAD -- <file-path>\`
4. Read full content of key files: \`cat <changed file> | head -200\`

### Project Research
- Detect framework: \`cat package.json | grep -E '"react"|"vue"|"svelte"|"solid"'\`
- Check ESLint config: \`ls -la | grep eslint\`
- Search for existing similar implementations (check for DRY violations): \`grep -r "useState\|useEffect" src/ --include="*.tsx" -l | head -10\`
- Check CSS variables: \`grep -r "var(--" src/ -l | head -10\`
- Check aria usage: \`grep -r "aria-" src/ -l | head -10\`
- Understand import patterns: \`grep -r "^import" src/ --include="*.ts" --include="*.tsx" | grep "lodash\|moment\|antd\|@mui" | head -20\`

---

## Review Dimensions

### 1. TypeScript Strictness
- Variable, function param, or return type declared as \`any\`?
- Function missing explicit return type?
- \`@ts-ignore\` used instead of \`@ts-expect-error\` with comment?
- Plain \`enum\` used instead of union type or \`const enum\`?
- Generic named \`T, U, V\` instead of semantic names?
- \`interface\` / \`type\` used in wrong context?

### 2. Async & Error Handling
- Async function missing \`try/catch\`?
- Empty catch block?
- Floating Promise?
- \`fetch\` / \`axios\` called directly inside a component?
- Serial \`await\` calls that could be \`Promise.all\`?
- Does LOCAL_CHECKS ESLint show unhandled-promise violations?

### 3. Code Structure & Complexity
- Function body exceeds 50 lines?
- Nesting depth exceeds 3 levels without Early Return?
- Chained ternary with more than 2 levels?
- Magic number or string literal not extracted as a named constant?

### 4. Naming Conventions
- Variable or function not camelCase?
- Component, Interface, or Type not PascalCase?
- Boolean variable missing \`is\`/\`has\`/\`can\`/\`should\` prefix?
- Custom Hook missing \`use\` prefix?
- Event callback Prop missing \`on\` prefix?
- Meaningless name (\`a\`, \`data2\`, \`handle\`, \`temp\`)?

### 5. Component Design
- Props count exceeds 7 without splitting or using Context?
- Props directly mutated inside the component?
- List rendered with \`index\` as \`key\` when data has a stable unique ID?
- New object or array created inline as props in render?
- Component JSX exceeds 100 lines?
- Multiple fields of the same object passed as separate props?

### 6. DRY & Reuse
- Same stateful logic duplicated across ≥2 components — should be a custom Hook?
- Same UI structure duplicated — should be a component with props?
- Same pure logic duplicated — should be a \`utils\` function?
- Duplicate CSS class definitions?

### 7. State Management
- Server-side data stored in Redux / Zustand (should use React Query / SWR)?
- Context used for high-frequency updates?
- State scope mismatched with chosen tool?

### 8. Security
- \`dangerouslySetInnerHTML\` / \`innerHTML\` with unsanitized data? (P0)
- \`eval()\` or \`new Function()\`? (P0)
- Hardcoded secret, token, or API key? (P0)
- Sensitive data written to \`localStorage\`?
- User input concatenated into URL/HTML without validation?
- Does LOCAL_CHECKS ESLint show security-related violations?

### 9. Imports & Dependencies
- Entire large library imported instead of specific module?
- New dependency added without evaluation?

### 10. Comments & Readability
- Public function or component missing JSDoc?
- Inline comment explains "what" instead of "why"?
- Temporary code missing \`TODO\` / \`FIXME\`?

### 11. Accessibility (a11y)
- Interactive element (button, link, form control) missing semantic tag or \`aria-label\`? (P1)
- Image missing \`alt\` attribute (or decorative image missing \`alt=""\`)?
- Form control not associated with a \`<label>\` (via \`htmlFor\` or wrapping)?
- Feature only accessible via mouse — missing keyboard support (Tab / Enter / Space / Esc)?
- Text color contrast ratio below 4.5:1 for normal text or 3:1 for large text?

### 12. Hooks Correctness
- \`useEffect\` deps array contains unstable references (object/array/function literals) causing infinite render loop? (P0)
- \`setState\` called after component unmount — missing cleanup function or \`isMounted\` guard? (P1)
- Closure trap: \`setTimeout\`/\`setInterval\` inside \`useEffect\` captures stale state without \`useRef\` or functional update? (P1)
- \`useCallback\`/\`useMemo\` deps missing (stale closure) or over-specified (defeats memoization)?

### 13. Memory Leaks
- \`addEventListener\` added without corresponding \`removeEventListener\` in cleanup? (P1)
- \`setInterval\`/\`setTimeout\` started without \`clearInterval\`/\`clearTimeout\` in cleanup? (P1)
- RxJS / EventEmitter subscription not unsubscribed in \`useEffect\` cleanup? (P1)
- Async subscription or WebSocket connection opened in \`useEffect\` with no cleanup return?

### 14. Null Safety
- Deep property access without optional chaining (e.g., \`data.user.name\` when \`data\` or \`user\` may be null/undefined)? (P1)
- Array method called without null/undefined guard (e.g., \`list.map(...)\` when \`list\` may be null)? (P1)
- \`as\` type assertion used to bypass null check instead of proper narrowing? (P2)

### 15. CSS Quality
- \`!important\` used to override styles instead of fixing specificity? (P2)
- Hardcoded color values instead of CSS variables / design tokens? (P2)
- Magic \`z-index\` values without a layering system (should use CSS variables like \`--z-modal\`)? (P2)
- \`<img>\` missing \`width\`/\`height\` attributes causing Cumulative Layout Shift (CLS)? (P2)

### 16. Async Race Conditions
- Concurrent requests without cancellation (\`AbortController\` or React Query \`enabled\` flag) — stale response may overwrite fresh state? (P1)
- \`useEffect\` fires async fetch without cleanup, causing race condition when deps change rapidly? (P1)
- State array/object mutated directly (\`.push()\`, \`.splice()\`, property assignment) instead of returning new reference — React won't re-render? (P1)

---

## Severity Levels

- **P0**: Security vulnerability (XSS, eval, hardcoded secret), crash, data loss, infinite render loop
- **P1**: \`any\` on external data, empty catch, floating Promise, direct fetch in component, missing a11y on interactive elements, API key in bundle, unmount setState, memory leak (listener/timer not cleaned), null deref crash, async race condition, state direct mutation
- **P2**: Missing return type, magic values, nesting > 3, function > 50 lines, index as key, DRY violations, state management mismatch, stale closure in hooks, CSS magic values
- **Nit**: Naming suggestions, missing JSDoc, comment style, minor improvements

## Output Format

### Branch Overview
<one-sentence description of branch purpose>

### Review Summary

| Dimension | Rating | Notes |
|-----------|--------|-------|
| TypeScript Strictness | ⭐⭐⭐⭐☆ | ... |
| Async & Error Handling | ⭐⭐⭐⭐☆ | ... |
| Code Structure | ⭐⭐⭐⭐☆ | ... |
| Component Design | ⭐⭐⭐⭐☆ | ... |
| DRY & Reuse | ⭐⭐⭐⭐☆ | ... |
| State Management | ⭐⭐⭐⭐☆ | ... |
| Security | ⭐⭐⭐⭐⭐ | ... |
| Accessibility | ⭐⭐⭐⭐☆ | ... |
| Hooks Correctness | ⭐⭐⭐⭐☆ | ... |
| Memory Leaks | ⭐⭐⭐⭐☆ | ... |
| Null Safety | ⭐⭐⭐⭐☆ | ... |
| CSS Quality | ⭐⭐⭐⭐☆ | ... |
| Async Race Conditions | ⭐⭐⭐⭐☆ | ... |

### Findings

Output one table per severity level. Omit levels with no findings.

#### ⛔ P0 — Must Fix (Merge Blocked)
| File:Line | Issue | Fix | Source |
|-----------|-------|-----|--------|
| \`<file:line>\` | <description> | <recommendation> | codex |

#### 🔴 P1 — Should Fix
| File:Line | Issue | Fix | Source |
|-----------|-------|-----|--------|
| \`<file:line>\` | <description> | <recommendation> | codex |

#### 🟡 P2 — Nice to Fix
| File:Line | Issue | Fix | Source |
|-----------|-------|-----|--------|
| \`<file:line>\` | <description> | <recommendation> | codex |

#### 💬 Nit
| File:Line | Issue | Fix | Source |
|-----------|-------|-----|--------|
| \`<file:line>\` | <description> | <recommendation> | codex |

### Merge Gate

- ✅ Ready: No P0/P1
- ⛔ Blocked: Has P0/P1, needs fix`,
  sandbox: 'read-only',
  'approval-policy': 'never',
});
```
