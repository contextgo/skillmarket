#!/usr/bin/env bash
# emit-review-gate.sh - Emit review gate state
# Usage: emit-review-gate.sh <STATE>
# STATE: PENDING | READY | BLOCKED
#
# Optional env vars for rich state.json:
#   BRANCH_NAME       - git branch name (auto-detected if unset)
#   REVIEW_MODE       - "dual" | "codex-only" | "framework-only" (default: "dual")
#   ITERATION         - current review loop iteration (default: 0)
#   CODEX_THREAD_ID   - Codex threadId for loop continuation (default: null)
#   GATE_SOURCE       - "codex+framework" | "codex-only" | "framework-only" (default: "")
#   P0_COUNT          - P0 findings count (default: 0)
#   P1_COUNT          - P1 findings count (default: 0)
#   P2_COUNT          - P2 findings count (default: 0)
#   NIT_COUNT         - Nit findings count (default: 0)

set -euo pipefail

STATE="${1:-PENDING}"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
GATE_FILE="${GATE_FILE:-.review-gate.json}"

# Validate GATE_FILE is a local .json file (prevent path injection via env var)
if [[ "$GATE_FILE" != *.json ]]; then
  echo "Error: GATE_FILE must end with .json" >&2
  exit 1
fi

case "$STATE" in
  PENDING|READY|BLOCKED)
    ;;
  *)
    echo "Usage: $0 <PENDING|READY|BLOCKED>" >&2
    exit 1
    ;;
esac

# --- Write simple gate file (backward compat) ---
# STATE is whitelist-validated above; TIMESTAMP is system-controlled date output — safe for direct interpolation
echo "{ \"state\": \"$STATE\", \"timestamp\": \"$TIMESTAMP\" }" > "$GATE_FILE"
echo "[review-gate] State set to: $STATE (written to $GATE_FILE)"

# --- Write rich state.json ---
BRANCH_NAME="${BRANCH_NAME:-$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "unknown")}"
REVIEW_MODE="${REVIEW_MODE:-dual}"
ITERATION="${ITERATION:-0}"
CODEX_THREAD_ID="${CODEX_THREAD_ID:-}"
GATE_SOURCE="${GATE_SOURCE:-}"
P0_COUNT="${P0_COUNT:-0}"
P1_COUNT="${P1_COUNT:-0}"
P2_COUNT="${P2_COUNT:-0}"
NIT_COUNT="${NIT_COUNT:-0}"

STATE_DIR="${HOME}/.pipeline-ai-workflow/frontend-code-review/${BRANCH_NAME}"
STATE_FILE="${STATE_DIR}/state.json"

mkdir -p "$STATE_DIR"

# Determine status and executed flag from STATE
if [[ "$STATE" == "PENDING" ]]; then
  STATUS="running"
  EXECUTED="false"
else
  STATUS="completed"
  EXECUTED="true"
fi

# Encode CODEX_THREAD_ID as JSON null or quoted string
if [[ -z "$CODEX_THREAD_ID" ]]; then
  THREAD_JSON="null"
else
  THREAD_JSON="\"${CODEX_THREAD_ID}\""
fi

# Encode GATE_SOURCE as JSON null or quoted string
if [[ -z "$GATE_SOURCE" ]]; then
  SOURCE_JSON="null"
else
  SOURCE_JSON="\"${GATE_SOURCE}\""
fi

# Read existing created_at if state file already exists, otherwise use current timestamp
if [[ -f "$STATE_FILE" ]]; then
  # Extract created_at from existing file; fall back to current timestamp if extraction fails
  CREATED_AT=$(grep -o '"created_at": *"[^"]*"' "$STATE_FILE" 2>/dev/null | sed 's/.*: *"\([^"]*\)"/\1/' || echo "$TIMESTAMP")
else
  CREATED_AT="$TIMESTAMP"
fi

cat > "$STATE_FILE" <<EOF
{
  "_meta": {
    "created_at": "${CREATED_AT}",
    "updated_at": "${TIMESTAMP}",
    "namespace": "frontend-code-review/${BRANCH_NAME}"
  },
  "status": "${STATUS}",
  "data": {
    "review_mode": "${REVIEW_MODE}",
    "aggregate_gate": {
      "executed": ${EXECUTED},
      "gate": "${STATE}",
      "source": ${SOURCE_JSON},
      "findings_count": { "P0": ${P0_COUNT}, "P1": ${P1_COUNT}, "P2": ${P2_COUNT}, "Nit": ${NIT_COUNT} }
    },
    "iteration": ${ITERATION},
    "codex_thread_id": ${THREAD_JSON},
    "secondary_status": "pending"
  }
}
EOF

echo "[review-gate] State persisted to: ${STATE_FILE}"
