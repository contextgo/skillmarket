#!/usr/bin/env python3
"""
按用户提供截图模板生成报价单（3列商品卡片布局）
"""

from __future__ import annotations

import os
from datetime import datetime
from typing import Any, Dict, List

import xlsxwriter

from image_handler import process_image_for_excel
from web_access_1688_scraper import scrape_shop_offers


def build_template_quote(products: List[Dict[str, Any]], output_path: str) -> str:
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    wb = xlsxwriter.Workbook(output_path)
    ws = wb.add_worksheet("Quotation")

    # A-I 三组商品列：A-C / D-F / G-I
    ws.set_column("A:A", 24)
    ws.set_column("B:B", 6)
    ws.set_column("C:C", 8)
    ws.set_column("D:D", 24)
    ws.set_column("E:E", 6)
    ws.set_column("F:F", 8)
    ws.set_column("G:G", 24)
    ws.set_column("H:H", 6)
    ws.set_column("I:I", 8)

    blue = wb.add_format({"bold": True, "font_color": "white", "bg_color": "#0B2E73", "align": "center", "valign": "vcenter", "font_size": 20})
    subtitle = wb.add_format({"bold": True, "align": "center", "valign": "vcenter", "font_size": 14, "font_color": "#0B2E73"})
    label = wb.add_format({"bold": True, "font_color": "#0B2E73", "font_size": 12})
    normal = wb.add_format({"font_size": 12, "font_color": "#1b2a4a"})
    section = wb.add_format({"bold": True, "font_size": 18, "font_color": "#0B2E73", "align": "center", "valign": "vcenter"})
    sku_fmt = wb.add_format({"bold": False, "font_size": 16, "align": "center", "valign": "vcenter"})
    price_fmt = wb.add_format({"bold": False, "font_size": 16, "align": "center", "valign": "vcenter", "num_format": '"$"#,##0.00'})
    price_blank_fmt = wb.add_format({"font_size": 16, "align": "center", "valign": "vcenter"})
    card_border = wb.add_format({"border": 1, "border_color": "#2f2f2f"})

    # 顶部头
    ws.merge_range("A1:I1", "DongGuan DG Jewelry Co,.Ltd", blue)
    ws.set_row(0, 44)
    ws.merge_range("A2:I2", "Charms", subtitle)
    ws.set_row(1, 28)

    ws.merge_range("A3:C3", "W:  www.dgjewelry.cn", label)
    ws.merge_range("D3:I3", "As a jewelry, a pendant not only has a decorative role, but also carries a rich\nmoral and symbolic meaning. Here are some pendants and charms.", normal)
    ws.set_row(2, 48)

    ws.merge_range("A4:C4", "P : +86 186 8869 1502", label)
    ws.merge_range("D4:I4", "With our rich experience, OEM & ODM services are also welcome here, send", normal)
    ws.set_row(3, 36)

    ws.merge_range("A5:C5", "E: sparrow@dgjewelry.cn", label)
    ws.merge_range("D5:I5", "", normal)
    ws.set_row(4, 30)

    ws.merge_range("A6:C6", "Contact us for more Collection", label)
    ws.merge_range("D6:I6", "", normal)
    ws.set_row(5, 34)

    ws.merge_range("A7:I7", "Stainless steel   Charms", section)
    ws.set_row(6, 40)

    # 商品区：每 3 个一行组，结构 2 行：图行 + 文本行
    start_row = 7  # excel 第8行
    for idx, p in enumerate(products):
        block = idx // 3
        col_group = idx % 3
        row_img = start_row + block * 3
        row_txt = row_img + 1

        base_col = col_group * 3
        col_img = base_col
        col_sku = base_col + 1
        col_price = base_col + 2

        ws.set_row(row_img, 130)
        ws.set_row(row_txt, 30)

        # 画边框
        ws.write_blank(row_img, col_img, None, card_border)
        ws.write_blank(row_img, col_sku, None, card_border)
        ws.write_blank(row_img, col_price, None, card_border)
        ws.write_blank(row_txt, col_img, None, card_border)
        ws.write_blank(row_txt, col_sku, None, card_border)
        ws.write_blank(row_txt, col_price, None, card_border)

        # 图片
        image_url = p.get("image_url", "")
        if image_url:
            img_path, w, h = process_image_for_excel(image_url, "./tmp/images")
            if img_path and os.path.exists(img_path):
                x_scale = min(1.0, 170 / w) if w else 1.0
                y_scale = min(1.0, 120 / h) if h else 1.0
                ws.insert_image(row_img, col_img, img_path, {
                    "x_offset": 8,
                    "y_offset": 6,
                    "x_scale": x_scale,
                    "y_scale": y_scale,
                    "positioning": 1,
                })

        sku = p.get("sku", f"DGCMS{idx+1:04d}")
        ws.write(row_txt, col_img, sku, sku_fmt)

        price = p.get("price")
        if price in (None, "", "私密价"):
            ws.write_blank(row_txt, col_price, None, price_blank_fmt)
        else:
            ws.write_number(row_txt, col_price, float(price), price_fmt)

    wb.close()
    return output_path


if __name__ == "__main__":
    shop_url = "https://milishipin.1688.com/page/offerlist.htm?spm=a2615.7691456.wp_pc_common_topnav.0"
    data = scrape_shop_offers(shop_url=shop_url, pages=1, markup_rate=0.30, exchange_rate=0.14)
    products = data.get("products", [])
    out = f"./output/quotation_template_page1_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    file_path = build_template_quote(products, out)
    print(file_path)

