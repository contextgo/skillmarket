# quotation-builder - 外贸报价单生成器

专业的 Excel 报价单生成工具，支持多规则包扩展，专为外贸行业设计。

## ✨ 核心功能

- **Excel 报价单生成** - 自动生成带公司信息、产品图片的专业报价单
- **规则包系统** - 支持不同客户的专用规则（如 dg-1688）
- **CSV 产品库管理** - 本地产品数据检索与管理
- **横向 3 列布局** - 每行展示 3 个产品，排版专业美观
- **1688 数据抓取** - 支持从 1688.com 抓取产品数据并生成报价

---

## 📦 安装

### 1. 克隆/下载仓库

```bash
cd quotation-builder
```

### 2. 创建虚拟环境

```bash
# Windows
python -m venv .venv
.venv\Scripts\activate

# macOS/Linux
python3 -m venv .venv
source .venv/bin/activate
```

### 3. 安装依赖

```bash
pip install -r requirements.txt
```

---

## 🚀 快速开始

### 最小验证

```bash
python scripts/smoke_test.py
```

成功后会在 `output/` 目录生成 `smoke_test_quote.xlsx`。

### 基础用法

```bash
# 搜索本地 CSV 产品库
python main.py --action search_csv --query "mouse"

# 生成报价单
python main.py --action generate_excel --output ./output/quote.xlsx

# 使用 DG 规则包从 1688 生成报价单
python main.py --action run_rule --rule dg-1688 --url "https://detail.1688.com/offer/xxx.html"

# 带额外参数（如汇率）
python main.py --action run_rule \
  --rule dg-1688 \
  --url "https://detail.1688.com/offer/xxx.html" \
  --rule-params '{"fx":7.2}'
```

---

## 📁 项目结构

```
quotation-builder/
├── SKILL.md                      # OpenClaw 技能定义
├── main.py                       # 主入口
├── excel_builder.py              # Excel 生成核心
├── csv_manager.py                # CSV 产品库管理
├── image_handler.py              # 图片处理
├── rule_loader.py                # 规则包加载器
├── template_quote_builder.py     # 报价单模板
├── requirements.txt              # Python 依赖
├── .gitignore                    # Git 忽略文件
├── config/
│   └── company.json              # 公司信息配置
├── data/
│   └── local_products.csv        # 产品库数据
├── rules/
│   └── dg-1688/                  # DG 客户专用规则包
│       ├── SKILL.md              # 规则包说明
│       ├── build_quote_from_detail.py
│       ├── extract_sku_selection.js
│       ├── extract_sku_separated.js
│       └── scripts/
├── scripts/
│   └── smoke_test.py             # 最小验证脚本
├── assets/                       # 资源文件（Logo 等）
├── output/                       # 生成的报价单（已忽略）
└── tmp/                          # 临时文件（已忽略）
```

---

## 🎯 dg-1688 规则包

### 功能特性

- **1688 商品详情抓取** - 自动提取 SKU 维度的图片、名称、价格
- **分离式 SKU 支持** - 颜色/尺码分开在不同区域
- **标准 SKU 支持** - expand-view-item 列表结构
- **自动报价计算** - 配合美元/人民币汇率与报价系数（0.65/0.7）
- **横向 3 列布局** - 每行 3 个产品，名称带序号

### 使用场景

- DG 客户专用报价单生成
- 1688 店铺/商品链接批量报价
- 跨平台价格对比

### 导入方式

```python
# Python 导入（兼容路径）
from rules.dg_1688.build_quote_from_detail import build_quote

# 或通过主入口动态执行
python main.py --action run_rule --rule dg-1688 --url "https://..."
```

---

## ⚙️ 配置

### 公司信息

编辑 `config/company.json`：

```json
{
  "name": "Your Company Name",
  "address": "Your Address",
  "email": "contact@yourcompany.com",
  "phone": "+86-xxx-xxxx-xxxx",
  "logo": "assets/logo.png"
}
```

### 产品库

产品数据位于 `data/local_products.csv`，格式：

```csv
sku,name,price,image_url,category
MOU-001,Wireless Mouse,15.99,assets/mouse.jpg,Electronics
```

---

## 📋 依赖

主要 Python 包：

- `openpyxl` - Excel 文件操作
- `pandas` - 数据处理
- `requests` - HTTP 请求
- `beautifulsoup4` - HTML 解析
- `playwright` - 浏览器自动化（1688 抓取）

完整依赖见 `requirements.txt`。

---

## ⚠️ 已知限制

- `scrape_1688` 依赖 `web_access_1688_scraper` 模块；若未安装，该 action 会返回明确错误，但不影响 `search_csv`/`generate_excel`
- 1688 抓取可能需要配置代理或 Cookie
- 图片处理需要网络连接或本地资源

---

## 📝 许可证

MIT License

---

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

---

**版本:** 1.0.0  
**最后更新:** 2026-04-01
