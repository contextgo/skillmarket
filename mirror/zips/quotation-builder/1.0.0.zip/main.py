#!/usr/bin/env python3
"""
外贸报价单生成器 - 主入口
支持命令行参数和 JSON 一体化传参
"""

import argparse
import json
import os
import subprocess
import sys
from typing import List, Dict, Any
from datetime import datetime

from csv_manager import search_csv, load_all_products, insert_product
from excel_builder import generate_excel
from rule_loader import run_rule, list_rules, extract_rule_items, load_rule_module


def load_company_info(company_info_path: str = "./config/company.json") -> Dict[str, Any]:
    """从配置文件加载公司信息"""
    if os.path.exists(company_info_path):
        try:
            with open(company_info_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Warning: Failed to load company info: {e}")
    return {}


def cmd_search_csv(args) -> Dict[str, Any]:
    """执行 CSV 搜索命令"""
    csv_path = args.csv or "./data/local_products.csv"
    results = search_csv(args.query, csv_path)
    return {
        "status": "ok",
        "query": args.query,
        "results": results,
        "count": len(results)
    }


def cmd_generate_excel(args) -> Dict[str, Any]:
    """执行生成 Excel 命令"""

    # 获取公司信息（优先级：传入参数 > 配置文件）
    company_info = None
    if args.company:
        try:
            company_info = json.loads(args.company)
        except json.JSONDecodeError as e:
            return {"status": "error", "message": f"Invalid company JSON: {e}"}
    else:
        company_info = load_company_info()

    if not company_info or not company_info.get('name'):
        return {"status": "error", "message": "company_info missing or invalid"}

    # 获取产品数据（优先级：传入 JSON > 搜索 CSV）
    products = []
    if args.products:
        try:
            products = json.loads(args.products)
        except json.JSONDecodeError as e:
            return {"status": "error", "message": f"Invalid products JSON: {e}"}
    elif args.query:
        csv_path = args.csv or "./data/local_products.csv"
        products = search_csv(args.query, csv_path)
    else:
        # 加载所有产品
        csv_path = args.csv or "./data/local_products.csv"
        products = load_all_products(csv_path)

    if not products:
        return {"status": "error", "message": "No products found"}

    # 确定输出路径
    output_path = args.output
    if not output_path:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = f"./output/quotation_{timestamp}.xlsx"

    # 生成 Excel
    result = generate_excel(
        products=products,
        company_info=company_info,
        output_path=output_path,
        temp_dir=args.temp_dir or "./tmp/images"
    )

    return result


def cmd_scrape_1688(args) -> Dict[str, Any]:
    """抓取 1688 店铺商品并直接生成报价单"""
    try:
        # 延迟导入，避免缺少抓取模块时影响基础功能（search_csv/generate_excel）
        from web_access_1688_scraper import scrape_shop_offers
    except Exception as e:
        return {
            "status": "error",
            "message": (
                "scrape_1688 dependency missing: web_access_1688_scraper. "
                "Please install crawler module before using scrape_1688."
            ),
            "details": str(e),
        }

    shop_url = args.shop_url
    if not shop_url:
        return {"status": "error", "message": "--shop-url is required for scrape_1688"}

    company_info = None
    if args.company:
        try:
            company_info = json.loads(args.company)
        except json.JSONDecodeError as e:
            return {"status": "error", "message": f"Invalid company JSON: {e}"}
    else:
        company_info = load_company_info()

    if not company_info or not company_info.get("name"):
        return {"status": "error", "message": "company_info missing or invalid"}

    pages = int(args.pages or 2)
    markup = float(args.markup if args.markup is not None else 0.30)
    exchange = float(args.exchange if args.exchange is not None else 0.14)

    scrape_result = scrape_shop_offers(
        shop_url=shop_url,
        pages=pages,
        markup_rate=markup,
        exchange_rate=exchange,
    )
    products = scrape_result.get("products", [])
    if not products:
        return {"status": "error", "message": "No products scraped from 1688", "meta": scrape_result}

    output_path = args.output or f"./output/quotation_1688_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    excel_result = generate_excel(
        products=products,
        company_info=company_info,
        output_path=output_path,
        temp_dir=args.temp_dir or "./tmp/images",
    )
    excel_result["meta"] = {
        "scraped_pages": scrape_result.get("page_stats", []),
        "total_products": len(products),
        "private_price_count": sum(1 for p in products if p.get("price") in (None, "", "私密价")),
    }
    return excel_result


def cmd_run_rule(args) -> Dict[str, Any]:
    """执行通用规则包入口（可用于多客户定制规则）"""
    rule_name = args.rule
    detail_url = args.url
    if not rule_name:
        return {"status": "error", "message": "--rule is required"}
    if not detail_url:
        return {"status": "error", "message": "--url is required"}

    extra_kwargs: Dict[str, Any] = {}
    if args.rule_params:
        try:
            extra_kwargs = json.loads(args.rule_params)
            if not isinstance(extra_kwargs, dict):
                return {"status": "error", "message": "--rule-params must be a JSON object"}
        except json.JSONDecodeError as e:
            return {"status": "error", "message": f"Invalid --rule-params JSON: {e}"}

    # 兼容老参数：--exchange 可映射到 fx
    if args.exchange is not None and "fx" not in extra_kwargs:
        extra_kwargs["fx"] = float(args.exchange)

    try:
        output_path = run_rule(rule_name=rule_name, url=detail_url, kwargs=extra_kwargs)
        return {
            "status": "ok",
            "rule": rule_name,
            "file_path": output_path,
            "available_rules": list_rules(),
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to execute rule '{rule_name}': {e}",
            "available_rules": list_rules(),
        }


def cmd_shop_to_quote(args) -> Dict[str, Any]:
    """店铺筛选后抓取详情并默认合并成单份报价单。"""
    shop_url = args.shop_url
    if not shop_url:
        return {"status": "error", "message": "--shop-url is required"}

    rule_name = args.rule or "dg-1688"
    first_filter = args.first_filter or "2026 新款"
    second_filter = args.second_filter or first_filter
    pipeline_output = args.pipeline_output or "./tmp/shop_filtered_products.json"
    pipeline_state = args.pipeline_state or "./tmp/shop_filter_pipeline_state.json"

    company_info = None
    if args.company:
        try:
            company_info = json.loads(args.company)
        except json.JSONDecodeError as e:
            return {"status": "error", "message": f"Invalid company JSON: {e}"}
    else:
        company_info = load_company_info()

    if not company_info or not company_info.get("name"):
        return {"status": "error", "message": "company_info missing or invalid"}

    script_path = "./rules/dg-1688/scripts/run_shop_filter_pipeline.py"
    cmd = [
        sys.executable,
        script_path,
        "--shop-url",
        shop_url,
        "--first-filter",
        first_filter,
        "--second-filter",
        second_filter,
        "--output",
        pipeline_output,
        "--state",
        pipeline_state,
    ]
    if args.resume:
        cmd.append("--resume")

    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        return {"status": "error", "message": "shop pipeline failed", "stderr": p.stderr, "stdout": p.stdout}

    try:
        with open(pipeline_output, "r", encoding="utf-8") as f:
            filtered = json.load(f)
    except Exception as e:
        return {"status": "error", "message": f"failed to load pipeline output: {e}"}

    links = [str(i.get("link", "")).strip() for i in filtered.get("items", []) if str(i.get("link", "")).strip()]
    if not links:
        return {"status": "error", "message": "No detail links from shop filter", "pipeline_output": pipeline_output}

    all_products: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    for link in links:
        try:
            rule_kwargs: Dict[str, Any] = {}
            if args.exchange is not None:
                rule_kwargs["fx"] = float(args.exchange)
            rows = extract_rule_items(rule_name=rule_name, url=link, kwargs=rule_kwargs)
            all_products.extend(rows)
        except Exception as e:
            errors.append({"link": link, "error": str(e)})

    if not all_products:
        return {
            "status": "error",
            "message": "No products extracted from detail pages",
            "errors": errors,
            "pipeline_output": pipeline_output,
        }

    output_path = args.output or f"./output/quotation_shop_merged_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    normalized_rule = (rule_name or "").strip().replace("_", "-").lower()

    # 默认逻辑保持不变；仅当 dg-1688 规则时应用 DG 模板渲染
    if normalized_rule == "dg-1688":
        try:
            rule_mod = load_rule_module(rule_name)
            renderer = getattr(rule_mod, "build_quote_from_items", None)
            if callable(renderer):
                dg_items = []
                for p in all_products:
                    remark = str(p.get("remarks", "")).strip()
                    cny = None
                    if remark.startswith("CNY:"):
                        try:
                            cny = float(remark.split(":", 1)[1].strip())
                        except Exception:
                            cny = None
                    dg_items.append(
                        {
                            "imageUrl": p.get("image_url", ""),
                            "name": p.get("name", ""),
                            "priceCny": cny,
                            "link": p.get("detail_link", ""),
                        }
                    )
                final_path = renderer(dg_items, output_path=output_path, page_url=shop_url)
                return {
                    "status": "ok",
                    "file_path": final_path,
                    "warnings": [],
                    "meta": {
                        "shop_url": shop_url,
                        "rule": rule_name,
                        "template": "dg-1688",
                        "filters": {"first": first_filter, "second": second_filter},
                        "detail_links_count": len(links),
                        "merged_products_count": len(all_products),
                        "errors": errors,
                        "pipeline_output": pipeline_output,
                    },
                }
        except Exception as e:
            errors.append({"stage": "dg_template_render", "error": str(e)})

    # 非 dg-1688 或 dg 模板渲染失败时，回退通用 Excel
    excel_result = generate_excel(
        products=all_products,
        company_info=company_info,
        output_path=output_path,
        temp_dir=args.temp_dir or "./tmp/images",
    )
    excel_result["meta"] = {
        "shop_url": shop_url,
        "rule": rule_name,
        "template": "default",
        "filters": {"first": first_filter, "second": second_filter},
        "detail_links_count": len(links),
        "merged_products_count": len(all_products),
        "errors": errors,
        "pipeline_output": pipeline_output,
    }
    return excel_result


def cmd_json_mode(args) -> Dict[str, Any]:
    """JSON 一体化传参模式"""
    try:
        params = json.loads(args.json)
    except json.JSONDecodeError as e:
        return {"status": "error", "message": f"Invalid JSON: {e}"}

    action = params.get('action')

    if action == 'search_csv':
        query = params.get('query', '')
        csv_path = params.get('csv_path', './data/local_products.csv')
        results = search_csv(query, csv_path)
        return {
            "status": "ok",
            "query": query,
            "results": results,
            "count": len(results)
        }

    elif action == 'generate_excel':
        products = params.get('products', [])
        company_info = params.get('company_info')

        # 如果未传入公司信息，尝试从配置文件加载
        if not company_info:
            config_path = params.get('company_config_path', './config/company.json')
            company_info = load_company_info(config_path)

        if not company_info or not company_info.get('name'):
            return {"status": "error", "message": "company_info missing"}

        if not products:
            return {"status": "error", "message": "products list is empty"}

        output_path = params.get('output_path', f"./output/quotation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
        temp_dir = params.get('temp_dir', './tmp/images')

        return generate_excel(products, company_info, output_path, temp_dir)

    elif action == 'insert_product':
        # 预留接口
        data = params.get('data', {})
        success = insert_product(data)
        return {"status": "ok" if success else "error"}

    elif action == 'run_rule':
        rule_name = params.get("rule")
        detail_url = params.get("url")
        kwargs = params.get("rule_params", {})
        if not isinstance(kwargs, dict):
            return {"status": "error", "message": "rule_params must be object"}
        try:
            output_path = run_rule(rule_name=rule_name, url=detail_url, kwargs=kwargs)
            return {
                "status": "ok",
                "rule": rule_name,
                "file_path": output_path,
                "available_rules": list_rules(),
            }
        except Exception as e:
            return {
                "status": "error",
                "message": f"Failed to execute rule '{rule_name}': {e}",
                "available_rules": list_rules(),
            }
    elif action == 'shop_to_quote':
        # 统一复用 CLI 逻辑参数，减少分叉
        for k, v in params.items():
            setattr(args, k, v)
        return cmd_shop_to_quote(args)

    else:
        return {"status": "error", "message": f"Unknown action: {action}"}


def main():
    parser = argparse.ArgumentParser(
        description="外贸报价单生成器 - Quotation Builder",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 搜索 CSV
  python main.py --action search_csv --query "mouse"

  # 生成 Excel（使用配置文件中的公司信息）
  python main.py --action generate_excel --output ./output/quote.xlsx

  # 生成 Excel（传入产品和公司信息）
  python main.py --action generate_excel --products '[{"sku":"MS-001","name":"Mouse","price":25}]' --company '{"name":"Test Co."}'

  # 执行规则包（多客户可插拔）
  python main.py --action run_rule --rule dg-1688 --url "https://detail.1688.com/offer/xxx.html"

  # JSON 一体化传参
  python main.py --json '{"action":"generate_excel","products":[...],"company_info":{...}}'
"""
    )

    parser.add_argument('--action', choices=['search_csv', 'generate_excel', 'insert_product', 'scrape_1688', 'run_rule', 'shop_to_quote'],
                        help='执行的动作')
    parser.add_argument('--query', help='搜索关键词（用于 CSV 检索）')
    parser.add_argument('--csv', help='CSV 文件路径（默认 ./data/local_products.csv）')
    parser.add_argument('--products', help='产品 JSON 字符串')
    parser.add_argument('--company', help='公司信息 JSON 字符串')
    parser.add_argument('--output', '-o', help='输出文件路径')
    parser.add_argument('--temp-dir', help='临时图片目录（默认 ./tmp/images）')
    parser.add_argument('--shop-url', help='1688 店铺商品页 URL（用于 scrape_1688）')
    parser.add_argument('--rule', help='规则包名称（用于 run_rule）')
    parser.add_argument('--url', help='规则入口 URL（用于 run_rule）')
    parser.add_argument('--rule-params', help='规则额外参数 JSON（用于 run_rule）')
    parser.add_argument('--first-filter', help='店铺筛选一级关键词（用于 shop_to_quote）')
    parser.add_argument('--second-filter', help='店铺筛选二级关键词（用于 shop_to_quote）')
    parser.add_argument('--pipeline-output', help='店铺筛选结果输出 JSON（用于 shop_to_quote）')
    parser.add_argument('--pipeline-state', help='店铺筛选断点文件（用于 shop_to_quote）')
    parser.add_argument('--resume', action='store_true', help='店铺筛选从断点继续（用于 shop_to_quote）')
    parser.add_argument('--pages', type=int, help='抓取页数（用于 scrape_1688，默认 2）')
    parser.add_argument('--markup', type=float, help='利润加成比例（默认 0.30）')
    parser.add_argument('--exchange', type=float, help='汇率（默认 0.14）')
    parser.add_argument('--json', help='JSON 一体化传参模式')
    parser.add_argument('--version', '-v', action='version', version='%(prog)s 2.0')

    args = parser.parse_args()

    # 执行对应命令
    if args.json:
        result = cmd_json_mode(args)
    elif args.action == 'search_csv':
        result = cmd_search_csv(args)
    elif args.action == 'generate_excel':
        result = cmd_generate_excel(args)
    elif args.action == 'scrape_1688':
        result = cmd_scrape_1688(args)
    elif args.action == 'run_rule':
        result = cmd_run_rule(args)
    elif args.action == 'shop_to_quote':
        result = cmd_shop_to_quote(args)
    elif args.action == 'insert_product':
        # 预留接口
        result = {"status": "ok", "message": "insert_product is reserved"}
    else:
        parser.print_help()
        sys.exit(0)

    # 输出结果
    print(json.dumps(result, ensure_ascii=False, indent=2))

    # 根据状态设置退出码
    sys.exit(0 if result.get('status') == 'ok' else 1)


if __name__ == "__main__":
    main()
