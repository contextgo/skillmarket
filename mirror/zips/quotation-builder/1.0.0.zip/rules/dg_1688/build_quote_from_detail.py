"""
Compatibility wrapper:
allow `from rules.dg_1688.build_quote_from_detail import ...`
while implementation lives in `rules/dg-1688/build_quote_from_detail.py`.
"""

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path


_SOURCE = Path(__file__).resolve().parents[1] / "dg-1688" / "build_quote_from_detail.py"
_SPEC = spec_from_file_location("dg1688_impl", _SOURCE)
if _SPEC is None or _SPEC.loader is None:
    raise ImportError(f"Cannot load dg-1688 implementation from {_SOURCE}")

_MODULE = module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)

build_quote = _MODULE.build_quote
DEFAULT_FX = _MODULE.DEFAULT_FX
extract_quote_items = _MODULE.extract_quote_items
build_quote_from_items = _MODULE.build_quote_from_items

__all__ = ["build_quote", "DEFAULT_FX", "extract_quote_items", "build_quote_from_items"]

