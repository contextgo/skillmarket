# Rules package for quotation generator extensions.
