# DG-1688 GitHub 部署指南

> 完整的项目发布和部署操作手册

---

## 📖 目录

- [准备工作](#-准备工作)
- [创建 GitHub 仓库](#-创建-github-仓库)
- [上传项目文件](#-上传项目文件)
- [配置 GitHub Actions](#-配置-github-actions)
- [发布到 GitHub](#-发布到-github)
- [版本管理](#-版本管理)
- [维护指南](#-维护指南)

---

## 🔧 准备工作

### 1. 安装 Git

**Windows:**
```bash
# 下载安装 Git for Windows
https://git-scm.com/download/win

# 验证安装
git --version
```

**macOS:**
```bash
# 使用 Homebrew 安装
brew install git

# 验证安装
git --version
```

### 2. 配置 Git 用户信息

```bash
# 设置用户名
git config --global user.name "Your Name"

# 设置邮箱
git config --global user.email "your.email@example.com"

# 验证配置
git config --list
```

### 3. 创建 GitHub 账号

访问 https://github.com 注册账号（如已有可跳过）

---

## 📁 创建 GitHub 仓库

### 步骤 1：登录 GitHub

访问 https://github.com 并登录

### 步骤 2：创建新仓库

1. 点击右上角 **+** → **New repository**
2. 填写仓库信息：
   - **Repository name**: `dg-1688-quotation-builder`
   - **Description**: `1688 抓取规则包（DG 客户专用）- 自动化生成外贸报价单`
   - **Visibility**: Public（公开）或 Private（私有）
   - **Initialize this repository with**: 不勾选（我们将上传现有代码）
3. 点击 **Create repository**

### 步骤 3：记录仓库 URL

创建成功后，复制仓库 URL，格式：
```
https://github.com/your-username/dg-1688-quotation-builder.git
```

---

## 📤 上传项目文件

### 步骤 1：准备项目文件

确保以下文件已创建：

```
dg-1688/
├── README.md                 # 项目说明文档
├── SKILL.md                  # Skill 配置文档
├── IMAGE_INSERT_CONFIG.md    # 图片插入配置指南
├── build_quote_from_detail.py  # 主程序
├── extract_sku_selection.js  # SKU 提取脚本
├── extract_sku_separated.js  # 分离式 SKU 提取脚本
├── scripts/
│   └── run_shop_filter_pipeline.py  # 店铺筛选脚本
└── rules/
    └── dg-1688/              # 规则目录
```

### 步骤 2：初始化本地 Git 仓库

```bash
# 进入项目目录
cd C:\Users\caizheyu\.openclaw\workspace-hamburger\skills\quotation-builder\rules\dg-1688

# 初始化 Git 仓库
git init

# 添加所有文件
git add .

# 提交更改
git commit -m "Initial commit: DG-1688 quotation builder v1.4"
```

### 步骤 3：关联远程仓库

```bash
# 添加远程仓库（替换为你的仓库 URL）
git remote add origin https://github.com/your-username/dg-1688-quotation-builder.git

# 验证远程仓库
git remote -v
```

### 步骤 4：推送到 GitHub

```bash
# 推送到 main 分支
git push -u origin main

# 如果提示分支名称，使用：
git branch -M main
git push -u origin main
```

### 步骤 5：验证上传

1. 打开浏览器访问仓库 URL
2. 确认所有文件已正确上传
3. 检查 README.md 是否正常显示

---

## ⚙️ 配置 GitHub Actions

### 步骤 1：创建工作流文件

创建 `.github/workflows/test.yml`：

```yaml
name: Python Tests

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: windows-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.10'
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install xlsxwriter Pillow requests
    
    - name: Run tests
      run: |
        echo "Tests would run here"
        # 添加你的测试命令
```

### 步骤 2：创建目录结构

```bash
# 创建 .github 目录
mkdir -p .github/workflows

# 创建工作流文件
# （将上面的 YAML 内容保存为 .github/workflows/test.yml）
```

### 步骤 3：提交工作流文件

```bash
git add .github/workflows/test.yml
git commit -m "Add GitHub Actions workflow"
git push origin main
```

---

## 🏷️ 版本管理

### 创建 Git Tag

```bash
# 创建新版本标签
git tag -a v1.4.0 -m "Release version 1.4.0"

# 推送标签到 GitHub
git push origin v1.4.0
```

### 创建 GitHub Release

1. 访问仓库页面
2. 点击右侧 **Releases** → **Create a new release**
3. 填写发布信息：
   - **Tag version**: `v1.4.0`
   - **Release title**: `DG-1688 v1.4.0`
   - **Description**: 
     ```markdown
     ## 更新内容
     
     ### 新增
     - SKU 图片匹配规则（逐个点击获取）
     - 产品名称格式改为 DG-{店铺缩写}-{序号}
     - 强制要求 1688 链接
     
     ### 修复
     - 图片插入配置问题
     ```
   - **Publish release**: 勾选
4. 点击 **Publish release**

---

## 📢 发布到 GitHub

### 步骤 1：更新 README.md

确保 README.md 包含：
- ✅ 项目简介
- ✅ 功能特性
- ✅ 安装说明
- ✅ 使用示例
- ✅ 配置说明
- ✅ 故障排查
- ✅ 许可证信息

### 步骤 2：添加许可证

创建 `LICENSE` 文件（推荐使用 MIT）：

```text
MIT License

Copyright (c) 2026 DG Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### 步骤 3：创建 .gitignore

创建 `.gitignore` 文件：

```text
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
ENV/
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# Output files
output/
tmp/
*.xlsx
*.xls

# OS
.DS_Store
Thumbs.db
```

### 步骤 4：最终提交

```bash
git add .
git commit -m "Prepare for GitHub release v1.4.0"
git push origin main
git push origin v1.4.0
```

---

## 🔍 维护指南

### 日常更新流程

```bash
# 1. 修改代码
# （编辑文件...）

# 2. 查看更改
git status
git diff

# 3. 添加更改
git add .

# 4. 提交更改
git commit -m "Fix: 描述你的更改"

# 5. 推送到 GitHub
git push origin main
```

### 版本更新流程

```bash
# 1. 更新版本号（在 README.md 和 SKILL.md 中）
# 2. 更新更新日志
# 3. 创建新标签
git tag -a v1.5.0 -m "Release version 1.5.0"

# 4. 推送标签
git push origin v1.5.0

# 5. 在 GitHub 创建 Release
# （访问 Releases 页面创建）
```

### 处理 Issue

1. 访问仓库 **Issues** 标签
2. 查看用户报告的问题
3. 创建分支修复问题：
   ```bash
   git checkout -b fix/issue-123
   # 修复代码...
   git add .
   git commit -m "Fix: 修复问题 #123"
   git push origin fix/issue-123
   ```
4. 创建 Pull Request
5. 合并后删除分支

---

## 📊 项目统计

### 查看仓库统计

访问 https://github.com/your-username/dg-1688-quotation-builder/graphs

### 添加统计徽章到 README

```markdown
[![Stars](https://img.shields.io/github/stars/your-username/dg-1688-quotation-builder.svg)](https://github.com/your-username/dg-1688-quotation-builder/stargazers)
[![Forks](https://img.shields.io/github/forks/your-username/dg-1688-quotation-builder.svg)](https://github.com/your-username/dg-1688-quotation-builder/network)
[![Issues](https://img.shields.io/github/issues/your-username/dg-1688-quotation-builder.svg)](https://github.com/your-username/dg-1688-quotation-builder/issues)
```

---

## 🔐 安全建议

### 1. 保护 main 分支

1. 访问仓库 **Settings** → **Branches**
2. 点击 **Add branch protection rule**
3. 填写：
   - **Branch name pattern**: `main`
   - **Require pull request reviews**: 勾选
   - **Require status checks**: 勾选（如有 CI）
4. 点击 **Create**

### 2. 使用 Secret 管理敏感信息

如需 API 密钥等敏感信息：

1. 访问仓库 **Settings** → **Secrets and variables** → **Actions**
2. 点击 **New repository secret**
3. 添加密钥（如 `API_KEY`）
4. 在工作流中使用：`${{ secrets.API_KEY }}`

---

## 📞 常见问题

### Q: 推送时提示权限错误

**A:** 使用 HTTPS 方式需要输入用户名和密码（或个人访问令牌）：

```bash
# 使用个人访问令牌（推荐）
git push https://your-username:your-token@github.com/your-username/repo.git

# 或配置 SSH 密钥
ssh-keygen -t ed25519 -C "your.email@example.com"
# 将公钥添加到 GitHub Settings → SSH and GPG keys
```

### Q: 如何删除已上传的敏感文件

**A:** 

```bash
# 从 Git 历史中删除文件
git filter-branch --force --index-filter \
  'git rm --cached --ignore-unmatch path/to/sensitive/file' \
  --prune-empty --tag-name-filter cat -- --all

# 强制推送
git push origin --force --all
```

### Q: 如何同步上游仓库更新

**A:**

```bash
# 添加上游仓库
git remote add upstream https://github.com/original-owner/repo.git

# 获取更新
git fetch upstream

# 合并到本地分支
git checkout main
git merge upstream/main

# 推送到自己的仓库
git push origin main
```

---

## 📚 相关资源

- [Git 官方文档](https://git-scm.com/doc)
- [GitHub 官方文档](https://docs.github.com/)
- [GitHub Actions 文档](https://docs.github.com/en/actions)
- [Markdown 语法指南](https://guides.github.com/features/mastering-markdown/)

---

**最后更新**: 2026-03-31  
**维护状态**: 活跃维护中
