# DG-1688 报价单生成器

> 1688 抓取规则包（DG 客户专用）| 自动化生成外贸报价单

[![Version](https://img.shields.io/badge/version-1.4-blue.svg)](https://github.com/your-repo/dg-1688)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.8+-orange.svg)](https://python.org)

---

## 📖 目录

- [功能特性](#-功能特性)
- [快速开始](#-快速开始)
- [配置说明](#-配置说明)
- [使用示例](#-使用示例)
- [故障排查](#-故障排查)
- [API 参考](#-api-参考)
- [贡献指南](#-贡献指南)

---

## 🎯 功能特性

### 核心功能

| 功能 | 说明 | 状态 |
|------|------|------|
| SKU 抓取 | 从 1688 详情页提取 SKU 图片、名称、价格 | ✅ |
| 图片处理 | 自动裁剪顶部编码水印，等比缩放 | ✅ |
| Excel 生成 | 横向 3 列布局，符合 DG 模板规范 | ✅ |
| 价格转换 | CNY → USD（汇率可配置） | ✅ |
| 店铺筛选 | 支持按分类筛选后批量抓取 | ✅ |
| 断点续跑 | 遇到验证码可保存进度后继续 | ✅ |

### 输出格式

- **公司介绍区**（前 7 行）：DG Jewelry 公司信息
- **数据区**：横向 3 列布局，每行 3 个产品
- **图片行**：产品图片 + 1688 链接
- **数据行**：产品名称 + CNY 价格 + USD 价格

---

## 🚀 快速开始

### 环境要求

- Python 3.8+
- Windows / macOS / Linux
- 网络连接（访问 1688.com）

### 安装依赖

```bash
# 进入项目目录
cd quotation-builder

# 安装 Python 依赖
pip install -r requirements.txt
```

### 依赖列表

```txt
xlsxwriter>=3.0.0
Pillow>=9.0.0
requests>=2.28.0
```

### 基本使用

```python
from rules.dg_1688.build_quote_from_detail import build_quote

# 方式 1：使用默认汇率（7.0）
output = build_quote("https://detail.1688.com/offer/1234567890.html")
print(f"报价单已生成：{output}")

# 方式 2：指定汇率
output = build_quote("https://detail.1688.com/offer/1234567890.html", fx=7.2)
print(f"报价单已生成：{output}")
```

### 命令行使用

```bash
cd price-list-generator
python -c "from rules.dg_1688.build_quote_from_detail import build_quote; print(build_quote('https://detail.1688.com/offer/1234567890.html'))"
```

---

## ⚙️ 配置说明

### 1. 图片插入配置（⚠️ 关键）

**问题记录：** 图片插入配置问题多次出现，必须严格按以下步骤操作！

#### 步骤 1：导入 image_handler 模块

```python
from pathlib import Path
import sys

# 添加 quotation-builder 目录到路径
quotation_builder_dir = Path(__file__).resolve().parent.parent / "quotation-builder"
sys.path.insert(0, str(quotation_builder_dir))

# 导入图片处理函数
from image_handler import process_image_for_excel
```

#### 步骤 2：使用 process_image_for_excel 处理图片

```python
# 处理图片（下载 + 裁剪顶部 100px + 返回本地路径）
img_path, w, h = process_image_for_excel(image_url, "./tmp/images")

# 验证图片是否处理成功
if img_path and Path(img_path).exists():
    # 继续下一步
else:
    # 处理失败，写入 "No Image"
    ws.write(img_row, col_offset, "No Image", base)
```

#### 步骤 3：Windows 路径规范化

```python
# Windows 兼容性：将路径转换为正斜杠
img_path_normalized = str(Path(img_path).as_posix())
```

#### 步骤 4：计算缩放比例

```python
# 图片显示框尺寸（像素）
box_w, box_h = 140.0, 100.0

# 计算等比缩放比例
scale = min(1.0, box_w / w, box_h / h) if w and h else 1.0
```

#### 步骤 5：插入图片到 Excel 单元格（关键！）

```python
# 关键参数：positioning=1（图片随单元格移动和调整大小）
ws.insert_image(
    img_row,                    # 行索引
    col_offset,                 # 列索引（0=A, 3=D, 6=G）
    img_path_normalized,        # 图片路径（正斜杠）
    {
        "x_offset": 5,          # 左边距 5 像素
        "y_offset": 5,          # 上边距 5 像素
        "x_scale": scale,       # X 缩放比例
        "y_scale": scale,       # Y 缩放比例
        "positioning": 1,       # ⚠️ 关键！1=图片嵌入单元格
    },
)
```

### 2. 关键参数说明

| 参数 | 必须值 | 说明 |
|------|--------|------|
| `positioning` | **1** | **1=图片嵌入单元格（随单元格移动和调整大小）** |
| `x_offset` | 5 | 图片左边距（像素） |
| `y_offset` | 5 | 图片上边距（像素） |
| `x_scale` | scale | X 轴缩放比例（0.0-1.0） |
| `y_scale` | scale | Y 轴缩放比例（0.0-1.0） |

### 3. 行高列宽设置

```python
# 列宽设置（9 列布局）
ws.set_column("A:A", 18)   # 图片 1
ws.set_column("B:B", 10)   # 链接 1 / CNY
ws.set_column("C:C", 14)   # 空 1 / USD
ws.set_column("D:D", 18)   # 图片 2
ws.set_column("E:E", 10)   # 链接 2 / CNY
ws.set_column("F:F", 14)   # 空 2 / USD
ws.set_column("G:G", 18)   # 图片 3
ws.set_column("H:H", 10)   # 链接 3 / CNY
ws.set_column("I:I", 14)   # 空 3 / USD

# 行高设置
ws.set_row(img_row, 120)   # 图片行高度（120 像素）
ws.set_row(data_row, 24)   # 数据行高度（24 像素）
```

### 4. 价格配置

```python
# 汇率配置（默认 7.0）
DEFAULT_FX = 7.0

# 报价系数
QUOTE_FACTOR = 0.65

# USD 计算公式
USD = CNY / QUOTE_FACTOR / DEFAULT_FX
```

---

## 📋 使用示例

### 示例 1：单个产品报价单

```python
from rules.dg_1688.build_quote_from_detail import build_quote

# 生成报价单
output = build_quote("https://detail.1688.com/offer/1015553072542.html")

# 输出：./output/dg1688_template_quote_20260331_180000.xlsx
```

### 示例 2：批量抓取店铺产品

```python
# 使用店铺筛选脚本
python rules/dg-1688/scripts/run_shop_filter_pipeline.py \
  --shop-url "https://milishipin.1688.com/page/offerlist.htm" \
  --first-filter "2026 新款" \
  --second-filter "3 月 上新" \
  --output "./tmp/milishipin_2026_3month_products.json"
```

### 示例 3：自定义汇率

```python
# 使用指定汇率生成报价单
output = build_quote(
    "https://detail.1688.com/offer/1015553072542.html",
    fx=7.2  # 自定义汇率
)
```

---

## 🔧 故障排查

### 问题 1：图片未插入 Excel

**症状：** 生成的 Excel 中图片位置显示 "No Image" 或空白

**解决方案：**

1. 检查是否导入 `image_handler.process_image_for_excel`
2. 确认使用 `process_image_for_excel()` 处理图片
3. 验证路径转换为正斜杠：`Path(img_path).as_posix()`
4. 确认 `insert_image` 参数包含 `positioning: 1`

**检查清单：**

```python
# ✅ 正确示例
from image_handler import process_image_for_excel

img_path, w, h = process_image_for_excel(image_url, "./tmp/images")
if img_path and Path(img_path).exists():
    img_path_normalized = str(Path(img_path).as_posix())
    scale = min(1.0, 140.0 / w, 100.0 / h) if w and h else 1.0
    ws.insert_image(
        img_row, col_offset, img_path_normalized,
        {"x_offset": 5, "y_offset": 5, "x_scale": scale, "y_scale": scale, "positioning": 1},
    )
```

### 问题 2：图片过大溢出单元格

**症状：** 图片超出单元格边界

**解决方案：**

1. 检查缩放比例计算：`scale = min(1.0, 140.0/w, 100.0/h)`
2. 确认列宽设置为 18，行高设置为 120
3. 确认 `box_w=140.0, box_h=100.0`

### 问题 3：1688 页面返回验证码

**症状：** 抓取过程中遇到滑块验证码

**解决方案：**

1. 脚本会自动检测验证码并暂停
2. 手动完成验证码后，使用 `--resume` 参数续跑
3. 建议降低抓取频率，避免触发风控

```bash
python rules/dg-1688/scripts/run_shop_filter_pipeline.py --resume
```

### 问题 4：图片下载失败

**症状：** 控制台显示 "Download failed"

**解决方案：**

1. 检查网络连接是否正常
2. 确认图片 URL 可访问
3. 检查 `./tmp/images` 目录是否有写入权限
4. 尝试更换网络环境（某些地区可能无法访问 alicdn.com）

---

## 📚 API 参考

### build_quote 函数

```python
def build_quote(
    detail_url: str,
    fx: float = 7.0,
    output_path: Optional[str] = None
) -> str:
    """
    从 1688 详情页生成 DG 格式报价单

    Args:
        detail_url: 1688 商品详情页 URL
        fx: 美元/人民币汇率（默认 7.0）
        output_path: 输出文件路径（默认自动生成）

    Returns:
        生成的 Excel 文件路径
    """
```

### process_image_for_excel 函数

```python
def process_image_for_excel(
    image_url: str,
    temp_dir: str = "./tmp/images"
) -> Tuple[Optional[str], int, int]:
    """
    全流程处理图片：下载 → 裁剪 → 缩放

    Args:
        image_url: 图片 URL 或本地路径
        temp_dir: 临时目录

    Returns:
        (最终图片路径，宽度，高度)，失败返回 (None, 0, 0)
    """
```

---

## 🤝 贡献指南

### 提交代码

1. Fork 本仓库
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

### 报告问题

请在 Issues 中报告问题，并提供：
- 问题描述
- 复现步骤
- 预期行为
- 实际行为
- 环境信息（Python 版本、操作系统等）

---

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

---

## 📞 联系方式

- 项目维护者：DG Team
- 邮箱：support@dgjewelry.cn
- 项目地址：https://github.com/your-repo/dg-1688

---

## 📝 更新日志

### v1.4 (2026-03-31)
- ✅ 新增：SKU 图片匹配规则（逐个点击获取）
- ✅ 新增：产品名称格式改为 DG-{店铺缩写}-{序号}
- ✅ 新增：强制要求 1688 链接
- ✅ 修复：图片插入配置问题（详见 IMAGE_INSERT_CONFIG.md）

### v1.3 (2026-03-30)
- ✅ 新增：店铺筛选抓取实施步骤
- ✅ 新增：自动化评估与半自动执行标准流程
- ✅ 新增：断点续跑功能

### v1.2 (2026-03-29)
- ✅ 新增：分离式 SKU 结构支持（颜色/尺码笛卡尔积）

### v1.1 (2026-03-28)
- ✅ 新增：横向 3 列布局
- ✅ 新增：产品名称加序号（DG-XXX-01）

### v1.0 (2026-03-27)
- ✅ 初版：标准 SKU 提取
- ✅ 初版：expand-view-item 选择器
- ✅ 初版：汇率含义说明

---

**最后更新**: 2026-03-31  
**维护状态**: 活跃维护中
