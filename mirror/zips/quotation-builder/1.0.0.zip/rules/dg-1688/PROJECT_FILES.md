# DG-1688 项目文件清单

> 完整的项目文件结构和说明

---

## 📁 项目结构

```
dg-1688/
│
├── README.md                              # 项目说明文档（GitHub 首页显示）
├── GITHUB_DEPLOYMENT_GUIDE.md             # GitHub 部署指南
├── IMAGE_INSERT_CONFIG.md                 # 图片插入配置详解
├── SKILL.md                               # Skill 配置文档（OpenClaw 使用）
├── requirements.txt                       # Python 依赖列表
├── quickstart.py                          # 快速开始脚本
│
├── build_quote_from_detail.py             # 主程序：报价单生成器
├── image_handler.py                       # 图片处理模块
│
├── extract_sku_selection.js               # SKU 提取脚本（标准结构）
├── extract_sku_separated.js               # SKU 提取脚本（分离式结构）
│
├── scripts/
│   └── run_shop_filter_pipeline.py        # 店铺筛选抓取脚本
│
├── rules/
│   └── dg-1688/                           # 规则目录（与主目录相同文件）
│       └── [同上文件...]
│
└── output/                                # 输出目录（自动生成）
    ├── dg1688_template_quote_*.xlsx       # 生成的报价单
    └── sku_images/                        # SKU 图片缓存
```

---

## 📄 核心文件说明

### 1. 文档文件

| 文件名 | 用途 | 重要程度 |
|--------|------|----------|
| `README.md` | 项目说明文档，GitHub 首页显示 | ⭐⭐⭐⭐⭐ |
| `GITHUB_DEPLOYMENT_GUIDE.md` | GitHub 部署完整指南 | ⭐⭐⭐⭐⭐ |
| `IMAGE_INSERT_CONFIG.md` | 图片插入配置详解（故障排查） | ⭐⭐⭐⭐⭐ |
| `SKILL.md` | OpenClaw Skill 配置文档 | ⭐⭐⭐⭐ |
| `requirements.txt` | Python 依赖列表 | ⭐⭐⭐⭐ |

### 2. 核心代码

| 文件名 | 用途 | 重要程度 |
|--------|------|----------|
| `build_quote_from_detail.py` | 主程序：报价单生成器 | ⭐⭐⭐⭐⭐ |
| `image_handler.py` | 图片处理模块（下载/裁剪/缩放） | ⭐⭐⭐⭐⭐ |
| `extract_sku_selection.js` | SKU 提取脚本（标准结构） | ⭐⭐⭐⭐ |
| `extract_sku_separated.js` | SKU 提取脚本（分离式结构） | ⭐⭐⭐⭐ |

### 3. 辅助脚本

| 文件名 | 用途 | 重要程度 |
|--------|------|----------|
| `quickstart.py` | 快速开始脚本（交互式） | ⭐⭐⭐ |
| `scripts/run_shop_filter_pipeline.py` | 店铺筛选抓取脚本 | ⭐⭐⭐⭐ |

---

## 🔑 关键配置点

### 图片插入配置（必须严格遵守）

**文件位置:** `build_quote_from_detail.py` 第 470-485 行

```python
ws.insert_image(
    img_row,
    col_offset,
    img_path_normalized,
    {
        "x_offset": 5,
        "y_offset": 5,
        "x_scale": scale,
        "y_scale": scale,
        "positioning": 1,  # ⚠️ 关键参数！
    },
)
```

**参数说明:**
- `positioning: 1` - 图片嵌入单元格（随单元格移动和调整大小）
- `x_offset: 5` - 左边距 5 像素
- `y_offset: 5` - 上边距 5 像素
- `x_scale/y_scale` - 等比缩放比例

### 行高列宽配置

**文件位置:** `build_quote_from_detail.py` 第 437-449 行

```python
# 列宽设置
ws.set_column("A:A", 18)   # 图片 1
ws.set_column("D:D", 18)   # 图片 2
ws.set_column("G:G", 18)   # 图片 3

# 行高设置
ws.set_row(img_row, 120)   # 图片行高度（120 像素）
ws.set_row(data_row, 24)   # 数据行高度（24 像素）
```

### 图片处理配置

**文件位置:** `image_handler.py` 第 230-250 行

```python
def process_image_for_excel(image_url: str, temp_dir: str = "./tmp/images"):
    # 1. 下载图片
    local_path = download_image(image_url, temp_dir)
    
    # 2. 裁剪顶部 100px（去除编码水印）
    cropped_path = _crop_top_pixels(final_path, crop_top_px=100)
    
    # 3. 返回最终路径和尺寸
    return final_path, width, height
```

---

## 📋 上传到 GitHub 前的检查清单

### 文档检查

- [ ] README.md 包含完整的项目说明
- [ ] GITHUB_DEPLOYMENT_GUIDE.md 包含部署步骤
- [ ] IMAGE_INSERT_CONFIG.md 包含故障排查指南
- [ ] SKILL.md 包含配置说明
- [ ] requirements.txt 包含所有依赖
- [ ] LICENSE 文件已添加

### 代码检查

- [ ] build_quote_from_detail.py 包含图片插入配置
- [ ] image_handler.py 包含图片处理逻辑
- [ ] 所有 JavaScript 脚本已测试
- [ ] 辅助脚本可正常运行

### 清理检查

- [ ] 删除 output/ 目录中的临时文件
- [ ] 删除 tmp/ 目录中的缓存文件
- [ ] 删除 __pycache__/ 目录
- [ ] 删除 .pyc 文件
- [ ] 检查是否有敏感信息（API 密钥等）

### .gitignore 检查

确保 .gitignore 包含：

```text
# Python
__pycache__/
*.py[cod]
*.so
.eggs/
*.egg-info/

# 输出文件
output/
tmp/
*.xlsx

# IDE
.vscode/
.idea/
*.swp

# OS
.DS_Store
Thumbs.db
```

---

## 🚀 发布流程

### 1. 本地测试

```bash
# 安装依赖
pip install -r requirements.txt

# 运行快速开始脚本
python quickstart.py

# 测试报价单生成
python -c "from build_quote_from_detail import build_quote; build_quote('https://detail.1688.com/offer/xxx.html')"
```

### 2. 提交到 Git

```bash
# 初始化仓库（如未初始化）
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit: DG-1688 v1.4.0"

# 关联远程仓库
git remote add origin https://github.com/your-username/dg-1688-quotation-builder.git

# 推送
git push -u origin main
```

### 3. 创建 Release

1. 访问 GitHub 仓库页面
2. 点击 **Releases** → **Create a new release**
3. 填写版本信息（Tag: v1.4.0）
4. 发布

---

## 📞 维护说明

### 日常更新

```bash
# 修改代码后
git add .
git commit -m "Fix: 描述更改"
git push origin main
```

### 版本更新

```bash
# 1. 更新版本号（README.md, SKILL.md）
# 2. 更新更新日志
# 3. 创建标签
git tag -a v1.5.0 -m "Release version 1.5.0"

# 4. 推送标签
git push origin v1.5.0

# 5. 在 GitHub 创建 Release
```

### 问题修复

```bash
# 1. 创建修复分支
git checkout -b fix/issue-123

# 2. 修复代码
# ...

# 3. 提交并推送
git add .
git commit -m "Fix: 修复问题 #123"
git push origin fix/issue-123

# 4. 创建 Pull Request
```

---

## 📚 相关文档

- [README.md](README.md) - 项目说明
- [GITHUB_DEPLOYMENT_GUIDE.md](GITHUB_DEPLOYMENT_GUIDE.md) - GitHub 部署指南
- [IMAGE_INSERT_CONFIG.md](IMAGE_INSERT_CONFIG.md) - 图片插入配置详解
- [SKILL.md](SKILL.md) - Skill 配置文档

---

**最后更新**: 2026-03-31  
**维护状态**: 活跃维护中
