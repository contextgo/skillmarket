# DG-1688 报价单图片插入配置指南

## ⚠️ 重要提醒

**图片插入配置问题一直存在！每次生成报价单时必须严格按照以下步骤操作！**

---

## 📋 正确配置步骤

### 步骤 1：导入 image_handler 模块

```python
# 添加 quotation-builder 目录到 Python 路径
from pathlib import Path
import sys

quotation_builder_dir = Path(__file__).resolve().parent.parent / "skills" / "quotation-builder"
sys.path.insert(0, str(quotation_builder_dir))

# 导入图片处理函数
from image_handler import process_image_for_excel
```

### 步骤 2：使用 process_image_for_excel 处理图片

```python
# 处理图片（下载 + 裁剪顶部 100px 编码水印 + 返回本地路径）
img_path, w, h = process_image_for_excel(image_url, "./tmp/images")

# 验证图片是否处理成功
if img_path and Path(img_path).exists():
    # 继续下一步
else:
    # 处理失败，写入 "No Image"
    ws.write(img_row, col_offset, "No Image", base)
```

### 步骤 3：Windows 路径规范化

```python
# Windows 兼容性：将路径转换为正斜杠
img_path_normalized = str(Path(img_path).as_posix())
```

### 步骤 4：计算缩放比例

```python
# 图片显示框尺寸（像素）
box_w, box_h = 140.0, 100.0

# 计算等比缩放比例
scale = min(1.0, box_w / w, box_h / h) if w and h else 1.0
```

### 步骤 5：插入图片到 Excel 单元格（关键！）

```python
# 关键参数：positioning=1（图片随单元格移动和调整大小）
ws.insert_image(
    img_row,                    # 行索引
    col_offset,                 # 列索引（0=A, 3=D, 6=G）
    img_path_normalized,        # 图片路径（正斜杠）
    {
        "x_offset": 5,          # 左边距 5 像素
        "y_offset": 5,          # 上边距 5 像素
        "x_scale": scale,       # X 缩放比例
        "y_scale": scale,       # Y 缩放比例
        "positioning": 1,       # 关键！1=移动和调整大小与单元格
    },
)
```

---

## 🔑 关键参数说明

### insert_image 参数

| 参数 | 值 | 说明 |
|------|-----|------|
| `x_offset` | 5 | 图片左边距（像素） |
| `y_offset` | 5 | 图片上边距（像素） |
| `x_scale` | scale | X 轴缩放比例（0.0-1.0） |
| `y_scale` | scale | Y 轴缩放比例（0.0-1.0） |
| `positioning` | **1** | **关键！1=图片嵌入单元格** |

### positioning 参数值

| 值 | 说明 |
|----|------|
| **1** | **图片随单元格移动和调整大小（内嵌）** ✅ |
| 2 | 图片随单元格移动但大小固定 |
| 3 | 图片完全独立于单元格 |

**必须使用 positioning=1！**

---

## 📐 行高列宽设置

```python
# 列宽设置（9 列布局）
ws.set_column("A:A", 18)   # 图片 1
ws.set_column("B:B", 10)   # 链接 1 / CNY
ws.set_column("C:C", 14)   # 空 1 / USD
ws.set_column("D:D", 18)   # 图片 2
ws.set_column("E:E", 10)   # 链接 2 / CNY
ws.set_column("F:F", 14)   # 空 2 / USD
ws.set_column("G:G", 18)   # 图片 3
ws.set_column("H:H", 10)   # 链接 3 / CNY
ws.set_column("I:I", 14)   # 空 3 / USD

# 行高设置
ws.set_row(img_row, 120)   # 图片行高度（120 像素）
ws.set_row(data_row, 24)   # 数据行高度（24 像素）
```

---

## 🚫 常见错误

### ❌ 错误 1：直接使用 requests 下载图片

```python
# 错误！没有裁剪顶部编码水印
response = requests.get(image_url)
with open("image.jpg", "wb") as f:
    f.write(response.content)
ws.insert_image(img_row, col_offset, "image.jpg")  # 图片会包含顶部编码
```

### ❌ 错误 2：缺少 positioning 参数

```python
# 错误！图片不会嵌入单元格
ws.insert_image(img_row, col_offset, img_path)
```

### ❌ 错误 3：使用 Windows 反斜杠路径

```python
# 错误！xlsxwriter 可能无法识别
ws.insert_image(img_row, col_offset, "C:\\tmp\\image.jpg")

# 正确！使用正斜杠
ws.insert_image(img_row, col_offset, "C:/tmp/image.jpg")
```

### ❌ 错误 4：不计算缩放比例

```python
# 错误！图片可能过大溢出单元格
ws.insert_image(img_row, col_offset, img_path, {"x_scale": 1, "y_scale": 1})

# 正确！根据图片尺寸计算缩放
scale = min(1.0, 140.0 / w, 100.0 / h)
ws.insert_image(img_row, col_offset, img_path, {"x_scale": scale, "y_scale": scale})
```

---

## ✅ 完整代码示例

```python
#!/usr/bin/env python3
import sys
import xlsxwriter
from pathlib import Path

# 步骤 1：导入 image_handler
quotation_builder_dir = Path(__file__).resolve().parent.parent / "skills" / "quotation-builder"
sys.path.insert(0, str(quotation_builder_dir))
from image_handler import process_image_for_excel

def generate_quote(items, output_path):
    wb = xlsxwriter.Workbook(output_path)
    ws = wb.add_worksheet("Quotation")
    
    # 设置列宽
    ws.set_column("A:A", 18)
    ws.set_column("B:B", 10)
    ws.set_column("C:C", 14)
    # ... 其他列
    
    # 写入 header（7 行）
    # ... header 代码 ...
    
    # 定义格式
    base = wb.add_format({"align": "center", "valign": "vcenter", "border": 1})
    link_fmt = wb.add_format({"align": "center", "valign": "vcenter", "border": 1, "font_color": "#0563C1", "underline": 1})
    
    # 写入数据
    start_row = 7
    for group_idx in range(0, len(items), 3):
        group_items = items[group_idx:group_idx + 3]
        img_row = start_row + (group_idx // 3) * 2
        data_row = img_row + 1
        
        ws.set_row(img_row, 120)   # 图片行高度
        ws.set_row(data_row, 24)   # 数据行高度
        
        for i, item in enumerate(group_items):
            col_offset = i * 3
            image_url = item.get("imageUrl", "")
            
            # 步骤 2-5：处理并插入图片
            if image_url:
                img_path, w, h = process_image_for_excel(image_url, "./tmp/images")
                if img_path and Path(img_path).exists():
                    img_path_normalized = str(Path(img_path).as_posix())
                    box_w, box_h = 140.0, 100.0
                    scale = min(1.0, box_w / w, box_h / h) if w and h else 1.0
                    ws.insert_image(
                        img_row,
                        col_offset,
                        img_path_normalized,
                        {"x_offset": 5, "y_offset": 5, "x_scale": scale, "y_scale": scale, "positioning": 1},
                    )
                else:
                    ws.write(img_row, col_offset, "No Image", base)
            else:
                ws.write(img_row, col_offset, "No Image", base)
            
            # 写入链接
            link = item.get("link", "")
            if link.startswith(("http://", "https://")):
                ws.write_url(img_row, col_offset + 1, link, link_fmt, string="1688 Link")
            else:
                ws.write(img_row, col_offset + 1, link, base)
            ws.write(img_row, col_offset + 2, "", base)
            
            # 写入数据行
            # ... 数据行代码 ...
    
    wb.close()
    return output_path
```

---

## 📝 检查清单

每次生成报价单前，请确认：

- [ ] 已导入 `image_handler.process_image_for_excel`
- [ ] 使用 `process_image_for_excel()` 处理图片（不是直接 requests 下载）
- [ ] 路径转换为正斜杠：`Path(img_path).as_posix()`
- [ ] 计算缩放比例：`scale = min(1.0, 140.0/w, 100.0/h)`
- [ ] `insert_image` 参数包含 `positioning: 1`
- [ ] 图片行高度设置为 120 像素
- [ ] 图片列宽度设置为 18

---

## 🔧 故障排查

### 图片未显示

1. 检查 `process_image_for_excel` 返回值是否为 `(None, 0, 0)`
2. 检查 `./tmp/images` 目录是否有写入权限
3. 检查图片 URL 是否可访问

### 图片位置不对

1. 确认 `positioning=1` 参数已设置
2. 确认行高设置为 120 像素
3. 确认列宽设置为 18

### 图片过大溢出

1. 检查缩放比例计算是否正确
2. 确认 `box_w=140.0, box_h=100.0`
3. 确认 `scale = min(1.0, box_w/w, box_h/h)`

---

## 📚 相关文件

- `skills/quotation-builder/image_handler.py` - 图片处理模块
- `skills/quotation-builder/rules/dg-1688/build_quote_from_detail.py` - DG 报价单生成器
- `skills/quotation-builder/rules/dg-1688/dg-template.numbers` - DG 模板参考

---

**最后更新**: 2026-03-31  
**问题记录**: 图片插入配置问题多次出现，必须严格按此文档操作！
