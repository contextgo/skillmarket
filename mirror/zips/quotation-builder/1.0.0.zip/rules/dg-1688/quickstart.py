#!/usr/bin/env python3
"""
DG-1688 快速开始示例脚本

使用方法:
    python quickstart.py
"""

import sys
from pathlib import Path

# 添加 quotation-builder 目录到路径
quotation_builder_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(quotation_builder_dir))

from image_handler import process_image_for_excel
from rules.dg_1688.build_quote_from_detail import build_quote


def main():
    print("=" * 60)
    print("DG-1688 Quotation Builder - 快速开始示例")
    print("=" * 60)
    
    # 示例 1：从 1688 链接生成报价单
    print("\n[示例 1] 从 1688 详情页生成报价单")
    print("-" * 60)
    
    detail_url = input("请输入 1688 商品详情页 URL: ").strip()
    
    if not detail_url:
        print("❌ URL 不能为空！")
        return
    
    if not detail_url.startswith(("http://", "https://")):
        print("❌ URL 格式不正确！")
        return
    
    # 询问是否使用自定义汇率
    use_custom_fx = input("是否使用自定义汇率？(y/n, 默认 n): ").strip().lower()
    fx = 7.0
    
    if use_custom_fx == 'y':
        try:
            fx = float(input("请输入美元/人民币汇率 (默认 7.0): ").strip() or "7.0")
            print(f"✓ 使用汇率：1 USD = {fx} CNY")
        except ValueError:
            print("❌ 汇率必须是数字！")
            return
    
    # 生成报价单
    print(f"\n正在生成报价单...")
    print(f"  URL: {detail_url}")
    print(f"  汇率：{fx}")
    
    try:
        output_path = build_quote(detail_url, fx=fx)
        print(f"\n✅ 报价单生成成功！")
        print(f"   文件位置：{output_path}")
    except Exception as e:
        print(f"\n❌ 生成失败：{e}")
        print("\n可能的原因:")
        print("  1. 网络连接问题")
        print("  2. 1688 页面返回验证码")
        print("  3. 页面结构发生变化")
        print("\n建议:")
        print("  1. 检查网络连接")
        print("  2. 手动访问 URL 确认页面正常")
        print("  3. 查看日志获取详细错误信息")
    
    print("\n" + "=" * 60)
    print("示例结束")
    print("=" * 60)


if __name__ == "__main__":
    main()
