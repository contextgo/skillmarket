#!/usr/bin/env python3
"""
店铺筛选列表抓取流水线（web-access + CDP）

能力：
1) 进入店铺列表页并点击一级/二级筛选
2) 分页抓取产品名、价格、详情链接
3) 遇验证码自动中断并保存断点
4) 支持 --resume 从断点续跑
"""

from __future__ import annotations

import argparse
import json
import subprocess
import time
from pathlib import Path
from typing import Any, Dict

import requests

PROXY_BASE = "http://localhost:3456"


class PipelineError(RuntimeError):
    pass


def _proxy_get(path: str) -> Any:
    resp = requests.get(f"{PROXY_BASE}{path}", timeout=30)
    resp.raise_for_status()
    return resp.json()


def _proxy_eval(target_id: str, js_expr: str) -> Any:
    resp = requests.post(
        f"{PROXY_BASE}/eval",
        params={"target": target_id},
        data=js_expr.encode("utf-8"),
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise PipelineError(f"proxy eval failed: {data['error']}")
    return data.get("value")


def _run_dep_check() -> None:
    cmd = ["bash", str(Path.home() / ".claude/skills/web-access/scripts/check-deps.sh")]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        raise PipelineError(f"web-access 依赖检查失败:\n{p.stdout}\n{p.stderr}")


def _find_or_open_target(shop_url: str) -> str:
    targets = _proxy_get("/targets")
    if isinstance(targets, list):
        for t in targets:
            u = str(t.get("url", ""))
            if "milishipin.1688.com/page/offerlist" in u and "验证码" not in str(t.get("title", "")):
                tid = t.get("targetId")
                if tid:
                    return str(tid)
    data = _proxy_get(f"/new?url={shop_url}")
    tid = data.get("targetId")
    if not tid:
        raise PipelineError("无法创建店铺页 tab")
    return str(tid)


def _page_status(target_id: str) -> Dict[str, Any]:
    js = r"""(function(){
      const txt=(document.body&&document.body.innerText)||'';
      return {
        url: location.href,
        title: document.title,
        captcha: document.title.includes('验证码') || txt.includes('请按住滑块'),
        pageInfo: (txt.match(/\d+\/\d+/)||[''])[0],
        hasFilter: txt.includes('2026 新款 > 3月 上新')
      };
    })()"""
    return _proxy_eval(target_id, js) or {}


def _click_filters(target_id: str, first_filter: str, second_filter: str) -> Dict[str, Any]:
    js = rf"""(function(){{
      function clickLeaf(cands){{
        const leaves=[...document.querySelectorAll('div,span,a,button')].filter(n=>n.children.length===0);
        for(const t of cands){{
          const el=leaves.find(n=>(n.textContent||'').trim()===t);
          if(el){{ el.click(); return t; }}
        }}
        return '';
      }}
      const first = clickLeaf(['{first_filter}']);
      const second = clickLeaf(['{second_filter}', '{second_filter}（96）']);
      return {{first, second, url: location.href, title: document.title}};
    }})()"""
    return _proxy_eval(target_id, js) or {}


def _extract_page_items(target_id: str) -> Dict[str, Any]:
    js = r"""(function() {
      function getFiber(el) {
        var k = Object.keys(el || {}).find(function(x){ return x.indexOf('__reactInternalInstance') === 0; });
        return k ? el[k] : null;
      }
      function findDataProps(fiber) {
        var cur = fiber;
        for (var i = 0; i < 25 && cur; i++) {
          var props = cur.memoizedProps || cur.pendingProps;
          if (props && props.data && typeof props.data === 'object' && props.data.id && props.data.title) {
            return props.data;
          }
          cur = cur.return;
        }
        return null;
      }
      var imgs = Array.from(document.querySelectorAll('img.main-picture'));
      var rows = [];
      var seen = {};
      for (var i = 0; i < imgs.length; i++) {
        var fiber = getFiber(imgs[i]);
        if (!fiber) continue;
        var d = findDataProps(fiber);
        if (!d || !d.id || seen[d.id]) continue;
        seen[d.id] = true;
        rows.push({
          id: String(d.id),
          title: d.title || '',
          price: d.price || ''
        });
      }
      const txt=(document.body&&document.body.innerText)||'';
      return {
        count: rows.length,
        items: rows,
        pageInfo: (txt.match(/\d+\/\d+/)||[''])[0]
      };
    })()"""
    return _proxy_eval(target_id, js) or {}


def _click_next_page(target_id: str) -> bool:
    js = r"""(function(){
      const leaves=[...document.querySelectorAll('a,span,button,div')].filter(n=>n.children.length===0);
      const next=leaves.find(n=>{const t=(n.textContent||'').trim(); return t==='下一页 >' || t==='下一页';});
      if(!next) return false;
      const cls=((next.className||'')+' '+((next.parentElement&&next.parentElement.className)||'')).toLowerCase();
      if(cls.includes('disabled')) return false;
      next.click();
      return true;
    })()"""
    return bool(_proxy_eval(target_id, js))


def _save_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def run_pipeline(
    shop_url: str,
    first_filter: str,
    second_filter: str,
    output_path: Path,
    state_path: Path,
    resume: bool,
) -> Dict[str, Any]:
    _run_dep_check()
    target_id = _find_or_open_target(shop_url)

    if resume and state_path.exists():
        state = _load_json(state_path)
        items = state.get("items", [])
        seen_ids = set(state.get("seen_ids", []))
    else:
        items = []
        seen_ids = set()
        _click_filters(target_id, first_filter, second_filter)
        time.sleep(2.2)

    status = _page_status(target_id)
    if status.get("captcha"):
        state = {"status": "captcha", "target_id": target_id, "items": items, "seen_ids": sorted(seen_ids), "last_status": status}
        _save_json(state_path, state)
        raise PipelineError("当前页面仍是验证码拦截，请先手动通过后再执行 --resume")

    visited_pages = set()
    while True:
        status = _page_status(target_id)
        if status.get("captcha"):
            state = {"status": "captcha", "target_id": target_id, "items": items, "seen_ids": sorted(seen_ids), "last_status": status}
            _save_json(state_path, state)
            raise PipelineError("抓取中触发验证码，已保存断点，请手动验证后 --resume")

        page_data = _extract_page_items(target_id)
        page_info = str(page_data.get("pageInfo", "")).strip()
        if page_info and page_info in visited_pages:
            break
        if page_info:
            visited_pages.add(page_info)

        for it in page_data.get("items", []):
            oid = str(it.get("id", "")).strip()
            if not oid or oid in seen_ids:
                continue
            seen_ids.add(oid)
            try:
                price = float(it.get("price")) if str(it.get("price", "")).strip() else None
            except Exception:
                price = None
            items.append(
                {
                    "name": str(it.get("title", "")).strip(),
                    "priceCny": price,
                    "link": f"https://detail.1688.com/offer/{oid}.html",
                }
            )

        if not _click_next_page(target_id):
            break
        time.sleep(2.0)

    result = {
        "shop": shop_url,
        "filter": f"{first_filter} > {second_filter}",
        "count": len(items),
        "items": items,
    }
    _save_json(output_path, result)
    _save_json(
        state_path,
        {
            "status": "done",
            "target_id": target_id,
            "seen_ids": sorted(seen_ids),
            "count": len(items),
        },
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="店铺筛选列表抓取流水线（支持验证码断点续跑）")
    parser.add_argument("--shop-url", required=True, help="店铺 offerlist 链接")
    parser.add_argument("--first-filter", default="2026 新款", help="一级筛选文本")
    parser.add_argument("--second-filter", default="3月 上新", help="二级筛选文本")
    parser.add_argument(
        "--output",
        default="./tmp/shop_filtered_products.json",
        help="输出 JSON 路径",
    )
    parser.add_argument(
        "--state",
        default="./tmp/shop_filter_pipeline_state.json",
        help="断点状态文件路径",
    )
    parser.add_argument("--resume", action="store_true", help="从断点续跑")
    args = parser.parse_args()

    out = run_pipeline(
        shop_url=args.shop_url,
        first_filter=args.first_filter,
        second_filter=args.second_filter,
        output_path=Path(args.output),
        state_path=Path(args.state),
        resume=args.resume,
    )
    print(json.dumps({"status": "ok", "count": out["count"], "output": args.output}, ensure_ascii=False))


if __name__ == "__main__":
    main()
