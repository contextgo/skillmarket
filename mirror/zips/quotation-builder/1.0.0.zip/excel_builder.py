#!/usr/bin/env python3
"""
Excel 报价单生成引擎
负责生成排版专业、带公司信息的 Excel 报价单
"""

import os
import io
from typing import List, Dict, Any, Optional
import xlsxwriter
from image_handler import process_image_for_excel


# 样式常量
HEADER_BG_COLOR = '#1F4E79'
HEADER_FONT_COLOR = '#FFFFFF'
ODD_ROW_COLOR = '#FFFFFF'
EVEN_ROW_COLOR = '#F2F7FF'
ROW_HEIGHT_POINTS = 80  # 80pt 行高
MAX_IMAGE_SIZE = 90  # 图片最大尺寸


def generate_excel(
    products: List[Dict[str, Any]],
    company_info: Dict[str, Any],
    output_path: str,
    temp_dir: str = "./tmp/images"
) -> Dict[str, Any]:
    """
    生成 Excel 报价单

    Args:
        products: 产品字典列表，每个字典包含 sku, name, image_url, price, specs, moq, remarks
        company_info: 公司信息字典，包含 name, logo_path, website, contact_name, phone, whatsapp, email, address
        output_path: 输出文件路径
        temp_dir: 临时图片目录

    Returns:
        {"status": "ok", "file_path": str, "warnings": []} 或 {"status": "error", "message": str}
    """
    warnings = []

    try:
        # 确保输出目录存在
        os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)

        # 创建工作簿
        workbook = xlsxwriter.Workbook(output_path)
        worksheet = workbook.add_worksheet('Quotation')

        # 设置列宽
        _set_column_widths(worksheet)

        # 写入公司信息区（第 1-5 行）
        _write_company_info(workbook, worksheet, company_info, warnings)

        # 写入表头区（第 6 行）
        _write_header(workbook, worksheet)

        # 写入产品数据区（第 7 行起）
        _write_products(workbook, worksheet, products, temp_dir, warnings)

        workbook.close()

        return {
            "status": "ok",
            "file_path": output_path,
            "warnings": warnings
        }

    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to generate Excel: {str(e)}"
        }


def _set_column_widths(worksheet):
    """设置各列宽度"""
    worksheet.set_column('A:A', 15)  # Image
    worksheet.set_column('B:B', 30)  # Product Name
    worksheet.set_column('C:C', 25)  # Specifications
    worksheet.set_column('D:D', 15)  # Unit Price (USD)
    worksheet.set_column('E:E', 10)  # MOQ
    worksheet.set_column('F:F', 20)  # Remarks


def _write_company_info(workbook, worksheet, company_info: Dict[str, Any], warnings: List[str]):
    """写入公司信息区（第 1-5 行）"""

    # 合并单元格 A1:B5 用于 Logo
    worksheet.merge_range('A1:B5', '', None)

    # 合并单元格 C1:F5 用于联系信息
    worksheet.merge_range('C1:F5', '', None)

    # 插入 Logo
    logo_path = company_info.get('logo_path', '')
    if logo_path and os.path.exists(logo_path):
        try:
            # 处理 Logo（等比缩放，最大 200px 宽，100px 高）
            logo_result, logo_w, logo_h = process_image_for_excel(logo_path)
            if logo_result:
                # Windows 兼容性：将反斜杠转换为正斜杠
                logo_path_normalized = os.path.normpath(logo_result).replace('\\', '/')
                worksheet.insert_image('A1', logo_path_normalized, {
                    'x_offset': 10,
                    'y_offset': 10,
                    'x_scale': min(1.0, 200 / logo_w) if logo_w > 0 else 1.0,
                    'y_scale': min(1.0, 100 / logo_h) if logo_h > 0 else 1.0,
                    'positioning': 1  # 随单元格移动但不改变大小
                })
        except Exception as e:
            warnings.append(f"logo_load_failed: {e}")
    else:
        if logo_path:
            warnings.append(f"logo_load_failed: file not found at {logo_path}")

    # 创建样式
    name_format = workbook.add_format({
        'bold': True,
        'font_size': 14,
        'font_color': '#000000',
        'align': 'left',
        'valign': 'top'
    })

    info_format = workbook.add_format({
        'font_size': 10,
        'font_color': '#000000',
        'align': 'left',
        'valign': 'top'
    })

    # 准备联系信息文本
    company_name = company_info.get('name', 'Company Name')
    website = company_info.get('website', '')
    contact_name = company_info.get('contact_name', '')
    phone = company_info.get('phone', '')
    whatsapp = company_info.get('whatsapp', '')
    email = company_info.get('email', '')
    address = company_info.get('address', '')

    # 构建联系信息文本
    info_lines = [company_name]
    if website:
        info_lines.append(f"Website: {website}")
    if contact_name:
        info_lines.append(f"Contact: {contact_name}")
    if phone:
        info_lines.append(f"Phone: {phone}")
    if whatsapp:
        info_lines.append(f"WhatsApp: {whatsapp}")
    if email:
        info_lines.append(f"Email: {email}")
    if address:
        info_lines.append(f"Address: {address}")

    info_text = '\n'.join(info_lines)

    # 写入公司信息到 C1:F5 区域
    worksheet.write('C1', info_text, info_format)

    # 单独写入公司名称（加粗格式）
    worksheet.write('C1', company_name, name_format)


def _write_header(workbook, worksheet):
    """写入表头区（第 6 行）"""

    # 表头样式
    header_format = workbook.add_format({
        'bold': True,
        'font_size': 12,
        'font_color': HEADER_FONT_COLOR,
        'bg_color': HEADER_BG_COLOR,
        'align': 'center',
        'valign': 'vcenter',
        'border': 1,
        'border_color': '#CCCCCC'
    })

    headers = ['Image', 'Product Name', 'Specifications', 'Unit Price (USD)', 'MOQ', 'Remarks']

    for col, header in enumerate(headers):
        worksheet.write(5, col, header, header_format)  # 第 6 行（索引 5）

    # 设置表头行高
    worksheet.set_row(5, 20)  # 表头行高 20pt


def _write_products(workbook, worksheet, products: List[Dict], temp_dir: str, warnings: List[str]):
    """写入产品数据区（第 7 行起）"""

    # 创建单元格样式
    odd_format = workbook.add_format({
        'align': 'left' if False else 'center',  # Product Name 左对齐，其他居中
        'valign': 'vcenter',
        'text_wrap': True,
        'bg_color': ODD_ROW_COLOR,
        'border': 1,
        'border_color': '#E0E0E0'
    })

    even_format = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'text_wrap': True,
        'bg_color': EVEN_ROW_COLOR,
        'border': 1,
        'border_color': '#E0E0E0'
    })

    # 左对齐格式（用于 Product Name）
    name_odd_format = workbook.add_format({
        'align': 'left',
        'valign': 'vcenter',
        'text_wrap': True,
        'bg_color': ODD_ROW_COLOR,
        'border': 1,
        'border_color': '#E0E0E0'
    })

    name_even_format = workbook.add_format({
        'align': 'left',
        'valign': 'vcenter',
        'text_wrap': True,
        'bg_color': EVEN_ROW_COLOR,
        'border': 1,
        'border_color': '#E0E0E0'
    })

    # 价格格式（保留 2 位小数，前缀 $）
    price_odd_format = workbook.add_format({
        'num_format': '"$"#,##0.00',
        'align': 'center',
        'valign': 'vcenter',
        'bg_color': ODD_ROW_COLOR,
        'border': 1,
        'border_color': '#E0E0E0'
    })

    price_even_format = workbook.add_format({
        'num_format': '"$"#,##0.00',
        'align': 'center',
        'valign': 'vcenter',
        'bg_color': EVEN_ROW_COLOR,
        'border': 1,
        'border_color': '#E0E0E0'
    })

    # 无图片占位符样式（灰色斜体）
    no_image_format = workbook.add_format({
        'italic': True,
        'font_color': '#999999',
        'align': 'center',
        'valign': 'vcenter'
    })

    # 写入每个产品
    for idx, product in enumerate(products):
        row = 6 + idx  # 从第 7 行开始（索引 6）

        # 设置行高
        worksheet.set_row(row, ROW_HEIGHT_POINTS)

        # 确定使用奇数行还是偶数行格式
        is_odd = idx % 2 == 0
        base_format = odd_format if is_odd else even_format
        name_format = name_odd_format if is_odd else name_even_format
        price_format = price_odd_format if is_odd else price_even_format

        # 列 A: 图片
        image_url = product.get('image_url', '')
        if image_url:
            try:
                img_path, img_w, img_h = process_image_for_excel(image_url, temp_dir)
                if img_path and os.path.exists(img_path):
                    # Windows 兼容性：将反斜杠转换为正斜杠，确保 xlsxwriter 正确识别路径
                    img_path_normalized = os.path.normpath(img_path).replace('\\', '/')
                    # 计算居中偏移
                    # 不压缩图片文件本身，仅在 Excel 中做显示缩放
                    max_px = 90
                    x_scale = min(1.0, max_px / img_w) if img_w > 0 else 1.0
                    y_scale = min(1.0, max_px / img_h) if img_h > 0 else 1.0
                    x_offset = (15 * 8 - int(img_w * x_scale)) // 2 if img_w < 120 else 10
                    y_offset = (ROW_HEIGHT_POINTS - int(img_h * y_scale)) // 2 if img_h < ROW_HEIGHT_POINTS else 10

                    worksheet.insert_image(row, 0, img_path_normalized, {
                        'x_offset': max(10, x_offset),
                        'y_offset': max(10, y_offset),
                        'x_scale': x_scale,
                        'y_scale': y_scale,
                        'positioning': 1
                    })
                else:
                    worksheet.write(row, 0, "No Image", no_image_format)
                    warnings.append(f"image_failed: {product.get('name', 'Unknown')}")
            except Exception as e:
                worksheet.write(row, 0, "No Image", no_image_format)
                warnings.append(f"image_failed: {product.get('name', 'Unknown')} - {e}")
        else:
            worksheet.write(row, 0, "No Image", no_image_format)

        # 列 B: Product Name（左对齐）
        worksheet.write(row, 1, product.get('name', ''), name_format)

        # 列 C: Specifications
        worksheet.write(row, 2, product.get('specs', ''), base_format)

        # 列 D: Unit Price（数字格式，前缀 $）
        # 私密价或不可用价格保持空白，避免错位和误导
        raw_price = product.get('price')
        if raw_price in (None, "", "私密价"):
            worksheet.write_blank(row, 3, None, base_format)
        else:
            try:
                price = float(raw_price)
                worksheet.write_number(row, 3, price, price_format)
            except (TypeError, ValueError):
                worksheet.write_blank(row, 3, None, base_format)

        # 列 E: MOQ（整数）
        moq = int(product.get('moq', 1))
        worksheet.write_number(row, 4, moq, base_format)

        # 列 F: Remarks
        worksheet.write(row, 5, product.get('remarks', ''), base_format)


if __name__ == "__main__":
    # 简单测试
    print("Testing Excel builder...")

    # 测试数据
    test_products = [
        {
            "sku": "MS-001",
            "name": "Wireless Mouse 2.4G with Ergonomic Design",
            "image_url": "",  # 空图片测试降级
            "price": 25.00,
            "specs": "Color: Black; DPI: 1600; Battery: AA",
            "moq": 100,
            "remarks": "Lead time: 7 days"
        },
        {
            "sku": "KB-001",
            "name": "Bluetooth Mechanical Keyboard",
            "image_url": "",  # 空图片测试降级
            "price": 45.50,
            "specs": "Color: White; Layout: US; Switch: Blue",
            "moq": 50,
            "remarks": "OEM available"
        }
    ]

    test_company = {
        "name": "Test Trade Co., Ltd.",
        "logo_path": "",  # 无 Logo 测试
        "website": "https://test.example.com",
        "contact_name": "John Doe",
        "phone": "+86-138-0000-0000",
        "whatsapp": "+86-138-0000-0000",
        "email": "sales@test.com",
        "address": "Shenzhen, China"
    }

    output = "./output/test_quotation.xlsx"

    result = generate_excel(test_products, test_company, output)
    print(f"Result: {result}")

    if result['status'] == 'ok':
        print(f"Excel generated successfully: {result['file_path']}")
        print(f"Warnings: {result['warnings']}")
    else:
        print(f"Error: {result['message']}")

    print("\nExcel builder test completed!")
