#!/usr/bin/env python3
"""
规则包动态加载器：
- 约定规则目录：rules/{rule_name}/
- 约定入口文件：build_quote_from_detail.py
- 约定函数：build_quote(url, **kwargs) -> str
"""

from __future__ import annotations

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Dict, List


PROJECT_ROOT = Path(__file__).resolve().parent
RULES_DIR = PROJECT_ROOT / "rules"
ENTRY_FILE = "build_quote_from_detail.py"


def _candidate_rule_dirs(rule_name: str) -> List[Path]:
    normalized = (rule_name or "").strip()
    if not normalized:
        return []
    variants = {
        normalized,
        normalized.replace("_", "-"),
        normalized.replace("-", "_"),
    }
    return [RULES_DIR / v for v in variants]


def resolve_rule_dir(rule_name: str) -> Path:
    for path in _candidate_rule_dirs(rule_name):
        if path.exists() and path.is_dir():
            return path
    raise FileNotFoundError(f"Rule '{rule_name}' not found under {RULES_DIR}")


def list_rules() -> List[str]:
    if not RULES_DIR.exists():
        return []
    result: List[str] = []
    for child in RULES_DIR.iterdir():
        if not child.is_dir():
            continue
        if child.name.startswith("__"):
            continue
        if (child / ENTRY_FILE).exists():
            result.append(child.name)
    return sorted(result)


def load_rule_module(rule_name: str) -> ModuleType:
    rule_dir = resolve_rule_dir(rule_name)
    entry = rule_dir / ENTRY_FILE
    if not entry.exists():
        raise FileNotFoundError(f"Rule '{rule_name}' missing entry file: {entry}")

    spec = spec_from_file_location(f"rule_{rule_dir.name}", entry)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load rule module from {entry}")

    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_rule_entry(rule_name: str) -> Callable[..., str]:
    module = load_rule_module(rule_name)
    func = getattr(module, "build_quote", None)
    if not callable(func):
        raise AttributeError(f"Rule '{rule_name}' must define callable build_quote(url, **kwargs)")
    return func


def run_rule(rule_name: str, url: str, kwargs: Dict[str, Any] | None = None) -> str:
    if not url:
        raise ValueError("url is required to execute rule")
    kwargs = kwargs or {}
    entry = load_rule_entry(rule_name)
    return entry(url, **kwargs)


def extract_rule_items(rule_name: str, url: str, kwargs: Dict[str, Any] | None = None) -> List[Dict[str, Any]]:
    if not url:
        raise ValueError("url is required to extract rule items")
    kwargs = kwargs or {}
    module = load_rule_module(rule_name)
    extractor = getattr(module, "extract_quote_items", None)
    if not callable(extractor):
        raise AttributeError(f"Rule '{rule_name}' must define callable extract_quote_items(url, **kwargs)")
    items = extractor(url, **kwargs)
    if not isinstance(items, list):
        raise TypeError("extract_quote_items must return a list")
    return items

