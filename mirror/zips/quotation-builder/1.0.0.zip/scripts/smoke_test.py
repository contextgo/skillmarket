#!/usr/bin/env python3
"""
发布前 smoke test：
1) CLI 可启动
2) search_csv 可用
3) generate_excel 最小样例可用
"""

import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PYTHON = sys.executable


def run_cmd(args):
    proc = subprocess.run(
        args,
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    return proc.returncode, proc.stdout, proc.stderr


def main():
    # 1) --help
    code, out, err = run_cmd([PYTHON, "main.py", "--help"])
    if code != 0:
        print("FAIL: CLI --help failed")
        print(err or out)
        return 1

    # 2) search_csv
    code, out, err = run_cmd([PYTHON, "main.py", "--action", "search_csv", "--query", "mouse"])
    if code != 0:
        print("FAIL: search_csv command failed")
        print(err or out)
        return 1
    try:
        payload = json.loads(out)
        if payload.get("status") != "ok":
            print("FAIL: search_csv status not ok")
            print(out)
            return 1
    except Exception:
        print("FAIL: search_csv output is not valid JSON")
        print(out)
        return 1

    # 3) generate_excel 最小样例（无网络图片，避免外网波动）
    output_path = "./output/smoke_test_quote.xlsx"
    products = json.dumps([
        {
            "sku": "SMOKE-001",
            "name": "Smoke Test Product",
            "image_url": "",
            "price": 12.34,
            "specs": "Color: Black",
            "moq": 10,
            "remarks": "smoke test",
        }
    ], ensure_ascii=False)
    company = json.dumps({
        "name": "Smoke Test Co., Ltd.",
        "website": "https://example.com",
        "contact_name": "Tester",
        "phone": "+86-000-0000-0000",
        "email": "test@example.com",
    }, ensure_ascii=False)

    code, out, err = run_cmd([
        PYTHON,
        "main.py",
        "--action",
        "generate_excel",
        "--products",
        products,
        "--company",
        company,
        "--output",
        output_path,
    ])
    if code != 0:
        print("FAIL: generate_excel command failed")
        print(err or out)
        return 1
    try:
        payload = json.loads(out)
        if payload.get("status") != "ok":
            print("FAIL: generate_excel status not ok")
            print(out)
            return 1
        fp = ROOT / payload.get("file_path", "")
        if not fp.exists():
            print("FAIL: generated file not found", fp)
            return 1
    except Exception:
        print("FAIL: generate_excel output is not valid JSON")
        print(out)
        return 1

    print("PASS: smoke tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

