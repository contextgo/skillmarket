#!/usr/bin/env python3
"""
兼容入口：脚本已迁移到 rules/dg-1688/scripts 目录。
保留该文件以避免旧命令失效。
"""

from pathlib import Path
import runpy


if __name__ == "__main__":
    new_script = Path(__file__).resolve().parents[1] / "rules/dg-1688/scripts/run_shop_filter_pipeline.py"
    runpy.run_path(str(new_script), run_name="__main__")

