#!/usr/bin/env python3
"""
CSV 产品库管理模块
负责本地产品数据的检索和预留入库接口
"""

import csv
import os
from pathlib import Path
from typing import List, Dict, Any, Optional
import pandas as pd


def search_csv(query: str, csv_path: str = "./data/local_products.csv") -> List[Dict[str, Any]]:
    """
    搜索本地产品库 CSV 文件

    搜索逻辑：
    1. 优先对 SKU 字段进行精确匹配（大小写不敏感）
    2. 若无精确匹配，对 Name 字段进行模糊匹配
    3. 返回所有匹配的产品字典列表

    Args:
        query: 搜索关键词（SKU 或产品名称）
        csv_path: CSV 文件路径，默认为 ./data/local_products.csv

    Returns:
        匹配到的产品字典列表，格式为 ProductDict
        无匹配时返回空列表 []
    """
    results = []

    if not os.path.exists(csv_path):
        return results

    try:
        df = pd.read_csv(csv_path)

        # 标准化查询词
        query_lower = query.lower().strip()

        # 1. 尝试 SKU 精确匹配（大小写不敏感）
        if 'SKU' in df.columns:
            sku_match = df[df['SKU'].str.lower() == query_lower]
            if not sku_match.empty:
                results = _dataframe_to_dicts(sku_match)
                return results

        # 2. 对 Name 字段进行模糊匹配
        if 'Name' in df.columns:
            name_match = df[df['Name'].str.lower().str.contains(query_lower, na=False)]
            if not name_match.empty:
                results = _dataframe_to_dicts(name_match)
                return results

    except Exception as e:
        # 返回空列表，不报错
        print(f"Warning: CSV search error: {e}")

    return results


def _dataframe_to_dicts(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """将 DataFrame 转换为标准化的 ProductDict 列表"""
    results = []

    for _, row in df.iterrows():
        product = {
            "sku": str(row.get('SKU', '')).strip(),
            "name": str(row.get('Name', '')).strip(),
            "image_url": str(row.get('Image_URL', '')).strip(),
            "price": float(row.get('Price', 0)) if pd.notna(row.get('Price')) else 0.0,
            "specs": str(row.get('Specs', '')).strip(),
            "moq": int(row.get('MOQ', 1)) if pd.notna(row.get('MOQ')) else 1,
            "remarks": str(row.get('Remarks', '')).strip(),
            "source": "csv"
        }
        results.append(product)

    return results


def insert_product(data: Dict[str, Any], csv_path: str = "./data/local_products.csv") -> bool:
    """
    插入新产品到 CSV（预留接口，当前版本暂不实现具体逻辑）

    Args:
        data: 产品数据字典，应包含 SKU, Name, Image_URL, Price, Specs, MOQ, Remarks 字段
        csv_path: CSV 文件路径

    Returns:
        成功返回 True（当前版本仅返回 True，不实际写入）
    """
    # 预留接口，供后续 ERP 或爬虫自动入库使用
    # 当前版本仅返回 True，不实际执行写入
    return True


def load_all_products(csv_path: str = "./data/local_products.csv") -> List[Dict[str, Any]]:
    """
    加载所有产品数据

    Args:
        csv_path: CSV 文件路径

    Returns:
        所有产品字典列表
    """
    if not os.path.exists(csv_path):
        return []

    try:
        df = pd.read_csv(csv_path)
        return _dataframe_to_dicts(df)
    except Exception as e:
        print(f"Warning: Failed to load CSV: {e}")
        return []


if __name__ == "__main__":
    # 简单测试
    print("Testing CSV manager...")

    # 创建测试数据
    test_csv = "./data/test_products.csv"
    os.makedirs(os.path.dirname(test_csv), exist_ok=True)

    test_data = [
        ["SKU", "Name", "Image_URL", "Price", "Specs", "MOQ", "Remarks"],
        ["MS-001", "Wireless Mouse 2.4G", "https://example.com/mouse1.jpg", "15.50", "Color: Black; DPI: 1600", "100", "Lead time: 7 days"],
        ["KB-001", "Bluetooth Keyboard", "https://example.com/kb1.jpg", "25.00", "Color: White; Layout: US", "50", ""],
        ["MS-002", "Gaming Mouse RGB", "https://example.com/mouse2.jpg", "35.00", "Color: RGB; DPI: 3200", "200", "Gaming series"],
    ]

    with open(test_csv, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerows(test_data)

    # 测试搜索
    print("\nTest 1: Search by SKU 'MS-001'")
    results = search_csv("MS-001", test_csv)
    print(f"Found {len(results)} product(s)")
    for r in results:
        print(f"  - {r['sku']}: {r['name']}")

    print("\nTest 2: Search by name 'mouse' (fuzzy)")
    results = search_csv("mouse", test_csv)
    print(f"Found {len(results)} product(s)")
    for r in results:
        print(f"  - {r['sku']}: {r['name']}")

    print("\nTest 3: Search non-existent 'xyz'")
    results = search_csv("xyz", test_csv)
    print(f"Found {len(results)} product(s)")

    # 清理测试文件
    os.remove(test_csv)
    print("\nCSV manager tests passed!")
