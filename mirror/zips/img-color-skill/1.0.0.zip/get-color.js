const sharp = require('sharp');
const fs = require('fs');

// ============================================================
// 颜色量化步长（越小颜色越精确，越大聚类越粗）
// ============================================================
const QUANTIZE_STEP = 24; // 24 ≈ 256/10, 每个通道分 10 档

// ============================================================
// RGB 转 HSL
// ============================================================
function rgbToHsl(r, g, b) {
  r /= 255;
  g /= 255;
  b /= 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const delta = max - min;

  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (delta !== 0) {
    s = l > 0.5 ? delta / (2 - max - min) : delta / (max + min);

    switch (max) {
      case r:
        h = ((g - b) / delta + (g < b ? 6 : 0)) / 6;
        break;
      case g:
        h = ((b - r) / delta + 2) / 6;
        break;
      case b:
        h = ((r - g) / delta + 4) / 6;
        break;
    }
  }

  return {
    h: Math.round(h * 360),
    s: Math.round(s * 100),
    l: Math.round(l * 100),
  };
}

// ============================================================
// 格式化输出
// ============================================================
function formatRgb(r, g, b) {
  return `rgb(${r},${g},${b})`;
}

function formatHsl(r, g, b) {
  const hsl = rgbToHsl(r, g, b);
  return `hsl(${hsl.h},${hsl.s}%,${hsl.l}%)`;
}

function formatHex(r, g, b) {
  return '#' + [r, g, b].map(c => c.toString(16).padStart(2, '0').toUpperCase()).join('');
}

// ============================================================
// 量化颜色（用于聚类）
// ============================================================
function quantizeColor(r, g, b) {
  return {
    r: Math.floor(r / QUANTIZE_STEP) * QUANTIZE_STEP,
    g: Math.floor(g / QUANTIZE_STEP) * QUANTIZE_STEP,
    b: Math.floor(b / QUANTIZE_STEP) * QUANTIZE_STEP,
  };
}

// ============================================================
// 计算颜色距离（欧几里得）
// ============================================================
function colorDistance(c1, c2) {
  return Math.sqrt(
    Math.pow(c1.r - c2.r, 2) +
    Math.pow(c1.g - c2.g, 2) +
    Math.pow(c1.b - c2.b, 2)
  );
}

// ============================================================
// 提取调色板
// ============================================================
async function extractPalette(imagePath, colorCount = 10) {
  // 缩小图片以加速处理，同时保持颜色代表性
  const { data, info } = await sharp(imagePath)
    .resize(150, 150, { fit: 'inside', withoutEnlargement: true })
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const totalPixels = info.width * info.height;

  // 第一阶段：量化聚类
  const colorMap = new Map();

  for (let i = 0; i < data.length; i += info.channels) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const a = info.channels > 3 ? data[i + 3] : 255;

    // 跳过完全透明的像素
    if (a < 128) continue;

    const quantized = quantizeColor(r, g, b);
    const key = `${quantized.r},${quantized.g},${quantized.b}`;

    if (!colorMap.has(key)) {
      colorMap.set(key, { r, g, b, count: 0, sumR: 0, sumG: 0, sumB: 0 });
    }

    const entry = colorMap.get(key);
    entry.count++;
    entry.sumR += r;
    entry.sumG += g;
    entry.sumB += b;
  }

  // 转换为数组并计算平均颜色
  let colors = Array.from(colorMap.values()).map(entry => ({
    r: Math.round(entry.sumR / entry.count),
    g: Math.round(entry.sumG / entry.count),
    b: Math.round(entry.sumB / entry.count),
    count: entry.count,
    percentage: (entry.count / totalPixels * 100).toFixed(1),
  }));

  // 按数量排序
  colors.sort((a, b) => b.count - a.count);

  // 第二阶段：合并相似颜色（去重）
  const mergedColors = [];
  const MIN_DISTANCE = 30; // 相似颜色阈值

  for (const color of colors) {
    let isSimilar = false;
    for (const merged of mergedColors) {
      const dist = colorDistance(color, merged);
      if (dist < MIN_DISTANCE) {
        // 合并：加权平均
        const totalCount = merged.count + color.count;
        merged.r = Math.round((merged.r * merged.count + color.r * color.count) / totalCount);
        merged.g = Math.round((merged.g * merged.count + color.g * color.count) / totalCount);
        merged.b = Math.round((merged.b * merged.count + color.b * color.count) / totalCount);
        merged.count += color.count;
        merged.percentage = (merged.count / totalPixels * 100).toFixed(1);
        isSimilar = true;
        break;
      }
    }
    if (!isSimilar) {
      mergedColors.push({ ...color });
    }
  }

  // 返回前 N 个颜色
  return mergedColors.slice(0, colorCount).map(c => ({
    hex: formatHex(c.r, c.g, c.b),
    rgb: formatRgb(c.r, c.g, c.b),
    hsl: formatHsl(c.r, c.g, c.b),
    percentage: parseFloat(c.percentage),
  }));
}

// ============================================================
// 单点/区域取色
// ============================================================
async function getColor(imagePath, x, y, w, h, format) {
  const region = sharp(imagePath).extract({ left: x, top: y, width: w, height: h });

  const { data, info } = await region
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const pixelCount = info.width * info.height;

  let sumR = 0, sumG = 0, sumB = 0;

  for (let i = 0; i < data.length; i += info.channels) {
    sumR += data[i];
    sumG += data[i + 1];
    sumB += data[i + 2];
  }

  const avgR = Math.round(sumR / pixelCount);
  const avgG = Math.round(sumG / pixelCount);
  const avgB = Math.round(sumB / pixelCount);

  if (format === 'hex') {
    console.log(formatHex(avgR, avgG, avgB));
  } else if (format === 'rgb') {
    console.log(formatRgb(avgR, avgG, avgB));
  } else if (format === 'hsl') {
    console.log(formatHsl(avgR, avgG, avgB));
  } else {
    console.log(JSON.stringify({
      hex: formatHex(avgR, avgG, avgB),
      rgb: formatRgb(avgR, avgG, avgB),
      hsl: formatHsl(avgR, avgG, avgB),
    }));
  }
}

// ============================================================
// 主入口
// ============================================================
async function main() {
  const args = process.argv.slice(2);

  // 解析选项
  let format = null;
  let paletteCount = null;
  const positional = [];

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--format') {
      if (i + 1 < args.length) {
        format = args[i + 1];
        i++;
      }
    } else if (args[i] === '--palette') {
      if (i + 1 < args.length) {
        paletteCount = parseInt(args[i + 1], 10);
        i++;
      } else {
        paletteCount = 10; // 默认 10 色
      }
    } else {
      positional.push(args[i]);
    }
  }

  // 检查文件
  if (positional.length < 1) {
    console.error('Usage:');
    console.error('  node get-color.js <image> --palette [count]     # 提取调色板');
    console.error('  node get-color.js <image> <x> <y> [<w> <h>] [--format hex|rgb|hsl]');
    process.exit(1);
  }

  const imagePath = positional[0];

  if (!fs.existsSync(imagePath)) {
    console.error(`Error: image file not found: ${imagePath}`);
    process.exit(1);
  }

  // 调色板模式
  if (paletteCount !== null) {
    const palette = await extractPalette(imagePath, paletteCount);
    console.log(JSON.stringify(palette, null, 2));
    return;
  }

  // 取色模式
  if (positional.length < 3) {
    console.error('Usage: node get-color.js <image> <x> <y> [<w> <h>] [--format hex|rgb|hsl]');
    process.exit(1);
  }

  const x = parseInt(positional[1], 10);
  const y = parseInt(positional[2], 10);
  const w = positional.length >= 5 ? parseInt(positional[3], 10) : 1;
  const h = positional.length >= 5 ? parseInt(positional[4], 10) : 1;

  if (isNaN(x) || isNaN(y) || isNaN(w) || isNaN(h)) {
    console.error('Error: x, y, w, h must be valid integers');
    process.exit(1);
  }
  if (x < 0 || y < 0 || w < 0 || h < 0) {
    console.error('Error: x, y, w, h must be non-negative integers');
    process.exit(1);
  }

  if (format && !['hex', 'rgb', 'hsl'].includes(format)) {
    console.error('Error: --format must be one of: hex, rgb, hsl');
    process.exit(1);
  }

  await getColor(imagePath, x, y, w, h, format);
}

main().catch(err => {
  console.error(`Error: ${err.message}`);
  process.exit(1);
});
