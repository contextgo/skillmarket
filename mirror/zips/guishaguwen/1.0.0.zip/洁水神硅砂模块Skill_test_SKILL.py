#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
洁水神硅砂模块产品顾问 - 功能测试
"""

import sys
sys.path.insert(0, '.')

from 洁水神硅砂模块Skill.skill_main import JieshuishenSkill

def test_all_features():
    """测试所有功能"""
    print("=" * 60)
    print("洁水神硅砂模块产品顾问 - 功能测试")
    print("=" * 60)
    print()
    
    skill = JieshuishenSkill()
    
    test_cases = [
        # 1. 价格查询
        ("价格查询 - 按立方", "100立方多少钱？"),
        ("价格查询 - 按块", "500块多少钱？"),
        
        # 2. 联系方式
        ("联系方式", "怎么联系你们？"),
        ("联系方式", "找蔡经理"),
        
        # 3. 发货网点
        ("发货网点 - 全部", "从哪里发货？"),
        ("发货网点 - 按省份", "发到山东从哪里发？"),
        
        # 4. 质保服务
        ("质保服务 - 全部", "质保期多久？"),
        ("质保服务 - 结构", "结构质保多久？"),
        ("质保服务 - 防渗", "防渗质保多久？"),
        
        # 5. 技术响应
        ("技术响应", "技术支持怎么联系？"),
        ("技术响应", "响应时效多久？"),
        
        # 6. 用量计算
        ("用量计算", "10米长5米宽2米高需要多少块？"),
        
        # 7. LCC分析
        ("LCC分析", "100立方的50年全生命周期成本？"),
        
        # 8. 12项检测对比
        ("12项检测对比", "和传统搭接式模块对比有哪些优势？"),
        
        # 9. 参数查询
        ("参数查询", "产品参数有哪些？"),
        
        # 10. FAQ
        ("FAQ", "使用寿命多久？"),
        
        # 11. 选型推荐
        ("选型推荐", "雨水花园用什么型号？"),
        
        # 12. 安装指导
        ("安装指导", "怎么安装施工？"),
    ]
    
    for test_name, query in test_cases:
        print(f"\n{'='*60}")
        print(f"【测试】{test_name}")
        print(f"【输入】{query}")
        print("-" * 60)
        try:
            result = skill.handle_query(query)
            print(result)
        except Exception as e:
            print(f"❌ 测试失败: {e}")
    
    print("\n" + "=" * 60)
    print("所有测试完成！")
    print("=" * 60)


if __name__ == "__main__":
    test_all_features()
