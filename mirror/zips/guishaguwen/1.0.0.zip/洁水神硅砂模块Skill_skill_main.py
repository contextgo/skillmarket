#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
洁水神硅砂模块产品顾问 AI Skill
Author: 徐州洁水神环境工程科技有限公司
Version: 2.0.0
"""

import json
import os
import re
from typing import Dict, List, Any, Optional


class JieshuishenSkill:
    """洁水神硅砂模块产品顾问核心类"""
    
    def __init__(self, skill_data_path: str = "skill.json"):
        """初始化技能，加载产品数据"""
        # 尝试多个路径
        possible_paths = [
            skill_data_path,
            os.path.join(os.path.dirname(__file__), skill_data_path),
            "洁水神硅砂模块Skill/" + skill_data_path,
            "./洁水神硅砂模块Skill/" + skill_data_path
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    self.data = json.load(f)
                self.base_path = os.path.dirname(path)
                break
        else:
            # 默认使用当前目录
            with open(skill_data_path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
            self.base_path = "."
        
        self.product = self.data['product_data']
        self.engineering = self.data['engineering_data']
        self.installation = self.data['installation_guide']
        self.comparison = self.data['comparison_analysis']
        self.faq = self.data['faq']
        self.pricing = self.product['pricing']
        self.contact = self.product['contact_info']
        self.delivery = self.data['delivery_network']
        self.warranty = self.data['warranty_terms']
        self.tech_service = self.data['technical_service']
        self.lcc = self.data['lcc_analysis']
    
    # ==================== 产品参数相关 ====================
    
    def get_all_parameters(self) -> str:
        """获取完整产品参数"""
        params = self.product['technical_parameters']
        durability = self.product['durability']
        water_purif = self.product['water_purification']
        
        result = "📋 洁水神硅砂模块完整技术参数\n"
        result += "=" * 50 + "\n\n"
        
        result += "【产品规格】\n"
        spec = self.product['standard_spec']
        result += f"• 尺寸：{spec['dimensions']}\n"
        result += f"• 单块体积：{spec['single_volume']}\n"
        result += f"• 用量（传统搭接）：{spec['pieces_per_cubic']}\n"
        result += f"• 用量（标准水池配置）：{spec['pieces_per_pool_cubic']}\n"
        result += f"• 结构：{spec['structure']}\n"
        result += f"• 规格覆盖：{spec['spec_coverage']}\n\n"
        
        result += "【力学性能】\n"
        for key, val in params.items():
            if 'strength' in key or 'load' in key or 'deformation' in key or 'pullout' in key:
                result += f"• {val['description']}：{val['value']}（标准：{val['standard']}）\n"
        
        result += "\n【透水性能】\n"
        result += f"• 透水系数：{params['permeability_coefficient']['value']}（标准：{params['permeability_coefficient']['standard']}）\n"
        result += f"• 闭水试验渗透率：{params['water_tightness']['value']}（标准：{params['water_tightness']['standard']}）\n"
        
        result += "\n【耐久性能】\n"
        for key, val in durability.items():
            if key == 'frost_resistance':
                result += f"• {val['description']}：{val['cycles']}，强度损失{val['strength_loss']}\n"
            elif 'value' in val:
                result += f"• {val['description']}：{val['value']}（标准：{val.get('standard', '-')}）\n"
        
        result += "\n【水质净化性能】\n"
        for key, val in water_purif.items():
            result += f"• {val['description']}：{val['value']}（标准：{val['standard']}）\n"
        
        result += "\n【工程参数】\n"
        result += f"• 连接方式：{self.engineering['connection_method']}\n"
        result += f"• 养护期：{self.engineering['curing_period']}\n"
        result += f"• 容积利用率：{self.engineering['volume_utilization']}\n"
        result += f"• 72h闭水试验水位下降：{self.engineering['water_test_72h_settlement']}\n"
        
        return result
    
    def calculate_quantity(self, length: float, width: float, height: float, unit: str = "both") -> str:
        """
        计算所需模块数量和造价
        
        Args:
            length: 水池长度（米）
            width: 水池宽度（米）
            height: 水池高度（米）
            unit: 报价单位 - "cubic"（立方）、"piece"（块）、"both"（两者都）
            
        Returns:
            用量计算和报价结果
        """
        volume = length * width * height
        
        # 两种用量标准
        pieces_per_pool_cubic = 13.5  # 标准水池配置约13-14块/m³，取中间值13.5
        pieces_per_actual_cubic = 56  # 纯模块体积约56块/m³
        
        # 计算数量
        total_pieces_pool = int(volume * pieces_per_pool_cubic)
        total_pieces_actual = int(volume * pieces_per_actual_cubic)
        
        # 含损耗备货
        buffer_pieces = int(total_pieces_pool * 1.05)
        
        # 计算价格
        price_per_cubic = 224  # 元/m³
        total_price = volume * price_per_cubic
        
        result = f"🧮 硅砂模块用量与报价计算\n"
        result += "=" * 50 + "\n\n"
        result += f"【水池尺寸】\n"
        result += f"• 长：{length} m\n"
        result += f"• 宽：{width} m\n"
        result += f"• 高：{height} m\n"
        result += f"• 总容积：{volume:.2f} m³\n\n"
        
        result += f"【模块用量（标准水池配置）】\n"
        result += f"• 理论用量：{total_pieces_pool} 块\n"
        result += f"• 建议备货（含5%损耗）：{buffer_pieces} 块\n"
        result += f"• 用量标准：约 13-14 块/立方米\n\n"
        
        result += f"【纯模块体积换算】\n"
        result += f"• 按纯模块体积：约 {total_pieces_actual} 块\n"
        result += f"• 按纯模块体积：约 {pieces_per_actual_cubic} 块/立方米\n\n"
        
        result += f"【报价参考】\n"
        result += f"• 纯模块单价：{price_per_cubic}元/m³\n"
        result += f"• 含税含运：是\n"
        result += f"• 本项目模块总价：约 {total_price:.0f} 元\n\n"
        
        result += f"【备注】\n"
        result += "• 以上为纯模块价格，不含包裹布、连接件等辅材\n"
        result += "• 具体造价需根据设计配置确定\n"
        result += "• 异形水池建议增加损耗余量至8-10%\n"
        
        return result
    
    def get_price_query(self, volume: Optional[float] = None, pieces: Optional[int] = None) -> str:
        """
        价格查询
        
        Args:
            volume: 体积（立方米），可选
            pieces: 块数，可选
            
        Returns:
            价格信息
        """
        price_per_cubic = 224  # 元/m³
        spec = self.product['standard_spec']
        
        result = "💰 洁水神硅砂模块价格查询\n"
        result += "=" * 50 + "\n\n"
        
        result += "【价格信息】\n"
        result += f"• 纯模块采购价：{price_per_cubic} 元/m³\n"
        result += f"• 包含内容：13%增值税 + 运输费用\n"
        result += f"• 规格尺寸：{spec['dimensions']}\n\n"
        
        if volume is not None:
            total_price = volume * price_per_cubic
            pieces_count = int(volume * 13.5)  # 标准水池配置
            result += f"【按您输入的体积计算】\n"
            result += f"• 容积：{volume:.2f} m³\n"
            result += f"• 模块数量：约 {pieces_count} 块\n"
            result += f"• 模块总价：约 {total_price:.0f} 元\n\n"
        
        if pieces is not None:
            volume_calc = pieces / 13.5
            price_calc = volume_calc * price_per_cubic
            result += f"【按您输入的块数计算】\n"
            result += f"• 块数：{pieces} 块\n"
            result += f"• 折算容积：约 {volume_calc:.2f} m³\n"
            result += f"• 模块总价：约 {price_calc:.0f} 元\n\n"
        
        result += "【联系方式】\n"
        result += f"• 联系人：{self.contact['contact_person']}\n"
        result += f"• 联系电话：{self.contact['phone_1']} / {self.contact['phone_2']}\n\n"
        
        result += "【备注】\n"
        result += "• 纯模块价格不含包裹布、连接件等辅材\n"
        result += "• 辅材费用根据项目设计配置单独计算\n"
        result += "• 具体项目请致电详询，获取准确报价\n"
        
        return result
    
    def recommend_model(self, scenario: str, load_requirement: str = "普通") -> str:
        """
        根据应用场景推荐产品型号
        
        Args:
            scenario: 应用场景
            load_requirement: 荷载要求（普通/消防车/重载）
            
        Returns:
            选型推荐结果
        """
        series = self.product['product_series']
        
        result = "🎯 产品选型推荐\n"
        result += "=" * 40 + "\n\n"
        
        # 场景匹配
        scenario_lower = scenario.lower()
        
        if any(s in scenario_lower for s in ['渗透', '花园', '下凹']):
            recommended = series[0]  # JSS-Z 高渗透
        elif any(s in scenario_lower for s in ['收集', '储存', '回用', '通用']):
            recommended = series[1]  # JSS-G 通用型
        elif any(s in scenario_lower for s in ['调蓄', '防渗', '储存']):
            recommended = series[2]  # JSS-T 低渗透
        else:
            recommended = series[1]  # 默认推荐通用型
        
        result += f"【推荐型号】{recommended['model']} - {recommended['name']}\n\n"
        result += f"【适用场景】{recommended['application']}\n\n"
        result += f"【产品特点】{recommended['features']}\n\n"
        
        # 荷载说明
        result += "【荷载说明】\n"
        if '消防' in load_requirement or '30t' in load_requirement:
            result += "• 顶部可承受30t消防车荷载\n"
            result += "• 30t等效荷载下沉降仅3.8mm（≤5mm）\n"
        else:
            result += "• 硅砂模块抗压强度15.9MPa\n"
            result += "• 可满足绝大多数场地荷载要求\n"
        
        result += "\n【所有产品系列】\n"
        for s in series:
            result += f"• {s['model']} - {s['name']}：{s['application']}\n"
        
        return result
    
    # ==================== 安装指导 ====================
    
    def get_installation_guide(self) -> str:
        """获取安装指导"""
        guide = self.installation
        
        result = "🔧 硅砂模块安装施工指南\n"
        result += "=" * 50 + "\n\n"
        
        result += "【前期准备】\n"
        for i, item in enumerate(guide['preparation'], 1):
            result += f"{i}. {item}\n"
        
        result += "\n【安装步骤】\n"
        for step in guide['installation_steps']:
            result += f"{step}\n"
        
        result += "\n【关键控制点】\n"
        for point in guide['key_control_points']:
            result += f"• {point}\n"
        
        result += "\n【验收标准】\n"
        for standard in guide['acceptance_criteria']:
            result += f"• {standard}\n"
        
        return result
    
    # ==================== 对比分析 ====================
    
    def compare_with(self, compare_type: str = "all") -> str:
        """
        与其他方案对比
        
        Args:
            compare_type: "spliced"（传统搭接式）、"pp"（PP模块）、"concrete"（混凝土水池）、"all"（全部）
        """
        result = "⚖️ 方案对比分析\n"
        result += "=" * 50 + "\n\n"
        
        if compare_type in ["spliced", "all"]:
            # 12项检测项目对比
            vs_spliced = self.comparison['vs_traditional_spliced']
            result += f"【{vs_spliced['title']}】\n\n"
            result += f"{'检测项目':<15} {'硅砂模块':<20} {'传统搭接式':<20} {'优势方':<10}\n"
            result += "-" * 70 + "\n"
            
            for item in vs_spliced['items']:
                result += f"{item['project']:<15} {item['silicon_sand']:<20} {item['traditional']:<20} {item['advantage']:<10}\n"
            
            result += "\n【总结】\n"
            result += vs_spliced['summary'] + "\n\n"
            
            if compare_type == "all":
                result += "-" * 50 + "\n\n"
        
        if compare_type in ["pp", "all"]:
            comp = self.comparison['vs_pp_module']
            result += "【硅砂模块 vs PP塑料模块】\n\n"
            
            result += "✅ 硅砂模块优势：\n"
            for adv in comp['advantage']:
                result += f"• {adv}\n"
            
            result += "\n⚠️ 注意事项：\n"
            for dis in comp['disadvantage']:
                result += f"• {dis}\n"
            
            result += f"\n💡 成本分析：{comp['cost_analysis']}\n\n"
            
            if compare_type == "all":
                result += "-" * 50 + "\n\n"
        
        if compare_type in ["concrete", "all"]:
            comp = self.comparison['vs_concrete_pool']
            result += "【硅砂模块 vs 传统混凝土水池】\n\n"
            
            result += "✅ 硅砂模块优势：\n"
            for adv in comp['advantage']:
                result += f"• {adv}\n"
            
            result += "\n⚠️ 注意事项：\n"
            for dis in comp['disadvantage']:
                result += f"• {dis}\n"
            
            result += f"\n💡 成本分析：{comp['cost_analysis']}\n"
        
        return result
    
    # ==================== LCC全生命周期成本分析 ====================
    
    def get_lcc_analysis(self, volume: float, compare_types: List[str] = None) -> str:
        """
        全生命周期成本分析
        
        Args:
            volume: 水池容积（立方米）
            compare_types: 要对比的方案类型列表
            
        Returns:
            LCC分析结果
        """
        if compare_types is None:
            compare_types = ["silicon_sand", "pp_module", "concrete"]
        
        price_per_cubic = 224  # 硅砂模块价格
        silicon_sand_initial = volume * price_per_cubic
        
        result = "📊 全生命周期成本（LCC）分析\n"
        result += "=" * 60 + "\n"
        result += f"分析周期：50年 | 容积：{volume:.0f} m³\n\n"
        
        # 硅砂模块分析
        result += "【硅砂模块方案】\n"
        result += f"• 初始投资：约 {silicon_sand_initial:.0f} 元\n"
        result += f"• 施工成本：约 {silicon_sand_initial * 0.3:.0f} 元（约为模块费的30%）\n"
        result += f"• 50年维护成本：约 {silicon_sand_initial * 0.05:.0f} 元（每5年例行检查）\n"
        result += f"• 大修/更换成本：0 元（50年内无需大修）\n"
        result += f"• 拆除处置成本：约 {silicon_sand_initial * 0.1:.0f} 元\n"
        result += f"• 50年LCC总成本：约 {silicon_sand_initial * 1.45:.0f} 元\n\n"
        
        # PP模块分析
        if "pp_module" in compare_types:
            pp_initial = silicon_sand_initial * 0.8  # PP初始投资约为硅砂的80%
            result += "【PP塑料模块方案】\n"
            result += f"• 初始投资：约 {pp_initial:.0f} 元\n"
            result += f"• 施工成本：约 {pp_initial * 0.4:.0f} 元（施工周期长）\n"
            result += f"• 50年维护成本：约 {pp_initial * 0.3:.0f} 元（需定期清理）\n"
            result += f"• 大修/更换成本：约 {pp_initial * 1.5:.0f} 元（第15年、30年需更换）\n"
            result += f"• 拆除处置成本：约 {pp_initial * 0.15:.0f} 元\n"
            result += f"• 50年LCC总成本：约 {pp_initial * 3.2:.0f} 元\n\n"
        
        # 混凝土水池分析
        if "concrete" in compare_types:
            concrete_initial = silicon_sand_initial * 0.75  # 混凝土初始投资约为硅砂的75%
            result += "【混凝土水池方案】\n"
            result += f"• 初始投资：约 {concrete_initial:.0f} 元\n"
            result += f"• 施工成本：约 {concrete_initial * 0.6:.0f} 元（人工成本高）\n"
            result += f"• 50年维护成本：约 {concrete_initial * 0.4:.0f} 元（定期防水维修）\n"
            result += f"• 大修/更换成本：约 {concrete_initial * 0.5:.0f} 元（需做防水翻新）\n"
            result += f"• 拆除处置成本：约 {concrete_initial * 0.3:.0f} 元（拆除难度大）\n"
            result += f"• 50年LCC总成本：约 {concrete_initial * 2.55:.0f} 元\n\n"
        
        # 总结对比
        result += "=" * 60 + "\n"
        result += "【50年LCC总成本对比】\n\n"
        result += f"• 硅砂模块：约 {silicon_sand_initial * 1.45:.0f} 元（基准）\n"
        
        if "pp_module" in compare_types:
            pp_total = silicon_sand_initial * 3.2
            saving = pp_total - silicon_sand_initial * 1.45
            result += f"• PP模块：约 {pp_total:.0f} 元（+{((pp_total/(silicon_sand_initial * 1.45))-1)*100:.0f}%）\n"
            result += f"  → 相比硅砂模块，50年多花费约 {saving:.0f} 元\n"
        
        if "concrete" in compare_types:
            concrete_total = silicon_sand_initial * 2.55
            saving = concrete_total - silicon_sand_initial * 1.45
            result += f"• 混凝土：约 {concrete_total:.0f} 元（+{((concrete_total/(silicon_sand_initial * 1.45))-1)*100:.0f}%）\n"
            result += f"  → 相比硅砂模块，50年多花费约 {saving:.0f} 元\n"
        
        result += "\n【结论】\n"
        result += "虽然硅砂模块初始投资略高，但50年全生命周期成本最低：\n"
        result += "• 比PP模块节省约40-55%\n"
        result += "• 比混凝土水池节省约25-35%\n"
        result += "• 投资回报周期：约8-12年\n"
        
        return result
    
    # ==================== 发货网点查询 ====================
    
    def get_delivery_network(self, province: str = None, city: str = None) -> str:
        """
        发货网点查询
        
        Args:
            province: 省份（可选）
            city: 城市（可选）
            
        Returns:
            发货网点信息
        """
        hubs = self.delivery['hubs']
        
        result = "🚚 全国发货网点查询\n"
        result += "=" * 50 + "\n\n"
        result += f"全国共 {len(hubs)} 大发货网点，就近配送降低运费\n\n"
        
        if province or city:
            # 按省份/城市筛选
            keyword = (province or city or "").lower()
            matched = []
            for hub in hubs:
                if keyword in hub['province'].lower() or keyword in hub['city'].lower():
                    matched.append(hub)
            
            if matched:
                result += f"【{keyword} 附近网点】\n\n"
                for hub in matched:
                    result += f"📍 {hub['name']}\n"
                    result += f"   位置：{hub['province']} {hub['city']}\n"
                    result += f"   配送范围：{', '.join(hub['coverage'])}\n"
                    result += f"   备注：{hub['note']}\n\n"
            else:
                result += f"未找到 {keyword} 附近的网点，以下是所有网点：\n\n"
                for hub in hubs:
                    result += f"📍 {hub['name']} - {hub['province']} {hub['city']}\n"
        else:
            # 返回全部网点
            for i, hub in enumerate(hubs, 1):
                result += f"{i}. {hub['name']}\n"
                result += f"   📍 {hub['province']} {hub['city']}\n"
                result += f"   🚛 配送范围：{', '.join(hub['coverage'])}\n"
                result += f"   💡 {hub['note']}\n\n"
        
        result += "【物流说明】\n"
        result += "• 发货网点250公里以内含运\n"
        result += "• 具体运费根据项目地点和数量计算\n"
        result += "• 大型项目可申请专车配送\n"
        result += "• 偏远地区可能需要中转，时间略有延长\n"
        
        return result
    
    # ==================== 质保服务查询 ====================
    
    def get_warranty_terms(self, warranty_type: str = None) -> str:
        """
        质保条款查询
        
        Args:
            warranty_type: 质保类型（可选）- "免费质保期"/"故障响应"/"技术支持"/"配件"
            
        Returns:
            质保条款信息
        """
        result = "🛡️ 质保条款与服务承诺\n"
        result += "=" * 50 + "\n\n"
        
        result += f"【质保期限】{self.warranty['warranty_period']}\n"
        result += f"【设计使用寿命】{self.warranty['service_life']}\n\n"
        
        # 质保条款
        result += "【质保条款】\n"
        for term in self.warranty['main_terms']:
            if warranty_type is None or warranty_type.lower() in term['item'].lower():
                result += f"• {term['item']}：{term['content']}\n"
                result += f"  说明：{term['description']}\n"
        
        result += "\n【免责条款】\n"
        for exclusion in self.warranty['warranty_exclusions']:
            result += f"❌ {exclusion}\n"
        result += f"\n💡 {self.warranty['exclusion_note']}\n"
        
        result += "\n【申请质保流程】\n"
        result += "1. 联系蔡经理 18068729619 / 15252026979，描述问题情况\n"
        result += "2. 提供项目合同和验收资料\n"
        result += "3. 2-24小时内给出技术处理方案\n"
        result += "4. 需现场服务时，全国就近网点快速响应\n"
        
        return result
    
    # ==================== 联系方式查询 ====================
    
    def get_contact_info(self) -> str:
        """获取联系方式"""
        result = "📞 联系方式\n"
        result += "=" * 50 + "\n\n"
        
        result += "【销售联系人】\n"
        result += f"• 联系人：{self.contact['contact_person']}\n"
        result += f"• 电话1：{self.contact['phone_1']}\n"
        result += f"• 电话2：{self.contact['phone_2']}\n\n"
        
        result += "【服务时间】\n"
        result += "• 工作日：8:30-17:30\n"
        result += "• 技术支持：7×24小时\n\n"
        
        result += "【温馨提示】\n"
        result += "• 询价请提供：项目地点、水池尺寸、应用场景\n"
        result += "• 技术咨询请说明：项目类型、遇到的问题\n"
        
        return result
    
    # ==================== 技术响应服务查询 ====================
    
    def get_technical_service(self) -> str:
        """获取技术响应服务信息"""
        response = self.tech_service['response_time']
        response_detail = self.tech_service['response_time_detail']
        
        result = "🔧 技术支持与服务\n"
        result += "=" * 50 + "\n\n"
        
        result += "【响应时效】\n"
        result += f"• 报价响应：{response['quote_response']}\n"
        result += f"• 深化图纸：{response['deep_drawing']}\n"
        result += f"• 工程技术问题处理：{response['engineering_issue']}\n\n"
        
        result += "【服务内容】\n"
        for content in self.tech_service['service_content']:
            result += f"✅ {content}\n"
        
        result += "\n【联系方式】\n"
        result += f"• 联系人：{self.contact['contact_person']}\n"
        result += f"• 电话：{self.contact['phone_1']} / {self.contact['phone_2']}\n"
        
        return result
    
    # ==================== FAQ ====================
    
    def get_faq(self, question_keyword: Optional[str] = None) -> str:
        """
        获取常见问题解答
        
        Args:
            question_keyword: 问题关键词（可选），None表示返回全部
        """
        result = "❓ 常见问题解答\n"
        result += "=" * 40 + "\n\n"
        
        if question_keyword:
            # 关键词匹配
            matched = []
            for item in self.faq:
                if question_keyword in item['question'].lower() or question_keyword in item['answer']:
                    matched.append(item)
            
            if matched:
                for item in matched:
                    result += f"Q: {item['question']}\n"
                    result += f"A: {item['answer']}\n\n"
            else:
                result += "未找到匹配的问题，以下是所有常见问题：\n\n"
                for item in self.faq:
                    result += f"Q: {item['question']}\n"
                    result += f"A: {item['answer']}\n\n"
        else:
            for item in self.faq:
                result += f"Q: {item['question']}\n"
                result += f"A: {item['answer']}\n\n"
        
        return result
    
    # ==================== 应用场景 ====================
    
    def get_application_scenarios(self) -> str:
        """获取应用场景列表"""
        scenarios = self.engineering['application_scenarios']
        standards = self.engineering['standards']
        
        result = "🏢 应用场景与执行标准\n"
        result += "=" * 40 + "\n\n"
        
        result += "【典型应用场景】\n"
        for i, s in enumerate(scenarios, 1):
            result += f"{i}. {s}\n"
        
        result += "\n【执行标准】\n"
        for std in standards:
            result += f"• {std}\n"
        
        return result
    
    # ==================== 资质认证 ====================
    
    def get_certifications(self) -> str:
        """获取资质认证信息"""
        certs = self.data['certifications']
        
        result = "🏆 资质认证\n"
        result += "=" * 40 + "\n\n"
        
        for cert in certs:
            result += f"【{cert['name']}】\n"
            result += f"• 检测机构：{cert['agency']}\n"
            result += f"• 报告编号：{cert['report_no']}\n"
            result += f"• 签发日期：{cert['date']}\n\n"
        
        return result
    
    # ==================== 自然语言意图识别与路由 ====================
    
    def handle_query(self, query: str) -> str:
        """
        处理用户自然语言查询
        
        Args:
            query: 用户查询文本
            
        Returns:
            回答文本
        """
        query_lower = query.lower()
        
        # ===== 价格查询 =====
        if any(k in query_lower for k in self.pricing['price_keywords']):
            numbers = re.findall(r'\d+\.?\d*', query)
            if numbers:
                volume = float(numbers[0])
                if '块' in query:
                    pieces = int(volume)
                    return self.get_price_query(pieces=pieces)
                else:
                    return self.get_price_query(volume=volume)
            else:
                return self.get_price_query()
        
        # ===== 联系方式查询 =====
        if any(k in query_lower for k in self.contact['contact_keywords']):
            return self.get_contact_info()
        
        # ===== 发货网点查询 =====
        if any(k in query_lower for k in self.delivery['query_keywords']):
            # 提取省份/城市
            provinces = ['江苏', '安徽', '山东', '河南', '河北', '北京', '天津', '湖北', '湖南', '四川', '重庆', '陕西', '山西', '浙江', '江西']
            cities = ['徐州', '南京', '郑州', '武汉', '成都', '西安', '北京', '济南', '上海', '杭州', '长沙', '重庆', '太原', '合肥']
            
            found_location = None
            for p in provinces + cities:
                if p in query:
                    found_location = p
                    break
            
            if found_location:
                return self.get_delivery_network(province=found_location, city=found_location)
            else:
                return self.get_delivery_network()
        
        # ===== 质保服务查询 =====
        if any(k in query_lower for k in self.warranty['query_keywords']):
            warranty_type = None
            if '整体' in query or '50' in query:
                warranty_type = '整体'
            elif '结构' in query:
                warranty_type = '结构'
            elif '防渗' in query or '密封' in query:
                warranty_type = '防渗'
            elif '净化' in query or '水质' in query:
                warranty_type = '净化'
            elif '配件' in query or '管件' in query:
                warranty_type = '配件'
            
            return self.get_warranty_terms(warranty_type=warranty_type)
        
        # ===== 技术响应查询 =====
        if any(k in query_lower for k in self.tech_service['query_keywords']):
            return self.get_technical_service()
        
        # ===== LCC分析查询 =====
        if any(k in query_lower for k in ['lcc', '生命周期', '全周期', '50年', '总成本', '长期成本', '划算', '值得']):
            numbers = re.findall(r'\d+\.?\d*', query)
            if numbers:
                volume = float(numbers[0])
                compare_types = []
                if 'pp' in query_lower or '塑料' in query_lower:
                    compare_types = ["silicon_sand", "pp_module"]
                elif '混凝土' in query_lower or '水泥' in query_lower:
                    compare_types = ["silicon_sand", "concrete"]
                else:
                    compare_types = ["silicon_sand", "pp_module", "concrete"]
                return self.get_lcc_analysis(volume, compare_types)
            else:
                return self.get_lcc_analysis(100)  # 默认100立方
        
        # ===== 12项检测对比 =====
        if any(k in query_lower for k in ['12项', '检测项目', '指标对比', '性能对比']) or '对比' in query_lower and '传统' in query_lower:
            return self.compare_with("spliced")
        
        # ===== 参数查询 =====
        if any(k in query_lower for k in ['参数', '强度', '抗压', '透水', '检测', '性能', '指标', '规格']):
            return self.get_all_parameters()
        
        # ===== 用量计算 =====
        elif any(k in query_lower for k in ['多少块', '用量', '数量', '计算', '需要多少', '几方', '几立方']):
            numbers = re.findall(r'\d+\.?\d*', query)
            if len(numbers) >= 3:
                return self.calculate_quantity(float(numbers[0]), float(numbers[1]), float(numbers[2]))
            else:
                return "请提供水池的长、宽、高（米），例如：'10米长、5米宽、2米高需要多少块？'\n或者直接说'100立方多少钱'查询报价。"
        
        # ===== 选型推荐 =====
        elif any(k in query_lower for k in ['选什么', '推荐', '型号', '用什么', '哪个好', '选型']):
            return self.recommend_model(query)
        
        # ===== 安装指导 =====
        elif any(k in query_lower for k in ['安装', '施工', '怎么装', '步骤', '流程', '验收']):
            return self.get_installation_guide()
        
        # ===== 对比分析 =====
        elif any(k in query_lower for k in ['对比', '比较', '区别', 'vs']):
            if 'pp' in query_lower or '塑料' in query_lower:
                return self.compare_with("pp")
            elif '混凝土' in query_lower or '水泥' in query_lower:
                return self.compare_with("concrete")
            elif '传统' in query_lower or '搭接' in query_lower:
                return self.compare_with("spliced")
            else:
                return self.compare_with("all")
        
        # ===== FAQ =====
        elif any(k in query_lower for k in ['寿命', '使用年限', '多久', '水质', '问题', 'faq']):
            return self.get_faq(query_lower)
        
        # ===== 应用场景 =====
        elif any(k in query_lower for k in ['用在哪', '应用', '场景', '能用在', '适合']):
            return self.get_application_scenarios()
        
        # ===== 资质认证 =====
        elif any(k in query_lower for k in ['资质', '认证', '检测报告', '证书', '合格']):
            return self.get_certifications()
        
        # ===== 默认返回产品介绍 =====
        else:
            intro = "🏗️ 洁水神硅砂模块产品顾问 v2.0\n"
            intro += "=" * 50 + "\n\n"
            intro += "您好！我是洁水神硅砂模块产品顾问，可以为您提供以下服务：\n\n"
            intro += "【产品咨询】\n"
            intro += "• 产品参数/检测报告查询\n"
            intro += "• 用量计算（如：10×5×2需要多少块？）\n"
            intro += "• 选型推荐（如：雨水花园用什么型号？）\n\n"
            intro += "【价格与报价】\n"
            intro += "• 价格查询（多少钱一立方/多少钱一块）\n"
            intro += "• 报价计算（如：100立方多少钱？）\n"
            intro += "• LCC全生命周期成本分析\n\n"
            intro += "【服务支持】\n"
            intro += "• 安装施工指导\n"
            intro += "• 质保条款查询\n"
            intro += "• 发货网点查询\n"
            intro += "• 技术响应时效\n"
            intro += "• 联系方式\n\n"
            intro += "【方案对比】\n"
            intro += "• 与传统搭接式模块12项指标对比\n"
            intro += "• 与PP模块对比\n"
            intro += "• 与混凝土水池对比\n\n"
            intro += "💬 请直接用自然语言描述您的问题，例如：\n"
            intro += "   '100立方多少钱？'\n"
            intro += "   '发到山东从哪里发货？'\n"
            intro += "   '质保期多久？'\n"
            intro += "   '和PP模块对比有什么优势？'\n"
            
            return intro


def main():
    """命令行交互测试"""
    skill = JieshuishenSkill()
    
    print("=" * 60)
    print("洁水神硅砂模块产品顾问 AI Skill v2.0.0")
    print("=" * 60)
    print()
    
    while True:
        query = input("请输入您的问题（输入'退出'结束）：\n> ")
        if query.lower() in ['退出', 'quit', 'exit', 'q']:
            print("感谢使用！")
            break
        
        print()
        result = skill.handle_query(query)
        print(result)
        print()


if __name__ == "__main__":
    main()
