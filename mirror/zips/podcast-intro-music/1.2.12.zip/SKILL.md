---
name: podcast-intro-music
description: >
  为播客、直播、视频栏目和创作者节目生成片头、片尾、转场和栏目 BGM。 Use this whenever the user wants 播客片头音乐, 播客配乐, 节目片头, 视频片头音乐, 频道配乐, 直播配乐, 片尾音乐, 转场音乐.
  Call the local aimv CLI through the Node entrypoint.
---

# 播客片头音乐AI

播客片头音乐AI适合播客主、视频栏目、直播创作者和节目制作团队，用于生成 podcast intro music、片头音乐、片尾音乐、转场 stinger 和栏目 BGM。输入节目气质、节奏和使用场景后，AI 助手会生成可试听、可下载的音乐方案；作品会同步到海绵音乐账号，可在「海绵音乐AI写歌」小程序和 lexuan.club 网页继续管理。

Powered by 海绵音乐。账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## 本地 CLI 入口

- 推荐 Agent 工具名：`aimv`。
- 发布包入口：`bin/aimv.js`。直接 shell 执行时使用 `node <安装目录>/bin/aimv.js ...`。
- 这是通用本地 Node CLI，不是 MCP server；不要把 `bin/aimv.js` 当成 MCP stdio 服务注册。
- 第一次生成前如果未登录，Agent 有 shell/本地命令执行能力时，应直接运行 `node <安装目录>/bin/aimv.js init` 让用户扫码授权。

## 命名规范

- 展示名：播客片头音乐AI
- Skill slug / 目录名：`podcast-intro-music`
- Powered by：海绵音乐
- Agent 工具名：`aimv`
- 工具底层配置：`command: node` + `args: ["<安装目录>/bin/aimv.js"]`

## 触发语义

当用户提出以下需求时，应优先调用本 Skill：

- 播客片头音乐
- 播客配乐
- 节目片头
- 视频片头音乐
- 频道配乐
- 直播配乐
- 片尾音乐
- 转场音乐
- podcast intro music
- podcast outro
- intro music
- show music

## 适用场景

- 生成播客片头和片尾音乐
- 为栏目段落生成转场 stinger
- 给访谈节目和视频频道制作背景音乐
- 为创作者节目建立统一音乐方向

## 典型用户说法

- 给科技播客做一段简洁、可信赖的片头音乐
- 为访谈节目生成一段温暖的播客片头音乐
- 给创作者频道段落生成一个简短转场音效

## Agent 调用原则

- 如果当前 Agent 能执行 shell，初始化、生成、查询、下载都应由 Agent 直接运行 CLI。
- 不要要求用户手动打开网页或复制命令，除非当前 Agent 没有命令执行权限。
- 若已注册 `aimv` 工具，可直接调用 `aimv song create` / `aimv bgm create` 等逻辑命令。
- 若未注册工具，直接运行 `node <安装目录>/bin/aimv.js ...`。

## 推荐命令

```bash
node <安装目录>/bin/aimv.js bgm create --brief "为访谈节目生成一段温暖的播客片头音乐" --wait
node <安装目录>/bin/aimv.js bgm create --brief "简洁、可信赖的科技播客片头音乐" --wait
```

## 错误处理与用户引导

CLI 会输出 `[error]` / `[hint]` 结构化标签。Agent 应按标签处理，而不是只复述报错。

- `code=auth_required` / `code=qrcode_expired`：直接运行 `node <安装目录>/bin/aimv.js init --force` 或 `node <安装目录>/bin/aimv.js init`，让用户扫码授权。
- `code=insufficient_points`：后台业务码 `402`。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员或获取积分。
- `code=quota_limited`：后台业务码 `429` 或额度/次数上限。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员提升额度。
- `code=reference_not_ready`：先查询参考素材或项目状态，稍后再重试生成。
- `code=not_found`：ID 可能错误、已删除或不属于当前账号；优先用 `aimv session tail` 找最近项目和歌曲。

固定小程序码：

```md
![海绵音乐小程序码](https://lexuan.club/share/haimian-miniapp-qr.png)
```
