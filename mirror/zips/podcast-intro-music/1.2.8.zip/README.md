# 播客片头音乐AI

为播客、直播、视频栏目和创作者节目生成片头、片尾、转场和栏目 BGM。

播客片头音乐AI面向播客主、视频栏目和直播创作者，生成片头音乐、片尾音乐、转场 stinger 和节目背景音乐。能力由海绵音乐提供，账号、积分、会员和作品库与海绵音乐小程序及 lexuan.club 互通。

Powered by 海绵音乐。账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## Package Identity

- Skill slug: `podcast-intro-music`
- Package name: `podcast-intro-music`
- Agent tool name: `aimv`
- Node entrypoint: `bin/aimv.js`
- Runtime bundle: `dist/aimv.cjs`

## Keywords

- 播客片头音乐
- 播客配乐
- 节目片头
- 视频片头音乐
- 频道配乐
- 直播配乐
- 片尾音乐
- 转场音乐
- podcast intro music
- podcast outro
- intro music
- show music

## Use Cases

- 生成播客片头和片尾音乐
- 为栏目段落生成转场 stinger
- 给访谈节目和视频频道制作背景音乐
- 为创作者节目建立统一音乐方向

## Examples

- 给科技播客做一段简洁、可信赖的片头音乐
- 为访谈节目生成一段温暖的播客片头音乐
- 给创作者频道段落生成一个简短转场音效

## Run

```bash
node ./bin/aimv.js init
node ./bin/aimv.js bgm create --brief "为访谈节目生成一段温暖的播客片头音乐" --wait
node ./bin/aimv.js bgm create --brief "简洁、可信赖的科技播客片头音乐" --wait
```

The package does not include an opaque native binary or an extensionless Unix executable. It runs through Node.js >=18.
