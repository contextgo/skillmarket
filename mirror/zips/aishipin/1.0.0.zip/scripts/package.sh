#!/bin/bash
# AI视频创作师 - 技能打包脚本

echo "打包 AI视频创作师 技能..."

# 创建临时目录
mkdir -p /tmp/AI视频创作师

# 复制文件
cp -r AI视频创作师/* /tmp/AI视频创作师/

# 打包
cd /tmp
zip -r AI视频创作师_v1.0.0.zip AI视频创作师

# 移动到工作目录
mv AI视频创作师_v1.0.0.zip $OLDPWD/

echo "打包完成：AI视频创作师_v1.0.0.zip"
