---
name: esg-factor-engine
description: ESG因子引擎 — 多Agent协作A股ESG投资分析系统。当用户说"分析ESG"、"ESG评分"、"ESG风险"、"做ESG分析"、"ESG报告"、"生成ESG叙事"、"投资组合ESG诊断"、或需要完成完整的ESG投资研究流程时激活。提供9个专业Agent协作（IC/CV/IA/SI/RSM/ES/HIA等），支持可信度分级、漂绿检测、人机协作签字、尽责管理建议。
---

# ESG因子引擎 Skill

基于RealGreen AI九Agent架构的多智能体ESG投资分析系统。

## 文件结构

```
scripts/
├── full_workflow_v2.py       # 完整工作流演示（9个Agent协作）
├── ic_orchestrator.py        # IC首席分析师（任务编排）
├── cv_credibility_validator.py   # CV可信度验证（A/B/C/D四级+CIQI）
├── ia_intelligence_aggregator.py # IA情报聚合（采集+去重+冲突仲裁）
├── si_strategic_interpreter.py   # SI战略解读（Materiality矩阵+政策周期）
├── rsm_risk_signal_monitor.py    # RSM风险监测（负面事件+漂绿+舆情）
├── es_engagement_steward.py      # ES尽责管理（行动计划+投票建议）
├── hia_human_intelligence_advisor.py  # HIA人类分析师（8个强制签字节点）
├── esg_scorer.py            # ESG评分（行业权重配置+政策导向因子）
├── portfolio_analyst.py     # 投资组合诊断
└── factor_quant.py          # 因子归因

references/
└── ESG_FACTOR_ENGINE_v2.md  # 完整系统规格说明书
```

## 核心工作流

当用户请求完整ESG分析时，使用 `scripts/full_workflow_v2.py` 作为入口脚本：

```bash
python3 scripts/full_workflow_v2.py
```

该脚本串联全部9个Agent，模拟7步流水线 + 8个人类签字节点。

## Agent快速参考

| Agent | 文件 | 关键函数 |
|-------|------|---------|
| IC | ic_orchestrator.py | `ICOrchestrator().receive_task()` / `.finalize()` |
| CV | cv_credibility_validator.py | `assess_data_credibility(source, cross_validated, completeness, recency_days)` |
| IA | ia_intelligence_aggregator.py | `IAIntelligenceAggregator().ingest()` / `.fuse()` |
| SI | si_strategic_interpreter.py | `interpret_esg_materiality(code, name, industry, e, s, g, policies)` |
| RSM | rsm_risk_signal_monitor.py | `monitor_risk_signals(code, name, esg_score, news_items)` |
| ES | es_engagement_steward.py | `generate_engagement_plan(code, name, risk_signals, esg_scores)` |
| HIA | hia_human_intelligence_advisor.py | `HumanAdvisor().sign(node, analyst, decision)` |

## 可信度分级标准（CV）

| 等级 | 说明 | 来源示例 |
|------|------|---------|
| A | 高可信，多方交叉验证 | 交易所年报、审计报告 |
| B | 较可信，权威单一来源 | Wind ESG、华证ESG |
| C | 需审慎，存在信息缺口 | 行业估算、媒体推断 |
| D | 仅参考，非官方来源 | 社交媒体 |

交叉验证可将B升A；综合输出CIQI指数（0-100）。

## 行业Materiality矩阵（SI）

使用 `si_strategic_interpreter.py` 中的 `MATERIALITY_MATRIX` 配置，支持30+行业E/S/G实质性议题，包括：
新能源、光伏、锂电、电力、半导体、白酒、煤炭、银行、保险等。

## 人机协作节点（HIA）

8个强制人类签字节点，定义于 `HumanAdvisor.CHECKPOINT_DESCRIPTIONS`：
1. 任务范围确认 | 2. 数据溯源确认 | 3. 争议数据复核
4. 风险定级确认 | 5. 趋势解读确认 | 6. 战略对齐审核
7. 投资建议签字 | 8. 合规最终审查

用 `HumanAdvisor().sign(node, analyst_name, decision)` 记录签字。

## 使用场景

**快速单股票分析：**
调用 `si_strategic_interpreter + cv_credibility_validator + rsm_risk_signal_monitor` 三个Agent，组合输出。

**完整持仓诊断：**
调用 `portfolio_analyst.py` 的 `diagnose_portfolio_esg()`，配合 HIA 8节点签字流程。

**ESG评分排名：**
使用 `esg_scorer.py` 的 `build_esg_score()`，配合行业权重配置。

所有输出仅供研究参考，不构成投资建议。