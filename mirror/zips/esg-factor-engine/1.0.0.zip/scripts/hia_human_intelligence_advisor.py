"""HIA (Human Intelligence Advisor) - 人类分析师顾问"""
from datetime import datetime

class HumanAdvisor:
    CHECKPOINT_DESCRIPTIONS = {
        1: "任务范围确认", 2: "数据溯源确认", 3: "争议数据复核",
        4: "风险定级确认", 5: "趋势解读确认", 6: "战略对齐审核",
        7: "投资建议签字", 8: "合规最终审查",
    }
    def __init__(self):
        self.checkpoints = {k: {"status":"pending","signed_by":"","notes":""}
                            for k in self.CHECKPOINT_DESCRIPTIONS}
    def sign(self, node, analyst, decision, notes=''):
        self.checkpoints[node] = {"status":"approved","signed_by":analyst,
                                   "decision":decision,"notes":notes,"signed_at":datetime.now().isoformat()}
        return {"node":node,"status":"approved","by":analyst}
    def override(self, node, analyst, decision, reason):
        self.checkpoints[node] = {"status":"overridden","signed_by":analyst,
                                   "decision":decision,"override_reason":reason,"signed_at":datetime.now().isoformat()}
        return {"node":node,"status":"overridden","by":analyst}
    def is_all_signed(self):
        return all(v["status"] in ["approved","overridden"] for v in self.checkpoints.values())
    def summary(self):
        a=sum(1 for v in self.checkpoints.values() if v["status"]=="approved")
        o=sum(1 for v in self.checkpoints.values() if v["status"]=="overridden")
        return {"total":8,"approved":a,"overridden":o,"pending":8-a-o}
