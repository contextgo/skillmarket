"""ES (Engagement Steward) — 尽责管理官
职责：股东对话建议、投票指引、ESG行动追踪、投后管理
"""
from datetime import datetime, timedelta


ENGAGEMENT_PRIORITIES = {
    "E": {
        "高": ["碳排放目标落后", "无减排计划", "环保处罚"],
        "中": ["能耗强度偏高", "水资源风险", "废弃物管理不足"],
    },
    "S": {
        "高": ["重大安全事故", "供应链劳工违规", "社区冲突"],
        "中": ["多元化不足", "员工满意度低", "产品安全问题"],
    },
    "G": {
        "高": ["高管贪腐", "关联交易异常", "信息披露违规"],
        "中": ["董事会独立性不足", "ESG治理架构缺失", "股权激励争议"],
    },
}


def generate_engagement_plan(stock_code, stock_name, risk_signals, esg_scores, holding_period="中长期"):
    """生成尽责管理行动计划"""
    plan = []

    # 基于风险信号生成行动项
    for sig in risk_signals.get("signals", [])[:3]:
        kw = sig.get("keyword", "")
        if any(k in kw for k in ["排放", "污染", "能耗", "环保"]):
            dim = "E"
        elif any(k in kw for k in ["安全", "劳工", "社区"]):
            dim = "S"
        else:
            dim = "G"
        plan.append({
            "dimension": dim,
            "topic": kw,
            "action": f"向公司发函询问{kw}事件详情及整改措施",
            "priority": "high",
            "timeline": "2周内",
            "type": "问询函",
        })

    # ESG薄弱维度行动
    for dim in ["E", "S", "G"]:
        score_key = {"E": "esg_e", "S": "esg_s", "G": "esg_g"}[dim]
        score = esg_scores.get(score_key, 60)
        if score < 60:
            issues = ENGAGEMENT_PRIORITIES[dim]["高"] if score < 50 else ENGAGEMENT_PRIORITIES[dim]["中"]
            plan.append({
                "dimension": dim,
                "topic": issues[0] if issues else "ESG表现待提升",
                "action": f"安排投资者交流会，询问{dim}维度的改善计划和时间表",
                "priority": "medium",
                "timeline": "季度内",
                "type": "投资者交流",
            })

    # 投票建议
    voting_guide = {
        "反对": ["高管薪酬方案超标", "关联交易未披露", "ESG报告标准降级"],
        "弃权": ["新业务扩张风险不明", "并购估值偏高"],
        "支持": ["股权激励方案合理", "ESG改善计划具体可量化"],
    }

    # 排序
    priority_order = {"high": 0, "medium": 1}
    plan.sort(key=lambda x: priority_order.get(x["priority"], 2))

    return {
        "stock_code": stock_code,
        "stock_name": stock_name,
        "engagement_timestamp": datetime.now().isoformat(),
        "action_plan": plan[:5],
        "voting_guide": voting_guide,
        "follow_up_date": (datetime.now() + timedelta(days=90)).strftime("%Y-%m-%d"),
        "holding_recommendation": "继续持有" if esg_scores.get("esg_total", 0) >= 60 else "关注调仓",
    }


def generate_engagement_narrative(engagement: dict) -> str:
    """生成尽责管理叙事"""
    lines = [
        f"## 🤝 尽责管理报告 — {engagement['stock_name']}（{engagement['stock_code']}）",
        f"**生成时间**: {engagement['engagement_timestamp']}",
        f"**后续跟进日期**: {engagement['follow_up_date']}",
        "",
        "### 行动方案",
        "",
    ]
    for a in engagement["action_plan"]:
        emoji = "🔴" if a["priority"] == "high" else "🟡"
        lines.append(f"{emoji} **[{a['priority'].upper()}] {a['type']}**")
        lines.append(f"   议题: {a['topic']}")
        lines.append(f"   行动: {a['action']}")
        lines.append(f"   时间: {a['timeline']}")
        lines.append("")

    lines.append("### 投票指引")
    for rec, items in engagement["voting_guide"].items():
        lines.append(f"**{rec}**: {', '.join(items)}")

    lines.append("")
    lines.append(f"**持仓建议**: {engagement['holding_recommendation']}")
    return "\n".join(lines)


if __name__ == "__main__":
    r = generate_engagement_plan(
        "300750", "宁德时代",
        risk_signals={"signals": [{"keyword": "碳排放", "content": "碳排放超标"}]},
        esg_scores={"esg_total": 75, "esg_e": 72, "esg_s": 78, "esg_g": 76},
    )
    print(f"尽责管理计划 - {r['stock_name']}")
    for a in r["action_plan"]:
        print(f"  [{a['priority'].upper()}] {a['type']}: {a['action']}")
