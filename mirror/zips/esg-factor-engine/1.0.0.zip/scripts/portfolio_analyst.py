# portfolio_analyst.py — 投资组合分析Agent
"""
投资组合分析师
职责：组合ESG评估、持仓诊断、同业基准对比、优化建议
"""

def diagnose_portfolio_esg(holdings, esg_scores, benchmark="沪深300"):
    score_map = {s["code"]: s for s in esg_scores}
    portfolio_esg_list, industry_weights, low_esg_stocks = [], {}, []
    total_weight = sum(h["weight"] for h in holdings)
    for h in holdings:
        score = score_map.get(h["code"], {})
        w = h["weight"] / total_weight
        esg = score.get("esg_final", 0)
        portfolio_esg_list.append(esg * w)
        ind = h.get("industry", "未知")
        industry_weights[ind] = industry_weights.get(ind, 0) + w
        if esg < 50:
            low_esg_stocks.append({**h, "esg": esg, "weight_pct": round(w*100, 2)})
    port_esg = round(sum(portfolio_esg_list), 2)
    grade = "AA" if port_esg>=80 else "A" if port_esg>=70 else "BBB" if port_esg>=60 else "BB" if port_esg>=50 else "B"
    return {
        "portfolio_esg": port_esg, "portfolio_grade": grade,
        "industry_weights": {k: round(v*100,1) for k,v in industry_weights.items()},
        "low_esg_holdings": sorted(low_esg_stocks, key=lambda x: x["esg"]),
        "total_holdings": len(holdings), "esg_below_50_count": len(low_esg_stocks),
        "esg_below_50_weight": round(sum(h["weight_pct"] for h in low_esg_stocks), 2),
    }

def compare_with_benchmark(portfolio_result, benchmark_esg=65.0, benchmark_e=62.0, benchmark_s=66.0, benchmark_g=67.0):
    return {"portfolio_ESG": portfolio_result["portfolio_esg"], "benchmark_ESG": benchmark_esg,
            "active_ESG": round(portfolio_result["portfolio_esg"]-benchmark_esg, 2),
            "active_E": round(portfolio_result.get("portfolio_e",0)-benchmark_e, 2)}

def generate_optimization_suggestions(portfolio_result):
    suggestions = []
    if portfolio_result.get("esg_below_50_count", 0) > 0:
        suggestions.append({"type":"replace","action":"减持低ESG持仓","reason":"ESG低于50分","priority":"high"})
    return suggestions
