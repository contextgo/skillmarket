"""IC (Investment Committee) — 首席分析师 / 任务编排器
职责：接收任务、分解工作流、协调8个人机节点、最终质量把控
参考：RealGreen AI九Agent架构 — https://www.realgreenai.com/invest-factor
"""
import json
from datetime import datetime

HUMAN_CHECKPOINT_COUNT = 8

WORKFLOW_STEPS = [
    {"step": 1, "id": "TASK_DECOMPOSE",    "name": "任务接收与分解",     "agents": "IC",      "human_node": 1},
    {"step": 2, "id": "DATA_COLLECT",      "name": "多源信息采集",       "agents": "IA+CV",   "human_node": 2},
    {"step": 3, "id": "CREDIBILITY_CHECK",  "name": "可信度分级验证",     "agents": "CV",      "human_node": 3},
    {"step": 4, "id": "NARRATIVE_BUILD",    "name": "ESG叙事生成",        "agents": "SI+TA+RSM","human_node": "4-6"},
    {"step": 5, "id": "PORTFOLIO_ANALYZE",  "name": "组合分析与归因",     "agents": "PI",      "human_node": 7},
    {"step": 6, "id": "ENGAGEMENT_PLAN",    "name": "尽责管理建议",       "agents": "ES",      "human_node": 8},
    {"step": 7, "id": "FINAL_REPORT",      "name": "汇总报告输出",        "agents": "IC",      "human_node": 8},
]

SIGNATURES_TEMPLATE = {
    f"node_{i}": {"status": "pending", "signed_by": "", "decision": "", "timestamp": ""}
    for i in range(1, HUMAN_CHECKPOINT_COUNT + 1)
}


class ICOrchestrator:
    def __init__(self, task_id: str = None):
        self.task_id = task_id or f"esg_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        self.status = "initialized"
        self.step = 0
        self.signatures = SIGNATURES_TEMPLATE.copy()
        self.workflow_log = []
        self.results = {}

    def receive_task(self, user_message: str, task_type: str) -> dict:
        self.status = "running"
        self.step = 1
        self.workflow_log.append({"step": 0, "event": "task_received", "task_type": task_type})
        return {
            "task_id": self.task_id,
            "user_request": user_message,
            "task_type": task_type,
            "received_at": datetime.now().isoformat(),
            "steps_total": len(WORKFLOW_STEPS),
            "human_checkpoints": HUMAN_CHECKPOINT_COUNT,
            "agent_roster": ["IC","CV","TA","SI","IA","RSM","ES","PI","HIA"],
        }

    def log_step(self, step_id: str, agent_id: str, output: dict):
        self.step += 1
        self.workflow_log.append({
            "step": self.step, "step_id": step_id, "agent": agent_id,
            "timestamp": datetime.now().isoformat(),
            "output_keys": list(output.keys())[:5],
        })
        self.results[step_id] = output

    def finalize(self, final_output: dict) -> dict:
        self.status = "completed"
        unsigned = [k for k, v in self.signatures.items() if v["status"] == "pending"]
        return {
            "task_id": self.task_id,
            "status": "completed",
            "all_human_signed": len(unsigned) == 0,
            "unsigned_nodes": unsigned,
            "workflow_steps": {s["id"]: s["agents"] for s in WORKFLOW_STEPS},
            "workflow_log_count": len(self.workflow_log),
            "final_output": final_output,
            "signatures": self.signatures,
            "completed_at": datetime.now().isoformat(),
        }

    def print_architecture(self):
        print(f"\n{'='*55}")
        print(f"  ESG因子引擎 v2.0 — 九Agent架构")
        print(f"{'='*55}")
        for s in WORKFLOW_STEPS:
            sig = self.signatures.get(f"node_{s['human_node']}", {})
            status = "已签字" if sig.get("status") == "approved" else "待签字"
            print(f"  STEP{s['step']} [{s['id']}] {s['name']}")
            print(f"         Agent: {s['agents']} | 人类节点#{s['human_node']}: {status}")
        print(f"{'='*55}")


if __name__ == "__main__":
    ic = ICOrchestrator("demo_001")
    manifest = ic.receive_task("分析宁德时代ESG投资价值", "full_analysis")
    print("任务已接收:")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    ic.print_architecture()
