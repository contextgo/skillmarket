"""IA (Intelligence Aggregator) — 情报聚合员
职责：多源ESG信息采集、去重、冲突仲裁、情报融合
"""
import json
from datetime import datetime
from collections import defaultdict


class IAIntelligenceAggregator:
    def __init__(self):
        self.raw_data = []
        self.deduped = []
        self.conflicts = []

    def ingest(self, source: str, data_type: str, content: str, timestamp: str = None, confidence: float = 0.8):
        self.raw_data.append({
            "source": source, "data_type": data_type, "content": content,
            "timestamp": timestamp or datetime.now().isoformat(),
            "raw_confidence": confidence, "status": "raw"
        })

    def deduplicate(self) -> list:
        seen = set()
        self.deduped = []
        for item in self.raw_data:
            key = (item["source"], item["data_type"], item["content"][:50])
            if key not in seen:
                seen.add(key)
                item["status"] = "deduped"
                self.deduped.append(item)
        return self.deduped

    def detect_conflicts(self) -> list:
        by_indicator = defaultdict(list)
        for item in self.deduped:
            by_indicator[item["data_type"]].append(item)
        self.conflicts = []
        for ind, items in by_indicator.items():
            if len(items) < 2:
                continue
            for i in range(len(items)):
                for j in range(i + 1, len(items)):
                    a, b = items[i], items[j]
                    if self._is_conflicting(a, b):
                        self.conflicts.append({
                            "data_type": ind,
                            "item_a": {"source": a["source"], "content": a["content"]},
                            "item_b": {"source": b["source"], "content": b["content"]},
                            "resolution": self._resolve_conflict(a, b),
                        })
        return self.conflicts

    def _is_conflicting(self, a, b) -> bool:
        try:
            v1 = float("".join(filter(lambda x: x in ".-0123456789", a["content"])))
            v2 = float("".join(filter(lambda x: x in ".-0123456789", b["content"])))
            if v1 == 0 or v2 == 0:
                return False
            return abs(v1 - v2) / max(abs(v1), abs(v2)) > 0.2
        except:
            return False

    def _resolve_conflict(self, a, b) -> str:
        priority = {
            "交易所文件": 4, "公司公告": 4, "审计报告": 4,
            "Wind ESG": 3, "华证ESG": 3, "中证ESG": 3,
            "财经媒体": 2, "行业报告": 2, "社交媒体": 1,
        }
        s1 = priority.get(a["source"], 1)
        s2 = priority.get(b["source"], 1)
        winner = a if s1 > s2 else b
        return f"采用优先级策略，选择【{winner['source']}】数据"

    def fuse(self) -> dict:
        self.deduplicate()
        self.detect_conflicts()
        return {
            "total_raw_items": len(self.raw_data),
            "after_dedup": len(self.deduped),
            "conflicts_resolved": len(self.conflicts),
            "fusion_timestamp": datetime.now().isoformat(),
            "deduped_items": self.deduped,
            "conflict_report": self.conflicts,
        }


if __name__ == "__main__":
    ia = IAIntelligenceAggregator()
    ia.ingest("公司年报", "碳排放", "2024年碳排放强度: 12.5 tCO2/百万元", confidence=0.95)
    ia.ingest("Wind ESG", "碳排放", "碳排放强度: 14.2 tCO2/百万元(估算)", confidence=0.7)
    ia.ingest("财经媒体", "碳排放", "据悉该公司碳排放呈下降趋势", confidence=0.5)
    result = ia.fuse()
    print("IA情报聚合报告:")
    print(f"  原始数据: {result['total_raw_items']}条")
    print(f"  去重后: {result['after_dedup']}条")
    print(f"  冲突: {result['conflicts_resolved']}条")
    for c in result["conflict_report"]:
        print(f"  冲突: {c['data_type']} -> {c['resolution']}")
