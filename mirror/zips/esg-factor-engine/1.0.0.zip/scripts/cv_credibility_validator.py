"""
CV (Credibility Validator) — 可信度验证员
职责：对ESG信息进行A/B/C/D四级可信度评级，基于REAL算法和EDCS评分卡
参考：RealGreen AI「可信度分级」设计
"""
import json
from datetime import datetime

# 可信度等级定义
CREDIBILITY_LEVELS = {
    "A": {
        "label": "🟢 A级 — 高可信",
        "description": "经多方交叉验证，可作为投资决策核心依据",
        "examples": ["交易所年报", "审计报告", "监管文件", "官方公告"],
        "weight": 1.0,
    },
    "B": {
        "label": "🔵 B级 — 较可信",
        "description": "单一权威来源，建议与其他数据交叉确认",
        "examples": ["Wind ESG", "华证ESG", "中证ESG", "公司公告"],
        "weight": 0.75,
    },
    "C": {
        "label": "🟡 C级 — 需审慎",
        "description": "存在信息缺口，需人工复核或补充证据",
        "examples": ["行业机构估算", "媒体推断", "企业自愿披露"],
        "weight": 0.40,
    },
    "D": {
        "label": "🔴 D级 — 低可信",
        "description": "仅供参考，不建议作为独立决策依据",
        "examples": ["社交媒体", "小道消息", "非官方爆料"],
        "weight": 0.10,
    },
}

# ESG数据源可信度配置
SOURCE_CREDIBILITY = {
    # 一级（官方/监管）
    "上交所公告": "A", "深交所公告": "A", "证监会文件": "A",
    "公司年报": "A", "审计报告": "A", "社会责任报告(官方)": "A",
    # 二级（权威第三方）
    "Wind ESG": "B", "华证ESG": "B", "中证ESG": "B", "商道融绿": "B",
    "MSCI ESG": "B", "Sustainalytics": "B", "Refinitiv ESG": "B",
    # 三级（行业/媒体）
    "行业协会报告": "C", "财经媒体": "C", "企业ESG报告(自愿)": "C",
    "券商研报": "C", "研究员估算": "C",
    # 四级（非官方）
    "社交媒体": "D", "论坛帖子": "D", "匿名信源": "D",
}

# CIQI综合信息质量指数权重
CIQI_WEIGHTS = {
    "source_credibility": 0.35,    # 来源可信度
    "cross_validation": 0.25,      # 交叉验证程度
    "data_completeness": 0.20,    # 数据完整度
    "temporal_relevance": 0.10,   # 时间相关性
    "methodology_transparency": 0.10,  # 方法论透明度
}


def assess_data_credibility(
    source: str,
    cross_validated: bool = False,
    completeness: float = 1.0,
    recency_days: int = 30,
    has_methodology: bool = False,
) -> dict:
    """
    评估单条ESG数据的可信度
    返回：CREDIBILITY_LEVEL + CIQI综合信息质量指数(0-100)
    """
    # 来源基础等级
    base_level = SOURCE_CREDIBILITY.get(source, "C")
    base_info = CREDIBILITY_LEVELS[base_level]

    # 交叉验证加成
    cross_bonus = 1.0 if cross_validated else 0.0

    # 数据完整度（0-1）
    completeness_score = completeness * 100

    # 时间衰减（30天内满分，超过则递减）
    recency_score = max(0, 100 - (recency_days / 365) * 30)

    # 方法论透明度
    method_score = 100 if has_methodology else 50

    # CIQI综合计算
    ciqi = (
        CREDIBILITY_LEVELS[base_level]["weight"] * 100 * CIQI_WEIGHTS["source_credibility"]
        + min(cross_bonus, 1.0) * 100 * CIQI_WEIGHTS["cross_validation"]
        + completeness_score * CIQI_WEIGHTS["data_completeness"]
        + recency_score * CIQI_WEIGHTS["temporal_relevance"]
        + method_score * CIQI_WEIGHTS["methodology_transparency"]
    )

    # 综合可信度等级（可因交叉验证上调，或因时间衰减下调）
    final_level = base_level
    if cross_validated and base_level == "B":
        final_level = "A"  # B级数据交叉验证后升为A级

    ciqi_final = round(ciqi, 1)

    return {
        "source": source,
        "base_level": base_level,
        "final_level": final_level,
        "ciqi": ciqi_final,
        "label": CREDIBILITY_LEVELS[final_level]["label"],
        "ciqi_breakdown": {
            "source_component": round(CREDIBILITY_LEVELS[base_level]["weight"] * 100 * CIQI_WEIGHTS["source_credibility"], 1),
            "cross_validation": round(cross_bonus * 100 * CIQI_WEIGHTS["cross_validation"], 1),
            "completeness": round(completeness_score * CIQI_WEIGHTS["data_completeness"], 1),
            "recency": round(recency_score * CIQI_WEIGHTS["temporal_relevance"], 1),
            "methodology": round(method_score * CIQI_WEIGHTS["methodology_transparency"], 1),
        },
        "cross_validated": cross_validated,
        "completeness": completeness,
        "recency_days": recency_days,
        "recommendation": _get_recommendation(final_level, ciqi_final),
    }


def _get_recommendation(level: str, ciqi: float) -> str:
    if level == "A" and ciqi >= 80: return "可直接作为核心依据"
    if level == "A": return "可作为主要依据，建议定期复核"
    if level == "B": return "可作为参考，需交叉验证"
    if level == "C": return "审慎使用，建议补充证据"
    return "仅供背景参考，不建议作为决策依据"


def batch_assess(items: list[dict]) -> list[dict]:
    """批量评估ESG数据可信度"""
    results = []
    for item in items:
        r = assess_data_credibility(
            source=item.get("source", "未知"),
            cross_validated=item.get("cross_validated", False),
            completeness=item.get("completeness", 1.0),
            recency_days=item.get("recency_days", 30),
            has_methodology=item.get("has_methodology", False),
        )
        results.append({**item, "credibility": r})
    return results


def generate_credibility_report(stock_code: str, data_items: list[dict]) -> str:
    """生成可信度评估报告Markdown"""
    assessed = batch_assess(data_items)
    a_count = sum(1 for d in assessed if d["credibility"]["final_level"] == "A")
    b_count = sum(1 for d in assessed if d["credibility"]["final_level"] == "B")
    c_count = sum(1 for d in assessed if d["credibility"]["final_level"] == "C")
    d_count = sum(1 for d in assessed if d["credibility"]["final_level"] == "D")
    avg_ciqi = round(sum(d["credibility"]["ciqi"] for d in assessed) / len(assessed), 1)

    lines = [f"## 🔍 可信度评估报告 — {stock_code}", f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M')}", "",
             f"### 数据可信度分布", "",
             f"| 等级 | 数量 | 说明 |", f"|------|------|------|",
             f"| 🟢 A级 | {a_count}条 | 高可信，多方验证 |",
             f"| 🔵 B级 | {b_count}条 | 较可信，权威来源 |",
             f"| 🟡 C级 | {c_count}条 | 需审慎，信息缺口 |",
             f"| 🔴 D级 | {d_count}条 | 仅参考，谨慎使用 |", "",
             f"**CIQI综合信息质量指数**: {avg_ciqi} / 100", ""]

    for d in assessed:
        c = d["credibility"]
        lines.append(f"- **{d.get('data_name', d['source'])}** [{c['label']}] CIQI={c['ciqi']}")

    return "\n".join(lines)


if __name__ == "__main__":
    test_items = [
        {"source": "公司年报", "data_name": "2024年碳排放量", "cross_validated": True, "completeness": 0.95, "recency_days": 60},
        {"source": "Wind ESG", "data_name": "Wind ESG综合评分", "cross_validated": True, "completeness": 1.0, "recency_days": 15},
        {"source": "财经媒体", "data_name": "媒体估算碳排放", "cross_validated": False, "completeness": 0.6, "recency_days": 7},
        {"source": "社交媒体", "data_name": "网络传言", "cross_validated": False, "completeness": 0.2, "recency_days": 2},
    ]
    result = batch_assess(test_items)
    print("CV可信度验证 — 演示结果")
    print(f"{'数据名称':<20} {'来源':<15} {'等级':<10} {'CIQI':>6}")
    print("-" * 60)
    for r in result:
        c = r["credibility"]
        print(f"{r['data_name']:<20} {r['source']:<15} {c['final_level']:<10} {c['ciqi']:>6.1f}")
