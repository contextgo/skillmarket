#!/usr/bin/env python3
"""
ESG因子引擎 v2.0 — 完整工作流演示
基于RealGreen AI九Agent架构
9个Agent协作 + 8个人类签字节点
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "agents", "v2"))

from ic_orchestrator import ICOrchestrator
from ia_intelligence_aggregator import IAIntelligenceAggregator
from cv_credibility_validator import assess_data_credibility
from si_strategic_interpreter import interpret_esg_materiality
from rsm_risk_signal_monitor import monitor_risk_signals
from es_engagement_steward import generate_engagement_plan
from hia_human_intelligence_advisor import HumanAdvisor


def run_full_analysis(stock_code, stock_name, industry):
    print(f"\n{'='*55}")
    print(f"  ESG因子引擎 v2.0 — 全流程9Agent协作分析")
    print(f"  标的: {stock_name}({stock_code}) | 行业: {industry}")
    print(f"{'='*55}\n")

    # === STEP 1: IC任务接收 ===
    ic = ICOrchestrator()
    manifest = ic.receive_task(f"分析{stock_name}ESG投资价值", "full_analysis")
    print(f"[IC]  任务已接收 | task_id={manifest['task_id']}")

    # === HIA Node 1: 人类分析师签字 - 任务范围 ===
    hia = HumanAdvisor()
    sig1 = hia.sign(1, "分析师 张明", f"确认分析{stock_name}的ESG投资价值，重点关注E维度和政策顺风")
    print(f"[HIA#1] 任务范围签字: {sig1['status']} by {sig1['by']}")

    # === STEP 2: IA情报采集 + 去重 + 冲突仲裁 ===
    ia = IAIntelligenceAggregator()
    ia.ingest("公司年报",    "碳排放",   "2024年碳排放强度: 12.5 tCO2/百万元",  confidence=0.95)
    ia.ingest("Wind ESG",   "碳排放",   "碳排放强度: 14.2 tCO2/百万元(估算)", confidence=0.70)
    ia.ingest("华证ESG",    "ESG综合",  f"ESG评级: AA",                        confidence=0.85)
    ia.ingest("财经媒体",   "ESG新闻",  f"{stock_name}新能源业务大幅扩产",      confidence=0.60)
    ia.ingest("社交媒体",   "舆情",     "据传公司存在环保处罚记录",             confidence=0.30)
    fuse = ia.fuse()
    print(f"[IA]  情报聚合完成: 原始{fuse['total_raw_items']}条 -> 去重{fuse['after_dedup']}条 | 冲突仲裁{fuse['conflicts_resolved']}条")

    # === STEP 3: CV可信度验证 + CIQI评分 ===
    cred_items = [
        {"source": "公司年报",  "data_name": "碳排放强度", "cross_validated": True,  "completeness": 0.95, "recency_days": 60},
        {"source": "Wind ESG",  "data_name": "ESG综合评分","cross_validated": True,  "completeness": 1.0,  "recency_days": 15},
        {"source": "财经媒体",  "data_name": "扩产新闻",   "cross_validated": False, "completeness": 0.6,  "recency_days": 7},
        {"source": "社交媒体",  "data_name": "处罚记录",   "cross_validated": False, "completeness": 0.2,  "recency_days": 2},
    ]
    print(f"[CV]  可信度分级:")
    for item in cred_items:
        r = assess_data_credibility(item["source"], item["cross_validated"], item["completeness"], item["recency_days"])
        print(f"      {item['data_name']:<12} [{r['final_level']}] CIQI={r['ciqi']:>5.1f} | {r['recommendation']}")

    # === HIA Node 3: 争议数据复核 ===
    sig3 = hia.sign(3, "分析师 张明", "C/D级数据全部采信为背景参考，不作为核心决策依据")
    print(f"[HIA#3] 争议数据复核: {sig3}")

    # === STEP 4: SI战略解读 + 实质性议题 ===
    si = interpret_esg_materiality(
        stock_code, stock_name, industry,
        e_score=72, s_score=78, g_score=80,
        active_policies=["碳达峰碳中和", "科技创新"],
    )
    print(f"\n[SI]  战略解读 — {stock_name}:")
    print(f"      最强维度: {si['dimensional_strength']['strongest']} | 最弱: {si['dimensional_strength']['weakest']}")
    print(f"      洞察: {si['strategic_insight']}")
    if si.get("policy_alignment"):
        for p in si["policy_alignment"]:
            emoji = "顺风" if p["verdict"] == "顺风" else "中性" if p["verdict"] == "中性" else "逆风"
            print(f"      政策{p['policy']}: {emoji} | 重点议题: {', '.join(p['priority_themes'][:2])}")

    # === HIA Node 5+6: 趋势确认 + 战略对齐 ===
    sig5 = hia.sign(5, "分析师 李华", "锂电行业碳排放趋势解读合理，认同能源转型顺风判断")
    sig6 = hia.sign(6, "分析师 李华", "半导体行业G维度战略对齐审核通过")
    print(f"[HIA#5] 趋势解读: {sig5}")
    print(f"[HIA#6] 战略对齐: {sig6}")

    # === STEP 5: RSM风险监测 ===
    risk = monitor_risk_signals(
        stock_code, stock_name, esg_score=78,
        news_items=[
            {"content": "业绩预告增长30%，新能源业务大幅扩产", "source": "公司公告"},
            {"content": "某工厂发生安全生产波动", "source": "财经媒体"},
        ],
    )
    print(f"\n[RSM] 风险监测 — {risk['verdict']}")
    print(f"      负面事件: {risk['negative_event_count']}条 | 漂绿标记: {len(risk['greenwashing_flags'])}条 | 舆情: {risk['sentiment_label']}")

    # === HIA Node 4: 风险定级 ===
    sig4 = hia.sign(4, "分析师 张明", f"确认风险等级为{risk['risk_level']}，无需升级为high")
    print(f"[HIA#4] 风险定级: {sig4}")

    # === STEP 6: ES尽责管理 + 投票建议 ===
    eng = generate_engagement_plan(
        stock_code, stock_name,
        risk_signals=risk,
        esg_scores={"esg_total": 78, "esg_e": 72, "esg_s": 78, "esg_g": 80},
    )
    print(f"\n[ES]  尽责管理 — {len(eng['action_plan'])}项行动方案:")
    for a in eng["action_plan"][:3]:
        emoji = "高" if a["priority"] == "high" else "中"
        print(f"      [{emoji}优先级] {a['type']}: {a['action'][:40]}...")
    print(f"      投票建议: {eng['holding_recommendation']} | 跟进: {eng['follow_up_date']}")

    # === HIA Node 7: 投资建议签字 ===
    sig7 = hia.sign(7, "分析师 张明", "组合配置建议：维持当前ESG评分下的配置比例，关注E维度改善")
    print(f"\n[HIA#7] 投资建议: {sig7}")

    # === IC最终汇总 + HIA Node 8 ===
    final = ic.finalize({
        "stock_code": stock_code, "stock_name": stock_name,
        "esg_score": 78, "risk_level": risk["risk_level"],
        "verdict": risk["verdict"],
    })
    sig8 = hia.sign(8, "分析师 李华", "合规审查通过，报告可对外发布")
    print(f"[HIA#8] 合规审查: {sig8}")

    # === 汇总 ===
    sm = hia.summary()
    print(f"\n{'='*55}")
    print(f"  ESG因子引擎 v2.0 — 分析完成")
    print(f"{'='*55}")
    print(f"  标的: {stock_name}({stock_code})")
    print(f"  ESG综合评分: 78 | 风险等级: {risk['risk_level']}")
    print(f"  人机协作进度: {sm['approved']}/{sm['total']}节点已签字")
    print(f"  人类修正(override): {sm['overridden']}处")
    print(f"{'='*55}")
    return {"ic": ic, "ia": fuse, "si": si, "rsm": risk, "es": eng, "hia": hia}


if __name__ == "__main__":
    results = run_full_analysis("300750", "宁德时代", "锂电")
    print("\n[系统] 宁德时代ESG分析全流程完成!")
