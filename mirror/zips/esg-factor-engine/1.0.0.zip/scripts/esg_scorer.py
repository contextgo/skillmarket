# esg_scorer.py — ESG评分分析Agent

"""
ESG评分分析师
职责：基于多源数据构建本土化ESG评分体系
输出：E/S/G分、ESG综合分、行业百分位、同业对比
"""

import json, sys, os

# 行业E/S/G权重配置（来自a-stock-esg-positive-screening skill）
INDUSTRY_WEIGHTS = {
    # 行业中性权重配置（E=环境权重，S=社会责任权重，G=公司治理权重）
    "新能源":     {"E": 0.50, "S": 0.25, "G": 0.25},
    "光伏":       {"E": 0.55, "S": 0.20, "G": 0.25},
    "锂电":       {"E": 0.50, "S": 0.25, "G": 0.25},
    "电力":       {"E": 0.50, "S": 0.25, "G": 0.25},
    "公用事业":   {"E": 0.45, "S": 0.30, "G": 0.25},
    "银行":       {"E": 0.15, "S": 0.35, "G": 0.50},
    "保险":       {"E": 0.15, "S": 0.40, "G": 0.45},
    "证券":       {"E": 0.15, "S": 0.35, "G": 0.50},
    "房地产":     {"E": 0.30, "S": 0.35, "G": 0.35},
    "煤炭":       {"E": 0.40, "S": 0.30, "G": 0.30},
    "钢铁":       {"E": 0.45, "S": 0.25, "G": 0.30},
    "有色金属":   {"E": 0.40, "S": 0.30, "G": 0.30},
    "建筑":       {"E": 0.30, "S": 0.35, "G": 0.35},
    "交通运输":   {"E": 0.30, "S": 0.40, "G": 0.30},
    "化工":       {"E": 0.45, "S": 0.25, "G": 0.30},
    "医药":       {"E": 0.25, "S": 0.45, "G": 0.30},
    "食品饮料":   {"E": 0.25, "S": 0.45, "G": 0.30},
    "白酒":       {"E": 0.25, "S": 0.40, "G": 0.35},
    "家电":       {"E": 0.30, "S": 0.35, "G": 0.35},
    "汽车":       {"E": 0.35, "S": 0.30, "G": 0.35},
    "电子":       {"E": 0.25, "S": 0.35, "G": 0.40},
    "半导体":     {"E": 0.25, "S": 0.35, "G": 0.40},
    "软件服务":   {"E": 0.10, "S": 0.45, "G": 0.45},
    "通信":       {"E": 0.20, "S": 0.35, "G": 0.45},
    "传媒":       {"E": 0.10, "S": 0.50, "G": 0.40},
    "环保":       {"E": 0.55, "S": 0.25, "G": 0.20},
    "农业":       {"E": 0.35, "S": 0.40, "G": 0.25},
    "默认":       {"E": 0.30, "S": 0.35, "G": 0.35},
}

# 政策导向调整因子（中国特色指标）
POLICY_BONUS = {
    "碳中和": 5,     # 碳中和目标相关业务
    "乡村振兴": 3,   # 扶贫/乡村振兴参与
    "科技创新": 4,   # 专精特新/科创板
    "共同富裕": 2,   # 员工持股/股权激励
    "绿色信贷": 3,   # 绿色金融相关
}


def get_industry_weights(industry: str) -> dict:
    """获取行业权重配置"""
    return INDUSTRY_WEIGHTS.get(industry, INDUSTRY_WEIGHTS["默认"])


def build_esg_score(
    stock_code: str,
    stock_name: str,
    industry: str,
    e_raw: float,
    s_raw: float,
    g_raw: float,
    policy_factors: list[str] = None,
) -> dict:
    """
    构建ESG综合评分
    e_raw/s_raw/g_raw: 0-100原始分数
    """
    weights = get_industry_weights(industry)
    
    # 政策导向加分
    bonus = 0
    if policy_factors:
        for factor in policy_factors:
            bonus += POLICY_BONUS.get(factor, 0)
    
    # 加权综合分
    raw_score = e_raw * weights["E"] + s_raw * weights["S"] + g_raw * weights["G"]
    esg_score = min(100, raw_score + bonus)
    
    return {
        "code": stock_code,
        "name": stock_name,
        "industry": industry,
        "weights": weights,
        "e_score": round(e_raw * weights["E"], 2),
        "s_score": round(s_raw * weights["S"], 2),
        "g_score": round(g_raw * weights["G"], 2),
        "esg_raw": round(raw_score, 2),
        "policy_bonus": bonus,
        "esg_final": round(esg_score, 2),
        "grade": _score_to_grade(esg_score),
    }


def _score_to_grade(score: float) -> str:
    """评分转评级"""
    if score >= 90: return "AAA"
    if score >= 80: return "AA"
    if score >= 70: return "A"
    if score >= 60: return "BBB"
    if score >= 50: return "BB"
    if score >= 40: return "B"
    return "CCC"


def rank_within_industry(stock_scores: list[dict], stock_code: str) -> dict:
    """
    行业内ESG排名
    stock_scores: 同行业多只股票的ESG评分列表
    """
    sorted_stocks = sorted(stock_scores, key=lambda x: x["esg_final"], reverse=True)
    rank = next((i + 1 for i, s in enumerate(sorted_stocks) if s["code"] == stock_code), None)
    percentile = round((1 - (rank - 1) / len(sorted_stocks)) * 100, 1) if rank else None
    return {"rank": rank, "total": len(sorted_stocks), "percentile": percentile}


def output_esg_scores_csv(scores: list[dict], output_path: str):
    """输出ESG评分CSV"""
    import csv
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "code", "name", "industry", "e_score", "s_score", "g_score",
            "esg_raw", "policy_bonus", "esg_final", "grade"
        ])
        writer.writeheader()
        writer.writerows(sorted(scores, key=lambda x: x["esg_final"], reverse=True))
    return output_path


# 示例数据（用于演示）
DEMO_STOCKS = [
    {"code": "600519", "name": "贵州茅台", "industry": "白酒",   "e": 72, "s": 85, "g": 88},
    {"code": "002594", "name": "比亚迪",   "industry": "汽车",   "e": 78, "s": 80, "g": 75},
    {"code": "600900", "name": "长江电力", "industry": "电力",   "e": 88, "s": 82, "g": 85},
    {"code": "601012", "name": "隆基绿能", "industry": "光伏",   "e": 85, "s": 75, "g": 72},
    {"code": "688041", "name": "海光信息", "industry": "半导体", "e": 60, "s": 78, "g": 82},
    {"code": "600019", "name": "宝钢股份", "industry": "钢铁",   "e": 65, "s": 70, "g": 75},
    {"code": "600585", "name": "海螺水泥", "industry": "煤炭",   "e": 55, "s": 68, "g": 72},
    {"code": "002371", "name": "北方华创", "industry": "半导体", "e": 62, "s": 76, "g": 80},
]


if __name__ == "__main__":
    # 演示：构建示例股票ESG评分
    results = []
    for s in DEMO_STOCKS:
        r = build_esg_score(s["code"], s["name"], s["industry"], s["e"], s["s"], s["g"])
        results.append(r)
    
    ranked = sorted(results, key=lambda x: x["esg_final"], reverse=True)
    print("\n📊 ESG因子引擎 — 评分结果")
    print(f"{'代码':<8} {'名称':<8} {'行业':<6} {'E':>5} {'S':>5} {'G':>5} {'ESG':>6} {'等级':<4}")
    print("-" * 60)
    for r in ranked:
        print(f"{r['code']:<8} {r['name']:<8} {r['industry']:<6} "
              f"{r['e_score']:>5.1f} {r['s_score']:>5.1f} {r['g_score']:>5.1f} "
              f"{r['esg_final']:>6.1f} {r['grade']:<4}")