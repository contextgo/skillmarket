"""
SI (Strategic Interpreter) — 战略解读员
职责：解读行业ESG实质性议题、分析政策周期适配性、判断公司治理质量
映射：原「行业适配」+「治理分析」功能
"""
import json
from datetime import datetime

# 各行业ESG实质性议题矩阵（Materiality Matrix）
MATERIALITY_MATRIX = {
    "新能源": {
        "E": ["碳排放强度", "可再生能源使用率", "废水排放", "生态恢复投入"],
        "S": ["职业健康与安全", "供应链劳工权益", "社区关系"],
        "G": ["董事会多样性", "高管薪酬", "关联交易透明度"],
    },
    "光伏": {
        "E": ["能耗强度", "水资源使用", "土地使用", "稀有材料采购"],
        "S": ["供应链人权", "本地就业贡献", "产品安全"],
        "G": ["供应链治理", "出口合规", "技术主权"],
    },
    "锂电": {
        "E": ["上游采矿环境", "水资源消耗", "回收体系完善度"],
        "S": ["矿产供应链劳工", "安全生产记录", "社区健康影响"],
        "G": ["供应链ESG审核", "反腐败政策", "数据安全"],
    },
    "电力": {
        "E": ["碳排放强度", "空气质量", "水资源影响", "碳汇项目"],
        "S": ["电价可负担性", "供电可靠性", "就业创造"],
        "G": ["国企治理特殊性", "关联交易", "信息披露质量"],
    },
    "半导体": {
        "E": ["能耗强度", "温室气体排放", "化学品使用", "用水强度"],
        "S": ["人才吸引力", "研发人员留存", "供应链劳工"],
        "G": ["出口管制合规", "技术护城河", "供应链安全"],
    },
    "白酒": {
        "E": ["酿造用水质量", "酿酒副产物利用", "包装减量"],
        "S": ["渠道管控(防伪)", "青少年保护", "理性饮酒推广"],
        "G": ["关联交易", "存货周转", "国企改革进度"],
    },
    "煤炭": {
        "E": ["碳排放强度", "甲烷泄漏", "土地复垦", "塌陷区治理"],
        "S": ["员工转型安置", "关闭矿山补偿", "社区转型支持"],
        "G": ["产能合规性", "项目审批合规", "关联交易"],
    },
    "银行": {
        "E": ["绿色信贷占比", "棕色资产敞口", "气候风险敞口"],
        "S": ["金融普惠", "金融教育", "数据隐私保护"],
        "G": ["资本充足率", "关联贷款", "高管激励", "ESG风险管理架构"],
    },
    "保险": {
        "E": ["承保组合碳强度", "可再生能源保险产品", "巨灾风险敞口"],
        "S": ["产品可负担性", "医疗险覆盖广度", "理赔效率"],
        "G": ["精算假设审慎性", "投资端ESG", "负债端ESG"],
    },
    "默认": {
        "E": ["碳排放强度", "能源效率", "废弃物管理", "水资源"],
        "S": ["员工多元化", "供应链劳工", "产品安全", "社区投资"],
        "G": ["董事会结构", "高管薪酬", "信息披露", "商业道德"],
    },
}

# 中国政策周期与ESG主题映射
POLICY_CYCLE_ESG = {
    "碳达峰碳中和": {"E": 0.9, "S": 0.3, "G": 0.5, "priority_themes": ["碳排放披露", "绿色收入"]},
    "乡村振兴": {"E": 0.3, "S": 0.9, "G": 0.4, "priority_themes": ["农民增收", "农村就业"]},
    "共同富裕": {"E": 0.3, "S": 0.9, "G": 0.6, "priority_themes": ["收入分配", "三次分配"]},
    "科技创新": {"E": 0.4, "S": 0.5, "G": 0.8, "priority_themes": ["专精特新", "技术自主"]},
    "数据安全": {"E": 0.1, "S": 0.6, "G": 0.9, "priority_themes": ["数据合规", "用户隐私"]},
    "能源安全": {"E": 0.9, "S": 0.4, "G": 0.5, "priority_themes": ["能源转型", "能源储备"]},
}


def get_materiality_topics(industry: str) -> dict:
    return MATERIALITY_MATRIX.get(industry, MATERIALITY_MATRIX["默认"])


def interpret_esg_materiality(
    stock_code: str,
    stock_name: str,
    industry: str,
    e_score: float,
    s_score: float,
    g_score: float,
    active_policies: list[str] = None,
) -> dict:
    """
    解读公司ESG实质性议题
    结合行业Materiality Matrix + 政策周期，给出实质性议题优先级
    """
    topics = get_materiality_topics(industry)

    # 行业内部E/S/G相对表现
    scores = {"E": e_score, "S": s_score, "G": g_score}
    best_dim = max(scores, key=scores.get)
    worst_dim = min(scores, key=scores.get)

    # 政策顺风评估
    policy_alignment = []
    if active_policies:
        for pol in active_policies:
            pol_info = POLICY_CYCLE_ESG.get(pol, {"E": 0.3, "S": 0.3, "G": 0.3, "priority_themes": []})
            alignment = round((scores["E"] * pol_info["E"] +
                               scores["S"] * pol_info["S"] +
                               scores["G"] * pol_info["G"]) / 3, 2)
            policy_alignment.append({
                "policy": pol,
                "alignment_score": alignment,
                "priority_themes": pol_info["priority_themes"],
                "verdict": "顺风" if alignment >= 60 else "中性" if alignment >= 40 else "逆风",
            })

    # 实质性议题优先级排序
    material_issues = []
    for dim, dim_topics in topics.items():
        for topic in dim_topics:
            material_issues.append({
                "topic": topic,
                "dimension": dim,
                "current_score": scores[dim],
                "materiality": "高" if scores[dim] >= 70 else "中" if scores[dim] >= 50 else "低",
            })
    material_issues.sort(key=lambda x: (x["materiality"] == "高", x["current_score"]), reverse=True)

    return {
        "stock_code": stock_code,
        "stock_name": stock_name,
        "industry": industry,
        "materiality_matrix": topics,
        "dimensional_strength": {"E": e_score, "S": s_score, "G": g_score, "strongest": best_dim, "weakest": worst_dim},
        "policy_alignment": policy_alignment,
        "top_material_issues": material_issues[:6],
        "strategic_insight": _generate_insight(stock_name, best_dim, worst_dim, policy_alignment),
    }


def _generate_insight(name: str, best: str, worst: str, policy: list) -> str:
    tailwind = [p for p in policy if p["verdict"] == "顺风"]
    insights = [f"{name}在【{best}】维度表现突出"]
    if worst:
        insights.append(f"【{worst}】维度需重点关注")
    if tailwind:
        insights.append(f"当前政策顺风：{', '.join([p['policy'] for p in tailwind])}")
    return "；".join(insights)


def generate_strategic_narrative(interp: dict) -> str:
    """生成战略解读叙事文本"""
    lines = [
        f"## 📋 战略解读报告 — {interp['stock_name']}（{interp['stock_code']}）",
        f"**行业**: {interp['industry']} | **生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M')}", "",
        "### 实质性议题矩阵",
        "",
    ]
    for dim in ["E", "S", "G"]:
        topics = interp["materiality_matrix"].get(dim, [])
        score = interp["dimensional_strength"].get(dim, 0)
        label = "环境" if dim == "E" else "社会" if dim == "S" else "治理"
        lines.append(f"**{label}({dim}): {score:.1f}分**")
        for t in topics:
            mat = next((m for m in interp["top_material_issues"] if m["topic"] == t and m["dimension"] == dim), {})
            lines.append(f"  - {t} {'⭐高实质性' if mat.get('materiality')=='高' else ''}")
        lines.append("")

    if interp.get("policy_alignment"):
        lines.append("### 政策周期适配")
        for p in interp["policy_alignment"]:
            emoji = "🟢" if p["verdict"] == "顺风" else "🟡" if p["verdict"] == "中性" else "🔴"
            lines.append(f"{emoji} **{p['policy']}**: {p['verdict']}（得分{p['alignment_score']}）")
            lines.append(f"   重点议题：{', '.join(p['priority_themes'])}")

    lines.append("")
    lines.append(f"### 战略洞察\n{interp.get('strategic_insight', '')}")
    return "\n".join(lines)


if __name__ == "__main__":
    r = interpret_esg_materiality("300750", "宁德时代", "锂电",
                                    e_score=72, s_score=78, g_score=80,
                                    active_policies=["碳达峰碳中和", "科技创新"])
    print(generate_strategic_narrative(r))
