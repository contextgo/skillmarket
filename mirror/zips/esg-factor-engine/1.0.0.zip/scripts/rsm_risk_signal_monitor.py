"""RSM (Risk Signal Monitor) — 风险信号监测员
职责：ESG负面事件识别、漂绿检测、舆情情绪、风险预警
"""
import json
from datetime import datetime


NEGATIVE_KEYWORDS = ["处罚", "违规", "召回", "造假", "污染", "泄露", "诉讼", "调查", "罚款", "停产"]


def monitor_risk_signals(stock_code, stock_name, esg_score, news_items, esg_report_quality="B"):
    """监测ESG风险信号"""
    signals = []
    risk_level = "low"

    # 负面新闻扫描
    neg_count = 0
    for news in news_items:
        content = news.get("content", "")
        for kw in NEGATIVE_KEYWORDS:
            if kw in content:
                neg_count += 1
                signals.append({
                    "type": "负面事件",
                    "keyword": kw,
                    "source": news.get("source", ""),
                    "content": content,
                })
                break

    # 漂绿检测
    greenwashing_flags = []
    if esg_score > 80 and esg_report_quality in ["C", "D"]:
        greenwashing_flags.append("ESG高评分但报告质量低，存在漂绿风险")
    if esg_score > 85:
        greenwashing_flags.append("ESG评分处于行业顶端，建议核实数据来源")

    # 舆情情绪
    positive_kws = ["增长", "盈利", "突破", "获奖", "扩产"]
    negative_kws = ["处罚", "违规", "召回", "停产"]
    sentiment_score = 0
    for news in news_items:
        c = news.get("content", "")
        sentiment_score += sum(3 for kw in positive_kws if kw in c)
        sentiment_score -= sum(4 for kw in negative_kws if kw in c)

    # 综合风险等级
    if neg_count >= 3 or len(greenwashing_flags) >= 2:
        risk_level = "high"
    elif neg_count >= 1 or greenwashing_flags:
        risk_level = "medium"

    sentiment_label = "负面" if sentiment_score < -10 else "中性" if abs(sentiment_score) <= 10 else "正面"
    verdict_map = {"low": "低", "medium": "中", "high": "高"}

    return {
        "stock_code": stock_code,
        "stock_name": stock_name,
        "risk_level": risk_level,
        "negative_event_count": neg_count,
        "signals": signals[:5],
        "greenwashing_flags": greenwashing_flags,
        "sentiment_score": sentiment_score,
        "sentiment_label": sentiment_label,
        "monitoring_timestamp": datetime.now().isoformat(),
        "verdict": f"风险{verdict_map[risk_level]} | 舆情{sentiment_label}",
    }


def generate_risk_narrative(risk_result: dict) -> str:
    """生成风险监测叙事文本"""
    lines = [
        f"## ⚠️ 风险监测报告 — {risk_result['stock_name']}（{risk_result['stock_code']}）",
        f"**生成时间**: {risk_result['monitoring_timestamp']}",
        "",
        f"### 综合风险定级: {risk_result['verdict']}",
        "",
    ]

    if risk_result["signals"]:
        lines.append("### 负面事件信号")
        for s in risk_result["signals"]:
            lines.append(f"- [{s['source']}] {s['keyword']}: {s['content'][:60]}")
        lines.append("")

    if risk_result["greenwashing_flags"]:
        lines.append("### 漂绿预警")
        for flag in risk_result["greenwashing_flags"]:
            lines.append(f"- 🔴 {flag}")
        lines.append("")

    lines.append(f"### 舆情情绪\n{risk_result['sentiment_label']}（情绪分: {risk_result['sentiment_score']}）")
    return "\n".join(lines)


if __name__ == "__main__":
    test_news = [
        {"content": "某公司因环保违规被罚款500万元", "source": "财经媒体"},
        {"content": "业绩预告增长30%，新能源业务大幅扩产", "source": "公司公告"},
        {"content": "ESG报告连续三年获得AA评级", "source": "Wind ESG"},
    ]
    r = monitor_risk_signals("300750", "宁德时代", esg_score=82,
                              news_items=test_news, esg_report_quality="B")
    print(f"风险监控: {r['stock_name']} | {r['verdict']}")
    print(f"  负面事件: {r['negative_event_count']}条")
    print(f"  漂绿标记: {len(r['greenwashing_flags'])}条")
    print(f"  舆情情绪: {r['sentiment_label']}({r['sentiment_score']})")
