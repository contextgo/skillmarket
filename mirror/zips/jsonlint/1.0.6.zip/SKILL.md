---
name: JSONLint
description: "Validate and pretty-print JSON files from the terminal. Use when linting config files, formatting API payloads, checking syntax before deployment."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["json","validator","formatter","lint","pretty-print","minify","developer","data"]
categories: ["Developer Tools", "Utility"]
---

# JSONLint

A developer toolkit for working with JSON and structured data from the terminal. Check, validate, generate, format, lint, explain, convert, diff, preview, fix, and report — with built-in history tracking, search, statistics, and data export.

## Commands

### Core Operations

| Command | Description |
|---------|-------------|
| `jsonlint check <input>` | Record a check entry; without args, shows recent check entries |
| `jsonlint validate <input>` | Record a validation entry; without args, shows recent validations |
| `jsonlint generate <input>` | Record a generate entry; without args, shows recent generations |
| `jsonlint format <input>` | Record a format entry; without args, shows recent format entries |
| `jsonlint lint <input>` | Record a lint entry; without args, shows recent lint entries |
| `jsonlint explain <input>` | Record an explain entry; without args, shows recent explanations |
| `jsonlint convert <input>` | Record a convert entry; without args, shows recent conversions |
| `jsonlint template <input>` | Record a template entry; without args, shows recent templates |
| `jsonlint diff <input>` | Record a diff entry; without args, shows recent diffs |
| `jsonlint preview <input>` | Record a preview entry; without args, shows recent previews |
| `jsonlint fix <input>` | Record a fix entry; without args, shows recent fixes |
| `jsonlint report <input>` | Record a report entry; without args, shows recent reports |

### Management & Export

| Command | Description |
|---------|-------------|
| `jsonlint stats` | Show summary statistics across all log categories |
| `jsonlint export <fmt>` | Export all data in `json`, `csv`, or `txt` format |
| `jsonlint search <term>` | Search across all log files for a term (case-insensitive) |
| `jsonlint recent` | Show the 20 most recent activity entries |
| `jsonlint status` | Health check — version, data dir, entry count, disk usage, last activity |
| `jsonlint help` | Show the built-in help message |
| `jsonlint version` | Print the current version |

## Data Storage

All entries are stored in `~/.local/share/jsonlint/` as individual log files per command category (e.g., `check.log`, `validate.log`, `lint.log`). A unified `history.log` tracks all activity with timestamps. Each entry is pipe-delimited (`timestamp|value`) for easy parsing. Export to JSON, CSV, or plain text at any time.

## Requirements

- Bash 4+ with standard Unix utilities (`date`, `wc`, `du`, `grep`, `tail`, `head`, `sed`)
- No external dependencies or API keys required
- Works on any Linux/macOS terminal

## When to Use

1. **Tracking JSON validation work** — Use `jsonlint validate <file>` to log each validation you perform and review history later with `jsonlint validate` (no args).
2. **Auditing development activity** — Run `jsonlint stats` to see how many checks, lints, formats, and other operations you've performed across all categories.
3. **Searching past entries** — Use `jsonlint search <term>` to find specific entries across all log files when you need to recall past work.
4. **Exporting records** — Run `jsonlint export json` (or `csv`/`txt`) to export all logged data for reporting, backup, or integration with other tools.
5. **Quick status check** — Use `jsonlint status` to see version info, data directory location, total entries, disk usage, and last activity at a glance.

## Examples

```bash
# Log a check operation
jsonlint check config.json

# Log a validation
jsonlint validate api-response.json

# Log a format operation
jsonlint format data.json

# Log a lint operation
jsonlint lint package.json

# View recent lint entries (no args)
jsonlint lint

# Show summary statistics
jsonlint stats

# Export all data as JSON
jsonlint export json

# Export all data as CSV
jsonlint export csv

# Search for a term across all logs
jsonlint search "config"

# View recent activity
jsonlint recent

# Health check
jsonlint status
```

## How It Works

JSONLint stores all entries locally in `~/.local/share/jsonlint/`. Each command type has its own log file. When you run a command with input, it records a timestamped entry. Running the same command without arguments shows the 20 most recent entries from that category. The `history.log` file provides a unified audit trail of all operations.

---

Powered by BytesAgain | bytesagain.com | hello@bytesagain.com
