#!/usr/bin/env node
/**
 * Cognitive Brain - 元认知反思模块
 * 分析行为模式，生成洞察
 */

const fs = require('fs');
const path = require('path');

const HOME = process.env.HOME || '/root';
const SKILL_DIR = path.join(HOME, '.openclaw/workspace/skills/cognitive-brain');
const CONFIG_PATH = path.join(SKILL_DIR, 'config.json');
const REFLECTIONS_PATH = path.join(SKILL_DIR, '.reflections.json');

// 反思存储
let reflections = {
  records: [],
  insights: [],
  patterns: []
};

/**
 * 加载反思数据
 */
function load() {
  try {
    if (fs.existsSync(REFLECTIONS_PATH)) {
      reflections = JSON.parse(fs.readFileSync(REFLECTIONS_PATH, 'utf8'));
    }
  } catch (e) {
    reflections = { records: [], insights: [], patterns: [] };
  }
}

/**
 * 保存反思数据
 */
function save() {
  try {
    // 保留最近 100 条
    reflections.records = reflections.records.slice(-100);
    fs.writeFileSync(REFLECTIONS_PATH, JSON.stringify(reflections, null, 2));
  } catch (e) {
    // ignore
  }
}

/**
 * 反思触发类型
 */
const TRIGGER_TYPES = {
  TASK_FAILURE: {
    name: 'task_failure',
    description: '任务失败',
    priority: 'high'
  },
  TASK_SUCCESS: {
    name: 'task_success',
    description: '任务成功',
    priority: 'medium'
  },
  USER_CORRECTION: {
    name: 'user_correction',
    description: '用户纠正',
    priority: 'high'
  },
  PATTERN_FOUND: {
    name: 'pattern_found',
    description: '发现模式',
    priority: 'medium'
  },
  PERIODIC: {
    name: 'periodic',
    description: '定期反思',
    priority: 'low'
  }
};

/**
 * 执行反思
 */
async function reflect(triggerType, context = {}) {
  load();

  const reflection = {
    id: `ref_${Date.now()}`,
    timestamp: Date.now(),
    trigger: triggerType,
    context,
    analysis: {},
    insights: [],
    recommendations: []
  };

  // 根据触发类型进行分析
  switch (triggerType) {
    case 'task_failure':
      reflection.analysis = analyzeFailure(context);
      break;

    case 'task_success':
      reflection.analysis = analyzeSuccess(context);
      break;

    case 'user_correction':
      reflection.analysis = analyzeCorrection(context);
      break;

    case 'pattern_found':
      reflection.analysis = analyzePattern(context);
      break;

    case 'periodic':
      reflection.analysis = analyzePeriodic();
      break;
  }

  // 生成洞察
  reflection.insights = generateInsights(reflection.analysis);

  // 生成建议
  reflection.recommendations = generateRecommendations(reflection.insights);

  // 保存
  reflections.records.push(reflection);
  save();

  return reflection;
}

/**
 * 分析失败
 */
function analyzeFailure(context) {
  const analysis = {
    errorType: context.error?.type || 'unknown',
    errorMessage: context.error?.message || '',
    attemptedAction: context.action || '',
    rootCause: null,
    contributingFactors: []
  };

  // 分析根本原因
  if (context.error?.message) {
    if (context.error.message.includes('ECONNREFUSED')) {
      analysis.rootCause = 'network';
      analysis.contributingFactors.push('网络连接问题');
    } else if (context.error.message.includes('ENOENT')) {
      analysis.rootCause = 'resource';
      analysis.contributingFactors.push('资源不存在');
    } else if (context.error.message.includes('permission')) {
      analysis.rootCause = 'permission';
      analysis.contributingFactors.push('权限不足');
    } else {
      analysis.rootCause = 'unknown';
      analysis.contributingFactors.push('未知错误');
    }
  }

  return analysis;
}

/**
 * 分析成功
 */
function analyzeSuccess(context) {
  return {
    action: context.action || '',
    duration: context.duration || 0,
    successFactors: context.factors || [],
    canReplicate: true
  };
}

/**
 * 分析用户纠正
 */
function analyzeCorrection(context) {
  return {
    originalAction: context.originalAction || '',
    correctedAction: context.correctedAction || '',
    whatWasWrong: context.whatWasWrong || '',
    lessonLearned: `用户偏好: ${context.correctedAction}`
  };
}

/**
 * 分析模式
 */
function analyzePattern(context) {
  return {
    pattern: context.pattern || '',
    occurrences: context.occurrences || 0,
    significance: context.significance || 'medium',
    relatedConcepts: context.concepts || []
  };
}

/**
 * 定期分析
 */
function analyzePeriodic() {
  const recent = reflections.records.slice(-20);

  // 统计成功率
  const failures = recent.filter(r => r.trigger === 'task_failure').length;
  const successes = recent.filter(r => r.trigger === 'task_success').length;
  const total = failures + successes;
  const successRate = total > 0 ? successes / total : 0;

  // 统计常见错误
  const errorTypes = {};
  for (const r of recent) {
    if (r.analysis?.errorType) {
      errorTypes[r.analysis.errorType] = (errorTypes[r.analysis.errorType] || 0) + 1;
    }
  }

  return {
    period: 'recent_20',
    successRate,
    failures,
    successes,
    commonErrors: Object.entries(errorTypes)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
  };
}

/**
 * 生成洞察
 */
function generateInsights(analysis) {
  const insights = [];

  // 基于分析类型生成洞察
  if (analysis.rootCause) {
    insights.push({
      type: 'root_cause',
      content: `根本原因: ${analysis.rootCause}`,
      confidence: 0.8
    });
  }

  if (analysis.contributingFactors) {
    for (const factor of analysis.contributingFactors) {
      insights.push({
        type: 'contributing_factor',
        content: factor,
        confidence: 0.7
      });
    }
  }

  if (analysis.successRate !== undefined) {
    if (analysis.successRate < 0.5) {
      insights.push({
        type: 'performance_warning',
        content: `成功率较低: ${(analysis.successRate * 100).toFixed(1)}%`,
        confidence: 0.9
      });
    } else if (analysis.successRate > 0.8) {
      insights.push({
        type: 'performance_good',
        content: `表现良好，成功率: ${(analysis.successRate * 100).toFixed(1)}%`,
        confidence: 0.9
      });
    }
  }

  if (analysis.lessonLearned) {
    insights.push({
      type: 'lesson',
      content: analysis.lessonLearned,
      confidence: 0.9
    });
  }

  return insights;
}

/**
 * 生成建议
 */
function generateRecommendations(insights) {
  const recommendations = [];

  for (const insight of insights) {
    switch (insight.type) {
      case 'root_cause':
        if (insight.content.includes('network')) {
          recommendations.push('建议检查网络连接，或启用离线模式');
        } else if (insight.content.includes('resource')) {
          recommendations.push('建议先检查资源是否存在');
        } else if (insight.content.includes('permission')) {
          recommendations.push('建议请求用户授权或使用替代方案');
        }
        break;

      case 'performance_warning':
        recommendations.push('建议分析失败原因，优化策略');
        break;

      case 'lesson':
        recommendations.push(`记住这个偏好，以后避免类似错误`);
        break;
    }
  }

  return [...new Set(recommendations)];  // 去重
}

/**
 * 获取反思统计
 */
function getStats() {
  load();

  const byTrigger = {};
  for (const r of reflections.records) {
    byTrigger[r.trigger] = (byTrigger[r.trigger] || 0) + 1;
  }

  return {
    total: reflections.records.length,
    byTrigger,
    insights: reflections.insights.length,
    patterns: reflections.patterns.length
  };
}

/**
 * 获取最近洞察
 */
function getRecentInsights(limit = 20) {
  load();

  const insights = [];
  for (const r of reflections.records) {
    if (r.insights) {
      insights.push(...r.insights.map(i => ({
        ...i,
        timestamp: r.timestamp,
        trigger: r.trigger
      })));
    }
  }

  return insights.slice(-limit);
}

/**
 * 从数据库加载并反思
 */
async function reflectFromDB() {
  try {
    const pg = require(path.join(SKILL_DIR, 'node_modules/pg'));
    const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));

    const { Pool } = pg;
    const pool = new Pool(config.storage.primary);

    // 获取最近的 episodes
    const episodes = await pool.query(`
      SELECT * FROM episodes
      WHERE created_at > NOW() - INTERVAL '24 hours'
      ORDER BY created_at DESC
      LIMIT 100
    `);

    await pool.end();

    // 分析
    const failures = episodes.rows.filter(e => e.type === 'error').length;
    const successes = episodes.rows.filter(e => e.type === 'success').length;
    const corrections = episodes.rows.filter(e => e.type === 'correction').length;

    const context = {
      total: episodes.rows.length,
      failures,
      successes,
      corrections
    };

    return reflect('periodic', context);

  } catch (e) {
    console.log('[reflect] 数据库不可用');
    return reflect('periodic', {});
  }
}

// ===== 主函数 =====
async function main() {
  const action = process.argv[2];
  const args = process.argv.slice(3);

  load();

  switch (action) {
    case 'run':
      const trigger = args[0] || 'periodic';
      const result = await reflect(trigger, { note: args.slice(1).join(' ') });
      console.log('🤔 反思结果:');
      console.log(JSON.stringify(result, null, 2));
      break;

    case 'insights':
      const insights = getRecentInsights();
      console.log('💡 最近洞察:');
      insights.forEach((i, idx) => {
        console.log(`   ${idx + 1}. [${i.type}] ${i.content}`);
      });
      break;

    case 'stats':
      console.log(JSON.stringify(getStats(), null, 2));
      break;

    case 'history':
      const recent = reflections.records.slice(-10);
      console.log('📋 最近反思:');
      recent.forEach((r, i) => {
        console.log(`   ${i + 1}. [${r.trigger}] ${r.insights.length} 个洞察`);
      });
      break;

    default:
      console.log(`
元认知反思模块

用法:
  node reflect.cjs run [trigger] [note]   # 执行反思
  node reflect.cjs insights               # 查看洞察
  node reflect.cjs stats                  # 查看统计
  node reflect.cjs history                # 查看历史

触发类型:
  - task_failure: 任务失败
  - task_success: 任务成功
  - user_correction: 用户纠正
  - pattern_found: 发现模式
  - periodic: 定期反思
      `);
  }
}

main();
