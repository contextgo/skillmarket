#!/usr/bin/env node
/**
 * Cognitive Brain - Post-install script
 * 自动复制 hooks 到 ~/.openclaw/hooks/
 */

const fs = require('fs');
const path = require('path');

const HOME = process.env.HOME || '/root';
const OPENCLAW_HOOKS_DIR = path.join(HOME, '.openclaw', 'hooks');
const SKILL_DIR = path.dirname(__dirname);
const HOOKS_IN_SKILL = path.join(SKILL_DIR, 'hooks');

console.log('🧠 Cognitive Brain postinstall...\n');

// 确保 ~/.openclaw/hooks 目录存在
if (!fs.existsSync(OPENCLAW_HOOKS_DIR)) {
  fs.mkdirSync(OPENCLAW_HOOKS_DIR, { recursive: true });
  console.log(`✅ Created: ${OPENCLAW_HOOKS_DIR}`);
}

// 扫描 skill 内的 hooks 并复制
if (fs.existsSync(HOOKS_IN_SKILL)) {
  const hookDirs = fs.readdirSync(HOOKS_IN_SKILL).filter(f => {
    return fs.statSync(path.join(HOOKS_IN_SKILL, f)).isDirectory();
  });
  
  for (const hookName of hookDirs) {
    const targetDir = path.join(OPENCLAW_HOOKS_DIR, hookName);
    const sourceDir = path.join(HOOKS_IN_SKILL, hookName);
    
    // 如果已存在，先删除
    if (fs.existsSync(targetDir)) {
      fs.rmSync(targetDir, { recursive: true, force: true });
      console.log(`🗑️  Removed old hook: ${targetDir}`);
    }
    
    // 复制目录
    fs.cpSync(sourceDir, targetDir, { recursive: true });
    console.log(`✅ Copied: ${hookName}`);
  }
}

console.log('\n✨ Hooks installed. Restart gateway to activate.');
console.log('   Run: openclaw gateway restart\n');
