#!/usr/bin/env node
/**
 * Cognitive Brain - 用户建模模块
 * 构建和维护用户画像
 */

const fs = require('fs');
const path = require('path');

const HOME = process.env.HOME || '/root';
const SKILL_DIR = path.join(HOME, '.openclaw/workspace/skills/cognitive-brain');
const CONFIG_PATH = path.join(SKILL_DIR, 'config.json');
const USER_MODEL_PATH = path.join(SKILL_DIR, '.user-model.json');

// 用户模型
const userModel = {
  // 基本信息
  basic: {
    name: null,
    preferredName: null,
    timezone: null,
    language: 'zh-CN',
    communicationStyle: 'casual' // casual, formal, technical
  },

  // 偏好
  preferences: {
    topics: {},           // { topic: interest_score }
    communicationTone: 'friendly',
    responseLength: 'medium', // short, medium, long
    levelOfDetail: 'balanced', // brief, balanced, detailed
    proactivity: 'moderate'    // passive, moderate, proactive
  },

  // 行为模式
  patterns: {
    activeHours: [],      // 活跃时段
    commonTasks: {},      // 常见任务
    interactionFrequency: 0,
    avgSessionLength: 0
  },

  // 知识水平
  knowledge: {
    knownConcepts: [],
    expertiseAreas: [],
    learningInterests: []
  },

  // 统计
  stats: {
    totalInteractions: 0,
    lastInteraction: null,
    sessions: []
  }
};

/**
 * 加载用户模型
 */
function load() {
  try {
    if (fs.existsSync(USER_MODEL_PATH)) {
      const data = JSON.parse(fs.readFileSync(USER_MODEL_PATH, 'utf8'));
      Object.assign(userModel, data);
    }
  } catch (e) {
    console.warn('[user-model] Load failed:', e.message);
  }
}

/**
 * 保存用户模型
 */
function save() {
  try {
    fs.writeFileSync(USER_MODEL_PATH, JSON.stringify(userModel, null, 2));
  } catch (e) {
    console.warn('[user-model] Save failed:', e.message);
  }
}

/**
 * 更新基本信息
 */
function updateBasic(info) {
  Object.assign(userModel.basic, info);
  save();
}

/**
 * 记录兴趣
 */
function recordInterest(topic, delta = 0.1) {
  if (!userModel.preferences.topics[topic]) {
    userModel.preferences.topics[topic] = 0;
  }
  userModel.preferences.topics[topic] = Math.min(1,
    Math.max(0, userModel.preferences.topics[topic] + delta)
  );
  save();
}

/**
 * 获取用户偏好
 */
function getPreferences() {
  return {
    ...userModel.preferences,
    topInterests: Object.entries(userModel.preferences.topics)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([topic, score]) => ({ topic, score }))
  };
}

/**
 * 记录交互
 */
function recordInteraction(metadata = {}) {
  userModel.stats.totalInteractions++;
  userModel.stats.lastInteraction = Date.now();

  // 记录活跃时段
  const hour = new Date().getHours();
  const activeHours = userModel.patterns.activeHours;
  if (!activeHours.includes(hour)) {
    activeHours.push(hour);
    activeHours.sort();
  }

  // 记录常见任务
  if (metadata.task) {
    userModel.patterns.commonTasks[metadata.task] =
      (userModel.patterns.commonTasks[metadata.task] || 0) + 1;
  }

  // 记录话题兴趣
  if (metadata.topic) {
    recordInterest(metadata.topic, 0.1);
  }

  save();
}

/**
 * 记录会话
 */
function recordSession(duration, interactions) {
  userModel.stats.sessions.push({
    startedAt: Date.now() - duration,
    endedAt: Date.now(),
    duration,
    interactions
  });

  // 保留最近 30 天的会话
  const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
  userModel.stats.sessions = userModel.stats.sessions
    .filter(s => s.startedAt > cutoff);

  // 更新平均会话长度
  const avgLength = userModel.stats.sessions
    .reduce((sum, s) => sum + s.duration, 0) / userModel.stats.sessions.length;
  userModel.patterns.avgSessionLength = avgLength;
  userModel.patterns.interactionFrequency = userModel.stats.sessions.length;

  save();
}

/**
 * 添加已知概念
 */
function addKnownConcept(concept) {
  if (!userModel.knowledge.knownConcepts.includes(concept)) {
    userModel.knowledge.knownConcepts.push(concept);
    save();
  }
}

/**
 * 添加专业领域
 */
function addExpertiseArea(area) {
  if (!userModel.knowledge.expertiseAreas.includes(area)) {
    userModel.knowledge.expertiseAreas.push(area);
    save();
  }
}

/**
 * 添加学习兴趣
 */
function addLearningInterest(interest) {
  if (!userModel.knowledge.learningInterests.includes(interest)) {
    userModel.knowledge.learningInterests.push(interest);
    save();
  }
}

/**
 * 推断沟通风格
 */
function inferCommunicationStyle(messages) {
  // 简单的启发式规则
  const formalIndicators = ['请', '麻烦', '能否', '是否', '您好'];
  const casualIndicators = ['哈', '哈哈', '嗯', '啊', '呢', '吧'];
  const technicalIndicators = ['代码', '实现', '配置', '参数', '模块'];

  let formalCount = 0;
  let casualCount = 0;
  let technicalCount = 0;

  for (const msg of messages) {
    for (const indicator of formalIndicators) {
      if (msg.includes(indicator)) formalCount++;
    }
    for (const indicator of casualIndicators) {
      if (msg.includes(indicator)) casualCount++;
    }
    for (const indicator of technicalIndicators) {
      if (msg.includes(indicator)) technicalCount++;
    }
  }

  if (technicalCount > formalCount && technicalCount > casualCount) {
    userModel.basic.communicationStyle = 'technical';
  } else if (formalCount > casualCount) {
    userModel.basic.communicationStyle = 'formal';
  } else {
    userModel.basic.communicationStyle = 'casual';
  }

  save();
}

/**
 * 获取用户画像摘要
 */
function getProfileSummary() {
  return {
    name: userModel.basic.name || userModel.basic.preferredName || 'Unknown',
    communicationStyle: userModel.basic.communicationStyle,
    topInterests: Object.entries(userModel.preferences.topics)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([topic]) => topic),
    expertiseAreas: userModel.knowledge.expertiseAreas,
    activeHours: userModel.patterns.activeHours,
    totalInteractions: userModel.stats.totalInteractions,
    avgSessionLength: Math.round(userModel.patterns.avgSessionLength / 60000) + ' min'
  };
}

/**
 * 预测用户需求
 */
function predictNeeds() {
  const predictions = [];

  // 基于时间预测
  const hour = new Date().getHours();
  if (userModel.patterns.activeHours.includes(hour)) {
    predictions.push({
      type: 'timing',
      confidence: 0.7,
      message: '用户通常在这个时段活跃'
    });
  }

  // 基于常见任务预测
  const commonTasks = Object.entries(userModel.patterns.commonTasks)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  if (commonTasks.length > 0) {
    predictions.push({
      type: 'task',
      confidence: 0.6,
      message: `用户经常做: ${commonTasks.map(([t]) => t).join(', ')}`
    });
  }

  // 基于兴趣预测
  const topInterests = Object.entries(userModel.preferences.topics)
    .filter(([_, score]) => score > 0.5)
    .slice(0, 3);

  if (topInterests.length > 0) {
    predictions.push({
      type: 'interest',
      confidence: 0.5,
      message: `用户感兴趣: ${topInterests.map(([t]) => t).join(', ')}`
    });
  }

  return predictions;
}

// ===== 主函数 =====
async function main() {
  const action = process.argv[2];
  const args = process.argv.slice(3);

  load();

  switch (action) {
    case 'summary':
      console.log(JSON.stringify(getProfileSummary(), null, 2));
      break;

    case 'preferences':
      console.log(JSON.stringify(getPreferences(), null, 2));
      break;

    case 'predict':
      console.log(JSON.stringify(predictNeeds(), null, 2));
      break;

    case 'name':
      if (args[0]) {
        updateBasic({ name: args[0] });
        console.log('✅ Name set:', args[0]);
      } else {
        console.log('Name:', userModel.basic.name);
      }
      break;

    case 'interest':
      if (args[0]) {
        recordInterest(args[0], parseFloat(args[1]) || 0.1);
        console.log('✅ Interest recorded:', args[0]);
      }
      break;

    case 'interact':
      recordInteraction(args[0] ? { task: args[0] } : {});
      console.log('✅ Interaction recorded');
      break;

    case 'concept':
      if (args[0]) {
        addKnownConcept(args[0]);
        console.log('✅ Concept added:', args[0]);
      } else {
        console.log('Known concepts:', userModel.knowledge.knownConcepts);
      }
      break;

    case 'expertise':
      if (args[0]) {
        addExpertiseArea(args[0]);
        console.log('✅ Expertise added:', args[0]);
      } else {
        console.log('Expertise areas:', userModel.knowledge.expertiseAreas);
      }
      break;

    case 'full':
      console.log(JSON.stringify(userModel, null, 2));
      break;

    default:
      console.log(`
用户建模模块

用法:
  node user_model.cjs summary              # 获取画像摘要
  node user_model.cjs preferences          # 获取偏好
  node user_model.cjs predict              # 预测用户需求
  node user_model.cjs name [name]          # 设置/查看名字
  node user_model.cjs interest [topic] [score]  # 记录兴趣
  node user_model.cjs interact [task]      # 记录交互
  node user_model.cjs concept [concept]    # 添加/查看已知概念
  node user_model.cjs expertise [area]     # 添加/查看专业领域
  node user_model.cjs full                 # 完整用户模型
      `);
  }
}

main();
