# Changelog

All notable changes to this project will be documented in this file.

## [1.5.0] - 2026-03-12

### Added - 补全所有缺失模块

**多模态处理 (multimodal.cjs)**
- 支持 5 种模态：文本、图片、音频、视频、文档
- 自动检测文件类型
- 图片 OCR 和音频转文字接口预留
- 多模态内容缓存和搜索

**性能监控 (monitoring.cjs)**
- 系统指标收集（CPU、内存、负载）
- 应用指标记录（响应时间、错误率）
- 阈值告警机制
- 健康状态检查
- 性能报告生成

**联想网络 (associate.cjs)**
- 概念节点和联想边管理
- 激活扩散算法
- 路径查找
- 联想强度调节
- 从数据库加载网络

**元认知反思 (reflect.cjs)**
- 5 种反思触发类型
- 失败/成功/纠正分析
- 洞察生成
- 建议推荐
- 定期反思

**遗忘模块 (forget.cjs)**
- 艾宾浩斯遗忘曲线
- 重要性分级保留
- 硬遗忘（删除）和软遗忘（衰减）
- 记忆强化
- 预览功能

### Changed
- 所有 SKILL.md 中列出的 23 个模块全部实现

## [1.4.0] - 2026-03-12

### Added - 新增 11 个核心模块

**工作记忆 (working_memory.cjs)**
- 管理短期活跃上下文
- 注意力焦点追踪
- 开放问题和待处理任务管理
- 自动衰减旧数据

**用户建模 (user_model.cjs)**
- 用户画像构建
- 偏好学习
- 行为模式分析
- 需求预测

**意图识别 (intent.cjs)**
- 10+ 种意图分类
- 槽位提取
- 优先级和情感推断

**决策引擎 (decision.cjs)**
- 多因素决策评估
- 规则引擎
- 历史成功率追踪

**错误恢复 (error_recovery.cjs)**
- 7 种错误类型分类
- 自动恢复策略
- 重试机制

**情感识别 (emotion.cjs)**
- 正面/负面/中性情感分析
- 15+ 种具体情绪识别
- 响应风格建议

**对话管理 (dialogue.cjs)**
- 多轮对话追踪
- 槽位管理
- 话题转换检测
- 待确认项管理

**预测模块 (prediction.cjs)**
- 基于时间/历史/上下文预测
- 序列模式检测
- 用户需求预测

**可解释性 (explainability.cjs)**
- 决策解释生成
- 记忆召回解释
- 自然语言报告

**冲突解决 (conflict_resolution.cjs)**
- 信息冲突检测
- 多种解决策略
- 用户确认机制

**主动学习 (active_learning.cjs)**
- 学习问题队列
- 按优先级排序
- 知识空白检测

**目标管理 (goal_management.cjs)**
- 目标创建和追踪
- 里程碑管理
- 进度报告

**上下文切换 (context_switching.cjs)**
- 上下文栈管理
- 多任务切换
- 状态保存恢复

**安全护栏 (safety.cjs)**
- 7 种危险模式检测
- 文件路径检查
- 操作审批机制

## [1.3.0] - 2026-03-12

### Added

**1. 健康检查 + 降级**
- `healthState` 模块，30 秒检查一次 PostgreSQL 状态
- PostgreSQL 不可用时自动降级到 `MEMORY.md` 文件存储
- 降级模式标记，避免频繁重试

**2. 动态关键词**
- `keywordState` 模块，每小时从用户历史消息提取高频词
- 自动合并基础关键词 + 动态关键词（最多 15 个）
- 持久化到 `.dynamic-keywords.json`

**3. 缓存分级优化**
- 按记忆重要性分级 TTL：
  - 高重要性 (≥0.8): 10 分钟
  - 中重要性 (0.5-0.8): 3 分钟
  - 低重要性 (<0.5): 1 分钟
- 避免频繁查库

**4. 错误重试机制**
- npm install 失败后最多重试 3 次
- 5 分钟冷却期后重置计数
- 成功后重置重试状态

**5. 性能监控**
- `perfLog` 模块记录查询耗时
- 超过 100ms 发出警告
- 保留最近 100 条记录

## [1.2.4] - 2026-03-12

### Added
- **Hook 自动安装依赖**: `handler.js` 会在 `pg` 缺失时自动执行 `npm install --production`
- 新增 `ensurePgDependency()` 函数，带并发保护和状态缓存

### Technical
- 使用 `execSync()` 执行 npm install，30 秒超时
- 防止多个 hook 调用同时触发安装（`isInstalling` 标志）
- 缓存已加载的 `pg` 模块，避免重复 require

## [1.2.3] - 2026-03-12

### Fixed
- **Hook 安装问题**: OpenClaw 不识别符号链接，改用 `fs.cpSync()` 复制 hook 文件
- `scripts/postinstall.cjs`: 从 `fs.symlinkSync()` 改为 `fs.cpSync()`

### Technical
- OpenClaw hook 发现机制不跟随符号链接，必须使用真实目录

## [1.2.2] - 2026-03-12

### Fixed
- **Hook 依赖加载**: `pg` 包找不到，改用 CommonJS + 从 skill node_modules 显式加载
- `hooks/cognitive-recall/handler.js`: CommonJS 版本，修复依赖路径

## [1.2.1] - 2026-03-12

### Fixed
- **多关键词搜索**: `recall.cjs` 支持空格分隔的多关键词 OR 搜索

## [1.2.0] - 2026-03-12

### Added
- **cognitive-recall hook**: OpenClaw 原生 hook，自动注入跨会话记忆上下文
- Hook 触发事件: `message:preprocessed`
- Hook 安装位置: `hooks/cognitive-recall/`

### Changed
- 更新 SKILL.md，添加 cognitive-recall hook 详细说明

## [1.1.0] - 2026-03-12

### Added
- 初始版本
- 四层记忆架构（感官、工作、情景、语义）
- PostgreSQL + pgvector 存储
- Redis 热数据缓存
- 联想网络
- 元认知反思
