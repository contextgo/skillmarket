const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');

// Cognitive Brain config
const HOME = process.env.HOME || '/root';
const SKILL_DIR = path.join(HOME, '.openclaw/workspace/skills/cognitive-brain');
const CONFIG_PATH = path.join(SKILL_DIR, 'config.json');
const MEMORY_PATH = path.join(HOME, '.openclaw/workspace/MEMORY.md');
const KEYWORDS_PATH = path.join(SKILL_DIR, '.dynamic-keywords.json');

// ============================================================================
// 1. 性能监控
// ============================================================================

const perfLog = {
  queries: [],
  maxEntries: 100,
  warnThreshold: 100, // ms

  record(operation, durationMs, success = true) {
    this.queries.push({
      operation,
      duration: durationMs,
      success,
      timestamp: Date.now()
    });

    // Keep only recent entries
    if (this.queries.length > this.maxEntries) {
      this.queries.shift();
    }

    // Warn if slow
    if (durationMs > this.warnThreshold) {
      console.warn(`[cognitive-recall] ⚠️ Slow query: ${operation} took ${durationMs}ms`);
    }
  },

  getStats() {
    if (this.queries.length === 0) return null;
    const durations = this.queries.map(q => q.duration);
    return {
      count: this.queries.length,
      avg: Math.round(durations.reduce((a, b) => a + b, 0) / durations.length),
      max: Math.max(...durations),
      min: Math.min(...durations)
    };
  }
};

// ============================================================================
// 2. 缓存优化 - 按重要性分级
// ============================================================================

const recallCache = new Map();

const CACHE_CONFIG = {
  high: { ttl: 10 * 60 * 1000 },    // 10 minutes (importance >= 0.8)
  medium: { ttl: 3 * 60 * 1000 },   // 3 minutes (importance 0.5-0.8)
  low: { ttl: 60 * 1000 },          // 1 minute (importance < 0.5)
  default: { ttl: 60 * 1000 }       // 1 minute (unknown)
};

function getCacheTTL(importance) {
  if (importance >= 0.8) return CACHE_CONFIG.high.ttl;
  if (importance >= 0.5) return CACHE_CONFIG.medium.ttl;
  return CACHE_CONFIG.low.ttl;
}

function getCacheEntry(key) {
  const entry = recallCache.get(key);
  if (!entry) return null;

  const now = Date.now();
  const maxTTL = Math.max(...Object.values(CACHE_CONFIG).map(c => c.ttl));

  // Use the stored TTL for this entry
  if (now - entry.timestamp > entry.ttl) {
    recallCache.delete(key);
    return null;
  }

  return entry.result;
}

function setCacheEntry(key, result, importance = 0.5) {
  const ttl = getCacheTTL(importance);
  recallCache.set(key, {
    result,
    timestamp: Date.now(),
    ttl
  });
}

// ============================================================================
// 3. 健康检查 + 降级
// ============================================================================

const healthState = {
  pgHealthy: null,
  lastCheck: 0,
  checkInterval: 30 * 1000, // 30 seconds
  fallbackMode: false,

  async check(pg, dbConfig) {
    const now = Date.now();

    // Skip if recently checked
    if (this.pgHealthy !== null && now - this.lastCheck < this.checkInterval) {
      return this.pgHealthy;
    }

    this.lastCheck = now;

    // Try a simple query
    let pool = null;
    try {
      const { Pool } = pg;
      pool = new Pool({
        host: dbConfig.host,
        port: dbConfig.port,
        database: dbConfig.database,
        user: dbConfig.user,
        password: dbConfig.password,
        connectionTimeoutMillis: 2000,
        query_timeout: 3000
      });

      await pool.query('SELECT 1');
      this.pgHealthy = true;
      this.fallbackMode = false;
      console.log('[cognitive-recall] ✅ PostgreSQL healthy');
      return true;
    } catch (err) {
      this.pgHealthy = false;
      this.fallbackMode = true;
      console.warn('[cognitive-recall] ⚠️ PostgreSQL unavailable, falling back to MEMORY.md');
      return false;
    } finally {
      if (pool) await pool.end().catch(() => {});
    }
  },

  async fallback(keywords, limit) {
    // Read from MEMORY.md
    try {
      if (!fs.existsSync(MEMORY_PATH)) {
        return [];
      }

      const content = fs.readFileSync(MEMORY_PATH, 'utf8');
      const lines = content.split('\n').filter(l => l.trim());

      // Simple keyword matching
      const matches = [];
      for (const line of lines) {
        if (line.startsWith('#') || line.startsWith('---')) continue;

        const matchCount = keywords.filter(kw =>
          line.toLowerCase().includes(kw.toLowerCase())
        ).length;

        if (matchCount > 0) {
          matches.push({
            summary: line.replace(/^[-*]\s*/, '').substring(0, 100),
            content: line,
            type: 'fallback',
            importance: matchCount / keywords.length,
            source: 'MEMORY.md'
          });
        }
      }

      return matches
        .sort((a, b) => b.importance - a.importance)
        .slice(0, limit);
    } catch (err) {
      console.error('[cognitive-recall] Fallback read error:', err.message);
      return [];
    }
  }
};

// ============================================================================
// 4. 动态关键词
// ============================================================================

const keywordState = {
  keywords: ['用户', 'master', '偏好', '重要', '项目'],
  lastUpdate: 0,
  updateInterval: 60 * 60 * 1000, // 1 hour

  load() {
    try {
      if (fs.existsSync(KEYWORDS_PATH)) {
        const data = JSON.parse(fs.readFileSync(KEYWORDS_PATH, 'utf8'));
        if (data.keywords && data.keywords.length > 0) {
          this.keywords = data.keywords;
          this.lastUpdate = data.lastUpdate || 0;
        }
      }
    } catch (err) {
      console.warn('[cognitive-recall] Failed to load keywords:', err.message);
    }
  },

  async update(pg, dbConfig) {
    const now = Date.now();
    if (now - this.lastUpdate < this.updateInterval) {
      return this.keywords;
    }

    let pool = null;
    try {
      const { Pool } = pg;
      pool = new Pool({
        host: dbConfig.host,
        port: dbConfig.port,
        database: dbConfig.database,
        user: dbConfig.user,
        password: dbConfig.password,
        connectionTimeoutMillis: 5000
      });

      // Extract high-frequency words from recent episodes
      const result = await pool.query(`
        SELECT summary, content
        FROM episodes
        WHERE timestamp > NOW() - INTERVAL '7 days'
        ORDER BY importance DESC
        LIMIT 100
      `);

      const wordFreq = new Map();

      for (const row of result.rows) {
        const text = `${row.summary} ${row.content || ''}`;
        // Extract Chinese words (2-4 chars) and English words
        const chineseWords = text.match(/[\u4e00-\u9fa5]{2,4}/g) || [];
        const englishWords = text.match(/[a-zA-Z]{3,}/gi) || [];

        for (const word of [...chineseWords, ...englishWords]) {
          wordFreq.set(word, (wordFreq.get(word) || 0) + 1);
        }
      }

      // Get top keywords (excluding common words)
      const stopWords = new Set(['的', '是', '在', '了', '和', '有', '不', '这', '我', '你', 'the', 'and', 'for', 'was', 'are', 'but', 'not']);

      const topKeywords = [...wordFreq.entries()]
        .filter(([word]) => !stopWords.has(word.toLowerCase()))
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([word]) => word);

      if (topKeywords.length > 0) {
        // Merge with base keywords
        const baseKeywords = ['用户', 'master', '偏好', '重要', '项目'];
        this.keywords = [...new Set([...baseKeywords, ...topKeywords])].slice(0, 15);
        this.lastUpdate = now;

        // Save to file
        fs.writeFileSync(KEYWORDS_PATH, JSON.stringify({
          keywords: this.keywords,
          lastUpdate: this.lastUpdate
        }, null, 2));

        console.log('[cognitive-recall] 📝 Updated keywords:', this.keywords.join(', '));
      }

      return this.keywords;
    } catch (err) {
      console.warn('[cognitive-recall] Failed to update keywords:', err.message);
      return this.keywords;
    } finally {
      if (pool) await pool.end().catch(() => {});
    }
  },

  getKeywords() {
    return this.keywords;
  }
};

// Initialize keywords on load
keywordState.load();

// ============================================================================
// 5. 错误重试机制
// ============================================================================

const retryState = {
  installAttempts: 0,
  maxAttempts: 3,
  cooldownMs: 5 * 60 * 1000, // 5 minutes
  lastAttempt: 0,

  shouldRetry() {
    const now = Date.now();

    // Reset attempts after cooldown
    if (now - this.lastAttempt > this.cooldownMs) {
      this.installAttempts = 0;
    }

    return this.installAttempts < this.maxAttempts;
  },

  recordAttempt() {
    this.installAttempts++;
    this.lastAttempt = Date.now();
  }
};

// ============================================================================
// 依赖自动安装（带重试）
// ============================================================================

let isInstalling = false;
let pgLoaded = false;
let pgModule = null;

function ensurePgDependency() {
  if (pgLoaded && pgModule) {
    return pgModule;
  }

  // Try to load pg
  try {
    pgModule = require(path.join(SKILL_DIR, 'node_modules/pg'));
    pgLoaded = true;
    return pgModule;
  } catch (e) {
    if (isInstalling) {
      console.log('[cognitive-recall] npm install already in progress');
      return null;
    }

    // Check retry limit
    if (!retryState.shouldRetry()) {
      console.warn('[cognitive-recall] ⚠️ Max install attempts reached, waiting for cooldown');
      return null;
    }

    console.log('[cognitive-recall] pg not found, auto-installing...');
    isInstalling = true;
    retryState.recordAttempt();

    try {
      const startTime = Date.now();

      execSync('npm install --production', {
        cwd: SKILL_DIR,
        timeout: 30000,
        stdio: ['pipe', 'pipe', 'pipe']
      });

      const duration = Date.now() - startTime;
      perfLog.record('npm-install', duration);
      console.log(`[cognitive-recall] ✅ npm install completed in ${duration}ms`);

      // Reset retry state on success
      retryState.installAttempts = 0;

      // Try loading again
      pgModule = require(path.join(SKILL_DIR, 'node_modules/pg'));
      pgLoaded = true;
      return pgModule;
    } catch (installErr) {
      console.error('[cognitive-recall] ❌ Auto-install failed:', installErr.message);
      perfLog.record('npm-install', 0, false);
      return null;
    } finally {
      isInstalling = false;
    }
  }
}

// ============================================================================
// 主查询逻辑
// ============================================================================

async function recallFromDB(queries, limit = 3) {
  const startTime = Date.now();

  // Check cache
  const cacheKey = queries.join('|');
  const cached = getCacheEntry(cacheKey);
  if (cached) {
    perfLog.record('cache-hit', Date.now() - startTime);
    return cached;
  }

  // Load pg (with auto-install)
  const pg = ensurePgDependency();
  if (!pg) {
    console.error('[cognitive-recall] pg module unavailable');
    return healthState.fallback(queries, limit);
  }

  // Check config
  if (!fs.existsSync(CONFIG_PATH)) {
    console.log('[cognitive-recall] Config not found');
    return [];
  }

  const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  const dbConfig = config.storage.primary;

  // Health check
  const isHealthy = await healthState.check(pg, dbConfig);

  if (!isHealthy) {
    // Fallback to MEMORY.md
    const result = await healthState.fallback(queries, limit);
    perfLog.record('fallback-query', Date.now() - startTime);
    return result;
  }

  // Update dynamic keywords (async, don't wait)
  keywordState.update(pg, dbConfig).catch(() => {});

  let pool = null;
  try {
    const { Pool } = pg;
    pool = new Pool({
      host: dbConfig.host,
      port: dbConfig.port,
      database: dbConfig.database,
      user: dbConfig.user,
      password: dbConfig.password,
      connectionTimeoutMillis: 3000,
      query_timeout: 5000
    });

    // Build OR conditions for multiple keywords
    const conditions = queries.map((q, i) => `(summary ILIKE $${i + 1} OR content ILIKE $${i + 1})`).join(' OR ');
    const params = queries.map(q => `%${q}%`);
    params.push(limit.toString());

    const result = await pool.query(`
      SELECT id, summary, content, type, importance, timestamp
      FROM episodes
      WHERE ${conditions}
      ORDER BY importance DESC, timestamp DESC
      LIMIT $${params.length}
    `, params);

    const memories = result.rows;

    // Cache result with importance-based TTL
    if (memories.length > 0) {
      const maxImportance = Math.max(...memories.map(m => m.importance || 0.5));
      setCacheEntry(cacheKey, memories, maxImportance);
    }

    perfLog.record('db-query', Date.now() - startTime);
    return memories;
  } catch (err) {
    console.error('[cognitive-recall] DB error:', err.message || String(err));
    perfLog.record('db-query', Date.now() - startTime, false);

    // Fallback on error
    return healthState.fallback(queries, limit);
  } finally {
    if (pool) {
      await pool.end().catch(() => {});
    }
  }
}

// ============================================================================
// Hook handler
// ============================================================================

const handler = async (event) => {
  // Only handle preprocessed messages
  if (event.type !== 'message' || event.action !== 'preprocessed') {
    return;
  }

  // Skip if no context
  if (!event.context) {
    return;
  }

  // Only recall for direct messages (not groups)
  if (event.context.isGroup || event.context.groupId) {
    return;
  }

  // Skip if bodyForAgent is empty
  if (!event.context.bodyForAgent) {
    return;
  }

  // Get dynamic keywords
  const keywords = keywordState.getKeywords();

  try {
    const memories = await recallFromDB(keywords, 5);

    if (memories && memories.length > 0) {
      // Format memory context
      const memoryLines = memories.map(m => {
        const source = m.source ? ` (${m.source})` : '';
        return `  - ${m.summary}${source}`;
      });
      const memoryContext = `\n\n[🧠 Memory Context]\n${memoryLines.join('\n')}\n[/Memory Context]\n`;

      // Inject into bodyForAgent
      event.context.bodyForAgent = memoryContext + event.context.bodyForAgent;

      console.log('[cognitive-recall] Injected', memories.length, 'memories into context');
    }
  } catch (err) {
    console.error('[cognitive-recall] Error:', err.message || String(err));
  }
};

module.exports = handler;
