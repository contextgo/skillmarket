---
name: "feature-change-workflow"
description: "Executes complete feature change workflow including requirement analysis, documentation update, test design, coding, automated testing, and iterative fixes. Invoke when user requests feature changes, new functionality, or system logic updates."
---

# Feature Change Workflow

## Skill Overview

This skill automatically executes a standardized workflow for every system functionality change, ensuring a complete closed loop of requirement analysis, documentation updates, test design, coding implementation, automated testing, and lessons learned.

## Trigger Conditions

**Scenarios where this skill MUST be invoked:**

1. User proposes new feature requirements
2. User requests modifications to existing features
3. User proposes system logic changes
4. User mentions keywords like "add", "modify", "update", "refactor" for feature changes
5. User explicitly requests functional changes

## Execution Workflow

### Step 1: Requirement Analysis

**Goal**: Deeply understand user requirements, perform equivalence class partitioning and boundary value analysis

**Actions:**

```python
# 1.1 Read user requirements
- Carefully analyze user's feature change requests
- Identify key functional points and business logic

# 1.2 Requirement Analysis Methods
- Equivalence class partitioning: Identify valid/invalid inputs
- Boundary value analysis: Determine boundary conditions
- Scenario method: Sort out business processes
- Decision table method: Analyze complex business rules

# 1.3 Output Requirement Analysis Document
- Feature point list
- Business rules
- Data format requirements
- User interaction flow
```

**Checklist:**

- Understand the core objectives of user requirements
- Identify all feature points
- Clarify data formats and validation rules
- Sort out user interaction flow
- Identify boundary cases and exception handling

### Step 2: Update Documentation

**Goal**: Keep documentation synchronized with requirements

**Actions:**

```python
# 2.1 Update Requirement Documents
- Locate project's requirement documentation (e.g., docs/prd/, docs/requirements/)
- Update feature description sections
- Add new business rules
- Update data format specifications
- Supplement user interaction flow

# 2.2 Update Prototypes/Mockups (if applicable)
- Locate project's prototype files
- Update UI layouts
- Add new interactive elements
- Adjust page flow

# 2.3 Document Version Management
- Update document version numbers
- Add changelog entries
- Record change date and author
```

**Checklist:**

- Requirement documents updated
- Prototypes updated (if applicable)
- Version numbers incremented
- Changelog recorded
- Documentation style consistent

### Step 3: Test Design and Case Writing

**Goal**: Design complete test solutions and automated test cases based on updated requirements

**Actions:**

```python
# 3.1 Test Solution Design
- Determine test scope (API + UI)
- Design test data strategy
- Plan test priorities (P0/P1/P2)

# 3.2 API Test Cases
- Locate project's API test directory (e.g., tests/api/, test/api_tests/)
- Add/update test files for corresponding functional modules
- Add database validation logic
- Implement white-box testing

# 3.3 UI Test Cases
- Locate project's UI test directory (e.g., tests/ui/, test/ui_tests/)
- Add/update test files for corresponding pages
- Use robust selector strategies
- Add conditional assertions

# 3.4 Test Data Preparation
- Create test data factory methods
- Implement pre-test data preparation fixtures
- Implement post-test cleanup mechanisms
```

**Checklist:**

- API test cases written
- UI test cases written
- Database validation added
- Test data management implemented
- Test priorities marked

### Step 4: Coding and Self-Testing

**Goal**: Implement features according to requirements and design specifications, and perform self-testing

**Actions:**

```python
# 4.1 Backend Implementation
- Locate project's backend code directory (e.g., app/, src/, backend/)
- Implement/update API endpoints
- Add data validation logic
- Implement business logic
- Add database operations

# 4.2 Frontend Implementation
- Locate project's frontend code directory (e.g., web/, frontend/, src/)
- Implement/update components
- Add form validation
- Implement user interactions

# 4.3 Self-Testing
- Manually test basic functionality
- Verify boundary cases
- Check error handling
- Confirm UI interactions work properly
```

**Checklist:**

- Backend code implemented
- Frontend code implemented
- Code follows project conventions
- Self-testing passed
- No obvious bugs

### Step 5: Execute Automated Tests

**Goal**: Run automated tests to verify functional correctness and identify issues

**Actions:**

```python
# 5.1 Run Related Tests
# Run tests for affected modules
pytest <test_directory>/<affected_module>.py -v

# 5.2 Analyze Test Results
- Statistics on pass rate
- Categorize failed tests (ERROR vs FAILED)
- Identify priority issues
```

**Checklist:**

- Related tests executed
- Test results analyzed
- Issues categorized and recorded

### Step 6: Fix Issues and Iterate

**Goal**: Fix all issues exposed by automated testing, loop testing until perfect

**Actions:**

```python
# 6.1 Issue Fix Strategy
- Prioritize fixing ERRORs (blocking issues)
- Categorize and handle FAILED tests
- Fix P0 priority issues first

# 6.2 Iterative Fix Loop
while test pass rate < 100%:
    1. Analyze failed tests
    2. Locate root cause
    3. Implement fix
    4. Re-run tests
    5. Verify fix effectiveness

# 6.3 Fix Verification
- Ensure fixes don't introduce new issues
- Regression test related functionality
- Confirm all tests pass
```

**Checklist:**

- ERRORs all fixed
- P0 tests all passed
- P1 tests all passed
- P2 tests all passed
- No regression issues

### Step 7: Summarize Experience

**Goal**: Summarize lessons learned from this feature change and record to learning system

**Actions:**

```python
# 7.1 Record Learning Points
- Locate project's learning records (e.g., .learnings/, docs/learnings/)
- Record encountered issues
- Record solutions
- Record best practices
- Add Pattern-Key

# 7.2 Promote to Project Documentation
- If experience is widely applicable, promote to project guidelines
- Update testing best practices
- Add new workflow guidelines

# 7.3 Generate Summary Report
- Statistics on changes
- Record test pass rate changes
- List key fixes
- Propose next steps
```

**Checklist:**

- Learning points recorded
- Experience promoted (if applicable)
- Summary report generated
- Git commit completed

## Output Artifacts

### Required Outputs

1. ✅ Updated requirement documents
2. ✅ Updated prototypes/mockups (if applicable)
3. ✅ Test cases (API and UI tests)
4. ✅ Implementation code
5. ✅ Learning records
6. ✅ Test report

### Optional Outputs

- Test data factory methods updates
- Test fixtures updates
- Configuration file updates

## Quality Standards

### Code Quality

- ✅ Follows project code conventions
- ✅ No obvious bugs
- ✅ Complete error handling
- ✅ Clear code comments

### Test Quality

- ✅ API test coverage appropriate
- ✅ UI tests cover core functionality
- ✅ Includes database validation
- ✅ Includes boundary testing
- ✅ 100% test pass rate

### Documentation Quality

- ✅ Complete requirement documents
- ✅ Accurate prototypes
- ✅ Detailed test documentation
- ✅ Clear learning records

## Execution Example

### Example: Data Import Feature Enhancement

**User Request:**

> Data import supports two types: business line data import and combined data import, with tabs in the interface

**Skill Execution:**

1. **Requirement Analysis**
   - Identify two functional modules: business line data import, combined data import
   - Analyze business rules: business line selection, file format validation, import process
   - Sort out user interactions: tab switching, file upload, preview confirmation, redirect logic

2. **Documentation Update**
   - Update requirement docs to add combined data import requirements
   - Update prototypes to add tab interface design

3. **Test Design**
   - API tests: Add combined data import tests
   - UI tests: Add tab switching tests
   - Database validation: Check data imports correctly

4. **Coding Implementation**
   - Backend: Add new API endpoint
   - Frontend: Update component to add tab component

5. **Automated Testing**
   - Run related tests
   - Analyze failed tests
   - Fix issues

6. **Iterative Fixing**
   - Fix selector issues
   - Fix data validation issues
   - Until 100% pass rate

7. **Experience Summary**
   - Record tab component implementation experience
   - Record multi-type file handling experience
   - Promote to project guidelines

## Important Notes

### Principles That Must Be Followed

1. **Documentation First**: Update documentation before coding
2. **Test-Driven**: Write tests before implementing features
3. **Iterative Improvement**: Don't pursue perfection at once, but continuously improve
4. **Record Experience**: Leave learning records for every change
5. **Git Commit**: Must commit after completing changes
6. **Steps Cannot Be Skipped**: Must execute all 7 steps in order, strictly prohibited from skipping any step
7. **Automated Testing Must Be Executed**: Steps 5 and 6 must be fully executed, not allowed to skip

### Prohibited Behaviors

❌ Skip requirement analysis and code directly
❌ Implement features without updating documentation
❌ Submit code without writing tests
❌ Stop when tests don't pass
❌ End without recording experience
❌ **Skip Step 5 (Automated Testing)**
❌ **Skip Step 6 (Fix Issues and Iterate)**
❌ **Skip any step for any reason**

### Special Requirements for Steps 5 and 6

**Step 5: Execute Automated Testing (Must Execute)**

- ✅ Must run tests within the scope of changes
- ✅ Must analyze and record test results
- ✅ Must statistics pass rate and failure classification
- ❌ Not allowed to skip or simplify

**Step 6: Fix Issues and Iterate (Must Execute)**

- ✅ Must fix all ERRORs
- ✅ Must fix all P0 tests
- ✅ Must loop test until 100% pass rate
- ✅ Must verify no regression issues
- ❌ Not allowed to skip or end early

### Time Management

- Requirement Analysis: 10-15 minutes
- Documentation Update: 15-20 minutes
- Test Design: 20-30 minutes
- Coding: 30-60 minutes
- Test Fixing: 30-60 minutes
- Experience Summary: 10-15 minutes

**Total**: Approximately 2-3 hours (adjust based on complexity)

## Related Skills

- `self-improvement` - Record learning points and experience
- `testing-workflow` - Testing workflow
- `prd-fullstack` - PRD document writing

## Version History

| Version | Date       | Change Description                    |
| :------ | :--------- | :------------------------------------ |
| v1.1    | 2026-04-27 | Generalized version for community sharing |
| v1.0    | 2026-04-27 | Initial version, created complete workflow |

---

**Skill Status**: ✅ Active  
**Last Updated**: 2026-04-27  
**Author**: AiShan  
**Maintainer**: Community
