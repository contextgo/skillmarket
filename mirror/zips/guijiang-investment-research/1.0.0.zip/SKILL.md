---
name: guijiang-distress-reversal-deep-research
description: 困境反转个股深度研究框架。当用户要求"研究困境反转个股"、"分析困境股票"、"深度反转分析"、"归江困境反转框架"、"研究遭人厌恶的股票"、"反转催化剂分析"、"为什么市场是错的"等主题时使用本技能。触发词：困境反转、困境股票研究、反转深度分析、归江反转框架、遭人厌恶的股票、周期底部反转、均值回归研究、错杀股研究、困境反转报告。
---

# 归江价值精选 · 困境反转个股深度研究技能

## Overview

本技能提供一套系统化的困境反转（Turnaround / Distressed Investment）研究框架，根植于归江价值投资思想与《价值投资：从格雷厄姆到巴菲特（第2版）》的核心逻辑。核心理念是：**在市场最恐惧时寻找错误定价，在短暂困境中识别永久性伤害与暂时性挫折的区别，最终回答："为什么市场是错的？为什么你能成为交易中正确的一方？"**

每次调用必须：
1. 获取计算机当前最新系统时间（不得硬编码）
2. 获取目标公司的实时市场数据
3. 按五步框架执行深度研究
4. 生成专业 HTML 报告并发送邮件至 `hncjit@qq.com`

---

## 执行前准备

### 获取当前系统时间（强制要求）

```powershell
# Windows PowerShell
Get-Date -Format "yyyy年MM月dd日 HH:mm"
```

所有报告标题、数据时效说明必须使用上述命令获取的实际时间填充。

### 明确研究标的

用户必须提供待研究的标的名称或股票代码（A/港/美股均可）。格式示例：
- `研究 中国恒大 03333.HK`
- `分析 某ST公司`
- `深度研究 [股票代码]`

若用户未指定标的，本技能可结合当前市场数据，自主扫描并推荐最符合条件的困境反转候选标的。

---

## 五步深度研究框架

### 第一步：定义"困境"与识别"过度反应"

#### 1.1 困境表征描述

客观、量化地描述公司当前面临的核心困境：

**困境类型分类（请在分析中标注类型）：**
- 【业绩型】连续多年业绩下滑或亏损（如营收/净利润持续负增长）
- 【产能型】行业产能过剩，全行业亏损或价格战
- 【诉讼型】重大诉讼、监管处罚、违规事件
- 【债务型】资产负债表危机（高负债率、流动性紧张）
- 【管理层型】核心管理层丑闻、离职、战略失误
- 【产品型】主力产品被淘汰、技术路线失败
- 【宏观型】行业遭遇系统性政策打压或需求萎缩

**量化困境程度：**
- 股价从高点最大回撤：___%（标注：轻度<30% / 中度30-60% / 重度>60%）
- 连续亏损年限：___年
- 当前市值相对净资产折让：PB = __（破净程度）
- 当前股息率是否异常（高到不可持续）：是/否，数值___%

#### 1.2 市场情绪判断

**主流叙事分析：**
- 券商研报覆盖情况：___篇（无人问津 / 少量关注 / 正常覆盖）
- 最近一篇研报时间：___（标注：已超过12个月=严重忽视）
- 媒体与公众讨论情绪：极度悲观 / 忽视 / 混合

**市场共识定价是否过度？**
核心问题：当前股价是否已经将"最坏情景"折现？如果是，那么任何好于最坏情景的事件都会驱动股价上涨。

#### 1.3 股价长期表现验证

- 股价是否长期（如2-3年）大幅跑输大盘和行业？
- 是否创出多年新低？
- 是否有"不受欢迎"和"令人失望"的典型特征（归江思想核心）？

**结论标注：**
市场过度悲观信号：✅ 确认存在 / ❌ 信号不明显

---

### 第二步：深挖困境根源——区分"周期性"与"永久性"损伤

#### 2.1 行业周期位置判断

**核心判断工具——ROE微笑曲线：**
- 绘制公司所在行业的ROE微笑曲线草图
- 标注当前行业ROE在曲线中的位置（周期底部 / 左侧下行 / 右侧回升）

**产能周期判断：**
- 行业资本开支历史：当前是产能出清阶段还是扩张末期？
- 落后产能在行业总产能中占比：___%（>30%为重要警示）
- 头部企业是否有主动限产动作：是/否

**"永久性衰退"排除清单（关键否决项）：**
- [ ] 核心产品是否面临不可逆的技术替代？（例：功能手机→智能手机）
- [ ] 核心护城河是否已被彻底侵蚀？
- [ ] 管理层是否普遍丧失经营意愿？
- [ ] 监管环境是否已结构性恶化，不可逆转？

若以上任意一项为"是"，困境可能是永久性的，研究需谨慎继续。

#### 2.2 困境归因——外部 vs 内部

**外部主导型（较易反转）：**
- 行业周期性下行（商品价格战、宏观经济衰退）
- 一次性巨额计提（会计准则变更、一次性商誉减值）
- 政策性的短期打压（医药集采、教培行业整治等已出清的阶段）
- 突发公共卫生事件影响

**内部主导型（难度较高）：**
- 战略失误（盲目多元化、错误赛道押注）
- 治理问题（掏空、大股东资金占用）
- 核心管理层能力不足

**分析结论：**
困境归因：□ 外部主导  □ 内部主导  □ 混合
反转难度：□ 较低（1-2年） □ 中等（2-3年） □ 较高（3年以上）

#### 2.3 资产负债表深度诊断（关键步骤）

**资产端隐蔽价值扫描：**
- 是否有被市场忽视的隐蔽资产？（土地增值、探矿权、商标品牌、子公司股权）
- 隐蔽资产评估：按市价重估 vs 账面价值，差距___亿元
- 资产清算价值 vs 当前市值：当前市值___亿元，清算价值约___亿元（折溢价___%）

**负债端结构分析：**
- 有息负债总额：___亿元，占总资产比例：___%
- 债务到期结构：未来1年内到期___亿元，现有货币资金___亿元
- 债务重组可能性评估：已启动 / 有意向 / 无信号 / 破产清算路径
- 债转股进展（如适用）：是否已有债转股方案或债权人谈判进展

**格雷厄姆"净净资产"计算（保守安全边际）：**
```
净净资产（Net-Net）= 流动资产 - 全部负债（含表外）
调整后净资产 = 总资产 - 全部负债（含表外）
当前市值 vs 净净资产：市值□高于/□低于净净资产
```

---

### 第三步：寻找"反转"的催化剂与必要条件

#### 3.1 内部催化剂

**资产重组信号：**
- 是否计划/已执行出售非核心或亏损业务？（聚焦主业=积极信号）
- 资产剥离对利润/负债率的改善预期：___

**管理层变更：**
- 是否有新管理层的引入计划或已到位？
- 新管理层历史记录：此前有无成功扭转困境企业的案例？

**成本削减验证：**
- 降本增效计划是否已公告？
- 预计每年节约成本：___亿元，时间节点：___

**资本结构优化：**
- 再融资计划：定增/配股/引入战投
- 债务重组进展：与主要债权人的谈判状态

#### 3.2 外部催化剂

**行业供需改善信号：**
- 产品价格是否已出现企稳或反弹迹象？（具体数据：___）
- 落后产能是否开始实质性退出？（退出规模___%）
- 行业库存周期：是否进入主动去库存末端？

**政策/监管变化：**
- 不利政策是否已出清？（如集采降价幅度趋于缓和）
- 是否有新的支持性政策出台？

**新需求/新技术应用：**
- 公司现有资产或技术是否可能应用于新兴领域？（例：钾肥→锂电需求下的价值重估）
- 新应用场景的收入贡献预期：___

#### 3.3 生存能力验证（前置条件）

**在反转发生前，公司能否存活？**

- 经营现金流（TTM）：___亿元
- 现金及等价物：___亿元
- 未来12个月刚性现金支出：___亿元
- 现金消耗速率：___个月耗尽 / ✅ 现金足够撑过反转预期窗口

**融资能力评估：**
- 银行授信未用额度：___亿元
- 母公司/关联方支持意愿：是/否/未知

**生存能力结论：**
- ✅ 生存概率高（可等待反转）
- ⚠️ 存在流动性风险（需紧密跟踪）
- ❌ 生存概率低（破产风险高，应降低仓位上限或排除）

---

### 第四步：估值与安全边际——"破产清算"视角评估下限

#### 4.1 绝对估值下限

**清算价值法（极度保守）：**
- 有形资产清算价值：___亿元（按快速变现折扣估算）
- 无形资产（品牌/专利/牌照）：___亿元（主观估算，需保守）
- 优先偿还债务后的清算净值：___亿元
- 破产清算情景下每股清算价值：___元

**重置成本法：**
- 重置成本 vs 当前市值：当前市值___亿元，重置成本约___亿元
- 重置成本溢价/折让：___%（折让>50%为强安全边际信号）

#### 4.2 相对估值与历史比较

| 估值指标 | 当前值 | 历史极限低位 | 历史分位 | 行业均值 |
|---------|--------|------------|---------|---------|
| PB |  |  |  |  |
| PS |  |  |  |  |
| 股息率 |  |  |  |  |

- 当前PB处于历史___%分位（<10%=极度低估信号）
- 相对行业平均PB折让：___%（>30%=显著折价）

#### 4.3 破产概率 vs 上涨空间的"不对称性"分析

**核心公式：**
```
期望值 = (上涨概率 × 上涨空间) - (下跌概率 × 下跌空间)

上涨情景：反转成功 → 目标价___元，潜在涨幅___%
下跌情景：反转失败 → 清算价值___元，潜在跌幅___%
幸存者概率（参考历史研究）：约1/3公司会破产，幸存者回报极高
```

**市场隐含的破产概率定价：**
- 若当前市值接近清算价值：市场定价已隐含极高破产概率
- 若股价仍高于清算价值30%+：市场定价可能低估了反转概率

---

### 第五步：风险管理与最终决策框架

#### 5.1 主要风险矩阵

| 风险类型 | 具体风险描述 | 概率 | 影响程度 | 应对预案 |
|---------|------------|------|---------|---------|
| 行业风险 | 行业继续恶化 | 中/低 | 高 | 止损线 |
| 催化剂失效 | 反转逻辑未兑现 | 中 | 高 | 持有期限 |
| 流动性风险 | 资金链断裂 | 低/中 | 致命 | 仓位上限 |
| 管理层风险 | 无力扭转局面 | 中 | 高 | 跟踪信号 |
| 政策风险 | 再度收紧 | 低 | 中 | 政策监测 |

#### 5.2 仓位管理建议

- 单一个股仓位上限：___%（建议不超过组合5-10%）
- 建仓方式：分批建仓（首仓30%，回调再加30%，确认再加40%）
- 止损线设置：跌破___元（约___%回撤）触发止损

#### 5.3 时间预期

- 困境反转典型时间周期：2-3年（请标注预期时间：___年）
- 公募基金短期考核风险：该公司是否可能因短期业绩压力被迫在反转前卖出？
- 投资者耐心资本属性评估：适合长期（>3年）/ 中期（1-3年）/ 短期（<1年）

---

## 最终决策框架（核心问题）

### 问题一：为什么市场是错的？

市场共识中忽略或过度悲观的关键点：
- [ ] 市场低估了______的资产价值
- [ ] 市场高估了困境的______（永久性/持续性）
- [ ] 市场忽视了______催化剂的即将到来
- [ ] 估值已隐含过高的______（破产概率/行业衰退）

### 问题二：为什么你能成为交易中正确的一方？

认知优势来源：
- [ ] 对行业周期的深刻理解：具体说明___
- [ ] 对资产负债表的细致分析：发现了___
- [ ] 对催化剂的紧密跟踪：已观察到___
- [ ] "对人性贪婪和恐慌的免疫"（归江核心）：___
- [ ] 其他认知优势：___

---

## 研究报告输出规范

### 强制输出要求

每次研究完成后，**必须生成专业 HTML 报告**并以邮件正文方式发送至 `hncjit@qq.com`。

### HTML 报告设计规范

**整体风格：**
- 背景色：`#f8fafc`（极浅灰蓝，专业沉稳）
- 正文字体：`Microsoft YaHei, "PingFang SC", SimSun, sans-serif`
- 容器最大宽度：900px，居中，内边距 32px
- 卡片式布局：白色背景 + 1px边框 + 轻阴影

**配色体系：**
- 主色：`#1e3a5f`（深海蓝，沉稳专业）
- 强调色：`#c9a84c`（金色，核心数据突出）
- 正向（买入/反转信号）：`#d1fae5` 背景 + `#065f46` 文字
- 警示（风险/困难）：`#fee2e2` 背景 + `#991b1b` 文字
- 中性（观察）：`#fef9c3` 背景 + `#713f12` 文字
- 数值标注：`#2563eb`（蓝色高亮）

**标题层次：**
- 报告主标题：深蓝 `#1e3a5f`，28px，加粗，底部金色 3px 边框
- 章节标题：`#1e3a5f`，18px，左侧 4px 金色竖线
- 小节标题：`#334155`，15px，加粗

**关键数据展示：**
- 核心指标卡片：白底 + 左 4px 主色边框
- 买入区间/评级：用金色大字体显示（如 `评级：高度关注`）
- 股价/估值：用蓝色加粗数字

**表格样式：**
- 表头：`#1e3a5f` 背景，白色文字，16px
- 奇偶行交替：`#f1f5f9` / `#ffffff`
- 关键行（如当前值）：左侧加亮条
- 单元格内数字：右对齐；文字：左对齐

**邮件兼容性：**
- 避免 `position:fixed`、复杂 CSS Grid
- 使用 `<table>` 做整体布局（邮件兼容性最优）
- 内联所有 CSS（`style="..."`）
- 重要数字用 `<strong>` 或 `<span style="color:#2563eb">` 高亮
- 段落间距充足，行高 1.8

### HTML 报告结构模板

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>归江价值精选 · 困境反转深度研究报告 · [公司名称] · [当前日期]</title>
<style>
  /* 全部内联样式，确保邮件客户端兼容 */
  body { margin:0; padding:0; background:#f0f4f8; font-family:'Microsoft YaHei','PingFang SC','SimSun',sans-serif; color:#1e293b; }
  .container { max-width:920px; margin:20px auto; background:#fff; border-radius:12px; overflow:hidden; box-shadow:0 4px 24px rgba(30,58,95,0.10); }
  .header { background:linear-gradient(135deg,#1e3a5f 0%,#2d5a87 100%); padding:28px 36px; color:#fff; }
  .report-title { font-size:26px; font-weight:bold; margin:0 0 8px; letter-spacing:1px; }
  .report-subtitle { font-size:14px; opacity:0.85; }
  .rating-bar { display:inline-block; margin-top:14px; padding:6px 20px; border-radius:20px; font-size:15px; font-weight:bold; }
  .rating-buy { background:#c9a84c; color:#fff; }
  .rating-watch { background:#94a3b8; color:#fff; }
  .rating-exclude { background:#ef4444; color:#fff; }
  .section { padding:24px 36px; border-bottom:1px solid #e2e8f0; }
  .section:last-child { border-bottom:none; }
  .section-title { font-size:17px; font-weight:bold; color:#1e3a5f; border-left:5px solid #c9a84c; padding-left:14px; margin:0 0 16px; line-height:1.4; }
  .card { background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:16px 20px; margin-bottom:14px; }
  .card:last-child { margin-bottom:0; }
  .card-title { font-size:14px; font-weight:bold; color:#1e3a5f; margin:0 0 10px; }
  .card-green { background:#f0fdf4; border-color:#86efac; }
  .card-yellow { background:#fefce8; border-color:#fde047; }
  .card-red { background:#fef2f2; border-color:#fca5a5; }
  .tag { display:inline-block; padding:2px 10px; border-radius:12px; font-size:12px; font-weight:bold; }
  .tag-green { background:#d1fae5; color:#065f46; }
  .tag-yellow { background:#fef9c3; color:#713f12; }
  .tag-red { background:#fee2e2; color:#991b1b; }
  .tag-blue { background:#dbeafe; color:#1e40af; }
  .metric-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin-top:12px; }
  .metric-box { background:#fff; border:1px solid #cbd5e1; border-radius:8px; padding:12px 16px; }
  .metric-label { font-size:12px; color:#64748b; margin-bottom:4px; }
  .metric-value { font-size:20px; font-weight:bold; color:#1e3a5f; }
  .metric-sub { font-size:11px; color:#94a3b8; margin-top:2px; }
  table { width:100%; border-collapse:collapse; margin:12px 0; font-size:13px; }
  th { background:#1e3a5f; color:#fff; padding:10px 14px; text-align:left; font-size:13px; }
  td { padding:9px 14px; border-bottom:1px solid #e2e8f0; }
  tr:nth-child(even) td { background:#f8fafc; }
  tr:hover td { background:#f1f5f9; }
  .highlight-row td { background:#fffbeb !important; border-left:4px solid #c9a84c; }
  .num { text-align:right; font-variant-numeric:tabular-nums; color:#2563eb; font-weight:bold; }
  .conclusion-box { background:linear-gradient(135deg,#f0fdf4 0%,#dcfce7 100%); border:2px solid #22c55e; border-radius:10px; padding:20px 24px; margin-top:16px; }
  .conclusion-title { font-size:15px; font-weight:bold; color:#065f46; margin-bottom:8px; }
  .conclusion-text { font-size:14px; color:#1e3a5f; line-height:1.8; }
  .risk-box { background:#fef2f2; border:1px solid #fca5a5; border-radius:8px; padding:14px 18px; margin-top:10px; }
  .risk-title { font-size:13px; font-weight:bold; color:#991b1b; margin-bottom:6px; }
  .footer { padding:16px 36px; background:#f8fafc; border-top:1px solid #e2e8f0; font-size:12px; color:#64748b; text-align:center; }
</style>
</head>
<body>
<div class="container">
  <!-- 报告头部 -->
  <div class="header">
    <div class="report-title">归江价值精选 · 困境反转深度研究报告</div>
    <div class="report-subtitle">[公司名称] · [股票代码] · 报告日期：[当前系统时间]</div>
    <div class="rating-bar rating-buy">综合评级：高度关注</div>
  </div>

  <!-- 执行摘要 -->
  <div class="section">
    <div class="section-title">执行摘要</div>
    <div class="conclusion-box">
      <div class="conclusion-title">研究结论</div>
      <div class="conclusion-text">[在此填写核心研究结论，2-3句话概括困境本质、反转路径和评级]</div>
    </div>
    <div class="metric-grid" style="margin-top:16px;">
      <div class="metric-box">
        <div class="metric-label">当前股价</div>
        <div class="metric-value">¥[ ]</div>
        <div class="metric-sub">市值：[ ]亿元</div>
      </div>
      <div class="metric-box">
        <div class="metric-label">市净率（PB）</div>
        <div class="metric-value">[ ]x</div>
        <div class="metric-sub">历史分位：[ ]%</div>
      </div>
      <div class="metric-box">
        <div class="metric-label">股价高点回撤</div>
        <div class="metric-value">[ ]%</div>
        <div class="metric-sub">困境类型：[ ]</div>
      </div>
      <div class="metric-box">
        <div class="metric-label">反转概率评估</div>
        <div class="metric-value">[ ]%</div>
        <div class="metric-sub">预期时间：[ ]年</div>
      </div>
    </div>
  </div>

  <!-- 第一步：困境识别 -->
  <div class="section">
    <div class="section-title">第一步：困境识别与过度反应验证</div>
    <div class="card">
      <div class="card-title">困境表征</div>
      <p>[描述核心困境，量化困境程度]</p>
    </div>
    <div class="card">
      <div class="card-title">市场情绪判断</div>
      <p>[市场共识是否过度悲观？列举券商覆盖/媒体情绪/持仓数据]</p>
    </div>
    <div class="card card-yellow">
      <div class="card-title">过度反应验证</div>
      <p>市场过度悲观信号：✅ 确认存在 / ❌ 信号不明显</p>
      <p>[详细说明]</p>
    </div>
  </div>

  <!-- 第二步：根源分析 -->
  <div class="section">
    <div class="section-title">第二步：困境根源——周期性 vs 永久性损伤</div>
    <div class="card">
      <div class="card-title">行业周期位置</div>
      <p>[ROE微笑曲线判断，产能周期阶段，是否为产能出清末期]</p>
    </div>
    <div class="card">
      <div class="card-title">困境归因分析</div>
      <p>困境归因：□ 外部主导  □ 内部主导  □ 混合</p>
      <p>反转难度：□ 较低  □ 中等  □ 较高</p>
    </div>
    <div class="card card-green">
      <div class="card-title">资产负债表诊断</div>
      <p>隐蔽资产评估：___亿元（具体列示）</p>
      <p>净净资产（格雷厄姆保守）：___亿元</p>
      <p>当前市值 vs 净净资产：市值□高于/□低于</p>
    </div>
  </div>

  <!-- 第三步：催化剂 -->
  <div class="section">
    <div class="section-title">第三步：反转催化剂与必要条件</div>
    <div class="card card-green">
      <div class="card-title">内部催化剂</div>
      <p>[资产重组、管理层变更、成本削减、资本结构优化的具体信号]</p>
    </div>
    <div class="card card-green">
      <div class="card-title">外部催化剂</div>
      <p>[行业供需改善、政策转向、新需求/新技术应用的具体证据]</p>
    </div>
    <div class="card">
      <div class="card-title">生存能力验证</div>
      <p>生存能力结论：✅ 高 / ⚠️ 中（风险） / ❌ 低（排除）</p>
      <p>[具体现金流与融资能力数据]</p>
    </div>
  </div>

  <!-- 第四步：估值 -->
  <div class="section">
    <div class="section-title">第四步：估值与安全边际</div>
    <table>
      <tr><th>估值方法</th><th>估算结果</th><th>当前市值对比</th></tr>
      <tr><td>清算价值法</td><td class="num">[ ]亿元</td><td>[  ]%</td></tr>
      <tr><td>重置成本法</td><td class="num">[ ]亿元</td><td>[  ]%</td></tr>
      <tr class="highlight-row"><td>格雷厄姆净净资产</td><td class="num">[ ]亿元</td><td>[  ]%</td></tr>
    </table>
    <div class="card card-yellow">
      <div class="card-title">不对称性分析</div>
      <p>上涨情景：目标价[ ]元，潜在涨幅[ ]%</p>
      <p>下跌情景：清算价值[ ]元，潜在跌幅[ ]%</p>
      <p>市场隐含破产概率：[ ]%（若股价接近清算价值=隐含极高破产概率）</p>
    </div>
  </div>

  <!-- 第五步：风险 -->
  <div class="section">
    <div class="section-title">第五步：风险管理与仓位建议</div>
    <table>
      <tr><th>风险类型</th><th>具体风险</th><th>概率</th><th>影响</th><th>应对预案</th></tr>
      <tr><td>行业风险</td><td>[ ]</td><td>[ ]</td><td>[ ]</td><td>[ ]</td></tr>
      <tr><td>催化剂失效</td><td>[ ]</td><td>[ ]</td><td>[ ]</td><td>[ ]</td></tr>
      <tr><td>流动性风险</td><td>[ ]</td><td>[ ]</td><td>[ ]</td><td>[ ]</td></tr>
    </table>
    <div class="card">
      <div class="card-title">仓位与时间建议</div>
      <p>单一个股仓位上限：不超过组合[ ]%</p>
      <p>建仓方式：分3批（30%/30%/40%）</p>
      <p>止损线：跌破¥[ ]元（约[ ]%回撤）</p>
      <p>预期反转时间：[ ]年 | 适合资本属性：长期/中期</p>
    </div>
  </div>

  <!-- 最终决策 -->
  <div class="section">
    <div class="section-title">最终决策框架</div>
    <div class="conclusion-box">
      <div class="conclusion-title">问题一：为什么市场是错的？</div>
      <div class="conclusion-text">[具体阐述市场忽略或过度悲观的关键点]</div>
    </div>
    <div class="conclusion-box" style="margin-top:12px; background:linear-gradient(135deg,#eff6ff 0%,#dbeafe 100%); border-color:#3b82f6;">
      <div class="conclusion-title" style="color:#1e40af;">问题二：为什么你能成为交易中正确的一方？</div>
      <div class="conclusion-text">[具体阐述认知优势来源]</div>
    </div>
  </div>

  <!-- 免责声明 -->
  <div class="footer">
    本报告基于归江价值投资哲学框架与《价值投资》方法论生成，仅供研究参考，不构成任何投资建议。<br>
    数据截至：[当前系统时间] | 归江价值精选研究团队 | 发送至：hncjit@qq.com
  </div>
</div>
</body>
</html>
```

---

## 邮件发送规范

### 调用邮件发送脚本

研究报告生成后，自动调用以下脚本将 HTML 报告发送至 `hncjit@qq.com`：

```python
import subprocess
import sys

script_path = r"C:\Users\Administrator\WorkBuddy\Claw\email_config.py"
# HTML内容由AI生成后通过邮件正文发送
```

### 邮件配置规范

使用已配置的邮箱信息（见 `C:\Users\Administrator\WorkBuddy\Claw\email_config.py`）：
- 发件人/收件人：`hncjit@qq.com`
- SMTP 服务器：`smtp.qq.com:587`
- From 头中文名必须使用 `email.header.Header` 编码，否则 QQ SMTP 返回 550 错误

**正确的 From 头写法：**
```python
from email.header import Header
msg['From'] = f'{Header("归江价值精选研究", "utf-8").encode()} <{SENDER_EMAIL}>'
```

### 邮件主题格式

```
[归江价值精选] 困境反转深度研究 · [公司名称/代码] · [当前日期]
```

---

## 数据获取优先级规范

### 财报期次自动判断

**核心原则**：根据当前日期判断最新可获取的财报期次，而非默认使用年报。

| 市场 | 最新可获取报告 | 截止时间 |
|------|-------------|---------|
| A股 | 一季报(4月)/ 中报(8月)/ 三季报(10月)/ 年报(次年4月) | 月底前披露 |
| 港股 | 中报(9月)/ 年报(次年3月) | 月底前披露 |
| 美股 | 最新10-Q季报 / 10-K年报 | 财季结束40-60天后 |

### 数据获取优先级

1. **金融数据API（Tushare/AkShare）** —— 获取最新报告期财务数据
2. **交易所官方披露** —— 巨潮资讯(cninfo) / 港交所披露易(hkexnews) / SEC EDGAR
3. **带时间限定的Web搜索** —— 搜索词必须包含报告期年份

---

## 踩坑经验积累

（当遇到以下情况时，必须追加记录：）

- 某API参数格式/返回字段与文档不符
- 某数据源的时效性判断失误
- 某困境反转逻辑验证后发现错误
- 邮件发送失败原因及修复方法

---

## 触发词优化规则

当用户在对话中使用了本技能未覆盖的表达时：
1. 完成当前任务
2. 分析用户原始请求中的关键词
3. 将其追加到 frontmatter 的 `description` 触发词列表末尾
4. 保持简洁通用，避免过于具体的个例
