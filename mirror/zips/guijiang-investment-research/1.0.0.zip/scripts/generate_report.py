#!/usr/bin/env python3
"""
困境反转深度研究 HTML 报告生成器

生成专业困境反转研究报告的 HTML 文件。
使用说明：调用 generate_html_report(company_info, analysis_data) 生成 HTML。
"""

import os
from datetime import datetime
from pathlib import Path

# ─────────────────────────────────────────────────────────────────────────────
# 报告生成器
# ─────────────────────────────────────────────────────────────────────────────

def get_current_time():
    """获取当前系统时间（格式化字符串）"""
    try:
        from datetime import datetime
        return datetime.now().strftime("%Y年%m月%d日 %H:%M")
    except Exception:
        return "未知时间"


def escape_html(text):
    """转义 HTML 特殊字符"""
    if text is None:
        return ""
    return (str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;"))


def generate_html_report(company_info: dict, analysis: dict) -> str:
    """
    生成困境反转深度研究 HTML 报告

    Parameters:
    ───────────
    company_info: dict
        - name: 公司名称
        - code: 股票代码
        - market: 市场（A/港/美）
        - current_price: 当前股价
        - market_cap: 市值（亿元）
        - pb: 市净率
        - ps: 市销率
        - dividend_yield: 股息率
        - price_from_high_pct: 股价高点回撤（%）
        - all_time_high: 历史最高价
    analysis: dict
        - distress_type: 困境类型
        - distress_desc: 困境描述
        - market_sentiment: 市场情绪
        - overreaction_confirmed: 是否过度反应（bool）
        - cycle_position: 行业周期位置
        - distress_attribution: 困境归因（外部/内部/混合）
        - reversal_difficulty: 反转难度（较低/中等/较高）
        - reversal_years: 预期反转年限
        - hidden_assets: 隐蔽资产评估值（亿元）
        - net_net_value: 格雷厄姆净净资产（亿元）
        - liquidation_value: 清算价值（亿元）
        - replacement_cost: 重置成本（亿元）
        - survival_probability: 生存能力（高/中/低）
        - internal_catalysts: 内部催化剂列表
        - external_catalysts: 外部催化剂列表
        - reversal_probability: 反转概率（%）
        - target_price: 目标价（元）
        - stop_loss: 止损价（元）
        - position_limit: 仓位上限（%）
        - key_risks: 风险列表
        - why_market_wrong: 为什么市场是错的
        - why_i_am_right: 为什么我能正确
        - rating: 综合评级（高度关注/观察/排除）
        - research_conclusion: 研究结论（摘要）
    """

    current_time = get_current_time()
    name = escape_html(company_info.get("name", "未知公司"))
    code = escape_html(company_info.get("code", "---"))
    market = escape_html(company_info.get("market", ""))
    rating = analysis.get("rating", "观察")

    rating_map = {
        "高度关注": ("rating-buy", "高度关注"),
        "观察": ("rating-watch", "观察"),
        "排除": ("rating-exclude", "排除"),
    }
    rating_class, rating_text = rating_map.get(rating, ("rating-watch", rating))

    distress_type = escape_html(analysis.get("distress_type", "待分析"))
    reversal_diff_map = {"较低": "较低（1-2年）", "中等": "中等（2-3年）", "较高": "较高（3年以上）"}
    reversal_diff_text = reversal_diff_map.get(analysis.get("reversal_difficulty", ""), analysis.get("reversal_difficulty", ""))

    survival_map = {"高": ("✅", "高", "card-green"), "中": ("⚠️", "中（存在风险）", "card-yellow"), "低": ("❌", "低（排除）", "card-red")}
    surv_sym, surv_text, surv_class = survival_map.get(analysis.get("survival_probability", "中"), ("⚠️", "中", "card-yellow"))

    overreaction = "✅ 确认存在" if analysis.get("overreaction_confirmed") else "❌ 信号不明显"
    overreaction_class = "card-green" if analysis.get("overreaction_confirmed") else "card-yellow"

    # 内部/外部催化剂列表
    internal_cats = analysis.get("internal_catalysts", [])
    external_cats = analysis.get("external_catalysts", [])
    key_risks = analysis.get("key_risks", [])

    # 估值表格
    liquidation = analysis.get("liquidation_value", 0)
    net_net = analysis.get("net_net_value", 0)
    replacement = analysis.get("replacement_cost", 0)
    current_price = company_info.get("current_price", 0)
    market_cap = company_info.get("market_cap", 0)
    pb = company_info.get("pb", 0)
    ps = company_info.get("ps", 0)
    dividend = company_info.get("dividend_yield", 0)
    price_from_high = company_info.get("price_from_high_pct", 0)
    all_time_high = company_info.get("all_time_high", 0)
    reversal_prob = analysis.get("reversal_probability", 0)
    reversal_years = analysis.get("reversal_years", "")
    target_price = analysis.get("target_price", 0)
    stop_loss = analysis.get("stop_loss", 0)
    position_limit = analysis.get("position_limit", 0)

    def pct(v1, v2):
        """计算v1相对于v2的百分比"""
        if not v1 or not v2 or float(v2) == 0:
            return "N/A"
        return f"{float(v1)/float(v2)*100:.1f}%"

    def liq_pct(v):
        if not liquidation or float(v) == 0:
            return "N/A"
        return f"{float(v)/float(liquidation)*100:.1f}%" if liquidation else "N/A"

    def fmt(v, unit="亿元"):
        try:
            return f"{float(v):,.2f} {unit}"
        except Exception:
            return str(v) if v else "—"

    def fmtpct(v):
        try:
            return f"{float(v)*100:.2f}%"
        except Exception:
            return str(v) if v else "—"

    # ─── HTML 主体 ───────────────────────────────────────────────────────────

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>归江价值精选 · 困境反转深度研究报告 · {name} · {current_time}</title>
<style>
  body {{ margin:0; padding:0; background:#f0f4f8; font-family:'Microsoft YaHei','PingFang SC','SimSun',sans-serif; color:#1e293b; }}
  .container {{ max-width:920px; margin:20px auto; background:#fff; border-radius:12px; overflow:hidden; box-shadow:0 4px 24px rgba(30,58,95,0.10); }}
  .header {{ background:linear-gradient(135deg,#1e3a5f 0%,#2d5a87 100%); padding:28px 36px; color:#fff; }}
  .report-title {{ font-size:26px; font-weight:bold; margin:0 0 8px; letter-spacing:1px; }}
  .report-subtitle {{ font-size:14px; opacity:0.85; }}
  .rating-bar {{ display:inline-block; margin-top:14px; padding:6px 20px; border-radius:20px; font-size:15px; font-weight:bold; }}
  .rating-buy {{ background:#c9a84c; color:#fff; }}
  .rating-watch {{ background:#94a3b8; color:#fff; }}
  .rating-exclude {{ background:#ef4444; color:#fff; }}
  .section {{ padding:24px 36px; border-bottom:1px solid #e2e8f0; }}
  .section:last-child {{ border-bottom:none; }}
  .section-title {{ font-size:17px; font-weight:bold; color:#1e3a5f; border-left:5px solid #c9a84c; padding-left:14px; margin:0 0 16px; line-height:1.4; }}
  .card {{ background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:16px 20px; margin-bottom:14px; }}
  .card:last-child {{ margin-bottom:0; }}
  .card-title {{ font-size:14px; font-weight:bold; color:#1e3a5f; margin:0 0 10px; }}
  .card-green {{ background:#f0fdf4; border-color:#86efac; }}
  .card-yellow {{ background:#fefce8; border-color:#fde047; }}
  .card-red {{ background:#fef2f2; border-color:#fca5a5; }}
  .tag {{ display:inline-block; padding:2px 10px; border-radius:12px; font-size:12px; font-weight:bold; }}
  .tag-green {{ background:#d1fae5; color:#065f46; }}
  .tag-yellow {{ background:#fef9c3; color:#713f12; }}
  .tag-red {{ background:#fee2e2; color:#991b1b; }}
  .tag-blue {{ background:#dbeafe; color:#1e40af; }}
  .metric-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin-top:12px; }}
  .metric-box {{ background:#fff; border:1px solid #cbd5e1; border-radius:8px; padding:12px 16px; }}
  .metric-label {{ font-size:12px; color:#64748b; margin-bottom:4px; }}
  .metric-value {{ font-size:20px; font-weight:bold; color:#1e3a5f; }}
  .metric-sub {{ font-size:11px; color:#94a3b8; margin-top:2px; }}
  table {{ width:100%; border-collapse:collapse; margin:12px 0; font-size:13px; }}
  th {{ background:#1e3a5f; color:#fff; padding:10px 14px; text-align:left; font-size:13px; }}
  td {{ padding:9px 14px; border-bottom:1px solid #e2e8f0; }}
  tr:nth-child(even) td {{ background:#f8fafc; }}
  tr:hover td {{ background:#f1f5f9; }}
  .highlight-row td {{ background:#fffbeb !important; border-left:4px solid #c9a84c; }}
  .num {{ text-align:right; font-variant-numeric:tabular-nums; color:#2563eb; font-weight:bold; }}
  .conclusion-box {{ background:linear-gradient(135deg,#f0fdf4 0%,#dcfce7 100%); border:2px solid #22c55e; border-radius:10px; padding:20px 24px; margin-top:16px; }}
  .conclusion-title {{ font-size:15px; font-weight:bold; color:#065f46; margin-bottom:8px; }}
  .conclusion-text {{ font-size:14px; color:#1e3a5f; line-height:1.8; }}
  .risk-box {{ background:#fef2f2; border:1px solid #fca5a5; border-radius:8px; padding:14px 18px; margin-top:10px; }}
  .risk-title {{ font-size:13px; font-weight:bold; color:#991b1b; margin-bottom:6px; }}
  .footer {{ padding:16px 36px; background:#f8fafc; border-top:1px solid #e2e8f0; font-size:12px; color:#64748b; text-align:center; }}
  .split-table td {{ vertical-align:top; }}
  .badge {{ display:inline-block; padding:2px 8px; border-radius:6px; font-size:12px; background:#e2e8f0; color:#475569; margin-right:6px; }}
  .highlight-text {{ color:#c9a84c; font-weight:bold; }}
</style>
</head>
<body>
<div class="container">
  <!-- 报告头部 -->
  <div class="header">
    <div class="report-title">归江价值精选 · 困境反转深度研究报告</div>
    <div class="report-subtitle">{name} · {code} · {market}股 · 报告日期：{current_time}</div>
    <div class="rating-bar {rating_class}">综合评级：{rating_text}</div>
  </div>

  <!-- 执行摘要 -->
  <div class="section">
    <div class="section-title">执行摘要</div>
    <div class="conclusion-box">
      <div class="conclusion-title">研究结论</div>
      <div class="conclusion-text">{escape_html(analysis.get('research_conclusion', '（待填写）'))}</div>
    </div>
    <div class="metric-grid" style="margin-top:16px;">
      <div class="metric-box">
        <div class="metric-label">当前股价</div>
        <div class="metric-value">¥{fmt(current_price, '')}</div>
        <div class="metric-sub">市值：{fmt(market_cap)}</div>
      </div>
      <div class="metric-box">
        <div class="metric-label">市净率（PB）</div>
        <div class="metric-value">{fmt(pb, '')}x</div>
        <div class="metric-sub">困境类型：{distress_type}</div>
      </div>
      <div class="metric-box">
        <div class="metric-label">股价高点回撤</div>
        <div class="metric-value">{fmtpct(price_from_high/100)}</div>
        <div class="metric-sub">历史高点：¥{fmt(all_time_high, '')}</div>
      </div>
      <div class="metric-box">
        <div class="metric-label">反转概率评估</div>
        <div class="metric-value">{reversal_prob}%</div>
        <div class="metric-sub">预期时间：{reversal_years}</div>
      </div>
    </div>
  </div>

  <!-- 第一步：困境识别 -->
  <div class="section">
    <div class="section-title">第一步：困境识别与过度反应验证</div>
    <div class="card">
      <div class="card-title">困境表征</div>
      <p><span class="badge">{distress_type}</span></p>
      <p>{escape_html(analysis.get('distress_desc', '（待填写）'))}</p>
    </div>
    <div class="card">
      <div class="card-title">市场情绪判断</div>
      <p>{escape_html(analysis.get('market_sentiment', '（待填写）'))}</p>
    </div>
    <div class="card {overreaction_class}">
      <div class="card-title">过度反应验证</div>
      <p>市场过度悲观信号：<strong>{overreaction}</strong></p>
    </div>
  </div>

  <!-- 第二步：根源分析 -->
  <div class="section">
    <div class="section-title">第二步：困境根源——周期性 vs 永久性损伤</div>
    <div class="card">
      <div class="card-title">行业周期位置</div>
      <p>{escape_html(analysis.get('cycle_position', '（待填写）'))}</p>
    </div>
    <div class="card">
      <div class="card-title">困境归因分析</div>
      <p>困境归因：<strong>{escape_html(analysis.get('distress_attribution', '（待填写）'))}</strong></p>
      <p>反转难度：<strong>{escape_html(reversal_diff_text)}</strong></p>
    </div>
    <div class="card card-green">
      <div class="card-title">资产负债表诊断（关键步骤）</div>
      <p>隐蔽资产评估：<strong>{fmt(analysis.get('hidden_assets', 0))}</strong>（具体资产明细待填写）</p>
      <p>格雷厄姆净净资产：<strong class="highlight-text">{fmt(net_net)}</strong></p>
      <p>清算价值（保守）：<strong>{fmt(liquidation)}</strong></p>
      <p>重置成本：<strong>{fmt(replacement)}</strong></p>
      <p>当前市值 vs 净净资产：<strong>{'低于（强安全边际）' if float(market_cap or 0) < float(net_net or 0) else '高于'}</strong></p>
    </div>
  </div>

  <!-- 第三步：催化剂 -->
  <div class="section">
    <div class="section-title">第三步：反转催化剂与必要条件</div>
    <div class="card card-green">
      <div class="card-title">内部催化剂</div>
      <ul style="margin:6px 0 0 18px; padding:0; line-height:2;">
"""
    if internal_cats:
        for cat in internal_cats:
            html += f'        <li>{escape_html(cat)}</li>\n'
    else:
        html += '        <li>（待填写）</li>\n'

    html += f"""      </ul>
    </div>
    <div class="card card-green">
      <div class="card-title">外部催化剂</div>
      <ul style="margin:6px 0 0 18px; padding:0; line-height:2;">
"""
    if external_cats:
        for cat in external_cats:
            html += f'        <li>{escape_html(cat)}</li>\n'
    else:
        html += '        <li>（待填写）</li>\n'

    html += f"""      </ul>
    </div>
    <div class="card {surv_class}">
      <div class="card-title">生存能力验证（反转前置条件）</div>
      <p>生存能力结论：<strong>{surv_sym} {surv_text}</strong></p>
    </div>
  </div>

  <!-- 第四步：估值 -->
  <div class="section">
    <div class="section-title">第四步：估值与安全边际</div>
    <table>
      <tr><th>估值方法</th><th>估算结果</th><th>备注</th></tr>
      <tr>
        <td>清算价值法（极度保守）</td>
        <td class="num">{fmt(liquidation)}</td>
        <td>快速变现折扣后估算</td>
      </tr>
      <tr>
        <td>重置成本法</td>
        <td class="num">{fmt(replacement)}</td>
        <td>重建相同业务所需成本</td>
      </tr>
      <tr class="highlight-row">
        <td>格雷厄姆净净资产</td>
        <td class="num">{fmt(net_net)}</td>
        <td>流动资产−全部负债，最保守下限</td>
      </tr>
    </table>
    <div class="card card-yellow">
      <div class="card-title">不对称性分析（核心决策依据）</div>
      <p>上涨情景：目标价 <strong style="color:#065f46">¥{fmt(target_price, '')}</strong>，潜在涨幅 <strong style="color:#065f46">{fmtpct((float(target_price or 0)/float(current_price or 1)-1)) if float(current_price or 0) > 0 else 'N/A'}</strong></p>
      <p>下跌情景：清算价值 <strong style="color:#991b1b">¥{fmt(float(liquidation or 0)/max(float(company_info.get('shares', 1)), 1), '')}</strong>（按股本摊薄），潜在跌幅 <strong style="color:#991b1b">{fmtpct((1-float(liquidation or 0)/max(float(market_cap or 1), 1))) if float(market_cap or 0) > 0 else 'N/A'}</strong></p>
      <p>止损价：<strong style="color:#991b1b">¥{fmt(stop_loss, '')}</strong>（跌破此价触发止损）</p>
    </div>
  </div>

  <!-- 第五步：风险 -->
  <div class="section">
    <div class="section-title">第五步：风险管理与仓位建议</div>
    <table>
      <tr><th>风险类型</th><th>具体风险描述</th><th>应对预案</th></tr>
"""
    if key_risks:
        for risk in key_risks:
            html += f'      <tr><td>{escape_html(risk.get("type", ""))}</td><td>{escape_html(risk.get("desc", ""))}</td><td>{escape_html(risk.get("预案", ""))}</td></tr>\n'
    else:
        html += '      <tr><td colspan="3">（待填写风险清单）</td></tr>\n'

    html += f"""    </table>
    <div class="card">
      <div class="card-title">仓位与时间建议</div>
      <p>单一个股仓位上限：不超过组合 <strong style="color:#2563eb">{position_limit}%</strong></p>
      <p>建仓方式：分3批（30% / 30% / 40%），回调加仓，确认再加</p>
      <p>止损线：跌破 <strong style="color:#991b1b">¥{fmt(stop_loss, '')}</strong> 触发止损</p>
      <p>预期反转时间：<strong>{reversal_years}</strong> 年</p>
    </div>
  </div>

  <!-- 最终决策 -->
  <div class="section">
    <div class="section-title">最终决策框架</div>
    <div class="conclusion-box">
      <div class="conclusion-title">问题一：为什么市场是错的？</div>
      <div class="conclusion-text">{escape_html(analysis.get('why_market_wrong', '（待填写）'))}</div>
    </div>
    <div class="conclusion-box" style="margin-top:12px; background:linear-gradient(135deg,#eff6ff 0%,#dbeafe 100%); border-color:#3b82f6;">
      <div class="conclusion-title" style="color:#1e40af;">问题二：为什么你能成为交易中正确的一方？</div>
      <div class="conclusion-text">{escape_html(analysis.get('why_i_am_right', '（待填写）'))}</div>
    </div>
  </div>

  <!-- 免责声明 -->
  <div class="footer">
    本报告基于归江价值投资哲学框架与《价值投资：从格雷厄姆到巴菲特》方法论生成，仅供研究参考，不构成任何投资建议。<br>
    数据截至：{current_time} | 归江价值精选研究团队 | 发送至：hncjit@qq.com
  </div>
</div>
</body>
</html>"""

    return html


def save_report(html: str, company_name: str, company_code: str) -> str:
    """保存HTML报告到文件，返回文件路径"""
    output_dir = Path(r"C:\Users\Administrator\WorkBuddy\Claw")
    output_dir.mkdir(parents=True, exist_ok=True)
    from datetime import datetime
    today = datetime.now().strftime("%Y%m%d")
    safe_name = company_name.replace(" ", "_").replace("*", "").replace("/", "_")
    safe_code = company_code.replace(".", "_").replace("*", "")
    filename = f"困境反转研究报告_{safe_name}_{safe_code}_{today}.html"
    filepath = output_dir / filename
    filepath.write_text(html, encoding="utf-8")
    return str(filepath)


def send_report_via_email(html_content: str, company_name: str, company_code: str):
    """通过邮件发送HTML报告"""
    try:
        import sys
        sys.path.insert(0, r"C:\Users\Administrator\WorkBuddy\Claw")
        from email_config import SENDER_EMAIL, SENDER_NAME, EMAIL_PASSWORD
        import smtplib
        from email.header import Header
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        from datetime import datetime

        current_time = datetime.now().strftime("%Y年%m月%d日")
        subject = f"[归江价值精选] 困境反转深度研究 · {company_name} {company_code} · {current_time}"

        msg = MIMEMultipart("alternative")
        msg["Subject"] = Header(subject, "utf-8").encode()
        msg["From"] = f'{Header(SENDER_NAME, "utf-8").encode()} <{SENDER_EMAIL}>'
        msg["To"] = "hncjit@qq.com"

        mime_html = MIMEText(html_content, "html", "utf-8")
        msg.attach(mime_html)

        server = smtplib.SMTP("smtp.qq.com", 587)
        server.ehlo()
        server.starttls()
        server.login(SENDER_EMAIL, EMAIL_PASSWORD)
        server.sendmail(SENDER_EMAIL, ["hncjit@qq.com"], msg.as_string())
        server.quit()

        print(f"✅ 邮件发送成功：{subject}")
        return True
    except Exception as e:
        print(f"❌ 邮件发送失败：{e}")
        return False


def main():
    """演示：生成一份示例报告"""
    print("=" * 60)
    print("困境反转深度研究报告生成器")
    print("=" * 60)
    print()
    print("请在 AI 对话中提供以下信息以生成完整报告：")
    print("  1. 公司名称与股票代码")
    print("  2. 困境类型与描述")
    print("  3. 关键财务数据（PB、股价、市值、ROE等）")
    print("  4. 反转催化剂证据")
    print("  5. 估值与安全边际分析")
    print()
    print("使用方式：在 AI 对话中触发本技能后，AI 将引导您完成分析。")


if __name__ == "__main__":
    main()
