#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
归江价值比较研究报告生成脚本
辅助生成标准化的横向比较研究报告
"""

import json
import sys
from datetime import datetime
from typing import List, Dict, Any


def generate_report_template(target_company: str, target_code: str, peers: List[Dict[str, str]]) -> str:
    """
    生成归江式比较研究报告模板
    
    Args:
        target_company: 目标公司名称
        target_code: 目标公司股票代码
        peers: 可比公司列表 [{"name": "公司名", "code": "代码"}]
    
    Returns:
        Markdown格式的报告模板
    """
    
    today = datetime.now().strftime("%Y-%m-%d")
    peer_names = ", ".join([p["name"] for p in peers])
    
    template = f"""# 归江价值比较研究：{target_company} vs {peer_names}

**研究日期**：{today}  
**研究对象**：{target_company} ({target_code})  
**可比公司**：{peer_names}

---

## 第一步：寻镜结果——可比公司池

### 1.1 业务相似性筛选

| 公司 | 代码 | 与目标公司的关系 | 入选理由 |
|-----|------|-----------------|---------|
| {target_company} | {target_code} | 研究主体 | - |
"""
    
    for peer in peers:
        template += f"| {peer['name']} | {peer['code']} | 直接竞品/替代品/标杆 | [待填写] |\n"
    
    template += f"""
### 1.2 财务特征对比

| 指标 | {target_company} | {" | ".join([p["name"] for p in peers])} |
|-----|------------------|{"|".join(["-" for _ in peers])}|
| 近5年平均ROE | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 净利率 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 总资产周转率 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 权益乘数 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 市值(亿) | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |

### 1.3 百年标杆参考

- 海外成熟市场相似商业模式公司：[待填写]
- 借鉴意义：[待填写]

---

## 第二步：三维度深度比较

### 2.1 生意模式与生态位

| 维度 | {target_company} | {" | ".join([p["name"] for p in peers])} |
|-----|------------------|{"|".join(["-" for _ in peers])}|
| 一句话生意 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 应收账款天数 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 应付账款天数 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 预收账款 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 客户类型 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 需求属性 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |

**产业链话语权分析**：
- [待填写：谁在占用上下游资金？谁是皮，谁是毛？]

### 2.2 财务质量与周期位置

| 指标 | {target_company} | {" | ".join([p["name"] for p in peers])} |
|-----|------------------|{"|".join(["-" for _ in peers])}|
| 近5年ROE均值 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| ROE稳定性 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 近5年ROIC均值 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| FCF/净利润 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 有息负债率 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 现金占比 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |

**周期位置判断**：
- [待填写：当前处于周期的什么位置？]

### 2.3 估值与市场情绪

| 指标 | {target_company} | {" | ".join([p["name"] for p in peers])} |
|-----|------------------|{"|".join(["-" for _ in peers])}|
| 当前PB | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| PB历史分位 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 当前PE | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| PE历史分位 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| 股息率 | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |
| **透视回报率(ROE/PB)** | [待填写] | {" | ".join(["[待填写]" for _ in peers])} |

**PB-ROE坐标系定位**：
- [待填写：各公司落在哪个象限？]

---

## 第三步：异常值识别与洞见

### 3.1 发现的异常

**异常1**：[待填写]
- 现象：[具体数据差异]
- 原因分析：[为什么有这个差异？]
- 投资启示：[机会还是陷阱？]

**异常2**：[待填写]
- 现象：[具体数据差异]
- 原因分析：[为什么有这个差异？]
- 投资启示：[机会还是陷阱？]

### 3.2 竞争力排序

1. [第一名的理由]
2. [第二名的理由]
3. [第三名的理由]

---

## 第四步：归江式判断与建议

### 【归江三原则检验】

| 原则 | 检验结果 | 说明 |
|-----|---------|------|
| 低PB | □ 通过 □ 未通过 | 当前PB=X.XX，处于历史XX%分位 |
| 可理解 | □ 通过 □ 未通过 | 一句话概括：[生意本质] |
| 不死 | □ 通过 □ 未通过 | 现金/有息负债=X，抗风险能力[强/中/弱] |

### 【最终评级】

- [ ] **优先投资选项**：性价比突出，符合三原则
- [ ] **中性选项**：需更多观察
- [ ] **规避选项**：显露出明显弱点

**选择理由**：[详细说明]

### 【下一步研究建议】

1. [具体建议1]
2. [具体建议2]
3. [具体建议3]

---

*本报告基于归江价值投资框架生成，仅供参考，不构成投资建议。*
"""
    
    return template


def main():
    """命令行入口"""
    if len(sys.argv) < 3:
        print("Usage: python generate_comparison_report.py <target_company> <target_code> [peer_json]")
        print("Example:")
        print('  python generate_comparison_report.py "贵州茅台" "600519" \'[{"name":"五粮液","code":"000858"}]\'')
        sys.exit(1)
    
    target_company = sys.argv[1]
    target_code = sys.argv[2]
    
    peers = []
    if len(sys.argv) > 3:
        try:
            peers = json.loads(sys.argv[3])
        except json.JSONDecodeError:
            print("Error: Invalid JSON for peers")
            sys.exit(1)
    
    report = generate_report_template(target_company, target_code, peers)
    print(report)


if __name__ == "__main__":
    main()
