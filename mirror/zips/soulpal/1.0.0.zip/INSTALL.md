# SoulPal 安装指引

> 每个人都会寂寞，但还好，有你陪我。

## 前置条件

- OpenClaw 已部署并正常运行（ECS / 本地 Mac 均可）
- Agent 已配置 web_search 和 web_fetch（需要 Brave 或 Tavily API key）
- sandbox mode 设为 "off"（SoulPal 需要读写 SOUL.md）

## 安装

### 方式一：手动安装（推荐）

```bash
# 1. 进入 OpenClaw workspace 的 skills 目录
#    ECS 部署：
mkdir -p /root/.openclaw/workspace/skills/soulpal/references

#    本地部署：
# mkdir -p ~/.openclaw/workspace/skills/soulpal/references

# 2. 复制文件（三个文件）
#    把以下文件放到对应位置：
#    soulpal/SKILL.md           → 主文件
#    soulpal/references/anti-ai-rules.md → 通用负面清单

# 3. 修复权限（ECS 部署需要）
chown -R 1000:1000 /root/.openclaw/workspace/skills/soulpal

# 4. 重启 gateway 让 skill 生效
cd /opt/openclaw && docker compose restart

# 5. 验证 skill 已加载
docker logs openclaw-openclaw-gateway-1 --tail 30 2>&1 | grep -i skill
```

### 方式二：直接在 Telegram/企微/钉钉/飞书 中安装

把 SKILL.md 和 anti-ai-rules.md 的内容发给你的 Agent，让它帮你写入。

## 使用

安装完成后，对任意 Agent 发消息：

```
安装人设：上户彩 昼颜 笹本纱和
```

或者：

```
给这个 Agent 装千寻的性格
```

或者：

```
/soulpal Jarvis MCU
```

等 2-5 分钟。Agent 会用新风格回你一句话。

## 日常调整

| 你说 | 效果 |
|------|------|
| "这句不像" / "太假" | Agent 默默记住，下次不这样说 |
| "说话再轻一点" | 当场调整 |
| "重新安装人设" | 从头来 |
| "去掉人设" | 恢复默认 |
| "换成 XX 角色" | 新角色覆盖旧角色 |

## 注意事项

1. **模型要求**：建议使用 kimi-k2.5 或 MiniMax-M2.5 或更好的模型。Qwen、codex-mini 效果较差。
2. **Token 消耗**：单次安装约 25,000-40,000 tokens，约 $0.03-0.05（MiniMax 价格）。
3. **采集时间**：取决于角色知名度。热门角色（千寻、Jarvis）2-3 分钟，冷门角色 5 分钟+。
4. **多 Agent**：可以给不同 Agent 装不同角色。每个 Agent 的 SOUL.md 独立。
5. **进化**：安装后 Agent 会自动从对话中学习。不需要手动干预。

## 文件结构

```
~/.openclaw/workspace/skills/soulpal/
├── SKILL.md                    # 主文件
└── references/
    └── anti-ai-rules.md        # 通用负面清单
```

## 问题排查

**Agent 没有用新风格说话**
- 检查 SOUL.md 是否已写入：让 Agent 执行 `read SOUL.md`
- 检查 sandbox mode 是否为 "off"
- 重启 gateway 后重试

**搜索失败**
- 检查 Brave API key 是否配置正确
- 检查 web_search 和 web_fetch 是否在 tools 的 allow 列表中

**角色不像**
- 直接说"不像"——Agent 会记住并调整
- 冷门角色素材少，效果不如热门角色
- 可以手动编辑 SOUL.md 补充示范对话

## 反馈

用了之后告诉我：
- 哪个角色效果好/不好
- 哪些 AI 痕迹还没去掉
- 还缺什么功能

---

*SoulPal v1.0.0 · 2026.03*
