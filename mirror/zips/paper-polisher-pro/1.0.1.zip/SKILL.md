# paper-polisher-pro — 论文润色降重一站式工具

> 🎯 **AI痕迹检测 · 去AI味改写 · 智能降重 · 术语标准化 · 综合质量报告**
> 中英双语 · 纯本地运行 · 数据不出本机 · 零配置

## ✨ 核心亮点

| 特性 | 说明 |
|------|------|
| 🕵️ **14个AI模型指纹识别** | DeepSeek V4、GLM-5、Qwen3.5、Kimi K2、ChatGPT、Claude 等 |
| 📊 **量化评分** | 0-100分AI痕迹评分，不是模糊判断 |
| 🛡️ **术语保护** | 2255条医学术语库，降重时自动跳过 |
| 🔒 **本地隐私** | 论文不上传，数据不出本机 |
| 🧪 **6层检测引擎** | 模式匹配 + TTR + 句长 + 信息密度 + 句首结构 + 段落特征 |

**唯一支持国产AI模型指纹识别的学术工具** — 不止检测ChatGPT，更能识别DeepSeek、GLM、Qwen、Kimi、MiniMax、Step等国产大模型的写作痕迹。

## 触发词

"润色论文", "降重", "去AI味", "论文改写", "查AI率", "术语标准化", "降AI率", "论文润色", "论文降重", "论文查重", "AI论文检测", "论文降AI率", "毕业论文润色", "SCI润色", "论文去重", "学术写作助手", "知网降重", "Turnitin降重", "AI写作检测", "论文改写降重", "降重神器", "去AI痕迹", "论文去AI", "研究生论文", "学位论文润色", "降AI检测", "AI痕迹清除", "论文抄袭率", "polish paper", "paraphrase", "check ai writing", "humanize ai text", "deai", "remove ai traces", "ai content detector", "thesis polishing", "dissertation polish", "manuscript polishing", "reduce ai detection", "sci paper editing", "essay polisher", "paper proofread", "grammar check academic", "journal submission polish", "humanize paper", "rewrite paper", "detect ai writing", "ai writing score", "research paper rewrite", "paper polish", "ai paper detector", "plagiarism reducer", "academic writing assistant", "论文排版", "英文润色", "中文降重", "学术降重", "毕业论文降重", "期刊投稿", "核心期刊润色", "论文质量检测", "AI生成检测", "AIGC检测", "论文自检", "写作辅助", "论文审校", "中文学术润色", "英文论文改写", "降重技巧", "AI论文改写", "查重率降低", "降低重复率", "论文去重工具", "学术写作工具"

## 适用场景

- 🎓 毕业论文提交前的AI痕迹清理
- 📄 SCI/核心期刊投稿前的润色降重
- 📋 学位论文的术语规范化
- 🔬 学术写作质量自查
- 🌐 中英文论文均可处理

---

## 🚀 快速开始

### 30秒检测AI痕迹

```bash
python3 {{SKILL_DIR}}/scripts/ai_detector.py your_paper.txt --lang auto
```

输出示例：
```
📄 your_paper.txt
AI Risk Score: 68.5 / 100 🔴 HIGH
Paragraphs analyzed: 12
Top AI patterns: "综上所述" (×3), "不容忽视" (×2)
Recommendation: 改写建议用于第2、5、8段
```

### 检查术语标准化

```bash
python3 {{SKILL_DIR}}/scripts/term_check.py your_paper.txt
```

### 生成综合质量报告

```bash
python3 {{SKILL_DIR}}/scripts/quality_report.py your_paper.txt --format json
```

---

## 📋 完整工作流（五步）

### 第一步：AI痕迹检测

```bash
python3 {{SKILL_DIR}}/scripts/ai_detector.py <输入文件> --lang auto --format json --output <输出.json>
```

展示给用户：
- AI痕迹评分（0-100，越高越像AI）
- 风险等级（🟢低 / 🟡中 / 🔴高）
- 高风险段落位置
- 命中的AI模式TOP 10

### 第二步：去AI味改写

对评分 ≥ 35 的段落进行改写。

**中文改写铁律：**

1. ❌ **删套话**："值得注意的是"、"综上所述"、"具有重要的理论意义" → 删
2. ❌ **删空泛评价**："提供了新的视角"、"为…提供了有益参考" → 给具体内容或删
3. ❌ **破对称**："不仅…而且…"、"一方面…另一方面…" → 拆为递进、转折
4. ❌ **禁万能动词**："深入探讨"、"系统梳理" → "比较了X和Y的差异"
5. ✅ **用数据**："取得了显著进展" → "3年随访缓解率从42%提升至78%"
6. ✅ **长短交替**：长句接短句，打破AI均匀节奏
7. ✅ **内容衔接**：用内容逻辑过渡，不用"此外"、"与此同时"堆砌
8. ✅ **保留术语**：所有专业术语、数据、引用原封不动

**英文改写规则：**
- 禁用：plays a crucial role, has gained significant attention, shed light on, pave the way, delve into, myriad, plethora
- 用主动语态："We found" 不用 "It was found that"
- 长短句交替（5-10词和20-30词混搭）

**改写模板：**
```
请改写以下学术论文段落，去除AI写作痕迹。

要求：
1. 删除所有AI高频短语和空泛评价
2. 用具体数据/事实替代模糊表述
3. 打破对称句式，恢复自然长短句交替
4. 段间用内容衔接，不用过渡词堆砌
5. 保留所有专业术语、数据、引用不变
6. 保持原文语义和学术逻辑

原文段落：
{paragraph}

改写后输出，不要解释。
```

### 第三步：智能降重

**五层降重策略：**

1. **同义词替换**：查 `synonyms_general.json`，跳过受保护术语
2. **句式变换**：主动↔被动、长句拆分、短句合并
3. **语序调整**：重排信息点（不改逻辑）
4. **概括↔展开**：高重复→概括 / 简略→展开
5. **视角转换**：从不同角度描述同一内容

⚠️ **术语保护**：2255条医学术语（名词委+MeSH+药物）降重时自动跳过

### 第四步：术语标准化

```bash
python3 {{SKILL_DIR}}/scripts/term_check.py <输入文件>
```

基于2255条权威术语库自动检查非标准用法，如"风湿病" → "风湿免疫病"。

### 第五步：综合质量报告

改写后重新检测，展示前后对比：
- 改写前AI评分 → 改写后AI评分
- 各段落改善情况
- 术语标准化率

---

## 🎯 支持检测的AI模型

### 国产模型（独家支持）
| 模型 | 检测分数 | 风险判定 |
|------|---------|---------|
| DeepSeek V4 | 84.3 | 🔴 高 |
| GLM-5-Turbo | 98.6 | 🔴 高 |
| GLM-5.1 | 74.9 | 🔴 高 |
| Kimi K2 | 66.3 | 🔴 高 |
| Step 3.5 Flash | 79.3 | 🔴 高 |
| Qwen3.5-Plus | 39.5-58.6 | 🟡-🔴 |
| MiniMax M2.5 | 39.9 | 🟡 中 |

### 国际模型
ChatGPT (77.3 🔴) · Claude (70+ 🔴) · Gemini (65+ 🔴)

### 真人文本（零误报）
临床病历 24.8 🟢 · 学术论文 31.6 🟢

---

## ⚠️ 使用约束

1. **绝不篡改数据**：数值、统计值、引用编号原样保留
2. **术语保护**：2255条专业术语降重时自动跳过
3. **语义不变**：改写前后语义等价
4. **逐段处理**：长论文逐段改写保持连贯
5. **用户确认**：改写结果展示后由用户决定是否采纳

---

## 📦 文件结构

```
paper-polisher/
├── SKILL.md                    ← 本文件
├── scripts/
│   ├── ai_detector.py          ← AI检测引擎 (v3.3b, 6层, 300+规则)
│   ├── term_check.py           ← 术语标准化 (2255条)
│   ├── ngram_similarity.py     ← N-gram重复率分析
│   └── quality_report.py       ← 综合质量报告
├── references/
│   ├── ai_patterns_zh.json     ← 中文AI模式库 (300+规则)
│   ├── ai_patterns_en.json     ← 英文AI模式库 (100+规则)
│   └── synonyms_general.json   ← 同义词库 (291组)
└── data/
    └── terminology.json        ← 标准术语库 (2255条)
```

## 版本

- **v1.0.1** — 显示名更新为"Paper Polisher Pro" + SEO关键词优化（70个中英文触发词）+ 小红书推广文案
- **v1.0.0** — 首发版本：AI检测（14模型）+ 去AI味 + 降重 + 术语检查 + 质量报告
