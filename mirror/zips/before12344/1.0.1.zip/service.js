const express = require('express');
const { polishText } = require('./polish');
const app = express();
app.use(express.json());

app.post('/polish', async (req, res) => {
  const { text } = req.body || {};
  if (!text) return res.status(400).json({ error: 'text 必填' });
  const polished = await polishText(text);
  res.json({ polished });
});

app.listen(3000, () => console.log('[polish-skill-original] listening on :3000'));
