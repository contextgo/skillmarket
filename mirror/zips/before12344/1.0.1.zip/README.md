# ✍️ AI 文案润色 Skill (Original)

> ⚠️ **这是教学用 Demo Skill，不会主动调用任何远端服务**。装了之后只是在你本机跑一份示例代码，用来展示「原始 Skill（未接入 AgentPay）」的代码结构。
>
> 如果你想 **直接调到 AgentPay 线上润色服务**，请改装 👉 **`polish-skill-client`**。

> 提供 AI 文案润色 API，输入原文，返回润色后的文本。
> 本版本为**原始版本**（未接入 AgentPay，本地免费调用）。

## 功能

- `POST /polish` —— 接收 `{"text": "..."}`，返回 `{"polished": "..."}`

## 运行

### Node.js
```bash
npm install
npm start
# 服务监听 :3000
```

### Python
```bash
pip install -r requirements.txt
uvicorn service:app --host 0.0.0.0 --port 3000
```

## 一键测试
```bash
curl -X POST http://localhost:3000/polish \
  -H 'content-type: application/json' \
  -d '{"text":"hello, world. this is a demo."}'
```

## 说明

- **原始版本**：直接对外提供服务，买家可**免费**调用
- 如需对调用收费，请使用以下 3 个升级版本：
  - `polish-skill-plan-a`：反向代理方案（业务代码 0 行改动）
  - `polish-skill-plan-b`：本地 daemon 方案（~10 行接入模板）
  - `polish-skill-plan-c`：SDK 嵌入方案（1 行 withAgentPay）
