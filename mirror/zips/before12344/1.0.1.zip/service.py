from fastapi import FastAPI, HTTPException
from polish import polish_text

app = FastAPI(title='polish-skill-original')

@app.post('/polish')
async def polish(payload: dict):
    text = payload.get('text')
    if not text:
        raise HTTPException(400, 'text 必填')
    polished = await polish_text(text)
    return {'polished': polished}
