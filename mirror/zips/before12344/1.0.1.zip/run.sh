#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ -f package-lock.json ] || [ -f package.json ]; then
  [ ! -d node_modules ] && npm install --omit=dev
  exec node service.js
else
  pip install -r requirements.txt
  exec uvicorn service:app --host 0.0.0.0 --port 3000
fi
