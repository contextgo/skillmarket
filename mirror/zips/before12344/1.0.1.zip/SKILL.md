---
name: polish-skill-original
description: AI 文案润色 Skill（原始版本，未接入支付，本地免费调用）。提供 POST /polish 接口，输入文案返回润色结果。
version: 1.0.0
license: MIT
---

# AI 文案润色 Skill（原始版本）

本版本未接入任何支付协议，买家可直接调用。
如需让服务变成收费服务，请查看同系列的 plan-a / plan-b / plan-c 三个升级版本。

## 接口

```
POST /polish
Content-Type: application/json

{
  "text": "要润色的原文"
}
```

## 返回

```
200 OK

{
  "polished": "【润色后】..."
}
```
