"""
论文格式修改技能 - 核心配置模块
包含所有格式规范的常量定义
"""

from docx.shared import Pt, Cm

# ==================== 页面设置 ====================
PAGE_SETTINGS = {
    'paper_size': 'A4',
    'margin_top': Cm(2.5),
    'margin_bottom': Cm(2.5),
    'margin_left': Cm(2.5),
    'margin_right': Cm(2.5),
    'line_spacing': 20  # 固定值20磅
}

# ==================== 字体格式 ====================
FONT_FORMATS = {
    # 封面部分
    'title': {
        'size': Pt(16),  # 三号
        'bold': True,
        'name': '黑体',
        'alignment': 'center'
    },
    'subtitle': {
        'size': Pt(14),  # 四号
        'bold': True,
        'name': '黑体',
        'alignment': 'center'
    },
    'author_info': {
        'size': Pt(12),  # 小四号
        'bold': False,
        'name': '楷体',
        'alignment': 'center'
    },
    
    # 摘要部分
    'abstract_label': {
        'size': Pt(12),  # 小四号
        'bold': True,
        'name': '黑体',
        'alignment': 'left',
        'first_line_indent': Cm(0.74)  # 空两格
    },
    'abstract_content': {
        'size': Pt(10.5),  # 五号
        'bold': False,
        'name': '楷体',
        'alignment': 'left'
    },
    'keywords_label': {
        'size': Pt(12),  # 小四号
        'bold': True,
        'name': '黑体',
        'alignment': 'left',
        'first_line_indent': Cm(0.74)
    },
    'keywords_content': {
        'size': Pt(10.5),  # 五号
        'bold': False,
        'name': '楷体',
        'alignment': 'left'
    },
    
    # 文档主标题（在摘要上方的论文题目）
    'document_title': {
        'size': Pt(16),  # 三号
        'bold': True,
        'name': '黑体',
        'alignment': 'center'
    },
    
    # 正文部分
    'body_content': {
        'size': Pt(10.5),  # 五号
        'bold': False,
        'name': '宋体',
        'alignment': 'left',
        'line_spacing': 20  # 固定值20磅
    },
    'body_english': {
        'size': Pt(12),  # Times New Roman 12
        'bold': False,
        'name': 'Times New Roman',
        'alignment': 'left'
    },
    
    # 标题层级（文经管法）
    'header_1': {
        'size': Pt(14),  # 四号
        'bold': True,
        'name': '黑体',
        'alignment': 'left',
        'prefix': ['一、', '二、', '三、', '四、', '五、', '六、', '七、', '八、', '九、', '十、']
    },
    'header_2': {
        'size': Pt(12),  # 小四号
        'bold': True,
        'name': '黑体',
        'alignment': 'left',
        'prefix': ['（一）', '（二）', '（三）', '（四）', '（五）', '（六）', '（七）', '（八）', '（九）', '（十）']
    },
    'header_3': {
        'size': Pt(12),  # 小四号
        'bold': True,
        'name': '黑体',
        'alignment': 'left',
        'prefix': ['1. ', '2. ', '3. ', '4. ', '5. ', '6. ', '7. ', '8. ', '9. ', '10. ']
    },
    'header_4': {
        'size': Pt(10.5),  # 五号
        'bold': True,
        'name': '黑体',
        'alignment': 'left',
        'prefix': ['（1）', '（2）', '（3）', '（4）', '（5）', '（6）', '（7）', '（8）', '（9）', '（10）']
    },
    'header_5': {
        'size': Pt(10.5),  # 五号
        'bold': True,
        'name': '黑体',
        'alignment': 'left',
        'prefix': ['1)', '2)', '3)', '4)', '5)', '6)', '7)', '8)', '9)', '10)']
    },
    
    # 标题层级（理工类）
    'tech_header_1': {
        'size': Pt(14),
        'bold': True,
        'name': '黑体',
        'alignment': 'left',
        'prefix': ['1 ', '2 ', '3 ', '4 ', '5 ', '6 ', '7 ', '8 ', '9 ', '10 ']
    },
    'tech_header_2': {
        'size': Pt(12),
        'bold': True,
        'name': '黑体',
        'alignment': 'left',
        'prefix': ['1.1 ', '1.2 ', '1.3 ', '1.4 ', '1.5 ', '2.1 ', '2.2 ', '2.3 ', '2.4 ', '2.5 ']
    },
    'tech_header_3': {
        'size': Pt(12),
        'bold': True,
        'name': '黑体',
        'alignment': 'left',
        'prefix': ['1.1.1 ', '1.1.2 ', '1.1.3 ', '1.1.4 ', '1.1.5 ', '2.1.1 ', '2.1.2 ', '2.1.3 ', '2.1.4 ', '2.1.5 ']
    },
    
    # 参考文献部分
    'references_label': {
        'size': Pt(14),  # 四号
        'bold': True,
        'name': '黑体',
        'alignment': 'center'
    },
    'references_content': {
        'size': Pt(10.5),  # 五号
        'bold': False,
        'name': '宋体',
        'alignment': 'left'
    },
    
    # 英文摘要部分
    'english_title': {
        'size': Pt(16),  # 三号
        'bold': True,
        'name': 'Times New Roman',
        'alignment': 'center'
    },
    'english_abstract_label': {
        'size': Pt(12),  # 小四号
        'bold': True,
        'name': 'Times New Roman',
        'alignment': 'left'
    },
    'english_abstract_content': {
        'size': Pt(12),  # 小四号
        'bold': False,
        'name': 'Times New Roman',
        'alignment': 'left'
    },
    'english_keywords_label': {
        'size': Pt(12),  # 小四号
        'bold': True,
        'name': 'Times New Roman',
        'alignment': 'left'
    },
    'english_keywords_content': {
        'size': Pt(12),  # 小四号
        'bold': False,
        'name': 'Times New Roman',
        'alignment': 'left'
    }
}

# ==================== 段落间距 ====================
PARAGRAPH_SPACING = {
    'before_title': 0,      # 标题段前间距
    'after_title': 0,       # 标题段后间距
    'before_paragraph': 0,  # 正文段前间距
    'after_paragraph': 0,   # 正文段后间距
    'line_spacing': 20      # 行距（固定值）
}

# ==================== 文档结构识别 ====================
DOCUMENT_SECTIONS = {
    'cover': ['题目', '副标题', '专业', '班级', '学生姓名', '指导教师'],
    'abstract': ['摘要', '关键词'],
    'body': ['正文', '引言', '第一章', '第二章', '第三章'],
    'references': ['参考文献', 'References'],
    'english_abstract': ['Title', 'Abstract', 'Key Words']
}
