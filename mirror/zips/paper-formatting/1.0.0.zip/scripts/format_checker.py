"""
论文格式修改技能 - 格式检查模块
检查文档格式是否符合规范，生成检查报告
"""

import json
import sys
import os
from typing import Dict, List, Any, Tuple
from docx.shared import Pt, Cm
from docx import Document

# 导入配置
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)
from config import FONT_FORMATS, PAGE_SETTINGS, PARAGRAPH_SPACING
from document_parser import DocumentParser


class FormatChecker:
    """格式检查器"""
    
    def __init__(self, doc_path: str):
        self.doc = Document(doc_path)
        self.parser = DocumentParser(self.doc)
        self.issues = []
        self.checks = []
    
    def check_all(self, discipline: str = 'liberal') -> Dict[str, Any]:
        """执行所有格式检查"""
        self.parser.parse()
        
        report = {
            'overall_score': 100,
            'total_issues': 0,
            'sections': {}
        }
        
        # 检查页面设置
        report['sections']['page_settings'] = self._check_page_settings()
        
        # 检查封面格式
        report['sections']['cover'] = self._check_cover_format()
        
        # 检查摘要格式
        report['sections']['abstract'] = self._check_abstract_format()
        
        # 检查正文格式
        report['sections']['body'] = self._check_body_format(discipline)
        
        # 检查参考文献格式
        report['sections']['references'] = self._check_references_format()
        
        # 检查英文摘要格式
        report['sections']['english_abstract'] = self._check_english_abstract_format()
        
        # 计算总分
        report['overall_score'], report['total_issues'] = self._calculate_score(report)
        
        return report
    
    def _check_page_settings(self) -> Dict[str, Any]:
        """检查页面设置"""
        result = {
            'status': 'pass',
            'issues': []
        }
        
        section = self.doc.sections[0]
        
        # 检查页边距
        top_margin = section.top_margin.cm
        bottom_margin = section.bottom_margin.cm
        left_margin = section.left_margin.cm
        right_margin = section.right_margin.cm
        
        expected = PAGE_SETTINGS
        
        if abs(top_margin - expected['margin_top'].cm) > 0.1:
            result['issues'].append({
                'type': 'error',
                'location': '页面设置',
                'message': f'上边距为 {top_margin:.1f}cm，应为 {expected["margin_top"].cm:.1f}cm'
            })
        
        if abs(bottom_margin - expected['margin_bottom'].cm) > 0.1:
            result['issues'].append({
                'type': 'error',
                'location': '页面设置',
                'message': f'下边距为 {bottom_margin:.1f}cm，应为 {expected["margin_bottom"].cm:.1f}cm'
            })
        
        if abs(left_margin - expected['margin_left'].cm) > 0.1:
            result['issues'].append({
                'type': 'error',
                'location': '页面设置',
                'message': f'左边距为 {left_margin:.1f}cm，应为 {expected["margin_left"].cm:.1f}cm'
            })
        
        if abs(right_margin - expected['margin_right'].cm) > 0.1:
            result['issues'].append({
                'type': 'error',
                'location': '页面设置',
                'message': f'右边距为 {right_margin:.1f}cm，应为 {expected["margin_right"].cm:.1f}cm'
            })
        
        # 检查行距
        for i, para in enumerate(self.doc.paragraphs[:10]):  # 检查前10个段落
            if para.style and hasattr(para.style, 'paragraph_format'):
                pf = para.paragraph_format
                if pf.line_spacing and pf.line_spacing_rule == 4:  # 4 = 固定值
                    if abs(pf.line_spacing.pt - expected['line_spacing']) > 1:
                        result['issues'].append({
                            'type': 'warning',
                            'location': f'第{i+1}段',
                            'message': f'行距为 {pf.line_spacing.pt:.0f}磅，建议设为固定值 {expected["line_spacing"]}磅'
                        })
        
        if result['issues']:
            result['status'] = 'fail'
        
        return result
    
    def _check_cover_format(self) -> Dict[str, Any]:
        """检查封面格式"""
        result = {
            'status': 'pass',
            'issues': []
        }
        
        cover_paras = self.parser.get_section_paragraphs('cover')
        
        if not cover_paras:
            result['issues'].append({
                'type': 'warning',
                'location': '封面',
                'message': '未识别到封面部分'
            })
            result['status'] = 'warning'
            return result
        
        # 检查题目格式
        title_formats = FONT_FORMATS['title']
        for i, para in enumerate(cover_paras[:3]):  # 检查前3个段落（可能包含题目和副标题）
            if para.runs:
                run = para.runs[0]
                # 检查字体
                if run.font.name != title_formats['name']:
                    result['issues'].append({
                        'type': 'error',
                        'location': f'封面第{i+1}行',
                        'message': f'字体为 "{run.font.name}"，应为 "{title_formats["name"]}"'
                    })
                # 检查字号
                actual_size = run.font.size.pt if run.font.size else 0
                if abs(actual_size - title_formats['size'].pt) > 1:
                    result['issues'].append({
                        'type': 'error',
                        'location': f'封面第{i+1}行',
                        'message': f'字号为 {actual_size:.0f}磅，应为 {title_formats["size"].pt:.0f}磅'
                    })
                # 检查对齐
                from docx.enum.text import WD_ALIGN_PARAGRAPH
                alignment_map = {
                    0: 'left',
                    1: 'center',
                    2: 'right',
                    3: 'justify'
                }
                actual_align = alignment_map.get(para.alignment, 'unknown')
                if actual_align != title_formats['alignment']:
                    result['issues'].append({
                        'type': 'warning',
                        'location': f'封面第{i+1}行',
                        'message': f'对齐方式为 "{actual_align}"，建议居中对齐'
                    })
        
        if result['issues']:
            result['status'] = 'fail' if any(i['type'] == 'error' for i in result['issues']) else 'warning'
        
        return result
    
    def _check_abstract_format(self) -> Dict[str, Any]:
        """检查摘要格式"""
        result = {
            'status': 'pass',
            'issues': []
        }
        
        abstract_paras = self.parser.get_section_paragraphs('abstract')
        
        if not abstract_paras:
            result['issues'].append({
                'type': 'warning',
                'location': '摘要',
                'message': '未识别到摘要部分'
            })
            result['status'] = 'warning'
            return result
        
        # 检查"摘要"标签格式
        abstract_label = FONT_FORMATS['abstract_label']
        abstract_content = FONT_FORMATS['abstract_content']
        keywords_label = FONT_FORMATS['keywords_label']
        keywords_content = FONT_FORMATS['keywords_content']
        
        for i, para in enumerate(abstract_paras):
            text = para.text.strip()
            if text.startswith('摘要'):
                # 检查标签格式
                if para.runs and para.runs[0].font.size:
                    actual_size = para.runs[0].font.size.pt
                    if abs(actual_size - abstract_label['size'].pt) > 1:
                        result['issues'].append({
                            'type': 'warning',
                            'location': '摘要标签',
                            'message': f'字号为 {actual_size:.0f}磅，应为 {abstract_label["size"].pt:.0f}磅'
                        })
            elif text.startswith('关键词'):
                # 检查关键词标签格式
                if para.runs and para.runs[0].font.size:
                    actual_size = para.runs[0].font.size.pt
                    if abs(actual_size - keywords_label['size'].pt) > 1:
                        result['issues'].append({
                            'type': 'warning',
                            'location': '关键词标签',
                            'message': f'字号为 {actual_size:.0f}磅，应为 {keywords_label["size"].pt:.0f}磅'
                        })
        
        if result['issues']:
            result['status'] = 'fail' if any(i['type'] == 'error' for i in result['issues']) else 'warning'
        
        return result
    
    def _check_body_format(self, discipline: str) -> Dict[str, Any]:
        """检查正文格式"""
        result = {
            'status': 'pass',
            'issues': []
        }
        
        body_paras = self.parser.get_section_paragraphs('body')
        
        if not body_paras:
            result['issues'].append({
                'type': 'warning',
                'location': '正文',
                'message': '未识别到正文部分'
            })
            result['status'] = 'warning'
            return result
        
        body_format = FONT_FORMATS['body_content']
        
        # 检查前20个正文段落
        for i, para in enumerate(body_paras[:20]):
            if not para.text.strip():
                continue
            
            # 检查字体
            if para.runs and para.runs[0].font.name:
                actual_font = para.runs[0].font.name
                if actual_font != body_format['name']:
                    result['issues'].append({
                        'type': 'warning',
                        'location': f'正文第{i+1}段',
                        'message': f'字体为 "{actual_font}"，应为 "{body_format["name"]}"'
                    })
            
            # 检查字号
            if para.runs and para.runs[0].font.size:
                actual_size = para.runs[0].font.size.pt
                if abs(actual_size - body_format['size'].pt) > 1:
                    result['issues'].append({
                        'type': 'warning',
                        'location': f'正文第{i+1}段',
                        'message': f'字号为 {actual_size:.0f}磅，应为 {body_format["size"].pt:.0f}磅'
                    })
            
            # 检查标题层级
            text = para.text.strip()
            level = self.parser.identify_title_level(text, discipline)
            if level > 0:
                header_key = f'header_{level}'
                if discipline == 'tech' and level <= 3:
                    header_key = f'tech_header_{level}'
                
                if header_key in FONT_FORMATS:
                    header_format = FONT_FORMATS[header_key]
                    if para.runs and para.runs[0].font.name:
                        if para.runs[0].font.name != header_format['name']:
                            result['issues'].append({
                                'type': 'warning',
                                'location': f'标题"{text[:20]}..."',
                                'message': f'标题{level}字体为 "{para.runs[0].font.name}"，应为 "{header_format["name"]}"'
                            })
        
        if result['issues']:
            result['status'] = 'fail' if any(i['type'] == 'error' for i in result['issues']) else 'warning'
        
        return result
    
    def _check_references_format(self) -> Dict[str, Any]:
        """检查参考文献格式"""
        result = {
            'status': 'pass',
            'issues': []
        }
        
        refs_paras = self.parser.get_section_paragraphs('references')
        
        if not refs_paras:
            result['issues'].append({
                'type': 'warning',
                'location': '参考文献',
                'message': '未识别到参考文献部分'
            })
            result['status'] = 'warning'
            return result
        
        # 检查参考文献标题
        refs_label = FONT_FORMATS['references_label']
        refs_content = FONT_FORMATS['references_content']
        
        if refs_paras and refs_paras[0].text.strip() in ['参考文献', '参考文献：']:
            if refs_paras[0].runs and refs_paras[0].runs[0].font.size:
                actual_size = refs_paras[0].runs[0].font.size.pt
                if abs(actual_size - refs_label['size'].pt) > 1:
                    result['issues'].append({
                        'type': 'warning',
                        'location': '参考文献标题',
                        'message': f'字号为 {actual_size:.0f}磅，应为 {refs_label["size"].pt:.0f}磅'
                    })
        
        if result['issues']:
            result['status'] = 'fail' if any(i['type'] == 'error' for i in result['issues']) else 'warning'
        
        return result
    
    def _check_english_abstract_format(self) -> Dict[str, Any]:
        """检查英文摘要格式"""
        result = {
            'status': 'pass',
            'issues': []
        }
        
        english_paras = self.parser.get_section_paragraphs('english_abstract')
        
        if not english_paras:
            result['issues'].append({
                'type': 'info',
                'location': '英文摘要',
                'message': '未识别到英文摘要部分（可选）'
            })
            return result
        
        # 检查英文标题
        eng_title = FONT_FORMATS['english_title']
        
        for para in english_paras[:3]:
            text = para.text.strip()
            if text.startswith('Title') or (text and not text.startswith('Abstract') and not text.startswith('Key Words')):
                if para.runs and para.runs[0].font.size:
                    actual_size = para.runs[0].font.size.pt
                    if abs(actual_size - eng_title['size'].pt) > 1:
                        result['issues'].append({
                            'type': 'warning',
                            'location': '英文标题',
                            'message': f'字号为 {actual_size:.0f}磅，应为 {eng_title["size"].pt:.0f}磅'
                        })
                break
        
        if result['issues']:
            result['status'] = 'fail' if any(i['type'] == 'error' for i in result['issues']) else 'warning'
        
        return result
    
    def _calculate_score(self, report: Dict[str, Any]) -> Tuple[int, int]:
        """计算总分和问题数量"""
        total_issues = 0
        error_count = 0
        
        for section, data in report['sections'].items():
            for issue in data.get('issues', []):
                total_issues += 1
                if issue['type'] == 'error':
                    error_count += 1
        
        # 每个错误扣10分，每个警告扣5分
        score = 100 - (error_count * 10) - ((total_issues - error_count) * 5)
        score = max(0, score)  # 不低于0分
        
        return score, total_issues
    
    def generate_markdown_report(self) -> str:
        """生成 Markdown 格式的检查报告"""
        report = self.check_all()
        
        md = []
        md.append("# 论文格式检查报告\n")
        md.append(f"**总体评分**: {report['overall_score']}/100\n")
        md.append(f"**发现问题**: {report['total_issues']} 个\n\n")
        md.append("---\n\n")
        
        for section_name, section_data in report['sections'].items():
            md.append(f"## {section_name.replace('_', ' ').title()}\n")
            md.append(f"**状态**: {section_data['status']}\n\n")
            
            if section_data['issues']:
                md.append("**问题列表**:\n\n")
                for issue in section_data['issues']:
                    if issue['type'] == 'error':
                        icon = '[错误]'
                    elif issue['type'] == 'warning':
                        icon = '[警告]'
                    else:
                        icon = '[信息]'
                    md.append(f"- {icon} **{issue['location']}**: {issue['message']}\n")
            else:
                md.append("[通过] 检查通过，未发现问题\n")
            
            md.append("\n---\n\n")
        
        return ''.join(md)
