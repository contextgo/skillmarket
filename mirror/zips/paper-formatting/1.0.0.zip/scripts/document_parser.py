"""
论文格式修改技能 - 文档结构解析模块
采用两阶段策略：
  阶段1（parse）：逐段识别内容类型（cover/abstract/body/references等）
  阶段2（classify_sections）：汇总相邻段落为逻辑部分（封面/摘要/正文/参考文献）
"""

import re
from typing import Dict, List, Optional, Tuple
from docx import Document
from docx.text.paragraph import Paragraph


class ParagraphType:
    """段落类型常量"""
    # 封面相关
    COVER_TITLE = 'cover_title'          # 文档标题（封面大标题）
    COVER_INFO = 'cover_info'            # 封面信息（专业、学生姓名等）
    # 摘要相关
    ABSTRACT_LABEL = 'abstract_label'    # "摘要"标签
    ABSTRACT_CONTENT = 'abstract_content'# 摘要正文
    KEYWORDS_LABEL = 'keywords_label'    # "关键词"标签
    KEYWORDS_CONTENT = 'keywords_content'# 关键词内容
    # 正文相关
    TITLE_L1 = 'title_l1'                # 一、二、三、
    TITLE_L2 = 'title_l2'                # （一）（二）（三）
    TITLE_L3 = 'title_l3'                # 1. 2. 3.
    TITLE_L4 = 'title_l4'                # （1）（2）（3）
    TITLE_L5 = 'title_l5'                # 1）2）3）
    BODY_PARAGRAPH = 'body_para'         # 正文段落
    # 参考文献
    REFERENCES_LABEL = 'references_label' # "参考文献"标签
    REFERENCES_ITEM = 'references_item'   # 参考文献条目
    # 英文摘要
    EN_TITLE = 'en_title'                # Title
    EN_ABSTRACT_LABEL = 'en_abstract_label'  # Abstract
    EN_ABSTRACT_CONTENT = 'en_abstract_content'
    EN_KEYWORDS_LABEL = 'en_keywords_label' # Key Words
    EN_KEYWORDS_CONTENT = 'en_keywords_content'
    UNKNOWN = 'unknown'


class SectionType:
    """文档部分类型"""
    COVER = 'cover'
    ABSTRACT = 'abstract'
    BODY = 'body'
    REFERENCES = 'references'
    ENGLISH_ABSTRACT = 'english_abstract'
    UNKNOWN = 'unknown'


class ParsedParagraph:
    """解析后的段落信息"""
    def __init__(self, index: int, text: str, para_type: str, section: str,
                 level: int = 0, discipline: str = 'liberal'):
        self.index = index      # 段落索引
        self.text = text        # 段落文本
        self.type = para_type   # 段落类型
        self.section = section  # 所属部分
        self.level = level      # 标题层级（0表示非标题）
        self.discipline = discipline

    def __repr__(self):
        return f"<ParsedParagraph [{self.index}] {self.type}: {self.text[:30]}>"


class DocumentParser:
    """
    文档解析器，采用两阶段策略：
    1. parse(): 逐段识别内容类型
    2. classify_sections(): 汇总为逻辑部分
    """

    def __init__(self, doc: Document, discipline: str = 'liberal'):
        self.doc = doc
        self.discipline = discipline
        self.parsed_paragraphs: List[ParsedParagraph] = []
        self.sections: Dict[str, List[int]] = {
            'cover': [],
            'abstract': [],
            'body': [],
            'references': [],
            'english_abstract': []
        }

    def parse(self) -> List[ParsedParagraph]:
        """
        阶段1：逐段识别内容类型
        返回所有解析后的段落列表
        """
        self.parsed_paragraphs = []
        current_section = SectionType.UNKNOWN

        for i, para in enumerate(self.doc.paragraphs):
            text = para.text.strip()

            # 跳过空段落
            if not text:
                continue

            # 识别段落类型和所在部分
            para_type, new_section, level = self._classify_paragraph(text, current_section)

            # 更新当前部分
            if new_section != SectionType.UNKNOWN:
                current_section = new_section

            parsed = ParsedParagraph(
                index=i,
                text=text,
                para_type=para_type,
                section=current_section,
                level=level,
                discipline=self.discipline
            )
            self.parsed_paragraphs.append(parsed)

        # 阶段2：根据段落类型汇总逻辑部分
        self._classify_sections()

        return self.parsed_paragraphs

    def _classify_paragraph(self, text: str, current_section: str) -> Tuple[str, str, int]:
        """
        分类单个段落
        返回: (段落类型, 所属部分, 标题层级)
        """
        # === 1. 首先检查是否为各部分的标题标签（这些会切换部分）===

        # 参考文献标题 - 切换到参考文献部分
        if self._is_references_title(text):
            return ParagraphType.REFERENCES_LABEL, SectionType.REFERENCES, 0

        # 英文摘要标题 - 切换到英文摘要部分
        if self._is_english_title(text):
            return self._classify_english_section(text), SectionType.ENGLISH_ABSTRACT, 0

        # 中文摘要标签 - 切换到摘要部分
        if (text.startswith('摘要') or text.startswith('【摘要】') or text.startswith('【摘要】')):
            return ParagraphType.ABSTRACT_LABEL, SectionType.ABSTRACT, 0

        # 关键词标签 - 保持在摘要部分
        if (text.startswith('关键词') or text.startswith('【关键词】')):
            return ParagraphType.KEYWORDS_LABEL, SectionType.ABSTRACT, 0

        # === 2. 根据当前部分判断段落类型 ===

        if current_section == SectionType.ABSTRACT:
            # 摘要部分 - 但遇到正文标题时要切换
            if text.startswith('关键词'):
                return ParagraphType.KEYWORDS_LABEL, SectionType.ABSTRACT, 0
            elif self._is_keywords_content(text):
                return ParagraphType.KEYWORDS_CONTENT, SectionType.ABSTRACT, 0

            # 检查是否为正文标题（这会切换到正文部分）
            body_level = self._identify_title_level(text)
            if body_level > 0:
                level_type_map = {
                    1: ParagraphType.TITLE_L1,
                    2: ParagraphType.TITLE_L2,
                    3: ParagraphType.TITLE_L3,
                    4: ParagraphType.TITLE_L4,
                    5: ParagraphType.TITLE_L5
                }
                return level_type_map.get(body_level, ParagraphType.BODY_PARAGRAPH), SectionType.BODY, body_level

            # 摘要正文
            return ParagraphType.ABSTRACT_CONTENT, SectionType.ABSTRACT, 0

        if current_section == SectionType.REFERENCES:
            # 参考文献部分
            return ParagraphType.REFERENCES_ITEM, SectionType.REFERENCES, 0

        if current_section == SectionType.ENGLISH_ABSTRACT:
            # 英文摘要部分
            return self._classify_english_content(text), SectionType.ENGLISH_ABSTRACT, 0

        if current_section == SectionType.BODY:
            # 正文部分 - 判断是否为标题
            level = self._identify_title_level(text)
            if level > 0:
                level_type_map = {
                    1: ParagraphType.TITLE_L1,
                    2: ParagraphType.TITLE_L2,
                    3: ParagraphType.TITLE_L3,
                    4: ParagraphType.TITLE_L4,
                    5: ParagraphType.TITLE_L5
                }
                return level_type_map.get(level, ParagraphType.BODY_PARAGRAPH), SectionType.BODY, level
            # 正文段落
            return ParagraphType.BODY_PARAGRAPH, SectionType.BODY, 0

        # === 3. UNKNOWN 部分：判断是封面还是正文开始 ===

        # 检查是否为正文标题（这会切换到正文部分）
        body_level = self._identify_title_level(text)
        if body_level > 0:
            # 这是正文部分的标题
            level_type_map = {
                1: ParagraphType.TITLE_L1,
                2: ParagraphType.TITLE_L2,
                3: ParagraphType.TITLE_L3,
                4: ParagraphType.TITLE_L4,
                5: ParagraphType.TITLE_L5
            }
            return level_type_map.get(body_level, ParagraphType.BODY_PARAGRAPH), SectionType.BODY, body_level

        # 检查是否为正文内容（不以标题开始的正文）
        if self._is_body_content(text):
            return ParagraphType.BODY_PARAGRAPH, SectionType.BODY, 0

        # 默认认为是封面部分
        if self._is_cover_info(text):
            return ParagraphType.COVER_INFO, SectionType.COVER, 0
        else:
            # 封面标题
            return ParagraphType.COVER_TITLE, SectionType.COVER, 0

    def _is_references_title(self, text: str) -> bool:
        """判断是否为参考文献标题"""
        text_lower = text.lower().strip()
        return text in ['参考文献', '参考文献：', 'References', 'reference', '参考文献:'] or text_lower == 'references'

    def _is_english_title(self, text: str) -> bool:
        """判断是否为英文摘要标题"""
        text_lower = text.lower().strip()
        return text_lower.startswith('title') or text_lower.startswith('abstract') or text_lower.startswith('key words')

    def _is_cover_info(self, text: str) -> bool:
        """判断是否为封面信息（专业、班级、学生等）"""
        cover_keywords = ['专业', '班级', '学号', '学生姓名', '指导教师', '学    院',
                          '学院', '学校', '年月日', '日期']
        return any(keyword in text for keyword in cover_keywords)

    def _is_keywords_content(self, text: str) -> bool:
        """判断是否为关键词内容（通常用分号分隔）"""
        return '；' in text or ';' in text

    def _is_body_content(self, text: str) -> bool:
        """
        判断是否为正文内容
        正文内容通常较长，且有明确的句子结构
        """
        # 太短的通常不是正文
        if len(text) < 10:
            return False
        # 检查是否包含常见的中文标点（句子结构）
        if '。' in text or '；' in text or '，' in text:
            return True
        # 检查是否像正文段落（以常见开头词）
        body_starters = ['随着', '近年来', '目前', '本文', '首先', '其次', '最后',
                         '因此', '然而', '但是', '由于', '所以', '总之', '一方面']
        for starter in body_starters:
            if text.startswith(starter):
                return True
        return False

    def _classify_english_section(self, text: str) -> str:
        """分类英文摘要部分的标题"""
        text_lower = text.lower().strip()
        if text_lower.startswith('title'):
            return ParagraphType.EN_TITLE
        elif text_lower.startswith('abstract'):
            return ParagraphType.EN_ABSTRACT_LABEL
        elif text_lower.startswith('key words'):
            return ParagraphType.EN_KEYWORDS_LABEL
        return ParagraphType.UNKNOWN

    def _classify_english_content(self, text: str) -> str:
        """分类英文摘要内容"""
        # 包含大量英文视为英文内容
        english_ratio = self._get_english_ratio(text)
        if english_ratio > 0.5:
            return ParagraphType.EN_ABSTRACT_CONTENT
        return ParagraphType.EN_KEYWORDS_CONTENT

    def _classify_sections(self):
        """阶段2：汇总逻辑部分"""
        self.sections = {
            'cover': [],
            'abstract': [],
            'body': [],
            'references': [],
            'english_abstract': []
        }

        for parsed in self.parsed_paragraphs:
            if parsed.section in self.sections:
                self.sections[parsed.section].append(parsed.index)

    def _identify_title_level(self, text: str) -> int:
        """
        识别标题层级
        返回: 1-5 级标题，0 表示不是标题
        """
        if self.discipline == 'liberal':
            # 文经管法格式
            # 第五层: 1) 2) 3)
            if re.match(r'^[0-9]+）[\s\u4e00-\u9fff]', text):
                return 5
            # 第四层: （1）（2）（3）
            if re.match(r'^（[0-9]+）[\s\u4e00-\u9fff]', text):
                return 4
            # 第三层: 1. 2. 3.
            if re.match(r'^[0-9]+\.[\s\u4e00-\u9fff]', text):
                return 3
            # 第二层: （一）（二）（三）
            if re.match(r'^（[一二三四五六七八九十]+）[\s\u4e00-\u9fff]', text):
                return 2
            # 第一层: 一、二、三、
            if re.match(r'^[一二三四五六七八九十]+、[\s\u4e00-\u9fff]', text):
                return 1
        else:
            # 理工类格式
            # 第三层: 1.1.1
            if re.match(r'^[1-9]+\.[1-9]+\.[1-9]+[\s\u4e00-\u9fff]', text):
                return 3
            # 第二层: 1.1
            if re.match(r'^[1-9]+\.[1-9]+[\s\u4e00-\u9fff]', text):
                return 2
            # 第一层: 1 2 3
            if re.match(r'^[1-9]+[\s\u4e00-\u9fff]', text):
                return 1

        return 0

    def _get_english_ratio(self, text: str) -> float:
        """计算英文占比"""
        english_chars = re.findall(r'[a-zA-Z]', text)
        return len(english_chars) / len(text) if text else 0

    def get_section_paragraphs(self, section: str) -> List[Paragraph]:
        """获取指定部分的所有段落对象"""
        indices = self.sections.get(section, [])
        return [self.doc.paragraphs[i] for i in indices]

    def get_parsed_paragraphs(self) -> List[ParsedParagraph]:
        """获取所有解析后的段落"""
        return self.parsed_paragraphs

    def get_parsed_by_type(self, para_type: str) -> List[ParsedParagraph]:
        """获取指定类型的所有段落"""
        return [p for p in self.parsed_paragraphs if p.type == para_type]

    def get_parsed_by_section(self, section: str) -> List[ParsedParagraph]:
        """获取指定部分的所有段落"""
        return [p for p in self.parsed_paragraphs if p.section == section]

    def debug_print(self):
        """打印解析结果（调试用）"""
        print("\n=== 文档结构解析结果 ===")
        print(f"{'索引':<4} {'段落类型':<22} {'所属部分':<14} {'层级':<4} {'内容预览':<40}")
        print("-" * 95)
        for p in self.parsed_paragraphs:
            preview = p.text[:35].replace('\n', ' ')
            print(f"{p.index:<4} {p.type:<22} {p.section:<14} {p.level:<4} {preview:<40}")