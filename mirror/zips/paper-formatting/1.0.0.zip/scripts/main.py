#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
论文格式修改技能 - 主程序
提供命令行接口和API接口
"""

import sys
import os
import argparse
from pathlib import Path

# 设置输出编码
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 添加脚本目录到Python路径
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from format_checker import FormatChecker
from format_applier import FormatApplier


def check_format(doc_path: str, discipline: str = 'liberal', output: str = None):
    """检查文档格式"""
    print(f"\n{'='*60}")
    print(f"检查文档格式: {doc_path}")
    print(f"{'='*60}\n")
    
    checker = FormatChecker(doc_path)
    report = checker.check_all(discipline)
    
    # 打印报告
    print(f"总体评分: {report['overall_score']}/100")
    print(f"发现问题: {report['total_issues']} 个\n")
    
    for section_name, section_data in report['sections'].items():
        print(f"\n{section_name.replace('_', ' ').title()}")
        print(f"状态: {section_data['status']}")
        
        if section_data['issues']:
            print("问题列表:")
            for issue in section_data['issues']:
                if issue['type'] == 'error':
                    icon = '[错误]'
                elif issue['type'] == 'warning':
                    icon = '[警告]'
                else:
                    icon = '[信息]'
                print(f"  {icon} [{issue['location']}] {issue['message']}")
        else:
            print("[通过] 检查通过")
    
    # 保存报告
    if output:
        md_report = checker.generate_markdown_report()
        with open(output, 'w', encoding='utf-8') as f:
            f.write(md_report)
        print(f"\n报告已保存至: {output}")
    
    return report['overall_score']


def apply_format(doc_path: str, output_path: str = None, discipline: str = 'liberal', 
                 check_only: bool = False):
    """应用格式到文档"""
    
    if not os.path.exists(doc_path):
        print(f"错误: 文件不存在 - {doc_path}")
        return False
    
    # 生成输出路径
    if not output_path:
        if check_only:
            output_path = doc_path.replace('.docx', '_check_report.md')
        else:
            base, ext = os.path.splitext(doc_path)
            output_path = f"{base}_formatted{ext}"
    
    print(f"\n{'='*60}")
    print(f"处理文档: {doc_path}")
    print(f"学科类别: {'文经管法' if discipline == 'liberal' else '理工类'}")
    print(f"模式: {'仅检查' if check_only else '应用格式'}")
    print(f"{'='*60}\n")
    
    if check_only:
        # 仅检查模式
        score = check_format(doc_path, discipline, output_path)
        print(f"\n检查完成！总体评分: {score}/100")
        return True
    
    # 格式化模式
    applier = FormatApplier(doc_path, discipline)
    changes = applier.apply_all_formats()
    
    # 保存文档
    applier.save_document(output_path)
    print(f"\n✓ 格式化完成！")
    print(f"输出文件: {output_path}\n")
    
    # 打印修改内容
    print("格式修改内容:")
    print("-" * 40)
    for section, section_changes in changes.items():
        if section_changes:
            print(f"\n{section.replace('_', ' ').title()}:")
            for change in section_changes:
                print(f"  - {change}")
    
    # 生成修改报告
    report_path = output_path.replace('.docx', '_report.md')
    md_report = applier.generate_change_report(changes)
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(md_report)
    print(f"\n修改报告已保存至: {report_path}")
    
    return True


def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(
        description='论文格式修改工具 - 根据《本科生优秀毕业论文（设计）选集》稿件格式要求自动调整Word论文格式',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 检查格式（文经管法）
  python main.py check 论文.docx
  
  # 检查格式（理工类）
  python main.py check 论文.docx --discipline tech
  
  # 应用格式
  python main.py format 论文.docx
  
  # 应用格式并指定输出文件
  python main.py format 论文.docx --output 格式化后的论文.docx
  
  # 仅检查不修改
  python main.py format 论文.docx --check-only
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # 检查命令
    check_parser = subparsers.add_parser('check', help='检查文档格式')
    check_parser.add_argument('document', help='Word文档路径')
    check_parser.add_argument('--discipline', choices=['liberal', 'tech'], 
                            default='liberal', help='学科类别（liberal=文经管法，tech=理工类）')
    check_parser.add_argument('-o', '--output', help='报告输出路径')
    
    # 格式化命令
    format_parser = subparsers.add_parser('format', help='应用格式到文档')
    format_parser.add_argument('document', help='Word文档路径')
    format_parser.add_argument('--discipline', choices=['liberal', 'tech'], 
                              default='liberal', help='学科类别（liberal=文经管法，tech=理工类）')
    format_parser.add_argument('-o', '--output', help='输出文档路径')
    format_parser.add_argument('--check-only', action='store_true', 
                              help='仅检查格式，不进行修改')
    
    args = parser.parse_args()
    
    if args.command == 'check':
        check_format(args.document, args.discipline, args.output)
    elif args.command == 'format':
        apply_format(args.document, args.output, args.discipline, args.check_only)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
