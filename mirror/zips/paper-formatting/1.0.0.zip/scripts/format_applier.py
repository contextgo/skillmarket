"""
论文格式修改技能 - 格式应用模块
根据段落类型应用相应格式（两阶段策略）
"""

import os
import re
from typing import Dict, List
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING

# 导入配置和解析器
script_dir = os.path.dirname(os.path.abspath(__file__))
import sys
sys.path.insert(0, script_dir)

from config import FONT_FORMATS, PAGE_SETTINGS
from document_parser import DocumentParser, ParagraphType, SectionType


class FormatApplier:
    """
    格式应用器 - 基于段落类型的两阶段格式应用
    阶段1：解析文档结构（使用DocumentParser）
    阶段2：根据段落类型应用格式
    """

    def __init__(self, doc_path: str, discipline: str = 'liberal'):
        self.doc = Document(doc_path)
        self.parser = DocumentParser(self.doc, discipline)
        self.discipline = discipline
        self.changes: List[str] = []

    def apply_all_formats(self) -> Dict[str, List[str]]:
        """应用所有格式设置"""
        # 阶段1：解析文档结构
        self.parser.parse()

        # 可选：打印解析结果用于调试
        # self.parser.debug_print()

        changes = {
            'page_settings': self._apply_page_settings(),
            'cover': self._apply_cover_format(),
            'abstract': self._apply_abstract_format(),
            'body': self._apply_body_format(),
            'references': self._apply_references_format(),
            'english_abstract': self._apply_english_abstract_format()
        }

        return changes

    # ==================== 页面设置 ====================

    def _apply_page_settings(self) -> List[str]:
        """应用页面设置"""
        changes = []
        section = self.doc.sections[0]

        # 设置页边距
        section.top_margin = PAGE_SETTINGS['margin_top']
        section.bottom_margin = PAGE_SETTINGS['margin_bottom']
        section.left_margin = PAGE_SETTINGS['margin_left']
        section.right_margin = PAGE_SETTINGS['margin_right']

        changes.append("设置页边距：上下左右均为 2.5cm")

        # 设置行距（应用于所有段落）
        for para in self.doc.paragraphs:
            if para.text.strip():
                para.paragraph_format.line_spacing = Pt(PAGE_SETTINGS['line_spacing'])
                para.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY

        changes.append("设置行距：固定值 20磅")

        return changes

    # ==================== 封面格式 ====================

    def _apply_cover_format(self) -> List[str]:
        """应用封面格式"""
        changes = []

        cover_paragraphs = self.parser.get_parsed_by_section(SectionType.COVER)

        if not cover_paragraphs:
            changes.append("警告: 未识别到封面部分，请手动检查")
            return changes

        title_format = FONT_FORMATS['document_title']
        info_format = FONT_FORMATS['author_info']

        for parsed in cover_paragraphs:
            para = self.doc.paragraphs[parsed.index]
            if parsed.type == ParagraphType.COVER_TITLE:
                self._apply_paragraph_format(para, title_format)
                changes.append("设置文档主标题格式：三号黑体居中")
            elif parsed.type == ParagraphType.COVER_INFO:
                self._apply_paragraph_format(para, info_format)
                changes.append("设置封面信息格式：小四号楷体居中")

        return changes

    # ==================== 摘要格式 ====================

    def _apply_abstract_format(self) -> List[str]:
        """应用摘要格式"""
        changes = []

        abstract_paragraphs = self.parser.get_parsed_by_section(SectionType.ABSTRACT)

        if not abstract_paragraphs:
            changes.append("警告: 未识别到摘要部分，请手动检查")
            return changes

        abstract_label_format = FONT_FORMATS['abstract_label']
        abstract_content_format = FONT_FORMATS['abstract_content']
        keywords_label_format = FONT_FORMATS['keywords_label']
        keywords_content_format = FONT_FORMATS['keywords_content']

        for parsed in abstract_paragraphs:
            para = self.doc.paragraphs[parsed.index]
            text = parsed.text

            if parsed.type == ParagraphType.ABSTRACT_LABEL:
                # 识别标签（可能是"摘要"、"【摘要】"等）
                label_text = self._extract_label_text(text, ['摘要', '【摘要】', '【摘要】'])
                self._apply_mixed_label_format(para, label_text, abstract_label_format, abstract_content_format)
                changes.append("设置摘要标签格式：小四号黑体")

            elif parsed.type == ParagraphType.ABSTRACT_CONTENT:
                self._apply_paragraph_format(para, abstract_content_format)
                changes.append("设置摘要内容格式：五号楷体")

            elif parsed.type == ParagraphType.KEYWORDS_LABEL:
                # 识别标签（可能是"关键词"、"【关键词】"等）
                label_text = self._extract_label_text(text, ['关键词', '【关键词】', '【关键词】'])
                self._apply_mixed_label_format(para, label_text, keywords_label_format, keywords_content_format)
                changes.append("设置关键词标签格式：小四号黑体")

            elif parsed.type == ParagraphType.KEYWORDS_CONTENT:
                self._apply_paragraph_format(para, keywords_content_format)
                changes.append("设置关键词内容格式：五号楷体（分号分隔）")

        return changes

    def _extract_label_text(self, text: str, label_candidates: List[str]) -> str:
        """从文本中提取标签文本"""
        for label in label_candidates:
            if label in text:
                return label
        # 默认返回第一个候选
        return label_candidates[0] if label_candidates else ''

    # ==================== 正文格式 ====================

    def _apply_body_format(self) -> List[str]:
        """应用正文格式"""
        changes = []

        body_paragraphs = self.parser.get_parsed_by_section(SectionType.BODY)

        if not body_paragraphs:
            changes.append("警告: 未识别到正文部分，请手动检查")
            return changes

        body_format = FONT_FORMATS['body_content']
        header_counters = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}

        for parsed in body_paragraphs:
            para = self.doc.paragraphs[parsed.index]

            if parsed.type.startswith('title_l'):
                # 标题段落
                level = parsed.level
                header_key = f'header_{level}'
                if self.discipline == 'tech' and level <= 3:
                    header_key = f'tech_header_{level}'

                if header_key in FONT_FORMATS:
                    header_format = FONT_FORMATS[header_key]
                    # 标题只设置标题前缀的格式，内容保持正文格式
                    self._apply_header_format(para, header_format, body_format, level, self.discipline)
                    header_counters[level] += 1
            else:
                # 正文段落
                self._apply_paragraph_format(para, body_format)

        changes.append(f"设置正文格式：五号宋体（英文 Times New Roman 12）")
        total_headers = sum(header_counters.values())
        changes.append(f"识别并格式化标题：{total_headers} 个")

        for level, count in sorted(header_counters.items()):
            if count > 0:
                level_name = '一级' if level == 1 else f'标题{level}'
                changes.append(f"  - {level_name}：{count} 个")

        return changes

    # ==================== 参考文献格式 ====================

    def _apply_references_format(self) -> List[str]:
        """应用参考文献格式"""
        changes = []

        ref_paragraphs = self.parser.get_parsed_by_section(SectionType.REFERENCES)

        if not ref_paragraphs:
            changes.append("警告: 未识别到参考文献部分，请手动检查")
            return changes

        ref_label_format = FONT_FORMATS['references_label']
        ref_content_format = FONT_FORMATS['references_content']

        for parsed in ref_paragraphs:
            para = self.doc.paragraphs[parsed.index]

            if parsed.type == ParagraphType.REFERENCES_LABEL:
                self._apply_paragraph_format(para, ref_label_format)
                changes.append("设置参考文献标题格式：四号黑体居中")
            else:
                self._apply_paragraph_format(para, ref_content_format)
                changes.append("设置参考文献内容格式：五号宋体")

        return changes

    # ==================== 英文摘要格式 ====================

    def _apply_english_abstract_format(self) -> List[str]:
        """应用英文摘要格式"""
        changes = []

        en_paragraphs = self.parser.get_parsed_by_section(SectionType.ENGLISH_ABSTRACT)

        if not en_paragraphs:
            changes.append("信息: 未识别到英文摘要部分（可选）")
            return changes

        en_title_format = FONT_FORMATS['english_title']
        en_label_format = FONT_FORMATS['english_abstract_label']
        en_content_format = FONT_FORMATS['english_abstract_content']
        en_keywords_label_format = FONT_FORMATS['english_keywords_label']
        en_keywords_content_format = FONT_FORMATS['english_keywords_content']

        for parsed in en_paragraphs:
            para = self.doc.paragraphs[parsed.index]

            if parsed.type == ParagraphType.EN_TITLE:
                self._apply_paragraph_format(para, en_title_format)
                changes.append("设置英文标题格式：三号加黑 Times New Roman 居中")
            elif parsed.type == ParagraphType.EN_ABSTRACT_LABEL:
                self._apply_paragraph_format(para, en_label_format)
                changes.append("设置 Abstract 标签格式：小四号加黑 Times New Roman")
            elif parsed.type == ParagraphType.EN_ABSTRACT_CONTENT:
                self._apply_paragraph_format(para, en_content_format)
                changes.append("设置英文摘要内容格式：小四号 Times New Roman")
            elif parsed.type == ParagraphType.EN_KEYWORDS_LABEL:
                self._apply_paragraph_format(para, en_keywords_label_format)
                changes.append("设置 Key Words 标签格式：小四号加黑 Times New Roman")
            elif parsed.type == ParagraphType.EN_KEYWORDS_CONTENT:
                self._apply_paragraph_format(para, en_keywords_content_format)
                changes.append("设置英文关键词内容格式：小四号 Times New Roman（分号分隔）")

        return changes

    # ==================== 辅助方法 ====================

    def _apply_paragraph_format(self, para, format_config: Dict):
        """应用段落格式到所有run"""
        # 字体格式
        for run in para.runs:
            if format_config.get('name'):
                run.font.name = format_config['name']
                # 设置中英文字体
                run._element.rPr.rFonts.set(
                    '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}ascii',
                    format_config['name'])
                run._element.rPr.rFonts.set(
                    '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia',
                    format_config['name'])
                run._element.rPr.rFonts.set(
                    '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}hAnsi',
                    format_config['name'])

            if format_config.get('size'):
                run.font.size = format_config['size']

            # 强制设置加粗
            if 'bold' in format_config:
                run.font.bold = format_config['bold']
            else:
                run.font.bold = False

        # 段落格式
        alignment_map = {
            'left': WD_ALIGN_PARAGRAPH.LEFT,
            'center': WD_ALIGN_PARAGRAPH.CENTER,
            'right': WD_ALIGN_PARAGRAPH.RIGHT,
            'justify': WD_ALIGN_PARAGRAPH.JUSTIFY
        }
        if format_config.get('alignment'):
            para.alignment = alignment_map.get(format_config['alignment'])

        if format_config.get('first_line_indent'):
            para.paragraph_format.first_line_indent = format_config['first_line_indent']

        if format_config.get('line_spacing'):
            para.paragraph_format.line_spacing = Pt(format_config['line_spacing'])
            para.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY

    def _apply_mixed_label_format(self, para, label_text: str,
                                   label_format: Dict, content_format: Dict):
        """
        应用混合段落格式（标签+内容）
        标签部分应用label_format，内容部分应用content_format
        """
        text = para.text.strip()
        label_pos = text.find(label_text)
        if label_pos == -1:
            label_end = len(label_text)
        else:
            label_end = label_pos + len(label_text)

        # 段落格式（使用标签的格式）
        alignment_map = {
            'left': WD_ALIGN_PARAGRAPH.LEFT,
            'center': WD_ALIGN_PARAGRAPH.CENTER,
            'right': WD_ALIGN_PARAGRAPH.RIGHT,
            'justify': WD_ALIGN_PARAGRAPH.JUSTIFY
        }
        if label_format.get('alignment'):
            para.alignment = alignment_map.get(label_format['alignment'])

        if label_format.get('first_line_indent'):
            para.paragraph_format.first_line_indent = label_format['first_line_indent']

        if label_format.get('line_spacing'):
            para.paragraph_format.line_spacing = Pt(label_format['line_spacing'])
            para.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY

        # 逐run设置格式
        current_pos = 0
        for run in para.runs:
            run_len = len(run.text)
            run_end = current_pos + run_len

            # 判断run属于标签还是内容
            if run_end <= label_end:
                fmt = label_format
            elif current_pos >= label_end:
                fmt = content_format
            else:
                # run跨越标签和内容边界，拆分处理（取标签格式）
                fmt = label_format

            # 应用格式
            if fmt.get('name'):
                run.font.name = fmt['name']
                run._element.rPr.rFonts.set(
                    '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}ascii',
                    fmt['name'])
                run._element.rPr.rFonts.set(
                    '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia',
                    fmt['name'])
                run._element.rPr.rFonts.set(
                    '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}hAnsi',
                    fmt['name'])

            if fmt.get('size'):
                run.font.size = fmt['size']

            if 'bold' in fmt:
                run.font.bold = fmt['bold']
            else:
                run.font.bold = False

            current_pos = run_end

    def _apply_header_format(self, para, header_format: Dict, body_format: Dict,
                              level: int, discipline: str):
        """
        应用标题段落格式
        标题前缀加粗，内容部分保持正文格式
        """
        text = para.text.strip()

        # 确定标题前缀的范围
        header_end = self._get_header_prefix_length(text, level, discipline)

        # 段落格式
        alignment_map = {
            'left': WD_ALIGN_PARAGRAPH.LEFT,
            'center': WD_ALIGN_PARAGRAPH.CENTER,
            'right': WD_ALIGN_PARAGRAPH.RIGHT,
            'justify': WD_ALIGN_PARAGRAPH.JUSTIFY
        }
        if header_format.get('alignment'):
            para.alignment = alignment_map.get(header_format['alignment'])

        if header_format.get('line_spacing'):
            para.paragraph_format.line_spacing = Pt(header_format['line_spacing'])
            para.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY

        # 逐run设置格式
        current_pos = 0
        for run in para.runs:
            run_len = len(run.text)
            run_end = current_pos + run_len

            # 判断run属于标题前缀还是内容
            if current_pos < header_end:
                fmt = header_format
            else:
                fmt = body_format

            # 应用格式
            if fmt.get('name'):
                run.font.name = fmt['name']
                run._element.rPr.rFonts.set(
                    '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}ascii',
                    fmt['name'])
                run._element.rPr.rFonts.set(
                    '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia',
                    fmt['name'])
                run._element.rPr.rFonts.set(
                    '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}hAnsi',
                    fmt['name'])

            if fmt.get('size'):
                run.font.size = fmt['size']

            # 标题加粗，内容不加粗
            if current_pos < header_end:
                run.font.bold = header_format.get('bold', True)
            else:
                run.font.bold = body_format.get('bold', False)

            current_pos = run_end

    def _get_header_prefix_length(self, text: str, level: int, discipline: str) -> int:
        """获取标题前缀的长度"""
        if discipline == 'liberal':
            if level == 1:
                # 一、二、三、
                match = re.match(r'^([一二三四五六七八九十]+、)', text)
            elif level == 2:
                # （一）（二）（三）
                match = re.match(r'^（([一二三四五六七八九十]+)）', text)
            elif level == 3:
                # 1. 2. 3.
                match = re.match(r'^([0-9]+\.)', text)
            elif level == 4:
                # （1）（2）（3）
                match = re.match(r'^（([0-9]+)）', text)
            elif level == 5:
                # 1）2）3）
                match = re.match(r'^([0-9]+）)', text)
            else:
                match = None
        else:
            # 理工类
            if level == 1:
                match = re.match(r'^([1-9]+)', text)
            elif level == 2:
                match = re.match(r'^([1-9]+\.[1-9]+)', text)
            elif level == 3:
                match = re.match(r'^([1-9]+\.[1-9]+\.[1-9]+)', text)
            else:
                match = None

        if match:
            return len(match.group(0))
        return min(10, len(text))

    def save_document(self, output_path: str):
        """保存文档"""
        self.doc.save(output_path)

    def generate_change_report(self, changes: Dict[str, List[str]]) -> str:
        """生成格式修改报告"""
        md = []
        md.append("# 论文格式修改报告\n")
        md.append("---\n\n")

        for section, section_changes in changes.items():
            if not section_changes:
                continue

            section_name_map = {
                'page_settings': '页面设置',
                'cover': '封面',
                'abstract': '摘要',
                'body': '正文',
                'references': '参考文献',
                'english_abstract': '英文摘要'
            }
            name = section_name_map.get(section, section.replace('_', ' ').title())

            md.append(f"## {name}\n\n")

            for change in section_changes:
                md.append(f"- {change}\n")

            md.append("\n---\n\n")

        return ''.join(md)