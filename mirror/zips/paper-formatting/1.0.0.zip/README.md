# 论文格式修改技能

## 简介

本技能专门用于根据《本科生优秀毕业论文（设计）选集》稿件格式要求，自动调整 Word 论文文档的格式。

## 功能特性

- 页面设置：自动设置A4纸型、25mm页边距、20磅固定行距
- 封面格式：题目三号黑体居中、副标题四号黑体居中、专业信息小四号楷体居中
- 摘要格式：摘要/关键词标签小四号黑体、内容五号楷体
- 正文格式：正文五号宋体、支持文经管法和理工类两种标题层级
- 参考文献格式：四号黑体居中标签+五号宋体内容
- 英文摘要格式：Title三号加黑、Abstract/Key Words小四号加黑
- 格式检查：生成详细的格式检查报告，列出所有问题
- 批量处理：支持批量处理多篇论文

## 安装依赖

```bash
pip install python-docx
```

## 使用方法

### 方式一：作为 WorkBuddy 技能使用

在 WorkBuddy 中直接调用：

```
请帮我按照格式要求修改这个论文的格式：论文.docx
```

或者指定学科类别：

```
请帮我修改这篇理工类论文的格式：算法论文.docx
```

仅检查不修改：

```
请检查这篇论文的格式是否符合要求：论文.docx
```

### 方式二：命令行使用

进入技能目录的 scripts 文件夹：

```bash
cd .workbuddy/skills/paper-format-modification/scripts
```

检查文档格式（文经管法）：

```bash
python main.py check 论文.docx
```

检查文档格式（理工类）：

```bash
python main.py check 论文.docx --discipline tech
```

应用格式到文档：

```bash
python main.py format 论文.docx
```

指定输出文件：

```bash
python main.py format 论文.docx --output 格式化后的论文.docx
```

仅检查不修改：

```bash
python main.py format 论文.docx --check-only
```

### 方式三：作为 Python 模块使用

```python
from scripts import FormatChecker, FormatApplier

# 检查格式
checker = FormatChecker('论文.docx')
report = checker.check_all(discipline='liberal')
print(report['overall_score'])

# 应用格式
applier = FormatApplier('论文.docx')
changes = applier.apply_all_formats(discipline='liberal')
applier.save_document('论文_formatted.docx')
```

## 格式要求

### 页面设置
- 纸型：A4
- 页边距：上下左右均为 25mm
- 行距：固定值 20 磅
- 页码：暂不设置

### 字体格式

#### 封面部分
- **题目**：三号黑体，居中
- **副标题**：四号黑体，居中（如有）
- **专业信息**：小四号楷体，居中

#### 摘要部分
- **"摘要"标签**：小四号黑体，空两格
- **摘要内容**：五号楷体
- **"关键词"标签**：小四号黑体，空两格
- **关键词**：3-6个，五号楷体，用分号分隔

#### 正文部分
- **正文内容**：五号宋体（英文为 Times New Roman 12）
- **表格**：采用三线表格式

#### 标题层级

**文经管法类**：
- 第一层：一、二、……（4号黑体）
- 第二层：（一）（二）……（小4号黑体）
- 第三层：1. 2. ……（小4号黑体）
- 第四层：（1）（2）……（5号黑体）
- 第五层：1）2）……（5号黑体）

**理工类**：
- 第一层：1……（4号黑体）
- 第二层：1.1……（小4号黑体）
- 第三层：1.1.1……（小4号黑体）

#### 参考文献部分
- **"参考文献"标签**：四号黑体，居中
- **文献条目**：[1]、[2]……，五号宋体

#### 英文摘要部分
- **Title**：三号加黑，Times New Roman
- **Abstract**：小四号加黑
- **Abstract内容**：小四号
- **Key Words**：小四号加黑
- **关键词**：小四号，用分号分隔

## 输出说明

### 格式化后文档
- 原文件名 + `_formatted.docx`
- 保留原文档内容，仅调整格式

### 检查报告
- 原文件名 + `_check_report.md`
- 包含总体评分、详细检查项、问题列表、修改建议

### 修改报告
- 格式化后文档名 + `_report.md`
- 列出所有格式修改内容

## 注意事项

1. **备份原文件**：技能会自动备份原文件，建议用户也自行备份
2. **文档结构**：技能依赖文档结构识别，请确保文档包含封面、摘要、正文、参考文献等部分
3. **表格格式**：三线表可能需要手动微调
4. **学科类别**：默认为文经管法格式，理工类需明确指定
5. **特殊内容**：公式、复杂表格等可能需要人工检查

## 技能结构

```
paper-format-modification/
├── SKILL.md              # 技能说明文件（符合 skill-creator 规范）
├── README.md             # 使用文档
└── scripts/
    ├── config.py         # 格式配置
    ├── document_parser.py # 文档结构解析
    ├── format_checker.py # 格式检查
    ├── format_applier.py # 格式应用
    └── main.py           # 命令行入口
```

## 示例对话

**用户**：请帮我按照格式要求修改这篇论文的格式，文件是毕业论文.docx

**助手**：好的，我来帮你修改论文格式。正在读取文档并应用格式规范...

[执行格式化...]

**助手**：格式修改完成！主要调整内容：
- 页面设置：A4，页边距25mm，行距20磅
- 封面题目：三号黑体居中
- 摘要：小四号黑体标签+五号楷体内容
- 正文：五号宋体，文经管法标题层级
- 参考文献：四号黑体居中标签+五号宋体内容

修改后的文件保存为：毕业论文_formatted.docx
详细修改报告见：格式修改报告.md

## 版本信息

- 版本：1.0.0
- 作者：WorkBuddy
- 创建日期：2026-04-01
- 依赖：python-docx
