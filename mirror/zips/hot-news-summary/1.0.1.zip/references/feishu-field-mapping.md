# 飞书多维表格字段映射规范

## 目录
- [概述](#概述)
- [标准字段定义](#标准字段定义)
- [字段映射配置](#字段映射配置)
- [使用示例](#使用示例)

## 概述

本文档定义了热点摘要导入到飞书多维表格时的字段映射规范，确保数据正确导入到对应的表格字段中。

## 标准字段定义

### 热点数据字段

| 字段名 | 类型 | 说明 | 示例 |
|--------|------|------|------|
| title | 文本 | 热点标题 | "某科技公司发布重磅新品" |
| comment | 文本 | 犀利幽默点评 | "这波操作比春晚还热闹，网友：终于等到你" |
| analysis | 文本 | 精准分析 | "国产科技突破引发关注，市场反响热烈..." |
| platform | 单选 | 来源平台 | "微博" / "知乎" / "B站" / "百度" |
| heat | 文本 | 热度指数 | "2,500,000" / "500万+" |
| url | 超链接 | 相关链接 | "https://..." |
| timestamp | 日期 | 抓取时间 | "2024-01-15 10:30:00" |
| rank | 数字 | 排名 | 1, 2, 3... |

### 飞书多维表格字段类型对应

| 热点字段 | 飞书字段类型 | 说明 |
|---------|-------------|------|
| title | 多行文本 | 适合较长的标题 |
| comment | 多行文本 | 适合点评内容 |
| analysis | 多行文本 | 适合分析内容 |
| platform | 单选 | 平台选项：微博、知乎、B站、百度 |
| heat | 文本 | 热度数值，保持原始格式 |
| url | 超链接 | 点击跳转 |
| timestamp | 日期 | 自动记录导入时间 |
| rank | 数字 | 热点排名 |

## 字段映射配置

### 默认映射

```json
{
  "title": "标题",
  "comment": "点评",
  "analysis": "分析",
  "platform": "来源平台",
  "heat": "热度",
  "url": "链接",
  "timestamp": "时间"
}
```

### 自定义映射

如果您的多维表格字段名称不同，可以自定义映射：

```json
{
  "title": "热点标题",
  "comment": "犀利点评",
  "analysis": "深度分析",
  "platform": "来源",
  "heat": "热度值",
  "url": "详情链接",
  "timestamp": "创建时间"
}
```

### 多维表格字段创建建议

在飞书多维表格中创建以下字段：

1. **标题**（多行文本）
   - 字段名：标题
   - 描述：热点新闻标题

2. **点评**（多行文本）
   - 字段名：点评
   - 描述：犀利幽默点评

3. **分析**（多行文本）
   - 字段名：分析
   - 描述：精准专业分析

4. **来源平台**（单选）
   - 字段名：来源平台
   - 选项：微博、知乎、B站、百度
   - 描述：热点来源平台

5. **热度**（文本）
   - 字段名：热度
   - 描述：热度指数

6. **链接**（超链接）
   - 字段名：链接
   - 描述：热点详情链接

7. **时间**（日期）
   - 字段名：时间
   - 描述：抓取时间

8. **排名**（数字，可选）
   - 字段名：排名
   - 描述：热点排名

## 使用示例

### 示例1：使用默认映射

```bash
python scripts/export_feishu.py \
  --type bitable \
  --app-token "appXXXXXXXXXXXX" \
  --table-id "tblXXXXXXXXXXXX" \
  --input ./hot_lists.json
```

### 示例2：使用自定义映射

```bash
python scripts/export_feishu.py \
  --type bitable \
  --app-token "appXXXXXXXXXXXX" \
  --table-id "tblXXXXXXXXXXXX" \
  --input ./hot_lists.json \
  --field-mapping '{"title":"热点标题","comment":"犀利点评","analysis":"深度分析","platform":"来源","heat":"热度值","url":"详情链接","timestamp":"创建时间"}'
```

### 示例3：智能体调用

智能体在调用时，应根据用户提供的多维表格信息自动填充参数：

```python
# 智能体收集的信息
app_token = "用户提供的app_token"
table_id = "用户提供的table_id"
field_mapping = {
    "title": "标题",  # 对应用户表格中的字段名
    "comment": "点评",
    "analysis": "分析",
    "platform": "来源平台",
    "heat": "热度",
    "url": "链接",
    "timestamp": "时间"
}

# 构建命令
command = f"""
python scripts/export_feishu.py \
  --type bitable \
  --app-token {app_token} \
  --table-id {table_id} \
  --input ./hot_lists.json \
  --field-mapping '{json.dumps(field_mapping)}'
"""
```

## 注意事项

1. **字段必须存在**：确保多维表格中已创建所有必需字段
2. **字段名称匹配**：映射中的字段名必须与多维表格中的字段名完全一致
3. **字段类型正确**：确保字段类型与数据类型匹配
4. **权限要求**：需要飞书应用具有多维表格的读写权限
5. **数据格式**：超链接字段需要完整的URL格式

## 常见问题

### Q1: 如何获取 app_token 和 table_id？

A: 在飞书多维表格中：
- 打开目标多维表格
- URL格式为：`https://xxx.feishu.cn/base/[app_token]?table=[table_id]`
- 复制URL中的app_token和table_id即可

### Q2: 字段映射不匹配怎么办？

A: 
1. 检查字段名称是否完全一致（包括空格和标点）
2. 使用 `--field-mapping` 参数自定义映射
3. 确保字段类型匹配

### Q3: 导入失败提示权限不足？

A: 
1. 检查飞书应用是否开通了多维表格权限
2. 确认用户已授权应用访问多维表格
3. 验证access_token是否有效

### Q4: 超链接字段导入失败？

A: 
1. 确保URL格式正确（以http://或https://开头）
2. 检查多维表格中的字段类型是否为"超链接"
3. 如果是文本字段，需要先转换为超链接类型
