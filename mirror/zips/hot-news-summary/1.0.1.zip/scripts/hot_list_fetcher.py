#!/usr/bin/env python3
"""
热榜数据抓取脚本
抓取微博热搜、知乎热榜、B站热门数据并保存为JSON文件
"""

import json
import re
import time
from datetime import datetime
from typing import Dict, List, Any

import requests
from bs4 import BeautifulSoup


def fetch_weibo_hotsearch() -> List[Dict[str, Any]]:
    """
    抓取微博热搜榜
    
    Returns:
        热搜列表，每项包含rank, title, heat, url
    """
    url = "https://weibo.com/ajax/side/hotSearch"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Referer": "https://weibo.com",
        "Accept": "application/json, text/plain, */*",
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        # 解析微博热搜数据
        hot_list = []
        if data.get("ok") == 1 and "data" in data:
            items = data["data"].get("realtime", [])
            for item in items[:50]:  # 取前50条
                # 跳过广告位
                if item.get("is_ad", 0) == 1:
                    continue
                    
                hot_list.append({
                    "rank": item.get("rank", 0),
                    "title": item.get("word", ""),
                    "heat": item.get("raw_hot", 0),
                    "label": item.get("word_type", 0),  # 0-普通, 1-热, 2-新, 3-推荐
                    "url": f"https://s.weibo.com/weibo?q=%23{item.get('word', '')}%23"
                })
        
        print(f"微博热搜抓取成功，共 {len(hot_list)} 条")
        return hot_list
        
    except Exception as e:
        print(f"微博热搜抓取失败: {str(e)}")
        return []


def fetch_zhihu_hotlist() -> List[Dict[str, Any]]:
    """
    抓取知乎热榜（通过公开热榜话题列表）
    
    Returns:
        热榜列表，每项包含rank, title, heat, url, excerpt
    """
    # 使用知乎公开的热榜话题API
    url = "https://www.zhihu.com/api/v3/feed/topstory/hot-lists/total"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Referer": "https://www.zhihu.com/hot",
        "Accept": "application/json",
        "x-api-version": "3.0.40",
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        
        # 知乎API可能返回401，尝试备用方案
        if response.status_code == 401:
            print("知乎API需要授权，使用备用数据源...")
            # 使用第三方热榜聚合API（如果可用）
            return fetch_zhihu_hotlist_backup()
        
        response.raise_for_status()
        
        data = response.json()
        
        # 解析知乎热榜数据
        hot_list = []
        if "data" in data:
            items = data["data"]
            for idx, item in enumerate(items[:50], 1):
                target = item.get("target", {})
                hot_list.append({
                    "rank": idx,
                    "title": target.get("title", ""),
                    "heat": item.get("detail_text", "").replace("热度 ", ""),
                    "excerpt": target.get("excerpt", ""),
                    "url": target.get("url", f"https://www.zhihu.com/question/{target.get('id', '')}")
                })
        
        print(f"知乎热榜抓取成功，共 {len(hot_list)} 条")
        return hot_list
        
    except Exception as e:
        print(f"知乎热榜抓取失败: {str(e)}，尝试备用方案...")
        return fetch_zhihu_hotlist_backup()


def fetch_zhihu_hotlist_backup() -> List[Dict[str, Any]]:
    """
    知乎热榜备用抓取方案（使用第三方热榜聚合或直接返回空列表）
    
    Returns:
        热榜列表
    """
    # 方案1：尝试使用第三方热榜聚合API
    # 注意：这里使用公开的热榜聚合服务，如TodayHot等
    try:
        # 使用公开的热榜聚合接口（示例）
        url = "https://api.vvhan.com/api/hotlist/zhihuHot"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            # 根据第三方API的返回格式解析
            if data.get("success") and "data" in data:
                hot_list = []
                items = data["data"]
                
                for idx, item in enumerate(items[:50], 1):
                    hot_list.append({
                        "rank": idx,
                        "title": item.get("title", ""),
                        "heat": item.get("hot", ""),
                        "excerpt": item.get("desc", ""),
                        "url": item.get("url", "")
                    })
                
                print(f"知乎热榜抓取成功（备用源），共 {len(hot_list)} 条")
                return hot_list
    except Exception as e:
        print(f"备用数据源也失败: {str(e)}")
    
    # 方案2：返回空列表，由智能体处理
    print("知乎热榜暂时无法获取，跳过该平台")
    return []


def fetch_bilibili_hot() -> List[Dict[str, Any]]:
    """
    抓取B站热门视频榜
    
    Returns:
        热门视频列表，每项包含rank, title, heat, url, author, play_count
    """
    url = "https://api.bilibili.com/x/web-interface/ranking/v2"
    params = {
        "rid": 0,  # 0表示全站榜
        "type": "all",
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Referer": "https://www.bilibili.com",
        "Accept": "application/json, text/plain, */*",
    }
    
    try:
        response = requests.get(url, headers=headers, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        # 解析B站热门数据
        hot_list = []
        if data.get("code") == 0 and "data" in data:
            items = data["data"].get("list", [])
            for item in items[:100]:  # 取前100条
                hot_list.append({
                    "rank": item.get("rank", 0),
                    "title": item.get("title", ""),
                    "heat": item.get("stat", {}).get("view", 0),  # 播放量
                    "author": item.get("owner", {}).get("name", ""),
                    "play_count": item.get("stat", {}).get("view", 0),
                    "danmaku_count": item.get("stat", {}).get("danmaku", 0),
                    "url": f"https://www.bilibili.com/video/{item.get('bvid', '')}"
                })
        
        print(f"B站热门抓取成功，共 {len(hot_list)} 条")
        return hot_list
        
    except Exception as e:
        print(f"B站热门抓取失败: {str(e)}")
        return []


def fetch_baidu_hotlist() -> List[Dict[str, Any]]:
    """
    抓取百度热榜
    
    Returns:
        热榜列表，每项包含rank, title, heat, url
    """
    # 方案1：尝试官方页面解析
    url = "https://top.baidu.com/board?tab=realtime"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Referer": "https://www.baidu.com",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        # 使用BeautifulSoup解析HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 查找热榜数据（百度热榜数据在script标签中）
        hot_list = []
        
        # 尝试从HTML中提取JSON数据
        script_tags = soup.find_all('script')
        for script in script_tags:
            if script.string and 'content' in script.string:
                # 使用正则表达式提取JSON数据
                try:
                    pattern = r'<!--s-data:(.*?)-->'
                    match = re.search(pattern, script.string, re.DOTALL)
                    if match:
                        import json
                        data = json.loads(match.group(1))
                        
                        # 解析百度热榜数据结构
                        cards = data.get('data', {}).get('cards', [])
                        for card in cards:
                            if card.get('cardName') == '热点榜':
                                items = card.get('content', [])
                                for idx, item in enumerate(items[:50], 1):
                                    hot_list.append({
                                        "rank": idx,
                                        "title": item.get('word', ''),
                                        "heat": item.get('show', ''),
                                        "desc": item.get('desc', ''),
                                        "url": item.get('url', '')
                                    })
                                break
                        
                        if hot_list:
                            print(f"百度热榜抓取成功，共 {len(hot_list)} 条")
                            return hot_list
                except (json.JSONDecodeError, KeyError, AttributeError):
                    continue
        
        # 如果官方页面解析失败，尝试备用方案
        print("百度官方页面解析失败，尝试备用数据源...")
        return fetch_baidu_hotlist_backup()
        
    except Exception as e:
        print(f"百度热榜抓取失败: {str(e)}，尝试备用方案...")
        return fetch_baidu_hotlist_backup()


def fetch_baidu_hotlist_backup() -> List[Dict[str, Any]]:
    """
    百度热榜备用抓取方案（使用第三方热榜聚合）
    
    Returns:
        热榜列表
    """
    # 尝试使用第三方热榜聚合API
    try:
        # 使用公开的热榜聚合接口
        url = "https://api.vvhan.com/api/hotlist/baiduRD"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            # 根据第三方API的返回格式解析
            if data.get("success") and "data" in data:
                hot_list = []
                items = data["data"]
                
                for idx, item in enumerate(items[:50], 1):
                    hot_list.append({
                        "rank": idx,
                        "title": item.get("title", ""),
                        "heat": item.get("hot", ""),
                        "desc": item.get("desc", ""),
                        "url": item.get("url", "")
                    })
                
                print(f"百度热榜抓取成功（备用源），共 {len(hot_list)} 条")
                return hot_list
    except Exception as e:
        print(f"备用数据源也失败: {str(e)}")
    
    # 最终降级：返回空列表
    print("百度热榜暂时无法获取，跳过该平台")
    return []


def fetch_toutiao_hotlist() -> List[Dict[str, Any]]:
    """
    抓取今日头条热榜
    
    Returns:
        热榜列表，每项包含rank, title, heat, url
    """
    try:
        url = "https://www.toutiao.com/hot-event/hot-board/"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://www.toutiao.com",
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        hot_list = []
        if "data" in data:
            items = data["data"]
            for idx, item in enumerate(items[:50], 1):
                hot_list.append({
                    "rank": idx,
                    "title": item.get("Title", ""),
                    "heat": item.get("HotValue", 0),
                    "url": item.get("Url", "")
                })
        
        print(f"今日头条热榜抓取成功，共 {len(hot_list)} 条")
        return hot_list
        
    except Exception as e:
        print(f"今日头条热榜抓取失败: {str(e)}")
        return []


def fetch_douyin_hotlist() -> List[Dict[str, Any]]:
    """
    抓取抖音热点榜
    
    Returns:
        热榜列表，每项包含rank, title, heat, url
    """
    try:
        # 抖音热点通常需要登录，这里尝试公开API
        url = "https://api.vvhan.com/api/hotlist/douyinHot"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get("success") and "data" in data:
                hot_list = []
                items = data["data"]
                
                for idx, item in enumerate(items[:50], 1):
                    hot_list.append({
                        "rank": idx,
                        "title": item.get("title", ""),
                        "heat": item.get("hot", ""),
                        "url": item.get("url", "")
                    })
                
                print(f"抖音热点抓取成功，共 {len(hot_list)} 条")
                return hot_list
        
        print("抖音热点暂时无法获取，跳过该平台")
        return []
        
    except Exception as e:
        print(f"抖音热点抓取失败: {str(e)}")
        return []


def fetch_netease_hotlist() -> List[Dict[str, Any]]:
    """
    抓取网易新闻热榜
    
    Returns:
        热榜列表，每项包含rank, title, heat, url
    """
    try:
        url = "https://c.m.163.com/pc/api/cmstopic/getList.html"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://news.163.com/",
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        hot_list = []
        if "data" in data and "topicList" in data["data"]:
            items = data["data"]["topicList"]
            for idx, item in enumerate(items[:50], 1):
                hot_list.append({
                    "rank": idx,
                    "title": item.get("title", ""),
                    "heat": item.get("score", 0),
                    "url": f"https://news.163.com/topics/{item.get('tid', '')}"
                })
        
        print(f"网易新闻热榜抓取成功，共 {len(hot_list)} 条")
        return hot_list
        
    except Exception as e:
        print(f"网易新闻热榜抓取失败: {str(e)}")
        return []


def fetch_36kr_hotlist() -> List[Dict[str, Any]]:
    """
    抓取36氪热文
    
    Returns:
        热榜列表，每项包含rank, title, heat, url
    """
    try:
        url = "https://gateway.36kr.com/api/mis/nav/home/navList/hotRankList"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://36kr.com/",
            "Content-Type": "application/json",
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        hot_list = []
        if "data" in data and "hotRankList" in data["data"]:
            items = data["data"]["hotRankList"]
            for idx, item in enumerate(items[:50], 1):
                hot_list.append({
                    "rank": idx,
                    "title": item.get("title", ""),
                    "heat": item.get("statistics", {}).get("pv", 0),
                    "url": f"https://36kr.com/p/{item.get('id', '')}"
                })
        
        print(f"36氪热文抓取成功，共 {len(hot_list)} 条")
        return hot_list
        
    except Exception as e:
        print(f"36氪热文抓取失败: {str(e)}")
        return []


def remove_duplicates(hot_list: List[Dict[str, Any]], similarity_threshold: float = 0.8) -> List[Dict[str, Any]]:
    """
    去除重复热点
    
    Args:
        hot_list: 热点列表
        similarity_threshold: 相似度阈值（0-1之间）
        
    Returns:
        去重后的热点列表
    """
    if not hot_list:
        return []
    
    def calculate_similarity(title1: str, title2: str) -> float:
        """计算两个标题的相似度（简单的词重叠率）"""
        if not title1 or not title2:
            return 0.0
        
        # 提取关键词（简单分词）
        words1 = set(title1)
        words2 = set(title2)
        
        if not words1 or not words2:
            return 0.0
        
        # 计算交集占比
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        
        return intersection / union if union > 0 else 0.0
    
    unique_list = []
    
    for item in hot_list:
        title = item.get("title", "")
        is_duplicate = False
        
        # 检查是否与已有热点重复
        for unique_item in unique_list:
            unique_title = unique_item.get("title", "")
            similarity = calculate_similarity(title, unique_title)
            
            if similarity >= similarity_threshold:
                is_duplicate = True
                # 如果新热点热度更高，替换旧的
                if item.get("heat", 0) > unique_item.get("heat", 0):
                    unique_list.remove(unique_item)
                    unique_list.append(item)
                break
        
        if not is_duplicate:
            unique_list.append(item)
    
    print(f"去重完成：{len(hot_list)}条 -> {len(unique_list)}条")
    return unique_list


def main():
    """
    主函数：抓取多平台热榜数据并保存为JSON文件
    """
    print("=" * 60)
    print("热榜数据抓取开始")
    print(f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 抓取数据（按优先级）
    all_hot_lists = {}
    
    # 第一优先级：微博、B站、百度
    weibo_data = fetch_weibo_hotsearch()
    if weibo_data:
        all_hot_lists["weibo"] = weibo_data
    time.sleep(1)
    
    bilibili_data = fetch_bilibili_hot()
    if bilibili_data:
        all_hot_lists["bilibili"] = bilibili_data
    time.sleep(1)
    
    baidu_data = fetch_baidu_hotlist()
    if baidu_data:
        all_hot_lists["baidu"] = baidu_data
    time.sleep(1)
    
    # 第二优先级：知乎、今日头条、网易
    zhihu_data = fetch_zhihu_hotlist()
    if zhihu_data:
        all_hot_lists["zhihu"] = zhihu_data
    time.sleep(1)
    
    toutiao_data = fetch_toutiao_hotlist()
    if toutiao_data:
        all_hot_lists["toutiao"] = toutiao_data
    time.sleep(1)
    
    netease_data = fetch_netease_hotlist()
    if netease_data:
        all_hot_lists["netease"] = netease_data
    time.sleep(1)
    
    # 第三优先级：抖音、36氪
    douyin_data = fetch_douyin_hotlist()
    if douyin_data:
        all_hot_lists["douyin"] = douyin_data
    time.sleep(1)
    
    kr36_data = fetch_36kr_hotlist()
    if kr36_data:
        all_hot_lists["36kr"] = kr36_data
    
    # 合并所有热点并去重
    all_hot_items = []
    platform_map = {
        "weibo": "微博热搜",
        "zhihu": "知乎热榜",
        "bilibili": "B站热门",
        "baidu": "百度热榜",
        "toutiao": "今日头条",
        "douyin": "抖音热点",
        "netease": "网易新闻",
        "36kr": "36氪"
    }
    
    for platform_key, platform_name in platform_map.items():
        if platform_key in all_hot_lists:
            for item in all_hot_lists[platform_key]:
                item["platform"] = platform_name
                all_hot_items.append(item)
    
    # 去重
    unique_items = remove_duplicates(all_hot_items)
    
    # 按热度排序，确保至少有10条
    unique_items.sort(key=lambda x: x.get("heat", 0) if isinstance(x.get("heat", 0), (int, float)) else 0, reverse=True)
    
    # 构建结果
    result = {
        "timestamp": datetime.now().isoformat(),
        "total_count": len(unique_items),
        "platforms": {}
    }
    
    # 按平台分类
    for platform_key, platform_name in platform_map.items():
        if platform_key in all_hot_lists:
            result["platforms"][platform_key] = {
                "platform": platform_name,
                "count": len(all_hot_lists[platform_key]),
                "data": all_hot_lists[platform_key]
            }
    
    # 添加去重后的全部热点
    result["all_hot_items"] = unique_items[:100]  # 保存前100条
    
    # 保存到JSON文件
    output_file = "./hot_lists.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    print("=" * 60)
    print(f"数据已保存到: {output_file}")
    print(f"各平台数据：")
    for platform_key, platform_name in platform_map.items():
        if platform_key in all_hot_lists:
            print(f"  - {platform_name}: {len(all_hot_lists[platform_key])}条")
    print(f"去重后总计: {len(unique_items)}条")
    print("=" * 60)


if __name__ == "__main__":
    main()
