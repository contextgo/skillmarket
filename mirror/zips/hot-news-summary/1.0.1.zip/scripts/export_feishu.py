#!/usr/bin/env python3
"""
飞书文档导出脚本
将热点摘要导入到飞书文档或多维表格
"""

import argparse
import json
import os
from datetime import datetime
from typing import Dict, List, Any

from coze_workload_identity import requests


def create_feishu_document(access_token: str, title: str) -> Dict[str, Any]:
    """
    创建飞书文档
    
    Args:
        access_token: 用户访问令牌
        title: 文档标题
        
    Returns:
        API响应数据
    """
    url = "https://open.feishu.cn/open-apis/docx/v1/documents"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    data = {
        "title": title,
        "folder_token": ""  # 根目录
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=30)
        
        if response.status_code >= 400:
            raise Exception(f"HTTP请求失败: 状态码 {response.status_code}, 响应内容: {response.text}")
        
        result = response.json()
        
        if result.get("code", 0) != 0:
            raise Exception(f"飞书API错误: {result}")
        
        return result.get("data", {})
        
    except Exception as e:
        raise Exception(f"创建飞书文档失败: {str(e)}")


def insert_content_to_document(access_token: str, document_id: str, content: List[Dict[str, Any]]) -> bool:
    """
    向飞书文档插入内容
    
    Args:
        access_token: 用户访问令牌
        document_id: 文档ID
        content: 内容块列表
        
    Returns:
        是否成功
    """
    url = f"https://open.feishu.cn/open-apis/docx/v1/documents/{document_id}/blocks/{document_id}/children/batch_insert"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    
    data = {
        "children": content,
        "index": 0
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=30)
        
        if response.status_code >= 400:
            raise Exception(f"HTTP请求失败: 状态码 {response.status_code}, 响应内容: {response.text}")
        
        result = response.json()
        
        if result.get("code", 0) != 0:
            raise Exception(f"飞书API错误: {result}")
        
        return True
        
    except Exception as e:
        print(f"插入文档内容失败: {str(e)}")
        return False


def create_bitable_record(access_token: str, app_token: str, table_id: str, fields: Dict[str, Any]) -> Dict[str, Any]:
    """
    向飞书多维表格添加记录
    
    Args:
        access_token: 用户访问令牌
        app_token: 多维表格应用token
        table_id: 数据表ID
        fields: 字段数据
        
    Returns:
        API响应数据
    """
    url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    
    data = {
        "fields": fields
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=30)
        
        if response.status_code >= 400:
            raise Exception(f"HTTP请求失败: 状态码 {response.status_code}, 响应内容: {response.text}")
        
        result = response.json()
        
        if result.get("code", 0) != 0:
            raise Exception(f"飞书API错误: {result}")
        
        return result.get("data", {})
        
    except Exception as e:
        raise Exception(f"添加多维表格记录失败: {str(e)}")


def export_to_feishu_document(access_token: str, hot_news_data: List[Dict[str, Any]], title: str) -> bool:
    """
    导出到飞书文档
    
    Args:
        access_token: 用户访问令牌
        hot_news_data: 热点数据列表
        title: 文档标题
        
    Returns:
        是否成功
    """
    print(f"正在创建飞书文档：{title}")
    
    # 创建文档
    doc_data = create_feishu_document(access_token, title)
    document_id = doc_data.get("document", {}).get("document_id")
    
    if not document_id:
        print("✗ 创建文档失败：未获取到document_id")
        return False
    
    print(f"✓ 文档创建成功：{document_id}")
    
    # 构建文档内容
    content_blocks = []
    
    # 添加概览
    overview_text = f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n热点数量：{len(hot_news_data)}条"
    content_blocks.append({
        "block_type": 3,  # 文本块
        "text": {
            "elements": [
                {
                    "text_run": {
                        "content": overview_text
                    }
                }
            ],
            "style": {}
        }
    })
    
    # 添加每条热点
    for idx, item in enumerate(hot_news_data, 1):
        hot_title = item.get('title', '无标题')
        platform = item.get('platform', '未知平台')
        comment = item.get('comment', '暂无点评')
        analysis = item.get('analysis', '暂无分析')
        
        # 标题
        content_blocks.append({
            "block_type": 6,  # 标题块
            "heading1": {
                "elements": [
                    {
                        "text_run": {
                            "content": f"{idx}. {hot_title}"
                        }
                    }
                ]
            }
        })
        
        # 平台信息
        content_blocks.append({
            "block_type": 3,
            "text": {
                "elements": [
                    {
                        "text_run": {
                            "content": f"来源平台：{platform}"
                        }
                    }
                ],
                "style": {}
            }
        })
        
        # 点评
        content_blocks.append({
            "block_type": 3,
            "text": {
                "elements": [
                    {
                        "text_run": {
                            "content": f"💬 犀利点评：{comment}"
                        }
                    }
                ],
                "style": {}
            }
        })
        
        # 分析
        content_blocks.append({
            "block_type": 3,
            "text": {
                "elements": [
                    {
                        "text_run": {
                            "content": f"📊 精准分析：{analysis}"
                        }
                    }
                ],
                "style": {}
            }
        })
    
    # 插入内容
    success = insert_content_to_document(access_token, document_id, content_blocks)
    
    if success:
        print(f"✓ 内容插入成功")
        print(f"文档链接：https://feishu.cn/docx/{document_id}")
        return True
    else:
        print("✗ 内容插入失败")
        return False


def export_to_feishu_bitable(access_token: str, app_token: str, table_id: str, 
                             hot_news_data: List[Dict[str, Any]], field_mapping: Dict[str, str]) -> bool:
    """
    导出到飞书多维表格
    
    Args:
        access_token: 用户访问令牌
        app_token: 多维表格应用token
        table_id: 数据表ID
        hot_news_data: 热点数据列表
        field_mapping: 字段映射（数据字段 -> 多维表格字段）
        
    Returns:
        是否成功
    """
    print(f"正在向多维表格添加 {len(hot_news_data)} 条记录...")
    
    success_count = 0
    
    for item in hot_news_data:
        # 根据字段映射构建记录数据
        fields = {}
        
        for data_field, table_field in field_mapping.items():
            if data_field in item:
                fields[table_field] = item[data_field]
        
        # 添加时间戳
        fields[field_mapping.get('timestamp', '时间')] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        try:
            create_bitable_record(access_token, app_token, table_id, fields)
            success_count += 1
        except Exception as e:
            print(f"✗ 记录添加失败：{item.get('title', '未知')} - {str(e)}")
    
    print(f"✓ 成功添加 {success_count}/{len(hot_news_data)} 条记录")
    return success_count > 0


def main():
    """
    主函数：导出热点摘要到飞书
    """
    parser = argparse.ArgumentParser(description='导出热点摘要到飞书文档或多维表格')
    parser.add_argument('--input', type=str, default='./hot_lists.json',
                        help='输入JSON文件路径（智能体生成的热点数据）')
    parser.add_argument('--type', type=str, choices=['document', 'bitable'], required=True,
                        help='导出类型：document（文档）或 bitable（多维表格）')
    parser.add_argument('--title', type=str, default=None,
                        help='文档标题（仅文档类型需要）')
    
    # 多维表格相关参数
    parser.add_argument('--app-token', type=str, default=None,
                        help='多维表格应用token（仅多维表格类型需要）')
    parser.add_argument('--table-id', type=str, default=None,
                        help='数据表ID（仅多维表格类型需要）')
    parser.add_argument('--field-mapping', type=str, default=None,
                        help='字段映射JSON字符串（仅多维表格类型需要）')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("飞书文档导出工具")
    print("=" * 60)
    
    # 获取访问令牌
    skill_id = "7623777311753519139"
    access_token = os.getenv("COZE_FEISHU_DOC_7623777311753519139")
    
    if not access_token:
        print("✗ 缺少飞书访问令牌")
        print("提示：请先完成飞书OAuth授权")
        return
    
    # 读取输入数据
    try:
        with open(args.input, 'r', encoding='utf-8') as f:
            input_data = json.load(f)
    except FileNotFoundError:
        print(f"✗ 输入文件不存在：{args.input}")
        return
    except json.JSONDecodeError:
        print(f"✗ 输入文件格式错误：{args.input}")
        return
    
    hot_news_list = input_data.get('hot_news', [])
    
    if not hot_news_list:
        print("✗ 输入数据中没有热点信息")
        return
    
    # 根据类型导出
    if args.type == 'document':
        # 导出到文档
        title = args.title or f"热点摘要 {datetime.now().strftime('%Y-%m-%d')}"
        success = export_to_feishu_document(access_token, hot_news_list, title)
        
    elif args.type == 'bitable':
        # 导出到多维表格
        if not args.app_token or not args.table_id:
            print("✗ 缺少必要参数：app_token 或 table_id")
            return
        
        # 默认字段映射
        default_field_mapping = {
            'title': '标题',
            'comment': '点评',
            'analysis': '分析',
            'platform': '来源平台',
            'heat': '热度',
            'url': '链接',
            'timestamp': '时间'
        }
        
        # 如果提供了自定义字段映射，使用自定义的
        field_mapping = default_field_mapping
        if args.field_mapping:
            try:
                field_mapping = json.loads(args.field_mapping)
            except json.JSONDecodeError:
                print("⚠ 字段映射格式错误，使用默认映射")
        
        success = export_to_feishu_bitable(
            access_token, 
            args.app_token, 
            args.table_id, 
            hot_news_list, 
            field_mapping
        )
    
    if success:
        print("=" * 60)
        print("✓ 导出成功！")
        print("=" * 60)
    else:
        print("=" * 60)
        print("✗ 导出失败")
        print("=" * 60)


if __name__ == "__main__":
    main()
