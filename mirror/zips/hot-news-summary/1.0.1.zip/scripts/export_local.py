#!/usr/bin/env python3
"""
本地知识库文档导出脚本
将热点摘要导出为Markdown格式文档
"""

import argparse
import json
import os
from datetime import datetime
from typing import Dict, List, Any


def create_knowledge_base(kb_name: str, base_dir: str) -> str:
    """
    创建知识库目录结构
    
    Args:
        kb_name: 知识库名称
        base_dir: 基础目录路径
        
    Returns:
        知识库完整路径
    """
    kb_path = os.path.join(base_dir, kb_name)
    
    # 创建知识库主目录
    if not os.path.exists(kb_path):
        os.makedirs(kb_path)
        print(f"✓ 创建知识库：{kb_name}")
    
    # 创建子目录
    subdirs = ["daily", "weekly", "monthly"]
    for subdir in subdirs:
        subdir_path = os.path.join(kb_path, subdir)
        if not os.path.exists(subdir_path):
            os.makedirs(subdir_path)
    
    return kb_path


def generate_markdown_content(hot_news_data: Dict[str, Any], title: str) -> str:
    """
    生成Markdown格式的内容
    
    Args:
        hot_news_data: 热点数据（包含title, comment, analysis, platform等）
        title: 文档标题
        
    Returns:
        Markdown格式的内容
    """
    md_content = f"""# {title}

## 概览

- **生成时间**：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **数据来源**：微博热搜、知乎热榜、B站热门、百度热榜
- **热点数量**：{len(hot_news_data)}条

---

## 热点详情

"""
    
    for idx, item in enumerate(hot_news_data, 1):
        platform = item.get('platform', '未知平台')
        hot_title = item.get('title', '无标题')
        comment = item.get('comment', '暂无点评')
        analysis = item.get('analysis', '暂无分析')
        heat = item.get('heat', '未知')
        url = item.get('url', '')
        
        md_content += f"""### {idx}. {hot_title}

**来源平台**：{platform}  
**热度指数**：{heat}

**💬 犀利点评**：{comment}

**📊 精准分析**：{analysis}

"""
        
        if url:
            md_content += f"**相关链接**：[{hot_title}]({url})\n\n"
        
        md_content += "---\n\n"
    
    # 添加统计信息
    md_content += """## 数据统计

| 平台 | 抓取数量 | 入选数量 | 占比 |
|------|---------|---------|------|
"""
    
    # 统计各平台数量
    platform_stats = {}
    for item in hot_news_data:
        platform = item.get('platform', '未知平台')
        platform_stats[platform] = platform_stats.get(platform, 0) + 1
    
    for platform, count in platform_stats.items():
        percentage = (count / len(hot_news_data)) * 100 if hot_news_data else 0
        md_content += f"| {platform} | - | {count} | {percentage:.1f}% |\n"
    
    md_content += """
## 今日观察

（此处可添加综合观察和趋势分析）

---

> 本摘要由热榜摘要器自动生成，数据来源于公开热榜API
"""
    
    return md_content


def export_to_file(content: str, file_path: str) -> bool:
    """
    将内容导出到文件
    
    Args:
        content: 文件内容
        file_path: 文件路径
        
    Returns:
        是否成功
    """
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✓ 文件已导出：{file_path}")
        return True
    except Exception as e:
        print(f"✗ 文件导出失败：{str(e)}")
        return False


def main():
    """
    主函数：导出热点摘要到本地知识库
    """
    parser = argparse.ArgumentParser(description='导出热点摘要到本地知识库')
    parser.add_argument('--input', type=str, default='./hot_lists.json',
                        help='输入JSON文件路径（智能体生成的热点数据）')
    parser.add_argument('--knowledge-base', type=str, default='热点知识库',
                        help='知识库名称')
    parser.add_argument('--output-dir', type=str, default='./knowledge_base',
                        help='输出基础目录')
    parser.add_argument('--filename', type=str, default=None,
                        help='自定义文件名（不含扩展名）')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("本地知识库导出工具")
    print("=" * 60)
    
    # 读取输入数据
    # 注意：这里需要智能体先读取hot_lists.json并生成点评和分析
    # 然后将处理后的数据作为参数传入
    # 为了演示，这里假设输入是一个包含完整信息的JSON文件
    
    try:
        with open(args.input, 'r', encoding='utf-8') as f:
            input_data = json.load(f)
    except FileNotFoundError:
        print(f"✗ 输入文件不存在：{args.input}")
        print("提示：请先运行数据抓取脚本并生成热点分析数据")
        return
    except json.JSONDecodeError:
        print(f"✗ 输入文件格式错误：{args.input}")
        return
    
    # 创建知识库
    kb_path = create_knowledge_base(args.knowledge_base, args.output_dir)
    
    # 生成文件名
    if args.filename:
        filename = f"{args.filename}.md"
    else:
        date_str = datetime.now().strftime('%Y-%m-%d')
        filename = f"热点摘要_{date_str}.md"
    
    file_path = os.path.join(kb_path, "daily", filename)
    
    # 生成文档标题
    date_str = datetime.now().strftime('%Y年%m月%d日')
    title = f"每日热点摘要 - {date_str}"
    
    # 生成Markdown内容
    # 注意：这里需要智能体传入处理后的数据
    # 假设input_data包含hot_news列表，每个元素有title, comment, analysis等字段
    hot_news_list = input_data.get('hot_news', [])
    
    if not hot_news_list:
        print("✗ 输入数据中没有热点信息")
        print("提示：请确保输入数据包含hot_news字段")
        return
    
    md_content = generate_markdown_content(hot_news_list, title)
    
    # 导出到文件
    success = export_to_file(md_content, file_path)
    
    if success:
        print("=" * 60)
        print(f"✓ 导出成功！")
        print(f"知识库位置：{kb_path}")
        print(f"文件位置：{file_path}")
        print("=" * 60)
    else:
        print("=" * 60)
        print("✗ 导出失败")
        print("=" * 60)


if __name__ == "__main__":
    main()
