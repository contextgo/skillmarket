# Smart-Admin 列表页基础模板（admin-page-layout）

## 1. 目标与约束

- 页面输出结构强制为三件套：`index.vue`、`components/`、`column.js`。
- 禁止只生成单一 `index.vue`，必须同时产出 `components` 目录与 `column.js` 文件。
- 页面骨架统一使用 `admin-page-layout`。
- 新增、删除、导入、导出按钮显隐必须由权限点控制。
- 页面内所有按钮（含“新增”）都必须绑定权限点。
- 筛选区输入项统一使用 `admin-input`。
- 筛选区下拉/枚举项统一使用 `SmartEnumSelect`（你提到的 `SmartEnumSelecct`，项目实际组件名为 `SmartEnumSelect`）。
- API 文件统一放在 `src/api/**`。
- 页面权限统一维护在 `src/constants/permission-const.js`。
- 页面 table-id 统一维护在 `src/constants/support/table-id-const.js`。
- 生成页面时，必须同步新增对应权限点和 table-id。
- 页面脚本内所有方法都必须写完整注释（方法用途、参数、返回值或关键行为）。

## 2. 生成页面前的同步改动

```js
// src/constants/permission-const.js
const USER_MANAGE = {
  // 原有
  USER_LIST: {},
  // 新增页面权限点
  USER_PROFILE: {
    ADD: "user:manage:profile:add",
    UPDATE: "user:manage:profile:update",
    DELETE: "user:manage:profile:delete",
    IMPORT: "user:manage:profile:import",
    EXPORT: "user:manage:profile:export",
    DETAIL: "user:manage:profile:detail",
    BATCH_UPDATE: "user:manage:profile:batch:update",
  },
};

export default {
  USER_MANAGE,
};
```

```js
// src/constants/support/table-id-const.js
const userManageInitTableId = 50000;

export const TABLE_ID_CONST = {
  USER_MANAGE: {
    USER_INFO: userManageInitTableId + 1, // 原有
    BLACK_LIST: userManageInitTableId + 2, // 原有
    USER_PROFILE: userManageInitTableId + 3, // 新增页面 table id（示例）
  },
};
```

## 3. 页面模板（可直接改业务字段）

```vue
<script setup>
import { ref, unref, readonly } from "vue";
import { message } from "ant-design-vue";
import { useLoading, useFormReset, usePaging, useTableSelection, delay } from "admin-utils";
import { useUserStore, useValidCodeStore } from "@/store";

import permissionConst from "@/constants/permission-const";
import { TABLE_ID_CONST } from "@/constants/support/table-id-const";
// TODO: 替换为真实 API / 常量 / 列定义
// TODO: 列定义可放在当前页面目录，也可按项目规范拆分
import { columns } from "./column";
import {
  queryDemoPageApi,
  deleteDemoApi,
  batchDeleteDemoApi,
  exportDemoApi,
  importDemoApi,
  downloadTemplateApi,
} from "@/api/user-manage/user-profile-api";
const userStore = useUserStore();
const validCodeStore = useValidCodeStore();


const [formModel, resetForm] = useFormReset({
  keyword: null, // 输入框 -> admin-input
  status: null, // 下拉枚举 -> SmartEnumSelect
  type: null, // 下拉枚举 -> SmartEnumSelect
});

const { loading, setLoading } = useLoading();
const { paginationModel, resetPagination, pagingParams } = usePaging();
const { selectedRowKeys, selectedRows, hasSelected, onSelectChange, clearSelection } =
  useTableSelection();

const tableData = ref([]);
const importExcelRef = ref();
const formModalRef = ref();

/**
 * 组装查询参数
 * @returns {Object} 接口查询参数
 */
function getFormData() {
  return {
    ...unref(pagingParams),
    keyword: formModel.keyword,
    status: formModel.status,
    type: formModel.type,
  };
}

/**
 * 获取表格数据
 * @returns {Promise<void>}
 */
async function getTableList() {
  setLoading(true);
  try {
    const { data } = await queryDemoPageApi(getFormData());
    tableData.value = data.list || [];
    paginationModel.total = data.total || 0;
  } finally {
    setLoading(false);
  }
}

/**
 * 查询按钮事件
 * @returns {void}
 */
function handleSearch() {
  paginationModel.current = 1;
  getTableList();
}

/**
 * 重置按钮事件
 * @returns {void}
 */
function handleReset() {
  resetForm();
  resetPagination();
  getTableList();
}

/**
 * 分页变化事件
 * @param {Object} params 分页参数
 * @param {number} params.current 当前页
 * @param {number} params.pageSize 每页条数
 * @returns {void}
 */
function handleSizeChange({ current, pageSize }) {
  Object.assign(paginationModel, { current, pageSize });
  getTableList();
}

/**
 * 新增事件
 * @returns {void}
 */
function handleAdd() {
  validCodeStore.validateAuthCode(permissionConst.USER_MANAGE.USER_PROFILE.ADD, () => {
    formModalRef.value?.showDialog?.(null, getTableList);
  });
}

/**
 * 批量删除事件
 * @returns {void}
 */
function handleBatchDelete() {
  if (!hasSelected.value) {
    message.warning("请先选择要删除的数据");
    return;
  }
  validCodeStore.validateAuthCode(permissionConst.USER_MANAGE.USER_PROFILE.DELETE, async () => {
    setLoading(true);
    try {
      await batchDeleteDemoApi(selectedRows.value.map((e) => e.id));
      message.success("批量删除成功");
      clearSelection();
      handleSearch();
    } finally {
      setLoading(false);
    }
  });
}

/**
 * 导入事件
 * @returns {void}
 */
function handleImport() {
  validCodeStore.validateAuthCode(permissionConst.USER_MANAGE.USER_PROFILE.IMPORT, () => {
    importExcelRef.value?.showDialog?.(null, async (file, loadingFn, controller) => {
      loadingFn(true);
      try {
        await importDemoApi(file, { signal: controller?.signal });
        message.success("导入成功");
        handleSearch();
        importExcelRef.value?.hideDialog?.();
      } finally {
        loadingFn(false);
      }
    });
  });
}

/**
 * 导出事件
 * @param {Function} loadingFn admin-page-layout 传入的导出按钮 loading 控制函数
 * @returns {void}
 */
function handleExport(loadingFn) {
  validCodeStore.validateAuthCode(permissionConst.USER_MANAGE.USER_PROFILE.EXPORT, async () => {
    loadingFn(true);
    try {
      await exportDemoApi(getFormData());
      await delay(200);
      message.success("导出成功");
    } finally {
      await delay(200);
      loadingFn(false);
    }
  });
}

/**
 * 行内编辑事件
 * @param {Object} row 当前行数据
 * @returns {void}
 */
function handleEdit(row) {
  validCodeStore.validateAuthCode(permissionConst.USER_MANAGE.USER_PROFILE.UPDATE, () => {
    formModalRef.value?.showDialog?.(row, getTableList);
  });
}

/**
 * 行内删除事件
 * @param {Object} row 当前行数据
 * @returns {Promise<void>}
 */
async function handleDelete(row) {
  validCodeStore.validateAuthCode(permissionConst.USER_MANAGE.USER_PROFILE.DELETE, async () => {
    setLoading(true);
    try {
      await deleteDemoApi({ id: row.id });
      message.success("删除成功");
      getTableList();
    } finally {
      setLoading(false);
    }
  });
}

/**
 * 详情事件
 * @param {Object} row 当前行数据
 * @returns {void}
 */
function handleDetail(row) {
  validCodeStore.validateAuthCode(permissionConst.USER_MANAGE.USER_PROFILE.DETAIL, () => {
    console.log("open detail", row);
  });
}

const moreButtonOptions = readonly([
  {
    label: "编辑",
    permission: permissionConst.USER_MANAGE.USER_PROFILE.UPDATE,
    onClick: handleEdit,
    icon: "AdminIconEdit",
  },
  {
    label: "详情",
    permission: permissionConst.USER_MANAGE.USER_PROFILE.DETAIL,
    onClick: handleDetail,
    icon: "AdminIconDetail",
  },
  {
    label: "删除",
    permission: permissionConst.USER_MANAGE.USER_PROFILE.DELETE,
    onClick: handleDelete,
    confirm: true,
    danger: true,
    icon: "AdminIconDelete",
  },
]);

getTableList();
</script>

<template>
  <admin-page-layout
    :show-add="userStore.hasPermission(permissionConst.USER_MANAGE.USER_PROFILE.ADD)"
    :show-delete="userStore.hasPermission(permissionConst.USER_MANAGE.USER_PROFILE.DELETE)"
    :show-import="userStore.hasPermission(permissionConst.USER_MANAGE.USER_PROFILE.IMPORT)"
    :show-export="userStore.hasPermission(permissionConst.USER_MANAGE.USER_PROFILE.EXPORT)"
    :delete-disabled="!hasSelected"
    add-text="新增"
    label-width="100px"
    @add="handleAdd"
    @delete="handleBatchDelete"
    @search="handleSearch"
    @reset="handleReset"
    @import="handleImport"
    @export="handleExport"
  >
    <template #filter>
      <a-form-item label="关键字">
        <admin-input v-model="formModel.keyword" placeholder="请输入关键字" allow-clear />
      </a-form-item>
      <a-form-item label="状态">
        <SmartEnumSelect v-model:value="formModel.status" enum-name="STATUS_ENUM" />
      </a-form-item>
      <a-form-item label="类型">
        <SmartEnumSelect v-model:value="formModel.type" enum-name="DEMO_TYPE_ENUM" />
      </a-form-item>
    </template>

    <template #operate>
      <base-operate-button
        type="default"
        :permission="permissionConst.USER_MANAGE.USER_PROFILE.BATCH_UPDATE"
        :disabled="!hasSelected"
        @click="() => console.log('batch update')"
      >
        批量更新
      </base-operate-button>
    </template>

    <template #table>
      <base-table
        v-model:columns="columns"
        :table-id="TABLE_ID_CONST.USER_MANAGE.USER_PROFILE"
        :refresh="getTableList"
        :loading="loading"
        :row-selection="{ selectedRowKeys, onChange: onSelectChange }"
        :data="tableData"
        row-key="id"
        :pagination="paginationModel"
        @paging-change="handleSizeChange"
      >
        <template #operate="{ record }">
          <more-button :item="record" :options="moreButtonOptions" />
        </template>
      </base-table>
    </template>

    <import-excel
      v-if="userStore.hasPermission(permissionConst.USER_MANAGE.USER_PROFILE.IMPORT)"
      ref="importExcelRef"
      :down-api="downloadTemplateApi"
    />
    <!-- <DemoFormModal ref="formModalRef" @refresh="getTableList" /> -->
  </admin-page-layout>
</template>

<style scoped lang="less"></style>
```

## 4. 生成规则（给技能/脚手架）

- 目录结构必须包含且仅至少包含：`index.vue`、`components/`、`column.js` 三件套。
- `index.vue` 仅负责页面编排和事件调用；弹窗/表单等子模块放在 `components/`；表格列定义统一放在 `column.js`。
- `show-add/show-delete/show-import/show-export` 必须绑定 `userStore.hasPermission(...)`。
- `@add/@delete/@import/@export` 对应处理函数内部必须再次做 `validateAuthCode` 二次校验。
- 顶部操作按钮统一使用 `base-operate-button` 并传入 `permission`。
- 表格行内按钮统一走 `more-button options`，每个 option 必须有 `permission`，禁止在行内直接平铺 `a-button` 操作按钮。
- 操作列必须使用 `dataIndex: "operate"` + `fieldType: "slot"` + 显式 `width`，并在 `#operate` 插槽中渲染 `<more-button :item="record" :options="moreButtonOptions" />`。
- 所有 table 列（包含文本列、状态列、时间列、操作列）必须显式配置 `width`，禁止省略宽度。
- API 引用路径必须来自 `src/api/**`。
- 权限点必须写入 `src/constants/permission-const.js` 后再在页面中引用。
- table-id 必须写入 `src/constants/support/table-id-const.js` 后再在页面中引用。
- 页面中的每个方法都必须包含完整注释（用途、参数、返回值或关键行为）。
- Filter 区字段映射规则：
  - 输入型：`admin-input`
  - 枚举/下拉型：`SmartEnumSelect`
