"""
Tests for parsers package
"""