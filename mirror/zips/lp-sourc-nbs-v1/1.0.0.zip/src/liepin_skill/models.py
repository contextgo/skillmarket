from typing import Literal

from pydantic import BaseModel, Field, HttpUrl, model_validator


class TargetJob(BaseModel):
    display_name: str
    job_id: str | None = None
    job_url: HttpUrl | None = None


class SearchRequirements(BaseModel):
    keyword_groups: list[list[str]] = Field(min_length=1, max_length=5)
    current_city: list[str] = Field(default_factory=list)
    expected_city: list[str] = Field(default_factory=list)
    education: str | None = None
    experience: str | None = None
    job_title: list[str] = Field(default_factory=list)
    current_industry: list[str] = Field(default_factory=list)
    current_function: list[str] = Field(default_factory=list)
    company: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_city_presence(self) -> "SearchRequirements":
        if not self.current_city and not self.expected_city:
            raise ValueError("At least one city filter is required")
        return self


class Policy(BaseModel):
    target_links: int = 50
    max_search_changes: int = 5
    ideal_result_min: int = 50
    ideal_result_max: int = 200

    @model_validator(mode="after")
    def validate_policy_bounds(self) -> "Policy":
        if self.target_links < 0:
            raise ValueError("target_links must be non-negative")
        if self.max_search_changes < 0:
            raise ValueError("max_search_changes must be non-negative")
        if self.ideal_result_min < 0:
            raise ValueError("ideal_result_min must be non-negative")
        if self.ideal_result_max < 0:
            raise ValueError("ideal_result_max must be non-negative")
        if self.ideal_result_min > self.ideal_result_max:
            raise ValueError("ideal_result_min must be less than or equal to ideal_result_max")
        return self


class SourcingTask(BaseModel):
    target_job: TargetJob
    search_requirements: SearchRequirements
    policy: Policy


class CandidateDecision(BaseModel):
    action: Literal["link", "open_detail", "skip"]
    reason: str


class RunState(BaseModel):
    linked_count: int = 0
    reviewed_count: int = 0
    search_changes: int = 0
    current_plan_index: int = 0
