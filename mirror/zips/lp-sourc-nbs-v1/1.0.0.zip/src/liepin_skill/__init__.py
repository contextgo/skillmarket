from importlib import import_module

__all__ = [
    "__version__",
    "models",
    "planner",
    "evaluator",
    "browser_helpers",
    "browser",
    "runtime",
]
__version__ = "0.2.0"


def __getattr__(name: str):
    if name in {"models", "planner", "evaluator", "browser_helpers", "browser", "runtime"}:
        module = import_module(f"{__name__}.{name}")
        globals()[name] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
