from liepin_skill.models import CandidateDecision
import re


def _text_blob(data: dict) -> str:
    return " ".join(str(value).lower() for value in data.values())


def _unique_terms(must_have_terms: list[str]) -> list[str]:
    unique_terms: list[str] = []
    seen: set[str] = set()
    for term in must_have_terms:
        normalized = term.strip().lower()
        if normalized and normalized not in seen:
            seen.add(normalized)
            unique_terms.append(normalized)
    return unique_terms


def _term_matches(blob: str, term: str) -> bool:
    if term.isascii():
        return re.search(rf"\b{re.escape(term)}\b", blob) is not None
    return term in blob


def _count_hits(blob: str, must_have_terms: list[str]) -> int:
    return sum(1 for term in _unique_terms(must_have_terms) if _term_matches(blob, term))


class CandidateEvaluator:
    def evaluate_preview(self, preview: dict, must_have_terms: list[str]) -> CandidateDecision:
        blob = _text_blob(preview)
        unique_terms = _unique_terms(must_have_terms)
        hits = _count_hits(blob, unique_terms)
        # Preview stage is now coarse screening only: never link directly from preview.
        if unique_terms and hits > 0:
            return CandidateDecision(action="open_detail", reason=f"preview matches {hits}/{len(unique_terms)} keywords; requires detail review")
        return CandidateDecision(action="skip", reason="preview lacks enough relevant signals")

    def evaluate_detail(self, detail: dict, must_have_terms: list[str]) -> CandidateDecision:
        blob = _text_blob(detail)
        unique_terms = _unique_terms(must_have_terms)
        hits = _count_hits(blob, unique_terms)
        # Use 60% threshold for automated sourcing fallback
        if unique_terms and hits >= (len(unique_terms) * 0.6):
            return CandidateDecision(action="link", reason=f"detail matches {hits}/{len(unique_terms)} keywords")
        return CandidateDecision(action="skip", reason=f"detail only matches {hits}/{len(unique_terms)} keywords")
