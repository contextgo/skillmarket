"""
Tencent Cloud Slider Captcha Solver

基于图像匹配的滑块验证码求解器。
支持猎聘网站使用的腾讯云验证码。
"""

import asyncio
import os
import tempfile
from pathlib import Path
from typing import Optional, Tuple
from datetime import datetime

from PIL import Image, ImageFilter, ImageOps, ImageStat
from playwright.async_api import Page


class TencentCaptchaSolver:
    """
    腾讯云滑块验证码求解器
    
    工作原理:
    1. 从验证码 iframe 获取背景图和拼图块图片 URL
    2. 使用 page.request 获取图片数据 (绕过 iframe fetch 限制)
    3. 用 PIL 加载图片，找背景图上最暗区域 (缺口)
    4. 计算拖动距离并模拟人类拖动轨迹
    """
    
    def __init__(self, page: Page, timeout: int = 60):
        self.page = page
        self.timeout = timeout
        self.debug_dir = Path(__file__).resolve().parents[3] / "screenshots"
        self.debug_dir.mkdir(parents=True, exist_ok=True)
    
    async def solve(self, max_attempts: int = 2) -> bool:
        """
        求解验证码
        
        Args:
            max_attempts: 最大尝试次数
        
        Returns:
            bool: 是否成功
        """
        for attempt in range(1, max_attempts + 1):
            print(f"  🔍 [尝试 {attempt}/{max_attempts}] 求解验证码...")
            
            try:
                success = await self._solve_once()
                if success:
                    print(f"  ✅ 第 {attempt} 次尝试成功!")
                    return True
                else:
                    print(f"  ⚠️ 第 {attempt} 次失败，准备重试...")
                    await asyncio.sleep(2)
            except Exception as e:
                print(f"  ❌ [尝试 {attempt}] 异常：{e}")
                if attempt < max_attempts:
                    await asyncio.sleep(2)
        
        return False
    
    async def _solve_once(self) -> bool:
        """执行一次验证码求解"""
        # 找到验证码 frame
        captcha_frame = await self._get_captcha_frame()
        if not captcha_frame:
            print("  ❌ 未找到腾讯云验证码 frame")
            return False
        
        print(f"  ✅ 找到验证码 frame")
        await asyncio.sleep(0.8)
        
        # 获取图片
        try:
            bg_img, piece_img, bg_rect, piece_rect = await self._fetch_images(captcha_frame)
            print(f"  ✅ 图片获取成功：bg={bg_img.size}, piece={piece_img.size}")
        except Exception as e:
            print(f"  ❌ 获取图片失败：{e}")
            return False
        
        # 保存原始图，便于分析失败原因
        ts = datetime.now().strftime('%H%M%S')
        try:
            bg_img.save(str(self.debug_dir / f"{ts}_captcha_bg_runtime.png"))
            piece_img.save(str(self.debug_dir / f"{ts}_captcha_piece_runtime.png"))
        except Exception:
            pass

        # 图像匹配计算缺口位置：并行尝试 3 种独立方法
        try:
            gap_candidates = self._estimate_gap_candidates(bg_img, piece_img)
            print(f"  ✅ 图像匹配候选：{gap_candidates}")
        except Exception as e:
            print(f"  ❌ 图像匹配失败：{e}")
            return False
        
        # 获取滑块位置
        try:
            slider_box = await self._get_slider_button(captcha_frame)
            print(f"  ✅ 滑块位置：x={slider_box[0]:.1f}, y={slider_box[1]:.1f}")
        except Exception as e:
            print(f"  ❌ 获取滑块失败：{e}")
            return False
        
        scale = bg_rect["width"] / bg_img.width
        piece_start_in_bg = piece_rect["x"] - bg_rect["x"]

        start_x = slider_box[0] + slider_box[2] / 2
        start_y = slider_box[1] + slider_box[3] / 2
        candidate_offsets = [0, -8, 8]
        trial_no = 0

        for method_name, gap_x in gap_candidates:
            target_piece_left = gap_x * scale
            drag_distance = target_piece_left - piece_start_in_bg + 2.5
            print(f"  ✅ 方法 {method_name}: gap_x={gap_x}, drag={drag_distance:.1f}px (scale={scale:.3f})")

            if drag_distance < 50 or drag_distance > 350:
                print(f"  ⚠️ 方法 {method_name} 拖动距离异常，跳过")
                continue

            for offset in candidate_offsets:
                trial_no += 1
                trial_distance = drag_distance + offset
                if trial_distance < 50 or trial_distance > 350:
                    continue

                print(f"  🖱️ 尝试#{trial_no} [{method_name}] distance={trial_distance:.1f}px (offset={offset:+.1f})")
                await self._human_drag(start_x, start_y, trial_distance)

                print("  ⏳ 等待验证结果...")
                await asyncio.sleep(2.5)
                ok = await self._check_result()
                if ok:
                    return True

                try:
                    captcha_frame = await self._get_captcha_frame()
                    if captcha_frame:
                        reload_btn = captcha_frame.locator("#coverReload")
                        if await reload_btn.count() > 0 and await reload_btn.is_visible():
                            print("  🔄 点击验证码重试按钮")
                            await reload_btn.click()
                            await asyncio.sleep(1.5)
                            return False
                except Exception:
                    pass

        try:
            await self.page.screenshot(path=str(self.debug_dir / f"{ts}_captcha_failed_runtime.png"), full_page=False, timeout=5000)
        except Exception:
            pass
        return False
    
    async def _get_captcha_frame(self):
        """获取验证码 iframe"""
        for frame in self.page.frames:
            if frame.url and "turing.captcha.qcloud.com" in frame.url:
                return frame
        return None
    
    async def _fetch_images(self, frame):
        """获取验证码图片"""
        # 等待图片元素
        bg_el = frame.locator("img.tc-bg-img")
        piece_el = frame.locator("img.tc-jpp-img")
        
        await bg_el.wait_for(timeout=5000)
        await piece_el.wait_for(timeout=5000)
        
        bg_src = await bg_el.get_attribute("src")
        piece_src = await piece_el.get_attribute("src")
        bg_rect = await bg_el.bounding_box()
        piece_rect = await piece_el.bounding_box()
        
        if not bg_src or not piece_src:
            raise RuntimeError("图片 src 为空")
        
        # 使用 page.request 获取图片 (关键：绕过 iframe fetch 限制)
        bg_resp = await self.page.request.get(bg_src)
        piece_resp = await self.page.request.get(piece_src)
        
        bg_data = await bg_resp.body()
        piece_data = await piece_resp.body()
        
        if len(bg_data) == 0 or len(piece_data) == 0:
            raise RuntimeError("图片数据为空")
        
        # 保存为临时文件再打开 (PIL 对某些图片需要这样)
        with tempfile.NamedTemporaryFile(suffix='.bin', delete=False) as bg_tmp:
            bg_tmp.write(bg_data)
            bg_tmp_path = bg_tmp.name
        
        with tempfile.NamedTemporaryFile(suffix='.bin', delete=False) as piece_tmp:
            piece_tmp.write(piece_data)
            piece_tmp_path = piece_tmp.name
        
        try:
            bg_img = Image.open(bg_tmp_path).convert("RGB")
            piece_img = Image.open(piece_tmp_path).convert("RGB")
        finally:
            os.unlink(bg_tmp_path)
            os.unlink(piece_tmp_path)
        
        return bg_img, piece_img, bg_rect, piece_rect
    
    def _estimate_gap_candidates(self, bg_img: Image, piece_img: Image):
        """返回至少 3 种独立方法给出的 gap_x 候选。"""
        bg_gray = ImageOps.grayscale(bg_img)
        bg_edges = bg_gray.filter(ImageFilter.FIND_EDGES)
        piece_gray = ImageOps.grayscale(piece_img)
        piece_edges = piece_gray.filter(ImageFilter.FIND_EDGES)

        bg_w, bg_h = bg_gray.size
        pw, ph = piece_gray.size
        min_x = max(20, int(bg_w * 0.08))
        max_x = min(bg_w - pw - 20, int(bg_w * 0.92) - pw)
        if max_x <= min_x:
            min_x = 0
            max_x = bg_w - pw

        band_top = max(0, int(bg_h * 0.18))
        band_bottom = min(bg_h, int(bg_h * 0.82))

        # 方法1：暗区积分法
        col_darkness = []
        for x in range(bg_w):
            total = 0
            count = 0
            for y in range(band_top, band_bottom):
                total += bg_gray.getpixel((x, y))
                count += 1
            col_darkness.append(total / count if count else 255)
        best_dark_x = min(
            range(min_x, max_x + 1),
            key=lambda x: sum(col_darkness[x:x + pw]) / pw,
        )

        # 方法2：边缘差分法
        margin = max(6, min(pw, ph) // 12)
        sample_step = max(4, pw // 18)
        edge_points = []
        for x in range(margin, pw - margin, sample_step):
            edge_points.append((x, margin))
            edge_points.append((x, ph - margin - 1))
        for y in range(margin, ph - margin, sample_step):
            edge_points.append((margin, y))
            edge_points.append((pw - margin - 1, y))

        def edge_diff_score(cand_x):
            score = 0
            for px, py in edge_points:
                py_bg = min(bg_h - 1, max(0, py))
                score += abs(piece_edges.getpixel((px, py)) - bg_edges.getpixel((cand_x + px, py_bg)))
            return score / max(1, len(edge_points))

        best_edge_x = max(range(min_x, max_x + 1), key=edge_diff_score)

        # 方法3：列能量峰值法（垂直边缘 + 局部对比）
        col_energy = []
        for x in range(bg_w):
            total = 0
            count = 0
            for y in range(band_top, band_bottom):
                total += bg_edges.getpixel((x, y))
                count += 1
            col_energy.append(total / count if count else 0)
        best_energy_x = max(
            range(min_x, max_x + 1),
            key=lambda x: sum(col_energy[x:x + pw]) / pw,
        )

        # 方法4：旧综合法，保留作对照
        candidates = []
        for cand_x in range(min_x, max_x + 1):
            crop = bg_gray.crop((cand_x, band_top, cand_x + pw, band_bottom))
            stat = ImageStat.Stat(crop)
            mean_luma = stat.mean[0]
            std_luma = stat.stddev[0]
            window_dark = sum(col_darkness[cand_x:cand_x + pw]) / pw
            window_edge = sum(col_energy[cand_x:cand_x + pw]) / pw
            score = (
                (255 - mean_luma) * 0.50 +
                (255 - window_dark) * 0.20 +
                std_luma * 0.15 +
                window_edge * 0.05 +
                edge_diff_score(cand_x) * 0.10
            )
            candidates.append((score, cand_x))
        best_combo_x = max(candidates, key=lambda t: t[0])[1]

        results = [
            ("dark", best_dark_x),
            ("edge", best_edge_x),
            ("energy", best_energy_x),
            ("combo", best_combo_x),
        ]

        # 去重，保持顺序
        deduped = []
        seen = set()
        for name, x in results:
            if x not in seen:
                seen.add(x)
                deduped.append((name, x))
        return deduped
    
    async def _get_slider_button(self, frame):
        """获取滑块按钮位置和大小"""
        slider = frame.locator("#tcaptcha_drag_button")
        await slider.wait_for(timeout=3000)
        box = await slider.bounding_box()
        return (box["x"], box["y"], box["width"], box["height"])
    
    async def _human_drag(self, start_x: float, start_y: float, distance: float):
        """模拟人类拖动轨迹"""
        import random
        
        mouse = self.page.mouse
        await mouse.move(start_x, start_y)
        await asyncio.sleep(random.uniform(0.08, 0.15))
        await mouse.down()
        await asyncio.sleep(random.uniform(0.08, 0.16))
        
        # 先快后慢，尾部轻微回拉
        steps = 30
        overshoot = random.uniform(6, 14)
        total = distance + overshoot
        
        for i in range(steps):
            progress = (i + 1) / steps
            eased = 1 - (1 - progress) ** 2  # ease-out
            x = start_x + total * eased
            y = start_y + random.uniform(-1.8, 1.8)
            await mouse.move(x, y, steps=2)
            await asyncio.sleep(random.uniform(0.01, 0.03))
        
        # 微调回拉
        back = random.uniform(3, min(overshoot, 8))
        await mouse.move(start_x + distance - back, start_y + random.uniform(-1.0, 1.0), steps=4)
        await asyncio.sleep(random.uniform(0.04, 0.08))
        await mouse.move(start_x + distance, start_y + random.uniform(-0.8, 0.8), steps=3)
        await asyncio.sleep(random.uniform(0.25, 0.45))
        await mouse.up()
    
    async def _check_result(self) -> bool:
        """检查验证结果"""
        # 1) URL 跳转是最强成功信号
        if "login" not in self.page.url.lower():
            print("  ✅ URL 已跳转，验证成功")
            return True

        # 2) 验证码 iframe 消失后，再检查登录表单是否还在
        remaining_frames = [
            f for f in self.page.frames
            if f.url and "turing.captcha.qcloud.com" in f.url
        ]
        if not remaining_frames:
            print("  ℹ️ 验证码 iframe 已消失，继续检查页面状态")
            await asyncio.sleep(1.5)
            try:
                username_input = self.page.locator('input[placeholder*="用户名"], input[placeholder*="手机号"], input[placeholder*="邮箱"]')
                password_input = self.page.locator('input[type="password"]')
                username_visible = await username_input.count() > 0 and await username_input.first.is_visible()
                password_visible = await password_input.count() > 0 and await password_input.first.is_visible()
                if username_visible or password_visible:
                    print("  ⚠️ 登录表单仍可见，判定未登录")
                    return False
            except Exception:
                pass

            # 3) 检查正向页面特征，避免 body 取空时直接误判失败
            positive_selectors = [
                "text=推荐",
                "text=简历",
                "text=候选人",
                "text=立即沟通",
                "text=我的猎聘",
                "text=VIP",
                "a[href*='recommend']",
                "a[href*='resume']",
            ]
            for selector in positive_selectors:
                try:
                    locator = self.page.locator(selector)
                    if await locator.count() > 0 and await locator.first.is_visible():
                        print(f"  ✅ 命中成功特征：{selector}")
                        return True
                except Exception:
                    continue

            try:
                page_text = await self.page.locator("body").inner_text(timeout=3000)
                indicators = [kw for kw in ["推荐", "简历", "候选人", "立即沟通", "我的猎聘", "VIP"] if kw in page_text]
                if indicators:
                    print(f"  ✅ 页面文本命中成功指标：{indicators}")
                    return True
                print(f"  ⚠️ iframe 已消失，但未命中成功指标，文本长度={len(page_text)}")
            except Exception as e:
                print(f"  ⚠️ 页面文本检查异常：{e}")

            return False
        
        # 4) iframe 还在时，检查是否显示失败覆盖层
        try:
            captcha_frame = await self._get_captcha_frame()
            if captcha_frame:
                fail_btn = captcha_frame.locator("#coverReload")
                if await fail_btn.count() > 0 and await fail_btn.is_visible():
                    print("  ⚠️ 验证失败，显示重试按钮")
                    return False
        except Exception:
            pass
        
        print("  ⚠️ 未能明确判定成功，保守视为失败")
        return False
