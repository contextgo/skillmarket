"""
Liepin Skill - Browser Layer

Browser automation modules for Liepin sourcing:
- session: Authentication and persistent session management
- pages: Page object models for Liepin pages
- captcha: Captcha solving (Tencent Cloud slider)
"""

from liepin_skill.browser.session import LiepinSession, SessionConfig
from liepin_skill.browser.pages import LoginPage, SearchPage, CandidatePage
from liepin_skill.browser.captcha import TencentCaptchaSolver

__all__ = [
    "LiepinSession",
    "SessionConfig",
    "LoginPage",
    "SearchPage",
    "CandidatePage",
    "TencentCaptchaSolver",
]
