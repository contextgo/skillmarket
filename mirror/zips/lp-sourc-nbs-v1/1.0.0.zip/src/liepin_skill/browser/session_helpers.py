"""
共享的会话验证辅助函数

供各个脚本复用,避免重复代码。
"""
from typing import Optional
from playwright.async_api import Page


async def validate_session_at_recommend(page: Page) -> bool:
    """
    在 lpt.liepin.com/recommend 页面验证会话是否有效。
    
    Args:
        page: 已导航到 recommend 页面的 Page 对象
        
    Returns:
        True 如果会话有效, False 如果已过期或无效
    """
    try:
        # 等待页面稳定
        import asyncio
        await asyncio.sleep(2)
        
        # 检查 URL 是否被重定向到登录页
        current_url = page.url
        if "login" in current_url.lower():
            return False
        
        # 读取页面文本
        try:
            page_text = await page.locator("body").inner_text(timeout=5000)
        except Exception:
            return False
        
        # 检查明确的失效标记
        invalid_markers = [
            "帐号信息已过期",
            "此页面似乎不存在", 
            "登录/注册",
            "请退出帐号重新登录",
        ]
        if any(marker in page_text for marker in invalid_markers):
            return False
        
        # 检查有效会话的正面标记
        valid_markers = [
            "人才推荐",
            "职位管理",
            "搜索人才",
            "沟通",
            "人才管理",
        ]
        return any(marker in page_text for marker in valid_markers)
        
    except Exception:
        return False


def get_browser_launch_args() -> dict:
    """
    获取标准的浏览器启动参数。
    
    Returns:
        包含 locale, timezone_id, user_agent, viewport, args 的字典
    """
    return {
        "locale": "zh-CN",
        "timezone_id": "Asia/Shanghai",
        "user_agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/131.0.0.0 Safari/537.36"
        ),
        "viewport": {"width": 1440, "height": 900},
        "args": [
            "--lang=zh-CN",
            "--disable-features=VizDisplayCompositor",
            "--disable-blink-features=AutomationControlled",
            "--disable-dev-shm-usage",
            "--no-sandbox",
        ],
    }
