"""
Liepin Page Objects

Page object models for:
- Login page
- Search results page
- Candidate detail page
"""

import asyncio
import re
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

from playwright.async_api import Locator, Page


MASKED_NAME_RE = re.compile(r"^[\u4e00-\u9fffA-Za-z]{1,8}\*{1,2}$")
AGE_RE = re.compile(r"^\d{2}岁$")
EXPERIENCE_RE = re.compile(r"^(工作)?\d{1,2}年$")
GRAD_YEAR_RE = re.compile(r"^\d{4}年毕业$")
CITY_RE = re.compile(r"^[\u4e00-\u9fffA-Za-z·（）()\-]{2,20}$")
DATE_RANGE_RE = re.compile(r"\d{4}\.\d{2}-[至今\d]{2,7}.*")
SALARY_RE = re.compile(r"\d+(?:-\d+)?K")
DEGREE_WORDS = ["本科", "硕士", "博士", "博士后", "大专", "中专", "MBA", "EMBA", "高中", "Master", "Bachelor"]
RESPONSIBILITY_WORDS = ["负责", "职责", "工作职责", "汇报", "下属", "团队规模", "业绩", "覆盖", "管理"]
NOISE_WORDS = ["隐藏", "活跃状态", "立即沟通", "继续沟通", "期望：", "在线"]
SECTION_HEADING_PATTERNS = {
    "work": [r"^Work Experience$", r"^工作经历$"],
    "education": [r"^Educational Experience$", r"^教育经历$", r"^教育背景$"],
    "skills": [r"^Personal Skills$", r"^个人技能$", r"^关键词$"],
    "job_intention": [r"^Job Seeking Intention$", r"^求职意向$"],
}


@dataclass
class WorkExperienceEntry:
    company: Optional[str] = None
    role: Optional[str] = None
    date_range: Optional[str] = None
    duration: Optional[str] = None
    responsibilities: List[str] = field(default_factory=list)
    raw_text: Optional[str] = None


@dataclass
class EducationEntry:
    school: Optional[str] = None
    major: Optional[str] = None
    degree: Optional[str] = None
    study_mode: Optional[str] = None
    date_range: Optional[str] = None
    raw_text: Optional[str] = None


@dataclass
class CandidatePreview:
    name: Optional[str] = None
    title: Optional[str] = None
    current_company: Optional[str] = None
    current_city: Optional[str] = None
    education: Optional[str] = None
    experience_years: Optional[str] = None
    salary_range: Optional[str] = None
    last_active: Optional[str] = None
    action_button: Optional[str] = None
    is_already_communicated: bool = False  # ← 新增：猎聘显示"继续沟通"时为 True
    preview_summary: Optional[str] = None
    visible_keywords: List[str] = field(default_factory=list)
    current_industry: Optional[str] = None
    raw_text: Optional[str] = None
    element_index: int = 0


@dataclass
class SearchStats:
    total_count: int = 0
    page_number: int = 1
    total_pages: int = 1
    candidates_on_page: int = 0
    raw_text: Optional[str] = None


@dataclass
class CandidateDetail:
    name: Optional[str] = None
    current_role: Optional[str] = None
    current_company: Optional[str] = None
    city: Optional[str] = None
    experience_summary: Optional[str] = None
    education_summary: List[str] = field(default_factory=list)
    skills: List[str] = field(default_factory=list)
    domain_text: List[str] = field(default_factory=list)
    job_scope: List[str] = field(default_factory=list)
    work_experiences: List[WorkExperienceEntry] = field(default_factory=list)
    education_entries: List[EducationEntry] = field(default_factory=list)
    raw_text: Optional[str] = None


def _clean_lines(lines: List[str]) -> List[str]:
    cleaned: List[str] = []
    for line in lines:
        line = re.sub(r"\s+", " ", line.strip())
        if not line:
            continue
        if line in NOISE_WORDS:
            continue
        cleaned.append(line)
    return cleaned


def _split_lines(text: str) -> List[str]:
    return _clean_lines(text.splitlines())


def parse_work_experience_text(raw_text: str) -> WorkExperienceEntry:
    lines = _split_lines(raw_text)
    entry = WorkExperienceEntry(raw_text="\n".join(lines))
    if not lines:
        return entry

    entry.company = lines[0]
    if len(lines) >= 2:
        role_line = lines[1]
        match = re.search(r"(?P<role>.*?)(?P<date>\d{4}\.\d{2}-.*)$", role_line)
        if match:
            entry.role = match.group("role").strip() or None
            entry.date_range = match.group("date").strip()
            duration_match = re.search(r"(\([^\)]*\))$", entry.date_range)
            if duration_match:
                entry.duration = duration_match.group(1).strip("()")
        else:
            entry.role = role_line
    if len(lines) > 2:
        entry.responsibilities = [ln for ln in lines[2:] if any(word in ln for word in RESPONSIBILITY_WORDS)]
    return entry


def parse_education_text(raw_text: str) -> EducationEntry:
    lines = _split_lines(raw_text)
    entry = EducationEntry(raw_text="\n".join(lines))
    if not lines:
        return entry

    entry.school = lines[0]
    remainder = " ".join(lines[1:]) if len(lines) > 1 else ""
    if remainder:
        for degree in DEGREE_WORDS:
            if degree in remainder:
                entry.degree = degree
                break
        study_mode_match = re.search(r"(统招|非统招)", remainder)
        if study_mode_match:
            entry.study_mode = study_mode_match.group(1)
        date_match = re.search(r"(\d{4}\.\d{2}-\d{4}\.\d{2}\([^\)]*\))", remainder)
        if date_match:
            entry.date_range = date_match.group(1)
            remainder = remainder.replace(entry.date_range, " ")
        if entry.degree:
            remainder = remainder.replace(entry.degree, " ")
        if entry.study_mode:
            remainder = remainder.replace(entry.study_mode, " ")
        remainder = re.sub(r"\s+", " ", remainder).strip(" ·-")
        entry.major = remainder or None
    return entry


def parse_preview_text(card_text: str) -> CandidatePreview:
    lines = _split_lines(card_text)
    preview = CandidatePreview(raw_text="\n".join(lines))
    if not lines:
        return preview

    for idx, line in enumerate(lines):
        if MASKED_NAME_RE.match(line):
            preview.name = line
            meta = lines[idx + 1 : idx + 8]
            for meta_line in meta:
                if AGE_RE.match(meta_line):
                    continue
                if EXPERIENCE_RE.match(meta_line):
                    preview.experience_years = meta_line.replace("工作", "")
                elif GRAD_YEAR_RE.match(meta_line):
                    preview.experience_years = meta_line
                elif any(word in meta_line for word in DEGREE_WORDS):
                    preview.education = meta_line
                elif CITY_RE.match(meta_line) and not any(word in meta_line for word in DEGREE_WORDS):
                    preview.current_city = meta_line
            break

    if not preview.last_active:
        for line in lines[:4]:
            if "活跃" in line or line == "在线":
                preview.last_active = line
                break

    for line in lines:
        salary_match = SALARY_RE.search(line)
        if salary_match:
            preview.salary_range = salary_match.group(0)
            break

    if "期望：" in lines:
        idx = lines.index("期望：")
        if idx + 1 < len(lines):
            preview.preview_summary = lines[idx + 1]

    work_candidates = [ln for ln in lines if DATE_RANGE_RE.search(ln)]
    if work_candidates:
        work_line = work_candidates[0]
        match = re.search(r"(?P<title>.*?)(?P<date>\d{4}\.\d{2}-.*)$", work_line)
        if match:
            preview.title = match.group("title").strip() or work_line
        else:
            preview.title = work_line
        work_idx = lines.index(work_line)
        if work_idx > 0:
            preview.current_company = lines[work_idx - 1]

    edu_lines = [ln for ln in lines if any(word in ln for word in DEGREE_WORDS)]
    if edu_lines and not preview.education:
        preview.education = edu_lines[0]

    for idx, line in enumerate(lines):
        if idx == 0:
            continue
        if line == preview.name or line == preview.current_company or line == preview.title:
            continue
        if line == preview.education or line == preview.current_city or line == preview.experience_years:
            continue
        if line == preview.preview_summary or line == preview.last_active:
            continue
        if SALARY_RE.search(line) or DATE_RANGE_RE.search(line):
            continue
        if any(word in line for word in ["期望：", "简历", "搜索", "沟通状态", "获取联系方式状态"]):
            continue
        if any(word in line for word in ["有限公司", "公司", "集团", "银行", "科技", "器材", "制药", "汽车", "软件", "半导体"]):
            if not preview.current_industry and line != preview.current_company:
                preview.current_industry = line
                continue
        if line not in preview.visible_keywords and len(line) <= 24:
            preview.visible_keywords.append(line)

    if len(preview.visible_keywords) > 6:
        preview.visible_keywords = preview.visible_keywords[:6]

    # 检查沟通状态按钮
    if "立即沟通" in lines:
        preview.action_button = "立即沟通"
        preview.is_already_communicated = False
    elif "继续沟通" in lines:
        preview.action_button = "继续沟通"
        preview.is_already_communicated = True

    return preview


class LoginPage:
    def __init__(self, page: Page):
        self.page = page

    async def goto(self, url: str = "https://lpt.liepin.com/login"):
        await self.page.goto(url, wait_until="domcontentloaded")
        await asyncio.sleep(1)

    async def switch_to_password_login(self):
        try:
            password_tab = self.page.locator("li:has-text('密码登录')")
            if await password_tab.count() > 0:
                await password_tab.click()
                await asyncio.sleep(1)
        except Exception:
            pass

    async def fill_credentials(self, username: str, password: str):
        for selector in [
            'input[placeholder*="用户名"]',
            'input[placeholder*="手机号"]',
            'input[placeholder*="邮箱"]',
            'input[name="userName"]',
            'input[id="userName"]',
        ]:
            try:
                username_input = self.page.locator(selector)
                if await username_input.count() > 0:
                    await username_input.fill(username)
                    break
            except Exception:
                continue

        for selector in [
            'input[type="password"]',
            'input[name="password"]',
            'input[id="password"]',
        ]:
            try:
                password_input = self.page.locator(selector)
                if await password_input.count() > 0:
                    await password_input.fill(password)
                    break
            except Exception:
                continue

    async def submit(self):
        buttons = await self.page.locator("button").all()
        if buttons:
            await buttons[-1].click()

    async def is_logged_in(self) -> bool:
        current_url = self.page.url.lower()
        if "login" in current_url:
            return False
        try:
            for selector in [".user-info", ".user-name", "text=/我的猎聘/"]:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    return True
        except Exception:
            pass
        return False


class SearchPage:
    def __init__(self, page: Page):
        self.page = page

    async def goto(self, params: Optional[Dict[str, Any]] = None):
        from urllib.parse import urlencode

        base_url = "https://lpt.liepin.com/search"
        if params:
            base_url = f"{base_url}?{urlencode(params)}"
        await self.page.goto(base_url, wait_until="domcontentloaded", timeout=30000)
        await asyncio.sleep(3)

    async def detect_page_mode(self) -> str:
        try:
            text = await self.page.locator("body").inner_text(timeout=5000)
        except Exception:
            text = ""
        if any(m in text for m in ["帐号信息已过期", "此页面似乎不存在", "访问受限", "异常", "验证码", "验证", "登录/注册"]):
            return "restricted"
        return "normal"

    async def open_search_page_from_nav(self):
        print("[DEBUG] open_search_page_from_nav: starting")
        try:
            print("[DEBUG] open_search_page_from_nav: navigating to search page...")
            await self.page.goto("https://lpt.liepin.com/search", wait_until="commit", timeout=30000)
            print("[DEBUG] open_search_page_from_nav: URL is now:", self.page.url)
            # domcontentloaded can hang if page does a cookie-redirect. Use fixed sleep instead.
            await asyncio.sleep(5)
            print("[DEBUG] open_search_page_from_nav: sleep done, ready to interact")
            # Close tour popups / AI help popups if they exist
            # AI 帮搜 overlay has z-index:1000 and pointer-events:none on inner content
            # Must use force=True to bypass the overlay interception
            try:
                overlay = self.page.locator('[class*="overlay--"]').first
                if await overlay.count() > 0:
                    # Check if visible (overlay appears after a few seconds)
                    try:
                        is_vis = await overlay.is_visible(timeout=3000)
                    except:
                        is_vis = False
                    if is_vis:
                        print("[DEBUG] AI 帮搜 overlay visible, force-closing...")
                        # Must use force=True: the overlay div (z-index:1000) sits above the ✕ button
                        # and intercepts all pointer events unless we force the click through.
                        x_btn = overlay.locator('text=✕').first
                        if await x_btn.count() > 0:
                            await x_btn.click(force=True, timeout=2000)
                            await asyncio.sleep(1)
                            print("[DEBUG] Closed via ✕ button")
                        else:
                            # Fallback: ESC
                            await self.page.keyboard.press("Escape")
                            await asyncio.sleep(1)
                            print("[DEBUG] Closed via ESC")
            except Exception as e:
                print(f"[DEBUG] overlay close: {e}")
                # Last resort
                await self.page.keyboard.press("Escape")
                await asyncio.sleep(0.5)

            # Also try standard close buttons (for non-overlay modals)
            for close_btn in ['button:has-text("我知道了")', '.ant-lpt-modal-close', 'text=关闭']:
                try:
                    loc = self.page.locator(close_btn)
                    if await loc.count() > 0 and await loc.first.is_visible():
                        await loc.first.click(timeout=1000)
                        await asyncio.sleep(0.5)
                except Exception:
                    continue
            if await self.detect_page_mode() == "normal":
                return
        except Exception:
            pass

        for selector in ["text=搜索人才", "a:has-text('搜索人才')", "a[href*='/search']", "a[href*='search']"]:
            try:
                loc = self.page.locator(selector)
                if await loc.count() > 0 and await loc.first.is_visible():
                    await loc.first.click()
                    await self.page.wait_for_load_state("domcontentloaded")
                    await asyncio.sleep(3)
                    return
            except Exception:
                continue
        await self.goto()

    async def go_to_next_page(self) -> bool:
        """
        点击"下一页"按钮。
        Returns True if successfully moved to next page, False if no more pages or disabled.
        """
        try:
            # 猎聘常用的分页按钮选择器
            selectors = [
                '[title="下一页"]',
                '.ant-lpt-pagination-next',
                '.ant-lpt-pagination-next button',
                'li.ant-pagination-next:not(.ant-pagination-disabled)',
            ]

            for selector in selectors:
                next_btn = self.page.locator(selector).first
                if await next_btn.is_visible(timeout=2000):
                    # 检查是否已禁用（aria-disabled 或特定 class）
                    is_disabled = await next_btn.evaluate("""
                        el => el.getAttribute('aria-disabled') === 'true' ||
                              el.classList.contains('ant-lpt-pagination-disabled') ||
                              el.classList.contains('ant-pagination-disabled')
                    """)

                    if is_disabled:
                        return False

                    await next_btn.click()
                    # 等待页面加载（搜索结果列表刷新）
                    await self.page.wait_for_load_state("networkidle")
                    await asyncio.sleep(2)  # 给 DOM 一点缓冲时间
                    return True
            return False
        except Exception as e:
            print(f"Error navigating to next page: {e}")
            return False

    async def get_search_stats(self) -> SearchStats:
        stats = SearchStats()
        try:
            body_text = await self.page.locator("body").inner_text(timeout=5000)
            body_match = re.search(r"(共有\s*[\d,+]+\s*份简历)", body_text)
            if body_match:
                stats.raw_text = body_match.group(1)
                count_num = re.search(r"([\d,]+)", stats.raw_text)
                if count_num:
                    stats.total_count = int(count_num.group(1).replace(",", ""))
        except Exception:
            pass

        if not stats.raw_text:
            for pattern in [
                "text=/共有\\s*[\\d,+]+\\s*份简历/",
                "text=/共[有到]?\\s*[\\d,+]+\\s*份?简历/",
                "text=/[\\d,+]+\\s*份简历/",
                ".result-count",
                "[class*='result-count']",
            ]:
                try:
                    locator = self.page.locator(pattern)
                    if await locator.count() > 0:
                        text = await locator.first.text_content()
                        if text:
                            stats.raw_text = text
                            match = re.search(r"([\\d,]+)", text)
                            if match:
                                stats.total_count = int(match.group(1).replace(",", ""))
                            break
                except Exception:
                    continue

        stats.candidates_on_page = len(await self.get_candidate_previews())
        return stats

    async def _candidate_card_locators(self) -> List[Locator]:
        selectors = [
            "li.resumeCardWrap--FcnzW",
            "li[class*='resumeCardWrap']",
            "div.resumeCardContent--A03AZ",
            "div[class*='resume-card-new']",
        ]
        cards: List[Locator] = []
        for selector in selectors:
            try:
                loc = self.page.locator(selector)
                count = await loc.count()
                for i in range(count):
                    item = loc.nth(i)
                    if await item.is_visible():
                        cards.append(item)
                if cards:
                    return cards
            except Exception:
                continue
        return cards

    async def get_candidate_card_locators(self) -> List[Locator]:
        """Public wrapper for candidate card locators used by main workflow scripts."""
        return await self._candidate_card_locators()

    async def _parse_candidate_card(self, card: Locator, index: int) -> CandidatePreview:
        text = await card.inner_text(timeout=2000)
        preview = parse_preview_text(text)
        preview.element_index = index

        # --- Per-card button detection via DOM query (scoped to this card only) ---
        # Each card contains exactly one action button: "立即沟通" or "继续沟通"
        # Using direct DOM query ensures we get the button for THIS card, not from elsewhere on the page.
        try:
            imm_btn = card.locator('button:has-text("立即沟通")')
            cont_btn = card.locator('button:has-text("继续沟通")')
            imm_count = await imm_btn.count()
            cont_count = await cont_btn.count()
            if imm_count > 0:
                preview.action_button = "立即沟通"
                preview.is_already_communicated = False
            elif cont_count > 0:
                preview.action_button = "继续沟通"
                preview.is_already_communicated = True
        except Exception:
            # Fallback: text-based detection if DOM query fails
            if preview.action_button is None:
                if "立即沟通" in text:
                    preview.action_button = "立即沟通"
                    preview.is_already_communicated = False
                elif "继续沟通" in text:
                    preview.action_button = "继续沟通"
                    preview.is_already_communicated = True

        try:
            keyword_nodes = card.locator(".nest-resume-personal-skills, .keyWordList--F7UPD span, [class*='keyword']")
            count = await keyword_nodes.count()
            dom_keywords: List[str] = []
            for i in range(min(count, 10)):
                txt = await keyword_nodes.nth(i).inner_text(timeout=500)
                txt = txt.strip()
                if txt and txt not in dom_keywords and txt not in ["立即沟通", "继续沟通"]:
                    dom_keywords.append(txt)
            if dom_keywords:
                preview.visible_keywords = dom_keywords[:8]
        except Exception:
            pass

        try:
            work_items = card.locator(".nest-resume-work-item .work-item-content, .work-item-content")
            if await work_items.count() > 0:
                first_work = await work_items.first.inner_text(timeout=1000)
                work_entry = parse_work_experience_text(first_work)
                preview.current_company = work_entry.company or preview.current_company
                preview.title = work_entry.role or preview.title
        except Exception:
            pass

        return preview

    async def get_action_button(self, candidate_index: int = 0) -> Optional[str]:
        previews = await self.get_candidate_previews()
        if previews and candidate_index < len(previews):
            return previews[candidate_index].action_button
        return None

    async def get_candidate_previews(self) -> List[CandidatePreview]:
        candidates: List[CandidatePreview] = []
        cards = await self._candidate_card_locators()
        for i, card in enumerate(cards):
            try:
                preview = await self._parse_candidate_card(card, i)
                if preview.name or preview.title or preview.current_company:
                    candidates.append(preview)
            except Exception:
                continue
        return candidates

    async def _fill_top_search_query(self, query: str):
        top_query_done = False
        # Try multiple selectors and interaction methods
        selectors = ['input[placeholder*="搜职位/公司/行业"]', 'input[class*="searchInput"]', 'input[placeholder*="职位"]']
        for selector in selectors:
            try:
                loc = self.page.locator(selector).first
                if await loc.count() > 0:
                    # Force click to bypass transparent overlays or small popups
                    await loc.click(force=True, timeout=3000)
                    # Clear and fill
                    await loc.fill("", timeout=2000)
                    await loc.type(query, delay=50)
                    await self.page.wait_for_timeout(500)
                    top_query_done = True
                    break
            except Exception:
                continue
        return top_query_done

    async def fill_simple_keyword_query(self, query: str):
        return await self._fill_top_search_query(query)

    async def fill_keyword_groups(self, keyword_groups: List[List[str]] | List[tuple[str, ...]]):
        """
        Fill keyword groups in compound mode (OR within groups, AND between groups).
        Robust implementation with UI cleanup and JS fallback.
        """
        print("[DEBUG] fill_keyword_groups ENTRY")
        try:
            print("[DEBUG] fill_keyword_groups: page URL =", self.page.url)
            # 0. Dismiss any new feature / product popups that may have appeared after page load
            await self.page.keyboard.press("Escape")
            await asyncio.sleep(1)
            # 0b. Close AI Assistant wizard modal FIRST (blocks the entire search UI)
            for ai_close in [
                'button:has-text("以后再说")',    # "Remind me later" / skip wizard
                '[aria-label*="关闭"]',             # any close button
                '.ant-lpt-modal-close',            # standard modal close
                'button:has-text("X")',           # X button
                'button:has-text("✕")',           # X unicode button
                '[class*="modal"] button[class*="close"]',  # modal close btn
            ]:
                try:
                    loc = self.page.locator(ai_close)
                    if await loc.count() > 0 and await loc.first.is_visible():
                        await loc.first.click(timeout=2000)
                        await asyncio.sleep(0.5)
                        print(f"[DEBUG] Closed AI wizard with: {ai_close}")
                except: pass

            # 0b. Dismiss any remaining overlay by pressing Escape (handles "new feature" modals, guides, etc.)
            await self.page.keyboard.press("Escape")
            await asyncio.sleep(0.5)

            # 0c. UI Cleanup: Close any remaining blocking popups/tours
            for close_btn in ['.ant-lpt-modal-close', 'text=✕', 'button:has-text("我知道了")', 'text=关闭']:
                try:
                    loc = self.page.locator(close_btn)
                    if await loc.count() > 0 and await loc.first.is_visible():
                        await loc.first.click(timeout=1000)
                        await asyncio.sleep(0.5)
                except: continue

            # 1. Ensure we are in compound mode
            compound_input_selector = 'input[placeholder*="可填写多个"], input[placeholder*="关系的关键词，回车分隔"], input[placeholder*="关系的关键词"]'
            compound_inputs = self.page.locator(compound_input_selector)
            is_compound = False
            try:
                is_compound = await compound_inputs.first.is_visible(timeout=1000)
            except Exception:
                is_compound = False

            if not is_compound:
                print("[DEBUG] Not in compound mode, attempting to switch...")
                mode_triggers = ['text="包含全部关键词"', 'text="包含任一关键词"', '.ant-lpt-select-selection-item']
                switched = False
                for trigger_sel in mode_triggers:
                    try:
                        trigger = self.page.locator(trigger_sel).first
                        if await trigger.count() == 0:
                            continue
                        await trigger.click(force=True, timeout=3000)
                        await asyncio.sleep(0.5)
                        compound_opt = self.page.locator('text="复合关键词"').first
                        if await compound_opt.count() > 0:
                            await compound_opt.click(force=True, timeout=3000)
                        try:
                            await self.page.wait_for_selector(compound_input_selector, timeout=5000)
                            print("[DEBUG] Successfully switched to compound mode")
                            switched = True
                            break
                        except Exception:
                            continue
                    except Exception:
                        continue

                if not switched:
                    print("[WARN] Failed to switch mode, falling back to simple")
                    return await self._fallback_to_simple(keyword_groups)

            # 2. Fill groups
            groups_to_fill = keyword_groups[:5]
            print(f"[DEBUG] Starting to fill {len(groups_to_fill)} groups")
            for i, group in enumerate(groups_to_fill):
                print(f"[DEBUG] === Starting Group {i+1}: {group[:2]}... ===")
                # 正确时序：
                # - Group 1/2: 直接填当前唯一空着且带占位符的输入栏
                # - Group 3/4/5: 先点"增加要求"，再填当前唯一空着且带占位符的输入栏
                if i >= 2:
                    print(f"[DEBUG] Adding row {i+1}")
                    added = False
                    for btn_sel in ['text="+ 增加要求"', 'text="增加要求"', 'button:has-text("增加要求")']:
                        try:
                            btn = self.page.locator(btn_sel).first
                            if await btn.count() > 0:
                                await btn.click(force=True, timeout=3000)
                                await asyncio.sleep(1.0)
                                added = True
                                break
                        except Exception as ex:
                            print(f"[DEBUG] Add row attempt failed: {ex}")
                            continue
                    if not added:
                        print(f"[WARN] Failed to add row for group {i+1}")
                        break

                # Liepin only exposes one *active empty* compound input at a time via placeholder matching.
                # So always fill `.first` instead of indexing by group number.
                target_input = self.page.locator(compound_input_selector).first
                try:
                    cnt = await target_input.count()
                    print(f"[DEBUG] target_input.count() = {cnt}")
                    if cnt == 0:
                        print(f"[WARN] No active compound input available for group {i+1}")
                        break
                except Exception as ex:
                    print(f"[WARN] Compound input lookup failed for group {i+1}: {ex}")
                    break

                await target_input.scroll_into_view_if_needed()

                # 每组只点一次；同组内连续 type -> Enter，不再重复 click
                filled_kws = []
                try:
                    print(f"[DEBUG] Clicking target_input for group {i+1}")
                    await target_input.click(force=True, timeout=3000)
                    await asyncio.sleep(0.3)
                    print(f"[DEBUG] Click succeeded")
                except Exception as e:
                    print(f"[WARN] Initial click on group {i+1} failed: {e}")
                    continue

                print(f"[DEBUG] Typing {len(group)} keywords for group {i+1}")
                for kw in group:
                    clean_kw = kw.strip().replace(",", " ").replace(";", " ")
                    if not clean_kw:
                        continue
                    try:
                        print(f"[DEBUG] Typing: '{clean_kw}'")
                        await self.page.keyboard.type(clean_kw, delay=60)
                        await self.page.keyboard.press("Enter")
                        await asyncio.sleep(0.5)
                        filled_kws.append(clean_kw)
                        print(f"[DEBUG] Typed successfully, filled_kws={filled_kws}")
                    except Exception as te:
                        print(f"[WARN] keyword input failed for '{clean_kw}': {te}")

                # 3. Final Verification for this group
                # Note: Liepin renders tags as separate chip elements, not as text content.
                # Using a quick screenshot-based verification instead of inner_text().
                print(f"[DEBUG] Verifying group {i+1}, filled_kws={filled_kws}")
                try:
                    # Quick check: look for tag elements near the input
                    tag_locator = target_input.locator("xpath=..").locator("[class*='tag'], [class*='chip'], span:has-text('{kw}')")
                    tag_count = await tag_locator.count()
                    if tag_count > 0:
                        print(f"[OK] Group {i+1} verified ({tag_count} tags found)")
                    else:
                        # Fallback: just confirm keywords were typed without error
                        print(f"[OK] Group {i+1} confirmed (typed {len(filled_kws)} keywords)")
                except Exception as ex:
                    # If verification fails, just log and continue - typing succeeded
                    print(f"[DEBUG] Verification skipped for group {i+1}: {ex}")

            return True

        except Exception as e:
            print(f"Critical error in fill_keyword_groups: {e}")
            return await self._fallback_to_simple(keyword_groups)

    async def _fallback_to_simple(self, keyword_groups: List[List[str]] | List[tuple[str, ...]]):
        print("[DEBUG] Executing simple mode fallback")
        # Flatten first 2 groups as a simple query
        query_parts = []
        for g in keyword_groups[:2]:
            query_parts.extend(g)
        query = " ".join(query_parts)[:100]
        return await self._fill_top_search_query(query)

    async def fill_test_search_criteria(self, city: str, keyword_groups: List[List[str]]):
        # Implementation to align with the required 5-OR-group logic
        top_query_done = await self.fill_keyword_groups(keyword_groups)

        city_done = False
        try:
            # Simple city selection logic
            city_btn = self.page.locator(f'text="{city}"').first
            if await city_btn.count() > 0:
                await city_btn.click()
                city_done = True
        except Exception:
            pass

        return {
            "city_done": city_done,
            "keyword_groups_filled": len(keyword_groups) if top_query_done else 0,
            "top_query": top_query_done,
            "city_target": city,
            "search_mode": "compound" if top_query_done else "simple"
        }

    async def submit_search(self):
        for selector in ["button:has-text('搜索')", "button:has-text('搜 索')", "text=搜索"]:
            try:
                loc = self.page.locator(selector)
                if await loc.count() > 0 and await loc.first.is_visible():
                    await loc.first.click(timeout=5000)
                    await asyncio.sleep(5)
                    return
            except Exception:
                continue
        await self.page.keyboard.press("Enter")
        await asyncio.sleep(5)

    async def open_first_candidate_detail(self) -> bool:
        cards = await self._candidate_card_locators()
        if not cards:
            return False
        before = self.page.url
        try:
            await cards[0].click(position={"x": 120, "y": 120}, timeout=5000)
            await asyncio.sleep(4)
            return self.page.url != before or self.page.url.endswith("#preview") or "#preview" in self.page.url
        except Exception:
            return False

    async def return_to_list(self):
        try:
            await self.page.go_back(wait_until="domcontentloaded")
            await asyncio.sleep(3)
        except Exception:
            pass

    async def click_action_button(self, position_name: str, candidate_index: int = 0) -> bool:
        """
        Click communication button and select position.

        Args:
            position_name: Name of the position to select (e.g., "Brand Director")
            candidate_index: Index of candidate (default 0 for current preview)

        Returns:
            True if successful, False otherwise
        """
        try:
            # Step 1: Find the communication button in the preview modal
            preview_modal = self.page.locator(".ant-lpt-modal-wrap.resume-detail-modal-wrap").first
            if not await preview_modal.is_visible(timeout=3000):
                print("ERROR: Preview modal not visible")
                return False

            # Find the button (立即沟通 or 继续沟通)
            button = None
            button_type = None
            
            # Milestone 3 Overlay Fix: Check for and dismiss small popover/modal that may block the button
            for overlay_selector in ['.ant-popover', '.ant-modal-mask', '.ant-modal-wrap:not(.resume-detail-modal-wrap)', '.vip-guide-modal']:
                try:
                    overlay = self.page.locator(overlay_selector).first
                    if await overlay.is_visible(timeout=500):
                        print(f"Dismissing overlay: {overlay_selector}")
                        await self.page.keyboard.press("Escape")
                        await asyncio.sleep(1)
                except: pass

            # Milestone 3 Popup Button Fix: Look for "我知道了"/"确认" buttons on small popups
            popup_clicked = False
            for btn_text in ["我知道了", "确认", "确定", "好的", "知道了"]:
                try:
                    btn = self.page.locator(f'button:has-text("{btn_text}"), div[role="button"]:has-text("{btn_text}")').first
                    if await btn.is_visible(timeout=500):
                        print(f"Found popup button: {btn_text}, clicking with force=True...")
                        await btn.click(force=True)
                        await asyncio.sleep(1.5)
                        popup_clicked = True
                        print("Popup dismissed successfully!")
                        break
                except: pass
            
            if popup_clicked:
                # Wait a bit for the popup animation to finish
                await asyncio.sleep(0.5)

            for btn_text in ["立即沟通", "继续沟通"]:
                try:
                    btn = preview_modal.locator(f'button:has-text("{btn_text}")').first
                    if await btn.is_visible(timeout=1000):
                        button = btn
                        button_type = btn_text
                        print(f"Found button: {btn_text}")
                        break
                except:
                    continue

            if not button:
                print("ERROR: Communication button not found")
                return False

            # Skip if already communicated (继续沟通)
            if button_type == "继续沟通":
                print("SKIP: Already communicated with this candidate")
                return False

            # Step 2: Click the button
            await button.click()
            await asyncio.sleep(2)

            # Check for communication limit error
            try:
                body_text = await self.page.locator("body").inner_text(timeout=2000)
                if any(msg in body_text for msg in ["沟通次数已达上限", "沟通次数已用完", "今日沟通次数", "达到上限", "次数用尽"]):
                    print("ERROR: Daily communication limit reached")
                    raise RuntimeError("Daily communication limit reached - stopping task")
            except RuntimeError:
                raise  # Re-raise the RuntimeError to stop the task
            except Exception:
                pass  # Ignore other exceptions

            # Step 3: Wait for position selection modal
            position_modal = None
            for selector in ['[class*="modal"]', '.ant-lpt-modal', '[role="dialog"]']:
                try:
                    modal = self.page.locator(selector).last  # Use last to get the newest modal
                    if await modal.is_visible(timeout=3000):
                        modal_text = await modal.inner_text()
                        if "请选择开聊职位" in modal_text or "职位" in modal_text:
                            position_modal = modal
                            print("Position selection modal appeared")
                            break
                except:
                    continue

            if not position_modal:
                print("ERROR: Position selection modal did not appear")
                return False

            # Step 4: Scroll modal to load all positions
            # Find scrollable container
            scrollable = None
            for selector in ['[class*="modal-body"]', '[class*="position-list"]', '[class*="job-list"]']:
                try:
                    s = position_modal.locator(selector).first
                    if await s.is_visible(timeout=1000):
                        scrollable = s
                        print(f"Found scrollable container: {selector}")
                        break
                except:
                    continue

            if not scrollable:
                scrollable = position_modal
                print("Using modal as scrollable container")

            # Get bounding box and move mouse to center
            bbox = await scrollable.bounding_box()
            if bbox:
                center_x = bbox['x'] + bbox['width'] / 2
                center_y = bbox['y'] + bbox['height'] / 2
                print(f"Moving mouse to center: ({center_x:.0f}, {center_y:.0f})")
                await self.page.mouse.move(center_x, center_y)
                await asyncio.sleep(0.3)

            # Scroll to load all positions
            print("Scrolling to load positions...")
            for i in range(8):
                try:
                    await self.page.mouse.wheel(0, 300)
                    await asyncio.sleep(0.5)
                except Exception as e:
                    print(f"Scroll {i+1} failed: {e}")

            # Step 5: Find and click the target position (using partial match)
            # First try exact match
            position_items_list = await position_modal.locator(f'text="{position_name}"').all()

            # If exact match fails, try partial match (position name may include salary info)
            if not position_items_list:
                print(f"Exact match failed, trying partial match for: {position_name}")
                # Get all clickable elements that might be position items
                all_items = await position_modal.locator('div, span, p').all()
                for item in all_items:
                    try:
                        item_text = await item.inner_text(timeout=500)
                        # Check if position name is contained in the item text
                        if position_name in item_text and len(item_text) < 200:  # Avoid matching large containers
                            position_items_list = [item]
                            print(f"Found partial match: {item_text[:100]}")
                            break
                    except:
                        continue

            if not position_items_list:
                print(f"ERROR: Position '{position_name}' not found (tried exact and partial match)")
                # Try to show available positions for debugging
                modal_text = await position_modal.inner_text()
                print(f"Available positions:\n{modal_text}")
                # Close modal before returning
                try:
                    cancel_btn = position_modal.locator('button:has-text("取消")').first
                    if await cancel_btn.is_visible(timeout=1000):
                        await cancel_btn.click()
                        print("Closed modal via cancel button")
                        await asyncio.sleep(1)
                except Exception as e:
                    print(f"Failed to close modal: {e}")
                return False

            # Click the first match
            if position_items_list:
                await position_items_list[0].click()
                print(f"Selected position: {position_name}")
                await asyncio.sleep(0.5)

            # Step 6: Click confirm button
            confirm_button = None
            for btn_text in ["确认", "确定", "OK"]:
                try:
                    btn = position_modal.locator(f'button:has-text("{btn_text}")').first
                    if await btn.is_visible(timeout=1000):
                        confirm_button = btn
                        break
                except:
                    continue

            if not confirm_button:
                print("ERROR: Confirm button not found")
                return False

            await confirm_button.click()
            await asyncio.sleep(2)

            # Verify modal closed
            try:
                if not await position_modal.is_visible(timeout=2000):
                    print("Communication flow completed successfully")
                    return True
            except:
                pass

            print("Modal may still be visible, but flow completed")
            return True

        except Exception as e:
            print(f"ERROR in click_action_button: {e}")
            import traceback
            traceback.print_exc()
            return False


class CandidatePage:
    def __init__(self, page: Page):
        self.page = page

    async def is_open(self) -> bool:
        current_url = self.page.url.lower()
        return "resume" in current_url or "candidate" in current_url or "#preview" in current_url

    async def close(self):
        try:
            await self.page.go_back(wait_until="domcontentloaded")
            await asyncio.sleep(1)
        except Exception:
            pass

    async def _detail_container(self) -> Locator:
        selectors = [
            ".resume-detail-content-body.printable-content",
            ".resume-detail-content-body",
            "[class*='resume-detail-content-body']",
        ]
        for selector in selectors:
            loc = self.page.locator(selector).first
            try:
                if await loc.count() > 0:
                    return loc
            except Exception:
                continue
        return self.page.locator("body").first

    async def _first_text_from_container(self, container: Locator, selectors: List[str], timeout: int = 800) -> Optional[str]:
        for selector in selectors:
            try:
                loc = container.locator(selector)
                count = await loc.count()
                for i in range(count):
                    txt = (await loc.nth(i).inner_text(timeout=timeout)).strip()
                    if txt:
                        return txt
            except Exception:
                continue
        return None

    async def _texts_from_container(self, container: Locator, selectors: List[str], timeout: int = 1000, limit: int = 30) -> List[str]:
        values: List[str] = []
        for selector in selectors:
            try:
                loc = container.locator(selector)
                count = await loc.count()
                for i in range(min(count, limit)):
                    txt = (await loc.nth(i).inner_text(timeout=timeout)).strip()
                    if txt and txt not in values:
                        values.append(txt)
            except Exception:
                continue
            if values:
                return values
        return values

    def _extract_section_lines(self, body_text: str, section_key: str) -> List[str]:
        lines = _split_lines(body_text)
        if not lines:
            return []
        patterns = [re.compile(p, re.I) for p in SECTION_HEADING_PATTERNS.get(section_key, [])]
        start_idx: Optional[int] = None
        for idx, line in enumerate(lines):
            if any(p.search(line) for p in patterns):
                start_idx = idx + 1
                break
        if start_idx is None:
            return []

        stop_patterns = []
        for key, pats in SECTION_HEADING_PATTERNS.items():
            if key == section_key:
                continue
            stop_patterns.extend(re.compile(p, re.I) for p in pats)

        section_lines: List[str] = []
        for line in lines[start_idx:]:
            if any(p.search(line) for p in stop_patterns):
                break
            section_lines.append(line)
        return section_lines

    def _parse_work_entries_from_section_lines(self, lines: List[str]) -> List[WorkExperienceEntry]:
        entries: List[WorkExperienceEntry] = []
        current_entry: Optional[WorkExperienceEntry] = None
        collecting_resp = False

        for idx, raw_line in enumerate(lines):
            line = raw_line.strip()
            if not line or line in NOISE_WORDS:
                continue
            if any(re.search(p, line, re.I) for pats in SECTION_HEADING_PATTERNS.values() for p in pats):
                break

            parsed_role = self._parse_role_and_date_line(line) if DATE_RANGE_RE.search(line) else None
            if parsed_role and (parsed_role["role"] or parsed_role["date_range"]):
                if current_entry and current_entry.company and not current_entry.role:
                    current_entry.role = parsed_role["role"]
                    current_entry.date_range = parsed_role["date_range"]
                    current_entry.duration = parsed_role["duration"]
                    current_entry.raw_text = (current_entry.raw_text or "") + "\n" + line
                    collecting_resp = False
                    continue
                if current_entry and (current_entry.company or current_entry.role):
                    entries.append(current_entry)
                company = None
                prev_idx = idx - 1
                if prev_idx >= 0:
                    prev_line = lines[prev_idx].strip()
                    if self._looks_like_company_line(prev_line):
                        company = prev_line
                current_entry = WorkExperienceEntry(
                    company=company,
                    role=parsed_role["role"],
                    date_range=parsed_role["date_range"],
                    duration=parsed_role["duration"],
                    responsibilities=[],
                    raw_text=((company + "\n") if company else "") + line,
                )
                collecting_resp = False
                continue

            if current_entry is None:
                if self._looks_like_company_line(line):
                    current_entry = WorkExperienceEntry(company=line, responsibilities=[], raw_text=line)
                continue

            if current_entry.company is None and self._looks_like_company_line(line):
                current_entry.company = line
                current_entry.raw_text = line + "\n" + (current_entry.raw_text or "")
                continue

            if current_entry.role is None and DATE_RANGE_RE.search(line):
                parsed_role = self._parse_role_and_date_line(line)
                current_entry.role = parsed_role["role"]
                current_entry.date_range = parsed_role["date_range"]
                current_entry.duration = parsed_role["duration"]
                current_entry.raw_text = (current_entry.raw_text or "") + "\n" + line
                collecting_resp = False
                continue

            if any(token in line for token in ["工作职责", "工作经验", "工作业绩", "职责：", "职责", "业绩"]):
                collecting_resp = True
                current_entry.responsibilities.append(line)
                current_entry.raw_text = (current_entry.raw_text or "") + "\n" + line
                continue

            if collecting_resp or any(word in line for word in RESPONSIBILITY_WORDS) or re.match(r"^[\-\d一二三四五六七八九十（(]", line):
                current_entry.responsibilities.append(line)
                current_entry.raw_text = (current_entry.raw_text or "") + "\n" + line
                continue

        if current_entry and (current_entry.company or current_entry.role):
            entries.append(current_entry)
        return entries

    def _parse_education_entries_from_section_lines(self, lines: List[str]) -> List[EducationEntry]:
        entries: List[EducationEntry] = []
        current: List[str] = []
        for line in lines:
            if line in NOISE_WORDS:
                continue
            if any(re.search(p, line, re.I) for pats in SECTION_HEADING_PATTERNS.values() for p in pats):
                break
            if len(line) <= 40 or current:
                current.append(line)
            if re.search(r"\d{4}\.\d{2}-\d{4}\.\d{2}\([^\)]*\)", line):
                entry = parse_education_text("\n".join(current))
                if entry.school or entry.degree:
                    entries.append(entry)
                current = []
        return entries

    def _extract_skills_from_section_lines(self, lines: List[str]) -> List[str]:
        skills: List[str] = []
        for line in lines:
            if line in NOISE_WORDS:
                continue
            if len(line) <= 40 and line not in skills:
                skills.append(line)
        return skills

    def _extract_current_role_company_from_section_lines(self, lines: List[str]) -> Dict[str, Optional[str]]:
        result: Dict[str, Optional[str]] = {"current_company": None, "current_role": None}
        for idx, line in enumerate(lines):
            if DATE_RANGE_RE.search(line):
                parsed = parse_work_experience_text("\n".join(lines[max(0, idx - 1): idx + 1]))
                result["current_company"] = parsed.company
                result["current_role"] = parsed.role
                break
        return result

    def _merge_harvest_chunks(self, chunks: List[str]) -> str:
        if not chunks:
            return ""
        merged_lines: List[str] = []
        for chunk in chunks:
            lines = _split_lines(chunk)
            if not lines:
                continue
            if not merged_lines:
                merged_lines.extend(lines)
                continue
            max_overlap = min(len(merged_lines), len(lines), 80)
            overlap = 0
            for size in range(max_overlap, 0, -1):
                if merged_lines[-size:] == lines[:size]:
                    overlap = size
                    break
            for line in lines[overlap:]:
                if merged_lines and line == merged_lines[-1]:
                    continue
                merged_lines.append(line)
        return "\n".join(merged_lines)

    def _looks_like_company_line(self, line: str) -> bool:
        if not line or line in NOISE_WORDS:
            return False
        if DATE_RANGE_RE.search(line):
            return False
        if any(re.search(p, line, re.I) for pats in SECTION_HEADING_PATTERNS.values() for p in pats):
            return False
        if any(token in line for token in ["工作职责", "工作经验", "工作业绩", "职责：", "职责", "业绩", "覆盖", "负责"]):
            return False
        if len(line) > 80:
            return False
        return True

    def _parse_role_and_date_line(self, line: str) -> Dict[str, Optional[str]]:
        match = re.search(r"(?P<role>.*?)(?P<date>\d{4}\.\d{2}-.*)$", line)
        if not match:
            return {"role": None, "date_range": None, "duration": None}
        date_range = match.group("date").strip()
        duration_match = re.search(r"\(([^\)]*)\)$", date_range)
        return {
            "role": match.group("role").strip() or None,
            "date_range": date_range,
            "duration": duration_match.group(1).strip() if duration_match else None,
        }

    def _focus_active_candidate_block(self, body_text: str) -> str:
        lines = _split_lines(body_text)
        if not lines:
            return body_text

        anchor_idx = None
        for idx, line in enumerate(lines):
            if "姓名保护" in line or MASKED_NAME_RE.match(line) or (("先生" in line or "女士" in line) and len(line) <= 30):
                anchor_idx = idx
        if anchor_idx is None:
            return body_text

        focused = lines[anchor_idx:]
        return "\n".join(focused)

    def _extract_basic_fields_from_harvested_text(self, body_text: str) -> Dict[str, Optional[str]]:
        basics: Dict[str, Optional[str]] = {
            "name": None,
            "city": None,
            "experience_summary": None,
        }
        lines = _split_lines(body_text)
        if not lines:
            return basics

        for line in lines[:20]:
            if not basics["name"] and (
                MASKED_NAME_RE.match(line)
                or "姓名保护" in line
                or ("先生" in line and len(line) <= 20)
                or ("女士" in line and len(line) <= 20)
            ):
                basics["name"] = line
                continue

            if not basics["experience_summary"] and (
                EXPERIENCE_RE.match(line)
                or re.search(r"\d{1,2}\s*Years of work experience", line, re.I)
                or re.search(r"工作\s*\d{1,2}年", line)
            ):
                basics["experience_summary"] = line.replace("工作", "").strip()
                continue

            if not basics["city"]:
                city_candidate = line.strip()
                if any(token in city_candidate for token in ["-", "·", "上海", "北京", "深圳", "广州", "杭州", "苏州", "美国", "洛杉矶", "Shanghai", "Beijing"]):
                    if not any(bad in city_candidate for bad in ["Work Experience", "Educational Experience", "Job Seeking", "Resume", "Director", "Sales", "ArcelorMittal", "ICL", "AHB", "Adama"]):
                        basics["city"] = city_candidate
                        continue
                if CITY_RE.match(city_candidate) and not any(bad in city_candidate for bad in ["Director", "Sales", "Manager", "ArcelorMittal", "ICL", "AHB", "Adama"]):
                    basics["city"] = city_candidate
                    continue

        return basics

    async def harvest_preview_text(self, step_px: int = 700, max_steps: int = 8) -> Dict[str, Any]:
        container = await self._detail_container()
        chunks: List[str] = []
        scroll_positions: List[int] = []
        try:
            metrics = await container.evaluate(
                """el => ({clientHeight: el.clientHeight || 0, scrollHeight: el.scrollHeight || 0})"""
            )
        except Exception:
            metrics = {"clientHeight": 0, "scrollHeight": 0}

        max_scroll = max(0, int(metrics.get("scrollHeight", 0)) - int(metrics.get("clientHeight", 0)))
        positions = [0]
        if max_scroll > 0:
            pos = step_px
            while pos < max_scroll and len(positions) < max_steps:
                positions.append(pos)
                pos += step_px
            if positions[-1] != max_scroll and len(positions) < max_steps:
                positions.append(max_scroll)

        for pos in positions[:max_steps]:
            try:
                await container.evaluate("(el, y) => { el.scrollTop = y; }", pos)
                await self.page.wait_for_timeout(350)
                text = await container.inner_text(timeout=1500)
                text = text.strip()
                if text and text not in chunks:
                    chunks.append(text)
                    scroll_positions.append(pos)
            except Exception:
                continue

        return {
            "chunks": chunks,
            "scroll_positions": scroll_positions,
            "clientHeight": metrics.get("clientHeight", 0),
            "scrollHeight": metrics.get("scrollHeight", 0),
        }

    async def get_full_info(self) -> Dict[str, Any]:
        detail = CandidateDetail()
        container = await self._detail_container()
        harvest = await self.harvest_preview_text()
        merged_text = self._merge_harvest_chunks(harvest["chunks"])
        body_text = self._focus_active_candidate_block(merged_text) or await container.inner_text(timeout=5000)
        detail.raw_text = body_text

        basics = self._extract_basic_fields_from_harvested_text(body_text)
        detail.name = basics["name"]
        detail.city = basics["city"]
        detail.experience_summary = basics["experience_summary"]

        work_section_lines = self._extract_section_lines(body_text, "work")
        education_section_lines = self._extract_section_lines(body_text, "education")
        skills_section_lines = self._extract_section_lines(body_text, "skills")
        if not skills_section_lines:
            zh_skill_lines = self._extract_section_lines(body_text, "job_intention")
            if zh_skill_lines:
                skills_section_lines = []

        parsed_work_entries = self._parse_work_entries_from_section_lines(work_section_lines)
        if parsed_work_entries:
            detail.work_experiences.extend(parsed_work_entries)
            detail.current_company = parsed_work_entries[0].company
            detail.current_role = parsed_work_entries[0].role
        else:
            try:
                work_texts = await self._texts_from_container(
                    container,
                    [
                        ".nest-resume-work-item .work-item-content",
                        ".work-item-content",
                        "[class*='work-item-content']",
                    ],
                )
                for txt in work_texts:
                    entry = parse_work_experience_text(txt)
                    if entry.company or entry.role:
                        detail.work_experiences.append(entry)
                if detail.work_experiences:
                    detail.current_company = detail.work_experiences[0].company
                    detail.current_role = detail.work_experiences[0].role
            except Exception:
                pass

        parsed_education_entries = self._parse_education_entries_from_section_lines(education_section_lines)
        if parsed_education_entries:
            detail.education_entries.extend(parsed_education_entries)
            detail.education_summary.extend([entry.raw_text or "" for entry in parsed_education_entries if entry.raw_text])
        else:
            try:
                edu_texts = await self._texts_from_container(
                    container,
                    [
                        ".edu-item-content",
                        "[class*='edu-item-content']",
                    ],
                )
                for txt in edu_texts:
                    entry = parse_education_text(txt)
                    if entry.school or entry.degree:
                        detail.education_entries.append(entry)
                        detail.education_summary.append(txt.strip())
            except Exception:
                pass

        section_skills = self._extract_skills_from_section_lines(skills_section_lines)
        if section_skills:
            detail.skills.extend(section_skills)
        else:
            try:
                skill_texts = await self._texts_from_container(
                    container,
                    [
                        ".nest-resume-personal-skills span",
                        ".nest-resume-personal-skills",
                        ".keyWordList--F7UPD span",
                        "[class*='keyword']",
                    ],
                    timeout=500,
                    limit=20,
                )
                for txt in skill_texts:
                    norm = txt.strip()
                    if not norm:
                        continue
                    if "\n" in norm and len(norm) <= 40:
                        norm = norm.split("\n", 1)[0].strip()
                    if norm and norm not in detail.skills:
                        detail.skills.append(norm)
            except Exception:
                pass

        domain_text: List[str] = []
        for line in _split_lines(body_text):
            if any(word in line for word in ["半导体", "汽车", "银行", "制药", "化工", "软件", "器材", "外贸", "销售", "director", "sales"]):
                if line not in domain_text:
                    domain_text.append(line)
            if len(domain_text) >= 12:
                break
        detail.domain_text = domain_text

        job_scope: List[str] = []
        for line in work_section_lines or _split_lines(body_text):
            if any(word in line for word in RESPONSIBILITY_WORDS):
                if line not in job_scope:
                    job_scope.append(line)
        detail.job_scope = job_scope[:12]

        result = asdict(detail)
        result["harvest_meta"] = {
            "chunk_count": len(harvest["chunks"]),
            "scroll_positions": harvest["scroll_positions"],
            "clientHeight": harvest["clientHeight"],
            "scrollHeight": harvest["scrollHeight"],
            "scoped_to_active_preview": True,
            "work_section_line_count": len(work_section_lines),
            "education_section_line_count": len(education_section_lines),
            "skills_section_line_count": len(skills_section_lines),
        }
        return result
