"""
Liepin Session Management

Handles:
- Persistent browser profile/storage
- Authentication bootstrap (login + captcha)
- Session validation and refresh
"""

import asyncio
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field

from playwright.async_api import async_playwright, Browser, BrowserContext, Page


@dataclass
class SessionConfig:
    """会话配置"""
    
    # 账号凭证
    username: str
    password: str
    
    # 持久化存储路径 (相对于 skill 根目录或绝对路径)
    storage_path: str = "browser_storage"
    
    # 浏览器配置
    headless: bool = True
    locale: str = "zh-CN"
    timezone_id: str = "Asia/Shanghai"
    
    # 超时配置 (秒)
    navigation_timeout: int = 30
    action_timeout: int = 10
    
    # 登录 URL
    login_url: str = "https://lpt.liepin.com/login"
    
    def resolve_storage_path(self, base_dir: Optional[Path] = None) -> Path:
        """解析持久化存储路径"""
        storage = Path(self.storage_path)
        if storage.is_absolute():
            return storage
        if base_dir:
            return base_dir / storage
        # 默认相对于当前工作目录
        return Path.cwd() / storage


class LiepinSession:
    """
    猎聘会话管理
    
    特性:
    - 持久化存储 (cookies, localStorage)
    - 自动登录 (含验证码处理)
    - 会话有效性验证
    """
    
    def __init__(self, config: SessionConfig, base_dir: Optional[Path] = None):
        self.config = config
        self.base_dir = base_dir or Path(__file__).parent.parent.parent
        self.storage_dir = self.config.resolve_storage_path(self.base_dir)
        
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
    
    @property
    def browser(self) -> Browser:
        if self._browser is None:
            raise RuntimeError("Browser not initialized. Call start() first.")
        return self._browser
    
    @property
    def context(self) -> BrowserContext:
        if self._context is None:
            raise RuntimeError("Context not initialized. Call start() first.")
        return self._context
    
    @property
    def page(self) -> Page:
        if self._page is None:
            raise RuntimeError("Page not initialized. Call start() first.")
        return self._page
    
    async def start(self) -> "LiepinSession":
        """启动浏览器并加载持久化会话"""
        from playwright.async_api import async_playwright
        
        self._playwright = await async_playwright().start()
        
        # 确保存储目录存在
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        storage_state = self.storage_dir / "storage_state.json"
        
        # 启动浏览器
        self._browser = await self._playwright.chromium.launch(
            headless=self.config.headless,
            args=[
                "--lang=zh-CN",
                "--disable-features=VizDisplayCompositor",
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-web-security",
                "--disable-features=IsolateOrigins,site-per-process",
            ],
        )
        
        # 创建上下文（先创建，再加初始化脚本）
        if storage_state.exists():
            print(f"📦 加载持久化会话：{storage_state}")
            self._context = await self._browser.new_context(
                storage_state=storage_state,
                locale=self.config.locale,
                timezone_id=self.config.timezone_id,
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                viewport={"width": 1920, "height": 1080},
            )
        else:
            print("🆕 创建新会话 (无持久化数据)")
            self._context = await self._browser.new_context(
                locale=self.config.locale,
                timezone_id=self.config.timezone_id,
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                viewport={"width": 1920, "height": 1080},
            )
        
        # 添加更强的反检测脚本
        await self._context.add_init_script("""
            // 隐藏 webdriver 特征
            Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
            
            // 伪造 plugins
            Object.defineProperty(navigator, 'plugins', { 
                get: () => [1, 2, 3, 4, 5] 
            });
            
            // 伪造 languages
            Object.defineProperty(navigator, 'languages', { 
                get: () => ['zh-CN', 'zh', 'en'] 
            });
            
            // 伪造 hardwareConcurrency
            Object.defineProperty(navigator, 'hardwareConcurrency', { 
                get: () => 8 
            });
            
            // 伪造 deviceMemory
            Object.defineProperty(navigator, 'deviceMemory', { 
                get: () => 8 
            });
            
            // 伪造 vendor
            Object.defineProperty(navigator, 'vendor', { 
                get: () => 'Google Inc.' 
            });
            
            // 伪造 vendorSub
            Object.defineProperty(navigator, 'vendorSub', { 
                get: () => '' 
            });
            
            // 伪造 productSub
            Object.defineProperty(navigator, 'productSub', { 
                get: () => '20030107' 
            });
            
            // 隐藏 automation 特征
            delete navigator.__proto__.webdriver;
            
            // 伪造 permissions
            const originalQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (parameters) => (
                parameters.name === 'notifications' ?
                    Promise.resolve({ state: Notification.permission }) :
                    originalQuery(parameters)
            );
        """)
        
        self._page = await self._context.new_page()
        
        # 验证会话是否有效
        is_valid = await self._validate_session()
        if not is_valid:
            print("⚠️ 会话已过期，重新登录...")
            await self._do_login()
        
        return self
    
    async def _validate_session(self) -> bool:
        """验证会话是否有效"""
        try:
            await self._page.goto(
                "https://lpt.liepin.com/recommend",
                timeout=self.config.navigation_timeout * 1000,
                wait_until="domcontentloaded",
            )
            await asyncio.sleep(2)

            current_url = self._page.url
            if "login" in current_url.lower():
                return False

            # 读取正文，识别典型过期/错误页，避免 URL 假阳性
            page_text = ""
            try:
                page_text = await self._page.locator("body").inner_text(timeout=5000)
            except Exception:
                page_text = ""

            invalid_markers = [
                "您的帐号信息已过期，请退出帐号重新登录",
                "此页面似乎不存在",
                "登录/注册",
            ]
            if any(marker in page_text for marker in invalid_markers):
                print("⚠️ 检测到过期会话或错误页，视为未登录")
                return False

            # 强成功信号：推荐页核心元素/业务文案
            positive_selectors = [
                "text=候选人",
                "text=立即沟通",
                "text=推荐人选",
                "a[href*='resume']",
                "a[href*='recommend']",
            ]
            for selector in positive_selectors:
                try:
                    locator = self._page.locator(selector)
                    if await locator.count() > 0 and await locator.first.is_visible():
                        return True
                except Exception:
                    continue

            # 如果没有命中明显失败页，也没有命中明显成功特征，保守判未登录
            return False
        except Exception as e:
            print(f"会话验证异常：{e}")
            return False
    
    async def _do_login(self):
        """执行登录流程（含验证码处理）"""
        from liepin_skill.browser.captcha import TencentCaptchaSolver
        
        print(f"🔐 开始登录：{self.config.username}")
        
        # 打开登录页
        print("🌐 打开登录页...")
        await self._page.goto(
            self.config.login_url,
            timeout=self.config.navigation_timeout * 1000,
            wait_until="domcontentloaded",
        )
        await asyncio.sleep(3)  # 多等一会儿让页面完全加载
        print(f"🌐 当前 URL: {self._page.url}")
        
        # 切换到密码登录
        print("🔑 尝试切换到密码登录...")
        try:
            password_login = self._page.locator("li:has-text('密码登录')")
            count = await password_login.count()
            print(f"🔑 密码登录 tab count={count}")
            if count > 0:
                await password_login.click()
                await asyncio.sleep(2)
                print("🔑 已点击密码登录")
        except Exception as e:
            print(f"⚠️ 切换密码登录异常：{e}")
            pass  # 可能已经在密码登录页
        
        # 填写账号密码
        print("📝 准备填写账号密码...")
        username_input = self._page.locator('input[placeholder*="用户名"], input[placeholder*="手机号"], input[placeholder*="邮箱"]')
        password_input = self._page.locator('input[type="password"]')
        
        await username_input.fill(self.config.username)
        print("📝 用户名已填写")
        await password_input.fill(self.config.password)
        print("📝 密码已填写")
        
        # 点击登录按钮
        buttons = await self._page.locator("button").all()
        print(f"🚀 检测到 button 数量={len(buttons)}")
        if buttons:
            await buttons[-1].click()
            print("🚀 已点击登录按钮")
        
        # 等待验证码或登录结果
        await asyncio.sleep(5)
        print(f"⏳ 点击登录后 URL: {self._page.url}")
        
        # 检查是否需要验证码
        if await self._has_captcha():
            print("🧩 检测到验证码，开始求解...")
            solver = TencentCaptchaSolver(self._page)
            success = await solver.solve()
            
            if not success:
                raise RuntimeError("验证码求解失败")
            
            await asyncio.sleep(3)
        
        # 验证登录结果
        await asyncio.sleep(3)
        
        # 截图保存用于调试（避免 full_page 卡死）
        from pathlib import Path
        screenshot_path = self.storage_dir / "login_result.png"
        try:
            await self._page.screenshot(path=str(screenshot_path), full_page=False, timeout=5000)
            print(f"📸 登录结果截图：{screenshot_path}")
        except Exception as e:
            print(f"⚠️ 登录结果截图失败：{e}")
        
        if self._page.url == self.config.login_url:
            # 检查是否仍有验证码 frame
            if await self._has_captcha():
                raise RuntimeError("登录失败：仍停留在登录页")
        
        # 保存会话
        await self._save_session()
        print("✅ 登录成功，会话已保存")
    
    async def _has_captcha(self) -> bool:
        """检查是否有验证码"""
        try:
            captcha_frame = next(
                (f for f in self._page.frames if f.url and "turing.captcha.qcloud.com" in f.url),
                None,
            )
            return captcha_frame is not None
        except Exception:
            return False
    
    async def _save_session(self):
        """保存会话到存储"""
        storage_state = self.storage_dir / "storage_state.json"
        await self._context.storage_state(path=storage_state)
        print(f"💾 会话已保存：{storage_state}")
    
    async def navigate_to_search(self, query_params: Optional[dict] = None) -> str:
        """导航到搜索页面"""
        base_url = "https://lpt.liepin.com/recommend"
        if query_params:
            from urllib.parse import urlencode
            params = urlencode(query_params)
            base_url = f"{base_url}?{params}"
        
        await self._page.goto(
            base_url,
            timeout=self.config.navigation_timeout * 1000,
            wait_until="domcontentloaded",
        )
        await asyncio.sleep(1)
        return self._page.url
    
    async def close(self):
        """关闭浏览器"""
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
        self._browser = None
        self._context = None
        self._page = None
        self._playwright = None
    
    async def __aenter__(self) -> "LiepinSession":
        await self.start()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
