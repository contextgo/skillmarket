"""
Liepin Real-Page Helpers
实现 Codex 建议的页面解析功能：
1. Result count parsing from "共有X份简历"
2. Candidate action button detection (立即沟通/继续沟通)
3. Preview-card reading
4. Detail-page or pop-out handling
5. Return-to-list behavior
"""

import re
from typing import Optional
from dataclasses import dataclass
from playwright.async_api import Page, Locator


@dataclass
class CandidatePreview:
    """候选人预览信息"""
    name: Optional[str] = None
    title: Optional[str] = None
    current_company: Optional[str] = None
    current_city: Optional[str] = None
    education: Optional[str] = None
    experience_years: Optional[str] = None
    salary_range: Optional[str] = None
    last_active: Optional[str] = None
    profile_url: Optional[str] = None
    action_button: Optional[str] = None  # "立即沟通" / "继续沟通" / None


@dataclass
class SearchResult:
    """搜索结果统计"""
    total_count: int
    page_number: int
    total_pages: int
    candidates_on_page: int


class ResultCountParser:
    """解析搜索结果数量 - "共有X份简历" """
    
    @staticmethod
    def parse_result_count(page: Page) -> Optional[int]:
        """
        从页面中解析总结果数
        典型文本: "共有 1,234 份简历" 或 "共找到1234份简历"
        """
        # 方法1：查找包含"份简历"的文本
        try:
            # 尝试查找结果统计区域
            result_locator = page.locator("text=/共.*份简历/")
            if result_locator.count() > 0:
                text = result_locator.first.text_content()
                if text:
                    # 提取数字
                    match = re.search(r'共[有找到]?\s*([\d,]+)\s*份?简历', text)
                    if match:
                        count_str = match.group(1).replace(',', '')
                        return int(count_str)
        except Exception:
            pass
        
        # 方法2：查找页面标题或 meta 信息
        try:
            # 查找 ".result-count" 或类似的元素
            for selector in [".result-count", "[class*='result']", ".sofa-text"]:
                count_elem = page.locator(selector)
                if count_elem.count() > 0:
                    text = count_elem.first.text_content()
                    if text:
                        match = re.search(r'([\d,]+)', text)
                        if match:
                            return int(match.group(1).replace(',', ''))
        except Exception:
            pass
        
        return None
    
    @staticmethod
    def parse_pagination(page: Page) -> tuple[int, int]:
        """
        解析分页信息
        返回: (current_page, total_pages)
        """
        try:
            # 查找分页元素
            pagination = page.locator(".pager, .pagination, [class*='pager']")
            if pagination.count() > 0:
                text = pagination.first.text_content()
                if text:
                    # 匹配 "1/20" 格式
                    match = re.search(r'(\d+)\s*/\s*(\d+)', text)
                    if match:
                        return int(match.group(1)), int(match.group(2))
        except Exception:
            pass
        return 1, 1


class CandidateActionDetector:
    """候选人操作按钮检测"""
    
    BUTTON_TEXT_IMMEDIATE = "立即沟通"
    BUTTON_TEXT_CONTINUE = "继续沟通"
    
    @staticmethod
    async def detect_action_button(page: Page, candidate_card: Locator) -> Optional[str]:
        """
        检测候选人卡片上的操作按钮
        返回: "立即沟通" / "继续沟通" / None
        """
        try:
            # 查找包含"沟通"的按钮
            button_locator = candidate_card.locator(f"text=/立即沟通|继续沟通/")
            if button_locator.count() > 0:
                return await button_locator.first.text_content()
        except Exception:
            pass
        return None
    
    @staticmethod
    async def is_actionable(page: Page, candidate_card: Locator) -> bool:
        """检测候选人是否可以被联系（有沟通按钮）"""
        button = await CandidateActionDetector.detect_action_button(page, candidate_card)
        return button is not None


class PreviewCardReader:
    """预览卡片读取"""
    
    @staticmethod
    async def read_card(page: Page, card: Locator) -> CandidatePreview:
        """
        读取候选人预览卡片信息
        """
        preview = CandidatePreview()
        
        try:
            # 读取姓名
            name_elem = card.locator("[class*='name'], [class*='title-name'], .name")
            if name_elem.count() > 0:
                preview.name = (await name_elem.first.text_content()) or None
            
            # 读取职位标题
            title_elem = card.locator("[class*='title'], [class*='position'], h3")
            if title_elem.count() > 0:
                preview.title = (await title_elem.first.text_content()) or None
            
            # 读取公司名称
            company_elem = card.locator("[class*='company'], [class*='org']")
            if company_elem.count() > 0:
                preview.current_company = (await company_elem.first.text_content()) or None
            
            # 读取城市
            city_elem = card.locator("[class*='city'], [class*='location']")
            if city_elem.count() > 0:
                preview.current_city = (await city_elem.first.text_content()) or None
            
            # 读取学历
            edu_elem = card.locator("[class*='edu'], [class*='education']")
            if edu_elem.count() > 0:
                preview.education = (await edu_elem.first.text_content()) or None
            
            # 读取工作年限
            exp_elem = card.locator("[class*='exp'], [class*='experience'], [class*='year']")
            if exp_elem.count() > 0:
                preview.experience_years = (await exp_elem.first.text_content()) or None
            
            # 读取薪资范围
            salary_elem = card.locator("[class*='salary'], [class*='compensation']")
            if salary_elem.count() > 0:
                preview.salary_range = (await salary_elem.first.text_content()) or None
            
            # 读取最近活跃时间
            active_elem = card.locator("[class*='active'], [class*='update'], [class*='time']")
            if active_elem.count() > 0:
                preview.last_active = (await active_elem.first.text_content()) or None
            
            # 读取详情链接
            link_elem = card.locator("a[href*='liepin.com']")
            if link_elem.count() > 0:
                href = await link_elem.first.get_attribute("href")
                preview.profile_url = href
            
            # 读取操作按钮
            preview.action_button = await CandidateActionDetector.detect_action_button(page, card)
            
        except Exception as e:
            print(f"Warning: Error reading card: {e}")
        
        return preview
    
    @staticmethod
    async def read_all_candidates(page: Page) -> list[CandidatePreview]:
        """
        读取页面上所有候选人卡片
        """
        candidates = []
        
        # 查找候选人卡片容器
        # Liepin 的候选人卡片可能在不同容器中
        card_selectors = [
            ".candidate-item",
            ".sofa-list .sofa-item",
            "[class*='candidate']",
            ".resume-item",
            ".search-result .item",
        ]
        
        cards = None
        for selector in card_selectors:
            card_locator = page.locator(selector)
            if card_locator.count() > 0:
                cards = card_locator
                print(f"Found {cards.count()} cards with selector: {selector}")
                break
        
        if cards is None or cards.count() == 0:
            print("No candidate cards found")
            return candidates
        
        for i in range(cards.count()):
            try:
                card = cards.nth(i)
                preview = await PreviewCardReader.read_card(page, card)
                candidates.append(preview)
            except Exception as e:
                print(f"Warning: Error reading card {i}: {e}")
        
        return candidates


class DetailPageHandler:
    """详情页或弹出处理"""
    
    @staticmethod
    async def handle(page: Page, candidate: CandidatePreview) -> Optional[dict]:
        """
        处理候选人详情页
        可能的情况：
        1. 点击后新窗口打开
        2. 点击后页面内跳转
        3. 点击后弹出 modal
        """
        result = {"type": "unknown", "data": None}
        
        # 获取当前所有页面/窗口
        contexts = page.context.browser.contexts
        initial_pages = set(page.context.pages)
        
        # 尝试点击候选人卡片或详情链接
        # 这需要根据实际页面结构调整
        
        # 等待新窗口或弹窗
        try:
            await page.wait_for_timeout(1000)
            new_pages = set(page.context.pages) - initial_pages
            
            if new_pages:
                # 新窗口打开
                new_page = new_pages.pop()
                await new_page.wait_for_load_state("networkidle")
                result["type"] = "new_window"
                result["data"] = {
                    "url": new_page.url,
                    "title": await new_page.title()
                }
                return result
        except Exception:
            pass
        
        # 检查是否是 modal/popup
        try:
            modal = page.locator(".modal, [class*='modal'], .popup, [class*='popup']")
            if modal.count() > 0 and modal.first.is_visible():
                result["type"] = "modal"
                return result
        except Exception:
            pass
        
        return result
    
    @staticmethod
    async def return_to_list(page: Page, list_page: Page) -> bool:
        """
        从详情页返回列表页
        """
        try:
            # 查找返回按钮
            back_button = page.locator("text=/返回|back|后退/")
            if back_button.count() > 0:
                await back_button.first.click()
                await page.wait_for_load_state("networkidle")
                return True
            
            # 直接关闭当前页面/标签页
            if len(page.context.pages) > 1:
                await page.close()
                # 激活列表页
                await list_page.bring_to_front()
                return True
        except Exception:
            pass
        
        return False


class LiepinBrowserHelpers:
    """
    整合所有 helper 功能的主类
    """
    
    def __init__(self, page: Page):
        self.page = page
        self.result_parser = ResultCountParser()
        self.action_detector = CandidateActionDetector()
        self.preview_reader = PreviewCardReader()
        self.detail_handler = DetailPageHandler()
    
    async def get_search_result(self) -> Optional[SearchResult]:
        """获取搜索结果统计"""
        total = self.result_parser.parse_result_count(self.page)
        if total is None:
            return None
        
        current, total_pages = self.result_parser.parse_pagination(self.page)
        
        # 计算当前页候选人数量
        candidates = await self.preview_reader.read_all_candidates(self.page)
        
        return SearchResult(
            total_count=total,
            page_number=current,
            total_pages=total_pages,
            candidates_on_page=len(candidates)
        )
    
    async def get_all_candidates(self) -> list[CandidatePreview]:
        """获取当前页所有候选人"""
        return await self.preview_reader.read_all_candidates(self.page)
