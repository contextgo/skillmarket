from liepin_skill.models import Policy, RunState


def should_stop(state: RunState, policy: Policy) -> bool:
    return state.linked_count >= policy.target_links or state.search_changes >= policy.max_search_changes
