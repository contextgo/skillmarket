from __future__ import annotations

import json

from collections.abc import Mapping, Sequence
from typing import Any

from liepin_skill.evaluator import CandidateEvaluator
from liepin_skill.models import CandidateDecision
from liepin_skill.runtime.db import RuntimeDatabase
from liepin_skill.runtime.llm_clients import LightweightResumeClient, build_resume_client_from_env, ExternalClientError


class ResumeWorker:
    def __init__(
        self,
        *,
        lightweight_resume_client: LightweightResumeClient | None = None,
        evaluator: CandidateEvaluator | None = None,
    ) -> None:
        self.lightweight_resume_client = lightweight_resume_client
        self.evaluator = evaluator or CandidateEvaluator()

    def evaluate_preview(
        self,
        *,
        jd_compact_profile: dict[str, Any],
        preview_payload: dict[str, Any],
    ) -> CandidateDecision:
        # 优先检查：候选人是否已在猎聘上联系过
        if preview_payload.get("is_already_communicated"):
            return CandidateDecision(
                action="skip",
                reason="[自动去重] 候选人已在猎聘上联系过（显示为'继续沟通'状态）"
            )
        
        # Try LLM first (already has internal retries + fallback)
        if self.lightweight_resume_client is not None:
            try:
                payload = self.lightweight_resume_client.evaluate_preview(
                    jd_compact_profile=jd_compact_profile,
                    preview_payload=preview_payload,
                )
                return self._coerce_decision(payload)
            except ExternalClientError as exc:
                print(f"[FALLBACK] LLM preview eval failed, using deterministic evaluator: {exc}")

        # Deterministic fallback: keyword matching
        must_have = jd_compact_profile.get("must_have_signals", [])
        return self.evaluator.evaluate_preview(
            preview=preview_payload,
            must_have_terms=list(must_have),
        )

    def evaluate_detail(
        self,
        *,
        jd_compact_profile: dict[str, Any],
        detail_payload: dict[str, Any],
    ) -> CandidateDecision:
        if self.lightweight_resume_client is not None:
            try:
                payload = self.lightweight_resume_client.evaluate_detail(
                    jd_compact_profile=jd_compact_profile,
                    detail_payload=detail_payload,
                )
                return self._coerce_decision(payload)
            except ExternalClientError as exc:
                print(f"[FALLBACK] LLM detail eval failed, using deterministic evaluator: {exc}")

        must_have = jd_compact_profile.get("must_have_signals", [])
        return self.evaluator.evaluate_detail(
            detail=detail_payload,
            must_have_terms=list(must_have),
        )

    # ------------------------------------------------------------------
    # Batch Preview Evaluation
    # ------------------------------------------------------------------

    def batch_preview_eval(
        self,
        *,
        db: RuntimeDatabase,
        job_id: str,
        page_number: int,
    ) -> dict[str, int]:
        """Evaluate all pending_preview_eval candidates for a page in one LLM call.

        Returns a summary dict: {"total": N, "open_detail": N, "skip": N, "already_communicated": N}
        """
        candidates = db.list_candidate_queue_rows(
            job_id=job_id,
            page_number=page_number,
            status="pending_preview_eval",
        )
        if not candidates:
            return {"total": 0, "open_detail": 0, "skip": 0, "already_communicated": 0}

        latest_plan = db.get_latest_search_plan(job_id=job_id)
        if latest_plan is None:
            print(f"[BatchEval] No search plan found for job {job_id}")
            return {"total": len(candidates), "open_detail": 0, "skip": 0, "already_communicated": 0}

        jd_profile = latest_plan.get("jd_compact_profile", {})
        jd_text = jd_profile.get("jd_raw_text", "") or jd_profile.get("jd_summary", "")

        # Build candidates JSON for LLM
        candidates_for_llm = []
        for c in candidates:
            preview = json.loads(c["preview_payload_json"])
            candidates_for_llm.append({
                "queue_id": c["queue_id"],
                "name": preview.get("name", ""),
                "current_company": preview.get("current_company", ""),
                "title": preview.get("title", ""),
                "education": preview.get("education", ""),
                "experience_years": preview.get("experience_years", ""),
                "current_city": preview.get("current_city", ""),
                "visible_keywords": preview.get("visible_keywords", []),
                "action_button": preview.get("action_button", ""),
                "candidate_key": c.get("candidate_key", ""),
            })

        # Build batch prompt
        prompt = self._build_batch_preview_prompt(jd_text, candidates_for_llm, page_number)

        # Call LLM with retry
        result = self._call_llm_batch_with_retry(prompt, max_retries=3)

        # Parse result
        evaluations = self._parse_batch_result(result, candidates)

        # Apply hard-coded override: "继续沟通" → force skip
        stats = {"total": len(candidates), "open_detail": 0, "skip": 0, "already_communicated": 0}
        for ev in evaluations:
            c = next(c for c in candidates if c["queue_id"] == ev["queue_id"])
            preview = json.loads(c["preview_payload_json"])
            if preview.get("action_button") == "继续沟通":
                ev["action"] = "skip"
                ev["reason"] = "already_communicated"
                stats["already_communicated"] += 1
            elif ev["action"] == "open_detail":
                stats["open_detail"] += 1
            else:
                stats["skip"] += 1

            db.insert_candidate_evaluation(
                queue_id=ev["queue_id"],
                job_id=job_id,
                stage="preview",
                decision=ev["action"],
                evaluation_payload={"reason": ev.get("reason", ""), "source": "batch_eval"},
            )
            
            # Fix: set correct next status (pending_detail_harvest or completed)
            next_status = "pending_detail_harvest" if ev["action"] == "open_detail" else "completed"
            db.update_candidate_queue_status(queue_id=ev["queue_id"], status=next_status)

        db.record_event(
            job_id=job_id,
            event_type="resume_worker.batch_preview_eval_done",
            payload={"page_number": page_number, **stats},
        )
        print(f"[BatchEval] page={page_number}: {stats}")
        return stats

    def _build_batch_preview_prompt(
        self,
        jd_text: str,
        candidates: list[dict],
        page_number: int,
    ) -> str:
        return (
            f"You are evaluating candidates for a job. Given the job requirements and a list of "
            f"candidate previews, decide for each candidate whether to \"open_detail\" or \"skip\".\n\n"
            f"## Job Requirements\n{jd_text}\n\n"
            f"## Candidates (Page {page_number})\n"
            f"{json.dumps(candidates, ensure_ascii=False, indent=2)}\n\n"
            f"## Rules\n"
            f"1. If a candidate clearly matches the requirements → \"open_detail\"\n"
            f"2. If a candidate clearly doesn't match → \"skip\"\n"
            f"3. If unsure → \"open_detail\" (detail eval will make the final call)\n\n"
            f"## Output Format\n"
            f"Return ONLY a valid JSON array, no other text:\n"
            f'[{{"queue_id": "...", "action": "open_detail"}}, {{"queue_id": "...", "action": "skip"}}, ...]'
        )

    def _call_llm_batch_with_retry(self, prompt: str, max_retries: int = 3) -> str:
        """Call LLM for batch preview eval with exponential backoff and strategy refinement.
        Handles both LLM errors and JSON parse failures (empty responses, markdown, etc).
        Uses complete_batch_preview which has a longer timeout (60s)."""
        import re
        import time

        for attempt in range(max_retries):
            try:
                if self.lightweight_resume_client is not None:
                    # Strategy: On last attempt, add explicit formatting constraint
                    current_prompt = prompt
                    if attempt == max_retries - 1:
                        current_prompt += "\n\nIMPORTANT: Return ONLY a raw JSON array. No markdown, no triple backticks, no explanations. If no candidates match, return []."
                    
                    # Use complete_batch_preview which has 60s timeout
                    result = self.lightweight_resume_client.complete_batch_preview(
                        jd_text="",
                        candidates_json=current_prompt,
                        page_number=0,
                    )
                    
                    if not result or not result.strip():
                        print(f"[BatchEval] LLM returned empty response on attempt {attempt + 1}")
                        if attempt < max_retries - 1:
                            time.sleep(2 ** attempt)
                            continue
                        return "[]"

                    # Clean result before parsing
                    cleaned_result = result.strip()
                    # Remove markdown code block if present
                    if cleaned_result.startswith("```"):
                        match = re.search(r"```(?:json)?\s*(\[.*?\])\s*```", cleaned_result, re.DOTALL)
                        if match:
                            cleaned_result = match.group(1)
                    
                    # Try to parse as JSON to validate
                    json.loads(cleaned_result)
                    return cleaned_result

            except (json.JSONDecodeError, Exception) as e:
                print(f"[BatchEval] Attempt {attempt + 1} failed: {e}")
                if attempt < max_retries - 1:
                    wait_time = 2 ** attempt
                    time.sleep(wait_time)
                else:
                    print(f"[BatchEval] All retries exhausted. Returning empty array to prevent worker crash.")
                    return "[]"
        
        return "[]"

    def _parse_batch_result(
        self,
        result: str,
        expected_candidates: list[dict],
    ) -> list[dict]:
        """Parse LLM batch result with strict schema validation and fallback."""
        parsed = []
        try:
            parsed = json.loads(result)
            if not isinstance(parsed, list):
                # Handle cases where LLM returns {"evaluations": [...]}
                if isinstance(parsed, dict) and "evaluations" in parsed:
                    parsed = parsed["evaluations"]
                else:
                    raise ValueError("Parsed JSON is not a list or evaluations dict")
        except (json.JSONDecodeError, ValueError) as e:
            print(f"[BatchEval] Schema validation failed: {e}. Defaulting all to open_detail.")
            return [
                {"queue_id": c["queue_id"], "action": "open_detail", "reason": "llm_schema_validation_failed_default"}
                for c in expected_candidates
            ]

        # Build queue_id → evaluation map with per-item validation
        eval_map = {}
        for ev in parsed:
            if isinstance(ev, dict) and "queue_id" in ev:
                # Normalize action
                action = str(ev.get("action", "open_detail")).lower()
                if action not in ["open_detail", "skip", "link"]:
                    action = "open_detail"
                
                eval_map[str(ev["queue_id"])] = {
                    "queue_id": str(ev["queue_id"]),
                    "action": action,
                    "reason": str(ev.get("reason", "batch_eval_standard")),
                }

        # Fill in missing candidates with conservative default (open_detail)
        evaluations = []
        for c in expected_candidates:
            qid = str(c["queue_id"])
            if qid in eval_map:
                evaluations.append(eval_map[qid])
            else:
                evaluations.append({
                    "queue_id": qid,
                    "action": "open_detail",
                    "reason": "missing_from_llm_response_default",
                })

        return evaluations

    def _coerce_decision(self, payload: Any) -> CandidateDecision:
        if isinstance(payload, CandidateDecision):
            return payload
        if isinstance(payload, Mapping):
            return CandidateDecision.model_validate(payload)
        return CandidateDecision.model_validate(payload)

    def _require_must_have_signals(self, jd_compact_profile: Mapping[str, Any]) -> tuple[str, ...]:
        if "must_have_signals" not in jd_compact_profile:
            raise KeyError("Missing required field: must_have_signals")

        signals = jd_compact_profile["must_have_signals"]
        if isinstance(signals, str) or not isinstance(signals, Sequence):
            raise TypeError("jd_compact_profile['must_have_signals'] must be a sequence of strings")

        terms: list[str] = []
        for index, term in enumerate(signals):
            if not isinstance(term, str):
                raise TypeError(
                    f"jd_compact_profile['must_have_signals'][{index}] must be a string"
                )
            terms.append(term)
        return tuple(terms)

    def run_job(self, *, db: RuntimeDatabase, job_id: str) -> CandidateDecision | None:
        latest_plan = db.get_latest_search_plan(job_id=job_id)
        if latest_plan is None:
            db.record_event(job_id=job_id, event_type="resume_worker.waiting_for_plan")
            return None

        last_decision: CandidateDecision | None = None
        focused_page = db.get_next_resume_page_number(job_id=job_id)

        while focused_page is not None:
            db.record_event(
                job_id=job_id,
                event_type="resume_worker.page_processing_started",
                payload={"page_number": focused_page},
            )

            # ── STEP 0: Check if batch preview eval is needed for this page ──
            # Priority 1: Check if there are pending_preview_eval candidates on this page.
            # If so, trigger batch eval directly (don't fall through to individual eval).
            pending_previews = db.list_candidate_queue_rows(
                job_id=job_id,
                page_number=focused_page,
                status="pending_preview_eval",
            )
            if pending_previews and len(pending_previews) > 1:
                # Multiple pending previews → use batch eval
                print(f"[ResumeWorker] {len(pending_previews)} pending previews on page {focused_page} → batch eval")
                stats = self.batch_preview_eval(db=db, job_id=job_id, page_number=focused_page)
                print(f"[ResumeWorker] Batch eval done: {stats}")
                # After batch eval, candidate statuses changed → re-check focused_page
                focused_page = db.get_next_resume_page_number(job_id=job_id)
                continue
            elif pending_previews and len(pending_previews) == 1:
                # Only 1 pending → still use batch eval (logic is correct for any count)
                print(f"[ResumeWorker] 1 pending preview on page {focused_page} → batch eval")
                stats = self.batch_preview_eval(db=db, job_id=job_id, page_number=focused_page)
                print(f"[ResumeWorker] Batch eval done: {stats}")
                focused_page = db.get_next_resume_page_number(job_id=job_id)
                continue

            # Priority 2: Fallback — check orchestrator batch request event
            latest_batch_requested = db.get_latest_event(
                job_id=job_id,
                event_type_prefix="orchestrator.batch_preview_eval_requested",
            )
            latest_batch_done = db.get_latest_event(
                job_id=job_id,
                event_type_prefix="resume_worker.batch_preview_eval_done",
            )

            if latest_batch_requested and (
                latest_batch_done is None
                or latest_batch_requested["created_at"] > latest_batch_done["created_at"]
            ):
                batch_page = (latest_batch_requested.get("payload") or {}).get("page_number")
                if batch_page is not None:
                    print(f"[ResumeWorker] Executing batch preview eval for page {batch_page} (orchestrator requested)")
                    stats = self.batch_preview_eval(db=db, job_id=job_id, page_number=batch_page)
                    print(f"[ResumeWorker] Batch eval done: {stats}")
                    # After batch eval, candidate statuses changed → re-check focused_page
                    focused_page = db.get_next_resume_page_number(job_id=job_id)
                    continue

            # ── STEP 1: Process detail_harvested (higher priority) ──
            queue_row = None
            page_detail_rows = db.list_candidate_queue_rows(
                job_id=job_id,
                page_number=focused_page,
                status="detail_harvested",
            )
            if page_detail_rows:
                queue_row = db.claim_candidate(
                    queue_id=page_detail_rows[0]["queue_id"],
                    worker_name="resume-worker",
                    lease_seconds=60,
                    status="detail_harvested",
                )
                db.record_event(
                    job_id=job_id,
                    event_type="resume_worker.page_scoped_detail_claim",
                    payload={"page_number": focused_page, "queue_id": page_detail_rows[0]["queue_id"]},
                )
            if queue_row is not None:
                # Read from detail_payload_json (preview_payload_json preserved for reference)
                detail_payload = json.loads(queue_row.get("detail_payload_json") or queue_row["preview_payload_json"])
                decision = self.evaluate_detail(
                    jd_compact_profile=latest_plan["jd_compact_profile"],
                    detail_payload=detail_payload,
                )
                db.insert_candidate_evaluation(
                    queue_id=queue_row["queue_id"],
                    job_id=job_id,
                    stage="detail",
                    decision=decision.action,
                    evaluation_payload=decision.model_dump(),
                )
                next_status = "pending_communication" if decision.action == "link" else "completed"
                db.update_candidate_queue_status(queue_id=queue_row["queue_id"], status=next_status)
                db.record_event(
                    job_id=job_id,
                    event_type="resume_worker.detail_evaluated",
                    payload={"queue_id": queue_row["queue_id"], "decision": decision.action, "next_status": next_status},
                )
                if decision.action == "link":
                    db.record_event(
                        job_id=job_id,
                        event_type="resume_worker.promoted_to_communication_direct",
                        payload={"queue_id": queue_row["queue_id"]},
                    )
                last_decision = decision
                continue

            queue_row = None
            page_pending_previews = db.list_candidate_queue_rows(
                job_id=job_id,
                page_number=focused_page,
                status="pending_preview_eval",
            )
            if page_pending_previews:
                queue_row = db.claim_candidate(
                    queue_id=page_pending_previews[0]["queue_id"],
                    worker_name="resume-worker",
                    lease_seconds=60,
                    status="pending_preview_eval",
                )
                db.record_event(
                    job_id=job_id,
                    event_type="resume_worker.page_scoped_preview_claim",
                    payload={"page_number": focused_page, "queue_id": page_pending_previews[0]["queue_id"]},
                )
            if queue_row is None:
                page_still_pending = db.page_has_resume_work(job_id=job_id, page_number=focused_page)
                db.record_event(
                    job_id=job_id,
                    event_type="resume_worker.page_processing_finished",
                    payload={"page_number": focused_page, "page_still_pending": page_still_pending},
                )
                if page_still_pending:
                    break
                focused_page = db.get_next_resume_page_number(job_id=job_id)
                continue

            preview_payload = json.loads(queue_row["preview_payload_json"])
            decision = self.evaluate_preview(
                jd_compact_profile=latest_plan["jd_compact_profile"],
                preview_payload=preview_payload,
            )
            if decision.action == "link":
                db.record_event(
                    job_id=job_id,
                    event_type="resume_worker.preview_link_blocked",
                    payload={"queue_id": queue_row["queue_id"]},
                )
                decision = CandidateDecision(
                    action="open_detail",
                    reason=f"preview link blocked by implementation plan; downgraded. original_reason={decision.reason}",
                )
            db.insert_candidate_evaluation(
                queue_id=queue_row["queue_id"],
                job_id=job_id,
                stage="preview",
                decision=decision.action,
                evaluation_payload=decision.model_dump(),
            )
            db.update_candidate_queue_status(
                queue_id=queue_row["queue_id"],
                status="completed",
            )
            db.record_event(
                job_id=job_id,
                event_type="resume_worker.preview_evaluated",
                payload={
                    "queue_id": queue_row["queue_id"],
                    "decision": decision.action,
                    "page_number": queue_row.get("page_number"),
                },
            )
            if decision.action == "open_detail":
                page_number = int(queue_row.get("page_number", 0) or 0)
                page_open_detail_count = len(
                    db.list_candidate_queue_rows(
                        job_id=job_id,
                        page_number=page_number,
                        statuses=("completed", "pending_detail_harvest", "detail_harvested", "pending_communication"),
                    )
                )
                db.record_event(
                    job_id=job_id,
                    event_type="resume_worker.page_open_detail_selected",
                    payload={
                        "queue_id": queue_row["queue_id"],
                        "page_number": page_number,
                        "page_open_detail_count": page_open_detail_count,
                    },
                )
            last_decision = decision
            continue

        if last_decision is None:
            db.record_event(
                job_id=job_id,
                event_type="resume_worker.idle",
                payload={"reason": "no_pending_candidates"},
            )
        return last_decision


def build_default_resume_worker() -> ResumeWorker:
    return ResumeWorker(lightweight_resume_client=build_resume_client_from_env())
